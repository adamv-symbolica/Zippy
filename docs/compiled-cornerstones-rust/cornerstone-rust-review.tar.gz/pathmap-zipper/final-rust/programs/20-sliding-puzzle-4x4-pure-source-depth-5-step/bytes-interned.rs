#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,16]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 2 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,17]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,18]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 3 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 3 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,19]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 4 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,20]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,21]));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 6 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,22]));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,23]));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,24]));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 5 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_21: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,25]));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,26]));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 56 0 0 0 2 0 0 0 3 0 0 0 7 0 0 0 4 0 0 0 5 0 0 0 6 0 0 0 11 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 7 0 0 0 11 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 11 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_25: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,27]));
static CONSTANT_26: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_27: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,28]));
static CONSTANT_28: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15"));
static CONSTANT_29: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,29]));
static CONSTANT_30: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 4 0 0 0 5 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 5 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15"));
static CONSTANT_31: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_32: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_33: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 5 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_34: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_35: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 1 0 0 0 2 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 3 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 2 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_36: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 5 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 5 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_37: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 5 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_38: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 6 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 6 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 5 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 2 0 0 0 6 0 0 0 3 0 0 0 5 0 0 0 1 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_39: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_40: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_41: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 9 0 0 0 14 0 0 0 15"));
static CONSTANT_42: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_43: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 11 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_44: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 8 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_45: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_46: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 6 0 0 0 10 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 10 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 5 0 0 0 9 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 10 0 0 0 14 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 9 0 0 0 13 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 14 0 0 0 15 56 0 0 0 1 0 0 0 2 0 0 0 3 0 0 0 8 0 0 0 5 0 0 0 6 0 0 0 7 0 0 0 12 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_47: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_48: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 2 0 0 0 3 0 0 0 1 0 0 0 4 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_49: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 56 0 0 0 4 0 0 0 2 0 0 0 3 0 0 0 1 0 0 0 6 0 0 0 7 0 0 0 8 0 0 0 9 0 0 0 10 0 0 0 11 0 0 0 12 0 0 0 13 0 0 0 14 0 0 0 15"));
static CONSTANT_50: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 0"));
static CONSTANT_51: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 16"));
static CONSTANT_52: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 17"));
static CONSTANT_53: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 18"));
static CONSTANT_54: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 19"));
static CONSTANT_55: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 20"));
static CONSTANT_56: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 21"));
static CONSTANT_57: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 22"));
static CONSTANT_58: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 23"));
static CONSTANT_59: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 24"));
static CONSTANT_60: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 25"));
static CONSTANT_61: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 26"));
static CONSTANT_62: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 27"));
static CONSTANT_63: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 28"));
static CONSTANT_64: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 29"));
static CONSTANT_65: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 34"));
static CONSTANT_66: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 30 0 0 0 0 0 0 0 19 12 0 0 0 30 0 0 0 19 0 0 0 0 12 0 0 0 31 0 0 0 0 0 0 0 16 12 0 0 0 31 0 0 0 16 0 0 0 0"));
static CONSTANT_67: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 16 0 0 0 20 12 0 0 0 30 0 0 0 20 0 0 0 16 12 0 0 0 31 0 0 0 16 0 0 0 17 12 0 0 0 31 0 0 0 17 0 0 0 16 12 0 0 0 32 0 0 0 0 0 0 0 16 12 0 0 0 32 0 0 0 16 0 0 0 0"));
static CONSTANT_68: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 17 0 0 0 21 12 0 0 0 30 0 0 0 21 0 0 0 17 12 0 0 0 31 0 0 0 17 0 0 0 18 12 0 0 0 31 0 0 0 18 0 0 0 17 12 0 0 0 32 0 0 0 16 0 0 0 17 12 0 0 0 32 0 0 0 17 0 0 0 16"));
static CONSTANT_69: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 30 0 0 0 18 0 0 0 22 12 0 0 0 30 0 0 0 22 0 0 0 18 12 0 0 0 32 0 0 0 17 0 0 0 18 12 0 0 0 32 0 0 0 18 0 0 0 17"));
static CONSTANT_70: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 19 0 0 0 23 12 0 0 0 30 0 0 0 23 0 0 0 19 12 0 0 0 31 0 0 0 19 0 0 0 20 12 0 0 0 31 0 0 0 20 0 0 0 19 12 0 0 0 33 0 0 0 0 0 0 0 19 12 0 0 0 33 0 0 0 19 0 0 0 0"));
static CONSTANT_71: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 12 0 0 0 30 0 0 0 20 0 0 0 24 12 0 0 0 30 0 0 0 24 0 0 0 20 12 0 0 0 31 0 0 0 20 0 0 0 21 12 0 0 0 31 0 0 0 21 0 0 0 20 12 0 0 0 32 0 0 0 19 0 0 0 20 12 0 0 0 32 0 0 0 20 0 0 0 19 12 0 0 0 33 0 0 0 16 0 0 0 20 12 0 0 0 33 0 0 0 20 0 0 0 16"));
static CONSTANT_72: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 12 0 0 0 30 0 0 0 21 0 0 0 25 12 0 0 0 30 0 0 0 25 0 0 0 21 12 0 0 0 31 0 0 0 21 0 0 0 22 12 0 0 0 31 0 0 0 22 0 0 0 21 12 0 0 0 32 0 0 0 20 0 0 0 21 12 0 0 0 32 0 0 0 21 0 0 0 20 12 0 0 0 33 0 0 0 17 0 0 0 21 12 0 0 0 33 0 0 0 21 0 0 0 17"));
static CONSTANT_73: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 22 0 0 0 26 12 0 0 0 30 0 0 0 26 0 0 0 22 12 0 0 0 32 0 0 0 21 0 0 0 22 12 0 0 0 32 0 0 0 22 0 0 0 21 12 0 0 0 33 0 0 0 18 0 0 0 22 12 0 0 0 33 0 0 0 22 0 0 0 18"));
static CONSTANT_74: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 23 0 0 0 27 12 0 0 0 30 0 0 0 27 0 0 0 23 12 0 0 0 31 0 0 0 23 0 0 0 24 12 0 0 0 31 0 0 0 24 0 0 0 23 12 0 0 0 33 0 0 0 19 0 0 0 23 12 0 0 0 33 0 0 0 23 0 0 0 19"));
static CONSTANT_75: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 12 0 0 0 30 0 0 0 24 0 0 0 28 12 0 0 0 30 0 0 0 28 0 0 0 24 12 0 0 0 31 0 0 0 24 0 0 0 25 12 0 0 0 31 0 0 0 25 0 0 0 24 12 0 0 0 32 0 0 0 23 0 0 0 24 12 0 0 0 32 0 0 0 24 0 0 0 23 12 0 0 0 33 0 0 0 20 0 0 0 24 12 0 0 0 33 0 0 0 24 0 0 0 20"));
static CONSTANT_76: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 12 0 0 0 30 0 0 0 25 0 0 0 29 12 0 0 0 30 0 0 0 29 0 0 0 25 12 0 0 0 31 0 0 0 25 0 0 0 26 12 0 0 0 31 0 0 0 26 0 0 0 25 12 0 0 0 32 0 0 0 24 0 0 0 25 12 0 0 0 32 0 0 0 25 0 0 0 24 12 0 0 0 33 0 0 0 21 0 0 0 25 12 0 0 0 33 0 0 0 25 0 0 0 21"));
static CONSTANT_77: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 30 0 0 0 26 0 0 0 34 12 0 0 0 30 0 0 0 34 0 0 0 26 12 0 0 0 32 0 0 0 25 0 0 0 26 12 0 0 0 32 0 0 0 26 0 0 0 25 12 0 0 0 33 0 0 0 22 0 0 0 26 12 0 0 0 33 0 0 0 26 0 0 0 22"));
static CONSTANT_78: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 31 0 0 0 27 0 0 0 28 12 0 0 0 31 0 0 0 28 0 0 0 27 12 0 0 0 33 0 0 0 23 0 0 0 27 12 0 0 0 33 0 0 0 27 0 0 0 23"));
static CONSTANT_79: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 31 0 0 0 28 0 0 0 29 12 0 0 0 31 0 0 0 29 0 0 0 28 12 0 0 0 32 0 0 0 27 0 0 0 28 12 0 0 0 32 0 0 0 28 0 0 0 27 12 0 0 0 33 0 0 0 24 0 0 0 28 12 0 0 0 33 0 0 0 28 0 0 0 24"));
static CONSTANT_80: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 12 0 0 0 31 0 0 0 29 0 0 0 34 12 0 0 0 31 0 0 0 34 0 0 0 29 12 0 0 0 32 0 0 0 28 0 0 0 29 12 0 0 0 32 0 0 0 29 0 0 0 28 12 0 0 0 33 0 0 0 25 0 0 0 29 12 0 0 0 33 0 0 0 29 0 0 0 25"));
static CONSTANT_81: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,34]));
static CONSTANT_82: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 32 0 0 0 29 0 0 0 34 12 0 0 0 32 0 0 0 34 0 0 0 29 12 0 0 0 33 0 0 0 26 0 0 0 34 12 0 0 0 33 0 0 0 34 0 0 0 26"));
static CONSTANT_83: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("16 8 0 0 0 0 0 0 0 0 8 0 0 0 16 0 0 0 16 8 0 0 0 17 0 0 0 17 8 0 0 0 18 0 0 0 18 8 0 0 0 19 0 0 0 19 8 0 0 0 20 0 0 0 20 8 0 0 0 21 0 0 0 21 8 0 0 0 22 0 0 0 22 8 0 0 0 23 0 0 0 23 8 0 0 0 24 0 0 0 24 8 0 0 0 25 0 0 0 25 8 0 0 0 26 0 0 0 26 8 0 0 0 27 0 0 0 27 8 0 0 0 28 0 0 0 28 8 0 0 0 29 0 0 0 29 8 0 0 0 34 0 0 0 34"));
static CONSTANT_84: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 0 0 0 0 35"));
static CONSTANT_85: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 16 0 0 0 35"));
static CONSTANT_86: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 17 0 0 0 35"));
static CONSTANT_87: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 18 0 0 0 35"));
static CONSTANT_88: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 19 0 0 0 35"));
static CONSTANT_89: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 20 0 0 0 35"));
static CONSTANT_90: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 21 0 0 0 35"));
static CONSTANT_91: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 22 0 0 0 35"));
static CONSTANT_92: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 23 0 0 0 35"));
static CONSTANT_93: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 24 0 0 0 35"));
static CONSTANT_94: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 25 0 0 0 35"));
static CONSTANT_95: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 26 0 0 0 35"));
static CONSTANT_96: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 27 0 0 0 35"));
static CONSTANT_97: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 28 0 0 0 35"));
static CONSTANT_98: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 29 0 0 0 35"));
static CONSTANT_99: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 34 0 0 0 35"));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Path,capture_1: &Path,capture_2: &Path,capture_3: &Path,capture_4: &Path,capture_5: &Path,capture_6: &Path,capture_7: &Path,capture_8: &Path,capture_9: &Path,capture_10: &Path,capture_11: &Path,capture_12: &Path,capture_13: &Path,capture_14: &Path,capture_15: &Path) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v64_18: Space = singleton(&(*capture_1));
  let v64_19: Space = map_map_kernels::intersect(&(*CONSTANT_50),&(v64_18));
  let mut v64_20 = Space::new();
  let mut v64_20_cursor = (v64_19).read_zipper();
  for v64_20_byte in v64_20_cursor.child_mask().iter() {
    v64_20_cursor.descend_to_byte(v64_20_byte);
    {
    let v64_20_tail = v64_20_cursor.fork_read_zipper();
    let v64_20_head = Path::from_slice(&[v64_20_byte]);
    let mut v65_2 = Space::new();
    let mut v65_2_cursor = (v64_20_tail).read_zipper();
    for v65_2_byte in v65_2_cursor.child_mask().iter() {
      v65_2_cursor.descend_to_byte(v65_2_byte);
      {
      let v65_2_tail = v65_2_cursor.fork_read_zipper();
      let v65_2_head = Path::from_slice(&[v65_2_byte]);
      let v66_2: Path = concat_path(&(v64_20_head),&(v65_2_head));
      let mut v66_3 = Space::new();
      let mut v66_3_cursor = (v65_2_tail).read_zipper();
      for v66_3_byte in v66_3_cursor.child_mask().iter() {
        v66_3_cursor.descend_to_byte(v66_3_byte);
        {
        let v66_3_tail = v66_3_cursor.fork_read_zipper();
        let v66_3_head = Path::from_slice(&[v66_3_byte]);
        let v67_2: Path = concat_path(&(v66_2),&(v66_3_head));
        let mut v67_3 = Space::new();
        let mut v67_3_cursor = (v66_3_tail).read_zipper();
        for v67_3_byte in v67_3_cursor.child_mask().iter() {
          v67_3_cursor.descend_to_byte(v67_3_byte);
          {
          let v67_3_tail = v67_3_cursor.fork_read_zipper();
          let v67_3_head = Path::from_slice(&[v67_3_byte]);
          let v68_2: Path = concat_path(&(v67_2),&(v67_3_head));
          let v68_3: Space = routine_9(c, &(v68_2), &(v67_3_tail).make_space());
          drop(v68_2);
          v67_3.join_into((v68_3).clone());
          }
          v67_3_cursor.ascend(1);
        }
        drop(v67_3_cursor);
        drop(v67_2);
        v66_3.join_into((v67_3).clone());
        }
        v66_3_cursor.ascend(1);
      }
      drop(v66_3_cursor);
      drop(v66_2);
      v65_2.join_into((v66_3).clone());
      }
      v65_2_cursor.ascend(1);
    }
    drop(v65_2_cursor);
    v64_20.join_into((v65_2).clone());
    }
    v64_20_cursor.ascend(1);
  }
  drop(v64_20_cursor);
  drop(v64_19);
  let v64_37: Space = if (v64_20).is_empty() { Space::new() } else {
    let v69_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v69_22: Path = concat_path(&(v69_21),&(*capture_10));
    drop(v69_21);
    let v69_23: Path = concat_path(&(v69_22),&(*capture_11));
    drop(v69_22);
    let v69_24: Path = concat_path(&(v69_23),&(*capture_12));
    drop(v69_23);
    let v69_25: Path = concat_path(&(v69_24),&(*capture_13));
    drop(v69_24);
    let v69_26: Path = concat_path(&(v69_25),&(*capture_14));
    drop(v69_25);
    let v69_27: Path = concat_path(&(v69_26),&(*capture_15));
    drop(v69_26);
    let v69_28: Path = concat_path(&(v69_27),&(*capture_2));
    drop(v69_27);
    let v69_29: Path = concat_path(&(v69_28),&(*capture_3));
    drop(v69_28);
    let v69_30: Path = concat_path(&(v69_29),&(*capture_4));
    drop(v69_29);
    let v69_31: Path = concat_path(&(v69_30),&(*capture_5));
    drop(v69_30);
    let v69_32: Path = concat_path(&(v69_31),&(*capture_6));
    drop(v69_31);
    let v69_33: Path = concat_path(&(v69_32),&(*capture_7));
    drop(v69_32);
    let v69_34: Path = concat_path(&(v69_33),&(*capture_0));
    drop(v69_33);
    let v69_35: Space = singleton(&(v69_34));
    drop(v69_34);
    let mut v69_36 = Space::new();
    let mut v69_36_cursor = (v69_35).read_zipper();
    for v69_36_byte in v69_36_cursor.child_mask().iter() {
      v69_36_cursor.descend_to_byte(v69_36_byte);
      {
      let v69_36_tail = v69_36_cursor.fork_read_zipper();
      let v69_36_head = Path::from_slice(&[v69_36_byte]);
      let mut v70_2 = Space::new();
      let mut v70_2_cursor = (v69_36_tail).read_zipper();
      for v70_2_byte in v70_2_cursor.child_mask().iter() {
        v70_2_cursor.descend_to_byte(v70_2_byte);
        {
        let v70_2_tail = v70_2_cursor.fork_read_zipper();
        let v70_2_head = Path::from_slice(&[v70_2_byte]);
        let v71_2: Path = concat_path(&(v69_36_head),&(v70_2_head));
        let mut v71_3 = Space::new();
        let mut v71_3_cursor = (v70_2_tail).read_zipper();
        for v71_3_byte in v71_3_cursor.child_mask().iter() {
          v71_3_cursor.descend_to_byte(v71_3_byte);
          {
          let v71_3_tail = v71_3_cursor.fork_read_zipper();
          let v71_3_head = Path::from_slice(&[v71_3_byte]);
          let v72_2: Path = concat_path(&(v71_2),&(v71_3_head));
          let mut v72_3 = Space::new();
          let mut v72_3_cursor = (v71_3_tail).read_zipper();
          for v72_3_byte in v72_3_cursor.child_mask().iter() {
            v72_3_cursor.descend_to_byte(v72_3_byte);
            {
            let v72_3_tail = v72_3_cursor.fork_read_zipper();
            let v72_3_head = Path::from_slice(&[v72_3_byte]);
            let v73_2: Path = concat_path(&(v72_2),&(v72_3_head));
            let v73_3: Space = routine_10(c, &(v73_2), &(v72_3_tail).make_space());
            drop(v73_2);
            v72_3.join_into((v73_3).clone());
            }
            v72_3_cursor.ascend(1);
          }
          drop(v72_3_cursor);
          drop(v72_2);
          v71_3.join_into((v72_3).clone());
          }
          v71_3_cursor.ascend(1);
        }
        drop(v71_3_cursor);
        drop(v71_2);
        v70_2.join_into((v71_3).clone());
        }
        v70_2_cursor.ascend(1);
      }
      drop(v70_2_cursor);
      v69_36.join_into((v70_2).clone());
      }
      v69_36_cursor.ascend(1);
    }
    drop(v69_36_cursor);
    map_map_kernels::compose(&(v64_20),&(v69_36))
  };
  let v64_39: Space = map_map_kernels::intersect(&(*CONSTANT_51),&(v64_18));
  let mut v64_40 = Space::new();
  let mut v64_40_cursor = (v64_39).read_zipper();
  for v64_40_byte in v64_40_cursor.child_mask().iter() {
    v64_40_cursor.descend_to_byte(v64_40_byte);
    {
    let v64_40_tail = v64_40_cursor.fork_read_zipper();
    let v64_40_head = Path::from_slice(&[v64_40_byte]);
    let mut v74_2 = Space::new();
    let mut v74_2_cursor = (v64_40_tail).read_zipper();
    for v74_2_byte in v74_2_cursor.child_mask().iter() {
      v74_2_cursor.descend_to_byte(v74_2_byte);
      {
      let v74_2_tail = v74_2_cursor.fork_read_zipper();
      let v74_2_head = Path::from_slice(&[v74_2_byte]);
      let v75_2: Path = concat_path(&(v64_40_head),&(v74_2_head));
      let mut v75_3 = Space::new();
      let mut v75_3_cursor = (v74_2_tail).read_zipper();
      for v75_3_byte in v75_3_cursor.child_mask().iter() {
        v75_3_cursor.descend_to_byte(v75_3_byte);
        {
        let v75_3_tail = v75_3_cursor.fork_read_zipper();
        let v75_3_head = Path::from_slice(&[v75_3_byte]);
        let v76_2: Path = concat_path(&(v75_2),&(v75_3_head));
        let mut v76_3 = Space::new();
        let mut v76_3_cursor = (v75_3_tail).read_zipper();
        for v76_3_byte in v76_3_cursor.child_mask().iter() {
          v76_3_cursor.descend_to_byte(v76_3_byte);
          {
          let v76_3_tail = v76_3_cursor.fork_read_zipper();
          let v76_3_head = Path::from_slice(&[v76_3_byte]);
          let v77_2: Path = concat_path(&(v76_2),&(v76_3_head));
          let v77_3: Space = routine_11(c, &(v77_2), &(v76_3_tail).make_space());
          drop(v77_2);
          v76_3.join_into((v77_3).clone());
          }
          v76_3_cursor.ascend(1);
        }
        drop(v76_3_cursor);
        drop(v76_2);
        v75_3.join_into((v76_3).clone());
        }
        v75_3_cursor.ascend(1);
      }
      drop(v75_3_cursor);
      drop(v75_2);
      v74_2.join_into((v75_3).clone());
      }
      v74_2_cursor.ascend(1);
    }
    drop(v74_2_cursor);
    v64_40.join_into((v74_2).clone());
    }
    v64_40_cursor.ascend(1);
  }
  drop(v64_40_cursor);
  drop(v64_39);
  let v64_42: Space = if (v64_40).is_empty() { Space::new() } else {
    let v78_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v78_22: Path = concat_path(&(v78_21),&(*capture_10));
    drop(v78_21);
    let v78_23: Path = concat_path(&(v78_22),&(*capture_11));
    drop(v78_22);
    let v78_24: Path = concat_path(&(v78_23),&(*capture_12));
    drop(v78_23);
    let v78_25: Path = concat_path(&(v78_24),&(*capture_13));
    drop(v78_24);
    let v78_26: Path = concat_path(&(v78_25),&(*capture_14));
    drop(v78_25);
    let v78_27: Path = concat_path(&(v78_26),&(*capture_15));
    drop(v78_26);
    let v78_28: Path = concat_path(&(v78_27),&(*capture_2));
    drop(v78_27);
    let v78_29: Path = concat_path(&(v78_28),&(*capture_3));
    drop(v78_28);
    let v78_30: Path = concat_path(&(v78_29),&(*capture_4));
    drop(v78_29);
    let v78_31: Path = concat_path(&(v78_30),&(*capture_5));
    drop(v78_30);
    let v78_32: Path = concat_path(&(v78_31),&(*capture_6));
    drop(v78_31);
    let v78_33: Path = concat_path(&(v78_32),&(*capture_7));
    drop(v78_32);
    let v78_34: Path = concat_path(&(v78_33),&(*capture_0));
    drop(v78_33);
    let v78_35: Space = singleton(&(v78_34));
    drop(v78_34);
    let mut v78_41 = Space::new();
    let mut v78_41_cursor = (v78_35).read_zipper();
    for v78_41_byte in v78_41_cursor.child_mask().iter() {
      v78_41_cursor.descend_to_byte(v78_41_byte);
      {
      let v78_41_tail = v78_41_cursor.fork_read_zipper();
      let v78_41_head = Path::from_slice(&[v78_41_byte]);
      let mut v79_2 = Space::new();
      let mut v79_2_cursor = (v78_41_tail).read_zipper();
      for v79_2_byte in v79_2_cursor.child_mask().iter() {
        v79_2_cursor.descend_to_byte(v79_2_byte);
        {
        let v79_2_tail = v79_2_cursor.fork_read_zipper();
        let v79_2_head = Path::from_slice(&[v79_2_byte]);
        let v80_2: Path = concat_path(&(v78_41_head),&(v79_2_head));
        let mut v80_3 = Space::new();
        let mut v80_3_cursor = (v79_2_tail).read_zipper();
        for v80_3_byte in v80_3_cursor.child_mask().iter() {
          v80_3_cursor.descend_to_byte(v80_3_byte);
          {
          let v80_3_tail = v80_3_cursor.fork_read_zipper();
          let v80_3_head = Path::from_slice(&[v80_3_byte]);
          let v81_2: Path = concat_path(&(v80_2),&(v80_3_head));
          let mut v81_3 = Space::new();
          let mut v81_3_cursor = (v80_3_tail).read_zipper();
          for v81_3_byte in v81_3_cursor.child_mask().iter() {
            v81_3_cursor.descend_to_byte(v81_3_byte);
            {
            let v81_3_tail = v81_3_cursor.fork_read_zipper();
            let v81_3_head = Path::from_slice(&[v81_3_byte]);
            let v82_2: Path = concat_path(&(v81_2),&(v81_3_head));
            let v82_3: Space = routine_12(c, &(v82_2), &(v81_3_tail).make_space());
            drop(v82_2);
            v81_3.join_into((v82_3).clone());
            }
            v81_3_cursor.ascend(1);
          }
          drop(v81_3_cursor);
          drop(v81_2);
          v80_3.join_into((v81_3).clone());
          }
          v80_3_cursor.ascend(1);
        }
        drop(v80_3_cursor);
        drop(v80_2);
        v79_2.join_into((v80_3).clone());
        }
        v79_2_cursor.ascend(1);
      }
      drop(v79_2_cursor);
      v78_41.join_into((v79_2).clone());
      }
      v78_41_cursor.ascend(1);
    }
    drop(v78_41_cursor);
    map_map_kernels::compose(&(v64_40),&(v78_41))
  };
  let v64_43: Space = map_map_kernels::unite(&(v64_37),&(v64_42));
  let v64_45: Space = map_map_kernels::intersect(&(*CONSTANT_52),&(v64_18));
  let mut v64_46 = Space::new();
  let mut v64_46_cursor = (v64_45).read_zipper();
  for v64_46_byte in v64_46_cursor.child_mask().iter() {
    v64_46_cursor.descend_to_byte(v64_46_byte);
    {
    let v64_46_tail = v64_46_cursor.fork_read_zipper();
    let v64_46_head = Path::from_slice(&[v64_46_byte]);
    let mut v83_2 = Space::new();
    let mut v83_2_cursor = (v64_46_tail).read_zipper();
    for v83_2_byte in v83_2_cursor.child_mask().iter() {
      v83_2_cursor.descend_to_byte(v83_2_byte);
      {
      let v83_2_tail = v83_2_cursor.fork_read_zipper();
      let v83_2_head = Path::from_slice(&[v83_2_byte]);
      let v84_2: Path = concat_path(&(v64_46_head),&(v83_2_head));
      let mut v84_3 = Space::new();
      let mut v84_3_cursor = (v83_2_tail).read_zipper();
      for v84_3_byte in v84_3_cursor.child_mask().iter() {
        v84_3_cursor.descend_to_byte(v84_3_byte);
        {
        let v84_3_tail = v84_3_cursor.fork_read_zipper();
        let v84_3_head = Path::from_slice(&[v84_3_byte]);
        let v85_2: Path = concat_path(&(v84_2),&(v84_3_head));
        let mut v85_3 = Space::new();
        let mut v85_3_cursor = (v84_3_tail).read_zipper();
        for v85_3_byte in v85_3_cursor.child_mask().iter() {
          v85_3_cursor.descend_to_byte(v85_3_byte);
          {
          let v85_3_tail = v85_3_cursor.fork_read_zipper();
          let v85_3_head = Path::from_slice(&[v85_3_byte]);
          let v86_2: Path = concat_path(&(v85_2),&(v85_3_head));
          let v86_3: Space = routine_13(c, &(v86_2), &(v85_3_tail).make_space());
          drop(v86_2);
          v85_3.join_into((v86_3).clone());
          }
          v85_3_cursor.ascend(1);
        }
        drop(v85_3_cursor);
        drop(v85_2);
        v84_3.join_into((v85_3).clone());
        }
        v84_3_cursor.ascend(1);
      }
      drop(v84_3_cursor);
      drop(v84_2);
      v83_2.join_into((v84_3).clone());
      }
      v83_2_cursor.ascend(1);
    }
    drop(v83_2_cursor);
    v64_46.join_into((v83_2).clone());
    }
    v64_46_cursor.ascend(1);
  }
  drop(v64_46_cursor);
  drop(v64_45);
  let v64_48: Space = if (v64_46).is_empty() { Space::new() } else {
    let v87_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v87_22: Path = concat_path(&(v87_21),&(*capture_10));
    drop(v87_21);
    let v87_23: Path = concat_path(&(v87_22),&(*capture_11));
    drop(v87_22);
    let v87_24: Path = concat_path(&(v87_23),&(*capture_12));
    drop(v87_23);
    let v87_25: Path = concat_path(&(v87_24),&(*capture_13));
    drop(v87_24);
    let v87_26: Path = concat_path(&(v87_25),&(*capture_14));
    drop(v87_25);
    let v87_27: Path = concat_path(&(v87_26),&(*capture_15));
    drop(v87_26);
    let v87_28: Path = concat_path(&(v87_27),&(*capture_2));
    drop(v87_27);
    let v87_29: Path = concat_path(&(v87_28),&(*capture_3));
    drop(v87_28);
    let v87_30: Path = concat_path(&(v87_29),&(*capture_4));
    drop(v87_29);
    let v87_31: Path = concat_path(&(v87_30),&(*capture_5));
    drop(v87_30);
    let v87_32: Path = concat_path(&(v87_31),&(*capture_6));
    drop(v87_31);
    let v87_33: Path = concat_path(&(v87_32),&(*capture_7));
    drop(v87_32);
    let v87_34: Path = concat_path(&(v87_33),&(*capture_0));
    drop(v87_33);
    let v87_35: Space = singleton(&(v87_34));
    drop(v87_34);
    let mut v87_47 = Space::new();
    let mut v87_47_cursor = (v87_35).read_zipper();
    for v87_47_byte in v87_47_cursor.child_mask().iter() {
      v87_47_cursor.descend_to_byte(v87_47_byte);
      {
      let v87_47_tail = v87_47_cursor.fork_read_zipper();
      let v87_47_head = Path::from_slice(&[v87_47_byte]);
      let mut v88_2 = Space::new();
      let mut v88_2_cursor = (v87_47_tail).read_zipper();
      for v88_2_byte in v88_2_cursor.child_mask().iter() {
        v88_2_cursor.descend_to_byte(v88_2_byte);
        {
        let v88_2_tail = v88_2_cursor.fork_read_zipper();
        let v88_2_head = Path::from_slice(&[v88_2_byte]);
        let v89_2: Path = concat_path(&(v87_47_head),&(v88_2_head));
        let mut v89_3 = Space::new();
        let mut v89_3_cursor = (v88_2_tail).read_zipper();
        for v89_3_byte in v89_3_cursor.child_mask().iter() {
          v89_3_cursor.descend_to_byte(v89_3_byte);
          {
          let v89_3_tail = v89_3_cursor.fork_read_zipper();
          let v89_3_head = Path::from_slice(&[v89_3_byte]);
          let v90_2: Path = concat_path(&(v89_2),&(v89_3_head));
          let mut v90_3 = Space::new();
          let mut v90_3_cursor = (v89_3_tail).read_zipper();
          for v90_3_byte in v90_3_cursor.child_mask().iter() {
            v90_3_cursor.descend_to_byte(v90_3_byte);
            {
            let v90_3_tail = v90_3_cursor.fork_read_zipper();
            let v90_3_head = Path::from_slice(&[v90_3_byte]);
            let v91_2: Path = concat_path(&(v90_2),&(v90_3_head));
            let v91_3: Space = routine_14(c, &(v91_2), &(v90_3_tail).make_space());
            drop(v91_2);
            v90_3.join_into((v91_3).clone());
            }
            v90_3_cursor.ascend(1);
          }
          drop(v90_3_cursor);
          drop(v90_2);
          v89_3.join_into((v90_3).clone());
          }
          v89_3_cursor.ascend(1);
        }
        drop(v89_3_cursor);
        drop(v89_2);
        v88_2.join_into((v89_3).clone());
        }
        v88_2_cursor.ascend(1);
      }
      drop(v88_2_cursor);
      v87_47.join_into((v88_2).clone());
      }
      v87_47_cursor.ascend(1);
    }
    drop(v87_47_cursor);
    map_map_kernels::compose(&(v64_46),&(v87_47))
  };
  let v64_49: Space = map_map_kernels::unite(&(v64_43),&(v64_48));
  let v64_51: Space = map_map_kernels::intersect(&(*CONSTANT_53),&(v64_18));
  let mut v64_52 = Space::new();
  let mut v64_52_cursor = (v64_51).read_zipper();
  for v64_52_byte in v64_52_cursor.child_mask().iter() {
    v64_52_cursor.descend_to_byte(v64_52_byte);
    {
    let v64_52_tail = v64_52_cursor.fork_read_zipper();
    let v64_52_head = Path::from_slice(&[v64_52_byte]);
    let mut v92_2 = Space::new();
    let mut v92_2_cursor = (v64_52_tail).read_zipper();
    for v92_2_byte in v92_2_cursor.child_mask().iter() {
      v92_2_cursor.descend_to_byte(v92_2_byte);
      {
      let v92_2_tail = v92_2_cursor.fork_read_zipper();
      let v92_2_head = Path::from_slice(&[v92_2_byte]);
      let v93_2: Path = concat_path(&(v64_52_head),&(v92_2_head));
      let mut v93_3 = Space::new();
      let mut v93_3_cursor = (v92_2_tail).read_zipper();
      for v93_3_byte in v93_3_cursor.child_mask().iter() {
        v93_3_cursor.descend_to_byte(v93_3_byte);
        {
        let v93_3_tail = v93_3_cursor.fork_read_zipper();
        let v93_3_head = Path::from_slice(&[v93_3_byte]);
        let v94_2: Path = concat_path(&(v93_2),&(v93_3_head));
        let mut v94_3 = Space::new();
        let mut v94_3_cursor = (v93_3_tail).read_zipper();
        for v94_3_byte in v94_3_cursor.child_mask().iter() {
          v94_3_cursor.descend_to_byte(v94_3_byte);
          {
          let v94_3_tail = v94_3_cursor.fork_read_zipper();
          let v94_3_head = Path::from_slice(&[v94_3_byte]);
          let v95_2: Path = concat_path(&(v94_2),&(v94_3_head));
          let v95_3: Space = routine_15(c, &(v95_2), &(v94_3_tail).make_space());
          drop(v95_2);
          v94_3.join_into((v95_3).clone());
          }
          v94_3_cursor.ascend(1);
        }
        drop(v94_3_cursor);
        drop(v94_2);
        v93_3.join_into((v94_3).clone());
        }
        v93_3_cursor.ascend(1);
      }
      drop(v93_3_cursor);
      drop(v93_2);
      v92_2.join_into((v93_3).clone());
      }
      v92_2_cursor.ascend(1);
    }
    drop(v92_2_cursor);
    v64_52.join_into((v92_2).clone());
    }
    v64_52_cursor.ascend(1);
  }
  drop(v64_52_cursor);
  drop(v64_51);
  let v64_54: Space = if (v64_52).is_empty() { Space::new() } else {
    let v96_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v96_22: Path = concat_path(&(v96_21),&(*capture_10));
    drop(v96_21);
    let v96_23: Path = concat_path(&(v96_22),&(*capture_11));
    drop(v96_22);
    let v96_24: Path = concat_path(&(v96_23),&(*capture_12));
    drop(v96_23);
    let v96_25: Path = concat_path(&(v96_24),&(*capture_13));
    drop(v96_24);
    let v96_26: Path = concat_path(&(v96_25),&(*capture_14));
    drop(v96_25);
    let v96_27: Path = concat_path(&(v96_26),&(*capture_15));
    drop(v96_26);
    let v96_28: Path = concat_path(&(v96_27),&(*capture_2));
    drop(v96_27);
    let v96_29: Path = concat_path(&(v96_28),&(*capture_3));
    drop(v96_28);
    let v96_30: Path = concat_path(&(v96_29),&(*capture_4));
    drop(v96_29);
    let v96_31: Path = concat_path(&(v96_30),&(*capture_5));
    drop(v96_30);
    let v96_32: Path = concat_path(&(v96_31),&(*capture_6));
    drop(v96_31);
    let v96_33: Path = concat_path(&(v96_32),&(*capture_7));
    drop(v96_32);
    let v96_34: Path = concat_path(&(v96_33),&(*capture_0));
    drop(v96_33);
    let v96_35: Space = singleton(&(v96_34));
    drop(v96_34);
    let mut v96_53 = Space::new();
    let mut v96_53_cursor = (v96_35).read_zipper();
    for v96_53_byte in v96_53_cursor.child_mask().iter() {
      v96_53_cursor.descend_to_byte(v96_53_byte);
      {
      let v96_53_tail = v96_53_cursor.fork_read_zipper();
      let v96_53_head = Path::from_slice(&[v96_53_byte]);
      let mut v97_2 = Space::new();
      let mut v97_2_cursor = (v96_53_tail).read_zipper();
      for v97_2_byte in v97_2_cursor.child_mask().iter() {
        v97_2_cursor.descend_to_byte(v97_2_byte);
        {
        let v97_2_tail = v97_2_cursor.fork_read_zipper();
        let v97_2_head = Path::from_slice(&[v97_2_byte]);
        let v98_2: Path = concat_path(&(v96_53_head),&(v97_2_head));
        let mut v98_3 = Space::new();
        let mut v98_3_cursor = (v97_2_tail).read_zipper();
        for v98_3_byte in v98_3_cursor.child_mask().iter() {
          v98_3_cursor.descend_to_byte(v98_3_byte);
          {
          let v98_3_tail = v98_3_cursor.fork_read_zipper();
          let v98_3_head = Path::from_slice(&[v98_3_byte]);
          let v99_2: Path = concat_path(&(v98_2),&(v98_3_head));
          let mut v99_3 = Space::new();
          let mut v99_3_cursor = (v98_3_tail).read_zipper();
          for v99_3_byte in v99_3_cursor.child_mask().iter() {
            v99_3_cursor.descend_to_byte(v99_3_byte);
            {
            let v99_3_tail = v99_3_cursor.fork_read_zipper();
            let v99_3_head = Path::from_slice(&[v99_3_byte]);
            let v100_2: Path = concat_path(&(v99_2),&(v99_3_head));
            let v100_3: Space = routine_16(c, &(v100_2), &(v99_3_tail).make_space());
            drop(v100_2);
            v99_3.join_into((v100_3).clone());
            }
            v99_3_cursor.ascend(1);
          }
          drop(v99_3_cursor);
          drop(v99_2);
          v98_3.join_into((v99_3).clone());
          }
          v98_3_cursor.ascend(1);
        }
        drop(v98_3_cursor);
        drop(v98_2);
        v97_2.join_into((v98_3).clone());
        }
        v97_2_cursor.ascend(1);
      }
      drop(v97_2_cursor);
      v96_53.join_into((v97_2).clone());
      }
      v96_53_cursor.ascend(1);
    }
    drop(v96_53_cursor);
    map_map_kernels::compose(&(v64_52),&(v96_53))
  };
  let v64_55: Space = map_map_kernels::unite(&(v64_49),&(v64_54));
  let v64_57: Space = map_map_kernels::intersect(&(*CONSTANT_54),&(v64_18));
  let mut v64_58 = Space::new();
  let mut v64_58_cursor = (v64_57).read_zipper();
  for v64_58_byte in v64_58_cursor.child_mask().iter() {
    v64_58_cursor.descend_to_byte(v64_58_byte);
    {
    let v64_58_tail = v64_58_cursor.fork_read_zipper();
    let v64_58_head = Path::from_slice(&[v64_58_byte]);
    let mut v101_2 = Space::new();
    let mut v101_2_cursor = (v64_58_tail).read_zipper();
    for v101_2_byte in v101_2_cursor.child_mask().iter() {
      v101_2_cursor.descend_to_byte(v101_2_byte);
      {
      let v101_2_tail = v101_2_cursor.fork_read_zipper();
      let v101_2_head = Path::from_slice(&[v101_2_byte]);
      let v102_2: Path = concat_path(&(v64_58_head),&(v101_2_head));
      let mut v102_3 = Space::new();
      let mut v102_3_cursor = (v101_2_tail).read_zipper();
      for v102_3_byte in v102_3_cursor.child_mask().iter() {
        v102_3_cursor.descend_to_byte(v102_3_byte);
        {
        let v102_3_tail = v102_3_cursor.fork_read_zipper();
        let v102_3_head = Path::from_slice(&[v102_3_byte]);
        let v103_2: Path = concat_path(&(v102_2),&(v102_3_head));
        let mut v103_3 = Space::new();
        let mut v103_3_cursor = (v102_3_tail).read_zipper();
        for v103_3_byte in v103_3_cursor.child_mask().iter() {
          v103_3_cursor.descend_to_byte(v103_3_byte);
          {
          let v103_3_tail = v103_3_cursor.fork_read_zipper();
          let v103_3_head = Path::from_slice(&[v103_3_byte]);
          let v104_2: Path = concat_path(&(v103_2),&(v103_3_head));
          let v104_3: Space = routine_17(c, &(v104_2), &(v103_3_tail).make_space());
          drop(v104_2);
          v103_3.join_into((v104_3).clone());
          }
          v103_3_cursor.ascend(1);
        }
        drop(v103_3_cursor);
        drop(v103_2);
        v102_3.join_into((v103_3).clone());
        }
        v102_3_cursor.ascend(1);
      }
      drop(v102_3_cursor);
      drop(v102_2);
      v101_2.join_into((v102_3).clone());
      }
      v101_2_cursor.ascend(1);
    }
    drop(v101_2_cursor);
    v64_58.join_into((v101_2).clone());
    }
    v64_58_cursor.ascend(1);
  }
  drop(v64_58_cursor);
  drop(v64_57);
  let v64_60: Space = if (v64_58).is_empty() { Space::new() } else {
    let v105_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v105_22: Path = concat_path(&(v105_21),&(*capture_10));
    drop(v105_21);
    let v105_23: Path = concat_path(&(v105_22),&(*capture_11));
    drop(v105_22);
    let v105_24: Path = concat_path(&(v105_23),&(*capture_12));
    drop(v105_23);
    let v105_25: Path = concat_path(&(v105_24),&(*capture_13));
    drop(v105_24);
    let v105_26: Path = concat_path(&(v105_25),&(*capture_14));
    drop(v105_25);
    let v105_27: Path = concat_path(&(v105_26),&(*capture_15));
    drop(v105_26);
    let v105_28: Path = concat_path(&(v105_27),&(*capture_2));
    drop(v105_27);
    let v105_29: Path = concat_path(&(v105_28),&(*capture_3));
    drop(v105_28);
    let v105_30: Path = concat_path(&(v105_29),&(*capture_4));
    drop(v105_29);
    let v105_31: Path = concat_path(&(v105_30),&(*capture_5));
    drop(v105_30);
    let v105_32: Path = concat_path(&(v105_31),&(*capture_6));
    drop(v105_31);
    let v105_33: Path = concat_path(&(v105_32),&(*capture_7));
    drop(v105_32);
    let v105_34: Path = concat_path(&(v105_33),&(*capture_0));
    drop(v105_33);
    let v105_35: Space = singleton(&(v105_34));
    drop(v105_34);
    let mut v105_59 = Space::new();
    let mut v105_59_cursor = (v105_35).read_zipper();
    for v105_59_byte in v105_59_cursor.child_mask().iter() {
      v105_59_cursor.descend_to_byte(v105_59_byte);
      {
      let v105_59_tail = v105_59_cursor.fork_read_zipper();
      let v105_59_head = Path::from_slice(&[v105_59_byte]);
      let mut v106_2 = Space::new();
      let mut v106_2_cursor = (v105_59_tail).read_zipper();
      for v106_2_byte in v106_2_cursor.child_mask().iter() {
        v106_2_cursor.descend_to_byte(v106_2_byte);
        {
        let v106_2_tail = v106_2_cursor.fork_read_zipper();
        let v106_2_head = Path::from_slice(&[v106_2_byte]);
        let v107_2: Path = concat_path(&(v105_59_head),&(v106_2_head));
        let mut v107_3 = Space::new();
        let mut v107_3_cursor = (v106_2_tail).read_zipper();
        for v107_3_byte in v107_3_cursor.child_mask().iter() {
          v107_3_cursor.descend_to_byte(v107_3_byte);
          {
          let v107_3_tail = v107_3_cursor.fork_read_zipper();
          let v107_3_head = Path::from_slice(&[v107_3_byte]);
          let v108_2: Path = concat_path(&(v107_2),&(v107_3_head));
          let mut v108_3 = Space::new();
          let mut v108_3_cursor = (v107_3_tail).read_zipper();
          for v108_3_byte in v108_3_cursor.child_mask().iter() {
            v108_3_cursor.descend_to_byte(v108_3_byte);
            {
            let v108_3_tail = v108_3_cursor.fork_read_zipper();
            let v108_3_head = Path::from_slice(&[v108_3_byte]);
            let v109_2: Path = concat_path(&(v108_2),&(v108_3_head));
            let v109_3: Space = routine_18(c, &(v109_2), &(v108_3_tail).make_space());
            drop(v109_2);
            v108_3.join_into((v109_3).clone());
            }
            v108_3_cursor.ascend(1);
          }
          drop(v108_3_cursor);
          drop(v108_2);
          v107_3.join_into((v108_3).clone());
          }
          v107_3_cursor.ascend(1);
        }
        drop(v107_3_cursor);
        drop(v107_2);
        v106_2.join_into((v107_3).clone());
        }
        v106_2_cursor.ascend(1);
      }
      drop(v106_2_cursor);
      v105_59.join_into((v106_2).clone());
      }
      v105_59_cursor.ascend(1);
    }
    drop(v105_59_cursor);
    map_map_kernels::compose(&(v64_58),&(v105_59))
  };
  let v64_61: Space = map_map_kernels::unite(&(v64_55),&(v64_60));
  let v64_63: Space = map_map_kernels::intersect(&(*CONSTANT_55),&(v64_18));
  let mut v64_64 = Space::new();
  let mut v64_64_cursor = (v64_63).read_zipper();
  for v64_64_byte in v64_64_cursor.child_mask().iter() {
    v64_64_cursor.descend_to_byte(v64_64_byte);
    {
    let v64_64_tail = v64_64_cursor.fork_read_zipper();
    let v64_64_head = Path::from_slice(&[v64_64_byte]);
    let mut v110_2 = Space::new();
    let mut v110_2_cursor = (v64_64_tail).read_zipper();
    for v110_2_byte in v110_2_cursor.child_mask().iter() {
      v110_2_cursor.descend_to_byte(v110_2_byte);
      {
      let v110_2_tail = v110_2_cursor.fork_read_zipper();
      let v110_2_head = Path::from_slice(&[v110_2_byte]);
      let v111_2: Path = concat_path(&(v64_64_head),&(v110_2_head));
      let mut v111_3 = Space::new();
      let mut v111_3_cursor = (v110_2_tail).read_zipper();
      for v111_3_byte in v111_3_cursor.child_mask().iter() {
        v111_3_cursor.descend_to_byte(v111_3_byte);
        {
        let v111_3_tail = v111_3_cursor.fork_read_zipper();
        let v111_3_head = Path::from_slice(&[v111_3_byte]);
        let v112_2: Path = concat_path(&(v111_2),&(v111_3_head));
        let mut v112_3 = Space::new();
        let mut v112_3_cursor = (v111_3_tail).read_zipper();
        for v112_3_byte in v112_3_cursor.child_mask().iter() {
          v112_3_cursor.descend_to_byte(v112_3_byte);
          {
          let v112_3_tail = v112_3_cursor.fork_read_zipper();
          let v112_3_head = Path::from_slice(&[v112_3_byte]);
          let v113_2: Path = concat_path(&(v112_2),&(v112_3_head));
          let v113_3: Space = routine_19(c, &(v113_2), &(v112_3_tail).make_space());
          drop(v113_2);
          v112_3.join_into((v113_3).clone());
          }
          v112_3_cursor.ascend(1);
        }
        drop(v112_3_cursor);
        drop(v112_2);
        v111_3.join_into((v112_3).clone());
        }
        v111_3_cursor.ascend(1);
      }
      drop(v111_3_cursor);
      drop(v111_2);
      v110_2.join_into((v111_3).clone());
      }
      v110_2_cursor.ascend(1);
    }
    drop(v110_2_cursor);
    v64_64.join_into((v110_2).clone());
    }
    v64_64_cursor.ascend(1);
  }
  drop(v64_64_cursor);
  drop(v64_63);
  let v64_66: Space = if (v64_64).is_empty() { Space::new() } else {
    let v114_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v114_22: Path = concat_path(&(v114_21),&(*capture_10));
    drop(v114_21);
    let v114_23: Path = concat_path(&(v114_22),&(*capture_11));
    drop(v114_22);
    let v114_24: Path = concat_path(&(v114_23),&(*capture_12));
    drop(v114_23);
    let v114_25: Path = concat_path(&(v114_24),&(*capture_13));
    drop(v114_24);
    let v114_26: Path = concat_path(&(v114_25),&(*capture_14));
    drop(v114_25);
    let v114_27: Path = concat_path(&(v114_26),&(*capture_15));
    drop(v114_26);
    let v114_28: Path = concat_path(&(v114_27),&(*capture_2));
    drop(v114_27);
    let v114_29: Path = concat_path(&(v114_28),&(*capture_3));
    drop(v114_28);
    let v114_30: Path = concat_path(&(v114_29),&(*capture_4));
    drop(v114_29);
    let v114_31: Path = concat_path(&(v114_30),&(*capture_5));
    drop(v114_30);
    let v114_32: Path = concat_path(&(v114_31),&(*capture_6));
    drop(v114_31);
    let v114_33: Path = concat_path(&(v114_32),&(*capture_7));
    drop(v114_32);
    let v114_34: Path = concat_path(&(v114_33),&(*capture_0));
    drop(v114_33);
    let v114_35: Space = singleton(&(v114_34));
    drop(v114_34);
    let mut v114_65 = Space::new();
    let mut v114_65_cursor = (v114_35).read_zipper();
    for v114_65_byte in v114_65_cursor.child_mask().iter() {
      v114_65_cursor.descend_to_byte(v114_65_byte);
      {
      let v114_65_tail = v114_65_cursor.fork_read_zipper();
      let v114_65_head = Path::from_slice(&[v114_65_byte]);
      let mut v115_2 = Space::new();
      let mut v115_2_cursor = (v114_65_tail).read_zipper();
      for v115_2_byte in v115_2_cursor.child_mask().iter() {
        v115_2_cursor.descend_to_byte(v115_2_byte);
        {
        let v115_2_tail = v115_2_cursor.fork_read_zipper();
        let v115_2_head = Path::from_slice(&[v115_2_byte]);
        let v116_2: Path = concat_path(&(v114_65_head),&(v115_2_head));
        let mut v116_3 = Space::new();
        let mut v116_3_cursor = (v115_2_tail).read_zipper();
        for v116_3_byte in v116_3_cursor.child_mask().iter() {
          v116_3_cursor.descend_to_byte(v116_3_byte);
          {
          let v116_3_tail = v116_3_cursor.fork_read_zipper();
          let v116_3_head = Path::from_slice(&[v116_3_byte]);
          let v117_2: Path = concat_path(&(v116_2),&(v116_3_head));
          let mut v117_3 = Space::new();
          let mut v117_3_cursor = (v116_3_tail).read_zipper();
          for v117_3_byte in v117_3_cursor.child_mask().iter() {
            v117_3_cursor.descend_to_byte(v117_3_byte);
            {
            let v117_3_tail = v117_3_cursor.fork_read_zipper();
            let v117_3_head = Path::from_slice(&[v117_3_byte]);
            let v118_2: Path = concat_path(&(v117_2),&(v117_3_head));
            let v118_3: Space = routine_20(c, &(v118_2), &(v117_3_tail).make_space());
            drop(v118_2);
            v117_3.join_into((v118_3).clone());
            }
            v117_3_cursor.ascend(1);
          }
          drop(v117_3_cursor);
          drop(v117_2);
          v116_3.join_into((v117_3).clone());
          }
          v116_3_cursor.ascend(1);
        }
        drop(v116_3_cursor);
        drop(v116_2);
        v115_2.join_into((v116_3).clone());
        }
        v115_2_cursor.ascend(1);
      }
      drop(v115_2_cursor);
      v114_65.join_into((v115_2).clone());
      }
      v114_65_cursor.ascend(1);
    }
    drop(v114_65_cursor);
    map_map_kernels::compose(&(v64_64),&(v114_65))
  };

((v64_18).clone(),(v64_20).clone(),(v64_37).clone(),(v64_40).clone(),(v64_42).clone(),(v64_43).clone(),(v64_46).clone(),(v64_48).clone(),(v64_49).clone(),(v64_52).clone(),(v64_54).clone(),(v64_55).clone(),(v64_58).clone(),(v64_60).clone(),(v64_61).clone(),(v64_64).clone(),(v64_66).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &Path,capture_1: &Path,capture_2: &Path,capture_3: &Path,capture_4: &Path,capture_5: &Path,capture_6: &Path,capture_7: &Path,capture_8: &Path,capture_9: &Path,capture_10: &Path,capture_11: &Path,capture_12: &Path,capture_13: &Path,capture_14: &Path,capture_15: &Space,capture_16: &Space,capture_17: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v64_67: Space = map_map_kernels::unite(&((*capture_16)),&((*capture_17)));
  let v64_69: Space = map_map_kernels::intersect(&(*CONSTANT_56),&((*capture_15)));
  let mut v64_70 = Space::new();
  let mut v64_70_cursor = (v64_69).read_zipper();
  for v64_70_byte in v64_70_cursor.child_mask().iter() {
    v64_70_cursor.descend_to_byte(v64_70_byte);
    {
    let v64_70_tail = v64_70_cursor.fork_read_zipper();
    let v64_70_head = Path::from_slice(&[v64_70_byte]);
    let mut v119_2 = Space::new();
    let mut v119_2_cursor = (v64_70_tail).read_zipper();
    for v119_2_byte in v119_2_cursor.child_mask().iter() {
      v119_2_cursor.descend_to_byte(v119_2_byte);
      {
      let v119_2_tail = v119_2_cursor.fork_read_zipper();
      let v119_2_head = Path::from_slice(&[v119_2_byte]);
      let v120_2: Path = concat_path(&(v64_70_head),&(v119_2_head));
      let mut v120_3 = Space::new();
      let mut v120_3_cursor = (v119_2_tail).read_zipper();
      for v120_3_byte in v120_3_cursor.child_mask().iter() {
        v120_3_cursor.descend_to_byte(v120_3_byte);
        {
        let v120_3_tail = v120_3_cursor.fork_read_zipper();
        let v120_3_head = Path::from_slice(&[v120_3_byte]);
        let v121_2: Path = concat_path(&(v120_2),&(v120_3_head));
        let mut v121_3 = Space::new();
        let mut v121_3_cursor = (v120_3_tail).read_zipper();
        for v121_3_byte in v121_3_cursor.child_mask().iter() {
          v121_3_cursor.descend_to_byte(v121_3_byte);
          {
          let v121_3_tail = v121_3_cursor.fork_read_zipper();
          let v121_3_head = Path::from_slice(&[v121_3_byte]);
          let v122_2: Path = concat_path(&(v121_2),&(v121_3_head));
          let v122_3: Space = routine_21(c, &(v122_2), &(v121_3_tail).make_space());
          drop(v122_2);
          v121_3.join_into((v122_3).clone());
          }
          v121_3_cursor.ascend(1);
        }
        drop(v121_3_cursor);
        drop(v121_2);
        v120_3.join_into((v121_3).clone());
        }
        v120_3_cursor.ascend(1);
      }
      drop(v120_3_cursor);
      drop(v120_2);
      v119_2.join_into((v120_3).clone());
      }
      v119_2_cursor.ascend(1);
    }
    drop(v119_2_cursor);
    v64_70.join_into((v119_2).clone());
    }
    v64_70_cursor.ascend(1);
  }
  drop(v64_70_cursor);
  drop(v64_69);
  let v64_72: Space = if (v64_70).is_empty() { Space::new() } else {
    let v123_21: Path = concat_path(&(*capture_7),&(*capture_8));
    let v123_22: Path = concat_path(&(v123_21),&(*capture_9));
    drop(v123_21);
    let v123_23: Path = concat_path(&(v123_22),&(*capture_10));
    drop(v123_22);
    let v123_24: Path = concat_path(&(v123_23),&(*capture_11));
    drop(v123_23);
    let v123_25: Path = concat_path(&(v123_24),&(*capture_12));
    drop(v123_24);
    let v123_26: Path = concat_path(&(v123_25),&(*capture_13));
    drop(v123_25);
    let v123_27: Path = concat_path(&(v123_26),&(*capture_14));
    drop(v123_26);
    let v123_28: Path = concat_path(&(v123_27),&(*capture_1));
    drop(v123_27);
    let v123_29: Path = concat_path(&(v123_28),&(*capture_2));
    drop(v123_28);
    let v123_30: Path = concat_path(&(v123_29),&(*capture_3));
    drop(v123_29);
    let v123_31: Path = concat_path(&(v123_30),&(*capture_4));
    drop(v123_30);
    let v123_32: Path = concat_path(&(v123_31),&(*capture_5));
    drop(v123_31);
    let v123_33: Path = concat_path(&(v123_32),&(*capture_6));
    drop(v123_32);
    let v123_34: Path = concat_path(&(v123_33),&(*capture_0));
    drop(v123_33);
    let v123_35: Space = singleton(&(v123_34));
    drop(v123_34);
    let mut v123_71 = Space::new();
    let mut v123_71_cursor = (v123_35).read_zipper();
    for v123_71_byte in v123_71_cursor.child_mask().iter() {
      v123_71_cursor.descend_to_byte(v123_71_byte);
      {
      let v123_71_tail = v123_71_cursor.fork_read_zipper();
      let v123_71_head = Path::from_slice(&[v123_71_byte]);
      let mut v124_2 = Space::new();
      let mut v124_2_cursor = (v123_71_tail).read_zipper();
      for v124_2_byte in v124_2_cursor.child_mask().iter() {
        v124_2_cursor.descend_to_byte(v124_2_byte);
        {
        let v124_2_tail = v124_2_cursor.fork_read_zipper();
        let v124_2_head = Path::from_slice(&[v124_2_byte]);
        let v125_2: Path = concat_path(&(v123_71_head),&(v124_2_head));
        let mut v125_3 = Space::new();
        let mut v125_3_cursor = (v124_2_tail).read_zipper();
        for v125_3_byte in v125_3_cursor.child_mask().iter() {
          v125_3_cursor.descend_to_byte(v125_3_byte);
          {
          let v125_3_tail = v125_3_cursor.fork_read_zipper();
          let v125_3_head = Path::from_slice(&[v125_3_byte]);
          let v126_2: Path = concat_path(&(v125_2),&(v125_3_head));
          let mut v126_3 = Space::new();
          let mut v126_3_cursor = (v125_3_tail).read_zipper();
          for v126_3_byte in v126_3_cursor.child_mask().iter() {
            v126_3_cursor.descend_to_byte(v126_3_byte);
            {
            let v126_3_tail = v126_3_cursor.fork_read_zipper();
            let v126_3_head = Path::from_slice(&[v126_3_byte]);
            let v127_2: Path = concat_path(&(v126_2),&(v126_3_head));
            let v127_3: Space = routine_22(c, &(v127_2), &(v126_3_tail).make_space());
            drop(v127_2);
            v126_3.join_into((v127_3).clone());
            }
            v126_3_cursor.ascend(1);
          }
          drop(v126_3_cursor);
          drop(v126_2);
          v125_3.join_into((v126_3).clone());
          }
          v125_3_cursor.ascend(1);
        }
        drop(v125_3_cursor);
        drop(v125_2);
        v124_2.join_into((v125_3).clone());
        }
        v124_2_cursor.ascend(1);
      }
      drop(v124_2_cursor);
      v123_71.join_into((v124_2).clone());
      }
      v123_71_cursor.ascend(1);
    }
    drop(v123_71_cursor);
    map_map_kernels::compose(&(v64_70),&(v123_71))
  };
  let v64_73: Space = map_map_kernels::unite(&(v64_67),&(v64_72));
  let v64_75: Space = map_map_kernels::intersect(&(*CONSTANT_57),&((*capture_15)));
  let mut v64_76 = Space::new();
  let mut v64_76_cursor = (v64_75).read_zipper();
  for v64_76_byte in v64_76_cursor.child_mask().iter() {
    v64_76_cursor.descend_to_byte(v64_76_byte);
    {
    let v64_76_tail = v64_76_cursor.fork_read_zipper();
    let v64_76_head = Path::from_slice(&[v64_76_byte]);
    let mut v128_2 = Space::new();
    let mut v128_2_cursor = (v64_76_tail).read_zipper();
    for v128_2_byte in v128_2_cursor.child_mask().iter() {
      v128_2_cursor.descend_to_byte(v128_2_byte);
      {
      let v128_2_tail = v128_2_cursor.fork_read_zipper();
      let v128_2_head = Path::from_slice(&[v128_2_byte]);
      let v129_2: Path = concat_path(&(v64_76_head),&(v128_2_head));
      let mut v129_3 = Space::new();
      let mut v129_3_cursor = (v128_2_tail).read_zipper();
      for v129_3_byte in v129_3_cursor.child_mask().iter() {
        v129_3_cursor.descend_to_byte(v129_3_byte);
        {
        let v129_3_tail = v129_3_cursor.fork_read_zipper();
        let v129_3_head = Path::from_slice(&[v129_3_byte]);
        let v130_2: Path = concat_path(&(v129_2),&(v129_3_head));
        let mut v130_3 = Space::new();
        let mut v130_3_cursor = (v129_3_tail).read_zipper();
        for v130_3_byte in v130_3_cursor.child_mask().iter() {
          v130_3_cursor.descend_to_byte(v130_3_byte);
          {
          let v130_3_tail = v130_3_cursor.fork_read_zipper();
          let v130_3_head = Path::from_slice(&[v130_3_byte]);
          let v131_2: Path = concat_path(&(v130_2),&(v130_3_head));
          let v131_3: Space = routine_23(c, &(v131_2), &(v130_3_tail).make_space());
          drop(v131_2);
          v130_3.join_into((v131_3).clone());
          }
          v130_3_cursor.ascend(1);
        }
        drop(v130_3_cursor);
        drop(v130_2);
        v129_3.join_into((v130_3).clone());
        }
        v129_3_cursor.ascend(1);
      }
      drop(v129_3_cursor);
      drop(v129_2);
      v128_2.join_into((v129_3).clone());
      }
      v128_2_cursor.ascend(1);
    }
    drop(v128_2_cursor);
    v64_76.join_into((v128_2).clone());
    }
    v64_76_cursor.ascend(1);
  }
  drop(v64_76_cursor);
  drop(v64_75);
  let v64_78: Space = if (v64_76).is_empty() { Space::new() } else {
    let v132_21: Path = concat_path(&(*capture_7),&(*capture_8));
    let v132_22: Path = concat_path(&(v132_21),&(*capture_9));
    drop(v132_21);
    let v132_23: Path = concat_path(&(v132_22),&(*capture_10));
    drop(v132_22);
    let v132_24: Path = concat_path(&(v132_23),&(*capture_11));
    drop(v132_23);
    let v132_25: Path = concat_path(&(v132_24),&(*capture_12));
    drop(v132_24);
    let v132_26: Path = concat_path(&(v132_25),&(*capture_13));
    drop(v132_25);
    let v132_27: Path = concat_path(&(v132_26),&(*capture_14));
    drop(v132_26);
    let v132_28: Path = concat_path(&(v132_27),&(*capture_1));
    drop(v132_27);
    let v132_29: Path = concat_path(&(v132_28),&(*capture_2));
    drop(v132_28);
    let v132_30: Path = concat_path(&(v132_29),&(*capture_3));
    drop(v132_29);
    let v132_31: Path = concat_path(&(v132_30),&(*capture_4));
    drop(v132_30);
    let v132_32: Path = concat_path(&(v132_31),&(*capture_5));
    drop(v132_31);
    let v132_33: Path = concat_path(&(v132_32),&(*capture_6));
    drop(v132_32);
    let v132_34: Path = concat_path(&(v132_33),&(*capture_0));
    drop(v132_33);
    let v132_35: Space = singleton(&(v132_34));
    drop(v132_34);
    let mut v132_77 = Space::new();
    let mut v132_77_cursor = (v132_35).read_zipper();
    for v132_77_byte in v132_77_cursor.child_mask().iter() {
      v132_77_cursor.descend_to_byte(v132_77_byte);
      {
      let v132_77_tail = v132_77_cursor.fork_read_zipper();
      let v132_77_head = Path::from_slice(&[v132_77_byte]);
      let mut v133_2 = Space::new();
      let mut v133_2_cursor = (v132_77_tail).read_zipper();
      for v133_2_byte in v133_2_cursor.child_mask().iter() {
        v133_2_cursor.descend_to_byte(v133_2_byte);
        {
        let v133_2_tail = v133_2_cursor.fork_read_zipper();
        let v133_2_head = Path::from_slice(&[v133_2_byte]);
        let v134_2: Path = concat_path(&(v132_77_head),&(v133_2_head));
        let mut v134_3 = Space::new();
        let mut v134_3_cursor = (v133_2_tail).read_zipper();
        for v134_3_byte in v134_3_cursor.child_mask().iter() {
          v134_3_cursor.descend_to_byte(v134_3_byte);
          {
          let v134_3_tail = v134_3_cursor.fork_read_zipper();
          let v134_3_head = Path::from_slice(&[v134_3_byte]);
          let v135_2: Path = concat_path(&(v134_2),&(v134_3_head));
          let mut v135_3 = Space::new();
          let mut v135_3_cursor = (v134_3_tail).read_zipper();
          for v135_3_byte in v135_3_cursor.child_mask().iter() {
            v135_3_cursor.descend_to_byte(v135_3_byte);
            {
            let v135_3_tail = v135_3_cursor.fork_read_zipper();
            let v135_3_head = Path::from_slice(&[v135_3_byte]);
            let v136_2: Path = concat_path(&(v135_2),&(v135_3_head));
            let v136_3: Space = routine_24(c, &(v136_2), &(v135_3_tail).make_space());
            drop(v136_2);
            v135_3.join_into((v136_3).clone());
            }
            v135_3_cursor.ascend(1);
          }
          drop(v135_3_cursor);
          drop(v135_2);
          v134_3.join_into((v135_3).clone());
          }
          v134_3_cursor.ascend(1);
        }
        drop(v134_3_cursor);
        drop(v134_2);
        v133_2.join_into((v134_3).clone());
        }
        v133_2_cursor.ascend(1);
      }
      drop(v133_2_cursor);
      v132_77.join_into((v133_2).clone());
      }
      v132_77_cursor.ascend(1);
    }
    drop(v132_77_cursor);
    map_map_kernels::compose(&(v64_76),&(v132_77))
  };
  let v64_79: Space = map_map_kernels::unite(&(v64_73),&(v64_78));
  let v64_81: Space = map_map_kernels::intersect(&(*CONSTANT_58),&((*capture_15)));
  let mut v64_82 = Space::new();
  let mut v64_82_cursor = (v64_81).read_zipper();
  for v64_82_byte in v64_82_cursor.child_mask().iter() {
    v64_82_cursor.descend_to_byte(v64_82_byte);
    {
    let v64_82_tail = v64_82_cursor.fork_read_zipper();
    let v64_82_head = Path::from_slice(&[v64_82_byte]);
    let mut v137_2 = Space::new();
    let mut v137_2_cursor = (v64_82_tail).read_zipper();
    for v137_2_byte in v137_2_cursor.child_mask().iter() {
      v137_2_cursor.descend_to_byte(v137_2_byte);
      {
      let v137_2_tail = v137_2_cursor.fork_read_zipper();
      let v137_2_head = Path::from_slice(&[v137_2_byte]);
      let v138_2: Path = concat_path(&(v64_82_head),&(v137_2_head));
      let mut v138_3 = Space::new();
      let mut v138_3_cursor = (v137_2_tail).read_zipper();
      for v138_3_byte in v138_3_cursor.child_mask().iter() {
        v138_3_cursor.descend_to_byte(v138_3_byte);
        {
        let v138_3_tail = v138_3_cursor.fork_read_zipper();
        let v138_3_head = Path::from_slice(&[v138_3_byte]);
        let v139_2: Path = concat_path(&(v138_2),&(v138_3_head));
        let mut v139_3 = Space::new();
        let mut v139_3_cursor = (v138_3_tail).read_zipper();
        for v139_3_byte in v139_3_cursor.child_mask().iter() {
          v139_3_cursor.descend_to_byte(v139_3_byte);
          {
          let v139_3_tail = v139_3_cursor.fork_read_zipper();
          let v139_3_head = Path::from_slice(&[v139_3_byte]);
          let v140_2: Path = concat_path(&(v139_2),&(v139_3_head));
          let v140_3: Space = routine_25(c, &(v140_2), &(v139_3_tail).make_space());
          drop(v140_2);
          v139_3.join_into((v140_3).clone());
          }
          v139_3_cursor.ascend(1);
        }
        drop(v139_3_cursor);
        drop(v139_2);
        v138_3.join_into((v139_3).clone());
        }
        v138_3_cursor.ascend(1);
      }
      drop(v138_3_cursor);
      drop(v138_2);
      v137_2.join_into((v138_3).clone());
      }
      v137_2_cursor.ascend(1);
    }
    drop(v137_2_cursor);
    v64_82.join_into((v137_2).clone());
    }
    v64_82_cursor.ascend(1);
  }
  drop(v64_82_cursor);
  drop(v64_81);
  let v64_84: Space = if (v64_82).is_empty() { Space::new() } else {
    let v141_21: Path = concat_path(&(*capture_7),&(*capture_8));
    let v141_22: Path = concat_path(&(v141_21),&(*capture_9));
    drop(v141_21);
    let v141_23: Path = concat_path(&(v141_22),&(*capture_10));
    drop(v141_22);
    let v141_24: Path = concat_path(&(v141_23),&(*capture_11));
    drop(v141_23);
    let v141_25: Path = concat_path(&(v141_24),&(*capture_12));
    drop(v141_24);
    let v141_26: Path = concat_path(&(v141_25),&(*capture_13));
    drop(v141_25);
    let v141_27: Path = concat_path(&(v141_26),&(*capture_14));
    drop(v141_26);
    let v141_28: Path = concat_path(&(v141_27),&(*capture_1));
    drop(v141_27);
    let v141_29: Path = concat_path(&(v141_28),&(*capture_2));
    drop(v141_28);
    let v141_30: Path = concat_path(&(v141_29),&(*capture_3));
    drop(v141_29);
    let v141_31: Path = concat_path(&(v141_30),&(*capture_4));
    drop(v141_30);
    let v141_32: Path = concat_path(&(v141_31),&(*capture_5));
    drop(v141_31);
    let v141_33: Path = concat_path(&(v141_32),&(*capture_6));
    drop(v141_32);
    let v141_34: Path = concat_path(&(v141_33),&(*capture_0));
    drop(v141_33);
    let v141_35: Space = singleton(&(v141_34));
    drop(v141_34);
    let mut v141_83 = Space::new();
    let mut v141_83_cursor = (v141_35).read_zipper();
    for v141_83_byte in v141_83_cursor.child_mask().iter() {
      v141_83_cursor.descend_to_byte(v141_83_byte);
      {
      let v141_83_tail = v141_83_cursor.fork_read_zipper();
      let v141_83_head = Path::from_slice(&[v141_83_byte]);
      let mut v142_2 = Space::new();
      let mut v142_2_cursor = (v141_83_tail).read_zipper();
      for v142_2_byte in v142_2_cursor.child_mask().iter() {
        v142_2_cursor.descend_to_byte(v142_2_byte);
        {
        let v142_2_tail = v142_2_cursor.fork_read_zipper();
        let v142_2_head = Path::from_slice(&[v142_2_byte]);
        let v143_2: Path = concat_path(&(v141_83_head),&(v142_2_head));
        let mut v143_3 = Space::new();
        let mut v143_3_cursor = (v142_2_tail).read_zipper();
        for v143_3_byte in v143_3_cursor.child_mask().iter() {
          v143_3_cursor.descend_to_byte(v143_3_byte);
          {
          let v143_3_tail = v143_3_cursor.fork_read_zipper();
          let v143_3_head = Path::from_slice(&[v143_3_byte]);
          let v144_2: Path = concat_path(&(v143_2),&(v143_3_head));
          let mut v144_3 = Space::new();
          let mut v144_3_cursor = (v143_3_tail).read_zipper();
          for v144_3_byte in v144_3_cursor.child_mask().iter() {
            v144_3_cursor.descend_to_byte(v144_3_byte);
            {
            let v144_3_tail = v144_3_cursor.fork_read_zipper();
            let v144_3_head = Path::from_slice(&[v144_3_byte]);
            let v145_2: Path = concat_path(&(v144_2),&(v144_3_head));
            let v145_3: Space = routine_26(c, &(v145_2), &(v144_3_tail).make_space());
            drop(v145_2);
            v144_3.join_into((v145_3).clone());
            }
            v144_3_cursor.ascend(1);
          }
          drop(v144_3_cursor);
          drop(v144_2);
          v143_3.join_into((v144_3).clone());
          }
          v143_3_cursor.ascend(1);
        }
        drop(v143_3_cursor);
        drop(v143_2);
        v142_2.join_into((v143_3).clone());
        }
        v142_2_cursor.ascend(1);
      }
      drop(v142_2_cursor);
      v141_83.join_into((v142_2).clone());
      }
      v141_83_cursor.ascend(1);
    }
    drop(v141_83_cursor);
    map_map_kernels::compose(&(v64_82),&(v141_83))
  };
  let v64_85: Space = map_map_kernels::unite(&(v64_79),&(v64_84));
  let v64_87: Space = map_map_kernels::intersect(&(*CONSTANT_59),&((*capture_15)));
  let mut v64_88 = Space::new();
  let mut v64_88_cursor = (v64_87).read_zipper();
  for v64_88_byte in v64_88_cursor.child_mask().iter() {
    v64_88_cursor.descend_to_byte(v64_88_byte);
    {
    let v64_88_tail = v64_88_cursor.fork_read_zipper();
    let v64_88_head = Path::from_slice(&[v64_88_byte]);
    let mut v146_2 = Space::new();
    let mut v146_2_cursor = (v64_88_tail).read_zipper();
    for v146_2_byte in v146_2_cursor.child_mask().iter() {
      v146_2_cursor.descend_to_byte(v146_2_byte);
      {
      let v146_2_tail = v146_2_cursor.fork_read_zipper();
      let v146_2_head = Path::from_slice(&[v146_2_byte]);
      let v147_2: Path = concat_path(&(v64_88_head),&(v146_2_head));
      let mut v147_3 = Space::new();
      let mut v147_3_cursor = (v146_2_tail).read_zipper();
      for v147_3_byte in v147_3_cursor.child_mask().iter() {
        v147_3_cursor.descend_to_byte(v147_3_byte);
        {
        let v147_3_tail = v147_3_cursor.fork_read_zipper();
        let v147_3_head = Path::from_slice(&[v147_3_byte]);
        let v148_2: Path = concat_path(&(v147_2),&(v147_3_head));
        let mut v148_3 = Space::new();
        let mut v148_3_cursor = (v147_3_tail).read_zipper();
        for v148_3_byte in v148_3_cursor.child_mask().iter() {
          v148_3_cursor.descend_to_byte(v148_3_byte);
          {
          let v148_3_tail = v148_3_cursor.fork_read_zipper();
          let v148_3_head = Path::from_slice(&[v148_3_byte]);
          let v149_2: Path = concat_path(&(v148_2),&(v148_3_head));
          let v149_3: Space = routine_27(c, &(v149_2), &(v148_3_tail).make_space());
          drop(v149_2);
          v148_3.join_into((v149_3).clone());
          }
          v148_3_cursor.ascend(1);
        }
        drop(v148_3_cursor);
        drop(v148_2);
        v147_3.join_into((v148_3).clone());
        }
        v147_3_cursor.ascend(1);
      }
      drop(v147_3_cursor);
      drop(v147_2);
      v146_2.join_into((v147_3).clone());
      }
      v146_2_cursor.ascend(1);
    }
    drop(v146_2_cursor);
    v64_88.join_into((v146_2).clone());
    }
    v64_88_cursor.ascend(1);
  }
  drop(v64_88_cursor);
  drop(v64_87);
  let v64_90: Space = if (v64_88).is_empty() { Space::new() } else {
    let v150_21: Path = concat_path(&(*capture_7),&(*capture_8));
    let v150_22: Path = concat_path(&(v150_21),&(*capture_9));
    drop(v150_21);
    let v150_23: Path = concat_path(&(v150_22),&(*capture_10));
    drop(v150_22);
    let v150_24: Path = concat_path(&(v150_23),&(*capture_11));
    drop(v150_23);
    let v150_25: Path = concat_path(&(v150_24),&(*capture_12));
    drop(v150_24);
    let v150_26: Path = concat_path(&(v150_25),&(*capture_13));
    drop(v150_25);
    let v150_27: Path = concat_path(&(v150_26),&(*capture_14));
    drop(v150_26);
    let v150_28: Path = concat_path(&(v150_27),&(*capture_1));
    drop(v150_27);
    let v150_29: Path = concat_path(&(v150_28),&(*capture_2));
    drop(v150_28);
    let v150_30: Path = concat_path(&(v150_29),&(*capture_3));
    drop(v150_29);
    let v150_31: Path = concat_path(&(v150_30),&(*capture_4));
    drop(v150_30);
    let v150_32: Path = concat_path(&(v150_31),&(*capture_5));
    drop(v150_31);
    let v150_33: Path = concat_path(&(v150_32),&(*capture_6));
    drop(v150_32);
    let v150_34: Path = concat_path(&(v150_33),&(*capture_0));
    drop(v150_33);
    let v150_35: Space = singleton(&(v150_34));
    drop(v150_34);
    let mut v150_89 = Space::new();
    let mut v150_89_cursor = (v150_35).read_zipper();
    for v150_89_byte in v150_89_cursor.child_mask().iter() {
      v150_89_cursor.descend_to_byte(v150_89_byte);
      {
      let v150_89_tail = v150_89_cursor.fork_read_zipper();
      let v150_89_head = Path::from_slice(&[v150_89_byte]);
      let mut v151_2 = Space::new();
      let mut v151_2_cursor = (v150_89_tail).read_zipper();
      for v151_2_byte in v151_2_cursor.child_mask().iter() {
        v151_2_cursor.descend_to_byte(v151_2_byte);
        {
        let v151_2_tail = v151_2_cursor.fork_read_zipper();
        let v151_2_head = Path::from_slice(&[v151_2_byte]);
        let v152_2: Path = concat_path(&(v150_89_head),&(v151_2_head));
        let mut v152_3 = Space::new();
        let mut v152_3_cursor = (v151_2_tail).read_zipper();
        for v152_3_byte in v152_3_cursor.child_mask().iter() {
          v152_3_cursor.descend_to_byte(v152_3_byte);
          {
          let v152_3_tail = v152_3_cursor.fork_read_zipper();
          let v152_3_head = Path::from_slice(&[v152_3_byte]);
          let v153_2: Path = concat_path(&(v152_2),&(v152_3_head));
          let mut v153_3 = Space::new();
          let mut v153_3_cursor = (v152_3_tail).read_zipper();
          for v153_3_byte in v153_3_cursor.child_mask().iter() {
            v153_3_cursor.descend_to_byte(v153_3_byte);
            {
            let v153_3_tail = v153_3_cursor.fork_read_zipper();
            let v153_3_head = Path::from_slice(&[v153_3_byte]);
            let v154_2: Path = concat_path(&(v153_2),&(v153_3_head));
            let v154_3: Space = routine_28(c, &(v154_2), &(v153_3_tail).make_space());
            drop(v154_2);
            v153_3.join_into((v154_3).clone());
            }
            v153_3_cursor.ascend(1);
          }
          drop(v153_3_cursor);
          drop(v153_2);
          v152_3.join_into((v153_3).clone());
          }
          v152_3_cursor.ascend(1);
        }
        drop(v152_3_cursor);
        drop(v152_2);
        v151_2.join_into((v152_3).clone());
        }
        v151_2_cursor.ascend(1);
      }
      drop(v151_2_cursor);
      v150_89.join_into((v151_2).clone());
      }
      v150_89_cursor.ascend(1);
    }
    drop(v150_89_cursor);
    map_map_kernels::compose(&(v64_88),&(v150_89))
  };
  let v64_91: Space = map_map_kernels::unite(&(v64_85),&(v64_90));
  let v64_93: Space = map_map_kernels::intersect(&(*CONSTANT_60),&((*capture_15)));
  let mut v64_94 = Space::new();
  let mut v64_94_cursor = (v64_93).read_zipper();
  for v64_94_byte in v64_94_cursor.child_mask().iter() {
    v64_94_cursor.descend_to_byte(v64_94_byte);
    {
    let v64_94_tail = v64_94_cursor.fork_read_zipper();
    let v64_94_head = Path::from_slice(&[v64_94_byte]);
    let mut v155_2 = Space::new();
    let mut v155_2_cursor = (v64_94_tail).read_zipper();
    for v155_2_byte in v155_2_cursor.child_mask().iter() {
      v155_2_cursor.descend_to_byte(v155_2_byte);
      {
      let v155_2_tail = v155_2_cursor.fork_read_zipper();
      let v155_2_head = Path::from_slice(&[v155_2_byte]);
      let v156_2: Path = concat_path(&(v64_94_head),&(v155_2_head));
      let mut v156_3 = Space::new();
      let mut v156_3_cursor = (v155_2_tail).read_zipper();
      for v156_3_byte in v156_3_cursor.child_mask().iter() {
        v156_3_cursor.descend_to_byte(v156_3_byte);
        {
        let v156_3_tail = v156_3_cursor.fork_read_zipper();
        let v156_3_head = Path::from_slice(&[v156_3_byte]);
        let v157_2: Path = concat_path(&(v156_2),&(v156_3_head));
        let mut v157_3 = Space::new();
        let mut v157_3_cursor = (v156_3_tail).read_zipper();
        for v157_3_byte in v157_3_cursor.child_mask().iter() {
          v157_3_cursor.descend_to_byte(v157_3_byte);
          {
          let v157_3_tail = v157_3_cursor.fork_read_zipper();
          let v157_3_head = Path::from_slice(&[v157_3_byte]);
          let v158_2: Path = concat_path(&(v157_2),&(v157_3_head));
          let v158_3: Space = routine_29(c, &(v158_2), &(v157_3_tail).make_space());
          drop(v158_2);
          v157_3.join_into((v158_3).clone());
          }
          v157_3_cursor.ascend(1);
        }
        drop(v157_3_cursor);
        drop(v157_2);
        v156_3.join_into((v157_3).clone());
        }
        v156_3_cursor.ascend(1);
      }
      drop(v156_3_cursor);
      drop(v156_2);
      v155_2.join_into((v156_3).clone());
      }
      v155_2_cursor.ascend(1);
    }
    drop(v155_2_cursor);
    v64_94.join_into((v155_2).clone());
    }
    v64_94_cursor.ascend(1);
  }
  drop(v64_94_cursor);
  drop(v64_93);
  let v64_96: Space = if (v64_94).is_empty() { Space::new() } else {
    let v159_21: Path = concat_path(&(*capture_7),&(*capture_8));
    let v159_22: Path = concat_path(&(v159_21),&(*capture_9));
    drop(v159_21);
    let v159_23: Path = concat_path(&(v159_22),&(*capture_10));
    drop(v159_22);
    let v159_24: Path = concat_path(&(v159_23),&(*capture_11));
    drop(v159_23);
    let v159_25: Path = concat_path(&(v159_24),&(*capture_12));
    drop(v159_24);
    let v159_26: Path = concat_path(&(v159_25),&(*capture_13));
    drop(v159_25);
    let v159_27: Path = concat_path(&(v159_26),&(*capture_14));
    drop(v159_26);
    let v159_28: Path = concat_path(&(v159_27),&(*capture_1));
    drop(v159_27);
    let v159_29: Path = concat_path(&(v159_28),&(*capture_2));
    drop(v159_28);
    let v159_30: Path = concat_path(&(v159_29),&(*capture_3));
    drop(v159_29);
    let v159_31: Path = concat_path(&(v159_30),&(*capture_4));
    drop(v159_30);
    let v159_32: Path = concat_path(&(v159_31),&(*capture_5));
    drop(v159_31);
    let v159_33: Path = concat_path(&(v159_32),&(*capture_6));
    drop(v159_32);
    let v159_34: Path = concat_path(&(v159_33),&(*capture_0));
    drop(v159_33);
    let v159_35: Space = singleton(&(v159_34));
    drop(v159_34);
    let mut v159_95 = Space::new();
    let mut v159_95_cursor = (v159_35).read_zipper();
    for v159_95_byte in v159_95_cursor.child_mask().iter() {
      v159_95_cursor.descend_to_byte(v159_95_byte);
      {
      let v159_95_tail = v159_95_cursor.fork_read_zipper();
      let v159_95_head = Path::from_slice(&[v159_95_byte]);
      let mut v160_2 = Space::new();
      let mut v160_2_cursor = (v159_95_tail).read_zipper();
      for v160_2_byte in v160_2_cursor.child_mask().iter() {
        v160_2_cursor.descend_to_byte(v160_2_byte);
        {
        let v160_2_tail = v160_2_cursor.fork_read_zipper();
        let v160_2_head = Path::from_slice(&[v160_2_byte]);
        let v161_2: Path = concat_path(&(v159_95_head),&(v160_2_head));
        let mut v161_3 = Space::new();
        let mut v161_3_cursor = (v160_2_tail).read_zipper();
        for v161_3_byte in v161_3_cursor.child_mask().iter() {
          v161_3_cursor.descend_to_byte(v161_3_byte);
          {
          let v161_3_tail = v161_3_cursor.fork_read_zipper();
          let v161_3_head = Path::from_slice(&[v161_3_byte]);
          let v162_2: Path = concat_path(&(v161_2),&(v161_3_head));
          let mut v162_3 = Space::new();
          let mut v162_3_cursor = (v161_3_tail).read_zipper();
          for v162_3_byte in v162_3_cursor.child_mask().iter() {
            v162_3_cursor.descend_to_byte(v162_3_byte);
            {
            let v162_3_tail = v162_3_cursor.fork_read_zipper();
            let v162_3_head = Path::from_slice(&[v162_3_byte]);
            let v163_2: Path = concat_path(&(v162_2),&(v162_3_head));
            let v163_3: Space = routine_30(c, &(v163_2), &(v162_3_tail).make_space());
            drop(v163_2);
            v162_3.join_into((v163_3).clone());
            }
            v162_3_cursor.ascend(1);
          }
          drop(v162_3_cursor);
          drop(v162_2);
          v161_3.join_into((v162_3).clone());
          }
          v161_3_cursor.ascend(1);
        }
        drop(v161_3_cursor);
        drop(v161_2);
        v160_2.join_into((v161_3).clone());
        }
        v160_2_cursor.ascend(1);
      }
      drop(v160_2_cursor);
      v159_95.join_into((v160_2).clone());
      }
      v159_95_cursor.ascend(1);
    }
    drop(v159_95_cursor);
    map_map_kernels::compose(&(v64_94),&(v159_95))
  };
  let v64_97: Space = map_map_kernels::unite(&(v64_91),&(v64_96));
  let v64_99: Space = map_map_kernels::intersect(&(*CONSTANT_61),&((*capture_15)));
  let mut v64_100 = Space::new();
  let mut v64_100_cursor = (v64_99).read_zipper();
  for v64_100_byte in v64_100_cursor.child_mask().iter() {
    v64_100_cursor.descend_to_byte(v64_100_byte);
    {
    let v64_100_tail = v64_100_cursor.fork_read_zipper();
    let v64_100_head = Path::from_slice(&[v64_100_byte]);
    let mut v164_2 = Space::new();
    let mut v164_2_cursor = (v64_100_tail).read_zipper();
    for v164_2_byte in v164_2_cursor.child_mask().iter() {
      v164_2_cursor.descend_to_byte(v164_2_byte);
      {
      let v164_2_tail = v164_2_cursor.fork_read_zipper();
      let v164_2_head = Path::from_slice(&[v164_2_byte]);
      let v165_2: Path = concat_path(&(v64_100_head),&(v164_2_head));
      let mut v165_3 = Space::new();
      let mut v165_3_cursor = (v164_2_tail).read_zipper();
      for v165_3_byte in v165_3_cursor.child_mask().iter() {
        v165_3_cursor.descend_to_byte(v165_3_byte);
        {
        let v165_3_tail = v165_3_cursor.fork_read_zipper();
        let v165_3_head = Path::from_slice(&[v165_3_byte]);
        let v166_2: Path = concat_path(&(v165_2),&(v165_3_head));
        let mut v166_3 = Space::new();
        let mut v166_3_cursor = (v165_3_tail).read_zipper();
        for v166_3_byte in v166_3_cursor.child_mask().iter() {
          v166_3_cursor.descend_to_byte(v166_3_byte);
          {
          let v166_3_tail = v166_3_cursor.fork_read_zipper();
          let v166_3_head = Path::from_slice(&[v166_3_byte]);
          let v167_2: Path = concat_path(&(v166_2),&(v166_3_head));
          let v167_3: Space = routine_31(c, &(v167_2), &(v166_3_tail).make_space());
          drop(v167_2);
          v166_3.join_into((v167_3).clone());
          }
          v166_3_cursor.ascend(1);
        }
        drop(v166_3_cursor);
        drop(v166_2);
        v165_3.join_into((v166_3).clone());
        }
        v165_3_cursor.ascend(1);
      }
      drop(v165_3_cursor);
      drop(v165_2);
      v164_2.join_into((v165_3).clone());
      }
      v164_2_cursor.ascend(1);
    }
    drop(v164_2_cursor);
    v64_100.join_into((v164_2).clone());
    }
    v64_100_cursor.ascend(1);
  }
  drop(v64_100_cursor);
  drop(v64_99);
  let v64_102: Space = if (v64_100).is_empty() { Space::new() } else {
    let v168_21: Path = concat_path(&(*capture_7),&(*capture_8));
    let v168_22: Path = concat_path(&(v168_21),&(*capture_9));
    drop(v168_21);
    let v168_23: Path = concat_path(&(v168_22),&(*capture_10));
    drop(v168_22);
    let v168_24: Path = concat_path(&(v168_23),&(*capture_11));
    drop(v168_23);
    let v168_25: Path = concat_path(&(v168_24),&(*capture_12));
    drop(v168_24);
    let v168_26: Path = concat_path(&(v168_25),&(*capture_13));
    drop(v168_25);
    let v168_27: Path = concat_path(&(v168_26),&(*capture_14));
    drop(v168_26);
    let v168_28: Path = concat_path(&(v168_27),&(*capture_1));
    drop(v168_27);
    let v168_29: Path = concat_path(&(v168_28),&(*capture_2));
    drop(v168_28);
    let v168_30: Path = concat_path(&(v168_29),&(*capture_3));
    drop(v168_29);
    let v168_31: Path = concat_path(&(v168_30),&(*capture_4));
    drop(v168_30);
    let v168_32: Path = concat_path(&(v168_31),&(*capture_5));
    drop(v168_31);
    let v168_33: Path = concat_path(&(v168_32),&(*capture_6));
    drop(v168_32);
    let v168_34: Path = concat_path(&(v168_33),&(*capture_0));
    drop(v168_33);
    let v168_35: Space = singleton(&(v168_34));
    drop(v168_34);
    let mut v168_101 = Space::new();
    let mut v168_101_cursor = (v168_35).read_zipper();
    for v168_101_byte in v168_101_cursor.child_mask().iter() {
      v168_101_cursor.descend_to_byte(v168_101_byte);
      {
      let v168_101_tail = v168_101_cursor.fork_read_zipper();
      let v168_101_head = Path::from_slice(&[v168_101_byte]);
      let mut v169_2 = Space::new();
      let mut v169_2_cursor = (v168_101_tail).read_zipper();
      for v169_2_byte in v169_2_cursor.child_mask().iter() {
        v169_2_cursor.descend_to_byte(v169_2_byte);
        {
        let v169_2_tail = v169_2_cursor.fork_read_zipper();
        let v169_2_head = Path::from_slice(&[v169_2_byte]);
        let v170_2: Path = concat_path(&(v168_101_head),&(v169_2_head));
        let mut v170_3 = Space::new();
        let mut v170_3_cursor = (v169_2_tail).read_zipper();
        for v170_3_byte in v170_3_cursor.child_mask().iter() {
          v170_3_cursor.descend_to_byte(v170_3_byte);
          {
          let v170_3_tail = v170_3_cursor.fork_read_zipper();
          let v170_3_head = Path::from_slice(&[v170_3_byte]);
          let v171_2: Path = concat_path(&(v170_2),&(v170_3_head));
          let mut v171_3 = Space::new();
          let mut v171_3_cursor = (v170_3_tail).read_zipper();
          for v171_3_byte in v171_3_cursor.child_mask().iter() {
            v171_3_cursor.descend_to_byte(v171_3_byte);
            {
            let v171_3_tail = v171_3_cursor.fork_read_zipper();
            let v171_3_head = Path::from_slice(&[v171_3_byte]);
            let v172_2: Path = concat_path(&(v171_2),&(v171_3_head));
            let v172_3: Space = routine_32(c, &(v172_2), &(v171_3_tail).make_space());
            drop(v172_2);
            v171_3.join_into((v172_3).clone());
            }
            v171_3_cursor.ascend(1);
          }
          drop(v171_3_cursor);
          drop(v171_2);
          v170_3.join_into((v171_3).clone());
          }
          v170_3_cursor.ascend(1);
        }
        drop(v170_3_cursor);
        drop(v170_2);
        v169_2.join_into((v170_3).clone());
        }
        v169_2_cursor.ascend(1);
      }
      drop(v169_2_cursor);
      v168_101.join_into((v169_2).clone());
      }
      v168_101_cursor.ascend(1);
    }
    drop(v168_101_cursor);
    map_map_kernels::compose(&(v64_100),&(v168_101))
  };

((v64_100).clone(),(v64_102).clone(),(v64_67).clone(),(v64_70).clone(),(v64_72).clone(),(v64_73).clone(),(v64_76).clone(),(v64_78).clone(),(v64_79).clone(),(v64_82).clone(),(v64_84).clone(),(v64_85).clone(),(v64_88).clone(),(v64_90).clone(),(v64_91).clone(),(v64_94).clone(),(v64_96).clone(),(v64_97).clone(),)
}

#[inline(never)]
fn native_block_2(c: &mut Context,capture_0: &Path,capture_1: &Path,capture_2: &Path,capture_3: &Path,capture_4: &Path,capture_5: &Path,capture_6: &Path,capture_7: &Path,capture_8: &Path,capture_9: &Path,capture_10: &Path,capture_11: &Path,capture_12: &Path,capture_13: &Path,capture_14: &Path,capture_15: &Path,capture_16: &Space,capture_17: &Space,capture_18: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v64_103: Space = map_map_kernels::unite(&((*capture_18)),&((*capture_16)));
  let v64_105: Space = map_map_kernels::intersect(&(*CONSTANT_62),&((*capture_17)));
  let mut v64_106 = Space::new();
  let mut v64_106_cursor = (v64_105).read_zipper();
  for v64_106_byte in v64_106_cursor.child_mask().iter() {
    v64_106_cursor.descend_to_byte(v64_106_byte);
    {
    let v64_106_tail = v64_106_cursor.fork_read_zipper();
    let v64_106_head = Path::from_slice(&[v64_106_byte]);
    let mut v173_2 = Space::new();
    let mut v173_2_cursor = (v64_106_tail).read_zipper();
    for v173_2_byte in v173_2_cursor.child_mask().iter() {
      v173_2_cursor.descend_to_byte(v173_2_byte);
      {
      let v173_2_tail = v173_2_cursor.fork_read_zipper();
      let v173_2_head = Path::from_slice(&[v173_2_byte]);
      let v174_2: Path = concat_path(&(v64_106_head),&(v173_2_head));
      let mut v174_3 = Space::new();
      let mut v174_3_cursor = (v173_2_tail).read_zipper();
      for v174_3_byte in v174_3_cursor.child_mask().iter() {
        v174_3_cursor.descend_to_byte(v174_3_byte);
        {
        let v174_3_tail = v174_3_cursor.fork_read_zipper();
        let v174_3_head = Path::from_slice(&[v174_3_byte]);
        let v175_2: Path = concat_path(&(v174_2),&(v174_3_head));
        let mut v175_3 = Space::new();
        let mut v175_3_cursor = (v174_3_tail).read_zipper();
        for v175_3_byte in v175_3_cursor.child_mask().iter() {
          v175_3_cursor.descend_to_byte(v175_3_byte);
          {
          let v175_3_tail = v175_3_cursor.fork_read_zipper();
          let v175_3_head = Path::from_slice(&[v175_3_byte]);
          let v176_2: Path = concat_path(&(v175_2),&(v175_3_head));
          let v176_3: Space = routine_33(c, &(v176_2), &(v175_3_tail).make_space());
          drop(v176_2);
          v175_3.join_into((v176_3).clone());
          }
          v175_3_cursor.ascend(1);
        }
        drop(v175_3_cursor);
        drop(v175_2);
        v174_3.join_into((v175_3).clone());
        }
        v174_3_cursor.ascend(1);
      }
      drop(v174_3_cursor);
      drop(v174_2);
      v173_2.join_into((v174_3).clone());
      }
      v173_2_cursor.ascend(1);
    }
    drop(v173_2_cursor);
    v64_106.join_into((v173_2).clone());
    }
    v64_106_cursor.ascend(1);
  }
  drop(v64_106_cursor);
  drop(v64_105);
  let v64_108: Space = if (v64_106).is_empty() { Space::new() } else {
    let v177_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v177_22: Path = concat_path(&(v177_21),&(*capture_10));
    drop(v177_21);
    let v177_23: Path = concat_path(&(v177_22),&(*capture_11));
    drop(v177_22);
    let v177_24: Path = concat_path(&(v177_23),&(*capture_12));
    drop(v177_23);
    let v177_25: Path = concat_path(&(v177_24),&(*capture_13));
    drop(v177_24);
    let v177_26: Path = concat_path(&(v177_25),&(*capture_14));
    drop(v177_25);
    let v177_27: Path = concat_path(&(v177_26),&(*capture_15));
    drop(v177_26);
    let v177_28: Path = concat_path(&(v177_27),&(*capture_2));
    drop(v177_27);
    let v177_29: Path = concat_path(&(v177_28),&(*capture_3));
    drop(v177_28);
    let v177_30: Path = concat_path(&(v177_29),&(*capture_4));
    drop(v177_29);
    let v177_31: Path = concat_path(&(v177_30),&(*capture_5));
    drop(v177_30);
    let v177_32: Path = concat_path(&(v177_31),&(*capture_6));
    drop(v177_31);
    let v177_33: Path = concat_path(&(v177_32),&(*capture_7));
    drop(v177_32);
    let v177_34: Path = concat_path(&(v177_33),&(*capture_0));
    drop(v177_33);
    let v177_35: Space = singleton(&(v177_34));
    drop(v177_34);
    let mut v177_107 = Space::new();
    let mut v177_107_cursor = (v177_35).read_zipper();
    for v177_107_byte in v177_107_cursor.child_mask().iter() {
      v177_107_cursor.descend_to_byte(v177_107_byte);
      {
      let v177_107_tail = v177_107_cursor.fork_read_zipper();
      let v177_107_head = Path::from_slice(&[v177_107_byte]);
      let mut v178_2 = Space::new();
      let mut v178_2_cursor = (v177_107_tail).read_zipper();
      for v178_2_byte in v178_2_cursor.child_mask().iter() {
        v178_2_cursor.descend_to_byte(v178_2_byte);
        {
        let v178_2_tail = v178_2_cursor.fork_read_zipper();
        let v178_2_head = Path::from_slice(&[v178_2_byte]);
        let v179_2: Path = concat_path(&(v177_107_head),&(v178_2_head));
        let mut v179_3 = Space::new();
        let mut v179_3_cursor = (v178_2_tail).read_zipper();
        for v179_3_byte in v179_3_cursor.child_mask().iter() {
          v179_3_cursor.descend_to_byte(v179_3_byte);
          {
          let v179_3_tail = v179_3_cursor.fork_read_zipper();
          let v179_3_head = Path::from_slice(&[v179_3_byte]);
          let v180_2: Path = concat_path(&(v179_2),&(v179_3_head));
          let mut v180_3 = Space::new();
          let mut v180_3_cursor = (v179_3_tail).read_zipper();
          for v180_3_byte in v180_3_cursor.child_mask().iter() {
            v180_3_cursor.descend_to_byte(v180_3_byte);
            {
            let v180_3_tail = v180_3_cursor.fork_read_zipper();
            let v180_3_head = Path::from_slice(&[v180_3_byte]);
            let v181_2: Path = concat_path(&(v180_2),&(v180_3_head));
            let v181_3: Space = routine_34(c, &(v181_2), &(v180_3_tail).make_space());
            drop(v181_2);
            v180_3.join_into((v181_3).clone());
            }
            v180_3_cursor.ascend(1);
          }
          drop(v180_3_cursor);
          drop(v180_2);
          v179_3.join_into((v180_3).clone());
          }
          v179_3_cursor.ascend(1);
        }
        drop(v179_3_cursor);
        drop(v179_2);
        v178_2.join_into((v179_3).clone());
        }
        v178_2_cursor.ascend(1);
      }
      drop(v178_2_cursor);
      v177_107.join_into((v178_2).clone());
      }
      v177_107_cursor.ascend(1);
    }
    drop(v177_107_cursor);
    map_map_kernels::compose(&(v64_106),&(v177_107))
  };
  let v64_109: Space = map_map_kernels::unite(&(v64_103),&(v64_108));
  let v64_111: Space = map_map_kernels::intersect(&(*CONSTANT_63),&((*capture_17)));
  let mut v64_112 = Space::new();
  let mut v64_112_cursor = (v64_111).read_zipper();
  for v64_112_byte in v64_112_cursor.child_mask().iter() {
    v64_112_cursor.descend_to_byte(v64_112_byte);
    {
    let v64_112_tail = v64_112_cursor.fork_read_zipper();
    let v64_112_head = Path::from_slice(&[v64_112_byte]);
    let mut v182_2 = Space::new();
    let mut v182_2_cursor = (v64_112_tail).read_zipper();
    for v182_2_byte in v182_2_cursor.child_mask().iter() {
      v182_2_cursor.descend_to_byte(v182_2_byte);
      {
      let v182_2_tail = v182_2_cursor.fork_read_zipper();
      let v182_2_head = Path::from_slice(&[v182_2_byte]);
      let v183_2: Path = concat_path(&(v64_112_head),&(v182_2_head));
      let mut v183_3 = Space::new();
      let mut v183_3_cursor = (v182_2_tail).read_zipper();
      for v183_3_byte in v183_3_cursor.child_mask().iter() {
        v183_3_cursor.descend_to_byte(v183_3_byte);
        {
        let v183_3_tail = v183_3_cursor.fork_read_zipper();
        let v183_3_head = Path::from_slice(&[v183_3_byte]);
        let v184_2: Path = concat_path(&(v183_2),&(v183_3_head));
        let mut v184_3 = Space::new();
        let mut v184_3_cursor = (v183_3_tail).read_zipper();
        for v184_3_byte in v184_3_cursor.child_mask().iter() {
          v184_3_cursor.descend_to_byte(v184_3_byte);
          {
          let v184_3_tail = v184_3_cursor.fork_read_zipper();
          let v184_3_head = Path::from_slice(&[v184_3_byte]);
          let v185_2: Path = concat_path(&(v184_2),&(v184_3_head));
          let v185_3: Space = routine_35(c, &(v185_2), &(v184_3_tail).make_space());
          drop(v185_2);
          v184_3.join_into((v185_3).clone());
          }
          v184_3_cursor.ascend(1);
        }
        drop(v184_3_cursor);
        drop(v184_2);
        v183_3.join_into((v184_3).clone());
        }
        v183_3_cursor.ascend(1);
      }
      drop(v183_3_cursor);
      drop(v183_2);
      v182_2.join_into((v183_3).clone());
      }
      v182_2_cursor.ascend(1);
    }
    drop(v182_2_cursor);
    v64_112.join_into((v182_2).clone());
    }
    v64_112_cursor.ascend(1);
  }
  drop(v64_112_cursor);
  drop(v64_111);
  let v64_114: Space = if (v64_112).is_empty() { Space::new() } else {
    let v186_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v186_22: Path = concat_path(&(v186_21),&(*capture_10));
    drop(v186_21);
    let v186_23: Path = concat_path(&(v186_22),&(*capture_11));
    drop(v186_22);
    let v186_24: Path = concat_path(&(v186_23),&(*capture_12));
    drop(v186_23);
    let v186_25: Path = concat_path(&(v186_24),&(*capture_13));
    drop(v186_24);
    let v186_26: Path = concat_path(&(v186_25),&(*capture_14));
    drop(v186_25);
    let v186_27: Path = concat_path(&(v186_26),&(*capture_15));
    drop(v186_26);
    let v186_28: Path = concat_path(&(v186_27),&(*capture_2));
    drop(v186_27);
    let v186_29: Path = concat_path(&(v186_28),&(*capture_3));
    drop(v186_28);
    let v186_30: Path = concat_path(&(v186_29),&(*capture_4));
    drop(v186_29);
    let v186_31: Path = concat_path(&(v186_30),&(*capture_5));
    drop(v186_30);
    let v186_32: Path = concat_path(&(v186_31),&(*capture_6));
    drop(v186_31);
    let v186_33: Path = concat_path(&(v186_32),&(*capture_7));
    drop(v186_32);
    let v186_34: Path = concat_path(&(v186_33),&(*capture_0));
    drop(v186_33);
    let v186_35: Space = singleton(&(v186_34));
    drop(v186_34);
    let mut v186_113 = Space::new();
    let mut v186_113_cursor = (v186_35).read_zipper();
    for v186_113_byte in v186_113_cursor.child_mask().iter() {
      v186_113_cursor.descend_to_byte(v186_113_byte);
      {
      let v186_113_tail = v186_113_cursor.fork_read_zipper();
      let v186_113_head = Path::from_slice(&[v186_113_byte]);
      let mut v187_2 = Space::new();
      let mut v187_2_cursor = (v186_113_tail).read_zipper();
      for v187_2_byte in v187_2_cursor.child_mask().iter() {
        v187_2_cursor.descend_to_byte(v187_2_byte);
        {
        let v187_2_tail = v187_2_cursor.fork_read_zipper();
        let v187_2_head = Path::from_slice(&[v187_2_byte]);
        let v188_2: Path = concat_path(&(v186_113_head),&(v187_2_head));
        let mut v188_3 = Space::new();
        let mut v188_3_cursor = (v187_2_tail).read_zipper();
        for v188_3_byte in v188_3_cursor.child_mask().iter() {
          v188_3_cursor.descend_to_byte(v188_3_byte);
          {
          let v188_3_tail = v188_3_cursor.fork_read_zipper();
          let v188_3_head = Path::from_slice(&[v188_3_byte]);
          let v189_2: Path = concat_path(&(v188_2),&(v188_3_head));
          let mut v189_3 = Space::new();
          let mut v189_3_cursor = (v188_3_tail).read_zipper();
          for v189_3_byte in v189_3_cursor.child_mask().iter() {
            v189_3_cursor.descend_to_byte(v189_3_byte);
            {
            let v189_3_tail = v189_3_cursor.fork_read_zipper();
            let v189_3_head = Path::from_slice(&[v189_3_byte]);
            let v190_2: Path = concat_path(&(v189_2),&(v189_3_head));
            let v190_3: Space = routine_36(c, &(v190_2), &(v189_3_tail).make_space());
            drop(v190_2);
            v189_3.join_into((v190_3).clone());
            }
            v189_3_cursor.ascend(1);
          }
          drop(v189_3_cursor);
          drop(v189_2);
          v188_3.join_into((v189_3).clone());
          }
          v188_3_cursor.ascend(1);
        }
        drop(v188_3_cursor);
        drop(v188_2);
        v187_2.join_into((v188_3).clone());
        }
        v187_2_cursor.ascend(1);
      }
      drop(v187_2_cursor);
      v186_113.join_into((v187_2).clone());
      }
      v186_113_cursor.ascend(1);
    }
    drop(v186_113_cursor);
    map_map_kernels::compose(&(v64_112),&(v186_113))
  };
  let v64_115: Space = map_map_kernels::unite(&(v64_109),&(v64_114));
  let v64_117: Space = map_map_kernels::intersect(&(*CONSTANT_64),&((*capture_17)));
  let mut v64_118 = Space::new();
  let mut v64_118_cursor = (v64_117).read_zipper();
  for v64_118_byte in v64_118_cursor.child_mask().iter() {
    v64_118_cursor.descend_to_byte(v64_118_byte);
    {
    let v64_118_tail = v64_118_cursor.fork_read_zipper();
    let v64_118_head = Path::from_slice(&[v64_118_byte]);
    let mut v191_2 = Space::new();
    let mut v191_2_cursor = (v64_118_tail).read_zipper();
    for v191_2_byte in v191_2_cursor.child_mask().iter() {
      v191_2_cursor.descend_to_byte(v191_2_byte);
      {
      let v191_2_tail = v191_2_cursor.fork_read_zipper();
      let v191_2_head = Path::from_slice(&[v191_2_byte]);
      let v192_2: Path = concat_path(&(v64_118_head),&(v191_2_head));
      let mut v192_3 = Space::new();
      let mut v192_3_cursor = (v191_2_tail).read_zipper();
      for v192_3_byte in v192_3_cursor.child_mask().iter() {
        v192_3_cursor.descend_to_byte(v192_3_byte);
        {
        let v192_3_tail = v192_3_cursor.fork_read_zipper();
        let v192_3_head = Path::from_slice(&[v192_3_byte]);
        let v193_2: Path = concat_path(&(v192_2),&(v192_3_head));
        let mut v193_3 = Space::new();
        let mut v193_3_cursor = (v192_3_tail).read_zipper();
        for v193_3_byte in v193_3_cursor.child_mask().iter() {
          v193_3_cursor.descend_to_byte(v193_3_byte);
          {
          let v193_3_tail = v193_3_cursor.fork_read_zipper();
          let v193_3_head = Path::from_slice(&[v193_3_byte]);
          let v194_2: Path = concat_path(&(v193_2),&(v193_3_head));
          let v194_3: Space = routine_37(c, &(v194_2), &(v193_3_tail).make_space());
          drop(v194_2);
          v193_3.join_into((v194_3).clone());
          }
          v193_3_cursor.ascend(1);
        }
        drop(v193_3_cursor);
        drop(v193_2);
        v192_3.join_into((v193_3).clone());
        }
        v192_3_cursor.ascend(1);
      }
      drop(v192_3_cursor);
      drop(v192_2);
      v191_2.join_into((v192_3).clone());
      }
      v191_2_cursor.ascend(1);
    }
    drop(v191_2_cursor);
    v64_118.join_into((v191_2).clone());
    }
    v64_118_cursor.ascend(1);
  }
  drop(v64_118_cursor);
  drop(v64_117);
  let v64_120: Space = if (v64_118).is_empty() { Space::new() } else {
    let v195_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v195_22: Path = concat_path(&(v195_21),&(*capture_10));
    drop(v195_21);
    let v195_23: Path = concat_path(&(v195_22),&(*capture_11));
    drop(v195_22);
    let v195_24: Path = concat_path(&(v195_23),&(*capture_12));
    drop(v195_23);
    let v195_25: Path = concat_path(&(v195_24),&(*capture_13));
    drop(v195_24);
    let v195_26: Path = concat_path(&(v195_25),&(*capture_14));
    drop(v195_25);
    let v195_27: Path = concat_path(&(v195_26),&(*capture_15));
    drop(v195_26);
    let v195_28: Path = concat_path(&(v195_27),&(*capture_2));
    drop(v195_27);
    let v195_29: Path = concat_path(&(v195_28),&(*capture_3));
    drop(v195_28);
    let v195_30: Path = concat_path(&(v195_29),&(*capture_4));
    drop(v195_29);
    let v195_31: Path = concat_path(&(v195_30),&(*capture_5));
    drop(v195_30);
    let v195_32: Path = concat_path(&(v195_31),&(*capture_6));
    drop(v195_31);
    let v195_33: Path = concat_path(&(v195_32),&(*capture_7));
    drop(v195_32);
    let v195_34: Path = concat_path(&(v195_33),&(*capture_0));
    drop(v195_33);
    let v195_35: Space = singleton(&(v195_34));
    drop(v195_34);
    let mut v195_119 = Space::new();
    let mut v195_119_cursor = (v195_35).read_zipper();
    for v195_119_byte in v195_119_cursor.child_mask().iter() {
      v195_119_cursor.descend_to_byte(v195_119_byte);
      {
      let v195_119_tail = v195_119_cursor.fork_read_zipper();
      let v195_119_head = Path::from_slice(&[v195_119_byte]);
      let mut v196_2 = Space::new();
      let mut v196_2_cursor = (v195_119_tail).read_zipper();
      for v196_2_byte in v196_2_cursor.child_mask().iter() {
        v196_2_cursor.descend_to_byte(v196_2_byte);
        {
        let v196_2_tail = v196_2_cursor.fork_read_zipper();
        let v196_2_head = Path::from_slice(&[v196_2_byte]);
        let v197_2: Path = concat_path(&(v195_119_head),&(v196_2_head));
        let mut v197_3 = Space::new();
        let mut v197_3_cursor = (v196_2_tail).read_zipper();
        for v197_3_byte in v197_3_cursor.child_mask().iter() {
          v197_3_cursor.descend_to_byte(v197_3_byte);
          {
          let v197_3_tail = v197_3_cursor.fork_read_zipper();
          let v197_3_head = Path::from_slice(&[v197_3_byte]);
          let v198_2: Path = concat_path(&(v197_2),&(v197_3_head));
          let mut v198_3 = Space::new();
          let mut v198_3_cursor = (v197_3_tail).read_zipper();
          for v198_3_byte in v198_3_cursor.child_mask().iter() {
            v198_3_cursor.descend_to_byte(v198_3_byte);
            {
            let v198_3_tail = v198_3_cursor.fork_read_zipper();
            let v198_3_head = Path::from_slice(&[v198_3_byte]);
            let v199_2: Path = concat_path(&(v198_2),&(v198_3_head));
            let v199_3: Space = routine_38(c, &(v199_2), &(v198_3_tail).make_space());
            drop(v199_2);
            v198_3.join_into((v199_3).clone());
            }
            v198_3_cursor.ascend(1);
          }
          drop(v198_3_cursor);
          drop(v198_2);
          v197_3.join_into((v198_3).clone());
          }
          v197_3_cursor.ascend(1);
        }
        drop(v197_3_cursor);
        drop(v197_2);
        v196_2.join_into((v197_3).clone());
        }
        v196_2_cursor.ascend(1);
      }
      drop(v196_2_cursor);
      v195_119.join_into((v196_2).clone());
      }
      v195_119_cursor.ascend(1);
    }
    drop(v195_119_cursor);
    map_map_kernels::compose(&(v64_118),&(v195_119))
  };
  let v64_121: Space = map_map_kernels::unite(&(v64_115),&(v64_120));
  let v64_123: Space = map_map_kernels::intersect(&(*CONSTANT_65),&((*capture_17)));

  let mut v64_124 = Space::new();
  let mut v64_124_cursor = (v64_123).read_zipper();
  for v64_124_byte in v64_124_cursor.child_mask().iter() {
    v64_124_cursor.descend_to_byte(v64_124_byte);
    {
    let v64_124_tail = v64_124_cursor.fork_read_zipper();
    let v64_124_head = Path::from_slice(&[v64_124_byte]);
    let mut v200_2 = Space::new();
    let mut v200_2_cursor = (v64_124_tail).read_zipper();
    for v200_2_byte in v200_2_cursor.child_mask().iter() {
      v200_2_cursor.descend_to_byte(v200_2_byte);
      {
      let v200_2_tail = v200_2_cursor.fork_read_zipper();
      let v200_2_head = Path::from_slice(&[v200_2_byte]);
      let v201_2: Path = concat_path(&(v64_124_head),&(v200_2_head));
      let mut v201_3 = Space::new();
      let mut v201_3_cursor = (v200_2_tail).read_zipper();
      for v201_3_byte in v201_3_cursor.child_mask().iter() {
        v201_3_cursor.descend_to_byte(v201_3_byte);
        {
        let v201_3_tail = v201_3_cursor.fork_read_zipper();
        let v201_3_head = Path::from_slice(&[v201_3_byte]);
        let v202_2: Path = concat_path(&(v201_2),&(v201_3_head));
        let mut v202_3 = Space::new();
        let mut v202_3_cursor = (v201_3_tail).read_zipper();
        for v202_3_byte in v202_3_cursor.child_mask().iter() {
          v202_3_cursor.descend_to_byte(v202_3_byte);
          {
          let v202_3_tail = v202_3_cursor.fork_read_zipper();
          let v202_3_head = Path::from_slice(&[v202_3_byte]);
          let v203_2: Path = concat_path(&(v202_2),&(v202_3_head));
          let v203_3: Space = routine_39(c, &(v203_2), &(v202_3_tail).make_space());
          drop(v203_2);
          v202_3.join_into((v203_3).clone());
          }
          v202_3_cursor.ascend(1);
        }
        drop(v202_3_cursor);
        drop(v202_2);
        v201_3.join_into((v202_3).clone());
        }
        v201_3_cursor.ascend(1);
      }
      drop(v201_3_cursor);
      drop(v201_2);
      v200_2.join_into((v201_3).clone());
      }
      v200_2_cursor.ascend(1);
    }
    drop(v200_2_cursor);
    v64_124.join_into((v200_2).clone());
    }
    v64_124_cursor.ascend(1);
  }
  drop(v64_124_cursor);
  drop(v64_123);
  let v64_126: Space = if (v64_124).is_empty() { Space::new() } else {
    let v204_21: Path = concat_path(&(*capture_8),&(*capture_9));
    let v204_22: Path = concat_path(&(v204_21),&(*capture_10));
    drop(v204_21);
    let v204_23: Path = concat_path(&(v204_22),&(*capture_11));
    drop(v204_22);
    let v204_24: Path = concat_path(&(v204_23),&(*capture_12));
    drop(v204_23);
    let v204_25: Path = concat_path(&(v204_24),&(*capture_13));
    drop(v204_24);
    let v204_26: Path = concat_path(&(v204_25),&(*capture_14));
    drop(v204_25);
    let v204_27: Path = concat_path(&(v204_26),&(*capture_15));
    drop(v204_26);
    let v204_28: Path = concat_path(&(v204_27),&(*capture_2));
    drop(v204_27);
    let v204_29: Path = concat_path(&(v204_28),&(*capture_3));
    drop(v204_28);
    let v204_30: Path = concat_path(&(v204_29),&(*capture_4));
    drop(v204_29);
    let v204_31: Path = concat_path(&(v204_30),&(*capture_5));
    drop(v204_30);
    let v204_32: Path = concat_path(&(v204_31),&(*capture_6));
    drop(v204_31);
    let v204_33: Path = concat_path(&(v204_32),&(*capture_7));
    drop(v204_32);
    let v204_34: Path = concat_path(&(v204_33),&(*capture_0));
    drop(v204_33);
    let v204_35: Space = singleton(&(v204_34));
    drop(v204_34);
    let mut v204_125 = Space::new();
    let mut v204_125_cursor = (v204_35).read_zipper();
    for v204_125_byte in v204_125_cursor.child_mask().iter() {
      v204_125_cursor.descend_to_byte(v204_125_byte);
      {
      let v204_125_tail = v204_125_cursor.fork_read_zipper();
      let v204_125_head = Path::from_slice(&[v204_125_byte]);
      let mut v205_2 = Space::new();
      let mut v205_2_cursor = (v204_125_tail).read_zipper();
      for v205_2_byte in v205_2_cursor.child_mask().iter() {
        v205_2_cursor.descend_to_byte(v205_2_byte);
        {
        let v205_2_tail = v205_2_cursor.fork_read_zipper();
        let v205_2_head = Path::from_slice(&[v205_2_byte]);
        let v206_2: Path = concat_path(&(v204_125_head),&(v205_2_head));
        let mut v206_3 = Space::new();
        let mut v206_3_cursor = (v205_2_tail).read_zipper();
        for v206_3_byte in v206_3_cursor.child_mask().iter() {
          v206_3_cursor.descend_to_byte(v206_3_byte);
          {
          let v206_3_tail = v206_3_cursor.fork_read_zipper();
          let v206_3_head = Path::from_slice(&[v206_3_byte]);
          let v207_2: Path = concat_path(&(v206_2),&(v206_3_head));
          let mut v207_3 = Space::new();
          let mut v207_3_cursor = (v206_3_tail).read_zipper();
          for v207_3_byte in v207_3_cursor.child_mask().iter() {
            v207_3_cursor.descend_to_byte(v207_3_byte);
            {
            let v207_3_tail = v207_3_cursor.fork_read_zipper();
            let v207_3_head = Path::from_slice(&[v207_3_byte]);
            let v208_2: Path = concat_path(&(v207_2),&(v207_3_head));
            let v208_3: Space = routine_40(c, &(v208_2), &(v207_3_tail).make_space());
            drop(v208_2);
            v207_3.join_into((v208_3).clone());
            }
            v207_3_cursor.ascend(1);
          }
          drop(v207_3_cursor);
          drop(v207_2);
          v206_3.join_into((v207_3).clone());
          }
          v206_3_cursor.ascend(1);
        }
        drop(v206_3_cursor);
        drop(v206_2);
        v205_2.join_into((v206_3).clone());
        }
        v205_2_cursor.ascend(1);
      }
      drop(v205_2_cursor);
      v204_125.join_into((v205_2).clone());
      }
      v204_125_cursor.ascend(1);
    }
    drop(v204_125_cursor);
    drop(v204_35);
    map_map_kernels::compose(&(v64_124),&(v204_125))
  };
  let v64_127: Space = map_map_kernels::unite(&(v64_121),&(v64_126));
  let mut v64_160 = Space::new();
  let mut v64_160_cursor = (v64_127).read_zipper();
  for v64_160_byte in v64_160_cursor.child_mask().iter() {
    v64_160_cursor.descend_to_byte(v64_160_byte);
    {
    let v64_160_tail = v64_160_cursor.fork_read_zipper();
    let v64_160_head = Path::from_slice(&[v64_160_byte]);
    let mut v209_2 = Space::new();
    let mut v209_2_cursor = (v64_160_tail).read_zipper();
    for v209_2_byte in v209_2_cursor.child_mask().iter() {
      v209_2_cursor.descend_to_byte(v209_2_byte);
      {
      let v209_2_tail = v209_2_cursor.fork_read_zipper();
      let v209_2_head = Path::from_slice(&[v209_2_byte]);
      let v210_2: Path = concat_path(&(v64_160_head),&(v209_2_head));
      let mut v210_3 = Space::new();
      let mut v210_3_cursor = (v209_2_tail).read_zipper();
      for v210_3_byte in v210_3_cursor.child_mask().iter() {
        v210_3_cursor.descend_to_byte(v210_3_byte);
        {
        let v210_3_tail = v210_3_cursor.fork_read_zipper();
        let v210_3_head = Path::from_slice(&[v210_3_byte]);
        let v211_2: Path = concat_path(&(v210_2),&(v210_3_head));
        let mut v211_3 = Space::new();
        let mut v211_3_cursor = (v210_3_tail).read_zipper();
        for v211_3_byte in v211_3_cursor.child_mask().iter() {
          v211_3_cursor.descend_to_byte(v211_3_byte);
          {
          let v211_3_tail = v211_3_cursor.fork_read_zipper();
          let v211_3_head = Path::from_slice(&[v211_3_byte]);
          let v212_2: Space = routine_41(c, &(*CONSTANT_1), &(*CONSTANT_66));
          let v212_3: Space = routine_41(c, &(*CONSTANT_3), &(*CONSTANT_67));
          let v212_4: Space = map_map_kernels::unite(&(v212_2),&(v212_3));
          let v212_5: Space = routine_41(c, &(*CONSTANT_5), &(*CONSTANT_68));
          let v212_6: Space = map_map_kernels::unite(&(v212_4),&(v212_5));
          let v212_7: Space = routine_41(c, &(*CONSTANT_7), &(*CONSTANT_69));
          let v212_8: Space = map_map_kernels::unite(&(v212_6),&(v212_7));
          let v212_9: Space = routine_41(c, &(*CONSTANT_9), &(*CONSTANT_70));
          let v212_10: Space = map_map_kernels::unite(&(v212_8),&(v212_9));
          let v212_11: Space = routine_41(c, &(*CONSTANT_11), &(*CONSTANT_71));
          let v212_12: Space = map_map_kernels::unite(&(v212_10),&(v212_11));
          let v212_13: Space = routine_41(c, &(*CONSTANT_13), &(*CONSTANT_72));
          let v212_14: Space = map_map_kernels::unite(&(v212_12),&(v212_13));
          let v212_15: Space = routine_41(c, &(*CONSTANT_15), &(*CONSTANT_73));
          let v212_16: Space = map_map_kernels::unite(&(v212_14),&(v212_15));
          let v212_17: Space = routine_41(c, &(*CONSTANT_17), &(*CONSTANT_74));
          let v212_18: Space = map_map_kernels::unite(&(v212_16),&(v212_17));
          let v212_19: Space = routine_41(c, &(*CONSTANT_19), &(*CONSTANT_75));
          let v212_20: Space = map_map_kernels::unite(&(v212_18),&(v212_19));
          let v212_21: Space = routine_41(c, &(*CONSTANT_21), &(*CONSTANT_76));
          let v212_22: Space = map_map_kernels::unite(&(v212_20),&(v212_21));
          let v212_23: Space = routine_41(c, &(*CONSTANT_23), &(*CONSTANT_77));
          let v212_24: Space = map_map_kernels::unite(&(v212_22),&(v212_23));
          let v212_25: Space = routine_41(c, &(*CONSTANT_25), &(*CONSTANT_78));
          let v212_26: Space = map_map_kernels::unite(&(v212_24),&(v212_25));
          let v212_27: Space = routine_41(c, &(*CONSTANT_27), &(*CONSTANT_79));
          let v212_28: Space = map_map_kernels::unite(&(v212_26),&(v212_27));
          let v212_29: Space = routine_41(c, &(*CONSTANT_29), &(*CONSTANT_80));
          let v212_30: Space = map_map_kernels::unite(&(v212_28),&(v212_29));
          let v212_31: Space = routine_41(c, &(*CONSTANT_81), &(*CONSTANT_82));
          let v212_32: Space = map_map_kernels::unite(&(v212_30),&(v212_31));
          let v212_33: Space = map_kernels::unwrap(&(v212_32),&(*capture_1));
          let v212_34: Path = concat_path(&(v211_2),&(v211_3_head));
          let mut v212_35 = Space::new();
          let mut v212_35_cursor = (v212_33).read_zipper();
          for v212_35_byte in v212_35_cursor.child_mask().iter() {
            v212_35_cursor.descend_to_byte(v212_35_byte);
            {
            let v212_35_tail = v212_35_cursor.fork_read_zipper();
            let v212_35_head = Path::from_slice(&[v212_35_byte]);
            let mut v213_2 = Space::new();
            let mut v213_2_cursor = (v212_35_tail).read_zipper();
            for v213_2_byte in v213_2_cursor.child_mask().iter() {
              v213_2_cursor.descend_to_byte(v213_2_byte);
              {
              let v213_2_tail = v213_2_cursor.fork_read_zipper();
              let v213_2_head = Path::from_slice(&[v213_2_byte]);
              let v214_2: Path = concat_path(&(v212_35_head),&(v213_2_head));
              let mut v214_3 = Space::new();
              let mut v214_3_cursor = (v213_2_tail).read_zipper();
              for v214_3_byte in v214_3_cursor.child_mask().iter() {
                v214_3_cursor.descend_to_byte(v214_3_byte);
                {
                let v214_3_tail = v214_3_cursor.fork_read_zipper();
                let v214_3_head = Path::from_slice(&[v214_3_byte]);
                let v215_2: Path = concat_path(&(v214_2),&(v214_3_head));
                let mut v215_3 = Space::new();
                let mut v215_3_cursor = (v214_3_tail).read_zipper();
                for v215_3_byte in v215_3_cursor.child_mask().iter() {
                  v215_3_cursor.descend_to_byte(v215_3_byte);
                  {
                  let v215_3_tail = v215_3_cursor.fork_read_zipper();
                  let v215_3_head = Path::from_slice(&[v215_3_byte]);
                  let v216_2: Path = concat_path(&(v215_2),&(v215_3_head));
                  let v216_3: Space = routine_42(c, &(v216_2), &(v212_34), &(v215_3_tail).make_space(), &(v211_3_tail).make_space());
                  drop(v216_2);
                  v215_3.join_into((v216_3).clone());
                  }
                  v215_3_cursor.ascend(1);
                }
                drop(v215_3_cursor);
                drop(v215_2);
                v214_3.join_into((v215_3).clone());
                }
                v214_3_cursor.ascend(1);
              }
              drop(v214_3_cursor);
              drop(v214_2);
              v213_2.join_into((v214_3).clone());
              }
              v213_2_cursor.ascend(1);
            }
            drop(v213_2_cursor);
            v212_35.join_into((v213_2).clone());
            }
            v212_35_cursor.ascend(1);
          }
          drop(v212_35_cursor);
          drop(v212_34);
          v211_3.join_into((v212_35).clone());
          }
          v211_3_cursor.ascend(1);
        }
        drop(v211_3_cursor);
        drop(v211_2);
        v210_3.join_into((v211_3).clone());
        }
        v210_3_cursor.ascend(1);
      }
      drop(v210_3_cursor);
      drop(v210_2);
      v209_2.join_into((v210_3).clone());
      }
      v209_2_cursor.ascend(1);
    }
    drop(v209_2_cursor);
    v64_160.join_into((v209_2).clone());
    }
    v64_160_cursor.ascend(1);
  }
  drop(v64_160_cursor);
  let mut v64_177 = Space::new();
  let mut v64_177_cursor = (v64_160).read_zipper();
  for v64_177_byte in v64_177_cursor.child_mask().iter() {
    v64_177_cursor.descend_to_byte(v64_177_byte);
    {
    let v64_177_tail = v64_177_cursor.fork_read_zipper();
    let v64_177_head = Path::from_slice(&[v64_177_byte]);
    let mut v217_2 = Space::new();
    let mut v217_2_cursor = (v64_177_tail).read_zipper();
    for v217_2_byte in v217_2_cursor.child_mask().iter() {
      v217_2_cursor.descend_to_byte(v217_2_byte);
      {
      let v217_2_tail = v217_2_cursor.fork_read_zipper();
      let v217_2_head = Path::from_slice(&[v217_2_byte]);
      let mut v218_2 = Space::new();
      let mut v218_2_cursor = (v217_2_tail).read_zipper();
      for v218_2_byte in v218_2_cursor.child_mask().iter() {
        v218_2_cursor.descend_to_byte(v218_2_byte);
        {
        let v218_2_tail = v218_2_cursor.fork_read_zipper();
        let v218_2_head = Path::from_slice(&[v218_2_byte]);
        let mut v219_2 = Space::new();
        let mut v219_2_cursor = (v218_2_tail).read_zipper();
        for v219_2_byte in v219_2_cursor.child_mask().iter() {
          v219_2_cursor.descend_to_byte(v219_2_byte);
          {
          let v219_2_tail = v219_2_cursor.fork_read_zipper();
          let v219_2_head = Path::from_slice(&[v219_2_byte]);
          let v220_2: Space = routine_43(c, &(*CONSTANT_1), &(*CONSTANT_66));
          let v220_3: Space = routine_43(c, &(*CONSTANT_3), &(*CONSTANT_67));
          let v220_4: Space = map_map_kernels::unite(&(v220_2),&(v220_3));
          let v220_5: Space = routine_43(c, &(*CONSTANT_5), &(*CONSTANT_68));
          let v220_6: Space = map_map_kernels::unite(&(v220_4),&(v220_5));
          let v220_7: Space = routine_43(c, &(*CONSTANT_7), &(*CONSTANT_69));
          let v220_8: Space = map_map_kernels::unite(&(v220_6),&(v220_7));
          let v220_9: Space = routine_43(c, &(*CONSTANT_9), &(*CONSTANT_70));
          let v220_10: Space = map_map_kernels::unite(&(v220_8),&(v220_9));
          let v220_11: Space = routine_43(c, &(*CONSTANT_11), &(*CONSTANT_71));
          let v220_12: Space = map_map_kernels::unite(&(v220_10),&(v220_11));
          let v220_13: Space = routine_43(c, &(*CONSTANT_13), &(*CONSTANT_72));
          let v220_14: Space = map_map_kernels::unite(&(v220_12),&(v220_13));
          let v220_15: Space = routine_43(c, &(*CONSTANT_15), &(*CONSTANT_73));
          let v220_16: Space = map_map_kernels::unite(&(v220_14),&(v220_15));
          let v220_17: Space = routine_43(c, &(*CONSTANT_17), &(*CONSTANT_74));
          let v220_18: Space = map_map_kernels::unite(&(v220_16),&(v220_17));
          let v220_19: Space = routine_43(c, &(*CONSTANT_19), &(*CONSTANT_75));
          let v220_20: Space = map_map_kernels::unite(&(v220_18),&(v220_19));
          let v220_21: Space = routine_43(c, &(*CONSTANT_21), &(*CONSTANT_76));
          let v220_22: Space = map_map_kernels::unite(&(v220_20),&(v220_21));
          let v220_23: Space = routine_43(c, &(*CONSTANT_23), &(*CONSTANT_77));
          let v220_24: Space = map_map_kernels::unite(&(v220_22),&(v220_23));
          let v220_25: Space = routine_43(c, &(*CONSTANT_25), &(*CONSTANT_78));
          let v220_26: Space = map_map_kernels::unite(&(v220_24),&(v220_25));
          let v220_27: Space = routine_43(c, &(*CONSTANT_27), &(*CONSTANT_79));
          let v220_28: Space = map_map_kernels::unite(&(v220_26),&(v220_27));
          let v220_29: Space = routine_43(c, &(*CONSTANT_29), &(*CONSTANT_80));
          let v220_30: Space = map_map_kernels::unite(&(v220_28),&(v220_29));
          let v220_31: Space = routine_43(c, &(*CONSTANT_81), &(*CONSTANT_82));
          let v220_32: Space = map_map_kernels::unite(&(v220_30),&(v220_31));
          let v220_33: Space = map_kernels::unwrap(&(v220_32),&(*capture_1));
          let v220_34: Space = map_kernels::unwrap(&(v220_33),&(v64_177_head));
          let v220_35: Space = map_kernels::unwrap(&(v220_34),&(v217_2_head));
          let v220_36: Space = map_kernels::unwrap(&(v220_35),&(v218_2_head));
          let v220_37: Space = map_kernels::unwrap(&(v220_36),&(v219_2_head));
          let v220_38: Space = map_kernels::unwrap(&(v220_37),&(*capture_1));
          let mut v220_39 = Space::new();
          let mut v220_39_cursor = (v220_38).read_zipper();
          for v220_39_byte in v220_39_cursor.child_mask().iter() {
            v220_39_cursor.descend_to_byte(v220_39_byte);
            {
            let v220_39_tail = v220_39_cursor.fork_read_zipper();
            let v220_39_head = Path::from_slice(&[v220_39_byte]);
            let mut v221_2 = Space::new();
            let mut v221_2_cursor = (v220_39_tail).read_zipper();
            for v221_2_byte in v221_2_cursor.child_mask().iter() {
              v221_2_cursor.descend_to_byte(v221_2_byte);
              {
              let v221_2_tail = v221_2_cursor.fork_read_zipper();
              let v221_2_head = Path::from_slice(&[v221_2_byte]);
              let v222_2: Path = concat_path(&(v220_39_head),&(v221_2_head));
              let mut v222_3 = Space::new();
              let mut v222_3_cursor = (v221_2_tail).read_zipper();
              for v222_3_byte in v222_3_cursor.child_mask().iter() {
                v222_3_cursor.descend_to_byte(v222_3_byte);
                {
                let v222_3_tail = v222_3_cursor.fork_read_zipper();
                let v222_3_head = Path::from_slice(&[v222_3_byte]);
                let v223_2: Path = concat_path(&(v222_2),&(v222_3_head));
                let mut v223_3 = Space::new();
                let mut v223_3_cursor = (v222_3_tail).read_zipper();
                for v223_3_byte in v223_3_cursor.child_mask().iter() {
                  v223_3_cursor.descend_to_byte(v223_3_byte);
                  {
                  let v223_3_tail = v223_3_cursor.fork_read_zipper();
                  let v223_3_head = Path::from_slice(&[v223_3_byte]);
                  let v224_2: Path = concat_path(&(v223_2),&(v223_3_head));
                  let v224_3: Space = routine_44(c, &(v224_2), &(v223_3_tail).make_space(), &(v219_2_tail).make_space());
                  drop(v224_2);
                  v223_3.join_into((v224_3).clone());
                  }
                  v223_3_cursor.ascend(1);
                }
                drop(v223_3_cursor);
                drop(v223_2);
                v222_3.join_into((v223_3).clone());
                }
                v222_3_cursor.ascend(1);
              }
              drop(v222_3_cursor);
              drop(v222_2);
              v221_2.join_into((v222_3).clone());
              }
              v221_2_cursor.ascend(1);
            }
            drop(v221_2_cursor);
            v220_39.join_into((v221_2).clone());
            }
            v220_39_cursor.ascend(1);
          }
          drop(v220_39_cursor);
          v219_2.join_into((v220_39).clone());
          }
          v219_2_cursor.ascend(1);
        }
        drop(v219_2_cursor);
        v218_2.join_into((v219_2).clone());
        }
        v218_2_cursor.ascend(1);
      }
      drop(v218_2_cursor);
      v217_2.join_into((v218_2).clone());
      }
      v217_2_cursor.ascend(1);
    }
    drop(v217_2_cursor);
    v64_177.join_into((v217_2).clone());
    }
    v64_177_cursor.ascend(1);
  }
  drop(v64_177_cursor);

((v64_103).clone(),(v64_106).clone(),(v64_108).clone(),(v64_109).clone(),(v64_112).clone(),(v64_114).clone(),(v64_115).clone(),(v64_118).clone(),(v64_120).clone(),(v64_121).clone(),(v64_124).clone(),(v64_126).clone(),(v64_127).clone(),(v64_160).clone(),(v64_177).clone(),)
}

#[inline(never)]
fn native_block_3(c: &mut Context,capture_0: &Path,capture_1: &Space) -> (Space,Space,Space,) {
  let v405_4: Space = singleton(&(*capture_0));
  let v405_5: Space = map_map_kernels::intersect(&(*CONSTANT_50),&(v405_4));
  let v405_50: Space = if (v405_5).is_empty() { Space::new() } else {
    let v406_7: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_3));
    let v406_10: Space = if (v406_7).is_empty() { Space::new() } else {
      let v407_9: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v406_7),&(v407_9))
    };
    let v406_13: Space = if (v406_10).is_empty() { Space::new() } else {
      let v408_12: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v406_10),&(v408_12))
    };
    drop(v406_10);
    let v406_16: Space = if (v406_13).is_empty() { Space::new() } else {
      let v409_15: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v406_13),&(v409_15))
    };
    drop(v406_13);
    let v406_19: Space = if (v406_16).is_empty() { Space::new() } else {
      let v410_18: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v406_16),&(v410_18))
    };
    drop(v406_16);
    let v406_22: Space = if (v406_19).is_empty() { Space::new() } else {
      let v411_21: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v406_19),&(v411_21))
    };
    drop(v406_19);
    let v406_25: Space = if (v406_22).is_empty() { Space::new() } else {
      let v412_24: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v406_22),&(v412_24))
    };
    drop(v406_22);
    let v406_28: Space = if (v406_25).is_empty() { Space::new() } else {
      let v413_27: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v406_25),&(v413_27))
    };
    drop(v406_25);
    let v406_31: Space = if (v406_28).is_empty() { Space::new() } else {
      let v414_30: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v406_28),&(v414_30))
    };
    drop(v406_28);
    let v406_34: Space = if (v406_31).is_empty() { Space::new() } else {
      let v415_33: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v406_31),&(v415_33))
    };
    drop(v406_31);
    let v406_37: Space = if (v406_34).is_empty() { Space::new() } else {
      let v416_36: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v406_34),&(v416_36))
    };
    drop(v406_34);
    let v406_40: Space = if (v406_37).is_empty() { Space::new() } else {
      let v417_39: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v406_37),&(v417_39))
    };
    drop(v406_37);
    let v406_43: Space = if (v406_40).is_empty() { Space::new() } else {
      let v418_42: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v406_40),&(v418_42))
    };
    drop(v406_40);
    let v406_46: Space = if (v406_43).is_empty() { Space::new() } else {
      let v419_45: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v406_43),&(v419_45))
    };
    drop(v406_43);
    let v406_49: Space = if (v406_46).is_empty() { Space::new() } else {
      let v420_48: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v406_46),&(v420_48))
    };
    drop(v406_46);
    map_map_kernels::compose(&(v405_5),&(v406_49))
  };
  drop(v405_5);
  let v405_52: Space = map_map_kernels::intersect(&(*CONSTANT_51),&(v405_4));
  let v405_69: Space = if (v405_52).is_empty() { Space::new() } else {
    let v421_54: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_1));
    let v421_55: Space = if (v421_54).is_empty() { Space::new() } else {
      let v422_9: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v421_54),&(v422_9))
    };
    let v421_56: Space = if (v421_55).is_empty() { Space::new() } else {
      let v423_12: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v421_55),&(v423_12))
    };
    drop(v421_55);
    let v421_57: Space = if (v421_56).is_empty() { Space::new() } else {
      let v424_15: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v421_56),&(v424_15))
    };
    drop(v421_56);
    let v421_58: Space = if (v421_57).is_empty() { Space::new() } else {
      let v425_18: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v421_57),&(v425_18))
    };
    drop(v421_57);
    let v421_59: Space = if (v421_58).is_empty() { Space::new() } else {
      let v426_21: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v421_58),&(v426_21))
    };
    drop(v421_58);
    let v421_60: Space = if (v421_59).is_empty() { Space::new() } else {
      let v427_24: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v421_59),&(v427_24))
    };
    drop(v421_59);
    let v421_61: Space = if (v421_60).is_empty() { Space::new() } else {
      let v428_27: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v421_60),&(v428_27))
    };
    drop(v421_60);
    let v421_62: Space = if (v421_61).is_empty() { Space::new() } else {
      let v429_30: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v421_61),&(v429_30))
    };
    drop(v421_61);
    let v421_63: Space = if (v421_62).is_empty() { Space::new() } else {
      let v430_33: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v421_62),&(v430_33))
    };
    drop(v421_62);
    let v421_64: Space = if (v421_63).is_empty() { Space::new() } else {
      let v431_36: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v421_63),&(v431_36))
    };
    drop(v421_63);
    let v421_65: Space = if (v421_64).is_empty() { Space::new() } else {
      let v432_39: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v421_64),&(v432_39))
    };
    drop(v421_64);
    let v421_66: Space = if (v421_65).is_empty() { Space::new() } else {
      let v433_42: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v421_65),&(v433_42))
    };
    drop(v421_65);
    let v421_67: Space = if (v421_66).is_empty() { Space::new() } else {
      let v434_45: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v421_66),&(v434_45))
    };
    drop(v421_66);
    let v421_68: Space = if (v421_67).is_empty() { Space::new() } else {
      let v435_48: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v421_67),&(v435_48))
    };
    drop(v421_67);
    map_map_kernels::compose(&(v405_52),&(v421_68))
  };
  drop(v405_52);
  let v405_70: Space = map_map_kernels::unite(&(v405_50),&(v405_69));
  drop(v405_50);
  drop(v405_69);
  let v405_72: Space = map_map_kernels::intersect(&(*CONSTANT_52),&(v405_4));
  let v405_87: Space = if (v405_72).is_empty() { Space::new() } else {
    let v436_54: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_1));
    let v436_73: Space = if (v436_54).is_empty() { Space::new() } else {
      let v437_7: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v436_54),&(v437_7))
    };
    drop(v436_54);
    let v436_74: Space = if (v436_73).is_empty() { Space::new() } else {
      let v438_12: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v436_73),&(v438_12))
    };
    let v436_75: Space = if (v436_74).is_empty() { Space::new() } else {
      let v439_15: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v436_74),&(v439_15))
    };
    drop(v436_74);
    let v436_76: Space = if (v436_75).is_empty() { Space::new() } else {
      let v440_18: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v436_75),&(v440_18))
    };
    drop(v436_75);
    let v436_77: Space = if (v436_76).is_empty() { Space::new() } else {
      let v441_21: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v436_76),&(v441_21))
    };
    drop(v436_76);
    let v436_78: Space = if (v436_77).is_empty() { Space::new() } else {
      let v442_24: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v436_77),&(v442_24))
    };
    drop(v436_77);
    let v436_79: Space = if (v436_78).is_empty() { Space::new() } else {
      let v443_27: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v436_78),&(v443_27))
    };
    drop(v436_78);
    let v436_80: Space = if (v436_79).is_empty() { Space::new() } else {
      let v444_30: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v436_79),&(v444_30))
    };
    drop(v436_79);
    let v436_81: Space = if (v436_80).is_empty() { Space::new() } else {
      let v445_33: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v436_80),&(v445_33))
    };
    drop(v436_80);
    let v436_82: Space = if (v436_81).is_empty() { Space::new() } else {
      let v446_36: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v436_81),&(v446_36))
    };
    drop(v436_81);
    let v436_83: Space = if (v436_82).is_empty() { Space::new() } else {
      let v447_39: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v436_82),&(v447_39))
    };
    drop(v436_82);
    let v436_84: Space = if (v436_83).is_empty() { Space::new() } else {
      let v448_42: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v436_83),&(v448_42))
    };
    drop(v436_83);
    let v436_85: Space = if (v436_84).is_empty() { Space::new() } else {
      let v449_45: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v436_84),&(v449_45))
    };
    drop(v436_84);
    let v436_86: Space = if (v436_85).is_empty() { Space::new() } else {
      let v450_48: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v436_85),&(v450_48))
    };
    drop(v436_85);
    map_map_kernels::compose(&(v405_72),&(v436_86))
  };
  drop(v405_72);
  let v405_88: Space = map_map_kernels::unite(&(v405_70),&(v405_87));
  drop(v405_70);
  drop(v405_87);
  let v405_90: Space = map_map_kernels::intersect(&(*CONSTANT_53),&(v405_4));
  let v405_104: Space = if (v405_90).is_empty() { Space::new() } else {
    let v451_54: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_1));
    let v451_73: Space = if (v451_54).is_empty() { Space::new() } else {
      let v452_7: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v451_54),&(v452_7))
    };
    drop(v451_54);
    let v451_91: Space = if (v451_73).is_empty() { Space::new() } else {
      let v453_9: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v451_73),&(v453_9))
    };
    drop(v451_73);
    let v451_92: Space = if (v451_91).is_empty() { Space::new() } else {
      let v454_15: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v451_91),&(v454_15))
    };
    let v451_93: Space = if (v451_92).is_empty() { Space::new() } else {
      let v455_18: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v451_92),&(v455_18))
    };
    drop(v451_92);
    let v451_94: Space = if (v451_93).is_empty() { Space::new() } else {
      let v456_21: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v451_93),&(v456_21))
    };
    drop(v451_93);
    let v451_95: Space = if (v451_94).is_empty() { Space::new() } else {
      let v457_24: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v451_94),&(v457_24))
    };
    drop(v451_94);
    let v451_96: Space = if (v451_95).is_empty() { Space::new() } else {
      let v458_27: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v451_95),&(v458_27))
    };
    drop(v451_95);
    let v451_97: Space = if (v451_96).is_empty() { Space::new() } else {
      let v459_30: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v451_96),&(v459_30))
    };
    drop(v451_96);
    let v451_98: Space = if (v451_97).is_empty() { Space::new() } else {
      let v460_33: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v451_97),&(v460_33))
    };
    drop(v451_97);
    let v451_99: Space = if (v451_98).is_empty() { Space::new() } else {
      let v461_36: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v451_98),&(v461_36))
    };
    drop(v451_98);
    let v451_100: Space = if (v451_99).is_empty() { Space::new() } else {
      let v462_39: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v451_99),&(v462_39))
    };
    drop(v451_99);
    let v451_101: Space = if (v451_100).is_empty() { Space::new() } else {
      let v463_42: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v451_100),&(v463_42))
    };
    drop(v451_100);
    let v451_102: Space = if (v451_101).is_empty() { Space::new() } else {
      let v464_45: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v451_101),&(v464_45))
    };
    drop(v451_101);
    let v451_103: Space = if (v451_102).is_empty() { Space::new() } else {
      let v465_48: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v451_102),&(v465_48))
    };
    drop(v451_102);
    map_map_kernels::compose(&(v405_90),&(v451_103))
  };
  drop(v405_90);
  let v405_105: Space = map_map_kernels::unite(&(v405_88),&(v405_104));
  drop(v405_88);
  drop(v405_104);
  let v405_107: Space = map_map_kernels::intersect(&(*CONSTANT_54),&(v405_4));
  let v405_120: Space = if (v405_107).is_empty() { Space::new() } else {
    let v466_54: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_1));
    let v466_73: Space = if (v466_54).is_empty() { Space::new() } else {
      let v467_7: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v466_54),&(v467_7))
    };
    drop(v466_54);
    let v466_91: Space = if (v466_73).is_empty() { Space::new() } else {
      let v468_9: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v466_73),&(v468_9))
    };
    drop(v466_73);
    let v466_108: Space = if (v466_91).is_empty() { Space::new() } else {
      let v469_12: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v466_91),&(v469_12))
    };
    drop(v466_91);
    let v466_109: Space = if (v466_108).is_empty() { Space::new() } else {
      let v470_18: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v466_108),&(v470_18))
    };
    let v466_110: Space = if (v466_109).is_empty() { Space::new() } else {
      let v471_21: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v466_109),&(v471_21))
    };
    drop(v466_109);
    let v466_111: Space = if (v466_110).is_empty() { Space::new() } else {
      let v472_24: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v466_110),&(v472_24))
    };
    drop(v466_110);
    let v466_112: Space = if (v466_111).is_empty() { Space::new() } else {
      let v473_27: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v466_111),&(v473_27))
    };
    drop(v466_111);
    let v466_113: Space = if (v466_112).is_empty() { Space::new() } else {
      let v474_30: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v466_112),&(v474_30))
    };
    drop(v466_112);
    let v466_114: Space = if (v466_113).is_empty() { Space::new() } else {
      let v475_33: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v466_113),&(v475_33))
    };
    drop(v466_113);
    let v466_115: Space = if (v466_114).is_empty() { Space::new() } else {
      let v476_36: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v466_114),&(v476_36))
    };
    drop(v466_114);
    let v466_116: Space = if (v466_115).is_empty() { Space::new() } else {
      let v477_39: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v466_115),&(v477_39))
    };
    drop(v466_115);
    let v466_117: Space = if (v466_116).is_empty() { Space::new() } else {
      let v478_42: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v466_116),&(v478_42))
    };
    drop(v466_116);
    let v466_118: Space = if (v466_117).is_empty() { Space::new() } else {
      let v479_45: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v466_117),&(v479_45))
    };
    drop(v466_117);
    let v466_119: Space = if (v466_118).is_empty() { Space::new() } else {
      let v480_48: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v466_118),&(v480_48))
    };
    drop(v466_118);
    map_map_kernels::compose(&(v405_107),&(v466_119))
  };
  drop(v405_107);
  let v405_121: Space = map_map_kernels::unite(&(v405_105),&(v405_120));
  drop(v405_105);
  drop(v405_120);
  let v405_123: Space = map_map_kernels::intersect(&(*CONSTANT_55),&(v405_4));
  let v405_135: Space = if (v405_123).is_empty() { Space::new() } else {
    let v481_54: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_1));
    let v481_73: Space = if (v481_54).is_empty() { Space::new() } else {
      let v482_7: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v481_54),&(v482_7))
    };
    drop(v481_54);
    let v481_91: Space = if (v481_73).is_empty() { Space::new() } else {
      let v483_9: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v481_73),&(v483_9))
    };
    drop(v481_73);
    let v481_108: Space = if (v481_91).is_empty() { Space::new() } else {
      let v484_12: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v481_91),&(v484_12))
    };
    drop(v481_91);
    let v481_124: Space = if (v481_108).is_empty() { Space::new() } else {
      let v485_15: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v481_108),&(v485_15))
    };
    drop(v481_108);
    let v481_125: Space = if (v481_124).is_empty() { Space::new() } else {
      let v486_21: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v481_124),&(v486_21))
    };
    let v481_126: Space = if (v481_125).is_empty() { Space::new() } else {
      let v487_24: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v481_125),&(v487_24))
    };
    drop(v481_125);
    let v481_127: Space = if (v481_126).is_empty() { Space::new() } else {
      let v488_27: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v481_126),&(v488_27))
    };
    drop(v481_126);
    let v481_128: Space = if (v481_127).is_empty() { Space::new() } else {
      let v489_30: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v481_127),&(v489_30))
    };
    drop(v481_127);
    let v481_129: Space = if (v481_128).is_empty() { Space::new() } else {
      let v490_33: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v481_128),&(v490_33))
    };
    drop(v481_128);
    let v481_130: Space = if (v481_129).is_empty() { Space::new() } else {
      let v491_36: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v481_129),&(v491_36))
    };
    drop(v481_129);
    let v481_131: Space = if (v481_130).is_empty() { Space::new() } else {
      let v492_39: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v481_130),&(v492_39))
    };
    drop(v481_130);
    let v481_132: Space = if (v481_131).is_empty() { Space::new() } else {
      let v493_42: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v481_131),&(v493_42))
    };
    drop(v481_131);
    let v481_133: Space = if (v481_132).is_empty() { Space::new() } else {
      let v494_45: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v481_132),&(v494_45))
    };
    drop(v481_132);
    let v481_134: Space = if (v481_133).is_empty() { Space::new() } else {
      let v495_48: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v481_133),&(v495_48))
    };
    drop(v481_133);
    map_map_kernels::compose(&(v405_123),&(v481_134))
  };
  drop(v405_123);
  let v405_136: Space = map_map_kernels::unite(&(v405_121),&(v405_135));
  drop(v405_121);
  drop(v405_135);
  let v405_138: Space = map_map_kernels::intersect(&(*CONSTANT_56),&(v405_4));
  let v405_149: Space = if (v405_138).is_empty() { Space::new() } else {
    let v496_54: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_1));
    let v496_73: Space = if (v496_54).is_empty() { Space::new() } else {
      let v497_7: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v496_54),&(v497_7))
    };
    drop(v496_54);
    let v496_91: Space = if (v496_73).is_empty() { Space::new() } else {
      let v498_9: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v496_73),&(v498_9))
    };
    drop(v496_73);
    let v496_108: Space = if (v496_91).is_empty() { Space::new() } else {
      let v499_12: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v496_91),&(v499_12))
    };
    drop(v496_91);
    let v496_124: Space = if (v496_108).is_empty() { Space::new() } else {
      let v500_15: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v496_108),&(v500_15))
    };
    drop(v496_108);
    let v496_139: Space = if (v496_124).is_empty() { Space::new() } else {
      let v501_18: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v496_124),&(v501_18))
    };
    drop(v496_124);
    let v496_140: Space = if (v496_139).is_empty() { Space::new() } else {
      let v502_24: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v496_139),&(v502_24))
    };
    let v496_141: Space = if (v496_140).is_empty() { Space::new() } else {
      let v503_27: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v496_140),&(v503_27))
    };
    drop(v496_140);
    let v496_142: Space = if (v496_141).is_empty() { Space::new() } else {
      let v504_30: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v496_141),&(v504_30))
    };
    drop(v496_141);
    let v496_143: Space = if (v496_142).is_empty() { Space::new() } else {
      let v505_33: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v496_142),&(v505_33))
    };
    drop(v496_142);
    let v496_144: Space = if (v496_143).is_empty() { Space::new() } else {
      let v506_36: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v496_143),&(v506_36))
    };
    drop(v496_143);
    let v496_145: Space = if (v496_144).is_empty() { Space::new() } else {
      let v507_39: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v496_144),&(v507_39))
    };
    drop(v496_144);
    let v496_146: Space = if (v496_145).is_empty() { Space::new() } else {
      let v508_42: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v496_145),&(v508_42))
    };
    drop(v496_145);
    let v496_147: Space = if (v496_146).is_empty() { Space::new() } else {
      let v509_45: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v496_146),&(v509_45))
    };
    drop(v496_146);
    let v496_148: Space = if (v496_147).is_empty() { Space::new() } else {
      let v510_48: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v496_147),&(v510_48))
    };
    drop(v496_147);
    map_map_kernels::compose(&(v405_138),&(v496_148))
  };
  drop(v405_138);
  let v405_150: Space = map_map_kernels::unite(&(v405_136),&(v405_149));
  drop(v405_136);
  drop(v405_149);
  let v405_152: Space = map_map_kernels::intersect(&(*CONSTANT_57),&(v405_4));
  let v405_162: Space = if (v405_152).is_empty() { Space::new() } else {
    let v511_54: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_1));
    let v511_73: Space = if (v511_54).is_empty() { Space::new() } else {
      let v512_7: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v511_54),&(v512_7))
    };
    drop(v511_54);
    let v511_91: Space = if (v511_73).is_empty() { Space::new() } else {
      let v513_9: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v511_73),&(v513_9))
    };
    drop(v511_73);
    let v511_108: Space = if (v511_91).is_empty() { Space::new() } else {
      let v514_12: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v511_91),&(v514_12))
    };
    drop(v511_91);
    let v511_124: Space = if (v511_108).is_empty() { Space::new() } else {
      let v515_15: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v511_108),&(v515_15))
    };
    drop(v511_108);
    let v511_139: Space = if (v511_124).is_empty() { Space::new() } else {
      let v516_18: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v511_124),&(v516_18))
    };
    drop(v511_124);
    let v511_153: Space = if (v511_139).is_empty() { Space::new() } else {
      let v517_21: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v511_139),&(v517_21))
    };
    drop(v511_139);
    let v511_154: Space = if (v511_153).is_empty() { Space::new() } else {
      let v518_27: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v511_153),&(v518_27))
    };
    let v511_155: Space = if (v511_154).is_empty() { Space::new() } else {
      let v519_30: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v511_154),&(v519_30))
    };
    drop(v511_154);
    let v511_156: Space = if (v511_155).is_empty() { Space::new() } else {
      let v520_33: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v511_155),&(v520_33))
    };
    drop(v511_155);
    let v511_157: Space = if (v511_156).is_empty() { Space::new() } else {
      let v521_36: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v511_156),&(v521_36))
    };
    drop(v511_156);
    let v511_158: Space = if (v511_157).is_empty() { Space::new() } else {
      let v522_39: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v511_157),&(v522_39))
    };
    drop(v511_157);
    let v511_159: Space = if (v511_158).is_empty() { Space::new() } else {
      let v523_42: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v511_158),&(v523_42))
    };
    drop(v511_158);
    let v511_160: Space = if (v511_159).is_empty() { Space::new() } else {
      let v524_45: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v511_159),&(v524_45))
    };
    drop(v511_159);
    let v511_161: Space = if (v511_160).is_empty() { Space::new() } else {
      let v525_48: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v511_160),&(v525_48))
    };
    drop(v511_160);
    map_map_kernels::compose(&(v405_152),&(v511_161))
  };
  drop(v405_152);
  let v405_163: Space = map_map_kernels::unite(&(v405_150),&(v405_162));
  drop(v405_150);
  drop(v405_162);
  let v405_165: Space = map_map_kernels::intersect(&(*CONSTANT_58),&(v405_4));
  let v405_174: Space = if (v405_165).is_empty() { Space::new() } else {
    let v526_54: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_1));
    let v526_73: Space = if (v526_54).is_empty() { Space::new() } else {
      let v527_7: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v526_54),&(v527_7))
    };
    drop(v526_54);
    let v526_91: Space = if (v526_73).is_empty() { Space::new() } else {
      let v528_9: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v526_73),&(v528_9))
    };
    drop(v526_73);
    let v526_108: Space = if (v526_91).is_empty() { Space::new() } else {
      let v529_12: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v526_91),&(v529_12))
    };
    drop(v526_91);
    let v526_124: Space = if (v526_108).is_empty() { Space::new() } else {
      let v530_15: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v526_108),&(v530_15))
    };
    drop(v526_108);
    let v526_139: Space = if (v526_124).is_empty() { Space::new() } else {
      let v531_18: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v526_124),&(v531_18))
    };
    drop(v526_124);
    let v526_153: Space = if (v526_139).is_empty() { Space::new() } else {
      let v532_21: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v526_139),&(v532_21))
    };
    drop(v526_139);
    let v526_166: Space = if (v526_153).is_empty() { Space::new() } else {
      let v533_24: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v526_153),&(v533_24))
    };
    drop(v526_153);
    let v526_167: Space = if (v526_166).is_empty() { Space::new() } else {
      let v534_30: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v526_166),&(v534_30))
    };
    let v526_168: Space = if (v526_167).is_empty() { Space::new() } else {
      let v535_33: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v526_167),&(v535_33))
    };
    drop(v526_167);
    let v526_169: Space = if (v526_168).is_empty() { Space::new() } else {
      let v536_36: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v526_168),&(v536_36))
    };
    drop(v526_168);
    let v526_170: Space = if (v526_169).is_empty() { Space::new() } else {
      let v537_39: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v526_169),&(v537_39))
    };
    drop(v526_169);
    let v526_171: Space = if (v526_170).is_empty() { Space::new() } else {
      let v538_42: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v526_170),&(v538_42))
    };
    drop(v526_170);
    let v526_172: Space = if (v526_171).is_empty() { Space::new() } else {
      let v539_45: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v526_171),&(v539_45))
    };
    drop(v526_171);
    let v526_173: Space = if (v526_172).is_empty() { Space::new() } else {
      let v540_48: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v526_172),&(v540_48))
    };
    drop(v526_172);
    map_map_kernels::compose(&(v405_165),&(v526_173))
  };
  drop(v405_165);
  let v405_175: Space = map_map_kernels::unite(&(v405_163),&(v405_174));
  drop(v405_163);
  drop(v405_174);
  let v405_177: Space = map_map_kernels::intersect(&(*CONSTANT_59),&(v405_4));
  let v405_185: Space = if (v405_177).is_empty() { Space::new() } else {
    let v541_54: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_1));
    let v541_73: Space = if (v541_54).is_empty() { Space::new() } else {
      let v542_7: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v541_54),&(v542_7))
    };
    drop(v541_54);
    let v541_91: Space = if (v541_73).is_empty() { Space::new() } else {
      let v543_9: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v541_73),&(v543_9))
    };
    drop(v541_73);
    let v541_108: Space = if (v541_91).is_empty() { Space::new() } else {
      let v544_12: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v541_91),&(v544_12))
    };
    drop(v541_91);
    let v541_124: Space = if (v541_108).is_empty() { Space::new() } else {
      let v545_15: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v541_108),&(v545_15))
    };
    drop(v541_108);
    let v541_139: Space = if (v541_124).is_empty() { Space::new() } else {
      let v546_18: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v541_124),&(v546_18))
    };
    drop(v541_124);
    let v541_153: Space = if (v541_139).is_empty() { Space::new() } else {
      let v547_21: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v541_139),&(v547_21))
    };
    drop(v541_139);
    let v541_166: Space = if (v541_153).is_empty() { Space::new() } else {
      let v548_24: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v541_153),&(v548_24))
    };
    drop(v541_153);
    let v541_178: Space = if (v541_166).is_empty() { Space::new() } else {
      let v549_27: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v541_166),&(v549_27))
    };
    drop(v541_166);
    let v541_179: Space = if (v541_178).is_empty() { Space::new() } else {
      let v550_33: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v541_178),&(v550_33))
    };
    let v541_180: Space = if (v541_179).is_empty() { Space::new() } else {
      let v551_36: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v541_179),&(v551_36))
    };
    drop(v541_179);
    let v541_181: Space = if (v541_180).is_empty() { Space::new() } else {
      let v552_39: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v541_180),&(v552_39))
    };
    drop(v541_180);
    let v541_182: Space = if (v541_181).is_empty() { Space::new() } else {
      let v553_42: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v541_181),&(v553_42))
    };
    drop(v541_181);
    let v541_183: Space = if (v541_182).is_empty() { Space::new() } else {
      let v554_45: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v541_182),&(v554_45))
    };
    drop(v541_182);
    let v541_184: Space = if (v541_183).is_empty() { Space::new() } else {
      let v555_48: Space = map_kernels::unwrap(&(*capture_1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v541_183),&(v555_48))
    };
    drop(v541_183);
    map_map_kernels::compose(&(v405_177),&(v541_184))
  };
  drop(v405_177);

((v405_175).clone(),(v405_185).clone(),(v405_4).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_3: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &(*CONSTANT_2));
  let v0_6: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_3), &(*CONSTANT_4));
  let v0_7: Space = map_map_kernels::unite(&(v0_3),&(v0_6));
  let v0_10: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_5), &(*CONSTANT_6));
  let v0_11: Space = map_map_kernels::unite(&(v0_7),&(v0_10));
  let v0_14: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_7), &(*CONSTANT_8));
  let v0_15: Space = map_map_kernels::unite(&(v0_11),&(v0_14));
  let v0_18: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_9), &(*CONSTANT_10));
  let v0_19: Space = map_map_kernels::unite(&(v0_15),&(v0_18));
  let v0_22: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_11), &(*CONSTANT_12));
  let v0_23: Space = map_map_kernels::unite(&(v0_19),&(v0_22));
  let v0_26: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_13), &(*CONSTANT_14));
  let v0_27: Space = map_map_kernels::unite(&(v0_23),&(v0_26));
  let v0_30: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_15), &(*CONSTANT_16));
  let v0_31: Space = map_map_kernels::unite(&(v0_27),&(v0_30));
  let v0_34: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_17), &(*CONSTANT_18));
  let v0_35: Space = map_map_kernels::unite(&(v0_31),&(v0_34));
  let v0_38: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_19), &(*CONSTANT_20));
  let v0_39: Space = map_map_kernels::unite(&(v0_35),&(v0_38));
  let v0_42: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_21), &(*CONSTANT_22));
  let v0_43: Space = map_map_kernels::unite(&(v0_39),&(v0_42));
  let v0_46: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_23), &(*CONSTANT_24));
  let v0_47: Space = map_map_kernels::unite(&(v0_43),&(v0_46));
  let v0_50: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_25), &(*CONSTANT_26));
  let v0_51: Space = map_map_kernels::unite(&(v0_47),&(v0_50));
  let v0_54: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_27), &(*CONSTANT_28));
  let v0_55: Space = map_map_kernels::unite(&(v0_51),&(v0_54));
  let v0_58: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_29), &(*CONSTANT_30));
  let v0_59: Space = map_map_kernels::unite(&(v0_55),&(v0_58));
  let v0_62: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_1), &(*CONSTANT_32));
  let v0_63: Space = map_map_kernels::unite(&(v0_59),&(v0_62));
  let v0_65: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_3), &(*CONSTANT_33));
  let v0_66: Space = map_map_kernels::unite(&(v0_63),&(v0_65));
  let v0_68: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_5), &(*CONSTANT_34));
  let v0_69: Space = map_map_kernels::unite(&(v0_66),&(v0_68));
  let v0_71: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_7), &(*CONSTANT_35));
  let v0_72: Space = map_map_kernels::unite(&(v0_69),&(v0_71));
  let v0_74: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_9), &(*CONSTANT_36));
  let v0_75: Space = map_map_kernels::unite(&(v0_72),&(v0_74));
  let v0_77: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_11), &(*CONSTANT_37));
  let v0_78: Space = map_map_kernels::unite(&(v0_75),&(v0_77));
  let v0_80: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_13), &(*CONSTANT_38));
  let v0_81: Space = map_map_kernels::unite(&(v0_78),&(v0_80));
  let v0_83: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_15), &(*CONSTANT_39));
  let v0_84: Space = map_map_kernels::unite(&(v0_81),&(v0_83));
  let v0_86: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_17), &(*CONSTANT_40));
  let v0_87: Space = map_map_kernels::unite(&(v0_84),&(v0_86));
  let v0_89: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_19), &(*CONSTANT_41));
  let v0_90: Space = map_map_kernels::unite(&(v0_87),&(v0_89));
  let v0_92: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_21), &(*CONSTANT_42));
  let v0_93: Space = map_map_kernels::unite(&(v0_90),&(v0_92));
  let v0_95: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_23), &(*CONSTANT_43));
  let v0_96: Space = map_map_kernels::unite(&(v0_93),&(v0_95));
  let v0_98: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_25), &(*CONSTANT_44));
  let v0_99: Space = map_map_kernels::unite(&(v0_96),&(v0_98));
  let v0_101: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_27), &(*CONSTANT_45));
  let v0_102: Space = map_map_kernels::unite(&(v0_99),&(v0_101));
  let v0_104: Space = routine_1(c, &(*CONSTANT_31), &(*CONSTANT_29), &(*CONSTANT_46));
  let v0_105: Space = map_map_kernels::unite(&(v0_102),&(v0_104));
  let v0_108: Space = routine_1(c, &(*CONSTANT_47), &(*CONSTANT_1), &(*CONSTANT_48));
  let v0_109: Space = map_map_kernels::unite(&(v0_105),&(v0_108));
  let v0_111: Space = routine_1(c, &(*CONSTANT_47), &(*CONSTANT_3), &(*CONSTANT_48));
  let v0_112: Space = map_map_kernels::unite(&(v0_109),&(v0_111));
  let v0_114: Space = routine_1(c, &(*CONSTANT_47), &(*CONSTANT_9), &(*CONSTANT_49));
  let v0_115: Space = map_map_kernels::unite(&(v0_112),&(v0_114));
  (v0_115).clone()
}

fn routine_1(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1_3 = Space::new();
  let mut v1_3_cursor = (*s0).read_zipper();
  for v1_3_byte in v1_3_cursor.child_mask().iter() {
    v1_3_cursor.descend_to_byte(v1_3_byte);
    {
    let v1_3_tail = v1_3_cursor.fork_read_zipper();
    let v1_3_head = Path::from_slice(&[v1_3_byte]);
    let mut v2_2 = Space::new();
    let mut v2_2_cursor = (v1_3_tail).read_zipper();
    for v2_2_byte in v2_2_cursor.child_mask().iter() {
      v2_2_cursor.descend_to_byte(v2_2_byte);
      {
      let v2_2_tail = v2_2_cursor.fork_read_zipper();
      let v2_2_head = Path::from_slice(&[v2_2_byte]);
      let v3_2: Path = concat_path(&(v1_3_head),&(v2_2_head));
      let mut v3_3 = Space::new();
      let mut v3_3_cursor = (v2_2_tail).read_zipper();
      for v3_3_byte in v3_3_cursor.child_mask().iter() {
        v3_3_cursor.descend_to_byte(v3_3_byte);
        {
        let v3_3_tail = v3_3_cursor.fork_read_zipper();
        let v3_3_head = Path::from_slice(&[v3_3_byte]);
        let v4_2: Path = concat_path(&(v3_2),&(v3_3_head));
        let mut v4_3 = Space::new();
        let mut v4_3_cursor = (v3_3_tail).read_zipper();
        for v4_3_byte in v4_3_cursor.child_mask().iter() {
          v4_3_cursor.descend_to_byte(v4_3_byte);
          {
          let v4_3_tail = v4_3_cursor.fork_read_zipper();
          let v4_3_head = Path::from_slice(&[v4_3_byte]);
          let v5_2: Path = concat_path(&(v4_2),&(v4_3_head));
          let mut v5_3 = Space::new();
          let mut v5_3_cursor = (v4_3_tail).read_zipper();
          for v5_3_byte in v5_3_cursor.child_mask().iter() {
            v5_3_cursor.descend_to_byte(v5_3_byte);
            {
            let v5_3_tail = v5_3_cursor.fork_read_zipper();
            let v5_3_head = Path::from_slice(&[v5_3_byte]);
            let mut v6_2 = Space::new();
            let mut v6_2_cursor = (v5_3_tail).read_zipper();
            for v6_2_byte in v6_2_cursor.child_mask().iter() {
              v6_2_cursor.descend_to_byte(v6_2_byte);
              {
              let v6_2_tail = v6_2_cursor.fork_read_zipper();
              let v6_2_head = Path::from_slice(&[v6_2_byte]);
              let v7_2: Path = concat_path(&(v5_3_head),&(v6_2_head));
              let mut v7_3 = Space::new();
              let mut v7_3_cursor = (v6_2_tail).read_zipper();
              for v7_3_byte in v7_3_cursor.child_mask().iter() {
                v7_3_cursor.descend_to_byte(v7_3_byte);
                {
                let v7_3_tail = v7_3_cursor.fork_read_zipper();
                let v7_3_head = Path::from_slice(&[v7_3_byte]);
                let v8_2: Path = concat_path(&(v7_2),&(v7_3_head));
                let mut v8_3 = Space::new();
                let mut v8_3_cursor = (v7_3_tail).read_zipper();
                for v8_3_byte in v8_3_cursor.child_mask().iter() {
                  v8_3_cursor.descend_to_byte(v8_3_byte);
                  {
                  let v8_3_tail = v8_3_cursor.fork_read_zipper();
                  let v8_3_head = Path::from_slice(&[v8_3_byte]);
                  let v9_2: Path = concat_path(&(v8_2),&(v8_3_head));
                  let v9_3: Space = routine_2(c, &(v9_2), &(*p1), &(*p0), &(v5_2), &(v8_3_tail).make_space());
                  drop(v9_2);
                  v8_3.join_into((v9_3).clone());
                  }
                  v8_3_cursor.ascend(1);
                }
                drop(v8_3_cursor);
                drop(v8_2);
                v7_3.join_into((v8_3).clone());
                }
                v7_3_cursor.ascend(1);
              }
              drop(v7_3_cursor);
              drop(v7_2);
              v6_2.join_into((v7_3).clone());
              }
              v6_2_cursor.ascend(1);
            }
            drop(v6_2_cursor);
            v5_3.join_into((v6_2).clone());
            }
            v5_3_cursor.ascend(1);
          }
          drop(v5_3_cursor);
          drop(v5_2);
          v4_3.join_into((v5_3).clone());
          }
          v4_3_cursor.ascend(1);
        }
        drop(v4_3_cursor);
        drop(v4_2);
        v3_3.join_into((v4_3).clone());
        }
        v3_3_cursor.ascend(1);
      }
      drop(v3_3_cursor);
      drop(v3_2);
      v2_2.join_into((v3_3).clone());
      }
      v2_2_cursor.ascend(1);
    }
    drop(v2_2_cursor);
    v1_3.join_into((v2_2).clone());
    }
    v1_3_cursor.ascend(1);
  }
  drop(v1_3_cursor);
  (v1_3).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let mut v10_5 = Space::new();
  let mut v10_5_cursor = (*s0).read_zipper();
  for v10_5_byte in v10_5_cursor.child_mask().iter() {
    v10_5_cursor.descend_to_byte(v10_5_byte);
    {
    let v10_5_tail = v10_5_cursor.fork_read_zipper();
    let v10_5_head = Path::from_slice(&[v10_5_byte]);
    let mut v11_2 = Space::new();
    let mut v11_2_cursor = (v10_5_tail).read_zipper();
    for v11_2_byte in v11_2_cursor.child_mask().iter() {
      v11_2_cursor.descend_to_byte(v11_2_byte);
      {
      let v11_2_tail = v11_2_cursor.fork_read_zipper();
      let v11_2_head = Path::from_slice(&[v11_2_byte]);
      let v12_2: Path = concat_path(&(v10_5_head),&(v11_2_head));
      let mut v12_3 = Space::new();
      let mut v12_3_cursor = (v11_2_tail).read_zipper();
      for v12_3_byte in v12_3_cursor.child_mask().iter() {
        v12_3_cursor.descend_to_byte(v12_3_byte);
        {
        let v12_3_tail = v12_3_cursor.fork_read_zipper();
        let v12_3_head = Path::from_slice(&[v12_3_byte]);
        let v13_2: Path = concat_path(&(v12_2),&(v12_3_head));
        let mut v13_3 = Space::new();
        let mut v13_3_cursor = (v12_3_tail).read_zipper();
        for v13_3_byte in v13_3_cursor.child_mask().iter() {
          v13_3_cursor.descend_to_byte(v13_3_byte);
          {
          let v13_3_tail = v13_3_cursor.fork_read_zipper();
          let v13_3_head = Path::from_slice(&[v13_3_byte]);
          let v14_2: Path = concat_path(&(v13_2),&(v13_3_head));
          let mut v14_3 = Space::new();
          let mut v14_3_cursor = (v13_3_tail).read_zipper();
          for v14_3_byte in v14_3_cursor.child_mask().iter() {
            v14_3_cursor.descend_to_byte(v14_3_byte);
            {
            let v14_3_tail = v14_3_cursor.fork_read_zipper();
            let v14_3_head = Path::from_slice(&[v14_3_byte]);
            let mut v15_2 = Space::new();
            let mut v15_2_cursor = (v14_3_tail).read_zipper();
            for v15_2_byte in v15_2_cursor.child_mask().iter() {
              v15_2_cursor.descend_to_byte(v15_2_byte);
              {
              let v15_2_tail = v15_2_cursor.fork_read_zipper();
              let v15_2_head = Path::from_slice(&[v15_2_byte]);
              let v16_2: Path = concat_path(&(v14_3_head),&(v15_2_head));
              let mut v16_3 = Space::new();
              let mut v16_3_cursor = (v15_2_tail).read_zipper();
              for v16_3_byte in v16_3_cursor.child_mask().iter() {
                v16_3_cursor.descend_to_byte(v16_3_byte);
                {
                let v16_3_tail = v16_3_cursor.fork_read_zipper();
                let v16_3_head = Path::from_slice(&[v16_3_byte]);
                let v17_2: Path = concat_path(&(v16_2),&(v16_3_head));
                let mut v17_3 = Space::new();
                let mut v17_3_cursor = (v16_3_tail).read_zipper();
                for v17_3_byte in v17_3_cursor.child_mask().iter() {
                  v17_3_cursor.descend_to_byte(v17_3_byte);
                  {
                  let v17_3_tail = v17_3_cursor.fork_read_zipper();
                  let v17_3_head = Path::from_slice(&[v17_3_byte]);
                  let v18_2: Path = concat_path(&(v17_2),&(v17_3_head));
                  let v18_3: Space = routine_3(c, &(v18_2), &(*p1), &(*p2), &(*p3), &(*p0), &(v14_2), &(v17_3_tail).make_space());
                  drop(v18_2);
                  v17_3.join_into((v18_3).clone());
                  }
                  v17_3_cursor.ascend(1);
                }
                drop(v17_3_cursor);
                drop(v17_2);
                v16_3.join_into((v17_3).clone());
                }
                v16_3_cursor.ascend(1);
              }
              drop(v16_3_cursor);
              drop(v16_2);
              v15_2.join_into((v16_3).clone());
              }
              v15_2_cursor.ascend(1);
            }
            drop(v15_2_cursor);
            v14_3.join_into((v15_2).clone());
            }
            v14_3_cursor.ascend(1);
          }
          drop(v14_3_cursor);
          drop(v14_2);
          v13_3.join_into((v14_3).clone());
          }
          v13_3_cursor.ascend(1);
        }
        drop(v13_3_cursor);
        drop(v13_2);
        v12_3.join_into((v13_3).clone());
        }
        v12_3_cursor.ascend(1);
      }
      drop(v12_3_cursor);
      drop(v12_2);
      v11_2.join_into((v12_3).clone());
      }
      v11_2_cursor.ascend(1);
    }
    drop(v11_2_cursor);
    v10_5.join_into((v11_2).clone());
    }
    v10_5_cursor.ascend(1);
  }
  drop(v10_5_cursor);
  (v10_5).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, s0: &Space) -> Space {
  let mut v19_7 = Space::new();
  let mut v19_7_cursor = (*s0).read_zipper();
  for v19_7_byte in v19_7_cursor.child_mask().iter() {
    v19_7_cursor.descend_to_byte(v19_7_byte);
    {
    let v19_7_tail = v19_7_cursor.fork_read_zipper();
    let v19_7_head = Path::from_slice(&[v19_7_byte]);
    let mut v20_2 = Space::new();
    let mut v20_2_cursor = (v19_7_tail).read_zipper();
    for v20_2_byte in v20_2_cursor.child_mask().iter() {
      v20_2_cursor.descend_to_byte(v20_2_byte);
      {
      let v20_2_tail = v20_2_cursor.fork_read_zipper();
      let v20_2_head = Path::from_slice(&[v20_2_byte]);
      let v21_2: Path = concat_path(&(v19_7_head),&(v20_2_head));
      let mut v21_3 = Space::new();
      let mut v21_3_cursor = (v20_2_tail).read_zipper();
      for v21_3_byte in v21_3_cursor.child_mask().iter() {
        v21_3_cursor.descend_to_byte(v21_3_byte);
        {
        let v21_3_tail = v21_3_cursor.fork_read_zipper();
        let v21_3_head = Path::from_slice(&[v21_3_byte]);
        let v22_2: Path = concat_path(&(v21_2),&(v21_3_head));
        let mut v22_3 = Space::new();
        let mut v22_3_cursor = (v21_3_tail).read_zipper();
        for v22_3_byte in v22_3_cursor.child_mask().iter() {
          v22_3_cursor.descend_to_byte(v22_3_byte);
          {
          let v22_3_tail = v22_3_cursor.fork_read_zipper();
          let v22_3_head = Path::from_slice(&[v22_3_byte]);
          let v23_2: Path = concat_path(&(v22_2),&(v22_3_head));
          let mut v23_3 = Space::new();
          let mut v23_3_cursor = (v22_3_tail).read_zipper();
          for v23_3_byte in v23_3_cursor.child_mask().iter() {
            v23_3_cursor.descend_to_byte(v23_3_byte);
            {
            let v23_3_tail = v23_3_cursor.fork_read_zipper();
            let v23_3_head = Path::from_slice(&[v23_3_byte]);
            let mut v24_2 = Space::new();
            let mut v24_2_cursor = (v23_3_tail).read_zipper();
            for v24_2_byte in v24_2_cursor.child_mask().iter() {
              v24_2_cursor.descend_to_byte(v24_2_byte);
              {
              let v24_2_tail = v24_2_cursor.fork_read_zipper();
              let v24_2_head = Path::from_slice(&[v24_2_byte]);
              let v25_2: Path = concat_path(&(v23_3_head),&(v24_2_head));
              let mut v25_3 = Space::new();
              let mut v25_3_cursor = (v24_2_tail).read_zipper();
              for v25_3_byte in v25_3_cursor.child_mask().iter() {
                v25_3_cursor.descend_to_byte(v25_3_byte);
                {
                let v25_3_tail = v25_3_cursor.fork_read_zipper();
                let v25_3_head = Path::from_slice(&[v25_3_byte]);
                let v26_2: Path = concat_path(&(v25_2),&(v25_3_head));
                let mut v26_3 = Space::new();
                let mut v26_3_cursor = (v25_3_tail).read_zipper();
                for v26_3_byte in v26_3_cursor.child_mask().iter() {
                  v26_3_cursor.descend_to_byte(v26_3_byte);
                  {
                  let v26_3_tail = v26_3_cursor.fork_read_zipper();
                  let v26_3_head = Path::from_slice(&[v26_3_byte]);
                  let v27_2: Path = concat_path(&(v26_2),&(v26_3_head));
                  let v27_3: Space = routine_4(c, &(v27_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p0), &(v23_2), &(v26_3_tail).make_space());
                  drop(v27_2);
                  v26_3.join_into((v27_3).clone());
                  }
                  v26_3_cursor.ascend(1);
                }
                drop(v26_3_cursor);
                drop(v26_2);
                v25_3.join_into((v26_3).clone());
                }
                v25_3_cursor.ascend(1);
              }
              drop(v25_3_cursor);
              drop(v25_2);
              v24_2.join_into((v25_3).clone());
              }
              v24_2_cursor.ascend(1);
            }
            drop(v24_2_cursor);
            v23_3.join_into((v24_2).clone());
            }
            v23_3_cursor.ascend(1);
          }
          drop(v23_3_cursor);
          drop(v23_2);
          v22_3.join_into((v23_3).clone());
          }
          v22_3_cursor.ascend(1);
        }
        drop(v22_3_cursor);
        drop(v22_2);
        v21_3.join_into((v22_3).clone());
        }
        v21_3_cursor.ascend(1);
      }
      drop(v21_3_cursor);
      drop(v21_2);
      v20_2.join_into((v21_3).clone());
      }
      v20_2_cursor.ascend(1);
    }
    drop(v20_2_cursor);
    v19_7.join_into((v20_2).clone());
    }
    v19_7_cursor.ascend(1);
  }
  drop(v19_7_cursor);
  (v19_7).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, s0: &Space) -> Space {
  let mut v28_9 = Space::new();
  let mut v28_9_cursor = (*s0).read_zipper();
  for v28_9_byte in v28_9_cursor.child_mask().iter() {
    v28_9_cursor.descend_to_byte(v28_9_byte);
    {
    let v28_9_tail = v28_9_cursor.fork_read_zipper();
    let v28_9_head = Path::from_slice(&[v28_9_byte]);
    let mut v29_2 = Space::new();
    let mut v29_2_cursor = (v28_9_tail).read_zipper();
    for v29_2_byte in v29_2_cursor.child_mask().iter() {
      v29_2_cursor.descend_to_byte(v29_2_byte);
      {
      let v29_2_tail = v29_2_cursor.fork_read_zipper();
      let v29_2_head = Path::from_slice(&[v29_2_byte]);
      let v30_2: Path = concat_path(&(v28_9_head),&(v29_2_head));
      let mut v30_3 = Space::new();
      let mut v30_3_cursor = (v29_2_tail).read_zipper();
      for v30_3_byte in v30_3_cursor.child_mask().iter() {
        v30_3_cursor.descend_to_byte(v30_3_byte);
        {
        let v30_3_tail = v30_3_cursor.fork_read_zipper();
        let v30_3_head = Path::from_slice(&[v30_3_byte]);
        let v31_2: Path = concat_path(&(v30_2),&(v30_3_head));
        let mut v31_3 = Space::new();
        let mut v31_3_cursor = (v30_3_tail).read_zipper();
        for v31_3_byte in v31_3_cursor.child_mask().iter() {
          v31_3_cursor.descend_to_byte(v31_3_byte);
          {
          let v31_3_tail = v31_3_cursor.fork_read_zipper();
          let v31_3_head = Path::from_slice(&[v31_3_byte]);
          let v32_2: Path = concat_path(&(v31_2),&(v31_3_head));
          let mut v32_3 = Space::new();
          let mut v32_3_cursor = (v31_3_tail).read_zipper();
          for v32_3_byte in v32_3_cursor.child_mask().iter() {
            v32_3_cursor.descend_to_byte(v32_3_byte);
            {
            let v32_3_tail = v32_3_cursor.fork_read_zipper();
            let v32_3_head = Path::from_slice(&[v32_3_byte]);
            let mut v33_2 = Space::new();
            let mut v33_2_cursor = (v32_3_tail).read_zipper();
            for v33_2_byte in v33_2_cursor.child_mask().iter() {
              v33_2_cursor.descend_to_byte(v33_2_byte);
              {
              let v33_2_tail = v33_2_cursor.fork_read_zipper();
              let v33_2_head = Path::from_slice(&[v33_2_byte]);
              let v34_2: Path = concat_path(&(v32_3_head),&(v33_2_head));
              let mut v34_3 = Space::new();
              let mut v34_3_cursor = (v33_2_tail).read_zipper();
              for v34_3_byte in v34_3_cursor.child_mask().iter() {
                v34_3_cursor.descend_to_byte(v34_3_byte);
                {
                let v34_3_tail = v34_3_cursor.fork_read_zipper();
                let v34_3_head = Path::from_slice(&[v34_3_byte]);
                let v35_2: Path = concat_path(&(v34_2),&(v34_3_head));
                let mut v35_3 = Space::new();
                let mut v35_3_cursor = (v34_3_tail).read_zipper();
                for v35_3_byte in v35_3_cursor.child_mask().iter() {
                  v35_3_cursor.descend_to_byte(v35_3_byte);
                  {
                  let v35_3_tail = v35_3_cursor.fork_read_zipper();
                  let v35_3_head = Path::from_slice(&[v35_3_byte]);
                  let v36_2: Path = concat_path(&(v35_2),&(v35_3_head));
                  let v36_3: Space = routine_5(c, &(v36_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p0), &(v32_2), &(v35_3_tail).make_space());
                  drop(v36_2);
                  v35_3.join_into((v36_3).clone());
                  }
                  v35_3_cursor.ascend(1);
                }
                drop(v35_3_cursor);
                drop(v35_2);
                v34_3.join_into((v35_3).clone());
                }
                v34_3_cursor.ascend(1);
              }
              drop(v34_3_cursor);
              drop(v34_2);
              v33_2.join_into((v34_3).clone());
              }
              v33_2_cursor.ascend(1);
            }
            drop(v33_2_cursor);
            v32_3.join_into((v33_2).clone());
            }
            v32_3_cursor.ascend(1);
          }
          drop(v32_3_cursor);
          drop(v32_2);
          v31_3.join_into((v32_3).clone());
          }
          v31_3_cursor.ascend(1);
        }
        drop(v31_3_cursor);
        drop(v31_2);
        v30_3.join_into((v31_3).clone());
        }
        v30_3_cursor.ascend(1);
      }
      drop(v30_3_cursor);
      drop(v30_2);
      v29_2.join_into((v30_3).clone());
      }
      v29_2_cursor.ascend(1);
    }
    drop(v29_2_cursor);
    v28_9.join_into((v29_2).clone());
    }
    v28_9_cursor.ascend(1);
  }
  drop(v28_9_cursor);
  (v28_9).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, s0: &Space) -> Space {
  let mut v37_11 = Space::new();
  let mut v37_11_cursor = (*s0).read_zipper();
  for v37_11_byte in v37_11_cursor.child_mask().iter() {
    v37_11_cursor.descend_to_byte(v37_11_byte);
    {
    let v37_11_tail = v37_11_cursor.fork_read_zipper();
    let v37_11_head = Path::from_slice(&[v37_11_byte]);
    let mut v38_2 = Space::new();
    let mut v38_2_cursor = (v37_11_tail).read_zipper();
    for v38_2_byte in v38_2_cursor.child_mask().iter() {
      v38_2_cursor.descend_to_byte(v38_2_byte);
      {
      let v38_2_tail = v38_2_cursor.fork_read_zipper();
      let v38_2_head = Path::from_slice(&[v38_2_byte]);
      let v39_2: Path = concat_path(&(v37_11_head),&(v38_2_head));
      let mut v39_3 = Space::new();
      let mut v39_3_cursor = (v38_2_tail).read_zipper();
      for v39_3_byte in v39_3_cursor.child_mask().iter() {
        v39_3_cursor.descend_to_byte(v39_3_byte);
        {
        let v39_3_tail = v39_3_cursor.fork_read_zipper();
        let v39_3_head = Path::from_slice(&[v39_3_byte]);
        let v40_2: Path = concat_path(&(v39_2),&(v39_3_head));
        let mut v40_3 = Space::new();
        let mut v40_3_cursor = (v39_3_tail).read_zipper();
        for v40_3_byte in v40_3_cursor.child_mask().iter() {
          v40_3_cursor.descend_to_byte(v40_3_byte);
          {
          let v40_3_tail = v40_3_cursor.fork_read_zipper();
          let v40_3_head = Path::from_slice(&[v40_3_byte]);
          let v41_2: Path = concat_path(&(v40_2),&(v40_3_head));
          let mut v41_3 = Space::new();
          let mut v41_3_cursor = (v40_3_tail).read_zipper();
          for v41_3_byte in v41_3_cursor.child_mask().iter() {
            v41_3_cursor.descend_to_byte(v41_3_byte);
            {
            let v41_3_tail = v41_3_cursor.fork_read_zipper();
            let v41_3_head = Path::from_slice(&[v41_3_byte]);
            let mut v42_2 = Space::new();
            let mut v42_2_cursor = (v41_3_tail).read_zipper();
            for v42_2_byte in v42_2_cursor.child_mask().iter() {
              v42_2_cursor.descend_to_byte(v42_2_byte);
              {
              let v42_2_tail = v42_2_cursor.fork_read_zipper();
              let v42_2_head = Path::from_slice(&[v42_2_byte]);
              let v43_2: Path = concat_path(&(v41_3_head),&(v42_2_head));
              let mut v43_3 = Space::new();
              let mut v43_3_cursor = (v42_2_tail).read_zipper();
              for v43_3_byte in v43_3_cursor.child_mask().iter() {
                v43_3_cursor.descend_to_byte(v43_3_byte);
                {
                let v43_3_tail = v43_3_cursor.fork_read_zipper();
                let v43_3_head = Path::from_slice(&[v43_3_byte]);
                let v44_2: Path = concat_path(&(v43_2),&(v43_3_head));
                let mut v44_3 = Space::new();
                let mut v44_3_cursor = (v43_3_tail).read_zipper();
                for v44_3_byte in v44_3_cursor.child_mask().iter() {
                  v44_3_cursor.descend_to_byte(v44_3_byte);
                  {
                  let v44_3_tail = v44_3_cursor.fork_read_zipper();
                  let v44_3_head = Path::from_slice(&[v44_3_byte]);
                  let v45_2: Path = concat_path(&(v44_2),&(v44_3_head));
                  let v45_3: Space = routine_6(c, &(v45_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p0), &(v41_2), &(v44_3_tail).make_space());
                  drop(v45_2);
                  v44_3.join_into((v45_3).clone());
                  }
                  v44_3_cursor.ascend(1);
                }
                drop(v44_3_cursor);
                drop(v44_2);
                v43_3.join_into((v44_3).clone());
                }
                v43_3_cursor.ascend(1);
              }
              drop(v43_3_cursor);
              drop(v43_2);
              v42_2.join_into((v43_3).clone());
              }
              v42_2_cursor.ascend(1);
            }
            drop(v42_2_cursor);
            v41_3.join_into((v42_2).clone());
            }
            v41_3_cursor.ascend(1);
          }
          drop(v41_3_cursor);
          drop(v41_2);
          v40_3.join_into((v41_3).clone());
          }
          v40_3_cursor.ascend(1);
        }
        drop(v40_3_cursor);
        drop(v40_2);
        v39_3.join_into((v40_3).clone());
        }
        v39_3_cursor.ascend(1);
      }
      drop(v39_3_cursor);
      drop(v39_2);
      v38_2.join_into((v39_3).clone());
      }
      v38_2_cursor.ascend(1);
    }
    drop(v38_2_cursor);
    v37_11.join_into((v38_2).clone());
    }
    v37_11_cursor.ascend(1);
  }
  drop(v37_11_cursor);
  (v37_11).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, s0: &Space) -> Space {
  let mut v46_13 = Space::new();
  let mut v46_13_cursor = (*s0).read_zipper();
  for v46_13_byte in v46_13_cursor.child_mask().iter() {
    v46_13_cursor.descend_to_byte(v46_13_byte);
    {
    let v46_13_tail = v46_13_cursor.fork_read_zipper();
    let v46_13_head = Path::from_slice(&[v46_13_byte]);
    let mut v47_2 = Space::new();
    let mut v47_2_cursor = (v46_13_tail).read_zipper();
    for v47_2_byte in v47_2_cursor.child_mask().iter() {
      v47_2_cursor.descend_to_byte(v47_2_byte);
      {
      let v47_2_tail = v47_2_cursor.fork_read_zipper();
      let v47_2_head = Path::from_slice(&[v47_2_byte]);
      let v48_2: Path = concat_path(&(v46_13_head),&(v47_2_head));
      let mut v48_3 = Space::new();
      let mut v48_3_cursor = (v47_2_tail).read_zipper();
      for v48_3_byte in v48_3_cursor.child_mask().iter() {
        v48_3_cursor.descend_to_byte(v48_3_byte);
        {
        let v48_3_tail = v48_3_cursor.fork_read_zipper();
        let v48_3_head = Path::from_slice(&[v48_3_byte]);
        let v49_2: Path = concat_path(&(v48_2),&(v48_3_head));
        let mut v49_3 = Space::new();
        let mut v49_3_cursor = (v48_3_tail).read_zipper();
        for v49_3_byte in v49_3_cursor.child_mask().iter() {
          v49_3_cursor.descend_to_byte(v49_3_byte);
          {
          let v49_3_tail = v49_3_cursor.fork_read_zipper();
          let v49_3_head = Path::from_slice(&[v49_3_byte]);
          let v50_2: Path = concat_path(&(v49_2),&(v49_3_head));
          let mut v50_3 = Space::new();
          let mut v50_3_cursor = (v49_3_tail).read_zipper();
          for v50_3_byte in v50_3_cursor.child_mask().iter() {
            v50_3_cursor.descend_to_byte(v50_3_byte);
            {
            let v50_3_tail = v50_3_cursor.fork_read_zipper();
            let v50_3_head = Path::from_slice(&[v50_3_byte]);
            let mut v51_2 = Space::new();
            let mut v51_2_cursor = (v50_3_tail).read_zipper();
            for v51_2_byte in v51_2_cursor.child_mask().iter() {
              v51_2_cursor.descend_to_byte(v51_2_byte);
              {
              let v51_2_tail = v51_2_cursor.fork_read_zipper();
              let v51_2_head = Path::from_slice(&[v51_2_byte]);
              let v52_2: Path = concat_path(&(v50_3_head),&(v51_2_head));
              let mut v52_3 = Space::new();
              let mut v52_3_cursor = (v51_2_tail).read_zipper();
              for v52_3_byte in v52_3_cursor.child_mask().iter() {
                v52_3_cursor.descend_to_byte(v52_3_byte);
                {
                let v52_3_tail = v52_3_cursor.fork_read_zipper();
                let v52_3_head = Path::from_slice(&[v52_3_byte]);
                let v53_2: Path = concat_path(&(v52_2),&(v52_3_head));
                let mut v53_3 = Space::new();
                let mut v53_3_cursor = (v52_3_tail).read_zipper();
                for v53_3_byte in v53_3_cursor.child_mask().iter() {
                  v53_3_cursor.descend_to_byte(v53_3_byte);
                  {
                  let v53_3_tail = v53_3_cursor.fork_read_zipper();
                  let v53_3_head = Path::from_slice(&[v53_3_byte]);
                  let v54_2: Path = concat_path(&(v53_2),&(v53_3_head));
                  let v54_3: Space = routine_7(c, &(v54_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p0), &(v50_2), &(v53_3_tail).make_space());
                  drop(v54_2);
                  v53_3.join_into((v54_3).clone());
                  }
                  v53_3_cursor.ascend(1);
                }
                drop(v53_3_cursor);
                drop(v53_2);
                v52_3.join_into((v53_3).clone());
                }
                v52_3_cursor.ascend(1);
              }
              drop(v52_3_cursor);
              drop(v52_2);
              v51_2.join_into((v52_3).clone());
              }
              v51_2_cursor.ascend(1);
            }
            drop(v51_2_cursor);
            v50_3.join_into((v51_2).clone());
            }
            v50_3_cursor.ascend(1);
          }
          drop(v50_3_cursor);
          drop(v50_2);
          v49_3.join_into((v50_3).clone());
          }
          v49_3_cursor.ascend(1);
        }
        drop(v49_3_cursor);
        drop(v49_2);
        v48_3.join_into((v49_3).clone());
        }
        v48_3_cursor.ascend(1);
      }
      drop(v48_3_cursor);
      drop(v48_2);
      v47_2.join_into((v48_3).clone());
      }
      v47_2_cursor.ascend(1);
    }
    drop(v47_2_cursor);
    v46_13.join_into((v47_2).clone());
    }
    v46_13_cursor.ascend(1);
  }
  drop(v46_13_cursor);
  (v46_13).clone()
}

fn routine_7(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, s0: &Space) -> Space {
  let mut v55_15 = Space::new();
  let mut v55_15_cursor = (*s0).read_zipper();
  for v55_15_byte in v55_15_cursor.child_mask().iter() {
    v55_15_cursor.descend_to_byte(v55_15_byte);
    {
    let v55_15_tail = v55_15_cursor.fork_read_zipper();
    let v55_15_head = Path::from_slice(&[v55_15_byte]);
    let mut v56_2 = Space::new();
    let mut v56_2_cursor = (v55_15_tail).read_zipper();
    for v56_2_byte in v56_2_cursor.child_mask().iter() {
      v56_2_cursor.descend_to_byte(v56_2_byte);
      {
      let v56_2_tail = v56_2_cursor.fork_read_zipper();
      let v56_2_head = Path::from_slice(&[v56_2_byte]);
      let v57_2: Path = concat_path(&(v55_15_head),&(v56_2_head));
      let mut v57_3 = Space::new();
      let mut v57_3_cursor = (v56_2_tail).read_zipper();
      for v57_3_byte in v57_3_cursor.child_mask().iter() {
        v57_3_cursor.descend_to_byte(v57_3_byte);
        {
        let v57_3_tail = v57_3_cursor.fork_read_zipper();
        let v57_3_head = Path::from_slice(&[v57_3_byte]);
        let v58_2: Path = concat_path(&(v57_2),&(v57_3_head));
        let mut v58_3 = Space::new();
        let mut v58_3_cursor = (v57_3_tail).read_zipper();
        for v58_3_byte in v58_3_cursor.child_mask().iter() {
          v58_3_cursor.descend_to_byte(v58_3_byte);
          {
          let v58_3_tail = v58_3_cursor.fork_read_zipper();
          let v58_3_head = Path::from_slice(&[v58_3_byte]);
          let v59_2: Path = concat_path(&(v58_2),&(v58_3_head));
          let mut v59_3 = Space::new();
          let mut v59_3_cursor = (v58_3_tail).read_zipper();
          for v59_3_byte in v59_3_cursor.child_mask().iter() {
            v59_3_cursor.descend_to_byte(v59_3_byte);
            {
            let v59_3_tail = v59_3_cursor.fork_read_zipper();
            let v59_3_head = Path::from_slice(&[v59_3_byte]);
            let mut v60_2 = Space::new();
            let mut v60_2_cursor = (v59_3_tail).read_zipper();
            for v60_2_byte in v60_2_cursor.child_mask().iter() {
              v60_2_cursor.descend_to_byte(v60_2_byte);
              {
              let v60_2_tail = v60_2_cursor.fork_read_zipper();
              let v60_2_head = Path::from_slice(&[v60_2_byte]);
              let v61_2: Path = concat_path(&(v59_3_head),&(v60_2_head));
              let mut v61_3 = Space::new();
              let mut v61_3_cursor = (v60_2_tail).read_zipper();
              for v61_3_byte in v61_3_cursor.child_mask().iter() {
                v61_3_cursor.descend_to_byte(v61_3_byte);
                {
                let v61_3_tail = v61_3_cursor.fork_read_zipper();
                let v61_3_head = Path::from_slice(&[v61_3_byte]);
                let v62_2: Path = concat_path(&(v61_2),&(v61_3_head));
                let mut v62_3 = Space::new();
                let mut v62_3_cursor = (v61_3_tail).read_zipper();
                for v62_3_byte in v62_3_cursor.child_mask().iter() {
                  v62_3_cursor.descend_to_byte(v62_3_byte);
                  {
                  let v62_3_tail = v62_3_cursor.fork_read_zipper();
                  let v62_3_head = Path::from_slice(&[v62_3_byte]);
                  let v63_2: Path = concat_path(&(v62_2),&(v62_3_head));
                  let v63_3: Space = routine_8(c, &(v63_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p13), &(*p0), &(v59_2), &(v62_3_tail).make_space());
                  drop(v63_2);
                  v62_3.join_into((v63_3).clone());
                  }
                  v62_3_cursor.ascend(1);
                }
                drop(v62_3_cursor);
                drop(v62_2);
                v61_3.join_into((v62_3).clone());
                }
                v61_3_cursor.ascend(1);
              }
              drop(v61_3_cursor);
              drop(v61_2);
              v60_2.join_into((v61_3).clone());
              }
              v60_2_cursor.ascend(1);
            }
            drop(v60_2_cursor);
            v59_3.join_into((v60_2).clone());
            }
            v59_3_cursor.ascend(1);
          }
          drop(v59_3_cursor);
          drop(v59_2);
          v58_3.join_into((v59_3).clone());
          }
          v58_3_cursor.ascend(1);
        }
        drop(v58_3_cursor);
        drop(v58_2);
        v57_3.join_into((v58_3).clone());
        }
        v57_3_cursor.ascend(1);
      }
      drop(v57_3_cursor);
      drop(v57_2);
      v56_2.join_into((v57_3).clone());
      }
      v56_2_cursor.ascend(1);
    }
    drop(v56_2_cursor);
    v55_15.join_into((v56_2).clone());
    }
    v55_15_cursor.ascend(1);
  }
  drop(v55_15_cursor);
  (v55_15).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, p15: &Path, s0: &Space) -> Space {
  let (v64_18,v64_20,v64_37,v64_40,v64_42,v64_43,v64_46,v64_48,v64_49,v64_52,v64_54,v64_55,v64_58,v64_60,v64_61,v64_64,v64_66,) = native_block_0(c, p0, p1, p10, p11, p12, p13, p14, p15, p2, p3, p4, p5, p6, p7, p8, p9);
  let (v64_100,v64_102,v64_67,v64_70,v64_72,v64_73,v64_76,v64_78,v64_79,v64_82,v64_84,v64_85,v64_88,v64_90,v64_91,v64_94,v64_96,v64_97,) = native_block_1(c, p0, p10, p11, p12, p13, p14, p15, p2, p3, p4, p5, p6, p7, p8, p9, &v64_18, &v64_61, &v64_66);
  let (v64_103,v64_106,v64_108,v64_109,v64_112,v64_114,v64_115,v64_118,v64_120,v64_121,v64_124,v64_126,v64_127,v64_160,v64_177,) = native_block_2(c, p0, p1, p10, p11, p12, p13, p14, p15, p2, p3, p4, p5, p6, p7, p8, p9, &v64_102, &v64_18, &v64_97);
  drop(v64_18);
  (v64_177).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v226_2 = Space::new();
  let mut v226_2_cursor = (*s0).read_zipper();
  for v226_2_byte in v226_2_cursor.child_mask().iter() {
    v226_2_cursor.descend_to_byte(v226_2_byte);
    {
    let v226_2_tail = v226_2_cursor.fork_read_zipper();
    let v226_2_head = Path::from_slice(&[v226_2_byte]);
    let mut v227_2 = Space::new();
    let mut v227_2_cursor = (v226_2_tail).read_zipper();
    for v227_2_byte in v227_2_cursor.child_mask().iter() {
      v227_2_cursor.descend_to_byte(v227_2_byte);
      {
      let v227_2_tail = v227_2_cursor.fork_read_zipper();
      let v227_2_head = Path::from_slice(&[v227_2_byte]);
      let v228_2: Path = concat_path(&(v226_2_head),&(v227_2_head));
      let mut v228_3 = Space::new();
      let mut v228_3_cursor = (v227_2_tail).read_zipper();
      for v228_3_byte in v228_3_cursor.child_mask().iter() {
        v228_3_cursor.descend_to_byte(v228_3_byte);
        {
        let v228_3_tail = v228_3_cursor.fork_read_zipper();
        let v228_3_head = Path::from_slice(&[v228_3_byte]);
        let v229_2: Path = concat_path(&(v228_2),&(v228_3_head));
        let mut v229_3 = Space::new();
        let mut v229_3_cursor = (v228_3_tail).read_zipper();
        for v229_3_byte in v229_3_cursor.child_mask().iter() {
          v229_3_cursor.descend_to_byte(v229_3_byte);
          {
          let v229_3_tail = v229_3_cursor.fork_read_zipper();
          let v229_3_head = Path::from_slice(&[v229_3_byte]);
          let v230_2: Path = concat_path(&(v229_2),&(v229_3_head));
          let mut v230_3 = Space::new();
          let mut v230_3_cursor = (v229_3_tail).read_zipper();
          for v230_3_byte in v230_3_cursor.child_mask().iter() {
            v230_3_cursor.descend_to_byte(v230_3_byte);
            {
            let v230_3_tail = v230_3_cursor.fork_read_zipper();
            let v230_3_head = Path::from_slice(&[v230_3_byte]);
            let mut v231_2 = Space::new();
            let mut v231_2_cursor = (v230_3_tail).read_zipper();
            for v231_2_byte in v231_2_cursor.child_mask().iter() {
              v231_2_cursor.descend_to_byte(v231_2_byte);
              {
              let v231_2_tail = v231_2_cursor.fork_read_zipper();
              let v231_2_head = Path::from_slice(&[v231_2_byte]);
              let v232_2: Path = concat_path(&(v230_3_head),&(v231_2_head));
              let mut v232_3 = Space::new();
              let mut v232_3_cursor = (v231_2_tail).read_zipper();
              for v232_3_byte in v232_3_cursor.child_mask().iter() {
                v232_3_cursor.descend_to_byte(v232_3_byte);
                {
                let v232_3_tail = v232_3_cursor.fork_read_zipper();
                let v232_3_head = Path::from_slice(&[v232_3_byte]);
                let v233_2: Path = concat_path(&(v232_2),&(v232_3_head));
                let mut v233_3 = Space::new();
                let mut v233_3_cursor = (v232_3_tail).read_zipper();
                for v233_3_byte in v233_3_cursor.child_mask().iter() {
                  v233_3_cursor.descend_to_byte(v233_3_byte);
                  {
                  let v233_3_tail = v233_3_cursor.fork_read_zipper();
                  let v233_3_head = Path::from_slice(&[v233_3_byte]);
                  let v234_2: Path = concat_path(&(v233_2),&(v233_3_head));
                  let v234_3: Space = routine_45(c, &(v234_2), &(*p0), &(v230_2), &(v233_3_tail).make_space());
                  drop(v234_2);
                  v233_3.join_into((v234_3).clone());
                  }
                  v233_3_cursor.ascend(1);
                }
                drop(v233_3_cursor);
                drop(v233_2);
                v232_3.join_into((v233_3).clone());
                }
                v232_3_cursor.ascend(1);
              }
              drop(v232_3_cursor);
              drop(v232_2);
              v231_2.join_into((v232_3).clone());
              }
              v231_2_cursor.ascend(1);
            }
            drop(v231_2_cursor);
            v230_3.join_into((v231_2).clone());
            }
            v230_3_cursor.ascend(1);
          }
          drop(v230_3_cursor);
          drop(v230_2);
          v229_3.join_into((v230_3).clone());
          }
          v229_3_cursor.ascend(1);
        }
        drop(v229_3_cursor);
        drop(v229_2);
        v228_3.join_into((v229_3).clone());
        }
        v228_3_cursor.ascend(1);
      }
      drop(v228_3_cursor);
      drop(v228_2);
      v227_2.join_into((v228_3).clone());
      }
      v227_2_cursor.ascend(1);
    }
    drop(v227_2_cursor);
    v226_2.join_into((v227_2).clone());
    }
    v226_2_cursor.ascend(1);
  }
  drop(v226_2_cursor);
  (v226_2).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v236_2 = Space::new();
  let mut v236_2_cursor = (*s0).read_zipper();
  for v236_2_byte in v236_2_cursor.child_mask().iter() {
    v236_2_cursor.descend_to_byte(v236_2_byte);
    {
    let v236_2_tail = v236_2_cursor.fork_read_zipper();
    let v236_2_head = Path::from_slice(&[v236_2_byte]);
    let mut v237_2 = Space::new();
    let mut v237_2_cursor = (v236_2_tail).read_zipper();
    for v237_2_byte in v237_2_cursor.child_mask().iter() {
      v237_2_cursor.descend_to_byte(v237_2_byte);
      {
      let v237_2_tail = v237_2_cursor.fork_read_zipper();
      let v237_2_head = Path::from_slice(&[v237_2_byte]);
      let v238_2: Path = concat_path(&(v236_2_head),&(v237_2_head));
      let mut v238_3 = Space::new();
      let mut v238_3_cursor = (v237_2_tail).read_zipper();
      for v238_3_byte in v238_3_cursor.child_mask().iter() {
        v238_3_cursor.descend_to_byte(v238_3_byte);
        {
        let v238_3_tail = v238_3_cursor.fork_read_zipper();
        let v238_3_head = Path::from_slice(&[v238_3_byte]);
        let v239_2: Path = concat_path(&(v238_2),&(v238_3_head));
        let mut v239_3 = Space::new();
        let mut v239_3_cursor = (v238_3_tail).read_zipper();
        for v239_3_byte in v239_3_cursor.child_mask().iter() {
          v239_3_cursor.descend_to_byte(v239_3_byte);
          {
          let v239_3_tail = v239_3_cursor.fork_read_zipper();
          let v239_3_head = Path::from_slice(&[v239_3_byte]);
          let v240_2: Path = concat_path(&(v239_2),&(v239_3_head));
          let mut v240_3 = Space::new();
          let mut v240_3_cursor = (v239_3_tail).read_zipper();
          for v240_3_byte in v240_3_cursor.child_mask().iter() {
            v240_3_cursor.descend_to_byte(v240_3_byte);
            {
            let v240_3_tail = v240_3_cursor.fork_read_zipper();
            let v240_3_head = Path::from_slice(&[v240_3_byte]);
            let mut v241_2 = Space::new();
            let mut v241_2_cursor = (v240_3_tail).read_zipper();
            for v241_2_byte in v241_2_cursor.child_mask().iter() {
              v241_2_cursor.descend_to_byte(v241_2_byte);
              {
              let v241_2_tail = v241_2_cursor.fork_read_zipper();
              let v241_2_head = Path::from_slice(&[v241_2_byte]);
              let v242_2: Path = concat_path(&(v240_3_head),&(v241_2_head));
              let mut v242_3 = Space::new();
              let mut v242_3_cursor = (v241_2_tail).read_zipper();
              for v242_3_byte in v242_3_cursor.child_mask().iter() {
                v242_3_cursor.descend_to_byte(v242_3_byte);
                {
                let v242_3_tail = v242_3_cursor.fork_read_zipper();
                let v242_3_head = Path::from_slice(&[v242_3_byte]);
                let v243_2: Path = concat_path(&(v242_2),&(v242_3_head));
                let mut v243_3 = Space::new();
                let mut v243_3_cursor = (v242_3_tail).read_zipper();
                for v243_3_byte in v243_3_cursor.child_mask().iter() {
                  v243_3_cursor.descend_to_byte(v243_3_byte);
                  {
                  let v243_3_tail = v243_3_cursor.fork_read_zipper();
                  let v243_3_head = Path::from_slice(&[v243_3_byte]);
                  let v244_2: Path = concat_path(&(v243_2),&(v243_3_head));
                  let v244_3: Space = routine_46(c, &(v244_2), &(*p0), &(v240_2), &(v243_3_tail).make_space());
                  drop(v244_2);
                  v243_3.join_into((v244_3).clone());
                  }
                  v243_3_cursor.ascend(1);
                }
                drop(v243_3_cursor);
                drop(v243_2);
                v242_3.join_into((v243_3).clone());
                }
                v242_3_cursor.ascend(1);
              }
              drop(v242_3_cursor);
              drop(v242_2);
              v241_2.join_into((v242_3).clone());
              }
              v241_2_cursor.ascend(1);
            }
            drop(v241_2_cursor);
            v240_3.join_into((v241_2).clone());
            }
            v240_3_cursor.ascend(1);
          }
          drop(v240_3_cursor);
          drop(v240_2);
          v239_3.join_into((v240_3).clone());
          }
          v239_3_cursor.ascend(1);
        }
        drop(v239_3_cursor);
        drop(v239_2);
        v238_3.join_into((v239_3).clone());
        }
        v238_3_cursor.ascend(1);
      }
      drop(v238_3_cursor);
      drop(v238_2);
      v237_2.join_into((v238_3).clone());
      }
      v237_2_cursor.ascend(1);
    }
    drop(v237_2_cursor);
    v236_2.join_into((v237_2).clone());
    }
    v236_2_cursor.ascend(1);
  }
  drop(v236_2_cursor);
  (v236_2).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v246_2 = Space::new();
  let mut v246_2_cursor = (*s0).read_zipper();
  for v246_2_byte in v246_2_cursor.child_mask().iter() {
    v246_2_cursor.descend_to_byte(v246_2_byte);
    {
    let v246_2_tail = v246_2_cursor.fork_read_zipper();
    let v246_2_head = Path::from_slice(&[v246_2_byte]);
    let mut v247_2 = Space::new();
    let mut v247_2_cursor = (v246_2_tail).read_zipper();
    for v247_2_byte in v247_2_cursor.child_mask().iter() {
      v247_2_cursor.descend_to_byte(v247_2_byte);
      {
      let v247_2_tail = v247_2_cursor.fork_read_zipper();
      let v247_2_head = Path::from_slice(&[v247_2_byte]);
      let v248_2: Path = concat_path(&(v246_2_head),&(v247_2_head));
      let mut v248_3 = Space::new();
      let mut v248_3_cursor = (v247_2_tail).read_zipper();
      for v248_3_byte in v248_3_cursor.child_mask().iter() {
        v248_3_cursor.descend_to_byte(v248_3_byte);
        {
        let v248_3_tail = v248_3_cursor.fork_read_zipper();
        let v248_3_head = Path::from_slice(&[v248_3_byte]);
        let v249_2: Path = concat_path(&(v248_2),&(v248_3_head));
        let mut v249_3 = Space::new();
        let mut v249_3_cursor = (v248_3_tail).read_zipper();
        for v249_3_byte in v249_3_cursor.child_mask().iter() {
          v249_3_cursor.descend_to_byte(v249_3_byte);
          {
          let v249_3_tail = v249_3_cursor.fork_read_zipper();
          let v249_3_head = Path::from_slice(&[v249_3_byte]);
          let v250_2: Path = concat_path(&(v249_2),&(v249_3_head));
          let mut v250_3 = Space::new();
          let mut v250_3_cursor = (v249_3_tail).read_zipper();
          for v250_3_byte in v250_3_cursor.child_mask().iter() {
            v250_3_cursor.descend_to_byte(v250_3_byte);
            {
            let v250_3_tail = v250_3_cursor.fork_read_zipper();
            let v250_3_head = Path::from_slice(&[v250_3_byte]);
            let mut v251_2 = Space::new();
            let mut v251_2_cursor = (v250_3_tail).read_zipper();
            for v251_2_byte in v251_2_cursor.child_mask().iter() {
              v251_2_cursor.descend_to_byte(v251_2_byte);
              {
              let v251_2_tail = v251_2_cursor.fork_read_zipper();
              let v251_2_head = Path::from_slice(&[v251_2_byte]);
              let v252_2: Path = concat_path(&(v250_3_head),&(v251_2_head));
              let mut v252_3 = Space::new();
              let mut v252_3_cursor = (v251_2_tail).read_zipper();
              for v252_3_byte in v252_3_cursor.child_mask().iter() {
                v252_3_cursor.descend_to_byte(v252_3_byte);
                {
                let v252_3_tail = v252_3_cursor.fork_read_zipper();
                let v252_3_head = Path::from_slice(&[v252_3_byte]);
                let v253_2: Path = concat_path(&(v252_2),&(v252_3_head));
                let mut v253_3 = Space::new();
                let mut v253_3_cursor = (v252_3_tail).read_zipper();
                for v253_3_byte in v253_3_cursor.child_mask().iter() {
                  v253_3_cursor.descend_to_byte(v253_3_byte);
                  {
                  let v253_3_tail = v253_3_cursor.fork_read_zipper();
                  let v253_3_head = Path::from_slice(&[v253_3_byte]);
                  let v254_2: Path = concat_path(&(v253_2),&(v253_3_head));
                  let v254_3: Space = routine_47(c, &(v254_2), &(*p0), &(v250_2), &(v253_3_tail).make_space());
                  drop(v254_2);
                  v253_3.join_into((v254_3).clone());
                  }
                  v253_3_cursor.ascend(1);
                }
                drop(v253_3_cursor);
                drop(v253_2);
                v252_3.join_into((v253_3).clone());
                }
                v252_3_cursor.ascend(1);
              }
              drop(v252_3_cursor);
              drop(v252_2);
              v251_2.join_into((v252_3).clone());
              }
              v251_2_cursor.ascend(1);
            }
            drop(v251_2_cursor);
            v250_3.join_into((v251_2).clone());
            }
            v250_3_cursor.ascend(1);
          }
          drop(v250_3_cursor);
          drop(v250_2);
          v249_3.join_into((v250_3).clone());
          }
          v249_3_cursor.ascend(1);
        }
        drop(v249_3_cursor);
        drop(v249_2);
        v248_3.join_into((v249_3).clone());
        }
        v248_3_cursor.ascend(1);
      }
      drop(v248_3_cursor);
      drop(v248_2);
      v247_2.join_into((v248_3).clone());
      }
      v247_2_cursor.ascend(1);
    }
    drop(v247_2_cursor);
    v246_2.join_into((v247_2).clone());
    }
    v246_2_cursor.ascend(1);
  }
  drop(v246_2_cursor);
  (v246_2).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v256_2 = Space::new();
  let mut v256_2_cursor = (*s0).read_zipper();
  for v256_2_byte in v256_2_cursor.child_mask().iter() {
    v256_2_cursor.descend_to_byte(v256_2_byte);
    {
    let v256_2_tail = v256_2_cursor.fork_read_zipper();
    let v256_2_head = Path::from_slice(&[v256_2_byte]);
    let mut v257_2 = Space::new();
    let mut v257_2_cursor = (v256_2_tail).read_zipper();
    for v257_2_byte in v257_2_cursor.child_mask().iter() {
      v257_2_cursor.descend_to_byte(v257_2_byte);
      {
      let v257_2_tail = v257_2_cursor.fork_read_zipper();
      let v257_2_head = Path::from_slice(&[v257_2_byte]);
      let v258_2: Path = concat_path(&(v256_2_head),&(v257_2_head));
      let mut v258_3 = Space::new();
      let mut v258_3_cursor = (v257_2_tail).read_zipper();
      for v258_3_byte in v258_3_cursor.child_mask().iter() {
        v258_3_cursor.descend_to_byte(v258_3_byte);
        {
        let v258_3_tail = v258_3_cursor.fork_read_zipper();
        let v258_3_head = Path::from_slice(&[v258_3_byte]);
        let v259_2: Path = concat_path(&(v258_2),&(v258_3_head));
        let mut v259_3 = Space::new();
        let mut v259_3_cursor = (v258_3_tail).read_zipper();
        for v259_3_byte in v259_3_cursor.child_mask().iter() {
          v259_3_cursor.descend_to_byte(v259_3_byte);
          {
          let v259_3_tail = v259_3_cursor.fork_read_zipper();
          let v259_3_head = Path::from_slice(&[v259_3_byte]);
          let v260_2: Path = concat_path(&(v259_2),&(v259_3_head));
          let mut v260_3 = Space::new();
          let mut v260_3_cursor = (v259_3_tail).read_zipper();
          for v260_3_byte in v260_3_cursor.child_mask().iter() {
            v260_3_cursor.descend_to_byte(v260_3_byte);
            {
            let v260_3_tail = v260_3_cursor.fork_read_zipper();
            let v260_3_head = Path::from_slice(&[v260_3_byte]);
            let mut v261_2 = Space::new();
            let mut v261_2_cursor = (v260_3_tail).read_zipper();
            for v261_2_byte in v261_2_cursor.child_mask().iter() {
              v261_2_cursor.descend_to_byte(v261_2_byte);
              {
              let v261_2_tail = v261_2_cursor.fork_read_zipper();
              let v261_2_head = Path::from_slice(&[v261_2_byte]);
              let v262_2: Path = concat_path(&(v260_3_head),&(v261_2_head));
              let mut v262_3 = Space::new();
              let mut v262_3_cursor = (v261_2_tail).read_zipper();
              for v262_3_byte in v262_3_cursor.child_mask().iter() {
                v262_3_cursor.descend_to_byte(v262_3_byte);
                {
                let v262_3_tail = v262_3_cursor.fork_read_zipper();
                let v262_3_head = Path::from_slice(&[v262_3_byte]);
                let v263_2: Path = concat_path(&(v262_2),&(v262_3_head));
                let mut v263_3 = Space::new();
                let mut v263_3_cursor = (v262_3_tail).read_zipper();
                for v263_3_byte in v263_3_cursor.child_mask().iter() {
                  v263_3_cursor.descend_to_byte(v263_3_byte);
                  {
                  let v263_3_tail = v263_3_cursor.fork_read_zipper();
                  let v263_3_head = Path::from_slice(&[v263_3_byte]);
                  let v264_2: Path = concat_path(&(v263_2),&(v263_3_head));
                  let v264_3: Space = routine_48(c, &(v264_2), &(*p0), &(v260_2), &(v263_3_tail).make_space());
                  drop(v264_2);
                  v263_3.join_into((v264_3).clone());
                  }
                  v263_3_cursor.ascend(1);
                }
                drop(v263_3_cursor);
                drop(v263_2);
                v262_3.join_into((v263_3).clone());
                }
                v262_3_cursor.ascend(1);
              }
              drop(v262_3_cursor);
              drop(v262_2);
              v261_2.join_into((v262_3).clone());
              }
              v261_2_cursor.ascend(1);
            }
            drop(v261_2_cursor);
            v260_3.join_into((v261_2).clone());
            }
            v260_3_cursor.ascend(1);
          }
          drop(v260_3_cursor);
          drop(v260_2);
          v259_3.join_into((v260_3).clone());
          }
          v259_3_cursor.ascend(1);
        }
        drop(v259_3_cursor);
        drop(v259_2);
        v258_3.join_into((v259_3).clone());
        }
        v258_3_cursor.ascend(1);
      }
      drop(v258_3_cursor);
      drop(v258_2);
      v257_2.join_into((v258_3).clone());
      }
      v257_2_cursor.ascend(1);
    }
    drop(v257_2_cursor);
    v256_2.join_into((v257_2).clone());
    }
    v256_2_cursor.ascend(1);
  }
  drop(v256_2_cursor);
  (v256_2).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v266_2 = Space::new();
  let mut v266_2_cursor = (*s0).read_zipper();
  for v266_2_byte in v266_2_cursor.child_mask().iter() {
    v266_2_cursor.descend_to_byte(v266_2_byte);
    {
    let v266_2_tail = v266_2_cursor.fork_read_zipper();
    let v266_2_head = Path::from_slice(&[v266_2_byte]);
    let mut v267_2 = Space::new();
    let mut v267_2_cursor = (v266_2_tail).read_zipper();
    for v267_2_byte in v267_2_cursor.child_mask().iter() {
      v267_2_cursor.descend_to_byte(v267_2_byte);
      {
      let v267_2_tail = v267_2_cursor.fork_read_zipper();
      let v267_2_head = Path::from_slice(&[v267_2_byte]);
      let v268_2: Path = concat_path(&(v266_2_head),&(v267_2_head));
      let mut v268_3 = Space::new();
      let mut v268_3_cursor = (v267_2_tail).read_zipper();
      for v268_3_byte in v268_3_cursor.child_mask().iter() {
        v268_3_cursor.descend_to_byte(v268_3_byte);
        {
        let v268_3_tail = v268_3_cursor.fork_read_zipper();
        let v268_3_head = Path::from_slice(&[v268_3_byte]);
        let v269_2: Path = concat_path(&(v268_2),&(v268_3_head));
        let mut v269_3 = Space::new();
        let mut v269_3_cursor = (v268_3_tail).read_zipper();
        for v269_3_byte in v269_3_cursor.child_mask().iter() {
          v269_3_cursor.descend_to_byte(v269_3_byte);
          {
          let v269_3_tail = v269_3_cursor.fork_read_zipper();
          let v269_3_head = Path::from_slice(&[v269_3_byte]);
          let v270_2: Path = concat_path(&(v269_2),&(v269_3_head));
          let mut v270_3 = Space::new();
          let mut v270_3_cursor = (v269_3_tail).read_zipper();
          for v270_3_byte in v270_3_cursor.child_mask().iter() {
            v270_3_cursor.descend_to_byte(v270_3_byte);
            {
            let v270_3_tail = v270_3_cursor.fork_read_zipper();
            let v270_3_head = Path::from_slice(&[v270_3_byte]);
            let mut v271_2 = Space::new();
            let mut v271_2_cursor = (v270_3_tail).read_zipper();
            for v271_2_byte in v271_2_cursor.child_mask().iter() {
              v271_2_cursor.descend_to_byte(v271_2_byte);
              {
              let v271_2_tail = v271_2_cursor.fork_read_zipper();
              let v271_2_head = Path::from_slice(&[v271_2_byte]);
              let v272_2: Path = concat_path(&(v270_3_head),&(v271_2_head));
              let mut v272_3 = Space::new();
              let mut v272_3_cursor = (v271_2_tail).read_zipper();
              for v272_3_byte in v272_3_cursor.child_mask().iter() {
                v272_3_cursor.descend_to_byte(v272_3_byte);
                {
                let v272_3_tail = v272_3_cursor.fork_read_zipper();
                let v272_3_head = Path::from_slice(&[v272_3_byte]);
                let v273_2: Path = concat_path(&(v272_2),&(v272_3_head));
                let mut v273_3 = Space::new();
                let mut v273_3_cursor = (v272_3_tail).read_zipper();
                for v273_3_byte in v273_3_cursor.child_mask().iter() {
                  v273_3_cursor.descend_to_byte(v273_3_byte);
                  {
                  let v273_3_tail = v273_3_cursor.fork_read_zipper();
                  let v273_3_head = Path::from_slice(&[v273_3_byte]);
                  let v274_2: Path = concat_path(&(v273_2),&(v273_3_head));
                  let v274_3: Space = routine_49(c, &(v274_2), &(*p0), &(v270_2), &(v273_3_tail).make_space());
                  drop(v274_2);
                  v273_3.join_into((v274_3).clone());
                  }
                  v273_3_cursor.ascend(1);
                }
                drop(v273_3_cursor);
                drop(v273_2);
                v272_3.join_into((v273_3).clone());
                }
                v272_3_cursor.ascend(1);
              }
              drop(v272_3_cursor);
              drop(v272_2);
              v271_2.join_into((v272_3).clone());
              }
              v271_2_cursor.ascend(1);
            }
            drop(v271_2_cursor);
            v270_3.join_into((v271_2).clone());
            }
            v270_3_cursor.ascend(1);
          }
          drop(v270_3_cursor);
          drop(v270_2);
          v269_3.join_into((v270_3).clone());
          }
          v269_3_cursor.ascend(1);
        }
        drop(v269_3_cursor);
        drop(v269_2);
        v268_3.join_into((v269_3).clone());
        }
        v268_3_cursor.ascend(1);
      }
      drop(v268_3_cursor);
      drop(v268_2);
      v267_2.join_into((v268_3).clone());
      }
      v267_2_cursor.ascend(1);
    }
    drop(v267_2_cursor);
    v266_2.join_into((v267_2).clone());
    }
    v266_2_cursor.ascend(1);
  }
  drop(v266_2_cursor);
  (v266_2).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v276_2 = Space::new();
  let mut v276_2_cursor = (*s0).read_zipper();
  for v276_2_byte in v276_2_cursor.child_mask().iter() {
    v276_2_cursor.descend_to_byte(v276_2_byte);
    {
    let v276_2_tail = v276_2_cursor.fork_read_zipper();
    let v276_2_head = Path::from_slice(&[v276_2_byte]);
    let mut v277_2 = Space::new();
    let mut v277_2_cursor = (v276_2_tail).read_zipper();
    for v277_2_byte in v277_2_cursor.child_mask().iter() {
      v277_2_cursor.descend_to_byte(v277_2_byte);
      {
      let v277_2_tail = v277_2_cursor.fork_read_zipper();
      let v277_2_head = Path::from_slice(&[v277_2_byte]);
      let v278_2: Path = concat_path(&(v276_2_head),&(v277_2_head));
      let mut v278_3 = Space::new();
      let mut v278_3_cursor = (v277_2_tail).read_zipper();
      for v278_3_byte in v278_3_cursor.child_mask().iter() {
        v278_3_cursor.descend_to_byte(v278_3_byte);
        {
        let v278_3_tail = v278_3_cursor.fork_read_zipper();
        let v278_3_head = Path::from_slice(&[v278_3_byte]);
        let v279_2: Path = concat_path(&(v278_2),&(v278_3_head));
        let mut v279_3 = Space::new();
        let mut v279_3_cursor = (v278_3_tail).read_zipper();
        for v279_3_byte in v279_3_cursor.child_mask().iter() {
          v279_3_cursor.descend_to_byte(v279_3_byte);
          {
          let v279_3_tail = v279_3_cursor.fork_read_zipper();
          let v279_3_head = Path::from_slice(&[v279_3_byte]);
          let v280_2: Path = concat_path(&(v279_2),&(v279_3_head));
          let mut v280_3 = Space::new();
          let mut v280_3_cursor = (v279_3_tail).read_zipper();
          for v280_3_byte in v280_3_cursor.child_mask().iter() {
            v280_3_cursor.descend_to_byte(v280_3_byte);
            {
            let v280_3_tail = v280_3_cursor.fork_read_zipper();
            let v280_3_head = Path::from_slice(&[v280_3_byte]);
            let mut v281_2 = Space::new();
            let mut v281_2_cursor = (v280_3_tail).read_zipper();
            for v281_2_byte in v281_2_cursor.child_mask().iter() {
              v281_2_cursor.descend_to_byte(v281_2_byte);
              {
              let v281_2_tail = v281_2_cursor.fork_read_zipper();
              let v281_2_head = Path::from_slice(&[v281_2_byte]);
              let v282_2: Path = concat_path(&(v280_3_head),&(v281_2_head));
              let mut v282_3 = Space::new();
              let mut v282_3_cursor = (v281_2_tail).read_zipper();
              for v282_3_byte in v282_3_cursor.child_mask().iter() {
                v282_3_cursor.descend_to_byte(v282_3_byte);
                {
                let v282_3_tail = v282_3_cursor.fork_read_zipper();
                let v282_3_head = Path::from_slice(&[v282_3_byte]);
                let v283_2: Path = concat_path(&(v282_2),&(v282_3_head));
                let mut v283_3 = Space::new();
                let mut v283_3_cursor = (v282_3_tail).read_zipper();
                for v283_3_byte in v283_3_cursor.child_mask().iter() {
                  v283_3_cursor.descend_to_byte(v283_3_byte);
                  {
                  let v283_3_tail = v283_3_cursor.fork_read_zipper();
                  let v283_3_head = Path::from_slice(&[v283_3_byte]);
                  let v284_2: Path = concat_path(&(v283_2),&(v283_3_head));
                  let v284_3: Space = routine_50(c, &(v284_2), &(*p0), &(v280_2), &(v283_3_tail).make_space());
                  drop(v284_2);
                  v283_3.join_into((v284_3).clone());
                  }
                  v283_3_cursor.ascend(1);
                }
                drop(v283_3_cursor);
                drop(v283_2);
                v282_3.join_into((v283_3).clone());
                }
                v282_3_cursor.ascend(1);
              }
              drop(v282_3_cursor);
              drop(v282_2);
              v281_2.join_into((v282_3).clone());
              }
              v281_2_cursor.ascend(1);
            }
            drop(v281_2_cursor);
            v280_3.join_into((v281_2).clone());
            }
            v280_3_cursor.ascend(1);
          }
          drop(v280_3_cursor);
          drop(v280_2);
          v279_3.join_into((v280_3).clone());
          }
          v279_3_cursor.ascend(1);
        }
        drop(v279_3_cursor);
        drop(v279_2);
        v278_3.join_into((v279_3).clone());
        }
        v278_3_cursor.ascend(1);
      }
      drop(v278_3_cursor);
      drop(v278_2);
      v277_2.join_into((v278_3).clone());
      }
      v277_2_cursor.ascend(1);
    }
    drop(v277_2_cursor);
    v276_2.join_into((v277_2).clone());
    }
    v276_2_cursor.ascend(1);
  }
  drop(v276_2_cursor);
  (v276_2).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v286_2 = Space::new();
  let mut v286_2_cursor = (*s0).read_zipper();
  for v286_2_byte in v286_2_cursor.child_mask().iter() {
    v286_2_cursor.descend_to_byte(v286_2_byte);
    {
    let v286_2_tail = v286_2_cursor.fork_read_zipper();
    let v286_2_head = Path::from_slice(&[v286_2_byte]);
    let mut v287_2 = Space::new();
    let mut v287_2_cursor = (v286_2_tail).read_zipper();
    for v287_2_byte in v287_2_cursor.child_mask().iter() {
      v287_2_cursor.descend_to_byte(v287_2_byte);
      {
      let v287_2_tail = v287_2_cursor.fork_read_zipper();
      let v287_2_head = Path::from_slice(&[v287_2_byte]);
      let v288_2: Path = concat_path(&(v286_2_head),&(v287_2_head));
      let mut v288_3 = Space::new();
      let mut v288_3_cursor = (v287_2_tail).read_zipper();
      for v288_3_byte in v288_3_cursor.child_mask().iter() {
        v288_3_cursor.descend_to_byte(v288_3_byte);
        {
        let v288_3_tail = v288_3_cursor.fork_read_zipper();
        let v288_3_head = Path::from_slice(&[v288_3_byte]);
        let v289_2: Path = concat_path(&(v288_2),&(v288_3_head));
        let mut v289_3 = Space::new();
        let mut v289_3_cursor = (v288_3_tail).read_zipper();
        for v289_3_byte in v289_3_cursor.child_mask().iter() {
          v289_3_cursor.descend_to_byte(v289_3_byte);
          {
          let v289_3_tail = v289_3_cursor.fork_read_zipper();
          let v289_3_head = Path::from_slice(&[v289_3_byte]);
          let v290_2: Path = concat_path(&(v289_2),&(v289_3_head));
          let mut v290_3 = Space::new();
          let mut v290_3_cursor = (v289_3_tail).read_zipper();
          for v290_3_byte in v290_3_cursor.child_mask().iter() {
            v290_3_cursor.descend_to_byte(v290_3_byte);
            {
            let v290_3_tail = v290_3_cursor.fork_read_zipper();
            let v290_3_head = Path::from_slice(&[v290_3_byte]);
            let mut v291_2 = Space::new();
            let mut v291_2_cursor = (v290_3_tail).read_zipper();
            for v291_2_byte in v291_2_cursor.child_mask().iter() {
              v291_2_cursor.descend_to_byte(v291_2_byte);
              {
              let v291_2_tail = v291_2_cursor.fork_read_zipper();
              let v291_2_head = Path::from_slice(&[v291_2_byte]);
              let v292_2: Path = concat_path(&(v290_3_head),&(v291_2_head));
              let mut v292_3 = Space::new();
              let mut v292_3_cursor = (v291_2_tail).read_zipper();
              for v292_3_byte in v292_3_cursor.child_mask().iter() {
                v292_3_cursor.descend_to_byte(v292_3_byte);
                {
                let v292_3_tail = v292_3_cursor.fork_read_zipper();
                let v292_3_head = Path::from_slice(&[v292_3_byte]);
                let v293_2: Path = concat_path(&(v292_2),&(v292_3_head));
                let mut v293_3 = Space::new();
                let mut v293_3_cursor = (v292_3_tail).read_zipper();
                for v293_3_byte in v293_3_cursor.child_mask().iter() {
                  v293_3_cursor.descend_to_byte(v293_3_byte);
                  {
                  let v293_3_tail = v293_3_cursor.fork_read_zipper();
                  let v293_3_head = Path::from_slice(&[v293_3_byte]);
                  let v294_2: Path = concat_path(&(v293_2),&(v293_3_head));
                  let v294_3: Space = routine_51(c, &(v294_2), &(*p0), &(v290_2), &(v293_3_tail).make_space());
                  drop(v294_2);
                  v293_3.join_into((v294_3).clone());
                  }
                  v293_3_cursor.ascend(1);
                }
                drop(v293_3_cursor);
                drop(v293_2);
                v292_3.join_into((v293_3).clone());
                }
                v292_3_cursor.ascend(1);
              }
              drop(v292_3_cursor);
              drop(v292_2);
              v291_2.join_into((v292_3).clone());
              }
              v291_2_cursor.ascend(1);
            }
            drop(v291_2_cursor);
            v290_3.join_into((v291_2).clone());
            }
            v290_3_cursor.ascend(1);
          }
          drop(v290_3_cursor);
          drop(v290_2);
          v289_3.join_into((v290_3).clone());
          }
          v289_3_cursor.ascend(1);
        }
        drop(v289_3_cursor);
        drop(v289_2);
        v288_3.join_into((v289_3).clone());
        }
        v288_3_cursor.ascend(1);
      }
      drop(v288_3_cursor);
      drop(v288_2);
      v287_2.join_into((v288_3).clone());
      }
      v287_2_cursor.ascend(1);
    }
    drop(v287_2_cursor);
    v286_2.join_into((v287_2).clone());
    }
    v286_2_cursor.ascend(1);
  }
  drop(v286_2_cursor);
  (v286_2).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v296_2 = Space::new();
  let mut v296_2_cursor = (*s0).read_zipper();
  for v296_2_byte in v296_2_cursor.child_mask().iter() {
    v296_2_cursor.descend_to_byte(v296_2_byte);
    {
    let v296_2_tail = v296_2_cursor.fork_read_zipper();
    let v296_2_head = Path::from_slice(&[v296_2_byte]);
    let mut v297_2 = Space::new();
    let mut v297_2_cursor = (v296_2_tail).read_zipper();
    for v297_2_byte in v297_2_cursor.child_mask().iter() {
      v297_2_cursor.descend_to_byte(v297_2_byte);
      {
      let v297_2_tail = v297_2_cursor.fork_read_zipper();
      let v297_2_head = Path::from_slice(&[v297_2_byte]);
      let v298_2: Path = concat_path(&(v296_2_head),&(v297_2_head));
      let mut v298_3 = Space::new();
      let mut v298_3_cursor = (v297_2_tail).read_zipper();
      for v298_3_byte in v298_3_cursor.child_mask().iter() {
        v298_3_cursor.descend_to_byte(v298_3_byte);
        {
        let v298_3_tail = v298_3_cursor.fork_read_zipper();
        let v298_3_head = Path::from_slice(&[v298_3_byte]);
        let v299_2: Path = concat_path(&(v298_2),&(v298_3_head));
        let mut v299_3 = Space::new();
        let mut v299_3_cursor = (v298_3_tail).read_zipper();
        for v299_3_byte in v299_3_cursor.child_mask().iter() {
          v299_3_cursor.descend_to_byte(v299_3_byte);
          {
          let v299_3_tail = v299_3_cursor.fork_read_zipper();
          let v299_3_head = Path::from_slice(&[v299_3_byte]);
          let v300_2: Path = concat_path(&(v299_2),&(v299_3_head));
          let mut v300_3 = Space::new();
          let mut v300_3_cursor = (v299_3_tail).read_zipper();
          for v300_3_byte in v300_3_cursor.child_mask().iter() {
            v300_3_cursor.descend_to_byte(v300_3_byte);
            {
            let v300_3_tail = v300_3_cursor.fork_read_zipper();
            let v300_3_head = Path::from_slice(&[v300_3_byte]);
            let mut v301_2 = Space::new();
            let mut v301_2_cursor = (v300_3_tail).read_zipper();
            for v301_2_byte in v301_2_cursor.child_mask().iter() {
              v301_2_cursor.descend_to_byte(v301_2_byte);
              {
              let v301_2_tail = v301_2_cursor.fork_read_zipper();
              let v301_2_head = Path::from_slice(&[v301_2_byte]);
              let v302_2: Path = concat_path(&(v300_3_head),&(v301_2_head));
              let mut v302_3 = Space::new();
              let mut v302_3_cursor = (v301_2_tail).read_zipper();
              for v302_3_byte in v302_3_cursor.child_mask().iter() {
                v302_3_cursor.descend_to_byte(v302_3_byte);
                {
                let v302_3_tail = v302_3_cursor.fork_read_zipper();
                let v302_3_head = Path::from_slice(&[v302_3_byte]);
                let v303_2: Path = concat_path(&(v302_2),&(v302_3_head));
                let mut v303_3 = Space::new();
                let mut v303_3_cursor = (v302_3_tail).read_zipper();
                for v303_3_byte in v303_3_cursor.child_mask().iter() {
                  v303_3_cursor.descend_to_byte(v303_3_byte);
                  {
                  let v303_3_tail = v303_3_cursor.fork_read_zipper();
                  let v303_3_head = Path::from_slice(&[v303_3_byte]);
                  let v304_2: Path = concat_path(&(v303_2),&(v303_3_head));
                  let v304_3: Space = routine_52(c, &(v304_2), &(*p0), &(v300_2), &(v303_3_tail).make_space());
                  drop(v304_2);
                  v303_3.join_into((v304_3).clone());
                  }
                  v303_3_cursor.ascend(1);
                }
                drop(v303_3_cursor);
                drop(v303_2);
                v302_3.join_into((v303_3).clone());
                }
                v302_3_cursor.ascend(1);
              }
              drop(v302_3_cursor);
              drop(v302_2);
              v301_2.join_into((v302_3).clone());
              }
              v301_2_cursor.ascend(1);
            }
            drop(v301_2_cursor);
            v300_3.join_into((v301_2).clone());
            }
            v300_3_cursor.ascend(1);
          }
          drop(v300_3_cursor);
          drop(v300_2);
          v299_3.join_into((v300_3).clone());
          }
          v299_3_cursor.ascend(1);
        }
        drop(v299_3_cursor);
        drop(v299_2);
        v298_3.join_into((v299_3).clone());
        }
        v298_3_cursor.ascend(1);
      }
      drop(v298_3_cursor);
      drop(v298_2);
      v297_2.join_into((v298_3).clone());
      }
      v297_2_cursor.ascend(1);
    }
    drop(v297_2_cursor);
    v296_2.join_into((v297_2).clone());
    }
    v296_2_cursor.ascend(1);
  }
  drop(v296_2_cursor);
  (v296_2).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v306_2 = Space::new();
  let mut v306_2_cursor = (*s0).read_zipper();
  for v306_2_byte in v306_2_cursor.child_mask().iter() {
    v306_2_cursor.descend_to_byte(v306_2_byte);
    {
    let v306_2_tail = v306_2_cursor.fork_read_zipper();
    let v306_2_head = Path::from_slice(&[v306_2_byte]);
    let mut v307_2 = Space::new();
    let mut v307_2_cursor = (v306_2_tail).read_zipper();
    for v307_2_byte in v307_2_cursor.child_mask().iter() {
      v307_2_cursor.descend_to_byte(v307_2_byte);
      {
      let v307_2_tail = v307_2_cursor.fork_read_zipper();
      let v307_2_head = Path::from_slice(&[v307_2_byte]);
      let v308_2: Path = concat_path(&(v306_2_head),&(v307_2_head));
      let mut v308_3 = Space::new();
      let mut v308_3_cursor = (v307_2_tail).read_zipper();
      for v308_3_byte in v308_3_cursor.child_mask().iter() {
        v308_3_cursor.descend_to_byte(v308_3_byte);
        {
        let v308_3_tail = v308_3_cursor.fork_read_zipper();
        let v308_3_head = Path::from_slice(&[v308_3_byte]);
        let v309_2: Path = concat_path(&(v308_2),&(v308_3_head));
        let mut v309_3 = Space::new();
        let mut v309_3_cursor = (v308_3_tail).read_zipper();
        for v309_3_byte in v309_3_cursor.child_mask().iter() {
          v309_3_cursor.descend_to_byte(v309_3_byte);
          {
          let v309_3_tail = v309_3_cursor.fork_read_zipper();
          let v309_3_head = Path::from_slice(&[v309_3_byte]);
          let v310_2: Path = concat_path(&(v309_2),&(v309_3_head));
          let mut v310_3 = Space::new();
          let mut v310_3_cursor = (v309_3_tail).read_zipper();
          for v310_3_byte in v310_3_cursor.child_mask().iter() {
            v310_3_cursor.descend_to_byte(v310_3_byte);
            {
            let v310_3_tail = v310_3_cursor.fork_read_zipper();
            let v310_3_head = Path::from_slice(&[v310_3_byte]);
            let mut v311_2 = Space::new();
            let mut v311_2_cursor = (v310_3_tail).read_zipper();
            for v311_2_byte in v311_2_cursor.child_mask().iter() {
              v311_2_cursor.descend_to_byte(v311_2_byte);
              {
              let v311_2_tail = v311_2_cursor.fork_read_zipper();
              let v311_2_head = Path::from_slice(&[v311_2_byte]);
              let v312_2: Path = concat_path(&(v310_3_head),&(v311_2_head));
              let mut v312_3 = Space::new();
              let mut v312_3_cursor = (v311_2_tail).read_zipper();
              for v312_3_byte in v312_3_cursor.child_mask().iter() {
                v312_3_cursor.descend_to_byte(v312_3_byte);
                {
                let v312_3_tail = v312_3_cursor.fork_read_zipper();
                let v312_3_head = Path::from_slice(&[v312_3_byte]);
                let v313_2: Path = concat_path(&(v312_2),&(v312_3_head));
                let mut v313_3 = Space::new();
                let mut v313_3_cursor = (v312_3_tail).read_zipper();
                for v313_3_byte in v313_3_cursor.child_mask().iter() {
                  v313_3_cursor.descend_to_byte(v313_3_byte);
                  {
                  let v313_3_tail = v313_3_cursor.fork_read_zipper();
                  let v313_3_head = Path::from_slice(&[v313_3_byte]);
                  let v314_2: Path = concat_path(&(v313_2),&(v313_3_head));
                  let v314_3: Space = routine_53(c, &(v314_2), &(*p0), &(v310_2), &(v313_3_tail).make_space());
                  drop(v314_2);
                  v313_3.join_into((v314_3).clone());
                  }
                  v313_3_cursor.ascend(1);
                }
                drop(v313_3_cursor);
                drop(v313_2);
                v312_3.join_into((v313_3).clone());
                }
                v312_3_cursor.ascend(1);
              }
              drop(v312_3_cursor);
              drop(v312_2);
              v311_2.join_into((v312_3).clone());
              }
              v311_2_cursor.ascend(1);
            }
            drop(v311_2_cursor);
            v310_3.join_into((v311_2).clone());
            }
            v310_3_cursor.ascend(1);
          }
          drop(v310_3_cursor);
          drop(v310_2);
          v309_3.join_into((v310_3).clone());
          }
          v309_3_cursor.ascend(1);
        }
        drop(v309_3_cursor);
        drop(v309_2);
        v308_3.join_into((v309_3).clone());
        }
        v308_3_cursor.ascend(1);
      }
      drop(v308_3_cursor);
      drop(v308_2);
      v307_2.join_into((v308_3).clone());
      }
      v307_2_cursor.ascend(1);
    }
    drop(v307_2_cursor);
    v306_2.join_into((v307_2).clone());
    }
    v306_2_cursor.ascend(1);
  }
  drop(v306_2_cursor);
  (v306_2).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v316_2 = Space::new();
  let mut v316_2_cursor = (*s0).read_zipper();
  for v316_2_byte in v316_2_cursor.child_mask().iter() {
    v316_2_cursor.descend_to_byte(v316_2_byte);
    {
    let v316_2_tail = v316_2_cursor.fork_read_zipper();
    let v316_2_head = Path::from_slice(&[v316_2_byte]);
    let mut v317_2 = Space::new();
    let mut v317_2_cursor = (v316_2_tail).read_zipper();
    for v317_2_byte in v317_2_cursor.child_mask().iter() {
      v317_2_cursor.descend_to_byte(v317_2_byte);
      {
      let v317_2_tail = v317_2_cursor.fork_read_zipper();
      let v317_2_head = Path::from_slice(&[v317_2_byte]);
      let v318_2: Path = concat_path(&(v316_2_head),&(v317_2_head));
      let mut v318_3 = Space::new();
      let mut v318_3_cursor = (v317_2_tail).read_zipper();
      for v318_3_byte in v318_3_cursor.child_mask().iter() {
        v318_3_cursor.descend_to_byte(v318_3_byte);
        {
        let v318_3_tail = v318_3_cursor.fork_read_zipper();
        let v318_3_head = Path::from_slice(&[v318_3_byte]);
        let v319_2: Path = concat_path(&(v318_2),&(v318_3_head));
        let mut v319_3 = Space::new();
        let mut v319_3_cursor = (v318_3_tail).read_zipper();
        for v319_3_byte in v319_3_cursor.child_mask().iter() {
          v319_3_cursor.descend_to_byte(v319_3_byte);
          {
          let v319_3_tail = v319_3_cursor.fork_read_zipper();
          let v319_3_head = Path::from_slice(&[v319_3_byte]);
          let v320_2: Path = concat_path(&(v319_2),&(v319_3_head));
          let mut v320_3 = Space::new();
          let mut v320_3_cursor = (v319_3_tail).read_zipper();
          for v320_3_byte in v320_3_cursor.child_mask().iter() {
            v320_3_cursor.descend_to_byte(v320_3_byte);
            {
            let v320_3_tail = v320_3_cursor.fork_read_zipper();
            let v320_3_head = Path::from_slice(&[v320_3_byte]);
            let mut v321_2 = Space::new();
            let mut v321_2_cursor = (v320_3_tail).read_zipper();
            for v321_2_byte in v321_2_cursor.child_mask().iter() {
              v321_2_cursor.descend_to_byte(v321_2_byte);
              {
              let v321_2_tail = v321_2_cursor.fork_read_zipper();
              let v321_2_head = Path::from_slice(&[v321_2_byte]);
              let v322_2: Path = concat_path(&(v320_3_head),&(v321_2_head));
              let mut v322_3 = Space::new();
              let mut v322_3_cursor = (v321_2_tail).read_zipper();
              for v322_3_byte in v322_3_cursor.child_mask().iter() {
                v322_3_cursor.descend_to_byte(v322_3_byte);
                {
                let v322_3_tail = v322_3_cursor.fork_read_zipper();
                let v322_3_head = Path::from_slice(&[v322_3_byte]);
                let v323_2: Path = concat_path(&(v322_2),&(v322_3_head));
                let mut v323_3 = Space::new();
                let mut v323_3_cursor = (v322_3_tail).read_zipper();
                for v323_3_byte in v323_3_cursor.child_mask().iter() {
                  v323_3_cursor.descend_to_byte(v323_3_byte);
                  {
                  let v323_3_tail = v323_3_cursor.fork_read_zipper();
                  let v323_3_head = Path::from_slice(&[v323_3_byte]);
                  let v324_2: Path = concat_path(&(v323_2),&(v323_3_head));
                  let v324_3: Space = routine_54(c, &(v324_2), &(*p0), &(v320_2), &(v323_3_tail).make_space());
                  drop(v324_2);
                  v323_3.join_into((v324_3).clone());
                  }
                  v323_3_cursor.ascend(1);
                }
                drop(v323_3_cursor);
                drop(v323_2);
                v322_3.join_into((v323_3).clone());
                }
                v322_3_cursor.ascend(1);
              }
              drop(v322_3_cursor);
              drop(v322_2);
              v321_2.join_into((v322_3).clone());
              }
              v321_2_cursor.ascend(1);
            }
            drop(v321_2_cursor);
            v320_3.join_into((v321_2).clone());
            }
            v320_3_cursor.ascend(1);
          }
          drop(v320_3_cursor);
          drop(v320_2);
          v319_3.join_into((v320_3).clone());
          }
          v319_3_cursor.ascend(1);
        }
        drop(v319_3_cursor);
        drop(v319_2);
        v318_3.join_into((v319_3).clone());
        }
        v318_3_cursor.ascend(1);
      }
      drop(v318_3_cursor);
      drop(v318_2);
      v317_2.join_into((v318_3).clone());
      }
      v317_2_cursor.ascend(1);
    }
    drop(v317_2_cursor);
    v316_2.join_into((v317_2).clone());
    }
    v316_2_cursor.ascend(1);
  }
  drop(v316_2_cursor);
  (v316_2).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v326_2 = Space::new();
  let mut v326_2_cursor = (*s0).read_zipper();
  for v326_2_byte in v326_2_cursor.child_mask().iter() {
    v326_2_cursor.descend_to_byte(v326_2_byte);
    {
    let v326_2_tail = v326_2_cursor.fork_read_zipper();
    let v326_2_head = Path::from_slice(&[v326_2_byte]);
    let mut v327_2 = Space::new();
    let mut v327_2_cursor = (v326_2_tail).read_zipper();
    for v327_2_byte in v327_2_cursor.child_mask().iter() {
      v327_2_cursor.descend_to_byte(v327_2_byte);
      {
      let v327_2_tail = v327_2_cursor.fork_read_zipper();
      let v327_2_head = Path::from_slice(&[v327_2_byte]);
      let v328_2: Path = concat_path(&(v326_2_head),&(v327_2_head));
      let mut v328_3 = Space::new();
      let mut v328_3_cursor = (v327_2_tail).read_zipper();
      for v328_3_byte in v328_3_cursor.child_mask().iter() {
        v328_3_cursor.descend_to_byte(v328_3_byte);
        {
        let v328_3_tail = v328_3_cursor.fork_read_zipper();
        let v328_3_head = Path::from_slice(&[v328_3_byte]);
        let v329_2: Path = concat_path(&(v328_2),&(v328_3_head));
        let mut v329_3 = Space::new();
        let mut v329_3_cursor = (v328_3_tail).read_zipper();
        for v329_3_byte in v329_3_cursor.child_mask().iter() {
          v329_3_cursor.descend_to_byte(v329_3_byte);
          {
          let v329_3_tail = v329_3_cursor.fork_read_zipper();
          let v329_3_head = Path::from_slice(&[v329_3_byte]);
          let v330_2: Path = concat_path(&(v329_2),&(v329_3_head));
          let mut v330_3 = Space::new();
          let mut v330_3_cursor = (v329_3_tail).read_zipper();
          for v330_3_byte in v330_3_cursor.child_mask().iter() {
            v330_3_cursor.descend_to_byte(v330_3_byte);
            {
            let v330_3_tail = v330_3_cursor.fork_read_zipper();
            let v330_3_head = Path::from_slice(&[v330_3_byte]);
            let mut v331_2 = Space::new();
            let mut v331_2_cursor = (v330_3_tail).read_zipper();
            for v331_2_byte in v331_2_cursor.child_mask().iter() {
              v331_2_cursor.descend_to_byte(v331_2_byte);
              {
              let v331_2_tail = v331_2_cursor.fork_read_zipper();
              let v331_2_head = Path::from_slice(&[v331_2_byte]);
              let v332_2: Path = concat_path(&(v330_3_head),&(v331_2_head));
              let mut v332_3 = Space::new();
              let mut v332_3_cursor = (v331_2_tail).read_zipper();
              for v332_3_byte in v332_3_cursor.child_mask().iter() {
                v332_3_cursor.descend_to_byte(v332_3_byte);
                {
                let v332_3_tail = v332_3_cursor.fork_read_zipper();
                let v332_3_head = Path::from_slice(&[v332_3_byte]);
                let v333_2: Path = concat_path(&(v332_2),&(v332_3_head));
                let mut v333_3 = Space::new();
                let mut v333_3_cursor = (v332_3_tail).read_zipper();
                for v333_3_byte in v333_3_cursor.child_mask().iter() {
                  v333_3_cursor.descend_to_byte(v333_3_byte);
                  {
                  let v333_3_tail = v333_3_cursor.fork_read_zipper();
                  let v333_3_head = Path::from_slice(&[v333_3_byte]);
                  let v334_2: Path = concat_path(&(v333_2),&(v333_3_head));
                  let v334_3: Space = routine_55(c, &(v334_2), &(*p0), &(v330_2), &(v333_3_tail).make_space());
                  drop(v334_2);
                  v333_3.join_into((v334_3).clone());
                  }
                  v333_3_cursor.ascend(1);
                }
                drop(v333_3_cursor);
                drop(v333_2);
                v332_3.join_into((v333_3).clone());
                }
                v332_3_cursor.ascend(1);
              }
              drop(v332_3_cursor);
              drop(v332_2);
              v331_2.join_into((v332_3).clone());
              }
              v331_2_cursor.ascend(1);
            }
            drop(v331_2_cursor);
            v330_3.join_into((v331_2).clone());
            }
            v330_3_cursor.ascend(1);
          }
          drop(v330_3_cursor);
          drop(v330_2);
          v329_3.join_into((v330_3).clone());
          }
          v329_3_cursor.ascend(1);
        }
        drop(v329_3_cursor);
        drop(v329_2);
        v328_3.join_into((v329_3).clone());
        }
        v328_3_cursor.ascend(1);
      }
      drop(v328_3_cursor);
      drop(v328_2);
      v327_2.join_into((v328_3).clone());
      }
      v327_2_cursor.ascend(1);
    }
    drop(v327_2_cursor);
    v326_2.join_into((v327_2).clone());
    }
    v326_2_cursor.ascend(1);
  }
  drop(v326_2_cursor);
  (v326_2).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v336_2 = Space::new();
  let mut v336_2_cursor = (*s0).read_zipper();
  for v336_2_byte in v336_2_cursor.child_mask().iter() {
    v336_2_cursor.descend_to_byte(v336_2_byte);
    {
    let v336_2_tail = v336_2_cursor.fork_read_zipper();
    let v336_2_head = Path::from_slice(&[v336_2_byte]);
    let mut v337_2 = Space::new();
    let mut v337_2_cursor = (v336_2_tail).read_zipper();
    for v337_2_byte in v337_2_cursor.child_mask().iter() {
      v337_2_cursor.descend_to_byte(v337_2_byte);
      {
      let v337_2_tail = v337_2_cursor.fork_read_zipper();
      let v337_2_head = Path::from_slice(&[v337_2_byte]);
      let v338_2: Path = concat_path(&(v336_2_head),&(v337_2_head));
      let mut v338_3 = Space::new();
      let mut v338_3_cursor = (v337_2_tail).read_zipper();
      for v338_3_byte in v338_3_cursor.child_mask().iter() {
        v338_3_cursor.descend_to_byte(v338_3_byte);
        {
        let v338_3_tail = v338_3_cursor.fork_read_zipper();
        let v338_3_head = Path::from_slice(&[v338_3_byte]);
        let v339_2: Path = concat_path(&(v338_2),&(v338_3_head));
        let mut v339_3 = Space::new();
        let mut v339_3_cursor = (v338_3_tail).read_zipper();
        for v339_3_byte in v339_3_cursor.child_mask().iter() {
          v339_3_cursor.descend_to_byte(v339_3_byte);
          {
          let v339_3_tail = v339_3_cursor.fork_read_zipper();
          let v339_3_head = Path::from_slice(&[v339_3_byte]);
          let v340_2: Path = concat_path(&(v339_2),&(v339_3_head));
          let mut v340_3 = Space::new();
          let mut v340_3_cursor = (v339_3_tail).read_zipper();
          for v340_3_byte in v340_3_cursor.child_mask().iter() {
            v340_3_cursor.descend_to_byte(v340_3_byte);
            {
            let v340_3_tail = v340_3_cursor.fork_read_zipper();
            let v340_3_head = Path::from_slice(&[v340_3_byte]);
            let mut v341_2 = Space::new();
            let mut v341_2_cursor = (v340_3_tail).read_zipper();
            for v341_2_byte in v341_2_cursor.child_mask().iter() {
              v341_2_cursor.descend_to_byte(v341_2_byte);
              {
              let v341_2_tail = v341_2_cursor.fork_read_zipper();
              let v341_2_head = Path::from_slice(&[v341_2_byte]);
              let v342_2: Path = concat_path(&(v340_3_head),&(v341_2_head));
              let mut v342_3 = Space::new();
              let mut v342_3_cursor = (v341_2_tail).read_zipper();
              for v342_3_byte in v342_3_cursor.child_mask().iter() {
                v342_3_cursor.descend_to_byte(v342_3_byte);
                {
                let v342_3_tail = v342_3_cursor.fork_read_zipper();
                let v342_3_head = Path::from_slice(&[v342_3_byte]);
                let v343_2: Path = concat_path(&(v342_2),&(v342_3_head));
                let mut v343_3 = Space::new();
                let mut v343_3_cursor = (v342_3_tail).read_zipper();
                for v343_3_byte in v343_3_cursor.child_mask().iter() {
                  v343_3_cursor.descend_to_byte(v343_3_byte);
                  {
                  let v343_3_tail = v343_3_cursor.fork_read_zipper();
                  let v343_3_head = Path::from_slice(&[v343_3_byte]);
                  let v344_2: Path = concat_path(&(v343_2),&(v343_3_head));
                  let v344_3: Space = routine_56(c, &(v344_2), &(*p0), &(v340_2), &(v343_3_tail).make_space());
                  drop(v344_2);
                  v343_3.join_into((v344_3).clone());
                  }
                  v343_3_cursor.ascend(1);
                }
                drop(v343_3_cursor);
                drop(v343_2);
                v342_3.join_into((v343_3).clone());
                }
                v342_3_cursor.ascend(1);
              }
              drop(v342_3_cursor);
              drop(v342_2);
              v341_2.join_into((v342_3).clone());
              }
              v341_2_cursor.ascend(1);
            }
            drop(v341_2_cursor);
            v340_3.join_into((v341_2).clone());
            }
            v340_3_cursor.ascend(1);
          }
          drop(v340_3_cursor);
          drop(v340_2);
          v339_3.join_into((v340_3).clone());
          }
          v339_3_cursor.ascend(1);
        }
        drop(v339_3_cursor);
        drop(v339_2);
        v338_3.join_into((v339_3).clone());
        }
        v338_3_cursor.ascend(1);
      }
      drop(v338_3_cursor);
      drop(v338_2);
      v337_2.join_into((v338_3).clone());
      }
      v337_2_cursor.ascend(1);
    }
    drop(v337_2_cursor);
    v336_2.join_into((v337_2).clone());
    }
    v336_2_cursor.ascend(1);
  }
  drop(v336_2_cursor);
  (v336_2).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v346_2 = Space::new();
  let mut v346_2_cursor = (*s0).read_zipper();
  for v346_2_byte in v346_2_cursor.child_mask().iter() {
    v346_2_cursor.descend_to_byte(v346_2_byte);
    {
    let v346_2_tail = v346_2_cursor.fork_read_zipper();
    let v346_2_head = Path::from_slice(&[v346_2_byte]);
    let mut v347_2 = Space::new();
    let mut v347_2_cursor = (v346_2_tail).read_zipper();
    for v347_2_byte in v347_2_cursor.child_mask().iter() {
      v347_2_cursor.descend_to_byte(v347_2_byte);
      {
      let v347_2_tail = v347_2_cursor.fork_read_zipper();
      let v347_2_head = Path::from_slice(&[v347_2_byte]);
      let v348_2: Path = concat_path(&(v346_2_head),&(v347_2_head));
      let mut v348_3 = Space::new();
      let mut v348_3_cursor = (v347_2_tail).read_zipper();
      for v348_3_byte in v348_3_cursor.child_mask().iter() {
        v348_3_cursor.descend_to_byte(v348_3_byte);
        {
        let v348_3_tail = v348_3_cursor.fork_read_zipper();
        let v348_3_head = Path::from_slice(&[v348_3_byte]);
        let v349_2: Path = concat_path(&(v348_2),&(v348_3_head));
        let mut v349_3 = Space::new();
        let mut v349_3_cursor = (v348_3_tail).read_zipper();
        for v349_3_byte in v349_3_cursor.child_mask().iter() {
          v349_3_cursor.descend_to_byte(v349_3_byte);
          {
          let v349_3_tail = v349_3_cursor.fork_read_zipper();
          let v349_3_head = Path::from_slice(&[v349_3_byte]);
          let v350_2: Path = concat_path(&(v349_2),&(v349_3_head));
          let mut v350_3 = Space::new();
          let mut v350_3_cursor = (v349_3_tail).read_zipper();
          for v350_3_byte in v350_3_cursor.child_mask().iter() {
            v350_3_cursor.descend_to_byte(v350_3_byte);
            {
            let v350_3_tail = v350_3_cursor.fork_read_zipper();
            let v350_3_head = Path::from_slice(&[v350_3_byte]);
            let mut v351_2 = Space::new();
            let mut v351_2_cursor = (v350_3_tail).read_zipper();
            for v351_2_byte in v351_2_cursor.child_mask().iter() {
              v351_2_cursor.descend_to_byte(v351_2_byte);
              {
              let v351_2_tail = v351_2_cursor.fork_read_zipper();
              let v351_2_head = Path::from_slice(&[v351_2_byte]);
              let v352_2: Path = concat_path(&(v350_3_head),&(v351_2_head));
              let mut v352_3 = Space::new();
              let mut v352_3_cursor = (v351_2_tail).read_zipper();
              for v352_3_byte in v352_3_cursor.child_mask().iter() {
                v352_3_cursor.descend_to_byte(v352_3_byte);
                {
                let v352_3_tail = v352_3_cursor.fork_read_zipper();
                let v352_3_head = Path::from_slice(&[v352_3_byte]);
                let v353_2: Path = concat_path(&(v352_2),&(v352_3_head));
                let mut v353_3 = Space::new();
                let mut v353_3_cursor = (v352_3_tail).read_zipper();
                for v353_3_byte in v353_3_cursor.child_mask().iter() {
                  v353_3_cursor.descend_to_byte(v353_3_byte);
                  {
                  let v353_3_tail = v353_3_cursor.fork_read_zipper();
                  let v353_3_head = Path::from_slice(&[v353_3_byte]);
                  let v354_2: Path = concat_path(&(v353_2),&(v353_3_head));
                  let v354_3: Space = routine_57(c, &(v354_2), &(*p0), &(v350_2), &(v353_3_tail).make_space());
                  drop(v354_2);
                  v353_3.join_into((v354_3).clone());
                  }
                  v353_3_cursor.ascend(1);
                }
                drop(v353_3_cursor);
                drop(v353_2);
                v352_3.join_into((v353_3).clone());
                }
                v352_3_cursor.ascend(1);
              }
              drop(v352_3_cursor);
              drop(v352_2);
              v351_2.join_into((v352_3).clone());
              }
              v351_2_cursor.ascend(1);
            }
            drop(v351_2_cursor);
            v350_3.join_into((v351_2).clone());
            }
            v350_3_cursor.ascend(1);
          }
          drop(v350_3_cursor);
          drop(v350_2);
          v349_3.join_into((v350_3).clone());
          }
          v349_3_cursor.ascend(1);
        }
        drop(v349_3_cursor);
        drop(v349_2);
        v348_3.join_into((v349_3).clone());
        }
        v348_3_cursor.ascend(1);
      }
      drop(v348_3_cursor);
      drop(v348_2);
      v347_2.join_into((v348_3).clone());
      }
      v347_2_cursor.ascend(1);
    }
    drop(v347_2_cursor);
    v346_2.join_into((v347_2).clone());
    }
    v346_2_cursor.ascend(1);
  }
  drop(v346_2_cursor);
  (v346_2).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_36(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v356_2 = Space::new();
  let mut v356_2_cursor = (*s0).read_zipper();
  for v356_2_byte in v356_2_cursor.child_mask().iter() {
    v356_2_cursor.descend_to_byte(v356_2_byte);
    {
    let v356_2_tail = v356_2_cursor.fork_read_zipper();
    let v356_2_head = Path::from_slice(&[v356_2_byte]);
    let mut v357_2 = Space::new();
    let mut v357_2_cursor = (v356_2_tail).read_zipper();
    for v357_2_byte in v357_2_cursor.child_mask().iter() {
      v357_2_cursor.descend_to_byte(v357_2_byte);
      {
      let v357_2_tail = v357_2_cursor.fork_read_zipper();
      let v357_2_head = Path::from_slice(&[v357_2_byte]);
      let v358_2: Path = concat_path(&(v356_2_head),&(v357_2_head));
      let mut v358_3 = Space::new();
      let mut v358_3_cursor = (v357_2_tail).read_zipper();
      for v358_3_byte in v358_3_cursor.child_mask().iter() {
        v358_3_cursor.descend_to_byte(v358_3_byte);
        {
        let v358_3_tail = v358_3_cursor.fork_read_zipper();
        let v358_3_head = Path::from_slice(&[v358_3_byte]);
        let v359_2: Path = concat_path(&(v358_2),&(v358_3_head));
        let mut v359_3 = Space::new();
        let mut v359_3_cursor = (v358_3_tail).read_zipper();
        for v359_3_byte in v359_3_cursor.child_mask().iter() {
          v359_3_cursor.descend_to_byte(v359_3_byte);
          {
          let v359_3_tail = v359_3_cursor.fork_read_zipper();
          let v359_3_head = Path::from_slice(&[v359_3_byte]);
          let v360_2: Path = concat_path(&(v359_2),&(v359_3_head));
          let mut v360_3 = Space::new();
          let mut v360_3_cursor = (v359_3_tail).read_zipper();
          for v360_3_byte in v360_3_cursor.child_mask().iter() {
            v360_3_cursor.descend_to_byte(v360_3_byte);
            {
            let v360_3_tail = v360_3_cursor.fork_read_zipper();
            let v360_3_head = Path::from_slice(&[v360_3_byte]);
            let mut v361_2 = Space::new();
            let mut v361_2_cursor = (v360_3_tail).read_zipper();
            for v361_2_byte in v361_2_cursor.child_mask().iter() {
              v361_2_cursor.descend_to_byte(v361_2_byte);
              {
              let v361_2_tail = v361_2_cursor.fork_read_zipper();
              let v361_2_head = Path::from_slice(&[v361_2_byte]);
              let v362_2: Path = concat_path(&(v360_3_head),&(v361_2_head));
              let mut v362_3 = Space::new();
              let mut v362_3_cursor = (v361_2_tail).read_zipper();
              for v362_3_byte in v362_3_cursor.child_mask().iter() {
                v362_3_cursor.descend_to_byte(v362_3_byte);
                {
                let v362_3_tail = v362_3_cursor.fork_read_zipper();
                let v362_3_head = Path::from_slice(&[v362_3_byte]);
                let v363_2: Path = concat_path(&(v362_2),&(v362_3_head));
                let mut v363_3 = Space::new();
                let mut v363_3_cursor = (v362_3_tail).read_zipper();
                for v363_3_byte in v363_3_cursor.child_mask().iter() {
                  v363_3_cursor.descend_to_byte(v363_3_byte);
                  {
                  let v363_3_tail = v363_3_cursor.fork_read_zipper();
                  let v363_3_head = Path::from_slice(&[v363_3_byte]);
                  let v364_2: Path = concat_path(&(v363_2),&(v363_3_head));
                  let v364_3: Space = routine_58(c, &(v364_2), &(*p0), &(v360_2), &(v363_3_tail).make_space());
                  drop(v364_2);
                  v363_3.join_into((v364_3).clone());
                  }
                  v363_3_cursor.ascend(1);
                }
                drop(v363_3_cursor);
                drop(v363_2);
                v362_3.join_into((v363_3).clone());
                }
                v362_3_cursor.ascend(1);
              }
              drop(v362_3_cursor);
              drop(v362_2);
              v361_2.join_into((v362_3).clone());
              }
              v361_2_cursor.ascend(1);
            }
            drop(v361_2_cursor);
            v360_3.join_into((v361_2).clone());
            }
            v360_3_cursor.ascend(1);
          }
          drop(v360_3_cursor);
          drop(v360_2);
          v359_3.join_into((v360_3).clone());
          }
          v359_3_cursor.ascend(1);
        }
        drop(v359_3_cursor);
        drop(v359_2);
        v358_3.join_into((v359_3).clone());
        }
        v358_3_cursor.ascend(1);
      }
      drop(v358_3_cursor);
      drop(v358_2);
      v357_2.join_into((v358_3).clone());
      }
      v357_2_cursor.ascend(1);
    }
    drop(v357_2_cursor);
    v356_2.join_into((v357_2).clone());
    }
    v356_2_cursor.ascend(1);
  }
  drop(v356_2_cursor);
  (v356_2).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_38(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v366_2 = Space::new();
  let mut v366_2_cursor = (*s0).read_zipper();
  for v366_2_byte in v366_2_cursor.child_mask().iter() {
    v366_2_cursor.descend_to_byte(v366_2_byte);
    {
    let v366_2_tail = v366_2_cursor.fork_read_zipper();
    let v366_2_head = Path::from_slice(&[v366_2_byte]);
    let mut v367_2 = Space::new();
    let mut v367_2_cursor = (v366_2_tail).read_zipper();
    for v367_2_byte in v367_2_cursor.child_mask().iter() {
      v367_2_cursor.descend_to_byte(v367_2_byte);
      {
      let v367_2_tail = v367_2_cursor.fork_read_zipper();
      let v367_2_head = Path::from_slice(&[v367_2_byte]);
      let v368_2: Path = concat_path(&(v366_2_head),&(v367_2_head));
      let mut v368_3 = Space::new();
      let mut v368_3_cursor = (v367_2_tail).read_zipper();
      for v368_3_byte in v368_3_cursor.child_mask().iter() {
        v368_3_cursor.descend_to_byte(v368_3_byte);
        {
        let v368_3_tail = v368_3_cursor.fork_read_zipper();
        let v368_3_head = Path::from_slice(&[v368_3_byte]);
        let v369_2: Path = concat_path(&(v368_2),&(v368_3_head));
        let mut v369_3 = Space::new();
        let mut v369_3_cursor = (v368_3_tail).read_zipper();
        for v369_3_byte in v369_3_cursor.child_mask().iter() {
          v369_3_cursor.descend_to_byte(v369_3_byte);
          {
          let v369_3_tail = v369_3_cursor.fork_read_zipper();
          let v369_3_head = Path::from_slice(&[v369_3_byte]);
          let v370_2: Path = concat_path(&(v369_2),&(v369_3_head));
          let mut v370_3 = Space::new();
          let mut v370_3_cursor = (v369_3_tail).read_zipper();
          for v370_3_byte in v370_3_cursor.child_mask().iter() {
            v370_3_cursor.descend_to_byte(v370_3_byte);
            {
            let v370_3_tail = v370_3_cursor.fork_read_zipper();
            let v370_3_head = Path::from_slice(&[v370_3_byte]);
            let mut v371_2 = Space::new();
            let mut v371_2_cursor = (v370_3_tail).read_zipper();
            for v371_2_byte in v371_2_cursor.child_mask().iter() {
              v371_2_cursor.descend_to_byte(v371_2_byte);
              {
              let v371_2_tail = v371_2_cursor.fork_read_zipper();
              let v371_2_head = Path::from_slice(&[v371_2_byte]);
              let v372_2: Path = concat_path(&(v370_3_head),&(v371_2_head));
              let mut v372_3 = Space::new();
              let mut v372_3_cursor = (v371_2_tail).read_zipper();
              for v372_3_byte in v372_3_cursor.child_mask().iter() {
                v372_3_cursor.descend_to_byte(v372_3_byte);
                {
                let v372_3_tail = v372_3_cursor.fork_read_zipper();
                let v372_3_head = Path::from_slice(&[v372_3_byte]);
                let v373_2: Path = concat_path(&(v372_2),&(v372_3_head));
                let mut v373_3 = Space::new();
                let mut v373_3_cursor = (v372_3_tail).read_zipper();
                for v373_3_byte in v373_3_cursor.child_mask().iter() {
                  v373_3_cursor.descend_to_byte(v373_3_byte);
                  {
                  let v373_3_tail = v373_3_cursor.fork_read_zipper();
                  let v373_3_head = Path::from_slice(&[v373_3_byte]);
                  let v374_2: Path = concat_path(&(v373_2),&(v373_3_head));
                  let v374_3: Space = routine_59(c, &(v374_2), &(*p0), &(v370_2), &(v373_3_tail).make_space());
                  drop(v374_2);
                  v373_3.join_into((v374_3).clone());
                  }
                  v373_3_cursor.ascend(1);
                }
                drop(v373_3_cursor);
                drop(v373_2);
                v372_3.join_into((v373_3).clone());
                }
                v372_3_cursor.ascend(1);
              }
              drop(v372_3_cursor);
              drop(v372_2);
              v371_2.join_into((v372_3).clone());
              }
              v371_2_cursor.ascend(1);
            }
            drop(v371_2_cursor);
            v370_3.join_into((v371_2).clone());
            }
            v370_3_cursor.ascend(1);
          }
          drop(v370_3_cursor);
          drop(v370_2);
          v369_3.join_into((v370_3).clone());
          }
          v369_3_cursor.ascend(1);
        }
        drop(v369_3_cursor);
        drop(v369_2);
        v368_3.join_into((v369_3).clone());
        }
        v368_3_cursor.ascend(1);
      }
      drop(v368_3_cursor);
      drop(v368_2);
      v367_2.join_into((v368_3).clone());
      }
      v367_2_cursor.ascend(1);
    }
    drop(v367_2_cursor);
    v366_2.join_into((v367_2).clone());
    }
    v366_2_cursor.ascend(1);
  }
  drop(v366_2_cursor);
  (v366_2).clone()
}

fn routine_39(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_40(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v376_2 = Space::new();
  let mut v376_2_cursor = (*s0).read_zipper();
  for v376_2_byte in v376_2_cursor.child_mask().iter() {
    v376_2_cursor.descend_to_byte(v376_2_byte);
    {
    let v376_2_tail = v376_2_cursor.fork_read_zipper();
    let v376_2_head = Path::from_slice(&[v376_2_byte]);
    let mut v377_2 = Space::new();
    let mut v377_2_cursor = (v376_2_tail).read_zipper();
    for v377_2_byte in v377_2_cursor.child_mask().iter() {
      v377_2_cursor.descend_to_byte(v377_2_byte);
      {
      let v377_2_tail = v377_2_cursor.fork_read_zipper();
      let v377_2_head = Path::from_slice(&[v377_2_byte]);
      let v378_2: Path = concat_path(&(v376_2_head),&(v377_2_head));
      let mut v378_3 = Space::new();
      let mut v378_3_cursor = (v377_2_tail).read_zipper();
      for v378_3_byte in v378_3_cursor.child_mask().iter() {
        v378_3_cursor.descend_to_byte(v378_3_byte);
        {
        let v378_3_tail = v378_3_cursor.fork_read_zipper();
        let v378_3_head = Path::from_slice(&[v378_3_byte]);
        let v379_2: Path = concat_path(&(v378_2),&(v378_3_head));
        let mut v379_3 = Space::new();
        let mut v379_3_cursor = (v378_3_tail).read_zipper();
        for v379_3_byte in v379_3_cursor.child_mask().iter() {
          v379_3_cursor.descend_to_byte(v379_3_byte);
          {
          let v379_3_tail = v379_3_cursor.fork_read_zipper();
          let v379_3_head = Path::from_slice(&[v379_3_byte]);
          let v380_2: Path = concat_path(&(v379_2),&(v379_3_head));
          let mut v380_3 = Space::new();
          let mut v380_3_cursor = (v379_3_tail).read_zipper();
          for v380_3_byte in v380_3_cursor.child_mask().iter() {
            v380_3_cursor.descend_to_byte(v380_3_byte);
            {
            let v380_3_tail = v380_3_cursor.fork_read_zipper();
            let v380_3_head = Path::from_slice(&[v380_3_byte]);
            let mut v381_2 = Space::new();
            let mut v381_2_cursor = (v380_3_tail).read_zipper();
            for v381_2_byte in v381_2_cursor.child_mask().iter() {
              v381_2_cursor.descend_to_byte(v381_2_byte);
              {
              let v381_2_tail = v381_2_cursor.fork_read_zipper();
              let v381_2_head = Path::from_slice(&[v381_2_byte]);
              let v382_2: Path = concat_path(&(v380_3_head),&(v381_2_head));
              let mut v382_3 = Space::new();
              let mut v382_3_cursor = (v381_2_tail).read_zipper();
              for v382_3_byte in v382_3_cursor.child_mask().iter() {
                v382_3_cursor.descend_to_byte(v382_3_byte);
                {
                let v382_3_tail = v382_3_cursor.fork_read_zipper();
                let v382_3_head = Path::from_slice(&[v382_3_byte]);
                let v383_2: Path = concat_path(&(v382_2),&(v382_3_head));
                let mut v383_3 = Space::new();
                let mut v383_3_cursor = (v382_3_tail).read_zipper();
                for v383_3_byte in v383_3_cursor.child_mask().iter() {
                  v383_3_cursor.descend_to_byte(v383_3_byte);
                  {
                  let v383_3_tail = v383_3_cursor.fork_read_zipper();
                  let v383_3_head = Path::from_slice(&[v383_3_byte]);
                  let v384_2: Path = concat_path(&(v383_2),&(v383_3_head));
                  let v384_3: Space = routine_60(c, &(v384_2), &(*p0), &(v380_2), &(v383_3_tail).make_space());
                  drop(v384_2);
                  v383_3.join_into((v384_3).clone());
                  }
                  v383_3_cursor.ascend(1);
                }
                drop(v383_3_cursor);
                drop(v383_2);
                v382_3.join_into((v383_3).clone());
                }
                v382_3_cursor.ascend(1);
              }
              drop(v382_3_cursor);
              drop(v382_2);
              v381_2.join_into((v382_3).clone());
              }
              v381_2_cursor.ascend(1);
            }
            drop(v381_2_cursor);
            v380_3.join_into((v381_2).clone());
            }
            v380_3_cursor.ascend(1);
          }
          drop(v380_3_cursor);
          drop(v380_2);
          v379_3.join_into((v380_3).clone());
          }
          v379_3_cursor.ascend(1);
        }
        drop(v379_3_cursor);
        drop(v379_2);
        v378_3.join_into((v379_3).clone());
        }
        v378_3_cursor.ascend(1);
      }
      drop(v378_3_cursor);
      drop(v378_2);
      v377_2.join_into((v378_3).clone());
      }
      v377_2_cursor.ascend(1);
    }
    drop(v377_2_cursor);
    v376_2.join_into((v377_2).clone());
    }
    v376_2_cursor.ascend(1);
  }
  drop(v376_2_cursor);
  (v376_2).clone()
}

fn routine_41(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v385_3 = Space::new();
  let mut v385_3_cursor = (*s0).read_zipper();
  for v385_3_byte in v385_3_cursor.child_mask().iter() {
    v385_3_cursor.descend_to_byte(v385_3_byte);
    {
    let v385_3_tail = v385_3_cursor.fork_read_zipper();
    let v385_3_head = Path::from_slice(&[v385_3_byte]);
    let mut v386_2 = Space::new();
    let mut v386_2_cursor = (v385_3_tail).read_zipper();
    for v386_2_byte in v386_2_cursor.child_mask().iter() {
      v386_2_cursor.descend_to_byte(v386_2_byte);
      {
      let v386_2_tail = v386_2_cursor.fork_read_zipper();
      let v386_2_head = Path::from_slice(&[v386_2_byte]);
      let v387_2: Path = concat_path(&(v385_3_head),&(v386_2_head));
      let mut v387_3 = Space::new();
      let mut v387_3_cursor = (v386_2_tail).read_zipper();
      for v387_3_byte in v387_3_cursor.child_mask().iter() {
        v387_3_cursor.descend_to_byte(v387_3_byte);
        {
        let v387_3_tail = v387_3_cursor.fork_read_zipper();
        let v387_3_head = Path::from_slice(&[v387_3_byte]);
        let v388_2: Path = concat_path(&(v387_2),&(v387_3_head));
        let mut v388_3 = Space::new();
        let mut v388_3_cursor = (v387_3_tail).read_zipper();
        for v388_3_byte in v388_3_cursor.child_mask().iter() {
          v388_3_cursor.descend_to_byte(v388_3_byte);
          {
          let v388_3_tail = v388_3_cursor.fork_read_zipper();
          let v388_3_head = Path::from_slice(&[v388_3_byte]);
          let mut v389_2 = Space::new();
          let mut v389_2_cursor = (v388_3_tail).read_zipper();
          for v389_2_byte in v389_2_cursor.child_mask().iter() {
            v389_2_cursor.descend_to_byte(v389_2_byte);
            {
            let v389_2_tail = v389_2_cursor.fork_read_zipper();
            let v389_2_head = Path::from_slice(&[v389_2_byte]);
            let mut v390_2 = Space::new();
            let mut v390_2_cursor = (v389_2_tail).read_zipper();
            for v390_2_byte in v390_2_cursor.child_mask().iter() {
              v390_2_cursor.descend_to_byte(v390_2_byte);
              {
              let v390_2_tail = v390_2_cursor.fork_read_zipper();
              let v390_2_head = Path::from_slice(&[v390_2_byte]);
              let v391_2: Path = concat_path(&(v389_2_head),&(v390_2_head));
              let mut v391_3 = Space::new();
              let mut v391_3_cursor = (v390_2_tail).read_zipper();
              for v391_3_byte in v391_3_cursor.child_mask().iter() {
                v391_3_cursor.descend_to_byte(v391_3_byte);
                {
                let v391_3_tail = v391_3_cursor.fork_read_zipper();
                let v391_3_head = Path::from_slice(&[v391_3_byte]);
                let v392_2: Path = concat_path(&(v391_2),&(v391_3_head));
                let mut v392_3 = Space::new();
                let mut v392_3_cursor = (v391_3_tail).read_zipper();
                for v392_3_byte in v392_3_cursor.child_mask().iter() {
                  v392_3_cursor.descend_to_byte(v392_3_byte);
                  {
                  let v392_3_tail = v392_3_cursor.fork_read_zipper();
                  let v392_3_head = Path::from_slice(&[v392_3_byte]);
                  let v393_2: Path = concat_path(&(v392_2),&(v392_3_head));
                  let v393_3: Space = routine_61(c, &(v393_2), &(v392_3_tail).make_space());
                  drop(v393_2);
                  v392_3.join_into((v393_3).clone());
                  }
                  v392_3_cursor.ascend(1);
                }
                drop(v392_3_cursor);
                drop(v392_2);
                v391_3.join_into((v392_3).clone());
                }
                v391_3_cursor.ascend(1);
              }
              drop(v391_3_cursor);
              drop(v391_2);
              v390_2.join_into((v391_3).clone());
              }
              v390_2_cursor.ascend(1);
            }
            drop(v390_2_cursor);
            v389_2.join_into((v390_2).clone());
            }
            v389_2_cursor.ascend(1);
          }
          drop(v389_2_cursor);
          let v389_3: Space = map_map_kernels::raffine(&(*CONSTANT_83),&(v389_2));
          let v389_4: Space = map_view_kernels::unite(&(v389_3),&(v388_3_tail));
          let v389_5: Path = concat_path(&(v388_2),&(v388_3_head));
          let v389_6: Path = concat_path(&(*p0),&(v389_5));
          drop(v389_5);
          let v389_7: Space = map_kernels::wrap(&(v389_4),&(v389_6));
          drop(v389_6);
          v388_3.join_into((v389_7).clone());
          }
          v388_3_cursor.ascend(1);
        }
        drop(v388_3_cursor);
        drop(v388_2);
        v387_3.join_into((v388_3).clone());
        }
        v387_3_cursor.ascend(1);
      }
      drop(v387_3_cursor);
      drop(v387_2);
      v386_2.join_into((v387_3).clone());
      }
      v386_2_cursor.ascend(1);
    }
    drop(v386_2_cursor);
    v385_3.join_into((v386_2).clone());
    }
    v385_3_cursor.ascend(1);
  }
  drop(v385_3_cursor);
  (v385_3).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v394_4: Space = map_kernels::unwrap(&(*s0),&(*p1));
  let v394_5: Space = map_kernels::wrap(&(v394_4),&(*p0));
  drop(v394_4);
  let v394_6: Space = if (v394_5).is_empty() { Space::new() } else {
    map_map_kernels::compose(&(v394_5),&(*s1))
  };
  drop(v394_5);
  (v394_6).clone()
}

fn routine_43(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v396_3 = Space::new();
  let mut v396_3_cursor = (*s0).read_zipper();
  for v396_3_byte in v396_3_cursor.child_mask().iter() {
    v396_3_cursor.descend_to_byte(v396_3_byte);
    {
    let v396_3_tail = v396_3_cursor.fork_read_zipper();
    let v396_3_head = Path::from_slice(&[v396_3_byte]);
    let mut v397_2 = Space::new();
    let mut v397_2_cursor = (v396_3_tail).read_zipper();
    for v397_2_byte in v397_2_cursor.child_mask().iter() {
      v397_2_cursor.descend_to_byte(v397_2_byte);
      {
      let v397_2_tail = v397_2_cursor.fork_read_zipper();
      let v397_2_head = Path::from_slice(&[v397_2_byte]);
      let v398_2: Path = concat_path(&(v396_3_head),&(v397_2_head));
      let mut v398_3 = Space::new();
      let mut v398_3_cursor = (v397_2_tail).read_zipper();
      for v398_3_byte in v398_3_cursor.child_mask().iter() {
        v398_3_cursor.descend_to_byte(v398_3_byte);
        {
        let v398_3_tail = v398_3_cursor.fork_read_zipper();
        let v398_3_head = Path::from_slice(&[v398_3_byte]);
        let v399_2: Path = concat_path(&(v398_2),&(v398_3_head));
        let mut v399_3 = Space::new();
        let mut v399_3_cursor = (v398_3_tail).read_zipper();
        for v399_3_byte in v399_3_cursor.child_mask().iter() {
          v399_3_cursor.descend_to_byte(v399_3_byte);
          {
          let v399_3_tail = v399_3_cursor.fork_read_zipper();
          let v399_3_head = Path::from_slice(&[v399_3_byte]);
          let mut v400_2 = Space::new();
          let mut v400_2_cursor = (v399_3_tail).read_zipper();
          for v400_2_byte in v400_2_cursor.child_mask().iter() {
            v400_2_cursor.descend_to_byte(v400_2_byte);
            {
            let v400_2_tail = v400_2_cursor.fork_read_zipper();
            let v400_2_head = Path::from_slice(&[v400_2_byte]);
            let mut v401_2 = Space::new();
            let mut v401_2_cursor = (v400_2_tail).read_zipper();
            for v401_2_byte in v401_2_cursor.child_mask().iter() {
              v401_2_cursor.descend_to_byte(v401_2_byte);
              {
              let v401_2_tail = v401_2_cursor.fork_read_zipper();
              let v401_2_head = Path::from_slice(&[v401_2_byte]);
              let v402_2: Path = concat_path(&(v400_2_head),&(v401_2_head));
              let mut v402_3 = Space::new();
              let mut v402_3_cursor = (v401_2_tail).read_zipper();
              for v402_3_byte in v402_3_cursor.child_mask().iter() {
                v402_3_cursor.descend_to_byte(v402_3_byte);
                {
                let v402_3_tail = v402_3_cursor.fork_read_zipper();
                let v402_3_head = Path::from_slice(&[v402_3_byte]);
                let v403_2: Path = concat_path(&(v402_2),&(v402_3_head));
                let mut v403_3 = Space::new();
                let mut v403_3_cursor = (v402_3_tail).read_zipper();
                for v403_3_byte in v403_3_cursor.child_mask().iter() {
                  v403_3_cursor.descend_to_byte(v403_3_byte);
                  {
                  let v403_3_tail = v403_3_cursor.fork_read_zipper();
                  let v403_3_head = Path::from_slice(&[v403_3_byte]);
                  let v404_2: Path = concat_path(&(v403_2),&(v403_3_head));
                  let v404_3: Space = routine_62(c, &(v404_2), &(v403_3_tail).make_space());
                  drop(v404_2);
                  v403_3.join_into((v404_3).clone());
                  }
                  v403_3_cursor.ascend(1);
                }
                drop(v403_3_cursor);
                drop(v403_2);
                v402_3.join_into((v403_3).clone());
                }
                v402_3_cursor.ascend(1);
              }
              drop(v402_3_cursor);
              drop(v402_2);
              v401_2.join_into((v402_3).clone());
              }
              v401_2_cursor.ascend(1);
            }
            drop(v401_2_cursor);
            v400_2.join_into((v401_2).clone());
            }
            v400_2_cursor.ascend(1);
          }
          drop(v400_2_cursor);
          let v400_3: Space = map_map_kernels::raffine(&(*CONSTANT_83),&(v400_2));
          let v400_4: Space = map_view_kernels::unite(&(v400_3),&(v399_3_tail));
          let v400_5: Path = concat_path(&(v399_2),&(v399_3_head));
          let v400_6: Path = concat_path(&(*p0),&(v400_5));
          drop(v400_5);
          let v400_7: Space = map_kernels::wrap(&(v400_4),&(v400_6));
          drop(v400_6);
          v399_3.join_into((v400_7).clone());
          }
          v399_3_cursor.ascend(1);
        }
        drop(v399_3_cursor);
        drop(v399_2);
        v398_3.join_into((v399_3).clone());
        }
        v398_3_cursor.ascend(1);
      }
      drop(v398_3_cursor);
      drop(v398_2);
      v397_2.join_into((v398_3).clone());
      }
      v397_2_cursor.ascend(1);
    }
    drop(v397_2_cursor);
    v396_3.join_into((v397_2).clone());
    }
    v396_3_cursor.ascend(1);
  }
  drop(v396_3_cursor);
  (v396_3).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let (v405_175,v405_185,v405_4,) = native_block_3(c, p0, s1);
  let v405_186: Space = map_map_kernels::unite(&(v405_175),&(v405_185));
  drop(v405_175);
  drop(v405_185);
  let v405_188: Space = map_map_kernels::intersect(&(*CONSTANT_60),&(v405_4));
  let v405_195: Space = if (v405_188).is_empty() { Space::new() } else {
    let v556_54: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_1));
    let v556_73: Space = if (v556_54).is_empty() { Space::new() } else {
      let v557_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v556_54),&(v557_7))
    };
    drop(v556_54);
    let v556_91: Space = if (v556_73).is_empty() { Space::new() } else {
      let v558_9: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v556_73),&(v558_9))
    };
    drop(v556_73);
    let v556_108: Space = if (v556_91).is_empty() { Space::new() } else {
      let v559_12: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v556_91),&(v559_12))
    };
    drop(v556_91);
    let v556_124: Space = if (v556_108).is_empty() { Space::new() } else {
      let v560_15: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v556_108),&(v560_15))
    };
    drop(v556_108);
    let v556_139: Space = if (v556_124).is_empty() { Space::new() } else {
      let v561_18: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v556_124),&(v561_18))
    };
    drop(v556_124);
    let v556_153: Space = if (v556_139).is_empty() { Space::new() } else {
      let v562_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v556_139),&(v562_21))
    };
    drop(v556_139);
    let v556_166: Space = if (v556_153).is_empty() { Space::new() } else {
      let v563_24: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v556_153),&(v563_24))
    };
    drop(v556_153);
    let v556_178: Space = if (v556_166).is_empty() { Space::new() } else {
      let v564_27: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v556_166),&(v564_27))
    };
    drop(v556_166);
    let v556_189: Space = if (v556_178).is_empty() { Space::new() } else {
      let v565_30: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v556_178),&(v565_30))
    };
    drop(v556_178);
    let v556_190: Space = if (v556_189).is_empty() { Space::new() } else {
      let v566_36: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v556_189),&(v566_36))
    };
    let v556_191: Space = if (v556_190).is_empty() { Space::new() } else {
      let v567_39: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v556_190),&(v567_39))
    };
    drop(v556_190);
    let v556_192: Space = if (v556_191).is_empty() { Space::new() } else {
      let v568_42: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v556_191),&(v568_42))
    };
    drop(v556_191);
    let v556_193: Space = if (v556_192).is_empty() { Space::new() } else {
      let v569_45: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v556_192),&(v569_45))
    };
    drop(v556_192);
    let v556_194: Space = if (v556_193).is_empty() { Space::new() } else {
      let v570_48: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v556_193),&(v570_48))
    };
    drop(v556_193);
    map_map_kernels::compose(&(v405_188),&(v556_194))
  };
  drop(v405_188);
  let v405_196: Space = map_map_kernels::unite(&(v405_186),&(v405_195));
  drop(v405_186);
  drop(v405_195);
  let v405_198: Space = map_map_kernels::intersect(&(*CONSTANT_61),&(v405_4));
  let v405_204: Space = if (v405_198).is_empty() { Space::new() } else {
    let v571_54: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_1));
    let v571_73: Space = if (v571_54).is_empty() { Space::new() } else {
      let v572_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v571_54),&(v572_7))
    };
    drop(v571_54);
    let v571_91: Space = if (v571_73).is_empty() { Space::new() } else {
      let v573_9: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v571_73),&(v573_9))
    };
    drop(v571_73);
    let v571_108: Space = if (v571_91).is_empty() { Space::new() } else {
      let v574_12: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v571_91),&(v574_12))
    };
    drop(v571_91);
    let v571_124: Space = if (v571_108).is_empty() { Space::new() } else {
      let v575_15: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v571_108),&(v575_15))
    };
    drop(v571_108);
    let v571_139: Space = if (v571_124).is_empty() { Space::new() } else {
      let v576_18: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v571_124),&(v576_18))
    };
    drop(v571_124);
    let v571_153: Space = if (v571_139).is_empty() { Space::new() } else {
      let v577_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v571_139),&(v577_21))
    };
    drop(v571_139);
    let v571_166: Space = if (v571_153).is_empty() { Space::new() } else {
      let v578_24: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v571_153),&(v578_24))
    };
    drop(v571_153);
    let v571_178: Space = if (v571_166).is_empty() { Space::new() } else {
      let v579_27: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v571_166),&(v579_27))
    };
    drop(v571_166);
    let v571_189: Space = if (v571_178).is_empty() { Space::new() } else {
      let v580_30: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v571_178),&(v580_30))
    };
    drop(v571_178);
    let v571_199: Space = if (v571_189).is_empty() { Space::new() } else {
      let v581_33: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v571_189),&(v581_33))
    };
    drop(v571_189);
    let v571_200: Space = if (v571_199).is_empty() { Space::new() } else {
      let v582_39: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v571_199),&(v582_39))
    };
    let v571_201: Space = if (v571_200).is_empty() { Space::new() } else {
      let v583_42: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v571_200),&(v583_42))
    };
    drop(v571_200);
    let v571_202: Space = if (v571_201).is_empty() { Space::new() } else {
      let v584_45: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v571_201),&(v584_45))
    };
    drop(v571_201);
    let v571_203: Space = if (v571_202).is_empty() { Space::new() } else {
      let v585_48: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v571_202),&(v585_48))
    };
    drop(v571_202);
    map_map_kernels::compose(&(v405_198),&(v571_203))
  };
  drop(v405_198);
  let v405_205: Space = map_map_kernels::unite(&(v405_196),&(v405_204));
  drop(v405_196);
  drop(v405_204);
  let v405_207: Space = map_map_kernels::intersect(&(*CONSTANT_62),&(v405_4));
  let v405_212: Space = if (v405_207).is_empty() { Space::new() } else {
    let v586_54: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_1));
    let v586_73: Space = if (v586_54).is_empty() { Space::new() } else {
      let v587_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v586_54),&(v587_7))
    };
    drop(v586_54);
    let v586_91: Space = if (v586_73).is_empty() { Space::new() } else {
      let v588_9: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v586_73),&(v588_9))
    };
    drop(v586_73);
    let v586_108: Space = if (v586_91).is_empty() { Space::new() } else {
      let v589_12: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v586_91),&(v589_12))
    };
    drop(v586_91);
    let v586_124: Space = if (v586_108).is_empty() { Space::new() } else {
      let v590_15: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v586_108),&(v590_15))
    };
    drop(v586_108);
    let v586_139: Space = if (v586_124).is_empty() { Space::new() } else {
      let v591_18: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v586_124),&(v591_18))
    };
    drop(v586_124);
    let v586_153: Space = if (v586_139).is_empty() { Space::new() } else {
      let v592_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v586_139),&(v592_21))
    };
    drop(v586_139);
    let v586_166: Space = if (v586_153).is_empty() { Space::new() } else {
      let v593_24: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v586_153),&(v593_24))
    };
    drop(v586_153);
    let v586_178: Space = if (v586_166).is_empty() { Space::new() } else {
      let v594_27: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v586_166),&(v594_27))
    };
    drop(v586_166);
    let v586_189: Space = if (v586_178).is_empty() { Space::new() } else {
      let v595_30: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v586_178),&(v595_30))
    };
    drop(v586_178);
    let v586_199: Space = if (v586_189).is_empty() { Space::new() } else {
      let v596_33: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v586_189),&(v596_33))
    };
    drop(v586_189);
    let v586_208: Space = if (v586_199).is_empty() { Space::new() } else {
      let v597_36: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v586_199),&(v597_36))
    };
    drop(v586_199);
    let v586_209: Space = if (v586_208).is_empty() { Space::new() } else {
      let v598_42: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v586_208),&(v598_42))
    };
    let v586_210: Space = if (v586_209).is_empty() { Space::new() } else {
      let v599_45: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v586_209),&(v599_45))
    };
    drop(v586_209);
    let v586_211: Space = if (v586_210).is_empty() { Space::new() } else {
      let v600_48: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v586_210),&(v600_48))
    };
    drop(v586_210);
    map_map_kernels::compose(&(v405_207),&(v586_211))
  };
  drop(v405_207);
  let v405_213: Space = map_map_kernels::unite(&(v405_205),&(v405_212));
  drop(v405_205);
  drop(v405_212);
  let v405_215: Space = map_map_kernels::intersect(&(*CONSTANT_63),&(v405_4));
  let v405_219: Space = if (v405_215).is_empty() { Space::new() } else {
    let v601_54: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_1));
    let v601_73: Space = if (v601_54).is_empty() { Space::new() } else {
      let v602_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v601_54),&(v602_7))
    };
    drop(v601_54);
    let v601_91: Space = if (v601_73).is_empty() { Space::new() } else {
      let v603_9: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v601_73),&(v603_9))
    };
    drop(v601_73);
    let v601_108: Space = if (v601_91).is_empty() { Space::new() } else {
      let v604_12: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v601_91),&(v604_12))
    };
    drop(v601_91);
    let v601_124: Space = if (v601_108).is_empty() { Space::new() } else {
      let v605_15: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v601_108),&(v605_15))
    };
    drop(v601_108);
    let v601_139: Space = if (v601_124).is_empty() { Space::new() } else {
      let v606_18: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v601_124),&(v606_18))
    };
    drop(v601_124);
    let v601_153: Space = if (v601_139).is_empty() { Space::new() } else {
      let v607_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v601_139),&(v607_21))
    };
    drop(v601_139);
    let v601_166: Space = if (v601_153).is_empty() { Space::new() } else {
      let v608_24: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v601_153),&(v608_24))
    };
    drop(v601_153);
    let v601_178: Space = if (v601_166).is_empty() { Space::new() } else {
      let v609_27: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v601_166),&(v609_27))
    };
    drop(v601_166);
    let v601_189: Space = if (v601_178).is_empty() { Space::new() } else {
      let v610_30: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v601_178),&(v610_30))
    };
    drop(v601_178);
    let v601_199: Space = if (v601_189).is_empty() { Space::new() } else {
      let v611_33: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v601_189),&(v611_33))
    };
    drop(v601_189);
    let v601_208: Space = if (v601_199).is_empty() { Space::new() } else {
      let v612_36: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v601_199),&(v612_36))
    };
    drop(v601_199);
    let v601_216: Space = if (v601_208).is_empty() { Space::new() } else {
      let v613_39: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v601_208),&(v613_39))
    };
    drop(v601_208);
    let v601_217: Space = if (v601_216).is_empty() { Space::new() } else {
      let v614_45: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v601_216),&(v614_45))
    };
    let v601_218: Space = if (v601_217).is_empty() { Space::new() } else {
      let v615_48: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v601_217),&(v615_48))
    };
    drop(v601_217);
    map_map_kernels::compose(&(v405_215),&(v601_218))
  };
  drop(v405_215);
  let v405_220: Space = map_map_kernels::unite(&(v405_213),&(v405_219));
  drop(v405_213);
  drop(v405_219);
  let v405_222: Space = map_map_kernels::intersect(&(*CONSTANT_64),&(v405_4));
  let v405_225: Space = if (v405_222).is_empty() { Space::new() } else {
    let v616_54: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_1));
    let v616_73: Space = if (v616_54).is_empty() { Space::new() } else {
      let v617_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v616_54),&(v617_7))
    };
    drop(v616_54);
    let v616_91: Space = if (v616_73).is_empty() { Space::new() } else {
      let v618_9: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v616_73),&(v618_9))
    };
    drop(v616_73);
    let v616_108: Space = if (v616_91).is_empty() { Space::new() } else {
      let v619_12: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v616_91),&(v619_12))
    };
    drop(v616_91);
    let v616_124: Space = if (v616_108).is_empty() { Space::new() } else {
      let v620_15: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v616_108),&(v620_15))
    };
    drop(v616_108);
    let v616_139: Space = if (v616_124).is_empty() { Space::new() } else {
      let v621_18: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v616_124),&(v621_18))
    };
    drop(v616_124);
    let v616_153: Space = if (v616_139).is_empty() { Space::new() } else {
      let v622_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v616_139),&(v622_21))
    };
    drop(v616_139);
    let v616_166: Space = if (v616_153).is_empty() { Space::new() } else {
      let v623_24: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v616_153),&(v623_24))
    };
    drop(v616_153);
    let v616_178: Space = if (v616_166).is_empty() { Space::new() } else {
      let v624_27: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v616_166),&(v624_27))
    };
    drop(v616_166);
    let v616_189: Space = if (v616_178).is_empty() { Space::new() } else {
      let v625_30: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v616_178),&(v625_30))
    };
    drop(v616_178);
    let v616_199: Space = if (v616_189).is_empty() { Space::new() } else {
      let v626_33: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v616_189),&(v626_33))
    };
    drop(v616_189);
    let v616_208: Space = if (v616_199).is_empty() { Space::new() } else {
      let v627_36: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v616_199),&(v627_36))
    };
    drop(v616_199);
    let v616_216: Space = if (v616_208).is_empty() { Space::new() } else {
      let v628_39: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v616_208),&(v628_39))
    };
    drop(v616_208);
    let v616_223: Space = if (v616_216).is_empty() { Space::new() } else {
      let v629_42: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v616_216),&(v629_42))
    };
    drop(v616_216);
    let v616_224: Space = if (v616_223).is_empty() { Space::new() } else {
      let v630_48: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_81));
      map_map_kernels::compose(&(v616_223),&(v630_48))
    };
    map_map_kernels::compose(&(v405_222),&(v616_224))
  };
  drop(v405_222);
  let v405_226: Space = map_map_kernels::unite(&(v405_220),&(v405_225));
  drop(v405_220);
  drop(v405_225);
  let v405_228: Space = map_map_kernels::intersect(&(*CONSTANT_65),&(v405_4));
  drop(v405_4);
  let v405_230: Space = if (v405_228).is_empty() { Space::new() } else {
    let v631_54: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_1));
    let v631_73: Space = if (v631_54).is_empty() { Space::new() } else {
      let v632_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
      map_map_kernels::compose(&(v631_54),&(v632_7))
    };
    drop(v631_54);
    let v631_91: Space = if (v631_73).is_empty() { Space::new() } else {
      let v633_9: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
      map_map_kernels::compose(&(v631_73),&(v633_9))
    };
    drop(v631_73);
    let v631_108: Space = if (v631_91).is_empty() { Space::new() } else {
      let v634_12: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_7));
      map_map_kernels::compose(&(v631_91),&(v634_12))
    };
    drop(v631_91);
    let v631_124: Space = if (v631_108).is_empty() { Space::new() } else {
      let v635_15: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_9));
      map_map_kernels::compose(&(v631_108),&(v635_15))
    };
    drop(v631_108);
    let v631_139: Space = if (v631_124).is_empty() { Space::new() } else {
      let v636_18: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_11));
      map_map_kernels::compose(&(v631_124),&(v636_18))
    };
    drop(v631_124);
    let v631_153: Space = if (v631_139).is_empty() { Space::new() } else {
      let v637_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_13));
      map_map_kernels::compose(&(v631_139),&(v637_21))
    };
    drop(v631_139);
    let v631_166: Space = if (v631_153).is_empty() { Space::new() } else {
      let v638_24: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_15));
      map_map_kernels::compose(&(v631_153),&(v638_24))
    };
    drop(v631_153);
    let v631_178: Space = if (v631_166).is_empty() { Space::new() } else {
      let v639_27: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_17));
      map_map_kernels::compose(&(v631_166),&(v639_27))
    };
    drop(v631_166);
    let v631_189: Space = if (v631_178).is_empty() { Space::new() } else {
      let v640_30: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_19));
      map_map_kernels::compose(&(v631_178),&(v640_30))
    };
    drop(v631_178);
    let v631_199: Space = if (v631_189).is_empty() { Space::new() } else {
      let v641_33: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_21));
      map_map_kernels::compose(&(v631_189),&(v641_33))
    };
    drop(v631_189);
    let v631_208: Space = if (v631_199).is_empty() { Space::new() } else {
      let v642_36: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_23));
      map_map_kernels::compose(&(v631_199),&(v642_36))
    };
    drop(v631_199);
    let v631_216: Space = if (v631_208).is_empty() { Space::new() } else {
      let v643_39: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_25));
      map_map_kernels::compose(&(v631_208),&(v643_39))
    };
    drop(v631_208);
    let v631_223: Space = if (v631_216).is_empty() { Space::new() } else {
      let v644_42: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_27));
      map_map_kernels::compose(&(v631_216),&(v644_42))
    };
    drop(v631_216);
    let v631_229: Space = if (v631_223).is_empty() { Space::new() } else {
      let v645_45: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_29));
      map_map_kernels::compose(&(v631_223),&(v645_45))
    };
    drop(v631_223);
    map_map_kernels::compose(&(v405_228),&(v631_229))
  };
  drop(v405_228);
  let v405_231: Space = map_map_kernels::unite(&(v405_226),&(v405_230));
  drop(v405_226);
  drop(v405_230);
  (v405_231).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v646_4 = Space::new();
  let mut v646_4_cursor = (*s0).read_zipper();
  for v646_4_byte in v646_4_cursor.child_mask().iter() {
    v646_4_cursor.descend_to_byte(v646_4_byte);
    {
    let v646_4_tail = v646_4_cursor.fork_read_zipper();
    let v646_4_head = Path::from_slice(&[v646_4_byte]);
    let mut v647_2 = Space::new();
    let mut v647_2_cursor = (v646_4_tail).read_zipper();
    for v647_2_byte in v647_2_cursor.child_mask().iter() {
      v647_2_cursor.descend_to_byte(v647_2_byte);
      {
      let v647_2_tail = v647_2_cursor.fork_read_zipper();
      let v647_2_head = Path::from_slice(&[v647_2_byte]);
      let v648_2: Path = concat_path(&(v646_4_head),&(v647_2_head));
      let mut v648_3 = Space::new();
      let mut v648_3_cursor = (v647_2_tail).read_zipper();
      for v648_3_byte in v648_3_cursor.child_mask().iter() {
        v648_3_cursor.descend_to_byte(v648_3_byte);
        {
        let v648_3_tail = v648_3_cursor.fork_read_zipper();
        let v648_3_head = Path::from_slice(&[v648_3_byte]);
        let v649_2: Path = concat_path(&(v648_2),&(v648_3_head));
        let mut v649_3 = Space::new();
        let mut v649_3_cursor = (v648_3_tail).read_zipper();
        for v649_3_byte in v649_3_cursor.child_mask().iter() {
          v649_3_cursor.descend_to_byte(v649_3_byte);
          {
          let v649_3_tail = v649_3_cursor.fork_read_zipper();
          let v649_3_head = Path::from_slice(&[v649_3_byte]);
          let v650_2: Path = concat_path(&(v649_2),&(v649_3_head));
          let mut v650_3 = Space::new();
          let mut v650_3_cursor = (v649_3_tail).read_zipper();
          for v650_3_byte in v650_3_cursor.child_mask().iter() {
            v650_3_cursor.descend_to_byte(v650_3_byte);
            {
            let v650_3_tail = v650_3_cursor.fork_read_zipper();
            let v650_3_head = Path::from_slice(&[v650_3_byte]);
            let mut v651_2 = Space::new();
            let mut v651_2_cursor = (v650_3_tail).read_zipper();
            for v651_2_byte in v651_2_cursor.child_mask().iter() {
              v651_2_cursor.descend_to_byte(v651_2_byte);
              {
              let v651_2_tail = v651_2_cursor.fork_read_zipper();
              let v651_2_head = Path::from_slice(&[v651_2_byte]);
              let v652_2: Path = concat_path(&(v650_3_head),&(v651_2_head));
              let mut v652_3 = Space::new();
              let mut v652_3_cursor = (v651_2_tail).read_zipper();
              for v652_3_byte in v652_3_cursor.child_mask().iter() {
                v652_3_cursor.descend_to_byte(v652_3_byte);
                {
                let v652_3_tail = v652_3_cursor.fork_read_zipper();
                let v652_3_head = Path::from_slice(&[v652_3_byte]);
                let v653_2: Path = concat_path(&(v652_2),&(v652_3_head));
                let mut v653_3 = Space::new();
                let mut v653_3_cursor = (v652_3_tail).read_zipper();
                for v653_3_byte in v653_3_cursor.child_mask().iter() {
                  v653_3_cursor.descend_to_byte(v653_3_byte);
                  {
                  let v653_3_tail = v653_3_cursor.fork_read_zipper();
                  let v653_3_head = Path::from_slice(&[v653_3_byte]);
                  let v654_2: Path = concat_path(&(v653_2),&(v653_3_head));
                  let v654_3: Space = routine_63(c, &(v654_2), &(*p1), &(*p2), &(*p0), &(v650_2), &(v653_3_tail).make_space());
                  drop(v654_2);
                  v653_3.join_into((v654_3).clone());
                  }
                  v653_3_cursor.ascend(1);
                }
                drop(v653_3_cursor);
                drop(v653_2);
                v652_3.join_into((v653_3).clone());
                }
                v652_3_cursor.ascend(1);
              }
              drop(v652_3_cursor);
              drop(v652_2);
              v651_2.join_into((v652_3).clone());
              }
              v651_2_cursor.ascend(1);
            }
            drop(v651_2_cursor);
            v650_3.join_into((v651_2).clone());
            }
            v650_3_cursor.ascend(1);
          }
          drop(v650_3_cursor);
          drop(v650_2);
          v649_3.join_into((v650_3).clone());
          }
          v649_3_cursor.ascend(1);
        }
        drop(v649_3_cursor);
        drop(v649_2);
        v648_3.join_into((v649_3).clone());
        }
        v648_3_cursor.ascend(1);
      }
      drop(v648_3_cursor);
      drop(v648_2);
      v647_2.join_into((v648_3).clone());
      }
      v647_2_cursor.ascend(1);
    }
    drop(v647_2_cursor);
    v646_4.join_into((v647_2).clone());
    }
    v646_4_cursor.ascend(1);
  }
  drop(v646_4_cursor);
  (v646_4).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v655_4 = Space::new();
  let mut v655_4_cursor = (*s0).read_zipper();
  for v655_4_byte in v655_4_cursor.child_mask().iter() {
    v655_4_cursor.descend_to_byte(v655_4_byte);
    {
    let v655_4_tail = v655_4_cursor.fork_read_zipper();
    let v655_4_head = Path::from_slice(&[v655_4_byte]);
    let mut v656_2 = Space::new();
    let mut v656_2_cursor = (v655_4_tail).read_zipper();
    for v656_2_byte in v656_2_cursor.child_mask().iter() {
      v656_2_cursor.descend_to_byte(v656_2_byte);
      {
      let v656_2_tail = v656_2_cursor.fork_read_zipper();
      let v656_2_head = Path::from_slice(&[v656_2_byte]);
      let v657_2: Path = concat_path(&(v655_4_head),&(v656_2_head));
      let mut v657_3 = Space::new();
      let mut v657_3_cursor = (v656_2_tail).read_zipper();
      for v657_3_byte in v657_3_cursor.child_mask().iter() {
        v657_3_cursor.descend_to_byte(v657_3_byte);
        {
        let v657_3_tail = v657_3_cursor.fork_read_zipper();
        let v657_3_head = Path::from_slice(&[v657_3_byte]);
        let v658_2: Path = concat_path(&(v657_2),&(v657_3_head));
        let mut v658_3 = Space::new();
        let mut v658_3_cursor = (v657_3_tail).read_zipper();
        for v658_3_byte in v658_3_cursor.child_mask().iter() {
          v658_3_cursor.descend_to_byte(v658_3_byte);
          {
          let v658_3_tail = v658_3_cursor.fork_read_zipper();
          let v658_3_head = Path::from_slice(&[v658_3_byte]);
          let v659_2: Path = concat_path(&(v658_2),&(v658_3_head));
          let mut v659_3 = Space::new();
          let mut v659_3_cursor = (v658_3_tail).read_zipper();
          for v659_3_byte in v659_3_cursor.child_mask().iter() {
            v659_3_cursor.descend_to_byte(v659_3_byte);
            {
            let v659_3_tail = v659_3_cursor.fork_read_zipper();
            let v659_3_head = Path::from_slice(&[v659_3_byte]);
            let mut v660_2 = Space::new();
            let mut v660_2_cursor = (v659_3_tail).read_zipper();
            for v660_2_byte in v660_2_cursor.child_mask().iter() {
              v660_2_cursor.descend_to_byte(v660_2_byte);
              {
              let v660_2_tail = v660_2_cursor.fork_read_zipper();
              let v660_2_head = Path::from_slice(&[v660_2_byte]);
              let v661_2: Path = concat_path(&(v659_3_head),&(v660_2_head));
              let mut v661_3 = Space::new();
              let mut v661_3_cursor = (v660_2_tail).read_zipper();
              for v661_3_byte in v661_3_cursor.child_mask().iter() {
                v661_3_cursor.descend_to_byte(v661_3_byte);
                {
                let v661_3_tail = v661_3_cursor.fork_read_zipper();
                let v661_3_head = Path::from_slice(&[v661_3_byte]);
                let v662_2: Path = concat_path(&(v661_2),&(v661_3_head));
                let mut v662_3 = Space::new();
                let mut v662_3_cursor = (v661_3_tail).read_zipper();
                for v662_3_byte in v662_3_cursor.child_mask().iter() {
                  v662_3_cursor.descend_to_byte(v662_3_byte);
                  {
                  let v662_3_tail = v662_3_cursor.fork_read_zipper();
                  let v662_3_head = Path::from_slice(&[v662_3_byte]);
                  let v663_2: Path = concat_path(&(v662_2),&(v662_3_head));
                  let v663_3: Space = routine_64(c, &(v663_2), &(*p1), &(*p2), &(*p0), &(v659_2), &(v662_3_tail).make_space());
                  drop(v663_2);
                  v662_3.join_into((v663_3).clone());
                  }
                  v662_3_cursor.ascend(1);
                }
                drop(v662_3_cursor);
                drop(v662_2);
                v661_3.join_into((v662_3).clone());
                }
                v661_3_cursor.ascend(1);
              }
              drop(v661_3_cursor);
              drop(v661_2);
              v660_2.join_into((v661_3).clone());
              }
              v660_2_cursor.ascend(1);
            }
            drop(v660_2_cursor);
            v659_3.join_into((v660_2).clone());
            }
            v659_3_cursor.ascend(1);
          }
          drop(v659_3_cursor);
          drop(v659_2);
          v658_3.join_into((v659_3).clone());
          }
          v658_3_cursor.ascend(1);
        }
        drop(v658_3_cursor);
        drop(v658_2);
        v657_3.join_into((v658_3).clone());
        }
        v657_3_cursor.ascend(1);
      }
      drop(v657_3_cursor);
      drop(v657_2);
      v656_2.join_into((v657_3).clone());
      }
      v656_2_cursor.ascend(1);
    }
    drop(v656_2_cursor);
    v655_4.join_into((v656_2).clone());
    }
    v655_4_cursor.ascend(1);
  }
  drop(v655_4_cursor);
  (v655_4).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v664_4 = Space::new();
  let mut v664_4_cursor = (*s0).read_zipper();
  for v664_4_byte in v664_4_cursor.child_mask().iter() {
    v664_4_cursor.descend_to_byte(v664_4_byte);
    {
    let v664_4_tail = v664_4_cursor.fork_read_zipper();
    let v664_4_head = Path::from_slice(&[v664_4_byte]);
    let mut v665_2 = Space::new();
    let mut v665_2_cursor = (v664_4_tail).read_zipper();
    for v665_2_byte in v665_2_cursor.child_mask().iter() {
      v665_2_cursor.descend_to_byte(v665_2_byte);
      {
      let v665_2_tail = v665_2_cursor.fork_read_zipper();
      let v665_2_head = Path::from_slice(&[v665_2_byte]);
      let v666_2: Path = concat_path(&(v664_4_head),&(v665_2_head));
      let mut v666_3 = Space::new();
      let mut v666_3_cursor = (v665_2_tail).read_zipper();
      for v666_3_byte in v666_3_cursor.child_mask().iter() {
        v666_3_cursor.descend_to_byte(v666_3_byte);
        {
        let v666_3_tail = v666_3_cursor.fork_read_zipper();
        let v666_3_head = Path::from_slice(&[v666_3_byte]);
        let v667_2: Path = concat_path(&(v666_2),&(v666_3_head));
        let mut v667_3 = Space::new();
        let mut v667_3_cursor = (v666_3_tail).read_zipper();
        for v667_3_byte in v667_3_cursor.child_mask().iter() {
          v667_3_cursor.descend_to_byte(v667_3_byte);
          {
          let v667_3_tail = v667_3_cursor.fork_read_zipper();
          let v667_3_head = Path::from_slice(&[v667_3_byte]);
          let v668_2: Path = concat_path(&(v667_2),&(v667_3_head));
          let mut v668_3 = Space::new();
          let mut v668_3_cursor = (v667_3_tail).read_zipper();
          for v668_3_byte in v668_3_cursor.child_mask().iter() {
            v668_3_cursor.descend_to_byte(v668_3_byte);
            {
            let v668_3_tail = v668_3_cursor.fork_read_zipper();
            let v668_3_head = Path::from_slice(&[v668_3_byte]);
            let mut v669_2 = Space::new();
            let mut v669_2_cursor = (v668_3_tail).read_zipper();
            for v669_2_byte in v669_2_cursor.child_mask().iter() {
              v669_2_cursor.descend_to_byte(v669_2_byte);
              {
              let v669_2_tail = v669_2_cursor.fork_read_zipper();
              let v669_2_head = Path::from_slice(&[v669_2_byte]);
              let v670_2: Path = concat_path(&(v668_3_head),&(v669_2_head));
              let mut v670_3 = Space::new();
              let mut v670_3_cursor = (v669_2_tail).read_zipper();
              for v670_3_byte in v670_3_cursor.child_mask().iter() {
                v670_3_cursor.descend_to_byte(v670_3_byte);
                {
                let v670_3_tail = v670_3_cursor.fork_read_zipper();
                let v670_3_head = Path::from_slice(&[v670_3_byte]);
                let v671_2: Path = concat_path(&(v670_2),&(v670_3_head));
                let mut v671_3 = Space::new();
                let mut v671_3_cursor = (v670_3_tail).read_zipper();
                for v671_3_byte in v671_3_cursor.child_mask().iter() {
                  v671_3_cursor.descend_to_byte(v671_3_byte);
                  {
                  let v671_3_tail = v671_3_cursor.fork_read_zipper();
                  let v671_3_head = Path::from_slice(&[v671_3_byte]);
                  let v672_2: Path = concat_path(&(v671_2),&(v671_3_head));
                  let v672_3: Space = routine_65(c, &(v672_2), &(*p1), &(*p2), &(*p0), &(v668_2), &(v671_3_tail).make_space());
                  drop(v672_2);
                  v671_3.join_into((v672_3).clone());
                  }
                  v671_3_cursor.ascend(1);
                }
                drop(v671_3_cursor);
                drop(v671_2);
                v670_3.join_into((v671_3).clone());
                }
                v670_3_cursor.ascend(1);
              }
              drop(v670_3_cursor);
              drop(v670_2);
              v669_2.join_into((v670_3).clone());
              }
              v669_2_cursor.ascend(1);
            }
            drop(v669_2_cursor);
            v668_3.join_into((v669_2).clone());
            }
            v668_3_cursor.ascend(1);
          }
          drop(v668_3_cursor);
          drop(v668_2);
          v667_3.join_into((v668_3).clone());
          }
          v667_3_cursor.ascend(1);
        }
        drop(v667_3_cursor);
        drop(v667_2);
        v666_3.join_into((v667_3).clone());
        }
        v666_3_cursor.ascend(1);
      }
      drop(v666_3_cursor);
      drop(v666_2);
      v665_2.join_into((v666_3).clone());
      }
      v665_2_cursor.ascend(1);
    }
    drop(v665_2_cursor);
    v664_4.join_into((v665_2).clone());
    }
    v664_4_cursor.ascend(1);
  }
  drop(v664_4_cursor);
  (v664_4).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v673_4 = Space::new();
  let mut v673_4_cursor = (*s0).read_zipper();
  for v673_4_byte in v673_4_cursor.child_mask().iter() {
    v673_4_cursor.descend_to_byte(v673_4_byte);
    {
    let v673_4_tail = v673_4_cursor.fork_read_zipper();
    let v673_4_head = Path::from_slice(&[v673_4_byte]);
    let mut v674_2 = Space::new();
    let mut v674_2_cursor = (v673_4_tail).read_zipper();
    for v674_2_byte in v674_2_cursor.child_mask().iter() {
      v674_2_cursor.descend_to_byte(v674_2_byte);
      {
      let v674_2_tail = v674_2_cursor.fork_read_zipper();
      let v674_2_head = Path::from_slice(&[v674_2_byte]);
      let v675_2: Path = concat_path(&(v673_4_head),&(v674_2_head));
      let mut v675_3 = Space::new();
      let mut v675_3_cursor = (v674_2_tail).read_zipper();
      for v675_3_byte in v675_3_cursor.child_mask().iter() {
        v675_3_cursor.descend_to_byte(v675_3_byte);
        {
        let v675_3_tail = v675_3_cursor.fork_read_zipper();
        let v675_3_head = Path::from_slice(&[v675_3_byte]);
        let v676_2: Path = concat_path(&(v675_2),&(v675_3_head));
        let mut v676_3 = Space::new();
        let mut v676_3_cursor = (v675_3_tail).read_zipper();
        for v676_3_byte in v676_3_cursor.child_mask().iter() {
          v676_3_cursor.descend_to_byte(v676_3_byte);
          {
          let v676_3_tail = v676_3_cursor.fork_read_zipper();
          let v676_3_head = Path::from_slice(&[v676_3_byte]);
          let v677_2: Path = concat_path(&(v676_2),&(v676_3_head));
          let mut v677_3 = Space::new();
          let mut v677_3_cursor = (v676_3_tail).read_zipper();
          for v677_3_byte in v677_3_cursor.child_mask().iter() {
            v677_3_cursor.descend_to_byte(v677_3_byte);
            {
            let v677_3_tail = v677_3_cursor.fork_read_zipper();
            let v677_3_head = Path::from_slice(&[v677_3_byte]);
            let mut v678_2 = Space::new();
            let mut v678_2_cursor = (v677_3_tail).read_zipper();
            for v678_2_byte in v678_2_cursor.child_mask().iter() {
              v678_2_cursor.descend_to_byte(v678_2_byte);
              {
              let v678_2_tail = v678_2_cursor.fork_read_zipper();
              let v678_2_head = Path::from_slice(&[v678_2_byte]);
              let v679_2: Path = concat_path(&(v677_3_head),&(v678_2_head));
              let mut v679_3 = Space::new();
              let mut v679_3_cursor = (v678_2_tail).read_zipper();
              for v679_3_byte in v679_3_cursor.child_mask().iter() {
                v679_3_cursor.descend_to_byte(v679_3_byte);
                {
                let v679_3_tail = v679_3_cursor.fork_read_zipper();
                let v679_3_head = Path::from_slice(&[v679_3_byte]);
                let v680_2: Path = concat_path(&(v679_2),&(v679_3_head));
                let mut v680_3 = Space::new();
                let mut v680_3_cursor = (v679_3_tail).read_zipper();
                for v680_3_byte in v680_3_cursor.child_mask().iter() {
                  v680_3_cursor.descend_to_byte(v680_3_byte);
                  {
                  let v680_3_tail = v680_3_cursor.fork_read_zipper();
                  let v680_3_head = Path::from_slice(&[v680_3_byte]);
                  let v681_2: Path = concat_path(&(v680_2),&(v680_3_head));
                  let v681_3: Space = routine_66(c, &(v681_2), &(*p1), &(*p2), &(*p0), &(v677_2), &(v680_3_tail).make_space());
                  drop(v681_2);
                  v680_3.join_into((v681_3).clone());
                  }
                  v680_3_cursor.ascend(1);
                }
                drop(v680_3_cursor);
                drop(v680_2);
                v679_3.join_into((v680_3).clone());
                }
                v679_3_cursor.ascend(1);
              }
              drop(v679_3_cursor);
              drop(v679_2);
              v678_2.join_into((v679_3).clone());
              }
              v678_2_cursor.ascend(1);
            }
            drop(v678_2_cursor);
            v677_3.join_into((v678_2).clone());
            }
            v677_3_cursor.ascend(1);
          }
          drop(v677_3_cursor);
          drop(v677_2);
          v676_3.join_into((v677_3).clone());
          }
          v676_3_cursor.ascend(1);
        }
        drop(v676_3_cursor);
        drop(v676_2);
        v675_3.join_into((v676_3).clone());
        }
        v675_3_cursor.ascend(1);
      }
      drop(v675_3_cursor);
      drop(v675_2);
      v674_2.join_into((v675_3).clone());
      }
      v674_2_cursor.ascend(1);
    }
    drop(v674_2_cursor);
    v673_4.join_into((v674_2).clone());
    }
    v673_4_cursor.ascend(1);
  }
  drop(v673_4_cursor);
  (v673_4).clone()
}

fn routine_49(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v682_4 = Space::new();
  let mut v682_4_cursor = (*s0).read_zipper();
  for v682_4_byte in v682_4_cursor.child_mask().iter() {
    v682_4_cursor.descend_to_byte(v682_4_byte);
    {
    let v682_4_tail = v682_4_cursor.fork_read_zipper();
    let v682_4_head = Path::from_slice(&[v682_4_byte]);
    let mut v683_2 = Space::new();
    let mut v683_2_cursor = (v682_4_tail).read_zipper();
    for v683_2_byte in v683_2_cursor.child_mask().iter() {
      v683_2_cursor.descend_to_byte(v683_2_byte);
      {
      let v683_2_tail = v683_2_cursor.fork_read_zipper();
      let v683_2_head = Path::from_slice(&[v683_2_byte]);
      let v684_2: Path = concat_path(&(v682_4_head),&(v683_2_head));
      let mut v684_3 = Space::new();
      let mut v684_3_cursor = (v683_2_tail).read_zipper();
      for v684_3_byte in v684_3_cursor.child_mask().iter() {
        v684_3_cursor.descend_to_byte(v684_3_byte);
        {
        let v684_3_tail = v684_3_cursor.fork_read_zipper();
        let v684_3_head = Path::from_slice(&[v684_3_byte]);
        let v685_2: Path = concat_path(&(v684_2),&(v684_3_head));
        let mut v685_3 = Space::new();
        let mut v685_3_cursor = (v684_3_tail).read_zipper();
        for v685_3_byte in v685_3_cursor.child_mask().iter() {
          v685_3_cursor.descend_to_byte(v685_3_byte);
          {
          let v685_3_tail = v685_3_cursor.fork_read_zipper();
          let v685_3_head = Path::from_slice(&[v685_3_byte]);
          let v686_2: Path = concat_path(&(v685_2),&(v685_3_head));
          let mut v686_3 = Space::new();
          let mut v686_3_cursor = (v685_3_tail).read_zipper();
          for v686_3_byte in v686_3_cursor.child_mask().iter() {
            v686_3_cursor.descend_to_byte(v686_3_byte);
            {
            let v686_3_tail = v686_3_cursor.fork_read_zipper();
            let v686_3_head = Path::from_slice(&[v686_3_byte]);
            let mut v687_2 = Space::new();
            let mut v687_2_cursor = (v686_3_tail).read_zipper();
            for v687_2_byte in v687_2_cursor.child_mask().iter() {
              v687_2_cursor.descend_to_byte(v687_2_byte);
              {
              let v687_2_tail = v687_2_cursor.fork_read_zipper();
              let v687_2_head = Path::from_slice(&[v687_2_byte]);
              let v688_2: Path = concat_path(&(v686_3_head),&(v687_2_head));
              let mut v688_3 = Space::new();
              let mut v688_3_cursor = (v687_2_tail).read_zipper();
              for v688_3_byte in v688_3_cursor.child_mask().iter() {
                v688_3_cursor.descend_to_byte(v688_3_byte);
                {
                let v688_3_tail = v688_3_cursor.fork_read_zipper();
                let v688_3_head = Path::from_slice(&[v688_3_byte]);
                let v689_2: Path = concat_path(&(v688_2),&(v688_3_head));
                let mut v689_3 = Space::new();
                let mut v689_3_cursor = (v688_3_tail).read_zipper();
                for v689_3_byte in v689_3_cursor.child_mask().iter() {
                  v689_3_cursor.descend_to_byte(v689_3_byte);
                  {
                  let v689_3_tail = v689_3_cursor.fork_read_zipper();
                  let v689_3_head = Path::from_slice(&[v689_3_byte]);
                  let v690_2: Path = concat_path(&(v689_2),&(v689_3_head));
                  let v690_3: Space = routine_67(c, &(v690_2), &(*p1), &(*p2), &(*p0), &(v686_2), &(v689_3_tail).make_space());
                  drop(v690_2);
                  v689_3.join_into((v690_3).clone());
                  }
                  v689_3_cursor.ascend(1);
                }
                drop(v689_3_cursor);
                drop(v689_2);
                v688_3.join_into((v689_3).clone());
                }
                v688_3_cursor.ascend(1);
              }
              drop(v688_3_cursor);
              drop(v688_2);
              v687_2.join_into((v688_3).clone());
              }
              v687_2_cursor.ascend(1);
            }
            drop(v687_2_cursor);
            v686_3.join_into((v687_2).clone());
            }
            v686_3_cursor.ascend(1);
          }
          drop(v686_3_cursor);
          drop(v686_2);
          v685_3.join_into((v686_3).clone());
          }
          v685_3_cursor.ascend(1);
        }
        drop(v685_3_cursor);
        drop(v685_2);
        v684_3.join_into((v685_3).clone());
        }
        v684_3_cursor.ascend(1);
      }
      drop(v684_3_cursor);
      drop(v684_2);
      v683_2.join_into((v684_3).clone());
      }
      v683_2_cursor.ascend(1);
    }
    drop(v683_2_cursor);
    v682_4.join_into((v683_2).clone());
    }
    v682_4_cursor.ascend(1);
  }
  drop(v682_4_cursor);
  (v682_4).clone()
}

fn routine_50(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v691_4 = Space::new();
  let mut v691_4_cursor = (*s0).read_zipper();
  for v691_4_byte in v691_4_cursor.child_mask().iter() {
    v691_4_cursor.descend_to_byte(v691_4_byte);
    {
    let v691_4_tail = v691_4_cursor.fork_read_zipper();
    let v691_4_head = Path::from_slice(&[v691_4_byte]);
    let mut v692_2 = Space::new();
    let mut v692_2_cursor = (v691_4_tail).read_zipper();
    for v692_2_byte in v692_2_cursor.child_mask().iter() {
      v692_2_cursor.descend_to_byte(v692_2_byte);
      {
      let v692_2_tail = v692_2_cursor.fork_read_zipper();
      let v692_2_head = Path::from_slice(&[v692_2_byte]);
      let v693_2: Path = concat_path(&(v691_4_head),&(v692_2_head));
      let mut v693_3 = Space::new();
      let mut v693_3_cursor = (v692_2_tail).read_zipper();
      for v693_3_byte in v693_3_cursor.child_mask().iter() {
        v693_3_cursor.descend_to_byte(v693_3_byte);
        {
        let v693_3_tail = v693_3_cursor.fork_read_zipper();
        let v693_3_head = Path::from_slice(&[v693_3_byte]);
        let v694_2: Path = concat_path(&(v693_2),&(v693_3_head));
        let mut v694_3 = Space::new();
        let mut v694_3_cursor = (v693_3_tail).read_zipper();
        for v694_3_byte in v694_3_cursor.child_mask().iter() {
          v694_3_cursor.descend_to_byte(v694_3_byte);
          {
          let v694_3_tail = v694_3_cursor.fork_read_zipper();
          let v694_3_head = Path::from_slice(&[v694_3_byte]);
          let v695_2: Path = concat_path(&(v694_2),&(v694_3_head));
          let mut v695_3 = Space::new();
          let mut v695_3_cursor = (v694_3_tail).read_zipper();
          for v695_3_byte in v695_3_cursor.child_mask().iter() {
            v695_3_cursor.descend_to_byte(v695_3_byte);
            {
            let v695_3_tail = v695_3_cursor.fork_read_zipper();
            let v695_3_head = Path::from_slice(&[v695_3_byte]);
            let mut v696_2 = Space::new();
            let mut v696_2_cursor = (v695_3_tail).read_zipper();
            for v696_2_byte in v696_2_cursor.child_mask().iter() {
              v696_2_cursor.descend_to_byte(v696_2_byte);
              {
              let v696_2_tail = v696_2_cursor.fork_read_zipper();
              let v696_2_head = Path::from_slice(&[v696_2_byte]);
              let v697_2: Path = concat_path(&(v695_3_head),&(v696_2_head));
              let mut v697_3 = Space::new();
              let mut v697_3_cursor = (v696_2_tail).read_zipper();
              for v697_3_byte in v697_3_cursor.child_mask().iter() {
                v697_3_cursor.descend_to_byte(v697_3_byte);
                {
                let v697_3_tail = v697_3_cursor.fork_read_zipper();
                let v697_3_head = Path::from_slice(&[v697_3_byte]);
                let v698_2: Path = concat_path(&(v697_2),&(v697_3_head));
                let mut v698_3 = Space::new();
                let mut v698_3_cursor = (v697_3_tail).read_zipper();
                for v698_3_byte in v698_3_cursor.child_mask().iter() {
                  v698_3_cursor.descend_to_byte(v698_3_byte);
                  {
                  let v698_3_tail = v698_3_cursor.fork_read_zipper();
                  let v698_3_head = Path::from_slice(&[v698_3_byte]);
                  let v699_2: Path = concat_path(&(v698_2),&(v698_3_head));
                  let v699_3: Space = routine_68(c, &(v699_2), &(*p1), &(*p2), &(*p0), &(v695_2), &(v698_3_tail).make_space());
                  drop(v699_2);
                  v698_3.join_into((v699_3).clone());
                  }
                  v698_3_cursor.ascend(1);
                }
                drop(v698_3_cursor);
                drop(v698_2);
                v697_3.join_into((v698_3).clone());
                }
                v697_3_cursor.ascend(1);
              }
              drop(v697_3_cursor);
              drop(v697_2);
              v696_2.join_into((v697_3).clone());
              }
              v696_2_cursor.ascend(1);
            }
            drop(v696_2_cursor);
            v695_3.join_into((v696_2).clone());
            }
            v695_3_cursor.ascend(1);
          }
          drop(v695_3_cursor);
          drop(v695_2);
          v694_3.join_into((v695_3).clone());
          }
          v694_3_cursor.ascend(1);
        }
        drop(v694_3_cursor);
        drop(v694_2);
        v693_3.join_into((v694_3).clone());
        }
        v693_3_cursor.ascend(1);
      }
      drop(v693_3_cursor);
      drop(v693_2);
      v692_2.join_into((v693_3).clone());
      }
      v692_2_cursor.ascend(1);
    }
    drop(v692_2_cursor);
    v691_4.join_into((v692_2).clone());
    }
    v691_4_cursor.ascend(1);
  }
  drop(v691_4_cursor);
  (v691_4).clone()
}

fn routine_51(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v700_4 = Space::new();
  let mut v700_4_cursor = (*s0).read_zipper();
  for v700_4_byte in v700_4_cursor.child_mask().iter() {
    v700_4_cursor.descend_to_byte(v700_4_byte);
    {
    let v700_4_tail = v700_4_cursor.fork_read_zipper();
    let v700_4_head = Path::from_slice(&[v700_4_byte]);
    let mut v701_2 = Space::new();
    let mut v701_2_cursor = (v700_4_tail).read_zipper();
    for v701_2_byte in v701_2_cursor.child_mask().iter() {
      v701_2_cursor.descend_to_byte(v701_2_byte);
      {
      let v701_2_tail = v701_2_cursor.fork_read_zipper();
      let v701_2_head = Path::from_slice(&[v701_2_byte]);
      let v702_2: Path = concat_path(&(v700_4_head),&(v701_2_head));
      let mut v702_3 = Space::new();
      let mut v702_3_cursor = (v701_2_tail).read_zipper();
      for v702_3_byte in v702_3_cursor.child_mask().iter() {
        v702_3_cursor.descend_to_byte(v702_3_byte);
        {
        let v702_3_tail = v702_3_cursor.fork_read_zipper();
        let v702_3_head = Path::from_slice(&[v702_3_byte]);
        let v703_2: Path = concat_path(&(v702_2),&(v702_3_head));
        let mut v703_3 = Space::new();
        let mut v703_3_cursor = (v702_3_tail).read_zipper();
        for v703_3_byte in v703_3_cursor.child_mask().iter() {
          v703_3_cursor.descend_to_byte(v703_3_byte);
          {
          let v703_3_tail = v703_3_cursor.fork_read_zipper();
          let v703_3_head = Path::from_slice(&[v703_3_byte]);
          let v704_2: Path = concat_path(&(v703_2),&(v703_3_head));
          let mut v704_3 = Space::new();
          let mut v704_3_cursor = (v703_3_tail).read_zipper();
          for v704_3_byte in v704_3_cursor.child_mask().iter() {
            v704_3_cursor.descend_to_byte(v704_3_byte);
            {
            let v704_3_tail = v704_3_cursor.fork_read_zipper();
            let v704_3_head = Path::from_slice(&[v704_3_byte]);
            let mut v705_2 = Space::new();
            let mut v705_2_cursor = (v704_3_tail).read_zipper();
            for v705_2_byte in v705_2_cursor.child_mask().iter() {
              v705_2_cursor.descend_to_byte(v705_2_byte);
              {
              let v705_2_tail = v705_2_cursor.fork_read_zipper();
              let v705_2_head = Path::from_slice(&[v705_2_byte]);
              let v706_2: Path = concat_path(&(v704_3_head),&(v705_2_head));
              let mut v706_3 = Space::new();
              let mut v706_3_cursor = (v705_2_tail).read_zipper();
              for v706_3_byte in v706_3_cursor.child_mask().iter() {
                v706_3_cursor.descend_to_byte(v706_3_byte);
                {
                let v706_3_tail = v706_3_cursor.fork_read_zipper();
                let v706_3_head = Path::from_slice(&[v706_3_byte]);
                let v707_2: Path = concat_path(&(v706_2),&(v706_3_head));
                let mut v707_3 = Space::new();
                let mut v707_3_cursor = (v706_3_tail).read_zipper();
                for v707_3_byte in v707_3_cursor.child_mask().iter() {
                  v707_3_cursor.descend_to_byte(v707_3_byte);
                  {
                  let v707_3_tail = v707_3_cursor.fork_read_zipper();
                  let v707_3_head = Path::from_slice(&[v707_3_byte]);
                  let v708_2: Path = concat_path(&(v707_2),&(v707_3_head));
                  let v708_3: Space = routine_69(c, &(v708_2), &(*p1), &(*p2), &(*p0), &(v704_2), &(v707_3_tail).make_space());
                  drop(v708_2);
                  v707_3.join_into((v708_3).clone());
                  }
                  v707_3_cursor.ascend(1);
                }
                drop(v707_3_cursor);
                drop(v707_2);
                v706_3.join_into((v707_3).clone());
                }
                v706_3_cursor.ascend(1);
              }
              drop(v706_3_cursor);
              drop(v706_2);
              v705_2.join_into((v706_3).clone());
              }
              v705_2_cursor.ascend(1);
            }
            drop(v705_2_cursor);
            v704_3.join_into((v705_2).clone());
            }
            v704_3_cursor.ascend(1);
          }
          drop(v704_3_cursor);
          drop(v704_2);
          v703_3.join_into((v704_3).clone());
          }
          v703_3_cursor.ascend(1);
        }
        drop(v703_3_cursor);
        drop(v703_2);
        v702_3.join_into((v703_3).clone());
        }
        v702_3_cursor.ascend(1);
      }
      drop(v702_3_cursor);
      drop(v702_2);
      v701_2.join_into((v702_3).clone());
      }
      v701_2_cursor.ascend(1);
    }
    drop(v701_2_cursor);
    v700_4.join_into((v701_2).clone());
    }
    v700_4_cursor.ascend(1);
  }
  drop(v700_4_cursor);
  (v700_4).clone()
}

fn routine_52(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v709_4 = Space::new();
  let mut v709_4_cursor = (*s0).read_zipper();
  for v709_4_byte in v709_4_cursor.child_mask().iter() {
    v709_4_cursor.descend_to_byte(v709_4_byte);
    {
    let v709_4_tail = v709_4_cursor.fork_read_zipper();
    let v709_4_head = Path::from_slice(&[v709_4_byte]);
    let mut v710_2 = Space::new();
    let mut v710_2_cursor = (v709_4_tail).read_zipper();
    for v710_2_byte in v710_2_cursor.child_mask().iter() {
      v710_2_cursor.descend_to_byte(v710_2_byte);
      {
      let v710_2_tail = v710_2_cursor.fork_read_zipper();
      let v710_2_head = Path::from_slice(&[v710_2_byte]);
      let v711_2: Path = concat_path(&(v709_4_head),&(v710_2_head));
      let mut v711_3 = Space::new();
      let mut v711_3_cursor = (v710_2_tail).read_zipper();
      for v711_3_byte in v711_3_cursor.child_mask().iter() {
        v711_3_cursor.descend_to_byte(v711_3_byte);
        {
        let v711_3_tail = v711_3_cursor.fork_read_zipper();
        let v711_3_head = Path::from_slice(&[v711_3_byte]);
        let v712_2: Path = concat_path(&(v711_2),&(v711_3_head));
        let mut v712_3 = Space::new();
        let mut v712_3_cursor = (v711_3_tail).read_zipper();
        for v712_3_byte in v712_3_cursor.child_mask().iter() {
          v712_3_cursor.descend_to_byte(v712_3_byte);
          {
          let v712_3_tail = v712_3_cursor.fork_read_zipper();
          let v712_3_head = Path::from_slice(&[v712_3_byte]);
          let v713_2: Path = concat_path(&(v712_2),&(v712_3_head));
          let mut v713_3 = Space::new();
          let mut v713_3_cursor = (v712_3_tail).read_zipper();
          for v713_3_byte in v713_3_cursor.child_mask().iter() {
            v713_3_cursor.descend_to_byte(v713_3_byte);
            {
            let v713_3_tail = v713_3_cursor.fork_read_zipper();
            let v713_3_head = Path::from_slice(&[v713_3_byte]);
            let mut v714_2 = Space::new();
            let mut v714_2_cursor = (v713_3_tail).read_zipper();
            for v714_2_byte in v714_2_cursor.child_mask().iter() {
              v714_2_cursor.descend_to_byte(v714_2_byte);
              {
              let v714_2_tail = v714_2_cursor.fork_read_zipper();
              let v714_2_head = Path::from_slice(&[v714_2_byte]);
              let v715_2: Path = concat_path(&(v713_3_head),&(v714_2_head));
              let mut v715_3 = Space::new();
              let mut v715_3_cursor = (v714_2_tail).read_zipper();
              for v715_3_byte in v715_3_cursor.child_mask().iter() {
                v715_3_cursor.descend_to_byte(v715_3_byte);
                {
                let v715_3_tail = v715_3_cursor.fork_read_zipper();
                let v715_3_head = Path::from_slice(&[v715_3_byte]);
                let v716_2: Path = concat_path(&(v715_2),&(v715_3_head));
                let mut v716_3 = Space::new();
                let mut v716_3_cursor = (v715_3_tail).read_zipper();
                for v716_3_byte in v716_3_cursor.child_mask().iter() {
                  v716_3_cursor.descend_to_byte(v716_3_byte);
                  {
                  let v716_3_tail = v716_3_cursor.fork_read_zipper();
                  let v716_3_head = Path::from_slice(&[v716_3_byte]);
                  let v717_2: Path = concat_path(&(v716_2),&(v716_3_head));
                  let v717_3: Space = routine_70(c, &(v717_2), &(*p1), &(*p2), &(*p0), &(v713_2), &(v716_3_tail).make_space());
                  drop(v717_2);
                  v716_3.join_into((v717_3).clone());
                  }
                  v716_3_cursor.ascend(1);
                }
                drop(v716_3_cursor);
                drop(v716_2);
                v715_3.join_into((v716_3).clone());
                }
                v715_3_cursor.ascend(1);
              }
              drop(v715_3_cursor);
              drop(v715_2);
              v714_2.join_into((v715_3).clone());
              }
              v714_2_cursor.ascend(1);
            }
            drop(v714_2_cursor);
            v713_3.join_into((v714_2).clone());
            }
            v713_3_cursor.ascend(1);
          }
          drop(v713_3_cursor);
          drop(v713_2);
          v712_3.join_into((v713_3).clone());
          }
          v712_3_cursor.ascend(1);
        }
        drop(v712_3_cursor);
        drop(v712_2);
        v711_3.join_into((v712_3).clone());
        }
        v711_3_cursor.ascend(1);
      }
      drop(v711_3_cursor);
      drop(v711_2);
      v710_2.join_into((v711_3).clone());
      }
      v710_2_cursor.ascend(1);
    }
    drop(v710_2_cursor);
    v709_4.join_into((v710_2).clone());
    }
    v709_4_cursor.ascend(1);
  }
  drop(v709_4_cursor);
  (v709_4).clone()
}

fn routine_53(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v718_4 = Space::new();
  let mut v718_4_cursor = (*s0).read_zipper();
  for v718_4_byte in v718_4_cursor.child_mask().iter() {
    v718_4_cursor.descend_to_byte(v718_4_byte);
    {
    let v718_4_tail = v718_4_cursor.fork_read_zipper();
    let v718_4_head = Path::from_slice(&[v718_4_byte]);
    let mut v719_2 = Space::new();
    let mut v719_2_cursor = (v718_4_tail).read_zipper();
    for v719_2_byte in v719_2_cursor.child_mask().iter() {
      v719_2_cursor.descend_to_byte(v719_2_byte);
      {
      let v719_2_tail = v719_2_cursor.fork_read_zipper();
      let v719_2_head = Path::from_slice(&[v719_2_byte]);
      let v720_2: Path = concat_path(&(v718_4_head),&(v719_2_head));
      let mut v720_3 = Space::new();
      let mut v720_3_cursor = (v719_2_tail).read_zipper();
      for v720_3_byte in v720_3_cursor.child_mask().iter() {
        v720_3_cursor.descend_to_byte(v720_3_byte);
        {
        let v720_3_tail = v720_3_cursor.fork_read_zipper();
        let v720_3_head = Path::from_slice(&[v720_3_byte]);
        let v721_2: Path = concat_path(&(v720_2),&(v720_3_head));
        let mut v721_3 = Space::new();
        let mut v721_3_cursor = (v720_3_tail).read_zipper();
        for v721_3_byte in v721_3_cursor.child_mask().iter() {
          v721_3_cursor.descend_to_byte(v721_3_byte);
          {
          let v721_3_tail = v721_3_cursor.fork_read_zipper();
          let v721_3_head = Path::from_slice(&[v721_3_byte]);
          let v722_2: Path = concat_path(&(v721_2),&(v721_3_head));
          let mut v722_3 = Space::new();
          let mut v722_3_cursor = (v721_3_tail).read_zipper();
          for v722_3_byte in v722_3_cursor.child_mask().iter() {
            v722_3_cursor.descend_to_byte(v722_3_byte);
            {
            let v722_3_tail = v722_3_cursor.fork_read_zipper();
            let v722_3_head = Path::from_slice(&[v722_3_byte]);
            let mut v723_2 = Space::new();
            let mut v723_2_cursor = (v722_3_tail).read_zipper();
            for v723_2_byte in v723_2_cursor.child_mask().iter() {
              v723_2_cursor.descend_to_byte(v723_2_byte);
              {
              let v723_2_tail = v723_2_cursor.fork_read_zipper();
              let v723_2_head = Path::from_slice(&[v723_2_byte]);
              let v724_2: Path = concat_path(&(v722_3_head),&(v723_2_head));
              let mut v724_3 = Space::new();
              let mut v724_3_cursor = (v723_2_tail).read_zipper();
              for v724_3_byte in v724_3_cursor.child_mask().iter() {
                v724_3_cursor.descend_to_byte(v724_3_byte);
                {
                let v724_3_tail = v724_3_cursor.fork_read_zipper();
                let v724_3_head = Path::from_slice(&[v724_3_byte]);
                let v725_2: Path = concat_path(&(v724_2),&(v724_3_head));
                let mut v725_3 = Space::new();
                let mut v725_3_cursor = (v724_3_tail).read_zipper();
                for v725_3_byte in v725_3_cursor.child_mask().iter() {
                  v725_3_cursor.descend_to_byte(v725_3_byte);
                  {
                  let v725_3_tail = v725_3_cursor.fork_read_zipper();
                  let v725_3_head = Path::from_slice(&[v725_3_byte]);
                  let v726_2: Path = concat_path(&(v725_2),&(v725_3_head));
                  let v726_3: Space = routine_71(c, &(v726_2), &(*p1), &(*p2), &(*p0), &(v722_2), &(v725_3_tail).make_space());
                  drop(v726_2);
                  v725_3.join_into((v726_3).clone());
                  }
                  v725_3_cursor.ascend(1);
                }
                drop(v725_3_cursor);
                drop(v725_2);
                v724_3.join_into((v725_3).clone());
                }
                v724_3_cursor.ascend(1);
              }
              drop(v724_3_cursor);
              drop(v724_2);
              v723_2.join_into((v724_3).clone());
              }
              v723_2_cursor.ascend(1);
            }
            drop(v723_2_cursor);
            v722_3.join_into((v723_2).clone());
            }
            v722_3_cursor.ascend(1);
          }
          drop(v722_3_cursor);
          drop(v722_2);
          v721_3.join_into((v722_3).clone());
          }
          v721_3_cursor.ascend(1);
        }
        drop(v721_3_cursor);
        drop(v721_2);
        v720_3.join_into((v721_3).clone());
        }
        v720_3_cursor.ascend(1);
      }
      drop(v720_3_cursor);
      drop(v720_2);
      v719_2.join_into((v720_3).clone());
      }
      v719_2_cursor.ascend(1);
    }
    drop(v719_2_cursor);
    v718_4.join_into((v719_2).clone());
    }
    v718_4_cursor.ascend(1);
  }
  drop(v718_4_cursor);
  (v718_4).clone()
}

fn routine_54(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v727_4 = Space::new();
  let mut v727_4_cursor = (*s0).read_zipper();
  for v727_4_byte in v727_4_cursor.child_mask().iter() {
    v727_4_cursor.descend_to_byte(v727_4_byte);
    {
    let v727_4_tail = v727_4_cursor.fork_read_zipper();
    let v727_4_head = Path::from_slice(&[v727_4_byte]);
    let mut v728_2 = Space::new();
    let mut v728_2_cursor = (v727_4_tail).read_zipper();
    for v728_2_byte in v728_2_cursor.child_mask().iter() {
      v728_2_cursor.descend_to_byte(v728_2_byte);
      {
      let v728_2_tail = v728_2_cursor.fork_read_zipper();
      let v728_2_head = Path::from_slice(&[v728_2_byte]);
      let v729_2: Path = concat_path(&(v727_4_head),&(v728_2_head));
      let mut v729_3 = Space::new();
      let mut v729_3_cursor = (v728_2_tail).read_zipper();
      for v729_3_byte in v729_3_cursor.child_mask().iter() {
        v729_3_cursor.descend_to_byte(v729_3_byte);
        {
        let v729_3_tail = v729_3_cursor.fork_read_zipper();
        let v729_3_head = Path::from_slice(&[v729_3_byte]);
        let v730_2: Path = concat_path(&(v729_2),&(v729_3_head));
        let mut v730_3 = Space::new();
        let mut v730_3_cursor = (v729_3_tail).read_zipper();
        for v730_3_byte in v730_3_cursor.child_mask().iter() {
          v730_3_cursor.descend_to_byte(v730_3_byte);
          {
          let v730_3_tail = v730_3_cursor.fork_read_zipper();
          let v730_3_head = Path::from_slice(&[v730_3_byte]);
          let v731_2: Path = concat_path(&(v730_2),&(v730_3_head));
          let mut v731_3 = Space::new();
          let mut v731_3_cursor = (v730_3_tail).read_zipper();
          for v731_3_byte in v731_3_cursor.child_mask().iter() {
            v731_3_cursor.descend_to_byte(v731_3_byte);
            {
            let v731_3_tail = v731_3_cursor.fork_read_zipper();
            let v731_3_head = Path::from_slice(&[v731_3_byte]);
            let mut v732_2 = Space::new();
            let mut v732_2_cursor = (v731_3_tail).read_zipper();
            for v732_2_byte in v732_2_cursor.child_mask().iter() {
              v732_2_cursor.descend_to_byte(v732_2_byte);
              {
              let v732_2_tail = v732_2_cursor.fork_read_zipper();
              let v732_2_head = Path::from_slice(&[v732_2_byte]);
              let v733_2: Path = concat_path(&(v731_3_head),&(v732_2_head));
              let mut v733_3 = Space::new();
              let mut v733_3_cursor = (v732_2_tail).read_zipper();
              for v733_3_byte in v733_3_cursor.child_mask().iter() {
                v733_3_cursor.descend_to_byte(v733_3_byte);
                {
                let v733_3_tail = v733_3_cursor.fork_read_zipper();
                let v733_3_head = Path::from_slice(&[v733_3_byte]);
                let v734_2: Path = concat_path(&(v733_2),&(v733_3_head));
                let mut v734_3 = Space::new();
                let mut v734_3_cursor = (v733_3_tail).read_zipper();
                for v734_3_byte in v734_3_cursor.child_mask().iter() {
                  v734_3_cursor.descend_to_byte(v734_3_byte);
                  {
                  let v734_3_tail = v734_3_cursor.fork_read_zipper();
                  let v734_3_head = Path::from_slice(&[v734_3_byte]);
                  let v735_2: Path = concat_path(&(v734_2),&(v734_3_head));
                  let v735_3: Space = routine_72(c, &(v735_2), &(*p1), &(*p2), &(*p0), &(v731_2), &(v734_3_tail).make_space());
                  drop(v735_2);
                  v734_3.join_into((v735_3).clone());
                  }
                  v734_3_cursor.ascend(1);
                }
                drop(v734_3_cursor);
                drop(v734_2);
                v733_3.join_into((v734_3).clone());
                }
                v733_3_cursor.ascend(1);
              }
              drop(v733_3_cursor);
              drop(v733_2);
              v732_2.join_into((v733_3).clone());
              }
              v732_2_cursor.ascend(1);
            }
            drop(v732_2_cursor);
            v731_3.join_into((v732_2).clone());
            }
            v731_3_cursor.ascend(1);
          }
          drop(v731_3_cursor);
          drop(v731_2);
          v730_3.join_into((v731_3).clone());
          }
          v730_3_cursor.ascend(1);
        }
        drop(v730_3_cursor);
        drop(v730_2);
        v729_3.join_into((v730_3).clone());
        }
        v729_3_cursor.ascend(1);
      }
      drop(v729_3_cursor);
      drop(v729_2);
      v728_2.join_into((v729_3).clone());
      }
      v728_2_cursor.ascend(1);
    }
    drop(v728_2_cursor);
    v727_4.join_into((v728_2).clone());
    }
    v727_4_cursor.ascend(1);
  }
  drop(v727_4_cursor);
  (v727_4).clone()
}

fn routine_55(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v736_4 = Space::new();
  let mut v736_4_cursor = (*s0).read_zipper();
  for v736_4_byte in v736_4_cursor.child_mask().iter() {
    v736_4_cursor.descend_to_byte(v736_4_byte);
    {
    let v736_4_tail = v736_4_cursor.fork_read_zipper();
    let v736_4_head = Path::from_slice(&[v736_4_byte]);
    let mut v737_2 = Space::new();
    let mut v737_2_cursor = (v736_4_tail).read_zipper();
    for v737_2_byte in v737_2_cursor.child_mask().iter() {
      v737_2_cursor.descend_to_byte(v737_2_byte);
      {
      let v737_2_tail = v737_2_cursor.fork_read_zipper();
      let v737_2_head = Path::from_slice(&[v737_2_byte]);
      let v738_2: Path = concat_path(&(v736_4_head),&(v737_2_head));
      let mut v738_3 = Space::new();
      let mut v738_3_cursor = (v737_2_tail).read_zipper();
      for v738_3_byte in v738_3_cursor.child_mask().iter() {
        v738_3_cursor.descend_to_byte(v738_3_byte);
        {
        let v738_3_tail = v738_3_cursor.fork_read_zipper();
        let v738_3_head = Path::from_slice(&[v738_3_byte]);
        let v739_2: Path = concat_path(&(v738_2),&(v738_3_head));
        let mut v739_3 = Space::new();
        let mut v739_3_cursor = (v738_3_tail).read_zipper();
        for v739_3_byte in v739_3_cursor.child_mask().iter() {
          v739_3_cursor.descend_to_byte(v739_3_byte);
          {
          let v739_3_tail = v739_3_cursor.fork_read_zipper();
          let v739_3_head = Path::from_slice(&[v739_3_byte]);
          let v740_2: Path = concat_path(&(v739_2),&(v739_3_head));
          let mut v740_3 = Space::new();
          let mut v740_3_cursor = (v739_3_tail).read_zipper();
          for v740_3_byte in v740_3_cursor.child_mask().iter() {
            v740_3_cursor.descend_to_byte(v740_3_byte);
            {
            let v740_3_tail = v740_3_cursor.fork_read_zipper();
            let v740_3_head = Path::from_slice(&[v740_3_byte]);
            let mut v741_2 = Space::new();
            let mut v741_2_cursor = (v740_3_tail).read_zipper();
            for v741_2_byte in v741_2_cursor.child_mask().iter() {
              v741_2_cursor.descend_to_byte(v741_2_byte);
              {
              let v741_2_tail = v741_2_cursor.fork_read_zipper();
              let v741_2_head = Path::from_slice(&[v741_2_byte]);
              let v742_2: Path = concat_path(&(v740_3_head),&(v741_2_head));
              let mut v742_3 = Space::new();
              let mut v742_3_cursor = (v741_2_tail).read_zipper();
              for v742_3_byte in v742_3_cursor.child_mask().iter() {
                v742_3_cursor.descend_to_byte(v742_3_byte);
                {
                let v742_3_tail = v742_3_cursor.fork_read_zipper();
                let v742_3_head = Path::from_slice(&[v742_3_byte]);
                let v743_2: Path = concat_path(&(v742_2),&(v742_3_head));
                let mut v743_3 = Space::new();
                let mut v743_3_cursor = (v742_3_tail).read_zipper();
                for v743_3_byte in v743_3_cursor.child_mask().iter() {
                  v743_3_cursor.descend_to_byte(v743_3_byte);
                  {
                  let v743_3_tail = v743_3_cursor.fork_read_zipper();
                  let v743_3_head = Path::from_slice(&[v743_3_byte]);
                  let v744_2: Path = concat_path(&(v743_2),&(v743_3_head));
                  let v744_3: Space = routine_73(c, &(v744_2), &(*p1), &(*p2), &(*p0), &(v740_2), &(v743_3_tail).make_space());
                  drop(v744_2);
                  v743_3.join_into((v744_3).clone());
                  }
                  v743_3_cursor.ascend(1);
                }
                drop(v743_3_cursor);
                drop(v743_2);
                v742_3.join_into((v743_3).clone());
                }
                v742_3_cursor.ascend(1);
              }
              drop(v742_3_cursor);
              drop(v742_2);
              v741_2.join_into((v742_3).clone());
              }
              v741_2_cursor.ascend(1);
            }
            drop(v741_2_cursor);
            v740_3.join_into((v741_2).clone());
            }
            v740_3_cursor.ascend(1);
          }
          drop(v740_3_cursor);
          drop(v740_2);
          v739_3.join_into((v740_3).clone());
          }
          v739_3_cursor.ascend(1);
        }
        drop(v739_3_cursor);
        drop(v739_2);
        v738_3.join_into((v739_3).clone());
        }
        v738_3_cursor.ascend(1);
      }
      drop(v738_3_cursor);
      drop(v738_2);
      v737_2.join_into((v738_3).clone());
      }
      v737_2_cursor.ascend(1);
    }
    drop(v737_2_cursor);
    v736_4.join_into((v737_2).clone());
    }
    v736_4_cursor.ascend(1);
  }
  drop(v736_4_cursor);
  (v736_4).clone()
}

fn routine_56(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v745_4 = Space::new();
  let mut v745_4_cursor = (*s0).read_zipper();
  for v745_4_byte in v745_4_cursor.child_mask().iter() {
    v745_4_cursor.descend_to_byte(v745_4_byte);
    {
    let v745_4_tail = v745_4_cursor.fork_read_zipper();
    let v745_4_head = Path::from_slice(&[v745_4_byte]);
    let mut v746_2 = Space::new();
    let mut v746_2_cursor = (v745_4_tail).read_zipper();
    for v746_2_byte in v746_2_cursor.child_mask().iter() {
      v746_2_cursor.descend_to_byte(v746_2_byte);
      {
      let v746_2_tail = v746_2_cursor.fork_read_zipper();
      let v746_2_head = Path::from_slice(&[v746_2_byte]);
      let v747_2: Path = concat_path(&(v745_4_head),&(v746_2_head));
      let mut v747_3 = Space::new();
      let mut v747_3_cursor = (v746_2_tail).read_zipper();
      for v747_3_byte in v747_3_cursor.child_mask().iter() {
        v747_3_cursor.descend_to_byte(v747_3_byte);
        {
        let v747_3_tail = v747_3_cursor.fork_read_zipper();
        let v747_3_head = Path::from_slice(&[v747_3_byte]);
        let v748_2: Path = concat_path(&(v747_2),&(v747_3_head));
        let mut v748_3 = Space::new();
        let mut v748_3_cursor = (v747_3_tail).read_zipper();
        for v748_3_byte in v748_3_cursor.child_mask().iter() {
          v748_3_cursor.descend_to_byte(v748_3_byte);
          {
          let v748_3_tail = v748_3_cursor.fork_read_zipper();
          let v748_3_head = Path::from_slice(&[v748_3_byte]);
          let v749_2: Path = concat_path(&(v748_2),&(v748_3_head));
          let mut v749_3 = Space::new();
          let mut v749_3_cursor = (v748_3_tail).read_zipper();
          for v749_3_byte in v749_3_cursor.child_mask().iter() {
            v749_3_cursor.descend_to_byte(v749_3_byte);
            {
            let v749_3_tail = v749_3_cursor.fork_read_zipper();
            let v749_3_head = Path::from_slice(&[v749_3_byte]);
            let mut v750_2 = Space::new();
            let mut v750_2_cursor = (v749_3_tail).read_zipper();
            for v750_2_byte in v750_2_cursor.child_mask().iter() {
              v750_2_cursor.descend_to_byte(v750_2_byte);
              {
              let v750_2_tail = v750_2_cursor.fork_read_zipper();
              let v750_2_head = Path::from_slice(&[v750_2_byte]);
              let v751_2: Path = concat_path(&(v749_3_head),&(v750_2_head));
              let mut v751_3 = Space::new();
              let mut v751_3_cursor = (v750_2_tail).read_zipper();
              for v751_3_byte in v751_3_cursor.child_mask().iter() {
                v751_3_cursor.descend_to_byte(v751_3_byte);
                {
                let v751_3_tail = v751_3_cursor.fork_read_zipper();
                let v751_3_head = Path::from_slice(&[v751_3_byte]);
                let v752_2: Path = concat_path(&(v751_2),&(v751_3_head));
                let mut v752_3 = Space::new();
                let mut v752_3_cursor = (v751_3_tail).read_zipper();
                for v752_3_byte in v752_3_cursor.child_mask().iter() {
                  v752_3_cursor.descend_to_byte(v752_3_byte);
                  {
                  let v752_3_tail = v752_3_cursor.fork_read_zipper();
                  let v752_3_head = Path::from_slice(&[v752_3_byte]);
                  let v753_2: Path = concat_path(&(v752_2),&(v752_3_head));
                  let v753_3: Space = routine_74(c, &(v753_2), &(*p1), &(*p2), &(*p0), &(v749_2), &(v752_3_tail).make_space());
                  drop(v753_2);
                  v752_3.join_into((v753_3).clone());
                  }
                  v752_3_cursor.ascend(1);
                }
                drop(v752_3_cursor);
                drop(v752_2);
                v751_3.join_into((v752_3).clone());
                }
                v751_3_cursor.ascend(1);
              }
              drop(v751_3_cursor);
              drop(v751_2);
              v750_2.join_into((v751_3).clone());
              }
              v750_2_cursor.ascend(1);
            }
            drop(v750_2_cursor);
            v749_3.join_into((v750_2).clone());
            }
            v749_3_cursor.ascend(1);
          }
          drop(v749_3_cursor);
          drop(v749_2);
          v748_3.join_into((v749_3).clone());
          }
          v748_3_cursor.ascend(1);
        }
        drop(v748_3_cursor);
        drop(v748_2);
        v747_3.join_into((v748_3).clone());
        }
        v747_3_cursor.ascend(1);
      }
      drop(v747_3_cursor);
      drop(v747_2);
      v746_2.join_into((v747_3).clone());
      }
      v746_2_cursor.ascend(1);
    }
    drop(v746_2_cursor);
    v745_4.join_into((v746_2).clone());
    }
    v745_4_cursor.ascend(1);
  }
  drop(v745_4_cursor);
  (v745_4).clone()
}

fn routine_57(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v754_4 = Space::new();
  let mut v754_4_cursor = (*s0).read_zipper();
  for v754_4_byte in v754_4_cursor.child_mask().iter() {
    v754_4_cursor.descend_to_byte(v754_4_byte);
    {
    let v754_4_tail = v754_4_cursor.fork_read_zipper();
    let v754_4_head = Path::from_slice(&[v754_4_byte]);
    let mut v755_2 = Space::new();
    let mut v755_2_cursor = (v754_4_tail).read_zipper();
    for v755_2_byte in v755_2_cursor.child_mask().iter() {
      v755_2_cursor.descend_to_byte(v755_2_byte);
      {
      let v755_2_tail = v755_2_cursor.fork_read_zipper();
      let v755_2_head = Path::from_slice(&[v755_2_byte]);
      let v756_2: Path = concat_path(&(v754_4_head),&(v755_2_head));
      let mut v756_3 = Space::new();
      let mut v756_3_cursor = (v755_2_tail).read_zipper();
      for v756_3_byte in v756_3_cursor.child_mask().iter() {
        v756_3_cursor.descend_to_byte(v756_3_byte);
        {
        let v756_3_tail = v756_3_cursor.fork_read_zipper();
        let v756_3_head = Path::from_slice(&[v756_3_byte]);
        let v757_2: Path = concat_path(&(v756_2),&(v756_3_head));
        let mut v757_3 = Space::new();
        let mut v757_3_cursor = (v756_3_tail).read_zipper();
        for v757_3_byte in v757_3_cursor.child_mask().iter() {
          v757_3_cursor.descend_to_byte(v757_3_byte);
          {
          let v757_3_tail = v757_3_cursor.fork_read_zipper();
          let v757_3_head = Path::from_slice(&[v757_3_byte]);
          let v758_2: Path = concat_path(&(v757_2),&(v757_3_head));
          let mut v758_3 = Space::new();
          let mut v758_3_cursor = (v757_3_tail).read_zipper();
          for v758_3_byte in v758_3_cursor.child_mask().iter() {
            v758_3_cursor.descend_to_byte(v758_3_byte);
            {
            let v758_3_tail = v758_3_cursor.fork_read_zipper();
            let v758_3_head = Path::from_slice(&[v758_3_byte]);
            let mut v759_2 = Space::new();
            let mut v759_2_cursor = (v758_3_tail).read_zipper();
            for v759_2_byte in v759_2_cursor.child_mask().iter() {
              v759_2_cursor.descend_to_byte(v759_2_byte);
              {
              let v759_2_tail = v759_2_cursor.fork_read_zipper();
              let v759_2_head = Path::from_slice(&[v759_2_byte]);
              let v760_2: Path = concat_path(&(v758_3_head),&(v759_2_head));
              let mut v760_3 = Space::new();
              let mut v760_3_cursor = (v759_2_tail).read_zipper();
              for v760_3_byte in v760_3_cursor.child_mask().iter() {
                v760_3_cursor.descend_to_byte(v760_3_byte);
                {
                let v760_3_tail = v760_3_cursor.fork_read_zipper();
                let v760_3_head = Path::from_slice(&[v760_3_byte]);
                let v761_2: Path = concat_path(&(v760_2),&(v760_3_head));
                let mut v761_3 = Space::new();
                let mut v761_3_cursor = (v760_3_tail).read_zipper();
                for v761_3_byte in v761_3_cursor.child_mask().iter() {
                  v761_3_cursor.descend_to_byte(v761_3_byte);
                  {
                  let v761_3_tail = v761_3_cursor.fork_read_zipper();
                  let v761_3_head = Path::from_slice(&[v761_3_byte]);
                  let v762_2: Path = concat_path(&(v761_2),&(v761_3_head));
                  let v762_3: Space = routine_75(c, &(v762_2), &(*p1), &(*p2), &(*p0), &(v758_2), &(v761_3_tail).make_space());
                  drop(v762_2);
                  v761_3.join_into((v762_3).clone());
                  }
                  v761_3_cursor.ascend(1);
                }
                drop(v761_3_cursor);
                drop(v761_2);
                v760_3.join_into((v761_3).clone());
                }
                v760_3_cursor.ascend(1);
              }
              drop(v760_3_cursor);
              drop(v760_2);
              v759_2.join_into((v760_3).clone());
              }
              v759_2_cursor.ascend(1);
            }
            drop(v759_2_cursor);
            v758_3.join_into((v759_2).clone());
            }
            v758_3_cursor.ascend(1);
          }
          drop(v758_3_cursor);
          drop(v758_2);
          v757_3.join_into((v758_3).clone());
          }
          v757_3_cursor.ascend(1);
        }
        drop(v757_3_cursor);
        drop(v757_2);
        v756_3.join_into((v757_3).clone());
        }
        v756_3_cursor.ascend(1);
      }
      drop(v756_3_cursor);
      drop(v756_2);
      v755_2.join_into((v756_3).clone());
      }
      v755_2_cursor.ascend(1);
    }
    drop(v755_2_cursor);
    v754_4.join_into((v755_2).clone());
    }
    v754_4_cursor.ascend(1);
  }
  drop(v754_4_cursor);
  (v754_4).clone()
}

fn routine_58(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v763_4 = Space::new();
  let mut v763_4_cursor = (*s0).read_zipper();
  for v763_4_byte in v763_4_cursor.child_mask().iter() {
    v763_4_cursor.descend_to_byte(v763_4_byte);
    {
    let v763_4_tail = v763_4_cursor.fork_read_zipper();
    let v763_4_head = Path::from_slice(&[v763_4_byte]);
    let mut v764_2 = Space::new();
    let mut v764_2_cursor = (v763_4_tail).read_zipper();
    for v764_2_byte in v764_2_cursor.child_mask().iter() {
      v764_2_cursor.descend_to_byte(v764_2_byte);
      {
      let v764_2_tail = v764_2_cursor.fork_read_zipper();
      let v764_2_head = Path::from_slice(&[v764_2_byte]);
      let v765_2: Path = concat_path(&(v763_4_head),&(v764_2_head));
      let mut v765_3 = Space::new();
      let mut v765_3_cursor = (v764_2_tail).read_zipper();
      for v765_3_byte in v765_3_cursor.child_mask().iter() {
        v765_3_cursor.descend_to_byte(v765_3_byte);
        {
        let v765_3_tail = v765_3_cursor.fork_read_zipper();
        let v765_3_head = Path::from_slice(&[v765_3_byte]);
        let v766_2: Path = concat_path(&(v765_2),&(v765_3_head));
        let mut v766_3 = Space::new();
        let mut v766_3_cursor = (v765_3_tail).read_zipper();
        for v766_3_byte in v766_3_cursor.child_mask().iter() {
          v766_3_cursor.descend_to_byte(v766_3_byte);
          {
          let v766_3_tail = v766_3_cursor.fork_read_zipper();
          let v766_3_head = Path::from_slice(&[v766_3_byte]);
          let v767_2: Path = concat_path(&(v766_2),&(v766_3_head));
          let mut v767_3 = Space::new();
          let mut v767_3_cursor = (v766_3_tail).read_zipper();
          for v767_3_byte in v767_3_cursor.child_mask().iter() {
            v767_3_cursor.descend_to_byte(v767_3_byte);
            {
            let v767_3_tail = v767_3_cursor.fork_read_zipper();
            let v767_3_head = Path::from_slice(&[v767_3_byte]);
            let mut v768_2 = Space::new();
            let mut v768_2_cursor = (v767_3_tail).read_zipper();
            for v768_2_byte in v768_2_cursor.child_mask().iter() {
              v768_2_cursor.descend_to_byte(v768_2_byte);
              {
              let v768_2_tail = v768_2_cursor.fork_read_zipper();
              let v768_2_head = Path::from_slice(&[v768_2_byte]);
              let v769_2: Path = concat_path(&(v767_3_head),&(v768_2_head));
              let mut v769_3 = Space::new();
              let mut v769_3_cursor = (v768_2_tail).read_zipper();
              for v769_3_byte in v769_3_cursor.child_mask().iter() {
                v769_3_cursor.descend_to_byte(v769_3_byte);
                {
                let v769_3_tail = v769_3_cursor.fork_read_zipper();
                let v769_3_head = Path::from_slice(&[v769_3_byte]);
                let v770_2: Path = concat_path(&(v769_2),&(v769_3_head));
                let mut v770_3 = Space::new();
                let mut v770_3_cursor = (v769_3_tail).read_zipper();
                for v770_3_byte in v770_3_cursor.child_mask().iter() {
                  v770_3_cursor.descend_to_byte(v770_3_byte);
                  {
                  let v770_3_tail = v770_3_cursor.fork_read_zipper();
                  let v770_3_head = Path::from_slice(&[v770_3_byte]);
                  let v771_2: Path = concat_path(&(v770_2),&(v770_3_head));
                  let v771_3: Space = routine_76(c, &(v771_2), &(*p1), &(*p2), &(*p0), &(v767_2), &(v770_3_tail).make_space());
                  drop(v771_2);
                  v770_3.join_into((v771_3).clone());
                  }
                  v770_3_cursor.ascend(1);
                }
                drop(v770_3_cursor);
                drop(v770_2);
                v769_3.join_into((v770_3).clone());
                }
                v769_3_cursor.ascend(1);
              }
              drop(v769_3_cursor);
              drop(v769_2);
              v768_2.join_into((v769_3).clone());
              }
              v768_2_cursor.ascend(1);
            }
            drop(v768_2_cursor);
            v767_3.join_into((v768_2).clone());
            }
            v767_3_cursor.ascend(1);
          }
          drop(v767_3_cursor);
          drop(v767_2);
          v766_3.join_into((v767_3).clone());
          }
          v766_3_cursor.ascend(1);
        }
        drop(v766_3_cursor);
        drop(v766_2);
        v765_3.join_into((v766_3).clone());
        }
        v765_3_cursor.ascend(1);
      }
      drop(v765_3_cursor);
      drop(v765_2);
      v764_2.join_into((v765_3).clone());
      }
      v764_2_cursor.ascend(1);
    }
    drop(v764_2_cursor);
    v763_4.join_into((v764_2).clone());
    }
    v763_4_cursor.ascend(1);
  }
  drop(v763_4_cursor);
  (v763_4).clone()
}

fn routine_59(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v772_4 = Space::new();
  let mut v772_4_cursor = (*s0).read_zipper();
  for v772_4_byte in v772_4_cursor.child_mask().iter() {
    v772_4_cursor.descend_to_byte(v772_4_byte);
    {
    let v772_4_tail = v772_4_cursor.fork_read_zipper();
    let v772_4_head = Path::from_slice(&[v772_4_byte]);
    let mut v773_2 = Space::new();
    let mut v773_2_cursor = (v772_4_tail).read_zipper();
    for v773_2_byte in v773_2_cursor.child_mask().iter() {
      v773_2_cursor.descend_to_byte(v773_2_byte);
      {
      let v773_2_tail = v773_2_cursor.fork_read_zipper();
      let v773_2_head = Path::from_slice(&[v773_2_byte]);
      let v774_2: Path = concat_path(&(v772_4_head),&(v773_2_head));
      let mut v774_3 = Space::new();
      let mut v774_3_cursor = (v773_2_tail).read_zipper();
      for v774_3_byte in v774_3_cursor.child_mask().iter() {
        v774_3_cursor.descend_to_byte(v774_3_byte);
        {
        let v774_3_tail = v774_3_cursor.fork_read_zipper();
        let v774_3_head = Path::from_slice(&[v774_3_byte]);
        let v775_2: Path = concat_path(&(v774_2),&(v774_3_head));
        let mut v775_3 = Space::new();
        let mut v775_3_cursor = (v774_3_tail).read_zipper();
        for v775_3_byte in v775_3_cursor.child_mask().iter() {
          v775_3_cursor.descend_to_byte(v775_3_byte);
          {
          let v775_3_tail = v775_3_cursor.fork_read_zipper();
          let v775_3_head = Path::from_slice(&[v775_3_byte]);
          let v776_2: Path = concat_path(&(v775_2),&(v775_3_head));
          let mut v776_3 = Space::new();
          let mut v776_3_cursor = (v775_3_tail).read_zipper();
          for v776_3_byte in v776_3_cursor.child_mask().iter() {
            v776_3_cursor.descend_to_byte(v776_3_byte);
            {
            let v776_3_tail = v776_3_cursor.fork_read_zipper();
            let v776_3_head = Path::from_slice(&[v776_3_byte]);
            let mut v777_2 = Space::new();
            let mut v777_2_cursor = (v776_3_tail).read_zipper();
            for v777_2_byte in v777_2_cursor.child_mask().iter() {
              v777_2_cursor.descend_to_byte(v777_2_byte);
              {
              let v777_2_tail = v777_2_cursor.fork_read_zipper();
              let v777_2_head = Path::from_slice(&[v777_2_byte]);
              let v778_2: Path = concat_path(&(v776_3_head),&(v777_2_head));
              let mut v778_3 = Space::new();
              let mut v778_3_cursor = (v777_2_tail).read_zipper();
              for v778_3_byte in v778_3_cursor.child_mask().iter() {
                v778_3_cursor.descend_to_byte(v778_3_byte);
                {
                let v778_3_tail = v778_3_cursor.fork_read_zipper();
                let v778_3_head = Path::from_slice(&[v778_3_byte]);
                let v779_2: Path = concat_path(&(v778_2),&(v778_3_head));
                let mut v779_3 = Space::new();
                let mut v779_3_cursor = (v778_3_tail).read_zipper();
                for v779_3_byte in v779_3_cursor.child_mask().iter() {
                  v779_3_cursor.descend_to_byte(v779_3_byte);
                  {
                  let v779_3_tail = v779_3_cursor.fork_read_zipper();
                  let v779_3_head = Path::from_slice(&[v779_3_byte]);
                  let v780_2: Path = concat_path(&(v779_2),&(v779_3_head));
                  let v780_3: Space = routine_77(c, &(v780_2), &(*p1), &(*p2), &(*p0), &(v776_2), &(v779_3_tail).make_space());
                  drop(v780_2);
                  v779_3.join_into((v780_3).clone());
                  }
                  v779_3_cursor.ascend(1);
                }
                drop(v779_3_cursor);
                drop(v779_2);
                v778_3.join_into((v779_3).clone());
                }
                v778_3_cursor.ascend(1);
              }
              drop(v778_3_cursor);
              drop(v778_2);
              v777_2.join_into((v778_3).clone());
              }
              v777_2_cursor.ascend(1);
            }
            drop(v777_2_cursor);
            v776_3.join_into((v777_2).clone());
            }
            v776_3_cursor.ascend(1);
          }
          drop(v776_3_cursor);
          drop(v776_2);
          v775_3.join_into((v776_3).clone());
          }
          v775_3_cursor.ascend(1);
        }
        drop(v775_3_cursor);
        drop(v775_2);
        v774_3.join_into((v775_3).clone());
        }
        v774_3_cursor.ascend(1);
      }
      drop(v774_3_cursor);
      drop(v774_2);
      v773_2.join_into((v774_3).clone());
      }
      v773_2_cursor.ascend(1);
    }
    drop(v773_2_cursor);
    v772_4.join_into((v773_2).clone());
    }
    v772_4_cursor.ascend(1);
  }
  drop(v772_4_cursor);
  (v772_4).clone()
}

fn routine_60(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v781_4 = Space::new();
  let mut v781_4_cursor = (*s0).read_zipper();
  for v781_4_byte in v781_4_cursor.child_mask().iter() {
    v781_4_cursor.descend_to_byte(v781_4_byte);
    {
    let v781_4_tail = v781_4_cursor.fork_read_zipper();
    let v781_4_head = Path::from_slice(&[v781_4_byte]);
    let mut v782_2 = Space::new();
    let mut v782_2_cursor = (v781_4_tail).read_zipper();
    for v782_2_byte in v782_2_cursor.child_mask().iter() {
      v782_2_cursor.descend_to_byte(v782_2_byte);
      {
      let v782_2_tail = v782_2_cursor.fork_read_zipper();
      let v782_2_head = Path::from_slice(&[v782_2_byte]);
      let v783_2: Path = concat_path(&(v781_4_head),&(v782_2_head));
      let mut v783_3 = Space::new();
      let mut v783_3_cursor = (v782_2_tail).read_zipper();
      for v783_3_byte in v783_3_cursor.child_mask().iter() {
        v783_3_cursor.descend_to_byte(v783_3_byte);
        {
        let v783_3_tail = v783_3_cursor.fork_read_zipper();
        let v783_3_head = Path::from_slice(&[v783_3_byte]);
        let v784_2: Path = concat_path(&(v783_2),&(v783_3_head));
        let mut v784_3 = Space::new();
        let mut v784_3_cursor = (v783_3_tail).read_zipper();
        for v784_3_byte in v784_3_cursor.child_mask().iter() {
          v784_3_cursor.descend_to_byte(v784_3_byte);
          {
          let v784_3_tail = v784_3_cursor.fork_read_zipper();
          let v784_3_head = Path::from_slice(&[v784_3_byte]);
          let v785_2: Path = concat_path(&(v784_2),&(v784_3_head));
          let mut v785_3 = Space::new();
          let mut v785_3_cursor = (v784_3_tail).read_zipper();
          for v785_3_byte in v785_3_cursor.child_mask().iter() {
            v785_3_cursor.descend_to_byte(v785_3_byte);
            {
            let v785_3_tail = v785_3_cursor.fork_read_zipper();
            let v785_3_head = Path::from_slice(&[v785_3_byte]);
            let mut v786_2 = Space::new();
            let mut v786_2_cursor = (v785_3_tail).read_zipper();
            for v786_2_byte in v786_2_cursor.child_mask().iter() {
              v786_2_cursor.descend_to_byte(v786_2_byte);
              {
              let v786_2_tail = v786_2_cursor.fork_read_zipper();
              let v786_2_head = Path::from_slice(&[v786_2_byte]);
              let v787_2: Path = concat_path(&(v785_3_head),&(v786_2_head));
              let mut v787_3 = Space::new();
              let mut v787_3_cursor = (v786_2_tail).read_zipper();
              for v787_3_byte in v787_3_cursor.child_mask().iter() {
                v787_3_cursor.descend_to_byte(v787_3_byte);
                {
                let v787_3_tail = v787_3_cursor.fork_read_zipper();
                let v787_3_head = Path::from_slice(&[v787_3_byte]);
                let v788_2: Path = concat_path(&(v787_2),&(v787_3_head));
                let mut v788_3 = Space::new();
                let mut v788_3_cursor = (v787_3_tail).read_zipper();
                for v788_3_byte in v788_3_cursor.child_mask().iter() {
                  v788_3_cursor.descend_to_byte(v788_3_byte);
                  {
                  let v788_3_tail = v788_3_cursor.fork_read_zipper();
                  let v788_3_head = Path::from_slice(&[v788_3_byte]);
                  let v789_2: Path = concat_path(&(v788_2),&(v788_3_head));
                  let v789_3: Space = routine_78(c, &(v789_2), &(*p1), &(*p2), &(*p0), &(v785_2), &(v788_3_tail).make_space());
                  drop(v789_2);
                  v788_3.join_into((v789_3).clone());
                  }
                  v788_3_cursor.ascend(1);
                }
                drop(v788_3_cursor);
                drop(v788_2);
                v787_3.join_into((v788_3).clone());
                }
                v787_3_cursor.ascend(1);
              }
              drop(v787_3_cursor);
              drop(v787_2);
              v786_2.join_into((v787_3).clone());
              }
              v786_2_cursor.ascend(1);
            }
            drop(v786_2_cursor);
            v785_3.join_into((v786_2).clone());
            }
            v785_3_cursor.ascend(1);
          }
          drop(v785_3_cursor);
          drop(v785_2);
          v784_3.join_into((v785_3).clone());
          }
          v784_3_cursor.ascend(1);
        }
        drop(v784_3_cursor);
        drop(v784_2);
        v783_3.join_into((v784_3).clone());
        }
        v783_3_cursor.ascend(1);
      }
      drop(v783_3_cursor);
      drop(v783_2);
      v782_2.join_into((v783_3).clone());
      }
      v782_2_cursor.ascend(1);
    }
    drop(v782_2_cursor);
    v781_4.join_into((v782_2).clone());
    }
    v781_4_cursor.ascend(1);
  }
  drop(v781_4_cursor);
  (v781_4).clone()
}

fn routine_61(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v790_2: Space = singleton(&(*p0));
  (v790_2).clone()
}

fn routine_62(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v791_2: Space = singleton(&(*p0));
  (v791_2).clone()
}

fn routine_63(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v792_6 = Space::new();
  let mut v792_6_cursor = (*s0).read_zipper();
  for v792_6_byte in v792_6_cursor.child_mask().iter() {
    v792_6_cursor.descend_to_byte(v792_6_byte);
    {
    let v792_6_tail = v792_6_cursor.fork_read_zipper();
    let v792_6_head = Path::from_slice(&[v792_6_byte]);
    let mut v793_2 = Space::new();
    let mut v793_2_cursor = (v792_6_tail).read_zipper();
    for v793_2_byte in v793_2_cursor.child_mask().iter() {
      v793_2_cursor.descend_to_byte(v793_2_byte);
      {
      let v793_2_tail = v793_2_cursor.fork_read_zipper();
      let v793_2_head = Path::from_slice(&[v793_2_byte]);
      let v794_2: Path = concat_path(&(v792_6_head),&(v793_2_head));
      let mut v794_3 = Space::new();
      let mut v794_3_cursor = (v793_2_tail).read_zipper();
      for v794_3_byte in v794_3_cursor.child_mask().iter() {
        v794_3_cursor.descend_to_byte(v794_3_byte);
        {
        let v794_3_tail = v794_3_cursor.fork_read_zipper();
        let v794_3_head = Path::from_slice(&[v794_3_byte]);
        let v795_2: Path = concat_path(&(v794_2),&(v794_3_head));
        let mut v795_3 = Space::new();
        let mut v795_3_cursor = (v794_3_tail).read_zipper();
        for v795_3_byte in v795_3_cursor.child_mask().iter() {
          v795_3_cursor.descend_to_byte(v795_3_byte);
          {
          let v795_3_tail = v795_3_cursor.fork_read_zipper();
          let v795_3_head = Path::from_slice(&[v795_3_byte]);
          let v796_2: Path = concat_path(&(v795_2),&(v795_3_head));
          let mut v796_3 = Space::new();
          let mut v796_3_cursor = (v795_3_tail).read_zipper();
          for v796_3_byte in v796_3_cursor.child_mask().iter() {
            v796_3_cursor.descend_to_byte(v796_3_byte);
            {
            let v796_3_tail = v796_3_cursor.fork_read_zipper();
            let v796_3_head = Path::from_slice(&[v796_3_byte]);
            let mut v797_2 = Space::new();
            let mut v797_2_cursor = (v796_3_tail).read_zipper();
            for v797_2_byte in v797_2_cursor.child_mask().iter() {
              v797_2_cursor.descend_to_byte(v797_2_byte);
              {
              let v797_2_tail = v797_2_cursor.fork_read_zipper();
              let v797_2_head = Path::from_slice(&[v797_2_byte]);
              let v798_2: Path = concat_path(&(v796_3_head),&(v797_2_head));
              let mut v798_3 = Space::new();
              let mut v798_3_cursor = (v797_2_tail).read_zipper();
              for v798_3_byte in v798_3_cursor.child_mask().iter() {
                v798_3_cursor.descend_to_byte(v798_3_byte);
                {
                let v798_3_tail = v798_3_cursor.fork_read_zipper();
                let v798_3_head = Path::from_slice(&[v798_3_byte]);
                let v799_2: Path = concat_path(&(v798_2),&(v798_3_head));
                let mut v799_3 = Space::new();
                let mut v799_3_cursor = (v798_3_tail).read_zipper();
                for v799_3_byte in v799_3_cursor.child_mask().iter() {
                  v799_3_cursor.descend_to_byte(v799_3_byte);
                  {
                  let v799_3_tail = v799_3_cursor.fork_read_zipper();
                  let v799_3_head = Path::from_slice(&[v799_3_byte]);
                  let v800_2: Path = concat_path(&(v799_2),&(v799_3_head));
                  let v800_3: Space = routine_79(c, &(v800_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v796_2), &(v799_3_tail).make_space());
                  drop(v800_2);
                  v799_3.join_into((v800_3).clone());
                  }
                  v799_3_cursor.ascend(1);
                }
                drop(v799_3_cursor);
                drop(v799_2);
                v798_3.join_into((v799_3).clone());
                }
                v798_3_cursor.ascend(1);
              }
              drop(v798_3_cursor);
              drop(v798_2);
              v797_2.join_into((v798_3).clone());
              }
              v797_2_cursor.ascend(1);
            }
            drop(v797_2_cursor);
            v796_3.join_into((v797_2).clone());
            }
            v796_3_cursor.ascend(1);
          }
          drop(v796_3_cursor);
          drop(v796_2);
          v795_3.join_into((v796_3).clone());
          }
          v795_3_cursor.ascend(1);
        }
        drop(v795_3_cursor);
        drop(v795_2);
        v794_3.join_into((v795_3).clone());
        }
        v794_3_cursor.ascend(1);
      }
      drop(v794_3_cursor);
      drop(v794_2);
      v793_2.join_into((v794_3).clone());
      }
      v793_2_cursor.ascend(1);
    }
    drop(v793_2_cursor);
    v792_6.join_into((v793_2).clone());
    }
    v792_6_cursor.ascend(1);
  }
  drop(v792_6_cursor);
  (v792_6).clone()
}

fn routine_64(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v801_6 = Space::new();
  let mut v801_6_cursor = (*s0).read_zipper();
  for v801_6_byte in v801_6_cursor.child_mask().iter() {
    v801_6_cursor.descend_to_byte(v801_6_byte);
    {
    let v801_6_tail = v801_6_cursor.fork_read_zipper();
    let v801_6_head = Path::from_slice(&[v801_6_byte]);
    let mut v802_2 = Space::new();
    let mut v802_2_cursor = (v801_6_tail).read_zipper();
    for v802_2_byte in v802_2_cursor.child_mask().iter() {
      v802_2_cursor.descend_to_byte(v802_2_byte);
      {
      let v802_2_tail = v802_2_cursor.fork_read_zipper();
      let v802_2_head = Path::from_slice(&[v802_2_byte]);
      let v803_2: Path = concat_path(&(v801_6_head),&(v802_2_head));
      let mut v803_3 = Space::new();
      let mut v803_3_cursor = (v802_2_tail).read_zipper();
      for v803_3_byte in v803_3_cursor.child_mask().iter() {
        v803_3_cursor.descend_to_byte(v803_3_byte);
        {
        let v803_3_tail = v803_3_cursor.fork_read_zipper();
        let v803_3_head = Path::from_slice(&[v803_3_byte]);
        let v804_2: Path = concat_path(&(v803_2),&(v803_3_head));
        let mut v804_3 = Space::new();
        let mut v804_3_cursor = (v803_3_tail).read_zipper();
        for v804_3_byte in v804_3_cursor.child_mask().iter() {
          v804_3_cursor.descend_to_byte(v804_3_byte);
          {
          let v804_3_tail = v804_3_cursor.fork_read_zipper();
          let v804_3_head = Path::from_slice(&[v804_3_byte]);
          let v805_2: Path = concat_path(&(v804_2),&(v804_3_head));
          let mut v805_3 = Space::new();
          let mut v805_3_cursor = (v804_3_tail).read_zipper();
          for v805_3_byte in v805_3_cursor.child_mask().iter() {
            v805_3_cursor.descend_to_byte(v805_3_byte);
            {
            let v805_3_tail = v805_3_cursor.fork_read_zipper();
            let v805_3_head = Path::from_slice(&[v805_3_byte]);
            let mut v806_2 = Space::new();
            let mut v806_2_cursor = (v805_3_tail).read_zipper();
            for v806_2_byte in v806_2_cursor.child_mask().iter() {
              v806_2_cursor.descend_to_byte(v806_2_byte);
              {
              let v806_2_tail = v806_2_cursor.fork_read_zipper();
              let v806_2_head = Path::from_slice(&[v806_2_byte]);
              let v807_2: Path = concat_path(&(v805_3_head),&(v806_2_head));
              let mut v807_3 = Space::new();
              let mut v807_3_cursor = (v806_2_tail).read_zipper();
              for v807_3_byte in v807_3_cursor.child_mask().iter() {
                v807_3_cursor.descend_to_byte(v807_3_byte);
                {
                let v807_3_tail = v807_3_cursor.fork_read_zipper();
                let v807_3_head = Path::from_slice(&[v807_3_byte]);
                let v808_2: Path = concat_path(&(v807_2),&(v807_3_head));
                let mut v808_3 = Space::new();
                let mut v808_3_cursor = (v807_3_tail).read_zipper();
                for v808_3_byte in v808_3_cursor.child_mask().iter() {
                  v808_3_cursor.descend_to_byte(v808_3_byte);
                  {
                  let v808_3_tail = v808_3_cursor.fork_read_zipper();
                  let v808_3_head = Path::from_slice(&[v808_3_byte]);
                  let v809_2: Path = concat_path(&(v808_2),&(v808_3_head));
                  let v809_3: Space = routine_80(c, &(v809_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v805_2), &(v808_3_tail).make_space());
                  drop(v809_2);
                  v808_3.join_into((v809_3).clone());
                  }
                  v808_3_cursor.ascend(1);
                }
                drop(v808_3_cursor);
                drop(v808_2);
                v807_3.join_into((v808_3).clone());
                }
                v807_3_cursor.ascend(1);
              }
              drop(v807_3_cursor);
              drop(v807_2);
              v806_2.join_into((v807_3).clone());
              }
              v806_2_cursor.ascend(1);
            }
            drop(v806_2_cursor);
            v805_3.join_into((v806_2).clone());
            }
            v805_3_cursor.ascend(1);
          }
          drop(v805_3_cursor);
          drop(v805_2);
          v804_3.join_into((v805_3).clone());
          }
          v804_3_cursor.ascend(1);
        }
        drop(v804_3_cursor);
        drop(v804_2);
        v803_3.join_into((v804_3).clone());
        }
        v803_3_cursor.ascend(1);
      }
      drop(v803_3_cursor);
      drop(v803_2);
      v802_2.join_into((v803_3).clone());
      }
      v802_2_cursor.ascend(1);
    }
    drop(v802_2_cursor);
    v801_6.join_into((v802_2).clone());
    }
    v801_6_cursor.ascend(1);
  }
  drop(v801_6_cursor);
  (v801_6).clone()
}

fn routine_65(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v810_6 = Space::new();
  let mut v810_6_cursor = (*s0).read_zipper();
  for v810_6_byte in v810_6_cursor.child_mask().iter() {
    v810_6_cursor.descend_to_byte(v810_6_byte);
    {
    let v810_6_tail = v810_6_cursor.fork_read_zipper();
    let v810_6_head = Path::from_slice(&[v810_6_byte]);
    let mut v811_2 = Space::new();
    let mut v811_2_cursor = (v810_6_tail).read_zipper();
    for v811_2_byte in v811_2_cursor.child_mask().iter() {
      v811_2_cursor.descend_to_byte(v811_2_byte);
      {
      let v811_2_tail = v811_2_cursor.fork_read_zipper();
      let v811_2_head = Path::from_slice(&[v811_2_byte]);
      let v812_2: Path = concat_path(&(v810_6_head),&(v811_2_head));
      let mut v812_3 = Space::new();
      let mut v812_3_cursor = (v811_2_tail).read_zipper();
      for v812_3_byte in v812_3_cursor.child_mask().iter() {
        v812_3_cursor.descend_to_byte(v812_3_byte);
        {
        let v812_3_tail = v812_3_cursor.fork_read_zipper();
        let v812_3_head = Path::from_slice(&[v812_3_byte]);
        let v813_2: Path = concat_path(&(v812_2),&(v812_3_head));
        let mut v813_3 = Space::new();
        let mut v813_3_cursor = (v812_3_tail).read_zipper();
        for v813_3_byte in v813_3_cursor.child_mask().iter() {
          v813_3_cursor.descend_to_byte(v813_3_byte);
          {
          let v813_3_tail = v813_3_cursor.fork_read_zipper();
          let v813_3_head = Path::from_slice(&[v813_3_byte]);
          let v814_2: Path = concat_path(&(v813_2),&(v813_3_head));
          let mut v814_3 = Space::new();
          let mut v814_3_cursor = (v813_3_tail).read_zipper();
          for v814_3_byte in v814_3_cursor.child_mask().iter() {
            v814_3_cursor.descend_to_byte(v814_3_byte);
            {
            let v814_3_tail = v814_3_cursor.fork_read_zipper();
            let v814_3_head = Path::from_slice(&[v814_3_byte]);
            let mut v815_2 = Space::new();
            let mut v815_2_cursor = (v814_3_tail).read_zipper();
            for v815_2_byte in v815_2_cursor.child_mask().iter() {
              v815_2_cursor.descend_to_byte(v815_2_byte);
              {
              let v815_2_tail = v815_2_cursor.fork_read_zipper();
              let v815_2_head = Path::from_slice(&[v815_2_byte]);
              let v816_2: Path = concat_path(&(v814_3_head),&(v815_2_head));
              let mut v816_3 = Space::new();
              let mut v816_3_cursor = (v815_2_tail).read_zipper();
              for v816_3_byte in v816_3_cursor.child_mask().iter() {
                v816_3_cursor.descend_to_byte(v816_3_byte);
                {
                let v816_3_tail = v816_3_cursor.fork_read_zipper();
                let v816_3_head = Path::from_slice(&[v816_3_byte]);
                let v817_2: Path = concat_path(&(v816_2),&(v816_3_head));
                let mut v817_3 = Space::new();
                let mut v817_3_cursor = (v816_3_tail).read_zipper();
                for v817_3_byte in v817_3_cursor.child_mask().iter() {
                  v817_3_cursor.descend_to_byte(v817_3_byte);
                  {
                  let v817_3_tail = v817_3_cursor.fork_read_zipper();
                  let v817_3_head = Path::from_slice(&[v817_3_byte]);
                  let v818_2: Path = concat_path(&(v817_2),&(v817_3_head));
                  let v818_3: Space = routine_81(c, &(v818_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v814_2), &(v817_3_tail).make_space());
                  drop(v818_2);
                  v817_3.join_into((v818_3).clone());
                  }
                  v817_3_cursor.ascend(1);
                }
                drop(v817_3_cursor);
                drop(v817_2);
                v816_3.join_into((v817_3).clone());
                }
                v816_3_cursor.ascend(1);
              }
              drop(v816_3_cursor);
              drop(v816_2);
              v815_2.join_into((v816_3).clone());
              }
              v815_2_cursor.ascend(1);
            }
            drop(v815_2_cursor);
            v814_3.join_into((v815_2).clone());
            }
            v814_3_cursor.ascend(1);
          }
          drop(v814_3_cursor);
          drop(v814_2);
          v813_3.join_into((v814_3).clone());
          }
          v813_3_cursor.ascend(1);
        }
        drop(v813_3_cursor);
        drop(v813_2);
        v812_3.join_into((v813_3).clone());
        }
        v812_3_cursor.ascend(1);
      }
      drop(v812_3_cursor);
      drop(v812_2);
      v811_2.join_into((v812_3).clone());
      }
      v811_2_cursor.ascend(1);
    }
    drop(v811_2_cursor);
    v810_6.join_into((v811_2).clone());
    }
    v810_6_cursor.ascend(1);
  }
  drop(v810_6_cursor);
  (v810_6).clone()
}

fn routine_66(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v819_6 = Space::new();
  let mut v819_6_cursor = (*s0).read_zipper();
  for v819_6_byte in v819_6_cursor.child_mask().iter() {
    v819_6_cursor.descend_to_byte(v819_6_byte);
    {
    let v819_6_tail = v819_6_cursor.fork_read_zipper();
    let v819_6_head = Path::from_slice(&[v819_6_byte]);
    let mut v820_2 = Space::new();
    let mut v820_2_cursor = (v819_6_tail).read_zipper();
    for v820_2_byte in v820_2_cursor.child_mask().iter() {
      v820_2_cursor.descend_to_byte(v820_2_byte);
      {
      let v820_2_tail = v820_2_cursor.fork_read_zipper();
      let v820_2_head = Path::from_slice(&[v820_2_byte]);
      let v821_2: Path = concat_path(&(v819_6_head),&(v820_2_head));
      let mut v821_3 = Space::new();
      let mut v821_3_cursor = (v820_2_tail).read_zipper();
      for v821_3_byte in v821_3_cursor.child_mask().iter() {
        v821_3_cursor.descend_to_byte(v821_3_byte);
        {
        let v821_3_tail = v821_3_cursor.fork_read_zipper();
        let v821_3_head = Path::from_slice(&[v821_3_byte]);
        let v822_2: Path = concat_path(&(v821_2),&(v821_3_head));
        let mut v822_3 = Space::new();
        let mut v822_3_cursor = (v821_3_tail).read_zipper();
        for v822_3_byte in v822_3_cursor.child_mask().iter() {
          v822_3_cursor.descend_to_byte(v822_3_byte);
          {
          let v822_3_tail = v822_3_cursor.fork_read_zipper();
          let v822_3_head = Path::from_slice(&[v822_3_byte]);
          let v823_2: Path = concat_path(&(v822_2),&(v822_3_head));
          let mut v823_3 = Space::new();
          let mut v823_3_cursor = (v822_3_tail).read_zipper();
          for v823_3_byte in v823_3_cursor.child_mask().iter() {
            v823_3_cursor.descend_to_byte(v823_3_byte);
            {
            let v823_3_tail = v823_3_cursor.fork_read_zipper();
            let v823_3_head = Path::from_slice(&[v823_3_byte]);
            let mut v824_2 = Space::new();
            let mut v824_2_cursor = (v823_3_tail).read_zipper();
            for v824_2_byte in v824_2_cursor.child_mask().iter() {
              v824_2_cursor.descend_to_byte(v824_2_byte);
              {
              let v824_2_tail = v824_2_cursor.fork_read_zipper();
              let v824_2_head = Path::from_slice(&[v824_2_byte]);
              let v825_2: Path = concat_path(&(v823_3_head),&(v824_2_head));
              let mut v825_3 = Space::new();
              let mut v825_3_cursor = (v824_2_tail).read_zipper();
              for v825_3_byte in v825_3_cursor.child_mask().iter() {
                v825_3_cursor.descend_to_byte(v825_3_byte);
                {
                let v825_3_tail = v825_3_cursor.fork_read_zipper();
                let v825_3_head = Path::from_slice(&[v825_3_byte]);
                let v826_2: Path = concat_path(&(v825_2),&(v825_3_head));
                let mut v826_3 = Space::new();
                let mut v826_3_cursor = (v825_3_tail).read_zipper();
                for v826_3_byte in v826_3_cursor.child_mask().iter() {
                  v826_3_cursor.descend_to_byte(v826_3_byte);
                  {
                  let v826_3_tail = v826_3_cursor.fork_read_zipper();
                  let v826_3_head = Path::from_slice(&[v826_3_byte]);
                  let v827_2: Path = concat_path(&(v826_2),&(v826_3_head));
                  let v827_3: Space = routine_82(c, &(v827_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v823_2), &(v826_3_tail).make_space());
                  drop(v827_2);
                  v826_3.join_into((v827_3).clone());
                  }
                  v826_3_cursor.ascend(1);
                }
                drop(v826_3_cursor);
                drop(v826_2);
                v825_3.join_into((v826_3).clone());
                }
                v825_3_cursor.ascend(1);
              }
              drop(v825_3_cursor);
              drop(v825_2);
              v824_2.join_into((v825_3).clone());
              }
              v824_2_cursor.ascend(1);
            }
            drop(v824_2_cursor);
            v823_3.join_into((v824_2).clone());
            }
            v823_3_cursor.ascend(1);
          }
          drop(v823_3_cursor);
          drop(v823_2);
          v822_3.join_into((v823_3).clone());
          }
          v822_3_cursor.ascend(1);
        }
        drop(v822_3_cursor);
        drop(v822_2);
        v821_3.join_into((v822_3).clone());
        }
        v821_3_cursor.ascend(1);
      }
      drop(v821_3_cursor);
      drop(v821_2);
      v820_2.join_into((v821_3).clone());
      }
      v820_2_cursor.ascend(1);
    }
    drop(v820_2_cursor);
    v819_6.join_into((v820_2).clone());
    }
    v819_6_cursor.ascend(1);
  }
  drop(v819_6_cursor);
  (v819_6).clone()
}

fn routine_67(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v828_6 = Space::new();
  let mut v828_6_cursor = (*s0).read_zipper();
  for v828_6_byte in v828_6_cursor.child_mask().iter() {
    v828_6_cursor.descend_to_byte(v828_6_byte);
    {
    let v828_6_tail = v828_6_cursor.fork_read_zipper();
    let v828_6_head = Path::from_slice(&[v828_6_byte]);
    let mut v829_2 = Space::new();
    let mut v829_2_cursor = (v828_6_tail).read_zipper();
    for v829_2_byte in v829_2_cursor.child_mask().iter() {
      v829_2_cursor.descend_to_byte(v829_2_byte);
      {
      let v829_2_tail = v829_2_cursor.fork_read_zipper();
      let v829_2_head = Path::from_slice(&[v829_2_byte]);
      let v830_2: Path = concat_path(&(v828_6_head),&(v829_2_head));
      let mut v830_3 = Space::new();
      let mut v830_3_cursor = (v829_2_tail).read_zipper();
      for v830_3_byte in v830_3_cursor.child_mask().iter() {
        v830_3_cursor.descend_to_byte(v830_3_byte);
        {
        let v830_3_tail = v830_3_cursor.fork_read_zipper();
        let v830_3_head = Path::from_slice(&[v830_3_byte]);
        let v831_2: Path = concat_path(&(v830_2),&(v830_3_head));
        let mut v831_3 = Space::new();
        let mut v831_3_cursor = (v830_3_tail).read_zipper();
        for v831_3_byte in v831_3_cursor.child_mask().iter() {
          v831_3_cursor.descend_to_byte(v831_3_byte);
          {
          let v831_3_tail = v831_3_cursor.fork_read_zipper();
          let v831_3_head = Path::from_slice(&[v831_3_byte]);
          let v832_2: Path = concat_path(&(v831_2),&(v831_3_head));
          let mut v832_3 = Space::new();
          let mut v832_3_cursor = (v831_3_tail).read_zipper();
          for v832_3_byte in v832_3_cursor.child_mask().iter() {
            v832_3_cursor.descend_to_byte(v832_3_byte);
            {
            let v832_3_tail = v832_3_cursor.fork_read_zipper();
            let v832_3_head = Path::from_slice(&[v832_3_byte]);
            let mut v833_2 = Space::new();
            let mut v833_2_cursor = (v832_3_tail).read_zipper();
            for v833_2_byte in v833_2_cursor.child_mask().iter() {
              v833_2_cursor.descend_to_byte(v833_2_byte);
              {
              let v833_2_tail = v833_2_cursor.fork_read_zipper();
              let v833_2_head = Path::from_slice(&[v833_2_byte]);
              let v834_2: Path = concat_path(&(v832_3_head),&(v833_2_head));
              let mut v834_3 = Space::new();
              let mut v834_3_cursor = (v833_2_tail).read_zipper();
              for v834_3_byte in v834_3_cursor.child_mask().iter() {
                v834_3_cursor.descend_to_byte(v834_3_byte);
                {
                let v834_3_tail = v834_3_cursor.fork_read_zipper();
                let v834_3_head = Path::from_slice(&[v834_3_byte]);
                let v835_2: Path = concat_path(&(v834_2),&(v834_3_head));
                let mut v835_3 = Space::new();
                let mut v835_3_cursor = (v834_3_tail).read_zipper();
                for v835_3_byte in v835_3_cursor.child_mask().iter() {
                  v835_3_cursor.descend_to_byte(v835_3_byte);
                  {
                  let v835_3_tail = v835_3_cursor.fork_read_zipper();
                  let v835_3_head = Path::from_slice(&[v835_3_byte]);
                  let v836_2: Path = concat_path(&(v835_2),&(v835_3_head));
                  let v836_3: Space = routine_83(c, &(v836_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v832_2), &(v835_3_tail).make_space());
                  drop(v836_2);
                  v835_3.join_into((v836_3).clone());
                  }
                  v835_3_cursor.ascend(1);
                }
                drop(v835_3_cursor);
                drop(v835_2);
                v834_3.join_into((v835_3).clone());
                }
                v834_3_cursor.ascend(1);
              }
              drop(v834_3_cursor);
              drop(v834_2);
              v833_2.join_into((v834_3).clone());
              }
              v833_2_cursor.ascend(1);
            }
            drop(v833_2_cursor);
            v832_3.join_into((v833_2).clone());
            }
            v832_3_cursor.ascend(1);
          }
          drop(v832_3_cursor);
          drop(v832_2);
          v831_3.join_into((v832_3).clone());
          }
          v831_3_cursor.ascend(1);
        }
        drop(v831_3_cursor);
        drop(v831_2);
        v830_3.join_into((v831_3).clone());
        }
        v830_3_cursor.ascend(1);
      }
      drop(v830_3_cursor);
      drop(v830_2);
      v829_2.join_into((v830_3).clone());
      }
      v829_2_cursor.ascend(1);
    }
    drop(v829_2_cursor);
    v828_6.join_into((v829_2).clone());
    }
    v828_6_cursor.ascend(1);
  }
  drop(v828_6_cursor);
  (v828_6).clone()
}

fn routine_68(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v837_6 = Space::new();
  let mut v837_6_cursor = (*s0).read_zipper();
  for v837_6_byte in v837_6_cursor.child_mask().iter() {
    v837_6_cursor.descend_to_byte(v837_6_byte);
    {
    let v837_6_tail = v837_6_cursor.fork_read_zipper();
    let v837_6_head = Path::from_slice(&[v837_6_byte]);
    let mut v838_2 = Space::new();
    let mut v838_2_cursor = (v837_6_tail).read_zipper();
    for v838_2_byte in v838_2_cursor.child_mask().iter() {
      v838_2_cursor.descend_to_byte(v838_2_byte);
      {
      let v838_2_tail = v838_2_cursor.fork_read_zipper();
      let v838_2_head = Path::from_slice(&[v838_2_byte]);
      let v839_2: Path = concat_path(&(v837_6_head),&(v838_2_head));
      let mut v839_3 = Space::new();
      let mut v839_3_cursor = (v838_2_tail).read_zipper();
      for v839_3_byte in v839_3_cursor.child_mask().iter() {
        v839_3_cursor.descend_to_byte(v839_3_byte);
        {
        let v839_3_tail = v839_3_cursor.fork_read_zipper();
        let v839_3_head = Path::from_slice(&[v839_3_byte]);
        let v840_2: Path = concat_path(&(v839_2),&(v839_3_head));
        let mut v840_3 = Space::new();
        let mut v840_3_cursor = (v839_3_tail).read_zipper();
        for v840_3_byte in v840_3_cursor.child_mask().iter() {
          v840_3_cursor.descend_to_byte(v840_3_byte);
          {
          let v840_3_tail = v840_3_cursor.fork_read_zipper();
          let v840_3_head = Path::from_slice(&[v840_3_byte]);
          let v841_2: Path = concat_path(&(v840_2),&(v840_3_head));
          let mut v841_3 = Space::new();
          let mut v841_3_cursor = (v840_3_tail).read_zipper();
          for v841_3_byte in v841_3_cursor.child_mask().iter() {
            v841_3_cursor.descend_to_byte(v841_3_byte);
            {
            let v841_3_tail = v841_3_cursor.fork_read_zipper();
            let v841_3_head = Path::from_slice(&[v841_3_byte]);
            let mut v842_2 = Space::new();
            let mut v842_2_cursor = (v841_3_tail).read_zipper();
            for v842_2_byte in v842_2_cursor.child_mask().iter() {
              v842_2_cursor.descend_to_byte(v842_2_byte);
              {
              let v842_2_tail = v842_2_cursor.fork_read_zipper();
              let v842_2_head = Path::from_slice(&[v842_2_byte]);
              let v843_2: Path = concat_path(&(v841_3_head),&(v842_2_head));
              let mut v843_3 = Space::new();
              let mut v843_3_cursor = (v842_2_tail).read_zipper();
              for v843_3_byte in v843_3_cursor.child_mask().iter() {
                v843_3_cursor.descend_to_byte(v843_3_byte);
                {
                let v843_3_tail = v843_3_cursor.fork_read_zipper();
                let v843_3_head = Path::from_slice(&[v843_3_byte]);
                let v844_2: Path = concat_path(&(v843_2),&(v843_3_head));
                let mut v844_3 = Space::new();
                let mut v844_3_cursor = (v843_3_tail).read_zipper();
                for v844_3_byte in v844_3_cursor.child_mask().iter() {
                  v844_3_cursor.descend_to_byte(v844_3_byte);
                  {
                  let v844_3_tail = v844_3_cursor.fork_read_zipper();
                  let v844_3_head = Path::from_slice(&[v844_3_byte]);
                  let v845_2: Path = concat_path(&(v844_2),&(v844_3_head));
                  let v845_3: Space = routine_84(c, &(v845_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v841_2), &(v844_3_tail).make_space());
                  drop(v845_2);
                  v844_3.join_into((v845_3).clone());
                  }
                  v844_3_cursor.ascend(1);
                }
                drop(v844_3_cursor);
                drop(v844_2);
                v843_3.join_into((v844_3).clone());
                }
                v843_3_cursor.ascend(1);
              }
              drop(v843_3_cursor);
              drop(v843_2);
              v842_2.join_into((v843_3).clone());
              }
              v842_2_cursor.ascend(1);
            }
            drop(v842_2_cursor);
            v841_3.join_into((v842_2).clone());
            }
            v841_3_cursor.ascend(1);
          }
          drop(v841_3_cursor);
          drop(v841_2);
          v840_3.join_into((v841_3).clone());
          }
          v840_3_cursor.ascend(1);
        }
        drop(v840_3_cursor);
        drop(v840_2);
        v839_3.join_into((v840_3).clone());
        }
        v839_3_cursor.ascend(1);
      }
      drop(v839_3_cursor);
      drop(v839_2);
      v838_2.join_into((v839_3).clone());
      }
      v838_2_cursor.ascend(1);
    }
    drop(v838_2_cursor);
    v837_6.join_into((v838_2).clone());
    }
    v837_6_cursor.ascend(1);
  }
  drop(v837_6_cursor);
  (v837_6).clone()
}

fn routine_69(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v846_6 = Space::new();
  let mut v846_6_cursor = (*s0).read_zipper();
  for v846_6_byte in v846_6_cursor.child_mask().iter() {
    v846_6_cursor.descend_to_byte(v846_6_byte);
    {
    let v846_6_tail = v846_6_cursor.fork_read_zipper();
    let v846_6_head = Path::from_slice(&[v846_6_byte]);
    let mut v847_2 = Space::new();
    let mut v847_2_cursor = (v846_6_tail).read_zipper();
    for v847_2_byte in v847_2_cursor.child_mask().iter() {
      v847_2_cursor.descend_to_byte(v847_2_byte);
      {
      let v847_2_tail = v847_2_cursor.fork_read_zipper();
      let v847_2_head = Path::from_slice(&[v847_2_byte]);
      let v848_2: Path = concat_path(&(v846_6_head),&(v847_2_head));
      let mut v848_3 = Space::new();
      let mut v848_3_cursor = (v847_2_tail).read_zipper();
      for v848_3_byte in v848_3_cursor.child_mask().iter() {
        v848_3_cursor.descend_to_byte(v848_3_byte);
        {
        let v848_3_tail = v848_3_cursor.fork_read_zipper();
        let v848_3_head = Path::from_slice(&[v848_3_byte]);
        let v849_2: Path = concat_path(&(v848_2),&(v848_3_head));
        let mut v849_3 = Space::new();
        let mut v849_3_cursor = (v848_3_tail).read_zipper();
        for v849_3_byte in v849_3_cursor.child_mask().iter() {
          v849_3_cursor.descend_to_byte(v849_3_byte);
          {
          let v849_3_tail = v849_3_cursor.fork_read_zipper();
          let v849_3_head = Path::from_slice(&[v849_3_byte]);
          let v850_2: Path = concat_path(&(v849_2),&(v849_3_head));
          let mut v850_3 = Space::new();
          let mut v850_3_cursor = (v849_3_tail).read_zipper();
          for v850_3_byte in v850_3_cursor.child_mask().iter() {
            v850_3_cursor.descend_to_byte(v850_3_byte);
            {
            let v850_3_tail = v850_3_cursor.fork_read_zipper();
            let v850_3_head = Path::from_slice(&[v850_3_byte]);
            let mut v851_2 = Space::new();
            let mut v851_2_cursor = (v850_3_tail).read_zipper();
            for v851_2_byte in v851_2_cursor.child_mask().iter() {
              v851_2_cursor.descend_to_byte(v851_2_byte);
              {
              let v851_2_tail = v851_2_cursor.fork_read_zipper();
              let v851_2_head = Path::from_slice(&[v851_2_byte]);
              let v852_2: Path = concat_path(&(v850_3_head),&(v851_2_head));
              let mut v852_3 = Space::new();
              let mut v852_3_cursor = (v851_2_tail).read_zipper();
              for v852_3_byte in v852_3_cursor.child_mask().iter() {
                v852_3_cursor.descend_to_byte(v852_3_byte);
                {
                let v852_3_tail = v852_3_cursor.fork_read_zipper();
                let v852_3_head = Path::from_slice(&[v852_3_byte]);
                let v853_2: Path = concat_path(&(v852_2),&(v852_3_head));
                let mut v853_3 = Space::new();
                let mut v853_3_cursor = (v852_3_tail).read_zipper();
                for v853_3_byte in v853_3_cursor.child_mask().iter() {
                  v853_3_cursor.descend_to_byte(v853_3_byte);
                  {
                  let v853_3_tail = v853_3_cursor.fork_read_zipper();
                  let v853_3_head = Path::from_slice(&[v853_3_byte]);
                  let v854_2: Path = concat_path(&(v853_2),&(v853_3_head));
                  let v854_3: Space = routine_85(c, &(v854_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v850_2), &(v853_3_tail).make_space());
                  drop(v854_2);
                  v853_3.join_into((v854_3).clone());
                  }
                  v853_3_cursor.ascend(1);
                }
                drop(v853_3_cursor);
                drop(v853_2);
                v852_3.join_into((v853_3).clone());
                }
                v852_3_cursor.ascend(1);
              }
              drop(v852_3_cursor);
              drop(v852_2);
              v851_2.join_into((v852_3).clone());
              }
              v851_2_cursor.ascend(1);
            }
            drop(v851_2_cursor);
            v850_3.join_into((v851_2).clone());
            }
            v850_3_cursor.ascend(1);
          }
          drop(v850_3_cursor);
          drop(v850_2);
          v849_3.join_into((v850_3).clone());
          }
          v849_3_cursor.ascend(1);
        }
        drop(v849_3_cursor);
        drop(v849_2);
        v848_3.join_into((v849_3).clone());
        }
        v848_3_cursor.ascend(1);
      }
      drop(v848_3_cursor);
      drop(v848_2);
      v847_2.join_into((v848_3).clone());
      }
      v847_2_cursor.ascend(1);
    }
    drop(v847_2_cursor);
    v846_6.join_into((v847_2).clone());
    }
    v846_6_cursor.ascend(1);
  }
  drop(v846_6_cursor);
  (v846_6).clone()
}

fn routine_70(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v855_6 = Space::new();
  let mut v855_6_cursor = (*s0).read_zipper();
  for v855_6_byte in v855_6_cursor.child_mask().iter() {
    v855_6_cursor.descend_to_byte(v855_6_byte);
    {
    let v855_6_tail = v855_6_cursor.fork_read_zipper();
    let v855_6_head = Path::from_slice(&[v855_6_byte]);
    let mut v856_2 = Space::new();
    let mut v856_2_cursor = (v855_6_tail).read_zipper();
    for v856_2_byte in v856_2_cursor.child_mask().iter() {
      v856_2_cursor.descend_to_byte(v856_2_byte);
      {
      let v856_2_tail = v856_2_cursor.fork_read_zipper();
      let v856_2_head = Path::from_slice(&[v856_2_byte]);
      let v857_2: Path = concat_path(&(v855_6_head),&(v856_2_head));
      let mut v857_3 = Space::new();
      let mut v857_3_cursor = (v856_2_tail).read_zipper();
      for v857_3_byte in v857_3_cursor.child_mask().iter() {
        v857_3_cursor.descend_to_byte(v857_3_byte);
        {
        let v857_3_tail = v857_3_cursor.fork_read_zipper();
        let v857_3_head = Path::from_slice(&[v857_3_byte]);
        let v858_2: Path = concat_path(&(v857_2),&(v857_3_head));
        let mut v858_3 = Space::new();
        let mut v858_3_cursor = (v857_3_tail).read_zipper();
        for v858_3_byte in v858_3_cursor.child_mask().iter() {
          v858_3_cursor.descend_to_byte(v858_3_byte);
          {
          let v858_3_tail = v858_3_cursor.fork_read_zipper();
          let v858_3_head = Path::from_slice(&[v858_3_byte]);
          let v859_2: Path = concat_path(&(v858_2),&(v858_3_head));
          let mut v859_3 = Space::new();
          let mut v859_3_cursor = (v858_3_tail).read_zipper();
          for v859_3_byte in v859_3_cursor.child_mask().iter() {
            v859_3_cursor.descend_to_byte(v859_3_byte);
            {
            let v859_3_tail = v859_3_cursor.fork_read_zipper();
            let v859_3_head = Path::from_slice(&[v859_3_byte]);
            let mut v860_2 = Space::new();
            let mut v860_2_cursor = (v859_3_tail).read_zipper();
            for v860_2_byte in v860_2_cursor.child_mask().iter() {
              v860_2_cursor.descend_to_byte(v860_2_byte);
              {
              let v860_2_tail = v860_2_cursor.fork_read_zipper();
              let v860_2_head = Path::from_slice(&[v860_2_byte]);
              let v861_2: Path = concat_path(&(v859_3_head),&(v860_2_head));
              let mut v861_3 = Space::new();
              let mut v861_3_cursor = (v860_2_tail).read_zipper();
              for v861_3_byte in v861_3_cursor.child_mask().iter() {
                v861_3_cursor.descend_to_byte(v861_3_byte);
                {
                let v861_3_tail = v861_3_cursor.fork_read_zipper();
                let v861_3_head = Path::from_slice(&[v861_3_byte]);
                let v862_2: Path = concat_path(&(v861_2),&(v861_3_head));
                let mut v862_3 = Space::new();
                let mut v862_3_cursor = (v861_3_tail).read_zipper();
                for v862_3_byte in v862_3_cursor.child_mask().iter() {
                  v862_3_cursor.descend_to_byte(v862_3_byte);
                  {
                  let v862_3_tail = v862_3_cursor.fork_read_zipper();
                  let v862_3_head = Path::from_slice(&[v862_3_byte]);
                  let v863_2: Path = concat_path(&(v862_2),&(v862_3_head));
                  let v863_3: Space = routine_86(c, &(v863_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v859_2), &(v862_3_tail).make_space());
                  drop(v863_2);
                  v862_3.join_into((v863_3).clone());
                  }
                  v862_3_cursor.ascend(1);
                }
                drop(v862_3_cursor);
                drop(v862_2);
                v861_3.join_into((v862_3).clone());
                }
                v861_3_cursor.ascend(1);
              }
              drop(v861_3_cursor);
              drop(v861_2);
              v860_2.join_into((v861_3).clone());
              }
              v860_2_cursor.ascend(1);
            }
            drop(v860_2_cursor);
            v859_3.join_into((v860_2).clone());
            }
            v859_3_cursor.ascend(1);
          }
          drop(v859_3_cursor);
          drop(v859_2);
          v858_3.join_into((v859_3).clone());
          }
          v858_3_cursor.ascend(1);
        }
        drop(v858_3_cursor);
        drop(v858_2);
        v857_3.join_into((v858_3).clone());
        }
        v857_3_cursor.ascend(1);
      }
      drop(v857_3_cursor);
      drop(v857_2);
      v856_2.join_into((v857_3).clone());
      }
      v856_2_cursor.ascend(1);
    }
    drop(v856_2_cursor);
    v855_6.join_into((v856_2).clone());
    }
    v855_6_cursor.ascend(1);
  }
  drop(v855_6_cursor);
  (v855_6).clone()
}

fn routine_71(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v864_6 = Space::new();
  let mut v864_6_cursor = (*s0).read_zipper();
  for v864_6_byte in v864_6_cursor.child_mask().iter() {
    v864_6_cursor.descend_to_byte(v864_6_byte);
    {
    let v864_6_tail = v864_6_cursor.fork_read_zipper();
    let v864_6_head = Path::from_slice(&[v864_6_byte]);
    let mut v865_2 = Space::new();
    let mut v865_2_cursor = (v864_6_tail).read_zipper();
    for v865_2_byte in v865_2_cursor.child_mask().iter() {
      v865_2_cursor.descend_to_byte(v865_2_byte);
      {
      let v865_2_tail = v865_2_cursor.fork_read_zipper();
      let v865_2_head = Path::from_slice(&[v865_2_byte]);
      let v866_2: Path = concat_path(&(v864_6_head),&(v865_2_head));
      let mut v866_3 = Space::new();
      let mut v866_3_cursor = (v865_2_tail).read_zipper();
      for v866_3_byte in v866_3_cursor.child_mask().iter() {
        v866_3_cursor.descend_to_byte(v866_3_byte);
        {
        let v866_3_tail = v866_3_cursor.fork_read_zipper();
        let v866_3_head = Path::from_slice(&[v866_3_byte]);
        let v867_2: Path = concat_path(&(v866_2),&(v866_3_head));
        let mut v867_3 = Space::new();
        let mut v867_3_cursor = (v866_3_tail).read_zipper();
        for v867_3_byte in v867_3_cursor.child_mask().iter() {
          v867_3_cursor.descend_to_byte(v867_3_byte);
          {
          let v867_3_tail = v867_3_cursor.fork_read_zipper();
          let v867_3_head = Path::from_slice(&[v867_3_byte]);
          let v868_2: Path = concat_path(&(v867_2),&(v867_3_head));
          let mut v868_3 = Space::new();
          let mut v868_3_cursor = (v867_3_tail).read_zipper();
          for v868_3_byte in v868_3_cursor.child_mask().iter() {
            v868_3_cursor.descend_to_byte(v868_3_byte);
            {
            let v868_3_tail = v868_3_cursor.fork_read_zipper();
            let v868_3_head = Path::from_slice(&[v868_3_byte]);
            let mut v869_2 = Space::new();
            let mut v869_2_cursor = (v868_3_tail).read_zipper();
            for v869_2_byte in v869_2_cursor.child_mask().iter() {
              v869_2_cursor.descend_to_byte(v869_2_byte);
              {
              let v869_2_tail = v869_2_cursor.fork_read_zipper();
              let v869_2_head = Path::from_slice(&[v869_2_byte]);
              let v870_2: Path = concat_path(&(v868_3_head),&(v869_2_head));
              let mut v870_3 = Space::new();
              let mut v870_3_cursor = (v869_2_tail).read_zipper();
              for v870_3_byte in v870_3_cursor.child_mask().iter() {
                v870_3_cursor.descend_to_byte(v870_3_byte);
                {
                let v870_3_tail = v870_3_cursor.fork_read_zipper();
                let v870_3_head = Path::from_slice(&[v870_3_byte]);
                let v871_2: Path = concat_path(&(v870_2),&(v870_3_head));
                let mut v871_3 = Space::new();
                let mut v871_3_cursor = (v870_3_tail).read_zipper();
                for v871_3_byte in v871_3_cursor.child_mask().iter() {
                  v871_3_cursor.descend_to_byte(v871_3_byte);
                  {
                  let v871_3_tail = v871_3_cursor.fork_read_zipper();
                  let v871_3_head = Path::from_slice(&[v871_3_byte]);
                  let v872_2: Path = concat_path(&(v871_2),&(v871_3_head));
                  let v872_3: Space = routine_87(c, &(v872_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v868_2), &(v871_3_tail).make_space());
                  drop(v872_2);
                  v871_3.join_into((v872_3).clone());
                  }
                  v871_3_cursor.ascend(1);
                }
                drop(v871_3_cursor);
                drop(v871_2);
                v870_3.join_into((v871_3).clone());
                }
                v870_3_cursor.ascend(1);
              }
              drop(v870_3_cursor);
              drop(v870_2);
              v869_2.join_into((v870_3).clone());
              }
              v869_2_cursor.ascend(1);
            }
            drop(v869_2_cursor);
            v868_3.join_into((v869_2).clone());
            }
            v868_3_cursor.ascend(1);
          }
          drop(v868_3_cursor);
          drop(v868_2);
          v867_3.join_into((v868_3).clone());
          }
          v867_3_cursor.ascend(1);
        }
        drop(v867_3_cursor);
        drop(v867_2);
        v866_3.join_into((v867_3).clone());
        }
        v866_3_cursor.ascend(1);
      }
      drop(v866_3_cursor);
      drop(v866_2);
      v865_2.join_into((v866_3).clone());
      }
      v865_2_cursor.ascend(1);
    }
    drop(v865_2_cursor);
    v864_6.join_into((v865_2).clone());
    }
    v864_6_cursor.ascend(1);
  }
  drop(v864_6_cursor);
  (v864_6).clone()
}

fn routine_72(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v873_6 = Space::new();
  let mut v873_6_cursor = (*s0).read_zipper();
  for v873_6_byte in v873_6_cursor.child_mask().iter() {
    v873_6_cursor.descend_to_byte(v873_6_byte);
    {
    let v873_6_tail = v873_6_cursor.fork_read_zipper();
    let v873_6_head = Path::from_slice(&[v873_6_byte]);
    let mut v874_2 = Space::new();
    let mut v874_2_cursor = (v873_6_tail).read_zipper();
    for v874_2_byte in v874_2_cursor.child_mask().iter() {
      v874_2_cursor.descend_to_byte(v874_2_byte);
      {
      let v874_2_tail = v874_2_cursor.fork_read_zipper();
      let v874_2_head = Path::from_slice(&[v874_2_byte]);
      let v875_2: Path = concat_path(&(v873_6_head),&(v874_2_head));
      let mut v875_3 = Space::new();
      let mut v875_3_cursor = (v874_2_tail).read_zipper();
      for v875_3_byte in v875_3_cursor.child_mask().iter() {
        v875_3_cursor.descend_to_byte(v875_3_byte);
        {
        let v875_3_tail = v875_3_cursor.fork_read_zipper();
        let v875_3_head = Path::from_slice(&[v875_3_byte]);
        let v876_2: Path = concat_path(&(v875_2),&(v875_3_head));
        let mut v876_3 = Space::new();
        let mut v876_3_cursor = (v875_3_tail).read_zipper();
        for v876_3_byte in v876_3_cursor.child_mask().iter() {
          v876_3_cursor.descend_to_byte(v876_3_byte);
          {
          let v876_3_tail = v876_3_cursor.fork_read_zipper();
          let v876_3_head = Path::from_slice(&[v876_3_byte]);
          let v877_2: Path = concat_path(&(v876_2),&(v876_3_head));
          let mut v877_3 = Space::new();
          let mut v877_3_cursor = (v876_3_tail).read_zipper();
          for v877_3_byte in v877_3_cursor.child_mask().iter() {
            v877_3_cursor.descend_to_byte(v877_3_byte);
            {
            let v877_3_tail = v877_3_cursor.fork_read_zipper();
            let v877_3_head = Path::from_slice(&[v877_3_byte]);
            let mut v878_2 = Space::new();
            let mut v878_2_cursor = (v877_3_tail).read_zipper();
            for v878_2_byte in v878_2_cursor.child_mask().iter() {
              v878_2_cursor.descend_to_byte(v878_2_byte);
              {
              let v878_2_tail = v878_2_cursor.fork_read_zipper();
              let v878_2_head = Path::from_slice(&[v878_2_byte]);
              let v879_2: Path = concat_path(&(v877_3_head),&(v878_2_head));
              let mut v879_3 = Space::new();
              let mut v879_3_cursor = (v878_2_tail).read_zipper();
              for v879_3_byte in v879_3_cursor.child_mask().iter() {
                v879_3_cursor.descend_to_byte(v879_3_byte);
                {
                let v879_3_tail = v879_3_cursor.fork_read_zipper();
                let v879_3_head = Path::from_slice(&[v879_3_byte]);
                let v880_2: Path = concat_path(&(v879_2),&(v879_3_head));
                let mut v880_3 = Space::new();
                let mut v880_3_cursor = (v879_3_tail).read_zipper();
                for v880_3_byte in v880_3_cursor.child_mask().iter() {
                  v880_3_cursor.descend_to_byte(v880_3_byte);
                  {
                  let v880_3_tail = v880_3_cursor.fork_read_zipper();
                  let v880_3_head = Path::from_slice(&[v880_3_byte]);
                  let v881_2: Path = concat_path(&(v880_2),&(v880_3_head));
                  let v881_3: Space = routine_88(c, &(v881_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v877_2), &(v880_3_tail).make_space());
                  drop(v881_2);
                  v880_3.join_into((v881_3).clone());
                  }
                  v880_3_cursor.ascend(1);
                }
                drop(v880_3_cursor);
                drop(v880_2);
                v879_3.join_into((v880_3).clone());
                }
                v879_3_cursor.ascend(1);
              }
              drop(v879_3_cursor);
              drop(v879_2);
              v878_2.join_into((v879_3).clone());
              }
              v878_2_cursor.ascend(1);
            }
            drop(v878_2_cursor);
            v877_3.join_into((v878_2).clone());
            }
            v877_3_cursor.ascend(1);
          }
          drop(v877_3_cursor);
          drop(v877_2);
          v876_3.join_into((v877_3).clone());
          }
          v876_3_cursor.ascend(1);
        }
        drop(v876_3_cursor);
        drop(v876_2);
        v875_3.join_into((v876_3).clone());
        }
        v875_3_cursor.ascend(1);
      }
      drop(v875_3_cursor);
      drop(v875_2);
      v874_2.join_into((v875_3).clone());
      }
      v874_2_cursor.ascend(1);
    }
    drop(v874_2_cursor);
    v873_6.join_into((v874_2).clone());
    }
    v873_6_cursor.ascend(1);
  }
  drop(v873_6_cursor);
  (v873_6).clone()
}

fn routine_73(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v882_6 = Space::new();
  let mut v882_6_cursor = (*s0).read_zipper();
  for v882_6_byte in v882_6_cursor.child_mask().iter() {
    v882_6_cursor.descend_to_byte(v882_6_byte);
    {
    let v882_6_tail = v882_6_cursor.fork_read_zipper();
    let v882_6_head = Path::from_slice(&[v882_6_byte]);
    let mut v883_2 = Space::new();
    let mut v883_2_cursor = (v882_6_tail).read_zipper();
    for v883_2_byte in v883_2_cursor.child_mask().iter() {
      v883_2_cursor.descend_to_byte(v883_2_byte);
      {
      let v883_2_tail = v883_2_cursor.fork_read_zipper();
      let v883_2_head = Path::from_slice(&[v883_2_byte]);
      let v884_2: Path = concat_path(&(v882_6_head),&(v883_2_head));
      let mut v884_3 = Space::new();
      let mut v884_3_cursor = (v883_2_tail).read_zipper();
      for v884_3_byte in v884_3_cursor.child_mask().iter() {
        v884_3_cursor.descend_to_byte(v884_3_byte);
        {
        let v884_3_tail = v884_3_cursor.fork_read_zipper();
        let v884_3_head = Path::from_slice(&[v884_3_byte]);
        let v885_2: Path = concat_path(&(v884_2),&(v884_3_head));
        let mut v885_3 = Space::new();
        let mut v885_3_cursor = (v884_3_tail).read_zipper();
        for v885_3_byte in v885_3_cursor.child_mask().iter() {
          v885_3_cursor.descend_to_byte(v885_3_byte);
          {
          let v885_3_tail = v885_3_cursor.fork_read_zipper();
          let v885_3_head = Path::from_slice(&[v885_3_byte]);
          let v886_2: Path = concat_path(&(v885_2),&(v885_3_head));
          let mut v886_3 = Space::new();
          let mut v886_3_cursor = (v885_3_tail).read_zipper();
          for v886_3_byte in v886_3_cursor.child_mask().iter() {
            v886_3_cursor.descend_to_byte(v886_3_byte);
            {
            let v886_3_tail = v886_3_cursor.fork_read_zipper();
            let v886_3_head = Path::from_slice(&[v886_3_byte]);
            let mut v887_2 = Space::new();
            let mut v887_2_cursor = (v886_3_tail).read_zipper();
            for v887_2_byte in v887_2_cursor.child_mask().iter() {
              v887_2_cursor.descend_to_byte(v887_2_byte);
              {
              let v887_2_tail = v887_2_cursor.fork_read_zipper();
              let v887_2_head = Path::from_slice(&[v887_2_byte]);
              let v888_2: Path = concat_path(&(v886_3_head),&(v887_2_head));
              let mut v888_3 = Space::new();
              let mut v888_3_cursor = (v887_2_tail).read_zipper();
              for v888_3_byte in v888_3_cursor.child_mask().iter() {
                v888_3_cursor.descend_to_byte(v888_3_byte);
                {
                let v888_3_tail = v888_3_cursor.fork_read_zipper();
                let v888_3_head = Path::from_slice(&[v888_3_byte]);
                let v889_2: Path = concat_path(&(v888_2),&(v888_3_head));
                let mut v889_3 = Space::new();
                let mut v889_3_cursor = (v888_3_tail).read_zipper();
                for v889_3_byte in v889_3_cursor.child_mask().iter() {
                  v889_3_cursor.descend_to_byte(v889_3_byte);
                  {
                  let v889_3_tail = v889_3_cursor.fork_read_zipper();
                  let v889_3_head = Path::from_slice(&[v889_3_byte]);
                  let v890_2: Path = concat_path(&(v889_2),&(v889_3_head));
                  let v890_3: Space = routine_89(c, &(v890_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v886_2), &(v889_3_tail).make_space());
                  drop(v890_2);
                  v889_3.join_into((v890_3).clone());
                  }
                  v889_3_cursor.ascend(1);
                }
                drop(v889_3_cursor);
                drop(v889_2);
                v888_3.join_into((v889_3).clone());
                }
                v888_3_cursor.ascend(1);
              }
              drop(v888_3_cursor);
              drop(v888_2);
              v887_2.join_into((v888_3).clone());
              }
              v887_2_cursor.ascend(1);
            }
            drop(v887_2_cursor);
            v886_3.join_into((v887_2).clone());
            }
            v886_3_cursor.ascend(1);
          }
          drop(v886_3_cursor);
          drop(v886_2);
          v885_3.join_into((v886_3).clone());
          }
          v885_3_cursor.ascend(1);
        }
        drop(v885_3_cursor);
        drop(v885_2);
        v884_3.join_into((v885_3).clone());
        }
        v884_3_cursor.ascend(1);
      }
      drop(v884_3_cursor);
      drop(v884_2);
      v883_2.join_into((v884_3).clone());
      }
      v883_2_cursor.ascend(1);
    }
    drop(v883_2_cursor);
    v882_6.join_into((v883_2).clone());
    }
    v882_6_cursor.ascend(1);
  }
  drop(v882_6_cursor);
  (v882_6).clone()
}

fn routine_74(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v891_6 = Space::new();
  let mut v891_6_cursor = (*s0).read_zipper();
  for v891_6_byte in v891_6_cursor.child_mask().iter() {
    v891_6_cursor.descend_to_byte(v891_6_byte);
    {
    let v891_6_tail = v891_6_cursor.fork_read_zipper();
    let v891_6_head = Path::from_slice(&[v891_6_byte]);
    let mut v892_2 = Space::new();
    let mut v892_2_cursor = (v891_6_tail).read_zipper();
    for v892_2_byte in v892_2_cursor.child_mask().iter() {
      v892_2_cursor.descend_to_byte(v892_2_byte);
      {
      let v892_2_tail = v892_2_cursor.fork_read_zipper();
      let v892_2_head = Path::from_slice(&[v892_2_byte]);
      let v893_2: Path = concat_path(&(v891_6_head),&(v892_2_head));
      let mut v893_3 = Space::new();
      let mut v893_3_cursor = (v892_2_tail).read_zipper();
      for v893_3_byte in v893_3_cursor.child_mask().iter() {
        v893_3_cursor.descend_to_byte(v893_3_byte);
        {
        let v893_3_tail = v893_3_cursor.fork_read_zipper();
        let v893_3_head = Path::from_slice(&[v893_3_byte]);
        let v894_2: Path = concat_path(&(v893_2),&(v893_3_head));
        let mut v894_3 = Space::new();
        let mut v894_3_cursor = (v893_3_tail).read_zipper();
        for v894_3_byte in v894_3_cursor.child_mask().iter() {
          v894_3_cursor.descend_to_byte(v894_3_byte);
          {
          let v894_3_tail = v894_3_cursor.fork_read_zipper();
          let v894_3_head = Path::from_slice(&[v894_3_byte]);
          let v895_2: Path = concat_path(&(v894_2),&(v894_3_head));
          let mut v895_3 = Space::new();
          let mut v895_3_cursor = (v894_3_tail).read_zipper();
          for v895_3_byte in v895_3_cursor.child_mask().iter() {
            v895_3_cursor.descend_to_byte(v895_3_byte);
            {
            let v895_3_tail = v895_3_cursor.fork_read_zipper();
            let v895_3_head = Path::from_slice(&[v895_3_byte]);
            let mut v896_2 = Space::new();
            let mut v896_2_cursor = (v895_3_tail).read_zipper();
            for v896_2_byte in v896_2_cursor.child_mask().iter() {
              v896_2_cursor.descend_to_byte(v896_2_byte);
              {
              let v896_2_tail = v896_2_cursor.fork_read_zipper();
              let v896_2_head = Path::from_slice(&[v896_2_byte]);
              let v897_2: Path = concat_path(&(v895_3_head),&(v896_2_head));
              let mut v897_3 = Space::new();
              let mut v897_3_cursor = (v896_2_tail).read_zipper();
              for v897_3_byte in v897_3_cursor.child_mask().iter() {
                v897_3_cursor.descend_to_byte(v897_3_byte);
                {
                let v897_3_tail = v897_3_cursor.fork_read_zipper();
                let v897_3_head = Path::from_slice(&[v897_3_byte]);
                let v898_2: Path = concat_path(&(v897_2),&(v897_3_head));
                let mut v898_3 = Space::new();
                let mut v898_3_cursor = (v897_3_tail).read_zipper();
                for v898_3_byte in v898_3_cursor.child_mask().iter() {
                  v898_3_cursor.descend_to_byte(v898_3_byte);
                  {
                  let v898_3_tail = v898_3_cursor.fork_read_zipper();
                  let v898_3_head = Path::from_slice(&[v898_3_byte]);
                  let v899_2: Path = concat_path(&(v898_2),&(v898_3_head));
                  let v899_3: Space = routine_90(c, &(v899_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v895_2), &(v898_3_tail).make_space());
                  drop(v899_2);
                  v898_3.join_into((v899_3).clone());
                  }
                  v898_3_cursor.ascend(1);
                }
                drop(v898_3_cursor);
                drop(v898_2);
                v897_3.join_into((v898_3).clone());
                }
                v897_3_cursor.ascend(1);
              }
              drop(v897_3_cursor);
              drop(v897_2);
              v896_2.join_into((v897_3).clone());
              }
              v896_2_cursor.ascend(1);
            }
            drop(v896_2_cursor);
            v895_3.join_into((v896_2).clone());
            }
            v895_3_cursor.ascend(1);
          }
          drop(v895_3_cursor);
          drop(v895_2);
          v894_3.join_into((v895_3).clone());
          }
          v894_3_cursor.ascend(1);
        }
        drop(v894_3_cursor);
        drop(v894_2);
        v893_3.join_into((v894_3).clone());
        }
        v893_3_cursor.ascend(1);
      }
      drop(v893_3_cursor);
      drop(v893_2);
      v892_2.join_into((v893_3).clone());
      }
      v892_2_cursor.ascend(1);
    }
    drop(v892_2_cursor);
    v891_6.join_into((v892_2).clone());
    }
    v891_6_cursor.ascend(1);
  }
  drop(v891_6_cursor);
  (v891_6).clone()
}

fn routine_75(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v900_6 = Space::new();
  let mut v900_6_cursor = (*s0).read_zipper();
  for v900_6_byte in v900_6_cursor.child_mask().iter() {
    v900_6_cursor.descend_to_byte(v900_6_byte);
    {
    let v900_6_tail = v900_6_cursor.fork_read_zipper();
    let v900_6_head = Path::from_slice(&[v900_6_byte]);
    let mut v901_2 = Space::new();
    let mut v901_2_cursor = (v900_6_tail).read_zipper();
    for v901_2_byte in v901_2_cursor.child_mask().iter() {
      v901_2_cursor.descend_to_byte(v901_2_byte);
      {
      let v901_2_tail = v901_2_cursor.fork_read_zipper();
      let v901_2_head = Path::from_slice(&[v901_2_byte]);
      let v902_2: Path = concat_path(&(v900_6_head),&(v901_2_head));
      let mut v902_3 = Space::new();
      let mut v902_3_cursor = (v901_2_tail).read_zipper();
      for v902_3_byte in v902_3_cursor.child_mask().iter() {
        v902_3_cursor.descend_to_byte(v902_3_byte);
        {
        let v902_3_tail = v902_3_cursor.fork_read_zipper();
        let v902_3_head = Path::from_slice(&[v902_3_byte]);
        let v903_2: Path = concat_path(&(v902_2),&(v902_3_head));
        let mut v903_3 = Space::new();
        let mut v903_3_cursor = (v902_3_tail).read_zipper();
        for v903_3_byte in v903_3_cursor.child_mask().iter() {
          v903_3_cursor.descend_to_byte(v903_3_byte);
          {
          let v903_3_tail = v903_3_cursor.fork_read_zipper();
          let v903_3_head = Path::from_slice(&[v903_3_byte]);
          let v904_2: Path = concat_path(&(v903_2),&(v903_3_head));
          let mut v904_3 = Space::new();
          let mut v904_3_cursor = (v903_3_tail).read_zipper();
          for v904_3_byte in v904_3_cursor.child_mask().iter() {
            v904_3_cursor.descend_to_byte(v904_3_byte);
            {
            let v904_3_tail = v904_3_cursor.fork_read_zipper();
            let v904_3_head = Path::from_slice(&[v904_3_byte]);
            let mut v905_2 = Space::new();
            let mut v905_2_cursor = (v904_3_tail).read_zipper();
            for v905_2_byte in v905_2_cursor.child_mask().iter() {
              v905_2_cursor.descend_to_byte(v905_2_byte);
              {
              let v905_2_tail = v905_2_cursor.fork_read_zipper();
              let v905_2_head = Path::from_slice(&[v905_2_byte]);
              let v906_2: Path = concat_path(&(v904_3_head),&(v905_2_head));
              let mut v906_3 = Space::new();
              let mut v906_3_cursor = (v905_2_tail).read_zipper();
              for v906_3_byte in v906_3_cursor.child_mask().iter() {
                v906_3_cursor.descend_to_byte(v906_3_byte);
                {
                let v906_3_tail = v906_3_cursor.fork_read_zipper();
                let v906_3_head = Path::from_slice(&[v906_3_byte]);
                let v907_2: Path = concat_path(&(v906_2),&(v906_3_head));
                let mut v907_3 = Space::new();
                let mut v907_3_cursor = (v906_3_tail).read_zipper();
                for v907_3_byte in v907_3_cursor.child_mask().iter() {
                  v907_3_cursor.descend_to_byte(v907_3_byte);
                  {
                  let v907_3_tail = v907_3_cursor.fork_read_zipper();
                  let v907_3_head = Path::from_slice(&[v907_3_byte]);
                  let v908_2: Path = concat_path(&(v907_2),&(v907_3_head));
                  let v908_3: Space = routine_91(c, &(v908_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v904_2), &(v907_3_tail).make_space());
                  drop(v908_2);
                  v907_3.join_into((v908_3).clone());
                  }
                  v907_3_cursor.ascend(1);
                }
                drop(v907_3_cursor);
                drop(v907_2);
                v906_3.join_into((v907_3).clone());
                }
                v906_3_cursor.ascend(1);
              }
              drop(v906_3_cursor);
              drop(v906_2);
              v905_2.join_into((v906_3).clone());
              }
              v905_2_cursor.ascend(1);
            }
            drop(v905_2_cursor);
            v904_3.join_into((v905_2).clone());
            }
            v904_3_cursor.ascend(1);
          }
          drop(v904_3_cursor);
          drop(v904_2);
          v903_3.join_into((v904_3).clone());
          }
          v903_3_cursor.ascend(1);
        }
        drop(v903_3_cursor);
        drop(v903_2);
        v902_3.join_into((v903_3).clone());
        }
        v902_3_cursor.ascend(1);
      }
      drop(v902_3_cursor);
      drop(v902_2);
      v901_2.join_into((v902_3).clone());
      }
      v901_2_cursor.ascend(1);
    }
    drop(v901_2_cursor);
    v900_6.join_into((v901_2).clone());
    }
    v900_6_cursor.ascend(1);
  }
  drop(v900_6_cursor);
  (v900_6).clone()
}

fn routine_76(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v909_6 = Space::new();
  let mut v909_6_cursor = (*s0).read_zipper();
  for v909_6_byte in v909_6_cursor.child_mask().iter() {
    v909_6_cursor.descend_to_byte(v909_6_byte);
    {
    let v909_6_tail = v909_6_cursor.fork_read_zipper();
    let v909_6_head = Path::from_slice(&[v909_6_byte]);
    let mut v910_2 = Space::new();
    let mut v910_2_cursor = (v909_6_tail).read_zipper();
    for v910_2_byte in v910_2_cursor.child_mask().iter() {
      v910_2_cursor.descend_to_byte(v910_2_byte);
      {
      let v910_2_tail = v910_2_cursor.fork_read_zipper();
      let v910_2_head = Path::from_slice(&[v910_2_byte]);
      let v911_2: Path = concat_path(&(v909_6_head),&(v910_2_head));
      let mut v911_3 = Space::new();
      let mut v911_3_cursor = (v910_2_tail).read_zipper();
      for v911_3_byte in v911_3_cursor.child_mask().iter() {
        v911_3_cursor.descend_to_byte(v911_3_byte);
        {
        let v911_3_tail = v911_3_cursor.fork_read_zipper();
        let v911_3_head = Path::from_slice(&[v911_3_byte]);
        let v912_2: Path = concat_path(&(v911_2),&(v911_3_head));
        let mut v912_3 = Space::new();
        let mut v912_3_cursor = (v911_3_tail).read_zipper();
        for v912_3_byte in v912_3_cursor.child_mask().iter() {
          v912_3_cursor.descend_to_byte(v912_3_byte);
          {
          let v912_3_tail = v912_3_cursor.fork_read_zipper();
          let v912_3_head = Path::from_slice(&[v912_3_byte]);
          let v913_2: Path = concat_path(&(v912_2),&(v912_3_head));
          let mut v913_3 = Space::new();
          let mut v913_3_cursor = (v912_3_tail).read_zipper();
          for v913_3_byte in v913_3_cursor.child_mask().iter() {
            v913_3_cursor.descend_to_byte(v913_3_byte);
            {
            let v913_3_tail = v913_3_cursor.fork_read_zipper();
            let v913_3_head = Path::from_slice(&[v913_3_byte]);
            let mut v914_2 = Space::new();
            let mut v914_2_cursor = (v913_3_tail).read_zipper();
            for v914_2_byte in v914_2_cursor.child_mask().iter() {
              v914_2_cursor.descend_to_byte(v914_2_byte);
              {
              let v914_2_tail = v914_2_cursor.fork_read_zipper();
              let v914_2_head = Path::from_slice(&[v914_2_byte]);
              let v915_2: Path = concat_path(&(v913_3_head),&(v914_2_head));
              let mut v915_3 = Space::new();
              let mut v915_3_cursor = (v914_2_tail).read_zipper();
              for v915_3_byte in v915_3_cursor.child_mask().iter() {
                v915_3_cursor.descend_to_byte(v915_3_byte);
                {
                let v915_3_tail = v915_3_cursor.fork_read_zipper();
                let v915_3_head = Path::from_slice(&[v915_3_byte]);
                let v916_2: Path = concat_path(&(v915_2),&(v915_3_head));
                let mut v916_3 = Space::new();
                let mut v916_3_cursor = (v915_3_tail).read_zipper();
                for v916_3_byte in v916_3_cursor.child_mask().iter() {
                  v916_3_cursor.descend_to_byte(v916_3_byte);
                  {
                  let v916_3_tail = v916_3_cursor.fork_read_zipper();
                  let v916_3_head = Path::from_slice(&[v916_3_byte]);
                  let v917_2: Path = concat_path(&(v916_2),&(v916_3_head));
                  let v917_3: Space = routine_92(c, &(v917_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v913_2), &(v916_3_tail).make_space());
                  drop(v917_2);
                  v916_3.join_into((v917_3).clone());
                  }
                  v916_3_cursor.ascend(1);
                }
                drop(v916_3_cursor);
                drop(v916_2);
                v915_3.join_into((v916_3).clone());
                }
                v915_3_cursor.ascend(1);
              }
              drop(v915_3_cursor);
              drop(v915_2);
              v914_2.join_into((v915_3).clone());
              }
              v914_2_cursor.ascend(1);
            }
            drop(v914_2_cursor);
            v913_3.join_into((v914_2).clone());
            }
            v913_3_cursor.ascend(1);
          }
          drop(v913_3_cursor);
          drop(v913_2);
          v912_3.join_into((v913_3).clone());
          }
          v912_3_cursor.ascend(1);
        }
        drop(v912_3_cursor);
        drop(v912_2);
        v911_3.join_into((v912_3).clone());
        }
        v911_3_cursor.ascend(1);
      }
      drop(v911_3_cursor);
      drop(v911_2);
      v910_2.join_into((v911_3).clone());
      }
      v910_2_cursor.ascend(1);
    }
    drop(v910_2_cursor);
    v909_6.join_into((v910_2).clone());
    }
    v909_6_cursor.ascend(1);
  }
  drop(v909_6_cursor);
  (v909_6).clone()
}

fn routine_77(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v918_6 = Space::new();
  let mut v918_6_cursor = (*s0).read_zipper();
  for v918_6_byte in v918_6_cursor.child_mask().iter() {
    v918_6_cursor.descend_to_byte(v918_6_byte);
    {
    let v918_6_tail = v918_6_cursor.fork_read_zipper();
    let v918_6_head = Path::from_slice(&[v918_6_byte]);
    let mut v919_2 = Space::new();
    let mut v919_2_cursor = (v918_6_tail).read_zipper();
    for v919_2_byte in v919_2_cursor.child_mask().iter() {
      v919_2_cursor.descend_to_byte(v919_2_byte);
      {
      let v919_2_tail = v919_2_cursor.fork_read_zipper();
      let v919_2_head = Path::from_slice(&[v919_2_byte]);
      let v920_2: Path = concat_path(&(v918_6_head),&(v919_2_head));
      let mut v920_3 = Space::new();
      let mut v920_3_cursor = (v919_2_tail).read_zipper();
      for v920_3_byte in v920_3_cursor.child_mask().iter() {
        v920_3_cursor.descend_to_byte(v920_3_byte);
        {
        let v920_3_tail = v920_3_cursor.fork_read_zipper();
        let v920_3_head = Path::from_slice(&[v920_3_byte]);
        let v921_2: Path = concat_path(&(v920_2),&(v920_3_head));
        let mut v921_3 = Space::new();
        let mut v921_3_cursor = (v920_3_tail).read_zipper();
        for v921_3_byte in v921_3_cursor.child_mask().iter() {
          v921_3_cursor.descend_to_byte(v921_3_byte);
          {
          let v921_3_tail = v921_3_cursor.fork_read_zipper();
          let v921_3_head = Path::from_slice(&[v921_3_byte]);
          let v922_2: Path = concat_path(&(v921_2),&(v921_3_head));
          let mut v922_3 = Space::new();
          let mut v922_3_cursor = (v921_3_tail).read_zipper();
          for v922_3_byte in v922_3_cursor.child_mask().iter() {
            v922_3_cursor.descend_to_byte(v922_3_byte);
            {
            let v922_3_tail = v922_3_cursor.fork_read_zipper();
            let v922_3_head = Path::from_slice(&[v922_3_byte]);
            let mut v923_2 = Space::new();
            let mut v923_2_cursor = (v922_3_tail).read_zipper();
            for v923_2_byte in v923_2_cursor.child_mask().iter() {
              v923_2_cursor.descend_to_byte(v923_2_byte);
              {
              let v923_2_tail = v923_2_cursor.fork_read_zipper();
              let v923_2_head = Path::from_slice(&[v923_2_byte]);
              let v924_2: Path = concat_path(&(v922_3_head),&(v923_2_head));
              let mut v924_3 = Space::new();
              let mut v924_3_cursor = (v923_2_tail).read_zipper();
              for v924_3_byte in v924_3_cursor.child_mask().iter() {
                v924_3_cursor.descend_to_byte(v924_3_byte);
                {
                let v924_3_tail = v924_3_cursor.fork_read_zipper();
                let v924_3_head = Path::from_slice(&[v924_3_byte]);
                let v925_2: Path = concat_path(&(v924_2),&(v924_3_head));
                let mut v925_3 = Space::new();
                let mut v925_3_cursor = (v924_3_tail).read_zipper();
                for v925_3_byte in v925_3_cursor.child_mask().iter() {
                  v925_3_cursor.descend_to_byte(v925_3_byte);
                  {
                  let v925_3_tail = v925_3_cursor.fork_read_zipper();
                  let v925_3_head = Path::from_slice(&[v925_3_byte]);
                  let v926_2: Path = concat_path(&(v925_2),&(v925_3_head));
                  let v926_3: Space = routine_93(c, &(v926_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v922_2), &(v925_3_tail).make_space());
                  drop(v926_2);
                  v925_3.join_into((v926_3).clone());
                  }
                  v925_3_cursor.ascend(1);
                }
                drop(v925_3_cursor);
                drop(v925_2);
                v924_3.join_into((v925_3).clone());
                }
                v924_3_cursor.ascend(1);
              }
              drop(v924_3_cursor);
              drop(v924_2);
              v923_2.join_into((v924_3).clone());
              }
              v923_2_cursor.ascend(1);
            }
            drop(v923_2_cursor);
            v922_3.join_into((v923_2).clone());
            }
            v922_3_cursor.ascend(1);
          }
          drop(v922_3_cursor);
          drop(v922_2);
          v921_3.join_into((v922_3).clone());
          }
          v921_3_cursor.ascend(1);
        }
        drop(v921_3_cursor);
        drop(v921_2);
        v920_3.join_into((v921_3).clone());
        }
        v920_3_cursor.ascend(1);
      }
      drop(v920_3_cursor);
      drop(v920_2);
      v919_2.join_into((v920_3).clone());
      }
      v919_2_cursor.ascend(1);
    }
    drop(v919_2_cursor);
    v918_6.join_into((v919_2).clone());
    }
    v918_6_cursor.ascend(1);
  }
  drop(v918_6_cursor);
  (v918_6).clone()
}

fn routine_78(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, s0: &Space) -> Space {
  let mut v927_6 = Space::new();
  let mut v927_6_cursor = (*s0).read_zipper();
  for v927_6_byte in v927_6_cursor.child_mask().iter() {
    v927_6_cursor.descend_to_byte(v927_6_byte);
    {
    let v927_6_tail = v927_6_cursor.fork_read_zipper();
    let v927_6_head = Path::from_slice(&[v927_6_byte]);
    let mut v928_2 = Space::new();
    let mut v928_2_cursor = (v927_6_tail).read_zipper();
    for v928_2_byte in v928_2_cursor.child_mask().iter() {
      v928_2_cursor.descend_to_byte(v928_2_byte);
      {
      let v928_2_tail = v928_2_cursor.fork_read_zipper();
      let v928_2_head = Path::from_slice(&[v928_2_byte]);
      let v929_2: Path = concat_path(&(v927_6_head),&(v928_2_head));
      let mut v929_3 = Space::new();
      let mut v929_3_cursor = (v928_2_tail).read_zipper();
      for v929_3_byte in v929_3_cursor.child_mask().iter() {
        v929_3_cursor.descend_to_byte(v929_3_byte);
        {
        let v929_3_tail = v929_3_cursor.fork_read_zipper();
        let v929_3_head = Path::from_slice(&[v929_3_byte]);
        let v930_2: Path = concat_path(&(v929_2),&(v929_3_head));
        let mut v930_3 = Space::new();
        let mut v930_3_cursor = (v929_3_tail).read_zipper();
        for v930_3_byte in v930_3_cursor.child_mask().iter() {
          v930_3_cursor.descend_to_byte(v930_3_byte);
          {
          let v930_3_tail = v930_3_cursor.fork_read_zipper();
          let v930_3_head = Path::from_slice(&[v930_3_byte]);
          let v931_2: Path = concat_path(&(v930_2),&(v930_3_head));
          let mut v931_3 = Space::new();
          let mut v931_3_cursor = (v930_3_tail).read_zipper();
          for v931_3_byte in v931_3_cursor.child_mask().iter() {
            v931_3_cursor.descend_to_byte(v931_3_byte);
            {
            let v931_3_tail = v931_3_cursor.fork_read_zipper();
            let v931_3_head = Path::from_slice(&[v931_3_byte]);
            let mut v932_2 = Space::new();
            let mut v932_2_cursor = (v931_3_tail).read_zipper();
            for v932_2_byte in v932_2_cursor.child_mask().iter() {
              v932_2_cursor.descend_to_byte(v932_2_byte);
              {
              let v932_2_tail = v932_2_cursor.fork_read_zipper();
              let v932_2_head = Path::from_slice(&[v932_2_byte]);
              let v933_2: Path = concat_path(&(v931_3_head),&(v932_2_head));
              let mut v933_3 = Space::new();
              let mut v933_3_cursor = (v932_2_tail).read_zipper();
              for v933_3_byte in v933_3_cursor.child_mask().iter() {
                v933_3_cursor.descend_to_byte(v933_3_byte);
                {
                let v933_3_tail = v933_3_cursor.fork_read_zipper();
                let v933_3_head = Path::from_slice(&[v933_3_byte]);
                let v934_2: Path = concat_path(&(v933_2),&(v933_3_head));
                let mut v934_3 = Space::new();
                let mut v934_3_cursor = (v933_3_tail).read_zipper();
                for v934_3_byte in v934_3_cursor.child_mask().iter() {
                  v934_3_cursor.descend_to_byte(v934_3_byte);
                  {
                  let v934_3_tail = v934_3_cursor.fork_read_zipper();
                  let v934_3_head = Path::from_slice(&[v934_3_byte]);
                  let v935_2: Path = concat_path(&(v934_2),&(v934_3_head));
                  let v935_3: Space = routine_94(c, &(v935_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p0), &(v931_2), &(v934_3_tail).make_space());
                  drop(v935_2);
                  v934_3.join_into((v935_3).clone());
                  }
                  v934_3_cursor.ascend(1);
                }
                drop(v934_3_cursor);
                drop(v934_2);
                v933_3.join_into((v934_3).clone());
                }
                v933_3_cursor.ascend(1);
              }
              drop(v933_3_cursor);
              drop(v933_2);
              v932_2.join_into((v933_3).clone());
              }
              v932_2_cursor.ascend(1);
            }
            drop(v932_2_cursor);
            v931_3.join_into((v932_2).clone());
            }
            v931_3_cursor.ascend(1);
          }
          drop(v931_3_cursor);
          drop(v931_2);
          v930_3.join_into((v931_3).clone());
          }
          v930_3_cursor.ascend(1);
        }
        drop(v930_3_cursor);
        drop(v930_2);
        v929_3.join_into((v930_3).clone());
        }
        v929_3_cursor.ascend(1);
      }
      drop(v929_3_cursor);
      drop(v929_2);
      v928_2.join_into((v929_3).clone());
      }
      v928_2_cursor.ascend(1);
    }
    drop(v928_2_cursor);
    v927_6.join_into((v928_2).clone());
    }
    v927_6_cursor.ascend(1);
  }
  drop(v927_6_cursor);
  (v927_6).clone()
}

fn routine_79(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v936_8 = Space::new();
  let mut v936_8_cursor = (*s0).read_zipper();
  for v936_8_byte in v936_8_cursor.child_mask().iter() {
    v936_8_cursor.descend_to_byte(v936_8_byte);
    {
    let v936_8_tail = v936_8_cursor.fork_read_zipper();
    let v936_8_head = Path::from_slice(&[v936_8_byte]);
    let mut v937_2 = Space::new();
    let mut v937_2_cursor = (v936_8_tail).read_zipper();
    for v937_2_byte in v937_2_cursor.child_mask().iter() {
      v937_2_cursor.descend_to_byte(v937_2_byte);
      {
      let v937_2_tail = v937_2_cursor.fork_read_zipper();
      let v937_2_head = Path::from_slice(&[v937_2_byte]);
      let v938_2: Path = concat_path(&(v936_8_head),&(v937_2_head));
      let mut v938_3 = Space::new();
      let mut v938_3_cursor = (v937_2_tail).read_zipper();
      for v938_3_byte in v938_3_cursor.child_mask().iter() {
        v938_3_cursor.descend_to_byte(v938_3_byte);
        {
        let v938_3_tail = v938_3_cursor.fork_read_zipper();
        let v938_3_head = Path::from_slice(&[v938_3_byte]);
        let v939_2: Path = concat_path(&(v938_2),&(v938_3_head));
        let mut v939_3 = Space::new();
        let mut v939_3_cursor = (v938_3_tail).read_zipper();
        for v939_3_byte in v939_3_cursor.child_mask().iter() {
          v939_3_cursor.descend_to_byte(v939_3_byte);
          {
          let v939_3_tail = v939_3_cursor.fork_read_zipper();
          let v939_3_head = Path::from_slice(&[v939_3_byte]);
          let v940_2: Path = concat_path(&(v939_2),&(v939_3_head));
          let mut v940_3 = Space::new();
          let mut v940_3_cursor = (v939_3_tail).read_zipper();
          for v940_3_byte in v940_3_cursor.child_mask().iter() {
            v940_3_cursor.descend_to_byte(v940_3_byte);
            {
            let v940_3_tail = v940_3_cursor.fork_read_zipper();
            let v940_3_head = Path::from_slice(&[v940_3_byte]);
            let mut v941_2 = Space::new();
            let mut v941_2_cursor = (v940_3_tail).read_zipper();
            for v941_2_byte in v941_2_cursor.child_mask().iter() {
              v941_2_cursor.descend_to_byte(v941_2_byte);
              {
              let v941_2_tail = v941_2_cursor.fork_read_zipper();
              let v941_2_head = Path::from_slice(&[v941_2_byte]);
              let v942_2: Path = concat_path(&(v940_3_head),&(v941_2_head));
              let mut v942_3 = Space::new();
              let mut v942_3_cursor = (v941_2_tail).read_zipper();
              for v942_3_byte in v942_3_cursor.child_mask().iter() {
                v942_3_cursor.descend_to_byte(v942_3_byte);
                {
                let v942_3_tail = v942_3_cursor.fork_read_zipper();
                let v942_3_head = Path::from_slice(&[v942_3_byte]);
                let v943_2: Path = concat_path(&(v942_2),&(v942_3_head));
                let mut v943_3 = Space::new();
                let mut v943_3_cursor = (v942_3_tail).read_zipper();
                for v943_3_byte in v943_3_cursor.child_mask().iter() {
                  v943_3_cursor.descend_to_byte(v943_3_byte);
                  {
                  let v943_3_tail = v943_3_cursor.fork_read_zipper();
                  let v943_3_head = Path::from_slice(&[v943_3_byte]);
                  let v944_2: Path = concat_path(&(v943_2),&(v943_3_head));
                  let v944_3: Space = routine_95(c, &(v944_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v940_2), &(v943_3_tail).make_space());
                  drop(v944_2);
                  v943_3.join_into((v944_3).clone());
                  }
                  v943_3_cursor.ascend(1);
                }
                drop(v943_3_cursor);
                drop(v943_2);
                v942_3.join_into((v943_3).clone());
                }
                v942_3_cursor.ascend(1);
              }
              drop(v942_3_cursor);
              drop(v942_2);
              v941_2.join_into((v942_3).clone());
              }
              v941_2_cursor.ascend(1);
            }
            drop(v941_2_cursor);
            v940_3.join_into((v941_2).clone());
            }
            v940_3_cursor.ascend(1);
          }
          drop(v940_3_cursor);
          drop(v940_2);
          v939_3.join_into((v940_3).clone());
          }
          v939_3_cursor.ascend(1);
        }
        drop(v939_3_cursor);
        drop(v939_2);
        v938_3.join_into((v939_3).clone());
        }
        v938_3_cursor.ascend(1);
      }
      drop(v938_3_cursor);
      drop(v938_2);
      v937_2.join_into((v938_3).clone());
      }
      v937_2_cursor.ascend(1);
    }
    drop(v937_2_cursor);
    v936_8.join_into((v937_2).clone());
    }
    v936_8_cursor.ascend(1);
  }
  drop(v936_8_cursor);
  (v936_8).clone()
}

fn routine_80(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v945_8 = Space::new();
  let mut v945_8_cursor = (*s0).read_zipper();
  for v945_8_byte in v945_8_cursor.child_mask().iter() {
    v945_8_cursor.descend_to_byte(v945_8_byte);
    {
    let v945_8_tail = v945_8_cursor.fork_read_zipper();
    let v945_8_head = Path::from_slice(&[v945_8_byte]);
    let mut v946_2 = Space::new();
    let mut v946_2_cursor = (v945_8_tail).read_zipper();
    for v946_2_byte in v946_2_cursor.child_mask().iter() {
      v946_2_cursor.descend_to_byte(v946_2_byte);
      {
      let v946_2_tail = v946_2_cursor.fork_read_zipper();
      let v946_2_head = Path::from_slice(&[v946_2_byte]);
      let v947_2: Path = concat_path(&(v945_8_head),&(v946_2_head));
      let mut v947_3 = Space::new();
      let mut v947_3_cursor = (v946_2_tail).read_zipper();
      for v947_3_byte in v947_3_cursor.child_mask().iter() {
        v947_3_cursor.descend_to_byte(v947_3_byte);
        {
        let v947_3_tail = v947_3_cursor.fork_read_zipper();
        let v947_3_head = Path::from_slice(&[v947_3_byte]);
        let v948_2: Path = concat_path(&(v947_2),&(v947_3_head));
        let mut v948_3 = Space::new();
        let mut v948_3_cursor = (v947_3_tail).read_zipper();
        for v948_3_byte in v948_3_cursor.child_mask().iter() {
          v948_3_cursor.descend_to_byte(v948_3_byte);
          {
          let v948_3_tail = v948_3_cursor.fork_read_zipper();
          let v948_3_head = Path::from_slice(&[v948_3_byte]);
          let v949_2: Path = concat_path(&(v948_2),&(v948_3_head));
          let mut v949_3 = Space::new();
          let mut v949_3_cursor = (v948_3_tail).read_zipper();
          for v949_3_byte in v949_3_cursor.child_mask().iter() {
            v949_3_cursor.descend_to_byte(v949_3_byte);
            {
            let v949_3_tail = v949_3_cursor.fork_read_zipper();
            let v949_3_head = Path::from_slice(&[v949_3_byte]);
            let mut v950_2 = Space::new();
            let mut v950_2_cursor = (v949_3_tail).read_zipper();
            for v950_2_byte in v950_2_cursor.child_mask().iter() {
              v950_2_cursor.descend_to_byte(v950_2_byte);
              {
              let v950_2_tail = v950_2_cursor.fork_read_zipper();
              let v950_2_head = Path::from_slice(&[v950_2_byte]);
              let v951_2: Path = concat_path(&(v949_3_head),&(v950_2_head));
              let mut v951_3 = Space::new();
              let mut v951_3_cursor = (v950_2_tail).read_zipper();
              for v951_3_byte in v951_3_cursor.child_mask().iter() {
                v951_3_cursor.descend_to_byte(v951_3_byte);
                {
                let v951_3_tail = v951_3_cursor.fork_read_zipper();
                let v951_3_head = Path::from_slice(&[v951_3_byte]);
                let v952_2: Path = concat_path(&(v951_2),&(v951_3_head));
                let mut v952_3 = Space::new();
                let mut v952_3_cursor = (v951_3_tail).read_zipper();
                for v952_3_byte in v952_3_cursor.child_mask().iter() {
                  v952_3_cursor.descend_to_byte(v952_3_byte);
                  {
                  let v952_3_tail = v952_3_cursor.fork_read_zipper();
                  let v952_3_head = Path::from_slice(&[v952_3_byte]);
                  let v953_2: Path = concat_path(&(v952_2),&(v952_3_head));
                  let v953_3: Space = routine_96(c, &(v953_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v949_2), &(v952_3_tail).make_space());
                  drop(v953_2);
                  v952_3.join_into((v953_3).clone());
                  }
                  v952_3_cursor.ascend(1);
                }
                drop(v952_3_cursor);
                drop(v952_2);
                v951_3.join_into((v952_3).clone());
                }
                v951_3_cursor.ascend(1);
              }
              drop(v951_3_cursor);
              drop(v951_2);
              v950_2.join_into((v951_3).clone());
              }
              v950_2_cursor.ascend(1);
            }
            drop(v950_2_cursor);
            v949_3.join_into((v950_2).clone());
            }
            v949_3_cursor.ascend(1);
          }
          drop(v949_3_cursor);
          drop(v949_2);
          v948_3.join_into((v949_3).clone());
          }
          v948_3_cursor.ascend(1);
        }
        drop(v948_3_cursor);
        drop(v948_2);
        v947_3.join_into((v948_3).clone());
        }
        v947_3_cursor.ascend(1);
      }
      drop(v947_3_cursor);
      drop(v947_2);
      v946_2.join_into((v947_3).clone());
      }
      v946_2_cursor.ascend(1);
    }
    drop(v946_2_cursor);
    v945_8.join_into((v946_2).clone());
    }
    v945_8_cursor.ascend(1);
  }
  drop(v945_8_cursor);
  (v945_8).clone()
}

fn routine_81(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v954_8 = Space::new();
  let mut v954_8_cursor = (*s0).read_zipper();
  for v954_8_byte in v954_8_cursor.child_mask().iter() {
    v954_8_cursor.descend_to_byte(v954_8_byte);
    {
    let v954_8_tail = v954_8_cursor.fork_read_zipper();
    let v954_8_head = Path::from_slice(&[v954_8_byte]);
    let mut v955_2 = Space::new();
    let mut v955_2_cursor = (v954_8_tail).read_zipper();
    for v955_2_byte in v955_2_cursor.child_mask().iter() {
      v955_2_cursor.descend_to_byte(v955_2_byte);
      {
      let v955_2_tail = v955_2_cursor.fork_read_zipper();
      let v955_2_head = Path::from_slice(&[v955_2_byte]);
      let v956_2: Path = concat_path(&(v954_8_head),&(v955_2_head));
      let mut v956_3 = Space::new();
      let mut v956_3_cursor = (v955_2_tail).read_zipper();
      for v956_3_byte in v956_3_cursor.child_mask().iter() {
        v956_3_cursor.descend_to_byte(v956_3_byte);
        {
        let v956_3_tail = v956_3_cursor.fork_read_zipper();
        let v956_3_head = Path::from_slice(&[v956_3_byte]);
        let v957_2: Path = concat_path(&(v956_2),&(v956_3_head));
        let mut v957_3 = Space::new();
        let mut v957_3_cursor = (v956_3_tail).read_zipper();
        for v957_3_byte in v957_3_cursor.child_mask().iter() {
          v957_3_cursor.descend_to_byte(v957_3_byte);
          {
          let v957_3_tail = v957_3_cursor.fork_read_zipper();
          let v957_3_head = Path::from_slice(&[v957_3_byte]);
          let v958_2: Path = concat_path(&(v957_2),&(v957_3_head));
          let mut v958_3 = Space::new();
          let mut v958_3_cursor = (v957_3_tail).read_zipper();
          for v958_3_byte in v958_3_cursor.child_mask().iter() {
            v958_3_cursor.descend_to_byte(v958_3_byte);
            {
            let v958_3_tail = v958_3_cursor.fork_read_zipper();
            let v958_3_head = Path::from_slice(&[v958_3_byte]);
            let mut v959_2 = Space::new();
            let mut v959_2_cursor = (v958_3_tail).read_zipper();
            for v959_2_byte in v959_2_cursor.child_mask().iter() {
              v959_2_cursor.descend_to_byte(v959_2_byte);
              {
              let v959_2_tail = v959_2_cursor.fork_read_zipper();
              let v959_2_head = Path::from_slice(&[v959_2_byte]);
              let v960_2: Path = concat_path(&(v958_3_head),&(v959_2_head));
              let mut v960_3 = Space::new();
              let mut v960_3_cursor = (v959_2_tail).read_zipper();
              for v960_3_byte in v960_3_cursor.child_mask().iter() {
                v960_3_cursor.descend_to_byte(v960_3_byte);
                {
                let v960_3_tail = v960_3_cursor.fork_read_zipper();
                let v960_3_head = Path::from_slice(&[v960_3_byte]);
                let v961_2: Path = concat_path(&(v960_2),&(v960_3_head));
                let mut v961_3 = Space::new();
                let mut v961_3_cursor = (v960_3_tail).read_zipper();
                for v961_3_byte in v961_3_cursor.child_mask().iter() {
                  v961_3_cursor.descend_to_byte(v961_3_byte);
                  {
                  let v961_3_tail = v961_3_cursor.fork_read_zipper();
                  let v961_3_head = Path::from_slice(&[v961_3_byte]);
                  let v962_2: Path = concat_path(&(v961_2),&(v961_3_head));
                  let v962_3: Space = routine_97(c, &(v962_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v958_2), &(v961_3_tail).make_space());
                  drop(v962_2);
                  v961_3.join_into((v962_3).clone());
                  }
                  v961_3_cursor.ascend(1);
                }
                drop(v961_3_cursor);
                drop(v961_2);
                v960_3.join_into((v961_3).clone());
                }
                v960_3_cursor.ascend(1);
              }
              drop(v960_3_cursor);
              drop(v960_2);
              v959_2.join_into((v960_3).clone());
              }
              v959_2_cursor.ascend(1);
            }
            drop(v959_2_cursor);
            v958_3.join_into((v959_2).clone());
            }
            v958_3_cursor.ascend(1);
          }
          drop(v958_3_cursor);
          drop(v958_2);
          v957_3.join_into((v958_3).clone());
          }
          v957_3_cursor.ascend(1);
        }
        drop(v957_3_cursor);
        drop(v957_2);
        v956_3.join_into((v957_3).clone());
        }
        v956_3_cursor.ascend(1);
      }
      drop(v956_3_cursor);
      drop(v956_2);
      v955_2.join_into((v956_3).clone());
      }
      v955_2_cursor.ascend(1);
    }
    drop(v955_2_cursor);
    v954_8.join_into((v955_2).clone());
    }
    v954_8_cursor.ascend(1);
  }
  drop(v954_8_cursor);
  (v954_8).clone()
}

fn routine_82(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v963_8 = Space::new();
  let mut v963_8_cursor = (*s0).read_zipper();
  for v963_8_byte in v963_8_cursor.child_mask().iter() {
    v963_8_cursor.descend_to_byte(v963_8_byte);
    {
    let v963_8_tail = v963_8_cursor.fork_read_zipper();
    let v963_8_head = Path::from_slice(&[v963_8_byte]);
    let mut v964_2 = Space::new();
    let mut v964_2_cursor = (v963_8_tail).read_zipper();
    for v964_2_byte in v964_2_cursor.child_mask().iter() {
      v964_2_cursor.descend_to_byte(v964_2_byte);
      {
      let v964_2_tail = v964_2_cursor.fork_read_zipper();
      let v964_2_head = Path::from_slice(&[v964_2_byte]);
      let v965_2: Path = concat_path(&(v963_8_head),&(v964_2_head));
      let mut v965_3 = Space::new();
      let mut v965_3_cursor = (v964_2_tail).read_zipper();
      for v965_3_byte in v965_3_cursor.child_mask().iter() {
        v965_3_cursor.descend_to_byte(v965_3_byte);
        {
        let v965_3_tail = v965_3_cursor.fork_read_zipper();
        let v965_3_head = Path::from_slice(&[v965_3_byte]);
        let v966_2: Path = concat_path(&(v965_2),&(v965_3_head));
        let mut v966_3 = Space::new();
        let mut v966_3_cursor = (v965_3_tail).read_zipper();
        for v966_3_byte in v966_3_cursor.child_mask().iter() {
          v966_3_cursor.descend_to_byte(v966_3_byte);
          {
          let v966_3_tail = v966_3_cursor.fork_read_zipper();
          let v966_3_head = Path::from_slice(&[v966_3_byte]);
          let v967_2: Path = concat_path(&(v966_2),&(v966_3_head));
          let mut v967_3 = Space::new();
          let mut v967_3_cursor = (v966_3_tail).read_zipper();
          for v967_3_byte in v967_3_cursor.child_mask().iter() {
            v967_3_cursor.descend_to_byte(v967_3_byte);
            {
            let v967_3_tail = v967_3_cursor.fork_read_zipper();
            let v967_3_head = Path::from_slice(&[v967_3_byte]);
            let mut v968_2 = Space::new();
            let mut v968_2_cursor = (v967_3_tail).read_zipper();
            for v968_2_byte in v968_2_cursor.child_mask().iter() {
              v968_2_cursor.descend_to_byte(v968_2_byte);
              {
              let v968_2_tail = v968_2_cursor.fork_read_zipper();
              let v968_2_head = Path::from_slice(&[v968_2_byte]);
              let v969_2: Path = concat_path(&(v967_3_head),&(v968_2_head));
              let mut v969_3 = Space::new();
              let mut v969_3_cursor = (v968_2_tail).read_zipper();
              for v969_3_byte in v969_3_cursor.child_mask().iter() {
                v969_3_cursor.descend_to_byte(v969_3_byte);
                {
                let v969_3_tail = v969_3_cursor.fork_read_zipper();
                let v969_3_head = Path::from_slice(&[v969_3_byte]);
                let v970_2: Path = concat_path(&(v969_2),&(v969_3_head));
                let mut v970_3 = Space::new();
                let mut v970_3_cursor = (v969_3_tail).read_zipper();
                for v970_3_byte in v970_3_cursor.child_mask().iter() {
                  v970_3_cursor.descend_to_byte(v970_3_byte);
                  {
                  let v970_3_tail = v970_3_cursor.fork_read_zipper();
                  let v970_3_head = Path::from_slice(&[v970_3_byte]);
                  let v971_2: Path = concat_path(&(v970_2),&(v970_3_head));
                  let v971_3: Space = routine_98(c, &(v971_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v967_2), &(v970_3_tail).make_space());
                  drop(v971_2);
                  v970_3.join_into((v971_3).clone());
                  }
                  v970_3_cursor.ascend(1);
                }
                drop(v970_3_cursor);
                drop(v970_2);
                v969_3.join_into((v970_3).clone());
                }
                v969_3_cursor.ascend(1);
              }
              drop(v969_3_cursor);
              drop(v969_2);
              v968_2.join_into((v969_3).clone());
              }
              v968_2_cursor.ascend(1);
            }
            drop(v968_2_cursor);
            v967_3.join_into((v968_2).clone());
            }
            v967_3_cursor.ascend(1);
          }
          drop(v967_3_cursor);
          drop(v967_2);
          v966_3.join_into((v967_3).clone());
          }
          v966_3_cursor.ascend(1);
        }
        drop(v966_3_cursor);
        drop(v966_2);
        v965_3.join_into((v966_3).clone());
        }
        v965_3_cursor.ascend(1);
      }
      drop(v965_3_cursor);
      drop(v965_2);
      v964_2.join_into((v965_3).clone());
      }
      v964_2_cursor.ascend(1);
    }
    drop(v964_2_cursor);
    v963_8.join_into((v964_2).clone());
    }
    v963_8_cursor.ascend(1);
  }
  drop(v963_8_cursor);
  (v963_8).clone()
}

fn routine_83(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v972_8 = Space::new();
  let mut v972_8_cursor = (*s0).read_zipper();
  for v972_8_byte in v972_8_cursor.child_mask().iter() {
    v972_8_cursor.descend_to_byte(v972_8_byte);
    {
    let v972_8_tail = v972_8_cursor.fork_read_zipper();
    let v972_8_head = Path::from_slice(&[v972_8_byte]);
    let mut v973_2 = Space::new();
    let mut v973_2_cursor = (v972_8_tail).read_zipper();
    for v973_2_byte in v973_2_cursor.child_mask().iter() {
      v973_2_cursor.descend_to_byte(v973_2_byte);
      {
      let v973_2_tail = v973_2_cursor.fork_read_zipper();
      let v973_2_head = Path::from_slice(&[v973_2_byte]);
      let v974_2: Path = concat_path(&(v972_8_head),&(v973_2_head));
      let mut v974_3 = Space::new();
      let mut v974_3_cursor = (v973_2_tail).read_zipper();
      for v974_3_byte in v974_3_cursor.child_mask().iter() {
        v974_3_cursor.descend_to_byte(v974_3_byte);
        {
        let v974_3_tail = v974_3_cursor.fork_read_zipper();
        let v974_3_head = Path::from_slice(&[v974_3_byte]);
        let v975_2: Path = concat_path(&(v974_2),&(v974_3_head));
        let mut v975_3 = Space::new();
        let mut v975_3_cursor = (v974_3_tail).read_zipper();
        for v975_3_byte in v975_3_cursor.child_mask().iter() {
          v975_3_cursor.descend_to_byte(v975_3_byte);
          {
          let v975_3_tail = v975_3_cursor.fork_read_zipper();
          let v975_3_head = Path::from_slice(&[v975_3_byte]);
          let v976_2: Path = concat_path(&(v975_2),&(v975_3_head));
          let mut v976_3 = Space::new();
          let mut v976_3_cursor = (v975_3_tail).read_zipper();
          for v976_3_byte in v976_3_cursor.child_mask().iter() {
            v976_3_cursor.descend_to_byte(v976_3_byte);
            {
            let v976_3_tail = v976_3_cursor.fork_read_zipper();
            let v976_3_head = Path::from_slice(&[v976_3_byte]);
            let mut v977_2 = Space::new();
            let mut v977_2_cursor = (v976_3_tail).read_zipper();
            for v977_2_byte in v977_2_cursor.child_mask().iter() {
              v977_2_cursor.descend_to_byte(v977_2_byte);
              {
              let v977_2_tail = v977_2_cursor.fork_read_zipper();
              let v977_2_head = Path::from_slice(&[v977_2_byte]);
              let v978_2: Path = concat_path(&(v976_3_head),&(v977_2_head));
              let mut v978_3 = Space::new();
              let mut v978_3_cursor = (v977_2_tail).read_zipper();
              for v978_3_byte in v978_3_cursor.child_mask().iter() {
                v978_3_cursor.descend_to_byte(v978_3_byte);
                {
                let v978_3_tail = v978_3_cursor.fork_read_zipper();
                let v978_3_head = Path::from_slice(&[v978_3_byte]);
                let v979_2: Path = concat_path(&(v978_2),&(v978_3_head));
                let mut v979_3 = Space::new();
                let mut v979_3_cursor = (v978_3_tail).read_zipper();
                for v979_3_byte in v979_3_cursor.child_mask().iter() {
                  v979_3_cursor.descend_to_byte(v979_3_byte);
                  {
                  let v979_3_tail = v979_3_cursor.fork_read_zipper();
                  let v979_3_head = Path::from_slice(&[v979_3_byte]);
                  let v980_2: Path = concat_path(&(v979_2),&(v979_3_head));
                  let v980_3: Space = routine_99(c, &(v980_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v976_2), &(v979_3_tail).make_space());
                  drop(v980_2);
                  v979_3.join_into((v980_3).clone());
                  }
                  v979_3_cursor.ascend(1);
                }
                drop(v979_3_cursor);
                drop(v979_2);
                v978_3.join_into((v979_3).clone());
                }
                v978_3_cursor.ascend(1);
              }
              drop(v978_3_cursor);
              drop(v978_2);
              v977_2.join_into((v978_3).clone());
              }
              v977_2_cursor.ascend(1);
            }
            drop(v977_2_cursor);
            v976_3.join_into((v977_2).clone());
            }
            v976_3_cursor.ascend(1);
          }
          drop(v976_3_cursor);
          drop(v976_2);
          v975_3.join_into((v976_3).clone());
          }
          v975_3_cursor.ascend(1);
        }
        drop(v975_3_cursor);
        drop(v975_2);
        v974_3.join_into((v975_3).clone());
        }
        v974_3_cursor.ascend(1);
      }
      drop(v974_3_cursor);
      drop(v974_2);
      v973_2.join_into((v974_3).clone());
      }
      v973_2_cursor.ascend(1);
    }
    drop(v973_2_cursor);
    v972_8.join_into((v973_2).clone());
    }
    v972_8_cursor.ascend(1);
  }
  drop(v972_8_cursor);
  (v972_8).clone()
}

fn routine_84(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v981_8 = Space::new();
  let mut v981_8_cursor = (*s0).read_zipper();
  for v981_8_byte in v981_8_cursor.child_mask().iter() {
    v981_8_cursor.descend_to_byte(v981_8_byte);
    {
    let v981_8_tail = v981_8_cursor.fork_read_zipper();
    let v981_8_head = Path::from_slice(&[v981_8_byte]);
    let mut v982_2 = Space::new();
    let mut v982_2_cursor = (v981_8_tail).read_zipper();
    for v982_2_byte in v982_2_cursor.child_mask().iter() {
      v982_2_cursor.descend_to_byte(v982_2_byte);
      {
      let v982_2_tail = v982_2_cursor.fork_read_zipper();
      let v982_2_head = Path::from_slice(&[v982_2_byte]);
      let v983_2: Path = concat_path(&(v981_8_head),&(v982_2_head));
      let mut v983_3 = Space::new();
      let mut v983_3_cursor = (v982_2_tail).read_zipper();
      for v983_3_byte in v983_3_cursor.child_mask().iter() {
        v983_3_cursor.descend_to_byte(v983_3_byte);
        {
        let v983_3_tail = v983_3_cursor.fork_read_zipper();
        let v983_3_head = Path::from_slice(&[v983_3_byte]);
        let v984_2: Path = concat_path(&(v983_2),&(v983_3_head));
        let mut v984_3 = Space::new();
        let mut v984_3_cursor = (v983_3_tail).read_zipper();
        for v984_3_byte in v984_3_cursor.child_mask().iter() {
          v984_3_cursor.descend_to_byte(v984_3_byte);
          {
          let v984_3_tail = v984_3_cursor.fork_read_zipper();
          let v984_3_head = Path::from_slice(&[v984_3_byte]);
          let v985_2: Path = concat_path(&(v984_2),&(v984_3_head));
          let mut v985_3 = Space::new();
          let mut v985_3_cursor = (v984_3_tail).read_zipper();
          for v985_3_byte in v985_3_cursor.child_mask().iter() {
            v985_3_cursor.descend_to_byte(v985_3_byte);
            {
            let v985_3_tail = v985_3_cursor.fork_read_zipper();
            let v985_3_head = Path::from_slice(&[v985_3_byte]);
            let mut v986_2 = Space::new();
            let mut v986_2_cursor = (v985_3_tail).read_zipper();
            for v986_2_byte in v986_2_cursor.child_mask().iter() {
              v986_2_cursor.descend_to_byte(v986_2_byte);
              {
              let v986_2_tail = v986_2_cursor.fork_read_zipper();
              let v986_2_head = Path::from_slice(&[v986_2_byte]);
              let v987_2: Path = concat_path(&(v985_3_head),&(v986_2_head));
              let mut v987_3 = Space::new();
              let mut v987_3_cursor = (v986_2_tail).read_zipper();
              for v987_3_byte in v987_3_cursor.child_mask().iter() {
                v987_3_cursor.descend_to_byte(v987_3_byte);
                {
                let v987_3_tail = v987_3_cursor.fork_read_zipper();
                let v987_3_head = Path::from_slice(&[v987_3_byte]);
                let v988_2: Path = concat_path(&(v987_2),&(v987_3_head));
                let mut v988_3 = Space::new();
                let mut v988_3_cursor = (v987_3_tail).read_zipper();
                for v988_3_byte in v988_3_cursor.child_mask().iter() {
                  v988_3_cursor.descend_to_byte(v988_3_byte);
                  {
                  let v988_3_tail = v988_3_cursor.fork_read_zipper();
                  let v988_3_head = Path::from_slice(&[v988_3_byte]);
                  let v989_2: Path = concat_path(&(v988_2),&(v988_3_head));
                  let v989_3: Space = routine_100(c, &(v989_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v985_2), &(v988_3_tail).make_space());
                  drop(v989_2);
                  v988_3.join_into((v989_3).clone());
                  }
                  v988_3_cursor.ascend(1);
                }
                drop(v988_3_cursor);
                drop(v988_2);
                v987_3.join_into((v988_3).clone());
                }
                v987_3_cursor.ascend(1);
              }
              drop(v987_3_cursor);
              drop(v987_2);
              v986_2.join_into((v987_3).clone());
              }
              v986_2_cursor.ascend(1);
            }
            drop(v986_2_cursor);
            v985_3.join_into((v986_2).clone());
            }
            v985_3_cursor.ascend(1);
          }
          drop(v985_3_cursor);
          drop(v985_2);
          v984_3.join_into((v985_3).clone());
          }
          v984_3_cursor.ascend(1);
        }
        drop(v984_3_cursor);
        drop(v984_2);
        v983_3.join_into((v984_3).clone());
        }
        v983_3_cursor.ascend(1);
      }
      drop(v983_3_cursor);
      drop(v983_2);
      v982_2.join_into((v983_3).clone());
      }
      v982_2_cursor.ascend(1);
    }
    drop(v982_2_cursor);
    v981_8.join_into((v982_2).clone());
    }
    v981_8_cursor.ascend(1);
  }
  drop(v981_8_cursor);
  (v981_8).clone()
}

fn routine_85(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v990_8 = Space::new();
  let mut v990_8_cursor = (*s0).read_zipper();
  for v990_8_byte in v990_8_cursor.child_mask().iter() {
    v990_8_cursor.descend_to_byte(v990_8_byte);
    {
    let v990_8_tail = v990_8_cursor.fork_read_zipper();
    let v990_8_head = Path::from_slice(&[v990_8_byte]);
    let mut v991_2 = Space::new();
    let mut v991_2_cursor = (v990_8_tail).read_zipper();
    for v991_2_byte in v991_2_cursor.child_mask().iter() {
      v991_2_cursor.descend_to_byte(v991_2_byte);
      {
      let v991_2_tail = v991_2_cursor.fork_read_zipper();
      let v991_2_head = Path::from_slice(&[v991_2_byte]);
      let v992_2: Path = concat_path(&(v990_8_head),&(v991_2_head));
      let mut v992_3 = Space::new();
      let mut v992_3_cursor = (v991_2_tail).read_zipper();
      for v992_3_byte in v992_3_cursor.child_mask().iter() {
        v992_3_cursor.descend_to_byte(v992_3_byte);
        {
        let v992_3_tail = v992_3_cursor.fork_read_zipper();
        let v992_3_head = Path::from_slice(&[v992_3_byte]);
        let v993_2: Path = concat_path(&(v992_2),&(v992_3_head));
        let mut v993_3 = Space::new();
        let mut v993_3_cursor = (v992_3_tail).read_zipper();
        for v993_3_byte in v993_3_cursor.child_mask().iter() {
          v993_3_cursor.descend_to_byte(v993_3_byte);
          {
          let v993_3_tail = v993_3_cursor.fork_read_zipper();
          let v993_3_head = Path::from_slice(&[v993_3_byte]);
          let v994_2: Path = concat_path(&(v993_2),&(v993_3_head));
          let mut v994_3 = Space::new();
          let mut v994_3_cursor = (v993_3_tail).read_zipper();
          for v994_3_byte in v994_3_cursor.child_mask().iter() {
            v994_3_cursor.descend_to_byte(v994_3_byte);
            {
            let v994_3_tail = v994_3_cursor.fork_read_zipper();
            let v994_3_head = Path::from_slice(&[v994_3_byte]);
            let mut v995_2 = Space::new();
            let mut v995_2_cursor = (v994_3_tail).read_zipper();
            for v995_2_byte in v995_2_cursor.child_mask().iter() {
              v995_2_cursor.descend_to_byte(v995_2_byte);
              {
              let v995_2_tail = v995_2_cursor.fork_read_zipper();
              let v995_2_head = Path::from_slice(&[v995_2_byte]);
              let v996_2: Path = concat_path(&(v994_3_head),&(v995_2_head));
              let mut v996_3 = Space::new();
              let mut v996_3_cursor = (v995_2_tail).read_zipper();
              for v996_3_byte in v996_3_cursor.child_mask().iter() {
                v996_3_cursor.descend_to_byte(v996_3_byte);
                {
                let v996_3_tail = v996_3_cursor.fork_read_zipper();
                let v996_3_head = Path::from_slice(&[v996_3_byte]);
                let v997_2: Path = concat_path(&(v996_2),&(v996_3_head));
                let mut v997_3 = Space::new();
                let mut v997_3_cursor = (v996_3_tail).read_zipper();
                for v997_3_byte in v997_3_cursor.child_mask().iter() {
                  v997_3_cursor.descend_to_byte(v997_3_byte);
                  {
                  let v997_3_tail = v997_3_cursor.fork_read_zipper();
                  let v997_3_head = Path::from_slice(&[v997_3_byte]);
                  let v998_2: Path = concat_path(&(v997_2),&(v997_3_head));
                  let v998_3: Space = routine_101(c, &(v998_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v994_2), &(v997_3_tail).make_space());
                  drop(v998_2);
                  v997_3.join_into((v998_3).clone());
                  }
                  v997_3_cursor.ascend(1);
                }
                drop(v997_3_cursor);
                drop(v997_2);
                v996_3.join_into((v997_3).clone());
                }
                v996_3_cursor.ascend(1);
              }
              drop(v996_3_cursor);
              drop(v996_2);
              v995_2.join_into((v996_3).clone());
              }
              v995_2_cursor.ascend(1);
            }
            drop(v995_2_cursor);
            v994_3.join_into((v995_2).clone());
            }
            v994_3_cursor.ascend(1);
          }
          drop(v994_3_cursor);
          drop(v994_2);
          v993_3.join_into((v994_3).clone());
          }
          v993_3_cursor.ascend(1);
        }
        drop(v993_3_cursor);
        drop(v993_2);
        v992_3.join_into((v993_3).clone());
        }
        v992_3_cursor.ascend(1);
      }
      drop(v992_3_cursor);
      drop(v992_2);
      v991_2.join_into((v992_3).clone());
      }
      v991_2_cursor.ascend(1);
    }
    drop(v991_2_cursor);
    v990_8.join_into((v991_2).clone());
    }
    v990_8_cursor.ascend(1);
  }
  drop(v990_8_cursor);
  (v990_8).clone()
}

fn routine_86(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v999_8 = Space::new();
  let mut v999_8_cursor = (*s0).read_zipper();
  for v999_8_byte in v999_8_cursor.child_mask().iter() {
    v999_8_cursor.descend_to_byte(v999_8_byte);
    {
    let v999_8_tail = v999_8_cursor.fork_read_zipper();
    let v999_8_head = Path::from_slice(&[v999_8_byte]);
    let mut v1000_2 = Space::new();
    let mut v1000_2_cursor = (v999_8_tail).read_zipper();
    for v1000_2_byte in v1000_2_cursor.child_mask().iter() {
      v1000_2_cursor.descend_to_byte(v1000_2_byte);
      {
      let v1000_2_tail = v1000_2_cursor.fork_read_zipper();
      let v1000_2_head = Path::from_slice(&[v1000_2_byte]);
      let v1001_2: Path = concat_path(&(v999_8_head),&(v1000_2_head));
      let mut v1001_3 = Space::new();
      let mut v1001_3_cursor = (v1000_2_tail).read_zipper();
      for v1001_3_byte in v1001_3_cursor.child_mask().iter() {
        v1001_3_cursor.descend_to_byte(v1001_3_byte);
        {
        let v1001_3_tail = v1001_3_cursor.fork_read_zipper();
        let v1001_3_head = Path::from_slice(&[v1001_3_byte]);
        let v1002_2: Path = concat_path(&(v1001_2),&(v1001_3_head));
        let mut v1002_3 = Space::new();
        let mut v1002_3_cursor = (v1001_3_tail).read_zipper();
        for v1002_3_byte in v1002_3_cursor.child_mask().iter() {
          v1002_3_cursor.descend_to_byte(v1002_3_byte);
          {
          let v1002_3_tail = v1002_3_cursor.fork_read_zipper();
          let v1002_3_head = Path::from_slice(&[v1002_3_byte]);
          let v1003_2: Path = concat_path(&(v1002_2),&(v1002_3_head));
          let mut v1003_3 = Space::new();
          let mut v1003_3_cursor = (v1002_3_tail).read_zipper();
          for v1003_3_byte in v1003_3_cursor.child_mask().iter() {
            v1003_3_cursor.descend_to_byte(v1003_3_byte);
            {
            let v1003_3_tail = v1003_3_cursor.fork_read_zipper();
            let v1003_3_head = Path::from_slice(&[v1003_3_byte]);
            let mut v1004_2 = Space::new();
            let mut v1004_2_cursor = (v1003_3_tail).read_zipper();
            for v1004_2_byte in v1004_2_cursor.child_mask().iter() {
              v1004_2_cursor.descend_to_byte(v1004_2_byte);
              {
              let v1004_2_tail = v1004_2_cursor.fork_read_zipper();
              let v1004_2_head = Path::from_slice(&[v1004_2_byte]);
              let v1005_2: Path = concat_path(&(v1003_3_head),&(v1004_2_head));
              let mut v1005_3 = Space::new();
              let mut v1005_3_cursor = (v1004_2_tail).read_zipper();
              for v1005_3_byte in v1005_3_cursor.child_mask().iter() {
                v1005_3_cursor.descend_to_byte(v1005_3_byte);
                {
                let v1005_3_tail = v1005_3_cursor.fork_read_zipper();
                let v1005_3_head = Path::from_slice(&[v1005_3_byte]);
                let v1006_2: Path = concat_path(&(v1005_2),&(v1005_3_head));
                let mut v1006_3 = Space::new();
                let mut v1006_3_cursor = (v1005_3_tail).read_zipper();
                for v1006_3_byte in v1006_3_cursor.child_mask().iter() {
                  v1006_3_cursor.descend_to_byte(v1006_3_byte);
                  {
                  let v1006_3_tail = v1006_3_cursor.fork_read_zipper();
                  let v1006_3_head = Path::from_slice(&[v1006_3_byte]);
                  let v1007_2: Path = concat_path(&(v1006_2),&(v1006_3_head));
                  let v1007_3: Space = routine_102(c, &(v1007_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1003_2), &(v1006_3_tail).make_space());
                  drop(v1007_2);
                  v1006_3.join_into((v1007_3).clone());
                  }
                  v1006_3_cursor.ascend(1);
                }
                drop(v1006_3_cursor);
                drop(v1006_2);
                v1005_3.join_into((v1006_3).clone());
                }
                v1005_3_cursor.ascend(1);
              }
              drop(v1005_3_cursor);
              drop(v1005_2);
              v1004_2.join_into((v1005_3).clone());
              }
              v1004_2_cursor.ascend(1);
            }
            drop(v1004_2_cursor);
            v1003_3.join_into((v1004_2).clone());
            }
            v1003_3_cursor.ascend(1);
          }
          drop(v1003_3_cursor);
          drop(v1003_2);
          v1002_3.join_into((v1003_3).clone());
          }
          v1002_3_cursor.ascend(1);
        }
        drop(v1002_3_cursor);
        drop(v1002_2);
        v1001_3.join_into((v1002_3).clone());
        }
        v1001_3_cursor.ascend(1);
      }
      drop(v1001_3_cursor);
      drop(v1001_2);
      v1000_2.join_into((v1001_3).clone());
      }
      v1000_2_cursor.ascend(1);
    }
    drop(v1000_2_cursor);
    v999_8.join_into((v1000_2).clone());
    }
    v999_8_cursor.ascend(1);
  }
  drop(v999_8_cursor);
  (v999_8).clone()
}

fn routine_87(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1008_8 = Space::new();
  let mut v1008_8_cursor = (*s0).read_zipper();
  for v1008_8_byte in v1008_8_cursor.child_mask().iter() {
    v1008_8_cursor.descend_to_byte(v1008_8_byte);
    {
    let v1008_8_tail = v1008_8_cursor.fork_read_zipper();
    let v1008_8_head = Path::from_slice(&[v1008_8_byte]);
    let mut v1009_2 = Space::new();
    let mut v1009_2_cursor = (v1008_8_tail).read_zipper();
    for v1009_2_byte in v1009_2_cursor.child_mask().iter() {
      v1009_2_cursor.descend_to_byte(v1009_2_byte);
      {
      let v1009_2_tail = v1009_2_cursor.fork_read_zipper();
      let v1009_2_head = Path::from_slice(&[v1009_2_byte]);
      let v1010_2: Path = concat_path(&(v1008_8_head),&(v1009_2_head));
      let mut v1010_3 = Space::new();
      let mut v1010_3_cursor = (v1009_2_tail).read_zipper();
      for v1010_3_byte in v1010_3_cursor.child_mask().iter() {
        v1010_3_cursor.descend_to_byte(v1010_3_byte);
        {
        let v1010_3_tail = v1010_3_cursor.fork_read_zipper();
        let v1010_3_head = Path::from_slice(&[v1010_3_byte]);
        let v1011_2: Path = concat_path(&(v1010_2),&(v1010_3_head));
        let mut v1011_3 = Space::new();
        let mut v1011_3_cursor = (v1010_3_tail).read_zipper();
        for v1011_3_byte in v1011_3_cursor.child_mask().iter() {
          v1011_3_cursor.descend_to_byte(v1011_3_byte);
          {
          let v1011_3_tail = v1011_3_cursor.fork_read_zipper();
          let v1011_3_head = Path::from_slice(&[v1011_3_byte]);
          let v1012_2: Path = concat_path(&(v1011_2),&(v1011_3_head));
          let mut v1012_3 = Space::new();
          let mut v1012_3_cursor = (v1011_3_tail).read_zipper();
          for v1012_3_byte in v1012_3_cursor.child_mask().iter() {
            v1012_3_cursor.descend_to_byte(v1012_3_byte);
            {
            let v1012_3_tail = v1012_3_cursor.fork_read_zipper();
            let v1012_3_head = Path::from_slice(&[v1012_3_byte]);
            let mut v1013_2 = Space::new();
            let mut v1013_2_cursor = (v1012_3_tail).read_zipper();
            for v1013_2_byte in v1013_2_cursor.child_mask().iter() {
              v1013_2_cursor.descend_to_byte(v1013_2_byte);
              {
              let v1013_2_tail = v1013_2_cursor.fork_read_zipper();
              let v1013_2_head = Path::from_slice(&[v1013_2_byte]);
              let v1014_2: Path = concat_path(&(v1012_3_head),&(v1013_2_head));
              let mut v1014_3 = Space::new();
              let mut v1014_3_cursor = (v1013_2_tail).read_zipper();
              for v1014_3_byte in v1014_3_cursor.child_mask().iter() {
                v1014_3_cursor.descend_to_byte(v1014_3_byte);
                {
                let v1014_3_tail = v1014_3_cursor.fork_read_zipper();
                let v1014_3_head = Path::from_slice(&[v1014_3_byte]);
                let v1015_2: Path = concat_path(&(v1014_2),&(v1014_3_head));
                let mut v1015_3 = Space::new();
                let mut v1015_3_cursor = (v1014_3_tail).read_zipper();
                for v1015_3_byte in v1015_3_cursor.child_mask().iter() {
                  v1015_3_cursor.descend_to_byte(v1015_3_byte);
                  {
                  let v1015_3_tail = v1015_3_cursor.fork_read_zipper();
                  let v1015_3_head = Path::from_slice(&[v1015_3_byte]);
                  let v1016_2: Path = concat_path(&(v1015_2),&(v1015_3_head));
                  let v1016_3: Space = routine_103(c, &(v1016_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1012_2), &(v1015_3_tail).make_space());
                  drop(v1016_2);
                  v1015_3.join_into((v1016_3).clone());
                  }
                  v1015_3_cursor.ascend(1);
                }
                drop(v1015_3_cursor);
                drop(v1015_2);
                v1014_3.join_into((v1015_3).clone());
                }
                v1014_3_cursor.ascend(1);
              }
              drop(v1014_3_cursor);
              drop(v1014_2);
              v1013_2.join_into((v1014_3).clone());
              }
              v1013_2_cursor.ascend(1);
            }
            drop(v1013_2_cursor);
            v1012_3.join_into((v1013_2).clone());
            }
            v1012_3_cursor.ascend(1);
          }
          drop(v1012_3_cursor);
          drop(v1012_2);
          v1011_3.join_into((v1012_3).clone());
          }
          v1011_3_cursor.ascend(1);
        }
        drop(v1011_3_cursor);
        drop(v1011_2);
        v1010_3.join_into((v1011_3).clone());
        }
        v1010_3_cursor.ascend(1);
      }
      drop(v1010_3_cursor);
      drop(v1010_2);
      v1009_2.join_into((v1010_3).clone());
      }
      v1009_2_cursor.ascend(1);
    }
    drop(v1009_2_cursor);
    v1008_8.join_into((v1009_2).clone());
    }
    v1008_8_cursor.ascend(1);
  }
  drop(v1008_8_cursor);
  (v1008_8).clone()
}

fn routine_88(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1017_8 = Space::new();
  let mut v1017_8_cursor = (*s0).read_zipper();
  for v1017_8_byte in v1017_8_cursor.child_mask().iter() {
    v1017_8_cursor.descend_to_byte(v1017_8_byte);
    {
    let v1017_8_tail = v1017_8_cursor.fork_read_zipper();
    let v1017_8_head = Path::from_slice(&[v1017_8_byte]);
    let mut v1018_2 = Space::new();
    let mut v1018_2_cursor = (v1017_8_tail).read_zipper();
    for v1018_2_byte in v1018_2_cursor.child_mask().iter() {
      v1018_2_cursor.descend_to_byte(v1018_2_byte);
      {
      let v1018_2_tail = v1018_2_cursor.fork_read_zipper();
      let v1018_2_head = Path::from_slice(&[v1018_2_byte]);
      let v1019_2: Path = concat_path(&(v1017_8_head),&(v1018_2_head));
      let mut v1019_3 = Space::new();
      let mut v1019_3_cursor = (v1018_2_tail).read_zipper();
      for v1019_3_byte in v1019_3_cursor.child_mask().iter() {
        v1019_3_cursor.descend_to_byte(v1019_3_byte);
        {
        let v1019_3_tail = v1019_3_cursor.fork_read_zipper();
        let v1019_3_head = Path::from_slice(&[v1019_3_byte]);
        let v1020_2: Path = concat_path(&(v1019_2),&(v1019_3_head));
        let mut v1020_3 = Space::new();
        let mut v1020_3_cursor = (v1019_3_tail).read_zipper();
        for v1020_3_byte in v1020_3_cursor.child_mask().iter() {
          v1020_3_cursor.descend_to_byte(v1020_3_byte);
          {
          let v1020_3_tail = v1020_3_cursor.fork_read_zipper();
          let v1020_3_head = Path::from_slice(&[v1020_3_byte]);
          let v1021_2: Path = concat_path(&(v1020_2),&(v1020_3_head));
          let mut v1021_3 = Space::new();
          let mut v1021_3_cursor = (v1020_3_tail).read_zipper();
          for v1021_3_byte in v1021_3_cursor.child_mask().iter() {
            v1021_3_cursor.descend_to_byte(v1021_3_byte);
            {
            let v1021_3_tail = v1021_3_cursor.fork_read_zipper();
            let v1021_3_head = Path::from_slice(&[v1021_3_byte]);
            let mut v1022_2 = Space::new();
            let mut v1022_2_cursor = (v1021_3_tail).read_zipper();
            for v1022_2_byte in v1022_2_cursor.child_mask().iter() {
              v1022_2_cursor.descend_to_byte(v1022_2_byte);
              {
              let v1022_2_tail = v1022_2_cursor.fork_read_zipper();
              let v1022_2_head = Path::from_slice(&[v1022_2_byte]);
              let v1023_2: Path = concat_path(&(v1021_3_head),&(v1022_2_head));
              let mut v1023_3 = Space::new();
              let mut v1023_3_cursor = (v1022_2_tail).read_zipper();
              for v1023_3_byte in v1023_3_cursor.child_mask().iter() {
                v1023_3_cursor.descend_to_byte(v1023_3_byte);
                {
                let v1023_3_tail = v1023_3_cursor.fork_read_zipper();
                let v1023_3_head = Path::from_slice(&[v1023_3_byte]);
                let v1024_2: Path = concat_path(&(v1023_2),&(v1023_3_head));
                let mut v1024_3 = Space::new();
                let mut v1024_3_cursor = (v1023_3_tail).read_zipper();
                for v1024_3_byte in v1024_3_cursor.child_mask().iter() {
                  v1024_3_cursor.descend_to_byte(v1024_3_byte);
                  {
                  let v1024_3_tail = v1024_3_cursor.fork_read_zipper();
                  let v1024_3_head = Path::from_slice(&[v1024_3_byte]);
                  let v1025_2: Path = concat_path(&(v1024_2),&(v1024_3_head));
                  let v1025_3: Space = routine_104(c, &(v1025_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1021_2), &(v1024_3_tail).make_space());
                  drop(v1025_2);
                  v1024_3.join_into((v1025_3).clone());
                  }
                  v1024_3_cursor.ascend(1);
                }
                drop(v1024_3_cursor);
                drop(v1024_2);
                v1023_3.join_into((v1024_3).clone());
                }
                v1023_3_cursor.ascend(1);
              }
              drop(v1023_3_cursor);
              drop(v1023_2);
              v1022_2.join_into((v1023_3).clone());
              }
              v1022_2_cursor.ascend(1);
            }
            drop(v1022_2_cursor);
            v1021_3.join_into((v1022_2).clone());
            }
            v1021_3_cursor.ascend(1);
          }
          drop(v1021_3_cursor);
          drop(v1021_2);
          v1020_3.join_into((v1021_3).clone());
          }
          v1020_3_cursor.ascend(1);
        }
        drop(v1020_3_cursor);
        drop(v1020_2);
        v1019_3.join_into((v1020_3).clone());
        }
        v1019_3_cursor.ascend(1);
      }
      drop(v1019_3_cursor);
      drop(v1019_2);
      v1018_2.join_into((v1019_3).clone());
      }
      v1018_2_cursor.ascend(1);
    }
    drop(v1018_2_cursor);
    v1017_8.join_into((v1018_2).clone());
    }
    v1017_8_cursor.ascend(1);
  }
  drop(v1017_8_cursor);
  (v1017_8).clone()
}

fn routine_89(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1026_8 = Space::new();
  let mut v1026_8_cursor = (*s0).read_zipper();
  for v1026_8_byte in v1026_8_cursor.child_mask().iter() {
    v1026_8_cursor.descend_to_byte(v1026_8_byte);
    {
    let v1026_8_tail = v1026_8_cursor.fork_read_zipper();
    let v1026_8_head = Path::from_slice(&[v1026_8_byte]);
    let mut v1027_2 = Space::new();
    let mut v1027_2_cursor = (v1026_8_tail).read_zipper();
    for v1027_2_byte in v1027_2_cursor.child_mask().iter() {
      v1027_2_cursor.descend_to_byte(v1027_2_byte);
      {
      let v1027_2_tail = v1027_2_cursor.fork_read_zipper();
      let v1027_2_head = Path::from_slice(&[v1027_2_byte]);
      let v1028_2: Path = concat_path(&(v1026_8_head),&(v1027_2_head));
      let mut v1028_3 = Space::new();
      let mut v1028_3_cursor = (v1027_2_tail).read_zipper();
      for v1028_3_byte in v1028_3_cursor.child_mask().iter() {
        v1028_3_cursor.descend_to_byte(v1028_3_byte);
        {
        let v1028_3_tail = v1028_3_cursor.fork_read_zipper();
        let v1028_3_head = Path::from_slice(&[v1028_3_byte]);
        let v1029_2: Path = concat_path(&(v1028_2),&(v1028_3_head));
        let mut v1029_3 = Space::new();
        let mut v1029_3_cursor = (v1028_3_tail).read_zipper();
        for v1029_3_byte in v1029_3_cursor.child_mask().iter() {
          v1029_3_cursor.descend_to_byte(v1029_3_byte);
          {
          let v1029_3_tail = v1029_3_cursor.fork_read_zipper();
          let v1029_3_head = Path::from_slice(&[v1029_3_byte]);
          let v1030_2: Path = concat_path(&(v1029_2),&(v1029_3_head));
          let mut v1030_3 = Space::new();
          let mut v1030_3_cursor = (v1029_3_tail).read_zipper();
          for v1030_3_byte in v1030_3_cursor.child_mask().iter() {
            v1030_3_cursor.descend_to_byte(v1030_3_byte);
            {
            let v1030_3_tail = v1030_3_cursor.fork_read_zipper();
            let v1030_3_head = Path::from_slice(&[v1030_3_byte]);
            let mut v1031_2 = Space::new();
            let mut v1031_2_cursor = (v1030_3_tail).read_zipper();
            for v1031_2_byte in v1031_2_cursor.child_mask().iter() {
              v1031_2_cursor.descend_to_byte(v1031_2_byte);
              {
              let v1031_2_tail = v1031_2_cursor.fork_read_zipper();
              let v1031_2_head = Path::from_slice(&[v1031_2_byte]);
              let v1032_2: Path = concat_path(&(v1030_3_head),&(v1031_2_head));
              let mut v1032_3 = Space::new();
              let mut v1032_3_cursor = (v1031_2_tail).read_zipper();
              for v1032_3_byte in v1032_3_cursor.child_mask().iter() {
                v1032_3_cursor.descend_to_byte(v1032_3_byte);
                {
                let v1032_3_tail = v1032_3_cursor.fork_read_zipper();
                let v1032_3_head = Path::from_slice(&[v1032_3_byte]);
                let v1033_2: Path = concat_path(&(v1032_2),&(v1032_3_head));
                let mut v1033_3 = Space::new();
                let mut v1033_3_cursor = (v1032_3_tail).read_zipper();
                for v1033_3_byte in v1033_3_cursor.child_mask().iter() {
                  v1033_3_cursor.descend_to_byte(v1033_3_byte);
                  {
                  let v1033_3_tail = v1033_3_cursor.fork_read_zipper();
                  let v1033_3_head = Path::from_slice(&[v1033_3_byte]);
                  let v1034_2: Path = concat_path(&(v1033_2),&(v1033_3_head));
                  let v1034_3: Space = routine_105(c, &(v1034_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1030_2), &(v1033_3_tail).make_space());
                  drop(v1034_2);
                  v1033_3.join_into((v1034_3).clone());
                  }
                  v1033_3_cursor.ascend(1);
                }
                drop(v1033_3_cursor);
                drop(v1033_2);
                v1032_3.join_into((v1033_3).clone());
                }
                v1032_3_cursor.ascend(1);
              }
              drop(v1032_3_cursor);
              drop(v1032_2);
              v1031_2.join_into((v1032_3).clone());
              }
              v1031_2_cursor.ascend(1);
            }
            drop(v1031_2_cursor);
            v1030_3.join_into((v1031_2).clone());
            }
            v1030_3_cursor.ascend(1);
          }
          drop(v1030_3_cursor);
          drop(v1030_2);
          v1029_3.join_into((v1030_3).clone());
          }
          v1029_3_cursor.ascend(1);
        }
        drop(v1029_3_cursor);
        drop(v1029_2);
        v1028_3.join_into((v1029_3).clone());
        }
        v1028_3_cursor.ascend(1);
      }
      drop(v1028_3_cursor);
      drop(v1028_2);
      v1027_2.join_into((v1028_3).clone());
      }
      v1027_2_cursor.ascend(1);
    }
    drop(v1027_2_cursor);
    v1026_8.join_into((v1027_2).clone());
    }
    v1026_8_cursor.ascend(1);
  }
  drop(v1026_8_cursor);
  (v1026_8).clone()
}

fn routine_90(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1035_8 = Space::new();
  let mut v1035_8_cursor = (*s0).read_zipper();
  for v1035_8_byte in v1035_8_cursor.child_mask().iter() {
    v1035_8_cursor.descend_to_byte(v1035_8_byte);
    {
    let v1035_8_tail = v1035_8_cursor.fork_read_zipper();
    let v1035_8_head = Path::from_slice(&[v1035_8_byte]);
    let mut v1036_2 = Space::new();
    let mut v1036_2_cursor = (v1035_8_tail).read_zipper();
    for v1036_2_byte in v1036_2_cursor.child_mask().iter() {
      v1036_2_cursor.descend_to_byte(v1036_2_byte);
      {
      let v1036_2_tail = v1036_2_cursor.fork_read_zipper();
      let v1036_2_head = Path::from_slice(&[v1036_2_byte]);
      let v1037_2: Path = concat_path(&(v1035_8_head),&(v1036_2_head));
      let mut v1037_3 = Space::new();
      let mut v1037_3_cursor = (v1036_2_tail).read_zipper();
      for v1037_3_byte in v1037_3_cursor.child_mask().iter() {
        v1037_3_cursor.descend_to_byte(v1037_3_byte);
        {
        let v1037_3_tail = v1037_3_cursor.fork_read_zipper();
        let v1037_3_head = Path::from_slice(&[v1037_3_byte]);
        let v1038_2: Path = concat_path(&(v1037_2),&(v1037_3_head));
        let mut v1038_3 = Space::new();
        let mut v1038_3_cursor = (v1037_3_tail).read_zipper();
        for v1038_3_byte in v1038_3_cursor.child_mask().iter() {
          v1038_3_cursor.descend_to_byte(v1038_3_byte);
          {
          let v1038_3_tail = v1038_3_cursor.fork_read_zipper();
          let v1038_3_head = Path::from_slice(&[v1038_3_byte]);
          let v1039_2: Path = concat_path(&(v1038_2),&(v1038_3_head));
          let mut v1039_3 = Space::new();
          let mut v1039_3_cursor = (v1038_3_tail).read_zipper();
          for v1039_3_byte in v1039_3_cursor.child_mask().iter() {
            v1039_3_cursor.descend_to_byte(v1039_3_byte);
            {
            let v1039_3_tail = v1039_3_cursor.fork_read_zipper();
            let v1039_3_head = Path::from_slice(&[v1039_3_byte]);
            let mut v1040_2 = Space::new();
            let mut v1040_2_cursor = (v1039_3_tail).read_zipper();
            for v1040_2_byte in v1040_2_cursor.child_mask().iter() {
              v1040_2_cursor.descend_to_byte(v1040_2_byte);
              {
              let v1040_2_tail = v1040_2_cursor.fork_read_zipper();
              let v1040_2_head = Path::from_slice(&[v1040_2_byte]);
              let v1041_2: Path = concat_path(&(v1039_3_head),&(v1040_2_head));
              let mut v1041_3 = Space::new();
              let mut v1041_3_cursor = (v1040_2_tail).read_zipper();
              for v1041_3_byte in v1041_3_cursor.child_mask().iter() {
                v1041_3_cursor.descend_to_byte(v1041_3_byte);
                {
                let v1041_3_tail = v1041_3_cursor.fork_read_zipper();
                let v1041_3_head = Path::from_slice(&[v1041_3_byte]);
                let v1042_2: Path = concat_path(&(v1041_2),&(v1041_3_head));
                let mut v1042_3 = Space::new();
                let mut v1042_3_cursor = (v1041_3_tail).read_zipper();
                for v1042_3_byte in v1042_3_cursor.child_mask().iter() {
                  v1042_3_cursor.descend_to_byte(v1042_3_byte);
                  {
                  let v1042_3_tail = v1042_3_cursor.fork_read_zipper();
                  let v1042_3_head = Path::from_slice(&[v1042_3_byte]);
                  let v1043_2: Path = concat_path(&(v1042_2),&(v1042_3_head));
                  let v1043_3: Space = routine_106(c, &(v1043_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1039_2), &(v1042_3_tail).make_space());
                  drop(v1043_2);
                  v1042_3.join_into((v1043_3).clone());
                  }
                  v1042_3_cursor.ascend(1);
                }
                drop(v1042_3_cursor);
                drop(v1042_2);
                v1041_3.join_into((v1042_3).clone());
                }
                v1041_3_cursor.ascend(1);
              }
              drop(v1041_3_cursor);
              drop(v1041_2);
              v1040_2.join_into((v1041_3).clone());
              }
              v1040_2_cursor.ascend(1);
            }
            drop(v1040_2_cursor);
            v1039_3.join_into((v1040_2).clone());
            }
            v1039_3_cursor.ascend(1);
          }
          drop(v1039_3_cursor);
          drop(v1039_2);
          v1038_3.join_into((v1039_3).clone());
          }
          v1038_3_cursor.ascend(1);
        }
        drop(v1038_3_cursor);
        drop(v1038_2);
        v1037_3.join_into((v1038_3).clone());
        }
        v1037_3_cursor.ascend(1);
      }
      drop(v1037_3_cursor);
      drop(v1037_2);
      v1036_2.join_into((v1037_3).clone());
      }
      v1036_2_cursor.ascend(1);
    }
    drop(v1036_2_cursor);
    v1035_8.join_into((v1036_2).clone());
    }
    v1035_8_cursor.ascend(1);
  }
  drop(v1035_8_cursor);
  (v1035_8).clone()
}

fn routine_91(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1044_8 = Space::new();
  let mut v1044_8_cursor = (*s0).read_zipper();
  for v1044_8_byte in v1044_8_cursor.child_mask().iter() {
    v1044_8_cursor.descend_to_byte(v1044_8_byte);
    {
    let v1044_8_tail = v1044_8_cursor.fork_read_zipper();
    let v1044_8_head = Path::from_slice(&[v1044_8_byte]);
    let mut v1045_2 = Space::new();
    let mut v1045_2_cursor = (v1044_8_tail).read_zipper();
    for v1045_2_byte in v1045_2_cursor.child_mask().iter() {
      v1045_2_cursor.descend_to_byte(v1045_2_byte);
      {
      let v1045_2_tail = v1045_2_cursor.fork_read_zipper();
      let v1045_2_head = Path::from_slice(&[v1045_2_byte]);
      let v1046_2: Path = concat_path(&(v1044_8_head),&(v1045_2_head));
      let mut v1046_3 = Space::new();
      let mut v1046_3_cursor = (v1045_2_tail).read_zipper();
      for v1046_3_byte in v1046_3_cursor.child_mask().iter() {
        v1046_3_cursor.descend_to_byte(v1046_3_byte);
        {
        let v1046_3_tail = v1046_3_cursor.fork_read_zipper();
        let v1046_3_head = Path::from_slice(&[v1046_3_byte]);
        let v1047_2: Path = concat_path(&(v1046_2),&(v1046_3_head));
        let mut v1047_3 = Space::new();
        let mut v1047_3_cursor = (v1046_3_tail).read_zipper();
        for v1047_3_byte in v1047_3_cursor.child_mask().iter() {
          v1047_3_cursor.descend_to_byte(v1047_3_byte);
          {
          let v1047_3_tail = v1047_3_cursor.fork_read_zipper();
          let v1047_3_head = Path::from_slice(&[v1047_3_byte]);
          let v1048_2: Path = concat_path(&(v1047_2),&(v1047_3_head));
          let mut v1048_3 = Space::new();
          let mut v1048_3_cursor = (v1047_3_tail).read_zipper();
          for v1048_3_byte in v1048_3_cursor.child_mask().iter() {
            v1048_3_cursor.descend_to_byte(v1048_3_byte);
            {
            let v1048_3_tail = v1048_3_cursor.fork_read_zipper();
            let v1048_3_head = Path::from_slice(&[v1048_3_byte]);
            let mut v1049_2 = Space::new();
            let mut v1049_2_cursor = (v1048_3_tail).read_zipper();
            for v1049_2_byte in v1049_2_cursor.child_mask().iter() {
              v1049_2_cursor.descend_to_byte(v1049_2_byte);
              {
              let v1049_2_tail = v1049_2_cursor.fork_read_zipper();
              let v1049_2_head = Path::from_slice(&[v1049_2_byte]);
              let v1050_2: Path = concat_path(&(v1048_3_head),&(v1049_2_head));
              let mut v1050_3 = Space::new();
              let mut v1050_3_cursor = (v1049_2_tail).read_zipper();
              for v1050_3_byte in v1050_3_cursor.child_mask().iter() {
                v1050_3_cursor.descend_to_byte(v1050_3_byte);
                {
                let v1050_3_tail = v1050_3_cursor.fork_read_zipper();
                let v1050_3_head = Path::from_slice(&[v1050_3_byte]);
                let v1051_2: Path = concat_path(&(v1050_2),&(v1050_3_head));
                let mut v1051_3 = Space::new();
                let mut v1051_3_cursor = (v1050_3_tail).read_zipper();
                for v1051_3_byte in v1051_3_cursor.child_mask().iter() {
                  v1051_3_cursor.descend_to_byte(v1051_3_byte);
                  {
                  let v1051_3_tail = v1051_3_cursor.fork_read_zipper();
                  let v1051_3_head = Path::from_slice(&[v1051_3_byte]);
                  let v1052_2: Path = concat_path(&(v1051_2),&(v1051_3_head));
                  let v1052_3: Space = routine_107(c, &(v1052_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1048_2), &(v1051_3_tail).make_space());
                  drop(v1052_2);
                  v1051_3.join_into((v1052_3).clone());
                  }
                  v1051_3_cursor.ascend(1);
                }
                drop(v1051_3_cursor);
                drop(v1051_2);
                v1050_3.join_into((v1051_3).clone());
                }
                v1050_3_cursor.ascend(1);
              }
              drop(v1050_3_cursor);
              drop(v1050_2);
              v1049_2.join_into((v1050_3).clone());
              }
              v1049_2_cursor.ascend(1);
            }
            drop(v1049_2_cursor);
            v1048_3.join_into((v1049_2).clone());
            }
            v1048_3_cursor.ascend(1);
          }
          drop(v1048_3_cursor);
          drop(v1048_2);
          v1047_3.join_into((v1048_3).clone());
          }
          v1047_3_cursor.ascend(1);
        }
        drop(v1047_3_cursor);
        drop(v1047_2);
        v1046_3.join_into((v1047_3).clone());
        }
        v1046_3_cursor.ascend(1);
      }
      drop(v1046_3_cursor);
      drop(v1046_2);
      v1045_2.join_into((v1046_3).clone());
      }
      v1045_2_cursor.ascend(1);
    }
    drop(v1045_2_cursor);
    v1044_8.join_into((v1045_2).clone());
    }
    v1044_8_cursor.ascend(1);
  }
  drop(v1044_8_cursor);
  (v1044_8).clone()
}

fn routine_92(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1053_8 = Space::new();
  let mut v1053_8_cursor = (*s0).read_zipper();
  for v1053_8_byte in v1053_8_cursor.child_mask().iter() {
    v1053_8_cursor.descend_to_byte(v1053_8_byte);
    {
    let v1053_8_tail = v1053_8_cursor.fork_read_zipper();
    let v1053_8_head = Path::from_slice(&[v1053_8_byte]);
    let mut v1054_2 = Space::new();
    let mut v1054_2_cursor = (v1053_8_tail).read_zipper();
    for v1054_2_byte in v1054_2_cursor.child_mask().iter() {
      v1054_2_cursor.descend_to_byte(v1054_2_byte);
      {
      let v1054_2_tail = v1054_2_cursor.fork_read_zipper();
      let v1054_2_head = Path::from_slice(&[v1054_2_byte]);
      let v1055_2: Path = concat_path(&(v1053_8_head),&(v1054_2_head));
      let mut v1055_3 = Space::new();
      let mut v1055_3_cursor = (v1054_2_tail).read_zipper();
      for v1055_3_byte in v1055_3_cursor.child_mask().iter() {
        v1055_3_cursor.descend_to_byte(v1055_3_byte);
        {
        let v1055_3_tail = v1055_3_cursor.fork_read_zipper();
        let v1055_3_head = Path::from_slice(&[v1055_3_byte]);
        let v1056_2: Path = concat_path(&(v1055_2),&(v1055_3_head));
        let mut v1056_3 = Space::new();
        let mut v1056_3_cursor = (v1055_3_tail).read_zipper();
        for v1056_3_byte in v1056_3_cursor.child_mask().iter() {
          v1056_3_cursor.descend_to_byte(v1056_3_byte);
          {
          let v1056_3_tail = v1056_3_cursor.fork_read_zipper();
          let v1056_3_head = Path::from_slice(&[v1056_3_byte]);
          let v1057_2: Path = concat_path(&(v1056_2),&(v1056_3_head));
          let mut v1057_3 = Space::new();
          let mut v1057_3_cursor = (v1056_3_tail).read_zipper();
          for v1057_3_byte in v1057_3_cursor.child_mask().iter() {
            v1057_3_cursor.descend_to_byte(v1057_3_byte);
            {
            let v1057_3_tail = v1057_3_cursor.fork_read_zipper();
            let v1057_3_head = Path::from_slice(&[v1057_3_byte]);
            let mut v1058_2 = Space::new();
            let mut v1058_2_cursor = (v1057_3_tail).read_zipper();
            for v1058_2_byte in v1058_2_cursor.child_mask().iter() {
              v1058_2_cursor.descend_to_byte(v1058_2_byte);
              {
              let v1058_2_tail = v1058_2_cursor.fork_read_zipper();
              let v1058_2_head = Path::from_slice(&[v1058_2_byte]);
              let v1059_2: Path = concat_path(&(v1057_3_head),&(v1058_2_head));
              let mut v1059_3 = Space::new();
              let mut v1059_3_cursor = (v1058_2_tail).read_zipper();
              for v1059_3_byte in v1059_3_cursor.child_mask().iter() {
                v1059_3_cursor.descend_to_byte(v1059_3_byte);
                {
                let v1059_3_tail = v1059_3_cursor.fork_read_zipper();
                let v1059_3_head = Path::from_slice(&[v1059_3_byte]);
                let v1060_2: Path = concat_path(&(v1059_2),&(v1059_3_head));
                let mut v1060_3 = Space::new();
                let mut v1060_3_cursor = (v1059_3_tail).read_zipper();
                for v1060_3_byte in v1060_3_cursor.child_mask().iter() {
                  v1060_3_cursor.descend_to_byte(v1060_3_byte);
                  {
                  let v1060_3_tail = v1060_3_cursor.fork_read_zipper();
                  let v1060_3_head = Path::from_slice(&[v1060_3_byte]);
                  let v1061_2: Path = concat_path(&(v1060_2),&(v1060_3_head));
                  let v1061_3: Space = routine_108(c, &(v1061_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1057_2), &(v1060_3_tail).make_space());
                  drop(v1061_2);
                  v1060_3.join_into((v1061_3).clone());
                  }
                  v1060_3_cursor.ascend(1);
                }
                drop(v1060_3_cursor);
                drop(v1060_2);
                v1059_3.join_into((v1060_3).clone());
                }
                v1059_3_cursor.ascend(1);
              }
              drop(v1059_3_cursor);
              drop(v1059_2);
              v1058_2.join_into((v1059_3).clone());
              }
              v1058_2_cursor.ascend(1);
            }
            drop(v1058_2_cursor);
            v1057_3.join_into((v1058_2).clone());
            }
            v1057_3_cursor.ascend(1);
          }
          drop(v1057_3_cursor);
          drop(v1057_2);
          v1056_3.join_into((v1057_3).clone());
          }
          v1056_3_cursor.ascend(1);
        }
        drop(v1056_3_cursor);
        drop(v1056_2);
        v1055_3.join_into((v1056_3).clone());
        }
        v1055_3_cursor.ascend(1);
      }
      drop(v1055_3_cursor);
      drop(v1055_2);
      v1054_2.join_into((v1055_3).clone());
      }
      v1054_2_cursor.ascend(1);
    }
    drop(v1054_2_cursor);
    v1053_8.join_into((v1054_2).clone());
    }
    v1053_8_cursor.ascend(1);
  }
  drop(v1053_8_cursor);
  (v1053_8).clone()
}

fn routine_93(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1062_8 = Space::new();
  let mut v1062_8_cursor = (*s0).read_zipper();
  for v1062_8_byte in v1062_8_cursor.child_mask().iter() {
    v1062_8_cursor.descend_to_byte(v1062_8_byte);
    {
    let v1062_8_tail = v1062_8_cursor.fork_read_zipper();
    let v1062_8_head = Path::from_slice(&[v1062_8_byte]);
    let mut v1063_2 = Space::new();
    let mut v1063_2_cursor = (v1062_8_tail).read_zipper();
    for v1063_2_byte in v1063_2_cursor.child_mask().iter() {
      v1063_2_cursor.descend_to_byte(v1063_2_byte);
      {
      let v1063_2_tail = v1063_2_cursor.fork_read_zipper();
      let v1063_2_head = Path::from_slice(&[v1063_2_byte]);
      let v1064_2: Path = concat_path(&(v1062_8_head),&(v1063_2_head));
      let mut v1064_3 = Space::new();
      let mut v1064_3_cursor = (v1063_2_tail).read_zipper();
      for v1064_3_byte in v1064_3_cursor.child_mask().iter() {
        v1064_3_cursor.descend_to_byte(v1064_3_byte);
        {
        let v1064_3_tail = v1064_3_cursor.fork_read_zipper();
        let v1064_3_head = Path::from_slice(&[v1064_3_byte]);
        let v1065_2: Path = concat_path(&(v1064_2),&(v1064_3_head));
        let mut v1065_3 = Space::new();
        let mut v1065_3_cursor = (v1064_3_tail).read_zipper();
        for v1065_3_byte in v1065_3_cursor.child_mask().iter() {
          v1065_3_cursor.descend_to_byte(v1065_3_byte);
          {
          let v1065_3_tail = v1065_3_cursor.fork_read_zipper();
          let v1065_3_head = Path::from_slice(&[v1065_3_byte]);
          let v1066_2: Path = concat_path(&(v1065_2),&(v1065_3_head));
          let mut v1066_3 = Space::new();
          let mut v1066_3_cursor = (v1065_3_tail).read_zipper();
          for v1066_3_byte in v1066_3_cursor.child_mask().iter() {
            v1066_3_cursor.descend_to_byte(v1066_3_byte);
            {
            let v1066_3_tail = v1066_3_cursor.fork_read_zipper();
            let v1066_3_head = Path::from_slice(&[v1066_3_byte]);
            let mut v1067_2 = Space::new();
            let mut v1067_2_cursor = (v1066_3_tail).read_zipper();
            for v1067_2_byte in v1067_2_cursor.child_mask().iter() {
              v1067_2_cursor.descend_to_byte(v1067_2_byte);
              {
              let v1067_2_tail = v1067_2_cursor.fork_read_zipper();
              let v1067_2_head = Path::from_slice(&[v1067_2_byte]);
              let v1068_2: Path = concat_path(&(v1066_3_head),&(v1067_2_head));
              let mut v1068_3 = Space::new();
              let mut v1068_3_cursor = (v1067_2_tail).read_zipper();
              for v1068_3_byte in v1068_3_cursor.child_mask().iter() {
                v1068_3_cursor.descend_to_byte(v1068_3_byte);
                {
                let v1068_3_tail = v1068_3_cursor.fork_read_zipper();
                let v1068_3_head = Path::from_slice(&[v1068_3_byte]);
                let v1069_2: Path = concat_path(&(v1068_2),&(v1068_3_head));
                let mut v1069_3 = Space::new();
                let mut v1069_3_cursor = (v1068_3_tail).read_zipper();
                for v1069_3_byte in v1069_3_cursor.child_mask().iter() {
                  v1069_3_cursor.descend_to_byte(v1069_3_byte);
                  {
                  let v1069_3_tail = v1069_3_cursor.fork_read_zipper();
                  let v1069_3_head = Path::from_slice(&[v1069_3_byte]);
                  let v1070_2: Path = concat_path(&(v1069_2),&(v1069_3_head));
                  let v1070_3: Space = routine_109(c, &(v1070_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1066_2), &(v1069_3_tail).make_space());
                  drop(v1070_2);
                  v1069_3.join_into((v1070_3).clone());
                  }
                  v1069_3_cursor.ascend(1);
                }
                drop(v1069_3_cursor);
                drop(v1069_2);
                v1068_3.join_into((v1069_3).clone());
                }
                v1068_3_cursor.ascend(1);
              }
              drop(v1068_3_cursor);
              drop(v1068_2);
              v1067_2.join_into((v1068_3).clone());
              }
              v1067_2_cursor.ascend(1);
            }
            drop(v1067_2_cursor);
            v1066_3.join_into((v1067_2).clone());
            }
            v1066_3_cursor.ascend(1);
          }
          drop(v1066_3_cursor);
          drop(v1066_2);
          v1065_3.join_into((v1066_3).clone());
          }
          v1065_3_cursor.ascend(1);
        }
        drop(v1065_3_cursor);
        drop(v1065_2);
        v1064_3.join_into((v1065_3).clone());
        }
        v1064_3_cursor.ascend(1);
      }
      drop(v1064_3_cursor);
      drop(v1064_2);
      v1063_2.join_into((v1064_3).clone());
      }
      v1063_2_cursor.ascend(1);
    }
    drop(v1063_2_cursor);
    v1062_8.join_into((v1063_2).clone());
    }
    v1062_8_cursor.ascend(1);
  }
  drop(v1062_8_cursor);
  (v1062_8).clone()
}

fn routine_94(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, s0: &Space) -> Space {
  let mut v1071_8 = Space::new();
  let mut v1071_8_cursor = (*s0).read_zipper();
  for v1071_8_byte in v1071_8_cursor.child_mask().iter() {
    v1071_8_cursor.descend_to_byte(v1071_8_byte);
    {
    let v1071_8_tail = v1071_8_cursor.fork_read_zipper();
    let v1071_8_head = Path::from_slice(&[v1071_8_byte]);
    let mut v1072_2 = Space::new();
    let mut v1072_2_cursor = (v1071_8_tail).read_zipper();
    for v1072_2_byte in v1072_2_cursor.child_mask().iter() {
      v1072_2_cursor.descend_to_byte(v1072_2_byte);
      {
      let v1072_2_tail = v1072_2_cursor.fork_read_zipper();
      let v1072_2_head = Path::from_slice(&[v1072_2_byte]);
      let v1073_2: Path = concat_path(&(v1071_8_head),&(v1072_2_head));
      let mut v1073_3 = Space::new();
      let mut v1073_3_cursor = (v1072_2_tail).read_zipper();
      for v1073_3_byte in v1073_3_cursor.child_mask().iter() {
        v1073_3_cursor.descend_to_byte(v1073_3_byte);
        {
        let v1073_3_tail = v1073_3_cursor.fork_read_zipper();
        let v1073_3_head = Path::from_slice(&[v1073_3_byte]);
        let v1074_2: Path = concat_path(&(v1073_2),&(v1073_3_head));
        let mut v1074_3 = Space::new();
        let mut v1074_3_cursor = (v1073_3_tail).read_zipper();
        for v1074_3_byte in v1074_3_cursor.child_mask().iter() {
          v1074_3_cursor.descend_to_byte(v1074_3_byte);
          {
          let v1074_3_tail = v1074_3_cursor.fork_read_zipper();
          let v1074_3_head = Path::from_slice(&[v1074_3_byte]);
          let v1075_2: Path = concat_path(&(v1074_2),&(v1074_3_head));
          let mut v1075_3 = Space::new();
          let mut v1075_3_cursor = (v1074_3_tail).read_zipper();
          for v1075_3_byte in v1075_3_cursor.child_mask().iter() {
            v1075_3_cursor.descend_to_byte(v1075_3_byte);
            {
            let v1075_3_tail = v1075_3_cursor.fork_read_zipper();
            let v1075_3_head = Path::from_slice(&[v1075_3_byte]);
            let mut v1076_2 = Space::new();
            let mut v1076_2_cursor = (v1075_3_tail).read_zipper();
            for v1076_2_byte in v1076_2_cursor.child_mask().iter() {
              v1076_2_cursor.descend_to_byte(v1076_2_byte);
              {
              let v1076_2_tail = v1076_2_cursor.fork_read_zipper();
              let v1076_2_head = Path::from_slice(&[v1076_2_byte]);
              let v1077_2: Path = concat_path(&(v1075_3_head),&(v1076_2_head));
              let mut v1077_3 = Space::new();
              let mut v1077_3_cursor = (v1076_2_tail).read_zipper();
              for v1077_3_byte in v1077_3_cursor.child_mask().iter() {
                v1077_3_cursor.descend_to_byte(v1077_3_byte);
                {
                let v1077_3_tail = v1077_3_cursor.fork_read_zipper();
                let v1077_3_head = Path::from_slice(&[v1077_3_byte]);
                let v1078_2: Path = concat_path(&(v1077_2),&(v1077_3_head));
                let mut v1078_3 = Space::new();
                let mut v1078_3_cursor = (v1077_3_tail).read_zipper();
                for v1078_3_byte in v1078_3_cursor.child_mask().iter() {
                  v1078_3_cursor.descend_to_byte(v1078_3_byte);
                  {
                  let v1078_3_tail = v1078_3_cursor.fork_read_zipper();
                  let v1078_3_head = Path::from_slice(&[v1078_3_byte]);
                  let v1079_2: Path = concat_path(&(v1078_2),&(v1078_3_head));
                  let v1079_3: Space = routine_110(c, &(v1079_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p0), &(v1075_2), &(v1078_3_tail).make_space());
                  drop(v1079_2);
                  v1078_3.join_into((v1079_3).clone());
                  }
                  v1078_3_cursor.ascend(1);
                }
                drop(v1078_3_cursor);
                drop(v1078_2);
                v1077_3.join_into((v1078_3).clone());
                }
                v1077_3_cursor.ascend(1);
              }
              drop(v1077_3_cursor);
              drop(v1077_2);
              v1076_2.join_into((v1077_3).clone());
              }
              v1076_2_cursor.ascend(1);
            }
            drop(v1076_2_cursor);
            v1075_3.join_into((v1076_2).clone());
            }
            v1075_3_cursor.ascend(1);
          }
          drop(v1075_3_cursor);
          drop(v1075_2);
          v1074_3.join_into((v1075_3).clone());
          }
          v1074_3_cursor.ascend(1);
        }
        drop(v1074_3_cursor);
        drop(v1074_2);
        v1073_3.join_into((v1074_3).clone());
        }
        v1073_3_cursor.ascend(1);
      }
      drop(v1073_3_cursor);
      drop(v1073_2);
      v1072_2.join_into((v1073_3).clone());
      }
      v1072_2_cursor.ascend(1);
    }
    drop(v1072_2_cursor);
    v1071_8.join_into((v1072_2).clone());
    }
    v1071_8_cursor.ascend(1);
  }
  drop(v1071_8_cursor);
  (v1071_8).clone()
}

fn routine_95(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1080_10 = Space::new();
  let mut v1080_10_cursor = (*s0).read_zipper();
  for v1080_10_byte in v1080_10_cursor.child_mask().iter() {
    v1080_10_cursor.descend_to_byte(v1080_10_byte);
    {
    let v1080_10_tail = v1080_10_cursor.fork_read_zipper();
    let v1080_10_head = Path::from_slice(&[v1080_10_byte]);
    let mut v1081_2 = Space::new();
    let mut v1081_2_cursor = (v1080_10_tail).read_zipper();
    for v1081_2_byte in v1081_2_cursor.child_mask().iter() {
      v1081_2_cursor.descend_to_byte(v1081_2_byte);
      {
      let v1081_2_tail = v1081_2_cursor.fork_read_zipper();
      let v1081_2_head = Path::from_slice(&[v1081_2_byte]);
      let v1082_2: Path = concat_path(&(v1080_10_head),&(v1081_2_head));
      let mut v1082_3 = Space::new();
      let mut v1082_3_cursor = (v1081_2_tail).read_zipper();
      for v1082_3_byte in v1082_3_cursor.child_mask().iter() {
        v1082_3_cursor.descend_to_byte(v1082_3_byte);
        {
        let v1082_3_tail = v1082_3_cursor.fork_read_zipper();
        let v1082_3_head = Path::from_slice(&[v1082_3_byte]);
        let v1083_2: Path = concat_path(&(v1082_2),&(v1082_3_head));
        let mut v1083_3 = Space::new();
        let mut v1083_3_cursor = (v1082_3_tail).read_zipper();
        for v1083_3_byte in v1083_3_cursor.child_mask().iter() {
          v1083_3_cursor.descend_to_byte(v1083_3_byte);
          {
          let v1083_3_tail = v1083_3_cursor.fork_read_zipper();
          let v1083_3_head = Path::from_slice(&[v1083_3_byte]);
          let v1084_2: Path = concat_path(&(v1083_2),&(v1083_3_head));
          let mut v1084_3 = Space::new();
          let mut v1084_3_cursor = (v1083_3_tail).read_zipper();
          for v1084_3_byte in v1084_3_cursor.child_mask().iter() {
            v1084_3_cursor.descend_to_byte(v1084_3_byte);
            {
            let v1084_3_tail = v1084_3_cursor.fork_read_zipper();
            let v1084_3_head = Path::from_slice(&[v1084_3_byte]);
            let mut v1085_2 = Space::new();
            let mut v1085_2_cursor = (v1084_3_tail).read_zipper();
            for v1085_2_byte in v1085_2_cursor.child_mask().iter() {
              v1085_2_cursor.descend_to_byte(v1085_2_byte);
              {
              let v1085_2_tail = v1085_2_cursor.fork_read_zipper();
              let v1085_2_head = Path::from_slice(&[v1085_2_byte]);
              let v1086_2: Path = concat_path(&(v1084_3_head),&(v1085_2_head));
              let mut v1086_3 = Space::new();
              let mut v1086_3_cursor = (v1085_2_tail).read_zipper();
              for v1086_3_byte in v1086_3_cursor.child_mask().iter() {
                v1086_3_cursor.descend_to_byte(v1086_3_byte);
                {
                let v1086_3_tail = v1086_3_cursor.fork_read_zipper();
                let v1086_3_head = Path::from_slice(&[v1086_3_byte]);
                let v1087_2: Path = concat_path(&(v1086_2),&(v1086_3_head));
                let mut v1087_3 = Space::new();
                let mut v1087_3_cursor = (v1086_3_tail).read_zipper();
                for v1087_3_byte in v1087_3_cursor.child_mask().iter() {
                  v1087_3_cursor.descend_to_byte(v1087_3_byte);
                  {
                  let v1087_3_tail = v1087_3_cursor.fork_read_zipper();
                  let v1087_3_head = Path::from_slice(&[v1087_3_byte]);
                  let v1088_2: Path = concat_path(&(v1087_2),&(v1087_3_head));
                  let v1088_3: Space = routine_111(c, &(v1088_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1084_2), &(v1087_3_tail).make_space());
                  drop(v1088_2);
                  v1087_3.join_into((v1088_3).clone());
                  }
                  v1087_3_cursor.ascend(1);
                }
                drop(v1087_3_cursor);
                drop(v1087_2);
                v1086_3.join_into((v1087_3).clone());
                }
                v1086_3_cursor.ascend(1);
              }
              drop(v1086_3_cursor);
              drop(v1086_2);
              v1085_2.join_into((v1086_3).clone());
              }
              v1085_2_cursor.ascend(1);
            }
            drop(v1085_2_cursor);
            v1084_3.join_into((v1085_2).clone());
            }
            v1084_3_cursor.ascend(1);
          }
          drop(v1084_3_cursor);
          drop(v1084_2);
          v1083_3.join_into((v1084_3).clone());
          }
          v1083_3_cursor.ascend(1);
        }
        drop(v1083_3_cursor);
        drop(v1083_2);
        v1082_3.join_into((v1083_3).clone());
        }
        v1082_3_cursor.ascend(1);
      }
      drop(v1082_3_cursor);
      drop(v1082_2);
      v1081_2.join_into((v1082_3).clone());
      }
      v1081_2_cursor.ascend(1);
    }
    drop(v1081_2_cursor);
    v1080_10.join_into((v1081_2).clone());
    }
    v1080_10_cursor.ascend(1);
  }
  drop(v1080_10_cursor);
  (v1080_10).clone()
}

fn routine_96(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1089_10 = Space::new();
  let mut v1089_10_cursor = (*s0).read_zipper();
  for v1089_10_byte in v1089_10_cursor.child_mask().iter() {
    v1089_10_cursor.descend_to_byte(v1089_10_byte);
    {
    let v1089_10_tail = v1089_10_cursor.fork_read_zipper();
    let v1089_10_head = Path::from_slice(&[v1089_10_byte]);
    let mut v1090_2 = Space::new();
    let mut v1090_2_cursor = (v1089_10_tail).read_zipper();
    for v1090_2_byte in v1090_2_cursor.child_mask().iter() {
      v1090_2_cursor.descend_to_byte(v1090_2_byte);
      {
      let v1090_2_tail = v1090_2_cursor.fork_read_zipper();
      let v1090_2_head = Path::from_slice(&[v1090_2_byte]);
      let v1091_2: Path = concat_path(&(v1089_10_head),&(v1090_2_head));
      let mut v1091_3 = Space::new();
      let mut v1091_3_cursor = (v1090_2_tail).read_zipper();
      for v1091_3_byte in v1091_3_cursor.child_mask().iter() {
        v1091_3_cursor.descend_to_byte(v1091_3_byte);
        {
        let v1091_3_tail = v1091_3_cursor.fork_read_zipper();
        let v1091_3_head = Path::from_slice(&[v1091_3_byte]);
        let v1092_2: Path = concat_path(&(v1091_2),&(v1091_3_head));
        let mut v1092_3 = Space::new();
        let mut v1092_3_cursor = (v1091_3_tail).read_zipper();
        for v1092_3_byte in v1092_3_cursor.child_mask().iter() {
          v1092_3_cursor.descend_to_byte(v1092_3_byte);
          {
          let v1092_3_tail = v1092_3_cursor.fork_read_zipper();
          let v1092_3_head = Path::from_slice(&[v1092_3_byte]);
          let v1093_2: Path = concat_path(&(v1092_2),&(v1092_3_head));
          let mut v1093_3 = Space::new();
          let mut v1093_3_cursor = (v1092_3_tail).read_zipper();
          for v1093_3_byte in v1093_3_cursor.child_mask().iter() {
            v1093_3_cursor.descend_to_byte(v1093_3_byte);
            {
            let v1093_3_tail = v1093_3_cursor.fork_read_zipper();
            let v1093_3_head = Path::from_slice(&[v1093_3_byte]);
            let mut v1094_2 = Space::new();
            let mut v1094_2_cursor = (v1093_3_tail).read_zipper();
            for v1094_2_byte in v1094_2_cursor.child_mask().iter() {
              v1094_2_cursor.descend_to_byte(v1094_2_byte);
              {
              let v1094_2_tail = v1094_2_cursor.fork_read_zipper();
              let v1094_2_head = Path::from_slice(&[v1094_2_byte]);
              let v1095_2: Path = concat_path(&(v1093_3_head),&(v1094_2_head));
              let mut v1095_3 = Space::new();
              let mut v1095_3_cursor = (v1094_2_tail).read_zipper();
              for v1095_3_byte in v1095_3_cursor.child_mask().iter() {
                v1095_3_cursor.descend_to_byte(v1095_3_byte);
                {
                let v1095_3_tail = v1095_3_cursor.fork_read_zipper();
                let v1095_3_head = Path::from_slice(&[v1095_3_byte]);
                let v1096_2: Path = concat_path(&(v1095_2),&(v1095_3_head));
                let mut v1096_3 = Space::new();
                let mut v1096_3_cursor = (v1095_3_tail).read_zipper();
                for v1096_3_byte in v1096_3_cursor.child_mask().iter() {
                  v1096_3_cursor.descend_to_byte(v1096_3_byte);
                  {
                  let v1096_3_tail = v1096_3_cursor.fork_read_zipper();
                  let v1096_3_head = Path::from_slice(&[v1096_3_byte]);
                  let v1097_2: Path = concat_path(&(v1096_2),&(v1096_3_head));
                  let v1097_3: Space = routine_112(c, &(v1097_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1093_2), &(v1096_3_tail).make_space());
                  drop(v1097_2);
                  v1096_3.join_into((v1097_3).clone());
                  }
                  v1096_3_cursor.ascend(1);
                }
                drop(v1096_3_cursor);
                drop(v1096_2);
                v1095_3.join_into((v1096_3).clone());
                }
                v1095_3_cursor.ascend(1);
              }
              drop(v1095_3_cursor);
              drop(v1095_2);
              v1094_2.join_into((v1095_3).clone());
              }
              v1094_2_cursor.ascend(1);
            }
            drop(v1094_2_cursor);
            v1093_3.join_into((v1094_2).clone());
            }
            v1093_3_cursor.ascend(1);
          }
          drop(v1093_3_cursor);
          drop(v1093_2);
          v1092_3.join_into((v1093_3).clone());
          }
          v1092_3_cursor.ascend(1);
        }
        drop(v1092_3_cursor);
        drop(v1092_2);
        v1091_3.join_into((v1092_3).clone());
        }
        v1091_3_cursor.ascend(1);
      }
      drop(v1091_3_cursor);
      drop(v1091_2);
      v1090_2.join_into((v1091_3).clone());
      }
      v1090_2_cursor.ascend(1);
    }
    drop(v1090_2_cursor);
    v1089_10.join_into((v1090_2).clone());
    }
    v1089_10_cursor.ascend(1);
  }
  drop(v1089_10_cursor);
  (v1089_10).clone()
}

fn routine_97(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1098_10 = Space::new();
  let mut v1098_10_cursor = (*s0).read_zipper();
  for v1098_10_byte in v1098_10_cursor.child_mask().iter() {
    v1098_10_cursor.descend_to_byte(v1098_10_byte);
    {
    let v1098_10_tail = v1098_10_cursor.fork_read_zipper();
    let v1098_10_head = Path::from_slice(&[v1098_10_byte]);
    let mut v1099_2 = Space::new();
    let mut v1099_2_cursor = (v1098_10_tail).read_zipper();
    for v1099_2_byte in v1099_2_cursor.child_mask().iter() {
      v1099_2_cursor.descend_to_byte(v1099_2_byte);
      {
      let v1099_2_tail = v1099_2_cursor.fork_read_zipper();
      let v1099_2_head = Path::from_slice(&[v1099_2_byte]);
      let v1100_2: Path = concat_path(&(v1098_10_head),&(v1099_2_head));
      let mut v1100_3 = Space::new();
      let mut v1100_3_cursor = (v1099_2_tail).read_zipper();
      for v1100_3_byte in v1100_3_cursor.child_mask().iter() {
        v1100_3_cursor.descend_to_byte(v1100_3_byte);
        {
        let v1100_3_tail = v1100_3_cursor.fork_read_zipper();
        let v1100_3_head = Path::from_slice(&[v1100_3_byte]);
        let v1101_2: Path = concat_path(&(v1100_2),&(v1100_3_head));
        let mut v1101_3 = Space::new();
        let mut v1101_3_cursor = (v1100_3_tail).read_zipper();
        for v1101_3_byte in v1101_3_cursor.child_mask().iter() {
          v1101_3_cursor.descend_to_byte(v1101_3_byte);
          {
          let v1101_3_tail = v1101_3_cursor.fork_read_zipper();
          let v1101_3_head = Path::from_slice(&[v1101_3_byte]);
          let v1102_2: Path = concat_path(&(v1101_2),&(v1101_3_head));
          let mut v1102_3 = Space::new();
          let mut v1102_3_cursor = (v1101_3_tail).read_zipper();
          for v1102_3_byte in v1102_3_cursor.child_mask().iter() {
            v1102_3_cursor.descend_to_byte(v1102_3_byte);
            {
            let v1102_3_tail = v1102_3_cursor.fork_read_zipper();
            let v1102_3_head = Path::from_slice(&[v1102_3_byte]);
            let mut v1103_2 = Space::new();
            let mut v1103_2_cursor = (v1102_3_tail).read_zipper();
            for v1103_2_byte in v1103_2_cursor.child_mask().iter() {
              v1103_2_cursor.descend_to_byte(v1103_2_byte);
              {
              let v1103_2_tail = v1103_2_cursor.fork_read_zipper();
              let v1103_2_head = Path::from_slice(&[v1103_2_byte]);
              let v1104_2: Path = concat_path(&(v1102_3_head),&(v1103_2_head));
              let mut v1104_3 = Space::new();
              let mut v1104_3_cursor = (v1103_2_tail).read_zipper();
              for v1104_3_byte in v1104_3_cursor.child_mask().iter() {
                v1104_3_cursor.descend_to_byte(v1104_3_byte);
                {
                let v1104_3_tail = v1104_3_cursor.fork_read_zipper();
                let v1104_3_head = Path::from_slice(&[v1104_3_byte]);
                let v1105_2: Path = concat_path(&(v1104_2),&(v1104_3_head));
                let mut v1105_3 = Space::new();
                let mut v1105_3_cursor = (v1104_3_tail).read_zipper();
                for v1105_3_byte in v1105_3_cursor.child_mask().iter() {
                  v1105_3_cursor.descend_to_byte(v1105_3_byte);
                  {
                  let v1105_3_tail = v1105_3_cursor.fork_read_zipper();
                  let v1105_3_head = Path::from_slice(&[v1105_3_byte]);
                  let v1106_2: Path = concat_path(&(v1105_2),&(v1105_3_head));
                  let v1106_3: Space = routine_113(c, &(v1106_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1102_2), &(v1105_3_tail).make_space());
                  drop(v1106_2);
                  v1105_3.join_into((v1106_3).clone());
                  }
                  v1105_3_cursor.ascend(1);
                }
                drop(v1105_3_cursor);
                drop(v1105_2);
                v1104_3.join_into((v1105_3).clone());
                }
                v1104_3_cursor.ascend(1);
              }
              drop(v1104_3_cursor);
              drop(v1104_2);
              v1103_2.join_into((v1104_3).clone());
              }
              v1103_2_cursor.ascend(1);
            }
            drop(v1103_2_cursor);
            v1102_3.join_into((v1103_2).clone());
            }
            v1102_3_cursor.ascend(1);
          }
          drop(v1102_3_cursor);
          drop(v1102_2);
          v1101_3.join_into((v1102_3).clone());
          }
          v1101_3_cursor.ascend(1);
        }
        drop(v1101_3_cursor);
        drop(v1101_2);
        v1100_3.join_into((v1101_3).clone());
        }
        v1100_3_cursor.ascend(1);
      }
      drop(v1100_3_cursor);
      drop(v1100_2);
      v1099_2.join_into((v1100_3).clone());
      }
      v1099_2_cursor.ascend(1);
    }
    drop(v1099_2_cursor);
    v1098_10.join_into((v1099_2).clone());
    }
    v1098_10_cursor.ascend(1);
  }
  drop(v1098_10_cursor);
  (v1098_10).clone()
}

fn routine_98(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1107_10 = Space::new();
  let mut v1107_10_cursor = (*s0).read_zipper();
  for v1107_10_byte in v1107_10_cursor.child_mask().iter() {
    v1107_10_cursor.descend_to_byte(v1107_10_byte);
    {
    let v1107_10_tail = v1107_10_cursor.fork_read_zipper();
    let v1107_10_head = Path::from_slice(&[v1107_10_byte]);
    let mut v1108_2 = Space::new();
    let mut v1108_2_cursor = (v1107_10_tail).read_zipper();
    for v1108_2_byte in v1108_2_cursor.child_mask().iter() {
      v1108_2_cursor.descend_to_byte(v1108_2_byte);
      {
      let v1108_2_tail = v1108_2_cursor.fork_read_zipper();
      let v1108_2_head = Path::from_slice(&[v1108_2_byte]);
      let v1109_2: Path = concat_path(&(v1107_10_head),&(v1108_2_head));
      let mut v1109_3 = Space::new();
      let mut v1109_3_cursor = (v1108_2_tail).read_zipper();
      for v1109_3_byte in v1109_3_cursor.child_mask().iter() {
        v1109_3_cursor.descend_to_byte(v1109_3_byte);
        {
        let v1109_3_tail = v1109_3_cursor.fork_read_zipper();
        let v1109_3_head = Path::from_slice(&[v1109_3_byte]);
        let v1110_2: Path = concat_path(&(v1109_2),&(v1109_3_head));
        let mut v1110_3 = Space::new();
        let mut v1110_3_cursor = (v1109_3_tail).read_zipper();
        for v1110_3_byte in v1110_3_cursor.child_mask().iter() {
          v1110_3_cursor.descend_to_byte(v1110_3_byte);
          {
          let v1110_3_tail = v1110_3_cursor.fork_read_zipper();
          let v1110_3_head = Path::from_slice(&[v1110_3_byte]);
          let v1111_2: Path = concat_path(&(v1110_2),&(v1110_3_head));
          let mut v1111_3 = Space::new();
          let mut v1111_3_cursor = (v1110_3_tail).read_zipper();
          for v1111_3_byte in v1111_3_cursor.child_mask().iter() {
            v1111_3_cursor.descend_to_byte(v1111_3_byte);
            {
            let v1111_3_tail = v1111_3_cursor.fork_read_zipper();
            let v1111_3_head = Path::from_slice(&[v1111_3_byte]);
            let mut v1112_2 = Space::new();
            let mut v1112_2_cursor = (v1111_3_tail).read_zipper();
            for v1112_2_byte in v1112_2_cursor.child_mask().iter() {
              v1112_2_cursor.descend_to_byte(v1112_2_byte);
              {
              let v1112_2_tail = v1112_2_cursor.fork_read_zipper();
              let v1112_2_head = Path::from_slice(&[v1112_2_byte]);
              let v1113_2: Path = concat_path(&(v1111_3_head),&(v1112_2_head));
              let mut v1113_3 = Space::new();
              let mut v1113_3_cursor = (v1112_2_tail).read_zipper();
              for v1113_3_byte in v1113_3_cursor.child_mask().iter() {
                v1113_3_cursor.descend_to_byte(v1113_3_byte);
                {
                let v1113_3_tail = v1113_3_cursor.fork_read_zipper();
                let v1113_3_head = Path::from_slice(&[v1113_3_byte]);
                let v1114_2: Path = concat_path(&(v1113_2),&(v1113_3_head));
                let mut v1114_3 = Space::new();
                let mut v1114_3_cursor = (v1113_3_tail).read_zipper();
                for v1114_3_byte in v1114_3_cursor.child_mask().iter() {
                  v1114_3_cursor.descend_to_byte(v1114_3_byte);
                  {
                  let v1114_3_tail = v1114_3_cursor.fork_read_zipper();
                  let v1114_3_head = Path::from_slice(&[v1114_3_byte]);
                  let v1115_2: Path = concat_path(&(v1114_2),&(v1114_3_head));
                  let v1115_3: Space = routine_114(c, &(v1115_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1111_2), &(v1114_3_tail).make_space());
                  drop(v1115_2);
                  v1114_3.join_into((v1115_3).clone());
                  }
                  v1114_3_cursor.ascend(1);
                }
                drop(v1114_3_cursor);
                drop(v1114_2);
                v1113_3.join_into((v1114_3).clone());
                }
                v1113_3_cursor.ascend(1);
              }
              drop(v1113_3_cursor);
              drop(v1113_2);
              v1112_2.join_into((v1113_3).clone());
              }
              v1112_2_cursor.ascend(1);
            }
            drop(v1112_2_cursor);
            v1111_3.join_into((v1112_2).clone());
            }
            v1111_3_cursor.ascend(1);
          }
          drop(v1111_3_cursor);
          drop(v1111_2);
          v1110_3.join_into((v1111_3).clone());
          }
          v1110_3_cursor.ascend(1);
        }
        drop(v1110_3_cursor);
        drop(v1110_2);
        v1109_3.join_into((v1110_3).clone());
        }
        v1109_3_cursor.ascend(1);
      }
      drop(v1109_3_cursor);
      drop(v1109_2);
      v1108_2.join_into((v1109_3).clone());
      }
      v1108_2_cursor.ascend(1);
    }
    drop(v1108_2_cursor);
    v1107_10.join_into((v1108_2).clone());
    }
    v1107_10_cursor.ascend(1);
  }
  drop(v1107_10_cursor);
  (v1107_10).clone()
}

fn routine_99(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1116_10 = Space::new();
  let mut v1116_10_cursor = (*s0).read_zipper();
  for v1116_10_byte in v1116_10_cursor.child_mask().iter() {
    v1116_10_cursor.descend_to_byte(v1116_10_byte);
    {
    let v1116_10_tail = v1116_10_cursor.fork_read_zipper();
    let v1116_10_head = Path::from_slice(&[v1116_10_byte]);
    let mut v1117_2 = Space::new();
    let mut v1117_2_cursor = (v1116_10_tail).read_zipper();
    for v1117_2_byte in v1117_2_cursor.child_mask().iter() {
      v1117_2_cursor.descend_to_byte(v1117_2_byte);
      {
      let v1117_2_tail = v1117_2_cursor.fork_read_zipper();
      let v1117_2_head = Path::from_slice(&[v1117_2_byte]);
      let v1118_2: Path = concat_path(&(v1116_10_head),&(v1117_2_head));
      let mut v1118_3 = Space::new();
      let mut v1118_3_cursor = (v1117_2_tail).read_zipper();
      for v1118_3_byte in v1118_3_cursor.child_mask().iter() {
        v1118_3_cursor.descend_to_byte(v1118_3_byte);
        {
        let v1118_3_tail = v1118_3_cursor.fork_read_zipper();
        let v1118_3_head = Path::from_slice(&[v1118_3_byte]);
        let v1119_2: Path = concat_path(&(v1118_2),&(v1118_3_head));
        let mut v1119_3 = Space::new();
        let mut v1119_3_cursor = (v1118_3_tail).read_zipper();
        for v1119_3_byte in v1119_3_cursor.child_mask().iter() {
          v1119_3_cursor.descend_to_byte(v1119_3_byte);
          {
          let v1119_3_tail = v1119_3_cursor.fork_read_zipper();
          let v1119_3_head = Path::from_slice(&[v1119_3_byte]);
          let v1120_2: Path = concat_path(&(v1119_2),&(v1119_3_head));
          let mut v1120_3 = Space::new();
          let mut v1120_3_cursor = (v1119_3_tail).read_zipper();
          for v1120_3_byte in v1120_3_cursor.child_mask().iter() {
            v1120_3_cursor.descend_to_byte(v1120_3_byte);
            {
            let v1120_3_tail = v1120_3_cursor.fork_read_zipper();
            let v1120_3_head = Path::from_slice(&[v1120_3_byte]);
            let mut v1121_2 = Space::new();
            let mut v1121_2_cursor = (v1120_3_tail).read_zipper();
            for v1121_2_byte in v1121_2_cursor.child_mask().iter() {
              v1121_2_cursor.descend_to_byte(v1121_2_byte);
              {
              let v1121_2_tail = v1121_2_cursor.fork_read_zipper();
              let v1121_2_head = Path::from_slice(&[v1121_2_byte]);
              let v1122_2: Path = concat_path(&(v1120_3_head),&(v1121_2_head));
              let mut v1122_3 = Space::new();
              let mut v1122_3_cursor = (v1121_2_tail).read_zipper();
              for v1122_3_byte in v1122_3_cursor.child_mask().iter() {
                v1122_3_cursor.descend_to_byte(v1122_3_byte);
                {
                let v1122_3_tail = v1122_3_cursor.fork_read_zipper();
                let v1122_3_head = Path::from_slice(&[v1122_3_byte]);
                let v1123_2: Path = concat_path(&(v1122_2),&(v1122_3_head));
                let mut v1123_3 = Space::new();
                let mut v1123_3_cursor = (v1122_3_tail).read_zipper();
                for v1123_3_byte in v1123_3_cursor.child_mask().iter() {
                  v1123_3_cursor.descend_to_byte(v1123_3_byte);
                  {
                  let v1123_3_tail = v1123_3_cursor.fork_read_zipper();
                  let v1123_3_head = Path::from_slice(&[v1123_3_byte]);
                  let v1124_2: Path = concat_path(&(v1123_2),&(v1123_3_head));
                  let v1124_3: Space = routine_115(c, &(v1124_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1120_2), &(v1123_3_tail).make_space());
                  drop(v1124_2);
                  v1123_3.join_into((v1124_3).clone());
                  }
                  v1123_3_cursor.ascend(1);
                }
                drop(v1123_3_cursor);
                drop(v1123_2);
                v1122_3.join_into((v1123_3).clone());
                }
                v1122_3_cursor.ascend(1);
              }
              drop(v1122_3_cursor);
              drop(v1122_2);
              v1121_2.join_into((v1122_3).clone());
              }
              v1121_2_cursor.ascend(1);
            }
            drop(v1121_2_cursor);
            v1120_3.join_into((v1121_2).clone());
            }
            v1120_3_cursor.ascend(1);
          }
          drop(v1120_3_cursor);
          drop(v1120_2);
          v1119_3.join_into((v1120_3).clone());
          }
          v1119_3_cursor.ascend(1);
        }
        drop(v1119_3_cursor);
        drop(v1119_2);
        v1118_3.join_into((v1119_3).clone());
        }
        v1118_3_cursor.ascend(1);
      }
      drop(v1118_3_cursor);
      drop(v1118_2);
      v1117_2.join_into((v1118_3).clone());
      }
      v1117_2_cursor.ascend(1);
    }
    drop(v1117_2_cursor);
    v1116_10.join_into((v1117_2).clone());
    }
    v1116_10_cursor.ascend(1);
  }
  drop(v1116_10_cursor);
  (v1116_10).clone()
}

fn routine_100(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1125_10 = Space::new();
  let mut v1125_10_cursor = (*s0).read_zipper();
  for v1125_10_byte in v1125_10_cursor.child_mask().iter() {
    v1125_10_cursor.descend_to_byte(v1125_10_byte);
    {
    let v1125_10_tail = v1125_10_cursor.fork_read_zipper();
    let v1125_10_head = Path::from_slice(&[v1125_10_byte]);
    let mut v1126_2 = Space::new();
    let mut v1126_2_cursor = (v1125_10_tail).read_zipper();
    for v1126_2_byte in v1126_2_cursor.child_mask().iter() {
      v1126_2_cursor.descend_to_byte(v1126_2_byte);
      {
      let v1126_2_tail = v1126_2_cursor.fork_read_zipper();
      let v1126_2_head = Path::from_slice(&[v1126_2_byte]);
      let v1127_2: Path = concat_path(&(v1125_10_head),&(v1126_2_head));
      let mut v1127_3 = Space::new();
      let mut v1127_3_cursor = (v1126_2_tail).read_zipper();
      for v1127_3_byte in v1127_3_cursor.child_mask().iter() {
        v1127_3_cursor.descend_to_byte(v1127_3_byte);
        {
        let v1127_3_tail = v1127_3_cursor.fork_read_zipper();
        let v1127_3_head = Path::from_slice(&[v1127_3_byte]);
        let v1128_2: Path = concat_path(&(v1127_2),&(v1127_3_head));
        let mut v1128_3 = Space::new();
        let mut v1128_3_cursor = (v1127_3_tail).read_zipper();
        for v1128_3_byte in v1128_3_cursor.child_mask().iter() {
          v1128_3_cursor.descend_to_byte(v1128_3_byte);
          {
          let v1128_3_tail = v1128_3_cursor.fork_read_zipper();
          let v1128_3_head = Path::from_slice(&[v1128_3_byte]);
          let v1129_2: Path = concat_path(&(v1128_2),&(v1128_3_head));
          let mut v1129_3 = Space::new();
          let mut v1129_3_cursor = (v1128_3_tail).read_zipper();
          for v1129_3_byte in v1129_3_cursor.child_mask().iter() {
            v1129_3_cursor.descend_to_byte(v1129_3_byte);
            {
            let v1129_3_tail = v1129_3_cursor.fork_read_zipper();
            let v1129_3_head = Path::from_slice(&[v1129_3_byte]);
            let mut v1130_2 = Space::new();
            let mut v1130_2_cursor = (v1129_3_tail).read_zipper();
            for v1130_2_byte in v1130_2_cursor.child_mask().iter() {
              v1130_2_cursor.descend_to_byte(v1130_2_byte);
              {
              let v1130_2_tail = v1130_2_cursor.fork_read_zipper();
              let v1130_2_head = Path::from_slice(&[v1130_2_byte]);
              let v1131_2: Path = concat_path(&(v1129_3_head),&(v1130_2_head));
              let mut v1131_3 = Space::new();
              let mut v1131_3_cursor = (v1130_2_tail).read_zipper();
              for v1131_3_byte in v1131_3_cursor.child_mask().iter() {
                v1131_3_cursor.descend_to_byte(v1131_3_byte);
                {
                let v1131_3_tail = v1131_3_cursor.fork_read_zipper();
                let v1131_3_head = Path::from_slice(&[v1131_3_byte]);
                let v1132_2: Path = concat_path(&(v1131_2),&(v1131_3_head));
                let mut v1132_3 = Space::new();
                let mut v1132_3_cursor = (v1131_3_tail).read_zipper();
                for v1132_3_byte in v1132_3_cursor.child_mask().iter() {
                  v1132_3_cursor.descend_to_byte(v1132_3_byte);
                  {
                  let v1132_3_tail = v1132_3_cursor.fork_read_zipper();
                  let v1132_3_head = Path::from_slice(&[v1132_3_byte]);
                  let v1133_2: Path = concat_path(&(v1132_2),&(v1132_3_head));
                  let v1133_3: Space = routine_116(c, &(v1133_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1129_2), &(v1132_3_tail).make_space());
                  drop(v1133_2);
                  v1132_3.join_into((v1133_3).clone());
                  }
                  v1132_3_cursor.ascend(1);
                }
                drop(v1132_3_cursor);
                drop(v1132_2);
                v1131_3.join_into((v1132_3).clone());
                }
                v1131_3_cursor.ascend(1);
              }
              drop(v1131_3_cursor);
              drop(v1131_2);
              v1130_2.join_into((v1131_3).clone());
              }
              v1130_2_cursor.ascend(1);
            }
            drop(v1130_2_cursor);
            v1129_3.join_into((v1130_2).clone());
            }
            v1129_3_cursor.ascend(1);
          }
          drop(v1129_3_cursor);
          drop(v1129_2);
          v1128_3.join_into((v1129_3).clone());
          }
          v1128_3_cursor.ascend(1);
        }
        drop(v1128_3_cursor);
        drop(v1128_2);
        v1127_3.join_into((v1128_3).clone());
        }
        v1127_3_cursor.ascend(1);
      }
      drop(v1127_3_cursor);
      drop(v1127_2);
      v1126_2.join_into((v1127_3).clone());
      }
      v1126_2_cursor.ascend(1);
    }
    drop(v1126_2_cursor);
    v1125_10.join_into((v1126_2).clone());
    }
    v1125_10_cursor.ascend(1);
  }
  drop(v1125_10_cursor);
  (v1125_10).clone()
}

fn routine_101(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1134_10 = Space::new();
  let mut v1134_10_cursor = (*s0).read_zipper();
  for v1134_10_byte in v1134_10_cursor.child_mask().iter() {
    v1134_10_cursor.descend_to_byte(v1134_10_byte);
    {
    let v1134_10_tail = v1134_10_cursor.fork_read_zipper();
    let v1134_10_head = Path::from_slice(&[v1134_10_byte]);
    let mut v1135_2 = Space::new();
    let mut v1135_2_cursor = (v1134_10_tail).read_zipper();
    for v1135_2_byte in v1135_2_cursor.child_mask().iter() {
      v1135_2_cursor.descend_to_byte(v1135_2_byte);
      {
      let v1135_2_tail = v1135_2_cursor.fork_read_zipper();
      let v1135_2_head = Path::from_slice(&[v1135_2_byte]);
      let v1136_2: Path = concat_path(&(v1134_10_head),&(v1135_2_head));
      let mut v1136_3 = Space::new();
      let mut v1136_3_cursor = (v1135_2_tail).read_zipper();
      for v1136_3_byte in v1136_3_cursor.child_mask().iter() {
        v1136_3_cursor.descend_to_byte(v1136_3_byte);
        {
        let v1136_3_tail = v1136_3_cursor.fork_read_zipper();
        let v1136_3_head = Path::from_slice(&[v1136_3_byte]);
        let v1137_2: Path = concat_path(&(v1136_2),&(v1136_3_head));
        let mut v1137_3 = Space::new();
        let mut v1137_3_cursor = (v1136_3_tail).read_zipper();
        for v1137_3_byte in v1137_3_cursor.child_mask().iter() {
          v1137_3_cursor.descend_to_byte(v1137_3_byte);
          {
          let v1137_3_tail = v1137_3_cursor.fork_read_zipper();
          let v1137_3_head = Path::from_slice(&[v1137_3_byte]);
          let v1138_2: Path = concat_path(&(v1137_2),&(v1137_3_head));
          let mut v1138_3 = Space::new();
          let mut v1138_3_cursor = (v1137_3_tail).read_zipper();
          for v1138_3_byte in v1138_3_cursor.child_mask().iter() {
            v1138_3_cursor.descend_to_byte(v1138_3_byte);
            {
            let v1138_3_tail = v1138_3_cursor.fork_read_zipper();
            let v1138_3_head = Path::from_slice(&[v1138_3_byte]);
            let mut v1139_2 = Space::new();
            let mut v1139_2_cursor = (v1138_3_tail).read_zipper();
            for v1139_2_byte in v1139_2_cursor.child_mask().iter() {
              v1139_2_cursor.descend_to_byte(v1139_2_byte);
              {
              let v1139_2_tail = v1139_2_cursor.fork_read_zipper();
              let v1139_2_head = Path::from_slice(&[v1139_2_byte]);
              let v1140_2: Path = concat_path(&(v1138_3_head),&(v1139_2_head));
              let mut v1140_3 = Space::new();
              let mut v1140_3_cursor = (v1139_2_tail).read_zipper();
              for v1140_3_byte in v1140_3_cursor.child_mask().iter() {
                v1140_3_cursor.descend_to_byte(v1140_3_byte);
                {
                let v1140_3_tail = v1140_3_cursor.fork_read_zipper();
                let v1140_3_head = Path::from_slice(&[v1140_3_byte]);
                let v1141_2: Path = concat_path(&(v1140_2),&(v1140_3_head));
                let mut v1141_3 = Space::new();
                let mut v1141_3_cursor = (v1140_3_tail).read_zipper();
                for v1141_3_byte in v1141_3_cursor.child_mask().iter() {
                  v1141_3_cursor.descend_to_byte(v1141_3_byte);
                  {
                  let v1141_3_tail = v1141_3_cursor.fork_read_zipper();
                  let v1141_3_head = Path::from_slice(&[v1141_3_byte]);
                  let v1142_2: Path = concat_path(&(v1141_2),&(v1141_3_head));
                  let v1142_3: Space = routine_117(c, &(v1142_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1138_2), &(v1141_3_tail).make_space());
                  drop(v1142_2);
                  v1141_3.join_into((v1142_3).clone());
                  }
                  v1141_3_cursor.ascend(1);
                }
                drop(v1141_3_cursor);
                drop(v1141_2);
                v1140_3.join_into((v1141_3).clone());
                }
                v1140_3_cursor.ascend(1);
              }
              drop(v1140_3_cursor);
              drop(v1140_2);
              v1139_2.join_into((v1140_3).clone());
              }
              v1139_2_cursor.ascend(1);
            }
            drop(v1139_2_cursor);
            v1138_3.join_into((v1139_2).clone());
            }
            v1138_3_cursor.ascend(1);
          }
          drop(v1138_3_cursor);
          drop(v1138_2);
          v1137_3.join_into((v1138_3).clone());
          }
          v1137_3_cursor.ascend(1);
        }
        drop(v1137_3_cursor);
        drop(v1137_2);
        v1136_3.join_into((v1137_3).clone());
        }
        v1136_3_cursor.ascend(1);
      }
      drop(v1136_3_cursor);
      drop(v1136_2);
      v1135_2.join_into((v1136_3).clone());
      }
      v1135_2_cursor.ascend(1);
    }
    drop(v1135_2_cursor);
    v1134_10.join_into((v1135_2).clone());
    }
    v1134_10_cursor.ascend(1);
  }
  drop(v1134_10_cursor);
  (v1134_10).clone()
}

fn routine_102(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1143_10 = Space::new();
  let mut v1143_10_cursor = (*s0).read_zipper();
  for v1143_10_byte in v1143_10_cursor.child_mask().iter() {
    v1143_10_cursor.descend_to_byte(v1143_10_byte);
    {
    let v1143_10_tail = v1143_10_cursor.fork_read_zipper();
    let v1143_10_head = Path::from_slice(&[v1143_10_byte]);
    let mut v1144_2 = Space::new();
    let mut v1144_2_cursor = (v1143_10_tail).read_zipper();
    for v1144_2_byte in v1144_2_cursor.child_mask().iter() {
      v1144_2_cursor.descend_to_byte(v1144_2_byte);
      {
      let v1144_2_tail = v1144_2_cursor.fork_read_zipper();
      let v1144_2_head = Path::from_slice(&[v1144_2_byte]);
      let v1145_2: Path = concat_path(&(v1143_10_head),&(v1144_2_head));
      let mut v1145_3 = Space::new();
      let mut v1145_3_cursor = (v1144_2_tail).read_zipper();
      for v1145_3_byte in v1145_3_cursor.child_mask().iter() {
        v1145_3_cursor.descend_to_byte(v1145_3_byte);
        {
        let v1145_3_tail = v1145_3_cursor.fork_read_zipper();
        let v1145_3_head = Path::from_slice(&[v1145_3_byte]);
        let v1146_2: Path = concat_path(&(v1145_2),&(v1145_3_head));
        let mut v1146_3 = Space::new();
        let mut v1146_3_cursor = (v1145_3_tail).read_zipper();
        for v1146_3_byte in v1146_3_cursor.child_mask().iter() {
          v1146_3_cursor.descend_to_byte(v1146_3_byte);
          {
          let v1146_3_tail = v1146_3_cursor.fork_read_zipper();
          let v1146_3_head = Path::from_slice(&[v1146_3_byte]);
          let v1147_2: Path = concat_path(&(v1146_2),&(v1146_3_head));
          let mut v1147_3 = Space::new();
          let mut v1147_3_cursor = (v1146_3_tail).read_zipper();
          for v1147_3_byte in v1147_3_cursor.child_mask().iter() {
            v1147_3_cursor.descend_to_byte(v1147_3_byte);
            {
            let v1147_3_tail = v1147_3_cursor.fork_read_zipper();
            let v1147_3_head = Path::from_slice(&[v1147_3_byte]);
            let mut v1148_2 = Space::new();
            let mut v1148_2_cursor = (v1147_3_tail).read_zipper();
            for v1148_2_byte in v1148_2_cursor.child_mask().iter() {
              v1148_2_cursor.descend_to_byte(v1148_2_byte);
              {
              let v1148_2_tail = v1148_2_cursor.fork_read_zipper();
              let v1148_2_head = Path::from_slice(&[v1148_2_byte]);
              let v1149_2: Path = concat_path(&(v1147_3_head),&(v1148_2_head));
              let mut v1149_3 = Space::new();
              let mut v1149_3_cursor = (v1148_2_tail).read_zipper();
              for v1149_3_byte in v1149_3_cursor.child_mask().iter() {
                v1149_3_cursor.descend_to_byte(v1149_3_byte);
                {
                let v1149_3_tail = v1149_3_cursor.fork_read_zipper();
                let v1149_3_head = Path::from_slice(&[v1149_3_byte]);
                let v1150_2: Path = concat_path(&(v1149_2),&(v1149_3_head));
                let mut v1150_3 = Space::new();
                let mut v1150_3_cursor = (v1149_3_tail).read_zipper();
                for v1150_3_byte in v1150_3_cursor.child_mask().iter() {
                  v1150_3_cursor.descend_to_byte(v1150_3_byte);
                  {
                  let v1150_3_tail = v1150_3_cursor.fork_read_zipper();
                  let v1150_3_head = Path::from_slice(&[v1150_3_byte]);
                  let v1151_2: Path = concat_path(&(v1150_2),&(v1150_3_head));
                  let v1151_3: Space = routine_118(c, &(v1151_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1147_2), &(v1150_3_tail).make_space());
                  drop(v1151_2);
                  v1150_3.join_into((v1151_3).clone());
                  }
                  v1150_3_cursor.ascend(1);
                }
                drop(v1150_3_cursor);
                drop(v1150_2);
                v1149_3.join_into((v1150_3).clone());
                }
                v1149_3_cursor.ascend(1);
              }
              drop(v1149_3_cursor);
              drop(v1149_2);
              v1148_2.join_into((v1149_3).clone());
              }
              v1148_2_cursor.ascend(1);
            }
            drop(v1148_2_cursor);
            v1147_3.join_into((v1148_2).clone());
            }
            v1147_3_cursor.ascend(1);
          }
          drop(v1147_3_cursor);
          drop(v1147_2);
          v1146_3.join_into((v1147_3).clone());
          }
          v1146_3_cursor.ascend(1);
        }
        drop(v1146_3_cursor);
        drop(v1146_2);
        v1145_3.join_into((v1146_3).clone());
        }
        v1145_3_cursor.ascend(1);
      }
      drop(v1145_3_cursor);
      drop(v1145_2);
      v1144_2.join_into((v1145_3).clone());
      }
      v1144_2_cursor.ascend(1);
    }
    drop(v1144_2_cursor);
    v1143_10.join_into((v1144_2).clone());
    }
    v1143_10_cursor.ascend(1);
  }
  drop(v1143_10_cursor);
  (v1143_10).clone()
}

fn routine_103(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1152_10 = Space::new();
  let mut v1152_10_cursor = (*s0).read_zipper();
  for v1152_10_byte in v1152_10_cursor.child_mask().iter() {
    v1152_10_cursor.descend_to_byte(v1152_10_byte);
    {
    let v1152_10_tail = v1152_10_cursor.fork_read_zipper();
    let v1152_10_head = Path::from_slice(&[v1152_10_byte]);
    let mut v1153_2 = Space::new();
    let mut v1153_2_cursor = (v1152_10_tail).read_zipper();
    for v1153_2_byte in v1153_2_cursor.child_mask().iter() {
      v1153_2_cursor.descend_to_byte(v1153_2_byte);
      {
      let v1153_2_tail = v1153_2_cursor.fork_read_zipper();
      let v1153_2_head = Path::from_slice(&[v1153_2_byte]);
      let v1154_2: Path = concat_path(&(v1152_10_head),&(v1153_2_head));
      let mut v1154_3 = Space::new();
      let mut v1154_3_cursor = (v1153_2_tail).read_zipper();
      for v1154_3_byte in v1154_3_cursor.child_mask().iter() {
        v1154_3_cursor.descend_to_byte(v1154_3_byte);
        {
        let v1154_3_tail = v1154_3_cursor.fork_read_zipper();
        let v1154_3_head = Path::from_slice(&[v1154_3_byte]);
        let v1155_2: Path = concat_path(&(v1154_2),&(v1154_3_head));
        let mut v1155_3 = Space::new();
        let mut v1155_3_cursor = (v1154_3_tail).read_zipper();
        for v1155_3_byte in v1155_3_cursor.child_mask().iter() {
          v1155_3_cursor.descend_to_byte(v1155_3_byte);
          {
          let v1155_3_tail = v1155_3_cursor.fork_read_zipper();
          let v1155_3_head = Path::from_slice(&[v1155_3_byte]);
          let v1156_2: Path = concat_path(&(v1155_2),&(v1155_3_head));
          let mut v1156_3 = Space::new();
          let mut v1156_3_cursor = (v1155_3_tail).read_zipper();
          for v1156_3_byte in v1156_3_cursor.child_mask().iter() {
            v1156_3_cursor.descend_to_byte(v1156_3_byte);
            {
            let v1156_3_tail = v1156_3_cursor.fork_read_zipper();
            let v1156_3_head = Path::from_slice(&[v1156_3_byte]);
            let mut v1157_2 = Space::new();
            let mut v1157_2_cursor = (v1156_3_tail).read_zipper();
            for v1157_2_byte in v1157_2_cursor.child_mask().iter() {
              v1157_2_cursor.descend_to_byte(v1157_2_byte);
              {
              let v1157_2_tail = v1157_2_cursor.fork_read_zipper();
              let v1157_2_head = Path::from_slice(&[v1157_2_byte]);
              let v1158_2: Path = concat_path(&(v1156_3_head),&(v1157_2_head));
              let mut v1158_3 = Space::new();
              let mut v1158_3_cursor = (v1157_2_tail).read_zipper();
              for v1158_3_byte in v1158_3_cursor.child_mask().iter() {
                v1158_3_cursor.descend_to_byte(v1158_3_byte);
                {
                let v1158_3_tail = v1158_3_cursor.fork_read_zipper();
                let v1158_3_head = Path::from_slice(&[v1158_3_byte]);
                let v1159_2: Path = concat_path(&(v1158_2),&(v1158_3_head));
                let mut v1159_3 = Space::new();
                let mut v1159_3_cursor = (v1158_3_tail).read_zipper();
                for v1159_3_byte in v1159_3_cursor.child_mask().iter() {
                  v1159_3_cursor.descend_to_byte(v1159_3_byte);
                  {
                  let v1159_3_tail = v1159_3_cursor.fork_read_zipper();
                  let v1159_3_head = Path::from_slice(&[v1159_3_byte]);
                  let v1160_2: Path = concat_path(&(v1159_2),&(v1159_3_head));
                  let v1160_3: Space = routine_119(c, &(v1160_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1156_2), &(v1159_3_tail).make_space());
                  drop(v1160_2);
                  v1159_3.join_into((v1160_3).clone());
                  }
                  v1159_3_cursor.ascend(1);
                }
                drop(v1159_3_cursor);
                drop(v1159_2);
                v1158_3.join_into((v1159_3).clone());
                }
                v1158_3_cursor.ascend(1);
              }
              drop(v1158_3_cursor);
              drop(v1158_2);
              v1157_2.join_into((v1158_3).clone());
              }
              v1157_2_cursor.ascend(1);
            }
            drop(v1157_2_cursor);
            v1156_3.join_into((v1157_2).clone());
            }
            v1156_3_cursor.ascend(1);
          }
          drop(v1156_3_cursor);
          drop(v1156_2);
          v1155_3.join_into((v1156_3).clone());
          }
          v1155_3_cursor.ascend(1);
        }
        drop(v1155_3_cursor);
        drop(v1155_2);
        v1154_3.join_into((v1155_3).clone());
        }
        v1154_3_cursor.ascend(1);
      }
      drop(v1154_3_cursor);
      drop(v1154_2);
      v1153_2.join_into((v1154_3).clone());
      }
      v1153_2_cursor.ascend(1);
    }
    drop(v1153_2_cursor);
    v1152_10.join_into((v1153_2).clone());
    }
    v1152_10_cursor.ascend(1);
  }
  drop(v1152_10_cursor);
  (v1152_10).clone()
}

fn routine_104(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1161_10 = Space::new();
  let mut v1161_10_cursor = (*s0).read_zipper();
  for v1161_10_byte in v1161_10_cursor.child_mask().iter() {
    v1161_10_cursor.descend_to_byte(v1161_10_byte);
    {
    let v1161_10_tail = v1161_10_cursor.fork_read_zipper();
    let v1161_10_head = Path::from_slice(&[v1161_10_byte]);
    let mut v1162_2 = Space::new();
    let mut v1162_2_cursor = (v1161_10_tail).read_zipper();
    for v1162_2_byte in v1162_2_cursor.child_mask().iter() {
      v1162_2_cursor.descend_to_byte(v1162_2_byte);
      {
      let v1162_2_tail = v1162_2_cursor.fork_read_zipper();
      let v1162_2_head = Path::from_slice(&[v1162_2_byte]);
      let v1163_2: Path = concat_path(&(v1161_10_head),&(v1162_2_head));
      let mut v1163_3 = Space::new();
      let mut v1163_3_cursor = (v1162_2_tail).read_zipper();
      for v1163_3_byte in v1163_3_cursor.child_mask().iter() {
        v1163_3_cursor.descend_to_byte(v1163_3_byte);
        {
        let v1163_3_tail = v1163_3_cursor.fork_read_zipper();
        let v1163_3_head = Path::from_slice(&[v1163_3_byte]);
        let v1164_2: Path = concat_path(&(v1163_2),&(v1163_3_head));
        let mut v1164_3 = Space::new();
        let mut v1164_3_cursor = (v1163_3_tail).read_zipper();
        for v1164_3_byte in v1164_3_cursor.child_mask().iter() {
          v1164_3_cursor.descend_to_byte(v1164_3_byte);
          {
          let v1164_3_tail = v1164_3_cursor.fork_read_zipper();
          let v1164_3_head = Path::from_slice(&[v1164_3_byte]);
          let v1165_2: Path = concat_path(&(v1164_2),&(v1164_3_head));
          let mut v1165_3 = Space::new();
          let mut v1165_3_cursor = (v1164_3_tail).read_zipper();
          for v1165_3_byte in v1165_3_cursor.child_mask().iter() {
            v1165_3_cursor.descend_to_byte(v1165_3_byte);
            {
            let v1165_3_tail = v1165_3_cursor.fork_read_zipper();
            let v1165_3_head = Path::from_slice(&[v1165_3_byte]);
            let mut v1166_2 = Space::new();
            let mut v1166_2_cursor = (v1165_3_tail).read_zipper();
            for v1166_2_byte in v1166_2_cursor.child_mask().iter() {
              v1166_2_cursor.descend_to_byte(v1166_2_byte);
              {
              let v1166_2_tail = v1166_2_cursor.fork_read_zipper();
              let v1166_2_head = Path::from_slice(&[v1166_2_byte]);
              let v1167_2: Path = concat_path(&(v1165_3_head),&(v1166_2_head));
              let mut v1167_3 = Space::new();
              let mut v1167_3_cursor = (v1166_2_tail).read_zipper();
              for v1167_3_byte in v1167_3_cursor.child_mask().iter() {
                v1167_3_cursor.descend_to_byte(v1167_3_byte);
                {
                let v1167_3_tail = v1167_3_cursor.fork_read_zipper();
                let v1167_3_head = Path::from_slice(&[v1167_3_byte]);
                let v1168_2: Path = concat_path(&(v1167_2),&(v1167_3_head));
                let mut v1168_3 = Space::new();
                let mut v1168_3_cursor = (v1167_3_tail).read_zipper();
                for v1168_3_byte in v1168_3_cursor.child_mask().iter() {
                  v1168_3_cursor.descend_to_byte(v1168_3_byte);
                  {
                  let v1168_3_tail = v1168_3_cursor.fork_read_zipper();
                  let v1168_3_head = Path::from_slice(&[v1168_3_byte]);
                  let v1169_2: Path = concat_path(&(v1168_2),&(v1168_3_head));
                  let v1169_3: Space = routine_120(c, &(v1169_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1165_2), &(v1168_3_tail).make_space());
                  drop(v1169_2);
                  v1168_3.join_into((v1169_3).clone());
                  }
                  v1168_3_cursor.ascend(1);
                }
                drop(v1168_3_cursor);
                drop(v1168_2);
                v1167_3.join_into((v1168_3).clone());
                }
                v1167_3_cursor.ascend(1);
              }
              drop(v1167_3_cursor);
              drop(v1167_2);
              v1166_2.join_into((v1167_3).clone());
              }
              v1166_2_cursor.ascend(1);
            }
            drop(v1166_2_cursor);
            v1165_3.join_into((v1166_2).clone());
            }
            v1165_3_cursor.ascend(1);
          }
          drop(v1165_3_cursor);
          drop(v1165_2);
          v1164_3.join_into((v1165_3).clone());
          }
          v1164_3_cursor.ascend(1);
        }
        drop(v1164_3_cursor);
        drop(v1164_2);
        v1163_3.join_into((v1164_3).clone());
        }
        v1163_3_cursor.ascend(1);
      }
      drop(v1163_3_cursor);
      drop(v1163_2);
      v1162_2.join_into((v1163_3).clone());
      }
      v1162_2_cursor.ascend(1);
    }
    drop(v1162_2_cursor);
    v1161_10.join_into((v1162_2).clone());
    }
    v1161_10_cursor.ascend(1);
  }
  drop(v1161_10_cursor);
  (v1161_10).clone()
}

fn routine_105(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1170_10 = Space::new();
  let mut v1170_10_cursor = (*s0).read_zipper();
  for v1170_10_byte in v1170_10_cursor.child_mask().iter() {
    v1170_10_cursor.descend_to_byte(v1170_10_byte);
    {
    let v1170_10_tail = v1170_10_cursor.fork_read_zipper();
    let v1170_10_head = Path::from_slice(&[v1170_10_byte]);
    let mut v1171_2 = Space::new();
    let mut v1171_2_cursor = (v1170_10_tail).read_zipper();
    for v1171_2_byte in v1171_2_cursor.child_mask().iter() {
      v1171_2_cursor.descend_to_byte(v1171_2_byte);
      {
      let v1171_2_tail = v1171_2_cursor.fork_read_zipper();
      let v1171_2_head = Path::from_slice(&[v1171_2_byte]);
      let v1172_2: Path = concat_path(&(v1170_10_head),&(v1171_2_head));
      let mut v1172_3 = Space::new();
      let mut v1172_3_cursor = (v1171_2_tail).read_zipper();
      for v1172_3_byte in v1172_3_cursor.child_mask().iter() {
        v1172_3_cursor.descend_to_byte(v1172_3_byte);
        {
        let v1172_3_tail = v1172_3_cursor.fork_read_zipper();
        let v1172_3_head = Path::from_slice(&[v1172_3_byte]);
        let v1173_2: Path = concat_path(&(v1172_2),&(v1172_3_head));
        let mut v1173_3 = Space::new();
        let mut v1173_3_cursor = (v1172_3_tail).read_zipper();
        for v1173_3_byte in v1173_3_cursor.child_mask().iter() {
          v1173_3_cursor.descend_to_byte(v1173_3_byte);
          {
          let v1173_3_tail = v1173_3_cursor.fork_read_zipper();
          let v1173_3_head = Path::from_slice(&[v1173_3_byte]);
          let v1174_2: Path = concat_path(&(v1173_2),&(v1173_3_head));
          let mut v1174_3 = Space::new();
          let mut v1174_3_cursor = (v1173_3_tail).read_zipper();
          for v1174_3_byte in v1174_3_cursor.child_mask().iter() {
            v1174_3_cursor.descend_to_byte(v1174_3_byte);
            {
            let v1174_3_tail = v1174_3_cursor.fork_read_zipper();
            let v1174_3_head = Path::from_slice(&[v1174_3_byte]);
            let mut v1175_2 = Space::new();
            let mut v1175_2_cursor = (v1174_3_tail).read_zipper();
            for v1175_2_byte in v1175_2_cursor.child_mask().iter() {
              v1175_2_cursor.descend_to_byte(v1175_2_byte);
              {
              let v1175_2_tail = v1175_2_cursor.fork_read_zipper();
              let v1175_2_head = Path::from_slice(&[v1175_2_byte]);
              let v1176_2: Path = concat_path(&(v1174_3_head),&(v1175_2_head));
              let mut v1176_3 = Space::new();
              let mut v1176_3_cursor = (v1175_2_tail).read_zipper();
              for v1176_3_byte in v1176_3_cursor.child_mask().iter() {
                v1176_3_cursor.descend_to_byte(v1176_3_byte);
                {
                let v1176_3_tail = v1176_3_cursor.fork_read_zipper();
                let v1176_3_head = Path::from_slice(&[v1176_3_byte]);
                let v1177_2: Path = concat_path(&(v1176_2),&(v1176_3_head));
                let mut v1177_3 = Space::new();
                let mut v1177_3_cursor = (v1176_3_tail).read_zipper();
                for v1177_3_byte in v1177_3_cursor.child_mask().iter() {
                  v1177_3_cursor.descend_to_byte(v1177_3_byte);
                  {
                  let v1177_3_tail = v1177_3_cursor.fork_read_zipper();
                  let v1177_3_head = Path::from_slice(&[v1177_3_byte]);
                  let v1178_2: Path = concat_path(&(v1177_2),&(v1177_3_head));
                  let v1178_3: Space = routine_121(c, &(v1178_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1174_2), &(v1177_3_tail).make_space());
                  drop(v1178_2);
                  v1177_3.join_into((v1178_3).clone());
                  }
                  v1177_3_cursor.ascend(1);
                }
                drop(v1177_3_cursor);
                drop(v1177_2);
                v1176_3.join_into((v1177_3).clone());
                }
                v1176_3_cursor.ascend(1);
              }
              drop(v1176_3_cursor);
              drop(v1176_2);
              v1175_2.join_into((v1176_3).clone());
              }
              v1175_2_cursor.ascend(1);
            }
            drop(v1175_2_cursor);
            v1174_3.join_into((v1175_2).clone());
            }
            v1174_3_cursor.ascend(1);
          }
          drop(v1174_3_cursor);
          drop(v1174_2);
          v1173_3.join_into((v1174_3).clone());
          }
          v1173_3_cursor.ascend(1);
        }
        drop(v1173_3_cursor);
        drop(v1173_2);
        v1172_3.join_into((v1173_3).clone());
        }
        v1172_3_cursor.ascend(1);
      }
      drop(v1172_3_cursor);
      drop(v1172_2);
      v1171_2.join_into((v1172_3).clone());
      }
      v1171_2_cursor.ascend(1);
    }
    drop(v1171_2_cursor);
    v1170_10.join_into((v1171_2).clone());
    }
    v1170_10_cursor.ascend(1);
  }
  drop(v1170_10_cursor);
  (v1170_10).clone()
}

fn routine_106(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1179_10 = Space::new();
  let mut v1179_10_cursor = (*s0).read_zipper();
  for v1179_10_byte in v1179_10_cursor.child_mask().iter() {
    v1179_10_cursor.descend_to_byte(v1179_10_byte);
    {
    let v1179_10_tail = v1179_10_cursor.fork_read_zipper();
    let v1179_10_head = Path::from_slice(&[v1179_10_byte]);
    let mut v1180_2 = Space::new();
    let mut v1180_2_cursor = (v1179_10_tail).read_zipper();
    for v1180_2_byte in v1180_2_cursor.child_mask().iter() {
      v1180_2_cursor.descend_to_byte(v1180_2_byte);
      {
      let v1180_2_tail = v1180_2_cursor.fork_read_zipper();
      let v1180_2_head = Path::from_slice(&[v1180_2_byte]);
      let v1181_2: Path = concat_path(&(v1179_10_head),&(v1180_2_head));
      let mut v1181_3 = Space::new();
      let mut v1181_3_cursor = (v1180_2_tail).read_zipper();
      for v1181_3_byte in v1181_3_cursor.child_mask().iter() {
        v1181_3_cursor.descend_to_byte(v1181_3_byte);
        {
        let v1181_3_tail = v1181_3_cursor.fork_read_zipper();
        let v1181_3_head = Path::from_slice(&[v1181_3_byte]);
        let v1182_2: Path = concat_path(&(v1181_2),&(v1181_3_head));
        let mut v1182_3 = Space::new();
        let mut v1182_3_cursor = (v1181_3_tail).read_zipper();
        for v1182_3_byte in v1182_3_cursor.child_mask().iter() {
          v1182_3_cursor.descend_to_byte(v1182_3_byte);
          {
          let v1182_3_tail = v1182_3_cursor.fork_read_zipper();
          let v1182_3_head = Path::from_slice(&[v1182_3_byte]);
          let v1183_2: Path = concat_path(&(v1182_2),&(v1182_3_head));
          let mut v1183_3 = Space::new();
          let mut v1183_3_cursor = (v1182_3_tail).read_zipper();
          for v1183_3_byte in v1183_3_cursor.child_mask().iter() {
            v1183_3_cursor.descend_to_byte(v1183_3_byte);
            {
            let v1183_3_tail = v1183_3_cursor.fork_read_zipper();
            let v1183_3_head = Path::from_slice(&[v1183_3_byte]);
            let mut v1184_2 = Space::new();
            let mut v1184_2_cursor = (v1183_3_tail).read_zipper();
            for v1184_2_byte in v1184_2_cursor.child_mask().iter() {
              v1184_2_cursor.descend_to_byte(v1184_2_byte);
              {
              let v1184_2_tail = v1184_2_cursor.fork_read_zipper();
              let v1184_2_head = Path::from_slice(&[v1184_2_byte]);
              let v1185_2: Path = concat_path(&(v1183_3_head),&(v1184_2_head));
              let mut v1185_3 = Space::new();
              let mut v1185_3_cursor = (v1184_2_tail).read_zipper();
              for v1185_3_byte in v1185_3_cursor.child_mask().iter() {
                v1185_3_cursor.descend_to_byte(v1185_3_byte);
                {
                let v1185_3_tail = v1185_3_cursor.fork_read_zipper();
                let v1185_3_head = Path::from_slice(&[v1185_3_byte]);
                let v1186_2: Path = concat_path(&(v1185_2),&(v1185_3_head));
                let mut v1186_3 = Space::new();
                let mut v1186_3_cursor = (v1185_3_tail).read_zipper();
                for v1186_3_byte in v1186_3_cursor.child_mask().iter() {
                  v1186_3_cursor.descend_to_byte(v1186_3_byte);
                  {
                  let v1186_3_tail = v1186_3_cursor.fork_read_zipper();
                  let v1186_3_head = Path::from_slice(&[v1186_3_byte]);
                  let v1187_2: Path = concat_path(&(v1186_2),&(v1186_3_head));
                  let v1187_3: Space = routine_122(c, &(v1187_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1183_2), &(v1186_3_tail).make_space());
                  drop(v1187_2);
                  v1186_3.join_into((v1187_3).clone());
                  }
                  v1186_3_cursor.ascend(1);
                }
                drop(v1186_3_cursor);
                drop(v1186_2);
                v1185_3.join_into((v1186_3).clone());
                }
                v1185_3_cursor.ascend(1);
              }
              drop(v1185_3_cursor);
              drop(v1185_2);
              v1184_2.join_into((v1185_3).clone());
              }
              v1184_2_cursor.ascend(1);
            }
            drop(v1184_2_cursor);
            v1183_3.join_into((v1184_2).clone());
            }
            v1183_3_cursor.ascend(1);
          }
          drop(v1183_3_cursor);
          drop(v1183_2);
          v1182_3.join_into((v1183_3).clone());
          }
          v1182_3_cursor.ascend(1);
        }
        drop(v1182_3_cursor);
        drop(v1182_2);
        v1181_3.join_into((v1182_3).clone());
        }
        v1181_3_cursor.ascend(1);
      }
      drop(v1181_3_cursor);
      drop(v1181_2);
      v1180_2.join_into((v1181_3).clone());
      }
      v1180_2_cursor.ascend(1);
    }
    drop(v1180_2_cursor);
    v1179_10.join_into((v1180_2).clone());
    }
    v1179_10_cursor.ascend(1);
  }
  drop(v1179_10_cursor);
  (v1179_10).clone()
}

fn routine_107(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1188_10 = Space::new();
  let mut v1188_10_cursor = (*s0).read_zipper();
  for v1188_10_byte in v1188_10_cursor.child_mask().iter() {
    v1188_10_cursor.descend_to_byte(v1188_10_byte);
    {
    let v1188_10_tail = v1188_10_cursor.fork_read_zipper();
    let v1188_10_head = Path::from_slice(&[v1188_10_byte]);
    let mut v1189_2 = Space::new();
    let mut v1189_2_cursor = (v1188_10_tail).read_zipper();
    for v1189_2_byte in v1189_2_cursor.child_mask().iter() {
      v1189_2_cursor.descend_to_byte(v1189_2_byte);
      {
      let v1189_2_tail = v1189_2_cursor.fork_read_zipper();
      let v1189_2_head = Path::from_slice(&[v1189_2_byte]);
      let v1190_2: Path = concat_path(&(v1188_10_head),&(v1189_2_head));
      let mut v1190_3 = Space::new();
      let mut v1190_3_cursor = (v1189_2_tail).read_zipper();
      for v1190_3_byte in v1190_3_cursor.child_mask().iter() {
        v1190_3_cursor.descend_to_byte(v1190_3_byte);
        {
        let v1190_3_tail = v1190_3_cursor.fork_read_zipper();
        let v1190_3_head = Path::from_slice(&[v1190_3_byte]);
        let v1191_2: Path = concat_path(&(v1190_2),&(v1190_3_head));
        let mut v1191_3 = Space::new();
        let mut v1191_3_cursor = (v1190_3_tail).read_zipper();
        for v1191_3_byte in v1191_3_cursor.child_mask().iter() {
          v1191_3_cursor.descend_to_byte(v1191_3_byte);
          {
          let v1191_3_tail = v1191_3_cursor.fork_read_zipper();
          let v1191_3_head = Path::from_slice(&[v1191_3_byte]);
          let v1192_2: Path = concat_path(&(v1191_2),&(v1191_3_head));
          let mut v1192_3 = Space::new();
          let mut v1192_3_cursor = (v1191_3_tail).read_zipper();
          for v1192_3_byte in v1192_3_cursor.child_mask().iter() {
            v1192_3_cursor.descend_to_byte(v1192_3_byte);
            {
            let v1192_3_tail = v1192_3_cursor.fork_read_zipper();
            let v1192_3_head = Path::from_slice(&[v1192_3_byte]);
            let mut v1193_2 = Space::new();
            let mut v1193_2_cursor = (v1192_3_tail).read_zipper();
            for v1193_2_byte in v1193_2_cursor.child_mask().iter() {
              v1193_2_cursor.descend_to_byte(v1193_2_byte);
              {
              let v1193_2_tail = v1193_2_cursor.fork_read_zipper();
              let v1193_2_head = Path::from_slice(&[v1193_2_byte]);
              let v1194_2: Path = concat_path(&(v1192_3_head),&(v1193_2_head));
              let mut v1194_3 = Space::new();
              let mut v1194_3_cursor = (v1193_2_tail).read_zipper();
              for v1194_3_byte in v1194_3_cursor.child_mask().iter() {
                v1194_3_cursor.descend_to_byte(v1194_3_byte);
                {
                let v1194_3_tail = v1194_3_cursor.fork_read_zipper();
                let v1194_3_head = Path::from_slice(&[v1194_3_byte]);
                let v1195_2: Path = concat_path(&(v1194_2),&(v1194_3_head));
                let mut v1195_3 = Space::new();
                let mut v1195_3_cursor = (v1194_3_tail).read_zipper();
                for v1195_3_byte in v1195_3_cursor.child_mask().iter() {
                  v1195_3_cursor.descend_to_byte(v1195_3_byte);
                  {
                  let v1195_3_tail = v1195_3_cursor.fork_read_zipper();
                  let v1195_3_head = Path::from_slice(&[v1195_3_byte]);
                  let v1196_2: Path = concat_path(&(v1195_2),&(v1195_3_head));
                  let v1196_3: Space = routine_123(c, &(v1196_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1192_2), &(v1195_3_tail).make_space());
                  drop(v1196_2);
                  v1195_3.join_into((v1196_3).clone());
                  }
                  v1195_3_cursor.ascend(1);
                }
                drop(v1195_3_cursor);
                drop(v1195_2);
                v1194_3.join_into((v1195_3).clone());
                }
                v1194_3_cursor.ascend(1);
              }
              drop(v1194_3_cursor);
              drop(v1194_2);
              v1193_2.join_into((v1194_3).clone());
              }
              v1193_2_cursor.ascend(1);
            }
            drop(v1193_2_cursor);
            v1192_3.join_into((v1193_2).clone());
            }
            v1192_3_cursor.ascend(1);
          }
          drop(v1192_3_cursor);
          drop(v1192_2);
          v1191_3.join_into((v1192_3).clone());
          }
          v1191_3_cursor.ascend(1);
        }
        drop(v1191_3_cursor);
        drop(v1191_2);
        v1190_3.join_into((v1191_3).clone());
        }
        v1190_3_cursor.ascend(1);
      }
      drop(v1190_3_cursor);
      drop(v1190_2);
      v1189_2.join_into((v1190_3).clone());
      }
      v1189_2_cursor.ascend(1);
    }
    drop(v1189_2_cursor);
    v1188_10.join_into((v1189_2).clone());
    }
    v1188_10_cursor.ascend(1);
  }
  drop(v1188_10_cursor);
  (v1188_10).clone()
}

fn routine_108(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1197_10 = Space::new();
  let mut v1197_10_cursor = (*s0).read_zipper();
  for v1197_10_byte in v1197_10_cursor.child_mask().iter() {
    v1197_10_cursor.descend_to_byte(v1197_10_byte);
    {
    let v1197_10_tail = v1197_10_cursor.fork_read_zipper();
    let v1197_10_head = Path::from_slice(&[v1197_10_byte]);
    let mut v1198_2 = Space::new();
    let mut v1198_2_cursor = (v1197_10_tail).read_zipper();
    for v1198_2_byte in v1198_2_cursor.child_mask().iter() {
      v1198_2_cursor.descend_to_byte(v1198_2_byte);
      {
      let v1198_2_tail = v1198_2_cursor.fork_read_zipper();
      let v1198_2_head = Path::from_slice(&[v1198_2_byte]);
      let v1199_2: Path = concat_path(&(v1197_10_head),&(v1198_2_head));
      let mut v1199_3 = Space::new();
      let mut v1199_3_cursor = (v1198_2_tail).read_zipper();
      for v1199_3_byte in v1199_3_cursor.child_mask().iter() {
        v1199_3_cursor.descend_to_byte(v1199_3_byte);
        {
        let v1199_3_tail = v1199_3_cursor.fork_read_zipper();
        let v1199_3_head = Path::from_slice(&[v1199_3_byte]);
        let v1200_2: Path = concat_path(&(v1199_2),&(v1199_3_head));
        let mut v1200_3 = Space::new();
        let mut v1200_3_cursor = (v1199_3_tail).read_zipper();
        for v1200_3_byte in v1200_3_cursor.child_mask().iter() {
          v1200_3_cursor.descend_to_byte(v1200_3_byte);
          {
          let v1200_3_tail = v1200_3_cursor.fork_read_zipper();
          let v1200_3_head = Path::from_slice(&[v1200_3_byte]);
          let v1201_2: Path = concat_path(&(v1200_2),&(v1200_3_head));
          let mut v1201_3 = Space::new();
          let mut v1201_3_cursor = (v1200_3_tail).read_zipper();
          for v1201_3_byte in v1201_3_cursor.child_mask().iter() {
            v1201_3_cursor.descend_to_byte(v1201_3_byte);
            {
            let v1201_3_tail = v1201_3_cursor.fork_read_zipper();
            let v1201_3_head = Path::from_slice(&[v1201_3_byte]);
            let mut v1202_2 = Space::new();
            let mut v1202_2_cursor = (v1201_3_tail).read_zipper();
            for v1202_2_byte in v1202_2_cursor.child_mask().iter() {
              v1202_2_cursor.descend_to_byte(v1202_2_byte);
              {
              let v1202_2_tail = v1202_2_cursor.fork_read_zipper();
              let v1202_2_head = Path::from_slice(&[v1202_2_byte]);
              let v1203_2: Path = concat_path(&(v1201_3_head),&(v1202_2_head));
              let mut v1203_3 = Space::new();
              let mut v1203_3_cursor = (v1202_2_tail).read_zipper();
              for v1203_3_byte in v1203_3_cursor.child_mask().iter() {
                v1203_3_cursor.descend_to_byte(v1203_3_byte);
                {
                let v1203_3_tail = v1203_3_cursor.fork_read_zipper();
                let v1203_3_head = Path::from_slice(&[v1203_3_byte]);
                let v1204_2: Path = concat_path(&(v1203_2),&(v1203_3_head));
                let mut v1204_3 = Space::new();
                let mut v1204_3_cursor = (v1203_3_tail).read_zipper();
                for v1204_3_byte in v1204_3_cursor.child_mask().iter() {
                  v1204_3_cursor.descend_to_byte(v1204_3_byte);
                  {
                  let v1204_3_tail = v1204_3_cursor.fork_read_zipper();
                  let v1204_3_head = Path::from_slice(&[v1204_3_byte]);
                  let v1205_2: Path = concat_path(&(v1204_2),&(v1204_3_head));
                  let v1205_3: Space = routine_124(c, &(v1205_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1201_2), &(v1204_3_tail).make_space());
                  drop(v1205_2);
                  v1204_3.join_into((v1205_3).clone());
                  }
                  v1204_3_cursor.ascend(1);
                }
                drop(v1204_3_cursor);
                drop(v1204_2);
                v1203_3.join_into((v1204_3).clone());
                }
                v1203_3_cursor.ascend(1);
              }
              drop(v1203_3_cursor);
              drop(v1203_2);
              v1202_2.join_into((v1203_3).clone());
              }
              v1202_2_cursor.ascend(1);
            }
            drop(v1202_2_cursor);
            v1201_3.join_into((v1202_2).clone());
            }
            v1201_3_cursor.ascend(1);
          }
          drop(v1201_3_cursor);
          drop(v1201_2);
          v1200_3.join_into((v1201_3).clone());
          }
          v1200_3_cursor.ascend(1);
        }
        drop(v1200_3_cursor);
        drop(v1200_2);
        v1199_3.join_into((v1200_3).clone());
        }
        v1199_3_cursor.ascend(1);
      }
      drop(v1199_3_cursor);
      drop(v1199_2);
      v1198_2.join_into((v1199_3).clone());
      }
      v1198_2_cursor.ascend(1);
    }
    drop(v1198_2_cursor);
    v1197_10.join_into((v1198_2).clone());
    }
    v1197_10_cursor.ascend(1);
  }
  drop(v1197_10_cursor);
  (v1197_10).clone()
}

fn routine_109(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1206_10 = Space::new();
  let mut v1206_10_cursor = (*s0).read_zipper();
  for v1206_10_byte in v1206_10_cursor.child_mask().iter() {
    v1206_10_cursor.descend_to_byte(v1206_10_byte);
    {
    let v1206_10_tail = v1206_10_cursor.fork_read_zipper();
    let v1206_10_head = Path::from_slice(&[v1206_10_byte]);
    let mut v1207_2 = Space::new();
    let mut v1207_2_cursor = (v1206_10_tail).read_zipper();
    for v1207_2_byte in v1207_2_cursor.child_mask().iter() {
      v1207_2_cursor.descend_to_byte(v1207_2_byte);
      {
      let v1207_2_tail = v1207_2_cursor.fork_read_zipper();
      let v1207_2_head = Path::from_slice(&[v1207_2_byte]);
      let v1208_2: Path = concat_path(&(v1206_10_head),&(v1207_2_head));
      let mut v1208_3 = Space::new();
      let mut v1208_3_cursor = (v1207_2_tail).read_zipper();
      for v1208_3_byte in v1208_3_cursor.child_mask().iter() {
        v1208_3_cursor.descend_to_byte(v1208_3_byte);
        {
        let v1208_3_tail = v1208_3_cursor.fork_read_zipper();
        let v1208_3_head = Path::from_slice(&[v1208_3_byte]);
        let v1209_2: Path = concat_path(&(v1208_2),&(v1208_3_head));
        let mut v1209_3 = Space::new();
        let mut v1209_3_cursor = (v1208_3_tail).read_zipper();
        for v1209_3_byte in v1209_3_cursor.child_mask().iter() {
          v1209_3_cursor.descend_to_byte(v1209_3_byte);
          {
          let v1209_3_tail = v1209_3_cursor.fork_read_zipper();
          let v1209_3_head = Path::from_slice(&[v1209_3_byte]);
          let v1210_2: Path = concat_path(&(v1209_2),&(v1209_3_head));
          let mut v1210_3 = Space::new();
          let mut v1210_3_cursor = (v1209_3_tail).read_zipper();
          for v1210_3_byte in v1210_3_cursor.child_mask().iter() {
            v1210_3_cursor.descend_to_byte(v1210_3_byte);
            {
            let v1210_3_tail = v1210_3_cursor.fork_read_zipper();
            let v1210_3_head = Path::from_slice(&[v1210_3_byte]);
            let mut v1211_2 = Space::new();
            let mut v1211_2_cursor = (v1210_3_tail).read_zipper();
            for v1211_2_byte in v1211_2_cursor.child_mask().iter() {
              v1211_2_cursor.descend_to_byte(v1211_2_byte);
              {
              let v1211_2_tail = v1211_2_cursor.fork_read_zipper();
              let v1211_2_head = Path::from_slice(&[v1211_2_byte]);
              let v1212_2: Path = concat_path(&(v1210_3_head),&(v1211_2_head));
              let mut v1212_3 = Space::new();
              let mut v1212_3_cursor = (v1211_2_tail).read_zipper();
              for v1212_3_byte in v1212_3_cursor.child_mask().iter() {
                v1212_3_cursor.descend_to_byte(v1212_3_byte);
                {
                let v1212_3_tail = v1212_3_cursor.fork_read_zipper();
                let v1212_3_head = Path::from_slice(&[v1212_3_byte]);
                let v1213_2: Path = concat_path(&(v1212_2),&(v1212_3_head));
                let mut v1213_3 = Space::new();
                let mut v1213_3_cursor = (v1212_3_tail).read_zipper();
                for v1213_3_byte in v1213_3_cursor.child_mask().iter() {
                  v1213_3_cursor.descend_to_byte(v1213_3_byte);
                  {
                  let v1213_3_tail = v1213_3_cursor.fork_read_zipper();
                  let v1213_3_head = Path::from_slice(&[v1213_3_byte]);
                  let v1214_2: Path = concat_path(&(v1213_2),&(v1213_3_head));
                  let v1214_3: Space = routine_125(c, &(v1214_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1210_2), &(v1213_3_tail).make_space());
                  drop(v1214_2);
                  v1213_3.join_into((v1214_3).clone());
                  }
                  v1213_3_cursor.ascend(1);
                }
                drop(v1213_3_cursor);
                drop(v1213_2);
                v1212_3.join_into((v1213_3).clone());
                }
                v1212_3_cursor.ascend(1);
              }
              drop(v1212_3_cursor);
              drop(v1212_2);
              v1211_2.join_into((v1212_3).clone());
              }
              v1211_2_cursor.ascend(1);
            }
            drop(v1211_2_cursor);
            v1210_3.join_into((v1211_2).clone());
            }
            v1210_3_cursor.ascend(1);
          }
          drop(v1210_3_cursor);
          drop(v1210_2);
          v1209_3.join_into((v1210_3).clone());
          }
          v1209_3_cursor.ascend(1);
        }
        drop(v1209_3_cursor);
        drop(v1209_2);
        v1208_3.join_into((v1209_3).clone());
        }
        v1208_3_cursor.ascend(1);
      }
      drop(v1208_3_cursor);
      drop(v1208_2);
      v1207_2.join_into((v1208_3).clone());
      }
      v1207_2_cursor.ascend(1);
    }
    drop(v1207_2_cursor);
    v1206_10.join_into((v1207_2).clone());
    }
    v1206_10_cursor.ascend(1);
  }
  drop(v1206_10_cursor);
  (v1206_10).clone()
}

fn routine_110(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, s0: &Space) -> Space {
  let mut v1215_10 = Space::new();
  let mut v1215_10_cursor = (*s0).read_zipper();
  for v1215_10_byte in v1215_10_cursor.child_mask().iter() {
    v1215_10_cursor.descend_to_byte(v1215_10_byte);
    {
    let v1215_10_tail = v1215_10_cursor.fork_read_zipper();
    let v1215_10_head = Path::from_slice(&[v1215_10_byte]);
    let mut v1216_2 = Space::new();
    let mut v1216_2_cursor = (v1215_10_tail).read_zipper();
    for v1216_2_byte in v1216_2_cursor.child_mask().iter() {
      v1216_2_cursor.descend_to_byte(v1216_2_byte);
      {
      let v1216_2_tail = v1216_2_cursor.fork_read_zipper();
      let v1216_2_head = Path::from_slice(&[v1216_2_byte]);
      let v1217_2: Path = concat_path(&(v1215_10_head),&(v1216_2_head));
      let mut v1217_3 = Space::new();
      let mut v1217_3_cursor = (v1216_2_tail).read_zipper();
      for v1217_3_byte in v1217_3_cursor.child_mask().iter() {
        v1217_3_cursor.descend_to_byte(v1217_3_byte);
        {
        let v1217_3_tail = v1217_3_cursor.fork_read_zipper();
        let v1217_3_head = Path::from_slice(&[v1217_3_byte]);
        let v1218_2: Path = concat_path(&(v1217_2),&(v1217_3_head));
        let mut v1218_3 = Space::new();
        let mut v1218_3_cursor = (v1217_3_tail).read_zipper();
        for v1218_3_byte in v1218_3_cursor.child_mask().iter() {
          v1218_3_cursor.descend_to_byte(v1218_3_byte);
          {
          let v1218_3_tail = v1218_3_cursor.fork_read_zipper();
          let v1218_3_head = Path::from_slice(&[v1218_3_byte]);
          let v1219_2: Path = concat_path(&(v1218_2),&(v1218_3_head));
          let mut v1219_3 = Space::new();
          let mut v1219_3_cursor = (v1218_3_tail).read_zipper();
          for v1219_3_byte in v1219_3_cursor.child_mask().iter() {
            v1219_3_cursor.descend_to_byte(v1219_3_byte);
            {
            let v1219_3_tail = v1219_3_cursor.fork_read_zipper();
            let v1219_3_head = Path::from_slice(&[v1219_3_byte]);
            let mut v1220_2 = Space::new();
            let mut v1220_2_cursor = (v1219_3_tail).read_zipper();
            for v1220_2_byte in v1220_2_cursor.child_mask().iter() {
              v1220_2_cursor.descend_to_byte(v1220_2_byte);
              {
              let v1220_2_tail = v1220_2_cursor.fork_read_zipper();
              let v1220_2_head = Path::from_slice(&[v1220_2_byte]);
              let v1221_2: Path = concat_path(&(v1219_3_head),&(v1220_2_head));
              let mut v1221_3 = Space::new();
              let mut v1221_3_cursor = (v1220_2_tail).read_zipper();
              for v1221_3_byte in v1221_3_cursor.child_mask().iter() {
                v1221_3_cursor.descend_to_byte(v1221_3_byte);
                {
                let v1221_3_tail = v1221_3_cursor.fork_read_zipper();
                let v1221_3_head = Path::from_slice(&[v1221_3_byte]);
                let v1222_2: Path = concat_path(&(v1221_2),&(v1221_3_head));
                let mut v1222_3 = Space::new();
                let mut v1222_3_cursor = (v1221_3_tail).read_zipper();
                for v1222_3_byte in v1222_3_cursor.child_mask().iter() {
                  v1222_3_cursor.descend_to_byte(v1222_3_byte);
                  {
                  let v1222_3_tail = v1222_3_cursor.fork_read_zipper();
                  let v1222_3_head = Path::from_slice(&[v1222_3_byte]);
                  let v1223_2: Path = concat_path(&(v1222_2),&(v1222_3_head));
                  let v1223_3: Space = routine_126(c, &(v1223_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p0), &(v1219_2), &(v1222_3_tail).make_space());
                  drop(v1223_2);
                  v1222_3.join_into((v1223_3).clone());
                  }
                  v1222_3_cursor.ascend(1);
                }
                drop(v1222_3_cursor);
                drop(v1222_2);
                v1221_3.join_into((v1222_3).clone());
                }
                v1221_3_cursor.ascend(1);
              }
              drop(v1221_3_cursor);
              drop(v1221_2);
              v1220_2.join_into((v1221_3).clone());
              }
              v1220_2_cursor.ascend(1);
            }
            drop(v1220_2_cursor);
            v1219_3.join_into((v1220_2).clone());
            }
            v1219_3_cursor.ascend(1);
          }
          drop(v1219_3_cursor);
          drop(v1219_2);
          v1218_3.join_into((v1219_3).clone());
          }
          v1218_3_cursor.ascend(1);
        }
        drop(v1218_3_cursor);
        drop(v1218_2);
        v1217_3.join_into((v1218_3).clone());
        }
        v1217_3_cursor.ascend(1);
      }
      drop(v1217_3_cursor);
      drop(v1217_2);
      v1216_2.join_into((v1217_3).clone());
      }
      v1216_2_cursor.ascend(1);
    }
    drop(v1216_2_cursor);
    v1215_10.join_into((v1216_2).clone());
    }
    v1215_10_cursor.ascend(1);
  }
  drop(v1215_10_cursor);
  (v1215_10).clone()
}

fn routine_111(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1224_12 = Space::new();
  let mut v1224_12_cursor = (*s0).read_zipper();
  for v1224_12_byte in v1224_12_cursor.child_mask().iter() {
    v1224_12_cursor.descend_to_byte(v1224_12_byte);
    {
    let v1224_12_tail = v1224_12_cursor.fork_read_zipper();
    let v1224_12_head = Path::from_slice(&[v1224_12_byte]);
    let mut v1225_2 = Space::new();
    let mut v1225_2_cursor = (v1224_12_tail).read_zipper();
    for v1225_2_byte in v1225_2_cursor.child_mask().iter() {
      v1225_2_cursor.descend_to_byte(v1225_2_byte);
      {
      let v1225_2_tail = v1225_2_cursor.fork_read_zipper();
      let v1225_2_head = Path::from_slice(&[v1225_2_byte]);
      let v1226_2: Path = concat_path(&(v1224_12_head),&(v1225_2_head));
      let mut v1226_3 = Space::new();
      let mut v1226_3_cursor = (v1225_2_tail).read_zipper();
      for v1226_3_byte in v1226_3_cursor.child_mask().iter() {
        v1226_3_cursor.descend_to_byte(v1226_3_byte);
        {
        let v1226_3_tail = v1226_3_cursor.fork_read_zipper();
        let v1226_3_head = Path::from_slice(&[v1226_3_byte]);
        let v1227_2: Path = concat_path(&(v1226_2),&(v1226_3_head));
        let mut v1227_3 = Space::new();
        let mut v1227_3_cursor = (v1226_3_tail).read_zipper();
        for v1227_3_byte in v1227_3_cursor.child_mask().iter() {
          v1227_3_cursor.descend_to_byte(v1227_3_byte);
          {
          let v1227_3_tail = v1227_3_cursor.fork_read_zipper();
          let v1227_3_head = Path::from_slice(&[v1227_3_byte]);
          let v1228_2: Path = concat_path(&(v1227_2),&(v1227_3_head));
          let mut v1228_3 = Space::new();
          let mut v1228_3_cursor = (v1227_3_tail).read_zipper();
          for v1228_3_byte in v1228_3_cursor.child_mask().iter() {
            v1228_3_cursor.descend_to_byte(v1228_3_byte);
            {
            let v1228_3_tail = v1228_3_cursor.fork_read_zipper();
            let v1228_3_head = Path::from_slice(&[v1228_3_byte]);
            let mut v1229_2 = Space::new();
            let mut v1229_2_cursor = (v1228_3_tail).read_zipper();
            for v1229_2_byte in v1229_2_cursor.child_mask().iter() {
              v1229_2_cursor.descend_to_byte(v1229_2_byte);
              {
              let v1229_2_tail = v1229_2_cursor.fork_read_zipper();
              let v1229_2_head = Path::from_slice(&[v1229_2_byte]);
              let v1230_2: Path = concat_path(&(v1228_3_head),&(v1229_2_head));
              let mut v1230_3 = Space::new();
              let mut v1230_3_cursor = (v1229_2_tail).read_zipper();
              for v1230_3_byte in v1230_3_cursor.child_mask().iter() {
                v1230_3_cursor.descend_to_byte(v1230_3_byte);
                {
                let v1230_3_tail = v1230_3_cursor.fork_read_zipper();
                let v1230_3_head = Path::from_slice(&[v1230_3_byte]);
                let v1231_2: Path = concat_path(&(v1230_2),&(v1230_3_head));
                let mut v1231_3 = Space::new();
                let mut v1231_3_cursor = (v1230_3_tail).read_zipper();
                for v1231_3_byte in v1231_3_cursor.child_mask().iter() {
                  v1231_3_cursor.descend_to_byte(v1231_3_byte);
                  {
                  let v1231_3_tail = v1231_3_cursor.fork_read_zipper();
                  let v1231_3_head = Path::from_slice(&[v1231_3_byte]);
                  let v1232_2: Path = concat_path(&(v1231_2),&(v1231_3_head));
                  let v1232_3: Space = routine_127(c, &(v1232_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1228_2), &(v1231_3_tail).make_space());
                  drop(v1232_2);
                  v1231_3.join_into((v1232_3).clone());
                  }
                  v1231_3_cursor.ascend(1);
                }
                drop(v1231_3_cursor);
                drop(v1231_2);
                v1230_3.join_into((v1231_3).clone());
                }
                v1230_3_cursor.ascend(1);
              }
              drop(v1230_3_cursor);
              drop(v1230_2);
              v1229_2.join_into((v1230_3).clone());
              }
              v1229_2_cursor.ascend(1);
            }
            drop(v1229_2_cursor);
            v1228_3.join_into((v1229_2).clone());
            }
            v1228_3_cursor.ascend(1);
          }
          drop(v1228_3_cursor);
          drop(v1228_2);
          v1227_3.join_into((v1228_3).clone());
          }
          v1227_3_cursor.ascend(1);
        }
        drop(v1227_3_cursor);
        drop(v1227_2);
        v1226_3.join_into((v1227_3).clone());
        }
        v1226_3_cursor.ascend(1);
      }
      drop(v1226_3_cursor);
      drop(v1226_2);
      v1225_2.join_into((v1226_3).clone());
      }
      v1225_2_cursor.ascend(1);
    }
    drop(v1225_2_cursor);
    v1224_12.join_into((v1225_2).clone());
    }
    v1224_12_cursor.ascend(1);
  }
  drop(v1224_12_cursor);
  (v1224_12).clone()
}

fn routine_112(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1233_12 = Space::new();
  let mut v1233_12_cursor = (*s0).read_zipper();
  for v1233_12_byte in v1233_12_cursor.child_mask().iter() {
    v1233_12_cursor.descend_to_byte(v1233_12_byte);
    {
    let v1233_12_tail = v1233_12_cursor.fork_read_zipper();
    let v1233_12_head = Path::from_slice(&[v1233_12_byte]);
    let mut v1234_2 = Space::new();
    let mut v1234_2_cursor = (v1233_12_tail).read_zipper();
    for v1234_2_byte in v1234_2_cursor.child_mask().iter() {
      v1234_2_cursor.descend_to_byte(v1234_2_byte);
      {
      let v1234_2_tail = v1234_2_cursor.fork_read_zipper();
      let v1234_2_head = Path::from_slice(&[v1234_2_byte]);
      let v1235_2: Path = concat_path(&(v1233_12_head),&(v1234_2_head));
      let mut v1235_3 = Space::new();
      let mut v1235_3_cursor = (v1234_2_tail).read_zipper();
      for v1235_3_byte in v1235_3_cursor.child_mask().iter() {
        v1235_3_cursor.descend_to_byte(v1235_3_byte);
        {
        let v1235_3_tail = v1235_3_cursor.fork_read_zipper();
        let v1235_3_head = Path::from_slice(&[v1235_3_byte]);
        let v1236_2: Path = concat_path(&(v1235_2),&(v1235_3_head));
        let mut v1236_3 = Space::new();
        let mut v1236_3_cursor = (v1235_3_tail).read_zipper();
        for v1236_3_byte in v1236_3_cursor.child_mask().iter() {
          v1236_3_cursor.descend_to_byte(v1236_3_byte);
          {
          let v1236_3_tail = v1236_3_cursor.fork_read_zipper();
          let v1236_3_head = Path::from_slice(&[v1236_3_byte]);
          let v1237_2: Path = concat_path(&(v1236_2),&(v1236_3_head));
          let mut v1237_3 = Space::new();
          let mut v1237_3_cursor = (v1236_3_tail).read_zipper();
          for v1237_3_byte in v1237_3_cursor.child_mask().iter() {
            v1237_3_cursor.descend_to_byte(v1237_3_byte);
            {
            let v1237_3_tail = v1237_3_cursor.fork_read_zipper();
            let v1237_3_head = Path::from_slice(&[v1237_3_byte]);
            let mut v1238_2 = Space::new();
            let mut v1238_2_cursor = (v1237_3_tail).read_zipper();
            for v1238_2_byte in v1238_2_cursor.child_mask().iter() {
              v1238_2_cursor.descend_to_byte(v1238_2_byte);
              {
              let v1238_2_tail = v1238_2_cursor.fork_read_zipper();
              let v1238_2_head = Path::from_slice(&[v1238_2_byte]);
              let v1239_2: Path = concat_path(&(v1237_3_head),&(v1238_2_head));
              let mut v1239_3 = Space::new();
              let mut v1239_3_cursor = (v1238_2_tail).read_zipper();
              for v1239_3_byte in v1239_3_cursor.child_mask().iter() {
                v1239_3_cursor.descend_to_byte(v1239_3_byte);
                {
                let v1239_3_tail = v1239_3_cursor.fork_read_zipper();
                let v1239_3_head = Path::from_slice(&[v1239_3_byte]);
                let v1240_2: Path = concat_path(&(v1239_2),&(v1239_3_head));
                let mut v1240_3 = Space::new();
                let mut v1240_3_cursor = (v1239_3_tail).read_zipper();
                for v1240_3_byte in v1240_3_cursor.child_mask().iter() {
                  v1240_3_cursor.descend_to_byte(v1240_3_byte);
                  {
                  let v1240_3_tail = v1240_3_cursor.fork_read_zipper();
                  let v1240_3_head = Path::from_slice(&[v1240_3_byte]);
                  let v1241_2: Path = concat_path(&(v1240_2),&(v1240_3_head));
                  let v1241_3: Space = routine_128(c, &(v1241_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1237_2), &(v1240_3_tail).make_space());
                  drop(v1241_2);
                  v1240_3.join_into((v1241_3).clone());
                  }
                  v1240_3_cursor.ascend(1);
                }
                drop(v1240_3_cursor);
                drop(v1240_2);
                v1239_3.join_into((v1240_3).clone());
                }
                v1239_3_cursor.ascend(1);
              }
              drop(v1239_3_cursor);
              drop(v1239_2);
              v1238_2.join_into((v1239_3).clone());
              }
              v1238_2_cursor.ascend(1);
            }
            drop(v1238_2_cursor);
            v1237_3.join_into((v1238_2).clone());
            }
            v1237_3_cursor.ascend(1);
          }
          drop(v1237_3_cursor);
          drop(v1237_2);
          v1236_3.join_into((v1237_3).clone());
          }
          v1236_3_cursor.ascend(1);
        }
        drop(v1236_3_cursor);
        drop(v1236_2);
        v1235_3.join_into((v1236_3).clone());
        }
        v1235_3_cursor.ascend(1);
      }
      drop(v1235_3_cursor);
      drop(v1235_2);
      v1234_2.join_into((v1235_3).clone());
      }
      v1234_2_cursor.ascend(1);
    }
    drop(v1234_2_cursor);
    v1233_12.join_into((v1234_2).clone());
    }
    v1233_12_cursor.ascend(1);
  }
  drop(v1233_12_cursor);
  (v1233_12).clone()
}

fn routine_113(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1242_12 = Space::new();
  let mut v1242_12_cursor = (*s0).read_zipper();
  for v1242_12_byte in v1242_12_cursor.child_mask().iter() {
    v1242_12_cursor.descend_to_byte(v1242_12_byte);
    {
    let v1242_12_tail = v1242_12_cursor.fork_read_zipper();
    let v1242_12_head = Path::from_slice(&[v1242_12_byte]);
    let mut v1243_2 = Space::new();
    let mut v1243_2_cursor = (v1242_12_tail).read_zipper();
    for v1243_2_byte in v1243_2_cursor.child_mask().iter() {
      v1243_2_cursor.descend_to_byte(v1243_2_byte);
      {
      let v1243_2_tail = v1243_2_cursor.fork_read_zipper();
      let v1243_2_head = Path::from_slice(&[v1243_2_byte]);
      let v1244_2: Path = concat_path(&(v1242_12_head),&(v1243_2_head));
      let mut v1244_3 = Space::new();
      let mut v1244_3_cursor = (v1243_2_tail).read_zipper();
      for v1244_3_byte in v1244_3_cursor.child_mask().iter() {
        v1244_3_cursor.descend_to_byte(v1244_3_byte);
        {
        let v1244_3_tail = v1244_3_cursor.fork_read_zipper();
        let v1244_3_head = Path::from_slice(&[v1244_3_byte]);
        let v1245_2: Path = concat_path(&(v1244_2),&(v1244_3_head));
        let mut v1245_3 = Space::new();
        let mut v1245_3_cursor = (v1244_3_tail).read_zipper();
        for v1245_3_byte in v1245_3_cursor.child_mask().iter() {
          v1245_3_cursor.descend_to_byte(v1245_3_byte);
          {
          let v1245_3_tail = v1245_3_cursor.fork_read_zipper();
          let v1245_3_head = Path::from_slice(&[v1245_3_byte]);
          let v1246_2: Path = concat_path(&(v1245_2),&(v1245_3_head));
          let mut v1246_3 = Space::new();
          let mut v1246_3_cursor = (v1245_3_tail).read_zipper();
          for v1246_3_byte in v1246_3_cursor.child_mask().iter() {
            v1246_3_cursor.descend_to_byte(v1246_3_byte);
            {
            let v1246_3_tail = v1246_3_cursor.fork_read_zipper();
            let v1246_3_head = Path::from_slice(&[v1246_3_byte]);
            let mut v1247_2 = Space::new();
            let mut v1247_2_cursor = (v1246_3_tail).read_zipper();
            for v1247_2_byte in v1247_2_cursor.child_mask().iter() {
              v1247_2_cursor.descend_to_byte(v1247_2_byte);
              {
              let v1247_2_tail = v1247_2_cursor.fork_read_zipper();
              let v1247_2_head = Path::from_slice(&[v1247_2_byte]);
              let v1248_2: Path = concat_path(&(v1246_3_head),&(v1247_2_head));
              let mut v1248_3 = Space::new();
              let mut v1248_3_cursor = (v1247_2_tail).read_zipper();
              for v1248_3_byte in v1248_3_cursor.child_mask().iter() {
                v1248_3_cursor.descend_to_byte(v1248_3_byte);
                {
                let v1248_3_tail = v1248_3_cursor.fork_read_zipper();
                let v1248_3_head = Path::from_slice(&[v1248_3_byte]);
                let v1249_2: Path = concat_path(&(v1248_2),&(v1248_3_head));
                let mut v1249_3 = Space::new();
                let mut v1249_3_cursor = (v1248_3_tail).read_zipper();
                for v1249_3_byte in v1249_3_cursor.child_mask().iter() {
                  v1249_3_cursor.descend_to_byte(v1249_3_byte);
                  {
                  let v1249_3_tail = v1249_3_cursor.fork_read_zipper();
                  let v1249_3_head = Path::from_slice(&[v1249_3_byte]);
                  let v1250_2: Path = concat_path(&(v1249_2),&(v1249_3_head));
                  let v1250_3: Space = routine_129(c, &(v1250_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1246_2), &(v1249_3_tail).make_space());
                  drop(v1250_2);
                  v1249_3.join_into((v1250_3).clone());
                  }
                  v1249_3_cursor.ascend(1);
                }
                drop(v1249_3_cursor);
                drop(v1249_2);
                v1248_3.join_into((v1249_3).clone());
                }
                v1248_3_cursor.ascend(1);
              }
              drop(v1248_3_cursor);
              drop(v1248_2);
              v1247_2.join_into((v1248_3).clone());
              }
              v1247_2_cursor.ascend(1);
            }
            drop(v1247_2_cursor);
            v1246_3.join_into((v1247_2).clone());
            }
            v1246_3_cursor.ascend(1);
          }
          drop(v1246_3_cursor);
          drop(v1246_2);
          v1245_3.join_into((v1246_3).clone());
          }
          v1245_3_cursor.ascend(1);
        }
        drop(v1245_3_cursor);
        drop(v1245_2);
        v1244_3.join_into((v1245_3).clone());
        }
        v1244_3_cursor.ascend(1);
      }
      drop(v1244_3_cursor);
      drop(v1244_2);
      v1243_2.join_into((v1244_3).clone());
      }
      v1243_2_cursor.ascend(1);
    }
    drop(v1243_2_cursor);
    v1242_12.join_into((v1243_2).clone());
    }
    v1242_12_cursor.ascend(1);
  }
  drop(v1242_12_cursor);
  (v1242_12).clone()
}

fn routine_114(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1251_12 = Space::new();
  let mut v1251_12_cursor = (*s0).read_zipper();
  for v1251_12_byte in v1251_12_cursor.child_mask().iter() {
    v1251_12_cursor.descend_to_byte(v1251_12_byte);
    {
    let v1251_12_tail = v1251_12_cursor.fork_read_zipper();
    let v1251_12_head = Path::from_slice(&[v1251_12_byte]);
    let mut v1252_2 = Space::new();
    let mut v1252_2_cursor = (v1251_12_tail).read_zipper();
    for v1252_2_byte in v1252_2_cursor.child_mask().iter() {
      v1252_2_cursor.descend_to_byte(v1252_2_byte);
      {
      let v1252_2_tail = v1252_2_cursor.fork_read_zipper();
      let v1252_2_head = Path::from_slice(&[v1252_2_byte]);
      let v1253_2: Path = concat_path(&(v1251_12_head),&(v1252_2_head));
      let mut v1253_3 = Space::new();
      let mut v1253_3_cursor = (v1252_2_tail).read_zipper();
      for v1253_3_byte in v1253_3_cursor.child_mask().iter() {
        v1253_3_cursor.descend_to_byte(v1253_3_byte);
        {
        let v1253_3_tail = v1253_3_cursor.fork_read_zipper();
        let v1253_3_head = Path::from_slice(&[v1253_3_byte]);
        let v1254_2: Path = concat_path(&(v1253_2),&(v1253_3_head));
        let mut v1254_3 = Space::new();
        let mut v1254_3_cursor = (v1253_3_tail).read_zipper();
        for v1254_3_byte in v1254_3_cursor.child_mask().iter() {
          v1254_3_cursor.descend_to_byte(v1254_3_byte);
          {
          let v1254_3_tail = v1254_3_cursor.fork_read_zipper();
          let v1254_3_head = Path::from_slice(&[v1254_3_byte]);
          let v1255_2: Path = concat_path(&(v1254_2),&(v1254_3_head));
          let mut v1255_3 = Space::new();
          let mut v1255_3_cursor = (v1254_3_tail).read_zipper();
          for v1255_3_byte in v1255_3_cursor.child_mask().iter() {
            v1255_3_cursor.descend_to_byte(v1255_3_byte);
            {
            let v1255_3_tail = v1255_3_cursor.fork_read_zipper();
            let v1255_3_head = Path::from_slice(&[v1255_3_byte]);
            let mut v1256_2 = Space::new();
            let mut v1256_2_cursor = (v1255_3_tail).read_zipper();
            for v1256_2_byte in v1256_2_cursor.child_mask().iter() {
              v1256_2_cursor.descend_to_byte(v1256_2_byte);
              {
              let v1256_2_tail = v1256_2_cursor.fork_read_zipper();
              let v1256_2_head = Path::from_slice(&[v1256_2_byte]);
              let v1257_2: Path = concat_path(&(v1255_3_head),&(v1256_2_head));
              let mut v1257_3 = Space::new();
              let mut v1257_3_cursor = (v1256_2_tail).read_zipper();
              for v1257_3_byte in v1257_3_cursor.child_mask().iter() {
                v1257_3_cursor.descend_to_byte(v1257_3_byte);
                {
                let v1257_3_tail = v1257_3_cursor.fork_read_zipper();
                let v1257_3_head = Path::from_slice(&[v1257_3_byte]);
                let v1258_2: Path = concat_path(&(v1257_2),&(v1257_3_head));
                let mut v1258_3 = Space::new();
                let mut v1258_3_cursor = (v1257_3_tail).read_zipper();
                for v1258_3_byte in v1258_3_cursor.child_mask().iter() {
                  v1258_3_cursor.descend_to_byte(v1258_3_byte);
                  {
                  let v1258_3_tail = v1258_3_cursor.fork_read_zipper();
                  let v1258_3_head = Path::from_slice(&[v1258_3_byte]);
                  let v1259_2: Path = concat_path(&(v1258_2),&(v1258_3_head));
                  let v1259_3: Space = routine_130(c, &(v1259_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1255_2), &(v1258_3_tail).make_space());
                  drop(v1259_2);
                  v1258_3.join_into((v1259_3).clone());
                  }
                  v1258_3_cursor.ascend(1);
                }
                drop(v1258_3_cursor);
                drop(v1258_2);
                v1257_3.join_into((v1258_3).clone());
                }
                v1257_3_cursor.ascend(1);
              }
              drop(v1257_3_cursor);
              drop(v1257_2);
              v1256_2.join_into((v1257_3).clone());
              }
              v1256_2_cursor.ascend(1);
            }
            drop(v1256_2_cursor);
            v1255_3.join_into((v1256_2).clone());
            }
            v1255_3_cursor.ascend(1);
          }
          drop(v1255_3_cursor);
          drop(v1255_2);
          v1254_3.join_into((v1255_3).clone());
          }
          v1254_3_cursor.ascend(1);
        }
        drop(v1254_3_cursor);
        drop(v1254_2);
        v1253_3.join_into((v1254_3).clone());
        }
        v1253_3_cursor.ascend(1);
      }
      drop(v1253_3_cursor);
      drop(v1253_2);
      v1252_2.join_into((v1253_3).clone());
      }
      v1252_2_cursor.ascend(1);
    }
    drop(v1252_2_cursor);
    v1251_12.join_into((v1252_2).clone());
    }
    v1251_12_cursor.ascend(1);
  }
  drop(v1251_12_cursor);
  (v1251_12).clone()
}

fn routine_115(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1260_12 = Space::new();
  let mut v1260_12_cursor = (*s0).read_zipper();
  for v1260_12_byte in v1260_12_cursor.child_mask().iter() {
    v1260_12_cursor.descend_to_byte(v1260_12_byte);
    {
    let v1260_12_tail = v1260_12_cursor.fork_read_zipper();
    let v1260_12_head = Path::from_slice(&[v1260_12_byte]);
    let mut v1261_2 = Space::new();
    let mut v1261_2_cursor = (v1260_12_tail).read_zipper();
    for v1261_2_byte in v1261_2_cursor.child_mask().iter() {
      v1261_2_cursor.descend_to_byte(v1261_2_byte);
      {
      let v1261_2_tail = v1261_2_cursor.fork_read_zipper();
      let v1261_2_head = Path::from_slice(&[v1261_2_byte]);
      let v1262_2: Path = concat_path(&(v1260_12_head),&(v1261_2_head));
      let mut v1262_3 = Space::new();
      let mut v1262_3_cursor = (v1261_2_tail).read_zipper();
      for v1262_3_byte in v1262_3_cursor.child_mask().iter() {
        v1262_3_cursor.descend_to_byte(v1262_3_byte);
        {
        let v1262_3_tail = v1262_3_cursor.fork_read_zipper();
        let v1262_3_head = Path::from_slice(&[v1262_3_byte]);
        let v1263_2: Path = concat_path(&(v1262_2),&(v1262_3_head));
        let mut v1263_3 = Space::new();
        let mut v1263_3_cursor = (v1262_3_tail).read_zipper();
        for v1263_3_byte in v1263_3_cursor.child_mask().iter() {
          v1263_3_cursor.descend_to_byte(v1263_3_byte);
          {
          let v1263_3_tail = v1263_3_cursor.fork_read_zipper();
          let v1263_3_head = Path::from_slice(&[v1263_3_byte]);
          let v1264_2: Path = concat_path(&(v1263_2),&(v1263_3_head));
          let mut v1264_3 = Space::new();
          let mut v1264_3_cursor = (v1263_3_tail).read_zipper();
          for v1264_3_byte in v1264_3_cursor.child_mask().iter() {
            v1264_3_cursor.descend_to_byte(v1264_3_byte);
            {
            let v1264_3_tail = v1264_3_cursor.fork_read_zipper();
            let v1264_3_head = Path::from_slice(&[v1264_3_byte]);
            let mut v1265_2 = Space::new();
            let mut v1265_2_cursor = (v1264_3_tail).read_zipper();
            for v1265_2_byte in v1265_2_cursor.child_mask().iter() {
              v1265_2_cursor.descend_to_byte(v1265_2_byte);
              {
              let v1265_2_tail = v1265_2_cursor.fork_read_zipper();
              let v1265_2_head = Path::from_slice(&[v1265_2_byte]);
              let v1266_2: Path = concat_path(&(v1264_3_head),&(v1265_2_head));
              let mut v1266_3 = Space::new();
              let mut v1266_3_cursor = (v1265_2_tail).read_zipper();
              for v1266_3_byte in v1266_3_cursor.child_mask().iter() {
                v1266_3_cursor.descend_to_byte(v1266_3_byte);
                {
                let v1266_3_tail = v1266_3_cursor.fork_read_zipper();
                let v1266_3_head = Path::from_slice(&[v1266_3_byte]);
                let v1267_2: Path = concat_path(&(v1266_2),&(v1266_3_head));
                let mut v1267_3 = Space::new();
                let mut v1267_3_cursor = (v1266_3_tail).read_zipper();
                for v1267_3_byte in v1267_3_cursor.child_mask().iter() {
                  v1267_3_cursor.descend_to_byte(v1267_3_byte);
                  {
                  let v1267_3_tail = v1267_3_cursor.fork_read_zipper();
                  let v1267_3_head = Path::from_slice(&[v1267_3_byte]);
                  let v1268_2: Path = concat_path(&(v1267_2),&(v1267_3_head));
                  let v1268_3: Space = routine_131(c, &(v1268_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1264_2), &(v1267_3_tail).make_space());
                  drop(v1268_2);
                  v1267_3.join_into((v1268_3).clone());
                  }
                  v1267_3_cursor.ascend(1);
                }
                drop(v1267_3_cursor);
                drop(v1267_2);
                v1266_3.join_into((v1267_3).clone());
                }
                v1266_3_cursor.ascend(1);
              }
              drop(v1266_3_cursor);
              drop(v1266_2);
              v1265_2.join_into((v1266_3).clone());
              }
              v1265_2_cursor.ascend(1);
            }
            drop(v1265_2_cursor);
            v1264_3.join_into((v1265_2).clone());
            }
            v1264_3_cursor.ascend(1);
          }
          drop(v1264_3_cursor);
          drop(v1264_2);
          v1263_3.join_into((v1264_3).clone());
          }
          v1263_3_cursor.ascend(1);
        }
        drop(v1263_3_cursor);
        drop(v1263_2);
        v1262_3.join_into((v1263_3).clone());
        }
        v1262_3_cursor.ascend(1);
      }
      drop(v1262_3_cursor);
      drop(v1262_2);
      v1261_2.join_into((v1262_3).clone());
      }
      v1261_2_cursor.ascend(1);
    }
    drop(v1261_2_cursor);
    v1260_12.join_into((v1261_2).clone());
    }
    v1260_12_cursor.ascend(1);
  }
  drop(v1260_12_cursor);
  (v1260_12).clone()
}

fn routine_116(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1269_12 = Space::new();
  let mut v1269_12_cursor = (*s0).read_zipper();
  for v1269_12_byte in v1269_12_cursor.child_mask().iter() {
    v1269_12_cursor.descend_to_byte(v1269_12_byte);
    {
    let v1269_12_tail = v1269_12_cursor.fork_read_zipper();
    let v1269_12_head = Path::from_slice(&[v1269_12_byte]);
    let mut v1270_2 = Space::new();
    let mut v1270_2_cursor = (v1269_12_tail).read_zipper();
    for v1270_2_byte in v1270_2_cursor.child_mask().iter() {
      v1270_2_cursor.descend_to_byte(v1270_2_byte);
      {
      let v1270_2_tail = v1270_2_cursor.fork_read_zipper();
      let v1270_2_head = Path::from_slice(&[v1270_2_byte]);
      let v1271_2: Path = concat_path(&(v1269_12_head),&(v1270_2_head));
      let mut v1271_3 = Space::new();
      let mut v1271_3_cursor = (v1270_2_tail).read_zipper();
      for v1271_3_byte in v1271_3_cursor.child_mask().iter() {
        v1271_3_cursor.descend_to_byte(v1271_3_byte);
        {
        let v1271_3_tail = v1271_3_cursor.fork_read_zipper();
        let v1271_3_head = Path::from_slice(&[v1271_3_byte]);
        let v1272_2: Path = concat_path(&(v1271_2),&(v1271_3_head));
        let mut v1272_3 = Space::new();
        let mut v1272_3_cursor = (v1271_3_tail).read_zipper();
        for v1272_3_byte in v1272_3_cursor.child_mask().iter() {
          v1272_3_cursor.descend_to_byte(v1272_3_byte);
          {
          let v1272_3_tail = v1272_3_cursor.fork_read_zipper();
          let v1272_3_head = Path::from_slice(&[v1272_3_byte]);
          let v1273_2: Path = concat_path(&(v1272_2),&(v1272_3_head));
          let mut v1273_3 = Space::new();
          let mut v1273_3_cursor = (v1272_3_tail).read_zipper();
          for v1273_3_byte in v1273_3_cursor.child_mask().iter() {
            v1273_3_cursor.descend_to_byte(v1273_3_byte);
            {
            let v1273_3_tail = v1273_3_cursor.fork_read_zipper();
            let v1273_3_head = Path::from_slice(&[v1273_3_byte]);
            let mut v1274_2 = Space::new();
            let mut v1274_2_cursor = (v1273_3_tail).read_zipper();
            for v1274_2_byte in v1274_2_cursor.child_mask().iter() {
              v1274_2_cursor.descend_to_byte(v1274_2_byte);
              {
              let v1274_2_tail = v1274_2_cursor.fork_read_zipper();
              let v1274_2_head = Path::from_slice(&[v1274_2_byte]);
              let v1275_2: Path = concat_path(&(v1273_3_head),&(v1274_2_head));
              let mut v1275_3 = Space::new();
              let mut v1275_3_cursor = (v1274_2_tail).read_zipper();
              for v1275_3_byte in v1275_3_cursor.child_mask().iter() {
                v1275_3_cursor.descend_to_byte(v1275_3_byte);
                {
                let v1275_3_tail = v1275_3_cursor.fork_read_zipper();
                let v1275_3_head = Path::from_slice(&[v1275_3_byte]);
                let v1276_2: Path = concat_path(&(v1275_2),&(v1275_3_head));
                let mut v1276_3 = Space::new();
                let mut v1276_3_cursor = (v1275_3_tail).read_zipper();
                for v1276_3_byte in v1276_3_cursor.child_mask().iter() {
                  v1276_3_cursor.descend_to_byte(v1276_3_byte);
                  {
                  let v1276_3_tail = v1276_3_cursor.fork_read_zipper();
                  let v1276_3_head = Path::from_slice(&[v1276_3_byte]);
                  let v1277_2: Path = concat_path(&(v1276_2),&(v1276_3_head));
                  let v1277_3: Space = routine_132(c, &(v1277_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1273_2), &(v1276_3_tail).make_space());
                  drop(v1277_2);
                  v1276_3.join_into((v1277_3).clone());
                  }
                  v1276_3_cursor.ascend(1);
                }
                drop(v1276_3_cursor);
                drop(v1276_2);
                v1275_3.join_into((v1276_3).clone());
                }
                v1275_3_cursor.ascend(1);
              }
              drop(v1275_3_cursor);
              drop(v1275_2);
              v1274_2.join_into((v1275_3).clone());
              }
              v1274_2_cursor.ascend(1);
            }
            drop(v1274_2_cursor);
            v1273_3.join_into((v1274_2).clone());
            }
            v1273_3_cursor.ascend(1);
          }
          drop(v1273_3_cursor);
          drop(v1273_2);
          v1272_3.join_into((v1273_3).clone());
          }
          v1272_3_cursor.ascend(1);
        }
        drop(v1272_3_cursor);
        drop(v1272_2);
        v1271_3.join_into((v1272_3).clone());
        }
        v1271_3_cursor.ascend(1);
      }
      drop(v1271_3_cursor);
      drop(v1271_2);
      v1270_2.join_into((v1271_3).clone());
      }
      v1270_2_cursor.ascend(1);
    }
    drop(v1270_2_cursor);
    v1269_12.join_into((v1270_2).clone());
    }
    v1269_12_cursor.ascend(1);
  }
  drop(v1269_12_cursor);
  (v1269_12).clone()
}

fn routine_117(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1278_12 = Space::new();
  let mut v1278_12_cursor = (*s0).read_zipper();
  for v1278_12_byte in v1278_12_cursor.child_mask().iter() {
    v1278_12_cursor.descend_to_byte(v1278_12_byte);
    {
    let v1278_12_tail = v1278_12_cursor.fork_read_zipper();
    let v1278_12_head = Path::from_slice(&[v1278_12_byte]);
    let mut v1279_2 = Space::new();
    let mut v1279_2_cursor = (v1278_12_tail).read_zipper();
    for v1279_2_byte in v1279_2_cursor.child_mask().iter() {
      v1279_2_cursor.descend_to_byte(v1279_2_byte);
      {
      let v1279_2_tail = v1279_2_cursor.fork_read_zipper();
      let v1279_2_head = Path::from_slice(&[v1279_2_byte]);
      let v1280_2: Path = concat_path(&(v1278_12_head),&(v1279_2_head));
      let mut v1280_3 = Space::new();
      let mut v1280_3_cursor = (v1279_2_tail).read_zipper();
      for v1280_3_byte in v1280_3_cursor.child_mask().iter() {
        v1280_3_cursor.descend_to_byte(v1280_3_byte);
        {
        let v1280_3_tail = v1280_3_cursor.fork_read_zipper();
        let v1280_3_head = Path::from_slice(&[v1280_3_byte]);
        let v1281_2: Path = concat_path(&(v1280_2),&(v1280_3_head));
        let mut v1281_3 = Space::new();
        let mut v1281_3_cursor = (v1280_3_tail).read_zipper();
        for v1281_3_byte in v1281_3_cursor.child_mask().iter() {
          v1281_3_cursor.descend_to_byte(v1281_3_byte);
          {
          let v1281_3_tail = v1281_3_cursor.fork_read_zipper();
          let v1281_3_head = Path::from_slice(&[v1281_3_byte]);
          let v1282_2: Path = concat_path(&(v1281_2),&(v1281_3_head));
          let mut v1282_3 = Space::new();
          let mut v1282_3_cursor = (v1281_3_tail).read_zipper();
          for v1282_3_byte in v1282_3_cursor.child_mask().iter() {
            v1282_3_cursor.descend_to_byte(v1282_3_byte);
            {
            let v1282_3_tail = v1282_3_cursor.fork_read_zipper();
            let v1282_3_head = Path::from_slice(&[v1282_3_byte]);
            let mut v1283_2 = Space::new();
            let mut v1283_2_cursor = (v1282_3_tail).read_zipper();
            for v1283_2_byte in v1283_2_cursor.child_mask().iter() {
              v1283_2_cursor.descend_to_byte(v1283_2_byte);
              {
              let v1283_2_tail = v1283_2_cursor.fork_read_zipper();
              let v1283_2_head = Path::from_slice(&[v1283_2_byte]);
              let v1284_2: Path = concat_path(&(v1282_3_head),&(v1283_2_head));
              let mut v1284_3 = Space::new();
              let mut v1284_3_cursor = (v1283_2_tail).read_zipper();
              for v1284_3_byte in v1284_3_cursor.child_mask().iter() {
                v1284_3_cursor.descend_to_byte(v1284_3_byte);
                {
                let v1284_3_tail = v1284_3_cursor.fork_read_zipper();
                let v1284_3_head = Path::from_slice(&[v1284_3_byte]);
                let v1285_2: Path = concat_path(&(v1284_2),&(v1284_3_head));
                let mut v1285_3 = Space::new();
                let mut v1285_3_cursor = (v1284_3_tail).read_zipper();
                for v1285_3_byte in v1285_3_cursor.child_mask().iter() {
                  v1285_3_cursor.descend_to_byte(v1285_3_byte);
                  {
                  let v1285_3_tail = v1285_3_cursor.fork_read_zipper();
                  let v1285_3_head = Path::from_slice(&[v1285_3_byte]);
                  let v1286_2: Path = concat_path(&(v1285_2),&(v1285_3_head));
                  let v1286_3: Space = routine_133(c, &(v1286_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1282_2), &(v1285_3_tail).make_space());
                  drop(v1286_2);
                  v1285_3.join_into((v1286_3).clone());
                  }
                  v1285_3_cursor.ascend(1);
                }
                drop(v1285_3_cursor);
                drop(v1285_2);
                v1284_3.join_into((v1285_3).clone());
                }
                v1284_3_cursor.ascend(1);
              }
              drop(v1284_3_cursor);
              drop(v1284_2);
              v1283_2.join_into((v1284_3).clone());
              }
              v1283_2_cursor.ascend(1);
            }
            drop(v1283_2_cursor);
            v1282_3.join_into((v1283_2).clone());
            }
            v1282_3_cursor.ascend(1);
          }
          drop(v1282_3_cursor);
          drop(v1282_2);
          v1281_3.join_into((v1282_3).clone());
          }
          v1281_3_cursor.ascend(1);
        }
        drop(v1281_3_cursor);
        drop(v1281_2);
        v1280_3.join_into((v1281_3).clone());
        }
        v1280_3_cursor.ascend(1);
      }
      drop(v1280_3_cursor);
      drop(v1280_2);
      v1279_2.join_into((v1280_3).clone());
      }
      v1279_2_cursor.ascend(1);
    }
    drop(v1279_2_cursor);
    v1278_12.join_into((v1279_2).clone());
    }
    v1278_12_cursor.ascend(1);
  }
  drop(v1278_12_cursor);
  (v1278_12).clone()
}

fn routine_118(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1287_12 = Space::new();
  let mut v1287_12_cursor = (*s0).read_zipper();
  for v1287_12_byte in v1287_12_cursor.child_mask().iter() {
    v1287_12_cursor.descend_to_byte(v1287_12_byte);
    {
    let v1287_12_tail = v1287_12_cursor.fork_read_zipper();
    let v1287_12_head = Path::from_slice(&[v1287_12_byte]);
    let mut v1288_2 = Space::new();
    let mut v1288_2_cursor = (v1287_12_tail).read_zipper();
    for v1288_2_byte in v1288_2_cursor.child_mask().iter() {
      v1288_2_cursor.descend_to_byte(v1288_2_byte);
      {
      let v1288_2_tail = v1288_2_cursor.fork_read_zipper();
      let v1288_2_head = Path::from_slice(&[v1288_2_byte]);
      let v1289_2: Path = concat_path(&(v1287_12_head),&(v1288_2_head));
      let mut v1289_3 = Space::new();
      let mut v1289_3_cursor = (v1288_2_tail).read_zipper();
      for v1289_3_byte in v1289_3_cursor.child_mask().iter() {
        v1289_3_cursor.descend_to_byte(v1289_3_byte);
        {
        let v1289_3_tail = v1289_3_cursor.fork_read_zipper();
        let v1289_3_head = Path::from_slice(&[v1289_3_byte]);
        let v1290_2: Path = concat_path(&(v1289_2),&(v1289_3_head));
        let mut v1290_3 = Space::new();
        let mut v1290_3_cursor = (v1289_3_tail).read_zipper();
        for v1290_3_byte in v1290_3_cursor.child_mask().iter() {
          v1290_3_cursor.descend_to_byte(v1290_3_byte);
          {
          let v1290_3_tail = v1290_3_cursor.fork_read_zipper();
          let v1290_3_head = Path::from_slice(&[v1290_3_byte]);
          let v1291_2: Path = concat_path(&(v1290_2),&(v1290_3_head));
          let mut v1291_3 = Space::new();
          let mut v1291_3_cursor = (v1290_3_tail).read_zipper();
          for v1291_3_byte in v1291_3_cursor.child_mask().iter() {
            v1291_3_cursor.descend_to_byte(v1291_3_byte);
            {
            let v1291_3_tail = v1291_3_cursor.fork_read_zipper();
            let v1291_3_head = Path::from_slice(&[v1291_3_byte]);
            let mut v1292_2 = Space::new();
            let mut v1292_2_cursor = (v1291_3_tail).read_zipper();
            for v1292_2_byte in v1292_2_cursor.child_mask().iter() {
              v1292_2_cursor.descend_to_byte(v1292_2_byte);
              {
              let v1292_2_tail = v1292_2_cursor.fork_read_zipper();
              let v1292_2_head = Path::from_slice(&[v1292_2_byte]);
              let v1293_2: Path = concat_path(&(v1291_3_head),&(v1292_2_head));
              let mut v1293_3 = Space::new();
              let mut v1293_3_cursor = (v1292_2_tail).read_zipper();
              for v1293_3_byte in v1293_3_cursor.child_mask().iter() {
                v1293_3_cursor.descend_to_byte(v1293_3_byte);
                {
                let v1293_3_tail = v1293_3_cursor.fork_read_zipper();
                let v1293_3_head = Path::from_slice(&[v1293_3_byte]);
                let v1294_2: Path = concat_path(&(v1293_2),&(v1293_3_head));
                let mut v1294_3 = Space::new();
                let mut v1294_3_cursor = (v1293_3_tail).read_zipper();
                for v1294_3_byte in v1294_3_cursor.child_mask().iter() {
                  v1294_3_cursor.descend_to_byte(v1294_3_byte);
                  {
                  let v1294_3_tail = v1294_3_cursor.fork_read_zipper();
                  let v1294_3_head = Path::from_slice(&[v1294_3_byte]);
                  let v1295_2: Path = concat_path(&(v1294_2),&(v1294_3_head));
                  let v1295_3: Space = routine_134(c, &(v1295_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1291_2), &(v1294_3_tail).make_space());
                  drop(v1295_2);
                  v1294_3.join_into((v1295_3).clone());
                  }
                  v1294_3_cursor.ascend(1);
                }
                drop(v1294_3_cursor);
                drop(v1294_2);
                v1293_3.join_into((v1294_3).clone());
                }
                v1293_3_cursor.ascend(1);
              }
              drop(v1293_3_cursor);
              drop(v1293_2);
              v1292_2.join_into((v1293_3).clone());
              }
              v1292_2_cursor.ascend(1);
            }
            drop(v1292_2_cursor);
            v1291_3.join_into((v1292_2).clone());
            }
            v1291_3_cursor.ascend(1);
          }
          drop(v1291_3_cursor);
          drop(v1291_2);
          v1290_3.join_into((v1291_3).clone());
          }
          v1290_3_cursor.ascend(1);
        }
        drop(v1290_3_cursor);
        drop(v1290_2);
        v1289_3.join_into((v1290_3).clone());
        }
        v1289_3_cursor.ascend(1);
      }
      drop(v1289_3_cursor);
      drop(v1289_2);
      v1288_2.join_into((v1289_3).clone());
      }
      v1288_2_cursor.ascend(1);
    }
    drop(v1288_2_cursor);
    v1287_12.join_into((v1288_2).clone());
    }
    v1287_12_cursor.ascend(1);
  }
  drop(v1287_12_cursor);
  (v1287_12).clone()
}

fn routine_119(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1296_12 = Space::new();
  let mut v1296_12_cursor = (*s0).read_zipper();
  for v1296_12_byte in v1296_12_cursor.child_mask().iter() {
    v1296_12_cursor.descend_to_byte(v1296_12_byte);
    {
    let v1296_12_tail = v1296_12_cursor.fork_read_zipper();
    let v1296_12_head = Path::from_slice(&[v1296_12_byte]);
    let mut v1297_2 = Space::new();
    let mut v1297_2_cursor = (v1296_12_tail).read_zipper();
    for v1297_2_byte in v1297_2_cursor.child_mask().iter() {
      v1297_2_cursor.descend_to_byte(v1297_2_byte);
      {
      let v1297_2_tail = v1297_2_cursor.fork_read_zipper();
      let v1297_2_head = Path::from_slice(&[v1297_2_byte]);
      let v1298_2: Path = concat_path(&(v1296_12_head),&(v1297_2_head));
      let mut v1298_3 = Space::new();
      let mut v1298_3_cursor = (v1297_2_tail).read_zipper();
      for v1298_3_byte in v1298_3_cursor.child_mask().iter() {
        v1298_3_cursor.descend_to_byte(v1298_3_byte);
        {
        let v1298_3_tail = v1298_3_cursor.fork_read_zipper();
        let v1298_3_head = Path::from_slice(&[v1298_3_byte]);
        let v1299_2: Path = concat_path(&(v1298_2),&(v1298_3_head));
        let mut v1299_3 = Space::new();
        let mut v1299_3_cursor = (v1298_3_tail).read_zipper();
        for v1299_3_byte in v1299_3_cursor.child_mask().iter() {
          v1299_3_cursor.descend_to_byte(v1299_3_byte);
          {
          let v1299_3_tail = v1299_3_cursor.fork_read_zipper();
          let v1299_3_head = Path::from_slice(&[v1299_3_byte]);
          let v1300_2: Path = concat_path(&(v1299_2),&(v1299_3_head));
          let mut v1300_3 = Space::new();
          let mut v1300_3_cursor = (v1299_3_tail).read_zipper();
          for v1300_3_byte in v1300_3_cursor.child_mask().iter() {
            v1300_3_cursor.descend_to_byte(v1300_3_byte);
            {
            let v1300_3_tail = v1300_3_cursor.fork_read_zipper();
            let v1300_3_head = Path::from_slice(&[v1300_3_byte]);
            let mut v1301_2 = Space::new();
            let mut v1301_2_cursor = (v1300_3_tail).read_zipper();
            for v1301_2_byte in v1301_2_cursor.child_mask().iter() {
              v1301_2_cursor.descend_to_byte(v1301_2_byte);
              {
              let v1301_2_tail = v1301_2_cursor.fork_read_zipper();
              let v1301_2_head = Path::from_slice(&[v1301_2_byte]);
              let v1302_2: Path = concat_path(&(v1300_3_head),&(v1301_2_head));
              let mut v1302_3 = Space::new();
              let mut v1302_3_cursor = (v1301_2_tail).read_zipper();
              for v1302_3_byte in v1302_3_cursor.child_mask().iter() {
                v1302_3_cursor.descend_to_byte(v1302_3_byte);
                {
                let v1302_3_tail = v1302_3_cursor.fork_read_zipper();
                let v1302_3_head = Path::from_slice(&[v1302_3_byte]);
                let v1303_2: Path = concat_path(&(v1302_2),&(v1302_3_head));
                let mut v1303_3 = Space::new();
                let mut v1303_3_cursor = (v1302_3_tail).read_zipper();
                for v1303_3_byte in v1303_3_cursor.child_mask().iter() {
                  v1303_3_cursor.descend_to_byte(v1303_3_byte);
                  {
                  let v1303_3_tail = v1303_3_cursor.fork_read_zipper();
                  let v1303_3_head = Path::from_slice(&[v1303_3_byte]);
                  let v1304_2: Path = concat_path(&(v1303_2),&(v1303_3_head));
                  let v1304_3: Space = routine_135(c, &(v1304_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1300_2), &(v1303_3_tail).make_space());
                  drop(v1304_2);
                  v1303_3.join_into((v1304_3).clone());
                  }
                  v1303_3_cursor.ascend(1);
                }
                drop(v1303_3_cursor);
                drop(v1303_2);
                v1302_3.join_into((v1303_3).clone());
                }
                v1302_3_cursor.ascend(1);
              }
              drop(v1302_3_cursor);
              drop(v1302_2);
              v1301_2.join_into((v1302_3).clone());
              }
              v1301_2_cursor.ascend(1);
            }
            drop(v1301_2_cursor);
            v1300_3.join_into((v1301_2).clone());
            }
            v1300_3_cursor.ascend(1);
          }
          drop(v1300_3_cursor);
          drop(v1300_2);
          v1299_3.join_into((v1300_3).clone());
          }
          v1299_3_cursor.ascend(1);
        }
        drop(v1299_3_cursor);
        drop(v1299_2);
        v1298_3.join_into((v1299_3).clone());
        }
        v1298_3_cursor.ascend(1);
      }
      drop(v1298_3_cursor);
      drop(v1298_2);
      v1297_2.join_into((v1298_3).clone());
      }
      v1297_2_cursor.ascend(1);
    }
    drop(v1297_2_cursor);
    v1296_12.join_into((v1297_2).clone());
    }
    v1296_12_cursor.ascend(1);
  }
  drop(v1296_12_cursor);
  (v1296_12).clone()
}

fn routine_120(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1305_12 = Space::new();
  let mut v1305_12_cursor = (*s0).read_zipper();
  for v1305_12_byte in v1305_12_cursor.child_mask().iter() {
    v1305_12_cursor.descend_to_byte(v1305_12_byte);
    {
    let v1305_12_tail = v1305_12_cursor.fork_read_zipper();
    let v1305_12_head = Path::from_slice(&[v1305_12_byte]);
    let mut v1306_2 = Space::new();
    let mut v1306_2_cursor = (v1305_12_tail).read_zipper();
    for v1306_2_byte in v1306_2_cursor.child_mask().iter() {
      v1306_2_cursor.descend_to_byte(v1306_2_byte);
      {
      let v1306_2_tail = v1306_2_cursor.fork_read_zipper();
      let v1306_2_head = Path::from_slice(&[v1306_2_byte]);
      let v1307_2: Path = concat_path(&(v1305_12_head),&(v1306_2_head));
      let mut v1307_3 = Space::new();
      let mut v1307_3_cursor = (v1306_2_tail).read_zipper();
      for v1307_3_byte in v1307_3_cursor.child_mask().iter() {
        v1307_3_cursor.descend_to_byte(v1307_3_byte);
        {
        let v1307_3_tail = v1307_3_cursor.fork_read_zipper();
        let v1307_3_head = Path::from_slice(&[v1307_3_byte]);
        let v1308_2: Path = concat_path(&(v1307_2),&(v1307_3_head));
        let mut v1308_3 = Space::new();
        let mut v1308_3_cursor = (v1307_3_tail).read_zipper();
        for v1308_3_byte in v1308_3_cursor.child_mask().iter() {
          v1308_3_cursor.descend_to_byte(v1308_3_byte);
          {
          let v1308_3_tail = v1308_3_cursor.fork_read_zipper();
          let v1308_3_head = Path::from_slice(&[v1308_3_byte]);
          let v1309_2: Path = concat_path(&(v1308_2),&(v1308_3_head));
          let mut v1309_3 = Space::new();
          let mut v1309_3_cursor = (v1308_3_tail).read_zipper();
          for v1309_3_byte in v1309_3_cursor.child_mask().iter() {
            v1309_3_cursor.descend_to_byte(v1309_3_byte);
            {
            let v1309_3_tail = v1309_3_cursor.fork_read_zipper();
            let v1309_3_head = Path::from_slice(&[v1309_3_byte]);
            let mut v1310_2 = Space::new();
            let mut v1310_2_cursor = (v1309_3_tail).read_zipper();
            for v1310_2_byte in v1310_2_cursor.child_mask().iter() {
              v1310_2_cursor.descend_to_byte(v1310_2_byte);
              {
              let v1310_2_tail = v1310_2_cursor.fork_read_zipper();
              let v1310_2_head = Path::from_slice(&[v1310_2_byte]);
              let v1311_2: Path = concat_path(&(v1309_3_head),&(v1310_2_head));
              let mut v1311_3 = Space::new();
              let mut v1311_3_cursor = (v1310_2_tail).read_zipper();
              for v1311_3_byte in v1311_3_cursor.child_mask().iter() {
                v1311_3_cursor.descend_to_byte(v1311_3_byte);
                {
                let v1311_3_tail = v1311_3_cursor.fork_read_zipper();
                let v1311_3_head = Path::from_slice(&[v1311_3_byte]);
                let v1312_2: Path = concat_path(&(v1311_2),&(v1311_3_head));
                let mut v1312_3 = Space::new();
                let mut v1312_3_cursor = (v1311_3_tail).read_zipper();
                for v1312_3_byte in v1312_3_cursor.child_mask().iter() {
                  v1312_3_cursor.descend_to_byte(v1312_3_byte);
                  {
                  let v1312_3_tail = v1312_3_cursor.fork_read_zipper();
                  let v1312_3_head = Path::from_slice(&[v1312_3_byte]);
                  let v1313_2: Path = concat_path(&(v1312_2),&(v1312_3_head));
                  let v1313_3: Space = routine_136(c, &(v1313_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1309_2), &(v1312_3_tail).make_space());
                  drop(v1313_2);
                  v1312_3.join_into((v1313_3).clone());
                  }
                  v1312_3_cursor.ascend(1);
                }
                drop(v1312_3_cursor);
                drop(v1312_2);
                v1311_3.join_into((v1312_3).clone());
                }
                v1311_3_cursor.ascend(1);
              }
              drop(v1311_3_cursor);
              drop(v1311_2);
              v1310_2.join_into((v1311_3).clone());
              }
              v1310_2_cursor.ascend(1);
            }
            drop(v1310_2_cursor);
            v1309_3.join_into((v1310_2).clone());
            }
            v1309_3_cursor.ascend(1);
          }
          drop(v1309_3_cursor);
          drop(v1309_2);
          v1308_3.join_into((v1309_3).clone());
          }
          v1308_3_cursor.ascend(1);
        }
        drop(v1308_3_cursor);
        drop(v1308_2);
        v1307_3.join_into((v1308_3).clone());
        }
        v1307_3_cursor.ascend(1);
      }
      drop(v1307_3_cursor);
      drop(v1307_2);
      v1306_2.join_into((v1307_3).clone());
      }
      v1306_2_cursor.ascend(1);
    }
    drop(v1306_2_cursor);
    v1305_12.join_into((v1306_2).clone());
    }
    v1305_12_cursor.ascend(1);
  }
  drop(v1305_12_cursor);
  (v1305_12).clone()
}

fn routine_121(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1314_12 = Space::new();
  let mut v1314_12_cursor = (*s0).read_zipper();
  for v1314_12_byte in v1314_12_cursor.child_mask().iter() {
    v1314_12_cursor.descend_to_byte(v1314_12_byte);
    {
    let v1314_12_tail = v1314_12_cursor.fork_read_zipper();
    let v1314_12_head = Path::from_slice(&[v1314_12_byte]);
    let mut v1315_2 = Space::new();
    let mut v1315_2_cursor = (v1314_12_tail).read_zipper();
    for v1315_2_byte in v1315_2_cursor.child_mask().iter() {
      v1315_2_cursor.descend_to_byte(v1315_2_byte);
      {
      let v1315_2_tail = v1315_2_cursor.fork_read_zipper();
      let v1315_2_head = Path::from_slice(&[v1315_2_byte]);
      let v1316_2: Path = concat_path(&(v1314_12_head),&(v1315_2_head));
      let mut v1316_3 = Space::new();
      let mut v1316_3_cursor = (v1315_2_tail).read_zipper();
      for v1316_3_byte in v1316_3_cursor.child_mask().iter() {
        v1316_3_cursor.descend_to_byte(v1316_3_byte);
        {
        let v1316_3_tail = v1316_3_cursor.fork_read_zipper();
        let v1316_3_head = Path::from_slice(&[v1316_3_byte]);
        let v1317_2: Path = concat_path(&(v1316_2),&(v1316_3_head));
        let mut v1317_3 = Space::new();
        let mut v1317_3_cursor = (v1316_3_tail).read_zipper();
        for v1317_3_byte in v1317_3_cursor.child_mask().iter() {
          v1317_3_cursor.descend_to_byte(v1317_3_byte);
          {
          let v1317_3_tail = v1317_3_cursor.fork_read_zipper();
          let v1317_3_head = Path::from_slice(&[v1317_3_byte]);
          let v1318_2: Path = concat_path(&(v1317_2),&(v1317_3_head));
          let mut v1318_3 = Space::new();
          let mut v1318_3_cursor = (v1317_3_tail).read_zipper();
          for v1318_3_byte in v1318_3_cursor.child_mask().iter() {
            v1318_3_cursor.descend_to_byte(v1318_3_byte);
            {
            let v1318_3_tail = v1318_3_cursor.fork_read_zipper();
            let v1318_3_head = Path::from_slice(&[v1318_3_byte]);
            let mut v1319_2 = Space::new();
            let mut v1319_2_cursor = (v1318_3_tail).read_zipper();
            for v1319_2_byte in v1319_2_cursor.child_mask().iter() {
              v1319_2_cursor.descend_to_byte(v1319_2_byte);
              {
              let v1319_2_tail = v1319_2_cursor.fork_read_zipper();
              let v1319_2_head = Path::from_slice(&[v1319_2_byte]);
              let v1320_2: Path = concat_path(&(v1318_3_head),&(v1319_2_head));
              let mut v1320_3 = Space::new();
              let mut v1320_3_cursor = (v1319_2_tail).read_zipper();
              for v1320_3_byte in v1320_3_cursor.child_mask().iter() {
                v1320_3_cursor.descend_to_byte(v1320_3_byte);
                {
                let v1320_3_tail = v1320_3_cursor.fork_read_zipper();
                let v1320_3_head = Path::from_slice(&[v1320_3_byte]);
                let v1321_2: Path = concat_path(&(v1320_2),&(v1320_3_head));
                let mut v1321_3 = Space::new();
                let mut v1321_3_cursor = (v1320_3_tail).read_zipper();
                for v1321_3_byte in v1321_3_cursor.child_mask().iter() {
                  v1321_3_cursor.descend_to_byte(v1321_3_byte);
                  {
                  let v1321_3_tail = v1321_3_cursor.fork_read_zipper();
                  let v1321_3_head = Path::from_slice(&[v1321_3_byte]);
                  let v1322_2: Path = concat_path(&(v1321_2),&(v1321_3_head));
                  let v1322_3: Space = routine_137(c, &(v1322_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1318_2), &(v1321_3_tail).make_space());
                  drop(v1322_2);
                  v1321_3.join_into((v1322_3).clone());
                  }
                  v1321_3_cursor.ascend(1);
                }
                drop(v1321_3_cursor);
                drop(v1321_2);
                v1320_3.join_into((v1321_3).clone());
                }
                v1320_3_cursor.ascend(1);
              }
              drop(v1320_3_cursor);
              drop(v1320_2);
              v1319_2.join_into((v1320_3).clone());
              }
              v1319_2_cursor.ascend(1);
            }
            drop(v1319_2_cursor);
            v1318_3.join_into((v1319_2).clone());
            }
            v1318_3_cursor.ascend(1);
          }
          drop(v1318_3_cursor);
          drop(v1318_2);
          v1317_3.join_into((v1318_3).clone());
          }
          v1317_3_cursor.ascend(1);
        }
        drop(v1317_3_cursor);
        drop(v1317_2);
        v1316_3.join_into((v1317_3).clone());
        }
        v1316_3_cursor.ascend(1);
      }
      drop(v1316_3_cursor);
      drop(v1316_2);
      v1315_2.join_into((v1316_3).clone());
      }
      v1315_2_cursor.ascend(1);
    }
    drop(v1315_2_cursor);
    v1314_12.join_into((v1315_2).clone());
    }
    v1314_12_cursor.ascend(1);
  }
  drop(v1314_12_cursor);
  (v1314_12).clone()
}

fn routine_122(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1323_12 = Space::new();
  let mut v1323_12_cursor = (*s0).read_zipper();
  for v1323_12_byte in v1323_12_cursor.child_mask().iter() {
    v1323_12_cursor.descend_to_byte(v1323_12_byte);
    {
    let v1323_12_tail = v1323_12_cursor.fork_read_zipper();
    let v1323_12_head = Path::from_slice(&[v1323_12_byte]);
    let mut v1324_2 = Space::new();
    let mut v1324_2_cursor = (v1323_12_tail).read_zipper();
    for v1324_2_byte in v1324_2_cursor.child_mask().iter() {
      v1324_2_cursor.descend_to_byte(v1324_2_byte);
      {
      let v1324_2_tail = v1324_2_cursor.fork_read_zipper();
      let v1324_2_head = Path::from_slice(&[v1324_2_byte]);
      let v1325_2: Path = concat_path(&(v1323_12_head),&(v1324_2_head));
      let mut v1325_3 = Space::new();
      let mut v1325_3_cursor = (v1324_2_tail).read_zipper();
      for v1325_3_byte in v1325_3_cursor.child_mask().iter() {
        v1325_3_cursor.descend_to_byte(v1325_3_byte);
        {
        let v1325_3_tail = v1325_3_cursor.fork_read_zipper();
        let v1325_3_head = Path::from_slice(&[v1325_3_byte]);
        let v1326_2: Path = concat_path(&(v1325_2),&(v1325_3_head));
        let mut v1326_3 = Space::new();
        let mut v1326_3_cursor = (v1325_3_tail).read_zipper();
        for v1326_3_byte in v1326_3_cursor.child_mask().iter() {
          v1326_3_cursor.descend_to_byte(v1326_3_byte);
          {
          let v1326_3_tail = v1326_3_cursor.fork_read_zipper();
          let v1326_3_head = Path::from_slice(&[v1326_3_byte]);
          let v1327_2: Path = concat_path(&(v1326_2),&(v1326_3_head));
          let mut v1327_3 = Space::new();
          let mut v1327_3_cursor = (v1326_3_tail).read_zipper();
          for v1327_3_byte in v1327_3_cursor.child_mask().iter() {
            v1327_3_cursor.descend_to_byte(v1327_3_byte);
            {
            let v1327_3_tail = v1327_3_cursor.fork_read_zipper();
            let v1327_3_head = Path::from_slice(&[v1327_3_byte]);
            let mut v1328_2 = Space::new();
            let mut v1328_2_cursor = (v1327_3_tail).read_zipper();
            for v1328_2_byte in v1328_2_cursor.child_mask().iter() {
              v1328_2_cursor.descend_to_byte(v1328_2_byte);
              {
              let v1328_2_tail = v1328_2_cursor.fork_read_zipper();
              let v1328_2_head = Path::from_slice(&[v1328_2_byte]);
              let v1329_2: Path = concat_path(&(v1327_3_head),&(v1328_2_head));
              let mut v1329_3 = Space::new();
              let mut v1329_3_cursor = (v1328_2_tail).read_zipper();
              for v1329_3_byte in v1329_3_cursor.child_mask().iter() {
                v1329_3_cursor.descend_to_byte(v1329_3_byte);
                {
                let v1329_3_tail = v1329_3_cursor.fork_read_zipper();
                let v1329_3_head = Path::from_slice(&[v1329_3_byte]);
                let v1330_2: Path = concat_path(&(v1329_2),&(v1329_3_head));
                let mut v1330_3 = Space::new();
                let mut v1330_3_cursor = (v1329_3_tail).read_zipper();
                for v1330_3_byte in v1330_3_cursor.child_mask().iter() {
                  v1330_3_cursor.descend_to_byte(v1330_3_byte);
                  {
                  let v1330_3_tail = v1330_3_cursor.fork_read_zipper();
                  let v1330_3_head = Path::from_slice(&[v1330_3_byte]);
                  let v1331_2: Path = concat_path(&(v1330_2),&(v1330_3_head));
                  let v1331_3: Space = routine_138(c, &(v1331_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1327_2), &(v1330_3_tail).make_space());
                  drop(v1331_2);
                  v1330_3.join_into((v1331_3).clone());
                  }
                  v1330_3_cursor.ascend(1);
                }
                drop(v1330_3_cursor);
                drop(v1330_2);
                v1329_3.join_into((v1330_3).clone());
                }
                v1329_3_cursor.ascend(1);
              }
              drop(v1329_3_cursor);
              drop(v1329_2);
              v1328_2.join_into((v1329_3).clone());
              }
              v1328_2_cursor.ascend(1);
            }
            drop(v1328_2_cursor);
            v1327_3.join_into((v1328_2).clone());
            }
            v1327_3_cursor.ascend(1);
          }
          drop(v1327_3_cursor);
          drop(v1327_2);
          v1326_3.join_into((v1327_3).clone());
          }
          v1326_3_cursor.ascend(1);
        }
        drop(v1326_3_cursor);
        drop(v1326_2);
        v1325_3.join_into((v1326_3).clone());
        }
        v1325_3_cursor.ascend(1);
      }
      drop(v1325_3_cursor);
      drop(v1325_2);
      v1324_2.join_into((v1325_3).clone());
      }
      v1324_2_cursor.ascend(1);
    }
    drop(v1324_2_cursor);
    v1323_12.join_into((v1324_2).clone());
    }
    v1323_12_cursor.ascend(1);
  }
  drop(v1323_12_cursor);
  (v1323_12).clone()
}

fn routine_123(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1332_12 = Space::new();
  let mut v1332_12_cursor = (*s0).read_zipper();
  for v1332_12_byte in v1332_12_cursor.child_mask().iter() {
    v1332_12_cursor.descend_to_byte(v1332_12_byte);
    {
    let v1332_12_tail = v1332_12_cursor.fork_read_zipper();
    let v1332_12_head = Path::from_slice(&[v1332_12_byte]);
    let mut v1333_2 = Space::new();
    let mut v1333_2_cursor = (v1332_12_tail).read_zipper();
    for v1333_2_byte in v1333_2_cursor.child_mask().iter() {
      v1333_2_cursor.descend_to_byte(v1333_2_byte);
      {
      let v1333_2_tail = v1333_2_cursor.fork_read_zipper();
      let v1333_2_head = Path::from_slice(&[v1333_2_byte]);
      let v1334_2: Path = concat_path(&(v1332_12_head),&(v1333_2_head));
      let mut v1334_3 = Space::new();
      let mut v1334_3_cursor = (v1333_2_tail).read_zipper();
      for v1334_3_byte in v1334_3_cursor.child_mask().iter() {
        v1334_3_cursor.descend_to_byte(v1334_3_byte);
        {
        let v1334_3_tail = v1334_3_cursor.fork_read_zipper();
        let v1334_3_head = Path::from_slice(&[v1334_3_byte]);
        let v1335_2: Path = concat_path(&(v1334_2),&(v1334_3_head));
        let mut v1335_3 = Space::new();
        let mut v1335_3_cursor = (v1334_3_tail).read_zipper();
        for v1335_3_byte in v1335_3_cursor.child_mask().iter() {
          v1335_3_cursor.descend_to_byte(v1335_3_byte);
          {
          let v1335_3_tail = v1335_3_cursor.fork_read_zipper();
          let v1335_3_head = Path::from_slice(&[v1335_3_byte]);
          let v1336_2: Path = concat_path(&(v1335_2),&(v1335_3_head));
          let mut v1336_3 = Space::new();
          let mut v1336_3_cursor = (v1335_3_tail).read_zipper();
          for v1336_3_byte in v1336_3_cursor.child_mask().iter() {
            v1336_3_cursor.descend_to_byte(v1336_3_byte);
            {
            let v1336_3_tail = v1336_3_cursor.fork_read_zipper();
            let v1336_3_head = Path::from_slice(&[v1336_3_byte]);
            let mut v1337_2 = Space::new();
            let mut v1337_2_cursor = (v1336_3_tail).read_zipper();
            for v1337_2_byte in v1337_2_cursor.child_mask().iter() {
              v1337_2_cursor.descend_to_byte(v1337_2_byte);
              {
              let v1337_2_tail = v1337_2_cursor.fork_read_zipper();
              let v1337_2_head = Path::from_slice(&[v1337_2_byte]);
              let v1338_2: Path = concat_path(&(v1336_3_head),&(v1337_2_head));
              let mut v1338_3 = Space::new();
              let mut v1338_3_cursor = (v1337_2_tail).read_zipper();
              for v1338_3_byte in v1338_3_cursor.child_mask().iter() {
                v1338_3_cursor.descend_to_byte(v1338_3_byte);
                {
                let v1338_3_tail = v1338_3_cursor.fork_read_zipper();
                let v1338_3_head = Path::from_slice(&[v1338_3_byte]);
                let v1339_2: Path = concat_path(&(v1338_2),&(v1338_3_head));
                let mut v1339_3 = Space::new();
                let mut v1339_3_cursor = (v1338_3_tail).read_zipper();
                for v1339_3_byte in v1339_3_cursor.child_mask().iter() {
                  v1339_3_cursor.descend_to_byte(v1339_3_byte);
                  {
                  let v1339_3_tail = v1339_3_cursor.fork_read_zipper();
                  let v1339_3_head = Path::from_slice(&[v1339_3_byte]);
                  let v1340_2: Path = concat_path(&(v1339_2),&(v1339_3_head));
                  let v1340_3: Space = routine_139(c, &(v1340_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1336_2), &(v1339_3_tail).make_space());
                  drop(v1340_2);
                  v1339_3.join_into((v1340_3).clone());
                  }
                  v1339_3_cursor.ascend(1);
                }
                drop(v1339_3_cursor);
                drop(v1339_2);
                v1338_3.join_into((v1339_3).clone());
                }
                v1338_3_cursor.ascend(1);
              }
              drop(v1338_3_cursor);
              drop(v1338_2);
              v1337_2.join_into((v1338_3).clone());
              }
              v1337_2_cursor.ascend(1);
            }
            drop(v1337_2_cursor);
            v1336_3.join_into((v1337_2).clone());
            }
            v1336_3_cursor.ascend(1);
          }
          drop(v1336_3_cursor);
          drop(v1336_2);
          v1335_3.join_into((v1336_3).clone());
          }
          v1335_3_cursor.ascend(1);
        }
        drop(v1335_3_cursor);
        drop(v1335_2);
        v1334_3.join_into((v1335_3).clone());
        }
        v1334_3_cursor.ascend(1);
      }
      drop(v1334_3_cursor);
      drop(v1334_2);
      v1333_2.join_into((v1334_3).clone());
      }
      v1333_2_cursor.ascend(1);
    }
    drop(v1333_2_cursor);
    v1332_12.join_into((v1333_2).clone());
    }
    v1332_12_cursor.ascend(1);
  }
  drop(v1332_12_cursor);
  (v1332_12).clone()
}

fn routine_124(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1341_12 = Space::new();
  let mut v1341_12_cursor = (*s0).read_zipper();
  for v1341_12_byte in v1341_12_cursor.child_mask().iter() {
    v1341_12_cursor.descend_to_byte(v1341_12_byte);
    {
    let v1341_12_tail = v1341_12_cursor.fork_read_zipper();
    let v1341_12_head = Path::from_slice(&[v1341_12_byte]);
    let mut v1342_2 = Space::new();
    let mut v1342_2_cursor = (v1341_12_tail).read_zipper();
    for v1342_2_byte in v1342_2_cursor.child_mask().iter() {
      v1342_2_cursor.descend_to_byte(v1342_2_byte);
      {
      let v1342_2_tail = v1342_2_cursor.fork_read_zipper();
      let v1342_2_head = Path::from_slice(&[v1342_2_byte]);
      let v1343_2: Path = concat_path(&(v1341_12_head),&(v1342_2_head));
      let mut v1343_3 = Space::new();
      let mut v1343_3_cursor = (v1342_2_tail).read_zipper();
      for v1343_3_byte in v1343_3_cursor.child_mask().iter() {
        v1343_3_cursor.descend_to_byte(v1343_3_byte);
        {
        let v1343_3_tail = v1343_3_cursor.fork_read_zipper();
        let v1343_3_head = Path::from_slice(&[v1343_3_byte]);
        let v1344_2: Path = concat_path(&(v1343_2),&(v1343_3_head));
        let mut v1344_3 = Space::new();
        let mut v1344_3_cursor = (v1343_3_tail).read_zipper();
        for v1344_3_byte in v1344_3_cursor.child_mask().iter() {
          v1344_3_cursor.descend_to_byte(v1344_3_byte);
          {
          let v1344_3_tail = v1344_3_cursor.fork_read_zipper();
          let v1344_3_head = Path::from_slice(&[v1344_3_byte]);
          let v1345_2: Path = concat_path(&(v1344_2),&(v1344_3_head));
          let mut v1345_3 = Space::new();
          let mut v1345_3_cursor = (v1344_3_tail).read_zipper();
          for v1345_3_byte in v1345_3_cursor.child_mask().iter() {
            v1345_3_cursor.descend_to_byte(v1345_3_byte);
            {
            let v1345_3_tail = v1345_3_cursor.fork_read_zipper();
            let v1345_3_head = Path::from_slice(&[v1345_3_byte]);
            let mut v1346_2 = Space::new();
            let mut v1346_2_cursor = (v1345_3_tail).read_zipper();
            for v1346_2_byte in v1346_2_cursor.child_mask().iter() {
              v1346_2_cursor.descend_to_byte(v1346_2_byte);
              {
              let v1346_2_tail = v1346_2_cursor.fork_read_zipper();
              let v1346_2_head = Path::from_slice(&[v1346_2_byte]);
              let v1347_2: Path = concat_path(&(v1345_3_head),&(v1346_2_head));
              let mut v1347_3 = Space::new();
              let mut v1347_3_cursor = (v1346_2_tail).read_zipper();
              for v1347_3_byte in v1347_3_cursor.child_mask().iter() {
                v1347_3_cursor.descend_to_byte(v1347_3_byte);
                {
                let v1347_3_tail = v1347_3_cursor.fork_read_zipper();
                let v1347_3_head = Path::from_slice(&[v1347_3_byte]);
                let v1348_2: Path = concat_path(&(v1347_2),&(v1347_3_head));
                let mut v1348_3 = Space::new();
                let mut v1348_3_cursor = (v1347_3_tail).read_zipper();
                for v1348_3_byte in v1348_3_cursor.child_mask().iter() {
                  v1348_3_cursor.descend_to_byte(v1348_3_byte);
                  {
                  let v1348_3_tail = v1348_3_cursor.fork_read_zipper();
                  let v1348_3_head = Path::from_slice(&[v1348_3_byte]);
                  let v1349_2: Path = concat_path(&(v1348_2),&(v1348_3_head));
                  let v1349_3: Space = routine_140(c, &(v1349_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1345_2), &(v1348_3_tail).make_space());
                  drop(v1349_2);
                  v1348_3.join_into((v1349_3).clone());
                  }
                  v1348_3_cursor.ascend(1);
                }
                drop(v1348_3_cursor);
                drop(v1348_2);
                v1347_3.join_into((v1348_3).clone());
                }
                v1347_3_cursor.ascend(1);
              }
              drop(v1347_3_cursor);
              drop(v1347_2);
              v1346_2.join_into((v1347_3).clone());
              }
              v1346_2_cursor.ascend(1);
            }
            drop(v1346_2_cursor);
            v1345_3.join_into((v1346_2).clone());
            }
            v1345_3_cursor.ascend(1);
          }
          drop(v1345_3_cursor);
          drop(v1345_2);
          v1344_3.join_into((v1345_3).clone());
          }
          v1344_3_cursor.ascend(1);
        }
        drop(v1344_3_cursor);
        drop(v1344_2);
        v1343_3.join_into((v1344_3).clone());
        }
        v1343_3_cursor.ascend(1);
      }
      drop(v1343_3_cursor);
      drop(v1343_2);
      v1342_2.join_into((v1343_3).clone());
      }
      v1342_2_cursor.ascend(1);
    }
    drop(v1342_2_cursor);
    v1341_12.join_into((v1342_2).clone());
    }
    v1341_12_cursor.ascend(1);
  }
  drop(v1341_12_cursor);
  (v1341_12).clone()
}

fn routine_125(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1350_12 = Space::new();
  let mut v1350_12_cursor = (*s0).read_zipper();
  for v1350_12_byte in v1350_12_cursor.child_mask().iter() {
    v1350_12_cursor.descend_to_byte(v1350_12_byte);
    {
    let v1350_12_tail = v1350_12_cursor.fork_read_zipper();
    let v1350_12_head = Path::from_slice(&[v1350_12_byte]);
    let mut v1351_2 = Space::new();
    let mut v1351_2_cursor = (v1350_12_tail).read_zipper();
    for v1351_2_byte in v1351_2_cursor.child_mask().iter() {
      v1351_2_cursor.descend_to_byte(v1351_2_byte);
      {
      let v1351_2_tail = v1351_2_cursor.fork_read_zipper();
      let v1351_2_head = Path::from_slice(&[v1351_2_byte]);
      let v1352_2: Path = concat_path(&(v1350_12_head),&(v1351_2_head));
      let mut v1352_3 = Space::new();
      let mut v1352_3_cursor = (v1351_2_tail).read_zipper();
      for v1352_3_byte in v1352_3_cursor.child_mask().iter() {
        v1352_3_cursor.descend_to_byte(v1352_3_byte);
        {
        let v1352_3_tail = v1352_3_cursor.fork_read_zipper();
        let v1352_3_head = Path::from_slice(&[v1352_3_byte]);
        let v1353_2: Path = concat_path(&(v1352_2),&(v1352_3_head));
        let mut v1353_3 = Space::new();
        let mut v1353_3_cursor = (v1352_3_tail).read_zipper();
        for v1353_3_byte in v1353_3_cursor.child_mask().iter() {
          v1353_3_cursor.descend_to_byte(v1353_3_byte);
          {
          let v1353_3_tail = v1353_3_cursor.fork_read_zipper();
          let v1353_3_head = Path::from_slice(&[v1353_3_byte]);
          let v1354_2: Path = concat_path(&(v1353_2),&(v1353_3_head));
          let mut v1354_3 = Space::new();
          let mut v1354_3_cursor = (v1353_3_tail).read_zipper();
          for v1354_3_byte in v1354_3_cursor.child_mask().iter() {
            v1354_3_cursor.descend_to_byte(v1354_3_byte);
            {
            let v1354_3_tail = v1354_3_cursor.fork_read_zipper();
            let v1354_3_head = Path::from_slice(&[v1354_3_byte]);
            let mut v1355_2 = Space::new();
            let mut v1355_2_cursor = (v1354_3_tail).read_zipper();
            for v1355_2_byte in v1355_2_cursor.child_mask().iter() {
              v1355_2_cursor.descend_to_byte(v1355_2_byte);
              {
              let v1355_2_tail = v1355_2_cursor.fork_read_zipper();
              let v1355_2_head = Path::from_slice(&[v1355_2_byte]);
              let v1356_2: Path = concat_path(&(v1354_3_head),&(v1355_2_head));
              let mut v1356_3 = Space::new();
              let mut v1356_3_cursor = (v1355_2_tail).read_zipper();
              for v1356_3_byte in v1356_3_cursor.child_mask().iter() {
                v1356_3_cursor.descend_to_byte(v1356_3_byte);
                {
                let v1356_3_tail = v1356_3_cursor.fork_read_zipper();
                let v1356_3_head = Path::from_slice(&[v1356_3_byte]);
                let v1357_2: Path = concat_path(&(v1356_2),&(v1356_3_head));
                let mut v1357_3 = Space::new();
                let mut v1357_3_cursor = (v1356_3_tail).read_zipper();
                for v1357_3_byte in v1357_3_cursor.child_mask().iter() {
                  v1357_3_cursor.descend_to_byte(v1357_3_byte);
                  {
                  let v1357_3_tail = v1357_3_cursor.fork_read_zipper();
                  let v1357_3_head = Path::from_slice(&[v1357_3_byte]);
                  let v1358_2: Path = concat_path(&(v1357_2),&(v1357_3_head));
                  let v1358_3: Space = routine_141(c, &(v1358_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1354_2), &(v1357_3_tail).make_space());
                  drop(v1358_2);
                  v1357_3.join_into((v1358_3).clone());
                  }
                  v1357_3_cursor.ascend(1);
                }
                drop(v1357_3_cursor);
                drop(v1357_2);
                v1356_3.join_into((v1357_3).clone());
                }
                v1356_3_cursor.ascend(1);
              }
              drop(v1356_3_cursor);
              drop(v1356_2);
              v1355_2.join_into((v1356_3).clone());
              }
              v1355_2_cursor.ascend(1);
            }
            drop(v1355_2_cursor);
            v1354_3.join_into((v1355_2).clone());
            }
            v1354_3_cursor.ascend(1);
          }
          drop(v1354_3_cursor);
          drop(v1354_2);
          v1353_3.join_into((v1354_3).clone());
          }
          v1353_3_cursor.ascend(1);
        }
        drop(v1353_3_cursor);
        drop(v1353_2);
        v1352_3.join_into((v1353_3).clone());
        }
        v1352_3_cursor.ascend(1);
      }
      drop(v1352_3_cursor);
      drop(v1352_2);
      v1351_2.join_into((v1352_3).clone());
      }
      v1351_2_cursor.ascend(1);
    }
    drop(v1351_2_cursor);
    v1350_12.join_into((v1351_2).clone());
    }
    v1350_12_cursor.ascend(1);
  }
  drop(v1350_12_cursor);
  (v1350_12).clone()
}

fn routine_126(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, s0: &Space) -> Space {
  let mut v1359_12 = Space::new();
  let mut v1359_12_cursor = (*s0).read_zipper();
  for v1359_12_byte in v1359_12_cursor.child_mask().iter() {
    v1359_12_cursor.descend_to_byte(v1359_12_byte);
    {
    let v1359_12_tail = v1359_12_cursor.fork_read_zipper();
    let v1359_12_head = Path::from_slice(&[v1359_12_byte]);
    let mut v1360_2 = Space::new();
    let mut v1360_2_cursor = (v1359_12_tail).read_zipper();
    for v1360_2_byte in v1360_2_cursor.child_mask().iter() {
      v1360_2_cursor.descend_to_byte(v1360_2_byte);
      {
      let v1360_2_tail = v1360_2_cursor.fork_read_zipper();
      let v1360_2_head = Path::from_slice(&[v1360_2_byte]);
      let v1361_2: Path = concat_path(&(v1359_12_head),&(v1360_2_head));
      let mut v1361_3 = Space::new();
      let mut v1361_3_cursor = (v1360_2_tail).read_zipper();
      for v1361_3_byte in v1361_3_cursor.child_mask().iter() {
        v1361_3_cursor.descend_to_byte(v1361_3_byte);
        {
        let v1361_3_tail = v1361_3_cursor.fork_read_zipper();
        let v1361_3_head = Path::from_slice(&[v1361_3_byte]);
        let v1362_2: Path = concat_path(&(v1361_2),&(v1361_3_head));
        let mut v1362_3 = Space::new();
        let mut v1362_3_cursor = (v1361_3_tail).read_zipper();
        for v1362_3_byte in v1362_3_cursor.child_mask().iter() {
          v1362_3_cursor.descend_to_byte(v1362_3_byte);
          {
          let v1362_3_tail = v1362_3_cursor.fork_read_zipper();
          let v1362_3_head = Path::from_slice(&[v1362_3_byte]);
          let v1363_2: Path = concat_path(&(v1362_2),&(v1362_3_head));
          let mut v1363_3 = Space::new();
          let mut v1363_3_cursor = (v1362_3_tail).read_zipper();
          for v1363_3_byte in v1363_3_cursor.child_mask().iter() {
            v1363_3_cursor.descend_to_byte(v1363_3_byte);
            {
            let v1363_3_tail = v1363_3_cursor.fork_read_zipper();
            let v1363_3_head = Path::from_slice(&[v1363_3_byte]);
            let mut v1364_2 = Space::new();
            let mut v1364_2_cursor = (v1363_3_tail).read_zipper();
            for v1364_2_byte in v1364_2_cursor.child_mask().iter() {
              v1364_2_cursor.descend_to_byte(v1364_2_byte);
              {
              let v1364_2_tail = v1364_2_cursor.fork_read_zipper();
              let v1364_2_head = Path::from_slice(&[v1364_2_byte]);
              let v1365_2: Path = concat_path(&(v1363_3_head),&(v1364_2_head));
              let mut v1365_3 = Space::new();
              let mut v1365_3_cursor = (v1364_2_tail).read_zipper();
              for v1365_3_byte in v1365_3_cursor.child_mask().iter() {
                v1365_3_cursor.descend_to_byte(v1365_3_byte);
                {
                let v1365_3_tail = v1365_3_cursor.fork_read_zipper();
                let v1365_3_head = Path::from_slice(&[v1365_3_byte]);
                let v1366_2: Path = concat_path(&(v1365_2),&(v1365_3_head));
                let mut v1366_3 = Space::new();
                let mut v1366_3_cursor = (v1365_3_tail).read_zipper();
                for v1366_3_byte in v1366_3_cursor.child_mask().iter() {
                  v1366_3_cursor.descend_to_byte(v1366_3_byte);
                  {
                  let v1366_3_tail = v1366_3_cursor.fork_read_zipper();
                  let v1366_3_head = Path::from_slice(&[v1366_3_byte]);
                  let v1367_2: Path = concat_path(&(v1366_2),&(v1366_3_head));
                  let v1367_3: Space = routine_142(c, &(v1367_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p0), &(v1363_2), &(v1366_3_tail).make_space());
                  drop(v1367_2);
                  v1366_3.join_into((v1367_3).clone());
                  }
                  v1366_3_cursor.ascend(1);
                }
                drop(v1366_3_cursor);
                drop(v1366_2);
                v1365_3.join_into((v1366_3).clone());
                }
                v1365_3_cursor.ascend(1);
              }
              drop(v1365_3_cursor);
              drop(v1365_2);
              v1364_2.join_into((v1365_3).clone());
              }
              v1364_2_cursor.ascend(1);
            }
            drop(v1364_2_cursor);
            v1363_3.join_into((v1364_2).clone());
            }
            v1363_3_cursor.ascend(1);
          }
          drop(v1363_3_cursor);
          drop(v1363_2);
          v1362_3.join_into((v1363_3).clone());
          }
          v1362_3_cursor.ascend(1);
        }
        drop(v1362_3_cursor);
        drop(v1362_2);
        v1361_3.join_into((v1362_3).clone());
        }
        v1361_3_cursor.ascend(1);
      }
      drop(v1361_3_cursor);
      drop(v1361_2);
      v1360_2.join_into((v1361_3).clone());
      }
      v1360_2_cursor.ascend(1);
    }
    drop(v1360_2_cursor);
    v1359_12.join_into((v1360_2).clone());
    }
    v1359_12_cursor.ascend(1);
  }
  drop(v1359_12_cursor);
  (v1359_12).clone()
}

fn routine_127(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1368_14 = Space::new();
  let mut v1368_14_cursor = (*s0).read_zipper();
  for v1368_14_byte in v1368_14_cursor.child_mask().iter() {
    v1368_14_cursor.descend_to_byte(v1368_14_byte);
    {
    let v1368_14_tail = v1368_14_cursor.fork_read_zipper();
    let v1368_14_head = Path::from_slice(&[v1368_14_byte]);
    let mut v1369_2 = Space::new();
    let mut v1369_2_cursor = (v1368_14_tail).read_zipper();
    for v1369_2_byte in v1369_2_cursor.child_mask().iter() {
      v1369_2_cursor.descend_to_byte(v1369_2_byte);
      {
      let v1369_2_tail = v1369_2_cursor.fork_read_zipper();
      let v1369_2_head = Path::from_slice(&[v1369_2_byte]);
      let v1370_2: Path = concat_path(&(v1368_14_head),&(v1369_2_head));
      let mut v1370_3 = Space::new();
      let mut v1370_3_cursor = (v1369_2_tail).read_zipper();
      for v1370_3_byte in v1370_3_cursor.child_mask().iter() {
        v1370_3_cursor.descend_to_byte(v1370_3_byte);
        {
        let v1370_3_tail = v1370_3_cursor.fork_read_zipper();
        let v1370_3_head = Path::from_slice(&[v1370_3_byte]);
        let v1371_2: Path = concat_path(&(v1370_2),&(v1370_3_head));
        let mut v1371_3 = Space::new();
        let mut v1371_3_cursor = (v1370_3_tail).read_zipper();
        for v1371_3_byte in v1371_3_cursor.child_mask().iter() {
          v1371_3_cursor.descend_to_byte(v1371_3_byte);
          {
          let v1371_3_tail = v1371_3_cursor.fork_read_zipper();
          let v1371_3_head = Path::from_slice(&[v1371_3_byte]);
          let v1372_2: Path = concat_path(&(v1371_2),&(v1371_3_head));
          let mut v1372_3 = Space::new();
          let mut v1372_3_cursor = (v1371_3_tail).read_zipper();
          for v1372_3_byte in v1372_3_cursor.child_mask().iter() {
            v1372_3_cursor.descend_to_byte(v1372_3_byte);
            {
            let v1372_3_tail = v1372_3_cursor.fork_read_zipper();
            let v1372_3_head = Path::from_slice(&[v1372_3_byte]);
            let mut v1373_2 = Space::new();
            let mut v1373_2_cursor = (v1372_3_tail).read_zipper();
            for v1373_2_byte in v1373_2_cursor.child_mask().iter() {
              v1373_2_cursor.descend_to_byte(v1373_2_byte);
              {
              let v1373_2_tail = v1373_2_cursor.fork_read_zipper();
              let v1373_2_head = Path::from_slice(&[v1373_2_byte]);
              let v1374_2: Path = concat_path(&(v1372_3_head),&(v1373_2_head));
              let mut v1374_3 = Space::new();
              let mut v1374_3_cursor = (v1373_2_tail).read_zipper();
              for v1374_3_byte in v1374_3_cursor.child_mask().iter() {
                v1374_3_cursor.descend_to_byte(v1374_3_byte);
                {
                let v1374_3_tail = v1374_3_cursor.fork_read_zipper();
                let v1374_3_head = Path::from_slice(&[v1374_3_byte]);
                let v1375_2: Path = concat_path(&(v1374_2),&(v1374_3_head));
                let mut v1375_3 = Space::new();
                let mut v1375_3_cursor = (v1374_3_tail).read_zipper();
                for v1375_3_byte in v1375_3_cursor.child_mask().iter() {
                  v1375_3_cursor.descend_to_byte(v1375_3_byte);
                  {
                  let v1375_3_tail = v1375_3_cursor.fork_read_zipper();
                  let v1375_3_head = Path::from_slice(&[v1375_3_byte]);
                  let v1376_2: Path = concat_path(&(v1375_2),&(v1375_3_head));
                  let v1376_3: Space = routine_143(c, &(v1376_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1372_2), &(v1375_3_tail).make_space());
                  drop(v1376_2);
                  v1375_3.join_into((v1376_3).clone());
                  }
                  v1375_3_cursor.ascend(1);
                }
                drop(v1375_3_cursor);
                drop(v1375_2);
                v1374_3.join_into((v1375_3).clone());
                }
                v1374_3_cursor.ascend(1);
              }
              drop(v1374_3_cursor);
              drop(v1374_2);
              v1373_2.join_into((v1374_3).clone());
              }
              v1373_2_cursor.ascend(1);
            }
            drop(v1373_2_cursor);
            v1372_3.join_into((v1373_2).clone());
            }
            v1372_3_cursor.ascend(1);
          }
          drop(v1372_3_cursor);
          drop(v1372_2);
          v1371_3.join_into((v1372_3).clone());
          }
          v1371_3_cursor.ascend(1);
        }
        drop(v1371_3_cursor);
        drop(v1371_2);
        v1370_3.join_into((v1371_3).clone());
        }
        v1370_3_cursor.ascend(1);
      }
      drop(v1370_3_cursor);
      drop(v1370_2);
      v1369_2.join_into((v1370_3).clone());
      }
      v1369_2_cursor.ascend(1);
    }
    drop(v1369_2_cursor);
    v1368_14.join_into((v1369_2).clone());
    }
    v1368_14_cursor.ascend(1);
  }
  drop(v1368_14_cursor);
  (v1368_14).clone()
}

fn routine_128(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1377_14 = Space::new();
  let mut v1377_14_cursor = (*s0).read_zipper();
  for v1377_14_byte in v1377_14_cursor.child_mask().iter() {
    v1377_14_cursor.descend_to_byte(v1377_14_byte);
    {
    let v1377_14_tail = v1377_14_cursor.fork_read_zipper();
    let v1377_14_head = Path::from_slice(&[v1377_14_byte]);
    let mut v1378_2 = Space::new();
    let mut v1378_2_cursor = (v1377_14_tail).read_zipper();
    for v1378_2_byte in v1378_2_cursor.child_mask().iter() {
      v1378_2_cursor.descend_to_byte(v1378_2_byte);
      {
      let v1378_2_tail = v1378_2_cursor.fork_read_zipper();
      let v1378_2_head = Path::from_slice(&[v1378_2_byte]);
      let v1379_2: Path = concat_path(&(v1377_14_head),&(v1378_2_head));
      let mut v1379_3 = Space::new();
      let mut v1379_3_cursor = (v1378_2_tail).read_zipper();
      for v1379_3_byte in v1379_3_cursor.child_mask().iter() {
        v1379_3_cursor.descend_to_byte(v1379_3_byte);
        {
        let v1379_3_tail = v1379_3_cursor.fork_read_zipper();
        let v1379_3_head = Path::from_slice(&[v1379_3_byte]);
        let v1380_2: Path = concat_path(&(v1379_2),&(v1379_3_head));
        let mut v1380_3 = Space::new();
        let mut v1380_3_cursor = (v1379_3_tail).read_zipper();
        for v1380_3_byte in v1380_3_cursor.child_mask().iter() {
          v1380_3_cursor.descend_to_byte(v1380_3_byte);
          {
          let v1380_3_tail = v1380_3_cursor.fork_read_zipper();
          let v1380_3_head = Path::from_slice(&[v1380_3_byte]);
          let v1381_2: Path = concat_path(&(v1380_2),&(v1380_3_head));
          let mut v1381_3 = Space::new();
          let mut v1381_3_cursor = (v1380_3_tail).read_zipper();
          for v1381_3_byte in v1381_3_cursor.child_mask().iter() {
            v1381_3_cursor.descend_to_byte(v1381_3_byte);
            {
            let v1381_3_tail = v1381_3_cursor.fork_read_zipper();
            let v1381_3_head = Path::from_slice(&[v1381_3_byte]);
            let mut v1382_2 = Space::new();
            let mut v1382_2_cursor = (v1381_3_tail).read_zipper();
            for v1382_2_byte in v1382_2_cursor.child_mask().iter() {
              v1382_2_cursor.descend_to_byte(v1382_2_byte);
              {
              let v1382_2_tail = v1382_2_cursor.fork_read_zipper();
              let v1382_2_head = Path::from_slice(&[v1382_2_byte]);
              let v1383_2: Path = concat_path(&(v1381_3_head),&(v1382_2_head));
              let mut v1383_3 = Space::new();
              let mut v1383_3_cursor = (v1382_2_tail).read_zipper();
              for v1383_3_byte in v1383_3_cursor.child_mask().iter() {
                v1383_3_cursor.descend_to_byte(v1383_3_byte);
                {
                let v1383_3_tail = v1383_3_cursor.fork_read_zipper();
                let v1383_3_head = Path::from_slice(&[v1383_3_byte]);
                let v1384_2: Path = concat_path(&(v1383_2),&(v1383_3_head));
                let mut v1384_3 = Space::new();
                let mut v1384_3_cursor = (v1383_3_tail).read_zipper();
                for v1384_3_byte in v1384_3_cursor.child_mask().iter() {
                  v1384_3_cursor.descend_to_byte(v1384_3_byte);
                  {
                  let v1384_3_tail = v1384_3_cursor.fork_read_zipper();
                  let v1384_3_head = Path::from_slice(&[v1384_3_byte]);
                  let v1385_2: Path = concat_path(&(v1384_2),&(v1384_3_head));
                  let v1385_3: Space = routine_144(c, &(v1385_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1381_2), &(v1384_3_tail).make_space());
                  drop(v1385_2);
                  v1384_3.join_into((v1385_3).clone());
                  }
                  v1384_3_cursor.ascend(1);
                }
                drop(v1384_3_cursor);
                drop(v1384_2);
                v1383_3.join_into((v1384_3).clone());
                }
                v1383_3_cursor.ascend(1);
              }
              drop(v1383_3_cursor);
              drop(v1383_2);
              v1382_2.join_into((v1383_3).clone());
              }
              v1382_2_cursor.ascend(1);
            }
            drop(v1382_2_cursor);
            v1381_3.join_into((v1382_2).clone());
            }
            v1381_3_cursor.ascend(1);
          }
          drop(v1381_3_cursor);
          drop(v1381_2);
          v1380_3.join_into((v1381_3).clone());
          }
          v1380_3_cursor.ascend(1);
        }
        drop(v1380_3_cursor);
        drop(v1380_2);
        v1379_3.join_into((v1380_3).clone());
        }
        v1379_3_cursor.ascend(1);
      }
      drop(v1379_3_cursor);
      drop(v1379_2);
      v1378_2.join_into((v1379_3).clone());
      }
      v1378_2_cursor.ascend(1);
    }
    drop(v1378_2_cursor);
    v1377_14.join_into((v1378_2).clone());
    }
    v1377_14_cursor.ascend(1);
  }
  drop(v1377_14_cursor);
  (v1377_14).clone()
}

fn routine_129(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1386_14 = Space::new();
  let mut v1386_14_cursor = (*s0).read_zipper();
  for v1386_14_byte in v1386_14_cursor.child_mask().iter() {
    v1386_14_cursor.descend_to_byte(v1386_14_byte);
    {
    let v1386_14_tail = v1386_14_cursor.fork_read_zipper();
    let v1386_14_head = Path::from_slice(&[v1386_14_byte]);
    let mut v1387_2 = Space::new();
    let mut v1387_2_cursor = (v1386_14_tail).read_zipper();
    for v1387_2_byte in v1387_2_cursor.child_mask().iter() {
      v1387_2_cursor.descend_to_byte(v1387_2_byte);
      {
      let v1387_2_tail = v1387_2_cursor.fork_read_zipper();
      let v1387_2_head = Path::from_slice(&[v1387_2_byte]);
      let v1388_2: Path = concat_path(&(v1386_14_head),&(v1387_2_head));
      let mut v1388_3 = Space::new();
      let mut v1388_3_cursor = (v1387_2_tail).read_zipper();
      for v1388_3_byte in v1388_3_cursor.child_mask().iter() {
        v1388_3_cursor.descend_to_byte(v1388_3_byte);
        {
        let v1388_3_tail = v1388_3_cursor.fork_read_zipper();
        let v1388_3_head = Path::from_slice(&[v1388_3_byte]);
        let v1389_2: Path = concat_path(&(v1388_2),&(v1388_3_head));
        let mut v1389_3 = Space::new();
        let mut v1389_3_cursor = (v1388_3_tail).read_zipper();
        for v1389_3_byte in v1389_3_cursor.child_mask().iter() {
          v1389_3_cursor.descend_to_byte(v1389_3_byte);
          {
          let v1389_3_tail = v1389_3_cursor.fork_read_zipper();
          let v1389_3_head = Path::from_slice(&[v1389_3_byte]);
          let v1390_2: Path = concat_path(&(v1389_2),&(v1389_3_head));
          let mut v1390_3 = Space::new();
          let mut v1390_3_cursor = (v1389_3_tail).read_zipper();
          for v1390_3_byte in v1390_3_cursor.child_mask().iter() {
            v1390_3_cursor.descend_to_byte(v1390_3_byte);
            {
            let v1390_3_tail = v1390_3_cursor.fork_read_zipper();
            let v1390_3_head = Path::from_slice(&[v1390_3_byte]);
            let mut v1391_2 = Space::new();
            let mut v1391_2_cursor = (v1390_3_tail).read_zipper();
            for v1391_2_byte in v1391_2_cursor.child_mask().iter() {
              v1391_2_cursor.descend_to_byte(v1391_2_byte);
              {
              let v1391_2_tail = v1391_2_cursor.fork_read_zipper();
              let v1391_2_head = Path::from_slice(&[v1391_2_byte]);
              let v1392_2: Path = concat_path(&(v1390_3_head),&(v1391_2_head));
              let mut v1392_3 = Space::new();
              let mut v1392_3_cursor = (v1391_2_tail).read_zipper();
              for v1392_3_byte in v1392_3_cursor.child_mask().iter() {
                v1392_3_cursor.descend_to_byte(v1392_3_byte);
                {
                let v1392_3_tail = v1392_3_cursor.fork_read_zipper();
                let v1392_3_head = Path::from_slice(&[v1392_3_byte]);
                let v1393_2: Path = concat_path(&(v1392_2),&(v1392_3_head));
                let mut v1393_3 = Space::new();
                let mut v1393_3_cursor = (v1392_3_tail).read_zipper();
                for v1393_3_byte in v1393_3_cursor.child_mask().iter() {
                  v1393_3_cursor.descend_to_byte(v1393_3_byte);
                  {
                  let v1393_3_tail = v1393_3_cursor.fork_read_zipper();
                  let v1393_3_head = Path::from_slice(&[v1393_3_byte]);
                  let v1394_2: Path = concat_path(&(v1393_2),&(v1393_3_head));
                  let v1394_3: Space = routine_145(c, &(v1394_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1390_2), &(v1393_3_tail).make_space());
                  drop(v1394_2);
                  v1393_3.join_into((v1394_3).clone());
                  }
                  v1393_3_cursor.ascend(1);
                }
                drop(v1393_3_cursor);
                drop(v1393_2);
                v1392_3.join_into((v1393_3).clone());
                }
                v1392_3_cursor.ascend(1);
              }
              drop(v1392_3_cursor);
              drop(v1392_2);
              v1391_2.join_into((v1392_3).clone());
              }
              v1391_2_cursor.ascend(1);
            }
            drop(v1391_2_cursor);
            v1390_3.join_into((v1391_2).clone());
            }
            v1390_3_cursor.ascend(1);
          }
          drop(v1390_3_cursor);
          drop(v1390_2);
          v1389_3.join_into((v1390_3).clone());
          }
          v1389_3_cursor.ascend(1);
        }
        drop(v1389_3_cursor);
        drop(v1389_2);
        v1388_3.join_into((v1389_3).clone());
        }
        v1388_3_cursor.ascend(1);
      }
      drop(v1388_3_cursor);
      drop(v1388_2);
      v1387_2.join_into((v1388_3).clone());
      }
      v1387_2_cursor.ascend(1);
    }
    drop(v1387_2_cursor);
    v1386_14.join_into((v1387_2).clone());
    }
    v1386_14_cursor.ascend(1);
  }
  drop(v1386_14_cursor);
  (v1386_14).clone()
}

fn routine_130(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1395_14 = Space::new();
  let mut v1395_14_cursor = (*s0).read_zipper();
  for v1395_14_byte in v1395_14_cursor.child_mask().iter() {
    v1395_14_cursor.descend_to_byte(v1395_14_byte);
    {
    let v1395_14_tail = v1395_14_cursor.fork_read_zipper();
    let v1395_14_head = Path::from_slice(&[v1395_14_byte]);
    let mut v1396_2 = Space::new();
    let mut v1396_2_cursor = (v1395_14_tail).read_zipper();
    for v1396_2_byte in v1396_2_cursor.child_mask().iter() {
      v1396_2_cursor.descend_to_byte(v1396_2_byte);
      {
      let v1396_2_tail = v1396_2_cursor.fork_read_zipper();
      let v1396_2_head = Path::from_slice(&[v1396_2_byte]);
      let v1397_2: Path = concat_path(&(v1395_14_head),&(v1396_2_head));
      let mut v1397_3 = Space::new();
      let mut v1397_3_cursor = (v1396_2_tail).read_zipper();
      for v1397_3_byte in v1397_3_cursor.child_mask().iter() {
        v1397_3_cursor.descend_to_byte(v1397_3_byte);
        {
        let v1397_3_tail = v1397_3_cursor.fork_read_zipper();
        let v1397_3_head = Path::from_slice(&[v1397_3_byte]);
        let v1398_2: Path = concat_path(&(v1397_2),&(v1397_3_head));
        let mut v1398_3 = Space::new();
        let mut v1398_3_cursor = (v1397_3_tail).read_zipper();
        for v1398_3_byte in v1398_3_cursor.child_mask().iter() {
          v1398_3_cursor.descend_to_byte(v1398_3_byte);
          {
          let v1398_3_tail = v1398_3_cursor.fork_read_zipper();
          let v1398_3_head = Path::from_slice(&[v1398_3_byte]);
          let v1399_2: Path = concat_path(&(v1398_2),&(v1398_3_head));
          let mut v1399_3 = Space::new();
          let mut v1399_3_cursor = (v1398_3_tail).read_zipper();
          for v1399_3_byte in v1399_3_cursor.child_mask().iter() {
            v1399_3_cursor.descend_to_byte(v1399_3_byte);
            {
            let v1399_3_tail = v1399_3_cursor.fork_read_zipper();
            let v1399_3_head = Path::from_slice(&[v1399_3_byte]);
            let mut v1400_2 = Space::new();
            let mut v1400_2_cursor = (v1399_3_tail).read_zipper();
            for v1400_2_byte in v1400_2_cursor.child_mask().iter() {
              v1400_2_cursor.descend_to_byte(v1400_2_byte);
              {
              let v1400_2_tail = v1400_2_cursor.fork_read_zipper();
              let v1400_2_head = Path::from_slice(&[v1400_2_byte]);
              let v1401_2: Path = concat_path(&(v1399_3_head),&(v1400_2_head));
              let mut v1401_3 = Space::new();
              let mut v1401_3_cursor = (v1400_2_tail).read_zipper();
              for v1401_3_byte in v1401_3_cursor.child_mask().iter() {
                v1401_3_cursor.descend_to_byte(v1401_3_byte);
                {
                let v1401_3_tail = v1401_3_cursor.fork_read_zipper();
                let v1401_3_head = Path::from_slice(&[v1401_3_byte]);
                let v1402_2: Path = concat_path(&(v1401_2),&(v1401_3_head));
                let mut v1402_3 = Space::new();
                let mut v1402_3_cursor = (v1401_3_tail).read_zipper();
                for v1402_3_byte in v1402_3_cursor.child_mask().iter() {
                  v1402_3_cursor.descend_to_byte(v1402_3_byte);
                  {
                  let v1402_3_tail = v1402_3_cursor.fork_read_zipper();
                  let v1402_3_head = Path::from_slice(&[v1402_3_byte]);
                  let v1403_2: Path = concat_path(&(v1402_2),&(v1402_3_head));
                  let v1403_3: Space = routine_146(c, &(v1403_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1399_2), &(v1402_3_tail).make_space());
                  drop(v1403_2);
                  v1402_3.join_into((v1403_3).clone());
                  }
                  v1402_3_cursor.ascend(1);
                }
                drop(v1402_3_cursor);
                drop(v1402_2);
                v1401_3.join_into((v1402_3).clone());
                }
                v1401_3_cursor.ascend(1);
              }
              drop(v1401_3_cursor);
              drop(v1401_2);
              v1400_2.join_into((v1401_3).clone());
              }
              v1400_2_cursor.ascend(1);
            }
            drop(v1400_2_cursor);
            v1399_3.join_into((v1400_2).clone());
            }
            v1399_3_cursor.ascend(1);
          }
          drop(v1399_3_cursor);
          drop(v1399_2);
          v1398_3.join_into((v1399_3).clone());
          }
          v1398_3_cursor.ascend(1);
        }
        drop(v1398_3_cursor);
        drop(v1398_2);
        v1397_3.join_into((v1398_3).clone());
        }
        v1397_3_cursor.ascend(1);
      }
      drop(v1397_3_cursor);
      drop(v1397_2);
      v1396_2.join_into((v1397_3).clone());
      }
      v1396_2_cursor.ascend(1);
    }
    drop(v1396_2_cursor);
    v1395_14.join_into((v1396_2).clone());
    }
    v1395_14_cursor.ascend(1);
  }
  drop(v1395_14_cursor);
  (v1395_14).clone()
}

fn routine_131(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1404_14 = Space::new();
  let mut v1404_14_cursor = (*s0).read_zipper();
  for v1404_14_byte in v1404_14_cursor.child_mask().iter() {
    v1404_14_cursor.descend_to_byte(v1404_14_byte);
    {
    let v1404_14_tail = v1404_14_cursor.fork_read_zipper();
    let v1404_14_head = Path::from_slice(&[v1404_14_byte]);
    let mut v1405_2 = Space::new();
    let mut v1405_2_cursor = (v1404_14_tail).read_zipper();
    for v1405_2_byte in v1405_2_cursor.child_mask().iter() {
      v1405_2_cursor.descend_to_byte(v1405_2_byte);
      {
      let v1405_2_tail = v1405_2_cursor.fork_read_zipper();
      let v1405_2_head = Path::from_slice(&[v1405_2_byte]);
      let v1406_2: Path = concat_path(&(v1404_14_head),&(v1405_2_head));
      let mut v1406_3 = Space::new();
      let mut v1406_3_cursor = (v1405_2_tail).read_zipper();
      for v1406_3_byte in v1406_3_cursor.child_mask().iter() {
        v1406_3_cursor.descend_to_byte(v1406_3_byte);
        {
        let v1406_3_tail = v1406_3_cursor.fork_read_zipper();
        let v1406_3_head = Path::from_slice(&[v1406_3_byte]);
        let v1407_2: Path = concat_path(&(v1406_2),&(v1406_3_head));
        let mut v1407_3 = Space::new();
        let mut v1407_3_cursor = (v1406_3_tail).read_zipper();
        for v1407_3_byte in v1407_3_cursor.child_mask().iter() {
          v1407_3_cursor.descend_to_byte(v1407_3_byte);
          {
          let v1407_3_tail = v1407_3_cursor.fork_read_zipper();
          let v1407_3_head = Path::from_slice(&[v1407_3_byte]);
          let v1408_2: Path = concat_path(&(v1407_2),&(v1407_3_head));
          let mut v1408_3 = Space::new();
          let mut v1408_3_cursor = (v1407_3_tail).read_zipper();
          for v1408_3_byte in v1408_3_cursor.child_mask().iter() {
            v1408_3_cursor.descend_to_byte(v1408_3_byte);
            {
            let v1408_3_tail = v1408_3_cursor.fork_read_zipper();
            let v1408_3_head = Path::from_slice(&[v1408_3_byte]);
            let mut v1409_2 = Space::new();
            let mut v1409_2_cursor = (v1408_3_tail).read_zipper();
            for v1409_2_byte in v1409_2_cursor.child_mask().iter() {
              v1409_2_cursor.descend_to_byte(v1409_2_byte);
              {
              let v1409_2_tail = v1409_2_cursor.fork_read_zipper();
              let v1409_2_head = Path::from_slice(&[v1409_2_byte]);
              let v1410_2: Path = concat_path(&(v1408_3_head),&(v1409_2_head));
              let mut v1410_3 = Space::new();
              let mut v1410_3_cursor = (v1409_2_tail).read_zipper();
              for v1410_3_byte in v1410_3_cursor.child_mask().iter() {
                v1410_3_cursor.descend_to_byte(v1410_3_byte);
                {
                let v1410_3_tail = v1410_3_cursor.fork_read_zipper();
                let v1410_3_head = Path::from_slice(&[v1410_3_byte]);
                let v1411_2: Path = concat_path(&(v1410_2),&(v1410_3_head));
                let mut v1411_3 = Space::new();
                let mut v1411_3_cursor = (v1410_3_tail).read_zipper();
                for v1411_3_byte in v1411_3_cursor.child_mask().iter() {
                  v1411_3_cursor.descend_to_byte(v1411_3_byte);
                  {
                  let v1411_3_tail = v1411_3_cursor.fork_read_zipper();
                  let v1411_3_head = Path::from_slice(&[v1411_3_byte]);
                  let v1412_2: Path = concat_path(&(v1411_2),&(v1411_3_head));
                  let v1412_3: Space = routine_147(c, &(v1412_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1408_2), &(v1411_3_tail).make_space());
                  drop(v1412_2);
                  v1411_3.join_into((v1412_3).clone());
                  }
                  v1411_3_cursor.ascend(1);
                }
                drop(v1411_3_cursor);
                drop(v1411_2);
                v1410_3.join_into((v1411_3).clone());
                }
                v1410_3_cursor.ascend(1);
              }
              drop(v1410_3_cursor);
              drop(v1410_2);
              v1409_2.join_into((v1410_3).clone());
              }
              v1409_2_cursor.ascend(1);
            }
            drop(v1409_2_cursor);
            v1408_3.join_into((v1409_2).clone());
            }
            v1408_3_cursor.ascend(1);
          }
          drop(v1408_3_cursor);
          drop(v1408_2);
          v1407_3.join_into((v1408_3).clone());
          }
          v1407_3_cursor.ascend(1);
        }
        drop(v1407_3_cursor);
        drop(v1407_2);
        v1406_3.join_into((v1407_3).clone());
        }
        v1406_3_cursor.ascend(1);
      }
      drop(v1406_3_cursor);
      drop(v1406_2);
      v1405_2.join_into((v1406_3).clone());
      }
      v1405_2_cursor.ascend(1);
    }
    drop(v1405_2_cursor);
    v1404_14.join_into((v1405_2).clone());
    }
    v1404_14_cursor.ascend(1);
  }
  drop(v1404_14_cursor);
  (v1404_14).clone()
}

fn routine_132(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1413_14 = Space::new();
  let mut v1413_14_cursor = (*s0).read_zipper();
  for v1413_14_byte in v1413_14_cursor.child_mask().iter() {
    v1413_14_cursor.descend_to_byte(v1413_14_byte);
    {
    let v1413_14_tail = v1413_14_cursor.fork_read_zipper();
    let v1413_14_head = Path::from_slice(&[v1413_14_byte]);
    let mut v1414_2 = Space::new();
    let mut v1414_2_cursor = (v1413_14_tail).read_zipper();
    for v1414_2_byte in v1414_2_cursor.child_mask().iter() {
      v1414_2_cursor.descend_to_byte(v1414_2_byte);
      {
      let v1414_2_tail = v1414_2_cursor.fork_read_zipper();
      let v1414_2_head = Path::from_slice(&[v1414_2_byte]);
      let v1415_2: Path = concat_path(&(v1413_14_head),&(v1414_2_head));
      let mut v1415_3 = Space::new();
      let mut v1415_3_cursor = (v1414_2_tail).read_zipper();
      for v1415_3_byte in v1415_3_cursor.child_mask().iter() {
        v1415_3_cursor.descend_to_byte(v1415_3_byte);
        {
        let v1415_3_tail = v1415_3_cursor.fork_read_zipper();
        let v1415_3_head = Path::from_slice(&[v1415_3_byte]);
        let v1416_2: Path = concat_path(&(v1415_2),&(v1415_3_head));
        let mut v1416_3 = Space::new();
        let mut v1416_3_cursor = (v1415_3_tail).read_zipper();
        for v1416_3_byte in v1416_3_cursor.child_mask().iter() {
          v1416_3_cursor.descend_to_byte(v1416_3_byte);
          {
          let v1416_3_tail = v1416_3_cursor.fork_read_zipper();
          let v1416_3_head = Path::from_slice(&[v1416_3_byte]);
          let v1417_2: Path = concat_path(&(v1416_2),&(v1416_3_head));
          let mut v1417_3 = Space::new();
          let mut v1417_3_cursor = (v1416_3_tail).read_zipper();
          for v1417_3_byte in v1417_3_cursor.child_mask().iter() {
            v1417_3_cursor.descend_to_byte(v1417_3_byte);
            {
            let v1417_3_tail = v1417_3_cursor.fork_read_zipper();
            let v1417_3_head = Path::from_slice(&[v1417_3_byte]);
            let mut v1418_2 = Space::new();
            let mut v1418_2_cursor = (v1417_3_tail).read_zipper();
            for v1418_2_byte in v1418_2_cursor.child_mask().iter() {
              v1418_2_cursor.descend_to_byte(v1418_2_byte);
              {
              let v1418_2_tail = v1418_2_cursor.fork_read_zipper();
              let v1418_2_head = Path::from_slice(&[v1418_2_byte]);
              let v1419_2: Path = concat_path(&(v1417_3_head),&(v1418_2_head));
              let mut v1419_3 = Space::new();
              let mut v1419_3_cursor = (v1418_2_tail).read_zipper();
              for v1419_3_byte in v1419_3_cursor.child_mask().iter() {
                v1419_3_cursor.descend_to_byte(v1419_3_byte);
                {
                let v1419_3_tail = v1419_3_cursor.fork_read_zipper();
                let v1419_3_head = Path::from_slice(&[v1419_3_byte]);
                let v1420_2: Path = concat_path(&(v1419_2),&(v1419_3_head));
                let mut v1420_3 = Space::new();
                let mut v1420_3_cursor = (v1419_3_tail).read_zipper();
                for v1420_3_byte in v1420_3_cursor.child_mask().iter() {
                  v1420_3_cursor.descend_to_byte(v1420_3_byte);
                  {
                  let v1420_3_tail = v1420_3_cursor.fork_read_zipper();
                  let v1420_3_head = Path::from_slice(&[v1420_3_byte]);
                  let v1421_2: Path = concat_path(&(v1420_2),&(v1420_3_head));
                  let v1421_3: Space = routine_148(c, &(v1421_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1417_2), &(v1420_3_tail).make_space());
                  drop(v1421_2);
                  v1420_3.join_into((v1421_3).clone());
                  }
                  v1420_3_cursor.ascend(1);
                }
                drop(v1420_3_cursor);
                drop(v1420_2);
                v1419_3.join_into((v1420_3).clone());
                }
                v1419_3_cursor.ascend(1);
              }
              drop(v1419_3_cursor);
              drop(v1419_2);
              v1418_2.join_into((v1419_3).clone());
              }
              v1418_2_cursor.ascend(1);
            }
            drop(v1418_2_cursor);
            v1417_3.join_into((v1418_2).clone());
            }
            v1417_3_cursor.ascend(1);
          }
          drop(v1417_3_cursor);
          drop(v1417_2);
          v1416_3.join_into((v1417_3).clone());
          }
          v1416_3_cursor.ascend(1);
        }
        drop(v1416_3_cursor);
        drop(v1416_2);
        v1415_3.join_into((v1416_3).clone());
        }
        v1415_3_cursor.ascend(1);
      }
      drop(v1415_3_cursor);
      drop(v1415_2);
      v1414_2.join_into((v1415_3).clone());
      }
      v1414_2_cursor.ascend(1);
    }
    drop(v1414_2_cursor);
    v1413_14.join_into((v1414_2).clone());
    }
    v1413_14_cursor.ascend(1);
  }
  drop(v1413_14_cursor);
  (v1413_14).clone()
}

fn routine_133(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1422_14 = Space::new();
  let mut v1422_14_cursor = (*s0).read_zipper();
  for v1422_14_byte in v1422_14_cursor.child_mask().iter() {
    v1422_14_cursor.descend_to_byte(v1422_14_byte);
    {
    let v1422_14_tail = v1422_14_cursor.fork_read_zipper();
    let v1422_14_head = Path::from_slice(&[v1422_14_byte]);
    let mut v1423_2 = Space::new();
    let mut v1423_2_cursor = (v1422_14_tail).read_zipper();
    for v1423_2_byte in v1423_2_cursor.child_mask().iter() {
      v1423_2_cursor.descend_to_byte(v1423_2_byte);
      {
      let v1423_2_tail = v1423_2_cursor.fork_read_zipper();
      let v1423_2_head = Path::from_slice(&[v1423_2_byte]);
      let v1424_2: Path = concat_path(&(v1422_14_head),&(v1423_2_head));
      let mut v1424_3 = Space::new();
      let mut v1424_3_cursor = (v1423_2_tail).read_zipper();
      for v1424_3_byte in v1424_3_cursor.child_mask().iter() {
        v1424_3_cursor.descend_to_byte(v1424_3_byte);
        {
        let v1424_3_tail = v1424_3_cursor.fork_read_zipper();
        let v1424_3_head = Path::from_slice(&[v1424_3_byte]);
        let v1425_2: Path = concat_path(&(v1424_2),&(v1424_3_head));
        let mut v1425_3 = Space::new();
        let mut v1425_3_cursor = (v1424_3_tail).read_zipper();
        for v1425_3_byte in v1425_3_cursor.child_mask().iter() {
          v1425_3_cursor.descend_to_byte(v1425_3_byte);
          {
          let v1425_3_tail = v1425_3_cursor.fork_read_zipper();
          let v1425_3_head = Path::from_slice(&[v1425_3_byte]);
          let v1426_2: Path = concat_path(&(v1425_2),&(v1425_3_head));
          let mut v1426_3 = Space::new();
          let mut v1426_3_cursor = (v1425_3_tail).read_zipper();
          for v1426_3_byte in v1426_3_cursor.child_mask().iter() {
            v1426_3_cursor.descend_to_byte(v1426_3_byte);
            {
            let v1426_3_tail = v1426_3_cursor.fork_read_zipper();
            let v1426_3_head = Path::from_slice(&[v1426_3_byte]);
            let mut v1427_2 = Space::new();
            let mut v1427_2_cursor = (v1426_3_tail).read_zipper();
            for v1427_2_byte in v1427_2_cursor.child_mask().iter() {
              v1427_2_cursor.descend_to_byte(v1427_2_byte);
              {
              let v1427_2_tail = v1427_2_cursor.fork_read_zipper();
              let v1427_2_head = Path::from_slice(&[v1427_2_byte]);
              let v1428_2: Path = concat_path(&(v1426_3_head),&(v1427_2_head));
              let mut v1428_3 = Space::new();
              let mut v1428_3_cursor = (v1427_2_tail).read_zipper();
              for v1428_3_byte in v1428_3_cursor.child_mask().iter() {
                v1428_3_cursor.descend_to_byte(v1428_3_byte);
                {
                let v1428_3_tail = v1428_3_cursor.fork_read_zipper();
                let v1428_3_head = Path::from_slice(&[v1428_3_byte]);
                let v1429_2: Path = concat_path(&(v1428_2),&(v1428_3_head));
                let mut v1429_3 = Space::new();
                let mut v1429_3_cursor = (v1428_3_tail).read_zipper();
                for v1429_3_byte in v1429_3_cursor.child_mask().iter() {
                  v1429_3_cursor.descend_to_byte(v1429_3_byte);
                  {
                  let v1429_3_tail = v1429_3_cursor.fork_read_zipper();
                  let v1429_3_head = Path::from_slice(&[v1429_3_byte]);
                  let v1430_2: Path = concat_path(&(v1429_2),&(v1429_3_head));
                  let v1430_3: Space = routine_149(c, &(v1430_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1426_2), &(v1429_3_tail).make_space());
                  drop(v1430_2);
                  v1429_3.join_into((v1430_3).clone());
                  }
                  v1429_3_cursor.ascend(1);
                }
                drop(v1429_3_cursor);
                drop(v1429_2);
                v1428_3.join_into((v1429_3).clone());
                }
                v1428_3_cursor.ascend(1);
              }
              drop(v1428_3_cursor);
              drop(v1428_2);
              v1427_2.join_into((v1428_3).clone());
              }
              v1427_2_cursor.ascend(1);
            }
            drop(v1427_2_cursor);
            v1426_3.join_into((v1427_2).clone());
            }
            v1426_3_cursor.ascend(1);
          }
          drop(v1426_3_cursor);
          drop(v1426_2);
          v1425_3.join_into((v1426_3).clone());
          }
          v1425_3_cursor.ascend(1);
        }
        drop(v1425_3_cursor);
        drop(v1425_2);
        v1424_3.join_into((v1425_3).clone());
        }
        v1424_3_cursor.ascend(1);
      }
      drop(v1424_3_cursor);
      drop(v1424_2);
      v1423_2.join_into((v1424_3).clone());
      }
      v1423_2_cursor.ascend(1);
    }
    drop(v1423_2_cursor);
    v1422_14.join_into((v1423_2).clone());
    }
    v1422_14_cursor.ascend(1);
  }
  drop(v1422_14_cursor);
  (v1422_14).clone()
}

fn routine_134(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1431_14 = Space::new();
  let mut v1431_14_cursor = (*s0).read_zipper();
  for v1431_14_byte in v1431_14_cursor.child_mask().iter() {
    v1431_14_cursor.descend_to_byte(v1431_14_byte);
    {
    let v1431_14_tail = v1431_14_cursor.fork_read_zipper();
    let v1431_14_head = Path::from_slice(&[v1431_14_byte]);
    let mut v1432_2 = Space::new();
    let mut v1432_2_cursor = (v1431_14_tail).read_zipper();
    for v1432_2_byte in v1432_2_cursor.child_mask().iter() {
      v1432_2_cursor.descend_to_byte(v1432_2_byte);
      {
      let v1432_2_tail = v1432_2_cursor.fork_read_zipper();
      let v1432_2_head = Path::from_slice(&[v1432_2_byte]);
      let v1433_2: Path = concat_path(&(v1431_14_head),&(v1432_2_head));
      let mut v1433_3 = Space::new();
      let mut v1433_3_cursor = (v1432_2_tail).read_zipper();
      for v1433_3_byte in v1433_3_cursor.child_mask().iter() {
        v1433_3_cursor.descend_to_byte(v1433_3_byte);
        {
        let v1433_3_tail = v1433_3_cursor.fork_read_zipper();
        let v1433_3_head = Path::from_slice(&[v1433_3_byte]);
        let v1434_2: Path = concat_path(&(v1433_2),&(v1433_3_head));
        let mut v1434_3 = Space::new();
        let mut v1434_3_cursor = (v1433_3_tail).read_zipper();
        for v1434_3_byte in v1434_3_cursor.child_mask().iter() {
          v1434_3_cursor.descend_to_byte(v1434_3_byte);
          {
          let v1434_3_tail = v1434_3_cursor.fork_read_zipper();
          let v1434_3_head = Path::from_slice(&[v1434_3_byte]);
          let v1435_2: Path = concat_path(&(v1434_2),&(v1434_3_head));
          let mut v1435_3 = Space::new();
          let mut v1435_3_cursor = (v1434_3_tail).read_zipper();
          for v1435_3_byte in v1435_3_cursor.child_mask().iter() {
            v1435_3_cursor.descend_to_byte(v1435_3_byte);
            {
            let v1435_3_tail = v1435_3_cursor.fork_read_zipper();
            let v1435_3_head = Path::from_slice(&[v1435_3_byte]);
            let mut v1436_2 = Space::new();
            let mut v1436_2_cursor = (v1435_3_tail).read_zipper();
            for v1436_2_byte in v1436_2_cursor.child_mask().iter() {
              v1436_2_cursor.descend_to_byte(v1436_2_byte);
              {
              let v1436_2_tail = v1436_2_cursor.fork_read_zipper();
              let v1436_2_head = Path::from_slice(&[v1436_2_byte]);
              let v1437_2: Path = concat_path(&(v1435_3_head),&(v1436_2_head));
              let mut v1437_3 = Space::new();
              let mut v1437_3_cursor = (v1436_2_tail).read_zipper();
              for v1437_3_byte in v1437_3_cursor.child_mask().iter() {
                v1437_3_cursor.descend_to_byte(v1437_3_byte);
                {
                let v1437_3_tail = v1437_3_cursor.fork_read_zipper();
                let v1437_3_head = Path::from_slice(&[v1437_3_byte]);
                let v1438_2: Path = concat_path(&(v1437_2),&(v1437_3_head));
                let mut v1438_3 = Space::new();
                let mut v1438_3_cursor = (v1437_3_tail).read_zipper();
                for v1438_3_byte in v1438_3_cursor.child_mask().iter() {
                  v1438_3_cursor.descend_to_byte(v1438_3_byte);
                  {
                  let v1438_3_tail = v1438_3_cursor.fork_read_zipper();
                  let v1438_3_head = Path::from_slice(&[v1438_3_byte]);
                  let v1439_2: Path = concat_path(&(v1438_2),&(v1438_3_head));
                  let v1439_3: Space = routine_150(c, &(v1439_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1435_2), &(v1438_3_tail).make_space());
                  drop(v1439_2);
                  v1438_3.join_into((v1439_3).clone());
                  }
                  v1438_3_cursor.ascend(1);
                }
                drop(v1438_3_cursor);
                drop(v1438_2);
                v1437_3.join_into((v1438_3).clone());
                }
                v1437_3_cursor.ascend(1);
              }
              drop(v1437_3_cursor);
              drop(v1437_2);
              v1436_2.join_into((v1437_3).clone());
              }
              v1436_2_cursor.ascend(1);
            }
            drop(v1436_2_cursor);
            v1435_3.join_into((v1436_2).clone());
            }
            v1435_3_cursor.ascend(1);
          }
          drop(v1435_3_cursor);
          drop(v1435_2);
          v1434_3.join_into((v1435_3).clone());
          }
          v1434_3_cursor.ascend(1);
        }
        drop(v1434_3_cursor);
        drop(v1434_2);
        v1433_3.join_into((v1434_3).clone());
        }
        v1433_3_cursor.ascend(1);
      }
      drop(v1433_3_cursor);
      drop(v1433_2);
      v1432_2.join_into((v1433_3).clone());
      }
      v1432_2_cursor.ascend(1);
    }
    drop(v1432_2_cursor);
    v1431_14.join_into((v1432_2).clone());
    }
    v1431_14_cursor.ascend(1);
  }
  drop(v1431_14_cursor);
  (v1431_14).clone()
}

fn routine_135(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1440_14 = Space::new();
  let mut v1440_14_cursor = (*s0).read_zipper();
  for v1440_14_byte in v1440_14_cursor.child_mask().iter() {
    v1440_14_cursor.descend_to_byte(v1440_14_byte);
    {
    let v1440_14_tail = v1440_14_cursor.fork_read_zipper();
    let v1440_14_head = Path::from_slice(&[v1440_14_byte]);
    let mut v1441_2 = Space::new();
    let mut v1441_2_cursor = (v1440_14_tail).read_zipper();
    for v1441_2_byte in v1441_2_cursor.child_mask().iter() {
      v1441_2_cursor.descend_to_byte(v1441_2_byte);
      {
      let v1441_2_tail = v1441_2_cursor.fork_read_zipper();
      let v1441_2_head = Path::from_slice(&[v1441_2_byte]);
      let v1442_2: Path = concat_path(&(v1440_14_head),&(v1441_2_head));
      let mut v1442_3 = Space::new();
      let mut v1442_3_cursor = (v1441_2_tail).read_zipper();
      for v1442_3_byte in v1442_3_cursor.child_mask().iter() {
        v1442_3_cursor.descend_to_byte(v1442_3_byte);
        {
        let v1442_3_tail = v1442_3_cursor.fork_read_zipper();
        let v1442_3_head = Path::from_slice(&[v1442_3_byte]);
        let v1443_2: Path = concat_path(&(v1442_2),&(v1442_3_head));
        let mut v1443_3 = Space::new();
        let mut v1443_3_cursor = (v1442_3_tail).read_zipper();
        for v1443_3_byte in v1443_3_cursor.child_mask().iter() {
          v1443_3_cursor.descend_to_byte(v1443_3_byte);
          {
          let v1443_3_tail = v1443_3_cursor.fork_read_zipper();
          let v1443_3_head = Path::from_slice(&[v1443_3_byte]);
          let v1444_2: Path = concat_path(&(v1443_2),&(v1443_3_head));
          let mut v1444_3 = Space::new();
          let mut v1444_3_cursor = (v1443_3_tail).read_zipper();
          for v1444_3_byte in v1444_3_cursor.child_mask().iter() {
            v1444_3_cursor.descend_to_byte(v1444_3_byte);
            {
            let v1444_3_tail = v1444_3_cursor.fork_read_zipper();
            let v1444_3_head = Path::from_slice(&[v1444_3_byte]);
            let mut v1445_2 = Space::new();
            let mut v1445_2_cursor = (v1444_3_tail).read_zipper();
            for v1445_2_byte in v1445_2_cursor.child_mask().iter() {
              v1445_2_cursor.descend_to_byte(v1445_2_byte);
              {
              let v1445_2_tail = v1445_2_cursor.fork_read_zipper();
              let v1445_2_head = Path::from_slice(&[v1445_2_byte]);
              let v1446_2: Path = concat_path(&(v1444_3_head),&(v1445_2_head));
              let mut v1446_3 = Space::new();
              let mut v1446_3_cursor = (v1445_2_tail).read_zipper();
              for v1446_3_byte in v1446_3_cursor.child_mask().iter() {
                v1446_3_cursor.descend_to_byte(v1446_3_byte);
                {
                let v1446_3_tail = v1446_3_cursor.fork_read_zipper();
                let v1446_3_head = Path::from_slice(&[v1446_3_byte]);
                let v1447_2: Path = concat_path(&(v1446_2),&(v1446_3_head));
                let mut v1447_3 = Space::new();
                let mut v1447_3_cursor = (v1446_3_tail).read_zipper();
                for v1447_3_byte in v1447_3_cursor.child_mask().iter() {
                  v1447_3_cursor.descend_to_byte(v1447_3_byte);
                  {
                  let v1447_3_tail = v1447_3_cursor.fork_read_zipper();
                  let v1447_3_head = Path::from_slice(&[v1447_3_byte]);
                  let v1448_2: Path = concat_path(&(v1447_2),&(v1447_3_head));
                  let v1448_3: Space = routine_151(c, &(v1448_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1444_2), &(v1447_3_tail).make_space());
                  drop(v1448_2);
                  v1447_3.join_into((v1448_3).clone());
                  }
                  v1447_3_cursor.ascend(1);
                }
                drop(v1447_3_cursor);
                drop(v1447_2);
                v1446_3.join_into((v1447_3).clone());
                }
                v1446_3_cursor.ascend(1);
              }
              drop(v1446_3_cursor);
              drop(v1446_2);
              v1445_2.join_into((v1446_3).clone());
              }
              v1445_2_cursor.ascend(1);
            }
            drop(v1445_2_cursor);
            v1444_3.join_into((v1445_2).clone());
            }
            v1444_3_cursor.ascend(1);
          }
          drop(v1444_3_cursor);
          drop(v1444_2);
          v1443_3.join_into((v1444_3).clone());
          }
          v1443_3_cursor.ascend(1);
        }
        drop(v1443_3_cursor);
        drop(v1443_2);
        v1442_3.join_into((v1443_3).clone());
        }
        v1442_3_cursor.ascend(1);
      }
      drop(v1442_3_cursor);
      drop(v1442_2);
      v1441_2.join_into((v1442_3).clone());
      }
      v1441_2_cursor.ascend(1);
    }
    drop(v1441_2_cursor);
    v1440_14.join_into((v1441_2).clone());
    }
    v1440_14_cursor.ascend(1);
  }
  drop(v1440_14_cursor);
  (v1440_14).clone()
}

fn routine_136(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1449_14 = Space::new();
  let mut v1449_14_cursor = (*s0).read_zipper();
  for v1449_14_byte in v1449_14_cursor.child_mask().iter() {
    v1449_14_cursor.descend_to_byte(v1449_14_byte);
    {
    let v1449_14_tail = v1449_14_cursor.fork_read_zipper();
    let v1449_14_head = Path::from_slice(&[v1449_14_byte]);
    let mut v1450_2 = Space::new();
    let mut v1450_2_cursor = (v1449_14_tail).read_zipper();
    for v1450_2_byte in v1450_2_cursor.child_mask().iter() {
      v1450_2_cursor.descend_to_byte(v1450_2_byte);
      {
      let v1450_2_tail = v1450_2_cursor.fork_read_zipper();
      let v1450_2_head = Path::from_slice(&[v1450_2_byte]);
      let v1451_2: Path = concat_path(&(v1449_14_head),&(v1450_2_head));
      let mut v1451_3 = Space::new();
      let mut v1451_3_cursor = (v1450_2_tail).read_zipper();
      for v1451_3_byte in v1451_3_cursor.child_mask().iter() {
        v1451_3_cursor.descend_to_byte(v1451_3_byte);
        {
        let v1451_3_tail = v1451_3_cursor.fork_read_zipper();
        let v1451_3_head = Path::from_slice(&[v1451_3_byte]);
        let v1452_2: Path = concat_path(&(v1451_2),&(v1451_3_head));
        let mut v1452_3 = Space::new();
        let mut v1452_3_cursor = (v1451_3_tail).read_zipper();
        for v1452_3_byte in v1452_3_cursor.child_mask().iter() {
          v1452_3_cursor.descend_to_byte(v1452_3_byte);
          {
          let v1452_3_tail = v1452_3_cursor.fork_read_zipper();
          let v1452_3_head = Path::from_slice(&[v1452_3_byte]);
          let v1453_2: Path = concat_path(&(v1452_2),&(v1452_3_head));
          let mut v1453_3 = Space::new();
          let mut v1453_3_cursor = (v1452_3_tail).read_zipper();
          for v1453_3_byte in v1453_3_cursor.child_mask().iter() {
            v1453_3_cursor.descend_to_byte(v1453_3_byte);
            {
            let v1453_3_tail = v1453_3_cursor.fork_read_zipper();
            let v1453_3_head = Path::from_slice(&[v1453_3_byte]);
            let mut v1454_2 = Space::new();
            let mut v1454_2_cursor = (v1453_3_tail).read_zipper();
            for v1454_2_byte in v1454_2_cursor.child_mask().iter() {
              v1454_2_cursor.descend_to_byte(v1454_2_byte);
              {
              let v1454_2_tail = v1454_2_cursor.fork_read_zipper();
              let v1454_2_head = Path::from_slice(&[v1454_2_byte]);
              let v1455_2: Path = concat_path(&(v1453_3_head),&(v1454_2_head));
              let mut v1455_3 = Space::new();
              let mut v1455_3_cursor = (v1454_2_tail).read_zipper();
              for v1455_3_byte in v1455_3_cursor.child_mask().iter() {
                v1455_3_cursor.descend_to_byte(v1455_3_byte);
                {
                let v1455_3_tail = v1455_3_cursor.fork_read_zipper();
                let v1455_3_head = Path::from_slice(&[v1455_3_byte]);
                let v1456_2: Path = concat_path(&(v1455_2),&(v1455_3_head));
                let mut v1456_3 = Space::new();
                let mut v1456_3_cursor = (v1455_3_tail).read_zipper();
                for v1456_3_byte in v1456_3_cursor.child_mask().iter() {
                  v1456_3_cursor.descend_to_byte(v1456_3_byte);
                  {
                  let v1456_3_tail = v1456_3_cursor.fork_read_zipper();
                  let v1456_3_head = Path::from_slice(&[v1456_3_byte]);
                  let v1457_2: Path = concat_path(&(v1456_2),&(v1456_3_head));
                  let v1457_3: Space = routine_152(c, &(v1457_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1453_2), &(v1456_3_tail).make_space());
                  drop(v1457_2);
                  v1456_3.join_into((v1457_3).clone());
                  }
                  v1456_3_cursor.ascend(1);
                }
                drop(v1456_3_cursor);
                drop(v1456_2);
                v1455_3.join_into((v1456_3).clone());
                }
                v1455_3_cursor.ascend(1);
              }
              drop(v1455_3_cursor);
              drop(v1455_2);
              v1454_2.join_into((v1455_3).clone());
              }
              v1454_2_cursor.ascend(1);
            }
            drop(v1454_2_cursor);
            v1453_3.join_into((v1454_2).clone());
            }
            v1453_3_cursor.ascend(1);
          }
          drop(v1453_3_cursor);
          drop(v1453_2);
          v1452_3.join_into((v1453_3).clone());
          }
          v1452_3_cursor.ascend(1);
        }
        drop(v1452_3_cursor);
        drop(v1452_2);
        v1451_3.join_into((v1452_3).clone());
        }
        v1451_3_cursor.ascend(1);
      }
      drop(v1451_3_cursor);
      drop(v1451_2);
      v1450_2.join_into((v1451_3).clone());
      }
      v1450_2_cursor.ascend(1);
    }
    drop(v1450_2_cursor);
    v1449_14.join_into((v1450_2).clone());
    }
    v1449_14_cursor.ascend(1);
  }
  drop(v1449_14_cursor);
  (v1449_14).clone()
}

fn routine_137(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1458_14 = Space::new();
  let mut v1458_14_cursor = (*s0).read_zipper();
  for v1458_14_byte in v1458_14_cursor.child_mask().iter() {
    v1458_14_cursor.descend_to_byte(v1458_14_byte);
    {
    let v1458_14_tail = v1458_14_cursor.fork_read_zipper();
    let v1458_14_head = Path::from_slice(&[v1458_14_byte]);
    let mut v1459_2 = Space::new();
    let mut v1459_2_cursor = (v1458_14_tail).read_zipper();
    for v1459_2_byte in v1459_2_cursor.child_mask().iter() {
      v1459_2_cursor.descend_to_byte(v1459_2_byte);
      {
      let v1459_2_tail = v1459_2_cursor.fork_read_zipper();
      let v1459_2_head = Path::from_slice(&[v1459_2_byte]);
      let v1460_2: Path = concat_path(&(v1458_14_head),&(v1459_2_head));
      let mut v1460_3 = Space::new();
      let mut v1460_3_cursor = (v1459_2_tail).read_zipper();
      for v1460_3_byte in v1460_3_cursor.child_mask().iter() {
        v1460_3_cursor.descend_to_byte(v1460_3_byte);
        {
        let v1460_3_tail = v1460_3_cursor.fork_read_zipper();
        let v1460_3_head = Path::from_slice(&[v1460_3_byte]);
        let v1461_2: Path = concat_path(&(v1460_2),&(v1460_3_head));
        let mut v1461_3 = Space::new();
        let mut v1461_3_cursor = (v1460_3_tail).read_zipper();
        for v1461_3_byte in v1461_3_cursor.child_mask().iter() {
          v1461_3_cursor.descend_to_byte(v1461_3_byte);
          {
          let v1461_3_tail = v1461_3_cursor.fork_read_zipper();
          let v1461_3_head = Path::from_slice(&[v1461_3_byte]);
          let v1462_2: Path = concat_path(&(v1461_2),&(v1461_3_head));
          let mut v1462_3 = Space::new();
          let mut v1462_3_cursor = (v1461_3_tail).read_zipper();
          for v1462_3_byte in v1462_3_cursor.child_mask().iter() {
            v1462_3_cursor.descend_to_byte(v1462_3_byte);
            {
            let v1462_3_tail = v1462_3_cursor.fork_read_zipper();
            let v1462_3_head = Path::from_slice(&[v1462_3_byte]);
            let mut v1463_2 = Space::new();
            let mut v1463_2_cursor = (v1462_3_tail).read_zipper();
            for v1463_2_byte in v1463_2_cursor.child_mask().iter() {
              v1463_2_cursor.descend_to_byte(v1463_2_byte);
              {
              let v1463_2_tail = v1463_2_cursor.fork_read_zipper();
              let v1463_2_head = Path::from_slice(&[v1463_2_byte]);
              let v1464_2: Path = concat_path(&(v1462_3_head),&(v1463_2_head));
              let mut v1464_3 = Space::new();
              let mut v1464_3_cursor = (v1463_2_tail).read_zipper();
              for v1464_3_byte in v1464_3_cursor.child_mask().iter() {
                v1464_3_cursor.descend_to_byte(v1464_3_byte);
                {
                let v1464_3_tail = v1464_3_cursor.fork_read_zipper();
                let v1464_3_head = Path::from_slice(&[v1464_3_byte]);
                let v1465_2: Path = concat_path(&(v1464_2),&(v1464_3_head));
                let mut v1465_3 = Space::new();
                let mut v1465_3_cursor = (v1464_3_tail).read_zipper();
                for v1465_3_byte in v1465_3_cursor.child_mask().iter() {
                  v1465_3_cursor.descend_to_byte(v1465_3_byte);
                  {
                  let v1465_3_tail = v1465_3_cursor.fork_read_zipper();
                  let v1465_3_head = Path::from_slice(&[v1465_3_byte]);
                  let v1466_2: Path = concat_path(&(v1465_2),&(v1465_3_head));
                  let v1466_3: Space = routine_153(c, &(v1466_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1462_2), &(v1465_3_tail).make_space());
                  drop(v1466_2);
                  v1465_3.join_into((v1466_3).clone());
                  }
                  v1465_3_cursor.ascend(1);
                }
                drop(v1465_3_cursor);
                drop(v1465_2);
                v1464_3.join_into((v1465_3).clone());
                }
                v1464_3_cursor.ascend(1);
              }
              drop(v1464_3_cursor);
              drop(v1464_2);
              v1463_2.join_into((v1464_3).clone());
              }
              v1463_2_cursor.ascend(1);
            }
            drop(v1463_2_cursor);
            v1462_3.join_into((v1463_2).clone());
            }
            v1462_3_cursor.ascend(1);
          }
          drop(v1462_3_cursor);
          drop(v1462_2);
          v1461_3.join_into((v1462_3).clone());
          }
          v1461_3_cursor.ascend(1);
        }
        drop(v1461_3_cursor);
        drop(v1461_2);
        v1460_3.join_into((v1461_3).clone());
        }
        v1460_3_cursor.ascend(1);
      }
      drop(v1460_3_cursor);
      drop(v1460_2);
      v1459_2.join_into((v1460_3).clone());
      }
      v1459_2_cursor.ascend(1);
    }
    drop(v1459_2_cursor);
    v1458_14.join_into((v1459_2).clone());
    }
    v1458_14_cursor.ascend(1);
  }
  drop(v1458_14_cursor);
  (v1458_14).clone()
}

fn routine_138(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1467_14 = Space::new();
  let mut v1467_14_cursor = (*s0).read_zipper();
  for v1467_14_byte in v1467_14_cursor.child_mask().iter() {
    v1467_14_cursor.descend_to_byte(v1467_14_byte);
    {
    let v1467_14_tail = v1467_14_cursor.fork_read_zipper();
    let v1467_14_head = Path::from_slice(&[v1467_14_byte]);
    let mut v1468_2 = Space::new();
    let mut v1468_2_cursor = (v1467_14_tail).read_zipper();
    for v1468_2_byte in v1468_2_cursor.child_mask().iter() {
      v1468_2_cursor.descend_to_byte(v1468_2_byte);
      {
      let v1468_2_tail = v1468_2_cursor.fork_read_zipper();
      let v1468_2_head = Path::from_slice(&[v1468_2_byte]);
      let v1469_2: Path = concat_path(&(v1467_14_head),&(v1468_2_head));
      let mut v1469_3 = Space::new();
      let mut v1469_3_cursor = (v1468_2_tail).read_zipper();
      for v1469_3_byte in v1469_3_cursor.child_mask().iter() {
        v1469_3_cursor.descend_to_byte(v1469_3_byte);
        {
        let v1469_3_tail = v1469_3_cursor.fork_read_zipper();
        let v1469_3_head = Path::from_slice(&[v1469_3_byte]);
        let v1470_2: Path = concat_path(&(v1469_2),&(v1469_3_head));
        let mut v1470_3 = Space::new();
        let mut v1470_3_cursor = (v1469_3_tail).read_zipper();
        for v1470_3_byte in v1470_3_cursor.child_mask().iter() {
          v1470_3_cursor.descend_to_byte(v1470_3_byte);
          {
          let v1470_3_tail = v1470_3_cursor.fork_read_zipper();
          let v1470_3_head = Path::from_slice(&[v1470_3_byte]);
          let v1471_2: Path = concat_path(&(v1470_2),&(v1470_3_head));
          let mut v1471_3 = Space::new();
          let mut v1471_3_cursor = (v1470_3_tail).read_zipper();
          for v1471_3_byte in v1471_3_cursor.child_mask().iter() {
            v1471_3_cursor.descend_to_byte(v1471_3_byte);
            {
            let v1471_3_tail = v1471_3_cursor.fork_read_zipper();
            let v1471_3_head = Path::from_slice(&[v1471_3_byte]);
            let mut v1472_2 = Space::new();
            let mut v1472_2_cursor = (v1471_3_tail).read_zipper();
            for v1472_2_byte in v1472_2_cursor.child_mask().iter() {
              v1472_2_cursor.descend_to_byte(v1472_2_byte);
              {
              let v1472_2_tail = v1472_2_cursor.fork_read_zipper();
              let v1472_2_head = Path::from_slice(&[v1472_2_byte]);
              let v1473_2: Path = concat_path(&(v1471_3_head),&(v1472_2_head));
              let mut v1473_3 = Space::new();
              let mut v1473_3_cursor = (v1472_2_tail).read_zipper();
              for v1473_3_byte in v1473_3_cursor.child_mask().iter() {
                v1473_3_cursor.descend_to_byte(v1473_3_byte);
                {
                let v1473_3_tail = v1473_3_cursor.fork_read_zipper();
                let v1473_3_head = Path::from_slice(&[v1473_3_byte]);
                let v1474_2: Path = concat_path(&(v1473_2),&(v1473_3_head));
                let mut v1474_3 = Space::new();
                let mut v1474_3_cursor = (v1473_3_tail).read_zipper();
                for v1474_3_byte in v1474_3_cursor.child_mask().iter() {
                  v1474_3_cursor.descend_to_byte(v1474_3_byte);
                  {
                  let v1474_3_tail = v1474_3_cursor.fork_read_zipper();
                  let v1474_3_head = Path::from_slice(&[v1474_3_byte]);
                  let v1475_2: Path = concat_path(&(v1474_2),&(v1474_3_head));
                  let v1475_3: Space = routine_154(c, &(v1475_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1471_2), &(v1474_3_tail).make_space());
                  drop(v1475_2);
                  v1474_3.join_into((v1475_3).clone());
                  }
                  v1474_3_cursor.ascend(1);
                }
                drop(v1474_3_cursor);
                drop(v1474_2);
                v1473_3.join_into((v1474_3).clone());
                }
                v1473_3_cursor.ascend(1);
              }
              drop(v1473_3_cursor);
              drop(v1473_2);
              v1472_2.join_into((v1473_3).clone());
              }
              v1472_2_cursor.ascend(1);
            }
            drop(v1472_2_cursor);
            v1471_3.join_into((v1472_2).clone());
            }
            v1471_3_cursor.ascend(1);
          }
          drop(v1471_3_cursor);
          drop(v1471_2);
          v1470_3.join_into((v1471_3).clone());
          }
          v1470_3_cursor.ascend(1);
        }
        drop(v1470_3_cursor);
        drop(v1470_2);
        v1469_3.join_into((v1470_3).clone());
        }
        v1469_3_cursor.ascend(1);
      }
      drop(v1469_3_cursor);
      drop(v1469_2);
      v1468_2.join_into((v1469_3).clone());
      }
      v1468_2_cursor.ascend(1);
    }
    drop(v1468_2_cursor);
    v1467_14.join_into((v1468_2).clone());
    }
    v1467_14_cursor.ascend(1);
  }
  drop(v1467_14_cursor);
  (v1467_14).clone()
}

fn routine_139(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1476_14 = Space::new();
  let mut v1476_14_cursor = (*s0).read_zipper();
  for v1476_14_byte in v1476_14_cursor.child_mask().iter() {
    v1476_14_cursor.descend_to_byte(v1476_14_byte);
    {
    let v1476_14_tail = v1476_14_cursor.fork_read_zipper();
    let v1476_14_head = Path::from_slice(&[v1476_14_byte]);
    let mut v1477_2 = Space::new();
    let mut v1477_2_cursor = (v1476_14_tail).read_zipper();
    for v1477_2_byte in v1477_2_cursor.child_mask().iter() {
      v1477_2_cursor.descend_to_byte(v1477_2_byte);
      {
      let v1477_2_tail = v1477_2_cursor.fork_read_zipper();
      let v1477_2_head = Path::from_slice(&[v1477_2_byte]);
      let v1478_2: Path = concat_path(&(v1476_14_head),&(v1477_2_head));
      let mut v1478_3 = Space::new();
      let mut v1478_3_cursor = (v1477_2_tail).read_zipper();
      for v1478_3_byte in v1478_3_cursor.child_mask().iter() {
        v1478_3_cursor.descend_to_byte(v1478_3_byte);
        {
        let v1478_3_tail = v1478_3_cursor.fork_read_zipper();
        let v1478_3_head = Path::from_slice(&[v1478_3_byte]);
        let v1479_2: Path = concat_path(&(v1478_2),&(v1478_3_head));
        let mut v1479_3 = Space::new();
        let mut v1479_3_cursor = (v1478_3_tail).read_zipper();
        for v1479_3_byte in v1479_3_cursor.child_mask().iter() {
          v1479_3_cursor.descend_to_byte(v1479_3_byte);
          {
          let v1479_3_tail = v1479_3_cursor.fork_read_zipper();
          let v1479_3_head = Path::from_slice(&[v1479_3_byte]);
          let v1480_2: Path = concat_path(&(v1479_2),&(v1479_3_head));
          let mut v1480_3 = Space::new();
          let mut v1480_3_cursor = (v1479_3_tail).read_zipper();
          for v1480_3_byte in v1480_3_cursor.child_mask().iter() {
            v1480_3_cursor.descend_to_byte(v1480_3_byte);
            {
            let v1480_3_tail = v1480_3_cursor.fork_read_zipper();
            let v1480_3_head = Path::from_slice(&[v1480_3_byte]);
            let mut v1481_2 = Space::new();
            let mut v1481_2_cursor = (v1480_3_tail).read_zipper();
            for v1481_2_byte in v1481_2_cursor.child_mask().iter() {
              v1481_2_cursor.descend_to_byte(v1481_2_byte);
              {
              let v1481_2_tail = v1481_2_cursor.fork_read_zipper();
              let v1481_2_head = Path::from_slice(&[v1481_2_byte]);
              let v1482_2: Path = concat_path(&(v1480_3_head),&(v1481_2_head));
              let mut v1482_3 = Space::new();
              let mut v1482_3_cursor = (v1481_2_tail).read_zipper();
              for v1482_3_byte in v1482_3_cursor.child_mask().iter() {
                v1482_3_cursor.descend_to_byte(v1482_3_byte);
                {
                let v1482_3_tail = v1482_3_cursor.fork_read_zipper();
                let v1482_3_head = Path::from_slice(&[v1482_3_byte]);
                let v1483_2: Path = concat_path(&(v1482_2),&(v1482_3_head));
                let mut v1483_3 = Space::new();
                let mut v1483_3_cursor = (v1482_3_tail).read_zipper();
                for v1483_3_byte in v1483_3_cursor.child_mask().iter() {
                  v1483_3_cursor.descend_to_byte(v1483_3_byte);
                  {
                  let v1483_3_tail = v1483_3_cursor.fork_read_zipper();
                  let v1483_3_head = Path::from_slice(&[v1483_3_byte]);
                  let v1484_2: Path = concat_path(&(v1483_2),&(v1483_3_head));
                  let v1484_3: Space = routine_155(c, &(v1484_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1480_2), &(v1483_3_tail).make_space());
                  drop(v1484_2);
                  v1483_3.join_into((v1484_3).clone());
                  }
                  v1483_3_cursor.ascend(1);
                }
                drop(v1483_3_cursor);
                drop(v1483_2);
                v1482_3.join_into((v1483_3).clone());
                }
                v1482_3_cursor.ascend(1);
              }
              drop(v1482_3_cursor);
              drop(v1482_2);
              v1481_2.join_into((v1482_3).clone());
              }
              v1481_2_cursor.ascend(1);
            }
            drop(v1481_2_cursor);
            v1480_3.join_into((v1481_2).clone());
            }
            v1480_3_cursor.ascend(1);
          }
          drop(v1480_3_cursor);
          drop(v1480_2);
          v1479_3.join_into((v1480_3).clone());
          }
          v1479_3_cursor.ascend(1);
        }
        drop(v1479_3_cursor);
        drop(v1479_2);
        v1478_3.join_into((v1479_3).clone());
        }
        v1478_3_cursor.ascend(1);
      }
      drop(v1478_3_cursor);
      drop(v1478_2);
      v1477_2.join_into((v1478_3).clone());
      }
      v1477_2_cursor.ascend(1);
    }
    drop(v1477_2_cursor);
    v1476_14.join_into((v1477_2).clone());
    }
    v1476_14_cursor.ascend(1);
  }
  drop(v1476_14_cursor);
  (v1476_14).clone()
}

fn routine_140(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1485_14 = Space::new();
  let mut v1485_14_cursor = (*s0).read_zipper();
  for v1485_14_byte in v1485_14_cursor.child_mask().iter() {
    v1485_14_cursor.descend_to_byte(v1485_14_byte);
    {
    let v1485_14_tail = v1485_14_cursor.fork_read_zipper();
    let v1485_14_head = Path::from_slice(&[v1485_14_byte]);
    let mut v1486_2 = Space::new();
    let mut v1486_2_cursor = (v1485_14_tail).read_zipper();
    for v1486_2_byte in v1486_2_cursor.child_mask().iter() {
      v1486_2_cursor.descend_to_byte(v1486_2_byte);
      {
      let v1486_2_tail = v1486_2_cursor.fork_read_zipper();
      let v1486_2_head = Path::from_slice(&[v1486_2_byte]);
      let v1487_2: Path = concat_path(&(v1485_14_head),&(v1486_2_head));
      let mut v1487_3 = Space::new();
      let mut v1487_3_cursor = (v1486_2_tail).read_zipper();
      for v1487_3_byte in v1487_3_cursor.child_mask().iter() {
        v1487_3_cursor.descend_to_byte(v1487_3_byte);
        {
        let v1487_3_tail = v1487_3_cursor.fork_read_zipper();
        let v1487_3_head = Path::from_slice(&[v1487_3_byte]);
        let v1488_2: Path = concat_path(&(v1487_2),&(v1487_3_head));
        let mut v1488_3 = Space::new();
        let mut v1488_3_cursor = (v1487_3_tail).read_zipper();
        for v1488_3_byte in v1488_3_cursor.child_mask().iter() {
          v1488_3_cursor.descend_to_byte(v1488_3_byte);
          {
          let v1488_3_tail = v1488_3_cursor.fork_read_zipper();
          let v1488_3_head = Path::from_slice(&[v1488_3_byte]);
          let v1489_2: Path = concat_path(&(v1488_2),&(v1488_3_head));
          let mut v1489_3 = Space::new();
          let mut v1489_3_cursor = (v1488_3_tail).read_zipper();
          for v1489_3_byte in v1489_3_cursor.child_mask().iter() {
            v1489_3_cursor.descend_to_byte(v1489_3_byte);
            {
            let v1489_3_tail = v1489_3_cursor.fork_read_zipper();
            let v1489_3_head = Path::from_slice(&[v1489_3_byte]);
            let mut v1490_2 = Space::new();
            let mut v1490_2_cursor = (v1489_3_tail).read_zipper();
            for v1490_2_byte in v1490_2_cursor.child_mask().iter() {
              v1490_2_cursor.descend_to_byte(v1490_2_byte);
              {
              let v1490_2_tail = v1490_2_cursor.fork_read_zipper();
              let v1490_2_head = Path::from_slice(&[v1490_2_byte]);
              let v1491_2: Path = concat_path(&(v1489_3_head),&(v1490_2_head));
              let mut v1491_3 = Space::new();
              let mut v1491_3_cursor = (v1490_2_tail).read_zipper();
              for v1491_3_byte in v1491_3_cursor.child_mask().iter() {
                v1491_3_cursor.descend_to_byte(v1491_3_byte);
                {
                let v1491_3_tail = v1491_3_cursor.fork_read_zipper();
                let v1491_3_head = Path::from_slice(&[v1491_3_byte]);
                let v1492_2: Path = concat_path(&(v1491_2),&(v1491_3_head));
                let mut v1492_3 = Space::new();
                let mut v1492_3_cursor = (v1491_3_tail).read_zipper();
                for v1492_3_byte in v1492_3_cursor.child_mask().iter() {
                  v1492_3_cursor.descend_to_byte(v1492_3_byte);
                  {
                  let v1492_3_tail = v1492_3_cursor.fork_read_zipper();
                  let v1492_3_head = Path::from_slice(&[v1492_3_byte]);
                  let v1493_2: Path = concat_path(&(v1492_2),&(v1492_3_head));
                  let v1493_3: Space = routine_156(c, &(v1493_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1489_2), &(v1492_3_tail).make_space());
                  drop(v1493_2);
                  v1492_3.join_into((v1493_3).clone());
                  }
                  v1492_3_cursor.ascend(1);
                }
                drop(v1492_3_cursor);
                drop(v1492_2);
                v1491_3.join_into((v1492_3).clone());
                }
                v1491_3_cursor.ascend(1);
              }
              drop(v1491_3_cursor);
              drop(v1491_2);
              v1490_2.join_into((v1491_3).clone());
              }
              v1490_2_cursor.ascend(1);
            }
            drop(v1490_2_cursor);
            v1489_3.join_into((v1490_2).clone());
            }
            v1489_3_cursor.ascend(1);
          }
          drop(v1489_3_cursor);
          drop(v1489_2);
          v1488_3.join_into((v1489_3).clone());
          }
          v1488_3_cursor.ascend(1);
        }
        drop(v1488_3_cursor);
        drop(v1488_2);
        v1487_3.join_into((v1488_3).clone());
        }
        v1487_3_cursor.ascend(1);
      }
      drop(v1487_3_cursor);
      drop(v1487_2);
      v1486_2.join_into((v1487_3).clone());
      }
      v1486_2_cursor.ascend(1);
    }
    drop(v1486_2_cursor);
    v1485_14.join_into((v1486_2).clone());
    }
    v1485_14_cursor.ascend(1);
  }
  drop(v1485_14_cursor);
  (v1485_14).clone()
}

fn routine_141(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1494_14 = Space::new();
  let mut v1494_14_cursor = (*s0).read_zipper();
  for v1494_14_byte in v1494_14_cursor.child_mask().iter() {
    v1494_14_cursor.descend_to_byte(v1494_14_byte);
    {
    let v1494_14_tail = v1494_14_cursor.fork_read_zipper();
    let v1494_14_head = Path::from_slice(&[v1494_14_byte]);
    let mut v1495_2 = Space::new();
    let mut v1495_2_cursor = (v1494_14_tail).read_zipper();
    for v1495_2_byte in v1495_2_cursor.child_mask().iter() {
      v1495_2_cursor.descend_to_byte(v1495_2_byte);
      {
      let v1495_2_tail = v1495_2_cursor.fork_read_zipper();
      let v1495_2_head = Path::from_slice(&[v1495_2_byte]);
      let v1496_2: Path = concat_path(&(v1494_14_head),&(v1495_2_head));
      let mut v1496_3 = Space::new();
      let mut v1496_3_cursor = (v1495_2_tail).read_zipper();
      for v1496_3_byte in v1496_3_cursor.child_mask().iter() {
        v1496_3_cursor.descend_to_byte(v1496_3_byte);
        {
        let v1496_3_tail = v1496_3_cursor.fork_read_zipper();
        let v1496_3_head = Path::from_slice(&[v1496_3_byte]);
        let v1497_2: Path = concat_path(&(v1496_2),&(v1496_3_head));
        let mut v1497_3 = Space::new();
        let mut v1497_3_cursor = (v1496_3_tail).read_zipper();
        for v1497_3_byte in v1497_3_cursor.child_mask().iter() {
          v1497_3_cursor.descend_to_byte(v1497_3_byte);
          {
          let v1497_3_tail = v1497_3_cursor.fork_read_zipper();
          let v1497_3_head = Path::from_slice(&[v1497_3_byte]);
          let v1498_2: Path = concat_path(&(v1497_2),&(v1497_3_head));
          let mut v1498_3 = Space::new();
          let mut v1498_3_cursor = (v1497_3_tail).read_zipper();
          for v1498_3_byte in v1498_3_cursor.child_mask().iter() {
            v1498_3_cursor.descend_to_byte(v1498_3_byte);
            {
            let v1498_3_tail = v1498_3_cursor.fork_read_zipper();
            let v1498_3_head = Path::from_slice(&[v1498_3_byte]);
            let mut v1499_2 = Space::new();
            let mut v1499_2_cursor = (v1498_3_tail).read_zipper();
            for v1499_2_byte in v1499_2_cursor.child_mask().iter() {
              v1499_2_cursor.descend_to_byte(v1499_2_byte);
              {
              let v1499_2_tail = v1499_2_cursor.fork_read_zipper();
              let v1499_2_head = Path::from_slice(&[v1499_2_byte]);
              let v1500_2: Path = concat_path(&(v1498_3_head),&(v1499_2_head));
              let mut v1500_3 = Space::new();
              let mut v1500_3_cursor = (v1499_2_tail).read_zipper();
              for v1500_3_byte in v1500_3_cursor.child_mask().iter() {
                v1500_3_cursor.descend_to_byte(v1500_3_byte);
                {
                let v1500_3_tail = v1500_3_cursor.fork_read_zipper();
                let v1500_3_head = Path::from_slice(&[v1500_3_byte]);
                let v1501_2: Path = concat_path(&(v1500_2),&(v1500_3_head));
                let mut v1501_3 = Space::new();
                let mut v1501_3_cursor = (v1500_3_tail).read_zipper();
                for v1501_3_byte in v1501_3_cursor.child_mask().iter() {
                  v1501_3_cursor.descend_to_byte(v1501_3_byte);
                  {
                  let v1501_3_tail = v1501_3_cursor.fork_read_zipper();
                  let v1501_3_head = Path::from_slice(&[v1501_3_byte]);
                  let v1502_2: Path = concat_path(&(v1501_2),&(v1501_3_head));
                  let v1502_3: Space = routine_157(c, &(v1502_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1498_2), &(v1501_3_tail).make_space());
                  drop(v1502_2);
                  v1501_3.join_into((v1502_3).clone());
                  }
                  v1501_3_cursor.ascend(1);
                }
                drop(v1501_3_cursor);
                drop(v1501_2);
                v1500_3.join_into((v1501_3).clone());
                }
                v1500_3_cursor.ascend(1);
              }
              drop(v1500_3_cursor);
              drop(v1500_2);
              v1499_2.join_into((v1500_3).clone());
              }
              v1499_2_cursor.ascend(1);
            }
            drop(v1499_2_cursor);
            v1498_3.join_into((v1499_2).clone());
            }
            v1498_3_cursor.ascend(1);
          }
          drop(v1498_3_cursor);
          drop(v1498_2);
          v1497_3.join_into((v1498_3).clone());
          }
          v1497_3_cursor.ascend(1);
        }
        drop(v1497_3_cursor);
        drop(v1497_2);
        v1496_3.join_into((v1497_3).clone());
        }
        v1496_3_cursor.ascend(1);
      }
      drop(v1496_3_cursor);
      drop(v1496_2);
      v1495_2.join_into((v1496_3).clone());
      }
      v1495_2_cursor.ascend(1);
    }
    drop(v1495_2_cursor);
    v1494_14.join_into((v1495_2).clone());
    }
    v1494_14_cursor.ascend(1);
  }
  drop(v1494_14_cursor);
  (v1494_14).clone()
}

fn routine_142(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, s0: &Space) -> Space {
  let mut v1503_14 = Space::new();
  let mut v1503_14_cursor = (*s0).read_zipper();
  for v1503_14_byte in v1503_14_cursor.child_mask().iter() {
    v1503_14_cursor.descend_to_byte(v1503_14_byte);
    {
    let v1503_14_tail = v1503_14_cursor.fork_read_zipper();
    let v1503_14_head = Path::from_slice(&[v1503_14_byte]);
    let mut v1504_2 = Space::new();
    let mut v1504_2_cursor = (v1503_14_tail).read_zipper();
    for v1504_2_byte in v1504_2_cursor.child_mask().iter() {
      v1504_2_cursor.descend_to_byte(v1504_2_byte);
      {
      let v1504_2_tail = v1504_2_cursor.fork_read_zipper();
      let v1504_2_head = Path::from_slice(&[v1504_2_byte]);
      let v1505_2: Path = concat_path(&(v1503_14_head),&(v1504_2_head));
      let mut v1505_3 = Space::new();
      let mut v1505_3_cursor = (v1504_2_tail).read_zipper();
      for v1505_3_byte in v1505_3_cursor.child_mask().iter() {
        v1505_3_cursor.descend_to_byte(v1505_3_byte);
        {
        let v1505_3_tail = v1505_3_cursor.fork_read_zipper();
        let v1505_3_head = Path::from_slice(&[v1505_3_byte]);
        let v1506_2: Path = concat_path(&(v1505_2),&(v1505_3_head));
        let mut v1506_3 = Space::new();
        let mut v1506_3_cursor = (v1505_3_tail).read_zipper();
        for v1506_3_byte in v1506_3_cursor.child_mask().iter() {
          v1506_3_cursor.descend_to_byte(v1506_3_byte);
          {
          let v1506_3_tail = v1506_3_cursor.fork_read_zipper();
          let v1506_3_head = Path::from_slice(&[v1506_3_byte]);
          let v1507_2: Path = concat_path(&(v1506_2),&(v1506_3_head));
          let mut v1507_3 = Space::new();
          let mut v1507_3_cursor = (v1506_3_tail).read_zipper();
          for v1507_3_byte in v1507_3_cursor.child_mask().iter() {
            v1507_3_cursor.descend_to_byte(v1507_3_byte);
            {
            let v1507_3_tail = v1507_3_cursor.fork_read_zipper();
            let v1507_3_head = Path::from_slice(&[v1507_3_byte]);
            let mut v1508_2 = Space::new();
            let mut v1508_2_cursor = (v1507_3_tail).read_zipper();
            for v1508_2_byte in v1508_2_cursor.child_mask().iter() {
              v1508_2_cursor.descend_to_byte(v1508_2_byte);
              {
              let v1508_2_tail = v1508_2_cursor.fork_read_zipper();
              let v1508_2_head = Path::from_slice(&[v1508_2_byte]);
              let v1509_2: Path = concat_path(&(v1507_3_head),&(v1508_2_head));
              let mut v1509_3 = Space::new();
              let mut v1509_3_cursor = (v1508_2_tail).read_zipper();
              for v1509_3_byte in v1509_3_cursor.child_mask().iter() {
                v1509_3_cursor.descend_to_byte(v1509_3_byte);
                {
                let v1509_3_tail = v1509_3_cursor.fork_read_zipper();
                let v1509_3_head = Path::from_slice(&[v1509_3_byte]);
                let v1510_2: Path = concat_path(&(v1509_2),&(v1509_3_head));
                let mut v1510_3 = Space::new();
                let mut v1510_3_cursor = (v1509_3_tail).read_zipper();
                for v1510_3_byte in v1510_3_cursor.child_mask().iter() {
                  v1510_3_cursor.descend_to_byte(v1510_3_byte);
                  {
                  let v1510_3_tail = v1510_3_cursor.fork_read_zipper();
                  let v1510_3_head = Path::from_slice(&[v1510_3_byte]);
                  let v1511_2: Path = concat_path(&(v1510_2),&(v1510_3_head));
                  let v1511_3: Space = routine_158(c, &(v1511_2), &(*p1), &(*p2), &(*p3), &(*p4), &(*p5), &(*p6), &(*p7), &(*p8), &(*p9), &(*p10), &(*p11), &(*p12), &(*p0), &(v1507_2), &(v1510_3_tail).make_space());
                  drop(v1511_2);
                  v1510_3.join_into((v1511_3).clone());
                  }
                  v1510_3_cursor.ascend(1);
                }
                drop(v1510_3_cursor);
                drop(v1510_2);
                v1509_3.join_into((v1510_3).clone());
                }
                v1509_3_cursor.ascend(1);
              }
              drop(v1509_3_cursor);
              drop(v1509_2);
              v1508_2.join_into((v1509_3).clone());
              }
              v1508_2_cursor.ascend(1);
            }
            drop(v1508_2_cursor);
            v1507_3.join_into((v1508_2).clone());
            }
            v1507_3_cursor.ascend(1);
          }
          drop(v1507_3_cursor);
          drop(v1507_2);
          v1506_3.join_into((v1507_3).clone());
          }
          v1506_3_cursor.ascend(1);
        }
        drop(v1506_3_cursor);
        drop(v1506_2);
        v1505_3.join_into((v1506_3).clone());
        }
        v1505_3_cursor.ascend(1);
      }
      drop(v1505_3_cursor);
      drop(v1505_2);
      v1504_2.join_into((v1505_3).clone());
      }
      v1504_2_cursor.ascend(1);
    }
    drop(v1504_2_cursor);
    v1503_14.join_into((v1504_2).clone());
    }
    v1503_14_cursor.ascend(1);
  }
  drop(v1503_14_cursor);
  (v1503_14).clone()
}

fn routine_143(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1512_18: Path = concat_path(&(*CONSTANT_3),&(*p1));
  let v1512_19: Space = singleton(&(v1512_18));
  drop(v1512_18);
  let v1512_20: Space = map_map_kernels::unite(&(*CONSTANT_84),&(v1512_19));
  drop(v1512_19);
  let v1512_22: Path = concat_path(&(*CONSTANT_5),&(*p2));
  let v1512_23: Space = singleton(&(v1512_22));
  drop(v1512_22);
  let v1512_24: Space = map_map_kernels::unite(&(v1512_20),&(v1512_23));
  drop(v1512_20);
  drop(v1512_23);
  let v1512_26: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v1512_27: Space = singleton(&(v1512_26));
  drop(v1512_26);
  let v1512_28: Space = map_map_kernels::unite(&(v1512_24),&(v1512_27));
  drop(v1512_24);
  drop(v1512_27);
  let v1512_30: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v1512_31: Space = singleton(&(v1512_30));
  drop(v1512_30);
  let v1512_32: Space = map_map_kernels::unite(&(v1512_28),&(v1512_31));
  drop(v1512_28);
  drop(v1512_31);
  let v1512_34: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v1512_35: Space = singleton(&(v1512_34));
  drop(v1512_34);
  let v1512_36: Space = map_map_kernels::unite(&(v1512_32),&(v1512_35));
  drop(v1512_32);
  drop(v1512_35);
  let v1512_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1512_39: Space = singleton(&(v1512_38));
  drop(v1512_38);
  let v1512_40: Space = map_map_kernels::unite(&(v1512_36),&(v1512_39));
  drop(v1512_36);
  drop(v1512_39);
  let v1512_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1512_43: Space = singleton(&(v1512_42));
  drop(v1512_42);
  let v1512_44: Space = map_map_kernels::unite(&(v1512_40),&(v1512_43));
  drop(v1512_40);
  drop(v1512_43);
  let v1512_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1512_47: Space = singleton(&(v1512_46));
  drop(v1512_46);
  let v1512_48: Space = map_map_kernels::unite(&(v1512_44),&(v1512_47));
  drop(v1512_44);
  drop(v1512_47);
  let v1512_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1512_51: Space = singleton(&(v1512_50));
  drop(v1512_50);
  let v1512_52: Space = map_map_kernels::unite(&(v1512_48),&(v1512_51));
  drop(v1512_48);
  drop(v1512_51);
  let v1512_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1512_55: Space = singleton(&(v1512_54));
  drop(v1512_54);
  let v1512_56: Space = map_map_kernels::unite(&(v1512_52),&(v1512_55));
  drop(v1512_52);
  drop(v1512_55);
  let v1512_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1512_59: Space = singleton(&(v1512_58));
  drop(v1512_58);
  let v1512_60: Space = map_map_kernels::unite(&(v1512_56),&(v1512_59));
  drop(v1512_56);
  drop(v1512_59);
  let v1512_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1512_63: Space = singleton(&(v1512_62));
  drop(v1512_62);
  let v1512_64: Space = map_map_kernels::unite(&(v1512_60),&(v1512_63));
  drop(v1512_60);
  drop(v1512_63);
  let v1512_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1512_67: Space = singleton(&(v1512_66));
  drop(v1512_66);
  let v1512_68: Space = map_map_kernels::unite(&(v1512_64),&(v1512_67));
  drop(v1512_64);
  drop(v1512_67);
  let v1512_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1512_71: Space = singleton(&(v1512_70));
  drop(v1512_70);
  let v1512_72: Space = map_map_kernels::unite(&(v1512_68),&(v1512_71));
  drop(v1512_68);
  drop(v1512_71);
  let v1512_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1512_75: Space = singleton(&(v1512_74));
  drop(v1512_74);
  let v1512_76: Space = map_map_kernels::unite(&(v1512_72),&(v1512_75));
  drop(v1512_72);
  drop(v1512_75);
  (v1512_76).clone()
}

fn routine_144(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1513_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1513_19: Space = singleton(&(v1513_18));
  drop(v1513_18);
  let v1513_20: Space = map_map_kernels::unite(&(*CONSTANT_85),&(v1513_19));
  drop(v1513_19);
  let v1513_22: Path = concat_path(&(*CONSTANT_5),&(*p2));
  let v1513_23: Space = singleton(&(v1513_22));
  drop(v1513_22);
  let v1513_24: Space = map_map_kernels::unite(&(v1513_20),&(v1513_23));
  drop(v1513_20);
  drop(v1513_23);
  let v1513_26: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v1513_27: Space = singleton(&(v1513_26));
  drop(v1513_26);
  let v1513_28: Space = map_map_kernels::unite(&(v1513_24),&(v1513_27));
  drop(v1513_24);
  drop(v1513_27);
  let v1513_30: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v1513_31: Space = singleton(&(v1513_30));
  drop(v1513_30);
  let v1513_32: Space = map_map_kernels::unite(&(v1513_28),&(v1513_31));
  drop(v1513_28);
  drop(v1513_31);
  let v1513_34: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v1513_35: Space = singleton(&(v1513_34));
  drop(v1513_34);
  let v1513_36: Space = map_map_kernels::unite(&(v1513_32),&(v1513_35));
  drop(v1513_32);
  drop(v1513_35);
  let v1513_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1513_39: Space = singleton(&(v1513_38));
  drop(v1513_38);
  let v1513_40: Space = map_map_kernels::unite(&(v1513_36),&(v1513_39));
  drop(v1513_36);
  drop(v1513_39);
  let v1513_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1513_43: Space = singleton(&(v1513_42));
  drop(v1513_42);
  let v1513_44: Space = map_map_kernels::unite(&(v1513_40),&(v1513_43));
  drop(v1513_40);
  drop(v1513_43);
  let v1513_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1513_47: Space = singleton(&(v1513_46));
  drop(v1513_46);
  let v1513_48: Space = map_map_kernels::unite(&(v1513_44),&(v1513_47));
  drop(v1513_44);
  drop(v1513_47);
  let v1513_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1513_51: Space = singleton(&(v1513_50));
  drop(v1513_50);
  let v1513_52: Space = map_map_kernels::unite(&(v1513_48),&(v1513_51));
  drop(v1513_48);
  drop(v1513_51);
  let v1513_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1513_55: Space = singleton(&(v1513_54));
  drop(v1513_54);
  let v1513_56: Space = map_map_kernels::unite(&(v1513_52),&(v1513_55));
  drop(v1513_52);
  drop(v1513_55);
  let v1513_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1513_59: Space = singleton(&(v1513_58));
  drop(v1513_58);
  let v1513_60: Space = map_map_kernels::unite(&(v1513_56),&(v1513_59));
  drop(v1513_56);
  drop(v1513_59);
  let v1513_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1513_63: Space = singleton(&(v1513_62));
  drop(v1513_62);
  let v1513_64: Space = map_map_kernels::unite(&(v1513_60),&(v1513_63));
  drop(v1513_60);
  drop(v1513_63);
  let v1513_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1513_67: Space = singleton(&(v1513_66));
  drop(v1513_66);
  let v1513_68: Space = map_map_kernels::unite(&(v1513_64),&(v1513_67));
  drop(v1513_64);
  drop(v1513_67);
  let v1513_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1513_71: Space = singleton(&(v1513_70));
  drop(v1513_70);
  let v1513_72: Space = map_map_kernels::unite(&(v1513_68),&(v1513_71));
  drop(v1513_68);
  drop(v1513_71);
  let v1513_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1513_75: Space = singleton(&(v1513_74));
  drop(v1513_74);
  let v1513_76: Space = map_map_kernels::unite(&(v1513_72),&(v1513_75));
  drop(v1513_72);
  drop(v1513_75);
  (v1513_76).clone()
}

fn routine_145(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1514_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1514_19: Space = singleton(&(v1514_18));
  drop(v1514_18);
  let v1514_20: Space = map_map_kernels::unite(&(*CONSTANT_86),&(v1514_19));
  drop(v1514_19);
  let v1514_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1514_23: Space = singleton(&(v1514_22));
  drop(v1514_22);
  let v1514_24: Space = map_map_kernels::unite(&(v1514_20),&(v1514_23));
  drop(v1514_20);
  drop(v1514_23);
  let v1514_26: Path = concat_path(&(*CONSTANT_7),&(*p3));
  let v1514_27: Space = singleton(&(v1514_26));
  drop(v1514_26);
  let v1514_28: Space = map_map_kernels::unite(&(v1514_24),&(v1514_27));
  drop(v1514_24);
  drop(v1514_27);
  let v1514_30: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v1514_31: Space = singleton(&(v1514_30));
  drop(v1514_30);
  let v1514_32: Space = map_map_kernels::unite(&(v1514_28),&(v1514_31));
  drop(v1514_28);
  drop(v1514_31);
  let v1514_34: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v1514_35: Space = singleton(&(v1514_34));
  drop(v1514_34);
  let v1514_36: Space = map_map_kernels::unite(&(v1514_32),&(v1514_35));
  drop(v1514_32);
  drop(v1514_35);
  let v1514_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1514_39: Space = singleton(&(v1514_38));
  drop(v1514_38);
  let v1514_40: Space = map_map_kernels::unite(&(v1514_36),&(v1514_39));
  drop(v1514_36);
  drop(v1514_39);
  let v1514_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1514_43: Space = singleton(&(v1514_42));
  drop(v1514_42);
  let v1514_44: Space = map_map_kernels::unite(&(v1514_40),&(v1514_43));
  drop(v1514_40);
  drop(v1514_43);
  let v1514_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1514_47: Space = singleton(&(v1514_46));
  drop(v1514_46);
  let v1514_48: Space = map_map_kernels::unite(&(v1514_44),&(v1514_47));
  drop(v1514_44);
  drop(v1514_47);
  let v1514_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1514_51: Space = singleton(&(v1514_50));
  drop(v1514_50);
  let v1514_52: Space = map_map_kernels::unite(&(v1514_48),&(v1514_51));
  drop(v1514_48);
  drop(v1514_51);
  let v1514_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1514_55: Space = singleton(&(v1514_54));
  drop(v1514_54);
  let v1514_56: Space = map_map_kernels::unite(&(v1514_52),&(v1514_55));
  drop(v1514_52);
  drop(v1514_55);
  let v1514_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1514_59: Space = singleton(&(v1514_58));
  drop(v1514_58);
  let v1514_60: Space = map_map_kernels::unite(&(v1514_56),&(v1514_59));
  drop(v1514_56);
  drop(v1514_59);
  let v1514_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1514_63: Space = singleton(&(v1514_62));
  drop(v1514_62);
  let v1514_64: Space = map_map_kernels::unite(&(v1514_60),&(v1514_63));
  drop(v1514_60);
  drop(v1514_63);
  let v1514_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1514_67: Space = singleton(&(v1514_66));
  drop(v1514_66);
  let v1514_68: Space = map_map_kernels::unite(&(v1514_64),&(v1514_67));
  drop(v1514_64);
  drop(v1514_67);
  let v1514_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1514_71: Space = singleton(&(v1514_70));
  drop(v1514_70);
  let v1514_72: Space = map_map_kernels::unite(&(v1514_68),&(v1514_71));
  drop(v1514_68);
  drop(v1514_71);
  let v1514_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1514_75: Space = singleton(&(v1514_74));
  drop(v1514_74);
  let v1514_76: Space = map_map_kernels::unite(&(v1514_72),&(v1514_75));
  drop(v1514_72);
  drop(v1514_75);
  (v1514_76).clone()
}

fn routine_146(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1515_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1515_19: Space = singleton(&(v1515_18));
  drop(v1515_18);
  let v1515_20: Space = map_map_kernels::unite(&(*CONSTANT_87),&(v1515_19));
  drop(v1515_19);
  let v1515_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1515_23: Space = singleton(&(v1515_22));
  drop(v1515_22);
  let v1515_24: Space = map_map_kernels::unite(&(v1515_20),&(v1515_23));
  drop(v1515_20);
  drop(v1515_23);
  let v1515_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1515_27: Space = singleton(&(v1515_26));
  drop(v1515_26);
  let v1515_28: Space = map_map_kernels::unite(&(v1515_24),&(v1515_27));
  drop(v1515_24);
  drop(v1515_27);
  let v1515_30: Path = concat_path(&(*CONSTANT_9),&(*p4));
  let v1515_31: Space = singleton(&(v1515_30));
  drop(v1515_30);
  let v1515_32: Space = map_map_kernels::unite(&(v1515_28),&(v1515_31));
  drop(v1515_28);
  drop(v1515_31);
  let v1515_34: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v1515_35: Space = singleton(&(v1515_34));
  drop(v1515_34);
  let v1515_36: Space = map_map_kernels::unite(&(v1515_32),&(v1515_35));
  drop(v1515_32);
  drop(v1515_35);
  let v1515_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1515_39: Space = singleton(&(v1515_38));
  drop(v1515_38);
  let v1515_40: Space = map_map_kernels::unite(&(v1515_36),&(v1515_39));
  drop(v1515_36);
  drop(v1515_39);
  let v1515_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1515_43: Space = singleton(&(v1515_42));
  drop(v1515_42);
  let v1515_44: Space = map_map_kernels::unite(&(v1515_40),&(v1515_43));
  drop(v1515_40);
  drop(v1515_43);
  let v1515_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1515_47: Space = singleton(&(v1515_46));
  drop(v1515_46);
  let v1515_48: Space = map_map_kernels::unite(&(v1515_44),&(v1515_47));
  drop(v1515_44);
  drop(v1515_47);
  let v1515_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1515_51: Space = singleton(&(v1515_50));
  drop(v1515_50);
  let v1515_52: Space = map_map_kernels::unite(&(v1515_48),&(v1515_51));
  drop(v1515_48);
  drop(v1515_51);
  let v1515_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1515_55: Space = singleton(&(v1515_54));
  drop(v1515_54);
  let v1515_56: Space = map_map_kernels::unite(&(v1515_52),&(v1515_55));
  drop(v1515_52);
  drop(v1515_55);
  let v1515_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1515_59: Space = singleton(&(v1515_58));
  drop(v1515_58);
  let v1515_60: Space = map_map_kernels::unite(&(v1515_56),&(v1515_59));
  drop(v1515_56);
  drop(v1515_59);
  let v1515_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1515_63: Space = singleton(&(v1515_62));
  drop(v1515_62);
  let v1515_64: Space = map_map_kernels::unite(&(v1515_60),&(v1515_63));
  drop(v1515_60);
  drop(v1515_63);
  let v1515_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1515_67: Space = singleton(&(v1515_66));
  drop(v1515_66);
  let v1515_68: Space = map_map_kernels::unite(&(v1515_64),&(v1515_67));
  drop(v1515_64);
  drop(v1515_67);
  let v1515_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1515_71: Space = singleton(&(v1515_70));
  drop(v1515_70);
  let v1515_72: Space = map_map_kernels::unite(&(v1515_68),&(v1515_71));
  drop(v1515_68);
  drop(v1515_71);
  let v1515_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1515_75: Space = singleton(&(v1515_74));
  drop(v1515_74);
  let v1515_76: Space = map_map_kernels::unite(&(v1515_72),&(v1515_75));
  drop(v1515_72);
  drop(v1515_75);
  (v1515_76).clone()
}

fn routine_147(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1516_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1516_19: Space = singleton(&(v1516_18));
  drop(v1516_18);
  let v1516_20: Space = map_map_kernels::unite(&(*CONSTANT_88),&(v1516_19));
  drop(v1516_19);
  let v1516_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1516_23: Space = singleton(&(v1516_22));
  drop(v1516_22);
  let v1516_24: Space = map_map_kernels::unite(&(v1516_20),&(v1516_23));
  drop(v1516_20);
  drop(v1516_23);
  let v1516_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1516_27: Space = singleton(&(v1516_26));
  drop(v1516_26);
  let v1516_28: Space = map_map_kernels::unite(&(v1516_24),&(v1516_27));
  drop(v1516_24);
  drop(v1516_27);
  let v1516_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1516_31: Space = singleton(&(v1516_30));
  drop(v1516_30);
  let v1516_32: Space = map_map_kernels::unite(&(v1516_28),&(v1516_31));
  drop(v1516_28);
  drop(v1516_31);
  let v1516_34: Path = concat_path(&(*CONSTANT_11),&(*p5));
  let v1516_35: Space = singleton(&(v1516_34));
  drop(v1516_34);
  let v1516_36: Space = map_map_kernels::unite(&(v1516_32),&(v1516_35));
  drop(v1516_32);
  drop(v1516_35);
  let v1516_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1516_39: Space = singleton(&(v1516_38));
  drop(v1516_38);
  let v1516_40: Space = map_map_kernels::unite(&(v1516_36),&(v1516_39));
  drop(v1516_36);
  drop(v1516_39);
  let v1516_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1516_43: Space = singleton(&(v1516_42));
  drop(v1516_42);
  let v1516_44: Space = map_map_kernels::unite(&(v1516_40),&(v1516_43));
  drop(v1516_40);
  drop(v1516_43);
  let v1516_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1516_47: Space = singleton(&(v1516_46));
  drop(v1516_46);
  let v1516_48: Space = map_map_kernels::unite(&(v1516_44),&(v1516_47));
  drop(v1516_44);
  drop(v1516_47);
  let v1516_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1516_51: Space = singleton(&(v1516_50));
  drop(v1516_50);
  let v1516_52: Space = map_map_kernels::unite(&(v1516_48),&(v1516_51));
  drop(v1516_48);
  drop(v1516_51);
  let v1516_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1516_55: Space = singleton(&(v1516_54));
  drop(v1516_54);
  let v1516_56: Space = map_map_kernels::unite(&(v1516_52),&(v1516_55));
  drop(v1516_52);
  drop(v1516_55);
  let v1516_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1516_59: Space = singleton(&(v1516_58));
  drop(v1516_58);
  let v1516_60: Space = map_map_kernels::unite(&(v1516_56),&(v1516_59));
  drop(v1516_56);
  drop(v1516_59);
  let v1516_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1516_63: Space = singleton(&(v1516_62));
  drop(v1516_62);
  let v1516_64: Space = map_map_kernels::unite(&(v1516_60),&(v1516_63));
  drop(v1516_60);
  drop(v1516_63);
  let v1516_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1516_67: Space = singleton(&(v1516_66));
  drop(v1516_66);
  let v1516_68: Space = map_map_kernels::unite(&(v1516_64),&(v1516_67));
  drop(v1516_64);
  drop(v1516_67);
  let v1516_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1516_71: Space = singleton(&(v1516_70));
  drop(v1516_70);
  let v1516_72: Space = map_map_kernels::unite(&(v1516_68),&(v1516_71));
  drop(v1516_68);
  drop(v1516_71);
  let v1516_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1516_75: Space = singleton(&(v1516_74));
  drop(v1516_74);
  let v1516_76: Space = map_map_kernels::unite(&(v1516_72),&(v1516_75));
  drop(v1516_72);
  drop(v1516_75);
  (v1516_76).clone()
}

fn routine_148(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1517_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1517_19: Space = singleton(&(v1517_18));
  drop(v1517_18);
  let v1517_20: Space = map_map_kernels::unite(&(*CONSTANT_89),&(v1517_19));
  drop(v1517_19);
  let v1517_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1517_23: Space = singleton(&(v1517_22));
  drop(v1517_22);
  let v1517_24: Space = map_map_kernels::unite(&(v1517_20),&(v1517_23));
  drop(v1517_20);
  drop(v1517_23);
  let v1517_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1517_27: Space = singleton(&(v1517_26));
  drop(v1517_26);
  let v1517_28: Space = map_map_kernels::unite(&(v1517_24),&(v1517_27));
  drop(v1517_24);
  drop(v1517_27);
  let v1517_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1517_31: Space = singleton(&(v1517_30));
  drop(v1517_30);
  let v1517_32: Space = map_map_kernels::unite(&(v1517_28),&(v1517_31));
  drop(v1517_28);
  drop(v1517_31);
  let v1517_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1517_35: Space = singleton(&(v1517_34));
  drop(v1517_34);
  let v1517_36: Space = map_map_kernels::unite(&(v1517_32),&(v1517_35));
  drop(v1517_32);
  drop(v1517_35);
  let v1517_38: Path = concat_path(&(*CONSTANT_13),&(*p6));
  let v1517_39: Space = singleton(&(v1517_38));
  drop(v1517_38);
  let v1517_40: Space = map_map_kernels::unite(&(v1517_36),&(v1517_39));
  drop(v1517_36);
  drop(v1517_39);
  let v1517_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1517_43: Space = singleton(&(v1517_42));
  drop(v1517_42);
  let v1517_44: Space = map_map_kernels::unite(&(v1517_40),&(v1517_43));
  drop(v1517_40);
  drop(v1517_43);
  let v1517_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1517_47: Space = singleton(&(v1517_46));
  drop(v1517_46);
  let v1517_48: Space = map_map_kernels::unite(&(v1517_44),&(v1517_47));
  drop(v1517_44);
  drop(v1517_47);
  let v1517_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1517_51: Space = singleton(&(v1517_50));
  drop(v1517_50);
  let v1517_52: Space = map_map_kernels::unite(&(v1517_48),&(v1517_51));
  drop(v1517_48);
  drop(v1517_51);
  let v1517_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1517_55: Space = singleton(&(v1517_54));
  drop(v1517_54);
  let v1517_56: Space = map_map_kernels::unite(&(v1517_52),&(v1517_55));
  drop(v1517_52);
  drop(v1517_55);
  let v1517_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1517_59: Space = singleton(&(v1517_58));
  drop(v1517_58);
  let v1517_60: Space = map_map_kernels::unite(&(v1517_56),&(v1517_59));
  drop(v1517_56);
  drop(v1517_59);
  let v1517_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1517_63: Space = singleton(&(v1517_62));
  drop(v1517_62);
  let v1517_64: Space = map_map_kernels::unite(&(v1517_60),&(v1517_63));
  drop(v1517_60);
  drop(v1517_63);
  let v1517_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1517_67: Space = singleton(&(v1517_66));
  drop(v1517_66);
  let v1517_68: Space = map_map_kernels::unite(&(v1517_64),&(v1517_67));
  drop(v1517_64);
  drop(v1517_67);
  let v1517_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1517_71: Space = singleton(&(v1517_70));
  drop(v1517_70);
  let v1517_72: Space = map_map_kernels::unite(&(v1517_68),&(v1517_71));
  drop(v1517_68);
  drop(v1517_71);
  let v1517_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1517_75: Space = singleton(&(v1517_74));
  drop(v1517_74);
  let v1517_76: Space = map_map_kernels::unite(&(v1517_72),&(v1517_75));
  drop(v1517_72);
  drop(v1517_75);
  (v1517_76).clone()
}

fn routine_149(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1518_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1518_19: Space = singleton(&(v1518_18));
  drop(v1518_18);
  let v1518_20: Space = map_map_kernels::unite(&(*CONSTANT_90),&(v1518_19));
  drop(v1518_19);
  let v1518_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1518_23: Space = singleton(&(v1518_22));
  drop(v1518_22);
  let v1518_24: Space = map_map_kernels::unite(&(v1518_20),&(v1518_23));
  drop(v1518_20);
  drop(v1518_23);
  let v1518_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1518_27: Space = singleton(&(v1518_26));
  drop(v1518_26);
  let v1518_28: Space = map_map_kernels::unite(&(v1518_24),&(v1518_27));
  drop(v1518_24);
  drop(v1518_27);
  let v1518_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1518_31: Space = singleton(&(v1518_30));
  drop(v1518_30);
  let v1518_32: Space = map_map_kernels::unite(&(v1518_28),&(v1518_31));
  drop(v1518_28);
  drop(v1518_31);
  let v1518_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1518_35: Space = singleton(&(v1518_34));
  drop(v1518_34);
  let v1518_36: Space = map_map_kernels::unite(&(v1518_32),&(v1518_35));
  drop(v1518_32);
  drop(v1518_35);
  let v1518_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1518_39: Space = singleton(&(v1518_38));
  drop(v1518_38);
  let v1518_40: Space = map_map_kernels::unite(&(v1518_36),&(v1518_39));
  drop(v1518_36);
  drop(v1518_39);
  let v1518_42: Path = concat_path(&(*CONSTANT_15),&(*p7));
  let v1518_43: Space = singleton(&(v1518_42));
  drop(v1518_42);
  let v1518_44: Space = map_map_kernels::unite(&(v1518_40),&(v1518_43));
  drop(v1518_40);
  drop(v1518_43);
  let v1518_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1518_47: Space = singleton(&(v1518_46));
  drop(v1518_46);
  let v1518_48: Space = map_map_kernels::unite(&(v1518_44),&(v1518_47));
  drop(v1518_44);
  drop(v1518_47);
  let v1518_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1518_51: Space = singleton(&(v1518_50));
  drop(v1518_50);
  let v1518_52: Space = map_map_kernels::unite(&(v1518_48),&(v1518_51));
  drop(v1518_48);
  drop(v1518_51);
  let v1518_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1518_55: Space = singleton(&(v1518_54));
  drop(v1518_54);
  let v1518_56: Space = map_map_kernels::unite(&(v1518_52),&(v1518_55));
  drop(v1518_52);
  drop(v1518_55);
  let v1518_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1518_59: Space = singleton(&(v1518_58));
  drop(v1518_58);
  let v1518_60: Space = map_map_kernels::unite(&(v1518_56),&(v1518_59));
  drop(v1518_56);
  drop(v1518_59);
  let v1518_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1518_63: Space = singleton(&(v1518_62));
  drop(v1518_62);
  let v1518_64: Space = map_map_kernels::unite(&(v1518_60),&(v1518_63));
  drop(v1518_60);
  drop(v1518_63);
  let v1518_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1518_67: Space = singleton(&(v1518_66));
  drop(v1518_66);
  let v1518_68: Space = map_map_kernels::unite(&(v1518_64),&(v1518_67));
  drop(v1518_64);
  drop(v1518_67);
  let v1518_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1518_71: Space = singleton(&(v1518_70));
  drop(v1518_70);
  let v1518_72: Space = map_map_kernels::unite(&(v1518_68),&(v1518_71));
  drop(v1518_68);
  drop(v1518_71);
  let v1518_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1518_75: Space = singleton(&(v1518_74));
  drop(v1518_74);
  let v1518_76: Space = map_map_kernels::unite(&(v1518_72),&(v1518_75));
  drop(v1518_72);
  drop(v1518_75);
  (v1518_76).clone()
}

fn routine_150(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1519_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1519_19: Space = singleton(&(v1519_18));
  drop(v1519_18);
  let v1519_20: Space = map_map_kernels::unite(&(*CONSTANT_91),&(v1519_19));
  drop(v1519_19);
  let v1519_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1519_23: Space = singleton(&(v1519_22));
  drop(v1519_22);
  let v1519_24: Space = map_map_kernels::unite(&(v1519_20),&(v1519_23));
  drop(v1519_20);
  drop(v1519_23);
  let v1519_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1519_27: Space = singleton(&(v1519_26));
  drop(v1519_26);
  let v1519_28: Space = map_map_kernels::unite(&(v1519_24),&(v1519_27));
  drop(v1519_24);
  drop(v1519_27);
  let v1519_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1519_31: Space = singleton(&(v1519_30));
  drop(v1519_30);
  let v1519_32: Space = map_map_kernels::unite(&(v1519_28),&(v1519_31));
  drop(v1519_28);
  drop(v1519_31);
  let v1519_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1519_35: Space = singleton(&(v1519_34));
  drop(v1519_34);
  let v1519_36: Space = map_map_kernels::unite(&(v1519_32),&(v1519_35));
  drop(v1519_32);
  drop(v1519_35);
  let v1519_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1519_39: Space = singleton(&(v1519_38));
  drop(v1519_38);
  let v1519_40: Space = map_map_kernels::unite(&(v1519_36),&(v1519_39));
  drop(v1519_36);
  drop(v1519_39);
  let v1519_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1519_43: Space = singleton(&(v1519_42));
  drop(v1519_42);
  let v1519_44: Space = map_map_kernels::unite(&(v1519_40),&(v1519_43));
  drop(v1519_40);
  drop(v1519_43);
  let v1519_46: Path = concat_path(&(*CONSTANT_17),&(*p8));
  let v1519_47: Space = singleton(&(v1519_46));
  drop(v1519_46);
  let v1519_48: Space = map_map_kernels::unite(&(v1519_44),&(v1519_47));
  drop(v1519_44);
  drop(v1519_47);
  let v1519_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1519_51: Space = singleton(&(v1519_50));
  drop(v1519_50);
  let v1519_52: Space = map_map_kernels::unite(&(v1519_48),&(v1519_51));
  drop(v1519_48);
  drop(v1519_51);
  let v1519_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1519_55: Space = singleton(&(v1519_54));
  drop(v1519_54);
  let v1519_56: Space = map_map_kernels::unite(&(v1519_52),&(v1519_55));
  drop(v1519_52);
  drop(v1519_55);
  let v1519_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1519_59: Space = singleton(&(v1519_58));
  drop(v1519_58);
  let v1519_60: Space = map_map_kernels::unite(&(v1519_56),&(v1519_59));
  drop(v1519_56);
  drop(v1519_59);
  let v1519_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1519_63: Space = singleton(&(v1519_62));
  drop(v1519_62);
  let v1519_64: Space = map_map_kernels::unite(&(v1519_60),&(v1519_63));
  drop(v1519_60);
  drop(v1519_63);
  let v1519_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1519_67: Space = singleton(&(v1519_66));
  drop(v1519_66);
  let v1519_68: Space = map_map_kernels::unite(&(v1519_64),&(v1519_67));
  drop(v1519_64);
  drop(v1519_67);
  let v1519_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1519_71: Space = singleton(&(v1519_70));
  drop(v1519_70);
  let v1519_72: Space = map_map_kernels::unite(&(v1519_68),&(v1519_71));
  drop(v1519_68);
  drop(v1519_71);
  let v1519_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1519_75: Space = singleton(&(v1519_74));
  drop(v1519_74);
  let v1519_76: Space = map_map_kernels::unite(&(v1519_72),&(v1519_75));
  drop(v1519_72);
  drop(v1519_75);
  (v1519_76).clone()
}

fn routine_151(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1520_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1520_19: Space = singleton(&(v1520_18));
  drop(v1520_18);
  let v1520_20: Space = map_map_kernels::unite(&(*CONSTANT_92),&(v1520_19));
  drop(v1520_19);
  let v1520_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1520_23: Space = singleton(&(v1520_22));
  drop(v1520_22);
  let v1520_24: Space = map_map_kernels::unite(&(v1520_20),&(v1520_23));
  drop(v1520_20);
  drop(v1520_23);
  let v1520_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1520_27: Space = singleton(&(v1520_26));
  drop(v1520_26);
  let v1520_28: Space = map_map_kernels::unite(&(v1520_24),&(v1520_27));
  drop(v1520_24);
  drop(v1520_27);
  let v1520_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1520_31: Space = singleton(&(v1520_30));
  drop(v1520_30);
  let v1520_32: Space = map_map_kernels::unite(&(v1520_28),&(v1520_31));
  drop(v1520_28);
  drop(v1520_31);
  let v1520_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1520_35: Space = singleton(&(v1520_34));
  drop(v1520_34);
  let v1520_36: Space = map_map_kernels::unite(&(v1520_32),&(v1520_35));
  drop(v1520_32);
  drop(v1520_35);
  let v1520_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1520_39: Space = singleton(&(v1520_38));
  drop(v1520_38);
  let v1520_40: Space = map_map_kernels::unite(&(v1520_36),&(v1520_39));
  drop(v1520_36);
  drop(v1520_39);
  let v1520_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1520_43: Space = singleton(&(v1520_42));
  drop(v1520_42);
  let v1520_44: Space = map_map_kernels::unite(&(v1520_40),&(v1520_43));
  drop(v1520_40);
  drop(v1520_43);
  let v1520_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1520_47: Space = singleton(&(v1520_46));
  drop(v1520_46);
  let v1520_48: Space = map_map_kernels::unite(&(v1520_44),&(v1520_47));
  drop(v1520_44);
  drop(v1520_47);
  let v1520_50: Path = concat_path(&(*CONSTANT_19),&(*p9));
  let v1520_51: Space = singleton(&(v1520_50));
  drop(v1520_50);
  let v1520_52: Space = map_map_kernels::unite(&(v1520_48),&(v1520_51));
  drop(v1520_48);
  drop(v1520_51);
  let v1520_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1520_55: Space = singleton(&(v1520_54));
  drop(v1520_54);
  let v1520_56: Space = map_map_kernels::unite(&(v1520_52),&(v1520_55));
  drop(v1520_52);
  drop(v1520_55);
  let v1520_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1520_59: Space = singleton(&(v1520_58));
  drop(v1520_58);
  let v1520_60: Space = map_map_kernels::unite(&(v1520_56),&(v1520_59));
  drop(v1520_56);
  drop(v1520_59);
  let v1520_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1520_63: Space = singleton(&(v1520_62));
  drop(v1520_62);
  let v1520_64: Space = map_map_kernels::unite(&(v1520_60),&(v1520_63));
  drop(v1520_60);
  drop(v1520_63);
  let v1520_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1520_67: Space = singleton(&(v1520_66));
  drop(v1520_66);
  let v1520_68: Space = map_map_kernels::unite(&(v1520_64),&(v1520_67));
  drop(v1520_64);
  drop(v1520_67);
  let v1520_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1520_71: Space = singleton(&(v1520_70));
  drop(v1520_70);
  let v1520_72: Space = map_map_kernels::unite(&(v1520_68),&(v1520_71));
  drop(v1520_68);
  drop(v1520_71);
  let v1520_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1520_75: Space = singleton(&(v1520_74));
  drop(v1520_74);
  let v1520_76: Space = map_map_kernels::unite(&(v1520_72),&(v1520_75));
  drop(v1520_72);
  drop(v1520_75);
  (v1520_76).clone()
}

fn routine_152(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1521_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1521_19: Space = singleton(&(v1521_18));
  drop(v1521_18);
  let v1521_20: Space = map_map_kernels::unite(&(*CONSTANT_93),&(v1521_19));
  drop(v1521_19);
  let v1521_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1521_23: Space = singleton(&(v1521_22));
  drop(v1521_22);
  let v1521_24: Space = map_map_kernels::unite(&(v1521_20),&(v1521_23));
  drop(v1521_20);
  drop(v1521_23);
  let v1521_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1521_27: Space = singleton(&(v1521_26));
  drop(v1521_26);
  let v1521_28: Space = map_map_kernels::unite(&(v1521_24),&(v1521_27));
  drop(v1521_24);
  drop(v1521_27);
  let v1521_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1521_31: Space = singleton(&(v1521_30));
  drop(v1521_30);
  let v1521_32: Space = map_map_kernels::unite(&(v1521_28),&(v1521_31));
  drop(v1521_28);
  drop(v1521_31);
  let v1521_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1521_35: Space = singleton(&(v1521_34));
  drop(v1521_34);
  let v1521_36: Space = map_map_kernels::unite(&(v1521_32),&(v1521_35));
  drop(v1521_32);
  drop(v1521_35);
  let v1521_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1521_39: Space = singleton(&(v1521_38));
  drop(v1521_38);
  let v1521_40: Space = map_map_kernels::unite(&(v1521_36),&(v1521_39));
  drop(v1521_36);
  drop(v1521_39);
  let v1521_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1521_43: Space = singleton(&(v1521_42));
  drop(v1521_42);
  let v1521_44: Space = map_map_kernels::unite(&(v1521_40),&(v1521_43));
  drop(v1521_40);
  drop(v1521_43);
  let v1521_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1521_47: Space = singleton(&(v1521_46));
  drop(v1521_46);
  let v1521_48: Space = map_map_kernels::unite(&(v1521_44),&(v1521_47));
  drop(v1521_44);
  drop(v1521_47);
  let v1521_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1521_51: Space = singleton(&(v1521_50));
  drop(v1521_50);
  let v1521_52: Space = map_map_kernels::unite(&(v1521_48),&(v1521_51));
  drop(v1521_48);
  drop(v1521_51);
  let v1521_54: Path = concat_path(&(*CONSTANT_21),&(*p10));
  let v1521_55: Space = singleton(&(v1521_54));
  drop(v1521_54);
  let v1521_56: Space = map_map_kernels::unite(&(v1521_52),&(v1521_55));
  drop(v1521_52);
  drop(v1521_55);
  let v1521_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1521_59: Space = singleton(&(v1521_58));
  drop(v1521_58);
  let v1521_60: Space = map_map_kernels::unite(&(v1521_56),&(v1521_59));
  drop(v1521_56);
  drop(v1521_59);
  let v1521_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1521_63: Space = singleton(&(v1521_62));
  drop(v1521_62);
  let v1521_64: Space = map_map_kernels::unite(&(v1521_60),&(v1521_63));
  drop(v1521_60);
  drop(v1521_63);
  let v1521_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1521_67: Space = singleton(&(v1521_66));
  drop(v1521_66);
  let v1521_68: Space = map_map_kernels::unite(&(v1521_64),&(v1521_67));
  drop(v1521_64);
  drop(v1521_67);
  let v1521_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1521_71: Space = singleton(&(v1521_70));
  drop(v1521_70);
  let v1521_72: Space = map_map_kernels::unite(&(v1521_68),&(v1521_71));
  drop(v1521_68);
  drop(v1521_71);
  let v1521_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1521_75: Space = singleton(&(v1521_74));
  drop(v1521_74);
  let v1521_76: Space = map_map_kernels::unite(&(v1521_72),&(v1521_75));
  drop(v1521_72);
  drop(v1521_75);
  (v1521_76).clone()
}

fn routine_153(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1522_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1522_19: Space = singleton(&(v1522_18));
  drop(v1522_18);
  let v1522_20: Space = map_map_kernels::unite(&(*CONSTANT_94),&(v1522_19));
  drop(v1522_19);
  let v1522_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1522_23: Space = singleton(&(v1522_22));
  drop(v1522_22);
  let v1522_24: Space = map_map_kernels::unite(&(v1522_20),&(v1522_23));
  drop(v1522_20);
  drop(v1522_23);
  let v1522_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1522_27: Space = singleton(&(v1522_26));
  drop(v1522_26);
  let v1522_28: Space = map_map_kernels::unite(&(v1522_24),&(v1522_27));
  drop(v1522_24);
  drop(v1522_27);
  let v1522_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1522_31: Space = singleton(&(v1522_30));
  drop(v1522_30);
  let v1522_32: Space = map_map_kernels::unite(&(v1522_28),&(v1522_31));
  drop(v1522_28);
  drop(v1522_31);
  let v1522_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1522_35: Space = singleton(&(v1522_34));
  drop(v1522_34);
  let v1522_36: Space = map_map_kernels::unite(&(v1522_32),&(v1522_35));
  drop(v1522_32);
  drop(v1522_35);
  let v1522_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1522_39: Space = singleton(&(v1522_38));
  drop(v1522_38);
  let v1522_40: Space = map_map_kernels::unite(&(v1522_36),&(v1522_39));
  drop(v1522_36);
  drop(v1522_39);
  let v1522_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1522_43: Space = singleton(&(v1522_42));
  drop(v1522_42);
  let v1522_44: Space = map_map_kernels::unite(&(v1522_40),&(v1522_43));
  drop(v1522_40);
  drop(v1522_43);
  let v1522_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1522_47: Space = singleton(&(v1522_46));
  drop(v1522_46);
  let v1522_48: Space = map_map_kernels::unite(&(v1522_44),&(v1522_47));
  drop(v1522_44);
  drop(v1522_47);
  let v1522_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1522_51: Space = singleton(&(v1522_50));
  drop(v1522_50);
  let v1522_52: Space = map_map_kernels::unite(&(v1522_48),&(v1522_51));
  drop(v1522_48);
  drop(v1522_51);
  let v1522_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1522_55: Space = singleton(&(v1522_54));
  drop(v1522_54);
  let v1522_56: Space = map_map_kernels::unite(&(v1522_52),&(v1522_55));
  drop(v1522_52);
  drop(v1522_55);
  let v1522_58: Path = concat_path(&(*CONSTANT_23),&(*p11));
  let v1522_59: Space = singleton(&(v1522_58));
  drop(v1522_58);
  let v1522_60: Space = map_map_kernels::unite(&(v1522_56),&(v1522_59));
  drop(v1522_56);
  drop(v1522_59);
  let v1522_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1522_63: Space = singleton(&(v1522_62));
  drop(v1522_62);
  let v1522_64: Space = map_map_kernels::unite(&(v1522_60),&(v1522_63));
  drop(v1522_60);
  drop(v1522_63);
  let v1522_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1522_67: Space = singleton(&(v1522_66));
  drop(v1522_66);
  let v1522_68: Space = map_map_kernels::unite(&(v1522_64),&(v1522_67));
  drop(v1522_64);
  drop(v1522_67);
  let v1522_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1522_71: Space = singleton(&(v1522_70));
  drop(v1522_70);
  let v1522_72: Space = map_map_kernels::unite(&(v1522_68),&(v1522_71));
  drop(v1522_68);
  drop(v1522_71);
  let v1522_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1522_75: Space = singleton(&(v1522_74));
  drop(v1522_74);
  let v1522_76: Space = map_map_kernels::unite(&(v1522_72),&(v1522_75));
  drop(v1522_72);
  drop(v1522_75);
  (v1522_76).clone()
}

fn routine_154(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1523_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1523_19: Space = singleton(&(v1523_18));
  drop(v1523_18);
  let v1523_20: Space = map_map_kernels::unite(&(*CONSTANT_95),&(v1523_19));
  drop(v1523_19);
  let v1523_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1523_23: Space = singleton(&(v1523_22));
  drop(v1523_22);
  let v1523_24: Space = map_map_kernels::unite(&(v1523_20),&(v1523_23));
  drop(v1523_20);
  drop(v1523_23);
  let v1523_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1523_27: Space = singleton(&(v1523_26));
  drop(v1523_26);
  let v1523_28: Space = map_map_kernels::unite(&(v1523_24),&(v1523_27));
  drop(v1523_24);
  drop(v1523_27);
  let v1523_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1523_31: Space = singleton(&(v1523_30));
  drop(v1523_30);
  let v1523_32: Space = map_map_kernels::unite(&(v1523_28),&(v1523_31));
  drop(v1523_28);
  drop(v1523_31);
  let v1523_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1523_35: Space = singleton(&(v1523_34));
  drop(v1523_34);
  let v1523_36: Space = map_map_kernels::unite(&(v1523_32),&(v1523_35));
  drop(v1523_32);
  drop(v1523_35);
  let v1523_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1523_39: Space = singleton(&(v1523_38));
  drop(v1523_38);
  let v1523_40: Space = map_map_kernels::unite(&(v1523_36),&(v1523_39));
  drop(v1523_36);
  drop(v1523_39);
  let v1523_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1523_43: Space = singleton(&(v1523_42));
  drop(v1523_42);
  let v1523_44: Space = map_map_kernels::unite(&(v1523_40),&(v1523_43));
  drop(v1523_40);
  drop(v1523_43);
  let v1523_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1523_47: Space = singleton(&(v1523_46));
  drop(v1523_46);
  let v1523_48: Space = map_map_kernels::unite(&(v1523_44),&(v1523_47));
  drop(v1523_44);
  drop(v1523_47);
  let v1523_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1523_51: Space = singleton(&(v1523_50));
  drop(v1523_50);
  let v1523_52: Space = map_map_kernels::unite(&(v1523_48),&(v1523_51));
  drop(v1523_48);
  drop(v1523_51);
  let v1523_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1523_55: Space = singleton(&(v1523_54));
  drop(v1523_54);
  let v1523_56: Space = map_map_kernels::unite(&(v1523_52),&(v1523_55));
  drop(v1523_52);
  drop(v1523_55);
  let v1523_58: Path = concat_path(&(*CONSTANT_21),&(*p11));
  let v1523_59: Space = singleton(&(v1523_58));
  drop(v1523_58);
  let v1523_60: Space = map_map_kernels::unite(&(v1523_56),&(v1523_59));
  drop(v1523_56);
  drop(v1523_59);
  let v1523_62: Path = concat_path(&(*CONSTANT_25),&(*p12));
  let v1523_63: Space = singleton(&(v1523_62));
  drop(v1523_62);
  let v1523_64: Space = map_map_kernels::unite(&(v1523_60),&(v1523_63));
  drop(v1523_60);
  drop(v1523_63);
  let v1523_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1523_67: Space = singleton(&(v1523_66));
  drop(v1523_66);
  let v1523_68: Space = map_map_kernels::unite(&(v1523_64),&(v1523_67));
  drop(v1523_64);
  drop(v1523_67);
  let v1523_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1523_71: Space = singleton(&(v1523_70));
  drop(v1523_70);
  let v1523_72: Space = map_map_kernels::unite(&(v1523_68),&(v1523_71));
  drop(v1523_68);
  drop(v1523_71);
  let v1523_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1523_75: Space = singleton(&(v1523_74));
  drop(v1523_74);
  let v1523_76: Space = map_map_kernels::unite(&(v1523_72),&(v1523_75));
  drop(v1523_72);
  drop(v1523_75);
  (v1523_76).clone()
}

fn routine_155(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1524_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1524_19: Space = singleton(&(v1524_18));
  drop(v1524_18);
  let v1524_20: Space = map_map_kernels::unite(&(*CONSTANT_96),&(v1524_19));
  drop(v1524_19);
  let v1524_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1524_23: Space = singleton(&(v1524_22));
  drop(v1524_22);
  let v1524_24: Space = map_map_kernels::unite(&(v1524_20),&(v1524_23));
  drop(v1524_20);
  drop(v1524_23);
  let v1524_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1524_27: Space = singleton(&(v1524_26));
  drop(v1524_26);
  let v1524_28: Space = map_map_kernels::unite(&(v1524_24),&(v1524_27));
  drop(v1524_24);
  drop(v1524_27);
  let v1524_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1524_31: Space = singleton(&(v1524_30));
  drop(v1524_30);
  let v1524_32: Space = map_map_kernels::unite(&(v1524_28),&(v1524_31));
  drop(v1524_28);
  drop(v1524_31);
  let v1524_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1524_35: Space = singleton(&(v1524_34));
  drop(v1524_34);
  let v1524_36: Space = map_map_kernels::unite(&(v1524_32),&(v1524_35));
  drop(v1524_32);
  drop(v1524_35);
  let v1524_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1524_39: Space = singleton(&(v1524_38));
  drop(v1524_38);
  let v1524_40: Space = map_map_kernels::unite(&(v1524_36),&(v1524_39));
  drop(v1524_36);
  drop(v1524_39);
  let v1524_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1524_43: Space = singleton(&(v1524_42));
  drop(v1524_42);
  let v1524_44: Space = map_map_kernels::unite(&(v1524_40),&(v1524_43));
  drop(v1524_40);
  drop(v1524_43);
  let v1524_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1524_47: Space = singleton(&(v1524_46));
  drop(v1524_46);
  let v1524_48: Space = map_map_kernels::unite(&(v1524_44),&(v1524_47));
  drop(v1524_44);
  drop(v1524_47);
  let v1524_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1524_51: Space = singleton(&(v1524_50));
  drop(v1524_50);
  let v1524_52: Space = map_map_kernels::unite(&(v1524_48),&(v1524_51));
  drop(v1524_48);
  drop(v1524_51);
  let v1524_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1524_55: Space = singleton(&(v1524_54));
  drop(v1524_54);
  let v1524_56: Space = map_map_kernels::unite(&(v1524_52),&(v1524_55));
  drop(v1524_52);
  drop(v1524_55);
  let v1524_58: Path = concat_path(&(*CONSTANT_21),&(*p11));
  let v1524_59: Space = singleton(&(v1524_58));
  drop(v1524_58);
  let v1524_60: Space = map_map_kernels::unite(&(v1524_56),&(v1524_59));
  drop(v1524_56);
  drop(v1524_59);
  let v1524_62: Path = concat_path(&(*CONSTANT_23),&(*p12));
  let v1524_63: Space = singleton(&(v1524_62));
  drop(v1524_62);
  let v1524_64: Space = map_map_kernels::unite(&(v1524_60),&(v1524_63));
  drop(v1524_60);
  drop(v1524_63);
  let v1524_66: Path = concat_path(&(*CONSTANT_27),&(*p13));
  let v1524_67: Space = singleton(&(v1524_66));
  drop(v1524_66);
  let v1524_68: Space = map_map_kernels::unite(&(v1524_64),&(v1524_67));
  drop(v1524_64);
  drop(v1524_67);
  let v1524_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1524_71: Space = singleton(&(v1524_70));
  drop(v1524_70);
  let v1524_72: Space = map_map_kernels::unite(&(v1524_68),&(v1524_71));
  drop(v1524_68);
  drop(v1524_71);
  let v1524_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1524_75: Space = singleton(&(v1524_74));
  drop(v1524_74);
  let v1524_76: Space = map_map_kernels::unite(&(v1524_72),&(v1524_75));
  drop(v1524_72);
  drop(v1524_75);
  (v1524_76).clone()
}

fn routine_156(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1525_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1525_19: Space = singleton(&(v1525_18));
  drop(v1525_18);
  let v1525_20: Space = map_map_kernels::unite(&(*CONSTANT_97),&(v1525_19));
  drop(v1525_19);
  let v1525_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1525_23: Space = singleton(&(v1525_22));
  drop(v1525_22);
  let v1525_24: Space = map_map_kernels::unite(&(v1525_20),&(v1525_23));
  drop(v1525_20);
  drop(v1525_23);
  let v1525_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1525_27: Space = singleton(&(v1525_26));
  drop(v1525_26);
  let v1525_28: Space = map_map_kernels::unite(&(v1525_24),&(v1525_27));
  drop(v1525_24);
  drop(v1525_27);
  let v1525_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1525_31: Space = singleton(&(v1525_30));
  drop(v1525_30);
  let v1525_32: Space = map_map_kernels::unite(&(v1525_28),&(v1525_31));
  drop(v1525_28);
  drop(v1525_31);
  let v1525_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1525_35: Space = singleton(&(v1525_34));
  drop(v1525_34);
  let v1525_36: Space = map_map_kernels::unite(&(v1525_32),&(v1525_35));
  drop(v1525_32);
  drop(v1525_35);
  let v1525_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1525_39: Space = singleton(&(v1525_38));
  drop(v1525_38);
  let v1525_40: Space = map_map_kernels::unite(&(v1525_36),&(v1525_39));
  drop(v1525_36);
  drop(v1525_39);
  let v1525_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1525_43: Space = singleton(&(v1525_42));
  drop(v1525_42);
  let v1525_44: Space = map_map_kernels::unite(&(v1525_40),&(v1525_43));
  drop(v1525_40);
  drop(v1525_43);
  let v1525_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1525_47: Space = singleton(&(v1525_46));
  drop(v1525_46);
  let v1525_48: Space = map_map_kernels::unite(&(v1525_44),&(v1525_47));
  drop(v1525_44);
  drop(v1525_47);
  let v1525_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1525_51: Space = singleton(&(v1525_50));
  drop(v1525_50);
  let v1525_52: Space = map_map_kernels::unite(&(v1525_48),&(v1525_51));
  drop(v1525_48);
  drop(v1525_51);
  let v1525_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1525_55: Space = singleton(&(v1525_54));
  drop(v1525_54);
  let v1525_56: Space = map_map_kernels::unite(&(v1525_52),&(v1525_55));
  drop(v1525_52);
  drop(v1525_55);
  let v1525_58: Path = concat_path(&(*CONSTANT_21),&(*p11));
  let v1525_59: Space = singleton(&(v1525_58));
  drop(v1525_58);
  let v1525_60: Space = map_map_kernels::unite(&(v1525_56),&(v1525_59));
  drop(v1525_56);
  drop(v1525_59);
  let v1525_62: Path = concat_path(&(*CONSTANT_23),&(*p12));
  let v1525_63: Space = singleton(&(v1525_62));
  drop(v1525_62);
  let v1525_64: Space = map_map_kernels::unite(&(v1525_60),&(v1525_63));
  drop(v1525_60);
  drop(v1525_63);
  let v1525_66: Path = concat_path(&(*CONSTANT_25),&(*p13));
  let v1525_67: Space = singleton(&(v1525_66));
  drop(v1525_66);
  let v1525_68: Space = map_map_kernels::unite(&(v1525_64),&(v1525_67));
  drop(v1525_64);
  drop(v1525_67);
  let v1525_70: Path = concat_path(&(*CONSTANT_29),&(*p14));
  let v1525_71: Space = singleton(&(v1525_70));
  drop(v1525_70);
  let v1525_72: Space = map_map_kernels::unite(&(v1525_68),&(v1525_71));
  drop(v1525_68);
  drop(v1525_71);
  let v1525_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1525_75: Space = singleton(&(v1525_74));
  drop(v1525_74);
  let v1525_76: Space = map_map_kernels::unite(&(v1525_72),&(v1525_75));
  drop(v1525_72);
  drop(v1525_75);
  (v1525_76).clone()
}

fn routine_157(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1526_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1526_19: Space = singleton(&(v1526_18));
  drop(v1526_18);
  let v1526_20: Space = map_map_kernels::unite(&(*CONSTANT_98),&(v1526_19));
  drop(v1526_19);
  let v1526_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1526_23: Space = singleton(&(v1526_22));
  drop(v1526_22);
  let v1526_24: Space = map_map_kernels::unite(&(v1526_20),&(v1526_23));
  drop(v1526_20);
  drop(v1526_23);
  let v1526_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1526_27: Space = singleton(&(v1526_26));
  drop(v1526_26);
  let v1526_28: Space = map_map_kernels::unite(&(v1526_24),&(v1526_27));
  drop(v1526_24);
  drop(v1526_27);
  let v1526_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1526_31: Space = singleton(&(v1526_30));
  drop(v1526_30);
  let v1526_32: Space = map_map_kernels::unite(&(v1526_28),&(v1526_31));
  drop(v1526_28);
  drop(v1526_31);
  let v1526_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1526_35: Space = singleton(&(v1526_34));
  drop(v1526_34);
  let v1526_36: Space = map_map_kernels::unite(&(v1526_32),&(v1526_35));
  drop(v1526_32);
  drop(v1526_35);
  let v1526_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1526_39: Space = singleton(&(v1526_38));
  drop(v1526_38);
  let v1526_40: Space = map_map_kernels::unite(&(v1526_36),&(v1526_39));
  drop(v1526_36);
  drop(v1526_39);
  let v1526_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1526_43: Space = singleton(&(v1526_42));
  drop(v1526_42);
  let v1526_44: Space = map_map_kernels::unite(&(v1526_40),&(v1526_43));
  drop(v1526_40);
  drop(v1526_43);
  let v1526_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1526_47: Space = singleton(&(v1526_46));
  drop(v1526_46);
  let v1526_48: Space = map_map_kernels::unite(&(v1526_44),&(v1526_47));
  drop(v1526_44);
  drop(v1526_47);
  let v1526_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1526_51: Space = singleton(&(v1526_50));
  drop(v1526_50);
  let v1526_52: Space = map_map_kernels::unite(&(v1526_48),&(v1526_51));
  drop(v1526_48);
  drop(v1526_51);
  let v1526_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1526_55: Space = singleton(&(v1526_54));
  drop(v1526_54);
  let v1526_56: Space = map_map_kernels::unite(&(v1526_52),&(v1526_55));
  drop(v1526_52);
  drop(v1526_55);
  let v1526_58: Path = concat_path(&(*CONSTANT_21),&(*p11));
  let v1526_59: Space = singleton(&(v1526_58));
  drop(v1526_58);
  let v1526_60: Space = map_map_kernels::unite(&(v1526_56),&(v1526_59));
  drop(v1526_56);
  drop(v1526_59);
  let v1526_62: Path = concat_path(&(*CONSTANT_23),&(*p12));
  let v1526_63: Space = singleton(&(v1526_62));
  drop(v1526_62);
  let v1526_64: Space = map_map_kernels::unite(&(v1526_60),&(v1526_63));
  drop(v1526_60);
  drop(v1526_63);
  let v1526_66: Path = concat_path(&(*CONSTANT_25),&(*p13));
  let v1526_67: Space = singleton(&(v1526_66));
  drop(v1526_66);
  let v1526_68: Space = map_map_kernels::unite(&(v1526_64),&(v1526_67));
  drop(v1526_64);
  drop(v1526_67);
  let v1526_70: Path = concat_path(&(*CONSTANT_27),&(*p14));
  let v1526_71: Space = singleton(&(v1526_70));
  drop(v1526_70);
  let v1526_72: Space = map_map_kernels::unite(&(v1526_68),&(v1526_71));
  drop(v1526_68);
  drop(v1526_71);
  let v1526_74: Path = concat_path(&(*CONSTANT_81),&(*p0));
  let v1526_75: Space = singleton(&(v1526_74));
  drop(v1526_74);
  let v1526_76: Space = map_map_kernels::unite(&(v1526_72),&(v1526_75));
  drop(v1526_72);
  drop(v1526_75);
  (v1526_76).clone()
}

fn routine_158(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, p4: &Path, p5: &Path, p6: &Path, p7: &Path, p8: &Path, p9: &Path, p10: &Path, p11: &Path, p12: &Path, p13: &Path, p14: &Path, s0: &Space) -> Space {
  let v1527_18: Path = concat_path(&(*CONSTANT_1),&(*p1));
  let v1527_19: Space = singleton(&(v1527_18));
  drop(v1527_18);
  let v1527_20: Space = map_map_kernels::unite(&(*CONSTANT_99),&(v1527_19));
  drop(v1527_19);
  let v1527_22: Path = concat_path(&(*CONSTANT_3),&(*p2));
  let v1527_23: Space = singleton(&(v1527_22));
  drop(v1527_22);
  let v1527_24: Space = map_map_kernels::unite(&(v1527_20),&(v1527_23));
  drop(v1527_20);
  drop(v1527_23);
  let v1527_26: Path = concat_path(&(*CONSTANT_5),&(*p3));
  let v1527_27: Space = singleton(&(v1527_26));
  drop(v1527_26);
  let v1527_28: Space = map_map_kernels::unite(&(v1527_24),&(v1527_27));
  drop(v1527_24);
  drop(v1527_27);
  let v1527_30: Path = concat_path(&(*CONSTANT_7),&(*p4));
  let v1527_31: Space = singleton(&(v1527_30));
  drop(v1527_30);
  let v1527_32: Space = map_map_kernels::unite(&(v1527_28),&(v1527_31));
  drop(v1527_28);
  drop(v1527_31);
  let v1527_34: Path = concat_path(&(*CONSTANT_9),&(*p5));
  let v1527_35: Space = singleton(&(v1527_34));
  drop(v1527_34);
  let v1527_36: Space = map_map_kernels::unite(&(v1527_32),&(v1527_35));
  drop(v1527_32);
  drop(v1527_35);
  let v1527_38: Path = concat_path(&(*CONSTANT_11),&(*p6));
  let v1527_39: Space = singleton(&(v1527_38));
  drop(v1527_38);
  let v1527_40: Space = map_map_kernels::unite(&(v1527_36),&(v1527_39));
  drop(v1527_36);
  drop(v1527_39);
  let v1527_42: Path = concat_path(&(*CONSTANT_13),&(*p7));
  let v1527_43: Space = singleton(&(v1527_42));
  drop(v1527_42);
  let v1527_44: Space = map_map_kernels::unite(&(v1527_40),&(v1527_43));
  drop(v1527_40);
  drop(v1527_43);
  let v1527_46: Path = concat_path(&(*CONSTANT_15),&(*p8));
  let v1527_47: Space = singleton(&(v1527_46));
  drop(v1527_46);
  let v1527_48: Space = map_map_kernels::unite(&(v1527_44),&(v1527_47));
  drop(v1527_44);
  drop(v1527_47);
  let v1527_50: Path = concat_path(&(*CONSTANT_17),&(*p9));
  let v1527_51: Space = singleton(&(v1527_50));
  drop(v1527_50);
  let v1527_52: Space = map_map_kernels::unite(&(v1527_48),&(v1527_51));
  drop(v1527_48);
  drop(v1527_51);
  let v1527_54: Path = concat_path(&(*CONSTANT_19),&(*p10));
  let v1527_55: Space = singleton(&(v1527_54));
  drop(v1527_54);
  let v1527_56: Space = map_map_kernels::unite(&(v1527_52),&(v1527_55));
  drop(v1527_52);
  drop(v1527_55);
  let v1527_58: Path = concat_path(&(*CONSTANT_21),&(*p11));
  let v1527_59: Space = singleton(&(v1527_58));
  drop(v1527_58);
  let v1527_60: Space = map_map_kernels::unite(&(v1527_56),&(v1527_59));
  drop(v1527_56);
  drop(v1527_59);
  let v1527_62: Path = concat_path(&(*CONSTANT_23),&(*p12));
  let v1527_63: Space = singleton(&(v1527_62));
  drop(v1527_62);
  let v1527_64: Space = map_map_kernels::unite(&(v1527_60),&(v1527_63));
  drop(v1527_60);
  drop(v1527_63);
  let v1527_66: Path = concat_path(&(*CONSTANT_25),&(*p13));
  let v1527_67: Space = singleton(&(v1527_66));
  drop(v1527_66);
  let v1527_68: Space = map_map_kernels::unite(&(v1527_64),&(v1527_67));
  drop(v1527_64);
  drop(v1527_67);
  let v1527_70: Path = concat_path(&(*CONSTANT_27),&(*p14));
  let v1527_71: Space = singleton(&(v1527_70));
  drop(v1527_70);
  let v1527_72: Space = map_map_kernels::unite(&(v1527_68),&(v1527_71));
  drop(v1527_68);
  drop(v1527_71);
  let v1527_74: Path = concat_path(&(*CONSTANT_29),&(*p0));
  let v1527_75: Space = singleton(&(v1527_74));
  drop(v1527_74);
  let v1527_76: Space = map_map_kernels::unite(&(v1527_72),&(v1527_75));
  drop(v1527_72);
  drop(v1527_75);
  (v1527_76).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
