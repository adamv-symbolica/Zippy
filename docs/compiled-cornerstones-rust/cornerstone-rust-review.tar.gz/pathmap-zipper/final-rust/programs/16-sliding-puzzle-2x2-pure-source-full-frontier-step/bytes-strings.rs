#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,76]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 7 0 49 0 51 0 50 0 7 0 50 0 49 0 51 0 7 0 51 0 50 0 49 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,82]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,76]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("3 7 0 49 0 50 0 51 0 7 0 50 0 51 0 49 0 7 0 51 0 49 0 50 0"));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,82]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 66 76 0"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 66 82 0"));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 84 76 0"));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 3 84 82 0"));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66]));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 10 76 0 82 0 66 76 0 66 82 0 10 76 0 82 0 66 82 0 66 76 0 10 76 0 85 0 66 76 0 84 76 0 10 76 0 85 0 84 76 0 66 76 0 10 82 0 76 0 66 76 0 66 82 0 10 82 0 76 0 66 82 0 66 76 0 10 82 0 85 0 66 82 0 84 82 0 10 82 0 85 0 84 82 0 66 82 0"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84]));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("8 10 76 0 68 0 66 76 0 84 76 0 10 76 0 68 0 84 76 0 66 76 0 10 76 0 82 0 84 76 0 84 82 0 10 76 0 82 0 84 82 0 84 76 0 10 82 0 68 0 66 82 0 84 82 0 10 82 0 68 0 84 82 0 66 82 0 10 82 0 76 0 84 76 0 84 82 0 10 82 0 76 0 84 82 0 84 76 0"));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,76,0]));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,82,0]));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,82,0]));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[66,76,0]));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 82 0 66 76 0 66 82 0 9 0 82 0 66 82 0 66 76 0 9 0 85 0 66 76 0 84 76 0 9 0 85 0 84 76 0 66 76 0"));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 76 0 66 76 0 66 82 0 9 0 76 0 66 82 0 66 76 0 9 0 85 0 66 82 0 84 82 0 9 0 85 0 84 82 0 66 82 0"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 68 0 66 76 0 84 76 0 9 0 68 0 84 76 0 66 76 0 9 0 82 0 84 76 0 84 82 0 9 0 82 0 84 82 0 84 76 0"));
static CONSTANT_23: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 9 0 68 0 66 82 0 84 82 0 9 0 68 0 84 82 0 66 82 0 9 0 76 0 84 76 0 84 82 0 9 0 76 0 84 82 0 84 76 0"));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 66 76 0 95 0"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 66 82 0 95 0"));
static CONSTANT_26: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 84 76 0 95 0"));
static CONSTANT_27: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 84 82 0 95 0"));
static CONSTANT_28: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 6 66 76 0 66 76 0 6 66 82 0 66 82 0 6 84 76 0 84 76 0 6 84 82 0 84 82 0"));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Path,capture_1: &Path,capture_2: &Path,capture_3: &Path) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v65_6: Space = singleton(&(*capture_1));
  let v65_7: Space = intersect(&(*CONSTANT_8),&(v65_6));
  let mut v65_11 = Space::new();
  let mut v65_11_cursor = (v65_7).read_zipper();
  for v65_11_byte in v65_11_cursor.child_mask().iter() {
    v65_11_cursor.descend_to_byte(v65_11_byte);
    {
    let v65_11_tail = v65_11_cursor.fork_read_zipper();
    let v65_11_head = Path::from_slice(&[v65_11_byte]);
    let v66_2: Space = singleton(&(v65_11_head));
    let v66_3: Space = intersect(&(*CONSTANT_7),&(v66_2));
    let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
    drop(v66_3);
    let v66_5: Space = subtract(&(*CONSTANT_0),&(v66_4));
    drop(v66_4);
    let v66_7: Space = if (v66_5).is_empty() { Space::new() } else {
      let v67_6: Space = routine_12(c, &(v65_11_head), &(v65_11_tail).make_space());
      compose(&(v66_5),&(v67_6))
    };
    drop(v66_5);
    let v66_8: Space = intersect(&(*CONSTANT_7),&(v66_2));
    drop(v66_2);
    let v66_9: Space = if has_head(&(v66_8)) { singleton(&[]) } else { Space::new() };
    drop(v66_8);
    let v66_10: Space = compose(&(v66_9),&(v65_11_tail));
    drop(v66_9);
    let v66_11: Space = unite(&(v66_7),&(v66_10));
    drop(v66_10);
    v65_11.join_into((v66_11).clone());
    }
    v65_11_cursor.ascend(1);
  }
  drop(v65_11_cursor);
  drop(v65_7);
  let v65_22: Space = if (v65_11).is_empty() { Space::new() } else {
    let v68_12: Path = concat_path(&(*capture_2),&(*capture_3));
    let v68_13: Path = concat_path(&(v68_12),&(*capture_0));
    drop(v68_12);
    let v68_14: Space = singleton(&(v68_13));
    drop(v68_13);
    let mut v68_21 = Space::new();
    let mut v68_21_cursor = (v68_14).read_zipper();
    for v68_21_byte in v68_21_cursor.child_mask().iter() {
      v68_21_cursor.descend_to_byte(v68_21_byte);
      {
      let v68_21_tail = v68_21_cursor.fork_read_zipper();
      let v68_21_head = Path::from_slice(&[v68_21_byte]);
      let v69_2: Space = singleton(&(v68_21_head));
      let v69_3: Space = intersect(&(*CONSTANT_7),&(v69_2));
      let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
      drop(v69_3);
      let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
      drop(v69_4);
      let v69_7: Space = if (v69_5).is_empty() { Space::new() } else {
        let v70_6: Space = routine_13(c, &(v68_21_head), &(v68_21_tail).make_space());
        compose(&(v69_5),&(v70_6))
      };
      drop(v69_5);
      let v69_8: Space = intersect(&(*CONSTANT_7),&(v69_2));
      drop(v69_2);
      let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
      drop(v69_8);
      let v69_11: Space = if (v69_9).is_empty() { Space::new() } else {
        let mut v71_10 = Space::new();
        let mut v71_10_cursor = (v68_21_tail).read_zipper();
        for v71_10_byte in v71_10_cursor.child_mask().iter() {
          v71_10_cursor.descend_to_byte(v71_10_byte);
          {
          let v71_10_tail = v71_10_cursor.fork_read_zipper();
          let v71_10_head = Path::from_slice(&[v71_10_byte]);
          let v72_2: Space = singleton(&(v71_10_head));
          let v72_3: Space = intersect(&(*CONSTANT_7),&(v72_2));
          let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
          drop(v72_3);
          let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
          drop(v72_4);
          let v72_7: Space = if (v72_5).is_empty() { Space::new() } else {
            let v73_6: Space = routine_14(c, &(v71_10_head), &(v68_21_head), &(v71_10_tail).make_space());
            compose(&(v72_5),&(v73_6))
          };
          drop(v72_5);
          let v72_8: Space = intersect(&(*CONSTANT_7),&(v72_2));
          drop(v72_2);
          let v72_9: Space = if has_head(&(v72_8)) { singleton(&[]) } else { Space::new() };
          drop(v72_8);
          let v72_11: Space = if (v72_9).is_empty() { Space::new() } else {
            let v74_10: Space = routine_15(c, &(v71_10_head), &(v68_21_head), &(v71_10_tail).make_space());
            compose(&(v72_9),&(v74_10))
          };
          drop(v72_9);
          let v72_12: Space = unite(&(v72_7),&(v72_11));
          v71_10.join_into((v72_12).clone());
          }
          v71_10_cursor.ascend(1);
        }
        drop(v71_10_cursor);
        compose(&(v69_9),&(v71_10))
      };
      drop(v69_9);
      let v69_12: Space = unite(&(v69_7),&(v69_11));
      v68_21.join_into((v69_12).clone());
      }
      v68_21_cursor.ascend(1);
    }
    drop(v68_21_cursor);
    compose(&(v65_11),&(v68_21))
  };
  let v65_24: Space = intersect(&(*CONSTANT_9),&(v65_6));
  let mut v65_28 = Space::new();
  let mut v65_28_cursor = (v65_24).read_zipper();
  for v65_28_byte in v65_28_cursor.child_mask().iter() {
    v65_28_cursor.descend_to_byte(v65_28_byte);
    {
    let v65_28_tail = v65_28_cursor.fork_read_zipper();
    let v65_28_head = Path::from_slice(&[v65_28_byte]);
    let v75_2: Space = singleton(&(v65_28_head));
    let v75_3: Space = intersect(&(*CONSTANT_7),&(v75_2));
    let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
    drop(v75_3);
    let v75_5: Space = subtract(&(*CONSTANT_0),&(v75_4));
    drop(v75_4);
    let v75_7: Space = if (v75_5).is_empty() { Space::new() } else {
      let v76_6: Space = routine_16(c, &(v65_28_head), &(v65_28_tail).make_space());
      compose(&(v75_5),&(v76_6))
    };
    drop(v75_5);
    let v75_8: Space = intersect(&(*CONSTANT_7),&(v75_2));
    drop(v75_2);
    let v75_9: Space = if has_head(&(v75_8)) { singleton(&[]) } else { Space::new() };
    drop(v75_8);
    let v75_10: Space = compose(&(v75_9),&(v65_28_tail));
    drop(v75_9);
    let v75_11: Space = unite(&(v75_7),&(v75_10));
    drop(v75_10);
    v65_28.join_into((v75_11).clone());
    }
    v65_28_cursor.ascend(1);
  }
  drop(v65_28_cursor);
  drop(v65_24);
  let v65_36: Space = if (v65_28).is_empty() { Space::new() } else {
    let v77_12: Path = concat_path(&(*capture_2),&(*capture_3));
    let v77_13: Path = concat_path(&(v77_12),&(*capture_0));
    drop(v77_12);
    let v77_14: Space = singleton(&(v77_13));
    drop(v77_13);
    let mut v77_35 = Space::new();
    let mut v77_35_cursor = (v77_14).read_zipper();
    for v77_35_byte in v77_35_cursor.child_mask().iter() {
      v77_35_cursor.descend_to_byte(v77_35_byte);
      {
      let v77_35_tail = v77_35_cursor.fork_read_zipper();
      let v77_35_head = Path::from_slice(&[v77_35_byte]);
      let v78_2: Space = singleton(&(v77_35_head));
      let v78_3: Space = intersect(&(*CONSTANT_7),&(v78_2));
      let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
      drop(v78_3);
      let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
      drop(v78_4);
      let v78_7: Space = if (v78_5).is_empty() { Space::new() } else {
        let v79_6: Space = routine_17(c, &(v77_35_head), &(v77_35_tail).make_space());
        compose(&(v78_5),&(v79_6))
      };
      drop(v78_5);
      let v78_8: Space = intersect(&(*CONSTANT_7),&(v78_2));
      drop(v78_2);
      let v78_9: Space = if has_head(&(v78_8)) { singleton(&[]) } else { Space::new() };
      drop(v78_8);
      let v78_11: Space = if (v78_9).is_empty() { Space::new() } else {
        let mut v80_10 = Space::new();
        let mut v80_10_cursor = (v77_35_tail).read_zipper();
        for v80_10_byte in v80_10_cursor.child_mask().iter() {
          v80_10_cursor.descend_to_byte(v80_10_byte);
          {
          let v80_10_tail = v80_10_cursor.fork_read_zipper();
          let v80_10_head = Path::from_slice(&[v80_10_byte]);
          let v81_2: Space = singleton(&(v80_10_head));
          let v81_3: Space = intersect(&(*CONSTANT_7),&(v81_2));
          let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
          drop(v81_3);
          let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
          drop(v81_4);
          let v81_7: Space = if (v81_5).is_empty() { Space::new() } else {
            let v82_6: Space = routine_18(c, &(v80_10_head), &(v77_35_head), &(v80_10_tail).make_space());
            compose(&(v81_5),&(v82_6))
          };
          drop(v81_5);
          let v81_8: Space = intersect(&(*CONSTANT_7),&(v81_2));
          drop(v81_2);
          let v81_9: Space = if has_head(&(v81_8)) { singleton(&[]) } else { Space::new() };
          drop(v81_8);
          let v81_11: Space = if (v81_9).is_empty() { Space::new() } else {
            let v83_10: Space = routine_19(c, &(v80_10_head), &(v77_35_head), &(v80_10_tail).make_space());
            compose(&(v81_9),&(v83_10))
          };
          drop(v81_9);
          let v81_12: Space = unite(&(v81_7),&(v81_11));
          v80_10.join_into((v81_12).clone());
          }
          v80_10_cursor.ascend(1);
        }
        drop(v80_10_cursor);
        compose(&(v78_9),&(v80_10))
      };
      drop(v78_9);
      let v78_12: Space = unite(&(v78_7),&(v78_11));
      v77_35.join_into((v78_12).clone());
      }
      v77_35_cursor.ascend(1);
    }
    drop(v77_35_cursor);
    compose(&(v65_28),&(v77_35))
  };
  let v65_37: Space = unite(&(v65_22),&(v65_36));
  let v65_39: Space = intersect(&(*CONSTANT_10),&(v65_6));
  let mut v65_43 = Space::new();
  let mut v65_43_cursor = (v65_39).read_zipper();
  for v65_43_byte in v65_43_cursor.child_mask().iter() {
    v65_43_cursor.descend_to_byte(v65_43_byte);
    {
    let v65_43_tail = v65_43_cursor.fork_read_zipper();
    let v65_43_head = Path::from_slice(&[v65_43_byte]);
    let v84_2: Space = singleton(&(v65_43_head));
    let v84_3: Space = intersect(&(*CONSTANT_7),&(v84_2));
    let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
    drop(v84_3);
    let v84_5: Space = subtract(&(*CONSTANT_0),&(v84_4));
    drop(v84_4);
    let v84_7: Space = if (v84_5).is_empty() { Space::new() } else {
      let v85_6: Space = routine_20(c, &(v65_43_head), &(v65_43_tail).make_space());
      compose(&(v84_5),&(v85_6))
    };
    drop(v84_5);
    let v84_8: Space = intersect(&(*CONSTANT_7),&(v84_2));
    drop(v84_2);
    let v84_9: Space = if has_head(&(v84_8)) { singleton(&[]) } else { Space::new() };
    drop(v84_8);
    let v84_10: Space = compose(&(v84_9),&(v65_43_tail));
    drop(v84_9);
    let v84_11: Space = unite(&(v84_7),&(v84_10));
    drop(v84_10);
    v65_43.join_into((v84_11).clone());
    }
    v65_43_cursor.ascend(1);
  }
  drop(v65_43_cursor);
  drop(v65_39);
  let v65_51: Space = if (v65_43).is_empty() { Space::new() } else {
    let v86_12: Path = concat_path(&(*capture_2),&(*capture_3));
    let v86_13: Path = concat_path(&(v86_12),&(*capture_0));
    drop(v86_12);
    let v86_14: Space = singleton(&(v86_13));
    drop(v86_13);
    let mut v86_50 = Space::new();
    let mut v86_50_cursor = (v86_14).read_zipper();
    for v86_50_byte in v86_50_cursor.child_mask().iter() {
      v86_50_cursor.descend_to_byte(v86_50_byte);
      {
      let v86_50_tail = v86_50_cursor.fork_read_zipper();
      let v86_50_head = Path::from_slice(&[v86_50_byte]);
      let v87_2: Space = singleton(&(v86_50_head));
      let v87_3: Space = intersect(&(*CONSTANT_7),&(v87_2));
      let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
      drop(v87_3);
      let v87_5: Space = subtract(&(*CONSTANT_0),&(v87_4));
      drop(v87_4);
      let v87_7: Space = if (v87_5).is_empty() { Space::new() } else {
        let v88_6: Space = routine_21(c, &(v86_50_head), &(v86_50_tail).make_space());
        compose(&(v87_5),&(v88_6))
      };
      drop(v87_5);
      let v87_8: Space = intersect(&(*CONSTANT_7),&(v87_2));
      drop(v87_2);
      let v87_9: Space = if has_head(&(v87_8)) { singleton(&[]) } else { Space::new() };
      drop(v87_8);
      let v87_11: Space = if (v87_9).is_empty() { Space::new() } else {
        let mut v89_10 = Space::new();
        let mut v89_10_cursor = (v86_50_tail).read_zipper();
        for v89_10_byte in v89_10_cursor.child_mask().iter() {
          v89_10_cursor.descend_to_byte(v89_10_byte);
          {
          let v89_10_tail = v89_10_cursor.fork_read_zipper();
          let v89_10_head = Path::from_slice(&[v89_10_byte]);
          let v90_2: Space = singleton(&(v89_10_head));
          let v90_3: Space = intersect(&(*CONSTANT_7),&(v90_2));
          let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
          drop(v90_3);
          let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
          drop(v90_4);
          let v90_7: Space = if (v90_5).is_empty() { Space::new() } else {
            let v91_6: Space = routine_22(c, &(v89_10_head), &(v86_50_head), &(v89_10_tail).make_space());
            compose(&(v90_5),&(v91_6))
          };
          drop(v90_5);
          let v90_8: Space = intersect(&(*CONSTANT_7),&(v90_2));
          drop(v90_2);
          let v90_9: Space = if has_head(&(v90_8)) { singleton(&[]) } else { Space::new() };
          drop(v90_8);
          let v90_11: Space = if (v90_9).is_empty() { Space::new() } else {
            let v92_10: Space = routine_23(c, &(v89_10_head), &(v86_50_head), &(v89_10_tail).make_space());
            compose(&(v90_9),&(v92_10))
          };
          drop(v90_9);
          let v90_12: Space = unite(&(v90_7),&(v90_11));
          v89_10.join_into((v90_12).clone());
          }
          v89_10_cursor.ascend(1);
        }
        drop(v89_10_cursor);
        compose(&(v87_9),&(v89_10))
      };
      drop(v87_9);
      let v87_12: Space = unite(&(v87_7),&(v87_11));
      v86_50.join_into((v87_12).clone());
      }
      v86_50_cursor.ascend(1);
    }
    drop(v86_50_cursor);
    compose(&(v65_43),&(v86_50))
  };
  let v65_52: Space = unite(&(v65_37),&(v65_51));
  let v65_54: Space = intersect(&(*CONSTANT_11),&(v65_6));
  drop(v65_6);
  let mut v65_58 = Space::new();
  let mut v65_58_cursor = (v65_54).read_zipper();
  for v65_58_byte in v65_58_cursor.child_mask().iter() {
    v65_58_cursor.descend_to_byte(v65_58_byte);
    {
    let v65_58_tail = v65_58_cursor.fork_read_zipper();
    let v65_58_head = Path::from_slice(&[v65_58_byte]);
    let v93_2: Space = singleton(&(v65_58_head));
    let v93_3: Space = intersect(&(*CONSTANT_7),&(v93_2));
    let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
    drop(v93_3);
    let v93_5: Space = subtract(&(*CONSTANT_0),&(v93_4));
    drop(v93_4);
    let v93_7: Space = if (v93_5).is_empty() { Space::new() } else {
      let v94_6: Space = routine_24(c, &(v65_58_head), &(v65_58_tail).make_space());
      compose(&(v93_5),&(v94_6))
    };
    drop(v93_5);
    let v93_8: Space = intersect(&(*CONSTANT_7),&(v93_2));
    drop(v93_2);
    let v93_9: Space = if has_head(&(v93_8)) { singleton(&[]) } else { Space::new() };
    drop(v93_8);
    let v93_10: Space = compose(&(v93_9),&(v65_58_tail));
    drop(v93_9);
    let v93_11: Space = unite(&(v93_7),&(v93_10));
    drop(v93_10);
    v65_58.join_into((v93_11).clone());
    }
    v65_58_cursor.ascend(1);
  }
  drop(v65_58_cursor);
  drop(v65_54);
  let v65_66: Space = if (v65_58).is_empty() { Space::new() } else {
    let v95_12: Path = concat_path(&(*capture_2),&(*capture_3));
    let v95_13: Path = concat_path(&(v95_12),&(*capture_0));
    drop(v95_12);
    let v95_14: Space = singleton(&(v95_13));
    drop(v95_13);
    let mut v95_65 = Space::new();
    let mut v95_65_cursor = (v95_14).read_zipper();
    for v95_65_byte in v95_65_cursor.child_mask().iter() {
      v95_65_cursor.descend_to_byte(v95_65_byte);
      {
      let v95_65_tail = v95_65_cursor.fork_read_zipper();
      let v95_65_head = Path::from_slice(&[v95_65_byte]);
      let v96_2: Space = singleton(&(v95_65_head));
      let v96_3: Space = intersect(&(*CONSTANT_7),&(v96_2));
      let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
      drop(v96_3);
      let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
      drop(v96_4);
      let v96_7: Space = if (v96_5).is_empty() { Space::new() } else {
        let v97_6: Space = routine_25(c, &(v95_65_head), &(v95_65_tail).make_space());
        compose(&(v96_5),&(v97_6))
      };
      drop(v96_5);
      let v96_8: Space = intersect(&(*CONSTANT_7),&(v96_2));
      drop(v96_2);
      let v96_9: Space = if has_head(&(v96_8)) { singleton(&[]) } else { Space::new() };
      drop(v96_8);
      let v96_11: Space = if (v96_9).is_empty() { Space::new() } else {
        let mut v98_10 = Space::new();
        let mut v98_10_cursor = (v95_65_tail).read_zipper();
        for v98_10_byte in v98_10_cursor.child_mask().iter() {
          v98_10_cursor.descend_to_byte(v98_10_byte);
          {
          let v98_10_tail = v98_10_cursor.fork_read_zipper();
          let v98_10_head = Path::from_slice(&[v98_10_byte]);
          let v99_2: Space = singleton(&(v98_10_head));
          let v99_3: Space = intersect(&(*CONSTANT_7),&(v99_2));
          let v99_4: Space = if has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
          drop(v99_3);
          let v99_5: Space = subtract(&(*CONSTANT_0),&(v99_4));
          drop(v99_4);
          let v99_7: Space = if (v99_5).is_empty() { Space::new() } else {
            let v100_6: Space = routine_26(c, &(v98_10_head), &(v95_65_head), &(v98_10_tail).make_space());
            compose(&(v99_5),&(v100_6))
          };
          drop(v99_5);
          let v99_8: Space = intersect(&(*CONSTANT_7),&(v99_2));
          drop(v99_2);
          let v99_9: Space = if has_head(&(v99_8)) { singleton(&[]) } else { Space::new() };
          drop(v99_8);
          let v99_11: Space = if (v99_9).is_empty() { Space::new() } else {
            let v101_10: Space = routine_27(c, &(v98_10_head), &(v95_65_head), &(v98_10_tail).make_space());
            compose(&(v99_9),&(v101_10))
          };
          drop(v99_9);
          let v99_12: Space = unite(&(v99_7),&(v99_11));
          v98_10.join_into((v99_12).clone());
          }
          v98_10_cursor.ascend(1);
        }
        drop(v98_10_cursor);
        compose(&(v96_9),&(v98_10))
      };
      drop(v96_9);
      let v96_12: Space = unite(&(v96_7),&(v96_11));
      v95_65.join_into((v96_12).clone());
      }
      v95_65_cursor.ascend(1);
    }
    drop(v95_65_cursor);
    drop(v95_14);
    compose(&(v65_58),&(v95_65))
  };
  let v65_67: Space = unite(&(v65_52),&(v65_66));
  let mut v65_82 = Space::new();
  let mut v65_82_cursor = (v65_67).read_zipper();
  for v65_82_byte in v65_82_cursor.child_mask().iter() {
    v65_82_cursor.descend_to_byte(v65_82_byte);
    {
    let v65_82_tail = v65_82_cursor.fork_read_zipper();
    let v65_82_head = Path::from_slice(&[v65_82_byte]);
    let v102_2: Space = singleton(&(v65_82_head));
    let v102_3: Space = intersect(&(*CONSTANT_7),&(v102_2));
    let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
    drop(v102_3);
    let v102_5: Space = subtract(&(*CONSTANT_0),&(v102_4));
    drop(v102_4);
    let v102_7: Space = if (v102_5).is_empty() { Space::new() } else {
      let mut v103_6 = Space::new();
      let mut v103_6_cursor = (v65_82_tail).read_zipper();
      for v103_6_byte in v103_6_cursor.child_mask().iter() {
        v103_6_cursor.descend_to_byte(v103_6_byte);
        {
        let v103_6_tail = v103_6_cursor.fork_read_zipper();
        let v103_6_head = Path::from_slice(&[v103_6_byte]);
        let v104_2: Space = singleton(&(v103_6_head));
        let v104_3: Space = intersect(&(*CONSTANT_7),&(v104_2));
        let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
        drop(v104_3);
        let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
        drop(v104_4);
        let v104_8: Space = if (v104_5).is_empty() { Space::new() } else {
          let v105_6: Path = concat_path(&(v65_82_head),&(v103_6_head));
          let v105_7: Space = routine_8(c, &(v105_6), &(*capture_1), &(v103_6_tail).make_space());
          compose(&(v104_5),&(v105_7))
        };
        drop(v104_5);
        let v104_9: Space = intersect(&(*CONSTANT_7),&(v104_2));
        drop(v104_2);
        let v104_10: Space = if has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
        drop(v104_9);
        let v104_12: Space = if (v104_10).is_empty() { Space::new() } else {
          let v106_6: Path = concat_path(&(v65_82_head),&(v103_6_head));
          let v106_11: Space = routine_9(c, &(v106_6), &(*capture_1), &(v103_6_tail).make_space());
          drop(v106_6);
          compose(&(v104_10),&(v106_11))
        };
        drop(v104_10);
        let v104_13: Space = unite(&(v104_8),&(v104_12));
        v103_6.join_into((v104_13).clone());
        }
        v103_6_cursor.ascend(1);
      }
      drop(v103_6_cursor);
      compose(&(v102_5),&(v103_6))
    };
    drop(v102_5);
    let v102_8: Space = intersect(&(*CONSTANT_7),&(v102_2));
    drop(v102_2);
    let v102_9: Space = if has_head(&(v102_8)) { singleton(&[]) } else { Space::new() };
    drop(v102_8);
    let v102_16: Space = if (v102_9).is_empty() { Space::new() } else {
      let v107_13: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v108_10: Space = routine_28(c, &(*CONSTANT_12), &(*CONSTANT_13));
        let v108_11: Space = routine_28(c, &(*CONSTANT_14), &(*CONSTANT_15));
        let v108_12: Space = unite(&(v108_10),&(v108_11));
        compose(&(*CONSTANT_0),&(v108_12))
      };
      let v107_14: Space = unwrap(&(v107_13),&(*capture_1));
      let mut v107_15 = Space::new();
      let mut v107_15_cursor = (v107_14).read_zipper();
      for v107_15_byte in v107_15_cursor.child_mask().iter() {
        v107_15_cursor.descend_to_byte(v107_15_byte);
        {
        let v107_15_tail = v107_15_cursor.fork_read_zipper();
        let v107_15_head = Path::from_slice(&[v107_15_byte]);
        let v109_2: Space = singleton(&(v107_15_head));
        let v109_3: Space = intersect(&(*CONSTANT_7),&(v109_2));
        let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
        drop(v109_3);
        let v109_5: Space = subtract(&(*CONSTANT_0),&(v109_4));
        drop(v109_4);
        let v109_7: Space = if (v109_5).is_empty() { Space::new() } else {
          let v110_6: Space = routine_29(c, &(v107_15_head), &(v65_82_head), &(v107_15_tail).make_space(), &(v65_82_tail).make_space());
          compose(&(v109_5),&(v110_6))
        };
        drop(v109_5);
        let v109_8: Space = intersect(&(*CONSTANT_7),&(v109_2));
        drop(v109_2);
        let v109_9: Space = if has_head(&(v109_8)) { singleton(&[]) } else { Space::new() };
        drop(v109_8);
        let v109_10: Space = unwrap(&(v107_15_tail),&(v65_82_head));
        let v109_11: Space = wrap(&(v109_10),&(v107_15_head));
        drop(v109_10);
        let v109_12: Space = compose(&(v109_11),&(v65_82_tail));
        drop(v109_11);
        let v109_13: Space = compose(&(v109_9),&(v109_12));
        drop(v109_9);
        drop(v109_12);
        let v109_14: Space = unite(&(v109_7),&(v109_13));
        drop(v109_13);
        v107_15.join_into((v109_14).clone());
        }
        v107_15_cursor.ascend(1);
      }
      drop(v107_15_cursor);
      compose(&(v102_9),&(v107_15))
    };
    drop(v102_9);
    let v102_17: Space = unite(&(v102_7),&(v102_16));
    v65_82.join_into((v102_17).clone());
    }
    v65_82_cursor.ascend(1);
  }
  drop(v65_82_cursor);
  let mut v65_103 = Space::new();
  let mut v65_103_cursor = (v65_82).read_zipper();
  for v65_103_byte in v65_103_cursor.child_mask().iter() {
    v65_103_cursor.descend_to_byte(v65_103_byte);
    {
    let v65_103_tail = v65_103_cursor.fork_read_zipper();
    let v65_103_head = Path::from_slice(&[v65_103_byte]);
    let v111_2: Space = singleton(&(v65_103_head));
    let v111_3: Space = intersect(&(*CONSTANT_7),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_0),&(v111_4));
    drop(v111_4);
    let v111_7: Space = if (v111_5).is_empty() { Space::new() } else {
      let mut v112_6 = Space::new();
      let mut v112_6_cursor = (v65_103_tail).read_zipper();
      for v112_6_byte in v112_6_cursor.child_mask().iter() {
        v112_6_cursor.descend_to_byte(v112_6_byte);
        {
        let v112_6_tail = v112_6_cursor.fork_read_zipper();
        let v112_6_head = Path::from_slice(&[v112_6_byte]);
        let v113_2: Space = singleton(&(v112_6_head));
        let v113_3: Space = intersect(&(*CONSTANT_7),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v65_103_head),&(v112_6_head));
          let v114_7: Space = routine_10(c, &(v114_6), &(*capture_1), &(v112_6_tail).make_space());
          compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = intersect(&(*CONSTANT_7),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (v113_10).is_empty() { Space::new() } else {
          let v115_6: Path = concat_path(&(v65_103_head),&(v112_6_head));
          let v115_11: Space = routine_11(c, &(v115_6), &(*capture_1), &(v112_6_tail).make_space());
          drop(v115_6);
          compose(&(v113_10),&(v115_11))
        };
        drop(v113_10);
        let v113_13: Space = unite(&(v113_8),&(v113_12));
        v112_6.join_into((v113_13).clone());
        }
        v112_6_cursor.ascend(1);
      }
      drop(v112_6_cursor);
      compose(&(v111_5),&(v112_6))
    };
    drop(v111_5);
    let v111_8: Space = intersect(&(*CONSTANT_7),&(v111_2));
    drop(v111_2);
    let v111_9: Space = if has_head(&(v111_8)) { singleton(&[]) } else { Space::new() };
    drop(v111_8);
    let v111_29: Space = if (v111_9).is_empty() { Space::new() } else {
      let v116_13: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v117_10: Space = routine_30(c, &(*CONSTANT_12), &(*CONSTANT_13));
        let v117_11: Space = routine_30(c, &(*CONSTANT_14), &(*CONSTANT_15));
        let v117_12: Space = unite(&(v117_10),&(v117_11));
        compose(&(*CONSTANT_0),&(v117_12))
      };
      let v116_14: Space = unwrap(&(v116_13),&(*capture_1));
      let v116_15: Space = unwrap(&(v116_14),&(v65_103_head));
      let v116_16: Space = unwrap(&(v116_15),&(*capture_1));
      let v116_17: Space = unwrap(&(v65_103_tail),&(*CONSTANT_16));
      let v116_18: Space = unwrap(&(v65_103_tail),&(*CONSTANT_17));
      let v116_19: Space = compose(&(v116_17),&(v116_18));
      let v116_20: Space = unwrap(&(v65_103_tail),&(*CONSTANT_18));
      let v116_21: Space = compose(&(v116_19),&(v116_20));
      let v116_22: Space = unwrap(&(v65_103_tail),&(*CONSTANT_19));
      let v116_23: Space = compose(&(v116_19),&(v116_22));
      drop(v116_19);
      let v116_24: Space = compose(&(v116_18),&(v116_22));
      drop(v116_18);
      let v116_25: Space = compose(&(v116_24),&(v116_20));
      drop(v116_24);
      let v116_26: Space = compose(&(v116_17),&(v116_22));
      drop(v116_17);
      drop(v116_22);
      let v116_27: Space = compose(&(v116_26),&(v116_20));
      drop(v116_20);
      drop(v116_26);
      let mut v116_28 = Space::new();
      let mut v116_28_cursor = (v116_16).read_zipper();
      for v116_28_byte in v116_28_cursor.child_mask().iter() {
        v116_28_cursor.descend_to_byte(v116_28_byte);
        {
        let v116_28_tail = v116_28_cursor.fork_read_zipper();
        let v116_28_head = Path::from_slice(&[v116_28_byte]);
        let v118_2: Space = singleton(&(v116_28_head));
        let v118_3: Space = intersect(&(*CONSTANT_7),&(v118_2));
        let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
        drop(v118_3);
        let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
        drop(v118_4);
        let v118_7: Space = if (v118_5).is_empty() { Space::new() } else {
          let v119_6: Space = routine_31(c, &(v116_28_head), &(v116_28_tail).make_space(), &(v65_103_tail).make_space());
          compose(&(v118_5),&(v119_6))
        };
        drop(v118_5);
        let v118_8: Space = intersect(&(*CONSTANT_7),&(v118_2));
        let v118_9: Space = if has_head(&(v118_8)) { singleton(&[]) } else { Space::new() };
        drop(v118_8);
        let v118_10: Space = intersect(&(*CONSTANT_8),&(v118_2));
        let v118_11: Space = compose(&(v118_10),&(v116_21));
        drop(v118_10);
        let v118_12: Space = intersect(&(*CONSTANT_9),&(v118_2));
        let v118_13: Space = compose(&(v118_12),&(v116_23));
        drop(v118_12);
        let v118_14: Space = unite(&(v118_11),&(v118_13));
        drop(v118_11);
        drop(v118_13);
        let v118_15: Space = intersect(&(*CONSTANT_10),&(v118_2));
        let v118_16: Space = compose(&(v118_15),&(v116_25));
        drop(v118_15);
        let v118_17: Space = unite(&(v118_14),&(v118_16));
        drop(v118_14);
        drop(v118_16);
        let v118_18: Space = intersect(&(*CONSTANT_11),&(v118_2));
        drop(v118_2);
        let v118_19: Space = compose(&(v118_18),&(v116_27));
        drop(v118_18);
        let v118_20: Space = unite(&(v118_17),&(v118_19));
        drop(v118_17);
        drop(v118_19);
        let v118_21: Space = compose(&(v118_9),&(v118_20));
        drop(v118_9);
        drop(v118_20);
        let v118_22: Space = unite(&(v118_7),&(v118_21));
        drop(v118_21);
        v116_28.join_into((v118_22).clone());
        }
        v116_28_cursor.ascend(1);
      }
      drop(v116_28_cursor);
      drop(v116_21);
      drop(v116_23);
      drop(v116_25);
      drop(v116_27);
      compose(&(v111_9),&(v116_28))
    };
    drop(v111_9);
    let v111_30: Space = unite(&(v111_7),&(v111_29));
    v65_103.join_into((v111_30).clone());
    }
    v65_103_cursor.ascend(1);
  }
  drop(v65_103_cursor);

((v65_103).clone(),(v65_11).clone(),(v65_22).clone(),(v65_28).clone(),(v65_36).clone(),(v65_37).clone(),(v65_43).clone(),(v65_51).clone(),(v65_52).clone(),(v65_58).clone(),(v65_66).clone(),(v65_67).clone(),(v65_82).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &Path,capture_1: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v120_3: Space = singleton(&(*capture_0));
  let v120_4: Space = intersect(&(*CONSTANT_8),&(v120_3));
  let mut v120_11 = Space::new();
  let mut v120_11_cursor = (v120_4).read_zipper();
  for v120_11_byte in v120_11_cursor.child_mask().iter() {
    v120_11_cursor.descend_to_byte(v120_11_byte);
    {
    let v120_11_tail = v120_11_cursor.fork_read_zipper();
    let v120_11_head = Path::from_slice(&[v120_11_byte]);
    let v121_2: Space = singleton(&(v120_11_head));
    let v121_3: Space = intersect(&(*CONSTANT_7),&(v121_2));
    let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
    drop(v121_3);
    let v121_5: Space = subtract(&(*CONSTANT_0),&(v121_4));
    drop(v121_4);
    let v121_7: Space = if (v121_5).is_empty() { Space::new() } else {
      let mut v122_6 = Space::new();
      let mut v122_6_cursor = (v120_11_tail).read_zipper();
      for v122_6_byte in v122_6_cursor.child_mask().iter() {
        v122_6_cursor.descend_to_byte(v122_6_byte);
        {
        let v122_6_tail = v122_6_cursor.fork_read_zipper();
        let v122_6_head = Path::from_slice(&[v122_6_byte]);
        let v123_2: Space = singleton(&(v122_6_head));
        let v123_3: Space = intersect(&(*CONSTANT_7),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
        drop(v123_4);
        let v123_8: Space = if (v123_5).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v120_11_head),&(v122_6_head));
          let v124_7: Space = routine_12(c, &(v124_6), &(v122_6_tail).make_space());
          drop(v124_6);
          compose(&(v123_5),&(v124_7))
        };
        drop(v123_5);
        let v123_9: Space = intersect(&(*CONSTANT_7),&(v123_2));
        drop(v123_2);
        let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
        drop(v123_9);
        let v123_11: Space = compose(&(v123_10),&(v122_6_tail));
        drop(v123_10);
        let v123_12: Space = unite(&(v123_8),&(v123_11));
        drop(v123_11);
        v122_6.join_into((v123_12).clone());
        }
        v122_6_cursor.ascend(1);
      }
      drop(v122_6_cursor);
      compose(&(v121_5),&(v122_6))
    };
    drop(v121_5);
    let v121_8: Space = intersect(&(*CONSTANT_7),&(v121_2));
    drop(v121_2);
    let v121_9: Space = if has_head(&(v121_8)) { singleton(&[]) } else { Space::new() };
    drop(v121_8);
    let v121_10: Space = compose(&(v121_9),&(v120_11_tail));
    drop(v121_9);
    let v121_11: Space = unite(&(v121_7),&(v121_10));
    drop(v121_10);
    v120_11.join_into((v121_11).clone());
    }
    v120_11_cursor.ascend(1);
  }
  drop(v120_11_cursor);
  drop(v120_4);
  let v120_28: Space = if (v120_11).is_empty() { Space::new() } else {
    let mut v125_27 = Space::new();
    let mut v125_27_cursor = (*capture_1).read_zipper();
    for v125_27_byte in v125_27_cursor.child_mask().iter() {
      v125_27_cursor.descend_to_byte(v125_27_byte);
      {
      let v125_27_tail = v125_27_cursor.fork_read_zipper();
      let v125_27_head = Path::from_slice(&[v125_27_byte]);
      let v126_2: Space = singleton(&(v125_27_head));
      let v126_3: Space = intersect(&(*CONSTANT_7),&(v126_2));
      let v126_4: Space = if has_head(&(v126_3)) { singleton(&[]) } else { Space::new() };
      drop(v126_3);
      let v126_5: Space = subtract(&(*CONSTANT_0),&(v126_4));
      drop(v126_4);
      let v126_7: Space = if (v126_5).is_empty() { Space::new() } else {
        let mut v127_6 = Space::new();
        let mut v127_6_cursor = (v125_27_tail).read_zipper();
        for v127_6_byte in v127_6_cursor.child_mask().iter() {
          v127_6_cursor.descend_to_byte(v127_6_byte);
          {
          let v127_6_tail = v127_6_cursor.fork_read_zipper();
          let v127_6_head = Path::from_slice(&[v127_6_byte]);
          let v128_2: Space = singleton(&(v127_6_head));
          let v128_3: Space = intersect(&(*CONSTANT_7),&(v128_2));
          let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
          drop(v128_3);
          let v128_5: Space = subtract(&(*CONSTANT_0),&(v128_4));
          drop(v128_4);
          let v128_8: Space = if (v128_5).is_empty() { Space::new() } else {
            let v129_6: Path = concat_path(&(v125_27_head),&(v127_6_head));
            let v129_7: Space = routine_13(c, &(v129_6), &(v127_6_tail).make_space());
            compose(&(v128_5),&(v129_7))
          };
          drop(v128_5);
          let v128_9: Space = intersect(&(*CONSTANT_7),&(v128_2));
          drop(v128_2);
          let v128_10: Space = if has_head(&(v128_9)) { singleton(&[]) } else { Space::new() };
          drop(v128_9);
          let v128_12: Space = if (v128_10).is_empty() { Space::new() } else {
            let v130_6: Path = concat_path(&(v125_27_head),&(v127_6_head));
            let mut v130_11 = Space::new();
            let mut v130_11_cursor = (v127_6_tail).read_zipper();
            for v130_11_byte in v130_11_cursor.child_mask().iter() {
              v130_11_cursor.descend_to_byte(v130_11_byte);
              {
              let v130_11_tail = v130_11_cursor.fork_read_zipper();
              let v130_11_head = Path::from_slice(&[v130_11_byte]);
              let v131_2: Space = singleton(&(v130_11_head));
              let v131_3: Space = intersect(&(*CONSTANT_7),&(v131_2));
              let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
              drop(v131_3);
              let v131_5: Space = subtract(&(*CONSTANT_0),&(v131_4));
              drop(v131_4);
              let v131_7: Space = if (v131_5).is_empty() { Space::new() } else {
                let v132_6: Space = routine_14(c, &(v130_11_head), &(v130_6), &(v130_11_tail).make_space());
                compose(&(v131_5),&(v132_6))
              };
              drop(v131_5);
              let v131_8: Space = intersect(&(*CONSTANT_7),&(v131_2));
              drop(v131_2);
              let v131_9: Space = if has_head(&(v131_8)) { singleton(&[]) } else { Space::new() };
              drop(v131_8);
              let v131_11: Space = if (v131_9).is_empty() { Space::new() } else {
                let v133_10: Space = routine_15(c, &(v130_11_head), &(v130_6), &(v130_11_tail).make_space());
                compose(&(v131_9),&(v133_10))
              };
              drop(v131_9);
              let v131_12: Space = unite(&(v131_7),&(v131_11));
              v130_11.join_into((v131_12).clone());
              }
              v130_11_cursor.ascend(1);
            }
            drop(v130_11_cursor);
            drop(v130_6);
            compose(&(v128_10),&(v130_11))
          };
          drop(v128_10);
          let v128_13: Space = unite(&(v128_8),&(v128_12));
          v127_6.join_into((v128_13).clone());
          }
          v127_6_cursor.ascend(1);
        }
        drop(v127_6_cursor);
        compose(&(v126_5),&(v127_6))
      };
      drop(v126_5);
      let v126_8: Space = intersect(&(*CONSTANT_7),&(v126_2));
      drop(v126_2);
      let v126_9: Space = if has_head(&(v126_8)) { singleton(&[]) } else { Space::new() };
      drop(v126_8);
      let v126_11: Space = if (v126_9).is_empty() { Space::new() } else {
        let mut v134_10 = Space::new();
        let mut v134_10_cursor = (v125_27_tail).read_zipper();
        for v134_10_byte in v134_10_cursor.child_mask().iter() {
          v134_10_cursor.descend_to_byte(v134_10_byte);
          {
          let v134_10_tail = v134_10_cursor.fork_read_zipper();
          let v134_10_head = Path::from_slice(&[v134_10_byte]);
          let v135_2: Space = singleton(&(v134_10_head));
          let v135_3: Space = intersect(&(*CONSTANT_7),&(v135_2));
          let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
          drop(v135_3);
          let v135_5: Space = subtract(&(*CONSTANT_0),&(v135_4));
          drop(v135_4);
          let v135_7: Space = if (v135_5).is_empty() { Space::new() } else {
            let v136_6: Space = routine_14(c, &(v134_10_head), &(v125_27_head), &(v134_10_tail).make_space());
            compose(&(v135_5),&(v136_6))
          };
          drop(v135_5);
          let v135_8: Space = intersect(&(*CONSTANT_7),&(v135_2));
          drop(v135_2);
          let v135_9: Space = if has_head(&(v135_8)) { singleton(&[]) } else { Space::new() };
          drop(v135_8);
          let v135_11: Space = if (v135_9).is_empty() { Space::new() } else {
            let mut v137_10 = Space::new();
            let mut v137_10_cursor = (v134_10_tail).read_zipper();
            for v137_10_byte in v137_10_cursor.child_mask().iter() {
              v137_10_cursor.descend_to_byte(v137_10_byte);
              {
              let v137_10_tail = v137_10_cursor.fork_read_zipper();
              let v137_10_head = Path::from_slice(&[v137_10_byte]);
              let v138_2: Space = singleton(&(v137_10_head));
              let v138_3: Space = intersect(&(*CONSTANT_7),&(v138_2));
              let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
              drop(v138_3);
              let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
              drop(v138_4);
              let v138_7: Space = if (v138_5).is_empty() { Space::new() } else {
                let v139_6: Space = routine_32(c, &(v137_10_head), &(v125_27_head), &(v134_10_head), &(v137_10_tail).make_space());
                compose(&(v138_5),&(v139_6))
              };
              drop(v138_5);
              let v138_8: Space = intersect(&(*CONSTANT_7),&(v138_2));
              drop(v138_2);
              let v138_9: Space = if has_head(&(v138_8)) { singleton(&[]) } else { Space::new() };
              drop(v138_8);
              let v138_11: Space = if (v138_9).is_empty() { Space::new() } else {
                let v140_10: Space = routine_33(c, &(v137_10_head), &(v125_27_head), &(v134_10_head), &(v137_10_tail).make_space());
                compose(&(v138_9),&(v140_10))
              };
              drop(v138_9);
              let v138_12: Space = unite(&(v138_7),&(v138_11));
              v137_10.join_into((v138_12).clone());
              }
              v137_10_cursor.ascend(1);
            }
            drop(v137_10_cursor);
            compose(&(v135_9),&(v137_10))
          };
          drop(v135_9);
          let v135_12: Space = unite(&(v135_7),&(v135_11));
          v134_10.join_into((v135_12).clone());
          }
          v134_10_cursor.ascend(1);
        }
        drop(v134_10_cursor);
        compose(&(v126_9),&(v134_10))
      };
      drop(v126_9);
      let v126_12: Space = unite(&(v126_7),&(v126_11));
      v125_27.join_into((v126_12).clone());
      }
      v125_27_cursor.ascend(1);
    }
    drop(v125_27_cursor);
    compose(&(v120_11),&(v125_27))
  };
  let v120_30: Space = intersect(&(*CONSTANT_9),&(v120_3));
  let mut v120_37 = Space::new();
  let mut v120_37_cursor = (v120_30).read_zipper();
  for v120_37_byte in v120_37_cursor.child_mask().iter() {
    v120_37_cursor.descend_to_byte(v120_37_byte);
    {
    let v120_37_tail = v120_37_cursor.fork_read_zipper();
    let v120_37_head = Path::from_slice(&[v120_37_byte]);
    let v141_2: Space = singleton(&(v120_37_head));
    let v141_3: Space = intersect(&(*CONSTANT_7),&(v141_2));
    let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
    drop(v141_3);
    let v141_5: Space = subtract(&(*CONSTANT_0),&(v141_4));
    drop(v141_4);
    let v141_7: Space = if (v141_5).is_empty() { Space::new() } else {
      let mut v142_6 = Space::new();
      let mut v142_6_cursor = (v120_37_tail).read_zipper();
      for v142_6_byte in v142_6_cursor.child_mask().iter() {
        v142_6_cursor.descend_to_byte(v142_6_byte);
        {
        let v142_6_tail = v142_6_cursor.fork_read_zipper();
        let v142_6_head = Path::from_slice(&[v142_6_byte]);
        let v143_2: Space = singleton(&(v142_6_head));
        let v143_3: Space = intersect(&(*CONSTANT_7),&(v143_2));
        let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
        drop(v143_3);
        let v143_5: Space = subtract(&(*CONSTANT_0),&(v143_4));
        drop(v143_4);
        let v143_8: Space = if (v143_5).is_empty() { Space::new() } else {
          let v144_6: Path = concat_path(&(v120_37_head),&(v142_6_head));
          let v144_7: Space = routine_16(c, &(v144_6), &(v142_6_tail).make_space());
          drop(v144_6);
          compose(&(v143_5),&(v144_7))
        };
        drop(v143_5);
        let v143_9: Space = intersect(&(*CONSTANT_7),&(v143_2));
        drop(v143_2);
        let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
        drop(v143_9);
        let v143_11: Space = compose(&(v143_10),&(v142_6_tail));
        drop(v143_10);
        let v143_12: Space = unite(&(v143_8),&(v143_11));
        drop(v143_11);
        v142_6.join_into((v143_12).clone());
        }
        v142_6_cursor.ascend(1);
      }
      drop(v142_6_cursor);
      compose(&(v141_5),&(v142_6))
    };
    drop(v141_5);
    let v141_8: Space = intersect(&(*CONSTANT_7),&(v141_2));
    drop(v141_2);
    let v141_9: Space = if has_head(&(v141_8)) { singleton(&[]) } else { Space::new() };
    drop(v141_8);
    let v141_10: Space = compose(&(v141_9),&(v120_37_tail));
    drop(v141_9);
    let v141_11: Space = unite(&(v141_7),&(v141_10));
    drop(v141_10);
    v120_37.join_into((v141_11).clone());
    }
    v120_37_cursor.ascend(1);
  }
  drop(v120_37_cursor);
  drop(v120_30);
  let v120_54: Space = if (v120_37).is_empty() { Space::new() } else {
    let mut v145_53 = Space::new();
    let mut v145_53_cursor = (*capture_1).read_zipper();
    for v145_53_byte in v145_53_cursor.child_mask().iter() {
      v145_53_cursor.descend_to_byte(v145_53_byte);
      {
      let v145_53_tail = v145_53_cursor.fork_read_zipper();
      let v145_53_head = Path::from_slice(&[v145_53_byte]);
      let v146_2: Space = singleton(&(v145_53_head));
      let v146_3: Space = intersect(&(*CONSTANT_7),&(v146_2));
      let v146_4: Space = if has_head(&(v146_3)) { singleton(&[]) } else { Space::new() };
      drop(v146_3);
      let v146_5: Space = subtract(&(*CONSTANT_0),&(v146_4));
      drop(v146_4);
      let v146_7: Space = if (v146_5).is_empty() { Space::new() } else {
        let mut v147_6 = Space::new();
        let mut v147_6_cursor = (v145_53_tail).read_zipper();
        for v147_6_byte in v147_6_cursor.child_mask().iter() {
          v147_6_cursor.descend_to_byte(v147_6_byte);
          {
          let v147_6_tail = v147_6_cursor.fork_read_zipper();
          let v147_6_head = Path::from_slice(&[v147_6_byte]);
          let v148_2: Space = singleton(&(v147_6_head));
          let v148_3: Space = intersect(&(*CONSTANT_7),&(v148_2));
          let v148_4: Space = if has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
          drop(v148_3);
          let v148_5: Space = subtract(&(*CONSTANT_0),&(v148_4));
          drop(v148_4);
          let v148_8: Space = if (v148_5).is_empty() { Space::new() } else {
            let v149_6: Path = concat_path(&(v145_53_head),&(v147_6_head));
            let v149_7: Space = routine_17(c, &(v149_6), &(v147_6_tail).make_space());
            compose(&(v148_5),&(v149_7))
          };
          drop(v148_5);
          let v148_9: Space = intersect(&(*CONSTANT_7),&(v148_2));
          drop(v148_2);
          let v148_10: Space = if has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
          drop(v148_9);
          let v148_12: Space = if (v148_10).is_empty() { Space::new() } else {
            let v150_6: Path = concat_path(&(v145_53_head),&(v147_6_head));
            let mut v150_11 = Space::new();
            let mut v150_11_cursor = (v147_6_tail).read_zipper();
            for v150_11_byte in v150_11_cursor.child_mask().iter() {
              v150_11_cursor.descend_to_byte(v150_11_byte);
              {
              let v150_11_tail = v150_11_cursor.fork_read_zipper();
              let v150_11_head = Path::from_slice(&[v150_11_byte]);
              let v151_2: Space = singleton(&(v150_11_head));
              let v151_3: Space = intersect(&(*CONSTANT_7),&(v151_2));
              let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
              drop(v151_3);
              let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
              drop(v151_4);
              let v151_7: Space = if (v151_5).is_empty() { Space::new() } else {
                let v152_6: Space = routine_18(c, &(v150_11_head), &(v150_6), &(v150_11_tail).make_space());
                compose(&(v151_5),&(v152_6))
              };
              drop(v151_5);
              let v151_8: Space = intersect(&(*CONSTANT_7),&(v151_2));
              drop(v151_2);
              let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
              drop(v151_8);
              let v151_11: Space = if (v151_9).is_empty() { Space::new() } else {
                let v153_10: Space = routine_19(c, &(v150_11_head), &(v150_6), &(v150_11_tail).make_space());
                compose(&(v151_9),&(v153_10))
              };
              drop(v151_9);
              let v151_12: Space = unite(&(v151_7),&(v151_11));
              v150_11.join_into((v151_12).clone());
              }
              v150_11_cursor.ascend(1);
            }
            drop(v150_11_cursor);
            drop(v150_6);
            compose(&(v148_10),&(v150_11))
          };
          drop(v148_10);
          let v148_13: Space = unite(&(v148_8),&(v148_12));
          v147_6.join_into((v148_13).clone());
          }
          v147_6_cursor.ascend(1);
        }
        drop(v147_6_cursor);
        compose(&(v146_5),&(v147_6))
      };
      drop(v146_5);
      let v146_8: Space = intersect(&(*CONSTANT_7),&(v146_2));
      drop(v146_2);
      let v146_9: Space = if has_head(&(v146_8)) { singleton(&[]) } else { Space::new() };
      drop(v146_8);
      let v146_11: Space = if (v146_9).is_empty() { Space::new() } else {
        let mut v154_10 = Space::new();
        let mut v154_10_cursor = (v145_53_tail).read_zipper();
        for v154_10_byte in v154_10_cursor.child_mask().iter() {
          v154_10_cursor.descend_to_byte(v154_10_byte);
          {
          let v154_10_tail = v154_10_cursor.fork_read_zipper();
          let v154_10_head = Path::from_slice(&[v154_10_byte]);
          let v155_2: Space = singleton(&(v154_10_head));
          let v155_3: Space = intersect(&(*CONSTANT_7),&(v155_2));
          let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
          drop(v155_3);
          let v155_5: Space = subtract(&(*CONSTANT_0),&(v155_4));
          drop(v155_4);
          let v155_7: Space = if (v155_5).is_empty() { Space::new() } else {
            let v156_6: Space = routine_18(c, &(v154_10_head), &(v145_53_head), &(v154_10_tail).make_space());
            compose(&(v155_5),&(v156_6))
          };
          drop(v155_5);
          let v155_8: Space = intersect(&(*CONSTANT_7),&(v155_2));
          drop(v155_2);
          let v155_9: Space = if has_head(&(v155_8)) { singleton(&[]) } else { Space::new() };
          drop(v155_8);
          let v155_11: Space = if (v155_9).is_empty() { Space::new() } else {
            let mut v157_10 = Space::new();
            let mut v157_10_cursor = (v154_10_tail).read_zipper();
            for v157_10_byte in v157_10_cursor.child_mask().iter() {
              v157_10_cursor.descend_to_byte(v157_10_byte);
              {
              let v157_10_tail = v157_10_cursor.fork_read_zipper();
              let v157_10_head = Path::from_slice(&[v157_10_byte]);
              let v158_2: Space = singleton(&(v157_10_head));
              let v158_3: Space = intersect(&(*CONSTANT_7),&(v158_2));
              let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
              drop(v158_3);
              let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
              drop(v158_4);
              let v158_7: Space = if (v158_5).is_empty() { Space::new() } else {
                let v159_6: Space = routine_34(c, &(v157_10_head), &(v145_53_head), &(v154_10_head), &(v157_10_tail).make_space());
                compose(&(v158_5),&(v159_6))
              };
              drop(v158_5);
              let v158_8: Space = intersect(&(*CONSTANT_7),&(v158_2));
              drop(v158_2);
              let v158_9: Space = if has_head(&(v158_8)) { singleton(&[]) } else { Space::new() };
              drop(v158_8);
              let v158_11: Space = if (v158_9).is_empty() { Space::new() } else {
                let v160_10: Space = routine_35(c, &(v157_10_head), &(v145_53_head), &(v154_10_head), &(v157_10_tail).make_space());
                compose(&(v158_9),&(v160_10))
              };
              drop(v158_9);
              let v158_12: Space = unite(&(v158_7),&(v158_11));
              v157_10.join_into((v158_12).clone());
              }
              v157_10_cursor.ascend(1);
            }
            drop(v157_10_cursor);
            compose(&(v155_9),&(v157_10))
          };
          drop(v155_9);
          let v155_12: Space = unite(&(v155_7),&(v155_11));
          v154_10.join_into((v155_12).clone());
          }
          v154_10_cursor.ascend(1);
        }
        drop(v154_10_cursor);
        compose(&(v146_9),&(v154_10))
      };
      drop(v146_9);
      let v146_12: Space = unite(&(v146_7),&(v146_11));
      v145_53.join_into((v146_12).clone());
      }
      v145_53_cursor.ascend(1);
    }
    drop(v145_53_cursor);
    compose(&(v120_37),&(v145_53))
  };
  let v120_55: Space = unite(&(v120_28),&(v120_54));
  let v120_57: Space = intersect(&(*CONSTANT_10),&(v120_3));
  let mut v120_64 = Space::new();
  let mut v120_64_cursor = (v120_57).read_zipper();
  for v120_64_byte in v120_64_cursor.child_mask().iter() {
    v120_64_cursor.descend_to_byte(v120_64_byte);
    {
    let v120_64_tail = v120_64_cursor.fork_read_zipper();
    let v120_64_head = Path::from_slice(&[v120_64_byte]);
    let v161_2: Space = singleton(&(v120_64_head));
    let v161_3: Space = intersect(&(*CONSTANT_7),&(v161_2));
    let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
    drop(v161_3);
    let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
    drop(v161_4);
    let v161_7: Space = if (v161_5).is_empty() { Space::new() } else {
      let mut v162_6 = Space::new();
      let mut v162_6_cursor = (v120_64_tail).read_zipper();
      for v162_6_byte in v162_6_cursor.child_mask().iter() {
        v162_6_cursor.descend_to_byte(v162_6_byte);
        {
        let v162_6_tail = v162_6_cursor.fork_read_zipper();
        let v162_6_head = Path::from_slice(&[v162_6_byte]);
        let v163_2: Space = singleton(&(v162_6_head));
        let v163_3: Space = intersect(&(*CONSTANT_7),&(v163_2));
        let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
        drop(v163_3);
        let v163_5: Space = subtract(&(*CONSTANT_0),&(v163_4));
        drop(v163_4);
        let v163_8: Space = if (v163_5).is_empty() { Space::new() } else {
          let v164_6: Path = concat_path(&(v120_64_head),&(v162_6_head));
          let v164_7: Space = routine_20(c, &(v164_6), &(v162_6_tail).make_space());
          drop(v164_6);
          compose(&(v163_5),&(v164_7))
        };
        drop(v163_5);
        let v163_9: Space = intersect(&(*CONSTANT_7),&(v163_2));
        drop(v163_2);
        let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
        drop(v163_9);
        let v163_11: Space = compose(&(v163_10),&(v162_6_tail));
        drop(v163_10);
        let v163_12: Space = unite(&(v163_8),&(v163_11));
        drop(v163_11);
        v162_6.join_into((v163_12).clone());
        }
        v162_6_cursor.ascend(1);
      }
      drop(v162_6_cursor);
      compose(&(v161_5),&(v162_6))
    };
    drop(v161_5);
    let v161_8: Space = intersect(&(*CONSTANT_7),&(v161_2));
    drop(v161_2);
    let v161_9: Space = if has_head(&(v161_8)) { singleton(&[]) } else { Space::new() };
    drop(v161_8);
    let v161_10: Space = compose(&(v161_9),&(v120_64_tail));
    drop(v161_9);
    let v161_11: Space = unite(&(v161_7),&(v161_10));
    drop(v161_10);
    v120_64.join_into((v161_11).clone());
    }
    v120_64_cursor.ascend(1);
  }
  drop(v120_64_cursor);
  drop(v120_57);
  let v120_81: Space = if (v120_64).is_empty() { Space::new() } else {
    let mut v165_80 = Space::new();
    let mut v165_80_cursor = (*capture_1).read_zipper();
    for v165_80_byte in v165_80_cursor.child_mask().iter() {
      v165_80_cursor.descend_to_byte(v165_80_byte);
      {
      let v165_80_tail = v165_80_cursor.fork_read_zipper();
      let v165_80_head = Path::from_slice(&[v165_80_byte]);
      let v166_2: Space = singleton(&(v165_80_head));
      let v166_3: Space = intersect(&(*CONSTANT_7),&(v166_2));
      let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
      drop(v166_3);
      let v166_5: Space = subtract(&(*CONSTANT_0),&(v166_4));
      drop(v166_4);
      let v166_7: Space = if (v166_5).is_empty() { Space::new() } else {
        let mut v167_6 = Space::new();
        let mut v167_6_cursor = (v165_80_tail).read_zipper();
        for v167_6_byte in v167_6_cursor.child_mask().iter() {
          v167_6_cursor.descend_to_byte(v167_6_byte);
          {
          let v167_6_tail = v167_6_cursor.fork_read_zipper();
          let v167_6_head = Path::from_slice(&[v167_6_byte]);
          let v168_2: Space = singleton(&(v167_6_head));
          let v168_3: Space = intersect(&(*CONSTANT_7),&(v168_2));
          let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
          drop(v168_3);
          let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
          drop(v168_4);
          let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
            let v169_6: Path = concat_path(&(v165_80_head),&(v167_6_head));
            let v169_7: Space = routine_21(c, &(v169_6), &(v167_6_tail).make_space());
            compose(&(v168_5),&(v169_7))
          };
          drop(v168_5);
          let v168_9: Space = intersect(&(*CONSTANT_7),&(v168_2));
          drop(v168_2);
          let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
          drop(v168_9);
          let v168_12: Space = if (v168_10).is_empty() { Space::new() } else {
            let v170_6: Path = concat_path(&(v165_80_head),&(v167_6_head));
            let mut v170_11 = Space::new();
            let mut v170_11_cursor = (v167_6_tail).read_zipper();
            for v170_11_byte in v170_11_cursor.child_mask().iter() {
              v170_11_cursor.descend_to_byte(v170_11_byte);
              {
              let v170_11_tail = v170_11_cursor.fork_read_zipper();
              let v170_11_head = Path::from_slice(&[v170_11_byte]);
              let v171_2: Space = singleton(&(v170_11_head));
              let v171_3: Space = intersect(&(*CONSTANT_7),&(v171_2));
              let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
              drop(v171_3);
              let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
              drop(v171_4);
              let v171_7: Space = if (v171_5).is_empty() { Space::new() } else {
                let v172_6: Space = routine_22(c, &(v170_11_head), &(v170_6), &(v170_11_tail).make_space());
                compose(&(v171_5),&(v172_6))
              };
              drop(v171_5);
              let v171_8: Space = intersect(&(*CONSTANT_7),&(v171_2));
              drop(v171_2);
              let v171_9: Space = if has_head(&(v171_8)) { singleton(&[]) } else { Space::new() };
              drop(v171_8);
              let v171_11: Space = if (v171_9).is_empty() { Space::new() } else {
                let v173_10: Space = routine_23(c, &(v170_11_head), &(v170_6), &(v170_11_tail).make_space());
                compose(&(v171_9),&(v173_10))
              };
              drop(v171_9);
              let v171_12: Space = unite(&(v171_7),&(v171_11));
              v170_11.join_into((v171_12).clone());
              }
              v170_11_cursor.ascend(1);
            }
            drop(v170_11_cursor);
            drop(v170_6);
            compose(&(v168_10),&(v170_11))
          };
          drop(v168_10);
          let v168_13: Space = unite(&(v168_8),&(v168_12));
          v167_6.join_into((v168_13).clone());
          }
          v167_6_cursor.ascend(1);
        }
        drop(v167_6_cursor);
        compose(&(v166_5),&(v167_6))
      };
      drop(v166_5);
      let v166_8: Space = intersect(&(*CONSTANT_7),&(v166_2));
      drop(v166_2);
      let v166_9: Space = if has_head(&(v166_8)) { singleton(&[]) } else { Space::new() };
      drop(v166_8);
      let v166_11: Space = if (v166_9).is_empty() { Space::new() } else {
        let mut v174_10 = Space::new();
        let mut v174_10_cursor = (v165_80_tail).read_zipper();
        for v174_10_byte in v174_10_cursor.child_mask().iter() {
          v174_10_cursor.descend_to_byte(v174_10_byte);
          {
          let v174_10_tail = v174_10_cursor.fork_read_zipper();
          let v174_10_head = Path::from_slice(&[v174_10_byte]);
          let v175_2: Space = singleton(&(v174_10_head));
          let v175_3: Space = intersect(&(*CONSTANT_7),&(v175_2));
          let v175_4: Space = if has_head(&(v175_3)) { singleton(&[]) } else { Space::new() };
          drop(v175_3);
          let v175_5: Space = subtract(&(*CONSTANT_0),&(v175_4));
          drop(v175_4);
          let v175_7: Space = if (v175_5).is_empty() { Space::new() } else {
            let v176_6: Space = routine_22(c, &(v174_10_head), &(v165_80_head), &(v174_10_tail).make_space());
            compose(&(v175_5),&(v176_6))
          };
          drop(v175_5);
          let v175_8: Space = intersect(&(*CONSTANT_7),&(v175_2));
          drop(v175_2);
          let v175_9: Space = if has_head(&(v175_8)) { singleton(&[]) } else { Space::new() };
          drop(v175_8);
          let v175_11: Space = if (v175_9).is_empty() { Space::new() } else {
            let mut v177_10 = Space::new();
            let mut v177_10_cursor = (v174_10_tail).read_zipper();
            for v177_10_byte in v177_10_cursor.child_mask().iter() {
              v177_10_cursor.descend_to_byte(v177_10_byte);
              {
              let v177_10_tail = v177_10_cursor.fork_read_zipper();
              let v177_10_head = Path::from_slice(&[v177_10_byte]);
              let v178_2: Space = singleton(&(v177_10_head));
              let v178_3: Space = intersect(&(*CONSTANT_7),&(v178_2));
              let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
              drop(v178_3);
              let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
              drop(v178_4);
              let v178_7: Space = if (v178_5).is_empty() { Space::new() } else {
                let v179_6: Space = routine_36(c, &(v177_10_head), &(v165_80_head), &(v174_10_head), &(v177_10_tail).make_space());
                compose(&(v178_5),&(v179_6))
              };
              drop(v178_5);
              let v178_8: Space = intersect(&(*CONSTANT_7),&(v178_2));
              drop(v178_2);
              let v178_9: Space = if has_head(&(v178_8)) { singleton(&[]) } else { Space::new() };
              drop(v178_8);
              let v178_11: Space = if (v178_9).is_empty() { Space::new() } else {
                let v180_10: Space = routine_37(c, &(v177_10_head), &(v165_80_head), &(v174_10_head), &(v177_10_tail).make_space());
                compose(&(v178_9),&(v180_10))
              };
              drop(v178_9);
              let v178_12: Space = unite(&(v178_7),&(v178_11));
              v177_10.join_into((v178_12).clone());
              }
              v177_10_cursor.ascend(1);
            }
            drop(v177_10_cursor);
            compose(&(v175_9),&(v177_10))
          };
          drop(v175_9);
          let v175_12: Space = unite(&(v175_7),&(v175_11));
          v174_10.join_into((v175_12).clone());
          }
          v174_10_cursor.ascend(1);
        }
        drop(v174_10_cursor);
        compose(&(v166_9),&(v174_10))
      };
      drop(v166_9);
      let v166_12: Space = unite(&(v166_7),&(v166_11));
      v165_80.join_into((v166_12).clone());
      }
      v165_80_cursor.ascend(1);
    }
    drop(v165_80_cursor);
    compose(&(v120_64),&(v165_80))
  };

((v120_11).clone(),(v120_28).clone(),(v120_3).clone(),(v120_37).clone(),(v120_54).clone(),(v120_55).clone(),(v120_64).clone(),(v120_81).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_18: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_17: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v2_4: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
      let v2_7: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_2));
      let v2_8: Space = unite(&(v2_4),&(v2_7));
      let v2_11: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_5));
      let v2_12: Space = unite(&(v2_8),&(v2_11));
      let v2_15: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_5));
      let v2_16: Space = unite(&(v2_12),&(v2_15));
      compose(&(*CONSTANT_0),&(v2_16))
    };
    compose(&(*CONSTANT_0),&(v1_17))
  };
  (v0_18).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v3_11 = Space::new();
  let mut v3_11_cursor = (*s0).read_zipper();
  for v3_11_byte in v3_11_cursor.child_mask().iter() {
    v3_11_cursor.descend_to_byte(v3_11_byte);
    {
    let v3_11_tail = v3_11_cursor.fork_read_zipper();
    let v3_11_head = Path::from_slice(&[v3_11_byte]);
    let v4_2: Space = singleton(&(v3_11_head));
    let v4_3: Space = intersect(&(*CONSTANT_7),&(v4_2));
    let v4_4: Space = if has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
    drop(v4_3);
    let v4_5: Space = subtract(&(*CONSTANT_0),&(v4_4));
    drop(v4_4);
    let v4_8: Space = if (v4_5).is_empty() { Space::new() } else {
      let v5_6: Path = concat_path(&(*p0),&(v3_11_head));
      let v5_7: Space = routine_1(c, &(v5_6), &(v3_11_tail).make_space());
      compose(&(v4_5),&(v5_7))
    };
    drop(v4_5);
    let v4_9: Space = intersect(&(*CONSTANT_7),&(v4_2));
    drop(v4_2);
    let v4_10: Space = if has_head(&(v4_9)) { singleton(&[]) } else { Space::new() };
    drop(v4_9);
    let v4_12: Space = if (v4_10).is_empty() { Space::new() } else {
      let v6_6: Path = concat_path(&(*p0),&(v3_11_head));
      let mut v6_11 = Space::new();
      let mut v6_11_cursor = (v3_11_tail).read_zipper();
      for v6_11_byte in v6_11_cursor.child_mask().iter() {
        v6_11_cursor.descend_to_byte(v6_11_byte);
        {
        let v6_11_tail = v6_11_cursor.fork_read_zipper();
        let v6_11_head = Path::from_slice(&[v6_11_byte]);
        let v7_2: Space = singleton(&(v6_11_head));
        let v7_3: Space = intersect(&(*CONSTANT_7),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_7: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Space = routine_2(c, &(v6_11_head), &(v6_6), &(v6_11_tail).make_space());
          compose(&(v7_5),&(v8_6))
        };
        drop(v7_5);
        let v7_8: Space = intersect(&(*CONSTANT_7),&(v7_2));
        drop(v7_2);
        let v7_9: Space = if has_head(&(v7_8)) { singleton(&[]) } else { Space::new() };
        drop(v7_8);
        let v7_11: Space = if (v7_9).is_empty() { Space::new() } else {
          let mut v9_10 = Space::new();
          let mut v9_10_cursor = (v6_11_tail).read_zipper();
          for v9_10_byte in v9_10_cursor.child_mask().iter() {
            v9_10_cursor.descend_to_byte(v9_10_byte);
            {
            let v9_10_tail = v9_10_cursor.fork_read_zipper();
            let v9_10_head = Path::from_slice(&[v9_10_byte]);
            let v10_2: Space = singleton(&(v9_10_head));
            let v10_3: Space = intersect(&(*CONSTANT_7),&(v10_2));
            let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
            drop(v10_3);
            let v10_5: Space = subtract(&(*CONSTANT_0),&(v10_4));
            drop(v10_4);
            let v10_7: Space = if (v10_5).is_empty() { Space::new() } else {
              let v11_6: Space = routine_3(c, &(v9_10_head), &(v6_6), &(v6_11_head), &(v9_10_tail).make_space());
              compose(&(v10_5),&(v11_6))
            };
            drop(v10_5);
            let v10_8: Space = intersect(&(*CONSTANT_7),&(v10_2));
            drop(v10_2);
            let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
            drop(v10_8);
            let v10_11: Space = if (v10_9).is_empty() { Space::new() } else {
              let v12_10: Space = routine_4(c, &(v9_10_head), &(v6_6), &(v6_11_head), &(v9_10_tail).make_space());
              compose(&(v10_9),&(v12_10))
            };
            drop(v10_9);
            let v10_12: Space = unite(&(v10_7),&(v10_11));
            v9_10.join_into((v10_12).clone());
            }
            v9_10_cursor.ascend(1);
          }
          drop(v9_10_cursor);
          compose(&(v7_9),&(v9_10))
        };
        drop(v7_9);
        let v7_12: Space = unite(&(v7_7),&(v7_11));
        v6_11.join_into((v7_12).clone());
        }
        v6_11_cursor.ascend(1);
      }
      drop(v6_11_cursor);
      drop(v6_6);
      compose(&(v4_10),&(v6_11))
    };
    drop(v4_10);
    let v4_13: Space = unite(&(v4_8),&(v4_12));
    v3_11.join_into((v4_13).clone());
    }
    v3_11_cursor.ascend(1);
  }
  drop(v3_11_cursor);
  (v3_11).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v13_12 = Space::new();
  let mut v13_12_cursor = (*s0).read_zipper();
  for v13_12_byte in v13_12_cursor.child_mask().iter() {
    v13_12_cursor.descend_to_byte(v13_12_byte);
    {
    let v13_12_tail = v13_12_cursor.fork_read_zipper();
    let v13_12_head = Path::from_slice(&[v13_12_byte]);
    let v14_2: Space = singleton(&(v13_12_head));
    let v14_3: Space = intersect(&(*CONSTANT_7),&(v14_2));
    let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
    drop(v14_3);
    let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
    drop(v14_4);
    let v14_8: Space = if (v14_5).is_empty() { Space::new() } else {
      let v15_6: Path = concat_path(&(*p0),&(v13_12_head));
      let v15_7: Space = routine_2(c, &(v15_6), &(*p1), &(v13_12_tail).make_space());
      compose(&(v14_5),&(v15_7))
    };
    drop(v14_5);
    let v14_9: Space = intersect(&(*CONSTANT_7),&(v14_2));
    drop(v14_2);
    let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
    drop(v14_9);
    let v14_12: Space = if (v14_10).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v13_12_head));
      let mut v16_11 = Space::new();
      let mut v16_11_cursor = (v13_12_tail).read_zipper();
      for v16_11_byte in v16_11_cursor.child_mask().iter() {
        v16_11_cursor.descend_to_byte(v16_11_byte);
        {
        let v16_11_tail = v16_11_cursor.fork_read_zipper();
        let v16_11_head = Path::from_slice(&[v16_11_byte]);
        let v17_2: Space = singleton(&(v16_11_head));
        let v17_3: Space = intersect(&(*CONSTANT_7),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_7: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Space = routine_3(c, &(v16_11_head), &(*p1), &(v16_6), &(v16_11_tail).make_space());
          compose(&(v17_5),&(v18_6))
        };
        drop(v17_5);
        let v17_8: Space = intersect(&(*CONSTANT_7),&(v17_2));
        drop(v17_2);
        let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
        drop(v17_8);
        let v17_11: Space = if (v17_9).is_empty() { Space::new() } else {
          let mut v19_10 = Space::new();
          let mut v19_10_cursor = (v16_11_tail).read_zipper();
          for v19_10_byte in v19_10_cursor.child_mask().iter() {
            v19_10_cursor.descend_to_byte(v19_10_byte);
            {
            let v19_10_tail = v19_10_cursor.fork_read_zipper();
            let v19_10_head = Path::from_slice(&[v19_10_byte]);
            let v20_2: Space = singleton(&(v19_10_head));
            let v20_3: Space = intersect(&(*CONSTANT_7),&(v20_2));
            let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
            drop(v20_3);
            let v20_5: Space = subtract(&(*CONSTANT_0),&(v20_4));
            drop(v20_4);
            let v20_7: Space = if (v20_5).is_empty() { Space::new() } else {
              let v21_6: Space = routine_5(c, &(v19_10_head), &(*p1), &(v16_6), &(v16_11_head), &(v19_10_tail).make_space());
              compose(&(v20_5),&(v21_6))
            };
            drop(v20_5);
            let v20_8: Space = intersect(&(*CONSTANT_7),&(v20_2));
            drop(v20_2);
            let v20_9: Space = if has_head(&(v20_8)) { singleton(&[]) } else { Space::new() };
            drop(v20_8);
            let v20_11: Space = if (v20_9).is_empty() { Space::new() } else {
              let v22_10: Space = routine_6(c, &(v19_10_head), &(*p1), &(v16_6), &(v16_11_head), &(v19_10_tail).make_space());
              compose(&(v20_9),&(v22_10))
            };
            drop(v20_9);
            let v20_12: Space = unite(&(v20_7),&(v20_11));
            v19_10.join_into((v20_12).clone());
            }
            v19_10_cursor.ascend(1);
          }
          drop(v19_10_cursor);
          compose(&(v17_9),&(v19_10))
        };
        drop(v17_9);
        let v17_12: Space = unite(&(v17_7),&(v17_11));
        v16_11.join_into((v17_12).clone());
        }
        v16_11_cursor.ascend(1);
      }
      drop(v16_11_cursor);
      drop(v16_6);
      compose(&(v14_10),&(v16_11))
    };
    drop(v14_10);
    let v14_13: Space = unite(&(v14_8),&(v14_12));
    v13_12.join_into((v14_13).clone());
    }
    v13_12_cursor.ascend(1);
  }
  drop(v13_12_cursor);
  (v13_12).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let mut v23_16 = Space::new();
  let mut v23_16_cursor = (*s0).read_zipper();
  for v23_16_byte in v23_16_cursor.child_mask().iter() {
    v23_16_cursor.descend_to_byte(v23_16_byte);
    {
    let v23_16_tail = v23_16_cursor.fork_read_zipper();
    let v23_16_head = Path::from_slice(&[v23_16_byte]);
    let v24_2: Space = singleton(&(v23_16_head));
    let v24_3: Space = intersect(&(*CONSTANT_7),&(v24_2));
    let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
    drop(v24_3);
    let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
    drop(v24_4);
    let v24_8: Space = if (v24_5).is_empty() { Space::new() } else {
      let v25_6: Path = concat_path(&(*p0),&(v23_16_head));
      let v25_7: Space = routine_3(c, &(v25_6), &(*p1), &(*p2), &(v23_16_tail).make_space());
      compose(&(v24_5),&(v25_7))
    };
    drop(v24_5);
    let v24_9: Space = intersect(&(*CONSTANT_7),&(v24_2));
    drop(v24_2);
    let v24_10: Space = if has_head(&(v24_9)) { singleton(&[]) } else { Space::new() };
    drop(v24_9);
    let v24_13: Space = if (v24_10).is_empty() { Space::new() } else {
      let v26_6: Path = concat_path(&(*p0),&(v23_16_head));
      let v26_11: Path = concat_path(&(*p2),&(v26_6));
      let mut v26_12 = Space::new();
      let mut v26_12_cursor = (v23_16_tail).read_zipper();
      for v26_12_byte in v26_12_cursor.child_mask().iter() {
        v26_12_cursor.descend_to_byte(v26_12_byte);
        {
        let v26_12_tail = v26_12_cursor.fork_read_zipper();
        let v26_12_head = Path::from_slice(&[v26_12_byte]);
        let v27_2: Space = singleton(&(v26_12_head));
        let v27_3: Space = intersect(&(*CONSTANT_7),&(v27_2));
        let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
        drop(v27_3);
        let v27_5: Space = subtract(&(*CONSTANT_0),&(v27_4));
        drop(v27_4);
        let v27_7: Space = if (v27_5).is_empty() { Space::new() } else {
          let v28_6: Space = routine_5(c, &(v26_12_head), &(*p1), &(*p2), &(v26_6), &(v26_12_tail).make_space());
          compose(&(v27_5),&(v28_6))
        };
        drop(v27_5);
        let v27_8: Space = intersect(&(*CONSTANT_7),&(v27_2));
        drop(v27_2);
        let v27_9: Space = if has_head(&(v27_8)) { singleton(&[]) } else { Space::new() };
        drop(v27_8);
        let v27_15: Space = if (v27_9).is_empty() { Space::new() } else {
          let v29_10: Path = concat_path(&(v26_11),&(v26_12_head));
          let v29_11: Space = singleton(&(v29_10));
          drop(v29_10);
          let v29_12: Space = routine_7(c, &(*p1), &(v29_11));
          drop(v29_11);
          let mut v29_13 = Space::new();
          let mut v29_13_cursor = (v29_12).read_zipper();
          for v29_13_byte in v29_13_cursor.child_mask().iter() {
            v29_13_cursor.descend_to_byte(v29_13_byte);
            {
            let v29_13_tail = v29_13_cursor.fork_read_zipper();
            let v29_13_head = Path::from_slice(&[v29_13_byte]);
            let v30_2: Space = singleton(&(v29_13_head));
            let v30_3: Space = intersect(&(*CONSTANT_7),&(v30_2));
            let v30_4: Space = if has_head(&(v30_3)) { singleton(&[]) } else { Space::new() };
            drop(v30_3);
            let v30_5: Space = subtract(&(*CONSTANT_0),&(v30_4));
            drop(v30_4);
            let v30_7: Space = if (v30_5).is_empty() { Space::new() } else {
              let v31_6: Space = routine_8(c, &(v29_13_head), &(*p1), &(v29_13_tail).make_space());
              compose(&(v30_5),&(v31_6))
            };
            drop(v30_5);
            let v30_8: Space = intersect(&(*CONSTANT_7),&(v30_2));
            drop(v30_2);
            let v30_9: Space = if has_head(&(v30_8)) { singleton(&[]) } else { Space::new() };
            drop(v30_8);
            let v30_11: Space = if (v30_9).is_empty() { Space::new() } else {
              let v32_10: Space = routine_9(c, &(v29_13_head), &(*p1), &(v29_13_tail).make_space());
              compose(&(v30_9),&(v32_10))
            };
            drop(v30_9);
            let v30_12: Space = unite(&(v30_7),&(v30_11));
            v29_13.join_into((v30_12).clone());
            }
            v29_13_cursor.ascend(1);
          }
          drop(v29_13_cursor);
          let mut v29_14 = Space::new();
          let mut v29_14_cursor = (v29_13).read_zipper();
          for v29_14_byte in v29_14_cursor.child_mask().iter() {
            v29_14_cursor.descend_to_byte(v29_14_byte);
            {
            let v29_14_tail = v29_14_cursor.fork_read_zipper();
            let v29_14_head = Path::from_slice(&[v29_14_byte]);
            let v33_2: Space = singleton(&(v29_14_head));
            let v33_3: Space = intersect(&(*CONSTANT_7),&(v33_2));
            let v33_4: Space = if has_head(&(v33_3)) { singleton(&[]) } else { Space::new() };
            drop(v33_3);
            let v33_5: Space = subtract(&(*CONSTANT_0),&(v33_4));
            drop(v33_4);
            let v33_7: Space = if (v33_5).is_empty() { Space::new() } else {
              let v34_6: Space = routine_10(c, &(v29_14_head), &(*p1), &(v29_14_tail).make_space());
              compose(&(v33_5),&(v34_6))
            };
            drop(v33_5);
            let v33_8: Space = intersect(&(*CONSTANT_7),&(v33_2));
            drop(v33_2);
            let v33_9: Space = if has_head(&(v33_8)) { singleton(&[]) } else { Space::new() };
            drop(v33_8);
            let v33_11: Space = if (v33_9).is_empty() { Space::new() } else {
              let v35_10: Space = routine_11(c, &(v29_14_head), &(*p1), &(v29_14_tail).make_space());
              compose(&(v33_9),&(v35_10))
            };
            drop(v33_9);
            let v33_12: Space = unite(&(v33_7),&(v33_11));
            v29_14.join_into((v33_12).clone());
            }
            v29_14_cursor.ascend(1);
          }
          drop(v29_14_cursor);
          compose(&(v27_9),&(v29_14))
        };
        drop(v27_9);
        let v27_16: Space = unite(&(v27_7),&(v27_15));
        v26_12.join_into((v27_16).clone());
        }
        v26_12_cursor.ascend(1);
      }
      drop(v26_12_cursor);
      drop(v26_6);
      drop(v26_11);
      compose(&(v24_10),&(v26_12))
    };
    drop(v24_10);
    let v24_14: Space = unite(&(v24_8),&(v24_13));
    v23_16.join_into((v24_14).clone());
    }
    v23_16_cursor.ascend(1);
  }
  drop(v23_16_cursor);
  (v23_16).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v36_7: Path = concat_path(&(*p2),&(*p0));
  let mut v36_23 = Space::new();
  let mut v36_23_cursor = (*s0).read_zipper();
  for v36_23_byte in v36_23_cursor.child_mask().iter() {
    v36_23_cursor.descend_to_byte(v36_23_byte);
    {
    let v36_23_tail = v36_23_cursor.fork_read_zipper();
    let v36_23_head = Path::from_slice(&[v36_23_byte]);
    let v37_2: Space = singleton(&(v36_23_head));
    let v37_3: Space = intersect(&(*CONSTANT_7),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_7: Space = if (v37_5).is_empty() { Space::new() } else {
      let mut v38_6 = Space::new();
      let mut v38_6_cursor = (v36_23_tail).read_zipper();
      for v38_6_byte in v38_6_cursor.child_mask().iter() {
        v38_6_cursor.descend_to_byte(v38_6_byte);
        {
        let v38_6_tail = v38_6_cursor.fork_read_zipper();
        let v38_6_head = Path::from_slice(&[v38_6_byte]);
        let v39_2: Space = singleton(&(v38_6_head));
        let v39_3: Space = intersect(&(*CONSTANT_7),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v36_23_head),&(v38_6_head));
          let v40_7: Space = routine_5(c, &(v40_6), &(*p1), &(*p2), &(*p0), &(v38_6_tail).make_space());
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_7),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_16: Space = if (v39_10).is_empty() { Space::new() } else {
          let v41_6: Path = concat_path(&(v36_23_head),&(v38_6_head));
          let v41_11: Path = concat_path(&(v36_7),&(v41_6));
          drop(v41_6);
          let v41_12: Space = singleton(&(v41_11));
          drop(v41_11);
          let v41_13: Space = routine_7(c, &(*p1), &(v41_12));
          drop(v41_12);
          let mut v41_14 = Space::new();
          let mut v41_14_cursor = (v41_13).read_zipper();
          for v41_14_byte in v41_14_cursor.child_mask().iter() {
            v41_14_cursor.descend_to_byte(v41_14_byte);
            {
            let v41_14_tail = v41_14_cursor.fork_read_zipper();
            let v41_14_head = Path::from_slice(&[v41_14_byte]);
            let v42_2: Space = singleton(&(v41_14_head));
            let v42_3: Space = intersect(&(*CONSTANT_7),&(v42_2));
            let v42_4: Space = if has_head(&(v42_3)) { singleton(&[]) } else { Space::new() };
            drop(v42_3);
            let v42_5: Space = subtract(&(*CONSTANT_0),&(v42_4));
            drop(v42_4);
            let v42_7: Space = if (v42_5).is_empty() { Space::new() } else {
              let v43_6: Space = routine_8(c, &(v41_14_head), &(*p1), &(v41_14_tail).make_space());
              compose(&(v42_5),&(v43_6))
            };
            drop(v42_5);
            let v42_8: Space = intersect(&(*CONSTANT_7),&(v42_2));
            drop(v42_2);
            let v42_9: Space = if has_head(&(v42_8)) { singleton(&[]) } else { Space::new() };
            drop(v42_8);
            let v42_11: Space = if (v42_9).is_empty() { Space::new() } else {
              let v44_10: Space = routine_9(c, &(v41_14_head), &(*p1), &(v41_14_tail).make_space());
              compose(&(v42_9),&(v44_10))
            };
            drop(v42_9);
            let v42_12: Space = unite(&(v42_7),&(v42_11));
            v41_14.join_into((v42_12).clone());
            }
            v41_14_cursor.ascend(1);
          }
          drop(v41_14_cursor);
          let mut v41_15 = Space::new();
          let mut v41_15_cursor = (v41_14).read_zipper();
          for v41_15_byte in v41_15_cursor.child_mask().iter() {
            v41_15_cursor.descend_to_byte(v41_15_byte);
            {
            let v41_15_tail = v41_15_cursor.fork_read_zipper();
            let v41_15_head = Path::from_slice(&[v41_15_byte]);
            let v45_2: Space = singleton(&(v41_15_head));
            let v45_3: Space = intersect(&(*CONSTANT_7),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_7: Space = if (v45_5).is_empty() { Space::new() } else {
              let v46_6: Space = routine_10(c, &(v41_15_head), &(*p1), &(v41_15_tail).make_space());
              compose(&(v45_5),&(v46_6))
            };
            drop(v45_5);
            let v45_8: Space = intersect(&(*CONSTANT_7),&(v45_2));
            drop(v45_2);
            let v45_9: Space = if has_head(&(v45_8)) { singleton(&[]) } else { Space::new() };
            drop(v45_8);
            let v45_11: Space = if (v45_9).is_empty() { Space::new() } else {
              let v47_10: Space = routine_11(c, &(v41_15_head), &(*p1), &(v41_15_tail).make_space());
              compose(&(v45_9),&(v47_10))
            };
            drop(v45_9);
            let v45_12: Space = unite(&(v45_7),&(v45_11));
            v41_15.join_into((v45_12).clone());
            }
            v41_15_cursor.ascend(1);
          }
          drop(v41_15_cursor);
          compose(&(v39_10),&(v41_15))
        };
        drop(v39_10);
        let v39_17: Space = unite(&(v39_8),&(v39_16));
        v38_6.join_into((v39_17).clone());
        }
        v38_6_cursor.ascend(1);
      }
      drop(v38_6_cursor);
      compose(&(v37_5),&(v38_6))
    };
    drop(v37_5);
    let v37_8: Space = intersect(&(*CONSTANT_7),&(v37_2));
    drop(v37_2);
    let v37_9: Space = if has_head(&(v37_8)) { singleton(&[]) } else { Space::new() };
    drop(v37_8);
    let v37_15: Space = if (v37_9).is_empty() { Space::new() } else {
      let v48_10: Path = concat_path(&(v36_7),&(v36_23_head));
      let v48_11: Space = singleton(&(v48_10));
      drop(v48_10);
      let v48_12: Space = routine_7(c, &(*p1), &(v48_11));
      drop(v48_11);
      let mut v48_13 = Space::new();
      let mut v48_13_cursor = (v48_12).read_zipper();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_byte(v48_13_byte);
        {
        let v48_13_tail = v48_13_cursor.fork_read_zipper();
        let v48_13_head = Path::from_slice(&[v48_13_byte]);
        let v49_2: Space = singleton(&(v48_13_head));
        let v49_3: Space = intersect(&(*CONSTANT_7),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (v49_5).is_empty() { Space::new() } else {
          let v50_6: Space = routine_8(c, &(v48_13_head), &(*p1), &(v48_13_tail).make_space());
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_7),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (v49_9).is_empty() { Space::new() } else {
          let v51_10: Space = routine_9(c, &(v48_13_head), &(*p1), &(v48_13_tail).make_space());
          compose(&(v49_9),&(v51_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        v48_13.join_into((v49_12).clone());
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      let mut v48_14 = Space::new();
      let mut v48_14_cursor = (v48_13).read_zipper();
      for v48_14_byte in v48_14_cursor.child_mask().iter() {
        v48_14_cursor.descend_to_byte(v48_14_byte);
        {
        let v48_14_tail = v48_14_cursor.fork_read_zipper();
        let v48_14_head = Path::from_slice(&[v48_14_byte]);
        let v52_2: Space = singleton(&(v48_14_head));
        let v52_3: Space = intersect(&(*CONSTANT_7),&(v52_2));
        let v52_4: Space = if has_head(&(v52_3)) { singleton(&[]) } else { Space::new() };
        drop(v52_3);
        let v52_5: Space = subtract(&(*CONSTANT_0),&(v52_4));
        drop(v52_4);
        let v52_7: Space = if (v52_5).is_empty() { Space::new() } else {
          let v53_6: Space = routine_10(c, &(v48_14_head), &(*p1), &(v48_14_tail).make_space());
          compose(&(v52_5),&(v53_6))
        };
        drop(v52_5);
        let v52_8: Space = intersect(&(*CONSTANT_7),&(v52_2));
        drop(v52_2);
        let v52_9: Space = if has_head(&(v52_8)) { singleton(&[]) } else { Space::new() };
        drop(v52_8);
        let v52_11: Space = if (v52_9).is_empty() { Space::new() } else {
          let v54_10: Space = routine_11(c, &(v48_14_head), &(*p1), &(v48_14_tail).make_space());
          compose(&(v52_9),&(v54_10))
        };
        drop(v52_9);
        let v52_12: Space = unite(&(v52_7),&(v52_11));
        v48_14.join_into((v52_12).clone());
        }
        v48_14_cursor.ascend(1);
      }
      drop(v48_14_cursor);
      compose(&(v37_9),&(v48_14))
    };
    drop(v37_9);
    let v37_16: Space = unite(&(v37_7),&(v37_15));
    v36_23.join_into((v37_16).clone());
    }
    v36_23_cursor.ascend(1);
  }
  drop(v36_23_cursor);
  drop(v36_7);
  (v36_23).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let v55_8: Path = concat_path(&(*p2),&(*p3));
  let mut v55_15 = Space::new();
  let mut v55_15_cursor = (*s0).read_zipper();
  for v55_15_byte in v55_15_cursor.child_mask().iter() {
    v55_15_cursor.descend_to_byte(v55_15_byte);
    {
    let v55_15_tail = v55_15_cursor.fork_read_zipper();
    let v55_15_head = Path::from_slice(&[v55_15_byte]);
    let v56_2: Space = singleton(&(v55_15_head));
    let v56_3: Space = intersect(&(*CONSTANT_7),&(v56_2));
    let v56_4: Space = if has_head(&(v56_3)) { singleton(&[]) } else { Space::new() };
    drop(v56_3);
    let v56_5: Space = subtract(&(*CONSTANT_0),&(v56_4));
    drop(v56_4);
    let v56_8: Space = if (v56_5).is_empty() { Space::new() } else {
      let v57_6: Path = concat_path(&(*p0),&(v55_15_head));
      let v57_7: Space = routine_5(c, &(v57_6), &(*p1), &(*p2), &(*p3), &(v55_15_tail).make_space());
      compose(&(v56_5),&(v57_7))
    };
    drop(v56_5);
    let v56_9: Space = intersect(&(*CONSTANT_7),&(v56_2));
    drop(v56_2);
    let v56_10: Space = if has_head(&(v56_9)) { singleton(&[]) } else { Space::new() };
    drop(v56_9);
    let v56_16: Space = if (v56_10).is_empty() { Space::new() } else {
      let v58_6: Path = concat_path(&(*p0),&(v55_15_head));
      let v58_11: Path = concat_path(&(v55_8),&(v58_6));
      drop(v58_6);
      let v58_12: Space = singleton(&(v58_11));
      drop(v58_11);
      let v58_13: Space = routine_7(c, &(*p1), &(v58_12));
      drop(v58_12);
      let mut v58_14 = Space::new();
      let mut v58_14_cursor = (v58_13).read_zipper();
      for v58_14_byte in v58_14_cursor.child_mask().iter() {
        v58_14_cursor.descend_to_byte(v58_14_byte);
        {
        let v58_14_tail = v58_14_cursor.fork_read_zipper();
        let v58_14_head = Path::from_slice(&[v58_14_byte]);
        let v59_2: Space = singleton(&(v58_14_head));
        let v59_3: Space = intersect(&(*CONSTANT_7),&(v59_2));
        let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
        drop(v59_3);
        let v59_5: Space = subtract(&(*CONSTANT_0),&(v59_4));
        drop(v59_4);
        let v59_7: Space = if (v59_5).is_empty() { Space::new() } else {
          let v60_6: Space = routine_8(c, &(v58_14_head), &(*p1), &(v58_14_tail).make_space());
          compose(&(v59_5),&(v60_6))
        };
        drop(v59_5);
        let v59_8: Space = intersect(&(*CONSTANT_7),&(v59_2));
        drop(v59_2);
        let v59_9: Space = if has_head(&(v59_8)) { singleton(&[]) } else { Space::new() };
        drop(v59_8);
        let v59_11: Space = if (v59_9).is_empty() { Space::new() } else {
          let v61_10: Space = routine_9(c, &(v58_14_head), &(*p1), &(v58_14_tail).make_space());
          compose(&(v59_9),&(v61_10))
        };
        drop(v59_9);
        let v59_12: Space = unite(&(v59_7),&(v59_11));
        v58_14.join_into((v59_12).clone());
        }
        v58_14_cursor.ascend(1);
      }
      drop(v58_14_cursor);
      let mut v58_15 = Space::new();
      let mut v58_15_cursor = (v58_14).read_zipper();
      for v58_15_byte in v58_15_cursor.child_mask().iter() {
        v58_15_cursor.descend_to_byte(v58_15_byte);
        {
        let v58_15_tail = v58_15_cursor.fork_read_zipper();
        let v58_15_head = Path::from_slice(&[v58_15_byte]);
        let v62_2: Space = singleton(&(v58_15_head));
        let v62_3: Space = intersect(&(*CONSTANT_7),&(v62_2));
        let v62_4: Space = if has_head(&(v62_3)) { singleton(&[]) } else { Space::new() };
        drop(v62_3);
        let v62_5: Space = subtract(&(*CONSTANT_0),&(v62_4));
        drop(v62_4);
        let v62_7: Space = if (v62_5).is_empty() { Space::new() } else {
          let v63_6: Space = routine_10(c, &(v58_15_head), &(*p1), &(v58_15_tail).make_space());
          compose(&(v62_5),&(v63_6))
        };
        drop(v62_5);
        let v62_8: Space = intersect(&(*CONSTANT_7),&(v62_2));
        drop(v62_2);
        let v62_9: Space = if has_head(&(v62_8)) { singleton(&[]) } else { Space::new() };
        drop(v62_8);
        let v62_11: Space = if (v62_9).is_empty() { Space::new() } else {
          let v64_10: Space = routine_11(c, &(v58_15_head), &(*p1), &(v58_15_tail).make_space());
          compose(&(v62_9),&(v64_10))
        };
        drop(v62_9);
        let v62_12: Space = unite(&(v62_7),&(v62_11));
        v58_15.join_into((v62_12).clone());
        }
        v58_15_cursor.ascend(1);
      }
      drop(v58_15_cursor);
      compose(&(v56_10),&(v58_15))
    };
    drop(v56_10);
    let v56_17: Space = unite(&(v56_8),&(v56_16));
    v55_15.join_into((v56_17).clone());
    }
    v55_15_cursor.ascend(1);
  }
  drop(v55_15_cursor);
  drop(v55_8);
  (v55_15).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let (v65_103,v65_11,v65_22,v65_28,v65_36,v65_37,v65_43,v65_51,v65_52,v65_58,v65_66,v65_67,v65_82,) = native_block_0(c, p0, p1, p2, p3);
  (v65_103).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let (v120_11,v120_28,v120_3,v120_37,v120_54,v120_55,v120_64,v120_81,) = native_block_1(c, p0, s0);
  let v120_82: Space = unite(&(v120_55),&(v120_81));
  let v120_84: Space = intersect(&(*CONSTANT_11),&(v120_3));
  drop(v120_3);
  let mut v120_91 = Space::new();
  let mut v120_91_cursor = (v120_84).read_zipper();
  for v120_91_byte in v120_91_cursor.child_mask().iter() {
    v120_91_cursor.descend_to_byte(v120_91_byte);
    {
    let v120_91_tail = v120_91_cursor.fork_read_zipper();
    let v120_91_head = Path::from_slice(&[v120_91_byte]);
    let v181_2: Space = singleton(&(v120_91_head));
    let v181_3: Space = intersect(&(*CONSTANT_7),&(v181_2));
    let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
    drop(v181_3);
    let v181_5: Space = subtract(&(*CONSTANT_0),&(v181_4));
    drop(v181_4);
    let v181_7: Space = if (v181_5).is_empty() { Space::new() } else {
      let mut v182_6 = Space::new();
      let mut v182_6_cursor = (v120_91_tail).read_zipper();
      for v182_6_byte in v182_6_cursor.child_mask().iter() {
        v182_6_cursor.descend_to_byte(v182_6_byte);
        {
        let v182_6_tail = v182_6_cursor.fork_read_zipper();
        let v182_6_head = Path::from_slice(&[v182_6_byte]);
        let v183_2: Space = singleton(&(v182_6_head));
        let v183_3: Space = intersect(&(*CONSTANT_7),&(v183_2));
        let v183_4: Space = if has_head(&(v183_3)) { singleton(&[]) } else { Space::new() };
        drop(v183_3);
        let v183_5: Space = subtract(&(*CONSTANT_0),&(v183_4));
        drop(v183_4);
        let v183_8: Space = if (v183_5).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v120_91_head),&(v182_6_head));
          let v184_7: Space = routine_24(c, &(v184_6), &(v182_6_tail).make_space());
          drop(v184_6);
          compose(&(v183_5),&(v184_7))
        };
        drop(v183_5);
        let v183_9: Space = intersect(&(*CONSTANT_7),&(v183_2));
        drop(v183_2);
        let v183_10: Space = if has_head(&(v183_9)) { singleton(&[]) } else { Space::new() };
        drop(v183_9);
        let v183_11: Space = compose(&(v183_10),&(v182_6_tail));
        drop(v183_10);
        let v183_12: Space = unite(&(v183_8),&(v183_11));
        drop(v183_11);
        v182_6.join_into((v183_12).clone());
        }
        v182_6_cursor.ascend(1);
      }
      drop(v182_6_cursor);
      compose(&(v181_5),&(v182_6))
    };
    drop(v181_5);
    let v181_8: Space = intersect(&(*CONSTANT_7),&(v181_2));
    drop(v181_2);
    let v181_9: Space = if has_head(&(v181_8)) { singleton(&[]) } else { Space::new() };
    drop(v181_8);
    let v181_10: Space = compose(&(v181_9),&(v120_91_tail));
    drop(v181_9);
    let v181_11: Space = unite(&(v181_7),&(v181_10));
    drop(v181_10);
    v120_91.join_into((v181_11).clone());
    }
    v120_91_cursor.ascend(1);
  }
  drop(v120_91_cursor);
  drop(v120_84);
  let v120_108: Space = if (v120_91).is_empty() { Space::new() } else {
    let mut v185_107 = Space::new();
    let mut v185_107_cursor = (*s0).read_zipper();
    for v185_107_byte in v185_107_cursor.child_mask().iter() {
      v185_107_cursor.descend_to_byte(v185_107_byte);
      {
      let v185_107_tail = v185_107_cursor.fork_read_zipper();
      let v185_107_head = Path::from_slice(&[v185_107_byte]);
      let v186_2: Space = singleton(&(v185_107_head));
      let v186_3: Space = intersect(&(*CONSTANT_7),&(v186_2));
      let v186_4: Space = if has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
      drop(v186_3);
      let v186_5: Space = subtract(&(*CONSTANT_0),&(v186_4));
      drop(v186_4);
      let v186_7: Space = if (v186_5).is_empty() { Space::new() } else {
        let mut v187_6 = Space::new();
        let mut v187_6_cursor = (v185_107_tail).read_zipper();
        for v187_6_byte in v187_6_cursor.child_mask().iter() {
          v187_6_cursor.descend_to_byte(v187_6_byte);
          {
          let v187_6_tail = v187_6_cursor.fork_read_zipper();
          let v187_6_head = Path::from_slice(&[v187_6_byte]);
          let v188_2: Space = singleton(&(v187_6_head));
          let v188_3: Space = intersect(&(*CONSTANT_7),&(v188_2));
          let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
          drop(v188_3);
          let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
          drop(v188_4);
          let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
            let v189_6: Path = concat_path(&(v185_107_head),&(v187_6_head));
            let v189_7: Space = routine_25(c, &(v189_6), &(v187_6_tail).make_space());
            compose(&(v188_5),&(v189_7))
          };
          drop(v188_5);
          let v188_9: Space = intersect(&(*CONSTANT_7),&(v188_2));
          drop(v188_2);
          let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
          drop(v188_9);
          let v188_12: Space = if (v188_10).is_empty() { Space::new() } else {
            let v190_6: Path = concat_path(&(v185_107_head),&(v187_6_head));
            let mut v190_11 = Space::new();
            let mut v190_11_cursor = (v187_6_tail).read_zipper();
            for v190_11_byte in v190_11_cursor.child_mask().iter() {
              v190_11_cursor.descend_to_byte(v190_11_byte);
              {
              let v190_11_tail = v190_11_cursor.fork_read_zipper();
              let v190_11_head = Path::from_slice(&[v190_11_byte]);
              let v191_2: Space = singleton(&(v190_11_head));
              let v191_3: Space = intersect(&(*CONSTANT_7),&(v191_2));
              let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
              drop(v191_3);
              let v191_5: Space = subtract(&(*CONSTANT_0),&(v191_4));
              drop(v191_4);
              let v191_7: Space = if (v191_5).is_empty() { Space::new() } else {
                let v192_6: Space = routine_26(c, &(v190_11_head), &(v190_6), &(v190_11_tail).make_space());
                compose(&(v191_5),&(v192_6))
              };
              drop(v191_5);
              let v191_8: Space = intersect(&(*CONSTANT_7),&(v191_2));
              drop(v191_2);
              let v191_9: Space = if has_head(&(v191_8)) { singleton(&[]) } else { Space::new() };
              drop(v191_8);
              let v191_11: Space = if (v191_9).is_empty() { Space::new() } else {
                let v193_10: Space = routine_27(c, &(v190_11_head), &(v190_6), &(v190_11_tail).make_space());
                compose(&(v191_9),&(v193_10))
              };
              drop(v191_9);
              let v191_12: Space = unite(&(v191_7),&(v191_11));
              v190_11.join_into((v191_12).clone());
              }
              v190_11_cursor.ascend(1);
            }
            drop(v190_11_cursor);
            drop(v190_6);
            compose(&(v188_10),&(v190_11))
          };
          drop(v188_10);
          let v188_13: Space = unite(&(v188_8),&(v188_12));
          v187_6.join_into((v188_13).clone());
          }
          v187_6_cursor.ascend(1);
        }
        drop(v187_6_cursor);
        compose(&(v186_5),&(v187_6))
      };
      drop(v186_5);
      let v186_8: Space = intersect(&(*CONSTANT_7),&(v186_2));
      drop(v186_2);
      let v186_9: Space = if has_head(&(v186_8)) { singleton(&[]) } else { Space::new() };
      drop(v186_8);
      let v186_11: Space = if (v186_9).is_empty() { Space::new() } else {
        let mut v194_10 = Space::new();
        let mut v194_10_cursor = (v185_107_tail).read_zipper();
        for v194_10_byte in v194_10_cursor.child_mask().iter() {
          v194_10_cursor.descend_to_byte(v194_10_byte);
          {
          let v194_10_tail = v194_10_cursor.fork_read_zipper();
          let v194_10_head = Path::from_slice(&[v194_10_byte]);
          let v195_2: Space = singleton(&(v194_10_head));
          let v195_3: Space = intersect(&(*CONSTANT_7),&(v195_2));
          let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
          drop(v195_3);
          let v195_5: Space = subtract(&(*CONSTANT_0),&(v195_4));
          drop(v195_4);
          let v195_7: Space = if (v195_5).is_empty() { Space::new() } else {
            let v196_6: Space = routine_26(c, &(v194_10_head), &(v185_107_head), &(v194_10_tail).make_space());
            compose(&(v195_5),&(v196_6))
          };
          drop(v195_5);
          let v195_8: Space = intersect(&(*CONSTANT_7),&(v195_2));
          drop(v195_2);
          let v195_9: Space = if has_head(&(v195_8)) { singleton(&[]) } else { Space::new() };
          drop(v195_8);
          let v195_11: Space = if (v195_9).is_empty() { Space::new() } else {
            let mut v197_10 = Space::new();
            let mut v197_10_cursor = (v194_10_tail).read_zipper();
            for v197_10_byte in v197_10_cursor.child_mask().iter() {
              v197_10_cursor.descend_to_byte(v197_10_byte);
              {
              let v197_10_tail = v197_10_cursor.fork_read_zipper();
              let v197_10_head = Path::from_slice(&[v197_10_byte]);
              let v198_2: Space = singleton(&(v197_10_head));
              let v198_3: Space = intersect(&(*CONSTANT_7),&(v198_2));
              let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
              drop(v198_3);
              let v198_5: Space = subtract(&(*CONSTANT_0),&(v198_4));
              drop(v198_4);
              let v198_7: Space = if (v198_5).is_empty() { Space::new() } else {
                let v199_6: Space = routine_38(c, &(v197_10_head), &(v185_107_head), &(v194_10_head), &(v197_10_tail).make_space());
                compose(&(v198_5),&(v199_6))
              };
              drop(v198_5);
              let v198_8: Space = intersect(&(*CONSTANT_7),&(v198_2));
              drop(v198_2);
              let v198_9: Space = if has_head(&(v198_8)) { singleton(&[]) } else { Space::new() };
              drop(v198_8);
              let v198_11: Space = if (v198_9).is_empty() { Space::new() } else {
                let v200_10: Space = routine_39(c, &(v197_10_head), &(v185_107_head), &(v194_10_head), &(v197_10_tail).make_space());
                compose(&(v198_9),&(v200_10))
              };
              drop(v198_9);
              let v198_12: Space = unite(&(v198_7),&(v198_11));
              v197_10.join_into((v198_12).clone());
              }
              v197_10_cursor.ascend(1);
            }
            drop(v197_10_cursor);
            compose(&(v195_9),&(v197_10))
          };
          drop(v195_9);
          let v195_12: Space = unite(&(v195_7),&(v195_11));
          v194_10.join_into((v195_12).clone());
          }
          v194_10_cursor.ascend(1);
        }
        drop(v194_10_cursor);
        compose(&(v186_9),&(v194_10))
      };
      drop(v186_9);
      let v186_12: Space = unite(&(v186_7),&(v186_11));
      v185_107.join_into((v186_12).clone());
      }
      v185_107_cursor.ascend(1);
    }
    drop(v185_107_cursor);
    compose(&(v120_91),&(v185_107))
  };
  let v120_109: Space = unite(&(v120_82),&(v120_108));
  (v120_109).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v201_14 = Space::new();
  let mut v201_14_cursor = (*s0).read_zipper();
  for v201_14_byte in v201_14_cursor.child_mask().iter() {
    v201_14_cursor.descend_to_byte(v201_14_byte);
    {
    let v201_14_tail = v201_14_cursor.fork_read_zipper();
    let v201_14_head = Path::from_slice(&[v201_14_byte]);
    let v202_2: Space = singleton(&(v201_14_head));
    let v202_3: Space = intersect(&(*CONSTANT_7),&(v202_2));
    let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
    drop(v202_3);
    let v202_5: Space = subtract(&(*CONSTANT_0),&(v202_4));
    drop(v202_4);
    let v202_8: Space = if (v202_5).is_empty() { Space::new() } else {
      let v203_6: Path = concat_path(&(*p0),&(v201_14_head));
      let v203_7: Space = routine_8(c, &(v203_6), &(*p1), &(v201_14_tail).make_space());
      compose(&(v202_5),&(v203_7))
    };
    drop(v202_5);
    let v202_9: Space = intersect(&(*CONSTANT_7),&(v202_2));
    drop(v202_2);
    let v202_10: Space = if has_head(&(v202_9)) { singleton(&[]) } else { Space::new() };
    drop(v202_9);
    let v202_17: Space = if (v202_10).is_empty() { Space::new() } else {
      let v204_6: Path = concat_path(&(*p0),&(v201_14_head));
      let v204_14: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v205_11: Space = routine_28(c, &(*CONSTANT_12), &(*CONSTANT_13));
        let v205_12: Space = routine_28(c, &(*CONSTANT_14), &(*CONSTANT_15));
        let v205_13: Space = unite(&(v205_11),&(v205_12));
        compose(&(*CONSTANT_0),&(v205_13))
      };
      let v204_15: Space = unwrap(&(v204_14),&(*p1));
      let mut v204_16 = Space::new();
      let mut v204_16_cursor = (v204_15).read_zipper();
      for v204_16_byte in v204_16_cursor.child_mask().iter() {
        v204_16_cursor.descend_to_byte(v204_16_byte);
        {
        let v204_16_tail = v204_16_cursor.fork_read_zipper();
        let v204_16_head = Path::from_slice(&[v204_16_byte]);
        let v206_2: Space = singleton(&(v204_16_head));
        let v206_3: Space = intersect(&(*CONSTANT_7),&(v206_2));
        let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
        drop(v206_3);
        let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
        drop(v206_4);
        let v206_7: Space = if (v206_5).is_empty() { Space::new() } else {
          let v207_6: Space = routine_29(c, &(v204_16_head), &(v204_6), &(v204_16_tail).make_space(), &(v201_14_tail).make_space());
          compose(&(v206_5),&(v207_6))
        };
        drop(v206_5);
        let v206_8: Space = intersect(&(*CONSTANT_7),&(v206_2));
        drop(v206_2);
        let v206_9: Space = if has_head(&(v206_8)) { singleton(&[]) } else { Space::new() };
        drop(v206_8);
        let v206_14: Space = if (v206_9).is_empty() { Space::new() } else {
          let v208_10: Space = unwrap(&(v204_16_tail),&(*p0));
          let v208_11: Space = unwrap(&(v208_10),&(v201_14_head));
          drop(v208_10);
          let v208_12: Space = wrap(&(v208_11),&(v204_16_head));
          drop(v208_11);
          let v208_13: Space = compose(&(v208_12),&(v201_14_tail));
          drop(v208_12);
          compose(&(v206_9),&(v208_13))
        };
        drop(v206_9);
        let v206_15: Space = unite(&(v206_7),&(v206_14));
        drop(v206_14);
        v204_16.join_into((v206_15).clone());
        }
        v204_16_cursor.ascend(1);
      }
      drop(v204_16_cursor);
      drop(v204_6);
      compose(&(v202_10),&(v204_16))
    };
    drop(v202_10);
    let v202_18: Space = unite(&(v202_8),&(v202_17));
    v201_14.join_into((v202_18).clone());
    }
    v201_14_cursor.ascend(1);
  }
  drop(v201_14_cursor);
  (v201_14).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v209_21: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v210_20: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v211_7: Space = routine_28(c, &(*CONSTANT_1), &(*CONSTANT_20));
      let v211_10: Space = routine_28(c, &(*CONSTANT_3), &(*CONSTANT_21));
      let v211_11: Space = unite(&(v211_7),&(v211_10));
      let v211_14: Space = routine_28(c, &(*CONSTANT_4), &(*CONSTANT_22));
      let v211_15: Space = unite(&(v211_11),&(v211_14));
      let v211_18: Space = routine_28(c, &(*CONSTANT_6), &(*CONSTANT_23));
      let v211_19: Space = unite(&(v211_15),&(v211_18));
      compose(&(*CONSTANT_0),&(v211_19))
    };
    compose(&(*CONSTANT_0),&(v210_20))
  };
  let v209_22: Space = unwrap(&(v209_21),&(*p1));
  let mut v209_29 = Space::new();
  let mut v209_29_cursor = (v209_22).read_zipper();
  for v209_29_byte in v209_29_cursor.child_mask().iter() {
    v209_29_cursor.descend_to_byte(v209_29_byte);
    {
    let v209_29_tail = v209_29_cursor.fork_read_zipper();
    let v209_29_head = Path::from_slice(&[v209_29_byte]);
    let v212_2: Space = singleton(&(v209_29_head));
    let v212_3: Space = intersect(&(*CONSTANT_7),&(v212_2));
    let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
    drop(v212_3);
    let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
    drop(v212_4);
    let v212_7: Space = if (v212_5).is_empty() { Space::new() } else {
      let mut v213_6 = Space::new();
      let mut v213_6_cursor = (v209_29_tail).read_zipper();
      for v213_6_byte in v213_6_cursor.child_mask().iter() {
        v213_6_cursor.descend_to_byte(v213_6_byte);
        {
        let v213_6_tail = v213_6_cursor.fork_read_zipper();
        let v213_6_head = Path::from_slice(&[v213_6_byte]);
        let v214_2: Space = singleton(&(v213_6_head));
        let v214_3: Space = intersect(&(*CONSTANT_7),&(v214_2));
        let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
        drop(v214_3);
        let v214_5: Space = subtract(&(*CONSTANT_0),&(v214_4));
        drop(v214_4);
        let v214_8: Space = if (v214_5).is_empty() { Space::new() } else {
          let v215_6: Path = concat_path(&(v209_29_head),&(v213_6_head));
          let v215_7: Space = routine_29(c, &(v215_6), &(*p0), &(v213_6_tail).make_space(), &(*s0));
          compose(&(v214_5),&(v215_7))
        };
        drop(v214_5);
        let v214_9: Space = intersect(&(*CONSTANT_7),&(v214_2));
        drop(v214_2);
        let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
        drop(v214_9);
        let v214_14: Space = if (v214_10).is_empty() { Space::new() } else {
          let v216_6: Path = concat_path(&(v209_29_head),&(v213_6_head));
          let v216_11: Space = unwrap(&(v213_6_tail),&(*p0));
          let v216_12: Space = wrap(&(v216_11),&(v216_6));
          drop(v216_6);
          drop(v216_11);
          let v216_13: Space = compose(&(v216_12),&(*s0));
          drop(v216_12);
          compose(&(v214_10),&(v216_13))
        };
        drop(v214_10);
        let v214_15: Space = unite(&(v214_8),&(v214_14));
        drop(v214_14);
        v213_6.join_into((v214_15).clone());
        }
        v213_6_cursor.ascend(1);
      }
      drop(v213_6_cursor);
      compose(&(v212_5),&(v213_6))
    };
    drop(v212_5);
    let v212_8: Space = intersect(&(*CONSTANT_7),&(v212_2));
    drop(v212_2);
    let v212_9: Space = if has_head(&(v212_8)) { singleton(&[]) } else { Space::new() };
    drop(v212_8);
    let v212_13: Space = if (v212_9).is_empty() { Space::new() } else {
      let v217_10: Space = unwrap(&(v209_29_tail),&(*p0));
      let v217_11: Space = wrap(&(v217_10),&(v209_29_head));
      drop(v217_10);
      let v217_12: Space = compose(&(v217_11),&(*s0));
      drop(v217_11);
      compose(&(v212_9),&(v217_12))
    };
    drop(v212_9);
    let v212_14: Space = unite(&(v212_7),&(v212_13));
    drop(v212_13);
    v209_29.join_into((v212_14).clone());
    }
    v209_29_cursor.ascend(1);
  }
  drop(v209_29_cursor);
  (v209_29).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v218_22 = Space::new();
  let mut v218_22_cursor = (*s0).read_zipper();
  for v218_22_byte in v218_22_cursor.child_mask().iter() {
    v218_22_cursor.descend_to_byte(v218_22_byte);
    {
    let v218_22_tail = v218_22_cursor.fork_read_zipper();
    let v218_22_head = Path::from_slice(&[v218_22_byte]);
    let v219_2: Space = singleton(&(v218_22_head));
    let v219_3: Space = intersect(&(*CONSTANT_7),&(v219_2));
    let v219_4: Space = if has_head(&(v219_3)) { singleton(&[]) } else { Space::new() };
    drop(v219_3);
    let v219_5: Space = subtract(&(*CONSTANT_0),&(v219_4));
    drop(v219_4);
    let v219_8: Space = if (v219_5).is_empty() { Space::new() } else {
      let v220_6: Path = concat_path(&(*p0),&(v218_22_head));
      let v220_7: Space = routine_10(c, &(v220_6), &(*p1), &(v218_22_tail).make_space());
      drop(v220_6);
      compose(&(v219_5),&(v220_7))
    };
    drop(v219_5);
    let v219_9: Space = intersect(&(*CONSTANT_7),&(v219_2));
    drop(v219_2);
    let v219_10: Space = if has_head(&(v219_9)) { singleton(&[]) } else { Space::new() };
    drop(v219_9);
    let v219_31: Space = if (v219_10).is_empty() { Space::new() } else {
      let v221_14: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v222_11: Space = routine_30(c, &(*CONSTANT_12), &(*CONSTANT_13));
        let v222_12: Space = routine_30(c, &(*CONSTANT_14), &(*CONSTANT_15));
        let v222_13: Space = unite(&(v222_11),&(v222_12));
        compose(&(*CONSTANT_0),&(v222_13))
      };
      let v221_15: Space = unwrap(&(v221_14),&(*p1));
      let v221_16: Space = unwrap(&(v221_15),&(*p0));
      let v221_17: Space = unwrap(&(v221_16),&(v218_22_head));
      let v221_18: Space = unwrap(&(v221_17),&(*p1));
      let v221_19: Space = unwrap(&(v218_22_tail),&(*CONSTANT_16));
      let v221_20: Space = unwrap(&(v218_22_tail),&(*CONSTANT_17));
      let v221_21: Space = compose(&(v221_19),&(v221_20));
      let v221_22: Space = unwrap(&(v218_22_tail),&(*CONSTANT_18));
      let v221_23: Space = compose(&(v221_21),&(v221_22));
      let v221_24: Space = unwrap(&(v218_22_tail),&(*CONSTANT_19));
      let v221_25: Space = compose(&(v221_21),&(v221_24));
      drop(v221_21);
      let v221_26: Space = compose(&(v221_20),&(v221_24));
      drop(v221_20);
      let v221_27: Space = compose(&(v221_26),&(v221_22));
      drop(v221_26);
      let v221_28: Space = compose(&(v221_19),&(v221_24));
      drop(v221_19);
      drop(v221_24);
      let v221_29: Space = compose(&(v221_28),&(v221_22));
      drop(v221_22);
      drop(v221_28);
      let mut v221_30 = Space::new();
      let mut v221_30_cursor = (v221_18).read_zipper();
      for v221_30_byte in v221_30_cursor.child_mask().iter() {
        v221_30_cursor.descend_to_byte(v221_30_byte);
        {
        let v221_30_tail = v221_30_cursor.fork_read_zipper();
        let v221_30_head = Path::from_slice(&[v221_30_byte]);
        let v223_2: Space = singleton(&(v221_30_head));
        let v223_3: Space = intersect(&(*CONSTANT_7),&(v223_2));
        let v223_4: Space = if has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = subtract(&(*CONSTANT_0),&(v223_4));
        drop(v223_4);
        let v223_7: Space = if (v223_5).is_empty() { Space::new() } else {
          let v224_6: Space = routine_31(c, &(v221_30_head), &(v221_30_tail).make_space(), &(v218_22_tail).make_space());
          compose(&(v223_5),&(v224_6))
        };
        drop(v223_5);
        let v223_8: Space = intersect(&(*CONSTANT_7),&(v223_2));
        let v223_9: Space = if has_head(&(v223_8)) { singleton(&[]) } else { Space::new() };
        drop(v223_8);
        let v223_10: Space = intersect(&(*CONSTANT_8),&(v223_2));
        let v223_11: Space = compose(&(v223_10),&(v221_23));
        drop(v223_10);
        let v223_12: Space = intersect(&(*CONSTANT_9),&(v223_2));
        let v223_13: Space = compose(&(v223_12),&(v221_25));
        drop(v223_12);
        let v223_14: Space = unite(&(v223_11),&(v223_13));
        drop(v223_11);
        drop(v223_13);
        let v223_15: Space = intersect(&(*CONSTANT_10),&(v223_2));
        let v223_16: Space = compose(&(v223_15),&(v221_27));
        drop(v223_15);
        let v223_17: Space = unite(&(v223_14),&(v223_16));
        drop(v223_14);
        drop(v223_16);
        let v223_18: Space = intersect(&(*CONSTANT_11),&(v223_2));
        drop(v223_2);
        let v223_19: Space = compose(&(v223_18),&(v221_29));
        drop(v223_18);
        let v223_20: Space = unite(&(v223_17),&(v223_19));
        drop(v223_17);
        drop(v223_19);
        let v223_21: Space = compose(&(v223_9),&(v223_20));
        drop(v223_9);
        drop(v223_20);
        let v223_22: Space = unite(&(v223_7),&(v223_21));
        drop(v223_21);
        v221_30.join_into((v223_22).clone());
        }
        v221_30_cursor.ascend(1);
      }
      drop(v221_30_cursor);
      drop(v221_23);
      drop(v221_25);
      drop(v221_27);
      drop(v221_29);
      compose(&(v219_10),&(v221_30))
    };
    drop(v219_10);
    let v219_32: Space = unite(&(v219_8),&(v219_31));
    v218_22.join_into((v219_32).clone());
    }
    v218_22_cursor.ascend(1);
  }
  drop(v218_22_cursor);
  (v218_22).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v225_21: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v226_20: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v227_7: Space = routine_30(c, &(*CONSTANT_1), &(*CONSTANT_20));
      let v227_10: Space = routine_30(c, &(*CONSTANT_3), &(*CONSTANT_21));
      let v227_11: Space = unite(&(v227_7),&(v227_10));
      let v227_14: Space = routine_30(c, &(*CONSTANT_4), &(*CONSTANT_22));
      let v227_15: Space = unite(&(v227_11),&(v227_14));
      let v227_18: Space = routine_30(c, &(*CONSTANT_6), &(*CONSTANT_23));
      let v227_19: Space = unite(&(v227_15),&(v227_18));
      compose(&(*CONSTANT_0),&(v227_19))
    };
    compose(&(*CONSTANT_0),&(v226_20))
  };
  let v225_22: Space = unwrap(&(v225_21),&(*p1));
  let v225_23: Space = unwrap(&(v225_22),&(*p0));
  let v225_24: Space = unwrap(&(v225_23),&(*p1));
  let v225_30: Space = unwrap(&(*s0),&(*CONSTANT_16));
  let v225_33: Space = if (v225_30).is_empty() { Space::new() } else {
    let v228_32: Space = unwrap(&(*s0),&(*CONSTANT_17));
    compose(&(v225_30),&(v228_32))
  };
  let v225_36: Space = if (v225_33).is_empty() { Space::new() } else {
    let v229_35: Space = unwrap(&(*s0),&(*CONSTANT_18));
    compose(&(v225_33),&(v229_35))
  };
  let v225_40: Space = if (v225_33).is_empty() { Space::new() } else {
    let v230_39: Space = unwrap(&(*s0),&(*CONSTANT_19));
    compose(&(v225_33),&(v230_39))
  };
  drop(v225_33);
  let v231_32: Space = unwrap(&(*s0),&(*CONSTANT_17));
  let v225_42: Space = if (v231_32).is_empty() { Space::new() } else {
    let v232_39: Space = unwrap(&(*s0),&(*CONSTANT_19));
    compose(&(v231_32),&(v232_39))
  };
  let v225_43: Space = if (v225_42).is_empty() { Space::new() } else {
    let v233_35: Space = unwrap(&(*s0),&(*CONSTANT_18));
    compose(&(v225_42),&(v233_35))
  };
  drop(v225_42);
  let v225_45: Space = if (v225_30).is_empty() { Space::new() } else {
    let v234_39: Space = unwrap(&(*s0),&(*CONSTANT_19));
    compose(&(v225_30),&(v234_39))
  };
  drop(v225_30);
  let v225_46: Space = if (v225_45).is_empty() { Space::new() } else {
    let v235_35: Space = unwrap(&(*s0),&(*CONSTANT_18));
    compose(&(v225_45),&(v235_35))
  };
  drop(v225_45);
  let mut v225_54 = Space::new();
  let mut v225_54_cursor = (v225_24).read_zipper();
  for v225_54_byte in v225_54_cursor.child_mask().iter() {
    v225_54_cursor.descend_to_byte(v225_54_byte);
    {
    let v225_54_tail = v225_54_cursor.fork_read_zipper();
    let v225_54_head = Path::from_slice(&[v225_54_byte]);
    let v236_2: Space = singleton(&(v225_54_head));
    let v236_3: Space = intersect(&(*CONSTANT_7),&(v236_2));
    let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
    drop(v236_3);
    let v236_5: Space = subtract(&(*CONSTANT_0),&(v236_4));
    drop(v236_4);
    let v236_7: Space = if (v236_5).is_empty() { Space::new() } else {
      let mut v237_6 = Space::new();
      let mut v237_6_cursor = (v225_54_tail).read_zipper();
      for v237_6_byte in v237_6_cursor.child_mask().iter() {
        v237_6_cursor.descend_to_byte(v237_6_byte);
        {
        let v237_6_tail = v237_6_cursor.fork_read_zipper();
        let v237_6_head = Path::from_slice(&[v237_6_byte]);
        let v238_2: Space = singleton(&(v237_6_head));
        let v238_3: Space = intersect(&(*CONSTANT_7),&(v238_2));
        let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
        drop(v238_3);
        let v238_5: Space = subtract(&(*CONSTANT_0),&(v238_4));
        drop(v238_4);
        let v238_8: Space = if (v238_5).is_empty() { Space::new() } else {
          let v239_6: Path = concat_path(&(v225_54_head),&(v237_6_head));
          let v239_7: Space = routine_31(c, &(v239_6), &(v237_6_tail).make_space(), &(*s0));
          compose(&(v238_5),&(v239_7))
        };
        drop(v238_5);
        let v238_9: Space = intersect(&(*CONSTANT_7),&(v238_2));
        drop(v238_2);
        let v238_10: Space = if has_head(&(v238_9)) { singleton(&[]) } else { Space::new() };
        drop(v238_9);
        let v238_23: Space = if (v238_10).is_empty() { Space::new() } else {
          let v240_6: Path = concat_path(&(v225_54_head),&(v237_6_head));
          let v240_11: Space = singleton(&(v240_6));
          drop(v240_6);
          let v240_12: Space = intersect(&(*CONSTANT_8),&(v240_11));
          let v240_13: Space = compose(&(v240_12),&(v225_36));
          drop(v240_12);
          let v240_14: Space = intersect(&(*CONSTANT_9),&(v240_11));
          let v240_15: Space = compose(&(v240_14),&(v225_40));
          drop(v240_14);
          let v240_16: Space = unite(&(v240_13),&(v240_15));
          drop(v240_13);
          drop(v240_15);
          let v240_17: Space = intersect(&(*CONSTANT_10),&(v240_11));
          let v240_18: Space = compose(&(v240_17),&(v225_43));
          drop(v240_17);
          let v240_19: Space = unite(&(v240_16),&(v240_18));
          drop(v240_16);
          drop(v240_18);
          let v240_20: Space = intersect(&(*CONSTANT_11),&(v240_11));
          drop(v240_11);
          let v240_21: Space = compose(&(v240_20),&(v225_46));
          drop(v240_20);
          let v240_22: Space = unite(&(v240_19),&(v240_21));
          drop(v240_19);
          drop(v240_21);
          compose(&(v238_10),&(v240_22))
        };
        drop(v238_10);
        let v238_24: Space = unite(&(v238_8),&(v238_23));
        drop(v238_23);
        v237_6.join_into((v238_24).clone());
        }
        v237_6_cursor.ascend(1);
      }
      drop(v237_6_cursor);
      compose(&(v236_5),&(v237_6))
    };
    drop(v236_5);
    let v236_8: Space = intersect(&(*CONSTANT_7),&(v236_2));
    let v236_9: Space = if has_head(&(v236_8)) { singleton(&[]) } else { Space::new() };
    drop(v236_8);
    let v236_21: Space = if (v236_9).is_empty() { Space::new() } else {
      let v241_10: Space = intersect(&(*CONSTANT_8),&(v236_2));
      let v241_11: Space = compose(&(v241_10),&(v225_36));
      drop(v241_10);
      let v241_12: Space = intersect(&(*CONSTANT_9),&(v236_2));
      let v241_13: Space = compose(&(v241_12),&(v225_40));
      drop(v241_12);
      let v241_14: Space = unite(&(v241_11),&(v241_13));
      drop(v241_11);
      drop(v241_13);
      let v241_15: Space = intersect(&(*CONSTANT_10),&(v236_2));
      let v241_16: Space = compose(&(v241_15),&(v225_43));
      drop(v241_15);
      let v241_17: Space = unite(&(v241_14),&(v241_16));
      drop(v241_14);
      drop(v241_16);
      let v241_18: Space = intersect(&(*CONSTANT_11),&(v236_2));
      let v241_19: Space = compose(&(v241_18),&(v225_46));
      drop(v241_18);
      let v241_20: Space = unite(&(v241_17),&(v241_19));
      drop(v241_17);
      drop(v241_19);
      compose(&(v236_9),&(v241_20))
    };
    drop(v236_9);
    let v236_22: Space = unite(&(v236_7),&(v236_21));
    drop(v236_21);
    v225_54.join_into((v236_22).clone());
    }
    v225_54_cursor.ascend(1);
  }
  drop(v225_54_cursor);
  drop(v225_36);
  drop(v225_40);
  drop(v225_43);
  drop(v225_46);
  (v225_54).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v242_5 = Space::new();
  let mut v242_5_cursor = (*s0).read_zipper();
  for v242_5_byte in v242_5_cursor.child_mask().iter() {
    v242_5_cursor.descend_to_byte(v242_5_byte);
    {
    let v242_5_tail = v242_5_cursor.fork_read_zipper();
    let v242_5_head = Path::from_slice(&[v242_5_byte]);
    let v243_2: Space = singleton(&(v242_5_head));
    let v243_3: Space = intersect(&(*CONSTANT_7),&(v243_2));
    let v243_4: Space = if has_head(&(v243_3)) { singleton(&[]) } else { Space::new() };
    drop(v243_3);
    let v243_5: Space = subtract(&(*CONSTANT_0),&(v243_4));
    drop(v243_4);
    let v243_8: Space = if (v243_5).is_empty() { Space::new() } else {
      let v244_6: Path = concat_path(&(*p0),&(v242_5_head));
      let v244_7: Space = routine_12(c, &(v244_6), &(v242_5_tail).make_space());
      drop(v244_6);
      compose(&(v243_5),&(v244_7))
    };
    drop(v243_5);
    let v243_9: Space = intersect(&(*CONSTANT_7),&(v243_2));
    drop(v243_2);
    let v243_10: Space = if has_head(&(v243_9)) { singleton(&[]) } else { Space::new() };
    drop(v243_9);
    let v243_11: Space = compose(&(v243_10),&(v242_5_tail));
    drop(v243_10);
    let v243_12: Space = unite(&(v243_8),&(v243_11));
    drop(v243_11);
    v242_5.join_into((v243_12).clone());
    }
    v242_5_cursor.ascend(1);
  }
  drop(v242_5_cursor);
  (v242_5).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v245_11 = Space::new();
  let mut v245_11_cursor = (*s0).read_zipper();
  for v245_11_byte in v245_11_cursor.child_mask().iter() {
    v245_11_cursor.descend_to_byte(v245_11_byte);
    {
    let v245_11_tail = v245_11_cursor.fork_read_zipper();
    let v245_11_head = Path::from_slice(&[v245_11_byte]);
    let v246_2: Space = singleton(&(v245_11_head));
    let v246_3: Space = intersect(&(*CONSTANT_7),&(v246_2));
    let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
    drop(v246_3);
    let v246_5: Space = subtract(&(*CONSTANT_0),&(v246_4));
    drop(v246_4);
    let v246_8: Space = if (v246_5).is_empty() { Space::new() } else {
      let v247_6: Path = concat_path(&(*p0),&(v245_11_head));
      let v247_7: Space = routine_13(c, &(v247_6), &(v245_11_tail).make_space());
      compose(&(v246_5),&(v247_7))
    };
    drop(v246_5);
    let v246_9: Space = intersect(&(*CONSTANT_7),&(v246_2));
    drop(v246_2);
    let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
    drop(v246_9);
    let v246_12: Space = if (v246_10).is_empty() { Space::new() } else {
      let v248_6: Path = concat_path(&(*p0),&(v245_11_head));
      let mut v248_11 = Space::new();
      let mut v248_11_cursor = (v245_11_tail).read_zipper();
      for v248_11_byte in v248_11_cursor.child_mask().iter() {
        v248_11_cursor.descend_to_byte(v248_11_byte);
        {
        let v248_11_tail = v248_11_cursor.fork_read_zipper();
        let v248_11_head = Path::from_slice(&[v248_11_byte]);
        let v249_2: Space = singleton(&(v248_11_head));
        let v249_3: Space = intersect(&(*CONSTANT_7),&(v249_2));
        let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
        drop(v249_3);
        let v249_5: Space = subtract(&(*CONSTANT_0),&(v249_4));
        drop(v249_4);
        let v249_7: Space = if (v249_5).is_empty() { Space::new() } else {
          let v250_6: Space = routine_14(c, &(v248_11_head), &(v248_6), &(v248_11_tail).make_space());
          compose(&(v249_5),&(v250_6))
        };
        drop(v249_5);
        let v249_8: Space = intersect(&(*CONSTANT_7),&(v249_2));
        drop(v249_2);
        let v249_9: Space = if has_head(&(v249_8)) { singleton(&[]) } else { Space::new() };
        drop(v249_8);
        let v249_11: Space = if (v249_9).is_empty() { Space::new() } else {
          let mut v251_10 = Space::new();
          let mut v251_10_cursor = (v248_11_tail).read_zipper();
          for v251_10_byte in v251_10_cursor.child_mask().iter() {
            v251_10_cursor.descend_to_byte(v251_10_byte);
            {
            let v251_10_tail = v251_10_cursor.fork_read_zipper();
            let v251_10_head = Path::from_slice(&[v251_10_byte]);
            let v252_2: Space = singleton(&(v251_10_head));
            let v252_3: Space = intersect(&(*CONSTANT_7),&(v252_2));
            let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
            drop(v252_3);
            let v252_5: Space = subtract(&(*CONSTANT_0),&(v252_4));
            drop(v252_4);
            let v252_7: Space = if (v252_5).is_empty() { Space::new() } else {
              let v253_6: Space = routine_32(c, &(v251_10_head), &(v248_6), &(v248_11_head), &(v251_10_tail).make_space());
              compose(&(v252_5),&(v253_6))
            };
            drop(v252_5);
            let v252_8: Space = intersect(&(*CONSTANT_7),&(v252_2));
            drop(v252_2);
            let v252_9: Space = if has_head(&(v252_8)) { singleton(&[]) } else { Space::new() };
            drop(v252_8);
            let v252_11: Space = if (v252_9).is_empty() { Space::new() } else {
              let v254_10: Space = routine_33(c, &(v251_10_head), &(v248_6), &(v248_11_head), &(v251_10_tail).make_space());
              compose(&(v252_9),&(v254_10))
            };
            drop(v252_9);
            let v252_12: Space = unite(&(v252_7),&(v252_11));
            v251_10.join_into((v252_12).clone());
            }
            v251_10_cursor.ascend(1);
          }
          drop(v251_10_cursor);
          compose(&(v249_9),&(v251_10))
        };
        drop(v249_9);
        let v249_12: Space = unite(&(v249_7),&(v249_11));
        v248_11.join_into((v249_12).clone());
        }
        v248_11_cursor.ascend(1);
      }
      drop(v248_11_cursor);
      drop(v248_6);
      compose(&(v246_10),&(v248_11))
    };
    drop(v246_10);
    let v246_13: Space = unite(&(v246_8),&(v246_12));
    v245_11.join_into((v246_13).clone());
    }
    v245_11_cursor.ascend(1);
  }
  drop(v245_11_cursor);
  (v245_11).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v255_13: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v255_14: Space = singleton(&(v255_13));
  drop(v255_13);
  let mut v255_15 = Space::new();
  let mut v255_15_cursor = (*s0).read_zipper();
  for v255_15_byte in v255_15_cursor.child_mask().iter() {
    v255_15_cursor.descend_to_byte(v255_15_byte);
    {
    let v255_15_tail = v255_15_cursor.fork_read_zipper();
    let v255_15_head = Path::from_slice(&[v255_15_byte]);
    let v256_2: Space = singleton(&(v255_15_head));
    let v256_3: Space = intersect(&(*CONSTANT_7),&(v256_2));
    let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
    drop(v256_3);
    let v256_5: Space = subtract(&(*CONSTANT_0),&(v256_4));
    drop(v256_4);
    let v256_8: Space = if (v256_5).is_empty() { Space::new() } else {
      let v257_6: Path = concat_path(&(*p0),&(v255_15_head));
      let v257_7: Space = routine_14(c, &(v257_6), &(*p1), &(v255_15_tail).make_space());
      compose(&(v256_5),&(v257_7))
    };
    drop(v256_5);
    let v256_9: Space = intersect(&(*CONSTANT_7),&(v256_2));
    drop(v256_2);
    let v256_10: Space = if has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
    drop(v256_9);
    let v256_14: Space = if (v256_10).is_empty() { Space::new() } else {
      let v258_6: Path = concat_path(&(*p0),&(v255_15_head));
      let v258_11: Path = concat_path(&(*CONSTANT_17),&(v258_6));
      let v258_12: Space = singleton(&(v258_11));
      drop(v258_11);
      let mut v258_13 = Space::new();
      let mut v258_13_cursor = (v255_15_tail).read_zipper();
      for v258_13_byte in v258_13_cursor.child_mask().iter() {
        v258_13_cursor.descend_to_byte(v258_13_byte);
        {
        let v258_13_tail = v258_13_cursor.fork_read_zipper();
        let v258_13_head = Path::from_slice(&[v258_13_byte]);
        let v259_2: Space = singleton(&(v258_13_head));
        let v259_3: Space = intersect(&(*CONSTANT_7),&(v259_2));
        let v259_4: Space = if has_head(&(v259_3)) { singleton(&[]) } else { Space::new() };
        drop(v259_3);
        let v259_5: Space = subtract(&(*CONSTANT_0),&(v259_4));
        drop(v259_4);
        let v259_7: Space = if (v259_5).is_empty() { Space::new() } else {
          let v260_6: Space = routine_32(c, &(v258_13_head), &(*p1), &(v258_6), &(v258_13_tail).make_space());
          compose(&(v259_5),&(v260_6))
        };
        drop(v259_5);
        let v259_8: Space = intersect(&(*CONSTANT_7),&(v259_2));
        drop(v259_2);
        let v259_9: Space = if has_head(&(v259_8)) { singleton(&[]) } else { Space::new() };
        drop(v259_8);
        let v259_15: Space = if (v259_9).is_empty() { Space::new() } else {
          let v261_10: Path = concat_path(&(*CONSTANT_18),&(v258_13_head));
          let v261_11: Space = singleton(&(v261_10));
          drop(v261_10);
          let v261_12: Space = unite(&(*CONSTANT_24),&(v261_11));
          drop(v261_11);
          let v261_13: Space = unite(&(v261_12),&(v255_14));
          drop(v261_12);
          let v261_14: Space = unite(&(v261_13),&(v258_12));
          drop(v261_13);
          compose(&(v259_9),&(v261_14))
        };
        drop(v259_9);
        let v259_16: Space = unite(&(v259_7),&(v259_15));
        drop(v259_15);
        v258_13.join_into((v259_16).clone());
        }
        v258_13_cursor.ascend(1);
      }
      drop(v258_13_cursor);
      drop(v258_6);
      drop(v258_12);
      compose(&(v256_10),&(v258_13))
    };
    drop(v256_10);
    let v256_15: Space = unite(&(v256_8),&(v256_14));
    v255_15.join_into((v256_15).clone());
    }
    v255_15_cursor.ascend(1);
  }
  drop(v255_15_cursor);
  drop(v255_14);
  (v255_15).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v262_9: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v262_10: Space = singleton(&(v262_9));
  drop(v262_9);
  let v262_12: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v262_13: Space = singleton(&(v262_12));
  drop(v262_12);
  let mut v262_18 = Space::new();
  let mut v262_18_cursor = (*s0).read_zipper();
  for v262_18_byte in v262_18_cursor.child_mask().iter() {
    v262_18_cursor.descend_to_byte(v262_18_byte);
    {
    let v262_18_tail = v262_18_cursor.fork_read_zipper();
    let v262_18_head = Path::from_slice(&[v262_18_byte]);
    let v263_2: Space = singleton(&(v262_18_head));
    let v263_3: Space = intersect(&(*CONSTANT_7),&(v263_2));
    let v263_4: Space = if has_head(&(v263_3)) { singleton(&[]) } else { Space::new() };
    drop(v263_3);
    let v263_5: Space = subtract(&(*CONSTANT_0),&(v263_4));
    drop(v263_4);
    let v263_7: Space = if (v263_5).is_empty() { Space::new() } else {
      let mut v264_6 = Space::new();
      let mut v264_6_cursor = (v262_18_tail).read_zipper();
      for v264_6_byte in v264_6_cursor.child_mask().iter() {
        v264_6_cursor.descend_to_byte(v264_6_byte);
        {
        let v264_6_tail = v264_6_cursor.fork_read_zipper();
        let v264_6_head = Path::from_slice(&[v264_6_byte]);
        let v265_2: Space = singleton(&(v264_6_head));
        let v265_3: Space = intersect(&(*CONSTANT_7),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_0),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (v265_5).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v262_18_head),&(v264_6_head));
          let v266_7: Space = routine_32(c, &(v266_6), &(*p1), &(*p0), &(v264_6_tail).make_space());
          compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = intersect(&(*CONSTANT_7),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_16: Space = if (v265_10).is_empty() { Space::new() } else {
          let v267_6: Path = concat_path(&(v262_18_head),&(v264_6_head));
          let v267_11: Path = concat_path(&(*CONSTANT_18),&(v267_6));
          drop(v267_6);
          let v267_12: Space = singleton(&(v267_11));
          drop(v267_11);
          let v267_13: Space = unite(&(*CONSTANT_24),&(v267_12));
          drop(v267_12);
          let v267_14: Space = unite(&(v267_13),&(v262_10));
          drop(v267_13);
          let v267_15: Space = unite(&(v267_14),&(v262_13));
          drop(v267_14);
          compose(&(v265_10),&(v267_15))
        };
        drop(v265_10);
        let v265_17: Space = unite(&(v265_8),&(v265_16));
        drop(v265_16);
        v264_6.join_into((v265_17).clone());
        }
        v264_6_cursor.ascend(1);
      }
      drop(v264_6_cursor);
      compose(&(v263_5),&(v264_6))
    };
    drop(v263_5);
    let v263_8: Space = intersect(&(*CONSTANT_7),&(v263_2));
    drop(v263_2);
    let v263_9: Space = if has_head(&(v263_8)) { singleton(&[]) } else { Space::new() };
    drop(v263_8);
    let v263_15: Space = if (v263_9).is_empty() { Space::new() } else {
      let v268_10: Path = concat_path(&(*CONSTANT_18),&(v262_18_head));
      let v268_11: Space = singleton(&(v268_10));
      drop(v268_10);
      let v268_12: Space = unite(&(*CONSTANT_24),&(v268_11));
      drop(v268_11);
      let v268_13: Space = unite(&(v268_12),&(v262_10));
      drop(v268_12);
      let v268_14: Space = unite(&(v268_13),&(v262_13));
      drop(v268_13);
      compose(&(v263_9),&(v268_14))
    };
    drop(v263_9);
    let v263_16: Space = unite(&(v263_7),&(v263_15));
    drop(v263_15);
    v262_18.join_into((v263_16).clone());
    }
    v262_18_cursor.ascend(1);
  }
  drop(v262_18_cursor);
  drop(v262_10);
  drop(v262_13);
  (v262_18).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v269_5 = Space::new();
  let mut v269_5_cursor = (*s0).read_zipper();
  for v269_5_byte in v269_5_cursor.child_mask().iter() {
    v269_5_cursor.descend_to_byte(v269_5_byte);
    {
    let v269_5_tail = v269_5_cursor.fork_read_zipper();
    let v269_5_head = Path::from_slice(&[v269_5_byte]);
    let v270_2: Space = singleton(&(v269_5_head));
    let v270_3: Space = intersect(&(*CONSTANT_7),&(v270_2));
    let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
    drop(v270_3);
    let v270_5: Space = subtract(&(*CONSTANT_0),&(v270_4));
    drop(v270_4);
    let v270_8: Space = if (v270_5).is_empty() { Space::new() } else {
      let v271_6: Path = concat_path(&(*p0),&(v269_5_head));
      let v271_7: Space = routine_16(c, &(v271_6), &(v269_5_tail).make_space());
      drop(v271_6);
      compose(&(v270_5),&(v271_7))
    };
    drop(v270_5);
    let v270_9: Space = intersect(&(*CONSTANT_7),&(v270_2));
    drop(v270_2);
    let v270_10: Space = if has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
    drop(v270_9);
    let v270_11: Space = compose(&(v270_10),&(v269_5_tail));
    drop(v270_10);
    let v270_12: Space = unite(&(v270_8),&(v270_11));
    drop(v270_11);
    v269_5.join_into((v270_12).clone());
    }
    v269_5_cursor.ascend(1);
  }
  drop(v269_5_cursor);
  (v269_5).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v272_11 = Space::new();
  let mut v272_11_cursor = (*s0).read_zipper();
  for v272_11_byte in v272_11_cursor.child_mask().iter() {
    v272_11_cursor.descend_to_byte(v272_11_byte);
    {
    let v272_11_tail = v272_11_cursor.fork_read_zipper();
    let v272_11_head = Path::from_slice(&[v272_11_byte]);
    let v273_2: Space = singleton(&(v272_11_head));
    let v273_3: Space = intersect(&(*CONSTANT_7),&(v273_2));
    let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
    drop(v273_3);
    let v273_5: Space = subtract(&(*CONSTANT_0),&(v273_4));
    drop(v273_4);
    let v273_8: Space = if (v273_5).is_empty() { Space::new() } else {
      let v274_6: Path = concat_path(&(*p0),&(v272_11_head));
      let v274_7: Space = routine_17(c, &(v274_6), &(v272_11_tail).make_space());
      compose(&(v273_5),&(v274_7))
    };
    drop(v273_5);
    let v273_9: Space = intersect(&(*CONSTANT_7),&(v273_2));
    drop(v273_2);
    let v273_10: Space = if has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
    drop(v273_9);
    let v273_12: Space = if (v273_10).is_empty() { Space::new() } else {
      let v275_6: Path = concat_path(&(*p0),&(v272_11_head));
      let mut v275_11 = Space::new();
      let mut v275_11_cursor = (v272_11_tail).read_zipper();
      for v275_11_byte in v275_11_cursor.child_mask().iter() {
        v275_11_cursor.descend_to_byte(v275_11_byte);
        {
        let v275_11_tail = v275_11_cursor.fork_read_zipper();
        let v275_11_head = Path::from_slice(&[v275_11_byte]);
        let v276_2: Space = singleton(&(v275_11_head));
        let v276_3: Space = intersect(&(*CONSTANT_7),&(v276_2));
        let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
        drop(v276_3);
        let v276_5: Space = subtract(&(*CONSTANT_0),&(v276_4));
        drop(v276_4);
        let v276_7: Space = if (v276_5).is_empty() { Space::new() } else {
          let v277_6: Space = routine_18(c, &(v275_11_head), &(v275_6), &(v275_11_tail).make_space());
          compose(&(v276_5),&(v277_6))
        };
        drop(v276_5);
        let v276_8: Space = intersect(&(*CONSTANT_7),&(v276_2));
        drop(v276_2);
        let v276_9: Space = if has_head(&(v276_8)) { singleton(&[]) } else { Space::new() };
        drop(v276_8);
        let v276_11: Space = if (v276_9).is_empty() { Space::new() } else {
          let mut v278_10 = Space::new();
          let mut v278_10_cursor = (v275_11_tail).read_zipper();
          for v278_10_byte in v278_10_cursor.child_mask().iter() {
            v278_10_cursor.descend_to_byte(v278_10_byte);
            {
            let v278_10_tail = v278_10_cursor.fork_read_zipper();
            let v278_10_head = Path::from_slice(&[v278_10_byte]);
            let v279_2: Space = singleton(&(v278_10_head));
            let v279_3: Space = intersect(&(*CONSTANT_7),&(v279_2));
            let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
            drop(v279_3);
            let v279_5: Space = subtract(&(*CONSTANT_0),&(v279_4));
            drop(v279_4);
            let v279_7: Space = if (v279_5).is_empty() { Space::new() } else {
              let v280_6: Space = routine_34(c, &(v278_10_head), &(v275_6), &(v275_11_head), &(v278_10_tail).make_space());
              compose(&(v279_5),&(v280_6))
            };
            drop(v279_5);
            let v279_8: Space = intersect(&(*CONSTANT_7),&(v279_2));
            drop(v279_2);
            let v279_9: Space = if has_head(&(v279_8)) { singleton(&[]) } else { Space::new() };
            drop(v279_8);
            let v279_11: Space = if (v279_9).is_empty() { Space::new() } else {
              let v281_10: Space = routine_35(c, &(v278_10_head), &(v275_6), &(v275_11_head), &(v278_10_tail).make_space());
              compose(&(v279_9),&(v281_10))
            };
            drop(v279_9);
            let v279_12: Space = unite(&(v279_7),&(v279_11));
            v278_10.join_into((v279_12).clone());
            }
            v278_10_cursor.ascend(1);
          }
          drop(v278_10_cursor);
          compose(&(v276_9),&(v278_10))
        };
        drop(v276_9);
        let v276_12: Space = unite(&(v276_7),&(v276_11));
        v275_11.join_into((v276_12).clone());
        }
        v275_11_cursor.ascend(1);
      }
      drop(v275_11_cursor);
      drop(v275_6);
      compose(&(v273_10),&(v275_11))
    };
    drop(v273_10);
    let v273_13: Space = unite(&(v273_8),&(v273_12));
    v272_11.join_into((v273_13).clone());
    }
    v272_11_cursor.ascend(1);
  }
  drop(v272_11_cursor);
  (v272_11).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v282_13: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v282_14: Space = singleton(&(v282_13));
  drop(v282_13);
  let mut v282_15 = Space::new();
  let mut v282_15_cursor = (*s0).read_zipper();
  for v282_15_byte in v282_15_cursor.child_mask().iter() {
    v282_15_cursor.descend_to_byte(v282_15_byte);
    {
    let v282_15_tail = v282_15_cursor.fork_read_zipper();
    let v282_15_head = Path::from_slice(&[v282_15_byte]);
    let v283_2: Space = singleton(&(v282_15_head));
    let v283_3: Space = intersect(&(*CONSTANT_7),&(v283_2));
    let v283_4: Space = if has_head(&(v283_3)) { singleton(&[]) } else { Space::new() };
    drop(v283_3);
    let v283_5: Space = subtract(&(*CONSTANT_0),&(v283_4));
    drop(v283_4);
    let v283_8: Space = if (v283_5).is_empty() { Space::new() } else {
      let v284_6: Path = concat_path(&(*p0),&(v282_15_head));
      let v284_7: Space = routine_18(c, &(v284_6), &(*p1), &(v282_15_tail).make_space());
      compose(&(v283_5),&(v284_7))
    };
    drop(v283_5);
    let v283_9: Space = intersect(&(*CONSTANT_7),&(v283_2));
    drop(v283_2);
    let v283_10: Space = if has_head(&(v283_9)) { singleton(&[]) } else { Space::new() };
    drop(v283_9);
    let v283_14: Space = if (v283_10).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&(v282_15_head));
      let v285_11: Path = concat_path(&(*CONSTANT_17),&(v285_6));
      let v285_12: Space = singleton(&(v285_11));
      drop(v285_11);
      let mut v285_13 = Space::new();
      let mut v285_13_cursor = (v282_15_tail).read_zipper();
      for v285_13_byte in v285_13_cursor.child_mask().iter() {
        v285_13_cursor.descend_to_byte(v285_13_byte);
        {
        let v285_13_tail = v285_13_cursor.fork_read_zipper();
        let v285_13_head = Path::from_slice(&[v285_13_byte]);
        let v286_2: Space = singleton(&(v285_13_head));
        let v286_3: Space = intersect(&(*CONSTANT_7),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_0),&(v286_4));
        drop(v286_4);
        let v286_7: Space = if (v286_5).is_empty() { Space::new() } else {
          let v287_6: Space = routine_34(c, &(v285_13_head), &(*p1), &(v285_6), &(v285_13_tail).make_space());
          compose(&(v286_5),&(v287_6))
        };
        drop(v286_5);
        let v286_8: Space = intersect(&(*CONSTANT_7),&(v286_2));
        drop(v286_2);
        let v286_9: Space = if has_head(&(v286_8)) { singleton(&[]) } else { Space::new() };
        drop(v286_8);
        let v286_15: Space = if (v286_9).is_empty() { Space::new() } else {
          let v288_10: Path = concat_path(&(*CONSTANT_19),&(v285_13_head));
          let v288_11: Space = singleton(&(v288_10));
          drop(v288_10);
          let v288_12: Space = unite(&(*CONSTANT_25),&(v288_11));
          drop(v288_11);
          let v288_13: Space = unite(&(v288_12),&(v282_14));
          drop(v288_12);
          let v288_14: Space = unite(&(v288_13),&(v285_12));
          drop(v288_13);
          compose(&(v286_9),&(v288_14))
        };
        drop(v286_9);
        let v286_16: Space = unite(&(v286_7),&(v286_15));
        drop(v286_15);
        v285_13.join_into((v286_16).clone());
        }
        v285_13_cursor.ascend(1);
      }
      drop(v285_13_cursor);
      drop(v285_6);
      drop(v285_12);
      compose(&(v283_10),&(v285_13))
    };
    drop(v283_10);
    let v283_15: Space = unite(&(v283_8),&(v283_14));
    v282_15.join_into((v283_15).clone());
    }
    v282_15_cursor.ascend(1);
  }
  drop(v282_15_cursor);
  drop(v282_14);
  (v282_15).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v289_9: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v289_10: Space = singleton(&(v289_9));
  drop(v289_9);
  let v289_12: Path = concat_path(&(*CONSTANT_17),&(*p0));
  let v289_13: Space = singleton(&(v289_12));
  drop(v289_12);
  let mut v289_18 = Space::new();
  let mut v289_18_cursor = (*s0).read_zipper();
  for v289_18_byte in v289_18_cursor.child_mask().iter() {
    v289_18_cursor.descend_to_byte(v289_18_byte);
    {
    let v289_18_tail = v289_18_cursor.fork_read_zipper();
    let v289_18_head = Path::from_slice(&[v289_18_byte]);
    let v290_2: Space = singleton(&(v289_18_head));
    let v290_3: Space = intersect(&(*CONSTANT_7),&(v290_2));
    let v290_4: Space = if has_head(&(v290_3)) { singleton(&[]) } else { Space::new() };
    drop(v290_3);
    let v290_5: Space = subtract(&(*CONSTANT_0),&(v290_4));
    drop(v290_4);
    let v290_7: Space = if (v290_5).is_empty() { Space::new() } else {
      let mut v291_6 = Space::new();
      let mut v291_6_cursor = (v289_18_tail).read_zipper();
      for v291_6_byte in v291_6_cursor.child_mask().iter() {
        v291_6_cursor.descend_to_byte(v291_6_byte);
        {
        let v291_6_tail = v291_6_cursor.fork_read_zipper();
        let v291_6_head = Path::from_slice(&[v291_6_byte]);
        let v292_2: Space = singleton(&(v291_6_head));
        let v292_3: Space = intersect(&(*CONSTANT_7),&(v292_2));
        let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
        drop(v292_3);
        let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
        drop(v292_4);
        let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
          let v293_6: Path = concat_path(&(v289_18_head),&(v291_6_head));
          let v293_7: Space = routine_34(c, &(v293_6), &(*p1), &(*p0), &(v291_6_tail).make_space());
          compose(&(v292_5),&(v293_7))
        };
        drop(v292_5);
        let v292_9: Space = intersect(&(*CONSTANT_7),&(v292_2));
        drop(v292_2);
        let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
        drop(v292_9);
        let v292_16: Space = if (v292_10).is_empty() { Space::new() } else {
          let v294_6: Path = concat_path(&(v289_18_head),&(v291_6_head));
          let v294_11: Path = concat_path(&(*CONSTANT_19),&(v294_6));
          drop(v294_6);
          let v294_12: Space = singleton(&(v294_11));
          drop(v294_11);
          let v294_13: Space = unite(&(*CONSTANT_25),&(v294_12));
          drop(v294_12);
          let v294_14: Space = unite(&(v294_13),&(v289_10));
          drop(v294_13);
          let v294_15: Space = unite(&(v294_14),&(v289_13));
          drop(v294_14);
          compose(&(v292_10),&(v294_15))
        };
        drop(v292_10);
        let v292_17: Space = unite(&(v292_8),&(v292_16));
        drop(v292_16);
        v291_6.join_into((v292_17).clone());
        }
        v291_6_cursor.ascend(1);
      }
      drop(v291_6_cursor);
      compose(&(v290_5),&(v291_6))
    };
    drop(v290_5);
    let v290_8: Space = intersect(&(*CONSTANT_7),&(v290_2));
    drop(v290_2);
    let v290_9: Space = if has_head(&(v290_8)) { singleton(&[]) } else { Space::new() };
    drop(v290_8);
    let v290_15: Space = if (v290_9).is_empty() { Space::new() } else {
      let v295_10: Path = concat_path(&(*CONSTANT_19),&(v289_18_head));
      let v295_11: Space = singleton(&(v295_10));
      drop(v295_10);
      let v295_12: Space = unite(&(*CONSTANT_25),&(v295_11));
      drop(v295_11);
      let v295_13: Space = unite(&(v295_12),&(v289_10));
      drop(v295_12);
      let v295_14: Space = unite(&(v295_13),&(v289_13));
      drop(v295_13);
      compose(&(v290_9),&(v295_14))
    };
    drop(v290_9);
    let v290_16: Space = unite(&(v290_7),&(v290_15));
    drop(v290_15);
    v289_18.join_into((v290_16).clone());
    }
    v289_18_cursor.ascend(1);
  }
  drop(v289_18_cursor);
  drop(v289_10);
  drop(v289_13);
  (v289_18).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v296_5 = Space::new();
  let mut v296_5_cursor = (*s0).read_zipper();
  for v296_5_byte in v296_5_cursor.child_mask().iter() {
    v296_5_cursor.descend_to_byte(v296_5_byte);
    {
    let v296_5_tail = v296_5_cursor.fork_read_zipper();
    let v296_5_head = Path::from_slice(&[v296_5_byte]);
    let v297_2: Space = singleton(&(v296_5_head));
    let v297_3: Space = intersect(&(*CONSTANT_7),&(v297_2));
    let v297_4: Space = if has_head(&(v297_3)) { singleton(&[]) } else { Space::new() };
    drop(v297_3);
    let v297_5: Space = subtract(&(*CONSTANT_0),&(v297_4));
    drop(v297_4);
    let v297_8: Space = if (v297_5).is_empty() { Space::new() } else {
      let v298_6: Path = concat_path(&(*p0),&(v296_5_head));
      let v298_7: Space = routine_20(c, &(v298_6), &(v296_5_tail).make_space());
      drop(v298_6);
      compose(&(v297_5),&(v298_7))
    };
    drop(v297_5);
    let v297_9: Space = intersect(&(*CONSTANT_7),&(v297_2));
    drop(v297_2);
    let v297_10: Space = if has_head(&(v297_9)) { singleton(&[]) } else { Space::new() };
    drop(v297_9);
    let v297_11: Space = compose(&(v297_10),&(v296_5_tail));
    drop(v297_10);
    let v297_12: Space = unite(&(v297_8),&(v297_11));
    drop(v297_11);
    v296_5.join_into((v297_12).clone());
    }
    v296_5_cursor.ascend(1);
  }
  drop(v296_5_cursor);
  (v296_5).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v299_11 = Space::new();
  let mut v299_11_cursor = (*s0).read_zipper();
  for v299_11_byte in v299_11_cursor.child_mask().iter() {
    v299_11_cursor.descend_to_byte(v299_11_byte);
    {
    let v299_11_tail = v299_11_cursor.fork_read_zipper();
    let v299_11_head = Path::from_slice(&[v299_11_byte]);
    let v300_2: Space = singleton(&(v299_11_head));
    let v300_3: Space = intersect(&(*CONSTANT_7),&(v300_2));
    let v300_4: Space = if has_head(&(v300_3)) { singleton(&[]) } else { Space::new() };
    drop(v300_3);
    let v300_5: Space = subtract(&(*CONSTANT_0),&(v300_4));
    drop(v300_4);
    let v300_8: Space = if (v300_5).is_empty() { Space::new() } else {
      let v301_6: Path = concat_path(&(*p0),&(v299_11_head));
      let v301_7: Space = routine_21(c, &(v301_6), &(v299_11_tail).make_space());
      compose(&(v300_5),&(v301_7))
    };
    drop(v300_5);
    let v300_9: Space = intersect(&(*CONSTANT_7),&(v300_2));
    drop(v300_2);
    let v300_10: Space = if has_head(&(v300_9)) { singleton(&[]) } else { Space::new() };
    drop(v300_9);
    let v300_12: Space = if (v300_10).is_empty() { Space::new() } else {
      let v302_6: Path = concat_path(&(*p0),&(v299_11_head));
      let mut v302_11 = Space::new();
      let mut v302_11_cursor = (v299_11_tail).read_zipper();
      for v302_11_byte in v302_11_cursor.child_mask().iter() {
        v302_11_cursor.descend_to_byte(v302_11_byte);
        {
        let v302_11_tail = v302_11_cursor.fork_read_zipper();
        let v302_11_head = Path::from_slice(&[v302_11_byte]);
        let v303_2: Space = singleton(&(v302_11_head));
        let v303_3: Space = intersect(&(*CONSTANT_7),&(v303_2));
        let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
        drop(v303_3);
        let v303_5: Space = subtract(&(*CONSTANT_0),&(v303_4));
        drop(v303_4);
        let v303_7: Space = if (v303_5).is_empty() { Space::new() } else {
          let v304_6: Space = routine_22(c, &(v302_11_head), &(v302_6), &(v302_11_tail).make_space());
          compose(&(v303_5),&(v304_6))
        };
        drop(v303_5);
        let v303_8: Space = intersect(&(*CONSTANT_7),&(v303_2));
        drop(v303_2);
        let v303_9: Space = if has_head(&(v303_8)) { singleton(&[]) } else { Space::new() };
        drop(v303_8);
        let v303_11: Space = if (v303_9).is_empty() { Space::new() } else {
          let mut v305_10 = Space::new();
          let mut v305_10_cursor = (v302_11_tail).read_zipper();
          for v305_10_byte in v305_10_cursor.child_mask().iter() {
            v305_10_cursor.descend_to_byte(v305_10_byte);
            {
            let v305_10_tail = v305_10_cursor.fork_read_zipper();
            let v305_10_head = Path::from_slice(&[v305_10_byte]);
            let v306_2: Space = singleton(&(v305_10_head));
            let v306_3: Space = intersect(&(*CONSTANT_7),&(v306_2));
            let v306_4: Space = if has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
            drop(v306_3);
            let v306_5: Space = subtract(&(*CONSTANT_0),&(v306_4));
            drop(v306_4);
            let v306_7: Space = if (v306_5).is_empty() { Space::new() } else {
              let v307_6: Space = routine_36(c, &(v305_10_head), &(v302_6), &(v302_11_head), &(v305_10_tail).make_space());
              compose(&(v306_5),&(v307_6))
            };
            drop(v306_5);
            let v306_8: Space = intersect(&(*CONSTANT_7),&(v306_2));
            drop(v306_2);
            let v306_9: Space = if has_head(&(v306_8)) { singleton(&[]) } else { Space::new() };
            drop(v306_8);
            let v306_11: Space = if (v306_9).is_empty() { Space::new() } else {
              let v308_10: Space = routine_37(c, &(v305_10_head), &(v302_6), &(v302_11_head), &(v305_10_tail).make_space());
              compose(&(v306_9),&(v308_10))
            };
            drop(v306_9);
            let v306_12: Space = unite(&(v306_7),&(v306_11));
            v305_10.join_into((v306_12).clone());
            }
            v305_10_cursor.ascend(1);
          }
          drop(v305_10_cursor);
          compose(&(v303_9),&(v305_10))
        };
        drop(v303_9);
        let v303_12: Space = unite(&(v303_7),&(v303_11));
        v302_11.join_into((v303_12).clone());
        }
        v302_11_cursor.ascend(1);
      }
      drop(v302_11_cursor);
      drop(v302_6);
      compose(&(v300_10),&(v302_11))
    };
    drop(v300_10);
    let v300_13: Space = unite(&(v300_8),&(v300_12));
    v299_11.join_into((v300_13).clone());
    }
    v299_11_cursor.ascend(1);
  }
  drop(v299_11_cursor);
  (v299_11).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v309_13: Path = concat_path(&(*CONSTANT_17),&(*p1));
  let v309_14: Space = singleton(&(v309_13));
  drop(v309_13);
  let mut v309_15 = Space::new();
  let mut v309_15_cursor = (*s0).read_zipper();
  for v309_15_byte in v309_15_cursor.child_mask().iter() {
    v309_15_cursor.descend_to_byte(v309_15_byte);
    {
    let v309_15_tail = v309_15_cursor.fork_read_zipper();
    let v309_15_head = Path::from_slice(&[v309_15_byte]);
    let v310_2: Space = singleton(&(v309_15_head));
    let v310_3: Space = intersect(&(*CONSTANT_7),&(v310_2));
    let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
    drop(v310_3);
    let v310_5: Space = subtract(&(*CONSTANT_0),&(v310_4));
    drop(v310_4);
    let v310_8: Space = if (v310_5).is_empty() { Space::new() } else {
      let v311_6: Path = concat_path(&(*p0),&(v309_15_head));
      let v311_7: Space = routine_22(c, &(v311_6), &(*p1), &(v309_15_tail).make_space());
      compose(&(v310_5),&(v311_7))
    };
    drop(v310_5);
    let v310_9: Space = intersect(&(*CONSTANT_7),&(v310_2));
    drop(v310_2);
    let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
    drop(v310_9);
    let v310_15: Space = if (v310_10).is_empty() { Space::new() } else {
      let v312_6: Path = concat_path(&(*p0),&(v309_15_head));
      let v312_11: Path = concat_path(&(*CONSTANT_19),&(v312_6));
      let v312_12: Space = singleton(&(v312_11));
      drop(v312_11);
      let v312_13: Space = unite(&(*CONSTANT_26),&(v312_12));
      drop(v312_12);
      let mut v312_14 = Space::new();
      let mut v312_14_cursor = (v309_15_tail).read_zipper();
      for v312_14_byte in v312_14_cursor.child_mask().iter() {
        v312_14_cursor.descend_to_byte(v312_14_byte);
        {
        let v312_14_tail = v312_14_cursor.fork_read_zipper();
        let v312_14_head = Path::from_slice(&[v312_14_byte]);
        let v313_2: Space = singleton(&(v312_14_head));
        let v313_3: Space = intersect(&(*CONSTANT_7),&(v313_2));
        let v313_4: Space = if has_head(&(v313_3)) { singleton(&[]) } else { Space::new() };
        drop(v313_3);
        let v313_5: Space = subtract(&(*CONSTANT_0),&(v313_4));
        drop(v313_4);
        let v313_7: Space = if (v313_5).is_empty() { Space::new() } else {
          let v314_6: Space = routine_36(c, &(v312_14_head), &(*p1), &(v312_6), &(v312_14_tail).make_space());
          compose(&(v313_5),&(v314_6))
        };
        drop(v313_5);
        let v313_8: Space = intersect(&(*CONSTANT_7),&(v313_2));
        drop(v313_2);
        let v313_9: Space = if has_head(&(v313_8)) { singleton(&[]) } else { Space::new() };
        drop(v313_8);
        let v313_14: Space = if (v313_9).is_empty() { Space::new() } else {
          let v315_10: Path = concat_path(&(*CONSTANT_18),&(v312_14_head));
          let v315_11: Space = singleton(&(v315_10));
          drop(v315_10);
          let v315_12: Space = unite(&(v312_13),&(v315_11));
          drop(v315_11);
          let v315_13: Space = unite(&(v315_12),&(v309_14));
          drop(v315_12);
          compose(&(v313_9),&(v315_13))
        };
        drop(v313_9);
        let v313_15: Space = unite(&(v313_7),&(v313_14));
        drop(v313_14);
        v312_14.join_into((v313_15).clone());
        }
        v312_14_cursor.ascend(1);
      }
      drop(v312_14_cursor);
      drop(v312_6);
      drop(v312_13);
      compose(&(v310_10),&(v312_14))
    };
    drop(v310_10);
    let v310_16: Space = unite(&(v310_8),&(v310_15));
    v309_15.join_into((v310_16).clone());
    }
    v309_15_cursor.ascend(1);
  }
  drop(v309_15_cursor);
  drop(v309_14);
  (v309_15).clone()
}

fn routine_23(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v316_8: Path = concat_path(&(*CONSTANT_19),&(*p0));
  let v316_9: Space = singleton(&(v316_8));
  drop(v316_8);
  let v316_10: Space = unite(&(*CONSTANT_26),&(v316_9));
  let v316_13: Path = concat_path(&(*CONSTANT_17),&(*p1));
  let v316_14: Space = singleton(&(v316_13));
  drop(v316_13);
  let v316_19: Space = unite(&(*CONSTANT_26),&(v316_9));
  drop(v316_9);
  let mut v316_20 = Space::new();
  let mut v316_20_cursor = (*s0).read_zipper();
  for v316_20_byte in v316_20_cursor.child_mask().iter() {
    v316_20_cursor.descend_to_byte(v316_20_byte);
    {
    let v316_20_tail = v316_20_cursor.fork_read_zipper();
    let v316_20_head = Path::from_slice(&[v316_20_byte]);
    let v317_2: Space = singleton(&(v316_20_head));
    let v317_3: Space = intersect(&(*CONSTANT_7),&(v317_2));
    let v317_4: Space = if has_head(&(v317_3)) { singleton(&[]) } else { Space::new() };
    drop(v317_3);
    let v317_5: Space = subtract(&(*CONSTANT_0),&(v317_4));
    drop(v317_4);
    let v317_7: Space = if (v317_5).is_empty() { Space::new() } else {
      let mut v318_6 = Space::new();
      let mut v318_6_cursor = (v316_20_tail).read_zipper();
      for v318_6_byte in v318_6_cursor.child_mask().iter() {
        v318_6_cursor.descend_to_byte(v318_6_byte);
        {
        let v318_6_tail = v318_6_cursor.fork_read_zipper();
        let v318_6_head = Path::from_slice(&[v318_6_byte]);
        let v319_2: Space = singleton(&(v318_6_head));
        let v319_3: Space = intersect(&(*CONSTANT_7),&(v319_2));
        let v319_4: Space = if has_head(&(v319_3)) { singleton(&[]) } else { Space::new() };
        drop(v319_3);
        let v319_5: Space = subtract(&(*CONSTANT_0),&(v319_4));
        drop(v319_4);
        let v319_8: Space = if (v319_5).is_empty() { Space::new() } else {
          let v320_6: Path = concat_path(&(v316_20_head),&(v318_6_head));
          let v320_7: Space = routine_36(c, &(v320_6), &(*p1), &(*p0), &(v318_6_tail).make_space());
          compose(&(v319_5),&(v320_7))
        };
        drop(v319_5);
        let v319_9: Space = intersect(&(*CONSTANT_7),&(v319_2));
        drop(v319_2);
        let v319_10: Space = if has_head(&(v319_9)) { singleton(&[]) } else { Space::new() };
        drop(v319_9);
        let v319_15: Space = if (v319_10).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v316_20_head),&(v318_6_head));
          let v321_11: Path = concat_path(&(*CONSTANT_18),&(v321_6));
          drop(v321_6);
          let v321_12: Space = singleton(&(v321_11));
          drop(v321_11);
          let v321_13: Space = unite(&(v316_19),&(v321_12));
          drop(v321_12);
          let v321_14: Space = unite(&(v321_13),&(v316_14));
          drop(v321_13);
          compose(&(v319_10),&(v321_14))
        };
        drop(v319_10);
        let v319_16: Space = unite(&(v319_8),&(v319_15));
        drop(v319_15);
        v318_6.join_into((v319_16).clone());
        }
        v318_6_cursor.ascend(1);
      }
      drop(v318_6_cursor);
      compose(&(v317_5),&(v318_6))
    };
    drop(v317_5);
    let v317_8: Space = intersect(&(*CONSTANT_7),&(v317_2));
    drop(v317_2);
    let v317_9: Space = if has_head(&(v317_8)) { singleton(&[]) } else { Space::new() };
    drop(v317_8);
    let v317_14: Space = if (v317_9).is_empty() { Space::new() } else {
      let v322_10: Path = concat_path(&(*CONSTANT_18),&(v316_20_head));
      let v322_11: Space = singleton(&(v322_10));
      drop(v322_10);
      let v322_12: Space = unite(&(v316_10),&(v322_11));
      drop(v322_11);
      let v322_13: Space = unite(&(v322_12),&(v316_14));
      drop(v322_12);
      compose(&(v317_9),&(v322_13))
    };
    drop(v317_9);
    let v317_15: Space = unite(&(v317_7),&(v317_14));
    drop(v317_14);
    v316_20.join_into((v317_15).clone());
    }
    v316_20_cursor.ascend(1);
  }
  drop(v316_20_cursor);
  drop(v316_10);
  drop(v316_14);
  drop(v316_19);
  (v316_20).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v323_5 = Space::new();
  let mut v323_5_cursor = (*s0).read_zipper();
  for v323_5_byte in v323_5_cursor.child_mask().iter() {
    v323_5_cursor.descend_to_byte(v323_5_byte);
    {
    let v323_5_tail = v323_5_cursor.fork_read_zipper();
    let v323_5_head = Path::from_slice(&[v323_5_byte]);
    let v324_2: Space = singleton(&(v323_5_head));
    let v324_3: Space = intersect(&(*CONSTANT_7),&(v324_2));
    let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
    drop(v324_3);
    let v324_5: Space = subtract(&(*CONSTANT_0),&(v324_4));
    drop(v324_4);
    let v324_8: Space = if (v324_5).is_empty() { Space::new() } else {
      let v325_6: Path = concat_path(&(*p0),&(v323_5_head));
      let v325_7: Space = routine_24(c, &(v325_6), &(v323_5_tail).make_space());
      drop(v325_6);
      compose(&(v324_5),&(v325_7))
    };
    drop(v324_5);
    let v324_9: Space = intersect(&(*CONSTANT_7),&(v324_2));
    drop(v324_2);
    let v324_10: Space = if has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
    drop(v324_9);
    let v324_11: Space = compose(&(v324_10),&(v323_5_tail));
    drop(v324_10);
    let v324_12: Space = unite(&(v324_8),&(v324_11));
    drop(v324_11);
    v323_5.join_into((v324_12).clone());
    }
    v323_5_cursor.ascend(1);
  }
  drop(v323_5_cursor);
  (v323_5).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v326_11 = Space::new();
  let mut v326_11_cursor = (*s0).read_zipper();
  for v326_11_byte in v326_11_cursor.child_mask().iter() {
    v326_11_cursor.descend_to_byte(v326_11_byte);
    {
    let v326_11_tail = v326_11_cursor.fork_read_zipper();
    let v326_11_head = Path::from_slice(&[v326_11_byte]);
    let v327_2: Space = singleton(&(v326_11_head));
    let v327_3: Space = intersect(&(*CONSTANT_7),&(v327_2));
    let v327_4: Space = if has_head(&(v327_3)) { singleton(&[]) } else { Space::new() };
    drop(v327_3);
    let v327_5: Space = subtract(&(*CONSTANT_0),&(v327_4));
    drop(v327_4);
    let v327_8: Space = if (v327_5).is_empty() { Space::new() } else {
      let v328_6: Path = concat_path(&(*p0),&(v326_11_head));
      let v328_7: Space = routine_25(c, &(v328_6), &(v326_11_tail).make_space());
      compose(&(v327_5),&(v328_7))
    };
    drop(v327_5);
    let v327_9: Space = intersect(&(*CONSTANT_7),&(v327_2));
    drop(v327_2);
    let v327_10: Space = if has_head(&(v327_9)) { singleton(&[]) } else { Space::new() };
    drop(v327_9);
    let v327_12: Space = if (v327_10).is_empty() { Space::new() } else {
      let v329_6: Path = concat_path(&(*p0),&(v326_11_head));
      let mut v329_11 = Space::new();
      let mut v329_11_cursor = (v326_11_tail).read_zipper();
      for v329_11_byte in v329_11_cursor.child_mask().iter() {
        v329_11_cursor.descend_to_byte(v329_11_byte);
        {
        let v329_11_tail = v329_11_cursor.fork_read_zipper();
        let v329_11_head = Path::from_slice(&[v329_11_byte]);
        let v330_2: Space = singleton(&(v329_11_head));
        let v330_3: Space = intersect(&(*CONSTANT_7),&(v330_2));
        let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
        drop(v330_3);
        let v330_5: Space = subtract(&(*CONSTANT_0),&(v330_4));
        drop(v330_4);
        let v330_7: Space = if (v330_5).is_empty() { Space::new() } else {
          let v331_6: Space = routine_26(c, &(v329_11_head), &(v329_6), &(v329_11_tail).make_space());
          compose(&(v330_5),&(v331_6))
        };
        drop(v330_5);
        let v330_8: Space = intersect(&(*CONSTANT_7),&(v330_2));
        drop(v330_2);
        let v330_9: Space = if has_head(&(v330_8)) { singleton(&[]) } else { Space::new() };
        drop(v330_8);
        let v330_11: Space = if (v330_9).is_empty() { Space::new() } else {
          let mut v332_10 = Space::new();
          let mut v332_10_cursor = (v329_11_tail).read_zipper();
          for v332_10_byte in v332_10_cursor.child_mask().iter() {
            v332_10_cursor.descend_to_byte(v332_10_byte);
            {
            let v332_10_tail = v332_10_cursor.fork_read_zipper();
            let v332_10_head = Path::from_slice(&[v332_10_byte]);
            let v333_2: Space = singleton(&(v332_10_head));
            let v333_3: Space = intersect(&(*CONSTANT_7),&(v333_2));
            let v333_4: Space = if has_head(&(v333_3)) { singleton(&[]) } else { Space::new() };
            drop(v333_3);
            let v333_5: Space = subtract(&(*CONSTANT_0),&(v333_4));
            drop(v333_4);
            let v333_7: Space = if (v333_5).is_empty() { Space::new() } else {
              let v334_6: Space = routine_38(c, &(v332_10_head), &(v329_6), &(v329_11_head), &(v332_10_tail).make_space());
              compose(&(v333_5),&(v334_6))
            };
            drop(v333_5);
            let v333_8: Space = intersect(&(*CONSTANT_7),&(v333_2));
            drop(v333_2);
            let v333_9: Space = if has_head(&(v333_8)) { singleton(&[]) } else { Space::new() };
            drop(v333_8);
            let v333_11: Space = if (v333_9).is_empty() { Space::new() } else {
              let v335_10: Space = routine_39(c, &(v332_10_head), &(v329_6), &(v329_11_head), &(v332_10_tail).make_space());
              compose(&(v333_9),&(v335_10))
            };
            drop(v333_9);
            let v333_12: Space = unite(&(v333_7),&(v333_11));
            v332_10.join_into((v333_12).clone());
            }
            v332_10_cursor.ascend(1);
          }
          drop(v332_10_cursor);
          compose(&(v330_9),&(v332_10))
        };
        drop(v330_9);
        let v330_12: Space = unite(&(v330_7),&(v330_11));
        v329_11.join_into((v330_12).clone());
        }
        v329_11_cursor.ascend(1);
      }
      drop(v329_11_cursor);
      drop(v329_6);
      compose(&(v327_10),&(v329_11))
    };
    drop(v327_10);
    let v327_13: Space = unite(&(v327_8),&(v327_12));
    v326_11.join_into((v327_13).clone());
    }
    v326_11_cursor.ascend(1);
  }
  drop(v326_11_cursor);
  (v326_11).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v336_13: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v336_14: Space = singleton(&(v336_13));
  drop(v336_13);
  let mut v336_15 = Space::new();
  let mut v336_15_cursor = (*s0).read_zipper();
  for v336_15_byte in v336_15_cursor.child_mask().iter() {
    v336_15_cursor.descend_to_byte(v336_15_byte);
    {
    let v336_15_tail = v336_15_cursor.fork_read_zipper();
    let v336_15_head = Path::from_slice(&[v336_15_byte]);
    let v337_2: Space = singleton(&(v336_15_head));
    let v337_3: Space = intersect(&(*CONSTANT_7),&(v337_2));
    let v337_4: Space = if has_head(&(v337_3)) { singleton(&[]) } else { Space::new() };
    drop(v337_3);
    let v337_5: Space = subtract(&(*CONSTANT_0),&(v337_4));
    drop(v337_4);
    let v337_8: Space = if (v337_5).is_empty() { Space::new() } else {
      let v338_6: Path = concat_path(&(*p0),&(v336_15_head));
      let v338_7: Space = routine_26(c, &(v338_6), &(*p1), &(v336_15_tail).make_space());
      compose(&(v337_5),&(v338_7))
    };
    drop(v337_5);
    let v337_9: Space = intersect(&(*CONSTANT_7),&(v337_2));
    drop(v337_2);
    let v337_10: Space = if has_head(&(v337_9)) { singleton(&[]) } else { Space::new() };
    drop(v337_9);
    let v337_15: Space = if (v337_10).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&(v336_15_head));
      let v339_11: Path = concat_path(&(*CONSTANT_19),&(v339_6));
      let v339_12: Space = singleton(&(v339_11));
      drop(v339_11);
      let v339_13: Space = unite(&(*CONSTANT_27),&(v339_12));
      drop(v339_12);
      let mut v339_14 = Space::new();
      let mut v339_14_cursor = (v336_15_tail).read_zipper();
      for v339_14_byte in v339_14_cursor.child_mask().iter() {
        v339_14_cursor.descend_to_byte(v339_14_byte);
        {
        let v339_14_tail = v339_14_cursor.fork_read_zipper();
        let v339_14_head = Path::from_slice(&[v339_14_byte]);
        let v340_2: Space = singleton(&(v339_14_head));
        let v340_3: Space = intersect(&(*CONSTANT_7),&(v340_2));
        let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
        drop(v340_4);
        let v340_7: Space = if (v340_5).is_empty() { Space::new() } else {
          let v341_6: Space = routine_38(c, &(v339_14_head), &(*p1), &(v339_6), &(v339_14_tail).make_space());
          compose(&(v340_5),&(v341_6))
        };
        drop(v340_5);
        let v340_8: Space = intersect(&(*CONSTANT_7),&(v340_2));
        drop(v340_2);
        let v340_9: Space = if has_head(&(v340_8)) { singleton(&[]) } else { Space::new() };
        drop(v340_8);
        let v340_14: Space = if (v340_9).is_empty() { Space::new() } else {
          let v342_10: Path = concat_path(&(*CONSTANT_18),&(v339_14_head));
          let v342_11: Space = singleton(&(v342_10));
          drop(v342_10);
          let v342_12: Space = unite(&(v339_13),&(v342_11));
          drop(v342_11);
          let v342_13: Space = unite(&(v342_12),&(v336_14));
          drop(v342_12);
          compose(&(v340_9),&(v342_13))
        };
        drop(v340_9);
        let v340_15: Space = unite(&(v340_7),&(v340_14));
        drop(v340_14);
        v339_14.join_into((v340_15).clone());
        }
        v339_14_cursor.ascend(1);
      }
      drop(v339_14_cursor);
      drop(v339_6);
      drop(v339_13);
      compose(&(v337_10),&(v339_14))
    };
    drop(v337_10);
    let v337_16: Space = unite(&(v337_8),&(v337_15));
    v336_15.join_into((v337_16).clone());
    }
    v336_15_cursor.ascend(1);
  }
  drop(v336_15_cursor);
  drop(v336_14);
  (v336_15).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v343_8: Path = concat_path(&(*CONSTANT_19),&(*p0));
  let v343_9: Space = singleton(&(v343_8));
  drop(v343_8);
  let v343_10: Space = unite(&(*CONSTANT_27),&(v343_9));
  let v343_13: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v343_14: Space = singleton(&(v343_13));
  drop(v343_13);
  let v343_19: Space = unite(&(*CONSTANT_27),&(v343_9));
  drop(v343_9);
  let mut v343_20 = Space::new();
  let mut v343_20_cursor = (*s0).read_zipper();
  for v343_20_byte in v343_20_cursor.child_mask().iter() {
    v343_20_cursor.descend_to_byte(v343_20_byte);
    {
    let v343_20_tail = v343_20_cursor.fork_read_zipper();
    let v343_20_head = Path::from_slice(&[v343_20_byte]);
    let v344_2: Space = singleton(&(v343_20_head));
    let v344_3: Space = intersect(&(*CONSTANT_7),&(v344_2));
    let v344_4: Space = if has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
    drop(v344_3);
    let v344_5: Space = subtract(&(*CONSTANT_0),&(v344_4));
    drop(v344_4);
    let v344_7: Space = if (v344_5).is_empty() { Space::new() } else {
      let mut v345_6 = Space::new();
      let mut v345_6_cursor = (v343_20_tail).read_zipper();
      for v345_6_byte in v345_6_cursor.child_mask().iter() {
        v345_6_cursor.descend_to_byte(v345_6_byte);
        {
        let v345_6_tail = v345_6_cursor.fork_read_zipper();
        let v345_6_head = Path::from_slice(&[v345_6_byte]);
        let v346_2: Space = singleton(&(v345_6_head));
        let v346_3: Space = intersect(&(*CONSTANT_7),&(v346_2));
        let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
        drop(v346_3);
        let v346_5: Space = subtract(&(*CONSTANT_0),&(v346_4));
        drop(v346_4);
        let v346_8: Space = if (v346_5).is_empty() { Space::new() } else {
          let v347_6: Path = concat_path(&(v343_20_head),&(v345_6_head));
          let v347_7: Space = routine_38(c, &(v347_6), &(*p1), &(*p0), &(v345_6_tail).make_space());
          compose(&(v346_5),&(v347_7))
        };
        drop(v346_5);
        let v346_9: Space = intersect(&(*CONSTANT_7),&(v346_2));
        drop(v346_2);
        let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
        drop(v346_9);
        let v346_15: Space = if (v346_10).is_empty() { Space::new() } else {
          let v348_6: Path = concat_path(&(v343_20_head),&(v345_6_head));
          let v348_11: Path = concat_path(&(*CONSTANT_18),&(v348_6));
          drop(v348_6);
          let v348_12: Space = singleton(&(v348_11));
          drop(v348_11);
          let v348_13: Space = unite(&(v343_19),&(v348_12));
          drop(v348_12);
          let v348_14: Space = unite(&(v348_13),&(v343_14));
          drop(v348_13);
          compose(&(v346_10),&(v348_14))
        };
        drop(v346_10);
        let v346_16: Space = unite(&(v346_8),&(v346_15));
        drop(v346_15);
        v345_6.join_into((v346_16).clone());
        }
        v345_6_cursor.ascend(1);
      }
      drop(v345_6_cursor);
      compose(&(v344_5),&(v345_6))
    };
    drop(v344_5);
    let v344_8: Space = intersect(&(*CONSTANT_7),&(v344_2));
    drop(v344_2);
    let v344_9: Space = if has_head(&(v344_8)) { singleton(&[]) } else { Space::new() };
    drop(v344_8);
    let v344_14: Space = if (v344_9).is_empty() { Space::new() } else {
      let v349_10: Path = concat_path(&(*CONSTANT_18),&(v343_20_head));
      let v349_11: Space = singleton(&(v349_10));
      drop(v349_10);
      let v349_12: Space = unite(&(v343_10),&(v349_11));
      drop(v349_11);
      let v349_13: Space = unite(&(v349_12),&(v343_14));
      drop(v349_12);
      compose(&(v344_9),&(v349_13))
    };
    drop(v344_9);
    let v344_15: Space = unite(&(v344_7),&(v344_14));
    drop(v344_14);
    v343_20.join_into((v344_15).clone());
    }
    v343_20_cursor.ascend(1);
  }
  drop(v343_20_cursor);
  drop(v343_10);
  drop(v343_14);
  drop(v343_19);
  (v343_20).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v350_12 = Space::new();
  let mut v350_12_cursor = (*s0).read_zipper();
  for v350_12_byte in v350_12_cursor.child_mask().iter() {
    v350_12_cursor.descend_to_byte(v350_12_byte);
    {
    let v350_12_tail = v350_12_cursor.fork_read_zipper();
    let v350_12_head = Path::from_slice(&[v350_12_byte]);
    let v351_2: Space = singleton(&(v350_12_head));
    let v351_3: Space = intersect(&(*CONSTANT_7),&(v351_2));
    let v351_4: Space = if has_head(&(v351_3)) { singleton(&[]) } else { Space::new() };
    drop(v351_3);
    let v351_5: Space = subtract(&(*CONSTANT_0),&(v351_4));
    drop(v351_4);
    let v351_8: Space = if (v351_5).is_empty() { Space::new() } else {
      let v352_6: Path = concat_path(&(*p0),&(v350_12_head));
      let v352_7: Space = routine_28(c, &(v352_6), &(v350_12_tail).make_space());
      compose(&(v351_5),&(v352_7))
    };
    drop(v351_5);
    let v351_9: Space = intersect(&(*CONSTANT_7),&(v351_2));
    drop(v351_2);
    let v351_10: Space = if has_head(&(v351_9)) { singleton(&[]) } else { Space::new() };
    drop(v351_9);
    let v351_12: Space = if (v351_10).is_empty() { Space::new() } else {
      let v353_6: Path = concat_path(&(*p0),&(v350_12_head));
      let mut v353_11 = Space::new();
      let mut v353_11_cursor = (v350_12_tail).read_zipper();
      for v353_11_byte in v353_11_cursor.child_mask().iter() {
        v353_11_cursor.descend_to_byte(v353_11_byte);
        {
        let v353_11_tail = v353_11_cursor.fork_read_zipper();
        let v353_11_head = Path::from_slice(&[v353_11_byte]);
        let v354_2: Space = singleton(&(v353_11_head));
        let v354_3: Space = intersect(&(*CONSTANT_7),&(v354_2));
        let v354_4: Space = if has_head(&(v354_3)) { singleton(&[]) } else { Space::new() };
        drop(v354_3);
        let v354_5: Space = subtract(&(*CONSTANT_0),&(v354_4));
        drop(v354_4);
        let v354_7: Space = if (v354_5).is_empty() { Space::new() } else {
          let v355_6: Space = routine_40(c, &(v353_11_head), &(v353_6), &(v353_11_tail).make_space());
          compose(&(v354_5),&(v355_6))
        };
        drop(v354_5);
        let v354_8: Space = intersect(&(*CONSTANT_7),&(v354_2));
        drop(v354_2);
        let v354_9: Space = if has_head(&(v354_8)) { singleton(&[]) } else { Space::new() };
        drop(v354_8);
        let v354_13: Space = if (v354_9).is_empty() { Space::new() } else {
          let mut v356_10 = Space::new();
          let mut v356_10_cursor = (v353_11_tail).read_zipper();
          for v356_10_byte in v356_10_cursor.child_mask().iter() {
            v356_10_cursor.descend_to_byte(v356_10_byte);
            {
            let v356_10_tail = v356_10_cursor.fork_read_zipper();
            let v356_10_head = Path::from_slice(&[v356_10_byte]);
            let v357_2: Space = singleton(&(v356_10_head));
            let v357_3: Space = intersect(&(*CONSTANT_7),&(v357_2));
            let v357_4: Space = if has_head(&(v357_3)) { singleton(&[]) } else { Space::new() };
            drop(v357_3);
            let v357_5: Space = subtract(&(*CONSTANT_0),&(v357_4));
            drop(v357_4);
            let v357_7: Space = if (v357_5).is_empty() { Space::new() } else {
              let v358_6: Space = routine_41(c, &(v356_10_head), &(v356_10_tail).make_space());
              compose(&(v357_5),&(v358_6))
            };
            drop(v357_5);
            let v357_8: Space = intersect(&(*CONSTANT_7),&(v357_2));
            drop(v357_2);
            let v357_9: Space = if has_head(&(v357_8)) { singleton(&[]) } else { Space::new() };
            drop(v357_8);
            let v357_11: Space = if (v357_9).is_empty() { Space::new() } else {
              let v359_10: Space = routine_42(c, &(v356_10_head), &(v356_10_tail).make_space());
              compose(&(v357_9),&(v359_10))
            };
            drop(v357_9);
            let v357_12: Space = unite(&(v357_7),&(v357_11));
            v356_10.join_into((v357_12).clone());
            }
            v356_10_cursor.ascend(1);
          }
          drop(v356_10_cursor);
          let v356_11: Space = raffine(&(*CONSTANT_28),&(v356_10));
          let v356_12: Space = unite(&(v356_11),&(v353_11_tail));
          compose(&(v354_9),&(v356_12))
        };
        drop(v354_9);
        let v354_14: Path = concat_path(&(v353_6),&(v353_11_head));
        let v354_15: Space = wrap(&(v354_13),&(v354_14));
        drop(v354_14);
        let v354_16: Space = unite(&(v354_7),&(v354_15));
        v353_11.join_into((v354_16).clone());
        }
        v353_11_cursor.ascend(1);
      }
      drop(v353_11_cursor);
      drop(v353_6);
      compose(&(v351_10),&(v353_11))
    };
    drop(v351_10);
    let v351_13: Space = unite(&(v351_8),&(v351_12));
    v350_12.join_into((v351_13).clone());
    }
    v350_12_cursor.ascend(1);
  }
  drop(v350_12_cursor);
  (v350_12).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v360_7 = Space::new();
  let mut v360_7_cursor = (*s0).read_zipper();
  for v360_7_byte in v360_7_cursor.child_mask().iter() {
    v360_7_cursor.descend_to_byte(v360_7_byte);
    {
    let v360_7_tail = v360_7_cursor.fork_read_zipper();
    let v360_7_head = Path::from_slice(&[v360_7_byte]);
    let v361_2: Space = singleton(&(v360_7_head));
    let v361_3: Space = intersect(&(*CONSTANT_7),&(v361_2));
    let v361_4: Space = if has_head(&(v361_3)) { singleton(&[]) } else { Space::new() };
    drop(v361_3);
    let v361_5: Space = subtract(&(*CONSTANT_0),&(v361_4));
    drop(v361_4);
    let v361_8: Space = if (v361_5).is_empty() { Space::new() } else {
      let v362_6: Path = concat_path(&(*p0),&(v360_7_head));
      let v362_7: Space = routine_29(c, &(v362_6), &(*p1), &(v360_7_tail).make_space(), &(*s1));
      compose(&(v361_5),&(v362_7))
    };
    drop(v361_5);
    let v361_9: Space = intersect(&(*CONSTANT_7),&(v361_2));
    drop(v361_2);
    let v361_10: Space = if has_head(&(v361_9)) { singleton(&[]) } else { Space::new() };
    drop(v361_9);
    let v361_14: Space = if (v361_10).is_empty() { Space::new() } else {
      let v363_6: Path = concat_path(&(*p0),&(v360_7_head));
      let v363_11: Space = unwrap(&(v360_7_tail),&(*p1));
      let v363_12: Space = wrap(&(v363_11),&(v363_6));
      drop(v363_6);
      drop(v363_11);
      let v363_13: Space = compose(&(v363_12),&(*s1));
      drop(v363_12);
      compose(&(v361_10),&(v363_13))
    };
    drop(v361_10);
    let v361_15: Space = unite(&(v361_8),&(v361_14));
    drop(v361_14);
    v360_7.join_into((v361_15).clone());
    }
    v360_7_cursor.ascend(1);
  }
  drop(v360_7_cursor);
  (v360_7).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v364_12 = Space::new();
  let mut v364_12_cursor = (*s0).read_zipper();
  for v364_12_byte in v364_12_cursor.child_mask().iter() {
    v364_12_cursor.descend_to_byte(v364_12_byte);
    {
    let v364_12_tail = v364_12_cursor.fork_read_zipper();
    let v364_12_head = Path::from_slice(&[v364_12_byte]);
    let v365_2: Space = singleton(&(v364_12_head));
    let v365_3: Space = intersect(&(*CONSTANT_7),&(v365_2));
    let v365_4: Space = if has_head(&(v365_3)) { singleton(&[]) } else { Space::new() };
    drop(v365_3);
    let v365_5: Space = subtract(&(*CONSTANT_0),&(v365_4));
    drop(v365_4);
    let v365_8: Space = if (v365_5).is_empty() { Space::new() } else {
      let v366_6: Path = concat_path(&(*p0),&(v364_12_head));
      let v366_7: Space = routine_30(c, &(v366_6), &(v364_12_tail).make_space());
      compose(&(v365_5),&(v366_7))
    };
    drop(v365_5);
    let v365_9: Space = intersect(&(*CONSTANT_7),&(v365_2));
    drop(v365_2);
    let v365_10: Space = if has_head(&(v365_9)) { singleton(&[]) } else { Space::new() };
    drop(v365_9);
    let v365_12: Space = if (v365_10).is_empty() { Space::new() } else {
      let v367_6: Path = concat_path(&(*p0),&(v364_12_head));
      let mut v367_11 = Space::new();
      let mut v367_11_cursor = (v364_12_tail).read_zipper();
      for v367_11_byte in v367_11_cursor.child_mask().iter() {
        v367_11_cursor.descend_to_byte(v367_11_byte);
        {
        let v367_11_tail = v367_11_cursor.fork_read_zipper();
        let v367_11_head = Path::from_slice(&[v367_11_byte]);
        let v368_2: Space = singleton(&(v367_11_head));
        let v368_3: Space = intersect(&(*CONSTANT_7),&(v368_2));
        let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
        drop(v368_3);
        let v368_5: Space = subtract(&(*CONSTANT_0),&(v368_4));
        drop(v368_4);
        let v368_7: Space = if (v368_5).is_empty() { Space::new() } else {
          let v369_6: Space = routine_43(c, &(v367_11_head), &(v367_6), &(v367_11_tail).make_space());
          compose(&(v368_5),&(v369_6))
        };
        drop(v368_5);
        let v368_8: Space = intersect(&(*CONSTANT_7),&(v368_2));
        drop(v368_2);
        let v368_9: Space = if has_head(&(v368_8)) { singleton(&[]) } else { Space::new() };
        drop(v368_8);
        let v368_13: Space = if (v368_9).is_empty() { Space::new() } else {
          let mut v370_10 = Space::new();
          let mut v370_10_cursor = (v367_11_tail).read_zipper();
          for v370_10_byte in v370_10_cursor.child_mask().iter() {
            v370_10_cursor.descend_to_byte(v370_10_byte);
            {
            let v370_10_tail = v370_10_cursor.fork_read_zipper();
            let v370_10_head = Path::from_slice(&[v370_10_byte]);
            let v371_2: Space = singleton(&(v370_10_head));
            let v371_3: Space = intersect(&(*CONSTANT_7),&(v371_2));
            let v371_4: Space = if has_head(&(v371_3)) { singleton(&[]) } else { Space::new() };
            drop(v371_3);
            let v371_5: Space = subtract(&(*CONSTANT_0),&(v371_4));
            drop(v371_4);
            let v371_7: Space = if (v371_5).is_empty() { Space::new() } else {
              let v372_6: Space = routine_44(c, &(v370_10_head), &(v370_10_tail).make_space());
              compose(&(v371_5),&(v372_6))
            };
            drop(v371_5);
            let v371_8: Space = intersect(&(*CONSTANT_7),&(v371_2));
            drop(v371_2);
            let v371_9: Space = if has_head(&(v371_8)) { singleton(&[]) } else { Space::new() };
            drop(v371_8);
            let v371_11: Space = if (v371_9).is_empty() { Space::new() } else {
              let v373_10: Space = routine_45(c, &(v370_10_head), &(v370_10_tail).make_space());
              compose(&(v371_9),&(v373_10))
            };
            drop(v371_9);
            let v371_12: Space = unite(&(v371_7),&(v371_11));
            v370_10.join_into((v371_12).clone());
            }
            v370_10_cursor.ascend(1);
          }
          drop(v370_10_cursor);
          let v370_11: Space = raffine(&(*CONSTANT_28),&(v370_10));
          let v370_12: Space = unite(&(v370_11),&(v367_11_tail));
          compose(&(v368_9),&(v370_12))
        };
        drop(v368_9);
        let v368_14: Path = concat_path(&(v367_6),&(v367_11_head));
        let v368_15: Space = wrap(&(v368_13),&(v368_14));
        drop(v368_14);
        let v368_16: Space = unite(&(v368_7),&(v368_15));
        v367_11.join_into((v368_16).clone());
        }
        v367_11_cursor.ascend(1);
      }
      drop(v367_11_cursor);
      drop(v367_6);
      compose(&(v365_10),&(v367_11))
    };
    drop(v365_10);
    let v365_13: Space = unite(&(v365_8),&(v365_12));
    v364_12.join_into((v365_13).clone());
    }
    v364_12_cursor.ascend(1);
  }
  drop(v364_12_cursor);
  (v364_12).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v374_8: Space = unwrap(&(*s1),&(*CONSTANT_16));
  let v374_11: Space = if (v374_8).is_empty() { Space::new() } else {
    let v375_10: Space = unwrap(&(*s1),&(*CONSTANT_17));
    compose(&(v374_8),&(v375_10))
  };
  let v374_14: Space = if (v374_11).is_empty() { Space::new() } else {
    let v376_13: Space = unwrap(&(*s1),&(*CONSTANT_18));
    compose(&(v374_11),&(v376_13))
  };
  let v374_18: Space = if (v374_11).is_empty() { Space::new() } else {
    let v377_17: Space = unwrap(&(*s1),&(*CONSTANT_19));
    compose(&(v374_11),&(v377_17))
  };
  drop(v374_11);
  let v378_10: Space = unwrap(&(*s1),&(*CONSTANT_17));
  let v374_20: Space = if (v378_10).is_empty() { Space::new() } else {
    let v379_17: Space = unwrap(&(*s1),&(*CONSTANT_19));
    compose(&(v378_10),&(v379_17))
  };
  let v374_21: Space = if (v374_20).is_empty() { Space::new() } else {
    let v380_13: Space = unwrap(&(*s1),&(*CONSTANT_18));
    compose(&(v374_20),&(v380_13))
  };
  drop(v374_20);
  let v374_23: Space = if (v374_8).is_empty() { Space::new() } else {
    let v381_17: Space = unwrap(&(*s1),&(*CONSTANT_19));
    compose(&(v374_8),&(v381_17))
  };
  drop(v374_8);
  let v374_24: Space = if (v374_23).is_empty() { Space::new() } else {
    let v382_13: Space = unwrap(&(*s1),&(*CONSTANT_18));
    compose(&(v374_23),&(v382_13))
  };
  drop(v374_23);
  let mut v374_25 = Space::new();
  let mut v374_25_cursor = (*s0).read_zipper();
  for v374_25_byte in v374_25_cursor.child_mask().iter() {
    v374_25_cursor.descend_to_byte(v374_25_byte);
    {
    let v374_25_tail = v374_25_cursor.fork_read_zipper();
    let v374_25_head = Path::from_slice(&[v374_25_byte]);
    let v383_2: Space = singleton(&(v374_25_head));
    let v383_3: Space = intersect(&(*CONSTANT_7),&(v383_2));
    let v383_4: Space = if has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
    drop(v383_3);
    let v383_5: Space = subtract(&(*CONSTANT_0),&(v383_4));
    drop(v383_4);
    let v383_8: Space = if (v383_5).is_empty() { Space::new() } else {
      let v384_6: Path = concat_path(&(*p0),&(v374_25_head));
      let v384_7: Space = routine_31(c, &(v384_6), &(v374_25_tail).make_space(), &(*s1));
      compose(&(v383_5),&(v384_7))
    };
    drop(v383_5);
    let v383_9: Space = intersect(&(*CONSTANT_7),&(v383_2));
    drop(v383_2);
    let v383_10: Space = if has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
    drop(v383_9);
    let v383_23: Space = if (v383_10).is_empty() { Space::new() } else {
      let v385_6: Path = concat_path(&(*p0),&(v374_25_head));
      let v385_11: Space = singleton(&(v385_6));
      drop(v385_6);
      let v385_12: Space = intersect(&(*CONSTANT_8),&(v385_11));
      let v385_13: Space = compose(&(v385_12),&(v374_14));
      drop(v385_12);
      let v385_14: Space = intersect(&(*CONSTANT_9),&(v385_11));
      let v385_15: Space = compose(&(v385_14),&(v374_18));
      drop(v385_14);
      let v385_16: Space = unite(&(v385_13),&(v385_15));
      drop(v385_13);
      drop(v385_15);
      let v385_17: Space = intersect(&(*CONSTANT_10),&(v385_11));
      let v385_18: Space = compose(&(v385_17),&(v374_21));
      drop(v385_17);
      let v385_19: Space = unite(&(v385_16),&(v385_18));
      drop(v385_16);
      drop(v385_18);
      let v385_20: Space = intersect(&(*CONSTANT_11),&(v385_11));
      drop(v385_11);
      let v385_21: Space = compose(&(v385_20),&(v374_24));
      drop(v385_20);
      let v385_22: Space = unite(&(v385_19),&(v385_21));
      drop(v385_19);
      drop(v385_21);
      compose(&(v383_10),&(v385_22))
    };
    drop(v383_10);
    let v383_24: Space = unite(&(v383_8),&(v383_23));
    drop(v383_23);
    v374_25.join_into((v383_24).clone());
    }
    v374_25_cursor.ascend(1);
  }
  drop(v374_25_cursor);
  drop(v374_14);
  drop(v374_18);
  drop(v374_21);
  drop(v374_24);
  (v374_25).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v386_10: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v386_11: Space = singleton(&(v386_10));
  drop(v386_10);
  let v386_13: Path = concat_path(&(*CONSTANT_17),&(*p2));
  let v386_14: Space = singleton(&(v386_13));
  drop(v386_13);
  let mut v386_15 = Space::new();
  let mut v386_15_cursor = (*s0).read_zipper();
  for v386_15_byte in v386_15_cursor.child_mask().iter() {
    v386_15_cursor.descend_to_byte(v386_15_byte);
    {
    let v386_15_tail = v386_15_cursor.fork_read_zipper();
    let v386_15_head = Path::from_slice(&[v386_15_byte]);
    let v387_2: Space = singleton(&(v386_15_head));
    let v387_3: Space = intersect(&(*CONSTANT_7),&(v387_2));
    let v387_4: Space = if has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
    drop(v387_3);
    let v387_5: Space = subtract(&(*CONSTANT_0),&(v387_4));
    drop(v387_4);
    let v387_8: Space = if (v387_5).is_empty() { Space::new() } else {
      let v388_6: Path = concat_path(&(*p0),&(v386_15_head));
      let v388_7: Space = routine_32(c, &(v388_6), &(*p1), &(*p2), &(v386_15_tail).make_space());
      compose(&(v387_5),&(v388_7))
    };
    drop(v387_5);
    let v387_9: Space = intersect(&(*CONSTANT_7),&(v387_2));
    drop(v387_2);
    let v387_10: Space = if has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
    drop(v387_9);
    let v387_16: Space = if (v387_10).is_empty() { Space::new() } else {
      let v389_6: Path = concat_path(&(*p0),&(v386_15_head));
      let v389_11: Path = concat_path(&(*CONSTANT_18),&(v389_6));
      drop(v389_6);
      let v389_12: Space = singleton(&(v389_11));
      drop(v389_11);
      let v389_13: Space = unite(&(*CONSTANT_24),&(v389_12));
      drop(v389_12);
      let v389_14: Space = unite(&(v389_13),&(v386_11));
      drop(v389_13);
      let v389_15: Space = unite(&(v389_14),&(v386_14));
      drop(v389_14);
      compose(&(v387_10),&(v389_15))
    };
    drop(v387_10);
    let v387_17: Space = unite(&(v387_8),&(v387_16));
    drop(v387_16);
    v386_15.join_into((v387_17).clone());
    }
    v386_15_cursor.ascend(1);
  }
  drop(v386_15_cursor);
  drop(v386_11);
  drop(v386_14);
  (v386_15).clone()
}

fn routine_33(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v390_6: Path = concat_path(&(*CONSTANT_18),&(*p0));
  let v390_7: Space = singleton(&(v390_6));
  drop(v390_6);
  let v390_8: Space = unite(&(*CONSTANT_24),&(v390_7));
  drop(v390_7);
  let v390_10: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v390_11: Space = singleton(&(v390_10));
  drop(v390_10);
  let v390_12: Space = unite(&(v390_8),&(v390_11));
  drop(v390_8);
  drop(v390_11);
  let v390_14: Path = concat_path(&(*CONSTANT_17),&(*p2));
  let v390_15: Space = singleton(&(v390_14));
  drop(v390_14);
  let v390_16: Space = unite(&(v390_12),&(v390_15));
  drop(v390_12);
  drop(v390_15);
  (v390_16).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v391_10: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v391_11: Space = singleton(&(v391_10));
  drop(v391_10);
  let v391_13: Path = concat_path(&(*CONSTANT_17),&(*p2));
  let v391_14: Space = singleton(&(v391_13));
  drop(v391_13);
  let mut v391_15 = Space::new();
  let mut v391_15_cursor = (*s0).read_zipper();
  for v391_15_byte in v391_15_cursor.child_mask().iter() {
    v391_15_cursor.descend_to_byte(v391_15_byte);
    {
    let v391_15_tail = v391_15_cursor.fork_read_zipper();
    let v391_15_head = Path::from_slice(&[v391_15_byte]);
    let v392_2: Space = singleton(&(v391_15_head));
    let v392_3: Space = intersect(&(*CONSTANT_7),&(v392_2));
    let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
    drop(v392_3);
    let v392_5: Space = subtract(&(*CONSTANT_0),&(v392_4));
    drop(v392_4);
    let v392_8: Space = if (v392_5).is_empty() { Space::new() } else {
      let v393_6: Path = concat_path(&(*p0),&(v391_15_head));
      let v393_7: Space = routine_34(c, &(v393_6), &(*p1), &(*p2), &(v391_15_tail).make_space());
      compose(&(v392_5),&(v393_7))
    };
    drop(v392_5);
    let v392_9: Space = intersect(&(*CONSTANT_7),&(v392_2));
    drop(v392_2);
    let v392_10: Space = if has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
    drop(v392_9);
    let v392_16: Space = if (v392_10).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&(v391_15_head));
      let v394_11: Path = concat_path(&(*CONSTANT_19),&(v394_6));
      drop(v394_6);
      let v394_12: Space = singleton(&(v394_11));
      drop(v394_11);
      let v394_13: Space = unite(&(*CONSTANT_25),&(v394_12));
      drop(v394_12);
      let v394_14: Space = unite(&(v394_13),&(v391_11));
      drop(v394_13);
      let v394_15: Space = unite(&(v394_14),&(v391_14));
      drop(v394_14);
      compose(&(v392_10),&(v394_15))
    };
    drop(v392_10);
    let v392_17: Space = unite(&(v392_8),&(v392_16));
    drop(v392_16);
    v391_15.join_into((v392_17).clone());
    }
    v391_15_cursor.ascend(1);
  }
  drop(v391_15_cursor);
  drop(v391_11);
  drop(v391_14);
  (v391_15).clone()
}

fn routine_35(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v395_6: Path = concat_path(&(*CONSTANT_19),&(*p0));
  let v395_7: Space = singleton(&(v395_6));
  drop(v395_6);
  let v395_8: Space = unite(&(*CONSTANT_25),&(v395_7));
  drop(v395_7);
  let v395_10: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v395_11: Space = singleton(&(v395_10));
  drop(v395_10);
  let v395_12: Space = unite(&(v395_8),&(v395_11));
  drop(v395_8);
  drop(v395_11);
  let v395_14: Path = concat_path(&(*CONSTANT_17),&(*p2));
  let v395_15: Space = singleton(&(v395_14));
  drop(v395_14);
  let v395_16: Space = unite(&(v395_12),&(v395_15));
  drop(v395_12);
  drop(v395_15);
  (v395_16).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v396_9: Path = concat_path(&(*CONSTANT_19),&(*p2));
  let v396_10: Space = singleton(&(v396_9));
  drop(v396_9);
  let v396_11: Space = unite(&(*CONSTANT_26),&(v396_10));
  drop(v396_10);
  let v396_14: Path = concat_path(&(*CONSTANT_17),&(*p1));
  let v396_15: Space = singleton(&(v396_14));
  drop(v396_14);
  let mut v396_16 = Space::new();
  let mut v396_16_cursor = (*s0).read_zipper();
  for v396_16_byte in v396_16_cursor.child_mask().iter() {
    v396_16_cursor.descend_to_byte(v396_16_byte);
    {
    let v396_16_tail = v396_16_cursor.fork_read_zipper();
    let v396_16_head = Path::from_slice(&[v396_16_byte]);
    let v397_2: Space = singleton(&(v396_16_head));
    let v397_3: Space = intersect(&(*CONSTANT_7),&(v397_2));
    let v397_4: Space = if has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
    drop(v397_3);
    let v397_5: Space = subtract(&(*CONSTANT_0),&(v397_4));
    drop(v397_4);
    let v397_8: Space = if (v397_5).is_empty() { Space::new() } else {
      let v398_6: Path = concat_path(&(*p0),&(v396_16_head));
      let v398_7: Space = routine_36(c, &(v398_6), &(*p1), &(*p2), &(v396_16_tail).make_space());
      compose(&(v397_5),&(v398_7))
    };
    drop(v397_5);
    let v397_9: Space = intersect(&(*CONSTANT_7),&(v397_2));
    drop(v397_2);
    let v397_10: Space = if has_head(&(v397_9)) { singleton(&[]) } else { Space::new() };
    drop(v397_9);
    let v397_15: Space = if (v397_10).is_empty() { Space::new() } else {
      let v399_6: Path = concat_path(&(*p0),&(v396_16_head));
      let v399_11: Path = concat_path(&(*CONSTANT_18),&(v399_6));
      drop(v399_6);
      let v399_12: Space = singleton(&(v399_11));
      drop(v399_11);
      let v399_13: Space = unite(&(v396_11),&(v399_12));
      drop(v399_12);
      let v399_14: Space = unite(&(v399_13),&(v396_15));
      drop(v399_13);
      compose(&(v397_10),&(v399_14))
    };
    drop(v397_10);
    let v397_16: Space = unite(&(v397_8),&(v397_15));
    drop(v397_15);
    v396_16.join_into((v397_16).clone());
    }
    v396_16_cursor.ascend(1);
  }
  drop(v396_16_cursor);
  drop(v396_11);
  drop(v396_15);
  (v396_16).clone()
}

fn routine_37(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v400_6: Path = concat_path(&(*CONSTANT_19),&(*p2));
  let v400_7: Space = singleton(&(v400_6));
  drop(v400_6);
  let v400_8: Space = unite(&(*CONSTANT_26),&(v400_7));
  drop(v400_7);
  let v400_10: Path = concat_path(&(*CONSTANT_18),&(*p0));
  let v400_11: Space = singleton(&(v400_10));
  drop(v400_10);
  let v400_12: Space = unite(&(v400_8),&(v400_11));
  drop(v400_8);
  drop(v400_11);
  let v400_14: Path = concat_path(&(*CONSTANT_17),&(*p1));
  let v400_15: Space = singleton(&(v400_14));
  drop(v400_14);
  let v400_16: Space = unite(&(v400_12),&(v400_15));
  drop(v400_12);
  drop(v400_15);
  (v400_16).clone()
}

fn routine_38(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v401_9: Path = concat_path(&(*CONSTANT_19),&(*p2));
  let v401_10: Space = singleton(&(v401_9));
  drop(v401_9);
  let v401_11: Space = unite(&(*CONSTANT_27),&(v401_10));
  drop(v401_10);
  let v401_14: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v401_15: Space = singleton(&(v401_14));
  drop(v401_14);
  let mut v401_16 = Space::new();
  let mut v401_16_cursor = (*s0).read_zipper();
  for v401_16_byte in v401_16_cursor.child_mask().iter() {
    v401_16_cursor.descend_to_byte(v401_16_byte);
    {
    let v401_16_tail = v401_16_cursor.fork_read_zipper();
    let v401_16_head = Path::from_slice(&[v401_16_byte]);
    let v402_2: Space = singleton(&(v401_16_head));
    let v402_3: Space = intersect(&(*CONSTANT_7),&(v402_2));
    let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
    drop(v402_3);
    let v402_5: Space = subtract(&(*CONSTANT_0),&(v402_4));
    drop(v402_4);
    let v402_8: Space = if (v402_5).is_empty() { Space::new() } else {
      let v403_6: Path = concat_path(&(*p0),&(v401_16_head));
      let v403_7: Space = routine_38(c, &(v403_6), &(*p1), &(*p2), &(v401_16_tail).make_space());
      compose(&(v402_5),&(v403_7))
    };
    drop(v402_5);
    let v402_9: Space = intersect(&(*CONSTANT_7),&(v402_2));
    drop(v402_2);
    let v402_10: Space = if has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
    drop(v402_9);
    let v402_15: Space = if (v402_10).is_empty() { Space::new() } else {
      let v404_6: Path = concat_path(&(*p0),&(v401_16_head));
      let v404_11: Path = concat_path(&(*CONSTANT_18),&(v404_6));
      drop(v404_6);
      let v404_12: Space = singleton(&(v404_11));
      drop(v404_11);
      let v404_13: Space = unite(&(v401_11),&(v404_12));
      drop(v404_12);
      let v404_14: Space = unite(&(v404_13),&(v401_15));
      drop(v404_13);
      compose(&(v402_10),&(v404_14))
    };
    drop(v402_10);
    let v402_16: Space = unite(&(v402_8),&(v402_15));
    drop(v402_15);
    v401_16.join_into((v402_16).clone());
    }
    v401_16_cursor.ascend(1);
  }
  drop(v401_16_cursor);
  drop(v401_11);
  drop(v401_15);
  (v401_16).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v405_6: Path = concat_path(&(*CONSTANT_19),&(*p2));
  let v405_7: Space = singleton(&(v405_6));
  drop(v405_6);
  let v405_8: Space = unite(&(*CONSTANT_27),&(v405_7));
  drop(v405_7);
  let v405_10: Path = concat_path(&(*CONSTANT_18),&(*p0));
  let v405_11: Space = singleton(&(v405_10));
  drop(v405_10);
  let v405_12: Space = unite(&(v405_8),&(v405_11));
  drop(v405_8);
  drop(v405_11);
  let v405_14: Path = concat_path(&(*CONSTANT_16),&(*p1));
  let v405_15: Space = singleton(&(v405_14));
  drop(v405_14);
  let v405_16: Space = unite(&(v405_12),&(v405_15));
  drop(v405_12);
  drop(v405_15);
  (v405_16).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v406_10 = Space::new();
  let mut v406_10_cursor = (*s0).read_zipper();
  for v406_10_byte in v406_10_cursor.child_mask().iter() {
    v406_10_cursor.descend_to_byte(v406_10_byte);
    {
    let v406_10_tail = v406_10_cursor.fork_read_zipper();
    let v406_10_head = Path::from_slice(&[v406_10_byte]);
    let v407_2: Space = singleton(&(v406_10_head));
    let v407_3: Space = intersect(&(*CONSTANT_7),&(v407_2));
    let v407_4: Space = if has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
    drop(v407_3);
    let v407_5: Space = subtract(&(*CONSTANT_0),&(v407_4));
    drop(v407_4);
    let v407_8: Space = if (v407_5).is_empty() { Space::new() } else {
      let v408_6: Path = concat_path(&(*p0),&(v406_10_head));
      let v408_7: Space = routine_40(c, &(v408_6), &(*p1), &(v406_10_tail).make_space());
      compose(&(v407_5),&(v408_7))
    };
    drop(v407_5);
    let v407_9: Space = intersect(&(*CONSTANT_7),&(v407_2));
    drop(v407_2);
    let v407_10: Space = if has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
    drop(v407_9);
    let v407_14: Space = if (v407_10).is_empty() { Space::new() } else {
      let mut v409_11 = Space::new();
      let mut v409_11_cursor = (v406_10_tail).read_zipper();
      for v409_11_byte in v409_11_cursor.child_mask().iter() {
        v409_11_cursor.descend_to_byte(v409_11_byte);
        {
        let v409_11_tail = v409_11_cursor.fork_read_zipper();
        let v409_11_head = Path::from_slice(&[v409_11_byte]);
        let v410_2: Space = singleton(&(v409_11_head));
        let v410_3: Space = intersect(&(*CONSTANT_7),&(v410_2));
        let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
        drop(v410_3);
        let v410_5: Space = subtract(&(*CONSTANT_0),&(v410_4));
        drop(v410_4);
        let v410_7: Space = if (v410_5).is_empty() { Space::new() } else {
          let v411_6: Space = routine_41(c, &(v409_11_head), &(v409_11_tail).make_space());
          compose(&(v410_5),&(v411_6))
        };
        drop(v410_5);
        let v410_8: Space = intersect(&(*CONSTANT_7),&(v410_2));
        let v410_9: Space = if has_head(&(v410_8)) { singleton(&[]) } else { Space::new() };
        drop(v410_8);
        let v410_10: Space = compose(&(v410_9),&(v410_2));
        drop(v410_2);
        drop(v410_9);
        let v410_11: Space = unite(&(v410_7),&(v410_10));
        drop(v410_10);
        v409_11.join_into((v410_11).clone());
        }
        v409_11_cursor.ascend(1);
      }
      drop(v409_11_cursor);
      let v409_12: Space = raffine(&(*CONSTANT_28),&(v409_11));
      let v409_13: Space = unite(&(v409_12),&(v406_10_tail));
      compose(&(v407_10),&(v409_13))
    };
    drop(v407_10);
    let v412_6: Path = concat_path(&(*p0),&(v406_10_head));
    let v407_15: Path = concat_path(&(*p1),&(v412_6));
    let v407_16: Space = wrap(&(v407_14),&(v407_15));
    drop(v407_15);
    let v407_17: Space = unite(&(v407_8),&(v407_16));
    v406_10.join_into((v407_17).clone());
    }
    v406_10_cursor.ascend(1);
  }
  drop(v406_10_cursor);
  (v406_10).clone()
}

fn routine_41(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v413_5 = Space::new();
  let mut v413_5_cursor = (*s0).read_zipper();
  for v413_5_byte in v413_5_cursor.child_mask().iter() {
    v413_5_cursor.descend_to_byte(v413_5_byte);
    {
    let v413_5_tail = v413_5_cursor.fork_read_zipper();
    let v413_5_head = Path::from_slice(&[v413_5_byte]);
    let v414_2: Space = singleton(&(v413_5_head));
    let v414_3: Space = intersect(&(*CONSTANT_7),&(v414_2));
    let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
    drop(v414_3);
    let v414_5: Space = subtract(&(*CONSTANT_0),&(v414_4));
    drop(v414_4);
    let v414_8: Space = if (v414_5).is_empty() { Space::new() } else {
      let v415_6: Path = concat_path(&(*p0),&(v413_5_head));
      let v415_7: Space = routine_41(c, &(v415_6), &(v413_5_tail).make_space());
      compose(&(v414_5),&(v415_7))
    };
    drop(v414_5);
    let v414_9: Space = intersect(&(*CONSTANT_7),&(v414_2));
    drop(v414_2);
    let v414_10: Space = if has_head(&(v414_9)) { singleton(&[]) } else { Space::new() };
    drop(v414_9);
    let v414_12: Space = if (v414_10).is_empty() { Space::new() } else {
      let v416_6: Path = concat_path(&(*p0),&(v413_5_head));
      let v416_11: Space = singleton(&(v416_6));
      drop(v416_6);
      compose(&(v414_10),&(v416_11))
    };
    drop(v414_10);
    let v414_13: Space = unite(&(v414_8),&(v414_12));
    drop(v414_12);
    v413_5.join_into((v414_13).clone());
    }
    v413_5_cursor.ascend(1);
  }
  drop(v413_5_cursor);
  (v413_5).clone()
}

fn routine_42(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v417_2: Space = singleton(&(*p0));
  (v417_2).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v418_10 = Space::new();
  let mut v418_10_cursor = (*s0).read_zipper();
  for v418_10_byte in v418_10_cursor.child_mask().iter() {
    v418_10_cursor.descend_to_byte(v418_10_byte);
    {
    let v418_10_tail = v418_10_cursor.fork_read_zipper();
    let v418_10_head = Path::from_slice(&[v418_10_byte]);
    let v419_2: Space = singleton(&(v418_10_head));
    let v419_3: Space = intersect(&(*CONSTANT_7),&(v419_2));
    let v419_4: Space = if has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
    drop(v419_3);
    let v419_5: Space = subtract(&(*CONSTANT_0),&(v419_4));
    drop(v419_4);
    let v419_8: Space = if (v419_5).is_empty() { Space::new() } else {
      let v420_6: Path = concat_path(&(*p0),&(v418_10_head));
      let v420_7: Space = routine_43(c, &(v420_6), &(*p1), &(v418_10_tail).make_space());
      compose(&(v419_5),&(v420_7))
    };
    drop(v419_5);
    let v419_9: Space = intersect(&(*CONSTANT_7),&(v419_2));
    drop(v419_2);
    let v419_10: Space = if has_head(&(v419_9)) { singleton(&[]) } else { Space::new() };
    drop(v419_9);
    let v419_14: Space = if (v419_10).is_empty() { Space::new() } else {
      let mut v421_11 = Space::new();
      let mut v421_11_cursor = (v418_10_tail).read_zipper();
      for v421_11_byte in v421_11_cursor.child_mask().iter() {
        v421_11_cursor.descend_to_byte(v421_11_byte);
        {
        let v421_11_tail = v421_11_cursor.fork_read_zipper();
        let v421_11_head = Path::from_slice(&[v421_11_byte]);
        let v422_2: Space = singleton(&(v421_11_head));
        let v422_3: Space = intersect(&(*CONSTANT_7),&(v422_2));
        let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
        drop(v422_3);
        let v422_5: Space = subtract(&(*CONSTANT_0),&(v422_4));
        drop(v422_4);
        let v422_7: Space = if (v422_5).is_empty() { Space::new() } else {
          let v423_6: Space = routine_44(c, &(v421_11_head), &(v421_11_tail).make_space());
          compose(&(v422_5),&(v423_6))
        };
        drop(v422_5);
        let v422_8: Space = intersect(&(*CONSTANT_7),&(v422_2));
        let v422_9: Space = if has_head(&(v422_8)) { singleton(&[]) } else { Space::new() };
        drop(v422_8);
        let v422_10: Space = compose(&(v422_9),&(v422_2));
        drop(v422_2);
        drop(v422_9);
        let v422_11: Space = unite(&(v422_7),&(v422_10));
        drop(v422_10);
        v421_11.join_into((v422_11).clone());
        }
        v421_11_cursor.ascend(1);
      }
      drop(v421_11_cursor);
      let v421_12: Space = raffine(&(*CONSTANT_28),&(v421_11));
      let v421_13: Space = unite(&(v421_12),&(v418_10_tail));
      compose(&(v419_10),&(v421_13))
    };
    drop(v419_10);
    let v424_6: Path = concat_path(&(*p0),&(v418_10_head));
    let v419_15: Path = concat_path(&(*p1),&(v424_6));
    let v419_16: Space = wrap(&(v419_14),&(v419_15));
    drop(v419_15);
    let v419_17: Space = unite(&(v419_8),&(v419_16));
    v418_10.join_into((v419_17).clone());
    }
    v418_10_cursor.ascend(1);
  }
  drop(v418_10_cursor);
  (v418_10).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v425_5 = Space::new();
  let mut v425_5_cursor = (*s0).read_zipper();
  for v425_5_byte in v425_5_cursor.child_mask().iter() {
    v425_5_cursor.descend_to_byte(v425_5_byte);
    {
    let v425_5_tail = v425_5_cursor.fork_read_zipper();
    let v425_5_head = Path::from_slice(&[v425_5_byte]);
    let v426_2: Space = singleton(&(v425_5_head));
    let v426_3: Space = intersect(&(*CONSTANT_7),&(v426_2));
    let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
    drop(v426_3);
    let v426_5: Space = subtract(&(*CONSTANT_0),&(v426_4));
    drop(v426_4);
    let v426_8: Space = if (v426_5).is_empty() { Space::new() } else {
      let v427_6: Path = concat_path(&(*p0),&(v425_5_head));
      let v427_7: Space = routine_44(c, &(v427_6), &(v425_5_tail).make_space());
      compose(&(v426_5),&(v427_7))
    };
    drop(v426_5);
    let v426_9: Space = intersect(&(*CONSTANT_7),&(v426_2));
    drop(v426_2);
    let v426_10: Space = if has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
    drop(v426_9);
    let v426_12: Space = if (v426_10).is_empty() { Space::new() } else {
      let v428_6: Path = concat_path(&(*p0),&(v425_5_head));
      let v428_11: Space = singleton(&(v428_6));
      drop(v428_6);
      compose(&(v426_10),&(v428_11))
    };
    drop(v426_10);
    let v426_13: Space = unite(&(v426_8),&(v426_12));
    drop(v426_12);
    v425_5.join_into((v426_13).clone());
    }
    v425_5_cursor.ascend(1);
  }
  drop(v425_5_cursor);
  (v425_5).clone()
}

fn routine_45(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v429_2: Space = singleton(&(*p0));
  (v429_2).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
