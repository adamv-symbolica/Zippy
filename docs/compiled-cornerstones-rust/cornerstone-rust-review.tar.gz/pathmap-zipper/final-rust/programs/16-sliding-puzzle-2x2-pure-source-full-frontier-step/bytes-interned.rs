#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 2 0 0 0 3"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 3 0 0 0 2"));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,6]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 3 0 0 0 1"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 1 0 0 0 3"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_11: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 1 0 0 0 2"));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 2 0 0 0 1"));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 0"));
static CONSTANT_14: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 4"));
static CONSTANT_15: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 5"));
static CONSTANT_16: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 4 0 0 0 6"));
static CONSTANT_17: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 8 0 0 0 0 0 0 0 4 12 0 0 0 8 0 0 0 4 0 0 0 0 12 0 0 0 10 0 0 0 0 0 0 0 5 12 0 0 0 10 0 0 0 5 0 0 0 0"));
static CONSTANT_18: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 9 0 0 0 0 0 0 0 4 12 0 0 0 9 0 0 0 4 0 0 0 0 12 0 0 0 10 0 0 0 4 0 0 0 6 12 0 0 0 10 0 0 0 6 0 0 0 4"));
static CONSTANT_19: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 7 0 0 0 0 0 0 0 5 12 0 0 0 7 0 0 0 5 0 0 0 0 12 0 0 0 8 0 0 0 5 0 0 0 6 12 0 0 0 8 0 0 0 6 0 0 0 5"));
static CONSTANT_20: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 12 0 0 0 7 0 0 0 4 0 0 0 6 12 0 0 0 7 0 0 0 6 0 0 0 4 12 0 0 0 9 0 0 0 5 0 0 0 6 12 0 0 0 9 0 0 0 6 0 0 0 5"));
static CONSTANT_21: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 8 0 0 0 0 0 0 0 0 8 0 0 0 4 0 0 0 4 8 0 0 0 5 0 0 0 5 8 0 0 0 6 0 0 0 6"));
static CONSTANT_22: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 0 0 0 0 11"));
static CONSTANT_23: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 4 0 0 0 11"));
static CONSTANT_24: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 5 0 0 0 11"));
static CONSTANT_25: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 8 0 0 0 6 0 0 0 11"));
fn routine_0(c: &mut Context) -> Space {
  let v0_3: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &(*CONSTANT_2));
  let v0_6: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_3), &(*CONSTANT_2));
  let v0_7: Space = unite(&(v0_3),&(v0_6));
  let v0_10: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_4), &(*CONSTANT_5));
  let v0_11: Space = unite(&(v0_7),&(v0_10));
  let v0_14: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_6), &(*CONSTANT_5));
  let v0_15: Space = unite(&(v0_11),&(v0_14));
  let v0_18: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_1), &(*CONSTANT_8));
  let v0_19: Space = unite(&(v0_15),&(v0_18));
  let v0_21: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_3), &(*CONSTANT_8));
  let v0_22: Space = unite(&(v0_19),&(v0_21));
  let v0_24: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_4), &(*CONSTANT_9));
  let v0_25: Space = unite(&(v0_22),&(v0_24));
  let v0_27: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_6), &(*CONSTANT_9));
  let v0_28: Space = unite(&(v0_25),&(v0_27));
  let v0_31: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_1), &(*CONSTANT_11));
  let v0_32: Space = unite(&(v0_28),&(v0_31));
  let v0_34: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_3), &(*CONSTANT_11));
  let v0_35: Space = unite(&(v0_32),&(v0_34));
  let v0_37: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_4), &(*CONSTANT_12));
  let v0_38: Space = unite(&(v0_35),&(v0_37));
  let v0_40: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_6), &(*CONSTANT_12));
  let v0_41: Space = unite(&(v0_38),&(v0_40));
  (v0_41).clone()
}

fn routine_1(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v1_3 = Space::new();
  let mut v1_3_cursor = (*s0).read_zipper();
  for v1_3_byte in v1_3_cursor.child_mask().iter() {
    v1_3_cursor.descend_to_byte(v1_3_byte);
    {
    let v1_3_tail = v1_3_cursor.fork_read_zipper();
    let v1_3_head = Path::from_slice(&[v1_3_byte]);
    let mut v2_2 = Space::new();
    let mut v2_2_cursor = (v1_3_tail).read_zipper();
    for v2_2_byte in v2_2_cursor.child_mask().iter() {
      v2_2_cursor.descend_to_byte(v2_2_byte);
      {
      let v2_2_tail = v2_2_cursor.fork_read_zipper();
      let v2_2_head = Path::from_slice(&[v2_2_byte]);
      let v3_2: Path = concat_path(&(v1_3_head),&(v2_2_head));
      let mut v3_3 = Space::new();
      let mut v3_3_cursor = (v2_2_tail).read_zipper();
      for v3_3_byte in v3_3_cursor.child_mask().iter() {
        v3_3_cursor.descend_to_byte(v3_3_byte);
        {
        let v3_3_tail = v3_3_cursor.fork_read_zipper();
        let v3_3_head = Path::from_slice(&[v3_3_byte]);
        let v4_2: Path = concat_path(&(v3_2),&(v3_3_head));
        let mut v4_3 = Space::new();
        let mut v4_3_cursor = (v3_3_tail).read_zipper();
        for v4_3_byte in v4_3_cursor.child_mask().iter() {
          v4_3_cursor.descend_to_byte(v4_3_byte);
          {
          let v4_3_tail = v4_3_cursor.fork_read_zipper();
          let v4_3_head = Path::from_slice(&[v4_3_byte]);
          let v5_2: Path = concat_path(&(v4_2),&(v4_3_head));
          let mut v5_3 = Space::new();
          let mut v5_3_cursor = (v4_3_tail).read_zipper();
          for v5_3_byte in v5_3_cursor.child_mask().iter() {
            v5_3_cursor.descend_to_byte(v5_3_byte);
            {
            let v5_3_tail = v5_3_cursor.fork_read_zipper();
            let v5_3_head = Path::from_slice(&[v5_3_byte]);
            let mut v6_2 = Space::new();
            let mut v6_2_cursor = (v5_3_tail).read_zipper();
            for v6_2_byte in v6_2_cursor.child_mask().iter() {
              v6_2_cursor.descend_to_byte(v6_2_byte);
              {
              let v6_2_tail = v6_2_cursor.fork_read_zipper();
              let v6_2_head = Path::from_slice(&[v6_2_byte]);
              let v7_2: Path = concat_path(&(v5_3_head),&(v6_2_head));
              let mut v7_3 = Space::new();
              let mut v7_3_cursor = (v6_2_tail).read_zipper();
              for v7_3_byte in v7_3_cursor.child_mask().iter() {
                v7_3_cursor.descend_to_byte(v7_3_byte);
                {
                let v7_3_tail = v7_3_cursor.fork_read_zipper();
                let v7_3_head = Path::from_slice(&[v7_3_byte]);
                let v8_2: Path = concat_path(&(v7_2),&(v7_3_head));
                let mut v8_3 = Space::new();
                let mut v8_3_cursor = (v7_3_tail).read_zipper();
                for v8_3_byte in v8_3_cursor.child_mask().iter() {
                  v8_3_cursor.descend_to_byte(v8_3_byte);
                  {
                  let v8_3_tail = v8_3_cursor.fork_read_zipper();
                  let v8_3_head = Path::from_slice(&[v8_3_byte]);
                  let v9_2: Path = concat_path(&(v8_2),&(v8_3_head));
                  let v9_3: Space = routine_2(c, &(v9_2), &(*p1), &(*p0), &(v5_2), &(v8_3_tail).make_space());
                  drop(v9_2);
                  v8_3.join_into((v9_3).clone());
                  }
                  v8_3_cursor.ascend(1);
                }
                drop(v8_3_cursor);
                drop(v8_2);
                v7_3.join_into((v8_3).clone());
                }
                v7_3_cursor.ascend(1);
              }
              drop(v7_3_cursor);
              drop(v7_2);
              v6_2.join_into((v7_3).clone());
              }
              v6_2_cursor.ascend(1);
            }
            drop(v6_2_cursor);
            v5_3.join_into((v6_2).clone());
            }
            v5_3_cursor.ascend(1);
          }
          drop(v5_3_cursor);
          drop(v5_2);
          v4_3.join_into((v5_3).clone());
          }
          v4_3_cursor.ascend(1);
        }
        drop(v4_3_cursor);
        drop(v4_2);
        v3_3.join_into((v4_3).clone());
        }
        v3_3_cursor.ascend(1);
      }
      drop(v3_3_cursor);
      drop(v3_2);
      v2_2.join_into((v3_3).clone());
      }
      v2_2_cursor.ascend(1);
    }
    drop(v2_2_cursor);
    v1_3.join_into((v2_2).clone());
    }
    v1_3_cursor.ascend(1);
  }
  drop(v1_3_cursor);
  (v1_3).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, p3: &Path, s0: &Space) -> Space {
  let v10_6: Space = singleton(&(*p1));
  let v10_7: Space = intersect(&(*CONSTANT_13),&(v10_6));
  let mut v10_8 = Space::new();
  let mut v10_8_cursor = (v10_7).read_zipper();
  for v10_8_byte in v10_8_cursor.child_mask().iter() {
    v10_8_cursor.descend_to_byte(v10_8_byte);
    {
    let v10_8_tail = v10_8_cursor.fork_read_zipper();
    let v10_8_head = Path::from_slice(&[v10_8_byte]);
    let mut v11_2 = Space::new();
    let mut v11_2_cursor = (v10_8_tail).read_zipper();
    for v11_2_byte in v11_2_cursor.child_mask().iter() {
      v11_2_cursor.descend_to_byte(v11_2_byte);
      {
      let v11_2_tail = v11_2_cursor.fork_read_zipper();
      let v11_2_head = Path::from_slice(&[v11_2_byte]);
      let v12_2: Path = concat_path(&(v10_8_head),&(v11_2_head));
      let mut v12_3 = Space::new();
      let mut v12_3_cursor = (v11_2_tail).read_zipper();
      for v12_3_byte in v12_3_cursor.child_mask().iter() {
        v12_3_cursor.descend_to_byte(v12_3_byte);
        {
        let v12_3_tail = v12_3_cursor.fork_read_zipper();
        let v12_3_head = Path::from_slice(&[v12_3_byte]);
        let v13_2: Path = concat_path(&(v12_2),&(v12_3_head));
        let mut v13_3 = Space::new();
        let mut v13_3_cursor = (v12_3_tail).read_zipper();
        for v13_3_byte in v13_3_cursor.child_mask().iter() {
          v13_3_cursor.descend_to_byte(v13_3_byte);
          {
          let v13_3_tail = v13_3_cursor.fork_read_zipper();
          let v13_3_head = Path::from_slice(&[v13_3_byte]);
          let v14_2: Path = concat_path(&(v13_2),&(v13_3_head));
          let v14_3: Space = routine_3(c, &(v14_2), &(v13_3_tail).make_space());
          drop(v14_2);
          v13_3.join_into((v14_3).clone());
          }
          v13_3_cursor.ascend(1);
        }
        drop(v13_3_cursor);
        drop(v13_2);
        v12_3.join_into((v13_3).clone());
        }
        v12_3_cursor.ascend(1);
      }
      drop(v12_3_cursor);
      drop(v12_2);
      v11_2.join_into((v12_3).clone());
      }
      v11_2_cursor.ascend(1);
    }
    drop(v11_2_cursor);
    v10_8.join_into((v11_2).clone());
    }
    v10_8_cursor.ascend(1);
  }
  drop(v10_8_cursor);
  drop(v10_7);
  let v10_13: Space = if (v10_8).is_empty() { Space::new() } else {
    let v15_9: Path = concat_path(&(*p2),&(*p3));
    let v15_10: Path = concat_path(&(v15_9),&(*p0));
    drop(v15_9);
    let v15_11: Space = singleton(&(v15_10));
    drop(v15_10);
    let mut v15_12 = Space::new();
    let mut v15_12_cursor = (v15_11).read_zipper();
    for v15_12_byte in v15_12_cursor.child_mask().iter() {
      v15_12_cursor.descend_to_byte(v15_12_byte);
      {
      let v15_12_tail = v15_12_cursor.fork_read_zipper();
      let v15_12_head = Path::from_slice(&[v15_12_byte]);
      let mut v16_2 = Space::new();
      let mut v16_2_cursor = (v15_12_tail).read_zipper();
      for v16_2_byte in v16_2_cursor.child_mask().iter() {
        v16_2_cursor.descend_to_byte(v16_2_byte);
        {
        let v16_2_tail = v16_2_cursor.fork_read_zipper();
        let v16_2_head = Path::from_slice(&[v16_2_byte]);
        let v17_2: Path = concat_path(&(v15_12_head),&(v16_2_head));
        let mut v17_3 = Space::new();
        let mut v17_3_cursor = (v16_2_tail).read_zipper();
        for v17_3_byte in v17_3_cursor.child_mask().iter() {
          v17_3_cursor.descend_to_byte(v17_3_byte);
          {
          let v17_3_tail = v17_3_cursor.fork_read_zipper();
          let v17_3_head = Path::from_slice(&[v17_3_byte]);
          let v18_2: Path = concat_path(&(v17_2),&(v17_3_head));
          let mut v18_3 = Space::new();
          let mut v18_3_cursor = (v17_3_tail).read_zipper();
          for v18_3_byte in v18_3_cursor.child_mask().iter() {
            v18_3_cursor.descend_to_byte(v18_3_byte);
            {
            let v18_3_tail = v18_3_cursor.fork_read_zipper();
            let v18_3_head = Path::from_slice(&[v18_3_byte]);
            let v19_2: Path = concat_path(&(v18_2),&(v18_3_head));
            let v19_3: Space = routine_4(c, &(v19_2), &(v18_3_tail).make_space());
            drop(v19_2);
            v18_3.join_into((v19_3).clone());
            }
            v18_3_cursor.ascend(1);
          }
          drop(v18_3_cursor);
          drop(v18_2);
          v17_3.join_into((v18_3).clone());
          }
          v17_3_cursor.ascend(1);
        }
        drop(v17_3_cursor);
        drop(v17_2);
        v16_2.join_into((v17_3).clone());
        }
        v16_2_cursor.ascend(1);
      }
      drop(v16_2_cursor);
      v15_12.join_into((v16_2).clone());
      }
      v15_12_cursor.ascend(1);
    }
    drop(v15_12_cursor);
    compose(&(v10_8),&(v15_12))
  };
  let v10_15: Space = intersect(&(*CONSTANT_14),&(v10_6));
  let mut v10_16 = Space::new();
  let mut v10_16_cursor = (v10_15).read_zipper();
  for v10_16_byte in v10_16_cursor.child_mask().iter() {
    v10_16_cursor.descend_to_byte(v10_16_byte);
    {
    let v10_16_tail = v10_16_cursor.fork_read_zipper();
    let v10_16_head = Path::from_slice(&[v10_16_byte]);
    let mut v20_2 = Space::new();
    let mut v20_2_cursor = (v10_16_tail).read_zipper();
    for v20_2_byte in v20_2_cursor.child_mask().iter() {
      v20_2_cursor.descend_to_byte(v20_2_byte);
      {
      let v20_2_tail = v20_2_cursor.fork_read_zipper();
      let v20_2_head = Path::from_slice(&[v20_2_byte]);
      let v21_2: Path = concat_path(&(v10_16_head),&(v20_2_head));
      let mut v21_3 = Space::new();
      let mut v21_3_cursor = (v20_2_tail).read_zipper();
      for v21_3_byte in v21_3_cursor.child_mask().iter() {
        v21_3_cursor.descend_to_byte(v21_3_byte);
        {
        let v21_3_tail = v21_3_cursor.fork_read_zipper();
        let v21_3_head = Path::from_slice(&[v21_3_byte]);
        let v22_2: Path = concat_path(&(v21_2),&(v21_3_head));
        let mut v22_3 = Space::new();
        let mut v22_3_cursor = (v21_3_tail).read_zipper();
        for v22_3_byte in v22_3_cursor.child_mask().iter() {
          v22_3_cursor.descend_to_byte(v22_3_byte);
          {
          let v22_3_tail = v22_3_cursor.fork_read_zipper();
          let v22_3_head = Path::from_slice(&[v22_3_byte]);
          let v23_2: Path = concat_path(&(v22_2),&(v22_3_head));
          let v23_3: Space = routine_5(c, &(v23_2), &(v22_3_tail).make_space());
          drop(v23_2);
          v22_3.join_into((v23_3).clone());
          }
          v22_3_cursor.ascend(1);
        }
        drop(v22_3_cursor);
        drop(v22_2);
        v21_3.join_into((v22_3).clone());
        }
        v21_3_cursor.ascend(1);
      }
      drop(v21_3_cursor);
      drop(v21_2);
      v20_2.join_into((v21_3).clone());
      }
      v20_2_cursor.ascend(1);
    }
    drop(v20_2_cursor);
    v10_16.join_into((v20_2).clone());
    }
    v10_16_cursor.ascend(1);
  }
  drop(v10_16_cursor);
  drop(v10_15);
  let v10_18: Space = if (v10_16).is_empty() { Space::new() } else {
    let v24_9: Path = concat_path(&(*p2),&(*p3));
    let v24_10: Path = concat_path(&(v24_9),&(*p0));
    drop(v24_9);
    let v24_11: Space = singleton(&(v24_10));
    drop(v24_10);
    let mut v24_17 = Space::new();
    let mut v24_17_cursor = (v24_11).read_zipper();
    for v24_17_byte in v24_17_cursor.child_mask().iter() {
      v24_17_cursor.descend_to_byte(v24_17_byte);
      {
      let v24_17_tail = v24_17_cursor.fork_read_zipper();
      let v24_17_head = Path::from_slice(&[v24_17_byte]);
      let mut v25_2 = Space::new();
      let mut v25_2_cursor = (v24_17_tail).read_zipper();
      for v25_2_byte in v25_2_cursor.child_mask().iter() {
        v25_2_cursor.descend_to_byte(v25_2_byte);
        {
        let v25_2_tail = v25_2_cursor.fork_read_zipper();
        let v25_2_head = Path::from_slice(&[v25_2_byte]);
        let v26_2: Path = concat_path(&(v24_17_head),&(v25_2_head));
        let mut v26_3 = Space::new();
        let mut v26_3_cursor = (v25_2_tail).read_zipper();
        for v26_3_byte in v26_3_cursor.child_mask().iter() {
          v26_3_cursor.descend_to_byte(v26_3_byte);
          {
          let v26_3_tail = v26_3_cursor.fork_read_zipper();
          let v26_3_head = Path::from_slice(&[v26_3_byte]);
          let v27_2: Path = concat_path(&(v26_2),&(v26_3_head));
          let mut v27_3 = Space::new();
          let mut v27_3_cursor = (v26_3_tail).read_zipper();
          for v27_3_byte in v27_3_cursor.child_mask().iter() {
            v27_3_cursor.descend_to_byte(v27_3_byte);
            {
            let v27_3_tail = v27_3_cursor.fork_read_zipper();
            let v27_3_head = Path::from_slice(&[v27_3_byte]);
            let v28_2: Path = concat_path(&(v27_2),&(v27_3_head));
            let v28_3: Space = routine_6(c, &(v28_2), &(v27_3_tail).make_space());
            drop(v28_2);
            v27_3.join_into((v28_3).clone());
            }
            v27_3_cursor.ascend(1);
          }
          drop(v27_3_cursor);
          drop(v27_2);
          v26_3.join_into((v27_3).clone());
          }
          v26_3_cursor.ascend(1);
        }
        drop(v26_3_cursor);
        drop(v26_2);
        v25_2.join_into((v26_3).clone());
        }
        v25_2_cursor.ascend(1);
      }
      drop(v25_2_cursor);
      v24_17.join_into((v25_2).clone());
      }
      v24_17_cursor.ascend(1);
    }
    drop(v24_17_cursor);
    compose(&(v10_16),&(v24_17))
  };
  let v10_19: Space = unite(&(v10_13),&(v10_18));
  let v10_21: Space = intersect(&(*CONSTANT_15),&(v10_6));
  let mut v10_22 = Space::new();
  let mut v10_22_cursor = (v10_21).read_zipper();
  for v10_22_byte in v10_22_cursor.child_mask().iter() {
    v10_22_cursor.descend_to_byte(v10_22_byte);
    {
    let v10_22_tail = v10_22_cursor.fork_read_zipper();
    let v10_22_head = Path::from_slice(&[v10_22_byte]);
    let mut v29_2 = Space::new();
    let mut v29_2_cursor = (v10_22_tail).read_zipper();
    for v29_2_byte in v29_2_cursor.child_mask().iter() {
      v29_2_cursor.descend_to_byte(v29_2_byte);
      {
      let v29_2_tail = v29_2_cursor.fork_read_zipper();
      let v29_2_head = Path::from_slice(&[v29_2_byte]);
      let v30_2: Path = concat_path(&(v10_22_head),&(v29_2_head));
      let mut v30_3 = Space::new();
      let mut v30_3_cursor = (v29_2_tail).read_zipper();
      for v30_3_byte in v30_3_cursor.child_mask().iter() {
        v30_3_cursor.descend_to_byte(v30_3_byte);
        {
        let v30_3_tail = v30_3_cursor.fork_read_zipper();
        let v30_3_head = Path::from_slice(&[v30_3_byte]);
        let v31_2: Path = concat_path(&(v30_2),&(v30_3_head));
        let mut v31_3 = Space::new();
        let mut v31_3_cursor = (v30_3_tail).read_zipper();
        for v31_3_byte in v31_3_cursor.child_mask().iter() {
          v31_3_cursor.descend_to_byte(v31_3_byte);
          {
          let v31_3_tail = v31_3_cursor.fork_read_zipper();
          let v31_3_head = Path::from_slice(&[v31_3_byte]);
          let v32_2: Path = concat_path(&(v31_2),&(v31_3_head));
          let v32_3: Space = routine_7(c, &(v32_2), &(v31_3_tail).make_space());
          drop(v32_2);
          v31_3.join_into((v32_3).clone());
          }
          v31_3_cursor.ascend(1);
        }
        drop(v31_3_cursor);
        drop(v31_2);
        v30_3.join_into((v31_3).clone());
        }
        v30_3_cursor.ascend(1);
      }
      drop(v30_3_cursor);
      drop(v30_2);
      v29_2.join_into((v30_3).clone());
      }
      v29_2_cursor.ascend(1);
    }
    drop(v29_2_cursor);
    v10_22.join_into((v29_2).clone());
    }
    v10_22_cursor.ascend(1);
  }
  drop(v10_22_cursor);
  drop(v10_21);
  let v10_24: Space = if (v10_22).is_empty() { Space::new() } else {
    let v33_9: Path = concat_path(&(*p2),&(*p3));
    let v33_10: Path = concat_path(&(v33_9),&(*p0));
    drop(v33_9);
    let v33_11: Space = singleton(&(v33_10));
    drop(v33_10);
    let mut v33_23 = Space::new();
    let mut v33_23_cursor = (v33_11).read_zipper();
    for v33_23_byte in v33_23_cursor.child_mask().iter() {
      v33_23_cursor.descend_to_byte(v33_23_byte);
      {
      let v33_23_tail = v33_23_cursor.fork_read_zipper();
      let v33_23_head = Path::from_slice(&[v33_23_byte]);
      let mut v34_2 = Space::new();
      let mut v34_2_cursor = (v33_23_tail).read_zipper();
      for v34_2_byte in v34_2_cursor.child_mask().iter() {
        v34_2_cursor.descend_to_byte(v34_2_byte);
        {
        let v34_2_tail = v34_2_cursor.fork_read_zipper();
        let v34_2_head = Path::from_slice(&[v34_2_byte]);
        let v35_2: Path = concat_path(&(v33_23_head),&(v34_2_head));
        let mut v35_3 = Space::new();
        let mut v35_3_cursor = (v34_2_tail).read_zipper();
        for v35_3_byte in v35_3_cursor.child_mask().iter() {
          v35_3_cursor.descend_to_byte(v35_3_byte);
          {
          let v35_3_tail = v35_3_cursor.fork_read_zipper();
          let v35_3_head = Path::from_slice(&[v35_3_byte]);
          let v36_2: Path = concat_path(&(v35_2),&(v35_3_head));
          let mut v36_3 = Space::new();
          let mut v36_3_cursor = (v35_3_tail).read_zipper();
          for v36_3_byte in v36_3_cursor.child_mask().iter() {
            v36_3_cursor.descend_to_byte(v36_3_byte);
            {
            let v36_3_tail = v36_3_cursor.fork_read_zipper();
            let v36_3_head = Path::from_slice(&[v36_3_byte]);
            let v37_2: Path = concat_path(&(v36_2),&(v36_3_head));
            let v37_3: Space = routine_8(c, &(v37_2), &(v36_3_tail).make_space());
            drop(v37_2);
            v36_3.join_into((v37_3).clone());
            }
            v36_3_cursor.ascend(1);
          }
          drop(v36_3_cursor);
          drop(v36_2);
          v35_3.join_into((v36_3).clone());
          }
          v35_3_cursor.ascend(1);
        }
        drop(v35_3_cursor);
        drop(v35_2);
        v34_2.join_into((v35_3).clone());
        }
        v34_2_cursor.ascend(1);
      }
      drop(v34_2_cursor);
      v33_23.join_into((v34_2).clone());
      }
      v33_23_cursor.ascend(1);
    }
    drop(v33_23_cursor);
    compose(&(v10_22),&(v33_23))
  };
  let v10_25: Space = unite(&(v10_19),&(v10_24));
  let v10_27: Space = intersect(&(*CONSTANT_16),&(v10_6));
  drop(v10_6);
  let mut v10_28 = Space::new();
  let mut v10_28_cursor = (v10_27).read_zipper();
  for v10_28_byte in v10_28_cursor.child_mask().iter() {
    v10_28_cursor.descend_to_byte(v10_28_byte);
    {
    let v10_28_tail = v10_28_cursor.fork_read_zipper();
    let v10_28_head = Path::from_slice(&[v10_28_byte]);
    let mut v38_2 = Space::new();
    let mut v38_2_cursor = (v10_28_tail).read_zipper();
    for v38_2_byte in v38_2_cursor.child_mask().iter() {
      v38_2_cursor.descend_to_byte(v38_2_byte);
      {
      let v38_2_tail = v38_2_cursor.fork_read_zipper();
      let v38_2_head = Path::from_slice(&[v38_2_byte]);
      let v39_2: Path = concat_path(&(v10_28_head),&(v38_2_head));
      let mut v39_3 = Space::new();
      let mut v39_3_cursor = (v38_2_tail).read_zipper();
      for v39_3_byte in v39_3_cursor.child_mask().iter() {
        v39_3_cursor.descend_to_byte(v39_3_byte);
        {
        let v39_3_tail = v39_3_cursor.fork_read_zipper();
        let v39_3_head = Path::from_slice(&[v39_3_byte]);
        let v40_2: Path = concat_path(&(v39_2),&(v39_3_head));
        let mut v40_3 = Space::new();
        let mut v40_3_cursor = (v39_3_tail).read_zipper();
        for v40_3_byte in v40_3_cursor.child_mask().iter() {
          v40_3_cursor.descend_to_byte(v40_3_byte);
          {
          let v40_3_tail = v40_3_cursor.fork_read_zipper();
          let v40_3_head = Path::from_slice(&[v40_3_byte]);
          let v41_2: Path = concat_path(&(v40_2),&(v40_3_head));
          let v41_3: Space = routine_9(c, &(v41_2), &(v40_3_tail).make_space());
          drop(v41_2);
          v40_3.join_into((v41_3).clone());
          }
          v40_3_cursor.ascend(1);
        }
        drop(v40_3_cursor);
        drop(v40_2);
        v39_3.join_into((v40_3).clone());
        }
        v39_3_cursor.ascend(1);
      }
      drop(v39_3_cursor);
      drop(v39_2);
      v38_2.join_into((v39_3).clone());
      }
      v38_2_cursor.ascend(1);
    }
    drop(v38_2_cursor);
    v10_28.join_into((v38_2).clone());
    }
    v10_28_cursor.ascend(1);
  }
  drop(v10_28_cursor);
  drop(v10_27);
  let v10_30: Space = if (v10_28).is_empty() { Space::new() } else {
    let v42_9: Path = concat_path(&(*p2),&(*p3));
    let v42_10: Path = concat_path(&(v42_9),&(*p0));
    drop(v42_9);
    let v42_11: Space = singleton(&(v42_10));
    drop(v42_10);
    let mut v42_29 = Space::new();
    let mut v42_29_cursor = (v42_11).read_zipper();
    for v42_29_byte in v42_29_cursor.child_mask().iter() {
      v42_29_cursor.descend_to_byte(v42_29_byte);
      {
      let v42_29_tail = v42_29_cursor.fork_read_zipper();
      let v42_29_head = Path::from_slice(&[v42_29_byte]);
      let mut v43_2 = Space::new();
      let mut v43_2_cursor = (v42_29_tail).read_zipper();
      for v43_2_byte in v43_2_cursor.child_mask().iter() {
        v43_2_cursor.descend_to_byte(v43_2_byte);
        {
        let v43_2_tail = v43_2_cursor.fork_read_zipper();
        let v43_2_head = Path::from_slice(&[v43_2_byte]);
        let v44_2: Path = concat_path(&(v42_29_head),&(v43_2_head));
        let mut v44_3 = Space::new();
        let mut v44_3_cursor = (v43_2_tail).read_zipper();
        for v44_3_byte in v44_3_cursor.child_mask().iter() {
          v44_3_cursor.descend_to_byte(v44_3_byte);
          {
          let v44_3_tail = v44_3_cursor.fork_read_zipper();
          let v44_3_head = Path::from_slice(&[v44_3_byte]);
          let v45_2: Path = concat_path(&(v44_2),&(v44_3_head));
          let mut v45_3 = Space::new();
          let mut v45_3_cursor = (v44_3_tail).read_zipper();
          for v45_3_byte in v45_3_cursor.child_mask().iter() {
            v45_3_cursor.descend_to_byte(v45_3_byte);
            {
            let v45_3_tail = v45_3_cursor.fork_read_zipper();
            let v45_3_head = Path::from_slice(&[v45_3_byte]);
            let v46_2: Path = concat_path(&(v45_2),&(v45_3_head));
            let v46_3: Space = routine_10(c, &(v46_2), &(v45_3_tail).make_space());
            drop(v46_2);
            v45_3.join_into((v46_3).clone());
            }
            v45_3_cursor.ascend(1);
          }
          drop(v45_3_cursor);
          drop(v45_2);
          v44_3.join_into((v45_3).clone());
          }
          v44_3_cursor.ascend(1);
        }
        drop(v44_3_cursor);
        drop(v44_2);
        v43_2.join_into((v44_3).clone());
        }
        v43_2_cursor.ascend(1);
      }
      drop(v43_2_cursor);
      v42_29.join_into((v43_2).clone());
      }
      v42_29_cursor.ascend(1);
    }
    drop(v42_29_cursor);
    drop(v42_11);
    compose(&(v10_28),&(v42_29))
  };
  let v10_31: Space = unite(&(v10_25),&(v10_30));
  let mut v10_40 = Space::new();
  let mut v10_40_cursor = (v10_31).read_zipper();
  for v10_40_byte in v10_40_cursor.child_mask().iter() {
    v10_40_cursor.descend_to_byte(v10_40_byte);
    {
    let v10_40_tail = v10_40_cursor.fork_read_zipper();
    let v10_40_head = Path::from_slice(&[v10_40_byte]);
    let mut v47_2 = Space::new();
    let mut v47_2_cursor = (v10_40_tail).read_zipper();
    for v47_2_byte in v47_2_cursor.child_mask().iter() {
      v47_2_cursor.descend_to_byte(v47_2_byte);
      {
      let v47_2_tail = v47_2_cursor.fork_read_zipper();
      let v47_2_head = Path::from_slice(&[v47_2_byte]);
      let v48_2: Path = concat_path(&(v10_40_head),&(v47_2_head));
      let mut v48_3 = Space::new();
      let mut v48_3_cursor = (v47_2_tail).read_zipper();
      for v48_3_byte in v48_3_cursor.child_mask().iter() {
        v48_3_cursor.descend_to_byte(v48_3_byte);
        {
        let v48_3_tail = v48_3_cursor.fork_read_zipper();
        let v48_3_head = Path::from_slice(&[v48_3_byte]);
        let v49_2: Path = concat_path(&(v48_2),&(v48_3_head));
        let mut v49_3 = Space::new();
        let mut v49_3_cursor = (v48_3_tail).read_zipper();
        for v49_3_byte in v49_3_cursor.child_mask().iter() {
          v49_3_cursor.descend_to_byte(v49_3_byte);
          {
          let v49_3_tail = v49_3_cursor.fork_read_zipper();
          let v49_3_head = Path::from_slice(&[v49_3_byte]);
          let v50_2: Space = routine_11(c, &(*CONSTANT_1), &(*CONSTANT_17));
          let v50_3: Space = routine_11(c, &(*CONSTANT_3), &(*CONSTANT_18));
          let v50_4: Space = unite(&(v50_2),&(v50_3));
          let v50_5: Space = routine_11(c, &(*CONSTANT_4), &(*CONSTANT_19));
          let v50_6: Space = unite(&(v50_4),&(v50_5));
          let v50_7: Space = routine_11(c, &(*CONSTANT_6), &(*CONSTANT_20));
          let v50_8: Space = unite(&(v50_6),&(v50_7));
          let v50_9: Space = unwrap(&(v50_8),&(*p1));
          let v50_10: Path = concat_path(&(v49_2),&(v49_3_head));
          let mut v50_11 = Space::new();
          let mut v50_11_cursor = (v50_9).read_zipper();
          for v50_11_byte in v50_11_cursor.child_mask().iter() {
            v50_11_cursor.descend_to_byte(v50_11_byte);
            {
            let v50_11_tail = v50_11_cursor.fork_read_zipper();
            let v50_11_head = Path::from_slice(&[v50_11_byte]);
            let mut v51_2 = Space::new();
            let mut v51_2_cursor = (v50_11_tail).read_zipper();
            for v51_2_byte in v51_2_cursor.child_mask().iter() {
              v51_2_cursor.descend_to_byte(v51_2_byte);
              {
              let v51_2_tail = v51_2_cursor.fork_read_zipper();
              let v51_2_head = Path::from_slice(&[v51_2_byte]);
              let v52_2: Path = concat_path(&(v50_11_head),&(v51_2_head));
              let mut v52_3 = Space::new();
              let mut v52_3_cursor = (v51_2_tail).read_zipper();
              for v52_3_byte in v52_3_cursor.child_mask().iter() {
                v52_3_cursor.descend_to_byte(v52_3_byte);
                {
                let v52_3_tail = v52_3_cursor.fork_read_zipper();
                let v52_3_head = Path::from_slice(&[v52_3_byte]);
                let v53_2: Path = concat_path(&(v52_2),&(v52_3_head));
                let mut v53_3 = Space::new();
                let mut v53_3_cursor = (v52_3_tail).read_zipper();
                for v53_3_byte in v53_3_cursor.child_mask().iter() {
                  v53_3_cursor.descend_to_byte(v53_3_byte);
                  {
                  let v53_3_tail = v53_3_cursor.fork_read_zipper();
                  let v53_3_head = Path::from_slice(&[v53_3_byte]);
                  let v54_2: Path = concat_path(&(v53_2),&(v53_3_head));
                  let v54_3: Space = routine_12(c, &(v54_2), &(v50_10), &(v53_3_tail).make_space(), &(v49_3_tail).make_space());
                  drop(v54_2);
                  v53_3.join_into((v54_3).clone());
                  }
                  v53_3_cursor.ascend(1);
                }
                drop(v53_3_cursor);
                drop(v53_2);
                v52_3.join_into((v53_3).clone());
                }
                v52_3_cursor.ascend(1);
              }
              drop(v52_3_cursor);
              drop(v52_2);
              v51_2.join_into((v52_3).clone());
              }
              v51_2_cursor.ascend(1);
            }
            drop(v51_2_cursor);
            v50_11.join_into((v51_2).clone());
            }
            v50_11_cursor.ascend(1);
          }
          drop(v50_11_cursor);
          drop(v50_10);
          v49_3.join_into((v50_11).clone());
          }
          v49_3_cursor.ascend(1);
        }
        drop(v49_3_cursor);
        drop(v49_2);
        v48_3.join_into((v49_3).clone());
        }
        v48_3_cursor.ascend(1);
      }
      drop(v48_3_cursor);
      drop(v48_2);
      v47_2.join_into((v48_3).clone());
      }
      v47_2_cursor.ascend(1);
    }
    drop(v47_2_cursor);
    v10_40.join_into((v47_2).clone());
    }
    v10_40_cursor.ascend(1);
  }
  drop(v10_40_cursor);
  let mut v10_45 = Space::new();
  let mut v10_45_cursor = (v10_40).read_zipper();
  for v10_45_byte in v10_45_cursor.child_mask().iter() {
    v10_45_cursor.descend_to_byte(v10_45_byte);
    {
    let v10_45_tail = v10_45_cursor.fork_read_zipper();
    let v10_45_head = Path::from_slice(&[v10_45_byte]);
    let mut v55_2 = Space::new();
    let mut v55_2_cursor = (v10_45_tail).read_zipper();
    for v55_2_byte in v55_2_cursor.child_mask().iter() {
      v55_2_cursor.descend_to_byte(v55_2_byte);
      {
      let v55_2_tail = v55_2_cursor.fork_read_zipper();
      let v55_2_head = Path::from_slice(&[v55_2_byte]);
      let mut v56_2 = Space::new();
      let mut v56_2_cursor = (v55_2_tail).read_zipper();
      for v56_2_byte in v56_2_cursor.child_mask().iter() {
        v56_2_cursor.descend_to_byte(v56_2_byte);
        {
        let v56_2_tail = v56_2_cursor.fork_read_zipper();
        let v56_2_head = Path::from_slice(&[v56_2_byte]);
        let mut v57_2 = Space::new();
        let mut v57_2_cursor = (v56_2_tail).read_zipper();
        for v57_2_byte in v57_2_cursor.child_mask().iter() {
          v57_2_cursor.descend_to_byte(v57_2_byte);
          {
          let v57_2_tail = v57_2_cursor.fork_read_zipper();
          let v57_2_head = Path::from_slice(&[v57_2_byte]);
          let v58_2: Space = routine_13(c, &(*CONSTANT_1), &(*CONSTANT_17));
          let v58_3: Space = routine_13(c, &(*CONSTANT_3), &(*CONSTANT_18));
          let v58_4: Space = unite(&(v58_2),&(v58_3));
          let v58_5: Space = routine_13(c, &(*CONSTANT_4), &(*CONSTANT_19));
          let v58_6: Space = unite(&(v58_4),&(v58_5));
          let v58_7: Space = routine_13(c, &(*CONSTANT_6), &(*CONSTANT_20));
          let v58_8: Space = unite(&(v58_6),&(v58_7));
          let v58_9: Space = unwrap(&(v58_8),&(*p1));
          let v58_10: Space = unwrap(&(v58_9),&(v10_45_head));
          let v58_11: Space = unwrap(&(v58_10),&(v55_2_head));
          let v58_12: Space = unwrap(&(v58_11),&(v56_2_head));
          let v58_13: Space = unwrap(&(v58_12),&(v57_2_head));
          let v58_14: Space = unwrap(&(v58_13),&(*p1));
          let mut v58_15 = Space::new();
          let mut v58_15_cursor = (v58_14).read_zipper();
          for v58_15_byte in v58_15_cursor.child_mask().iter() {
            v58_15_cursor.descend_to_byte(v58_15_byte);
            {
            let v58_15_tail = v58_15_cursor.fork_read_zipper();
            let v58_15_head = Path::from_slice(&[v58_15_byte]);
            let mut v59_2 = Space::new();
            let mut v59_2_cursor = (v58_15_tail).read_zipper();
            for v59_2_byte in v59_2_cursor.child_mask().iter() {
              v59_2_cursor.descend_to_byte(v59_2_byte);
              {
              let v59_2_tail = v59_2_cursor.fork_read_zipper();
              let v59_2_head = Path::from_slice(&[v59_2_byte]);
              let v60_2: Path = concat_path(&(v58_15_head),&(v59_2_head));
              let mut v60_3 = Space::new();
              let mut v60_3_cursor = (v59_2_tail).read_zipper();
              for v60_3_byte in v60_3_cursor.child_mask().iter() {
                v60_3_cursor.descend_to_byte(v60_3_byte);
                {
                let v60_3_tail = v60_3_cursor.fork_read_zipper();
                let v60_3_head = Path::from_slice(&[v60_3_byte]);
                let v61_2: Path = concat_path(&(v60_2),&(v60_3_head));
                let mut v61_3 = Space::new();
                let mut v61_3_cursor = (v60_3_tail).read_zipper();
                for v61_3_byte in v61_3_cursor.child_mask().iter() {
                  v61_3_cursor.descend_to_byte(v61_3_byte);
                  {
                  let v61_3_tail = v61_3_cursor.fork_read_zipper();
                  let v61_3_head = Path::from_slice(&[v61_3_byte]);
                  let v62_2: Path = concat_path(&(v61_2),&(v61_3_head));
                  let v62_3: Space = routine_14(c, &(v62_2), &(v61_3_tail).make_space(), &(v57_2_tail).make_space());
                  drop(v62_2);
                  v61_3.join_into((v62_3).clone());
                  }
                  v61_3_cursor.ascend(1);
                }
                drop(v61_3_cursor);
                drop(v61_2);
                v60_3.join_into((v61_3).clone());
                }
                v60_3_cursor.ascend(1);
              }
              drop(v60_3_cursor);
              drop(v60_2);
              v59_2.join_into((v60_3).clone());
              }
              v59_2_cursor.ascend(1);
            }
            drop(v59_2_cursor);
            v58_15.join_into((v59_2).clone());
            }
            v58_15_cursor.ascend(1);
          }
          drop(v58_15_cursor);
          v57_2.join_into((v58_15).clone());
          }
          v57_2_cursor.ascend(1);
        }
        drop(v57_2_cursor);
        v56_2.join_into((v57_2).clone());
        }
        v56_2_cursor.ascend(1);
      }
      drop(v56_2_cursor);
      v55_2.join_into((v56_2).clone());
      }
      v55_2_cursor.ascend(1);
    }
    drop(v55_2_cursor);
    v10_45.join_into((v55_2).clone());
    }
    v10_45_cursor.ascend(1);
  }
  drop(v10_45_cursor);
  (v10_45).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v64_2 = Space::new();
  let mut v64_2_cursor = (*s0).read_zipper();
  for v64_2_byte in v64_2_cursor.child_mask().iter() {
    v64_2_cursor.descend_to_byte(v64_2_byte);
    {
    let v64_2_tail = v64_2_cursor.fork_read_zipper();
    let v64_2_head = Path::from_slice(&[v64_2_byte]);
    let mut v65_2 = Space::new();
    let mut v65_2_cursor = (v64_2_tail).read_zipper();
    for v65_2_byte in v65_2_cursor.child_mask().iter() {
      v65_2_cursor.descend_to_byte(v65_2_byte);
      {
      let v65_2_tail = v65_2_cursor.fork_read_zipper();
      let v65_2_head = Path::from_slice(&[v65_2_byte]);
      let v66_2: Path = concat_path(&(v64_2_head),&(v65_2_head));
      let mut v66_3 = Space::new();
      let mut v66_3_cursor = (v65_2_tail).read_zipper();
      for v66_3_byte in v66_3_cursor.child_mask().iter() {
        v66_3_cursor.descend_to_byte(v66_3_byte);
        {
        let v66_3_tail = v66_3_cursor.fork_read_zipper();
        let v66_3_head = Path::from_slice(&[v66_3_byte]);
        let v67_2: Path = concat_path(&(v66_2),&(v66_3_head));
        let mut v67_3 = Space::new();
        let mut v67_3_cursor = (v66_3_tail).read_zipper();
        for v67_3_byte in v67_3_cursor.child_mask().iter() {
          v67_3_cursor.descend_to_byte(v67_3_byte);
          {
          let v67_3_tail = v67_3_cursor.fork_read_zipper();
          let v67_3_head = Path::from_slice(&[v67_3_byte]);
          let v68_2: Path = concat_path(&(v67_2),&(v67_3_head));
          let mut v68_3 = Space::new();
          let mut v68_3_cursor = (v67_3_tail).read_zipper();
          for v68_3_byte in v68_3_cursor.child_mask().iter() {
            v68_3_cursor.descend_to_byte(v68_3_byte);
            {
            let v68_3_tail = v68_3_cursor.fork_read_zipper();
            let v68_3_head = Path::from_slice(&[v68_3_byte]);
            let mut v69_2 = Space::new();
            let mut v69_2_cursor = (v68_3_tail).read_zipper();
            for v69_2_byte in v69_2_cursor.child_mask().iter() {
              v69_2_cursor.descend_to_byte(v69_2_byte);
              {
              let v69_2_tail = v69_2_cursor.fork_read_zipper();
              let v69_2_head = Path::from_slice(&[v69_2_byte]);
              let v70_2: Path = concat_path(&(v68_3_head),&(v69_2_head));
              let mut v70_3 = Space::new();
              let mut v70_3_cursor = (v69_2_tail).read_zipper();
              for v70_3_byte in v70_3_cursor.child_mask().iter() {
                v70_3_cursor.descend_to_byte(v70_3_byte);
                {
                let v70_3_tail = v70_3_cursor.fork_read_zipper();
                let v70_3_head = Path::from_slice(&[v70_3_byte]);
                let v71_2: Path = concat_path(&(v70_2),&(v70_3_head));
                let mut v71_3 = Space::new();
                let mut v71_3_cursor = (v70_3_tail).read_zipper();
                for v71_3_byte in v71_3_cursor.child_mask().iter() {
                  v71_3_cursor.descend_to_byte(v71_3_byte);
                  {
                  let v71_3_tail = v71_3_cursor.fork_read_zipper();
                  let v71_3_head = Path::from_slice(&[v71_3_byte]);
                  let v72_2: Path = concat_path(&(v71_2),&(v71_3_head));
                  let v72_3: Space = routine_15(c, &(v72_2), &(v68_2), &(*p0), &(v71_3_tail).make_space());
                  drop(v72_2);
                  v71_3.join_into((v72_3).clone());
                  }
                  v71_3_cursor.ascend(1);
                }
                drop(v71_3_cursor);
                drop(v71_2);
                v70_3.join_into((v71_3).clone());
                }
                v70_3_cursor.ascend(1);
              }
              drop(v70_3_cursor);
              drop(v70_2);
              v69_2.join_into((v70_3).clone());
              }
              v69_2_cursor.ascend(1);
            }
            drop(v69_2_cursor);
            v68_3.join_into((v69_2).clone());
            }
            v68_3_cursor.ascend(1);
          }
          drop(v68_3_cursor);
          drop(v68_2);
          v67_3.join_into((v68_3).clone());
          }
          v67_3_cursor.ascend(1);
        }
        drop(v67_3_cursor);
        drop(v67_2);
        v66_3.join_into((v67_3).clone());
        }
        v66_3_cursor.ascend(1);
      }
      drop(v66_3_cursor);
      drop(v66_2);
      v65_2.join_into((v66_3).clone());
      }
      v65_2_cursor.ascend(1);
    }
    drop(v65_2_cursor);
    v64_2.join_into((v65_2).clone());
    }
    v64_2_cursor.ascend(1);
  }
  drop(v64_2_cursor);
  (v64_2).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v74_2 = Space::new();
  let mut v74_2_cursor = (*s0).read_zipper();
  for v74_2_byte in v74_2_cursor.child_mask().iter() {
    v74_2_cursor.descend_to_byte(v74_2_byte);
    {
    let v74_2_tail = v74_2_cursor.fork_read_zipper();
    let v74_2_head = Path::from_slice(&[v74_2_byte]);
    let mut v75_2 = Space::new();
    let mut v75_2_cursor = (v74_2_tail).read_zipper();
    for v75_2_byte in v75_2_cursor.child_mask().iter() {
      v75_2_cursor.descend_to_byte(v75_2_byte);
      {
      let v75_2_tail = v75_2_cursor.fork_read_zipper();
      let v75_2_head = Path::from_slice(&[v75_2_byte]);
      let v76_2: Path = concat_path(&(v74_2_head),&(v75_2_head));
      let mut v76_3 = Space::new();
      let mut v76_3_cursor = (v75_2_tail).read_zipper();
      for v76_3_byte in v76_3_cursor.child_mask().iter() {
        v76_3_cursor.descend_to_byte(v76_3_byte);
        {
        let v76_3_tail = v76_3_cursor.fork_read_zipper();
        let v76_3_head = Path::from_slice(&[v76_3_byte]);
        let v77_2: Path = concat_path(&(v76_2),&(v76_3_head));
        let mut v77_3 = Space::new();
        let mut v77_3_cursor = (v76_3_tail).read_zipper();
        for v77_3_byte in v77_3_cursor.child_mask().iter() {
          v77_3_cursor.descend_to_byte(v77_3_byte);
          {
          let v77_3_tail = v77_3_cursor.fork_read_zipper();
          let v77_3_head = Path::from_slice(&[v77_3_byte]);
          let v78_2: Path = concat_path(&(v77_2),&(v77_3_head));
          let mut v78_3 = Space::new();
          let mut v78_3_cursor = (v77_3_tail).read_zipper();
          for v78_3_byte in v78_3_cursor.child_mask().iter() {
            v78_3_cursor.descend_to_byte(v78_3_byte);
            {
            let v78_3_tail = v78_3_cursor.fork_read_zipper();
            let v78_3_head = Path::from_slice(&[v78_3_byte]);
            let mut v79_2 = Space::new();
            let mut v79_2_cursor = (v78_3_tail).read_zipper();
            for v79_2_byte in v79_2_cursor.child_mask().iter() {
              v79_2_cursor.descend_to_byte(v79_2_byte);
              {
              let v79_2_tail = v79_2_cursor.fork_read_zipper();
              let v79_2_head = Path::from_slice(&[v79_2_byte]);
              let v80_2: Path = concat_path(&(v78_3_head),&(v79_2_head));
              let mut v80_3 = Space::new();
              let mut v80_3_cursor = (v79_2_tail).read_zipper();
              for v80_3_byte in v80_3_cursor.child_mask().iter() {
                v80_3_cursor.descend_to_byte(v80_3_byte);
                {
                let v80_3_tail = v80_3_cursor.fork_read_zipper();
                let v80_3_head = Path::from_slice(&[v80_3_byte]);
                let v81_2: Path = concat_path(&(v80_2),&(v80_3_head));
                let mut v81_3 = Space::new();
                let mut v81_3_cursor = (v80_3_tail).read_zipper();
                for v81_3_byte in v81_3_cursor.child_mask().iter() {
                  v81_3_cursor.descend_to_byte(v81_3_byte);
                  {
                  let v81_3_tail = v81_3_cursor.fork_read_zipper();
                  let v81_3_head = Path::from_slice(&[v81_3_byte]);
                  let v82_2: Path = concat_path(&(v81_2),&(v81_3_head));
                  let v82_3: Space = routine_16(c, &(v82_2), &(*p0), &(v78_2), &(v81_3_tail).make_space());
                  drop(v82_2);
                  v81_3.join_into((v82_3).clone());
                  }
                  v81_3_cursor.ascend(1);
                }
                drop(v81_3_cursor);
                drop(v81_2);
                v80_3.join_into((v81_3).clone());
                }
                v80_3_cursor.ascend(1);
              }
              drop(v80_3_cursor);
              drop(v80_2);
              v79_2.join_into((v80_3).clone());
              }
              v79_2_cursor.ascend(1);
            }
            drop(v79_2_cursor);
            v78_3.join_into((v79_2).clone());
            }
            v78_3_cursor.ascend(1);
          }
          drop(v78_3_cursor);
          drop(v78_2);
          v77_3.join_into((v78_3).clone());
          }
          v77_3_cursor.ascend(1);
        }
        drop(v77_3_cursor);
        drop(v77_2);
        v76_3.join_into((v77_3).clone());
        }
        v76_3_cursor.ascend(1);
      }
      drop(v76_3_cursor);
      drop(v76_2);
      v75_2.join_into((v76_3).clone());
      }
      v75_2_cursor.ascend(1);
    }
    drop(v75_2_cursor);
    v74_2.join_into((v75_2).clone());
    }
    v74_2_cursor.ascend(1);
  }
  drop(v74_2_cursor);
  (v74_2).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v84_2 = Space::new();
  let mut v84_2_cursor = (*s0).read_zipper();
  for v84_2_byte in v84_2_cursor.child_mask().iter() {
    v84_2_cursor.descend_to_byte(v84_2_byte);
    {
    let v84_2_tail = v84_2_cursor.fork_read_zipper();
    let v84_2_head = Path::from_slice(&[v84_2_byte]);
    let mut v85_2 = Space::new();
    let mut v85_2_cursor = (v84_2_tail).read_zipper();
    for v85_2_byte in v85_2_cursor.child_mask().iter() {
      v85_2_cursor.descend_to_byte(v85_2_byte);
      {
      let v85_2_tail = v85_2_cursor.fork_read_zipper();
      let v85_2_head = Path::from_slice(&[v85_2_byte]);
      let v86_2: Path = concat_path(&(v84_2_head),&(v85_2_head));
      let mut v86_3 = Space::new();
      let mut v86_3_cursor = (v85_2_tail).read_zipper();
      for v86_3_byte in v86_3_cursor.child_mask().iter() {
        v86_3_cursor.descend_to_byte(v86_3_byte);
        {
        let v86_3_tail = v86_3_cursor.fork_read_zipper();
        let v86_3_head = Path::from_slice(&[v86_3_byte]);
        let v87_2: Path = concat_path(&(v86_2),&(v86_3_head));
        let mut v87_3 = Space::new();
        let mut v87_3_cursor = (v86_3_tail).read_zipper();
        for v87_3_byte in v87_3_cursor.child_mask().iter() {
          v87_3_cursor.descend_to_byte(v87_3_byte);
          {
          let v87_3_tail = v87_3_cursor.fork_read_zipper();
          let v87_3_head = Path::from_slice(&[v87_3_byte]);
          let v88_2: Path = concat_path(&(v87_2),&(v87_3_head));
          let mut v88_3 = Space::new();
          let mut v88_3_cursor = (v87_3_tail).read_zipper();
          for v88_3_byte in v88_3_cursor.child_mask().iter() {
            v88_3_cursor.descend_to_byte(v88_3_byte);
            {
            let v88_3_tail = v88_3_cursor.fork_read_zipper();
            let v88_3_head = Path::from_slice(&[v88_3_byte]);
            let mut v89_2 = Space::new();
            let mut v89_2_cursor = (v88_3_tail).read_zipper();
            for v89_2_byte in v89_2_cursor.child_mask().iter() {
              v89_2_cursor.descend_to_byte(v89_2_byte);
              {
              let v89_2_tail = v89_2_cursor.fork_read_zipper();
              let v89_2_head = Path::from_slice(&[v89_2_byte]);
              let v90_2: Path = concat_path(&(v88_3_head),&(v89_2_head));
              let mut v90_3 = Space::new();
              let mut v90_3_cursor = (v89_2_tail).read_zipper();
              for v90_3_byte in v90_3_cursor.child_mask().iter() {
                v90_3_cursor.descend_to_byte(v90_3_byte);
                {
                let v90_3_tail = v90_3_cursor.fork_read_zipper();
                let v90_3_head = Path::from_slice(&[v90_3_byte]);
                let v91_2: Path = concat_path(&(v90_2),&(v90_3_head));
                let mut v91_3 = Space::new();
                let mut v91_3_cursor = (v90_3_tail).read_zipper();
                for v91_3_byte in v91_3_cursor.child_mask().iter() {
                  v91_3_cursor.descend_to_byte(v91_3_byte);
                  {
                  let v91_3_tail = v91_3_cursor.fork_read_zipper();
                  let v91_3_head = Path::from_slice(&[v91_3_byte]);
                  let v92_2: Path = concat_path(&(v91_2),&(v91_3_head));
                  let v92_3: Space = routine_17(c, &(v92_2), &(*p0), &(v88_2), &(v91_3_tail).make_space());
                  drop(v92_2);
                  v91_3.join_into((v92_3).clone());
                  }
                  v91_3_cursor.ascend(1);
                }
                drop(v91_3_cursor);
                drop(v91_2);
                v90_3.join_into((v91_3).clone());
                }
                v90_3_cursor.ascend(1);
              }
              drop(v90_3_cursor);
              drop(v90_2);
              v89_2.join_into((v90_3).clone());
              }
              v89_2_cursor.ascend(1);
            }
            drop(v89_2_cursor);
            v88_3.join_into((v89_2).clone());
            }
            v88_3_cursor.ascend(1);
          }
          drop(v88_3_cursor);
          drop(v88_2);
          v87_3.join_into((v88_3).clone());
          }
          v87_3_cursor.ascend(1);
        }
        drop(v87_3_cursor);
        drop(v87_2);
        v86_3.join_into((v87_3).clone());
        }
        v86_3_cursor.ascend(1);
      }
      drop(v86_3_cursor);
      drop(v86_2);
      v85_2.join_into((v86_3).clone());
      }
      v85_2_cursor.ascend(1);
    }
    drop(v85_2_cursor);
    v84_2.join_into((v85_2).clone());
    }
    v84_2_cursor.ascend(1);
  }
  drop(v84_2_cursor);
  (v84_2).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v94_2 = Space::new();
  let mut v94_2_cursor = (*s0).read_zipper();
  for v94_2_byte in v94_2_cursor.child_mask().iter() {
    v94_2_cursor.descend_to_byte(v94_2_byte);
    {
    let v94_2_tail = v94_2_cursor.fork_read_zipper();
    let v94_2_head = Path::from_slice(&[v94_2_byte]);
    let mut v95_2 = Space::new();
    let mut v95_2_cursor = (v94_2_tail).read_zipper();
    for v95_2_byte in v95_2_cursor.child_mask().iter() {
      v95_2_cursor.descend_to_byte(v95_2_byte);
      {
      let v95_2_tail = v95_2_cursor.fork_read_zipper();
      let v95_2_head = Path::from_slice(&[v95_2_byte]);
      let v96_2: Path = concat_path(&(v94_2_head),&(v95_2_head));
      let mut v96_3 = Space::new();
      let mut v96_3_cursor = (v95_2_tail).read_zipper();
      for v96_3_byte in v96_3_cursor.child_mask().iter() {
        v96_3_cursor.descend_to_byte(v96_3_byte);
        {
        let v96_3_tail = v96_3_cursor.fork_read_zipper();
        let v96_3_head = Path::from_slice(&[v96_3_byte]);
        let v97_2: Path = concat_path(&(v96_2),&(v96_3_head));
        let mut v97_3 = Space::new();
        let mut v97_3_cursor = (v96_3_tail).read_zipper();
        for v97_3_byte in v97_3_cursor.child_mask().iter() {
          v97_3_cursor.descend_to_byte(v97_3_byte);
          {
          let v97_3_tail = v97_3_cursor.fork_read_zipper();
          let v97_3_head = Path::from_slice(&[v97_3_byte]);
          let v98_2: Path = concat_path(&(v97_2),&(v97_3_head));
          let mut v98_3 = Space::new();
          let mut v98_3_cursor = (v97_3_tail).read_zipper();
          for v98_3_byte in v98_3_cursor.child_mask().iter() {
            v98_3_cursor.descend_to_byte(v98_3_byte);
            {
            let v98_3_tail = v98_3_cursor.fork_read_zipper();
            let v98_3_head = Path::from_slice(&[v98_3_byte]);
            let mut v99_2 = Space::new();
            let mut v99_2_cursor = (v98_3_tail).read_zipper();
            for v99_2_byte in v99_2_cursor.child_mask().iter() {
              v99_2_cursor.descend_to_byte(v99_2_byte);
              {
              let v99_2_tail = v99_2_cursor.fork_read_zipper();
              let v99_2_head = Path::from_slice(&[v99_2_byte]);
              let v100_2: Path = concat_path(&(v98_3_head),&(v99_2_head));
              let mut v100_3 = Space::new();
              let mut v100_3_cursor = (v99_2_tail).read_zipper();
              for v100_3_byte in v100_3_cursor.child_mask().iter() {
                v100_3_cursor.descend_to_byte(v100_3_byte);
                {
                let v100_3_tail = v100_3_cursor.fork_read_zipper();
                let v100_3_head = Path::from_slice(&[v100_3_byte]);
                let v101_2: Path = concat_path(&(v100_2),&(v100_3_head));
                let mut v101_3 = Space::new();
                let mut v101_3_cursor = (v100_3_tail).read_zipper();
                for v101_3_byte in v101_3_cursor.child_mask().iter() {
                  v101_3_cursor.descend_to_byte(v101_3_byte);
                  {
                  let v101_3_tail = v101_3_cursor.fork_read_zipper();
                  let v101_3_head = Path::from_slice(&[v101_3_byte]);
                  let v102_2: Path = concat_path(&(v101_2),&(v101_3_head));
                  let v102_3: Space = routine_18(c, &(v102_2), &(*p0), &(v98_2), &(v101_3_tail).make_space());
                  drop(v102_2);
                  v101_3.join_into((v102_3).clone());
                  }
                  v101_3_cursor.ascend(1);
                }
                drop(v101_3_cursor);
                drop(v101_2);
                v100_3.join_into((v101_3).clone());
                }
                v100_3_cursor.ascend(1);
              }
              drop(v100_3_cursor);
              drop(v100_2);
              v99_2.join_into((v100_3).clone());
              }
              v99_2_cursor.ascend(1);
            }
            drop(v99_2_cursor);
            v98_3.join_into((v99_2).clone());
            }
            v98_3_cursor.ascend(1);
          }
          drop(v98_3_cursor);
          drop(v98_2);
          v97_3.join_into((v98_3).clone());
          }
          v97_3_cursor.ascend(1);
        }
        drop(v97_3_cursor);
        drop(v97_2);
        v96_3.join_into((v97_3).clone());
        }
        v96_3_cursor.ascend(1);
      }
      drop(v96_3_cursor);
      drop(v96_2);
      v95_2.join_into((v96_3).clone());
      }
      v95_2_cursor.ascend(1);
    }
    drop(v95_2_cursor);
    v94_2.join_into((v95_2).clone());
    }
    v94_2_cursor.ascend(1);
  }
  drop(v94_2_cursor);
  (v94_2).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v103_3 = Space::new();
  let mut v103_3_cursor = (*s0).read_zipper();
  for v103_3_byte in v103_3_cursor.child_mask().iter() {
    v103_3_cursor.descend_to_byte(v103_3_byte);
    {
    let v103_3_tail = v103_3_cursor.fork_read_zipper();
    let v103_3_head = Path::from_slice(&[v103_3_byte]);
    let mut v104_2 = Space::new();
    let mut v104_2_cursor = (v103_3_tail).read_zipper();
    for v104_2_byte in v104_2_cursor.child_mask().iter() {
      v104_2_cursor.descend_to_byte(v104_2_byte);
      {
      let v104_2_tail = v104_2_cursor.fork_read_zipper();
      let v104_2_head = Path::from_slice(&[v104_2_byte]);
      let v105_2: Path = concat_path(&(v103_3_head),&(v104_2_head));
      let mut v105_3 = Space::new();
      let mut v105_3_cursor = (v104_2_tail).read_zipper();
      for v105_3_byte in v105_3_cursor.child_mask().iter() {
        v105_3_cursor.descend_to_byte(v105_3_byte);
        {
        let v105_3_tail = v105_3_cursor.fork_read_zipper();
        let v105_3_head = Path::from_slice(&[v105_3_byte]);
        let v106_2: Path = concat_path(&(v105_2),&(v105_3_head));
        let mut v106_3 = Space::new();
        let mut v106_3_cursor = (v105_3_tail).read_zipper();
        for v106_3_byte in v106_3_cursor.child_mask().iter() {
          v106_3_cursor.descend_to_byte(v106_3_byte);
          {
          let v106_3_tail = v106_3_cursor.fork_read_zipper();
          let v106_3_head = Path::from_slice(&[v106_3_byte]);
          let mut v107_2 = Space::new();
          let mut v107_2_cursor = (v106_3_tail).read_zipper();
          for v107_2_byte in v107_2_cursor.child_mask().iter() {
            v107_2_cursor.descend_to_byte(v107_2_byte);
            {
            let v107_2_tail = v107_2_cursor.fork_read_zipper();
            let v107_2_head = Path::from_slice(&[v107_2_byte]);
            let mut v108_2 = Space::new();
            let mut v108_2_cursor = (v107_2_tail).read_zipper();
            for v108_2_byte in v108_2_cursor.child_mask().iter() {
              v108_2_cursor.descend_to_byte(v108_2_byte);
              {
              let v108_2_tail = v108_2_cursor.fork_read_zipper();
              let v108_2_head = Path::from_slice(&[v108_2_byte]);
              let v109_2: Path = concat_path(&(v107_2_head),&(v108_2_head));
              let mut v109_3 = Space::new();
              let mut v109_3_cursor = (v108_2_tail).read_zipper();
              for v109_3_byte in v109_3_cursor.child_mask().iter() {
                v109_3_cursor.descend_to_byte(v109_3_byte);
                {
                let v109_3_tail = v109_3_cursor.fork_read_zipper();
                let v109_3_head = Path::from_slice(&[v109_3_byte]);
                let v110_2: Path = concat_path(&(v109_2),&(v109_3_head));
                let mut v110_3 = Space::new();
                let mut v110_3_cursor = (v109_3_tail).read_zipper();
                for v110_3_byte in v110_3_cursor.child_mask().iter() {
                  v110_3_cursor.descend_to_byte(v110_3_byte);
                  {
                  let v110_3_tail = v110_3_cursor.fork_read_zipper();
                  let v110_3_head = Path::from_slice(&[v110_3_byte]);
                  let v111_2: Path = concat_path(&(v110_2),&(v110_3_head));
                  let v111_3: Space = routine_19(c, &(v111_2), &(v110_3_tail).make_space());
                  drop(v111_2);
                  v110_3.join_into((v111_3).clone());
                  }
                  v110_3_cursor.ascend(1);
                }
                drop(v110_3_cursor);
                drop(v110_2);
                v109_3.join_into((v110_3).clone());
                }
                v109_3_cursor.ascend(1);
              }
              drop(v109_3_cursor);
              drop(v109_2);
              v108_2.join_into((v109_3).clone());
              }
              v108_2_cursor.ascend(1);
            }
            drop(v108_2_cursor);
            v107_2.join_into((v108_2).clone());
            }
            v107_2_cursor.ascend(1);
          }
          drop(v107_2_cursor);
          let v107_3: Space = raffine(&(*CONSTANT_21),&(v107_2));
          let v107_4: Space = unite(&(v107_3),&(v106_3_tail));
          let v107_5: Path = concat_path(&(v106_2),&(v106_3_head));
          let v107_6: Path = concat_path(&(*p0),&(v107_5));
          drop(v107_5);
          let v107_7: Space = wrap(&(v107_4),&(v107_6));
          drop(v107_6);
          v106_3.join_into((v107_7).clone());
          }
          v106_3_cursor.ascend(1);
        }
        drop(v106_3_cursor);
        drop(v106_2);
        v105_3.join_into((v106_3).clone());
        }
        v105_3_cursor.ascend(1);
      }
      drop(v105_3_cursor);
      drop(v105_2);
      v104_2.join_into((v105_3).clone());
      }
      v104_2_cursor.ascend(1);
    }
    drop(v104_2_cursor);
    v103_3.join_into((v104_2).clone());
    }
    v103_3_cursor.ascend(1);
  }
  drop(v103_3_cursor);
  (v103_3).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v112_4: Space = unwrap(&(*s0),&(*p1));
  let v112_5: Space = wrap(&(v112_4),&(*p0));
  drop(v112_4);
  let v112_6: Space = if (v112_5).is_empty() { Space::new() } else {
    compose(&(v112_5),&(*s1))
  };
  drop(v112_5);
  (v112_6).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v114_3 = Space::new();
  let mut v114_3_cursor = (*s0).read_zipper();
  for v114_3_byte in v114_3_cursor.child_mask().iter() {
    v114_3_cursor.descend_to_byte(v114_3_byte);
    {
    let v114_3_tail = v114_3_cursor.fork_read_zipper();
    let v114_3_head = Path::from_slice(&[v114_3_byte]);
    let mut v115_2 = Space::new();
    let mut v115_2_cursor = (v114_3_tail).read_zipper();
    for v115_2_byte in v115_2_cursor.child_mask().iter() {
      v115_2_cursor.descend_to_byte(v115_2_byte);
      {
      let v115_2_tail = v115_2_cursor.fork_read_zipper();
      let v115_2_head = Path::from_slice(&[v115_2_byte]);
      let v116_2: Path = concat_path(&(v114_3_head),&(v115_2_head));
      let mut v116_3 = Space::new();
      let mut v116_3_cursor = (v115_2_tail).read_zipper();
      for v116_3_byte in v116_3_cursor.child_mask().iter() {
        v116_3_cursor.descend_to_byte(v116_3_byte);
        {
        let v116_3_tail = v116_3_cursor.fork_read_zipper();
        let v116_3_head = Path::from_slice(&[v116_3_byte]);
        let v117_2: Path = concat_path(&(v116_2),&(v116_3_head));
        let mut v117_3 = Space::new();
        let mut v117_3_cursor = (v116_3_tail).read_zipper();
        for v117_3_byte in v117_3_cursor.child_mask().iter() {
          v117_3_cursor.descend_to_byte(v117_3_byte);
          {
          let v117_3_tail = v117_3_cursor.fork_read_zipper();
          let v117_3_head = Path::from_slice(&[v117_3_byte]);
          let mut v118_2 = Space::new();
          let mut v118_2_cursor = (v117_3_tail).read_zipper();
          for v118_2_byte in v118_2_cursor.child_mask().iter() {
            v118_2_cursor.descend_to_byte(v118_2_byte);
            {
            let v118_2_tail = v118_2_cursor.fork_read_zipper();
            let v118_2_head = Path::from_slice(&[v118_2_byte]);
            let mut v119_2 = Space::new();
            let mut v119_2_cursor = (v118_2_tail).read_zipper();
            for v119_2_byte in v119_2_cursor.child_mask().iter() {
              v119_2_cursor.descend_to_byte(v119_2_byte);
              {
              let v119_2_tail = v119_2_cursor.fork_read_zipper();
              let v119_2_head = Path::from_slice(&[v119_2_byte]);
              let v120_2: Path = concat_path(&(v118_2_head),&(v119_2_head));
              let mut v120_3 = Space::new();
              let mut v120_3_cursor = (v119_2_tail).read_zipper();
              for v120_3_byte in v120_3_cursor.child_mask().iter() {
                v120_3_cursor.descend_to_byte(v120_3_byte);
                {
                let v120_3_tail = v120_3_cursor.fork_read_zipper();
                let v120_3_head = Path::from_slice(&[v120_3_byte]);
                let v121_2: Path = concat_path(&(v120_2),&(v120_3_head));
                let mut v121_3 = Space::new();
                let mut v121_3_cursor = (v120_3_tail).read_zipper();
                for v121_3_byte in v121_3_cursor.child_mask().iter() {
                  v121_3_cursor.descend_to_byte(v121_3_byte);
                  {
                  let v121_3_tail = v121_3_cursor.fork_read_zipper();
                  let v121_3_head = Path::from_slice(&[v121_3_byte]);
                  let v122_2: Path = concat_path(&(v121_2),&(v121_3_head));
                  let v122_3: Space = routine_20(c, &(v122_2), &(v121_3_tail).make_space());
                  drop(v122_2);
                  v121_3.join_into((v122_3).clone());
                  }
                  v121_3_cursor.ascend(1);
                }
                drop(v121_3_cursor);
                drop(v121_2);
                v120_3.join_into((v121_3).clone());
                }
                v120_3_cursor.ascend(1);
              }
              drop(v120_3_cursor);
              drop(v120_2);
              v119_2.join_into((v120_3).clone());
              }
              v119_2_cursor.ascend(1);
            }
            drop(v119_2_cursor);
            v118_2.join_into((v119_2).clone());
            }
            v118_2_cursor.ascend(1);
          }
          drop(v118_2_cursor);
          let v118_3: Space = raffine(&(*CONSTANT_21),&(v118_2));
          let v118_4: Space = unite(&(v118_3),&(v117_3_tail));
          let v118_5: Path = concat_path(&(v117_2),&(v117_3_head));
          let v118_6: Path = concat_path(&(*p0),&(v118_5));
          drop(v118_5);
          let v118_7: Space = wrap(&(v118_4),&(v118_6));
          drop(v118_6);
          v117_3.join_into((v118_7).clone());
          }
          v117_3_cursor.ascend(1);
        }
        drop(v117_3_cursor);
        drop(v117_2);
        v116_3.join_into((v117_3).clone());
        }
        v116_3_cursor.ascend(1);
      }
      drop(v116_3_cursor);
      drop(v116_2);
      v115_2.join_into((v116_3).clone());
      }
      v115_2_cursor.ascend(1);
    }
    drop(v115_2_cursor);
    v114_3.join_into((v115_2).clone());
    }
    v114_3_cursor.ascend(1);
  }
  drop(v114_3_cursor);
  (v114_3).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v123_4: Space = singleton(&(*p0));
  let v123_5: Space = intersect(&(*CONSTANT_13),&(v123_4));
  let v123_14: Space = if (v123_5).is_empty() { Space::new() } else {
    let v124_7: Space = unwrap(&(*s1),&(*CONSTANT_4));
    let v124_10: Space = if (v124_7).is_empty() { Space::new() } else {
      let v125_9: Space = unwrap(&(*s1),&(*CONSTANT_6));
      compose(&(v124_7),&(v125_9))
    };
    let v124_13: Space = if (v124_10).is_empty() { Space::new() } else {
      let v126_12: Space = unwrap(&(*s1),&(*CONSTANT_3));
      compose(&(v124_10),&(v126_12))
    };
    compose(&(v123_5),&(v124_13))
  };
  drop(v123_5);
  let v123_16: Space = intersect(&(*CONSTANT_14),&(v123_4));
  let v123_20: Space = if (v123_16).is_empty() { Space::new() } else {
    let v127_7: Space = unwrap(&(*s1),&(*CONSTANT_4));
    let v127_10: Space = if (v127_7).is_empty() { Space::new() } else {
      let v128_9: Space = unwrap(&(*s1),&(*CONSTANT_6));
      compose(&(v127_7),&(v128_9))
    };
    let v127_19: Space = if (v127_10).is_empty() { Space::new() } else {
      let v129_18: Space = unwrap(&(*s1),&(*CONSTANT_1));
      compose(&(v127_10),&(v129_18))
    };
    drop(v127_10);
    compose(&(v123_16),&(v127_19))
  };
  drop(v123_16);
  let v123_21: Space = unite(&(v123_14),&(v123_20));
  drop(v123_14);
  drop(v123_20);
  let v123_23: Space = intersect(&(*CONSTANT_15),&(v123_4));
  let v123_26: Space = if (v123_23).is_empty() { Space::new() } else {
    let v130_9: Space = unwrap(&(*s1),&(*CONSTANT_6));
    let v130_24: Space = if (v130_9).is_empty() { Space::new() } else {
      let v131_18: Space = unwrap(&(*s1),&(*CONSTANT_1));
      compose(&(v130_9),&(v131_18))
    };
    drop(v130_9);
    let v130_25: Space = if (v130_24).is_empty() { Space::new() } else {
      let v132_12: Space = unwrap(&(*s1),&(*CONSTANT_3));
      compose(&(v130_24),&(v132_12))
    };
    drop(v130_24);
    compose(&(v123_23),&(v130_25))
  };
  drop(v123_23);
  let v123_27: Space = unite(&(v123_21),&(v123_26));
  drop(v123_21);
  drop(v123_26);
  let v123_29: Space = intersect(&(*CONSTANT_16),&(v123_4));
  drop(v123_4);
  let v123_32: Space = if (v123_29).is_empty() { Space::new() } else {
    let v133_7: Space = unwrap(&(*s1),&(*CONSTANT_4));
    let v133_30: Space = if (v133_7).is_empty() { Space::new() } else {
      let v134_18: Space = unwrap(&(*s1),&(*CONSTANT_1));
      compose(&(v133_7),&(v134_18))
    };
    drop(v133_7);
    let v133_31: Space = if (v133_30).is_empty() { Space::new() } else {
      let v135_12: Space = unwrap(&(*s1),&(*CONSTANT_3));
      compose(&(v133_30),&(v135_12))
    };
    drop(v133_30);
    compose(&(v123_29),&(v133_31))
  };
  drop(v123_29);
  let v123_33: Space = unite(&(v123_27),&(v123_32));
  drop(v123_27);
  drop(v123_32);
  (v123_33).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v136_6: Path = concat_path(&(*CONSTANT_3),&(*p0));
  let v136_7: Space = singleton(&(v136_6));
  drop(v136_6);
  let v136_8: Space = unite(&(*CONSTANT_22),&(v136_7));
  drop(v136_7);
  let v136_10: Path = concat_path(&(*CONSTANT_4),&(*p2));
  let v136_11: Space = singleton(&(v136_10));
  drop(v136_10);
  let v136_12: Space = unite(&(v136_8),&(v136_11));
  drop(v136_8);
  drop(v136_11);
  let v136_14: Path = concat_path(&(*CONSTANT_6),&(*p1));
  let v136_15: Space = singleton(&(v136_14));
  drop(v136_14);
  let v136_16: Space = unite(&(v136_12),&(v136_15));
  drop(v136_12);
  drop(v136_15);
  (v136_16).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v137_6: Path = concat_path(&(*CONSTANT_1),&(*p0));
  let v137_7: Space = singleton(&(v137_6));
  drop(v137_6);
  let v137_8: Space = unite(&(*CONSTANT_23),&(v137_7));
  drop(v137_7);
  let v137_10: Path = concat_path(&(*CONSTANT_4),&(*p1));
  let v137_11: Space = singleton(&(v137_10));
  drop(v137_10);
  let v137_12: Space = unite(&(v137_8),&(v137_11));
  drop(v137_8);
  drop(v137_11);
  let v137_14: Path = concat_path(&(*CONSTANT_6),&(*p2));
  let v137_15: Space = singleton(&(v137_14));
  drop(v137_14);
  let v137_16: Space = unite(&(v137_12),&(v137_15));
  drop(v137_12);
  drop(v137_15);
  (v137_16).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v138_6: Path = concat_path(&(*CONSTANT_1),&(*p2));
  let v138_7: Space = singleton(&(v138_6));
  drop(v138_6);
  let v138_8: Space = unite(&(*CONSTANT_24),&(v138_7));
  drop(v138_7);
  let v138_10: Path = concat_path(&(*CONSTANT_3),&(*p0));
  let v138_11: Space = singleton(&(v138_10));
  drop(v138_10);
  let v138_12: Space = unite(&(v138_8),&(v138_11));
  drop(v138_8);
  drop(v138_11);
  let v138_14: Path = concat_path(&(*CONSTANT_6),&(*p1));
  let v138_15: Space = singleton(&(v138_14));
  drop(v138_14);
  let v138_16: Space = unite(&(v138_12),&(v138_15));
  drop(v138_12);
  drop(v138_15);
  (v138_16).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, p2: &Path, s0: &Space) -> Space {
  let v139_6: Path = concat_path(&(*CONSTANT_1),&(*p2));
  let v139_7: Space = singleton(&(v139_6));
  drop(v139_6);
  let v139_8: Space = unite(&(*CONSTANT_25),&(v139_7));
  drop(v139_7);
  let v139_10: Path = concat_path(&(*CONSTANT_3),&(*p0));
  let v139_11: Space = singleton(&(v139_10));
  drop(v139_10);
  let v139_12: Space = unite(&(v139_8),&(v139_11));
  drop(v139_8);
  drop(v139_11);
  let v139_14: Path = concat_path(&(*CONSTANT_4),&(*p1));
  let v139_15: Space = singleton(&(v139_14));
  drop(v139_14);
  let v139_16: Space = unite(&(v139_12),&(v139_15));
  drop(v139_12);
  drop(v139_15);
  (v139_16).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v140_2: Space = singleton(&(*p0));
  (v140_2).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v141_2: Space = singleton(&(*p0));
  (v141_2).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
