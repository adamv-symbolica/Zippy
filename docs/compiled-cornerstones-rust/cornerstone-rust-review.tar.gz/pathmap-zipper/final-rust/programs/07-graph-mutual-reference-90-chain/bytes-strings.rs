#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[101,100,103,101,0]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[77,117,116,117,97,108,0]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_15 = Space::new();
  let mut v0_15_cursor = (v0_2).read_zipper();
  for v0_15_byte in v0_15_cursor.child_mask().iter() {
    v0_15_cursor.descend_to_byte(v0_15_byte);
    {
    let v0_15_tail = v0_15_cursor.fork_read_zipper();
    let v0_15_head = Path::from_slice(&[v0_15_byte]);
    let v1_2: Space = singleton(&(v0_15_head));
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_15_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_15_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail).make_space(), &(*s0.expect("unbound native input")));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_15_head),&(v2_6_head));
          let mut v5_11 = Space::new();
          let mut v5_11_cursor = (v2_6_tail).read_zipper();
          for v5_11_byte in v5_11_cursor.child_mask().iter() {
            v5_11_cursor.descend_to_byte(v5_11_byte);
            {
            let v5_11_tail = v5_11_cursor.fork_read_zipper();
            let v5_11_head = Path::from_slice(&[v5_11_byte]);
            let v6_2: Space = singleton(&(v5_11_head));
            let v6_3: Space = intersect(&(*CONSTANT_2),&(v6_2));
            let v6_4: Space = if has_head(&(v6_3)) { singleton(&[]) } else { Space::new() };
            drop(v6_3);
            let v6_5: Space = subtract(&(*CONSTANT_1),&(v6_4));
            drop(v6_4);
            let v6_7: Space = if (v6_5).is_empty() { Space::new() } else {
              let v7_6: Space = routine_2(c, &(v5_11_head), &(v5_6), &(v5_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v6_5),&(v7_6))
            };
            drop(v6_5);
            let v6_8: Space = intersect(&(*CONSTANT_2),&(v6_2));
            drop(v6_2);
            let v6_9: Space = if has_head(&(v6_8)) { singleton(&[]) } else { Space::new() };
            drop(v6_8);
            let v6_11: Space = if (v6_9).is_empty() { Space::new() } else {
              let v8_10: Space = routine_3(c, &(v5_11_head), &(v5_6), &(v5_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v6_9),&(v8_10))
            };
            drop(v6_9);
            let v6_12: Space = unite(&(v6_7),&(v6_11));
            v5_11.join_into((v6_12).clone());
            }
            v5_11_cursor.ascend(1);
          }
          drop(v5_11_cursor);
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v9_10 = Space::new();
      let mut v9_10_cursor = (v0_15_tail).read_zipper();
      for v9_10_byte in v9_10_cursor.child_mask().iter() {
        v9_10_cursor.descend_to_byte(v9_10_byte);
        {
        let v9_10_tail = v9_10_cursor.fork_read_zipper();
        let v9_10_head = Path::from_slice(&[v9_10_byte]);
        let v10_2: Space = singleton(&(v9_10_head));
        let v10_3: Space = intersect(&(*CONSTANT_2),&(v10_2));
        let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
        drop(v10_3);
        let v10_5: Space = subtract(&(*CONSTANT_1),&(v10_4));
        drop(v10_4);
        let v10_7: Space = if (v10_5).is_empty() { Space::new() } else {
          let v11_6: Space = routine_2(c, &(v9_10_head), &(v0_15_head), &(v9_10_tail).make_space(), &(*s0.expect("unbound native input")));
          compose(&(v10_5),&(v11_6))
        };
        drop(v10_5);
        let v10_8: Space = intersect(&(*CONSTANT_2),&(v10_2));
        drop(v10_2);
        let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
        drop(v10_8);
        let v10_12: Space = if (v10_9).is_empty() { Space::new() } else {
          let v12_10: Space = unwrap(&(v0_2),&(v9_10_head));
          let v12_11: Space = unwrap(&(v12_10),&(v0_15_head));
          drop(v12_10);
          compose(&(v10_9),&(v12_11))
        };
        drop(v10_9);
        let v10_13: Space = wrap(&(v10_12),&(v9_10_head));
        drop(v10_12);
        let v10_14: Space = wrap(&(v10_13),&(v0_15_head));
        drop(v10_13);
        let v10_15: Space = unite(&(v10_7),&(v10_14));
        drop(v10_14);
        v9_10.join_into((v10_15).clone());
        }
        v9_10_cursor.ascend(1);
      }
      drop(v9_10_cursor);
      compose(&(v1_9),&(v9_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_15.join_into((v1_12).clone());
    }
    v0_15_cursor.ascend(1);
  }
  drop(v0_15_cursor);
  drop(v0_2);
  let v0_17: Space = wrap(&(v0_15),&(*CONSTANT_3));
  (v0_17).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v13_10: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let mut v13_11 = Space::new();
  let mut v13_11_cursor = (*s0).read_zipper();
  for v13_11_byte in v13_11_cursor.child_mask().iter() {
    v13_11_cursor.descend_to_byte(v13_11_byte);
    {
    let v13_11_tail = v13_11_cursor.fork_read_zipper();
    let v13_11_head = Path::from_slice(&[v13_11_byte]);
    let v14_2: Space = singleton(&(v13_11_head));
    let v14_3: Space = intersect(&(*CONSTANT_2),&(v14_2));
    let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
    drop(v14_3);
    let v14_5: Space = subtract(&(*CONSTANT_1),&(v14_4));
    drop(v14_4);
    let v14_8: Space = if (v14_5).is_empty() { Space::new() } else {
      let v15_6: Path = concat_path(&(*p0),&(v13_11_head));
      let v15_7: Space = routine_1(c, &(v15_6), &(v13_11_tail).make_space(), &(*s1));
      compose(&(v14_5),&(v15_7))
    };
    drop(v14_5);
    let v14_9: Space = intersect(&(*CONSTANT_2),&(v14_2));
    drop(v14_2);
    let v14_10: Space = if has_head(&(v14_9)) { singleton(&[]) } else { Space::new() };
    drop(v14_9);
    let v14_12: Space = if (v14_10).is_empty() { Space::new() } else {
      let v16_6: Path = concat_path(&(*p0),&(v13_11_head));
      let mut v16_11 = Space::new();
      let mut v16_11_cursor = (v13_11_tail).read_zipper();
      for v16_11_byte in v16_11_cursor.child_mask().iter() {
        v16_11_cursor.descend_to_byte(v16_11_byte);
        {
        let v16_11_tail = v16_11_cursor.fork_read_zipper();
        let v16_11_head = Path::from_slice(&[v16_11_byte]);
        let v17_2: Space = singleton(&(v16_11_head));
        let v17_3: Space = intersect(&(*CONSTANT_2),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_1),&(v17_4));
        drop(v17_4);
        let v17_7: Space = if (v17_5).is_empty() { Space::new() } else {
          let v18_6: Space = routine_2(c, &(v16_11_head), &(v16_6), &(v16_11_tail).make_space(), &(*s1));
          compose(&(v17_5),&(v18_6))
        };
        drop(v17_5);
        let v17_8: Space = intersect(&(*CONSTANT_2),&(v17_2));
        drop(v17_2);
        let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
        drop(v17_8);
        let v17_13: Space = if (v17_9).is_empty() { Space::new() } else {
          let v19_10: Space = unwrap(&(v13_10),&(v16_11_head));
          let v19_11: Space = unwrap(&(v19_10),&(*p0));
          drop(v19_10);
          let v19_12: Space = unwrap(&(v19_11),&(v13_11_head));
          drop(v19_11);
          compose(&(v17_9),&(v19_12))
        };
        drop(v17_9);
        let v17_14: Space = wrap(&(v17_13),&(v16_11_head));
        drop(v17_13);
        let v17_15: Space = wrap(&(v17_14),&(v16_6));
        drop(v17_14);
        let v17_16: Space = unite(&(v17_7),&(v17_15));
        drop(v17_15);
        v16_11.join_into((v17_16).clone());
        }
        v16_11_cursor.ascend(1);
      }
      drop(v16_11_cursor);
      drop(v16_6);
      compose(&(v14_10),&(v16_11))
    };
    drop(v14_10);
    let v14_13: Space = unite(&(v14_8),&(v14_12));
    v13_11.join_into((v14_13).clone());
    }
    v13_11_cursor.ascend(1);
  }
  drop(v13_11_cursor);
  drop(v13_10);
  (v13_11).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v20_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v20_9: Space = unwrap(&(v20_8),&(*p0));
  drop(v20_8);
  let mut v20_10 = Space::new();
  let mut v20_10_cursor = (*s0).read_zipper();
  for v20_10_byte in v20_10_cursor.child_mask().iter() {
    v20_10_cursor.descend_to_byte(v20_10_byte);
    {
    let v20_10_tail = v20_10_cursor.fork_read_zipper();
    let v20_10_head = Path::from_slice(&[v20_10_byte]);
    let v21_2: Space = singleton(&(v20_10_head));
    let v21_3: Space = intersect(&(*CONSTANT_2),&(v21_2));
    let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
    drop(v21_3);
    let v21_5: Space = subtract(&(*CONSTANT_1),&(v21_4));
    drop(v21_4);
    let v21_8: Space = if (v21_5).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v20_10_head));
      let v22_7: Space = routine_2(c, &(v22_6), &(*p1), &(v20_10_tail).make_space(), &(*s1));
      compose(&(v21_5),&(v22_7))
    };
    drop(v21_5);
    let v21_9: Space = intersect(&(*CONSTANT_2),&(v21_2));
    drop(v21_2);
    let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
    drop(v21_9);
    let v21_13: Space = if (v21_10).is_empty() { Space::new() } else {
      let v23_11: Space = unwrap(&(v20_9),&(v20_10_head));
      let v23_12: Space = unwrap(&(v23_11),&(*p1));
      drop(v23_11);
      compose(&(v21_10),&(v23_12))
    };
    drop(v21_10);
    let v24_6: Path = concat_path(&(*p0),&(v20_10_head));
    let v21_14: Space = wrap(&(v21_13),&(v24_6));
    drop(v21_13);
    let v21_15: Space = wrap(&(v21_14),&(*p1));
    drop(v21_14);
    let v21_16: Space = unite(&(v21_8),&(v21_15));
    drop(v21_15);
    v20_10.join_into((v21_16).clone());
    }
    v20_10_cursor.ascend(1);
  }
  drop(v20_10_cursor);
  drop(v20_9);
  (v20_10).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v25_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v25_6: Space = unwrap(&(v25_5),&(*p0));
  drop(v25_5);
  let v25_7: Space = unwrap(&(v25_6),&(*p1));
  drop(v25_6);
  let v25_8: Space = wrap(&(v25_7),&(*p0));
  drop(v25_7);
  let v25_9: Space = wrap(&(v25_8),&(*p1));
  drop(v25_8);
  (v25_9).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
