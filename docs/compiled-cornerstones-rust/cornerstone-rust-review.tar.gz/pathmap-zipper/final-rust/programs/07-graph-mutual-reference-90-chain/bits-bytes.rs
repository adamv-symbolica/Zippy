#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1,0,0,0,0,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_24 = Space::new();
  let mut v0_24_cursor = (v0_2).read_zipper();
  for v0_24_byte in v0_24_cursor.child_mask().iter() {
    v0_24_cursor.descend_to_byte(v0_24_byte);
    {
    let v0_24_tail = v0_24_cursor.fork_read_zipper();
    let v0_24_head = Path::from_slice(&[v0_24_byte]);
    let v1_2: Space = singleton(&(v0_24_head));
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_24_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_24_head),&(v2_6_head));
          let mut v4_7 = Space::new();
          let mut v4_7_cursor = (v2_6_tail).read_zipper();
          for v4_7_byte in v4_7_cursor.child_mask().iter() {
            v4_7_cursor.descend_to_byte(v4_7_byte);
            {
            let v4_7_tail = v4_7_cursor.fork_read_zipper();
            let v4_7_head = Path::from_slice(&[v4_7_byte]);
            let v5_2: Space = singleton(&(v4_7_head));
            let v5_3: Space = intersect(&(*CONSTANT_2),&(v5_2));
            let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
            drop(v5_3);
            let v5_5: Space = subtract(&(*CONSTANT_1),&(v5_4));
            drop(v5_4);
            let v5_8: Space = if (v5_5).is_empty() { Space::new() } else {
              let v6_6: Path = concat_path(&(v4_6),&(v4_7_head));
              let v6_7: Space = routine_1(c, &(v6_6), &(v4_7_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v5_5),&(v6_7))
            };
            drop(v5_5);
            let v5_9: Space = intersect(&(*CONSTANT_2),&(v5_2));
            drop(v5_2);
            let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
            drop(v5_9);
            let v5_12: Space = if (v5_10).is_empty() { Space::new() } else {
              let v7_6: Path = concat_path(&(v4_6),&(v4_7_head));
              let v7_11: Space = routine_2(c, &(v7_6), &(v4_7_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v7_6);
              compose(&(v5_10),&(v7_11))
            };
            drop(v5_10);
            let v5_13: Space = unite(&(v5_8),&(v5_12));
            v4_7.join_into((v5_13).clone());
            }
            v4_7_cursor.ascend(1);
          }
          drop(v4_7_cursor);
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_24_head),&(v2_6_head));
          let mut v8_11 = Space::new();
          let mut v8_11_cursor = (v2_6_tail).read_zipper();
          for v8_11_byte in v8_11_cursor.child_mask().iter() {
            v8_11_cursor.descend_to_byte(v8_11_byte);
            {
            let v8_11_tail = v8_11_cursor.fork_read_zipper();
            let v8_11_head = Path::from_slice(&[v8_11_byte]);
            let v9_2: Space = singleton(&(v8_11_head));
            let v9_3: Space = intersect(&(*CONSTANT_2),&(v9_2));
            let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
            drop(v9_3);
            let v9_5: Space = subtract(&(*CONSTANT_1),&(v9_4));
            drop(v9_4);
            let v9_8: Space = if (v9_5).is_empty() { Space::new() } else {
              let v10_6: Path = concat_path(&(v8_6),&(v8_11_head));
              let v10_7: Space = routine_1(c, &(v10_6), &(v8_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v9_5),&(v10_7))
            };
            drop(v9_5);
            let v9_9: Space = intersect(&(*CONSTANT_2),&(v9_2));
            drop(v9_2);
            let v9_10: Space = if has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
            drop(v9_9);
            let v9_12: Space = if (v9_10).is_empty() { Space::new() } else {
              let v11_6: Path = concat_path(&(v8_6),&(v8_11_head));
              let v11_11: Space = routine_3(c, &(v11_6), &(v8_11_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v11_6);
              compose(&(v9_10),&(v11_11))
            };
            drop(v9_10);
            let v9_13: Space = unite(&(v9_8),&(v9_12));
            v8_11.join_into((v9_13).clone());
            }
            v8_11_cursor.ascend(1);
          }
          drop(v8_11_cursor);
          drop(v8_6);
          compose(&(v3_10),&(v8_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v12_10 = Space::new();
      let mut v12_10_cursor = (v0_24_tail).read_zipper();
      for v12_10_byte in v12_10_cursor.child_mask().iter() {
        v12_10_cursor.descend_to_byte(v12_10_byte);
        {
        let v12_10_tail = v12_10_cursor.fork_read_zipper();
        let v12_10_head = Path::from_slice(&[v12_10_byte]);
        let v13_2: Space = singleton(&(v12_10_head));
        let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v0_24_head),&(v12_10_head));
          let mut v14_7 = Space::new();
          let mut v14_7_cursor = (v12_10_tail).read_zipper();
          for v14_7_byte in v14_7_cursor.child_mask().iter() {
            v14_7_cursor.descend_to_byte(v14_7_byte);
            {
            let v14_7_tail = v14_7_cursor.fork_read_zipper();
            let v14_7_head = Path::from_slice(&[v14_7_byte]);
            let v15_2: Space = singleton(&(v14_7_head));
            let v15_3: Space = intersect(&(*CONSTANT_2),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_1),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v16_7: Space = routine_1(c, &(v16_6), &(v14_7_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_2),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v17_11: Space = routine_2(c, &(v17_6), &(v14_7_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            v14_7.join_into((v15_13).clone());
            }
            v14_7_cursor.ascend(1);
          }
          drop(v14_7_cursor);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v0_24_head),&(v12_10_head));
          let mut v18_11 = Space::new();
          let mut v18_11_cursor = (v12_10_tail).read_zipper();
          for v18_11_byte in v18_11_cursor.child_mask().iter() {
            v18_11_cursor.descend_to_byte(v18_11_byte);
            {
            let v18_11_tail = v18_11_cursor.fork_read_zipper();
            let v18_11_head = Path::from_slice(&[v18_11_byte]);
            let v19_2: Space = singleton(&(v18_11_head));
            let v19_3: Space = intersect(&(*CONSTANT_2),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_1),&(v19_4));
            drop(v19_4);
            let v19_7: Space = if (v19_5).is_empty() { Space::new() } else {
              let v20_6: Space = routine_4(c, &(v18_11_head), &(v18_6), &(v18_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v19_5),&(v20_6))
            };
            drop(v19_5);
            let v19_8: Space = intersect(&(*CONSTANT_2),&(v19_2));
            drop(v19_2);
            let v19_9: Space = if has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
            drop(v19_8);
            let v19_11: Space = if (v19_9).is_empty() { Space::new() } else {
              let v21_10: Space = routine_5(c, &(v18_11_head), &(v18_6), &(v18_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v19_9),&(v21_10))
            };
            drop(v19_9);
            let v19_12: Space = unite(&(v19_7),&(v19_11));
            v18_11.join_into((v19_12).clone());
            }
            v18_11_cursor.ascend(1);
          }
          drop(v18_11_cursor);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_10.join_into((v13_13).clone());
        }
        v12_10_cursor.ascend(1);
      }
      drop(v12_10_cursor);
      compose(&(v1_9),&(v12_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_24.join_into((v1_12).clone());
    }
    v0_24_cursor.ascend(1);
  }
  drop(v0_24_cursor);
  drop(v0_2);
  let v0_26: Space = wrap(&(v0_24),&(*CONSTANT_3));
  (v0_26).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v22_24 = Space::new();
  let mut v22_24_cursor = (*s0).read_zipper();
  for v22_24_byte in v22_24_cursor.child_mask().iter() {
    v22_24_cursor.descend_to_byte(v22_24_byte);
    {
    let v22_24_tail = v22_24_cursor.fork_read_zipper();
    let v22_24_head = Path::from_slice(&[v22_24_byte]);
    let v23_2: Space = singleton(&(v22_24_head));
    let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
    let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
    drop(v23_3);
    let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
    drop(v23_4);
    let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
      let v24_6: Path = concat_path(&(*p0),&(v22_24_head));
      let mut v24_7 = Space::new();
      let mut v24_7_cursor = (v22_24_tail).read_zipper();
      for v24_7_byte in v24_7_cursor.child_mask().iter() {
        v24_7_cursor.descend_to_byte(v24_7_byte);
        {
        let v24_7_tail = v24_7_cursor.fork_read_zipper();
        let v24_7_head = Path::from_slice(&[v24_7_byte]);
        let v25_2: Space = singleton(&(v24_7_head));
        let v25_3: Space = intersect(&(*CONSTANT_2),&(v25_2));
        let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
        drop(v25_3);
        let v25_5: Space = subtract(&(*CONSTANT_1),&(v25_4));
        drop(v25_4);
        let v25_8: Space = if (v25_5).is_empty() { Space::new() } else {
          let v26_6: Path = concat_path(&(v24_6),&(v24_7_head));
          let mut v26_7 = Space::new();
          let mut v26_7_cursor = (v24_7_tail).read_zipper();
          for v26_7_byte in v26_7_cursor.child_mask().iter() {
            v26_7_cursor.descend_to_byte(v26_7_byte);
            {
            let v26_7_tail = v26_7_cursor.fork_read_zipper();
            let v26_7_head = Path::from_slice(&[v26_7_byte]);
            let v27_2: Space = singleton(&(v26_7_head));
            let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
            let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
            drop(v27_3);
            let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
            drop(v27_4);
            let v27_8: Space = if (v27_5).is_empty() { Space::new() } else {
              let v28_6: Path = concat_path(&(v26_6),&(v26_7_head));
              let v28_7: Space = routine_6(c, &(v28_6), &(v26_7_tail).make_space(), &(*s1));
              compose(&(v27_5),&(v28_7))
            };
            drop(v27_5);
            let v27_9: Space = intersect(&(*CONSTANT_2),&(v27_2));
            drop(v27_2);
            let v27_10: Space = if has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
            drop(v27_9);
            let v27_12: Space = if (v27_10).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v26_6),&(v26_7_head));
              let v29_11: Space = routine_7(c, &(v29_6), &(v26_7_tail).make_space(), &(*s1));
              drop(v29_6);
              compose(&(v27_10),&(v29_11))
            };
            drop(v27_10);
            let v27_13: Space = unite(&(v27_8),&(v27_12));
            v26_7.join_into((v27_13).clone());
            }
            v26_7_cursor.ascend(1);
          }
          drop(v26_7_cursor);
          compose(&(v25_5),&(v26_7))
        };
        drop(v25_5);
        let v25_9: Space = intersect(&(*CONSTANT_2),&(v25_2));
        drop(v25_2);
        let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
        drop(v25_9);
        let v25_12: Space = if (v25_10).is_empty() { Space::new() } else {
          let v30_6: Path = concat_path(&(v24_6),&(v24_7_head));
          let mut v30_11 = Space::new();
          let mut v30_11_cursor = (v24_7_tail).read_zipper();
          for v30_11_byte in v30_11_cursor.child_mask().iter() {
            v30_11_cursor.descend_to_byte(v30_11_byte);
            {
            let v30_11_tail = v30_11_cursor.fork_read_zipper();
            let v30_11_head = Path::from_slice(&[v30_11_byte]);
            let v31_2: Space = singleton(&(v30_11_head));
            let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
            let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
            drop(v31_3);
            let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
            drop(v31_4);
            let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
              let v32_6: Path = concat_path(&(v30_6),&(v30_11_head));
              let v32_7: Space = routine_6(c, &(v32_6), &(v30_11_tail).make_space(), &(*s1));
              compose(&(v31_5),&(v32_7))
            };
            drop(v31_5);
            let v31_9: Space = intersect(&(*CONSTANT_2),&(v31_2));
            drop(v31_2);
            let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
            drop(v31_9);
            let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v30_6),&(v30_11_head));
              let v33_11: Space = routine_3(c, &(v33_6), &(v30_11_tail).make_space(), &(*s1));
              drop(v33_6);
              compose(&(v31_10),&(v33_11))
            };
            drop(v31_10);
            let v31_13: Space = unite(&(v31_8),&(v31_12));
            v30_11.join_into((v31_13).clone());
            }
            v30_11_cursor.ascend(1);
          }
          drop(v30_11_cursor);
          drop(v30_6);
          compose(&(v25_10),&(v30_11))
        };
        drop(v25_10);
        let v25_13: Space = unite(&(v25_8),&(v25_12));
        v24_7.join_into((v25_13).clone());
        }
        v24_7_cursor.ascend(1);
      }
      drop(v24_7_cursor);
      compose(&(v23_5),&(v24_7))
    };
    drop(v23_5);
    let v23_9: Space = intersect(&(*CONSTANT_2),&(v23_2));
    drop(v23_2);
    let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
    drop(v23_9);
    let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&(v22_24_head));
      let mut v34_11 = Space::new();
      let mut v34_11_cursor = (v22_24_tail).read_zipper();
      for v34_11_byte in v34_11_cursor.child_mask().iter() {
        v34_11_cursor.descend_to_byte(v34_11_byte);
        {
        let v34_11_tail = v34_11_cursor.fork_read_zipper();
        let v34_11_head = Path::from_slice(&[v34_11_byte]);
        let v35_2: Space = singleton(&(v34_11_head));
        let v35_3: Space = intersect(&(*CONSTANT_2),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_1),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let mut v36_7 = Space::new();
          let mut v36_7_cursor = (v34_11_tail).read_zipper();
          for v36_7_byte in v36_7_cursor.child_mask().iter() {
            v36_7_cursor.descend_to_byte(v36_7_byte);
            {
            let v36_7_tail = v36_7_cursor.fork_read_zipper();
            let v36_7_head = Path::from_slice(&[v36_7_byte]);
            let v37_2: Space = singleton(&(v36_7_head));
            let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
            let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
            drop(v37_3);
            let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
            drop(v37_4);
            let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
              let v38_6: Path = concat_path(&(v36_6),&(v36_7_head));
              let v38_7: Space = routine_6(c, &(v38_6), &(v36_7_tail).make_space(), &(*s1));
              compose(&(v37_5),&(v38_7))
            };
            drop(v37_5);
            let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
            drop(v37_2);
            let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
            drop(v37_9);
            let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v36_6),&(v36_7_head));
              let v39_11: Space = routine_7(c, &(v39_6), &(v36_7_tail).make_space(), &(*s1));
              drop(v39_6);
              compose(&(v37_10),&(v39_11))
            };
            drop(v37_10);
            let v37_13: Space = unite(&(v37_8),&(v37_12));
            v36_7.join_into((v37_13).clone());
            }
            v36_7_cursor.ascend(1);
          }
          drop(v36_7_cursor);
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_2),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let mut v40_11 = Space::new();
          let mut v40_11_cursor = (v34_11_tail).read_zipper();
          for v40_11_byte in v40_11_cursor.child_mask().iter() {
            v40_11_cursor.descend_to_byte(v40_11_byte);
            {
            let v40_11_tail = v40_11_cursor.fork_read_zipper();
            let v40_11_head = Path::from_slice(&[v40_11_byte]);
            let v41_2: Space = singleton(&(v40_11_head));
            let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
            drop(v41_4);
            let v41_7: Space = if (v41_5).is_empty() { Space::new() } else {
              let v42_6: Space = routine_4(c, &(v40_11_head), &(v40_6), &(v40_11_tail).make_space(), &(*s1));
              compose(&(v41_5),&(v42_6))
            };
            drop(v41_5);
            let v41_8: Space = intersect(&(*CONSTANT_2),&(v41_2));
            drop(v41_2);
            let v41_9: Space = if has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
            drop(v41_8);
            let v41_11: Space = if (v41_9).is_empty() { Space::new() } else {
              let v43_10: Space = routine_5(c, &(v40_11_head), &(v40_6), &(v40_11_tail).make_space(), &(*s1));
              compose(&(v41_9),&(v43_10))
            };
            drop(v41_9);
            let v41_12: Space = unite(&(v41_7),&(v41_11));
            v40_11.join_into((v41_12).clone());
            }
            v40_11_cursor.ascend(1);
          }
          drop(v40_11_cursor);
          drop(v40_6);
          compose(&(v35_10),&(v40_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        v34_11.join_into((v35_13).clone());
        }
        v34_11_cursor.ascend(1);
      }
      drop(v34_11_cursor);
      drop(v34_6);
      compose(&(v23_10),&(v34_11))
    };
    drop(v23_10);
    let v23_13: Space = unite(&(v23_8),&(v23_12));
    v22_24.join_into((v23_13).clone());
    }
    v22_24_cursor.ascend(1);
  }
  drop(v22_24_cursor);
  (v22_24).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v44_24 = Space::new();
  let mut v44_24_cursor = (*s0).read_zipper();
  for v44_24_byte in v44_24_cursor.child_mask().iter() {
    v44_24_cursor.descend_to_byte(v44_24_byte);
    {
    let v44_24_tail = v44_24_cursor.fork_read_zipper();
    let v44_24_head = Path::from_slice(&[v44_24_byte]);
    let v45_2: Space = singleton(&(v44_24_head));
    let v45_3: Space = intersect(&(*CONSTANT_2),&(v45_2));
    let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = subtract(&(*CONSTANT_1),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v44_24_head));
      let mut v46_7 = Space::new();
      let mut v46_7_cursor = (v44_24_tail).read_zipper();
      for v46_7_byte in v46_7_cursor.child_mask().iter() {
        v46_7_cursor.descend_to_byte(v46_7_byte);
        {
        let v46_7_tail = v46_7_cursor.fork_read_zipper();
        let v46_7_head = Path::from_slice(&[v46_7_byte]);
        let v47_2: Space = singleton(&(v46_7_head));
        let v47_3: Space = intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (v47_5).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&(v46_7_head));
          let mut v48_7 = Space::new();
          let mut v48_7_cursor = (v46_7_tail).read_zipper();
          for v48_7_byte in v48_7_cursor.child_mask().iter() {
            v48_7_cursor.descend_to_byte(v48_7_byte);
            {
            let v48_7_tail = v48_7_cursor.fork_read_zipper();
            let v48_7_head = Path::from_slice(&[v48_7_byte]);
            let v49_2: Space = singleton(&(v48_7_head));
            let v49_3: Space = intersect(&(*CONSTANT_2),&(v49_2));
            let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
            drop(v49_3);
            let v49_5: Space = subtract(&(*CONSTANT_1),&(v49_4));
            drop(v49_4);
            let v49_8: Space = if (v49_5).is_empty() { Space::new() } else {
              let v50_6: Path = concat_path(&(v48_6),&(v48_7_head));
              let v50_7: Space = routine_6(c, &(v50_6), &(v48_7_tail).make_space(), &(*s1));
              compose(&(v49_5),&(v50_7))
            };
            drop(v49_5);
            let v49_9: Space = intersect(&(*CONSTANT_2),&(v49_2));
            drop(v49_2);
            let v49_10: Space = if has_head(&(v49_9)) { singleton(&[]) } else { Space::new() };
            drop(v49_9);
            let v49_12: Space = if (v49_10).is_empty() { Space::new() } else {
              let v51_6: Path = concat_path(&(v48_6),&(v48_7_head));
              let v51_11: Space = routine_7(c, &(v51_6), &(v48_7_tail).make_space(), &(*s1));
              drop(v51_6);
              compose(&(v49_10),&(v51_11))
            };
            drop(v49_10);
            let v49_13: Space = unite(&(v49_8),&(v49_12));
            v48_7.join_into((v49_13).clone());
            }
            v48_7_cursor.ascend(1);
          }
          drop(v48_7_cursor);
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (v47_10).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v46_6),&(v46_7_head));
          let mut v52_11 = Space::new();
          let mut v52_11_cursor = (v46_7_tail).read_zipper();
          for v52_11_byte in v52_11_cursor.child_mask().iter() {
            v52_11_cursor.descend_to_byte(v52_11_byte);
            {
            let v52_11_tail = v52_11_cursor.fork_read_zipper();
            let v52_11_head = Path::from_slice(&[v52_11_byte]);
            let v53_2: Space = singleton(&(v52_11_head));
            let v53_3: Space = intersect(&(*CONSTANT_2),&(v53_2));
            let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
            drop(v53_3);
            let v53_5: Space = subtract(&(*CONSTANT_1),&(v53_4));
            drop(v53_4);
            let v53_8: Space = if (v53_5).is_empty() { Space::new() } else {
              let v54_6: Path = concat_path(&(v52_6),&(v52_11_head));
              let v54_7: Space = routine_6(c, &(v54_6), &(v52_11_tail).make_space(), &(*s1));
              compose(&(v53_5),&(v54_7))
            };
            drop(v53_5);
            let v53_9: Space = intersect(&(*CONSTANT_2),&(v53_2));
            drop(v53_2);
            let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
            drop(v53_9);
            let v53_12: Space = if (v53_10).is_empty() { Space::new() } else {
              let v55_6: Path = concat_path(&(v52_6),&(v52_11_head));
              let v55_11: Space = routine_3(c, &(v55_6), &(v52_11_tail).make_space(), &(*s1));
              drop(v55_6);
              compose(&(v53_10),&(v55_11))
            };
            drop(v53_10);
            let v53_13: Space = unite(&(v53_8),&(v53_12));
            v52_11.join_into((v53_13).clone());
            }
            v52_11_cursor.ascend(1);
          }
          drop(v52_11_cursor);
          drop(v52_6);
          compose(&(v47_10),&(v52_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        v46_7.join_into((v47_13).clone());
        }
        v46_7_cursor.ascend(1);
      }
      drop(v46_7_cursor);
      compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = intersect(&(*CONSTANT_2),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_12: Space = if (v45_10).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&(v44_24_head));
      let mut v56_11 = Space::new();
      let mut v56_11_cursor = (v44_24_tail).read_zipper();
      for v56_11_byte in v56_11_cursor.child_mask().iter() {
        v56_11_cursor.descend_to_byte(v56_11_byte);
        {
        let v56_11_tail = v56_11_cursor.fork_read_zipper();
        let v56_11_head = Path::from_slice(&[v56_11_byte]);
        let v57_2: Space = singleton(&(v56_11_head));
        let v57_3: Space = intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
          let mut v58_6 = Space::new();
          let mut v58_6_cursor = (v56_11_tail).read_zipper();
          for v58_6_byte in v58_6_cursor.child_mask().iter() {
            v58_6_cursor.descend_to_byte(v58_6_byte);
            {
            let v58_6_tail = v58_6_cursor.fork_read_zipper();
            let v58_6_head = Path::from_slice(&[v58_6_byte]);
            let v59_2: Space = singleton(&(v58_6_head));
            let v59_3: Space = intersect(&(*CONSTANT_2),&(v59_2));
            let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
            drop(v59_3);
            let v59_5: Space = subtract(&(*CONSTANT_1),&(v59_4));
            drop(v59_4);
            let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
              let v60_6: Path = concat_path(&(v56_11_head),&(v58_6_head));
              let v60_7: Space = routine_8(c, &(v60_6), &(v56_6), &(v58_6_tail).make_space(), &(*s1));
              compose(&(v59_5),&(v60_7))
            };
            drop(v59_5);
            let v59_9: Space = intersect(&(*CONSTANT_2),&(v59_2));
            drop(v59_2);
            let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
            drop(v59_9);
            let v59_12: Space = if (v59_10).is_empty() { Space::new() } else {
              let v61_6: Path = concat_path(&(v56_11_head),&(v58_6_head));
              let v61_11: Space = routine_9(c, &(v61_6), &(v56_6), &(v58_6_tail).make_space(), &(*s1));
              drop(v61_6);
              compose(&(v59_10),&(v61_11))
            };
            drop(v59_10);
            let v59_13: Space = unite(&(v59_8),&(v59_12));
            v58_6.join_into((v59_13).clone());
            }
            v58_6_cursor.ascend(1);
          }
          drop(v58_6_cursor);
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
          let mut v62_10 = Space::new();
          let mut v62_10_cursor = (v56_11_tail).read_zipper();
          for v62_10_byte in v62_10_cursor.child_mask().iter() {
            v62_10_cursor.descend_to_byte(v62_10_byte);
            {
            let v62_10_tail = v62_10_cursor.fork_read_zipper();
            let v62_10_head = Path::from_slice(&[v62_10_byte]);
            let v63_2: Space = singleton(&(v62_10_head));
            let v63_3: Space = intersect(&(*CONSTANT_2),&(v63_2));
            let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
            drop(v63_3);
            let v63_5: Space = subtract(&(*CONSTANT_1),&(v63_4));
            drop(v63_4);
            let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
              let v64_6: Path = concat_path(&(v56_11_head),&(v62_10_head));
              let v64_7: Space = routine_8(c, &(v64_6), &(v56_6), &(v62_10_tail).make_space(), &(*s1));
              compose(&(v63_5),&(v64_7))
            };
            drop(v63_5);
            let v63_9: Space = intersect(&(*CONSTANT_2),&(v63_2));
            drop(v63_2);
            let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
            drop(v63_9);
            let v63_12: Space = if (v63_10).is_empty() { Space::new() } else {
              let v65_6: Path = concat_path(&(v56_11_head),&(v62_10_head));
              let v65_11: Space = routine_10(c, &(v65_6), &(v56_6), &(v62_10_tail).make_space(), &(*s1));
              drop(v65_6);
              compose(&(v63_10),&(v65_11))
            };
            drop(v63_10);
            let v63_13: Space = unite(&(v63_8),&(v63_12));
            v62_10.join_into((v63_13).clone());
            }
            v62_10_cursor.ascend(1);
          }
          drop(v62_10_cursor);
          compose(&(v57_9),&(v62_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        v56_11.join_into((v57_12).clone());
        }
        v56_11_cursor.ascend(1);
      }
      drop(v56_11_cursor);
      drop(v56_6);
      compose(&(v45_10),&(v56_11))
    };
    drop(v45_10);
    let v45_13: Space = unite(&(v45_8),&(v45_12));
    v44_24.join_into((v45_13).clone());
    }
    v44_24_cursor.ascend(1);
  }
  drop(v44_24_cursor);
  (v44_24).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v66_19: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let mut v66_23 = Space::new();
  let mut v66_23_cursor = (*s0).read_zipper();
  for v66_23_byte in v66_23_cursor.child_mask().iter() {
    v66_23_cursor.descend_to_byte(v66_23_byte);
    {
    let v66_23_tail = v66_23_cursor.fork_read_zipper();
    let v66_23_head = Path::from_slice(&[v66_23_byte]);
    let v67_2: Space = singleton(&(v66_23_head));
    let v67_3: Space = intersect(&(*CONSTANT_2),&(v67_2));
    let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = subtract(&(*CONSTANT_1),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (v67_5).is_empty() { Space::new() } else {
      let mut v68_6 = Space::new();
      let mut v68_6_cursor = (v66_23_tail).read_zipper();
      for v68_6_byte in v68_6_cursor.child_mask().iter() {
        v68_6_cursor.descend_to_byte(v68_6_byte);
        {
        let v68_6_tail = v68_6_cursor.fork_read_zipper();
        let v68_6_head = Path::from_slice(&[v68_6_byte]);
        let v69_2: Space = singleton(&(v68_6_head));
        let v69_3: Space = intersect(&(*CONSTANT_2),&(v69_2));
        let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = subtract(&(*CONSTANT_1),&(v69_4));
        drop(v69_4);
        let v69_8: Space = if (v69_5).is_empty() { Space::new() } else {
          let v70_6: Path = concat_path(&(v66_23_head),&(v68_6_head));
          let mut v70_7 = Space::new();
          let mut v70_7_cursor = (v68_6_tail).read_zipper();
          for v70_7_byte in v70_7_cursor.child_mask().iter() {
            v70_7_cursor.descend_to_byte(v70_7_byte);
            {
            let v70_7_tail = v70_7_cursor.fork_read_zipper();
            let v70_7_head = Path::from_slice(&[v70_7_byte]);
            let v71_2: Space = singleton(&(v70_7_head));
            let v71_3: Space = intersect(&(*CONSTANT_2),&(v71_2));
            let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
            drop(v71_3);
            let v71_5: Space = subtract(&(*CONSTANT_1),&(v71_4));
            drop(v71_4);
            let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
              let v72_6: Path = concat_path(&(v70_6),&(v70_7_head));
              let v72_7: Space = routine_11(c, &(v72_6), &(*p0), &(v70_7_tail).make_space(), &(*s1));
              compose(&(v71_5),&(v72_7))
            };
            drop(v71_5);
            let v71_9: Space = intersect(&(*CONSTANT_2),&(v71_2));
            drop(v71_2);
            let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
            drop(v71_9);
            let v71_12: Space = if (v71_10).is_empty() { Space::new() } else {
              let v73_6: Path = concat_path(&(v70_6),&(v70_7_head));
              let v73_11: Space = routine_12(c, &(v73_6), &(*p0), &(v70_7_tail).make_space(), &(*s1));
              drop(v73_6);
              compose(&(v71_10),&(v73_11))
            };
            drop(v71_10);
            let v71_13: Space = unite(&(v71_8),&(v71_12));
            v70_7.join_into((v71_13).clone());
            }
            v70_7_cursor.ascend(1);
          }
          drop(v70_7_cursor);
          compose(&(v69_5),&(v70_7))
        };
        drop(v69_5);
        let v69_9: Space = intersect(&(*CONSTANT_2),&(v69_2));
        drop(v69_2);
        let v69_10: Space = if has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
        drop(v69_9);
        let v69_12: Space = if (v69_10).is_empty() { Space::new() } else {
          let v74_6: Path = concat_path(&(v66_23_head),&(v68_6_head));
          let mut v74_11 = Space::new();
          let mut v74_11_cursor = (v68_6_tail).read_zipper();
          for v74_11_byte in v74_11_cursor.child_mask().iter() {
            v74_11_cursor.descend_to_byte(v74_11_byte);
            {
            let v74_11_tail = v74_11_cursor.fork_read_zipper();
            let v74_11_head = Path::from_slice(&[v74_11_byte]);
            let v75_2: Space = singleton(&(v74_11_head));
            let v75_3: Space = intersect(&(*CONSTANT_2),&(v75_2));
            let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
            drop(v75_3);
            let v75_5: Space = subtract(&(*CONSTANT_1),&(v75_4));
            drop(v75_4);
            let v75_8: Space = if (v75_5).is_empty() { Space::new() } else {
              let v76_6: Path = concat_path(&(v74_6),&(v74_11_head));
              let v76_7: Space = routine_11(c, &(v76_6), &(*p0), &(v74_11_tail).make_space(), &(*s1));
              compose(&(v75_5),&(v76_7))
            };
            drop(v75_5);
            let v75_9: Space = intersect(&(*CONSTANT_2),&(v75_2));
            drop(v75_2);
            let v75_10: Space = if has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
            drop(v75_9);
            let v75_12: Space = if (v75_10).is_empty() { Space::new() } else {
              let v77_6: Path = concat_path(&(v74_6),&(v74_11_head));
              let v77_11: Space = routine_10(c, &(v77_6), &(*p0), &(v74_11_tail).make_space(), &(*s1));
              drop(v77_6);
              compose(&(v75_10),&(v77_11))
            };
            drop(v75_10);
            let v75_13: Space = unite(&(v75_8),&(v75_12));
            v74_11.join_into((v75_13).clone());
            }
            v74_11_cursor.ascend(1);
          }
          drop(v74_11_cursor);
          drop(v74_6);
          compose(&(v69_10),&(v74_11))
        };
        drop(v69_10);
        let v69_13: Space = unite(&(v69_8),&(v69_12));
        v68_6.join_into((v69_13).clone());
        }
        v68_6_cursor.ascend(1);
      }
      drop(v68_6_cursor);
      compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = intersect(&(*CONSTANT_2),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_12: Space = if (v67_9).is_empty() { Space::new() } else {
      let v78_10: Space = unwrap(&(v66_19),&(v66_23_head));
      let mut v78_11 = Space::new();
      let mut v78_11_cursor = (v66_23_tail).read_zipper();
      for v78_11_byte in v78_11_cursor.child_mask().iter() {
        v78_11_cursor.descend_to_byte(v78_11_byte);
        {
        let v78_11_tail = v78_11_cursor.fork_read_zipper();
        let v78_11_head = Path::from_slice(&[v78_11_byte]);
        let v79_2: Space = singleton(&(v78_11_head));
        let v79_3: Space = intersect(&(*CONSTANT_2),&(v79_2));
        let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
        drop(v79_3);
        let v79_5: Space = subtract(&(*CONSTANT_1),&(v79_4));
        drop(v79_4);
        let v79_8: Space = if (v79_5).is_empty() { Space::new() } else {
          let v80_6: Path = concat_path(&(v66_23_head),&(v78_11_head));
          let mut v80_7 = Space::new();
          let mut v80_7_cursor = (v78_11_tail).read_zipper();
          for v80_7_byte in v80_7_cursor.child_mask().iter() {
            v80_7_cursor.descend_to_byte(v80_7_byte);
            {
            let v80_7_tail = v80_7_cursor.fork_read_zipper();
            let v80_7_head = Path::from_slice(&[v80_7_byte]);
            let v81_2: Space = singleton(&(v80_7_head));
            let v81_3: Space = intersect(&(*CONSTANT_2),&(v81_2));
            let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
            drop(v81_3);
            let v81_5: Space = subtract(&(*CONSTANT_1),&(v81_4));
            drop(v81_4);
            let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
              let v82_6: Path = concat_path(&(v80_6),&(v80_7_head));
              let v82_7: Space = routine_11(c, &(v82_6), &(*p0), &(v80_7_tail).make_space(), &(*s1));
              compose(&(v81_5),&(v82_7))
            };
            drop(v81_5);
            let v81_9: Space = intersect(&(*CONSTANT_2),&(v81_2));
            drop(v81_2);
            let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
            drop(v81_9);
            let v81_12: Space = if (v81_10).is_empty() { Space::new() } else {
              let v83_6: Path = concat_path(&(v80_6),&(v80_7_head));
              let v83_11: Space = routine_12(c, &(v83_6), &(*p0), &(v80_7_tail).make_space(), &(*s1));
              drop(v83_6);
              compose(&(v81_10),&(v83_11))
            };
            drop(v81_10);
            let v81_13: Space = unite(&(v81_8),&(v81_12));
            v80_7.join_into((v81_13).clone());
            }
            v80_7_cursor.ascend(1);
          }
          drop(v80_7_cursor);
          compose(&(v79_5),&(v80_7))
        };
        drop(v79_5);
        let v79_9: Space = intersect(&(*CONSTANT_2),&(v79_2));
        drop(v79_2);
        let v79_10: Space = if has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
        drop(v79_9);
        let v79_13: Space = if (v79_10).is_empty() { Space::new() } else {
          let v84_11: Space = unwrap(&(v78_10),&(v78_11_head));
          let v84_12: Space = unwrap(&(v84_11),&(*p0));
          drop(v84_11);
          compose(&(v79_10),&(v84_12))
        };
        drop(v79_10);
        let v85_6: Path = concat_path(&(v66_23_head),&(v78_11_head));
        let v79_14: Space = wrap(&(v79_13),&(v85_6));
        drop(v79_13);
        let v79_15: Space = wrap(&(v79_14),&(*p0));
        drop(v79_14);
        let v79_16: Space = unite(&(v79_8),&(v79_15));
        drop(v79_15);
        v78_11.join_into((v79_16).clone());
        }
        v78_11_cursor.ascend(1);
      }
      drop(v78_11_cursor);
      drop(v78_10);
      compose(&(v67_9),&(v78_11))
    };
    drop(v67_9);
    let v67_13: Space = unite(&(v67_7),&(v67_12));
    v66_23.join_into((v67_13).clone());
    }
    v66_23_cursor.ascend(1);
  }
  drop(v66_23_cursor);
  drop(v66_19);
  (v66_23).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v86_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v86_21: Space = unwrap(&(v86_20),&(*p0));
  drop(v86_20);
  let mut v86_25 = Space::new();
  let mut v86_25_cursor = (*s0).read_zipper();
  for v86_25_byte in v86_25_cursor.child_mask().iter() {
    v86_25_cursor.descend_to_byte(v86_25_byte);
    {
    let v86_25_tail = v86_25_cursor.fork_read_zipper();
    let v86_25_head = Path::from_slice(&[v86_25_byte]);
    let v87_2: Space = singleton(&(v86_25_head));
    let v87_3: Space = intersect(&(*CONSTANT_2),&(v87_2));
    let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
    drop(v87_3);
    let v87_5: Space = subtract(&(*CONSTANT_1),&(v87_4));
    drop(v87_4);
    let v87_8: Space = if (v87_5).is_empty() { Space::new() } else {
      let v88_6: Path = concat_path(&(*p0),&(v86_25_head));
      let mut v88_7 = Space::new();
      let mut v88_7_cursor = (v86_25_tail).read_zipper();
      for v88_7_byte in v88_7_cursor.child_mask().iter() {
        v88_7_cursor.descend_to_byte(v88_7_byte);
        {
        let v88_7_tail = v88_7_cursor.fork_read_zipper();
        let v88_7_head = Path::from_slice(&[v88_7_byte]);
        let v89_2: Space = singleton(&(v88_7_head));
        let v89_3: Space = intersect(&(*CONSTANT_2),&(v89_2));
        let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
        drop(v89_3);
        let v89_5: Space = subtract(&(*CONSTANT_1),&(v89_4));
        drop(v89_4);
        let v89_8: Space = if (v89_5).is_empty() { Space::new() } else {
          let v90_6: Path = concat_path(&(v88_6),&(v88_7_head));
          let mut v90_7 = Space::new();
          let mut v90_7_cursor = (v88_7_tail).read_zipper();
          for v90_7_byte in v90_7_cursor.child_mask().iter() {
            v90_7_cursor.descend_to_byte(v90_7_byte);
            {
            let v90_7_tail = v90_7_cursor.fork_read_zipper();
            let v90_7_head = Path::from_slice(&[v90_7_byte]);
            let v91_2: Space = singleton(&(v90_7_head));
            let v91_3: Space = intersect(&(*CONSTANT_2),&(v91_2));
            let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
            drop(v91_3);
            let v91_5: Space = subtract(&(*CONSTANT_1),&(v91_4));
            drop(v91_4);
            let v91_8: Space = if (v91_5).is_empty() { Space::new() } else {
              let v92_6: Path = concat_path(&(v90_6),&(v90_7_head));
              let v92_7: Space = routine_13(c, &(v92_6), &(*p1), &(v90_7_tail).make_space(), &(*s1));
              compose(&(v91_5),&(v92_7))
            };
            drop(v91_5);
            let v91_9: Space = intersect(&(*CONSTANT_2),&(v91_2));
            drop(v91_2);
            let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
            drop(v91_9);
            let v91_12: Space = if (v91_10).is_empty() { Space::new() } else {
              let v93_6: Path = concat_path(&(v90_6),&(v90_7_head));
              let v93_11: Space = routine_14(c, &(v93_6), &(*p1), &(v90_7_tail).make_space(), &(*s1));
              drop(v93_6);
              compose(&(v91_10),&(v93_11))
            };
            drop(v91_10);
            let v91_13: Space = unite(&(v91_8),&(v91_12));
            v90_7.join_into((v91_13).clone());
            }
            v90_7_cursor.ascend(1);
          }
          drop(v90_7_cursor);
          compose(&(v89_5),&(v90_7))
        };
        drop(v89_5);
        let v89_9: Space = intersect(&(*CONSTANT_2),&(v89_2));
        drop(v89_2);
        let v89_10: Space = if has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
        drop(v89_9);
        let v89_12: Space = if (v89_10).is_empty() { Space::new() } else {
          let v94_6: Path = concat_path(&(v88_6),&(v88_7_head));
          let mut v94_11 = Space::new();
          let mut v94_11_cursor = (v88_7_tail).read_zipper();
          for v94_11_byte in v94_11_cursor.child_mask().iter() {
            v94_11_cursor.descend_to_byte(v94_11_byte);
            {
            let v94_11_tail = v94_11_cursor.fork_read_zipper();
            let v94_11_head = Path::from_slice(&[v94_11_byte]);
            let v95_2: Space = singleton(&(v94_11_head));
            let v95_3: Space = intersect(&(*CONSTANT_2),&(v95_2));
            let v95_4: Space = if has_head(&(v95_3)) { singleton(&[]) } else { Space::new() };
            drop(v95_3);
            let v95_5: Space = subtract(&(*CONSTANT_1),&(v95_4));
            drop(v95_4);
            let v95_8: Space = if (v95_5).is_empty() { Space::new() } else {
              let v96_6: Path = concat_path(&(v94_6),&(v94_11_head));
              let v96_7: Space = routine_13(c, &(v96_6), &(*p1), &(v94_11_tail).make_space(), &(*s1));
              compose(&(v95_5),&(v96_7))
            };
            drop(v95_5);
            let v95_9: Space = intersect(&(*CONSTANT_2),&(v95_2));
            drop(v95_2);
            let v95_10: Space = if has_head(&(v95_9)) { singleton(&[]) } else { Space::new() };
            drop(v95_9);
            let v95_12: Space = if (v95_10).is_empty() { Space::new() } else {
              let v97_6: Path = concat_path(&(v94_6),&(v94_11_head));
              let v97_11: Space = routine_10(c, &(v97_6), &(*p1), &(v94_11_tail).make_space(), &(*s1));
              drop(v97_6);
              compose(&(v95_10),&(v97_11))
            };
            drop(v95_10);
            let v95_13: Space = unite(&(v95_8),&(v95_12));
            v94_11.join_into((v95_13).clone());
            }
            v94_11_cursor.ascend(1);
          }
          drop(v94_11_cursor);
          drop(v94_6);
          compose(&(v89_10),&(v94_11))
        };
        drop(v89_10);
        let v89_13: Space = unite(&(v89_8),&(v89_12));
        v88_7.join_into((v89_13).clone());
        }
        v88_7_cursor.ascend(1);
      }
      drop(v88_7_cursor);
      compose(&(v87_5),&(v88_7))
    };
    drop(v87_5);
    let v87_9: Space = intersect(&(*CONSTANT_2),&(v87_2));
    drop(v87_2);
    let v87_10: Space = if has_head(&(v87_9)) { singleton(&[]) } else { Space::new() };
    drop(v87_9);
    let v87_13: Space = if (v87_10).is_empty() { Space::new() } else {
      let v98_6: Path = concat_path(&(*p0),&(v86_25_head));
      let v98_11: Space = unwrap(&(v86_21),&(v86_25_head));
      let mut v98_12 = Space::new();
      let mut v98_12_cursor = (v86_25_tail).read_zipper();
      for v98_12_byte in v98_12_cursor.child_mask().iter() {
        v98_12_cursor.descend_to_byte(v98_12_byte);
        {
        let v98_12_tail = v98_12_cursor.fork_read_zipper();
        let v98_12_head = Path::from_slice(&[v98_12_byte]);
        let v99_2: Space = singleton(&(v98_12_head));
        let v99_3: Space = intersect(&(*CONSTANT_2),&(v99_2));
        let v99_4: Space = if has_head(&(v99_3)) { singleton(&[]) } else { Space::new() };
        drop(v99_3);
        let v99_5: Space = subtract(&(*CONSTANT_1),&(v99_4));
        drop(v99_4);
        let v99_8: Space = if (v99_5).is_empty() { Space::new() } else {
          let v100_6: Path = concat_path(&(v98_6),&(v98_12_head));
          let mut v100_7 = Space::new();
          let mut v100_7_cursor = (v98_12_tail).read_zipper();
          for v100_7_byte in v100_7_cursor.child_mask().iter() {
            v100_7_cursor.descend_to_byte(v100_7_byte);
            {
            let v100_7_tail = v100_7_cursor.fork_read_zipper();
            let v100_7_head = Path::from_slice(&[v100_7_byte]);
            let v101_2: Space = singleton(&(v100_7_head));
            let v101_3: Space = intersect(&(*CONSTANT_2),&(v101_2));
            let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
            drop(v101_3);
            let v101_5: Space = subtract(&(*CONSTANT_1),&(v101_4));
            drop(v101_4);
            let v101_8: Space = if (v101_5).is_empty() { Space::new() } else {
              let v102_6: Path = concat_path(&(v100_6),&(v100_7_head));
              let v102_7: Space = routine_13(c, &(v102_6), &(*p1), &(v100_7_tail).make_space(), &(*s1));
              compose(&(v101_5),&(v102_7))
            };
            drop(v101_5);
            let v101_9: Space = intersect(&(*CONSTANT_2),&(v101_2));
            drop(v101_2);
            let v101_10: Space = if has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
            drop(v101_9);
            let v101_12: Space = if (v101_10).is_empty() { Space::new() } else {
              let v103_6: Path = concat_path(&(v100_6),&(v100_7_head));
              let v103_11: Space = routine_14(c, &(v103_6), &(*p1), &(v100_7_tail).make_space(), &(*s1));
              drop(v103_6);
              compose(&(v101_10),&(v103_11))
            };
            drop(v101_10);
            let v101_13: Space = unite(&(v101_8),&(v101_12));
            v100_7.join_into((v101_13).clone());
            }
            v100_7_cursor.ascend(1);
          }
          drop(v100_7_cursor);
          compose(&(v99_5),&(v100_7))
        };
        drop(v99_5);
        let v99_9: Space = intersect(&(*CONSTANT_2),&(v99_2));
        drop(v99_2);
        let v99_10: Space = if has_head(&(v99_9)) { singleton(&[]) } else { Space::new() };
        drop(v99_9);
        let v99_13: Space = if (v99_10).is_empty() { Space::new() } else {
          let v104_11: Space = unwrap(&(v98_11),&(v98_12_head));
          let v104_12: Space = unwrap(&(v104_11),&(*p1));
          drop(v104_11);
          compose(&(v99_10),&(v104_12))
        };
        drop(v99_10);
        let v105_6: Path = concat_path(&(v98_6),&(v98_12_head));
        let v99_14: Space = wrap(&(v99_13),&(v105_6));
        drop(v99_13);
        let v99_15: Space = wrap(&(v99_14),&(*p1));
        drop(v99_14);
        let v99_16: Space = unite(&(v99_8),&(v99_15));
        drop(v99_15);
        v98_12.join_into((v99_16).clone());
        }
        v98_12_cursor.ascend(1);
      }
      drop(v98_12_cursor);
      drop(v98_6);
      drop(v98_11);
      compose(&(v87_10),&(v98_12))
    };
    drop(v87_10);
    let v87_14: Space = unite(&(v87_8),&(v87_13));
    v86_25.join_into((v87_14).clone());
    }
    v86_25_cursor.ascend(1);
  }
  drop(v86_25_cursor);
  drop(v86_21);
  (v86_25).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v106_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v106_9: Space = unwrap(&(v106_8),&(*p0));
  drop(v106_8);
  let mut v106_19 = Space::new();
  let mut v106_19_cursor = (*s0).read_zipper();
  for v106_19_byte in v106_19_cursor.child_mask().iter() {
    v106_19_cursor.descend_to_byte(v106_19_byte);
    {
    let v106_19_tail = v106_19_cursor.fork_read_zipper();
    let v106_19_head = Path::from_slice(&[v106_19_byte]);
    let v107_2: Space = singleton(&(v106_19_head));
    let v107_3: Space = intersect(&(*CONSTANT_2),&(v107_2));
    let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
    drop(v107_3);
    let v107_5: Space = subtract(&(*CONSTANT_1),&(v107_4));
    drop(v107_4);
    let v107_8: Space = if (v107_5).is_empty() { Space::new() } else {
      let v108_6: Path = concat_path(&(*p0),&(v106_19_head));
      let mut v108_7 = Space::new();
      let mut v108_7_cursor = (v106_19_tail).read_zipper();
      for v108_7_byte in v108_7_cursor.child_mask().iter() {
        v108_7_cursor.descend_to_byte(v108_7_byte);
        {
        let v108_7_tail = v108_7_cursor.fork_read_zipper();
        let v108_7_head = Path::from_slice(&[v108_7_byte]);
        let v109_2: Space = singleton(&(v108_7_head));
        let v109_3: Space = intersect(&(*CONSTANT_2),&(v109_2));
        let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
        drop(v109_3);
        let v109_5: Space = subtract(&(*CONSTANT_1),&(v109_4));
        drop(v109_4);
        let v109_8: Space = if (v109_5).is_empty() { Space::new() } else {
          let v110_6: Path = concat_path(&(v108_6),&(v108_7_head));
          let mut v110_7 = Space::new();
          let mut v110_7_cursor = (v108_7_tail).read_zipper();
          for v110_7_byte in v110_7_cursor.child_mask().iter() {
            v110_7_cursor.descend_to_byte(v110_7_byte);
            {
            let v110_7_tail = v110_7_cursor.fork_read_zipper();
            let v110_7_head = Path::from_slice(&[v110_7_byte]);
            let v111_2: Space = singleton(&(v110_7_head));
            let v111_3: Space = intersect(&(*CONSTANT_2),&(v111_2));
            let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
            drop(v111_3);
            let v111_5: Space = subtract(&(*CONSTANT_1),&(v111_4));
            drop(v111_4);
            let v111_8: Space = if (v111_5).is_empty() { Space::new() } else {
              let v112_6: Path = concat_path(&(v110_6),&(v110_7_head));
              let v112_7: Space = routine_13(c, &(v112_6), &(*p1), &(v110_7_tail).make_space(), &(*s1));
              compose(&(v111_5),&(v112_7))
            };
            drop(v111_5);
            let v111_9: Space = intersect(&(*CONSTANT_2),&(v111_2));
            drop(v111_2);
            let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
            drop(v111_9);
            let v111_12: Space = if (v111_10).is_empty() { Space::new() } else {
              let v113_6: Path = concat_path(&(v110_6),&(v110_7_head));
              let v113_11: Space = routine_14(c, &(v113_6), &(*p1), &(v110_7_tail).make_space(), &(*s1));
              drop(v113_6);
              compose(&(v111_10),&(v113_11))
            };
            drop(v111_10);
            let v111_13: Space = unite(&(v111_8),&(v111_12));
            v110_7.join_into((v111_13).clone());
            }
            v110_7_cursor.ascend(1);
          }
          drop(v110_7_cursor);
          compose(&(v109_5),&(v110_7))
        };
        drop(v109_5);
        let v109_9: Space = intersect(&(*CONSTANT_2),&(v109_2));
        drop(v109_2);
        let v109_10: Space = if has_head(&(v109_9)) { singleton(&[]) } else { Space::new() };
        drop(v109_9);
        let v109_12: Space = if (v109_10).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v108_6),&(v108_7_head));
          let mut v114_11 = Space::new();
          let mut v114_11_cursor = (v108_7_tail).read_zipper();
          for v114_11_byte in v114_11_cursor.child_mask().iter() {
            v114_11_cursor.descend_to_byte(v114_11_byte);
            {
            let v114_11_tail = v114_11_cursor.fork_read_zipper();
            let v114_11_head = Path::from_slice(&[v114_11_byte]);
            let v115_2: Space = singleton(&(v114_11_head));
            let v115_3: Space = intersect(&(*CONSTANT_2),&(v115_2));
            let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = subtract(&(*CONSTANT_1),&(v115_4));
            drop(v115_4);
            let v115_8: Space = if (v115_5).is_empty() { Space::new() } else {
              let v116_6: Path = concat_path(&(v114_6),&(v114_11_head));
              let v116_7: Space = routine_13(c, &(v116_6), &(*p1), &(v114_11_tail).make_space(), &(*s1));
              compose(&(v115_5),&(v116_7))
            };
            drop(v115_5);
            let v115_9: Space = intersect(&(*CONSTANT_2),&(v115_2));
            drop(v115_2);
            let v115_10: Space = if has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
            drop(v115_9);
            let v115_12: Space = if (v115_10).is_empty() { Space::new() } else {
              let v117_6: Path = concat_path(&(v114_6),&(v114_11_head));
              let v117_11: Space = routine_10(c, &(v117_6), &(*p1), &(v114_11_tail).make_space(), &(*s1));
              drop(v117_6);
              compose(&(v115_10),&(v117_11))
            };
            drop(v115_10);
            let v115_13: Space = unite(&(v115_8),&(v115_12));
            v114_11.join_into((v115_13).clone());
            }
            v114_11_cursor.ascend(1);
          }
          drop(v114_11_cursor);
          drop(v114_6);
          compose(&(v109_10),&(v114_11))
        };
        drop(v109_10);
        let v109_13: Space = unite(&(v109_8),&(v109_12));
        v108_7.join_into((v109_13).clone());
        }
        v108_7_cursor.ascend(1);
      }
      drop(v108_7_cursor);
      compose(&(v107_5),&(v108_7))
    };
    drop(v107_5);
    let v107_9: Space = intersect(&(*CONSTANT_2),&(v107_2));
    drop(v107_2);
    let v107_10: Space = if has_head(&(v107_9)) { singleton(&[]) } else { Space::new() };
    drop(v107_9);
    let v107_13: Space = if (v107_10).is_empty() { Space::new() } else {
      let v118_11: Space = unwrap(&(v106_9),&(v106_19_head));
      let v118_12: Space = unwrap(&(v118_11),&(*p1));
      drop(v118_11);
      compose(&(v107_10),&(v118_12))
    };
    drop(v107_10);
    let v119_6: Path = concat_path(&(*p0),&(v106_19_head));
    let v107_14: Space = wrap(&(v107_13),&(v119_6));
    drop(v107_13);
    let v107_15: Space = wrap(&(v107_14),&(*p1));
    drop(v107_14);
    let v107_16: Space = unite(&(v107_8),&(v107_15));
    drop(v107_15);
    v106_19.join_into((v107_16).clone());
    }
    v106_19_cursor.ascend(1);
  }
  drop(v106_19_cursor);
  drop(v106_9);
  (v106_19).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v120_24 = Space::new();
  let mut v120_24_cursor = (*s0).read_zipper();
  for v120_24_byte in v120_24_cursor.child_mask().iter() {
    v120_24_cursor.descend_to_byte(v120_24_byte);
    {
    let v120_24_tail = v120_24_cursor.fork_read_zipper();
    let v120_24_head = Path::from_slice(&[v120_24_byte]);
    let v121_2: Space = singleton(&(v120_24_head));
    let v121_3: Space = intersect(&(*CONSTANT_2),&(v121_2));
    let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
    drop(v121_3);
    let v121_5: Space = subtract(&(*CONSTANT_1),&(v121_4));
    drop(v121_4);
    let v121_8: Space = if (v121_5).is_empty() { Space::new() } else {
      let v122_6: Path = concat_path(&(*p0),&(v120_24_head));
      let mut v122_7 = Space::new();
      let mut v122_7_cursor = (v120_24_tail).read_zipper();
      for v122_7_byte in v122_7_cursor.child_mask().iter() {
        v122_7_cursor.descend_to_byte(v122_7_byte);
        {
        let v122_7_tail = v122_7_cursor.fork_read_zipper();
        let v122_7_head = Path::from_slice(&[v122_7_byte]);
        let v123_2: Space = singleton(&(v122_7_head));
        let v123_3: Space = intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_8: Space = if (v123_5).is_empty() { Space::new() } else {
          let v124_6: Path = concat_path(&(v122_6),&(v122_7_head));
          let mut v124_7 = Space::new();
          let mut v124_7_cursor = (v122_7_tail).read_zipper();
          for v124_7_byte in v124_7_cursor.child_mask().iter() {
            v124_7_cursor.descend_to_byte(v124_7_byte);
            {
            let v124_7_tail = v124_7_cursor.fork_read_zipper();
            let v124_7_head = Path::from_slice(&[v124_7_byte]);
            let v125_2: Space = singleton(&(v124_7_head));
            let v125_3: Space = intersect(&(*CONSTANT_2),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_1),&(v125_4));
            drop(v125_4);
            let v125_8: Space = if (v125_5).is_empty() { Space::new() } else {
              let v126_6: Path = concat_path(&(v124_6),&(v124_7_head));
              let v126_7: Space = routine_15(c, &(v126_6), &(v124_7_tail).make_space(), &(*s1));
              compose(&(v125_5),&(v126_7))
            };
            drop(v125_5);
            let v125_9: Space = intersect(&(*CONSTANT_2),&(v125_2));
            drop(v125_2);
            let v125_10: Space = if has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
            drop(v125_9);
            let v125_12: Space = if (v125_10).is_empty() { Space::new() } else {
              let v127_6: Path = concat_path(&(v124_6),&(v124_7_head));
              let v127_11: Space = routine_16(c, &(v127_6), &(v124_7_tail).make_space(), &(*s1));
              drop(v127_6);
              compose(&(v125_10),&(v127_11))
            };
            drop(v125_10);
            let v125_13: Space = unite(&(v125_8),&(v125_12));
            v124_7.join_into((v125_13).clone());
            }
            v124_7_cursor.ascend(1);
          }
          drop(v124_7_cursor);
          compose(&(v123_5),&(v124_7))
        };
        drop(v123_5);
        let v123_9: Space = intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
        drop(v123_9);
        let v123_12: Space = if (v123_10).is_empty() { Space::new() } else {
          let v128_6: Path = concat_path(&(v122_6),&(v122_7_head));
          let mut v128_11 = Space::new();
          let mut v128_11_cursor = (v122_7_tail).read_zipper();
          for v128_11_byte in v128_11_cursor.child_mask().iter() {
            v128_11_cursor.descend_to_byte(v128_11_byte);
            {
            let v128_11_tail = v128_11_cursor.fork_read_zipper();
            let v128_11_head = Path::from_slice(&[v128_11_byte]);
            let v129_2: Space = singleton(&(v128_11_head));
            let v129_3: Space = intersect(&(*CONSTANT_2),&(v129_2));
            let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
            drop(v129_3);
            let v129_5: Space = subtract(&(*CONSTANT_1),&(v129_4));
            drop(v129_4);
            let v129_8: Space = if (v129_5).is_empty() { Space::new() } else {
              let v130_6: Path = concat_path(&(v128_6),&(v128_11_head));
              let v130_7: Space = routine_15(c, &(v130_6), &(v128_11_tail).make_space(), &(*s1));
              compose(&(v129_5),&(v130_7))
            };
            drop(v129_5);
            let v129_9: Space = intersect(&(*CONSTANT_2),&(v129_2));
            drop(v129_2);
            let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
            drop(v129_9);
            let v129_12: Space = if (v129_10).is_empty() { Space::new() } else {
              let v131_6: Path = concat_path(&(v128_6),&(v128_11_head));
              let v131_11: Space = routine_3(c, &(v131_6), &(v128_11_tail).make_space(), &(*s1));
              drop(v131_6);
              compose(&(v129_10),&(v131_11))
            };
            drop(v129_10);
            let v129_13: Space = unite(&(v129_8),&(v129_12));
            v128_11.join_into((v129_13).clone());
            }
            v128_11_cursor.ascend(1);
          }
          drop(v128_11_cursor);
          drop(v128_6);
          compose(&(v123_10),&(v128_11))
        };
        drop(v123_10);
        let v123_13: Space = unite(&(v123_8),&(v123_12));
        v122_7.join_into((v123_13).clone());
        }
        v122_7_cursor.ascend(1);
      }
      drop(v122_7_cursor);
      compose(&(v121_5),&(v122_7))
    };
    drop(v121_5);
    let v121_9: Space = intersect(&(*CONSTANT_2),&(v121_2));
    drop(v121_2);
    let v121_10: Space = if has_head(&(v121_9)) { singleton(&[]) } else { Space::new() };
    drop(v121_9);
    let v121_12: Space = if (v121_10).is_empty() { Space::new() } else {
      let v132_6: Path = concat_path(&(*p0),&(v120_24_head));
      let mut v132_11 = Space::new();
      let mut v132_11_cursor = (v120_24_tail).read_zipper();
      for v132_11_byte in v132_11_cursor.child_mask().iter() {
        v132_11_cursor.descend_to_byte(v132_11_byte);
        {
        let v132_11_tail = v132_11_cursor.fork_read_zipper();
        let v132_11_head = Path::from_slice(&[v132_11_byte]);
        let v133_2: Space = singleton(&(v132_11_head));
        let v133_3: Space = intersect(&(*CONSTANT_2),&(v133_2));
        let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
        drop(v133_3);
        let v133_5: Space = subtract(&(*CONSTANT_1),&(v133_4));
        drop(v133_4);
        let v133_8: Space = if (v133_5).is_empty() { Space::new() } else {
          let v134_6: Path = concat_path(&(v132_6),&(v132_11_head));
          let mut v134_7 = Space::new();
          let mut v134_7_cursor = (v132_11_tail).read_zipper();
          for v134_7_byte in v134_7_cursor.child_mask().iter() {
            v134_7_cursor.descend_to_byte(v134_7_byte);
            {
            let v134_7_tail = v134_7_cursor.fork_read_zipper();
            let v134_7_head = Path::from_slice(&[v134_7_byte]);
            let v135_2: Space = singleton(&(v134_7_head));
            let v135_3: Space = intersect(&(*CONSTANT_2),&(v135_2));
            let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
            drop(v135_3);
            let v135_5: Space = subtract(&(*CONSTANT_1),&(v135_4));
            drop(v135_4);
            let v135_8: Space = if (v135_5).is_empty() { Space::new() } else {
              let v136_6: Path = concat_path(&(v134_6),&(v134_7_head));
              let v136_7: Space = routine_15(c, &(v136_6), &(v134_7_tail).make_space(), &(*s1));
              compose(&(v135_5),&(v136_7))
            };
            drop(v135_5);
            let v135_9: Space = intersect(&(*CONSTANT_2),&(v135_2));
            drop(v135_2);
            let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
            drop(v135_9);
            let v135_12: Space = if (v135_10).is_empty() { Space::new() } else {
              let v137_6: Path = concat_path(&(v134_6),&(v134_7_head));
              let v137_11: Space = routine_16(c, &(v137_6), &(v134_7_tail).make_space(), &(*s1));
              drop(v137_6);
              compose(&(v135_10),&(v137_11))
            };
            drop(v135_10);
            let v135_13: Space = unite(&(v135_8),&(v135_12));
            v134_7.join_into((v135_13).clone());
            }
            v134_7_cursor.ascend(1);
          }
          drop(v134_7_cursor);
          compose(&(v133_5),&(v134_7))
        };
        drop(v133_5);
        let v133_9: Space = intersect(&(*CONSTANT_2),&(v133_2));
        drop(v133_2);
        let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
        drop(v133_9);
        let v133_12: Space = if (v133_10).is_empty() { Space::new() } else {
          let v138_6: Path = concat_path(&(v132_6),&(v132_11_head));
          let mut v138_11 = Space::new();
          let mut v138_11_cursor = (v132_11_tail).read_zipper();
          for v138_11_byte in v138_11_cursor.child_mask().iter() {
            v138_11_cursor.descend_to_byte(v138_11_byte);
            {
            let v138_11_tail = v138_11_cursor.fork_read_zipper();
            let v138_11_head = Path::from_slice(&[v138_11_byte]);
            let v139_2: Space = singleton(&(v138_11_head));
            let v139_3: Space = intersect(&(*CONSTANT_2),&(v139_2));
            let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
            drop(v139_3);
            let v139_5: Space = subtract(&(*CONSTANT_1),&(v139_4));
            drop(v139_4);
            let v139_7: Space = if (v139_5).is_empty() { Space::new() } else {
              let v140_6: Space = routine_4(c, &(v138_11_head), &(v138_6), &(v138_11_tail).make_space(), &(*s1));
              compose(&(v139_5),&(v140_6))
            };
            drop(v139_5);
            let v139_8: Space = intersect(&(*CONSTANT_2),&(v139_2));
            drop(v139_2);
            let v139_9: Space = if has_head(&(v139_8)) { singleton(&[]) } else { Space::new() };
            drop(v139_8);
            let v139_11: Space = if (v139_9).is_empty() { Space::new() } else {
              let v141_10: Space = routine_5(c, &(v138_11_head), &(v138_6), &(v138_11_tail).make_space(), &(*s1));
              compose(&(v139_9),&(v141_10))
            };
            drop(v139_9);
            let v139_12: Space = unite(&(v139_7),&(v139_11));
            v138_11.join_into((v139_12).clone());
            }
            v138_11_cursor.ascend(1);
          }
          drop(v138_11_cursor);
          drop(v138_6);
          compose(&(v133_10),&(v138_11))
        };
        drop(v133_10);
        let v133_13: Space = unite(&(v133_8),&(v133_12));
        v132_11.join_into((v133_13).clone());
        }
        v132_11_cursor.ascend(1);
      }
      drop(v132_11_cursor);
      drop(v132_6);
      compose(&(v121_10),&(v132_11))
    };
    drop(v121_10);
    let v121_13: Space = unite(&(v121_8),&(v121_12));
    v120_24.join_into((v121_13).clone());
    }
    v120_24_cursor.ascend(1);
  }
  drop(v120_24_cursor);
  (v120_24).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v142_24 = Space::new();
  let mut v142_24_cursor = (*s0).read_zipper();
  for v142_24_byte in v142_24_cursor.child_mask().iter() {
    v142_24_cursor.descend_to_byte(v142_24_byte);
    {
    let v142_24_tail = v142_24_cursor.fork_read_zipper();
    let v142_24_head = Path::from_slice(&[v142_24_byte]);
    let v143_2: Space = singleton(&(v142_24_head));
    let v143_3: Space = intersect(&(*CONSTANT_2),&(v143_2));
    let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
    drop(v143_3);
    let v143_5: Space = subtract(&(*CONSTANT_1),&(v143_4));
    drop(v143_4);
    let v143_8: Space = if (v143_5).is_empty() { Space::new() } else {
      let v144_6: Path = concat_path(&(*p0),&(v142_24_head));
      let mut v144_7 = Space::new();
      let mut v144_7_cursor = (v142_24_tail).read_zipper();
      for v144_7_byte in v144_7_cursor.child_mask().iter() {
        v144_7_cursor.descend_to_byte(v144_7_byte);
        {
        let v144_7_tail = v144_7_cursor.fork_read_zipper();
        let v144_7_head = Path::from_slice(&[v144_7_byte]);
        let v145_2: Space = singleton(&(v144_7_head));
        let v145_3: Space = intersect(&(*CONSTANT_2),&(v145_2));
        let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = subtract(&(*CONSTANT_1),&(v145_4));
        drop(v145_4);
        let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v144_6),&(v144_7_head));
          let mut v146_7 = Space::new();
          let mut v146_7_cursor = (v144_7_tail).read_zipper();
          for v146_7_byte in v146_7_cursor.child_mask().iter() {
            v146_7_cursor.descend_to_byte(v146_7_byte);
            {
            let v146_7_tail = v146_7_cursor.fork_read_zipper();
            let v146_7_head = Path::from_slice(&[v146_7_byte]);
            let v147_2: Space = singleton(&(v146_7_head));
            let v147_3: Space = intersect(&(*CONSTANT_2),&(v147_2));
            let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
            drop(v147_3);
            let v147_5: Space = subtract(&(*CONSTANT_1),&(v147_4));
            drop(v147_4);
            let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
              let v148_6: Path = concat_path(&(v146_6),&(v146_7_head));
              let v148_7: Space = routine_15(c, &(v148_6), &(v146_7_tail).make_space(), &(*s1));
              compose(&(v147_5),&(v148_7))
            };
            drop(v147_5);
            let v147_9: Space = intersect(&(*CONSTANT_2),&(v147_2));
            drop(v147_2);
            let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
            drop(v147_9);
            let v147_12: Space = if (v147_10).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v146_6),&(v146_7_head));
              let v149_11: Space = routine_16(c, &(v149_6), &(v146_7_tail).make_space(), &(*s1));
              drop(v149_6);
              compose(&(v147_10),&(v149_11))
            };
            drop(v147_10);
            let v147_13: Space = unite(&(v147_8),&(v147_12));
            v146_7.join_into((v147_13).clone());
            }
            v146_7_cursor.ascend(1);
          }
          drop(v146_7_cursor);
          compose(&(v145_5),&(v146_7))
        };
        drop(v145_5);
        let v145_9: Space = intersect(&(*CONSTANT_2),&(v145_2));
        drop(v145_2);
        let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
        drop(v145_9);
        let v145_12: Space = if (v145_10).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v144_6),&(v144_7_head));
          let mut v150_11 = Space::new();
          let mut v150_11_cursor = (v144_7_tail).read_zipper();
          for v150_11_byte in v150_11_cursor.child_mask().iter() {
            v150_11_cursor.descend_to_byte(v150_11_byte);
            {
            let v150_11_tail = v150_11_cursor.fork_read_zipper();
            let v150_11_head = Path::from_slice(&[v150_11_byte]);
            let v151_2: Space = singleton(&(v150_11_head));
            let v151_3: Space = intersect(&(*CONSTANT_2),&(v151_2));
            let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
            drop(v151_3);
            let v151_5: Space = subtract(&(*CONSTANT_1),&(v151_4));
            drop(v151_4);
            let v151_8: Space = if (v151_5).is_empty() { Space::new() } else {
              let v152_6: Path = concat_path(&(v150_6),&(v150_11_head));
              let v152_7: Space = routine_15(c, &(v152_6), &(v150_11_tail).make_space(), &(*s1));
              compose(&(v151_5),&(v152_7))
            };
            drop(v151_5);
            let v151_9: Space = intersect(&(*CONSTANT_2),&(v151_2));
            drop(v151_2);
            let v151_10: Space = if has_head(&(v151_9)) { singleton(&[]) } else { Space::new() };
            drop(v151_9);
            let v151_12: Space = if (v151_10).is_empty() { Space::new() } else {
              let v153_6: Path = concat_path(&(v150_6),&(v150_11_head));
              let v153_11: Space = routine_3(c, &(v153_6), &(v150_11_tail).make_space(), &(*s1));
              drop(v153_6);
              compose(&(v151_10),&(v153_11))
            };
            drop(v151_10);
            let v151_13: Space = unite(&(v151_8),&(v151_12));
            v150_11.join_into((v151_13).clone());
            }
            v150_11_cursor.ascend(1);
          }
          drop(v150_11_cursor);
          drop(v150_6);
          compose(&(v145_10),&(v150_11))
        };
        drop(v145_10);
        let v145_13: Space = unite(&(v145_8),&(v145_12));
        v144_7.join_into((v145_13).clone());
        }
        v144_7_cursor.ascend(1);
      }
      drop(v144_7_cursor);
      compose(&(v143_5),&(v144_7))
    };
    drop(v143_5);
    let v143_9: Space = intersect(&(*CONSTANT_2),&(v143_2));
    drop(v143_2);
    let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
    drop(v143_9);
    let v143_12: Space = if (v143_10).is_empty() { Space::new() } else {
      let v154_6: Path = concat_path(&(*p0),&(v142_24_head));
      let mut v154_11 = Space::new();
      let mut v154_11_cursor = (v142_24_tail).read_zipper();
      for v154_11_byte in v154_11_cursor.child_mask().iter() {
        v154_11_cursor.descend_to_byte(v154_11_byte);
        {
        let v154_11_tail = v154_11_cursor.fork_read_zipper();
        let v154_11_head = Path::from_slice(&[v154_11_byte]);
        let v155_2: Space = singleton(&(v154_11_head));
        let v155_3: Space = intersect(&(*CONSTANT_2),&(v155_2));
        let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
        drop(v155_3);
        let v155_5: Space = subtract(&(*CONSTANT_1),&(v155_4));
        drop(v155_4);
        let v155_7: Space = if (v155_5).is_empty() { Space::new() } else {
          let mut v156_6 = Space::new();
          let mut v156_6_cursor = (v154_11_tail).read_zipper();
          for v156_6_byte in v156_6_cursor.child_mask().iter() {
            v156_6_cursor.descend_to_byte(v156_6_byte);
            {
            let v156_6_tail = v156_6_cursor.fork_read_zipper();
            let v156_6_head = Path::from_slice(&[v156_6_byte]);
            let v157_2: Space = singleton(&(v156_6_head));
            let v157_3: Space = intersect(&(*CONSTANT_2),&(v157_2));
            let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
            drop(v157_3);
            let v157_5: Space = subtract(&(*CONSTANT_1),&(v157_4));
            drop(v157_4);
            let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
              let v158_6: Path = concat_path(&(v154_11_head),&(v156_6_head));
              let v158_7: Space = routine_8(c, &(v158_6), &(v154_6), &(v156_6_tail).make_space(), &(*s1));
              compose(&(v157_5),&(v158_7))
            };
            drop(v157_5);
            let v157_9: Space = intersect(&(*CONSTANT_2),&(v157_2));
            drop(v157_2);
            let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
            drop(v157_9);
            let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
              let v159_6: Path = concat_path(&(v154_11_head),&(v156_6_head));
              let v159_11: Space = routine_9(c, &(v159_6), &(v154_6), &(v156_6_tail).make_space(), &(*s1));
              drop(v159_6);
              compose(&(v157_10),&(v159_11))
            };
            drop(v157_10);
            let v157_13: Space = unite(&(v157_8),&(v157_12));
            v156_6.join_into((v157_13).clone());
            }
            v156_6_cursor.ascend(1);
          }
          drop(v156_6_cursor);
          compose(&(v155_5),&(v156_6))
        };
        drop(v155_5);
        let v155_8: Space = intersect(&(*CONSTANT_2),&(v155_2));
        drop(v155_2);
        let v155_9: Space = if has_head(&(v155_8)) { singleton(&[]) } else { Space::new() };
        drop(v155_8);
        let v155_11: Space = if (v155_9).is_empty() { Space::new() } else {
          let mut v160_10 = Space::new();
          let mut v160_10_cursor = (v154_11_tail).read_zipper();
          for v160_10_byte in v160_10_cursor.child_mask().iter() {
            v160_10_cursor.descend_to_byte(v160_10_byte);
            {
            let v160_10_tail = v160_10_cursor.fork_read_zipper();
            let v160_10_head = Path::from_slice(&[v160_10_byte]);
            let v161_2: Space = singleton(&(v160_10_head));
            let v161_3: Space = intersect(&(*CONSTANT_2),&(v161_2));
            let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
            drop(v161_3);
            let v161_5: Space = subtract(&(*CONSTANT_1),&(v161_4));
            drop(v161_4);
            let v161_8: Space = if (v161_5).is_empty() { Space::new() } else {
              let v162_6: Path = concat_path(&(v154_11_head),&(v160_10_head));
              let v162_7: Space = routine_8(c, &(v162_6), &(v154_6), &(v160_10_tail).make_space(), &(*s1));
              compose(&(v161_5),&(v162_7))
            };
            drop(v161_5);
            let v161_9: Space = intersect(&(*CONSTANT_2),&(v161_2));
            drop(v161_2);
            let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
            drop(v161_9);
            let v161_12: Space = if (v161_10).is_empty() { Space::new() } else {
              let v163_6: Path = concat_path(&(v154_11_head),&(v160_10_head));
              let v163_11: Space = routine_10(c, &(v163_6), &(v154_6), &(v160_10_tail).make_space(), &(*s1));
              drop(v163_6);
              compose(&(v161_10),&(v163_11))
            };
            drop(v161_10);
            let v161_13: Space = unite(&(v161_8),&(v161_12));
            v160_10.join_into((v161_13).clone());
            }
            v160_10_cursor.ascend(1);
          }
          drop(v160_10_cursor);
          compose(&(v155_9),&(v160_10))
        };
        drop(v155_9);
        let v155_12: Space = unite(&(v155_7),&(v155_11));
        v154_11.join_into((v155_12).clone());
        }
        v154_11_cursor.ascend(1);
      }
      drop(v154_11_cursor);
      drop(v154_6);
      compose(&(v143_10),&(v154_11))
    };
    drop(v143_10);
    let v143_13: Space = unite(&(v143_8),&(v143_12));
    v142_24.join_into((v143_13).clone());
    }
    v142_24_cursor.ascend(1);
  }
  drop(v142_24_cursor);
  (v142_24).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v164_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v164_21: Space = unwrap(&(v164_20),&(*p0));
  drop(v164_20);
  let mut v164_25 = Space::new();
  let mut v164_25_cursor = (*s0).read_zipper();
  for v164_25_byte in v164_25_cursor.child_mask().iter() {
    v164_25_cursor.descend_to_byte(v164_25_byte);
    {
    let v164_25_tail = v164_25_cursor.fork_read_zipper();
    let v164_25_head = Path::from_slice(&[v164_25_byte]);
    let v165_2: Space = singleton(&(v164_25_head));
    let v165_3: Space = intersect(&(*CONSTANT_2),&(v165_2));
    let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
    drop(v165_3);
    let v165_5: Space = subtract(&(*CONSTANT_1),&(v165_4));
    drop(v165_4);
    let v165_8: Space = if (v165_5).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&(v164_25_head));
      let mut v166_7 = Space::new();
      let mut v166_7_cursor = (v164_25_tail).read_zipper();
      for v166_7_byte in v166_7_cursor.child_mask().iter() {
        v166_7_cursor.descend_to_byte(v166_7_byte);
        {
        let v166_7_tail = v166_7_cursor.fork_read_zipper();
        let v166_7_head = Path::from_slice(&[v166_7_byte]);
        let v167_2: Space = singleton(&(v166_7_head));
        let v167_3: Space = intersect(&(*CONSTANT_2),&(v167_2));
        let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = subtract(&(*CONSTANT_1),&(v167_4));
        drop(v167_4);
        let v167_8: Space = if (v167_5).is_empty() { Space::new() } else {
          let v168_6: Path = concat_path(&(v166_6),&(v166_7_head));
          let mut v168_7 = Space::new();
          let mut v168_7_cursor = (v166_7_tail).read_zipper();
          for v168_7_byte in v168_7_cursor.child_mask().iter() {
            v168_7_cursor.descend_to_byte(v168_7_byte);
            {
            let v168_7_tail = v168_7_cursor.fork_read_zipper();
            let v168_7_head = Path::from_slice(&[v168_7_byte]);
            let v169_2: Space = singleton(&(v168_7_head));
            let v169_3: Space = intersect(&(*CONSTANT_2),&(v169_2));
            let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = subtract(&(*CONSTANT_1),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (v169_5).is_empty() { Space::new() } else {
              let v170_6: Path = concat_path(&(v168_6),&(v168_7_head));
              let v170_7: Space = routine_17(c, &(v170_6), &(*p1), &(v168_7_tail).make_space(), &(*s1));
              compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = intersect(&(*CONSTANT_2),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (v169_10).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v168_6),&(v168_7_head));
              let v171_11: Space = routine_18(c, &(v171_6), &(*p1), &(v168_7_tail).make_space(), &(*s1));
              drop(v171_6);
              compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = unite(&(v169_8),&(v169_12));
            v168_7.join_into((v169_13).clone());
            }
            v168_7_cursor.ascend(1);
          }
          drop(v168_7_cursor);
          compose(&(v167_5),&(v168_7))
        };
        drop(v167_5);
        let v167_9: Space = intersect(&(*CONSTANT_2),&(v167_2));
        drop(v167_2);
        let v167_10: Space = if has_head(&(v167_9)) { singleton(&[]) } else { Space::new() };
        drop(v167_9);
        let v167_12: Space = if (v167_10).is_empty() { Space::new() } else {
          let v172_6: Path = concat_path(&(v166_6),&(v166_7_head));
          let mut v172_11 = Space::new();
          let mut v172_11_cursor = (v166_7_tail).read_zipper();
          for v172_11_byte in v172_11_cursor.child_mask().iter() {
            v172_11_cursor.descend_to_byte(v172_11_byte);
            {
            let v172_11_tail = v172_11_cursor.fork_read_zipper();
            let v172_11_head = Path::from_slice(&[v172_11_byte]);
            let v173_2: Space = singleton(&(v172_11_head));
            let v173_3: Space = intersect(&(*CONSTANT_2),&(v173_2));
            let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
            drop(v173_3);
            let v173_5: Space = subtract(&(*CONSTANT_1),&(v173_4));
            drop(v173_4);
            let v173_8: Space = if (v173_5).is_empty() { Space::new() } else {
              let v174_6: Path = concat_path(&(v172_6),&(v172_11_head));
              let v174_7: Space = routine_17(c, &(v174_6), &(*p1), &(v172_11_tail).make_space(), &(*s1));
              compose(&(v173_5),&(v174_7))
            };
            drop(v173_5);
            let v173_9: Space = intersect(&(*CONSTANT_2),&(v173_2));
            drop(v173_2);
            let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
            drop(v173_9);
            let v173_12: Space = if (v173_10).is_empty() { Space::new() } else {
              let v175_6: Path = concat_path(&(v172_6),&(v172_11_head));
              let v175_11: Space = routine_10(c, &(v175_6), &(*p1), &(v172_11_tail).make_space(), &(*s1));
              drop(v175_6);
              compose(&(v173_10),&(v175_11))
            };
            drop(v173_10);
            let v173_13: Space = unite(&(v173_8),&(v173_12));
            v172_11.join_into((v173_13).clone());
            }
            v172_11_cursor.ascend(1);
          }
          drop(v172_11_cursor);
          drop(v172_6);
          compose(&(v167_10),&(v172_11))
        };
        drop(v167_10);
        let v167_13: Space = unite(&(v167_8),&(v167_12));
        v166_7.join_into((v167_13).clone());
        }
        v166_7_cursor.ascend(1);
      }
      drop(v166_7_cursor);
      compose(&(v165_5),&(v166_7))
    };
    drop(v165_5);
    let v165_9: Space = intersect(&(*CONSTANT_2),&(v165_2));
    drop(v165_2);
    let v165_10: Space = if has_head(&(v165_9)) { singleton(&[]) } else { Space::new() };
    drop(v165_9);
    let v165_13: Space = if (v165_10).is_empty() { Space::new() } else {
      let v176_6: Path = concat_path(&(*p0),&(v164_25_head));
      let v176_11: Space = unwrap(&(v164_21),&(v164_25_head));
      let mut v176_12 = Space::new();
      let mut v176_12_cursor = (v164_25_tail).read_zipper();
      for v176_12_byte in v176_12_cursor.child_mask().iter() {
        v176_12_cursor.descend_to_byte(v176_12_byte);
        {
        let v176_12_tail = v176_12_cursor.fork_read_zipper();
        let v176_12_head = Path::from_slice(&[v176_12_byte]);
        let v177_2: Space = singleton(&(v176_12_head));
        let v177_3: Space = intersect(&(*CONSTANT_2),&(v177_2));
        let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
        drop(v177_3);
        let v177_5: Space = subtract(&(*CONSTANT_1),&(v177_4));
        drop(v177_4);
        let v177_8: Space = if (v177_5).is_empty() { Space::new() } else {
          let v178_6: Path = concat_path(&(v176_6),&(v176_12_head));
          let mut v178_7 = Space::new();
          let mut v178_7_cursor = (v176_12_tail).read_zipper();
          for v178_7_byte in v178_7_cursor.child_mask().iter() {
            v178_7_cursor.descend_to_byte(v178_7_byte);
            {
            let v178_7_tail = v178_7_cursor.fork_read_zipper();
            let v178_7_head = Path::from_slice(&[v178_7_byte]);
            let v179_2: Space = singleton(&(v178_7_head));
            let v179_3: Space = intersect(&(*CONSTANT_2),&(v179_2));
            let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
            drop(v179_3);
            let v179_5: Space = subtract(&(*CONSTANT_1),&(v179_4));
            drop(v179_4);
            let v179_8: Space = if (v179_5).is_empty() { Space::new() } else {
              let v180_6: Path = concat_path(&(v178_6),&(v178_7_head));
              let v180_7: Space = routine_17(c, &(v180_6), &(*p1), &(v178_7_tail).make_space(), &(*s1));
              compose(&(v179_5),&(v180_7))
            };
            drop(v179_5);
            let v179_9: Space = intersect(&(*CONSTANT_2),&(v179_2));
            drop(v179_2);
            let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
            drop(v179_9);
            let v179_12: Space = if (v179_10).is_empty() { Space::new() } else {
              let v181_6: Path = concat_path(&(v178_6),&(v178_7_head));
              let v181_11: Space = routine_18(c, &(v181_6), &(*p1), &(v178_7_tail).make_space(), &(*s1));
              drop(v181_6);
              compose(&(v179_10),&(v181_11))
            };
            drop(v179_10);
            let v179_13: Space = unite(&(v179_8),&(v179_12));
            v178_7.join_into((v179_13).clone());
            }
            v178_7_cursor.ascend(1);
          }
          drop(v178_7_cursor);
          compose(&(v177_5),&(v178_7))
        };
        drop(v177_5);
        let v177_9: Space = intersect(&(*CONSTANT_2),&(v177_2));
        drop(v177_2);
        let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
        drop(v177_9);
        let v177_13: Space = if (v177_10).is_empty() { Space::new() } else {
          let v182_11: Space = unwrap(&(v176_11),&(v176_12_head));
          let v182_12: Space = unwrap(&(v182_11),&(*p1));
          drop(v182_11);
          compose(&(v177_10),&(v182_12))
        };
        drop(v177_10);
        let v183_6: Path = concat_path(&(v176_6),&(v176_12_head));
        let v177_14: Space = wrap(&(v177_13),&(v183_6));
        drop(v177_13);
        let v177_15: Space = wrap(&(v177_14),&(*p1));
        drop(v177_14);
        let v177_16: Space = unite(&(v177_8),&(v177_15));
        drop(v177_15);
        v176_12.join_into((v177_16).clone());
        }
        v176_12_cursor.ascend(1);
      }
      drop(v176_12_cursor);
      drop(v176_6);
      drop(v176_11);
      compose(&(v165_10),&(v176_12))
    };
    drop(v165_10);
    let v165_14: Space = unite(&(v165_8),&(v165_13));
    v164_25.join_into((v165_14).clone());
    }
    v164_25_cursor.ascend(1);
  }
  drop(v164_25_cursor);
  drop(v164_21);
  (v164_25).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v184_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v184_9: Space = unwrap(&(v184_8),&(*p0));
  drop(v184_8);
  let mut v184_19 = Space::new();
  let mut v184_19_cursor = (*s0).read_zipper();
  for v184_19_byte in v184_19_cursor.child_mask().iter() {
    v184_19_cursor.descend_to_byte(v184_19_byte);
    {
    let v184_19_tail = v184_19_cursor.fork_read_zipper();
    let v184_19_head = Path::from_slice(&[v184_19_byte]);
    let v185_2: Space = singleton(&(v184_19_head));
    let v185_3: Space = intersect(&(*CONSTANT_2),&(v185_2));
    let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
    drop(v185_3);
    let v185_5: Space = subtract(&(*CONSTANT_1),&(v185_4));
    drop(v185_4);
    let v185_8: Space = if (v185_5).is_empty() { Space::new() } else {
      let v186_6: Path = concat_path(&(*p0),&(v184_19_head));
      let mut v186_7 = Space::new();
      let mut v186_7_cursor = (v184_19_tail).read_zipper();
      for v186_7_byte in v186_7_cursor.child_mask().iter() {
        v186_7_cursor.descend_to_byte(v186_7_byte);
        {
        let v186_7_tail = v186_7_cursor.fork_read_zipper();
        let v186_7_head = Path::from_slice(&[v186_7_byte]);
        let v187_2: Space = singleton(&(v186_7_head));
        let v187_3: Space = intersect(&(*CONSTANT_2),&(v187_2));
        let v187_4: Space = if has_head(&(v187_3)) { singleton(&[]) } else { Space::new() };
        drop(v187_3);
        let v187_5: Space = subtract(&(*CONSTANT_1),&(v187_4));
        drop(v187_4);
        let v187_8: Space = if (v187_5).is_empty() { Space::new() } else {
          let v188_6: Path = concat_path(&(v186_6),&(v186_7_head));
          let mut v188_7 = Space::new();
          let mut v188_7_cursor = (v186_7_tail).read_zipper();
          for v188_7_byte in v188_7_cursor.child_mask().iter() {
            v188_7_cursor.descend_to_byte(v188_7_byte);
            {
            let v188_7_tail = v188_7_cursor.fork_read_zipper();
            let v188_7_head = Path::from_slice(&[v188_7_byte]);
            let v189_2: Space = singleton(&(v188_7_head));
            let v189_3: Space = intersect(&(*CONSTANT_2),&(v189_2));
            let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
            drop(v189_3);
            let v189_5: Space = subtract(&(*CONSTANT_1),&(v189_4));
            drop(v189_4);
            let v189_8: Space = if (v189_5).is_empty() { Space::new() } else {
              let v190_6: Path = concat_path(&(v188_6),&(v188_7_head));
              let v190_7: Space = routine_17(c, &(v190_6), &(*p1), &(v188_7_tail).make_space(), &(*s1));
              compose(&(v189_5),&(v190_7))
            };
            drop(v189_5);
            let v189_9: Space = intersect(&(*CONSTANT_2),&(v189_2));
            drop(v189_2);
            let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
            drop(v189_9);
            let v189_12: Space = if (v189_10).is_empty() { Space::new() } else {
              let v191_6: Path = concat_path(&(v188_6),&(v188_7_head));
              let v191_11: Space = routine_18(c, &(v191_6), &(*p1), &(v188_7_tail).make_space(), &(*s1));
              drop(v191_6);
              compose(&(v189_10),&(v191_11))
            };
            drop(v189_10);
            let v189_13: Space = unite(&(v189_8),&(v189_12));
            v188_7.join_into((v189_13).clone());
            }
            v188_7_cursor.ascend(1);
          }
          drop(v188_7_cursor);
          compose(&(v187_5),&(v188_7))
        };
        drop(v187_5);
        let v187_9: Space = intersect(&(*CONSTANT_2),&(v187_2));
        drop(v187_2);
        let v187_10: Space = if has_head(&(v187_9)) { singleton(&[]) } else { Space::new() };
        drop(v187_9);
        let v187_12: Space = if (v187_10).is_empty() { Space::new() } else {
          let v192_6: Path = concat_path(&(v186_6),&(v186_7_head));
          let mut v192_11 = Space::new();
          let mut v192_11_cursor = (v186_7_tail).read_zipper();
          for v192_11_byte in v192_11_cursor.child_mask().iter() {
            v192_11_cursor.descend_to_byte(v192_11_byte);
            {
            let v192_11_tail = v192_11_cursor.fork_read_zipper();
            let v192_11_head = Path::from_slice(&[v192_11_byte]);
            let v193_2: Space = singleton(&(v192_11_head));
            let v193_3: Space = intersect(&(*CONSTANT_2),&(v193_2));
            let v193_4: Space = if has_head(&(v193_3)) { singleton(&[]) } else { Space::new() };
            drop(v193_3);
            let v193_5: Space = subtract(&(*CONSTANT_1),&(v193_4));
            drop(v193_4);
            let v193_8: Space = if (v193_5).is_empty() { Space::new() } else {
              let v194_6: Path = concat_path(&(v192_6),&(v192_11_head));
              let v194_7: Space = routine_17(c, &(v194_6), &(*p1), &(v192_11_tail).make_space(), &(*s1));
              compose(&(v193_5),&(v194_7))
            };
            drop(v193_5);
            let v193_9: Space = intersect(&(*CONSTANT_2),&(v193_2));
            drop(v193_2);
            let v193_10: Space = if has_head(&(v193_9)) { singleton(&[]) } else { Space::new() };
            drop(v193_9);
            let v193_12: Space = if (v193_10).is_empty() { Space::new() } else {
              let v195_6: Path = concat_path(&(v192_6),&(v192_11_head));
              let v195_11: Space = routine_10(c, &(v195_6), &(*p1), &(v192_11_tail).make_space(), &(*s1));
              drop(v195_6);
              compose(&(v193_10),&(v195_11))
            };
            drop(v193_10);
            let v193_13: Space = unite(&(v193_8),&(v193_12));
            v192_11.join_into((v193_13).clone());
            }
            v192_11_cursor.ascend(1);
          }
          drop(v192_11_cursor);
          drop(v192_6);
          compose(&(v187_10),&(v192_11))
        };
        drop(v187_10);
        let v187_13: Space = unite(&(v187_8),&(v187_12));
        v186_7.join_into((v187_13).clone());
        }
        v186_7_cursor.ascend(1);
      }
      drop(v186_7_cursor);
      compose(&(v185_5),&(v186_7))
    };
    drop(v185_5);
    let v185_9: Space = intersect(&(*CONSTANT_2),&(v185_2));
    drop(v185_2);
    let v185_10: Space = if has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
    drop(v185_9);
    let v185_13: Space = if (v185_10).is_empty() { Space::new() } else {
      let v196_11: Space = unwrap(&(v184_9),&(v184_19_head));
      let v196_12: Space = unwrap(&(v196_11),&(*p1));
      drop(v196_11);
      compose(&(v185_10),&(v196_12))
    };
    drop(v185_10);
    let v197_6: Path = concat_path(&(*p0),&(v184_19_head));
    let v185_14: Space = wrap(&(v185_13),&(v197_6));
    drop(v185_13);
    let v185_15: Space = wrap(&(v185_14),&(*p1));
    drop(v185_14);
    let v185_16: Space = unite(&(v185_8),&(v185_15));
    drop(v185_15);
    v184_19.join_into((v185_16).clone());
    }
    v184_19_cursor.ascend(1);
  }
  drop(v184_19_cursor);
  drop(v184_9);
  (v184_19).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v198_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v198_6: Space = unwrap(&(v198_5),&(*p0));
  drop(v198_5);
  let v198_7: Space = unwrap(&(v198_6),&(*p1));
  drop(v198_6);
  let v198_8: Space = wrap(&(v198_7),&(*p0));
  drop(v198_7);
  let v198_9: Space = wrap(&(v198_8),&(*p1));
  drop(v198_8);
  (v198_9).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v199_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v199_21: Space = unwrap(&(v199_20),&(*p0));
  drop(v199_20);
  let mut v199_25 = Space::new();
  let mut v199_25_cursor = (*s0).read_zipper();
  for v199_25_byte in v199_25_cursor.child_mask().iter() {
    v199_25_cursor.descend_to_byte(v199_25_byte);
    {
    let v199_25_tail = v199_25_cursor.fork_read_zipper();
    let v199_25_head = Path::from_slice(&[v199_25_byte]);
    let v200_2: Space = singleton(&(v199_25_head));
    let v200_3: Space = intersect(&(*CONSTANT_2),&(v200_2));
    let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
    drop(v200_3);
    let v200_5: Space = subtract(&(*CONSTANT_1),&(v200_4));
    drop(v200_4);
    let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
      let v201_6: Path = concat_path(&(*p0),&(v199_25_head));
      let mut v201_7 = Space::new();
      let mut v201_7_cursor = (v199_25_tail).read_zipper();
      for v201_7_byte in v201_7_cursor.child_mask().iter() {
        v201_7_cursor.descend_to_byte(v201_7_byte);
        {
        let v201_7_tail = v201_7_cursor.fork_read_zipper();
        let v201_7_head = Path::from_slice(&[v201_7_byte]);
        let v202_2: Space = singleton(&(v201_7_head));
        let v202_3: Space = intersect(&(*CONSTANT_2),&(v202_2));
        let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
        drop(v202_3);
        let v202_5: Space = subtract(&(*CONSTANT_1),&(v202_4));
        drop(v202_4);
        let v202_8: Space = if (v202_5).is_empty() { Space::new() } else {
          let v203_6: Path = concat_path(&(v201_6),&(v201_7_head));
          let mut v203_7 = Space::new();
          let mut v203_7_cursor = (v201_7_tail).read_zipper();
          for v203_7_byte in v203_7_cursor.child_mask().iter() {
            v203_7_cursor.descend_to_byte(v203_7_byte);
            {
            let v203_7_tail = v203_7_cursor.fork_read_zipper();
            let v203_7_head = Path::from_slice(&[v203_7_byte]);
            let v204_2: Space = singleton(&(v203_7_head));
            let v204_3: Space = intersect(&(*CONSTANT_2),&(v204_2));
            let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
            drop(v204_3);
            let v204_5: Space = subtract(&(*CONSTANT_1),&(v204_4));
            drop(v204_4);
            let v204_8: Space = if (v204_5).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v203_6),&(v203_7_head));
              let v205_7: Space = routine_19(c, &(v205_6), &(*p1), &(v203_7_tail).make_space(), &(*s1));
              compose(&(v204_5),&(v205_7))
            };
            drop(v204_5);
            let v204_9: Space = intersect(&(*CONSTANT_2),&(v204_2));
            drop(v204_2);
            let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
            drop(v204_9);
            let v204_12: Space = if (v204_10).is_empty() { Space::new() } else {
              let v206_6: Path = concat_path(&(v203_6),&(v203_7_head));
              let v206_11: Space = routine_20(c, &(v206_6), &(*p1), &(v203_7_tail).make_space(), &(*s1));
              drop(v206_6);
              compose(&(v204_10),&(v206_11))
            };
            drop(v204_10);
            let v204_13: Space = unite(&(v204_8),&(v204_12));
            v203_7.join_into((v204_13).clone());
            }
            v203_7_cursor.ascend(1);
          }
          drop(v203_7_cursor);
          compose(&(v202_5),&(v203_7))
        };
        drop(v202_5);
        let v202_9: Space = intersect(&(*CONSTANT_2),&(v202_2));
        drop(v202_2);
        let v202_10: Space = if has_head(&(v202_9)) { singleton(&[]) } else { Space::new() };
        drop(v202_9);
        let v202_12: Space = if (v202_10).is_empty() { Space::new() } else {
          let v207_6: Path = concat_path(&(v201_6),&(v201_7_head));
          let mut v207_11 = Space::new();
          let mut v207_11_cursor = (v201_7_tail).read_zipper();
          for v207_11_byte in v207_11_cursor.child_mask().iter() {
            v207_11_cursor.descend_to_byte(v207_11_byte);
            {
            let v207_11_tail = v207_11_cursor.fork_read_zipper();
            let v207_11_head = Path::from_slice(&[v207_11_byte]);
            let v208_2: Space = singleton(&(v207_11_head));
            let v208_3: Space = intersect(&(*CONSTANT_2),&(v208_2));
            let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
            drop(v208_3);
            let v208_5: Space = subtract(&(*CONSTANT_1),&(v208_4));
            drop(v208_4);
            let v208_8: Space = if (v208_5).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v207_6),&(v207_11_head));
              let v209_7: Space = routine_19(c, &(v209_6), &(*p1), &(v207_11_tail).make_space(), &(*s1));
              compose(&(v208_5),&(v209_7))
            };
            drop(v208_5);
            let v208_9: Space = intersect(&(*CONSTANT_2),&(v208_2));
            drop(v208_2);
            let v208_10: Space = if has_head(&(v208_9)) { singleton(&[]) } else { Space::new() };
            drop(v208_9);
            let v208_12: Space = if (v208_10).is_empty() { Space::new() } else {
              let v210_6: Path = concat_path(&(v207_6),&(v207_11_head));
              let v210_11: Space = routine_10(c, &(v210_6), &(*p1), &(v207_11_tail).make_space(), &(*s1));
              drop(v210_6);
              compose(&(v208_10),&(v210_11))
            };
            drop(v208_10);
            let v208_13: Space = unite(&(v208_8),&(v208_12));
            v207_11.join_into((v208_13).clone());
            }
            v207_11_cursor.ascend(1);
          }
          drop(v207_11_cursor);
          drop(v207_6);
          compose(&(v202_10),&(v207_11))
        };
        drop(v202_10);
        let v202_13: Space = unite(&(v202_8),&(v202_12));
        v201_7.join_into((v202_13).clone());
        }
        v201_7_cursor.ascend(1);
      }
      drop(v201_7_cursor);
      compose(&(v200_5),&(v201_7))
    };
    drop(v200_5);
    let v200_9: Space = intersect(&(*CONSTANT_2),&(v200_2));
    drop(v200_2);
    let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
    drop(v200_9);
    let v200_13: Space = if (v200_10).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&(v199_25_head));
      let v211_11: Space = unwrap(&(v199_21),&(v199_25_head));
      let mut v211_12 = Space::new();
      let mut v211_12_cursor = (v199_25_tail).read_zipper();
      for v211_12_byte in v211_12_cursor.child_mask().iter() {
        v211_12_cursor.descend_to_byte(v211_12_byte);
        {
        let v211_12_tail = v211_12_cursor.fork_read_zipper();
        let v211_12_head = Path::from_slice(&[v211_12_byte]);
        let v212_2: Space = singleton(&(v211_12_head));
        let v212_3: Space = intersect(&(*CONSTANT_2),&(v212_2));
        let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = subtract(&(*CONSTANT_1),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (v212_5).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&(v211_12_head));
          let mut v213_7 = Space::new();
          let mut v213_7_cursor = (v211_12_tail).read_zipper();
          for v213_7_byte in v213_7_cursor.child_mask().iter() {
            v213_7_cursor.descend_to_byte(v213_7_byte);
            {
            let v213_7_tail = v213_7_cursor.fork_read_zipper();
            let v213_7_head = Path::from_slice(&[v213_7_byte]);
            let v214_2: Space = singleton(&(v213_7_head));
            let v214_3: Space = intersect(&(*CONSTANT_2),&(v214_2));
            let v214_4: Space = if has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
            drop(v214_3);
            let v214_5: Space = subtract(&(*CONSTANT_1),&(v214_4));
            drop(v214_4);
            let v214_8: Space = if (v214_5).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v213_6),&(v213_7_head));
              let v215_7: Space = routine_19(c, &(v215_6), &(*p1), &(v213_7_tail).make_space(), &(*s1));
              compose(&(v214_5),&(v215_7))
            };
            drop(v214_5);
            let v214_9: Space = intersect(&(*CONSTANT_2),&(v214_2));
            drop(v214_2);
            let v214_10: Space = if has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
            drop(v214_9);
            let v214_12: Space = if (v214_10).is_empty() { Space::new() } else {
              let v216_6: Path = concat_path(&(v213_6),&(v213_7_head));
              let v216_11: Space = routine_20(c, &(v216_6), &(*p1), &(v213_7_tail).make_space(), &(*s1));
              drop(v216_6);
              compose(&(v214_10),&(v216_11))
            };
            drop(v214_10);
            let v214_13: Space = unite(&(v214_8),&(v214_12));
            v213_7.join_into((v214_13).clone());
            }
            v213_7_cursor.ascend(1);
          }
          drop(v213_7_cursor);
          compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = intersect(&(*CONSTANT_2),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_13: Space = if (v212_10).is_empty() { Space::new() } else {
          let v217_11: Space = unwrap(&(v211_11),&(v211_12_head));
          let v217_12: Space = unwrap(&(v217_11),&(*p1));
          drop(v217_11);
          compose(&(v212_10),&(v217_12))
        };
        drop(v212_10);
        let v218_6: Path = concat_path(&(v211_6),&(v211_12_head));
        let v212_14: Space = wrap(&(v212_13),&(v218_6));
        drop(v212_13);
        let v212_15: Space = wrap(&(v212_14),&(*p1));
        drop(v212_14);
        let v212_16: Space = unite(&(v212_8),&(v212_15));
        drop(v212_15);
        v211_12.join_into((v212_16).clone());
        }
        v211_12_cursor.ascend(1);
      }
      drop(v211_12_cursor);
      drop(v211_6);
      drop(v211_11);
      compose(&(v200_10),&(v211_12))
    };
    drop(v200_10);
    let v200_14: Space = unite(&(v200_8),&(v200_13));
    v199_25.join_into((v200_14).clone());
    }
    v199_25_cursor.ascend(1);
  }
  drop(v199_25_cursor);
  drop(v199_21);
  (v199_25).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v219_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v219_9: Space = unwrap(&(v219_8),&(*p0));
  drop(v219_8);
  let mut v219_19 = Space::new();
  let mut v219_19_cursor = (*s0).read_zipper();
  for v219_19_byte in v219_19_cursor.child_mask().iter() {
    v219_19_cursor.descend_to_byte(v219_19_byte);
    {
    let v219_19_tail = v219_19_cursor.fork_read_zipper();
    let v219_19_head = Path::from_slice(&[v219_19_byte]);
    let v220_2: Space = singleton(&(v219_19_head));
    let v220_3: Space = intersect(&(*CONSTANT_2),&(v220_2));
    let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
    drop(v220_3);
    let v220_5: Space = subtract(&(*CONSTANT_1),&(v220_4));
    drop(v220_4);
    let v220_8: Space = if (v220_5).is_empty() { Space::new() } else {
      let v221_6: Path = concat_path(&(*p0),&(v219_19_head));
      let mut v221_7 = Space::new();
      let mut v221_7_cursor = (v219_19_tail).read_zipper();
      for v221_7_byte in v221_7_cursor.child_mask().iter() {
        v221_7_cursor.descend_to_byte(v221_7_byte);
        {
        let v221_7_tail = v221_7_cursor.fork_read_zipper();
        let v221_7_head = Path::from_slice(&[v221_7_byte]);
        let v222_2: Space = singleton(&(v221_7_head));
        let v222_3: Space = intersect(&(*CONSTANT_2),&(v222_2));
        let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
        drop(v222_3);
        let v222_5: Space = subtract(&(*CONSTANT_1),&(v222_4));
        drop(v222_4);
        let v222_8: Space = if (v222_5).is_empty() { Space::new() } else {
          let v223_6: Path = concat_path(&(v221_6),&(v221_7_head));
          let mut v223_7 = Space::new();
          let mut v223_7_cursor = (v221_7_tail).read_zipper();
          for v223_7_byte in v223_7_cursor.child_mask().iter() {
            v223_7_cursor.descend_to_byte(v223_7_byte);
            {
            let v223_7_tail = v223_7_cursor.fork_read_zipper();
            let v223_7_head = Path::from_slice(&[v223_7_byte]);
            let v224_2: Space = singleton(&(v223_7_head));
            let v224_3: Space = intersect(&(*CONSTANT_2),&(v224_2));
            let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
            drop(v224_3);
            let v224_5: Space = subtract(&(*CONSTANT_1),&(v224_4));
            drop(v224_4);
            let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
              let v225_6: Path = concat_path(&(v223_6),&(v223_7_head));
              let v225_7: Space = routine_19(c, &(v225_6), &(*p1), &(v223_7_tail).make_space(), &(*s1));
              compose(&(v224_5),&(v225_7))
            };
            drop(v224_5);
            let v224_9: Space = intersect(&(*CONSTANT_2),&(v224_2));
            drop(v224_2);
            let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
            drop(v224_9);
            let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
              let v226_6: Path = concat_path(&(v223_6),&(v223_7_head));
              let v226_11: Space = routine_20(c, &(v226_6), &(*p1), &(v223_7_tail).make_space(), &(*s1));
              drop(v226_6);
              compose(&(v224_10),&(v226_11))
            };
            drop(v224_10);
            let v224_13: Space = unite(&(v224_8),&(v224_12));
            v223_7.join_into((v224_13).clone());
            }
            v223_7_cursor.ascend(1);
          }
          drop(v223_7_cursor);
          compose(&(v222_5),&(v223_7))
        };
        drop(v222_5);
        let v222_9: Space = intersect(&(*CONSTANT_2),&(v222_2));
        drop(v222_2);
        let v222_10: Space = if has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
        drop(v222_9);
        let v222_12: Space = if (v222_10).is_empty() { Space::new() } else {
          let v227_6: Path = concat_path(&(v221_6),&(v221_7_head));
          let mut v227_11 = Space::new();
          let mut v227_11_cursor = (v221_7_tail).read_zipper();
          for v227_11_byte in v227_11_cursor.child_mask().iter() {
            v227_11_cursor.descend_to_byte(v227_11_byte);
            {
            let v227_11_tail = v227_11_cursor.fork_read_zipper();
            let v227_11_head = Path::from_slice(&[v227_11_byte]);
            let v228_2: Space = singleton(&(v227_11_head));
            let v228_3: Space = intersect(&(*CONSTANT_2),&(v228_2));
            let v228_4: Space = if has_head(&(v228_3)) { singleton(&[]) } else { Space::new() };
            drop(v228_3);
            let v228_5: Space = subtract(&(*CONSTANT_1),&(v228_4));
            drop(v228_4);
            let v228_8: Space = if (v228_5).is_empty() { Space::new() } else {
              let v229_6: Path = concat_path(&(v227_6),&(v227_11_head));
              let v229_7: Space = routine_19(c, &(v229_6), &(*p1), &(v227_11_tail).make_space(), &(*s1));
              compose(&(v228_5),&(v229_7))
            };
            drop(v228_5);
            let v228_9: Space = intersect(&(*CONSTANT_2),&(v228_2));
            drop(v228_2);
            let v228_10: Space = if has_head(&(v228_9)) { singleton(&[]) } else { Space::new() };
            drop(v228_9);
            let v228_12: Space = if (v228_10).is_empty() { Space::new() } else {
              let v230_6: Path = concat_path(&(v227_6),&(v227_11_head));
              let v230_11: Space = routine_10(c, &(v230_6), &(*p1), &(v227_11_tail).make_space(), &(*s1));
              drop(v230_6);
              compose(&(v228_10),&(v230_11))
            };
            drop(v228_10);
            let v228_13: Space = unite(&(v228_8),&(v228_12));
            v227_11.join_into((v228_13).clone());
            }
            v227_11_cursor.ascend(1);
          }
          drop(v227_11_cursor);
          drop(v227_6);
          compose(&(v222_10),&(v227_11))
        };
        drop(v222_10);
        let v222_13: Space = unite(&(v222_8),&(v222_12));
        v221_7.join_into((v222_13).clone());
        }
        v221_7_cursor.ascend(1);
      }
      drop(v221_7_cursor);
      compose(&(v220_5),&(v221_7))
    };
    drop(v220_5);
    let v220_9: Space = intersect(&(*CONSTANT_2),&(v220_2));
    drop(v220_2);
    let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
    drop(v220_9);
    let v220_13: Space = if (v220_10).is_empty() { Space::new() } else {
      let v231_11: Space = unwrap(&(v219_9),&(v219_19_head));
      let v231_12: Space = unwrap(&(v231_11),&(*p1));
      drop(v231_11);
      compose(&(v220_10),&(v231_12))
    };
    drop(v220_10);
    let v232_6: Path = concat_path(&(*p0),&(v219_19_head));
    let v220_14: Space = wrap(&(v220_13),&(v232_6));
    drop(v220_13);
    let v220_15: Space = wrap(&(v220_14),&(*p1));
    drop(v220_14);
    let v220_16: Space = unite(&(v220_8),&(v220_15));
    drop(v220_15);
    v219_19.join_into((v220_16).clone());
    }
    v219_19_cursor.ascend(1);
  }
  drop(v219_19_cursor);
  drop(v219_9);
  (v219_19).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v233_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v233_21: Space = unwrap(&(v233_20),&(*p0));
  drop(v233_20);
  let mut v233_25 = Space::new();
  let mut v233_25_cursor = (*s0).read_zipper();
  for v233_25_byte in v233_25_cursor.child_mask().iter() {
    v233_25_cursor.descend_to_byte(v233_25_byte);
    {
    let v233_25_tail = v233_25_cursor.fork_read_zipper();
    let v233_25_head = Path::from_slice(&[v233_25_byte]);
    let v234_2: Space = singleton(&(v233_25_head));
    let v234_3: Space = intersect(&(*CONSTANT_2),&(v234_2));
    let v234_4: Space = if has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
    drop(v234_3);
    let v234_5: Space = subtract(&(*CONSTANT_1),&(v234_4));
    drop(v234_4);
    let v234_8: Space = if (v234_5).is_empty() { Space::new() } else {
      let v235_6: Path = concat_path(&(*p0),&(v233_25_head));
      let mut v235_7 = Space::new();
      let mut v235_7_cursor = (v233_25_tail).read_zipper();
      for v235_7_byte in v235_7_cursor.child_mask().iter() {
        v235_7_cursor.descend_to_byte(v235_7_byte);
        {
        let v235_7_tail = v235_7_cursor.fork_read_zipper();
        let v235_7_head = Path::from_slice(&[v235_7_byte]);
        let v236_2: Space = singleton(&(v235_7_head));
        let v236_3: Space = intersect(&(*CONSTANT_2),&(v236_2));
        let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
        drop(v236_3);
        let v236_5: Space = subtract(&(*CONSTANT_1),&(v236_4));
        drop(v236_4);
        let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
          let v237_6: Path = concat_path(&(v235_6),&(v235_7_head));
          let mut v237_7 = Space::new();
          let mut v237_7_cursor = (v235_7_tail).read_zipper();
          for v237_7_byte in v237_7_cursor.child_mask().iter() {
            v237_7_cursor.descend_to_byte(v237_7_byte);
            {
            let v237_7_tail = v237_7_cursor.fork_read_zipper();
            let v237_7_head = Path::from_slice(&[v237_7_byte]);
            let v238_2: Space = singleton(&(v237_7_head));
            let v238_3: Space = intersect(&(*CONSTANT_2),&(v238_2));
            let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
            drop(v238_3);
            let v238_5: Space = subtract(&(*CONSTANT_1),&(v238_4));
            drop(v238_4);
            let v238_8: Space = if (v238_5).is_empty() { Space::new() } else {
              let v239_6: Path = concat_path(&(v237_6),&(v237_7_head));
              let v239_7: Space = routine_21(c, &(v239_6), &(*p1), &(v237_7_tail).make_space(), &(*s1));
              compose(&(v238_5),&(v239_7))
            };
            drop(v238_5);
            let v238_9: Space = intersect(&(*CONSTANT_2),&(v238_2));
            drop(v238_2);
            let v238_10: Space = if has_head(&(v238_9)) { singleton(&[]) } else { Space::new() };
            drop(v238_9);
            let v238_12: Space = if (v238_10).is_empty() { Space::new() } else {
              let v240_6: Path = concat_path(&(v237_6),&(v237_7_head));
              let v240_11: Space = routine_22(c, &(v240_6), &(*p1), &(v237_7_tail).make_space(), &(*s1));
              drop(v240_6);
              compose(&(v238_10),&(v240_11))
            };
            drop(v238_10);
            let v238_13: Space = unite(&(v238_8),&(v238_12));
            v237_7.join_into((v238_13).clone());
            }
            v237_7_cursor.ascend(1);
          }
          drop(v237_7_cursor);
          compose(&(v236_5),&(v237_7))
        };
        drop(v236_5);
        let v236_9: Space = intersect(&(*CONSTANT_2),&(v236_2));
        drop(v236_2);
        let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
        drop(v236_9);
        let v236_12: Space = if (v236_10).is_empty() { Space::new() } else {
          let v241_6: Path = concat_path(&(v235_6),&(v235_7_head));
          let mut v241_11 = Space::new();
          let mut v241_11_cursor = (v235_7_tail).read_zipper();
          for v241_11_byte in v241_11_cursor.child_mask().iter() {
            v241_11_cursor.descend_to_byte(v241_11_byte);
            {
            let v241_11_tail = v241_11_cursor.fork_read_zipper();
            let v241_11_head = Path::from_slice(&[v241_11_byte]);
            let v242_2: Space = singleton(&(v241_11_head));
            let v242_3: Space = intersect(&(*CONSTANT_2),&(v242_2));
            let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
            drop(v242_3);
            let v242_5: Space = subtract(&(*CONSTANT_1),&(v242_4));
            drop(v242_4);
            let v242_8: Space = if (v242_5).is_empty() { Space::new() } else {
              let v243_6: Path = concat_path(&(v241_6),&(v241_11_head));
              let v243_7: Space = routine_21(c, &(v243_6), &(*p1), &(v241_11_tail).make_space(), &(*s1));
              compose(&(v242_5),&(v243_7))
            };
            drop(v242_5);
            let v242_9: Space = intersect(&(*CONSTANT_2),&(v242_2));
            drop(v242_2);
            let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
            drop(v242_9);
            let v242_12: Space = if (v242_10).is_empty() { Space::new() } else {
              let v244_6: Path = concat_path(&(v241_6),&(v241_11_head));
              let v244_11: Space = routine_10(c, &(v244_6), &(*p1), &(v241_11_tail).make_space(), &(*s1));
              drop(v244_6);
              compose(&(v242_10),&(v244_11))
            };
            drop(v242_10);
            let v242_13: Space = unite(&(v242_8),&(v242_12));
            v241_11.join_into((v242_13).clone());
            }
            v241_11_cursor.ascend(1);
          }
          drop(v241_11_cursor);
          drop(v241_6);
          compose(&(v236_10),&(v241_11))
        };
        drop(v236_10);
        let v236_13: Space = unite(&(v236_8),&(v236_12));
        v235_7.join_into((v236_13).clone());
        }
        v235_7_cursor.ascend(1);
      }
      drop(v235_7_cursor);
      compose(&(v234_5),&(v235_7))
    };
    drop(v234_5);
    let v234_9: Space = intersect(&(*CONSTANT_2),&(v234_2));
    drop(v234_2);
    let v234_10: Space = if has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
    drop(v234_9);
    let v234_13: Space = if (v234_10).is_empty() { Space::new() } else {
      let v245_6: Path = concat_path(&(*p0),&(v233_25_head));
      let v245_11: Space = unwrap(&(v233_21),&(v233_25_head));
      let mut v245_12 = Space::new();
      let mut v245_12_cursor = (v233_25_tail).read_zipper();
      for v245_12_byte in v245_12_cursor.child_mask().iter() {
        v245_12_cursor.descend_to_byte(v245_12_byte);
        {
        let v245_12_tail = v245_12_cursor.fork_read_zipper();
        let v245_12_head = Path::from_slice(&[v245_12_byte]);
        let v246_2: Space = singleton(&(v245_12_head));
        let v246_3: Space = intersect(&(*CONSTANT_2),&(v246_2));
        let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
        drop(v246_3);
        let v246_5: Space = subtract(&(*CONSTANT_1),&(v246_4));
        drop(v246_4);
        let v246_8: Space = if (v246_5).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v245_6),&(v245_12_head));
          let mut v247_7 = Space::new();
          let mut v247_7_cursor = (v245_12_tail).read_zipper();
          for v247_7_byte in v247_7_cursor.child_mask().iter() {
            v247_7_cursor.descend_to_byte(v247_7_byte);
            {
            let v247_7_tail = v247_7_cursor.fork_read_zipper();
            let v247_7_head = Path::from_slice(&[v247_7_byte]);
            let v248_2: Space = singleton(&(v247_7_head));
            let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
            let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&(v247_7_head));
              let v249_7: Space = routine_21(c, &(v249_6), &(*p1), &(v247_7_tail).make_space(), &(*s1));
              compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&(v247_7_head));
              let v250_11: Space = routine_22(c, &(v250_6), &(*p1), &(v247_7_tail).make_space(), &(*s1));
              drop(v250_6);
              compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = unite(&(v248_8),&(v248_12));
            v247_7.join_into((v248_13).clone());
            }
            v247_7_cursor.ascend(1);
          }
          drop(v247_7_cursor);
          compose(&(v246_5),&(v247_7))
        };
        drop(v246_5);
        let v246_9: Space = intersect(&(*CONSTANT_2),&(v246_2));
        drop(v246_2);
        let v246_10: Space = if has_head(&(v246_9)) { singleton(&[]) } else { Space::new() };
        drop(v246_9);
        let v246_13: Space = if (v246_10).is_empty() { Space::new() } else {
          let v251_11: Space = unwrap(&(v245_11),&(v245_12_head));
          let v251_12: Space = unwrap(&(v251_11),&(*p1));
          drop(v251_11);
          compose(&(v246_10),&(v251_12))
        };
        drop(v246_10);
        let v252_6: Path = concat_path(&(v245_6),&(v245_12_head));
        let v246_14: Space = wrap(&(v246_13),&(v252_6));
        drop(v246_13);
        let v246_15: Space = wrap(&(v246_14),&(*p1));
        drop(v246_14);
        let v246_16: Space = unite(&(v246_8),&(v246_15));
        drop(v246_15);
        v245_12.join_into((v246_16).clone());
        }
        v245_12_cursor.ascend(1);
      }
      drop(v245_12_cursor);
      drop(v245_6);
      drop(v245_11);
      compose(&(v234_10),&(v245_12))
    };
    drop(v234_10);
    let v234_14: Space = unite(&(v234_8),&(v234_13));
    v233_25.join_into((v234_14).clone());
    }
    v233_25_cursor.ascend(1);
  }
  drop(v233_25_cursor);
  drop(v233_21);
  (v233_25).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v253_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v253_9: Space = unwrap(&(v253_8),&(*p0));
  drop(v253_8);
  let mut v253_19 = Space::new();
  let mut v253_19_cursor = (*s0).read_zipper();
  for v253_19_byte in v253_19_cursor.child_mask().iter() {
    v253_19_cursor.descend_to_byte(v253_19_byte);
    {
    let v253_19_tail = v253_19_cursor.fork_read_zipper();
    let v253_19_head = Path::from_slice(&[v253_19_byte]);
    let v254_2: Space = singleton(&(v253_19_head));
    let v254_3: Space = intersect(&(*CONSTANT_2),&(v254_2));
    let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
    drop(v254_3);
    let v254_5: Space = subtract(&(*CONSTANT_1),&(v254_4));
    drop(v254_4);
    let v254_8: Space = if (v254_5).is_empty() { Space::new() } else {
      let v255_6: Path = concat_path(&(*p0),&(v253_19_head));
      let mut v255_7 = Space::new();
      let mut v255_7_cursor = (v253_19_tail).read_zipper();
      for v255_7_byte in v255_7_cursor.child_mask().iter() {
        v255_7_cursor.descend_to_byte(v255_7_byte);
        {
        let v255_7_tail = v255_7_cursor.fork_read_zipper();
        let v255_7_head = Path::from_slice(&[v255_7_byte]);
        let v256_2: Space = singleton(&(v255_7_head));
        let v256_3: Space = intersect(&(*CONSTANT_2),&(v256_2));
        let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
        drop(v256_3);
        let v256_5: Space = subtract(&(*CONSTANT_1),&(v256_4));
        drop(v256_4);
        let v256_8: Space = if (v256_5).is_empty() { Space::new() } else {
          let v257_6: Path = concat_path(&(v255_6),&(v255_7_head));
          let mut v257_7 = Space::new();
          let mut v257_7_cursor = (v255_7_tail).read_zipper();
          for v257_7_byte in v257_7_cursor.child_mask().iter() {
            v257_7_cursor.descend_to_byte(v257_7_byte);
            {
            let v257_7_tail = v257_7_cursor.fork_read_zipper();
            let v257_7_head = Path::from_slice(&[v257_7_byte]);
            let v258_2: Space = singleton(&(v257_7_head));
            let v258_3: Space = intersect(&(*CONSTANT_2),&(v258_2));
            let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = subtract(&(*CONSTANT_1),&(v258_4));
            drop(v258_4);
            let v258_8: Space = if (v258_5).is_empty() { Space::new() } else {
              let v259_6: Path = concat_path(&(v257_6),&(v257_7_head));
              let v259_7: Space = routine_21(c, &(v259_6), &(*p1), &(v257_7_tail).make_space(), &(*s1));
              compose(&(v258_5),&(v259_7))
            };
            drop(v258_5);
            let v258_9: Space = intersect(&(*CONSTANT_2),&(v258_2));
            drop(v258_2);
            let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
            drop(v258_9);
            let v258_12: Space = if (v258_10).is_empty() { Space::new() } else {
              let v260_6: Path = concat_path(&(v257_6),&(v257_7_head));
              let v260_11: Space = routine_22(c, &(v260_6), &(*p1), &(v257_7_tail).make_space(), &(*s1));
              drop(v260_6);
              compose(&(v258_10),&(v260_11))
            };
            drop(v258_10);
            let v258_13: Space = unite(&(v258_8),&(v258_12));
            v257_7.join_into((v258_13).clone());
            }
            v257_7_cursor.ascend(1);
          }
          drop(v257_7_cursor);
          compose(&(v256_5),&(v257_7))
        };
        drop(v256_5);
        let v256_9: Space = intersect(&(*CONSTANT_2),&(v256_2));
        drop(v256_2);
        let v256_10: Space = if has_head(&(v256_9)) { singleton(&[]) } else { Space::new() };
        drop(v256_9);
        let v256_12: Space = if (v256_10).is_empty() { Space::new() } else {
          let v261_6: Path = concat_path(&(v255_6),&(v255_7_head));
          let mut v261_11 = Space::new();
          let mut v261_11_cursor = (v255_7_tail).read_zipper();
          for v261_11_byte in v261_11_cursor.child_mask().iter() {
            v261_11_cursor.descend_to_byte(v261_11_byte);
            {
            let v261_11_tail = v261_11_cursor.fork_read_zipper();
            let v261_11_head = Path::from_slice(&[v261_11_byte]);
            let v262_2: Space = singleton(&(v261_11_head));
            let v262_3: Space = intersect(&(*CONSTANT_2),&(v262_2));
            let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
            drop(v262_3);
            let v262_5: Space = subtract(&(*CONSTANT_1),&(v262_4));
            drop(v262_4);
            let v262_8: Space = if (v262_5).is_empty() { Space::new() } else {
              let v263_6: Path = concat_path(&(v261_6),&(v261_11_head));
              let v263_7: Space = routine_21(c, &(v263_6), &(*p1), &(v261_11_tail).make_space(), &(*s1));
              compose(&(v262_5),&(v263_7))
            };
            drop(v262_5);
            let v262_9: Space = intersect(&(*CONSTANT_2),&(v262_2));
            drop(v262_2);
            let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
            drop(v262_9);
            let v262_12: Space = if (v262_10).is_empty() { Space::new() } else {
              let v264_6: Path = concat_path(&(v261_6),&(v261_11_head));
              let v264_11: Space = routine_10(c, &(v264_6), &(*p1), &(v261_11_tail).make_space(), &(*s1));
              drop(v264_6);
              compose(&(v262_10),&(v264_11))
            };
            drop(v262_10);
            let v262_13: Space = unite(&(v262_8),&(v262_12));
            v261_11.join_into((v262_13).clone());
            }
            v261_11_cursor.ascend(1);
          }
          drop(v261_11_cursor);
          drop(v261_6);
          compose(&(v256_10),&(v261_11))
        };
        drop(v256_10);
        let v256_13: Space = unite(&(v256_8),&(v256_12));
        v255_7.join_into((v256_13).clone());
        }
        v255_7_cursor.ascend(1);
      }
      drop(v255_7_cursor);
      compose(&(v254_5),&(v255_7))
    };
    drop(v254_5);
    let v254_9: Space = intersect(&(*CONSTANT_2),&(v254_2));
    drop(v254_2);
    let v254_10: Space = if has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
    drop(v254_9);
    let v254_13: Space = if (v254_10).is_empty() { Space::new() } else {
      let v265_11: Space = unwrap(&(v253_9),&(v253_19_head));
      let v265_12: Space = unwrap(&(v265_11),&(*p1));
      drop(v265_11);
      compose(&(v254_10),&(v265_12))
    };
    drop(v254_10);
    let v266_6: Path = concat_path(&(*p0),&(v253_19_head));
    let v254_14: Space = wrap(&(v254_13),&(v266_6));
    drop(v254_13);
    let v254_15: Space = wrap(&(v254_14),&(*p1));
    drop(v254_14);
    let v254_16: Space = unite(&(v254_8),&(v254_15));
    drop(v254_15);
    v253_19.join_into((v254_16).clone());
    }
    v253_19_cursor.ascend(1);
  }
  drop(v253_19_cursor);
  drop(v253_9);
  (v253_19).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v267_10 = Space::new();
  let mut v267_10_cursor = (*s0).read_zipper();
  for v267_10_byte in v267_10_cursor.child_mask().iter() {
    v267_10_cursor.descend_to_byte(v267_10_byte);
    {
    let v267_10_tail = v267_10_cursor.fork_read_zipper();
    let v267_10_head = Path::from_slice(&[v267_10_byte]);
    let v268_2: Space = singleton(&(v267_10_head));
    let v268_3: Space = intersect(&(*CONSTANT_2),&(v268_2));
    let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
    drop(v268_3);
    let v268_5: Space = subtract(&(*CONSTANT_1),&(v268_4));
    drop(v268_4);
    let mut v268_6 = Space::new();
    let mut v268_6_cursor = (v267_10_tail).read_zipper();
    for v268_6_byte in v268_6_cursor.child_mask().iter() {
      v268_6_cursor.descend_to_byte(v268_6_byte);
      {
      let v268_6_tail = v268_6_cursor.fork_read_zipper();
      let v268_6_head = Path::from_slice(&[v268_6_byte]);
      let v269_2: Space = Space::new();
      v268_6.join_into((v269_2).clone());
      }
      v268_6_cursor.ascend(1);
    }
    drop(v268_6_cursor);
    let v268_7: Space = compose(&(v268_5),&(v268_6));
    drop(v268_5);
    drop(v268_6);
    let v268_8: Space = intersect(&(*CONSTANT_2),&(v268_2));
    drop(v268_2);
    let v268_9: Space = if has_head(&(v268_8)) { singleton(&[]) } else { Space::new() };
    drop(v268_8);
    let v268_12: Space = if (v268_9).is_empty() { Space::new() } else {
      let v270_10: Path = concat_path(&(*p0),&(v267_10_head));
      let mut v270_11 = Space::new();
      let mut v270_11_cursor = (v267_10_tail).read_zipper();
      for v270_11_byte in v270_11_cursor.child_mask().iter() {
        v270_11_cursor.descend_to_byte(v270_11_byte);
        {
        let v270_11_tail = v270_11_cursor.fork_read_zipper();
        let v270_11_head = Path::from_slice(&[v270_11_byte]);
        let v271_2: Space = singleton(&(v270_11_head));
        let v271_3: Space = intersect(&(*CONSTANT_2),&(v271_2));
        drop(v271_2);
        let v271_4: Space = if has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
        drop(v271_3);
        let v271_7: Space = if (v271_4).is_empty() { Space::new() } else {
          let v272_5: Path = concat_path(&(v270_10),&(v270_11_head));
          let mut v272_6 = Space::new();
          let mut v272_6_cursor = (v270_11_tail).read_zipper();
          for v272_6_byte in v272_6_cursor.child_mask().iter() {
            v272_6_cursor.descend_to_byte(v272_6_byte);
            {
            let v272_6_tail = v272_6_cursor.fork_read_zipper();
            let v272_6_head = Path::from_slice(&[v272_6_byte]);
            let v273_2: Space = singleton(&(v272_6_head));
            let v273_3: Space = intersect(&(*CONSTANT_2),&(v273_2));
            let v273_4: Space = if has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
            drop(v273_3);
            let v273_5: Space = subtract(&(*CONSTANT_1),&(v273_4));
            drop(v273_4);
            let v273_7: Space = if (v273_5).is_empty() { Space::new() } else {
              let v274_6: Space = routine_4(c, &(v272_6_head), &(v272_5), &(v272_6_tail).make_space(), &(*s1));
              compose(&(v273_5),&(v274_6))
            };
            drop(v273_5);
            let v273_8: Space = intersect(&(*CONSTANT_2),&(v273_2));
            drop(v273_2);
            let v273_9: Space = if has_head(&(v273_8)) { singleton(&[]) } else { Space::new() };
            drop(v273_8);
            let v273_11: Space = if (v273_9).is_empty() { Space::new() } else {
              let v275_10: Space = routine_5(c, &(v272_6_head), &(v272_5), &(v272_6_tail).make_space(), &(*s1));
              compose(&(v273_9),&(v275_10))
            };
            drop(v273_9);
            let v273_12: Space = unite(&(v273_7),&(v273_11));
            v272_6.join_into((v273_12).clone());
            }
            v272_6_cursor.ascend(1);
          }
          drop(v272_6_cursor);
          drop(v272_5);
          compose(&(v271_4),&(v272_6))
        };
        drop(v271_4);
        v270_11.join_into((v271_7).clone());
        }
        v270_11_cursor.ascend(1);
      }
      drop(v270_11_cursor);
      drop(v270_10);
      compose(&(v268_9),&(v270_11))
    };
    drop(v268_9);
    let v268_13: Space = unite(&(v268_7),&(v268_12));
    drop(v268_7);
    v267_10.join_into((v268_13).clone());
    }
    v267_10_cursor.ascend(1);
  }
  drop(v267_10_cursor);
  (v267_10).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v276_15 = Space::new();
  let mut v276_15_cursor = (*s0).read_zipper();
  for v276_15_byte in v276_15_cursor.child_mask().iter() {
    v276_15_cursor.descend_to_byte(v276_15_byte);
    {
    let v276_15_tail = v276_15_cursor.fork_read_zipper();
    let v276_15_head = Path::from_slice(&[v276_15_byte]);
    let v277_2: Space = singleton(&(v276_15_head));
    let v277_3: Space = intersect(&(*CONSTANT_2),&(v277_2));
    let v277_4: Space = if has_head(&(v277_3)) { singleton(&[]) } else { Space::new() };
    drop(v277_3);
    let v277_5: Space = subtract(&(*CONSTANT_1),&(v277_4));
    drop(v277_4);
    let mut v277_6 = Space::new();
    let mut v277_6_cursor = (v276_15_tail).read_zipper();
    for v277_6_byte in v277_6_cursor.child_mask().iter() {
      v277_6_cursor.descend_to_byte(v277_6_byte);
      {
      let v277_6_tail = v277_6_cursor.fork_read_zipper();
      let v277_6_head = Path::from_slice(&[v277_6_byte]);
      let v278_2: Space = Space::new();
      v277_6.join_into((v278_2).clone());
      }
      v277_6_cursor.ascend(1);
    }
    drop(v277_6_cursor);
    let v277_7: Space = compose(&(v277_5),&(v277_6));
    drop(v277_5);
    drop(v277_6);
    let v277_8: Space = intersect(&(*CONSTANT_2),&(v277_2));
    drop(v277_2);
    let v277_9: Space = if has_head(&(v277_8)) { singleton(&[]) } else { Space::new() };
    drop(v277_8);
    let v277_12: Space = if (v277_9).is_empty() { Space::new() } else {
      let v279_10: Path = concat_path(&(*p0),&(v276_15_head));
      let mut v279_11 = Space::new();
      let mut v279_11_cursor = (v276_15_tail).read_zipper();
      for v279_11_byte in v279_11_cursor.child_mask().iter() {
        v279_11_cursor.descend_to_byte(v279_11_byte);
        {
        let v279_11_tail = v279_11_cursor.fork_read_zipper();
        let v279_11_head = Path::from_slice(&[v279_11_byte]);
        let v280_2: Space = singleton(&(v279_11_head));
        let v280_3: Space = intersect(&(*CONSTANT_2),&(v280_2));
        let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
        drop(v280_3);
        let v280_5: Space = subtract(&(*CONSTANT_1),&(v280_4));
        drop(v280_4);
        let v280_7: Space = if (v280_5).is_empty() { Space::new() } else {
          let mut v281_6 = Space::new();
          let mut v281_6_cursor = (v279_11_tail).read_zipper();
          for v281_6_byte in v281_6_cursor.child_mask().iter() {
            v281_6_cursor.descend_to_byte(v281_6_byte);
            {
            let v281_6_tail = v281_6_cursor.fork_read_zipper();
            let v281_6_head = Path::from_slice(&[v281_6_byte]);
            let v282_2: Space = singleton(&(v281_6_head));
            let v282_3: Space = intersect(&(*CONSTANT_2),&(v282_2));
            let v282_4: Space = if has_head(&(v282_3)) { singleton(&[]) } else { Space::new() };
            drop(v282_3);
            let v282_5: Space = subtract(&(*CONSTANT_1),&(v282_4));
            drop(v282_4);
            let v282_8: Space = if (v282_5).is_empty() { Space::new() } else {
              let v283_6: Path = concat_path(&(v279_11_head),&(v281_6_head));
              let v283_7: Space = routine_8(c, &(v283_6), &(v279_10), &(v281_6_tail).make_space(), &(*s1));
              compose(&(v282_5),&(v283_7))
            };
            drop(v282_5);
            let v282_9: Space = intersect(&(*CONSTANT_2),&(v282_2));
            drop(v282_2);
            let v282_10: Space = if has_head(&(v282_9)) { singleton(&[]) } else { Space::new() };
            drop(v282_9);
            let v282_12: Space = if (v282_10).is_empty() { Space::new() } else {
              let v284_6: Path = concat_path(&(v279_11_head),&(v281_6_head));
              let v284_11: Space = routine_9(c, &(v284_6), &(v279_10), &(v281_6_tail).make_space(), &(*s1));
              drop(v284_6);
              compose(&(v282_10),&(v284_11))
            };
            drop(v282_10);
            let v282_13: Space = unite(&(v282_8),&(v282_12));
            v281_6.join_into((v282_13).clone());
            }
            v281_6_cursor.ascend(1);
          }
          drop(v281_6_cursor);
          compose(&(v280_5),&(v281_6))
        };
        drop(v280_5);
        let v280_8: Space = intersect(&(*CONSTANT_2),&(v280_2));
        drop(v280_2);
        let v280_9: Space = if has_head(&(v280_8)) { singleton(&[]) } else { Space::new() };
        drop(v280_8);
        let v280_11: Space = if (v280_9).is_empty() { Space::new() } else {
          let mut v285_10 = Space::new();
          let mut v285_10_cursor = (v279_11_tail).read_zipper();
          for v285_10_byte in v285_10_cursor.child_mask().iter() {
            v285_10_cursor.descend_to_byte(v285_10_byte);
            {
            let v285_10_tail = v285_10_cursor.fork_read_zipper();
            let v285_10_head = Path::from_slice(&[v285_10_byte]);
            let v286_2: Space = singleton(&(v285_10_head));
            let v286_3: Space = intersect(&(*CONSTANT_2),&(v286_2));
            let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
            drop(v286_3);
            let v286_5: Space = subtract(&(*CONSTANT_1),&(v286_4));
            drop(v286_4);
            let v286_8: Space = if (v286_5).is_empty() { Space::new() } else {
              let v287_6: Path = concat_path(&(v279_11_head),&(v285_10_head));
              let v287_7: Space = routine_8(c, &(v287_6), &(v279_10), &(v285_10_tail).make_space(), &(*s1));
              compose(&(v286_5),&(v287_7))
            };
            drop(v286_5);
            let v286_9: Space = intersect(&(*CONSTANT_2),&(v286_2));
            drop(v286_2);
            let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
            drop(v286_9);
            let v286_12: Space = if (v286_10).is_empty() { Space::new() } else {
              let v288_6: Path = concat_path(&(v279_11_head),&(v285_10_head));
              let v288_11: Space = routine_10(c, &(v288_6), &(v279_10), &(v285_10_tail).make_space(), &(*s1));
              drop(v288_6);
              compose(&(v286_10),&(v288_11))
            };
            drop(v286_10);
            let v286_13: Space = unite(&(v286_8),&(v286_12));
            v285_10.join_into((v286_13).clone());
            }
            v285_10_cursor.ascend(1);
          }
          drop(v285_10_cursor);
          compose(&(v280_9),&(v285_10))
        };
        drop(v280_9);
        let v280_12: Space = unite(&(v280_7),&(v280_11));
        v279_11.join_into((v280_12).clone());
        }
        v279_11_cursor.ascend(1);
      }
      drop(v279_11_cursor);
      drop(v279_10);
      compose(&(v277_9),&(v279_11))
    };
    drop(v277_9);
    let v277_13: Space = unite(&(v277_7),&(v277_12));
    drop(v277_7);
    v276_15.join_into((v277_13).clone());
    }
    v276_15_cursor.ascend(1);
  }
  drop(v276_15_cursor);
  (v276_15).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v289_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v289_21: Space = unwrap(&(v289_20),&(*p0));
  drop(v289_20);
  let mut v289_25 = Space::new();
  let mut v289_25_cursor = (*s0).read_zipper();
  for v289_25_byte in v289_25_cursor.child_mask().iter() {
    v289_25_cursor.descend_to_byte(v289_25_byte);
    {
    let v289_25_tail = v289_25_cursor.fork_read_zipper();
    let v289_25_head = Path::from_slice(&[v289_25_byte]);
    let v290_2: Space = singleton(&(v289_25_head));
    let v290_3: Space = intersect(&(*CONSTANT_2),&(v290_2));
    let v290_4: Space = if has_head(&(v290_3)) { singleton(&[]) } else { Space::new() };
    drop(v290_3);
    let v290_5: Space = subtract(&(*CONSTANT_1),&(v290_4));
    drop(v290_4);
    let v290_8: Space = if (v290_5).is_empty() { Space::new() } else {
      let v291_6: Path = concat_path(&(*p0),&(v289_25_head));
      let mut v291_7 = Space::new();
      let mut v291_7_cursor = (v289_25_tail).read_zipper();
      for v291_7_byte in v291_7_cursor.child_mask().iter() {
        v291_7_cursor.descend_to_byte(v291_7_byte);
        {
        let v291_7_tail = v291_7_cursor.fork_read_zipper();
        let v291_7_head = Path::from_slice(&[v291_7_byte]);
        let v292_2: Space = singleton(&(v291_7_head));
        let v292_3: Space = intersect(&(*CONSTANT_2),&(v292_2));
        let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
        drop(v292_3);
        let v292_5: Space = subtract(&(*CONSTANT_1),&(v292_4));
        drop(v292_4);
        let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
          let v293_6: Path = concat_path(&(v291_6),&(v291_7_head));
          let mut v293_7 = Space::new();
          let mut v293_7_cursor = (v291_7_tail).read_zipper();
          for v293_7_byte in v293_7_cursor.child_mask().iter() {
            v293_7_cursor.descend_to_byte(v293_7_byte);
            {
            let v293_7_tail = v293_7_cursor.fork_read_zipper();
            let v293_7_head = Path::from_slice(&[v293_7_byte]);
            let v294_2: Space = singleton(&(v293_7_head));
            let v294_3: Space = intersect(&(*CONSTANT_2),&(v294_2));
            let v294_4: Space = if has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
            drop(v294_3);
            let v294_5: Space = subtract(&(*CONSTANT_1),&(v294_4));
            drop(v294_4);
            let v294_8: Space = if (v294_5).is_empty() { Space::new() } else {
              let v295_6: Path = concat_path(&(v293_6),&(v293_7_head));
              let v295_7: Space = routine_23(c, &(v295_6), &(*p1), &(v293_7_tail).make_space(), &(*s1));
              compose(&(v294_5),&(v295_7))
            };
            drop(v294_5);
            let v294_9: Space = intersect(&(*CONSTANT_2),&(v294_2));
            drop(v294_2);
            let v294_10: Space = if has_head(&(v294_9)) { singleton(&[]) } else { Space::new() };
            drop(v294_9);
            let v294_12: Space = if (v294_10).is_empty() { Space::new() } else {
              let v296_6: Path = concat_path(&(v293_6),&(v293_7_head));
              let v296_11: Space = routine_24(c, &(v296_6), &(*p1), &(v293_7_tail).make_space(), &(*s1));
              drop(v296_6);
              compose(&(v294_10),&(v296_11))
            };
            drop(v294_10);
            let v294_13: Space = unite(&(v294_8),&(v294_12));
            v293_7.join_into((v294_13).clone());
            }
            v293_7_cursor.ascend(1);
          }
          drop(v293_7_cursor);
          compose(&(v292_5),&(v293_7))
        };
        drop(v292_5);
        let v292_9: Space = intersect(&(*CONSTANT_2),&(v292_2));
        drop(v292_2);
        let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
        drop(v292_9);
        let v292_12: Space = if (v292_10).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v291_6),&(v291_7_head));
          let mut v297_11 = Space::new();
          let mut v297_11_cursor = (v291_7_tail).read_zipper();
          for v297_11_byte in v297_11_cursor.child_mask().iter() {
            v297_11_cursor.descend_to_byte(v297_11_byte);
            {
            let v297_11_tail = v297_11_cursor.fork_read_zipper();
            let v297_11_head = Path::from_slice(&[v297_11_byte]);
            let v298_2: Space = singleton(&(v297_11_head));
            let v298_3: Space = intersect(&(*CONSTANT_2),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_1),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (v298_5).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&(v297_11_head));
              let v299_7: Space = routine_23(c, &(v299_6), &(*p1), &(v297_11_tail).make_space(), &(*s1));
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_2),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (v298_10).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&(v297_11_head));
              let v300_11: Space = routine_10(c, &(v300_6), &(*p1), &(v297_11_tail).make_space(), &(*s1));
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            v297_11.join_into((v298_13).clone());
            }
            v297_11_cursor.ascend(1);
          }
          drop(v297_11_cursor);
          drop(v297_6);
          compose(&(v292_10),&(v297_11))
        };
        drop(v292_10);
        let v292_13: Space = unite(&(v292_8),&(v292_12));
        v291_7.join_into((v292_13).clone());
        }
        v291_7_cursor.ascend(1);
      }
      drop(v291_7_cursor);
      compose(&(v290_5),&(v291_7))
    };
    drop(v290_5);
    let v290_9: Space = intersect(&(*CONSTANT_2),&(v290_2));
    drop(v290_2);
    let v290_10: Space = if has_head(&(v290_9)) { singleton(&[]) } else { Space::new() };
    drop(v290_9);
    let v290_13: Space = if (v290_10).is_empty() { Space::new() } else {
      let v301_6: Path = concat_path(&(*p0),&(v289_25_head));
      let v301_11: Space = unwrap(&(v289_21),&(v289_25_head));
      let mut v301_12 = Space::new();
      let mut v301_12_cursor = (v289_25_tail).read_zipper();
      for v301_12_byte in v301_12_cursor.child_mask().iter() {
        v301_12_cursor.descend_to_byte(v301_12_byte);
        {
        let v301_12_tail = v301_12_cursor.fork_read_zipper();
        let v301_12_head = Path::from_slice(&[v301_12_byte]);
        let v302_2: Space = singleton(&(v301_12_head));
        let v302_3: Space = intersect(&(*CONSTANT_2),&(v302_2));
        let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
        drop(v302_3);
        let v302_5: Space = subtract(&(*CONSTANT_1),&(v302_4));
        drop(v302_4);
        let v302_8: Space = if (v302_5).is_empty() { Space::new() } else {
          let v303_6: Path = concat_path(&(v301_6),&(v301_12_head));
          let mut v303_7 = Space::new();
          let mut v303_7_cursor = (v301_12_tail).read_zipper();
          for v303_7_byte in v303_7_cursor.child_mask().iter() {
            v303_7_cursor.descend_to_byte(v303_7_byte);
            {
            let v303_7_tail = v303_7_cursor.fork_read_zipper();
            let v303_7_head = Path::from_slice(&[v303_7_byte]);
            let v304_2: Space = singleton(&(v303_7_head));
            let v304_3: Space = intersect(&(*CONSTANT_2),&(v304_2));
            let v304_4: Space = if has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
            drop(v304_3);
            let v304_5: Space = subtract(&(*CONSTANT_1),&(v304_4));
            drop(v304_4);
            let v304_8: Space = if (v304_5).is_empty() { Space::new() } else {
              let v305_6: Path = concat_path(&(v303_6),&(v303_7_head));
              let v305_7: Space = routine_23(c, &(v305_6), &(*p1), &(v303_7_tail).make_space(), &(*s1));
              compose(&(v304_5),&(v305_7))
            };
            drop(v304_5);
            let v304_9: Space = intersect(&(*CONSTANT_2),&(v304_2));
            drop(v304_2);
            let v304_10: Space = if has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
            drop(v304_9);
            let v304_12: Space = if (v304_10).is_empty() { Space::new() } else {
              let v306_6: Path = concat_path(&(v303_6),&(v303_7_head));
              let v306_11: Space = routine_24(c, &(v306_6), &(*p1), &(v303_7_tail).make_space(), &(*s1));
              drop(v306_6);
              compose(&(v304_10),&(v306_11))
            };
            drop(v304_10);
            let v304_13: Space = unite(&(v304_8),&(v304_12));
            v303_7.join_into((v304_13).clone());
            }
            v303_7_cursor.ascend(1);
          }
          drop(v303_7_cursor);
          compose(&(v302_5),&(v303_7))
        };
        drop(v302_5);
        let v302_9: Space = intersect(&(*CONSTANT_2),&(v302_2));
        drop(v302_2);
        let v302_10: Space = if has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
        drop(v302_9);
        let v302_13: Space = if (v302_10).is_empty() { Space::new() } else {
          let v307_11: Space = unwrap(&(v301_11),&(v301_12_head));
          let v307_12: Space = unwrap(&(v307_11),&(*p1));
          drop(v307_11);
          compose(&(v302_10),&(v307_12))
        };
        drop(v302_10);
        let v308_6: Path = concat_path(&(v301_6),&(v301_12_head));
        let v302_14: Space = wrap(&(v302_13),&(v308_6));
        drop(v302_13);
        let v302_15: Space = wrap(&(v302_14),&(*p1));
        drop(v302_14);
        let v302_16: Space = unite(&(v302_8),&(v302_15));
        drop(v302_15);
        v301_12.join_into((v302_16).clone());
        }
        v301_12_cursor.ascend(1);
      }
      drop(v301_12_cursor);
      drop(v301_6);
      drop(v301_11);
      compose(&(v290_10),&(v301_12))
    };
    drop(v290_10);
    let v290_14: Space = unite(&(v290_8),&(v290_13));
    v289_25.join_into((v290_14).clone());
    }
    v289_25_cursor.ascend(1);
  }
  drop(v289_25_cursor);
  drop(v289_21);
  (v289_25).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v309_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v309_9: Space = unwrap(&(v309_8),&(*p0));
  drop(v309_8);
  let mut v309_19 = Space::new();
  let mut v309_19_cursor = (*s0).read_zipper();
  for v309_19_byte in v309_19_cursor.child_mask().iter() {
    v309_19_cursor.descend_to_byte(v309_19_byte);
    {
    let v309_19_tail = v309_19_cursor.fork_read_zipper();
    let v309_19_head = Path::from_slice(&[v309_19_byte]);
    let v310_2: Space = singleton(&(v309_19_head));
    let v310_3: Space = intersect(&(*CONSTANT_2),&(v310_2));
    let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
    drop(v310_3);
    let v310_5: Space = subtract(&(*CONSTANT_1),&(v310_4));
    drop(v310_4);
    let v310_8: Space = if (v310_5).is_empty() { Space::new() } else {
      let v311_6: Path = concat_path(&(*p0),&(v309_19_head));
      let mut v311_7 = Space::new();
      let mut v311_7_cursor = (v309_19_tail).read_zipper();
      for v311_7_byte in v311_7_cursor.child_mask().iter() {
        v311_7_cursor.descend_to_byte(v311_7_byte);
        {
        let v311_7_tail = v311_7_cursor.fork_read_zipper();
        let v311_7_head = Path::from_slice(&[v311_7_byte]);
        let v312_2: Space = singleton(&(v311_7_head));
        let v312_3: Space = intersect(&(*CONSTANT_2),&(v312_2));
        let v312_4: Space = if has_head(&(v312_3)) { singleton(&[]) } else { Space::new() };
        drop(v312_3);
        let v312_5: Space = subtract(&(*CONSTANT_1),&(v312_4));
        drop(v312_4);
        let v312_8: Space = if (v312_5).is_empty() { Space::new() } else {
          let v313_6: Path = concat_path(&(v311_6),&(v311_7_head));
          let mut v313_7 = Space::new();
          let mut v313_7_cursor = (v311_7_tail).read_zipper();
          for v313_7_byte in v313_7_cursor.child_mask().iter() {
            v313_7_cursor.descend_to_byte(v313_7_byte);
            {
            let v313_7_tail = v313_7_cursor.fork_read_zipper();
            let v313_7_head = Path::from_slice(&[v313_7_byte]);
            let v314_2: Space = singleton(&(v313_7_head));
            let v314_3: Space = intersect(&(*CONSTANT_2),&(v314_2));
            let v314_4: Space = if has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
            drop(v314_3);
            let v314_5: Space = subtract(&(*CONSTANT_1),&(v314_4));
            drop(v314_4);
            let v314_8: Space = if (v314_5).is_empty() { Space::new() } else {
              let v315_6: Path = concat_path(&(v313_6),&(v313_7_head));
              let v315_7: Space = routine_23(c, &(v315_6), &(*p1), &(v313_7_tail).make_space(), &(*s1));
              compose(&(v314_5),&(v315_7))
            };
            drop(v314_5);
            let v314_9: Space = intersect(&(*CONSTANT_2),&(v314_2));
            drop(v314_2);
            let v314_10: Space = if has_head(&(v314_9)) { singleton(&[]) } else { Space::new() };
            drop(v314_9);
            let v314_12: Space = if (v314_10).is_empty() { Space::new() } else {
              let v316_6: Path = concat_path(&(v313_6),&(v313_7_head));
              let v316_11: Space = routine_24(c, &(v316_6), &(*p1), &(v313_7_tail).make_space(), &(*s1));
              drop(v316_6);
              compose(&(v314_10),&(v316_11))
            };
            drop(v314_10);
            let v314_13: Space = unite(&(v314_8),&(v314_12));
            v313_7.join_into((v314_13).clone());
            }
            v313_7_cursor.ascend(1);
          }
          drop(v313_7_cursor);
          compose(&(v312_5),&(v313_7))
        };
        drop(v312_5);
        let v312_9: Space = intersect(&(*CONSTANT_2),&(v312_2));
        drop(v312_2);
        let v312_10: Space = if has_head(&(v312_9)) { singleton(&[]) } else { Space::new() };
        drop(v312_9);
        let v312_12: Space = if (v312_10).is_empty() { Space::new() } else {
          let v317_6: Path = concat_path(&(v311_6),&(v311_7_head));
          let mut v317_11 = Space::new();
          let mut v317_11_cursor = (v311_7_tail).read_zipper();
          for v317_11_byte in v317_11_cursor.child_mask().iter() {
            v317_11_cursor.descend_to_byte(v317_11_byte);
            {
            let v317_11_tail = v317_11_cursor.fork_read_zipper();
            let v317_11_head = Path::from_slice(&[v317_11_byte]);
            let v318_2: Space = singleton(&(v317_11_head));
            let v318_3: Space = intersect(&(*CONSTANT_2),&(v318_2));
            let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
            drop(v318_3);
            let v318_5: Space = subtract(&(*CONSTANT_1),&(v318_4));
            drop(v318_4);
            let v318_8: Space = if (v318_5).is_empty() { Space::new() } else {
              let v319_6: Path = concat_path(&(v317_6),&(v317_11_head));
              let v319_7: Space = routine_23(c, &(v319_6), &(*p1), &(v317_11_tail).make_space(), &(*s1));
              compose(&(v318_5),&(v319_7))
            };
            drop(v318_5);
            let v318_9: Space = intersect(&(*CONSTANT_2),&(v318_2));
            drop(v318_2);
            let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
            drop(v318_9);
            let v318_12: Space = if (v318_10).is_empty() { Space::new() } else {
              let v320_6: Path = concat_path(&(v317_6),&(v317_11_head));
              let v320_11: Space = routine_10(c, &(v320_6), &(*p1), &(v317_11_tail).make_space(), &(*s1));
              drop(v320_6);
              compose(&(v318_10),&(v320_11))
            };
            drop(v318_10);
            let v318_13: Space = unite(&(v318_8),&(v318_12));
            v317_11.join_into((v318_13).clone());
            }
            v317_11_cursor.ascend(1);
          }
          drop(v317_11_cursor);
          drop(v317_6);
          compose(&(v312_10),&(v317_11))
        };
        drop(v312_10);
        let v312_13: Space = unite(&(v312_8),&(v312_12));
        v311_7.join_into((v312_13).clone());
        }
        v311_7_cursor.ascend(1);
      }
      drop(v311_7_cursor);
      compose(&(v310_5),&(v311_7))
    };
    drop(v310_5);
    let v310_9: Space = intersect(&(*CONSTANT_2),&(v310_2));
    drop(v310_2);
    let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
    drop(v310_9);
    let v310_13: Space = if (v310_10).is_empty() { Space::new() } else {
      let v321_11: Space = unwrap(&(v309_9),&(v309_19_head));
      let v321_12: Space = unwrap(&(v321_11),&(*p1));
      drop(v321_11);
      compose(&(v310_10),&(v321_12))
    };
    drop(v310_10);
    let v322_6: Path = concat_path(&(*p0),&(v309_19_head));
    let v310_14: Space = wrap(&(v310_13),&(v322_6));
    drop(v310_13);
    let v310_15: Space = wrap(&(v310_14),&(*p1));
    drop(v310_14);
    let v310_16: Space = unite(&(v310_8),&(v310_15));
    drop(v310_15);
    v309_19.join_into((v310_16).clone());
    }
    v309_19_cursor.ascend(1);
  }
  drop(v309_19_cursor);
  drop(v309_9);
  (v309_19).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v323_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v323_21: Space = unwrap(&(v323_20),&(*p0));
  drop(v323_20);
  let mut v323_25 = Space::new();
  let mut v323_25_cursor = (*s0).read_zipper();
  for v323_25_byte in v323_25_cursor.child_mask().iter() {
    v323_25_cursor.descend_to_byte(v323_25_byte);
    {
    let v323_25_tail = v323_25_cursor.fork_read_zipper();
    let v323_25_head = Path::from_slice(&[v323_25_byte]);
    let v324_2: Space = singleton(&(v323_25_head));
    let v324_3: Space = intersect(&(*CONSTANT_2),&(v324_2));
    let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
    drop(v324_3);
    let v324_5: Space = subtract(&(*CONSTANT_1),&(v324_4));
    drop(v324_4);
    let v324_8: Space = if (v324_5).is_empty() { Space::new() } else {
      let v325_6: Path = concat_path(&(*p0),&(v323_25_head));
      let mut v325_7 = Space::new();
      let mut v325_7_cursor = (v323_25_tail).read_zipper();
      for v325_7_byte in v325_7_cursor.child_mask().iter() {
        v325_7_cursor.descend_to_byte(v325_7_byte);
        {
        let v325_7_tail = v325_7_cursor.fork_read_zipper();
        let v325_7_head = Path::from_slice(&[v325_7_byte]);
        let v326_2: Space = singleton(&(v325_7_head));
        let v326_3: Space = intersect(&(*CONSTANT_2),&(v326_2));
        let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
        drop(v326_3);
        let v326_5: Space = subtract(&(*CONSTANT_1),&(v326_4));
        drop(v326_4);
        let v326_8: Space = if (v326_5).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v325_6),&(v325_7_head));
          let mut v327_7 = Space::new();
          let mut v327_7_cursor = (v325_7_tail).read_zipper();
          for v327_7_byte in v327_7_cursor.child_mask().iter() {
            v327_7_cursor.descend_to_byte(v327_7_byte);
            {
            let v327_7_tail = v327_7_cursor.fork_read_zipper();
            let v327_7_head = Path::from_slice(&[v327_7_byte]);
            let v328_2: Space = singleton(&(v327_7_head));
            let v328_3: Space = intersect(&(*CONSTANT_2),&(v328_2));
            let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
            drop(v328_3);
            let v328_5: Space = subtract(&(*CONSTANT_1),&(v328_4));
            drop(v328_4);
            let v328_8: Space = if (v328_5).is_empty() { Space::new() } else {
              let v329_6: Path = concat_path(&(v327_6),&(v327_7_head));
              let v329_7: Space = routine_25(c, &(v329_6), &(*p1), &(v327_7_tail).make_space(), &(*s1));
              compose(&(v328_5),&(v329_7))
            };
            drop(v328_5);
            let v328_9: Space = intersect(&(*CONSTANT_2),&(v328_2));
            drop(v328_2);
            let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
            drop(v328_9);
            let v328_12: Space = if (v328_10).is_empty() { Space::new() } else {
              let v330_6: Path = concat_path(&(v327_6),&(v327_7_head));
              let v330_11: Space = routine_26(c, &(v330_6), &(*p1), &(v327_7_tail).make_space(), &(*s1));
              drop(v330_6);
              compose(&(v328_10),&(v330_11))
            };
            drop(v328_10);
            let v328_13: Space = unite(&(v328_8),&(v328_12));
            v327_7.join_into((v328_13).clone());
            }
            v327_7_cursor.ascend(1);
          }
          drop(v327_7_cursor);
          compose(&(v326_5),&(v327_7))
        };
        drop(v326_5);
        let v326_9: Space = intersect(&(*CONSTANT_2),&(v326_2));
        drop(v326_2);
        let v326_10: Space = if has_head(&(v326_9)) { singleton(&[]) } else { Space::new() };
        drop(v326_9);
        let v326_12: Space = if (v326_10).is_empty() { Space::new() } else {
          let v331_6: Path = concat_path(&(v325_6),&(v325_7_head));
          let mut v331_11 = Space::new();
          let mut v331_11_cursor = (v325_7_tail).read_zipper();
          for v331_11_byte in v331_11_cursor.child_mask().iter() {
            v331_11_cursor.descend_to_byte(v331_11_byte);
            {
            let v331_11_tail = v331_11_cursor.fork_read_zipper();
            let v331_11_head = Path::from_slice(&[v331_11_byte]);
            let v332_2: Space = singleton(&(v331_11_head));
            let v332_3: Space = intersect(&(*CONSTANT_2),&(v332_2));
            let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
            drop(v332_3);
            let v332_5: Space = subtract(&(*CONSTANT_1),&(v332_4));
            drop(v332_4);
            let v332_8: Space = if (v332_5).is_empty() { Space::new() } else {
              let v333_6: Path = concat_path(&(v331_6),&(v331_11_head));
              let v333_7: Space = routine_25(c, &(v333_6), &(*p1), &(v331_11_tail).make_space(), &(*s1));
              compose(&(v332_5),&(v333_7))
            };
            drop(v332_5);
            let v332_9: Space = intersect(&(*CONSTANT_2),&(v332_2));
            drop(v332_2);
            let v332_10: Space = if has_head(&(v332_9)) { singleton(&[]) } else { Space::new() };
            drop(v332_9);
            let v332_12: Space = if (v332_10).is_empty() { Space::new() } else {
              let v334_6: Path = concat_path(&(v331_6),&(v331_11_head));
              let v334_11: Space = routine_10(c, &(v334_6), &(*p1), &(v331_11_tail).make_space(), &(*s1));
              drop(v334_6);
              compose(&(v332_10),&(v334_11))
            };
            drop(v332_10);
            let v332_13: Space = unite(&(v332_8),&(v332_12));
            v331_11.join_into((v332_13).clone());
            }
            v331_11_cursor.ascend(1);
          }
          drop(v331_11_cursor);
          drop(v331_6);
          compose(&(v326_10),&(v331_11))
        };
        drop(v326_10);
        let v326_13: Space = unite(&(v326_8),&(v326_12));
        v325_7.join_into((v326_13).clone());
        }
        v325_7_cursor.ascend(1);
      }
      drop(v325_7_cursor);
      compose(&(v324_5),&(v325_7))
    };
    drop(v324_5);
    let v324_9: Space = intersect(&(*CONSTANT_2),&(v324_2));
    drop(v324_2);
    let v324_10: Space = if has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
    drop(v324_9);
    let v324_13: Space = if (v324_10).is_empty() { Space::new() } else {
      let v335_6: Path = concat_path(&(*p0),&(v323_25_head));
      let v335_11: Space = unwrap(&(v323_21),&(v323_25_head));
      let mut v335_12 = Space::new();
      let mut v335_12_cursor = (v323_25_tail).read_zipper();
      for v335_12_byte in v335_12_cursor.child_mask().iter() {
        v335_12_cursor.descend_to_byte(v335_12_byte);
        {
        let v335_12_tail = v335_12_cursor.fork_read_zipper();
        let v335_12_head = Path::from_slice(&[v335_12_byte]);
        let v336_2: Space = singleton(&(v335_12_head));
        let v336_3: Space = intersect(&(*CONSTANT_2),&(v336_2));
        let v336_4: Space = if has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
        drop(v336_3);
        let v336_5: Space = subtract(&(*CONSTANT_1),&(v336_4));
        drop(v336_4);
        let v336_8: Space = if (v336_5).is_empty() { Space::new() } else {
          let v337_6: Path = concat_path(&(v335_6),&(v335_12_head));
          let mut v337_7 = Space::new();
          let mut v337_7_cursor = (v335_12_tail).read_zipper();
          for v337_7_byte in v337_7_cursor.child_mask().iter() {
            v337_7_cursor.descend_to_byte(v337_7_byte);
            {
            let v337_7_tail = v337_7_cursor.fork_read_zipper();
            let v337_7_head = Path::from_slice(&[v337_7_byte]);
            let v338_2: Space = singleton(&(v337_7_head));
            let v338_3: Space = intersect(&(*CONSTANT_2),&(v338_2));
            let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
            drop(v338_3);
            let v338_5: Space = subtract(&(*CONSTANT_1),&(v338_4));
            drop(v338_4);
            let v338_8: Space = if (v338_5).is_empty() { Space::new() } else {
              let v339_6: Path = concat_path(&(v337_6),&(v337_7_head));
              let v339_7: Space = routine_25(c, &(v339_6), &(*p1), &(v337_7_tail).make_space(), &(*s1));
              compose(&(v338_5),&(v339_7))
            };
            drop(v338_5);
            let v338_9: Space = intersect(&(*CONSTANT_2),&(v338_2));
            drop(v338_2);
            let v338_10: Space = if has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
            drop(v338_9);
            let v338_12: Space = if (v338_10).is_empty() { Space::new() } else {
              let v340_6: Path = concat_path(&(v337_6),&(v337_7_head));
              let v340_11: Space = routine_26(c, &(v340_6), &(*p1), &(v337_7_tail).make_space(), &(*s1));
              drop(v340_6);
              compose(&(v338_10),&(v340_11))
            };
            drop(v338_10);
            let v338_13: Space = unite(&(v338_8),&(v338_12));
            v337_7.join_into((v338_13).clone());
            }
            v337_7_cursor.ascend(1);
          }
          drop(v337_7_cursor);
          compose(&(v336_5),&(v337_7))
        };
        drop(v336_5);
        let v336_9: Space = intersect(&(*CONSTANT_2),&(v336_2));
        drop(v336_2);
        let v336_10: Space = if has_head(&(v336_9)) { singleton(&[]) } else { Space::new() };
        drop(v336_9);
        let v336_13: Space = if (v336_10).is_empty() { Space::new() } else {
          let v341_11: Space = unwrap(&(v335_11),&(v335_12_head));
          let v341_12: Space = unwrap(&(v341_11),&(*p1));
          drop(v341_11);
          compose(&(v336_10),&(v341_12))
        };
        drop(v336_10);
        let v342_6: Path = concat_path(&(v335_6),&(v335_12_head));
        let v336_14: Space = wrap(&(v336_13),&(v342_6));
        drop(v336_13);
        let v336_15: Space = wrap(&(v336_14),&(*p1));
        drop(v336_14);
        let v336_16: Space = unite(&(v336_8),&(v336_15));
        drop(v336_15);
        v335_12.join_into((v336_16).clone());
        }
        v335_12_cursor.ascend(1);
      }
      drop(v335_12_cursor);
      drop(v335_6);
      drop(v335_11);
      compose(&(v324_10),&(v335_12))
    };
    drop(v324_10);
    let v324_14: Space = unite(&(v324_8),&(v324_13));
    v323_25.join_into((v324_14).clone());
    }
    v323_25_cursor.ascend(1);
  }
  drop(v323_25_cursor);
  drop(v323_21);
  (v323_25).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v343_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v343_9: Space = unwrap(&(v343_8),&(*p0));
  drop(v343_8);
  let mut v343_19 = Space::new();
  let mut v343_19_cursor = (*s0).read_zipper();
  for v343_19_byte in v343_19_cursor.child_mask().iter() {
    v343_19_cursor.descend_to_byte(v343_19_byte);
    {
    let v343_19_tail = v343_19_cursor.fork_read_zipper();
    let v343_19_head = Path::from_slice(&[v343_19_byte]);
    let v344_2: Space = singleton(&(v343_19_head));
    let v344_3: Space = intersect(&(*CONSTANT_2),&(v344_2));
    let v344_4: Space = if has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
    drop(v344_3);
    let v344_5: Space = subtract(&(*CONSTANT_1),&(v344_4));
    drop(v344_4);
    let v344_8: Space = if (v344_5).is_empty() { Space::new() } else {
      let v345_6: Path = concat_path(&(*p0),&(v343_19_head));
      let mut v345_7 = Space::new();
      let mut v345_7_cursor = (v343_19_tail).read_zipper();
      for v345_7_byte in v345_7_cursor.child_mask().iter() {
        v345_7_cursor.descend_to_byte(v345_7_byte);
        {
        let v345_7_tail = v345_7_cursor.fork_read_zipper();
        let v345_7_head = Path::from_slice(&[v345_7_byte]);
        let v346_2: Space = singleton(&(v345_7_head));
        let v346_3: Space = intersect(&(*CONSTANT_2),&(v346_2));
        let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
        drop(v346_3);
        let v346_5: Space = subtract(&(*CONSTANT_1),&(v346_4));
        drop(v346_4);
        let v346_8: Space = if (v346_5).is_empty() { Space::new() } else {
          let v347_6: Path = concat_path(&(v345_6),&(v345_7_head));
          let mut v347_7 = Space::new();
          let mut v347_7_cursor = (v345_7_tail).read_zipper();
          for v347_7_byte in v347_7_cursor.child_mask().iter() {
            v347_7_cursor.descend_to_byte(v347_7_byte);
            {
            let v347_7_tail = v347_7_cursor.fork_read_zipper();
            let v347_7_head = Path::from_slice(&[v347_7_byte]);
            let v348_2: Space = singleton(&(v347_7_head));
            let v348_3: Space = intersect(&(*CONSTANT_2),&(v348_2));
            let v348_4: Space = if has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
            drop(v348_3);
            let v348_5: Space = subtract(&(*CONSTANT_1),&(v348_4));
            drop(v348_4);
            let v348_8: Space = if (v348_5).is_empty() { Space::new() } else {
              let v349_6: Path = concat_path(&(v347_6),&(v347_7_head));
              let v349_7: Space = routine_25(c, &(v349_6), &(*p1), &(v347_7_tail).make_space(), &(*s1));
              compose(&(v348_5),&(v349_7))
            };
            drop(v348_5);
            let v348_9: Space = intersect(&(*CONSTANT_2),&(v348_2));
            drop(v348_2);
            let v348_10: Space = if has_head(&(v348_9)) { singleton(&[]) } else { Space::new() };
            drop(v348_9);
            let v348_12: Space = if (v348_10).is_empty() { Space::new() } else {
              let v350_6: Path = concat_path(&(v347_6),&(v347_7_head));
              let v350_11: Space = routine_26(c, &(v350_6), &(*p1), &(v347_7_tail).make_space(), &(*s1));
              drop(v350_6);
              compose(&(v348_10),&(v350_11))
            };
            drop(v348_10);
            let v348_13: Space = unite(&(v348_8),&(v348_12));
            v347_7.join_into((v348_13).clone());
            }
            v347_7_cursor.ascend(1);
          }
          drop(v347_7_cursor);
          compose(&(v346_5),&(v347_7))
        };
        drop(v346_5);
        let v346_9: Space = intersect(&(*CONSTANT_2),&(v346_2));
        drop(v346_2);
        let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
        drop(v346_9);
        let v346_12: Space = if (v346_10).is_empty() { Space::new() } else {
          let v351_6: Path = concat_path(&(v345_6),&(v345_7_head));
          let mut v351_11 = Space::new();
          let mut v351_11_cursor = (v345_7_tail).read_zipper();
          for v351_11_byte in v351_11_cursor.child_mask().iter() {
            v351_11_cursor.descend_to_byte(v351_11_byte);
            {
            let v351_11_tail = v351_11_cursor.fork_read_zipper();
            let v351_11_head = Path::from_slice(&[v351_11_byte]);
            let v352_2: Space = singleton(&(v351_11_head));
            let v352_3: Space = intersect(&(*CONSTANT_2),&(v352_2));
            let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = subtract(&(*CONSTANT_1),&(v352_4));
            drop(v352_4);
            let v352_8: Space = if (v352_5).is_empty() { Space::new() } else {
              let v353_6: Path = concat_path(&(v351_6),&(v351_11_head));
              let v353_7: Space = routine_25(c, &(v353_6), &(*p1), &(v351_11_tail).make_space(), &(*s1));
              compose(&(v352_5),&(v353_7))
            };
            drop(v352_5);
            let v352_9: Space = intersect(&(*CONSTANT_2),&(v352_2));
            drop(v352_2);
            let v352_10: Space = if has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
            drop(v352_9);
            let v352_12: Space = if (v352_10).is_empty() { Space::new() } else {
              let v354_6: Path = concat_path(&(v351_6),&(v351_11_head));
              let v354_11: Space = routine_10(c, &(v354_6), &(*p1), &(v351_11_tail).make_space(), &(*s1));
              drop(v354_6);
              compose(&(v352_10),&(v354_11))
            };
            drop(v352_10);
            let v352_13: Space = unite(&(v352_8),&(v352_12));
            v351_11.join_into((v352_13).clone());
            }
            v351_11_cursor.ascend(1);
          }
          drop(v351_11_cursor);
          drop(v351_6);
          compose(&(v346_10),&(v351_11))
        };
        drop(v346_10);
        let v346_13: Space = unite(&(v346_8),&(v346_12));
        v345_7.join_into((v346_13).clone());
        }
        v345_7_cursor.ascend(1);
      }
      drop(v345_7_cursor);
      compose(&(v344_5),&(v345_7))
    };
    drop(v344_5);
    let v344_9: Space = intersect(&(*CONSTANT_2),&(v344_2));
    drop(v344_2);
    let v344_10: Space = if has_head(&(v344_9)) { singleton(&[]) } else { Space::new() };
    drop(v344_9);
    let v344_13: Space = if (v344_10).is_empty() { Space::new() } else {
      let v355_11: Space = unwrap(&(v343_9),&(v343_19_head));
      let v355_12: Space = unwrap(&(v355_11),&(*p1));
      drop(v355_11);
      compose(&(v344_10),&(v355_12))
    };
    drop(v344_10);
    let v356_6: Path = concat_path(&(*p0),&(v343_19_head));
    let v344_14: Space = wrap(&(v344_13),&(v356_6));
    drop(v344_13);
    let v344_15: Space = wrap(&(v344_14),&(*p1));
    drop(v344_14);
    let v344_16: Space = unite(&(v344_8),&(v344_15));
    drop(v344_15);
    v343_19.join_into((v344_16).clone());
    }
    v343_19_cursor.ascend(1);
  }
  drop(v343_19_cursor);
  drop(v343_9);
  (v343_19).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v357_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v357_21: Space = unwrap(&(v357_20),&(*p0));
  drop(v357_20);
  let mut v357_25 = Space::new();
  let mut v357_25_cursor = (*s0).read_zipper();
  for v357_25_byte in v357_25_cursor.child_mask().iter() {
    v357_25_cursor.descend_to_byte(v357_25_byte);
    {
    let v357_25_tail = v357_25_cursor.fork_read_zipper();
    let v357_25_head = Path::from_slice(&[v357_25_byte]);
    let v358_2: Space = singleton(&(v357_25_head));
    let v358_3: Space = intersect(&(*CONSTANT_2),&(v358_2));
    let v358_4: Space = if has_head(&(v358_3)) { singleton(&[]) } else { Space::new() };
    drop(v358_3);
    let v358_5: Space = subtract(&(*CONSTANT_1),&(v358_4));
    drop(v358_4);
    let v358_8: Space = if (v358_5).is_empty() { Space::new() } else {
      let v359_6: Path = concat_path(&(*p0),&(v357_25_head));
      let mut v359_7 = Space::new();
      let mut v359_7_cursor = (v357_25_tail).read_zipper();
      for v359_7_byte in v359_7_cursor.child_mask().iter() {
        v359_7_cursor.descend_to_byte(v359_7_byte);
        {
        let v359_7_tail = v359_7_cursor.fork_read_zipper();
        let v359_7_head = Path::from_slice(&[v359_7_byte]);
        let v360_2: Space = singleton(&(v359_7_head));
        let v360_3: Space = intersect(&(*CONSTANT_2),&(v360_2));
        let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
        drop(v360_3);
        let v360_5: Space = subtract(&(*CONSTANT_1),&(v360_4));
        drop(v360_4);
        let v360_8: Space = if (v360_5).is_empty() { Space::new() } else {
          let v361_6: Path = concat_path(&(v359_6),&(v359_7_head));
          let mut v361_7 = Space::new();
          let mut v361_7_cursor = (v359_7_tail).read_zipper();
          for v361_7_byte in v361_7_cursor.child_mask().iter() {
            v361_7_cursor.descend_to_byte(v361_7_byte);
            {
            let v361_7_tail = v361_7_cursor.fork_read_zipper();
            let v361_7_head = Path::from_slice(&[v361_7_byte]);
            let v362_2: Space = singleton(&(v361_7_head));
            let v362_3: Space = intersect(&(*CONSTANT_2),&(v362_2));
            let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
            drop(v362_3);
            let v362_5: Space = subtract(&(*CONSTANT_1),&(v362_4));
            drop(v362_4);
            let v362_8: Space = if (v362_5).is_empty() { Space::new() } else {
              let v363_6: Path = concat_path(&(v361_6),&(v361_7_head));
              let v363_7: Space = routine_27(c, &(v363_6), &(*p1), &(v361_7_tail).make_space(), &(*s1));
              compose(&(v362_5),&(v363_7))
            };
            drop(v362_5);
            let v362_9: Space = intersect(&(*CONSTANT_2),&(v362_2));
            drop(v362_2);
            let v362_10: Space = if has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
            drop(v362_9);
            let v362_12: Space = if (v362_10).is_empty() { Space::new() } else {
              let v364_6: Path = concat_path(&(v361_6),&(v361_7_head));
              let v364_11: Space = routine_28(c, &(v364_6), &(*p1), &(v361_7_tail).make_space(), &(*s1));
              drop(v364_6);
              compose(&(v362_10),&(v364_11))
            };
            drop(v362_10);
            let v362_13: Space = unite(&(v362_8),&(v362_12));
            v361_7.join_into((v362_13).clone());
            }
            v361_7_cursor.ascend(1);
          }
          drop(v361_7_cursor);
          compose(&(v360_5),&(v361_7))
        };
        drop(v360_5);
        let v360_9: Space = intersect(&(*CONSTANT_2),&(v360_2));
        drop(v360_2);
        let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
        drop(v360_9);
        let v360_12: Space = if (v360_10).is_empty() { Space::new() } else {
          let v365_6: Path = concat_path(&(v359_6),&(v359_7_head));
          let mut v365_11 = Space::new();
          let mut v365_11_cursor = (v359_7_tail).read_zipper();
          for v365_11_byte in v365_11_cursor.child_mask().iter() {
            v365_11_cursor.descend_to_byte(v365_11_byte);
            {
            let v365_11_tail = v365_11_cursor.fork_read_zipper();
            let v365_11_head = Path::from_slice(&[v365_11_byte]);
            let v366_2: Space = singleton(&(v365_11_head));
            let v366_3: Space = intersect(&(*CONSTANT_2),&(v366_2));
            let v366_4: Space = if has_head(&(v366_3)) { singleton(&[]) } else { Space::new() };
            drop(v366_3);
            let v366_5: Space = subtract(&(*CONSTANT_1),&(v366_4));
            drop(v366_4);
            let v366_8: Space = if (v366_5).is_empty() { Space::new() } else {
              let v367_6: Path = concat_path(&(v365_6),&(v365_11_head));
              let v367_7: Space = routine_27(c, &(v367_6), &(*p1), &(v365_11_tail).make_space(), &(*s1));
              compose(&(v366_5),&(v367_7))
            };
            drop(v366_5);
            let v366_9: Space = intersect(&(*CONSTANT_2),&(v366_2));
            drop(v366_2);
            let v366_10: Space = if has_head(&(v366_9)) { singleton(&[]) } else { Space::new() };
            drop(v366_9);
            let v366_12: Space = if (v366_10).is_empty() { Space::new() } else {
              let v368_6: Path = concat_path(&(v365_6),&(v365_11_head));
              let v368_11: Space = routine_10(c, &(v368_6), &(*p1), &(v365_11_tail).make_space(), &(*s1));
              drop(v368_6);
              compose(&(v366_10),&(v368_11))
            };
            drop(v366_10);
            let v366_13: Space = unite(&(v366_8),&(v366_12));
            v365_11.join_into((v366_13).clone());
            }
            v365_11_cursor.ascend(1);
          }
          drop(v365_11_cursor);
          drop(v365_6);
          compose(&(v360_10),&(v365_11))
        };
        drop(v360_10);
        let v360_13: Space = unite(&(v360_8),&(v360_12));
        v359_7.join_into((v360_13).clone());
        }
        v359_7_cursor.ascend(1);
      }
      drop(v359_7_cursor);
      compose(&(v358_5),&(v359_7))
    };
    drop(v358_5);
    let v358_9: Space = intersect(&(*CONSTANT_2),&(v358_2));
    drop(v358_2);
    let v358_10: Space = if has_head(&(v358_9)) { singleton(&[]) } else { Space::new() };
    drop(v358_9);
    let v358_13: Space = if (v358_10).is_empty() { Space::new() } else {
      let v369_6: Path = concat_path(&(*p0),&(v357_25_head));
      let v369_11: Space = unwrap(&(v357_21),&(v357_25_head));
      let mut v369_12 = Space::new();
      let mut v369_12_cursor = (v357_25_tail).read_zipper();
      for v369_12_byte in v369_12_cursor.child_mask().iter() {
        v369_12_cursor.descend_to_byte(v369_12_byte);
        {
        let v369_12_tail = v369_12_cursor.fork_read_zipper();
        let v369_12_head = Path::from_slice(&[v369_12_byte]);
        let v370_2: Space = singleton(&(v369_12_head));
        let v370_3: Space = intersect(&(*CONSTANT_2),&(v370_2));
        let v370_4: Space = if has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
        drop(v370_3);
        let v370_5: Space = subtract(&(*CONSTANT_1),&(v370_4));
        drop(v370_4);
        let v370_8: Space = if (v370_5).is_empty() { Space::new() } else {
          let v371_6: Path = concat_path(&(v369_6),&(v369_12_head));
          let mut v371_7 = Space::new();
          let mut v371_7_cursor = (v369_12_tail).read_zipper();
          for v371_7_byte in v371_7_cursor.child_mask().iter() {
            v371_7_cursor.descend_to_byte(v371_7_byte);
            {
            let v371_7_tail = v371_7_cursor.fork_read_zipper();
            let v371_7_head = Path::from_slice(&[v371_7_byte]);
            let v372_2: Space = singleton(&(v371_7_head));
            let v372_3: Space = intersect(&(*CONSTANT_2),&(v372_2));
            let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
            drop(v372_3);
            let v372_5: Space = subtract(&(*CONSTANT_1),&(v372_4));
            drop(v372_4);
            let v372_8: Space = if (v372_5).is_empty() { Space::new() } else {
              let v373_6: Path = concat_path(&(v371_6),&(v371_7_head));
              let v373_7: Space = routine_27(c, &(v373_6), &(*p1), &(v371_7_tail).make_space(), &(*s1));
              compose(&(v372_5),&(v373_7))
            };
            drop(v372_5);
            let v372_9: Space = intersect(&(*CONSTANT_2),&(v372_2));
            drop(v372_2);
            let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
            drop(v372_9);
            let v372_12: Space = if (v372_10).is_empty() { Space::new() } else {
              let v374_6: Path = concat_path(&(v371_6),&(v371_7_head));
              let v374_11: Space = routine_28(c, &(v374_6), &(*p1), &(v371_7_tail).make_space(), &(*s1));
              drop(v374_6);
              compose(&(v372_10),&(v374_11))
            };
            drop(v372_10);
            let v372_13: Space = unite(&(v372_8),&(v372_12));
            v371_7.join_into((v372_13).clone());
            }
            v371_7_cursor.ascend(1);
          }
          drop(v371_7_cursor);
          compose(&(v370_5),&(v371_7))
        };
        drop(v370_5);
        let v370_9: Space = intersect(&(*CONSTANT_2),&(v370_2));
        drop(v370_2);
        let v370_10: Space = if has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
        drop(v370_9);
        let v370_13: Space = if (v370_10).is_empty() { Space::new() } else {
          let v375_11: Space = unwrap(&(v369_11),&(v369_12_head));
          let v375_12: Space = unwrap(&(v375_11),&(*p1));
          drop(v375_11);
          compose(&(v370_10),&(v375_12))
        };
        drop(v370_10);
        let v376_6: Path = concat_path(&(v369_6),&(v369_12_head));
        let v370_14: Space = wrap(&(v370_13),&(v376_6));
        drop(v370_13);
        let v370_15: Space = wrap(&(v370_14),&(*p1));
        drop(v370_14);
        let v370_16: Space = unite(&(v370_8),&(v370_15));
        drop(v370_15);
        v369_12.join_into((v370_16).clone());
        }
        v369_12_cursor.ascend(1);
      }
      drop(v369_12_cursor);
      drop(v369_6);
      drop(v369_11);
      compose(&(v358_10),&(v369_12))
    };
    drop(v358_10);
    let v358_14: Space = unite(&(v358_8),&(v358_13));
    v357_25.join_into((v358_14).clone());
    }
    v357_25_cursor.ascend(1);
  }
  drop(v357_25_cursor);
  drop(v357_21);
  (v357_25).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v377_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v377_9: Space = unwrap(&(v377_8),&(*p0));
  drop(v377_8);
  let mut v377_19 = Space::new();
  let mut v377_19_cursor = (*s0).read_zipper();
  for v377_19_byte in v377_19_cursor.child_mask().iter() {
    v377_19_cursor.descend_to_byte(v377_19_byte);
    {
    let v377_19_tail = v377_19_cursor.fork_read_zipper();
    let v377_19_head = Path::from_slice(&[v377_19_byte]);
    let v378_2: Space = singleton(&(v377_19_head));
    let v378_3: Space = intersect(&(*CONSTANT_2),&(v378_2));
    let v378_4: Space = if has_head(&(v378_3)) { singleton(&[]) } else { Space::new() };
    drop(v378_3);
    let v378_5: Space = subtract(&(*CONSTANT_1),&(v378_4));
    drop(v378_4);
    let v378_8: Space = if (v378_5).is_empty() { Space::new() } else {
      let v379_6: Path = concat_path(&(*p0),&(v377_19_head));
      let mut v379_7 = Space::new();
      let mut v379_7_cursor = (v377_19_tail).read_zipper();
      for v379_7_byte in v379_7_cursor.child_mask().iter() {
        v379_7_cursor.descend_to_byte(v379_7_byte);
        {
        let v379_7_tail = v379_7_cursor.fork_read_zipper();
        let v379_7_head = Path::from_slice(&[v379_7_byte]);
        let v380_2: Space = singleton(&(v379_7_head));
        let v380_3: Space = intersect(&(*CONSTANT_2),&(v380_2));
        let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
        drop(v380_3);
        let v380_5: Space = subtract(&(*CONSTANT_1),&(v380_4));
        drop(v380_4);
        let v380_8: Space = if (v380_5).is_empty() { Space::new() } else {
          let v381_6: Path = concat_path(&(v379_6),&(v379_7_head));
          let mut v381_7 = Space::new();
          let mut v381_7_cursor = (v379_7_tail).read_zipper();
          for v381_7_byte in v381_7_cursor.child_mask().iter() {
            v381_7_cursor.descend_to_byte(v381_7_byte);
            {
            let v381_7_tail = v381_7_cursor.fork_read_zipper();
            let v381_7_head = Path::from_slice(&[v381_7_byte]);
            let v382_2: Space = singleton(&(v381_7_head));
            let v382_3: Space = intersect(&(*CONSTANT_2),&(v382_2));
            let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
            drop(v382_3);
            let v382_5: Space = subtract(&(*CONSTANT_1),&(v382_4));
            drop(v382_4);
            let v382_8: Space = if (v382_5).is_empty() { Space::new() } else {
              let v383_6: Path = concat_path(&(v381_6),&(v381_7_head));
              let v383_7: Space = routine_27(c, &(v383_6), &(*p1), &(v381_7_tail).make_space(), &(*s1));
              compose(&(v382_5),&(v383_7))
            };
            drop(v382_5);
            let v382_9: Space = intersect(&(*CONSTANT_2),&(v382_2));
            drop(v382_2);
            let v382_10: Space = if has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
            drop(v382_9);
            let v382_12: Space = if (v382_10).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v381_6),&(v381_7_head));
              let v384_11: Space = routine_28(c, &(v384_6), &(*p1), &(v381_7_tail).make_space(), &(*s1));
              drop(v384_6);
              compose(&(v382_10),&(v384_11))
            };
            drop(v382_10);
            let v382_13: Space = unite(&(v382_8),&(v382_12));
            v381_7.join_into((v382_13).clone());
            }
            v381_7_cursor.ascend(1);
          }
          drop(v381_7_cursor);
          compose(&(v380_5),&(v381_7))
        };
        drop(v380_5);
        let v380_9: Space = intersect(&(*CONSTANT_2),&(v380_2));
        drop(v380_2);
        let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
        drop(v380_9);
        let v380_12: Space = if (v380_10).is_empty() { Space::new() } else {
          let v385_6: Path = concat_path(&(v379_6),&(v379_7_head));
          let mut v385_11 = Space::new();
          let mut v385_11_cursor = (v379_7_tail).read_zipper();
          for v385_11_byte in v385_11_cursor.child_mask().iter() {
            v385_11_cursor.descend_to_byte(v385_11_byte);
            {
            let v385_11_tail = v385_11_cursor.fork_read_zipper();
            let v385_11_head = Path::from_slice(&[v385_11_byte]);
            let v386_2: Space = singleton(&(v385_11_head));
            let v386_3: Space = intersect(&(*CONSTANT_2),&(v386_2));
            let v386_4: Space = if has_head(&(v386_3)) { singleton(&[]) } else { Space::new() };
            drop(v386_3);
            let v386_5: Space = subtract(&(*CONSTANT_1),&(v386_4));
            drop(v386_4);
            let v386_8: Space = if (v386_5).is_empty() { Space::new() } else {
              let v387_6: Path = concat_path(&(v385_6),&(v385_11_head));
              let v387_7: Space = routine_27(c, &(v387_6), &(*p1), &(v385_11_tail).make_space(), &(*s1));
              compose(&(v386_5),&(v387_7))
            };
            drop(v386_5);
            let v386_9: Space = intersect(&(*CONSTANT_2),&(v386_2));
            drop(v386_2);
            let v386_10: Space = if has_head(&(v386_9)) { singleton(&[]) } else { Space::new() };
            drop(v386_9);
            let v386_12: Space = if (v386_10).is_empty() { Space::new() } else {
              let v388_6: Path = concat_path(&(v385_6),&(v385_11_head));
              let v388_11: Space = routine_10(c, &(v388_6), &(*p1), &(v385_11_tail).make_space(), &(*s1));
              drop(v388_6);
              compose(&(v386_10),&(v388_11))
            };
            drop(v386_10);
            let v386_13: Space = unite(&(v386_8),&(v386_12));
            v385_11.join_into((v386_13).clone());
            }
            v385_11_cursor.ascend(1);
          }
          drop(v385_11_cursor);
          drop(v385_6);
          compose(&(v380_10),&(v385_11))
        };
        drop(v380_10);
        let v380_13: Space = unite(&(v380_8),&(v380_12));
        v379_7.join_into((v380_13).clone());
        }
        v379_7_cursor.ascend(1);
      }
      drop(v379_7_cursor);
      compose(&(v378_5),&(v379_7))
    };
    drop(v378_5);
    let v378_9: Space = intersect(&(*CONSTANT_2),&(v378_2));
    drop(v378_2);
    let v378_10: Space = if has_head(&(v378_9)) { singleton(&[]) } else { Space::new() };
    drop(v378_9);
    let v378_13: Space = if (v378_10).is_empty() { Space::new() } else {
      let v389_11: Space = unwrap(&(v377_9),&(v377_19_head));
      let v389_12: Space = unwrap(&(v389_11),&(*p1));
      drop(v389_11);
      compose(&(v378_10),&(v389_12))
    };
    drop(v378_10);
    let v390_6: Path = concat_path(&(*p0),&(v377_19_head));
    let v378_14: Space = wrap(&(v378_13),&(v390_6));
    drop(v378_13);
    let v378_15: Space = wrap(&(v378_14),&(*p1));
    drop(v378_14);
    let v378_16: Space = unite(&(v378_8),&(v378_15));
    drop(v378_15);
    v377_19.join_into((v378_16).clone());
    }
    v377_19_cursor.ascend(1);
  }
  drop(v377_19_cursor);
  drop(v377_9);
  (v377_19).clone()
}

fn routine_23(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v391_15: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v391_16: Space = unwrap(&(v391_15),&(*p0));
  drop(v391_15);
  let mut v391_17 = Space::new();
  let mut v391_17_cursor = (*s0).read_zipper();
  for v391_17_byte in v391_17_cursor.child_mask().iter() {
    v391_17_cursor.descend_to_byte(v391_17_byte);
    {
    let v391_17_tail = v391_17_cursor.fork_read_zipper();
    let v391_17_head = Path::from_slice(&[v391_17_byte]);
    let v392_2: Space = singleton(&(v391_17_head));
    let v392_3: Space = intersect(&(*CONSTANT_2),&(v392_2));
    let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
    drop(v392_3);
    let v392_5: Space = subtract(&(*CONSTANT_1),&(v392_4));
    drop(v392_4);
    let v392_8: Space = if (v392_5).is_empty() { Space::new() } else {
      let v393_6: Path = concat_path(&(*p0),&(v391_17_head));
      let mut v393_7 = Space::new();
      let mut v393_7_cursor = (v391_17_tail).read_zipper();
      for v393_7_byte in v393_7_cursor.child_mask().iter() {
        v393_7_cursor.descend_to_byte(v393_7_byte);
        {
        let v393_7_tail = v393_7_cursor.fork_read_zipper();
        let v393_7_head = Path::from_slice(&[v393_7_byte]);
        let v394_2: Space = singleton(&(v393_7_head));
        let v394_3: Space = intersect(&(*CONSTANT_2),&(v394_2));
        let v394_4: Space = if has_head(&(v394_3)) { singleton(&[]) } else { Space::new() };
        drop(v394_3);
        let v394_5: Space = subtract(&(*CONSTANT_1),&(v394_4));
        drop(v394_4);
        let mut v394_6 = Space::new();
        let mut v394_6_cursor = (v393_7_tail).read_zipper();
        for v394_6_byte in v394_6_cursor.child_mask().iter() {
          v394_6_cursor.descend_to_byte(v394_6_byte);
          {
          let v394_6_tail = v394_6_cursor.fork_read_zipper();
          let v394_6_head = Path::from_slice(&[v394_6_byte]);
          let v395_2: Space = Space::new();
          v394_6.join_into((v395_2).clone());
          }
          v394_6_cursor.ascend(1);
        }
        drop(v394_6_cursor);
        let v394_7: Space = compose(&(v394_5),&(v394_6));
        drop(v394_5);
        drop(v394_6);
        let v394_8: Space = intersect(&(*CONSTANT_2),&(v394_2));
        drop(v394_2);
        let v394_9: Space = if has_head(&(v394_8)) { singleton(&[]) } else { Space::new() };
        drop(v394_8);
        let v394_12: Space = if (v394_9).is_empty() { Space::new() } else {
          let v396_10: Path = concat_path(&(v393_6),&(v393_7_head));
          let mut v396_11 = Space::new();
          let mut v396_11_cursor = (v393_7_tail).read_zipper();
          for v396_11_byte in v396_11_cursor.child_mask().iter() {
            v396_11_cursor.descend_to_byte(v396_11_byte);
            {
            let v396_11_tail = v396_11_cursor.fork_read_zipper();
            let v396_11_head = Path::from_slice(&[v396_11_byte]);
            let v397_2: Space = singleton(&(v396_11_head));
            let v397_3: Space = intersect(&(*CONSTANT_2),&(v397_2));
            drop(v397_2);
            let v397_4: Space = if has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
            drop(v397_3);
            let v397_7: Space = if (v397_4).is_empty() { Space::new() } else {
              let v398_5: Path = concat_path(&(v396_10),&(v396_11_head));
              let v398_6: Space = routine_10(c, &(v398_5), &(*p1), &(v396_11_tail).make_space(), &(*s1));
              drop(v398_5);
              compose(&(v397_4),&(v398_6))
            };
            drop(v397_4);
            v396_11.join_into((v397_7).clone());
            }
            v396_11_cursor.ascend(1);
          }
          drop(v396_11_cursor);
          drop(v396_10);
          compose(&(v394_9),&(v396_11))
        };
        drop(v394_9);
        let v394_13: Space = unite(&(v394_7),&(v394_12));
        drop(v394_7);
        v393_7.join_into((v394_13).clone());
        }
        v393_7_cursor.ascend(1);
      }
      drop(v393_7_cursor);
      compose(&(v392_5),&(v393_7))
    };
    drop(v392_5);
    let v392_9: Space = intersect(&(*CONSTANT_2),&(v392_2));
    drop(v392_2);
    let v392_10: Space = if has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
    drop(v392_9);
    let v392_13: Space = if (v392_10).is_empty() { Space::new() } else {
      let v399_6: Path = concat_path(&(*p0),&(v391_17_head));
      let v399_11: Space = unwrap(&(v391_16),&(v391_17_head));
      let mut v399_12 = Space::new();
      let mut v399_12_cursor = (v391_17_tail).read_zipper();
      for v399_12_byte in v399_12_cursor.child_mask().iter() {
        v399_12_cursor.descend_to_byte(v399_12_byte);
        {
        let v399_12_tail = v399_12_cursor.fork_read_zipper();
        let v399_12_head = Path::from_slice(&[v399_12_byte]);
        let v400_2: Space = singleton(&(v399_12_head));
        let v400_3: Space = intersect(&(*CONSTANT_2),&(v400_2));
        let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
        drop(v400_3);
        let v400_5: Space = subtract(&(*CONSTANT_1),&(v400_4));
        drop(v400_4);
        let mut v400_6 = Space::new();
        let mut v400_6_cursor = (v399_12_tail).read_zipper();
        for v400_6_byte in v400_6_cursor.child_mask().iter() {
          v400_6_cursor.descend_to_byte(v400_6_byte);
          {
          let v400_6_tail = v400_6_cursor.fork_read_zipper();
          let v400_6_head = Path::from_slice(&[v400_6_byte]);
          let v401_2: Space = Space::new();
          v400_6.join_into((v401_2).clone());
          }
          v400_6_cursor.ascend(1);
        }
        drop(v400_6_cursor);
        let v400_7: Space = compose(&(v400_5),&(v400_6));
        drop(v400_5);
        drop(v400_6);
        let v400_8: Space = intersect(&(*CONSTANT_2),&(v400_2));
        drop(v400_2);
        let v400_9: Space = if has_head(&(v400_8)) { singleton(&[]) } else { Space::new() };
        drop(v400_8);
        let v400_12: Space = if (v400_9).is_empty() { Space::new() } else {
          let v402_10: Space = unwrap(&(v399_11),&(v399_12_head));
          let v402_11: Space = unwrap(&(v402_10),&(*p1));
          drop(v402_10);
          compose(&(v400_9),&(v402_11))
        };
        drop(v400_9);
        let v400_13: Path = concat_path(&(v399_6),&(v399_12_head));
        let v400_14: Space = wrap(&(v400_12),&(v400_13));
        drop(v400_12);
        drop(v400_13);
        let v400_15: Space = wrap(&(v400_14),&(*p1));
        drop(v400_14);
        let v400_16: Space = unite(&(v400_7),&(v400_15));
        drop(v400_7);
        drop(v400_15);
        v399_12.join_into((v400_16).clone());
        }
        v399_12_cursor.ascend(1);
      }
      drop(v399_12_cursor);
      drop(v399_6);
      drop(v399_11);
      compose(&(v392_10),&(v399_12))
    };
    drop(v392_10);
    let v392_14: Space = unite(&(v392_8),&(v392_13));
    drop(v392_13);
    v391_17.join_into((v392_14).clone());
    }
    v391_17_cursor.ascend(1);
  }
  drop(v391_17_cursor);
  drop(v391_16);
  (v391_17).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v403_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v403_9: Space = unwrap(&(v403_8),&(*p0));
  drop(v403_8);
  let mut v403_14 = Space::new();
  let mut v403_14_cursor = (*s0).read_zipper();
  for v403_14_byte in v403_14_cursor.child_mask().iter() {
    v403_14_cursor.descend_to_byte(v403_14_byte);
    {
    let v403_14_tail = v403_14_cursor.fork_read_zipper();
    let v403_14_head = Path::from_slice(&[v403_14_byte]);
    let v404_2: Space = singleton(&(v403_14_head));
    let v404_3: Space = intersect(&(*CONSTANT_2),&(v404_2));
    let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
    drop(v404_3);
    let v404_5: Space = subtract(&(*CONSTANT_1),&(v404_4));
    drop(v404_4);
    let v404_8: Space = if (v404_5).is_empty() { Space::new() } else {
      let v405_6: Path = concat_path(&(*p0),&(v403_14_head));
      let mut v405_7 = Space::new();
      let mut v405_7_cursor = (v403_14_tail).read_zipper();
      for v405_7_byte in v405_7_cursor.child_mask().iter() {
        v405_7_cursor.descend_to_byte(v405_7_byte);
        {
        let v405_7_tail = v405_7_cursor.fork_read_zipper();
        let v405_7_head = Path::from_slice(&[v405_7_byte]);
        let v406_2: Space = singleton(&(v405_7_head));
        let v406_3: Space = intersect(&(*CONSTANT_2),&(v406_2));
        let v406_4: Space = if has_head(&(v406_3)) { singleton(&[]) } else { Space::new() };
        drop(v406_3);
        let v406_5: Space = subtract(&(*CONSTANT_1),&(v406_4));
        drop(v406_4);
        let mut v406_6 = Space::new();
        let mut v406_6_cursor = (v405_7_tail).read_zipper();
        for v406_6_byte in v406_6_cursor.child_mask().iter() {
          v406_6_cursor.descend_to_byte(v406_6_byte);
          {
          let v406_6_tail = v406_6_cursor.fork_read_zipper();
          let v406_6_head = Path::from_slice(&[v406_6_byte]);
          let v407_2: Space = Space::new();
          v406_6.join_into((v407_2).clone());
          }
          v406_6_cursor.ascend(1);
        }
        drop(v406_6_cursor);
        let v406_7: Space = compose(&(v406_5),&(v406_6));
        drop(v406_5);
        drop(v406_6);
        let v406_8: Space = intersect(&(*CONSTANT_2),&(v406_2));
        drop(v406_2);
        let v406_9: Space = if has_head(&(v406_8)) { singleton(&[]) } else { Space::new() };
        drop(v406_8);
        let v406_12: Space = if (v406_9).is_empty() { Space::new() } else {
          let v408_10: Path = concat_path(&(v405_6),&(v405_7_head));
          let mut v408_11 = Space::new();
          let mut v408_11_cursor = (v405_7_tail).read_zipper();
          for v408_11_byte in v408_11_cursor.child_mask().iter() {
            v408_11_cursor.descend_to_byte(v408_11_byte);
            {
            let v408_11_tail = v408_11_cursor.fork_read_zipper();
            let v408_11_head = Path::from_slice(&[v408_11_byte]);
            let v409_2: Space = singleton(&(v408_11_head));
            let v409_3: Space = intersect(&(*CONSTANT_2),&(v409_2));
            drop(v409_2);
            let v409_4: Space = if has_head(&(v409_3)) { singleton(&[]) } else { Space::new() };
            drop(v409_3);
            let v409_7: Space = if (v409_4).is_empty() { Space::new() } else {
              let v410_5: Path = concat_path(&(v408_10),&(v408_11_head));
              let v410_6: Space = routine_10(c, &(v410_5), &(*p1), &(v408_11_tail).make_space(), &(*s1));
              drop(v410_5);
              compose(&(v409_4),&(v410_6))
            };
            drop(v409_4);
            v408_11.join_into((v409_7).clone());
            }
            v408_11_cursor.ascend(1);
          }
          drop(v408_11_cursor);
          drop(v408_10);
          compose(&(v406_9),&(v408_11))
        };
        drop(v406_9);
        let v406_13: Space = unite(&(v406_7),&(v406_12));
        drop(v406_7);
        v405_7.join_into((v406_13).clone());
        }
        v405_7_cursor.ascend(1);
      }
      drop(v405_7_cursor);
      compose(&(v404_5),&(v405_7))
    };
    drop(v404_5);
    let v404_9: Space = intersect(&(*CONSTANT_2),&(v404_2));
    drop(v404_2);
    let v404_10: Space = if has_head(&(v404_9)) { singleton(&[]) } else { Space::new() };
    drop(v404_9);
    let v404_13: Space = if (v404_10).is_empty() { Space::new() } else {
      let v411_11: Space = unwrap(&(v403_9),&(v403_14_head));
      let v411_12: Space = unwrap(&(v411_11),&(*p1));
      drop(v411_11);
      compose(&(v404_10),&(v411_12))
    };
    drop(v404_10);
    let v412_6: Path = concat_path(&(*p0),&(v403_14_head));
    let v404_14: Space = wrap(&(v404_13),&(v412_6));
    drop(v404_13);
    let v404_15: Space = wrap(&(v404_14),&(*p1));
    drop(v404_14);
    let v404_16: Space = unite(&(v404_8),&(v404_15));
    drop(v404_15);
    v403_14.join_into((v404_16).clone());
    }
    v403_14_cursor.ascend(1);
  }
  drop(v403_14_cursor);
  drop(v403_9);
  (v403_14).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v413_9: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v413_10: Space = unwrap(&(v413_9),&(*p0));
  drop(v413_9);
  let mut v413_11 = Space::new();
  let mut v413_11_cursor = (*s0).read_zipper();
  for v413_11_byte in v413_11_cursor.child_mask().iter() {
    v413_11_cursor.descend_to_byte(v413_11_byte);
    {
    let v413_11_tail = v413_11_cursor.fork_read_zipper();
    let v413_11_head = Path::from_slice(&[v413_11_byte]);
    let v414_2: Space = singleton(&(v413_11_head));
    let v414_3: Space = intersect(&(*CONSTANT_2),&(v414_2));
    let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
    drop(v414_3);
    let v414_5: Space = subtract(&(*CONSTANT_1),&(v414_4));
    drop(v414_4);
    let mut v414_6 = Space::new();
    let mut v414_6_cursor = (v413_11_tail).read_zipper();
    for v414_6_byte in v414_6_cursor.child_mask().iter() {
      v414_6_cursor.descend_to_byte(v414_6_byte);
      {
      let v414_6_tail = v414_6_cursor.fork_read_zipper();
      let v414_6_head = Path::from_slice(&[v414_6_byte]);
      let v415_2: Space = Space::new();
      v414_6.join_into((v415_2).clone());
      }
      v414_6_cursor.ascend(1);
    }
    drop(v414_6_cursor);
    let v414_7: Space = compose(&(v414_5),&(v414_6));
    drop(v414_5);
    drop(v414_6);
    let v414_8: Space = intersect(&(*CONSTANT_2),&(v414_2));
    drop(v414_2);
    let v414_9: Space = if has_head(&(v414_8)) { singleton(&[]) } else { Space::new() };
    drop(v414_8);
    let v414_13: Space = if (v414_9).is_empty() { Space::new() } else {
      let v416_10: Space = unwrap(&(v413_10),&(v413_11_head));
      let v416_11: Path = concat_path(&(*p0),&(v413_11_head));
      let mut v416_12 = Space::new();
      let mut v416_12_cursor = (v413_11_tail).read_zipper();
      for v416_12_byte in v416_12_cursor.child_mask().iter() {
        v416_12_cursor.descend_to_byte(v416_12_byte);
        {
        let v416_12_tail = v416_12_cursor.fork_read_zipper();
        let v416_12_head = Path::from_slice(&[v416_12_byte]);
        let v417_2: Space = singleton(&(v416_12_head));
        let v417_3: Space = intersect(&(*CONSTANT_2),&(v417_2));
        drop(v417_2);
        let v417_4: Space = if has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
        drop(v417_3);
        let v417_7: Space = if (v417_4).is_empty() { Space::new() } else {
          let v418_5: Space = unwrap(&(v416_10),&(v416_12_head));
          let v418_6: Space = unwrap(&(v418_5),&(*p1));
          drop(v418_5);
          compose(&(v417_4),&(v418_6))
        };
        drop(v417_4);
        let v417_8: Path = concat_path(&(v416_11),&(v416_12_head));
        let v417_9: Space = wrap(&(v417_7),&(v417_8));
        drop(v417_7);
        drop(v417_8);
        v416_12.join_into((v417_9).clone());
        }
        v416_12_cursor.ascend(1);
      }
      drop(v416_12_cursor);
      drop(v416_10);
      drop(v416_11);
      compose(&(v414_9),&(v416_12))
    };
    drop(v414_9);
    let v414_14: Space = wrap(&(v414_13),&(*p1));
    drop(v414_13);
    let v414_15: Space = unite(&(v414_7),&(v414_14));
    drop(v414_7);
    drop(v414_14);
    v413_11.join_into((v414_15).clone());
    }
    v413_11_cursor.ascend(1);
  }
  drop(v413_11_cursor);
  drop(v413_10);
  (v413_11).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v419_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v419_9: Space = unwrap(&(v419_8),&(*p0));
  drop(v419_8);
  let mut v419_10 = Space::new();
  let mut v419_10_cursor = (*s0).read_zipper();
  for v419_10_byte in v419_10_cursor.child_mask().iter() {
    v419_10_cursor.descend_to_byte(v419_10_byte);
    {
    let v419_10_tail = v419_10_cursor.fork_read_zipper();
    let v419_10_head = Path::from_slice(&[v419_10_byte]);
    let v420_2: Space = singleton(&(v419_10_head));
    let v420_3: Space = intersect(&(*CONSTANT_2),&(v420_2));
    let v420_4: Space = if has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
    drop(v420_3);
    let v420_5: Space = subtract(&(*CONSTANT_1),&(v420_4));
    drop(v420_4);
    let mut v420_6 = Space::new();
    let mut v420_6_cursor = (v419_10_tail).read_zipper();
    for v420_6_byte in v420_6_cursor.child_mask().iter() {
      v420_6_cursor.descend_to_byte(v420_6_byte);
      {
      let v420_6_tail = v420_6_cursor.fork_read_zipper();
      let v420_6_head = Path::from_slice(&[v420_6_byte]);
      let v421_2: Space = Space::new();
      v420_6.join_into((v421_2).clone());
      }
      v420_6_cursor.ascend(1);
    }
    drop(v420_6_cursor);
    let v420_7: Space = compose(&(v420_5),&(v420_6));
    drop(v420_5);
    drop(v420_6);
    let v420_8: Space = intersect(&(*CONSTANT_2),&(v420_2));
    drop(v420_2);
    let v420_9: Space = if has_head(&(v420_8)) { singleton(&[]) } else { Space::new() };
    drop(v420_8);
    let v420_12: Space = if (v420_9).is_empty() { Space::new() } else {
      let v422_10: Space = unwrap(&(v419_9),&(v419_10_head));
      let v422_11: Space = unwrap(&(v422_10),&(*p1));
      drop(v422_10);
      compose(&(v420_9),&(v422_11))
    };
    drop(v420_9);
    let v420_13: Path = concat_path(&(*p0),&(v419_10_head));
    let v420_14: Space = wrap(&(v420_12),&(v420_13));
    drop(v420_12);
    drop(v420_13);
    let v420_15: Space = wrap(&(v420_14),&(*p1));
    drop(v420_14);
    let v420_16: Space = unite(&(v420_7),&(v420_15));
    drop(v420_7);
    drop(v420_15);
    v419_10.join_into((v420_16).clone());
    }
    v419_10_cursor.ascend(1);
  }
  drop(v419_10_cursor);
  drop(v419_9);
  (v419_10).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v423_4 = Space::new();
  let mut v423_4_cursor = (*s0).read_zipper();
  for v423_4_byte in v423_4_cursor.child_mask().iter() {
    v423_4_cursor.descend_to_byte(v423_4_byte);
    {
    let v423_4_tail = v423_4_cursor.fork_read_zipper();
    let v423_4_head = Path::from_slice(&[v423_4_byte]);
    let v424_2: Space = Space::new();
    v423_4.join_into((v424_2).clone());
    }
    v423_4_cursor.ascend(1);
  }
  drop(v423_4_cursor);
  (v423_4).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v425_6: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v425_7: Space = unwrap(&(v425_6),&(*p0));
  drop(v425_6);
  let mut v425_8 = Space::new();
  let mut v425_8_cursor = (*s0).read_zipper();
  for v425_8_byte in v425_8_cursor.child_mask().iter() {
    v425_8_cursor.descend_to_byte(v425_8_byte);
    {
    let v425_8_tail = v425_8_cursor.fork_read_zipper();
    let v425_8_head = Path::from_slice(&[v425_8_byte]);
    let v426_2: Space = singleton(&(v425_8_head));
    let v426_3: Space = intersect(&(*CONSTANT_2),&(v426_2));
    drop(v426_2);
    let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
    drop(v426_3);
    let v426_7: Space = if (v426_4).is_empty() { Space::new() } else {
      let v427_5: Space = unwrap(&(v425_7),&(v425_8_head));
      let v427_6: Space = unwrap(&(v427_5),&(*p1));
      drop(v427_5);
      compose(&(v426_4),&(v427_6))
    };
    drop(v426_4);
    let v426_8: Path = concat_path(&(*p0),&(v425_8_head));
    let v426_9: Space = wrap(&(v426_7),&(v426_8));
    drop(v426_7);
    drop(v426_8);
    v425_8.join_into((v426_9).clone());
    }
    v425_8_cursor.ascend(1);
  }
  drop(v425_8_cursor);
  drop(v425_7);
  let v425_9: Space = wrap(&(v425_8),&(*p1));
  drop(v425_8);
  (v425_9).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
