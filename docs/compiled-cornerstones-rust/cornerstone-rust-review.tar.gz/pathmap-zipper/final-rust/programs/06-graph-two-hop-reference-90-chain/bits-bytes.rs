#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1,0,0,0,0,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_24 = Space::new();
  let mut v0_24_cursor = (v0_2).read_zipper();
  for v0_24_byte in v0_24_cursor.child_mask().iter() {
    v0_24_cursor.descend_to_byte(v0_24_byte);
    {
    let v0_24_tail = v0_24_cursor.fork_read_zipper();
    let v0_24_head = Path::from_slice(&[v0_24_byte]);
    let v1_2: Space = singleton(&(v0_24_head));
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_24_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_24_head),&(v2_6_head));
          let mut v4_7 = Space::new();
          let mut v4_7_cursor = (v2_6_tail).read_zipper();
          for v4_7_byte in v4_7_cursor.child_mask().iter() {
            v4_7_cursor.descend_to_byte(v4_7_byte);
            {
            let v4_7_tail = v4_7_cursor.fork_read_zipper();
            let v4_7_head = Path::from_slice(&[v4_7_byte]);
            let v5_2: Space = singleton(&(v4_7_head));
            let v5_3: Space = intersect(&(*CONSTANT_2),&(v5_2));
            let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
            drop(v5_3);
            let v5_5: Space = subtract(&(*CONSTANT_1),&(v5_4));
            drop(v5_4);
            let v5_8: Space = if (v5_5).is_empty() { Space::new() } else {
              let v6_6: Path = concat_path(&(v4_6),&(v4_7_head));
              let v6_7: Space = routine_1(c, &(v6_6), &(v4_7_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v5_5),&(v6_7))
            };
            drop(v5_5);
            let v5_9: Space = intersect(&(*CONSTANT_2),&(v5_2));
            drop(v5_2);
            let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
            drop(v5_9);
            let v5_12: Space = if (v5_10).is_empty() { Space::new() } else {
              let v7_6: Path = concat_path(&(v4_6),&(v4_7_head));
              let v7_11: Space = routine_2(c, &(v7_6), &(v4_7_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v7_6);
              compose(&(v5_10),&(v7_11))
            };
            drop(v5_10);
            let v5_13: Space = unite(&(v5_8),&(v5_12));
            v4_7.join_into((v5_13).clone());
            }
            v4_7_cursor.ascend(1);
          }
          drop(v4_7_cursor);
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_24_head),&(v2_6_head));
          let mut v8_11 = Space::new();
          let mut v8_11_cursor = (v2_6_tail).read_zipper();
          for v8_11_byte in v8_11_cursor.child_mask().iter() {
            v8_11_cursor.descend_to_byte(v8_11_byte);
            {
            let v8_11_tail = v8_11_cursor.fork_read_zipper();
            let v8_11_head = Path::from_slice(&[v8_11_byte]);
            let v9_2: Space = singleton(&(v8_11_head));
            let v9_3: Space = intersect(&(*CONSTANT_2),&(v9_2));
            let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
            drop(v9_3);
            let v9_5: Space = subtract(&(*CONSTANT_1),&(v9_4));
            drop(v9_4);
            let v9_8: Space = if (v9_5).is_empty() { Space::new() } else {
              let v10_6: Path = concat_path(&(v8_6),&(v8_11_head));
              let v10_7: Space = routine_1(c, &(v10_6), &(v8_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v9_5),&(v10_7))
            };
            drop(v9_5);
            let v9_9: Space = intersect(&(*CONSTANT_2),&(v9_2));
            drop(v9_2);
            let v9_10: Space = if has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
            drop(v9_9);
            let v9_12: Space = if (v9_10).is_empty() { Space::new() } else {
              let v11_6: Path = concat_path(&(v8_6),&(v8_11_head));
              let v11_11: Space = routine_3(c, &(v11_6), &(v8_11_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v11_6);
              compose(&(v9_10),&(v11_11))
            };
            drop(v9_10);
            let v9_13: Space = unite(&(v9_8),&(v9_12));
            v8_11.join_into((v9_13).clone());
            }
            v8_11_cursor.ascend(1);
          }
          drop(v8_11_cursor);
          drop(v8_6);
          compose(&(v3_10),&(v8_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v12_10 = Space::new();
      let mut v12_10_cursor = (v0_24_tail).read_zipper();
      for v12_10_byte in v12_10_cursor.child_mask().iter() {
        v12_10_cursor.descend_to_byte(v12_10_byte);
        {
        let v12_10_tail = v12_10_cursor.fork_read_zipper();
        let v12_10_head = Path::from_slice(&[v12_10_byte]);
        let v13_2: Space = singleton(&(v12_10_head));
        let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v0_24_head),&(v12_10_head));
          let mut v14_7 = Space::new();
          let mut v14_7_cursor = (v12_10_tail).read_zipper();
          for v14_7_byte in v14_7_cursor.child_mask().iter() {
            v14_7_cursor.descend_to_byte(v14_7_byte);
            {
            let v14_7_tail = v14_7_cursor.fork_read_zipper();
            let v14_7_head = Path::from_slice(&[v14_7_byte]);
            let v15_2: Space = singleton(&(v14_7_head));
            let v15_3: Space = intersect(&(*CONSTANT_2),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_1),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v16_7: Space = routine_1(c, &(v16_6), &(v14_7_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_2),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v17_11: Space = routine_2(c, &(v17_6), &(v14_7_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            v14_7.join_into((v15_13).clone());
            }
            v14_7_cursor.ascend(1);
          }
          drop(v14_7_cursor);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v0_24_head),&(v12_10_head));
          let mut v18_11 = Space::new();
          let mut v18_11_cursor = (v12_10_tail).read_zipper();
          for v18_11_byte in v18_11_cursor.child_mask().iter() {
            v18_11_cursor.descend_to_byte(v18_11_byte);
            {
            let v18_11_tail = v18_11_cursor.fork_read_zipper();
            let v18_11_head = Path::from_slice(&[v18_11_byte]);
            let v19_2: Space = singleton(&(v18_11_head));
            let v19_3: Space = intersect(&(*CONSTANT_2),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_1),&(v19_4));
            drop(v19_4);
            let v19_7: Space = if (v19_5).is_empty() { Space::new() } else {
              let v20_6: Space = routine_4(c, &(v18_11_head), &(v18_6), &(v18_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v19_5),&(v20_6))
            };
            drop(v19_5);
            let v19_8: Space = intersect(&(*CONSTANT_2),&(v19_2));
            drop(v19_2);
            let v19_9: Space = if has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
            drop(v19_8);
            let v19_11: Space = if (v19_9).is_empty() { Space::new() } else {
              let v21_10: Space = routine_5(c, &(v18_11_head), &(v18_6), &(v18_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v19_9),&(v21_10))
            };
            drop(v19_9);
            let v19_12: Space = unite(&(v19_7),&(v19_11));
            v18_11.join_into((v19_12).clone());
            }
            v18_11_cursor.ascend(1);
          }
          drop(v18_11_cursor);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_10.join_into((v13_13).clone());
        }
        v12_10_cursor.ascend(1);
      }
      drop(v12_10_cursor);
      compose(&(v1_9),&(v12_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_24.join_into((v1_12).clone());
    }
    v0_24_cursor.ascend(1);
  }
  drop(v0_24_cursor);
  drop(v0_2);
  let v0_26: Space = wrap(&(v0_24),&(*CONSTANT_3));
  (v0_26).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v22_24 = Space::new();
  let mut v22_24_cursor = (*s0).read_zipper();
  for v22_24_byte in v22_24_cursor.child_mask().iter() {
    v22_24_cursor.descend_to_byte(v22_24_byte);
    {
    let v22_24_tail = v22_24_cursor.fork_read_zipper();
    let v22_24_head = Path::from_slice(&[v22_24_byte]);
    let v23_2: Space = singleton(&(v22_24_head));
    let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
    let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
    drop(v23_3);
    let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
    drop(v23_4);
    let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
      let v24_6: Path = concat_path(&(*p0),&(v22_24_head));
      let mut v24_7 = Space::new();
      let mut v24_7_cursor = (v22_24_tail).read_zipper();
      for v24_7_byte in v24_7_cursor.child_mask().iter() {
        v24_7_cursor.descend_to_byte(v24_7_byte);
        {
        let v24_7_tail = v24_7_cursor.fork_read_zipper();
        let v24_7_head = Path::from_slice(&[v24_7_byte]);
        let v25_2: Space = singleton(&(v24_7_head));
        let v25_3: Space = intersect(&(*CONSTANT_2),&(v25_2));
        let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
        drop(v25_3);
        let v25_5: Space = subtract(&(*CONSTANT_1),&(v25_4));
        drop(v25_4);
        let v25_8: Space = if (v25_5).is_empty() { Space::new() } else {
          let v26_6: Path = concat_path(&(v24_6),&(v24_7_head));
          let mut v26_7 = Space::new();
          let mut v26_7_cursor = (v24_7_tail).read_zipper();
          for v26_7_byte in v26_7_cursor.child_mask().iter() {
            v26_7_cursor.descend_to_byte(v26_7_byte);
            {
            let v26_7_tail = v26_7_cursor.fork_read_zipper();
            let v26_7_head = Path::from_slice(&[v26_7_byte]);
            let v27_2: Space = singleton(&(v26_7_head));
            let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
            let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
            drop(v27_3);
            let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
            drop(v27_4);
            let v27_8: Space = if (v27_5).is_empty() { Space::new() } else {
              let v28_6: Path = concat_path(&(v26_6),&(v26_7_head));
              let v28_7: Space = routine_6(c, &(v28_6), &(v26_7_tail).make_space(), &(*s1));
              compose(&(v27_5),&(v28_7))
            };
            drop(v27_5);
            let v27_9: Space = intersect(&(*CONSTANT_2),&(v27_2));
            drop(v27_2);
            let v27_10: Space = if has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
            drop(v27_9);
            let v27_12: Space = if (v27_10).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v26_6),&(v26_7_head));
              let v29_11: Space = routine_7(c, &(v29_6), &(v26_7_tail).make_space(), &(*s1));
              drop(v29_6);
              compose(&(v27_10),&(v29_11))
            };
            drop(v27_10);
            let v27_13: Space = unite(&(v27_8),&(v27_12));
            v26_7.join_into((v27_13).clone());
            }
            v26_7_cursor.ascend(1);
          }
          drop(v26_7_cursor);
          compose(&(v25_5),&(v26_7))
        };
        drop(v25_5);
        let v25_9: Space = intersect(&(*CONSTANT_2),&(v25_2));
        drop(v25_2);
        let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
        drop(v25_9);
        let v25_12: Space = if (v25_10).is_empty() { Space::new() } else {
          let v30_6: Path = concat_path(&(v24_6),&(v24_7_head));
          let mut v30_11 = Space::new();
          let mut v30_11_cursor = (v24_7_tail).read_zipper();
          for v30_11_byte in v30_11_cursor.child_mask().iter() {
            v30_11_cursor.descend_to_byte(v30_11_byte);
            {
            let v30_11_tail = v30_11_cursor.fork_read_zipper();
            let v30_11_head = Path::from_slice(&[v30_11_byte]);
            let v31_2: Space = singleton(&(v30_11_head));
            let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
            let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
            drop(v31_3);
            let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
            drop(v31_4);
            let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
              let v32_6: Path = concat_path(&(v30_6),&(v30_11_head));
              let v32_7: Space = routine_6(c, &(v32_6), &(v30_11_tail).make_space(), &(*s1));
              compose(&(v31_5),&(v32_7))
            };
            drop(v31_5);
            let v31_9: Space = intersect(&(*CONSTANT_2),&(v31_2));
            drop(v31_2);
            let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
            drop(v31_9);
            let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v30_6),&(v30_11_head));
              let v33_11: Space = routine_3(c, &(v33_6), &(v30_11_tail).make_space(), &(*s1));
              drop(v33_6);
              compose(&(v31_10),&(v33_11))
            };
            drop(v31_10);
            let v31_13: Space = unite(&(v31_8),&(v31_12));
            v30_11.join_into((v31_13).clone());
            }
            v30_11_cursor.ascend(1);
          }
          drop(v30_11_cursor);
          drop(v30_6);
          compose(&(v25_10),&(v30_11))
        };
        drop(v25_10);
        let v25_13: Space = unite(&(v25_8),&(v25_12));
        v24_7.join_into((v25_13).clone());
        }
        v24_7_cursor.ascend(1);
      }
      drop(v24_7_cursor);
      compose(&(v23_5),&(v24_7))
    };
    drop(v23_5);
    let v23_9: Space = intersect(&(*CONSTANT_2),&(v23_2));
    drop(v23_2);
    let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
    drop(v23_9);
    let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&(v22_24_head));
      let mut v34_11 = Space::new();
      let mut v34_11_cursor = (v22_24_tail).read_zipper();
      for v34_11_byte in v34_11_cursor.child_mask().iter() {
        v34_11_cursor.descend_to_byte(v34_11_byte);
        {
        let v34_11_tail = v34_11_cursor.fork_read_zipper();
        let v34_11_head = Path::from_slice(&[v34_11_byte]);
        let v35_2: Space = singleton(&(v34_11_head));
        let v35_3: Space = intersect(&(*CONSTANT_2),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_1),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let mut v36_7 = Space::new();
          let mut v36_7_cursor = (v34_11_tail).read_zipper();
          for v36_7_byte in v36_7_cursor.child_mask().iter() {
            v36_7_cursor.descend_to_byte(v36_7_byte);
            {
            let v36_7_tail = v36_7_cursor.fork_read_zipper();
            let v36_7_head = Path::from_slice(&[v36_7_byte]);
            let v37_2: Space = singleton(&(v36_7_head));
            let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
            let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
            drop(v37_3);
            let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
            drop(v37_4);
            let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
              let v38_6: Path = concat_path(&(v36_6),&(v36_7_head));
              let v38_7: Space = routine_6(c, &(v38_6), &(v36_7_tail).make_space(), &(*s1));
              compose(&(v37_5),&(v38_7))
            };
            drop(v37_5);
            let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
            drop(v37_2);
            let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
            drop(v37_9);
            let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v36_6),&(v36_7_head));
              let v39_11: Space = routine_7(c, &(v39_6), &(v36_7_tail).make_space(), &(*s1));
              drop(v39_6);
              compose(&(v37_10),&(v39_11))
            };
            drop(v37_10);
            let v37_13: Space = unite(&(v37_8),&(v37_12));
            v36_7.join_into((v37_13).clone());
            }
            v36_7_cursor.ascend(1);
          }
          drop(v36_7_cursor);
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_2),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let mut v40_11 = Space::new();
          let mut v40_11_cursor = (v34_11_tail).read_zipper();
          for v40_11_byte in v40_11_cursor.child_mask().iter() {
            v40_11_cursor.descend_to_byte(v40_11_byte);
            {
            let v40_11_tail = v40_11_cursor.fork_read_zipper();
            let v40_11_head = Path::from_slice(&[v40_11_byte]);
            let v41_2: Space = singleton(&(v40_11_head));
            let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
            drop(v41_4);
            let v41_7: Space = if (v41_5).is_empty() { Space::new() } else {
              let v42_6: Space = routine_4(c, &(v40_11_head), &(v40_6), &(v40_11_tail).make_space(), &(*s1));
              compose(&(v41_5),&(v42_6))
            };
            drop(v41_5);
            let v41_8: Space = intersect(&(*CONSTANT_2),&(v41_2));
            drop(v41_2);
            let v41_9: Space = if has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
            drop(v41_8);
            let v41_11: Space = if (v41_9).is_empty() { Space::new() } else {
              let v43_10: Space = routine_5(c, &(v40_11_head), &(v40_6), &(v40_11_tail).make_space(), &(*s1));
              compose(&(v41_9),&(v43_10))
            };
            drop(v41_9);
            let v41_12: Space = unite(&(v41_7),&(v41_11));
            v40_11.join_into((v41_12).clone());
            }
            v40_11_cursor.ascend(1);
          }
          drop(v40_11_cursor);
          drop(v40_6);
          compose(&(v35_10),&(v40_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        v34_11.join_into((v35_13).clone());
        }
        v34_11_cursor.ascend(1);
      }
      drop(v34_11_cursor);
      drop(v34_6);
      compose(&(v23_10),&(v34_11))
    };
    drop(v23_10);
    let v23_13: Space = unite(&(v23_8),&(v23_12));
    v22_24.join_into((v23_13).clone());
    }
    v22_24_cursor.ascend(1);
  }
  drop(v22_24_cursor);
  (v22_24).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v44_24 = Space::new();
  let mut v44_24_cursor = (*s0).read_zipper();
  for v44_24_byte in v44_24_cursor.child_mask().iter() {
    v44_24_cursor.descend_to_byte(v44_24_byte);
    {
    let v44_24_tail = v44_24_cursor.fork_read_zipper();
    let v44_24_head = Path::from_slice(&[v44_24_byte]);
    let v45_2: Space = singleton(&(v44_24_head));
    let v45_3: Space = intersect(&(*CONSTANT_2),&(v45_2));
    let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = subtract(&(*CONSTANT_1),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v44_24_head));
      let mut v46_7 = Space::new();
      let mut v46_7_cursor = (v44_24_tail).read_zipper();
      for v46_7_byte in v46_7_cursor.child_mask().iter() {
        v46_7_cursor.descend_to_byte(v46_7_byte);
        {
        let v46_7_tail = v46_7_cursor.fork_read_zipper();
        let v46_7_head = Path::from_slice(&[v46_7_byte]);
        let v47_2: Space = singleton(&(v46_7_head));
        let v47_3: Space = intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (v47_5).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&(v46_7_head));
          let mut v48_7 = Space::new();
          let mut v48_7_cursor = (v46_7_tail).read_zipper();
          for v48_7_byte in v48_7_cursor.child_mask().iter() {
            v48_7_cursor.descend_to_byte(v48_7_byte);
            {
            let v48_7_tail = v48_7_cursor.fork_read_zipper();
            let v48_7_head = Path::from_slice(&[v48_7_byte]);
            let v49_2: Space = singleton(&(v48_7_head));
            let v49_3: Space = intersect(&(*CONSTANT_2),&(v49_2));
            let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
            drop(v49_3);
            let v49_5: Space = subtract(&(*CONSTANT_1),&(v49_4));
            drop(v49_4);
            let v49_8: Space = if (v49_5).is_empty() { Space::new() } else {
              let v50_6: Path = concat_path(&(v48_6),&(v48_7_head));
              let v50_7: Space = routine_6(c, &(v50_6), &(v48_7_tail).make_space(), &(*s1));
              compose(&(v49_5),&(v50_7))
            };
            drop(v49_5);
            let v49_9: Space = intersect(&(*CONSTANT_2),&(v49_2));
            drop(v49_2);
            let v49_10: Space = if has_head(&(v49_9)) { singleton(&[]) } else { Space::new() };
            drop(v49_9);
            let v49_12: Space = if (v49_10).is_empty() { Space::new() } else {
              let v51_6: Path = concat_path(&(v48_6),&(v48_7_head));
              let v51_11: Space = routine_7(c, &(v51_6), &(v48_7_tail).make_space(), &(*s1));
              drop(v51_6);
              compose(&(v49_10),&(v51_11))
            };
            drop(v49_10);
            let v49_13: Space = unite(&(v49_8),&(v49_12));
            v48_7.join_into((v49_13).clone());
            }
            v48_7_cursor.ascend(1);
          }
          drop(v48_7_cursor);
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (v47_10).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v46_6),&(v46_7_head));
          let mut v52_11 = Space::new();
          let mut v52_11_cursor = (v46_7_tail).read_zipper();
          for v52_11_byte in v52_11_cursor.child_mask().iter() {
            v52_11_cursor.descend_to_byte(v52_11_byte);
            {
            let v52_11_tail = v52_11_cursor.fork_read_zipper();
            let v52_11_head = Path::from_slice(&[v52_11_byte]);
            let v53_2: Space = singleton(&(v52_11_head));
            let v53_3: Space = intersect(&(*CONSTANT_2),&(v53_2));
            let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
            drop(v53_3);
            let v53_5: Space = subtract(&(*CONSTANT_1),&(v53_4));
            drop(v53_4);
            let v53_8: Space = if (v53_5).is_empty() { Space::new() } else {
              let v54_6: Path = concat_path(&(v52_6),&(v52_11_head));
              let v54_7: Space = routine_6(c, &(v54_6), &(v52_11_tail).make_space(), &(*s1));
              compose(&(v53_5),&(v54_7))
            };
            drop(v53_5);
            let v53_9: Space = intersect(&(*CONSTANT_2),&(v53_2));
            drop(v53_2);
            let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
            drop(v53_9);
            let v53_12: Space = if (v53_10).is_empty() { Space::new() } else {
              let v55_6: Path = concat_path(&(v52_6),&(v52_11_head));
              let v55_11: Space = routine_3(c, &(v55_6), &(v52_11_tail).make_space(), &(*s1));
              drop(v55_6);
              compose(&(v53_10),&(v55_11))
            };
            drop(v53_10);
            let v53_13: Space = unite(&(v53_8),&(v53_12));
            v52_11.join_into((v53_13).clone());
            }
            v52_11_cursor.ascend(1);
          }
          drop(v52_11_cursor);
          drop(v52_6);
          compose(&(v47_10),&(v52_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        v46_7.join_into((v47_13).clone());
        }
        v46_7_cursor.ascend(1);
      }
      drop(v46_7_cursor);
      compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = intersect(&(*CONSTANT_2),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_12: Space = if (v45_10).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&(v44_24_head));
      let mut v56_11 = Space::new();
      let mut v56_11_cursor = (v44_24_tail).read_zipper();
      for v56_11_byte in v56_11_cursor.child_mask().iter() {
        v56_11_cursor.descend_to_byte(v56_11_byte);
        {
        let v56_11_tail = v56_11_cursor.fork_read_zipper();
        let v56_11_head = Path::from_slice(&[v56_11_byte]);
        let v57_2: Space = singleton(&(v56_11_head));
        let v57_3: Space = intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
          let mut v58_6 = Space::new();
          let mut v58_6_cursor = (v56_11_tail).read_zipper();
          for v58_6_byte in v58_6_cursor.child_mask().iter() {
            v58_6_cursor.descend_to_byte(v58_6_byte);
            {
            let v58_6_tail = v58_6_cursor.fork_read_zipper();
            let v58_6_head = Path::from_slice(&[v58_6_byte]);
            let v59_2: Space = singleton(&(v58_6_head));
            let v59_3: Space = intersect(&(*CONSTANT_2),&(v59_2));
            let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
            drop(v59_3);
            let v59_5: Space = subtract(&(*CONSTANT_1),&(v59_4));
            drop(v59_4);
            let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
              let v60_6: Path = concat_path(&(v56_11_head),&(v58_6_head));
              let v60_7: Space = routine_8(c, &(v60_6), &(v56_6), &(v58_6_tail).make_space(), &(*s1));
              compose(&(v59_5),&(v60_7))
            };
            drop(v59_5);
            let v59_9: Space = intersect(&(*CONSTANT_2),&(v59_2));
            drop(v59_2);
            let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
            drop(v59_9);
            let v59_12: Space = if (v59_10).is_empty() { Space::new() } else {
              let v61_6: Path = concat_path(&(v56_11_head),&(v58_6_head));
              let v61_11: Space = routine_9(c, &(v61_6), &(v56_6), &(v58_6_tail).make_space(), &(*s1));
              drop(v61_6);
              compose(&(v59_10),&(v61_11))
            };
            drop(v59_10);
            let v59_13: Space = unite(&(v59_8),&(v59_12));
            v58_6.join_into((v59_13).clone());
            }
            v58_6_cursor.ascend(1);
          }
          drop(v58_6_cursor);
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
          let mut v62_10 = Space::new();
          let mut v62_10_cursor = (v56_11_tail).read_zipper();
          for v62_10_byte in v62_10_cursor.child_mask().iter() {
            v62_10_cursor.descend_to_byte(v62_10_byte);
            {
            let v62_10_tail = v62_10_cursor.fork_read_zipper();
            let v62_10_head = Path::from_slice(&[v62_10_byte]);
            let v63_2: Space = singleton(&(v62_10_head));
            let v63_3: Space = intersect(&(*CONSTANT_2),&(v63_2));
            let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
            drop(v63_3);
            let v63_5: Space = subtract(&(*CONSTANT_1),&(v63_4));
            drop(v63_4);
            let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
              let v64_6: Path = concat_path(&(v56_11_head),&(v62_10_head));
              let v64_7: Space = routine_8(c, &(v64_6), &(v56_6), &(v62_10_tail).make_space(), &(*s1));
              compose(&(v63_5),&(v64_7))
            };
            drop(v63_5);
            let v63_9: Space = intersect(&(*CONSTANT_2),&(v63_2));
            drop(v63_2);
            let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
            drop(v63_9);
            let v63_12: Space = if (v63_10).is_empty() { Space::new() } else {
              let v65_6: Path = concat_path(&(v56_11_head),&(v62_10_head));
              let v65_11: Space = routine_10(c, &(v65_6), &(v56_6), &(v62_10_tail).make_space(), &(*s1));
              drop(v65_6);
              compose(&(v63_10),&(v65_11))
            };
            drop(v63_10);
            let v63_13: Space = unite(&(v63_8),&(v63_12));
            v62_10.join_into((v63_13).clone());
            }
            v62_10_cursor.ascend(1);
          }
          drop(v62_10_cursor);
          compose(&(v57_9),&(v62_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        v56_11.join_into((v57_12).clone());
        }
        v56_11_cursor.ascend(1);
      }
      drop(v56_11_cursor);
      drop(v56_6);
      compose(&(v45_10),&(v56_11))
    };
    drop(v45_10);
    let v45_13: Space = unite(&(v45_8),&(v45_12));
    v44_24.join_into((v45_13).clone());
    }
    v44_24_cursor.ascend(1);
  }
  drop(v44_24_cursor);
  (v44_24).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v66_19: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let mut v66_26 = Space::new();
  let mut v66_26_cursor = (*s0).read_zipper();
  for v66_26_byte in v66_26_cursor.child_mask().iter() {
    v66_26_cursor.descend_to_byte(v66_26_byte);
    {
    let v66_26_tail = v66_26_cursor.fork_read_zipper();
    let v66_26_head = Path::from_slice(&[v66_26_byte]);
    let v67_2: Space = singleton(&(v66_26_head));
    let v67_3: Space = intersect(&(*CONSTANT_2),&(v67_2));
    let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = subtract(&(*CONSTANT_1),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (v67_5).is_empty() { Space::new() } else {
      let mut v68_6 = Space::new();
      let mut v68_6_cursor = (v66_26_tail).read_zipper();
      for v68_6_byte in v68_6_cursor.child_mask().iter() {
        v68_6_cursor.descend_to_byte(v68_6_byte);
        {
        let v68_6_tail = v68_6_cursor.fork_read_zipper();
        let v68_6_head = Path::from_slice(&[v68_6_byte]);
        let v69_2: Space = singleton(&(v68_6_head));
        let v69_3: Space = intersect(&(*CONSTANT_2),&(v69_2));
        let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = subtract(&(*CONSTANT_1),&(v69_4));
        drop(v69_4);
        let v69_8: Space = if (v69_5).is_empty() { Space::new() } else {
          let v70_6: Path = concat_path(&(v66_26_head),&(v68_6_head));
          let mut v70_7 = Space::new();
          let mut v70_7_cursor = (v68_6_tail).read_zipper();
          for v70_7_byte in v70_7_cursor.child_mask().iter() {
            v70_7_cursor.descend_to_byte(v70_7_byte);
            {
            let v70_7_tail = v70_7_cursor.fork_read_zipper();
            let v70_7_head = Path::from_slice(&[v70_7_byte]);
            let v71_2: Space = singleton(&(v70_7_head));
            let v71_3: Space = intersect(&(*CONSTANT_2),&(v71_2));
            let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
            drop(v71_3);
            let v71_5: Space = subtract(&(*CONSTANT_1),&(v71_4));
            drop(v71_4);
            let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
              let v72_6: Path = concat_path(&(v70_6),&(v70_7_head));
              let v72_7: Space = routine_11(c, &(v72_6), &(*p0), &(v70_7_tail).make_space(), &(*s1));
              compose(&(v71_5),&(v72_7))
            };
            drop(v71_5);
            let v71_9: Space = intersect(&(*CONSTANT_2),&(v71_2));
            drop(v71_2);
            let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
            drop(v71_9);
            let v71_12: Space = if (v71_10).is_empty() { Space::new() } else {
              let v73_6: Path = concat_path(&(v70_6),&(v70_7_head));
              let v73_11: Space = routine_12(c, &(v73_6), &(*p0), &(v70_7_tail).make_space(), &(*s1));
              drop(v73_6);
              compose(&(v71_10),&(v73_11))
            };
            drop(v71_10);
            let v71_13: Space = unite(&(v71_8),&(v71_12));
            v70_7.join_into((v71_13).clone());
            }
            v70_7_cursor.ascend(1);
          }
          drop(v70_7_cursor);
          compose(&(v69_5),&(v70_7))
        };
        drop(v69_5);
        let v69_9: Space = intersect(&(*CONSTANT_2),&(v69_2));
        drop(v69_2);
        let v69_10: Space = if has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
        drop(v69_9);
        let v69_12: Space = if (v69_10).is_empty() { Space::new() } else {
          let v74_6: Path = concat_path(&(v66_26_head),&(v68_6_head));
          let mut v74_11 = Space::new();
          let mut v74_11_cursor = (v68_6_tail).read_zipper();
          for v74_11_byte in v74_11_cursor.child_mask().iter() {
            v74_11_cursor.descend_to_byte(v74_11_byte);
            {
            let v74_11_tail = v74_11_cursor.fork_read_zipper();
            let v74_11_head = Path::from_slice(&[v74_11_byte]);
            let v75_2: Space = singleton(&(v74_11_head));
            let v75_3: Space = intersect(&(*CONSTANT_2),&(v75_2));
            let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
            drop(v75_3);
            let v75_5: Space = subtract(&(*CONSTANT_1),&(v75_4));
            drop(v75_4);
            let v75_8: Space = if (v75_5).is_empty() { Space::new() } else {
              let v76_6: Path = concat_path(&(v74_6),&(v74_11_head));
              let v76_7: Space = routine_11(c, &(v76_6), &(*p0), &(v74_11_tail).make_space(), &(*s1));
              compose(&(v75_5),&(v76_7))
            };
            drop(v75_5);
            let v75_9: Space = intersect(&(*CONSTANT_2),&(v75_2));
            drop(v75_2);
            let v75_10: Space = if has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
            drop(v75_9);
            let v75_12: Space = if (v75_10).is_empty() { Space::new() } else {
              let v77_6: Path = concat_path(&(v74_6),&(v74_11_head));
              let v77_11: Space = routine_10(c, &(v77_6), &(*p0), &(v74_11_tail).make_space(), &(*s1));
              drop(v77_6);
              compose(&(v75_10),&(v77_11))
            };
            drop(v75_10);
            let v75_13: Space = unite(&(v75_8),&(v75_12));
            v74_11.join_into((v75_13).clone());
            }
            v74_11_cursor.ascend(1);
          }
          drop(v74_11_cursor);
          drop(v74_6);
          compose(&(v69_10),&(v74_11))
        };
        drop(v69_10);
        let v69_13: Space = unite(&(v69_8),&(v69_12));
        v68_6.join_into((v69_13).clone());
        }
        v68_6_cursor.ascend(1);
      }
      drop(v68_6_cursor);
      compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = intersect(&(*CONSTANT_2),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_12: Space = if (v67_9).is_empty() { Space::new() } else {
      let v78_10: Space = unwrap(&(v66_19),&(v66_26_head));
      let mut v78_11 = Space::new();
      let mut v78_11_cursor = (v66_26_tail).read_zipper();
      for v78_11_byte in v78_11_cursor.child_mask().iter() {
        v78_11_cursor.descend_to_byte(v78_11_byte);
        {
        let v78_11_tail = v78_11_cursor.fork_read_zipper();
        let v78_11_head = Path::from_slice(&[v78_11_byte]);
        let v79_2: Space = singleton(&(v78_11_head));
        let v79_3: Space = intersect(&(*CONSTANT_2),&(v79_2));
        let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
        drop(v79_3);
        let v79_5: Space = subtract(&(*CONSTANT_1),&(v79_4));
        drop(v79_4);
        let v79_8: Space = if (v79_5).is_empty() { Space::new() } else {
          let v80_6: Path = concat_path(&(v66_26_head),&(v78_11_head));
          let mut v80_7 = Space::new();
          let mut v80_7_cursor = (v78_11_tail).read_zipper();
          for v80_7_byte in v80_7_cursor.child_mask().iter() {
            v80_7_cursor.descend_to_byte(v80_7_byte);
            {
            let v80_7_tail = v80_7_cursor.fork_read_zipper();
            let v80_7_head = Path::from_slice(&[v80_7_byte]);
            let v81_2: Space = singleton(&(v80_7_head));
            let v81_3: Space = intersect(&(*CONSTANT_2),&(v81_2));
            let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
            drop(v81_3);
            let v81_5: Space = subtract(&(*CONSTANT_1),&(v81_4));
            drop(v81_4);
            let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
              let v82_6: Path = concat_path(&(v80_6),&(v80_7_head));
              let v82_7: Space = routine_11(c, &(v82_6), &(*p0), &(v80_7_tail).make_space(), &(*s1));
              compose(&(v81_5),&(v82_7))
            };
            drop(v81_5);
            let v81_9: Space = intersect(&(*CONSTANT_2),&(v81_2));
            drop(v81_2);
            let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
            drop(v81_9);
            let v81_12: Space = if (v81_10).is_empty() { Space::new() } else {
              let v83_6: Path = concat_path(&(v80_6),&(v80_7_head));
              let v83_11: Space = routine_12(c, &(v83_6), &(*p0), &(v80_7_tail).make_space(), &(*s1));
              drop(v83_6);
              compose(&(v81_10),&(v83_11))
            };
            drop(v81_10);
            let v81_13: Space = unite(&(v81_8),&(v81_12));
            v80_7.join_into((v81_13).clone());
            }
            v80_7_cursor.ascend(1);
          }
          drop(v80_7_cursor);
          drop(v80_6);
          compose(&(v79_5),&(v80_7))
        };
        drop(v79_5);
        let v79_9: Space = intersect(&(*CONSTANT_2),&(v79_2));
        drop(v79_2);
        let v79_10: Space = if has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
        drop(v79_9);
        let v79_13: Space = if (v79_10).is_empty() { Space::new() } else {
          let v84_11: Space = unwrap(&(v78_10),&(v78_11_head));
          let mut v84_12 = Space::new();
          let mut v84_12_cursor = (v84_11).read_zipper();
          for v84_12_byte in v84_12_cursor.child_mask().iter() {
            v84_12_cursor.descend_to_byte(v84_12_byte);
            {
            let v84_12_tail = v84_12_cursor.fork_read_zipper();
            let v84_12_head = Path::from_slice(&[v84_12_byte]);
            let v85_2: Space = singleton(&(v84_12_head));
            let v85_3: Space = intersect(&(*CONSTANT_2),&(v85_2));
            let v85_4: Space = if has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
            drop(v85_3);
            let v85_5: Space = subtract(&(*CONSTANT_1),&(v85_4));
            drop(v85_4);
            let v85_7: Space = if (v85_5).is_empty() { Space::new() } else {
              let v86_6: Space = routine_13(c, &(v84_12_head), &(*p0), &(v84_12_tail).make_space());
              compose(&(v85_5),&(v86_6))
            };
            drop(v85_5);
            let v85_8: Space = intersect(&(*CONSTANT_2),&(v85_2));
            drop(v85_2);
            let v85_9: Space = if has_head(&(v85_8)) { singleton(&[]) } else { Space::new() };
            drop(v85_8);
            let v85_11: Space = if (v85_9).is_empty() { Space::new() } else {
              let v87_10: Space = routine_14(c, &(v84_12_head), &(*p0), &(v84_12_tail).make_space());
              compose(&(v85_9),&(v87_10))
            };
            drop(v85_9);
            let v85_12: Space = unite(&(v85_7),&(v85_11));
            v84_12.join_into((v85_12).clone());
            }
            v84_12_cursor.ascend(1);
          }
          drop(v84_12_cursor);
          drop(v84_11);
          compose(&(v79_10),&(v84_12))
        };
        drop(v79_10);
        let v79_14: Space = unite(&(v79_8),&(v79_13));
        v78_11.join_into((v79_14).clone());
        }
        v78_11_cursor.ascend(1);
      }
      drop(v78_11_cursor);
      drop(v78_10);
      compose(&(v67_9),&(v78_11))
    };
    drop(v67_9);
    let v67_13: Space = unite(&(v67_7),&(v67_12));
    v66_26.join_into((v67_13).clone());
    }
    v66_26_cursor.ascend(1);
  }
  drop(v66_26_cursor);
  drop(v66_19);
  (v66_26).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v88_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v88_21: Space = unwrap(&(v88_20),&(*p0));
  drop(v88_20);
  let mut v88_28 = Space::new();
  let mut v88_28_cursor = (*s0).read_zipper();
  for v88_28_byte in v88_28_cursor.child_mask().iter() {
    v88_28_cursor.descend_to_byte(v88_28_byte);
    {
    let v88_28_tail = v88_28_cursor.fork_read_zipper();
    let v88_28_head = Path::from_slice(&[v88_28_byte]);
    let v89_2: Space = singleton(&(v88_28_head));
    let v89_3: Space = intersect(&(*CONSTANT_2),&(v89_2));
    let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
    drop(v89_3);
    let v89_5: Space = subtract(&(*CONSTANT_1),&(v89_4));
    drop(v89_4);
    let v89_8: Space = if (v89_5).is_empty() { Space::new() } else {
      let v90_6: Path = concat_path(&(*p0),&(v88_28_head));
      let mut v90_7 = Space::new();
      let mut v90_7_cursor = (v88_28_tail).read_zipper();
      for v90_7_byte in v90_7_cursor.child_mask().iter() {
        v90_7_cursor.descend_to_byte(v90_7_byte);
        {
        let v90_7_tail = v90_7_cursor.fork_read_zipper();
        let v90_7_head = Path::from_slice(&[v90_7_byte]);
        let v91_2: Space = singleton(&(v90_7_head));
        let v91_3: Space = intersect(&(*CONSTANT_2),&(v91_2));
        let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = subtract(&(*CONSTANT_1),&(v91_4));
        drop(v91_4);
        let v91_8: Space = if (v91_5).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v90_6),&(v90_7_head));
          let mut v92_7 = Space::new();
          let mut v92_7_cursor = (v90_7_tail).read_zipper();
          for v92_7_byte in v92_7_cursor.child_mask().iter() {
            v92_7_cursor.descend_to_byte(v92_7_byte);
            {
            let v92_7_tail = v92_7_cursor.fork_read_zipper();
            let v92_7_head = Path::from_slice(&[v92_7_byte]);
            let v93_2: Space = singleton(&(v92_7_head));
            let v93_3: Space = intersect(&(*CONSTANT_2),&(v93_2));
            let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
            drop(v93_3);
            let v93_5: Space = subtract(&(*CONSTANT_1),&(v93_4));
            drop(v93_4);
            let v93_8: Space = if (v93_5).is_empty() { Space::new() } else {
              let v94_6: Path = concat_path(&(v92_6),&(v92_7_head));
              let v94_7: Space = routine_15(c, &(v94_6), &(*p1), &(v92_7_tail).make_space(), &(*s1));
              compose(&(v93_5),&(v94_7))
            };
            drop(v93_5);
            let v93_9: Space = intersect(&(*CONSTANT_2),&(v93_2));
            drop(v93_2);
            let v93_10: Space = if has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
            drop(v93_9);
            let v93_12: Space = if (v93_10).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v92_6),&(v92_7_head));
              let v95_11: Space = routine_16(c, &(v95_6), &(*p1), &(v92_7_tail).make_space(), &(*s1));
              drop(v95_6);
              compose(&(v93_10),&(v95_11))
            };
            drop(v93_10);
            let v93_13: Space = unite(&(v93_8),&(v93_12));
            v92_7.join_into((v93_13).clone());
            }
            v92_7_cursor.ascend(1);
          }
          drop(v92_7_cursor);
          compose(&(v91_5),&(v92_7))
        };
        drop(v91_5);
        let v91_9: Space = intersect(&(*CONSTANT_2),&(v91_2));
        drop(v91_2);
        let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
        drop(v91_9);
        let v91_12: Space = if (v91_10).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v90_6),&(v90_7_head));
          let mut v96_11 = Space::new();
          let mut v96_11_cursor = (v90_7_tail).read_zipper();
          for v96_11_byte in v96_11_cursor.child_mask().iter() {
            v96_11_cursor.descend_to_byte(v96_11_byte);
            {
            let v96_11_tail = v96_11_cursor.fork_read_zipper();
            let v96_11_head = Path::from_slice(&[v96_11_byte]);
            let v97_2: Space = singleton(&(v96_11_head));
            let v97_3: Space = intersect(&(*CONSTANT_2),&(v97_2));
            let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
            drop(v97_3);
            let v97_5: Space = subtract(&(*CONSTANT_1),&(v97_4));
            drop(v97_4);
            let v97_8: Space = if (v97_5).is_empty() { Space::new() } else {
              let v98_6: Path = concat_path(&(v96_6),&(v96_11_head));
              let v98_7: Space = routine_15(c, &(v98_6), &(*p1), &(v96_11_tail).make_space(), &(*s1));
              compose(&(v97_5),&(v98_7))
            };
            drop(v97_5);
            let v97_9: Space = intersect(&(*CONSTANT_2),&(v97_2));
            drop(v97_2);
            let v97_10: Space = if has_head(&(v97_9)) { singleton(&[]) } else { Space::new() };
            drop(v97_9);
            let v97_12: Space = if (v97_10).is_empty() { Space::new() } else {
              let v99_6: Path = concat_path(&(v96_6),&(v96_11_head));
              let v99_11: Space = routine_10(c, &(v99_6), &(*p1), &(v96_11_tail).make_space(), &(*s1));
              drop(v99_6);
              compose(&(v97_10),&(v99_11))
            };
            drop(v97_10);
            let v97_13: Space = unite(&(v97_8),&(v97_12));
            v96_11.join_into((v97_13).clone());
            }
            v96_11_cursor.ascend(1);
          }
          drop(v96_11_cursor);
          drop(v96_6);
          compose(&(v91_10),&(v96_11))
        };
        drop(v91_10);
        let v91_13: Space = unite(&(v91_8),&(v91_12));
        v90_7.join_into((v91_13).clone());
        }
        v90_7_cursor.ascend(1);
      }
      drop(v90_7_cursor);
      compose(&(v89_5),&(v90_7))
    };
    drop(v89_5);
    let v89_9: Space = intersect(&(*CONSTANT_2),&(v89_2));
    drop(v89_2);
    let v89_10: Space = if has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
    drop(v89_9);
    let v89_13: Space = if (v89_10).is_empty() { Space::new() } else {
      let v100_6: Path = concat_path(&(*p0),&(v88_28_head));
      let v100_11: Space = unwrap(&(v88_21),&(v88_28_head));
      let mut v100_12 = Space::new();
      let mut v100_12_cursor = (v88_28_tail).read_zipper();
      for v100_12_byte in v100_12_cursor.child_mask().iter() {
        v100_12_cursor.descend_to_byte(v100_12_byte);
        {
        let v100_12_tail = v100_12_cursor.fork_read_zipper();
        let v100_12_head = Path::from_slice(&[v100_12_byte]);
        let v101_2: Space = singleton(&(v100_12_head));
        let v101_3: Space = intersect(&(*CONSTANT_2),&(v101_2));
        let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
        drop(v101_3);
        let v101_5: Space = subtract(&(*CONSTANT_1),&(v101_4));
        drop(v101_4);
        let v101_8: Space = if (v101_5).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v100_6),&(v100_12_head));
          let mut v102_7 = Space::new();
          let mut v102_7_cursor = (v100_12_tail).read_zipper();
          for v102_7_byte in v102_7_cursor.child_mask().iter() {
            v102_7_cursor.descend_to_byte(v102_7_byte);
            {
            let v102_7_tail = v102_7_cursor.fork_read_zipper();
            let v102_7_head = Path::from_slice(&[v102_7_byte]);
            let v103_2: Space = singleton(&(v102_7_head));
            let v103_3: Space = intersect(&(*CONSTANT_2),&(v103_2));
            let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
            drop(v103_3);
            let v103_5: Space = subtract(&(*CONSTANT_1),&(v103_4));
            drop(v103_4);
            let v103_8: Space = if (v103_5).is_empty() { Space::new() } else {
              let v104_6: Path = concat_path(&(v102_6),&(v102_7_head));
              let v104_7: Space = routine_15(c, &(v104_6), &(*p1), &(v102_7_tail).make_space(), &(*s1));
              compose(&(v103_5),&(v104_7))
            };
            drop(v103_5);
            let v103_9: Space = intersect(&(*CONSTANT_2),&(v103_2));
            drop(v103_2);
            let v103_10: Space = if has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
            drop(v103_9);
            let v103_12: Space = if (v103_10).is_empty() { Space::new() } else {
              let v105_6: Path = concat_path(&(v102_6),&(v102_7_head));
              let v105_11: Space = routine_16(c, &(v105_6), &(*p1), &(v102_7_tail).make_space(), &(*s1));
              drop(v105_6);
              compose(&(v103_10),&(v105_11))
            };
            drop(v103_10);
            let v103_13: Space = unite(&(v103_8),&(v103_12));
            v102_7.join_into((v103_13).clone());
            }
            v102_7_cursor.ascend(1);
          }
          drop(v102_7_cursor);
          drop(v102_6);
          compose(&(v101_5),&(v102_7))
        };
        drop(v101_5);
        let v101_9: Space = intersect(&(*CONSTANT_2),&(v101_2));
        drop(v101_2);
        let v101_10: Space = if has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
        drop(v101_9);
        let v101_13: Space = if (v101_10).is_empty() { Space::new() } else {
          let v106_11: Space = unwrap(&(v100_11),&(v100_12_head));
          let mut v106_12 = Space::new();
          let mut v106_12_cursor = (v106_11).read_zipper();
          for v106_12_byte in v106_12_cursor.child_mask().iter() {
            v106_12_cursor.descend_to_byte(v106_12_byte);
            {
            let v106_12_tail = v106_12_cursor.fork_read_zipper();
            let v106_12_head = Path::from_slice(&[v106_12_byte]);
            let v107_2: Space = singleton(&(v106_12_head));
            let v107_3: Space = intersect(&(*CONSTANT_2),&(v107_2));
            let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
            drop(v107_3);
            let v107_5: Space = subtract(&(*CONSTANT_1),&(v107_4));
            drop(v107_4);
            let v107_7: Space = if (v107_5).is_empty() { Space::new() } else {
              let v108_6: Space = routine_13(c, &(v106_12_head), &(*p1), &(v106_12_tail).make_space());
              compose(&(v107_5),&(v108_6))
            };
            drop(v107_5);
            let v107_8: Space = intersect(&(*CONSTANT_2),&(v107_2));
            drop(v107_2);
            let v107_9: Space = if has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
            drop(v107_8);
            let v107_11: Space = if (v107_9).is_empty() { Space::new() } else {
              let v109_10: Space = routine_14(c, &(v106_12_head), &(*p1), &(v106_12_tail).make_space());
              compose(&(v107_9),&(v109_10))
            };
            drop(v107_9);
            let v107_12: Space = unite(&(v107_7),&(v107_11));
            v106_12.join_into((v107_12).clone());
            }
            v106_12_cursor.ascend(1);
          }
          drop(v106_12_cursor);
          drop(v106_11);
          compose(&(v101_10),&(v106_12))
        };
        drop(v101_10);
        let v101_14: Space = unite(&(v101_8),&(v101_13));
        v100_12.join_into((v101_14).clone());
        }
        v100_12_cursor.ascend(1);
      }
      drop(v100_12_cursor);
      drop(v100_6);
      drop(v100_11);
      compose(&(v89_10),&(v100_12))
    };
    drop(v89_10);
    let v89_14: Space = unite(&(v89_8),&(v89_13));
    v88_28.join_into((v89_14).clone());
    }
    v88_28_cursor.ascend(1);
  }
  drop(v88_28_cursor);
  drop(v88_21);
  (v88_28).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v110_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v110_9: Space = unwrap(&(v110_8),&(*p0));
  drop(v110_8);
  let mut v110_28 = Space::new();
  let mut v110_28_cursor = (*s0).read_zipper();
  for v110_28_byte in v110_28_cursor.child_mask().iter() {
    v110_28_cursor.descend_to_byte(v110_28_byte);
    {
    let v110_28_tail = v110_28_cursor.fork_read_zipper();
    let v110_28_head = Path::from_slice(&[v110_28_byte]);
    let v111_2: Space = singleton(&(v110_28_head));
    let v111_3: Space = intersect(&(*CONSTANT_2),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_1),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (v111_5).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&(v110_28_head));
      let mut v112_7 = Space::new();
      let mut v112_7_cursor = (v110_28_tail).read_zipper();
      for v112_7_byte in v112_7_cursor.child_mask().iter() {
        v112_7_cursor.descend_to_byte(v112_7_byte);
        {
        let v112_7_tail = v112_7_cursor.fork_read_zipper();
        let v112_7_head = Path::from_slice(&[v112_7_byte]);
        let v113_2: Space = singleton(&(v112_7_head));
        let v113_3: Space = intersect(&(*CONSTANT_2),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_1),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let mut v114_7 = Space::new();
          let mut v114_7_cursor = (v112_7_tail).read_zipper();
          for v114_7_byte in v114_7_cursor.child_mask().iter() {
            v114_7_cursor.descend_to_byte(v114_7_byte);
            {
            let v114_7_tail = v114_7_cursor.fork_read_zipper();
            let v114_7_head = Path::from_slice(&[v114_7_byte]);
            let v115_2: Space = singleton(&(v114_7_head));
            let v115_3: Space = intersect(&(*CONSTANT_2),&(v115_2));
            let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = subtract(&(*CONSTANT_1),&(v115_4));
            drop(v115_4);
            let v115_8: Space = if (v115_5).is_empty() { Space::new() } else {
              let v116_6: Path = concat_path(&(v114_6),&(v114_7_head));
              let v116_7: Space = routine_15(c, &(v116_6), &(*p1), &(v114_7_tail).make_space(), &(*s1));
              compose(&(v115_5),&(v116_7))
            };
            drop(v115_5);
            let v115_9: Space = intersect(&(*CONSTANT_2),&(v115_2));
            drop(v115_2);
            let v115_10: Space = if has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
            drop(v115_9);
            let v115_12: Space = if (v115_10).is_empty() { Space::new() } else {
              let v117_6: Path = concat_path(&(v114_6),&(v114_7_head));
              let v117_11: Space = routine_16(c, &(v117_6), &(*p1), &(v114_7_tail).make_space(), &(*s1));
              drop(v117_6);
              compose(&(v115_10),&(v117_11))
            };
            drop(v115_10);
            let v115_13: Space = unite(&(v115_8),&(v115_12));
            v114_7.join_into((v115_13).clone());
            }
            v114_7_cursor.ascend(1);
          }
          drop(v114_7_cursor);
          compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = intersect(&(*CONSTANT_2),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (v113_10).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let mut v118_11 = Space::new();
          let mut v118_11_cursor = (v112_7_tail).read_zipper();
          for v118_11_byte in v118_11_cursor.child_mask().iter() {
            v118_11_cursor.descend_to_byte(v118_11_byte);
            {
            let v118_11_tail = v118_11_cursor.fork_read_zipper();
            let v118_11_head = Path::from_slice(&[v118_11_byte]);
            let v119_2: Space = singleton(&(v118_11_head));
            let v119_3: Space = intersect(&(*CONSTANT_2),&(v119_2));
            let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
            drop(v119_3);
            let v119_5: Space = subtract(&(*CONSTANT_1),&(v119_4));
            drop(v119_4);
            let v119_8: Space = if (v119_5).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v118_6),&(v118_11_head));
              let v120_7: Space = routine_15(c, &(v120_6), &(*p1), &(v118_11_tail).make_space(), &(*s1));
              compose(&(v119_5),&(v120_7))
            };
            drop(v119_5);
            let v119_9: Space = intersect(&(*CONSTANT_2),&(v119_2));
            drop(v119_2);
            let v119_10: Space = if has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
            drop(v119_9);
            let v119_12: Space = if (v119_10).is_empty() { Space::new() } else {
              let v121_6: Path = concat_path(&(v118_6),&(v118_11_head));
              let v121_11: Space = routine_10(c, &(v121_6), &(*p1), &(v118_11_tail).make_space(), &(*s1));
              drop(v121_6);
              compose(&(v119_10),&(v121_11))
            };
            drop(v119_10);
            let v119_13: Space = unite(&(v119_8),&(v119_12));
            v118_11.join_into((v119_13).clone());
            }
            v118_11_cursor.ascend(1);
          }
          drop(v118_11_cursor);
          drop(v118_6);
          compose(&(v113_10),&(v118_11))
        };
        drop(v113_10);
        let v113_13: Space = unite(&(v113_8),&(v113_12));
        v112_7.join_into((v113_13).clone());
        }
        v112_7_cursor.ascend(1);
      }
      drop(v112_7_cursor);
      drop(v112_6);
      compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = intersect(&(*CONSTANT_2),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_13: Space = if (v111_10).is_empty() { Space::new() } else {
      let v122_11: Space = unwrap(&(v110_9),&(v110_28_head));
      let mut v122_12 = Space::new();
      let mut v122_12_cursor = (v122_11).read_zipper();
      for v122_12_byte in v122_12_cursor.child_mask().iter() {
        v122_12_cursor.descend_to_byte(v122_12_byte);
        {
        let v122_12_tail = v122_12_cursor.fork_read_zipper();
        let v122_12_head = Path::from_slice(&[v122_12_byte]);
        let v123_2: Space = singleton(&(v122_12_head));
        let v123_3: Space = intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (v123_5).is_empty() { Space::new() } else {
          let mut v124_6 = Space::new();
          let mut v124_6_cursor = (v122_12_tail).read_zipper();
          for v124_6_byte in v124_6_cursor.child_mask().iter() {
            v124_6_cursor.descend_to_byte(v124_6_byte);
            {
            let v124_6_tail = v124_6_cursor.fork_read_zipper();
            let v124_6_head = Path::from_slice(&[v124_6_byte]);
            let v125_2: Space = singleton(&(v124_6_head));
            let v125_3: Space = intersect(&(*CONSTANT_2),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_1),&(v125_4));
            drop(v125_4);
            let v125_8: Space = if (v125_5).is_empty() { Space::new() } else {
              let v126_6: Path = concat_path(&(v122_12_head),&(v124_6_head));
              let v126_7: Space = routine_17(c, &(v126_6), &(*p1), &(v124_6_tail).make_space());
              compose(&(v125_5),&(v126_7))
            };
            drop(v125_5);
            let v125_9: Space = intersect(&(*CONSTANT_2),&(v125_2));
            drop(v125_2);
            let v125_10: Space = if has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
            drop(v125_9);
            let v125_12: Space = if (v125_10).is_empty() { Space::new() } else {
              let v127_6: Path = concat_path(&(v122_12_head),&(v124_6_head));
              let v127_11: Space = routine_18(c, &(v127_6), &(*p1), &(v124_6_tail).make_space());
              drop(v127_6);
              compose(&(v125_10),&(v127_11))
            };
            drop(v125_10);
            let v125_13: Space = unite(&(v125_8),&(v125_12));
            v124_6.join_into((v125_13).clone());
            }
            v124_6_cursor.ascend(1);
          }
          drop(v124_6_cursor);
          compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (v123_9).is_empty() { Space::new() } else {
          let mut v128_10 = Space::new();
          let mut v128_10_cursor = (v122_12_tail).read_zipper();
          for v128_10_byte in v128_10_cursor.child_mask().iter() {
            v128_10_cursor.descend_to_byte(v128_10_byte);
            {
            let v128_10_tail = v128_10_cursor.fork_read_zipper();
            let v128_10_head = Path::from_slice(&[v128_10_byte]);
            let v129_2: Space = singleton(&(v128_10_head));
            let v129_3: Space = intersect(&(*CONSTANT_2),&(v129_2));
            let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
            drop(v129_3);
            let v129_5: Space = subtract(&(*CONSTANT_1),&(v129_4));
            drop(v129_4);
            let v129_8: Space = if (v129_5).is_empty() { Space::new() } else {
              let v130_6: Path = concat_path(&(v122_12_head),&(v128_10_head));
              let v130_7: Space = routine_17(c, &(v130_6), &(*p1), &(v128_10_tail).make_space());
              compose(&(v129_5),&(v130_7))
            };
            drop(v129_5);
            let v129_9: Space = intersect(&(*CONSTANT_2),&(v129_2));
            drop(v129_2);
            let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
            drop(v129_9);
            let v129_12: Space = if (v129_10).is_empty() { Space::new() } else {
              let v131_6: Path = concat_path(&(v122_12_head),&(v128_10_head));
              let v131_11: Space = routine_19(c, &(v131_6), &(*p1), &(v128_10_tail).make_space());
              drop(v131_6);
              compose(&(v129_10),&(v131_11))
            };
            drop(v129_10);
            let v129_13: Space = unite(&(v129_8),&(v129_12));
            v128_10.join_into((v129_13).clone());
            }
            v128_10_cursor.ascend(1);
          }
          drop(v128_10_cursor);
          compose(&(v123_9),&(v128_10))
        };
        drop(v123_9);
        let v123_12: Space = unite(&(v123_7),&(v123_11));
        v122_12.join_into((v123_12).clone());
        }
        v122_12_cursor.ascend(1);
      }
      drop(v122_12_cursor);
      drop(v122_11);
      compose(&(v111_10),&(v122_12))
    };
    drop(v111_10);
    let v111_14: Space = unite(&(v111_8),&(v111_13));
    v110_28.join_into((v111_14).clone());
    }
    v110_28_cursor.ascend(1);
  }
  drop(v110_28_cursor);
  drop(v110_9);
  (v110_28).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v132_24 = Space::new();
  let mut v132_24_cursor = (*s0).read_zipper();
  for v132_24_byte in v132_24_cursor.child_mask().iter() {
    v132_24_cursor.descend_to_byte(v132_24_byte);
    {
    let v132_24_tail = v132_24_cursor.fork_read_zipper();
    let v132_24_head = Path::from_slice(&[v132_24_byte]);
    let v133_2: Space = singleton(&(v132_24_head));
    let v133_3: Space = intersect(&(*CONSTANT_2),&(v133_2));
    let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
    drop(v133_3);
    let v133_5: Space = subtract(&(*CONSTANT_1),&(v133_4));
    drop(v133_4);
    let v133_8: Space = if (v133_5).is_empty() { Space::new() } else {
      let v134_6: Path = concat_path(&(*p0),&(v132_24_head));
      let mut v134_7 = Space::new();
      let mut v134_7_cursor = (v132_24_tail).read_zipper();
      for v134_7_byte in v134_7_cursor.child_mask().iter() {
        v134_7_cursor.descend_to_byte(v134_7_byte);
        {
        let v134_7_tail = v134_7_cursor.fork_read_zipper();
        let v134_7_head = Path::from_slice(&[v134_7_byte]);
        let v135_2: Space = singleton(&(v134_7_head));
        let v135_3: Space = intersect(&(*CONSTANT_2),&(v135_2));
        let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
        drop(v135_3);
        let v135_5: Space = subtract(&(*CONSTANT_1),&(v135_4));
        drop(v135_4);
        let v135_8: Space = if (v135_5).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v134_6),&(v134_7_head));
          let mut v136_7 = Space::new();
          let mut v136_7_cursor = (v134_7_tail).read_zipper();
          for v136_7_byte in v136_7_cursor.child_mask().iter() {
            v136_7_cursor.descend_to_byte(v136_7_byte);
            {
            let v136_7_tail = v136_7_cursor.fork_read_zipper();
            let v136_7_head = Path::from_slice(&[v136_7_byte]);
            let v137_2: Space = singleton(&(v136_7_head));
            let v137_3: Space = intersect(&(*CONSTANT_2),&(v137_2));
            let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
            drop(v137_3);
            let v137_5: Space = subtract(&(*CONSTANT_1),&(v137_4));
            drop(v137_4);
            let v137_8: Space = if (v137_5).is_empty() { Space::new() } else {
              let v138_6: Path = concat_path(&(v136_6),&(v136_7_head));
              let v138_7: Space = routine_20(c, &(v138_6), &(v136_7_tail).make_space(), &(*s1));
              compose(&(v137_5),&(v138_7))
            };
            drop(v137_5);
            let v137_9: Space = intersect(&(*CONSTANT_2),&(v137_2));
            drop(v137_2);
            let v137_10: Space = if has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
            drop(v137_9);
            let v137_12: Space = if (v137_10).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v136_6),&(v136_7_head));
              let v139_11: Space = routine_21(c, &(v139_6), &(v136_7_tail).make_space(), &(*s1));
              drop(v139_6);
              compose(&(v137_10),&(v139_11))
            };
            drop(v137_10);
            let v137_13: Space = unite(&(v137_8),&(v137_12));
            v136_7.join_into((v137_13).clone());
            }
            v136_7_cursor.ascend(1);
          }
          drop(v136_7_cursor);
          compose(&(v135_5),&(v136_7))
        };
        drop(v135_5);
        let v135_9: Space = intersect(&(*CONSTANT_2),&(v135_2));
        drop(v135_2);
        let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
        drop(v135_9);
        let v135_12: Space = if (v135_10).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v134_6),&(v134_7_head));
          let mut v140_11 = Space::new();
          let mut v140_11_cursor = (v134_7_tail).read_zipper();
          for v140_11_byte in v140_11_cursor.child_mask().iter() {
            v140_11_cursor.descend_to_byte(v140_11_byte);
            {
            let v140_11_tail = v140_11_cursor.fork_read_zipper();
            let v140_11_head = Path::from_slice(&[v140_11_byte]);
            let v141_2: Space = singleton(&(v140_11_head));
            let v141_3: Space = intersect(&(*CONSTANT_2),&(v141_2));
            let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
            drop(v141_3);
            let v141_5: Space = subtract(&(*CONSTANT_1),&(v141_4));
            drop(v141_4);
            let v141_8: Space = if (v141_5).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v140_6),&(v140_11_head));
              let v142_7: Space = routine_20(c, &(v142_6), &(v140_11_tail).make_space(), &(*s1));
              compose(&(v141_5),&(v142_7))
            };
            drop(v141_5);
            let v141_9: Space = intersect(&(*CONSTANT_2),&(v141_2));
            drop(v141_2);
            let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
            drop(v141_9);
            let v141_12: Space = if (v141_10).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v140_6),&(v140_11_head));
              let v143_11: Space = routine_3(c, &(v143_6), &(v140_11_tail).make_space(), &(*s1));
              drop(v143_6);
              compose(&(v141_10),&(v143_11))
            };
            drop(v141_10);
            let v141_13: Space = unite(&(v141_8),&(v141_12));
            v140_11.join_into((v141_13).clone());
            }
            v140_11_cursor.ascend(1);
          }
          drop(v140_11_cursor);
          drop(v140_6);
          compose(&(v135_10),&(v140_11))
        };
        drop(v135_10);
        let v135_13: Space = unite(&(v135_8),&(v135_12));
        v134_7.join_into((v135_13).clone());
        }
        v134_7_cursor.ascend(1);
      }
      drop(v134_7_cursor);
      compose(&(v133_5),&(v134_7))
    };
    drop(v133_5);
    let v133_9: Space = intersect(&(*CONSTANT_2),&(v133_2));
    drop(v133_2);
    let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
    drop(v133_9);
    let v133_12: Space = if (v133_10).is_empty() { Space::new() } else {
      let v144_6: Path = concat_path(&(*p0),&(v132_24_head));
      let mut v144_11 = Space::new();
      let mut v144_11_cursor = (v132_24_tail).read_zipper();
      for v144_11_byte in v144_11_cursor.child_mask().iter() {
        v144_11_cursor.descend_to_byte(v144_11_byte);
        {
        let v144_11_tail = v144_11_cursor.fork_read_zipper();
        let v144_11_head = Path::from_slice(&[v144_11_byte]);
        let v145_2: Space = singleton(&(v144_11_head));
        let v145_3: Space = intersect(&(*CONSTANT_2),&(v145_2));
        let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = subtract(&(*CONSTANT_1),&(v145_4));
        drop(v145_4);
        let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v144_6),&(v144_11_head));
          let mut v146_7 = Space::new();
          let mut v146_7_cursor = (v144_11_tail).read_zipper();
          for v146_7_byte in v146_7_cursor.child_mask().iter() {
            v146_7_cursor.descend_to_byte(v146_7_byte);
            {
            let v146_7_tail = v146_7_cursor.fork_read_zipper();
            let v146_7_head = Path::from_slice(&[v146_7_byte]);
            let v147_2: Space = singleton(&(v146_7_head));
            let v147_3: Space = intersect(&(*CONSTANT_2),&(v147_2));
            let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
            drop(v147_3);
            let v147_5: Space = subtract(&(*CONSTANT_1),&(v147_4));
            drop(v147_4);
            let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
              let v148_6: Path = concat_path(&(v146_6),&(v146_7_head));
              let v148_7: Space = routine_20(c, &(v148_6), &(v146_7_tail).make_space(), &(*s1));
              compose(&(v147_5),&(v148_7))
            };
            drop(v147_5);
            let v147_9: Space = intersect(&(*CONSTANT_2),&(v147_2));
            drop(v147_2);
            let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
            drop(v147_9);
            let v147_12: Space = if (v147_10).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v146_6),&(v146_7_head));
              let v149_11: Space = routine_21(c, &(v149_6), &(v146_7_tail).make_space(), &(*s1));
              drop(v149_6);
              compose(&(v147_10),&(v149_11))
            };
            drop(v147_10);
            let v147_13: Space = unite(&(v147_8),&(v147_12));
            v146_7.join_into((v147_13).clone());
            }
            v146_7_cursor.ascend(1);
          }
          drop(v146_7_cursor);
          compose(&(v145_5),&(v146_7))
        };
        drop(v145_5);
        let v145_9: Space = intersect(&(*CONSTANT_2),&(v145_2));
        drop(v145_2);
        let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
        drop(v145_9);
        let v145_12: Space = if (v145_10).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v144_6),&(v144_11_head));
          let mut v150_11 = Space::new();
          let mut v150_11_cursor = (v144_11_tail).read_zipper();
          for v150_11_byte in v150_11_cursor.child_mask().iter() {
            v150_11_cursor.descend_to_byte(v150_11_byte);
            {
            let v150_11_tail = v150_11_cursor.fork_read_zipper();
            let v150_11_head = Path::from_slice(&[v150_11_byte]);
            let v151_2: Space = singleton(&(v150_11_head));
            let v151_3: Space = intersect(&(*CONSTANT_2),&(v151_2));
            let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
            drop(v151_3);
            let v151_5: Space = subtract(&(*CONSTANT_1),&(v151_4));
            drop(v151_4);
            let v151_7: Space = if (v151_5).is_empty() { Space::new() } else {
              let v152_6: Space = routine_4(c, &(v150_11_head), &(v150_6), &(v150_11_tail).make_space(), &(*s1));
              compose(&(v151_5),&(v152_6))
            };
            drop(v151_5);
            let v151_8: Space = intersect(&(*CONSTANT_2),&(v151_2));
            drop(v151_2);
            let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
            drop(v151_8);
            let v151_11: Space = if (v151_9).is_empty() { Space::new() } else {
              let v153_10: Space = routine_5(c, &(v150_11_head), &(v150_6), &(v150_11_tail).make_space(), &(*s1));
              compose(&(v151_9),&(v153_10))
            };
            drop(v151_9);
            let v151_12: Space = unite(&(v151_7),&(v151_11));
            v150_11.join_into((v151_12).clone());
            }
            v150_11_cursor.ascend(1);
          }
          drop(v150_11_cursor);
          drop(v150_6);
          compose(&(v145_10),&(v150_11))
        };
        drop(v145_10);
        let v145_13: Space = unite(&(v145_8),&(v145_12));
        v144_11.join_into((v145_13).clone());
        }
        v144_11_cursor.ascend(1);
      }
      drop(v144_11_cursor);
      drop(v144_6);
      compose(&(v133_10),&(v144_11))
    };
    drop(v133_10);
    let v133_13: Space = unite(&(v133_8),&(v133_12));
    v132_24.join_into((v133_13).clone());
    }
    v132_24_cursor.ascend(1);
  }
  drop(v132_24_cursor);
  (v132_24).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v154_24 = Space::new();
  let mut v154_24_cursor = (*s0).read_zipper();
  for v154_24_byte in v154_24_cursor.child_mask().iter() {
    v154_24_cursor.descend_to_byte(v154_24_byte);
    {
    let v154_24_tail = v154_24_cursor.fork_read_zipper();
    let v154_24_head = Path::from_slice(&[v154_24_byte]);
    let v155_2: Space = singleton(&(v154_24_head));
    let v155_3: Space = intersect(&(*CONSTANT_2),&(v155_2));
    let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = subtract(&(*CONSTANT_1),&(v155_4));
    drop(v155_4);
    let v155_8: Space = if (v155_5).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&(v154_24_head));
      let mut v156_7 = Space::new();
      let mut v156_7_cursor = (v154_24_tail).read_zipper();
      for v156_7_byte in v156_7_cursor.child_mask().iter() {
        v156_7_cursor.descend_to_byte(v156_7_byte);
        {
        let v156_7_tail = v156_7_cursor.fork_read_zipper();
        let v156_7_head = Path::from_slice(&[v156_7_byte]);
        let v157_2: Space = singleton(&(v156_7_head));
        let v157_3: Space = intersect(&(*CONSTANT_2),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_1),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let mut v158_7 = Space::new();
          let mut v158_7_cursor = (v156_7_tail).read_zipper();
          for v158_7_byte in v158_7_cursor.child_mask().iter() {
            v158_7_cursor.descend_to_byte(v158_7_byte);
            {
            let v158_7_tail = v158_7_cursor.fork_read_zipper();
            let v158_7_head = Path::from_slice(&[v158_7_byte]);
            let v159_2: Space = singleton(&(v158_7_head));
            let v159_3: Space = intersect(&(*CONSTANT_2),&(v159_2));
            let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
            drop(v159_3);
            let v159_5: Space = subtract(&(*CONSTANT_1),&(v159_4));
            drop(v159_4);
            let v159_8: Space = if (v159_5).is_empty() { Space::new() } else {
              let v160_6: Path = concat_path(&(v158_6),&(v158_7_head));
              let v160_7: Space = routine_20(c, &(v160_6), &(v158_7_tail).make_space(), &(*s1));
              compose(&(v159_5),&(v160_7))
            };
            drop(v159_5);
            let v159_9: Space = intersect(&(*CONSTANT_2),&(v159_2));
            drop(v159_2);
            let v159_10: Space = if has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
            drop(v159_9);
            let v159_12: Space = if (v159_10).is_empty() { Space::new() } else {
              let v161_6: Path = concat_path(&(v158_6),&(v158_7_head));
              let v161_11: Space = routine_21(c, &(v161_6), &(v158_7_tail).make_space(), &(*s1));
              drop(v161_6);
              compose(&(v159_10),&(v161_11))
            };
            drop(v159_10);
            let v159_13: Space = unite(&(v159_8),&(v159_12));
            v158_7.join_into((v159_13).clone());
            }
            v158_7_cursor.ascend(1);
          }
          drop(v158_7_cursor);
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_2),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let mut v162_11 = Space::new();
          let mut v162_11_cursor = (v156_7_tail).read_zipper();
          for v162_11_byte in v162_11_cursor.child_mask().iter() {
            v162_11_cursor.descend_to_byte(v162_11_byte);
            {
            let v162_11_tail = v162_11_cursor.fork_read_zipper();
            let v162_11_head = Path::from_slice(&[v162_11_byte]);
            let v163_2: Space = singleton(&(v162_11_head));
            let v163_3: Space = intersect(&(*CONSTANT_2),&(v163_2));
            let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
            drop(v163_3);
            let v163_5: Space = subtract(&(*CONSTANT_1),&(v163_4));
            drop(v163_4);
            let v163_8: Space = if (v163_5).is_empty() { Space::new() } else {
              let v164_6: Path = concat_path(&(v162_6),&(v162_11_head));
              let v164_7: Space = routine_20(c, &(v164_6), &(v162_11_tail).make_space(), &(*s1));
              compose(&(v163_5),&(v164_7))
            };
            drop(v163_5);
            let v163_9: Space = intersect(&(*CONSTANT_2),&(v163_2));
            drop(v163_2);
            let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
            drop(v163_9);
            let v163_12: Space = if (v163_10).is_empty() { Space::new() } else {
              let v165_6: Path = concat_path(&(v162_6),&(v162_11_head));
              let v165_11: Space = routine_3(c, &(v165_6), &(v162_11_tail).make_space(), &(*s1));
              drop(v165_6);
              compose(&(v163_10),&(v165_11))
            };
            drop(v163_10);
            let v163_13: Space = unite(&(v163_8),&(v163_12));
            v162_11.join_into((v163_13).clone());
            }
            v162_11_cursor.ascend(1);
          }
          drop(v162_11_cursor);
          drop(v162_6);
          compose(&(v157_10),&(v162_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        v156_7.join_into((v157_13).clone());
        }
        v156_7_cursor.ascend(1);
      }
      drop(v156_7_cursor);
      compose(&(v155_5),&(v156_7))
    };
    drop(v155_5);
    let v155_9: Space = intersect(&(*CONSTANT_2),&(v155_2));
    drop(v155_2);
    let v155_10: Space = if has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
    drop(v155_9);
    let v155_12: Space = if (v155_10).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&(v154_24_head));
      let mut v166_11 = Space::new();
      let mut v166_11_cursor = (v154_24_tail).read_zipper();
      for v166_11_byte in v166_11_cursor.child_mask().iter() {
        v166_11_cursor.descend_to_byte(v166_11_byte);
        {
        let v166_11_tail = v166_11_cursor.fork_read_zipper();
        let v166_11_head = Path::from_slice(&[v166_11_byte]);
        let v167_2: Space = singleton(&(v166_11_head));
        let v167_3: Space = intersect(&(*CONSTANT_2),&(v167_2));
        let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = subtract(&(*CONSTANT_1),&(v167_4));
        drop(v167_4);
        let v167_7: Space = if (v167_5).is_empty() { Space::new() } else {
          let mut v168_6 = Space::new();
          let mut v168_6_cursor = (v166_11_tail).read_zipper();
          for v168_6_byte in v168_6_cursor.child_mask().iter() {
            v168_6_cursor.descend_to_byte(v168_6_byte);
            {
            let v168_6_tail = v168_6_cursor.fork_read_zipper();
            let v168_6_head = Path::from_slice(&[v168_6_byte]);
            let v169_2: Space = singleton(&(v168_6_head));
            let v169_3: Space = intersect(&(*CONSTANT_2),&(v169_2));
            let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = subtract(&(*CONSTANT_1),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (v169_5).is_empty() { Space::new() } else {
              let v170_6: Path = concat_path(&(v166_11_head),&(v168_6_head));
              let v170_7: Space = routine_8(c, &(v170_6), &(v166_6), &(v168_6_tail).make_space(), &(*s1));
              compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = intersect(&(*CONSTANT_2),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (v169_10).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v166_11_head),&(v168_6_head));
              let v171_11: Space = routine_9(c, &(v171_6), &(v166_6), &(v168_6_tail).make_space(), &(*s1));
              drop(v171_6);
              compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = unite(&(v169_8),&(v169_12));
            v168_6.join_into((v169_13).clone());
            }
            v168_6_cursor.ascend(1);
          }
          drop(v168_6_cursor);
          compose(&(v167_5),&(v168_6))
        };
        drop(v167_5);
        let v167_8: Space = intersect(&(*CONSTANT_2),&(v167_2));
        drop(v167_2);
        let v167_9: Space = if has_head(&(v167_8)) { singleton(&[]) } else { Space::new() };
        drop(v167_8);
        let v167_11: Space = if (v167_9).is_empty() { Space::new() } else {
          let mut v172_10 = Space::new();
          let mut v172_10_cursor = (v166_11_tail).read_zipper();
          for v172_10_byte in v172_10_cursor.child_mask().iter() {
            v172_10_cursor.descend_to_byte(v172_10_byte);
            {
            let v172_10_tail = v172_10_cursor.fork_read_zipper();
            let v172_10_head = Path::from_slice(&[v172_10_byte]);
            let v173_2: Space = singleton(&(v172_10_head));
            let v173_3: Space = intersect(&(*CONSTANT_2),&(v173_2));
            let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
            drop(v173_3);
            let v173_5: Space = subtract(&(*CONSTANT_1),&(v173_4));
            drop(v173_4);
            let v173_8: Space = if (v173_5).is_empty() { Space::new() } else {
              let v174_6: Path = concat_path(&(v166_11_head),&(v172_10_head));
              let v174_7: Space = routine_8(c, &(v174_6), &(v166_6), &(v172_10_tail).make_space(), &(*s1));
              compose(&(v173_5),&(v174_7))
            };
            drop(v173_5);
            let v173_9: Space = intersect(&(*CONSTANT_2),&(v173_2));
            drop(v173_2);
            let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
            drop(v173_9);
            let v173_12: Space = if (v173_10).is_empty() { Space::new() } else {
              let v175_6: Path = concat_path(&(v166_11_head),&(v172_10_head));
              let v175_11: Space = routine_10(c, &(v175_6), &(v166_6), &(v172_10_tail).make_space(), &(*s1));
              drop(v175_6);
              compose(&(v173_10),&(v175_11))
            };
            drop(v173_10);
            let v173_13: Space = unite(&(v173_8),&(v173_12));
            v172_10.join_into((v173_13).clone());
            }
            v172_10_cursor.ascend(1);
          }
          drop(v172_10_cursor);
          compose(&(v167_9),&(v172_10))
        };
        drop(v167_9);
        let v167_12: Space = unite(&(v167_7),&(v167_11));
        v166_11.join_into((v167_12).clone());
        }
        v166_11_cursor.ascend(1);
      }
      drop(v166_11_cursor);
      drop(v166_6);
      compose(&(v155_10),&(v166_11))
    };
    drop(v155_10);
    let v155_13: Space = unite(&(v155_8),&(v155_12));
    v154_24.join_into((v155_13).clone());
    }
    v154_24_cursor.ascend(1);
  }
  drop(v154_24_cursor);
  (v154_24).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v176_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v176_21: Space = unwrap(&(v176_20),&(*p0));
  drop(v176_20);
  let mut v176_28 = Space::new();
  let mut v176_28_cursor = (*s0).read_zipper();
  for v176_28_byte in v176_28_cursor.child_mask().iter() {
    v176_28_cursor.descend_to_byte(v176_28_byte);
    {
    let v176_28_tail = v176_28_cursor.fork_read_zipper();
    let v176_28_head = Path::from_slice(&[v176_28_byte]);
    let v177_2: Space = singleton(&(v176_28_head));
    let v177_3: Space = intersect(&(*CONSTANT_2),&(v177_2));
    let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
    drop(v177_3);
    let v177_5: Space = subtract(&(*CONSTANT_1),&(v177_4));
    drop(v177_4);
    let v177_8: Space = if (v177_5).is_empty() { Space::new() } else {
      let v178_6: Path = concat_path(&(*p0),&(v176_28_head));
      let mut v178_7 = Space::new();
      let mut v178_7_cursor = (v176_28_tail).read_zipper();
      for v178_7_byte in v178_7_cursor.child_mask().iter() {
        v178_7_cursor.descend_to_byte(v178_7_byte);
        {
        let v178_7_tail = v178_7_cursor.fork_read_zipper();
        let v178_7_head = Path::from_slice(&[v178_7_byte]);
        let v179_2: Space = singleton(&(v178_7_head));
        let v179_3: Space = intersect(&(*CONSTANT_2),&(v179_2));
        let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
        drop(v179_3);
        let v179_5: Space = subtract(&(*CONSTANT_1),&(v179_4));
        drop(v179_4);
        let v179_8: Space = if (v179_5).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v178_6),&(v178_7_head));
          let mut v180_7 = Space::new();
          let mut v180_7_cursor = (v178_7_tail).read_zipper();
          for v180_7_byte in v180_7_cursor.child_mask().iter() {
            v180_7_cursor.descend_to_byte(v180_7_byte);
            {
            let v180_7_tail = v180_7_cursor.fork_read_zipper();
            let v180_7_head = Path::from_slice(&[v180_7_byte]);
            let v181_2: Space = singleton(&(v180_7_head));
            let v181_3: Space = intersect(&(*CONSTANT_2),&(v181_2));
            let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
            drop(v181_3);
            let v181_5: Space = subtract(&(*CONSTANT_1),&(v181_4));
            drop(v181_4);
            let v181_8: Space = if (v181_5).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v180_6),&(v180_7_head));
              let v182_7: Space = routine_22(c, &(v182_6), &(*p1), &(v180_7_tail).make_space(), &(*s1));
              compose(&(v181_5),&(v182_7))
            };
            drop(v181_5);
            let v181_9: Space = intersect(&(*CONSTANT_2),&(v181_2));
            drop(v181_2);
            let v181_10: Space = if has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
            drop(v181_9);
            let v181_12: Space = if (v181_10).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v180_6),&(v180_7_head));
              let v183_11: Space = routine_23(c, &(v183_6), &(*p1), &(v180_7_tail).make_space(), &(*s1));
              drop(v183_6);
              compose(&(v181_10),&(v183_11))
            };
            drop(v181_10);
            let v181_13: Space = unite(&(v181_8),&(v181_12));
            v180_7.join_into((v181_13).clone());
            }
            v180_7_cursor.ascend(1);
          }
          drop(v180_7_cursor);
          compose(&(v179_5),&(v180_7))
        };
        drop(v179_5);
        let v179_9: Space = intersect(&(*CONSTANT_2),&(v179_2));
        drop(v179_2);
        let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
        drop(v179_9);
        let v179_12: Space = if (v179_10).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v178_6),&(v178_7_head));
          let mut v184_11 = Space::new();
          let mut v184_11_cursor = (v178_7_tail).read_zipper();
          for v184_11_byte in v184_11_cursor.child_mask().iter() {
            v184_11_cursor.descend_to_byte(v184_11_byte);
            {
            let v184_11_tail = v184_11_cursor.fork_read_zipper();
            let v184_11_head = Path::from_slice(&[v184_11_byte]);
            let v185_2: Space = singleton(&(v184_11_head));
            let v185_3: Space = intersect(&(*CONSTANT_2),&(v185_2));
            let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
            drop(v185_3);
            let v185_5: Space = subtract(&(*CONSTANT_1),&(v185_4));
            drop(v185_4);
            let v185_8: Space = if (v185_5).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v184_6),&(v184_11_head));
              let v186_7: Space = routine_22(c, &(v186_6), &(*p1), &(v184_11_tail).make_space(), &(*s1));
              compose(&(v185_5),&(v186_7))
            };
            drop(v185_5);
            let v185_9: Space = intersect(&(*CONSTANT_2),&(v185_2));
            drop(v185_2);
            let v185_10: Space = if has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
            drop(v185_9);
            let v185_12: Space = if (v185_10).is_empty() { Space::new() } else {
              let v187_6: Path = concat_path(&(v184_6),&(v184_11_head));
              let v187_11: Space = routine_10(c, &(v187_6), &(*p1), &(v184_11_tail).make_space(), &(*s1));
              drop(v187_6);
              compose(&(v185_10),&(v187_11))
            };
            drop(v185_10);
            let v185_13: Space = unite(&(v185_8),&(v185_12));
            v184_11.join_into((v185_13).clone());
            }
            v184_11_cursor.ascend(1);
          }
          drop(v184_11_cursor);
          drop(v184_6);
          compose(&(v179_10),&(v184_11))
        };
        drop(v179_10);
        let v179_13: Space = unite(&(v179_8),&(v179_12));
        v178_7.join_into((v179_13).clone());
        }
        v178_7_cursor.ascend(1);
      }
      drop(v178_7_cursor);
      compose(&(v177_5),&(v178_7))
    };
    drop(v177_5);
    let v177_9: Space = intersect(&(*CONSTANT_2),&(v177_2));
    drop(v177_2);
    let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
    drop(v177_9);
    let v177_13: Space = if (v177_10).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&(v176_28_head));
      let v188_11: Space = unwrap(&(v176_21),&(v176_28_head));
      let mut v188_12 = Space::new();
      let mut v188_12_cursor = (v176_28_tail).read_zipper();
      for v188_12_byte in v188_12_cursor.child_mask().iter() {
        v188_12_cursor.descend_to_byte(v188_12_byte);
        {
        let v188_12_tail = v188_12_cursor.fork_read_zipper();
        let v188_12_head = Path::from_slice(&[v188_12_byte]);
        let v189_2: Space = singleton(&(v188_12_head));
        let v189_3: Space = intersect(&(*CONSTANT_2),&(v189_2));
        let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = subtract(&(*CONSTANT_1),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (v189_5).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&(v188_12_head));
          let mut v190_7 = Space::new();
          let mut v190_7_cursor = (v188_12_tail).read_zipper();
          for v190_7_byte in v190_7_cursor.child_mask().iter() {
            v190_7_cursor.descend_to_byte(v190_7_byte);
            {
            let v190_7_tail = v190_7_cursor.fork_read_zipper();
            let v190_7_head = Path::from_slice(&[v190_7_byte]);
            let v191_2: Space = singleton(&(v190_7_head));
            let v191_3: Space = intersect(&(*CONSTANT_2),&(v191_2));
            let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = subtract(&(*CONSTANT_1),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (v191_5).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&(v190_7_head));
              let v192_7: Space = routine_22(c, &(v192_6), &(*p1), &(v190_7_tail).make_space(), &(*s1));
              compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = intersect(&(*CONSTANT_2),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (v191_10).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&(v190_7_head));
              let v193_11: Space = routine_23(c, &(v193_6), &(*p1), &(v190_7_tail).make_space(), &(*s1));
              drop(v193_6);
              compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = unite(&(v191_8),&(v191_12));
            v190_7.join_into((v191_13).clone());
            }
            v190_7_cursor.ascend(1);
          }
          drop(v190_7_cursor);
          drop(v190_6);
          compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = intersect(&(*CONSTANT_2),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_13: Space = if (v189_10).is_empty() { Space::new() } else {
          let v194_11: Space = unwrap(&(v188_11),&(v188_12_head));
          let mut v194_12 = Space::new();
          let mut v194_12_cursor = (v194_11).read_zipper();
          for v194_12_byte in v194_12_cursor.child_mask().iter() {
            v194_12_cursor.descend_to_byte(v194_12_byte);
            {
            let v194_12_tail = v194_12_cursor.fork_read_zipper();
            let v194_12_head = Path::from_slice(&[v194_12_byte]);
            let v195_2: Space = singleton(&(v194_12_head));
            let v195_3: Space = intersect(&(*CONSTANT_2),&(v195_2));
            let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
            drop(v195_3);
            let v195_5: Space = subtract(&(*CONSTANT_1),&(v195_4));
            drop(v195_4);
            let v195_7: Space = if (v195_5).is_empty() { Space::new() } else {
              let v196_6: Space = routine_13(c, &(v194_12_head), &(*p1), &(v194_12_tail).make_space());
              compose(&(v195_5),&(v196_6))
            };
            drop(v195_5);
            let v195_8: Space = intersect(&(*CONSTANT_2),&(v195_2));
            drop(v195_2);
            let v195_9: Space = if has_head(&(v195_8)) { singleton(&[]) } else { Space::new() };
            drop(v195_8);
            let v195_11: Space = if (v195_9).is_empty() { Space::new() } else {
              let v197_10: Space = routine_14(c, &(v194_12_head), &(*p1), &(v194_12_tail).make_space());
              compose(&(v195_9),&(v197_10))
            };
            drop(v195_9);
            let v195_12: Space = unite(&(v195_7),&(v195_11));
            v194_12.join_into((v195_12).clone());
            }
            v194_12_cursor.ascend(1);
          }
          drop(v194_12_cursor);
          drop(v194_11);
          compose(&(v189_10),&(v194_12))
        };
        drop(v189_10);
        let v189_14: Space = unite(&(v189_8),&(v189_13));
        v188_12.join_into((v189_14).clone());
        }
        v188_12_cursor.ascend(1);
      }
      drop(v188_12_cursor);
      drop(v188_6);
      drop(v188_11);
      compose(&(v177_10),&(v188_12))
    };
    drop(v177_10);
    let v177_14: Space = unite(&(v177_8),&(v177_13));
    v176_28.join_into((v177_14).clone());
    }
    v176_28_cursor.ascend(1);
  }
  drop(v176_28_cursor);
  drop(v176_21);
  (v176_28).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v198_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v198_9: Space = unwrap(&(v198_8),&(*p0));
  drop(v198_8);
  let mut v198_28 = Space::new();
  let mut v198_28_cursor = (*s0).read_zipper();
  for v198_28_byte in v198_28_cursor.child_mask().iter() {
    v198_28_cursor.descend_to_byte(v198_28_byte);
    {
    let v198_28_tail = v198_28_cursor.fork_read_zipper();
    let v198_28_head = Path::from_slice(&[v198_28_byte]);
    let v199_2: Space = singleton(&(v198_28_head));
    let v199_3: Space = intersect(&(*CONSTANT_2),&(v199_2));
    let v199_4: Space = if has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
    drop(v199_3);
    let v199_5: Space = subtract(&(*CONSTANT_1),&(v199_4));
    drop(v199_4);
    let v199_8: Space = if (v199_5).is_empty() { Space::new() } else {
      let v200_6: Path = concat_path(&(*p0),&(v198_28_head));
      let mut v200_7 = Space::new();
      let mut v200_7_cursor = (v198_28_tail).read_zipper();
      for v200_7_byte in v200_7_cursor.child_mask().iter() {
        v200_7_cursor.descend_to_byte(v200_7_byte);
        {
        let v200_7_tail = v200_7_cursor.fork_read_zipper();
        let v200_7_head = Path::from_slice(&[v200_7_byte]);
        let v201_2: Space = singleton(&(v200_7_head));
        let v201_3: Space = intersect(&(*CONSTANT_2),&(v201_2));
        let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
        drop(v201_3);
        let v201_5: Space = subtract(&(*CONSTANT_1),&(v201_4));
        drop(v201_4);
        let v201_8: Space = if (v201_5).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v200_6),&(v200_7_head));
          let mut v202_7 = Space::new();
          let mut v202_7_cursor = (v200_7_tail).read_zipper();
          for v202_7_byte in v202_7_cursor.child_mask().iter() {
            v202_7_cursor.descend_to_byte(v202_7_byte);
            {
            let v202_7_tail = v202_7_cursor.fork_read_zipper();
            let v202_7_head = Path::from_slice(&[v202_7_byte]);
            let v203_2: Space = singleton(&(v202_7_head));
            let v203_3: Space = intersect(&(*CONSTANT_2),&(v203_2));
            let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
            drop(v203_3);
            let v203_5: Space = subtract(&(*CONSTANT_1),&(v203_4));
            drop(v203_4);
            let v203_8: Space = if (v203_5).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v202_6),&(v202_7_head));
              let v204_7: Space = routine_22(c, &(v204_6), &(*p1), &(v202_7_tail).make_space(), &(*s1));
              compose(&(v203_5),&(v204_7))
            };
            drop(v203_5);
            let v203_9: Space = intersect(&(*CONSTANT_2),&(v203_2));
            drop(v203_2);
            let v203_10: Space = if has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
            drop(v203_9);
            let v203_12: Space = if (v203_10).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v202_6),&(v202_7_head));
              let v205_11: Space = routine_23(c, &(v205_6), &(*p1), &(v202_7_tail).make_space(), &(*s1));
              drop(v205_6);
              compose(&(v203_10),&(v205_11))
            };
            drop(v203_10);
            let v203_13: Space = unite(&(v203_8),&(v203_12));
            v202_7.join_into((v203_13).clone());
            }
            v202_7_cursor.ascend(1);
          }
          drop(v202_7_cursor);
          compose(&(v201_5),&(v202_7))
        };
        drop(v201_5);
        let v201_9: Space = intersect(&(*CONSTANT_2),&(v201_2));
        drop(v201_2);
        let v201_10: Space = if has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
        drop(v201_9);
        let v201_12: Space = if (v201_10).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v200_6),&(v200_7_head));
          let mut v206_11 = Space::new();
          let mut v206_11_cursor = (v200_7_tail).read_zipper();
          for v206_11_byte in v206_11_cursor.child_mask().iter() {
            v206_11_cursor.descend_to_byte(v206_11_byte);
            {
            let v206_11_tail = v206_11_cursor.fork_read_zipper();
            let v206_11_head = Path::from_slice(&[v206_11_byte]);
            let v207_2: Space = singleton(&(v206_11_head));
            let v207_3: Space = intersect(&(*CONSTANT_2),&(v207_2));
            let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
            drop(v207_3);
            let v207_5: Space = subtract(&(*CONSTANT_1),&(v207_4));
            drop(v207_4);
            let v207_8: Space = if (v207_5).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v206_6),&(v206_11_head));
              let v208_7: Space = routine_22(c, &(v208_6), &(*p1), &(v206_11_tail).make_space(), &(*s1));
              compose(&(v207_5),&(v208_7))
            };
            drop(v207_5);
            let v207_9: Space = intersect(&(*CONSTANT_2),&(v207_2));
            drop(v207_2);
            let v207_10: Space = if has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
            drop(v207_9);
            let v207_12: Space = if (v207_10).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v206_6),&(v206_11_head));
              let v209_11: Space = routine_10(c, &(v209_6), &(*p1), &(v206_11_tail).make_space(), &(*s1));
              drop(v209_6);
              compose(&(v207_10),&(v209_11))
            };
            drop(v207_10);
            let v207_13: Space = unite(&(v207_8),&(v207_12));
            v206_11.join_into((v207_13).clone());
            }
            v206_11_cursor.ascend(1);
          }
          drop(v206_11_cursor);
          drop(v206_6);
          compose(&(v201_10),&(v206_11))
        };
        drop(v201_10);
        let v201_13: Space = unite(&(v201_8),&(v201_12));
        v200_7.join_into((v201_13).clone());
        }
        v200_7_cursor.ascend(1);
      }
      drop(v200_7_cursor);
      drop(v200_6);
      compose(&(v199_5),&(v200_7))
    };
    drop(v199_5);
    let v199_9: Space = intersect(&(*CONSTANT_2),&(v199_2));
    drop(v199_2);
    let v199_10: Space = if has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
    drop(v199_9);
    let v199_13: Space = if (v199_10).is_empty() { Space::new() } else {
      let v210_11: Space = unwrap(&(v198_9),&(v198_28_head));
      let mut v210_12 = Space::new();
      let mut v210_12_cursor = (v210_11).read_zipper();
      for v210_12_byte in v210_12_cursor.child_mask().iter() {
        v210_12_cursor.descend_to_byte(v210_12_byte);
        {
        let v210_12_tail = v210_12_cursor.fork_read_zipper();
        let v210_12_head = Path::from_slice(&[v210_12_byte]);
        let v211_2: Space = singleton(&(v210_12_head));
        let v211_3: Space = intersect(&(*CONSTANT_2),&(v211_2));
        let v211_4: Space = if has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
        drop(v211_3);
        let v211_5: Space = subtract(&(*CONSTANT_1),&(v211_4));
        drop(v211_4);
        let v211_7: Space = if (v211_5).is_empty() { Space::new() } else {
          let mut v212_6 = Space::new();
          let mut v212_6_cursor = (v210_12_tail).read_zipper();
          for v212_6_byte in v212_6_cursor.child_mask().iter() {
            v212_6_cursor.descend_to_byte(v212_6_byte);
            {
            let v212_6_tail = v212_6_cursor.fork_read_zipper();
            let v212_6_head = Path::from_slice(&[v212_6_byte]);
            let v213_2: Space = singleton(&(v212_6_head));
            let v213_3: Space = intersect(&(*CONSTANT_2),&(v213_2));
            let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
            drop(v213_3);
            let v213_5: Space = subtract(&(*CONSTANT_1),&(v213_4));
            drop(v213_4);
            let v213_8: Space = if (v213_5).is_empty() { Space::new() } else {
              let v214_6: Path = concat_path(&(v210_12_head),&(v212_6_head));
              let v214_7: Space = routine_17(c, &(v214_6), &(*p1), &(v212_6_tail).make_space());
              compose(&(v213_5),&(v214_7))
            };
            drop(v213_5);
            let v213_9: Space = intersect(&(*CONSTANT_2),&(v213_2));
            drop(v213_2);
            let v213_10: Space = if has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
            drop(v213_9);
            let v213_12: Space = if (v213_10).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v210_12_head),&(v212_6_head));
              let v215_11: Space = routine_18(c, &(v215_6), &(*p1), &(v212_6_tail).make_space());
              drop(v215_6);
              compose(&(v213_10),&(v215_11))
            };
            drop(v213_10);
            let v213_13: Space = unite(&(v213_8),&(v213_12));
            v212_6.join_into((v213_13).clone());
            }
            v212_6_cursor.ascend(1);
          }
          drop(v212_6_cursor);
          compose(&(v211_5),&(v212_6))
        };
        drop(v211_5);
        let v211_8: Space = intersect(&(*CONSTANT_2),&(v211_2));
        drop(v211_2);
        let v211_9: Space = if has_head(&(v211_8)) { singleton(&[]) } else { Space::new() };
        drop(v211_8);
        let v211_11: Space = if (v211_9).is_empty() { Space::new() } else {
          let mut v216_10 = Space::new();
          let mut v216_10_cursor = (v210_12_tail).read_zipper();
          for v216_10_byte in v216_10_cursor.child_mask().iter() {
            v216_10_cursor.descend_to_byte(v216_10_byte);
            {
            let v216_10_tail = v216_10_cursor.fork_read_zipper();
            let v216_10_head = Path::from_slice(&[v216_10_byte]);
            let v217_2: Space = singleton(&(v216_10_head));
            let v217_3: Space = intersect(&(*CONSTANT_2),&(v217_2));
            let v217_4: Space = if has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
            drop(v217_3);
            let v217_5: Space = subtract(&(*CONSTANT_1),&(v217_4));
            drop(v217_4);
            let v217_8: Space = if (v217_5).is_empty() { Space::new() } else {
              let v218_6: Path = concat_path(&(v210_12_head),&(v216_10_head));
              let v218_7: Space = routine_17(c, &(v218_6), &(*p1), &(v216_10_tail).make_space());
              compose(&(v217_5),&(v218_7))
            };
            drop(v217_5);
            let v217_9: Space = intersect(&(*CONSTANT_2),&(v217_2));
            drop(v217_2);
            let v217_10: Space = if has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
            drop(v217_9);
            let v217_12: Space = if (v217_10).is_empty() { Space::new() } else {
              let v219_6: Path = concat_path(&(v210_12_head),&(v216_10_head));
              let v219_11: Space = routine_19(c, &(v219_6), &(*p1), &(v216_10_tail).make_space());
              drop(v219_6);
              compose(&(v217_10),&(v219_11))
            };
            drop(v217_10);
            let v217_13: Space = unite(&(v217_8),&(v217_12));
            v216_10.join_into((v217_13).clone());
            }
            v216_10_cursor.ascend(1);
          }
          drop(v216_10_cursor);
          compose(&(v211_9),&(v216_10))
        };
        drop(v211_9);
        let v211_12: Space = unite(&(v211_7),&(v211_11));
        v210_12.join_into((v211_12).clone());
        }
        v210_12_cursor.ascend(1);
      }
      drop(v210_12_cursor);
      drop(v210_11);
      compose(&(v199_10),&(v210_12))
    };
    drop(v199_10);
    let v199_14: Space = unite(&(v199_8),&(v199_13));
    v198_28.join_into((v199_14).clone());
    }
    v198_28_cursor.ascend(1);
  }
  drop(v198_28_cursor);
  drop(v198_9);
  (v198_28).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v220_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v220_6: Space = unwrap(&(v220_5),&(*p0));
  drop(v220_5);
  let mut v220_25 = Space::new();
  let mut v220_25_cursor = (v220_6).read_zipper();
  for v220_25_byte in v220_25_cursor.child_mask().iter() {
    v220_25_cursor.descend_to_byte(v220_25_byte);
    {
    let v220_25_tail = v220_25_cursor.fork_read_zipper();
    let v220_25_head = Path::from_slice(&[v220_25_byte]);
    let v221_2: Space = singleton(&(v220_25_head));
    let v221_3: Space = intersect(&(*CONSTANT_2),&(v221_2));
    let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
    drop(v221_3);
    let v221_5: Space = subtract(&(*CONSTANT_1),&(v221_4));
    drop(v221_4);
    let v221_7: Space = if (v221_5).is_empty() { Space::new() } else {
      let mut v222_6 = Space::new();
      let mut v222_6_cursor = (v220_25_tail).read_zipper();
      for v222_6_byte in v222_6_cursor.child_mask().iter() {
        v222_6_cursor.descend_to_byte(v222_6_byte);
        {
        let v222_6_tail = v222_6_cursor.fork_read_zipper();
        let v222_6_head = Path::from_slice(&[v222_6_byte]);
        let v223_2: Space = singleton(&(v222_6_head));
        let v223_3: Space = intersect(&(*CONSTANT_2),&(v223_2));
        let v223_4: Space = if has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = subtract(&(*CONSTANT_1),&(v223_4));
        drop(v223_4);
        let v223_8: Space = if (v223_5).is_empty() { Space::new() } else {
          let v224_6: Path = concat_path(&(v220_25_head),&(v222_6_head));
          let mut v224_7 = Space::new();
          let mut v224_7_cursor = (v222_6_tail).read_zipper();
          for v224_7_byte in v224_7_cursor.child_mask().iter() {
            v224_7_cursor.descend_to_byte(v224_7_byte);
            {
            let v224_7_tail = v224_7_cursor.fork_read_zipper();
            let v224_7_head = Path::from_slice(&[v224_7_byte]);
            let v225_2: Space = singleton(&(v224_7_head));
            let v225_3: Space = intersect(&(*CONSTANT_2),&(v225_2));
            let v225_4: Space = if has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
            drop(v225_3);
            let v225_5: Space = subtract(&(*CONSTANT_1),&(v225_4));
            drop(v225_4);
            let v225_8: Space = if (v225_5).is_empty() { Space::new() } else {
              let v226_6: Path = concat_path(&(v224_6),&(v224_7_head));
              let v226_7: Space = routine_24(c, &(v226_6), &(*p1), &(v224_7_tail).make_space());
              compose(&(v225_5),&(v226_7))
            };
            drop(v225_5);
            let v225_9: Space = intersect(&(*CONSTANT_2),&(v225_2));
            drop(v225_2);
            let v225_10: Space = if has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
            drop(v225_9);
            let v225_12: Space = if (v225_10).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v224_6),&(v224_7_head));
              let v227_11: Space = routine_25(c, &(v227_6), &(*p1), &(v224_7_tail).make_space());
              drop(v227_6);
              compose(&(v225_10),&(v227_11))
            };
            drop(v225_10);
            let v225_13: Space = unite(&(v225_8),&(v225_12));
            v224_7.join_into((v225_13).clone());
            }
            v224_7_cursor.ascend(1);
          }
          drop(v224_7_cursor);
          compose(&(v223_5),&(v224_7))
        };
        drop(v223_5);
        let v223_9: Space = intersect(&(*CONSTANT_2),&(v223_2));
        drop(v223_2);
        let v223_10: Space = if has_head(&(v223_9)) { singleton(&[]) } else { Space::new() };
        drop(v223_9);
        let v223_12: Space = if (v223_10).is_empty() { Space::new() } else {
          let v228_6: Path = concat_path(&(v220_25_head),&(v222_6_head));
          let mut v228_11 = Space::new();
          let mut v228_11_cursor = (v222_6_tail).read_zipper();
          for v228_11_byte in v228_11_cursor.child_mask().iter() {
            v228_11_cursor.descend_to_byte(v228_11_byte);
            {
            let v228_11_tail = v228_11_cursor.fork_read_zipper();
            let v228_11_head = Path::from_slice(&[v228_11_byte]);
            let v229_2: Space = singleton(&(v228_11_head));
            let v229_3: Space = intersect(&(*CONSTANT_2),&(v229_2));
            let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
            drop(v229_3);
            let v229_5: Space = subtract(&(*CONSTANT_1),&(v229_4));
            drop(v229_4);
            let v229_8: Space = if (v229_5).is_empty() { Space::new() } else {
              let v230_6: Path = concat_path(&(v228_6),&(v228_11_head));
              let v230_7: Space = routine_24(c, &(v230_6), &(*p1), &(v228_11_tail).make_space());
              compose(&(v229_5),&(v230_7))
            };
            drop(v229_5);
            let v229_9: Space = intersect(&(*CONSTANT_2),&(v229_2));
            drop(v229_2);
            let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
            drop(v229_9);
            let v229_12: Space = if (v229_10).is_empty() { Space::new() } else {
              let v231_6: Path = concat_path(&(v228_6),&(v228_11_head));
              let v231_11: Space = routine_19(c, &(v231_6), &(*p1), &(v228_11_tail).make_space());
              drop(v231_6);
              compose(&(v229_10),&(v231_11))
            };
            drop(v229_10);
            let v229_13: Space = unite(&(v229_8),&(v229_12));
            v228_11.join_into((v229_13).clone());
            }
            v228_11_cursor.ascend(1);
          }
          drop(v228_11_cursor);
          drop(v228_6);
          compose(&(v223_10),&(v228_11))
        };
        drop(v223_10);
        let v223_13: Space = unite(&(v223_8),&(v223_12));
        v222_6.join_into((v223_13).clone());
        }
        v222_6_cursor.ascend(1);
      }
      drop(v222_6_cursor);
      compose(&(v221_5),&(v222_6))
    };
    drop(v221_5);
    let v221_8: Space = intersect(&(*CONSTANT_2),&(v221_2));
    drop(v221_2);
    let v221_9: Space = if has_head(&(v221_8)) { singleton(&[]) } else { Space::new() };
    drop(v221_8);
    let v221_11: Space = if (v221_9).is_empty() { Space::new() } else {
      let mut v232_10 = Space::new();
      let mut v232_10_cursor = (v220_25_tail).read_zipper();
      for v232_10_byte in v232_10_cursor.child_mask().iter() {
        v232_10_cursor.descend_to_byte(v232_10_byte);
        {
        let v232_10_tail = v232_10_cursor.fork_read_zipper();
        let v232_10_head = Path::from_slice(&[v232_10_byte]);
        let v233_2: Space = singleton(&(v232_10_head));
        let v233_3: Space = intersect(&(*CONSTANT_2),&(v233_2));
        let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = subtract(&(*CONSTANT_1),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (v233_5).is_empty() { Space::new() } else {
          let v234_6: Path = concat_path(&(v220_25_head),&(v232_10_head));
          let mut v234_7 = Space::new();
          let mut v234_7_cursor = (v232_10_tail).read_zipper();
          for v234_7_byte in v234_7_cursor.child_mask().iter() {
            v234_7_cursor.descend_to_byte(v234_7_byte);
            {
            let v234_7_tail = v234_7_cursor.fork_read_zipper();
            let v234_7_head = Path::from_slice(&[v234_7_byte]);
            let v235_2: Space = singleton(&(v234_7_head));
            let v235_3: Space = intersect(&(*CONSTANT_2),&(v235_2));
            let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
            drop(v235_3);
            let v235_5: Space = subtract(&(*CONSTANT_1),&(v235_4));
            drop(v235_4);
            let v235_8: Space = if (v235_5).is_empty() { Space::new() } else {
              let v236_6: Path = concat_path(&(v234_6),&(v234_7_head));
              let v236_7: Space = routine_24(c, &(v236_6), &(*p1), &(v234_7_tail).make_space());
              compose(&(v235_5),&(v236_7))
            };
            drop(v235_5);
            let v235_9: Space = intersect(&(*CONSTANT_2),&(v235_2));
            drop(v235_2);
            let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
            drop(v235_9);
            let v235_12: Space = if (v235_10).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v234_6),&(v234_7_head));
              let v237_11: Space = routine_25(c, &(v237_6), &(*p1), &(v234_7_tail).make_space());
              drop(v237_6);
              compose(&(v235_10),&(v237_11))
            };
            drop(v235_10);
            let v235_13: Space = unite(&(v235_8),&(v235_12));
            v234_7.join_into((v235_13).clone());
            }
            v234_7_cursor.ascend(1);
          }
          drop(v234_7_cursor);
          compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = intersect(&(*CONSTANT_2),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_11: Space = compose(&(v233_10),&(v232_10_tail));
        drop(v233_10);
        let v238_6: Path = concat_path(&(v220_25_head),&(v232_10_head));
        let v233_12: Space = wrap(&(v233_11),&(v238_6));
        drop(v233_11);
        let v233_13: Space = wrap(&(v233_12),&(*p1));
        drop(v233_12);
        let v233_14: Space = unite(&(v233_8),&(v233_13));
        drop(v233_13);
        v232_10.join_into((v233_14).clone());
        }
        v232_10_cursor.ascend(1);
      }
      drop(v232_10_cursor);
      compose(&(v221_9),&(v232_10))
    };
    drop(v221_9);
    let v221_12: Space = unite(&(v221_7),&(v221_11));
    v220_25.join_into((v221_12).clone());
    }
    v220_25_cursor.ascend(1);
  }
  drop(v220_25_cursor);
  drop(v220_6);
  (v220_25).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v239_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v239_21: Space = unwrap(&(v239_20),&(*p0));
  drop(v239_20);
  let mut v239_28 = Space::new();
  let mut v239_28_cursor = (*s0).read_zipper();
  for v239_28_byte in v239_28_cursor.child_mask().iter() {
    v239_28_cursor.descend_to_byte(v239_28_byte);
    {
    let v239_28_tail = v239_28_cursor.fork_read_zipper();
    let v239_28_head = Path::from_slice(&[v239_28_byte]);
    let v240_2: Space = singleton(&(v239_28_head));
    let v240_3: Space = intersect(&(*CONSTANT_2),&(v240_2));
    let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = subtract(&(*CONSTANT_1),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (v240_5).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&(v239_28_head));
      let mut v241_7 = Space::new();
      let mut v241_7_cursor = (v239_28_tail).read_zipper();
      for v241_7_byte in v241_7_cursor.child_mask().iter() {
        v241_7_cursor.descend_to_byte(v241_7_byte);
        {
        let v241_7_tail = v241_7_cursor.fork_read_zipper();
        let v241_7_head = Path::from_slice(&[v241_7_byte]);
        let v242_2: Space = singleton(&(v241_7_head));
        let v242_3: Space = intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (v242_5).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&(v241_7_head));
          let mut v243_7 = Space::new();
          let mut v243_7_cursor = (v241_7_tail).read_zipper();
          for v243_7_byte in v243_7_cursor.child_mask().iter() {
            v243_7_cursor.descend_to_byte(v243_7_byte);
            {
            let v243_7_tail = v243_7_cursor.fork_read_zipper();
            let v243_7_head = Path::from_slice(&[v243_7_byte]);
            let v244_2: Space = singleton(&(v243_7_head));
            let v244_3: Space = intersect(&(*CONSTANT_2),&(v244_2));
            let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = subtract(&(*CONSTANT_1),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (v244_5).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&(v243_7_head));
              let v245_7: Space = routine_26(c, &(v245_6), &(*p1), &(v243_7_tail).make_space(), &(*s1));
              compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = intersect(&(*CONSTANT_2),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (v244_10).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&(v243_7_head));
              let v246_11: Space = routine_27(c, &(v246_6), &(*p1), &(v243_7_tail).make_space(), &(*s1));
              drop(v246_6);
              compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = unite(&(v244_8),&(v244_12));
            v243_7.join_into((v244_13).clone());
            }
            v243_7_cursor.ascend(1);
          }
          drop(v243_7_cursor);
          compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (v242_10).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&(v241_7_head));
          let mut v247_11 = Space::new();
          let mut v247_11_cursor = (v241_7_tail).read_zipper();
          for v247_11_byte in v247_11_cursor.child_mask().iter() {
            v247_11_cursor.descend_to_byte(v247_11_byte);
            {
            let v247_11_tail = v247_11_cursor.fork_read_zipper();
            let v247_11_head = Path::from_slice(&[v247_11_byte]);
            let v248_2: Space = singleton(&(v247_11_head));
            let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
            let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&(v247_11_head));
              let v249_7: Space = routine_26(c, &(v249_6), &(*p1), &(v247_11_tail).make_space(), &(*s1));
              compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&(v247_11_head));
              let v250_11: Space = routine_10(c, &(v250_6), &(*p1), &(v247_11_tail).make_space(), &(*s1));
              drop(v250_6);
              compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = unite(&(v248_8),&(v248_12));
            v247_11.join_into((v248_13).clone());
            }
            v247_11_cursor.ascend(1);
          }
          drop(v247_11_cursor);
          drop(v247_6);
          compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = unite(&(v242_8),&(v242_12));
        v241_7.join_into((v242_13).clone());
        }
        v241_7_cursor.ascend(1);
      }
      drop(v241_7_cursor);
      compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = intersect(&(*CONSTANT_2),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_13: Space = if (v240_10).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&(v239_28_head));
      let v251_11: Space = unwrap(&(v239_21),&(v239_28_head));
      let mut v251_12 = Space::new();
      let mut v251_12_cursor = (v239_28_tail).read_zipper();
      for v251_12_byte in v251_12_cursor.child_mask().iter() {
        v251_12_cursor.descend_to_byte(v251_12_byte);
        {
        let v251_12_tail = v251_12_cursor.fork_read_zipper();
        let v251_12_head = Path::from_slice(&[v251_12_byte]);
        let v252_2: Space = singleton(&(v251_12_head));
        let v252_3: Space = intersect(&(*CONSTANT_2),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_1),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (v252_5).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&(v251_12_head));
          let mut v253_7 = Space::new();
          let mut v253_7_cursor = (v251_12_tail).read_zipper();
          for v253_7_byte in v253_7_cursor.child_mask().iter() {
            v253_7_cursor.descend_to_byte(v253_7_byte);
            {
            let v253_7_tail = v253_7_cursor.fork_read_zipper();
            let v253_7_head = Path::from_slice(&[v253_7_byte]);
            let v254_2: Space = singleton(&(v253_7_head));
            let v254_3: Space = intersect(&(*CONSTANT_2),&(v254_2));
            let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
            drop(v254_3);
            let v254_5: Space = subtract(&(*CONSTANT_1),&(v254_4));
            drop(v254_4);
            let v254_8: Space = if (v254_5).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v253_6),&(v253_7_head));
              let v255_7: Space = routine_26(c, &(v255_6), &(*p1), &(v253_7_tail).make_space(), &(*s1));
              compose(&(v254_5),&(v255_7))
            };
            drop(v254_5);
            let v254_9: Space = intersect(&(*CONSTANT_2),&(v254_2));
            drop(v254_2);
            let v254_10: Space = if has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
            drop(v254_9);
            let v254_12: Space = if (v254_10).is_empty() { Space::new() } else {
              let v256_6: Path = concat_path(&(v253_6),&(v253_7_head));
              let v256_11: Space = routine_27(c, &(v256_6), &(*p1), &(v253_7_tail).make_space(), &(*s1));
              drop(v256_6);
              compose(&(v254_10),&(v256_11))
            };
            drop(v254_10);
            let v254_13: Space = unite(&(v254_8),&(v254_12));
            v253_7.join_into((v254_13).clone());
            }
            v253_7_cursor.ascend(1);
          }
          drop(v253_7_cursor);
          drop(v253_6);
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_2),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_13: Space = if (v252_10).is_empty() { Space::new() } else {
          let v257_11: Space = unwrap(&(v251_11),&(v251_12_head));
          let mut v257_12 = Space::new();
          let mut v257_12_cursor = (v257_11).read_zipper();
          for v257_12_byte in v257_12_cursor.child_mask().iter() {
            v257_12_cursor.descend_to_byte(v257_12_byte);
            {
            let v257_12_tail = v257_12_cursor.fork_read_zipper();
            let v257_12_head = Path::from_slice(&[v257_12_byte]);
            let v258_2: Space = singleton(&(v257_12_head));
            let v258_3: Space = intersect(&(*CONSTANT_2),&(v258_2));
            let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = subtract(&(*CONSTANT_1),&(v258_4));
            drop(v258_4);
            let v258_7: Space = if (v258_5).is_empty() { Space::new() } else {
              let v259_6: Space = routine_13(c, &(v257_12_head), &(*p1), &(v257_12_tail).make_space());
              compose(&(v258_5),&(v259_6))
            };
            drop(v258_5);
            let v258_8: Space = intersect(&(*CONSTANT_2),&(v258_2));
            drop(v258_2);
            let v258_9: Space = if has_head(&(v258_8)) { singleton(&[]) } else { Space::new() };
            drop(v258_8);
            let v258_11: Space = if (v258_9).is_empty() { Space::new() } else {
              let v260_10: Space = routine_14(c, &(v257_12_head), &(*p1), &(v257_12_tail).make_space());
              compose(&(v258_9),&(v260_10))
            };
            drop(v258_9);
            let v258_12: Space = unite(&(v258_7),&(v258_11));
            v257_12.join_into((v258_12).clone());
            }
            v257_12_cursor.ascend(1);
          }
          drop(v257_12_cursor);
          drop(v257_11);
          compose(&(v252_10),&(v257_12))
        };
        drop(v252_10);
        let v252_14: Space = unite(&(v252_8),&(v252_13));
        v251_12.join_into((v252_14).clone());
        }
        v251_12_cursor.ascend(1);
      }
      drop(v251_12_cursor);
      drop(v251_6);
      drop(v251_11);
      compose(&(v240_10),&(v251_12))
    };
    drop(v240_10);
    let v240_14: Space = unite(&(v240_8),&(v240_13));
    v239_28.join_into((v240_14).clone());
    }
    v239_28_cursor.ascend(1);
  }
  drop(v239_28_cursor);
  drop(v239_21);
  (v239_28).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v261_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v261_9: Space = unwrap(&(v261_8),&(*p0));
  drop(v261_8);
  let mut v261_28 = Space::new();
  let mut v261_28_cursor = (*s0).read_zipper();
  for v261_28_byte in v261_28_cursor.child_mask().iter() {
    v261_28_cursor.descend_to_byte(v261_28_byte);
    {
    let v261_28_tail = v261_28_cursor.fork_read_zipper();
    let v261_28_head = Path::from_slice(&[v261_28_byte]);
    let v262_2: Space = singleton(&(v261_28_head));
    let v262_3: Space = intersect(&(*CONSTANT_2),&(v262_2));
    let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = subtract(&(*CONSTANT_1),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (v262_5).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&(v261_28_head));
      let mut v263_7 = Space::new();
      let mut v263_7_cursor = (v261_28_tail).read_zipper();
      for v263_7_byte in v263_7_cursor.child_mask().iter() {
        v263_7_cursor.descend_to_byte(v263_7_byte);
        {
        let v263_7_tail = v263_7_cursor.fork_read_zipper();
        let v263_7_head = Path::from_slice(&[v263_7_byte]);
        let v264_2: Space = singleton(&(v263_7_head));
        let v264_3: Space = intersect(&(*CONSTANT_2),&(v264_2));
        let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = subtract(&(*CONSTANT_1),&(v264_4));
        drop(v264_4);
        let v264_8: Space = if (v264_5).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v263_6),&(v263_7_head));
          let mut v265_7 = Space::new();
          let mut v265_7_cursor = (v263_7_tail).read_zipper();
          for v265_7_byte in v265_7_cursor.child_mask().iter() {
            v265_7_cursor.descend_to_byte(v265_7_byte);
            {
            let v265_7_tail = v265_7_cursor.fork_read_zipper();
            let v265_7_head = Path::from_slice(&[v265_7_byte]);
            let v266_2: Space = singleton(&(v265_7_head));
            let v266_3: Space = intersect(&(*CONSTANT_2),&(v266_2));
            let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = subtract(&(*CONSTANT_1),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (v266_5).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&(v265_7_head));
              let v267_7: Space = routine_26(c, &(v267_6), &(*p1), &(v265_7_tail).make_space(), &(*s1));
              compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = intersect(&(*CONSTANT_2),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (v266_10).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&(v265_7_head));
              let v268_11: Space = routine_27(c, &(v268_6), &(*p1), &(v265_7_tail).make_space(), &(*s1));
              drop(v268_6);
              compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = unite(&(v266_8),&(v266_12));
            v265_7.join_into((v266_13).clone());
            }
            v265_7_cursor.ascend(1);
          }
          drop(v265_7_cursor);
          compose(&(v264_5),&(v265_7))
        };
        drop(v264_5);
        let v264_9: Space = intersect(&(*CONSTANT_2),&(v264_2));
        drop(v264_2);
        let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
        drop(v264_9);
        let v264_12: Space = if (v264_10).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v263_6),&(v263_7_head));
          let mut v269_11 = Space::new();
          let mut v269_11_cursor = (v263_7_tail).read_zipper();
          for v269_11_byte in v269_11_cursor.child_mask().iter() {
            v269_11_cursor.descend_to_byte(v269_11_byte);
            {
            let v269_11_tail = v269_11_cursor.fork_read_zipper();
            let v269_11_head = Path::from_slice(&[v269_11_byte]);
            let v270_2: Space = singleton(&(v269_11_head));
            let v270_3: Space = intersect(&(*CONSTANT_2),&(v270_2));
            let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
            drop(v270_3);
            let v270_5: Space = subtract(&(*CONSTANT_1),&(v270_4));
            drop(v270_4);
            let v270_8: Space = if (v270_5).is_empty() { Space::new() } else {
              let v271_6: Path = concat_path(&(v269_6),&(v269_11_head));
              let v271_7: Space = routine_26(c, &(v271_6), &(*p1), &(v269_11_tail).make_space(), &(*s1));
              compose(&(v270_5),&(v271_7))
            };
            drop(v270_5);
            let v270_9: Space = intersect(&(*CONSTANT_2),&(v270_2));
            drop(v270_2);
            let v270_10: Space = if has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
            drop(v270_9);
            let v270_12: Space = if (v270_10).is_empty() { Space::new() } else {
              let v272_6: Path = concat_path(&(v269_6),&(v269_11_head));
              let v272_11: Space = routine_10(c, &(v272_6), &(*p1), &(v269_11_tail).make_space(), &(*s1));
              drop(v272_6);
              compose(&(v270_10),&(v272_11))
            };
            drop(v270_10);
            let v270_13: Space = unite(&(v270_8),&(v270_12));
            v269_11.join_into((v270_13).clone());
            }
            v269_11_cursor.ascend(1);
          }
          drop(v269_11_cursor);
          drop(v269_6);
          compose(&(v264_10),&(v269_11))
        };
        drop(v264_10);
        let v264_13: Space = unite(&(v264_8),&(v264_12));
        v263_7.join_into((v264_13).clone());
        }
        v263_7_cursor.ascend(1);
      }
      drop(v263_7_cursor);
      drop(v263_6);
      compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = intersect(&(*CONSTANT_2),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_13: Space = if (v262_10).is_empty() { Space::new() } else {
      let v273_11: Space = unwrap(&(v261_9),&(v261_28_head));
      let mut v273_12 = Space::new();
      let mut v273_12_cursor = (v273_11).read_zipper();
      for v273_12_byte in v273_12_cursor.child_mask().iter() {
        v273_12_cursor.descend_to_byte(v273_12_byte);
        {
        let v273_12_tail = v273_12_cursor.fork_read_zipper();
        let v273_12_head = Path::from_slice(&[v273_12_byte]);
        let v274_2: Space = singleton(&(v273_12_head));
        let v274_3: Space = intersect(&(*CONSTANT_2),&(v274_2));
        let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = subtract(&(*CONSTANT_1),&(v274_4));
        drop(v274_4);
        let v274_7: Space = if (v274_5).is_empty() { Space::new() } else {
          let mut v275_6 = Space::new();
          let mut v275_6_cursor = (v273_12_tail).read_zipper();
          for v275_6_byte in v275_6_cursor.child_mask().iter() {
            v275_6_cursor.descend_to_byte(v275_6_byte);
            {
            let v275_6_tail = v275_6_cursor.fork_read_zipper();
            let v275_6_head = Path::from_slice(&[v275_6_byte]);
            let v276_2: Space = singleton(&(v275_6_head));
            let v276_3: Space = intersect(&(*CONSTANT_2),&(v276_2));
            let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
            drop(v276_3);
            let v276_5: Space = subtract(&(*CONSTANT_1),&(v276_4));
            drop(v276_4);
            let v276_8: Space = if (v276_5).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v273_12_head),&(v275_6_head));
              let v277_7: Space = routine_17(c, &(v277_6), &(*p1), &(v275_6_tail).make_space());
              compose(&(v276_5),&(v277_7))
            };
            drop(v276_5);
            let v276_9: Space = intersect(&(*CONSTANT_2),&(v276_2));
            drop(v276_2);
            let v276_10: Space = if has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
            drop(v276_9);
            let v276_12: Space = if (v276_10).is_empty() { Space::new() } else {
              let v278_6: Path = concat_path(&(v273_12_head),&(v275_6_head));
              let v278_11: Space = routine_18(c, &(v278_6), &(*p1), &(v275_6_tail).make_space());
              drop(v278_6);
              compose(&(v276_10),&(v278_11))
            };
            drop(v276_10);
            let v276_13: Space = unite(&(v276_8),&(v276_12));
            v275_6.join_into((v276_13).clone());
            }
            v275_6_cursor.ascend(1);
          }
          drop(v275_6_cursor);
          compose(&(v274_5),&(v275_6))
        };
        drop(v274_5);
        let v274_8: Space = intersect(&(*CONSTANT_2),&(v274_2));
        drop(v274_2);
        let v274_9: Space = if has_head(&(v274_8)) { singleton(&[]) } else { Space::new() };
        drop(v274_8);
        let v274_11: Space = if (v274_9).is_empty() { Space::new() } else {
          let mut v279_10 = Space::new();
          let mut v279_10_cursor = (v273_12_tail).read_zipper();
          for v279_10_byte in v279_10_cursor.child_mask().iter() {
            v279_10_cursor.descend_to_byte(v279_10_byte);
            {
            let v279_10_tail = v279_10_cursor.fork_read_zipper();
            let v279_10_head = Path::from_slice(&[v279_10_byte]);
            let v280_2: Space = singleton(&(v279_10_head));
            let v280_3: Space = intersect(&(*CONSTANT_2),&(v280_2));
            let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
            drop(v280_3);
            let v280_5: Space = subtract(&(*CONSTANT_1),&(v280_4));
            drop(v280_4);
            let v280_8: Space = if (v280_5).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v273_12_head),&(v279_10_head));
              let v281_7: Space = routine_17(c, &(v281_6), &(*p1), &(v279_10_tail).make_space());
              compose(&(v280_5),&(v281_7))
            };
            drop(v280_5);
            let v280_9: Space = intersect(&(*CONSTANT_2),&(v280_2));
            drop(v280_2);
            let v280_10: Space = if has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
            drop(v280_9);
            let v280_12: Space = if (v280_10).is_empty() { Space::new() } else {
              let v282_6: Path = concat_path(&(v273_12_head),&(v279_10_head));
              let v282_11: Space = routine_19(c, &(v282_6), &(*p1), &(v279_10_tail).make_space());
              drop(v282_6);
              compose(&(v280_10),&(v282_11))
            };
            drop(v280_10);
            let v280_13: Space = unite(&(v280_8),&(v280_12));
            v279_10.join_into((v280_13).clone());
            }
            v279_10_cursor.ascend(1);
          }
          drop(v279_10_cursor);
          compose(&(v274_9),&(v279_10))
        };
        drop(v274_9);
        let v274_12: Space = unite(&(v274_7),&(v274_11));
        v273_12.join_into((v274_12).clone());
        }
        v273_12_cursor.ascend(1);
      }
      drop(v273_12_cursor);
      drop(v273_11);
      compose(&(v262_10),&(v273_12))
    };
    drop(v262_10);
    let v262_14: Space = unite(&(v262_8),&(v262_13));
    v261_28.join_into((v262_14).clone());
    }
    v261_28_cursor.ascend(1);
  }
  drop(v261_28_cursor);
  drop(v261_9);
  (v261_28).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v283_21 = Space::new();
  let mut v283_21_cursor = (*s0).read_zipper();
  for v283_21_byte in v283_21_cursor.child_mask().iter() {
    v283_21_cursor.descend_to_byte(v283_21_byte);
    {
    let v283_21_tail = v283_21_cursor.fork_read_zipper();
    let v283_21_head = Path::from_slice(&[v283_21_byte]);
    let v284_2: Space = singleton(&(v283_21_head));
    let v284_3: Space = intersect(&(*CONSTANT_2),&(v284_2));
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = subtract(&(*CONSTANT_1),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (v284_5).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&(v283_21_head));
      let mut v285_7 = Space::new();
      let mut v285_7_cursor = (v283_21_tail).read_zipper();
      for v285_7_byte in v285_7_cursor.child_mask().iter() {
        v285_7_cursor.descend_to_byte(v285_7_byte);
        {
        let v285_7_tail = v285_7_cursor.fork_read_zipper();
        let v285_7_head = Path::from_slice(&[v285_7_byte]);
        let v286_2: Space = singleton(&(v285_7_head));
        let v286_3: Space = intersect(&(*CONSTANT_2),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_1),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (v286_5).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&(v285_7_head));
          let mut v287_7 = Space::new();
          let mut v287_7_cursor = (v285_7_tail).read_zipper();
          for v287_7_byte in v287_7_cursor.child_mask().iter() {
            v287_7_cursor.descend_to_byte(v287_7_byte);
            {
            let v287_7_tail = v287_7_cursor.fork_read_zipper();
            let v287_7_head = Path::from_slice(&[v287_7_byte]);
            let v288_2: Space = singleton(&(v287_7_head));
            let v288_3: Space = intersect(&(*CONSTANT_2),&(v288_2));
            let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = subtract(&(*CONSTANT_1),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (v288_5).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&(v287_7_head));
              let v289_7: Space = routine_28(c, &(v289_6), &(*p1), &(v287_7_tail).make_space());
              compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = intersect(&(*CONSTANT_2),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (v288_10).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&(v287_7_head));
              let v290_11: Space = routine_29(c, &(v290_6), &(*p1), &(v287_7_tail).make_space());
              drop(v290_6);
              compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = unite(&(v288_8),&(v288_12));
            v287_7.join_into((v288_13).clone());
            }
            v287_7_cursor.ascend(1);
          }
          drop(v287_7_cursor);
          compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = intersect(&(*CONSTANT_2),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (v286_10).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&(v285_7_head));
          let mut v291_11 = Space::new();
          let mut v291_11_cursor = (v285_7_tail).read_zipper();
          for v291_11_byte in v291_11_cursor.child_mask().iter() {
            v291_11_cursor.descend_to_byte(v291_11_byte);
            {
            let v291_11_tail = v291_11_cursor.fork_read_zipper();
            let v291_11_head = Path::from_slice(&[v291_11_byte]);
            let v292_2: Space = singleton(&(v291_11_head));
            let v292_3: Space = intersect(&(*CONSTANT_2),&(v292_2));
            let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = subtract(&(*CONSTANT_1),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&(v291_11_head));
              let v293_7: Space = routine_28(c, &(v293_6), &(*p1), &(v291_11_tail).make_space());
              compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = intersect(&(*CONSTANT_2),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (v292_10).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&(v291_11_head));
              let v294_11: Space = routine_19(c, &(v294_6), &(*p1), &(v291_11_tail).make_space());
              drop(v294_6);
              compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = unite(&(v292_8),&(v292_12));
            v291_11.join_into((v292_13).clone());
            }
            v291_11_cursor.ascend(1);
          }
          drop(v291_11_cursor);
          drop(v291_6);
          compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = unite(&(v286_8),&(v286_12));
        v285_7.join_into((v286_13).clone());
        }
        v285_7_cursor.ascend(1);
      }
      drop(v285_7_cursor);
      compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = intersect(&(*CONSTANT_2),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (v284_10).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&(v283_21_head));
      let mut v295_11 = Space::new();
      let mut v295_11_cursor = (v283_21_tail).read_zipper();
      for v295_11_byte in v295_11_cursor.child_mask().iter() {
        v295_11_cursor.descend_to_byte(v295_11_byte);
        {
        let v295_11_tail = v295_11_cursor.fork_read_zipper();
        let v295_11_head = Path::from_slice(&[v295_11_byte]);
        let v296_2: Space = singleton(&(v295_11_head));
        let v296_3: Space = intersect(&(*CONSTANT_2),&(v296_2));
        let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = subtract(&(*CONSTANT_1),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (v296_5).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&(v295_11_head));
          let mut v297_7 = Space::new();
          let mut v297_7_cursor = (v295_11_tail).read_zipper();
          for v297_7_byte in v297_7_cursor.child_mask().iter() {
            v297_7_cursor.descend_to_byte(v297_7_byte);
            {
            let v297_7_tail = v297_7_cursor.fork_read_zipper();
            let v297_7_head = Path::from_slice(&[v297_7_byte]);
            let v298_2: Space = singleton(&(v297_7_head));
            let v298_3: Space = intersect(&(*CONSTANT_2),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_1),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (v298_5).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&(v297_7_head));
              let v299_7: Space = routine_28(c, &(v299_6), &(*p1), &(v297_7_tail).make_space());
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_2),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (v298_10).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&(v297_7_head));
              let v300_11: Space = routine_29(c, &(v300_6), &(*p1), &(v297_7_tail).make_space());
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            v297_7.join_into((v298_13).clone());
            }
            v297_7_cursor.ascend(1);
          }
          drop(v297_7_cursor);
          compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = intersect(&(*CONSTANT_2),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = compose(&(v296_10),&(v295_11_tail));
        drop(v296_10);
        let v301_6: Path = concat_path(&(v295_6),&(v295_11_head));
        let v296_12: Space = wrap(&(v296_11),&(v301_6));
        drop(v296_11);
        let v296_13: Space = wrap(&(v296_12),&(*p1));
        drop(v296_12);
        let v296_14: Space = unite(&(v296_8),&(v296_13));
        drop(v296_13);
        v295_11.join_into((v296_14).clone());
        }
        v295_11_cursor.ascend(1);
      }
      drop(v295_11_cursor);
      drop(v295_6);
      compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = unite(&(v284_8),&(v284_12));
    v283_21.join_into((v284_13).clone());
    }
    v283_21_cursor.ascend(1);
  }
  drop(v283_21_cursor);
  (v283_21).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v302_15 = Space::new();
  let mut v302_15_cursor = (*s0).read_zipper();
  for v302_15_byte in v302_15_cursor.child_mask().iter() {
    v302_15_cursor.descend_to_byte(v302_15_byte);
    {
    let v302_15_tail = v302_15_cursor.fork_read_zipper();
    let v302_15_head = Path::from_slice(&[v302_15_byte]);
    let v303_2: Space = singleton(&(v302_15_head));
    let v303_3: Space = intersect(&(*CONSTANT_2),&(v303_2));
    let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = subtract(&(*CONSTANT_1),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (v303_5).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&(v302_15_head));
      let mut v304_7 = Space::new();
      let mut v304_7_cursor = (v302_15_tail).read_zipper();
      for v304_7_byte in v304_7_cursor.child_mask().iter() {
        v304_7_cursor.descend_to_byte(v304_7_byte);
        {
        let v304_7_tail = v304_7_cursor.fork_read_zipper();
        let v304_7_head = Path::from_slice(&[v304_7_byte]);
        let v305_2: Space = singleton(&(v304_7_head));
        let v305_3: Space = intersect(&(*CONSTANT_2),&(v305_2));
        let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = subtract(&(*CONSTANT_1),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (v305_5).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let mut v306_7 = Space::new();
          let mut v306_7_cursor = (v304_7_tail).read_zipper();
          for v306_7_byte in v306_7_cursor.child_mask().iter() {
            v306_7_cursor.descend_to_byte(v306_7_byte);
            {
            let v306_7_tail = v306_7_cursor.fork_read_zipper();
            let v306_7_head = Path::from_slice(&[v306_7_byte]);
            let v307_2: Space = singleton(&(v306_7_head));
            let v307_3: Space = intersect(&(*CONSTANT_2),&(v307_2));
            let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
            drop(v307_3);
            let v307_5: Space = subtract(&(*CONSTANT_1),&(v307_4));
            drop(v307_4);
            let v307_8: Space = if (v307_5).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v306_6),&(v306_7_head));
              let v308_7: Space = routine_28(c, &(v308_6), &(*p1), &(v306_7_tail).make_space());
              compose(&(v307_5),&(v308_7))
            };
            drop(v307_5);
            let v307_9: Space = intersect(&(*CONSTANT_2),&(v307_2));
            drop(v307_2);
            let v307_10: Space = if has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
            drop(v307_9);
            let v307_12: Space = if (v307_10).is_empty() { Space::new() } else {
              let v309_6: Path = concat_path(&(v306_6),&(v306_7_head));
              let v309_11: Space = routine_29(c, &(v309_6), &(*p1), &(v306_7_tail).make_space());
              drop(v309_6);
              compose(&(v307_10),&(v309_11))
            };
            drop(v307_10);
            let v307_13: Space = unite(&(v307_8),&(v307_12));
            v306_7.join_into((v307_13).clone());
            }
            v306_7_cursor.ascend(1);
          }
          drop(v306_7_cursor);
          compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = intersect(&(*CONSTANT_2),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (v305_10).is_empty() { Space::new() } else {
          let v310_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let mut v310_11 = Space::new();
          let mut v310_11_cursor = (v304_7_tail).read_zipper();
          for v310_11_byte in v310_11_cursor.child_mask().iter() {
            v310_11_cursor.descend_to_byte(v310_11_byte);
            {
            let v310_11_tail = v310_11_cursor.fork_read_zipper();
            let v310_11_head = Path::from_slice(&[v310_11_byte]);
            let v311_2: Space = singleton(&(v310_11_head));
            let v311_3: Space = intersect(&(*CONSTANT_2),&(v311_2));
            let v311_4: Space = if has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
            drop(v311_3);
            let v311_5: Space = subtract(&(*CONSTANT_1),&(v311_4));
            drop(v311_4);
            let v311_8: Space = if (v311_5).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v310_6),&(v310_11_head));
              let v312_7: Space = routine_28(c, &(v312_6), &(*p1), &(v310_11_tail).make_space());
              compose(&(v311_5),&(v312_7))
            };
            drop(v311_5);
            let v311_9: Space = intersect(&(*CONSTANT_2),&(v311_2));
            drop(v311_2);
            let v311_10: Space = if has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
            drop(v311_9);
            let v311_12: Space = if (v311_10).is_empty() { Space::new() } else {
              let v313_6: Path = concat_path(&(v310_6),&(v310_11_head));
              let v313_11: Space = routine_19(c, &(v313_6), &(*p1), &(v310_11_tail).make_space());
              drop(v313_6);
              compose(&(v311_10),&(v313_11))
            };
            drop(v311_10);
            let v311_13: Space = unite(&(v311_8),&(v311_12));
            v310_11.join_into((v311_13).clone());
            }
            v310_11_cursor.ascend(1);
          }
          drop(v310_11_cursor);
          drop(v310_6);
          compose(&(v305_10),&(v310_11))
        };
        drop(v305_10);
        let v305_13: Space = unite(&(v305_8),&(v305_12));
        v304_7.join_into((v305_13).clone());
        }
        v304_7_cursor.ascend(1);
      }
      drop(v304_7_cursor);
      compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = intersect(&(*CONSTANT_2),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_11: Space = compose(&(v303_10),&(v302_15_tail));
    drop(v303_10);
    let v314_6: Path = concat_path(&(*p0),&(v302_15_head));
    let v303_12: Space = wrap(&(v303_11),&(v314_6));
    drop(v303_11);
    let v303_13: Space = wrap(&(v303_12),&(*p1));
    drop(v303_12);
    let v303_14: Space = unite(&(v303_8),&(v303_13));
    drop(v303_13);
    v302_15.join_into((v303_14).clone());
    }
    v302_15_cursor.ascend(1);
  }
  drop(v302_15_cursor);
  (v302_15).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v315_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v315_21: Space = unwrap(&(v315_20),&(*p0));
  drop(v315_20);
  let mut v315_28 = Space::new();
  let mut v315_28_cursor = (*s0).read_zipper();
  for v315_28_byte in v315_28_cursor.child_mask().iter() {
    v315_28_cursor.descend_to_byte(v315_28_byte);
    {
    let v315_28_tail = v315_28_cursor.fork_read_zipper();
    let v315_28_head = Path::from_slice(&[v315_28_byte]);
    let v316_2: Space = singleton(&(v315_28_head));
    let v316_3: Space = intersect(&(*CONSTANT_2),&(v316_2));
    let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
    drop(v316_3);
    let v316_5: Space = subtract(&(*CONSTANT_1),&(v316_4));
    drop(v316_4);
    let v316_8: Space = if (v316_5).is_empty() { Space::new() } else {
      let v317_6: Path = concat_path(&(*p0),&(v315_28_head));
      let mut v317_7 = Space::new();
      let mut v317_7_cursor = (v315_28_tail).read_zipper();
      for v317_7_byte in v317_7_cursor.child_mask().iter() {
        v317_7_cursor.descend_to_byte(v317_7_byte);
        {
        let v317_7_tail = v317_7_cursor.fork_read_zipper();
        let v317_7_head = Path::from_slice(&[v317_7_byte]);
        let v318_2: Space = singleton(&(v317_7_head));
        let v318_3: Space = intersect(&(*CONSTANT_2),&(v318_2));
        let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
        drop(v318_3);
        let v318_5: Space = subtract(&(*CONSTANT_1),&(v318_4));
        drop(v318_4);
        let v318_8: Space = if (v318_5).is_empty() { Space::new() } else {
          let v319_6: Path = concat_path(&(v317_6),&(v317_7_head));
          let mut v319_7 = Space::new();
          let mut v319_7_cursor = (v317_7_tail).read_zipper();
          for v319_7_byte in v319_7_cursor.child_mask().iter() {
            v319_7_cursor.descend_to_byte(v319_7_byte);
            {
            let v319_7_tail = v319_7_cursor.fork_read_zipper();
            let v319_7_head = Path::from_slice(&[v319_7_byte]);
            let v320_2: Space = singleton(&(v319_7_head));
            let v320_3: Space = intersect(&(*CONSTANT_2),&(v320_2));
            let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
            drop(v320_3);
            let v320_5: Space = subtract(&(*CONSTANT_1),&(v320_4));
            drop(v320_4);
            let v320_8: Space = if (v320_5).is_empty() { Space::new() } else {
              let v321_6: Path = concat_path(&(v319_6),&(v319_7_head));
              let v321_7: Space = routine_30(c, &(v321_6), &(*p1), &(v319_7_tail).make_space(), &(*s1));
              compose(&(v320_5),&(v321_7))
            };
            drop(v320_5);
            let v320_9: Space = intersect(&(*CONSTANT_2),&(v320_2));
            drop(v320_2);
            let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
            drop(v320_9);
            let v320_12: Space = if (v320_10).is_empty() { Space::new() } else {
              let v322_6: Path = concat_path(&(v319_6),&(v319_7_head));
              let v322_11: Space = routine_31(c, &(v322_6), &(*p1), &(v319_7_tail).make_space(), &(*s1));
              drop(v322_6);
              compose(&(v320_10),&(v322_11))
            };
            drop(v320_10);
            let v320_13: Space = unite(&(v320_8),&(v320_12));
            v319_7.join_into((v320_13).clone());
            }
            v319_7_cursor.ascend(1);
          }
          drop(v319_7_cursor);
          compose(&(v318_5),&(v319_7))
        };
        drop(v318_5);
        let v318_9: Space = intersect(&(*CONSTANT_2),&(v318_2));
        drop(v318_2);
        let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
        drop(v318_9);
        let v318_12: Space = if (v318_10).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v317_6),&(v317_7_head));
          let mut v323_11 = Space::new();
          let mut v323_11_cursor = (v317_7_tail).read_zipper();
          for v323_11_byte in v323_11_cursor.child_mask().iter() {
            v323_11_cursor.descend_to_byte(v323_11_byte);
            {
            let v323_11_tail = v323_11_cursor.fork_read_zipper();
            let v323_11_head = Path::from_slice(&[v323_11_byte]);
            let v324_2: Space = singleton(&(v323_11_head));
            let v324_3: Space = intersect(&(*CONSTANT_2),&(v324_2));
            let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
            drop(v324_3);
            let v324_5: Space = subtract(&(*CONSTANT_1),&(v324_4));
            drop(v324_4);
            let v324_8: Space = if (v324_5).is_empty() { Space::new() } else {
              let v325_6: Path = concat_path(&(v323_6),&(v323_11_head));
              let v325_7: Space = routine_30(c, &(v325_6), &(*p1), &(v323_11_tail).make_space(), &(*s1));
              compose(&(v324_5),&(v325_7))
            };
            drop(v324_5);
            let v324_9: Space = intersect(&(*CONSTANT_2),&(v324_2));
            drop(v324_2);
            let v324_10: Space = if has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
            drop(v324_9);
            let v324_12: Space = if (v324_10).is_empty() { Space::new() } else {
              let v326_6: Path = concat_path(&(v323_6),&(v323_11_head));
              let v326_11: Space = routine_10(c, &(v326_6), &(*p1), &(v323_11_tail).make_space(), &(*s1));
              drop(v326_6);
              compose(&(v324_10),&(v326_11))
            };
            drop(v324_10);
            let v324_13: Space = unite(&(v324_8),&(v324_12));
            v323_11.join_into((v324_13).clone());
            }
            v323_11_cursor.ascend(1);
          }
          drop(v323_11_cursor);
          drop(v323_6);
          compose(&(v318_10),&(v323_11))
        };
        drop(v318_10);
        let v318_13: Space = unite(&(v318_8),&(v318_12));
        v317_7.join_into((v318_13).clone());
        }
        v317_7_cursor.ascend(1);
      }
      drop(v317_7_cursor);
      compose(&(v316_5),&(v317_7))
    };
    drop(v316_5);
    let v316_9: Space = intersect(&(*CONSTANT_2),&(v316_2));
    drop(v316_2);
    let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
    drop(v316_9);
    let v316_13: Space = if (v316_10).is_empty() { Space::new() } else {
      let v327_6: Path = concat_path(&(*p0),&(v315_28_head));
      let v327_11: Space = unwrap(&(v315_21),&(v315_28_head));
      let mut v327_12 = Space::new();
      let mut v327_12_cursor = (v315_28_tail).read_zipper();
      for v327_12_byte in v327_12_cursor.child_mask().iter() {
        v327_12_cursor.descend_to_byte(v327_12_byte);
        {
        let v327_12_tail = v327_12_cursor.fork_read_zipper();
        let v327_12_head = Path::from_slice(&[v327_12_byte]);
        let v328_2: Space = singleton(&(v327_12_head));
        let v328_3: Space = intersect(&(*CONSTANT_2),&(v328_2));
        let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
        drop(v328_3);
        let v328_5: Space = subtract(&(*CONSTANT_1),&(v328_4));
        drop(v328_4);
        let v328_8: Space = if (v328_5).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v327_6),&(v327_12_head));
          let mut v329_7 = Space::new();
          let mut v329_7_cursor = (v327_12_tail).read_zipper();
          for v329_7_byte in v329_7_cursor.child_mask().iter() {
            v329_7_cursor.descend_to_byte(v329_7_byte);
            {
            let v329_7_tail = v329_7_cursor.fork_read_zipper();
            let v329_7_head = Path::from_slice(&[v329_7_byte]);
            let v330_2: Space = singleton(&(v329_7_head));
            let v330_3: Space = intersect(&(*CONSTANT_2),&(v330_2));
            let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
            drop(v330_3);
            let v330_5: Space = subtract(&(*CONSTANT_1),&(v330_4));
            drop(v330_4);
            let v330_8: Space = if (v330_5).is_empty() { Space::new() } else {
              let v331_6: Path = concat_path(&(v329_6),&(v329_7_head));
              let v331_7: Space = routine_30(c, &(v331_6), &(*p1), &(v329_7_tail).make_space(), &(*s1));
              compose(&(v330_5),&(v331_7))
            };
            drop(v330_5);
            let v330_9: Space = intersect(&(*CONSTANT_2),&(v330_2));
            drop(v330_2);
            let v330_10: Space = if has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
            drop(v330_9);
            let v330_12: Space = if (v330_10).is_empty() { Space::new() } else {
              let v332_6: Path = concat_path(&(v329_6),&(v329_7_head));
              let v332_11: Space = routine_31(c, &(v332_6), &(*p1), &(v329_7_tail).make_space(), &(*s1));
              drop(v332_6);
              compose(&(v330_10),&(v332_11))
            };
            drop(v330_10);
            let v330_13: Space = unite(&(v330_8),&(v330_12));
            v329_7.join_into((v330_13).clone());
            }
            v329_7_cursor.ascend(1);
          }
          drop(v329_7_cursor);
          drop(v329_6);
          compose(&(v328_5),&(v329_7))
        };
        drop(v328_5);
        let v328_9: Space = intersect(&(*CONSTANT_2),&(v328_2));
        drop(v328_2);
        let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
        drop(v328_9);
        let v328_13: Space = if (v328_10).is_empty() { Space::new() } else {
          let v333_11: Space = unwrap(&(v327_11),&(v327_12_head));
          let mut v333_12 = Space::new();
          let mut v333_12_cursor = (v333_11).read_zipper();
          for v333_12_byte in v333_12_cursor.child_mask().iter() {
            v333_12_cursor.descend_to_byte(v333_12_byte);
            {
            let v333_12_tail = v333_12_cursor.fork_read_zipper();
            let v333_12_head = Path::from_slice(&[v333_12_byte]);
            let v334_2: Space = singleton(&(v333_12_head));
            let v334_3: Space = intersect(&(*CONSTANT_2),&(v334_2));
            let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
            drop(v334_3);
            let v334_5: Space = subtract(&(*CONSTANT_1),&(v334_4));
            drop(v334_4);
            let v334_7: Space = if (v334_5).is_empty() { Space::new() } else {
              let v335_6: Space = routine_13(c, &(v333_12_head), &(*p1), &(v333_12_tail).make_space());
              compose(&(v334_5),&(v335_6))
            };
            drop(v334_5);
            let v334_8: Space = intersect(&(*CONSTANT_2),&(v334_2));
            drop(v334_2);
            let v334_9: Space = if has_head(&(v334_8)) { singleton(&[]) } else { Space::new() };
            drop(v334_8);
            let v334_11: Space = if (v334_9).is_empty() { Space::new() } else {
              let v336_10: Space = routine_14(c, &(v333_12_head), &(*p1), &(v333_12_tail).make_space());
              compose(&(v334_9),&(v336_10))
            };
            drop(v334_9);
            let v334_12: Space = unite(&(v334_7),&(v334_11));
            v333_12.join_into((v334_12).clone());
            }
            v333_12_cursor.ascend(1);
          }
          drop(v333_12_cursor);
          drop(v333_11);
          compose(&(v328_10),&(v333_12))
        };
        drop(v328_10);
        let v328_14: Space = unite(&(v328_8),&(v328_13));
        v327_12.join_into((v328_14).clone());
        }
        v327_12_cursor.ascend(1);
      }
      drop(v327_12_cursor);
      drop(v327_6);
      drop(v327_11);
      compose(&(v316_10),&(v327_12))
    };
    drop(v316_10);
    let v316_14: Space = unite(&(v316_8),&(v316_13));
    v315_28.join_into((v316_14).clone());
    }
    v315_28_cursor.ascend(1);
  }
  drop(v315_28_cursor);
  drop(v315_21);
  (v315_28).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v337_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v337_9: Space = unwrap(&(v337_8),&(*p0));
  drop(v337_8);
  let mut v337_28 = Space::new();
  let mut v337_28_cursor = (*s0).read_zipper();
  for v337_28_byte in v337_28_cursor.child_mask().iter() {
    v337_28_cursor.descend_to_byte(v337_28_byte);
    {
    let v337_28_tail = v337_28_cursor.fork_read_zipper();
    let v337_28_head = Path::from_slice(&[v337_28_byte]);
    let v338_2: Space = singleton(&(v337_28_head));
    let v338_3: Space = intersect(&(*CONSTANT_2),&(v338_2));
    let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
    drop(v338_3);
    let v338_5: Space = subtract(&(*CONSTANT_1),&(v338_4));
    drop(v338_4);
    let v338_8: Space = if (v338_5).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&(v337_28_head));
      let mut v339_7 = Space::new();
      let mut v339_7_cursor = (v337_28_tail).read_zipper();
      for v339_7_byte in v339_7_cursor.child_mask().iter() {
        v339_7_cursor.descend_to_byte(v339_7_byte);
        {
        let v339_7_tail = v339_7_cursor.fork_read_zipper();
        let v339_7_head = Path::from_slice(&[v339_7_byte]);
        let v340_2: Space = singleton(&(v339_7_head));
        let v340_3: Space = intersect(&(*CONSTANT_2),&(v340_2));
        let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = subtract(&(*CONSTANT_1),&(v340_4));
        drop(v340_4);
        let v340_8: Space = if (v340_5).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v339_6),&(v339_7_head));
          let mut v341_7 = Space::new();
          let mut v341_7_cursor = (v339_7_tail).read_zipper();
          for v341_7_byte in v341_7_cursor.child_mask().iter() {
            v341_7_cursor.descend_to_byte(v341_7_byte);
            {
            let v341_7_tail = v341_7_cursor.fork_read_zipper();
            let v341_7_head = Path::from_slice(&[v341_7_byte]);
            let v342_2: Space = singleton(&(v341_7_head));
            let v342_3: Space = intersect(&(*CONSTANT_2),&(v342_2));
            let v342_4: Space = if has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
            drop(v342_3);
            let v342_5: Space = subtract(&(*CONSTANT_1),&(v342_4));
            drop(v342_4);
            let v342_8: Space = if (v342_5).is_empty() { Space::new() } else {
              let v343_6: Path = concat_path(&(v341_6),&(v341_7_head));
              let v343_7: Space = routine_30(c, &(v343_6), &(*p1), &(v341_7_tail).make_space(), &(*s1));
              compose(&(v342_5),&(v343_7))
            };
            drop(v342_5);
            let v342_9: Space = intersect(&(*CONSTANT_2),&(v342_2));
            drop(v342_2);
            let v342_10: Space = if has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
            drop(v342_9);
            let v342_12: Space = if (v342_10).is_empty() { Space::new() } else {
              let v344_6: Path = concat_path(&(v341_6),&(v341_7_head));
              let v344_11: Space = routine_31(c, &(v344_6), &(*p1), &(v341_7_tail).make_space(), &(*s1));
              drop(v344_6);
              compose(&(v342_10),&(v344_11))
            };
            drop(v342_10);
            let v342_13: Space = unite(&(v342_8),&(v342_12));
            v341_7.join_into((v342_13).clone());
            }
            v341_7_cursor.ascend(1);
          }
          drop(v341_7_cursor);
          compose(&(v340_5),&(v341_7))
        };
        drop(v340_5);
        let v340_9: Space = intersect(&(*CONSTANT_2),&(v340_2));
        drop(v340_2);
        let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
        drop(v340_9);
        let v340_12: Space = if (v340_10).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v339_6),&(v339_7_head));
          let mut v345_11 = Space::new();
          let mut v345_11_cursor = (v339_7_tail).read_zipper();
          for v345_11_byte in v345_11_cursor.child_mask().iter() {
            v345_11_cursor.descend_to_byte(v345_11_byte);
            {
            let v345_11_tail = v345_11_cursor.fork_read_zipper();
            let v345_11_head = Path::from_slice(&[v345_11_byte]);
            let v346_2: Space = singleton(&(v345_11_head));
            let v346_3: Space = intersect(&(*CONSTANT_2),&(v346_2));
            let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
            drop(v346_3);
            let v346_5: Space = subtract(&(*CONSTANT_1),&(v346_4));
            drop(v346_4);
            let v346_8: Space = if (v346_5).is_empty() { Space::new() } else {
              let v347_6: Path = concat_path(&(v345_6),&(v345_11_head));
              let v347_7: Space = routine_30(c, &(v347_6), &(*p1), &(v345_11_tail).make_space(), &(*s1));
              compose(&(v346_5),&(v347_7))
            };
            drop(v346_5);
            let v346_9: Space = intersect(&(*CONSTANT_2),&(v346_2));
            drop(v346_2);
            let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
            drop(v346_9);
            let v346_12: Space = if (v346_10).is_empty() { Space::new() } else {
              let v348_6: Path = concat_path(&(v345_6),&(v345_11_head));
              let v348_11: Space = routine_10(c, &(v348_6), &(*p1), &(v345_11_tail).make_space(), &(*s1));
              drop(v348_6);
              compose(&(v346_10),&(v348_11))
            };
            drop(v346_10);
            let v346_13: Space = unite(&(v346_8),&(v346_12));
            v345_11.join_into((v346_13).clone());
            }
            v345_11_cursor.ascend(1);
          }
          drop(v345_11_cursor);
          drop(v345_6);
          compose(&(v340_10),&(v345_11))
        };
        drop(v340_10);
        let v340_13: Space = unite(&(v340_8),&(v340_12));
        v339_7.join_into((v340_13).clone());
        }
        v339_7_cursor.ascend(1);
      }
      drop(v339_7_cursor);
      drop(v339_6);
      compose(&(v338_5),&(v339_7))
    };
    drop(v338_5);
    let v338_9: Space = intersect(&(*CONSTANT_2),&(v338_2));
    drop(v338_2);
    let v338_10: Space = if has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
    drop(v338_9);
    let v338_13: Space = if (v338_10).is_empty() { Space::new() } else {
      let v349_11: Space = unwrap(&(v337_9),&(v337_28_head));
      let mut v349_12 = Space::new();
      let mut v349_12_cursor = (v349_11).read_zipper();
      for v349_12_byte in v349_12_cursor.child_mask().iter() {
        v349_12_cursor.descend_to_byte(v349_12_byte);
        {
        let v349_12_tail = v349_12_cursor.fork_read_zipper();
        let v349_12_head = Path::from_slice(&[v349_12_byte]);
        let v350_2: Space = singleton(&(v349_12_head));
        let v350_3: Space = intersect(&(*CONSTANT_2),&(v350_2));
        let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
        drop(v350_3);
        let v350_5: Space = subtract(&(*CONSTANT_1),&(v350_4));
        drop(v350_4);
        let v350_7: Space = if (v350_5).is_empty() { Space::new() } else {
          let mut v351_6 = Space::new();
          let mut v351_6_cursor = (v349_12_tail).read_zipper();
          for v351_6_byte in v351_6_cursor.child_mask().iter() {
            v351_6_cursor.descend_to_byte(v351_6_byte);
            {
            let v351_6_tail = v351_6_cursor.fork_read_zipper();
            let v351_6_head = Path::from_slice(&[v351_6_byte]);
            let v352_2: Space = singleton(&(v351_6_head));
            let v352_3: Space = intersect(&(*CONSTANT_2),&(v352_2));
            let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = subtract(&(*CONSTANT_1),&(v352_4));
            drop(v352_4);
            let v352_8: Space = if (v352_5).is_empty() { Space::new() } else {
              let v353_6: Path = concat_path(&(v349_12_head),&(v351_6_head));
              let v353_7: Space = routine_17(c, &(v353_6), &(*p1), &(v351_6_tail).make_space());
              compose(&(v352_5),&(v353_7))
            };
            drop(v352_5);
            let v352_9: Space = intersect(&(*CONSTANT_2),&(v352_2));
            drop(v352_2);
            let v352_10: Space = if has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
            drop(v352_9);
            let v352_12: Space = if (v352_10).is_empty() { Space::new() } else {
              let v354_6: Path = concat_path(&(v349_12_head),&(v351_6_head));
              let v354_11: Space = routine_18(c, &(v354_6), &(*p1), &(v351_6_tail).make_space());
              drop(v354_6);
              compose(&(v352_10),&(v354_11))
            };
            drop(v352_10);
            let v352_13: Space = unite(&(v352_8),&(v352_12));
            v351_6.join_into((v352_13).clone());
            }
            v351_6_cursor.ascend(1);
          }
          drop(v351_6_cursor);
          compose(&(v350_5),&(v351_6))
        };
        drop(v350_5);
        let v350_8: Space = intersect(&(*CONSTANT_2),&(v350_2));
        drop(v350_2);
        let v350_9: Space = if has_head(&(v350_8)) { singleton(&[]) } else { Space::new() };
        drop(v350_8);
        let v350_11: Space = if (v350_9).is_empty() { Space::new() } else {
          let mut v355_10 = Space::new();
          let mut v355_10_cursor = (v349_12_tail).read_zipper();
          for v355_10_byte in v355_10_cursor.child_mask().iter() {
            v355_10_cursor.descend_to_byte(v355_10_byte);
            {
            let v355_10_tail = v355_10_cursor.fork_read_zipper();
            let v355_10_head = Path::from_slice(&[v355_10_byte]);
            let v356_2: Space = singleton(&(v355_10_head));
            let v356_3: Space = intersect(&(*CONSTANT_2),&(v356_2));
            let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
            drop(v356_3);
            let v356_5: Space = subtract(&(*CONSTANT_1),&(v356_4));
            drop(v356_4);
            let v356_8: Space = if (v356_5).is_empty() { Space::new() } else {
              let v357_6: Path = concat_path(&(v349_12_head),&(v355_10_head));
              let v357_7: Space = routine_17(c, &(v357_6), &(*p1), &(v355_10_tail).make_space());
              compose(&(v356_5),&(v357_7))
            };
            drop(v356_5);
            let v356_9: Space = intersect(&(*CONSTANT_2),&(v356_2));
            drop(v356_2);
            let v356_10: Space = if has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
            drop(v356_9);
            let v356_12: Space = if (v356_10).is_empty() { Space::new() } else {
              let v358_6: Path = concat_path(&(v349_12_head),&(v355_10_head));
              let v358_11: Space = routine_19(c, &(v358_6), &(*p1), &(v355_10_tail).make_space());
              drop(v358_6);
              compose(&(v356_10),&(v358_11))
            };
            drop(v356_10);
            let v356_13: Space = unite(&(v356_8),&(v356_12));
            v355_10.join_into((v356_13).clone());
            }
            v355_10_cursor.ascend(1);
          }
          drop(v355_10_cursor);
          compose(&(v350_9),&(v355_10))
        };
        drop(v350_9);
        let v350_12: Space = unite(&(v350_7),&(v350_11));
        v349_12.join_into((v350_12).clone());
        }
        v349_12_cursor.ascend(1);
      }
      drop(v349_12_cursor);
      drop(v349_11);
      compose(&(v338_10),&(v349_12))
    };
    drop(v338_10);
    let v338_14: Space = unite(&(v338_8),&(v338_13));
    v337_28.join_into((v338_14).clone());
    }
    v337_28_cursor.ascend(1);
  }
  drop(v337_28_cursor);
  drop(v337_9);
  (v337_28).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v359_21 = Space::new();
  let mut v359_21_cursor = (*s0).read_zipper();
  for v359_21_byte in v359_21_cursor.child_mask().iter() {
    v359_21_cursor.descend_to_byte(v359_21_byte);
    {
    let v359_21_tail = v359_21_cursor.fork_read_zipper();
    let v359_21_head = Path::from_slice(&[v359_21_byte]);
    let v360_2: Space = singleton(&(v359_21_head));
    let v360_3: Space = intersect(&(*CONSTANT_2),&(v360_2));
    let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = subtract(&(*CONSTANT_1),&(v360_4));
    drop(v360_4);
    let v360_8: Space = if (v360_5).is_empty() { Space::new() } else {
      let v361_6: Path = concat_path(&(*p0),&(v359_21_head));
      let mut v361_7 = Space::new();
      let mut v361_7_cursor = (v359_21_tail).read_zipper();
      for v361_7_byte in v361_7_cursor.child_mask().iter() {
        v361_7_cursor.descend_to_byte(v361_7_byte);
        {
        let v361_7_tail = v361_7_cursor.fork_read_zipper();
        let v361_7_head = Path::from_slice(&[v361_7_byte]);
        let v362_2: Space = singleton(&(v361_7_head));
        let v362_3: Space = intersect(&(*CONSTANT_2),&(v362_2));
        let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
        drop(v362_3);
        let v362_5: Space = subtract(&(*CONSTANT_1),&(v362_4));
        drop(v362_4);
        let v362_8: Space = if (v362_5).is_empty() { Space::new() } else {
          let v363_6: Path = concat_path(&(v361_6),&(v361_7_head));
          let mut v363_7 = Space::new();
          let mut v363_7_cursor = (v361_7_tail).read_zipper();
          for v363_7_byte in v363_7_cursor.child_mask().iter() {
            v363_7_cursor.descend_to_byte(v363_7_byte);
            {
            let v363_7_tail = v363_7_cursor.fork_read_zipper();
            let v363_7_head = Path::from_slice(&[v363_7_byte]);
            let v364_2: Space = singleton(&(v363_7_head));
            let v364_3: Space = intersect(&(*CONSTANT_2),&(v364_2));
            let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
            drop(v364_3);
            let v364_5: Space = subtract(&(*CONSTANT_1),&(v364_4));
            drop(v364_4);
            let v364_8: Space = if (v364_5).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v363_6),&(v363_7_head));
              let v365_7: Space = routine_32(c, &(v365_6), &(*p1), &(v363_7_tail).make_space());
              compose(&(v364_5),&(v365_7))
            };
            drop(v364_5);
            let v364_9: Space = intersect(&(*CONSTANT_2),&(v364_2));
            drop(v364_2);
            let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
            drop(v364_9);
            let v364_12: Space = if (v364_10).is_empty() { Space::new() } else {
              let v366_6: Path = concat_path(&(v363_6),&(v363_7_head));
              let v366_11: Space = routine_33(c, &(v366_6), &(*p1), &(v363_7_tail).make_space());
              drop(v366_6);
              compose(&(v364_10),&(v366_11))
            };
            drop(v364_10);
            let v364_13: Space = unite(&(v364_8),&(v364_12));
            v363_7.join_into((v364_13).clone());
            }
            v363_7_cursor.ascend(1);
          }
          drop(v363_7_cursor);
          compose(&(v362_5),&(v363_7))
        };
        drop(v362_5);
        let v362_9: Space = intersect(&(*CONSTANT_2),&(v362_2));
        drop(v362_2);
        let v362_10: Space = if has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
        drop(v362_9);
        let v362_12: Space = if (v362_10).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v361_6),&(v361_7_head));
          let mut v367_11 = Space::new();
          let mut v367_11_cursor = (v361_7_tail).read_zipper();
          for v367_11_byte in v367_11_cursor.child_mask().iter() {
            v367_11_cursor.descend_to_byte(v367_11_byte);
            {
            let v367_11_tail = v367_11_cursor.fork_read_zipper();
            let v367_11_head = Path::from_slice(&[v367_11_byte]);
            let v368_2: Space = singleton(&(v367_11_head));
            let v368_3: Space = intersect(&(*CONSTANT_2),&(v368_2));
            let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
            drop(v368_3);
            let v368_5: Space = subtract(&(*CONSTANT_1),&(v368_4));
            drop(v368_4);
            let v368_8: Space = if (v368_5).is_empty() { Space::new() } else {
              let v369_6: Path = concat_path(&(v367_6),&(v367_11_head));
              let v369_7: Space = routine_32(c, &(v369_6), &(*p1), &(v367_11_tail).make_space());
              compose(&(v368_5),&(v369_7))
            };
            drop(v368_5);
            let v368_9: Space = intersect(&(*CONSTANT_2),&(v368_2));
            drop(v368_2);
            let v368_10: Space = if has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
            drop(v368_9);
            let v368_12: Space = if (v368_10).is_empty() { Space::new() } else {
              let v370_6: Path = concat_path(&(v367_6),&(v367_11_head));
              let v370_11: Space = routine_19(c, &(v370_6), &(*p1), &(v367_11_tail).make_space());
              drop(v370_6);
              compose(&(v368_10),&(v370_11))
            };
            drop(v368_10);
            let v368_13: Space = unite(&(v368_8),&(v368_12));
            v367_11.join_into((v368_13).clone());
            }
            v367_11_cursor.ascend(1);
          }
          drop(v367_11_cursor);
          drop(v367_6);
          compose(&(v362_10),&(v367_11))
        };
        drop(v362_10);
        let v362_13: Space = unite(&(v362_8),&(v362_12));
        v361_7.join_into((v362_13).clone());
        }
        v361_7_cursor.ascend(1);
      }
      drop(v361_7_cursor);
      compose(&(v360_5),&(v361_7))
    };
    drop(v360_5);
    let v360_9: Space = intersect(&(*CONSTANT_2),&(v360_2));
    drop(v360_2);
    let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
    drop(v360_9);
    let v360_12: Space = if (v360_10).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&(v359_21_head));
      let mut v371_11 = Space::new();
      let mut v371_11_cursor = (v359_21_tail).read_zipper();
      for v371_11_byte in v371_11_cursor.child_mask().iter() {
        v371_11_cursor.descend_to_byte(v371_11_byte);
        {
        let v371_11_tail = v371_11_cursor.fork_read_zipper();
        let v371_11_head = Path::from_slice(&[v371_11_byte]);
        let v372_2: Space = singleton(&(v371_11_head));
        let v372_3: Space = intersect(&(*CONSTANT_2),&(v372_2));
        let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = subtract(&(*CONSTANT_1),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (v372_5).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&(v371_11_head));
          let mut v373_7 = Space::new();
          let mut v373_7_cursor = (v371_11_tail).read_zipper();
          for v373_7_byte in v373_7_cursor.child_mask().iter() {
            v373_7_cursor.descend_to_byte(v373_7_byte);
            {
            let v373_7_tail = v373_7_cursor.fork_read_zipper();
            let v373_7_head = Path::from_slice(&[v373_7_byte]);
            let v374_2: Space = singleton(&(v373_7_head));
            let v374_3: Space = intersect(&(*CONSTANT_2),&(v374_2));
            let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = subtract(&(*CONSTANT_1),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (v374_5).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&(v373_7_head));
              let v375_7: Space = routine_32(c, &(v375_6), &(*p1), &(v373_7_tail).make_space());
              compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = intersect(&(*CONSTANT_2),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (v374_10).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&(v373_7_head));
              let v376_11: Space = routine_33(c, &(v376_6), &(*p1), &(v373_7_tail).make_space());
              drop(v376_6);
              compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = unite(&(v374_8),&(v374_12));
            v373_7.join_into((v374_13).clone());
            }
            v373_7_cursor.ascend(1);
          }
          drop(v373_7_cursor);
          compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = intersect(&(*CONSTANT_2),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_11: Space = compose(&(v372_10),&(v371_11_tail));
        drop(v372_10);
        let v377_6: Path = concat_path(&(v371_6),&(v371_11_head));
        let v372_12: Space = wrap(&(v372_11),&(v377_6));
        drop(v372_11);
        let v372_13: Space = wrap(&(v372_12),&(*p1));
        drop(v372_12);
        let v372_14: Space = unite(&(v372_8),&(v372_13));
        drop(v372_13);
        v371_11.join_into((v372_14).clone());
        }
        v371_11_cursor.ascend(1);
      }
      drop(v371_11_cursor);
      drop(v371_6);
      compose(&(v360_10),&(v371_11))
    };
    drop(v360_10);
    let v360_13: Space = unite(&(v360_8),&(v360_12));
    v359_21.join_into((v360_13).clone());
    }
    v359_21_cursor.ascend(1);
  }
  drop(v359_21_cursor);
  (v359_21).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v378_15 = Space::new();
  let mut v378_15_cursor = (*s0).read_zipper();
  for v378_15_byte in v378_15_cursor.child_mask().iter() {
    v378_15_cursor.descend_to_byte(v378_15_byte);
    {
    let v378_15_tail = v378_15_cursor.fork_read_zipper();
    let v378_15_head = Path::from_slice(&[v378_15_byte]);
    let v379_2: Space = singleton(&(v378_15_head));
    let v379_3: Space = intersect(&(*CONSTANT_2),&(v379_2));
    let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
    drop(v379_3);
    let v379_5: Space = subtract(&(*CONSTANT_1),&(v379_4));
    drop(v379_4);
    let v379_8: Space = if (v379_5).is_empty() { Space::new() } else {
      let v380_6: Path = concat_path(&(*p0),&(v378_15_head));
      let mut v380_7 = Space::new();
      let mut v380_7_cursor = (v378_15_tail).read_zipper();
      for v380_7_byte in v380_7_cursor.child_mask().iter() {
        v380_7_cursor.descend_to_byte(v380_7_byte);
        {
        let v380_7_tail = v380_7_cursor.fork_read_zipper();
        let v380_7_head = Path::from_slice(&[v380_7_byte]);
        let v381_2: Space = singleton(&(v380_7_head));
        let v381_3: Space = intersect(&(*CONSTANT_2),&(v381_2));
        let v381_4: Space = if has_head(&(v381_3)) { singleton(&[]) } else { Space::new() };
        drop(v381_3);
        let v381_5: Space = subtract(&(*CONSTANT_1),&(v381_4));
        drop(v381_4);
        let v381_8: Space = if (v381_5).is_empty() { Space::new() } else {
          let v382_6: Path = concat_path(&(v380_6),&(v380_7_head));
          let mut v382_7 = Space::new();
          let mut v382_7_cursor = (v380_7_tail).read_zipper();
          for v382_7_byte in v382_7_cursor.child_mask().iter() {
            v382_7_cursor.descend_to_byte(v382_7_byte);
            {
            let v382_7_tail = v382_7_cursor.fork_read_zipper();
            let v382_7_head = Path::from_slice(&[v382_7_byte]);
            let v383_2: Space = singleton(&(v382_7_head));
            let v383_3: Space = intersect(&(*CONSTANT_2),&(v383_2));
            let v383_4: Space = if has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
            drop(v383_3);
            let v383_5: Space = subtract(&(*CONSTANT_1),&(v383_4));
            drop(v383_4);
            let v383_8: Space = if (v383_5).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v382_6),&(v382_7_head));
              let v384_7: Space = routine_32(c, &(v384_6), &(*p1), &(v382_7_tail).make_space());
              compose(&(v383_5),&(v384_7))
            };
            drop(v383_5);
            let v383_9: Space = intersect(&(*CONSTANT_2),&(v383_2));
            drop(v383_2);
            let v383_10: Space = if has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
            drop(v383_9);
            let v383_12: Space = if (v383_10).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v382_6),&(v382_7_head));
              let v385_11: Space = routine_33(c, &(v385_6), &(*p1), &(v382_7_tail).make_space());
              drop(v385_6);
              compose(&(v383_10),&(v385_11))
            };
            drop(v383_10);
            let v383_13: Space = unite(&(v383_8),&(v383_12));
            v382_7.join_into((v383_13).clone());
            }
            v382_7_cursor.ascend(1);
          }
          drop(v382_7_cursor);
          compose(&(v381_5),&(v382_7))
        };
        drop(v381_5);
        let v381_9: Space = intersect(&(*CONSTANT_2),&(v381_2));
        drop(v381_2);
        let v381_10: Space = if has_head(&(v381_9)) { singleton(&[]) } else { Space::new() };
        drop(v381_9);
        let v381_12: Space = if (v381_10).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v380_6),&(v380_7_head));
          let mut v386_11 = Space::new();
          let mut v386_11_cursor = (v380_7_tail).read_zipper();
          for v386_11_byte in v386_11_cursor.child_mask().iter() {
            v386_11_cursor.descend_to_byte(v386_11_byte);
            {
            let v386_11_tail = v386_11_cursor.fork_read_zipper();
            let v386_11_head = Path::from_slice(&[v386_11_byte]);
            let v387_2: Space = singleton(&(v386_11_head));
            let v387_3: Space = intersect(&(*CONSTANT_2),&(v387_2));
            let v387_4: Space = if has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
            drop(v387_3);
            let v387_5: Space = subtract(&(*CONSTANT_1),&(v387_4));
            drop(v387_4);
            let v387_8: Space = if (v387_5).is_empty() { Space::new() } else {
              let v388_6: Path = concat_path(&(v386_6),&(v386_11_head));
              let v388_7: Space = routine_32(c, &(v388_6), &(*p1), &(v386_11_tail).make_space());
              compose(&(v387_5),&(v388_7))
            };
            drop(v387_5);
            let v387_9: Space = intersect(&(*CONSTANT_2),&(v387_2));
            drop(v387_2);
            let v387_10: Space = if has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
            drop(v387_9);
            let v387_12: Space = if (v387_10).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v386_6),&(v386_11_head));
              let v389_11: Space = routine_19(c, &(v389_6), &(*p1), &(v386_11_tail).make_space());
              drop(v389_6);
              compose(&(v387_10),&(v389_11))
            };
            drop(v387_10);
            let v387_13: Space = unite(&(v387_8),&(v387_12));
            v386_11.join_into((v387_13).clone());
            }
            v386_11_cursor.ascend(1);
          }
          drop(v386_11_cursor);
          drop(v386_6);
          compose(&(v381_10),&(v386_11))
        };
        drop(v381_10);
        let v381_13: Space = unite(&(v381_8),&(v381_12));
        v380_7.join_into((v381_13).clone());
        }
        v380_7_cursor.ascend(1);
      }
      drop(v380_7_cursor);
      compose(&(v379_5),&(v380_7))
    };
    drop(v379_5);
    let v379_9: Space = intersect(&(*CONSTANT_2),&(v379_2));
    drop(v379_2);
    let v379_10: Space = if has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
    drop(v379_9);
    let v379_11: Space = compose(&(v379_10),&(v378_15_tail));
    drop(v379_10);
    let v390_6: Path = concat_path(&(*p0),&(v378_15_head));
    let v379_12: Space = wrap(&(v379_11),&(v390_6));
    drop(v379_11);
    let v379_13: Space = wrap(&(v379_12),&(*p1));
    drop(v379_12);
    let v379_14: Space = unite(&(v379_8),&(v379_13));
    drop(v379_13);
    v378_15.join_into((v379_14).clone());
    }
    v378_15_cursor.ascend(1);
  }
  drop(v378_15_cursor);
  (v378_15).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v391_3: Space = wrap(&(*s0),&(*p0));
  let v391_4: Space = wrap(&(v391_3),&(*p1));
  drop(v391_3);
  (v391_4).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v392_10 = Space::new();
  let mut v392_10_cursor = (*s0).read_zipper();
  for v392_10_byte in v392_10_cursor.child_mask().iter() {
    v392_10_cursor.descend_to_byte(v392_10_byte);
    {
    let v392_10_tail = v392_10_cursor.fork_read_zipper();
    let v392_10_head = Path::from_slice(&[v392_10_byte]);
    let v393_2: Space = singleton(&(v392_10_head));
    let v393_3: Space = intersect(&(*CONSTANT_2),&(v393_2));
    let v393_4: Space = if has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_5: Space = subtract(&(*CONSTANT_1),&(v393_4));
    drop(v393_4);
    let mut v393_6 = Space::new();
    let mut v393_6_cursor = (v392_10_tail).read_zipper();
    for v393_6_byte in v393_6_cursor.child_mask().iter() {
      v393_6_cursor.descend_to_byte(v393_6_byte);
      {
      let v393_6_tail = v393_6_cursor.fork_read_zipper();
      let v393_6_head = Path::from_slice(&[v393_6_byte]);
      let v394_2: Space = Space::new();
      v393_6.join_into((v394_2).clone());
      }
      v393_6_cursor.ascend(1);
    }
    drop(v393_6_cursor);
    let v393_7: Space = compose(&(v393_5),&(v393_6));
    drop(v393_5);
    drop(v393_6);
    let v393_8: Space = intersect(&(*CONSTANT_2),&(v393_2));
    drop(v393_2);
    let v393_9: Space = if has_head(&(v393_8)) { singleton(&[]) } else { Space::new() };
    drop(v393_8);
    let v393_12: Space = if (v393_9).is_empty() { Space::new() } else {
      let v395_10: Path = concat_path(&(*p0),&(v392_10_head));
      let mut v395_11 = Space::new();
      let mut v395_11_cursor = (v392_10_tail).read_zipper();
      for v395_11_byte in v395_11_cursor.child_mask().iter() {
        v395_11_cursor.descend_to_byte(v395_11_byte);
        {
        let v395_11_tail = v395_11_cursor.fork_read_zipper();
        let v395_11_head = Path::from_slice(&[v395_11_byte]);
        let v396_2: Space = singleton(&(v395_11_head));
        let v396_3: Space = intersect(&(*CONSTANT_2),&(v396_2));
        drop(v396_2);
        let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
        drop(v396_3);
        let v396_7: Space = if (v396_4).is_empty() { Space::new() } else {
          let v397_5: Path = concat_path(&(v395_10),&(v395_11_head));
          let mut v397_6 = Space::new();
          let mut v397_6_cursor = (v395_11_tail).read_zipper();
          for v397_6_byte in v397_6_cursor.child_mask().iter() {
            v397_6_cursor.descend_to_byte(v397_6_byte);
            {
            let v397_6_tail = v397_6_cursor.fork_read_zipper();
            let v397_6_head = Path::from_slice(&[v397_6_byte]);
            let v398_2: Space = singleton(&(v397_6_head));
            let v398_3: Space = intersect(&(*CONSTANT_2),&(v398_2));
            let v398_4: Space = if has_head(&(v398_3)) { singleton(&[]) } else { Space::new() };
            drop(v398_3);
            let v398_5: Space = subtract(&(*CONSTANT_1),&(v398_4));
            drop(v398_4);
            let v398_7: Space = if (v398_5).is_empty() { Space::new() } else {
              let v399_6: Space = routine_4(c, &(v397_6_head), &(v397_5), &(v397_6_tail).make_space(), &(*s1));
              compose(&(v398_5),&(v399_6))
            };
            drop(v398_5);
            let v398_8: Space = intersect(&(*CONSTANT_2),&(v398_2));
            drop(v398_2);
            let v398_9: Space = if has_head(&(v398_8)) { singleton(&[]) } else { Space::new() };
            drop(v398_8);
            let v398_11: Space = if (v398_9).is_empty() { Space::new() } else {
              let v400_10: Space = routine_5(c, &(v397_6_head), &(v397_5), &(v397_6_tail).make_space(), &(*s1));
              compose(&(v398_9),&(v400_10))
            };
            drop(v398_9);
            let v398_12: Space = unite(&(v398_7),&(v398_11));
            v397_6.join_into((v398_12).clone());
            }
            v397_6_cursor.ascend(1);
          }
          drop(v397_6_cursor);
          drop(v397_5);
          compose(&(v396_4),&(v397_6))
        };
        drop(v396_4);
        v395_11.join_into((v396_7).clone());
        }
        v395_11_cursor.ascend(1);
      }
      drop(v395_11_cursor);
      drop(v395_10);
      compose(&(v393_9),&(v395_11))
    };
    drop(v393_9);
    let v393_13: Space = unite(&(v393_7),&(v393_12));
    drop(v393_7);
    v392_10.join_into((v393_13).clone());
    }
    v392_10_cursor.ascend(1);
  }
  drop(v392_10_cursor);
  (v392_10).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v401_15 = Space::new();
  let mut v401_15_cursor = (*s0).read_zipper();
  for v401_15_byte in v401_15_cursor.child_mask().iter() {
    v401_15_cursor.descend_to_byte(v401_15_byte);
    {
    let v401_15_tail = v401_15_cursor.fork_read_zipper();
    let v401_15_head = Path::from_slice(&[v401_15_byte]);
    let v402_2: Space = singleton(&(v401_15_head));
    let v402_3: Space = intersect(&(*CONSTANT_2),&(v402_2));
    let v402_4: Space = if has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
    drop(v402_3);
    let v402_5: Space = subtract(&(*CONSTANT_1),&(v402_4));
    drop(v402_4);
    let mut v402_6 = Space::new();
    let mut v402_6_cursor = (v401_15_tail).read_zipper();
    for v402_6_byte in v402_6_cursor.child_mask().iter() {
      v402_6_cursor.descend_to_byte(v402_6_byte);
      {
      let v402_6_tail = v402_6_cursor.fork_read_zipper();
      let v402_6_head = Path::from_slice(&[v402_6_byte]);
      let v403_2: Space = Space::new();
      v402_6.join_into((v403_2).clone());
      }
      v402_6_cursor.ascend(1);
    }
    drop(v402_6_cursor);
    let v402_7: Space = compose(&(v402_5),&(v402_6));
    drop(v402_5);
    drop(v402_6);
    let v402_8: Space = intersect(&(*CONSTANT_2),&(v402_2));
    drop(v402_2);
    let v402_9: Space = if has_head(&(v402_8)) { singleton(&[]) } else { Space::new() };
    drop(v402_8);
    let v402_12: Space = if (v402_9).is_empty() { Space::new() } else {
      let v404_10: Path = concat_path(&(*p0),&(v401_15_head));
      let mut v404_11 = Space::new();
      let mut v404_11_cursor = (v401_15_tail).read_zipper();
      for v404_11_byte in v404_11_cursor.child_mask().iter() {
        v404_11_cursor.descend_to_byte(v404_11_byte);
        {
        let v404_11_tail = v404_11_cursor.fork_read_zipper();
        let v404_11_head = Path::from_slice(&[v404_11_byte]);
        let v405_2: Space = singleton(&(v404_11_head));
        let v405_3: Space = intersect(&(*CONSTANT_2),&(v405_2));
        let v405_4: Space = if has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
        drop(v405_3);
        let v405_5: Space = subtract(&(*CONSTANT_1),&(v405_4));
        drop(v405_4);
        let v405_7: Space = if (v405_5).is_empty() { Space::new() } else {
          let mut v406_6 = Space::new();
          let mut v406_6_cursor = (v404_11_tail).read_zipper();
          for v406_6_byte in v406_6_cursor.child_mask().iter() {
            v406_6_cursor.descend_to_byte(v406_6_byte);
            {
            let v406_6_tail = v406_6_cursor.fork_read_zipper();
            let v406_6_head = Path::from_slice(&[v406_6_byte]);
            let v407_2: Space = singleton(&(v406_6_head));
            let v407_3: Space = intersect(&(*CONSTANT_2),&(v407_2));
            let v407_4: Space = if has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
            drop(v407_3);
            let v407_5: Space = subtract(&(*CONSTANT_1),&(v407_4));
            drop(v407_4);
            let v407_8: Space = if (v407_5).is_empty() { Space::new() } else {
              let v408_6: Path = concat_path(&(v404_11_head),&(v406_6_head));
              let v408_7: Space = routine_8(c, &(v408_6), &(v404_10), &(v406_6_tail).make_space(), &(*s1));
              compose(&(v407_5),&(v408_7))
            };
            drop(v407_5);
            let v407_9: Space = intersect(&(*CONSTANT_2),&(v407_2));
            drop(v407_2);
            let v407_10: Space = if has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
            drop(v407_9);
            let v407_12: Space = if (v407_10).is_empty() { Space::new() } else {
              let v409_6: Path = concat_path(&(v404_11_head),&(v406_6_head));
              let v409_11: Space = routine_9(c, &(v409_6), &(v404_10), &(v406_6_tail).make_space(), &(*s1));
              drop(v409_6);
              compose(&(v407_10),&(v409_11))
            };
            drop(v407_10);
            let v407_13: Space = unite(&(v407_8),&(v407_12));
            v406_6.join_into((v407_13).clone());
            }
            v406_6_cursor.ascend(1);
          }
          drop(v406_6_cursor);
          compose(&(v405_5),&(v406_6))
        };
        drop(v405_5);
        let v405_8: Space = intersect(&(*CONSTANT_2),&(v405_2));
        drop(v405_2);
        let v405_9: Space = if has_head(&(v405_8)) { singleton(&[]) } else { Space::new() };
        drop(v405_8);
        let v405_11: Space = if (v405_9).is_empty() { Space::new() } else {
          let mut v410_10 = Space::new();
          let mut v410_10_cursor = (v404_11_tail).read_zipper();
          for v410_10_byte in v410_10_cursor.child_mask().iter() {
            v410_10_cursor.descend_to_byte(v410_10_byte);
            {
            let v410_10_tail = v410_10_cursor.fork_read_zipper();
            let v410_10_head = Path::from_slice(&[v410_10_byte]);
            let v411_2: Space = singleton(&(v410_10_head));
            let v411_3: Space = intersect(&(*CONSTANT_2),&(v411_2));
            let v411_4: Space = if has_head(&(v411_3)) { singleton(&[]) } else { Space::new() };
            drop(v411_3);
            let v411_5: Space = subtract(&(*CONSTANT_1),&(v411_4));
            drop(v411_4);
            let v411_8: Space = if (v411_5).is_empty() { Space::new() } else {
              let v412_6: Path = concat_path(&(v404_11_head),&(v410_10_head));
              let v412_7: Space = routine_8(c, &(v412_6), &(v404_10), &(v410_10_tail).make_space(), &(*s1));
              compose(&(v411_5),&(v412_7))
            };
            drop(v411_5);
            let v411_9: Space = intersect(&(*CONSTANT_2),&(v411_2));
            drop(v411_2);
            let v411_10: Space = if has_head(&(v411_9)) { singleton(&[]) } else { Space::new() };
            drop(v411_9);
            let v411_12: Space = if (v411_10).is_empty() { Space::new() } else {
              let v413_6: Path = concat_path(&(v404_11_head),&(v410_10_head));
              let v413_11: Space = routine_10(c, &(v413_6), &(v404_10), &(v410_10_tail).make_space(), &(*s1));
              drop(v413_6);
              compose(&(v411_10),&(v413_11))
            };
            drop(v411_10);
            let v411_13: Space = unite(&(v411_8),&(v411_12));
            v410_10.join_into((v411_13).clone());
            }
            v410_10_cursor.ascend(1);
          }
          drop(v410_10_cursor);
          compose(&(v405_9),&(v410_10))
        };
        drop(v405_9);
        let v405_12: Space = unite(&(v405_7),&(v405_11));
        v404_11.join_into((v405_12).clone());
        }
        v404_11_cursor.ascend(1);
      }
      drop(v404_11_cursor);
      drop(v404_10);
      compose(&(v402_9),&(v404_11))
    };
    drop(v402_9);
    let v402_13: Space = unite(&(v402_7),&(v402_12));
    drop(v402_7);
    v401_15.join_into((v402_13).clone());
    }
    v401_15_cursor.ascend(1);
  }
  drop(v401_15_cursor);
  (v401_15).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v414_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v414_21: Space = unwrap(&(v414_20),&(*p0));
  drop(v414_20);
  let mut v414_28 = Space::new();
  let mut v414_28_cursor = (*s0).read_zipper();
  for v414_28_byte in v414_28_cursor.child_mask().iter() {
    v414_28_cursor.descend_to_byte(v414_28_byte);
    {
    let v414_28_tail = v414_28_cursor.fork_read_zipper();
    let v414_28_head = Path::from_slice(&[v414_28_byte]);
    let v415_2: Space = singleton(&(v414_28_head));
    let v415_3: Space = intersect(&(*CONSTANT_2),&(v415_2));
    let v415_4: Space = if has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
    drop(v415_3);
    let v415_5: Space = subtract(&(*CONSTANT_1),&(v415_4));
    drop(v415_4);
    let v415_8: Space = if (v415_5).is_empty() { Space::new() } else {
      let v416_6: Path = concat_path(&(*p0),&(v414_28_head));
      let mut v416_7 = Space::new();
      let mut v416_7_cursor = (v414_28_tail).read_zipper();
      for v416_7_byte in v416_7_cursor.child_mask().iter() {
        v416_7_cursor.descend_to_byte(v416_7_byte);
        {
        let v416_7_tail = v416_7_cursor.fork_read_zipper();
        let v416_7_head = Path::from_slice(&[v416_7_byte]);
        let v417_2: Space = singleton(&(v416_7_head));
        let v417_3: Space = intersect(&(*CONSTANT_2),&(v417_2));
        let v417_4: Space = if has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
        drop(v417_3);
        let v417_5: Space = subtract(&(*CONSTANT_1),&(v417_4));
        drop(v417_4);
        let v417_8: Space = if (v417_5).is_empty() { Space::new() } else {
          let v418_6: Path = concat_path(&(v416_6),&(v416_7_head));
          let mut v418_7 = Space::new();
          let mut v418_7_cursor = (v416_7_tail).read_zipper();
          for v418_7_byte in v418_7_cursor.child_mask().iter() {
            v418_7_cursor.descend_to_byte(v418_7_byte);
            {
            let v418_7_tail = v418_7_cursor.fork_read_zipper();
            let v418_7_head = Path::from_slice(&[v418_7_byte]);
            let v419_2: Space = singleton(&(v418_7_head));
            let v419_3: Space = intersect(&(*CONSTANT_2),&(v419_2));
            let v419_4: Space = if has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
            drop(v419_3);
            let v419_5: Space = subtract(&(*CONSTANT_1),&(v419_4));
            drop(v419_4);
            let v419_8: Space = if (v419_5).is_empty() { Space::new() } else {
              let v420_6: Path = concat_path(&(v418_6),&(v418_7_head));
              let v420_7: Space = routine_34(c, &(v420_6), &(*p1), &(v418_7_tail).make_space(), &(*s1));
              compose(&(v419_5),&(v420_7))
            };
            drop(v419_5);
            let v419_9: Space = intersect(&(*CONSTANT_2),&(v419_2));
            drop(v419_2);
            let v419_10: Space = if has_head(&(v419_9)) { singleton(&[]) } else { Space::new() };
            drop(v419_9);
            let v419_12: Space = if (v419_10).is_empty() { Space::new() } else {
              let v421_6: Path = concat_path(&(v418_6),&(v418_7_head));
              let v421_11: Space = routine_35(c, &(v421_6), &(*p1), &(v418_7_tail).make_space(), &(*s1));
              drop(v421_6);
              compose(&(v419_10),&(v421_11))
            };
            drop(v419_10);
            let v419_13: Space = unite(&(v419_8),&(v419_12));
            v418_7.join_into((v419_13).clone());
            }
            v418_7_cursor.ascend(1);
          }
          drop(v418_7_cursor);
          compose(&(v417_5),&(v418_7))
        };
        drop(v417_5);
        let v417_9: Space = intersect(&(*CONSTANT_2),&(v417_2));
        drop(v417_2);
        let v417_10: Space = if has_head(&(v417_9)) { singleton(&[]) } else { Space::new() };
        drop(v417_9);
        let v417_12: Space = if (v417_10).is_empty() { Space::new() } else {
          let v422_6: Path = concat_path(&(v416_6),&(v416_7_head));
          let mut v422_11 = Space::new();
          let mut v422_11_cursor = (v416_7_tail).read_zipper();
          for v422_11_byte in v422_11_cursor.child_mask().iter() {
            v422_11_cursor.descend_to_byte(v422_11_byte);
            {
            let v422_11_tail = v422_11_cursor.fork_read_zipper();
            let v422_11_head = Path::from_slice(&[v422_11_byte]);
            let v423_2: Space = singleton(&(v422_11_head));
            let v423_3: Space = intersect(&(*CONSTANT_2),&(v423_2));
            let v423_4: Space = if has_head(&(v423_3)) { singleton(&[]) } else { Space::new() };
            drop(v423_3);
            let v423_5: Space = subtract(&(*CONSTANT_1),&(v423_4));
            drop(v423_4);
            let v423_8: Space = if (v423_5).is_empty() { Space::new() } else {
              let v424_6: Path = concat_path(&(v422_6),&(v422_11_head));
              let v424_7: Space = routine_34(c, &(v424_6), &(*p1), &(v422_11_tail).make_space(), &(*s1));
              compose(&(v423_5),&(v424_7))
            };
            drop(v423_5);
            let v423_9: Space = intersect(&(*CONSTANT_2),&(v423_2));
            drop(v423_2);
            let v423_10: Space = if has_head(&(v423_9)) { singleton(&[]) } else { Space::new() };
            drop(v423_9);
            let v423_12: Space = if (v423_10).is_empty() { Space::new() } else {
              let v425_6: Path = concat_path(&(v422_6),&(v422_11_head));
              let v425_11: Space = routine_10(c, &(v425_6), &(*p1), &(v422_11_tail).make_space(), &(*s1));
              drop(v425_6);
              compose(&(v423_10),&(v425_11))
            };
            drop(v423_10);
            let v423_13: Space = unite(&(v423_8),&(v423_12));
            v422_11.join_into((v423_13).clone());
            }
            v422_11_cursor.ascend(1);
          }
          drop(v422_11_cursor);
          drop(v422_6);
          compose(&(v417_10),&(v422_11))
        };
        drop(v417_10);
        let v417_13: Space = unite(&(v417_8),&(v417_12));
        v416_7.join_into((v417_13).clone());
        }
        v416_7_cursor.ascend(1);
      }
      drop(v416_7_cursor);
      compose(&(v415_5),&(v416_7))
    };
    drop(v415_5);
    let v415_9: Space = intersect(&(*CONSTANT_2),&(v415_2));
    drop(v415_2);
    let v415_10: Space = if has_head(&(v415_9)) { singleton(&[]) } else { Space::new() };
    drop(v415_9);
    let v415_13: Space = if (v415_10).is_empty() { Space::new() } else {
      let v426_6: Path = concat_path(&(*p0),&(v414_28_head));
      let v426_11: Space = unwrap(&(v414_21),&(v414_28_head));
      let mut v426_12 = Space::new();
      let mut v426_12_cursor = (v414_28_tail).read_zipper();
      for v426_12_byte in v426_12_cursor.child_mask().iter() {
        v426_12_cursor.descend_to_byte(v426_12_byte);
        {
        let v426_12_tail = v426_12_cursor.fork_read_zipper();
        let v426_12_head = Path::from_slice(&[v426_12_byte]);
        let v427_2: Space = singleton(&(v426_12_head));
        let v427_3: Space = intersect(&(*CONSTANT_2),&(v427_2));
        let v427_4: Space = if has_head(&(v427_3)) { singleton(&[]) } else { Space::new() };
        drop(v427_3);
        let v427_5: Space = subtract(&(*CONSTANT_1),&(v427_4));
        drop(v427_4);
        let v427_8: Space = if (v427_5).is_empty() { Space::new() } else {
          let v428_6: Path = concat_path(&(v426_6),&(v426_12_head));
          let mut v428_7 = Space::new();
          let mut v428_7_cursor = (v426_12_tail).read_zipper();
          for v428_7_byte in v428_7_cursor.child_mask().iter() {
            v428_7_cursor.descend_to_byte(v428_7_byte);
            {
            let v428_7_tail = v428_7_cursor.fork_read_zipper();
            let v428_7_head = Path::from_slice(&[v428_7_byte]);
            let v429_2: Space = singleton(&(v428_7_head));
            let v429_3: Space = intersect(&(*CONSTANT_2),&(v429_2));
            let v429_4: Space = if has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
            drop(v429_3);
            let v429_5: Space = subtract(&(*CONSTANT_1),&(v429_4));
            drop(v429_4);
            let v429_8: Space = if (v429_5).is_empty() { Space::new() } else {
              let v430_6: Path = concat_path(&(v428_6),&(v428_7_head));
              let v430_7: Space = routine_34(c, &(v430_6), &(*p1), &(v428_7_tail).make_space(), &(*s1));
              compose(&(v429_5),&(v430_7))
            };
            drop(v429_5);
            let v429_9: Space = intersect(&(*CONSTANT_2),&(v429_2));
            drop(v429_2);
            let v429_10: Space = if has_head(&(v429_9)) { singleton(&[]) } else { Space::new() };
            drop(v429_9);
            let v429_12: Space = if (v429_10).is_empty() { Space::new() } else {
              let v431_6: Path = concat_path(&(v428_6),&(v428_7_head));
              let v431_11: Space = routine_35(c, &(v431_6), &(*p1), &(v428_7_tail).make_space(), &(*s1));
              drop(v431_6);
              compose(&(v429_10),&(v431_11))
            };
            drop(v429_10);
            let v429_13: Space = unite(&(v429_8),&(v429_12));
            v428_7.join_into((v429_13).clone());
            }
            v428_7_cursor.ascend(1);
          }
          drop(v428_7_cursor);
          drop(v428_6);
          compose(&(v427_5),&(v428_7))
        };
        drop(v427_5);
        let v427_9: Space = intersect(&(*CONSTANT_2),&(v427_2));
        drop(v427_2);
        let v427_10: Space = if has_head(&(v427_9)) { singleton(&[]) } else { Space::new() };
        drop(v427_9);
        let v427_13: Space = if (v427_10).is_empty() { Space::new() } else {
          let v432_11: Space = unwrap(&(v426_11),&(v426_12_head));
          let mut v432_12 = Space::new();
          let mut v432_12_cursor = (v432_11).read_zipper();
          for v432_12_byte in v432_12_cursor.child_mask().iter() {
            v432_12_cursor.descend_to_byte(v432_12_byte);
            {
            let v432_12_tail = v432_12_cursor.fork_read_zipper();
            let v432_12_head = Path::from_slice(&[v432_12_byte]);
            let v433_2: Space = singleton(&(v432_12_head));
            let v433_3: Space = intersect(&(*CONSTANT_2),&(v433_2));
            let v433_4: Space = if has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
            drop(v433_3);
            let v433_5: Space = subtract(&(*CONSTANT_1),&(v433_4));
            drop(v433_4);
            let v433_7: Space = if (v433_5).is_empty() { Space::new() } else {
              let v434_6: Space = routine_13(c, &(v432_12_head), &(*p1), &(v432_12_tail).make_space());
              compose(&(v433_5),&(v434_6))
            };
            drop(v433_5);
            let v433_8: Space = intersect(&(*CONSTANT_2),&(v433_2));
            drop(v433_2);
            let v433_9: Space = if has_head(&(v433_8)) { singleton(&[]) } else { Space::new() };
            drop(v433_8);
            let v433_11: Space = if (v433_9).is_empty() { Space::new() } else {
              let v435_10: Space = routine_14(c, &(v432_12_head), &(*p1), &(v432_12_tail).make_space());
              compose(&(v433_9),&(v435_10))
            };
            drop(v433_9);
            let v433_12: Space = unite(&(v433_7),&(v433_11));
            v432_12.join_into((v433_12).clone());
            }
            v432_12_cursor.ascend(1);
          }
          drop(v432_12_cursor);
          drop(v432_11);
          compose(&(v427_10),&(v432_12))
        };
        drop(v427_10);
        let v427_14: Space = unite(&(v427_8),&(v427_13));
        v426_12.join_into((v427_14).clone());
        }
        v426_12_cursor.ascend(1);
      }
      drop(v426_12_cursor);
      drop(v426_6);
      drop(v426_11);
      compose(&(v415_10),&(v426_12))
    };
    drop(v415_10);
    let v415_14: Space = unite(&(v415_8),&(v415_13));
    v414_28.join_into((v415_14).clone());
    }
    v414_28_cursor.ascend(1);
  }
  drop(v414_28_cursor);
  drop(v414_21);
  (v414_28).clone()
}

fn routine_23(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v436_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v436_9: Space = unwrap(&(v436_8),&(*p0));
  drop(v436_8);
  let mut v436_28 = Space::new();
  let mut v436_28_cursor = (*s0).read_zipper();
  for v436_28_byte in v436_28_cursor.child_mask().iter() {
    v436_28_cursor.descend_to_byte(v436_28_byte);
    {
    let v436_28_tail = v436_28_cursor.fork_read_zipper();
    let v436_28_head = Path::from_slice(&[v436_28_byte]);
    let v437_2: Space = singleton(&(v436_28_head));
    let v437_3: Space = intersect(&(*CONSTANT_2),&(v437_2));
    let v437_4: Space = if has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
    drop(v437_3);
    let v437_5: Space = subtract(&(*CONSTANT_1),&(v437_4));
    drop(v437_4);
    let v437_8: Space = if (v437_5).is_empty() { Space::new() } else {
      let v438_6: Path = concat_path(&(*p0),&(v436_28_head));
      let mut v438_7 = Space::new();
      let mut v438_7_cursor = (v436_28_tail).read_zipper();
      for v438_7_byte in v438_7_cursor.child_mask().iter() {
        v438_7_cursor.descend_to_byte(v438_7_byte);
        {
        let v438_7_tail = v438_7_cursor.fork_read_zipper();
        let v438_7_head = Path::from_slice(&[v438_7_byte]);
        let v439_2: Space = singleton(&(v438_7_head));
        let v439_3: Space = intersect(&(*CONSTANT_2),&(v439_2));
        let v439_4: Space = if has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
        drop(v439_3);
        let v439_5: Space = subtract(&(*CONSTANT_1),&(v439_4));
        drop(v439_4);
        let v439_8: Space = if (v439_5).is_empty() { Space::new() } else {
          let v440_6: Path = concat_path(&(v438_6),&(v438_7_head));
          let mut v440_7 = Space::new();
          let mut v440_7_cursor = (v438_7_tail).read_zipper();
          for v440_7_byte in v440_7_cursor.child_mask().iter() {
            v440_7_cursor.descend_to_byte(v440_7_byte);
            {
            let v440_7_tail = v440_7_cursor.fork_read_zipper();
            let v440_7_head = Path::from_slice(&[v440_7_byte]);
            let v441_2: Space = singleton(&(v440_7_head));
            let v441_3: Space = intersect(&(*CONSTANT_2),&(v441_2));
            let v441_4: Space = if has_head(&(v441_3)) { singleton(&[]) } else { Space::new() };
            drop(v441_3);
            let v441_5: Space = subtract(&(*CONSTANT_1),&(v441_4));
            drop(v441_4);
            let v441_8: Space = if (v441_5).is_empty() { Space::new() } else {
              let v442_6: Path = concat_path(&(v440_6),&(v440_7_head));
              let v442_7: Space = routine_34(c, &(v442_6), &(*p1), &(v440_7_tail).make_space(), &(*s1));
              compose(&(v441_5),&(v442_7))
            };
            drop(v441_5);
            let v441_9: Space = intersect(&(*CONSTANT_2),&(v441_2));
            drop(v441_2);
            let v441_10: Space = if has_head(&(v441_9)) { singleton(&[]) } else { Space::new() };
            drop(v441_9);
            let v441_12: Space = if (v441_10).is_empty() { Space::new() } else {
              let v443_6: Path = concat_path(&(v440_6),&(v440_7_head));
              let v443_11: Space = routine_35(c, &(v443_6), &(*p1), &(v440_7_tail).make_space(), &(*s1));
              drop(v443_6);
              compose(&(v441_10),&(v443_11))
            };
            drop(v441_10);
            let v441_13: Space = unite(&(v441_8),&(v441_12));
            v440_7.join_into((v441_13).clone());
            }
            v440_7_cursor.ascend(1);
          }
          drop(v440_7_cursor);
          compose(&(v439_5),&(v440_7))
        };
        drop(v439_5);
        let v439_9: Space = intersect(&(*CONSTANT_2),&(v439_2));
        drop(v439_2);
        let v439_10: Space = if has_head(&(v439_9)) { singleton(&[]) } else { Space::new() };
        drop(v439_9);
        let v439_12: Space = if (v439_10).is_empty() { Space::new() } else {
          let v444_6: Path = concat_path(&(v438_6),&(v438_7_head));
          let mut v444_11 = Space::new();
          let mut v444_11_cursor = (v438_7_tail).read_zipper();
          for v444_11_byte in v444_11_cursor.child_mask().iter() {
            v444_11_cursor.descend_to_byte(v444_11_byte);
            {
            let v444_11_tail = v444_11_cursor.fork_read_zipper();
            let v444_11_head = Path::from_slice(&[v444_11_byte]);
            let v445_2: Space = singleton(&(v444_11_head));
            let v445_3: Space = intersect(&(*CONSTANT_2),&(v445_2));
            let v445_4: Space = if has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
            drop(v445_3);
            let v445_5: Space = subtract(&(*CONSTANT_1),&(v445_4));
            drop(v445_4);
            let v445_8: Space = if (v445_5).is_empty() { Space::new() } else {
              let v446_6: Path = concat_path(&(v444_6),&(v444_11_head));
              let v446_7: Space = routine_34(c, &(v446_6), &(*p1), &(v444_11_tail).make_space(), &(*s1));
              compose(&(v445_5),&(v446_7))
            };
            drop(v445_5);
            let v445_9: Space = intersect(&(*CONSTANT_2),&(v445_2));
            drop(v445_2);
            let v445_10: Space = if has_head(&(v445_9)) { singleton(&[]) } else { Space::new() };
            drop(v445_9);
            let v445_12: Space = if (v445_10).is_empty() { Space::new() } else {
              let v447_6: Path = concat_path(&(v444_6),&(v444_11_head));
              let v447_11: Space = routine_10(c, &(v447_6), &(*p1), &(v444_11_tail).make_space(), &(*s1));
              drop(v447_6);
              compose(&(v445_10),&(v447_11))
            };
            drop(v445_10);
            let v445_13: Space = unite(&(v445_8),&(v445_12));
            v444_11.join_into((v445_13).clone());
            }
            v444_11_cursor.ascend(1);
          }
          drop(v444_11_cursor);
          drop(v444_6);
          compose(&(v439_10),&(v444_11))
        };
        drop(v439_10);
        let v439_13: Space = unite(&(v439_8),&(v439_12));
        v438_7.join_into((v439_13).clone());
        }
        v438_7_cursor.ascend(1);
      }
      drop(v438_7_cursor);
      drop(v438_6);
      compose(&(v437_5),&(v438_7))
    };
    drop(v437_5);
    let v437_9: Space = intersect(&(*CONSTANT_2),&(v437_2));
    drop(v437_2);
    let v437_10: Space = if has_head(&(v437_9)) { singleton(&[]) } else { Space::new() };
    drop(v437_9);
    let v437_13: Space = if (v437_10).is_empty() { Space::new() } else {
      let v448_11: Space = unwrap(&(v436_9),&(v436_28_head));
      let mut v448_12 = Space::new();
      let mut v448_12_cursor = (v448_11).read_zipper();
      for v448_12_byte in v448_12_cursor.child_mask().iter() {
        v448_12_cursor.descend_to_byte(v448_12_byte);
        {
        let v448_12_tail = v448_12_cursor.fork_read_zipper();
        let v448_12_head = Path::from_slice(&[v448_12_byte]);
        let v449_2: Space = singleton(&(v448_12_head));
        let v449_3: Space = intersect(&(*CONSTANT_2),&(v449_2));
        let v449_4: Space = if has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
        drop(v449_3);
        let v449_5: Space = subtract(&(*CONSTANT_1),&(v449_4));
        drop(v449_4);
        let v449_7: Space = if (v449_5).is_empty() { Space::new() } else {
          let mut v450_6 = Space::new();
          let mut v450_6_cursor = (v448_12_tail).read_zipper();
          for v450_6_byte in v450_6_cursor.child_mask().iter() {
            v450_6_cursor.descend_to_byte(v450_6_byte);
            {
            let v450_6_tail = v450_6_cursor.fork_read_zipper();
            let v450_6_head = Path::from_slice(&[v450_6_byte]);
            let v451_2: Space = singleton(&(v450_6_head));
            let v451_3: Space = intersect(&(*CONSTANT_2),&(v451_2));
            let v451_4: Space = if has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
            drop(v451_3);
            let v451_5: Space = subtract(&(*CONSTANT_1),&(v451_4));
            drop(v451_4);
            let v451_8: Space = if (v451_5).is_empty() { Space::new() } else {
              let v452_6: Path = concat_path(&(v448_12_head),&(v450_6_head));
              let v452_7: Space = routine_17(c, &(v452_6), &(*p1), &(v450_6_tail).make_space());
              compose(&(v451_5),&(v452_7))
            };
            drop(v451_5);
            let v451_9: Space = intersect(&(*CONSTANT_2),&(v451_2));
            drop(v451_2);
            let v451_10: Space = if has_head(&(v451_9)) { singleton(&[]) } else { Space::new() };
            drop(v451_9);
            let v451_12: Space = if (v451_10).is_empty() { Space::new() } else {
              let v453_6: Path = concat_path(&(v448_12_head),&(v450_6_head));
              let v453_11: Space = routine_18(c, &(v453_6), &(*p1), &(v450_6_tail).make_space());
              drop(v453_6);
              compose(&(v451_10),&(v453_11))
            };
            drop(v451_10);
            let v451_13: Space = unite(&(v451_8),&(v451_12));
            v450_6.join_into((v451_13).clone());
            }
            v450_6_cursor.ascend(1);
          }
          drop(v450_6_cursor);
          compose(&(v449_5),&(v450_6))
        };
        drop(v449_5);
        let v449_8: Space = intersect(&(*CONSTANT_2),&(v449_2));
        drop(v449_2);
        let v449_9: Space = if has_head(&(v449_8)) { singleton(&[]) } else { Space::new() };
        drop(v449_8);
        let v449_11: Space = if (v449_9).is_empty() { Space::new() } else {
          let mut v454_10 = Space::new();
          let mut v454_10_cursor = (v448_12_tail).read_zipper();
          for v454_10_byte in v454_10_cursor.child_mask().iter() {
            v454_10_cursor.descend_to_byte(v454_10_byte);
            {
            let v454_10_tail = v454_10_cursor.fork_read_zipper();
            let v454_10_head = Path::from_slice(&[v454_10_byte]);
            let v455_2: Space = singleton(&(v454_10_head));
            let v455_3: Space = intersect(&(*CONSTANT_2),&(v455_2));
            let v455_4: Space = if has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
            drop(v455_3);
            let v455_5: Space = subtract(&(*CONSTANT_1),&(v455_4));
            drop(v455_4);
            let v455_8: Space = if (v455_5).is_empty() { Space::new() } else {
              let v456_6: Path = concat_path(&(v448_12_head),&(v454_10_head));
              let v456_7: Space = routine_17(c, &(v456_6), &(*p1), &(v454_10_tail).make_space());
              compose(&(v455_5),&(v456_7))
            };
            drop(v455_5);
            let v455_9: Space = intersect(&(*CONSTANT_2),&(v455_2));
            drop(v455_2);
            let v455_10: Space = if has_head(&(v455_9)) { singleton(&[]) } else { Space::new() };
            drop(v455_9);
            let v455_12: Space = if (v455_10).is_empty() { Space::new() } else {
              let v457_6: Path = concat_path(&(v448_12_head),&(v454_10_head));
              let v457_11: Space = routine_19(c, &(v457_6), &(*p1), &(v454_10_tail).make_space());
              drop(v457_6);
              compose(&(v455_10),&(v457_11))
            };
            drop(v455_10);
            let v455_13: Space = unite(&(v455_8),&(v455_12));
            v454_10.join_into((v455_13).clone());
            }
            v454_10_cursor.ascend(1);
          }
          drop(v454_10_cursor);
          compose(&(v449_9),&(v454_10))
        };
        drop(v449_9);
        let v449_12: Space = unite(&(v449_7),&(v449_11));
        v448_12.join_into((v449_12).clone());
        }
        v448_12_cursor.ascend(1);
      }
      drop(v448_12_cursor);
      drop(v448_11);
      compose(&(v437_10),&(v448_12))
    };
    drop(v437_10);
    let v437_14: Space = unite(&(v437_8),&(v437_13));
    v436_28.join_into((v437_14).clone());
    }
    v436_28_cursor.ascend(1);
  }
  drop(v436_28_cursor);
  drop(v436_9);
  (v436_28).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v458_21 = Space::new();
  let mut v458_21_cursor = (*s0).read_zipper();
  for v458_21_byte in v458_21_cursor.child_mask().iter() {
    v458_21_cursor.descend_to_byte(v458_21_byte);
    {
    let v458_21_tail = v458_21_cursor.fork_read_zipper();
    let v458_21_head = Path::from_slice(&[v458_21_byte]);
    let v459_2: Space = singleton(&(v458_21_head));
    let v459_3: Space = intersect(&(*CONSTANT_2),&(v459_2));
    let v459_4: Space = if has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
    drop(v459_3);
    let v459_5: Space = subtract(&(*CONSTANT_1),&(v459_4));
    drop(v459_4);
    let v459_8: Space = if (v459_5).is_empty() { Space::new() } else {
      let v460_6: Path = concat_path(&(*p0),&(v458_21_head));
      let mut v460_7 = Space::new();
      let mut v460_7_cursor = (v458_21_tail).read_zipper();
      for v460_7_byte in v460_7_cursor.child_mask().iter() {
        v460_7_cursor.descend_to_byte(v460_7_byte);
        {
        let v460_7_tail = v460_7_cursor.fork_read_zipper();
        let v460_7_head = Path::from_slice(&[v460_7_byte]);
        let v461_2: Space = singleton(&(v460_7_head));
        let v461_3: Space = intersect(&(*CONSTANT_2),&(v461_2));
        let v461_4: Space = if has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
        drop(v461_3);
        let v461_5: Space = subtract(&(*CONSTANT_1),&(v461_4));
        drop(v461_4);
        let v461_8: Space = if (v461_5).is_empty() { Space::new() } else {
          let v462_6: Path = concat_path(&(v460_6),&(v460_7_head));
          let mut v462_7 = Space::new();
          let mut v462_7_cursor = (v460_7_tail).read_zipper();
          for v462_7_byte in v462_7_cursor.child_mask().iter() {
            v462_7_cursor.descend_to_byte(v462_7_byte);
            {
            let v462_7_tail = v462_7_cursor.fork_read_zipper();
            let v462_7_head = Path::from_slice(&[v462_7_byte]);
            let v463_2: Space = singleton(&(v462_7_head));
            let v463_3: Space = intersect(&(*CONSTANT_2),&(v463_2));
            let v463_4: Space = if has_head(&(v463_3)) { singleton(&[]) } else { Space::new() };
            drop(v463_3);
            let v463_5: Space = subtract(&(*CONSTANT_1),&(v463_4));
            drop(v463_4);
            let v463_8: Space = if (v463_5).is_empty() { Space::new() } else {
              let v464_6: Path = concat_path(&(v462_6),&(v462_7_head));
              let v464_7: Space = routine_36(c, &(v464_6), &(*p1), &(v462_7_tail).make_space());
              compose(&(v463_5),&(v464_7))
            };
            drop(v463_5);
            let v463_9: Space = intersect(&(*CONSTANT_2),&(v463_2));
            drop(v463_2);
            let v463_10: Space = if has_head(&(v463_9)) { singleton(&[]) } else { Space::new() };
            drop(v463_9);
            let v463_12: Space = if (v463_10).is_empty() { Space::new() } else {
              let v465_6: Path = concat_path(&(v462_6),&(v462_7_head));
              let v465_11: Space = routine_37(c, &(v465_6), &(*p1), &(v462_7_tail).make_space());
              drop(v465_6);
              compose(&(v463_10),&(v465_11))
            };
            drop(v463_10);
            let v463_13: Space = unite(&(v463_8),&(v463_12));
            v462_7.join_into((v463_13).clone());
            }
            v462_7_cursor.ascend(1);
          }
          drop(v462_7_cursor);
          compose(&(v461_5),&(v462_7))
        };
        drop(v461_5);
        let v461_9: Space = intersect(&(*CONSTANT_2),&(v461_2));
        drop(v461_2);
        let v461_10: Space = if has_head(&(v461_9)) { singleton(&[]) } else { Space::new() };
        drop(v461_9);
        let v461_12: Space = if (v461_10).is_empty() { Space::new() } else {
          let v466_6: Path = concat_path(&(v460_6),&(v460_7_head));
          let mut v466_11 = Space::new();
          let mut v466_11_cursor = (v460_7_tail).read_zipper();
          for v466_11_byte in v466_11_cursor.child_mask().iter() {
            v466_11_cursor.descend_to_byte(v466_11_byte);
            {
            let v466_11_tail = v466_11_cursor.fork_read_zipper();
            let v466_11_head = Path::from_slice(&[v466_11_byte]);
            let v467_2: Space = singleton(&(v466_11_head));
            let v467_3: Space = intersect(&(*CONSTANT_2),&(v467_2));
            let v467_4: Space = if has_head(&(v467_3)) { singleton(&[]) } else { Space::new() };
            drop(v467_3);
            let v467_5: Space = subtract(&(*CONSTANT_1),&(v467_4));
            drop(v467_4);
            let v467_8: Space = if (v467_5).is_empty() { Space::new() } else {
              let v468_6: Path = concat_path(&(v466_6),&(v466_11_head));
              let v468_7: Space = routine_36(c, &(v468_6), &(*p1), &(v466_11_tail).make_space());
              compose(&(v467_5),&(v468_7))
            };
            drop(v467_5);
            let v467_9: Space = intersect(&(*CONSTANT_2),&(v467_2));
            drop(v467_2);
            let v467_10: Space = if has_head(&(v467_9)) { singleton(&[]) } else { Space::new() };
            drop(v467_9);
            let v467_12: Space = if (v467_10).is_empty() { Space::new() } else {
              let v469_6: Path = concat_path(&(v466_6),&(v466_11_head));
              let v469_11: Space = routine_19(c, &(v469_6), &(*p1), &(v466_11_tail).make_space());
              drop(v469_6);
              compose(&(v467_10),&(v469_11))
            };
            drop(v467_10);
            let v467_13: Space = unite(&(v467_8),&(v467_12));
            v466_11.join_into((v467_13).clone());
            }
            v466_11_cursor.ascend(1);
          }
          drop(v466_11_cursor);
          drop(v466_6);
          compose(&(v461_10),&(v466_11))
        };
        drop(v461_10);
        let v461_13: Space = unite(&(v461_8),&(v461_12));
        v460_7.join_into((v461_13).clone());
        }
        v460_7_cursor.ascend(1);
      }
      drop(v460_7_cursor);
      compose(&(v459_5),&(v460_7))
    };
    drop(v459_5);
    let v459_9: Space = intersect(&(*CONSTANT_2),&(v459_2));
    drop(v459_2);
    let v459_10: Space = if has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
    drop(v459_9);
    let v459_12: Space = if (v459_10).is_empty() { Space::new() } else {
      let v470_6: Path = concat_path(&(*p0),&(v458_21_head));
      let mut v470_11 = Space::new();
      let mut v470_11_cursor = (v458_21_tail).read_zipper();
      for v470_11_byte in v470_11_cursor.child_mask().iter() {
        v470_11_cursor.descend_to_byte(v470_11_byte);
        {
        let v470_11_tail = v470_11_cursor.fork_read_zipper();
        let v470_11_head = Path::from_slice(&[v470_11_byte]);
        let v471_2: Space = singleton(&(v470_11_head));
        let v471_3: Space = intersect(&(*CONSTANT_2),&(v471_2));
        let v471_4: Space = if has_head(&(v471_3)) { singleton(&[]) } else { Space::new() };
        drop(v471_3);
        let v471_5: Space = subtract(&(*CONSTANT_1),&(v471_4));
        drop(v471_4);
        let v471_8: Space = if (v471_5).is_empty() { Space::new() } else {
          let v472_6: Path = concat_path(&(v470_6),&(v470_11_head));
          let mut v472_7 = Space::new();
          let mut v472_7_cursor = (v470_11_tail).read_zipper();
          for v472_7_byte in v472_7_cursor.child_mask().iter() {
            v472_7_cursor.descend_to_byte(v472_7_byte);
            {
            let v472_7_tail = v472_7_cursor.fork_read_zipper();
            let v472_7_head = Path::from_slice(&[v472_7_byte]);
            let v473_2: Space = singleton(&(v472_7_head));
            let v473_3: Space = intersect(&(*CONSTANT_2),&(v473_2));
            let v473_4: Space = if has_head(&(v473_3)) { singleton(&[]) } else { Space::new() };
            drop(v473_3);
            let v473_5: Space = subtract(&(*CONSTANT_1),&(v473_4));
            drop(v473_4);
            let v473_8: Space = if (v473_5).is_empty() { Space::new() } else {
              let v474_6: Path = concat_path(&(v472_6),&(v472_7_head));
              let v474_7: Space = routine_36(c, &(v474_6), &(*p1), &(v472_7_tail).make_space());
              compose(&(v473_5),&(v474_7))
            };
            drop(v473_5);
            let v473_9: Space = intersect(&(*CONSTANT_2),&(v473_2));
            drop(v473_2);
            let v473_10: Space = if has_head(&(v473_9)) { singleton(&[]) } else { Space::new() };
            drop(v473_9);
            let v473_12: Space = if (v473_10).is_empty() { Space::new() } else {
              let v475_6: Path = concat_path(&(v472_6),&(v472_7_head));
              let v475_11: Space = routine_37(c, &(v475_6), &(*p1), &(v472_7_tail).make_space());
              drop(v475_6);
              compose(&(v473_10),&(v475_11))
            };
            drop(v473_10);
            let v473_13: Space = unite(&(v473_8),&(v473_12));
            v472_7.join_into((v473_13).clone());
            }
            v472_7_cursor.ascend(1);
          }
          drop(v472_7_cursor);
          compose(&(v471_5),&(v472_7))
        };
        drop(v471_5);
        let v471_9: Space = intersect(&(*CONSTANT_2),&(v471_2));
        drop(v471_2);
        let v471_10: Space = if has_head(&(v471_9)) { singleton(&[]) } else { Space::new() };
        drop(v471_9);
        let v471_11: Space = compose(&(v471_10),&(v470_11_tail));
        drop(v471_10);
        let v476_6: Path = concat_path(&(v470_6),&(v470_11_head));
        let v471_12: Space = wrap(&(v471_11),&(v476_6));
        drop(v471_11);
        let v471_13: Space = wrap(&(v471_12),&(*p1));
        drop(v471_12);
        let v471_14: Space = unite(&(v471_8),&(v471_13));
        drop(v471_13);
        v470_11.join_into((v471_14).clone());
        }
        v470_11_cursor.ascend(1);
      }
      drop(v470_11_cursor);
      drop(v470_6);
      compose(&(v459_10),&(v470_11))
    };
    drop(v459_10);
    let v459_13: Space = unite(&(v459_8),&(v459_12));
    v458_21.join_into((v459_13).clone());
    }
    v458_21_cursor.ascend(1);
  }
  drop(v458_21_cursor);
  (v458_21).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v477_15 = Space::new();
  let mut v477_15_cursor = (*s0).read_zipper();
  for v477_15_byte in v477_15_cursor.child_mask().iter() {
    v477_15_cursor.descend_to_byte(v477_15_byte);
    {
    let v477_15_tail = v477_15_cursor.fork_read_zipper();
    let v477_15_head = Path::from_slice(&[v477_15_byte]);
    let v478_2: Space = singleton(&(v477_15_head));
    let v478_3: Space = intersect(&(*CONSTANT_2),&(v478_2));
    let v478_4: Space = if has_head(&(v478_3)) { singleton(&[]) } else { Space::new() };
    drop(v478_3);
    let v478_5: Space = subtract(&(*CONSTANT_1),&(v478_4));
    drop(v478_4);
    let v478_8: Space = if (v478_5).is_empty() { Space::new() } else {
      let v479_6: Path = concat_path(&(*p0),&(v477_15_head));
      let mut v479_7 = Space::new();
      let mut v479_7_cursor = (v477_15_tail).read_zipper();
      for v479_7_byte in v479_7_cursor.child_mask().iter() {
        v479_7_cursor.descend_to_byte(v479_7_byte);
        {
        let v479_7_tail = v479_7_cursor.fork_read_zipper();
        let v479_7_head = Path::from_slice(&[v479_7_byte]);
        let v480_2: Space = singleton(&(v479_7_head));
        let v480_3: Space = intersect(&(*CONSTANT_2),&(v480_2));
        let v480_4: Space = if has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
        drop(v480_3);
        let v480_5: Space = subtract(&(*CONSTANT_1),&(v480_4));
        drop(v480_4);
        let v480_8: Space = if (v480_5).is_empty() { Space::new() } else {
          let v481_6: Path = concat_path(&(v479_6),&(v479_7_head));
          let mut v481_7 = Space::new();
          let mut v481_7_cursor = (v479_7_tail).read_zipper();
          for v481_7_byte in v481_7_cursor.child_mask().iter() {
            v481_7_cursor.descend_to_byte(v481_7_byte);
            {
            let v481_7_tail = v481_7_cursor.fork_read_zipper();
            let v481_7_head = Path::from_slice(&[v481_7_byte]);
            let v482_2: Space = singleton(&(v481_7_head));
            let v482_3: Space = intersect(&(*CONSTANT_2),&(v482_2));
            let v482_4: Space = if has_head(&(v482_3)) { singleton(&[]) } else { Space::new() };
            drop(v482_3);
            let v482_5: Space = subtract(&(*CONSTANT_1),&(v482_4));
            drop(v482_4);
            let v482_8: Space = if (v482_5).is_empty() { Space::new() } else {
              let v483_6: Path = concat_path(&(v481_6),&(v481_7_head));
              let v483_7: Space = routine_36(c, &(v483_6), &(*p1), &(v481_7_tail).make_space());
              compose(&(v482_5),&(v483_7))
            };
            drop(v482_5);
            let v482_9: Space = intersect(&(*CONSTANT_2),&(v482_2));
            drop(v482_2);
            let v482_10: Space = if has_head(&(v482_9)) { singleton(&[]) } else { Space::new() };
            drop(v482_9);
            let v482_12: Space = if (v482_10).is_empty() { Space::new() } else {
              let v484_6: Path = concat_path(&(v481_6),&(v481_7_head));
              let v484_11: Space = routine_37(c, &(v484_6), &(*p1), &(v481_7_tail).make_space());
              drop(v484_6);
              compose(&(v482_10),&(v484_11))
            };
            drop(v482_10);
            let v482_13: Space = unite(&(v482_8),&(v482_12));
            v481_7.join_into((v482_13).clone());
            }
            v481_7_cursor.ascend(1);
          }
          drop(v481_7_cursor);
          compose(&(v480_5),&(v481_7))
        };
        drop(v480_5);
        let v480_9: Space = intersect(&(*CONSTANT_2),&(v480_2));
        drop(v480_2);
        let v480_10: Space = if has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
        drop(v480_9);
        let v480_12: Space = if (v480_10).is_empty() { Space::new() } else {
          let v485_6: Path = concat_path(&(v479_6),&(v479_7_head));
          let mut v485_11 = Space::new();
          let mut v485_11_cursor = (v479_7_tail).read_zipper();
          for v485_11_byte in v485_11_cursor.child_mask().iter() {
            v485_11_cursor.descend_to_byte(v485_11_byte);
            {
            let v485_11_tail = v485_11_cursor.fork_read_zipper();
            let v485_11_head = Path::from_slice(&[v485_11_byte]);
            let v486_2: Space = singleton(&(v485_11_head));
            let v486_3: Space = intersect(&(*CONSTANT_2),&(v486_2));
            let v486_4: Space = if has_head(&(v486_3)) { singleton(&[]) } else { Space::new() };
            drop(v486_3);
            let v486_5: Space = subtract(&(*CONSTANT_1),&(v486_4));
            drop(v486_4);
            let v486_8: Space = if (v486_5).is_empty() { Space::new() } else {
              let v487_6: Path = concat_path(&(v485_6),&(v485_11_head));
              let v487_7: Space = routine_36(c, &(v487_6), &(*p1), &(v485_11_tail).make_space());
              compose(&(v486_5),&(v487_7))
            };
            drop(v486_5);
            let v486_9: Space = intersect(&(*CONSTANT_2),&(v486_2));
            drop(v486_2);
            let v486_10: Space = if has_head(&(v486_9)) { singleton(&[]) } else { Space::new() };
            drop(v486_9);
            let v486_12: Space = if (v486_10).is_empty() { Space::new() } else {
              let v488_6: Path = concat_path(&(v485_6),&(v485_11_head));
              let v488_11: Space = routine_19(c, &(v488_6), &(*p1), &(v485_11_tail).make_space());
              drop(v488_6);
              compose(&(v486_10),&(v488_11))
            };
            drop(v486_10);
            let v486_13: Space = unite(&(v486_8),&(v486_12));
            v485_11.join_into((v486_13).clone());
            }
            v485_11_cursor.ascend(1);
          }
          drop(v485_11_cursor);
          drop(v485_6);
          compose(&(v480_10),&(v485_11))
        };
        drop(v480_10);
        let v480_13: Space = unite(&(v480_8),&(v480_12));
        v479_7.join_into((v480_13).clone());
        }
        v479_7_cursor.ascend(1);
      }
      drop(v479_7_cursor);
      compose(&(v478_5),&(v479_7))
    };
    drop(v478_5);
    let v478_9: Space = intersect(&(*CONSTANT_2),&(v478_2));
    drop(v478_2);
    let v478_10: Space = if has_head(&(v478_9)) { singleton(&[]) } else { Space::new() };
    drop(v478_9);
    let v478_11: Space = compose(&(v478_10),&(v477_15_tail));
    drop(v478_10);
    let v489_6: Path = concat_path(&(*p0),&(v477_15_head));
    let v478_12: Space = wrap(&(v478_11),&(v489_6));
    drop(v478_11);
    let v478_13: Space = wrap(&(v478_12),&(*p1));
    drop(v478_12);
    let v478_14: Space = unite(&(v478_8),&(v478_13));
    drop(v478_13);
    v477_15.join_into((v478_14).clone());
    }
    v477_15_cursor.ascend(1);
  }
  drop(v477_15_cursor);
  (v477_15).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v490_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v490_21: Space = unwrap(&(v490_20),&(*p0));
  drop(v490_20);
  let mut v490_28 = Space::new();
  let mut v490_28_cursor = (*s0).read_zipper();
  for v490_28_byte in v490_28_cursor.child_mask().iter() {
    v490_28_cursor.descend_to_byte(v490_28_byte);
    {
    let v490_28_tail = v490_28_cursor.fork_read_zipper();
    let v490_28_head = Path::from_slice(&[v490_28_byte]);
    let v491_2: Space = singleton(&(v490_28_head));
    let v491_3: Space = intersect(&(*CONSTANT_2),&(v491_2));
    let v491_4: Space = if has_head(&(v491_3)) { singleton(&[]) } else { Space::new() };
    drop(v491_3);
    let v491_5: Space = subtract(&(*CONSTANT_1),&(v491_4));
    drop(v491_4);
    let v491_8: Space = if (v491_5).is_empty() { Space::new() } else {
      let v492_6: Path = concat_path(&(*p0),&(v490_28_head));
      let mut v492_7 = Space::new();
      let mut v492_7_cursor = (v490_28_tail).read_zipper();
      for v492_7_byte in v492_7_cursor.child_mask().iter() {
        v492_7_cursor.descend_to_byte(v492_7_byte);
        {
        let v492_7_tail = v492_7_cursor.fork_read_zipper();
        let v492_7_head = Path::from_slice(&[v492_7_byte]);
        let v493_2: Space = singleton(&(v492_7_head));
        let v493_3: Space = intersect(&(*CONSTANT_2),&(v493_2));
        let v493_4: Space = if has_head(&(v493_3)) { singleton(&[]) } else { Space::new() };
        drop(v493_3);
        let v493_5: Space = subtract(&(*CONSTANT_1),&(v493_4));
        drop(v493_4);
        let v493_8: Space = if (v493_5).is_empty() { Space::new() } else {
          let v494_6: Path = concat_path(&(v492_6),&(v492_7_head));
          let mut v494_7 = Space::new();
          let mut v494_7_cursor = (v492_7_tail).read_zipper();
          for v494_7_byte in v494_7_cursor.child_mask().iter() {
            v494_7_cursor.descend_to_byte(v494_7_byte);
            {
            let v494_7_tail = v494_7_cursor.fork_read_zipper();
            let v494_7_head = Path::from_slice(&[v494_7_byte]);
            let v495_2: Space = singleton(&(v494_7_head));
            let v495_3: Space = intersect(&(*CONSTANT_2),&(v495_2));
            let v495_4: Space = if has_head(&(v495_3)) { singleton(&[]) } else { Space::new() };
            drop(v495_3);
            let v495_5: Space = subtract(&(*CONSTANT_1),&(v495_4));
            drop(v495_4);
            let v495_8: Space = if (v495_5).is_empty() { Space::new() } else {
              let v496_6: Path = concat_path(&(v494_6),&(v494_7_head));
              let v496_7: Space = routine_38(c, &(v496_6), &(*p1), &(v494_7_tail).make_space(), &(*s1));
              compose(&(v495_5),&(v496_7))
            };
            drop(v495_5);
            let v495_9: Space = intersect(&(*CONSTANT_2),&(v495_2));
            drop(v495_2);
            let v495_10: Space = if has_head(&(v495_9)) { singleton(&[]) } else { Space::new() };
            drop(v495_9);
            let v495_12: Space = if (v495_10).is_empty() { Space::new() } else {
              let v497_6: Path = concat_path(&(v494_6),&(v494_7_head));
              let v497_11: Space = routine_39(c, &(v497_6), &(*p1), &(v494_7_tail).make_space(), &(*s1));
              drop(v497_6);
              compose(&(v495_10),&(v497_11))
            };
            drop(v495_10);
            let v495_13: Space = unite(&(v495_8),&(v495_12));
            v494_7.join_into((v495_13).clone());
            }
            v494_7_cursor.ascend(1);
          }
          drop(v494_7_cursor);
          compose(&(v493_5),&(v494_7))
        };
        drop(v493_5);
        let v493_9: Space = intersect(&(*CONSTANT_2),&(v493_2));
        drop(v493_2);
        let v493_10: Space = if has_head(&(v493_9)) { singleton(&[]) } else { Space::new() };
        drop(v493_9);
        let v493_12: Space = if (v493_10).is_empty() { Space::new() } else {
          let v498_6: Path = concat_path(&(v492_6),&(v492_7_head));
          let mut v498_11 = Space::new();
          let mut v498_11_cursor = (v492_7_tail).read_zipper();
          for v498_11_byte in v498_11_cursor.child_mask().iter() {
            v498_11_cursor.descend_to_byte(v498_11_byte);
            {
            let v498_11_tail = v498_11_cursor.fork_read_zipper();
            let v498_11_head = Path::from_slice(&[v498_11_byte]);
            let v499_2: Space = singleton(&(v498_11_head));
            let v499_3: Space = intersect(&(*CONSTANT_2),&(v499_2));
            let v499_4: Space = if has_head(&(v499_3)) { singleton(&[]) } else { Space::new() };
            drop(v499_3);
            let v499_5: Space = subtract(&(*CONSTANT_1),&(v499_4));
            drop(v499_4);
            let v499_8: Space = if (v499_5).is_empty() { Space::new() } else {
              let v500_6: Path = concat_path(&(v498_6),&(v498_11_head));
              let v500_7: Space = routine_38(c, &(v500_6), &(*p1), &(v498_11_tail).make_space(), &(*s1));
              compose(&(v499_5),&(v500_7))
            };
            drop(v499_5);
            let v499_9: Space = intersect(&(*CONSTANT_2),&(v499_2));
            drop(v499_2);
            let v499_10: Space = if has_head(&(v499_9)) { singleton(&[]) } else { Space::new() };
            drop(v499_9);
            let v499_12: Space = if (v499_10).is_empty() { Space::new() } else {
              let v501_6: Path = concat_path(&(v498_6),&(v498_11_head));
              let v501_11: Space = routine_10(c, &(v501_6), &(*p1), &(v498_11_tail).make_space(), &(*s1));
              drop(v501_6);
              compose(&(v499_10),&(v501_11))
            };
            drop(v499_10);
            let v499_13: Space = unite(&(v499_8),&(v499_12));
            v498_11.join_into((v499_13).clone());
            }
            v498_11_cursor.ascend(1);
          }
          drop(v498_11_cursor);
          drop(v498_6);
          compose(&(v493_10),&(v498_11))
        };
        drop(v493_10);
        let v493_13: Space = unite(&(v493_8),&(v493_12));
        v492_7.join_into((v493_13).clone());
        }
        v492_7_cursor.ascend(1);
      }
      drop(v492_7_cursor);
      compose(&(v491_5),&(v492_7))
    };
    drop(v491_5);
    let v491_9: Space = intersect(&(*CONSTANT_2),&(v491_2));
    drop(v491_2);
    let v491_10: Space = if has_head(&(v491_9)) { singleton(&[]) } else { Space::new() };
    drop(v491_9);
    let v491_13: Space = if (v491_10).is_empty() { Space::new() } else {
      let v502_6: Path = concat_path(&(*p0),&(v490_28_head));
      let v502_11: Space = unwrap(&(v490_21),&(v490_28_head));
      let mut v502_12 = Space::new();
      let mut v502_12_cursor = (v490_28_tail).read_zipper();
      for v502_12_byte in v502_12_cursor.child_mask().iter() {
        v502_12_cursor.descend_to_byte(v502_12_byte);
        {
        let v502_12_tail = v502_12_cursor.fork_read_zipper();
        let v502_12_head = Path::from_slice(&[v502_12_byte]);
        let v503_2: Space = singleton(&(v502_12_head));
        let v503_3: Space = intersect(&(*CONSTANT_2),&(v503_2));
        let v503_4: Space = if has_head(&(v503_3)) { singleton(&[]) } else { Space::new() };
        drop(v503_3);
        let v503_5: Space = subtract(&(*CONSTANT_1),&(v503_4));
        drop(v503_4);
        let v503_8: Space = if (v503_5).is_empty() { Space::new() } else {
          let v504_6: Path = concat_path(&(v502_6),&(v502_12_head));
          let mut v504_7 = Space::new();
          let mut v504_7_cursor = (v502_12_tail).read_zipper();
          for v504_7_byte in v504_7_cursor.child_mask().iter() {
            v504_7_cursor.descend_to_byte(v504_7_byte);
            {
            let v504_7_tail = v504_7_cursor.fork_read_zipper();
            let v504_7_head = Path::from_slice(&[v504_7_byte]);
            let v505_2: Space = singleton(&(v504_7_head));
            let v505_3: Space = intersect(&(*CONSTANT_2),&(v505_2));
            let v505_4: Space = if has_head(&(v505_3)) { singleton(&[]) } else { Space::new() };
            drop(v505_3);
            let v505_5: Space = subtract(&(*CONSTANT_1),&(v505_4));
            drop(v505_4);
            let v505_8: Space = if (v505_5).is_empty() { Space::new() } else {
              let v506_6: Path = concat_path(&(v504_6),&(v504_7_head));
              let v506_7: Space = routine_38(c, &(v506_6), &(*p1), &(v504_7_tail).make_space(), &(*s1));
              compose(&(v505_5),&(v506_7))
            };
            drop(v505_5);
            let v505_9: Space = intersect(&(*CONSTANT_2),&(v505_2));
            drop(v505_2);
            let v505_10: Space = if has_head(&(v505_9)) { singleton(&[]) } else { Space::new() };
            drop(v505_9);
            let v505_12: Space = if (v505_10).is_empty() { Space::new() } else {
              let v507_6: Path = concat_path(&(v504_6),&(v504_7_head));
              let v507_11: Space = routine_39(c, &(v507_6), &(*p1), &(v504_7_tail).make_space(), &(*s1));
              drop(v507_6);
              compose(&(v505_10),&(v507_11))
            };
            drop(v505_10);
            let v505_13: Space = unite(&(v505_8),&(v505_12));
            v504_7.join_into((v505_13).clone());
            }
            v504_7_cursor.ascend(1);
          }
          drop(v504_7_cursor);
          drop(v504_6);
          compose(&(v503_5),&(v504_7))
        };
        drop(v503_5);
        let v503_9: Space = intersect(&(*CONSTANT_2),&(v503_2));
        drop(v503_2);
        let v503_10: Space = if has_head(&(v503_9)) { singleton(&[]) } else { Space::new() };
        drop(v503_9);
        let v503_13: Space = if (v503_10).is_empty() { Space::new() } else {
          let v508_11: Space = unwrap(&(v502_11),&(v502_12_head));
          let mut v508_12 = Space::new();
          let mut v508_12_cursor = (v508_11).read_zipper();
          for v508_12_byte in v508_12_cursor.child_mask().iter() {
            v508_12_cursor.descend_to_byte(v508_12_byte);
            {
            let v508_12_tail = v508_12_cursor.fork_read_zipper();
            let v508_12_head = Path::from_slice(&[v508_12_byte]);
            let v509_2: Space = singleton(&(v508_12_head));
            let v509_3: Space = intersect(&(*CONSTANT_2),&(v509_2));
            let v509_4: Space = if has_head(&(v509_3)) { singleton(&[]) } else { Space::new() };
            drop(v509_3);
            let v509_5: Space = subtract(&(*CONSTANT_1),&(v509_4));
            drop(v509_4);
            let v509_7: Space = if (v509_5).is_empty() { Space::new() } else {
              let v510_6: Space = routine_13(c, &(v508_12_head), &(*p1), &(v508_12_tail).make_space());
              compose(&(v509_5),&(v510_6))
            };
            drop(v509_5);
            let v509_8: Space = intersect(&(*CONSTANT_2),&(v509_2));
            drop(v509_2);
            let v509_9: Space = if has_head(&(v509_8)) { singleton(&[]) } else { Space::new() };
            drop(v509_8);
            let v509_11: Space = if (v509_9).is_empty() { Space::new() } else {
              let v511_10: Space = routine_14(c, &(v508_12_head), &(*p1), &(v508_12_tail).make_space());
              compose(&(v509_9),&(v511_10))
            };
            drop(v509_9);
            let v509_12: Space = unite(&(v509_7),&(v509_11));
            v508_12.join_into((v509_12).clone());
            }
            v508_12_cursor.ascend(1);
          }
          drop(v508_12_cursor);
          drop(v508_11);
          compose(&(v503_10),&(v508_12))
        };
        drop(v503_10);
        let v503_14: Space = unite(&(v503_8),&(v503_13));
        v502_12.join_into((v503_14).clone());
        }
        v502_12_cursor.ascend(1);
      }
      drop(v502_12_cursor);
      drop(v502_6);
      drop(v502_11);
      compose(&(v491_10),&(v502_12))
    };
    drop(v491_10);
    let v491_14: Space = unite(&(v491_8),&(v491_13));
    v490_28.join_into((v491_14).clone());
    }
    v490_28_cursor.ascend(1);
  }
  drop(v490_28_cursor);
  drop(v490_21);
  (v490_28).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v512_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v512_9: Space = unwrap(&(v512_8),&(*p0));
  drop(v512_8);
  let mut v512_28 = Space::new();
  let mut v512_28_cursor = (*s0).read_zipper();
  for v512_28_byte in v512_28_cursor.child_mask().iter() {
    v512_28_cursor.descend_to_byte(v512_28_byte);
    {
    let v512_28_tail = v512_28_cursor.fork_read_zipper();
    let v512_28_head = Path::from_slice(&[v512_28_byte]);
    let v513_2: Space = singleton(&(v512_28_head));
    let v513_3: Space = intersect(&(*CONSTANT_2),&(v513_2));
    let v513_4: Space = if has_head(&(v513_3)) { singleton(&[]) } else { Space::new() };
    drop(v513_3);
    let v513_5: Space = subtract(&(*CONSTANT_1),&(v513_4));
    drop(v513_4);
    let v513_8: Space = if (v513_5).is_empty() { Space::new() } else {
      let v514_6: Path = concat_path(&(*p0),&(v512_28_head));
      let mut v514_7 = Space::new();
      let mut v514_7_cursor = (v512_28_tail).read_zipper();
      for v514_7_byte in v514_7_cursor.child_mask().iter() {
        v514_7_cursor.descend_to_byte(v514_7_byte);
        {
        let v514_7_tail = v514_7_cursor.fork_read_zipper();
        let v514_7_head = Path::from_slice(&[v514_7_byte]);
        let v515_2: Space = singleton(&(v514_7_head));
        let v515_3: Space = intersect(&(*CONSTANT_2),&(v515_2));
        let v515_4: Space = if has_head(&(v515_3)) { singleton(&[]) } else { Space::new() };
        drop(v515_3);
        let v515_5: Space = subtract(&(*CONSTANT_1),&(v515_4));
        drop(v515_4);
        let v515_8: Space = if (v515_5).is_empty() { Space::new() } else {
          let v516_6: Path = concat_path(&(v514_6),&(v514_7_head));
          let mut v516_7 = Space::new();
          let mut v516_7_cursor = (v514_7_tail).read_zipper();
          for v516_7_byte in v516_7_cursor.child_mask().iter() {
            v516_7_cursor.descend_to_byte(v516_7_byte);
            {
            let v516_7_tail = v516_7_cursor.fork_read_zipper();
            let v516_7_head = Path::from_slice(&[v516_7_byte]);
            let v517_2: Space = singleton(&(v516_7_head));
            let v517_3: Space = intersect(&(*CONSTANT_2),&(v517_2));
            let v517_4: Space = if has_head(&(v517_3)) { singleton(&[]) } else { Space::new() };
            drop(v517_3);
            let v517_5: Space = subtract(&(*CONSTANT_1),&(v517_4));
            drop(v517_4);
            let v517_8: Space = if (v517_5).is_empty() { Space::new() } else {
              let v518_6: Path = concat_path(&(v516_6),&(v516_7_head));
              let v518_7: Space = routine_38(c, &(v518_6), &(*p1), &(v516_7_tail).make_space(), &(*s1));
              compose(&(v517_5),&(v518_7))
            };
            drop(v517_5);
            let v517_9: Space = intersect(&(*CONSTANT_2),&(v517_2));
            drop(v517_2);
            let v517_10: Space = if has_head(&(v517_9)) { singleton(&[]) } else { Space::new() };
            drop(v517_9);
            let v517_12: Space = if (v517_10).is_empty() { Space::new() } else {
              let v519_6: Path = concat_path(&(v516_6),&(v516_7_head));
              let v519_11: Space = routine_39(c, &(v519_6), &(*p1), &(v516_7_tail).make_space(), &(*s1));
              drop(v519_6);
              compose(&(v517_10),&(v519_11))
            };
            drop(v517_10);
            let v517_13: Space = unite(&(v517_8),&(v517_12));
            v516_7.join_into((v517_13).clone());
            }
            v516_7_cursor.ascend(1);
          }
          drop(v516_7_cursor);
          compose(&(v515_5),&(v516_7))
        };
        drop(v515_5);
        let v515_9: Space = intersect(&(*CONSTANT_2),&(v515_2));
        drop(v515_2);
        let v515_10: Space = if has_head(&(v515_9)) { singleton(&[]) } else { Space::new() };
        drop(v515_9);
        let v515_12: Space = if (v515_10).is_empty() { Space::new() } else {
          let v520_6: Path = concat_path(&(v514_6),&(v514_7_head));
          let mut v520_11 = Space::new();
          let mut v520_11_cursor = (v514_7_tail).read_zipper();
          for v520_11_byte in v520_11_cursor.child_mask().iter() {
            v520_11_cursor.descend_to_byte(v520_11_byte);
            {
            let v520_11_tail = v520_11_cursor.fork_read_zipper();
            let v520_11_head = Path::from_slice(&[v520_11_byte]);
            let v521_2: Space = singleton(&(v520_11_head));
            let v521_3: Space = intersect(&(*CONSTANT_2),&(v521_2));
            let v521_4: Space = if has_head(&(v521_3)) { singleton(&[]) } else { Space::new() };
            drop(v521_3);
            let v521_5: Space = subtract(&(*CONSTANT_1),&(v521_4));
            drop(v521_4);
            let v521_8: Space = if (v521_5).is_empty() { Space::new() } else {
              let v522_6: Path = concat_path(&(v520_6),&(v520_11_head));
              let v522_7: Space = routine_38(c, &(v522_6), &(*p1), &(v520_11_tail).make_space(), &(*s1));
              compose(&(v521_5),&(v522_7))
            };
            drop(v521_5);
            let v521_9: Space = intersect(&(*CONSTANT_2),&(v521_2));
            drop(v521_2);
            let v521_10: Space = if has_head(&(v521_9)) { singleton(&[]) } else { Space::new() };
            drop(v521_9);
            let v521_12: Space = if (v521_10).is_empty() { Space::new() } else {
              let v523_6: Path = concat_path(&(v520_6),&(v520_11_head));
              let v523_11: Space = routine_10(c, &(v523_6), &(*p1), &(v520_11_tail).make_space(), &(*s1));
              drop(v523_6);
              compose(&(v521_10),&(v523_11))
            };
            drop(v521_10);
            let v521_13: Space = unite(&(v521_8),&(v521_12));
            v520_11.join_into((v521_13).clone());
            }
            v520_11_cursor.ascend(1);
          }
          drop(v520_11_cursor);
          drop(v520_6);
          compose(&(v515_10),&(v520_11))
        };
        drop(v515_10);
        let v515_13: Space = unite(&(v515_8),&(v515_12));
        v514_7.join_into((v515_13).clone());
        }
        v514_7_cursor.ascend(1);
      }
      drop(v514_7_cursor);
      drop(v514_6);
      compose(&(v513_5),&(v514_7))
    };
    drop(v513_5);
    let v513_9: Space = intersect(&(*CONSTANT_2),&(v513_2));
    drop(v513_2);
    let v513_10: Space = if has_head(&(v513_9)) { singleton(&[]) } else { Space::new() };
    drop(v513_9);
    let v513_13: Space = if (v513_10).is_empty() { Space::new() } else {
      let v524_11: Space = unwrap(&(v512_9),&(v512_28_head));
      let mut v524_12 = Space::new();
      let mut v524_12_cursor = (v524_11).read_zipper();
      for v524_12_byte in v524_12_cursor.child_mask().iter() {
        v524_12_cursor.descend_to_byte(v524_12_byte);
        {
        let v524_12_tail = v524_12_cursor.fork_read_zipper();
        let v524_12_head = Path::from_slice(&[v524_12_byte]);
        let v525_2: Space = singleton(&(v524_12_head));
        let v525_3: Space = intersect(&(*CONSTANT_2),&(v525_2));
        let v525_4: Space = if has_head(&(v525_3)) { singleton(&[]) } else { Space::new() };
        drop(v525_3);
        let v525_5: Space = subtract(&(*CONSTANT_1),&(v525_4));
        drop(v525_4);
        let v525_7: Space = if (v525_5).is_empty() { Space::new() } else {
          let mut v526_6 = Space::new();
          let mut v526_6_cursor = (v524_12_tail).read_zipper();
          for v526_6_byte in v526_6_cursor.child_mask().iter() {
            v526_6_cursor.descend_to_byte(v526_6_byte);
            {
            let v526_6_tail = v526_6_cursor.fork_read_zipper();
            let v526_6_head = Path::from_slice(&[v526_6_byte]);
            let v527_2: Space = singleton(&(v526_6_head));
            let v527_3: Space = intersect(&(*CONSTANT_2),&(v527_2));
            let v527_4: Space = if has_head(&(v527_3)) { singleton(&[]) } else { Space::new() };
            drop(v527_3);
            let v527_5: Space = subtract(&(*CONSTANT_1),&(v527_4));
            drop(v527_4);
            let v527_8: Space = if (v527_5).is_empty() { Space::new() } else {
              let v528_6: Path = concat_path(&(v524_12_head),&(v526_6_head));
              let v528_7: Space = routine_17(c, &(v528_6), &(*p1), &(v526_6_tail).make_space());
              compose(&(v527_5),&(v528_7))
            };
            drop(v527_5);
            let v527_9: Space = intersect(&(*CONSTANT_2),&(v527_2));
            drop(v527_2);
            let v527_10: Space = if has_head(&(v527_9)) { singleton(&[]) } else { Space::new() };
            drop(v527_9);
            let v527_12: Space = if (v527_10).is_empty() { Space::new() } else {
              let v529_6: Path = concat_path(&(v524_12_head),&(v526_6_head));
              let v529_11: Space = routine_18(c, &(v529_6), &(*p1), &(v526_6_tail).make_space());
              drop(v529_6);
              compose(&(v527_10),&(v529_11))
            };
            drop(v527_10);
            let v527_13: Space = unite(&(v527_8),&(v527_12));
            v526_6.join_into((v527_13).clone());
            }
            v526_6_cursor.ascend(1);
          }
          drop(v526_6_cursor);
          compose(&(v525_5),&(v526_6))
        };
        drop(v525_5);
        let v525_8: Space = intersect(&(*CONSTANT_2),&(v525_2));
        drop(v525_2);
        let v525_9: Space = if has_head(&(v525_8)) { singleton(&[]) } else { Space::new() };
        drop(v525_8);
        let v525_11: Space = if (v525_9).is_empty() { Space::new() } else {
          let mut v530_10 = Space::new();
          let mut v530_10_cursor = (v524_12_tail).read_zipper();
          for v530_10_byte in v530_10_cursor.child_mask().iter() {
            v530_10_cursor.descend_to_byte(v530_10_byte);
            {
            let v530_10_tail = v530_10_cursor.fork_read_zipper();
            let v530_10_head = Path::from_slice(&[v530_10_byte]);
            let v531_2: Space = singleton(&(v530_10_head));
            let v531_3: Space = intersect(&(*CONSTANT_2),&(v531_2));
            let v531_4: Space = if has_head(&(v531_3)) { singleton(&[]) } else { Space::new() };
            drop(v531_3);
            let v531_5: Space = subtract(&(*CONSTANT_1),&(v531_4));
            drop(v531_4);
            let v531_8: Space = if (v531_5).is_empty() { Space::new() } else {
              let v532_6: Path = concat_path(&(v524_12_head),&(v530_10_head));
              let v532_7: Space = routine_17(c, &(v532_6), &(*p1), &(v530_10_tail).make_space());
              compose(&(v531_5),&(v532_7))
            };
            drop(v531_5);
            let v531_9: Space = intersect(&(*CONSTANT_2),&(v531_2));
            drop(v531_2);
            let v531_10: Space = if has_head(&(v531_9)) { singleton(&[]) } else { Space::new() };
            drop(v531_9);
            let v531_12: Space = if (v531_10).is_empty() { Space::new() } else {
              let v533_6: Path = concat_path(&(v524_12_head),&(v530_10_head));
              let v533_11: Space = routine_19(c, &(v533_6), &(*p1), &(v530_10_tail).make_space());
              drop(v533_6);
              compose(&(v531_10),&(v533_11))
            };
            drop(v531_10);
            let v531_13: Space = unite(&(v531_8),&(v531_12));
            v530_10.join_into((v531_13).clone());
            }
            v530_10_cursor.ascend(1);
          }
          drop(v530_10_cursor);
          compose(&(v525_9),&(v530_10))
        };
        drop(v525_9);
        let v525_12: Space = unite(&(v525_7),&(v525_11));
        v524_12.join_into((v525_12).clone());
        }
        v524_12_cursor.ascend(1);
      }
      drop(v524_12_cursor);
      drop(v524_11);
      compose(&(v513_10),&(v524_12))
    };
    drop(v513_10);
    let v513_14: Space = unite(&(v513_8),&(v513_13));
    v512_28.join_into((v513_14).clone());
    }
    v512_28_cursor.ascend(1);
  }
  drop(v512_28_cursor);
  drop(v512_9);
  (v512_28).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v534_21 = Space::new();
  let mut v534_21_cursor = (*s0).read_zipper();
  for v534_21_byte in v534_21_cursor.child_mask().iter() {
    v534_21_cursor.descend_to_byte(v534_21_byte);
    {
    let v534_21_tail = v534_21_cursor.fork_read_zipper();
    let v534_21_head = Path::from_slice(&[v534_21_byte]);
    let v535_2: Space = singleton(&(v534_21_head));
    let v535_3: Space = intersect(&(*CONSTANT_2),&(v535_2));
    let v535_4: Space = if has_head(&(v535_3)) { singleton(&[]) } else { Space::new() };
    drop(v535_3);
    let v535_5: Space = subtract(&(*CONSTANT_1),&(v535_4));
    drop(v535_4);
    let v535_8: Space = if (v535_5).is_empty() { Space::new() } else {
      let v536_6: Path = concat_path(&(*p0),&(v534_21_head));
      let mut v536_7 = Space::new();
      let mut v536_7_cursor = (v534_21_tail).read_zipper();
      for v536_7_byte in v536_7_cursor.child_mask().iter() {
        v536_7_cursor.descend_to_byte(v536_7_byte);
        {
        let v536_7_tail = v536_7_cursor.fork_read_zipper();
        let v536_7_head = Path::from_slice(&[v536_7_byte]);
        let v537_2: Space = singleton(&(v536_7_head));
        let v537_3: Space = intersect(&(*CONSTANT_2),&(v537_2));
        let v537_4: Space = if has_head(&(v537_3)) { singleton(&[]) } else { Space::new() };
        drop(v537_3);
        let v537_5: Space = subtract(&(*CONSTANT_1),&(v537_4));
        drop(v537_4);
        let v537_8: Space = if (v537_5).is_empty() { Space::new() } else {
          let v538_6: Path = concat_path(&(v536_6),&(v536_7_head));
          let mut v538_7 = Space::new();
          let mut v538_7_cursor = (v536_7_tail).read_zipper();
          for v538_7_byte in v538_7_cursor.child_mask().iter() {
            v538_7_cursor.descend_to_byte(v538_7_byte);
            {
            let v538_7_tail = v538_7_cursor.fork_read_zipper();
            let v538_7_head = Path::from_slice(&[v538_7_byte]);
            let v539_2: Space = singleton(&(v538_7_head));
            let v539_3: Space = intersect(&(*CONSTANT_2),&(v539_2));
            let v539_4: Space = if has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
            drop(v539_3);
            let v539_5: Space = subtract(&(*CONSTANT_1),&(v539_4));
            drop(v539_4);
            let v539_8: Space = if (v539_5).is_empty() { Space::new() } else {
              let v540_6: Path = concat_path(&(v538_6),&(v538_7_head));
              let v540_7: Space = routine_40(c, &(v540_6), &(*p1), &(v538_7_tail).make_space());
              compose(&(v539_5),&(v540_7))
            };
            drop(v539_5);
            let v539_9: Space = intersect(&(*CONSTANT_2),&(v539_2));
            drop(v539_2);
            let v539_10: Space = if has_head(&(v539_9)) { singleton(&[]) } else { Space::new() };
            drop(v539_9);
            let v539_12: Space = if (v539_10).is_empty() { Space::new() } else {
              let v541_6: Path = concat_path(&(v538_6),&(v538_7_head));
              let v541_11: Space = routine_41(c, &(v541_6), &(*p1), &(v538_7_tail).make_space());
              drop(v541_6);
              compose(&(v539_10),&(v541_11))
            };
            drop(v539_10);
            let v539_13: Space = unite(&(v539_8),&(v539_12));
            v538_7.join_into((v539_13).clone());
            }
            v538_7_cursor.ascend(1);
          }
          drop(v538_7_cursor);
          compose(&(v537_5),&(v538_7))
        };
        drop(v537_5);
        let v537_9: Space = intersect(&(*CONSTANT_2),&(v537_2));
        drop(v537_2);
        let v537_10: Space = if has_head(&(v537_9)) { singleton(&[]) } else { Space::new() };
        drop(v537_9);
        let v537_12: Space = if (v537_10).is_empty() { Space::new() } else {
          let v542_6: Path = concat_path(&(v536_6),&(v536_7_head));
          let mut v542_11 = Space::new();
          let mut v542_11_cursor = (v536_7_tail).read_zipper();
          for v542_11_byte in v542_11_cursor.child_mask().iter() {
            v542_11_cursor.descend_to_byte(v542_11_byte);
            {
            let v542_11_tail = v542_11_cursor.fork_read_zipper();
            let v542_11_head = Path::from_slice(&[v542_11_byte]);
            let v543_2: Space = singleton(&(v542_11_head));
            let v543_3: Space = intersect(&(*CONSTANT_2),&(v543_2));
            let v543_4: Space = if has_head(&(v543_3)) { singleton(&[]) } else { Space::new() };
            drop(v543_3);
            let v543_5: Space = subtract(&(*CONSTANT_1),&(v543_4));
            drop(v543_4);
            let v543_8: Space = if (v543_5).is_empty() { Space::new() } else {
              let v544_6: Path = concat_path(&(v542_6),&(v542_11_head));
              let v544_7: Space = routine_40(c, &(v544_6), &(*p1), &(v542_11_tail).make_space());
              compose(&(v543_5),&(v544_7))
            };
            drop(v543_5);
            let v543_9: Space = intersect(&(*CONSTANT_2),&(v543_2));
            drop(v543_2);
            let v543_10: Space = if has_head(&(v543_9)) { singleton(&[]) } else { Space::new() };
            drop(v543_9);
            let v543_12: Space = if (v543_10).is_empty() { Space::new() } else {
              let v545_6: Path = concat_path(&(v542_6),&(v542_11_head));
              let v545_11: Space = routine_19(c, &(v545_6), &(*p1), &(v542_11_tail).make_space());
              drop(v545_6);
              compose(&(v543_10),&(v545_11))
            };
            drop(v543_10);
            let v543_13: Space = unite(&(v543_8),&(v543_12));
            v542_11.join_into((v543_13).clone());
            }
            v542_11_cursor.ascend(1);
          }
          drop(v542_11_cursor);
          drop(v542_6);
          compose(&(v537_10),&(v542_11))
        };
        drop(v537_10);
        let v537_13: Space = unite(&(v537_8),&(v537_12));
        v536_7.join_into((v537_13).clone());
        }
        v536_7_cursor.ascend(1);
      }
      drop(v536_7_cursor);
      compose(&(v535_5),&(v536_7))
    };
    drop(v535_5);
    let v535_9: Space = intersect(&(*CONSTANT_2),&(v535_2));
    drop(v535_2);
    let v535_10: Space = if has_head(&(v535_9)) { singleton(&[]) } else { Space::new() };
    drop(v535_9);
    let v535_12: Space = if (v535_10).is_empty() { Space::new() } else {
      let v546_6: Path = concat_path(&(*p0),&(v534_21_head));
      let mut v546_11 = Space::new();
      let mut v546_11_cursor = (v534_21_tail).read_zipper();
      for v546_11_byte in v546_11_cursor.child_mask().iter() {
        v546_11_cursor.descend_to_byte(v546_11_byte);
        {
        let v546_11_tail = v546_11_cursor.fork_read_zipper();
        let v546_11_head = Path::from_slice(&[v546_11_byte]);
        let v547_2: Space = singleton(&(v546_11_head));
        let v547_3: Space = intersect(&(*CONSTANT_2),&(v547_2));
        let v547_4: Space = if has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
        drop(v547_3);
        let v547_5: Space = subtract(&(*CONSTANT_1),&(v547_4));
        drop(v547_4);
        let v547_8: Space = if (v547_5).is_empty() { Space::new() } else {
          let v548_6: Path = concat_path(&(v546_6),&(v546_11_head));
          let mut v548_7 = Space::new();
          let mut v548_7_cursor = (v546_11_tail).read_zipper();
          for v548_7_byte in v548_7_cursor.child_mask().iter() {
            v548_7_cursor.descend_to_byte(v548_7_byte);
            {
            let v548_7_tail = v548_7_cursor.fork_read_zipper();
            let v548_7_head = Path::from_slice(&[v548_7_byte]);
            let v549_2: Space = singleton(&(v548_7_head));
            let v549_3: Space = intersect(&(*CONSTANT_2),&(v549_2));
            let v549_4: Space = if has_head(&(v549_3)) { singleton(&[]) } else { Space::new() };
            drop(v549_3);
            let v549_5: Space = subtract(&(*CONSTANT_1),&(v549_4));
            drop(v549_4);
            let v549_8: Space = if (v549_5).is_empty() { Space::new() } else {
              let v550_6: Path = concat_path(&(v548_6),&(v548_7_head));
              let v550_7: Space = routine_40(c, &(v550_6), &(*p1), &(v548_7_tail).make_space());
              compose(&(v549_5),&(v550_7))
            };
            drop(v549_5);
            let v549_9: Space = intersect(&(*CONSTANT_2),&(v549_2));
            drop(v549_2);
            let v549_10: Space = if has_head(&(v549_9)) { singleton(&[]) } else { Space::new() };
            drop(v549_9);
            let v549_12: Space = if (v549_10).is_empty() { Space::new() } else {
              let v551_6: Path = concat_path(&(v548_6),&(v548_7_head));
              let v551_11: Space = routine_41(c, &(v551_6), &(*p1), &(v548_7_tail).make_space());
              drop(v551_6);
              compose(&(v549_10),&(v551_11))
            };
            drop(v549_10);
            let v549_13: Space = unite(&(v549_8),&(v549_12));
            v548_7.join_into((v549_13).clone());
            }
            v548_7_cursor.ascend(1);
          }
          drop(v548_7_cursor);
          compose(&(v547_5),&(v548_7))
        };
        drop(v547_5);
        let v547_9: Space = intersect(&(*CONSTANT_2),&(v547_2));
        drop(v547_2);
        let v547_10: Space = if has_head(&(v547_9)) { singleton(&[]) } else { Space::new() };
        drop(v547_9);
        let v547_11: Space = compose(&(v547_10),&(v546_11_tail));
        drop(v547_10);
        let v552_6: Path = concat_path(&(v546_6),&(v546_11_head));
        let v547_12: Space = wrap(&(v547_11),&(v552_6));
        drop(v547_11);
        let v547_13: Space = wrap(&(v547_12),&(*p1));
        drop(v547_12);
        let v547_14: Space = unite(&(v547_8),&(v547_13));
        drop(v547_13);
        v546_11.join_into((v547_14).clone());
        }
        v546_11_cursor.ascend(1);
      }
      drop(v546_11_cursor);
      drop(v546_6);
      compose(&(v535_10),&(v546_11))
    };
    drop(v535_10);
    let v535_13: Space = unite(&(v535_8),&(v535_12));
    v534_21.join_into((v535_13).clone());
    }
    v534_21_cursor.ascend(1);
  }
  drop(v534_21_cursor);
  (v534_21).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v553_15 = Space::new();
  let mut v553_15_cursor = (*s0).read_zipper();
  for v553_15_byte in v553_15_cursor.child_mask().iter() {
    v553_15_cursor.descend_to_byte(v553_15_byte);
    {
    let v553_15_tail = v553_15_cursor.fork_read_zipper();
    let v553_15_head = Path::from_slice(&[v553_15_byte]);
    let v554_2: Space = singleton(&(v553_15_head));
    let v554_3: Space = intersect(&(*CONSTANT_2),&(v554_2));
    let v554_4: Space = if has_head(&(v554_3)) { singleton(&[]) } else { Space::new() };
    drop(v554_3);
    let v554_5: Space = subtract(&(*CONSTANT_1),&(v554_4));
    drop(v554_4);
    let v554_8: Space = if (v554_5).is_empty() { Space::new() } else {
      let v555_6: Path = concat_path(&(*p0),&(v553_15_head));
      let mut v555_7 = Space::new();
      let mut v555_7_cursor = (v553_15_tail).read_zipper();
      for v555_7_byte in v555_7_cursor.child_mask().iter() {
        v555_7_cursor.descend_to_byte(v555_7_byte);
        {
        let v555_7_tail = v555_7_cursor.fork_read_zipper();
        let v555_7_head = Path::from_slice(&[v555_7_byte]);
        let v556_2: Space = singleton(&(v555_7_head));
        let v556_3: Space = intersect(&(*CONSTANT_2),&(v556_2));
        let v556_4: Space = if has_head(&(v556_3)) { singleton(&[]) } else { Space::new() };
        drop(v556_3);
        let v556_5: Space = subtract(&(*CONSTANT_1),&(v556_4));
        drop(v556_4);
        let v556_8: Space = if (v556_5).is_empty() { Space::new() } else {
          let v557_6: Path = concat_path(&(v555_6),&(v555_7_head));
          let mut v557_7 = Space::new();
          let mut v557_7_cursor = (v555_7_tail).read_zipper();
          for v557_7_byte in v557_7_cursor.child_mask().iter() {
            v557_7_cursor.descend_to_byte(v557_7_byte);
            {
            let v557_7_tail = v557_7_cursor.fork_read_zipper();
            let v557_7_head = Path::from_slice(&[v557_7_byte]);
            let v558_2: Space = singleton(&(v557_7_head));
            let v558_3: Space = intersect(&(*CONSTANT_2),&(v558_2));
            let v558_4: Space = if has_head(&(v558_3)) { singleton(&[]) } else { Space::new() };
            drop(v558_3);
            let v558_5: Space = subtract(&(*CONSTANT_1),&(v558_4));
            drop(v558_4);
            let v558_8: Space = if (v558_5).is_empty() { Space::new() } else {
              let v559_6: Path = concat_path(&(v557_6),&(v557_7_head));
              let v559_7: Space = routine_40(c, &(v559_6), &(*p1), &(v557_7_tail).make_space());
              compose(&(v558_5),&(v559_7))
            };
            drop(v558_5);
            let v558_9: Space = intersect(&(*CONSTANT_2),&(v558_2));
            drop(v558_2);
            let v558_10: Space = if has_head(&(v558_9)) { singleton(&[]) } else { Space::new() };
            drop(v558_9);
            let v558_12: Space = if (v558_10).is_empty() { Space::new() } else {
              let v560_6: Path = concat_path(&(v557_6),&(v557_7_head));
              let v560_11: Space = routine_41(c, &(v560_6), &(*p1), &(v557_7_tail).make_space());
              drop(v560_6);
              compose(&(v558_10),&(v560_11))
            };
            drop(v558_10);
            let v558_13: Space = unite(&(v558_8),&(v558_12));
            v557_7.join_into((v558_13).clone());
            }
            v557_7_cursor.ascend(1);
          }
          drop(v557_7_cursor);
          compose(&(v556_5),&(v557_7))
        };
        drop(v556_5);
        let v556_9: Space = intersect(&(*CONSTANT_2),&(v556_2));
        drop(v556_2);
        let v556_10: Space = if has_head(&(v556_9)) { singleton(&[]) } else { Space::new() };
        drop(v556_9);
        let v556_12: Space = if (v556_10).is_empty() { Space::new() } else {
          let v561_6: Path = concat_path(&(v555_6),&(v555_7_head));
          let mut v561_11 = Space::new();
          let mut v561_11_cursor = (v555_7_tail).read_zipper();
          for v561_11_byte in v561_11_cursor.child_mask().iter() {
            v561_11_cursor.descend_to_byte(v561_11_byte);
            {
            let v561_11_tail = v561_11_cursor.fork_read_zipper();
            let v561_11_head = Path::from_slice(&[v561_11_byte]);
            let v562_2: Space = singleton(&(v561_11_head));
            let v562_3: Space = intersect(&(*CONSTANT_2),&(v562_2));
            let v562_4: Space = if has_head(&(v562_3)) { singleton(&[]) } else { Space::new() };
            drop(v562_3);
            let v562_5: Space = subtract(&(*CONSTANT_1),&(v562_4));
            drop(v562_4);
            let v562_8: Space = if (v562_5).is_empty() { Space::new() } else {
              let v563_6: Path = concat_path(&(v561_6),&(v561_11_head));
              let v563_7: Space = routine_40(c, &(v563_6), &(*p1), &(v561_11_tail).make_space());
              compose(&(v562_5),&(v563_7))
            };
            drop(v562_5);
            let v562_9: Space = intersect(&(*CONSTANT_2),&(v562_2));
            drop(v562_2);
            let v562_10: Space = if has_head(&(v562_9)) { singleton(&[]) } else { Space::new() };
            drop(v562_9);
            let v562_12: Space = if (v562_10).is_empty() { Space::new() } else {
              let v564_6: Path = concat_path(&(v561_6),&(v561_11_head));
              let v564_11: Space = routine_19(c, &(v564_6), &(*p1), &(v561_11_tail).make_space());
              drop(v564_6);
              compose(&(v562_10),&(v564_11))
            };
            drop(v562_10);
            let v562_13: Space = unite(&(v562_8),&(v562_12));
            v561_11.join_into((v562_13).clone());
            }
            v561_11_cursor.ascend(1);
          }
          drop(v561_11_cursor);
          drop(v561_6);
          compose(&(v556_10),&(v561_11))
        };
        drop(v556_10);
        let v556_13: Space = unite(&(v556_8),&(v556_12));
        v555_7.join_into((v556_13).clone());
        }
        v555_7_cursor.ascend(1);
      }
      drop(v555_7_cursor);
      compose(&(v554_5),&(v555_7))
    };
    drop(v554_5);
    let v554_9: Space = intersect(&(*CONSTANT_2),&(v554_2));
    drop(v554_2);
    let v554_10: Space = if has_head(&(v554_9)) { singleton(&[]) } else { Space::new() };
    drop(v554_9);
    let v554_11: Space = compose(&(v554_10),&(v553_15_tail));
    drop(v554_10);
    let v565_6: Path = concat_path(&(*p0),&(v553_15_head));
    let v554_12: Space = wrap(&(v554_11),&(v565_6));
    drop(v554_11);
    let v554_13: Space = wrap(&(v554_12),&(*p1));
    drop(v554_12);
    let v554_14: Space = unite(&(v554_8),&(v554_13));
    drop(v554_13);
    v553_15.join_into((v554_14).clone());
    }
    v553_15_cursor.ascend(1);
  }
  drop(v553_15_cursor);
  (v553_15).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v566_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v566_21: Space = unwrap(&(v566_20),&(*p0));
  drop(v566_20);
  let mut v566_28 = Space::new();
  let mut v566_28_cursor = (*s0).read_zipper();
  for v566_28_byte in v566_28_cursor.child_mask().iter() {
    v566_28_cursor.descend_to_byte(v566_28_byte);
    {
    let v566_28_tail = v566_28_cursor.fork_read_zipper();
    let v566_28_head = Path::from_slice(&[v566_28_byte]);
    let v567_2: Space = singleton(&(v566_28_head));
    let v567_3: Space = intersect(&(*CONSTANT_2),&(v567_2));
    let v567_4: Space = if has_head(&(v567_3)) { singleton(&[]) } else { Space::new() };
    drop(v567_3);
    let v567_5: Space = subtract(&(*CONSTANT_1),&(v567_4));
    drop(v567_4);
    let v567_8: Space = if (v567_5).is_empty() { Space::new() } else {
      let v568_6: Path = concat_path(&(*p0),&(v566_28_head));
      let mut v568_7 = Space::new();
      let mut v568_7_cursor = (v566_28_tail).read_zipper();
      for v568_7_byte in v568_7_cursor.child_mask().iter() {
        v568_7_cursor.descend_to_byte(v568_7_byte);
        {
        let v568_7_tail = v568_7_cursor.fork_read_zipper();
        let v568_7_head = Path::from_slice(&[v568_7_byte]);
        let v569_2: Space = singleton(&(v568_7_head));
        let v569_3: Space = intersect(&(*CONSTANT_2),&(v569_2));
        let v569_4: Space = if has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
        drop(v569_3);
        let v569_5: Space = subtract(&(*CONSTANT_1),&(v569_4));
        drop(v569_4);
        let v569_8: Space = if (v569_5).is_empty() { Space::new() } else {
          let v570_6: Path = concat_path(&(v568_6),&(v568_7_head));
          let mut v570_7 = Space::new();
          let mut v570_7_cursor = (v568_7_tail).read_zipper();
          for v570_7_byte in v570_7_cursor.child_mask().iter() {
            v570_7_cursor.descend_to_byte(v570_7_byte);
            {
            let v570_7_tail = v570_7_cursor.fork_read_zipper();
            let v570_7_head = Path::from_slice(&[v570_7_byte]);
            let v571_2: Space = singleton(&(v570_7_head));
            let v571_3: Space = intersect(&(*CONSTANT_2),&(v571_2));
            let v571_4: Space = if has_head(&(v571_3)) { singleton(&[]) } else { Space::new() };
            drop(v571_3);
            let v571_5: Space = subtract(&(*CONSTANT_1),&(v571_4));
            drop(v571_4);
            let v571_8: Space = if (v571_5).is_empty() { Space::new() } else {
              let v572_6: Path = concat_path(&(v570_6),&(v570_7_head));
              let v572_7: Space = routine_42(c, &(v572_6), &(*p1), &(v570_7_tail).make_space(), &(*s1));
              compose(&(v571_5),&(v572_7))
            };
            drop(v571_5);
            let v571_9: Space = intersect(&(*CONSTANT_2),&(v571_2));
            drop(v571_2);
            let v571_10: Space = if has_head(&(v571_9)) { singleton(&[]) } else { Space::new() };
            drop(v571_9);
            let v571_12: Space = if (v571_10).is_empty() { Space::new() } else {
              let v573_6: Path = concat_path(&(v570_6),&(v570_7_head));
              let v573_11: Space = routine_43(c, &(v573_6), &(*p1), &(v570_7_tail).make_space(), &(*s1));
              drop(v573_6);
              compose(&(v571_10),&(v573_11))
            };
            drop(v571_10);
            let v571_13: Space = unite(&(v571_8),&(v571_12));
            v570_7.join_into((v571_13).clone());
            }
            v570_7_cursor.ascend(1);
          }
          drop(v570_7_cursor);
          compose(&(v569_5),&(v570_7))
        };
        drop(v569_5);
        let v569_9: Space = intersect(&(*CONSTANT_2),&(v569_2));
        drop(v569_2);
        let v569_10: Space = if has_head(&(v569_9)) { singleton(&[]) } else { Space::new() };
        drop(v569_9);
        let v569_12: Space = if (v569_10).is_empty() { Space::new() } else {
          let v574_6: Path = concat_path(&(v568_6),&(v568_7_head));
          let mut v574_11 = Space::new();
          let mut v574_11_cursor = (v568_7_tail).read_zipper();
          for v574_11_byte in v574_11_cursor.child_mask().iter() {
            v574_11_cursor.descend_to_byte(v574_11_byte);
            {
            let v574_11_tail = v574_11_cursor.fork_read_zipper();
            let v574_11_head = Path::from_slice(&[v574_11_byte]);
            let v575_2: Space = singleton(&(v574_11_head));
            let v575_3: Space = intersect(&(*CONSTANT_2),&(v575_2));
            let v575_4: Space = if has_head(&(v575_3)) { singleton(&[]) } else { Space::new() };
            drop(v575_3);
            let v575_5: Space = subtract(&(*CONSTANT_1),&(v575_4));
            drop(v575_4);
            let v575_8: Space = if (v575_5).is_empty() { Space::new() } else {
              let v576_6: Path = concat_path(&(v574_6),&(v574_11_head));
              let v576_7: Space = routine_42(c, &(v576_6), &(*p1), &(v574_11_tail).make_space(), &(*s1));
              compose(&(v575_5),&(v576_7))
            };
            drop(v575_5);
            let v575_9: Space = intersect(&(*CONSTANT_2),&(v575_2));
            drop(v575_2);
            let v575_10: Space = if has_head(&(v575_9)) { singleton(&[]) } else { Space::new() };
            drop(v575_9);
            let v575_12: Space = if (v575_10).is_empty() { Space::new() } else {
              let v577_6: Path = concat_path(&(v574_6),&(v574_11_head));
              let v577_11: Space = routine_10(c, &(v577_6), &(*p1), &(v574_11_tail).make_space(), &(*s1));
              drop(v577_6);
              compose(&(v575_10),&(v577_11))
            };
            drop(v575_10);
            let v575_13: Space = unite(&(v575_8),&(v575_12));
            v574_11.join_into((v575_13).clone());
            }
            v574_11_cursor.ascend(1);
          }
          drop(v574_11_cursor);
          drop(v574_6);
          compose(&(v569_10),&(v574_11))
        };
        drop(v569_10);
        let v569_13: Space = unite(&(v569_8),&(v569_12));
        v568_7.join_into((v569_13).clone());
        }
        v568_7_cursor.ascend(1);
      }
      drop(v568_7_cursor);
      compose(&(v567_5),&(v568_7))
    };
    drop(v567_5);
    let v567_9: Space = intersect(&(*CONSTANT_2),&(v567_2));
    drop(v567_2);
    let v567_10: Space = if has_head(&(v567_9)) { singleton(&[]) } else { Space::new() };
    drop(v567_9);
    let v567_13: Space = if (v567_10).is_empty() { Space::new() } else {
      let v578_6: Path = concat_path(&(*p0),&(v566_28_head));
      let v578_11: Space = unwrap(&(v566_21),&(v566_28_head));
      let mut v578_12 = Space::new();
      let mut v578_12_cursor = (v566_28_tail).read_zipper();
      for v578_12_byte in v578_12_cursor.child_mask().iter() {
        v578_12_cursor.descend_to_byte(v578_12_byte);
        {
        let v578_12_tail = v578_12_cursor.fork_read_zipper();
        let v578_12_head = Path::from_slice(&[v578_12_byte]);
        let v579_2: Space = singleton(&(v578_12_head));
        let v579_3: Space = intersect(&(*CONSTANT_2),&(v579_2));
        let v579_4: Space = if has_head(&(v579_3)) { singleton(&[]) } else { Space::new() };
        drop(v579_3);
        let v579_5: Space = subtract(&(*CONSTANT_1),&(v579_4));
        drop(v579_4);
        let v579_8: Space = if (v579_5).is_empty() { Space::new() } else {
          let v580_6: Path = concat_path(&(v578_6),&(v578_12_head));
          let mut v580_7 = Space::new();
          let mut v580_7_cursor = (v578_12_tail).read_zipper();
          for v580_7_byte in v580_7_cursor.child_mask().iter() {
            v580_7_cursor.descend_to_byte(v580_7_byte);
            {
            let v580_7_tail = v580_7_cursor.fork_read_zipper();
            let v580_7_head = Path::from_slice(&[v580_7_byte]);
            let v581_2: Space = singleton(&(v580_7_head));
            let v581_3: Space = intersect(&(*CONSTANT_2),&(v581_2));
            let v581_4: Space = if has_head(&(v581_3)) { singleton(&[]) } else { Space::new() };
            drop(v581_3);
            let v581_5: Space = subtract(&(*CONSTANT_1),&(v581_4));
            drop(v581_4);
            let v581_8: Space = if (v581_5).is_empty() { Space::new() } else {
              let v582_6: Path = concat_path(&(v580_6),&(v580_7_head));
              let v582_7: Space = routine_42(c, &(v582_6), &(*p1), &(v580_7_tail).make_space(), &(*s1));
              compose(&(v581_5),&(v582_7))
            };
            drop(v581_5);
            let v581_9: Space = intersect(&(*CONSTANT_2),&(v581_2));
            drop(v581_2);
            let v581_10: Space = if has_head(&(v581_9)) { singleton(&[]) } else { Space::new() };
            drop(v581_9);
            let v581_12: Space = if (v581_10).is_empty() { Space::new() } else {
              let v583_6: Path = concat_path(&(v580_6),&(v580_7_head));
              let v583_11: Space = routine_43(c, &(v583_6), &(*p1), &(v580_7_tail).make_space(), &(*s1));
              drop(v583_6);
              compose(&(v581_10),&(v583_11))
            };
            drop(v581_10);
            let v581_13: Space = unite(&(v581_8),&(v581_12));
            v580_7.join_into((v581_13).clone());
            }
            v580_7_cursor.ascend(1);
          }
          drop(v580_7_cursor);
          drop(v580_6);
          compose(&(v579_5),&(v580_7))
        };
        drop(v579_5);
        let v579_9: Space = intersect(&(*CONSTANT_2),&(v579_2));
        drop(v579_2);
        let v579_10: Space = if has_head(&(v579_9)) { singleton(&[]) } else { Space::new() };
        drop(v579_9);
        let v579_13: Space = if (v579_10).is_empty() { Space::new() } else {
          let v584_11: Space = unwrap(&(v578_11),&(v578_12_head));
          let mut v584_12 = Space::new();
          let mut v584_12_cursor = (v584_11).read_zipper();
          for v584_12_byte in v584_12_cursor.child_mask().iter() {
            v584_12_cursor.descend_to_byte(v584_12_byte);
            {
            let v584_12_tail = v584_12_cursor.fork_read_zipper();
            let v584_12_head = Path::from_slice(&[v584_12_byte]);
            let v585_2: Space = singleton(&(v584_12_head));
            let v585_3: Space = intersect(&(*CONSTANT_2),&(v585_2));
            let v585_4: Space = if has_head(&(v585_3)) { singleton(&[]) } else { Space::new() };
            drop(v585_3);
            let v585_5: Space = subtract(&(*CONSTANT_1),&(v585_4));
            drop(v585_4);
            let v585_7: Space = if (v585_5).is_empty() { Space::new() } else {
              let v586_6: Space = routine_13(c, &(v584_12_head), &(*p1), &(v584_12_tail).make_space());
              compose(&(v585_5),&(v586_6))
            };
            drop(v585_5);
            let v585_8: Space = intersect(&(*CONSTANT_2),&(v585_2));
            drop(v585_2);
            let v585_9: Space = if has_head(&(v585_8)) { singleton(&[]) } else { Space::new() };
            drop(v585_8);
            let v585_11: Space = if (v585_9).is_empty() { Space::new() } else {
              let v587_10: Space = routine_14(c, &(v584_12_head), &(*p1), &(v584_12_tail).make_space());
              compose(&(v585_9),&(v587_10))
            };
            drop(v585_9);
            let v585_12: Space = unite(&(v585_7),&(v585_11));
            v584_12.join_into((v585_12).clone());
            }
            v584_12_cursor.ascend(1);
          }
          drop(v584_12_cursor);
          drop(v584_11);
          compose(&(v579_10),&(v584_12))
        };
        drop(v579_10);
        let v579_14: Space = unite(&(v579_8),&(v579_13));
        v578_12.join_into((v579_14).clone());
        }
        v578_12_cursor.ascend(1);
      }
      drop(v578_12_cursor);
      drop(v578_6);
      drop(v578_11);
      compose(&(v567_10),&(v578_12))
    };
    drop(v567_10);
    let v567_14: Space = unite(&(v567_8),&(v567_13));
    v566_28.join_into((v567_14).clone());
    }
    v566_28_cursor.ascend(1);
  }
  drop(v566_28_cursor);
  drop(v566_21);
  (v566_28).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v588_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v588_9: Space = unwrap(&(v588_8),&(*p0));
  drop(v588_8);
  let mut v588_28 = Space::new();
  let mut v588_28_cursor = (*s0).read_zipper();
  for v588_28_byte in v588_28_cursor.child_mask().iter() {
    v588_28_cursor.descend_to_byte(v588_28_byte);
    {
    let v588_28_tail = v588_28_cursor.fork_read_zipper();
    let v588_28_head = Path::from_slice(&[v588_28_byte]);
    let v589_2: Space = singleton(&(v588_28_head));
    let v589_3: Space = intersect(&(*CONSTANT_2),&(v589_2));
    let v589_4: Space = if has_head(&(v589_3)) { singleton(&[]) } else { Space::new() };
    drop(v589_3);
    let v589_5: Space = subtract(&(*CONSTANT_1),&(v589_4));
    drop(v589_4);
    let v589_8: Space = if (v589_5).is_empty() { Space::new() } else {
      let v590_6: Path = concat_path(&(*p0),&(v588_28_head));
      let mut v590_7 = Space::new();
      let mut v590_7_cursor = (v588_28_tail).read_zipper();
      for v590_7_byte in v590_7_cursor.child_mask().iter() {
        v590_7_cursor.descend_to_byte(v590_7_byte);
        {
        let v590_7_tail = v590_7_cursor.fork_read_zipper();
        let v590_7_head = Path::from_slice(&[v590_7_byte]);
        let v591_2: Space = singleton(&(v590_7_head));
        let v591_3: Space = intersect(&(*CONSTANT_2),&(v591_2));
        let v591_4: Space = if has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
        drop(v591_3);
        let v591_5: Space = subtract(&(*CONSTANT_1),&(v591_4));
        drop(v591_4);
        let v591_8: Space = if (v591_5).is_empty() { Space::new() } else {
          let v592_6: Path = concat_path(&(v590_6),&(v590_7_head));
          let mut v592_7 = Space::new();
          let mut v592_7_cursor = (v590_7_tail).read_zipper();
          for v592_7_byte in v592_7_cursor.child_mask().iter() {
            v592_7_cursor.descend_to_byte(v592_7_byte);
            {
            let v592_7_tail = v592_7_cursor.fork_read_zipper();
            let v592_7_head = Path::from_slice(&[v592_7_byte]);
            let v593_2: Space = singleton(&(v592_7_head));
            let v593_3: Space = intersect(&(*CONSTANT_2),&(v593_2));
            let v593_4: Space = if has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
            drop(v593_3);
            let v593_5: Space = subtract(&(*CONSTANT_1),&(v593_4));
            drop(v593_4);
            let v593_8: Space = if (v593_5).is_empty() { Space::new() } else {
              let v594_6: Path = concat_path(&(v592_6),&(v592_7_head));
              let v594_7: Space = routine_42(c, &(v594_6), &(*p1), &(v592_7_tail).make_space(), &(*s1));
              compose(&(v593_5),&(v594_7))
            };
            drop(v593_5);
            let v593_9: Space = intersect(&(*CONSTANT_2),&(v593_2));
            drop(v593_2);
            let v593_10: Space = if has_head(&(v593_9)) { singleton(&[]) } else { Space::new() };
            drop(v593_9);
            let v593_12: Space = if (v593_10).is_empty() { Space::new() } else {
              let v595_6: Path = concat_path(&(v592_6),&(v592_7_head));
              let v595_11: Space = routine_43(c, &(v595_6), &(*p1), &(v592_7_tail).make_space(), &(*s1));
              drop(v595_6);
              compose(&(v593_10),&(v595_11))
            };
            drop(v593_10);
            let v593_13: Space = unite(&(v593_8),&(v593_12));
            v592_7.join_into((v593_13).clone());
            }
            v592_7_cursor.ascend(1);
          }
          drop(v592_7_cursor);
          compose(&(v591_5),&(v592_7))
        };
        drop(v591_5);
        let v591_9: Space = intersect(&(*CONSTANT_2),&(v591_2));
        drop(v591_2);
        let v591_10: Space = if has_head(&(v591_9)) { singleton(&[]) } else { Space::new() };
        drop(v591_9);
        let v591_12: Space = if (v591_10).is_empty() { Space::new() } else {
          let v596_6: Path = concat_path(&(v590_6),&(v590_7_head));
          let mut v596_11 = Space::new();
          let mut v596_11_cursor = (v590_7_tail).read_zipper();
          for v596_11_byte in v596_11_cursor.child_mask().iter() {
            v596_11_cursor.descend_to_byte(v596_11_byte);
            {
            let v596_11_tail = v596_11_cursor.fork_read_zipper();
            let v596_11_head = Path::from_slice(&[v596_11_byte]);
            let v597_2: Space = singleton(&(v596_11_head));
            let v597_3: Space = intersect(&(*CONSTANT_2),&(v597_2));
            let v597_4: Space = if has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
            drop(v597_3);
            let v597_5: Space = subtract(&(*CONSTANT_1),&(v597_4));
            drop(v597_4);
            let v597_8: Space = if (v597_5).is_empty() { Space::new() } else {
              let v598_6: Path = concat_path(&(v596_6),&(v596_11_head));
              let v598_7: Space = routine_42(c, &(v598_6), &(*p1), &(v596_11_tail).make_space(), &(*s1));
              compose(&(v597_5),&(v598_7))
            };
            drop(v597_5);
            let v597_9: Space = intersect(&(*CONSTANT_2),&(v597_2));
            drop(v597_2);
            let v597_10: Space = if has_head(&(v597_9)) { singleton(&[]) } else { Space::new() };
            drop(v597_9);
            let v597_12: Space = if (v597_10).is_empty() { Space::new() } else {
              let v599_6: Path = concat_path(&(v596_6),&(v596_11_head));
              let v599_11: Space = routine_10(c, &(v599_6), &(*p1), &(v596_11_tail).make_space(), &(*s1));
              drop(v599_6);
              compose(&(v597_10),&(v599_11))
            };
            drop(v597_10);
            let v597_13: Space = unite(&(v597_8),&(v597_12));
            v596_11.join_into((v597_13).clone());
            }
            v596_11_cursor.ascend(1);
          }
          drop(v596_11_cursor);
          drop(v596_6);
          compose(&(v591_10),&(v596_11))
        };
        drop(v591_10);
        let v591_13: Space = unite(&(v591_8),&(v591_12));
        v590_7.join_into((v591_13).clone());
        }
        v590_7_cursor.ascend(1);
      }
      drop(v590_7_cursor);
      drop(v590_6);
      compose(&(v589_5),&(v590_7))
    };
    drop(v589_5);
    let v589_9: Space = intersect(&(*CONSTANT_2),&(v589_2));
    drop(v589_2);
    let v589_10: Space = if has_head(&(v589_9)) { singleton(&[]) } else { Space::new() };
    drop(v589_9);
    let v589_13: Space = if (v589_10).is_empty() { Space::new() } else {
      let v600_11: Space = unwrap(&(v588_9),&(v588_28_head));
      let mut v600_12 = Space::new();
      let mut v600_12_cursor = (v600_11).read_zipper();
      for v600_12_byte in v600_12_cursor.child_mask().iter() {
        v600_12_cursor.descend_to_byte(v600_12_byte);
        {
        let v600_12_tail = v600_12_cursor.fork_read_zipper();
        let v600_12_head = Path::from_slice(&[v600_12_byte]);
        let v601_2: Space = singleton(&(v600_12_head));
        let v601_3: Space = intersect(&(*CONSTANT_2),&(v601_2));
        let v601_4: Space = if has_head(&(v601_3)) { singleton(&[]) } else { Space::new() };
        drop(v601_3);
        let v601_5: Space = subtract(&(*CONSTANT_1),&(v601_4));
        drop(v601_4);
        let v601_7: Space = if (v601_5).is_empty() { Space::new() } else {
          let mut v602_6 = Space::new();
          let mut v602_6_cursor = (v600_12_tail).read_zipper();
          for v602_6_byte in v602_6_cursor.child_mask().iter() {
            v602_6_cursor.descend_to_byte(v602_6_byte);
            {
            let v602_6_tail = v602_6_cursor.fork_read_zipper();
            let v602_6_head = Path::from_slice(&[v602_6_byte]);
            let v603_2: Space = singleton(&(v602_6_head));
            let v603_3: Space = intersect(&(*CONSTANT_2),&(v603_2));
            let v603_4: Space = if has_head(&(v603_3)) { singleton(&[]) } else { Space::new() };
            drop(v603_3);
            let v603_5: Space = subtract(&(*CONSTANT_1),&(v603_4));
            drop(v603_4);
            let v603_8: Space = if (v603_5).is_empty() { Space::new() } else {
              let v604_6: Path = concat_path(&(v600_12_head),&(v602_6_head));
              let v604_7: Space = routine_17(c, &(v604_6), &(*p1), &(v602_6_tail).make_space());
              compose(&(v603_5),&(v604_7))
            };
            drop(v603_5);
            let v603_9: Space = intersect(&(*CONSTANT_2),&(v603_2));
            drop(v603_2);
            let v603_10: Space = if has_head(&(v603_9)) { singleton(&[]) } else { Space::new() };
            drop(v603_9);
            let v603_12: Space = if (v603_10).is_empty() { Space::new() } else {
              let v605_6: Path = concat_path(&(v600_12_head),&(v602_6_head));
              let v605_11: Space = routine_18(c, &(v605_6), &(*p1), &(v602_6_tail).make_space());
              drop(v605_6);
              compose(&(v603_10),&(v605_11))
            };
            drop(v603_10);
            let v603_13: Space = unite(&(v603_8),&(v603_12));
            v602_6.join_into((v603_13).clone());
            }
            v602_6_cursor.ascend(1);
          }
          drop(v602_6_cursor);
          compose(&(v601_5),&(v602_6))
        };
        drop(v601_5);
        let v601_8: Space = intersect(&(*CONSTANT_2),&(v601_2));
        drop(v601_2);
        let v601_9: Space = if has_head(&(v601_8)) { singleton(&[]) } else { Space::new() };
        drop(v601_8);
        let v601_11: Space = if (v601_9).is_empty() { Space::new() } else {
          let mut v606_10 = Space::new();
          let mut v606_10_cursor = (v600_12_tail).read_zipper();
          for v606_10_byte in v606_10_cursor.child_mask().iter() {
            v606_10_cursor.descend_to_byte(v606_10_byte);
            {
            let v606_10_tail = v606_10_cursor.fork_read_zipper();
            let v606_10_head = Path::from_slice(&[v606_10_byte]);
            let v607_2: Space = singleton(&(v606_10_head));
            let v607_3: Space = intersect(&(*CONSTANT_2),&(v607_2));
            let v607_4: Space = if has_head(&(v607_3)) { singleton(&[]) } else { Space::new() };
            drop(v607_3);
            let v607_5: Space = subtract(&(*CONSTANT_1),&(v607_4));
            drop(v607_4);
            let v607_8: Space = if (v607_5).is_empty() { Space::new() } else {
              let v608_6: Path = concat_path(&(v600_12_head),&(v606_10_head));
              let v608_7: Space = routine_17(c, &(v608_6), &(*p1), &(v606_10_tail).make_space());
              compose(&(v607_5),&(v608_7))
            };
            drop(v607_5);
            let v607_9: Space = intersect(&(*CONSTANT_2),&(v607_2));
            drop(v607_2);
            let v607_10: Space = if has_head(&(v607_9)) { singleton(&[]) } else { Space::new() };
            drop(v607_9);
            let v607_12: Space = if (v607_10).is_empty() { Space::new() } else {
              let v609_6: Path = concat_path(&(v600_12_head),&(v606_10_head));
              let v609_11: Space = routine_19(c, &(v609_6), &(*p1), &(v606_10_tail).make_space());
              drop(v609_6);
              compose(&(v607_10),&(v609_11))
            };
            drop(v607_10);
            let v607_13: Space = unite(&(v607_8),&(v607_12));
            v606_10.join_into((v607_13).clone());
            }
            v606_10_cursor.ascend(1);
          }
          drop(v606_10_cursor);
          compose(&(v601_9),&(v606_10))
        };
        drop(v601_9);
        let v601_12: Space = unite(&(v601_7),&(v601_11));
        v600_12.join_into((v601_12).clone());
        }
        v600_12_cursor.ascend(1);
      }
      drop(v600_12_cursor);
      drop(v600_11);
      compose(&(v589_10),&(v600_12))
    };
    drop(v589_10);
    let v589_14: Space = unite(&(v589_8),&(v589_13));
    v588_28.join_into((v589_14).clone());
    }
    v588_28_cursor.ascend(1);
  }
  drop(v588_28_cursor);
  drop(v588_9);
  (v588_28).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v610_21 = Space::new();
  let mut v610_21_cursor = (*s0).read_zipper();
  for v610_21_byte in v610_21_cursor.child_mask().iter() {
    v610_21_cursor.descend_to_byte(v610_21_byte);
    {
    let v610_21_tail = v610_21_cursor.fork_read_zipper();
    let v610_21_head = Path::from_slice(&[v610_21_byte]);
    let v611_2: Space = singleton(&(v610_21_head));
    let v611_3: Space = intersect(&(*CONSTANT_2),&(v611_2));
    let v611_4: Space = if has_head(&(v611_3)) { singleton(&[]) } else { Space::new() };
    drop(v611_3);
    let v611_5: Space = subtract(&(*CONSTANT_1),&(v611_4));
    drop(v611_4);
    let v611_8: Space = if (v611_5).is_empty() { Space::new() } else {
      let v612_6: Path = concat_path(&(*p0),&(v610_21_head));
      let mut v612_7 = Space::new();
      let mut v612_7_cursor = (v610_21_tail).read_zipper();
      for v612_7_byte in v612_7_cursor.child_mask().iter() {
        v612_7_cursor.descend_to_byte(v612_7_byte);
        {
        let v612_7_tail = v612_7_cursor.fork_read_zipper();
        let v612_7_head = Path::from_slice(&[v612_7_byte]);
        let v613_2: Space = singleton(&(v612_7_head));
        let v613_3: Space = intersect(&(*CONSTANT_2),&(v613_2));
        let v613_4: Space = if has_head(&(v613_3)) { singleton(&[]) } else { Space::new() };
        drop(v613_3);
        let v613_5: Space = subtract(&(*CONSTANT_1),&(v613_4));
        drop(v613_4);
        let v613_8: Space = if (v613_5).is_empty() { Space::new() } else {
          let v614_6: Path = concat_path(&(v612_6),&(v612_7_head));
          let mut v614_7 = Space::new();
          let mut v614_7_cursor = (v612_7_tail).read_zipper();
          for v614_7_byte in v614_7_cursor.child_mask().iter() {
            v614_7_cursor.descend_to_byte(v614_7_byte);
            {
            let v614_7_tail = v614_7_cursor.fork_read_zipper();
            let v614_7_head = Path::from_slice(&[v614_7_byte]);
            let v615_2: Space = singleton(&(v614_7_head));
            let v615_3: Space = intersect(&(*CONSTANT_2),&(v615_2));
            let v615_4: Space = if has_head(&(v615_3)) { singleton(&[]) } else { Space::new() };
            drop(v615_3);
            let v615_5: Space = subtract(&(*CONSTANT_1),&(v615_4));
            drop(v615_4);
            let v615_8: Space = if (v615_5).is_empty() { Space::new() } else {
              let v616_6: Path = concat_path(&(v614_6),&(v614_7_head));
              let v616_7: Space = routine_44(c, &(v616_6), &(*p1), &(v614_7_tail).make_space());
              compose(&(v615_5),&(v616_7))
            };
            drop(v615_5);
            let v615_9: Space = intersect(&(*CONSTANT_2),&(v615_2));
            drop(v615_2);
            let v615_10: Space = if has_head(&(v615_9)) { singleton(&[]) } else { Space::new() };
            drop(v615_9);
            let v615_12: Space = if (v615_10).is_empty() { Space::new() } else {
              let v617_6: Path = concat_path(&(v614_6),&(v614_7_head));
              let v617_11: Space = routine_45(c, &(v617_6), &(*p1), &(v614_7_tail).make_space());
              drop(v617_6);
              compose(&(v615_10),&(v617_11))
            };
            drop(v615_10);
            let v615_13: Space = unite(&(v615_8),&(v615_12));
            v614_7.join_into((v615_13).clone());
            }
            v614_7_cursor.ascend(1);
          }
          drop(v614_7_cursor);
          compose(&(v613_5),&(v614_7))
        };
        drop(v613_5);
        let v613_9: Space = intersect(&(*CONSTANT_2),&(v613_2));
        drop(v613_2);
        let v613_10: Space = if has_head(&(v613_9)) { singleton(&[]) } else { Space::new() };
        drop(v613_9);
        let v613_12: Space = if (v613_10).is_empty() { Space::new() } else {
          let v618_6: Path = concat_path(&(v612_6),&(v612_7_head));
          let mut v618_11 = Space::new();
          let mut v618_11_cursor = (v612_7_tail).read_zipper();
          for v618_11_byte in v618_11_cursor.child_mask().iter() {
            v618_11_cursor.descend_to_byte(v618_11_byte);
            {
            let v618_11_tail = v618_11_cursor.fork_read_zipper();
            let v618_11_head = Path::from_slice(&[v618_11_byte]);
            let v619_2: Space = singleton(&(v618_11_head));
            let v619_3: Space = intersect(&(*CONSTANT_2),&(v619_2));
            let v619_4: Space = if has_head(&(v619_3)) { singleton(&[]) } else { Space::new() };
            drop(v619_3);
            let v619_5: Space = subtract(&(*CONSTANT_1),&(v619_4));
            drop(v619_4);
            let v619_8: Space = if (v619_5).is_empty() { Space::new() } else {
              let v620_6: Path = concat_path(&(v618_6),&(v618_11_head));
              let v620_7: Space = routine_44(c, &(v620_6), &(*p1), &(v618_11_tail).make_space());
              compose(&(v619_5),&(v620_7))
            };
            drop(v619_5);
            let v619_9: Space = intersect(&(*CONSTANT_2),&(v619_2));
            drop(v619_2);
            let v619_10: Space = if has_head(&(v619_9)) { singleton(&[]) } else { Space::new() };
            drop(v619_9);
            let v619_12: Space = if (v619_10).is_empty() { Space::new() } else {
              let v621_6: Path = concat_path(&(v618_6),&(v618_11_head));
              let v621_11: Space = routine_19(c, &(v621_6), &(*p1), &(v618_11_tail).make_space());
              drop(v621_6);
              compose(&(v619_10),&(v621_11))
            };
            drop(v619_10);
            let v619_13: Space = unite(&(v619_8),&(v619_12));
            v618_11.join_into((v619_13).clone());
            }
            v618_11_cursor.ascend(1);
          }
          drop(v618_11_cursor);
          drop(v618_6);
          compose(&(v613_10),&(v618_11))
        };
        drop(v613_10);
        let v613_13: Space = unite(&(v613_8),&(v613_12));
        v612_7.join_into((v613_13).clone());
        }
        v612_7_cursor.ascend(1);
      }
      drop(v612_7_cursor);
      compose(&(v611_5),&(v612_7))
    };
    drop(v611_5);
    let v611_9: Space = intersect(&(*CONSTANT_2),&(v611_2));
    drop(v611_2);
    let v611_10: Space = if has_head(&(v611_9)) { singleton(&[]) } else { Space::new() };
    drop(v611_9);
    let v611_12: Space = if (v611_10).is_empty() { Space::new() } else {
      let v622_6: Path = concat_path(&(*p0),&(v610_21_head));
      let mut v622_11 = Space::new();
      let mut v622_11_cursor = (v610_21_tail).read_zipper();
      for v622_11_byte in v622_11_cursor.child_mask().iter() {
        v622_11_cursor.descend_to_byte(v622_11_byte);
        {
        let v622_11_tail = v622_11_cursor.fork_read_zipper();
        let v622_11_head = Path::from_slice(&[v622_11_byte]);
        let v623_2: Space = singleton(&(v622_11_head));
        let v623_3: Space = intersect(&(*CONSTANT_2),&(v623_2));
        let v623_4: Space = if has_head(&(v623_3)) { singleton(&[]) } else { Space::new() };
        drop(v623_3);
        let v623_5: Space = subtract(&(*CONSTANT_1),&(v623_4));
        drop(v623_4);
        let v623_8: Space = if (v623_5).is_empty() { Space::new() } else {
          let v624_6: Path = concat_path(&(v622_6),&(v622_11_head));
          let mut v624_7 = Space::new();
          let mut v624_7_cursor = (v622_11_tail).read_zipper();
          for v624_7_byte in v624_7_cursor.child_mask().iter() {
            v624_7_cursor.descend_to_byte(v624_7_byte);
            {
            let v624_7_tail = v624_7_cursor.fork_read_zipper();
            let v624_7_head = Path::from_slice(&[v624_7_byte]);
            let v625_2: Space = singleton(&(v624_7_head));
            let v625_3: Space = intersect(&(*CONSTANT_2),&(v625_2));
            let v625_4: Space = if has_head(&(v625_3)) { singleton(&[]) } else { Space::new() };
            drop(v625_3);
            let v625_5: Space = subtract(&(*CONSTANT_1),&(v625_4));
            drop(v625_4);
            let v625_8: Space = if (v625_5).is_empty() { Space::new() } else {
              let v626_6: Path = concat_path(&(v624_6),&(v624_7_head));
              let v626_7: Space = routine_44(c, &(v626_6), &(*p1), &(v624_7_tail).make_space());
              compose(&(v625_5),&(v626_7))
            };
            drop(v625_5);
            let v625_9: Space = intersect(&(*CONSTANT_2),&(v625_2));
            drop(v625_2);
            let v625_10: Space = if has_head(&(v625_9)) { singleton(&[]) } else { Space::new() };
            drop(v625_9);
            let v625_12: Space = if (v625_10).is_empty() { Space::new() } else {
              let v627_6: Path = concat_path(&(v624_6),&(v624_7_head));
              let v627_11: Space = routine_45(c, &(v627_6), &(*p1), &(v624_7_tail).make_space());
              drop(v627_6);
              compose(&(v625_10),&(v627_11))
            };
            drop(v625_10);
            let v625_13: Space = unite(&(v625_8),&(v625_12));
            v624_7.join_into((v625_13).clone());
            }
            v624_7_cursor.ascend(1);
          }
          drop(v624_7_cursor);
          compose(&(v623_5),&(v624_7))
        };
        drop(v623_5);
        let v623_9: Space = intersect(&(*CONSTANT_2),&(v623_2));
        drop(v623_2);
        let v623_10: Space = if has_head(&(v623_9)) { singleton(&[]) } else { Space::new() };
        drop(v623_9);
        let v623_11: Space = compose(&(v623_10),&(v622_11_tail));
        drop(v623_10);
        let v628_6: Path = concat_path(&(v622_6),&(v622_11_head));
        let v623_12: Space = wrap(&(v623_11),&(v628_6));
        drop(v623_11);
        let v623_13: Space = wrap(&(v623_12),&(*p1));
        drop(v623_12);
        let v623_14: Space = unite(&(v623_8),&(v623_13));
        drop(v623_13);
        v622_11.join_into((v623_14).clone());
        }
        v622_11_cursor.ascend(1);
      }
      drop(v622_11_cursor);
      drop(v622_6);
      compose(&(v611_10),&(v622_11))
    };
    drop(v611_10);
    let v611_13: Space = unite(&(v611_8),&(v611_12));
    v610_21.join_into((v611_13).clone());
    }
    v610_21_cursor.ascend(1);
  }
  drop(v610_21_cursor);
  (v610_21).clone()
}

fn routine_33(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v629_15 = Space::new();
  let mut v629_15_cursor = (*s0).read_zipper();
  for v629_15_byte in v629_15_cursor.child_mask().iter() {
    v629_15_cursor.descend_to_byte(v629_15_byte);
    {
    let v629_15_tail = v629_15_cursor.fork_read_zipper();
    let v629_15_head = Path::from_slice(&[v629_15_byte]);
    let v630_2: Space = singleton(&(v629_15_head));
    let v630_3: Space = intersect(&(*CONSTANT_2),&(v630_2));
    let v630_4: Space = if has_head(&(v630_3)) { singleton(&[]) } else { Space::new() };
    drop(v630_3);
    let v630_5: Space = subtract(&(*CONSTANT_1),&(v630_4));
    drop(v630_4);
    let v630_8: Space = if (v630_5).is_empty() { Space::new() } else {
      let v631_6: Path = concat_path(&(*p0),&(v629_15_head));
      let mut v631_7 = Space::new();
      let mut v631_7_cursor = (v629_15_tail).read_zipper();
      for v631_7_byte in v631_7_cursor.child_mask().iter() {
        v631_7_cursor.descend_to_byte(v631_7_byte);
        {
        let v631_7_tail = v631_7_cursor.fork_read_zipper();
        let v631_7_head = Path::from_slice(&[v631_7_byte]);
        let v632_2: Space = singleton(&(v631_7_head));
        let v632_3: Space = intersect(&(*CONSTANT_2),&(v632_2));
        let v632_4: Space = if has_head(&(v632_3)) { singleton(&[]) } else { Space::new() };
        drop(v632_3);
        let v632_5: Space = subtract(&(*CONSTANT_1),&(v632_4));
        drop(v632_4);
        let v632_8: Space = if (v632_5).is_empty() { Space::new() } else {
          let v633_6: Path = concat_path(&(v631_6),&(v631_7_head));
          let mut v633_7 = Space::new();
          let mut v633_7_cursor = (v631_7_tail).read_zipper();
          for v633_7_byte in v633_7_cursor.child_mask().iter() {
            v633_7_cursor.descend_to_byte(v633_7_byte);
            {
            let v633_7_tail = v633_7_cursor.fork_read_zipper();
            let v633_7_head = Path::from_slice(&[v633_7_byte]);
            let v634_2: Space = singleton(&(v633_7_head));
            let v634_3: Space = intersect(&(*CONSTANT_2),&(v634_2));
            let v634_4: Space = if has_head(&(v634_3)) { singleton(&[]) } else { Space::new() };
            drop(v634_3);
            let v634_5: Space = subtract(&(*CONSTANT_1),&(v634_4));
            drop(v634_4);
            let v634_8: Space = if (v634_5).is_empty() { Space::new() } else {
              let v635_6: Path = concat_path(&(v633_6),&(v633_7_head));
              let v635_7: Space = routine_44(c, &(v635_6), &(*p1), &(v633_7_tail).make_space());
              compose(&(v634_5),&(v635_7))
            };
            drop(v634_5);
            let v634_9: Space = intersect(&(*CONSTANT_2),&(v634_2));
            drop(v634_2);
            let v634_10: Space = if has_head(&(v634_9)) { singleton(&[]) } else { Space::new() };
            drop(v634_9);
            let v634_12: Space = if (v634_10).is_empty() { Space::new() } else {
              let v636_6: Path = concat_path(&(v633_6),&(v633_7_head));
              let v636_11: Space = routine_45(c, &(v636_6), &(*p1), &(v633_7_tail).make_space());
              drop(v636_6);
              compose(&(v634_10),&(v636_11))
            };
            drop(v634_10);
            let v634_13: Space = unite(&(v634_8),&(v634_12));
            v633_7.join_into((v634_13).clone());
            }
            v633_7_cursor.ascend(1);
          }
          drop(v633_7_cursor);
          compose(&(v632_5),&(v633_7))
        };
        drop(v632_5);
        let v632_9: Space = intersect(&(*CONSTANT_2),&(v632_2));
        drop(v632_2);
        let v632_10: Space = if has_head(&(v632_9)) { singleton(&[]) } else { Space::new() };
        drop(v632_9);
        let v632_12: Space = if (v632_10).is_empty() { Space::new() } else {
          let v637_6: Path = concat_path(&(v631_6),&(v631_7_head));
          let mut v637_11 = Space::new();
          let mut v637_11_cursor = (v631_7_tail).read_zipper();
          for v637_11_byte in v637_11_cursor.child_mask().iter() {
            v637_11_cursor.descend_to_byte(v637_11_byte);
            {
            let v637_11_tail = v637_11_cursor.fork_read_zipper();
            let v637_11_head = Path::from_slice(&[v637_11_byte]);
            let v638_2: Space = singleton(&(v637_11_head));
            let v638_3: Space = intersect(&(*CONSTANT_2),&(v638_2));
            let v638_4: Space = if has_head(&(v638_3)) { singleton(&[]) } else { Space::new() };
            drop(v638_3);
            let v638_5: Space = subtract(&(*CONSTANT_1),&(v638_4));
            drop(v638_4);
            let v638_8: Space = if (v638_5).is_empty() { Space::new() } else {
              let v639_6: Path = concat_path(&(v637_6),&(v637_11_head));
              let v639_7: Space = routine_44(c, &(v639_6), &(*p1), &(v637_11_tail).make_space());
              compose(&(v638_5),&(v639_7))
            };
            drop(v638_5);
            let v638_9: Space = intersect(&(*CONSTANT_2),&(v638_2));
            drop(v638_2);
            let v638_10: Space = if has_head(&(v638_9)) { singleton(&[]) } else { Space::new() };
            drop(v638_9);
            let v638_12: Space = if (v638_10).is_empty() { Space::new() } else {
              let v640_6: Path = concat_path(&(v637_6),&(v637_11_head));
              let v640_11: Space = routine_19(c, &(v640_6), &(*p1), &(v637_11_tail).make_space());
              drop(v640_6);
              compose(&(v638_10),&(v640_11))
            };
            drop(v638_10);
            let v638_13: Space = unite(&(v638_8),&(v638_12));
            v637_11.join_into((v638_13).clone());
            }
            v637_11_cursor.ascend(1);
          }
          drop(v637_11_cursor);
          drop(v637_6);
          compose(&(v632_10),&(v637_11))
        };
        drop(v632_10);
        let v632_13: Space = unite(&(v632_8),&(v632_12));
        v631_7.join_into((v632_13).clone());
        }
        v631_7_cursor.ascend(1);
      }
      drop(v631_7_cursor);
      compose(&(v630_5),&(v631_7))
    };
    drop(v630_5);
    let v630_9: Space = intersect(&(*CONSTANT_2),&(v630_2));
    drop(v630_2);
    let v630_10: Space = if has_head(&(v630_9)) { singleton(&[]) } else { Space::new() };
    drop(v630_9);
    let v630_11: Space = compose(&(v630_10),&(v629_15_tail));
    drop(v630_10);
    let v641_6: Path = concat_path(&(*p0),&(v629_15_head));
    let v630_12: Space = wrap(&(v630_11),&(v641_6));
    drop(v630_11);
    let v630_13: Space = wrap(&(v630_12),&(*p1));
    drop(v630_12);
    let v630_14: Space = unite(&(v630_8),&(v630_13));
    drop(v630_13);
    v629_15.join_into((v630_14).clone());
    }
    v629_15_cursor.ascend(1);
  }
  drop(v629_15_cursor);
  (v629_15).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v642_15: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v642_16: Space = unwrap(&(v642_15),&(*p0));
  drop(v642_15);
  let mut v642_20 = Space::new();
  let mut v642_20_cursor = (*s0).read_zipper();
  for v642_20_byte in v642_20_cursor.child_mask().iter() {
    v642_20_cursor.descend_to_byte(v642_20_byte);
    {
    let v642_20_tail = v642_20_cursor.fork_read_zipper();
    let v642_20_head = Path::from_slice(&[v642_20_byte]);
    let v643_2: Space = singleton(&(v642_20_head));
    let v643_3: Space = intersect(&(*CONSTANT_2),&(v643_2));
    let v643_4: Space = if has_head(&(v643_3)) { singleton(&[]) } else { Space::new() };
    drop(v643_3);
    let v643_5: Space = subtract(&(*CONSTANT_1),&(v643_4));
    drop(v643_4);
    let v643_8: Space = if (v643_5).is_empty() { Space::new() } else {
      let v644_6: Path = concat_path(&(*p0),&(v642_20_head));
      let mut v644_7 = Space::new();
      let mut v644_7_cursor = (v642_20_tail).read_zipper();
      for v644_7_byte in v644_7_cursor.child_mask().iter() {
        v644_7_cursor.descend_to_byte(v644_7_byte);
        {
        let v644_7_tail = v644_7_cursor.fork_read_zipper();
        let v644_7_head = Path::from_slice(&[v644_7_byte]);
        let v645_2: Space = singleton(&(v644_7_head));
        let v645_3: Space = intersect(&(*CONSTANT_2),&(v645_2));
        let v645_4: Space = if has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
        drop(v645_3);
        let v645_5: Space = subtract(&(*CONSTANT_1),&(v645_4));
        drop(v645_4);
        let mut v645_6 = Space::new();
        let mut v645_6_cursor = (v644_7_tail).read_zipper();
        for v645_6_byte in v645_6_cursor.child_mask().iter() {
          v645_6_cursor.descend_to_byte(v645_6_byte);
          {
          let v645_6_tail = v645_6_cursor.fork_read_zipper();
          let v645_6_head = Path::from_slice(&[v645_6_byte]);
          let v646_2: Space = Space::new();
          v645_6.join_into((v646_2).clone());
          }
          v645_6_cursor.ascend(1);
        }
        drop(v645_6_cursor);
        let v645_7: Space = compose(&(v645_5),&(v645_6));
        drop(v645_5);
        drop(v645_6);
        let v645_8: Space = intersect(&(*CONSTANT_2),&(v645_2));
        drop(v645_2);
        let v645_9: Space = if has_head(&(v645_8)) { singleton(&[]) } else { Space::new() };
        drop(v645_8);
        let v645_12: Space = if (v645_9).is_empty() { Space::new() } else {
          let v647_10: Path = concat_path(&(v644_6),&(v644_7_head));
          let mut v647_11 = Space::new();
          let mut v647_11_cursor = (v644_7_tail).read_zipper();
          for v647_11_byte in v647_11_cursor.child_mask().iter() {
            v647_11_cursor.descend_to_byte(v647_11_byte);
            {
            let v647_11_tail = v647_11_cursor.fork_read_zipper();
            let v647_11_head = Path::from_slice(&[v647_11_byte]);
            let v648_2: Space = singleton(&(v647_11_head));
            let v648_3: Space = intersect(&(*CONSTANT_2),&(v648_2));
            drop(v648_2);
            let v648_4: Space = if has_head(&(v648_3)) { singleton(&[]) } else { Space::new() };
            drop(v648_3);
            let v648_7: Space = if (v648_4).is_empty() { Space::new() } else {
              let v649_5: Path = concat_path(&(v647_10),&(v647_11_head));
              let v649_6: Space = routine_10(c, &(v649_5), &(*p1), &(v647_11_tail).make_space(), &(*s1));
              drop(v649_5);
              compose(&(v648_4),&(v649_6))
            };
            drop(v648_4);
            v647_11.join_into((v648_7).clone());
            }
            v647_11_cursor.ascend(1);
          }
          drop(v647_11_cursor);
          drop(v647_10);
          compose(&(v645_9),&(v647_11))
        };
        drop(v645_9);
        let v645_13: Space = unite(&(v645_7),&(v645_12));
        drop(v645_7);
        v644_7.join_into((v645_13).clone());
        }
        v644_7_cursor.ascend(1);
      }
      drop(v644_7_cursor);
      drop(v644_6);
      compose(&(v643_5),&(v644_7))
    };
    drop(v643_5);
    let v643_9: Space = intersect(&(*CONSTANT_2),&(v643_2));
    drop(v643_2);
    let v643_10: Space = if has_head(&(v643_9)) { singleton(&[]) } else { Space::new() };
    drop(v643_9);
    let v643_13: Space = if (v643_10).is_empty() { Space::new() } else {
      let v650_11: Space = unwrap(&(v642_16),&(v642_20_head));
      let mut v650_12 = Space::new();
      let mut v650_12_cursor = (v642_20_tail).read_zipper();
      for v650_12_byte in v650_12_cursor.child_mask().iter() {
        v650_12_cursor.descend_to_byte(v650_12_byte);
        {
        let v650_12_tail = v650_12_cursor.fork_read_zipper();
        let v650_12_head = Path::from_slice(&[v650_12_byte]);
        let v651_2: Space = singleton(&(v650_12_head));
        let v651_3: Space = intersect(&(*CONSTANT_2),&(v651_2));
        let v651_4: Space = if has_head(&(v651_3)) { singleton(&[]) } else { Space::new() };
        drop(v651_3);
        let v651_5: Space = subtract(&(*CONSTANT_1),&(v651_4));
        drop(v651_4);
        let mut v651_6 = Space::new();
        let mut v651_6_cursor = (v650_12_tail).read_zipper();
        for v651_6_byte in v651_6_cursor.child_mask().iter() {
          v651_6_cursor.descend_to_byte(v651_6_byte);
          {
          let v651_6_tail = v651_6_cursor.fork_read_zipper();
          let v651_6_head = Path::from_slice(&[v651_6_byte]);
          let v652_2: Space = Space::new();
          v651_6.join_into((v652_2).clone());
          }
          v651_6_cursor.ascend(1);
        }
        drop(v651_6_cursor);
        let v651_7: Space = compose(&(v651_5),&(v651_6));
        drop(v651_5);
        drop(v651_6);
        let v651_8: Space = intersect(&(*CONSTANT_2),&(v651_2));
        drop(v651_2);
        let v651_9: Space = if has_head(&(v651_8)) { singleton(&[]) } else { Space::new() };
        drop(v651_8);
        let v651_12: Space = if (v651_9).is_empty() { Space::new() } else {
          let v653_10: Space = unwrap(&(v650_11),&(v650_12_head));
          let mut v653_11 = Space::new();
          let mut v653_11_cursor = (v653_10).read_zipper();
          for v653_11_byte in v653_11_cursor.child_mask().iter() {
            v653_11_cursor.descend_to_byte(v653_11_byte);
            {
            let v653_11_tail = v653_11_cursor.fork_read_zipper();
            let v653_11_head = Path::from_slice(&[v653_11_byte]);
            let v654_2: Space = singleton(&(v653_11_head));
            let v654_3: Space = intersect(&(*CONSTANT_2),&(v654_2));
            let v654_4: Space = if has_head(&(v654_3)) { singleton(&[]) } else { Space::new() };
            drop(v654_3);
            let v654_5: Space = subtract(&(*CONSTANT_1),&(v654_4));
            drop(v654_4);
            let v654_7: Space = if (v654_5).is_empty() { Space::new() } else {
              let v655_6: Space = routine_13(c, &(v653_11_head), &(*p1), &(v653_11_tail).make_space());
              compose(&(v654_5),&(v655_6))
            };
            drop(v654_5);
            let v654_8: Space = intersect(&(*CONSTANT_2),&(v654_2));
            drop(v654_2);
            let v654_9: Space = if has_head(&(v654_8)) { singleton(&[]) } else { Space::new() };
            drop(v654_8);
            let v654_11: Space = if (v654_9).is_empty() { Space::new() } else {
              let v656_10: Space = routine_14(c, &(v653_11_head), &(*p1), &(v653_11_tail).make_space());
              compose(&(v654_9),&(v656_10))
            };
            drop(v654_9);
            let v654_12: Space = unite(&(v654_7),&(v654_11));
            v653_11.join_into((v654_12).clone());
            }
            v653_11_cursor.ascend(1);
          }
          drop(v653_11_cursor);
          drop(v653_10);
          compose(&(v651_9),&(v653_11))
        };
        drop(v651_9);
        let v651_13: Space = unite(&(v651_7),&(v651_12));
        drop(v651_7);
        v650_12.join_into((v651_13).clone());
        }
        v650_12_cursor.ascend(1);
      }
      drop(v650_12_cursor);
      drop(v650_11);
      compose(&(v643_10),&(v650_12))
    };
    drop(v643_10);
    let v643_14: Space = unite(&(v643_8),&(v643_13));
    v642_20.join_into((v643_14).clone());
    }
    v642_20_cursor.ascend(1);
  }
  drop(v642_20_cursor);
  drop(v642_16);
  (v642_20).clone()
}

fn routine_35(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v657_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v657_9: Space = unwrap(&(v657_8),&(*p0));
  drop(v657_8);
  let mut v657_23 = Space::new();
  let mut v657_23_cursor = (*s0).read_zipper();
  for v657_23_byte in v657_23_cursor.child_mask().iter() {
    v657_23_cursor.descend_to_byte(v657_23_byte);
    {
    let v657_23_tail = v657_23_cursor.fork_read_zipper();
    let v657_23_head = Path::from_slice(&[v657_23_byte]);
    let v658_2: Space = singleton(&(v657_23_head));
    let v658_3: Space = intersect(&(*CONSTANT_2),&(v658_2));
    let v658_4: Space = if has_head(&(v658_3)) { singleton(&[]) } else { Space::new() };
    drop(v658_3);
    let v658_5: Space = subtract(&(*CONSTANT_1),&(v658_4));
    drop(v658_4);
    let v658_8: Space = if (v658_5).is_empty() { Space::new() } else {
      let v659_6: Path = concat_path(&(*p0),&(v657_23_head));
      let mut v659_7 = Space::new();
      let mut v659_7_cursor = (v657_23_tail).read_zipper();
      for v659_7_byte in v659_7_cursor.child_mask().iter() {
        v659_7_cursor.descend_to_byte(v659_7_byte);
        {
        let v659_7_tail = v659_7_cursor.fork_read_zipper();
        let v659_7_head = Path::from_slice(&[v659_7_byte]);
        let v660_2: Space = singleton(&(v659_7_head));
        let v660_3: Space = intersect(&(*CONSTANT_2),&(v660_2));
        let v660_4: Space = if has_head(&(v660_3)) { singleton(&[]) } else { Space::new() };
        drop(v660_3);
        let v660_5: Space = subtract(&(*CONSTANT_1),&(v660_4));
        drop(v660_4);
        let mut v660_6 = Space::new();
        let mut v660_6_cursor = (v659_7_tail).read_zipper();
        for v660_6_byte in v660_6_cursor.child_mask().iter() {
          v660_6_cursor.descend_to_byte(v660_6_byte);
          {
          let v660_6_tail = v660_6_cursor.fork_read_zipper();
          let v660_6_head = Path::from_slice(&[v660_6_byte]);
          let v661_2: Space = Space::new();
          v660_6.join_into((v661_2).clone());
          }
          v660_6_cursor.ascend(1);
        }
        drop(v660_6_cursor);
        let v660_7: Space = compose(&(v660_5),&(v660_6));
        drop(v660_5);
        drop(v660_6);
        let v660_8: Space = intersect(&(*CONSTANT_2),&(v660_2));
        drop(v660_2);
        let v660_9: Space = if has_head(&(v660_8)) { singleton(&[]) } else { Space::new() };
        drop(v660_8);
        let v660_12: Space = if (v660_9).is_empty() { Space::new() } else {
          let v662_10: Path = concat_path(&(v659_6),&(v659_7_head));
          let mut v662_11 = Space::new();
          let mut v662_11_cursor = (v659_7_tail).read_zipper();
          for v662_11_byte in v662_11_cursor.child_mask().iter() {
            v662_11_cursor.descend_to_byte(v662_11_byte);
            {
            let v662_11_tail = v662_11_cursor.fork_read_zipper();
            let v662_11_head = Path::from_slice(&[v662_11_byte]);
            let v663_2: Space = singleton(&(v662_11_head));
            let v663_3: Space = intersect(&(*CONSTANT_2),&(v663_2));
            drop(v663_2);
            let v663_4: Space = if has_head(&(v663_3)) { singleton(&[]) } else { Space::new() };
            drop(v663_3);
            let v663_7: Space = if (v663_4).is_empty() { Space::new() } else {
              let v664_5: Path = concat_path(&(v662_10),&(v662_11_head));
              let v664_6: Space = routine_10(c, &(v664_5), &(*p1), &(v662_11_tail).make_space(), &(*s1));
              drop(v664_5);
              compose(&(v663_4),&(v664_6))
            };
            drop(v663_4);
            v662_11.join_into((v663_7).clone());
            }
            v662_11_cursor.ascend(1);
          }
          drop(v662_11_cursor);
          drop(v662_10);
          compose(&(v660_9),&(v662_11))
        };
        drop(v660_9);
        let v660_13: Space = unite(&(v660_7),&(v660_12));
        drop(v660_7);
        v659_7.join_into((v660_13).clone());
        }
        v659_7_cursor.ascend(1);
      }
      drop(v659_7_cursor);
      drop(v659_6);
      compose(&(v658_5),&(v659_7))
    };
    drop(v658_5);
    let v658_9: Space = intersect(&(*CONSTANT_2),&(v658_2));
    drop(v658_2);
    let v658_10: Space = if has_head(&(v658_9)) { singleton(&[]) } else { Space::new() };
    drop(v658_9);
    let v658_13: Space = if (v658_10).is_empty() { Space::new() } else {
      let v665_11: Space = unwrap(&(v657_9),&(v657_23_head));
      let mut v665_12 = Space::new();
      let mut v665_12_cursor = (v665_11).read_zipper();
      for v665_12_byte in v665_12_cursor.child_mask().iter() {
        v665_12_cursor.descend_to_byte(v665_12_byte);
        {
        let v665_12_tail = v665_12_cursor.fork_read_zipper();
        let v665_12_head = Path::from_slice(&[v665_12_byte]);
        let v666_2: Space = singleton(&(v665_12_head));
        let v666_3: Space = intersect(&(*CONSTANT_2),&(v666_2));
        let v666_4: Space = if has_head(&(v666_3)) { singleton(&[]) } else { Space::new() };
        drop(v666_3);
        let v666_5: Space = subtract(&(*CONSTANT_1),&(v666_4));
        drop(v666_4);
        let v666_7: Space = if (v666_5).is_empty() { Space::new() } else {
          let mut v667_6 = Space::new();
          let mut v667_6_cursor = (v665_12_tail).read_zipper();
          for v667_6_byte in v667_6_cursor.child_mask().iter() {
            v667_6_cursor.descend_to_byte(v667_6_byte);
            {
            let v667_6_tail = v667_6_cursor.fork_read_zipper();
            let v667_6_head = Path::from_slice(&[v667_6_byte]);
            let v668_2: Space = singleton(&(v667_6_head));
            let v668_3: Space = intersect(&(*CONSTANT_2),&(v668_2));
            let v668_4: Space = if has_head(&(v668_3)) { singleton(&[]) } else { Space::new() };
            drop(v668_3);
            let v668_5: Space = subtract(&(*CONSTANT_1),&(v668_4));
            drop(v668_4);
            let v668_8: Space = if (v668_5).is_empty() { Space::new() } else {
              let v669_6: Path = concat_path(&(v665_12_head),&(v667_6_head));
              let v669_7: Space = routine_17(c, &(v669_6), &(*p1), &(v667_6_tail).make_space());
              compose(&(v668_5),&(v669_7))
            };
            drop(v668_5);
            let v668_9: Space = intersect(&(*CONSTANT_2),&(v668_2));
            drop(v668_2);
            let v668_10: Space = if has_head(&(v668_9)) { singleton(&[]) } else { Space::new() };
            drop(v668_9);
            let v668_12: Space = if (v668_10).is_empty() { Space::new() } else {
              let v670_6: Path = concat_path(&(v665_12_head),&(v667_6_head));
              let v670_11: Space = routine_18(c, &(v670_6), &(*p1), &(v667_6_tail).make_space());
              drop(v670_6);
              compose(&(v668_10),&(v670_11))
            };
            drop(v668_10);
            let v668_13: Space = unite(&(v668_8),&(v668_12));
            v667_6.join_into((v668_13).clone());
            }
            v667_6_cursor.ascend(1);
          }
          drop(v667_6_cursor);
          compose(&(v666_5),&(v667_6))
        };
        drop(v666_5);
        let v666_8: Space = intersect(&(*CONSTANT_2),&(v666_2));
        drop(v666_2);
        let v666_9: Space = if has_head(&(v666_8)) { singleton(&[]) } else { Space::new() };
        drop(v666_8);
        let v666_11: Space = if (v666_9).is_empty() { Space::new() } else {
          let mut v671_10 = Space::new();
          let mut v671_10_cursor = (v665_12_tail).read_zipper();
          for v671_10_byte in v671_10_cursor.child_mask().iter() {
            v671_10_cursor.descend_to_byte(v671_10_byte);
            {
            let v671_10_tail = v671_10_cursor.fork_read_zipper();
            let v671_10_head = Path::from_slice(&[v671_10_byte]);
            let v672_2: Space = singleton(&(v671_10_head));
            let v672_3: Space = intersect(&(*CONSTANT_2),&(v672_2));
            let v672_4: Space = if has_head(&(v672_3)) { singleton(&[]) } else { Space::new() };
            drop(v672_3);
            let v672_5: Space = subtract(&(*CONSTANT_1),&(v672_4));
            drop(v672_4);
            let v672_8: Space = if (v672_5).is_empty() { Space::new() } else {
              let v673_6: Path = concat_path(&(v665_12_head),&(v671_10_head));
              let v673_7: Space = routine_17(c, &(v673_6), &(*p1), &(v671_10_tail).make_space());
              compose(&(v672_5),&(v673_7))
            };
            drop(v672_5);
            let v672_9: Space = intersect(&(*CONSTANT_2),&(v672_2));
            drop(v672_2);
            let v672_10: Space = if has_head(&(v672_9)) { singleton(&[]) } else { Space::new() };
            drop(v672_9);
            let v672_12: Space = if (v672_10).is_empty() { Space::new() } else {
              let v674_6: Path = concat_path(&(v665_12_head),&(v671_10_head));
              let v674_11: Space = routine_19(c, &(v674_6), &(*p1), &(v671_10_tail).make_space());
              drop(v674_6);
              compose(&(v672_10),&(v674_11))
            };
            drop(v672_10);
            let v672_13: Space = unite(&(v672_8),&(v672_12));
            v671_10.join_into((v672_13).clone());
            }
            v671_10_cursor.ascend(1);
          }
          drop(v671_10_cursor);
          compose(&(v666_9),&(v671_10))
        };
        drop(v666_9);
        let v666_12: Space = unite(&(v666_7),&(v666_11));
        v665_12.join_into((v666_12).clone());
        }
        v665_12_cursor.ascend(1);
      }
      drop(v665_12_cursor);
      drop(v665_11);
      compose(&(v658_10),&(v665_12))
    };
    drop(v658_10);
    let v658_14: Space = unite(&(v658_8),&(v658_13));
    v657_23.join_into((v658_14).clone());
    }
    v657_23_cursor.ascend(1);
  }
  drop(v657_23_cursor);
  drop(v657_9);
  (v657_23).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v675_21 = Space::new();
  let mut v675_21_cursor = (*s0).read_zipper();
  for v675_21_byte in v675_21_cursor.child_mask().iter() {
    v675_21_cursor.descend_to_byte(v675_21_byte);
    {
    let v675_21_tail = v675_21_cursor.fork_read_zipper();
    let v675_21_head = Path::from_slice(&[v675_21_byte]);
    let v676_2: Space = singleton(&(v675_21_head));
    let v676_3: Space = intersect(&(*CONSTANT_2),&(v676_2));
    let v676_4: Space = if has_head(&(v676_3)) { singleton(&[]) } else { Space::new() };
    drop(v676_3);
    let v676_5: Space = subtract(&(*CONSTANT_1),&(v676_4));
    drop(v676_4);
    let v676_8: Space = if (v676_5).is_empty() { Space::new() } else {
      let v677_6: Path = concat_path(&(*p0),&(v675_21_head));
      let mut v677_7 = Space::new();
      let mut v677_7_cursor = (v675_21_tail).read_zipper();
      for v677_7_byte in v677_7_cursor.child_mask().iter() {
        v677_7_cursor.descend_to_byte(v677_7_byte);
        {
        let v677_7_tail = v677_7_cursor.fork_read_zipper();
        let v677_7_head = Path::from_slice(&[v677_7_byte]);
        let v678_2: Space = singleton(&(v677_7_head));
        let v678_3: Space = intersect(&(*CONSTANT_2),&(v678_2));
        let v678_4: Space = if has_head(&(v678_3)) { singleton(&[]) } else { Space::new() };
        drop(v678_3);
        let v678_5: Space = subtract(&(*CONSTANT_1),&(v678_4));
        drop(v678_4);
        let v678_8: Space = if (v678_5).is_empty() { Space::new() } else {
          let v679_6: Path = concat_path(&(v677_6),&(v677_7_head));
          let mut v679_7 = Space::new();
          let mut v679_7_cursor = (v677_7_tail).read_zipper();
          for v679_7_byte in v679_7_cursor.child_mask().iter() {
            v679_7_cursor.descend_to_byte(v679_7_byte);
            {
            let v679_7_tail = v679_7_cursor.fork_read_zipper();
            let v679_7_head = Path::from_slice(&[v679_7_byte]);
            let v680_2: Space = singleton(&(v679_7_head));
            let v680_3: Space = intersect(&(*CONSTANT_2),&(v680_2));
            let v680_4: Space = if has_head(&(v680_3)) { singleton(&[]) } else { Space::new() };
            drop(v680_3);
            let v680_5: Space = subtract(&(*CONSTANT_1),&(v680_4));
            drop(v680_4);
            let v680_8: Space = if (v680_5).is_empty() { Space::new() } else {
              let v681_6: Path = concat_path(&(v679_6),&(v679_7_head));
              let v681_7: Space = routine_46(c, &(v681_6), &(*p1), &(v679_7_tail).make_space());
              compose(&(v680_5),&(v681_7))
            };
            drop(v680_5);
            let v680_9: Space = intersect(&(*CONSTANT_2),&(v680_2));
            drop(v680_2);
            let v680_10: Space = if has_head(&(v680_9)) { singleton(&[]) } else { Space::new() };
            drop(v680_9);
            let v680_12: Space = if (v680_10).is_empty() { Space::new() } else {
              let v682_6: Path = concat_path(&(v679_6),&(v679_7_head));
              let v682_11: Space = routine_47(c, &(v682_6), &(*p1), &(v679_7_tail).make_space());
              drop(v682_6);
              compose(&(v680_10),&(v682_11))
            };
            drop(v680_10);
            let v680_13: Space = unite(&(v680_8),&(v680_12));
            v679_7.join_into((v680_13).clone());
            }
            v679_7_cursor.ascend(1);
          }
          drop(v679_7_cursor);
          compose(&(v678_5),&(v679_7))
        };
        drop(v678_5);
        let v678_9: Space = intersect(&(*CONSTANT_2),&(v678_2));
        drop(v678_2);
        let v678_10: Space = if has_head(&(v678_9)) { singleton(&[]) } else { Space::new() };
        drop(v678_9);
        let v678_12: Space = if (v678_10).is_empty() { Space::new() } else {
          let v683_6: Path = concat_path(&(v677_6),&(v677_7_head));
          let mut v683_11 = Space::new();
          let mut v683_11_cursor = (v677_7_tail).read_zipper();
          for v683_11_byte in v683_11_cursor.child_mask().iter() {
            v683_11_cursor.descend_to_byte(v683_11_byte);
            {
            let v683_11_tail = v683_11_cursor.fork_read_zipper();
            let v683_11_head = Path::from_slice(&[v683_11_byte]);
            let v684_2: Space = singleton(&(v683_11_head));
            let v684_3: Space = intersect(&(*CONSTANT_2),&(v684_2));
            let v684_4: Space = if has_head(&(v684_3)) { singleton(&[]) } else { Space::new() };
            drop(v684_3);
            let v684_5: Space = subtract(&(*CONSTANT_1),&(v684_4));
            drop(v684_4);
            let v684_8: Space = if (v684_5).is_empty() { Space::new() } else {
              let v685_6: Path = concat_path(&(v683_6),&(v683_11_head));
              let v685_7: Space = routine_46(c, &(v685_6), &(*p1), &(v683_11_tail).make_space());
              compose(&(v684_5),&(v685_7))
            };
            drop(v684_5);
            let v684_9: Space = intersect(&(*CONSTANT_2),&(v684_2));
            drop(v684_2);
            let v684_10: Space = if has_head(&(v684_9)) { singleton(&[]) } else { Space::new() };
            drop(v684_9);
            let v684_12: Space = if (v684_10).is_empty() { Space::new() } else {
              let v686_6: Path = concat_path(&(v683_6),&(v683_11_head));
              let v686_11: Space = routine_19(c, &(v686_6), &(*p1), &(v683_11_tail).make_space());
              drop(v686_6);
              compose(&(v684_10),&(v686_11))
            };
            drop(v684_10);
            let v684_13: Space = unite(&(v684_8),&(v684_12));
            v683_11.join_into((v684_13).clone());
            }
            v683_11_cursor.ascend(1);
          }
          drop(v683_11_cursor);
          drop(v683_6);
          compose(&(v678_10),&(v683_11))
        };
        drop(v678_10);
        let v678_13: Space = unite(&(v678_8),&(v678_12));
        v677_7.join_into((v678_13).clone());
        }
        v677_7_cursor.ascend(1);
      }
      drop(v677_7_cursor);
      compose(&(v676_5),&(v677_7))
    };
    drop(v676_5);
    let v676_9: Space = intersect(&(*CONSTANT_2),&(v676_2));
    drop(v676_2);
    let v676_10: Space = if has_head(&(v676_9)) { singleton(&[]) } else { Space::new() };
    drop(v676_9);
    let v676_12: Space = if (v676_10).is_empty() { Space::new() } else {
      let v687_6: Path = concat_path(&(*p0),&(v675_21_head));
      let mut v687_11 = Space::new();
      let mut v687_11_cursor = (v675_21_tail).read_zipper();
      for v687_11_byte in v687_11_cursor.child_mask().iter() {
        v687_11_cursor.descend_to_byte(v687_11_byte);
        {
        let v687_11_tail = v687_11_cursor.fork_read_zipper();
        let v687_11_head = Path::from_slice(&[v687_11_byte]);
        let v688_2: Space = singleton(&(v687_11_head));
        let v688_3: Space = intersect(&(*CONSTANT_2),&(v688_2));
        let v688_4: Space = if has_head(&(v688_3)) { singleton(&[]) } else { Space::new() };
        drop(v688_3);
        let v688_5: Space = subtract(&(*CONSTANT_1),&(v688_4));
        drop(v688_4);
        let v688_8: Space = if (v688_5).is_empty() { Space::new() } else {
          let v689_6: Path = concat_path(&(v687_6),&(v687_11_head));
          let mut v689_7 = Space::new();
          let mut v689_7_cursor = (v687_11_tail).read_zipper();
          for v689_7_byte in v689_7_cursor.child_mask().iter() {
            v689_7_cursor.descend_to_byte(v689_7_byte);
            {
            let v689_7_tail = v689_7_cursor.fork_read_zipper();
            let v689_7_head = Path::from_slice(&[v689_7_byte]);
            let v690_2: Space = singleton(&(v689_7_head));
            let v690_3: Space = intersect(&(*CONSTANT_2),&(v690_2));
            let v690_4: Space = if has_head(&(v690_3)) { singleton(&[]) } else { Space::new() };
            drop(v690_3);
            let v690_5: Space = subtract(&(*CONSTANT_1),&(v690_4));
            drop(v690_4);
            let v690_8: Space = if (v690_5).is_empty() { Space::new() } else {
              let v691_6: Path = concat_path(&(v689_6),&(v689_7_head));
              let v691_7: Space = routine_46(c, &(v691_6), &(*p1), &(v689_7_tail).make_space());
              compose(&(v690_5),&(v691_7))
            };
            drop(v690_5);
            let v690_9: Space = intersect(&(*CONSTANT_2),&(v690_2));
            drop(v690_2);
            let v690_10: Space = if has_head(&(v690_9)) { singleton(&[]) } else { Space::new() };
            drop(v690_9);
            let v690_12: Space = if (v690_10).is_empty() { Space::new() } else {
              let v692_6: Path = concat_path(&(v689_6),&(v689_7_head));
              let v692_11: Space = routine_47(c, &(v692_6), &(*p1), &(v689_7_tail).make_space());
              drop(v692_6);
              compose(&(v690_10),&(v692_11))
            };
            drop(v690_10);
            let v690_13: Space = unite(&(v690_8),&(v690_12));
            v689_7.join_into((v690_13).clone());
            }
            v689_7_cursor.ascend(1);
          }
          drop(v689_7_cursor);
          compose(&(v688_5),&(v689_7))
        };
        drop(v688_5);
        let v688_9: Space = intersect(&(*CONSTANT_2),&(v688_2));
        drop(v688_2);
        let v688_10: Space = if has_head(&(v688_9)) { singleton(&[]) } else { Space::new() };
        drop(v688_9);
        let v688_11: Space = compose(&(v688_10),&(v687_11_tail));
        drop(v688_10);
        let v693_6: Path = concat_path(&(v687_6),&(v687_11_head));
        let v688_12: Space = wrap(&(v688_11),&(v693_6));
        drop(v688_11);
        let v688_13: Space = wrap(&(v688_12),&(*p1));
        drop(v688_12);
        let v688_14: Space = unite(&(v688_8),&(v688_13));
        drop(v688_13);
        v687_11.join_into((v688_14).clone());
        }
        v687_11_cursor.ascend(1);
      }
      drop(v687_11_cursor);
      drop(v687_6);
      compose(&(v676_10),&(v687_11))
    };
    drop(v676_10);
    let v676_13: Space = unite(&(v676_8),&(v676_12));
    v675_21.join_into((v676_13).clone());
    }
    v675_21_cursor.ascend(1);
  }
  drop(v675_21_cursor);
  (v675_21).clone()
}

fn routine_37(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v694_15 = Space::new();
  let mut v694_15_cursor = (*s0).read_zipper();
  for v694_15_byte in v694_15_cursor.child_mask().iter() {
    v694_15_cursor.descend_to_byte(v694_15_byte);
    {
    let v694_15_tail = v694_15_cursor.fork_read_zipper();
    let v694_15_head = Path::from_slice(&[v694_15_byte]);
    let v695_2: Space = singleton(&(v694_15_head));
    let v695_3: Space = intersect(&(*CONSTANT_2),&(v695_2));
    let v695_4: Space = if has_head(&(v695_3)) { singleton(&[]) } else { Space::new() };
    drop(v695_3);
    let v695_5: Space = subtract(&(*CONSTANT_1),&(v695_4));
    drop(v695_4);
    let v695_8: Space = if (v695_5).is_empty() { Space::new() } else {
      let v696_6: Path = concat_path(&(*p0),&(v694_15_head));
      let mut v696_7 = Space::new();
      let mut v696_7_cursor = (v694_15_tail).read_zipper();
      for v696_7_byte in v696_7_cursor.child_mask().iter() {
        v696_7_cursor.descend_to_byte(v696_7_byte);
        {
        let v696_7_tail = v696_7_cursor.fork_read_zipper();
        let v696_7_head = Path::from_slice(&[v696_7_byte]);
        let v697_2: Space = singleton(&(v696_7_head));
        let v697_3: Space = intersect(&(*CONSTANT_2),&(v697_2));
        let v697_4: Space = if has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
        drop(v697_3);
        let v697_5: Space = subtract(&(*CONSTANT_1),&(v697_4));
        drop(v697_4);
        let v697_8: Space = if (v697_5).is_empty() { Space::new() } else {
          let v698_6: Path = concat_path(&(v696_6),&(v696_7_head));
          let mut v698_7 = Space::new();
          let mut v698_7_cursor = (v696_7_tail).read_zipper();
          for v698_7_byte in v698_7_cursor.child_mask().iter() {
            v698_7_cursor.descend_to_byte(v698_7_byte);
            {
            let v698_7_tail = v698_7_cursor.fork_read_zipper();
            let v698_7_head = Path::from_slice(&[v698_7_byte]);
            let v699_2: Space = singleton(&(v698_7_head));
            let v699_3: Space = intersect(&(*CONSTANT_2),&(v699_2));
            let v699_4: Space = if has_head(&(v699_3)) { singleton(&[]) } else { Space::new() };
            drop(v699_3);
            let v699_5: Space = subtract(&(*CONSTANT_1),&(v699_4));
            drop(v699_4);
            let v699_8: Space = if (v699_5).is_empty() { Space::new() } else {
              let v700_6: Path = concat_path(&(v698_6),&(v698_7_head));
              let v700_7: Space = routine_46(c, &(v700_6), &(*p1), &(v698_7_tail).make_space());
              compose(&(v699_5),&(v700_7))
            };
            drop(v699_5);
            let v699_9: Space = intersect(&(*CONSTANT_2),&(v699_2));
            drop(v699_2);
            let v699_10: Space = if has_head(&(v699_9)) { singleton(&[]) } else { Space::new() };
            drop(v699_9);
            let v699_12: Space = if (v699_10).is_empty() { Space::new() } else {
              let v701_6: Path = concat_path(&(v698_6),&(v698_7_head));
              let v701_11: Space = routine_47(c, &(v701_6), &(*p1), &(v698_7_tail).make_space());
              drop(v701_6);
              compose(&(v699_10),&(v701_11))
            };
            drop(v699_10);
            let v699_13: Space = unite(&(v699_8),&(v699_12));
            v698_7.join_into((v699_13).clone());
            }
            v698_7_cursor.ascend(1);
          }
          drop(v698_7_cursor);
          compose(&(v697_5),&(v698_7))
        };
        drop(v697_5);
        let v697_9: Space = intersect(&(*CONSTANT_2),&(v697_2));
        drop(v697_2);
        let v697_10: Space = if has_head(&(v697_9)) { singleton(&[]) } else { Space::new() };
        drop(v697_9);
        let v697_12: Space = if (v697_10).is_empty() { Space::new() } else {
          let v702_6: Path = concat_path(&(v696_6),&(v696_7_head));
          let mut v702_11 = Space::new();
          let mut v702_11_cursor = (v696_7_tail).read_zipper();
          for v702_11_byte in v702_11_cursor.child_mask().iter() {
            v702_11_cursor.descend_to_byte(v702_11_byte);
            {
            let v702_11_tail = v702_11_cursor.fork_read_zipper();
            let v702_11_head = Path::from_slice(&[v702_11_byte]);
            let v703_2: Space = singleton(&(v702_11_head));
            let v703_3: Space = intersect(&(*CONSTANT_2),&(v703_2));
            let v703_4: Space = if has_head(&(v703_3)) { singleton(&[]) } else { Space::new() };
            drop(v703_3);
            let v703_5: Space = subtract(&(*CONSTANT_1),&(v703_4));
            drop(v703_4);
            let v703_8: Space = if (v703_5).is_empty() { Space::new() } else {
              let v704_6: Path = concat_path(&(v702_6),&(v702_11_head));
              let v704_7: Space = routine_46(c, &(v704_6), &(*p1), &(v702_11_tail).make_space());
              compose(&(v703_5),&(v704_7))
            };
            drop(v703_5);
            let v703_9: Space = intersect(&(*CONSTANT_2),&(v703_2));
            drop(v703_2);
            let v703_10: Space = if has_head(&(v703_9)) { singleton(&[]) } else { Space::new() };
            drop(v703_9);
            let v703_12: Space = if (v703_10).is_empty() { Space::new() } else {
              let v705_6: Path = concat_path(&(v702_6),&(v702_11_head));
              let v705_11: Space = routine_19(c, &(v705_6), &(*p1), &(v702_11_tail).make_space());
              drop(v705_6);
              compose(&(v703_10),&(v705_11))
            };
            drop(v703_10);
            let v703_13: Space = unite(&(v703_8),&(v703_12));
            v702_11.join_into((v703_13).clone());
            }
            v702_11_cursor.ascend(1);
          }
          drop(v702_11_cursor);
          drop(v702_6);
          compose(&(v697_10),&(v702_11))
        };
        drop(v697_10);
        let v697_13: Space = unite(&(v697_8),&(v697_12));
        v696_7.join_into((v697_13).clone());
        }
        v696_7_cursor.ascend(1);
      }
      drop(v696_7_cursor);
      compose(&(v695_5),&(v696_7))
    };
    drop(v695_5);
    let v695_9: Space = intersect(&(*CONSTANT_2),&(v695_2));
    drop(v695_2);
    let v695_10: Space = if has_head(&(v695_9)) { singleton(&[]) } else { Space::new() };
    drop(v695_9);
    let v695_11: Space = compose(&(v695_10),&(v694_15_tail));
    drop(v695_10);
    let v706_6: Path = concat_path(&(*p0),&(v694_15_head));
    let v695_12: Space = wrap(&(v695_11),&(v706_6));
    drop(v695_11);
    let v695_13: Space = wrap(&(v695_12),&(*p1));
    drop(v695_12);
    let v695_14: Space = unite(&(v695_8),&(v695_13));
    drop(v695_13);
    v694_15.join_into((v695_14).clone());
    }
    v694_15_cursor.ascend(1);
  }
  drop(v694_15_cursor);
  (v694_15).clone()
}

fn routine_38(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v707_9: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v707_10: Space = unwrap(&(v707_9),&(*p0));
  drop(v707_9);
  let mut v707_14 = Space::new();
  let mut v707_14_cursor = (*s0).read_zipper();
  for v707_14_byte in v707_14_cursor.child_mask().iter() {
    v707_14_cursor.descend_to_byte(v707_14_byte);
    {
    let v707_14_tail = v707_14_cursor.fork_read_zipper();
    let v707_14_head = Path::from_slice(&[v707_14_byte]);
    let v708_2: Space = singleton(&(v707_14_head));
    let v708_3: Space = intersect(&(*CONSTANT_2),&(v708_2));
    let v708_4: Space = if has_head(&(v708_3)) { singleton(&[]) } else { Space::new() };
    drop(v708_3);
    let v708_5: Space = subtract(&(*CONSTANT_1),&(v708_4));
    drop(v708_4);
    let mut v708_6 = Space::new();
    let mut v708_6_cursor = (v707_14_tail).read_zipper();
    for v708_6_byte in v708_6_cursor.child_mask().iter() {
      v708_6_cursor.descend_to_byte(v708_6_byte);
      {
      let v708_6_tail = v708_6_cursor.fork_read_zipper();
      let v708_6_head = Path::from_slice(&[v708_6_byte]);
      let v709_2: Space = Space::new();
      v708_6.join_into((v709_2).clone());
      }
      v708_6_cursor.ascend(1);
    }
    drop(v708_6_cursor);
    let v708_7: Space = compose(&(v708_5),&(v708_6));
    drop(v708_5);
    drop(v708_6);
    let v708_8: Space = intersect(&(*CONSTANT_2),&(v708_2));
    drop(v708_2);
    let v708_9: Space = if has_head(&(v708_8)) { singleton(&[]) } else { Space::new() };
    drop(v708_8);
    let v708_12: Space = if (v708_9).is_empty() { Space::new() } else {
      let v710_10: Space = unwrap(&(v707_10),&(v707_14_head));
      let mut v710_11 = Space::new();
      let mut v710_11_cursor = (v707_14_tail).read_zipper();
      for v710_11_byte in v710_11_cursor.child_mask().iter() {
        v710_11_cursor.descend_to_byte(v710_11_byte);
        {
        let v710_11_tail = v710_11_cursor.fork_read_zipper();
        let v710_11_head = Path::from_slice(&[v710_11_byte]);
        let v711_2: Space = singleton(&(v710_11_head));
        let v711_3: Space = intersect(&(*CONSTANT_2),&(v711_2));
        drop(v711_2);
        let v711_4: Space = if has_head(&(v711_3)) { singleton(&[]) } else { Space::new() };
        drop(v711_3);
        let v711_7: Space = if (v711_4).is_empty() { Space::new() } else {
          let v712_5: Space = unwrap(&(v710_10),&(v710_11_head));
          let mut v712_6 = Space::new();
          let mut v712_6_cursor = (v712_5).read_zipper();
          for v712_6_byte in v712_6_cursor.child_mask().iter() {
            v712_6_cursor.descend_to_byte(v712_6_byte);
            {
            let v712_6_tail = v712_6_cursor.fork_read_zipper();
            let v712_6_head = Path::from_slice(&[v712_6_byte]);
            let v713_2: Space = singleton(&(v712_6_head));
            let v713_3: Space = intersect(&(*CONSTANT_2),&(v713_2));
            let v713_4: Space = if has_head(&(v713_3)) { singleton(&[]) } else { Space::new() };
            drop(v713_3);
            let v713_5: Space = subtract(&(*CONSTANT_1),&(v713_4));
            drop(v713_4);
            let v713_7: Space = if (v713_5).is_empty() { Space::new() } else {
              let v714_6: Space = routine_13(c, &(v712_6_head), &(*p1), &(v712_6_tail).make_space());
              compose(&(v713_5),&(v714_6))
            };
            drop(v713_5);
            let v713_8: Space = intersect(&(*CONSTANT_2),&(v713_2));
            drop(v713_2);
            let v713_9: Space = if has_head(&(v713_8)) { singleton(&[]) } else { Space::new() };
            drop(v713_8);
            let v713_11: Space = if (v713_9).is_empty() { Space::new() } else {
              let v715_10: Space = routine_14(c, &(v712_6_head), &(*p1), &(v712_6_tail).make_space());
              compose(&(v713_9),&(v715_10))
            };
            drop(v713_9);
            let v713_12: Space = unite(&(v713_7),&(v713_11));
            v712_6.join_into((v713_12).clone());
            }
            v712_6_cursor.ascend(1);
          }
          drop(v712_6_cursor);
          drop(v712_5);
          compose(&(v711_4),&(v712_6))
        };
        drop(v711_4);
        v710_11.join_into((v711_7).clone());
        }
        v710_11_cursor.ascend(1);
      }
      drop(v710_11_cursor);
      drop(v710_10);
      compose(&(v708_9),&(v710_11))
    };
    drop(v708_9);
    let v708_13: Space = unite(&(v708_7),&(v708_12));
    drop(v708_7);
    v707_14.join_into((v708_13).clone());
    }
    v707_14_cursor.ascend(1);
  }
  drop(v707_14_cursor);
  drop(v707_10);
  (v707_14).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v716_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v716_9: Space = unwrap(&(v716_8),&(*p0));
  drop(v716_8);
  let mut v716_19 = Space::new();
  let mut v716_19_cursor = (*s0).read_zipper();
  for v716_19_byte in v716_19_cursor.child_mask().iter() {
    v716_19_cursor.descend_to_byte(v716_19_byte);
    {
    let v716_19_tail = v716_19_cursor.fork_read_zipper();
    let v716_19_head = Path::from_slice(&[v716_19_byte]);
    let v717_2: Space = singleton(&(v716_19_head));
    let v717_3: Space = intersect(&(*CONSTANT_2),&(v717_2));
    let v717_4: Space = if has_head(&(v717_3)) { singleton(&[]) } else { Space::new() };
    drop(v717_3);
    let v717_5: Space = subtract(&(*CONSTANT_1),&(v717_4));
    drop(v717_4);
    let mut v717_6 = Space::new();
    let mut v717_6_cursor = (v716_19_tail).read_zipper();
    for v717_6_byte in v717_6_cursor.child_mask().iter() {
      v717_6_cursor.descend_to_byte(v717_6_byte);
      {
      let v717_6_tail = v717_6_cursor.fork_read_zipper();
      let v717_6_head = Path::from_slice(&[v717_6_byte]);
      let v718_2: Space = Space::new();
      v717_6.join_into((v718_2).clone());
      }
      v717_6_cursor.ascend(1);
    }
    drop(v717_6_cursor);
    let v717_7: Space = compose(&(v717_5),&(v717_6));
    drop(v717_5);
    drop(v717_6);
    let v717_8: Space = intersect(&(*CONSTANT_2),&(v717_2));
    drop(v717_2);
    let v717_9: Space = if has_head(&(v717_8)) { singleton(&[]) } else { Space::new() };
    drop(v717_8);
    let v717_12: Space = if (v717_9).is_empty() { Space::new() } else {
      let v719_10: Space = unwrap(&(v716_9),&(v716_19_head));
      let mut v719_11 = Space::new();
      let mut v719_11_cursor = (v719_10).read_zipper();
      for v719_11_byte in v719_11_cursor.child_mask().iter() {
        v719_11_cursor.descend_to_byte(v719_11_byte);
        {
        let v719_11_tail = v719_11_cursor.fork_read_zipper();
        let v719_11_head = Path::from_slice(&[v719_11_byte]);
        let v720_2: Space = singleton(&(v719_11_head));
        let v720_3: Space = intersect(&(*CONSTANT_2),&(v720_2));
        let v720_4: Space = if has_head(&(v720_3)) { singleton(&[]) } else { Space::new() };
        drop(v720_3);
        let v720_5: Space = subtract(&(*CONSTANT_1),&(v720_4));
        drop(v720_4);
        let v720_7: Space = if (v720_5).is_empty() { Space::new() } else {
          let mut v721_6 = Space::new();
          let mut v721_6_cursor = (v719_11_tail).read_zipper();
          for v721_6_byte in v721_6_cursor.child_mask().iter() {
            v721_6_cursor.descend_to_byte(v721_6_byte);
            {
            let v721_6_tail = v721_6_cursor.fork_read_zipper();
            let v721_6_head = Path::from_slice(&[v721_6_byte]);
            let v722_2: Space = singleton(&(v721_6_head));
            let v722_3: Space = intersect(&(*CONSTANT_2),&(v722_2));
            let v722_4: Space = if has_head(&(v722_3)) { singleton(&[]) } else { Space::new() };
            drop(v722_3);
            let v722_5: Space = subtract(&(*CONSTANT_1),&(v722_4));
            drop(v722_4);
            let v722_8: Space = if (v722_5).is_empty() { Space::new() } else {
              let v723_6: Path = concat_path(&(v719_11_head),&(v721_6_head));
              let v723_7: Space = routine_17(c, &(v723_6), &(*p1), &(v721_6_tail).make_space());
              compose(&(v722_5),&(v723_7))
            };
            drop(v722_5);
            let v722_9: Space = intersect(&(*CONSTANT_2),&(v722_2));
            drop(v722_2);
            let v722_10: Space = if has_head(&(v722_9)) { singleton(&[]) } else { Space::new() };
            drop(v722_9);
            let v722_12: Space = if (v722_10).is_empty() { Space::new() } else {
              let v724_6: Path = concat_path(&(v719_11_head),&(v721_6_head));
              let v724_11: Space = routine_18(c, &(v724_6), &(*p1), &(v721_6_tail).make_space());
              drop(v724_6);
              compose(&(v722_10),&(v724_11))
            };
            drop(v722_10);
            let v722_13: Space = unite(&(v722_8),&(v722_12));
            v721_6.join_into((v722_13).clone());
            }
            v721_6_cursor.ascend(1);
          }
          drop(v721_6_cursor);
          compose(&(v720_5),&(v721_6))
        };
        drop(v720_5);
        let v720_8: Space = intersect(&(*CONSTANT_2),&(v720_2));
        drop(v720_2);
        let v720_9: Space = if has_head(&(v720_8)) { singleton(&[]) } else { Space::new() };
        drop(v720_8);
        let v720_11: Space = if (v720_9).is_empty() { Space::new() } else {
          let mut v725_10 = Space::new();
          let mut v725_10_cursor = (v719_11_tail).read_zipper();
          for v725_10_byte in v725_10_cursor.child_mask().iter() {
            v725_10_cursor.descend_to_byte(v725_10_byte);
            {
            let v725_10_tail = v725_10_cursor.fork_read_zipper();
            let v725_10_head = Path::from_slice(&[v725_10_byte]);
            let v726_2: Space = singleton(&(v725_10_head));
            let v726_3: Space = intersect(&(*CONSTANT_2),&(v726_2));
            let v726_4: Space = if has_head(&(v726_3)) { singleton(&[]) } else { Space::new() };
            drop(v726_3);
            let v726_5: Space = subtract(&(*CONSTANT_1),&(v726_4));
            drop(v726_4);
            let v726_8: Space = if (v726_5).is_empty() { Space::new() } else {
              let v727_6: Path = concat_path(&(v719_11_head),&(v725_10_head));
              let v727_7: Space = routine_17(c, &(v727_6), &(*p1), &(v725_10_tail).make_space());
              compose(&(v726_5),&(v727_7))
            };
            drop(v726_5);
            let v726_9: Space = intersect(&(*CONSTANT_2),&(v726_2));
            drop(v726_2);
            let v726_10: Space = if has_head(&(v726_9)) { singleton(&[]) } else { Space::new() };
            drop(v726_9);
            let v726_12: Space = if (v726_10).is_empty() { Space::new() } else {
              let v728_6: Path = concat_path(&(v719_11_head),&(v725_10_head));
              let v728_11: Space = routine_19(c, &(v728_6), &(*p1), &(v725_10_tail).make_space());
              drop(v728_6);
              compose(&(v726_10),&(v728_11))
            };
            drop(v726_10);
            let v726_13: Space = unite(&(v726_8),&(v726_12));
            v725_10.join_into((v726_13).clone());
            }
            v725_10_cursor.ascend(1);
          }
          drop(v725_10_cursor);
          compose(&(v720_9),&(v725_10))
        };
        drop(v720_9);
        let v720_12: Space = unite(&(v720_7),&(v720_11));
        v719_11.join_into((v720_12).clone());
        }
        v719_11_cursor.ascend(1);
      }
      drop(v719_11_cursor);
      drop(v719_10);
      compose(&(v717_9),&(v719_11))
    };
    drop(v717_9);
    let v717_13: Space = unite(&(v717_7),&(v717_12));
    drop(v717_7);
    v716_19.join_into((v717_13).clone());
    }
    v716_19_cursor.ascend(1);
  }
  drop(v716_19_cursor);
  drop(v716_9);
  (v716_19).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v729_21 = Space::new();
  let mut v729_21_cursor = (*s0).read_zipper();
  for v729_21_byte in v729_21_cursor.child_mask().iter() {
    v729_21_cursor.descend_to_byte(v729_21_byte);
    {
    let v729_21_tail = v729_21_cursor.fork_read_zipper();
    let v729_21_head = Path::from_slice(&[v729_21_byte]);
    let v730_2: Space = singleton(&(v729_21_head));
    let v730_3: Space = intersect(&(*CONSTANT_2),&(v730_2));
    let v730_4: Space = if has_head(&(v730_3)) { singleton(&[]) } else { Space::new() };
    drop(v730_3);
    let v730_5: Space = subtract(&(*CONSTANT_1),&(v730_4));
    drop(v730_4);
    let v730_8: Space = if (v730_5).is_empty() { Space::new() } else {
      let v731_6: Path = concat_path(&(*p0),&(v729_21_head));
      let mut v731_7 = Space::new();
      let mut v731_7_cursor = (v729_21_tail).read_zipper();
      for v731_7_byte in v731_7_cursor.child_mask().iter() {
        v731_7_cursor.descend_to_byte(v731_7_byte);
        {
        let v731_7_tail = v731_7_cursor.fork_read_zipper();
        let v731_7_head = Path::from_slice(&[v731_7_byte]);
        let v732_2: Space = singleton(&(v731_7_head));
        let v732_3: Space = intersect(&(*CONSTANT_2),&(v732_2));
        let v732_4: Space = if has_head(&(v732_3)) { singleton(&[]) } else { Space::new() };
        drop(v732_3);
        let v732_5: Space = subtract(&(*CONSTANT_1),&(v732_4));
        drop(v732_4);
        let v732_8: Space = if (v732_5).is_empty() { Space::new() } else {
          let v733_6: Path = concat_path(&(v731_6),&(v731_7_head));
          let mut v733_7 = Space::new();
          let mut v733_7_cursor = (v731_7_tail).read_zipper();
          for v733_7_byte in v733_7_cursor.child_mask().iter() {
            v733_7_cursor.descend_to_byte(v733_7_byte);
            {
            let v733_7_tail = v733_7_cursor.fork_read_zipper();
            let v733_7_head = Path::from_slice(&[v733_7_byte]);
            let v734_2: Space = singleton(&(v733_7_head));
            let v734_3: Space = intersect(&(*CONSTANT_2),&(v734_2));
            let v734_4: Space = if has_head(&(v734_3)) { singleton(&[]) } else { Space::new() };
            drop(v734_3);
            let v734_5: Space = subtract(&(*CONSTANT_1),&(v734_4));
            drop(v734_4);
            let v734_8: Space = if (v734_5).is_empty() { Space::new() } else {
              let v735_6: Path = concat_path(&(v733_6),&(v733_7_head));
              let v735_7: Space = routine_48(c, &(v735_6), &(*p1), &(v733_7_tail).make_space());
              compose(&(v734_5),&(v735_7))
            };
            drop(v734_5);
            let v734_9: Space = intersect(&(*CONSTANT_2),&(v734_2));
            drop(v734_2);
            let v734_10: Space = if has_head(&(v734_9)) { singleton(&[]) } else { Space::new() };
            drop(v734_9);
            let v734_12: Space = if (v734_10).is_empty() { Space::new() } else {
              let v736_6: Path = concat_path(&(v733_6),&(v733_7_head));
              let v736_11: Space = routine_49(c, &(v736_6), &(*p1), &(v733_7_tail).make_space());
              drop(v736_6);
              compose(&(v734_10),&(v736_11))
            };
            drop(v734_10);
            let v734_13: Space = unite(&(v734_8),&(v734_12));
            v733_7.join_into((v734_13).clone());
            }
            v733_7_cursor.ascend(1);
          }
          drop(v733_7_cursor);
          compose(&(v732_5),&(v733_7))
        };
        drop(v732_5);
        let v732_9: Space = intersect(&(*CONSTANT_2),&(v732_2));
        drop(v732_2);
        let v732_10: Space = if has_head(&(v732_9)) { singleton(&[]) } else { Space::new() };
        drop(v732_9);
        let v732_12: Space = if (v732_10).is_empty() { Space::new() } else {
          let v737_6: Path = concat_path(&(v731_6),&(v731_7_head));
          let mut v737_11 = Space::new();
          let mut v737_11_cursor = (v731_7_tail).read_zipper();
          for v737_11_byte in v737_11_cursor.child_mask().iter() {
            v737_11_cursor.descend_to_byte(v737_11_byte);
            {
            let v737_11_tail = v737_11_cursor.fork_read_zipper();
            let v737_11_head = Path::from_slice(&[v737_11_byte]);
            let v738_2: Space = singleton(&(v737_11_head));
            let v738_3: Space = intersect(&(*CONSTANT_2),&(v738_2));
            let v738_4: Space = if has_head(&(v738_3)) { singleton(&[]) } else { Space::new() };
            drop(v738_3);
            let v738_5: Space = subtract(&(*CONSTANT_1),&(v738_4));
            drop(v738_4);
            let v738_8: Space = if (v738_5).is_empty() { Space::new() } else {
              let v739_6: Path = concat_path(&(v737_6),&(v737_11_head));
              let v739_7: Space = routine_48(c, &(v739_6), &(*p1), &(v737_11_tail).make_space());
              compose(&(v738_5),&(v739_7))
            };
            drop(v738_5);
            let v738_9: Space = intersect(&(*CONSTANT_2),&(v738_2));
            drop(v738_2);
            let v738_10: Space = if has_head(&(v738_9)) { singleton(&[]) } else { Space::new() };
            drop(v738_9);
            let v738_12: Space = if (v738_10).is_empty() { Space::new() } else {
              let v740_6: Path = concat_path(&(v737_6),&(v737_11_head));
              let v740_11: Space = routine_19(c, &(v740_6), &(*p1), &(v737_11_tail).make_space());
              drop(v740_6);
              compose(&(v738_10),&(v740_11))
            };
            drop(v738_10);
            let v738_13: Space = unite(&(v738_8),&(v738_12));
            v737_11.join_into((v738_13).clone());
            }
            v737_11_cursor.ascend(1);
          }
          drop(v737_11_cursor);
          drop(v737_6);
          compose(&(v732_10),&(v737_11))
        };
        drop(v732_10);
        let v732_13: Space = unite(&(v732_8),&(v732_12));
        v731_7.join_into((v732_13).clone());
        }
        v731_7_cursor.ascend(1);
      }
      drop(v731_7_cursor);
      compose(&(v730_5),&(v731_7))
    };
    drop(v730_5);
    let v730_9: Space = intersect(&(*CONSTANT_2),&(v730_2));
    drop(v730_2);
    let v730_10: Space = if has_head(&(v730_9)) { singleton(&[]) } else { Space::new() };
    drop(v730_9);
    let v730_12: Space = if (v730_10).is_empty() { Space::new() } else {
      let v741_6: Path = concat_path(&(*p0),&(v729_21_head));
      let mut v741_11 = Space::new();
      let mut v741_11_cursor = (v729_21_tail).read_zipper();
      for v741_11_byte in v741_11_cursor.child_mask().iter() {
        v741_11_cursor.descend_to_byte(v741_11_byte);
        {
        let v741_11_tail = v741_11_cursor.fork_read_zipper();
        let v741_11_head = Path::from_slice(&[v741_11_byte]);
        let v742_2: Space = singleton(&(v741_11_head));
        let v742_3: Space = intersect(&(*CONSTANT_2),&(v742_2));
        let v742_4: Space = if has_head(&(v742_3)) { singleton(&[]) } else { Space::new() };
        drop(v742_3);
        let v742_5: Space = subtract(&(*CONSTANT_1),&(v742_4));
        drop(v742_4);
        let v742_8: Space = if (v742_5).is_empty() { Space::new() } else {
          let v743_6: Path = concat_path(&(v741_6),&(v741_11_head));
          let mut v743_7 = Space::new();
          let mut v743_7_cursor = (v741_11_tail).read_zipper();
          for v743_7_byte in v743_7_cursor.child_mask().iter() {
            v743_7_cursor.descend_to_byte(v743_7_byte);
            {
            let v743_7_tail = v743_7_cursor.fork_read_zipper();
            let v743_7_head = Path::from_slice(&[v743_7_byte]);
            let v744_2: Space = singleton(&(v743_7_head));
            let v744_3: Space = intersect(&(*CONSTANT_2),&(v744_2));
            let v744_4: Space = if has_head(&(v744_3)) { singleton(&[]) } else { Space::new() };
            drop(v744_3);
            let v744_5: Space = subtract(&(*CONSTANT_1),&(v744_4));
            drop(v744_4);
            let v744_8: Space = if (v744_5).is_empty() { Space::new() } else {
              let v745_6: Path = concat_path(&(v743_6),&(v743_7_head));
              let v745_7: Space = routine_48(c, &(v745_6), &(*p1), &(v743_7_tail).make_space());
              compose(&(v744_5),&(v745_7))
            };
            drop(v744_5);
            let v744_9: Space = intersect(&(*CONSTANT_2),&(v744_2));
            drop(v744_2);
            let v744_10: Space = if has_head(&(v744_9)) { singleton(&[]) } else { Space::new() };
            drop(v744_9);
            let v744_12: Space = if (v744_10).is_empty() { Space::new() } else {
              let v746_6: Path = concat_path(&(v743_6),&(v743_7_head));
              let v746_11: Space = routine_49(c, &(v746_6), &(*p1), &(v743_7_tail).make_space());
              drop(v746_6);
              compose(&(v744_10),&(v746_11))
            };
            drop(v744_10);
            let v744_13: Space = unite(&(v744_8),&(v744_12));
            v743_7.join_into((v744_13).clone());
            }
            v743_7_cursor.ascend(1);
          }
          drop(v743_7_cursor);
          compose(&(v742_5),&(v743_7))
        };
        drop(v742_5);
        let v742_9: Space = intersect(&(*CONSTANT_2),&(v742_2));
        drop(v742_2);
        let v742_10: Space = if has_head(&(v742_9)) { singleton(&[]) } else { Space::new() };
        drop(v742_9);
        let v742_11: Space = compose(&(v742_10),&(v741_11_tail));
        drop(v742_10);
        let v747_6: Path = concat_path(&(v741_6),&(v741_11_head));
        let v742_12: Space = wrap(&(v742_11),&(v747_6));
        drop(v742_11);
        let v742_13: Space = wrap(&(v742_12),&(*p1));
        drop(v742_12);
        let v742_14: Space = unite(&(v742_8),&(v742_13));
        drop(v742_13);
        v741_11.join_into((v742_14).clone());
        }
        v741_11_cursor.ascend(1);
      }
      drop(v741_11_cursor);
      drop(v741_6);
      compose(&(v730_10),&(v741_11))
    };
    drop(v730_10);
    let v730_13: Space = unite(&(v730_8),&(v730_12));
    v729_21.join_into((v730_13).clone());
    }
    v729_21_cursor.ascend(1);
  }
  drop(v729_21_cursor);
  (v729_21).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v748_15 = Space::new();
  let mut v748_15_cursor = (*s0).read_zipper();
  for v748_15_byte in v748_15_cursor.child_mask().iter() {
    v748_15_cursor.descend_to_byte(v748_15_byte);
    {
    let v748_15_tail = v748_15_cursor.fork_read_zipper();
    let v748_15_head = Path::from_slice(&[v748_15_byte]);
    let v749_2: Space = singleton(&(v748_15_head));
    let v749_3: Space = intersect(&(*CONSTANT_2),&(v749_2));
    let v749_4: Space = if has_head(&(v749_3)) { singleton(&[]) } else { Space::new() };
    drop(v749_3);
    let v749_5: Space = subtract(&(*CONSTANT_1),&(v749_4));
    drop(v749_4);
    let v749_8: Space = if (v749_5).is_empty() { Space::new() } else {
      let v750_6: Path = concat_path(&(*p0),&(v748_15_head));
      let mut v750_7 = Space::new();
      let mut v750_7_cursor = (v748_15_tail).read_zipper();
      for v750_7_byte in v750_7_cursor.child_mask().iter() {
        v750_7_cursor.descend_to_byte(v750_7_byte);
        {
        let v750_7_tail = v750_7_cursor.fork_read_zipper();
        let v750_7_head = Path::from_slice(&[v750_7_byte]);
        let v751_2: Space = singleton(&(v750_7_head));
        let v751_3: Space = intersect(&(*CONSTANT_2),&(v751_2));
        let v751_4: Space = if has_head(&(v751_3)) { singleton(&[]) } else { Space::new() };
        drop(v751_3);
        let v751_5: Space = subtract(&(*CONSTANT_1),&(v751_4));
        drop(v751_4);
        let v751_8: Space = if (v751_5).is_empty() { Space::new() } else {
          let v752_6: Path = concat_path(&(v750_6),&(v750_7_head));
          let mut v752_7 = Space::new();
          let mut v752_7_cursor = (v750_7_tail).read_zipper();
          for v752_7_byte in v752_7_cursor.child_mask().iter() {
            v752_7_cursor.descend_to_byte(v752_7_byte);
            {
            let v752_7_tail = v752_7_cursor.fork_read_zipper();
            let v752_7_head = Path::from_slice(&[v752_7_byte]);
            let v753_2: Space = singleton(&(v752_7_head));
            let v753_3: Space = intersect(&(*CONSTANT_2),&(v753_2));
            let v753_4: Space = if has_head(&(v753_3)) { singleton(&[]) } else { Space::new() };
            drop(v753_3);
            let v753_5: Space = subtract(&(*CONSTANT_1),&(v753_4));
            drop(v753_4);
            let v753_8: Space = if (v753_5).is_empty() { Space::new() } else {
              let v754_6: Path = concat_path(&(v752_6),&(v752_7_head));
              let v754_7: Space = routine_48(c, &(v754_6), &(*p1), &(v752_7_tail).make_space());
              compose(&(v753_5),&(v754_7))
            };
            drop(v753_5);
            let v753_9: Space = intersect(&(*CONSTANT_2),&(v753_2));
            drop(v753_2);
            let v753_10: Space = if has_head(&(v753_9)) { singleton(&[]) } else { Space::new() };
            drop(v753_9);
            let v753_12: Space = if (v753_10).is_empty() { Space::new() } else {
              let v755_6: Path = concat_path(&(v752_6),&(v752_7_head));
              let v755_11: Space = routine_49(c, &(v755_6), &(*p1), &(v752_7_tail).make_space());
              drop(v755_6);
              compose(&(v753_10),&(v755_11))
            };
            drop(v753_10);
            let v753_13: Space = unite(&(v753_8),&(v753_12));
            v752_7.join_into((v753_13).clone());
            }
            v752_7_cursor.ascend(1);
          }
          drop(v752_7_cursor);
          compose(&(v751_5),&(v752_7))
        };
        drop(v751_5);
        let v751_9: Space = intersect(&(*CONSTANT_2),&(v751_2));
        drop(v751_2);
        let v751_10: Space = if has_head(&(v751_9)) { singleton(&[]) } else { Space::new() };
        drop(v751_9);
        let v751_12: Space = if (v751_10).is_empty() { Space::new() } else {
          let v756_6: Path = concat_path(&(v750_6),&(v750_7_head));
          let mut v756_11 = Space::new();
          let mut v756_11_cursor = (v750_7_tail).read_zipper();
          for v756_11_byte in v756_11_cursor.child_mask().iter() {
            v756_11_cursor.descend_to_byte(v756_11_byte);
            {
            let v756_11_tail = v756_11_cursor.fork_read_zipper();
            let v756_11_head = Path::from_slice(&[v756_11_byte]);
            let v757_2: Space = singleton(&(v756_11_head));
            let v757_3: Space = intersect(&(*CONSTANT_2),&(v757_2));
            let v757_4: Space = if has_head(&(v757_3)) { singleton(&[]) } else { Space::new() };
            drop(v757_3);
            let v757_5: Space = subtract(&(*CONSTANT_1),&(v757_4));
            drop(v757_4);
            let v757_8: Space = if (v757_5).is_empty() { Space::new() } else {
              let v758_6: Path = concat_path(&(v756_6),&(v756_11_head));
              let v758_7: Space = routine_48(c, &(v758_6), &(*p1), &(v756_11_tail).make_space());
              compose(&(v757_5),&(v758_7))
            };
            drop(v757_5);
            let v757_9: Space = intersect(&(*CONSTANT_2),&(v757_2));
            drop(v757_2);
            let v757_10: Space = if has_head(&(v757_9)) { singleton(&[]) } else { Space::new() };
            drop(v757_9);
            let v757_12: Space = if (v757_10).is_empty() { Space::new() } else {
              let v759_6: Path = concat_path(&(v756_6),&(v756_11_head));
              let v759_11: Space = routine_19(c, &(v759_6), &(*p1), &(v756_11_tail).make_space());
              drop(v759_6);
              compose(&(v757_10),&(v759_11))
            };
            drop(v757_10);
            let v757_13: Space = unite(&(v757_8),&(v757_12));
            v756_11.join_into((v757_13).clone());
            }
            v756_11_cursor.ascend(1);
          }
          drop(v756_11_cursor);
          drop(v756_6);
          compose(&(v751_10),&(v756_11))
        };
        drop(v751_10);
        let v751_13: Space = unite(&(v751_8),&(v751_12));
        v750_7.join_into((v751_13).clone());
        }
        v750_7_cursor.ascend(1);
      }
      drop(v750_7_cursor);
      compose(&(v749_5),&(v750_7))
    };
    drop(v749_5);
    let v749_9: Space = intersect(&(*CONSTANT_2),&(v749_2));
    drop(v749_2);
    let v749_10: Space = if has_head(&(v749_9)) { singleton(&[]) } else { Space::new() };
    drop(v749_9);
    let v749_11: Space = compose(&(v749_10),&(v748_15_tail));
    drop(v749_10);
    let v760_6: Path = concat_path(&(*p0),&(v748_15_head));
    let v749_12: Space = wrap(&(v749_11),&(v760_6));
    drop(v749_11);
    let v749_13: Space = wrap(&(v749_12),&(*p1));
    drop(v749_12);
    let v749_14: Space = unite(&(v749_8),&(v749_13));
    drop(v749_13);
    v748_15.join_into((v749_14).clone());
    }
    v748_15_cursor.ascend(1);
  }
  drop(v748_15_cursor);
  (v748_15).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v761_4 = Space::new();
  let mut v761_4_cursor = (*s0).read_zipper();
  for v761_4_byte in v761_4_cursor.child_mask().iter() {
    v761_4_cursor.descend_to_byte(v761_4_byte);
    {
    let v761_4_tail = v761_4_cursor.fork_read_zipper();
    let v761_4_head = Path::from_slice(&[v761_4_byte]);
    let v762_2: Space = Space::new();
    v761_4.join_into((v762_2).clone());
    }
    v761_4_cursor.ascend(1);
  }
  drop(v761_4_cursor);
  (v761_4).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v763_6: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v763_7: Space = unwrap(&(v763_6),&(*p0));
  drop(v763_6);
  let mut v763_17 = Space::new();
  let mut v763_17_cursor = (*s0).read_zipper();
  for v763_17_byte in v763_17_cursor.child_mask().iter() {
    v763_17_cursor.descend_to_byte(v763_17_byte);
    {
    let v763_17_tail = v763_17_cursor.fork_read_zipper();
    let v763_17_head = Path::from_slice(&[v763_17_byte]);
    let v764_2: Space = singleton(&(v763_17_head));
    let v764_3: Space = intersect(&(*CONSTANT_2),&(v764_2));
    drop(v764_2);
    let v764_4: Space = if has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
    drop(v764_3);
    let v764_7: Space = if (v764_4).is_empty() { Space::new() } else {
      let v765_5: Space = unwrap(&(v763_7),&(v763_17_head));
      let mut v765_6 = Space::new();
      let mut v765_6_cursor = (v765_5).read_zipper();
      for v765_6_byte in v765_6_cursor.child_mask().iter() {
        v765_6_cursor.descend_to_byte(v765_6_byte);
        {
        let v765_6_tail = v765_6_cursor.fork_read_zipper();
        let v765_6_head = Path::from_slice(&[v765_6_byte]);
        let v766_2: Space = singleton(&(v765_6_head));
        let v766_3: Space = intersect(&(*CONSTANT_2),&(v766_2));
        let v766_4: Space = if has_head(&(v766_3)) { singleton(&[]) } else { Space::new() };
        drop(v766_3);
        let v766_5: Space = subtract(&(*CONSTANT_1),&(v766_4));
        drop(v766_4);
        let v766_7: Space = if (v766_5).is_empty() { Space::new() } else {
          let mut v767_6 = Space::new();
          let mut v767_6_cursor = (v765_6_tail).read_zipper();
          for v767_6_byte in v767_6_cursor.child_mask().iter() {
            v767_6_cursor.descend_to_byte(v767_6_byte);
            {
            let v767_6_tail = v767_6_cursor.fork_read_zipper();
            let v767_6_head = Path::from_slice(&[v767_6_byte]);
            let v768_2: Space = singleton(&(v767_6_head));
            let v768_3: Space = intersect(&(*CONSTANT_2),&(v768_2));
            let v768_4: Space = if has_head(&(v768_3)) { singleton(&[]) } else { Space::new() };
            drop(v768_3);
            let v768_5: Space = subtract(&(*CONSTANT_1),&(v768_4));
            drop(v768_4);
            let v768_8: Space = if (v768_5).is_empty() { Space::new() } else {
              let v769_6: Path = concat_path(&(v765_6_head),&(v767_6_head));
              let v769_7: Space = routine_17(c, &(v769_6), &(*p1), &(v767_6_tail).make_space());
              compose(&(v768_5),&(v769_7))
            };
            drop(v768_5);
            let v768_9: Space = intersect(&(*CONSTANT_2),&(v768_2));
            drop(v768_2);
            let v768_10: Space = if has_head(&(v768_9)) { singleton(&[]) } else { Space::new() };
            drop(v768_9);
            let v768_12: Space = if (v768_10).is_empty() { Space::new() } else {
              let v770_6: Path = concat_path(&(v765_6_head),&(v767_6_head));
              let v770_11: Space = routine_18(c, &(v770_6), &(*p1), &(v767_6_tail).make_space());
              drop(v770_6);
              compose(&(v768_10),&(v770_11))
            };
            drop(v768_10);
            let v768_13: Space = unite(&(v768_8),&(v768_12));
            v767_6.join_into((v768_13).clone());
            }
            v767_6_cursor.ascend(1);
          }
          drop(v767_6_cursor);
          compose(&(v766_5),&(v767_6))
        };
        drop(v766_5);
        let v766_8: Space = intersect(&(*CONSTANT_2),&(v766_2));
        drop(v766_2);
        let v766_9: Space = if has_head(&(v766_8)) { singleton(&[]) } else { Space::new() };
        drop(v766_8);
        let v766_11: Space = if (v766_9).is_empty() { Space::new() } else {
          let mut v771_10 = Space::new();
          let mut v771_10_cursor = (v765_6_tail).read_zipper();
          for v771_10_byte in v771_10_cursor.child_mask().iter() {
            v771_10_cursor.descend_to_byte(v771_10_byte);
            {
            let v771_10_tail = v771_10_cursor.fork_read_zipper();
            let v771_10_head = Path::from_slice(&[v771_10_byte]);
            let v772_2: Space = singleton(&(v771_10_head));
            let v772_3: Space = intersect(&(*CONSTANT_2),&(v772_2));
            let v772_4: Space = if has_head(&(v772_3)) { singleton(&[]) } else { Space::new() };
            drop(v772_3);
            let v772_5: Space = subtract(&(*CONSTANT_1),&(v772_4));
            drop(v772_4);
            let v772_8: Space = if (v772_5).is_empty() { Space::new() } else {
              let v773_6: Path = concat_path(&(v765_6_head),&(v771_10_head));
              let v773_7: Space = routine_17(c, &(v773_6), &(*p1), &(v771_10_tail).make_space());
              compose(&(v772_5),&(v773_7))
            };
            drop(v772_5);
            let v772_9: Space = intersect(&(*CONSTANT_2),&(v772_2));
            drop(v772_2);
            let v772_10: Space = if has_head(&(v772_9)) { singleton(&[]) } else { Space::new() };
            drop(v772_9);
            let v772_12: Space = if (v772_10).is_empty() { Space::new() } else {
              let v774_6: Path = concat_path(&(v765_6_head),&(v771_10_head));
              let v774_11: Space = routine_19(c, &(v774_6), &(*p1), &(v771_10_tail).make_space());
              drop(v774_6);
              compose(&(v772_10),&(v774_11))
            };
            drop(v772_10);
            let v772_13: Space = unite(&(v772_8),&(v772_12));
            v771_10.join_into((v772_13).clone());
            }
            v771_10_cursor.ascend(1);
          }
          drop(v771_10_cursor);
          compose(&(v766_9),&(v771_10))
        };
        drop(v766_9);
        let v766_12: Space = unite(&(v766_7),&(v766_11));
        v765_6.join_into((v766_12).clone());
        }
        v765_6_cursor.ascend(1);
      }
      drop(v765_6_cursor);
      drop(v765_5);
      compose(&(v764_4),&(v765_6))
    };
    drop(v764_4);
    v763_17.join_into((v764_7).clone());
    }
    v763_17_cursor.ascend(1);
  }
  drop(v763_17_cursor);
  drop(v763_7);
  (v763_17).clone()
}

fn routine_44(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v775_13 = Space::new();
  let mut v775_13_cursor = (*s0).read_zipper();
  for v775_13_byte in v775_13_cursor.child_mask().iter() {
    v775_13_cursor.descend_to_byte(v775_13_byte);
    {
    let v775_13_tail = v775_13_cursor.fork_read_zipper();
    let v775_13_head = Path::from_slice(&[v775_13_byte]);
    let v776_2: Space = singleton(&(v775_13_head));
    let v776_3: Space = intersect(&(*CONSTANT_2),&(v776_2));
    let v776_4: Space = if has_head(&(v776_3)) { singleton(&[]) } else { Space::new() };
    drop(v776_3);
    let v776_5: Space = subtract(&(*CONSTANT_1),&(v776_4));
    drop(v776_4);
    let v776_8: Space = if (v776_5).is_empty() { Space::new() } else {
      let v777_6: Path = concat_path(&(*p0),&(v775_13_head));
      let mut v777_7 = Space::new();
      let mut v777_7_cursor = (v775_13_tail).read_zipper();
      for v777_7_byte in v777_7_cursor.child_mask().iter() {
        v777_7_cursor.descend_to_byte(v777_7_byte);
        {
        let v777_7_tail = v777_7_cursor.fork_read_zipper();
        let v777_7_head = Path::from_slice(&[v777_7_byte]);
        let v778_2: Space = singleton(&(v777_7_head));
        let v778_3: Space = intersect(&(*CONSTANT_2),&(v778_2));
        let v778_4: Space = if has_head(&(v778_3)) { singleton(&[]) } else { Space::new() };
        drop(v778_3);
        let v778_5: Space = subtract(&(*CONSTANT_1),&(v778_4));
        drop(v778_4);
        let mut v778_6 = Space::new();
        let mut v778_6_cursor = (v777_7_tail).read_zipper();
        for v778_6_byte in v778_6_cursor.child_mask().iter() {
          v778_6_cursor.descend_to_byte(v778_6_byte);
          {
          let v778_6_tail = v778_6_cursor.fork_read_zipper();
          let v778_6_head = Path::from_slice(&[v778_6_byte]);
          let v779_2: Space = Space::new();
          v778_6.join_into((v779_2).clone());
          }
          v778_6_cursor.ascend(1);
        }
        drop(v778_6_cursor);
        let v778_7: Space = compose(&(v778_5),&(v778_6));
        drop(v778_5);
        drop(v778_6);
        let v778_8: Space = intersect(&(*CONSTANT_2),&(v778_2));
        drop(v778_2);
        let v778_9: Space = if has_head(&(v778_8)) { singleton(&[]) } else { Space::new() };
        drop(v778_8);
        let v778_12: Space = if (v778_9).is_empty() { Space::new() } else {
          let v780_10: Path = concat_path(&(v777_6),&(v777_7_head));
          let mut v780_11 = Space::new();
          let mut v780_11_cursor = (v777_7_tail).read_zipper();
          for v780_11_byte in v780_11_cursor.child_mask().iter() {
            v780_11_cursor.descend_to_byte(v780_11_byte);
            {
            let v780_11_tail = v780_11_cursor.fork_read_zipper();
            let v780_11_head = Path::from_slice(&[v780_11_byte]);
            let v781_2: Space = singleton(&(v780_11_head));
            let v781_3: Space = intersect(&(*CONSTANT_2),&(v781_2));
            drop(v781_2);
            let v781_4: Space = if has_head(&(v781_3)) { singleton(&[]) } else { Space::new() };
            drop(v781_3);
            let v781_7: Space = if (v781_4).is_empty() { Space::new() } else {
              let v782_5: Path = concat_path(&(v780_10),&(v780_11_head));
              let v782_6: Space = routine_19(c, &(v782_5), &(*p1), &(v780_11_tail).make_space());
              drop(v782_5);
              compose(&(v781_4),&(v782_6))
            };
            drop(v781_4);
            v780_11.join_into((v781_7).clone());
            }
            v780_11_cursor.ascend(1);
          }
          drop(v780_11_cursor);
          drop(v780_10);
          compose(&(v778_9),&(v780_11))
        };
        drop(v778_9);
        let v778_13: Space = unite(&(v778_7),&(v778_12));
        drop(v778_7);
        v777_7.join_into((v778_13).clone());
        }
        v777_7_cursor.ascend(1);
      }
      drop(v777_7_cursor);
      compose(&(v776_5),&(v777_7))
    };
    drop(v776_5);
    let v776_9: Space = intersect(&(*CONSTANT_2),&(v776_2));
    drop(v776_2);
    let v776_10: Space = if has_head(&(v776_9)) { singleton(&[]) } else { Space::new() };
    drop(v776_9);
    let v776_12: Space = if (v776_10).is_empty() { Space::new() } else {
      let v783_6: Path = concat_path(&(*p0),&(v775_13_head));
      let mut v783_11 = Space::new();
      let mut v783_11_cursor = (v775_13_tail).read_zipper();
      for v783_11_byte in v783_11_cursor.child_mask().iter() {
        v783_11_cursor.descend_to_byte(v783_11_byte);
        {
        let v783_11_tail = v783_11_cursor.fork_read_zipper();
        let v783_11_head = Path::from_slice(&[v783_11_byte]);
        let v784_2: Space = singleton(&(v783_11_head));
        let v784_3: Space = intersect(&(*CONSTANT_2),&(v784_2));
        let v784_4: Space = if has_head(&(v784_3)) { singleton(&[]) } else { Space::new() };
        drop(v784_3);
        let v784_5: Space = subtract(&(*CONSTANT_1),&(v784_4));
        drop(v784_4);
        let mut v784_6 = Space::new();
        let mut v784_6_cursor = (v783_11_tail).read_zipper();
        for v784_6_byte in v784_6_cursor.child_mask().iter() {
          v784_6_cursor.descend_to_byte(v784_6_byte);
          {
          let v784_6_tail = v784_6_cursor.fork_read_zipper();
          let v784_6_head = Path::from_slice(&[v784_6_byte]);
          let v785_2: Space = Space::new();
          v784_6.join_into((v785_2).clone());
          }
          v784_6_cursor.ascend(1);
        }
        drop(v784_6_cursor);
        let v784_7: Space = compose(&(v784_5),&(v784_6));
        drop(v784_5);
        drop(v784_6);
        let v784_8: Space = intersect(&(*CONSTANT_2),&(v784_2));
        drop(v784_2);
        let v784_9: Space = if has_head(&(v784_8)) { singleton(&[]) } else { Space::new() };
        drop(v784_8);
        let v784_10: Space = compose(&(v784_9),&(v783_11_tail));
        drop(v784_9);
        let v784_11: Path = concat_path(&(v783_6),&(v783_11_head));
        let v784_12: Space = wrap(&(v784_10),&(v784_11));
        drop(v784_10);
        drop(v784_11);
        let v784_13: Space = wrap(&(v784_12),&(*p1));
        drop(v784_12);
        let v784_14: Space = unite(&(v784_7),&(v784_13));
        drop(v784_7);
        drop(v784_13);
        v783_11.join_into((v784_14).clone());
        }
        v783_11_cursor.ascend(1);
      }
      drop(v783_11_cursor);
      drop(v783_6);
      compose(&(v776_10),&(v783_11))
    };
    drop(v776_10);
    let v776_13: Space = unite(&(v776_8),&(v776_12));
    drop(v776_12);
    v775_13.join_into((v776_13).clone());
    }
    v775_13_cursor.ascend(1);
  }
  drop(v775_13_cursor);
  (v775_13).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v786_10 = Space::new();
  let mut v786_10_cursor = (*s0).read_zipper();
  for v786_10_byte in v786_10_cursor.child_mask().iter() {
    v786_10_cursor.descend_to_byte(v786_10_byte);
    {
    let v786_10_tail = v786_10_cursor.fork_read_zipper();
    let v786_10_head = Path::from_slice(&[v786_10_byte]);
    let v787_2: Space = singleton(&(v786_10_head));
    let v787_3: Space = intersect(&(*CONSTANT_2),&(v787_2));
    let v787_4: Space = if has_head(&(v787_3)) { singleton(&[]) } else { Space::new() };
    drop(v787_3);
    let v787_5: Space = subtract(&(*CONSTANT_1),&(v787_4));
    drop(v787_4);
    let v787_8: Space = if (v787_5).is_empty() { Space::new() } else {
      let v788_6: Path = concat_path(&(*p0),&(v786_10_head));
      let mut v788_7 = Space::new();
      let mut v788_7_cursor = (v786_10_tail).read_zipper();
      for v788_7_byte in v788_7_cursor.child_mask().iter() {
        v788_7_cursor.descend_to_byte(v788_7_byte);
        {
        let v788_7_tail = v788_7_cursor.fork_read_zipper();
        let v788_7_head = Path::from_slice(&[v788_7_byte]);
        let v789_2: Space = singleton(&(v788_7_head));
        let v789_3: Space = intersect(&(*CONSTANT_2),&(v789_2));
        let v789_4: Space = if has_head(&(v789_3)) { singleton(&[]) } else { Space::new() };
        drop(v789_3);
        let v789_5: Space = subtract(&(*CONSTANT_1),&(v789_4));
        drop(v789_4);
        let mut v789_6 = Space::new();
        let mut v789_6_cursor = (v788_7_tail).read_zipper();
        for v789_6_byte in v789_6_cursor.child_mask().iter() {
          v789_6_cursor.descend_to_byte(v789_6_byte);
          {
          let v789_6_tail = v789_6_cursor.fork_read_zipper();
          let v789_6_head = Path::from_slice(&[v789_6_byte]);
          let v790_2: Space = Space::new();
          v789_6.join_into((v790_2).clone());
          }
          v789_6_cursor.ascend(1);
        }
        drop(v789_6_cursor);
        let v789_7: Space = compose(&(v789_5),&(v789_6));
        drop(v789_5);
        drop(v789_6);
        let v789_8: Space = intersect(&(*CONSTANT_2),&(v789_2));
        drop(v789_2);
        let v789_9: Space = if has_head(&(v789_8)) { singleton(&[]) } else { Space::new() };
        drop(v789_8);
        let v789_12: Space = if (v789_9).is_empty() { Space::new() } else {
          let v791_10: Path = concat_path(&(v788_6),&(v788_7_head));
          let mut v791_11 = Space::new();
          let mut v791_11_cursor = (v788_7_tail).read_zipper();
          for v791_11_byte in v791_11_cursor.child_mask().iter() {
            v791_11_cursor.descend_to_byte(v791_11_byte);
            {
            let v791_11_tail = v791_11_cursor.fork_read_zipper();
            let v791_11_head = Path::from_slice(&[v791_11_byte]);
            let v792_2: Space = singleton(&(v791_11_head));
            let v792_3: Space = intersect(&(*CONSTANT_2),&(v792_2));
            drop(v792_2);
            let v792_4: Space = if has_head(&(v792_3)) { singleton(&[]) } else { Space::new() };
            drop(v792_3);
            let v792_7: Space = if (v792_4).is_empty() { Space::new() } else {
              let v793_5: Path = concat_path(&(v791_10),&(v791_11_head));
              let v793_6: Space = routine_19(c, &(v793_5), &(*p1), &(v791_11_tail).make_space());
              drop(v793_5);
              compose(&(v792_4),&(v793_6))
            };
            drop(v792_4);
            v791_11.join_into((v792_7).clone());
            }
            v791_11_cursor.ascend(1);
          }
          drop(v791_11_cursor);
          drop(v791_10);
          compose(&(v789_9),&(v791_11))
        };
        drop(v789_9);
        let v789_13: Space = unite(&(v789_7),&(v789_12));
        drop(v789_7);
        v788_7.join_into((v789_13).clone());
        }
        v788_7_cursor.ascend(1);
      }
      drop(v788_7_cursor);
      compose(&(v787_5),&(v788_7))
    };
    drop(v787_5);
    let v787_9: Space = intersect(&(*CONSTANT_2),&(v787_2));
    drop(v787_2);
    let v787_10: Space = if has_head(&(v787_9)) { singleton(&[]) } else { Space::new() };
    drop(v787_9);
    let v787_11: Space = compose(&(v787_10),&(v786_10_tail));
    drop(v787_10);
    let v794_6: Path = concat_path(&(*p0),&(v786_10_head));
    let v787_12: Space = wrap(&(v787_11),&(v794_6));
    drop(v787_11);
    let v787_13: Space = wrap(&(v787_12),&(*p1));
    drop(v787_12);
    let v787_14: Space = unite(&(v787_8),&(v787_13));
    drop(v787_13);
    v786_10.join_into((v787_14).clone());
    }
    v786_10_cursor.ascend(1);
  }
  drop(v786_10_cursor);
  (v786_10).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v795_7 = Space::new();
  let mut v795_7_cursor = (*s0).read_zipper();
  for v795_7_byte in v795_7_cursor.child_mask().iter() {
    v795_7_cursor.descend_to_byte(v795_7_byte);
    {
    let v795_7_tail = v795_7_cursor.fork_read_zipper();
    let v795_7_head = Path::from_slice(&[v795_7_byte]);
    let v796_2: Space = singleton(&(v795_7_head));
    let v796_3: Space = intersect(&(*CONSTANT_2),&(v796_2));
    let v796_4: Space = if has_head(&(v796_3)) { singleton(&[]) } else { Space::new() };
    drop(v796_3);
    let v796_5: Space = subtract(&(*CONSTANT_1),&(v796_4));
    drop(v796_4);
    let mut v796_6 = Space::new();
    let mut v796_6_cursor = (v795_7_tail).read_zipper();
    for v796_6_byte in v796_6_cursor.child_mask().iter() {
      v796_6_cursor.descend_to_byte(v796_6_byte);
      {
      let v796_6_tail = v796_6_cursor.fork_read_zipper();
      let v796_6_head = Path::from_slice(&[v796_6_byte]);
      let v797_2: Space = Space::new();
      v796_6.join_into((v797_2).clone());
      }
      v796_6_cursor.ascend(1);
    }
    drop(v796_6_cursor);
    let v796_7: Space = compose(&(v796_5),&(v796_6));
    drop(v796_5);
    drop(v796_6);
    let v796_8: Space = intersect(&(*CONSTANT_2),&(v796_2));
    drop(v796_2);
    let v796_9: Space = if has_head(&(v796_8)) { singleton(&[]) } else { Space::new() };
    drop(v796_8);
    let v796_12: Space = if (v796_9).is_empty() { Space::new() } else {
      let v798_10: Path = concat_path(&(*p0),&(v795_7_head));
      let mut v798_11 = Space::new();
      let mut v798_11_cursor = (v795_7_tail).read_zipper();
      for v798_11_byte in v798_11_cursor.child_mask().iter() {
        v798_11_cursor.descend_to_byte(v798_11_byte);
        {
        let v798_11_tail = v798_11_cursor.fork_read_zipper();
        let v798_11_head = Path::from_slice(&[v798_11_byte]);
        let v799_2: Space = singleton(&(v798_11_head));
        let v799_3: Space = intersect(&(*CONSTANT_2),&(v799_2));
        drop(v799_2);
        let v799_4: Space = if has_head(&(v799_3)) { singleton(&[]) } else { Space::new() };
        drop(v799_3);
        let v799_5: Space = compose(&(v799_4),&(v798_11_tail));
        drop(v799_4);
        let v799_6: Path = concat_path(&(v798_10),&(v798_11_head));
        let v799_7: Space = wrap(&(v799_5),&(v799_6));
        drop(v799_5);
        drop(v799_6);
        v798_11.join_into((v799_7).clone());
        }
        v798_11_cursor.ascend(1);
      }
      drop(v798_11_cursor);
      drop(v798_10);
      compose(&(v796_9),&(v798_11))
    };
    drop(v796_9);
    let v796_13: Space = wrap(&(v796_12),&(*p1));
    drop(v796_12);
    let v796_14: Space = unite(&(v796_7),&(v796_13));
    drop(v796_7);
    drop(v796_13);
    v795_7.join_into((v796_14).clone());
    }
    v795_7_cursor.ascend(1);
  }
  drop(v795_7_cursor);
  (v795_7).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v800_6 = Space::new();
  let mut v800_6_cursor = (*s0).read_zipper();
  for v800_6_byte in v800_6_cursor.child_mask().iter() {
    v800_6_cursor.descend_to_byte(v800_6_byte);
    {
    let v800_6_tail = v800_6_cursor.fork_read_zipper();
    let v800_6_head = Path::from_slice(&[v800_6_byte]);
    let v801_2: Space = singleton(&(v800_6_head));
    let v801_3: Space = intersect(&(*CONSTANT_2),&(v801_2));
    let v801_4: Space = if has_head(&(v801_3)) { singleton(&[]) } else { Space::new() };
    drop(v801_3);
    let v801_5: Space = subtract(&(*CONSTANT_1),&(v801_4));
    drop(v801_4);
    let mut v801_6 = Space::new();
    let mut v801_6_cursor = (v800_6_tail).read_zipper();
    for v801_6_byte in v801_6_cursor.child_mask().iter() {
      v801_6_cursor.descend_to_byte(v801_6_byte);
      {
      let v801_6_tail = v801_6_cursor.fork_read_zipper();
      let v801_6_head = Path::from_slice(&[v801_6_byte]);
      let v802_2: Space = Space::new();
      v801_6.join_into((v802_2).clone());
      }
      v801_6_cursor.ascend(1);
    }
    drop(v801_6_cursor);
    let v801_7: Space = compose(&(v801_5),&(v801_6));
    drop(v801_5);
    drop(v801_6);
    let v801_8: Space = intersect(&(*CONSTANT_2),&(v801_2));
    drop(v801_2);
    let v801_9: Space = if has_head(&(v801_8)) { singleton(&[]) } else { Space::new() };
    drop(v801_8);
    let v801_10: Space = compose(&(v801_9),&(v800_6_tail));
    drop(v801_9);
    let v801_11: Path = concat_path(&(*p0),&(v800_6_head));
    let v801_12: Space = wrap(&(v801_10),&(v801_11));
    drop(v801_10);
    drop(v801_11);
    let v801_13: Space = wrap(&(v801_12),&(*p1));
    drop(v801_12);
    let v801_14: Space = unite(&(v801_7),&(v801_13));
    drop(v801_7);
    drop(v801_13);
    v800_6.join_into((v801_14).clone());
    }
    v800_6_cursor.ascend(1);
  }
  drop(v800_6_cursor);
  (v800_6).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v803_3 = Space::new();
  let mut v803_3_cursor = (*s0).read_zipper();
  for v803_3_byte in v803_3_cursor.child_mask().iter() {
    v803_3_cursor.descend_to_byte(v803_3_byte);
    {
    let v803_3_tail = v803_3_cursor.fork_read_zipper();
    let v803_3_head = Path::from_slice(&[v803_3_byte]);
    let v804_2: Space = Space::new();
    v803_3.join_into((v804_2).clone());
    }
    v803_3_cursor.ascend(1);
  }
  drop(v803_3_cursor);
  (v803_3).clone()
}

fn routine_49(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v805_4 = Space::new();
  let mut v805_4_cursor = (*s0).read_zipper();
  for v805_4_byte in v805_4_cursor.child_mask().iter() {
    v805_4_cursor.descend_to_byte(v805_4_byte);
    {
    let v805_4_tail = v805_4_cursor.fork_read_zipper();
    let v805_4_head = Path::from_slice(&[v805_4_byte]);
    let v806_2: Space = singleton(&(v805_4_head));
    let v806_3: Space = intersect(&(*CONSTANT_2),&(v806_2));
    drop(v806_2);
    let v806_4: Space = if has_head(&(v806_3)) { singleton(&[]) } else { Space::new() };
    drop(v806_3);
    let v806_5: Space = compose(&(v806_4),&(v805_4_tail));
    drop(v806_4);
    let v806_6: Path = concat_path(&(*p0),&(v805_4_head));
    let v806_7: Space = wrap(&(v806_5),&(v806_6));
    drop(v806_5);
    drop(v806_6);
    v805_4.join_into((v806_7).clone());
    }
    v805_4_cursor.ascend(1);
  }
  drop(v805_4_cursor);
  let v805_5: Space = wrap(&(v805_4),&(*p1));
  drop(v805_4);
  (v805_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
