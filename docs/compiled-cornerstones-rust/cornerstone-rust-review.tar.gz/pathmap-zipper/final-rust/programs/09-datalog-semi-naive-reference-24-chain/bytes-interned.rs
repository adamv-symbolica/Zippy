#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,24]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,25]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,6]));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,7]));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,8]));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,9]));
static CONSTANT_12: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,10]));
static CONSTANT_13: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,11]));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,12]));
static CONSTANT_15: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,13]));
static CONSTANT_16: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,14]));
static CONSTANT_17: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,15]));
static CONSTANT_18: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,16]));
static CONSTANT_19: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,17]));
static CONSTANT_20: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,18]));
static CONSTANT_21: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,19]));
static CONSTANT_22: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,20]));
static CONSTANT_23: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,21]));
static CONSTANT_24: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,22]));
static CONSTANT_25: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,23]));
static CONSTANT_26: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,27]));
static CONSTANT_27: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("47 16 0 0 0 28 0 0 0 0 0 0 0 1 0 0 0 2 16 0 0 0 28 0 0 0 0 0 0 0 1 0 0 0 3 16 0 0 0 28 0 0 0 0 0 0 0 2 0 0 0 3 16 0 0 0 28 0 0 0 0 0 0 0 2 0 0 0 4 16 0 0 0 28 0 0 0 0 0 0 0 3 0 0 0 4 16 0 0 0 28 0 0 0 0 0 0 0 3 0 0 0 17 16 0 0 0 28 0 0 0 0 0 0 0 4 0 0 0 17 16 0 0 0 28 0 0 0 0 0 0 0 4 0 0 0 21 16 0 0 0 28 0 0 0 0 0 0 0 5 0 0 0 6 16 0 0 0 28 0 0 0 0 0 0 0 5 0 0 0 7 16 0 0 0 28 0 0 0 0 0 0 0 6 0 0 0 7 16 0 0 0 28 0 0 0 0 0 0 0 6 0 0 0 8 16 0 0 0 28 0 0 0 0 0 0 0 7 0 0 0 8 16 0 0 0 28 0 0 0 0 0 0 0 7 0 0 0 9 16 0 0 0 28 0 0 0 0 0 0 0 8 0 0 0 9 16 0 0 0 28 0 0 0 0 0 0 0 8 0 0 0 10 16 0 0 0 28 0 0 0 0 0 0 0 9 0 0 0 10 16 0 0 0 28 0 0 0 0 0 0 0 9 0 0 0 11 16 0 0 0 28 0 0 0 0 0 0 0 10 0 0 0 11 16 0 0 0 28 0 0 0 0 0 0 0 10 0 0 0 12 16 0 0 0 28 0 0 0 0 0 0 0 11 0 0 0 12 16 0 0 0 28 0 0 0 0 0 0 0 11 0 0 0 13 16 0 0 0 28 0 0 0 0 0 0 0 12 0 0 0 13 16 0 0 0 28 0 0 0 0 0 0 0 12 0 0 0 14 16 0 0 0 28 0 0 0 0 0 0 0 13 0 0 0 14 16 0 0 0 28 0 0 0 0 0 0 0 13 0 0 0 15 16 0 0 0 28 0 0 0 0 0 0 0 14 0 0 0 15 16 0 0 0 28 0 0 0 0 0 0 0 14 0 0 0 16 16 0 0 0 28 0 0 0 0 0 0 0 15 0 0 0 16 16 0 0 0 28 0 0 0 0 0 0 0 15 0 0 0 18 16 0 0 0 28 0 0 0 0 0 0 0 16 0 0 0 18 16 0 0 0 28 0 0 0 0 0 0 0 16 0 0 0 19 16 0 0 0 28 0 0 0 0 0 0 0 17 0 0 0 21 16 0 0 0 28 0 0 0 0 0 0 0 17 0 0 0 22 16 0 0 0 28 0 0 0 0 0 0 0 18 0 0 0 19 16 0 0 0 28 0 0 0 0 0 0 0 18 0 0 0 20 16 0 0 0 28 0 0 0 0 0 0 0 19 0 0 0 20 16 0 0 0 28 0 0 0 0 0 0 0 21 0 0 0 22 16 0 0 0 28 0 0 0 0 0 0 0 21 0 0 0 23 16 0 0 0 28 0 0 0 0 0 0 0 22 0 0 0 23 16 0 0 0 28 0 0 0 0 0 0 0 22 0 0 0 24 16 0 0 0 28 0 0 0 0 0 0 0 23 0 0 0 24 16 0 0 0 28 0 0 0 0 0 0 0 23 0 0 0 25 16 0 0 0 28 0 0 0 0 0 0 0 24 0 0 0 5 16 0 0 0 28 0 0 0 0 0 0 0 24 0 0 0 25 16 0 0 0 28 0 0 0 0 0 0 0 25 0 0 0 5 16 0 0 0 28 0 0 0 0 0 0 0 25 0 0 0 6"));
static CONSTANT_28: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,26]));
static CONSTANT_29: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,28]));
static CONSTANT_30: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_31: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,27,0,0,0,26]));
static CONSTANT_32: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,28,0,0,0,26]));
fn routine_0(c: &mut Context) -> Space {
  let v0_3: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &(*CONSTANT_2));
  let v0_6: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_1), &(*CONSTANT_2));
  let v0_7: Space = unite(&(v0_3),&(v0_6));
  let v0_9: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_0), &(*CONSTANT_2));
  let v0_10: Space = unite(&(v0_7),&(v0_9));
  let v0_13: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_0), &(*CONSTANT_2));
  let v0_14: Space = unite(&(v0_10),&(v0_13));
  let v0_16: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_3), &(*CONSTANT_2));
  let v0_17: Space = unite(&(v0_14),&(v0_16));
  let v0_21: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6), &(*CONSTANT_2));
  let v0_22: Space = unite(&(v0_17),&(v0_21));
  let v0_25: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_7), &(*CONSTANT_2));
  let v0_26: Space = unite(&(v0_22),&(v0_25));
  let v0_29: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_5), &(*CONSTANT_2));
  let v0_30: Space = unite(&(v0_26),&(v0_29));
  let v0_32: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_7), &(*CONSTANT_2));
  let v0_33: Space = unite(&(v0_30),&(v0_32));
  let v0_36: Space = routine_1(c, &(*CONSTANT_9), &(*CONSTANT_5), &(*CONSTANT_2));
  let v0_37: Space = unite(&(v0_33),&(v0_36));
  let v0_39: Space = routine_1(c, &(*CONSTANT_9), &(*CONSTANT_8), &(*CONSTANT_2));
  let v0_40: Space = unite(&(v0_37),&(v0_39));
  let v0_43: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_8), &(*CONSTANT_2));
  let v0_44: Space = unite(&(v0_40),&(v0_43));
  let v0_46: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_9), &(*CONSTANT_2));
  let v0_47: Space = unite(&(v0_44),&(v0_46));
  let v0_50: Space = routine_1(c, &(*CONSTANT_11), &(*CONSTANT_9), &(*CONSTANT_2));
  let v0_51: Space = unite(&(v0_47),&(v0_50));
  let v0_53: Space = routine_1(c, &(*CONSTANT_11), &(*CONSTANT_10), &(*CONSTANT_2));
  let v0_54: Space = unite(&(v0_51),&(v0_53));
  let v0_57: Space = routine_1(c, &(*CONSTANT_12), &(*CONSTANT_10), &(*CONSTANT_2));
  let v0_58: Space = unite(&(v0_54),&(v0_57));
  let v0_60: Space = routine_1(c, &(*CONSTANT_12), &(*CONSTANT_11), &(*CONSTANT_2));
  let v0_61: Space = unite(&(v0_58),&(v0_60));
  let v0_64: Space = routine_1(c, &(*CONSTANT_13), &(*CONSTANT_11), &(*CONSTANT_2));
  let v0_65: Space = unite(&(v0_61),&(v0_64));
  let v0_67: Space = routine_1(c, &(*CONSTANT_13), &(*CONSTANT_12), &(*CONSTANT_2));
  let v0_68: Space = unite(&(v0_65),&(v0_67));
  let v0_71: Space = routine_1(c, &(*CONSTANT_14), &(*CONSTANT_12), &(*CONSTANT_2));
  let v0_72: Space = unite(&(v0_68),&(v0_71));
  let v0_74: Space = routine_1(c, &(*CONSTANT_14), &(*CONSTANT_13), &(*CONSTANT_2));
  let v0_75: Space = unite(&(v0_72),&(v0_74));
  let v0_78: Space = routine_1(c, &(*CONSTANT_15), &(*CONSTANT_13), &(*CONSTANT_2));
  let v0_79: Space = unite(&(v0_75),&(v0_78));
  let v0_81: Space = routine_1(c, &(*CONSTANT_15), &(*CONSTANT_14), &(*CONSTANT_2));
  let v0_82: Space = unite(&(v0_79),&(v0_81));
  let v0_85: Space = routine_1(c, &(*CONSTANT_16), &(*CONSTANT_14), &(*CONSTANT_2));
  let v0_86: Space = unite(&(v0_82),&(v0_85));
  let v0_88: Space = routine_1(c, &(*CONSTANT_16), &(*CONSTANT_15), &(*CONSTANT_2));
  let v0_89: Space = unite(&(v0_86),&(v0_88));
  let v0_92: Space = routine_1(c, &(*CONSTANT_17), &(*CONSTANT_15), &(*CONSTANT_2));
  let v0_93: Space = unite(&(v0_89),&(v0_92));
  let v0_95: Space = routine_1(c, &(*CONSTANT_17), &(*CONSTANT_16), &(*CONSTANT_2));
  let v0_96: Space = unite(&(v0_93),&(v0_95));
  let v0_99: Space = routine_1(c, &(*CONSTANT_18), &(*CONSTANT_16), &(*CONSTANT_2));
  let v0_100: Space = unite(&(v0_96),&(v0_99));
  let v0_102: Space = routine_1(c, &(*CONSTANT_18), &(*CONSTANT_17), &(*CONSTANT_2));
  let v0_103: Space = unite(&(v0_100),&(v0_102));
  let v0_106: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_3), &(*CONSTANT_2));
  let v0_107: Space = unite(&(v0_103),&(v0_106));
  let v0_109: Space = routine_1(c, &(*CONSTANT_19), &(*CONSTANT_4), &(*CONSTANT_2));
  let v0_110: Space = unite(&(v0_107),&(v0_109));
  let v0_113: Space = routine_1(c, &(*CONSTANT_20), &(*CONSTANT_17), &(*CONSTANT_2));
  let v0_114: Space = unite(&(v0_110),&(v0_113));
  let v0_116: Space = routine_1(c, &(*CONSTANT_20), &(*CONSTANT_18), &(*CONSTANT_2));
  let v0_117: Space = unite(&(v0_114),&(v0_116));
  let v0_120: Space = routine_1(c, &(*CONSTANT_21), &(*CONSTANT_18), &(*CONSTANT_2));
  let v0_121: Space = unite(&(v0_117),&(v0_120));
  let v0_123: Space = routine_1(c, &(*CONSTANT_21), &(*CONSTANT_20), &(*CONSTANT_2));
  let v0_124: Space = unite(&(v0_121),&(v0_123));
  let v0_127: Space = routine_1(c, &(*CONSTANT_22), &(*CONSTANT_20), &(*CONSTANT_2));
  let v0_128: Space = unite(&(v0_124),&(v0_127));
  let v0_130: Space = routine_1(c, &(*CONSTANT_22), &(*CONSTANT_21), &(*CONSTANT_2));
  let v0_131: Space = unite(&(v0_128),&(v0_130));
  let v0_134: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_4), &(*CONSTANT_2));
  let v0_135: Space = unite(&(v0_131),&(v0_134));
  let v0_137: Space = routine_1(c, &(*CONSTANT_23), &(*CONSTANT_19), &(*CONSTANT_2));
  let v0_138: Space = unite(&(v0_135),&(v0_137));
  let v0_141: Space = routine_1(c, &(*CONSTANT_24), &(*CONSTANT_19), &(*CONSTANT_2));
  let v0_142: Space = unite(&(v0_138),&(v0_141));
  let v0_144: Space = routine_1(c, &(*CONSTANT_24), &(*CONSTANT_23), &(*CONSTANT_2));
  let v0_145: Space = unite(&(v0_142),&(v0_144));
  let v0_148: Space = routine_1(c, &(*CONSTANT_25), &(*CONSTANT_23), &(*CONSTANT_2));
  let v0_149: Space = unite(&(v0_145),&(v0_148));
  let v0_151: Space = routine_1(c, &(*CONSTANT_25), &(*CONSTANT_24), &(*CONSTANT_2));
  let v0_152: Space = unite(&(v0_149),&(v0_151));
  let v0_154: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_24), &(*CONSTANT_2));
  let v0_155: Space = unite(&(v0_152),&(v0_154));
  let v0_157: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_25), &(*CONSTANT_2));
  let v0_158: Space = unite(&(v0_155),&(v0_157));
  let v0_160: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_25), &(*CONSTANT_2));
  let v0_161: Space = unite(&(v0_158),&(v0_160));
  let v0_163: Space = routine_1(c, &(*CONSTANT_7), &(*CONSTANT_6), &(*CONSTANT_2));
  let v0_164: Space = unite(&(v0_161),&(v0_163));
  let v0_166: Space = wrap(&(v0_164),&(*CONSTANT_26));
  let v0_168: Space = unite(&(v0_166),&(*CONSTANT_27));
  let mut v0_174: Space = (v0_168).clone();
  loop {
    let v1_1: Space = unwrap(&(v0_174),&(*CONSTANT_26));
    let v1_2: Space = unwrap(&(v1_1),&(*CONSTANT_28));
    let mut v1_3 = Space::new();
    let mut v1_3_cursor = (v1_2).read_zipper();
    for v1_3_byte in v1_3_cursor.child_mask().iter() {
      v1_3_cursor.descend_to_byte(v1_3_byte);
      {
      let v1_3_tail = v1_3_cursor.fork_read_zipper();
      let v1_3_head = Path::from_slice(&[v1_3_byte]);
      let mut v2_2 = Space::new();
      let mut v2_2_cursor = (v1_3_tail).read_zipper();
      for v2_2_byte in v2_2_cursor.child_mask().iter() {
        v2_2_cursor.descend_to_byte(v2_2_byte);
        {
        let v2_2_tail = v2_2_cursor.fork_read_zipper();
        let v2_2_head = Path::from_slice(&[v2_2_byte]);
        let v3_2: Path = concat_path(&(v1_3_head),&(v2_2_head));
        let mut v3_3 = Space::new();
        let mut v3_3_cursor = (v2_2_tail).read_zipper();
        for v3_3_byte in v3_3_cursor.child_mask().iter() {
          v3_3_cursor.descend_to_byte(v3_3_byte);
          {
          let v3_3_tail = v3_3_cursor.fork_read_zipper();
          let v3_3_head = Path::from_slice(&[v3_3_byte]);
          let v4_2: Path = concat_path(&(v3_2),&(v3_3_head));
          let mut v4_3 = Space::new();
          let mut v4_3_cursor = (v3_3_tail).read_zipper();
          for v4_3_byte in v4_3_cursor.child_mask().iter() {
            v4_3_cursor.descend_to_byte(v4_3_byte);
            {
            let v4_3_tail = v4_3_cursor.fork_read_zipper();
            let v4_3_head = Path::from_slice(&[v4_3_byte]);
            let v5_2: Path = concat_path(&(v4_2),&(v4_3_head));
            let mut v5_3 = Space::new();
            let mut v5_3_cursor = (v4_3_tail).read_zipper();
            for v5_3_byte in v5_3_cursor.child_mask().iter() {
              v5_3_cursor.descend_to_byte(v5_3_byte);
              {
              let v5_3_tail = v5_3_cursor.fork_read_zipper();
              let v5_3_head = Path::from_slice(&[v5_3_byte]);
              let mut v6_2 = Space::new();
              let mut v6_2_cursor = (v5_3_tail).read_zipper();
              for v6_2_byte in v6_2_cursor.child_mask().iter() {
                v6_2_cursor.descend_to_byte(v6_2_byte);
                {
                let v6_2_tail = v6_2_cursor.fork_read_zipper();
                let v6_2_head = Path::from_slice(&[v6_2_byte]);
                let v7_2: Path = concat_path(&(v5_3_head),&(v6_2_head));
                let mut v7_3 = Space::new();
                let mut v7_3_cursor = (v6_2_tail).read_zipper();
                for v7_3_byte in v7_3_cursor.child_mask().iter() {
                  v7_3_cursor.descend_to_byte(v7_3_byte);
                  {
                  let v7_3_tail = v7_3_cursor.fork_read_zipper();
                  let v7_3_head = Path::from_slice(&[v7_3_byte]);
                  let v8_2: Path = concat_path(&(v7_2),&(v7_3_head));
                  let mut v8_3 = Space::new();
                  let mut v8_3_cursor = (v7_3_tail).read_zipper();
                  for v8_3_byte in v8_3_cursor.child_mask().iter() {
                    v8_3_cursor.descend_to_byte(v8_3_byte);
                    {
                    let v8_3_tail = v8_3_cursor.fork_read_zipper();
                    let v8_3_head = Path::from_slice(&[v8_3_byte]);
                    let v9_2: Path = concat_path(&(v8_2),&(v8_3_head));
                    let v9_3: Space = routine_2(c, &(v9_2), &(v5_2), &(v8_3_tail).make_space(), &(v0_174));
                    drop(v9_2);
                    v8_3.join_into((v9_3).clone());
                    }
                    v8_3_cursor.ascend(1);
                  }
                  drop(v8_3_cursor);
                  drop(v8_2);
                  v7_3.join_into((v8_3).clone());
                  }
                  v7_3_cursor.ascend(1);
                }
                drop(v7_3_cursor);
                drop(v7_2);
                v6_2.join_into((v7_3).clone());
                }
                v6_2_cursor.ascend(1);
              }
              drop(v6_2_cursor);
              v5_3.join_into((v6_2).clone());
              }
              v5_3_cursor.ascend(1);
            }
            drop(v5_3_cursor);
            drop(v5_2);
            v4_3.join_into((v5_3).clone());
            }
            v4_3_cursor.ascend(1);
          }
          drop(v4_3_cursor);
          drop(v4_2);
          v3_3.join_into((v4_3).clone());
          }
          v3_3_cursor.ascend(1);
        }
        drop(v3_3_cursor);
        drop(v3_2);
        v2_2.join_into((v3_3).clone());
        }
        v2_2_cursor.ascend(1);
      }
      drop(v2_2_cursor);
      v1_3.join_into((v2_2).clone());
      }
      v1_3_cursor.ascend(1);
    }
    drop(v1_3_cursor);
    let mut v1_4 = Space::new();
    let mut v1_4_cursor = (v1_2).read_zipper();
    for v1_4_byte in v1_4_cursor.child_mask().iter() {
      v1_4_cursor.descend_to_byte(v1_4_byte);
      {
      let v1_4_tail = v1_4_cursor.fork_read_zipper();
      let v1_4_head = Path::from_slice(&[v1_4_byte]);
      let mut v10_2 = Space::new();
      let mut v10_2_cursor = (v1_4_tail).read_zipper();
      for v10_2_byte in v10_2_cursor.child_mask().iter() {
        v10_2_cursor.descend_to_byte(v10_2_byte);
        {
        let v10_2_tail = v10_2_cursor.fork_read_zipper();
        let v10_2_head = Path::from_slice(&[v10_2_byte]);
        let v11_2: Path = concat_path(&(v1_4_head),&(v10_2_head));
        let mut v11_3 = Space::new();
        let mut v11_3_cursor = (v10_2_tail).read_zipper();
        for v11_3_byte in v11_3_cursor.child_mask().iter() {
          v11_3_cursor.descend_to_byte(v11_3_byte);
          {
          let v11_3_tail = v11_3_cursor.fork_read_zipper();
          let v11_3_head = Path::from_slice(&[v11_3_byte]);
          let v12_2: Path = concat_path(&(v11_2),&(v11_3_head));
          let mut v12_3 = Space::new();
          let mut v12_3_cursor = (v11_3_tail).read_zipper();
          for v12_3_byte in v12_3_cursor.child_mask().iter() {
            v12_3_cursor.descend_to_byte(v12_3_byte);
            {
            let v12_3_tail = v12_3_cursor.fork_read_zipper();
            let v12_3_head = Path::from_slice(&[v12_3_byte]);
            let v13_2: Path = concat_path(&(v12_2),&(v12_3_head));
            let mut v13_3 = Space::new();
            let mut v13_3_cursor = (v12_3_tail).read_zipper();
            for v13_3_byte in v13_3_cursor.child_mask().iter() {
              v13_3_cursor.descend_to_byte(v13_3_byte);
              {
              let v13_3_tail = v13_3_cursor.fork_read_zipper();
              let v13_3_head = Path::from_slice(&[v13_3_byte]);
              let mut v14_2 = Space::new();
              let mut v14_2_cursor = (v13_3_tail).read_zipper();
              for v14_2_byte in v14_2_cursor.child_mask().iter() {
                v14_2_cursor.descend_to_byte(v14_2_byte);
                {
                let v14_2_tail = v14_2_cursor.fork_read_zipper();
                let v14_2_head = Path::from_slice(&[v14_2_byte]);
                let v15_2: Path = concat_path(&(v13_3_head),&(v14_2_head));
                let mut v15_3 = Space::new();
                let mut v15_3_cursor = (v14_2_tail).read_zipper();
                for v15_3_byte in v15_3_cursor.child_mask().iter() {
                  v15_3_cursor.descend_to_byte(v15_3_byte);
                  {
                  let v15_3_tail = v15_3_cursor.fork_read_zipper();
                  let v15_3_head = Path::from_slice(&[v15_3_byte]);
                  let v16_2: Path = concat_path(&(v15_2),&(v15_3_head));
                  let mut v16_3 = Space::new();
                  let mut v16_3_cursor = (v15_3_tail).read_zipper();
                  for v16_3_byte in v16_3_cursor.child_mask().iter() {
                    v16_3_cursor.descend_to_byte(v16_3_byte);
                    {
                    let v16_3_tail = v16_3_cursor.fork_read_zipper();
                    let v16_3_head = Path::from_slice(&[v16_3_byte]);
                    let v17_2: Path = concat_path(&(v16_2),&(v16_3_head));
                    let v17_3: Space = routine_3(c, &(v17_2), &(v13_2), &(v16_3_tail).make_space(), &(v0_174));
                    drop(v17_2);
                    v16_3.join_into((v17_3).clone());
                    }
                    v16_3_cursor.ascend(1);
                  }
                  drop(v16_3_cursor);
                  drop(v16_2);
                  v15_3.join_into((v16_3).clone());
                  }
                  v15_3_cursor.ascend(1);
                }
                drop(v15_3_cursor);
                drop(v15_2);
                v14_2.join_into((v15_3).clone());
                }
                v14_2_cursor.ascend(1);
              }
              drop(v14_2_cursor);
              v13_3.join_into((v14_2).clone());
              }
              v13_3_cursor.ascend(1);
            }
            drop(v13_3_cursor);
            drop(v13_2);
            v12_3.join_into((v13_3).clone());
            }
            v12_3_cursor.ascend(1);
          }
          drop(v12_3_cursor);
          drop(v12_2);
          v11_3.join_into((v12_3).clone());
          }
          v11_3_cursor.ascend(1);
        }
        drop(v11_3_cursor);
        drop(v11_2);
        v10_2.join_into((v11_3).clone());
        }
        v10_2_cursor.ascend(1);
      }
      drop(v10_2_cursor);
      v1_4.join_into((v10_2).clone());
      }
      v1_4_cursor.ascend(1);
    }
    drop(v1_4_cursor);
    drop(v1_2);
    let v1_5: Space = unite(&(v1_3),&(v1_4));
    let v1_6: Space = unwrap(&(v0_174),&(*CONSTANT_29));
    let v1_7: Space = unwrap(&(v1_6),&(*CONSTANT_30));
    let mut v1_8 = Space::new();
    let mut v1_8_cursor = (v1_7).read_zipper();
    for v1_8_byte in v1_8_cursor.child_mask().iter() {
      v1_8_cursor.descend_to_byte(v1_8_byte);
      {
      let v1_8_tail = v1_8_cursor.fork_read_zipper();
      let v1_8_head = Path::from_slice(&[v1_8_byte]);
      let mut v18_2 = Space::new();
      let mut v18_2_cursor = (v1_8_tail).read_zipper();
      for v18_2_byte in v18_2_cursor.child_mask().iter() {
        v18_2_cursor.descend_to_byte(v18_2_byte);
        {
        let v18_2_tail = v18_2_cursor.fork_read_zipper();
        let v18_2_head = Path::from_slice(&[v18_2_byte]);
        let v19_2: Path = concat_path(&(v1_8_head),&(v18_2_head));
        let mut v19_3 = Space::new();
        let mut v19_3_cursor = (v18_2_tail).read_zipper();
        for v19_3_byte in v19_3_cursor.child_mask().iter() {
          v19_3_cursor.descend_to_byte(v19_3_byte);
          {
          let v19_3_tail = v19_3_cursor.fork_read_zipper();
          let v19_3_head = Path::from_slice(&[v19_3_byte]);
          let v20_2: Path = concat_path(&(v19_2),&(v19_3_head));
          let mut v20_3 = Space::new();
          let mut v20_3_cursor = (v19_3_tail).read_zipper();
          for v20_3_byte in v20_3_cursor.child_mask().iter() {
            v20_3_cursor.descend_to_byte(v20_3_byte);
            {
            let v20_3_tail = v20_3_cursor.fork_read_zipper();
            let v20_3_head = Path::from_slice(&[v20_3_byte]);
            let v21_2: Path = concat_path(&(v20_2),&(v20_3_head));
            let mut v21_3 = Space::new();
            let mut v21_3_cursor = (v20_3_tail).read_zipper();
            for v21_3_byte in v21_3_cursor.child_mask().iter() {
              v21_3_cursor.descend_to_byte(v21_3_byte);
              {
              let v21_3_tail = v21_3_cursor.fork_read_zipper();
              let v21_3_head = Path::from_slice(&[v21_3_byte]);
              let mut v22_2 = Space::new();
              let mut v22_2_cursor = (v21_3_tail).read_zipper();
              for v22_2_byte in v22_2_cursor.child_mask().iter() {
                v22_2_cursor.descend_to_byte(v22_2_byte);
                {
                let v22_2_tail = v22_2_cursor.fork_read_zipper();
                let v22_2_head = Path::from_slice(&[v22_2_byte]);
                let v23_2: Path = concat_path(&(v21_3_head),&(v22_2_head));
                let mut v23_3 = Space::new();
                let mut v23_3_cursor = (v22_2_tail).read_zipper();
                for v23_3_byte in v23_3_cursor.child_mask().iter() {
                  v23_3_cursor.descend_to_byte(v23_3_byte);
                  {
                  let v23_3_tail = v23_3_cursor.fork_read_zipper();
                  let v23_3_head = Path::from_slice(&[v23_3_byte]);
                  let v24_2: Path = concat_path(&(v23_2),&(v23_3_head));
                  let mut v24_3 = Space::new();
                  let mut v24_3_cursor = (v23_3_tail).read_zipper();
                  for v24_3_byte in v24_3_cursor.child_mask().iter() {
                    v24_3_cursor.descend_to_byte(v24_3_byte);
                    {
                    let v24_3_tail = v24_3_cursor.fork_read_zipper();
                    let v24_3_head = Path::from_slice(&[v24_3_byte]);
                    let v25_2: Path = concat_path(&(v24_2),&(v24_3_head));
                    let v25_3: Space = routine_4(c, &(v25_2), &(v21_2), &(v24_3_tail).make_space());
                    drop(v25_2);
                    v24_3.join_into((v25_3).clone());
                    }
                    v24_3_cursor.ascend(1);
                  }
                  drop(v24_3_cursor);
                  drop(v24_2);
                  v23_3.join_into((v24_3).clone());
                  }
                  v23_3_cursor.ascend(1);
                }
                drop(v23_3_cursor);
                drop(v23_2);
                v22_2.join_into((v23_3).clone());
                }
                v22_2_cursor.ascend(1);
              }
              drop(v22_2_cursor);
              v21_3.join_into((v22_2).clone());
              }
              v21_3_cursor.ascend(1);
            }
            drop(v21_3_cursor);
            drop(v21_2);
            v20_3.join_into((v21_3).clone());
            }
            v20_3_cursor.ascend(1);
          }
          drop(v20_3_cursor);
          drop(v20_2);
          v19_3.join_into((v20_3).clone());
          }
          v19_3_cursor.ascend(1);
        }
        drop(v19_3_cursor);
        drop(v19_2);
        v18_2.join_into((v19_3).clone());
        }
        v18_2_cursor.ascend(1);
      }
      drop(v18_2_cursor);
      v1_8.join_into((v18_2).clone());
      }
      v1_8_cursor.ascend(1);
    }
    drop(v1_8_cursor);
    drop(v1_7);
    let v1_9: Space = unite(&(v1_5),&(v1_8));
    let v1_10: Space = unwrap(&(v1_6),&(*CONSTANT_28));
    let mut v1_11 = Space::new();
    let mut v1_11_cursor = (v1_10).read_zipper();
    for v1_11_byte in v1_11_cursor.child_mask().iter() {
      v1_11_cursor.descend_to_byte(v1_11_byte);
      {
      let v1_11_tail = v1_11_cursor.fork_read_zipper();
      let v1_11_head = Path::from_slice(&[v1_11_byte]);
      let mut v26_2 = Space::new();
      let mut v26_2_cursor = (v1_11_tail).read_zipper();
      for v26_2_byte in v26_2_cursor.child_mask().iter() {
        v26_2_cursor.descend_to_byte(v26_2_byte);
        {
        let v26_2_tail = v26_2_cursor.fork_read_zipper();
        let v26_2_head = Path::from_slice(&[v26_2_byte]);
        let v27_2: Path = concat_path(&(v1_11_head),&(v26_2_head));
        let mut v27_3 = Space::new();
        let mut v27_3_cursor = (v26_2_tail).read_zipper();
        for v27_3_byte in v27_3_cursor.child_mask().iter() {
          v27_3_cursor.descend_to_byte(v27_3_byte);
          {
          let v27_3_tail = v27_3_cursor.fork_read_zipper();
          let v27_3_head = Path::from_slice(&[v27_3_byte]);
          let v28_2: Path = concat_path(&(v27_2),&(v27_3_head));
          let mut v28_3 = Space::new();
          let mut v28_3_cursor = (v27_3_tail).read_zipper();
          for v28_3_byte in v28_3_cursor.child_mask().iter() {
            v28_3_cursor.descend_to_byte(v28_3_byte);
            {
            let v28_3_tail = v28_3_cursor.fork_read_zipper();
            let v28_3_head = Path::from_slice(&[v28_3_byte]);
            let v29_2: Path = concat_path(&(v28_2),&(v28_3_head));
            let mut v29_3 = Space::new();
            let mut v29_3_cursor = (v28_3_tail).read_zipper();
            for v29_3_byte in v29_3_cursor.child_mask().iter() {
              v29_3_cursor.descend_to_byte(v29_3_byte);
              {
              let v29_3_tail = v29_3_cursor.fork_read_zipper();
              let v29_3_head = Path::from_slice(&[v29_3_byte]);
              let mut v30_2 = Space::new();
              let mut v30_2_cursor = (v29_3_tail).read_zipper();
              for v30_2_byte in v30_2_cursor.child_mask().iter() {
                v30_2_cursor.descend_to_byte(v30_2_byte);
                {
                let v30_2_tail = v30_2_cursor.fork_read_zipper();
                let v30_2_head = Path::from_slice(&[v30_2_byte]);
                let v31_2: Path = concat_path(&(v29_3_head),&(v30_2_head));
                let mut v31_3 = Space::new();
                let mut v31_3_cursor = (v30_2_tail).read_zipper();
                for v31_3_byte in v31_3_cursor.child_mask().iter() {
                  v31_3_cursor.descend_to_byte(v31_3_byte);
                  {
                  let v31_3_tail = v31_3_cursor.fork_read_zipper();
                  let v31_3_head = Path::from_slice(&[v31_3_byte]);
                  let v32_2: Path = concat_path(&(v31_2),&(v31_3_head));
                  let mut v32_3 = Space::new();
                  let mut v32_3_cursor = (v31_3_tail).read_zipper();
                  for v32_3_byte in v32_3_cursor.child_mask().iter() {
                    v32_3_cursor.descend_to_byte(v32_3_byte);
                    {
                    let v32_3_tail = v32_3_cursor.fork_read_zipper();
                    let v32_3_head = Path::from_slice(&[v32_3_byte]);
                    let v33_2: Path = concat_path(&(v32_2),&(v32_3_head));
                    let v33_3: Space = routine_5(c, &(v33_2), &(v29_2), &(v32_3_tail).make_space(), &(v0_174));
                    drop(v33_2);
                    v32_3.join_into((v33_3).clone());
                    }
                    v32_3_cursor.ascend(1);
                  }
                  drop(v32_3_cursor);
                  drop(v32_2);
                  v31_3.join_into((v32_3).clone());
                  }
                  v31_3_cursor.ascend(1);
                }
                drop(v31_3_cursor);
                drop(v31_2);
                v30_2.join_into((v31_3).clone());
                }
                v30_2_cursor.ascend(1);
              }
              drop(v30_2_cursor);
              v29_3.join_into((v30_2).clone());
              }
              v29_3_cursor.ascend(1);
            }
            drop(v29_3_cursor);
            drop(v29_2);
            v28_3.join_into((v29_3).clone());
            }
            v28_3_cursor.ascend(1);
          }
          drop(v28_3_cursor);
          drop(v28_2);
          v27_3.join_into((v28_3).clone());
          }
          v27_3_cursor.ascend(1);
        }
        drop(v27_3_cursor);
        drop(v27_2);
        v26_2.join_into((v27_3).clone());
        }
        v26_2_cursor.ascend(1);
      }
      drop(v26_2_cursor);
      v1_11.join_into((v26_2).clone());
      }
      v1_11_cursor.ascend(1);
    }
    drop(v1_11_cursor);
    drop(v1_10);
    let v1_12: Space = unite(&(v1_9),&(v1_11));
    let v1_13: Space = unwrap(&(v0_174),&(*CONSTANT_31));
    let v1_14: Space = subtract(&(v1_12),&(v1_13));
    drop(v1_13);
    let v1_15: Space = unwrap(&(v0_174),&(*CONSTANT_32));
    let v1_16: Space = subtract(&(v1_14),&(v1_15));
    drop(v1_15);
    let v1_17: Space = wrap(&(v1_16),&(*CONSTANT_31));
    let v1_18: Space = unite(&(v1_1),&(v1_6));
    drop(v1_1);
    drop(v1_6);
    let v1_19: Space = wrap(&(v1_18),&(*CONSTANT_29));
    drop(v1_18);
    let v1_20: Space = unite(&(v1_17),&(v1_19));
    drop(v1_19);
    let v1_21: Space = unite(&(v1_20),&(v0_174));
    if !v0_174.join_into((v1_21).clone()).is_element() { break; }
  }
  let v0_175: Space = unwrap(&(v0_174),&(*CONSTANT_32));
  (v0_175).clone()
}

fn routine_1(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v34_3: Space = wrap(&(*s0),&(*p0));
  let v34_4: Space = wrap(&(v34_3),&(*p1));
  drop(v34_3);
  let v34_6: Space = wrap(&(v34_4),&(*CONSTANT_28));
  drop(v34_4);
  (v34_6).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v35_5: Space = unwrap(&(*s1),&(*CONSTANT_29));
  let v35_7: Space = unwrap(&(v35_5),&(*CONSTANT_28));
  drop(v35_5);
  let v35_8: Space = unwrap(&(v35_7),&(*p0));
  drop(v35_7);
  let mut v35_10 = Space::new();
  let mut v35_10_cursor = (v35_8).read_zipper();
  for v35_10_byte in v35_10_cursor.child_mask().iter() {
    v35_10_cursor.descend_to_byte(v35_10_byte);
    {
    let v35_10_tail = v35_10_cursor.fork_read_zipper();
    let v35_10_head = Path::from_slice(&[v35_10_byte]);
    let mut v36_2 = Space::new();
    let mut v36_2_cursor = (v35_10_tail).read_zipper();
    for v36_2_byte in v36_2_cursor.child_mask().iter() {
      v36_2_cursor.descend_to_byte(v36_2_byte);
      {
      let v36_2_tail = v36_2_cursor.fork_read_zipper();
      let v36_2_head = Path::from_slice(&[v36_2_byte]);
      let v37_2: Path = concat_path(&(v35_10_head),&(v36_2_head));
      let mut v37_3 = Space::new();
      let mut v37_3_cursor = (v36_2_tail).read_zipper();
      for v37_3_byte in v37_3_cursor.child_mask().iter() {
        v37_3_cursor.descend_to_byte(v37_3_byte);
        {
        let v37_3_tail = v37_3_cursor.fork_read_zipper();
        let v37_3_head = Path::from_slice(&[v37_3_byte]);
        let v38_2: Space = subtract(&(v37_3_tail),&(*CONSTANT_2));
        let v38_3: Path = concat_path(&(v37_2),&(v37_3_head));
        let v38_4: Space = wrap(&(v38_2),&(v38_3));
        drop(v38_2);
        drop(v38_3);
        v37_3.join_into((v38_4).clone());
        }
        v37_3_cursor.ascend(1);
      }
      drop(v37_3_cursor);
      drop(v37_2);
      v36_2.join_into((v37_3).clone());
      }
      v36_2_cursor.ascend(1);
    }
    drop(v36_2_cursor);
    v35_10.join_into((v36_2).clone());
    }
    v35_10_cursor.ascend(1);
  }
  drop(v35_10_cursor);
  drop(v35_8);
  let v35_11: Space = wrap(&(v35_10),&(*p1));
  drop(v35_10);
  (v35_11).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v39_5: Space = unwrap(&(*s1),&(*CONSTANT_26));
  let v39_7: Space = unwrap(&(v39_5),&(*CONSTANT_28));
  drop(v39_5);
  let v39_8: Space = unwrap(&(v39_7),&(*p0));
  drop(v39_7);
  let mut v39_10 = Space::new();
  let mut v39_10_cursor = (v39_8).read_zipper();
  for v39_10_byte in v39_10_cursor.child_mask().iter() {
    v39_10_cursor.descend_to_byte(v39_10_byte);
    {
    let v39_10_tail = v39_10_cursor.fork_read_zipper();
    let v39_10_head = Path::from_slice(&[v39_10_byte]);
    let mut v40_2 = Space::new();
    let mut v40_2_cursor = (v39_10_tail).read_zipper();
    for v40_2_byte in v40_2_cursor.child_mask().iter() {
      v40_2_cursor.descend_to_byte(v40_2_byte);
      {
      let v40_2_tail = v40_2_cursor.fork_read_zipper();
      let v40_2_head = Path::from_slice(&[v40_2_byte]);
      let v41_2: Path = concat_path(&(v39_10_head),&(v40_2_head));
      let mut v41_3 = Space::new();
      let mut v41_3_cursor = (v40_2_tail).read_zipper();
      for v41_3_byte in v41_3_cursor.child_mask().iter() {
        v41_3_cursor.descend_to_byte(v41_3_byte);
        {
        let v41_3_tail = v41_3_cursor.fork_read_zipper();
        let v41_3_head = Path::from_slice(&[v41_3_byte]);
        let v42_2: Space = subtract(&(v41_3_tail),&(*CONSTANT_2));
        let v42_3: Path = concat_path(&(v41_2),&(v41_3_head));
        let v42_4: Space = wrap(&(v42_2),&(v42_3));
        drop(v42_2);
        drop(v42_3);
        v41_3.join_into((v42_4).clone());
        }
        v41_3_cursor.ascend(1);
      }
      drop(v41_3_cursor);
      drop(v41_2);
      v40_2.join_into((v41_3).clone());
      }
      v40_2_cursor.ascend(1);
    }
    drop(v40_2_cursor);
    v39_10.join_into((v40_2).clone());
    }
    v39_10_cursor.ascend(1);
  }
  drop(v39_10_cursor);
  drop(v39_8);
  let v39_11: Space = wrap(&(v39_10),&(*p1));
  drop(v39_10);
  (v39_11).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v43_3: Space = wrap(&(*s0),&(*p0));
  let v43_4: Space = wrap(&(v43_3),&(*p1));
  drop(v43_3);
  (v43_4).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v44_5: Space = unwrap(&(*s1),&(*CONSTANT_26));
  let v44_7: Space = unwrap(&(v44_5),&(*CONSTANT_28));
  drop(v44_5);
  let v44_8: Space = unwrap(&(v44_7),&(*p0));
  drop(v44_7);
  let mut v44_10 = Space::new();
  let mut v44_10_cursor = (v44_8).read_zipper();
  for v44_10_byte in v44_10_cursor.child_mask().iter() {
    v44_10_cursor.descend_to_byte(v44_10_byte);
    {
    let v44_10_tail = v44_10_cursor.fork_read_zipper();
    let v44_10_head = Path::from_slice(&[v44_10_byte]);
    let mut v45_2 = Space::new();
    let mut v45_2_cursor = (v44_10_tail).read_zipper();
    for v45_2_byte in v45_2_cursor.child_mask().iter() {
      v45_2_cursor.descend_to_byte(v45_2_byte);
      {
      let v45_2_tail = v45_2_cursor.fork_read_zipper();
      let v45_2_head = Path::from_slice(&[v45_2_byte]);
      let v46_2: Path = concat_path(&(v44_10_head),&(v45_2_head));
      let mut v46_3 = Space::new();
      let mut v46_3_cursor = (v45_2_tail).read_zipper();
      for v46_3_byte in v46_3_cursor.child_mask().iter() {
        v46_3_cursor.descend_to_byte(v46_3_byte);
        {
        let v46_3_tail = v46_3_cursor.fork_read_zipper();
        let v46_3_head = Path::from_slice(&[v46_3_byte]);
        let v47_2: Space = subtract(&(v46_3_tail),&(*CONSTANT_2));
        let v47_3: Path = concat_path(&(v46_2),&(v46_3_head));
        let v47_4: Space = wrap(&(v47_2),&(v47_3));
        drop(v47_2);
        drop(v47_3);
        v46_3.join_into((v47_4).clone());
        }
        v46_3_cursor.ascend(1);
      }
      drop(v46_3_cursor);
      drop(v46_2);
      v45_2.join_into((v46_3).clone());
      }
      v45_2_cursor.ascend(1);
    }
    drop(v45_2_cursor);
    v44_10.join_into((v45_2).clone());
    }
    v44_10_cursor.ascend(1);
  }
  drop(v44_10_cursor);
  drop(v44_8);
  let v44_11: Space = wrap(&(v44_10),&(*p1));
  drop(v44_10);
  (v44_11).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
