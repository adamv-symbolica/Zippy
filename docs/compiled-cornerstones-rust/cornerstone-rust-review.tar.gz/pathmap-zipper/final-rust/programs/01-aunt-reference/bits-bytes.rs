#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_11 = Space::new();
  let mut v0_11_cursor = (*s1.expect("unbound native input")).read_zipper();
  for v0_11_byte in v0_11_cursor.child_mask().iter() {
    v0_11_cursor.descend_to_byte(v0_11_byte);
    {
    let v0_11_tail = v0_11_cursor.fork_read_zipper();
    let v0_11_head = Path::from_slice(&[v0_11_byte]);
    let v1_2: Space = singleton(&(v0_11_head));
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_11_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_11_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail).make_space(), &(*s0.expect("unbound native input")));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_11_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail).make_space(), &(*s0.expect("unbound native input")));
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_11_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        {
        let v6_10_tail = v6_10_cursor.fork_read_zipper();
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_11_head),&(v6_10_head));
          let v8_7: Space = routine_1(c, &(v8_6), &(v6_10_tail).make_space(), &(*s0.expect("unbound native input")));
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_11_head),&(v6_10_head));
          let v9_11: Space = routine_3(c, &(v9_6), &(v6_10_tail).make_space(), &(*s0.expect("unbound native input")));
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_10.join_into((v7_13).clone());
        }
        v6_10_cursor.ascend(1);
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_11.join_into((v1_12).clone());
    }
    v0_11_cursor.ascend(1);
  }
  drop(v0_11_cursor);
  let v0_13: Space = wrap(&(v0_11),&(*CONSTANT_2));
  (v0_13).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v10_21: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v10_22: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v10_23: Space = unwrap(&(v10_22),&(*p0));
  let v10_24: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v10_34 = Space::new();
  let mut v10_34_cursor = (*s0).read_zipper();
  for v10_34_byte in v10_34_cursor.child_mask().iter() {
    v10_34_cursor.descend_to_byte(v10_34_byte);
    {
    let v10_34_tail = v10_34_cursor.fork_read_zipper();
    let v10_34_head = Path::from_slice(&[v10_34_byte]);
    let v11_2: Space = singleton(&(v10_34_head));
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_34_head));
      let mut v12_7 = Space::new();
      let mut v12_7_cursor = (v10_34_tail).read_zipper();
      for v12_7_byte in v12_7_cursor.child_mask().iter() {
        v12_7_cursor.descend_to_byte(v12_7_byte);
        {
        let v12_7_tail = v12_7_cursor.fork_read_zipper();
        let v12_7_head = Path::from_slice(&[v12_7_byte]);
        let v13_2: Space = singleton(&(v12_7_head));
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let mut v14_7 = Space::new();
          let mut v14_7_cursor = (v12_7_tail).read_zipper();
          for v14_7_byte in v14_7_cursor.child_mask().iter() {
            v14_7_cursor.descend_to_byte(v14_7_byte);
            {
            let v14_7_tail = v14_7_cursor.fork_read_zipper();
            let v14_7_head = Path::from_slice(&[v14_7_byte]);
            let v15_2: Space = singleton(&(v14_7_head));
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v16_7: Space = routine_4(c, &(v16_6), &(v14_7_tail).make_space(), &(*s1));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v17_11: Space = routine_5(c, &(v17_6), &(v14_7_tail).make_space(), &(*s1));
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            v14_7.join_into((v15_13).clone());
            }
            v14_7_cursor.ascend(1);
          }
          drop(v14_7_cursor);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let mut v18_11 = Space::new();
          let mut v18_11_cursor = (v12_7_tail).read_zipper();
          for v18_11_byte in v18_11_cursor.child_mask().iter() {
            v18_11_cursor.descend_to_byte(v18_11_byte);
            {
            let v18_11_tail = v18_11_cursor.fork_read_zipper();
            let v18_11_head = Path::from_slice(&[v18_11_byte]);
            let v19_2: Space = singleton(&(v18_11_head));
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (v19_5).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&(v18_11_head));
              let v20_7: Space = routine_4(c, &(v20_6), &(v18_11_tail).make_space(), &(*s1));
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (v19_10).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&(v18_11_head));
              let v21_11: Space = routine_3(c, &(v21_6), &(v18_11_tail).make_space(), &(*s1));
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            v18_11.join_into((v19_13).clone());
            }
            v18_11_cursor.ascend(1);
          }
          drop(v18_11_cursor);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_7.join_into((v13_13).clone());
        }
        v12_7_cursor.ascend(1);
      }
      drop(v12_7_cursor);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_13: Space = if (v11_10).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v10_34_head));
      let v22_11: Space = unwrap(&(v10_23),&(v10_34_head));
      let mut v22_12 = Space::new();
      let mut v22_12_cursor = (v10_34_tail).read_zipper();
      for v22_12_byte in v22_12_cursor.child_mask().iter() {
        v22_12_cursor.descend_to_byte(v22_12_byte);
        {
        let v22_12_tail = v22_12_cursor.fork_read_zipper();
        let v22_12_head = Path::from_slice(&[v22_12_byte]);
        let v23_2: Space = singleton(&(v22_12_head));
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&(v22_12_head));
          let mut v24_7 = Space::new();
          let mut v24_7_cursor = (v22_12_tail).read_zipper();
          for v24_7_byte in v24_7_cursor.child_mask().iter() {
            v24_7_cursor.descend_to_byte(v24_7_byte);
            {
            let v24_7_tail = v24_7_cursor.fork_read_zipper();
            let v24_7_head = Path::from_slice(&[v24_7_byte]);
            let v25_2: Space = singleton(&(v24_7_head));
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (v25_5).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&(v24_7_head));
              let v26_7: Space = routine_4(c, &(v26_6), &(v24_7_tail).make_space(), &(*s1));
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (v25_10).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&(v24_7_head));
              let v27_11: Space = routine_5(c, &(v27_6), &(v24_7_tail).make_space(), &(*s1));
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            v24_7.join_into((v25_13).clone());
            }
            v24_7_cursor.ascend(1);
          }
          drop(v24_7_cursor);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_18: Space = if (v23_10).is_empty() { Space::new() } else {
          let v28_11: Space = unwrap(&(v22_11),&(v22_12_head));
          let v28_12: Space = restrict_to(&(v10_22),&(v28_11));
          let mut v28_13 = Space::new();
          let mut v28_13_cursor = (v28_12).read_zipper();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_byte(v28_13_byte);
            {
            let v28_13_tail = v28_13_cursor.fork_read_zipper();
            let v28_13_head = Path::from_slice(&[v28_13_byte]);
            let v29_2: Space = singleton(&(v28_13_head));
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (v29_5).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &(v28_13_head), &(v28_13_tail).make_space());
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (v29_9).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &(v28_13_head), &(v28_13_tail).make_space());
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            v28_13.join_into((v29_12).clone());
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(v10_21),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_cursor = (v28_14).read_zipper();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_byte(v28_15_byte);
            {
            let v28_15_tail = v28_15_cursor.fork_read_zipper();
            let v28_15_head = Path::from_slice(&[v28_15_byte]);
            let v32_2: Space = singleton(&(v28_15_head));
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (v32_5).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &(v28_15_head), &(v28_15_tail).make_space());
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (v32_9).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &(v28_15_head), &(v28_15_tail).make_space());
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            v28_15.join_into((v32_12).clone());
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          let v28_16: Space = subtract(&(v28_15),&(v28_11));
          drop(v28_11);
          let v28_17: Space = intersect(&(v28_16),&(v10_24));
          compose(&(v23_10),&(v28_17))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&(v22_12_head));
        let v23_19: Space = wrap(&(v23_18),&(v35_6));
        let v23_20: Space = unite(&(v23_8),&(v23_19));
        v22_12.join_into((v23_20).clone());
        }
        v22_12_cursor.ascend(1);
      }
      drop(v22_12_cursor);
      drop(v22_6);
      drop(v22_11);
      compose(&(v11_10),&(v22_12))
    };
    drop(v11_10);
    let v11_14: Space = unite(&(v11_8),&(v11_13));
    v10_34.join_into((v11_14).clone());
    }
    v10_34_cursor.ascend(1);
  }
  drop(v10_34_cursor);
  drop(v10_21);
  drop(v10_22);
  drop(v10_23);
  drop(v10_24);
  (v10_34).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v36_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v36_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v36_10: Space = unwrap(&(v36_9),&(*p0));
  let v36_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v36_40 = Space::new();
  let mut v36_40_cursor = (*s0).read_zipper();
  for v36_40_byte in v36_40_cursor.child_mask().iter() {
    v36_40_cursor.descend_to_byte(v36_40_byte);
    {
    let v36_40_tail = v36_40_cursor.fork_read_zipper();
    let v36_40_head = Path::from_slice(&[v36_40_byte]);
    let v37_2: Space = singleton(&(v36_40_head));
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&(v36_40_head));
      let mut v38_7 = Space::new();
      let mut v38_7_cursor = (v36_40_tail).read_zipper();
      for v38_7_byte in v38_7_cursor.child_mask().iter() {
        v38_7_cursor.descend_to_byte(v38_7_byte);
        {
        let v38_7_tail = v38_7_cursor.fork_read_zipper();
        let v38_7_head = Path::from_slice(&[v38_7_byte]);
        let v39_2: Space = singleton(&(v38_7_head));
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&(v38_7_head));
          let mut v40_7 = Space::new();
          let mut v40_7_cursor = (v38_7_tail).read_zipper();
          for v40_7_byte in v40_7_cursor.child_mask().iter() {
            v40_7_cursor.descend_to_byte(v40_7_byte);
            {
            let v40_7_tail = v40_7_cursor.fork_read_zipper();
            let v40_7_head = Path::from_slice(&[v40_7_byte]);
            let v41_2: Space = singleton(&(v40_7_head));
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&(v40_7_head));
              let v42_7: Space = routine_4(c, &(v42_6), &(v40_7_tail).make_space(), &(*s1));
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&(v40_7_head));
              let v43_11: Space = routine_5(c, &(v43_6), &(v40_7_tail).make_space(), &(*s1));
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            v40_7.join_into((v41_13).clone());
            }
            v40_7_cursor.ascend(1);
          }
          drop(v40_7_cursor);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (v39_10).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&(v38_7_head));
          let mut v44_11 = Space::new();
          let mut v44_11_cursor = (v38_7_tail).read_zipper();
          for v44_11_byte in v44_11_cursor.child_mask().iter() {
            v44_11_cursor.descend_to_byte(v44_11_byte);
            {
            let v44_11_tail = v44_11_cursor.fork_read_zipper();
            let v44_11_head = Path::from_slice(&[v44_11_byte]);
            let v45_2: Space = singleton(&(v44_11_head));
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&(v44_11_head));
              let v46_7: Space = routine_4(c, &(v46_6), &(v44_11_tail).make_space(), &(*s1));
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (v45_10).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&(v44_11_head));
              let v47_11: Space = routine_3(c, &(v47_6), &(v44_11_tail).make_space(), &(*s1));
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            v44_11.join_into((v45_13).clone());
            }
            v44_11_cursor.ascend(1);
          }
          drop(v44_11_cursor);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        v38_7.join_into((v39_13).clone());
        }
        v38_7_cursor.ascend(1);
      }
      drop(v38_7_cursor);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_18: Space = if (v37_10).is_empty() { Space::new() } else {
      let v48_11: Space = unwrap(&(v36_10),&(v36_40_head));
      let v48_12: Space = restrict_to(&(v36_9),&(v48_11));
      let mut v48_13 = Space::new();
      let mut v48_13_cursor = (v48_12).read_zipper();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_byte(v48_13_byte);
        {
        let v48_13_tail = v48_13_cursor.fork_read_zipper();
        let v48_13_head = Path::from_slice(&[v48_13_byte]);
        let v49_2: Space = singleton(&(v48_13_head));
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (v49_5).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_cursor = (v48_13_tail).read_zipper();
          for v50_6_byte in v50_6_cursor.child_mask().iter() {
            v50_6_cursor.descend_to_byte(v50_6_byte);
            {
            let v50_6_tail = v50_6_cursor.fork_read_zipper();
            let v50_6_head = Path::from_slice(&[v50_6_byte]);
            let v51_2: Space = singleton(&(v50_6_head));
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (v51_5).is_empty() { Space::new() } else {
              let v52_6: Path = concat_path(&(v48_13_head),&(v50_6_head));
              let v52_7: Space = routine_10(c, &(v52_6), &(v50_6_tail).make_space());
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (v51_10).is_empty() { Space::new() } else {
              let v53_6: Path = concat_path(&(v48_13_head),&(v50_6_head));
              let v53_11: Space = routine_11(c, &(v53_6), &(v50_6_tail).make_space());
              drop(v53_6);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            v50_6.join_into((v51_13).clone());
            }
            v50_6_cursor.ascend(1);
          }
          drop(v50_6_cursor);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (v49_9).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_cursor = (v48_13_tail).read_zipper();
          for v54_10_byte in v54_10_cursor.child_mask().iter() {
            v54_10_cursor.descend_to_byte(v54_10_byte);
            {
            let v54_10_tail = v54_10_cursor.fork_read_zipper();
            let v54_10_head = Path::from_slice(&[v54_10_byte]);
            let v55_2: Space = singleton(&(v54_10_head));
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (v55_5).is_empty() { Space::new() } else {
              let v56_6: Path = concat_path(&(v48_13_head),&(v54_10_head));
              let v56_7: Space = routine_10(c, &(v56_6), &(v54_10_tail).make_space());
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (v55_10).is_empty() { Space::new() } else {
              let v57_6: Path = concat_path(&(v48_13_head),&(v54_10_head));
              let v57_11: Space = routine_12(c, &(v57_6), &(v54_10_tail).make_space());
              drop(v57_6);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            v54_10.join_into((v55_13).clone());
            }
            v54_10_cursor.ascend(1);
          }
          drop(v54_10_cursor);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        v48_13.join_into((v49_12).clone());
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(v36_7),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_cursor = (v48_14).read_zipper();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_byte(v48_15_byte);
        {
        let v48_15_tail = v48_15_cursor.fork_read_zipper();
        let v48_15_head = Path::from_slice(&[v48_15_byte]);
        let v58_2: Space = singleton(&(v48_15_head));
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (v58_5).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_cursor = (v48_15_tail).read_zipper();
          for v59_6_byte in v59_6_cursor.child_mask().iter() {
            v59_6_cursor.descend_to_byte(v59_6_byte);
            {
            let v59_6_tail = v59_6_cursor.fork_read_zipper();
            let v59_6_head = Path::from_slice(&[v59_6_byte]);
            let v60_2: Space = singleton(&(v59_6_head));
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (v60_5).is_empty() { Space::new() } else {
              let v61_6: Path = concat_path(&(v48_15_head),&(v59_6_head));
              let v61_7: Space = routine_13(c, &(v61_6), &(v59_6_tail).make_space());
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (v60_10).is_empty() { Space::new() } else {
              let v62_6: Path = concat_path(&(v48_15_head),&(v59_6_head));
              let v62_11: Space = routine_14(c, &(v62_6), &(v59_6_tail).make_space());
              drop(v62_6);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            v59_6.join_into((v60_13).clone());
            }
            v59_6_cursor.ascend(1);
          }
          drop(v59_6_cursor);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (v58_9).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_cursor = (v48_15_tail).read_zipper();
          for v63_10_byte in v63_10_cursor.child_mask().iter() {
            v63_10_cursor.descend_to_byte(v63_10_byte);
            {
            let v63_10_tail = v63_10_cursor.fork_read_zipper();
            let v63_10_head = Path::from_slice(&[v63_10_byte]);
            let v64_2: Space = singleton(&(v63_10_head));
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
              let v65_6: Path = concat_path(&(v48_15_head),&(v63_10_head));
              let v65_7: Space = routine_13(c, &(v65_6), &(v63_10_tail).make_space());
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (v64_10).is_empty() { Space::new() } else {
              let v66_6: Path = concat_path(&(v48_15_head),&(v63_10_head));
              let v66_11: Space = routine_15(c, &(v66_6), &(v63_10_tail).make_space());
              drop(v66_6);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            v63_10.join_into((v64_13).clone());
            }
            v63_10_cursor.ascend(1);
          }
          drop(v63_10_cursor);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        v48_15.join_into((v58_12).clone());
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      let v48_16: Space = subtract(&(v48_15),&(v48_11));
      drop(v48_11);
      let v48_17: Space = intersect(&(v48_16),&(v36_12));
      compose(&(v37_10),&(v48_17))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&(v36_40_head));
    let v37_19: Space = wrap(&(v37_18),&(v67_6));
    let v37_20: Space = unite(&(v37_8),&(v37_19));
    v36_40.join_into((v37_20).clone());
    }
    v36_40_cursor.ascend(1);
  }
  drop(v36_40_cursor);
  drop(v36_7);
  drop(v36_9);
  drop(v36_10);
  drop(v36_12);
  (v36_40).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v68_4: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v68_6: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v68_7: Space = unwrap(&(v68_6),&(*p0));
  let v68_8: Space = restrict_to(&(v68_6),&(v68_7));
  drop(v68_6);
  let mut v68_27 = Space::new();
  let mut v68_27_cursor = (v68_8).read_zipper();
  for v68_27_byte in v68_27_cursor.child_mask().iter() {
    v68_27_cursor.descend_to_byte(v68_27_byte);
    {
    let v68_27_tail = v68_27_cursor.fork_read_zipper();
    let v68_27_head = Path::from_slice(&[v68_27_byte]);
    let v69_2: Space = singleton(&(v68_27_head));
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (v69_5).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_cursor = (v68_27_tail).read_zipper();
      for v70_6_byte in v70_6_cursor.child_mask().iter() {
        v70_6_cursor.descend_to_byte(v70_6_byte);
        {
        let v70_6_tail = v70_6_cursor.fork_read_zipper();
        let v70_6_head = Path::from_slice(&[v70_6_byte]);
        let v71_2: Space = singleton(&(v70_6_head));
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
          let v72_6: Path = concat_path(&(v68_27_head),&(v70_6_head));
          let mut v72_7 = Space::new();
          let mut v72_7_cursor = (v70_6_tail).read_zipper();
          for v72_7_byte in v72_7_cursor.child_mask().iter() {
            v72_7_cursor.descend_to_byte(v72_7_byte);
            {
            let v72_7_tail = v72_7_cursor.fork_read_zipper();
            let v72_7_head = Path::from_slice(&[v72_7_byte]);
            let v73_2: Space = singleton(&(v72_7_head));
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (v73_5).is_empty() { Space::new() } else {
              let v74_6: Path = concat_path(&(v72_6),&(v72_7_head));
              let v74_7: Space = routine_16(c, &(v74_6), &(v72_7_tail).make_space());
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (v73_10).is_empty() { Space::new() } else {
              let v75_6: Path = concat_path(&(v72_6),&(v72_7_head));
              let v75_11: Space = routine_17(c, &(v75_6), &(v72_7_tail).make_space());
              drop(v75_6);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            v72_7.join_into((v73_13).clone());
            }
            v72_7_cursor.ascend(1);
          }
          drop(v72_7_cursor);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (v71_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v68_27_head),&(v70_6_head));
          let mut v76_11 = Space::new();
          let mut v76_11_cursor = (v70_6_tail).read_zipper();
          for v76_11_byte in v76_11_cursor.child_mask().iter() {
            v76_11_cursor.descend_to_byte(v76_11_byte);
            {
            let v76_11_tail = v76_11_cursor.fork_read_zipper();
            let v76_11_head = Path::from_slice(&[v76_11_byte]);
            let v77_2: Space = singleton(&(v76_11_head));
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (v77_5).is_empty() { Space::new() } else {
              let v78_6: Path = concat_path(&(v76_6),&(v76_11_head));
              let v78_7: Space = routine_16(c, &(v78_6), &(v76_11_tail).make_space());
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (v77_10).is_empty() { Space::new() } else {
              let v79_6: Path = concat_path(&(v76_6),&(v76_11_head));
              let v79_11: Space = routine_12(c, &(v79_6), &(v76_11_tail).make_space());
              drop(v79_6);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            v76_11.join_into((v77_13).clone());
            }
            v76_11_cursor.ascend(1);
          }
          drop(v76_11_cursor);
          drop(v76_6);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        v70_6.join_into((v71_13).clone());
        }
        v70_6_cursor.ascend(1);
      }
      drop(v70_6_cursor);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (v69_9).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_cursor = (v68_27_tail).read_zipper();
      for v80_10_byte in v80_10_cursor.child_mask().iter() {
        v80_10_cursor.descend_to_byte(v80_10_byte);
        {
        let v80_10_tail = v80_10_cursor.fork_read_zipper();
        let v80_10_head = Path::from_slice(&[v80_10_byte]);
        let v81_2: Space = singleton(&(v80_10_head));
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
          let v82_6: Path = concat_path(&(v68_27_head),&(v80_10_head));
          let mut v82_7 = Space::new();
          let mut v82_7_cursor = (v80_10_tail).read_zipper();
          for v82_7_byte in v82_7_cursor.child_mask().iter() {
            v82_7_cursor.descend_to_byte(v82_7_byte);
            {
            let v82_7_tail = v82_7_cursor.fork_read_zipper();
            let v82_7_head = Path::from_slice(&[v82_7_byte]);
            let v83_2: Space = singleton(&(v82_7_head));
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (v83_5).is_empty() { Space::new() } else {
              let v84_6: Path = concat_path(&(v82_6),&(v82_7_head));
              let v84_7: Space = routine_16(c, &(v84_6), &(v82_7_tail).make_space());
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (v83_10).is_empty() { Space::new() } else {
              let v85_6: Path = concat_path(&(v82_6),&(v82_7_head));
              let v85_11: Space = routine_17(c, &(v85_6), &(v82_7_tail).make_space());
              drop(v85_6);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            v82_7.join_into((v83_13).clone());
            }
            v82_7_cursor.ascend(1);
          }
          drop(v82_7_cursor);
          drop(v82_6);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&(v80_10_tail));
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        v80_10.join_into((v81_12).clone());
        }
        v80_10_cursor.ascend(1);
      }
      drop(v80_10_cursor);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    v68_27.join_into((v69_12).clone());
    }
    v68_27_cursor.ascend(1);
  }
  drop(v68_27_cursor);
  drop(v68_8);
  let v68_28: Space = restrict_to(&(v68_4),&(v68_27));
  drop(v68_4);
  let mut v68_47 = Space::new();
  let mut v68_47_cursor = (v68_28).read_zipper();
  for v68_47_byte in v68_47_cursor.child_mask().iter() {
    v68_47_cursor.descend_to_byte(v68_47_byte);
    {
    let v68_47_tail = v68_47_cursor.fork_read_zipper();
    let v68_47_head = Path::from_slice(&[v68_47_byte]);
    let v86_2: Space = singleton(&(v68_47_head));
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (v86_5).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_cursor = (v68_47_tail).read_zipper();
      for v87_6_byte in v87_6_cursor.child_mask().iter() {
        v87_6_cursor.descend_to_byte(v87_6_byte);
        {
        let v87_6_tail = v87_6_cursor.fork_read_zipper();
        let v87_6_head = Path::from_slice(&[v87_6_byte]);
        let v88_2: Space = singleton(&(v87_6_head));
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v68_47_head),&(v87_6_head));
          let mut v89_7 = Space::new();
          let mut v89_7_cursor = (v87_6_tail).read_zipper();
          for v89_7_byte in v89_7_cursor.child_mask().iter() {
            v89_7_cursor.descend_to_byte(v89_7_byte);
            {
            let v89_7_tail = v89_7_cursor.fork_read_zipper();
            let v89_7_head = Path::from_slice(&[v89_7_byte]);
            let v90_2: Space = singleton(&(v89_7_head));
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
              let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
              let v91_7: Space = routine_18(c, &(v91_6), &(v89_7_tail).make_space());
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
              let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
              let v92_11: Space = routine_19(c, &(v92_6), &(v89_7_tail).make_space());
              drop(v92_6);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            v89_7.join_into((v90_13).clone());
            }
            v89_7_cursor.ascend(1);
          }
          drop(v89_7_cursor);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
          let v93_6: Path = concat_path(&(v68_47_head),&(v87_6_head));
          let mut v93_11 = Space::new();
          let mut v93_11_cursor = (v87_6_tail).read_zipper();
          for v93_11_byte in v93_11_cursor.child_mask().iter() {
            v93_11_cursor.descend_to_byte(v93_11_byte);
            {
            let v93_11_tail = v93_11_cursor.fork_read_zipper();
            let v93_11_head = Path::from_slice(&[v93_11_byte]);
            let v94_2: Space = singleton(&(v93_11_head));
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (v94_5).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v93_6),&(v93_11_head));
              let v95_7: Space = routine_18(c, &(v95_6), &(v93_11_tail).make_space());
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (v94_10).is_empty() { Space::new() } else {
              let v96_6: Path = concat_path(&(v93_6),&(v93_11_head));
              let v96_11: Space = routine_15(c, &(v96_6), &(v93_11_tail).make_space());
              drop(v96_6);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            v93_11.join_into((v94_13).clone());
            }
            v93_11_cursor.ascend(1);
          }
          drop(v93_11_cursor);
          drop(v93_6);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        v87_6.join_into((v88_13).clone());
        }
        v87_6_cursor.ascend(1);
      }
      drop(v87_6_cursor);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (v86_9).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_cursor = (v68_47_tail).read_zipper();
      for v97_10_byte in v97_10_cursor.child_mask().iter() {
        v97_10_cursor.descend_to_byte(v97_10_byte);
        {
        let v97_10_tail = v97_10_cursor.fork_read_zipper();
        let v97_10_head = Path::from_slice(&[v97_10_byte]);
        let v98_2: Space = singleton(&(v97_10_head));
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
          let v99_6: Path = concat_path(&(v68_47_head),&(v97_10_head));
          let mut v99_7 = Space::new();
          let mut v99_7_cursor = (v97_10_tail).read_zipper();
          for v99_7_byte in v99_7_cursor.child_mask().iter() {
            v99_7_cursor.descend_to_byte(v99_7_byte);
            {
            let v99_7_tail = v99_7_cursor.fork_read_zipper();
            let v99_7_head = Path::from_slice(&[v99_7_byte]);
            let v100_2: Space = singleton(&(v99_7_head));
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
              let v101_6: Path = concat_path(&(v99_6),&(v99_7_head));
              let v101_7: Space = routine_18(c, &(v101_6), &(v99_7_tail).make_space());
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
              let v102_6: Path = concat_path(&(v99_6),&(v99_7_head));
              let v102_11: Space = routine_19(c, &(v102_6), &(v99_7_tail).make_space());
              drop(v102_6);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            v99_7.join_into((v100_13).clone());
            }
            v99_7_cursor.ascend(1);
          }
          drop(v99_7_cursor);
          drop(v99_6);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&(v97_10_tail));
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        v97_10.join_into((v98_12).clone());
        }
        v97_10_cursor.ascend(1);
      }
      drop(v97_10_cursor);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    v68_47.join_into((v86_12).clone());
    }
    v68_47_cursor.ascend(1);
  }
  drop(v68_47_cursor);
  let v68_48: Space = subtract(&(v68_47),&(v68_7));
  drop(v68_7);
  let v68_50: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let v68_51: Space = intersect(&(v68_48),&(v68_50));
  drop(v68_50);
  let v68_52: Space = wrap(&(v68_51),&(*p0));
  (v68_52).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v103_10: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v103_11: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v103_12: Space = unwrap(&(v103_11),&(*p0));
  let v103_13: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v103_20 = Space::new();
  let mut v103_20_cursor = (*s0).read_zipper();
  for v103_20_byte in v103_20_cursor.child_mask().iter() {
    v103_20_cursor.descend_to_byte(v103_20_byte);
    {
    let v103_20_tail = v103_20_cursor.fork_read_zipper();
    let v103_20_head = Path::from_slice(&[v103_20_byte]);
    let v104_2: Space = singleton(&(v103_20_head));
    let v104_3: Space = intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let mut v104_6 = Space::new();
    let mut v104_6_cursor = (v103_20_tail).read_zipper();
    for v104_6_byte in v104_6_cursor.child_mask().iter() {
      v104_6_cursor.descend_to_byte(v104_6_byte);
      {
      let v104_6_tail = v104_6_cursor.fork_read_zipper();
      let v104_6_head = Path::from_slice(&[v104_6_byte]);
      let v105_2: Space = Space::new();
      v104_6.join_into((v105_2).clone());
      }
      v104_6_cursor.ascend(1);
    }
    drop(v104_6_cursor);
    let v104_7: Space = compose(&(v104_5),&(v104_6));
    drop(v104_5);
    drop(v104_6);
    let v104_8: Space = intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_9: Space = if has_head(&(v104_8)) { singleton(&[]) } else { Space::new() };
    drop(v104_8);
    let v104_13: Space = if (v104_9).is_empty() { Space::new() } else {
      let v106_10: Space = unwrap(&(v103_12),&(v103_20_head));
      let v106_11: Path = concat_path(&(*p0),&(v103_20_head));
      let mut v106_12 = Space::new();
      let mut v106_12_cursor = (v103_20_tail).read_zipper();
      for v106_12_byte in v106_12_cursor.child_mask().iter() {
        v106_12_cursor.descend_to_byte(v106_12_byte);
        {
        let v106_12_tail = v106_12_cursor.fork_read_zipper();
        let v106_12_head = Path::from_slice(&[v106_12_byte]);
        let v107_2: Space = singleton(&(v106_12_head));
        let v107_3: Space = intersect(&(*CONSTANT_1),&(v107_2));
        drop(v107_2);
        let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
        drop(v107_3);
        let v107_12: Space = if (v107_4).is_empty() { Space::new() } else {
          let v108_5: Space = unwrap(&(v106_10),&(v106_12_head));
          let v108_6: Space = restrict_to(&(v103_11),&(v108_5));
          let mut v108_7 = Space::new();
          let mut v108_7_cursor = (v108_6).read_zipper();
          for v108_7_byte in v108_7_cursor.child_mask().iter() {
            v108_7_cursor.descend_to_byte(v108_7_byte);
            {
            let v108_7_tail = v108_7_cursor.fork_read_zipper();
            let v108_7_head = Path::from_slice(&[v108_7_byte]);
            let v109_2: Space = singleton(&(v108_7_head));
            let v109_3: Space = intersect(&(*CONSTANT_1),&(v109_2));
            let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
            drop(v109_3);
            let v109_5: Space = subtract(&(*CONSTANT_0),&(v109_4));
            drop(v109_4);
            let v109_7: Space = if (v109_5).is_empty() { Space::new() } else {
              let v110_6: Space = routine_6(c, &(v108_7_head), &(v108_7_tail).make_space());
              compose(&(v109_5),&(v110_6))
            };
            drop(v109_5);
            let v109_8: Space = intersect(&(*CONSTANT_1),&(v109_2));
            drop(v109_2);
            let v109_9: Space = if has_head(&(v109_8)) { singleton(&[]) } else { Space::new() };
            drop(v109_8);
            let v109_11: Space = if (v109_9).is_empty() { Space::new() } else {
              let v111_10: Space = routine_7(c, &(v108_7_head), &(v108_7_tail).make_space());
              compose(&(v109_9),&(v111_10))
            };
            drop(v109_9);
            let v109_12: Space = unite(&(v109_7),&(v109_11));
            v108_7.join_into((v109_12).clone());
            }
            v108_7_cursor.ascend(1);
          }
          drop(v108_7_cursor);
          drop(v108_6);
          let v108_8: Space = restrict_to(&(v103_10),&(v108_7));
          let mut v108_9 = Space::new();
          let mut v108_9_cursor = (v108_8).read_zipper();
          for v108_9_byte in v108_9_cursor.child_mask().iter() {
            v108_9_cursor.descend_to_byte(v108_9_byte);
            {
            let v108_9_tail = v108_9_cursor.fork_read_zipper();
            let v108_9_head = Path::from_slice(&[v108_9_byte]);
            let v112_2: Space = singleton(&(v108_9_head));
            let v112_3: Space = intersect(&(*CONSTANT_1),&(v112_2));
            let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
            drop(v112_3);
            let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
            drop(v112_4);
            let v112_7: Space = if (v112_5).is_empty() { Space::new() } else {
              let v113_6: Space = routine_8(c, &(v108_9_head), &(v108_9_tail).make_space());
              compose(&(v112_5),&(v113_6))
            };
            drop(v112_5);
            let v112_8: Space = intersect(&(*CONSTANT_1),&(v112_2));
            drop(v112_2);
            let v112_9: Space = if has_head(&(v112_8)) { singleton(&[]) } else { Space::new() };
            drop(v112_8);
            let v112_11: Space = if (v112_9).is_empty() { Space::new() } else {
              let v114_10: Space = routine_9(c, &(v108_9_head), &(v108_9_tail).make_space());
              compose(&(v112_9),&(v114_10))
            };
            drop(v112_9);
            let v112_12: Space = unite(&(v112_7),&(v112_11));
            v108_9.join_into((v112_12).clone());
            }
            v108_9_cursor.ascend(1);
          }
          drop(v108_9_cursor);
          let v108_10: Space = subtract(&(v108_9),&(v108_5));
          drop(v108_5);
          let v108_11: Space = intersect(&(v108_10),&(v103_13));
          compose(&(v107_4),&(v108_11))
        };
        drop(v107_4);
        let v107_13: Path = concat_path(&(v106_11),&(v106_12_head));
        let v107_14: Space = wrap(&(v107_12),&(v107_13));
        drop(v107_13);
        v106_12.join_into((v107_14).clone());
        }
        v106_12_cursor.ascend(1);
      }
      drop(v106_12_cursor);
      drop(v106_10);
      drop(v106_11);
      compose(&(v104_9),&(v106_12))
    };
    drop(v104_9);
    let v104_14: Space = unite(&(v104_7),&(v104_13));
    drop(v104_7);
    v103_20.join_into((v104_14).clone());
    }
    v103_20_cursor.ascend(1);
  }
  drop(v103_20_cursor);
  drop(v103_10);
  drop(v103_11);
  drop(v103_12);
  drop(v103_13);
  (v103_20).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v115_7: Space = unwrap(&(*s1),&(*CONSTANT_3));
  let v115_9: Space = unwrap(&(*s1),&(*CONSTANT_4));
  let v115_10: Space = unwrap(&(v115_9),&(*p0));
  let v115_12: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let mut v115_31 = Space::new();
  let mut v115_31_cursor = (*s0).read_zipper();
  for v115_31_byte in v115_31_cursor.child_mask().iter() {
    v115_31_cursor.descend_to_byte(v115_31_byte);
    {
    let v115_31_tail = v115_31_cursor.fork_read_zipper();
    let v115_31_head = Path::from_slice(&[v115_31_byte]);
    let v116_2: Space = singleton(&(v115_31_head));
    let v116_3: Space = intersect(&(*CONSTANT_1),&(v116_2));
    let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
    drop(v116_3);
    let v116_5: Space = subtract(&(*CONSTANT_0),&(v116_4));
    drop(v116_4);
    let mut v116_6 = Space::new();
    let mut v116_6_cursor = (v115_31_tail).read_zipper();
    for v116_6_byte in v116_6_cursor.child_mask().iter() {
      v116_6_cursor.descend_to_byte(v116_6_byte);
      {
      let v116_6_tail = v116_6_cursor.fork_read_zipper();
      let v116_6_head = Path::from_slice(&[v116_6_byte]);
      let v117_2: Space = Space::new();
      v116_6.join_into((v117_2).clone());
      }
      v116_6_cursor.ascend(1);
    }
    drop(v116_6_cursor);
    let v116_7: Space = compose(&(v116_5),&(v116_6));
    drop(v116_5);
    drop(v116_6);
    let v116_8: Space = intersect(&(*CONSTANT_1),&(v116_2));
    drop(v116_2);
    let v116_9: Space = if has_head(&(v116_8)) { singleton(&[]) } else { Space::new() };
    drop(v116_8);
    let v116_17: Space = if (v116_9).is_empty() { Space::new() } else {
      let v118_10: Space = unwrap(&(v115_10),&(v115_31_head));
      let v118_11: Space = restrict_to(&(v115_9),&(v118_10));
      let mut v118_12 = Space::new();
      let mut v118_12_cursor = (v118_11).read_zipper();
      for v118_12_byte in v118_12_cursor.child_mask().iter() {
        v118_12_cursor.descend_to_byte(v118_12_byte);
        {
        let v118_12_tail = v118_12_cursor.fork_read_zipper();
        let v118_12_head = Path::from_slice(&[v118_12_byte]);
        let v119_2: Space = singleton(&(v118_12_head));
        let v119_3: Space = intersect(&(*CONSTANT_1),&(v119_2));
        let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
        drop(v119_3);
        let v119_5: Space = subtract(&(*CONSTANT_0),&(v119_4));
        drop(v119_4);
        let v119_7: Space = if (v119_5).is_empty() { Space::new() } else {
          let mut v120_6 = Space::new();
          let mut v120_6_cursor = (v118_12_tail).read_zipper();
          for v120_6_byte in v120_6_cursor.child_mask().iter() {
            v120_6_cursor.descend_to_byte(v120_6_byte);
            {
            let v120_6_tail = v120_6_cursor.fork_read_zipper();
            let v120_6_head = Path::from_slice(&[v120_6_byte]);
            let v121_2: Space = singleton(&(v120_6_head));
            let v121_3: Space = intersect(&(*CONSTANT_1),&(v121_2));
            let v121_4: Space = if has_head(&(v121_3)) { singleton(&[]) } else { Space::new() };
            drop(v121_3);
            let v121_5: Space = subtract(&(*CONSTANT_0),&(v121_4));
            drop(v121_4);
            let v121_8: Space = if (v121_5).is_empty() { Space::new() } else {
              let v122_6: Path = concat_path(&(v118_12_head),&(v120_6_head));
              let v122_7: Space = routine_10(c, &(v122_6), &(v120_6_tail).make_space());
              compose(&(v121_5),&(v122_7))
            };
            drop(v121_5);
            let v121_9: Space = intersect(&(*CONSTANT_1),&(v121_2));
            drop(v121_2);
            let v121_10: Space = if has_head(&(v121_9)) { singleton(&[]) } else { Space::new() };
            drop(v121_9);
            let v121_12: Space = if (v121_10).is_empty() { Space::new() } else {
              let v123_6: Path = concat_path(&(v118_12_head),&(v120_6_head));
              let v123_11: Space = routine_11(c, &(v123_6), &(v120_6_tail).make_space());
              drop(v123_6);
              compose(&(v121_10),&(v123_11))
            };
            drop(v121_10);
            let v121_13: Space = unite(&(v121_8),&(v121_12));
            v120_6.join_into((v121_13).clone());
            }
            v120_6_cursor.ascend(1);
          }
          drop(v120_6_cursor);
          compose(&(v119_5),&(v120_6))
        };
        drop(v119_5);
        let v119_8: Space = intersect(&(*CONSTANT_1),&(v119_2));
        drop(v119_2);
        let v119_9: Space = if has_head(&(v119_8)) { singleton(&[]) } else { Space::new() };
        drop(v119_8);
        let v119_11: Space = if (v119_9).is_empty() { Space::new() } else {
          let mut v124_10 = Space::new();
          let mut v124_10_cursor = (v118_12_tail).read_zipper();
          for v124_10_byte in v124_10_cursor.child_mask().iter() {
            v124_10_cursor.descend_to_byte(v124_10_byte);
            {
            let v124_10_tail = v124_10_cursor.fork_read_zipper();
            let v124_10_head = Path::from_slice(&[v124_10_byte]);
            let v125_2: Space = singleton(&(v124_10_head));
            let v125_3: Space = intersect(&(*CONSTANT_1),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_0),&(v125_4));
            drop(v125_4);
            let v125_8: Space = if (v125_5).is_empty() { Space::new() } else {
              let v126_6: Path = concat_path(&(v118_12_head),&(v124_10_head));
              let v126_7: Space = routine_10(c, &(v126_6), &(v124_10_tail).make_space());
              compose(&(v125_5),&(v126_7))
            };
            drop(v125_5);
            let v125_9: Space = intersect(&(*CONSTANT_1),&(v125_2));
            drop(v125_2);
            let v125_10: Space = if has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
            drop(v125_9);
            let v125_12: Space = if (v125_10).is_empty() { Space::new() } else {
              let v127_6: Path = concat_path(&(v118_12_head),&(v124_10_head));
              let v127_11: Space = routine_12(c, &(v127_6), &(v124_10_tail).make_space());
              drop(v127_6);
              compose(&(v125_10),&(v127_11))
            };
            drop(v125_10);
            let v125_13: Space = unite(&(v125_8),&(v125_12));
            v124_10.join_into((v125_13).clone());
            }
            v124_10_cursor.ascend(1);
          }
          drop(v124_10_cursor);
          compose(&(v119_9),&(v124_10))
        };
        drop(v119_9);
        let v119_12: Space = unite(&(v119_7),&(v119_11));
        v118_12.join_into((v119_12).clone());
        }
        v118_12_cursor.ascend(1);
      }
      drop(v118_12_cursor);
      drop(v118_11);
      let v118_13: Space = restrict_to(&(v115_7),&(v118_12));
      let mut v118_14 = Space::new();
      let mut v118_14_cursor = (v118_13).read_zipper();
      for v118_14_byte in v118_14_cursor.child_mask().iter() {
        v118_14_cursor.descend_to_byte(v118_14_byte);
        {
        let v118_14_tail = v118_14_cursor.fork_read_zipper();
        let v118_14_head = Path::from_slice(&[v118_14_byte]);
        let v128_2: Space = singleton(&(v118_14_head));
        let v128_3: Space = intersect(&(*CONSTANT_1),&(v128_2));
        let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
        drop(v128_3);
        let v128_5: Space = subtract(&(*CONSTANT_0),&(v128_4));
        drop(v128_4);
        let v128_7: Space = if (v128_5).is_empty() { Space::new() } else {
          let mut v129_6 = Space::new();
          let mut v129_6_cursor = (v118_14_tail).read_zipper();
          for v129_6_byte in v129_6_cursor.child_mask().iter() {
            v129_6_cursor.descend_to_byte(v129_6_byte);
            {
            let v129_6_tail = v129_6_cursor.fork_read_zipper();
            let v129_6_head = Path::from_slice(&[v129_6_byte]);
            let v130_2: Space = singleton(&(v129_6_head));
            let v130_3: Space = intersect(&(*CONSTANT_1),&(v130_2));
            let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
            drop(v130_3);
            let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
            drop(v130_4);
            let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
              let v131_6: Path = concat_path(&(v118_14_head),&(v129_6_head));
              let v131_7: Space = routine_13(c, &(v131_6), &(v129_6_tail).make_space());
              compose(&(v130_5),&(v131_7))
            };
            drop(v130_5);
            let v130_9: Space = intersect(&(*CONSTANT_1),&(v130_2));
            drop(v130_2);
            let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
            drop(v130_9);
            let v130_12: Space = if (v130_10).is_empty() { Space::new() } else {
              let v132_6: Path = concat_path(&(v118_14_head),&(v129_6_head));
              let v132_11: Space = routine_14(c, &(v132_6), &(v129_6_tail).make_space());
              drop(v132_6);
              compose(&(v130_10),&(v132_11))
            };
            drop(v130_10);
            let v130_13: Space = unite(&(v130_8),&(v130_12));
            v129_6.join_into((v130_13).clone());
            }
            v129_6_cursor.ascend(1);
          }
          drop(v129_6_cursor);
          compose(&(v128_5),&(v129_6))
        };
        drop(v128_5);
        let v128_8: Space = intersect(&(*CONSTANT_1),&(v128_2));
        drop(v128_2);
        let v128_9: Space = if has_head(&(v128_8)) { singleton(&[]) } else { Space::new() };
        drop(v128_8);
        let v128_11: Space = if (v128_9).is_empty() { Space::new() } else {
          let mut v133_10 = Space::new();
          let mut v133_10_cursor = (v118_14_tail).read_zipper();
          for v133_10_byte in v133_10_cursor.child_mask().iter() {
            v133_10_cursor.descend_to_byte(v133_10_byte);
            {
            let v133_10_tail = v133_10_cursor.fork_read_zipper();
            let v133_10_head = Path::from_slice(&[v133_10_byte]);
            let v134_2: Space = singleton(&(v133_10_head));
            let v134_3: Space = intersect(&(*CONSTANT_1),&(v134_2));
            let v134_4: Space = if has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
            drop(v134_3);
            let v134_5: Space = subtract(&(*CONSTANT_0),&(v134_4));
            drop(v134_4);
            let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
              let v135_6: Path = concat_path(&(v118_14_head),&(v133_10_head));
              let v135_7: Space = routine_13(c, &(v135_6), &(v133_10_tail).make_space());
              compose(&(v134_5),&(v135_7))
            };
            drop(v134_5);
            let v134_9: Space = intersect(&(*CONSTANT_1),&(v134_2));
            drop(v134_2);
            let v134_10: Space = if has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
            drop(v134_9);
            let v134_12: Space = if (v134_10).is_empty() { Space::new() } else {
              let v136_6: Path = concat_path(&(v118_14_head),&(v133_10_head));
              let v136_11: Space = routine_15(c, &(v136_6), &(v133_10_tail).make_space());
              drop(v136_6);
              compose(&(v134_10),&(v136_11))
            };
            drop(v134_10);
            let v134_13: Space = unite(&(v134_8),&(v134_12));
            v133_10.join_into((v134_13).clone());
            }
            v133_10_cursor.ascend(1);
          }
          drop(v133_10_cursor);
          compose(&(v128_9),&(v133_10))
        };
        drop(v128_9);
        let v128_12: Space = unite(&(v128_7),&(v128_11));
        v118_14.join_into((v128_12).clone());
        }
        v118_14_cursor.ascend(1);
      }
      drop(v118_14_cursor);
      let v118_15: Space = subtract(&(v118_14),&(v118_10));
      drop(v118_10);
      let v118_16: Space = intersect(&(v118_15),&(v115_12));
      compose(&(v116_9),&(v118_16))
    };
    drop(v116_9);
    let v116_18: Path = concat_path(&(*p0),&(v115_31_head));
    let v116_19: Space = wrap(&(v116_17),&(v116_18));
    drop(v116_18);
    let v116_20: Space = unite(&(v116_7),&(v116_19));
    drop(v116_7);
    v115_31.join_into((v116_20).clone());
    }
    v115_31_cursor.ascend(1);
  }
  drop(v115_31_cursor);
  drop(v115_7);
  drop(v115_9);
  drop(v115_10);
  drop(v115_12);
  (v115_31).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v137_20 = Space::new();
  let mut v137_20_cursor = (*s0).read_zipper();
  for v137_20_byte in v137_20_cursor.child_mask().iter() {
    v137_20_cursor.descend_to_byte(v137_20_byte);
    {
    let v137_20_tail = v137_20_cursor.fork_read_zipper();
    let v137_20_head = Path::from_slice(&[v137_20_byte]);
    let v138_2: Space = singleton(&(v137_20_head));
    let v138_3: Space = intersect(&(*CONSTANT_1),&(v138_2));
    let v138_4: Space = if has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
    drop(v138_3);
    let v138_5: Space = subtract(&(*CONSTANT_0),&(v138_4));
    drop(v138_4);
    let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
      let v139_6: Path = concat_path(&(*p0),&(v137_20_head));
      let mut v139_7 = Space::new();
      let mut v139_7_cursor = (v137_20_tail).read_zipper();
      for v139_7_byte in v139_7_cursor.child_mask().iter() {
        v139_7_cursor.descend_to_byte(v139_7_byte);
        {
        let v139_7_tail = v139_7_cursor.fork_read_zipper();
        let v139_7_head = Path::from_slice(&[v139_7_byte]);
        let v140_2: Space = singleton(&(v139_7_head));
        let v140_3: Space = intersect(&(*CONSTANT_1),&(v140_2));
        let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
        drop(v140_3);
        let v140_5: Space = subtract(&(*CONSTANT_0),&(v140_4));
        drop(v140_4);
        let v140_8: Space = if (v140_5).is_empty() { Space::new() } else {
          let v141_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let mut v141_7 = Space::new();
          let mut v141_7_cursor = (v139_7_tail).read_zipper();
          for v141_7_byte in v141_7_cursor.child_mask().iter() {
            v141_7_cursor.descend_to_byte(v141_7_byte);
            {
            let v141_7_tail = v141_7_cursor.fork_read_zipper();
            let v141_7_head = Path::from_slice(&[v141_7_byte]);
            let v142_2: Space = singleton(&(v141_7_head));
            let v142_3: Space = intersect(&(*CONSTANT_1),&(v142_2));
            let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
            drop(v142_3);
            let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
            drop(v142_4);
            let v142_8: Space = if (v142_5).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v141_6),&(v141_7_head));
              let v143_7: Space = routine_20(c, &(v143_6), &(v141_7_tail).make_space());
              compose(&(v142_5),&(v143_7))
            };
            drop(v142_5);
            let v142_9: Space = intersect(&(*CONSTANT_1),&(v142_2));
            drop(v142_2);
            let v142_10: Space = if has_head(&(v142_9)) { singleton(&[]) } else { Space::new() };
            drop(v142_9);
            let v142_12: Space = if (v142_10).is_empty() { Space::new() } else {
              let v144_6: Path = concat_path(&(v141_6),&(v141_7_head));
              let v144_11: Space = routine_21(c, &(v144_6), &(v141_7_tail).make_space());
              drop(v144_6);
              compose(&(v142_10),&(v144_11))
            };
            drop(v142_10);
            let v142_13: Space = unite(&(v142_8),&(v142_12));
            v141_7.join_into((v142_13).clone());
            }
            v141_7_cursor.ascend(1);
          }
          drop(v141_7_cursor);
          compose(&(v140_5),&(v141_7))
        };
        drop(v140_5);
        let v140_9: Space = intersect(&(*CONSTANT_1),&(v140_2));
        drop(v140_2);
        let v140_10: Space = if has_head(&(v140_9)) { singleton(&[]) } else { Space::new() };
        drop(v140_9);
        let v140_12: Space = if (v140_10).is_empty() { Space::new() } else {
          let v145_6: Path = concat_path(&(v139_6),&(v139_7_head));
          let mut v145_11 = Space::new();
          let mut v145_11_cursor = (v139_7_tail).read_zipper();
          for v145_11_byte in v145_11_cursor.child_mask().iter() {
            v145_11_cursor.descend_to_byte(v145_11_byte);
            {
            let v145_11_tail = v145_11_cursor.fork_read_zipper();
            let v145_11_head = Path::from_slice(&[v145_11_byte]);
            let v146_2: Space = singleton(&(v145_11_head));
            let v146_3: Space = intersect(&(*CONSTANT_1),&(v146_2));
            let v146_4: Space = if has_head(&(v146_3)) { singleton(&[]) } else { Space::new() };
            drop(v146_3);
            let v146_5: Space = subtract(&(*CONSTANT_0),&(v146_4));
            drop(v146_4);
            let v146_8: Space = if (v146_5).is_empty() { Space::new() } else {
              let v147_6: Path = concat_path(&(v145_6),&(v145_11_head));
              let v147_7: Space = routine_20(c, &(v147_6), &(v145_11_tail).make_space());
              compose(&(v146_5),&(v147_7))
            };
            drop(v146_5);
            let v146_9: Space = intersect(&(*CONSTANT_1),&(v146_2));
            drop(v146_2);
            let v146_10: Space = if has_head(&(v146_9)) { singleton(&[]) } else { Space::new() };
            drop(v146_9);
            let v146_12: Space = if (v146_10).is_empty() { Space::new() } else {
              let v148_6: Path = concat_path(&(v145_6),&(v145_11_head));
              let v148_11: Space = routine_12(c, &(v148_6), &(v145_11_tail).make_space());
              drop(v148_6);
              compose(&(v146_10),&(v148_11))
            };
            drop(v146_10);
            let v146_13: Space = unite(&(v146_8),&(v146_12));
            v145_11.join_into((v146_13).clone());
            }
            v145_11_cursor.ascend(1);
          }
          drop(v145_11_cursor);
          drop(v145_6);
          compose(&(v140_10),&(v145_11))
        };
        drop(v140_10);
        let v140_13: Space = unite(&(v140_8),&(v140_12));
        v139_7.join_into((v140_13).clone());
        }
        v139_7_cursor.ascend(1);
      }
      drop(v139_7_cursor);
      compose(&(v138_5),&(v139_7))
    };
    drop(v138_5);
    let v138_9: Space = intersect(&(*CONSTANT_1),&(v138_2));
    drop(v138_2);
    let v138_10: Space = if has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
    drop(v138_9);
    let v138_12: Space = if (v138_10).is_empty() { Space::new() } else {
      let v149_6: Path = concat_path(&(*p0),&(v137_20_head));
      let mut v149_11 = Space::new();
      let mut v149_11_cursor = (v137_20_tail).read_zipper();
      for v149_11_byte in v149_11_cursor.child_mask().iter() {
        v149_11_cursor.descend_to_byte(v149_11_byte);
        {
        let v149_11_tail = v149_11_cursor.fork_read_zipper();
        let v149_11_head = Path::from_slice(&[v149_11_byte]);
        let v150_2: Space = singleton(&(v149_11_head));
        let v150_3: Space = intersect(&(*CONSTANT_1),&(v150_2));
        let v150_4: Space = if has_head(&(v150_3)) { singleton(&[]) } else { Space::new() };
        drop(v150_3);
        let v150_5: Space = subtract(&(*CONSTANT_0),&(v150_4));
        drop(v150_4);
        let v150_8: Space = if (v150_5).is_empty() { Space::new() } else {
          let v151_6: Path = concat_path(&(v149_6),&(v149_11_head));
          let mut v151_7 = Space::new();
          let mut v151_7_cursor = (v149_11_tail).read_zipper();
          for v151_7_byte in v151_7_cursor.child_mask().iter() {
            v151_7_cursor.descend_to_byte(v151_7_byte);
            {
            let v151_7_tail = v151_7_cursor.fork_read_zipper();
            let v151_7_head = Path::from_slice(&[v151_7_byte]);
            let v152_2: Space = singleton(&(v151_7_head));
            let v152_3: Space = intersect(&(*CONSTANT_1),&(v152_2));
            let v152_4: Space = if has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
            drop(v152_3);
            let v152_5: Space = subtract(&(*CONSTANT_0),&(v152_4));
            drop(v152_4);
            let v152_8: Space = if (v152_5).is_empty() { Space::new() } else {
              let v153_6: Path = concat_path(&(v151_6),&(v151_7_head));
              let v153_7: Space = routine_20(c, &(v153_6), &(v151_7_tail).make_space());
              compose(&(v152_5),&(v153_7))
            };
            drop(v152_5);
            let v152_9: Space = intersect(&(*CONSTANT_1),&(v152_2));
            drop(v152_2);
            let v152_10: Space = if has_head(&(v152_9)) { singleton(&[]) } else { Space::new() };
            drop(v152_9);
            let v152_12: Space = if (v152_10).is_empty() { Space::new() } else {
              let v154_6: Path = concat_path(&(v151_6),&(v151_7_head));
              let v154_11: Space = routine_21(c, &(v154_6), &(v151_7_tail).make_space());
              drop(v154_6);
              compose(&(v152_10),&(v154_11))
            };
            drop(v152_10);
            let v152_13: Space = unite(&(v152_8),&(v152_12));
            v151_7.join_into((v152_13).clone());
            }
            v151_7_cursor.ascend(1);
          }
          drop(v151_7_cursor);
          drop(v151_6);
          compose(&(v150_5),&(v151_7))
        };
        drop(v150_5);
        let v150_9: Space = intersect(&(*CONSTANT_1),&(v150_2));
        drop(v150_2);
        let v150_10: Space = if has_head(&(v150_9)) { singleton(&[]) } else { Space::new() };
        drop(v150_9);
        let v150_11: Space = compose(&(v150_10),&(v149_11_tail));
        drop(v150_10);
        let v150_12: Space = unite(&(v150_8),&(v150_11));
        drop(v150_11);
        v149_11.join_into((v150_12).clone());
        }
        v149_11_cursor.ascend(1);
      }
      drop(v149_11_cursor);
      drop(v149_6);
      compose(&(v138_10),&(v149_11))
    };
    drop(v138_10);
    let v138_13: Space = unite(&(v138_8),&(v138_12));
    v137_20.join_into((v138_13).clone());
    }
    v137_20_cursor.ascend(1);
  }
  drop(v137_20_cursor);
  (v137_20).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v155_14 = Space::new();
  let mut v155_14_cursor = (*s0).read_zipper();
  for v155_14_byte in v155_14_cursor.child_mask().iter() {
    v155_14_cursor.descend_to_byte(v155_14_byte);
    {
    let v155_14_tail = v155_14_cursor.fork_read_zipper();
    let v155_14_head = Path::from_slice(&[v155_14_byte]);
    let v156_2: Space = singleton(&(v155_14_head));
    let v156_3: Space = intersect(&(*CONSTANT_1),&(v156_2));
    let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
    drop(v156_3);
    let v156_5: Space = subtract(&(*CONSTANT_0),&(v156_4));
    drop(v156_4);
    let v156_8: Space = if (v156_5).is_empty() { Space::new() } else {
      let v157_6: Path = concat_path(&(*p0),&(v155_14_head));
      let mut v157_7 = Space::new();
      let mut v157_7_cursor = (v155_14_tail).read_zipper();
      for v157_7_byte in v157_7_cursor.child_mask().iter() {
        v157_7_cursor.descend_to_byte(v157_7_byte);
        {
        let v157_7_tail = v157_7_cursor.fork_read_zipper();
        let v157_7_head = Path::from_slice(&[v157_7_byte]);
        let v158_2: Space = singleton(&(v157_7_head));
        let v158_3: Space = intersect(&(*CONSTANT_1),&(v158_2));
        let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
        drop(v158_3);
        let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
        drop(v158_4);
        let v158_8: Space = if (v158_5).is_empty() { Space::new() } else {
          let v159_6: Path = concat_path(&(v157_6),&(v157_7_head));
          let mut v159_7 = Space::new();
          let mut v159_7_cursor = (v157_7_tail).read_zipper();
          for v159_7_byte in v159_7_cursor.child_mask().iter() {
            v159_7_cursor.descend_to_byte(v159_7_byte);
            {
            let v159_7_tail = v159_7_cursor.fork_read_zipper();
            let v159_7_head = Path::from_slice(&[v159_7_byte]);
            let v160_2: Space = singleton(&(v159_7_head));
            let v160_3: Space = intersect(&(*CONSTANT_1),&(v160_2));
            let v160_4: Space = if has_head(&(v160_3)) { singleton(&[]) } else { Space::new() };
            drop(v160_3);
            let v160_5: Space = subtract(&(*CONSTANT_0),&(v160_4));
            drop(v160_4);
            let v160_8: Space = if (v160_5).is_empty() { Space::new() } else {
              let v161_6: Path = concat_path(&(v159_6),&(v159_7_head));
              let v161_7: Space = routine_20(c, &(v161_6), &(v159_7_tail).make_space());
              compose(&(v160_5),&(v161_7))
            };
            drop(v160_5);
            let v160_9: Space = intersect(&(*CONSTANT_1),&(v160_2));
            drop(v160_2);
            let v160_10: Space = if has_head(&(v160_9)) { singleton(&[]) } else { Space::new() };
            drop(v160_9);
            let v160_12: Space = if (v160_10).is_empty() { Space::new() } else {
              let v162_6: Path = concat_path(&(v159_6),&(v159_7_head));
              let v162_11: Space = routine_21(c, &(v162_6), &(v159_7_tail).make_space());
              drop(v162_6);
              compose(&(v160_10),&(v162_11))
            };
            drop(v160_10);
            let v160_13: Space = unite(&(v160_8),&(v160_12));
            v159_7.join_into((v160_13).clone());
            }
            v159_7_cursor.ascend(1);
          }
          drop(v159_7_cursor);
          compose(&(v158_5),&(v159_7))
        };
        drop(v158_5);
        let v158_9: Space = intersect(&(*CONSTANT_1),&(v158_2));
        drop(v158_2);
        let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
        drop(v158_9);
        let v158_12: Space = if (v158_10).is_empty() { Space::new() } else {
          let v163_6: Path = concat_path(&(v157_6),&(v157_7_head));
          let mut v163_11 = Space::new();
          let mut v163_11_cursor = (v157_7_tail).read_zipper();
          for v163_11_byte in v163_11_cursor.child_mask().iter() {
            v163_11_cursor.descend_to_byte(v163_11_byte);
            {
            let v163_11_tail = v163_11_cursor.fork_read_zipper();
            let v163_11_head = Path::from_slice(&[v163_11_byte]);
            let v164_2: Space = singleton(&(v163_11_head));
            let v164_3: Space = intersect(&(*CONSTANT_1),&(v164_2));
            let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
            drop(v164_3);
            let v164_5: Space = subtract(&(*CONSTANT_0),&(v164_4));
            drop(v164_4);
            let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
              let v165_6: Path = concat_path(&(v163_6),&(v163_11_head));
              let v165_7: Space = routine_20(c, &(v165_6), &(v163_11_tail).make_space());
              compose(&(v164_5),&(v165_7))
            };
            drop(v164_5);
            let v164_9: Space = intersect(&(*CONSTANT_1),&(v164_2));
            drop(v164_2);
            let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
            drop(v164_9);
            let v164_12: Space = if (v164_10).is_empty() { Space::new() } else {
              let v166_6: Path = concat_path(&(v163_6),&(v163_11_head));
              let v166_11: Space = routine_12(c, &(v166_6), &(v163_11_tail).make_space());
              drop(v166_6);
              compose(&(v164_10),&(v166_11))
            };
            drop(v164_10);
            let v164_13: Space = unite(&(v164_8),&(v164_12));
            v163_11.join_into((v164_13).clone());
            }
            v163_11_cursor.ascend(1);
          }
          drop(v163_11_cursor);
          drop(v163_6);
          compose(&(v158_10),&(v163_11))
        };
        drop(v158_10);
        let v158_13: Space = unite(&(v158_8),&(v158_12));
        v157_7.join_into((v158_13).clone());
        }
        v157_7_cursor.ascend(1);
      }
      drop(v157_7_cursor);
      drop(v157_6);
      compose(&(v156_5),&(v157_7))
    };
    drop(v156_5);
    let v156_9: Space = intersect(&(*CONSTANT_1),&(v156_2));
    drop(v156_2);
    let v156_10: Space = if has_head(&(v156_9)) { singleton(&[]) } else { Space::new() };
    drop(v156_9);
    let v156_11: Space = compose(&(v156_10),&(v155_14_tail));
    drop(v156_10);
    let v156_12: Space = unite(&(v156_8),&(v156_11));
    drop(v156_11);
    v155_14.join_into((v156_12).clone());
    }
    v155_14_cursor.ascend(1);
  }
  drop(v155_14_cursor);
  (v155_14).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v167_20 = Space::new();
  let mut v167_20_cursor = (*s0).read_zipper();
  for v167_20_byte in v167_20_cursor.child_mask().iter() {
    v167_20_cursor.descend_to_byte(v167_20_byte);
    {
    let v167_20_tail = v167_20_cursor.fork_read_zipper();
    let v167_20_head = Path::from_slice(&[v167_20_byte]);
    let v168_2: Space = singleton(&(v167_20_head));
    let v168_3: Space = intersect(&(*CONSTANT_1),&(v168_2));
    let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
    drop(v168_3);
    let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
    drop(v168_4);
    let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
      let v169_6: Path = concat_path(&(*p0),&(v167_20_head));
      let mut v169_7 = Space::new();
      let mut v169_7_cursor = (v167_20_tail).read_zipper();
      for v169_7_byte in v169_7_cursor.child_mask().iter() {
        v169_7_cursor.descend_to_byte(v169_7_byte);
        {
        let v169_7_tail = v169_7_cursor.fork_read_zipper();
        let v169_7_head = Path::from_slice(&[v169_7_byte]);
        let v170_2: Space = singleton(&(v169_7_head));
        let v170_3: Space = intersect(&(*CONSTANT_1),&(v170_2));
        let v170_4: Space = if has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
        drop(v170_3);
        let v170_5: Space = subtract(&(*CONSTANT_0),&(v170_4));
        drop(v170_4);
        let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
          let v171_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let mut v171_7 = Space::new();
          let mut v171_7_cursor = (v169_7_tail).read_zipper();
          for v171_7_byte in v171_7_cursor.child_mask().iter() {
            v171_7_cursor.descend_to_byte(v171_7_byte);
            {
            let v171_7_tail = v171_7_cursor.fork_read_zipper();
            let v171_7_head = Path::from_slice(&[v171_7_byte]);
            let v172_2: Space = singleton(&(v171_7_head));
            let v172_3: Space = intersect(&(*CONSTANT_1),&(v172_2));
            let v172_4: Space = if has_head(&(v172_3)) { singleton(&[]) } else { Space::new() };
            drop(v172_3);
            let v172_5: Space = subtract(&(*CONSTANT_0),&(v172_4));
            drop(v172_4);
            let v172_8: Space = if (v172_5).is_empty() { Space::new() } else {
              let v173_6: Path = concat_path(&(v171_6),&(v171_7_head));
              let v173_7: Space = routine_22(c, &(v173_6), &(v171_7_tail).make_space());
              compose(&(v172_5),&(v173_7))
            };
            drop(v172_5);
            let v172_9: Space = intersect(&(*CONSTANT_1),&(v172_2));
            drop(v172_2);
            let v172_10: Space = if has_head(&(v172_9)) { singleton(&[]) } else { Space::new() };
            drop(v172_9);
            let v172_12: Space = if (v172_10).is_empty() { Space::new() } else {
              let v174_6: Path = concat_path(&(v171_6),&(v171_7_head));
              let v174_11: Space = routine_23(c, &(v174_6), &(v171_7_tail).make_space());
              drop(v174_6);
              compose(&(v172_10),&(v174_11))
            };
            drop(v172_10);
            let v172_13: Space = unite(&(v172_8),&(v172_12));
            v171_7.join_into((v172_13).clone());
            }
            v171_7_cursor.ascend(1);
          }
          drop(v171_7_cursor);
          compose(&(v170_5),&(v171_7))
        };
        drop(v170_5);
        let v170_9: Space = intersect(&(*CONSTANT_1),&(v170_2));
        drop(v170_2);
        let v170_10: Space = if has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
        drop(v170_9);
        let v170_12: Space = if (v170_10).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v169_6),&(v169_7_head));
          let mut v175_11 = Space::new();
          let mut v175_11_cursor = (v169_7_tail).read_zipper();
          for v175_11_byte in v175_11_cursor.child_mask().iter() {
            v175_11_cursor.descend_to_byte(v175_11_byte);
            {
            let v175_11_tail = v175_11_cursor.fork_read_zipper();
            let v175_11_head = Path::from_slice(&[v175_11_byte]);
            let v176_2: Space = singleton(&(v175_11_head));
            let v176_3: Space = intersect(&(*CONSTANT_1),&(v176_2));
            let v176_4: Space = if has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
            drop(v176_3);
            let v176_5: Space = subtract(&(*CONSTANT_0),&(v176_4));
            drop(v176_4);
            let v176_8: Space = if (v176_5).is_empty() { Space::new() } else {
              let v177_6: Path = concat_path(&(v175_6),&(v175_11_head));
              let v177_7: Space = routine_22(c, &(v177_6), &(v175_11_tail).make_space());
              compose(&(v176_5),&(v177_7))
            };
            drop(v176_5);
            let v176_9: Space = intersect(&(*CONSTANT_1),&(v176_2));
            drop(v176_2);
            let v176_10: Space = if has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
            drop(v176_9);
            let v176_12: Space = if (v176_10).is_empty() { Space::new() } else {
              let v178_6: Path = concat_path(&(v175_6),&(v175_11_head));
              let v178_11: Space = routine_15(c, &(v178_6), &(v175_11_tail).make_space());
              drop(v178_6);
              compose(&(v176_10),&(v178_11))
            };
            drop(v176_10);
            let v176_13: Space = unite(&(v176_8),&(v176_12));
            v175_11.join_into((v176_13).clone());
            }
            v175_11_cursor.ascend(1);
          }
          drop(v175_11_cursor);
          drop(v175_6);
          compose(&(v170_10),&(v175_11))
        };
        drop(v170_10);
        let v170_13: Space = unite(&(v170_8),&(v170_12));
        v169_7.join_into((v170_13).clone());
        }
        v169_7_cursor.ascend(1);
      }
      drop(v169_7_cursor);
      compose(&(v168_5),&(v169_7))
    };
    drop(v168_5);
    let v168_9: Space = intersect(&(*CONSTANT_1),&(v168_2));
    drop(v168_2);
    let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
    drop(v168_9);
    let v168_12: Space = if (v168_10).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v167_20_head));
      let mut v179_11 = Space::new();
      let mut v179_11_cursor = (v167_20_tail).read_zipper();
      for v179_11_byte in v179_11_cursor.child_mask().iter() {
        v179_11_cursor.descend_to_byte(v179_11_byte);
        {
        let v179_11_tail = v179_11_cursor.fork_read_zipper();
        let v179_11_head = Path::from_slice(&[v179_11_byte]);
        let v180_2: Space = singleton(&(v179_11_head));
        let v180_3: Space = intersect(&(*CONSTANT_1),&(v180_2));
        let v180_4: Space = if has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
        drop(v180_3);
        let v180_5: Space = subtract(&(*CONSTANT_0),&(v180_4));
        drop(v180_4);
        let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
          let v181_6: Path = concat_path(&(v179_6),&(v179_11_head));
          let mut v181_7 = Space::new();
          let mut v181_7_cursor = (v179_11_tail).read_zipper();
          for v181_7_byte in v181_7_cursor.child_mask().iter() {
            v181_7_cursor.descend_to_byte(v181_7_byte);
            {
            let v181_7_tail = v181_7_cursor.fork_read_zipper();
            let v181_7_head = Path::from_slice(&[v181_7_byte]);
            let v182_2: Space = singleton(&(v181_7_head));
            let v182_3: Space = intersect(&(*CONSTANT_1),&(v182_2));
            let v182_4: Space = if has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
            drop(v182_3);
            let v182_5: Space = subtract(&(*CONSTANT_0),&(v182_4));
            drop(v182_4);
            let v182_8: Space = if (v182_5).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v181_6),&(v181_7_head));
              let v183_7: Space = routine_22(c, &(v183_6), &(v181_7_tail).make_space());
              compose(&(v182_5),&(v183_7))
            };
            drop(v182_5);
            let v182_9: Space = intersect(&(*CONSTANT_1),&(v182_2));
            drop(v182_2);
            let v182_10: Space = if has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
            drop(v182_9);
            let v182_12: Space = if (v182_10).is_empty() { Space::new() } else {
              let v184_6: Path = concat_path(&(v181_6),&(v181_7_head));
              let v184_11: Space = routine_23(c, &(v184_6), &(v181_7_tail).make_space());
              drop(v184_6);
              compose(&(v182_10),&(v184_11))
            };
            drop(v182_10);
            let v182_13: Space = unite(&(v182_8),&(v182_12));
            v181_7.join_into((v182_13).clone());
            }
            v181_7_cursor.ascend(1);
          }
          drop(v181_7_cursor);
          drop(v181_6);
          compose(&(v180_5),&(v181_7))
        };
        drop(v180_5);
        let v180_9: Space = intersect(&(*CONSTANT_1),&(v180_2));
        drop(v180_2);
        let v180_10: Space = if has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
        drop(v180_9);
        let v180_11: Space = compose(&(v180_10),&(v179_11_tail));
        drop(v180_10);
        let v180_12: Space = unite(&(v180_8),&(v180_11));
        drop(v180_11);
        v179_11.join_into((v180_12).clone());
        }
        v179_11_cursor.ascend(1);
      }
      drop(v179_11_cursor);
      drop(v179_6);
      compose(&(v168_10),&(v179_11))
    };
    drop(v168_10);
    let v168_13: Space = unite(&(v168_8),&(v168_12));
    v167_20.join_into((v168_13).clone());
    }
    v167_20_cursor.ascend(1);
  }
  drop(v167_20_cursor);
  (v167_20).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v185_14 = Space::new();
  let mut v185_14_cursor = (*s0).read_zipper();
  for v185_14_byte in v185_14_cursor.child_mask().iter() {
    v185_14_cursor.descend_to_byte(v185_14_byte);
    {
    let v185_14_tail = v185_14_cursor.fork_read_zipper();
    let v185_14_head = Path::from_slice(&[v185_14_byte]);
    let v186_2: Space = singleton(&(v185_14_head));
    let v186_3: Space = intersect(&(*CONSTANT_1),&(v186_2));
    let v186_4: Space = if has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
    drop(v186_3);
    let v186_5: Space = subtract(&(*CONSTANT_0),&(v186_4));
    drop(v186_4);
    let v186_8: Space = if (v186_5).is_empty() { Space::new() } else {
      let v187_6: Path = concat_path(&(*p0),&(v185_14_head));
      let mut v187_7 = Space::new();
      let mut v187_7_cursor = (v185_14_tail).read_zipper();
      for v187_7_byte in v187_7_cursor.child_mask().iter() {
        v187_7_cursor.descend_to_byte(v187_7_byte);
        {
        let v187_7_tail = v187_7_cursor.fork_read_zipper();
        let v187_7_head = Path::from_slice(&[v187_7_byte]);
        let v188_2: Space = singleton(&(v187_7_head));
        let v188_3: Space = intersect(&(*CONSTANT_1),&(v188_2));
        let v188_4: Space = if has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
        drop(v188_3);
        let v188_5: Space = subtract(&(*CONSTANT_0),&(v188_4));
        drop(v188_4);
        let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
          let v189_6: Path = concat_path(&(v187_6),&(v187_7_head));
          let mut v189_7 = Space::new();
          let mut v189_7_cursor = (v187_7_tail).read_zipper();
          for v189_7_byte in v189_7_cursor.child_mask().iter() {
            v189_7_cursor.descend_to_byte(v189_7_byte);
            {
            let v189_7_tail = v189_7_cursor.fork_read_zipper();
            let v189_7_head = Path::from_slice(&[v189_7_byte]);
            let v190_2: Space = singleton(&(v189_7_head));
            let v190_3: Space = intersect(&(*CONSTANT_1),&(v190_2));
            let v190_4: Space = if has_head(&(v190_3)) { singleton(&[]) } else { Space::new() };
            drop(v190_3);
            let v190_5: Space = subtract(&(*CONSTANT_0),&(v190_4));
            drop(v190_4);
            let v190_8: Space = if (v190_5).is_empty() { Space::new() } else {
              let v191_6: Path = concat_path(&(v189_6),&(v189_7_head));
              let v191_7: Space = routine_22(c, &(v191_6), &(v189_7_tail).make_space());
              compose(&(v190_5),&(v191_7))
            };
            drop(v190_5);
            let v190_9: Space = intersect(&(*CONSTANT_1),&(v190_2));
            drop(v190_2);
            let v190_10: Space = if has_head(&(v190_9)) { singleton(&[]) } else { Space::new() };
            drop(v190_9);
            let v190_12: Space = if (v190_10).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v189_6),&(v189_7_head));
              let v192_11: Space = routine_23(c, &(v192_6), &(v189_7_tail).make_space());
              drop(v192_6);
              compose(&(v190_10),&(v192_11))
            };
            drop(v190_10);
            let v190_13: Space = unite(&(v190_8),&(v190_12));
            v189_7.join_into((v190_13).clone());
            }
            v189_7_cursor.ascend(1);
          }
          drop(v189_7_cursor);
          compose(&(v188_5),&(v189_7))
        };
        drop(v188_5);
        let v188_9: Space = intersect(&(*CONSTANT_1),&(v188_2));
        drop(v188_2);
        let v188_10: Space = if has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
        drop(v188_9);
        let v188_12: Space = if (v188_10).is_empty() { Space::new() } else {
          let v193_6: Path = concat_path(&(v187_6),&(v187_7_head));
          let mut v193_11 = Space::new();
          let mut v193_11_cursor = (v187_7_tail).read_zipper();
          for v193_11_byte in v193_11_cursor.child_mask().iter() {
            v193_11_cursor.descend_to_byte(v193_11_byte);
            {
            let v193_11_tail = v193_11_cursor.fork_read_zipper();
            let v193_11_head = Path::from_slice(&[v193_11_byte]);
            let v194_2: Space = singleton(&(v193_11_head));
            let v194_3: Space = intersect(&(*CONSTANT_1),&(v194_2));
            let v194_4: Space = if has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
            drop(v194_3);
            let v194_5: Space = subtract(&(*CONSTANT_0),&(v194_4));
            drop(v194_4);
            let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
              let v195_6: Path = concat_path(&(v193_6),&(v193_11_head));
              let v195_7: Space = routine_22(c, &(v195_6), &(v193_11_tail).make_space());
              compose(&(v194_5),&(v195_7))
            };
            drop(v194_5);
            let v194_9: Space = intersect(&(*CONSTANT_1),&(v194_2));
            drop(v194_2);
            let v194_10: Space = if has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
            drop(v194_9);
            let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
              let v196_6: Path = concat_path(&(v193_6),&(v193_11_head));
              let v196_11: Space = routine_15(c, &(v196_6), &(v193_11_tail).make_space());
              drop(v196_6);
              compose(&(v194_10),&(v196_11))
            };
            drop(v194_10);
            let v194_13: Space = unite(&(v194_8),&(v194_12));
            v193_11.join_into((v194_13).clone());
            }
            v193_11_cursor.ascend(1);
          }
          drop(v193_11_cursor);
          drop(v193_6);
          compose(&(v188_10),&(v193_11))
        };
        drop(v188_10);
        let v188_13: Space = unite(&(v188_8),&(v188_12));
        v187_7.join_into((v188_13).clone());
        }
        v187_7_cursor.ascend(1);
      }
      drop(v187_7_cursor);
      drop(v187_6);
      compose(&(v186_5),&(v187_7))
    };
    drop(v186_5);
    let v186_9: Space = intersect(&(*CONSTANT_1),&(v186_2));
    drop(v186_2);
    let v186_10: Space = if has_head(&(v186_9)) { singleton(&[]) } else { Space::new() };
    drop(v186_9);
    let v186_11: Space = compose(&(v186_10),&(v185_14_tail));
    drop(v186_10);
    let v186_12: Space = unite(&(v186_8),&(v186_11));
    drop(v186_11);
    v185_14.join_into((v186_12).clone());
    }
    v185_14_cursor.ascend(1);
  }
  drop(v185_14_cursor);
  (v185_14).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v197_20 = Space::new();
  let mut v197_20_cursor = (*s0).read_zipper();
  for v197_20_byte in v197_20_cursor.child_mask().iter() {
    v197_20_cursor.descend_to_byte(v197_20_byte);
    {
    let v197_20_tail = v197_20_cursor.fork_read_zipper();
    let v197_20_head = Path::from_slice(&[v197_20_byte]);
    let v198_2: Space = singleton(&(v197_20_head));
    let v198_3: Space = intersect(&(*CONSTANT_1),&(v198_2));
    let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
    drop(v198_3);
    let v198_5: Space = subtract(&(*CONSTANT_0),&(v198_4));
    drop(v198_4);
    let v198_8: Space = if (v198_5).is_empty() { Space::new() } else {
      let v199_6: Path = concat_path(&(*p0),&(v197_20_head));
      let mut v199_7 = Space::new();
      let mut v199_7_cursor = (v197_20_tail).read_zipper();
      for v199_7_byte in v199_7_cursor.child_mask().iter() {
        v199_7_cursor.descend_to_byte(v199_7_byte);
        {
        let v199_7_tail = v199_7_cursor.fork_read_zipper();
        let v199_7_head = Path::from_slice(&[v199_7_byte]);
        let v200_2: Space = singleton(&(v199_7_head));
        let v200_3: Space = intersect(&(*CONSTANT_1),&(v200_2));
        let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
        drop(v200_3);
        let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
        drop(v200_4);
        let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
          let v201_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let mut v201_7 = Space::new();
          let mut v201_7_cursor = (v199_7_tail).read_zipper();
          for v201_7_byte in v201_7_cursor.child_mask().iter() {
            v201_7_cursor.descend_to_byte(v201_7_byte);
            {
            let v201_7_tail = v201_7_cursor.fork_read_zipper();
            let v201_7_head = Path::from_slice(&[v201_7_byte]);
            let v202_2: Space = singleton(&(v201_7_head));
            let v202_3: Space = intersect(&(*CONSTANT_1),&(v202_2));
            let v202_4: Space = if has_head(&(v202_3)) { singleton(&[]) } else { Space::new() };
            drop(v202_3);
            let v202_5: Space = subtract(&(*CONSTANT_0),&(v202_4));
            drop(v202_4);
            let v202_8: Space = if (v202_5).is_empty() { Space::new() } else {
              let v203_6: Path = concat_path(&(v201_6),&(v201_7_head));
              let v203_7: Space = routine_24(c, &(v203_6), &(v201_7_tail).make_space());
              compose(&(v202_5),&(v203_7))
            };
            drop(v202_5);
            let v202_9: Space = intersect(&(*CONSTANT_1),&(v202_2));
            drop(v202_2);
            let v202_10: Space = if has_head(&(v202_9)) { singleton(&[]) } else { Space::new() };
            drop(v202_9);
            let v202_12: Space = if (v202_10).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v201_6),&(v201_7_head));
              let v204_11: Space = routine_25(c, &(v204_6), &(v201_7_tail).make_space());
              drop(v204_6);
              compose(&(v202_10),&(v204_11))
            };
            drop(v202_10);
            let v202_13: Space = unite(&(v202_8),&(v202_12));
            v201_7.join_into((v202_13).clone());
            }
            v201_7_cursor.ascend(1);
          }
          drop(v201_7_cursor);
          compose(&(v200_5),&(v201_7))
        };
        drop(v200_5);
        let v200_9: Space = intersect(&(*CONSTANT_1),&(v200_2));
        drop(v200_2);
        let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
        drop(v200_9);
        let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v199_6),&(v199_7_head));
          let mut v205_11 = Space::new();
          let mut v205_11_cursor = (v199_7_tail).read_zipper();
          for v205_11_byte in v205_11_cursor.child_mask().iter() {
            v205_11_cursor.descend_to_byte(v205_11_byte);
            {
            let v205_11_tail = v205_11_cursor.fork_read_zipper();
            let v205_11_head = Path::from_slice(&[v205_11_byte]);
            let v206_2: Space = singleton(&(v205_11_head));
            let v206_3: Space = intersect(&(*CONSTANT_1),&(v206_2));
            let v206_4: Space = if has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
            drop(v206_3);
            let v206_5: Space = subtract(&(*CONSTANT_0),&(v206_4));
            drop(v206_4);
            let v206_8: Space = if (v206_5).is_empty() { Space::new() } else {
              let v207_6: Path = concat_path(&(v205_6),&(v205_11_head));
              let v207_7: Space = routine_24(c, &(v207_6), &(v205_11_tail).make_space());
              compose(&(v206_5),&(v207_7))
            };
            drop(v206_5);
            let v206_9: Space = intersect(&(*CONSTANT_1),&(v206_2));
            drop(v206_2);
            let v206_10: Space = if has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
            drop(v206_9);
            let v206_12: Space = if (v206_10).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v205_6),&(v205_11_head));
              let v208_11: Space = routine_12(c, &(v208_6), &(v205_11_tail).make_space());
              drop(v208_6);
              compose(&(v206_10),&(v208_11))
            };
            drop(v206_10);
            let v206_13: Space = unite(&(v206_8),&(v206_12));
            v205_11.join_into((v206_13).clone());
            }
            v205_11_cursor.ascend(1);
          }
          drop(v205_11_cursor);
          drop(v205_6);
          compose(&(v200_10),&(v205_11))
        };
        drop(v200_10);
        let v200_13: Space = unite(&(v200_8),&(v200_12));
        v199_7.join_into((v200_13).clone());
        }
        v199_7_cursor.ascend(1);
      }
      drop(v199_7_cursor);
      compose(&(v198_5),&(v199_7))
    };
    drop(v198_5);
    let v198_9: Space = intersect(&(*CONSTANT_1),&(v198_2));
    drop(v198_2);
    let v198_10: Space = if has_head(&(v198_9)) { singleton(&[]) } else { Space::new() };
    drop(v198_9);
    let v198_12: Space = if (v198_10).is_empty() { Space::new() } else {
      let v209_6: Path = concat_path(&(*p0),&(v197_20_head));
      let mut v209_11 = Space::new();
      let mut v209_11_cursor = (v197_20_tail).read_zipper();
      for v209_11_byte in v209_11_cursor.child_mask().iter() {
        v209_11_cursor.descend_to_byte(v209_11_byte);
        {
        let v209_11_tail = v209_11_cursor.fork_read_zipper();
        let v209_11_head = Path::from_slice(&[v209_11_byte]);
        let v210_2: Space = singleton(&(v209_11_head));
        let v210_3: Space = intersect(&(*CONSTANT_1),&(v210_2));
        let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
        drop(v210_3);
        let v210_5: Space = subtract(&(*CONSTANT_0),&(v210_4));
        drop(v210_4);
        let v210_8: Space = if (v210_5).is_empty() { Space::new() } else {
          let v211_6: Path = concat_path(&(v209_6),&(v209_11_head));
          let mut v211_7 = Space::new();
          let mut v211_7_cursor = (v209_11_tail).read_zipper();
          for v211_7_byte in v211_7_cursor.child_mask().iter() {
            v211_7_cursor.descend_to_byte(v211_7_byte);
            {
            let v211_7_tail = v211_7_cursor.fork_read_zipper();
            let v211_7_head = Path::from_slice(&[v211_7_byte]);
            let v212_2: Space = singleton(&(v211_7_head));
            let v212_3: Space = intersect(&(*CONSTANT_1),&(v212_2));
            let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
            drop(v212_3);
            let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
            drop(v212_4);
            let v212_8: Space = if (v212_5).is_empty() { Space::new() } else {
              let v213_6: Path = concat_path(&(v211_6),&(v211_7_head));
              let v213_7: Space = routine_24(c, &(v213_6), &(v211_7_tail).make_space());
              compose(&(v212_5),&(v213_7))
            };
            drop(v212_5);
            let v212_9: Space = intersect(&(*CONSTANT_1),&(v212_2));
            drop(v212_2);
            let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
            drop(v212_9);
            let v212_12: Space = if (v212_10).is_empty() { Space::new() } else {
              let v214_6: Path = concat_path(&(v211_6),&(v211_7_head));
              let v214_11: Space = routine_25(c, &(v214_6), &(v211_7_tail).make_space());
              drop(v214_6);
              compose(&(v212_10),&(v214_11))
            };
            drop(v212_10);
            let v212_13: Space = unite(&(v212_8),&(v212_12));
            v211_7.join_into((v212_13).clone());
            }
            v211_7_cursor.ascend(1);
          }
          drop(v211_7_cursor);
          drop(v211_6);
          compose(&(v210_5),&(v211_7))
        };
        drop(v210_5);
        let v210_9: Space = intersect(&(*CONSTANT_1),&(v210_2));
        drop(v210_2);
        let v210_10: Space = if has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
        drop(v210_9);
        let v210_11: Space = compose(&(v210_10),&(v209_11_tail));
        drop(v210_10);
        let v210_12: Space = unite(&(v210_8),&(v210_11));
        drop(v210_11);
        v209_11.join_into((v210_12).clone());
        }
        v209_11_cursor.ascend(1);
      }
      drop(v209_11_cursor);
      drop(v209_6);
      compose(&(v198_10),&(v209_11))
    };
    drop(v198_10);
    let v198_13: Space = unite(&(v198_8),&(v198_12));
    v197_20.join_into((v198_13).clone());
    }
    v197_20_cursor.ascend(1);
  }
  drop(v197_20_cursor);
  (v197_20).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v215_14 = Space::new();
  let mut v215_14_cursor = (*s0).read_zipper();
  for v215_14_byte in v215_14_cursor.child_mask().iter() {
    v215_14_cursor.descend_to_byte(v215_14_byte);
    {
    let v215_14_tail = v215_14_cursor.fork_read_zipper();
    let v215_14_head = Path::from_slice(&[v215_14_byte]);
    let v216_2: Space = singleton(&(v215_14_head));
    let v216_3: Space = intersect(&(*CONSTANT_1),&(v216_2));
    let v216_4: Space = if has_head(&(v216_3)) { singleton(&[]) } else { Space::new() };
    drop(v216_3);
    let v216_5: Space = subtract(&(*CONSTANT_0),&(v216_4));
    drop(v216_4);
    let v216_8: Space = if (v216_5).is_empty() { Space::new() } else {
      let v217_6: Path = concat_path(&(*p0),&(v215_14_head));
      let mut v217_7 = Space::new();
      let mut v217_7_cursor = (v215_14_tail).read_zipper();
      for v217_7_byte in v217_7_cursor.child_mask().iter() {
        v217_7_cursor.descend_to_byte(v217_7_byte);
        {
        let v217_7_tail = v217_7_cursor.fork_read_zipper();
        let v217_7_head = Path::from_slice(&[v217_7_byte]);
        let v218_2: Space = singleton(&(v217_7_head));
        let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
        let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
        drop(v218_3);
        let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
        drop(v218_4);
        let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
          let v219_6: Path = concat_path(&(v217_6),&(v217_7_head));
          let mut v219_7 = Space::new();
          let mut v219_7_cursor = (v217_7_tail).read_zipper();
          for v219_7_byte in v219_7_cursor.child_mask().iter() {
            v219_7_cursor.descend_to_byte(v219_7_byte);
            {
            let v219_7_tail = v219_7_cursor.fork_read_zipper();
            let v219_7_head = Path::from_slice(&[v219_7_byte]);
            let v220_2: Space = singleton(&(v219_7_head));
            let v220_3: Space = intersect(&(*CONSTANT_1),&(v220_2));
            let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
            drop(v220_3);
            let v220_5: Space = subtract(&(*CONSTANT_0),&(v220_4));
            drop(v220_4);
            let v220_8: Space = if (v220_5).is_empty() { Space::new() } else {
              let v221_6: Path = concat_path(&(v219_6),&(v219_7_head));
              let v221_7: Space = routine_24(c, &(v221_6), &(v219_7_tail).make_space());
              compose(&(v220_5),&(v221_7))
            };
            drop(v220_5);
            let v220_9: Space = intersect(&(*CONSTANT_1),&(v220_2));
            drop(v220_2);
            let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
            drop(v220_9);
            let v220_12: Space = if (v220_10).is_empty() { Space::new() } else {
              let v222_6: Path = concat_path(&(v219_6),&(v219_7_head));
              let v222_11: Space = routine_25(c, &(v222_6), &(v219_7_tail).make_space());
              drop(v222_6);
              compose(&(v220_10),&(v222_11))
            };
            drop(v220_10);
            let v220_13: Space = unite(&(v220_8),&(v220_12));
            v219_7.join_into((v220_13).clone());
            }
            v219_7_cursor.ascend(1);
          }
          drop(v219_7_cursor);
          compose(&(v218_5),&(v219_7))
        };
        drop(v218_5);
        let v218_9: Space = intersect(&(*CONSTANT_1),&(v218_2));
        drop(v218_2);
        let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
        drop(v218_9);
        let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
          let v223_6: Path = concat_path(&(v217_6),&(v217_7_head));
          let mut v223_11 = Space::new();
          let mut v223_11_cursor = (v217_7_tail).read_zipper();
          for v223_11_byte in v223_11_cursor.child_mask().iter() {
            v223_11_cursor.descend_to_byte(v223_11_byte);
            {
            let v223_11_tail = v223_11_cursor.fork_read_zipper();
            let v223_11_head = Path::from_slice(&[v223_11_byte]);
            let v224_2: Space = singleton(&(v223_11_head));
            let v224_3: Space = intersect(&(*CONSTANT_1),&(v224_2));
            let v224_4: Space = if has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
            drop(v224_3);
            let v224_5: Space = subtract(&(*CONSTANT_0),&(v224_4));
            drop(v224_4);
            let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
              let v225_6: Path = concat_path(&(v223_6),&(v223_11_head));
              let v225_7: Space = routine_24(c, &(v225_6), &(v223_11_tail).make_space());
              compose(&(v224_5),&(v225_7))
            };
            drop(v224_5);
            let v224_9: Space = intersect(&(*CONSTANT_1),&(v224_2));
            drop(v224_2);
            let v224_10: Space = if has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
            drop(v224_9);
            let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
              let v226_6: Path = concat_path(&(v223_6),&(v223_11_head));
              let v226_11: Space = routine_12(c, &(v226_6), &(v223_11_tail).make_space());
              drop(v226_6);
              compose(&(v224_10),&(v226_11))
            };
            drop(v224_10);
            let v224_13: Space = unite(&(v224_8),&(v224_12));
            v223_11.join_into((v224_13).clone());
            }
            v223_11_cursor.ascend(1);
          }
          drop(v223_11_cursor);
          drop(v223_6);
          compose(&(v218_10),&(v223_11))
        };
        drop(v218_10);
        let v218_13: Space = unite(&(v218_8),&(v218_12));
        v217_7.join_into((v218_13).clone());
        }
        v217_7_cursor.ascend(1);
      }
      drop(v217_7_cursor);
      drop(v217_6);
      compose(&(v216_5),&(v217_7))
    };
    drop(v216_5);
    let v216_9: Space = intersect(&(*CONSTANT_1),&(v216_2));
    drop(v216_2);
    let v216_10: Space = if has_head(&(v216_9)) { singleton(&[]) } else { Space::new() };
    drop(v216_9);
    let v216_11: Space = compose(&(v216_10),&(v215_14_tail));
    drop(v216_10);
    let v216_12: Space = unite(&(v216_8),&(v216_11));
    drop(v216_11);
    v215_14.join_into((v216_12).clone());
    }
    v215_14_cursor.ascend(1);
  }
  drop(v215_14_cursor);
  (v215_14).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v228_20 = Space::new();
  let mut v228_20_cursor = (*s0).read_zipper();
  for v228_20_byte in v228_20_cursor.child_mask().iter() {
    v228_20_cursor.descend_to_byte(v228_20_byte);
    {
    let v228_20_tail = v228_20_cursor.fork_read_zipper();
    let v228_20_head = Path::from_slice(&[v228_20_byte]);
    let v229_2: Space = singleton(&(v228_20_head));
    let v229_3: Space = intersect(&(*CONSTANT_1),&(v229_2));
    let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
    drop(v229_3);
    let v229_5: Space = subtract(&(*CONSTANT_0),&(v229_4));
    drop(v229_4);
    let v229_8: Space = if (v229_5).is_empty() { Space::new() } else {
      let v230_6: Path = concat_path(&(*p0),&(v228_20_head));
      let mut v230_7 = Space::new();
      let mut v230_7_cursor = (v228_20_tail).read_zipper();
      for v230_7_byte in v230_7_cursor.child_mask().iter() {
        v230_7_cursor.descend_to_byte(v230_7_byte);
        {
        let v230_7_tail = v230_7_cursor.fork_read_zipper();
        let v230_7_head = Path::from_slice(&[v230_7_byte]);
        let v231_2: Space = singleton(&(v230_7_head));
        let v231_3: Space = intersect(&(*CONSTANT_1),&(v231_2));
        let v231_4: Space = if has_head(&(v231_3)) { singleton(&[]) } else { Space::new() };
        drop(v231_3);
        let v231_5: Space = subtract(&(*CONSTANT_0),&(v231_4));
        drop(v231_4);
        let v231_8: Space = if (v231_5).is_empty() { Space::new() } else {
          let v232_6: Path = concat_path(&(v230_6),&(v230_7_head));
          let mut v232_7 = Space::new();
          let mut v232_7_cursor = (v230_7_tail).read_zipper();
          for v232_7_byte in v232_7_cursor.child_mask().iter() {
            v232_7_cursor.descend_to_byte(v232_7_byte);
            {
            let v232_7_tail = v232_7_cursor.fork_read_zipper();
            let v232_7_head = Path::from_slice(&[v232_7_byte]);
            let v233_2: Space = singleton(&(v232_7_head));
            let v233_3: Space = intersect(&(*CONSTANT_1),&(v233_2));
            let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
            drop(v233_3);
            let v233_5: Space = subtract(&(*CONSTANT_0),&(v233_4));
            drop(v233_4);
            let v233_8: Space = if (v233_5).is_empty() { Space::new() } else {
              let v234_6: Path = concat_path(&(v232_6),&(v232_7_head));
              let v234_7: Space = routine_26(c, &(v234_6), &(v232_7_tail).make_space());
              compose(&(v233_5),&(v234_7))
            };
            drop(v233_5);
            let v233_9: Space = intersect(&(*CONSTANT_1),&(v233_2));
            drop(v233_2);
            let v233_10: Space = if has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
            drop(v233_9);
            let v233_12: Space = if (v233_10).is_empty() { Space::new() } else {
              let v235_6: Path = concat_path(&(v232_6),&(v232_7_head));
              let v235_11: Space = routine_27(c, &(v235_6), &(v232_7_tail).make_space());
              drop(v235_6);
              compose(&(v233_10),&(v235_11))
            };
            drop(v233_10);
            let v233_13: Space = unite(&(v233_8),&(v233_12));
            v232_7.join_into((v233_13).clone());
            }
            v232_7_cursor.ascend(1);
          }
          drop(v232_7_cursor);
          compose(&(v231_5),&(v232_7))
        };
        drop(v231_5);
        let v231_9: Space = intersect(&(*CONSTANT_1),&(v231_2));
        drop(v231_2);
        let v231_10: Space = if has_head(&(v231_9)) { singleton(&[]) } else { Space::new() };
        drop(v231_9);
        let v231_12: Space = if (v231_10).is_empty() { Space::new() } else {
          let v236_6: Path = concat_path(&(v230_6),&(v230_7_head));
          let mut v236_11 = Space::new();
          let mut v236_11_cursor = (v230_7_tail).read_zipper();
          for v236_11_byte in v236_11_cursor.child_mask().iter() {
            v236_11_cursor.descend_to_byte(v236_11_byte);
            {
            let v236_11_tail = v236_11_cursor.fork_read_zipper();
            let v236_11_head = Path::from_slice(&[v236_11_byte]);
            let v237_2: Space = singleton(&(v236_11_head));
            let v237_3: Space = intersect(&(*CONSTANT_1),&(v237_2));
            let v237_4: Space = if has_head(&(v237_3)) { singleton(&[]) } else { Space::new() };
            drop(v237_3);
            let v237_5: Space = subtract(&(*CONSTANT_0),&(v237_4));
            drop(v237_4);
            let v237_8: Space = if (v237_5).is_empty() { Space::new() } else {
              let v238_6: Path = concat_path(&(v236_6),&(v236_11_head));
              let v238_7: Space = routine_26(c, &(v238_6), &(v236_11_tail).make_space());
              compose(&(v237_5),&(v238_7))
            };
            drop(v237_5);
            let v237_9: Space = intersect(&(*CONSTANT_1),&(v237_2));
            drop(v237_2);
            let v237_10: Space = if has_head(&(v237_9)) { singleton(&[]) } else { Space::new() };
            drop(v237_9);
            let v237_12: Space = if (v237_10).is_empty() { Space::new() } else {
              let v239_6: Path = concat_path(&(v236_6),&(v236_11_head));
              let v239_11: Space = routine_15(c, &(v239_6), &(v236_11_tail).make_space());
              drop(v239_6);
              compose(&(v237_10),&(v239_11))
            };
            drop(v237_10);
            let v237_13: Space = unite(&(v237_8),&(v237_12));
            v236_11.join_into((v237_13).clone());
            }
            v236_11_cursor.ascend(1);
          }
          drop(v236_11_cursor);
          drop(v236_6);
          compose(&(v231_10),&(v236_11))
        };
        drop(v231_10);
        let v231_13: Space = unite(&(v231_8),&(v231_12));
        v230_7.join_into((v231_13).clone());
        }
        v230_7_cursor.ascend(1);
      }
      drop(v230_7_cursor);
      compose(&(v229_5),&(v230_7))
    };
    drop(v229_5);
    let v229_9: Space = intersect(&(*CONSTANT_1),&(v229_2));
    drop(v229_2);
    let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
    drop(v229_9);
    let v229_12: Space = if (v229_10).is_empty() { Space::new() } else {
      let v240_6: Path = concat_path(&(*p0),&(v228_20_head));
      let mut v240_11 = Space::new();
      let mut v240_11_cursor = (v228_20_tail).read_zipper();
      for v240_11_byte in v240_11_cursor.child_mask().iter() {
        v240_11_cursor.descend_to_byte(v240_11_byte);
        {
        let v240_11_tail = v240_11_cursor.fork_read_zipper();
        let v240_11_head = Path::from_slice(&[v240_11_byte]);
        let v241_2: Space = singleton(&(v240_11_head));
        let v241_3: Space = intersect(&(*CONSTANT_1),&(v241_2));
        let v241_4: Space = if has_head(&(v241_3)) { singleton(&[]) } else { Space::new() };
        drop(v241_3);
        let v241_5: Space = subtract(&(*CONSTANT_0),&(v241_4));
        drop(v241_4);
        let v241_8: Space = if (v241_5).is_empty() { Space::new() } else {
          let v242_6: Path = concat_path(&(v240_6),&(v240_11_head));
          let mut v242_7 = Space::new();
          let mut v242_7_cursor = (v240_11_tail).read_zipper();
          for v242_7_byte in v242_7_cursor.child_mask().iter() {
            v242_7_cursor.descend_to_byte(v242_7_byte);
            {
            let v242_7_tail = v242_7_cursor.fork_read_zipper();
            let v242_7_head = Path::from_slice(&[v242_7_byte]);
            let v243_2: Space = singleton(&(v242_7_head));
            let v243_3: Space = intersect(&(*CONSTANT_1),&(v243_2));
            let v243_4: Space = if has_head(&(v243_3)) { singleton(&[]) } else { Space::new() };
            drop(v243_3);
            let v243_5: Space = subtract(&(*CONSTANT_0),&(v243_4));
            drop(v243_4);
            let v243_8: Space = if (v243_5).is_empty() { Space::new() } else {
              let v244_6: Path = concat_path(&(v242_6),&(v242_7_head));
              let v244_7: Space = routine_26(c, &(v244_6), &(v242_7_tail).make_space());
              compose(&(v243_5),&(v244_7))
            };
            drop(v243_5);
            let v243_9: Space = intersect(&(*CONSTANT_1),&(v243_2));
            drop(v243_2);
            let v243_10: Space = if has_head(&(v243_9)) { singleton(&[]) } else { Space::new() };
            drop(v243_9);
            let v243_12: Space = if (v243_10).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v242_6),&(v242_7_head));
              let v245_11: Space = routine_27(c, &(v245_6), &(v242_7_tail).make_space());
              drop(v245_6);
              compose(&(v243_10),&(v245_11))
            };
            drop(v243_10);
            let v243_13: Space = unite(&(v243_8),&(v243_12));
            v242_7.join_into((v243_13).clone());
            }
            v242_7_cursor.ascend(1);
          }
          drop(v242_7_cursor);
          drop(v242_6);
          compose(&(v241_5),&(v242_7))
        };
        drop(v241_5);
        let v241_9: Space = intersect(&(*CONSTANT_1),&(v241_2));
        drop(v241_2);
        let v241_10: Space = if has_head(&(v241_9)) { singleton(&[]) } else { Space::new() };
        drop(v241_9);
        let v241_11: Space = compose(&(v241_10),&(v240_11_tail));
        drop(v241_10);
        let v241_12: Space = unite(&(v241_8),&(v241_11));
        drop(v241_11);
        v240_11.join_into((v241_12).clone());
        }
        v240_11_cursor.ascend(1);
      }
      drop(v240_11_cursor);
      drop(v240_6);
      compose(&(v229_10),&(v240_11))
    };
    drop(v229_10);
    let v229_13: Space = unite(&(v229_8),&(v229_12));
    v228_20.join_into((v229_13).clone());
    }
    v228_20_cursor.ascend(1);
  }
  drop(v228_20_cursor);
  (v228_20).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v246_14 = Space::new();
  let mut v246_14_cursor = (*s0).read_zipper();
  for v246_14_byte in v246_14_cursor.child_mask().iter() {
    v246_14_cursor.descend_to_byte(v246_14_byte);
    {
    let v246_14_tail = v246_14_cursor.fork_read_zipper();
    let v246_14_head = Path::from_slice(&[v246_14_byte]);
    let v247_2: Space = singleton(&(v246_14_head));
    let v247_3: Space = intersect(&(*CONSTANT_1),&(v247_2));
    let v247_4: Space = if has_head(&(v247_3)) { singleton(&[]) } else { Space::new() };
    drop(v247_3);
    let v247_5: Space = subtract(&(*CONSTANT_0),&(v247_4));
    drop(v247_4);
    let v247_8: Space = if (v247_5).is_empty() { Space::new() } else {
      let v248_6: Path = concat_path(&(*p0),&(v246_14_head));
      let mut v248_7 = Space::new();
      let mut v248_7_cursor = (v246_14_tail).read_zipper();
      for v248_7_byte in v248_7_cursor.child_mask().iter() {
        v248_7_cursor.descend_to_byte(v248_7_byte);
        {
        let v248_7_tail = v248_7_cursor.fork_read_zipper();
        let v248_7_head = Path::from_slice(&[v248_7_byte]);
        let v249_2: Space = singleton(&(v248_7_head));
        let v249_3: Space = intersect(&(*CONSTANT_1),&(v249_2));
        let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
        drop(v249_3);
        let v249_5: Space = subtract(&(*CONSTANT_0),&(v249_4));
        drop(v249_4);
        let v249_8: Space = if (v249_5).is_empty() { Space::new() } else {
          let v250_6: Path = concat_path(&(v248_6),&(v248_7_head));
          let mut v250_7 = Space::new();
          let mut v250_7_cursor = (v248_7_tail).read_zipper();
          for v250_7_byte in v250_7_cursor.child_mask().iter() {
            v250_7_cursor.descend_to_byte(v250_7_byte);
            {
            let v250_7_tail = v250_7_cursor.fork_read_zipper();
            let v250_7_head = Path::from_slice(&[v250_7_byte]);
            let v251_2: Space = singleton(&(v250_7_head));
            let v251_3: Space = intersect(&(*CONSTANT_1),&(v251_2));
            let v251_4: Space = if has_head(&(v251_3)) { singleton(&[]) } else { Space::new() };
            drop(v251_3);
            let v251_5: Space = subtract(&(*CONSTANT_0),&(v251_4));
            drop(v251_4);
            let v251_8: Space = if (v251_5).is_empty() { Space::new() } else {
              let v252_6: Path = concat_path(&(v250_6),&(v250_7_head));
              let v252_7: Space = routine_26(c, &(v252_6), &(v250_7_tail).make_space());
              compose(&(v251_5),&(v252_7))
            };
            drop(v251_5);
            let v251_9: Space = intersect(&(*CONSTANT_1),&(v251_2));
            drop(v251_2);
            let v251_10: Space = if has_head(&(v251_9)) { singleton(&[]) } else { Space::new() };
            drop(v251_9);
            let v251_12: Space = if (v251_10).is_empty() { Space::new() } else {
              let v253_6: Path = concat_path(&(v250_6),&(v250_7_head));
              let v253_11: Space = routine_27(c, &(v253_6), &(v250_7_tail).make_space());
              drop(v253_6);
              compose(&(v251_10),&(v253_11))
            };
            drop(v251_10);
            let v251_13: Space = unite(&(v251_8),&(v251_12));
            v250_7.join_into((v251_13).clone());
            }
            v250_7_cursor.ascend(1);
          }
          drop(v250_7_cursor);
          compose(&(v249_5),&(v250_7))
        };
        drop(v249_5);
        let v249_9: Space = intersect(&(*CONSTANT_1),&(v249_2));
        drop(v249_2);
        let v249_10: Space = if has_head(&(v249_9)) { singleton(&[]) } else { Space::new() };
        drop(v249_9);
        let v249_12: Space = if (v249_10).is_empty() { Space::new() } else {
          let v254_6: Path = concat_path(&(v248_6),&(v248_7_head));
          let mut v254_11 = Space::new();
          let mut v254_11_cursor = (v248_7_tail).read_zipper();
          for v254_11_byte in v254_11_cursor.child_mask().iter() {
            v254_11_cursor.descend_to_byte(v254_11_byte);
            {
            let v254_11_tail = v254_11_cursor.fork_read_zipper();
            let v254_11_head = Path::from_slice(&[v254_11_byte]);
            let v255_2: Space = singleton(&(v254_11_head));
            let v255_3: Space = intersect(&(*CONSTANT_1),&(v255_2));
            let v255_4: Space = if has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
            drop(v255_3);
            let v255_5: Space = subtract(&(*CONSTANT_0),&(v255_4));
            drop(v255_4);
            let v255_8: Space = if (v255_5).is_empty() { Space::new() } else {
              let v256_6: Path = concat_path(&(v254_6),&(v254_11_head));
              let v256_7: Space = routine_26(c, &(v256_6), &(v254_11_tail).make_space());
              compose(&(v255_5),&(v256_7))
            };
            drop(v255_5);
            let v255_9: Space = intersect(&(*CONSTANT_1),&(v255_2));
            drop(v255_2);
            let v255_10: Space = if has_head(&(v255_9)) { singleton(&[]) } else { Space::new() };
            drop(v255_9);
            let v255_12: Space = if (v255_10).is_empty() { Space::new() } else {
              let v257_6: Path = concat_path(&(v254_6),&(v254_11_head));
              let v257_11: Space = routine_15(c, &(v257_6), &(v254_11_tail).make_space());
              drop(v257_6);
              compose(&(v255_10),&(v257_11))
            };
            drop(v255_10);
            let v255_13: Space = unite(&(v255_8),&(v255_12));
            v254_11.join_into((v255_13).clone());
            }
            v254_11_cursor.ascend(1);
          }
          drop(v254_11_cursor);
          drop(v254_6);
          compose(&(v249_10),&(v254_11))
        };
        drop(v249_10);
        let v249_13: Space = unite(&(v249_8),&(v249_12));
        v248_7.join_into((v249_13).clone());
        }
        v248_7_cursor.ascend(1);
      }
      drop(v248_7_cursor);
      drop(v248_6);
      compose(&(v247_5),&(v248_7))
    };
    drop(v247_5);
    let v247_9: Space = intersect(&(*CONSTANT_1),&(v247_2));
    drop(v247_2);
    let v247_10: Space = if has_head(&(v247_9)) { singleton(&[]) } else { Space::new() };
    drop(v247_9);
    let v247_11: Space = compose(&(v247_10),&(v246_14_tail));
    drop(v247_10);
    let v247_12: Space = unite(&(v247_8),&(v247_11));
    drop(v247_11);
    v246_14.join_into((v247_12).clone());
    }
    v246_14_cursor.ascend(1);
  }
  drop(v246_14_cursor);
  (v246_14).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v259_20 = Space::new();
  let mut v259_20_cursor = (*s0).read_zipper();
  for v259_20_byte in v259_20_cursor.child_mask().iter() {
    v259_20_cursor.descend_to_byte(v259_20_byte);
    {
    let v259_20_tail = v259_20_cursor.fork_read_zipper();
    let v259_20_head = Path::from_slice(&[v259_20_byte]);
    let v260_2: Space = singleton(&(v259_20_head));
    let v260_3: Space = intersect(&(*CONSTANT_1),&(v260_2));
    let v260_4: Space = if has_head(&(v260_3)) { singleton(&[]) } else { Space::new() };
    drop(v260_3);
    let v260_5: Space = subtract(&(*CONSTANT_0),&(v260_4));
    drop(v260_4);
    let v260_8: Space = if (v260_5).is_empty() { Space::new() } else {
      let v261_6: Path = concat_path(&(*p0),&(v259_20_head));
      let mut v261_7 = Space::new();
      let mut v261_7_cursor = (v259_20_tail).read_zipper();
      for v261_7_byte in v261_7_cursor.child_mask().iter() {
        v261_7_cursor.descend_to_byte(v261_7_byte);
        {
        let v261_7_tail = v261_7_cursor.fork_read_zipper();
        let v261_7_head = Path::from_slice(&[v261_7_byte]);
        let v262_2: Space = singleton(&(v261_7_head));
        let v262_3: Space = intersect(&(*CONSTANT_1),&(v262_2));
        let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
        drop(v262_3);
        let v262_5: Space = subtract(&(*CONSTANT_0),&(v262_4));
        drop(v262_4);
        let v262_8: Space = if (v262_5).is_empty() { Space::new() } else {
          let v263_6: Path = concat_path(&(v261_6),&(v261_7_head));
          let mut v263_7 = Space::new();
          let mut v263_7_cursor = (v261_7_tail).read_zipper();
          for v263_7_byte in v263_7_cursor.child_mask().iter() {
            v263_7_cursor.descend_to_byte(v263_7_byte);
            {
            let v263_7_tail = v263_7_cursor.fork_read_zipper();
            let v263_7_head = Path::from_slice(&[v263_7_byte]);
            let v264_2: Space = singleton(&(v263_7_head));
            let v264_3: Space = intersect(&(*CONSTANT_1),&(v264_2));
            let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
            drop(v264_3);
            let v264_5: Space = subtract(&(*CONSTANT_0),&(v264_4));
            drop(v264_4);
            let v264_8: Space = if (v264_5).is_empty() { Space::new() } else {
              let v265_6: Path = concat_path(&(v263_6),&(v263_7_head));
              let v265_7: Space = routine_28(c, &(v265_6), &(v263_7_tail).make_space());
              compose(&(v264_5),&(v265_7))
            };
            drop(v264_5);
            let v264_9: Space = intersect(&(*CONSTANT_1),&(v264_2));
            drop(v264_2);
            let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
            drop(v264_9);
            let v264_12: Space = if (v264_10).is_empty() { Space::new() } else {
              let v266_6: Path = concat_path(&(v263_6),&(v263_7_head));
              let v266_11: Space = routine_29(c, &(v266_6), &(v263_7_tail).make_space());
              drop(v266_6);
              compose(&(v264_10),&(v266_11))
            };
            drop(v264_10);
            let v264_13: Space = unite(&(v264_8),&(v264_12));
            v263_7.join_into((v264_13).clone());
            }
            v263_7_cursor.ascend(1);
          }
          drop(v263_7_cursor);
          compose(&(v262_5),&(v263_7))
        };
        drop(v262_5);
        let v262_9: Space = intersect(&(*CONSTANT_1),&(v262_2));
        drop(v262_2);
        let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
        drop(v262_9);
        let v262_12: Space = if (v262_10).is_empty() { Space::new() } else {
          let v267_6: Path = concat_path(&(v261_6),&(v261_7_head));
          let mut v267_11 = Space::new();
          let mut v267_11_cursor = (v261_7_tail).read_zipper();
          for v267_11_byte in v267_11_cursor.child_mask().iter() {
            v267_11_cursor.descend_to_byte(v267_11_byte);
            {
            let v267_11_tail = v267_11_cursor.fork_read_zipper();
            let v267_11_head = Path::from_slice(&[v267_11_byte]);
            let v268_2: Space = singleton(&(v267_11_head));
            let v268_3: Space = intersect(&(*CONSTANT_1),&(v268_2));
            let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
            drop(v268_3);
            let v268_5: Space = subtract(&(*CONSTANT_0),&(v268_4));
            drop(v268_4);
            let v268_8: Space = if (v268_5).is_empty() { Space::new() } else {
              let v269_6: Path = concat_path(&(v267_6),&(v267_11_head));
              let v269_7: Space = routine_28(c, &(v269_6), &(v267_11_tail).make_space());
              compose(&(v268_5),&(v269_7))
            };
            drop(v268_5);
            let v268_9: Space = intersect(&(*CONSTANT_1),&(v268_2));
            drop(v268_2);
            let v268_10: Space = if has_head(&(v268_9)) { singleton(&[]) } else { Space::new() };
            drop(v268_9);
            let v268_12: Space = if (v268_10).is_empty() { Space::new() } else {
              let v270_6: Path = concat_path(&(v267_6),&(v267_11_head));
              let v270_11: Space = routine_12(c, &(v270_6), &(v267_11_tail).make_space());
              drop(v270_6);
              compose(&(v268_10),&(v270_11))
            };
            drop(v268_10);
            let v268_13: Space = unite(&(v268_8),&(v268_12));
            v267_11.join_into((v268_13).clone());
            }
            v267_11_cursor.ascend(1);
          }
          drop(v267_11_cursor);
          drop(v267_6);
          compose(&(v262_10),&(v267_11))
        };
        drop(v262_10);
        let v262_13: Space = unite(&(v262_8),&(v262_12));
        v261_7.join_into((v262_13).clone());
        }
        v261_7_cursor.ascend(1);
      }
      drop(v261_7_cursor);
      compose(&(v260_5),&(v261_7))
    };
    drop(v260_5);
    let v260_9: Space = intersect(&(*CONSTANT_1),&(v260_2));
    drop(v260_2);
    let v260_10: Space = if has_head(&(v260_9)) { singleton(&[]) } else { Space::new() };
    drop(v260_9);
    let v260_12: Space = if (v260_10).is_empty() { Space::new() } else {
      let v271_6: Path = concat_path(&(*p0),&(v259_20_head));
      let mut v271_11 = Space::new();
      let mut v271_11_cursor = (v259_20_tail).read_zipper();
      for v271_11_byte in v271_11_cursor.child_mask().iter() {
        v271_11_cursor.descend_to_byte(v271_11_byte);
        {
        let v271_11_tail = v271_11_cursor.fork_read_zipper();
        let v271_11_head = Path::from_slice(&[v271_11_byte]);
        let v272_2: Space = singleton(&(v271_11_head));
        let v272_3: Space = intersect(&(*CONSTANT_1),&(v272_2));
        let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
        drop(v272_3);
        let v272_5: Space = subtract(&(*CONSTANT_0),&(v272_4));
        drop(v272_4);
        let v272_8: Space = if (v272_5).is_empty() { Space::new() } else {
          let v273_6: Path = concat_path(&(v271_6),&(v271_11_head));
          let mut v273_7 = Space::new();
          let mut v273_7_cursor = (v271_11_tail).read_zipper();
          for v273_7_byte in v273_7_cursor.child_mask().iter() {
            v273_7_cursor.descend_to_byte(v273_7_byte);
            {
            let v273_7_tail = v273_7_cursor.fork_read_zipper();
            let v273_7_head = Path::from_slice(&[v273_7_byte]);
            let v274_2: Space = singleton(&(v273_7_head));
            let v274_3: Space = intersect(&(*CONSTANT_1),&(v274_2));
            let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
            drop(v274_3);
            let v274_5: Space = subtract(&(*CONSTANT_0),&(v274_4));
            drop(v274_4);
            let v274_8: Space = if (v274_5).is_empty() { Space::new() } else {
              let v275_6: Path = concat_path(&(v273_6),&(v273_7_head));
              let v275_7: Space = routine_28(c, &(v275_6), &(v273_7_tail).make_space());
              compose(&(v274_5),&(v275_7))
            };
            drop(v274_5);
            let v274_9: Space = intersect(&(*CONSTANT_1),&(v274_2));
            drop(v274_2);
            let v274_10: Space = if has_head(&(v274_9)) { singleton(&[]) } else { Space::new() };
            drop(v274_9);
            let v274_12: Space = if (v274_10).is_empty() { Space::new() } else {
              let v276_6: Path = concat_path(&(v273_6),&(v273_7_head));
              let v276_11: Space = routine_29(c, &(v276_6), &(v273_7_tail).make_space());
              drop(v276_6);
              compose(&(v274_10),&(v276_11))
            };
            drop(v274_10);
            let v274_13: Space = unite(&(v274_8),&(v274_12));
            v273_7.join_into((v274_13).clone());
            }
            v273_7_cursor.ascend(1);
          }
          drop(v273_7_cursor);
          drop(v273_6);
          compose(&(v272_5),&(v273_7))
        };
        drop(v272_5);
        let v272_9: Space = intersect(&(*CONSTANT_1),&(v272_2));
        drop(v272_2);
        let v272_10: Space = if has_head(&(v272_9)) { singleton(&[]) } else { Space::new() };
        drop(v272_9);
        let v272_11: Space = compose(&(v272_10),&(v271_11_tail));
        drop(v272_10);
        let v272_12: Space = unite(&(v272_8),&(v272_11));
        drop(v272_11);
        v271_11.join_into((v272_12).clone());
        }
        v271_11_cursor.ascend(1);
      }
      drop(v271_11_cursor);
      drop(v271_6);
      compose(&(v260_10),&(v271_11))
    };
    drop(v260_10);
    let v260_13: Space = unite(&(v260_8),&(v260_12));
    v259_20.join_into((v260_13).clone());
    }
    v259_20_cursor.ascend(1);
  }
  drop(v259_20_cursor);
  (v259_20).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v277_14 = Space::new();
  let mut v277_14_cursor = (*s0).read_zipper();
  for v277_14_byte in v277_14_cursor.child_mask().iter() {
    v277_14_cursor.descend_to_byte(v277_14_byte);
    {
    let v277_14_tail = v277_14_cursor.fork_read_zipper();
    let v277_14_head = Path::from_slice(&[v277_14_byte]);
    let v278_2: Space = singleton(&(v277_14_head));
    let v278_3: Space = intersect(&(*CONSTANT_1),&(v278_2));
    let v278_4: Space = if has_head(&(v278_3)) { singleton(&[]) } else { Space::new() };
    drop(v278_3);
    let v278_5: Space = subtract(&(*CONSTANT_0),&(v278_4));
    drop(v278_4);
    let v278_8: Space = if (v278_5).is_empty() { Space::new() } else {
      let v279_6: Path = concat_path(&(*p0),&(v277_14_head));
      let mut v279_7 = Space::new();
      let mut v279_7_cursor = (v277_14_tail).read_zipper();
      for v279_7_byte in v279_7_cursor.child_mask().iter() {
        v279_7_cursor.descend_to_byte(v279_7_byte);
        {
        let v279_7_tail = v279_7_cursor.fork_read_zipper();
        let v279_7_head = Path::from_slice(&[v279_7_byte]);
        let v280_2: Space = singleton(&(v279_7_head));
        let v280_3: Space = intersect(&(*CONSTANT_1),&(v280_2));
        let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
        drop(v280_3);
        let v280_5: Space = subtract(&(*CONSTANT_0),&(v280_4));
        drop(v280_4);
        let v280_8: Space = if (v280_5).is_empty() { Space::new() } else {
          let v281_6: Path = concat_path(&(v279_6),&(v279_7_head));
          let mut v281_7 = Space::new();
          let mut v281_7_cursor = (v279_7_tail).read_zipper();
          for v281_7_byte in v281_7_cursor.child_mask().iter() {
            v281_7_cursor.descend_to_byte(v281_7_byte);
            {
            let v281_7_tail = v281_7_cursor.fork_read_zipper();
            let v281_7_head = Path::from_slice(&[v281_7_byte]);
            let v282_2: Space = singleton(&(v281_7_head));
            let v282_3: Space = intersect(&(*CONSTANT_1),&(v282_2));
            let v282_4: Space = if has_head(&(v282_3)) { singleton(&[]) } else { Space::new() };
            drop(v282_3);
            let v282_5: Space = subtract(&(*CONSTANT_0),&(v282_4));
            drop(v282_4);
            let v282_8: Space = if (v282_5).is_empty() { Space::new() } else {
              let v283_6: Path = concat_path(&(v281_6),&(v281_7_head));
              let v283_7: Space = routine_28(c, &(v283_6), &(v281_7_tail).make_space());
              compose(&(v282_5),&(v283_7))
            };
            drop(v282_5);
            let v282_9: Space = intersect(&(*CONSTANT_1),&(v282_2));
            drop(v282_2);
            let v282_10: Space = if has_head(&(v282_9)) { singleton(&[]) } else { Space::new() };
            drop(v282_9);
            let v282_12: Space = if (v282_10).is_empty() { Space::new() } else {
              let v284_6: Path = concat_path(&(v281_6),&(v281_7_head));
              let v284_11: Space = routine_29(c, &(v284_6), &(v281_7_tail).make_space());
              drop(v284_6);
              compose(&(v282_10),&(v284_11))
            };
            drop(v282_10);
            let v282_13: Space = unite(&(v282_8),&(v282_12));
            v281_7.join_into((v282_13).clone());
            }
            v281_7_cursor.ascend(1);
          }
          drop(v281_7_cursor);
          compose(&(v280_5),&(v281_7))
        };
        drop(v280_5);
        let v280_9: Space = intersect(&(*CONSTANT_1),&(v280_2));
        drop(v280_2);
        let v280_10: Space = if has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
        drop(v280_9);
        let v280_12: Space = if (v280_10).is_empty() { Space::new() } else {
          let v285_6: Path = concat_path(&(v279_6),&(v279_7_head));
          let mut v285_11 = Space::new();
          let mut v285_11_cursor = (v279_7_tail).read_zipper();
          for v285_11_byte in v285_11_cursor.child_mask().iter() {
            v285_11_cursor.descend_to_byte(v285_11_byte);
            {
            let v285_11_tail = v285_11_cursor.fork_read_zipper();
            let v285_11_head = Path::from_slice(&[v285_11_byte]);
            let v286_2: Space = singleton(&(v285_11_head));
            let v286_3: Space = intersect(&(*CONSTANT_1),&(v286_2));
            let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
            drop(v286_3);
            let v286_5: Space = subtract(&(*CONSTANT_0),&(v286_4));
            drop(v286_4);
            let v286_8: Space = if (v286_5).is_empty() { Space::new() } else {
              let v287_6: Path = concat_path(&(v285_6),&(v285_11_head));
              let v287_7: Space = routine_28(c, &(v287_6), &(v285_11_tail).make_space());
              compose(&(v286_5),&(v287_7))
            };
            drop(v286_5);
            let v286_9: Space = intersect(&(*CONSTANT_1),&(v286_2));
            drop(v286_2);
            let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
            drop(v286_9);
            let v286_12: Space = if (v286_10).is_empty() { Space::new() } else {
              let v288_6: Path = concat_path(&(v285_6),&(v285_11_head));
              let v288_11: Space = routine_12(c, &(v288_6), &(v285_11_tail).make_space());
              drop(v288_6);
              compose(&(v286_10),&(v288_11))
            };
            drop(v286_10);
            let v286_13: Space = unite(&(v286_8),&(v286_12));
            v285_11.join_into((v286_13).clone());
            }
            v285_11_cursor.ascend(1);
          }
          drop(v285_11_cursor);
          drop(v285_6);
          compose(&(v280_10),&(v285_11))
        };
        drop(v280_10);
        let v280_13: Space = unite(&(v280_8),&(v280_12));
        v279_7.join_into((v280_13).clone());
        }
        v279_7_cursor.ascend(1);
      }
      drop(v279_7_cursor);
      drop(v279_6);
      compose(&(v278_5),&(v279_7))
    };
    drop(v278_5);
    let v278_9: Space = intersect(&(*CONSTANT_1),&(v278_2));
    drop(v278_2);
    let v278_10: Space = if has_head(&(v278_9)) { singleton(&[]) } else { Space::new() };
    drop(v278_9);
    let v278_11: Space = compose(&(v278_10),&(v277_14_tail));
    drop(v278_10);
    let v278_12: Space = unite(&(v278_8),&(v278_11));
    drop(v278_11);
    v277_14.join_into((v278_12).clone());
    }
    v277_14_cursor.ascend(1);
  }
  drop(v277_14_cursor);
  (v277_14).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v289_20 = Space::new();
  let mut v289_20_cursor = (*s0).read_zipper();
  for v289_20_byte in v289_20_cursor.child_mask().iter() {
    v289_20_cursor.descend_to_byte(v289_20_byte);
    {
    let v289_20_tail = v289_20_cursor.fork_read_zipper();
    let v289_20_head = Path::from_slice(&[v289_20_byte]);
    let v290_2: Space = singleton(&(v289_20_head));
    let v290_3: Space = intersect(&(*CONSTANT_1),&(v290_2));
    let v290_4: Space = if has_head(&(v290_3)) { singleton(&[]) } else { Space::new() };
    drop(v290_3);
    let v290_5: Space = subtract(&(*CONSTANT_0),&(v290_4));
    drop(v290_4);
    let v290_8: Space = if (v290_5).is_empty() { Space::new() } else {
      let v291_6: Path = concat_path(&(*p0),&(v289_20_head));
      let mut v291_7 = Space::new();
      let mut v291_7_cursor = (v289_20_tail).read_zipper();
      for v291_7_byte in v291_7_cursor.child_mask().iter() {
        v291_7_cursor.descend_to_byte(v291_7_byte);
        {
        let v291_7_tail = v291_7_cursor.fork_read_zipper();
        let v291_7_head = Path::from_slice(&[v291_7_byte]);
        let v292_2: Space = singleton(&(v291_7_head));
        let v292_3: Space = intersect(&(*CONSTANT_1),&(v292_2));
        let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
        drop(v292_3);
        let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
        drop(v292_4);
        let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
          let v293_6: Path = concat_path(&(v291_6),&(v291_7_head));
          let mut v293_7 = Space::new();
          let mut v293_7_cursor = (v291_7_tail).read_zipper();
          for v293_7_byte in v293_7_cursor.child_mask().iter() {
            v293_7_cursor.descend_to_byte(v293_7_byte);
            {
            let v293_7_tail = v293_7_cursor.fork_read_zipper();
            let v293_7_head = Path::from_slice(&[v293_7_byte]);
            let v294_2: Space = singleton(&(v293_7_head));
            let v294_3: Space = intersect(&(*CONSTANT_1),&(v294_2));
            let v294_4: Space = if has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
            drop(v294_3);
            let v294_5: Space = subtract(&(*CONSTANT_0),&(v294_4));
            drop(v294_4);
            let v294_8: Space = if (v294_5).is_empty() { Space::new() } else {
              let v295_6: Path = concat_path(&(v293_6),&(v293_7_head));
              let v295_7: Space = routine_30(c, &(v295_6), &(v293_7_tail).make_space());
              compose(&(v294_5),&(v295_7))
            };
            drop(v294_5);
            let v294_9: Space = intersect(&(*CONSTANT_1),&(v294_2));
            drop(v294_2);
            let v294_10: Space = if has_head(&(v294_9)) { singleton(&[]) } else { Space::new() };
            drop(v294_9);
            let v294_12: Space = if (v294_10).is_empty() { Space::new() } else {
              let v296_6: Path = concat_path(&(v293_6),&(v293_7_head));
              let v296_11: Space = routine_31(c, &(v296_6), &(v293_7_tail).make_space());
              drop(v296_6);
              compose(&(v294_10),&(v296_11))
            };
            drop(v294_10);
            let v294_13: Space = unite(&(v294_8),&(v294_12));
            v293_7.join_into((v294_13).clone());
            }
            v293_7_cursor.ascend(1);
          }
          drop(v293_7_cursor);
          compose(&(v292_5),&(v293_7))
        };
        drop(v292_5);
        let v292_9: Space = intersect(&(*CONSTANT_1),&(v292_2));
        drop(v292_2);
        let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
        drop(v292_9);
        let v292_12: Space = if (v292_10).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v291_6),&(v291_7_head));
          let mut v297_11 = Space::new();
          let mut v297_11_cursor = (v291_7_tail).read_zipper();
          for v297_11_byte in v297_11_cursor.child_mask().iter() {
            v297_11_cursor.descend_to_byte(v297_11_byte);
            {
            let v297_11_tail = v297_11_cursor.fork_read_zipper();
            let v297_11_head = Path::from_slice(&[v297_11_byte]);
            let v298_2: Space = singleton(&(v297_11_head));
            let v298_3: Space = intersect(&(*CONSTANT_1),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_0),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (v298_5).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&(v297_11_head));
              let v299_7: Space = routine_30(c, &(v299_6), &(v297_11_tail).make_space());
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_1),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (v298_10).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&(v297_11_head));
              let v300_11: Space = routine_15(c, &(v300_6), &(v297_11_tail).make_space());
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            v297_11.join_into((v298_13).clone());
            }
            v297_11_cursor.ascend(1);
          }
          drop(v297_11_cursor);
          drop(v297_6);
          compose(&(v292_10),&(v297_11))
        };
        drop(v292_10);
        let v292_13: Space = unite(&(v292_8),&(v292_12));
        v291_7.join_into((v292_13).clone());
        }
        v291_7_cursor.ascend(1);
      }
      drop(v291_7_cursor);
      compose(&(v290_5),&(v291_7))
    };
    drop(v290_5);
    let v290_9: Space = intersect(&(*CONSTANT_1),&(v290_2));
    drop(v290_2);
    let v290_10: Space = if has_head(&(v290_9)) { singleton(&[]) } else { Space::new() };
    drop(v290_9);
    let v290_12: Space = if (v290_10).is_empty() { Space::new() } else {
      let v301_6: Path = concat_path(&(*p0),&(v289_20_head));
      let mut v301_11 = Space::new();
      let mut v301_11_cursor = (v289_20_tail).read_zipper();
      for v301_11_byte in v301_11_cursor.child_mask().iter() {
        v301_11_cursor.descend_to_byte(v301_11_byte);
        {
        let v301_11_tail = v301_11_cursor.fork_read_zipper();
        let v301_11_head = Path::from_slice(&[v301_11_byte]);
        let v302_2: Space = singleton(&(v301_11_head));
        let v302_3: Space = intersect(&(*CONSTANT_1),&(v302_2));
        let v302_4: Space = if has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
        drop(v302_3);
        let v302_5: Space = subtract(&(*CONSTANT_0),&(v302_4));
        drop(v302_4);
        let v302_8: Space = if (v302_5).is_empty() { Space::new() } else {
          let v303_6: Path = concat_path(&(v301_6),&(v301_11_head));
          let mut v303_7 = Space::new();
          let mut v303_7_cursor = (v301_11_tail).read_zipper();
          for v303_7_byte in v303_7_cursor.child_mask().iter() {
            v303_7_cursor.descend_to_byte(v303_7_byte);
            {
            let v303_7_tail = v303_7_cursor.fork_read_zipper();
            let v303_7_head = Path::from_slice(&[v303_7_byte]);
            let v304_2: Space = singleton(&(v303_7_head));
            let v304_3: Space = intersect(&(*CONSTANT_1),&(v304_2));
            let v304_4: Space = if has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
            drop(v304_3);
            let v304_5: Space = subtract(&(*CONSTANT_0),&(v304_4));
            drop(v304_4);
            let v304_8: Space = if (v304_5).is_empty() { Space::new() } else {
              let v305_6: Path = concat_path(&(v303_6),&(v303_7_head));
              let v305_7: Space = routine_30(c, &(v305_6), &(v303_7_tail).make_space());
              compose(&(v304_5),&(v305_7))
            };
            drop(v304_5);
            let v304_9: Space = intersect(&(*CONSTANT_1),&(v304_2));
            drop(v304_2);
            let v304_10: Space = if has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
            drop(v304_9);
            let v304_12: Space = if (v304_10).is_empty() { Space::new() } else {
              let v306_6: Path = concat_path(&(v303_6),&(v303_7_head));
              let v306_11: Space = routine_31(c, &(v306_6), &(v303_7_tail).make_space());
              drop(v306_6);
              compose(&(v304_10),&(v306_11))
            };
            drop(v304_10);
            let v304_13: Space = unite(&(v304_8),&(v304_12));
            v303_7.join_into((v304_13).clone());
            }
            v303_7_cursor.ascend(1);
          }
          drop(v303_7_cursor);
          drop(v303_6);
          compose(&(v302_5),&(v303_7))
        };
        drop(v302_5);
        let v302_9: Space = intersect(&(*CONSTANT_1),&(v302_2));
        drop(v302_2);
        let v302_10: Space = if has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
        drop(v302_9);
        let v302_11: Space = compose(&(v302_10),&(v301_11_tail));
        drop(v302_10);
        let v302_12: Space = unite(&(v302_8),&(v302_11));
        drop(v302_11);
        v301_11.join_into((v302_12).clone());
        }
        v301_11_cursor.ascend(1);
      }
      drop(v301_11_cursor);
      drop(v301_6);
      compose(&(v290_10),&(v301_11))
    };
    drop(v290_10);
    let v290_13: Space = unite(&(v290_8),&(v290_12));
    v289_20.join_into((v290_13).clone());
    }
    v289_20_cursor.ascend(1);
  }
  drop(v289_20_cursor);
  (v289_20).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v307_14 = Space::new();
  let mut v307_14_cursor = (*s0).read_zipper();
  for v307_14_byte in v307_14_cursor.child_mask().iter() {
    v307_14_cursor.descend_to_byte(v307_14_byte);
    {
    let v307_14_tail = v307_14_cursor.fork_read_zipper();
    let v307_14_head = Path::from_slice(&[v307_14_byte]);
    let v308_2: Space = singleton(&(v307_14_head));
    let v308_3: Space = intersect(&(*CONSTANT_1),&(v308_2));
    let v308_4: Space = if has_head(&(v308_3)) { singleton(&[]) } else { Space::new() };
    drop(v308_3);
    let v308_5: Space = subtract(&(*CONSTANT_0),&(v308_4));
    drop(v308_4);
    let v308_8: Space = if (v308_5).is_empty() { Space::new() } else {
      let v309_6: Path = concat_path(&(*p0),&(v307_14_head));
      let mut v309_7 = Space::new();
      let mut v309_7_cursor = (v307_14_tail).read_zipper();
      for v309_7_byte in v309_7_cursor.child_mask().iter() {
        v309_7_cursor.descend_to_byte(v309_7_byte);
        {
        let v309_7_tail = v309_7_cursor.fork_read_zipper();
        let v309_7_head = Path::from_slice(&[v309_7_byte]);
        let v310_2: Space = singleton(&(v309_7_head));
        let v310_3: Space = intersect(&(*CONSTANT_1),&(v310_2));
        let v310_4: Space = if has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
        drop(v310_3);
        let v310_5: Space = subtract(&(*CONSTANT_0),&(v310_4));
        drop(v310_4);
        let v310_8: Space = if (v310_5).is_empty() { Space::new() } else {
          let v311_6: Path = concat_path(&(v309_6),&(v309_7_head));
          let mut v311_7 = Space::new();
          let mut v311_7_cursor = (v309_7_tail).read_zipper();
          for v311_7_byte in v311_7_cursor.child_mask().iter() {
            v311_7_cursor.descend_to_byte(v311_7_byte);
            {
            let v311_7_tail = v311_7_cursor.fork_read_zipper();
            let v311_7_head = Path::from_slice(&[v311_7_byte]);
            let v312_2: Space = singleton(&(v311_7_head));
            let v312_3: Space = intersect(&(*CONSTANT_1),&(v312_2));
            let v312_4: Space = if has_head(&(v312_3)) { singleton(&[]) } else { Space::new() };
            drop(v312_3);
            let v312_5: Space = subtract(&(*CONSTANT_0),&(v312_4));
            drop(v312_4);
            let v312_8: Space = if (v312_5).is_empty() { Space::new() } else {
              let v313_6: Path = concat_path(&(v311_6),&(v311_7_head));
              let v313_7: Space = routine_30(c, &(v313_6), &(v311_7_tail).make_space());
              compose(&(v312_5),&(v313_7))
            };
            drop(v312_5);
            let v312_9: Space = intersect(&(*CONSTANT_1),&(v312_2));
            drop(v312_2);
            let v312_10: Space = if has_head(&(v312_9)) { singleton(&[]) } else { Space::new() };
            drop(v312_9);
            let v312_12: Space = if (v312_10).is_empty() { Space::new() } else {
              let v314_6: Path = concat_path(&(v311_6),&(v311_7_head));
              let v314_11: Space = routine_31(c, &(v314_6), &(v311_7_tail).make_space());
              drop(v314_6);
              compose(&(v312_10),&(v314_11))
            };
            drop(v312_10);
            let v312_13: Space = unite(&(v312_8),&(v312_12));
            v311_7.join_into((v312_13).clone());
            }
            v311_7_cursor.ascend(1);
          }
          drop(v311_7_cursor);
          compose(&(v310_5),&(v311_7))
        };
        drop(v310_5);
        let v310_9: Space = intersect(&(*CONSTANT_1),&(v310_2));
        drop(v310_2);
        let v310_10: Space = if has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
        drop(v310_9);
        let v310_12: Space = if (v310_10).is_empty() { Space::new() } else {
          let v315_6: Path = concat_path(&(v309_6),&(v309_7_head));
          let mut v315_11 = Space::new();
          let mut v315_11_cursor = (v309_7_tail).read_zipper();
          for v315_11_byte in v315_11_cursor.child_mask().iter() {
            v315_11_cursor.descend_to_byte(v315_11_byte);
            {
            let v315_11_tail = v315_11_cursor.fork_read_zipper();
            let v315_11_head = Path::from_slice(&[v315_11_byte]);
            let v316_2: Space = singleton(&(v315_11_head));
            let v316_3: Space = intersect(&(*CONSTANT_1),&(v316_2));
            let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
            drop(v316_3);
            let v316_5: Space = subtract(&(*CONSTANT_0),&(v316_4));
            drop(v316_4);
            let v316_8: Space = if (v316_5).is_empty() { Space::new() } else {
              let v317_6: Path = concat_path(&(v315_6),&(v315_11_head));
              let v317_7: Space = routine_30(c, &(v317_6), &(v315_11_tail).make_space());
              compose(&(v316_5),&(v317_7))
            };
            drop(v316_5);
            let v316_9: Space = intersect(&(*CONSTANT_1),&(v316_2));
            drop(v316_2);
            let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
            drop(v316_9);
            let v316_12: Space = if (v316_10).is_empty() { Space::new() } else {
              let v318_6: Path = concat_path(&(v315_6),&(v315_11_head));
              let v318_11: Space = routine_15(c, &(v318_6), &(v315_11_tail).make_space());
              drop(v318_6);
              compose(&(v316_10),&(v318_11))
            };
            drop(v316_10);
            let v316_13: Space = unite(&(v316_8),&(v316_12));
            v315_11.join_into((v316_13).clone());
            }
            v315_11_cursor.ascend(1);
          }
          drop(v315_11_cursor);
          drop(v315_6);
          compose(&(v310_10),&(v315_11))
        };
        drop(v310_10);
        let v310_13: Space = unite(&(v310_8),&(v310_12));
        v309_7.join_into((v310_13).clone());
        }
        v309_7_cursor.ascend(1);
      }
      drop(v309_7_cursor);
      drop(v309_6);
      compose(&(v308_5),&(v309_7))
    };
    drop(v308_5);
    let v308_9: Space = intersect(&(*CONSTANT_1),&(v308_2));
    drop(v308_2);
    let v308_10: Space = if has_head(&(v308_9)) { singleton(&[]) } else { Space::new() };
    drop(v308_9);
    let v308_11: Space = compose(&(v308_10),&(v307_14_tail));
    drop(v308_10);
    let v308_12: Space = unite(&(v308_8),&(v308_11));
    drop(v308_11);
    v307_14.join_into((v308_12).clone());
    }
    v307_14_cursor.ascend(1);
  }
  drop(v307_14_cursor);
  (v307_14).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v319_12 = Space::new();
  let mut v319_12_cursor = (*s0).read_zipper();
  for v319_12_byte in v319_12_cursor.child_mask().iter() {
    v319_12_cursor.descend_to_byte(v319_12_byte);
    {
    let v319_12_tail = v319_12_cursor.fork_read_zipper();
    let v319_12_head = Path::from_slice(&[v319_12_byte]);
    let v320_2: Space = singleton(&(v319_12_head));
    let v320_3: Space = intersect(&(*CONSTANT_1),&(v320_2));
    let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
    drop(v320_3);
    let v320_5: Space = subtract(&(*CONSTANT_0),&(v320_4));
    drop(v320_4);
    let v320_8: Space = if (v320_5).is_empty() { Space::new() } else {
      let v321_6: Path = concat_path(&(*p0),&(v319_12_head));
      let mut v321_7 = Space::new();
      let mut v321_7_cursor = (v319_12_tail).read_zipper();
      for v321_7_byte in v321_7_cursor.child_mask().iter() {
        v321_7_cursor.descend_to_byte(v321_7_byte);
        {
        let v321_7_tail = v321_7_cursor.fork_read_zipper();
        let v321_7_head = Path::from_slice(&[v321_7_byte]);
        let v322_2: Space = singleton(&(v321_7_head));
        let v322_3: Space = intersect(&(*CONSTANT_1),&(v322_2));
        let v322_4: Space = if has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
        drop(v322_3);
        let v322_5: Space = subtract(&(*CONSTANT_0),&(v322_4));
        drop(v322_4);
        let mut v322_6 = Space::new();
        let mut v322_6_cursor = (v321_7_tail).read_zipper();
        for v322_6_byte in v322_6_cursor.child_mask().iter() {
          v322_6_cursor.descend_to_byte(v322_6_byte);
          {
          let v322_6_tail = v322_6_cursor.fork_read_zipper();
          let v322_6_head = Path::from_slice(&[v322_6_byte]);
          let v323_2: Space = Space::new();
          v322_6.join_into((v323_2).clone());
          }
          v322_6_cursor.ascend(1);
        }
        drop(v322_6_cursor);
        let v322_7: Space = compose(&(v322_5),&(v322_6));
        drop(v322_5);
        drop(v322_6);
        let v322_8: Space = intersect(&(*CONSTANT_1),&(v322_2));
        drop(v322_2);
        let v322_9: Space = if has_head(&(v322_8)) { singleton(&[]) } else { Space::new() };
        drop(v322_8);
        let v322_12: Space = if (v322_9).is_empty() { Space::new() } else {
          let v324_10: Path = concat_path(&(v321_6),&(v321_7_head));
          let mut v324_11 = Space::new();
          let mut v324_11_cursor = (v321_7_tail).read_zipper();
          for v324_11_byte in v324_11_cursor.child_mask().iter() {
            v324_11_cursor.descend_to_byte(v324_11_byte);
            {
            let v324_11_tail = v324_11_cursor.fork_read_zipper();
            let v324_11_head = Path::from_slice(&[v324_11_byte]);
            let v325_2: Space = singleton(&(v324_11_head));
            let v325_3: Space = intersect(&(*CONSTANT_1),&(v325_2));
            drop(v325_2);
            let v325_4: Space = if has_head(&(v325_3)) { singleton(&[]) } else { Space::new() };
            drop(v325_3);
            let v325_7: Space = if (v325_4).is_empty() { Space::new() } else {
              let v326_5: Path = concat_path(&(v324_10),&(v324_11_head));
              let v326_6: Space = routine_12(c, &(v326_5), &(v324_11_tail).make_space());
              drop(v326_5);
              compose(&(v325_4),&(v326_6))
            };
            drop(v325_4);
            v324_11.join_into((v325_7).clone());
            }
            v324_11_cursor.ascend(1);
          }
          drop(v324_11_cursor);
          drop(v324_10);
          compose(&(v322_9),&(v324_11))
        };
        drop(v322_9);
        let v322_13: Space = unite(&(v322_7),&(v322_12));
        drop(v322_7);
        v321_7.join_into((v322_13).clone());
        }
        v321_7_cursor.ascend(1);
      }
      drop(v321_7_cursor);
      drop(v321_6);
      compose(&(v320_5),&(v321_7))
    };
    drop(v320_5);
    let v320_9: Space = intersect(&(*CONSTANT_1),&(v320_2));
    drop(v320_2);
    let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
    drop(v320_9);
    let mut v320_11 = Space::new();
    let mut v320_11_cursor = (v319_12_tail).read_zipper();
    for v320_11_byte in v320_11_cursor.child_mask().iter() {
      v320_11_cursor.descend_to_byte(v320_11_byte);
      {
      let v320_11_tail = v320_11_cursor.fork_read_zipper();
      let v320_11_head = Path::from_slice(&[v320_11_byte]);
      let v327_2: Space = singleton(&(v320_11_head));
      let v327_3: Space = intersect(&(*CONSTANT_1),&(v327_2));
      let v327_4: Space = if has_head(&(v327_3)) { singleton(&[]) } else { Space::new() };
      drop(v327_3);
      let v327_5: Space = subtract(&(*CONSTANT_0),&(v327_4));
      drop(v327_4);
      let mut v327_6 = Space::new();
      let mut v327_6_cursor = (v320_11_tail).read_zipper();
      for v327_6_byte in v327_6_cursor.child_mask().iter() {
        v327_6_cursor.descend_to_byte(v327_6_byte);
        {
        let v327_6_tail = v327_6_cursor.fork_read_zipper();
        let v327_6_head = Path::from_slice(&[v327_6_byte]);
        let v328_2: Space = Space::new();
        v327_6.join_into((v328_2).clone());
        }
        v327_6_cursor.ascend(1);
      }
      drop(v327_6_cursor);
      let v327_7: Space = compose(&(v327_5),&(v327_6));
      drop(v327_5);
      drop(v327_6);
      let v327_8: Space = intersect(&(*CONSTANT_1),&(v327_2));
      drop(v327_2);
      let v327_9: Space = if has_head(&(v327_8)) { singleton(&[]) } else { Space::new() };
      drop(v327_8);
      let v327_10: Space = compose(&(v327_9),&(v320_11_tail));
      drop(v327_9);
      let v327_11: Space = unite(&(v327_7),&(v327_10));
      drop(v327_7);
      drop(v327_10);
      v320_11.join_into((v327_11).clone());
      }
      v320_11_cursor.ascend(1);
    }
    drop(v320_11_cursor);
    let v320_12: Space = compose(&(v320_10),&(v320_11));
    drop(v320_10);
    drop(v320_11);
    let v320_13: Space = unite(&(v320_8),&(v320_12));
    drop(v320_12);
    v319_12.join_into((v320_13).clone());
    }
    v319_12_cursor.ascend(1);
  }
  drop(v319_12_cursor);
  (v319_12).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v329_9 = Space::new();
  let mut v329_9_cursor = (*s0).read_zipper();
  for v329_9_byte in v329_9_cursor.child_mask().iter() {
    v329_9_cursor.descend_to_byte(v329_9_byte);
    {
    let v329_9_tail = v329_9_cursor.fork_read_zipper();
    let v329_9_head = Path::from_slice(&[v329_9_byte]);
    let v330_2: Space = singleton(&(v329_9_head));
    let v330_3: Space = intersect(&(*CONSTANT_1),&(v330_2));
    let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
    drop(v330_3);
    let v330_5: Space = subtract(&(*CONSTANT_0),&(v330_4));
    drop(v330_4);
    let v330_8: Space = if (v330_5).is_empty() { Space::new() } else {
      let v331_6: Path = concat_path(&(*p0),&(v329_9_head));
      let mut v331_7 = Space::new();
      let mut v331_7_cursor = (v329_9_tail).read_zipper();
      for v331_7_byte in v331_7_cursor.child_mask().iter() {
        v331_7_cursor.descend_to_byte(v331_7_byte);
        {
        let v331_7_tail = v331_7_cursor.fork_read_zipper();
        let v331_7_head = Path::from_slice(&[v331_7_byte]);
        let v332_2: Space = singleton(&(v331_7_head));
        let v332_3: Space = intersect(&(*CONSTANT_1),&(v332_2));
        let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
        drop(v332_3);
        let v332_5: Space = subtract(&(*CONSTANT_0),&(v332_4));
        drop(v332_4);
        let mut v332_6 = Space::new();
        let mut v332_6_cursor = (v331_7_tail).read_zipper();
        for v332_6_byte in v332_6_cursor.child_mask().iter() {
          v332_6_cursor.descend_to_byte(v332_6_byte);
          {
          let v332_6_tail = v332_6_cursor.fork_read_zipper();
          let v332_6_head = Path::from_slice(&[v332_6_byte]);
          let v333_2: Space = Space::new();
          v332_6.join_into((v333_2).clone());
          }
          v332_6_cursor.ascend(1);
        }
        drop(v332_6_cursor);
        let v332_7: Space = compose(&(v332_5),&(v332_6));
        drop(v332_5);
        drop(v332_6);
        let v332_8: Space = intersect(&(*CONSTANT_1),&(v332_2));
        drop(v332_2);
        let v332_9: Space = if has_head(&(v332_8)) { singleton(&[]) } else { Space::new() };
        drop(v332_8);
        let v332_12: Space = if (v332_9).is_empty() { Space::new() } else {
          let v334_10: Path = concat_path(&(v331_6),&(v331_7_head));
          let mut v334_11 = Space::new();
          let mut v334_11_cursor = (v331_7_tail).read_zipper();
          for v334_11_byte in v334_11_cursor.child_mask().iter() {
            v334_11_cursor.descend_to_byte(v334_11_byte);
            {
            let v334_11_tail = v334_11_cursor.fork_read_zipper();
            let v334_11_head = Path::from_slice(&[v334_11_byte]);
            let v335_2: Space = singleton(&(v334_11_head));
            let v335_3: Space = intersect(&(*CONSTANT_1),&(v335_2));
            drop(v335_2);
            let v335_4: Space = if has_head(&(v335_3)) { singleton(&[]) } else { Space::new() };
            drop(v335_3);
            let v335_7: Space = if (v335_4).is_empty() { Space::new() } else {
              let v336_5: Path = concat_path(&(v334_10),&(v334_11_head));
              let v336_6: Space = routine_12(c, &(v336_5), &(v334_11_tail).make_space());
              drop(v336_5);
              compose(&(v335_4),&(v336_6))
            };
            drop(v335_4);
            v334_11.join_into((v335_7).clone());
            }
            v334_11_cursor.ascend(1);
          }
          drop(v334_11_cursor);
          drop(v334_10);
          compose(&(v332_9),&(v334_11))
        };
        drop(v332_9);
        let v332_13: Space = unite(&(v332_7),&(v332_12));
        drop(v332_7);
        v331_7.join_into((v332_13).clone());
        }
        v331_7_cursor.ascend(1);
      }
      drop(v331_7_cursor);
      drop(v331_6);
      compose(&(v330_5),&(v331_7))
    };
    drop(v330_5);
    let v330_9: Space = intersect(&(*CONSTANT_1),&(v330_2));
    drop(v330_2);
    let v330_10: Space = if has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
    drop(v330_9);
    let v330_11: Space = compose(&(v330_10),&(v329_9_tail));
    drop(v330_10);
    let v330_12: Space = unite(&(v330_8),&(v330_11));
    drop(v330_11);
    v329_9.join_into((v330_12).clone());
    }
    v329_9_cursor.ascend(1);
  }
  drop(v329_9_cursor);
  (v329_9).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v337_12 = Space::new();
  let mut v337_12_cursor = (*s0).read_zipper();
  for v337_12_byte in v337_12_cursor.child_mask().iter() {
    v337_12_cursor.descend_to_byte(v337_12_byte);
    {
    let v337_12_tail = v337_12_cursor.fork_read_zipper();
    let v337_12_head = Path::from_slice(&[v337_12_byte]);
    let v338_2: Space = singleton(&(v337_12_head));
    let v338_3: Space = intersect(&(*CONSTANT_1),&(v338_2));
    let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
    drop(v338_3);
    let v338_5: Space = subtract(&(*CONSTANT_0),&(v338_4));
    drop(v338_4);
    let v338_8: Space = if (v338_5).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&(v337_12_head));
      let mut v339_7 = Space::new();
      let mut v339_7_cursor = (v337_12_tail).read_zipper();
      for v339_7_byte in v339_7_cursor.child_mask().iter() {
        v339_7_cursor.descend_to_byte(v339_7_byte);
        {
        let v339_7_tail = v339_7_cursor.fork_read_zipper();
        let v339_7_head = Path::from_slice(&[v339_7_byte]);
        let v340_2: Space = singleton(&(v339_7_head));
        let v340_3: Space = intersect(&(*CONSTANT_1),&(v340_2));
        let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = subtract(&(*CONSTANT_0),&(v340_4));
        drop(v340_4);
        let mut v340_6 = Space::new();
        let mut v340_6_cursor = (v339_7_tail).read_zipper();
        for v340_6_byte in v340_6_cursor.child_mask().iter() {
          v340_6_cursor.descend_to_byte(v340_6_byte);
          {
          let v340_6_tail = v340_6_cursor.fork_read_zipper();
          let v340_6_head = Path::from_slice(&[v340_6_byte]);
          let v341_2: Space = Space::new();
          v340_6.join_into((v341_2).clone());
          }
          v340_6_cursor.ascend(1);
        }
        drop(v340_6_cursor);
        let v340_7: Space = compose(&(v340_5),&(v340_6));
        drop(v340_5);
        drop(v340_6);
        let v340_8: Space = intersect(&(*CONSTANT_1),&(v340_2));
        drop(v340_2);
        let v340_9: Space = if has_head(&(v340_8)) { singleton(&[]) } else { Space::new() };
        drop(v340_8);
        let v340_12: Space = if (v340_9).is_empty() { Space::new() } else {
          let v342_10: Path = concat_path(&(v339_6),&(v339_7_head));
          let mut v342_11 = Space::new();
          let mut v342_11_cursor = (v339_7_tail).read_zipper();
          for v342_11_byte in v342_11_cursor.child_mask().iter() {
            v342_11_cursor.descend_to_byte(v342_11_byte);
            {
            let v342_11_tail = v342_11_cursor.fork_read_zipper();
            let v342_11_head = Path::from_slice(&[v342_11_byte]);
            let v343_2: Space = singleton(&(v342_11_head));
            let v343_3: Space = intersect(&(*CONSTANT_1),&(v343_2));
            drop(v343_2);
            let v343_4: Space = if has_head(&(v343_3)) { singleton(&[]) } else { Space::new() };
            drop(v343_3);
            let v343_7: Space = if (v343_4).is_empty() { Space::new() } else {
              let v344_5: Path = concat_path(&(v342_10),&(v342_11_head));
              let v344_6: Space = routine_15(c, &(v344_5), &(v342_11_tail).make_space());
              drop(v344_5);
              compose(&(v343_4),&(v344_6))
            };
            drop(v343_4);
            v342_11.join_into((v343_7).clone());
            }
            v342_11_cursor.ascend(1);
          }
          drop(v342_11_cursor);
          drop(v342_10);
          compose(&(v340_9),&(v342_11))
        };
        drop(v340_9);
        let v340_13: Space = unite(&(v340_7),&(v340_12));
        drop(v340_7);
        v339_7.join_into((v340_13).clone());
        }
        v339_7_cursor.ascend(1);
      }
      drop(v339_7_cursor);
      drop(v339_6);
      compose(&(v338_5),&(v339_7))
    };
    drop(v338_5);
    let v338_9: Space = intersect(&(*CONSTANT_1),&(v338_2));
    drop(v338_2);
    let v338_10: Space = if has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
    drop(v338_9);
    let mut v338_11 = Space::new();
    let mut v338_11_cursor = (v337_12_tail).read_zipper();
    for v338_11_byte in v338_11_cursor.child_mask().iter() {
      v338_11_cursor.descend_to_byte(v338_11_byte);
      {
      let v338_11_tail = v338_11_cursor.fork_read_zipper();
      let v338_11_head = Path::from_slice(&[v338_11_byte]);
      let v345_2: Space = singleton(&(v338_11_head));
      let v345_3: Space = intersect(&(*CONSTANT_1),&(v345_2));
      let v345_4: Space = if has_head(&(v345_3)) { singleton(&[]) } else { Space::new() };
      drop(v345_3);
      let v345_5: Space = subtract(&(*CONSTANT_0),&(v345_4));
      drop(v345_4);
      let mut v345_6 = Space::new();
      let mut v345_6_cursor = (v338_11_tail).read_zipper();
      for v345_6_byte in v345_6_cursor.child_mask().iter() {
        v345_6_cursor.descend_to_byte(v345_6_byte);
        {
        let v345_6_tail = v345_6_cursor.fork_read_zipper();
        let v345_6_head = Path::from_slice(&[v345_6_byte]);
        let v346_2: Space = Space::new();
        v345_6.join_into((v346_2).clone());
        }
        v345_6_cursor.ascend(1);
      }
      drop(v345_6_cursor);
      let v345_7: Space = compose(&(v345_5),&(v345_6));
      drop(v345_5);
      drop(v345_6);
      let v345_8: Space = intersect(&(*CONSTANT_1),&(v345_2));
      drop(v345_2);
      let v345_9: Space = if has_head(&(v345_8)) { singleton(&[]) } else { Space::new() };
      drop(v345_8);
      let v345_10: Space = compose(&(v345_9),&(v338_11_tail));
      drop(v345_9);
      let v345_11: Space = unite(&(v345_7),&(v345_10));
      drop(v345_7);
      drop(v345_10);
      v338_11.join_into((v345_11).clone());
      }
      v338_11_cursor.ascend(1);
    }
    drop(v338_11_cursor);
    let v338_12: Space = compose(&(v338_10),&(v338_11));
    drop(v338_10);
    drop(v338_11);
    let v338_13: Space = unite(&(v338_8),&(v338_12));
    drop(v338_12);
    v337_12.join_into((v338_13).clone());
    }
    v337_12_cursor.ascend(1);
  }
  drop(v337_12_cursor);
  (v337_12).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v347_9 = Space::new();
  let mut v347_9_cursor = (*s0).read_zipper();
  for v347_9_byte in v347_9_cursor.child_mask().iter() {
    v347_9_cursor.descend_to_byte(v347_9_byte);
    {
    let v347_9_tail = v347_9_cursor.fork_read_zipper();
    let v347_9_head = Path::from_slice(&[v347_9_byte]);
    let v348_2: Space = singleton(&(v347_9_head));
    let v348_3: Space = intersect(&(*CONSTANT_1),&(v348_2));
    let v348_4: Space = if has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
    drop(v348_3);
    let v348_5: Space = subtract(&(*CONSTANT_0),&(v348_4));
    drop(v348_4);
    let v348_8: Space = if (v348_5).is_empty() { Space::new() } else {
      let v349_6: Path = concat_path(&(*p0),&(v347_9_head));
      let mut v349_7 = Space::new();
      let mut v349_7_cursor = (v347_9_tail).read_zipper();
      for v349_7_byte in v349_7_cursor.child_mask().iter() {
        v349_7_cursor.descend_to_byte(v349_7_byte);
        {
        let v349_7_tail = v349_7_cursor.fork_read_zipper();
        let v349_7_head = Path::from_slice(&[v349_7_byte]);
        let v350_2: Space = singleton(&(v349_7_head));
        let v350_3: Space = intersect(&(*CONSTANT_1),&(v350_2));
        let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
        drop(v350_3);
        let v350_5: Space = subtract(&(*CONSTANT_0),&(v350_4));
        drop(v350_4);
        let mut v350_6 = Space::new();
        let mut v350_6_cursor = (v349_7_tail).read_zipper();
        for v350_6_byte in v350_6_cursor.child_mask().iter() {
          v350_6_cursor.descend_to_byte(v350_6_byte);
          {
          let v350_6_tail = v350_6_cursor.fork_read_zipper();
          let v350_6_head = Path::from_slice(&[v350_6_byte]);
          let v351_2: Space = Space::new();
          v350_6.join_into((v351_2).clone());
          }
          v350_6_cursor.ascend(1);
        }
        drop(v350_6_cursor);
        let v350_7: Space = compose(&(v350_5),&(v350_6));
        drop(v350_5);
        drop(v350_6);
        let v350_8: Space = intersect(&(*CONSTANT_1),&(v350_2));
        drop(v350_2);
        let v350_9: Space = if has_head(&(v350_8)) { singleton(&[]) } else { Space::new() };
        drop(v350_8);
        let v350_12: Space = if (v350_9).is_empty() { Space::new() } else {
          let v352_10: Path = concat_path(&(v349_6),&(v349_7_head));
          let mut v352_11 = Space::new();
          let mut v352_11_cursor = (v349_7_tail).read_zipper();
          for v352_11_byte in v352_11_cursor.child_mask().iter() {
            v352_11_cursor.descend_to_byte(v352_11_byte);
            {
            let v352_11_tail = v352_11_cursor.fork_read_zipper();
            let v352_11_head = Path::from_slice(&[v352_11_byte]);
            let v353_2: Space = singleton(&(v352_11_head));
            let v353_3: Space = intersect(&(*CONSTANT_1),&(v353_2));
            drop(v353_2);
            let v353_4: Space = if has_head(&(v353_3)) { singleton(&[]) } else { Space::new() };
            drop(v353_3);
            let v353_7: Space = if (v353_4).is_empty() { Space::new() } else {
              let v354_5: Path = concat_path(&(v352_10),&(v352_11_head));
              let v354_6: Space = routine_15(c, &(v354_5), &(v352_11_tail).make_space());
              drop(v354_5);
              compose(&(v353_4),&(v354_6))
            };
            drop(v353_4);
            v352_11.join_into((v353_7).clone());
            }
            v352_11_cursor.ascend(1);
          }
          drop(v352_11_cursor);
          drop(v352_10);
          compose(&(v350_9),&(v352_11))
        };
        drop(v350_9);
        let v350_13: Space = unite(&(v350_7),&(v350_12));
        drop(v350_7);
        v349_7.join_into((v350_13).clone());
        }
        v349_7_cursor.ascend(1);
      }
      drop(v349_7_cursor);
      drop(v349_6);
      compose(&(v348_5),&(v349_7))
    };
    drop(v348_5);
    let v348_9: Space = intersect(&(*CONSTANT_1),&(v348_2));
    drop(v348_2);
    let v348_10: Space = if has_head(&(v348_9)) { singleton(&[]) } else { Space::new() };
    drop(v348_9);
    let v348_11: Space = compose(&(v348_10),&(v347_9_tail));
    drop(v348_10);
    let v348_12: Space = unite(&(v348_8),&(v348_11));
    drop(v348_11);
    v347_9.join_into((v348_12).clone());
    }
    v347_9_cursor.ascend(1);
  }
  drop(v347_9_cursor);
  (v347_9).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v355_6 = Space::new();
  let mut v355_6_cursor = (*s0).read_zipper();
  for v355_6_byte in v355_6_cursor.child_mask().iter() {
    v355_6_cursor.descend_to_byte(v355_6_byte);
    {
    let v355_6_tail = v355_6_cursor.fork_read_zipper();
    let v355_6_head = Path::from_slice(&[v355_6_byte]);
    let v356_2: Space = singleton(&(v355_6_head));
    let v356_3: Space = intersect(&(*CONSTANT_1),&(v356_2));
    let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
    drop(v356_3);
    let v356_5: Space = subtract(&(*CONSTANT_0),&(v356_4));
    drop(v356_4);
    let mut v356_6 = Space::new();
    let mut v356_6_cursor = (v355_6_tail).read_zipper();
    for v356_6_byte in v356_6_cursor.child_mask().iter() {
      v356_6_cursor.descend_to_byte(v356_6_byte);
      {
      let v356_6_tail = v356_6_cursor.fork_read_zipper();
      let v356_6_head = Path::from_slice(&[v356_6_byte]);
      let v357_2: Space = Space::new();
      v356_6.join_into((v357_2).clone());
      }
      v356_6_cursor.ascend(1);
    }
    drop(v356_6_cursor);
    let v356_7: Space = compose(&(v356_5),&(v356_6));
    drop(v356_5);
    drop(v356_6);
    let v356_8: Space = intersect(&(*CONSTANT_1),&(v356_2));
    drop(v356_2);
    let v356_9: Space = if has_head(&(v356_8)) { singleton(&[]) } else { Space::new() };
    drop(v356_8);
    let mut v356_10 = Space::new();
    let mut v356_10_cursor = (v355_6_tail).read_zipper();
    for v356_10_byte in v356_10_cursor.child_mask().iter() {
      v356_10_cursor.descend_to_byte(v356_10_byte);
      {
      let v356_10_tail = v356_10_cursor.fork_read_zipper();
      let v356_10_head = Path::from_slice(&[v356_10_byte]);
      let v358_2: Space = singleton(&(v356_10_head));
      let v358_3: Space = intersect(&(*CONSTANT_1),&(v358_2));
      drop(v358_2);
      let v358_4: Space = if has_head(&(v358_3)) { singleton(&[]) } else { Space::new() };
      drop(v358_3);
      let v358_5: Space = compose(&(v358_4),&(v356_10_tail));
      drop(v358_4);
      v356_10.join_into((v358_5).clone());
      }
      v356_10_cursor.ascend(1);
    }
    drop(v356_10_cursor);
    let v356_11: Space = compose(&(v356_9),&(v356_10));
    drop(v356_9);
    drop(v356_10);
    let v356_12: Space = unite(&(v356_7),&(v356_11));
    drop(v356_7);
    drop(v356_11);
    v355_6.join_into((v356_12).clone());
    }
    v355_6_cursor.ascend(1);
  }
  drop(v355_6_cursor);
  (v355_6).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v359_5 = Space::new();
  let mut v359_5_cursor = (*s0).read_zipper();
  for v359_5_byte in v359_5_cursor.child_mask().iter() {
    v359_5_cursor.descend_to_byte(v359_5_byte);
    {
    let v359_5_tail = v359_5_cursor.fork_read_zipper();
    let v359_5_head = Path::from_slice(&[v359_5_byte]);
    let v360_2: Space = singleton(&(v359_5_head));
    let v360_3: Space = intersect(&(*CONSTANT_1),&(v360_2));
    let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = subtract(&(*CONSTANT_0),&(v360_4));
    drop(v360_4);
    let mut v360_6 = Space::new();
    let mut v360_6_cursor = (v359_5_tail).read_zipper();
    for v360_6_byte in v360_6_cursor.child_mask().iter() {
      v360_6_cursor.descend_to_byte(v360_6_byte);
      {
      let v360_6_tail = v360_6_cursor.fork_read_zipper();
      let v360_6_head = Path::from_slice(&[v360_6_byte]);
      let v361_2: Space = Space::new();
      v360_6.join_into((v361_2).clone());
      }
      v360_6_cursor.ascend(1);
    }
    drop(v360_6_cursor);
    let v360_7: Space = compose(&(v360_5),&(v360_6));
    drop(v360_5);
    drop(v360_6);
    let v360_8: Space = intersect(&(*CONSTANT_1),&(v360_2));
    drop(v360_2);
    let v360_9: Space = if has_head(&(v360_8)) { singleton(&[]) } else { Space::new() };
    drop(v360_8);
    let v360_10: Space = compose(&(v360_9),&(v359_5_tail));
    drop(v360_9);
    let v360_11: Space = unite(&(v360_7),&(v360_10));
    drop(v360_7);
    drop(v360_10);
    v359_5.join_into((v360_11).clone());
    }
    v359_5_cursor.ascend(1);
  }
  drop(v359_5_cursor);
  (v359_5).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v362_6 = Space::new();
  let mut v362_6_cursor = (*s0).read_zipper();
  for v362_6_byte in v362_6_cursor.child_mask().iter() {
    v362_6_cursor.descend_to_byte(v362_6_byte);
    {
    let v362_6_tail = v362_6_cursor.fork_read_zipper();
    let v362_6_head = Path::from_slice(&[v362_6_byte]);
    let v363_2: Space = singleton(&(v362_6_head));
    let v363_3: Space = intersect(&(*CONSTANT_1),&(v363_2));
    let v363_4: Space = if has_head(&(v363_3)) { singleton(&[]) } else { Space::new() };
    drop(v363_3);
    let v363_5: Space = subtract(&(*CONSTANT_0),&(v363_4));
    drop(v363_4);
    let mut v363_6 = Space::new();
    let mut v363_6_cursor = (v362_6_tail).read_zipper();
    for v363_6_byte in v363_6_cursor.child_mask().iter() {
      v363_6_cursor.descend_to_byte(v363_6_byte);
      {
      let v363_6_tail = v363_6_cursor.fork_read_zipper();
      let v363_6_head = Path::from_slice(&[v363_6_byte]);
      let v364_2: Space = Space::new();
      v363_6.join_into((v364_2).clone());
      }
      v363_6_cursor.ascend(1);
    }
    drop(v363_6_cursor);
    let v363_7: Space = compose(&(v363_5),&(v363_6));
    drop(v363_5);
    drop(v363_6);
    let v363_8: Space = intersect(&(*CONSTANT_1),&(v363_2));
    drop(v363_2);
    let v363_9: Space = if has_head(&(v363_8)) { singleton(&[]) } else { Space::new() };
    drop(v363_8);
    let mut v363_10 = Space::new();
    let mut v363_10_cursor = (v362_6_tail).read_zipper();
    for v363_10_byte in v363_10_cursor.child_mask().iter() {
      v363_10_cursor.descend_to_byte(v363_10_byte);
      {
      let v363_10_tail = v363_10_cursor.fork_read_zipper();
      let v363_10_head = Path::from_slice(&[v363_10_byte]);
      let v365_2: Space = singleton(&(v363_10_head));
      let v365_3: Space = intersect(&(*CONSTANT_1),&(v365_2));
      drop(v365_2);
      let v365_4: Space = if has_head(&(v365_3)) { singleton(&[]) } else { Space::new() };
      drop(v365_3);
      let v365_5: Space = compose(&(v365_4),&(v363_10_tail));
      drop(v365_4);
      v363_10.join_into((v365_5).clone());
      }
      v363_10_cursor.ascend(1);
    }
    drop(v363_10_cursor);
    let v363_11: Space = compose(&(v363_9),&(v363_10));
    drop(v363_9);
    drop(v363_10);
    let v363_12: Space = unite(&(v363_7),&(v363_11));
    drop(v363_7);
    drop(v363_11);
    v362_6.join_into((v363_12).clone());
    }
    v362_6_cursor.ascend(1);
  }
  drop(v362_6_cursor);
  (v362_6).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v366_5 = Space::new();
  let mut v366_5_cursor = (*s0).read_zipper();
  for v366_5_byte in v366_5_cursor.child_mask().iter() {
    v366_5_cursor.descend_to_byte(v366_5_byte);
    {
    let v366_5_tail = v366_5_cursor.fork_read_zipper();
    let v366_5_head = Path::from_slice(&[v366_5_byte]);
    let v367_2: Space = singleton(&(v366_5_head));
    let v367_3: Space = intersect(&(*CONSTANT_1),&(v367_2));
    let v367_4: Space = if has_head(&(v367_3)) { singleton(&[]) } else { Space::new() };
    drop(v367_3);
    let v367_5: Space = subtract(&(*CONSTANT_0),&(v367_4));
    drop(v367_4);
    let mut v367_6 = Space::new();
    let mut v367_6_cursor = (v366_5_tail).read_zipper();
    for v367_6_byte in v367_6_cursor.child_mask().iter() {
      v367_6_cursor.descend_to_byte(v367_6_byte);
      {
      let v367_6_tail = v367_6_cursor.fork_read_zipper();
      let v367_6_head = Path::from_slice(&[v367_6_byte]);
      let v368_2: Space = Space::new();
      v367_6.join_into((v368_2).clone());
      }
      v367_6_cursor.ascend(1);
    }
    drop(v367_6_cursor);
    let v367_7: Space = compose(&(v367_5),&(v367_6));
    drop(v367_5);
    drop(v367_6);
    let v367_8: Space = intersect(&(*CONSTANT_1),&(v367_2));
    drop(v367_2);
    let v367_9: Space = if has_head(&(v367_8)) { singleton(&[]) } else { Space::new() };
    drop(v367_8);
    let v367_10: Space = compose(&(v367_9),&(v366_5_tail));
    drop(v367_9);
    let v367_11: Space = unite(&(v367_7),&(v367_10));
    drop(v367_7);
    drop(v367_10);
    v366_5.join_into((v367_11).clone());
    }
    v366_5_cursor.ascend(1);
  }
  drop(v366_5_cursor);
  (v366_5).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v369_2 = Space::new();
  let mut v369_2_cursor = (*s0).read_zipper();
  for v369_2_byte in v369_2_cursor.child_mask().iter() {
    v369_2_cursor.descend_to_byte(v369_2_byte);
    {
    let v369_2_tail = v369_2_cursor.fork_read_zipper();
    let v369_2_head = Path::from_slice(&[v369_2_byte]);
    let v370_2: Space = Space::new();
    v369_2.join_into((v370_2).clone());
    }
    v369_2_cursor.ascend(1);
  }
  drop(v369_2_cursor);
  (v369_2).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v371_3 = Space::new();
  let mut v371_3_cursor = (*s0).read_zipper();
  for v371_3_byte in v371_3_cursor.child_mask().iter() {
    v371_3_cursor.descend_to_byte(v371_3_byte);
    {
    let v371_3_tail = v371_3_cursor.fork_read_zipper();
    let v371_3_head = Path::from_slice(&[v371_3_byte]);
    let v372_2: Space = singleton(&(v371_3_head));
    let v372_3: Space = intersect(&(*CONSTANT_1),&(v372_2));
    drop(v372_2);
    let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
    drop(v372_3);
    let v372_5: Space = compose(&(v372_4),&(v371_3_tail));
    drop(v372_4);
    v371_3.join_into((v372_5).clone());
    }
    v371_3_cursor.ascend(1);
  }
  drop(v371_3_cursor);
  (v371_3).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v373_2 = Space::new();
  let mut v373_2_cursor = (*s0).read_zipper();
  for v373_2_byte in v373_2_cursor.child_mask().iter() {
    v373_2_cursor.descend_to_byte(v373_2_byte);
    {
    let v373_2_tail = v373_2_cursor.fork_read_zipper();
    let v373_2_head = Path::from_slice(&[v373_2_byte]);
    let v374_2: Space = Space::new();
    v373_2.join_into((v374_2).clone());
    }
    v373_2_cursor.ascend(1);
  }
  drop(v373_2_cursor);
  (v373_2).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v375_3 = Space::new();
  let mut v375_3_cursor = (*s0).read_zipper();
  for v375_3_byte in v375_3_cursor.child_mask().iter() {
    v375_3_cursor.descend_to_byte(v375_3_byte);
    {
    let v375_3_tail = v375_3_cursor.fork_read_zipper();
    let v375_3_head = Path::from_slice(&[v375_3_byte]);
    let v376_2: Space = singleton(&(v375_3_head));
    let v376_3: Space = intersect(&(*CONSTANT_1),&(v376_2));
    drop(v376_2);
    let v376_4: Space = if has_head(&(v376_3)) { singleton(&[]) } else { Space::new() };
    drop(v376_3);
    let v376_5: Space = compose(&(v376_4),&(v375_3_tail));
    drop(v376_4);
    v375_3.join_into((v376_5).clone());
    }
    v375_3_cursor.ascend(1);
  }
  drop(v375_3_cursor);
  (v375_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
