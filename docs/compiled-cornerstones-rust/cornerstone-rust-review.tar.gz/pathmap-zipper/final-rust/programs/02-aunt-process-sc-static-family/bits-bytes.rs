#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 8 0 0 0 1 1 0 1 1 8 0 1 0 1 1 0 1 1 9 0 1 0 1 1 1 0 1 1 8 0 1 1 1 0 0 1 1 5 0 1 1 1 1 9 1 0 0 1 1 0 0 1 1"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 9 0 0 1 1 1 0 0 1 1 8 0 1 1 0 0 0 1 1 8 0 1 1 0 1 0 1 1 8 1 0 0 1 1 0 1 1 9 1 0 1 1 0 1 0 1 1 5 1 1 0 1 1"));
static CONSTANT_5: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 5 0 0 0 1 1 5 1 0 0 1 1 4 1 0 1 1 2 1 1"));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_10 = Space::new();
  let mut v0_10_cursor = (*s0.expect("unbound native input")).read_zipper();
  for v0_10_byte in v0_10_cursor.child_mask().iter() {
    v0_10_cursor.descend_to_byte(v0_10_byte);
    {
    let v0_10_tail = v0_10_cursor.fork_read_zipper();
    let v0_10_head = Path::from_slice(&[v0_10_byte]);
    let v1_2: Space = singleton(&(v0_10_head));
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_10_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_10_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail).make_space());
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_10_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail).make_space());
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_10_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        {
        let v6_10_tail = v6_10_cursor.fork_read_zipper();
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_10_head),&(v6_10_head));
          let v8_7: Space = routine_1(c, &(v8_6), &(v6_10_tail).make_space());
          compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_10_head),&(v6_10_head));
          let v9_11: Space = routine_3(c, &(v9_6), &(v6_10_tail).make_space());
          drop(v9_6);
          compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = unite(&(v7_8),&(v7_12));
        v6_10.join_into((v7_13).clone());
        }
        v6_10_cursor.ascend(1);
      }
      drop(v6_10_cursor);
      compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_10.join_into((v1_12).clone());
    }
    v0_10_cursor.ascend(1);
  }
  drop(v0_10_cursor);
  let v0_12: Space = wrap(&(v0_10),&(*CONSTANT_2));
  (v0_12).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v10_22: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v10_23: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v10_33 = Space::new();
  let mut v10_33_cursor = (*s0).read_zipper();
  for v10_33_byte in v10_33_cursor.child_mask().iter() {
    v10_33_cursor.descend_to_byte(v10_33_byte);
    {
    let v10_33_tail = v10_33_cursor.fork_read_zipper();
    let v10_33_head = Path::from_slice(&[v10_33_byte]);
    let v11_2: Space = singleton(&(v10_33_head));
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_33_head));
      let mut v12_7 = Space::new();
      let mut v12_7_cursor = (v10_33_tail).read_zipper();
      for v12_7_byte in v12_7_cursor.child_mask().iter() {
        v12_7_cursor.descend_to_byte(v12_7_byte);
        {
        let v12_7_tail = v12_7_cursor.fork_read_zipper();
        let v12_7_head = Path::from_slice(&[v12_7_byte]);
        let v13_2: Space = singleton(&(v12_7_head));
        let v13_3: Space = intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let mut v14_7 = Space::new();
          let mut v14_7_cursor = (v12_7_tail).read_zipper();
          for v14_7_byte in v14_7_cursor.child_mask().iter() {
            v14_7_cursor.descend_to_byte(v14_7_byte);
            {
            let v14_7_tail = v14_7_cursor.fork_read_zipper();
            let v14_7_head = Path::from_slice(&[v14_7_byte]);
            let v15_2: Space = singleton(&(v14_7_head));
            let v15_3: Space = intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v16_7: Space = routine_4(c, &(v16_6), &(v14_7_tail).make_space());
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v17_11: Space = routine_5(c, &(v17_6), &(v14_7_tail).make_space());
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            v14_7.join_into((v15_13).clone());
            }
            v14_7_cursor.ascend(1);
          }
          drop(v14_7_cursor);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let mut v18_11 = Space::new();
          let mut v18_11_cursor = (v12_7_tail).read_zipper();
          for v18_11_byte in v18_11_cursor.child_mask().iter() {
            v18_11_cursor.descend_to_byte(v18_11_byte);
            {
            let v18_11_tail = v18_11_cursor.fork_read_zipper();
            let v18_11_head = Path::from_slice(&[v18_11_byte]);
            let v19_2: Space = singleton(&(v18_11_head));
            let v19_3: Space = intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (v19_5).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&(v18_11_head));
              let v20_7: Space = routine_4(c, &(v20_6), &(v18_11_tail).make_space());
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (v19_10).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&(v18_11_head));
              let v21_11: Space = routine_3(c, &(v21_6), &(v18_11_tail).make_space());
              drop(v21_6);
              compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            v18_11.join_into((v19_13).clone());
            }
            v18_11_cursor.ascend(1);
          }
          drop(v18_11_cursor);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_7.join_into((v13_13).clone());
        }
        v12_7_cursor.ascend(1);
      }
      drop(v12_7_cursor);
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_14: Space = if (v11_10).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v10_33_head));
      let v22_11: Space = unwrap(&(v10_22),&(v10_33_head));
      let v22_12: Space = unwrap(&(v10_23),&(v10_33_head));
      let mut v22_13 = Space::new();
      let mut v22_13_cursor = (v10_33_tail).read_zipper();
      for v22_13_byte in v22_13_cursor.child_mask().iter() {
        v22_13_cursor.descend_to_byte(v22_13_byte);
        {
        let v22_13_tail = v22_13_cursor.fork_read_zipper();
        let v22_13_head = Path::from_slice(&[v22_13_byte]);
        let v23_2: Space = singleton(&(v22_13_head));
        let v23_3: Space = intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&(v22_13_head));
          let mut v24_7 = Space::new();
          let mut v24_7_cursor = (v22_13_tail).read_zipper();
          for v24_7_byte in v24_7_cursor.child_mask().iter() {
            v24_7_cursor.descend_to_byte(v24_7_byte);
            {
            let v24_7_tail = v24_7_cursor.fork_read_zipper();
            let v24_7_head = Path::from_slice(&[v24_7_byte]);
            let v25_2: Space = singleton(&(v24_7_head));
            let v25_3: Space = intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (v25_5).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&(v24_7_head));
              let v26_7: Space = routine_4(c, &(v26_6), &(v24_7_tail).make_space());
              compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (v25_10).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&(v24_7_head));
              let v27_11: Space = routine_5(c, &(v27_6), &(v24_7_tail).make_space());
              drop(v27_6);
              compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = unite(&(v25_8),&(v25_12));
            v24_7.join_into((v25_13).clone());
            }
            v24_7_cursor.ascend(1);
          }
          drop(v24_7_cursor);
          compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_19: Space = if (v23_10).is_empty() { Space::new() } else {
          let v28_11: Space = unwrap(&(v22_11),&(v22_13_head));
          let v28_12: Space = restrict_to(&(*CONSTANT_4),&(v28_11));
          drop(v28_11);
          let mut v28_13 = Space::new();
          let mut v28_13_cursor = (v28_12).read_zipper();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_byte(v28_13_byte);
            {
            let v28_13_tail = v28_13_cursor.fork_read_zipper();
            let v28_13_head = Path::from_slice(&[v28_13_byte]);
            let v29_2: Space = singleton(&(v28_13_head));
            let v29_3: Space = intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (v29_5).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &(v28_13_head), &(v28_13_tail).make_space());
              compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (v29_9).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &(v28_13_head), &(v28_13_tail).make_space());
              compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = unite(&(v29_7),&(v29_11));
            v28_13.join_into((v29_12).clone());
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_12);
          let v28_14: Space = restrict_to(&(*CONSTANT_3),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_cursor = (v28_14).read_zipper();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_byte(v28_15_byte);
            {
            let v28_15_tail = v28_15_cursor.fork_read_zipper();
            let v28_15_head = Path::from_slice(&[v28_15_byte]);
            let v32_2: Space = singleton(&(v28_15_head));
            let v32_3: Space = intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (v32_5).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &(v28_15_head), &(v28_15_tail).make_space());
              compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (v32_9).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &(v28_15_head), &(v28_15_tail).make_space());
              compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = unite(&(v32_7),&(v32_11));
            v28_15.join_into((v32_12).clone());
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          let v28_16: Space = unwrap(&(v22_12),&(v22_13_head));
          let v28_17: Space = subtract(&(v28_15),&(v28_16));
          drop(v28_16);
          let v28_18: Space = intersect(&(v28_17),&(*CONSTANT_5));
          compose(&(v23_10),&(v28_18))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&(v22_13_head));
        let v23_20: Space = wrap(&(v23_19),&(v35_6));
        let v23_21: Space = unite(&(v23_8),&(v23_20));
        v22_13.join_into((v23_21).clone());
        }
        v22_13_cursor.ascend(1);
      }
      drop(v22_13_cursor);
      drop(v22_6);
      drop(v22_11);
      drop(v22_12);
      compose(&(v11_10),&(v22_13))
    };
    drop(v11_10);
    let v11_15: Space = unite(&(v11_8),&(v11_14));
    v10_33.join_into((v11_15).clone());
    }
    v10_33_cursor.ascend(1);
  }
  drop(v10_33_cursor);
  drop(v10_22);
  drop(v10_23);
  (v10_33).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v36_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v36_10: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v36_39 = Space::new();
  let mut v36_39_cursor = (*s0).read_zipper();
  for v36_39_byte in v36_39_cursor.child_mask().iter() {
    v36_39_cursor.descend_to_byte(v36_39_byte);
    {
    let v36_39_tail = v36_39_cursor.fork_read_zipper();
    let v36_39_head = Path::from_slice(&[v36_39_byte]);
    let v37_2: Space = singleton(&(v36_39_head));
    let v37_3: Space = intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&(v36_39_head));
      let mut v38_7 = Space::new();
      let mut v38_7_cursor = (v36_39_tail).read_zipper();
      for v38_7_byte in v38_7_cursor.child_mask().iter() {
        v38_7_cursor.descend_to_byte(v38_7_byte);
        {
        let v38_7_tail = v38_7_cursor.fork_read_zipper();
        let v38_7_head = Path::from_slice(&[v38_7_byte]);
        let v39_2: Space = singleton(&(v38_7_head));
        let v39_3: Space = intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&(v38_7_head));
          let mut v40_7 = Space::new();
          let mut v40_7_cursor = (v38_7_tail).read_zipper();
          for v40_7_byte in v40_7_cursor.child_mask().iter() {
            v40_7_cursor.descend_to_byte(v40_7_byte);
            {
            let v40_7_tail = v40_7_cursor.fork_read_zipper();
            let v40_7_head = Path::from_slice(&[v40_7_byte]);
            let v41_2: Space = singleton(&(v40_7_head));
            let v41_3: Space = intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&(v40_7_head));
              let v42_7: Space = routine_4(c, &(v42_6), &(v40_7_tail).make_space());
              compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&(v40_7_head));
              let v43_11: Space = routine_5(c, &(v43_6), &(v40_7_tail).make_space());
              drop(v43_6);
              compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = unite(&(v41_8),&(v41_12));
            v40_7.join_into((v41_13).clone());
            }
            v40_7_cursor.ascend(1);
          }
          drop(v40_7_cursor);
          compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (v39_10).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&(v38_7_head));
          let mut v44_11 = Space::new();
          let mut v44_11_cursor = (v38_7_tail).read_zipper();
          for v44_11_byte in v44_11_cursor.child_mask().iter() {
            v44_11_cursor.descend_to_byte(v44_11_byte);
            {
            let v44_11_tail = v44_11_cursor.fork_read_zipper();
            let v44_11_head = Path::from_slice(&[v44_11_byte]);
            let v45_2: Space = singleton(&(v44_11_head));
            let v45_3: Space = intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&(v44_11_head));
              let v46_7: Space = routine_4(c, &(v46_6), &(v44_11_tail).make_space());
              compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (v45_10).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&(v44_11_head));
              let v47_11: Space = routine_3(c, &(v47_6), &(v44_11_tail).make_space());
              drop(v47_6);
              compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = unite(&(v45_8),&(v45_12));
            v44_11.join_into((v45_13).clone());
            }
            v44_11_cursor.ascend(1);
          }
          drop(v44_11_cursor);
          drop(v44_6);
          compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = unite(&(v39_8),&(v39_12));
        v38_7.join_into((v39_13).clone());
        }
        v38_7_cursor.ascend(1);
      }
      drop(v38_7_cursor);
      compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_19: Space = if (v37_10).is_empty() { Space::new() } else {
      let v48_11: Space = unwrap(&(v36_8),&(v36_39_head));
      let v48_12: Space = restrict_to(&(*CONSTANT_4),&(v48_11));
      drop(v48_11);
      let mut v48_13 = Space::new();
      let mut v48_13_cursor = (v48_12).read_zipper();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_byte(v48_13_byte);
        {
        let v48_13_tail = v48_13_cursor.fork_read_zipper();
        let v48_13_head = Path::from_slice(&[v48_13_byte]);
        let v49_2: Space = singleton(&(v48_13_head));
        let v49_3: Space = intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (v49_5).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_cursor = (v48_13_tail).read_zipper();
          for v50_6_byte in v50_6_cursor.child_mask().iter() {
            v50_6_cursor.descend_to_byte(v50_6_byte);
            {
            let v50_6_tail = v50_6_cursor.fork_read_zipper();
            let v50_6_head = Path::from_slice(&[v50_6_byte]);
            let v51_2: Space = singleton(&(v50_6_head));
            let v51_3: Space = intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (v51_5).is_empty() { Space::new() } else {
              let v52_6: Path = concat_path(&(v48_13_head),&(v50_6_head));
              let v52_7: Space = routine_10(c, &(v52_6), &(v50_6_tail).make_space());
              compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (v51_10).is_empty() { Space::new() } else {
              let v53_6: Path = concat_path(&(v48_13_head),&(v50_6_head));
              let v53_11: Space = routine_11(c, &(v53_6), &(v50_6_tail).make_space());
              drop(v53_6);
              compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = unite(&(v51_8),&(v51_12));
            v50_6.join_into((v51_13).clone());
            }
            v50_6_cursor.ascend(1);
          }
          drop(v50_6_cursor);
          compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (v49_9).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_cursor = (v48_13_tail).read_zipper();
          for v54_10_byte in v54_10_cursor.child_mask().iter() {
            v54_10_cursor.descend_to_byte(v54_10_byte);
            {
            let v54_10_tail = v54_10_cursor.fork_read_zipper();
            let v54_10_head = Path::from_slice(&[v54_10_byte]);
            let v55_2: Space = singleton(&(v54_10_head));
            let v55_3: Space = intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (v55_5).is_empty() { Space::new() } else {
              let v56_6: Path = concat_path(&(v48_13_head),&(v54_10_head));
              let v56_7: Space = routine_10(c, &(v56_6), &(v54_10_tail).make_space());
              compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (v55_10).is_empty() { Space::new() } else {
              let v57_6: Path = concat_path(&(v48_13_head),&(v54_10_head));
              let v57_11: Space = routine_12(c, &(v57_6), &(v54_10_tail).make_space());
              drop(v57_6);
              compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = unite(&(v55_8),&(v55_12));
            v54_10.join_into((v55_13).clone());
            }
            v54_10_cursor.ascend(1);
          }
          drop(v54_10_cursor);
          compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = unite(&(v49_7),&(v49_11));
        v48_13.join_into((v49_12).clone());
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_12);
      let v48_14: Space = restrict_to(&(*CONSTANT_3),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_cursor = (v48_14).read_zipper();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_byte(v48_15_byte);
        {
        let v48_15_tail = v48_15_cursor.fork_read_zipper();
        let v48_15_head = Path::from_slice(&[v48_15_byte]);
        let v58_2: Space = singleton(&(v48_15_head));
        let v58_3: Space = intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (v58_5).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_cursor = (v48_15_tail).read_zipper();
          for v59_6_byte in v59_6_cursor.child_mask().iter() {
            v59_6_cursor.descend_to_byte(v59_6_byte);
            {
            let v59_6_tail = v59_6_cursor.fork_read_zipper();
            let v59_6_head = Path::from_slice(&[v59_6_byte]);
            let v60_2: Space = singleton(&(v59_6_head));
            let v60_3: Space = intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (v60_5).is_empty() { Space::new() } else {
              let v61_6: Path = concat_path(&(v48_15_head),&(v59_6_head));
              let v61_7: Space = routine_13(c, &(v61_6), &(v59_6_tail).make_space());
              compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (v60_10).is_empty() { Space::new() } else {
              let v62_6: Path = concat_path(&(v48_15_head),&(v59_6_head));
              let v62_11: Space = routine_14(c, &(v62_6), &(v59_6_tail).make_space());
              drop(v62_6);
              compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = unite(&(v60_8),&(v60_12));
            v59_6.join_into((v60_13).clone());
            }
            v59_6_cursor.ascend(1);
          }
          drop(v59_6_cursor);
          compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (v58_9).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_cursor = (v48_15_tail).read_zipper();
          for v63_10_byte in v63_10_cursor.child_mask().iter() {
            v63_10_cursor.descend_to_byte(v63_10_byte);
            {
            let v63_10_tail = v63_10_cursor.fork_read_zipper();
            let v63_10_head = Path::from_slice(&[v63_10_byte]);
            let v64_2: Space = singleton(&(v63_10_head));
            let v64_3: Space = intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
              let v65_6: Path = concat_path(&(v48_15_head),&(v63_10_head));
              let v65_7: Space = routine_13(c, &(v65_6), &(v63_10_tail).make_space());
              compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (v64_10).is_empty() { Space::new() } else {
              let v66_6: Path = concat_path(&(v48_15_head),&(v63_10_head));
              let v66_11: Space = routine_15(c, &(v66_6), &(v63_10_tail).make_space());
              drop(v66_6);
              compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = unite(&(v64_8),&(v64_12));
            v63_10.join_into((v64_13).clone());
            }
            v63_10_cursor.ascend(1);
          }
          drop(v63_10_cursor);
          compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = unite(&(v58_7),&(v58_11));
        v48_15.join_into((v58_12).clone());
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      let v48_16: Space = unwrap(&(v36_10),&(v36_39_head));
      let v48_17: Space = subtract(&(v48_15),&(v48_16));
      drop(v48_16);
      let v48_18: Space = intersect(&(v48_17),&(*CONSTANT_5));
      compose(&(v37_10),&(v48_18))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&(v36_39_head));
    let v37_20: Space = wrap(&(v37_19),&(v67_6));
    let v37_21: Space = unite(&(v37_8),&(v37_20));
    v36_39.join_into((v37_21).clone());
    }
    v36_39_cursor.ascend(1);
  }
  drop(v36_39_cursor);
  drop(v36_8);
  drop(v36_10);
  (v36_39).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v68_5: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v68_6: Space = restrict_to(&(*CONSTANT_4),&(v68_5));
  drop(v68_5);
  let mut v68_25 = Space::new();
  let mut v68_25_cursor = (v68_6).read_zipper();
  for v68_25_byte in v68_25_cursor.child_mask().iter() {
    v68_25_cursor.descend_to_byte(v68_25_byte);
    {
    let v68_25_tail = v68_25_cursor.fork_read_zipper();
    let v68_25_head = Path::from_slice(&[v68_25_byte]);
    let v69_2: Space = singleton(&(v68_25_head));
    let v69_3: Space = intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (v69_5).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_cursor = (v68_25_tail).read_zipper();
      for v70_6_byte in v70_6_cursor.child_mask().iter() {
        v70_6_cursor.descend_to_byte(v70_6_byte);
        {
        let v70_6_tail = v70_6_cursor.fork_read_zipper();
        let v70_6_head = Path::from_slice(&[v70_6_byte]);
        let v71_2: Space = singleton(&(v70_6_head));
        let v71_3: Space = intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
          let v72_6: Path = concat_path(&(v68_25_head),&(v70_6_head));
          let mut v72_7 = Space::new();
          let mut v72_7_cursor = (v70_6_tail).read_zipper();
          for v72_7_byte in v72_7_cursor.child_mask().iter() {
            v72_7_cursor.descend_to_byte(v72_7_byte);
            {
            let v72_7_tail = v72_7_cursor.fork_read_zipper();
            let v72_7_head = Path::from_slice(&[v72_7_byte]);
            let v73_2: Space = singleton(&(v72_7_head));
            let v73_3: Space = intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (v73_5).is_empty() { Space::new() } else {
              let v74_6: Path = concat_path(&(v72_6),&(v72_7_head));
              let v74_7: Space = routine_16(c, &(v74_6), &(v72_7_tail).make_space());
              compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (v73_10).is_empty() { Space::new() } else {
              let v75_6: Path = concat_path(&(v72_6),&(v72_7_head));
              let v75_11: Space = routine_17(c, &(v75_6), &(v72_7_tail).make_space());
              drop(v75_6);
              compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = unite(&(v73_8),&(v73_12));
            v72_7.join_into((v73_13).clone());
            }
            v72_7_cursor.ascend(1);
          }
          drop(v72_7_cursor);
          compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (v71_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v68_25_head),&(v70_6_head));
          let mut v76_11 = Space::new();
          let mut v76_11_cursor = (v70_6_tail).read_zipper();
          for v76_11_byte in v76_11_cursor.child_mask().iter() {
            v76_11_cursor.descend_to_byte(v76_11_byte);
            {
            let v76_11_tail = v76_11_cursor.fork_read_zipper();
            let v76_11_head = Path::from_slice(&[v76_11_byte]);
            let v77_2: Space = singleton(&(v76_11_head));
            let v77_3: Space = intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (v77_5).is_empty() { Space::new() } else {
              let v78_6: Path = concat_path(&(v76_6),&(v76_11_head));
              let v78_7: Space = routine_16(c, &(v78_6), &(v76_11_tail).make_space());
              compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (v77_10).is_empty() { Space::new() } else {
              let v79_6: Path = concat_path(&(v76_6),&(v76_11_head));
              let v79_11: Space = routine_12(c, &(v79_6), &(v76_11_tail).make_space());
              drop(v79_6);
              compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = unite(&(v77_8),&(v77_12));
            v76_11.join_into((v77_13).clone());
            }
            v76_11_cursor.ascend(1);
          }
          drop(v76_11_cursor);
          drop(v76_6);
          compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = unite(&(v71_8),&(v71_12));
        v70_6.join_into((v71_13).clone());
        }
        v70_6_cursor.ascend(1);
      }
      drop(v70_6_cursor);
      compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (v69_9).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_cursor = (v68_25_tail).read_zipper();
      for v80_10_byte in v80_10_cursor.child_mask().iter() {
        v80_10_cursor.descend_to_byte(v80_10_byte);
        {
        let v80_10_tail = v80_10_cursor.fork_read_zipper();
        let v80_10_head = Path::from_slice(&[v80_10_byte]);
        let v81_2: Space = singleton(&(v80_10_head));
        let v81_3: Space = intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
          let v82_6: Path = concat_path(&(v68_25_head),&(v80_10_head));
          let mut v82_7 = Space::new();
          let mut v82_7_cursor = (v80_10_tail).read_zipper();
          for v82_7_byte in v82_7_cursor.child_mask().iter() {
            v82_7_cursor.descend_to_byte(v82_7_byte);
            {
            let v82_7_tail = v82_7_cursor.fork_read_zipper();
            let v82_7_head = Path::from_slice(&[v82_7_byte]);
            let v83_2: Space = singleton(&(v82_7_head));
            let v83_3: Space = intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (v83_5).is_empty() { Space::new() } else {
              let v84_6: Path = concat_path(&(v82_6),&(v82_7_head));
              let v84_7: Space = routine_16(c, &(v84_6), &(v82_7_tail).make_space());
              compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (v83_10).is_empty() { Space::new() } else {
              let v85_6: Path = concat_path(&(v82_6),&(v82_7_head));
              let v85_11: Space = routine_17(c, &(v85_6), &(v82_7_tail).make_space());
              drop(v85_6);
              compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = unite(&(v83_8),&(v83_12));
            v82_7.join_into((v83_13).clone());
            }
            v82_7_cursor.ascend(1);
          }
          drop(v82_7_cursor);
          drop(v82_6);
          compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = compose(&(v81_10),&(v80_10_tail));
        drop(v81_10);
        let v81_12: Space = unite(&(v81_8),&(v81_11));
        drop(v81_11);
        v80_10.join_into((v81_12).clone());
        }
        v80_10_cursor.ascend(1);
      }
      drop(v80_10_cursor);
      compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = unite(&(v69_7),&(v69_11));
    v68_25.join_into((v69_12).clone());
    }
    v68_25_cursor.ascend(1);
  }
  drop(v68_25_cursor);
  drop(v68_6);
  let v68_26: Space = restrict_to(&(*CONSTANT_3),&(v68_25));
  let mut v68_45 = Space::new();
  let mut v68_45_cursor = (v68_26).read_zipper();
  for v68_45_byte in v68_45_cursor.child_mask().iter() {
    v68_45_cursor.descend_to_byte(v68_45_byte);
    {
    let v68_45_tail = v68_45_cursor.fork_read_zipper();
    let v68_45_head = Path::from_slice(&[v68_45_byte]);
    let v86_2: Space = singleton(&(v68_45_head));
    let v86_3: Space = intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (v86_5).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_cursor = (v68_45_tail).read_zipper();
      for v87_6_byte in v87_6_cursor.child_mask().iter() {
        v87_6_cursor.descend_to_byte(v87_6_byte);
        {
        let v87_6_tail = v87_6_cursor.fork_read_zipper();
        let v87_6_head = Path::from_slice(&[v87_6_byte]);
        let v88_2: Space = singleton(&(v87_6_head));
        let v88_3: Space = intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v68_45_head),&(v87_6_head));
          let mut v89_7 = Space::new();
          let mut v89_7_cursor = (v87_6_tail).read_zipper();
          for v89_7_byte in v89_7_cursor.child_mask().iter() {
            v89_7_cursor.descend_to_byte(v89_7_byte);
            {
            let v89_7_tail = v89_7_cursor.fork_read_zipper();
            let v89_7_head = Path::from_slice(&[v89_7_byte]);
            let v90_2: Space = singleton(&(v89_7_head));
            let v90_3: Space = intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
              let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
              let v91_7: Space = routine_18(c, &(v91_6), &(v89_7_tail).make_space());
              compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
              let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
              let v92_11: Space = routine_19(c, &(v92_6), &(v89_7_tail).make_space());
              drop(v92_6);
              compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = unite(&(v90_8),&(v90_12));
            v89_7.join_into((v90_13).clone());
            }
            v89_7_cursor.ascend(1);
          }
          drop(v89_7_cursor);
          compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
          let v93_6: Path = concat_path(&(v68_45_head),&(v87_6_head));
          let mut v93_11 = Space::new();
          let mut v93_11_cursor = (v87_6_tail).read_zipper();
          for v93_11_byte in v93_11_cursor.child_mask().iter() {
            v93_11_cursor.descend_to_byte(v93_11_byte);
            {
            let v93_11_tail = v93_11_cursor.fork_read_zipper();
            let v93_11_head = Path::from_slice(&[v93_11_byte]);
            let v94_2: Space = singleton(&(v93_11_head));
            let v94_3: Space = intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (v94_5).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v93_6),&(v93_11_head));
              let v95_7: Space = routine_18(c, &(v95_6), &(v93_11_tail).make_space());
              compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (v94_10).is_empty() { Space::new() } else {
              let v96_6: Path = concat_path(&(v93_6),&(v93_11_head));
              let v96_11: Space = routine_15(c, &(v96_6), &(v93_11_tail).make_space());
              drop(v96_6);
              compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = unite(&(v94_8),&(v94_12));
            v93_11.join_into((v94_13).clone());
            }
            v93_11_cursor.ascend(1);
          }
          drop(v93_11_cursor);
          drop(v93_6);
          compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = unite(&(v88_8),&(v88_12));
        v87_6.join_into((v88_13).clone());
        }
        v87_6_cursor.ascend(1);
      }
      drop(v87_6_cursor);
      compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (v86_9).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_cursor = (v68_45_tail).read_zipper();
      for v97_10_byte in v97_10_cursor.child_mask().iter() {
        v97_10_cursor.descend_to_byte(v97_10_byte);
        {
        let v97_10_tail = v97_10_cursor.fork_read_zipper();
        let v97_10_head = Path::from_slice(&[v97_10_byte]);
        let v98_2: Space = singleton(&(v97_10_head));
        let v98_3: Space = intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
          let v99_6: Path = concat_path(&(v68_45_head),&(v97_10_head));
          let mut v99_7 = Space::new();
          let mut v99_7_cursor = (v97_10_tail).read_zipper();
          for v99_7_byte in v99_7_cursor.child_mask().iter() {
            v99_7_cursor.descend_to_byte(v99_7_byte);
            {
            let v99_7_tail = v99_7_cursor.fork_read_zipper();
            let v99_7_head = Path::from_slice(&[v99_7_byte]);
            let v100_2: Space = singleton(&(v99_7_head));
            let v100_3: Space = intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
              let v101_6: Path = concat_path(&(v99_6),&(v99_7_head));
              let v101_7: Space = routine_18(c, &(v101_6), &(v99_7_tail).make_space());
              compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
              let v102_6: Path = concat_path(&(v99_6),&(v99_7_head));
              let v102_11: Space = routine_19(c, &(v102_6), &(v99_7_tail).make_space());
              drop(v102_6);
              compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = unite(&(v100_8),&(v100_12));
            v99_7.join_into((v100_13).clone());
            }
            v99_7_cursor.ascend(1);
          }
          drop(v99_7_cursor);
          drop(v99_6);
          compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = compose(&(v98_10),&(v97_10_tail));
        drop(v98_10);
        let v98_12: Space = unite(&(v98_8),&(v98_11));
        drop(v98_11);
        v97_10.join_into((v98_12).clone());
        }
        v97_10_cursor.ascend(1);
      }
      drop(v97_10_cursor);
      compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = unite(&(v86_7),&(v86_11));
    v68_45.join_into((v86_12).clone());
    }
    v68_45_cursor.ascend(1);
  }
  drop(v68_45_cursor);
  let v68_47: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v68_48: Space = subtract(&(v68_45),&(v68_47));
  drop(v68_47);
  let v68_50: Space = intersect(&(v68_48),&(*CONSTANT_5));
  let v68_51: Space = wrap(&(v68_50),&(*p0));
  (v68_51).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v103_2 = Space::new();
  let mut v103_2_cursor = (*s0).read_zipper();
  for v103_2_byte in v103_2_cursor.child_mask().iter() {
    v103_2_cursor.descend_to_byte(v103_2_byte);
    {
    let v103_2_tail = v103_2_cursor.fork_read_zipper();
    let v103_2_head = Path::from_slice(&[v103_2_byte]);
    let v104_2: Space = Space::new();
    v103_2.join_into((v104_2).clone());
    }
    v103_2_cursor.ascend(1);
  }
  drop(v103_2_cursor);
  (v103_2).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v105_6: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let v105_8: Space = unwrap(&(*CONSTANT_4),&(*p0));
  let mut v105_28 = Space::new();
  let mut v105_28_cursor = (*s0).read_zipper();
  for v105_28_byte in v105_28_cursor.child_mask().iter() {
    v105_28_cursor.descend_to_byte(v105_28_byte);
    {
    let v105_28_tail = v105_28_cursor.fork_read_zipper();
    let v105_28_head = Path::from_slice(&[v105_28_byte]);
    let v106_2: Space = singleton(&(v105_28_head));
    let v106_3: Space = intersect(&(*CONSTANT_1),&(v106_2));
    drop(v106_2);
    let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
    drop(v106_3);
    let v106_13: Space = if (v106_4).is_empty() { Space::new() } else {
      let v107_5: Space = unwrap(&(v105_6),&(v105_28_head));
      let v107_6: Space = restrict_to(&(*CONSTANT_4),&(v107_5));
      drop(v107_5);
      let mut v107_7 = Space::new();
      let mut v107_7_cursor = (v107_6).read_zipper();
      for v107_7_byte in v107_7_cursor.child_mask().iter() {
        v107_7_cursor.descend_to_byte(v107_7_byte);
        {
        let v107_7_tail = v107_7_cursor.fork_read_zipper();
        let v107_7_head = Path::from_slice(&[v107_7_byte]);
        let v108_2: Space = singleton(&(v107_7_head));
        let v108_3: Space = intersect(&(*CONSTANT_1),&(v108_2));
        let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
        drop(v108_3);
        let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
        drop(v108_4);
        let v108_7: Space = if (v108_5).is_empty() { Space::new() } else {
          let mut v109_6 = Space::new();
          let mut v109_6_cursor = (v107_7_tail).read_zipper();
          for v109_6_byte in v109_6_cursor.child_mask().iter() {
            v109_6_cursor.descend_to_byte(v109_6_byte);
            {
            let v109_6_tail = v109_6_cursor.fork_read_zipper();
            let v109_6_head = Path::from_slice(&[v109_6_byte]);
            let v110_2: Space = singleton(&(v109_6_head));
            let v110_3: Space = intersect(&(*CONSTANT_1),&(v110_2));
            let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
            drop(v110_3);
            let v110_5: Space = subtract(&(*CONSTANT_0),&(v110_4));
            drop(v110_4);
            let v110_8: Space = if (v110_5).is_empty() { Space::new() } else {
              let v111_6: Path = concat_path(&(v107_7_head),&(v109_6_head));
              let v111_7: Space = routine_10(c, &(v111_6), &(v109_6_tail).make_space());
              compose(&(v110_5),&(v111_7))
            };
            drop(v110_5);
            let v110_9: Space = intersect(&(*CONSTANT_1),&(v110_2));
            drop(v110_2);
            let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
            drop(v110_9);
            let v110_12: Space = if (v110_10).is_empty() { Space::new() } else {
              let v112_6: Path = concat_path(&(v107_7_head),&(v109_6_head));
              let v112_11: Space = routine_11(c, &(v112_6), &(v109_6_tail).make_space());
              drop(v112_6);
              compose(&(v110_10),&(v112_11))
            };
            drop(v110_10);
            let v110_13: Space = unite(&(v110_8),&(v110_12));
            v109_6.join_into((v110_13).clone());
            }
            v109_6_cursor.ascend(1);
          }
          drop(v109_6_cursor);
          compose(&(v108_5),&(v109_6))
        };
        drop(v108_5);
        let v108_8: Space = intersect(&(*CONSTANT_1),&(v108_2));
        drop(v108_2);
        let v108_9: Space = if has_head(&(v108_8)) { singleton(&[]) } else { Space::new() };
        drop(v108_8);
        let v108_11: Space = if (v108_9).is_empty() { Space::new() } else {
          let mut v113_10 = Space::new();
          let mut v113_10_cursor = (v107_7_tail).read_zipper();
          for v113_10_byte in v113_10_cursor.child_mask().iter() {
            v113_10_cursor.descend_to_byte(v113_10_byte);
            {
            let v113_10_tail = v113_10_cursor.fork_read_zipper();
            let v113_10_head = Path::from_slice(&[v113_10_byte]);
            let v114_2: Space = singleton(&(v113_10_head));
            let v114_3: Space = intersect(&(*CONSTANT_1),&(v114_2));
            let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
            drop(v114_3);
            let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
            drop(v114_4);
            let v114_8: Space = if (v114_5).is_empty() { Space::new() } else {
              let v115_6: Path = concat_path(&(v107_7_head),&(v113_10_head));
              let v115_7: Space = routine_10(c, &(v115_6), &(v113_10_tail).make_space());
              compose(&(v114_5),&(v115_7))
            };
            drop(v114_5);
            let v114_9: Space = intersect(&(*CONSTANT_1),&(v114_2));
            drop(v114_2);
            let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
            drop(v114_9);
            let v114_12: Space = if (v114_10).is_empty() { Space::new() } else {
              let v116_6: Path = concat_path(&(v107_7_head),&(v113_10_head));
              let v116_11: Space = routine_12(c, &(v116_6), &(v113_10_tail).make_space());
              drop(v116_6);
              compose(&(v114_10),&(v116_11))
            };
            drop(v114_10);
            let v114_13: Space = unite(&(v114_8),&(v114_12));
            v113_10.join_into((v114_13).clone());
            }
            v113_10_cursor.ascend(1);
          }
          drop(v113_10_cursor);
          compose(&(v108_9),&(v113_10))
        };
        drop(v108_9);
        let v108_12: Space = unite(&(v108_7),&(v108_11));
        v107_7.join_into((v108_12).clone());
        }
        v107_7_cursor.ascend(1);
      }
      drop(v107_7_cursor);
      drop(v107_6);
      let v107_8: Space = restrict_to(&(*CONSTANT_3),&(v107_7));
      let mut v107_9 = Space::new();
      let mut v107_9_cursor = (v107_8).read_zipper();
      for v107_9_byte in v107_9_cursor.child_mask().iter() {
        v107_9_cursor.descend_to_byte(v107_9_byte);
        {
        let v107_9_tail = v107_9_cursor.fork_read_zipper();
        let v107_9_head = Path::from_slice(&[v107_9_byte]);
        let v117_2: Space = singleton(&(v107_9_head));
        let v117_3: Space = intersect(&(*CONSTANT_1),&(v117_2));
        let v117_4: Space = if has_head(&(v117_3)) { singleton(&[]) } else { Space::new() };
        drop(v117_3);
        let v117_5: Space = subtract(&(*CONSTANT_0),&(v117_4));
        drop(v117_4);
        let v117_7: Space = if (v117_5).is_empty() { Space::new() } else {
          let mut v118_6 = Space::new();
          let mut v118_6_cursor = (v107_9_tail).read_zipper();
          for v118_6_byte in v118_6_cursor.child_mask().iter() {
            v118_6_cursor.descend_to_byte(v118_6_byte);
            {
            let v118_6_tail = v118_6_cursor.fork_read_zipper();
            let v118_6_head = Path::from_slice(&[v118_6_byte]);
            let v119_2: Space = singleton(&(v118_6_head));
            let v119_3: Space = intersect(&(*CONSTANT_1),&(v119_2));
            let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
            drop(v119_3);
            let v119_5: Space = subtract(&(*CONSTANT_0),&(v119_4));
            drop(v119_4);
            let v119_8: Space = if (v119_5).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v107_9_head),&(v118_6_head));
              let v120_7: Space = routine_13(c, &(v120_6), &(v118_6_tail).make_space());
              compose(&(v119_5),&(v120_7))
            };
            drop(v119_5);
            let v119_9: Space = intersect(&(*CONSTANT_1),&(v119_2));
            drop(v119_2);
            let v119_10: Space = if has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
            drop(v119_9);
            let v119_12: Space = if (v119_10).is_empty() { Space::new() } else {
              let v121_6: Path = concat_path(&(v107_9_head),&(v118_6_head));
              let v121_11: Space = routine_14(c, &(v121_6), &(v118_6_tail).make_space());
              drop(v121_6);
              compose(&(v119_10),&(v121_11))
            };
            drop(v119_10);
            let v119_13: Space = unite(&(v119_8),&(v119_12));
            v118_6.join_into((v119_13).clone());
            }
            v118_6_cursor.ascend(1);
          }
          drop(v118_6_cursor);
          compose(&(v117_5),&(v118_6))
        };
        drop(v117_5);
        let v117_8: Space = intersect(&(*CONSTANT_1),&(v117_2));
        drop(v117_2);
        let v117_9: Space = if has_head(&(v117_8)) { singleton(&[]) } else { Space::new() };
        drop(v117_8);
        let v117_11: Space = if (v117_9).is_empty() { Space::new() } else {
          let mut v122_10 = Space::new();
          let mut v122_10_cursor = (v107_9_tail).read_zipper();
          for v122_10_byte in v122_10_cursor.child_mask().iter() {
            v122_10_cursor.descend_to_byte(v122_10_byte);
            {
            let v122_10_tail = v122_10_cursor.fork_read_zipper();
            let v122_10_head = Path::from_slice(&[v122_10_byte]);
            let v123_2: Space = singleton(&(v122_10_head));
            let v123_3: Space = intersect(&(*CONSTANT_1),&(v123_2));
            let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
            drop(v123_3);
            let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
            drop(v123_4);
            let v123_8: Space = if (v123_5).is_empty() { Space::new() } else {
              let v124_6: Path = concat_path(&(v107_9_head),&(v122_10_head));
              let v124_7: Space = routine_13(c, &(v124_6), &(v122_10_tail).make_space());
              compose(&(v123_5),&(v124_7))
            };
            drop(v123_5);
            let v123_9: Space = intersect(&(*CONSTANT_1),&(v123_2));
            drop(v123_2);
            let v123_10: Space = if has_head(&(v123_9)) { singleton(&[]) } else { Space::new() };
            drop(v123_9);
            let v123_12: Space = if (v123_10).is_empty() { Space::new() } else {
              let v125_6: Path = concat_path(&(v107_9_head),&(v122_10_head));
              let v125_11: Space = routine_15(c, &(v125_6), &(v122_10_tail).make_space());
              drop(v125_6);
              compose(&(v123_10),&(v125_11))
            };
            drop(v123_10);
            let v123_13: Space = unite(&(v123_8),&(v123_12));
            v122_10.join_into((v123_13).clone());
            }
            v122_10_cursor.ascend(1);
          }
          drop(v122_10_cursor);
          compose(&(v117_9),&(v122_10))
        };
        drop(v117_9);
        let v117_12: Space = unite(&(v117_7),&(v117_11));
        v107_9.join_into((v117_12).clone());
        }
        v107_9_cursor.ascend(1);
      }
      drop(v107_9_cursor);
      let v107_10: Space = unwrap(&(v105_8),&(v105_28_head));
      let v107_11: Space = subtract(&(v107_9),&(v107_10));
      drop(v107_10);
      let v107_12: Space = intersect(&(v107_11),&(*CONSTANT_5));
      compose(&(v106_4),&(v107_12))
    };
    drop(v106_4);
    let v106_14: Path = concat_path(&(*p0),&(v105_28_head));
    let v106_15: Space = wrap(&(v106_13),&(v106_14));
    drop(v106_14);
    v105_28.join_into((v106_15).clone());
    }
    v105_28_cursor.ascend(1);
  }
  drop(v105_28_cursor);
  drop(v105_6);
  drop(v105_8);
  (v105_28).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v126_20 = Space::new();
  let mut v126_20_cursor = (*s0).read_zipper();
  for v126_20_byte in v126_20_cursor.child_mask().iter() {
    v126_20_cursor.descend_to_byte(v126_20_byte);
    {
    let v126_20_tail = v126_20_cursor.fork_read_zipper();
    let v126_20_head = Path::from_slice(&[v126_20_byte]);
    let v127_2: Space = singleton(&(v126_20_head));
    let v127_3: Space = intersect(&(*CONSTANT_1),&(v127_2));
    let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
    drop(v127_3);
    let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
    drop(v127_4);
    let v127_8: Space = if (v127_5).is_empty() { Space::new() } else {
      let v128_6: Path = concat_path(&(*p0),&(v126_20_head));
      let mut v128_7 = Space::new();
      let mut v128_7_cursor = (v126_20_tail).read_zipper();
      for v128_7_byte in v128_7_cursor.child_mask().iter() {
        v128_7_cursor.descend_to_byte(v128_7_byte);
        {
        let v128_7_tail = v128_7_cursor.fork_read_zipper();
        let v128_7_head = Path::from_slice(&[v128_7_byte]);
        let v129_2: Space = singleton(&(v128_7_head));
        let v129_3: Space = intersect(&(*CONSTANT_1),&(v129_2));
        let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
        drop(v129_3);
        let v129_5: Space = subtract(&(*CONSTANT_0),&(v129_4));
        drop(v129_4);
        let v129_8: Space = if (v129_5).is_empty() { Space::new() } else {
          let v130_6: Path = concat_path(&(v128_6),&(v128_7_head));
          let mut v130_7 = Space::new();
          let mut v130_7_cursor = (v128_7_tail).read_zipper();
          for v130_7_byte in v130_7_cursor.child_mask().iter() {
            v130_7_cursor.descend_to_byte(v130_7_byte);
            {
            let v130_7_tail = v130_7_cursor.fork_read_zipper();
            let v130_7_head = Path::from_slice(&[v130_7_byte]);
            let v131_2: Space = singleton(&(v130_7_head));
            let v131_3: Space = intersect(&(*CONSTANT_1),&(v131_2));
            let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
            drop(v131_3);
            let v131_5: Space = subtract(&(*CONSTANT_0),&(v131_4));
            drop(v131_4);
            let v131_8: Space = if (v131_5).is_empty() { Space::new() } else {
              let v132_6: Path = concat_path(&(v130_6),&(v130_7_head));
              let v132_7: Space = routine_20(c, &(v132_6), &(v130_7_tail).make_space());
              compose(&(v131_5),&(v132_7))
            };
            drop(v131_5);
            let v131_9: Space = intersect(&(*CONSTANT_1),&(v131_2));
            drop(v131_2);
            let v131_10: Space = if has_head(&(v131_9)) { singleton(&[]) } else { Space::new() };
            drop(v131_9);
            let v131_12: Space = if (v131_10).is_empty() { Space::new() } else {
              let v133_6: Path = concat_path(&(v130_6),&(v130_7_head));
              let v133_11: Space = routine_21(c, &(v133_6), &(v130_7_tail).make_space());
              drop(v133_6);
              compose(&(v131_10),&(v133_11))
            };
            drop(v131_10);
            let v131_13: Space = unite(&(v131_8),&(v131_12));
            v130_7.join_into((v131_13).clone());
            }
            v130_7_cursor.ascend(1);
          }
          drop(v130_7_cursor);
          compose(&(v129_5),&(v130_7))
        };
        drop(v129_5);
        let v129_9: Space = intersect(&(*CONSTANT_1),&(v129_2));
        drop(v129_2);
        let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
        drop(v129_9);
        let v129_12: Space = if (v129_10).is_empty() { Space::new() } else {
          let v134_6: Path = concat_path(&(v128_6),&(v128_7_head));
          let mut v134_11 = Space::new();
          let mut v134_11_cursor = (v128_7_tail).read_zipper();
          for v134_11_byte in v134_11_cursor.child_mask().iter() {
            v134_11_cursor.descend_to_byte(v134_11_byte);
            {
            let v134_11_tail = v134_11_cursor.fork_read_zipper();
            let v134_11_head = Path::from_slice(&[v134_11_byte]);
            let v135_2: Space = singleton(&(v134_11_head));
            let v135_3: Space = intersect(&(*CONSTANT_1),&(v135_2));
            let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
            drop(v135_3);
            let v135_5: Space = subtract(&(*CONSTANT_0),&(v135_4));
            drop(v135_4);
            let v135_8: Space = if (v135_5).is_empty() { Space::new() } else {
              let v136_6: Path = concat_path(&(v134_6),&(v134_11_head));
              let v136_7: Space = routine_20(c, &(v136_6), &(v134_11_tail).make_space());
              compose(&(v135_5),&(v136_7))
            };
            drop(v135_5);
            let v135_9: Space = intersect(&(*CONSTANT_1),&(v135_2));
            drop(v135_2);
            let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
            drop(v135_9);
            let v135_12: Space = if (v135_10).is_empty() { Space::new() } else {
              let v137_6: Path = concat_path(&(v134_6),&(v134_11_head));
              let v137_11: Space = routine_12(c, &(v137_6), &(v134_11_tail).make_space());
              drop(v137_6);
              compose(&(v135_10),&(v137_11))
            };
            drop(v135_10);
            let v135_13: Space = unite(&(v135_8),&(v135_12));
            v134_11.join_into((v135_13).clone());
            }
            v134_11_cursor.ascend(1);
          }
          drop(v134_11_cursor);
          drop(v134_6);
          compose(&(v129_10),&(v134_11))
        };
        drop(v129_10);
        let v129_13: Space = unite(&(v129_8),&(v129_12));
        v128_7.join_into((v129_13).clone());
        }
        v128_7_cursor.ascend(1);
      }
      drop(v128_7_cursor);
      compose(&(v127_5),&(v128_7))
    };
    drop(v127_5);
    let v127_9: Space = intersect(&(*CONSTANT_1),&(v127_2));
    drop(v127_2);
    let v127_10: Space = if has_head(&(v127_9)) { singleton(&[]) } else { Space::new() };
    drop(v127_9);
    let v127_12: Space = if (v127_10).is_empty() { Space::new() } else {
      let v138_6: Path = concat_path(&(*p0),&(v126_20_head));
      let mut v138_11 = Space::new();
      let mut v138_11_cursor = (v126_20_tail).read_zipper();
      for v138_11_byte in v138_11_cursor.child_mask().iter() {
        v138_11_cursor.descend_to_byte(v138_11_byte);
        {
        let v138_11_tail = v138_11_cursor.fork_read_zipper();
        let v138_11_head = Path::from_slice(&[v138_11_byte]);
        let v139_2: Space = singleton(&(v138_11_head));
        let v139_3: Space = intersect(&(*CONSTANT_1),&(v139_2));
        let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
        drop(v139_3);
        let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
        drop(v139_4);
        let v139_8: Space = if (v139_5).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v138_6),&(v138_11_head));
          let mut v140_7 = Space::new();
          let mut v140_7_cursor = (v138_11_tail).read_zipper();
          for v140_7_byte in v140_7_cursor.child_mask().iter() {
            v140_7_cursor.descend_to_byte(v140_7_byte);
            {
            let v140_7_tail = v140_7_cursor.fork_read_zipper();
            let v140_7_head = Path::from_slice(&[v140_7_byte]);
            let v141_2: Space = singleton(&(v140_7_head));
            let v141_3: Space = intersect(&(*CONSTANT_1),&(v141_2));
            let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
            drop(v141_3);
            let v141_5: Space = subtract(&(*CONSTANT_0),&(v141_4));
            drop(v141_4);
            let v141_8: Space = if (v141_5).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v140_6),&(v140_7_head));
              let v142_7: Space = routine_20(c, &(v142_6), &(v140_7_tail).make_space());
              compose(&(v141_5),&(v142_7))
            };
            drop(v141_5);
            let v141_9: Space = intersect(&(*CONSTANT_1),&(v141_2));
            drop(v141_2);
            let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
            drop(v141_9);
            let v141_12: Space = if (v141_10).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v140_6),&(v140_7_head));
              let v143_11: Space = routine_21(c, &(v143_6), &(v140_7_tail).make_space());
              drop(v143_6);
              compose(&(v141_10),&(v143_11))
            };
            drop(v141_10);
            let v141_13: Space = unite(&(v141_8),&(v141_12));
            v140_7.join_into((v141_13).clone());
            }
            v140_7_cursor.ascend(1);
          }
          drop(v140_7_cursor);
          drop(v140_6);
          compose(&(v139_5),&(v140_7))
        };
        drop(v139_5);
        let v139_9: Space = intersect(&(*CONSTANT_1),&(v139_2));
        drop(v139_2);
        let v139_10: Space = if has_head(&(v139_9)) { singleton(&[]) } else { Space::new() };
        drop(v139_9);
        let v139_11: Space = compose(&(v139_10),&(v138_11_tail));
        drop(v139_10);
        let v139_12: Space = unite(&(v139_8),&(v139_11));
        drop(v139_11);
        v138_11.join_into((v139_12).clone());
        }
        v138_11_cursor.ascend(1);
      }
      drop(v138_11_cursor);
      drop(v138_6);
      compose(&(v127_10),&(v138_11))
    };
    drop(v127_10);
    let v127_13: Space = unite(&(v127_8),&(v127_12));
    v126_20.join_into((v127_13).clone());
    }
    v126_20_cursor.ascend(1);
  }
  drop(v126_20_cursor);
  (v126_20).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v144_14 = Space::new();
  let mut v144_14_cursor = (*s0).read_zipper();
  for v144_14_byte in v144_14_cursor.child_mask().iter() {
    v144_14_cursor.descend_to_byte(v144_14_byte);
    {
    let v144_14_tail = v144_14_cursor.fork_read_zipper();
    let v144_14_head = Path::from_slice(&[v144_14_byte]);
    let v145_2: Space = singleton(&(v144_14_head));
    let v145_3: Space = intersect(&(*CONSTANT_1),&(v145_2));
    let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
    drop(v145_3);
    let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
    drop(v145_4);
    let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
      let v146_6: Path = concat_path(&(*p0),&(v144_14_head));
      let mut v146_7 = Space::new();
      let mut v146_7_cursor = (v144_14_tail).read_zipper();
      for v146_7_byte in v146_7_cursor.child_mask().iter() {
        v146_7_cursor.descend_to_byte(v146_7_byte);
        {
        let v146_7_tail = v146_7_cursor.fork_read_zipper();
        let v146_7_head = Path::from_slice(&[v146_7_byte]);
        let v147_2: Space = singleton(&(v146_7_head));
        let v147_3: Space = intersect(&(*CONSTANT_1),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
        drop(v147_4);
        let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
          let v148_6: Path = concat_path(&(v146_6),&(v146_7_head));
          let mut v148_7 = Space::new();
          let mut v148_7_cursor = (v146_7_tail).read_zipper();
          for v148_7_byte in v148_7_cursor.child_mask().iter() {
            v148_7_cursor.descend_to_byte(v148_7_byte);
            {
            let v148_7_tail = v148_7_cursor.fork_read_zipper();
            let v148_7_head = Path::from_slice(&[v148_7_byte]);
            let v149_2: Space = singleton(&(v148_7_head));
            let v149_3: Space = intersect(&(*CONSTANT_1),&(v149_2));
            let v149_4: Space = if has_head(&(v149_3)) { singleton(&[]) } else { Space::new() };
            drop(v149_3);
            let v149_5: Space = subtract(&(*CONSTANT_0),&(v149_4));
            drop(v149_4);
            let v149_8: Space = if (v149_5).is_empty() { Space::new() } else {
              let v150_6: Path = concat_path(&(v148_6),&(v148_7_head));
              let v150_7: Space = routine_20(c, &(v150_6), &(v148_7_tail).make_space());
              compose(&(v149_5),&(v150_7))
            };
            drop(v149_5);
            let v149_9: Space = intersect(&(*CONSTANT_1),&(v149_2));
            drop(v149_2);
            let v149_10: Space = if has_head(&(v149_9)) { singleton(&[]) } else { Space::new() };
            drop(v149_9);
            let v149_12: Space = if (v149_10).is_empty() { Space::new() } else {
              let v151_6: Path = concat_path(&(v148_6),&(v148_7_head));
              let v151_11: Space = routine_21(c, &(v151_6), &(v148_7_tail).make_space());
              drop(v151_6);
              compose(&(v149_10),&(v151_11))
            };
            drop(v149_10);
            let v149_13: Space = unite(&(v149_8),&(v149_12));
            v148_7.join_into((v149_13).clone());
            }
            v148_7_cursor.ascend(1);
          }
          drop(v148_7_cursor);
          compose(&(v147_5),&(v148_7))
        };
        drop(v147_5);
        let v147_9: Space = intersect(&(*CONSTANT_1),&(v147_2));
        drop(v147_2);
        let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
        drop(v147_9);
        let v147_12: Space = if (v147_10).is_empty() { Space::new() } else {
          let v152_6: Path = concat_path(&(v146_6),&(v146_7_head));
          let mut v152_11 = Space::new();
          let mut v152_11_cursor = (v146_7_tail).read_zipper();
          for v152_11_byte in v152_11_cursor.child_mask().iter() {
            v152_11_cursor.descend_to_byte(v152_11_byte);
            {
            let v152_11_tail = v152_11_cursor.fork_read_zipper();
            let v152_11_head = Path::from_slice(&[v152_11_byte]);
            let v153_2: Space = singleton(&(v152_11_head));
            let v153_3: Space = intersect(&(*CONSTANT_1),&(v153_2));
            let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
            drop(v153_3);
            let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
            drop(v153_4);
            let v153_8: Space = if (v153_5).is_empty() { Space::new() } else {
              let v154_6: Path = concat_path(&(v152_6),&(v152_11_head));
              let v154_7: Space = routine_20(c, &(v154_6), &(v152_11_tail).make_space());
              compose(&(v153_5),&(v154_7))
            };
            drop(v153_5);
            let v153_9: Space = intersect(&(*CONSTANT_1),&(v153_2));
            drop(v153_2);
            let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
            drop(v153_9);
            let v153_12: Space = if (v153_10).is_empty() { Space::new() } else {
              let v155_6: Path = concat_path(&(v152_6),&(v152_11_head));
              let v155_11: Space = routine_12(c, &(v155_6), &(v152_11_tail).make_space());
              drop(v155_6);
              compose(&(v153_10),&(v155_11))
            };
            drop(v153_10);
            let v153_13: Space = unite(&(v153_8),&(v153_12));
            v152_11.join_into((v153_13).clone());
            }
            v152_11_cursor.ascend(1);
          }
          drop(v152_11_cursor);
          drop(v152_6);
          compose(&(v147_10),&(v152_11))
        };
        drop(v147_10);
        let v147_13: Space = unite(&(v147_8),&(v147_12));
        v146_7.join_into((v147_13).clone());
        }
        v146_7_cursor.ascend(1);
      }
      drop(v146_7_cursor);
      drop(v146_6);
      compose(&(v145_5),&(v146_7))
    };
    drop(v145_5);
    let v145_9: Space = intersect(&(*CONSTANT_1),&(v145_2));
    drop(v145_2);
    let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
    drop(v145_9);
    let v145_11: Space = compose(&(v145_10),&(v144_14_tail));
    drop(v145_10);
    let v145_12: Space = unite(&(v145_8),&(v145_11));
    drop(v145_11);
    v144_14.join_into((v145_12).clone());
    }
    v144_14_cursor.ascend(1);
  }
  drop(v144_14_cursor);
  (v144_14).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v156_20 = Space::new();
  let mut v156_20_cursor = (*s0).read_zipper();
  for v156_20_byte in v156_20_cursor.child_mask().iter() {
    v156_20_cursor.descend_to_byte(v156_20_byte);
    {
    let v156_20_tail = v156_20_cursor.fork_read_zipper();
    let v156_20_head = Path::from_slice(&[v156_20_byte]);
    let v157_2: Space = singleton(&(v156_20_head));
    let v157_3: Space = intersect(&(*CONSTANT_1),&(v157_2));
    let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
    drop(v157_3);
    let v157_5: Space = subtract(&(*CONSTANT_0),&(v157_4));
    drop(v157_4);
    let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
      let v158_6: Path = concat_path(&(*p0),&(v156_20_head));
      let mut v158_7 = Space::new();
      let mut v158_7_cursor = (v156_20_tail).read_zipper();
      for v158_7_byte in v158_7_cursor.child_mask().iter() {
        v158_7_cursor.descend_to_byte(v158_7_byte);
        {
        let v158_7_tail = v158_7_cursor.fork_read_zipper();
        let v158_7_head = Path::from_slice(&[v158_7_byte]);
        let v159_2: Space = singleton(&(v158_7_head));
        let v159_3: Space = intersect(&(*CONSTANT_1),&(v159_2));
        let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
        drop(v159_3);
        let v159_5: Space = subtract(&(*CONSTANT_0),&(v159_4));
        drop(v159_4);
        let v159_8: Space = if (v159_5).is_empty() { Space::new() } else {
          let v160_6: Path = concat_path(&(v158_6),&(v158_7_head));
          let mut v160_7 = Space::new();
          let mut v160_7_cursor = (v158_7_tail).read_zipper();
          for v160_7_byte in v160_7_cursor.child_mask().iter() {
            v160_7_cursor.descend_to_byte(v160_7_byte);
            {
            let v160_7_tail = v160_7_cursor.fork_read_zipper();
            let v160_7_head = Path::from_slice(&[v160_7_byte]);
            let v161_2: Space = singleton(&(v160_7_head));
            let v161_3: Space = intersect(&(*CONSTANT_1),&(v161_2));
            let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
            drop(v161_3);
            let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
            drop(v161_4);
            let v161_8: Space = if (v161_5).is_empty() { Space::new() } else {
              let v162_6: Path = concat_path(&(v160_6),&(v160_7_head));
              let v162_7: Space = routine_22(c, &(v162_6), &(v160_7_tail).make_space());
              compose(&(v161_5),&(v162_7))
            };
            drop(v161_5);
            let v161_9: Space = intersect(&(*CONSTANT_1),&(v161_2));
            drop(v161_2);
            let v161_10: Space = if has_head(&(v161_9)) { singleton(&[]) } else { Space::new() };
            drop(v161_9);
            let v161_12: Space = if (v161_10).is_empty() { Space::new() } else {
              let v163_6: Path = concat_path(&(v160_6),&(v160_7_head));
              let v163_11: Space = routine_23(c, &(v163_6), &(v160_7_tail).make_space());
              drop(v163_6);
              compose(&(v161_10),&(v163_11))
            };
            drop(v161_10);
            let v161_13: Space = unite(&(v161_8),&(v161_12));
            v160_7.join_into((v161_13).clone());
            }
            v160_7_cursor.ascend(1);
          }
          drop(v160_7_cursor);
          compose(&(v159_5),&(v160_7))
        };
        drop(v159_5);
        let v159_9: Space = intersect(&(*CONSTANT_1),&(v159_2));
        drop(v159_2);
        let v159_10: Space = if has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
        drop(v159_9);
        let v159_12: Space = if (v159_10).is_empty() { Space::new() } else {
          let v164_6: Path = concat_path(&(v158_6),&(v158_7_head));
          let mut v164_11 = Space::new();
          let mut v164_11_cursor = (v158_7_tail).read_zipper();
          for v164_11_byte in v164_11_cursor.child_mask().iter() {
            v164_11_cursor.descend_to_byte(v164_11_byte);
            {
            let v164_11_tail = v164_11_cursor.fork_read_zipper();
            let v164_11_head = Path::from_slice(&[v164_11_byte]);
            let v165_2: Space = singleton(&(v164_11_head));
            let v165_3: Space = intersect(&(*CONSTANT_1),&(v165_2));
            let v165_4: Space = if has_head(&(v165_3)) { singleton(&[]) } else { Space::new() };
            drop(v165_3);
            let v165_5: Space = subtract(&(*CONSTANT_0),&(v165_4));
            drop(v165_4);
            let v165_8: Space = if (v165_5).is_empty() { Space::new() } else {
              let v166_6: Path = concat_path(&(v164_6),&(v164_11_head));
              let v166_7: Space = routine_22(c, &(v166_6), &(v164_11_tail).make_space());
              compose(&(v165_5),&(v166_7))
            };
            drop(v165_5);
            let v165_9: Space = intersect(&(*CONSTANT_1),&(v165_2));
            drop(v165_2);
            let v165_10: Space = if has_head(&(v165_9)) { singleton(&[]) } else { Space::new() };
            drop(v165_9);
            let v165_12: Space = if (v165_10).is_empty() { Space::new() } else {
              let v167_6: Path = concat_path(&(v164_6),&(v164_11_head));
              let v167_11: Space = routine_15(c, &(v167_6), &(v164_11_tail).make_space());
              drop(v167_6);
              compose(&(v165_10),&(v167_11))
            };
            drop(v165_10);
            let v165_13: Space = unite(&(v165_8),&(v165_12));
            v164_11.join_into((v165_13).clone());
            }
            v164_11_cursor.ascend(1);
          }
          drop(v164_11_cursor);
          drop(v164_6);
          compose(&(v159_10),&(v164_11))
        };
        drop(v159_10);
        let v159_13: Space = unite(&(v159_8),&(v159_12));
        v158_7.join_into((v159_13).clone());
        }
        v158_7_cursor.ascend(1);
      }
      drop(v158_7_cursor);
      compose(&(v157_5),&(v158_7))
    };
    drop(v157_5);
    let v157_9: Space = intersect(&(*CONSTANT_1),&(v157_2));
    drop(v157_2);
    let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
    drop(v157_9);
    let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
      let v168_6: Path = concat_path(&(*p0),&(v156_20_head));
      let mut v168_11 = Space::new();
      let mut v168_11_cursor = (v156_20_tail).read_zipper();
      for v168_11_byte in v168_11_cursor.child_mask().iter() {
        v168_11_cursor.descend_to_byte(v168_11_byte);
        {
        let v168_11_tail = v168_11_cursor.fork_read_zipper();
        let v168_11_head = Path::from_slice(&[v168_11_byte]);
        let v169_2: Space = singleton(&(v168_11_head));
        let v169_3: Space = intersect(&(*CONSTANT_1),&(v169_2));
        let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
        drop(v169_3);
        let v169_5: Space = subtract(&(*CONSTANT_0),&(v169_4));
        drop(v169_4);
        let v169_8: Space = if (v169_5).is_empty() { Space::new() } else {
          let v170_6: Path = concat_path(&(v168_6),&(v168_11_head));
          let mut v170_7 = Space::new();
          let mut v170_7_cursor = (v168_11_tail).read_zipper();
          for v170_7_byte in v170_7_cursor.child_mask().iter() {
            v170_7_cursor.descend_to_byte(v170_7_byte);
            {
            let v170_7_tail = v170_7_cursor.fork_read_zipper();
            let v170_7_head = Path::from_slice(&[v170_7_byte]);
            let v171_2: Space = singleton(&(v170_7_head));
            let v171_3: Space = intersect(&(*CONSTANT_1),&(v171_2));
            let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
            drop(v171_3);
            let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
            drop(v171_4);
            let v171_8: Space = if (v171_5).is_empty() { Space::new() } else {
              let v172_6: Path = concat_path(&(v170_6),&(v170_7_head));
              let v172_7: Space = routine_22(c, &(v172_6), &(v170_7_tail).make_space());
              compose(&(v171_5),&(v172_7))
            };
            drop(v171_5);
            let v171_9: Space = intersect(&(*CONSTANT_1),&(v171_2));
            drop(v171_2);
            let v171_10: Space = if has_head(&(v171_9)) { singleton(&[]) } else { Space::new() };
            drop(v171_9);
            let v171_12: Space = if (v171_10).is_empty() { Space::new() } else {
              let v173_6: Path = concat_path(&(v170_6),&(v170_7_head));
              let v173_11: Space = routine_23(c, &(v173_6), &(v170_7_tail).make_space());
              drop(v173_6);
              compose(&(v171_10),&(v173_11))
            };
            drop(v171_10);
            let v171_13: Space = unite(&(v171_8),&(v171_12));
            v170_7.join_into((v171_13).clone());
            }
            v170_7_cursor.ascend(1);
          }
          drop(v170_7_cursor);
          drop(v170_6);
          compose(&(v169_5),&(v170_7))
        };
        drop(v169_5);
        let v169_9: Space = intersect(&(*CONSTANT_1),&(v169_2));
        drop(v169_2);
        let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
        drop(v169_9);
        let v169_11: Space = compose(&(v169_10),&(v168_11_tail));
        drop(v169_10);
        let v169_12: Space = unite(&(v169_8),&(v169_11));
        drop(v169_11);
        v168_11.join_into((v169_12).clone());
        }
        v168_11_cursor.ascend(1);
      }
      drop(v168_11_cursor);
      drop(v168_6);
      compose(&(v157_10),&(v168_11))
    };
    drop(v157_10);
    let v157_13: Space = unite(&(v157_8),&(v157_12));
    v156_20.join_into((v157_13).clone());
    }
    v156_20_cursor.ascend(1);
  }
  drop(v156_20_cursor);
  (v156_20).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v174_14 = Space::new();
  let mut v174_14_cursor = (*s0).read_zipper();
  for v174_14_byte in v174_14_cursor.child_mask().iter() {
    v174_14_cursor.descend_to_byte(v174_14_byte);
    {
    let v174_14_tail = v174_14_cursor.fork_read_zipper();
    let v174_14_head = Path::from_slice(&[v174_14_byte]);
    let v175_2: Space = singleton(&(v174_14_head));
    let v175_3: Space = intersect(&(*CONSTANT_1),&(v175_2));
    let v175_4: Space = if has_head(&(v175_3)) { singleton(&[]) } else { Space::new() };
    drop(v175_3);
    let v175_5: Space = subtract(&(*CONSTANT_0),&(v175_4));
    drop(v175_4);
    let v175_8: Space = if (v175_5).is_empty() { Space::new() } else {
      let v176_6: Path = concat_path(&(*p0),&(v174_14_head));
      let mut v176_7 = Space::new();
      let mut v176_7_cursor = (v174_14_tail).read_zipper();
      for v176_7_byte in v176_7_cursor.child_mask().iter() {
        v176_7_cursor.descend_to_byte(v176_7_byte);
        {
        let v176_7_tail = v176_7_cursor.fork_read_zipper();
        let v176_7_head = Path::from_slice(&[v176_7_byte]);
        let v177_2: Space = singleton(&(v176_7_head));
        let v177_3: Space = intersect(&(*CONSTANT_1),&(v177_2));
        let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
        drop(v177_3);
        let v177_5: Space = subtract(&(*CONSTANT_0),&(v177_4));
        drop(v177_4);
        let v177_8: Space = if (v177_5).is_empty() { Space::new() } else {
          let v178_6: Path = concat_path(&(v176_6),&(v176_7_head));
          let mut v178_7 = Space::new();
          let mut v178_7_cursor = (v176_7_tail).read_zipper();
          for v178_7_byte in v178_7_cursor.child_mask().iter() {
            v178_7_cursor.descend_to_byte(v178_7_byte);
            {
            let v178_7_tail = v178_7_cursor.fork_read_zipper();
            let v178_7_head = Path::from_slice(&[v178_7_byte]);
            let v179_2: Space = singleton(&(v178_7_head));
            let v179_3: Space = intersect(&(*CONSTANT_1),&(v179_2));
            let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
            drop(v179_3);
            let v179_5: Space = subtract(&(*CONSTANT_0),&(v179_4));
            drop(v179_4);
            let v179_8: Space = if (v179_5).is_empty() { Space::new() } else {
              let v180_6: Path = concat_path(&(v178_6),&(v178_7_head));
              let v180_7: Space = routine_22(c, &(v180_6), &(v178_7_tail).make_space());
              compose(&(v179_5),&(v180_7))
            };
            drop(v179_5);
            let v179_9: Space = intersect(&(*CONSTANT_1),&(v179_2));
            drop(v179_2);
            let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
            drop(v179_9);
            let v179_12: Space = if (v179_10).is_empty() { Space::new() } else {
              let v181_6: Path = concat_path(&(v178_6),&(v178_7_head));
              let v181_11: Space = routine_23(c, &(v181_6), &(v178_7_tail).make_space());
              drop(v181_6);
              compose(&(v179_10),&(v181_11))
            };
            drop(v179_10);
            let v179_13: Space = unite(&(v179_8),&(v179_12));
            v178_7.join_into((v179_13).clone());
            }
            v178_7_cursor.ascend(1);
          }
          drop(v178_7_cursor);
          compose(&(v177_5),&(v178_7))
        };
        drop(v177_5);
        let v177_9: Space = intersect(&(*CONSTANT_1),&(v177_2));
        drop(v177_2);
        let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
        drop(v177_9);
        let v177_12: Space = if (v177_10).is_empty() { Space::new() } else {
          let v182_6: Path = concat_path(&(v176_6),&(v176_7_head));
          let mut v182_11 = Space::new();
          let mut v182_11_cursor = (v176_7_tail).read_zipper();
          for v182_11_byte in v182_11_cursor.child_mask().iter() {
            v182_11_cursor.descend_to_byte(v182_11_byte);
            {
            let v182_11_tail = v182_11_cursor.fork_read_zipper();
            let v182_11_head = Path::from_slice(&[v182_11_byte]);
            let v183_2: Space = singleton(&(v182_11_head));
            let v183_3: Space = intersect(&(*CONSTANT_1),&(v183_2));
            let v183_4: Space = if has_head(&(v183_3)) { singleton(&[]) } else { Space::new() };
            drop(v183_3);
            let v183_5: Space = subtract(&(*CONSTANT_0),&(v183_4));
            drop(v183_4);
            let v183_8: Space = if (v183_5).is_empty() { Space::new() } else {
              let v184_6: Path = concat_path(&(v182_6),&(v182_11_head));
              let v184_7: Space = routine_22(c, &(v184_6), &(v182_11_tail).make_space());
              compose(&(v183_5),&(v184_7))
            };
            drop(v183_5);
            let v183_9: Space = intersect(&(*CONSTANT_1),&(v183_2));
            drop(v183_2);
            let v183_10: Space = if has_head(&(v183_9)) { singleton(&[]) } else { Space::new() };
            drop(v183_9);
            let v183_12: Space = if (v183_10).is_empty() { Space::new() } else {
              let v185_6: Path = concat_path(&(v182_6),&(v182_11_head));
              let v185_11: Space = routine_15(c, &(v185_6), &(v182_11_tail).make_space());
              drop(v185_6);
              compose(&(v183_10),&(v185_11))
            };
            drop(v183_10);
            let v183_13: Space = unite(&(v183_8),&(v183_12));
            v182_11.join_into((v183_13).clone());
            }
            v182_11_cursor.ascend(1);
          }
          drop(v182_11_cursor);
          drop(v182_6);
          compose(&(v177_10),&(v182_11))
        };
        drop(v177_10);
        let v177_13: Space = unite(&(v177_8),&(v177_12));
        v176_7.join_into((v177_13).clone());
        }
        v176_7_cursor.ascend(1);
      }
      drop(v176_7_cursor);
      drop(v176_6);
      compose(&(v175_5),&(v176_7))
    };
    drop(v175_5);
    let v175_9: Space = intersect(&(*CONSTANT_1),&(v175_2));
    drop(v175_2);
    let v175_10: Space = if has_head(&(v175_9)) { singleton(&[]) } else { Space::new() };
    drop(v175_9);
    let v175_11: Space = compose(&(v175_10),&(v174_14_tail));
    drop(v175_10);
    let v175_12: Space = unite(&(v175_8),&(v175_11));
    drop(v175_11);
    v174_14.join_into((v175_12).clone());
    }
    v174_14_cursor.ascend(1);
  }
  drop(v174_14_cursor);
  (v174_14).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v186_20 = Space::new();
  let mut v186_20_cursor = (*s0).read_zipper();
  for v186_20_byte in v186_20_cursor.child_mask().iter() {
    v186_20_cursor.descend_to_byte(v186_20_byte);
    {
    let v186_20_tail = v186_20_cursor.fork_read_zipper();
    let v186_20_head = Path::from_slice(&[v186_20_byte]);
    let v187_2: Space = singleton(&(v186_20_head));
    let v187_3: Space = intersect(&(*CONSTANT_1),&(v187_2));
    let v187_4: Space = if has_head(&(v187_3)) { singleton(&[]) } else { Space::new() };
    drop(v187_3);
    let v187_5: Space = subtract(&(*CONSTANT_0),&(v187_4));
    drop(v187_4);
    let v187_8: Space = if (v187_5).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&(v186_20_head));
      let mut v188_7 = Space::new();
      let mut v188_7_cursor = (v186_20_tail).read_zipper();
      for v188_7_byte in v188_7_cursor.child_mask().iter() {
        v188_7_cursor.descend_to_byte(v188_7_byte);
        {
        let v188_7_tail = v188_7_cursor.fork_read_zipper();
        let v188_7_head = Path::from_slice(&[v188_7_byte]);
        let v189_2: Space = singleton(&(v188_7_head));
        let v189_3: Space = intersect(&(*CONSTANT_1),&(v189_2));
        let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = subtract(&(*CONSTANT_0),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (v189_5).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&(v188_7_head));
          let mut v190_7 = Space::new();
          let mut v190_7_cursor = (v188_7_tail).read_zipper();
          for v190_7_byte in v190_7_cursor.child_mask().iter() {
            v190_7_cursor.descend_to_byte(v190_7_byte);
            {
            let v190_7_tail = v190_7_cursor.fork_read_zipper();
            let v190_7_head = Path::from_slice(&[v190_7_byte]);
            let v191_2: Space = singleton(&(v190_7_head));
            let v191_3: Space = intersect(&(*CONSTANT_1),&(v191_2));
            let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = subtract(&(*CONSTANT_0),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (v191_5).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&(v190_7_head));
              let v192_7: Space = routine_24(c, &(v192_6), &(v190_7_tail).make_space());
              compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = intersect(&(*CONSTANT_1),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (v191_10).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&(v190_7_head));
              let v193_11: Space = routine_25(c, &(v193_6), &(v190_7_tail).make_space());
              drop(v193_6);
              compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = unite(&(v191_8),&(v191_12));
            v190_7.join_into((v191_13).clone());
            }
            v190_7_cursor.ascend(1);
          }
          drop(v190_7_cursor);
          compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = intersect(&(*CONSTANT_1),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_12: Space = if (v189_10).is_empty() { Space::new() } else {
          let v194_6: Path = concat_path(&(v188_6),&(v188_7_head));
          let mut v194_11 = Space::new();
          let mut v194_11_cursor = (v188_7_tail).read_zipper();
          for v194_11_byte in v194_11_cursor.child_mask().iter() {
            v194_11_cursor.descend_to_byte(v194_11_byte);
            {
            let v194_11_tail = v194_11_cursor.fork_read_zipper();
            let v194_11_head = Path::from_slice(&[v194_11_byte]);
            let v195_2: Space = singleton(&(v194_11_head));
            let v195_3: Space = intersect(&(*CONSTANT_1),&(v195_2));
            let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
            drop(v195_3);
            let v195_5: Space = subtract(&(*CONSTANT_0),&(v195_4));
            drop(v195_4);
            let v195_8: Space = if (v195_5).is_empty() { Space::new() } else {
              let v196_6: Path = concat_path(&(v194_6),&(v194_11_head));
              let v196_7: Space = routine_24(c, &(v196_6), &(v194_11_tail).make_space());
              compose(&(v195_5),&(v196_7))
            };
            drop(v195_5);
            let v195_9: Space = intersect(&(*CONSTANT_1),&(v195_2));
            drop(v195_2);
            let v195_10: Space = if has_head(&(v195_9)) { singleton(&[]) } else { Space::new() };
            drop(v195_9);
            let v195_12: Space = if (v195_10).is_empty() { Space::new() } else {
              let v197_6: Path = concat_path(&(v194_6),&(v194_11_head));
              let v197_11: Space = routine_12(c, &(v197_6), &(v194_11_tail).make_space());
              drop(v197_6);
              compose(&(v195_10),&(v197_11))
            };
            drop(v195_10);
            let v195_13: Space = unite(&(v195_8),&(v195_12));
            v194_11.join_into((v195_13).clone());
            }
            v194_11_cursor.ascend(1);
          }
          drop(v194_11_cursor);
          drop(v194_6);
          compose(&(v189_10),&(v194_11))
        };
        drop(v189_10);
        let v189_13: Space = unite(&(v189_8),&(v189_12));
        v188_7.join_into((v189_13).clone());
        }
        v188_7_cursor.ascend(1);
      }
      drop(v188_7_cursor);
      compose(&(v187_5),&(v188_7))
    };
    drop(v187_5);
    let v187_9: Space = intersect(&(*CONSTANT_1),&(v187_2));
    drop(v187_2);
    let v187_10: Space = if has_head(&(v187_9)) { singleton(&[]) } else { Space::new() };
    drop(v187_9);
    let v187_12: Space = if (v187_10).is_empty() { Space::new() } else {
      let v198_6: Path = concat_path(&(*p0),&(v186_20_head));
      let mut v198_11 = Space::new();
      let mut v198_11_cursor = (v186_20_tail).read_zipper();
      for v198_11_byte in v198_11_cursor.child_mask().iter() {
        v198_11_cursor.descend_to_byte(v198_11_byte);
        {
        let v198_11_tail = v198_11_cursor.fork_read_zipper();
        let v198_11_head = Path::from_slice(&[v198_11_byte]);
        let v199_2: Space = singleton(&(v198_11_head));
        let v199_3: Space = intersect(&(*CONSTANT_1),&(v199_2));
        let v199_4: Space = if has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
        drop(v199_3);
        let v199_5: Space = subtract(&(*CONSTANT_0),&(v199_4));
        drop(v199_4);
        let v199_8: Space = if (v199_5).is_empty() { Space::new() } else {
          let v200_6: Path = concat_path(&(v198_6),&(v198_11_head));
          let mut v200_7 = Space::new();
          let mut v200_7_cursor = (v198_11_tail).read_zipper();
          for v200_7_byte in v200_7_cursor.child_mask().iter() {
            v200_7_cursor.descend_to_byte(v200_7_byte);
            {
            let v200_7_tail = v200_7_cursor.fork_read_zipper();
            let v200_7_head = Path::from_slice(&[v200_7_byte]);
            let v201_2: Space = singleton(&(v200_7_head));
            let v201_3: Space = intersect(&(*CONSTANT_1),&(v201_2));
            let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
            drop(v201_3);
            let v201_5: Space = subtract(&(*CONSTANT_0),&(v201_4));
            drop(v201_4);
            let v201_8: Space = if (v201_5).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v200_6),&(v200_7_head));
              let v202_7: Space = routine_24(c, &(v202_6), &(v200_7_tail).make_space());
              compose(&(v201_5),&(v202_7))
            };
            drop(v201_5);
            let v201_9: Space = intersect(&(*CONSTANT_1),&(v201_2));
            drop(v201_2);
            let v201_10: Space = if has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
            drop(v201_9);
            let v201_12: Space = if (v201_10).is_empty() { Space::new() } else {
              let v203_6: Path = concat_path(&(v200_6),&(v200_7_head));
              let v203_11: Space = routine_25(c, &(v203_6), &(v200_7_tail).make_space());
              drop(v203_6);
              compose(&(v201_10),&(v203_11))
            };
            drop(v201_10);
            let v201_13: Space = unite(&(v201_8),&(v201_12));
            v200_7.join_into((v201_13).clone());
            }
            v200_7_cursor.ascend(1);
          }
          drop(v200_7_cursor);
          drop(v200_6);
          compose(&(v199_5),&(v200_7))
        };
        drop(v199_5);
        let v199_9: Space = intersect(&(*CONSTANT_1),&(v199_2));
        drop(v199_2);
        let v199_10: Space = if has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
        drop(v199_9);
        let v199_11: Space = compose(&(v199_10),&(v198_11_tail));
        drop(v199_10);
        let v199_12: Space = unite(&(v199_8),&(v199_11));
        drop(v199_11);
        v198_11.join_into((v199_12).clone());
        }
        v198_11_cursor.ascend(1);
      }
      drop(v198_11_cursor);
      drop(v198_6);
      compose(&(v187_10),&(v198_11))
    };
    drop(v187_10);
    let v187_13: Space = unite(&(v187_8),&(v187_12));
    v186_20.join_into((v187_13).clone());
    }
    v186_20_cursor.ascend(1);
  }
  drop(v186_20_cursor);
  (v186_20).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v204_14 = Space::new();
  let mut v204_14_cursor = (*s0).read_zipper();
  for v204_14_byte in v204_14_cursor.child_mask().iter() {
    v204_14_cursor.descend_to_byte(v204_14_byte);
    {
    let v204_14_tail = v204_14_cursor.fork_read_zipper();
    let v204_14_head = Path::from_slice(&[v204_14_byte]);
    let v205_2: Space = singleton(&(v204_14_head));
    let v205_3: Space = intersect(&(*CONSTANT_1),&(v205_2));
    let v205_4: Space = if has_head(&(v205_3)) { singleton(&[]) } else { Space::new() };
    drop(v205_3);
    let v205_5: Space = subtract(&(*CONSTANT_0),&(v205_4));
    drop(v205_4);
    let v205_8: Space = if (v205_5).is_empty() { Space::new() } else {
      let v206_6: Path = concat_path(&(*p0),&(v204_14_head));
      let mut v206_7 = Space::new();
      let mut v206_7_cursor = (v204_14_tail).read_zipper();
      for v206_7_byte in v206_7_cursor.child_mask().iter() {
        v206_7_cursor.descend_to_byte(v206_7_byte);
        {
        let v206_7_tail = v206_7_cursor.fork_read_zipper();
        let v206_7_head = Path::from_slice(&[v206_7_byte]);
        let v207_2: Space = singleton(&(v206_7_head));
        let v207_3: Space = intersect(&(*CONSTANT_1),&(v207_2));
        let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
        drop(v207_3);
        let v207_5: Space = subtract(&(*CONSTANT_0),&(v207_4));
        drop(v207_4);
        let v207_8: Space = if (v207_5).is_empty() { Space::new() } else {
          let v208_6: Path = concat_path(&(v206_6),&(v206_7_head));
          let mut v208_7 = Space::new();
          let mut v208_7_cursor = (v206_7_tail).read_zipper();
          for v208_7_byte in v208_7_cursor.child_mask().iter() {
            v208_7_cursor.descend_to_byte(v208_7_byte);
            {
            let v208_7_tail = v208_7_cursor.fork_read_zipper();
            let v208_7_head = Path::from_slice(&[v208_7_byte]);
            let v209_2: Space = singleton(&(v208_7_head));
            let v209_3: Space = intersect(&(*CONSTANT_1),&(v209_2));
            let v209_4: Space = if has_head(&(v209_3)) { singleton(&[]) } else { Space::new() };
            drop(v209_3);
            let v209_5: Space = subtract(&(*CONSTANT_0),&(v209_4));
            drop(v209_4);
            let v209_8: Space = if (v209_5).is_empty() { Space::new() } else {
              let v210_6: Path = concat_path(&(v208_6),&(v208_7_head));
              let v210_7: Space = routine_24(c, &(v210_6), &(v208_7_tail).make_space());
              compose(&(v209_5),&(v210_7))
            };
            drop(v209_5);
            let v209_9: Space = intersect(&(*CONSTANT_1),&(v209_2));
            drop(v209_2);
            let v209_10: Space = if has_head(&(v209_9)) { singleton(&[]) } else { Space::new() };
            drop(v209_9);
            let v209_12: Space = if (v209_10).is_empty() { Space::new() } else {
              let v211_6: Path = concat_path(&(v208_6),&(v208_7_head));
              let v211_11: Space = routine_25(c, &(v211_6), &(v208_7_tail).make_space());
              drop(v211_6);
              compose(&(v209_10),&(v211_11))
            };
            drop(v209_10);
            let v209_13: Space = unite(&(v209_8),&(v209_12));
            v208_7.join_into((v209_13).clone());
            }
            v208_7_cursor.ascend(1);
          }
          drop(v208_7_cursor);
          compose(&(v207_5),&(v208_7))
        };
        drop(v207_5);
        let v207_9: Space = intersect(&(*CONSTANT_1),&(v207_2));
        drop(v207_2);
        let v207_10: Space = if has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
        drop(v207_9);
        let v207_12: Space = if (v207_10).is_empty() { Space::new() } else {
          let v212_6: Path = concat_path(&(v206_6),&(v206_7_head));
          let mut v212_11 = Space::new();
          let mut v212_11_cursor = (v206_7_tail).read_zipper();
          for v212_11_byte in v212_11_cursor.child_mask().iter() {
            v212_11_cursor.descend_to_byte(v212_11_byte);
            {
            let v212_11_tail = v212_11_cursor.fork_read_zipper();
            let v212_11_head = Path::from_slice(&[v212_11_byte]);
            let v213_2: Space = singleton(&(v212_11_head));
            let v213_3: Space = intersect(&(*CONSTANT_1),&(v213_2));
            let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
            drop(v213_3);
            let v213_5: Space = subtract(&(*CONSTANT_0),&(v213_4));
            drop(v213_4);
            let v213_8: Space = if (v213_5).is_empty() { Space::new() } else {
              let v214_6: Path = concat_path(&(v212_6),&(v212_11_head));
              let v214_7: Space = routine_24(c, &(v214_6), &(v212_11_tail).make_space());
              compose(&(v213_5),&(v214_7))
            };
            drop(v213_5);
            let v213_9: Space = intersect(&(*CONSTANT_1),&(v213_2));
            drop(v213_2);
            let v213_10: Space = if has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
            drop(v213_9);
            let v213_12: Space = if (v213_10).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v212_6),&(v212_11_head));
              let v215_11: Space = routine_12(c, &(v215_6), &(v212_11_tail).make_space());
              drop(v215_6);
              compose(&(v213_10),&(v215_11))
            };
            drop(v213_10);
            let v213_13: Space = unite(&(v213_8),&(v213_12));
            v212_11.join_into((v213_13).clone());
            }
            v212_11_cursor.ascend(1);
          }
          drop(v212_11_cursor);
          drop(v212_6);
          compose(&(v207_10),&(v212_11))
        };
        drop(v207_10);
        let v207_13: Space = unite(&(v207_8),&(v207_12));
        v206_7.join_into((v207_13).clone());
        }
        v206_7_cursor.ascend(1);
      }
      drop(v206_7_cursor);
      drop(v206_6);
      compose(&(v205_5),&(v206_7))
    };
    drop(v205_5);
    let v205_9: Space = intersect(&(*CONSTANT_1),&(v205_2));
    drop(v205_2);
    let v205_10: Space = if has_head(&(v205_9)) { singleton(&[]) } else { Space::new() };
    drop(v205_9);
    let v205_11: Space = compose(&(v205_10),&(v204_14_tail));
    drop(v205_10);
    let v205_12: Space = unite(&(v205_8),&(v205_11));
    drop(v205_11);
    v204_14.join_into((v205_12).clone());
    }
    v204_14_cursor.ascend(1);
  }
  drop(v204_14_cursor);
  (v204_14).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v217_20 = Space::new();
  let mut v217_20_cursor = (*s0).read_zipper();
  for v217_20_byte in v217_20_cursor.child_mask().iter() {
    v217_20_cursor.descend_to_byte(v217_20_byte);
    {
    let v217_20_tail = v217_20_cursor.fork_read_zipper();
    let v217_20_head = Path::from_slice(&[v217_20_byte]);
    let v218_2: Space = singleton(&(v217_20_head));
    let v218_3: Space = intersect(&(*CONSTANT_1),&(v218_2));
    let v218_4: Space = if has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
    drop(v218_3);
    let v218_5: Space = subtract(&(*CONSTANT_0),&(v218_4));
    drop(v218_4);
    let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
      let v219_6: Path = concat_path(&(*p0),&(v217_20_head));
      let mut v219_7 = Space::new();
      let mut v219_7_cursor = (v217_20_tail).read_zipper();
      for v219_7_byte in v219_7_cursor.child_mask().iter() {
        v219_7_cursor.descend_to_byte(v219_7_byte);
        {
        let v219_7_tail = v219_7_cursor.fork_read_zipper();
        let v219_7_head = Path::from_slice(&[v219_7_byte]);
        let v220_2: Space = singleton(&(v219_7_head));
        let v220_3: Space = intersect(&(*CONSTANT_1),&(v220_2));
        let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
        drop(v220_3);
        let v220_5: Space = subtract(&(*CONSTANT_0),&(v220_4));
        drop(v220_4);
        let v220_8: Space = if (v220_5).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let mut v221_7 = Space::new();
          let mut v221_7_cursor = (v219_7_tail).read_zipper();
          for v221_7_byte in v221_7_cursor.child_mask().iter() {
            v221_7_cursor.descend_to_byte(v221_7_byte);
            {
            let v221_7_tail = v221_7_cursor.fork_read_zipper();
            let v221_7_head = Path::from_slice(&[v221_7_byte]);
            let v222_2: Space = singleton(&(v221_7_head));
            let v222_3: Space = intersect(&(*CONSTANT_1),&(v222_2));
            let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
            drop(v222_3);
            let v222_5: Space = subtract(&(*CONSTANT_0),&(v222_4));
            drop(v222_4);
            let v222_8: Space = if (v222_5).is_empty() { Space::new() } else {
              let v223_6: Path = concat_path(&(v221_6),&(v221_7_head));
              let v223_7: Space = routine_26(c, &(v223_6), &(v221_7_tail).make_space());
              compose(&(v222_5),&(v223_7))
            };
            drop(v222_5);
            let v222_9: Space = intersect(&(*CONSTANT_1),&(v222_2));
            drop(v222_2);
            let v222_10: Space = if has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
            drop(v222_9);
            let v222_12: Space = if (v222_10).is_empty() { Space::new() } else {
              let v224_6: Path = concat_path(&(v221_6),&(v221_7_head));
              let v224_11: Space = routine_27(c, &(v224_6), &(v221_7_tail).make_space());
              drop(v224_6);
              compose(&(v222_10),&(v224_11))
            };
            drop(v222_10);
            let v222_13: Space = unite(&(v222_8),&(v222_12));
            v221_7.join_into((v222_13).clone());
            }
            v221_7_cursor.ascend(1);
          }
          drop(v221_7_cursor);
          compose(&(v220_5),&(v221_7))
        };
        drop(v220_5);
        let v220_9: Space = intersect(&(*CONSTANT_1),&(v220_2));
        drop(v220_2);
        let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
        drop(v220_9);
        let v220_12: Space = if (v220_10).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v219_6),&(v219_7_head));
          let mut v225_11 = Space::new();
          let mut v225_11_cursor = (v219_7_tail).read_zipper();
          for v225_11_byte in v225_11_cursor.child_mask().iter() {
            v225_11_cursor.descend_to_byte(v225_11_byte);
            {
            let v225_11_tail = v225_11_cursor.fork_read_zipper();
            let v225_11_head = Path::from_slice(&[v225_11_byte]);
            let v226_2: Space = singleton(&(v225_11_head));
            let v226_3: Space = intersect(&(*CONSTANT_1),&(v226_2));
            let v226_4: Space = if has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
            drop(v226_3);
            let v226_5: Space = subtract(&(*CONSTANT_0),&(v226_4));
            drop(v226_4);
            let v226_8: Space = if (v226_5).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v225_6),&(v225_11_head));
              let v227_7: Space = routine_26(c, &(v227_6), &(v225_11_tail).make_space());
              compose(&(v226_5),&(v227_7))
            };
            drop(v226_5);
            let v226_9: Space = intersect(&(*CONSTANT_1),&(v226_2));
            drop(v226_2);
            let v226_10: Space = if has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
            drop(v226_9);
            let v226_12: Space = if (v226_10).is_empty() { Space::new() } else {
              let v228_6: Path = concat_path(&(v225_6),&(v225_11_head));
              let v228_11: Space = routine_15(c, &(v228_6), &(v225_11_tail).make_space());
              drop(v228_6);
              compose(&(v226_10),&(v228_11))
            };
            drop(v226_10);
            let v226_13: Space = unite(&(v226_8),&(v226_12));
            v225_11.join_into((v226_13).clone());
            }
            v225_11_cursor.ascend(1);
          }
          drop(v225_11_cursor);
          drop(v225_6);
          compose(&(v220_10),&(v225_11))
        };
        drop(v220_10);
        let v220_13: Space = unite(&(v220_8),&(v220_12));
        v219_7.join_into((v220_13).clone());
        }
        v219_7_cursor.ascend(1);
      }
      drop(v219_7_cursor);
      compose(&(v218_5),&(v219_7))
    };
    drop(v218_5);
    let v218_9: Space = intersect(&(*CONSTANT_1),&(v218_2));
    drop(v218_2);
    let v218_10: Space = if has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
    drop(v218_9);
    let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
      let v229_6: Path = concat_path(&(*p0),&(v217_20_head));
      let mut v229_11 = Space::new();
      let mut v229_11_cursor = (v217_20_tail).read_zipper();
      for v229_11_byte in v229_11_cursor.child_mask().iter() {
        v229_11_cursor.descend_to_byte(v229_11_byte);
        {
        let v229_11_tail = v229_11_cursor.fork_read_zipper();
        let v229_11_head = Path::from_slice(&[v229_11_byte]);
        let v230_2: Space = singleton(&(v229_11_head));
        let v230_3: Space = intersect(&(*CONSTANT_1),&(v230_2));
        let v230_4: Space = if has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
        drop(v230_3);
        let v230_5: Space = subtract(&(*CONSTANT_0),&(v230_4));
        drop(v230_4);
        let v230_8: Space = if (v230_5).is_empty() { Space::new() } else {
          let v231_6: Path = concat_path(&(v229_6),&(v229_11_head));
          let mut v231_7 = Space::new();
          let mut v231_7_cursor = (v229_11_tail).read_zipper();
          for v231_7_byte in v231_7_cursor.child_mask().iter() {
            v231_7_cursor.descend_to_byte(v231_7_byte);
            {
            let v231_7_tail = v231_7_cursor.fork_read_zipper();
            let v231_7_head = Path::from_slice(&[v231_7_byte]);
            let v232_2: Space = singleton(&(v231_7_head));
            let v232_3: Space = intersect(&(*CONSTANT_1),&(v232_2));
            let v232_4: Space = if has_head(&(v232_3)) { singleton(&[]) } else { Space::new() };
            drop(v232_3);
            let v232_5: Space = subtract(&(*CONSTANT_0),&(v232_4));
            drop(v232_4);
            let v232_8: Space = if (v232_5).is_empty() { Space::new() } else {
              let v233_6: Path = concat_path(&(v231_6),&(v231_7_head));
              let v233_7: Space = routine_26(c, &(v233_6), &(v231_7_tail).make_space());
              compose(&(v232_5),&(v233_7))
            };
            drop(v232_5);
            let v232_9: Space = intersect(&(*CONSTANT_1),&(v232_2));
            drop(v232_2);
            let v232_10: Space = if has_head(&(v232_9)) { singleton(&[]) } else { Space::new() };
            drop(v232_9);
            let v232_12: Space = if (v232_10).is_empty() { Space::new() } else {
              let v234_6: Path = concat_path(&(v231_6),&(v231_7_head));
              let v234_11: Space = routine_27(c, &(v234_6), &(v231_7_tail).make_space());
              drop(v234_6);
              compose(&(v232_10),&(v234_11))
            };
            drop(v232_10);
            let v232_13: Space = unite(&(v232_8),&(v232_12));
            v231_7.join_into((v232_13).clone());
            }
            v231_7_cursor.ascend(1);
          }
          drop(v231_7_cursor);
          drop(v231_6);
          compose(&(v230_5),&(v231_7))
        };
        drop(v230_5);
        let v230_9: Space = intersect(&(*CONSTANT_1),&(v230_2));
        drop(v230_2);
        let v230_10: Space = if has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
        drop(v230_9);
        let v230_11: Space = compose(&(v230_10),&(v229_11_tail));
        drop(v230_10);
        let v230_12: Space = unite(&(v230_8),&(v230_11));
        drop(v230_11);
        v229_11.join_into((v230_12).clone());
        }
        v229_11_cursor.ascend(1);
      }
      drop(v229_11_cursor);
      drop(v229_6);
      compose(&(v218_10),&(v229_11))
    };
    drop(v218_10);
    let v218_13: Space = unite(&(v218_8),&(v218_12));
    v217_20.join_into((v218_13).clone());
    }
    v217_20_cursor.ascend(1);
  }
  drop(v217_20_cursor);
  (v217_20).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v235_14 = Space::new();
  let mut v235_14_cursor = (*s0).read_zipper();
  for v235_14_byte in v235_14_cursor.child_mask().iter() {
    v235_14_cursor.descend_to_byte(v235_14_byte);
    {
    let v235_14_tail = v235_14_cursor.fork_read_zipper();
    let v235_14_head = Path::from_slice(&[v235_14_byte]);
    let v236_2: Space = singleton(&(v235_14_head));
    let v236_3: Space = intersect(&(*CONSTANT_1),&(v236_2));
    let v236_4: Space = if has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
    drop(v236_3);
    let v236_5: Space = subtract(&(*CONSTANT_0),&(v236_4));
    drop(v236_4);
    let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
      let v237_6: Path = concat_path(&(*p0),&(v235_14_head));
      let mut v237_7 = Space::new();
      let mut v237_7_cursor = (v235_14_tail).read_zipper();
      for v237_7_byte in v237_7_cursor.child_mask().iter() {
        v237_7_cursor.descend_to_byte(v237_7_byte);
        {
        let v237_7_tail = v237_7_cursor.fork_read_zipper();
        let v237_7_head = Path::from_slice(&[v237_7_byte]);
        let v238_2: Space = singleton(&(v237_7_head));
        let v238_3: Space = intersect(&(*CONSTANT_1),&(v238_2));
        let v238_4: Space = if has_head(&(v238_3)) { singleton(&[]) } else { Space::new() };
        drop(v238_3);
        let v238_5: Space = subtract(&(*CONSTANT_0),&(v238_4));
        drop(v238_4);
        let v238_8: Space = if (v238_5).is_empty() { Space::new() } else {
          let v239_6: Path = concat_path(&(v237_6),&(v237_7_head));
          let mut v239_7 = Space::new();
          let mut v239_7_cursor = (v237_7_tail).read_zipper();
          for v239_7_byte in v239_7_cursor.child_mask().iter() {
            v239_7_cursor.descend_to_byte(v239_7_byte);
            {
            let v239_7_tail = v239_7_cursor.fork_read_zipper();
            let v239_7_head = Path::from_slice(&[v239_7_byte]);
            let v240_2: Space = singleton(&(v239_7_head));
            let v240_3: Space = intersect(&(*CONSTANT_1),&(v240_2));
            let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
            drop(v240_3);
            let v240_5: Space = subtract(&(*CONSTANT_0),&(v240_4));
            drop(v240_4);
            let v240_8: Space = if (v240_5).is_empty() { Space::new() } else {
              let v241_6: Path = concat_path(&(v239_6),&(v239_7_head));
              let v241_7: Space = routine_26(c, &(v241_6), &(v239_7_tail).make_space());
              compose(&(v240_5),&(v241_7))
            };
            drop(v240_5);
            let v240_9: Space = intersect(&(*CONSTANT_1),&(v240_2));
            drop(v240_2);
            let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
            drop(v240_9);
            let v240_12: Space = if (v240_10).is_empty() { Space::new() } else {
              let v242_6: Path = concat_path(&(v239_6),&(v239_7_head));
              let v242_11: Space = routine_27(c, &(v242_6), &(v239_7_tail).make_space());
              drop(v242_6);
              compose(&(v240_10),&(v242_11))
            };
            drop(v240_10);
            let v240_13: Space = unite(&(v240_8),&(v240_12));
            v239_7.join_into((v240_13).clone());
            }
            v239_7_cursor.ascend(1);
          }
          drop(v239_7_cursor);
          compose(&(v238_5),&(v239_7))
        };
        drop(v238_5);
        let v238_9: Space = intersect(&(*CONSTANT_1),&(v238_2));
        drop(v238_2);
        let v238_10: Space = if has_head(&(v238_9)) { singleton(&[]) } else { Space::new() };
        drop(v238_9);
        let v238_12: Space = if (v238_10).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v237_6),&(v237_7_head));
          let mut v243_11 = Space::new();
          let mut v243_11_cursor = (v237_7_tail).read_zipper();
          for v243_11_byte in v243_11_cursor.child_mask().iter() {
            v243_11_cursor.descend_to_byte(v243_11_byte);
            {
            let v243_11_tail = v243_11_cursor.fork_read_zipper();
            let v243_11_head = Path::from_slice(&[v243_11_byte]);
            let v244_2: Space = singleton(&(v243_11_head));
            let v244_3: Space = intersect(&(*CONSTANT_1),&(v244_2));
            let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = subtract(&(*CONSTANT_0),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (v244_5).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&(v243_11_head));
              let v245_7: Space = routine_26(c, &(v245_6), &(v243_11_tail).make_space());
              compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = intersect(&(*CONSTANT_1),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (v244_10).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&(v243_11_head));
              let v246_11: Space = routine_15(c, &(v246_6), &(v243_11_tail).make_space());
              drop(v246_6);
              compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = unite(&(v244_8),&(v244_12));
            v243_11.join_into((v244_13).clone());
            }
            v243_11_cursor.ascend(1);
          }
          drop(v243_11_cursor);
          drop(v243_6);
          compose(&(v238_10),&(v243_11))
        };
        drop(v238_10);
        let v238_13: Space = unite(&(v238_8),&(v238_12));
        v237_7.join_into((v238_13).clone());
        }
        v237_7_cursor.ascend(1);
      }
      drop(v237_7_cursor);
      drop(v237_6);
      compose(&(v236_5),&(v237_7))
    };
    drop(v236_5);
    let v236_9: Space = intersect(&(*CONSTANT_1),&(v236_2));
    drop(v236_2);
    let v236_10: Space = if has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
    drop(v236_9);
    let v236_11: Space = compose(&(v236_10),&(v235_14_tail));
    drop(v236_10);
    let v236_12: Space = unite(&(v236_8),&(v236_11));
    drop(v236_11);
    v235_14.join_into((v236_12).clone());
    }
    v235_14_cursor.ascend(1);
  }
  drop(v235_14_cursor);
  (v235_14).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v248_12 = Space::new();
  let mut v248_12_cursor = (*s0).read_zipper();
  for v248_12_byte in v248_12_cursor.child_mask().iter() {
    v248_12_cursor.descend_to_byte(v248_12_byte);
    {
    let v248_12_tail = v248_12_cursor.fork_read_zipper();
    let v248_12_head = Path::from_slice(&[v248_12_byte]);
    let v249_2: Space = singleton(&(v248_12_head));
    let v249_3: Space = intersect(&(*CONSTANT_1),&(v249_2));
    let v249_4: Space = if has_head(&(v249_3)) { singleton(&[]) } else { Space::new() };
    drop(v249_3);
    let v249_5: Space = subtract(&(*CONSTANT_0),&(v249_4));
    drop(v249_4);
    let v249_8: Space = if (v249_5).is_empty() { Space::new() } else {
      let v250_6: Path = concat_path(&(*p0),&(v248_12_head));
      let mut v250_7 = Space::new();
      let mut v250_7_cursor = (v248_12_tail).read_zipper();
      for v250_7_byte in v250_7_cursor.child_mask().iter() {
        v250_7_cursor.descend_to_byte(v250_7_byte);
        {
        let v250_7_tail = v250_7_cursor.fork_read_zipper();
        let v250_7_head = Path::from_slice(&[v250_7_byte]);
        let v251_2: Space = singleton(&(v250_7_head));
        let v251_3: Space = intersect(&(*CONSTANT_1),&(v251_2));
        let v251_4: Space = if has_head(&(v251_3)) { singleton(&[]) } else { Space::new() };
        drop(v251_3);
        let v251_5: Space = subtract(&(*CONSTANT_0),&(v251_4));
        drop(v251_4);
        let mut v251_6 = Space::new();
        let mut v251_6_cursor = (v250_7_tail).read_zipper();
        for v251_6_byte in v251_6_cursor.child_mask().iter() {
          v251_6_cursor.descend_to_byte(v251_6_byte);
          {
          let v251_6_tail = v251_6_cursor.fork_read_zipper();
          let v251_6_head = Path::from_slice(&[v251_6_byte]);
          let v252_2: Space = Space::new();
          v251_6.join_into((v252_2).clone());
          }
          v251_6_cursor.ascend(1);
        }
        drop(v251_6_cursor);
        let v251_7: Space = compose(&(v251_5),&(v251_6));
        drop(v251_5);
        drop(v251_6);
        let v251_8: Space = intersect(&(*CONSTANT_1),&(v251_2));
        drop(v251_2);
        let v251_9: Space = if has_head(&(v251_8)) { singleton(&[]) } else { Space::new() };
        drop(v251_8);
        let v251_12: Space = if (v251_9).is_empty() { Space::new() } else {
          let v253_10: Path = concat_path(&(v250_6),&(v250_7_head));
          let mut v253_11 = Space::new();
          let mut v253_11_cursor = (v250_7_tail).read_zipper();
          for v253_11_byte in v253_11_cursor.child_mask().iter() {
            v253_11_cursor.descend_to_byte(v253_11_byte);
            {
            let v253_11_tail = v253_11_cursor.fork_read_zipper();
            let v253_11_head = Path::from_slice(&[v253_11_byte]);
            let v254_2: Space = singleton(&(v253_11_head));
            let v254_3: Space = intersect(&(*CONSTANT_1),&(v254_2));
            drop(v254_2);
            let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
            drop(v254_3);
            let v254_7: Space = if (v254_4).is_empty() { Space::new() } else {
              let v255_5: Path = concat_path(&(v253_10),&(v253_11_head));
              let v255_6: Space = routine_12(c, &(v255_5), &(v253_11_tail).make_space());
              drop(v255_5);
              compose(&(v254_4),&(v255_6))
            };
            drop(v254_4);
            v253_11.join_into((v254_7).clone());
            }
            v253_11_cursor.ascend(1);
          }
          drop(v253_11_cursor);
          drop(v253_10);
          compose(&(v251_9),&(v253_11))
        };
        drop(v251_9);
        let v251_13: Space = unite(&(v251_7),&(v251_12));
        drop(v251_7);
        v250_7.join_into((v251_13).clone());
        }
        v250_7_cursor.ascend(1);
      }
      drop(v250_7_cursor);
      drop(v250_6);
      compose(&(v249_5),&(v250_7))
    };
    drop(v249_5);
    let v249_9: Space = intersect(&(*CONSTANT_1),&(v249_2));
    drop(v249_2);
    let v249_10: Space = if has_head(&(v249_9)) { singleton(&[]) } else { Space::new() };
    drop(v249_9);
    let mut v249_11 = Space::new();
    let mut v249_11_cursor = (v248_12_tail).read_zipper();
    for v249_11_byte in v249_11_cursor.child_mask().iter() {
      v249_11_cursor.descend_to_byte(v249_11_byte);
      {
      let v249_11_tail = v249_11_cursor.fork_read_zipper();
      let v249_11_head = Path::from_slice(&[v249_11_byte]);
      let v256_2: Space = singleton(&(v249_11_head));
      let v256_3: Space = intersect(&(*CONSTANT_1),&(v256_2));
      let v256_4: Space = if has_head(&(v256_3)) { singleton(&[]) } else { Space::new() };
      drop(v256_3);
      let v256_5: Space = subtract(&(*CONSTANT_0),&(v256_4));
      drop(v256_4);
      let mut v256_6 = Space::new();
      let mut v256_6_cursor = (v249_11_tail).read_zipper();
      for v256_6_byte in v256_6_cursor.child_mask().iter() {
        v256_6_cursor.descend_to_byte(v256_6_byte);
        {
        let v256_6_tail = v256_6_cursor.fork_read_zipper();
        let v256_6_head = Path::from_slice(&[v256_6_byte]);
        let v257_2: Space = Space::new();
        v256_6.join_into((v257_2).clone());
        }
        v256_6_cursor.ascend(1);
      }
      drop(v256_6_cursor);
      let v256_7: Space = compose(&(v256_5),&(v256_6));
      drop(v256_5);
      drop(v256_6);
      let v256_8: Space = intersect(&(*CONSTANT_1),&(v256_2));
      drop(v256_2);
      let v256_9: Space = if has_head(&(v256_8)) { singleton(&[]) } else { Space::new() };
      drop(v256_8);
      let v256_10: Space = compose(&(v256_9),&(v249_11_tail));
      drop(v256_9);
      let v256_11: Space = unite(&(v256_7),&(v256_10));
      drop(v256_7);
      drop(v256_10);
      v249_11.join_into((v256_11).clone());
      }
      v249_11_cursor.ascend(1);
    }
    drop(v249_11_cursor);
    let v249_12: Space = compose(&(v249_10),&(v249_11));
    drop(v249_10);
    drop(v249_11);
    let v249_13: Space = unite(&(v249_8),&(v249_12));
    drop(v249_12);
    v248_12.join_into((v249_13).clone());
    }
    v248_12_cursor.ascend(1);
  }
  drop(v248_12_cursor);
  (v248_12).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v258_9 = Space::new();
  let mut v258_9_cursor = (*s0).read_zipper();
  for v258_9_byte in v258_9_cursor.child_mask().iter() {
    v258_9_cursor.descend_to_byte(v258_9_byte);
    {
    let v258_9_tail = v258_9_cursor.fork_read_zipper();
    let v258_9_head = Path::from_slice(&[v258_9_byte]);
    let v259_2: Space = singleton(&(v258_9_head));
    let v259_3: Space = intersect(&(*CONSTANT_1),&(v259_2));
    let v259_4: Space = if has_head(&(v259_3)) { singleton(&[]) } else { Space::new() };
    drop(v259_3);
    let v259_5: Space = subtract(&(*CONSTANT_0),&(v259_4));
    drop(v259_4);
    let v259_8: Space = if (v259_5).is_empty() { Space::new() } else {
      let v260_6: Path = concat_path(&(*p0),&(v258_9_head));
      let mut v260_7 = Space::new();
      let mut v260_7_cursor = (v258_9_tail).read_zipper();
      for v260_7_byte in v260_7_cursor.child_mask().iter() {
        v260_7_cursor.descend_to_byte(v260_7_byte);
        {
        let v260_7_tail = v260_7_cursor.fork_read_zipper();
        let v260_7_head = Path::from_slice(&[v260_7_byte]);
        let v261_2: Space = singleton(&(v260_7_head));
        let v261_3: Space = intersect(&(*CONSTANT_1),&(v261_2));
        let v261_4: Space = if has_head(&(v261_3)) { singleton(&[]) } else { Space::new() };
        drop(v261_3);
        let v261_5: Space = subtract(&(*CONSTANT_0),&(v261_4));
        drop(v261_4);
        let mut v261_6 = Space::new();
        let mut v261_6_cursor = (v260_7_tail).read_zipper();
        for v261_6_byte in v261_6_cursor.child_mask().iter() {
          v261_6_cursor.descend_to_byte(v261_6_byte);
          {
          let v261_6_tail = v261_6_cursor.fork_read_zipper();
          let v261_6_head = Path::from_slice(&[v261_6_byte]);
          let v262_2: Space = Space::new();
          v261_6.join_into((v262_2).clone());
          }
          v261_6_cursor.ascend(1);
        }
        drop(v261_6_cursor);
        let v261_7: Space = compose(&(v261_5),&(v261_6));
        drop(v261_5);
        drop(v261_6);
        let v261_8: Space = intersect(&(*CONSTANT_1),&(v261_2));
        drop(v261_2);
        let v261_9: Space = if has_head(&(v261_8)) { singleton(&[]) } else { Space::new() };
        drop(v261_8);
        let v261_12: Space = if (v261_9).is_empty() { Space::new() } else {
          let v263_10: Path = concat_path(&(v260_6),&(v260_7_head));
          let mut v263_11 = Space::new();
          let mut v263_11_cursor = (v260_7_tail).read_zipper();
          for v263_11_byte in v263_11_cursor.child_mask().iter() {
            v263_11_cursor.descend_to_byte(v263_11_byte);
            {
            let v263_11_tail = v263_11_cursor.fork_read_zipper();
            let v263_11_head = Path::from_slice(&[v263_11_byte]);
            let v264_2: Space = singleton(&(v263_11_head));
            let v264_3: Space = intersect(&(*CONSTANT_1),&(v264_2));
            drop(v264_2);
            let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
            drop(v264_3);
            let v264_7: Space = if (v264_4).is_empty() { Space::new() } else {
              let v265_5: Path = concat_path(&(v263_10),&(v263_11_head));
              let v265_6: Space = routine_12(c, &(v265_5), &(v263_11_tail).make_space());
              drop(v265_5);
              compose(&(v264_4),&(v265_6))
            };
            drop(v264_4);
            v263_11.join_into((v264_7).clone());
            }
            v263_11_cursor.ascend(1);
          }
          drop(v263_11_cursor);
          drop(v263_10);
          compose(&(v261_9),&(v263_11))
        };
        drop(v261_9);
        let v261_13: Space = unite(&(v261_7),&(v261_12));
        drop(v261_7);
        v260_7.join_into((v261_13).clone());
        }
        v260_7_cursor.ascend(1);
      }
      drop(v260_7_cursor);
      drop(v260_6);
      compose(&(v259_5),&(v260_7))
    };
    drop(v259_5);
    let v259_9: Space = intersect(&(*CONSTANT_1),&(v259_2));
    drop(v259_2);
    let v259_10: Space = if has_head(&(v259_9)) { singleton(&[]) } else { Space::new() };
    drop(v259_9);
    let v259_11: Space = compose(&(v259_10),&(v258_9_tail));
    drop(v259_10);
    let v259_12: Space = unite(&(v259_8),&(v259_11));
    drop(v259_11);
    v258_9.join_into((v259_12).clone());
    }
    v258_9_cursor.ascend(1);
  }
  drop(v258_9_cursor);
  (v258_9).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v266_12 = Space::new();
  let mut v266_12_cursor = (*s0).read_zipper();
  for v266_12_byte in v266_12_cursor.child_mask().iter() {
    v266_12_cursor.descend_to_byte(v266_12_byte);
    {
    let v266_12_tail = v266_12_cursor.fork_read_zipper();
    let v266_12_head = Path::from_slice(&[v266_12_byte]);
    let v267_2: Space = singleton(&(v266_12_head));
    let v267_3: Space = intersect(&(*CONSTANT_1),&(v267_2));
    let v267_4: Space = if has_head(&(v267_3)) { singleton(&[]) } else { Space::new() };
    drop(v267_3);
    let v267_5: Space = subtract(&(*CONSTANT_0),&(v267_4));
    drop(v267_4);
    let v267_8: Space = if (v267_5).is_empty() { Space::new() } else {
      let v268_6: Path = concat_path(&(*p0),&(v266_12_head));
      let mut v268_7 = Space::new();
      let mut v268_7_cursor = (v266_12_tail).read_zipper();
      for v268_7_byte in v268_7_cursor.child_mask().iter() {
        v268_7_cursor.descend_to_byte(v268_7_byte);
        {
        let v268_7_tail = v268_7_cursor.fork_read_zipper();
        let v268_7_head = Path::from_slice(&[v268_7_byte]);
        let v269_2: Space = singleton(&(v268_7_head));
        let v269_3: Space = intersect(&(*CONSTANT_1),&(v269_2));
        let v269_4: Space = if has_head(&(v269_3)) { singleton(&[]) } else { Space::new() };
        drop(v269_3);
        let v269_5: Space = subtract(&(*CONSTANT_0),&(v269_4));
        drop(v269_4);
        let mut v269_6 = Space::new();
        let mut v269_6_cursor = (v268_7_tail).read_zipper();
        for v269_6_byte in v269_6_cursor.child_mask().iter() {
          v269_6_cursor.descend_to_byte(v269_6_byte);
          {
          let v269_6_tail = v269_6_cursor.fork_read_zipper();
          let v269_6_head = Path::from_slice(&[v269_6_byte]);
          let v270_2: Space = Space::new();
          v269_6.join_into((v270_2).clone());
          }
          v269_6_cursor.ascend(1);
        }
        drop(v269_6_cursor);
        let v269_7: Space = compose(&(v269_5),&(v269_6));
        drop(v269_5);
        drop(v269_6);
        let v269_8: Space = intersect(&(*CONSTANT_1),&(v269_2));
        drop(v269_2);
        let v269_9: Space = if has_head(&(v269_8)) { singleton(&[]) } else { Space::new() };
        drop(v269_8);
        let v269_12: Space = if (v269_9).is_empty() { Space::new() } else {
          let v271_10: Path = concat_path(&(v268_6),&(v268_7_head));
          let mut v271_11 = Space::new();
          let mut v271_11_cursor = (v268_7_tail).read_zipper();
          for v271_11_byte in v271_11_cursor.child_mask().iter() {
            v271_11_cursor.descend_to_byte(v271_11_byte);
            {
            let v271_11_tail = v271_11_cursor.fork_read_zipper();
            let v271_11_head = Path::from_slice(&[v271_11_byte]);
            let v272_2: Space = singleton(&(v271_11_head));
            let v272_3: Space = intersect(&(*CONSTANT_1),&(v272_2));
            drop(v272_2);
            let v272_4: Space = if has_head(&(v272_3)) { singleton(&[]) } else { Space::new() };
            drop(v272_3);
            let v272_7: Space = if (v272_4).is_empty() { Space::new() } else {
              let v273_5: Path = concat_path(&(v271_10),&(v271_11_head));
              let v273_6: Space = routine_15(c, &(v273_5), &(v271_11_tail).make_space());
              drop(v273_5);
              compose(&(v272_4),&(v273_6))
            };
            drop(v272_4);
            v271_11.join_into((v272_7).clone());
            }
            v271_11_cursor.ascend(1);
          }
          drop(v271_11_cursor);
          drop(v271_10);
          compose(&(v269_9),&(v271_11))
        };
        drop(v269_9);
        let v269_13: Space = unite(&(v269_7),&(v269_12));
        drop(v269_7);
        v268_7.join_into((v269_13).clone());
        }
        v268_7_cursor.ascend(1);
      }
      drop(v268_7_cursor);
      drop(v268_6);
      compose(&(v267_5),&(v268_7))
    };
    drop(v267_5);
    let v267_9: Space = intersect(&(*CONSTANT_1),&(v267_2));
    drop(v267_2);
    let v267_10: Space = if has_head(&(v267_9)) { singleton(&[]) } else { Space::new() };
    drop(v267_9);
    let mut v267_11 = Space::new();
    let mut v267_11_cursor = (v266_12_tail).read_zipper();
    for v267_11_byte in v267_11_cursor.child_mask().iter() {
      v267_11_cursor.descend_to_byte(v267_11_byte);
      {
      let v267_11_tail = v267_11_cursor.fork_read_zipper();
      let v267_11_head = Path::from_slice(&[v267_11_byte]);
      let v274_2: Space = singleton(&(v267_11_head));
      let v274_3: Space = intersect(&(*CONSTANT_1),&(v274_2));
      let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
      drop(v274_3);
      let v274_5: Space = subtract(&(*CONSTANT_0),&(v274_4));
      drop(v274_4);
      let mut v274_6 = Space::new();
      let mut v274_6_cursor = (v267_11_tail).read_zipper();
      for v274_6_byte in v274_6_cursor.child_mask().iter() {
        v274_6_cursor.descend_to_byte(v274_6_byte);
        {
        let v274_6_tail = v274_6_cursor.fork_read_zipper();
        let v274_6_head = Path::from_slice(&[v274_6_byte]);
        let v275_2: Space = Space::new();
        v274_6.join_into((v275_2).clone());
        }
        v274_6_cursor.ascend(1);
      }
      drop(v274_6_cursor);
      let v274_7: Space = compose(&(v274_5),&(v274_6));
      drop(v274_5);
      drop(v274_6);
      let v274_8: Space = intersect(&(*CONSTANT_1),&(v274_2));
      drop(v274_2);
      let v274_9: Space = if has_head(&(v274_8)) { singleton(&[]) } else { Space::new() };
      drop(v274_8);
      let v274_10: Space = compose(&(v274_9),&(v267_11_tail));
      drop(v274_9);
      let v274_11: Space = unite(&(v274_7),&(v274_10));
      drop(v274_7);
      drop(v274_10);
      v267_11.join_into((v274_11).clone());
      }
      v267_11_cursor.ascend(1);
    }
    drop(v267_11_cursor);
    let v267_12: Space = compose(&(v267_10),&(v267_11));
    drop(v267_10);
    drop(v267_11);
    let v267_13: Space = unite(&(v267_8),&(v267_12));
    drop(v267_12);
    v266_12.join_into((v267_13).clone());
    }
    v266_12_cursor.ascend(1);
  }
  drop(v266_12_cursor);
  (v266_12).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v276_9 = Space::new();
  let mut v276_9_cursor = (*s0).read_zipper();
  for v276_9_byte in v276_9_cursor.child_mask().iter() {
    v276_9_cursor.descend_to_byte(v276_9_byte);
    {
    let v276_9_tail = v276_9_cursor.fork_read_zipper();
    let v276_9_head = Path::from_slice(&[v276_9_byte]);
    let v277_2: Space = singleton(&(v276_9_head));
    let v277_3: Space = intersect(&(*CONSTANT_1),&(v277_2));
    let v277_4: Space = if has_head(&(v277_3)) { singleton(&[]) } else { Space::new() };
    drop(v277_3);
    let v277_5: Space = subtract(&(*CONSTANT_0),&(v277_4));
    drop(v277_4);
    let v277_8: Space = if (v277_5).is_empty() { Space::new() } else {
      let v278_6: Path = concat_path(&(*p0),&(v276_9_head));
      let mut v278_7 = Space::new();
      let mut v278_7_cursor = (v276_9_tail).read_zipper();
      for v278_7_byte in v278_7_cursor.child_mask().iter() {
        v278_7_cursor.descend_to_byte(v278_7_byte);
        {
        let v278_7_tail = v278_7_cursor.fork_read_zipper();
        let v278_7_head = Path::from_slice(&[v278_7_byte]);
        let v279_2: Space = singleton(&(v278_7_head));
        let v279_3: Space = intersect(&(*CONSTANT_1),&(v279_2));
        let v279_4: Space = if has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
        drop(v279_3);
        let v279_5: Space = subtract(&(*CONSTANT_0),&(v279_4));
        drop(v279_4);
        let mut v279_6 = Space::new();
        let mut v279_6_cursor = (v278_7_tail).read_zipper();
        for v279_6_byte in v279_6_cursor.child_mask().iter() {
          v279_6_cursor.descend_to_byte(v279_6_byte);
          {
          let v279_6_tail = v279_6_cursor.fork_read_zipper();
          let v279_6_head = Path::from_slice(&[v279_6_byte]);
          let v280_2: Space = Space::new();
          v279_6.join_into((v280_2).clone());
          }
          v279_6_cursor.ascend(1);
        }
        drop(v279_6_cursor);
        let v279_7: Space = compose(&(v279_5),&(v279_6));
        drop(v279_5);
        drop(v279_6);
        let v279_8: Space = intersect(&(*CONSTANT_1),&(v279_2));
        drop(v279_2);
        let v279_9: Space = if has_head(&(v279_8)) { singleton(&[]) } else { Space::new() };
        drop(v279_8);
        let v279_12: Space = if (v279_9).is_empty() { Space::new() } else {
          let v281_10: Path = concat_path(&(v278_6),&(v278_7_head));
          let mut v281_11 = Space::new();
          let mut v281_11_cursor = (v278_7_tail).read_zipper();
          for v281_11_byte in v281_11_cursor.child_mask().iter() {
            v281_11_cursor.descend_to_byte(v281_11_byte);
            {
            let v281_11_tail = v281_11_cursor.fork_read_zipper();
            let v281_11_head = Path::from_slice(&[v281_11_byte]);
            let v282_2: Space = singleton(&(v281_11_head));
            let v282_3: Space = intersect(&(*CONSTANT_1),&(v282_2));
            drop(v282_2);
            let v282_4: Space = if has_head(&(v282_3)) { singleton(&[]) } else { Space::new() };
            drop(v282_3);
            let v282_7: Space = if (v282_4).is_empty() { Space::new() } else {
              let v283_5: Path = concat_path(&(v281_10),&(v281_11_head));
              let v283_6: Space = routine_15(c, &(v283_5), &(v281_11_tail).make_space());
              drop(v283_5);
              compose(&(v282_4),&(v283_6))
            };
            drop(v282_4);
            v281_11.join_into((v282_7).clone());
            }
            v281_11_cursor.ascend(1);
          }
          drop(v281_11_cursor);
          drop(v281_10);
          compose(&(v279_9),&(v281_11))
        };
        drop(v279_9);
        let v279_13: Space = unite(&(v279_7),&(v279_12));
        drop(v279_7);
        v278_7.join_into((v279_13).clone());
        }
        v278_7_cursor.ascend(1);
      }
      drop(v278_7_cursor);
      drop(v278_6);
      compose(&(v277_5),&(v278_7))
    };
    drop(v277_5);
    let v277_9: Space = intersect(&(*CONSTANT_1),&(v277_2));
    drop(v277_2);
    let v277_10: Space = if has_head(&(v277_9)) { singleton(&[]) } else { Space::new() };
    drop(v277_9);
    let v277_11: Space = compose(&(v277_10),&(v276_9_tail));
    drop(v277_10);
    let v277_12: Space = unite(&(v277_8),&(v277_11));
    drop(v277_11);
    v276_9.join_into((v277_12).clone());
    }
    v276_9_cursor.ascend(1);
  }
  drop(v276_9_cursor);
  (v276_9).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v284_6 = Space::new();
  let mut v284_6_cursor = (*s0).read_zipper();
  for v284_6_byte in v284_6_cursor.child_mask().iter() {
    v284_6_cursor.descend_to_byte(v284_6_byte);
    {
    let v284_6_tail = v284_6_cursor.fork_read_zipper();
    let v284_6_head = Path::from_slice(&[v284_6_byte]);
    let v285_2: Space = singleton(&(v284_6_head));
    let v285_3: Space = intersect(&(*CONSTANT_1),&(v285_2));
    let v285_4: Space = if has_head(&(v285_3)) { singleton(&[]) } else { Space::new() };
    drop(v285_3);
    let v285_5: Space = subtract(&(*CONSTANT_0),&(v285_4));
    drop(v285_4);
    let mut v285_6 = Space::new();
    let mut v285_6_cursor = (v284_6_tail).read_zipper();
    for v285_6_byte in v285_6_cursor.child_mask().iter() {
      v285_6_cursor.descend_to_byte(v285_6_byte);
      {
      let v285_6_tail = v285_6_cursor.fork_read_zipper();
      let v285_6_head = Path::from_slice(&[v285_6_byte]);
      let v286_2: Space = Space::new();
      v285_6.join_into((v286_2).clone());
      }
      v285_6_cursor.ascend(1);
    }
    drop(v285_6_cursor);
    let v285_7: Space = compose(&(v285_5),&(v285_6));
    drop(v285_5);
    drop(v285_6);
    let v285_8: Space = intersect(&(*CONSTANT_1),&(v285_2));
    drop(v285_2);
    let v285_9: Space = if has_head(&(v285_8)) { singleton(&[]) } else { Space::new() };
    drop(v285_8);
    let mut v285_10 = Space::new();
    let mut v285_10_cursor = (v284_6_tail).read_zipper();
    for v285_10_byte in v285_10_cursor.child_mask().iter() {
      v285_10_cursor.descend_to_byte(v285_10_byte);
      {
      let v285_10_tail = v285_10_cursor.fork_read_zipper();
      let v285_10_head = Path::from_slice(&[v285_10_byte]);
      let v287_2: Space = singleton(&(v285_10_head));
      let v287_3: Space = intersect(&(*CONSTANT_1),&(v287_2));
      drop(v287_2);
      let v287_4: Space = if has_head(&(v287_3)) { singleton(&[]) } else { Space::new() };
      drop(v287_3);
      let v287_5: Space = compose(&(v287_4),&(v285_10_tail));
      drop(v287_4);
      v285_10.join_into((v287_5).clone());
      }
      v285_10_cursor.ascend(1);
    }
    drop(v285_10_cursor);
    let v285_11: Space = compose(&(v285_9),&(v285_10));
    drop(v285_9);
    drop(v285_10);
    let v285_12: Space = unite(&(v285_7),&(v285_11));
    drop(v285_7);
    drop(v285_11);
    v284_6.join_into((v285_12).clone());
    }
    v284_6_cursor.ascend(1);
  }
  drop(v284_6_cursor);
  (v284_6).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v288_5 = Space::new();
  let mut v288_5_cursor = (*s0).read_zipper();
  for v288_5_byte in v288_5_cursor.child_mask().iter() {
    v288_5_cursor.descend_to_byte(v288_5_byte);
    {
    let v288_5_tail = v288_5_cursor.fork_read_zipper();
    let v288_5_head = Path::from_slice(&[v288_5_byte]);
    let v289_2: Space = singleton(&(v288_5_head));
    let v289_3: Space = intersect(&(*CONSTANT_1),&(v289_2));
    let v289_4: Space = if has_head(&(v289_3)) { singleton(&[]) } else { Space::new() };
    drop(v289_3);
    let v289_5: Space = subtract(&(*CONSTANT_0),&(v289_4));
    drop(v289_4);
    let mut v289_6 = Space::new();
    let mut v289_6_cursor = (v288_5_tail).read_zipper();
    for v289_6_byte in v289_6_cursor.child_mask().iter() {
      v289_6_cursor.descend_to_byte(v289_6_byte);
      {
      let v289_6_tail = v289_6_cursor.fork_read_zipper();
      let v289_6_head = Path::from_slice(&[v289_6_byte]);
      let v290_2: Space = Space::new();
      v289_6.join_into((v290_2).clone());
      }
      v289_6_cursor.ascend(1);
    }
    drop(v289_6_cursor);
    let v289_7: Space = compose(&(v289_5),&(v289_6));
    drop(v289_5);
    drop(v289_6);
    let v289_8: Space = intersect(&(*CONSTANT_1),&(v289_2));
    drop(v289_2);
    let v289_9: Space = if has_head(&(v289_8)) { singleton(&[]) } else { Space::new() };
    drop(v289_8);
    let v289_10: Space = compose(&(v289_9),&(v288_5_tail));
    drop(v289_9);
    let v289_11: Space = unite(&(v289_7),&(v289_10));
    drop(v289_7);
    drop(v289_10);
    v288_5.join_into((v289_11).clone());
    }
    v288_5_cursor.ascend(1);
  }
  drop(v288_5_cursor);
  (v288_5).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v291_6 = Space::new();
  let mut v291_6_cursor = (*s0).read_zipper();
  for v291_6_byte in v291_6_cursor.child_mask().iter() {
    v291_6_cursor.descend_to_byte(v291_6_byte);
    {
    let v291_6_tail = v291_6_cursor.fork_read_zipper();
    let v291_6_head = Path::from_slice(&[v291_6_byte]);
    let v292_2: Space = singleton(&(v291_6_head));
    let v292_3: Space = intersect(&(*CONSTANT_1),&(v292_2));
    let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
    drop(v292_3);
    let v292_5: Space = subtract(&(*CONSTANT_0),&(v292_4));
    drop(v292_4);
    let mut v292_6 = Space::new();
    let mut v292_6_cursor = (v291_6_tail).read_zipper();
    for v292_6_byte in v292_6_cursor.child_mask().iter() {
      v292_6_cursor.descend_to_byte(v292_6_byte);
      {
      let v292_6_tail = v292_6_cursor.fork_read_zipper();
      let v292_6_head = Path::from_slice(&[v292_6_byte]);
      let v293_2: Space = Space::new();
      v292_6.join_into((v293_2).clone());
      }
      v292_6_cursor.ascend(1);
    }
    drop(v292_6_cursor);
    let v292_7: Space = compose(&(v292_5),&(v292_6));
    drop(v292_5);
    drop(v292_6);
    let v292_8: Space = intersect(&(*CONSTANT_1),&(v292_2));
    drop(v292_2);
    let v292_9: Space = if has_head(&(v292_8)) { singleton(&[]) } else { Space::new() };
    drop(v292_8);
    let mut v292_10 = Space::new();
    let mut v292_10_cursor = (v291_6_tail).read_zipper();
    for v292_10_byte in v292_10_cursor.child_mask().iter() {
      v292_10_cursor.descend_to_byte(v292_10_byte);
      {
      let v292_10_tail = v292_10_cursor.fork_read_zipper();
      let v292_10_head = Path::from_slice(&[v292_10_byte]);
      let v294_2: Space = singleton(&(v292_10_head));
      let v294_3: Space = intersect(&(*CONSTANT_1),&(v294_2));
      drop(v294_2);
      let v294_4: Space = if has_head(&(v294_3)) { singleton(&[]) } else { Space::new() };
      drop(v294_3);
      let v294_5: Space = compose(&(v294_4),&(v292_10_tail));
      drop(v294_4);
      v292_10.join_into((v294_5).clone());
      }
      v292_10_cursor.ascend(1);
    }
    drop(v292_10_cursor);
    let v292_11: Space = compose(&(v292_9),&(v292_10));
    drop(v292_9);
    drop(v292_10);
    let v292_12: Space = unite(&(v292_7),&(v292_11));
    drop(v292_7);
    drop(v292_11);
    v291_6.join_into((v292_12).clone());
    }
    v291_6_cursor.ascend(1);
  }
  drop(v291_6_cursor);
  (v291_6).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v295_5 = Space::new();
  let mut v295_5_cursor = (*s0).read_zipper();
  for v295_5_byte in v295_5_cursor.child_mask().iter() {
    v295_5_cursor.descend_to_byte(v295_5_byte);
    {
    let v295_5_tail = v295_5_cursor.fork_read_zipper();
    let v295_5_head = Path::from_slice(&[v295_5_byte]);
    let v296_2: Space = singleton(&(v295_5_head));
    let v296_3: Space = intersect(&(*CONSTANT_1),&(v296_2));
    let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
    drop(v296_3);
    let v296_5: Space = subtract(&(*CONSTANT_0),&(v296_4));
    drop(v296_4);
    let mut v296_6 = Space::new();
    let mut v296_6_cursor = (v295_5_tail).read_zipper();
    for v296_6_byte in v296_6_cursor.child_mask().iter() {
      v296_6_cursor.descend_to_byte(v296_6_byte);
      {
      let v296_6_tail = v296_6_cursor.fork_read_zipper();
      let v296_6_head = Path::from_slice(&[v296_6_byte]);
      let v297_2: Space = Space::new();
      v296_6.join_into((v297_2).clone());
      }
      v296_6_cursor.ascend(1);
    }
    drop(v296_6_cursor);
    let v296_7: Space = compose(&(v296_5),&(v296_6));
    drop(v296_5);
    drop(v296_6);
    let v296_8: Space = intersect(&(*CONSTANT_1),&(v296_2));
    drop(v296_2);
    let v296_9: Space = if has_head(&(v296_8)) { singleton(&[]) } else { Space::new() };
    drop(v296_8);
    let v296_10: Space = compose(&(v296_9),&(v295_5_tail));
    drop(v296_9);
    let v296_11: Space = unite(&(v296_7),&(v296_10));
    drop(v296_7);
    drop(v296_10);
    v295_5.join_into((v296_11).clone());
    }
    v295_5_cursor.ascend(1);
  }
  drop(v295_5_cursor);
  (v295_5).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v298_2 = Space::new();
  let mut v298_2_cursor = (*s0).read_zipper();
  for v298_2_byte in v298_2_cursor.child_mask().iter() {
    v298_2_cursor.descend_to_byte(v298_2_byte);
    {
    let v298_2_tail = v298_2_cursor.fork_read_zipper();
    let v298_2_head = Path::from_slice(&[v298_2_byte]);
    let v299_2: Space = Space::new();
    v298_2.join_into((v299_2).clone());
    }
    v298_2_cursor.ascend(1);
  }
  drop(v298_2_cursor);
  (v298_2).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v300_3 = Space::new();
  let mut v300_3_cursor = (*s0).read_zipper();
  for v300_3_byte in v300_3_cursor.child_mask().iter() {
    v300_3_cursor.descend_to_byte(v300_3_byte);
    {
    let v300_3_tail = v300_3_cursor.fork_read_zipper();
    let v300_3_head = Path::from_slice(&[v300_3_byte]);
    let v301_2: Space = singleton(&(v300_3_head));
    let v301_3: Space = intersect(&(*CONSTANT_1),&(v301_2));
    drop(v301_2);
    let v301_4: Space = if has_head(&(v301_3)) { singleton(&[]) } else { Space::new() };
    drop(v301_3);
    let v301_5: Space = compose(&(v301_4),&(v300_3_tail));
    drop(v301_4);
    v300_3.join_into((v301_5).clone());
    }
    v300_3_cursor.ascend(1);
  }
  drop(v300_3_cursor);
  (v300_3).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v302_2 = Space::new();
  let mut v302_2_cursor = (*s0).read_zipper();
  for v302_2_byte in v302_2_cursor.child_mask().iter() {
    v302_2_cursor.descend_to_byte(v302_2_byte);
    {
    let v302_2_tail = v302_2_cursor.fork_read_zipper();
    let v302_2_head = Path::from_slice(&[v302_2_byte]);
    let v303_2: Space = Space::new();
    v302_2.join_into((v303_2).clone());
    }
    v302_2_cursor.ascend(1);
  }
  drop(v302_2_cursor);
  (v302_2).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v304_3 = Space::new();
  let mut v304_3_cursor = (*s0).read_zipper();
  for v304_3_byte in v304_3_cursor.child_mask().iter() {
    v304_3_cursor.descend_to_byte(v304_3_byte);
    {
    let v304_3_tail = v304_3_cursor.fork_read_zipper();
    let v304_3_head = Path::from_slice(&[v304_3_byte]);
    let v305_2: Space = singleton(&(v304_3_head));
    let v305_3: Space = intersect(&(*CONSTANT_1),&(v305_2));
    drop(v305_2);
    let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
    drop(v305_3);
    let v305_5: Space = compose(&(v305_4),&(v304_3_tail));
    drop(v305_4);
    v304_3.join_into((v305_5).clone());
    }
    v304_3_cursor.ascend(1);
  }
  drop(v304_3_cursor);
  (v304_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
