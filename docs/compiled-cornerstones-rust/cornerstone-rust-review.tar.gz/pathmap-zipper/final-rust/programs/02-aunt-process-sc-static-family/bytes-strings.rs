#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 8 66 111 98 0 65 110 110 0 8 66 111 98 0 80 97 116 0 8 80 97 109 0 66 111 98 0 8 80 97 116 0 74 105 109 0 8 84 111 109 0 66 111 98 0 8 84 111 109 0 76 105 122 0"));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 8 65 110 110 0 66 111 98 0 8 66 111 98 0 80 97 109 0 8 66 111 98 0 84 111 109 0 8 74 105 109 0 80 97 116 0 8 76 105 122 0 84 111 109 0 8 80 97 116 0 66 111 98 0"));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("4 4 65 110 110 0 4 76 105 122 0 4 80 97 109 0 4 80 97 116 0"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[65,117,110,116,0]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let mut v0_15 = Space::new();
  let mut v0_15_cursor = (*s0.expect("unbound native input")).read_zipper();
  for v0_15_byte in v0_15_cursor.child_mask().iter() {
    v0_15_cursor.descend_to_byte(v0_15_byte);
    {
    let v0_15_tail = v0_15_cursor.fork_read_zipper();
    let v0_15_head = Path::from_slice(&[v0_15_byte]);
    let v1_2: Space = singleton(&(v0_15_head));
    let v1_3: Space = intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let v2_6: Space = routine_1(c, &(v0_15_head), &(v0_15_tail).make_space());
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_18: Space = if (v1_9).is_empty() { Space::new() } else {
      let v3_10: Space = unwrap(&(*CONSTANT_3),&(v0_15_head));
      let v3_11: Space = restrict_to(&(*CONSTANT_3),&(v3_10));
      drop(v3_10);
      let mut v3_12 = Space::new();
      let mut v3_12_cursor = (v3_11).read_zipper();
      for v3_12_byte in v3_12_cursor.child_mask().iter() {
        v3_12_cursor.descend_to_byte(v3_12_byte);
        {
        let v3_12_tail = v3_12_cursor.fork_read_zipper();
        let v3_12_head = Path::from_slice(&[v3_12_byte]);
        let v4_2: Space = singleton(&(v3_12_head));
        let v4_3: Space = intersect(&(*CONSTANT_1),&(v4_2));
        let v4_4: Space = if has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
        drop(v4_3);
        let v4_5: Space = subtract(&(*CONSTANT_0),&(v4_4));
        drop(v4_4);
        let v4_7: Space = if (v4_5).is_empty() { Space::new() } else {
          let v5_6: Space = routine_2(c, &(v3_12_head), &(v3_12_tail).make_space());
          compose(&(v4_5),&(v5_6))
        };
        drop(v4_5);
        let v4_8: Space = intersect(&(*CONSTANT_1),&(v4_2));
        drop(v4_2);
        let v4_9: Space = if has_head(&(v4_8)) { singleton(&[]) } else { Space::new() };
        drop(v4_8);
        let v4_11: Space = if (v4_9).is_empty() { Space::new() } else {
          let v6_10: Space = routine_3(c, &(v3_12_head), &(v3_12_tail).make_space());
          compose(&(v4_9),&(v6_10))
        };
        drop(v4_9);
        let v4_12: Space = unite(&(v4_7),&(v4_11));
        v3_12.join_into((v4_12).clone());
        }
        v3_12_cursor.ascend(1);
      }
      drop(v3_12_cursor);
      drop(v3_11);
      let v3_13: Space = restrict_to(&(*CONSTANT_2),&(v3_12));
      let mut v3_14 = Space::new();
      let mut v3_14_cursor = (v3_13).read_zipper();
      for v3_14_byte in v3_14_cursor.child_mask().iter() {
        v3_14_cursor.descend_to_byte(v3_14_byte);
        {
        let v3_14_tail = v3_14_cursor.fork_read_zipper();
        let v3_14_head = Path::from_slice(&[v3_14_byte]);
        let v7_2: Space = singleton(&(v3_14_head));
        let v7_3: Space = intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_7: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Space = routine_4(c, &(v3_14_head), &(v3_14_tail).make_space());
          compose(&(v7_5),&(v8_6))
        };
        drop(v7_5);
        let v7_8: Space = intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_9: Space = if has_head(&(v7_8)) { singleton(&[]) } else { Space::new() };
        drop(v7_8);
        let v7_11: Space = if (v7_9).is_empty() { Space::new() } else {
          let v9_10: Space = routine_5(c, &(v3_14_head), &(v3_14_tail).make_space());
          compose(&(v7_9),&(v9_10))
        };
        drop(v7_9);
        let v7_12: Space = unite(&(v7_7),&(v7_11));
        v3_14.join_into((v7_12).clone());
        }
        v3_14_cursor.ascend(1);
      }
      drop(v3_14_cursor);
      let v3_15: Space = unwrap(&(*CONSTANT_3),&(v0_15_head));
      let v3_16: Space = subtract(&(v3_14),&(v3_15));
      drop(v3_15);
      let v3_17: Space = intersect(&(v3_16),&(*CONSTANT_4));
      compose(&(v1_9),&(v3_17))
    };
    drop(v1_9);
    let v1_19: Space = wrap(&(v1_18),&(v0_15_head));
    let v1_20: Space = unite(&(v1_7),&(v1_19));
    v0_15.join_into((v1_20).clone());
    }
    v0_15_cursor.ascend(1);
  }
  drop(v0_15_cursor);
  let v0_17: Space = wrap(&(v0_15),&(*CONSTANT_5));
  (v0_17).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v10_8: Space = unwrap(&(*CONSTANT_3),&(*p0));
  let v10_10: Space = unwrap(&(*CONSTANT_3),&(*p0));
  let mut v10_18 = Space::new();
  let mut v10_18_cursor = (*s0).read_zipper();
  for v10_18_byte in v10_18_cursor.child_mask().iter() {
    v10_18_cursor.descend_to_byte(v10_18_byte);
    {
    let v10_18_tail = v10_18_cursor.fork_read_zipper();
    let v10_18_head = Path::from_slice(&[v10_18_byte]);
    let v11_2: Space = singleton(&(v10_18_head));
    let v11_3: Space = intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_18_head));
      let v12_7: Space = routine_1(c, &(v12_6), &(v10_18_tail).make_space());
      compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_19: Space = if (v11_10).is_empty() { Space::new() } else {
      let v13_11: Space = unwrap(&(v10_8),&(v10_18_head));
      let v13_12: Space = restrict_to(&(*CONSTANT_3),&(v13_11));
      drop(v13_11);
      let mut v13_13 = Space::new();
      let mut v13_13_cursor = (v13_12).read_zipper();
      for v13_13_byte in v13_13_cursor.child_mask().iter() {
        v13_13_cursor.descend_to_byte(v13_13_byte);
        {
        let v13_13_tail = v13_13_cursor.fork_read_zipper();
        let v13_13_head = Path::from_slice(&[v13_13_byte]);
        let v14_2: Space = singleton(&(v13_13_head));
        let v14_3: Space = intersect(&(*CONSTANT_1),&(v14_2));
        let v14_4: Space = if has_head(&(v14_3)) { singleton(&[]) } else { Space::new() };
        drop(v14_3);
        let v14_5: Space = subtract(&(*CONSTANT_0),&(v14_4));
        drop(v14_4);
        let v14_7: Space = if (v14_5).is_empty() { Space::new() } else {
          let v15_6: Space = routine_2(c, &(v13_13_head), &(v13_13_tail).make_space());
          compose(&(v14_5),&(v15_6))
        };
        drop(v14_5);
        let v14_8: Space = intersect(&(*CONSTANT_1),&(v14_2));
        drop(v14_2);
        let v14_9: Space = if has_head(&(v14_8)) { singleton(&[]) } else { Space::new() };
        drop(v14_8);
        let v14_10: Space = compose(&(v14_9),&(v13_13_tail));
        drop(v14_9);
        let v14_11: Space = unite(&(v14_7),&(v14_10));
        drop(v14_10);
        v13_13.join_into((v14_11).clone());
        }
        v13_13_cursor.ascend(1);
      }
      drop(v13_13_cursor);
      drop(v13_12);
      let v13_14: Space = restrict_to(&(*CONSTANT_2),&(v13_13));
      let mut v13_15 = Space::new();
      let mut v13_15_cursor = (v13_14).read_zipper();
      for v13_15_byte in v13_15_cursor.child_mask().iter() {
        v13_15_cursor.descend_to_byte(v13_15_byte);
        {
        let v13_15_tail = v13_15_cursor.fork_read_zipper();
        let v13_15_head = Path::from_slice(&[v13_15_byte]);
        let v16_2: Space = singleton(&(v13_15_head));
        let v16_3: Space = intersect(&(*CONSTANT_1),&(v16_2));
        let v16_4: Space = if has_head(&(v16_3)) { singleton(&[]) } else { Space::new() };
        drop(v16_3);
        let v16_5: Space = subtract(&(*CONSTANT_0),&(v16_4));
        drop(v16_4);
        let v16_7: Space = if (v16_5).is_empty() { Space::new() } else {
          let v17_6: Space = routine_4(c, &(v13_15_head), &(v13_15_tail).make_space());
          compose(&(v16_5),&(v17_6))
        };
        drop(v16_5);
        let v16_8: Space = intersect(&(*CONSTANT_1),&(v16_2));
        drop(v16_2);
        let v16_9: Space = if has_head(&(v16_8)) { singleton(&[]) } else { Space::new() };
        drop(v16_8);
        let v16_10: Space = compose(&(v16_9),&(v13_15_tail));
        drop(v16_9);
        let v16_11: Space = unite(&(v16_7),&(v16_10));
        drop(v16_10);
        v13_15.join_into((v16_11).clone());
        }
        v13_15_cursor.ascend(1);
      }
      drop(v13_15_cursor);
      let v13_16: Space = unwrap(&(v10_10),&(v10_18_head));
      let v13_17: Space = subtract(&(v13_15),&(v13_16));
      drop(v13_16);
      let v13_18: Space = intersect(&(v13_17),&(*CONSTANT_4));
      compose(&(v11_10),&(v13_18))
    };
    drop(v11_10);
    let v18_6: Path = concat_path(&(*p0),&(v10_18_head));
    let v11_20: Space = wrap(&(v11_19),&(v18_6));
    let v11_21: Space = unite(&(v11_8),&(v11_20));
    v10_18.join_into((v11_21).clone());
    }
    v10_18_cursor.ascend(1);
  }
  drop(v10_18_cursor);
  drop(v10_8);
  drop(v10_10);
  (v10_18).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v19_5 = Space::new();
  let mut v19_5_cursor = (*s0).read_zipper();
  for v19_5_byte in v19_5_cursor.child_mask().iter() {
    v19_5_cursor.descend_to_byte(v19_5_byte);
    {
    let v19_5_tail = v19_5_cursor.fork_read_zipper();
    let v19_5_head = Path::from_slice(&[v19_5_byte]);
    let v20_2: Space = singleton(&(v19_5_head));
    let v20_3: Space = intersect(&(*CONSTANT_1),&(v20_2));
    let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
    drop(v20_3);
    let v20_5: Space = subtract(&(*CONSTANT_0),&(v20_4));
    drop(v20_4);
    let v20_8: Space = if (v20_5).is_empty() { Space::new() } else {
      let v21_6: Path = concat_path(&(*p0),&(v19_5_head));
      let v21_7: Space = routine_2(c, &(v21_6), &(v19_5_tail).make_space());
      drop(v21_6);
      compose(&(v20_5),&(v21_7))
    };
    drop(v20_5);
    let v20_9: Space = intersect(&(*CONSTANT_1),&(v20_2));
    drop(v20_2);
    let v20_10: Space = if has_head(&(v20_9)) { singleton(&[]) } else { Space::new() };
    drop(v20_9);
    let v20_11: Space = compose(&(v20_10),&(v19_5_tail));
    drop(v20_10);
    let v20_12: Space = unite(&(v20_8),&(v20_11));
    drop(v20_11);
    v19_5.join_into((v20_12).clone());
    }
    v19_5_cursor.ascend(1);
  }
  drop(v19_5_cursor);
  (v19_5).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v23_5 = Space::new();
  let mut v23_5_cursor = (*s0).read_zipper();
  for v23_5_byte in v23_5_cursor.child_mask().iter() {
    v23_5_cursor.descend_to_byte(v23_5_byte);
    {
    let v23_5_tail = v23_5_cursor.fork_read_zipper();
    let v23_5_head = Path::from_slice(&[v23_5_byte]);
    let v24_2: Space = singleton(&(v23_5_head));
    let v24_3: Space = intersect(&(*CONSTANT_1),&(v24_2));
    let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
    drop(v24_3);
    let v24_5: Space = subtract(&(*CONSTANT_0),&(v24_4));
    drop(v24_4);
    let v24_8: Space = if (v24_5).is_empty() { Space::new() } else {
      let v25_6: Path = concat_path(&(*p0),&(v23_5_head));
      let v25_7: Space = routine_4(c, &(v25_6), &(v23_5_tail).make_space());
      drop(v25_6);
      compose(&(v24_5),&(v25_7))
    };
    drop(v24_5);
    let v24_9: Space = intersect(&(*CONSTANT_1),&(v24_2));
    drop(v24_2);
    let v24_10: Space = if has_head(&(v24_9)) { singleton(&[]) } else { Space::new() };
    drop(v24_9);
    let v24_11: Space = compose(&(v24_10),&(v23_5_tail));
    drop(v24_10);
    let v24_12: Space = unite(&(v24_8),&(v24_11));
    drop(v24_11);
    v23_5.join_into((v24_12).clone());
    }
    v23_5_cursor.ascend(1);
  }
  drop(v23_5_cursor);
  (v23_5).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
