#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[99,111,109,112,108,101,116,101,0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[101,100,103,101,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[112,97,116,104,0]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[100,101,108,116,97,0]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[99,111,109,112,108,101,116,101,0,112,97,116,104,0]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[100,101,108,116,97,0,112,97,116,104,0]));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Space) -> (Space,Space,Space,Space,Space,Space,Space,) {
    let v12_1: Space = unwrap(&((*capture_0)),&(*CONSTANT_0));
    let v12_2: Space = unwrap(&((*capture_0)),&(*CONSTANT_5));
    let v12_3: Space = unite(&(v12_1),&(v12_2));
    let v12_4: Space = wrap(&(v12_3),&(*CONSTANT_0));
    drop(v12_3);
    let v12_5: Space = unwrap(&(v12_1),&(*CONSTANT_1));
    let mut v12_6 = Space::new();
    let mut v12_6_cursor = (v12_5).read_zipper();
    for v12_6_byte in v12_6_cursor.child_mask().iter() {
      v12_6_cursor.descend_to_byte(v12_6_byte);
      {
      let v12_6_tail = v12_6_cursor.fork_read_zipper();
      let v12_6_head = Path::from_slice(&[v12_6_byte]);
      let v13_2: Space = singleton(&(v12_6_head));
      let v13_3: Space = intersect(&(*CONSTANT_3),&(v13_2));
      let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
      drop(v13_3);
      let v13_5: Space = subtract(&(*CONSTANT_2),&(v13_4));
      drop(v13_4);
      let v13_7: Space = if (v13_5).is_empty() { Space::new() } else {
        let mut v14_6 = Space::new();
        let mut v14_6_cursor = (v12_6_tail).read_zipper();
        for v14_6_byte in v14_6_cursor.child_mask().iter() {
          v14_6_cursor.descend_to_byte(v14_6_byte);
          {
          let v14_6_tail = v14_6_cursor.fork_read_zipper();
          let v14_6_head = Path::from_slice(&[v14_6_byte]);
          let v15_2: Space = singleton(&(v14_6_head));
          let v15_3: Space = intersect(&(*CONSTANT_3),&(v15_2));
          let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
          drop(v15_3);
          let v15_5: Space = subtract(&(*CONSTANT_2),&(v15_4));
          drop(v15_4);
          let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
            let v16_6: Path = concat_path(&(v12_6_head),&(v14_6_head));
            let v16_7: Space = routine_4(c, &(v16_6), &(v14_6_tail).make_space());
            compose(&(v15_5),&(v16_7))
          };
          drop(v15_5);
          let v15_9: Space = intersect(&(*CONSTANT_3),&(v15_2));
          drop(v15_2);
          let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
          drop(v15_9);
          let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
            let v17_6: Path = concat_path(&(v12_6_head),&(v14_6_head));
            let mut v17_11 = Space::new();
            let mut v17_11_cursor = (v14_6_tail).read_zipper();
            for v17_11_byte in v17_11_cursor.child_mask().iter() {
              v17_11_cursor.descend_to_byte(v17_11_byte);
              {
              let v17_11_tail = v17_11_cursor.fork_read_zipper();
              let v17_11_head = Path::from_slice(&[v17_11_byte]);
              let v18_2: Space = singleton(&(v17_11_head));
              let v18_3: Space = intersect(&(*CONSTANT_3),&(v18_2));
              let v18_4: Space = if has_head(&(v18_3)) { singleton(&[]) } else { Space::new() };
              drop(v18_3);
              let v18_5: Space = subtract(&(*CONSTANT_2),&(v18_4));
              drop(v18_4);
              let v18_7: Space = if (v18_5).is_empty() { Space::new() } else {
                let v19_6: Space = routine_5(c, &(v17_11_head), &(v17_6), &(v17_11_tail).make_space());
                compose(&(v18_5),&(v19_6))
              };
              drop(v18_5);
              let v18_8: Space = intersect(&(*CONSTANT_3),&(v18_2));
              drop(v18_2);
              let v18_9: Space = if has_head(&(v18_8)) { singleton(&[]) } else { Space::new() };
              drop(v18_8);
              let v18_11: Space = if (v18_9).is_empty() { Space::new() } else {
                let v20_10: Space = routine_6(c, &(v17_11_head), &(v17_6), &(v17_11_tail).make_space());
                compose(&(v18_9),&(v20_10))
              };
              drop(v18_9);
              let v18_12: Space = unite(&(v18_7),&(v18_11));
              v17_11.join_into((v18_12).clone());
              }
              v17_11_cursor.ascend(1);
            }
            drop(v17_11_cursor);
            drop(v17_6);
            compose(&(v15_10),&(v17_11))
          };
          drop(v15_10);
          let v15_13: Space = unite(&(v15_8),&(v15_12));
          v14_6.join_into((v15_13).clone());
          }
          v14_6_cursor.ascend(1);
        }
        drop(v14_6_cursor);
        compose(&(v13_5),&(v14_6))
      };
      drop(v13_5);
      let v13_8: Space = intersect(&(*CONSTANT_3),&(v13_2));
      drop(v13_2);
      let v13_9: Space = if has_head(&(v13_8)) { singleton(&[]) } else { Space::new() };
      drop(v13_8);
      let v13_11: Space = if (v13_9).is_empty() { Space::new() } else {
        let mut v21_10 = Space::new();
        let mut v21_10_cursor = (v12_6_tail).read_zipper();
        for v21_10_byte in v21_10_cursor.child_mask().iter() {
          v21_10_cursor.descend_to_byte(v21_10_byte);
          {
          let v21_10_tail = v21_10_cursor.fork_read_zipper();
          let v21_10_head = Path::from_slice(&[v21_10_byte]);
          let v22_2: Space = singleton(&(v21_10_head));
          let v22_3: Space = intersect(&(*CONSTANT_3),&(v22_2));
          let v22_4: Space = if has_head(&(v22_3)) { singleton(&[]) } else { Space::new() };
          drop(v22_3);
          let v22_5: Space = subtract(&(*CONSTANT_2),&(v22_4));
          drop(v22_4);
          let v22_7: Space = if (v22_5).is_empty() { Space::new() } else {
            let v23_6: Space = routine_5(c, &(v21_10_head), &(v12_6_head), &(v21_10_tail).make_space());
            compose(&(v22_5),&(v23_6))
          };
          drop(v22_5);
          let v22_8: Space = intersect(&(*CONSTANT_3),&(v22_2));
          drop(v22_2);
          let v22_9: Space = if has_head(&(v22_8)) { singleton(&[]) } else { Space::new() };
          drop(v22_8);
          let v22_10: Space = compose(&(v22_9),&(v21_10_tail));
          drop(v22_9);
          let v22_11: Space = wrap(&(v22_10),&(v21_10_head));
          drop(v22_10);
          let v22_12: Space = wrap(&(v22_11),&(v12_6_head));
          drop(v22_11);
          let v22_13: Space = unite(&(v22_7),&(v22_12));
          drop(v22_12);
          v21_10.join_into((v22_13).clone());
          }
          v21_10_cursor.ascend(1);
        }
        drop(v21_10_cursor);
        compose(&(v13_9),&(v21_10))
      };
      drop(v13_9);
      let v13_12: Space = unite(&(v13_7),&(v13_11));
      v12_6.join_into((v13_12).clone());
      }
      v12_6_cursor.ascend(1);
    }
    drop(v12_6_cursor);
    drop(v12_5);
    let v12_7: Space = unwrap(&(v12_1),&(*CONSTANT_4));
    drop(v12_1);
    let v12_8: Space = unwrap(&(v12_2),&(*CONSTANT_4));
    drop(v12_2);
    let mut v12_9 = Space::new();
    let mut v12_9_cursor = (v12_7).read_zipper();
    for v12_9_byte in v12_9_cursor.child_mask().iter() {
      v12_9_cursor.descend_to_byte(v12_9_byte);
      {
      let v12_9_tail = v12_9_cursor.fork_read_zipper();
      let v12_9_head = Path::from_slice(&[v12_9_byte]);
      let v24_2: Space = singleton(&(v12_9_head));
      let v24_3: Space = intersect(&(*CONSTANT_3),&(v24_2));
      let v24_4: Space = if has_head(&(v24_3)) { singleton(&[]) } else { Space::new() };
      drop(v24_3);
      let v24_5: Space = subtract(&(*CONSTANT_2),&(v24_4));
      drop(v24_4);
      let v24_7: Space = if (v24_5).is_empty() { Space::new() } else {
        let mut v25_6 = Space::new();
        let mut v25_6_cursor = (v12_9_tail).read_zipper();
        for v25_6_byte in v25_6_cursor.child_mask().iter() {
          v25_6_cursor.descend_to_byte(v25_6_byte);
          {
          let v25_6_tail = v25_6_cursor.fork_read_zipper();
          let v25_6_head = Path::from_slice(&[v25_6_byte]);
          let v26_2: Space = singleton(&(v25_6_head));
          let v26_3: Space = intersect(&(*CONSTANT_3),&(v26_2));
          let v26_4: Space = if has_head(&(v26_3)) { singleton(&[]) } else { Space::new() };
          drop(v26_3);
          let v26_5: Space = subtract(&(*CONSTANT_2),&(v26_4));
          drop(v26_4);
          let v26_8: Space = if (v26_5).is_empty() { Space::new() } else {
            let v27_6: Path = concat_path(&(v12_9_head),&(v25_6_head));
            let v27_7: Space = routine_7(c, &(v27_6), &(v25_6_tail).make_space(), &((*capture_0)));
            compose(&(v26_5),&(v27_7))
          };
          drop(v26_5);
          let v26_9: Space = intersect(&(*CONSTANT_3),&(v26_2));
          drop(v26_2);
          let v26_10: Space = if has_head(&(v26_9)) { singleton(&[]) } else { Space::new() };
          drop(v26_9);
          let v26_12: Space = if (v26_10).is_empty() { Space::new() } else {
            let v28_6: Path = concat_path(&(v12_9_head),&(v25_6_head));
            let mut v28_11 = Space::new();
            let mut v28_11_cursor = (v25_6_tail).read_zipper();
            for v28_11_byte in v28_11_cursor.child_mask().iter() {
              v28_11_cursor.descend_to_byte(v28_11_byte);
              {
              let v28_11_tail = v28_11_cursor.fork_read_zipper();
              let v28_11_head = Path::from_slice(&[v28_11_byte]);
              let v29_2: Space = singleton(&(v28_11_head));
              let v29_3: Space = intersect(&(*CONSTANT_3),&(v29_2));
              let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
              drop(v29_3);
              let v29_5: Space = subtract(&(*CONSTANT_2),&(v29_4));
              drop(v29_4);
              let v29_7: Space = if (v29_5).is_empty() { Space::new() } else {
                let v30_6: Space = routine_8(c, &(v28_11_head), &(v28_6), &(v28_11_tail).make_space(), &((*capture_0)));
                compose(&(v29_5),&(v30_6))
              };
              drop(v29_5);
              let v29_8: Space = intersect(&(*CONSTANT_3),&(v29_2));
              drop(v29_2);
              let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
              drop(v29_8);
              let v29_11: Space = if (v29_9).is_empty() { Space::new() } else {
                let v31_10: Space = routine_9(c, &(v28_11_head), &(v28_6), &(v28_11_tail).make_space(), &((*capture_0)));
                compose(&(v29_9),&(v31_10))
              };
              drop(v29_9);
              let v29_12: Space = unite(&(v29_7),&(v29_11));
              v28_11.join_into((v29_12).clone());
              }
              v28_11_cursor.ascend(1);
            }
            drop(v28_11_cursor);
            drop(v28_6);
            compose(&(v26_10),&(v28_11))
          };
          drop(v26_10);
          let v26_13: Space = unite(&(v26_8),&(v26_12));
          v25_6.join_into((v26_13).clone());
          }
          v25_6_cursor.ascend(1);
        }
        drop(v25_6_cursor);
        compose(&(v24_5),&(v25_6))
      };
      drop(v24_5);
      let v24_8: Space = intersect(&(*CONSTANT_3),&(v24_2));
      drop(v24_2);
      let v24_9: Space = if has_head(&(v24_8)) { singleton(&[]) } else { Space::new() };
      drop(v24_8);
      let v24_11: Space = if (v24_9).is_empty() { Space::new() } else {
        let mut v32_10 = Space::new();
        let mut v32_10_cursor = (v12_9_tail).read_zipper();
        for v32_10_byte in v32_10_cursor.child_mask().iter() {
          v32_10_cursor.descend_to_byte(v32_10_byte);
          {
          let v32_10_tail = v32_10_cursor.fork_read_zipper();
          let v32_10_head = Path::from_slice(&[v32_10_byte]);
          let v33_2: Space = singleton(&(v32_10_head));
          let v33_3: Space = intersect(&(*CONSTANT_3),&(v33_2));
          let v33_4: Space = if has_head(&(v33_3)) { singleton(&[]) } else { Space::new() };
          drop(v33_3);
          let v33_5: Space = subtract(&(*CONSTANT_2),&(v33_4));
          drop(v33_4);
          let v33_7: Space = if (v33_5).is_empty() { Space::new() } else {
            let v34_6: Space = routine_8(c, &(v32_10_head), &(v12_9_head), &(v32_10_tail).make_space(), &((*capture_0)));
            compose(&(v33_5),&(v34_6))
          };
          drop(v33_5);
          let v33_8: Space = intersect(&(*CONSTANT_3),&(v33_2));
          drop(v33_2);
          let v33_9: Space = if has_head(&(v33_8)) { singleton(&[]) } else { Space::new() };
          drop(v33_8);
          let v33_12: Space = if (v33_9).is_empty() { Space::new() } else {
            let v35_10: Space = unwrap(&(v12_8),&(v32_10_head));
            let mut v35_11 = Space::new();
            let mut v35_11_cursor = (v35_10).read_zipper();
            for v35_11_byte in v35_11_cursor.child_mask().iter() {
              v35_11_cursor.descend_to_byte(v35_11_byte);
              {
              let v35_11_tail = v35_11_cursor.fork_read_zipper();
              let v35_11_head = Path::from_slice(&[v35_11_byte]);
              let v36_2: Space = singleton(&(v35_11_head));
              let v36_3: Space = intersect(&(*CONSTANT_3),&(v36_2));
              let v36_4: Space = if has_head(&(v36_3)) { singleton(&[]) } else { Space::new() };
              drop(v36_3);
              let v36_5: Space = subtract(&(*CONSTANT_2),&(v36_4));
              drop(v36_4);
              let v36_7: Space = if (v36_5).is_empty() { Space::new() } else {
                let v37_6: Space = routine_10(c, &(v35_11_head), &(v12_9_head), &(v35_11_tail).make_space());
                compose(&(v36_5),&(v37_6))
              };
              drop(v36_5);
              let v36_8: Space = intersect(&(*CONSTANT_3),&(v36_2));
              drop(v36_2);
              let v36_9: Space = if has_head(&(v36_8)) { singleton(&[]) } else { Space::new() };
              drop(v36_8);
              let v36_11: Space = if (v36_9).is_empty() { Space::new() } else {
                let v38_10: Space = routine_11(c, &(v35_11_head), &(v12_9_head), &(v35_11_tail).make_space());
                compose(&(v36_9),&(v38_10))
              };
              drop(v36_9);
              let v36_12: Space = unite(&(v36_7),&(v36_11));
              v35_11.join_into((v36_12).clone());
              }
              v35_11_cursor.ascend(1);
            }
            drop(v35_11_cursor);
            drop(v35_10);
            compose(&(v33_9),&(v35_11))
          };
          drop(v33_9);
          let v33_13: Space = unite(&(v33_7),&(v33_12));
          v32_10.join_into((v33_13).clone());
          }
          v32_10_cursor.ascend(1);
        }
        drop(v32_10_cursor);
        compose(&(v24_9),&(v32_10))
      };
      drop(v24_9);
      let v24_12: Space = unite(&(v24_7),&(v24_11));
      v12_9.join_into((v24_12).clone());
      }
      v12_9_cursor.ascend(1);
    }
    drop(v12_9_cursor);
    let v12_10: Space = unite(&(v12_6),&(v12_9));
    let mut v12_11 = Space::new();
    let mut v12_11_cursor = (v12_8).read_zipper();
    for v12_11_byte in v12_11_cursor.child_mask().iter() {
      v12_11_cursor.descend_to_byte(v12_11_byte);
      {
      let v12_11_tail = v12_11_cursor.fork_read_zipper();
      let v12_11_head = Path::from_slice(&[v12_11_byte]);
      let v39_2: Space = singleton(&(v12_11_head));
      let v39_3: Space = intersect(&(*CONSTANT_3),&(v39_2));
      let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
      drop(v39_3);
      let v39_5: Space = subtract(&(*CONSTANT_2),&(v39_4));
      drop(v39_4);
      let v39_7: Space = if (v39_5).is_empty() { Space::new() } else {
        let mut v40_6 = Space::new();
        let mut v40_6_cursor = (v12_11_tail).read_zipper();
        for v40_6_byte in v40_6_cursor.child_mask().iter() {
          v40_6_cursor.descend_to_byte(v40_6_byte);
          {
          let v40_6_tail = v40_6_cursor.fork_read_zipper();
          let v40_6_head = Path::from_slice(&[v40_6_byte]);
          let v41_2: Space = singleton(&(v40_6_head));
          let v41_3: Space = intersect(&(*CONSTANT_3),&(v41_2));
          let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
          drop(v41_3);
          let v41_5: Space = subtract(&(*CONSTANT_2),&(v41_4));
          drop(v41_4);
          let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
            let v42_6: Path = concat_path(&(v12_11_head),&(v40_6_head));
            let v42_7: Space = routine_12(c, &(v42_6), &(v40_6_tail).make_space(), &((*capture_0)));
            compose(&(v41_5),&(v42_7))
          };
          drop(v41_5);
          let v41_9: Space = intersect(&(*CONSTANT_3),&(v41_2));
          drop(v41_2);
          let v41_10: Space = if has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
          drop(v41_9);
          let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
            let v43_6: Path = concat_path(&(v12_11_head),&(v40_6_head));
            let mut v43_11 = Space::new();
            let mut v43_11_cursor = (v40_6_tail).read_zipper();
            for v43_11_byte in v43_11_cursor.child_mask().iter() {
              v43_11_cursor.descend_to_byte(v43_11_byte);
              {
              let v43_11_tail = v43_11_cursor.fork_read_zipper();
              let v43_11_head = Path::from_slice(&[v43_11_byte]);
              let v44_2: Space = singleton(&(v43_11_head));
              let v44_3: Space = intersect(&(*CONSTANT_3),&(v44_2));
              let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
              drop(v44_3);
              let v44_5: Space = subtract(&(*CONSTANT_2),&(v44_4));
              drop(v44_4);
              let v44_7: Space = if (v44_5).is_empty() { Space::new() } else {
                let v45_6: Space = routine_13(c, &(v43_11_head), &(v43_6), &(v43_11_tail).make_space(), &((*capture_0)));
                compose(&(v44_5),&(v45_6))
              };
              drop(v44_5);
              let v44_8: Space = intersect(&(*CONSTANT_3),&(v44_2));
              drop(v44_2);
              let v44_9: Space = if has_head(&(v44_8)) { singleton(&[]) } else { Space::new() };
              drop(v44_8);
              let v44_11: Space = if (v44_9).is_empty() { Space::new() } else {
                let v46_10: Space = routine_14(c, &(v43_11_head), &(v43_6), &(v43_11_tail).make_space(), &((*capture_0)));
                compose(&(v44_9),&(v46_10))
              };
              drop(v44_9);
              let v44_12: Space = unite(&(v44_7),&(v44_11));
              v43_11.join_into((v44_12).clone());
              }
              v43_11_cursor.ascend(1);
            }
            drop(v43_11_cursor);
            drop(v43_6);
            compose(&(v41_10),&(v43_11))
          };
          drop(v41_10);
          let v41_13: Space = unite(&(v41_8),&(v41_12));
          v40_6.join_into((v41_13).clone());
          }
          v40_6_cursor.ascend(1);
        }
        drop(v40_6_cursor);
        compose(&(v39_5),&(v40_6))
      };
      drop(v39_5);
      let v39_8: Space = intersect(&(*CONSTANT_3),&(v39_2));
      drop(v39_2);
      let v39_9: Space = if has_head(&(v39_8)) { singleton(&[]) } else { Space::new() };
      drop(v39_8);
      let v39_11: Space = if (v39_9).is_empty() { Space::new() } else {
        let mut v47_10 = Space::new();
        let mut v47_10_cursor = (v12_11_tail).read_zipper();
        for v47_10_byte in v47_10_cursor.child_mask().iter() {
          v47_10_cursor.descend_to_byte(v47_10_byte);
          {
          let v47_10_tail = v47_10_cursor.fork_read_zipper();
          let v47_10_head = Path::from_slice(&[v47_10_byte]);
          let v48_2: Space = singleton(&(v47_10_head));
          let v48_3: Space = intersect(&(*CONSTANT_3),&(v48_2));
          let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
          drop(v48_3);
          let v48_5: Space = subtract(&(*CONSTANT_2),&(v48_4));
          drop(v48_4);
          let v48_7: Space = if (v48_5).is_empty() { Space::new() } else {
            let v49_6: Space = routine_13(c, &(v47_10_head), &(v12_11_head), &(v47_10_tail).make_space(), &((*capture_0)));
            compose(&(v48_5),&(v49_6))
          };
          drop(v48_5);
          let v48_8: Space = intersect(&(*CONSTANT_3),&(v48_2));
          drop(v48_2);
          let v48_9: Space = if has_head(&(v48_8)) { singleton(&[]) } else { Space::new() };
          drop(v48_8);
          let v48_12: Space = if (v48_9).is_empty() { Space::new() } else {
            let v50_10: Space = unwrap(&(v12_7),&(v47_10_head));
            let mut v50_11 = Space::new();
            let mut v50_11_cursor = (v50_10).read_zipper();
            for v50_11_byte in v50_11_cursor.child_mask().iter() {
              v50_11_cursor.descend_to_byte(v50_11_byte);
              {
              let v50_11_tail = v50_11_cursor.fork_read_zipper();
              let v50_11_head = Path::from_slice(&[v50_11_byte]);
              let v51_2: Space = singleton(&(v50_11_head));
              let v51_3: Space = intersect(&(*CONSTANT_3),&(v51_2));
              let v51_4: Space = if has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
              drop(v51_3);
              let v51_5: Space = subtract(&(*CONSTANT_2),&(v51_4));
              drop(v51_4);
              let v51_7: Space = if (v51_5).is_empty() { Space::new() } else {
                let v52_6: Space = routine_15(c, &(v50_11_head), &(v12_11_head), &(v50_11_tail).make_space());
                compose(&(v51_5),&(v52_6))
              };
              drop(v51_5);
              let v51_8: Space = intersect(&(*CONSTANT_3),&(v51_2));
              drop(v51_2);
              let v51_9: Space = if has_head(&(v51_8)) { singleton(&[]) } else { Space::new() };
              drop(v51_8);
              let v51_11: Space = if (v51_9).is_empty() { Space::new() } else {
                let v53_10: Space = routine_16(c, &(v50_11_head), &(v12_11_head), &(v50_11_tail).make_space());
                compose(&(v51_9),&(v53_10))
              };
              drop(v51_9);
              let v51_12: Space = unite(&(v51_7),&(v51_11));
              v50_11.join_into((v51_12).clone());
              }
              v50_11_cursor.ascend(1);
            }
            drop(v50_11_cursor);
            drop(v50_10);
            compose(&(v48_9),&(v50_11))
          };
          drop(v48_9);
          let v48_13: Space = unite(&(v48_7),&(v48_12));
          v47_10.join_into((v48_13).clone());
          }
          v47_10_cursor.ascend(1);
        }
        drop(v47_10_cursor);
        compose(&(v39_9),&(v47_10))
      };
      drop(v39_9);
      let v39_12: Space = unite(&(v39_7),&(v39_11));
      v12_11.join_into((v39_12).clone());
      }
      v12_11_cursor.ascend(1);
    }
    drop(v12_11_cursor);
    drop(v12_7);
    let v12_12: Space = unite(&(v12_10),&(v12_11));
    let mut v12_13 = Space::new();
    let mut v12_13_cursor = (v12_8).read_zipper();
    for v12_13_byte in v12_13_cursor.child_mask().iter() {
      v12_13_cursor.descend_to_byte(v12_13_byte);
      {
      let v12_13_tail = v12_13_cursor.fork_read_zipper();
      let v12_13_head = Path::from_slice(&[v12_13_byte]);
      let v54_2: Space = singleton(&(v12_13_head));
      let v54_3: Space = intersect(&(*CONSTANT_3),&(v54_2));
      let v54_4: Space = if has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
      drop(v54_3);
      let v54_5: Space = subtract(&(*CONSTANT_2),&(v54_4));
      drop(v54_4);
      let v54_7: Space = if (v54_5).is_empty() { Space::new() } else {
        let mut v55_6 = Space::new();
        let mut v55_6_cursor = (v12_13_tail).read_zipper();
        for v55_6_byte in v55_6_cursor.child_mask().iter() {
          v55_6_cursor.descend_to_byte(v55_6_byte);
          {
          let v55_6_tail = v55_6_cursor.fork_read_zipper();
          let v55_6_head = Path::from_slice(&[v55_6_byte]);
          let v56_2: Space = singleton(&(v55_6_head));
          let v56_3: Space = intersect(&(*CONSTANT_3),&(v56_2));
          let v56_4: Space = if has_head(&(v56_3)) { singleton(&[]) } else { Space::new() };
          drop(v56_3);
          let v56_5: Space = subtract(&(*CONSTANT_2),&(v56_4));
          drop(v56_4);
          let v56_8: Space = if (v56_5).is_empty() { Space::new() } else {
            let v57_6: Path = concat_path(&(v12_13_head),&(v55_6_head));
            let v57_7: Space = routine_17(c, &(v57_6), &(v55_6_tail).make_space(), &((*capture_0)));
            compose(&(v56_5),&(v57_7))
          };
          drop(v56_5);
          let v56_9: Space = intersect(&(*CONSTANT_3),&(v56_2));
          drop(v56_2);
          let v56_10: Space = if has_head(&(v56_9)) { singleton(&[]) } else { Space::new() };
          drop(v56_9);
          let v56_12: Space = if (v56_10).is_empty() { Space::new() } else {
            let v58_6: Path = concat_path(&(v12_13_head),&(v55_6_head));
            let mut v58_11 = Space::new();
            let mut v58_11_cursor = (v55_6_tail).read_zipper();
            for v58_11_byte in v58_11_cursor.child_mask().iter() {
              v58_11_cursor.descend_to_byte(v58_11_byte);
              {
              let v58_11_tail = v58_11_cursor.fork_read_zipper();
              let v58_11_head = Path::from_slice(&[v58_11_byte]);
              let v59_2: Space = singleton(&(v58_11_head));
              let v59_3: Space = intersect(&(*CONSTANT_3),&(v59_2));
              let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
              drop(v59_3);
              let v59_5: Space = subtract(&(*CONSTANT_2),&(v59_4));
              drop(v59_4);
              let v59_7: Space = if (v59_5).is_empty() { Space::new() } else {
                let v60_6: Space = routine_18(c, &(v58_11_head), &(v58_6), &(v58_11_tail).make_space(), &((*capture_0)));
                compose(&(v59_5),&(v60_6))
              };
              drop(v59_5);
              let v59_8: Space = intersect(&(*CONSTANT_3),&(v59_2));
              drop(v59_2);
              let v59_9: Space = if has_head(&(v59_8)) { singleton(&[]) } else { Space::new() };
              drop(v59_8);
              let v59_11: Space = if (v59_9).is_empty() { Space::new() } else {
                let v61_10: Space = routine_19(c, &(v58_11_head), &(v58_6), &(v58_11_tail).make_space(), &((*capture_0)));
                compose(&(v59_9),&(v61_10))
              };
              drop(v59_9);
              let v59_12: Space = unite(&(v59_7),&(v59_11));
              v58_11.join_into((v59_12).clone());
              }
              v58_11_cursor.ascend(1);
            }
            drop(v58_11_cursor);
            drop(v58_6);
            compose(&(v56_10),&(v58_11))
          };
          drop(v56_10);
          let v56_13: Space = unite(&(v56_8),&(v56_12));
          v55_6.join_into((v56_13).clone());
          }
          v55_6_cursor.ascend(1);
        }
        drop(v55_6_cursor);
        compose(&(v54_5),&(v55_6))
      };
      drop(v54_5);
      let v54_8: Space = intersect(&(*CONSTANT_3),&(v54_2));
      drop(v54_2);
      let v54_9: Space = if has_head(&(v54_8)) { singleton(&[]) } else { Space::new() };
      drop(v54_8);
      let v54_11: Space = if (v54_9).is_empty() { Space::new() } else {
        let mut v62_10 = Space::new();
        let mut v62_10_cursor = (v12_13_tail).read_zipper();
        for v62_10_byte in v62_10_cursor.child_mask().iter() {
          v62_10_cursor.descend_to_byte(v62_10_byte);
          {
          let v62_10_tail = v62_10_cursor.fork_read_zipper();
          let v62_10_head = Path::from_slice(&[v62_10_byte]);
          let v63_2: Space = singleton(&(v62_10_head));
          let v63_3: Space = intersect(&(*CONSTANT_3),&(v63_2));
          let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
          drop(v63_3);
          let v63_5: Space = subtract(&(*CONSTANT_2),&(v63_4));
          drop(v63_4);
          let v63_7: Space = if (v63_5).is_empty() { Space::new() } else {
            let v64_6: Space = routine_18(c, &(v62_10_head), &(v12_13_head), &(v62_10_tail).make_space(), &((*capture_0)));
            compose(&(v63_5),&(v64_6))
          };
          drop(v63_5);
          let v63_8: Space = intersect(&(*CONSTANT_3),&(v63_2));
          drop(v63_2);
          let v63_9: Space = if has_head(&(v63_8)) { singleton(&[]) } else { Space::new() };
          drop(v63_8);
          let v63_12: Space = if (v63_9).is_empty() { Space::new() } else {
            let v65_10: Space = unwrap(&(v12_8),&(v62_10_head));
            let mut v65_11 = Space::new();
            let mut v65_11_cursor = (v65_10).read_zipper();
            for v65_11_byte in v65_11_cursor.child_mask().iter() {
              v65_11_cursor.descend_to_byte(v65_11_byte);
              {
              let v65_11_tail = v65_11_cursor.fork_read_zipper();
              let v65_11_head = Path::from_slice(&[v65_11_byte]);
              let v66_2: Space = singleton(&(v65_11_head));
              let v66_3: Space = intersect(&(*CONSTANT_3),&(v66_2));
              let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
              drop(v66_3);
              let v66_5: Space = subtract(&(*CONSTANT_2),&(v66_4));
              drop(v66_4);
              let v66_7: Space = if (v66_5).is_empty() { Space::new() } else {
                let v67_6: Space = routine_20(c, &(v65_11_head), &(v12_13_head), &(v65_11_tail).make_space());
                compose(&(v66_5),&(v67_6))
              };
              drop(v66_5);
              let v66_8: Space = intersect(&(*CONSTANT_3),&(v66_2));
              drop(v66_2);
              let v66_9: Space = if has_head(&(v66_8)) { singleton(&[]) } else { Space::new() };
              drop(v66_8);
              let v66_11: Space = if (v66_9).is_empty() { Space::new() } else {
                let v68_10: Space = routine_21(c, &(v65_11_head), &(v12_13_head), &(v65_11_tail).make_space());
                compose(&(v66_9),&(v68_10))
              };
              drop(v66_9);
              let v66_12: Space = unite(&(v66_7),&(v66_11));
              v65_11.join_into((v66_12).clone());
              }
              v65_11_cursor.ascend(1);
            }
            drop(v65_11_cursor);
            drop(v65_10);
            compose(&(v63_9),&(v65_11))
          };
          drop(v63_9);
          let v63_13: Space = unite(&(v63_7),&(v63_12));
          v62_10.join_into((v63_13).clone());
          }
          v62_10_cursor.ascend(1);
        }
        drop(v62_10_cursor);
        compose(&(v54_9),&(v62_10))
      };
      drop(v54_9);
      let v54_12: Space = unite(&(v54_7),&(v54_11));
      v12_13.join_into((v54_12).clone());
      }
      v12_13_cursor.ascend(1);
    }
    drop(v12_13_cursor);
    drop(v12_8);

((v12_10).clone(),(v12_11).clone(),(v12_12).clone(),(v12_13).clone(),(v12_4).clone(),(v12_6).clone(),(v12_9).clone(),)
}

fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = wrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let v0_4: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_1));
  let mut v0_18 = Space::new();
  let mut v0_18_cursor = (v0_4).read_zipper();
  for v0_18_byte in v0_18_cursor.child_mask().iter() {
    v0_18_cursor.descend_to_byte(v0_18_byte);
    {
    let v0_18_tail = v0_18_cursor.fork_read_zipper();
    let v0_18_head = Path::from_slice(&[v0_18_byte]);
    let v1_2: Space = singleton(&(v0_18_head));
    let v1_3: Space = intersect(&(*CONSTANT_3),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_2),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_18_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_3),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_2),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_18_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail).make_space());
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_3),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_18_head),&(v2_6_head));
          let mut v5_11 = Space::new();
          let mut v5_11_cursor = (v2_6_tail).read_zipper();
          for v5_11_byte in v5_11_cursor.child_mask().iter() {
            v5_11_cursor.descend_to_byte(v5_11_byte);
            {
            let v5_11_tail = v5_11_cursor.fork_read_zipper();
            let v5_11_head = Path::from_slice(&[v5_11_byte]);
            let v6_2: Space = singleton(&(v5_11_head));
            let v6_3: Space = intersect(&(*CONSTANT_3),&(v6_2));
            let v6_4: Space = if has_head(&(v6_3)) { singleton(&[]) } else { Space::new() };
            drop(v6_3);
            let v6_5: Space = subtract(&(*CONSTANT_2),&(v6_4));
            drop(v6_4);
            let v6_7: Space = if (v6_5).is_empty() { Space::new() } else {
              let v7_6: Space = routine_2(c, &(v5_11_head), &(v5_6), &(v5_11_tail).make_space());
              compose(&(v6_5),&(v7_6))
            };
            drop(v6_5);
            let v6_8: Space = intersect(&(*CONSTANT_3),&(v6_2));
            drop(v6_2);
            let v6_9: Space = if has_head(&(v6_8)) { singleton(&[]) } else { Space::new() };
            drop(v6_8);
            let v6_11: Space = if (v6_9).is_empty() { Space::new() } else {
              let v8_10: Space = routine_3(c, &(v5_11_head), &(v5_6), &(v5_11_tail).make_space());
              compose(&(v6_9),&(v8_10))
            };
            drop(v6_9);
            let v6_12: Space = unite(&(v6_7),&(v6_11));
            v5_11.join_into((v6_12).clone());
            }
            v5_11_cursor.ascend(1);
          }
          drop(v5_11_cursor);
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_3),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v9_10 = Space::new();
      let mut v9_10_cursor = (v0_18_tail).read_zipper();
      for v9_10_byte in v9_10_cursor.child_mask().iter() {
        v9_10_cursor.descend_to_byte(v9_10_byte);
        {
        let v9_10_tail = v9_10_cursor.fork_read_zipper();
        let v9_10_head = Path::from_slice(&[v9_10_byte]);
        let v10_2: Space = singleton(&(v9_10_head));
        let v10_3: Space = intersect(&(*CONSTANT_3),&(v10_2));
        let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
        drop(v10_3);
        let v10_5: Space = compose(&(v10_4),&(v9_10_tail));
        drop(v10_4);
        let v10_6: Space = wrap(&(v10_5),&(v9_10_head));
        drop(v10_5);
        let v10_7: Space = wrap(&(v10_6),&(v0_18_head));
        drop(v10_6);
        let v10_8: Space = wrap(&(v10_7),&(*CONSTANT_4));
        drop(v10_7);
        let v10_9: Space = intersect(&(*CONSTANT_3),&(v10_2));
        drop(v10_2);
        let v10_10: Space = if has_head(&(v10_9)) { singleton(&[]) } else { Space::new() };
        drop(v10_9);
        let v10_11: Space = subtract(&(*CONSTANT_2),&(v10_10));
        drop(v10_10);
        let v10_13: Space = if (v10_11).is_empty() { Space::new() } else {
          let v11_12: Space = routine_2(c, &(v9_10_head), &(v0_18_head), &(v9_10_tail).make_space());
          compose(&(v10_11),&(v11_12))
        };
        drop(v10_11);
        let v10_14: Space = unite(&(v10_8),&(v10_13));
        drop(v10_8);
        v9_10.join_into((v10_14).clone());
        }
        v9_10_cursor.ascend(1);
      }
      drop(v9_10_cursor);
      compose(&(v1_9),&(v9_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_18.join_into((v1_12).clone());
    }
    v0_18_cursor.ascend(1);
  }
  drop(v0_18_cursor);
  drop(v0_4);
  let v0_20: Space = wrap(&(v0_18),&(*CONSTANT_5));
  let v0_21: Space = unite(&(v0_2),&(v0_20));
  drop(v0_2);
  let mut v0_81: Space = (v0_21).clone();
  loop {
    let (v12_10,v12_11,v12_12,v12_13,v12_4,v12_6,v12_9,) = native_block_0(c, &v0_81);
    let v12_14: Space = unite(&(v12_12),&(v12_13));
    let v12_15: Space = unwrap(&(v0_81),&(*CONSTANT_6));
    let v12_16: Space = subtract(&(v12_14),&(v12_15));
    drop(v12_15);
    let v12_17: Space = unwrap(&(v0_81),&(*CONSTANT_7));
    let v12_18: Space = subtract(&(v12_16),&(v12_17));
    drop(v12_17);
    let v12_19: Space = wrap(&(v12_18),&(*CONSTANT_7));
    let v12_20: Space = unite(&(v12_4),&(v12_19));
    drop(v12_4);
    let v12_21: Space = unite(&(v12_20),&(v0_81));
    if !v0_81.join_into((v12_21).clone()).is_element() { break; }
  }
  let v0_82: Space = unwrap(&(v0_81),&(*CONSTANT_6));
  (v0_82).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v69_9 = Space::new();
  let mut v69_9_cursor = (*s0).read_zipper();
  for v69_9_byte in v69_9_cursor.child_mask().iter() {
    v69_9_cursor.descend_to_byte(v69_9_byte);
    {
    let v69_9_tail = v69_9_cursor.fork_read_zipper();
    let v69_9_head = Path::from_slice(&[v69_9_byte]);
    let v70_2: Space = singleton(&(v69_9_head));
    let v70_3: Space = intersect(&(*CONSTANT_3),&(v70_2));
    let v70_4: Space = if has_head(&(v70_3)) { singleton(&[]) } else { Space::new() };
    drop(v70_3);
    let v70_5: Space = subtract(&(*CONSTANT_2),&(v70_4));
    drop(v70_4);
    let v70_8: Space = if (v70_5).is_empty() { Space::new() } else {
      let v71_6: Path = concat_path(&(*p0),&(v69_9_head));
      let v71_7: Space = routine_1(c, &(v71_6), &(v69_9_tail).make_space());
      compose(&(v70_5),&(v71_7))
    };
    drop(v70_5);
    let v70_9: Space = intersect(&(*CONSTANT_3),&(v70_2));
    drop(v70_2);
    let v70_10: Space = if has_head(&(v70_9)) { singleton(&[]) } else { Space::new() };
    drop(v70_9);
    let v70_12: Space = if (v70_10).is_empty() { Space::new() } else {
      let v72_6: Path = concat_path(&(*p0),&(v69_9_head));
      let mut v72_11 = Space::new();
      let mut v72_11_cursor = (v69_9_tail).read_zipper();
      for v72_11_byte in v72_11_cursor.child_mask().iter() {
        v72_11_cursor.descend_to_byte(v72_11_byte);
        {
        let v72_11_tail = v72_11_cursor.fork_read_zipper();
        let v72_11_head = Path::from_slice(&[v72_11_byte]);
        let v73_2: Space = singleton(&(v72_11_head));
        let v73_3: Space = intersect(&(*CONSTANT_3),&(v73_2));
        let v73_4: Space = if has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
        drop(v73_3);
        let v73_5: Space = compose(&(v73_4),&(v72_11_tail));
        drop(v73_4);
        let v73_6: Space = wrap(&(v73_5),&(v72_11_head));
        drop(v73_5);
        let v73_7: Space = wrap(&(v73_6),&(v72_6));
        drop(v73_6);
        let v73_8: Space = wrap(&(v73_7),&(*CONSTANT_4));
        drop(v73_7);
        let v73_9: Space = intersect(&(*CONSTANT_3),&(v73_2));
        drop(v73_2);
        let v73_10: Space = if has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
        drop(v73_9);
        let v73_11: Space = subtract(&(*CONSTANT_2),&(v73_10));
        drop(v73_10);
        let v73_13: Space = if (v73_11).is_empty() { Space::new() } else {
          let v74_12: Space = routine_2(c, &(v72_11_head), &(v72_6), &(v72_11_tail).make_space());
          compose(&(v73_11),&(v74_12))
        };
        drop(v73_11);
        let v73_14: Space = unite(&(v73_8),&(v73_13));
        drop(v73_8);
        v72_11.join_into((v73_14).clone());
        }
        v72_11_cursor.ascend(1);
      }
      drop(v72_11_cursor);
      drop(v72_6);
      compose(&(v70_10),&(v72_11))
    };
    drop(v70_10);
    let v70_13: Space = unite(&(v70_8),&(v70_12));
    v69_9.join_into((v70_13).clone());
    }
    v69_9_cursor.ascend(1);
  }
  drop(v69_9_cursor);
  (v69_9).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v75_7 = Space::new();
  let mut v75_7_cursor = (*s0).read_zipper();
  for v75_7_byte in v75_7_cursor.child_mask().iter() {
    v75_7_cursor.descend_to_byte(v75_7_byte);
    {
    let v75_7_tail = v75_7_cursor.fork_read_zipper();
    let v75_7_head = Path::from_slice(&[v75_7_byte]);
    let v76_2: Space = singleton(&(v75_7_head));
    let v76_3: Space = intersect(&(*CONSTANT_3),&(v76_2));
    let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
    drop(v76_3);
    let v76_5: Space = compose(&(v76_4),&(v75_7_tail));
    drop(v76_4);
    let v77_6: Path = concat_path(&(*p0),&(v75_7_head));
    let v76_7: Space = wrap(&(v76_5),&(v77_6));
    drop(v76_5);
    let v76_8: Space = wrap(&(v76_7),&(*p1));
    drop(v76_7);
    let v76_9: Space = wrap(&(v76_8),&(*CONSTANT_4));
    drop(v76_8);
    let v76_10: Space = intersect(&(*CONSTANT_3),&(v76_2));
    drop(v76_2);
    let v76_11: Space = if has_head(&(v76_10)) { singleton(&[]) } else { Space::new() };
    drop(v76_10);
    let v76_12: Space = subtract(&(*CONSTANT_2),&(v76_11));
    drop(v76_11);
    let v76_14: Space = if (v76_12).is_empty() { Space::new() } else {
      let v78_13: Space = routine_2(c, &(v77_6), &(*p1), &(v75_7_tail).make_space());
      compose(&(v76_12),&(v78_13))
    };
    drop(v76_12);
    let v76_15: Space = unite(&(v76_9),&(v76_14));
    drop(v76_9);
    v75_7.join_into((v76_15).clone());
    }
    v75_7_cursor.ascend(1);
  }
  drop(v75_7_cursor);
  (v75_7).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v79_3: Space = wrap(&(*s0),&(*p0));
  let v79_4: Space = wrap(&(v79_3),&(*p1));
  drop(v79_3);
  let v79_6: Space = wrap(&(v79_4),&(*CONSTANT_4));
  drop(v79_4);
  (v79_6).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v80_8 = Space::new();
  let mut v80_8_cursor = (*s0).read_zipper();
  for v80_8_byte in v80_8_cursor.child_mask().iter() {
    v80_8_cursor.descend_to_byte(v80_8_byte);
    {
    let v80_8_tail = v80_8_cursor.fork_read_zipper();
    let v80_8_head = Path::from_slice(&[v80_8_byte]);
    let v81_2: Space = singleton(&(v80_8_head));
    let v81_3: Space = intersect(&(*CONSTANT_3),&(v81_2));
    let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
    drop(v81_3);
    let v81_5: Space = subtract(&(*CONSTANT_2),&(v81_4));
    drop(v81_4);
    let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
      let v82_6: Path = concat_path(&(*p0),&(v80_8_head));
      let v82_7: Space = routine_4(c, &(v82_6), &(v80_8_tail).make_space());
      compose(&(v81_5),&(v82_7))
    };
    drop(v81_5);
    let v81_9: Space = intersect(&(*CONSTANT_3),&(v81_2));
    drop(v81_2);
    let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
    drop(v81_9);
    let v81_12: Space = if (v81_10).is_empty() { Space::new() } else {
      let v83_6: Path = concat_path(&(*p0),&(v80_8_head));
      let mut v83_11 = Space::new();
      let mut v83_11_cursor = (v80_8_tail).read_zipper();
      for v83_11_byte in v83_11_cursor.child_mask().iter() {
        v83_11_cursor.descend_to_byte(v83_11_byte);
        {
        let v83_11_tail = v83_11_cursor.fork_read_zipper();
        let v83_11_head = Path::from_slice(&[v83_11_byte]);
        let v84_2: Space = singleton(&(v83_11_head));
        let v84_3: Space = intersect(&(*CONSTANT_3),&(v84_2));
        let v84_4: Space = if has_head(&(v84_3)) { singleton(&[]) } else { Space::new() };
        drop(v84_3);
        let v84_5: Space = subtract(&(*CONSTANT_2),&(v84_4));
        drop(v84_4);
        let v84_7: Space = if (v84_5).is_empty() { Space::new() } else {
          let v85_6: Space = routine_5(c, &(v83_11_head), &(v83_6), &(v83_11_tail).make_space());
          compose(&(v84_5),&(v85_6))
        };
        drop(v84_5);
        let v84_8: Space = intersect(&(*CONSTANT_3),&(v84_2));
        drop(v84_2);
        let v84_9: Space = if has_head(&(v84_8)) { singleton(&[]) } else { Space::new() };
        drop(v84_8);
        let v84_10: Space = compose(&(v84_9),&(v83_11_tail));
        drop(v84_9);
        let v84_11: Space = wrap(&(v84_10),&(v83_11_head));
        drop(v84_10);
        let v84_12: Space = wrap(&(v84_11),&(v83_6));
        drop(v84_11);
        let v84_13: Space = unite(&(v84_7),&(v84_12));
        drop(v84_12);
        v83_11.join_into((v84_13).clone());
        }
        v83_11_cursor.ascend(1);
      }
      drop(v83_11_cursor);
      drop(v83_6);
      compose(&(v81_10),&(v83_11))
    };
    drop(v81_10);
    let v81_13: Space = unite(&(v81_8),&(v81_12));
    v80_8.join_into((v81_13).clone());
    }
    v80_8_cursor.ascend(1);
  }
  drop(v80_8_cursor);
  (v80_8).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v86_6 = Space::new();
  let mut v86_6_cursor = (*s0).read_zipper();
  for v86_6_byte in v86_6_cursor.child_mask().iter() {
    v86_6_cursor.descend_to_byte(v86_6_byte);
    {
    let v86_6_tail = v86_6_cursor.fork_read_zipper();
    let v86_6_head = Path::from_slice(&[v86_6_byte]);
    let v87_2: Space = singleton(&(v86_6_head));
    let v87_3: Space = intersect(&(*CONSTANT_3),&(v87_2));
    let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
    drop(v87_3);
    let v87_5: Space = subtract(&(*CONSTANT_2),&(v87_4));
    drop(v87_4);
    let v87_8: Space = if (v87_5).is_empty() { Space::new() } else {
      let v88_6: Path = concat_path(&(*p0),&(v86_6_head));
      let v88_7: Space = routine_5(c, &(v88_6), &(*p1), &(v86_6_tail).make_space());
      compose(&(v87_5),&(v88_7))
    };
    drop(v87_5);
    let v87_9: Space = intersect(&(*CONSTANT_3),&(v87_2));
    drop(v87_2);
    let v87_10: Space = if has_head(&(v87_9)) { singleton(&[]) } else { Space::new() };
    drop(v87_9);
    let v87_11: Space = compose(&(v87_10),&(v86_6_tail));
    drop(v87_10);
    let v89_6: Path = concat_path(&(*p0),&(v86_6_head));
    let v87_12: Space = wrap(&(v87_11),&(v89_6));
    drop(v87_11);
    let v87_13: Space = wrap(&(v87_12),&(*p1));
    drop(v87_12);
    let v87_14: Space = unite(&(v87_8),&(v87_13));
    drop(v87_13);
    v86_6.join_into((v87_14).clone());
    }
    v86_6_cursor.ascend(1);
  }
  drop(v86_6_cursor);
  (v86_6).clone()
}

fn routine_6(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v90_3: Space = wrap(&(*s0),&(*p0));
  let v90_4: Space = wrap(&(v90_3),&(*p1));
  drop(v90_3);
  (v90_4).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v91_11: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let v91_12: Space = unwrap(&(v91_11),&(*CONSTANT_4));
  drop(v91_11);
  let mut v91_16 = Space::new();
  let mut v91_16_cursor = (*s0).read_zipper();
  for v91_16_byte in v91_16_cursor.child_mask().iter() {
    v91_16_cursor.descend_to_byte(v91_16_byte);
    {
    let v91_16_tail = v91_16_cursor.fork_read_zipper();
    let v91_16_head = Path::from_slice(&[v91_16_byte]);
    let v92_2: Space = singleton(&(v91_16_head));
    let v92_3: Space = intersect(&(*CONSTANT_3),&(v92_2));
    let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
    drop(v92_3);
    let v92_5: Space = subtract(&(*CONSTANT_2),&(v92_4));
    drop(v92_4);
    let v92_8: Space = if (v92_5).is_empty() { Space::new() } else {
      let v93_6: Path = concat_path(&(*p0),&(v91_16_head));
      let v93_7: Space = routine_7(c, &(v93_6), &(v91_16_tail).make_space(), &(*s1));
      compose(&(v92_5),&(v93_7))
    };
    drop(v92_5);
    let v92_9: Space = intersect(&(*CONSTANT_3),&(v92_2));
    drop(v92_2);
    let v92_10: Space = if has_head(&(v92_9)) { singleton(&[]) } else { Space::new() };
    drop(v92_9);
    let v92_12: Space = if (v92_10).is_empty() { Space::new() } else {
      let v94_6: Path = concat_path(&(*p0),&(v91_16_head));
      let mut v94_11 = Space::new();
      let mut v94_11_cursor = (v91_16_tail).read_zipper();
      for v94_11_byte in v94_11_cursor.child_mask().iter() {
        v94_11_cursor.descend_to_byte(v94_11_byte);
        {
        let v94_11_tail = v94_11_cursor.fork_read_zipper();
        let v94_11_head = Path::from_slice(&[v94_11_byte]);
        let v95_2: Space = singleton(&(v94_11_head));
        let v95_3: Space = intersect(&(*CONSTANT_3),&(v95_2));
        let v95_4: Space = if has_head(&(v95_3)) { singleton(&[]) } else { Space::new() };
        drop(v95_3);
        let v95_5: Space = subtract(&(*CONSTANT_2),&(v95_4));
        drop(v95_4);
        let v95_7: Space = if (v95_5).is_empty() { Space::new() } else {
          let v96_6: Space = routine_8(c, &(v94_11_head), &(v94_6), &(v94_11_tail).make_space(), &(*s1));
          compose(&(v95_5),&(v96_6))
        };
        drop(v95_5);
        let v95_8: Space = intersect(&(*CONSTANT_3),&(v95_2));
        drop(v95_2);
        let v95_9: Space = if has_head(&(v95_8)) { singleton(&[]) } else { Space::new() };
        drop(v95_8);
        let v95_12: Space = if (v95_9).is_empty() { Space::new() } else {
          let v97_10: Space = unwrap(&(v91_12),&(v94_11_head));
          let mut v97_11 = Space::new();
          let mut v97_11_cursor = (v97_10).read_zipper();
          for v97_11_byte in v97_11_cursor.child_mask().iter() {
            v97_11_cursor.descend_to_byte(v97_11_byte);
            {
            let v97_11_tail = v97_11_cursor.fork_read_zipper();
            let v97_11_head = Path::from_slice(&[v97_11_byte]);
            let v98_2: Space = singleton(&(v97_11_head));
            let v98_3: Space = intersect(&(*CONSTANT_3),&(v98_2));
            let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
            drop(v98_3);
            let v98_5: Space = subtract(&(*CONSTANT_2),&(v98_4));
            drop(v98_4);
            let v98_7: Space = if (v98_5).is_empty() { Space::new() } else {
              let v99_6: Space = routine_10(c, &(v97_11_head), &(v94_6), &(v97_11_tail).make_space());
              compose(&(v98_5),&(v99_6))
            };
            drop(v98_5);
            let v98_8: Space = intersect(&(*CONSTANT_3),&(v98_2));
            drop(v98_2);
            let v98_9: Space = if has_head(&(v98_8)) { singleton(&[]) } else { Space::new() };
            drop(v98_8);
            let v98_11: Space = if (v98_9).is_empty() { Space::new() } else {
              let v100_10: Space = routine_11(c, &(v97_11_head), &(v94_6), &(v97_11_tail).make_space());
              compose(&(v98_9),&(v100_10))
            };
            drop(v98_9);
            let v98_12: Space = unite(&(v98_7),&(v98_11));
            v97_11.join_into((v98_12).clone());
            }
            v97_11_cursor.ascend(1);
          }
          drop(v97_11_cursor);
          drop(v97_10);
          compose(&(v95_9),&(v97_11))
        };
        drop(v95_9);
        let v95_13: Space = unite(&(v95_7),&(v95_12));
        v94_11.join_into((v95_13).clone());
        }
        v94_11_cursor.ascend(1);
      }
      drop(v94_11_cursor);
      drop(v94_6);
      compose(&(v92_10),&(v94_11))
    };
    drop(v92_10);
    let v92_13: Space = unite(&(v92_8),&(v92_12));
    v91_16.join_into((v92_13).clone());
    }
    v91_16_cursor.ascend(1);
  }
  drop(v91_16_cursor);
  drop(v91_12);
  (v91_16).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v101_8: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let v101_10: Space = unwrap(&(v101_8),&(*CONSTANT_4));
  drop(v101_8);
  let v101_11: Space = unwrap(&(v101_10),&(*p0));
  drop(v101_10);
  let mut v101_15 = Space::new();
  let mut v101_15_cursor = (*s0).read_zipper();
  for v101_15_byte in v101_15_cursor.child_mask().iter() {
    v101_15_cursor.descend_to_byte(v101_15_byte);
    {
    let v101_15_tail = v101_15_cursor.fork_read_zipper();
    let v101_15_head = Path::from_slice(&[v101_15_byte]);
    let v102_2: Space = singleton(&(v101_15_head));
    let v102_3: Space = intersect(&(*CONSTANT_3),&(v102_2));
    let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
    drop(v102_3);
    let v102_5: Space = subtract(&(*CONSTANT_2),&(v102_4));
    drop(v102_4);
    let v102_8: Space = if (v102_5).is_empty() { Space::new() } else {
      let v103_6: Path = concat_path(&(*p0),&(v101_15_head));
      let v103_7: Space = routine_8(c, &(v103_6), &(*p1), &(v101_15_tail).make_space(), &(*s1));
      drop(v103_6);
      compose(&(v102_5),&(v103_7))
    };
    drop(v102_5);
    let v102_9: Space = intersect(&(*CONSTANT_3),&(v102_2));
    drop(v102_2);
    let v102_10: Space = if has_head(&(v102_9)) { singleton(&[]) } else { Space::new() };
    drop(v102_9);
    let v102_13: Space = if (v102_10).is_empty() { Space::new() } else {
      let v104_11: Space = unwrap(&(v101_11),&(v101_15_head));
      let mut v104_12 = Space::new();
      let mut v104_12_cursor = (v104_11).read_zipper();
      for v104_12_byte in v104_12_cursor.child_mask().iter() {
        v104_12_cursor.descend_to_byte(v104_12_byte);
        {
        let v104_12_tail = v104_12_cursor.fork_read_zipper();
        let v104_12_head = Path::from_slice(&[v104_12_byte]);
        let v105_2: Space = singleton(&(v104_12_head));
        let v105_3: Space = intersect(&(*CONSTANT_3),&(v105_2));
        let v105_4: Space = if has_head(&(v105_3)) { singleton(&[]) } else { Space::new() };
        drop(v105_3);
        let v105_5: Space = subtract(&(*CONSTANT_2),&(v105_4));
        drop(v105_4);
        let v105_7: Space = if (v105_5).is_empty() { Space::new() } else {
          let v106_6: Space = routine_10(c, &(v104_12_head), &(*p1), &(v104_12_tail).make_space());
          compose(&(v105_5),&(v106_6))
        };
        drop(v105_5);
        let v105_8: Space = intersect(&(*CONSTANT_3),&(v105_2));
        drop(v105_2);
        let v105_9: Space = if has_head(&(v105_8)) { singleton(&[]) } else { Space::new() };
        drop(v105_8);
        let v105_10: Space = compose(&(v105_9),&(v104_12_tail));
        drop(v105_9);
        let v105_11: Space = wrap(&(v105_10),&(v104_12_head));
        drop(v105_10);
        let v105_12: Space = wrap(&(v105_11),&(*p1));
        drop(v105_11);
        let v105_13: Space = unite(&(v105_7),&(v105_12));
        drop(v105_12);
        v104_12.join_into((v105_13).clone());
        }
        v104_12_cursor.ascend(1);
      }
      drop(v104_12_cursor);
      drop(v104_11);
      compose(&(v102_10),&(v104_12))
    };
    drop(v102_10);
    let v102_14: Space = unite(&(v102_8),&(v102_13));
    v101_15.join_into((v102_14).clone());
    }
    v101_15_cursor.ascend(1);
  }
  drop(v101_15_cursor);
  drop(v101_11);
  (v101_15).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v107_5: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let v107_7: Space = unwrap(&(v107_5),&(*CONSTANT_4));
  drop(v107_5);
  let v107_8: Space = unwrap(&(v107_7),&(*p0));
  drop(v107_7);
  let mut v107_15 = Space::new();
  let mut v107_15_cursor = (v107_8).read_zipper();
  for v107_15_byte in v107_15_cursor.child_mask().iter() {
    v107_15_cursor.descend_to_byte(v107_15_byte);
    {
    let v107_15_tail = v107_15_cursor.fork_read_zipper();
    let v107_15_head = Path::from_slice(&[v107_15_byte]);
    let v108_2: Space = singleton(&(v107_15_head));
    let v108_3: Space = intersect(&(*CONSTANT_3),&(v108_2));
    let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
    drop(v108_3);
    let v108_5: Space = subtract(&(*CONSTANT_2),&(v108_4));
    drop(v108_4);
    let v108_7: Space = if (v108_5).is_empty() { Space::new() } else {
      let mut v109_6 = Space::new();
      let mut v109_6_cursor = (v107_15_tail).read_zipper();
      for v109_6_byte in v109_6_cursor.child_mask().iter() {
        v109_6_cursor.descend_to_byte(v109_6_byte);
        {
        let v109_6_tail = v109_6_cursor.fork_read_zipper();
        let v109_6_head = Path::from_slice(&[v109_6_byte]);
        let v110_2: Space = singleton(&(v109_6_head));
        let v110_3: Space = intersect(&(*CONSTANT_3),&(v110_2));
        let v110_4: Space = if has_head(&(v110_3)) { singleton(&[]) } else { Space::new() };
        drop(v110_3);
        let v110_5: Space = subtract(&(*CONSTANT_2),&(v110_4));
        drop(v110_4);
        let v110_8: Space = if (v110_5).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v107_15_head),&(v109_6_head));
          let v111_7: Space = routine_10(c, &(v111_6), &(*p1), &(v109_6_tail).make_space());
          compose(&(v110_5),&(v111_7))
        };
        drop(v110_5);
        let v110_9: Space = intersect(&(*CONSTANT_3),&(v110_2));
        drop(v110_2);
        let v110_10: Space = if has_head(&(v110_9)) { singleton(&[]) } else { Space::new() };
        drop(v110_9);
        let v110_11: Space = compose(&(v110_10),&(v109_6_tail));
        drop(v110_10);
        let v112_6: Path = concat_path(&(v107_15_head),&(v109_6_head));
        let v110_12: Space = wrap(&(v110_11),&(v112_6));
        drop(v110_11);
        let v110_13: Space = wrap(&(v110_12),&(*p1));
        drop(v110_12);
        let v110_14: Space = unite(&(v110_8),&(v110_13));
        drop(v110_13);
        v109_6.join_into((v110_14).clone());
        }
        v109_6_cursor.ascend(1);
      }
      drop(v109_6_cursor);
      compose(&(v108_5),&(v109_6))
    };
    drop(v108_5);
    let v108_8: Space = intersect(&(*CONSTANT_3),&(v108_2));
    drop(v108_2);
    let v108_9: Space = if has_head(&(v108_8)) { singleton(&[]) } else { Space::new() };
    drop(v108_8);
    let v108_10: Space = compose(&(v108_9),&(v107_15_tail));
    drop(v108_9);
    let v108_11: Space = wrap(&(v108_10),&(v107_15_head));
    drop(v108_10);
    let v108_12: Space = wrap(&(v108_11),&(*p1));
    drop(v108_11);
    let v108_13: Space = unite(&(v108_7),&(v108_12));
    drop(v108_12);
    v107_15.join_into((v108_13).clone());
    }
    v107_15_cursor.ascend(1);
  }
  drop(v107_15_cursor);
  drop(v107_8);
  (v107_15).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v113_6 = Space::new();
  let mut v113_6_cursor = (*s0).read_zipper();
  for v113_6_byte in v113_6_cursor.child_mask().iter() {
    v113_6_cursor.descend_to_byte(v113_6_byte);
    {
    let v113_6_tail = v113_6_cursor.fork_read_zipper();
    let v113_6_head = Path::from_slice(&[v113_6_byte]);
    let v114_2: Space = singleton(&(v113_6_head));
    let v114_3: Space = intersect(&(*CONSTANT_3),&(v114_2));
    let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
    drop(v114_3);
    let v114_5: Space = subtract(&(*CONSTANT_2),&(v114_4));
    drop(v114_4);
    let v114_8: Space = if (v114_5).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&(v113_6_head));
      let v115_7: Space = routine_10(c, &(v115_6), &(*p1), &(v113_6_tail).make_space());
      compose(&(v114_5),&(v115_7))
    };
    drop(v114_5);
    let v114_9: Space = intersect(&(*CONSTANT_3),&(v114_2));
    drop(v114_2);
    let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
    drop(v114_9);
    let v114_11: Space = compose(&(v114_10),&(v113_6_tail));
    drop(v114_10);
    let v116_6: Path = concat_path(&(*p0),&(v113_6_head));
    let v114_12: Space = wrap(&(v114_11),&(v116_6));
    drop(v114_11);
    let v114_13: Space = wrap(&(v114_12),&(*p1));
    drop(v114_12);
    let v114_14: Space = unite(&(v114_8),&(v114_13));
    drop(v114_13);
    v113_6.join_into((v114_14).clone());
    }
    v113_6_cursor.ascend(1);
  }
  drop(v113_6_cursor);
  (v113_6).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v117_3: Space = wrap(&(*s0),&(*p0));
  let v117_4: Space = wrap(&(v117_3),&(*p1));
  drop(v117_3);
  (v117_4).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v118_11: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v118_12: Space = unwrap(&(v118_11),&(*CONSTANT_4));
  drop(v118_11);
  let mut v118_16 = Space::new();
  let mut v118_16_cursor = (*s0).read_zipper();
  for v118_16_byte in v118_16_cursor.child_mask().iter() {
    v118_16_cursor.descend_to_byte(v118_16_byte);
    {
    let v118_16_tail = v118_16_cursor.fork_read_zipper();
    let v118_16_head = Path::from_slice(&[v118_16_byte]);
    let v119_2: Space = singleton(&(v118_16_head));
    let v119_3: Space = intersect(&(*CONSTANT_3),&(v119_2));
    let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
    drop(v119_3);
    let v119_5: Space = subtract(&(*CONSTANT_2),&(v119_4));
    drop(v119_4);
    let v119_8: Space = if (v119_5).is_empty() { Space::new() } else {
      let v120_6: Path = concat_path(&(*p0),&(v118_16_head));
      let v120_7: Space = routine_12(c, &(v120_6), &(v118_16_tail).make_space(), &(*s1));
      compose(&(v119_5),&(v120_7))
    };
    drop(v119_5);
    let v119_9: Space = intersect(&(*CONSTANT_3),&(v119_2));
    drop(v119_2);
    let v119_10: Space = if has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
    drop(v119_9);
    let v119_12: Space = if (v119_10).is_empty() { Space::new() } else {
      let v121_6: Path = concat_path(&(*p0),&(v118_16_head));
      let mut v121_11 = Space::new();
      let mut v121_11_cursor = (v118_16_tail).read_zipper();
      for v121_11_byte in v121_11_cursor.child_mask().iter() {
        v121_11_cursor.descend_to_byte(v121_11_byte);
        {
        let v121_11_tail = v121_11_cursor.fork_read_zipper();
        let v121_11_head = Path::from_slice(&[v121_11_byte]);
        let v122_2: Space = singleton(&(v121_11_head));
        let v122_3: Space = intersect(&(*CONSTANT_3),&(v122_2));
        let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
        drop(v122_3);
        let v122_5: Space = subtract(&(*CONSTANT_2),&(v122_4));
        drop(v122_4);
        let v122_7: Space = if (v122_5).is_empty() { Space::new() } else {
          let v123_6: Space = routine_13(c, &(v121_11_head), &(v121_6), &(v121_11_tail).make_space(), &(*s1));
          compose(&(v122_5),&(v123_6))
        };
        drop(v122_5);
        let v122_8: Space = intersect(&(*CONSTANT_3),&(v122_2));
        drop(v122_2);
        let v122_9: Space = if has_head(&(v122_8)) { singleton(&[]) } else { Space::new() };
        drop(v122_8);
        let v122_12: Space = if (v122_9).is_empty() { Space::new() } else {
          let v124_10: Space = unwrap(&(v118_12),&(v121_11_head));
          let mut v124_11 = Space::new();
          let mut v124_11_cursor = (v124_10).read_zipper();
          for v124_11_byte in v124_11_cursor.child_mask().iter() {
            v124_11_cursor.descend_to_byte(v124_11_byte);
            {
            let v124_11_tail = v124_11_cursor.fork_read_zipper();
            let v124_11_head = Path::from_slice(&[v124_11_byte]);
            let v125_2: Space = singleton(&(v124_11_head));
            let v125_3: Space = intersect(&(*CONSTANT_3),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_2),&(v125_4));
            drop(v125_4);
            let v125_7: Space = if (v125_5).is_empty() { Space::new() } else {
              let v126_6: Space = routine_15(c, &(v124_11_head), &(v121_6), &(v124_11_tail).make_space());
              compose(&(v125_5),&(v126_6))
            };
            drop(v125_5);
            let v125_8: Space = intersect(&(*CONSTANT_3),&(v125_2));
            drop(v125_2);
            let v125_9: Space = if has_head(&(v125_8)) { singleton(&[]) } else { Space::new() };
            drop(v125_8);
            let v125_11: Space = if (v125_9).is_empty() { Space::new() } else {
              let v127_10: Space = routine_16(c, &(v124_11_head), &(v121_6), &(v124_11_tail).make_space());
              compose(&(v125_9),&(v127_10))
            };
            drop(v125_9);
            let v125_12: Space = unite(&(v125_7),&(v125_11));
            v124_11.join_into((v125_12).clone());
            }
            v124_11_cursor.ascend(1);
          }
          drop(v124_11_cursor);
          drop(v124_10);
          compose(&(v122_9),&(v124_11))
        };
        drop(v122_9);
        let v122_13: Space = unite(&(v122_7),&(v122_12));
        v121_11.join_into((v122_13).clone());
        }
        v121_11_cursor.ascend(1);
      }
      drop(v121_11_cursor);
      drop(v121_6);
      compose(&(v119_10),&(v121_11))
    };
    drop(v119_10);
    let v119_13: Space = unite(&(v119_8),&(v119_12));
    v118_16.join_into((v119_13).clone());
    }
    v118_16_cursor.ascend(1);
  }
  drop(v118_16_cursor);
  drop(v118_12);
  (v118_16).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v128_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v128_10: Space = unwrap(&(v128_8),&(*CONSTANT_4));
  drop(v128_8);
  let v128_11: Space = unwrap(&(v128_10),&(*p0));
  drop(v128_10);
  let mut v128_15 = Space::new();
  let mut v128_15_cursor = (*s0).read_zipper();
  for v128_15_byte in v128_15_cursor.child_mask().iter() {
    v128_15_cursor.descend_to_byte(v128_15_byte);
    {
    let v128_15_tail = v128_15_cursor.fork_read_zipper();
    let v128_15_head = Path::from_slice(&[v128_15_byte]);
    let v129_2: Space = singleton(&(v128_15_head));
    let v129_3: Space = intersect(&(*CONSTANT_3),&(v129_2));
    let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
    drop(v129_3);
    let v129_5: Space = subtract(&(*CONSTANT_2),&(v129_4));
    drop(v129_4);
    let v129_8: Space = if (v129_5).is_empty() { Space::new() } else {
      let v130_6: Path = concat_path(&(*p0),&(v128_15_head));
      let v130_7: Space = routine_13(c, &(v130_6), &(*p1), &(v128_15_tail).make_space(), &(*s1));
      drop(v130_6);
      compose(&(v129_5),&(v130_7))
    };
    drop(v129_5);
    let v129_9: Space = intersect(&(*CONSTANT_3),&(v129_2));
    drop(v129_2);
    let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
    drop(v129_9);
    let v129_13: Space = if (v129_10).is_empty() { Space::new() } else {
      let v131_11: Space = unwrap(&(v128_11),&(v128_15_head));
      let mut v131_12 = Space::new();
      let mut v131_12_cursor = (v131_11).read_zipper();
      for v131_12_byte in v131_12_cursor.child_mask().iter() {
        v131_12_cursor.descend_to_byte(v131_12_byte);
        {
        let v131_12_tail = v131_12_cursor.fork_read_zipper();
        let v131_12_head = Path::from_slice(&[v131_12_byte]);
        let v132_2: Space = singleton(&(v131_12_head));
        let v132_3: Space = intersect(&(*CONSTANT_3),&(v132_2));
        let v132_4: Space = if has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
        drop(v132_3);
        let v132_5: Space = subtract(&(*CONSTANT_2),&(v132_4));
        drop(v132_4);
        let v132_7: Space = if (v132_5).is_empty() { Space::new() } else {
          let v133_6: Space = routine_15(c, &(v131_12_head), &(*p1), &(v131_12_tail).make_space());
          compose(&(v132_5),&(v133_6))
        };
        drop(v132_5);
        let v132_8: Space = intersect(&(*CONSTANT_3),&(v132_2));
        drop(v132_2);
        let v132_9: Space = if has_head(&(v132_8)) { singleton(&[]) } else { Space::new() };
        drop(v132_8);
        let v132_10: Space = compose(&(v132_9),&(v131_12_tail));
        drop(v132_9);
        let v132_11: Space = wrap(&(v132_10),&(v131_12_head));
        drop(v132_10);
        let v132_12: Space = wrap(&(v132_11),&(*p1));
        drop(v132_11);
        let v132_13: Space = unite(&(v132_7),&(v132_12));
        drop(v132_12);
        v131_12.join_into((v132_13).clone());
        }
        v131_12_cursor.ascend(1);
      }
      drop(v131_12_cursor);
      drop(v131_11);
      compose(&(v129_10),&(v131_12))
    };
    drop(v129_10);
    let v129_14: Space = unite(&(v129_8),&(v129_13));
    v128_15.join_into((v129_14).clone());
    }
    v128_15_cursor.ascend(1);
  }
  drop(v128_15_cursor);
  drop(v128_11);
  (v128_15).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v134_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v134_7: Space = unwrap(&(v134_5),&(*CONSTANT_4));
  drop(v134_5);
  let v134_8: Space = unwrap(&(v134_7),&(*p0));
  drop(v134_7);
  let mut v134_15 = Space::new();
  let mut v134_15_cursor = (v134_8).read_zipper();
  for v134_15_byte in v134_15_cursor.child_mask().iter() {
    v134_15_cursor.descend_to_byte(v134_15_byte);
    {
    let v134_15_tail = v134_15_cursor.fork_read_zipper();
    let v134_15_head = Path::from_slice(&[v134_15_byte]);
    let v135_2: Space = singleton(&(v134_15_head));
    let v135_3: Space = intersect(&(*CONSTANT_3),&(v135_2));
    let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
    drop(v135_3);
    let v135_5: Space = subtract(&(*CONSTANT_2),&(v135_4));
    drop(v135_4);
    let v135_7: Space = if (v135_5).is_empty() { Space::new() } else {
      let mut v136_6 = Space::new();
      let mut v136_6_cursor = (v134_15_tail).read_zipper();
      for v136_6_byte in v136_6_cursor.child_mask().iter() {
        v136_6_cursor.descend_to_byte(v136_6_byte);
        {
        let v136_6_tail = v136_6_cursor.fork_read_zipper();
        let v136_6_head = Path::from_slice(&[v136_6_byte]);
        let v137_2: Space = singleton(&(v136_6_head));
        let v137_3: Space = intersect(&(*CONSTANT_3),&(v137_2));
        let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
        drop(v137_3);
        let v137_5: Space = subtract(&(*CONSTANT_2),&(v137_4));
        drop(v137_4);
        let v137_8: Space = if (v137_5).is_empty() { Space::new() } else {
          let v138_6: Path = concat_path(&(v134_15_head),&(v136_6_head));
          let v138_7: Space = routine_15(c, &(v138_6), &(*p1), &(v136_6_tail).make_space());
          compose(&(v137_5),&(v138_7))
        };
        drop(v137_5);
        let v137_9: Space = intersect(&(*CONSTANT_3),&(v137_2));
        drop(v137_2);
        let v137_10: Space = if has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
        drop(v137_9);
        let v137_11: Space = compose(&(v137_10),&(v136_6_tail));
        drop(v137_10);
        let v139_6: Path = concat_path(&(v134_15_head),&(v136_6_head));
        let v137_12: Space = wrap(&(v137_11),&(v139_6));
        drop(v137_11);
        let v137_13: Space = wrap(&(v137_12),&(*p1));
        drop(v137_12);
        let v137_14: Space = unite(&(v137_8),&(v137_13));
        drop(v137_13);
        v136_6.join_into((v137_14).clone());
        }
        v136_6_cursor.ascend(1);
      }
      drop(v136_6_cursor);
      compose(&(v135_5),&(v136_6))
    };
    drop(v135_5);
    let v135_8: Space = intersect(&(*CONSTANT_3),&(v135_2));
    drop(v135_2);
    let v135_9: Space = if has_head(&(v135_8)) { singleton(&[]) } else { Space::new() };
    drop(v135_8);
    let v135_10: Space = compose(&(v135_9),&(v134_15_tail));
    drop(v135_9);
    let v135_11: Space = wrap(&(v135_10),&(v134_15_head));
    drop(v135_10);
    let v135_12: Space = wrap(&(v135_11),&(*p1));
    drop(v135_11);
    let v135_13: Space = unite(&(v135_7),&(v135_12));
    drop(v135_12);
    v134_15.join_into((v135_13).clone());
    }
    v134_15_cursor.ascend(1);
  }
  drop(v134_15_cursor);
  drop(v134_8);
  (v134_15).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v140_6 = Space::new();
  let mut v140_6_cursor = (*s0).read_zipper();
  for v140_6_byte in v140_6_cursor.child_mask().iter() {
    v140_6_cursor.descend_to_byte(v140_6_byte);
    {
    let v140_6_tail = v140_6_cursor.fork_read_zipper();
    let v140_6_head = Path::from_slice(&[v140_6_byte]);
    let v141_2: Space = singleton(&(v140_6_head));
    let v141_3: Space = intersect(&(*CONSTANT_3),&(v141_2));
    let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
    drop(v141_3);
    let v141_5: Space = subtract(&(*CONSTANT_2),&(v141_4));
    drop(v141_4);
    let v141_8: Space = if (v141_5).is_empty() { Space::new() } else {
      let v142_6: Path = concat_path(&(*p0),&(v140_6_head));
      let v142_7: Space = routine_15(c, &(v142_6), &(*p1), &(v140_6_tail).make_space());
      compose(&(v141_5),&(v142_7))
    };
    drop(v141_5);
    let v141_9: Space = intersect(&(*CONSTANT_3),&(v141_2));
    drop(v141_2);
    let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
    drop(v141_9);
    let v141_11: Space = compose(&(v141_10),&(v140_6_tail));
    drop(v141_10);
    let v143_6: Path = concat_path(&(*p0),&(v140_6_head));
    let v141_12: Space = wrap(&(v141_11),&(v143_6));
    drop(v141_11);
    let v141_13: Space = wrap(&(v141_12),&(*p1));
    drop(v141_12);
    let v141_14: Space = unite(&(v141_8),&(v141_13));
    drop(v141_13);
    v140_6.join_into((v141_14).clone());
    }
    v140_6_cursor.ascend(1);
  }
  drop(v140_6_cursor);
  (v140_6).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v144_3: Space = wrap(&(*s0),&(*p0));
  let v144_4: Space = wrap(&(v144_3),&(*p1));
  drop(v144_3);
  (v144_4).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v145_11: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let v145_12: Space = unwrap(&(v145_11),&(*CONSTANT_4));
  drop(v145_11);
  let mut v145_16 = Space::new();
  let mut v145_16_cursor = (*s0).read_zipper();
  for v145_16_byte in v145_16_cursor.child_mask().iter() {
    v145_16_cursor.descend_to_byte(v145_16_byte);
    {
    let v145_16_tail = v145_16_cursor.fork_read_zipper();
    let v145_16_head = Path::from_slice(&[v145_16_byte]);
    let v146_2: Space = singleton(&(v145_16_head));
    let v146_3: Space = intersect(&(*CONSTANT_3),&(v146_2));
    let v146_4: Space = if has_head(&(v146_3)) { singleton(&[]) } else { Space::new() };
    drop(v146_3);
    let v146_5: Space = subtract(&(*CONSTANT_2),&(v146_4));
    drop(v146_4);
    let v146_8: Space = if (v146_5).is_empty() { Space::new() } else {
      let v147_6: Path = concat_path(&(*p0),&(v145_16_head));
      let v147_7: Space = routine_17(c, &(v147_6), &(v145_16_tail).make_space(), &(*s1));
      compose(&(v146_5),&(v147_7))
    };
    drop(v146_5);
    let v146_9: Space = intersect(&(*CONSTANT_3),&(v146_2));
    drop(v146_2);
    let v146_10: Space = if has_head(&(v146_9)) { singleton(&[]) } else { Space::new() };
    drop(v146_9);
    let v146_12: Space = if (v146_10).is_empty() { Space::new() } else {
      let v148_6: Path = concat_path(&(*p0),&(v145_16_head));
      let mut v148_11 = Space::new();
      let mut v148_11_cursor = (v145_16_tail).read_zipper();
      for v148_11_byte in v148_11_cursor.child_mask().iter() {
        v148_11_cursor.descend_to_byte(v148_11_byte);
        {
        let v148_11_tail = v148_11_cursor.fork_read_zipper();
        let v148_11_head = Path::from_slice(&[v148_11_byte]);
        let v149_2: Space = singleton(&(v148_11_head));
        let v149_3: Space = intersect(&(*CONSTANT_3),&(v149_2));
        let v149_4: Space = if has_head(&(v149_3)) { singleton(&[]) } else { Space::new() };
        drop(v149_3);
        let v149_5: Space = subtract(&(*CONSTANT_2),&(v149_4));
        drop(v149_4);
        let v149_7: Space = if (v149_5).is_empty() { Space::new() } else {
          let v150_6: Space = routine_18(c, &(v148_11_head), &(v148_6), &(v148_11_tail).make_space(), &(*s1));
          compose(&(v149_5),&(v150_6))
        };
        drop(v149_5);
        let v149_8: Space = intersect(&(*CONSTANT_3),&(v149_2));
        drop(v149_2);
        let v149_9: Space = if has_head(&(v149_8)) { singleton(&[]) } else { Space::new() };
        drop(v149_8);
        let v149_12: Space = if (v149_9).is_empty() { Space::new() } else {
          let v151_10: Space = unwrap(&(v145_12),&(v148_11_head));
          let mut v151_11 = Space::new();
          let mut v151_11_cursor = (v151_10).read_zipper();
          for v151_11_byte in v151_11_cursor.child_mask().iter() {
            v151_11_cursor.descend_to_byte(v151_11_byte);
            {
            let v151_11_tail = v151_11_cursor.fork_read_zipper();
            let v151_11_head = Path::from_slice(&[v151_11_byte]);
            let v152_2: Space = singleton(&(v151_11_head));
            let v152_3: Space = intersect(&(*CONSTANT_3),&(v152_2));
            let v152_4: Space = if has_head(&(v152_3)) { singleton(&[]) } else { Space::new() };
            drop(v152_3);
            let v152_5: Space = subtract(&(*CONSTANT_2),&(v152_4));
            drop(v152_4);
            let v152_7: Space = if (v152_5).is_empty() { Space::new() } else {
              let v153_6: Space = routine_20(c, &(v151_11_head), &(v148_6), &(v151_11_tail).make_space());
              compose(&(v152_5),&(v153_6))
            };
            drop(v152_5);
            let v152_8: Space = intersect(&(*CONSTANT_3),&(v152_2));
            drop(v152_2);
            let v152_9: Space = if has_head(&(v152_8)) { singleton(&[]) } else { Space::new() };
            drop(v152_8);
            let v152_11: Space = if (v152_9).is_empty() { Space::new() } else {
              let v154_10: Space = routine_21(c, &(v151_11_head), &(v148_6), &(v151_11_tail).make_space());
              compose(&(v152_9),&(v154_10))
            };
            drop(v152_9);
            let v152_12: Space = unite(&(v152_7),&(v152_11));
            v151_11.join_into((v152_12).clone());
            }
            v151_11_cursor.ascend(1);
          }
          drop(v151_11_cursor);
          drop(v151_10);
          compose(&(v149_9),&(v151_11))
        };
        drop(v149_9);
        let v149_13: Space = unite(&(v149_7),&(v149_12));
        v148_11.join_into((v149_13).clone());
        }
        v148_11_cursor.ascend(1);
      }
      drop(v148_11_cursor);
      drop(v148_6);
      compose(&(v146_10),&(v148_11))
    };
    drop(v146_10);
    let v146_13: Space = unite(&(v146_8),&(v146_12));
    v145_16.join_into((v146_13).clone());
    }
    v145_16_cursor.ascend(1);
  }
  drop(v145_16_cursor);
  drop(v145_12);
  (v145_16).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v155_8: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let v155_10: Space = unwrap(&(v155_8),&(*CONSTANT_4));
  drop(v155_8);
  let v155_11: Space = unwrap(&(v155_10),&(*p0));
  drop(v155_10);
  let mut v155_15 = Space::new();
  let mut v155_15_cursor = (*s0).read_zipper();
  for v155_15_byte in v155_15_cursor.child_mask().iter() {
    v155_15_cursor.descend_to_byte(v155_15_byte);
    {
    let v155_15_tail = v155_15_cursor.fork_read_zipper();
    let v155_15_head = Path::from_slice(&[v155_15_byte]);
    let v156_2: Space = singleton(&(v155_15_head));
    let v156_3: Space = intersect(&(*CONSTANT_3),&(v156_2));
    let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
    drop(v156_3);
    let v156_5: Space = subtract(&(*CONSTANT_2),&(v156_4));
    drop(v156_4);
    let v156_8: Space = if (v156_5).is_empty() { Space::new() } else {
      let v157_6: Path = concat_path(&(*p0),&(v155_15_head));
      let v157_7: Space = routine_18(c, &(v157_6), &(*p1), &(v155_15_tail).make_space(), &(*s1));
      drop(v157_6);
      compose(&(v156_5),&(v157_7))
    };
    drop(v156_5);
    let v156_9: Space = intersect(&(*CONSTANT_3),&(v156_2));
    drop(v156_2);
    let v156_10: Space = if has_head(&(v156_9)) { singleton(&[]) } else { Space::new() };
    drop(v156_9);
    let v156_13: Space = if (v156_10).is_empty() { Space::new() } else {
      let v158_11: Space = unwrap(&(v155_11),&(v155_15_head));
      let mut v158_12 = Space::new();
      let mut v158_12_cursor = (v158_11).read_zipper();
      for v158_12_byte in v158_12_cursor.child_mask().iter() {
        v158_12_cursor.descend_to_byte(v158_12_byte);
        {
        let v158_12_tail = v158_12_cursor.fork_read_zipper();
        let v158_12_head = Path::from_slice(&[v158_12_byte]);
        let v159_2: Space = singleton(&(v158_12_head));
        let v159_3: Space = intersect(&(*CONSTANT_3),&(v159_2));
        let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
        drop(v159_3);
        let v159_5: Space = subtract(&(*CONSTANT_2),&(v159_4));
        drop(v159_4);
        let v159_7: Space = if (v159_5).is_empty() { Space::new() } else {
          let v160_6: Space = routine_20(c, &(v158_12_head), &(*p1), &(v158_12_tail).make_space());
          compose(&(v159_5),&(v160_6))
        };
        drop(v159_5);
        let v159_8: Space = intersect(&(*CONSTANT_3),&(v159_2));
        drop(v159_2);
        let v159_9: Space = if has_head(&(v159_8)) { singleton(&[]) } else { Space::new() };
        drop(v159_8);
        let v159_10: Space = compose(&(v159_9),&(v158_12_tail));
        drop(v159_9);
        let v159_11: Space = wrap(&(v159_10),&(v158_12_head));
        drop(v159_10);
        let v159_12: Space = wrap(&(v159_11),&(*p1));
        drop(v159_11);
        let v159_13: Space = unite(&(v159_7),&(v159_12));
        drop(v159_12);
        v158_12.join_into((v159_13).clone());
        }
        v158_12_cursor.ascend(1);
      }
      drop(v158_12_cursor);
      drop(v158_11);
      compose(&(v156_10),&(v158_12))
    };
    drop(v156_10);
    let v156_14: Space = unite(&(v156_8),&(v156_13));
    v155_15.join_into((v156_14).clone());
    }
    v155_15_cursor.ascend(1);
  }
  drop(v155_15_cursor);
  drop(v155_11);
  (v155_15).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v161_5: Space = unwrap(&(*s1),&(*CONSTANT_5));
  let v161_7: Space = unwrap(&(v161_5),&(*CONSTANT_4));
  drop(v161_5);
  let v161_8: Space = unwrap(&(v161_7),&(*p0));
  drop(v161_7);
  let mut v161_15 = Space::new();
  let mut v161_15_cursor = (v161_8).read_zipper();
  for v161_15_byte in v161_15_cursor.child_mask().iter() {
    v161_15_cursor.descend_to_byte(v161_15_byte);
    {
    let v161_15_tail = v161_15_cursor.fork_read_zipper();
    let v161_15_head = Path::from_slice(&[v161_15_byte]);
    let v162_2: Space = singleton(&(v161_15_head));
    let v162_3: Space = intersect(&(*CONSTANT_3),&(v162_2));
    let v162_4: Space = if has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
    drop(v162_3);
    let v162_5: Space = subtract(&(*CONSTANT_2),&(v162_4));
    drop(v162_4);
    let v162_7: Space = if (v162_5).is_empty() { Space::new() } else {
      let mut v163_6 = Space::new();
      let mut v163_6_cursor = (v161_15_tail).read_zipper();
      for v163_6_byte in v163_6_cursor.child_mask().iter() {
        v163_6_cursor.descend_to_byte(v163_6_byte);
        {
        let v163_6_tail = v163_6_cursor.fork_read_zipper();
        let v163_6_head = Path::from_slice(&[v163_6_byte]);
        let v164_2: Space = singleton(&(v163_6_head));
        let v164_3: Space = intersect(&(*CONSTANT_3),&(v164_2));
        let v164_4: Space = if has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = subtract(&(*CONSTANT_2),&(v164_4));
        drop(v164_4);
        let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v161_15_head),&(v163_6_head));
          let v165_7: Space = routine_20(c, &(v165_6), &(*p1), &(v163_6_tail).make_space());
          compose(&(v164_5),&(v165_7))
        };
        drop(v164_5);
        let v164_9: Space = intersect(&(*CONSTANT_3),&(v164_2));
        drop(v164_2);
        let v164_10: Space = if has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
        drop(v164_9);
        let v164_11: Space = compose(&(v164_10),&(v163_6_tail));
        drop(v164_10);
        let v166_6: Path = concat_path(&(v161_15_head),&(v163_6_head));
        let v164_12: Space = wrap(&(v164_11),&(v166_6));
        drop(v164_11);
        let v164_13: Space = wrap(&(v164_12),&(*p1));
        drop(v164_12);
        let v164_14: Space = unite(&(v164_8),&(v164_13));
        drop(v164_13);
        v163_6.join_into((v164_14).clone());
        }
        v163_6_cursor.ascend(1);
      }
      drop(v163_6_cursor);
      compose(&(v162_5),&(v163_6))
    };
    drop(v162_5);
    let v162_8: Space = intersect(&(*CONSTANT_3),&(v162_2));
    drop(v162_2);
    let v162_9: Space = if has_head(&(v162_8)) { singleton(&[]) } else { Space::new() };
    drop(v162_8);
    let v162_10: Space = compose(&(v162_9),&(v161_15_tail));
    drop(v162_9);
    let v162_11: Space = wrap(&(v162_10),&(v161_15_head));
    drop(v162_10);
    let v162_12: Space = wrap(&(v162_11),&(*p1));
    drop(v162_11);
    let v162_13: Space = unite(&(v162_7),&(v162_12));
    drop(v162_12);
    v161_15.join_into((v162_13).clone());
    }
    v161_15_cursor.ascend(1);
  }
  drop(v161_15_cursor);
  drop(v161_8);
  (v161_15).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v167_6 = Space::new();
  let mut v167_6_cursor = (*s0).read_zipper();
  for v167_6_byte in v167_6_cursor.child_mask().iter() {
    v167_6_cursor.descend_to_byte(v167_6_byte);
    {
    let v167_6_tail = v167_6_cursor.fork_read_zipper();
    let v167_6_head = Path::from_slice(&[v167_6_byte]);
    let v168_2: Space = singleton(&(v167_6_head));
    let v168_3: Space = intersect(&(*CONSTANT_3),&(v168_2));
    let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
    drop(v168_3);
    let v168_5: Space = subtract(&(*CONSTANT_2),&(v168_4));
    drop(v168_4);
    let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
      let v169_6: Path = concat_path(&(*p0),&(v167_6_head));
      let v169_7: Space = routine_20(c, &(v169_6), &(*p1), &(v167_6_tail).make_space());
      compose(&(v168_5),&(v169_7))
    };
    drop(v168_5);
    let v168_9: Space = intersect(&(*CONSTANT_3),&(v168_2));
    drop(v168_2);
    let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
    drop(v168_9);
    let v168_11: Space = compose(&(v168_10),&(v167_6_tail));
    drop(v168_10);
    let v170_6: Path = concat_path(&(*p0),&(v167_6_head));
    let v168_12: Space = wrap(&(v168_11),&(v170_6));
    drop(v168_11);
    let v168_13: Space = wrap(&(v168_12),&(*p1));
    drop(v168_12);
    let v168_14: Space = unite(&(v168_8),&(v168_13));
    drop(v168_13);
    v167_6.join_into((v168_14).clone());
    }
    v167_6_cursor.ascend(1);
  }
  drop(v167_6_cursor);
  (v167_6).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v171_3: Space = wrap(&(*s0),&(*p0));
  let v171_4: Space = wrap(&(v171_3),&(*p1));
  drop(v171_3);
  (v171_4).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
