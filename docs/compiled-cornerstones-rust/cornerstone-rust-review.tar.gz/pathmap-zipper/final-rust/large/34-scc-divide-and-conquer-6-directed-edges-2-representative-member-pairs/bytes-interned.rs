#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,2]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,3]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,5]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,4]));
static CONSTANT_7: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 4 0 0 0 0 4 0 0 0 1 4 0 0 0 2 4 0 0 0 3 4 0 0 0 4"));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 8 0 0 0 0 0 0 0 1 8 0 0 0 1 0 0 0 0 8 0 0 0 1 0 0 0 2 8 0 0 0 2 0 0 0 3 8 0 0 0 3 0 0 0 2 8 0 0 0 4 0 0 0 5"));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
static CONSTANT_10: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 0 0 0 0 4 0 0 0 1 4 0 0 0 2 4 0 0 0 3 4 0 0 0 4 4 0 0 0 5"));
fn routine_0(c: &mut Context) -> Space {
  let v0_3: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &(*CONSTANT_2));
  let v0_5: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_0), &(*CONSTANT_2));
  let v0_6: Space = unite(&(v0_3),&(v0_5));
  let v0_9: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_1), &(*CONSTANT_2));
  let v0_10: Space = unite(&(v0_6),&(v0_9));
  let v0_13: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4), &(*CONSTANT_2));
  let v0_14: Space = unite(&(v0_10),&(v0_13));
  let v0_16: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_3), &(*CONSTANT_2));
  let v0_17: Space = unite(&(v0_14),&(v0_16));
  let v0_21: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6), &(*CONSTANT_2));
  let v0_22: Space = unite(&(v0_17),&(v0_21));
  let mut v0_23 = Space::new();
  let mut v0_23_cursor = (v0_22).read_zipper();
  for v0_23_byte in v0_23_cursor.child_mask().iter() {
    v0_23_cursor.descend_to_byte(v0_23_byte);
    {
    let v0_23_tail = v0_23_cursor.fork_read_zipper();
    let v0_23_head = Path::from_slice(&[v0_23_byte]);
    let mut v1_2 = Space::new();
    let mut v1_2_cursor = (v0_23_tail).read_zipper();
    for v1_2_byte in v1_2_cursor.child_mask().iter() {
      v1_2_cursor.descend_to_byte(v1_2_byte);
      {
      let v1_2_tail = v1_2_cursor.fork_read_zipper();
      let v1_2_head = Path::from_slice(&[v1_2_byte]);
      let v2_2: Path = concat_path(&(v0_23_head),&(v1_2_head));
      let mut v2_3 = Space::new();
      let mut v2_3_cursor = (v1_2_tail).read_zipper();
      for v2_3_byte in v2_3_cursor.child_mask().iter() {
        v2_3_cursor.descend_to_byte(v2_3_byte);
        {
        let v2_3_tail = v2_3_cursor.fork_read_zipper();
        let v2_3_head = Path::from_slice(&[v2_3_byte]);
        let v3_2: Space = head_space(&(v2_3_tail));
        let v3_3: Path = concat_path(&(v2_2),&(v2_3_head));
        let v3_4: Space = wrap(&(v3_2),&(v3_3));
        drop(v3_2);
        drop(v3_3);
        v2_3.join_into((v3_4).clone());
        }
        v2_3_cursor.ascend(1);
      }
      drop(v2_3_cursor);
      drop(v2_2);
      v1_2.join_into((v2_3).clone());
      }
      v1_2_cursor.ascend(1);
    }
    drop(v1_2_cursor);
    v0_23.join_into((v1_2).clone());
    }
    v0_23_cursor.ascend(1);
  }
  drop(v0_23_cursor);
  let v0_25: Space = unite(&(v0_23),&(*CONSTANT_7));
  let v0_26: Space = routine_2(c, &(v0_25));
  let mut v0_41 = Space::new();
  let mut v0_41_cursor = (v0_26).read_zipper();
  for v0_41_byte in v0_41_cursor.child_mask().iter() {
    v0_41_cursor.descend_to_byte(v0_41_byte);
    {
    let v0_41_tail = v0_41_cursor.fork_read_zipper();
    let v0_41_head = Path::from_slice(&[v0_41_byte]);
    let mut v4_2 = Space::new();
    let mut v4_2_cursor = (v0_41_tail).read_zipper();
    for v4_2_byte in v4_2_cursor.child_mask().iter() {
      v4_2_cursor.descend_to_byte(v4_2_byte);
      {
      let v4_2_tail = v4_2_cursor.fork_read_zipper();
      let v4_2_head = Path::from_slice(&[v4_2_byte]);
      let v5_2: Path = concat_path(&(v0_41_head),&(v4_2_head));
      let mut v5_3 = Space::new();
      let mut v5_3_cursor = (v4_2_tail).read_zipper();
      for v5_3_byte in v5_3_cursor.child_mask().iter() {
        v5_3_cursor.descend_to_byte(v5_3_byte);
        {
        let v5_3_tail = v5_3_cursor.fork_read_zipper();
        let v5_3_head = Path::from_slice(&[v5_3_byte]);
        let v6_2: Path = concat_path(&(v5_2),&(v5_3_head));
        let mut v6_3 = Space::new();
        let mut v6_3_cursor = (v5_3_tail).read_zipper();
        for v6_3_byte in v6_3_cursor.child_mask().iter() {
          v6_3_cursor.descend_to_byte(v6_3_byte);
          {
          let v6_3_tail = v6_3_cursor.fork_read_zipper();
          let v6_3_head = Path::from_slice(&[v6_3_byte]);
          let v7_2: Path = concat_path(&(v6_2),&(v6_3_head));
          let v7_3: Space = routine_3(c, &(*CONSTANT_0), &(*CONSTANT_1), &(*CONSTANT_2));
          let v7_4: Space = routine_3(c, &(*CONSTANT_1), &(*CONSTANT_0), &(*CONSTANT_2));
          let v7_5: Space = unite(&(v7_3),&(v7_4));
          let v7_6: Space = routine_3(c, &(*CONSTANT_3), &(*CONSTANT_1), &(*CONSTANT_2));
          let v7_7: Space = unite(&(v7_5),&(v7_6));
          let v7_8: Space = routine_3(c, &(*CONSTANT_3), &(*CONSTANT_4), &(*CONSTANT_2));
          let v7_9: Space = unite(&(v7_7),&(v7_8));
          let v7_10: Space = routine_3(c, &(*CONSTANT_4), &(*CONSTANT_3), &(*CONSTANT_2));
          let v7_11: Space = unite(&(v7_9),&(v7_10));
          let v7_12: Space = routine_3(c, &(*CONSTANT_5), &(*CONSTANT_6), &(*CONSTANT_2));
          let v7_13: Space = unite(&(v7_11),&(v7_12));
          let v7_14: Space = routine_1(c, &(*CONSTANT_0), &(*CONSTANT_1), &(*CONSTANT_2));
          let v7_15: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_0), &(*CONSTANT_2));
          let v7_16: Space = unite(&(v7_14),&(v7_15));
          let v7_17: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_1), &(*CONSTANT_2));
          let v7_18: Space = unite(&(v7_16),&(v7_17));
          let v7_19: Space = routine_1(c, &(*CONSTANT_3), &(*CONSTANT_4), &(*CONSTANT_2));
          let v7_20: Space = unite(&(v7_18),&(v7_19));
          let v7_21: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_3), &(*CONSTANT_2));
          let v7_22: Space = unite(&(v7_20),&(v7_21));
          let v7_23: Space = routine_1(c, &(*CONSTANT_5), &(*CONSTANT_6), &(*CONSTANT_2));
          let v7_24: Space = unite(&(v7_22),&(v7_23));
          let mut v7_25 = Space::new();
          let mut v7_25_cursor = (v7_24).read_zipper();
          for v7_25_byte in v7_25_cursor.child_mask().iter() {
            v7_25_cursor.descend_to_byte(v7_25_byte);
            {
            let v7_25_tail = v7_25_cursor.fork_read_zipper();
            let v7_25_head = Path::from_slice(&[v7_25_byte]);
            let mut v8_2 = Space::new();
            let mut v8_2_cursor = (v7_25_tail).read_zipper();
            for v8_2_byte in v8_2_cursor.child_mask().iter() {
              v8_2_cursor.descend_to_byte(v8_2_byte);
              {
              let v8_2_tail = v8_2_cursor.fork_read_zipper();
              let v8_2_head = Path::from_slice(&[v8_2_byte]);
              let v9_2: Path = concat_path(&(v7_25_head),&(v8_2_head));
              let mut v9_3 = Space::new();
              let mut v9_3_cursor = (v8_2_tail).read_zipper();
              for v9_3_byte in v9_3_cursor.child_mask().iter() {
                v9_3_cursor.descend_to_byte(v9_3_byte);
                {
                let v9_3_tail = v9_3_cursor.fork_read_zipper();
                let v9_3_head = Path::from_slice(&[v9_3_byte]);
                let v10_2: Space = head_space(&(v9_3_tail));
                let v10_3: Path = concat_path(&(v9_2),&(v9_3_head));
                let v10_4: Space = wrap(&(v10_2),&(v10_3));
                drop(v10_2);
                drop(v10_3);
                v9_3.join_into((v10_4).clone());
                }
                v9_3_cursor.ascend(1);
              }
              drop(v9_3_cursor);
              drop(v9_2);
              v8_2.join_into((v9_3).clone());
              }
              v8_2_cursor.ascend(1);
            }
            drop(v8_2_cursor);
            v7_25.join_into((v8_2).clone());
            }
            v7_25_cursor.ascend(1);
          }
          drop(v7_25_cursor);
          let v7_26: Space = unite(&(v7_25),&(*CONSTANT_7));
          let v7_27: Space = routine_4(c, &(v7_2), &(v6_3_tail).make_space(), &(v7_13), &(*CONSTANT_8), &(v7_26));
          drop(v7_2);
          v6_3.join_into((v7_27).clone());
          }
          v6_3_cursor.ascend(1);
        }
        drop(v6_3_cursor);
        drop(v6_2);
        v5_3.join_into((v6_3).clone());
        }
        v5_3_cursor.ascend(1);
      }
      drop(v5_3_cursor);
      drop(v5_2);
      v4_2.join_into((v5_3).clone());
      }
      v4_2_cursor.ascend(1);
    }
    drop(v4_2_cursor);
    v0_41.join_into((v4_2).clone());
    }
    v0_41_cursor.ascend(1);
  }
  drop(v0_41_cursor);
  (v0_41).clone()
}

fn routine_1(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v11_3: Path = concat_path(&(*p0),&(*p1));
  let v11_4: Space = singleton(&(v11_3));
  drop(v11_3);
  (v11_4).clone()
}

fn routine_2(c: &mut Context, s0: &Space) -> Space {
  let v12_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v12_2: Space = first_matching(&(*s0),&(*CONSTANT_2),false);
  let v12_3: Space = unite(&(v12_1),&(v12_2));
  drop(v12_1);
  drop(v12_2);
  let v12_6: Space = if (v12_3).is_empty() { Space::new() } else {
    let v13_4: Space = routine_5(c, &(*s0));
    let v13_5: Space = subtract(&(*s0),&(v13_4));
    compose(&(v12_3),&(v13_5))
  };
  drop(v12_3);
  let v12_7: Space = subtract(&(*s0),&(v12_6));
  (v12_7).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v14_3: Path = concat_path(&(*p0),&(*p1));
  let v14_4: Space = singleton(&(v14_3));
  drop(v14_3);
  (v14_4).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let v15_5: Space = singleton(&(*p0));
  let mut v15_6: Space = (v15_5).clone();
  loop {
    let v16_1: Space = intersect(&(v15_6),&(*s3));
    let v16_2: Space = restrict_to(&(*s2),&(v16_1));
    drop(v16_1);
    let mut v16_3 = Space::new();
    let mut v16_3_cursor = (v16_2).read_zipper();
    for v16_3_byte in v16_3_cursor.child_mask().iter() {
      v16_3_cursor.descend_to_byte(v16_3_byte);
      {
      let v16_3_tail = v16_3_cursor.fork_read_zipper();
      let v16_3_head = Path::from_slice(&[v16_3_byte]);
      let mut v17_2 = Space::new();
      let mut v17_2_cursor = (v16_3_tail).read_zipper();
      for v17_2_byte in v17_2_cursor.child_mask().iter() {
        v17_2_cursor.descend_to_byte(v17_2_byte);
        {
        let v17_2_tail = v17_2_cursor.fork_read_zipper();
        let v17_2_head = Path::from_slice(&[v17_2_byte]);
        let mut v18_2 = Space::new();
        let mut v18_2_cursor = (v17_2_tail).read_zipper();
        for v18_2_byte in v18_2_cursor.child_mask().iter() {
          v18_2_cursor.descend_to_byte(v18_2_byte);
          {
          let v18_2_tail = v18_2_cursor.fork_read_zipper();
          let v18_2_head = Path::from_slice(&[v18_2_byte]);
          let v19_2: Space = tails_union(&(v18_2_tail));
          v18_2.join_into((v19_2).clone());
          }
          v18_2_cursor.ascend(1);
        }
        drop(v18_2_cursor);
        v17_2.join_into((v18_2).clone());
        }
        v17_2_cursor.ascend(1);
      }
      drop(v17_2_cursor);
      v16_3.join_into((v17_2).clone());
      }
      v16_3_cursor.ascend(1);
    }
    drop(v16_3_cursor);
    drop(v16_2);
    let v16_4: Space = unite(&(v16_3),&(v15_6));
    drop(v16_3);
    let v16_5: Space = intersect(&(v16_4),&(*s3));
    drop(v16_4);
    if !v15_6.join_into((v16_5).clone()).is_element() { break; }
  }
  let mut v15_7: Space = (v15_5).clone();
  loop {
    let v20_1: Space = intersect(&(v15_7),&(*s3));
    let v20_2: Space = restrict_to(&(*s1),&(v20_1));
    drop(v20_1);
    let mut v20_3 = Space::new();
    let mut v20_3_cursor = (v20_2).read_zipper();
    for v20_3_byte in v20_3_cursor.child_mask().iter() {
      v20_3_cursor.descend_to_byte(v20_3_byte);
      {
      let v20_3_tail = v20_3_cursor.fork_read_zipper();
      let v20_3_head = Path::from_slice(&[v20_3_byte]);
      let mut v21_2 = Space::new();
      let mut v21_2_cursor = (v20_3_tail).read_zipper();
      for v21_2_byte in v21_2_cursor.child_mask().iter() {
        v21_2_cursor.descend_to_byte(v21_2_byte);
        {
        let v21_2_tail = v21_2_cursor.fork_read_zipper();
        let v21_2_head = Path::from_slice(&[v21_2_byte]);
        let mut v22_2 = Space::new();
        let mut v22_2_cursor = (v21_2_tail).read_zipper();
        for v22_2_byte in v22_2_cursor.child_mask().iter() {
          v22_2_cursor.descend_to_byte(v22_2_byte);
          {
          let v22_2_tail = v22_2_cursor.fork_read_zipper();
          let v22_2_head = Path::from_slice(&[v22_2_byte]);
          let v23_2: Space = tails_union(&(v22_2_tail));
          v22_2.join_into((v23_2).clone());
          }
          v22_2_cursor.ascend(1);
        }
        drop(v22_2_cursor);
        v21_2.join_into((v22_2).clone());
        }
        v21_2_cursor.ascend(1);
      }
      drop(v21_2_cursor);
      v20_3.join_into((v21_2).clone());
      }
      v20_3_cursor.ascend(1);
    }
    drop(v20_3_cursor);
    drop(v20_2);
    let v20_4: Space = unite(&(v20_3),&(v15_7));
    drop(v20_3);
    let v20_5: Space = intersect(&(v20_4),&(*s3));
    drop(v20_4);
    if !v15_7.join_into((v20_5).clone()).is_element() { break; }
  }
  let v15_8: Space = intersect(&(v15_6),&(v15_7));
  let v15_9: Space = subtract(&(v15_8),&(v15_5));
  drop(v15_8);
  let v15_10: Space = wrap(&(v15_9),&(*p0));
  drop(v15_9);
  let v15_11: Space = subtract(&(*s3),&(v15_6));
  let v15_12: Space = subtract(&(v15_11),&(v15_7));
  drop(v15_11);
  let v15_13: Space = routine_2(c, &(v15_12));
  drop(v15_12);
  let mut v15_14 = Space::new();
  let mut v15_14_cursor = (v15_13).read_zipper();
  for v15_14_byte in v15_14_cursor.child_mask().iter() {
    v15_14_cursor.descend_to_byte(v15_14_byte);
    {
    let v15_14_tail = v15_14_cursor.fork_read_zipper();
    let v15_14_head = Path::from_slice(&[v15_14_byte]);
    let mut v24_2 = Space::new();
    let mut v24_2_cursor = (v15_14_tail).read_zipper();
    for v24_2_byte in v24_2_cursor.child_mask().iter() {
      v24_2_cursor.descend_to_byte(v24_2_byte);
      {
      let v24_2_tail = v24_2_cursor.fork_read_zipper();
      let v24_2_head = Path::from_slice(&[v24_2_byte]);
      let v25_2: Path = concat_path(&(v15_14_head),&(v24_2_head));
      let mut v25_3 = Space::new();
      let mut v25_3_cursor = (v24_2_tail).read_zipper();
      for v25_3_byte in v25_3_cursor.child_mask().iter() {
        v25_3_cursor.descend_to_byte(v25_3_byte);
        {
        let v25_3_tail = v25_3_cursor.fork_read_zipper();
        let v25_3_head = Path::from_slice(&[v25_3_byte]);
        let v26_2: Path = concat_path(&(v25_2),&(v25_3_head));
        let mut v26_3 = Space::new();
        let mut v26_3_cursor = (v25_3_tail).read_zipper();
        for v26_3_byte in v26_3_cursor.child_mask().iter() {
          v26_3_cursor.descend_to_byte(v26_3_byte);
          {
          let v26_3_tail = v26_3_cursor.fork_read_zipper();
          let v26_3_head = Path::from_slice(&[v26_3_byte]);
          let v27_2: Path = concat_path(&(v26_2),&(v26_3_head));
          let mut v27_3: Space = (v15_5).clone();
          loop {
            let v28_1: Space = intersect(&(v27_3),&(*s3));
            let v28_2: Space = restrict_to(&(*s2),&(v28_1));
            drop(v28_1);
            let mut v28_3 = Space::new();
            let mut v28_3_cursor = (v28_2).read_zipper();
            for v28_3_byte in v28_3_cursor.child_mask().iter() {
              v28_3_cursor.descend_to_byte(v28_3_byte);
              {
              let v28_3_tail = v28_3_cursor.fork_read_zipper();
              let v28_3_head = Path::from_slice(&[v28_3_byte]);
              let mut v29_2 = Space::new();
              let mut v29_2_cursor = (v28_3_tail).read_zipper();
              for v29_2_byte in v29_2_cursor.child_mask().iter() {
                v29_2_cursor.descend_to_byte(v29_2_byte);
                {
                let v29_2_tail = v29_2_cursor.fork_read_zipper();
                let v29_2_head = Path::from_slice(&[v29_2_byte]);
                let mut v30_2 = Space::new();
                let mut v30_2_cursor = (v29_2_tail).read_zipper();
                for v30_2_byte in v30_2_cursor.child_mask().iter() {
                  v30_2_cursor.descend_to_byte(v30_2_byte);
                  {
                  let v30_2_tail = v30_2_cursor.fork_read_zipper();
                  let v30_2_head = Path::from_slice(&[v30_2_byte]);
                  let v31_2: Space = tails_union(&(v30_2_tail));
                  v30_2.join_into((v31_2).clone());
                  }
                  v30_2_cursor.ascend(1);
                }
                drop(v30_2_cursor);
                v29_2.join_into((v30_2).clone());
                }
                v29_2_cursor.ascend(1);
              }
              drop(v29_2_cursor);
              v28_3.join_into((v29_2).clone());
              }
              v28_3_cursor.ascend(1);
            }
            drop(v28_3_cursor);
            drop(v28_2);
            let v28_4: Space = unite(&(v28_3),&(v27_3));
            drop(v28_3);
            let v28_5: Space = intersect(&(v28_4),&(*s3));
            drop(v28_4);
            if !v27_3.join_into((v28_5).clone()).is_element() { break; }
          }
          let v27_4: Space = subtract(&(*s3),&(v27_3));
          drop(v27_3);
          let mut v27_5: Space = (v15_5).clone();
          loop {
            let v32_1: Space = intersect(&(v27_5),&(*s3));
            let v32_2: Space = restrict_to(&(*s1),&(v32_1));
            drop(v32_1);
            let mut v32_3 = Space::new();
            let mut v32_3_cursor = (v32_2).read_zipper();
            for v32_3_byte in v32_3_cursor.child_mask().iter() {
              v32_3_cursor.descend_to_byte(v32_3_byte);
              {
              let v32_3_tail = v32_3_cursor.fork_read_zipper();
              let v32_3_head = Path::from_slice(&[v32_3_byte]);
              let mut v33_2 = Space::new();
              let mut v33_2_cursor = (v32_3_tail).read_zipper();
              for v33_2_byte in v33_2_cursor.child_mask().iter() {
                v33_2_cursor.descend_to_byte(v33_2_byte);
                {
                let v33_2_tail = v33_2_cursor.fork_read_zipper();
                let v33_2_head = Path::from_slice(&[v33_2_byte]);
                let mut v34_2 = Space::new();
                let mut v34_2_cursor = (v33_2_tail).read_zipper();
                for v34_2_byte in v34_2_cursor.child_mask().iter() {
                  v34_2_cursor.descend_to_byte(v34_2_byte);
                  {
                  let v34_2_tail = v34_2_cursor.fork_read_zipper();
                  let v34_2_head = Path::from_slice(&[v34_2_byte]);
                  let v35_2: Space = tails_union(&(v34_2_tail));
                  v34_2.join_into((v35_2).clone());
                  }
                  v34_2_cursor.ascend(1);
                }
                drop(v34_2_cursor);
                v33_2.join_into((v34_2).clone());
                }
                v33_2_cursor.ascend(1);
              }
              drop(v33_2_cursor);
              v32_3.join_into((v33_2).clone());
              }
              v32_3_cursor.ascend(1);
            }
            drop(v32_3_cursor);
            drop(v32_2);
            let v32_4: Space = unite(&(v32_3),&(v27_5));
            drop(v32_3);
            let v32_5: Space = intersect(&(v32_4),&(*s3));
            drop(v32_4);
            if !v27_5.join_into((v32_5).clone()).is_element() { break; }
          }
          let v27_6: Space = subtract(&(v27_4),&(v27_5));
          drop(v27_4);
          drop(v27_5);
          let v27_7: Space = routine_4(c, &(v27_2), &(v26_3_tail).make_space(), &(*s1), &(*s2), &(v27_6));
          drop(v27_2);
          drop(v27_6);
          v26_3.join_into((v27_7).clone());
          }
          v26_3_cursor.ascend(1);
        }
        drop(v26_3_cursor);
        drop(v26_2);
        v25_3.join_into((v26_3).clone());
        }
        v25_3_cursor.ascend(1);
      }
      drop(v25_3_cursor);
      drop(v25_2);
      v24_2.join_into((v25_3).clone());
      }
      v24_2_cursor.ascend(1);
    }
    drop(v24_2_cursor);
    v15_14.join_into((v24_2).clone());
    }
    v15_14_cursor.ascend(1);
  }
  drop(v15_14_cursor);
  let v15_15: Space = unite(&(v15_10),&(v15_14));
  drop(v15_10);
  let v15_16: Space = subtract(&(v15_6),&(v15_7));
  let v15_17: Space = routine_2(c, &(v15_16));
  drop(v15_16);
  let mut v15_18 = Space::new();
  let mut v15_18_cursor = (v15_17).read_zipper();
  for v15_18_byte in v15_18_cursor.child_mask().iter() {
    v15_18_cursor.descend_to_byte(v15_18_byte);
    {
    let v15_18_tail = v15_18_cursor.fork_read_zipper();
    let v15_18_head = Path::from_slice(&[v15_18_byte]);
    let mut v36_2 = Space::new();
    let mut v36_2_cursor = (v15_18_tail).read_zipper();
    for v36_2_byte in v36_2_cursor.child_mask().iter() {
      v36_2_cursor.descend_to_byte(v36_2_byte);
      {
      let v36_2_tail = v36_2_cursor.fork_read_zipper();
      let v36_2_head = Path::from_slice(&[v36_2_byte]);
      let v37_2: Path = concat_path(&(v15_18_head),&(v36_2_head));
      let mut v37_3 = Space::new();
      let mut v37_3_cursor = (v36_2_tail).read_zipper();
      for v37_3_byte in v37_3_cursor.child_mask().iter() {
        v37_3_cursor.descend_to_byte(v37_3_byte);
        {
        let v37_3_tail = v37_3_cursor.fork_read_zipper();
        let v37_3_head = Path::from_slice(&[v37_3_byte]);
        let v38_2: Path = concat_path(&(v37_2),&(v37_3_head));
        let mut v38_3 = Space::new();
        let mut v38_3_cursor = (v37_3_tail).read_zipper();
        for v38_3_byte in v38_3_cursor.child_mask().iter() {
          v38_3_cursor.descend_to_byte(v38_3_byte);
          {
          let v38_3_tail = v38_3_cursor.fork_read_zipper();
          let v38_3_head = Path::from_slice(&[v38_3_byte]);
          let v39_2: Path = concat_path(&(v38_2),&(v38_3_head));
          let mut v39_3: Space = (v15_5).clone();
          loop {
            let v40_1: Space = intersect(&(v39_3),&(*s3));
            let v40_2: Space = restrict_to(&(*s2),&(v40_1));
            drop(v40_1);
            let mut v40_3 = Space::new();
            let mut v40_3_cursor = (v40_2).read_zipper();
            for v40_3_byte in v40_3_cursor.child_mask().iter() {
              v40_3_cursor.descend_to_byte(v40_3_byte);
              {
              let v40_3_tail = v40_3_cursor.fork_read_zipper();
              let v40_3_head = Path::from_slice(&[v40_3_byte]);
              let mut v41_2 = Space::new();
              let mut v41_2_cursor = (v40_3_tail).read_zipper();
              for v41_2_byte in v41_2_cursor.child_mask().iter() {
                v41_2_cursor.descend_to_byte(v41_2_byte);
                {
                let v41_2_tail = v41_2_cursor.fork_read_zipper();
                let v41_2_head = Path::from_slice(&[v41_2_byte]);
                let mut v42_2 = Space::new();
                let mut v42_2_cursor = (v41_2_tail).read_zipper();
                for v42_2_byte in v42_2_cursor.child_mask().iter() {
                  v42_2_cursor.descend_to_byte(v42_2_byte);
                  {
                  let v42_2_tail = v42_2_cursor.fork_read_zipper();
                  let v42_2_head = Path::from_slice(&[v42_2_byte]);
                  let v43_2: Space = tails_union(&(v42_2_tail));
                  v42_2.join_into((v43_2).clone());
                  }
                  v42_2_cursor.ascend(1);
                }
                drop(v42_2_cursor);
                v41_2.join_into((v42_2).clone());
                }
                v41_2_cursor.ascend(1);
              }
              drop(v41_2_cursor);
              v40_3.join_into((v41_2).clone());
              }
              v40_3_cursor.ascend(1);
            }
            drop(v40_3_cursor);
            drop(v40_2);
            let v40_4: Space = unite(&(v40_3),&(v39_3));
            drop(v40_3);
            let v40_5: Space = intersect(&(v40_4),&(*s3));
            drop(v40_4);
            if !v39_3.join_into((v40_5).clone()).is_element() { break; }
          }
          let mut v39_4: Space = (v15_5).clone();
          loop {
            let v44_1: Space = intersect(&(v39_4),&(*s3));
            let v44_2: Space = restrict_to(&(*s1),&(v44_1));
            drop(v44_1);
            let mut v44_3 = Space::new();
            let mut v44_3_cursor = (v44_2).read_zipper();
            for v44_3_byte in v44_3_cursor.child_mask().iter() {
              v44_3_cursor.descend_to_byte(v44_3_byte);
              {
              let v44_3_tail = v44_3_cursor.fork_read_zipper();
              let v44_3_head = Path::from_slice(&[v44_3_byte]);
              let mut v45_2 = Space::new();
              let mut v45_2_cursor = (v44_3_tail).read_zipper();
              for v45_2_byte in v45_2_cursor.child_mask().iter() {
                v45_2_cursor.descend_to_byte(v45_2_byte);
                {
                let v45_2_tail = v45_2_cursor.fork_read_zipper();
                let v45_2_head = Path::from_slice(&[v45_2_byte]);
                let mut v46_2 = Space::new();
                let mut v46_2_cursor = (v45_2_tail).read_zipper();
                for v46_2_byte in v46_2_cursor.child_mask().iter() {
                  v46_2_cursor.descend_to_byte(v46_2_byte);
                  {
                  let v46_2_tail = v46_2_cursor.fork_read_zipper();
                  let v46_2_head = Path::from_slice(&[v46_2_byte]);
                  let v47_2: Space = tails_union(&(v46_2_tail));
                  v46_2.join_into((v47_2).clone());
                  }
                  v46_2_cursor.ascend(1);
                }
                drop(v46_2_cursor);
                v45_2.join_into((v46_2).clone());
                }
                v45_2_cursor.ascend(1);
              }
              drop(v45_2_cursor);
              v44_3.join_into((v45_2).clone());
              }
              v44_3_cursor.ascend(1);
            }
            drop(v44_3_cursor);
            drop(v44_2);
            let v44_4: Space = unite(&(v44_3),&(v39_4));
            drop(v44_3);
            let v44_5: Space = intersect(&(v44_4),&(*s3));
            drop(v44_4);
            if !v39_4.join_into((v44_5).clone()).is_element() { break; }
          }
          let v39_5: Space = subtract(&(v39_3),&(v39_4));
          drop(v39_3);
          drop(v39_4);
          let v39_6: Space = routine_4(c, &(v39_2), &(v38_3_tail).make_space(), &(*s1), &(*s2), &(v39_5));
          drop(v39_2);
          drop(v39_5);
          v38_3.join_into((v39_6).clone());
          }
          v38_3_cursor.ascend(1);
        }
        drop(v38_3_cursor);
        drop(v38_2);
        v37_3.join_into((v38_3).clone());
        }
        v37_3_cursor.ascend(1);
      }
      drop(v37_3_cursor);
      drop(v37_2);
      v36_2.join_into((v37_3).clone());
      }
      v36_2_cursor.ascend(1);
    }
    drop(v36_2_cursor);
    v15_18.join_into((v36_2).clone());
    }
    v15_18_cursor.ascend(1);
  }
  drop(v15_18_cursor);
  let v15_19: Space = unite(&(v15_15),&(v15_18));
  let v15_20: Space = subtract(&(v15_7),&(v15_6));
  drop(v15_6);
  drop(v15_7);
  let v15_21: Space = routine_2(c, &(v15_20));
  drop(v15_20);
  let mut v15_22 = Space::new();
  let mut v15_22_cursor = (v15_21).read_zipper();
  for v15_22_byte in v15_22_cursor.child_mask().iter() {
    v15_22_cursor.descend_to_byte(v15_22_byte);
    {
    let v15_22_tail = v15_22_cursor.fork_read_zipper();
    let v15_22_head = Path::from_slice(&[v15_22_byte]);
    let mut v48_2 = Space::new();
    let mut v48_2_cursor = (v15_22_tail).read_zipper();
    for v48_2_byte in v48_2_cursor.child_mask().iter() {
      v48_2_cursor.descend_to_byte(v48_2_byte);
      {
      let v48_2_tail = v48_2_cursor.fork_read_zipper();
      let v48_2_head = Path::from_slice(&[v48_2_byte]);
      let v49_2: Path = concat_path(&(v15_22_head),&(v48_2_head));
      let mut v49_3 = Space::new();
      let mut v49_3_cursor = (v48_2_tail).read_zipper();
      for v49_3_byte in v49_3_cursor.child_mask().iter() {
        v49_3_cursor.descend_to_byte(v49_3_byte);
        {
        let v49_3_tail = v49_3_cursor.fork_read_zipper();
        let v49_3_head = Path::from_slice(&[v49_3_byte]);
        let v50_2: Path = concat_path(&(v49_2),&(v49_3_head));
        let mut v50_3 = Space::new();
        let mut v50_3_cursor = (v49_3_tail).read_zipper();
        for v50_3_byte in v50_3_cursor.child_mask().iter() {
          v50_3_cursor.descend_to_byte(v50_3_byte);
          {
          let v50_3_tail = v50_3_cursor.fork_read_zipper();
          let v50_3_head = Path::from_slice(&[v50_3_byte]);
          let v51_2: Path = concat_path(&(v50_2),&(v50_3_head));
          let mut v51_3: Space = (v15_5).clone();
          loop {
            let v52_1: Space = intersect(&(v51_3),&(*s3));
            let v52_2: Space = restrict_to(&(*s1),&(v52_1));
            drop(v52_1);
            let mut v52_3 = Space::new();
            let mut v52_3_cursor = (v52_2).read_zipper();
            for v52_3_byte in v52_3_cursor.child_mask().iter() {
              v52_3_cursor.descend_to_byte(v52_3_byte);
              {
              let v52_3_tail = v52_3_cursor.fork_read_zipper();
              let v52_3_head = Path::from_slice(&[v52_3_byte]);
              let mut v53_2 = Space::new();
              let mut v53_2_cursor = (v52_3_tail).read_zipper();
              for v53_2_byte in v53_2_cursor.child_mask().iter() {
                v53_2_cursor.descend_to_byte(v53_2_byte);
                {
                let v53_2_tail = v53_2_cursor.fork_read_zipper();
                let v53_2_head = Path::from_slice(&[v53_2_byte]);
                let mut v54_2 = Space::new();
                let mut v54_2_cursor = (v53_2_tail).read_zipper();
                for v54_2_byte in v54_2_cursor.child_mask().iter() {
                  v54_2_cursor.descend_to_byte(v54_2_byte);
                  {
                  let v54_2_tail = v54_2_cursor.fork_read_zipper();
                  let v54_2_head = Path::from_slice(&[v54_2_byte]);
                  let v55_2: Space = tails_union(&(v54_2_tail));
                  v54_2.join_into((v55_2).clone());
                  }
                  v54_2_cursor.ascend(1);
                }
                drop(v54_2_cursor);
                v53_2.join_into((v54_2).clone());
                }
                v53_2_cursor.ascend(1);
              }
              drop(v53_2_cursor);
              v52_3.join_into((v53_2).clone());
              }
              v52_3_cursor.ascend(1);
            }
            drop(v52_3_cursor);
            drop(v52_2);
            let v52_4: Space = unite(&(v52_3),&(v51_3));
            drop(v52_3);
            let v52_5: Space = intersect(&(v52_4),&(*s3));
            drop(v52_4);
            if !v51_3.join_into((v52_5).clone()).is_element() { break; }
          }
          let mut v51_4: Space = (v15_5).clone();
          loop {
            let v56_1: Space = intersect(&(v51_4),&(*s3));
            let v56_2: Space = restrict_to(&(*s2),&(v56_1));
            drop(v56_1);
            let mut v56_3 = Space::new();
            let mut v56_3_cursor = (v56_2).read_zipper();
            for v56_3_byte in v56_3_cursor.child_mask().iter() {
              v56_3_cursor.descend_to_byte(v56_3_byte);
              {
              let v56_3_tail = v56_3_cursor.fork_read_zipper();
              let v56_3_head = Path::from_slice(&[v56_3_byte]);
              let mut v57_2 = Space::new();
              let mut v57_2_cursor = (v56_3_tail).read_zipper();
              for v57_2_byte in v57_2_cursor.child_mask().iter() {
                v57_2_cursor.descend_to_byte(v57_2_byte);
                {
                let v57_2_tail = v57_2_cursor.fork_read_zipper();
                let v57_2_head = Path::from_slice(&[v57_2_byte]);
                let mut v58_2 = Space::new();
                let mut v58_2_cursor = (v57_2_tail).read_zipper();
                for v58_2_byte in v58_2_cursor.child_mask().iter() {
                  v58_2_cursor.descend_to_byte(v58_2_byte);
                  {
                  let v58_2_tail = v58_2_cursor.fork_read_zipper();
                  let v58_2_head = Path::from_slice(&[v58_2_byte]);
                  let v59_2: Space = tails_union(&(v58_2_tail));
                  v58_2.join_into((v59_2).clone());
                  }
                  v58_2_cursor.ascend(1);
                }
                drop(v58_2_cursor);
                v57_2.join_into((v58_2).clone());
                }
                v57_2_cursor.ascend(1);
              }
              drop(v57_2_cursor);
              v56_3.join_into((v57_2).clone());
              }
              v56_3_cursor.ascend(1);
            }
            drop(v56_3_cursor);
            drop(v56_2);
            let v56_4: Space = unite(&(v56_3),&(v51_4));
            drop(v56_3);
            let v56_5: Space = intersect(&(v56_4),&(*s3));
            drop(v56_4);
            if !v51_4.join_into((v56_5).clone()).is_element() { break; }
          }
          let v51_5: Space = subtract(&(v51_3),&(v51_4));
          drop(v51_3);
          drop(v51_4);
          let v51_6: Space = routine_4(c, &(v51_2), &(v50_3_tail).make_space(), &(*s1), &(*s2), &(v51_5));
          drop(v51_2);
          drop(v51_5);
          v50_3.join_into((v51_6).clone());
          }
          v50_3_cursor.ascend(1);
        }
        drop(v50_3_cursor);
        drop(v50_2);
        v49_3.join_into((v50_3).clone());
        }
        v49_3_cursor.ascend(1);
      }
      drop(v49_3_cursor);
      drop(v49_2);
      v48_2.join_into((v49_3).clone());
      }
      v48_2_cursor.ascend(1);
    }
    drop(v48_2_cursor);
    v15_22.join_into((v48_2).clone());
    }
    v15_22_cursor.ascend(1);
  }
  drop(v15_22_cursor);
  drop(v15_5);
  let v15_23: Space = unite(&(v15_19),&(v15_22));
  (v15_23).clone()
}

fn routine_5(c: &mut Context, s0: &Space) -> Space {
  let v60_2: Space = first_matching(&(*s0),&(*CONSTANT_2),false);
  let v60_3: Space = intersect(&(*CONSTANT_2),&(v60_2));
  let v60_4: Space = if has_head(&(v60_2)) { singleton(&[]) } else { Space::new() };
  let v60_5: Space = unite(&(v60_3),&(v60_4));
  drop(v60_3);
  let v60_7: Space = compose(&(v60_5),&(*CONSTANT_2));
  drop(v60_5);
  let v60_9: Space = subtract(&(*CONSTANT_2),&(v60_2));
  drop(v60_2);
  let v60_10: Space = subtract(&(v60_9),&(v60_4));
  drop(v60_4);
  drop(v60_9);
  let v60_18: Space = if (v60_10).is_empty() { Space::new() } else {
    let v61_11: Space = first_matching(&(*s0),&(*CONSTANT_10),true);
    let v61_12: Space = first_matching(&(v61_11),&(*CONSTANT_2),false);
    let v61_15: Space = if (v61_12).is_empty() { Space::new() } else {
      let v62_14: Space = routine_6(c, &(*CONSTANT_9), &(*s0));
      compose(&(v61_12),&(v62_14))
    };
    drop(v61_12);
    let mut v61_16 = Space::new();
    let mut v61_16_cursor = (v61_11).read_zipper();
    for v61_16_byte in v61_16_cursor.child_mask().iter() {
      v61_16_cursor.descend_to_byte(v61_16_byte);
      {
      let v61_16_tail = v61_16_cursor.fork_read_zipper();
      let v61_16_head = Path::from_slice(&[v61_16_byte]);
      let mut v63_2 = Space::new();
      let v63_2_arg_0: &Path = &(v61_16_head);
      let v63_2_arg_1: &Space = &(v61_16_tail).make_space();
      let v63_2_arg_2: &Space = &(*s0);
      let mut v63_2_cursor = v63_2_arg_1.read_zipper();
      let mut v63_2_more = v63_2_cursor.is_val() || v63_2_cursor.to_next_val();
      while v63_2_more {
        {
        let v63_2_path = concat_path(v63_2_arg_0,v63_2_cursor.path());
        let v63_2_rest = v63_2_cursor.fork_read_zipper();
        let v64_3: Space = unwrap(&(*v63_2_arg_2),&(v63_2_path));
        let v64_4: Space = routine_5(c, &(v64_3));
        drop(v64_3);
        let v64_5: Space = wrap(&(v64_4),&(v63_2_path));
        v63_2.join_into((v64_5).clone());
        }
        v63_2_more = v63_2_cursor.to_next_val();
      }
      drop(v63_2_cursor);
      v61_16.join_into((v63_2).clone());
      }
      v61_16_cursor.ascend(1);
    }
    drop(v61_16_cursor);
    drop(v61_11);
    let v61_17: Space = unite(&(v61_15),&(v61_16));
    compose(&(v60_10),&(v61_17))
  };
  drop(v60_10);
  let v60_19: Space = unite(&(v60_7),&(v60_18));
  drop(v60_7);
  (v60_19).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v65_3: Space = unwrap(&(*s0),&(*p0));
  let v65_4: Space = first_matching(&(v65_3),&(*CONSTANT_2),false);
  let v65_5: Space = intersect(&(*CONSTANT_2),&(v65_4));
  let v65_6: Space = if has_head(&(v65_4)) { singleton(&[]) } else { Space::new() };
  let v65_7: Space = unite(&(v65_5),&(v65_6));
  drop(v65_5);
  let v65_9: Space = compose(&(v65_7),&(*CONSTANT_2));
  drop(v65_7);
  let v65_11: Space = subtract(&(*CONSTANT_2),&(v65_4));
  drop(v65_4);
  let v65_12: Space = subtract(&(v65_11),&(v65_6));
  drop(v65_6);
  drop(v65_11);
  let v65_16: Space = if (v65_12).is_empty() { Space::new() } else {
    let v66_14: Space = first_matching(&(v65_3),&(*CONSTANT_10),true);
    let mut v66_15 = Space::new();
    let v66_15_arg_0: &Path = &(*CONSTANT_9);
    let v66_15_arg_1: &Space = &(v66_14);
    let v66_15_arg_2: &Space = &(v65_3);
    let mut v66_15_cursor = v66_15_arg_1.read_zipper();
    let mut v66_15_more = v66_15_cursor.is_val() || v66_15_cursor.to_next_val();
    while v66_15_more {
      {
      let v66_15_path = concat_path(v66_15_arg_0,v66_15_cursor.path());
      let v66_15_rest = v66_15_cursor.fork_read_zipper();
      let v67_3: Space = routine_6(c, &(v66_15_path), &(*v66_15_arg_2));
      v66_15.join_into((v67_3).clone());
      }
      v66_15_more = v66_15_cursor.to_next_val();
    }
    drop(v66_15_cursor);
    drop(v66_14);
    compose(&(v65_12),&(v66_15))
  };
  drop(v65_12);
  let v65_17: Space = unite(&(v65_9),&(v65_16));
  drop(v65_9);
  let v65_18: Space = wrap(&(v65_17),&(*p0));
  (v65_18).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
