#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 7 1 1 1 0 0 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1]));
static CONSTANT_4: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 1 1 0 1 1"));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,1]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 5 1 0 0 1 1"));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,1]));
static CONSTANT_8: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("2 4 0 0 1 1 2 1 1"));
static CONSTANT_9: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 2 1 1"));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0]));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 10 0 0 0 1 1 1 0 0 1 1 8 0 0 1 1 1 0 1 1 7 0 1 1 0 0 1 1 5 0 1 1 1 1 8 1 0 1 1 0 0 1 1 5 1 1 0 1 1"));
static CONSTANT_14: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[]));
#[inline(never)]
fn native_block_0(c: &mut Context) -> (Space,Space,Space,Space,Space,Space,) {
  let v0_22: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_19: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v2_18: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v3_5: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
        let v3_8: Space = routine_2(c, &(*CONSTANT_3), &(*CONSTANT_4));
        let v3_9: Space = unite(&(v3_5),&(v3_8));
        let v3_12: Space = routine_2(c, &(*CONSTANT_5), &(*CONSTANT_6));
        let v3_13: Space = unite(&(v3_9),&(v3_12));
        let v3_16: Space = routine_3(c, &(*CONSTANT_7), &(*CONSTANT_8));
        let v3_17: Space = unite(&(v3_13),&(v3_16));
        compose(&(*CONSTANT_0),&(v3_17))
      };
      compose(&(*CONSTANT_0),&(v2_18))
    };
    let v1_21: Space = unite(&(v1_19),&(*CONSTANT_9));
    compose(&(*CONSTANT_0),&(v1_21))
  };
  let v0_44: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v4_43: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v5_42: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v6_29: Space = routine_4(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_9));
        let v6_31: Space = routine_5(c, &(*CONSTANT_1), &(*CONSTANT_2));
        let v6_32: Space = unite(&(v6_29),&(v6_31));
        let v6_34: Space = routine_6(c, &(*CONSTANT_3), &(*CONSTANT_4));
        let v6_35: Space = unite(&(v6_32),&(v6_34));
        let v6_37: Space = routine_6(c, &(*CONSTANT_5), &(*CONSTANT_6));
        let v6_38: Space = unite(&(v6_35),&(v6_37));
        let v6_40: Space = routine_7(c, &(*CONSTANT_7), &(*CONSTANT_8));
        let v6_41: Space = unite(&(v6_38),&(v6_40));
        compose(&(*CONSTANT_0),&(v6_41))
      };
      compose(&(*CONSTANT_0),&(v5_42))
    };
    compose(&(*CONSTANT_0),&(v4_43))
  };
  let mut v0_63 = Space::new();
  let mut v0_63_cursor = (v0_44).read_zipper();
  for v0_63_byte in v0_63_cursor.child_mask().iter() {
    v0_63_cursor.descend_to_byte(v0_63_byte);
    {
    let v0_63_tail = v0_63_cursor.fork_read_zipper();
    let v0_63_head = Path::from_slice(&[v0_63_byte]);
    let v7_2: Space = singleton(&(v0_63_head));
    let v7_3: Space = intersect(&(*CONSTANT_12),&(v7_2));
    let v7_4: Space = if has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
    drop(v7_3);
    let v7_5: Space = subtract(&(*CONSTANT_0),&(v7_4));
    drop(v7_4);
    let v7_7: Space = if (v7_5).is_empty() { Space::new() } else {
      let mut v8_6 = Space::new();
      let mut v8_6_cursor = (v0_63_tail).read_zipper();
      for v8_6_byte in v8_6_cursor.child_mask().iter() {
        v8_6_cursor.descend_to_byte(v8_6_byte);
        {
        let v8_6_tail = v8_6_cursor.fork_read_zipper();
        let v8_6_head = Path::from_slice(&[v8_6_byte]);
        let v9_2: Space = singleton(&(v8_6_head));
        let v9_3: Space = intersect(&(*CONSTANT_12),&(v9_2));
        let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
        drop(v9_3);
        let v9_5: Space = subtract(&(*CONSTANT_0),&(v9_4));
        drop(v9_4);
        let v9_8: Space = if (v9_5).is_empty() { Space::new() } else {
          let v10_6: Path = concat_path(&(v0_63_head),&(v8_6_head));
          let mut v10_7 = Space::new();
          let mut v10_7_cursor = (v8_6_tail).read_zipper();
          for v10_7_byte in v10_7_cursor.child_mask().iter() {
            v10_7_cursor.descend_to_byte(v10_7_byte);
            {
            let v10_7_tail = v10_7_cursor.fork_read_zipper();
            let v10_7_head = Path::from_slice(&[v10_7_byte]);
            let v11_2: Space = singleton(&(v10_7_head));
            let v11_3: Space = intersect(&(*CONSTANT_12),&(v11_2));
            let v11_4: Space = if has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
            drop(v11_3);
            let v11_5: Space = subtract(&(*CONSTANT_0),&(v11_4));
            drop(v11_4);
            let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
              let v12_6: Path = concat_path(&(v10_6),&(v10_7_head));
              let v12_7: Space = routine_8(c, &(v12_6), &(v10_7_tail).make_space());
              compose(&(v11_5),&(v12_7))
            };
            drop(v11_5);
            let v11_9: Space = intersect(&(*CONSTANT_12),&(v11_2));
            drop(v11_2);
            let v11_10: Space = if has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
            drop(v11_9);
            let v11_12: Space = if (v11_10).is_empty() { Space::new() } else {
              let v13_6: Path = concat_path(&(v10_6),&(v10_7_head));
              let v13_11: Space = routine_9(c, &(v13_6), &(v10_7_tail).make_space());
              drop(v13_6);
              compose(&(v11_10),&(v13_11))
            };
            drop(v11_10);
            let v11_13: Space = unite(&(v11_8),&(v11_12));
            v10_7.join_into((v11_13).clone());
            }
            v10_7_cursor.ascend(1);
          }
          drop(v10_7_cursor);
          compose(&(v9_5),&(v10_7))
        };
        drop(v9_5);
        let v9_9: Space = intersect(&(*CONSTANT_12),&(v9_2));
        drop(v9_2);
        let v9_10: Space = if has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
        drop(v9_9);
        let v9_12: Space = if (v9_10).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v0_63_head),&(v8_6_head));
          let mut v14_11 = Space::new();
          let mut v14_11_cursor = (v8_6_tail).read_zipper();
          for v14_11_byte in v14_11_cursor.child_mask().iter() {
            v14_11_cursor.descend_to_byte(v14_11_byte);
            {
            let v14_11_tail = v14_11_cursor.fork_read_zipper();
            let v14_11_head = Path::from_slice(&[v14_11_byte]);
            let v15_2: Space = singleton(&(v14_11_head));
            let v15_3: Space = intersect(&(*CONSTANT_12),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&(v14_11_head));
              let v16_7: Space = routine_8(c, &(v16_6), &(v14_11_tail).make_space());
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_12),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&(v14_11_head));
              let v17_11: Space = routine_10(c, &(v17_6), &(v14_11_tail).make_space());
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            v14_11.join_into((v15_13).clone());
            }
            v14_11_cursor.ascend(1);
          }
          drop(v14_11_cursor);
          drop(v14_6);
          compose(&(v9_10),&(v14_11))
        };
        drop(v9_10);
        let v9_13: Space = unite(&(v9_8),&(v9_12));
        v8_6.join_into((v9_13).clone());
        }
        v8_6_cursor.ascend(1);
      }
      drop(v8_6_cursor);
      compose(&(v7_5),&(v8_6))
    };
    drop(v7_5);
    let v7_8: Space = intersect(&(*CONSTANT_12),&(v7_2));
    drop(v7_2);
    let v7_9: Space = if has_head(&(v7_8)) { singleton(&[]) } else { Space::new() };
    drop(v7_8);
    let v7_11: Space = if (v7_9).is_empty() { Space::new() } else {
      let mut v18_10 = Space::new();
      let mut v18_10_cursor = (v0_63_tail).read_zipper();
      for v18_10_byte in v18_10_cursor.child_mask().iter() {
        v18_10_cursor.descend_to_byte(v18_10_byte);
        {
        let v18_10_tail = v18_10_cursor.fork_read_zipper();
        let v18_10_head = Path::from_slice(&[v18_10_byte]);
        let v19_2: Space = singleton(&(v18_10_head));
        let v19_3: Space = intersect(&(*CONSTANT_12),&(v19_2));
        let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
        drop(v19_3);
        let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
        drop(v19_4);
        let v19_8: Space = if (v19_5).is_empty() { Space::new() } else {
          let v20_6: Path = concat_path(&(v0_63_head),&(v18_10_head));
          let mut v20_7 = Space::new();
          let mut v20_7_cursor = (v18_10_tail).read_zipper();
          for v20_7_byte in v20_7_cursor.child_mask().iter() {
            v20_7_cursor.descend_to_byte(v20_7_byte);
            {
            let v20_7_tail = v20_7_cursor.fork_read_zipper();
            let v20_7_head = Path::from_slice(&[v20_7_byte]);
            let v21_2: Space = singleton(&(v20_7_head));
            let v21_3: Space = intersect(&(*CONSTANT_12),&(v21_2));
            let v21_4: Space = if has_head(&(v21_3)) { singleton(&[]) } else { Space::new() };
            drop(v21_3);
            let v21_5: Space = subtract(&(*CONSTANT_0),&(v21_4));
            drop(v21_4);
            let v21_8: Space = if (v21_5).is_empty() { Space::new() } else {
              let v22_6: Path = concat_path(&(v20_6),&(v20_7_head));
              let v22_7: Space = routine_8(c, &(v22_6), &(v20_7_tail).make_space());
              compose(&(v21_5),&(v22_7))
            };
            drop(v21_5);
            let v21_9: Space = intersect(&(*CONSTANT_12),&(v21_2));
            drop(v21_2);
            let v21_10: Space = if has_head(&(v21_9)) { singleton(&[]) } else { Space::new() };
            drop(v21_9);
            let v21_12: Space = if (v21_10).is_empty() { Space::new() } else {
              let v23_6: Path = concat_path(&(v20_6),&(v20_7_head));
              let v23_11: Space = routine_9(c, &(v23_6), &(v20_7_tail).make_space());
              drop(v23_6);
              compose(&(v21_10),&(v23_11))
            };
            drop(v21_10);
            let v21_13: Space = unite(&(v21_8),&(v21_12));
            v20_7.join_into((v21_13).clone());
            }
            v20_7_cursor.ascend(1);
          }
          drop(v20_7_cursor);
          compose(&(v19_5),&(v20_7))
        };
        drop(v19_5);
        let v19_9: Space = intersect(&(*CONSTANT_12),&(v19_2));
        drop(v19_2);
        let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
        drop(v19_9);
        let v24_6: Path = concat_path(&(v0_63_head),&(v18_10_head));
        let v19_11: Space = singleton(&(v24_6));
        let v19_12: Space = compose(&(v19_10),&(v19_11));
        drop(v19_10);
        drop(v19_11);
        let v19_13: Space = unite(&(v19_8),&(v19_12));
        drop(v19_12);
        v18_10.join_into((v19_13).clone());
        }
        v18_10_cursor.ascend(1);
      }
      drop(v18_10_cursor);
      compose(&(v7_9),&(v18_10))
    };
    drop(v7_9);
    let v7_12: Space = unite(&(v7_7),&(v7_11));
    v0_63.join_into((v7_12).clone());
    }
    v0_63_cursor.ascend(1);
  }
  drop(v0_63_cursor);
  let v0_64: Space = unite(&(v0_22),&(v0_63));
  let v0_65: Space = routine_11(c, &(v0_64));
  let mut v0_155 = Space::new();
  let mut v0_155_cursor = (v0_65).read_zipper();
  for v0_155_byte in v0_155_cursor.child_mask().iter() {
    v0_155_cursor.descend_to_byte(v0_155_byte);
    {
    let v0_155_tail = v0_155_cursor.fork_read_zipper();
    let v0_155_head = Path::from_slice(&[v0_155_byte]);
    let v25_2: Space = singleton(&(v0_155_head));
    let v25_3: Space = intersect(&(*CONSTANT_12),&(v25_2));
    let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
    drop(v25_3);
    let v25_5: Space = subtract(&(*CONSTANT_0),&(v25_4));
    drop(v25_4);
    let v25_44: Space = if (v25_5).is_empty() { Space::new() } else {
      let v26_17: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v27_16: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v28_15: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
            let v29_6: Space = routine_12(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_9));
            let v29_7: Space = routine_13(c, &(*CONSTANT_1), &(*CONSTANT_2));
            let v29_8: Space = unite(&(v29_6),&(v29_7));
            let v29_9: Space = routine_14(c, &(*CONSTANT_3), &(*CONSTANT_4));
            let v29_10: Space = unite(&(v29_8),&(v29_9));
            let v29_11: Space = routine_14(c, &(*CONSTANT_5), &(*CONSTANT_6));
            let v29_12: Space = unite(&(v29_10),&(v29_11));
            let v29_13: Space = routine_15(c, &(*CONSTANT_7), &(*CONSTANT_8));
            let v29_14: Space = unite(&(v29_12),&(v29_13));
            compose(&(*CONSTANT_0),&(v29_14))
          };
          compose(&(*CONSTANT_0),&(v28_15))
        };
        compose(&(*CONSTANT_0),&(v27_16))
      };
      let v26_28: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v30_26: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v31_25: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
            let v32_18: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
            let v32_19: Space = routine_2(c, &(*CONSTANT_3), &(*CONSTANT_4));
            let v32_20: Space = unite(&(v32_18),&(v32_19));
            let v32_21: Space = routine_2(c, &(*CONSTANT_5), &(*CONSTANT_6));
            let v32_22: Space = unite(&(v32_20),&(v32_21));
            let v32_23: Space = routine_3(c, &(*CONSTANT_7), &(*CONSTANT_8));
            let v32_24: Space = unite(&(v32_22),&(v32_23));
            compose(&(*CONSTANT_0),&(v32_24))
          };
          compose(&(*CONSTANT_0),&(v31_25))
        };
        let v30_27: Space = unite(&(v30_26),&(*CONSTANT_9));
        compose(&(*CONSTANT_0),&(v30_27))
      };
      let v26_40: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v33_39: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v34_38: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
            let v35_29: Space = routine_4(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_9));
            let v35_30: Space = routine_5(c, &(*CONSTANT_1), &(*CONSTANT_2));
            let v35_31: Space = unite(&(v35_29),&(v35_30));
            let v35_32: Space = routine_6(c, &(*CONSTANT_3), &(*CONSTANT_4));
            let v35_33: Space = unite(&(v35_31),&(v35_32));
            let v35_34: Space = routine_6(c, &(*CONSTANT_5), &(*CONSTANT_6));
            let v35_35: Space = unite(&(v35_33),&(v35_34));
            let v35_36: Space = routine_7(c, &(*CONSTANT_7), &(*CONSTANT_8));
            let v35_37: Space = unite(&(v35_35),&(v35_36));
            compose(&(*CONSTANT_0),&(v35_37))
          };
          compose(&(*CONSTANT_0),&(v34_38))
        };
        compose(&(*CONSTANT_0),&(v33_39))
      };
      let mut v26_41 = Space::new();
      let mut v26_41_cursor = (v26_40).read_zipper();
      for v26_41_byte in v26_41_cursor.child_mask().iter() {
        v26_41_cursor.descend_to_byte(v26_41_byte);
        {
        let v26_41_tail = v26_41_cursor.fork_read_zipper();
        let v26_41_head = Path::from_slice(&[v26_41_byte]);
        let v36_2: Space = singleton(&(v26_41_head));
        let v36_3: Space = intersect(&(*CONSTANT_12),&(v36_2));
        let v36_4: Space = if has_head(&(v36_3)) { singleton(&[]) } else { Space::new() };
        drop(v36_3);
        let v36_5: Space = subtract(&(*CONSTANT_0),&(v36_4));
        drop(v36_4);
        let v36_7: Space = if (v36_5).is_empty() { Space::new() } else {
          let mut v37_6 = Space::new();
          let mut v37_6_cursor = (v26_41_tail).read_zipper();
          for v37_6_byte in v37_6_cursor.child_mask().iter() {
            v37_6_cursor.descend_to_byte(v37_6_byte);
            {
            let v37_6_tail = v37_6_cursor.fork_read_zipper();
            let v37_6_head = Path::from_slice(&[v37_6_byte]);
            let v38_2: Space = singleton(&(v37_6_head));
            let v38_3: Space = intersect(&(*CONSTANT_12),&(v38_2));
            let v38_4: Space = if has_head(&(v38_3)) { singleton(&[]) } else { Space::new() };
            drop(v38_3);
            let v38_5: Space = subtract(&(*CONSTANT_0),&(v38_4));
            drop(v38_4);
            let v38_8: Space = if (v38_5).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v26_41_head),&(v37_6_head));
              let mut v39_7 = Space::new();
              let mut v39_7_cursor = (v37_6_tail).read_zipper();
              for v39_7_byte in v39_7_cursor.child_mask().iter() {
                v39_7_cursor.descend_to_byte(v39_7_byte);
                {
                let v39_7_tail = v39_7_cursor.fork_read_zipper();
                let v39_7_head = Path::from_slice(&[v39_7_byte]);
                let v40_2: Space = singleton(&(v39_7_head));
                let v40_3: Space = intersect(&(*CONSTANT_12),&(v40_2));
                let v40_4: Space = if has_head(&(v40_3)) { singleton(&[]) } else { Space::new() };
                drop(v40_3);
                let v40_5: Space = subtract(&(*CONSTANT_0),&(v40_4));
                drop(v40_4);
                let v40_8: Space = if (v40_5).is_empty() { Space::new() } else {
                  let v41_6: Path = concat_path(&(v39_6),&(v39_7_head));
                  let v41_7: Space = routine_8(c, &(v41_6), &(v39_7_tail).make_space());
                  compose(&(v40_5),&(v41_7))
                };
                drop(v40_5);
                let v40_9: Space = intersect(&(*CONSTANT_12),&(v40_2));
                drop(v40_2);
                let v40_10: Space = if has_head(&(v40_9)) { singleton(&[]) } else { Space::new() };
                drop(v40_9);
                let v40_12: Space = if (v40_10).is_empty() { Space::new() } else {
                  let v42_6: Path = concat_path(&(v39_6),&(v39_7_head));
                  let v42_11: Space = routine_9(c, &(v42_6), &(v39_7_tail).make_space());
                  drop(v42_6);
                  compose(&(v40_10),&(v42_11))
                };
                drop(v40_10);
                let v40_13: Space = unite(&(v40_8),&(v40_12));
                v39_7.join_into((v40_13).clone());
                }
                v39_7_cursor.ascend(1);
              }
              drop(v39_7_cursor);
              compose(&(v38_5),&(v39_7))
            };
            drop(v38_5);
            let v38_9: Space = intersect(&(*CONSTANT_12),&(v38_2));
            drop(v38_2);
            let v38_10: Space = if has_head(&(v38_9)) { singleton(&[]) } else { Space::new() };
            drop(v38_9);
            let v38_12: Space = if (v38_10).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v26_41_head),&(v37_6_head));
              let mut v43_11 = Space::new();
              let mut v43_11_cursor = (v37_6_tail).read_zipper();
              for v43_11_byte in v43_11_cursor.child_mask().iter() {
                v43_11_cursor.descend_to_byte(v43_11_byte);
                {
                let v43_11_tail = v43_11_cursor.fork_read_zipper();
                let v43_11_head = Path::from_slice(&[v43_11_byte]);
                let v44_2: Space = singleton(&(v43_11_head));
                let v44_3: Space = intersect(&(*CONSTANT_12),&(v44_2));
                let v44_4: Space = if has_head(&(v44_3)) { singleton(&[]) } else { Space::new() };
                drop(v44_3);
                let v44_5: Space = subtract(&(*CONSTANT_0),&(v44_4));
                drop(v44_4);
                let v44_8: Space = if (v44_5).is_empty() { Space::new() } else {
                  let v45_6: Path = concat_path(&(v43_6),&(v43_11_head));
                  let v45_7: Space = routine_8(c, &(v45_6), &(v43_11_tail).make_space());
                  compose(&(v44_5),&(v45_7))
                };
                drop(v44_5);
                let v44_9: Space = intersect(&(*CONSTANT_12),&(v44_2));
                drop(v44_2);
                let v44_10: Space = if has_head(&(v44_9)) { singleton(&[]) } else { Space::new() };
                drop(v44_9);
                let v44_12: Space = if (v44_10).is_empty() { Space::new() } else {
                  let v46_6: Path = concat_path(&(v43_6),&(v43_11_head));
                  let v46_11: Space = routine_10(c, &(v46_6), &(v43_11_tail).make_space());
                  drop(v46_6);
                  compose(&(v44_10),&(v46_11))
                };
                drop(v44_10);
                let v44_13: Space = unite(&(v44_8),&(v44_12));
                v43_11.join_into((v44_13).clone());
                }
                v43_11_cursor.ascend(1);
              }
              drop(v43_11_cursor);
              drop(v43_6);
              compose(&(v38_10),&(v43_11))
            };
            drop(v38_10);
            let v38_13: Space = unite(&(v38_8),&(v38_12));
            v37_6.join_into((v38_13).clone());
            }
            v37_6_cursor.ascend(1);
          }
          drop(v37_6_cursor);
          compose(&(v36_5),&(v37_6))
        };
        drop(v36_5);
        let v36_8: Space = intersect(&(*CONSTANT_12),&(v36_2));
        drop(v36_2);
        let v36_9: Space = if has_head(&(v36_8)) { singleton(&[]) } else { Space::new() };
        drop(v36_8);
        let v36_11: Space = if (v36_9).is_empty() { Space::new() } else {
          let mut v47_10 = Space::new();
          let mut v47_10_cursor = (v26_41_tail).read_zipper();
          for v47_10_byte in v47_10_cursor.child_mask().iter() {
            v47_10_cursor.descend_to_byte(v47_10_byte);
            {
            let v47_10_tail = v47_10_cursor.fork_read_zipper();
            let v47_10_head = Path::from_slice(&[v47_10_byte]);
            let v48_2: Space = singleton(&(v47_10_head));
            let v48_3: Space = intersect(&(*CONSTANT_12),&(v48_2));
            let v48_4: Space = if has_head(&(v48_3)) { singleton(&[]) } else { Space::new() };
            drop(v48_3);
            let v48_5: Space = subtract(&(*CONSTANT_0),&(v48_4));
            drop(v48_4);
            let v48_8: Space = if (v48_5).is_empty() { Space::new() } else {
              let v49_6: Path = concat_path(&(v26_41_head),&(v47_10_head));
              let mut v49_7 = Space::new();
              let mut v49_7_cursor = (v47_10_tail).read_zipper();
              for v49_7_byte in v49_7_cursor.child_mask().iter() {
                v49_7_cursor.descend_to_byte(v49_7_byte);
                {
                let v49_7_tail = v49_7_cursor.fork_read_zipper();
                let v49_7_head = Path::from_slice(&[v49_7_byte]);
                let v50_2: Space = singleton(&(v49_7_head));
                let v50_3: Space = intersect(&(*CONSTANT_12),&(v50_2));
                let v50_4: Space = if has_head(&(v50_3)) { singleton(&[]) } else { Space::new() };
                drop(v50_3);
                let v50_5: Space = subtract(&(*CONSTANT_0),&(v50_4));
                drop(v50_4);
                let v50_8: Space = if (v50_5).is_empty() { Space::new() } else {
                  let v51_6: Path = concat_path(&(v49_6),&(v49_7_head));
                  let v51_7: Space = routine_8(c, &(v51_6), &(v49_7_tail).make_space());
                  compose(&(v50_5),&(v51_7))
                };
                drop(v50_5);
                let v50_9: Space = intersect(&(*CONSTANT_12),&(v50_2));
                drop(v50_2);
                let v50_10: Space = if has_head(&(v50_9)) { singleton(&[]) } else { Space::new() };
                drop(v50_9);
                let v50_12: Space = if (v50_10).is_empty() { Space::new() } else {
                  let v52_6: Path = concat_path(&(v49_6),&(v49_7_head));
                  let v52_11: Space = routine_9(c, &(v52_6), &(v49_7_tail).make_space());
                  drop(v52_6);
                  compose(&(v50_10),&(v52_11))
                };
                drop(v50_10);
                let v50_13: Space = unite(&(v50_8),&(v50_12));
                v49_7.join_into((v50_13).clone());
                }
                v49_7_cursor.ascend(1);
              }
              drop(v49_7_cursor);
              compose(&(v48_5),&(v49_7))
            };
            drop(v48_5);
            let v48_9: Space = intersect(&(*CONSTANT_12),&(v48_2));
            drop(v48_2);
            let v48_10: Space = if has_head(&(v48_9)) { singleton(&[]) } else { Space::new() };
            drop(v48_9);
            let v53_6: Path = concat_path(&(v26_41_head),&(v47_10_head));
            let v48_11: Space = singleton(&(v53_6));
            let v48_12: Space = compose(&(v48_10),&(v48_11));
            drop(v48_10);
            drop(v48_11);
            let v48_13: Space = unite(&(v48_8),&(v48_12));
            drop(v48_12);
            v47_10.join_into((v48_13).clone());
            }
            v47_10_cursor.ascend(1);
          }
          drop(v47_10_cursor);
          compose(&(v36_9),&(v47_10))
        };
        drop(v36_9);
        let v36_12: Space = unite(&(v36_7),&(v36_11));
        v26_41.join_into((v36_12).clone());
        }
        v26_41_cursor.ascend(1);
      }
      drop(v26_41_cursor);
      let v26_42: Space = unite(&(v26_28),&(v26_41));
      let v26_43: Space = routine_16(c, &(v0_155_head), &(v0_155_tail).make_space(), &(v26_17), &(*CONSTANT_13), &(v26_42));
      compose(&(v25_5),&(v26_43))
    };
    drop(v25_5);
    let v25_45: Space = intersect(&(*CONSTANT_12),&(v25_2));
    drop(v25_2);
    let v25_46: Space = if has_head(&(v25_45)) { singleton(&[]) } else { Space::new() };
    drop(v25_45);
    let v25_85: Space = if (v25_46).is_empty() { Space::new() } else {
      let v54_58: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v55_57: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v56_56: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
            let v57_47: Space = routine_12(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_9));
            let v57_48: Space = routine_13(c, &(*CONSTANT_1), &(*CONSTANT_2));
            let v57_49: Space = unite(&(v57_47),&(v57_48));
            let v57_50: Space = routine_14(c, &(*CONSTANT_3), &(*CONSTANT_4));
            let v57_51: Space = unite(&(v57_49),&(v57_50));
            let v57_52: Space = routine_14(c, &(*CONSTANT_5), &(*CONSTANT_6));
            let v57_53: Space = unite(&(v57_51),&(v57_52));
            let v57_54: Space = routine_15(c, &(*CONSTANT_7), &(*CONSTANT_8));
            let v57_55: Space = unite(&(v57_53),&(v57_54));
            compose(&(*CONSTANT_0),&(v57_55))
          };
          compose(&(*CONSTANT_0),&(v56_56))
        };
        compose(&(*CONSTANT_0),&(v55_57))
      };
      let v54_69: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v58_67: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v59_66: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
            let v60_59: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2));
            let v60_60: Space = routine_2(c, &(*CONSTANT_3), &(*CONSTANT_4));
            let v60_61: Space = unite(&(v60_59),&(v60_60));
            let v60_62: Space = routine_2(c, &(*CONSTANT_5), &(*CONSTANT_6));
            let v60_63: Space = unite(&(v60_61),&(v60_62));
            let v60_64: Space = routine_3(c, &(*CONSTANT_7), &(*CONSTANT_8));
            let v60_65: Space = unite(&(v60_63),&(v60_64));
            compose(&(*CONSTANT_0),&(v60_65))
          };
          compose(&(*CONSTANT_0),&(v59_66))
        };
        let v58_68: Space = unite(&(v58_67),&(*CONSTANT_9));
        compose(&(*CONSTANT_0),&(v58_68))
      };
      let v54_81: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v61_80: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v62_79: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
            let v63_70: Space = routine_4(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_9));
            let v63_71: Space = routine_5(c, &(*CONSTANT_1), &(*CONSTANT_2));
            let v63_72: Space = unite(&(v63_70),&(v63_71));
            let v63_73: Space = routine_6(c, &(*CONSTANT_3), &(*CONSTANT_4));
            let v63_74: Space = unite(&(v63_72),&(v63_73));
            let v63_75: Space = routine_6(c, &(*CONSTANT_5), &(*CONSTANT_6));
            let v63_76: Space = unite(&(v63_74),&(v63_75));
            let v63_77: Space = routine_7(c, &(*CONSTANT_7), &(*CONSTANT_8));
            let v63_78: Space = unite(&(v63_76),&(v63_77));
            compose(&(*CONSTANT_0),&(v63_78))
          };
          compose(&(*CONSTANT_0),&(v62_79))
        };
        compose(&(*CONSTANT_0),&(v61_80))
      };
      let mut v54_82 = Space::new();
      let mut v54_82_cursor = (v54_81).read_zipper();
      for v54_82_byte in v54_82_cursor.child_mask().iter() {
        v54_82_cursor.descend_to_byte(v54_82_byte);
        {
        let v54_82_tail = v54_82_cursor.fork_read_zipper();
        let v54_82_head = Path::from_slice(&[v54_82_byte]);
        let v64_2: Space = singleton(&(v54_82_head));
        let v64_3: Space = intersect(&(*CONSTANT_12),&(v64_2));
        let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
        drop(v64_3);
        let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
        drop(v64_4);
        let v64_7: Space = if (v64_5).is_empty() { Space::new() } else {
          let mut v65_6 = Space::new();
          let mut v65_6_cursor = (v54_82_tail).read_zipper();
          for v65_6_byte in v65_6_cursor.child_mask().iter() {
            v65_6_cursor.descend_to_byte(v65_6_byte);
            {
            let v65_6_tail = v65_6_cursor.fork_read_zipper();
            let v65_6_head = Path::from_slice(&[v65_6_byte]);
            let v66_2: Space = singleton(&(v65_6_head));
            let v66_3: Space = intersect(&(*CONSTANT_12),&(v66_2));
            let v66_4: Space = if has_head(&(v66_3)) { singleton(&[]) } else { Space::new() };
            drop(v66_3);
            let v66_5: Space = subtract(&(*CONSTANT_0),&(v66_4));
            drop(v66_4);
            let v66_8: Space = if (v66_5).is_empty() { Space::new() } else {
              let v67_6: Path = concat_path(&(v54_82_head),&(v65_6_head));
              let mut v67_7 = Space::new();
              let mut v67_7_cursor = (v65_6_tail).read_zipper();
              for v67_7_byte in v67_7_cursor.child_mask().iter() {
                v67_7_cursor.descend_to_byte(v67_7_byte);
                {
                let v67_7_tail = v67_7_cursor.fork_read_zipper();
                let v67_7_head = Path::from_slice(&[v67_7_byte]);
                let v68_2: Space = singleton(&(v67_7_head));
                let v68_3: Space = intersect(&(*CONSTANT_12),&(v68_2));
                let v68_4: Space = if has_head(&(v68_3)) { singleton(&[]) } else { Space::new() };
                drop(v68_3);
                let v68_5: Space = subtract(&(*CONSTANT_0),&(v68_4));
                drop(v68_4);
                let v68_8: Space = if (v68_5).is_empty() { Space::new() } else {
                  let v69_6: Path = concat_path(&(v67_6),&(v67_7_head));
                  let v69_7: Space = routine_8(c, &(v69_6), &(v67_7_tail).make_space());
                  compose(&(v68_5),&(v69_7))
                };
                drop(v68_5);
                let v68_9: Space = intersect(&(*CONSTANT_12),&(v68_2));
                drop(v68_2);
                let v68_10: Space = if has_head(&(v68_9)) { singleton(&[]) } else { Space::new() };
                drop(v68_9);
                let v68_12: Space = if (v68_10).is_empty() { Space::new() } else {
                  let v70_6: Path = concat_path(&(v67_6),&(v67_7_head));
                  let v70_11: Space = routine_9(c, &(v70_6), &(v67_7_tail).make_space());
                  drop(v70_6);
                  compose(&(v68_10),&(v70_11))
                };
                drop(v68_10);
                let v68_13: Space = unite(&(v68_8),&(v68_12));
                v67_7.join_into((v68_13).clone());
                }
                v67_7_cursor.ascend(1);
              }
              drop(v67_7_cursor);
              compose(&(v66_5),&(v67_7))
            };
            drop(v66_5);
            let v66_9: Space = intersect(&(*CONSTANT_12),&(v66_2));
            drop(v66_2);
            let v66_10: Space = if has_head(&(v66_9)) { singleton(&[]) } else { Space::new() };
            drop(v66_9);
            let v66_12: Space = if (v66_10).is_empty() { Space::new() } else {
              let v71_6: Path = concat_path(&(v54_82_head),&(v65_6_head));
              let mut v71_11 = Space::new();
              let mut v71_11_cursor = (v65_6_tail).read_zipper();
              for v71_11_byte in v71_11_cursor.child_mask().iter() {
                v71_11_cursor.descend_to_byte(v71_11_byte);
                {
                let v71_11_tail = v71_11_cursor.fork_read_zipper();
                let v71_11_head = Path::from_slice(&[v71_11_byte]);
                let v72_2: Space = singleton(&(v71_11_head));
                let v72_3: Space = intersect(&(*CONSTANT_12),&(v72_2));
                let v72_4: Space = if has_head(&(v72_3)) { singleton(&[]) } else { Space::new() };
                drop(v72_3);
                let v72_5: Space = subtract(&(*CONSTANT_0),&(v72_4));
                drop(v72_4);
                let v72_8: Space = if (v72_5).is_empty() { Space::new() } else {
                  let v73_6: Path = concat_path(&(v71_6),&(v71_11_head));
                  let v73_7: Space = routine_8(c, &(v73_6), &(v71_11_tail).make_space());
                  compose(&(v72_5),&(v73_7))
                };
                drop(v72_5);
                let v72_9: Space = intersect(&(*CONSTANT_12),&(v72_2));
                drop(v72_2);
                let v72_10: Space = if has_head(&(v72_9)) { singleton(&[]) } else { Space::new() };
                drop(v72_9);
                let v72_12: Space = if (v72_10).is_empty() { Space::new() } else {
                  let v74_6: Path = concat_path(&(v71_6),&(v71_11_head));
                  let v74_11: Space = routine_10(c, &(v74_6), &(v71_11_tail).make_space());
                  drop(v74_6);
                  compose(&(v72_10),&(v74_11))
                };
                drop(v72_10);
                let v72_13: Space = unite(&(v72_8),&(v72_12));
                v71_11.join_into((v72_13).clone());
                }
                v71_11_cursor.ascend(1);
              }
              drop(v71_11_cursor);
              drop(v71_6);
              compose(&(v66_10),&(v71_11))
            };
            drop(v66_10);
            let v66_13: Space = unite(&(v66_8),&(v66_12));
            v65_6.join_into((v66_13).clone());
            }
            v65_6_cursor.ascend(1);
          }
          drop(v65_6_cursor);
          compose(&(v64_5),&(v65_6))
        };
        drop(v64_5);
        let v64_8: Space = intersect(&(*CONSTANT_12),&(v64_2));
        drop(v64_2);
        let v64_9: Space = if has_head(&(v64_8)) { singleton(&[]) } else { Space::new() };
        drop(v64_8);
        let v64_11: Space = if (v64_9).is_empty() { Space::new() } else {
          let mut v75_10 = Space::new();
          let mut v75_10_cursor = (v54_82_tail).read_zipper();
          for v75_10_byte in v75_10_cursor.child_mask().iter() {
            v75_10_cursor.descend_to_byte(v75_10_byte);
            {
            let v75_10_tail = v75_10_cursor.fork_read_zipper();
            let v75_10_head = Path::from_slice(&[v75_10_byte]);
            let v76_2: Space = singleton(&(v75_10_head));
            let v76_3: Space = intersect(&(*CONSTANT_12),&(v76_2));
            let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
            drop(v76_3);
            let v76_5: Space = subtract(&(*CONSTANT_0),&(v76_4));
            drop(v76_4);
            let v76_8: Space = if (v76_5).is_empty() { Space::new() } else {
              let v77_6: Path = concat_path(&(v54_82_head),&(v75_10_head));
              let mut v77_7 = Space::new();
              let mut v77_7_cursor = (v75_10_tail).read_zipper();
              for v77_7_byte in v77_7_cursor.child_mask().iter() {
                v77_7_cursor.descend_to_byte(v77_7_byte);
                {
                let v77_7_tail = v77_7_cursor.fork_read_zipper();
                let v77_7_head = Path::from_slice(&[v77_7_byte]);
                let v78_2: Space = singleton(&(v77_7_head));
                let v78_3: Space = intersect(&(*CONSTANT_12),&(v78_2));
                let v78_4: Space = if has_head(&(v78_3)) { singleton(&[]) } else { Space::new() };
                drop(v78_3);
                let v78_5: Space = subtract(&(*CONSTANT_0),&(v78_4));
                drop(v78_4);
                let v78_8: Space = if (v78_5).is_empty() { Space::new() } else {
                  let v79_6: Path = concat_path(&(v77_6),&(v77_7_head));
                  let v79_7: Space = routine_8(c, &(v79_6), &(v77_7_tail).make_space());
                  compose(&(v78_5),&(v79_7))
                };
                drop(v78_5);
                let v78_9: Space = intersect(&(*CONSTANT_12),&(v78_2));
                drop(v78_2);
                let v78_10: Space = if has_head(&(v78_9)) { singleton(&[]) } else { Space::new() };
                drop(v78_9);
                let v78_12: Space = if (v78_10).is_empty() { Space::new() } else {
                  let v80_6: Path = concat_path(&(v77_6),&(v77_7_head));
                  let v80_11: Space = routine_9(c, &(v80_6), &(v77_7_tail).make_space());
                  drop(v80_6);
                  compose(&(v78_10),&(v80_11))
                };
                drop(v78_10);
                let v78_13: Space = unite(&(v78_8),&(v78_12));
                v77_7.join_into((v78_13).clone());
                }
                v77_7_cursor.ascend(1);
              }
              drop(v77_7_cursor);
              compose(&(v76_5),&(v77_7))
            };
            drop(v76_5);
            let v76_9: Space = intersect(&(*CONSTANT_12),&(v76_2));
            drop(v76_2);
            let v76_10: Space = if has_head(&(v76_9)) { singleton(&[]) } else { Space::new() };
            drop(v76_9);
            let v81_6: Path = concat_path(&(v54_82_head),&(v75_10_head));
            let v76_11: Space = singleton(&(v81_6));
            let v76_12: Space = compose(&(v76_10),&(v76_11));
            drop(v76_10);
            drop(v76_11);
            let v76_13: Space = unite(&(v76_8),&(v76_12));
            drop(v76_12);
            v75_10.join_into((v76_13).clone());
            }
            v75_10_cursor.ascend(1);
          }
          drop(v75_10_cursor);
          compose(&(v64_9),&(v75_10))
        };
        drop(v64_9);
        let v64_12: Space = unite(&(v64_7),&(v64_11));
        v54_82.join_into((v64_12).clone());
        }
        v54_82_cursor.ascend(1);
      }
      drop(v54_82_cursor);
      let v54_83: Space = unite(&(v54_69),&(v54_82));
      let v54_84: Space = routine_17(c, &(v0_155_head), &(v0_155_tail).make_space(), &(v54_58), &(*CONSTANT_13), &(v54_83));
      compose(&(v25_46),&(v54_84))
    };
    drop(v25_46);
    let v25_86: Space = unite(&(v25_44),&(v25_85));
    v0_155.join_into((v25_86).clone());
    }
    v0_155_cursor.ascend(1);
  }
  drop(v0_155_cursor);

((v0_155).clone(),(v0_22).clone(),(v0_44).clone(),(v0_63).clone(),(v0_64).clone(),(v0_65).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &Path,capture_1: &Space,capture_2: &Space,capture_3: &Space) -> (Space,Space,Space,Space,Space,Space,Space,) {
  let v358_5: Space = singleton(&(*capture_0));
  let mut v358_24: Space = (v358_5).clone();
  loop {
    let v359_1: Space = intersect(&(v358_24),&(*capture_3));
    let v359_2: Space = restrict_to(&(*capture_1),&(v359_1));
    drop(v359_1);
    let mut v359_3 = Space::new();
    let mut v359_3_cursor = (v359_2).read_zipper();
    for v359_3_byte in v359_3_cursor.child_mask().iter() {
      v359_3_cursor.descend_to_byte(v359_3_byte);
      {
      let v359_3_tail = v359_3_cursor.fork_read_zipper();
      let v359_3_head = Path::from_slice(&[v359_3_byte]);
      let v360_2: Space = singleton(&(v359_3_head));
      let v360_3: Space = intersect(&(*CONSTANT_12),&(v360_2));
      let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
      drop(v360_3);
      let v360_5: Space = subtract(&(*CONSTANT_0),&(v360_4));
      drop(v360_4);
      let v360_7: Space = if (v360_5).is_empty() { Space::new() } else {
        let mut v361_6 = Space::new();
        let mut v361_6_cursor = (v359_3_tail).read_zipper();
        for v361_6_byte in v361_6_cursor.child_mask().iter() {
          v361_6_cursor.descend_to_byte(v361_6_byte);
          {
          let v361_6_tail = v361_6_cursor.fork_read_zipper();
          let v361_6_head = Path::from_slice(&[v361_6_byte]);
          let v362_2: Space = singleton(&(v361_6_head));
          let v362_3: Space = intersect(&(*CONSTANT_12),&(v362_2));
          let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
          drop(v362_3);
          let v362_5: Space = subtract(&(*CONSTANT_0),&(v362_4));
          drop(v362_4);
          let v362_8: Space = if (v362_5).is_empty() { Space::new() } else {
            let v363_6: Path = concat_path(&(v359_3_head),&(v361_6_head));
            let mut v363_7 = Space::new();
            let mut v363_7_cursor = (v361_6_tail).read_zipper();
            for v363_7_byte in v363_7_cursor.child_mask().iter() {
              v363_7_cursor.descend_to_byte(v363_7_byte);
              {
              let v363_7_tail = v363_7_cursor.fork_read_zipper();
              let v363_7_head = Path::from_slice(&[v363_7_byte]);
              let v364_2: Space = singleton(&(v363_7_head));
              let v364_3: Space = intersect(&(*CONSTANT_12),&(v364_2));
              let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
              drop(v364_3);
              let v364_5: Space = subtract(&(*CONSTANT_0),&(v364_4));
              drop(v364_4);
              let v364_8: Space = if (v364_5).is_empty() { Space::new() } else {
                let v365_6: Path = concat_path(&(v363_6),&(v363_7_head));
                let v365_7: Space = routine_41(c, &(v365_6), &(v363_7_tail).make_space());
                compose(&(v364_5),&(v365_7))
              };
              drop(v364_5);
              let v364_9: Space = intersect(&(*CONSTANT_12),&(v364_2));
              drop(v364_2);
              let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
              drop(v364_9);
              let v364_12: Space = if (v364_10).is_empty() { Space::new() } else {
                let v366_6: Path = concat_path(&(v363_6),&(v363_7_head));
                let v366_11: Space = routine_42(c, &(v366_6), &(v363_7_tail).make_space());
                drop(v366_6);
                compose(&(v364_10),&(v366_11))
              };
              drop(v364_10);
              let v364_13: Space = unite(&(v364_8),&(v364_12));
              v363_7.join_into((v364_13).clone());
              }
              v363_7_cursor.ascend(1);
            }
            drop(v363_7_cursor);
            compose(&(v362_5),&(v363_7))
          };
          drop(v362_5);
          let v362_9: Space = intersect(&(*CONSTANT_12),&(v362_2));
          drop(v362_2);
          let v362_10: Space = if has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
          drop(v362_9);
          let v362_12: Space = if (v362_10).is_empty() { Space::new() } else {
            let v367_6: Path = concat_path(&(v359_3_head),&(v361_6_head));
            let mut v367_11 = Space::new();
            let mut v367_11_cursor = (v361_6_tail).read_zipper();
            for v367_11_byte in v367_11_cursor.child_mask().iter() {
              v367_11_cursor.descend_to_byte(v367_11_byte);
              {
              let v367_11_tail = v367_11_cursor.fork_read_zipper();
              let v367_11_head = Path::from_slice(&[v367_11_byte]);
              let v368_2: Space = singleton(&(v367_11_head));
              let v368_3: Space = intersect(&(*CONSTANT_12),&(v368_2));
              let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
              drop(v368_3);
              let v368_5: Space = subtract(&(*CONSTANT_0),&(v368_4));
              drop(v368_4);
              let v368_8: Space = if (v368_5).is_empty() { Space::new() } else {
                let v369_6: Path = concat_path(&(v367_6),&(v367_11_head));
                let v369_7: Space = routine_41(c, &(v369_6), &(v367_11_tail).make_space());
                compose(&(v368_5),&(v369_7))
              };
              drop(v368_5);
              let v368_9: Space = intersect(&(*CONSTANT_12),&(v368_2));
              drop(v368_2);
              let v368_10: Space = if has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
              drop(v368_9);
              let v368_12: Space = if (v368_10).is_empty() { Space::new() } else {
                let v370_6: Path = concat_path(&(v367_6),&(v367_11_head));
                let v370_11: Space = routine_43(c, &(v370_6), &(v367_11_tail).make_space());
                drop(v370_6);
                compose(&(v368_10),&(v370_11))
              };
              drop(v368_10);
              let v368_13: Space = unite(&(v368_8),&(v368_12));
              v367_11.join_into((v368_13).clone());
              }
              v367_11_cursor.ascend(1);
            }
            drop(v367_11_cursor);
            drop(v367_6);
            compose(&(v362_10),&(v367_11))
          };
          drop(v362_10);
          let v362_13: Space = unite(&(v362_8),&(v362_12));
          v361_6.join_into((v362_13).clone());
          }
          v361_6_cursor.ascend(1);
        }
        drop(v361_6_cursor);
        compose(&(v360_5),&(v361_6))
      };
      drop(v360_5);
      let v360_8: Space = intersect(&(*CONSTANT_12),&(v360_2));
      drop(v360_2);
      let v360_9: Space = if has_head(&(v360_8)) { singleton(&[]) } else { Space::new() };
      drop(v360_8);
      let v360_11: Space = if (v360_9).is_empty() { Space::new() } else {
        let mut v371_10 = Space::new();
        let mut v371_10_cursor = (v359_3_tail).read_zipper();
        for v371_10_byte in v371_10_cursor.child_mask().iter() {
          v371_10_cursor.descend_to_byte(v371_10_byte);
          {
          let v371_10_tail = v371_10_cursor.fork_read_zipper();
          let v371_10_head = Path::from_slice(&[v371_10_byte]);
          let v372_2: Space = singleton(&(v371_10_head));
          let v372_3: Space = intersect(&(*CONSTANT_12),&(v372_2));
          let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
          drop(v372_3);
          let v372_5: Space = subtract(&(*CONSTANT_0),&(v372_4));
          drop(v372_4);
          let v372_8: Space = if (v372_5).is_empty() { Space::new() } else {
            let v373_6: Path = concat_path(&(v359_3_head),&(v371_10_head));
            let mut v373_7 = Space::new();
            let mut v373_7_cursor = (v371_10_tail).read_zipper();
            for v373_7_byte in v373_7_cursor.child_mask().iter() {
              v373_7_cursor.descend_to_byte(v373_7_byte);
              {
              let v373_7_tail = v373_7_cursor.fork_read_zipper();
              let v373_7_head = Path::from_slice(&[v373_7_byte]);
              let v374_2: Space = singleton(&(v373_7_head));
              let v374_3: Space = intersect(&(*CONSTANT_12),&(v374_2));
              let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
              drop(v374_3);
              let v374_5: Space = subtract(&(*CONSTANT_0),&(v374_4));
              drop(v374_4);
              let v374_8: Space = if (v374_5).is_empty() { Space::new() } else {
                let v375_6: Path = concat_path(&(v373_6),&(v373_7_head));
                let v375_7: Space = routine_41(c, &(v375_6), &(v373_7_tail).make_space());
                compose(&(v374_5),&(v375_7))
              };
              drop(v374_5);
              let v374_9: Space = intersect(&(*CONSTANT_12),&(v374_2));
              drop(v374_2);
              let v374_10: Space = if has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
              drop(v374_9);
              let v374_12: Space = if (v374_10).is_empty() { Space::new() } else {
                let v376_6: Path = concat_path(&(v373_6),&(v373_7_head));
                let v376_11: Space = routine_42(c, &(v376_6), &(v373_7_tail).make_space());
                drop(v376_6);
                compose(&(v374_10),&(v376_11))
              };
              drop(v374_10);
              let v374_13: Space = unite(&(v374_8),&(v374_12));
              v373_7.join_into((v374_13).clone());
              }
              v373_7_cursor.ascend(1);
            }
            drop(v373_7_cursor);
            drop(v373_6);
            compose(&(v372_5),&(v373_7))
          };
          drop(v372_5);
          let v372_9: Space = intersect(&(*CONSTANT_12),&(v372_2));
          drop(v372_2);
          let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
          drop(v372_9);
          let v372_11: Space = compose(&(v372_10),&(v371_10_tail));
          drop(v372_10);
          let v372_12: Space = unite(&(v372_8),&(v372_11));
          drop(v372_11);
          v371_10.join_into((v372_12).clone());
          }
          v371_10_cursor.ascend(1);
        }
        drop(v371_10_cursor);
        compose(&(v360_9),&(v371_10))
      };
      drop(v360_9);
      let v360_12: Space = unite(&(v360_7),&(v360_11));
      v359_3.join_into((v360_12).clone());
      }
      v359_3_cursor.ascend(1);
    }
    drop(v359_3_cursor);
    drop(v359_2);
    let v359_4: Space = unite(&(v359_3),&(v358_24));
    let v359_5: Space = intersect(&(v359_4),&(*capture_3));
    if !v358_24.join_into((v359_5).clone()).is_element() { break; }
  }
  let mut v358_43: Space = (v358_5).clone();
  loop {
    let v377_1: Space = intersect(&(v358_43),&(*capture_3));
    let v377_2: Space = restrict_to(&(*capture_2),&(v377_1));
    drop(v377_1);
    let mut v377_3 = Space::new();
    let mut v377_3_cursor = (v377_2).read_zipper();
    for v377_3_byte in v377_3_cursor.child_mask().iter() {
      v377_3_cursor.descend_to_byte(v377_3_byte);
      {
      let v377_3_tail = v377_3_cursor.fork_read_zipper();
      let v377_3_head = Path::from_slice(&[v377_3_byte]);
      let v378_2: Space = singleton(&(v377_3_head));
      let v378_3: Space = intersect(&(*CONSTANT_12),&(v378_2));
      let v378_4: Space = if has_head(&(v378_3)) { singleton(&[]) } else { Space::new() };
      drop(v378_3);
      let v378_5: Space = subtract(&(*CONSTANT_0),&(v378_4));
      drop(v378_4);
      let v378_7: Space = if (v378_5).is_empty() { Space::new() } else {
        let mut v379_6 = Space::new();
        let mut v379_6_cursor = (v377_3_tail).read_zipper();
        for v379_6_byte in v379_6_cursor.child_mask().iter() {
          v379_6_cursor.descend_to_byte(v379_6_byte);
          {
          let v379_6_tail = v379_6_cursor.fork_read_zipper();
          let v379_6_head = Path::from_slice(&[v379_6_byte]);
          let v380_2: Space = singleton(&(v379_6_head));
          let v380_3: Space = intersect(&(*CONSTANT_12),&(v380_2));
          let v380_4: Space = if has_head(&(v380_3)) { singleton(&[]) } else { Space::new() };
          drop(v380_3);
          let v380_5: Space = subtract(&(*CONSTANT_0),&(v380_4));
          drop(v380_4);
          let v380_8: Space = if (v380_5).is_empty() { Space::new() } else {
            let v381_6: Path = concat_path(&(v377_3_head),&(v379_6_head));
            let mut v381_7 = Space::new();
            let mut v381_7_cursor = (v379_6_tail).read_zipper();
            for v381_7_byte in v381_7_cursor.child_mask().iter() {
              v381_7_cursor.descend_to_byte(v381_7_byte);
              {
              let v381_7_tail = v381_7_cursor.fork_read_zipper();
              let v381_7_head = Path::from_slice(&[v381_7_byte]);
              let v382_2: Space = singleton(&(v381_7_head));
              let v382_3: Space = intersect(&(*CONSTANT_12),&(v382_2));
              let v382_4: Space = if has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
              drop(v382_3);
              let v382_5: Space = subtract(&(*CONSTANT_0),&(v382_4));
              drop(v382_4);
              let v382_8: Space = if (v382_5).is_empty() { Space::new() } else {
                let v383_6: Path = concat_path(&(v381_6),&(v381_7_head));
                let v383_7: Space = routine_41(c, &(v383_6), &(v381_7_tail).make_space());
                compose(&(v382_5),&(v383_7))
              };
              drop(v382_5);
              let v382_9: Space = intersect(&(*CONSTANT_12),&(v382_2));
              drop(v382_2);
              let v382_10: Space = if has_head(&(v382_9)) { singleton(&[]) } else { Space::new() };
              drop(v382_9);
              let v382_12: Space = if (v382_10).is_empty() { Space::new() } else {
                let v384_6: Path = concat_path(&(v381_6),&(v381_7_head));
                let v384_11: Space = routine_42(c, &(v384_6), &(v381_7_tail).make_space());
                drop(v384_6);
                compose(&(v382_10),&(v384_11))
              };
              drop(v382_10);
              let v382_13: Space = unite(&(v382_8),&(v382_12));
              v381_7.join_into((v382_13).clone());
              }
              v381_7_cursor.ascend(1);
            }
            drop(v381_7_cursor);
            compose(&(v380_5),&(v381_7))
          };
          drop(v380_5);
          let v380_9: Space = intersect(&(*CONSTANT_12),&(v380_2));
          drop(v380_2);
          let v380_10: Space = if has_head(&(v380_9)) { singleton(&[]) } else { Space::new() };
          drop(v380_9);
          let v380_12: Space = if (v380_10).is_empty() { Space::new() } else {
            let v385_6: Path = concat_path(&(v377_3_head),&(v379_6_head));
            let mut v385_11 = Space::new();
            let mut v385_11_cursor = (v379_6_tail).read_zipper();
            for v385_11_byte in v385_11_cursor.child_mask().iter() {
              v385_11_cursor.descend_to_byte(v385_11_byte);
              {
              let v385_11_tail = v385_11_cursor.fork_read_zipper();
              let v385_11_head = Path::from_slice(&[v385_11_byte]);
              let v386_2: Space = singleton(&(v385_11_head));
              let v386_3: Space = intersect(&(*CONSTANT_12),&(v386_2));
              let v386_4: Space = if has_head(&(v386_3)) { singleton(&[]) } else { Space::new() };
              drop(v386_3);
              let v386_5: Space = subtract(&(*CONSTANT_0),&(v386_4));
              drop(v386_4);
              let v386_8: Space = if (v386_5).is_empty() { Space::new() } else {
                let v387_6: Path = concat_path(&(v385_6),&(v385_11_head));
                let v387_7: Space = routine_41(c, &(v387_6), &(v385_11_tail).make_space());
                compose(&(v386_5),&(v387_7))
              };
              drop(v386_5);
              let v386_9: Space = intersect(&(*CONSTANT_12),&(v386_2));
              drop(v386_2);
              let v386_10: Space = if has_head(&(v386_9)) { singleton(&[]) } else { Space::new() };
              drop(v386_9);
              let v386_12: Space = if (v386_10).is_empty() { Space::new() } else {
                let v388_6: Path = concat_path(&(v385_6),&(v385_11_head));
                let v388_11: Space = routine_43(c, &(v388_6), &(v385_11_tail).make_space());
                drop(v388_6);
                compose(&(v386_10),&(v388_11))
              };
              drop(v386_10);
              let v386_13: Space = unite(&(v386_8),&(v386_12));
              v385_11.join_into((v386_13).clone());
              }
              v385_11_cursor.ascend(1);
            }
            drop(v385_11_cursor);
            drop(v385_6);
            compose(&(v380_10),&(v385_11))
          };
          drop(v380_10);
          let v380_13: Space = unite(&(v380_8),&(v380_12));
          v379_6.join_into((v380_13).clone());
          }
          v379_6_cursor.ascend(1);
        }
        drop(v379_6_cursor);
        compose(&(v378_5),&(v379_6))
      };
      drop(v378_5);
      let v378_8: Space = intersect(&(*CONSTANT_12),&(v378_2));
      drop(v378_2);
      let v378_9: Space = if has_head(&(v378_8)) { singleton(&[]) } else { Space::new() };
      drop(v378_8);
      let v378_11: Space = if (v378_9).is_empty() { Space::new() } else {
        let mut v389_10 = Space::new();
        let mut v389_10_cursor = (v377_3_tail).read_zipper();
        for v389_10_byte in v389_10_cursor.child_mask().iter() {
          v389_10_cursor.descend_to_byte(v389_10_byte);
          {
          let v389_10_tail = v389_10_cursor.fork_read_zipper();
          let v389_10_head = Path::from_slice(&[v389_10_byte]);
          let v390_2: Space = singleton(&(v389_10_head));
          let v390_3: Space = intersect(&(*CONSTANT_12),&(v390_2));
          let v390_4: Space = if has_head(&(v390_3)) { singleton(&[]) } else { Space::new() };
          drop(v390_3);
          let v390_5: Space = subtract(&(*CONSTANT_0),&(v390_4));
          drop(v390_4);
          let v390_8: Space = if (v390_5).is_empty() { Space::new() } else {
            let v391_6: Path = concat_path(&(v377_3_head),&(v389_10_head));
            let mut v391_7 = Space::new();
            let mut v391_7_cursor = (v389_10_tail).read_zipper();
            for v391_7_byte in v391_7_cursor.child_mask().iter() {
              v391_7_cursor.descend_to_byte(v391_7_byte);
              {
              let v391_7_tail = v391_7_cursor.fork_read_zipper();
              let v391_7_head = Path::from_slice(&[v391_7_byte]);
              let v392_2: Space = singleton(&(v391_7_head));
              let v392_3: Space = intersect(&(*CONSTANT_12),&(v392_2));
              let v392_4: Space = if has_head(&(v392_3)) { singleton(&[]) } else { Space::new() };
              drop(v392_3);
              let v392_5: Space = subtract(&(*CONSTANT_0),&(v392_4));
              drop(v392_4);
              let v392_8: Space = if (v392_5).is_empty() { Space::new() } else {
                let v393_6: Path = concat_path(&(v391_6),&(v391_7_head));
                let v393_7: Space = routine_41(c, &(v393_6), &(v391_7_tail).make_space());
                compose(&(v392_5),&(v393_7))
              };
              drop(v392_5);
              let v392_9: Space = intersect(&(*CONSTANT_12),&(v392_2));
              drop(v392_2);
              let v392_10: Space = if has_head(&(v392_9)) { singleton(&[]) } else { Space::new() };
              drop(v392_9);
              let v392_12: Space = if (v392_10).is_empty() { Space::new() } else {
                let v394_6: Path = concat_path(&(v391_6),&(v391_7_head));
                let v394_11: Space = routine_42(c, &(v394_6), &(v391_7_tail).make_space());
                drop(v394_6);
                compose(&(v392_10),&(v394_11))
              };
              drop(v392_10);
              let v392_13: Space = unite(&(v392_8),&(v392_12));
              v391_7.join_into((v392_13).clone());
              }
              v391_7_cursor.ascend(1);
            }
            drop(v391_7_cursor);
            drop(v391_6);
            compose(&(v390_5),&(v391_7))
          };
          drop(v390_5);
          let v390_9: Space = intersect(&(*CONSTANT_12),&(v390_2));
          drop(v390_2);
          let v390_10: Space = if has_head(&(v390_9)) { singleton(&[]) } else { Space::new() };
          drop(v390_9);
          let v390_11: Space = compose(&(v390_10),&(v389_10_tail));
          drop(v390_10);
          let v390_12: Space = unite(&(v390_8),&(v390_11));
          drop(v390_11);
          v389_10.join_into((v390_12).clone());
          }
          v389_10_cursor.ascend(1);
        }
        drop(v389_10_cursor);
        compose(&(v378_9),&(v389_10))
      };
      drop(v378_9);
      let v378_12: Space = unite(&(v378_7),&(v378_11));
      v377_3.join_into((v378_12).clone());
      }
      v377_3_cursor.ascend(1);
    }
    drop(v377_3_cursor);
    drop(v377_2);
    let v377_4: Space = unite(&(v377_3),&(v358_43));
    let v377_5: Space = intersect(&(v377_4),&(*capture_3));
    if !v358_43.join_into((v377_5).clone()).is_element() { break; }
  }
  let v358_44: Space = intersect(&(v358_24),&(v358_43));
  let v358_45: Space = subtract(&(v358_44),&(v358_5));
  let v358_46: Space = wrap(&(v358_45),&(*capture_0));
  let mut v358_65: Space = (v358_5).clone();
  loop {
    let v395_1: Space = intersect(&(v358_65),&(*capture_3));
    let v395_2: Space = restrict_to(&(*capture_2),&(v395_1));
    drop(v395_1);
    let mut v395_3 = Space::new();
    let mut v395_3_cursor = (v395_2).read_zipper();
    for v395_3_byte in v395_3_cursor.child_mask().iter() {
      v395_3_cursor.descend_to_byte(v395_3_byte);
      {
      let v395_3_tail = v395_3_cursor.fork_read_zipper();
      let v395_3_head = Path::from_slice(&[v395_3_byte]);
      let v396_2: Space = singleton(&(v395_3_head));
      let v396_3: Space = intersect(&(*CONSTANT_12),&(v396_2));
      let v396_4: Space = if has_head(&(v396_3)) { singleton(&[]) } else { Space::new() };
      drop(v396_3);
      let v396_5: Space = subtract(&(*CONSTANT_0),&(v396_4));
      drop(v396_4);
      let v396_7: Space = if (v396_5).is_empty() { Space::new() } else {
        let mut v397_6 = Space::new();
        let mut v397_6_cursor = (v395_3_tail).read_zipper();
        for v397_6_byte in v397_6_cursor.child_mask().iter() {
          v397_6_cursor.descend_to_byte(v397_6_byte);
          {
          let v397_6_tail = v397_6_cursor.fork_read_zipper();
          let v397_6_head = Path::from_slice(&[v397_6_byte]);
          let v398_2: Space = singleton(&(v397_6_head));
          let v398_3: Space = intersect(&(*CONSTANT_12),&(v398_2));
          let v398_4: Space = if has_head(&(v398_3)) { singleton(&[]) } else { Space::new() };
          drop(v398_3);
          let v398_5: Space = subtract(&(*CONSTANT_0),&(v398_4));
          drop(v398_4);
          let v398_8: Space = if (v398_5).is_empty() { Space::new() } else {
            let v399_6: Path = concat_path(&(v395_3_head),&(v397_6_head));
            let mut v399_7 = Space::new();
            let mut v399_7_cursor = (v397_6_tail).read_zipper();
            for v399_7_byte in v399_7_cursor.child_mask().iter() {
              v399_7_cursor.descend_to_byte(v399_7_byte);
              {
              let v399_7_tail = v399_7_cursor.fork_read_zipper();
              let v399_7_head = Path::from_slice(&[v399_7_byte]);
              let v400_2: Space = singleton(&(v399_7_head));
              let v400_3: Space = intersect(&(*CONSTANT_12),&(v400_2));
              let v400_4: Space = if has_head(&(v400_3)) { singleton(&[]) } else { Space::new() };
              drop(v400_3);
              let v400_5: Space = subtract(&(*CONSTANT_0),&(v400_4));
              drop(v400_4);
              let v400_8: Space = if (v400_5).is_empty() { Space::new() } else {
                let v401_6: Path = concat_path(&(v399_6),&(v399_7_head));
                let v401_7: Space = routine_41(c, &(v401_6), &(v399_7_tail).make_space());
                compose(&(v400_5),&(v401_7))
              };
              drop(v400_5);
              let v400_9: Space = intersect(&(*CONSTANT_12),&(v400_2));
              drop(v400_2);
              let v400_10: Space = if has_head(&(v400_9)) { singleton(&[]) } else { Space::new() };
              drop(v400_9);
              let v400_12: Space = if (v400_10).is_empty() { Space::new() } else {
                let v402_6: Path = concat_path(&(v399_6),&(v399_7_head));
                let v402_11: Space = routine_42(c, &(v402_6), &(v399_7_tail).make_space());
                drop(v402_6);
                compose(&(v400_10),&(v402_11))
              };
              drop(v400_10);
              let v400_13: Space = unite(&(v400_8),&(v400_12));
              v399_7.join_into((v400_13).clone());
              }
              v399_7_cursor.ascend(1);
            }
            drop(v399_7_cursor);
            compose(&(v398_5),&(v399_7))
          };
          drop(v398_5);
          let v398_9: Space = intersect(&(*CONSTANT_12),&(v398_2));
          drop(v398_2);
          let v398_10: Space = if has_head(&(v398_9)) { singleton(&[]) } else { Space::new() };
          drop(v398_9);
          let v398_12: Space = if (v398_10).is_empty() { Space::new() } else {
            let v403_6: Path = concat_path(&(v395_3_head),&(v397_6_head));
            let mut v403_11 = Space::new();
            let mut v403_11_cursor = (v397_6_tail).read_zipper();
            for v403_11_byte in v403_11_cursor.child_mask().iter() {
              v403_11_cursor.descend_to_byte(v403_11_byte);
              {
              let v403_11_tail = v403_11_cursor.fork_read_zipper();
              let v403_11_head = Path::from_slice(&[v403_11_byte]);
              let v404_2: Space = singleton(&(v403_11_head));
              let v404_3: Space = intersect(&(*CONSTANT_12),&(v404_2));
              let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
              drop(v404_3);
              let v404_5: Space = subtract(&(*CONSTANT_0),&(v404_4));
              drop(v404_4);
              let v404_8: Space = if (v404_5).is_empty() { Space::new() } else {
                let v405_6: Path = concat_path(&(v403_6),&(v403_11_head));
                let v405_7: Space = routine_41(c, &(v405_6), &(v403_11_tail).make_space());
                compose(&(v404_5),&(v405_7))
              };
              drop(v404_5);
              let v404_9: Space = intersect(&(*CONSTANT_12),&(v404_2));
              drop(v404_2);
              let v404_10: Space = if has_head(&(v404_9)) { singleton(&[]) } else { Space::new() };
              drop(v404_9);
              let v404_12: Space = if (v404_10).is_empty() { Space::new() } else {
                let v406_6: Path = concat_path(&(v403_6),&(v403_11_head));
                let v406_11: Space = routine_43(c, &(v406_6), &(v403_11_tail).make_space());
                drop(v406_6);
                compose(&(v404_10),&(v406_11))
              };
              drop(v404_10);
              let v404_13: Space = unite(&(v404_8),&(v404_12));
              v403_11.join_into((v404_13).clone());
              }
              v403_11_cursor.ascend(1);
            }
            drop(v403_11_cursor);
            drop(v403_6);
            compose(&(v398_10),&(v403_11))
          };
          drop(v398_10);
          let v398_13: Space = unite(&(v398_8),&(v398_12));
          v397_6.join_into((v398_13).clone());
          }
          v397_6_cursor.ascend(1);
        }
        drop(v397_6_cursor);
        compose(&(v396_5),&(v397_6))
      };
      drop(v396_5);
      let v396_8: Space = intersect(&(*CONSTANT_12),&(v396_2));
      drop(v396_2);
      let v396_9: Space = if has_head(&(v396_8)) { singleton(&[]) } else { Space::new() };
      drop(v396_8);
      let v396_11: Space = if (v396_9).is_empty() { Space::new() } else {
        let mut v407_10 = Space::new();
        let mut v407_10_cursor = (v395_3_tail).read_zipper();
        for v407_10_byte in v407_10_cursor.child_mask().iter() {
          v407_10_cursor.descend_to_byte(v407_10_byte);
          {
          let v407_10_tail = v407_10_cursor.fork_read_zipper();
          let v407_10_head = Path::from_slice(&[v407_10_byte]);
          let v408_2: Space = singleton(&(v407_10_head));
          let v408_3: Space = intersect(&(*CONSTANT_12),&(v408_2));
          let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
          drop(v408_3);
          let v408_5: Space = subtract(&(*CONSTANT_0),&(v408_4));
          drop(v408_4);
          let v408_8: Space = if (v408_5).is_empty() { Space::new() } else {
            let v409_6: Path = concat_path(&(v395_3_head),&(v407_10_head));
            let mut v409_7 = Space::new();
            let mut v409_7_cursor = (v407_10_tail).read_zipper();
            for v409_7_byte in v409_7_cursor.child_mask().iter() {
              v409_7_cursor.descend_to_byte(v409_7_byte);
              {
              let v409_7_tail = v409_7_cursor.fork_read_zipper();
              let v409_7_head = Path::from_slice(&[v409_7_byte]);
              let v410_2: Space = singleton(&(v409_7_head));
              let v410_3: Space = intersect(&(*CONSTANT_12),&(v410_2));
              let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
              drop(v410_3);
              let v410_5: Space = subtract(&(*CONSTANT_0),&(v410_4));
              drop(v410_4);
              let v410_8: Space = if (v410_5).is_empty() { Space::new() } else {
                let v411_6: Path = concat_path(&(v409_6),&(v409_7_head));
                let v411_7: Space = routine_41(c, &(v411_6), &(v409_7_tail).make_space());
                compose(&(v410_5),&(v411_7))
              };
              drop(v410_5);
              let v410_9: Space = intersect(&(*CONSTANT_12),&(v410_2));
              drop(v410_2);
              let v410_10: Space = if has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
              drop(v410_9);
              let v410_12: Space = if (v410_10).is_empty() { Space::new() } else {
                let v412_6: Path = concat_path(&(v409_6),&(v409_7_head));
                let v412_11: Space = routine_42(c, &(v412_6), &(v409_7_tail).make_space());
                drop(v412_6);
                compose(&(v410_10),&(v412_11))
              };
              drop(v410_10);
              let v410_13: Space = unite(&(v410_8),&(v410_12));
              v409_7.join_into((v410_13).clone());
              }
              v409_7_cursor.ascend(1);
            }
            drop(v409_7_cursor);
            drop(v409_6);
            compose(&(v408_5),&(v409_7))
          };
          drop(v408_5);
          let v408_9: Space = intersect(&(*CONSTANT_12),&(v408_2));
          drop(v408_2);
          let v408_10: Space = if has_head(&(v408_9)) { singleton(&[]) } else { Space::new() };
          drop(v408_9);
          let v408_11: Space = compose(&(v408_10),&(v407_10_tail));
          drop(v408_10);
          let v408_12: Space = unite(&(v408_8),&(v408_11));
          drop(v408_11);
          v407_10.join_into((v408_12).clone());
          }
          v407_10_cursor.ascend(1);
        }
        drop(v407_10_cursor);
        compose(&(v396_9),&(v407_10))
      };
      drop(v396_9);
      let v396_12: Space = unite(&(v396_7),&(v396_11));
      v395_3.join_into((v396_12).clone());
      }
      v395_3_cursor.ascend(1);
    }
    drop(v395_3_cursor);
    drop(v395_2);
    let v395_4: Space = unite(&(v395_3),&(v358_65));
    let v395_5: Space = intersect(&(v395_4),&(*capture_3));
    if !v358_65.join_into((v395_5).clone()).is_element() { break; }
  }

((v358_24).clone(),(v358_43).clone(),(v358_44).clone(),(v358_45).clone(),(v358_46).clone(),(v358_5).clone(),(v358_65).clone(),)
}

#[inline(never)]
fn native_block_2(c: &mut Context,capture_0: &Space,capture_1: &Space,capture_2: &Space,capture_3: &Path,capture_4: &View<'_, '_>,capture_5: &Space) -> (Space,Space,) {
    let v431_2: Space = singleton(&((*capture_3)));
    let v431_3: Space = intersect(&(*CONSTANT_12),&(v431_2));
    let v431_4: Space = if has_head(&(v431_3)) { singleton(&[]) } else { Space::new() };
    drop(v431_3);
    let v431_5: Space = subtract(&(*CONSTANT_0),&(v431_4));
    drop(v431_4);
    let v431_11: Space = if (v431_5).is_empty() { Space::new() } else {
      let mut v432_6: Space = ((*capture_5)).clone();
      loop {
        let v433_1: Space = intersect(&(v432_6),&(*capture_2));
        let v433_2: Space = restrict_to(&(*capture_1),&(v433_1));
        drop(v433_1);
        let mut v433_3 = Space::new();
        let mut v433_3_cursor = (v433_2).read_zipper();
        for v433_3_byte in v433_3_cursor.child_mask().iter() {
          v433_3_cursor.descend_to_byte(v433_3_byte);
          {
          let v433_3_tail = v433_3_cursor.fork_read_zipper();
          let v433_3_head = Path::from_slice(&[v433_3_byte]);
          let v434_2: Space = singleton(&(v433_3_head));
          let v434_3: Space = intersect(&(*CONSTANT_12),&(v434_2));
          let v434_4: Space = if has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
          drop(v434_3);
          let v434_5: Space = subtract(&(*CONSTANT_0),&(v434_4));
          drop(v434_4);
          let v434_7: Space = if (v434_5).is_empty() { Space::new() } else {
            let mut v435_6 = Space::new();
            let mut v435_6_cursor = (v433_3_tail).read_zipper();
            for v435_6_byte in v435_6_cursor.child_mask().iter() {
              v435_6_cursor.descend_to_byte(v435_6_byte);
              {
              let v435_6_tail = v435_6_cursor.fork_read_zipper();
              let v435_6_head = Path::from_slice(&[v435_6_byte]);
              let v436_2: Space = singleton(&(v435_6_head));
              let v436_3: Space = intersect(&(*CONSTANT_12),&(v436_2));
              let v436_4: Space = if has_head(&(v436_3)) { singleton(&[]) } else { Space::new() };
              drop(v436_3);
              let v436_5: Space = subtract(&(*CONSTANT_0),&(v436_4));
              drop(v436_4);
              let v436_8: Space = if (v436_5).is_empty() { Space::new() } else {
                let v437_6: Path = concat_path(&(v433_3_head),&(v435_6_head));
                let mut v437_7 = Space::new();
                let mut v437_7_cursor = (v435_6_tail).read_zipper();
                for v437_7_byte in v437_7_cursor.child_mask().iter() {
                  v437_7_cursor.descend_to_byte(v437_7_byte);
                  {
                  let v437_7_tail = v437_7_cursor.fork_read_zipper();
                  let v437_7_head = Path::from_slice(&[v437_7_byte]);
                  let v438_2: Space = singleton(&(v437_7_head));
                  let v438_3: Space = intersect(&(*CONSTANT_12),&(v438_2));
                  let v438_4: Space = if has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
                  drop(v438_3);
                  let v438_5: Space = subtract(&(*CONSTANT_0),&(v438_4));
                  drop(v438_4);
                  let v438_8: Space = if (v438_5).is_empty() { Space::new() } else {
                    let v439_6: Path = concat_path(&(v437_6),&(v437_7_head));
                    let v439_7: Space = routine_41(c, &(v439_6), &(v437_7_tail).make_space());
                    compose(&(v438_5),&(v439_7))
                  };
                  drop(v438_5);
                  let v438_9: Space = intersect(&(*CONSTANT_12),&(v438_2));
                  drop(v438_2);
                  let v438_10: Space = if has_head(&(v438_9)) { singleton(&[]) } else { Space::new() };
                  drop(v438_9);
                  let v438_12: Space = if (v438_10).is_empty() { Space::new() } else {
                    let v440_6: Path = concat_path(&(v437_6),&(v437_7_head));
                    let v440_11: Space = routine_42(c, &(v440_6), &(v437_7_tail).make_space());
                    drop(v440_6);
                    compose(&(v438_10),&(v440_11))
                  };
                  drop(v438_10);
                  let v438_13: Space = unite(&(v438_8),&(v438_12));
                  v437_7.join_into((v438_13).clone());
                  }
                  v437_7_cursor.ascend(1);
                }
                drop(v437_7_cursor);
                compose(&(v436_5),&(v437_7))
              };
              drop(v436_5);
              let v436_9: Space = intersect(&(*CONSTANT_12),&(v436_2));
              drop(v436_2);
              let v436_10: Space = if has_head(&(v436_9)) { singleton(&[]) } else { Space::new() };
              drop(v436_9);
              let v436_12: Space = if (v436_10).is_empty() { Space::new() } else {
                let v441_6: Path = concat_path(&(v433_3_head),&(v435_6_head));
                let mut v441_11 = Space::new();
                let mut v441_11_cursor = (v435_6_tail).read_zipper();
                for v441_11_byte in v441_11_cursor.child_mask().iter() {
                  v441_11_cursor.descend_to_byte(v441_11_byte);
                  {
                  let v441_11_tail = v441_11_cursor.fork_read_zipper();
                  let v441_11_head = Path::from_slice(&[v441_11_byte]);
                  let v442_2: Space = singleton(&(v441_11_head));
                  let v442_3: Space = intersect(&(*CONSTANT_12),&(v442_2));
                  let v442_4: Space = if has_head(&(v442_3)) { singleton(&[]) } else { Space::new() };
                  drop(v442_3);
                  let v442_5: Space = subtract(&(*CONSTANT_0),&(v442_4));
                  drop(v442_4);
                  let v442_8: Space = if (v442_5).is_empty() { Space::new() } else {
                    let v443_6: Path = concat_path(&(v441_6),&(v441_11_head));
                    let v443_7: Space = routine_41(c, &(v443_6), &(v441_11_tail).make_space());
                    compose(&(v442_5),&(v443_7))
                  };
                  drop(v442_5);
                  let v442_9: Space = intersect(&(*CONSTANT_12),&(v442_2));
                  drop(v442_2);
                  let v442_10: Space = if has_head(&(v442_9)) { singleton(&[]) } else { Space::new() };
                  drop(v442_9);
                  let v442_12: Space = if (v442_10).is_empty() { Space::new() } else {
                    let v444_6: Path = concat_path(&(v441_6),&(v441_11_head));
                    let v444_11: Space = routine_43(c, &(v444_6), &(v441_11_tail).make_space());
                    drop(v444_6);
                    compose(&(v442_10),&(v444_11))
                  };
                  drop(v442_10);
                  let v442_13: Space = unite(&(v442_8),&(v442_12));
                  v441_11.join_into((v442_13).clone());
                  }
                  v441_11_cursor.ascend(1);
                }
                drop(v441_11_cursor);
                drop(v441_6);
                compose(&(v436_10),&(v441_11))
              };
              drop(v436_10);
              let v436_13: Space = unite(&(v436_8),&(v436_12));
              v435_6.join_into((v436_13).clone());
              }
              v435_6_cursor.ascend(1);
            }
            drop(v435_6_cursor);
            compose(&(v434_5),&(v435_6))
          };
          drop(v434_5);
          let v434_8: Space = intersect(&(*CONSTANT_12),&(v434_2));
          drop(v434_2);
          let v434_9: Space = if has_head(&(v434_8)) { singleton(&[]) } else { Space::new() };
          drop(v434_8);
          let v434_11: Space = if (v434_9).is_empty() { Space::new() } else {
            let mut v445_10 = Space::new();
            let mut v445_10_cursor = (v433_3_tail).read_zipper();
            for v445_10_byte in v445_10_cursor.child_mask().iter() {
              v445_10_cursor.descend_to_byte(v445_10_byte);
              {
              let v445_10_tail = v445_10_cursor.fork_read_zipper();
              let v445_10_head = Path::from_slice(&[v445_10_byte]);
              let v446_2: Space = singleton(&(v445_10_head));
              let v446_3: Space = intersect(&(*CONSTANT_12),&(v446_2));
              let v446_4: Space = if has_head(&(v446_3)) { singleton(&[]) } else { Space::new() };
              drop(v446_3);
              let v446_5: Space = subtract(&(*CONSTANT_0),&(v446_4));
              drop(v446_4);
              let v446_8: Space = if (v446_5).is_empty() { Space::new() } else {
                let v447_6: Path = concat_path(&(v433_3_head),&(v445_10_head));
                let mut v447_7 = Space::new();
                let mut v447_7_cursor = (v445_10_tail).read_zipper();
                for v447_7_byte in v447_7_cursor.child_mask().iter() {
                  v447_7_cursor.descend_to_byte(v447_7_byte);
                  {
                  let v447_7_tail = v447_7_cursor.fork_read_zipper();
                  let v447_7_head = Path::from_slice(&[v447_7_byte]);
                  let v448_2: Space = singleton(&(v447_7_head));
                  let v448_3: Space = intersect(&(*CONSTANT_12),&(v448_2));
                  let v448_4: Space = if has_head(&(v448_3)) { singleton(&[]) } else { Space::new() };
                  drop(v448_3);
                  let v448_5: Space = subtract(&(*CONSTANT_0),&(v448_4));
                  drop(v448_4);
                  let v448_8: Space = if (v448_5).is_empty() { Space::new() } else {
                    let v449_6: Path = concat_path(&(v447_6),&(v447_7_head));
                    let v449_7: Space = routine_41(c, &(v449_6), &(v447_7_tail).make_space());
                    compose(&(v448_5),&(v449_7))
                  };
                  drop(v448_5);
                  let v448_9: Space = intersect(&(*CONSTANT_12),&(v448_2));
                  drop(v448_2);
                  let v448_10: Space = if has_head(&(v448_9)) { singleton(&[]) } else { Space::new() };
                  drop(v448_9);
                  let v448_12: Space = if (v448_10).is_empty() { Space::new() } else {
                    let v450_6: Path = concat_path(&(v447_6),&(v447_7_head));
                    let v450_11: Space = routine_42(c, &(v450_6), &(v447_7_tail).make_space());
                    drop(v450_6);
                    compose(&(v448_10),&(v450_11))
                  };
                  drop(v448_10);
                  let v448_13: Space = unite(&(v448_8),&(v448_12));
                  v447_7.join_into((v448_13).clone());
                  }
                  v447_7_cursor.ascend(1);
                }
                drop(v447_7_cursor);
                drop(v447_6);
                compose(&(v446_5),&(v447_7))
              };
              drop(v446_5);
              let v446_9: Space = intersect(&(*CONSTANT_12),&(v446_2));
              drop(v446_2);
              let v446_10: Space = if has_head(&(v446_9)) { singleton(&[]) } else { Space::new() };
              drop(v446_9);
              let v446_11: Space = compose(&(v446_10),&(v445_10_tail));
              drop(v446_10);
              let v446_12: Space = unite(&(v446_8),&(v446_11));
              drop(v446_11);
              v445_10.join_into((v446_12).clone());
              }
              v445_10_cursor.ascend(1);
            }
            drop(v445_10_cursor);
            compose(&(v434_9),&(v445_10))
          };
          drop(v434_9);
          let v434_12: Space = unite(&(v434_7),&(v434_11));
          v433_3.join_into((v434_12).clone());
          }
          v433_3_cursor.ascend(1);
        }
        drop(v433_3_cursor);
        drop(v433_2);
        let v433_4: Space = unite(&(v433_3),&(v432_6));
        let v433_5: Space = intersect(&(v433_4),&(*capture_2));
        if !v432_6.join_into((v433_5).clone()).is_element() { break; }
      }
      let v432_7: Space = subtract(&(*capture_2),&(v432_6));
      let mut v432_8: Space = ((*capture_5)).clone();
      loop {
        let v451_1: Space = intersect(&(v432_8),&(*capture_2));
        let v451_2: Space = restrict_to(&(*capture_0),&(v451_1));
        drop(v451_1);
        let mut v451_3 = Space::new();
        let mut v451_3_cursor = (v451_2).read_zipper();
        for v451_3_byte in v451_3_cursor.child_mask().iter() {
          v451_3_cursor.descend_to_byte(v451_3_byte);
          {
          let v451_3_tail = v451_3_cursor.fork_read_zipper();
          let v451_3_head = Path::from_slice(&[v451_3_byte]);
          let v452_2: Space = singleton(&(v451_3_head));
          let v452_3: Space = intersect(&(*CONSTANT_12),&(v452_2));
          let v452_4: Space = if has_head(&(v452_3)) { singleton(&[]) } else { Space::new() };
          drop(v452_3);
          let v452_5: Space = subtract(&(*CONSTANT_0),&(v452_4));
          drop(v452_4);
          let v452_7: Space = if (v452_5).is_empty() { Space::new() } else {
            let mut v453_6 = Space::new();
            let mut v453_6_cursor = (v451_3_tail).read_zipper();
            for v453_6_byte in v453_6_cursor.child_mask().iter() {
              v453_6_cursor.descend_to_byte(v453_6_byte);
              {
              let v453_6_tail = v453_6_cursor.fork_read_zipper();
              let v453_6_head = Path::from_slice(&[v453_6_byte]);
              let v454_2: Space = singleton(&(v453_6_head));
              let v454_3: Space = intersect(&(*CONSTANT_12),&(v454_2));
              let v454_4: Space = if has_head(&(v454_3)) { singleton(&[]) } else { Space::new() };
              drop(v454_3);
              let v454_5: Space = subtract(&(*CONSTANT_0),&(v454_4));
              drop(v454_4);
              let v454_8: Space = if (v454_5).is_empty() { Space::new() } else {
                let v455_6: Path = concat_path(&(v451_3_head),&(v453_6_head));
                let mut v455_7 = Space::new();
                let mut v455_7_cursor = (v453_6_tail).read_zipper();
                for v455_7_byte in v455_7_cursor.child_mask().iter() {
                  v455_7_cursor.descend_to_byte(v455_7_byte);
                  {
                  let v455_7_tail = v455_7_cursor.fork_read_zipper();
                  let v455_7_head = Path::from_slice(&[v455_7_byte]);
                  let v456_2: Space = singleton(&(v455_7_head));
                  let v456_3: Space = intersect(&(*CONSTANT_12),&(v456_2));
                  let v456_4: Space = if has_head(&(v456_3)) { singleton(&[]) } else { Space::new() };
                  drop(v456_3);
                  let v456_5: Space = subtract(&(*CONSTANT_0),&(v456_4));
                  drop(v456_4);
                  let v456_8: Space = if (v456_5).is_empty() { Space::new() } else {
                    let v457_6: Path = concat_path(&(v455_6),&(v455_7_head));
                    let v457_7: Space = routine_41(c, &(v457_6), &(v455_7_tail).make_space());
                    compose(&(v456_5),&(v457_7))
                  };
                  drop(v456_5);
                  let v456_9: Space = intersect(&(*CONSTANT_12),&(v456_2));
                  drop(v456_2);
                  let v456_10: Space = if has_head(&(v456_9)) { singleton(&[]) } else { Space::new() };
                  drop(v456_9);
                  let v456_12: Space = if (v456_10).is_empty() { Space::new() } else {
                    let v458_6: Path = concat_path(&(v455_6),&(v455_7_head));
                    let v458_11: Space = routine_42(c, &(v458_6), &(v455_7_tail).make_space());
                    drop(v458_6);
                    compose(&(v456_10),&(v458_11))
                  };
                  drop(v456_10);
                  let v456_13: Space = unite(&(v456_8),&(v456_12));
                  v455_7.join_into((v456_13).clone());
                  }
                  v455_7_cursor.ascend(1);
                }
                drop(v455_7_cursor);
                compose(&(v454_5),&(v455_7))
              };
              drop(v454_5);
              let v454_9: Space = intersect(&(*CONSTANT_12),&(v454_2));
              drop(v454_2);
              let v454_10: Space = if has_head(&(v454_9)) { singleton(&[]) } else { Space::new() };
              drop(v454_9);
              let v454_12: Space = if (v454_10).is_empty() { Space::new() } else {
                let v459_6: Path = concat_path(&(v451_3_head),&(v453_6_head));
                let mut v459_11 = Space::new();
                let mut v459_11_cursor = (v453_6_tail).read_zipper();
                for v459_11_byte in v459_11_cursor.child_mask().iter() {
                  v459_11_cursor.descend_to_byte(v459_11_byte);
                  {
                  let v459_11_tail = v459_11_cursor.fork_read_zipper();
                  let v459_11_head = Path::from_slice(&[v459_11_byte]);
                  let v460_2: Space = singleton(&(v459_11_head));
                  let v460_3: Space = intersect(&(*CONSTANT_12),&(v460_2));
                  let v460_4: Space = if has_head(&(v460_3)) { singleton(&[]) } else { Space::new() };
                  drop(v460_3);
                  let v460_5: Space = subtract(&(*CONSTANT_0),&(v460_4));
                  drop(v460_4);
                  let v460_8: Space = if (v460_5).is_empty() { Space::new() } else {
                    let v461_6: Path = concat_path(&(v459_6),&(v459_11_head));
                    let v461_7: Space = routine_41(c, &(v461_6), &(v459_11_tail).make_space());
                    compose(&(v460_5),&(v461_7))
                  };
                  drop(v460_5);
                  let v460_9: Space = intersect(&(*CONSTANT_12),&(v460_2));
                  drop(v460_2);
                  let v460_10: Space = if has_head(&(v460_9)) { singleton(&[]) } else { Space::new() };
                  drop(v460_9);
                  let v460_12: Space = if (v460_10).is_empty() { Space::new() } else {
                    let v462_6: Path = concat_path(&(v459_6),&(v459_11_head));
                    let v462_11: Space = routine_43(c, &(v462_6), &(v459_11_tail).make_space());
                    drop(v462_6);
                    compose(&(v460_10),&(v462_11))
                  };
                  drop(v460_10);
                  let v460_13: Space = unite(&(v460_8),&(v460_12));
                  v459_11.join_into((v460_13).clone());
                  }
                  v459_11_cursor.ascend(1);
                }
                drop(v459_11_cursor);
                drop(v459_6);
                compose(&(v454_10),&(v459_11))
              };
              drop(v454_10);
              let v454_13: Space = unite(&(v454_8),&(v454_12));
              v453_6.join_into((v454_13).clone());
              }
              v453_6_cursor.ascend(1);
            }
            drop(v453_6_cursor);
            compose(&(v452_5),&(v453_6))
          };
          drop(v452_5);
          let v452_8: Space = intersect(&(*CONSTANT_12),&(v452_2));
          drop(v452_2);
          let v452_9: Space = if has_head(&(v452_8)) { singleton(&[]) } else { Space::new() };
          drop(v452_8);
          let v452_11: Space = if (v452_9).is_empty() { Space::new() } else {
            let mut v463_10 = Space::new();
            let mut v463_10_cursor = (v451_3_tail).read_zipper();
            for v463_10_byte in v463_10_cursor.child_mask().iter() {
              v463_10_cursor.descend_to_byte(v463_10_byte);
              {
              let v463_10_tail = v463_10_cursor.fork_read_zipper();
              let v463_10_head = Path::from_slice(&[v463_10_byte]);
              let v464_2: Space = singleton(&(v463_10_head));
              let v464_3: Space = intersect(&(*CONSTANT_12),&(v464_2));
              let v464_4: Space = if has_head(&(v464_3)) { singleton(&[]) } else { Space::new() };
              drop(v464_3);
              let v464_5: Space = subtract(&(*CONSTANT_0),&(v464_4));
              drop(v464_4);
              let v464_8: Space = if (v464_5).is_empty() { Space::new() } else {
                let v465_6: Path = concat_path(&(v451_3_head),&(v463_10_head));
                let mut v465_7 = Space::new();
                let mut v465_7_cursor = (v463_10_tail).read_zipper();
                for v465_7_byte in v465_7_cursor.child_mask().iter() {
                  v465_7_cursor.descend_to_byte(v465_7_byte);
                  {
                  let v465_7_tail = v465_7_cursor.fork_read_zipper();
                  let v465_7_head = Path::from_slice(&[v465_7_byte]);
                  let v466_2: Space = singleton(&(v465_7_head));
                  let v466_3: Space = intersect(&(*CONSTANT_12),&(v466_2));
                  let v466_4: Space = if has_head(&(v466_3)) { singleton(&[]) } else { Space::new() };
                  drop(v466_3);
                  let v466_5: Space = subtract(&(*CONSTANT_0),&(v466_4));
                  drop(v466_4);
                  let v466_8: Space = if (v466_5).is_empty() { Space::new() } else {
                    let v467_6: Path = concat_path(&(v465_6),&(v465_7_head));
                    let v467_7: Space = routine_41(c, &(v467_6), &(v465_7_tail).make_space());
                    compose(&(v466_5),&(v467_7))
                  };
                  drop(v466_5);
                  let v466_9: Space = intersect(&(*CONSTANT_12),&(v466_2));
                  drop(v466_2);
                  let v466_10: Space = if has_head(&(v466_9)) { singleton(&[]) } else { Space::new() };
                  drop(v466_9);
                  let v466_12: Space = if (v466_10).is_empty() { Space::new() } else {
                    let v468_6: Path = concat_path(&(v465_6),&(v465_7_head));
                    let v468_11: Space = routine_42(c, &(v468_6), &(v465_7_tail).make_space());
                    drop(v468_6);
                    compose(&(v466_10),&(v468_11))
                  };
                  drop(v466_10);
                  let v466_13: Space = unite(&(v466_8),&(v466_12));
                  v465_7.join_into((v466_13).clone());
                  }
                  v465_7_cursor.ascend(1);
                }
                drop(v465_7_cursor);
                drop(v465_6);
                compose(&(v464_5),&(v465_7))
              };
              drop(v464_5);
              let v464_9: Space = intersect(&(*CONSTANT_12),&(v464_2));
              drop(v464_2);
              let v464_10: Space = if has_head(&(v464_9)) { singleton(&[]) } else { Space::new() };
              drop(v464_9);
              let v464_11: Space = compose(&(v464_10),&(v463_10_tail));
              drop(v464_10);
              let v464_12: Space = unite(&(v464_8),&(v464_11));
              drop(v464_11);
              v463_10.join_into((v464_12).clone());
              }
              v463_10_cursor.ascend(1);
            }
            drop(v463_10_cursor);
            compose(&(v452_9),&(v463_10))
          };
          drop(v452_9);
          let v452_12: Space = unite(&(v452_7),&(v452_11));
          v451_3.join_into((v452_12).clone());
          }
          v451_3_cursor.ascend(1);
        }
        drop(v451_3_cursor);
        drop(v451_2);
        let v451_4: Space = unite(&(v451_3),&(v432_8));
        let v451_5: Space = intersect(&(v451_4),&(*capture_2));
        if !v432_8.join_into((v451_5).clone()).is_element() { break; }
      }
      let v432_9: Space = subtract(&(v432_7),&(v432_8));
      let v432_10: Space = routine_16(c, &((*capture_3)), &((*capture_4)).make_space(), &(*capture_0), &(*capture_1), &(v432_9));
      compose(&(v431_5),&(v432_10))
    };
    drop(v431_5);
    let v431_12: Space = intersect(&(*CONSTANT_12),&(v431_2));
    drop(v431_2);
    let v431_13: Space = if has_head(&(v431_12)) { singleton(&[]) } else { Space::new() };
    drop(v431_12);
    let v431_19: Space = if (v431_13).is_empty() { Space::new() } else {
      let mut v469_14: Space = ((*capture_5)).clone();
      loop {
        let v470_1: Space = intersect(&(v469_14),&(*capture_2));
        let v470_2: Space = restrict_to(&(*capture_1),&(v470_1));
        drop(v470_1);
        let mut v470_3 = Space::new();
        let mut v470_3_cursor = (v470_2).read_zipper();
        for v470_3_byte in v470_3_cursor.child_mask().iter() {
          v470_3_cursor.descend_to_byte(v470_3_byte);
          {
          let v470_3_tail = v470_3_cursor.fork_read_zipper();
          let v470_3_head = Path::from_slice(&[v470_3_byte]);
          let v471_2: Space = singleton(&(v470_3_head));
          let v471_3: Space = intersect(&(*CONSTANT_12),&(v471_2));
          let v471_4: Space = if has_head(&(v471_3)) { singleton(&[]) } else { Space::new() };
          drop(v471_3);
          let v471_5: Space = subtract(&(*CONSTANT_0),&(v471_4));
          drop(v471_4);
          let v471_7: Space = if (v471_5).is_empty() { Space::new() } else {
            let mut v472_6 = Space::new();
            let mut v472_6_cursor = (v470_3_tail).read_zipper();
            for v472_6_byte in v472_6_cursor.child_mask().iter() {
              v472_6_cursor.descend_to_byte(v472_6_byte);
              {
              let v472_6_tail = v472_6_cursor.fork_read_zipper();
              let v472_6_head = Path::from_slice(&[v472_6_byte]);
              let v473_2: Space = singleton(&(v472_6_head));
              let v473_3: Space = intersect(&(*CONSTANT_12),&(v473_2));
              let v473_4: Space = if has_head(&(v473_3)) { singleton(&[]) } else { Space::new() };
              drop(v473_3);
              let v473_5: Space = subtract(&(*CONSTANT_0),&(v473_4));
              drop(v473_4);
              let v473_8: Space = if (v473_5).is_empty() { Space::new() } else {
                let v474_6: Path = concat_path(&(v470_3_head),&(v472_6_head));
                let mut v474_7 = Space::new();
                let mut v474_7_cursor = (v472_6_tail).read_zipper();
                for v474_7_byte in v474_7_cursor.child_mask().iter() {
                  v474_7_cursor.descend_to_byte(v474_7_byte);
                  {
                  let v474_7_tail = v474_7_cursor.fork_read_zipper();
                  let v474_7_head = Path::from_slice(&[v474_7_byte]);
                  let v475_2: Space = singleton(&(v474_7_head));
                  let v475_3: Space = intersect(&(*CONSTANT_12),&(v475_2));
                  let v475_4: Space = if has_head(&(v475_3)) { singleton(&[]) } else { Space::new() };
                  drop(v475_3);
                  let v475_5: Space = subtract(&(*CONSTANT_0),&(v475_4));
                  drop(v475_4);
                  let v475_8: Space = if (v475_5).is_empty() { Space::new() } else {
                    let v476_6: Path = concat_path(&(v474_6),&(v474_7_head));
                    let v476_7: Space = routine_41(c, &(v476_6), &(v474_7_tail).make_space());
                    compose(&(v475_5),&(v476_7))
                  };
                  drop(v475_5);
                  let v475_9: Space = intersect(&(*CONSTANT_12),&(v475_2));
                  drop(v475_2);
                  let v475_10: Space = if has_head(&(v475_9)) { singleton(&[]) } else { Space::new() };
                  drop(v475_9);
                  let v475_12: Space = if (v475_10).is_empty() { Space::new() } else {
                    let v477_6: Path = concat_path(&(v474_6),&(v474_7_head));
                    let v477_11: Space = routine_42(c, &(v477_6), &(v474_7_tail).make_space());
                    drop(v477_6);
                    compose(&(v475_10),&(v477_11))
                  };
                  drop(v475_10);
                  let v475_13: Space = unite(&(v475_8),&(v475_12));
                  v474_7.join_into((v475_13).clone());
                  }
                  v474_7_cursor.ascend(1);
                }
                drop(v474_7_cursor);
                compose(&(v473_5),&(v474_7))
              };
              drop(v473_5);
              let v473_9: Space = intersect(&(*CONSTANT_12),&(v473_2));
              drop(v473_2);
              let v473_10: Space = if has_head(&(v473_9)) { singleton(&[]) } else { Space::new() };
              drop(v473_9);
              let v473_12: Space = if (v473_10).is_empty() { Space::new() } else {
                let v478_6: Path = concat_path(&(v470_3_head),&(v472_6_head));
                let mut v478_11 = Space::new();
                let mut v478_11_cursor = (v472_6_tail).read_zipper();
                for v478_11_byte in v478_11_cursor.child_mask().iter() {
                  v478_11_cursor.descend_to_byte(v478_11_byte);
                  {
                  let v478_11_tail = v478_11_cursor.fork_read_zipper();
                  let v478_11_head = Path::from_slice(&[v478_11_byte]);
                  let v479_2: Space = singleton(&(v478_11_head));
                  let v479_3: Space = intersect(&(*CONSTANT_12),&(v479_2));
                  let v479_4: Space = if has_head(&(v479_3)) { singleton(&[]) } else { Space::new() };
                  drop(v479_3);
                  let v479_5: Space = subtract(&(*CONSTANT_0),&(v479_4));
                  drop(v479_4);
                  let v479_8: Space = if (v479_5).is_empty() { Space::new() } else {
                    let v480_6: Path = concat_path(&(v478_6),&(v478_11_head));
                    let v480_7: Space = routine_41(c, &(v480_6), &(v478_11_tail).make_space());
                    compose(&(v479_5),&(v480_7))
                  };
                  drop(v479_5);
                  let v479_9: Space = intersect(&(*CONSTANT_12),&(v479_2));
                  drop(v479_2);
                  let v479_10: Space = if has_head(&(v479_9)) { singleton(&[]) } else { Space::new() };
                  drop(v479_9);
                  let v479_12: Space = if (v479_10).is_empty() { Space::new() } else {
                    let v481_6: Path = concat_path(&(v478_6),&(v478_11_head));
                    let v481_11: Space = routine_43(c, &(v481_6), &(v478_11_tail).make_space());
                    drop(v481_6);
                    compose(&(v479_10),&(v481_11))
                  };
                  drop(v479_10);
                  let v479_13: Space = unite(&(v479_8),&(v479_12));
                  v478_11.join_into((v479_13).clone());
                  }
                  v478_11_cursor.ascend(1);
                }
                drop(v478_11_cursor);
                drop(v478_6);
                compose(&(v473_10),&(v478_11))
              };
              drop(v473_10);
              let v473_13: Space = unite(&(v473_8),&(v473_12));
              v472_6.join_into((v473_13).clone());
              }
              v472_6_cursor.ascend(1);
            }
            drop(v472_6_cursor);
            compose(&(v471_5),&(v472_6))
          };
          drop(v471_5);
          let v471_8: Space = intersect(&(*CONSTANT_12),&(v471_2));
          drop(v471_2);
          let v471_9: Space = if has_head(&(v471_8)) { singleton(&[]) } else { Space::new() };
          drop(v471_8);
          let v471_11: Space = if (v471_9).is_empty() { Space::new() } else {
            let mut v482_10 = Space::new();
            let mut v482_10_cursor = (v470_3_tail).read_zipper();
            for v482_10_byte in v482_10_cursor.child_mask().iter() {
              v482_10_cursor.descend_to_byte(v482_10_byte);
              {
              let v482_10_tail = v482_10_cursor.fork_read_zipper();
              let v482_10_head = Path::from_slice(&[v482_10_byte]);
              let v483_2: Space = singleton(&(v482_10_head));
              let v483_3: Space = intersect(&(*CONSTANT_12),&(v483_2));
              let v483_4: Space = if has_head(&(v483_3)) { singleton(&[]) } else { Space::new() };
              drop(v483_3);
              let v483_5: Space = subtract(&(*CONSTANT_0),&(v483_4));
              drop(v483_4);
              let v483_8: Space = if (v483_5).is_empty() { Space::new() } else {
                let v484_6: Path = concat_path(&(v470_3_head),&(v482_10_head));
                let mut v484_7 = Space::new();
                let mut v484_7_cursor = (v482_10_tail).read_zipper();
                for v484_7_byte in v484_7_cursor.child_mask().iter() {
                  v484_7_cursor.descend_to_byte(v484_7_byte);
                  {
                  let v484_7_tail = v484_7_cursor.fork_read_zipper();
                  let v484_7_head = Path::from_slice(&[v484_7_byte]);
                  let v485_2: Space = singleton(&(v484_7_head));
                  let v485_3: Space = intersect(&(*CONSTANT_12),&(v485_2));
                  let v485_4: Space = if has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
                  drop(v485_3);
                  let v485_5: Space = subtract(&(*CONSTANT_0),&(v485_4));
                  drop(v485_4);
                  let v485_8: Space = if (v485_5).is_empty() { Space::new() } else {
                    let v486_6: Path = concat_path(&(v484_6),&(v484_7_head));
                    let v486_7: Space = routine_41(c, &(v486_6), &(v484_7_tail).make_space());
                    compose(&(v485_5),&(v486_7))
                  };
                  drop(v485_5);
                  let v485_9: Space = intersect(&(*CONSTANT_12),&(v485_2));
                  drop(v485_2);
                  let v485_10: Space = if has_head(&(v485_9)) { singleton(&[]) } else { Space::new() };
                  drop(v485_9);
                  let v485_12: Space = if (v485_10).is_empty() { Space::new() } else {
                    let v487_6: Path = concat_path(&(v484_6),&(v484_7_head));
                    let v487_11: Space = routine_42(c, &(v487_6), &(v484_7_tail).make_space());
                    drop(v487_6);
                    compose(&(v485_10),&(v487_11))
                  };
                  drop(v485_10);
                  let v485_13: Space = unite(&(v485_8),&(v485_12));
                  v484_7.join_into((v485_13).clone());
                  }
                  v484_7_cursor.ascend(1);
                }
                drop(v484_7_cursor);
                drop(v484_6);
                compose(&(v483_5),&(v484_7))
              };
              drop(v483_5);
              let v483_9: Space = intersect(&(*CONSTANT_12),&(v483_2));
              drop(v483_2);
              let v483_10: Space = if has_head(&(v483_9)) { singleton(&[]) } else { Space::new() };
              drop(v483_9);
              let v483_11: Space = compose(&(v483_10),&(v482_10_tail));
              drop(v483_10);
              let v483_12: Space = unite(&(v483_8),&(v483_11));
              drop(v483_11);
              v482_10.join_into((v483_12).clone());
              }
              v482_10_cursor.ascend(1);
            }
            drop(v482_10_cursor);
            compose(&(v471_9),&(v482_10))
          };
          drop(v471_9);
          let v471_12: Space = unite(&(v471_7),&(v471_11));
          v470_3.join_into((v471_12).clone());
          }
          v470_3_cursor.ascend(1);
        }
        drop(v470_3_cursor);
        drop(v470_2);
        let v470_4: Space = unite(&(v470_3),&(v469_14));
        let v470_5: Space = intersect(&(v470_4),&(*capture_2));
        if !v469_14.join_into((v470_5).clone()).is_element() { break; }
      }
      let v469_15: Space = subtract(&(*capture_2),&(v469_14));
      let mut v469_16: Space = ((*capture_5)).clone();
      loop {
        let v488_1: Space = intersect(&(v469_16),&(*capture_2));
        let v488_2: Space = restrict_to(&(*capture_0),&(v488_1));
        drop(v488_1);
        let mut v488_3 = Space::new();
        let mut v488_3_cursor = (v488_2).read_zipper();
        for v488_3_byte in v488_3_cursor.child_mask().iter() {
          v488_3_cursor.descend_to_byte(v488_3_byte);
          {
          let v488_3_tail = v488_3_cursor.fork_read_zipper();
          let v488_3_head = Path::from_slice(&[v488_3_byte]);
          let v489_2: Space = singleton(&(v488_3_head));
          let v489_3: Space = intersect(&(*CONSTANT_12),&(v489_2));
          let v489_4: Space = if has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
          drop(v489_3);
          let v489_5: Space = subtract(&(*CONSTANT_0),&(v489_4));
          drop(v489_4);
          let v489_7: Space = if (v489_5).is_empty() { Space::new() } else {
            let mut v490_6 = Space::new();
            let mut v490_6_cursor = (v488_3_tail).read_zipper();
            for v490_6_byte in v490_6_cursor.child_mask().iter() {
              v490_6_cursor.descend_to_byte(v490_6_byte);
              {
              let v490_6_tail = v490_6_cursor.fork_read_zipper();
              let v490_6_head = Path::from_slice(&[v490_6_byte]);
              let v491_2: Space = singleton(&(v490_6_head));
              let v491_3: Space = intersect(&(*CONSTANT_12),&(v491_2));
              let v491_4: Space = if has_head(&(v491_3)) { singleton(&[]) } else { Space::new() };
              drop(v491_3);
              let v491_5: Space = subtract(&(*CONSTANT_0),&(v491_4));
              drop(v491_4);
              let v491_8: Space = if (v491_5).is_empty() { Space::new() } else {
                let v492_6: Path = concat_path(&(v488_3_head),&(v490_6_head));
                let mut v492_7 = Space::new();
                let mut v492_7_cursor = (v490_6_tail).read_zipper();
                for v492_7_byte in v492_7_cursor.child_mask().iter() {
                  v492_7_cursor.descend_to_byte(v492_7_byte);
                  {
                  let v492_7_tail = v492_7_cursor.fork_read_zipper();
                  let v492_7_head = Path::from_slice(&[v492_7_byte]);
                  let v493_2: Space = singleton(&(v492_7_head));
                  let v493_3: Space = intersect(&(*CONSTANT_12),&(v493_2));
                  let v493_4: Space = if has_head(&(v493_3)) { singleton(&[]) } else { Space::new() };
                  drop(v493_3);
                  let v493_5: Space = subtract(&(*CONSTANT_0),&(v493_4));
                  drop(v493_4);
                  let v493_8: Space = if (v493_5).is_empty() { Space::new() } else {
                    let v494_6: Path = concat_path(&(v492_6),&(v492_7_head));
                    let v494_7: Space = routine_41(c, &(v494_6), &(v492_7_tail).make_space());
                    compose(&(v493_5),&(v494_7))
                  };
                  drop(v493_5);
                  let v493_9: Space = intersect(&(*CONSTANT_12),&(v493_2));
                  drop(v493_2);
                  let v493_10: Space = if has_head(&(v493_9)) { singleton(&[]) } else { Space::new() };
                  drop(v493_9);
                  let v493_12: Space = if (v493_10).is_empty() { Space::new() } else {
                    let v495_6: Path = concat_path(&(v492_6),&(v492_7_head));
                    let v495_11: Space = routine_42(c, &(v495_6), &(v492_7_tail).make_space());
                    drop(v495_6);
                    compose(&(v493_10),&(v495_11))
                  };
                  drop(v493_10);
                  let v493_13: Space = unite(&(v493_8),&(v493_12));
                  v492_7.join_into((v493_13).clone());
                  }
                  v492_7_cursor.ascend(1);
                }
                drop(v492_7_cursor);
                compose(&(v491_5),&(v492_7))
              };
              drop(v491_5);
              let v491_9: Space = intersect(&(*CONSTANT_12),&(v491_2));
              drop(v491_2);
              let v491_10: Space = if has_head(&(v491_9)) { singleton(&[]) } else { Space::new() };
              drop(v491_9);
              let v491_12: Space = if (v491_10).is_empty() { Space::new() } else {
                let v496_6: Path = concat_path(&(v488_3_head),&(v490_6_head));
                let mut v496_11 = Space::new();
                let mut v496_11_cursor = (v490_6_tail).read_zipper();
                for v496_11_byte in v496_11_cursor.child_mask().iter() {
                  v496_11_cursor.descend_to_byte(v496_11_byte);
                  {
                  let v496_11_tail = v496_11_cursor.fork_read_zipper();
                  let v496_11_head = Path::from_slice(&[v496_11_byte]);
                  let v497_2: Space = singleton(&(v496_11_head));
                  let v497_3: Space = intersect(&(*CONSTANT_12),&(v497_2));
                  let v497_4: Space = if has_head(&(v497_3)) { singleton(&[]) } else { Space::new() };
                  drop(v497_3);
                  let v497_5: Space = subtract(&(*CONSTANT_0),&(v497_4));
                  drop(v497_4);
                  let v497_8: Space = if (v497_5).is_empty() { Space::new() } else {
                    let v498_6: Path = concat_path(&(v496_6),&(v496_11_head));
                    let v498_7: Space = routine_41(c, &(v498_6), &(v496_11_tail).make_space());
                    compose(&(v497_5),&(v498_7))
                  };
                  drop(v497_5);
                  let v497_9: Space = intersect(&(*CONSTANT_12),&(v497_2));
                  drop(v497_2);
                  let v497_10: Space = if has_head(&(v497_9)) { singleton(&[]) } else { Space::new() };
                  drop(v497_9);
                  let v497_12: Space = if (v497_10).is_empty() { Space::new() } else {
                    let v499_6: Path = concat_path(&(v496_6),&(v496_11_head));
                    let v499_11: Space = routine_43(c, &(v499_6), &(v496_11_tail).make_space());
                    drop(v499_6);
                    compose(&(v497_10),&(v499_11))
                  };
                  drop(v497_10);
                  let v497_13: Space = unite(&(v497_8),&(v497_12));
                  v496_11.join_into((v497_13).clone());
                  }
                  v496_11_cursor.ascend(1);
                }
                drop(v496_11_cursor);
                drop(v496_6);
                compose(&(v491_10),&(v496_11))
              };
              drop(v491_10);
              let v491_13: Space = unite(&(v491_8),&(v491_12));
              v490_6.join_into((v491_13).clone());
              }
              v490_6_cursor.ascend(1);
            }
            drop(v490_6_cursor);
            compose(&(v489_5),&(v490_6))
          };
          drop(v489_5);
          let v489_8: Space = intersect(&(*CONSTANT_12),&(v489_2));
          drop(v489_2);
          let v489_9: Space = if has_head(&(v489_8)) { singleton(&[]) } else { Space::new() };
          drop(v489_8);
          let v489_11: Space = if (v489_9).is_empty() { Space::new() } else {
            let mut v500_10 = Space::new();
            let mut v500_10_cursor = (v488_3_tail).read_zipper();
            for v500_10_byte in v500_10_cursor.child_mask().iter() {
              v500_10_cursor.descend_to_byte(v500_10_byte);
              {
              let v500_10_tail = v500_10_cursor.fork_read_zipper();
              let v500_10_head = Path::from_slice(&[v500_10_byte]);
              let v501_2: Space = singleton(&(v500_10_head));
              let v501_3: Space = intersect(&(*CONSTANT_12),&(v501_2));
              let v501_4: Space = if has_head(&(v501_3)) { singleton(&[]) } else { Space::new() };
              drop(v501_3);
              let v501_5: Space = subtract(&(*CONSTANT_0),&(v501_4));
              drop(v501_4);
              let v501_8: Space = if (v501_5).is_empty() { Space::new() } else {
                let v502_6: Path = concat_path(&(v488_3_head),&(v500_10_head));
                let mut v502_7 = Space::new();
                let mut v502_7_cursor = (v500_10_tail).read_zipper();
                for v502_7_byte in v502_7_cursor.child_mask().iter() {
                  v502_7_cursor.descend_to_byte(v502_7_byte);
                  {
                  let v502_7_tail = v502_7_cursor.fork_read_zipper();
                  let v502_7_head = Path::from_slice(&[v502_7_byte]);
                  let v503_2: Space = singleton(&(v502_7_head));
                  let v503_3: Space = intersect(&(*CONSTANT_12),&(v503_2));
                  let v503_4: Space = if has_head(&(v503_3)) { singleton(&[]) } else { Space::new() };
                  drop(v503_3);
                  let v503_5: Space = subtract(&(*CONSTANT_0),&(v503_4));
                  drop(v503_4);
                  let v503_8: Space = if (v503_5).is_empty() { Space::new() } else {
                    let v504_6: Path = concat_path(&(v502_6),&(v502_7_head));
                    let v504_7: Space = routine_41(c, &(v504_6), &(v502_7_tail).make_space());
                    compose(&(v503_5),&(v504_7))
                  };
                  drop(v503_5);
                  let v503_9: Space = intersect(&(*CONSTANT_12),&(v503_2));
                  drop(v503_2);
                  let v503_10: Space = if has_head(&(v503_9)) { singleton(&[]) } else { Space::new() };
                  drop(v503_9);
                  let v503_12: Space = if (v503_10).is_empty() { Space::new() } else {
                    let v505_6: Path = concat_path(&(v502_6),&(v502_7_head));
                    let v505_11: Space = routine_42(c, &(v505_6), &(v502_7_tail).make_space());
                    drop(v505_6);
                    compose(&(v503_10),&(v505_11))
                  };
                  drop(v503_10);
                  let v503_13: Space = unite(&(v503_8),&(v503_12));
                  v502_7.join_into((v503_13).clone());
                  }
                  v502_7_cursor.ascend(1);
                }
                drop(v502_7_cursor);
                drop(v502_6);
                compose(&(v501_5),&(v502_7))
              };
              drop(v501_5);
              let v501_9: Space = intersect(&(*CONSTANT_12),&(v501_2));
              drop(v501_2);
              let v501_10: Space = if has_head(&(v501_9)) { singleton(&[]) } else { Space::new() };
              drop(v501_9);
              let v501_11: Space = compose(&(v501_10),&(v500_10_tail));
              drop(v501_10);
              let v501_12: Space = unite(&(v501_8),&(v501_11));
              drop(v501_11);
              v500_10.join_into((v501_12).clone());
              }
              v500_10_cursor.ascend(1);
            }
            drop(v500_10_cursor);
            compose(&(v489_9),&(v500_10))
          };
          drop(v489_9);
          let v489_12: Space = unite(&(v489_7),&(v489_11));
          v488_3.join_into((v489_12).clone());
          }
          v488_3_cursor.ascend(1);
        }
        drop(v488_3_cursor);
        drop(v488_2);
        let v488_4: Space = unite(&(v488_3),&(v469_16));
        let v488_5: Space = intersect(&(v488_4),&(*capture_2));
        if !v469_16.join_into((v488_5).clone()).is_element() { break; }
      }
      let v469_17: Space = subtract(&(v469_15),&(v469_16));
      let v469_18: Space = routine_17(c, &((*capture_3)), &((*capture_4)).make_space(), &(*capture_0), &(*capture_1), &(v469_17));
      compose(&(v431_13),&(v469_18))
    };
    drop(v431_13);

((v431_11).clone(),(v431_19).clone(),)
}

#[inline(never)]
fn native_block_3(c: &mut Context,capture_0: &Space,capture_1: &Space,capture_2: &Space,capture_3: &Space,capture_4: &Space,capture_5: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v358_66: Space = subtract(&(*capture_2),&((*capture_5)));
  let mut v358_85: Space = ((*capture_4)).clone();
  loop {
    let v413_1: Space = intersect(&(v358_85),&(*capture_2));
    let v413_2: Space = restrict_to(&(*capture_0),&(v413_1));
    drop(v413_1);
    let mut v413_3 = Space::new();
    let mut v413_3_cursor = (v413_2).read_zipper();
    for v413_3_byte in v413_3_cursor.child_mask().iter() {
      v413_3_cursor.descend_to_byte(v413_3_byte);
      {
      let v413_3_tail = v413_3_cursor.fork_read_zipper();
      let v413_3_head = Path::from_slice(&[v413_3_byte]);
      let v414_2: Space = singleton(&(v413_3_head));
      let v414_3: Space = intersect(&(*CONSTANT_12),&(v414_2));
      let v414_4: Space = if has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
      drop(v414_3);
      let v414_5: Space = subtract(&(*CONSTANT_0),&(v414_4));
      drop(v414_4);
      let v414_7: Space = if (v414_5).is_empty() { Space::new() } else {
        let mut v415_6 = Space::new();
        let mut v415_6_cursor = (v413_3_tail).read_zipper();
        for v415_6_byte in v415_6_cursor.child_mask().iter() {
          v415_6_cursor.descend_to_byte(v415_6_byte);
          {
          let v415_6_tail = v415_6_cursor.fork_read_zipper();
          let v415_6_head = Path::from_slice(&[v415_6_byte]);
          let v416_2: Space = singleton(&(v415_6_head));
          let v416_3: Space = intersect(&(*CONSTANT_12),&(v416_2));
          let v416_4: Space = if has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
          drop(v416_3);
          let v416_5: Space = subtract(&(*CONSTANT_0),&(v416_4));
          drop(v416_4);
          let v416_8: Space = if (v416_5).is_empty() { Space::new() } else {
            let v417_6: Path = concat_path(&(v413_3_head),&(v415_6_head));
            let mut v417_7 = Space::new();
            let mut v417_7_cursor = (v415_6_tail).read_zipper();
            for v417_7_byte in v417_7_cursor.child_mask().iter() {
              v417_7_cursor.descend_to_byte(v417_7_byte);
              {
              let v417_7_tail = v417_7_cursor.fork_read_zipper();
              let v417_7_head = Path::from_slice(&[v417_7_byte]);
              let v418_2: Space = singleton(&(v417_7_head));
              let v418_3: Space = intersect(&(*CONSTANT_12),&(v418_2));
              let v418_4: Space = if has_head(&(v418_3)) { singleton(&[]) } else { Space::new() };
              drop(v418_3);
              let v418_5: Space = subtract(&(*CONSTANT_0),&(v418_4));
              drop(v418_4);
              let v418_8: Space = if (v418_5).is_empty() { Space::new() } else {
                let v419_6: Path = concat_path(&(v417_6),&(v417_7_head));
                let v419_7: Space = routine_41(c, &(v419_6), &(v417_7_tail).make_space());
                compose(&(v418_5),&(v419_7))
              };
              drop(v418_5);
              let v418_9: Space = intersect(&(*CONSTANT_12),&(v418_2));
              drop(v418_2);
              let v418_10: Space = if has_head(&(v418_9)) { singleton(&[]) } else { Space::new() };
              drop(v418_9);
              let v418_12: Space = if (v418_10).is_empty() { Space::new() } else {
                let v420_6: Path = concat_path(&(v417_6),&(v417_7_head));
                let v420_11: Space = routine_42(c, &(v420_6), &(v417_7_tail).make_space());
                drop(v420_6);
                compose(&(v418_10),&(v420_11))
              };
              drop(v418_10);
              let v418_13: Space = unite(&(v418_8),&(v418_12));
              v417_7.join_into((v418_13).clone());
              }
              v417_7_cursor.ascend(1);
            }
            drop(v417_7_cursor);
            compose(&(v416_5),&(v417_7))
          };
          drop(v416_5);
          let v416_9: Space = intersect(&(*CONSTANT_12),&(v416_2));
          drop(v416_2);
          let v416_10: Space = if has_head(&(v416_9)) { singleton(&[]) } else { Space::new() };
          drop(v416_9);
          let v416_12: Space = if (v416_10).is_empty() { Space::new() } else {
            let v421_6: Path = concat_path(&(v413_3_head),&(v415_6_head));
            let mut v421_11 = Space::new();
            let mut v421_11_cursor = (v415_6_tail).read_zipper();
            for v421_11_byte in v421_11_cursor.child_mask().iter() {
              v421_11_cursor.descend_to_byte(v421_11_byte);
              {
              let v421_11_tail = v421_11_cursor.fork_read_zipper();
              let v421_11_head = Path::from_slice(&[v421_11_byte]);
              let v422_2: Space = singleton(&(v421_11_head));
              let v422_3: Space = intersect(&(*CONSTANT_12),&(v422_2));
              let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
              drop(v422_3);
              let v422_5: Space = subtract(&(*CONSTANT_0),&(v422_4));
              drop(v422_4);
              let v422_8: Space = if (v422_5).is_empty() { Space::new() } else {
                let v423_6: Path = concat_path(&(v421_6),&(v421_11_head));
                let v423_7: Space = routine_41(c, &(v423_6), &(v421_11_tail).make_space());
                compose(&(v422_5),&(v423_7))
              };
              drop(v422_5);
              let v422_9: Space = intersect(&(*CONSTANT_12),&(v422_2));
              drop(v422_2);
              let v422_10: Space = if has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
              drop(v422_9);
              let v422_12: Space = if (v422_10).is_empty() { Space::new() } else {
                let v424_6: Path = concat_path(&(v421_6),&(v421_11_head));
                let v424_11: Space = routine_43(c, &(v424_6), &(v421_11_tail).make_space());
                drop(v424_6);
                compose(&(v422_10),&(v424_11))
              };
              drop(v422_10);
              let v422_13: Space = unite(&(v422_8),&(v422_12));
              v421_11.join_into((v422_13).clone());
              }
              v421_11_cursor.ascend(1);
            }
            drop(v421_11_cursor);
            drop(v421_6);
            compose(&(v416_10),&(v421_11))
          };
          drop(v416_10);
          let v416_13: Space = unite(&(v416_8),&(v416_12));
          v415_6.join_into((v416_13).clone());
          }
          v415_6_cursor.ascend(1);
        }
        drop(v415_6_cursor);
        compose(&(v414_5),&(v415_6))
      };
      drop(v414_5);
      let v414_8: Space = intersect(&(*CONSTANT_12),&(v414_2));
      drop(v414_2);
      let v414_9: Space = if has_head(&(v414_8)) { singleton(&[]) } else { Space::new() };
      drop(v414_8);
      let v414_11: Space = if (v414_9).is_empty() { Space::new() } else {
        let mut v425_10 = Space::new();
        let mut v425_10_cursor = (v413_3_tail).read_zipper();
        for v425_10_byte in v425_10_cursor.child_mask().iter() {
          v425_10_cursor.descend_to_byte(v425_10_byte);
          {
          let v425_10_tail = v425_10_cursor.fork_read_zipper();
          let v425_10_head = Path::from_slice(&[v425_10_byte]);
          let v426_2: Space = singleton(&(v425_10_head));
          let v426_3: Space = intersect(&(*CONSTANT_12),&(v426_2));
          let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
          drop(v426_3);
          let v426_5: Space = subtract(&(*CONSTANT_0),&(v426_4));
          drop(v426_4);
          let v426_8: Space = if (v426_5).is_empty() { Space::new() } else {
            let v427_6: Path = concat_path(&(v413_3_head),&(v425_10_head));
            let mut v427_7 = Space::new();
            let mut v427_7_cursor = (v425_10_tail).read_zipper();
            for v427_7_byte in v427_7_cursor.child_mask().iter() {
              v427_7_cursor.descend_to_byte(v427_7_byte);
              {
              let v427_7_tail = v427_7_cursor.fork_read_zipper();
              let v427_7_head = Path::from_slice(&[v427_7_byte]);
              let v428_2: Space = singleton(&(v427_7_head));
              let v428_3: Space = intersect(&(*CONSTANT_12),&(v428_2));
              let v428_4: Space = if has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
              drop(v428_3);
              let v428_5: Space = subtract(&(*CONSTANT_0),&(v428_4));
              drop(v428_4);
              let v428_8: Space = if (v428_5).is_empty() { Space::new() } else {
                let v429_6: Path = concat_path(&(v427_6),&(v427_7_head));
                let v429_7: Space = routine_41(c, &(v429_6), &(v427_7_tail).make_space());
                compose(&(v428_5),&(v429_7))
              };
              drop(v428_5);
              let v428_9: Space = intersect(&(*CONSTANT_12),&(v428_2));
              drop(v428_2);
              let v428_10: Space = if has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
              drop(v428_9);
              let v428_12: Space = if (v428_10).is_empty() { Space::new() } else {
                let v430_6: Path = concat_path(&(v427_6),&(v427_7_head));
                let v430_11: Space = routine_42(c, &(v430_6), &(v427_7_tail).make_space());
                drop(v430_6);
                compose(&(v428_10),&(v430_11))
              };
              drop(v428_10);
              let v428_13: Space = unite(&(v428_8),&(v428_12));
              v427_7.join_into((v428_13).clone());
              }
              v427_7_cursor.ascend(1);
            }
            drop(v427_7_cursor);
            drop(v427_6);
            compose(&(v426_5),&(v427_7))
          };
          drop(v426_5);
          let v426_9: Space = intersect(&(*CONSTANT_12),&(v426_2));
          drop(v426_2);
          let v426_10: Space = if has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
          drop(v426_9);
          let v426_11: Space = compose(&(v426_10),&(v425_10_tail));
          drop(v426_10);
          let v426_12: Space = unite(&(v426_8),&(v426_11));
          drop(v426_11);
          v425_10.join_into((v426_12).clone());
          }
          v425_10_cursor.ascend(1);
        }
        drop(v425_10_cursor);
        compose(&(v414_9),&(v425_10))
      };
      drop(v414_9);
      let v414_12: Space = unite(&(v414_7),&(v414_11));
      v413_3.join_into((v414_12).clone());
      }
      v413_3_cursor.ascend(1);
    }
    drop(v413_3_cursor);
    drop(v413_2);
    let v413_4: Space = unite(&(v413_3),&(v358_85));
    let v413_5: Space = intersect(&(v413_4),&(*capture_2));
    if !v358_85.join_into((v413_5).clone()).is_element() { break; }
  }
  let v358_86: Space = subtract(&(v358_66),&(v358_85));
  let v358_87: Space = routine_11(c, &(v358_86));
  let mut v358_163 = Space::new();
  let mut v358_163_cursor = (v358_87).read_zipper();
  for v358_163_byte in v358_163_cursor.child_mask().iter() {
    v358_163_cursor.descend_to_byte(v358_163_byte);
    {
    let v358_163_tail = v358_163_cursor.fork_read_zipper();
    let v358_163_head = Path::from_slice(&[v358_163_byte]);
    let (v431_11,v431_19,) = native_block_2(c, capture_0, capture_1, capture_2, &v358_163_head, &v358_163_tail, &(*capture_4));
    let v431_20: Space = unite(&(v431_11),&(v431_19));
    v358_163.join_into((v431_20).clone());
    }
    v358_163_cursor.ascend(1);
  }
  drop(v358_163_cursor);
  let v358_164: Space = unite(&((*capture_3)),&(v358_163));
  let mut v358_183: Space = ((*capture_4)).clone();
  loop {
    let v506_1: Space = intersect(&(v358_183),&(*capture_2));
    let v506_2: Space = restrict_to(&(*capture_0),&(v506_1));
    drop(v506_1);
    let mut v506_3 = Space::new();
    let mut v506_3_cursor = (v506_2).read_zipper();
    for v506_3_byte in v506_3_cursor.child_mask().iter() {
      v506_3_cursor.descend_to_byte(v506_3_byte);
      {
      let v506_3_tail = v506_3_cursor.fork_read_zipper();
      let v506_3_head = Path::from_slice(&[v506_3_byte]);
      let v507_2: Space = singleton(&(v506_3_head));
      let v507_3: Space = intersect(&(*CONSTANT_12),&(v507_2));
      let v507_4: Space = if has_head(&(v507_3)) { singleton(&[]) } else { Space::new() };
      drop(v507_3);
      let v507_5: Space = subtract(&(*CONSTANT_0),&(v507_4));
      drop(v507_4);
      let v507_7: Space = if (v507_5).is_empty() { Space::new() } else {
        let mut v508_6 = Space::new();
        let mut v508_6_cursor = (v506_3_tail).read_zipper();
        for v508_6_byte in v508_6_cursor.child_mask().iter() {
          v508_6_cursor.descend_to_byte(v508_6_byte);
          {
          let v508_6_tail = v508_6_cursor.fork_read_zipper();
          let v508_6_head = Path::from_slice(&[v508_6_byte]);
          let v509_2: Space = singleton(&(v508_6_head));
          let v509_3: Space = intersect(&(*CONSTANT_12),&(v509_2));
          let v509_4: Space = if has_head(&(v509_3)) { singleton(&[]) } else { Space::new() };
          drop(v509_3);
          let v509_5: Space = subtract(&(*CONSTANT_0),&(v509_4));
          drop(v509_4);
          let v509_8: Space = if (v509_5).is_empty() { Space::new() } else {
            let v510_6: Path = concat_path(&(v506_3_head),&(v508_6_head));
            let mut v510_7 = Space::new();
            let mut v510_7_cursor = (v508_6_tail).read_zipper();
            for v510_7_byte in v510_7_cursor.child_mask().iter() {
              v510_7_cursor.descend_to_byte(v510_7_byte);
              {
              let v510_7_tail = v510_7_cursor.fork_read_zipper();
              let v510_7_head = Path::from_slice(&[v510_7_byte]);
              let v511_2: Space = singleton(&(v510_7_head));
              let v511_3: Space = intersect(&(*CONSTANT_12),&(v511_2));
              let v511_4: Space = if has_head(&(v511_3)) { singleton(&[]) } else { Space::new() };
              drop(v511_3);
              let v511_5: Space = subtract(&(*CONSTANT_0),&(v511_4));
              drop(v511_4);
              let v511_8: Space = if (v511_5).is_empty() { Space::new() } else {
                let v512_6: Path = concat_path(&(v510_6),&(v510_7_head));
                let v512_7: Space = routine_41(c, &(v512_6), &(v510_7_tail).make_space());
                compose(&(v511_5),&(v512_7))
              };
              drop(v511_5);
              let v511_9: Space = intersect(&(*CONSTANT_12),&(v511_2));
              drop(v511_2);
              let v511_10: Space = if has_head(&(v511_9)) { singleton(&[]) } else { Space::new() };
              drop(v511_9);
              let v511_12: Space = if (v511_10).is_empty() { Space::new() } else {
                let v513_6: Path = concat_path(&(v510_6),&(v510_7_head));
                let v513_11: Space = routine_42(c, &(v513_6), &(v510_7_tail).make_space());
                drop(v513_6);
                compose(&(v511_10),&(v513_11))
              };
              drop(v511_10);
              let v511_13: Space = unite(&(v511_8),&(v511_12));
              v510_7.join_into((v511_13).clone());
              }
              v510_7_cursor.ascend(1);
            }
            drop(v510_7_cursor);
            compose(&(v509_5),&(v510_7))
          };
          drop(v509_5);
          let v509_9: Space = intersect(&(*CONSTANT_12),&(v509_2));
          drop(v509_2);
          let v509_10: Space = if has_head(&(v509_9)) { singleton(&[]) } else { Space::new() };
          drop(v509_9);
          let v509_12: Space = if (v509_10).is_empty() { Space::new() } else {
            let v514_6: Path = concat_path(&(v506_3_head),&(v508_6_head));
            let mut v514_11 = Space::new();
            let mut v514_11_cursor = (v508_6_tail).read_zipper();
            for v514_11_byte in v514_11_cursor.child_mask().iter() {
              v514_11_cursor.descend_to_byte(v514_11_byte);
              {
              let v514_11_tail = v514_11_cursor.fork_read_zipper();
              let v514_11_head = Path::from_slice(&[v514_11_byte]);
              let v515_2: Space = singleton(&(v514_11_head));
              let v515_3: Space = intersect(&(*CONSTANT_12),&(v515_2));
              let v515_4: Space = if has_head(&(v515_3)) { singleton(&[]) } else { Space::new() };
              drop(v515_3);
              let v515_5: Space = subtract(&(*CONSTANT_0),&(v515_4));
              drop(v515_4);
              let v515_8: Space = if (v515_5).is_empty() { Space::new() } else {
                let v516_6: Path = concat_path(&(v514_6),&(v514_11_head));
                let v516_7: Space = routine_41(c, &(v516_6), &(v514_11_tail).make_space());
                compose(&(v515_5),&(v516_7))
              };
              drop(v515_5);
              let v515_9: Space = intersect(&(*CONSTANT_12),&(v515_2));
              drop(v515_2);
              let v515_10: Space = if has_head(&(v515_9)) { singleton(&[]) } else { Space::new() };
              drop(v515_9);
              let v515_12: Space = if (v515_10).is_empty() { Space::new() } else {
                let v517_6: Path = concat_path(&(v514_6),&(v514_11_head));
                let v517_11: Space = routine_43(c, &(v517_6), &(v514_11_tail).make_space());
                drop(v517_6);
                compose(&(v515_10),&(v517_11))
              };
              drop(v515_10);
              let v515_13: Space = unite(&(v515_8),&(v515_12));
              v514_11.join_into((v515_13).clone());
              }
              v514_11_cursor.ascend(1);
            }
            drop(v514_11_cursor);
            drop(v514_6);
            compose(&(v509_10),&(v514_11))
          };
          drop(v509_10);
          let v509_13: Space = unite(&(v509_8),&(v509_12));
          v508_6.join_into((v509_13).clone());
          }
          v508_6_cursor.ascend(1);
        }
        drop(v508_6_cursor);
        compose(&(v507_5),&(v508_6))
      };
      drop(v507_5);
      let v507_8: Space = intersect(&(*CONSTANT_12),&(v507_2));
      drop(v507_2);
      let v507_9: Space = if has_head(&(v507_8)) { singleton(&[]) } else { Space::new() };
      drop(v507_8);
      let v507_11: Space = if (v507_9).is_empty() { Space::new() } else {
        let mut v518_10 = Space::new();
        let mut v518_10_cursor = (v506_3_tail).read_zipper();
        for v518_10_byte in v518_10_cursor.child_mask().iter() {
          v518_10_cursor.descend_to_byte(v518_10_byte);
          {
          let v518_10_tail = v518_10_cursor.fork_read_zipper();
          let v518_10_head = Path::from_slice(&[v518_10_byte]);
          let v519_2: Space = singleton(&(v518_10_head));
          let v519_3: Space = intersect(&(*CONSTANT_12),&(v519_2));
          let v519_4: Space = if has_head(&(v519_3)) { singleton(&[]) } else { Space::new() };
          drop(v519_3);
          let v519_5: Space = subtract(&(*CONSTANT_0),&(v519_4));
          drop(v519_4);
          let v519_8: Space = if (v519_5).is_empty() { Space::new() } else {
            let v520_6: Path = concat_path(&(v506_3_head),&(v518_10_head));
            let mut v520_7 = Space::new();
            let mut v520_7_cursor = (v518_10_tail).read_zipper();
            for v520_7_byte in v520_7_cursor.child_mask().iter() {
              v520_7_cursor.descend_to_byte(v520_7_byte);
              {
              let v520_7_tail = v520_7_cursor.fork_read_zipper();
              let v520_7_head = Path::from_slice(&[v520_7_byte]);
              let v521_2: Space = singleton(&(v520_7_head));
              let v521_3: Space = intersect(&(*CONSTANT_12),&(v521_2));
              let v521_4: Space = if has_head(&(v521_3)) { singleton(&[]) } else { Space::new() };
              drop(v521_3);
              let v521_5: Space = subtract(&(*CONSTANT_0),&(v521_4));
              drop(v521_4);
              let v521_8: Space = if (v521_5).is_empty() { Space::new() } else {
                let v522_6: Path = concat_path(&(v520_6),&(v520_7_head));
                let v522_7: Space = routine_41(c, &(v522_6), &(v520_7_tail).make_space());
                compose(&(v521_5),&(v522_7))
              };
              drop(v521_5);
              let v521_9: Space = intersect(&(*CONSTANT_12),&(v521_2));
              drop(v521_2);
              let v521_10: Space = if has_head(&(v521_9)) { singleton(&[]) } else { Space::new() };
              drop(v521_9);
              let v521_12: Space = if (v521_10).is_empty() { Space::new() } else {
                let v523_6: Path = concat_path(&(v520_6),&(v520_7_head));
                let v523_11: Space = routine_42(c, &(v523_6), &(v520_7_tail).make_space());
                drop(v523_6);
                compose(&(v521_10),&(v523_11))
              };
              drop(v521_10);
              let v521_13: Space = unite(&(v521_8),&(v521_12));
              v520_7.join_into((v521_13).clone());
              }
              v520_7_cursor.ascend(1);
            }
            drop(v520_7_cursor);
            drop(v520_6);
            compose(&(v519_5),&(v520_7))
          };
          drop(v519_5);
          let v519_9: Space = intersect(&(*CONSTANT_12),&(v519_2));
          drop(v519_2);
          let v519_10: Space = if has_head(&(v519_9)) { singleton(&[]) } else { Space::new() };
          drop(v519_9);
          let v519_11: Space = compose(&(v519_10),&(v518_10_tail));
          drop(v519_10);
          let v519_12: Space = unite(&(v519_8),&(v519_11));
          drop(v519_11);
          v518_10.join_into((v519_12).clone());
          }
          v518_10_cursor.ascend(1);
        }
        drop(v518_10_cursor);
        compose(&(v507_9),&(v518_10))
      };
      drop(v507_9);
      let v507_12: Space = unite(&(v507_7),&(v507_11));
      v506_3.join_into((v507_12).clone());
      }
      v506_3_cursor.ascend(1);
    }
    drop(v506_3_cursor);
    drop(v506_2);
    let v506_4: Space = unite(&(v506_3),&(v358_183));
    let v506_5: Space = intersect(&(v506_4),&(*capture_2));
    if !v358_183.join_into((v506_5).clone()).is_element() { break; }
  }
  let mut v358_202: Space = ((*capture_4)).clone();
  loop {
    let v524_1: Space = intersect(&(v358_202),&(*capture_2));
    let v524_2: Space = restrict_to(&(*capture_1),&(v524_1));
    drop(v524_1);
    let mut v524_3 = Space::new();
    let mut v524_3_cursor = (v524_2).read_zipper();
    for v524_3_byte in v524_3_cursor.child_mask().iter() {
      v524_3_cursor.descend_to_byte(v524_3_byte);
      {
      let v524_3_tail = v524_3_cursor.fork_read_zipper();
      let v524_3_head = Path::from_slice(&[v524_3_byte]);
      let v525_2: Space = singleton(&(v524_3_head));
      let v525_3: Space = intersect(&(*CONSTANT_12),&(v525_2));
      let v525_4: Space = if has_head(&(v525_3)) { singleton(&[]) } else { Space::new() };
      drop(v525_3);
      let v525_5: Space = subtract(&(*CONSTANT_0),&(v525_4));
      drop(v525_4);
      let v525_7: Space = if (v525_5).is_empty() { Space::new() } else {
        let mut v526_6 = Space::new();
        let mut v526_6_cursor = (v524_3_tail).read_zipper();
        for v526_6_byte in v526_6_cursor.child_mask().iter() {
          v526_6_cursor.descend_to_byte(v526_6_byte);
          {
          let v526_6_tail = v526_6_cursor.fork_read_zipper();
          let v526_6_head = Path::from_slice(&[v526_6_byte]);
          let v527_2: Space = singleton(&(v526_6_head));
          let v527_3: Space = intersect(&(*CONSTANT_12),&(v527_2));
          let v527_4: Space = if has_head(&(v527_3)) { singleton(&[]) } else { Space::new() };
          drop(v527_3);
          let v527_5: Space = subtract(&(*CONSTANT_0),&(v527_4));
          drop(v527_4);
          let v527_8: Space = if (v527_5).is_empty() { Space::new() } else {
            let v528_6: Path = concat_path(&(v524_3_head),&(v526_6_head));
            let mut v528_7 = Space::new();
            let mut v528_7_cursor = (v526_6_tail).read_zipper();
            for v528_7_byte in v528_7_cursor.child_mask().iter() {
              v528_7_cursor.descend_to_byte(v528_7_byte);
              {
              let v528_7_tail = v528_7_cursor.fork_read_zipper();
              let v528_7_head = Path::from_slice(&[v528_7_byte]);
              let v529_2: Space = singleton(&(v528_7_head));
              let v529_3: Space = intersect(&(*CONSTANT_12),&(v529_2));
              let v529_4: Space = if has_head(&(v529_3)) { singleton(&[]) } else { Space::new() };
              drop(v529_3);
              let v529_5: Space = subtract(&(*CONSTANT_0),&(v529_4));
              drop(v529_4);
              let v529_8: Space = if (v529_5).is_empty() { Space::new() } else {
                let v530_6: Path = concat_path(&(v528_6),&(v528_7_head));
                let v530_7: Space = routine_41(c, &(v530_6), &(v528_7_tail).make_space());
                compose(&(v529_5),&(v530_7))
              };
              drop(v529_5);
              let v529_9: Space = intersect(&(*CONSTANT_12),&(v529_2));
              drop(v529_2);
              let v529_10: Space = if has_head(&(v529_9)) { singleton(&[]) } else { Space::new() };
              drop(v529_9);
              let v529_12: Space = if (v529_10).is_empty() { Space::new() } else {
                let v531_6: Path = concat_path(&(v528_6),&(v528_7_head));
                let v531_11: Space = routine_42(c, &(v531_6), &(v528_7_tail).make_space());
                drop(v531_6);
                compose(&(v529_10),&(v531_11))
              };
              drop(v529_10);
              let v529_13: Space = unite(&(v529_8),&(v529_12));
              v528_7.join_into((v529_13).clone());
              }
              v528_7_cursor.ascend(1);
            }
            drop(v528_7_cursor);
            compose(&(v527_5),&(v528_7))
          };
          drop(v527_5);
          let v527_9: Space = intersect(&(*CONSTANT_12),&(v527_2));
          drop(v527_2);
          let v527_10: Space = if has_head(&(v527_9)) { singleton(&[]) } else { Space::new() };
          drop(v527_9);
          let v527_12: Space = if (v527_10).is_empty() { Space::new() } else {
            let v532_6: Path = concat_path(&(v524_3_head),&(v526_6_head));
            let mut v532_11 = Space::new();
            let mut v532_11_cursor = (v526_6_tail).read_zipper();
            for v532_11_byte in v532_11_cursor.child_mask().iter() {
              v532_11_cursor.descend_to_byte(v532_11_byte);
              {
              let v532_11_tail = v532_11_cursor.fork_read_zipper();
              let v532_11_head = Path::from_slice(&[v532_11_byte]);
              let v533_2: Space = singleton(&(v532_11_head));
              let v533_3: Space = intersect(&(*CONSTANT_12),&(v533_2));
              let v533_4: Space = if has_head(&(v533_3)) { singleton(&[]) } else { Space::new() };
              drop(v533_3);
              let v533_5: Space = subtract(&(*CONSTANT_0),&(v533_4));
              drop(v533_4);
              let v533_8: Space = if (v533_5).is_empty() { Space::new() } else {
                let v534_6: Path = concat_path(&(v532_6),&(v532_11_head));
                let v534_7: Space = routine_41(c, &(v534_6), &(v532_11_tail).make_space());
                compose(&(v533_5),&(v534_7))
              };
              drop(v533_5);
              let v533_9: Space = intersect(&(*CONSTANT_12),&(v533_2));
              drop(v533_2);
              let v533_10: Space = if has_head(&(v533_9)) { singleton(&[]) } else { Space::new() };
              drop(v533_9);
              let v533_12: Space = if (v533_10).is_empty() { Space::new() } else {
                let v535_6: Path = concat_path(&(v532_6),&(v532_11_head));
                let v535_11: Space = routine_43(c, &(v535_6), &(v532_11_tail).make_space());
                drop(v535_6);
                compose(&(v533_10),&(v535_11))
              };
              drop(v533_10);
              let v533_13: Space = unite(&(v533_8),&(v533_12));
              v532_11.join_into((v533_13).clone());
              }
              v532_11_cursor.ascend(1);
            }
            drop(v532_11_cursor);
            drop(v532_6);
            compose(&(v527_10),&(v532_11))
          };
          drop(v527_10);
          let v527_13: Space = unite(&(v527_8),&(v527_12));
          v526_6.join_into((v527_13).clone());
          }
          v526_6_cursor.ascend(1);
        }
        drop(v526_6_cursor);
        compose(&(v525_5),&(v526_6))
      };
      drop(v525_5);
      let v525_8: Space = intersect(&(*CONSTANT_12),&(v525_2));
      drop(v525_2);
      let v525_9: Space = if has_head(&(v525_8)) { singleton(&[]) } else { Space::new() };
      drop(v525_8);
      let v525_11: Space = if (v525_9).is_empty() { Space::new() } else {
        let mut v536_10 = Space::new();
        let mut v536_10_cursor = (v524_3_tail).read_zipper();
        for v536_10_byte in v536_10_cursor.child_mask().iter() {
          v536_10_cursor.descend_to_byte(v536_10_byte);
          {
          let v536_10_tail = v536_10_cursor.fork_read_zipper();
          let v536_10_head = Path::from_slice(&[v536_10_byte]);
          let v537_2: Space = singleton(&(v536_10_head));
          let v537_3: Space = intersect(&(*CONSTANT_12),&(v537_2));
          let v537_4: Space = if has_head(&(v537_3)) { singleton(&[]) } else { Space::new() };
          drop(v537_3);
          let v537_5: Space = subtract(&(*CONSTANT_0),&(v537_4));
          drop(v537_4);
          let v537_8: Space = if (v537_5).is_empty() { Space::new() } else {
            let v538_6: Path = concat_path(&(v524_3_head),&(v536_10_head));
            let mut v538_7 = Space::new();
            let mut v538_7_cursor = (v536_10_tail).read_zipper();
            for v538_7_byte in v538_7_cursor.child_mask().iter() {
              v538_7_cursor.descend_to_byte(v538_7_byte);
              {
              let v538_7_tail = v538_7_cursor.fork_read_zipper();
              let v538_7_head = Path::from_slice(&[v538_7_byte]);
              let v539_2: Space = singleton(&(v538_7_head));
              let v539_3: Space = intersect(&(*CONSTANT_12),&(v539_2));
              let v539_4: Space = if has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
              drop(v539_3);
              let v539_5: Space = subtract(&(*CONSTANT_0),&(v539_4));
              drop(v539_4);
              let v539_8: Space = if (v539_5).is_empty() { Space::new() } else {
                let v540_6: Path = concat_path(&(v538_6),&(v538_7_head));
                let v540_7: Space = routine_41(c, &(v540_6), &(v538_7_tail).make_space());
                compose(&(v539_5),&(v540_7))
              };
              drop(v539_5);
              let v539_9: Space = intersect(&(*CONSTANT_12),&(v539_2));
              drop(v539_2);
              let v539_10: Space = if has_head(&(v539_9)) { singleton(&[]) } else { Space::new() };
              drop(v539_9);
              let v539_12: Space = if (v539_10).is_empty() { Space::new() } else {
                let v541_6: Path = concat_path(&(v538_6),&(v538_7_head));
                let v541_11: Space = routine_42(c, &(v541_6), &(v538_7_tail).make_space());
                drop(v541_6);
                compose(&(v539_10),&(v541_11))
              };
              drop(v539_10);
              let v539_13: Space = unite(&(v539_8),&(v539_12));
              v538_7.join_into((v539_13).clone());
              }
              v538_7_cursor.ascend(1);
            }
            drop(v538_7_cursor);
            drop(v538_6);
            compose(&(v537_5),&(v538_7))
          };
          drop(v537_5);
          let v537_9: Space = intersect(&(*CONSTANT_12),&(v537_2));
          drop(v537_2);
          let v537_10: Space = if has_head(&(v537_9)) { singleton(&[]) } else { Space::new() };
          drop(v537_9);
          let v537_11: Space = compose(&(v537_10),&(v536_10_tail));
          drop(v537_10);
          let v537_12: Space = unite(&(v537_8),&(v537_11));
          drop(v537_11);
          v536_10.join_into((v537_12).clone());
          }
          v536_10_cursor.ascend(1);
        }
        drop(v536_10_cursor);
        compose(&(v525_9),&(v536_10))
      };
      drop(v525_9);
      let v525_12: Space = unite(&(v525_7),&(v525_11));
      v524_3.join_into((v525_12).clone());
      }
      v524_3_cursor.ascend(1);
    }
    drop(v524_3_cursor);
    drop(v524_2);
    let v524_4: Space = unite(&(v524_3),&(v358_202));
    let v524_5: Space = intersect(&(v524_4),&(*capture_2));
    if !v358_202.join_into((v524_5).clone()).is_element() { break; }
  }

((v358_163).clone(),(v358_164).clone(),(v358_183).clone(),(v358_202).clone(),(v358_66).clone(),(v358_85).clone(),(v358_86).clone(),(v358_87).clone(),)
}

#[inline(never)]
fn native_block_4(c: &mut Context,capture_0: &Space,capture_1: &Space,capture_2: &Space,capture_3: &Path,capture_4: &View<'_, '_>,capture_5: &Space) -> (Space,Space,) {
    let v542_2: Space = singleton(&((*capture_3)));
    let v542_3: Space = intersect(&(*CONSTANT_12),&(v542_2));
    let v542_4: Space = if has_head(&(v542_3)) { singleton(&[]) } else { Space::new() };
    drop(v542_3);
    let v542_5: Space = subtract(&(*CONSTANT_0),&(v542_4));
    drop(v542_4);
    let v542_10: Space = if (v542_5).is_empty() { Space::new() } else {
      let mut v543_6: Space = ((*capture_5)).clone();
      loop {
        let v544_1: Space = intersect(&(v543_6),&(*capture_2));
        let v544_2: Space = restrict_to(&(*capture_0),&(v544_1));
        drop(v544_1);
        let mut v544_3 = Space::new();
        let mut v544_3_cursor = (v544_2).read_zipper();
        for v544_3_byte in v544_3_cursor.child_mask().iter() {
          v544_3_cursor.descend_to_byte(v544_3_byte);
          {
          let v544_3_tail = v544_3_cursor.fork_read_zipper();
          let v544_3_head = Path::from_slice(&[v544_3_byte]);
          let v545_2: Space = singleton(&(v544_3_head));
          let v545_3: Space = intersect(&(*CONSTANT_12),&(v545_2));
          let v545_4: Space = if has_head(&(v545_3)) { singleton(&[]) } else { Space::new() };
          drop(v545_3);
          let v545_5: Space = subtract(&(*CONSTANT_0),&(v545_4));
          drop(v545_4);
          let v545_7: Space = if (v545_5).is_empty() { Space::new() } else {
            let mut v546_6 = Space::new();
            let mut v546_6_cursor = (v544_3_tail).read_zipper();
            for v546_6_byte in v546_6_cursor.child_mask().iter() {
              v546_6_cursor.descend_to_byte(v546_6_byte);
              {
              let v546_6_tail = v546_6_cursor.fork_read_zipper();
              let v546_6_head = Path::from_slice(&[v546_6_byte]);
              let v547_2: Space = singleton(&(v546_6_head));
              let v547_3: Space = intersect(&(*CONSTANT_12),&(v547_2));
              let v547_4: Space = if has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
              drop(v547_3);
              let v547_5: Space = subtract(&(*CONSTANT_0),&(v547_4));
              drop(v547_4);
              let v547_8: Space = if (v547_5).is_empty() { Space::new() } else {
                let v548_6: Path = concat_path(&(v544_3_head),&(v546_6_head));
                let mut v548_7 = Space::new();
                let mut v548_7_cursor = (v546_6_tail).read_zipper();
                for v548_7_byte in v548_7_cursor.child_mask().iter() {
                  v548_7_cursor.descend_to_byte(v548_7_byte);
                  {
                  let v548_7_tail = v548_7_cursor.fork_read_zipper();
                  let v548_7_head = Path::from_slice(&[v548_7_byte]);
                  let v549_2: Space = singleton(&(v548_7_head));
                  let v549_3: Space = intersect(&(*CONSTANT_12),&(v549_2));
                  let v549_4: Space = if has_head(&(v549_3)) { singleton(&[]) } else { Space::new() };
                  drop(v549_3);
                  let v549_5: Space = subtract(&(*CONSTANT_0),&(v549_4));
                  drop(v549_4);
                  let v549_8: Space = if (v549_5).is_empty() { Space::new() } else {
                    let v550_6: Path = concat_path(&(v548_6),&(v548_7_head));
                    let v550_7: Space = routine_41(c, &(v550_6), &(v548_7_tail).make_space());
                    compose(&(v549_5),&(v550_7))
                  };
                  drop(v549_5);
                  let v549_9: Space = intersect(&(*CONSTANT_12),&(v549_2));
                  drop(v549_2);
                  let v549_10: Space = if has_head(&(v549_9)) { singleton(&[]) } else { Space::new() };
                  drop(v549_9);
                  let v549_12: Space = if (v549_10).is_empty() { Space::new() } else {
                    let v551_6: Path = concat_path(&(v548_6),&(v548_7_head));
                    let v551_11: Space = routine_42(c, &(v551_6), &(v548_7_tail).make_space());
                    drop(v551_6);
                    compose(&(v549_10),&(v551_11))
                  };
                  drop(v549_10);
                  let v549_13: Space = unite(&(v549_8),&(v549_12));
                  v548_7.join_into((v549_13).clone());
                  }
                  v548_7_cursor.ascend(1);
                }
                drop(v548_7_cursor);
                compose(&(v547_5),&(v548_7))
              };
              drop(v547_5);
              let v547_9: Space = intersect(&(*CONSTANT_12),&(v547_2));
              drop(v547_2);
              let v547_10: Space = if has_head(&(v547_9)) { singleton(&[]) } else { Space::new() };
              drop(v547_9);
              let v547_12: Space = if (v547_10).is_empty() { Space::new() } else {
                let v552_6: Path = concat_path(&(v544_3_head),&(v546_6_head));
                let mut v552_11 = Space::new();
                let mut v552_11_cursor = (v546_6_tail).read_zipper();
                for v552_11_byte in v552_11_cursor.child_mask().iter() {
                  v552_11_cursor.descend_to_byte(v552_11_byte);
                  {
                  let v552_11_tail = v552_11_cursor.fork_read_zipper();
                  let v552_11_head = Path::from_slice(&[v552_11_byte]);
                  let v553_2: Space = singleton(&(v552_11_head));
                  let v553_3: Space = intersect(&(*CONSTANT_12),&(v553_2));
                  let v553_4: Space = if has_head(&(v553_3)) { singleton(&[]) } else { Space::new() };
                  drop(v553_3);
                  let v553_5: Space = subtract(&(*CONSTANT_0),&(v553_4));
                  drop(v553_4);
                  let v553_8: Space = if (v553_5).is_empty() { Space::new() } else {
                    let v554_6: Path = concat_path(&(v552_6),&(v552_11_head));
                    let v554_7: Space = routine_41(c, &(v554_6), &(v552_11_tail).make_space());
                    compose(&(v553_5),&(v554_7))
                  };
                  drop(v553_5);
                  let v553_9: Space = intersect(&(*CONSTANT_12),&(v553_2));
                  drop(v553_2);
                  let v553_10: Space = if has_head(&(v553_9)) { singleton(&[]) } else { Space::new() };
                  drop(v553_9);
                  let v553_12: Space = if (v553_10).is_empty() { Space::new() } else {
                    let v555_6: Path = concat_path(&(v552_6),&(v552_11_head));
                    let v555_11: Space = routine_43(c, &(v555_6), &(v552_11_tail).make_space());
                    drop(v555_6);
                    compose(&(v553_10),&(v555_11))
                  };
                  drop(v553_10);
                  let v553_13: Space = unite(&(v553_8),&(v553_12));
                  v552_11.join_into((v553_13).clone());
                  }
                  v552_11_cursor.ascend(1);
                }
                drop(v552_11_cursor);
                drop(v552_6);
                compose(&(v547_10),&(v552_11))
              };
              drop(v547_10);
              let v547_13: Space = unite(&(v547_8),&(v547_12));
              v546_6.join_into((v547_13).clone());
              }
              v546_6_cursor.ascend(1);
            }
            drop(v546_6_cursor);
            compose(&(v545_5),&(v546_6))
          };
          drop(v545_5);
          let v545_8: Space = intersect(&(*CONSTANT_12),&(v545_2));
          drop(v545_2);
          let v545_9: Space = if has_head(&(v545_8)) { singleton(&[]) } else { Space::new() };
          drop(v545_8);
          let v545_11: Space = if (v545_9).is_empty() { Space::new() } else {
            let mut v556_10 = Space::new();
            let mut v556_10_cursor = (v544_3_tail).read_zipper();
            for v556_10_byte in v556_10_cursor.child_mask().iter() {
              v556_10_cursor.descend_to_byte(v556_10_byte);
              {
              let v556_10_tail = v556_10_cursor.fork_read_zipper();
              let v556_10_head = Path::from_slice(&[v556_10_byte]);
              let v557_2: Space = singleton(&(v556_10_head));
              let v557_3: Space = intersect(&(*CONSTANT_12),&(v557_2));
              let v557_4: Space = if has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
              drop(v557_3);
              let v557_5: Space = subtract(&(*CONSTANT_0),&(v557_4));
              drop(v557_4);
              let v557_8: Space = if (v557_5).is_empty() { Space::new() } else {
                let v558_6: Path = concat_path(&(v544_3_head),&(v556_10_head));
                let mut v558_7 = Space::new();
                let mut v558_7_cursor = (v556_10_tail).read_zipper();
                for v558_7_byte in v558_7_cursor.child_mask().iter() {
                  v558_7_cursor.descend_to_byte(v558_7_byte);
                  {
                  let v558_7_tail = v558_7_cursor.fork_read_zipper();
                  let v558_7_head = Path::from_slice(&[v558_7_byte]);
                  let v559_2: Space = singleton(&(v558_7_head));
                  let v559_3: Space = intersect(&(*CONSTANT_12),&(v559_2));
                  let v559_4: Space = if has_head(&(v559_3)) { singleton(&[]) } else { Space::new() };
                  drop(v559_3);
                  let v559_5: Space = subtract(&(*CONSTANT_0),&(v559_4));
                  drop(v559_4);
                  let v559_8: Space = if (v559_5).is_empty() { Space::new() } else {
                    let v560_6: Path = concat_path(&(v558_6),&(v558_7_head));
                    let v560_7: Space = routine_41(c, &(v560_6), &(v558_7_tail).make_space());
                    compose(&(v559_5),&(v560_7))
                  };
                  drop(v559_5);
                  let v559_9: Space = intersect(&(*CONSTANT_12),&(v559_2));
                  drop(v559_2);
                  let v559_10: Space = if has_head(&(v559_9)) { singleton(&[]) } else { Space::new() };
                  drop(v559_9);
                  let v559_12: Space = if (v559_10).is_empty() { Space::new() } else {
                    let v561_6: Path = concat_path(&(v558_6),&(v558_7_head));
                    let v561_11: Space = routine_42(c, &(v561_6), &(v558_7_tail).make_space());
                    drop(v561_6);
                    compose(&(v559_10),&(v561_11))
                  };
                  drop(v559_10);
                  let v559_13: Space = unite(&(v559_8),&(v559_12));
                  v558_7.join_into((v559_13).clone());
                  }
                  v558_7_cursor.ascend(1);
                }
                drop(v558_7_cursor);
                drop(v558_6);
                compose(&(v557_5),&(v558_7))
              };
              drop(v557_5);
              let v557_9: Space = intersect(&(*CONSTANT_12),&(v557_2));
              drop(v557_2);
              let v557_10: Space = if has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
              drop(v557_9);
              let v557_11: Space = compose(&(v557_10),&(v556_10_tail));
              drop(v557_10);
              let v557_12: Space = unite(&(v557_8),&(v557_11));
              drop(v557_11);
              v556_10.join_into((v557_12).clone());
              }
              v556_10_cursor.ascend(1);
            }
            drop(v556_10_cursor);
            compose(&(v545_9),&(v556_10))
          };
          drop(v545_9);
          let v545_12: Space = unite(&(v545_7),&(v545_11));
          v544_3.join_into((v545_12).clone());
          }
          v544_3_cursor.ascend(1);
        }
        drop(v544_3_cursor);
        drop(v544_2);
        let v544_4: Space = unite(&(v544_3),&(v543_6));
        let v544_5: Space = intersect(&(v544_4),&(*capture_2));
        if !v543_6.join_into((v544_5).clone()).is_element() { break; }
      }
      let mut v543_7: Space = ((*capture_5)).clone();
      loop {
        let v562_1: Space = intersect(&(v543_7),&(*capture_2));
        let v562_2: Space = restrict_to(&(*capture_1),&(v562_1));
        drop(v562_1);
        let mut v562_3 = Space::new();
        let mut v562_3_cursor = (v562_2).read_zipper();
        for v562_3_byte in v562_3_cursor.child_mask().iter() {
          v562_3_cursor.descend_to_byte(v562_3_byte);
          {
          let v562_3_tail = v562_3_cursor.fork_read_zipper();
          let v562_3_head = Path::from_slice(&[v562_3_byte]);
          let v563_2: Space = singleton(&(v562_3_head));
          let v563_3: Space = intersect(&(*CONSTANT_12),&(v563_2));
          let v563_4: Space = if has_head(&(v563_3)) { singleton(&[]) } else { Space::new() };
          drop(v563_3);
          let v563_5: Space = subtract(&(*CONSTANT_0),&(v563_4));
          drop(v563_4);
          let v563_7: Space = if (v563_5).is_empty() { Space::new() } else {
            let mut v564_6 = Space::new();
            let mut v564_6_cursor = (v562_3_tail).read_zipper();
            for v564_6_byte in v564_6_cursor.child_mask().iter() {
              v564_6_cursor.descend_to_byte(v564_6_byte);
              {
              let v564_6_tail = v564_6_cursor.fork_read_zipper();
              let v564_6_head = Path::from_slice(&[v564_6_byte]);
              let v565_2: Space = singleton(&(v564_6_head));
              let v565_3: Space = intersect(&(*CONSTANT_12),&(v565_2));
              let v565_4: Space = if has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
              drop(v565_3);
              let v565_5: Space = subtract(&(*CONSTANT_0),&(v565_4));
              drop(v565_4);
              let v565_8: Space = if (v565_5).is_empty() { Space::new() } else {
                let v566_6: Path = concat_path(&(v562_3_head),&(v564_6_head));
                let mut v566_7 = Space::new();
                let mut v566_7_cursor = (v564_6_tail).read_zipper();
                for v566_7_byte in v566_7_cursor.child_mask().iter() {
                  v566_7_cursor.descend_to_byte(v566_7_byte);
                  {
                  let v566_7_tail = v566_7_cursor.fork_read_zipper();
                  let v566_7_head = Path::from_slice(&[v566_7_byte]);
                  let v567_2: Space = singleton(&(v566_7_head));
                  let v567_3: Space = intersect(&(*CONSTANT_12),&(v567_2));
                  let v567_4: Space = if has_head(&(v567_3)) { singleton(&[]) } else { Space::new() };
                  drop(v567_3);
                  let v567_5: Space = subtract(&(*CONSTANT_0),&(v567_4));
                  drop(v567_4);
                  let v567_8: Space = if (v567_5).is_empty() { Space::new() } else {
                    let v568_6: Path = concat_path(&(v566_6),&(v566_7_head));
                    let v568_7: Space = routine_41(c, &(v568_6), &(v566_7_tail).make_space());
                    compose(&(v567_5),&(v568_7))
                  };
                  drop(v567_5);
                  let v567_9: Space = intersect(&(*CONSTANT_12),&(v567_2));
                  drop(v567_2);
                  let v567_10: Space = if has_head(&(v567_9)) { singleton(&[]) } else { Space::new() };
                  drop(v567_9);
                  let v567_12: Space = if (v567_10).is_empty() { Space::new() } else {
                    let v569_6: Path = concat_path(&(v566_6),&(v566_7_head));
                    let v569_11: Space = routine_42(c, &(v569_6), &(v566_7_tail).make_space());
                    drop(v569_6);
                    compose(&(v567_10),&(v569_11))
                  };
                  drop(v567_10);
                  let v567_13: Space = unite(&(v567_8),&(v567_12));
                  v566_7.join_into((v567_13).clone());
                  }
                  v566_7_cursor.ascend(1);
                }
                drop(v566_7_cursor);
                compose(&(v565_5),&(v566_7))
              };
              drop(v565_5);
              let v565_9: Space = intersect(&(*CONSTANT_12),&(v565_2));
              drop(v565_2);
              let v565_10: Space = if has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
              drop(v565_9);
              let v565_12: Space = if (v565_10).is_empty() { Space::new() } else {
                let v570_6: Path = concat_path(&(v562_3_head),&(v564_6_head));
                let mut v570_11 = Space::new();
                let mut v570_11_cursor = (v564_6_tail).read_zipper();
                for v570_11_byte in v570_11_cursor.child_mask().iter() {
                  v570_11_cursor.descend_to_byte(v570_11_byte);
                  {
                  let v570_11_tail = v570_11_cursor.fork_read_zipper();
                  let v570_11_head = Path::from_slice(&[v570_11_byte]);
                  let v571_2: Space = singleton(&(v570_11_head));
                  let v571_3: Space = intersect(&(*CONSTANT_12),&(v571_2));
                  let v571_4: Space = if has_head(&(v571_3)) { singleton(&[]) } else { Space::new() };
                  drop(v571_3);
                  let v571_5: Space = subtract(&(*CONSTANT_0),&(v571_4));
                  drop(v571_4);
                  let v571_8: Space = if (v571_5).is_empty() { Space::new() } else {
                    let v572_6: Path = concat_path(&(v570_6),&(v570_11_head));
                    let v572_7: Space = routine_41(c, &(v572_6), &(v570_11_tail).make_space());
                    compose(&(v571_5),&(v572_7))
                  };
                  drop(v571_5);
                  let v571_9: Space = intersect(&(*CONSTANT_12),&(v571_2));
                  drop(v571_2);
                  let v571_10: Space = if has_head(&(v571_9)) { singleton(&[]) } else { Space::new() };
                  drop(v571_9);
                  let v571_12: Space = if (v571_10).is_empty() { Space::new() } else {
                    let v573_6: Path = concat_path(&(v570_6),&(v570_11_head));
                    let v573_11: Space = routine_43(c, &(v573_6), &(v570_11_tail).make_space());
                    drop(v573_6);
                    compose(&(v571_10),&(v573_11))
                  };
                  drop(v571_10);
                  let v571_13: Space = unite(&(v571_8),&(v571_12));
                  v570_11.join_into((v571_13).clone());
                  }
                  v570_11_cursor.ascend(1);
                }
                drop(v570_11_cursor);
                drop(v570_6);
                compose(&(v565_10),&(v570_11))
              };
              drop(v565_10);
              let v565_13: Space = unite(&(v565_8),&(v565_12));
              v564_6.join_into((v565_13).clone());
              }
              v564_6_cursor.ascend(1);
            }
            drop(v564_6_cursor);
            compose(&(v563_5),&(v564_6))
          };
          drop(v563_5);
          let v563_8: Space = intersect(&(*CONSTANT_12),&(v563_2));
          drop(v563_2);
          let v563_9: Space = if has_head(&(v563_8)) { singleton(&[]) } else { Space::new() };
          drop(v563_8);
          let v563_11: Space = if (v563_9).is_empty() { Space::new() } else {
            let mut v574_10 = Space::new();
            let mut v574_10_cursor = (v562_3_tail).read_zipper();
            for v574_10_byte in v574_10_cursor.child_mask().iter() {
              v574_10_cursor.descend_to_byte(v574_10_byte);
              {
              let v574_10_tail = v574_10_cursor.fork_read_zipper();
              let v574_10_head = Path::from_slice(&[v574_10_byte]);
              let v575_2: Space = singleton(&(v574_10_head));
              let v575_3: Space = intersect(&(*CONSTANT_12),&(v575_2));
              let v575_4: Space = if has_head(&(v575_3)) { singleton(&[]) } else { Space::new() };
              drop(v575_3);
              let v575_5: Space = subtract(&(*CONSTANT_0),&(v575_4));
              drop(v575_4);
              let v575_8: Space = if (v575_5).is_empty() { Space::new() } else {
                let v576_6: Path = concat_path(&(v562_3_head),&(v574_10_head));
                let mut v576_7 = Space::new();
                let mut v576_7_cursor = (v574_10_tail).read_zipper();
                for v576_7_byte in v576_7_cursor.child_mask().iter() {
                  v576_7_cursor.descend_to_byte(v576_7_byte);
                  {
                  let v576_7_tail = v576_7_cursor.fork_read_zipper();
                  let v576_7_head = Path::from_slice(&[v576_7_byte]);
                  let v577_2: Space = singleton(&(v576_7_head));
                  let v577_3: Space = intersect(&(*CONSTANT_12),&(v577_2));
                  let v577_4: Space = if has_head(&(v577_3)) { singleton(&[]) } else { Space::new() };
                  drop(v577_3);
                  let v577_5: Space = subtract(&(*CONSTANT_0),&(v577_4));
                  drop(v577_4);
                  let v577_8: Space = if (v577_5).is_empty() { Space::new() } else {
                    let v578_6: Path = concat_path(&(v576_6),&(v576_7_head));
                    let v578_7: Space = routine_41(c, &(v578_6), &(v576_7_tail).make_space());
                    compose(&(v577_5),&(v578_7))
                  };
                  drop(v577_5);
                  let v577_9: Space = intersect(&(*CONSTANT_12),&(v577_2));
                  drop(v577_2);
                  let v577_10: Space = if has_head(&(v577_9)) { singleton(&[]) } else { Space::new() };
                  drop(v577_9);
                  let v577_12: Space = if (v577_10).is_empty() { Space::new() } else {
                    let v579_6: Path = concat_path(&(v576_6),&(v576_7_head));
                    let v579_11: Space = routine_42(c, &(v579_6), &(v576_7_tail).make_space());
                    drop(v579_6);
                    compose(&(v577_10),&(v579_11))
                  };
                  drop(v577_10);
                  let v577_13: Space = unite(&(v577_8),&(v577_12));
                  v576_7.join_into((v577_13).clone());
                  }
                  v576_7_cursor.ascend(1);
                }
                drop(v576_7_cursor);
                drop(v576_6);
                compose(&(v575_5),&(v576_7))
              };
              drop(v575_5);
              let v575_9: Space = intersect(&(*CONSTANT_12),&(v575_2));
              drop(v575_2);
              let v575_10: Space = if has_head(&(v575_9)) { singleton(&[]) } else { Space::new() };
              drop(v575_9);
              let v575_11: Space = compose(&(v575_10),&(v574_10_tail));
              drop(v575_10);
              let v575_12: Space = unite(&(v575_8),&(v575_11));
              drop(v575_11);
              v574_10.join_into((v575_12).clone());
              }
              v574_10_cursor.ascend(1);
            }
            drop(v574_10_cursor);
            compose(&(v563_9),&(v574_10))
          };
          drop(v563_9);
          let v563_12: Space = unite(&(v563_7),&(v563_11));
          v562_3.join_into((v563_12).clone());
          }
          v562_3_cursor.ascend(1);
        }
        drop(v562_3_cursor);
        drop(v562_2);
        let v562_4: Space = unite(&(v562_3),&(v543_7));
        let v562_5: Space = intersect(&(v562_4),&(*capture_2));
        if !v543_7.join_into((v562_5).clone()).is_element() { break; }
      }
      let v543_8: Space = subtract(&(v543_6),&(v543_7));
      let v543_9: Space = routine_16(c, &((*capture_3)), &((*capture_4)).make_space(), &(*capture_0), &(*capture_1), &(v543_8));
      compose(&(v542_5),&(v543_9))
    };
    drop(v542_5);
    let v542_11: Space = intersect(&(*CONSTANT_12),&(v542_2));
    drop(v542_2);
    let v542_12: Space = if has_head(&(v542_11)) { singleton(&[]) } else { Space::new() };
    drop(v542_11);
    let v542_17: Space = if (v542_12).is_empty() { Space::new() } else {
      let mut v580_13: Space = ((*capture_5)).clone();
      loop {
        let v581_1: Space = intersect(&(v580_13),&(*capture_2));
        let v581_2: Space = restrict_to(&(*capture_0),&(v581_1));
        drop(v581_1);
        let mut v581_3 = Space::new();
        let mut v581_3_cursor = (v581_2).read_zipper();
        for v581_3_byte in v581_3_cursor.child_mask().iter() {
          v581_3_cursor.descend_to_byte(v581_3_byte);
          {
          let v581_3_tail = v581_3_cursor.fork_read_zipper();
          let v581_3_head = Path::from_slice(&[v581_3_byte]);
          let v582_2: Space = singleton(&(v581_3_head));
          let v582_3: Space = intersect(&(*CONSTANT_12),&(v582_2));
          let v582_4: Space = if has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
          drop(v582_3);
          let v582_5: Space = subtract(&(*CONSTANT_0),&(v582_4));
          drop(v582_4);
          let v582_7: Space = if (v582_5).is_empty() { Space::new() } else {
            let mut v583_6 = Space::new();
            let mut v583_6_cursor = (v581_3_tail).read_zipper();
            for v583_6_byte in v583_6_cursor.child_mask().iter() {
              v583_6_cursor.descend_to_byte(v583_6_byte);
              {
              let v583_6_tail = v583_6_cursor.fork_read_zipper();
              let v583_6_head = Path::from_slice(&[v583_6_byte]);
              let v584_2: Space = singleton(&(v583_6_head));
              let v584_3: Space = intersect(&(*CONSTANT_12),&(v584_2));
              let v584_4: Space = if has_head(&(v584_3)) { singleton(&[]) } else { Space::new() };
              drop(v584_3);
              let v584_5: Space = subtract(&(*CONSTANT_0),&(v584_4));
              drop(v584_4);
              let v584_8: Space = if (v584_5).is_empty() { Space::new() } else {
                let v585_6: Path = concat_path(&(v581_3_head),&(v583_6_head));
                let mut v585_7 = Space::new();
                let mut v585_7_cursor = (v583_6_tail).read_zipper();
                for v585_7_byte in v585_7_cursor.child_mask().iter() {
                  v585_7_cursor.descend_to_byte(v585_7_byte);
                  {
                  let v585_7_tail = v585_7_cursor.fork_read_zipper();
                  let v585_7_head = Path::from_slice(&[v585_7_byte]);
                  let v586_2: Space = singleton(&(v585_7_head));
                  let v586_3: Space = intersect(&(*CONSTANT_12),&(v586_2));
                  let v586_4: Space = if has_head(&(v586_3)) { singleton(&[]) } else { Space::new() };
                  drop(v586_3);
                  let v586_5: Space = subtract(&(*CONSTANT_0),&(v586_4));
                  drop(v586_4);
                  let v586_8: Space = if (v586_5).is_empty() { Space::new() } else {
                    let v587_6: Path = concat_path(&(v585_6),&(v585_7_head));
                    let v587_7: Space = routine_41(c, &(v587_6), &(v585_7_tail).make_space());
                    compose(&(v586_5),&(v587_7))
                  };
                  drop(v586_5);
                  let v586_9: Space = intersect(&(*CONSTANT_12),&(v586_2));
                  drop(v586_2);
                  let v586_10: Space = if has_head(&(v586_9)) { singleton(&[]) } else { Space::new() };
                  drop(v586_9);
                  let v586_12: Space = if (v586_10).is_empty() { Space::new() } else {
                    let v588_6: Path = concat_path(&(v585_6),&(v585_7_head));
                    let v588_11: Space = routine_42(c, &(v588_6), &(v585_7_tail).make_space());
                    drop(v588_6);
                    compose(&(v586_10),&(v588_11))
                  };
                  drop(v586_10);
                  let v586_13: Space = unite(&(v586_8),&(v586_12));
                  v585_7.join_into((v586_13).clone());
                  }
                  v585_7_cursor.ascend(1);
                }
                drop(v585_7_cursor);
                compose(&(v584_5),&(v585_7))
              };
              drop(v584_5);
              let v584_9: Space = intersect(&(*CONSTANT_12),&(v584_2));
              drop(v584_2);
              let v584_10: Space = if has_head(&(v584_9)) { singleton(&[]) } else { Space::new() };
              drop(v584_9);
              let v584_12: Space = if (v584_10).is_empty() { Space::new() } else {
                let v589_6: Path = concat_path(&(v581_3_head),&(v583_6_head));
                let mut v589_11 = Space::new();
                let mut v589_11_cursor = (v583_6_tail).read_zipper();
                for v589_11_byte in v589_11_cursor.child_mask().iter() {
                  v589_11_cursor.descend_to_byte(v589_11_byte);
                  {
                  let v589_11_tail = v589_11_cursor.fork_read_zipper();
                  let v589_11_head = Path::from_slice(&[v589_11_byte]);
                  let v590_2: Space = singleton(&(v589_11_head));
                  let v590_3: Space = intersect(&(*CONSTANT_12),&(v590_2));
                  let v590_4: Space = if has_head(&(v590_3)) { singleton(&[]) } else { Space::new() };
                  drop(v590_3);
                  let v590_5: Space = subtract(&(*CONSTANT_0),&(v590_4));
                  drop(v590_4);
                  let v590_8: Space = if (v590_5).is_empty() { Space::new() } else {
                    let v591_6: Path = concat_path(&(v589_6),&(v589_11_head));
                    let v591_7: Space = routine_41(c, &(v591_6), &(v589_11_tail).make_space());
                    compose(&(v590_5),&(v591_7))
                  };
                  drop(v590_5);
                  let v590_9: Space = intersect(&(*CONSTANT_12),&(v590_2));
                  drop(v590_2);
                  let v590_10: Space = if has_head(&(v590_9)) { singleton(&[]) } else { Space::new() };
                  drop(v590_9);
                  let v590_12: Space = if (v590_10).is_empty() { Space::new() } else {
                    let v592_6: Path = concat_path(&(v589_6),&(v589_11_head));
                    let v592_11: Space = routine_43(c, &(v592_6), &(v589_11_tail).make_space());
                    drop(v592_6);
                    compose(&(v590_10),&(v592_11))
                  };
                  drop(v590_10);
                  let v590_13: Space = unite(&(v590_8),&(v590_12));
                  v589_11.join_into((v590_13).clone());
                  }
                  v589_11_cursor.ascend(1);
                }
                drop(v589_11_cursor);
                drop(v589_6);
                compose(&(v584_10),&(v589_11))
              };
              drop(v584_10);
              let v584_13: Space = unite(&(v584_8),&(v584_12));
              v583_6.join_into((v584_13).clone());
              }
              v583_6_cursor.ascend(1);
            }
            drop(v583_6_cursor);
            compose(&(v582_5),&(v583_6))
          };
          drop(v582_5);
          let v582_8: Space = intersect(&(*CONSTANT_12),&(v582_2));
          drop(v582_2);
          let v582_9: Space = if has_head(&(v582_8)) { singleton(&[]) } else { Space::new() };
          drop(v582_8);
          let v582_11: Space = if (v582_9).is_empty() { Space::new() } else {
            let mut v593_10 = Space::new();
            let mut v593_10_cursor = (v581_3_tail).read_zipper();
            for v593_10_byte in v593_10_cursor.child_mask().iter() {
              v593_10_cursor.descend_to_byte(v593_10_byte);
              {
              let v593_10_tail = v593_10_cursor.fork_read_zipper();
              let v593_10_head = Path::from_slice(&[v593_10_byte]);
              let v594_2: Space = singleton(&(v593_10_head));
              let v594_3: Space = intersect(&(*CONSTANT_12),&(v594_2));
              let v594_4: Space = if has_head(&(v594_3)) { singleton(&[]) } else { Space::new() };
              drop(v594_3);
              let v594_5: Space = subtract(&(*CONSTANT_0),&(v594_4));
              drop(v594_4);
              let v594_8: Space = if (v594_5).is_empty() { Space::new() } else {
                let v595_6: Path = concat_path(&(v581_3_head),&(v593_10_head));
                let mut v595_7 = Space::new();
                let mut v595_7_cursor = (v593_10_tail).read_zipper();
                for v595_7_byte in v595_7_cursor.child_mask().iter() {
                  v595_7_cursor.descend_to_byte(v595_7_byte);
                  {
                  let v595_7_tail = v595_7_cursor.fork_read_zipper();
                  let v595_7_head = Path::from_slice(&[v595_7_byte]);
                  let v596_2: Space = singleton(&(v595_7_head));
                  let v596_3: Space = intersect(&(*CONSTANT_12),&(v596_2));
                  let v596_4: Space = if has_head(&(v596_3)) { singleton(&[]) } else { Space::new() };
                  drop(v596_3);
                  let v596_5: Space = subtract(&(*CONSTANT_0),&(v596_4));
                  drop(v596_4);
                  let v596_8: Space = if (v596_5).is_empty() { Space::new() } else {
                    let v597_6: Path = concat_path(&(v595_6),&(v595_7_head));
                    let v597_7: Space = routine_41(c, &(v597_6), &(v595_7_tail).make_space());
                    compose(&(v596_5),&(v597_7))
                  };
                  drop(v596_5);
                  let v596_9: Space = intersect(&(*CONSTANT_12),&(v596_2));
                  drop(v596_2);
                  let v596_10: Space = if has_head(&(v596_9)) { singleton(&[]) } else { Space::new() };
                  drop(v596_9);
                  let v596_12: Space = if (v596_10).is_empty() { Space::new() } else {
                    let v598_6: Path = concat_path(&(v595_6),&(v595_7_head));
                    let v598_11: Space = routine_42(c, &(v598_6), &(v595_7_tail).make_space());
                    drop(v598_6);
                    compose(&(v596_10),&(v598_11))
                  };
                  drop(v596_10);
                  let v596_13: Space = unite(&(v596_8),&(v596_12));
                  v595_7.join_into((v596_13).clone());
                  }
                  v595_7_cursor.ascend(1);
                }
                drop(v595_7_cursor);
                drop(v595_6);
                compose(&(v594_5),&(v595_7))
              };
              drop(v594_5);
              let v594_9: Space = intersect(&(*CONSTANT_12),&(v594_2));
              drop(v594_2);
              let v594_10: Space = if has_head(&(v594_9)) { singleton(&[]) } else { Space::new() };
              drop(v594_9);
              let v594_11: Space = compose(&(v594_10),&(v593_10_tail));
              drop(v594_10);
              let v594_12: Space = unite(&(v594_8),&(v594_11));
              drop(v594_11);
              v593_10.join_into((v594_12).clone());
              }
              v593_10_cursor.ascend(1);
            }
            drop(v593_10_cursor);
            compose(&(v582_9),&(v593_10))
          };
          drop(v582_9);
          let v582_12: Space = unite(&(v582_7),&(v582_11));
          v581_3.join_into((v582_12).clone());
          }
          v581_3_cursor.ascend(1);
        }
        drop(v581_3_cursor);
        drop(v581_2);
        let v581_4: Space = unite(&(v581_3),&(v580_13));
        let v581_5: Space = intersect(&(v581_4),&(*capture_2));
        if !v580_13.join_into((v581_5).clone()).is_element() { break; }
      }
      let mut v580_14: Space = ((*capture_5)).clone();
      loop {
        let v599_1: Space = intersect(&(v580_14),&(*capture_2));
        let v599_2: Space = restrict_to(&(*capture_1),&(v599_1));
        drop(v599_1);
        let mut v599_3 = Space::new();
        let mut v599_3_cursor = (v599_2).read_zipper();
        for v599_3_byte in v599_3_cursor.child_mask().iter() {
          v599_3_cursor.descend_to_byte(v599_3_byte);
          {
          let v599_3_tail = v599_3_cursor.fork_read_zipper();
          let v599_3_head = Path::from_slice(&[v599_3_byte]);
          let v600_2: Space = singleton(&(v599_3_head));
          let v600_3: Space = intersect(&(*CONSTANT_12),&(v600_2));
          let v600_4: Space = if has_head(&(v600_3)) { singleton(&[]) } else { Space::new() };
          drop(v600_3);
          let v600_5: Space = subtract(&(*CONSTANT_0),&(v600_4));
          drop(v600_4);
          let v600_7: Space = if (v600_5).is_empty() { Space::new() } else {
            let mut v601_6 = Space::new();
            let mut v601_6_cursor = (v599_3_tail).read_zipper();
            for v601_6_byte in v601_6_cursor.child_mask().iter() {
              v601_6_cursor.descend_to_byte(v601_6_byte);
              {
              let v601_6_tail = v601_6_cursor.fork_read_zipper();
              let v601_6_head = Path::from_slice(&[v601_6_byte]);
              let v602_2: Space = singleton(&(v601_6_head));
              let v602_3: Space = intersect(&(*CONSTANT_12),&(v602_2));
              let v602_4: Space = if has_head(&(v602_3)) { singleton(&[]) } else { Space::new() };
              drop(v602_3);
              let v602_5: Space = subtract(&(*CONSTANT_0),&(v602_4));
              drop(v602_4);
              let v602_8: Space = if (v602_5).is_empty() { Space::new() } else {
                let v603_6: Path = concat_path(&(v599_3_head),&(v601_6_head));
                let mut v603_7 = Space::new();
                let mut v603_7_cursor = (v601_6_tail).read_zipper();
                for v603_7_byte in v603_7_cursor.child_mask().iter() {
                  v603_7_cursor.descend_to_byte(v603_7_byte);
                  {
                  let v603_7_tail = v603_7_cursor.fork_read_zipper();
                  let v603_7_head = Path::from_slice(&[v603_7_byte]);
                  let v604_2: Space = singleton(&(v603_7_head));
                  let v604_3: Space = intersect(&(*CONSTANT_12),&(v604_2));
                  let v604_4: Space = if has_head(&(v604_3)) { singleton(&[]) } else { Space::new() };
                  drop(v604_3);
                  let v604_5: Space = subtract(&(*CONSTANT_0),&(v604_4));
                  drop(v604_4);
                  let v604_8: Space = if (v604_5).is_empty() { Space::new() } else {
                    let v605_6: Path = concat_path(&(v603_6),&(v603_7_head));
                    let v605_7: Space = routine_41(c, &(v605_6), &(v603_7_tail).make_space());
                    compose(&(v604_5),&(v605_7))
                  };
                  drop(v604_5);
                  let v604_9: Space = intersect(&(*CONSTANT_12),&(v604_2));
                  drop(v604_2);
                  let v604_10: Space = if has_head(&(v604_9)) { singleton(&[]) } else { Space::new() };
                  drop(v604_9);
                  let v604_12: Space = if (v604_10).is_empty() { Space::new() } else {
                    let v606_6: Path = concat_path(&(v603_6),&(v603_7_head));
                    let v606_11: Space = routine_42(c, &(v606_6), &(v603_7_tail).make_space());
                    drop(v606_6);
                    compose(&(v604_10),&(v606_11))
                  };
                  drop(v604_10);
                  let v604_13: Space = unite(&(v604_8),&(v604_12));
                  v603_7.join_into((v604_13).clone());
                  }
                  v603_7_cursor.ascend(1);
                }
                drop(v603_7_cursor);
                compose(&(v602_5),&(v603_7))
              };
              drop(v602_5);
              let v602_9: Space = intersect(&(*CONSTANT_12),&(v602_2));
              drop(v602_2);
              let v602_10: Space = if has_head(&(v602_9)) { singleton(&[]) } else { Space::new() };
              drop(v602_9);
              let v602_12: Space = if (v602_10).is_empty() { Space::new() } else {
                let v607_6: Path = concat_path(&(v599_3_head),&(v601_6_head));
                let mut v607_11 = Space::new();
                let mut v607_11_cursor = (v601_6_tail).read_zipper();
                for v607_11_byte in v607_11_cursor.child_mask().iter() {
                  v607_11_cursor.descend_to_byte(v607_11_byte);
                  {
                  let v607_11_tail = v607_11_cursor.fork_read_zipper();
                  let v607_11_head = Path::from_slice(&[v607_11_byte]);
                  let v608_2: Space = singleton(&(v607_11_head));
                  let v608_3: Space = intersect(&(*CONSTANT_12),&(v608_2));
                  let v608_4: Space = if has_head(&(v608_3)) { singleton(&[]) } else { Space::new() };
                  drop(v608_3);
                  let v608_5: Space = subtract(&(*CONSTANT_0),&(v608_4));
                  drop(v608_4);
                  let v608_8: Space = if (v608_5).is_empty() { Space::new() } else {
                    let v609_6: Path = concat_path(&(v607_6),&(v607_11_head));
                    let v609_7: Space = routine_41(c, &(v609_6), &(v607_11_tail).make_space());
                    compose(&(v608_5),&(v609_7))
                  };
                  drop(v608_5);
                  let v608_9: Space = intersect(&(*CONSTANT_12),&(v608_2));
                  drop(v608_2);
                  let v608_10: Space = if has_head(&(v608_9)) { singleton(&[]) } else { Space::new() };
                  drop(v608_9);
                  let v608_12: Space = if (v608_10).is_empty() { Space::new() } else {
                    let v610_6: Path = concat_path(&(v607_6),&(v607_11_head));
                    let v610_11: Space = routine_43(c, &(v610_6), &(v607_11_tail).make_space());
                    drop(v610_6);
                    compose(&(v608_10),&(v610_11))
                  };
                  drop(v608_10);
                  let v608_13: Space = unite(&(v608_8),&(v608_12));
                  v607_11.join_into((v608_13).clone());
                  }
                  v607_11_cursor.ascend(1);
                }
                drop(v607_11_cursor);
                drop(v607_6);
                compose(&(v602_10),&(v607_11))
              };
              drop(v602_10);
              let v602_13: Space = unite(&(v602_8),&(v602_12));
              v601_6.join_into((v602_13).clone());
              }
              v601_6_cursor.ascend(1);
            }
            drop(v601_6_cursor);
            compose(&(v600_5),&(v601_6))
          };
          drop(v600_5);
          let v600_8: Space = intersect(&(*CONSTANT_12),&(v600_2));
          drop(v600_2);
          let v600_9: Space = if has_head(&(v600_8)) { singleton(&[]) } else { Space::new() };
          drop(v600_8);
          let v600_11: Space = if (v600_9).is_empty() { Space::new() } else {
            let mut v611_10 = Space::new();
            let mut v611_10_cursor = (v599_3_tail).read_zipper();
            for v611_10_byte in v611_10_cursor.child_mask().iter() {
              v611_10_cursor.descend_to_byte(v611_10_byte);
              {
              let v611_10_tail = v611_10_cursor.fork_read_zipper();
              let v611_10_head = Path::from_slice(&[v611_10_byte]);
              let v612_2: Space = singleton(&(v611_10_head));
              let v612_3: Space = intersect(&(*CONSTANT_12),&(v612_2));
              let v612_4: Space = if has_head(&(v612_3)) { singleton(&[]) } else { Space::new() };
              drop(v612_3);
              let v612_5: Space = subtract(&(*CONSTANT_0),&(v612_4));
              drop(v612_4);
              let v612_8: Space = if (v612_5).is_empty() { Space::new() } else {
                let v613_6: Path = concat_path(&(v599_3_head),&(v611_10_head));
                let mut v613_7 = Space::new();
                let mut v613_7_cursor = (v611_10_tail).read_zipper();
                for v613_7_byte in v613_7_cursor.child_mask().iter() {
                  v613_7_cursor.descend_to_byte(v613_7_byte);
                  {
                  let v613_7_tail = v613_7_cursor.fork_read_zipper();
                  let v613_7_head = Path::from_slice(&[v613_7_byte]);
                  let v614_2: Space = singleton(&(v613_7_head));
                  let v614_3: Space = intersect(&(*CONSTANT_12),&(v614_2));
                  let v614_4: Space = if has_head(&(v614_3)) { singleton(&[]) } else { Space::new() };
                  drop(v614_3);
                  let v614_5: Space = subtract(&(*CONSTANT_0),&(v614_4));
                  drop(v614_4);
                  let v614_8: Space = if (v614_5).is_empty() { Space::new() } else {
                    let v615_6: Path = concat_path(&(v613_6),&(v613_7_head));
                    let v615_7: Space = routine_41(c, &(v615_6), &(v613_7_tail).make_space());
                    compose(&(v614_5),&(v615_7))
                  };
                  drop(v614_5);
                  let v614_9: Space = intersect(&(*CONSTANT_12),&(v614_2));
                  drop(v614_2);
                  let v614_10: Space = if has_head(&(v614_9)) { singleton(&[]) } else { Space::new() };
                  drop(v614_9);
                  let v614_12: Space = if (v614_10).is_empty() { Space::new() } else {
                    let v616_6: Path = concat_path(&(v613_6),&(v613_7_head));
                    let v616_11: Space = routine_42(c, &(v616_6), &(v613_7_tail).make_space());
                    drop(v616_6);
                    compose(&(v614_10),&(v616_11))
                  };
                  drop(v614_10);
                  let v614_13: Space = unite(&(v614_8),&(v614_12));
                  v613_7.join_into((v614_13).clone());
                  }
                  v613_7_cursor.ascend(1);
                }
                drop(v613_7_cursor);
                drop(v613_6);
                compose(&(v612_5),&(v613_7))
              };
              drop(v612_5);
              let v612_9: Space = intersect(&(*CONSTANT_12),&(v612_2));
              drop(v612_2);
              let v612_10: Space = if has_head(&(v612_9)) { singleton(&[]) } else { Space::new() };
              drop(v612_9);
              let v612_11: Space = compose(&(v612_10),&(v611_10_tail));
              drop(v612_10);
              let v612_12: Space = unite(&(v612_8),&(v612_11));
              drop(v612_11);
              v611_10.join_into((v612_12).clone());
              }
              v611_10_cursor.ascend(1);
            }
            drop(v611_10_cursor);
            compose(&(v600_9),&(v611_10))
          };
          drop(v600_9);
          let v600_12: Space = unite(&(v600_7),&(v600_11));
          v599_3.join_into((v600_12).clone());
          }
          v599_3_cursor.ascend(1);
        }
        drop(v599_3_cursor);
        drop(v599_2);
        let v599_4: Space = unite(&(v599_3),&(v580_14));
        let v599_5: Space = intersect(&(v599_4),&(*capture_2));
        if !v580_14.join_into((v599_5).clone()).is_element() { break; }
      }
      let v580_15: Space = subtract(&(v580_13),&(v580_14));
      let v580_16: Space = routine_17(c, &((*capture_3)), &((*capture_4)).make_space(), &(*capture_0), &(*capture_1), &(v580_15));
      compose(&(v542_12),&(v580_16))
    };
    drop(v542_12);

((v542_10).clone(),(v542_17).clone(),)
}

#[inline(never)]
fn native_block_5(c: &mut Context,capture_0: &Space,capture_1: &Space,capture_2: &Space,capture_3: &Path,capture_4: &View<'_, '_>,capture_5: &Space) -> (Space,Space,) {
    let v653_2: Space = singleton(&((*capture_3)));
    let v653_3: Space = intersect(&(*CONSTANT_12),&(v653_2));
    let v653_4: Space = if has_head(&(v653_3)) { singleton(&[]) } else { Space::new() };
    drop(v653_3);
    let v653_5: Space = subtract(&(*CONSTANT_0),&(v653_4));
    drop(v653_4);
    let v653_10: Space = if (v653_5).is_empty() { Space::new() } else {
      let mut v654_6: Space = ((*capture_5)).clone();
      loop {
        let v655_1: Space = intersect(&(v654_6),&(*capture_2));
        let v655_2: Space = restrict_to(&(*capture_1),&(v655_1));
        drop(v655_1);
        let mut v655_3 = Space::new();
        let mut v655_3_cursor = (v655_2).read_zipper();
        for v655_3_byte in v655_3_cursor.child_mask().iter() {
          v655_3_cursor.descend_to_byte(v655_3_byte);
          {
          let v655_3_tail = v655_3_cursor.fork_read_zipper();
          let v655_3_head = Path::from_slice(&[v655_3_byte]);
          let v656_2: Space = singleton(&(v655_3_head));
          let v656_3: Space = intersect(&(*CONSTANT_12),&(v656_2));
          let v656_4: Space = if has_head(&(v656_3)) { singleton(&[]) } else { Space::new() };
          drop(v656_3);
          let v656_5: Space = subtract(&(*CONSTANT_0),&(v656_4));
          drop(v656_4);
          let v656_7: Space = if (v656_5).is_empty() { Space::new() } else {
            let mut v657_6 = Space::new();
            let mut v657_6_cursor = (v655_3_tail).read_zipper();
            for v657_6_byte in v657_6_cursor.child_mask().iter() {
              v657_6_cursor.descend_to_byte(v657_6_byte);
              {
              let v657_6_tail = v657_6_cursor.fork_read_zipper();
              let v657_6_head = Path::from_slice(&[v657_6_byte]);
              let v658_2: Space = singleton(&(v657_6_head));
              let v658_3: Space = intersect(&(*CONSTANT_12),&(v658_2));
              let v658_4: Space = if has_head(&(v658_3)) { singleton(&[]) } else { Space::new() };
              drop(v658_3);
              let v658_5: Space = subtract(&(*CONSTANT_0),&(v658_4));
              drop(v658_4);
              let v658_8: Space = if (v658_5).is_empty() { Space::new() } else {
                let v659_6: Path = concat_path(&(v655_3_head),&(v657_6_head));
                let mut v659_7 = Space::new();
                let mut v659_7_cursor = (v657_6_tail).read_zipper();
                for v659_7_byte in v659_7_cursor.child_mask().iter() {
                  v659_7_cursor.descend_to_byte(v659_7_byte);
                  {
                  let v659_7_tail = v659_7_cursor.fork_read_zipper();
                  let v659_7_head = Path::from_slice(&[v659_7_byte]);
                  let v660_2: Space = singleton(&(v659_7_head));
                  let v660_3: Space = intersect(&(*CONSTANT_12),&(v660_2));
                  let v660_4: Space = if has_head(&(v660_3)) { singleton(&[]) } else { Space::new() };
                  drop(v660_3);
                  let v660_5: Space = subtract(&(*CONSTANT_0),&(v660_4));
                  drop(v660_4);
                  let v660_8: Space = if (v660_5).is_empty() { Space::new() } else {
                    let v661_6: Path = concat_path(&(v659_6),&(v659_7_head));
                    let v661_7: Space = routine_41(c, &(v661_6), &(v659_7_tail).make_space());
                    compose(&(v660_5),&(v661_7))
                  };
                  drop(v660_5);
                  let v660_9: Space = intersect(&(*CONSTANT_12),&(v660_2));
                  drop(v660_2);
                  let v660_10: Space = if has_head(&(v660_9)) { singleton(&[]) } else { Space::new() };
                  drop(v660_9);
                  let v660_12: Space = if (v660_10).is_empty() { Space::new() } else {
                    let v662_6: Path = concat_path(&(v659_6),&(v659_7_head));
                    let v662_11: Space = routine_42(c, &(v662_6), &(v659_7_tail).make_space());
                    drop(v662_6);
                    compose(&(v660_10),&(v662_11))
                  };
                  drop(v660_10);
                  let v660_13: Space = unite(&(v660_8),&(v660_12));
                  v659_7.join_into((v660_13).clone());
                  }
                  v659_7_cursor.ascend(1);
                }
                drop(v659_7_cursor);
                compose(&(v658_5),&(v659_7))
              };
              drop(v658_5);
              let v658_9: Space = intersect(&(*CONSTANT_12),&(v658_2));
              drop(v658_2);
              let v658_10: Space = if has_head(&(v658_9)) { singleton(&[]) } else { Space::new() };
              drop(v658_9);
              let v658_12: Space = if (v658_10).is_empty() { Space::new() } else {
                let v663_6: Path = concat_path(&(v655_3_head),&(v657_6_head));
                let mut v663_11 = Space::new();
                let mut v663_11_cursor = (v657_6_tail).read_zipper();
                for v663_11_byte in v663_11_cursor.child_mask().iter() {
                  v663_11_cursor.descend_to_byte(v663_11_byte);
                  {
                  let v663_11_tail = v663_11_cursor.fork_read_zipper();
                  let v663_11_head = Path::from_slice(&[v663_11_byte]);
                  let v664_2: Space = singleton(&(v663_11_head));
                  let v664_3: Space = intersect(&(*CONSTANT_12),&(v664_2));
                  let v664_4: Space = if has_head(&(v664_3)) { singleton(&[]) } else { Space::new() };
                  drop(v664_3);
                  let v664_5: Space = subtract(&(*CONSTANT_0),&(v664_4));
                  drop(v664_4);
                  let v664_8: Space = if (v664_5).is_empty() { Space::new() } else {
                    let v665_6: Path = concat_path(&(v663_6),&(v663_11_head));
                    let v665_7: Space = routine_41(c, &(v665_6), &(v663_11_tail).make_space());
                    compose(&(v664_5),&(v665_7))
                  };
                  drop(v664_5);
                  let v664_9: Space = intersect(&(*CONSTANT_12),&(v664_2));
                  drop(v664_2);
                  let v664_10: Space = if has_head(&(v664_9)) { singleton(&[]) } else { Space::new() };
                  drop(v664_9);
                  let v664_12: Space = if (v664_10).is_empty() { Space::new() } else {
                    let v666_6: Path = concat_path(&(v663_6),&(v663_11_head));
                    let v666_11: Space = routine_43(c, &(v666_6), &(v663_11_tail).make_space());
                    drop(v666_6);
                    compose(&(v664_10),&(v666_11))
                  };
                  drop(v664_10);
                  let v664_13: Space = unite(&(v664_8),&(v664_12));
                  v663_11.join_into((v664_13).clone());
                  }
                  v663_11_cursor.ascend(1);
                }
                drop(v663_11_cursor);
                drop(v663_6);
                compose(&(v658_10),&(v663_11))
              };
              drop(v658_10);
              let v658_13: Space = unite(&(v658_8),&(v658_12));
              v657_6.join_into((v658_13).clone());
              }
              v657_6_cursor.ascend(1);
            }
            drop(v657_6_cursor);
            compose(&(v656_5),&(v657_6))
          };
          drop(v656_5);
          let v656_8: Space = intersect(&(*CONSTANT_12),&(v656_2));
          drop(v656_2);
          let v656_9: Space = if has_head(&(v656_8)) { singleton(&[]) } else { Space::new() };
          drop(v656_8);
          let v656_11: Space = if (v656_9).is_empty() { Space::new() } else {
            let mut v667_10 = Space::new();
            let mut v667_10_cursor = (v655_3_tail).read_zipper();
            for v667_10_byte in v667_10_cursor.child_mask().iter() {
              v667_10_cursor.descend_to_byte(v667_10_byte);
              {
              let v667_10_tail = v667_10_cursor.fork_read_zipper();
              let v667_10_head = Path::from_slice(&[v667_10_byte]);
              let v668_2: Space = singleton(&(v667_10_head));
              let v668_3: Space = intersect(&(*CONSTANT_12),&(v668_2));
              let v668_4: Space = if has_head(&(v668_3)) { singleton(&[]) } else { Space::new() };
              drop(v668_3);
              let v668_5: Space = subtract(&(*CONSTANT_0),&(v668_4));
              drop(v668_4);
              let v668_8: Space = if (v668_5).is_empty() { Space::new() } else {
                let v669_6: Path = concat_path(&(v655_3_head),&(v667_10_head));
                let mut v669_7 = Space::new();
                let mut v669_7_cursor = (v667_10_tail).read_zipper();
                for v669_7_byte in v669_7_cursor.child_mask().iter() {
                  v669_7_cursor.descend_to_byte(v669_7_byte);
                  {
                  let v669_7_tail = v669_7_cursor.fork_read_zipper();
                  let v669_7_head = Path::from_slice(&[v669_7_byte]);
                  let v670_2: Space = singleton(&(v669_7_head));
                  let v670_3: Space = intersect(&(*CONSTANT_12),&(v670_2));
                  let v670_4: Space = if has_head(&(v670_3)) { singleton(&[]) } else { Space::new() };
                  drop(v670_3);
                  let v670_5: Space = subtract(&(*CONSTANT_0),&(v670_4));
                  drop(v670_4);
                  let v670_8: Space = if (v670_5).is_empty() { Space::new() } else {
                    let v671_6: Path = concat_path(&(v669_6),&(v669_7_head));
                    let v671_7: Space = routine_41(c, &(v671_6), &(v669_7_tail).make_space());
                    compose(&(v670_5),&(v671_7))
                  };
                  drop(v670_5);
                  let v670_9: Space = intersect(&(*CONSTANT_12),&(v670_2));
                  drop(v670_2);
                  let v670_10: Space = if has_head(&(v670_9)) { singleton(&[]) } else { Space::new() };
                  drop(v670_9);
                  let v670_12: Space = if (v670_10).is_empty() { Space::new() } else {
                    let v672_6: Path = concat_path(&(v669_6),&(v669_7_head));
                    let v672_11: Space = routine_42(c, &(v672_6), &(v669_7_tail).make_space());
                    drop(v672_6);
                    compose(&(v670_10),&(v672_11))
                  };
                  drop(v670_10);
                  let v670_13: Space = unite(&(v670_8),&(v670_12));
                  v669_7.join_into((v670_13).clone());
                  }
                  v669_7_cursor.ascend(1);
                }
                drop(v669_7_cursor);
                drop(v669_6);
                compose(&(v668_5),&(v669_7))
              };
              drop(v668_5);
              let v668_9: Space = intersect(&(*CONSTANT_12),&(v668_2));
              drop(v668_2);
              let v668_10: Space = if has_head(&(v668_9)) { singleton(&[]) } else { Space::new() };
              drop(v668_9);
              let v668_11: Space = compose(&(v668_10),&(v667_10_tail));
              drop(v668_10);
              let v668_12: Space = unite(&(v668_8),&(v668_11));
              drop(v668_11);
              v667_10.join_into((v668_12).clone());
              }
              v667_10_cursor.ascend(1);
            }
            drop(v667_10_cursor);
            compose(&(v656_9),&(v667_10))
          };
          drop(v656_9);
          let v656_12: Space = unite(&(v656_7),&(v656_11));
          v655_3.join_into((v656_12).clone());
          }
          v655_3_cursor.ascend(1);
        }
        drop(v655_3_cursor);
        drop(v655_2);
        let v655_4: Space = unite(&(v655_3),&(v654_6));
        let v655_5: Space = intersect(&(v655_4),&(*capture_2));
        if !v654_6.join_into((v655_5).clone()).is_element() { break; }
      }
      let mut v654_7: Space = ((*capture_5)).clone();
      loop {
        let v673_1: Space = intersect(&(v654_7),&(*capture_2));
        let v673_2: Space = restrict_to(&(*capture_0),&(v673_1));
        drop(v673_1);
        let mut v673_3 = Space::new();
        let mut v673_3_cursor = (v673_2).read_zipper();
        for v673_3_byte in v673_3_cursor.child_mask().iter() {
          v673_3_cursor.descend_to_byte(v673_3_byte);
          {
          let v673_3_tail = v673_3_cursor.fork_read_zipper();
          let v673_3_head = Path::from_slice(&[v673_3_byte]);
          let v674_2: Space = singleton(&(v673_3_head));
          let v674_3: Space = intersect(&(*CONSTANT_12),&(v674_2));
          let v674_4: Space = if has_head(&(v674_3)) { singleton(&[]) } else { Space::new() };
          drop(v674_3);
          let v674_5: Space = subtract(&(*CONSTANT_0),&(v674_4));
          drop(v674_4);
          let v674_7: Space = if (v674_5).is_empty() { Space::new() } else {
            let mut v675_6 = Space::new();
            let mut v675_6_cursor = (v673_3_tail).read_zipper();
            for v675_6_byte in v675_6_cursor.child_mask().iter() {
              v675_6_cursor.descend_to_byte(v675_6_byte);
              {
              let v675_6_tail = v675_6_cursor.fork_read_zipper();
              let v675_6_head = Path::from_slice(&[v675_6_byte]);
              let v676_2: Space = singleton(&(v675_6_head));
              let v676_3: Space = intersect(&(*CONSTANT_12),&(v676_2));
              let v676_4: Space = if has_head(&(v676_3)) { singleton(&[]) } else { Space::new() };
              drop(v676_3);
              let v676_5: Space = subtract(&(*CONSTANT_0),&(v676_4));
              drop(v676_4);
              let v676_8: Space = if (v676_5).is_empty() { Space::new() } else {
                let v677_6: Path = concat_path(&(v673_3_head),&(v675_6_head));
                let mut v677_7 = Space::new();
                let mut v677_7_cursor = (v675_6_tail).read_zipper();
                for v677_7_byte in v677_7_cursor.child_mask().iter() {
                  v677_7_cursor.descend_to_byte(v677_7_byte);
                  {
                  let v677_7_tail = v677_7_cursor.fork_read_zipper();
                  let v677_7_head = Path::from_slice(&[v677_7_byte]);
                  let v678_2: Space = singleton(&(v677_7_head));
                  let v678_3: Space = intersect(&(*CONSTANT_12),&(v678_2));
                  let v678_4: Space = if has_head(&(v678_3)) { singleton(&[]) } else { Space::new() };
                  drop(v678_3);
                  let v678_5: Space = subtract(&(*CONSTANT_0),&(v678_4));
                  drop(v678_4);
                  let v678_8: Space = if (v678_5).is_empty() { Space::new() } else {
                    let v679_6: Path = concat_path(&(v677_6),&(v677_7_head));
                    let v679_7: Space = routine_41(c, &(v679_6), &(v677_7_tail).make_space());
                    compose(&(v678_5),&(v679_7))
                  };
                  drop(v678_5);
                  let v678_9: Space = intersect(&(*CONSTANT_12),&(v678_2));
                  drop(v678_2);
                  let v678_10: Space = if has_head(&(v678_9)) { singleton(&[]) } else { Space::new() };
                  drop(v678_9);
                  let v678_12: Space = if (v678_10).is_empty() { Space::new() } else {
                    let v680_6: Path = concat_path(&(v677_6),&(v677_7_head));
                    let v680_11: Space = routine_42(c, &(v680_6), &(v677_7_tail).make_space());
                    drop(v680_6);
                    compose(&(v678_10),&(v680_11))
                  };
                  drop(v678_10);
                  let v678_13: Space = unite(&(v678_8),&(v678_12));
                  v677_7.join_into((v678_13).clone());
                  }
                  v677_7_cursor.ascend(1);
                }
                drop(v677_7_cursor);
                compose(&(v676_5),&(v677_7))
              };
              drop(v676_5);
              let v676_9: Space = intersect(&(*CONSTANT_12),&(v676_2));
              drop(v676_2);
              let v676_10: Space = if has_head(&(v676_9)) { singleton(&[]) } else { Space::new() };
              drop(v676_9);
              let v676_12: Space = if (v676_10).is_empty() { Space::new() } else {
                let v681_6: Path = concat_path(&(v673_3_head),&(v675_6_head));
                let mut v681_11 = Space::new();
                let mut v681_11_cursor = (v675_6_tail).read_zipper();
                for v681_11_byte in v681_11_cursor.child_mask().iter() {
                  v681_11_cursor.descend_to_byte(v681_11_byte);
                  {
                  let v681_11_tail = v681_11_cursor.fork_read_zipper();
                  let v681_11_head = Path::from_slice(&[v681_11_byte]);
                  let v682_2: Space = singleton(&(v681_11_head));
                  let v682_3: Space = intersect(&(*CONSTANT_12),&(v682_2));
                  let v682_4: Space = if has_head(&(v682_3)) { singleton(&[]) } else { Space::new() };
                  drop(v682_3);
                  let v682_5: Space = subtract(&(*CONSTANT_0),&(v682_4));
                  drop(v682_4);
                  let v682_8: Space = if (v682_5).is_empty() { Space::new() } else {
                    let v683_6: Path = concat_path(&(v681_6),&(v681_11_head));
                    let v683_7: Space = routine_41(c, &(v683_6), &(v681_11_tail).make_space());
                    compose(&(v682_5),&(v683_7))
                  };
                  drop(v682_5);
                  let v682_9: Space = intersect(&(*CONSTANT_12),&(v682_2));
                  drop(v682_2);
                  let v682_10: Space = if has_head(&(v682_9)) { singleton(&[]) } else { Space::new() };
                  drop(v682_9);
                  let v682_12: Space = if (v682_10).is_empty() { Space::new() } else {
                    let v684_6: Path = concat_path(&(v681_6),&(v681_11_head));
                    let v684_11: Space = routine_43(c, &(v684_6), &(v681_11_tail).make_space());
                    drop(v684_6);
                    compose(&(v682_10),&(v684_11))
                  };
                  drop(v682_10);
                  let v682_13: Space = unite(&(v682_8),&(v682_12));
                  v681_11.join_into((v682_13).clone());
                  }
                  v681_11_cursor.ascend(1);
                }
                drop(v681_11_cursor);
                drop(v681_6);
                compose(&(v676_10),&(v681_11))
              };
              drop(v676_10);
              let v676_13: Space = unite(&(v676_8),&(v676_12));
              v675_6.join_into((v676_13).clone());
              }
              v675_6_cursor.ascend(1);
            }
            drop(v675_6_cursor);
            compose(&(v674_5),&(v675_6))
          };
          drop(v674_5);
          let v674_8: Space = intersect(&(*CONSTANT_12),&(v674_2));
          drop(v674_2);
          let v674_9: Space = if has_head(&(v674_8)) { singleton(&[]) } else { Space::new() };
          drop(v674_8);
          let v674_11: Space = if (v674_9).is_empty() { Space::new() } else {
            let mut v685_10 = Space::new();
            let mut v685_10_cursor = (v673_3_tail).read_zipper();
            for v685_10_byte in v685_10_cursor.child_mask().iter() {
              v685_10_cursor.descend_to_byte(v685_10_byte);
              {
              let v685_10_tail = v685_10_cursor.fork_read_zipper();
              let v685_10_head = Path::from_slice(&[v685_10_byte]);
              let v686_2: Space = singleton(&(v685_10_head));
              let v686_3: Space = intersect(&(*CONSTANT_12),&(v686_2));
              let v686_4: Space = if has_head(&(v686_3)) { singleton(&[]) } else { Space::new() };
              drop(v686_3);
              let v686_5: Space = subtract(&(*CONSTANT_0),&(v686_4));
              drop(v686_4);
              let v686_8: Space = if (v686_5).is_empty() { Space::new() } else {
                let v687_6: Path = concat_path(&(v673_3_head),&(v685_10_head));
                let mut v687_7 = Space::new();
                let mut v687_7_cursor = (v685_10_tail).read_zipper();
                for v687_7_byte in v687_7_cursor.child_mask().iter() {
                  v687_7_cursor.descend_to_byte(v687_7_byte);
                  {
                  let v687_7_tail = v687_7_cursor.fork_read_zipper();
                  let v687_7_head = Path::from_slice(&[v687_7_byte]);
                  let v688_2: Space = singleton(&(v687_7_head));
                  let v688_3: Space = intersect(&(*CONSTANT_12),&(v688_2));
                  let v688_4: Space = if has_head(&(v688_3)) { singleton(&[]) } else { Space::new() };
                  drop(v688_3);
                  let v688_5: Space = subtract(&(*CONSTANT_0),&(v688_4));
                  drop(v688_4);
                  let v688_8: Space = if (v688_5).is_empty() { Space::new() } else {
                    let v689_6: Path = concat_path(&(v687_6),&(v687_7_head));
                    let v689_7: Space = routine_41(c, &(v689_6), &(v687_7_tail).make_space());
                    compose(&(v688_5),&(v689_7))
                  };
                  drop(v688_5);
                  let v688_9: Space = intersect(&(*CONSTANT_12),&(v688_2));
                  drop(v688_2);
                  let v688_10: Space = if has_head(&(v688_9)) { singleton(&[]) } else { Space::new() };
                  drop(v688_9);
                  let v688_12: Space = if (v688_10).is_empty() { Space::new() } else {
                    let v690_6: Path = concat_path(&(v687_6),&(v687_7_head));
                    let v690_11: Space = routine_42(c, &(v690_6), &(v687_7_tail).make_space());
                    drop(v690_6);
                    compose(&(v688_10),&(v690_11))
                  };
                  drop(v688_10);
                  let v688_13: Space = unite(&(v688_8),&(v688_12));
                  v687_7.join_into((v688_13).clone());
                  }
                  v687_7_cursor.ascend(1);
                }
                drop(v687_7_cursor);
                drop(v687_6);
                compose(&(v686_5),&(v687_7))
              };
              drop(v686_5);
              let v686_9: Space = intersect(&(*CONSTANT_12),&(v686_2));
              drop(v686_2);
              let v686_10: Space = if has_head(&(v686_9)) { singleton(&[]) } else { Space::new() };
              drop(v686_9);
              let v686_11: Space = compose(&(v686_10),&(v685_10_tail));
              drop(v686_10);
              let v686_12: Space = unite(&(v686_8),&(v686_11));
              drop(v686_11);
              v685_10.join_into((v686_12).clone());
              }
              v685_10_cursor.ascend(1);
            }
            drop(v685_10_cursor);
            compose(&(v674_9),&(v685_10))
          };
          drop(v674_9);
          let v674_12: Space = unite(&(v674_7),&(v674_11));
          v673_3.join_into((v674_12).clone());
          }
          v673_3_cursor.ascend(1);
        }
        drop(v673_3_cursor);
        drop(v673_2);
        let v673_4: Space = unite(&(v673_3),&(v654_7));
        let v673_5: Space = intersect(&(v673_4),&(*capture_2));
        if !v654_7.join_into((v673_5).clone()).is_element() { break; }
      }
      let v654_8: Space = subtract(&(v654_6),&(v654_7));
      let v654_9: Space = routine_16(c, &((*capture_3)), &((*capture_4)).make_space(), &(*capture_0), &(*capture_1), &(v654_8));
      compose(&(v653_5),&(v654_9))
    };
    drop(v653_5);
    let v653_11: Space = intersect(&(*CONSTANT_12),&(v653_2));
    drop(v653_2);
    let v653_12: Space = if has_head(&(v653_11)) { singleton(&[]) } else { Space::new() };
    drop(v653_11);
    let v653_17: Space = if (v653_12).is_empty() { Space::new() } else {
      let mut v691_13: Space = ((*capture_5)).clone();
      loop {
        let v692_1: Space = intersect(&(v691_13),&(*capture_2));
        let v692_2: Space = restrict_to(&(*capture_1),&(v692_1));
        drop(v692_1);
        let mut v692_3 = Space::new();
        let mut v692_3_cursor = (v692_2).read_zipper();
        for v692_3_byte in v692_3_cursor.child_mask().iter() {
          v692_3_cursor.descend_to_byte(v692_3_byte);
          {
          let v692_3_tail = v692_3_cursor.fork_read_zipper();
          let v692_3_head = Path::from_slice(&[v692_3_byte]);
          let v693_2: Space = singleton(&(v692_3_head));
          let v693_3: Space = intersect(&(*CONSTANT_12),&(v693_2));
          let v693_4: Space = if has_head(&(v693_3)) { singleton(&[]) } else { Space::new() };
          drop(v693_3);
          let v693_5: Space = subtract(&(*CONSTANT_0),&(v693_4));
          drop(v693_4);
          let v693_7: Space = if (v693_5).is_empty() { Space::new() } else {
            let mut v694_6 = Space::new();
            let mut v694_6_cursor = (v692_3_tail).read_zipper();
            for v694_6_byte in v694_6_cursor.child_mask().iter() {
              v694_6_cursor.descend_to_byte(v694_6_byte);
              {
              let v694_6_tail = v694_6_cursor.fork_read_zipper();
              let v694_6_head = Path::from_slice(&[v694_6_byte]);
              let v695_2: Space = singleton(&(v694_6_head));
              let v695_3: Space = intersect(&(*CONSTANT_12),&(v695_2));
              let v695_4: Space = if has_head(&(v695_3)) { singleton(&[]) } else { Space::new() };
              drop(v695_3);
              let v695_5: Space = subtract(&(*CONSTANT_0),&(v695_4));
              drop(v695_4);
              let v695_8: Space = if (v695_5).is_empty() { Space::new() } else {
                let v696_6: Path = concat_path(&(v692_3_head),&(v694_6_head));
                let mut v696_7 = Space::new();
                let mut v696_7_cursor = (v694_6_tail).read_zipper();
                for v696_7_byte in v696_7_cursor.child_mask().iter() {
                  v696_7_cursor.descend_to_byte(v696_7_byte);
                  {
                  let v696_7_tail = v696_7_cursor.fork_read_zipper();
                  let v696_7_head = Path::from_slice(&[v696_7_byte]);
                  let v697_2: Space = singleton(&(v696_7_head));
                  let v697_3: Space = intersect(&(*CONSTANT_12),&(v697_2));
                  let v697_4: Space = if has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
                  drop(v697_3);
                  let v697_5: Space = subtract(&(*CONSTANT_0),&(v697_4));
                  drop(v697_4);
                  let v697_8: Space = if (v697_5).is_empty() { Space::new() } else {
                    let v698_6: Path = concat_path(&(v696_6),&(v696_7_head));
                    let v698_7: Space = routine_41(c, &(v698_6), &(v696_7_tail).make_space());
                    compose(&(v697_5),&(v698_7))
                  };
                  drop(v697_5);
                  let v697_9: Space = intersect(&(*CONSTANT_12),&(v697_2));
                  drop(v697_2);
                  let v697_10: Space = if has_head(&(v697_9)) { singleton(&[]) } else { Space::new() };
                  drop(v697_9);
                  let v697_12: Space = if (v697_10).is_empty() { Space::new() } else {
                    let v699_6: Path = concat_path(&(v696_6),&(v696_7_head));
                    let v699_11: Space = routine_42(c, &(v699_6), &(v696_7_tail).make_space());
                    drop(v699_6);
                    compose(&(v697_10),&(v699_11))
                  };
                  drop(v697_10);
                  let v697_13: Space = unite(&(v697_8),&(v697_12));
                  v696_7.join_into((v697_13).clone());
                  }
                  v696_7_cursor.ascend(1);
                }
                drop(v696_7_cursor);
                compose(&(v695_5),&(v696_7))
              };
              drop(v695_5);
              let v695_9: Space = intersect(&(*CONSTANT_12),&(v695_2));
              drop(v695_2);
              let v695_10: Space = if has_head(&(v695_9)) { singleton(&[]) } else { Space::new() };
              drop(v695_9);
              let v695_12: Space = if (v695_10).is_empty() { Space::new() } else {
                let v700_6: Path = concat_path(&(v692_3_head),&(v694_6_head));
                let mut v700_11 = Space::new();
                let mut v700_11_cursor = (v694_6_tail).read_zipper();
                for v700_11_byte in v700_11_cursor.child_mask().iter() {
                  v700_11_cursor.descend_to_byte(v700_11_byte);
                  {
                  let v700_11_tail = v700_11_cursor.fork_read_zipper();
                  let v700_11_head = Path::from_slice(&[v700_11_byte]);
                  let v701_2: Space = singleton(&(v700_11_head));
                  let v701_3: Space = intersect(&(*CONSTANT_12),&(v701_2));
                  let v701_4: Space = if has_head(&(v701_3)) { singleton(&[]) } else { Space::new() };
                  drop(v701_3);
                  let v701_5: Space = subtract(&(*CONSTANT_0),&(v701_4));
                  drop(v701_4);
                  let v701_8: Space = if (v701_5).is_empty() { Space::new() } else {
                    let v702_6: Path = concat_path(&(v700_6),&(v700_11_head));
                    let v702_7: Space = routine_41(c, &(v702_6), &(v700_11_tail).make_space());
                    compose(&(v701_5),&(v702_7))
                  };
                  drop(v701_5);
                  let v701_9: Space = intersect(&(*CONSTANT_12),&(v701_2));
                  drop(v701_2);
                  let v701_10: Space = if has_head(&(v701_9)) { singleton(&[]) } else { Space::new() };
                  drop(v701_9);
                  let v701_12: Space = if (v701_10).is_empty() { Space::new() } else {
                    let v703_6: Path = concat_path(&(v700_6),&(v700_11_head));
                    let v703_11: Space = routine_43(c, &(v703_6), &(v700_11_tail).make_space());
                    drop(v703_6);
                    compose(&(v701_10),&(v703_11))
                  };
                  drop(v701_10);
                  let v701_13: Space = unite(&(v701_8),&(v701_12));
                  v700_11.join_into((v701_13).clone());
                  }
                  v700_11_cursor.ascend(1);
                }
                drop(v700_11_cursor);
                drop(v700_6);
                compose(&(v695_10),&(v700_11))
              };
              drop(v695_10);
              let v695_13: Space = unite(&(v695_8),&(v695_12));
              v694_6.join_into((v695_13).clone());
              }
              v694_6_cursor.ascend(1);
            }
            drop(v694_6_cursor);
            compose(&(v693_5),&(v694_6))
          };
          drop(v693_5);
          let v693_8: Space = intersect(&(*CONSTANT_12),&(v693_2));
          drop(v693_2);
          let v693_9: Space = if has_head(&(v693_8)) { singleton(&[]) } else { Space::new() };
          drop(v693_8);
          let v693_11: Space = if (v693_9).is_empty() { Space::new() } else {
            let mut v704_10 = Space::new();
            let mut v704_10_cursor = (v692_3_tail).read_zipper();
            for v704_10_byte in v704_10_cursor.child_mask().iter() {
              v704_10_cursor.descend_to_byte(v704_10_byte);
              {
              let v704_10_tail = v704_10_cursor.fork_read_zipper();
              let v704_10_head = Path::from_slice(&[v704_10_byte]);
              let v705_2: Space = singleton(&(v704_10_head));
              let v705_3: Space = intersect(&(*CONSTANT_12),&(v705_2));
              let v705_4: Space = if has_head(&(v705_3)) { singleton(&[]) } else { Space::new() };
              drop(v705_3);
              let v705_5: Space = subtract(&(*CONSTANT_0),&(v705_4));
              drop(v705_4);
              let v705_8: Space = if (v705_5).is_empty() { Space::new() } else {
                let v706_6: Path = concat_path(&(v692_3_head),&(v704_10_head));
                let mut v706_7 = Space::new();
                let mut v706_7_cursor = (v704_10_tail).read_zipper();
                for v706_7_byte in v706_7_cursor.child_mask().iter() {
                  v706_7_cursor.descend_to_byte(v706_7_byte);
                  {
                  let v706_7_tail = v706_7_cursor.fork_read_zipper();
                  let v706_7_head = Path::from_slice(&[v706_7_byte]);
                  let v707_2: Space = singleton(&(v706_7_head));
                  let v707_3: Space = intersect(&(*CONSTANT_12),&(v707_2));
                  let v707_4: Space = if has_head(&(v707_3)) { singleton(&[]) } else { Space::new() };
                  drop(v707_3);
                  let v707_5: Space = subtract(&(*CONSTANT_0),&(v707_4));
                  drop(v707_4);
                  let v707_8: Space = if (v707_5).is_empty() { Space::new() } else {
                    let v708_6: Path = concat_path(&(v706_6),&(v706_7_head));
                    let v708_7: Space = routine_41(c, &(v708_6), &(v706_7_tail).make_space());
                    compose(&(v707_5),&(v708_7))
                  };
                  drop(v707_5);
                  let v707_9: Space = intersect(&(*CONSTANT_12),&(v707_2));
                  drop(v707_2);
                  let v707_10: Space = if has_head(&(v707_9)) { singleton(&[]) } else { Space::new() };
                  drop(v707_9);
                  let v707_12: Space = if (v707_10).is_empty() { Space::new() } else {
                    let v709_6: Path = concat_path(&(v706_6),&(v706_7_head));
                    let v709_11: Space = routine_42(c, &(v709_6), &(v706_7_tail).make_space());
                    drop(v709_6);
                    compose(&(v707_10),&(v709_11))
                  };
                  drop(v707_10);
                  let v707_13: Space = unite(&(v707_8),&(v707_12));
                  v706_7.join_into((v707_13).clone());
                  }
                  v706_7_cursor.ascend(1);
                }
                drop(v706_7_cursor);
                drop(v706_6);
                compose(&(v705_5),&(v706_7))
              };
              drop(v705_5);
              let v705_9: Space = intersect(&(*CONSTANT_12),&(v705_2));
              drop(v705_2);
              let v705_10: Space = if has_head(&(v705_9)) { singleton(&[]) } else { Space::new() };
              drop(v705_9);
              let v705_11: Space = compose(&(v705_10),&(v704_10_tail));
              drop(v705_10);
              let v705_12: Space = unite(&(v705_8),&(v705_11));
              drop(v705_11);
              v704_10.join_into((v705_12).clone());
              }
              v704_10_cursor.ascend(1);
            }
            drop(v704_10_cursor);
            compose(&(v693_9),&(v704_10))
          };
          drop(v693_9);
          let v693_12: Space = unite(&(v693_7),&(v693_11));
          v692_3.join_into((v693_12).clone());
          }
          v692_3_cursor.ascend(1);
        }
        drop(v692_3_cursor);
        drop(v692_2);
        let v692_4: Space = unite(&(v692_3),&(v691_13));
        let v692_5: Space = intersect(&(v692_4),&(*capture_2));
        if !v691_13.join_into((v692_5).clone()).is_element() { break; }
      }
      let mut v691_14: Space = ((*capture_5)).clone();
      loop {
        let v710_1: Space = intersect(&(v691_14),&(*capture_2));
        let v710_2: Space = restrict_to(&(*capture_0),&(v710_1));
        drop(v710_1);
        let mut v710_3 = Space::new();
        let mut v710_3_cursor = (v710_2).read_zipper();
        for v710_3_byte in v710_3_cursor.child_mask().iter() {
          v710_3_cursor.descend_to_byte(v710_3_byte);
          {
          let v710_3_tail = v710_3_cursor.fork_read_zipper();
          let v710_3_head = Path::from_slice(&[v710_3_byte]);
          let v711_2: Space = singleton(&(v710_3_head));
          let v711_3: Space = intersect(&(*CONSTANT_12),&(v711_2));
          let v711_4: Space = if has_head(&(v711_3)) { singleton(&[]) } else { Space::new() };
          drop(v711_3);
          let v711_5: Space = subtract(&(*CONSTANT_0),&(v711_4));
          drop(v711_4);
          let v711_7: Space = if (v711_5).is_empty() { Space::new() } else {
            let mut v712_6 = Space::new();
            let mut v712_6_cursor = (v710_3_tail).read_zipper();
            for v712_6_byte in v712_6_cursor.child_mask().iter() {
              v712_6_cursor.descend_to_byte(v712_6_byte);
              {
              let v712_6_tail = v712_6_cursor.fork_read_zipper();
              let v712_6_head = Path::from_slice(&[v712_6_byte]);
              let v713_2: Space = singleton(&(v712_6_head));
              let v713_3: Space = intersect(&(*CONSTANT_12),&(v713_2));
              let v713_4: Space = if has_head(&(v713_3)) { singleton(&[]) } else { Space::new() };
              drop(v713_3);
              let v713_5: Space = subtract(&(*CONSTANT_0),&(v713_4));
              drop(v713_4);
              let v713_8: Space = if (v713_5).is_empty() { Space::new() } else {
                let v714_6: Path = concat_path(&(v710_3_head),&(v712_6_head));
                let mut v714_7 = Space::new();
                let mut v714_7_cursor = (v712_6_tail).read_zipper();
                for v714_7_byte in v714_7_cursor.child_mask().iter() {
                  v714_7_cursor.descend_to_byte(v714_7_byte);
                  {
                  let v714_7_tail = v714_7_cursor.fork_read_zipper();
                  let v714_7_head = Path::from_slice(&[v714_7_byte]);
                  let v715_2: Space = singleton(&(v714_7_head));
                  let v715_3: Space = intersect(&(*CONSTANT_12),&(v715_2));
                  let v715_4: Space = if has_head(&(v715_3)) { singleton(&[]) } else { Space::new() };
                  drop(v715_3);
                  let v715_5: Space = subtract(&(*CONSTANT_0),&(v715_4));
                  drop(v715_4);
                  let v715_8: Space = if (v715_5).is_empty() { Space::new() } else {
                    let v716_6: Path = concat_path(&(v714_6),&(v714_7_head));
                    let v716_7: Space = routine_41(c, &(v716_6), &(v714_7_tail).make_space());
                    compose(&(v715_5),&(v716_7))
                  };
                  drop(v715_5);
                  let v715_9: Space = intersect(&(*CONSTANT_12),&(v715_2));
                  drop(v715_2);
                  let v715_10: Space = if has_head(&(v715_9)) { singleton(&[]) } else { Space::new() };
                  drop(v715_9);
                  let v715_12: Space = if (v715_10).is_empty() { Space::new() } else {
                    let v717_6: Path = concat_path(&(v714_6),&(v714_7_head));
                    let v717_11: Space = routine_42(c, &(v717_6), &(v714_7_tail).make_space());
                    drop(v717_6);
                    compose(&(v715_10),&(v717_11))
                  };
                  drop(v715_10);
                  let v715_13: Space = unite(&(v715_8),&(v715_12));
                  v714_7.join_into((v715_13).clone());
                  }
                  v714_7_cursor.ascend(1);
                }
                drop(v714_7_cursor);
                compose(&(v713_5),&(v714_7))
              };
              drop(v713_5);
              let v713_9: Space = intersect(&(*CONSTANT_12),&(v713_2));
              drop(v713_2);
              let v713_10: Space = if has_head(&(v713_9)) { singleton(&[]) } else { Space::new() };
              drop(v713_9);
              let v713_12: Space = if (v713_10).is_empty() { Space::new() } else {
                let v718_6: Path = concat_path(&(v710_3_head),&(v712_6_head));
                let mut v718_11 = Space::new();
                let mut v718_11_cursor = (v712_6_tail).read_zipper();
                for v718_11_byte in v718_11_cursor.child_mask().iter() {
                  v718_11_cursor.descend_to_byte(v718_11_byte);
                  {
                  let v718_11_tail = v718_11_cursor.fork_read_zipper();
                  let v718_11_head = Path::from_slice(&[v718_11_byte]);
                  let v719_2: Space = singleton(&(v718_11_head));
                  let v719_3: Space = intersect(&(*CONSTANT_12),&(v719_2));
                  let v719_4: Space = if has_head(&(v719_3)) { singleton(&[]) } else { Space::new() };
                  drop(v719_3);
                  let v719_5: Space = subtract(&(*CONSTANT_0),&(v719_4));
                  drop(v719_4);
                  let v719_8: Space = if (v719_5).is_empty() { Space::new() } else {
                    let v720_6: Path = concat_path(&(v718_6),&(v718_11_head));
                    let v720_7: Space = routine_41(c, &(v720_6), &(v718_11_tail).make_space());
                    compose(&(v719_5),&(v720_7))
                  };
                  drop(v719_5);
                  let v719_9: Space = intersect(&(*CONSTANT_12),&(v719_2));
                  drop(v719_2);
                  let v719_10: Space = if has_head(&(v719_9)) { singleton(&[]) } else { Space::new() };
                  drop(v719_9);
                  let v719_12: Space = if (v719_10).is_empty() { Space::new() } else {
                    let v721_6: Path = concat_path(&(v718_6),&(v718_11_head));
                    let v721_11: Space = routine_43(c, &(v721_6), &(v718_11_tail).make_space());
                    drop(v721_6);
                    compose(&(v719_10),&(v721_11))
                  };
                  drop(v719_10);
                  let v719_13: Space = unite(&(v719_8),&(v719_12));
                  v718_11.join_into((v719_13).clone());
                  }
                  v718_11_cursor.ascend(1);
                }
                drop(v718_11_cursor);
                drop(v718_6);
                compose(&(v713_10),&(v718_11))
              };
              drop(v713_10);
              let v713_13: Space = unite(&(v713_8),&(v713_12));
              v712_6.join_into((v713_13).clone());
              }
              v712_6_cursor.ascend(1);
            }
            drop(v712_6_cursor);
            compose(&(v711_5),&(v712_6))
          };
          drop(v711_5);
          let v711_8: Space = intersect(&(*CONSTANT_12),&(v711_2));
          drop(v711_2);
          let v711_9: Space = if has_head(&(v711_8)) { singleton(&[]) } else { Space::new() };
          drop(v711_8);
          let v711_11: Space = if (v711_9).is_empty() { Space::new() } else {
            let mut v722_10 = Space::new();
            let mut v722_10_cursor = (v710_3_tail).read_zipper();
            for v722_10_byte in v722_10_cursor.child_mask().iter() {
              v722_10_cursor.descend_to_byte(v722_10_byte);
              {
              let v722_10_tail = v722_10_cursor.fork_read_zipper();
              let v722_10_head = Path::from_slice(&[v722_10_byte]);
              let v723_2: Space = singleton(&(v722_10_head));
              let v723_3: Space = intersect(&(*CONSTANT_12),&(v723_2));
              let v723_4: Space = if has_head(&(v723_3)) { singleton(&[]) } else { Space::new() };
              drop(v723_3);
              let v723_5: Space = subtract(&(*CONSTANT_0),&(v723_4));
              drop(v723_4);
              let v723_8: Space = if (v723_5).is_empty() { Space::new() } else {
                let v724_6: Path = concat_path(&(v710_3_head),&(v722_10_head));
                let mut v724_7 = Space::new();
                let mut v724_7_cursor = (v722_10_tail).read_zipper();
                for v724_7_byte in v724_7_cursor.child_mask().iter() {
                  v724_7_cursor.descend_to_byte(v724_7_byte);
                  {
                  let v724_7_tail = v724_7_cursor.fork_read_zipper();
                  let v724_7_head = Path::from_slice(&[v724_7_byte]);
                  let v725_2: Space = singleton(&(v724_7_head));
                  let v725_3: Space = intersect(&(*CONSTANT_12),&(v725_2));
                  let v725_4: Space = if has_head(&(v725_3)) { singleton(&[]) } else { Space::new() };
                  drop(v725_3);
                  let v725_5: Space = subtract(&(*CONSTANT_0),&(v725_4));
                  drop(v725_4);
                  let v725_8: Space = if (v725_5).is_empty() { Space::new() } else {
                    let v726_6: Path = concat_path(&(v724_6),&(v724_7_head));
                    let v726_7: Space = routine_41(c, &(v726_6), &(v724_7_tail).make_space());
                    compose(&(v725_5),&(v726_7))
                  };
                  drop(v725_5);
                  let v725_9: Space = intersect(&(*CONSTANT_12),&(v725_2));
                  drop(v725_2);
                  let v725_10: Space = if has_head(&(v725_9)) { singleton(&[]) } else { Space::new() };
                  drop(v725_9);
                  let v725_12: Space = if (v725_10).is_empty() { Space::new() } else {
                    let v727_6: Path = concat_path(&(v724_6),&(v724_7_head));
                    let v727_11: Space = routine_42(c, &(v727_6), &(v724_7_tail).make_space());
                    drop(v727_6);
                    compose(&(v725_10),&(v727_11))
                  };
                  drop(v725_10);
                  let v725_13: Space = unite(&(v725_8),&(v725_12));
                  v724_7.join_into((v725_13).clone());
                  }
                  v724_7_cursor.ascend(1);
                }
                drop(v724_7_cursor);
                drop(v724_6);
                compose(&(v723_5),&(v724_7))
              };
              drop(v723_5);
              let v723_9: Space = intersect(&(*CONSTANT_12),&(v723_2));
              drop(v723_2);
              let v723_10: Space = if has_head(&(v723_9)) { singleton(&[]) } else { Space::new() };
              drop(v723_9);
              let v723_11: Space = compose(&(v723_10),&(v722_10_tail));
              drop(v723_10);
              let v723_12: Space = unite(&(v723_8),&(v723_11));
              drop(v723_11);
              v722_10.join_into((v723_12).clone());
              }
              v722_10_cursor.ascend(1);
            }
            drop(v722_10_cursor);
            compose(&(v711_9),&(v722_10))
          };
          drop(v711_9);
          let v711_12: Space = unite(&(v711_7),&(v711_11));
          v710_3.join_into((v711_12).clone());
          }
          v710_3_cursor.ascend(1);
        }
        drop(v710_3_cursor);
        drop(v710_2);
        let v710_4: Space = unite(&(v710_3),&(v691_14));
        let v710_5: Space = intersect(&(v710_4),&(*capture_2));
        if !v691_14.join_into((v710_5).clone()).is_element() { break; }
      }
      let v691_15: Space = subtract(&(v691_13),&(v691_14));
      let v691_16: Space = routine_17(c, &((*capture_3)), &((*capture_4)).make_space(), &(*capture_0), &(*capture_1), &(v691_15));
      compose(&(v653_12),&(v691_16))
    };
    drop(v653_12);

((v653_10).clone(),(v653_17).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let (v0_155,v0_22,v0_44,v0_63,v0_64,v0_65,) = native_block_0(c);
  (v0_155).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v82_6 = Space::new();
  let mut v82_6_cursor = (*s0).read_zipper();
  for v82_6_byte in v82_6_cursor.child_mask().iter() {
    v82_6_cursor.descend_to_byte(v82_6_byte);
    {
    let v82_6_tail = v82_6_cursor.fork_read_zipper();
    let v82_6_head = Path::from_slice(&[v82_6_byte]);
    let v83_2: Space = singleton(&(v82_6_head));
    let v83_3: Space = intersect(&(*CONSTANT_12),&(v83_2));
    let v83_4: Space = if has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
    drop(v83_3);
    let v83_5: Space = subtract(&(*CONSTANT_0),&(v83_4));
    drop(v83_4);
    let mut v83_6 = Space::new();
    let mut v83_6_cursor = (v82_6_tail).read_zipper();
    for v83_6_byte in v83_6_cursor.child_mask().iter() {
      v83_6_cursor.descend_to_byte(v83_6_byte);
      {
      let v83_6_tail = v83_6_cursor.fork_read_zipper();
      let v83_6_head = Path::from_slice(&[v83_6_byte]);
      let v84_2: Space = Space::new();
      v83_6.join_into((v84_2).clone());
      }
      v83_6_cursor.ascend(1);
    }
    drop(v83_6_cursor);
    let v83_7: Space = compose(&(v83_5),&(v83_6));
    drop(v83_5);
    drop(v83_6);
    let v83_8: Space = intersect(&(*CONSTANT_12),&(v83_2));
    drop(v83_2);
    let v83_9: Space = if has_head(&(v83_8)) { singleton(&[]) } else { Space::new() };
    drop(v83_8);
    let v83_12: Space = if (v83_9).is_empty() { Space::new() } else {
      let v85_10: Path = concat_path(&(*p0),&(v82_6_head));
      let mut v85_11 = Space::new();
      let mut v85_11_cursor = (v82_6_tail).read_zipper();
      for v85_11_byte in v85_11_cursor.child_mask().iter() {
        v85_11_cursor.descend_to_byte(v85_11_byte);
        {
        let v85_11_tail = v85_11_cursor.fork_read_zipper();
        let v85_11_head = Path::from_slice(&[v85_11_byte]);
        let v86_2: Space = singleton(&(v85_11_head));
        let v86_3: Space = intersect(&(*CONSTANT_12),&(v86_2));
        drop(v86_2);
        let v86_4: Space = if has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
        drop(v86_3);
        let v86_7: Space = if (v86_4).is_empty() { Space::new() } else {
          let v87_5: Path = concat_path(&(v85_10),&(v85_11_head));
          let v87_6: Space = singleton(&(v87_5));
          drop(v87_5);
          compose(&(v86_4),&(v87_6))
        };
        drop(v86_4);
        v85_11.join_into((v86_7).clone());
        }
        v85_11_cursor.ascend(1);
      }
      drop(v85_11_cursor);
      drop(v85_10);
      compose(&(v83_9),&(v85_11))
    };
    drop(v83_9);
    let v83_13: Space = unite(&(v83_7),&(v83_12));
    drop(v83_7);
    drop(v83_12);
    v82_6.join_into((v83_13).clone());
    }
    v82_6_cursor.ascend(1);
  }
  drop(v82_6_cursor);
  (v82_6).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v88_5 = Space::new();
  let mut v88_5_cursor = (*s0).read_zipper();
  for v88_5_byte in v88_5_cursor.child_mask().iter() {
    v88_5_cursor.descend_to_byte(v88_5_byte);
    {
    let v88_5_tail = v88_5_cursor.fork_read_zipper();
    let v88_5_head = Path::from_slice(&[v88_5_byte]);
    let v89_2: Space = singleton(&(v88_5_head));
    let v89_3: Space = intersect(&(*CONSTANT_12),&(v89_2));
    let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
    drop(v89_3);
    let v89_5: Space = subtract(&(*CONSTANT_0),&(v89_4));
    drop(v89_4);
    let mut v89_6 = Space::new();
    let mut v89_6_cursor = (v88_5_tail).read_zipper();
    for v89_6_byte in v89_6_cursor.child_mask().iter() {
      v89_6_cursor.descend_to_byte(v89_6_byte);
      {
      let v89_6_tail = v89_6_cursor.fork_read_zipper();
      let v89_6_head = Path::from_slice(&[v89_6_byte]);
      let v90_2: Space = Space::new();
      v89_6.join_into((v90_2).clone());
      }
      v89_6_cursor.ascend(1);
    }
    drop(v89_6_cursor);
    let v89_7: Space = compose(&(v89_5),&(v89_6));
    drop(v89_5);
    drop(v89_6);
    let v89_8: Space = intersect(&(*CONSTANT_12),&(v89_2));
    drop(v89_2);
    let v89_9: Space = if has_head(&(v89_8)) { singleton(&[]) } else { Space::new() };
    drop(v89_8);
    let v89_12: Space = if (v89_9).is_empty() { Space::new() } else {
      let v91_10: Path = concat_path(&(*p0),&(v88_5_head));
      let v91_11: Space = singleton(&(v91_10));
      drop(v91_10);
      compose(&(v89_9),&(v91_11))
    };
    drop(v89_9);
    let v89_13: Space = unite(&(v89_7),&(v89_12));
    drop(v89_7);
    drop(v89_12);
    v88_5.join_into((v89_13).clone());
    }
    v88_5_cursor.ascend(1);
  }
  drop(v88_5_cursor);
  (v88_5).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v92_2: Space = singleton(&(*p0));
  (v92_2).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v93_21 = Space::new();
  let mut v93_21_cursor = (*s0).read_zipper();
  for v93_21_byte in v93_21_cursor.child_mask().iter() {
    v93_21_cursor.descend_to_byte(v93_21_byte);
    {
    let v93_21_tail = v93_21_cursor.fork_read_zipper();
    let v93_21_head = Path::from_slice(&[v93_21_byte]);
    let v94_2: Space = singleton(&(v93_21_head));
    let v94_3: Space = intersect(&(*CONSTANT_12),&(v94_2));
    let v94_4: Space = if has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
    drop(v94_3);
    let v94_5: Space = subtract(&(*CONSTANT_0),&(v94_4));
    drop(v94_4);
    let v94_8: Space = if (v94_5).is_empty() { Space::new() } else {
      let v95_6: Path = concat_path(&(*p0),&(v93_21_head));
      let mut v95_7 = Space::new();
      let mut v95_7_cursor = (v93_21_tail).read_zipper();
      for v95_7_byte in v95_7_cursor.child_mask().iter() {
        v95_7_cursor.descend_to_byte(v95_7_byte);
        {
        let v95_7_tail = v95_7_cursor.fork_read_zipper();
        let v95_7_head = Path::from_slice(&[v95_7_byte]);
        let v96_2: Space = singleton(&(v95_7_head));
        let v96_3: Space = intersect(&(*CONSTANT_12),&(v96_2));
        let v96_4: Space = if has_head(&(v96_3)) { singleton(&[]) } else { Space::new() };
        drop(v96_3);
        let v96_5: Space = subtract(&(*CONSTANT_0),&(v96_4));
        drop(v96_4);
        let v96_8: Space = if (v96_5).is_empty() { Space::new() } else {
          let v97_6: Path = concat_path(&(v95_6),&(v95_7_head));
          let mut v97_7 = Space::new();
          let mut v97_7_cursor = (v95_7_tail).read_zipper();
          for v97_7_byte in v97_7_cursor.child_mask().iter() {
            v97_7_cursor.descend_to_byte(v97_7_byte);
            {
            let v97_7_tail = v97_7_cursor.fork_read_zipper();
            let v97_7_head = Path::from_slice(&[v97_7_byte]);
            let v98_2: Space = singleton(&(v97_7_head));
            let v98_3: Space = intersect(&(*CONSTANT_12),&(v98_2));
            let v98_4: Space = if has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
            drop(v98_3);
            let v98_5: Space = subtract(&(*CONSTANT_0),&(v98_4));
            drop(v98_4);
            let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
              let v99_6: Path = concat_path(&(v97_6),&(v97_7_head));
              let v99_7: Space = routine_18(c, &(v99_6), &(*p1), &(v97_7_tail).make_space());
              compose(&(v98_5),&(v99_7))
            };
            drop(v98_5);
            let v98_9: Space = intersect(&(*CONSTANT_12),&(v98_2));
            drop(v98_2);
            let v98_10: Space = if has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
            drop(v98_9);
            let v98_12: Space = if (v98_10).is_empty() { Space::new() } else {
              let v100_6: Path = concat_path(&(v97_6),&(v97_7_head));
              let v100_11: Space = routine_19(c, &(v100_6), &(*p1), &(v97_7_tail).make_space());
              drop(v100_6);
              compose(&(v98_10),&(v100_11))
            };
            drop(v98_10);
            let v98_13: Space = unite(&(v98_8),&(v98_12));
            v97_7.join_into((v98_13).clone());
            }
            v97_7_cursor.ascend(1);
          }
          drop(v97_7_cursor);
          compose(&(v96_5),&(v97_7))
        };
        drop(v96_5);
        let v96_9: Space = intersect(&(*CONSTANT_12),&(v96_2));
        drop(v96_2);
        let v96_10: Space = if has_head(&(v96_9)) { singleton(&[]) } else { Space::new() };
        drop(v96_9);
        let v96_12: Space = if (v96_10).is_empty() { Space::new() } else {
          let v101_6: Path = concat_path(&(v95_6),&(v95_7_head));
          let mut v101_11 = Space::new();
          let mut v101_11_cursor = (v95_7_tail).read_zipper();
          for v101_11_byte in v101_11_cursor.child_mask().iter() {
            v101_11_cursor.descend_to_byte(v101_11_byte);
            {
            let v101_11_tail = v101_11_cursor.fork_read_zipper();
            let v101_11_head = Path::from_slice(&[v101_11_byte]);
            let v102_2: Space = singleton(&(v101_11_head));
            let v102_3: Space = intersect(&(*CONSTANT_12),&(v102_2));
            let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
            drop(v102_3);
            let v102_5: Space = subtract(&(*CONSTANT_0),&(v102_4));
            drop(v102_4);
            let v102_8: Space = if (v102_5).is_empty() { Space::new() } else {
              let v103_6: Path = concat_path(&(v101_6),&(v101_11_head));
              let v103_7: Space = routine_18(c, &(v103_6), &(*p1), &(v101_11_tail).make_space());
              compose(&(v102_5),&(v103_7))
            };
            drop(v102_5);
            let v102_9: Space = intersect(&(*CONSTANT_12),&(v102_2));
            drop(v102_2);
            let v102_10: Space = if has_head(&(v102_9)) { singleton(&[]) } else { Space::new() };
            drop(v102_9);
            let v102_12: Space = if (v102_10).is_empty() { Space::new() } else {
              let v104_6: Path = concat_path(&(v101_6),&(v101_11_head));
              let v104_11: Space = routine_20(c, &(v104_6), &(*p1), &(v101_11_tail).make_space());
              drop(v104_6);
              compose(&(v102_10),&(v104_11))
            };
            drop(v102_10);
            let v102_13: Space = unite(&(v102_8),&(v102_12));
            v101_11.join_into((v102_13).clone());
            }
            v101_11_cursor.ascend(1);
          }
          drop(v101_11_cursor);
          drop(v101_6);
          compose(&(v96_10),&(v101_11))
        };
        drop(v96_10);
        let v96_13: Space = unite(&(v96_8),&(v96_12));
        v95_7.join_into((v96_13).clone());
        }
        v95_7_cursor.ascend(1);
      }
      drop(v95_7_cursor);
      compose(&(v94_5),&(v95_7))
    };
    drop(v94_5);
    let v94_9: Space = intersect(&(*CONSTANT_12),&(v94_2));
    drop(v94_2);
    let v94_10: Space = if has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
    drop(v94_9);
    let v94_12: Space = if (v94_10).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&(v93_21_head));
      let mut v105_11 = Space::new();
      let mut v105_11_cursor = (v93_21_tail).read_zipper();
      for v105_11_byte in v105_11_cursor.child_mask().iter() {
        v105_11_cursor.descend_to_byte(v105_11_byte);
        {
        let v105_11_tail = v105_11_cursor.fork_read_zipper();
        let v105_11_head = Path::from_slice(&[v105_11_byte]);
        let v106_2: Space = singleton(&(v105_11_head));
        let v106_3: Space = intersect(&(*CONSTANT_12),&(v106_2));
        let v106_4: Space = if has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_8: Space = if (v106_5).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v105_6),&(v105_11_head));
          let mut v107_7 = Space::new();
          let mut v107_7_cursor = (v105_11_tail).read_zipper();
          for v107_7_byte in v107_7_cursor.child_mask().iter() {
            v107_7_cursor.descend_to_byte(v107_7_byte);
            {
            let v107_7_tail = v107_7_cursor.fork_read_zipper();
            let v107_7_head = Path::from_slice(&[v107_7_byte]);
            let v108_2: Space = singleton(&(v107_7_head));
            let v108_3: Space = intersect(&(*CONSTANT_12),&(v108_2));
            let v108_4: Space = if has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
            drop(v108_3);
            let v108_5: Space = subtract(&(*CONSTANT_0),&(v108_4));
            drop(v108_4);
            let v108_8: Space = if (v108_5).is_empty() { Space::new() } else {
              let v109_6: Path = concat_path(&(v107_6),&(v107_7_head));
              let v109_7: Space = routine_18(c, &(v109_6), &(*p1), &(v107_7_tail).make_space());
              compose(&(v108_5),&(v109_7))
            };
            drop(v108_5);
            let v108_9: Space = intersect(&(*CONSTANT_12),&(v108_2));
            drop(v108_2);
            let v108_10: Space = if has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
            drop(v108_9);
            let v108_12: Space = if (v108_10).is_empty() { Space::new() } else {
              let v110_6: Path = concat_path(&(v107_6),&(v107_7_head));
              let v110_11: Space = routine_19(c, &(v110_6), &(*p1), &(v107_7_tail).make_space());
              drop(v110_6);
              compose(&(v108_10),&(v110_11))
            };
            drop(v108_10);
            let v108_13: Space = unite(&(v108_8),&(v108_12));
            v107_7.join_into((v108_13).clone());
            }
            v107_7_cursor.ascend(1);
          }
          drop(v107_7_cursor);
          compose(&(v106_5),&(v107_7))
        };
        drop(v106_5);
        let v106_9: Space = intersect(&(*CONSTANT_12),&(v106_2));
        drop(v106_2);
        let v106_10: Space = if has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
        drop(v106_9);
        let v106_13: Space = if (v106_10).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v105_6),&(v105_11_head));
          let v111_11: Path = concat_path(&(v111_6),&(*p1));
          drop(v111_6);
          let v111_12: Space = singleton(&(v111_11));
          drop(v111_11);
          compose(&(v106_10),&(v111_12))
        };
        drop(v106_10);
        let v106_14: Space = unite(&(v106_8),&(v106_13));
        drop(v106_13);
        v105_11.join_into((v106_14).clone());
        }
        v105_11_cursor.ascend(1);
      }
      drop(v105_11_cursor);
      drop(v105_6);
      compose(&(v94_10),&(v105_11))
    };
    drop(v94_10);
    let v94_13: Space = unite(&(v94_8),&(v94_12));
    v93_21.join_into((v94_13).clone());
    }
    v93_21_cursor.ascend(1);
  }
  drop(v93_21_cursor);
  (v93_21).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v112_9 = Space::new();
  let mut v112_9_cursor = (*s0).read_zipper();
  for v112_9_byte in v112_9_cursor.child_mask().iter() {
    v112_9_cursor.descend_to_byte(v112_9_byte);
    {
    let v112_9_tail = v112_9_cursor.fork_read_zipper();
    let v112_9_head = Path::from_slice(&[v112_9_byte]);
    let v113_2: Space = singleton(&(v112_9_head));
    let v113_3: Space = intersect(&(*CONSTANT_12),&(v113_2));
    let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
    drop(v113_3);
    let v113_5: Space = subtract(&(*CONSTANT_0),&(v113_4));
    drop(v113_4);
    let mut v113_6 = Space::new();
    let mut v113_6_cursor = (v112_9_tail).read_zipper();
    for v113_6_byte in v113_6_cursor.child_mask().iter() {
      v113_6_cursor.descend_to_byte(v113_6_byte);
      {
      let v113_6_tail = v113_6_cursor.fork_read_zipper();
      let v113_6_head = Path::from_slice(&[v113_6_byte]);
      let v114_2: Space = Space::new();
      v113_6.join_into((v114_2).clone());
      }
      v113_6_cursor.ascend(1);
    }
    drop(v113_6_cursor);
    let v113_7: Space = compose(&(v113_5),&(v113_6));
    drop(v113_5);
    drop(v113_6);
    let v113_8: Space = intersect(&(*CONSTANT_12),&(v113_2));
    drop(v113_2);
    let v113_9: Space = if has_head(&(v113_8)) { singleton(&[]) } else { Space::new() };
    drop(v113_8);
    let v113_12: Space = if (v113_9).is_empty() { Space::new() } else {
      let v115_10: Path = concat_path(&(*p0),&(v112_9_head));
      let mut v115_11 = Space::new();
      let mut v115_11_cursor = (v112_9_tail).read_zipper();
      for v115_11_byte in v115_11_cursor.child_mask().iter() {
        v115_11_cursor.descend_to_byte(v115_11_byte);
        {
        let v115_11_tail = v115_11_cursor.fork_read_zipper();
        let v115_11_head = Path::from_slice(&[v115_11_byte]);
        let v116_2: Space = singleton(&(v115_11_head));
        let v116_3: Space = intersect(&(*CONSTANT_12),&(v116_2));
        drop(v116_2);
        let v116_4: Space = if has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_7: Space = if (v116_4).is_empty() { Space::new() } else {
          let v117_5: Path = concat_path(&(v115_10),&(v115_11_head));
          let mut v117_6 = Space::new();
          let mut v117_6_cursor = (v115_11_tail).read_zipper();
          for v117_6_byte in v117_6_cursor.child_mask().iter() {
            v117_6_cursor.descend_to_byte(v117_6_byte);
            {
            let v117_6_tail = v117_6_cursor.fork_read_zipper();
            let v117_6_head = Path::from_slice(&[v117_6_byte]);
            let v118_2: Space = singleton(&(v117_6_head));
            let v118_3: Space = intersect(&(*CONSTANT_12),&(v118_2));
            let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
            drop(v118_3);
            let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
            drop(v118_4);
            let v118_7: Space = if (v118_5).is_empty() { Space::new() } else {
              let v119_6: Space = routine_4(c, &(v117_6_head), &(v117_5), &(v117_6_tail).make_space());
              compose(&(v118_5),&(v119_6))
            };
            drop(v118_5);
            let v118_8: Space = intersect(&(*CONSTANT_12),&(v118_2));
            drop(v118_2);
            let v118_9: Space = if has_head(&(v118_8)) { singleton(&[]) } else { Space::new() };
            drop(v118_8);
            let v118_11: Space = if (v118_9).is_empty() { Space::new() } else {
              let v120_10: Space = routine_21(c, &(v117_6_head), &(v117_5), &(v117_6_tail).make_space());
              compose(&(v118_9),&(v120_10))
            };
            drop(v118_9);
            let v118_12: Space = unite(&(v118_7),&(v118_11));
            v117_6.join_into((v118_12).clone());
            }
            v117_6_cursor.ascend(1);
          }
          drop(v117_6_cursor);
          drop(v117_5);
          compose(&(v116_4),&(v117_6))
        };
        drop(v116_4);
        v115_11.join_into((v116_7).clone());
        }
        v115_11_cursor.ascend(1);
      }
      drop(v115_11_cursor);
      drop(v115_10);
      compose(&(v113_9),&(v115_11))
    };
    drop(v113_9);
    let v113_13: Space = unite(&(v113_7),&(v113_12));
    drop(v113_7);
    v112_9.join_into((v113_13).clone());
    }
    v112_9_cursor.ascend(1);
  }
  drop(v112_9_cursor);
  (v112_9).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v121_14 = Space::new();
  let mut v121_14_cursor = (*s0).read_zipper();
  for v121_14_byte in v121_14_cursor.child_mask().iter() {
    v121_14_cursor.descend_to_byte(v121_14_byte);
    {
    let v121_14_tail = v121_14_cursor.fork_read_zipper();
    let v121_14_head = Path::from_slice(&[v121_14_byte]);
    let v122_2: Space = singleton(&(v121_14_head));
    let v122_3: Space = intersect(&(*CONSTANT_12),&(v122_2));
    let v122_4: Space = if has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
    drop(v122_3);
    let v122_5: Space = subtract(&(*CONSTANT_0),&(v122_4));
    drop(v122_4);
    let mut v122_6 = Space::new();
    let mut v122_6_cursor = (v121_14_tail).read_zipper();
    for v122_6_byte in v122_6_cursor.child_mask().iter() {
      v122_6_cursor.descend_to_byte(v122_6_byte);
      {
      let v122_6_tail = v122_6_cursor.fork_read_zipper();
      let v122_6_head = Path::from_slice(&[v122_6_byte]);
      let v123_2: Space = Space::new();
      v122_6.join_into((v123_2).clone());
      }
      v122_6_cursor.ascend(1);
    }
    drop(v122_6_cursor);
    let v122_7: Space = compose(&(v122_5),&(v122_6));
    drop(v122_5);
    drop(v122_6);
    let v122_8: Space = intersect(&(*CONSTANT_12),&(v122_2));
    drop(v122_2);
    let v122_9: Space = if has_head(&(v122_8)) { singleton(&[]) } else { Space::new() };
    drop(v122_8);
    let v122_12: Space = if (v122_9).is_empty() { Space::new() } else {
      let v124_10: Path = concat_path(&(*p0),&(v121_14_head));
      let mut v124_11 = Space::new();
      let mut v124_11_cursor = (v121_14_tail).read_zipper();
      for v124_11_byte in v124_11_cursor.child_mask().iter() {
        v124_11_cursor.descend_to_byte(v124_11_byte);
        {
        let v124_11_tail = v124_11_cursor.fork_read_zipper();
        let v124_11_head = Path::from_slice(&[v124_11_byte]);
        let v125_2: Space = singleton(&(v124_11_head));
        let v125_3: Space = intersect(&(*CONSTANT_12),&(v125_2));
        let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
        drop(v125_3);
        let v125_5: Space = subtract(&(*CONSTANT_0),&(v125_4));
        drop(v125_4);
        let v125_7: Space = if (v125_5).is_empty() { Space::new() } else {
          let mut v126_6 = Space::new();
          let mut v126_6_cursor = (v124_11_tail).read_zipper();
          for v126_6_byte in v126_6_cursor.child_mask().iter() {
            v126_6_cursor.descend_to_byte(v126_6_byte);
            {
            let v126_6_tail = v126_6_cursor.fork_read_zipper();
            let v126_6_head = Path::from_slice(&[v126_6_byte]);
            let v127_2: Space = singleton(&(v126_6_head));
            let v127_3: Space = intersect(&(*CONSTANT_12),&(v127_2));
            let v127_4: Space = if has_head(&(v127_3)) { singleton(&[]) } else { Space::new() };
            drop(v127_3);
            let v127_5: Space = subtract(&(*CONSTANT_0),&(v127_4));
            drop(v127_4);
            let v127_8: Space = if (v127_5).is_empty() { Space::new() } else {
              let v128_6: Path = concat_path(&(v124_11_head),&(v126_6_head));
              let v128_7: Space = routine_22(c, &(v128_6), &(v124_10), &(v126_6_tail).make_space());
              compose(&(v127_5),&(v128_7))
            };
            drop(v127_5);
            let v127_9: Space = intersect(&(*CONSTANT_12),&(v127_2));
            drop(v127_2);
            let v127_10: Space = if has_head(&(v127_9)) { singleton(&[]) } else { Space::new() };
            drop(v127_9);
            let v127_12: Space = if (v127_10).is_empty() { Space::new() } else {
              let v129_6: Path = concat_path(&(v124_11_head),&(v126_6_head));
              let v129_11: Space = routine_23(c, &(v129_6), &(v124_10), &(v126_6_tail).make_space());
              drop(v129_6);
              compose(&(v127_10),&(v129_11))
            };
            drop(v127_10);
            let v127_13: Space = unite(&(v127_8),&(v127_12));
            v126_6.join_into((v127_13).clone());
            }
            v126_6_cursor.ascend(1);
          }
          drop(v126_6_cursor);
          compose(&(v125_5),&(v126_6))
        };
        drop(v125_5);
        let v125_8: Space = intersect(&(*CONSTANT_12),&(v125_2));
        drop(v125_2);
        let v125_9: Space = if has_head(&(v125_8)) { singleton(&[]) } else { Space::new() };
        drop(v125_8);
        let v125_11: Space = if (v125_9).is_empty() { Space::new() } else {
          let mut v130_10 = Space::new();
          let mut v130_10_cursor = (v124_11_tail).read_zipper();
          for v130_10_byte in v130_10_cursor.child_mask().iter() {
            v130_10_cursor.descend_to_byte(v130_10_byte);
            {
            let v130_10_tail = v130_10_cursor.fork_read_zipper();
            let v130_10_head = Path::from_slice(&[v130_10_byte]);
            let v131_2: Space = singleton(&(v130_10_head));
            let v131_3: Space = intersect(&(*CONSTANT_12),&(v131_2));
            let v131_4: Space = if has_head(&(v131_3)) { singleton(&[]) } else { Space::new() };
            drop(v131_3);
            let v131_5: Space = subtract(&(*CONSTANT_0),&(v131_4));
            drop(v131_4);
            let v131_8: Space = if (v131_5).is_empty() { Space::new() } else {
              let v132_6: Path = concat_path(&(v124_11_head),&(v130_10_head));
              let v132_7: Space = routine_22(c, &(v132_6), &(v124_10), &(v130_10_tail).make_space());
              compose(&(v131_5),&(v132_7))
            };
            drop(v131_5);
            let v131_9: Space = intersect(&(*CONSTANT_12),&(v131_2));
            drop(v131_2);
            let v131_10: Space = if has_head(&(v131_9)) { singleton(&[]) } else { Space::new() };
            drop(v131_9);
            let v131_12: Space = if (v131_10).is_empty() { Space::new() } else {
              let v133_6: Path = concat_path(&(v124_11_head),&(v130_10_head));
              let v133_11: Space = routine_20(c, &(v133_6), &(v124_10), &(v130_10_tail).make_space());
              drop(v133_6);
              compose(&(v131_10),&(v133_11))
            };
            drop(v131_10);
            let v131_13: Space = unite(&(v131_8),&(v131_12));
            v130_10.join_into((v131_13).clone());
            }
            v130_10_cursor.ascend(1);
          }
          drop(v130_10_cursor);
          compose(&(v125_9),&(v130_10))
        };
        drop(v125_9);
        let v125_12: Space = unite(&(v125_7),&(v125_11));
        v124_11.join_into((v125_12).clone());
        }
        v124_11_cursor.ascend(1);
      }
      drop(v124_11_cursor);
      drop(v124_10);
      compose(&(v122_9),&(v124_11))
    };
    drop(v122_9);
    let v122_13: Space = unite(&(v122_7),&(v122_12));
    drop(v122_7);
    v121_14.join_into((v122_13).clone());
    }
    v121_14_cursor.ascend(1);
  }
  drop(v121_14_cursor);
  (v121_14).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v134_20 = Space::new();
  let mut v134_20_cursor = (*s0).read_zipper();
  for v134_20_byte in v134_20_cursor.child_mask().iter() {
    v134_20_cursor.descend_to_byte(v134_20_byte);
    {
    let v134_20_tail = v134_20_cursor.fork_read_zipper();
    let v134_20_head = Path::from_slice(&[v134_20_byte]);
    let v135_2: Space = singleton(&(v134_20_head));
    let v135_3: Space = intersect(&(*CONSTANT_12),&(v135_2));
    let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
    drop(v135_3);
    let v135_5: Space = subtract(&(*CONSTANT_0),&(v135_4));
    drop(v135_4);
    let v135_7: Space = if (v135_5).is_empty() { Space::new() } else {
      let mut v136_6 = Space::new();
      let mut v136_6_cursor = (v134_20_tail).read_zipper();
      for v136_6_byte in v136_6_cursor.child_mask().iter() {
        v136_6_cursor.descend_to_byte(v136_6_byte);
        {
        let v136_6_tail = v136_6_cursor.fork_read_zipper();
        let v136_6_head = Path::from_slice(&[v136_6_byte]);
        let v137_2: Space = singleton(&(v136_6_head));
        let v137_3: Space = intersect(&(*CONSTANT_12),&(v137_2));
        let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
        drop(v137_3);
        let v137_5: Space = subtract(&(*CONSTANT_0),&(v137_4));
        drop(v137_4);
        let v137_8: Space = if (v137_5).is_empty() { Space::new() } else {
          let v138_6: Path = concat_path(&(v134_20_head),&(v136_6_head));
          let mut v138_7 = Space::new();
          let mut v138_7_cursor = (v136_6_tail).read_zipper();
          for v138_7_byte in v138_7_cursor.child_mask().iter() {
            v138_7_cursor.descend_to_byte(v138_7_byte);
            {
            let v138_7_tail = v138_7_cursor.fork_read_zipper();
            let v138_7_head = Path::from_slice(&[v138_7_byte]);
            let v139_2: Space = singleton(&(v138_7_head));
            let v139_3: Space = intersect(&(*CONSTANT_12),&(v139_2));
            let v139_4: Space = if has_head(&(v139_3)) { singleton(&[]) } else { Space::new() };
            drop(v139_3);
            let v139_5: Space = subtract(&(*CONSTANT_0),&(v139_4));
            drop(v139_4);
            let v139_8: Space = if (v139_5).is_empty() { Space::new() } else {
              let v140_6: Path = concat_path(&(v138_6),&(v138_7_head));
              let v140_7: Space = routine_24(c, &(v140_6), &(*p0), &(v138_7_tail).make_space());
              compose(&(v139_5),&(v140_7))
            };
            drop(v139_5);
            let v139_9: Space = intersect(&(*CONSTANT_12),&(v139_2));
            drop(v139_2);
            let v139_10: Space = if has_head(&(v139_9)) { singleton(&[]) } else { Space::new() };
            drop(v139_9);
            let v139_12: Space = if (v139_10).is_empty() { Space::new() } else {
              let v141_6: Path = concat_path(&(v138_6),&(v138_7_head));
              let v141_11: Space = routine_25(c, &(v141_6), &(*p0), &(v138_7_tail).make_space());
              drop(v141_6);
              compose(&(v139_10),&(v141_11))
            };
            drop(v139_10);
            let v139_13: Space = unite(&(v139_8),&(v139_12));
            v138_7.join_into((v139_13).clone());
            }
            v138_7_cursor.ascend(1);
          }
          drop(v138_7_cursor);
          compose(&(v137_5),&(v138_7))
        };
        drop(v137_5);
        let v137_9: Space = intersect(&(*CONSTANT_12),&(v137_2));
        drop(v137_2);
        let v137_10: Space = if has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
        drop(v137_9);
        let v137_12: Space = if (v137_10).is_empty() { Space::new() } else {
          let v142_6: Path = concat_path(&(v134_20_head),&(v136_6_head));
          let mut v142_11 = Space::new();
          let mut v142_11_cursor = (v136_6_tail).read_zipper();
          for v142_11_byte in v142_11_cursor.child_mask().iter() {
            v142_11_cursor.descend_to_byte(v142_11_byte);
            {
            let v142_11_tail = v142_11_cursor.fork_read_zipper();
            let v142_11_head = Path::from_slice(&[v142_11_byte]);
            let v143_2: Space = singleton(&(v142_11_head));
            let v143_3: Space = intersect(&(*CONSTANT_12),&(v143_2));
            let v143_4: Space = if has_head(&(v143_3)) { singleton(&[]) } else { Space::new() };
            drop(v143_3);
            let v143_5: Space = subtract(&(*CONSTANT_0),&(v143_4));
            drop(v143_4);
            let v143_8: Space = if (v143_5).is_empty() { Space::new() } else {
              let v144_6: Path = concat_path(&(v142_6),&(v142_11_head));
              let v144_7: Space = routine_24(c, &(v144_6), &(*p0), &(v142_11_tail).make_space());
              compose(&(v143_5),&(v144_7))
            };
            drop(v143_5);
            let v143_9: Space = intersect(&(*CONSTANT_12),&(v143_2));
            drop(v143_2);
            let v143_10: Space = if has_head(&(v143_9)) { singleton(&[]) } else { Space::new() };
            drop(v143_9);
            let v143_12: Space = if (v143_10).is_empty() { Space::new() } else {
              let v145_6: Path = concat_path(&(v142_6),&(v142_11_head));
              let v145_11: Space = routine_20(c, &(v145_6), &(*p0), &(v142_11_tail).make_space());
              drop(v145_6);
              compose(&(v143_10),&(v145_11))
            };
            drop(v143_10);
            let v143_13: Space = unite(&(v143_8),&(v143_12));
            v142_11.join_into((v143_13).clone());
            }
            v142_11_cursor.ascend(1);
          }
          drop(v142_11_cursor);
          drop(v142_6);
          compose(&(v137_10),&(v142_11))
        };
        drop(v137_10);
        let v137_13: Space = unite(&(v137_8),&(v137_12));
        v136_6.join_into((v137_13).clone());
        }
        v136_6_cursor.ascend(1);
      }
      drop(v136_6_cursor);
      compose(&(v135_5),&(v136_6))
    };
    drop(v135_5);
    let v135_8: Space = intersect(&(*CONSTANT_12),&(v135_2));
    drop(v135_2);
    let v135_9: Space = if has_head(&(v135_8)) { singleton(&[]) } else { Space::new() };
    drop(v135_8);
    let v135_11: Space = if (v135_9).is_empty() { Space::new() } else {
      let mut v146_10 = Space::new();
      let mut v146_10_cursor = (v134_20_tail).read_zipper();
      for v146_10_byte in v146_10_cursor.child_mask().iter() {
        v146_10_cursor.descend_to_byte(v146_10_byte);
        {
        let v146_10_tail = v146_10_cursor.fork_read_zipper();
        let v146_10_head = Path::from_slice(&[v146_10_byte]);
        let v147_2: Space = singleton(&(v146_10_head));
        let v147_3: Space = intersect(&(*CONSTANT_12),&(v147_2));
        let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
        drop(v147_3);
        let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
        drop(v147_4);
        let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
          let v148_6: Path = concat_path(&(v134_20_head),&(v146_10_head));
          let mut v148_7 = Space::new();
          let mut v148_7_cursor = (v146_10_tail).read_zipper();
          for v148_7_byte in v148_7_cursor.child_mask().iter() {
            v148_7_cursor.descend_to_byte(v148_7_byte);
            {
            let v148_7_tail = v148_7_cursor.fork_read_zipper();
            let v148_7_head = Path::from_slice(&[v148_7_byte]);
            let v149_2: Space = singleton(&(v148_7_head));
            let v149_3: Space = intersect(&(*CONSTANT_12),&(v149_2));
            let v149_4: Space = if has_head(&(v149_3)) { singleton(&[]) } else { Space::new() };
            drop(v149_3);
            let v149_5: Space = subtract(&(*CONSTANT_0),&(v149_4));
            drop(v149_4);
            let v149_8: Space = if (v149_5).is_empty() { Space::new() } else {
              let v150_6: Path = concat_path(&(v148_6),&(v148_7_head));
              let v150_7: Space = routine_24(c, &(v150_6), &(*p0), &(v148_7_tail).make_space());
              compose(&(v149_5),&(v150_7))
            };
            drop(v149_5);
            let v149_9: Space = intersect(&(*CONSTANT_12),&(v149_2));
            drop(v149_2);
            let v149_10: Space = if has_head(&(v149_9)) { singleton(&[]) } else { Space::new() };
            drop(v149_9);
            let v149_12: Space = if (v149_10).is_empty() { Space::new() } else {
              let v151_6: Path = concat_path(&(v148_6),&(v148_7_head));
              let v151_11: Space = routine_25(c, &(v151_6), &(*p0), &(v148_7_tail).make_space());
              drop(v151_6);
              compose(&(v149_10),&(v151_11))
            };
            drop(v149_10);
            let v149_13: Space = unite(&(v149_8),&(v149_12));
            v148_7.join_into((v149_13).clone());
            }
            v148_7_cursor.ascend(1);
          }
          drop(v148_7_cursor);
          compose(&(v147_5),&(v148_7))
        };
        drop(v147_5);
        let v147_9: Space = intersect(&(*CONSTANT_12),&(v147_2));
        drop(v147_2);
        let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
        drop(v147_9);
        let v147_13: Space = if (v147_10).is_empty() { Space::new() } else {
          let v152_6: Path = concat_path(&(v134_20_head),&(v146_10_head));
          let v152_11: Path = concat_path(&(v152_6),&(*p0));
          drop(v152_6);
          let v152_12: Space = singleton(&(v152_11));
          drop(v152_11);
          compose(&(v147_10),&(v152_12))
        };
        drop(v147_10);
        let v147_14: Space = unite(&(v147_8),&(v147_13));
        drop(v147_13);
        v146_10.join_into((v147_14).clone());
        }
        v146_10_cursor.ascend(1);
      }
      drop(v146_10_cursor);
      compose(&(v135_9),&(v146_10))
    };
    drop(v135_9);
    let v135_12: Space = unite(&(v135_7),&(v135_11));
    v134_20.join_into((v135_12).clone());
    }
    v134_20_cursor.ascend(1);
  }
  drop(v134_20_cursor);
  (v134_20).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v153_6 = Space::new();
  let mut v153_6_cursor = (*s0).read_zipper();
  for v153_6_byte in v153_6_cursor.child_mask().iter() {
    v153_6_cursor.descend_to_byte(v153_6_byte);
    {
    let v153_6_tail = v153_6_cursor.fork_read_zipper();
    let v153_6_head = Path::from_slice(&[v153_6_byte]);
    let v154_2: Space = singleton(&(v153_6_head));
    let v154_3: Space = intersect(&(*CONSTANT_12),&(v154_2));
    let v154_4: Space = if has_head(&(v154_3)) { singleton(&[]) } else { Space::new() };
    drop(v154_3);
    let v154_5: Space = subtract(&(*CONSTANT_0),&(v154_4));
    drop(v154_4);
    let mut v154_6 = Space::new();
    let mut v154_6_cursor = (v153_6_tail).read_zipper();
    for v154_6_byte in v154_6_cursor.child_mask().iter() {
      v154_6_cursor.descend_to_byte(v154_6_byte);
      {
      let v154_6_tail = v154_6_cursor.fork_read_zipper();
      let v154_6_head = Path::from_slice(&[v154_6_byte]);
      let v155_2: Space = Space::new();
      v154_6.join_into((v155_2).clone());
      }
      v154_6_cursor.ascend(1);
    }
    drop(v154_6_cursor);
    let v154_7: Space = compose(&(v154_5),&(v154_6));
    drop(v154_5);
    drop(v154_6);
    let v154_8: Space = intersect(&(*CONSTANT_12),&(v154_2));
    drop(v154_2);
    let v154_9: Space = if has_head(&(v154_8)) { singleton(&[]) } else { Space::new() };
    drop(v154_8);
    let v154_12: Space = if (v154_9).is_empty() { Space::new() } else {
      let v156_10: Path = concat_path(&(*p0),&(v153_6_head));
      let mut v156_11 = Space::new();
      let mut v156_11_cursor = (v153_6_tail).read_zipper();
      for v156_11_byte in v156_11_cursor.child_mask().iter() {
        v156_11_cursor.descend_to_byte(v156_11_byte);
        {
        let v156_11_tail = v156_11_cursor.fork_read_zipper();
        let v156_11_head = Path::from_slice(&[v156_11_byte]);
        let v157_2: Space = singleton(&(v156_11_head));
        let v157_3: Space = intersect(&(*CONSTANT_12),&(v157_2));
        drop(v157_2);
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_7: Space = if (v157_4).is_empty() { Space::new() } else {
          let v158_5: Path = concat_path(&(v156_10),&(v156_11_head));
          let v158_6: Space = singleton(&(v158_5));
          drop(v158_5);
          compose(&(v157_4),&(v158_6))
        };
        drop(v157_4);
        v156_11.join_into((v157_7).clone());
        }
        v156_11_cursor.ascend(1);
      }
      drop(v156_11_cursor);
      drop(v156_10);
      compose(&(v154_9),&(v156_11))
    };
    drop(v154_9);
    let v154_13: Space = unite(&(v154_7),&(v154_12));
    drop(v154_7);
    drop(v154_12);
    v153_6.join_into((v154_13).clone());
    }
    v153_6_cursor.ascend(1);
  }
  drop(v153_6_cursor);
  (v153_6).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v159_5 = Space::new();
  let mut v159_5_cursor = (*s0).read_zipper();
  for v159_5_byte in v159_5_cursor.child_mask().iter() {
    v159_5_cursor.descend_to_byte(v159_5_byte);
    {
    let v159_5_tail = v159_5_cursor.fork_read_zipper();
    let v159_5_head = Path::from_slice(&[v159_5_byte]);
    let v160_2: Space = singleton(&(v159_5_head));
    let v160_3: Space = intersect(&(*CONSTANT_12),&(v160_2));
    let v160_4: Space = if has_head(&(v160_3)) { singleton(&[]) } else { Space::new() };
    drop(v160_3);
    let v160_5: Space = subtract(&(*CONSTANT_0),&(v160_4));
    drop(v160_4);
    let mut v160_6 = Space::new();
    let mut v160_6_cursor = (v159_5_tail).read_zipper();
    for v160_6_byte in v160_6_cursor.child_mask().iter() {
      v160_6_cursor.descend_to_byte(v160_6_byte);
      {
      let v160_6_tail = v160_6_cursor.fork_read_zipper();
      let v160_6_head = Path::from_slice(&[v160_6_byte]);
      let v161_2: Space = Space::new();
      v160_6.join_into((v161_2).clone());
      }
      v160_6_cursor.ascend(1);
    }
    drop(v160_6_cursor);
    let v160_7: Space = compose(&(v160_5),&(v160_6));
    drop(v160_5);
    drop(v160_6);
    let v160_8: Space = intersect(&(*CONSTANT_12),&(v160_2));
    drop(v160_2);
    let v160_9: Space = if has_head(&(v160_8)) { singleton(&[]) } else { Space::new() };
    drop(v160_8);
    let v160_12: Space = if (v160_9).is_empty() { Space::new() } else {
      let v162_10: Path = concat_path(&(*p0),&(v159_5_head));
      let v162_11: Space = singleton(&(v162_10));
      drop(v162_10);
      compose(&(v160_9),&(v162_11))
    };
    drop(v160_9);
    let v160_13: Space = unite(&(v160_7),&(v160_12));
    drop(v160_7);
    drop(v160_12);
    v159_5.join_into((v160_13).clone());
    }
    v159_5_cursor.ascend(1);
  }
  drop(v159_5_cursor);
  (v159_5).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v163_2: Space = singleton(&(*p0));
  (v163_2).clone()
}

fn routine_11(c: &mut Context, s0: &Space) -> Space {
  let v164_1: Space = if has_head(&(*s0)) { singleton(&[]) } else { Space::new() };
  let v164_2: Space = first_matching(&(*s0),&(*CONSTANT_0),false);
  let v164_3: Space = unite(&(v164_1),&(v164_2));
  drop(v164_1);
  drop(v164_2);
  let v164_6: Space = if (v164_3).is_empty() { Space::new() } else {
    let v165_4: Space = routine_26(c, &(*s0));
    let v165_5: Space = subtract(&(*s0),&(v165_4));
    compose(&(v164_3),&(v165_5))
  };
  drop(v164_3);
  let v164_7: Space = subtract(&(*s0),&(v164_6));
  (v164_7).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v166_21 = Space::new();
  let mut v166_21_cursor = (*s0).read_zipper();
  for v166_21_byte in v166_21_cursor.child_mask().iter() {
    v166_21_cursor.descend_to_byte(v166_21_byte);
    {
    let v166_21_tail = v166_21_cursor.fork_read_zipper();
    let v166_21_head = Path::from_slice(&[v166_21_byte]);
    let v167_2: Space = singleton(&(v166_21_head));
    let v167_3: Space = intersect(&(*CONSTANT_12),&(v167_2));
    let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
    drop(v167_3);
    let v167_5: Space = subtract(&(*CONSTANT_0),&(v167_4));
    drop(v167_4);
    let v167_8: Space = if (v167_5).is_empty() { Space::new() } else {
      let v168_6: Path = concat_path(&(*p0),&(v166_21_head));
      let mut v168_7 = Space::new();
      let mut v168_7_cursor = (v166_21_tail).read_zipper();
      for v168_7_byte in v168_7_cursor.child_mask().iter() {
        v168_7_cursor.descend_to_byte(v168_7_byte);
        {
        let v168_7_tail = v168_7_cursor.fork_read_zipper();
        let v168_7_head = Path::from_slice(&[v168_7_byte]);
        let v169_2: Space = singleton(&(v168_7_head));
        let v169_3: Space = intersect(&(*CONSTANT_12),&(v169_2));
        let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
        drop(v169_3);
        let v169_5: Space = subtract(&(*CONSTANT_0),&(v169_4));
        drop(v169_4);
        let v169_8: Space = if (v169_5).is_empty() { Space::new() } else {
          let v170_6: Path = concat_path(&(v168_6),&(v168_7_head));
          let mut v170_7 = Space::new();
          let mut v170_7_cursor = (v168_7_tail).read_zipper();
          for v170_7_byte in v170_7_cursor.child_mask().iter() {
            v170_7_cursor.descend_to_byte(v170_7_byte);
            {
            let v170_7_tail = v170_7_cursor.fork_read_zipper();
            let v170_7_head = Path::from_slice(&[v170_7_byte]);
            let v171_2: Space = singleton(&(v170_7_head));
            let v171_3: Space = intersect(&(*CONSTANT_12),&(v171_2));
            let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
            drop(v171_3);
            let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
            drop(v171_4);
            let v171_8: Space = if (v171_5).is_empty() { Space::new() } else {
              let v172_6: Path = concat_path(&(v170_6),&(v170_7_head));
              let v172_7: Space = routine_27(c, &(v172_6), &(*p1), &(v170_7_tail).make_space());
              compose(&(v171_5),&(v172_7))
            };
            drop(v171_5);
            let v171_9: Space = intersect(&(*CONSTANT_12),&(v171_2));
            drop(v171_2);
            let v171_10: Space = if has_head(&(v171_9)) { singleton(&[]) } else { Space::new() };
            drop(v171_9);
            let v171_12: Space = if (v171_10).is_empty() { Space::new() } else {
              let v173_6: Path = concat_path(&(v170_6),&(v170_7_head));
              let v173_11: Space = routine_28(c, &(v173_6), &(*p1), &(v170_7_tail).make_space());
              drop(v173_6);
              compose(&(v171_10),&(v173_11))
            };
            drop(v171_10);
            let v171_13: Space = unite(&(v171_8),&(v171_12));
            v170_7.join_into((v171_13).clone());
            }
            v170_7_cursor.ascend(1);
          }
          drop(v170_7_cursor);
          compose(&(v169_5),&(v170_7))
        };
        drop(v169_5);
        let v169_9: Space = intersect(&(*CONSTANT_12),&(v169_2));
        drop(v169_2);
        let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
        drop(v169_9);
        let v169_12: Space = if (v169_10).is_empty() { Space::new() } else {
          let v174_6: Path = concat_path(&(v168_6),&(v168_7_head));
          let mut v174_11 = Space::new();
          let mut v174_11_cursor = (v168_7_tail).read_zipper();
          for v174_11_byte in v174_11_cursor.child_mask().iter() {
            v174_11_cursor.descend_to_byte(v174_11_byte);
            {
            let v174_11_tail = v174_11_cursor.fork_read_zipper();
            let v174_11_head = Path::from_slice(&[v174_11_byte]);
            let v175_2: Space = singleton(&(v174_11_head));
            let v175_3: Space = intersect(&(*CONSTANT_12),&(v175_2));
            let v175_4: Space = if has_head(&(v175_3)) { singleton(&[]) } else { Space::new() };
            drop(v175_3);
            let v175_5: Space = subtract(&(*CONSTANT_0),&(v175_4));
            drop(v175_4);
            let v175_8: Space = if (v175_5).is_empty() { Space::new() } else {
              let v176_6: Path = concat_path(&(v174_6),&(v174_11_head));
              let v176_7: Space = routine_27(c, &(v176_6), &(*p1), &(v174_11_tail).make_space());
              compose(&(v175_5),&(v176_7))
            };
            drop(v175_5);
            let v175_9: Space = intersect(&(*CONSTANT_12),&(v175_2));
            drop(v175_2);
            let v175_10: Space = if has_head(&(v175_9)) { singleton(&[]) } else { Space::new() };
            drop(v175_9);
            let v175_12: Space = if (v175_10).is_empty() { Space::new() } else {
              let v177_6: Path = concat_path(&(v174_6),&(v174_11_head));
              let v177_11: Space = routine_29(c, &(v177_6), &(*p1), &(v174_11_tail).make_space());
              drop(v177_6);
              compose(&(v175_10),&(v177_11))
            };
            drop(v175_10);
            let v175_13: Space = unite(&(v175_8),&(v175_12));
            v174_11.join_into((v175_13).clone());
            }
            v174_11_cursor.ascend(1);
          }
          drop(v174_11_cursor);
          drop(v174_6);
          compose(&(v169_10),&(v174_11))
        };
        drop(v169_10);
        let v169_13: Space = unite(&(v169_8),&(v169_12));
        v168_7.join_into((v169_13).clone());
        }
        v168_7_cursor.ascend(1);
      }
      drop(v168_7_cursor);
      compose(&(v167_5),&(v168_7))
    };
    drop(v167_5);
    let v167_9: Space = intersect(&(*CONSTANT_12),&(v167_2));
    drop(v167_2);
    let v167_10: Space = if has_head(&(v167_9)) { singleton(&[]) } else { Space::new() };
    drop(v167_9);
    let v167_12: Space = if (v167_10).is_empty() { Space::new() } else {
      let v178_6: Path = concat_path(&(*p0),&(v166_21_head));
      let mut v178_11 = Space::new();
      let mut v178_11_cursor = (v166_21_tail).read_zipper();
      for v178_11_byte in v178_11_cursor.child_mask().iter() {
        v178_11_cursor.descend_to_byte(v178_11_byte);
        {
        let v178_11_tail = v178_11_cursor.fork_read_zipper();
        let v178_11_head = Path::from_slice(&[v178_11_byte]);
        let v179_2: Space = singleton(&(v178_11_head));
        let v179_3: Space = intersect(&(*CONSTANT_12),&(v179_2));
        let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
        drop(v179_3);
        let v179_5: Space = subtract(&(*CONSTANT_0),&(v179_4));
        drop(v179_4);
        let v179_8: Space = if (v179_5).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v178_6),&(v178_11_head));
          let mut v180_7 = Space::new();
          let mut v180_7_cursor = (v178_11_tail).read_zipper();
          for v180_7_byte in v180_7_cursor.child_mask().iter() {
            v180_7_cursor.descend_to_byte(v180_7_byte);
            {
            let v180_7_tail = v180_7_cursor.fork_read_zipper();
            let v180_7_head = Path::from_slice(&[v180_7_byte]);
            let v181_2: Space = singleton(&(v180_7_head));
            let v181_3: Space = intersect(&(*CONSTANT_12),&(v181_2));
            let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
            drop(v181_3);
            let v181_5: Space = subtract(&(*CONSTANT_0),&(v181_4));
            drop(v181_4);
            let v181_8: Space = if (v181_5).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v180_6),&(v180_7_head));
              let v182_7: Space = routine_27(c, &(v182_6), &(*p1), &(v180_7_tail).make_space());
              compose(&(v181_5),&(v182_7))
            };
            drop(v181_5);
            let v181_9: Space = intersect(&(*CONSTANT_12),&(v181_2));
            drop(v181_2);
            let v181_10: Space = if has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
            drop(v181_9);
            let v181_12: Space = if (v181_10).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v180_6),&(v180_7_head));
              let v183_11: Space = routine_28(c, &(v183_6), &(*p1), &(v180_7_tail).make_space());
              drop(v183_6);
              compose(&(v181_10),&(v183_11))
            };
            drop(v181_10);
            let v181_13: Space = unite(&(v181_8),&(v181_12));
            v180_7.join_into((v181_13).clone());
            }
            v180_7_cursor.ascend(1);
          }
          drop(v180_7_cursor);
          compose(&(v179_5),&(v180_7))
        };
        drop(v179_5);
        let v179_9: Space = intersect(&(*CONSTANT_12),&(v179_2));
        drop(v179_2);
        let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
        drop(v179_9);
        let v179_13: Space = if (v179_10).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v178_6),&(v178_11_head));
          let v184_11: Path = concat_path(&(v184_6),&(*p1));
          drop(v184_6);
          let v184_12: Space = singleton(&(v184_11));
          drop(v184_11);
          compose(&(v179_10),&(v184_12))
        };
        drop(v179_10);
        let v179_14: Space = unite(&(v179_8),&(v179_13));
        drop(v179_13);
        v178_11.join_into((v179_14).clone());
        }
        v178_11_cursor.ascend(1);
      }
      drop(v178_11_cursor);
      drop(v178_6);
      compose(&(v167_10),&(v178_11))
    };
    drop(v167_10);
    let v167_13: Space = unite(&(v167_8),&(v167_12));
    v166_21.join_into((v167_13).clone());
    }
    v166_21_cursor.ascend(1);
  }
  drop(v166_21_cursor);
  (v166_21).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v185_9 = Space::new();
  let mut v185_9_cursor = (*s0).read_zipper();
  for v185_9_byte in v185_9_cursor.child_mask().iter() {
    v185_9_cursor.descend_to_byte(v185_9_byte);
    {
    let v185_9_tail = v185_9_cursor.fork_read_zipper();
    let v185_9_head = Path::from_slice(&[v185_9_byte]);
    let v186_2: Space = singleton(&(v185_9_head));
    let v186_3: Space = intersect(&(*CONSTANT_12),&(v186_2));
    let v186_4: Space = if has_head(&(v186_3)) { singleton(&[]) } else { Space::new() };
    drop(v186_3);
    let v186_5: Space = subtract(&(*CONSTANT_0),&(v186_4));
    drop(v186_4);
    let mut v186_6 = Space::new();
    let mut v186_6_cursor = (v185_9_tail).read_zipper();
    for v186_6_byte in v186_6_cursor.child_mask().iter() {
      v186_6_cursor.descend_to_byte(v186_6_byte);
      {
      let v186_6_tail = v186_6_cursor.fork_read_zipper();
      let v186_6_head = Path::from_slice(&[v186_6_byte]);
      let v187_2: Space = Space::new();
      v186_6.join_into((v187_2).clone());
      }
      v186_6_cursor.ascend(1);
    }
    drop(v186_6_cursor);
    let v186_7: Space = compose(&(v186_5),&(v186_6));
    drop(v186_5);
    drop(v186_6);
    let v186_8: Space = intersect(&(*CONSTANT_12),&(v186_2));
    drop(v186_2);
    let v186_9: Space = if has_head(&(v186_8)) { singleton(&[]) } else { Space::new() };
    drop(v186_8);
    let v186_12: Space = if (v186_9).is_empty() { Space::new() } else {
      let v188_10: Path = concat_path(&(*p0),&(v185_9_head));
      let mut v188_11 = Space::new();
      let mut v188_11_cursor = (v185_9_tail).read_zipper();
      for v188_11_byte in v188_11_cursor.child_mask().iter() {
        v188_11_cursor.descend_to_byte(v188_11_byte);
        {
        let v188_11_tail = v188_11_cursor.fork_read_zipper();
        let v188_11_head = Path::from_slice(&[v188_11_byte]);
        let v189_2: Space = singleton(&(v188_11_head));
        let v189_3: Space = intersect(&(*CONSTANT_12),&(v189_2));
        drop(v189_2);
        let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_7: Space = if (v189_4).is_empty() { Space::new() } else {
          let v190_5: Path = concat_path(&(v188_10),&(v188_11_head));
          let mut v190_6 = Space::new();
          let mut v190_6_cursor = (v188_11_tail).read_zipper();
          for v190_6_byte in v190_6_cursor.child_mask().iter() {
            v190_6_cursor.descend_to_byte(v190_6_byte);
            {
            let v190_6_tail = v190_6_cursor.fork_read_zipper();
            let v190_6_head = Path::from_slice(&[v190_6_byte]);
            let v191_2: Space = singleton(&(v190_6_head));
            let v191_3: Space = intersect(&(*CONSTANT_12),&(v191_2));
            let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = subtract(&(*CONSTANT_0),&(v191_4));
            drop(v191_4);
            let v191_7: Space = if (v191_5).is_empty() { Space::new() } else {
              let v192_6: Space = routine_12(c, &(v190_6_head), &(v190_5), &(v190_6_tail).make_space());
              compose(&(v191_5),&(v192_6))
            };
            drop(v191_5);
            let v191_8: Space = intersect(&(*CONSTANT_12),&(v191_2));
            drop(v191_2);
            let v191_9: Space = if has_head(&(v191_8)) { singleton(&[]) } else { Space::new() };
            drop(v191_8);
            let v191_11: Space = if (v191_9).is_empty() { Space::new() } else {
              let v193_10: Space = routine_30(c, &(v190_6_head), &(v190_5), &(v190_6_tail).make_space());
              compose(&(v191_9),&(v193_10))
            };
            drop(v191_9);
            let v191_12: Space = unite(&(v191_7),&(v191_11));
            v190_6.join_into((v191_12).clone());
            }
            v190_6_cursor.ascend(1);
          }
          drop(v190_6_cursor);
          drop(v190_5);
          compose(&(v189_4),&(v190_6))
        };
        drop(v189_4);
        v188_11.join_into((v189_7).clone());
        }
        v188_11_cursor.ascend(1);
      }
      drop(v188_11_cursor);
      drop(v188_10);
      compose(&(v186_9),&(v188_11))
    };
    drop(v186_9);
    let v186_13: Space = unite(&(v186_7),&(v186_12));
    drop(v186_7);
    v185_9.join_into((v186_13).clone());
    }
    v185_9_cursor.ascend(1);
  }
  drop(v185_9_cursor);
  (v185_9).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v194_14 = Space::new();
  let mut v194_14_cursor = (*s0).read_zipper();
  for v194_14_byte in v194_14_cursor.child_mask().iter() {
    v194_14_cursor.descend_to_byte(v194_14_byte);
    {
    let v194_14_tail = v194_14_cursor.fork_read_zipper();
    let v194_14_head = Path::from_slice(&[v194_14_byte]);
    let v195_2: Space = singleton(&(v194_14_head));
    let v195_3: Space = intersect(&(*CONSTANT_12),&(v195_2));
    let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
    drop(v195_3);
    let v195_5: Space = subtract(&(*CONSTANT_0),&(v195_4));
    drop(v195_4);
    let mut v195_6 = Space::new();
    let mut v195_6_cursor = (v194_14_tail).read_zipper();
    for v195_6_byte in v195_6_cursor.child_mask().iter() {
      v195_6_cursor.descend_to_byte(v195_6_byte);
      {
      let v195_6_tail = v195_6_cursor.fork_read_zipper();
      let v195_6_head = Path::from_slice(&[v195_6_byte]);
      let v196_2: Space = Space::new();
      v195_6.join_into((v196_2).clone());
      }
      v195_6_cursor.ascend(1);
    }
    drop(v195_6_cursor);
    let v195_7: Space = compose(&(v195_5),&(v195_6));
    drop(v195_5);
    drop(v195_6);
    let v195_8: Space = intersect(&(*CONSTANT_12),&(v195_2));
    drop(v195_2);
    let v195_9: Space = if has_head(&(v195_8)) { singleton(&[]) } else { Space::new() };
    drop(v195_8);
    let v195_12: Space = if (v195_9).is_empty() { Space::new() } else {
      let v197_10: Path = concat_path(&(*p0),&(v194_14_head));
      let mut v197_11 = Space::new();
      let mut v197_11_cursor = (v194_14_tail).read_zipper();
      for v197_11_byte in v197_11_cursor.child_mask().iter() {
        v197_11_cursor.descend_to_byte(v197_11_byte);
        {
        let v197_11_tail = v197_11_cursor.fork_read_zipper();
        let v197_11_head = Path::from_slice(&[v197_11_byte]);
        let v198_2: Space = singleton(&(v197_11_head));
        let v198_3: Space = intersect(&(*CONSTANT_12),&(v198_2));
        let v198_4: Space = if has_head(&(v198_3)) { singleton(&[]) } else { Space::new() };
        drop(v198_3);
        let v198_5: Space = subtract(&(*CONSTANT_0),&(v198_4));
        drop(v198_4);
        let v198_7: Space = if (v198_5).is_empty() { Space::new() } else {
          let mut v199_6 = Space::new();
          let mut v199_6_cursor = (v197_11_tail).read_zipper();
          for v199_6_byte in v199_6_cursor.child_mask().iter() {
            v199_6_cursor.descend_to_byte(v199_6_byte);
            {
            let v199_6_tail = v199_6_cursor.fork_read_zipper();
            let v199_6_head = Path::from_slice(&[v199_6_byte]);
            let v200_2: Space = singleton(&(v199_6_head));
            let v200_3: Space = intersect(&(*CONSTANT_12),&(v200_2));
            let v200_4: Space = if has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
            drop(v200_3);
            let v200_5: Space = subtract(&(*CONSTANT_0),&(v200_4));
            drop(v200_4);
            let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
              let v201_6: Path = concat_path(&(v197_11_head),&(v199_6_head));
              let v201_7: Space = routine_31(c, &(v201_6), &(v197_10), &(v199_6_tail).make_space());
              compose(&(v200_5),&(v201_7))
            };
            drop(v200_5);
            let v200_9: Space = intersect(&(*CONSTANT_12),&(v200_2));
            drop(v200_2);
            let v200_10: Space = if has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
            drop(v200_9);
            let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v197_11_head),&(v199_6_head));
              let v202_11: Space = routine_32(c, &(v202_6), &(v197_10), &(v199_6_tail).make_space());
              drop(v202_6);
              compose(&(v200_10),&(v202_11))
            };
            drop(v200_10);
            let v200_13: Space = unite(&(v200_8),&(v200_12));
            v199_6.join_into((v200_13).clone());
            }
            v199_6_cursor.ascend(1);
          }
          drop(v199_6_cursor);
          compose(&(v198_5),&(v199_6))
        };
        drop(v198_5);
        let v198_8: Space = intersect(&(*CONSTANT_12),&(v198_2));
        drop(v198_2);
        let v198_9: Space = if has_head(&(v198_8)) { singleton(&[]) } else { Space::new() };
        drop(v198_8);
        let v198_11: Space = if (v198_9).is_empty() { Space::new() } else {
          let mut v203_10 = Space::new();
          let mut v203_10_cursor = (v197_11_tail).read_zipper();
          for v203_10_byte in v203_10_cursor.child_mask().iter() {
            v203_10_cursor.descend_to_byte(v203_10_byte);
            {
            let v203_10_tail = v203_10_cursor.fork_read_zipper();
            let v203_10_head = Path::from_slice(&[v203_10_byte]);
            let v204_2: Space = singleton(&(v203_10_head));
            let v204_3: Space = intersect(&(*CONSTANT_12),&(v204_2));
            let v204_4: Space = if has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
            drop(v204_3);
            let v204_5: Space = subtract(&(*CONSTANT_0),&(v204_4));
            drop(v204_4);
            let v204_8: Space = if (v204_5).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v197_11_head),&(v203_10_head));
              let v205_7: Space = routine_31(c, &(v205_6), &(v197_10), &(v203_10_tail).make_space());
              compose(&(v204_5),&(v205_7))
            };
            drop(v204_5);
            let v204_9: Space = intersect(&(*CONSTANT_12),&(v204_2));
            drop(v204_2);
            let v204_10: Space = if has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
            drop(v204_9);
            let v204_12: Space = if (v204_10).is_empty() { Space::new() } else {
              let v206_6: Path = concat_path(&(v197_11_head),&(v203_10_head));
              let v206_11: Space = routine_29(c, &(v206_6), &(v197_10), &(v203_10_tail).make_space());
              drop(v206_6);
              compose(&(v204_10),&(v206_11))
            };
            drop(v204_10);
            let v204_13: Space = unite(&(v204_8),&(v204_12));
            v203_10.join_into((v204_13).clone());
            }
            v203_10_cursor.ascend(1);
          }
          drop(v203_10_cursor);
          compose(&(v198_9),&(v203_10))
        };
        drop(v198_9);
        let v198_12: Space = unite(&(v198_7),&(v198_11));
        v197_11.join_into((v198_12).clone());
        }
        v197_11_cursor.ascend(1);
      }
      drop(v197_11_cursor);
      drop(v197_10);
      compose(&(v195_9),&(v197_11))
    };
    drop(v195_9);
    let v195_13: Space = unite(&(v195_7),&(v195_12));
    drop(v195_7);
    v194_14.join_into((v195_13).clone());
    }
    v194_14_cursor.ascend(1);
  }
  drop(v194_14_cursor);
  (v194_14).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v207_20 = Space::new();
  let mut v207_20_cursor = (*s0).read_zipper();
  for v207_20_byte in v207_20_cursor.child_mask().iter() {
    v207_20_cursor.descend_to_byte(v207_20_byte);
    {
    let v207_20_tail = v207_20_cursor.fork_read_zipper();
    let v207_20_head = Path::from_slice(&[v207_20_byte]);
    let v208_2: Space = singleton(&(v207_20_head));
    let v208_3: Space = intersect(&(*CONSTANT_12),&(v208_2));
    let v208_4: Space = if has_head(&(v208_3)) { singleton(&[]) } else { Space::new() };
    drop(v208_3);
    let v208_5: Space = subtract(&(*CONSTANT_0),&(v208_4));
    drop(v208_4);
    let v208_7: Space = if (v208_5).is_empty() { Space::new() } else {
      let mut v209_6 = Space::new();
      let mut v209_6_cursor = (v207_20_tail).read_zipper();
      for v209_6_byte in v209_6_cursor.child_mask().iter() {
        v209_6_cursor.descend_to_byte(v209_6_byte);
        {
        let v209_6_tail = v209_6_cursor.fork_read_zipper();
        let v209_6_head = Path::from_slice(&[v209_6_byte]);
        let v210_2: Space = singleton(&(v209_6_head));
        let v210_3: Space = intersect(&(*CONSTANT_12),&(v210_2));
        let v210_4: Space = if has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
        drop(v210_3);
        let v210_5: Space = subtract(&(*CONSTANT_0),&(v210_4));
        drop(v210_4);
        let v210_8: Space = if (v210_5).is_empty() { Space::new() } else {
          let v211_6: Path = concat_path(&(v207_20_head),&(v209_6_head));
          let mut v211_7 = Space::new();
          let mut v211_7_cursor = (v209_6_tail).read_zipper();
          for v211_7_byte in v211_7_cursor.child_mask().iter() {
            v211_7_cursor.descend_to_byte(v211_7_byte);
            {
            let v211_7_tail = v211_7_cursor.fork_read_zipper();
            let v211_7_head = Path::from_slice(&[v211_7_byte]);
            let v212_2: Space = singleton(&(v211_7_head));
            let v212_3: Space = intersect(&(*CONSTANT_12),&(v212_2));
            let v212_4: Space = if has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
            drop(v212_3);
            let v212_5: Space = subtract(&(*CONSTANT_0),&(v212_4));
            drop(v212_4);
            let v212_8: Space = if (v212_5).is_empty() { Space::new() } else {
              let v213_6: Path = concat_path(&(v211_6),&(v211_7_head));
              let v213_7: Space = routine_33(c, &(v213_6), &(*p0), &(v211_7_tail).make_space());
              compose(&(v212_5),&(v213_7))
            };
            drop(v212_5);
            let v212_9: Space = intersect(&(*CONSTANT_12),&(v212_2));
            drop(v212_2);
            let v212_10: Space = if has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
            drop(v212_9);
            let v212_12: Space = if (v212_10).is_empty() { Space::new() } else {
              let v214_6: Path = concat_path(&(v211_6),&(v211_7_head));
              let v214_11: Space = routine_34(c, &(v214_6), &(*p0), &(v211_7_tail).make_space());
              drop(v214_6);
              compose(&(v212_10),&(v214_11))
            };
            drop(v212_10);
            let v212_13: Space = unite(&(v212_8),&(v212_12));
            v211_7.join_into((v212_13).clone());
            }
            v211_7_cursor.ascend(1);
          }
          drop(v211_7_cursor);
          compose(&(v210_5),&(v211_7))
        };
        drop(v210_5);
        let v210_9: Space = intersect(&(*CONSTANT_12),&(v210_2));
        drop(v210_2);
        let v210_10: Space = if has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
        drop(v210_9);
        let v210_12: Space = if (v210_10).is_empty() { Space::new() } else {
          let v215_6: Path = concat_path(&(v207_20_head),&(v209_6_head));
          let mut v215_11 = Space::new();
          let mut v215_11_cursor = (v209_6_tail).read_zipper();
          for v215_11_byte in v215_11_cursor.child_mask().iter() {
            v215_11_cursor.descend_to_byte(v215_11_byte);
            {
            let v215_11_tail = v215_11_cursor.fork_read_zipper();
            let v215_11_head = Path::from_slice(&[v215_11_byte]);
            let v216_2: Space = singleton(&(v215_11_head));
            let v216_3: Space = intersect(&(*CONSTANT_12),&(v216_2));
            let v216_4: Space = if has_head(&(v216_3)) { singleton(&[]) } else { Space::new() };
            drop(v216_3);
            let v216_5: Space = subtract(&(*CONSTANT_0),&(v216_4));
            drop(v216_4);
            let v216_8: Space = if (v216_5).is_empty() { Space::new() } else {
              let v217_6: Path = concat_path(&(v215_6),&(v215_11_head));
              let v217_7: Space = routine_33(c, &(v217_6), &(*p0), &(v215_11_tail).make_space());
              compose(&(v216_5),&(v217_7))
            };
            drop(v216_5);
            let v216_9: Space = intersect(&(*CONSTANT_12),&(v216_2));
            drop(v216_2);
            let v216_10: Space = if has_head(&(v216_9)) { singleton(&[]) } else { Space::new() };
            drop(v216_9);
            let v216_12: Space = if (v216_10).is_empty() { Space::new() } else {
              let v218_6: Path = concat_path(&(v215_6),&(v215_11_head));
              let v218_11: Space = routine_29(c, &(v218_6), &(*p0), &(v215_11_tail).make_space());
              drop(v218_6);
              compose(&(v216_10),&(v218_11))
            };
            drop(v216_10);
            let v216_13: Space = unite(&(v216_8),&(v216_12));
            v215_11.join_into((v216_13).clone());
            }
            v215_11_cursor.ascend(1);
          }
          drop(v215_11_cursor);
          drop(v215_6);
          compose(&(v210_10),&(v215_11))
        };
        drop(v210_10);
        let v210_13: Space = unite(&(v210_8),&(v210_12));
        v209_6.join_into((v210_13).clone());
        }
        v209_6_cursor.ascend(1);
      }
      drop(v209_6_cursor);
      compose(&(v208_5),&(v209_6))
    };
    drop(v208_5);
    let v208_8: Space = intersect(&(*CONSTANT_12),&(v208_2));
    drop(v208_2);
    let v208_9: Space = if has_head(&(v208_8)) { singleton(&[]) } else { Space::new() };
    drop(v208_8);
    let v208_11: Space = if (v208_9).is_empty() { Space::new() } else {
      let mut v219_10 = Space::new();
      let mut v219_10_cursor = (v207_20_tail).read_zipper();
      for v219_10_byte in v219_10_cursor.child_mask().iter() {
        v219_10_cursor.descend_to_byte(v219_10_byte);
        {
        let v219_10_tail = v219_10_cursor.fork_read_zipper();
        let v219_10_head = Path::from_slice(&[v219_10_byte]);
        let v220_2: Space = singleton(&(v219_10_head));
        let v220_3: Space = intersect(&(*CONSTANT_12),&(v220_2));
        let v220_4: Space = if has_head(&(v220_3)) { singleton(&[]) } else { Space::new() };
        drop(v220_3);
        let v220_5: Space = subtract(&(*CONSTANT_0),&(v220_4));
        drop(v220_4);
        let v220_8: Space = if (v220_5).is_empty() { Space::new() } else {
          let v221_6: Path = concat_path(&(v207_20_head),&(v219_10_head));
          let mut v221_7 = Space::new();
          let mut v221_7_cursor = (v219_10_tail).read_zipper();
          for v221_7_byte in v221_7_cursor.child_mask().iter() {
            v221_7_cursor.descend_to_byte(v221_7_byte);
            {
            let v221_7_tail = v221_7_cursor.fork_read_zipper();
            let v221_7_head = Path::from_slice(&[v221_7_byte]);
            let v222_2: Space = singleton(&(v221_7_head));
            let v222_3: Space = intersect(&(*CONSTANT_12),&(v222_2));
            let v222_4: Space = if has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
            drop(v222_3);
            let v222_5: Space = subtract(&(*CONSTANT_0),&(v222_4));
            drop(v222_4);
            let v222_8: Space = if (v222_5).is_empty() { Space::new() } else {
              let v223_6: Path = concat_path(&(v221_6),&(v221_7_head));
              let v223_7: Space = routine_33(c, &(v223_6), &(*p0), &(v221_7_tail).make_space());
              compose(&(v222_5),&(v223_7))
            };
            drop(v222_5);
            let v222_9: Space = intersect(&(*CONSTANT_12),&(v222_2));
            drop(v222_2);
            let v222_10: Space = if has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
            drop(v222_9);
            let v222_12: Space = if (v222_10).is_empty() { Space::new() } else {
              let v224_6: Path = concat_path(&(v221_6),&(v221_7_head));
              let v224_11: Space = routine_34(c, &(v224_6), &(*p0), &(v221_7_tail).make_space());
              drop(v224_6);
              compose(&(v222_10),&(v224_11))
            };
            drop(v222_10);
            let v222_13: Space = unite(&(v222_8),&(v222_12));
            v221_7.join_into((v222_13).clone());
            }
            v221_7_cursor.ascend(1);
          }
          drop(v221_7_cursor);
          compose(&(v220_5),&(v221_7))
        };
        drop(v220_5);
        let v220_9: Space = intersect(&(*CONSTANT_12),&(v220_2));
        drop(v220_2);
        let v220_10: Space = if has_head(&(v220_9)) { singleton(&[]) } else { Space::new() };
        drop(v220_9);
        let v220_13: Space = if (v220_10).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v207_20_head),&(v219_10_head));
          let v225_11: Path = concat_path(&(v225_6),&(*p0));
          drop(v225_6);
          let v225_12: Space = singleton(&(v225_11));
          drop(v225_11);
          compose(&(v220_10),&(v225_12))
        };
        drop(v220_10);
        let v220_14: Space = unite(&(v220_8),&(v220_13));
        drop(v220_13);
        v219_10.join_into((v220_14).clone());
        }
        v219_10_cursor.ascend(1);
      }
      drop(v219_10_cursor);
      compose(&(v208_9),&(v219_10))
    };
    drop(v208_9);
    let v208_12: Space = unite(&(v208_7),&(v208_11));
    v207_20.join_into((v208_12).clone());
    }
    v207_20_cursor.ascend(1);
  }
  drop(v207_20_cursor);
  (v207_20).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v226_14 = Space::new();
  let mut v226_14_cursor = (*s0).read_zipper();
  for v226_14_byte in v226_14_cursor.child_mask().iter() {
    v226_14_cursor.descend_to_byte(v226_14_byte);
    {
    let v226_14_tail = v226_14_cursor.fork_read_zipper();
    let v226_14_head = Path::from_slice(&[v226_14_byte]);
    let v227_2: Space = singleton(&(v226_14_head));
    let v227_3: Space = intersect(&(*CONSTANT_12),&(v227_2));
    let v227_4: Space = if has_head(&(v227_3)) { singleton(&[]) } else { Space::new() };
    drop(v227_3);
    let v227_5: Space = subtract(&(*CONSTANT_0),&(v227_4));
    drop(v227_4);
    let v227_8: Space = if (v227_5).is_empty() { Space::new() } else {
      let v228_6: Path = concat_path(&(*p0),&(v226_14_head));
      let mut v228_7 = Space::new();
      let mut v228_7_cursor = (v226_14_tail).read_zipper();
      for v228_7_byte in v228_7_cursor.child_mask().iter() {
        v228_7_cursor.descend_to_byte(v228_7_byte);
        {
        let v228_7_tail = v228_7_cursor.fork_read_zipper();
        let v228_7_head = Path::from_slice(&[v228_7_byte]);
        let v229_2: Space = singleton(&(v228_7_head));
        let v229_3: Space = intersect(&(*CONSTANT_12),&(v229_2));
        let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
        drop(v229_3);
        let v229_5: Space = subtract(&(*CONSTANT_0),&(v229_4));
        drop(v229_4);
        let v229_8: Space = if (v229_5).is_empty() { Space::new() } else {
          let v230_6: Path = concat_path(&(v228_6),&(v228_7_head));
          let v230_7: Space = routine_35(c, &(v230_6), &(v228_7_tail).make_space(), &(*s1), &(*s2), &(*s3));
          compose(&(v229_5),&(v230_7))
        };
        drop(v229_5);
        let v229_9: Space = intersect(&(*CONSTANT_12),&(v229_2));
        drop(v229_2);
        let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
        drop(v229_9);
        let v229_12: Space = if (v229_10).is_empty() { Space::new() } else {
          let v231_6: Path = concat_path(&(v228_6),&(v228_7_head));
          let v231_11: Space = routine_36(c, &(v231_6), &(v228_7_tail).make_space(), &(*s1), &(*s2), &(*s3));
          drop(v231_6);
          compose(&(v229_10),&(v231_11))
        };
        drop(v229_10);
        let v229_13: Space = unite(&(v229_8),&(v229_12));
        v228_7.join_into((v229_13).clone());
        }
        v228_7_cursor.ascend(1);
      }
      drop(v228_7_cursor);
      compose(&(v227_5),&(v228_7))
    };
    drop(v227_5);
    let v227_9: Space = intersect(&(*CONSTANT_12),&(v227_2));
    drop(v227_2);
    let v227_10: Space = if has_head(&(v227_9)) { singleton(&[]) } else { Space::new() };
    drop(v227_9);
    let v227_12: Space = if (v227_10).is_empty() { Space::new() } else {
      let v232_6: Path = concat_path(&(*p0),&(v226_14_head));
      let mut v232_11 = Space::new();
      let mut v232_11_cursor = (v226_14_tail).read_zipper();
      for v232_11_byte in v232_11_cursor.child_mask().iter() {
        v232_11_cursor.descend_to_byte(v232_11_byte);
        {
        let v232_11_tail = v232_11_cursor.fork_read_zipper();
        let v232_11_head = Path::from_slice(&[v232_11_byte]);
        let v233_2: Space = singleton(&(v232_11_head));
        let v233_3: Space = intersect(&(*CONSTANT_12),&(v233_2));
        let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = subtract(&(*CONSTANT_0),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (v233_5).is_empty() { Space::new() } else {
          let v234_6: Path = concat_path(&(v232_6),&(v232_11_head));
          let v234_7: Space = routine_35(c, &(v234_6), &(v232_11_tail).make_space(), &(*s1), &(*s2), &(*s3));
          compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = intersect(&(*CONSTANT_12),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_12: Space = if (v233_10).is_empty() { Space::new() } else {
          let v235_6: Path = concat_path(&(v232_6),&(v232_11_head));
          let v235_11: Space = routine_37(c, &(v235_6), &(v232_11_tail).make_space(), &(*s1), &(*s2), &(*s3));
          drop(v235_6);
          compose(&(v233_10),&(v235_11))
        };
        drop(v233_10);
        let v233_13: Space = unite(&(v233_8),&(v233_12));
        v232_11.join_into((v233_13).clone());
        }
        v232_11_cursor.ascend(1);
      }
      drop(v232_11_cursor);
      drop(v232_6);
      compose(&(v227_10),&(v232_11))
    };
    drop(v227_10);
    let v227_13: Space = unite(&(v227_8),&(v227_12));
    v226_14.join_into((v227_13).clone());
    }
    v226_14_cursor.ascend(1);
  }
  drop(v226_14_cursor);
  (v226_14).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v236_11 = Space::new();
  let mut v236_11_cursor = (*s0).read_zipper();
  for v236_11_byte in v236_11_cursor.child_mask().iter() {
    v236_11_cursor.descend_to_byte(v236_11_byte);
    {
    let v236_11_tail = v236_11_cursor.fork_read_zipper();
    let v236_11_head = Path::from_slice(&[v236_11_byte]);
    let v237_2: Space = singleton(&(v236_11_head));
    let v237_3: Space = intersect(&(*CONSTANT_12),&(v237_2));
    let v237_4: Space = if has_head(&(v237_3)) { singleton(&[]) } else { Space::new() };
    drop(v237_3);
    let v237_5: Space = subtract(&(*CONSTANT_0),&(v237_4));
    drop(v237_4);
    let v237_8: Space = if (v237_5).is_empty() { Space::new() } else {
      let v238_6: Path = concat_path(&(*p0),&(v236_11_head));
      let mut v238_7 = Space::new();
      let mut v238_7_cursor = (v236_11_tail).read_zipper();
      for v238_7_byte in v238_7_cursor.child_mask().iter() {
        v238_7_cursor.descend_to_byte(v238_7_byte);
        {
        let v238_7_tail = v238_7_cursor.fork_read_zipper();
        let v238_7_head = Path::from_slice(&[v238_7_byte]);
        let v239_2: Space = singleton(&(v238_7_head));
        let v239_3: Space = intersect(&(*CONSTANT_12),&(v239_2));
        let v239_4: Space = if has_head(&(v239_3)) { singleton(&[]) } else { Space::new() };
        drop(v239_3);
        let v239_5: Space = subtract(&(*CONSTANT_0),&(v239_4));
        drop(v239_4);
        let v239_8: Space = if (v239_5).is_empty() { Space::new() } else {
          let v240_6: Path = concat_path(&(v238_6),&(v238_7_head));
          let v240_7: Space = routine_35(c, &(v240_6), &(v238_7_tail).make_space(), &(*s1), &(*s2), &(*s3));
          compose(&(v239_5),&(v240_7))
        };
        drop(v239_5);
        let v239_9: Space = intersect(&(*CONSTANT_12),&(v239_2));
        drop(v239_2);
        let v239_10: Space = if has_head(&(v239_9)) { singleton(&[]) } else { Space::new() };
        drop(v239_9);
        let v239_12: Space = if (v239_10).is_empty() { Space::new() } else {
          let v241_6: Path = concat_path(&(v238_6),&(v238_7_head));
          let v241_11: Space = routine_36(c, &(v241_6), &(v238_7_tail).make_space(), &(*s1), &(*s2), &(*s3));
          drop(v241_6);
          compose(&(v239_10),&(v241_11))
        };
        drop(v239_10);
        let v239_13: Space = unite(&(v239_8),&(v239_12));
        v238_7.join_into((v239_13).clone());
        }
        v238_7_cursor.ascend(1);
      }
      drop(v238_7_cursor);
      compose(&(v237_5),&(v238_7))
    };
    drop(v237_5);
    let v237_9: Space = intersect(&(*CONSTANT_12),&(v237_2));
    drop(v237_2);
    let v237_10: Space = if has_head(&(v237_9)) { singleton(&[]) } else { Space::new() };
    drop(v237_9);
    let v237_27: Space = if (v237_10).is_empty() { Space::new() } else {
      let v242_6: Path = concat_path(&(*p0),&(v236_11_head));
      let v242_11: Space = singleton(&(v242_6));
      let v242_12: Space = routine_38(c, &(*s1), &(*s3), &(v242_11));
      let v242_13: Space = routine_38(c, &(*s2), &(*s3), &(v242_11));
      let v242_14: Space = intersect(&(v242_12),&(v242_13));
      let v242_15: Space = subtract(&(v242_14),&(v242_11));
      drop(v242_11);
      let v242_16: Space = wrap(&(v242_15),&(v242_6));
      drop(v242_6);
      let v242_17: Space = subtract(&(*s3),&(v242_13));
      let v242_18: Space = subtract(&(v242_17),&(v242_12));
      let v242_19: Space = routine_39(c, &(*s2), &(*s1), &(v242_18));
      let v242_20: Space = unite(&(v242_16),&(v242_19));
      let v242_21: Space = subtract(&(v242_12),&(v242_13));
      let v242_22: Space = routine_39(c, &(*s2), &(*s1), &(v242_21));
      let v242_23: Space = unite(&(v242_20),&(v242_22));
      let v242_24: Space = subtract(&(v242_13),&(v242_12));
      let v242_25: Space = routine_39(c, &(*s2), &(*s1), &(v242_24));
      let v242_26: Space = unite(&(v242_23),&(v242_25));
      compose(&(v237_10),&(v242_26))
    };
    drop(v237_10);
    let v237_28: Space = unite(&(v237_8),&(v237_27));
    v236_11.join_into((v237_28).clone());
    }
    v236_11_cursor.ascend(1);
  }
  drop(v236_11_cursor);
  (v236_11).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v243_3 = Space::new();
  let mut v243_3_cursor = (*s0).read_zipper();
  for v243_3_byte in v243_3_cursor.child_mask().iter() {
    v243_3_cursor.descend_to_byte(v243_3_byte);
    {
    let v243_3_tail = v243_3_cursor.fork_read_zipper();
    let v243_3_head = Path::from_slice(&[v243_3_byte]);
    let v244_2: Space = Space::new();
    v243_3.join_into((v244_2).clone());
    }
    v243_3_cursor.ascend(1);
  }
  drop(v243_3_cursor);
  (v243_3).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v245_4 = Space::new();
  let mut v245_4_cursor = (*s0).read_zipper();
  for v245_4_byte in v245_4_cursor.child_mask().iter() {
    v245_4_cursor.descend_to_byte(v245_4_byte);
    {
    let v245_4_tail = v245_4_cursor.fork_read_zipper();
    let v245_4_head = Path::from_slice(&[v245_4_byte]);
    let v246_2: Space = singleton(&(v245_4_head));
    let v246_3: Space = intersect(&(*CONSTANT_12),&(v246_2));
    drop(v246_2);
    let v246_4: Space = if has_head(&(v246_3)) { singleton(&[]) } else { Space::new() };
    drop(v246_3);
    let v246_8: Space = if (v246_4).is_empty() { Space::new() } else {
      let v247_5: Path = concat_path(&(*p0),&(v245_4_head));
      let v247_6: Path = concat_path(&(v247_5),&(*p1));
      drop(v247_5);
      let v247_7: Space = singleton(&(v247_6));
      drop(v247_6);
      compose(&(v246_4),&(v247_7))
    };
    drop(v246_4);
    v245_4.join_into((v246_8).clone());
    }
    v245_4_cursor.ascend(1);
  }
  drop(v245_4_cursor);
  (v245_4).clone()
}

fn routine_20(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v248_3: Path = concat_path(&(*p0),&(*p1));
  let v248_4: Space = singleton(&(v248_3));
  drop(v248_3);
  (v248_4).clone()
}

fn routine_21(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v249_15 = Space::new();
  let mut v249_15_cursor = (*s0).read_zipper();
  for v249_15_byte in v249_15_cursor.child_mask().iter() {
    v249_15_cursor.descend_to_byte(v249_15_byte);
    {
    let v249_15_tail = v249_15_cursor.fork_read_zipper();
    let v249_15_head = Path::from_slice(&[v249_15_byte]);
    let v250_2: Space = singleton(&(v249_15_head));
    let v250_3: Space = intersect(&(*CONSTANT_12),&(v250_2));
    let v250_4: Space = if has_head(&(v250_3)) { singleton(&[]) } else { Space::new() };
    drop(v250_3);
    let v250_5: Space = subtract(&(*CONSTANT_0),&(v250_4));
    drop(v250_4);
    let v250_8: Space = if (v250_5).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&(v249_15_head));
      let mut v251_7 = Space::new();
      let mut v251_7_cursor = (v249_15_tail).read_zipper();
      for v251_7_byte in v251_7_cursor.child_mask().iter() {
        v251_7_cursor.descend_to_byte(v251_7_byte);
        {
        let v251_7_tail = v251_7_cursor.fork_read_zipper();
        let v251_7_head = Path::from_slice(&[v251_7_byte]);
        let v252_2: Space = singleton(&(v251_7_head));
        let v252_3: Space = intersect(&(*CONSTANT_12),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_0),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (v252_5).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&(v251_7_head));
          let mut v253_7 = Space::new();
          let mut v253_7_cursor = (v251_7_tail).read_zipper();
          for v253_7_byte in v253_7_cursor.child_mask().iter() {
            v253_7_cursor.descend_to_byte(v253_7_byte);
            {
            let v253_7_tail = v253_7_cursor.fork_read_zipper();
            let v253_7_head = Path::from_slice(&[v253_7_byte]);
            let v254_2: Space = singleton(&(v253_7_head));
            let v254_3: Space = intersect(&(*CONSTANT_12),&(v254_2));
            let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
            drop(v254_3);
            let v254_5: Space = subtract(&(*CONSTANT_0),&(v254_4));
            drop(v254_4);
            let v254_8: Space = if (v254_5).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v253_6),&(v253_7_head));
              let v255_7: Space = routine_18(c, &(v255_6), &(*p1), &(v253_7_tail).make_space());
              compose(&(v254_5),&(v255_7))
            };
            drop(v254_5);
            let v254_9: Space = intersect(&(*CONSTANT_12),&(v254_2));
            drop(v254_2);
            let v254_10: Space = if has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
            drop(v254_9);
            let v254_12: Space = if (v254_10).is_empty() { Space::new() } else {
              let v256_6: Path = concat_path(&(v253_6),&(v253_7_head));
              let v256_11: Space = routine_19(c, &(v256_6), &(*p1), &(v253_7_tail).make_space());
              drop(v256_6);
              compose(&(v254_10),&(v256_11))
            };
            drop(v254_10);
            let v254_13: Space = unite(&(v254_8),&(v254_12));
            v253_7.join_into((v254_13).clone());
            }
            v253_7_cursor.ascend(1);
          }
          drop(v253_7_cursor);
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_12),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_12: Space = if (v252_10).is_empty() { Space::new() } else {
          let v257_6: Path = concat_path(&(v251_6),&(v251_7_head));
          let mut v257_11 = Space::new();
          let mut v257_11_cursor = (v251_7_tail).read_zipper();
          for v257_11_byte in v257_11_cursor.child_mask().iter() {
            v257_11_cursor.descend_to_byte(v257_11_byte);
            {
            let v257_11_tail = v257_11_cursor.fork_read_zipper();
            let v257_11_head = Path::from_slice(&[v257_11_byte]);
            let v258_2: Space = singleton(&(v257_11_head));
            let v258_3: Space = intersect(&(*CONSTANT_12),&(v258_2));
            let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = subtract(&(*CONSTANT_0),&(v258_4));
            drop(v258_4);
            let v258_8: Space = if (v258_5).is_empty() { Space::new() } else {
              let v259_6: Path = concat_path(&(v257_6),&(v257_11_head));
              let v259_7: Space = routine_18(c, &(v259_6), &(*p1), &(v257_11_tail).make_space());
              compose(&(v258_5),&(v259_7))
            };
            drop(v258_5);
            let v258_9: Space = intersect(&(*CONSTANT_12),&(v258_2));
            drop(v258_2);
            let v258_10: Space = if has_head(&(v258_9)) { singleton(&[]) } else { Space::new() };
            drop(v258_9);
            let v258_12: Space = if (v258_10).is_empty() { Space::new() } else {
              let v260_6: Path = concat_path(&(v257_6),&(v257_11_head));
              let v260_11: Space = routine_20(c, &(v260_6), &(*p1), &(v257_11_tail).make_space());
              drop(v260_6);
              compose(&(v258_10),&(v260_11))
            };
            drop(v258_10);
            let v258_13: Space = unite(&(v258_8),&(v258_12));
            v257_11.join_into((v258_13).clone());
            }
            v257_11_cursor.ascend(1);
          }
          drop(v257_11_cursor);
          drop(v257_6);
          compose(&(v252_10),&(v257_11))
        };
        drop(v252_10);
        let v252_13: Space = unite(&(v252_8),&(v252_12));
        v251_7.join_into((v252_13).clone());
        }
        v251_7_cursor.ascend(1);
      }
      drop(v251_7_cursor);
      compose(&(v250_5),&(v251_7))
    };
    drop(v250_5);
    let v250_9: Space = intersect(&(*CONSTANT_12),&(v250_2));
    drop(v250_2);
    let v250_10: Space = if has_head(&(v250_9)) { singleton(&[]) } else { Space::new() };
    drop(v250_9);
    let v250_13: Space = if (v250_10).is_empty() { Space::new() } else {
      let v261_6: Path = concat_path(&(*p0),&(v249_15_head));
      let v261_11: Path = concat_path(&(v261_6),&(*p1));
      drop(v261_6);
      let v261_12: Space = singleton(&(v261_11));
      drop(v261_11);
      compose(&(v250_10),&(v261_12))
    };
    drop(v250_10);
    let v250_14: Space = unite(&(v250_8),&(v250_13));
    drop(v250_13);
    v249_15.join_into((v250_14).clone());
    }
    v249_15_cursor.ascend(1);
  }
  drop(v249_15_cursor);
  (v249_15).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v262_13 = Space::new();
  let mut v262_13_cursor = (*s0).read_zipper();
  for v262_13_byte in v262_13_cursor.child_mask().iter() {
    v262_13_cursor.descend_to_byte(v262_13_byte);
    {
    let v262_13_tail = v262_13_cursor.fork_read_zipper();
    let v262_13_head = Path::from_slice(&[v262_13_byte]);
    let v263_2: Space = singleton(&(v262_13_head));
    let v263_3: Space = intersect(&(*CONSTANT_12),&(v263_2));
    let v263_4: Space = if has_head(&(v263_3)) { singleton(&[]) } else { Space::new() };
    drop(v263_3);
    let v263_5: Space = subtract(&(*CONSTANT_0),&(v263_4));
    drop(v263_4);
    let v263_8: Space = if (v263_5).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&(v262_13_head));
      let mut v264_7 = Space::new();
      let mut v264_7_cursor = (v262_13_tail).read_zipper();
      for v264_7_byte in v264_7_cursor.child_mask().iter() {
        v264_7_cursor.descend_to_byte(v264_7_byte);
        {
        let v264_7_tail = v264_7_cursor.fork_read_zipper();
        let v264_7_head = Path::from_slice(&[v264_7_byte]);
        let v265_2: Space = singleton(&(v264_7_head));
        let v265_3: Space = intersect(&(*CONSTANT_12),&(v265_2));
        let v265_4: Space = if has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = subtract(&(*CONSTANT_0),&(v265_4));
        drop(v265_4);
        let mut v265_6 = Space::new();
        let mut v265_6_cursor = (v264_7_tail).read_zipper();
        for v265_6_byte in v265_6_cursor.child_mask().iter() {
          v265_6_cursor.descend_to_byte(v265_6_byte);
          {
          let v265_6_tail = v265_6_cursor.fork_read_zipper();
          let v265_6_head = Path::from_slice(&[v265_6_byte]);
          let v266_2: Space = Space::new();
          v265_6.join_into((v266_2).clone());
          }
          v265_6_cursor.ascend(1);
        }
        drop(v265_6_cursor);
        let v265_7: Space = compose(&(v265_5),&(v265_6));
        drop(v265_5);
        drop(v265_6);
        let v265_8: Space = intersect(&(*CONSTANT_12),&(v265_2));
        drop(v265_2);
        let v265_9: Space = if has_head(&(v265_8)) { singleton(&[]) } else { Space::new() };
        drop(v265_8);
        let v265_12: Space = if (v265_9).is_empty() { Space::new() } else {
          let v267_10: Path = concat_path(&(v264_6),&(v264_7_head));
          let mut v267_11 = Space::new();
          let mut v267_11_cursor = (v264_7_tail).read_zipper();
          for v267_11_byte in v267_11_cursor.child_mask().iter() {
            v267_11_cursor.descend_to_byte(v267_11_byte);
            {
            let v267_11_tail = v267_11_cursor.fork_read_zipper();
            let v267_11_head = Path::from_slice(&[v267_11_byte]);
            let v268_2: Space = singleton(&(v267_11_head));
            let v268_3: Space = intersect(&(*CONSTANT_12),&(v268_2));
            drop(v268_2);
            let v268_4: Space = if has_head(&(v268_3)) { singleton(&[]) } else { Space::new() };
            drop(v268_3);
            let v268_7: Space = if (v268_4).is_empty() { Space::new() } else {
              let v269_5: Path = concat_path(&(v267_10),&(v267_11_head));
              let v269_6: Space = routine_20(c, &(v269_5), &(*p1), &(v267_11_tail).make_space());
              drop(v269_5);
              compose(&(v268_4),&(v269_6))
            };
            drop(v268_4);
            v267_11.join_into((v268_7).clone());
            }
            v267_11_cursor.ascend(1);
          }
          drop(v267_11_cursor);
          drop(v267_10);
          compose(&(v265_9),&(v267_11))
        };
        drop(v265_9);
        let v265_13: Space = unite(&(v265_7),&(v265_12));
        drop(v265_7);
        v264_7.join_into((v265_13).clone());
        }
        v264_7_cursor.ascend(1);
      }
      drop(v264_7_cursor);
      compose(&(v263_5),&(v264_7))
    };
    drop(v263_5);
    let v263_9: Space = intersect(&(*CONSTANT_12),&(v263_2));
    drop(v263_2);
    let v263_10: Space = if has_head(&(v263_9)) { singleton(&[]) } else { Space::new() };
    drop(v263_9);
    let v263_12: Space = if (v263_10).is_empty() { Space::new() } else {
      let v270_6: Path = concat_path(&(*p0),&(v262_13_head));
      let mut v270_11 = Space::new();
      let mut v270_11_cursor = (v262_13_tail).read_zipper();
      for v270_11_byte in v270_11_cursor.child_mask().iter() {
        v270_11_cursor.descend_to_byte(v270_11_byte);
        {
        let v270_11_tail = v270_11_cursor.fork_read_zipper();
        let v270_11_head = Path::from_slice(&[v270_11_byte]);
        let v271_2: Space = singleton(&(v270_11_head));
        let v271_3: Space = intersect(&(*CONSTANT_12),&(v271_2));
        let v271_4: Space = if has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
        drop(v271_3);
        let v271_5: Space = subtract(&(*CONSTANT_0),&(v271_4));
        drop(v271_4);
        let mut v271_6 = Space::new();
        let mut v271_6_cursor = (v270_11_tail).read_zipper();
        for v271_6_byte in v271_6_cursor.child_mask().iter() {
          v271_6_cursor.descend_to_byte(v271_6_byte);
          {
          let v271_6_tail = v271_6_cursor.fork_read_zipper();
          let v271_6_head = Path::from_slice(&[v271_6_byte]);
          let v272_2: Space = Space::new();
          v271_6.join_into((v272_2).clone());
          }
          v271_6_cursor.ascend(1);
        }
        drop(v271_6_cursor);
        let v271_7: Space = compose(&(v271_5),&(v271_6));
        drop(v271_5);
        drop(v271_6);
        let v271_8: Space = intersect(&(*CONSTANT_12),&(v271_2));
        drop(v271_2);
        let v271_9: Space = if has_head(&(v271_8)) { singleton(&[]) } else { Space::new() };
        drop(v271_8);
        let v271_13: Space = if (v271_9).is_empty() { Space::new() } else {
          let v273_10: Path = concat_path(&(v270_6),&(v270_11_head));
          let v273_11: Path = concat_path(&(v273_10),&(*p1));
          drop(v273_10);
          let v273_12: Space = singleton(&(v273_11));
          drop(v273_11);
          compose(&(v271_9),&(v273_12))
        };
        drop(v271_9);
        let v271_14: Space = unite(&(v271_7),&(v271_13));
        drop(v271_7);
        drop(v271_13);
        v270_11.join_into((v271_14).clone());
        }
        v270_11_cursor.ascend(1);
      }
      drop(v270_11_cursor);
      drop(v270_6);
      compose(&(v263_10),&(v270_11))
    };
    drop(v263_10);
    let v263_13: Space = unite(&(v263_8),&(v263_12));
    drop(v263_12);
    v262_13.join_into((v263_13).clone());
    }
    v262_13_cursor.ascend(1);
  }
  drop(v262_13_cursor);
  (v262_13).clone()
}

fn routine_23(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v274_10 = Space::new();
  let mut v274_10_cursor = (*s0).read_zipper();
  for v274_10_byte in v274_10_cursor.child_mask().iter() {
    v274_10_cursor.descend_to_byte(v274_10_byte);
    {
    let v274_10_tail = v274_10_cursor.fork_read_zipper();
    let v274_10_head = Path::from_slice(&[v274_10_byte]);
    let v275_2: Space = singleton(&(v274_10_head));
    let v275_3: Space = intersect(&(*CONSTANT_12),&(v275_2));
    let v275_4: Space = if has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
    drop(v275_3);
    let v275_5: Space = subtract(&(*CONSTANT_0),&(v275_4));
    drop(v275_4);
    let v275_8: Space = if (v275_5).is_empty() { Space::new() } else {
      let v276_6: Path = concat_path(&(*p0),&(v274_10_head));
      let mut v276_7 = Space::new();
      let mut v276_7_cursor = (v274_10_tail).read_zipper();
      for v276_7_byte in v276_7_cursor.child_mask().iter() {
        v276_7_cursor.descend_to_byte(v276_7_byte);
        {
        let v276_7_tail = v276_7_cursor.fork_read_zipper();
        let v276_7_head = Path::from_slice(&[v276_7_byte]);
        let v277_2: Space = singleton(&(v276_7_head));
        let v277_3: Space = intersect(&(*CONSTANT_12),&(v277_2));
        let v277_4: Space = if has_head(&(v277_3)) { singleton(&[]) } else { Space::new() };
        drop(v277_3);
        let v277_5: Space = subtract(&(*CONSTANT_0),&(v277_4));
        drop(v277_4);
        let mut v277_6 = Space::new();
        let mut v277_6_cursor = (v276_7_tail).read_zipper();
        for v277_6_byte in v277_6_cursor.child_mask().iter() {
          v277_6_cursor.descend_to_byte(v277_6_byte);
          {
          let v277_6_tail = v277_6_cursor.fork_read_zipper();
          let v277_6_head = Path::from_slice(&[v277_6_byte]);
          let v278_2: Space = Space::new();
          v277_6.join_into((v278_2).clone());
          }
          v277_6_cursor.ascend(1);
        }
        drop(v277_6_cursor);
        let v277_7: Space = compose(&(v277_5),&(v277_6));
        drop(v277_5);
        drop(v277_6);
        let v277_8: Space = intersect(&(*CONSTANT_12),&(v277_2));
        drop(v277_2);
        let v277_9: Space = if has_head(&(v277_8)) { singleton(&[]) } else { Space::new() };
        drop(v277_8);
        let v277_12: Space = if (v277_9).is_empty() { Space::new() } else {
          let v279_10: Path = concat_path(&(v276_6),&(v276_7_head));
          let mut v279_11 = Space::new();
          let mut v279_11_cursor = (v276_7_tail).read_zipper();
          for v279_11_byte in v279_11_cursor.child_mask().iter() {
            v279_11_cursor.descend_to_byte(v279_11_byte);
            {
            let v279_11_tail = v279_11_cursor.fork_read_zipper();
            let v279_11_head = Path::from_slice(&[v279_11_byte]);
            let v280_2: Space = singleton(&(v279_11_head));
            let v280_3: Space = intersect(&(*CONSTANT_12),&(v280_2));
            drop(v280_2);
            let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
            drop(v280_3);
            let v280_7: Space = if (v280_4).is_empty() { Space::new() } else {
              let v281_5: Path = concat_path(&(v279_10),&(v279_11_head));
              let v281_6: Space = routine_20(c, &(v281_5), &(*p1), &(v279_11_tail).make_space());
              drop(v281_5);
              compose(&(v280_4),&(v281_6))
            };
            drop(v280_4);
            v279_11.join_into((v280_7).clone());
            }
            v279_11_cursor.ascend(1);
          }
          drop(v279_11_cursor);
          drop(v279_10);
          compose(&(v277_9),&(v279_11))
        };
        drop(v277_9);
        let v277_13: Space = unite(&(v277_7),&(v277_12));
        drop(v277_7);
        v276_7.join_into((v277_13).clone());
        }
        v276_7_cursor.ascend(1);
      }
      drop(v276_7_cursor);
      compose(&(v275_5),&(v276_7))
    };
    drop(v275_5);
    let v275_9: Space = intersect(&(*CONSTANT_12),&(v275_2));
    drop(v275_2);
    let v275_10: Space = if has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
    drop(v275_9);
    let v275_13: Space = if (v275_10).is_empty() { Space::new() } else {
      let v282_6: Path = concat_path(&(*p0),&(v274_10_head));
      let v282_11: Path = concat_path(&(v282_6),&(*p1));
      drop(v282_6);
      let v282_12: Space = singleton(&(v282_11));
      drop(v282_11);
      compose(&(v275_10),&(v282_12))
    };
    drop(v275_10);
    let v275_14: Space = unite(&(v275_8),&(v275_13));
    drop(v275_13);
    v274_10.join_into((v275_14).clone());
    }
    v274_10_cursor.ascend(1);
  }
  drop(v274_10_cursor);
  (v274_10).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v283_7 = Space::new();
  let mut v283_7_cursor = (*s0).read_zipper();
  for v283_7_byte in v283_7_cursor.child_mask().iter() {
    v283_7_cursor.descend_to_byte(v283_7_byte);
    {
    let v283_7_tail = v283_7_cursor.fork_read_zipper();
    let v283_7_head = Path::from_slice(&[v283_7_byte]);
    let v284_2: Space = singleton(&(v283_7_head));
    let v284_3: Space = intersect(&(*CONSTANT_12),&(v284_2));
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = subtract(&(*CONSTANT_0),&(v284_4));
    drop(v284_4);
    let mut v284_6 = Space::new();
    let mut v284_6_cursor = (v283_7_tail).read_zipper();
    for v284_6_byte in v284_6_cursor.child_mask().iter() {
      v284_6_cursor.descend_to_byte(v284_6_byte);
      {
      let v284_6_tail = v284_6_cursor.fork_read_zipper();
      let v284_6_head = Path::from_slice(&[v284_6_byte]);
      let v285_2: Space = Space::new();
      v284_6.join_into((v285_2).clone());
      }
      v284_6_cursor.ascend(1);
    }
    drop(v284_6_cursor);
    let v284_7: Space = compose(&(v284_5),&(v284_6));
    drop(v284_5);
    drop(v284_6);
    let v284_8: Space = intersect(&(*CONSTANT_12),&(v284_2));
    drop(v284_2);
    let v284_9: Space = if has_head(&(v284_8)) { singleton(&[]) } else { Space::new() };
    drop(v284_8);
    let v284_12: Space = if (v284_9).is_empty() { Space::new() } else {
      let v286_10: Path = concat_path(&(*p0),&(v283_7_head));
      let mut v286_11 = Space::new();
      let mut v286_11_cursor = (v283_7_tail).read_zipper();
      for v286_11_byte in v286_11_cursor.child_mask().iter() {
        v286_11_cursor.descend_to_byte(v286_11_byte);
        {
        let v286_11_tail = v286_11_cursor.fork_read_zipper();
        let v286_11_head = Path::from_slice(&[v286_11_byte]);
        let v287_2: Space = singleton(&(v286_11_head));
        let v287_3: Space = intersect(&(*CONSTANT_12),&(v287_2));
        drop(v287_2);
        let v287_4: Space = if has_head(&(v287_3)) { singleton(&[]) } else { Space::new() };
        drop(v287_3);
        let v287_8: Space = if (v287_4).is_empty() { Space::new() } else {
          let v288_5: Path = concat_path(&(v286_10),&(v286_11_head));
          let v288_6: Path = concat_path(&(v288_5),&(*p1));
          drop(v288_5);
          let v288_7: Space = singleton(&(v288_6));
          drop(v288_6);
          compose(&(v287_4),&(v288_7))
        };
        drop(v287_4);
        v286_11.join_into((v287_8).clone());
        }
        v286_11_cursor.ascend(1);
      }
      drop(v286_11_cursor);
      drop(v286_10);
      compose(&(v284_9),&(v286_11))
    };
    drop(v284_9);
    let v284_13: Space = unite(&(v284_7),&(v284_12));
    drop(v284_7);
    drop(v284_12);
    v283_7.join_into((v284_13).clone());
    }
    v283_7_cursor.ascend(1);
  }
  drop(v283_7_cursor);
  (v283_7).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v289_6 = Space::new();
  let mut v289_6_cursor = (*s0).read_zipper();
  for v289_6_byte in v289_6_cursor.child_mask().iter() {
    v289_6_cursor.descend_to_byte(v289_6_byte);
    {
    let v289_6_tail = v289_6_cursor.fork_read_zipper();
    let v289_6_head = Path::from_slice(&[v289_6_byte]);
    let v290_2: Space = singleton(&(v289_6_head));
    let v290_3: Space = intersect(&(*CONSTANT_12),&(v290_2));
    let v290_4: Space = if has_head(&(v290_3)) { singleton(&[]) } else { Space::new() };
    drop(v290_3);
    let v290_5: Space = subtract(&(*CONSTANT_0),&(v290_4));
    drop(v290_4);
    let mut v290_6 = Space::new();
    let mut v290_6_cursor = (v289_6_tail).read_zipper();
    for v290_6_byte in v290_6_cursor.child_mask().iter() {
      v290_6_cursor.descend_to_byte(v290_6_byte);
      {
      let v290_6_tail = v290_6_cursor.fork_read_zipper();
      let v290_6_head = Path::from_slice(&[v290_6_byte]);
      let v291_2: Space = Space::new();
      v290_6.join_into((v291_2).clone());
      }
      v290_6_cursor.ascend(1);
    }
    drop(v290_6_cursor);
    let v290_7: Space = compose(&(v290_5),&(v290_6));
    drop(v290_5);
    drop(v290_6);
    let v290_8: Space = intersect(&(*CONSTANT_12),&(v290_2));
    drop(v290_2);
    let v290_9: Space = if has_head(&(v290_8)) { singleton(&[]) } else { Space::new() };
    drop(v290_8);
    let v290_13: Space = if (v290_9).is_empty() { Space::new() } else {
      let v292_10: Path = concat_path(&(*p0),&(v289_6_head));
      let v292_11: Path = concat_path(&(v292_10),&(*p1));
      drop(v292_10);
      let v292_12: Space = singleton(&(v292_11));
      drop(v292_11);
      compose(&(v290_9),&(v292_12))
    };
    drop(v290_9);
    let v290_14: Space = unite(&(v290_7),&(v290_13));
    drop(v290_7);
    drop(v290_13);
    v289_6.join_into((v290_14).clone());
    }
    v289_6_cursor.ascend(1);
  }
  drop(v289_6_cursor);
  (v289_6).clone()
}

fn routine_26(c: &mut Context, s0: &Space) -> Space {
  let v293_2: Space = first_matching(&(*s0),&(*CONSTANT_0),false);
  let v293_3: Space = intersect(&(*CONSTANT_0),&(v293_2));
  let v293_4: Space = if has_head(&(v293_2)) { singleton(&[]) } else { Space::new() };
  let v293_5: Space = unite(&(v293_3),&(v293_4));
  drop(v293_3);
  let v293_7: Space = compose(&(v293_5),&(*CONSTANT_0));
  drop(v293_5);
  let v293_9: Space = subtract(&(*CONSTANT_0),&(v293_2));
  drop(v293_2);
  let v293_10: Space = subtract(&(v293_9),&(v293_4));
  drop(v293_4);
  drop(v293_9);
  let v293_18: Space = if (v293_10).is_empty() { Space::new() } else {
    let v294_11: Space = first_fibonacci(&(*s0),6,5,true);
    let v294_12: Space = first_matching(&(v294_11),&(*CONSTANT_0),false);
    let v294_15: Space = if (v294_12).is_empty() { Space::new() } else {
      let v295_14: Space = routine_40(c, &(*CONSTANT_14), &(*s0));
      compose(&(v294_12),&(v295_14))
    };
    drop(v294_12);
    let mut v294_16 = Space::new();
    let mut v294_16_cursor = (v294_11).read_zipper();
    for v294_16_byte in v294_16_cursor.child_mask().iter() {
      v294_16_cursor.descend_to_byte(v294_16_byte);
      {
      let v294_16_tail = v294_16_cursor.fork_read_zipper();
      let v294_16_head = Path::from_slice(&[v294_16_byte]);
      let mut v296_2 = Space::new();
      let v296_2_arg_0: &Path = &(v294_16_head);
      let v296_2_arg_1: &Space = &(v294_16_tail).make_space();
      let v296_2_arg_2: &Space = &(*s0);
      let mut v296_2_cursor = v296_2_arg_1.read_zipper();
      let mut v296_2_more = v296_2_cursor.is_val() || v296_2_cursor.to_next_val();
      while v296_2_more {
        {
        let v296_2_path = concat_path(v296_2_arg_0,v296_2_cursor.path());
        let v296_2_rest = v296_2_cursor.fork_read_zipper();
        let v297_3: Space = unwrap(&(*v296_2_arg_2),&(v296_2_path));
        let v297_4: Space = routine_26(c, &(v297_3));
        drop(v297_3);
        let v297_5: Space = wrap(&(v297_4),&(v296_2_path));
        v296_2.join_into((v297_5).clone());
        }
        v296_2_more = v296_2_cursor.to_next_val();
      }
      drop(v296_2_cursor);
      v294_16.join_into((v296_2).clone());
      }
      v294_16_cursor.ascend(1);
    }
    drop(v294_16_cursor);
    drop(v294_11);
    let v294_17: Space = unite(&(v294_15),&(v294_16));
    compose(&(v293_10),&(v294_17))
  };
  drop(v293_10);
  let v293_19: Space = unite(&(v293_7),&(v293_18));
  drop(v293_7);
  (v293_19).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v298_3 = Space::new();
  let mut v298_3_cursor = (*s0).read_zipper();
  for v298_3_byte in v298_3_cursor.child_mask().iter() {
    v298_3_cursor.descend_to_byte(v298_3_byte);
    {
    let v298_3_tail = v298_3_cursor.fork_read_zipper();
    let v298_3_head = Path::from_slice(&[v298_3_byte]);
    let v299_2: Space = Space::new();
    v298_3.join_into((v299_2).clone());
    }
    v298_3_cursor.ascend(1);
  }
  drop(v298_3_cursor);
  (v298_3).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v300_4 = Space::new();
  let mut v300_4_cursor = (*s0).read_zipper();
  for v300_4_byte in v300_4_cursor.child_mask().iter() {
    v300_4_cursor.descend_to_byte(v300_4_byte);
    {
    let v300_4_tail = v300_4_cursor.fork_read_zipper();
    let v300_4_head = Path::from_slice(&[v300_4_byte]);
    let v301_2: Space = singleton(&(v300_4_head));
    let v301_3: Space = intersect(&(*CONSTANT_12),&(v301_2));
    drop(v301_2);
    let v301_4: Space = if has_head(&(v301_3)) { singleton(&[]) } else { Space::new() };
    drop(v301_3);
    let v301_8: Space = if (v301_4).is_empty() { Space::new() } else {
      let v302_5: Path = concat_path(&(*p0),&(v300_4_head));
      let v302_6: Path = concat_path(&(v302_5),&(*p1));
      drop(v302_5);
      let v302_7: Space = singleton(&(v302_6));
      drop(v302_6);
      compose(&(v301_4),&(v302_7))
    };
    drop(v301_4);
    v300_4.join_into((v301_8).clone());
    }
    v300_4_cursor.ascend(1);
  }
  drop(v300_4_cursor);
  (v300_4).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v303_3: Path = concat_path(&(*p0),&(*p1));
  let v303_4: Space = singleton(&(v303_3));
  drop(v303_3);
  (v303_4).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v304_15 = Space::new();
  let mut v304_15_cursor = (*s0).read_zipper();
  for v304_15_byte in v304_15_cursor.child_mask().iter() {
    v304_15_cursor.descend_to_byte(v304_15_byte);
    {
    let v304_15_tail = v304_15_cursor.fork_read_zipper();
    let v304_15_head = Path::from_slice(&[v304_15_byte]);
    let v305_2: Space = singleton(&(v304_15_head));
    let v305_3: Space = intersect(&(*CONSTANT_12),&(v305_2));
    let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
    drop(v305_3);
    let v305_5: Space = subtract(&(*CONSTANT_0),&(v305_4));
    drop(v305_4);
    let v305_8: Space = if (v305_5).is_empty() { Space::new() } else {
      let v306_6: Path = concat_path(&(*p0),&(v304_15_head));
      let mut v306_7 = Space::new();
      let mut v306_7_cursor = (v304_15_tail).read_zipper();
      for v306_7_byte in v306_7_cursor.child_mask().iter() {
        v306_7_cursor.descend_to_byte(v306_7_byte);
        {
        let v306_7_tail = v306_7_cursor.fork_read_zipper();
        let v306_7_head = Path::from_slice(&[v306_7_byte]);
        let v307_2: Space = singleton(&(v306_7_head));
        let v307_3: Space = intersect(&(*CONSTANT_12),&(v307_2));
        let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
        drop(v307_3);
        let v307_5: Space = subtract(&(*CONSTANT_0),&(v307_4));
        drop(v307_4);
        let v307_8: Space = if (v307_5).is_empty() { Space::new() } else {
          let v308_6: Path = concat_path(&(v306_6),&(v306_7_head));
          let mut v308_7 = Space::new();
          let mut v308_7_cursor = (v306_7_tail).read_zipper();
          for v308_7_byte in v308_7_cursor.child_mask().iter() {
            v308_7_cursor.descend_to_byte(v308_7_byte);
            {
            let v308_7_tail = v308_7_cursor.fork_read_zipper();
            let v308_7_head = Path::from_slice(&[v308_7_byte]);
            let v309_2: Space = singleton(&(v308_7_head));
            let v309_3: Space = intersect(&(*CONSTANT_12),&(v309_2));
            let v309_4: Space = if has_head(&(v309_3)) { singleton(&[]) } else { Space::new() };
            drop(v309_3);
            let v309_5: Space = subtract(&(*CONSTANT_0),&(v309_4));
            drop(v309_4);
            let v309_8: Space = if (v309_5).is_empty() { Space::new() } else {
              let v310_6: Path = concat_path(&(v308_6),&(v308_7_head));
              let v310_7: Space = routine_27(c, &(v310_6), &(*p1), &(v308_7_tail).make_space());
              compose(&(v309_5),&(v310_7))
            };
            drop(v309_5);
            let v309_9: Space = intersect(&(*CONSTANT_12),&(v309_2));
            drop(v309_2);
            let v309_10: Space = if has_head(&(v309_9)) { singleton(&[]) } else { Space::new() };
            drop(v309_9);
            let v309_12: Space = if (v309_10).is_empty() { Space::new() } else {
              let v311_6: Path = concat_path(&(v308_6),&(v308_7_head));
              let v311_11: Space = routine_28(c, &(v311_6), &(*p1), &(v308_7_tail).make_space());
              drop(v311_6);
              compose(&(v309_10),&(v311_11))
            };
            drop(v309_10);
            let v309_13: Space = unite(&(v309_8),&(v309_12));
            v308_7.join_into((v309_13).clone());
            }
            v308_7_cursor.ascend(1);
          }
          drop(v308_7_cursor);
          compose(&(v307_5),&(v308_7))
        };
        drop(v307_5);
        let v307_9: Space = intersect(&(*CONSTANT_12),&(v307_2));
        drop(v307_2);
        let v307_10: Space = if has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
        drop(v307_9);
        let v307_12: Space = if (v307_10).is_empty() { Space::new() } else {
          let v312_6: Path = concat_path(&(v306_6),&(v306_7_head));
          let mut v312_11 = Space::new();
          let mut v312_11_cursor = (v306_7_tail).read_zipper();
          for v312_11_byte in v312_11_cursor.child_mask().iter() {
            v312_11_cursor.descend_to_byte(v312_11_byte);
            {
            let v312_11_tail = v312_11_cursor.fork_read_zipper();
            let v312_11_head = Path::from_slice(&[v312_11_byte]);
            let v313_2: Space = singleton(&(v312_11_head));
            let v313_3: Space = intersect(&(*CONSTANT_12),&(v313_2));
            let v313_4: Space = if has_head(&(v313_3)) { singleton(&[]) } else { Space::new() };
            drop(v313_3);
            let v313_5: Space = subtract(&(*CONSTANT_0),&(v313_4));
            drop(v313_4);
            let v313_8: Space = if (v313_5).is_empty() { Space::new() } else {
              let v314_6: Path = concat_path(&(v312_6),&(v312_11_head));
              let v314_7: Space = routine_27(c, &(v314_6), &(*p1), &(v312_11_tail).make_space());
              compose(&(v313_5),&(v314_7))
            };
            drop(v313_5);
            let v313_9: Space = intersect(&(*CONSTANT_12),&(v313_2));
            drop(v313_2);
            let v313_10: Space = if has_head(&(v313_9)) { singleton(&[]) } else { Space::new() };
            drop(v313_9);
            let v313_12: Space = if (v313_10).is_empty() { Space::new() } else {
              let v315_6: Path = concat_path(&(v312_6),&(v312_11_head));
              let v315_11: Space = routine_29(c, &(v315_6), &(*p1), &(v312_11_tail).make_space());
              drop(v315_6);
              compose(&(v313_10),&(v315_11))
            };
            drop(v313_10);
            let v313_13: Space = unite(&(v313_8),&(v313_12));
            v312_11.join_into((v313_13).clone());
            }
            v312_11_cursor.ascend(1);
          }
          drop(v312_11_cursor);
          drop(v312_6);
          compose(&(v307_10),&(v312_11))
        };
        drop(v307_10);
        let v307_13: Space = unite(&(v307_8),&(v307_12));
        v306_7.join_into((v307_13).clone());
        }
        v306_7_cursor.ascend(1);
      }
      drop(v306_7_cursor);
      compose(&(v305_5),&(v306_7))
    };
    drop(v305_5);
    let v305_9: Space = intersect(&(*CONSTANT_12),&(v305_2));
    drop(v305_2);
    let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
    drop(v305_9);
    let v305_13: Space = if (v305_10).is_empty() { Space::new() } else {
      let v316_6: Path = concat_path(&(*p0),&(v304_15_head));
      let v316_11: Path = concat_path(&(v316_6),&(*p1));
      drop(v316_6);
      let v316_12: Space = singleton(&(v316_11));
      drop(v316_11);
      compose(&(v305_10),&(v316_12))
    };
    drop(v305_10);
    let v305_14: Space = unite(&(v305_8),&(v305_13));
    drop(v305_13);
    v304_15.join_into((v305_14).clone());
    }
    v304_15_cursor.ascend(1);
  }
  drop(v304_15_cursor);
  (v304_15).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v317_13 = Space::new();
  let mut v317_13_cursor = (*s0).read_zipper();
  for v317_13_byte in v317_13_cursor.child_mask().iter() {
    v317_13_cursor.descend_to_byte(v317_13_byte);
    {
    let v317_13_tail = v317_13_cursor.fork_read_zipper();
    let v317_13_head = Path::from_slice(&[v317_13_byte]);
    let v318_2: Space = singleton(&(v317_13_head));
    let v318_3: Space = intersect(&(*CONSTANT_12),&(v318_2));
    let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
    drop(v318_3);
    let v318_5: Space = subtract(&(*CONSTANT_0),&(v318_4));
    drop(v318_4);
    let v318_8: Space = if (v318_5).is_empty() { Space::new() } else {
      let v319_6: Path = concat_path(&(*p0),&(v317_13_head));
      let mut v319_7 = Space::new();
      let mut v319_7_cursor = (v317_13_tail).read_zipper();
      for v319_7_byte in v319_7_cursor.child_mask().iter() {
        v319_7_cursor.descend_to_byte(v319_7_byte);
        {
        let v319_7_tail = v319_7_cursor.fork_read_zipper();
        let v319_7_head = Path::from_slice(&[v319_7_byte]);
        let v320_2: Space = singleton(&(v319_7_head));
        let v320_3: Space = intersect(&(*CONSTANT_12),&(v320_2));
        let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
        drop(v320_3);
        let v320_5: Space = subtract(&(*CONSTANT_0),&(v320_4));
        drop(v320_4);
        let mut v320_6 = Space::new();
        let mut v320_6_cursor = (v319_7_tail).read_zipper();
        for v320_6_byte in v320_6_cursor.child_mask().iter() {
          v320_6_cursor.descend_to_byte(v320_6_byte);
          {
          let v320_6_tail = v320_6_cursor.fork_read_zipper();
          let v320_6_head = Path::from_slice(&[v320_6_byte]);
          let v321_2: Space = Space::new();
          v320_6.join_into((v321_2).clone());
          }
          v320_6_cursor.ascend(1);
        }
        drop(v320_6_cursor);
        let v320_7: Space = compose(&(v320_5),&(v320_6));
        drop(v320_5);
        drop(v320_6);
        let v320_8: Space = intersect(&(*CONSTANT_12),&(v320_2));
        drop(v320_2);
        let v320_9: Space = if has_head(&(v320_8)) { singleton(&[]) } else { Space::new() };
        drop(v320_8);
        let v320_12: Space = if (v320_9).is_empty() { Space::new() } else {
          let v322_10: Path = concat_path(&(v319_6),&(v319_7_head));
          let mut v322_11 = Space::new();
          let mut v322_11_cursor = (v319_7_tail).read_zipper();
          for v322_11_byte in v322_11_cursor.child_mask().iter() {
            v322_11_cursor.descend_to_byte(v322_11_byte);
            {
            let v322_11_tail = v322_11_cursor.fork_read_zipper();
            let v322_11_head = Path::from_slice(&[v322_11_byte]);
            let v323_2: Space = singleton(&(v322_11_head));
            let v323_3: Space = intersect(&(*CONSTANT_12),&(v323_2));
            drop(v323_2);
            let v323_4: Space = if has_head(&(v323_3)) { singleton(&[]) } else { Space::new() };
            drop(v323_3);
            let v323_7: Space = if (v323_4).is_empty() { Space::new() } else {
              let v324_5: Path = concat_path(&(v322_10),&(v322_11_head));
              let v324_6: Space = routine_29(c, &(v324_5), &(*p1), &(v322_11_tail).make_space());
              drop(v324_5);
              compose(&(v323_4),&(v324_6))
            };
            drop(v323_4);
            v322_11.join_into((v323_7).clone());
            }
            v322_11_cursor.ascend(1);
          }
          drop(v322_11_cursor);
          drop(v322_10);
          compose(&(v320_9),&(v322_11))
        };
        drop(v320_9);
        let v320_13: Space = unite(&(v320_7),&(v320_12));
        drop(v320_7);
        v319_7.join_into((v320_13).clone());
        }
        v319_7_cursor.ascend(1);
      }
      drop(v319_7_cursor);
      compose(&(v318_5),&(v319_7))
    };
    drop(v318_5);
    let v318_9: Space = intersect(&(*CONSTANT_12),&(v318_2));
    drop(v318_2);
    let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
    drop(v318_9);
    let v318_12: Space = if (v318_10).is_empty() { Space::new() } else {
      let v325_6: Path = concat_path(&(*p0),&(v317_13_head));
      let mut v325_11 = Space::new();
      let mut v325_11_cursor = (v317_13_tail).read_zipper();
      for v325_11_byte in v325_11_cursor.child_mask().iter() {
        v325_11_cursor.descend_to_byte(v325_11_byte);
        {
        let v325_11_tail = v325_11_cursor.fork_read_zipper();
        let v325_11_head = Path::from_slice(&[v325_11_byte]);
        let v326_2: Space = singleton(&(v325_11_head));
        let v326_3: Space = intersect(&(*CONSTANT_12),&(v326_2));
        let v326_4: Space = if has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
        drop(v326_3);
        let v326_5: Space = subtract(&(*CONSTANT_0),&(v326_4));
        drop(v326_4);
        let mut v326_6 = Space::new();
        let mut v326_6_cursor = (v325_11_tail).read_zipper();
        for v326_6_byte in v326_6_cursor.child_mask().iter() {
          v326_6_cursor.descend_to_byte(v326_6_byte);
          {
          let v326_6_tail = v326_6_cursor.fork_read_zipper();
          let v326_6_head = Path::from_slice(&[v326_6_byte]);
          let v327_2: Space = Space::new();
          v326_6.join_into((v327_2).clone());
          }
          v326_6_cursor.ascend(1);
        }
        drop(v326_6_cursor);
        let v326_7: Space = compose(&(v326_5),&(v326_6));
        drop(v326_5);
        drop(v326_6);
        let v326_8: Space = intersect(&(*CONSTANT_12),&(v326_2));
        drop(v326_2);
        let v326_9: Space = if has_head(&(v326_8)) { singleton(&[]) } else { Space::new() };
        drop(v326_8);
        let v326_13: Space = if (v326_9).is_empty() { Space::new() } else {
          let v328_10: Path = concat_path(&(v325_6),&(v325_11_head));
          let v328_11: Path = concat_path(&(v328_10),&(*p1));
          drop(v328_10);
          let v328_12: Space = singleton(&(v328_11));
          drop(v328_11);
          compose(&(v326_9),&(v328_12))
        };
        drop(v326_9);
        let v326_14: Space = unite(&(v326_7),&(v326_13));
        drop(v326_7);
        drop(v326_13);
        v325_11.join_into((v326_14).clone());
        }
        v325_11_cursor.ascend(1);
      }
      drop(v325_11_cursor);
      drop(v325_6);
      compose(&(v318_10),&(v325_11))
    };
    drop(v318_10);
    let v318_13: Space = unite(&(v318_8),&(v318_12));
    drop(v318_12);
    v317_13.join_into((v318_13).clone());
    }
    v317_13_cursor.ascend(1);
  }
  drop(v317_13_cursor);
  (v317_13).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v329_10 = Space::new();
  let mut v329_10_cursor = (*s0).read_zipper();
  for v329_10_byte in v329_10_cursor.child_mask().iter() {
    v329_10_cursor.descend_to_byte(v329_10_byte);
    {
    let v329_10_tail = v329_10_cursor.fork_read_zipper();
    let v329_10_head = Path::from_slice(&[v329_10_byte]);
    let v330_2: Space = singleton(&(v329_10_head));
    let v330_3: Space = intersect(&(*CONSTANT_12),&(v330_2));
    let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
    drop(v330_3);
    let v330_5: Space = subtract(&(*CONSTANT_0),&(v330_4));
    drop(v330_4);
    let v330_8: Space = if (v330_5).is_empty() { Space::new() } else {
      let v331_6: Path = concat_path(&(*p0),&(v329_10_head));
      let mut v331_7 = Space::new();
      let mut v331_7_cursor = (v329_10_tail).read_zipper();
      for v331_7_byte in v331_7_cursor.child_mask().iter() {
        v331_7_cursor.descend_to_byte(v331_7_byte);
        {
        let v331_7_tail = v331_7_cursor.fork_read_zipper();
        let v331_7_head = Path::from_slice(&[v331_7_byte]);
        let v332_2: Space = singleton(&(v331_7_head));
        let v332_3: Space = intersect(&(*CONSTANT_12),&(v332_2));
        let v332_4: Space = if has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
        drop(v332_3);
        let v332_5: Space = subtract(&(*CONSTANT_0),&(v332_4));
        drop(v332_4);
        let mut v332_6 = Space::new();
        let mut v332_6_cursor = (v331_7_tail).read_zipper();
        for v332_6_byte in v332_6_cursor.child_mask().iter() {
          v332_6_cursor.descend_to_byte(v332_6_byte);
          {
          let v332_6_tail = v332_6_cursor.fork_read_zipper();
          let v332_6_head = Path::from_slice(&[v332_6_byte]);
          let v333_2: Space = Space::new();
          v332_6.join_into((v333_2).clone());
          }
          v332_6_cursor.ascend(1);
        }
        drop(v332_6_cursor);
        let v332_7: Space = compose(&(v332_5),&(v332_6));
        drop(v332_5);
        drop(v332_6);
        let v332_8: Space = intersect(&(*CONSTANT_12),&(v332_2));
        drop(v332_2);
        let v332_9: Space = if has_head(&(v332_8)) { singleton(&[]) } else { Space::new() };
        drop(v332_8);
        let v332_12: Space = if (v332_9).is_empty() { Space::new() } else {
          let v334_10: Path = concat_path(&(v331_6),&(v331_7_head));
          let mut v334_11 = Space::new();
          let mut v334_11_cursor = (v331_7_tail).read_zipper();
          for v334_11_byte in v334_11_cursor.child_mask().iter() {
            v334_11_cursor.descend_to_byte(v334_11_byte);
            {
            let v334_11_tail = v334_11_cursor.fork_read_zipper();
            let v334_11_head = Path::from_slice(&[v334_11_byte]);
            let v335_2: Space = singleton(&(v334_11_head));
            let v335_3: Space = intersect(&(*CONSTANT_12),&(v335_2));
            drop(v335_2);
            let v335_4: Space = if has_head(&(v335_3)) { singleton(&[]) } else { Space::new() };
            drop(v335_3);
            let v335_7: Space = if (v335_4).is_empty() { Space::new() } else {
              let v336_5: Path = concat_path(&(v334_10),&(v334_11_head));
              let v336_6: Space = routine_29(c, &(v336_5), &(*p1), &(v334_11_tail).make_space());
              drop(v336_5);
              compose(&(v335_4),&(v336_6))
            };
            drop(v335_4);
            v334_11.join_into((v335_7).clone());
            }
            v334_11_cursor.ascend(1);
          }
          drop(v334_11_cursor);
          drop(v334_10);
          compose(&(v332_9),&(v334_11))
        };
        drop(v332_9);
        let v332_13: Space = unite(&(v332_7),&(v332_12));
        drop(v332_7);
        v331_7.join_into((v332_13).clone());
        }
        v331_7_cursor.ascend(1);
      }
      drop(v331_7_cursor);
      compose(&(v330_5),&(v331_7))
    };
    drop(v330_5);
    let v330_9: Space = intersect(&(*CONSTANT_12),&(v330_2));
    drop(v330_2);
    let v330_10: Space = if has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
    drop(v330_9);
    let v330_13: Space = if (v330_10).is_empty() { Space::new() } else {
      let v337_6: Path = concat_path(&(*p0),&(v329_10_head));
      let v337_11: Path = concat_path(&(v337_6),&(*p1));
      drop(v337_6);
      let v337_12: Space = singleton(&(v337_11));
      drop(v337_11);
      compose(&(v330_10),&(v337_12))
    };
    drop(v330_10);
    let v330_14: Space = unite(&(v330_8),&(v330_13));
    drop(v330_13);
    v329_10.join_into((v330_14).clone());
    }
    v329_10_cursor.ascend(1);
  }
  drop(v329_10_cursor);
  (v329_10).clone()
}

fn routine_33(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v338_7 = Space::new();
  let mut v338_7_cursor = (*s0).read_zipper();
  for v338_7_byte in v338_7_cursor.child_mask().iter() {
    v338_7_cursor.descend_to_byte(v338_7_byte);
    {
    let v338_7_tail = v338_7_cursor.fork_read_zipper();
    let v338_7_head = Path::from_slice(&[v338_7_byte]);
    let v339_2: Space = singleton(&(v338_7_head));
    let v339_3: Space = intersect(&(*CONSTANT_12),&(v339_2));
    let v339_4: Space = if has_head(&(v339_3)) { singleton(&[]) } else { Space::new() };
    drop(v339_3);
    let v339_5: Space = subtract(&(*CONSTANT_0),&(v339_4));
    drop(v339_4);
    let mut v339_6 = Space::new();
    let mut v339_6_cursor = (v338_7_tail).read_zipper();
    for v339_6_byte in v339_6_cursor.child_mask().iter() {
      v339_6_cursor.descend_to_byte(v339_6_byte);
      {
      let v339_6_tail = v339_6_cursor.fork_read_zipper();
      let v339_6_head = Path::from_slice(&[v339_6_byte]);
      let v340_2: Space = Space::new();
      v339_6.join_into((v340_2).clone());
      }
      v339_6_cursor.ascend(1);
    }
    drop(v339_6_cursor);
    let v339_7: Space = compose(&(v339_5),&(v339_6));
    drop(v339_5);
    drop(v339_6);
    let v339_8: Space = intersect(&(*CONSTANT_12),&(v339_2));
    drop(v339_2);
    let v339_9: Space = if has_head(&(v339_8)) { singleton(&[]) } else { Space::new() };
    drop(v339_8);
    let v339_12: Space = if (v339_9).is_empty() { Space::new() } else {
      let v341_10: Path = concat_path(&(*p0),&(v338_7_head));
      let mut v341_11 = Space::new();
      let mut v341_11_cursor = (v338_7_tail).read_zipper();
      for v341_11_byte in v341_11_cursor.child_mask().iter() {
        v341_11_cursor.descend_to_byte(v341_11_byte);
        {
        let v341_11_tail = v341_11_cursor.fork_read_zipper();
        let v341_11_head = Path::from_slice(&[v341_11_byte]);
        let v342_2: Space = singleton(&(v341_11_head));
        let v342_3: Space = intersect(&(*CONSTANT_12),&(v342_2));
        drop(v342_2);
        let v342_4: Space = if has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
        drop(v342_3);
        let v342_8: Space = if (v342_4).is_empty() { Space::new() } else {
          let v343_5: Path = concat_path(&(v341_10),&(v341_11_head));
          let v343_6: Path = concat_path(&(v343_5),&(*p1));
          drop(v343_5);
          let v343_7: Space = singleton(&(v343_6));
          drop(v343_6);
          compose(&(v342_4),&(v343_7))
        };
        drop(v342_4);
        v341_11.join_into((v342_8).clone());
        }
        v341_11_cursor.ascend(1);
      }
      drop(v341_11_cursor);
      drop(v341_10);
      compose(&(v339_9),&(v341_11))
    };
    drop(v339_9);
    let v339_13: Space = unite(&(v339_7),&(v339_12));
    drop(v339_7);
    drop(v339_12);
    v338_7.join_into((v339_13).clone());
    }
    v338_7_cursor.ascend(1);
  }
  drop(v338_7_cursor);
  (v338_7).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v344_6 = Space::new();
  let mut v344_6_cursor = (*s0).read_zipper();
  for v344_6_byte in v344_6_cursor.child_mask().iter() {
    v344_6_cursor.descend_to_byte(v344_6_byte);
    {
    let v344_6_tail = v344_6_cursor.fork_read_zipper();
    let v344_6_head = Path::from_slice(&[v344_6_byte]);
    let v345_2: Space = singleton(&(v344_6_head));
    let v345_3: Space = intersect(&(*CONSTANT_12),&(v345_2));
    let v345_4: Space = if has_head(&(v345_3)) { singleton(&[]) } else { Space::new() };
    drop(v345_3);
    let v345_5: Space = subtract(&(*CONSTANT_0),&(v345_4));
    drop(v345_4);
    let mut v345_6 = Space::new();
    let mut v345_6_cursor = (v344_6_tail).read_zipper();
    for v345_6_byte in v345_6_cursor.child_mask().iter() {
      v345_6_cursor.descend_to_byte(v345_6_byte);
      {
      let v345_6_tail = v345_6_cursor.fork_read_zipper();
      let v345_6_head = Path::from_slice(&[v345_6_byte]);
      let v346_2: Space = Space::new();
      v345_6.join_into((v346_2).clone());
      }
      v345_6_cursor.ascend(1);
    }
    drop(v345_6_cursor);
    let v345_7: Space = compose(&(v345_5),&(v345_6));
    drop(v345_5);
    drop(v345_6);
    let v345_8: Space = intersect(&(*CONSTANT_12),&(v345_2));
    drop(v345_2);
    let v345_9: Space = if has_head(&(v345_8)) { singleton(&[]) } else { Space::new() };
    drop(v345_8);
    let v345_13: Space = if (v345_9).is_empty() { Space::new() } else {
      let v347_10: Path = concat_path(&(*p0),&(v344_6_head));
      let v347_11: Path = concat_path(&(v347_10),&(*p1));
      drop(v347_10);
      let v347_12: Space = singleton(&(v347_11));
      drop(v347_11);
      compose(&(v345_9),&(v347_12))
    };
    drop(v345_9);
    let v345_14: Space = unite(&(v345_7),&(v345_13));
    drop(v345_7);
    drop(v345_13);
    v344_6.join_into((v345_14).clone());
    }
    v344_6_cursor.ascend(1);
  }
  drop(v344_6_cursor);
  (v344_6).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v348_9 = Space::new();
  let mut v348_9_cursor = (*s0).read_zipper();
  for v348_9_byte in v348_9_cursor.child_mask().iter() {
    v348_9_cursor.descend_to_byte(v348_9_byte);
    {
    let v348_9_tail = v348_9_cursor.fork_read_zipper();
    let v348_9_head = Path::from_slice(&[v348_9_byte]);
    let v349_2: Space = singleton(&(v348_9_head));
    let v349_3: Space = intersect(&(*CONSTANT_12),&(v349_2));
    let v349_4: Space = if has_head(&(v349_3)) { singleton(&[]) } else { Space::new() };
    drop(v349_3);
    let v349_5: Space = subtract(&(*CONSTANT_0),&(v349_4));
    drop(v349_4);
    let mut v349_6 = Space::new();
    let mut v349_6_cursor = (v348_9_tail).read_zipper();
    for v349_6_byte in v349_6_cursor.child_mask().iter() {
      v349_6_cursor.descend_to_byte(v349_6_byte);
      {
      let v349_6_tail = v349_6_cursor.fork_read_zipper();
      let v349_6_head = Path::from_slice(&[v349_6_byte]);
      let v350_2: Space = Space::new();
      v349_6.join_into((v350_2).clone());
      }
      v349_6_cursor.ascend(1);
    }
    drop(v349_6_cursor);
    let v349_7: Space = compose(&(v349_5),&(v349_6));
    drop(v349_5);
    drop(v349_6);
    let v349_8: Space = intersect(&(*CONSTANT_12),&(v349_2));
    drop(v349_2);
    let v349_9: Space = if has_head(&(v349_8)) { singleton(&[]) } else { Space::new() };
    drop(v349_8);
    let v349_12: Space = if (v349_9).is_empty() { Space::new() } else {
      let v351_10: Path = concat_path(&(*p0),&(v348_9_head));
      let mut v351_11 = Space::new();
      let mut v351_11_cursor = (v348_9_tail).read_zipper();
      for v351_11_byte in v351_11_cursor.child_mask().iter() {
        v351_11_cursor.descend_to_byte(v351_11_byte);
        {
        let v351_11_tail = v351_11_cursor.fork_read_zipper();
        let v351_11_head = Path::from_slice(&[v351_11_byte]);
        let v352_2: Space = singleton(&(v351_11_head));
        let v352_3: Space = intersect(&(*CONSTANT_12),&(v352_2));
        drop(v352_2);
        let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
        drop(v352_3);
        let v352_7: Space = if (v352_4).is_empty() { Space::new() } else {
          let v353_5: Path = concat_path(&(v351_10),&(v351_11_head));
          let v353_6: Space = routine_37(c, &(v353_5), &(v351_11_tail).make_space(), &(*s1), &(*s2), &(*s3));
          drop(v353_5);
          compose(&(v352_4),&(v353_6))
        };
        drop(v352_4);
        v351_11.join_into((v352_7).clone());
        }
        v351_11_cursor.ascend(1);
      }
      drop(v351_11_cursor);
      drop(v351_10);
      compose(&(v349_9),&(v351_11))
    };
    drop(v349_9);
    let v349_13: Space = unite(&(v349_7),&(v349_12));
    drop(v349_7);
    v348_9.join_into((v349_13).clone());
    }
    v348_9_cursor.ascend(1);
  }
  drop(v348_9_cursor);
  (v348_9).clone()
}

fn routine_36(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v354_8 = Space::new();
  let mut v354_8_cursor = (*s0).read_zipper();
  for v354_8_byte in v354_8_cursor.child_mask().iter() {
    v354_8_cursor.descend_to_byte(v354_8_byte);
    {
    let v354_8_tail = v354_8_cursor.fork_read_zipper();
    let v354_8_head = Path::from_slice(&[v354_8_byte]);
    let v355_2: Space = singleton(&(v354_8_head));
    let v355_3: Space = intersect(&(*CONSTANT_12),&(v355_2));
    let v355_4: Space = if has_head(&(v355_3)) { singleton(&[]) } else { Space::new() };
    drop(v355_3);
    let v355_5: Space = subtract(&(*CONSTANT_0),&(v355_4));
    drop(v355_4);
    let mut v355_6 = Space::new();
    let mut v355_6_cursor = (v354_8_tail).read_zipper();
    for v355_6_byte in v355_6_cursor.child_mask().iter() {
      v355_6_cursor.descend_to_byte(v355_6_byte);
      {
      let v355_6_tail = v355_6_cursor.fork_read_zipper();
      let v355_6_head = Path::from_slice(&[v355_6_byte]);
      let v356_2: Space = Space::new();
      v355_6.join_into((v356_2).clone());
      }
      v355_6_cursor.ascend(1);
    }
    drop(v355_6_cursor);
    let v355_7: Space = compose(&(v355_5),&(v355_6));
    drop(v355_5);
    drop(v355_6);
    let v355_8: Space = intersect(&(*CONSTANT_12),&(v355_2));
    drop(v355_2);
    let v355_9: Space = if has_head(&(v355_8)) { singleton(&[]) } else { Space::new() };
    drop(v355_8);
    let v355_27: Space = if (v355_9).is_empty() { Space::new() } else {
      let v357_10: Path = concat_path(&(*p0),&(v354_8_head));
      let v357_11: Space = singleton(&(v357_10));
      let v357_12: Space = routine_38(c, &(*s1), &(*s3), &(v357_11));
      let v357_13: Space = routine_38(c, &(*s2), &(*s3), &(v357_11));
      let v357_14: Space = intersect(&(v357_12),&(v357_13));
      let v357_15: Space = subtract(&(v357_14),&(v357_11));
      drop(v357_11);
      let v357_16: Space = wrap(&(v357_15),&(v357_10));
      drop(v357_10);
      let v357_17: Space = subtract(&(*s3),&(v357_13));
      let v357_18: Space = subtract(&(v357_17),&(v357_12));
      let v357_19: Space = routine_39(c, &(*s2), &(*s1), &(v357_18));
      let v357_20: Space = unite(&(v357_16),&(v357_19));
      let v357_21: Space = subtract(&(v357_12),&(v357_13));
      let v357_22: Space = routine_39(c, &(*s2), &(*s1), &(v357_21));
      let v357_23: Space = unite(&(v357_20),&(v357_22));
      let v357_24: Space = subtract(&(v357_13),&(v357_12));
      let v357_25: Space = routine_39(c, &(*s2), &(*s1), &(v357_24));
      let v357_26: Space = unite(&(v357_23),&(v357_25));
      compose(&(v355_9),&(v357_26))
    };
    drop(v355_9);
    let v355_28: Space = unite(&(v355_7),&(v355_27));
    drop(v355_7);
    v354_8.join_into((v355_28).clone());
    }
    v354_8_cursor.ascend(1);
  }
  drop(v354_8_cursor);
  (v354_8).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let (v358_24,v358_43,v358_44,v358_45,v358_46,v358_5,v358_65,) = native_block_1(c, p0, s1, s2, s3);
  let (v358_163,v358_164,v358_183,v358_202,v358_66,v358_85,v358_86,v358_87,) = native_block_3(c, s1, s2, s3, &v358_46, &v358_5, &v358_65);
  let v358_203: Space = subtract(&(v358_183),&(v358_202));
  let v358_204: Space = routine_11(c, &(v358_203));
  let mut v358_280 = Space::new();
  let mut v358_280_cursor = (v358_204).read_zipper();
  for v358_280_byte in v358_280_cursor.child_mask().iter() {
    v358_280_cursor.descend_to_byte(v358_280_byte);
    {
    let v358_280_tail = v358_280_cursor.fork_read_zipper();
    let v358_280_head = Path::from_slice(&[v358_280_byte]);
    let (v542_10,v542_17,) = native_block_4(c, s1, s2, s3, &v358_280_head, &v358_280_tail, &v358_5);
    let v542_18: Space = unite(&(v542_10),&(v542_17));
    v358_280.join_into((v542_18).clone());
    }
    v358_280_cursor.ascend(1);
  }
  drop(v358_280_cursor);
  let v358_281: Space = unite(&(v358_164),&(v358_280));
  let mut v358_300: Space = (v358_5).clone();
  loop {
    let v617_1: Space = intersect(&(v358_300),&(*s3));
    let v617_2: Space = restrict_to(&(*s2),&(v617_1));
    drop(v617_1);
    let mut v617_3 = Space::new();
    let mut v617_3_cursor = (v617_2).read_zipper();
    for v617_3_byte in v617_3_cursor.child_mask().iter() {
      v617_3_cursor.descend_to_byte(v617_3_byte);
      {
      let v617_3_tail = v617_3_cursor.fork_read_zipper();
      let v617_3_head = Path::from_slice(&[v617_3_byte]);
      let v618_2: Space = singleton(&(v617_3_head));
      let v618_3: Space = intersect(&(*CONSTANT_12),&(v618_2));
      let v618_4: Space = if has_head(&(v618_3)) { singleton(&[]) } else { Space::new() };
      drop(v618_3);
      let v618_5: Space = subtract(&(*CONSTANT_0),&(v618_4));
      drop(v618_4);
      let v618_7: Space = if (v618_5).is_empty() { Space::new() } else {
        let mut v619_6 = Space::new();
        let mut v619_6_cursor = (v617_3_tail).read_zipper();
        for v619_6_byte in v619_6_cursor.child_mask().iter() {
          v619_6_cursor.descend_to_byte(v619_6_byte);
          {
          let v619_6_tail = v619_6_cursor.fork_read_zipper();
          let v619_6_head = Path::from_slice(&[v619_6_byte]);
          let v620_2: Space = singleton(&(v619_6_head));
          let v620_3: Space = intersect(&(*CONSTANT_12),&(v620_2));
          let v620_4: Space = if has_head(&(v620_3)) { singleton(&[]) } else { Space::new() };
          drop(v620_3);
          let v620_5: Space = subtract(&(*CONSTANT_0),&(v620_4));
          drop(v620_4);
          let v620_8: Space = if (v620_5).is_empty() { Space::new() } else {
            let v621_6: Path = concat_path(&(v617_3_head),&(v619_6_head));
            let mut v621_7 = Space::new();
            let mut v621_7_cursor = (v619_6_tail).read_zipper();
            for v621_7_byte in v621_7_cursor.child_mask().iter() {
              v621_7_cursor.descend_to_byte(v621_7_byte);
              {
              let v621_7_tail = v621_7_cursor.fork_read_zipper();
              let v621_7_head = Path::from_slice(&[v621_7_byte]);
              let v622_2: Space = singleton(&(v621_7_head));
              let v622_3: Space = intersect(&(*CONSTANT_12),&(v622_2));
              let v622_4: Space = if has_head(&(v622_3)) { singleton(&[]) } else { Space::new() };
              drop(v622_3);
              let v622_5: Space = subtract(&(*CONSTANT_0),&(v622_4));
              drop(v622_4);
              let v622_8: Space = if (v622_5).is_empty() { Space::new() } else {
                let v623_6: Path = concat_path(&(v621_6),&(v621_7_head));
                let v623_7: Space = routine_41(c, &(v623_6), &(v621_7_tail).make_space());
                compose(&(v622_5),&(v623_7))
              };
              drop(v622_5);
              let v622_9: Space = intersect(&(*CONSTANT_12),&(v622_2));
              drop(v622_2);
              let v622_10: Space = if has_head(&(v622_9)) { singleton(&[]) } else { Space::new() };
              drop(v622_9);
              let v622_12: Space = if (v622_10).is_empty() { Space::new() } else {
                let v624_6: Path = concat_path(&(v621_6),&(v621_7_head));
                let v624_11: Space = routine_42(c, &(v624_6), &(v621_7_tail).make_space());
                drop(v624_6);
                compose(&(v622_10),&(v624_11))
              };
              drop(v622_10);
              let v622_13: Space = unite(&(v622_8),&(v622_12));
              v621_7.join_into((v622_13).clone());
              }
              v621_7_cursor.ascend(1);
            }
            drop(v621_7_cursor);
            compose(&(v620_5),&(v621_7))
          };
          drop(v620_5);
          let v620_9: Space = intersect(&(*CONSTANT_12),&(v620_2));
          drop(v620_2);
          let v620_10: Space = if has_head(&(v620_9)) { singleton(&[]) } else { Space::new() };
          drop(v620_9);
          let v620_12: Space = if (v620_10).is_empty() { Space::new() } else {
            let v625_6: Path = concat_path(&(v617_3_head),&(v619_6_head));
            let mut v625_11 = Space::new();
            let mut v625_11_cursor = (v619_6_tail).read_zipper();
            for v625_11_byte in v625_11_cursor.child_mask().iter() {
              v625_11_cursor.descend_to_byte(v625_11_byte);
              {
              let v625_11_tail = v625_11_cursor.fork_read_zipper();
              let v625_11_head = Path::from_slice(&[v625_11_byte]);
              let v626_2: Space = singleton(&(v625_11_head));
              let v626_3: Space = intersect(&(*CONSTANT_12),&(v626_2));
              let v626_4: Space = if has_head(&(v626_3)) { singleton(&[]) } else { Space::new() };
              drop(v626_3);
              let v626_5: Space = subtract(&(*CONSTANT_0),&(v626_4));
              drop(v626_4);
              let v626_8: Space = if (v626_5).is_empty() { Space::new() } else {
                let v627_6: Path = concat_path(&(v625_6),&(v625_11_head));
                let v627_7: Space = routine_41(c, &(v627_6), &(v625_11_tail).make_space());
                compose(&(v626_5),&(v627_7))
              };
              drop(v626_5);
              let v626_9: Space = intersect(&(*CONSTANT_12),&(v626_2));
              drop(v626_2);
              let v626_10: Space = if has_head(&(v626_9)) { singleton(&[]) } else { Space::new() };
              drop(v626_9);
              let v626_12: Space = if (v626_10).is_empty() { Space::new() } else {
                let v628_6: Path = concat_path(&(v625_6),&(v625_11_head));
                let v628_11: Space = routine_43(c, &(v628_6), &(v625_11_tail).make_space());
                drop(v628_6);
                compose(&(v626_10),&(v628_11))
              };
              drop(v626_10);
              let v626_13: Space = unite(&(v626_8),&(v626_12));
              v625_11.join_into((v626_13).clone());
              }
              v625_11_cursor.ascend(1);
            }
            drop(v625_11_cursor);
            drop(v625_6);
            compose(&(v620_10),&(v625_11))
          };
          drop(v620_10);
          let v620_13: Space = unite(&(v620_8),&(v620_12));
          v619_6.join_into((v620_13).clone());
          }
          v619_6_cursor.ascend(1);
        }
        drop(v619_6_cursor);
        compose(&(v618_5),&(v619_6))
      };
      drop(v618_5);
      let v618_8: Space = intersect(&(*CONSTANT_12),&(v618_2));
      drop(v618_2);
      let v618_9: Space = if has_head(&(v618_8)) { singleton(&[]) } else { Space::new() };
      drop(v618_8);
      let v618_11: Space = if (v618_9).is_empty() { Space::new() } else {
        let mut v629_10 = Space::new();
        let mut v629_10_cursor = (v617_3_tail).read_zipper();
        for v629_10_byte in v629_10_cursor.child_mask().iter() {
          v629_10_cursor.descend_to_byte(v629_10_byte);
          {
          let v629_10_tail = v629_10_cursor.fork_read_zipper();
          let v629_10_head = Path::from_slice(&[v629_10_byte]);
          let v630_2: Space = singleton(&(v629_10_head));
          let v630_3: Space = intersect(&(*CONSTANT_12),&(v630_2));
          let v630_4: Space = if has_head(&(v630_3)) { singleton(&[]) } else { Space::new() };
          drop(v630_3);
          let v630_5: Space = subtract(&(*CONSTANT_0),&(v630_4));
          drop(v630_4);
          let v630_8: Space = if (v630_5).is_empty() { Space::new() } else {
            let v631_6: Path = concat_path(&(v617_3_head),&(v629_10_head));
            let mut v631_7 = Space::new();
            let mut v631_7_cursor = (v629_10_tail).read_zipper();
            for v631_7_byte in v631_7_cursor.child_mask().iter() {
              v631_7_cursor.descend_to_byte(v631_7_byte);
              {
              let v631_7_tail = v631_7_cursor.fork_read_zipper();
              let v631_7_head = Path::from_slice(&[v631_7_byte]);
              let v632_2: Space = singleton(&(v631_7_head));
              let v632_3: Space = intersect(&(*CONSTANT_12),&(v632_2));
              let v632_4: Space = if has_head(&(v632_3)) { singleton(&[]) } else { Space::new() };
              drop(v632_3);
              let v632_5: Space = subtract(&(*CONSTANT_0),&(v632_4));
              drop(v632_4);
              let v632_8: Space = if (v632_5).is_empty() { Space::new() } else {
                let v633_6: Path = concat_path(&(v631_6),&(v631_7_head));
                let v633_7: Space = routine_41(c, &(v633_6), &(v631_7_tail).make_space());
                compose(&(v632_5),&(v633_7))
              };
              drop(v632_5);
              let v632_9: Space = intersect(&(*CONSTANT_12),&(v632_2));
              drop(v632_2);
              let v632_10: Space = if has_head(&(v632_9)) { singleton(&[]) } else { Space::new() };
              drop(v632_9);
              let v632_12: Space = if (v632_10).is_empty() { Space::new() } else {
                let v634_6: Path = concat_path(&(v631_6),&(v631_7_head));
                let v634_11: Space = routine_42(c, &(v634_6), &(v631_7_tail).make_space());
                drop(v634_6);
                compose(&(v632_10),&(v634_11))
              };
              drop(v632_10);
              let v632_13: Space = unite(&(v632_8),&(v632_12));
              v631_7.join_into((v632_13).clone());
              }
              v631_7_cursor.ascend(1);
            }
            drop(v631_7_cursor);
            drop(v631_6);
            compose(&(v630_5),&(v631_7))
          };
          drop(v630_5);
          let v630_9: Space = intersect(&(*CONSTANT_12),&(v630_2));
          drop(v630_2);
          let v630_10: Space = if has_head(&(v630_9)) { singleton(&[]) } else { Space::new() };
          drop(v630_9);
          let v630_11: Space = compose(&(v630_10),&(v629_10_tail));
          drop(v630_10);
          let v630_12: Space = unite(&(v630_8),&(v630_11));
          drop(v630_11);
          v629_10.join_into((v630_12).clone());
          }
          v629_10_cursor.ascend(1);
        }
        drop(v629_10_cursor);
        compose(&(v618_9),&(v629_10))
      };
      drop(v618_9);
      let v618_12: Space = unite(&(v618_7),&(v618_11));
      v617_3.join_into((v618_12).clone());
      }
      v617_3_cursor.ascend(1);
    }
    drop(v617_3_cursor);
    drop(v617_2);
    let v617_4: Space = unite(&(v617_3),&(v358_300));
    let v617_5: Space = intersect(&(v617_4),&(*s3));
    if !v358_300.join_into((v617_5).clone()).is_element() { break; }
  }
  let mut v358_319: Space = (v358_5).clone();
  loop {
    let v635_1: Space = intersect(&(v358_319),&(*s3));
    let v635_2: Space = restrict_to(&(*s1),&(v635_1));
    drop(v635_1);
    let mut v635_3 = Space::new();
    let mut v635_3_cursor = (v635_2).read_zipper();
    for v635_3_byte in v635_3_cursor.child_mask().iter() {
      v635_3_cursor.descend_to_byte(v635_3_byte);
      {
      let v635_3_tail = v635_3_cursor.fork_read_zipper();
      let v635_3_head = Path::from_slice(&[v635_3_byte]);
      let v636_2: Space = singleton(&(v635_3_head));
      let v636_3: Space = intersect(&(*CONSTANT_12),&(v636_2));
      let v636_4: Space = if has_head(&(v636_3)) { singleton(&[]) } else { Space::new() };
      drop(v636_3);
      let v636_5: Space = subtract(&(*CONSTANT_0),&(v636_4));
      drop(v636_4);
      let v636_7: Space = if (v636_5).is_empty() { Space::new() } else {
        let mut v637_6 = Space::new();
        let mut v637_6_cursor = (v635_3_tail).read_zipper();
        for v637_6_byte in v637_6_cursor.child_mask().iter() {
          v637_6_cursor.descend_to_byte(v637_6_byte);
          {
          let v637_6_tail = v637_6_cursor.fork_read_zipper();
          let v637_6_head = Path::from_slice(&[v637_6_byte]);
          let v638_2: Space = singleton(&(v637_6_head));
          let v638_3: Space = intersect(&(*CONSTANT_12),&(v638_2));
          let v638_4: Space = if has_head(&(v638_3)) { singleton(&[]) } else { Space::new() };
          drop(v638_3);
          let v638_5: Space = subtract(&(*CONSTANT_0),&(v638_4));
          drop(v638_4);
          let v638_8: Space = if (v638_5).is_empty() { Space::new() } else {
            let v639_6: Path = concat_path(&(v635_3_head),&(v637_6_head));
            let mut v639_7 = Space::new();
            let mut v639_7_cursor = (v637_6_tail).read_zipper();
            for v639_7_byte in v639_7_cursor.child_mask().iter() {
              v639_7_cursor.descend_to_byte(v639_7_byte);
              {
              let v639_7_tail = v639_7_cursor.fork_read_zipper();
              let v639_7_head = Path::from_slice(&[v639_7_byte]);
              let v640_2: Space = singleton(&(v639_7_head));
              let v640_3: Space = intersect(&(*CONSTANT_12),&(v640_2));
              let v640_4: Space = if has_head(&(v640_3)) { singleton(&[]) } else { Space::new() };
              drop(v640_3);
              let v640_5: Space = subtract(&(*CONSTANT_0),&(v640_4));
              drop(v640_4);
              let v640_8: Space = if (v640_5).is_empty() { Space::new() } else {
                let v641_6: Path = concat_path(&(v639_6),&(v639_7_head));
                let v641_7: Space = routine_41(c, &(v641_6), &(v639_7_tail).make_space());
                compose(&(v640_5),&(v641_7))
              };
              drop(v640_5);
              let v640_9: Space = intersect(&(*CONSTANT_12),&(v640_2));
              drop(v640_2);
              let v640_10: Space = if has_head(&(v640_9)) { singleton(&[]) } else { Space::new() };
              drop(v640_9);
              let v640_12: Space = if (v640_10).is_empty() { Space::new() } else {
                let v642_6: Path = concat_path(&(v639_6),&(v639_7_head));
                let v642_11: Space = routine_42(c, &(v642_6), &(v639_7_tail).make_space());
                drop(v642_6);
                compose(&(v640_10),&(v642_11))
              };
              drop(v640_10);
              let v640_13: Space = unite(&(v640_8),&(v640_12));
              v639_7.join_into((v640_13).clone());
              }
              v639_7_cursor.ascend(1);
            }
            drop(v639_7_cursor);
            compose(&(v638_5),&(v639_7))
          };
          drop(v638_5);
          let v638_9: Space = intersect(&(*CONSTANT_12),&(v638_2));
          drop(v638_2);
          let v638_10: Space = if has_head(&(v638_9)) { singleton(&[]) } else { Space::new() };
          drop(v638_9);
          let v638_12: Space = if (v638_10).is_empty() { Space::new() } else {
            let v643_6: Path = concat_path(&(v635_3_head),&(v637_6_head));
            let mut v643_11 = Space::new();
            let mut v643_11_cursor = (v637_6_tail).read_zipper();
            for v643_11_byte in v643_11_cursor.child_mask().iter() {
              v643_11_cursor.descend_to_byte(v643_11_byte);
              {
              let v643_11_tail = v643_11_cursor.fork_read_zipper();
              let v643_11_head = Path::from_slice(&[v643_11_byte]);
              let v644_2: Space = singleton(&(v643_11_head));
              let v644_3: Space = intersect(&(*CONSTANT_12),&(v644_2));
              let v644_4: Space = if has_head(&(v644_3)) { singleton(&[]) } else { Space::new() };
              drop(v644_3);
              let v644_5: Space = subtract(&(*CONSTANT_0),&(v644_4));
              drop(v644_4);
              let v644_8: Space = if (v644_5).is_empty() { Space::new() } else {
                let v645_6: Path = concat_path(&(v643_6),&(v643_11_head));
                let v645_7: Space = routine_41(c, &(v645_6), &(v643_11_tail).make_space());
                compose(&(v644_5),&(v645_7))
              };
              drop(v644_5);
              let v644_9: Space = intersect(&(*CONSTANT_12),&(v644_2));
              drop(v644_2);
              let v644_10: Space = if has_head(&(v644_9)) { singleton(&[]) } else { Space::new() };
              drop(v644_9);
              let v644_12: Space = if (v644_10).is_empty() { Space::new() } else {
                let v646_6: Path = concat_path(&(v643_6),&(v643_11_head));
                let v646_11: Space = routine_43(c, &(v646_6), &(v643_11_tail).make_space());
                drop(v646_6);
                compose(&(v644_10),&(v646_11))
              };
              drop(v644_10);
              let v644_13: Space = unite(&(v644_8),&(v644_12));
              v643_11.join_into((v644_13).clone());
              }
              v643_11_cursor.ascend(1);
            }
            drop(v643_11_cursor);
            drop(v643_6);
            compose(&(v638_10),&(v643_11))
          };
          drop(v638_10);
          let v638_13: Space = unite(&(v638_8),&(v638_12));
          v637_6.join_into((v638_13).clone());
          }
          v637_6_cursor.ascend(1);
        }
        drop(v637_6_cursor);
        compose(&(v636_5),&(v637_6))
      };
      drop(v636_5);
      let v636_8: Space = intersect(&(*CONSTANT_12),&(v636_2));
      drop(v636_2);
      let v636_9: Space = if has_head(&(v636_8)) { singleton(&[]) } else { Space::new() };
      drop(v636_8);
      let v636_11: Space = if (v636_9).is_empty() { Space::new() } else {
        let mut v647_10 = Space::new();
        let mut v647_10_cursor = (v635_3_tail).read_zipper();
        for v647_10_byte in v647_10_cursor.child_mask().iter() {
          v647_10_cursor.descend_to_byte(v647_10_byte);
          {
          let v647_10_tail = v647_10_cursor.fork_read_zipper();
          let v647_10_head = Path::from_slice(&[v647_10_byte]);
          let v648_2: Space = singleton(&(v647_10_head));
          let v648_3: Space = intersect(&(*CONSTANT_12),&(v648_2));
          let v648_4: Space = if has_head(&(v648_3)) { singleton(&[]) } else { Space::new() };
          drop(v648_3);
          let v648_5: Space = subtract(&(*CONSTANT_0),&(v648_4));
          drop(v648_4);
          let v648_8: Space = if (v648_5).is_empty() { Space::new() } else {
            let v649_6: Path = concat_path(&(v635_3_head),&(v647_10_head));
            let mut v649_7 = Space::new();
            let mut v649_7_cursor = (v647_10_tail).read_zipper();
            for v649_7_byte in v649_7_cursor.child_mask().iter() {
              v649_7_cursor.descend_to_byte(v649_7_byte);
              {
              let v649_7_tail = v649_7_cursor.fork_read_zipper();
              let v649_7_head = Path::from_slice(&[v649_7_byte]);
              let v650_2: Space = singleton(&(v649_7_head));
              let v650_3: Space = intersect(&(*CONSTANT_12),&(v650_2));
              let v650_4: Space = if has_head(&(v650_3)) { singleton(&[]) } else { Space::new() };
              drop(v650_3);
              let v650_5: Space = subtract(&(*CONSTANT_0),&(v650_4));
              drop(v650_4);
              let v650_8: Space = if (v650_5).is_empty() { Space::new() } else {
                let v651_6: Path = concat_path(&(v649_6),&(v649_7_head));
                let v651_7: Space = routine_41(c, &(v651_6), &(v649_7_tail).make_space());
                compose(&(v650_5),&(v651_7))
              };
              drop(v650_5);
              let v650_9: Space = intersect(&(*CONSTANT_12),&(v650_2));
              drop(v650_2);
              let v650_10: Space = if has_head(&(v650_9)) { singleton(&[]) } else { Space::new() };
              drop(v650_9);
              let v650_12: Space = if (v650_10).is_empty() { Space::new() } else {
                let v652_6: Path = concat_path(&(v649_6),&(v649_7_head));
                let v652_11: Space = routine_42(c, &(v652_6), &(v649_7_tail).make_space());
                drop(v652_6);
                compose(&(v650_10),&(v652_11))
              };
              drop(v650_10);
              let v650_13: Space = unite(&(v650_8),&(v650_12));
              v649_7.join_into((v650_13).clone());
              }
              v649_7_cursor.ascend(1);
            }
            drop(v649_7_cursor);
            drop(v649_6);
            compose(&(v648_5),&(v649_7))
          };
          drop(v648_5);
          let v648_9: Space = intersect(&(*CONSTANT_12),&(v648_2));
          drop(v648_2);
          let v648_10: Space = if has_head(&(v648_9)) { singleton(&[]) } else { Space::new() };
          drop(v648_9);
          let v648_11: Space = compose(&(v648_10),&(v647_10_tail));
          drop(v648_10);
          let v648_12: Space = unite(&(v648_8),&(v648_11));
          drop(v648_11);
          v647_10.join_into((v648_12).clone());
          }
          v647_10_cursor.ascend(1);
        }
        drop(v647_10_cursor);
        compose(&(v636_9),&(v647_10))
      };
      drop(v636_9);
      let v636_12: Space = unite(&(v636_7),&(v636_11));
      v635_3.join_into((v636_12).clone());
      }
      v635_3_cursor.ascend(1);
    }
    drop(v635_3_cursor);
    drop(v635_2);
    let v635_4: Space = unite(&(v635_3),&(v358_319));
    let v635_5: Space = intersect(&(v635_4),&(*s3));
    if !v358_319.join_into((v635_5).clone()).is_element() { break; }
  }
  let v358_320: Space = subtract(&(v358_300),&(v358_319));
  let v358_321: Space = routine_11(c, &(v358_320));
  let mut v358_397 = Space::new();
  let mut v358_397_cursor = (v358_321).read_zipper();
  for v358_397_byte in v358_397_cursor.child_mask().iter() {
    v358_397_cursor.descend_to_byte(v358_397_byte);
    {
    let v358_397_tail = v358_397_cursor.fork_read_zipper();
    let v358_397_head = Path::from_slice(&[v358_397_byte]);
    let (v653_10,v653_17,) = native_block_5(c, s1, s2, s3, &v358_397_head, &v358_397_tail, &v358_5);
    let v653_18: Space = unite(&(v653_10),&(v653_17));
    v358_397.join_into((v653_18).clone());
    }
    v358_397_cursor.ascend(1);
  }
  drop(v358_397_cursor);
  drop(v358_5);
  let v358_398: Space = unite(&(v358_281),&(v358_397));
  (v358_398).clone()
}

fn routine_38(c: &mut Context, s0: &Space, s1: &Space, s2: &Space) -> Space {
  let v728_3: Space = intersect(&(*s1),&(*s2));
  let v728_4: Space = restrict_to(&(*s0),&(v728_3));
  drop(v728_3);
  let mut v728_23 = Space::new();
  let mut v728_23_cursor = (v728_4).read_zipper();
  for v728_23_byte in v728_23_cursor.child_mask().iter() {
    v728_23_cursor.descend_to_byte(v728_23_byte);
    {
    let v728_23_tail = v728_23_cursor.fork_read_zipper();
    let v728_23_head = Path::from_slice(&[v728_23_byte]);
    let v729_2: Space = singleton(&(v728_23_head));
    let v729_3: Space = intersect(&(*CONSTANT_12),&(v729_2));
    let v729_4: Space = if has_head(&(v729_3)) { singleton(&[]) } else { Space::new() };
    drop(v729_3);
    let v729_5: Space = subtract(&(*CONSTANT_0),&(v729_4));
    drop(v729_4);
    let v729_7: Space = if (v729_5).is_empty() { Space::new() } else {
      let mut v730_6 = Space::new();
      let mut v730_6_cursor = (v728_23_tail).read_zipper();
      for v730_6_byte in v730_6_cursor.child_mask().iter() {
        v730_6_cursor.descend_to_byte(v730_6_byte);
        {
        let v730_6_tail = v730_6_cursor.fork_read_zipper();
        let v730_6_head = Path::from_slice(&[v730_6_byte]);
        let v731_2: Space = singleton(&(v730_6_head));
        let v731_3: Space = intersect(&(*CONSTANT_12),&(v731_2));
        let v731_4: Space = if has_head(&(v731_3)) { singleton(&[]) } else { Space::new() };
        drop(v731_3);
        let v731_5: Space = subtract(&(*CONSTANT_0),&(v731_4));
        drop(v731_4);
        let v731_8: Space = if (v731_5).is_empty() { Space::new() } else {
          let v732_6: Path = concat_path(&(v728_23_head),&(v730_6_head));
          let mut v732_7 = Space::new();
          let mut v732_7_cursor = (v730_6_tail).read_zipper();
          for v732_7_byte in v732_7_cursor.child_mask().iter() {
            v732_7_cursor.descend_to_byte(v732_7_byte);
            {
            let v732_7_tail = v732_7_cursor.fork_read_zipper();
            let v732_7_head = Path::from_slice(&[v732_7_byte]);
            let v733_2: Space = singleton(&(v732_7_head));
            let v733_3: Space = intersect(&(*CONSTANT_12),&(v733_2));
            let v733_4: Space = if has_head(&(v733_3)) { singleton(&[]) } else { Space::new() };
            drop(v733_3);
            let v733_5: Space = subtract(&(*CONSTANT_0),&(v733_4));
            drop(v733_4);
            let v733_8: Space = if (v733_5).is_empty() { Space::new() } else {
              let v734_6: Path = concat_path(&(v732_6),&(v732_7_head));
              let v734_7: Space = routine_41(c, &(v734_6), &(v732_7_tail).make_space());
              compose(&(v733_5),&(v734_7))
            };
            drop(v733_5);
            let v733_9: Space = intersect(&(*CONSTANT_12),&(v733_2));
            drop(v733_2);
            let v733_10: Space = if has_head(&(v733_9)) { singleton(&[]) } else { Space::new() };
            drop(v733_9);
            let v733_12: Space = if (v733_10).is_empty() { Space::new() } else {
              let v735_6: Path = concat_path(&(v732_6),&(v732_7_head));
              let v735_11: Space = routine_42(c, &(v735_6), &(v732_7_tail).make_space());
              drop(v735_6);
              compose(&(v733_10),&(v735_11))
            };
            drop(v733_10);
            let v733_13: Space = unite(&(v733_8),&(v733_12));
            v732_7.join_into((v733_13).clone());
            }
            v732_7_cursor.ascend(1);
          }
          drop(v732_7_cursor);
          compose(&(v731_5),&(v732_7))
        };
        drop(v731_5);
        let v731_9: Space = intersect(&(*CONSTANT_12),&(v731_2));
        drop(v731_2);
        let v731_10: Space = if has_head(&(v731_9)) { singleton(&[]) } else { Space::new() };
        drop(v731_9);
        let v731_12: Space = if (v731_10).is_empty() { Space::new() } else {
          let v736_6: Path = concat_path(&(v728_23_head),&(v730_6_head));
          let mut v736_11 = Space::new();
          let mut v736_11_cursor = (v730_6_tail).read_zipper();
          for v736_11_byte in v736_11_cursor.child_mask().iter() {
            v736_11_cursor.descend_to_byte(v736_11_byte);
            {
            let v736_11_tail = v736_11_cursor.fork_read_zipper();
            let v736_11_head = Path::from_slice(&[v736_11_byte]);
            let v737_2: Space = singleton(&(v736_11_head));
            let v737_3: Space = intersect(&(*CONSTANT_12),&(v737_2));
            let v737_4: Space = if has_head(&(v737_3)) { singleton(&[]) } else { Space::new() };
            drop(v737_3);
            let v737_5: Space = subtract(&(*CONSTANT_0),&(v737_4));
            drop(v737_4);
            let v737_8: Space = if (v737_5).is_empty() { Space::new() } else {
              let v738_6: Path = concat_path(&(v736_6),&(v736_11_head));
              let v738_7: Space = routine_41(c, &(v738_6), &(v736_11_tail).make_space());
              compose(&(v737_5),&(v738_7))
            };
            drop(v737_5);
            let v737_9: Space = intersect(&(*CONSTANT_12),&(v737_2));
            drop(v737_2);
            let v737_10: Space = if has_head(&(v737_9)) { singleton(&[]) } else { Space::new() };
            drop(v737_9);
            let v737_12: Space = if (v737_10).is_empty() { Space::new() } else {
              let v739_6: Path = concat_path(&(v736_6),&(v736_11_head));
              let v739_11: Space = routine_43(c, &(v739_6), &(v736_11_tail).make_space());
              drop(v739_6);
              compose(&(v737_10),&(v739_11))
            };
            drop(v737_10);
            let v737_13: Space = unite(&(v737_8),&(v737_12));
            v736_11.join_into((v737_13).clone());
            }
            v736_11_cursor.ascend(1);
          }
          drop(v736_11_cursor);
          drop(v736_6);
          compose(&(v731_10),&(v736_11))
        };
        drop(v731_10);
        let v731_13: Space = unite(&(v731_8),&(v731_12));
        v730_6.join_into((v731_13).clone());
        }
        v730_6_cursor.ascend(1);
      }
      drop(v730_6_cursor);
      compose(&(v729_5),&(v730_6))
    };
    drop(v729_5);
    let v729_8: Space = intersect(&(*CONSTANT_12),&(v729_2));
    drop(v729_2);
    let v729_9: Space = if has_head(&(v729_8)) { singleton(&[]) } else { Space::new() };
    drop(v729_8);
    let v729_11: Space = if (v729_9).is_empty() { Space::new() } else {
      let mut v740_10 = Space::new();
      let mut v740_10_cursor = (v728_23_tail).read_zipper();
      for v740_10_byte in v740_10_cursor.child_mask().iter() {
        v740_10_cursor.descend_to_byte(v740_10_byte);
        {
        let v740_10_tail = v740_10_cursor.fork_read_zipper();
        let v740_10_head = Path::from_slice(&[v740_10_byte]);
        let v741_2: Space = singleton(&(v740_10_head));
        let v741_3: Space = intersect(&(*CONSTANT_12),&(v741_2));
        let v741_4: Space = if has_head(&(v741_3)) { singleton(&[]) } else { Space::new() };
        drop(v741_3);
        let v741_5: Space = subtract(&(*CONSTANT_0),&(v741_4));
        drop(v741_4);
        let v741_8: Space = if (v741_5).is_empty() { Space::new() } else {
          let v742_6: Path = concat_path(&(v728_23_head),&(v740_10_head));
          let mut v742_7 = Space::new();
          let mut v742_7_cursor = (v740_10_tail).read_zipper();
          for v742_7_byte in v742_7_cursor.child_mask().iter() {
            v742_7_cursor.descend_to_byte(v742_7_byte);
            {
            let v742_7_tail = v742_7_cursor.fork_read_zipper();
            let v742_7_head = Path::from_slice(&[v742_7_byte]);
            let v743_2: Space = singleton(&(v742_7_head));
            let v743_3: Space = intersect(&(*CONSTANT_12),&(v743_2));
            let v743_4: Space = if has_head(&(v743_3)) { singleton(&[]) } else { Space::new() };
            drop(v743_3);
            let v743_5: Space = subtract(&(*CONSTANT_0),&(v743_4));
            drop(v743_4);
            let v743_8: Space = if (v743_5).is_empty() { Space::new() } else {
              let v744_6: Path = concat_path(&(v742_6),&(v742_7_head));
              let v744_7: Space = routine_41(c, &(v744_6), &(v742_7_tail).make_space());
              compose(&(v743_5),&(v744_7))
            };
            drop(v743_5);
            let v743_9: Space = intersect(&(*CONSTANT_12),&(v743_2));
            drop(v743_2);
            let v743_10: Space = if has_head(&(v743_9)) { singleton(&[]) } else { Space::new() };
            drop(v743_9);
            let v743_12: Space = if (v743_10).is_empty() { Space::new() } else {
              let v745_6: Path = concat_path(&(v742_6),&(v742_7_head));
              let v745_11: Space = routine_42(c, &(v745_6), &(v742_7_tail).make_space());
              drop(v745_6);
              compose(&(v743_10),&(v745_11))
            };
            drop(v743_10);
            let v743_13: Space = unite(&(v743_8),&(v743_12));
            v742_7.join_into((v743_13).clone());
            }
            v742_7_cursor.ascend(1);
          }
          drop(v742_7_cursor);
          drop(v742_6);
          compose(&(v741_5),&(v742_7))
        };
        drop(v741_5);
        let v741_9: Space = intersect(&(*CONSTANT_12),&(v741_2));
        drop(v741_2);
        let v741_10: Space = if has_head(&(v741_9)) { singleton(&[]) } else { Space::new() };
        drop(v741_9);
        let v741_11: Space = compose(&(v741_10),&(v740_10_tail));
        drop(v741_10);
        let v741_12: Space = unite(&(v741_8),&(v741_11));
        drop(v741_11);
        v740_10.join_into((v741_12).clone());
        }
        v740_10_cursor.ascend(1);
      }
      drop(v740_10_cursor);
      compose(&(v729_9),&(v740_10))
    };
    drop(v729_9);
    let v729_12: Space = unite(&(v729_7),&(v729_11));
    v728_23.join_into((v729_12).clone());
    }
    v728_23_cursor.ascend(1);
  }
  drop(v728_23_cursor);
  drop(v728_4);
  let v728_24: Space = unite(&(v728_23),&(*s2));
  let v728_25: Space = intersect(&(v728_24),&(*s1));
  let mut v728_44: Space = (v728_25).clone();
  loop {
    let v746_1: Space = intersect(&(v728_44),&(*s1));
    let v746_2: Space = restrict_to(&(*s0),&(v746_1));
    drop(v746_1);
    let mut v746_3 = Space::new();
    let mut v746_3_cursor = (v746_2).read_zipper();
    for v746_3_byte in v746_3_cursor.child_mask().iter() {
      v746_3_cursor.descend_to_byte(v746_3_byte);
      {
      let v746_3_tail = v746_3_cursor.fork_read_zipper();
      let v746_3_head = Path::from_slice(&[v746_3_byte]);
      let v747_2: Space = singleton(&(v746_3_head));
      let v747_3: Space = intersect(&(*CONSTANT_12),&(v747_2));
      let v747_4: Space = if has_head(&(v747_3)) { singleton(&[]) } else { Space::new() };
      drop(v747_3);
      let v747_5: Space = subtract(&(*CONSTANT_0),&(v747_4));
      drop(v747_4);
      let v747_7: Space = if (v747_5).is_empty() { Space::new() } else {
        let mut v748_6 = Space::new();
        let mut v748_6_cursor = (v746_3_tail).read_zipper();
        for v748_6_byte in v748_6_cursor.child_mask().iter() {
          v748_6_cursor.descend_to_byte(v748_6_byte);
          {
          let v748_6_tail = v748_6_cursor.fork_read_zipper();
          let v748_6_head = Path::from_slice(&[v748_6_byte]);
          let v749_2: Space = singleton(&(v748_6_head));
          let v749_3: Space = intersect(&(*CONSTANT_12),&(v749_2));
          let v749_4: Space = if has_head(&(v749_3)) { singleton(&[]) } else { Space::new() };
          drop(v749_3);
          let v749_5: Space = subtract(&(*CONSTANT_0),&(v749_4));
          drop(v749_4);
          let v749_8: Space = if (v749_5).is_empty() { Space::new() } else {
            let v750_6: Path = concat_path(&(v746_3_head),&(v748_6_head));
            let mut v750_7 = Space::new();
            let mut v750_7_cursor = (v748_6_tail).read_zipper();
            for v750_7_byte in v750_7_cursor.child_mask().iter() {
              v750_7_cursor.descend_to_byte(v750_7_byte);
              {
              let v750_7_tail = v750_7_cursor.fork_read_zipper();
              let v750_7_head = Path::from_slice(&[v750_7_byte]);
              let v751_2: Space = singleton(&(v750_7_head));
              let v751_3: Space = intersect(&(*CONSTANT_12),&(v751_2));
              let v751_4: Space = if has_head(&(v751_3)) { singleton(&[]) } else { Space::new() };
              drop(v751_3);
              let v751_5: Space = subtract(&(*CONSTANT_0),&(v751_4));
              drop(v751_4);
              let v751_8: Space = if (v751_5).is_empty() { Space::new() } else {
                let v752_6: Path = concat_path(&(v750_6),&(v750_7_head));
                let v752_7: Space = routine_41(c, &(v752_6), &(v750_7_tail).make_space());
                compose(&(v751_5),&(v752_7))
              };
              drop(v751_5);
              let v751_9: Space = intersect(&(*CONSTANT_12),&(v751_2));
              drop(v751_2);
              let v751_10: Space = if has_head(&(v751_9)) { singleton(&[]) } else { Space::new() };
              drop(v751_9);
              let v751_12: Space = if (v751_10).is_empty() { Space::new() } else {
                let v753_6: Path = concat_path(&(v750_6),&(v750_7_head));
                let v753_11: Space = routine_42(c, &(v753_6), &(v750_7_tail).make_space());
                drop(v753_6);
                compose(&(v751_10),&(v753_11))
              };
              drop(v751_10);
              let v751_13: Space = unite(&(v751_8),&(v751_12));
              v750_7.join_into((v751_13).clone());
              }
              v750_7_cursor.ascend(1);
            }
            drop(v750_7_cursor);
            compose(&(v749_5),&(v750_7))
          };
          drop(v749_5);
          let v749_9: Space = intersect(&(*CONSTANT_12),&(v749_2));
          drop(v749_2);
          let v749_10: Space = if has_head(&(v749_9)) { singleton(&[]) } else { Space::new() };
          drop(v749_9);
          let v749_12: Space = if (v749_10).is_empty() { Space::new() } else {
            let v754_6: Path = concat_path(&(v746_3_head),&(v748_6_head));
            let mut v754_11 = Space::new();
            let mut v754_11_cursor = (v748_6_tail).read_zipper();
            for v754_11_byte in v754_11_cursor.child_mask().iter() {
              v754_11_cursor.descend_to_byte(v754_11_byte);
              {
              let v754_11_tail = v754_11_cursor.fork_read_zipper();
              let v754_11_head = Path::from_slice(&[v754_11_byte]);
              let v755_2: Space = singleton(&(v754_11_head));
              let v755_3: Space = intersect(&(*CONSTANT_12),&(v755_2));
              let v755_4: Space = if has_head(&(v755_3)) { singleton(&[]) } else { Space::new() };
              drop(v755_3);
              let v755_5: Space = subtract(&(*CONSTANT_0),&(v755_4));
              drop(v755_4);
              let v755_8: Space = if (v755_5).is_empty() { Space::new() } else {
                let v756_6: Path = concat_path(&(v754_6),&(v754_11_head));
                let v756_7: Space = routine_41(c, &(v756_6), &(v754_11_tail).make_space());
                compose(&(v755_5),&(v756_7))
              };
              drop(v755_5);
              let v755_9: Space = intersect(&(*CONSTANT_12),&(v755_2));
              drop(v755_2);
              let v755_10: Space = if has_head(&(v755_9)) { singleton(&[]) } else { Space::new() };
              drop(v755_9);
              let v755_12: Space = if (v755_10).is_empty() { Space::new() } else {
                let v757_6: Path = concat_path(&(v754_6),&(v754_11_head));
                let v757_11: Space = routine_43(c, &(v757_6), &(v754_11_tail).make_space());
                drop(v757_6);
                compose(&(v755_10),&(v757_11))
              };
              drop(v755_10);
              let v755_13: Space = unite(&(v755_8),&(v755_12));
              v754_11.join_into((v755_13).clone());
              }
              v754_11_cursor.ascend(1);
            }
            drop(v754_11_cursor);
            drop(v754_6);
            compose(&(v749_10),&(v754_11))
          };
          drop(v749_10);
          let v749_13: Space = unite(&(v749_8),&(v749_12));
          v748_6.join_into((v749_13).clone());
          }
          v748_6_cursor.ascend(1);
        }
        drop(v748_6_cursor);
        compose(&(v747_5),&(v748_6))
      };
      drop(v747_5);
      let v747_8: Space = intersect(&(*CONSTANT_12),&(v747_2));
      drop(v747_2);
      let v747_9: Space = if has_head(&(v747_8)) { singleton(&[]) } else { Space::new() };
      drop(v747_8);
      let v747_11: Space = if (v747_9).is_empty() { Space::new() } else {
        let mut v758_10 = Space::new();
        let mut v758_10_cursor = (v746_3_tail).read_zipper();
        for v758_10_byte in v758_10_cursor.child_mask().iter() {
          v758_10_cursor.descend_to_byte(v758_10_byte);
          {
          let v758_10_tail = v758_10_cursor.fork_read_zipper();
          let v758_10_head = Path::from_slice(&[v758_10_byte]);
          let v759_2: Space = singleton(&(v758_10_head));
          let v759_3: Space = intersect(&(*CONSTANT_12),&(v759_2));
          let v759_4: Space = if has_head(&(v759_3)) { singleton(&[]) } else { Space::new() };
          drop(v759_3);
          let v759_5: Space = subtract(&(*CONSTANT_0),&(v759_4));
          drop(v759_4);
          let v759_8: Space = if (v759_5).is_empty() { Space::new() } else {
            let v760_6: Path = concat_path(&(v746_3_head),&(v758_10_head));
            let mut v760_7 = Space::new();
            let mut v760_7_cursor = (v758_10_tail).read_zipper();
            for v760_7_byte in v760_7_cursor.child_mask().iter() {
              v760_7_cursor.descend_to_byte(v760_7_byte);
              {
              let v760_7_tail = v760_7_cursor.fork_read_zipper();
              let v760_7_head = Path::from_slice(&[v760_7_byte]);
              let v761_2: Space = singleton(&(v760_7_head));
              let v761_3: Space = intersect(&(*CONSTANT_12),&(v761_2));
              let v761_4: Space = if has_head(&(v761_3)) { singleton(&[]) } else { Space::new() };
              drop(v761_3);
              let v761_5: Space = subtract(&(*CONSTANT_0),&(v761_4));
              drop(v761_4);
              let v761_8: Space = if (v761_5).is_empty() { Space::new() } else {
                let v762_6: Path = concat_path(&(v760_6),&(v760_7_head));
                let v762_7: Space = routine_41(c, &(v762_6), &(v760_7_tail).make_space());
                compose(&(v761_5),&(v762_7))
              };
              drop(v761_5);
              let v761_9: Space = intersect(&(*CONSTANT_12),&(v761_2));
              drop(v761_2);
              let v761_10: Space = if has_head(&(v761_9)) { singleton(&[]) } else { Space::new() };
              drop(v761_9);
              let v761_12: Space = if (v761_10).is_empty() { Space::new() } else {
                let v763_6: Path = concat_path(&(v760_6),&(v760_7_head));
                let v763_11: Space = routine_42(c, &(v763_6), &(v760_7_tail).make_space());
                drop(v763_6);
                compose(&(v761_10),&(v763_11))
              };
              drop(v761_10);
              let v761_13: Space = unite(&(v761_8),&(v761_12));
              v760_7.join_into((v761_13).clone());
              }
              v760_7_cursor.ascend(1);
            }
            drop(v760_7_cursor);
            drop(v760_6);
            compose(&(v759_5),&(v760_7))
          };
          drop(v759_5);
          let v759_9: Space = intersect(&(*CONSTANT_12),&(v759_2));
          drop(v759_2);
          let v759_10: Space = if has_head(&(v759_9)) { singleton(&[]) } else { Space::new() };
          drop(v759_9);
          let v759_11: Space = compose(&(v759_10),&(v758_10_tail));
          drop(v759_10);
          let v759_12: Space = unite(&(v759_8),&(v759_11));
          drop(v759_11);
          v758_10.join_into((v759_12).clone());
          }
          v758_10_cursor.ascend(1);
        }
        drop(v758_10_cursor);
        compose(&(v747_9),&(v758_10))
      };
      drop(v747_9);
      let v747_12: Space = unite(&(v747_7),&(v747_11));
      v746_3.join_into((v747_12).clone());
      }
      v746_3_cursor.ascend(1);
    }
    drop(v746_3_cursor);
    drop(v746_2);
    let v746_4: Space = unite(&(v746_3),&(v728_44));
    let v746_5: Space = intersect(&(v746_4),&(*s1));
    if !v728_44.join_into((v746_5).clone()).is_element() { break; }
  }
  let v728_45: Space = unite(&(*s2),&(v728_44));
  (v728_45).clone()
}

fn routine_39(c: &mut Context, s0: &Space, s1: &Space, s2: &Space) -> Space {
  let v764_3: Space = if has_head(&(*s2)) { singleton(&[]) } else { Space::new() };
  let v764_4: Space = first_matching(&(*s2),&(*CONSTANT_0),false);
  let v764_5: Space = unite(&(v764_3),&(v764_4));
  drop(v764_3);
  drop(v764_4);
  let v764_8: Space = if (v764_5).is_empty() { Space::new() } else {
    let v765_6: Space = routine_26(c, &(*s2));
    let v765_7: Space = subtract(&(*s2),&(v765_6));
    compose(&(v764_5),&(v765_7))
  };
  drop(v764_5);
  let v764_9: Space = subtract(&(*s2),&(v764_8));
  let mut v764_19 = Space::new();
  let mut v764_19_cursor = (v764_9).read_zipper();
  for v764_19_byte in v764_19_cursor.child_mask().iter() {
    v764_19_cursor.descend_to_byte(v764_19_byte);
    {
    let v764_19_tail = v764_19_cursor.fork_read_zipper();
    let v764_19_head = Path::from_slice(&[v764_19_byte]);
    let v766_2: Space = singleton(&(v764_19_head));
    let v766_3: Space = intersect(&(*CONSTANT_12),&(v766_2));
    let v766_4: Space = if has_head(&(v766_3)) { singleton(&[]) } else { Space::new() };
    drop(v766_3);
    let v766_5: Space = subtract(&(*CONSTANT_0),&(v766_4));
    drop(v766_4);
    let v766_7: Space = if (v766_5).is_empty() { Space::new() } else {
      let mut v767_6 = Space::new();
      let mut v767_6_cursor = (v764_19_tail).read_zipper();
      for v767_6_byte in v767_6_cursor.child_mask().iter() {
        v767_6_cursor.descend_to_byte(v767_6_byte);
        {
        let v767_6_tail = v767_6_cursor.fork_read_zipper();
        let v767_6_head = Path::from_slice(&[v767_6_byte]);
        let v768_2: Space = singleton(&(v767_6_head));
        let v768_3: Space = intersect(&(*CONSTANT_12),&(v768_2));
        let v768_4: Space = if has_head(&(v768_3)) { singleton(&[]) } else { Space::new() };
        drop(v768_3);
        let v768_5: Space = subtract(&(*CONSTANT_0),&(v768_4));
        drop(v768_4);
        let v768_8: Space = if (v768_5).is_empty() { Space::new() } else {
          let v769_6: Path = concat_path(&(v764_19_head),&(v767_6_head));
          let v769_7: Space = routine_44(c, &(v769_6), &(v767_6_tail).make_space(), &(*s1), &(*s0), &(*s2));
          compose(&(v768_5),&(v769_7))
        };
        drop(v768_5);
        let v768_9: Space = intersect(&(*CONSTANT_12),&(v768_2));
        drop(v768_2);
        let v768_10: Space = if has_head(&(v768_9)) { singleton(&[]) } else { Space::new() };
        drop(v768_9);
        let v768_12: Space = if (v768_10).is_empty() { Space::new() } else {
          let v770_6: Path = concat_path(&(v764_19_head),&(v767_6_head));
          let v770_11: Space = routine_45(c, &(v770_6), &(v767_6_tail).make_space(), &(*s1), &(*s0), &(*s2));
          drop(v770_6);
          compose(&(v768_10),&(v770_11))
        };
        drop(v768_10);
        let v768_13: Space = unite(&(v768_8),&(v768_12));
        v767_6.join_into((v768_13).clone());
        }
        v767_6_cursor.ascend(1);
      }
      drop(v767_6_cursor);
      compose(&(v766_5),&(v767_6))
    };
    drop(v766_5);
    let v766_8: Space = intersect(&(*CONSTANT_12),&(v766_2));
    drop(v766_2);
    let v766_9: Space = if has_head(&(v766_8)) { singleton(&[]) } else { Space::new() };
    drop(v766_8);
    let v766_11: Space = if (v766_9).is_empty() { Space::new() } else {
      let mut v771_10 = Space::new();
      let mut v771_10_cursor = (v764_19_tail).read_zipper();
      for v771_10_byte in v771_10_cursor.child_mask().iter() {
        v771_10_cursor.descend_to_byte(v771_10_byte);
        {
        let v771_10_tail = v771_10_cursor.fork_read_zipper();
        let v771_10_head = Path::from_slice(&[v771_10_byte]);
        let v772_2: Space = singleton(&(v771_10_head));
        let v772_3: Space = intersect(&(*CONSTANT_12),&(v772_2));
        let v772_4: Space = if has_head(&(v772_3)) { singleton(&[]) } else { Space::new() };
        drop(v772_3);
        let v772_5: Space = subtract(&(*CONSTANT_0),&(v772_4));
        drop(v772_4);
        let v772_8: Space = if (v772_5).is_empty() { Space::new() } else {
          let v773_6: Path = concat_path(&(v764_19_head),&(v771_10_head));
          let v773_7: Space = routine_44(c, &(v773_6), &(v771_10_tail).make_space(), &(*s1), &(*s0), &(*s2));
          compose(&(v772_5),&(v773_7))
        };
        drop(v772_5);
        let v772_9: Space = intersect(&(*CONSTANT_12),&(v772_2));
        drop(v772_2);
        let v772_10: Space = if has_head(&(v772_9)) { singleton(&[]) } else { Space::new() };
        drop(v772_9);
        let v772_12: Space = if (v772_10).is_empty() { Space::new() } else {
          let v774_6: Path = concat_path(&(v764_19_head),&(v771_10_head));
          let v774_11: Space = routine_37(c, &(v774_6), &(v771_10_tail).make_space(), &(*s1), &(*s0), &(*s2));
          drop(v774_6);
          compose(&(v772_10),&(v774_11))
        };
        drop(v772_10);
        let v772_13: Space = unite(&(v772_8),&(v772_12));
        v771_10.join_into((v772_13).clone());
        }
        v771_10_cursor.ascend(1);
      }
      drop(v771_10_cursor);
      compose(&(v766_9),&(v771_10))
    };
    drop(v766_9);
    let v766_12: Space = unite(&(v766_7),&(v766_11));
    v764_19.join_into((v766_12).clone());
    }
    v764_19_cursor.ascend(1);
  }
  drop(v764_19_cursor);
  (v764_19).clone()
}

fn routine_40(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let v775_3: Space = unwrap(&(*s0),&(*p0));
  let v775_4: Space = first_matching(&(v775_3),&(*CONSTANT_0),false);
  let v775_5: Space = intersect(&(*CONSTANT_0),&(v775_4));
  let v775_6: Space = if has_head(&(v775_4)) { singleton(&[]) } else { Space::new() };
  let v775_7: Space = unite(&(v775_5),&(v775_6));
  drop(v775_5);
  let v775_9: Space = compose(&(v775_7),&(*CONSTANT_0));
  drop(v775_7);
  let v775_11: Space = subtract(&(*CONSTANT_0),&(v775_4));
  drop(v775_4);
  let v775_12: Space = subtract(&(v775_11),&(v775_6));
  drop(v775_6);
  drop(v775_11);
  let v775_16: Space = if (v775_12).is_empty() { Space::new() } else {
    let v776_14: Space = first_fibonacci(&(v775_3),6,5,true);
    let mut v776_15 = Space::new();
    let v776_15_arg_0: &Path = &(*CONSTANT_14);
    let v776_15_arg_1: &Space = &(v776_14);
    let v776_15_arg_2: &Space = &(v775_3);
    let mut v776_15_cursor = v776_15_arg_1.read_zipper();
    let mut v776_15_more = v776_15_cursor.is_val() || v776_15_cursor.to_next_val();
    while v776_15_more {
      {
      let v776_15_path = concat_path(v776_15_arg_0,v776_15_cursor.path());
      let v776_15_rest = v776_15_cursor.fork_read_zipper();
      let v777_3: Space = routine_40(c, &(v776_15_path), &(*v776_15_arg_2));
      v776_15.join_into((v777_3).clone());
      }
      v776_15_more = v776_15_cursor.to_next_val();
    }
    drop(v776_15_cursor);
    drop(v776_14);
    compose(&(v775_12),&(v776_15))
  };
  drop(v775_12);
  let v775_17: Space = unite(&(v775_9),&(v775_16));
  drop(v775_9);
  let v775_18: Space = wrap(&(v775_17),&(*p0));
  (v775_18).clone()
}

fn routine_41(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v778_6 = Space::new();
  let mut v778_6_cursor = (*s0).read_zipper();
  for v778_6_byte in v778_6_cursor.child_mask().iter() {
    v778_6_cursor.descend_to_byte(v778_6_byte);
    {
    let v778_6_tail = v778_6_cursor.fork_read_zipper();
    let v778_6_head = Path::from_slice(&[v778_6_byte]);
    let v779_2: Space = singleton(&(v778_6_head));
    let v779_3: Space = intersect(&(*CONSTANT_12),&(v779_2));
    let v779_4: Space = if has_head(&(v779_3)) { singleton(&[]) } else { Space::new() };
    drop(v779_3);
    let v779_5: Space = subtract(&(*CONSTANT_0),&(v779_4));
    drop(v779_4);
    let mut v779_6 = Space::new();
    let mut v779_6_cursor = (v778_6_tail).read_zipper();
    for v779_6_byte in v779_6_cursor.child_mask().iter() {
      v779_6_cursor.descend_to_byte(v779_6_byte);
      {
      let v779_6_tail = v779_6_cursor.fork_read_zipper();
      let v779_6_head = Path::from_slice(&[v779_6_byte]);
      let v780_2: Space = Space::new();
      v779_6.join_into((v780_2).clone());
      }
      v779_6_cursor.ascend(1);
    }
    drop(v779_6_cursor);
    let v779_7: Space = compose(&(v779_5),&(v779_6));
    drop(v779_5);
    drop(v779_6);
    let v779_8: Space = intersect(&(*CONSTANT_12),&(v779_2));
    drop(v779_2);
    let v779_9: Space = if has_head(&(v779_8)) { singleton(&[]) } else { Space::new() };
    drop(v779_8);
    let mut v779_10 = Space::new();
    let mut v779_10_cursor = (v778_6_tail).read_zipper();
    for v779_10_byte in v779_10_cursor.child_mask().iter() {
      v779_10_cursor.descend_to_byte(v779_10_byte);
      {
      let v779_10_tail = v779_10_cursor.fork_read_zipper();
      let v779_10_head = Path::from_slice(&[v779_10_byte]);
      let v781_2: Space = singleton(&(v779_10_head));
      let v781_3: Space = intersect(&(*CONSTANT_12),&(v781_2));
      drop(v781_2);
      let v781_4: Space = if has_head(&(v781_3)) { singleton(&[]) } else { Space::new() };
      drop(v781_3);
      let v781_5: Space = compose(&(v781_4),&(v779_10_tail));
      drop(v781_4);
      v779_10.join_into((v781_5).clone());
      }
      v779_10_cursor.ascend(1);
    }
    drop(v779_10_cursor);
    let v779_11: Space = compose(&(v779_9),&(v779_10));
    drop(v779_9);
    drop(v779_10);
    let v779_12: Space = unite(&(v779_7),&(v779_11));
    drop(v779_7);
    drop(v779_11);
    v778_6.join_into((v779_12).clone());
    }
    v778_6_cursor.ascend(1);
  }
  drop(v778_6_cursor);
  (v778_6).clone()
}

fn routine_42(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v782_5 = Space::new();
  let mut v782_5_cursor = (*s0).read_zipper();
  for v782_5_byte in v782_5_cursor.child_mask().iter() {
    v782_5_cursor.descend_to_byte(v782_5_byte);
    {
    let v782_5_tail = v782_5_cursor.fork_read_zipper();
    let v782_5_head = Path::from_slice(&[v782_5_byte]);
    let v783_2: Space = singleton(&(v782_5_head));
    let v783_3: Space = intersect(&(*CONSTANT_12),&(v783_2));
    let v783_4: Space = if has_head(&(v783_3)) { singleton(&[]) } else { Space::new() };
    drop(v783_3);
    let v783_5: Space = subtract(&(*CONSTANT_0),&(v783_4));
    drop(v783_4);
    let mut v783_6 = Space::new();
    let mut v783_6_cursor = (v782_5_tail).read_zipper();
    for v783_6_byte in v783_6_cursor.child_mask().iter() {
      v783_6_cursor.descend_to_byte(v783_6_byte);
      {
      let v783_6_tail = v783_6_cursor.fork_read_zipper();
      let v783_6_head = Path::from_slice(&[v783_6_byte]);
      let v784_2: Space = Space::new();
      v783_6.join_into((v784_2).clone());
      }
      v783_6_cursor.ascend(1);
    }
    drop(v783_6_cursor);
    let v783_7: Space = compose(&(v783_5),&(v783_6));
    drop(v783_5);
    drop(v783_6);
    let v783_8: Space = intersect(&(*CONSTANT_12),&(v783_2));
    drop(v783_2);
    let v783_9: Space = if has_head(&(v783_8)) { singleton(&[]) } else { Space::new() };
    drop(v783_8);
    let v783_10: Space = compose(&(v783_9),&(v782_5_tail));
    drop(v783_9);
    let v783_11: Space = unite(&(v783_7),&(v783_10));
    drop(v783_7);
    drop(v783_10);
    v782_5.join_into((v783_11).clone());
    }
    v782_5_cursor.ascend(1);
  }
  drop(v782_5_cursor);
  (v782_5).clone()
}

fn routine_43(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v786_14 = Space::new();
  let mut v786_14_cursor = (*s0).read_zipper();
  for v786_14_byte in v786_14_cursor.child_mask().iter() {
    v786_14_cursor.descend_to_byte(v786_14_byte);
    {
    let v786_14_tail = v786_14_cursor.fork_read_zipper();
    let v786_14_head = Path::from_slice(&[v786_14_byte]);
    let v787_2: Space = singleton(&(v786_14_head));
    let v787_3: Space = intersect(&(*CONSTANT_12),&(v787_2));
    let v787_4: Space = if has_head(&(v787_3)) { singleton(&[]) } else { Space::new() };
    drop(v787_3);
    let v787_5: Space = subtract(&(*CONSTANT_0),&(v787_4));
    drop(v787_4);
    let v787_8: Space = if (v787_5).is_empty() { Space::new() } else {
      let v788_6: Path = concat_path(&(*p0),&(v786_14_head));
      let mut v788_7 = Space::new();
      let mut v788_7_cursor = (v786_14_tail).read_zipper();
      for v788_7_byte in v788_7_cursor.child_mask().iter() {
        v788_7_cursor.descend_to_byte(v788_7_byte);
        {
        let v788_7_tail = v788_7_cursor.fork_read_zipper();
        let v788_7_head = Path::from_slice(&[v788_7_byte]);
        let v789_2: Space = singleton(&(v788_7_head));
        let v789_3: Space = intersect(&(*CONSTANT_12),&(v789_2));
        let v789_4: Space = if has_head(&(v789_3)) { singleton(&[]) } else { Space::new() };
        drop(v789_3);
        let v789_5: Space = subtract(&(*CONSTANT_0),&(v789_4));
        drop(v789_4);
        let mut v789_6 = Space::new();
        let mut v789_6_cursor = (v788_7_tail).read_zipper();
        for v789_6_byte in v789_6_cursor.child_mask().iter() {
          v789_6_cursor.descend_to_byte(v789_6_byte);
          {
          let v789_6_tail = v789_6_cursor.fork_read_zipper();
          let v789_6_head = Path::from_slice(&[v789_6_byte]);
          let v790_2: Space = Space::new();
          v789_6.join_into((v790_2).clone());
          }
          v789_6_cursor.ascend(1);
        }
        drop(v789_6_cursor);
        let v789_7: Space = compose(&(v789_5),&(v789_6));
        drop(v789_5);
        drop(v789_6);
        let v789_8: Space = intersect(&(*CONSTANT_12),&(v789_2));
        drop(v789_2);
        let v789_9: Space = if has_head(&(v789_8)) { singleton(&[]) } else { Space::new() };
        drop(v789_8);
        let v789_12: Space = if (v789_9).is_empty() { Space::new() } else {
          let v791_10: Path = concat_path(&(v788_6),&(v788_7_head));
          let v791_11: Space = routine_46(c, &(v791_10), &(v788_7_tail).make_space(), &(*s1), &(*s2), &(*s3));
          drop(v791_10);
          compose(&(v789_9),&(v791_11))
        };
        drop(v789_9);
        let v789_13: Space = unite(&(v789_7),&(v789_12));
        drop(v789_7);
        v788_7.join_into((v789_13).clone());
        }
        v788_7_cursor.ascend(1);
      }
      drop(v788_7_cursor);
      compose(&(v787_5),&(v788_7))
    };
    drop(v787_5);
    let v787_9: Space = intersect(&(*CONSTANT_12),&(v787_2));
    drop(v787_2);
    let v787_10: Space = if has_head(&(v787_9)) { singleton(&[]) } else { Space::new() };
    drop(v787_9);
    let v787_12: Space = if (v787_10).is_empty() { Space::new() } else {
      let v792_6: Path = concat_path(&(*p0),&(v786_14_head));
      let mut v792_11 = Space::new();
      let mut v792_11_cursor = (v786_14_tail).read_zipper();
      for v792_11_byte in v792_11_cursor.child_mask().iter() {
        v792_11_cursor.descend_to_byte(v792_11_byte);
        {
        let v792_11_tail = v792_11_cursor.fork_read_zipper();
        let v792_11_head = Path::from_slice(&[v792_11_byte]);
        let v793_2: Space = singleton(&(v792_11_head));
        let v793_3: Space = intersect(&(*CONSTANT_12),&(v793_2));
        let v793_4: Space = if has_head(&(v793_3)) { singleton(&[]) } else { Space::new() };
        drop(v793_3);
        let v793_5: Space = subtract(&(*CONSTANT_0),&(v793_4));
        drop(v793_4);
        let mut v793_6 = Space::new();
        let mut v793_6_cursor = (v792_11_tail).read_zipper();
        for v793_6_byte in v793_6_cursor.child_mask().iter() {
          v793_6_cursor.descend_to_byte(v793_6_byte);
          {
          let v793_6_tail = v793_6_cursor.fork_read_zipper();
          let v793_6_head = Path::from_slice(&[v793_6_byte]);
          let v794_2: Space = Space::new();
          v793_6.join_into((v794_2).clone());
          }
          v793_6_cursor.ascend(1);
        }
        drop(v793_6_cursor);
        let v793_7: Space = compose(&(v793_5),&(v793_6));
        drop(v793_5);
        drop(v793_6);
        let v793_8: Space = intersect(&(*CONSTANT_12),&(v793_2));
        drop(v793_2);
        let v793_9: Space = if has_head(&(v793_8)) { singleton(&[]) } else { Space::new() };
        drop(v793_8);
        let v793_12: Space = if (v793_9).is_empty() { Space::new() } else {
          let v795_10: Path = concat_path(&(v792_6),&(v792_11_head));
          let v795_11: Space = routine_37(c, &(v795_10), &(v792_11_tail).make_space(), &(*s1), &(*s2), &(*s3));
          drop(v795_10);
          compose(&(v793_9),&(v795_11))
        };
        drop(v793_9);
        let v793_13: Space = unite(&(v793_7),&(v793_12));
        drop(v793_7);
        v792_11.join_into((v793_13).clone());
        }
        v792_11_cursor.ascend(1);
      }
      drop(v792_11_cursor);
      drop(v792_6);
      compose(&(v787_10),&(v792_11))
    };
    drop(v787_10);
    let v787_13: Space = unite(&(v787_8),&(v787_12));
    v786_14.join_into((v787_13).clone());
    }
    v786_14_cursor.ascend(1);
  }
  drop(v786_14_cursor);
  (v786_14).clone()
}

fn routine_45(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v796_11 = Space::new();
  let mut v796_11_cursor = (*s0).read_zipper();
  for v796_11_byte in v796_11_cursor.child_mask().iter() {
    v796_11_cursor.descend_to_byte(v796_11_byte);
    {
    let v796_11_tail = v796_11_cursor.fork_read_zipper();
    let v796_11_head = Path::from_slice(&[v796_11_byte]);
    let v797_2: Space = singleton(&(v796_11_head));
    let v797_3: Space = intersect(&(*CONSTANT_12),&(v797_2));
    let v797_4: Space = if has_head(&(v797_3)) { singleton(&[]) } else { Space::new() };
    drop(v797_3);
    let v797_5: Space = subtract(&(*CONSTANT_0),&(v797_4));
    drop(v797_4);
    let v797_8: Space = if (v797_5).is_empty() { Space::new() } else {
      let v798_6: Path = concat_path(&(*p0),&(v796_11_head));
      let mut v798_7 = Space::new();
      let mut v798_7_cursor = (v796_11_tail).read_zipper();
      for v798_7_byte in v798_7_cursor.child_mask().iter() {
        v798_7_cursor.descend_to_byte(v798_7_byte);
        {
        let v798_7_tail = v798_7_cursor.fork_read_zipper();
        let v798_7_head = Path::from_slice(&[v798_7_byte]);
        let v799_2: Space = singleton(&(v798_7_head));
        let v799_3: Space = intersect(&(*CONSTANT_12),&(v799_2));
        let v799_4: Space = if has_head(&(v799_3)) { singleton(&[]) } else { Space::new() };
        drop(v799_3);
        let v799_5: Space = subtract(&(*CONSTANT_0),&(v799_4));
        drop(v799_4);
        let mut v799_6 = Space::new();
        let mut v799_6_cursor = (v798_7_tail).read_zipper();
        for v799_6_byte in v799_6_cursor.child_mask().iter() {
          v799_6_cursor.descend_to_byte(v799_6_byte);
          {
          let v799_6_tail = v799_6_cursor.fork_read_zipper();
          let v799_6_head = Path::from_slice(&[v799_6_byte]);
          let v800_2: Space = Space::new();
          v799_6.join_into((v800_2).clone());
          }
          v799_6_cursor.ascend(1);
        }
        drop(v799_6_cursor);
        let v799_7: Space = compose(&(v799_5),&(v799_6));
        drop(v799_5);
        drop(v799_6);
        let v799_8: Space = intersect(&(*CONSTANT_12),&(v799_2));
        drop(v799_2);
        let v799_9: Space = if has_head(&(v799_8)) { singleton(&[]) } else { Space::new() };
        drop(v799_8);
        let v799_12: Space = if (v799_9).is_empty() { Space::new() } else {
          let v801_10: Path = concat_path(&(v798_6),&(v798_7_head));
          let v801_11: Space = routine_46(c, &(v801_10), &(v798_7_tail).make_space(), &(*s1), &(*s2), &(*s3));
          drop(v801_10);
          compose(&(v799_9),&(v801_11))
        };
        drop(v799_9);
        let v799_13: Space = unite(&(v799_7),&(v799_12));
        drop(v799_7);
        v798_7.join_into((v799_13).clone());
        }
        v798_7_cursor.ascend(1);
      }
      drop(v798_7_cursor);
      compose(&(v797_5),&(v798_7))
    };
    drop(v797_5);
    let v797_9: Space = intersect(&(*CONSTANT_12),&(v797_2));
    drop(v797_2);
    let v797_10: Space = if has_head(&(v797_9)) { singleton(&[]) } else { Space::new() };
    drop(v797_9);
    let v797_27: Space = if (v797_10).is_empty() { Space::new() } else {
      let v802_6: Path = concat_path(&(*p0),&(v796_11_head));
      let v802_11: Space = singleton(&(v802_6));
      let v802_12: Space = routine_38(c, &(*s1), &(*s3), &(v802_11));
      let v802_13: Space = routine_38(c, &(*s2), &(*s3), &(v802_11));
      let v802_14: Space = intersect(&(v802_12),&(v802_13));
      let v802_15: Space = subtract(&(v802_14),&(v802_11));
      drop(v802_11);
      let v802_16: Space = wrap(&(v802_15),&(v802_6));
      drop(v802_6);
      let v802_17: Space = subtract(&(*s3),&(v802_13));
      let v802_18: Space = subtract(&(v802_17),&(v802_12));
      let v802_19: Space = routine_39(c, &(*s2), &(*s1), &(v802_18));
      let v802_20: Space = unite(&(v802_16),&(v802_19));
      let v802_21: Space = subtract(&(v802_12),&(v802_13));
      let v802_22: Space = routine_39(c, &(*s2), &(*s1), &(v802_21));
      let v802_23: Space = unite(&(v802_20),&(v802_22));
      let v802_24: Space = subtract(&(v802_13),&(v802_12));
      let v802_25: Space = routine_39(c, &(*s2), &(*s1), &(v802_24));
      let v802_26: Space = unite(&(v802_23),&(v802_25));
      compose(&(v797_10),&(v802_26))
    };
    drop(v797_10);
    let v797_28: Space = unite(&(v797_8),&(v797_27));
    v796_11.join_into((v797_28).clone());
    }
    v796_11_cursor.ascend(1);
  }
  drop(v796_11_cursor);
  (v796_11).clone()
}

fn routine_46(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v803_6 = Space::new();
  let mut v803_6_cursor = (*s0).read_zipper();
  for v803_6_byte in v803_6_cursor.child_mask().iter() {
    v803_6_cursor.descend_to_byte(v803_6_byte);
    {
    let v803_6_tail = v803_6_cursor.fork_read_zipper();
    let v803_6_head = Path::from_slice(&[v803_6_byte]);
    let v804_2: Space = singleton(&(v803_6_head));
    let v804_3: Space = intersect(&(*CONSTANT_12),&(v804_2));
    drop(v804_2);
    let v804_4: Space = if has_head(&(v804_3)) { singleton(&[]) } else { Space::new() };
    drop(v804_3);
    let v804_22: Space = if (v804_4).is_empty() { Space::new() } else {
      let v805_5: Path = concat_path(&(*p0),&(v803_6_head));
      let v805_6: Space = singleton(&(v805_5));
      let v805_7: Space = routine_38(c, &(*s1), &(*s3), &(v805_6));
      let v805_8: Space = routine_38(c, &(*s2), &(*s3), &(v805_6));
      let v805_9: Space = intersect(&(v805_7),&(v805_8));
      let v805_10: Space = subtract(&(v805_9),&(v805_6));
      drop(v805_6);
      let v805_11: Space = wrap(&(v805_10),&(v805_5));
      drop(v805_5);
      let v805_12: Space = subtract(&(*s3),&(v805_8));
      let v805_13: Space = subtract(&(v805_12),&(v805_7));
      let v805_14: Space = routine_39(c, &(*s2), &(*s1), &(v805_13));
      let v805_15: Space = unite(&(v805_11),&(v805_14));
      let v805_16: Space = subtract(&(v805_7),&(v805_8));
      let v805_17: Space = routine_39(c, &(*s2), &(*s1), &(v805_16));
      let v805_18: Space = unite(&(v805_15),&(v805_17));
      let v805_19: Space = subtract(&(v805_8),&(v805_7));
      let v805_20: Space = routine_39(c, &(*s2), &(*s1), &(v805_19));
      let v805_21: Space = unite(&(v805_18),&(v805_20));
      compose(&(v804_4),&(v805_21))
    };
    drop(v804_4);
    v803_6.join_into((v804_22).clone());
    }
    v803_6_cursor.ascend(1);
  }
  drop(v803_6_cursor);
  (v803_6).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
