#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[97]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[98,0]));
static CONSTANT_3: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[98]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[97,0]));
static CONSTANT_6: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[99]));
static CONSTANT_7: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[100,0]));
static CONSTANT_8: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[100]));
static CONSTANT_9: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[99,0]));
static CONSTANT_10: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[102]));
static CONSTANT_11: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[101,0]));
static CONSTANT_12: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("5 2 97 0 2 98 0 2 99 0 2 100 0 2 101 0"));
static CONSTANT_13: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("6 4 97 0 98 0 4 98 0 97 0 4 98 0 99 0 4 99 0 100 0 4 100 0 99 0 4 101 0 102 0"));
#[inline(never)]
fn native_block_0(c: &mut Context,capture_0: &Path,capture_1: &Space,capture_2: &Space,capture_3: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let v50_5: Space = singleton(&(*capture_0));
  let mut v50_12: Space = (v50_5).clone();
  loop {
    let v51_1: Space = intersect(&(v50_12),&(*capture_3));
    let v51_2: Space = restrict_to(&(*capture_1),&(v51_1));
    drop(v51_1);
    let mut v51_3 = Space::new();
    let mut v51_3_cursor = (v51_2).read_zipper();
    for v51_3_byte in v51_3_cursor.child_mask().iter() {
      v51_3_cursor.descend_to_byte(v51_3_byte);
      {
      let v51_3_tail = v51_3_cursor.fork_read_zipper();
      let v51_3_head = Path::from_slice(&[v51_3_byte]);
      let v52_2: Space = singleton(&(v51_3_head));
      let v52_3: Space = intersect(&(*CONSTANT_3),&(v52_2));
      let v52_4: Space = if has_head(&(v52_3)) { singleton(&[]) } else { Space::new() };
      drop(v52_3);
      let v52_5: Space = subtract(&(*CONSTANT_0),&(v52_4));
      drop(v52_4);
      let v52_7: Space = if (v52_5).is_empty() { Space::new() } else {
        let mut v53_6 = Space::new();
        let mut v53_6_cursor = (v51_3_tail).read_zipper();
        for v53_6_byte in v53_6_cursor.child_mask().iter() {
          v53_6_cursor.descend_to_byte(v53_6_byte);
          {
          let v53_6_tail = v53_6_cursor.fork_read_zipper();
          let v53_6_head = Path::from_slice(&[v53_6_byte]);
          let v54_2: Space = singleton(&(v53_6_head));
          let v54_3: Space = intersect(&(*CONSTANT_3),&(v54_2));
          let v54_4: Space = if has_head(&(v54_3)) { singleton(&[]) } else { Space::new() };
          drop(v54_3);
          let v54_5: Space = subtract(&(*CONSTANT_0),&(v54_4));
          drop(v54_4);
          let v54_8: Space = if (v54_5).is_empty() { Space::new() } else {
            let v55_6: Path = concat_path(&(v51_3_head),&(v53_6_head));
            let v55_7: Space = routine_8(c, &(v55_6), &(v53_6_tail).make_space());
            drop(v55_6);
            compose(&(v54_5),&(v55_7))
          };
          drop(v54_5);
          let v54_9: Space = intersect(&(*CONSTANT_3),&(v54_2));
          drop(v54_2);
          let v54_10: Space = if has_head(&(v54_9)) { singleton(&[]) } else { Space::new() };
          drop(v54_9);
          let v54_11: Space = compose(&(v54_10),&(v53_6_tail));
          drop(v54_10);
          let v54_12: Space = unite(&(v54_8),&(v54_11));
          drop(v54_11);
          v53_6.join_into((v54_12).clone());
          }
          v53_6_cursor.ascend(1);
        }
        drop(v53_6_cursor);
        compose(&(v52_5),&(v53_6))
      };
      drop(v52_5);
      let v52_8: Space = intersect(&(*CONSTANT_3),&(v52_2));
      drop(v52_2);
      let v52_9: Space = if has_head(&(v52_8)) { singleton(&[]) } else { Space::new() };
      drop(v52_8);
      let v52_10: Space = compose(&(v52_9),&(v51_3_tail));
      drop(v52_9);
      let v52_11: Space = unite(&(v52_7),&(v52_10));
      drop(v52_10);
      v51_3.join_into((v52_11).clone());
      }
      v51_3_cursor.ascend(1);
    }
    drop(v51_3_cursor);
    drop(v51_2);
    let v51_4: Space = unite(&(v51_3),&(v50_12));
    let v51_5: Space = intersect(&(v51_4),&(*capture_3));
    if !v50_12.join_into((v51_5).clone()).is_element() { break; }
  }
  let mut v50_19: Space = (v50_5).clone();
  loop {
    let v56_1: Space = intersect(&(v50_19),&(*capture_3));
    let v56_2: Space = restrict_to(&(*capture_2),&(v56_1));
    drop(v56_1);
    let mut v56_3 = Space::new();
    let mut v56_3_cursor = (v56_2).read_zipper();
    for v56_3_byte in v56_3_cursor.child_mask().iter() {
      v56_3_cursor.descend_to_byte(v56_3_byte);
      {
      let v56_3_tail = v56_3_cursor.fork_read_zipper();
      let v56_3_head = Path::from_slice(&[v56_3_byte]);
      let v57_2: Space = singleton(&(v56_3_head));
      let v57_3: Space = intersect(&(*CONSTANT_3),&(v57_2));
      let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
      drop(v57_3);
      let v57_5: Space = subtract(&(*CONSTANT_0),&(v57_4));
      drop(v57_4);
      let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
        let mut v58_6 = Space::new();
        let mut v58_6_cursor = (v56_3_tail).read_zipper();
        for v58_6_byte in v58_6_cursor.child_mask().iter() {
          v58_6_cursor.descend_to_byte(v58_6_byte);
          {
          let v58_6_tail = v58_6_cursor.fork_read_zipper();
          let v58_6_head = Path::from_slice(&[v58_6_byte]);
          let v59_2: Space = singleton(&(v58_6_head));
          let v59_3: Space = intersect(&(*CONSTANT_3),&(v59_2));
          let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
          drop(v59_3);
          let v59_5: Space = subtract(&(*CONSTANT_0),&(v59_4));
          drop(v59_4);
          let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
            let v60_6: Path = concat_path(&(v56_3_head),&(v58_6_head));
            let v60_7: Space = routine_8(c, &(v60_6), &(v58_6_tail).make_space());
            drop(v60_6);
            compose(&(v59_5),&(v60_7))
          };
          drop(v59_5);
          let v59_9: Space = intersect(&(*CONSTANT_3),&(v59_2));
          drop(v59_2);
          let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
          drop(v59_9);
          let v59_11: Space = compose(&(v59_10),&(v58_6_tail));
          drop(v59_10);
          let v59_12: Space = unite(&(v59_8),&(v59_11));
          drop(v59_11);
          v58_6.join_into((v59_12).clone());
          }
          v58_6_cursor.ascend(1);
        }
        drop(v58_6_cursor);
        compose(&(v57_5),&(v58_6))
      };
      drop(v57_5);
      let v57_8: Space = intersect(&(*CONSTANT_3),&(v57_2));
      drop(v57_2);
      let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
      drop(v57_8);
      let v57_10: Space = compose(&(v57_9),&(v56_3_tail));
      drop(v57_9);
      let v57_11: Space = unite(&(v57_7),&(v57_10));
      drop(v57_10);
      v56_3.join_into((v57_11).clone());
      }
      v56_3_cursor.ascend(1);
    }
    drop(v56_3_cursor);
    drop(v56_2);
    let v56_4: Space = unite(&(v56_3),&(v50_19));
    let v56_5: Space = intersect(&(v56_4),&(*capture_3));
    if !v50_19.join_into((v56_5).clone()).is_element() { break; }
  }
  let v50_20: Space = intersect(&(v50_12),&(v50_19));
  let v50_21: Space = subtract(&(v50_20),&(v50_5));
  let v50_22: Space = wrap(&(v50_21),&(*capture_0));
  let mut v50_29: Space = (v50_5).clone();
  loop {
    let v61_1: Space = intersect(&(v50_29),&(*capture_3));
    let v61_2: Space = restrict_to(&(*capture_2),&(v61_1));
    drop(v61_1);
    let mut v61_3 = Space::new();
    let mut v61_3_cursor = (v61_2).read_zipper();
    for v61_3_byte in v61_3_cursor.child_mask().iter() {
      v61_3_cursor.descend_to_byte(v61_3_byte);
      {
      let v61_3_tail = v61_3_cursor.fork_read_zipper();
      let v61_3_head = Path::from_slice(&[v61_3_byte]);
      let v62_2: Space = singleton(&(v61_3_head));
      let v62_3: Space = intersect(&(*CONSTANT_3),&(v62_2));
      let v62_4: Space = if has_head(&(v62_3)) { singleton(&[]) } else { Space::new() };
      drop(v62_3);
      let v62_5: Space = subtract(&(*CONSTANT_0),&(v62_4));
      drop(v62_4);
      let v62_7: Space = if (v62_5).is_empty() { Space::new() } else {
        let mut v63_6 = Space::new();
        let mut v63_6_cursor = (v61_3_tail).read_zipper();
        for v63_6_byte in v63_6_cursor.child_mask().iter() {
          v63_6_cursor.descend_to_byte(v63_6_byte);
          {
          let v63_6_tail = v63_6_cursor.fork_read_zipper();
          let v63_6_head = Path::from_slice(&[v63_6_byte]);
          let v64_2: Space = singleton(&(v63_6_head));
          let v64_3: Space = intersect(&(*CONSTANT_3),&(v64_2));
          let v64_4: Space = if has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
          drop(v64_3);
          let v64_5: Space = subtract(&(*CONSTANT_0),&(v64_4));
          drop(v64_4);
          let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
            let v65_6: Path = concat_path(&(v61_3_head),&(v63_6_head));
            let v65_7: Space = routine_8(c, &(v65_6), &(v63_6_tail).make_space());
            drop(v65_6);
            compose(&(v64_5),&(v65_7))
          };
          drop(v64_5);
          let v64_9: Space = intersect(&(*CONSTANT_3),&(v64_2));
          drop(v64_2);
          let v64_10: Space = if has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
          drop(v64_9);
          let v64_11: Space = compose(&(v64_10),&(v63_6_tail));
          drop(v64_10);
          let v64_12: Space = unite(&(v64_8),&(v64_11));
          drop(v64_11);
          v63_6.join_into((v64_12).clone());
          }
          v63_6_cursor.ascend(1);
        }
        drop(v63_6_cursor);
        compose(&(v62_5),&(v63_6))
      };
      drop(v62_5);
      let v62_8: Space = intersect(&(*CONSTANT_3),&(v62_2));
      drop(v62_2);
      let v62_9: Space = if has_head(&(v62_8)) { singleton(&[]) } else { Space::new() };
      drop(v62_8);
      let v62_10: Space = compose(&(v62_9),&(v61_3_tail));
      drop(v62_9);
      let v62_11: Space = unite(&(v62_7),&(v62_10));
      drop(v62_10);
      v61_3.join_into((v62_11).clone());
      }
      v61_3_cursor.ascend(1);
    }
    drop(v61_3_cursor);
    drop(v61_2);
    let v61_4: Space = unite(&(v61_3),&(v50_29));
    let v61_5: Space = intersect(&(v61_4),&(*capture_3));
    if !v50_29.join_into((v61_5).clone()).is_element() { break; }
  }
  let v50_30: Space = subtract(&(*capture_3),&(v50_29));
  let mut v50_37: Space = (v50_5).clone();
  loop {
    let v66_1: Space = intersect(&(v50_37),&(*capture_3));
    let v66_2: Space = restrict_to(&(*capture_1),&(v66_1));
    drop(v66_1);
    let mut v66_3 = Space::new();
    let mut v66_3_cursor = (v66_2).read_zipper();
    for v66_3_byte in v66_3_cursor.child_mask().iter() {
      v66_3_cursor.descend_to_byte(v66_3_byte);
      {
      let v66_3_tail = v66_3_cursor.fork_read_zipper();
      let v66_3_head = Path::from_slice(&[v66_3_byte]);
      let v67_2: Space = singleton(&(v66_3_head));
      let v67_3: Space = intersect(&(*CONSTANT_3),&(v67_2));
      let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
      drop(v67_3);
      let v67_5: Space = subtract(&(*CONSTANT_0),&(v67_4));
      drop(v67_4);
      let v67_7: Space = if (v67_5).is_empty() { Space::new() } else {
        let mut v68_6 = Space::new();
        let mut v68_6_cursor = (v66_3_tail).read_zipper();
        for v68_6_byte in v68_6_cursor.child_mask().iter() {
          v68_6_cursor.descend_to_byte(v68_6_byte);
          {
          let v68_6_tail = v68_6_cursor.fork_read_zipper();
          let v68_6_head = Path::from_slice(&[v68_6_byte]);
          let v69_2: Space = singleton(&(v68_6_head));
          let v69_3: Space = intersect(&(*CONSTANT_3),&(v69_2));
          let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
          drop(v69_3);
          let v69_5: Space = subtract(&(*CONSTANT_0),&(v69_4));
          drop(v69_4);
          let v69_8: Space = if (v69_5).is_empty() { Space::new() } else {
            let v70_6: Path = concat_path(&(v66_3_head),&(v68_6_head));
            let v70_7: Space = routine_8(c, &(v70_6), &(v68_6_tail).make_space());
            drop(v70_6);
            compose(&(v69_5),&(v70_7))
          };
          drop(v69_5);
          let v69_9: Space = intersect(&(*CONSTANT_3),&(v69_2));
          drop(v69_2);
          let v69_10: Space = if has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
          drop(v69_9);
          let v69_11: Space = compose(&(v69_10),&(v68_6_tail));
          drop(v69_10);
          let v69_12: Space = unite(&(v69_8),&(v69_11));
          drop(v69_11);
          v68_6.join_into((v69_12).clone());
          }
          v68_6_cursor.ascend(1);
        }
        drop(v68_6_cursor);
        compose(&(v67_5),&(v68_6))
      };
      drop(v67_5);
      let v67_8: Space = intersect(&(*CONSTANT_3),&(v67_2));
      drop(v67_2);
      let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
      drop(v67_8);
      let v67_10: Space = compose(&(v67_9),&(v66_3_tail));
      drop(v67_9);
      let v67_11: Space = unite(&(v67_7),&(v67_10));
      drop(v67_10);
      v66_3.join_into((v67_11).clone());
      }
      v66_3_cursor.ascend(1);
    }
    drop(v66_3_cursor);
    drop(v66_2);
    let v66_4: Space = unite(&(v66_3),&(v50_37));
    let v66_5: Space = intersect(&(v66_4),&(*capture_3));
    if !v50_37.join_into((v66_5).clone()).is_element() { break; }
  }
  let v50_38: Space = subtract(&(v50_30),&(v50_37));
  let v50_39: Space = range_const::<{0},{1}>(&(v50_38));
  let mut v50_67 = Space::new();
  let mut v50_67_cursor = (v50_39).read_zipper();
  for v50_67_byte in v50_67_cursor.child_mask().iter() {
    v50_67_cursor.descend_to_byte(v50_67_byte);
    {
    let v50_67_tail = v50_67_cursor.fork_read_zipper();
    let v50_67_head = Path::from_slice(&[v50_67_byte]);
    let v71_2: Space = singleton(&(v50_67_head));
    let v71_3: Space = intersect(&(*CONSTANT_3),&(v71_2));
    let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
    drop(v71_3);
    let v71_5: Space = subtract(&(*CONSTANT_0),&(v71_4));
    drop(v71_4);
    let v71_11: Space = if (v71_5).is_empty() { Space::new() } else {
      let mut v72_6: Space = (v50_5).clone();
      loop {
        let v73_1: Space = intersect(&(v72_6),&(*capture_3));
        let v73_2: Space = restrict_to(&(*capture_2),&(v73_1));
        drop(v73_1);
        let mut v73_3 = Space::new();
        let mut v73_3_cursor = (v73_2).read_zipper();
        for v73_3_byte in v73_3_cursor.child_mask().iter() {
          v73_3_cursor.descend_to_byte(v73_3_byte);
          {
          let v73_3_tail = v73_3_cursor.fork_read_zipper();
          let v73_3_head = Path::from_slice(&[v73_3_byte]);
          let v74_2: Space = singleton(&(v73_3_head));
          let v74_3: Space = intersect(&(*CONSTANT_3),&(v74_2));
          let v74_4: Space = if has_head(&(v74_3)) { singleton(&[]) } else { Space::new() };
          drop(v74_3);
          let v74_5: Space = subtract(&(*CONSTANT_0),&(v74_4));
          drop(v74_4);
          let v74_7: Space = if (v74_5).is_empty() { Space::new() } else {
            let mut v75_6 = Space::new();
            let mut v75_6_cursor = (v73_3_tail).read_zipper();
            for v75_6_byte in v75_6_cursor.child_mask().iter() {
              v75_6_cursor.descend_to_byte(v75_6_byte);
              {
              let v75_6_tail = v75_6_cursor.fork_read_zipper();
              let v75_6_head = Path::from_slice(&[v75_6_byte]);
              let v76_2: Space = singleton(&(v75_6_head));
              let v76_3: Space = intersect(&(*CONSTANT_3),&(v76_2));
              let v76_4: Space = if has_head(&(v76_3)) { singleton(&[]) } else { Space::new() };
              drop(v76_3);
              let v76_5: Space = subtract(&(*CONSTANT_0),&(v76_4));
              drop(v76_4);
              let v76_8: Space = if (v76_5).is_empty() { Space::new() } else {
                let v77_6: Path = concat_path(&(v73_3_head),&(v75_6_head));
                let v77_7: Space = routine_8(c, &(v77_6), &(v75_6_tail).make_space());
                drop(v77_6);
                compose(&(v76_5),&(v77_7))
              };
              drop(v76_5);
              let v76_9: Space = intersect(&(*CONSTANT_3),&(v76_2));
              drop(v76_2);
              let v76_10: Space = if has_head(&(v76_9)) { singleton(&[]) } else { Space::new() };
              drop(v76_9);
              let v76_11: Space = compose(&(v76_10),&(v75_6_tail));
              drop(v76_10);
              let v76_12: Space = unite(&(v76_8),&(v76_11));
              drop(v76_11);
              v75_6.join_into((v76_12).clone());
              }
              v75_6_cursor.ascend(1);
            }
            drop(v75_6_cursor);
            compose(&(v74_5),&(v75_6))
          };
          drop(v74_5);
          let v74_8: Space = intersect(&(*CONSTANT_3),&(v74_2));
          drop(v74_2);
          let v74_9: Space = if has_head(&(v74_8)) { singleton(&[]) } else { Space::new() };
          drop(v74_8);
          let v74_10: Space = compose(&(v74_9),&(v73_3_tail));
          drop(v74_9);
          let v74_11: Space = unite(&(v74_7),&(v74_10));
          drop(v74_10);
          v73_3.join_into((v74_11).clone());
          }
          v73_3_cursor.ascend(1);
        }
        drop(v73_3_cursor);
        drop(v73_2);
        let v73_4: Space = unite(&(v73_3),&(v72_6));
        let v73_5: Space = intersect(&(v73_4),&(*capture_3));
        if !v72_6.join_into((v73_5).clone()).is_element() { break; }
      }
      let v72_7: Space = subtract(&(*capture_3),&(v72_6));
      let mut v72_8: Space = (v50_5).clone();
      loop {
        let v78_1: Space = intersect(&(v72_8),&(*capture_3));
        let v78_2: Space = restrict_to(&(*capture_1),&(v78_1));
        drop(v78_1);
        let mut v78_3 = Space::new();
        let mut v78_3_cursor = (v78_2).read_zipper();
        for v78_3_byte in v78_3_cursor.child_mask().iter() {
          v78_3_cursor.descend_to_byte(v78_3_byte);
          {
          let v78_3_tail = v78_3_cursor.fork_read_zipper();
          let v78_3_head = Path::from_slice(&[v78_3_byte]);
          let v79_2: Space = singleton(&(v78_3_head));
          let v79_3: Space = intersect(&(*CONSTANT_3),&(v79_2));
          let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
          drop(v79_3);
          let v79_5: Space = subtract(&(*CONSTANT_0),&(v79_4));
          drop(v79_4);
          let v79_7: Space = if (v79_5).is_empty() { Space::new() } else {
            let mut v80_6 = Space::new();
            let mut v80_6_cursor = (v78_3_tail).read_zipper();
            for v80_6_byte in v80_6_cursor.child_mask().iter() {
              v80_6_cursor.descend_to_byte(v80_6_byte);
              {
              let v80_6_tail = v80_6_cursor.fork_read_zipper();
              let v80_6_head = Path::from_slice(&[v80_6_byte]);
              let v81_2: Space = singleton(&(v80_6_head));
              let v81_3: Space = intersect(&(*CONSTANT_3),&(v81_2));
              let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
              drop(v81_3);
              let v81_5: Space = subtract(&(*CONSTANT_0),&(v81_4));
              drop(v81_4);
              let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
                let v82_6: Path = concat_path(&(v78_3_head),&(v80_6_head));
                let v82_7: Space = routine_8(c, &(v82_6), &(v80_6_tail).make_space());
                drop(v82_6);
                compose(&(v81_5),&(v82_7))
              };
              drop(v81_5);
              let v81_9: Space = intersect(&(*CONSTANT_3),&(v81_2));
              drop(v81_2);
              let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
              drop(v81_9);
              let v81_11: Space = compose(&(v81_10),&(v80_6_tail));
              drop(v81_10);
              let v81_12: Space = unite(&(v81_8),&(v81_11));
              drop(v81_11);
              v80_6.join_into((v81_12).clone());
              }
              v80_6_cursor.ascend(1);
            }
            drop(v80_6_cursor);
            compose(&(v79_5),&(v80_6))
          };
          drop(v79_5);
          let v79_8: Space = intersect(&(*CONSTANT_3),&(v79_2));
          drop(v79_2);
          let v79_9: Space = if has_head(&(v79_8)) { singleton(&[]) } else { Space::new() };
          drop(v79_8);
          let v79_10: Space = compose(&(v79_9),&(v78_3_tail));
          drop(v79_9);
          let v79_11: Space = unite(&(v79_7),&(v79_10));
          drop(v79_10);
          v78_3.join_into((v79_11).clone());
          }
          v78_3_cursor.ascend(1);
        }
        drop(v78_3_cursor);
        drop(v78_2);
        let v78_4: Space = unite(&(v78_3),&(v72_8));
        let v78_5: Space = intersect(&(v78_4),&(*capture_3));
        if !v72_8.join_into((v78_5).clone()).is_element() { break; }
      }
      let v72_9: Space = subtract(&(v72_7),&(v72_8));
      let v72_10: Space = routine_4(c, &(v50_67_head), &(v50_67_tail).make_space(), &(*capture_1), &(*capture_2), &(v72_9));
      compose(&(v71_5),&(v72_10))
    };
    drop(v71_5);
    let v71_12: Space = intersect(&(*CONSTANT_3),&(v71_2));
    drop(v71_2);
    let v71_13: Space = if has_head(&(v71_12)) { singleton(&[]) } else { Space::new() };
    drop(v71_12);
    let v71_19: Space = if (v71_13).is_empty() { Space::new() } else {
      let mut v83_14: Space = (v50_5).clone();
      loop {
        let v84_1: Space = intersect(&(v83_14),&(*capture_3));
        let v84_2: Space = restrict_to(&(*capture_2),&(v84_1));
        drop(v84_1);
        let mut v84_3 = Space::new();
        let mut v84_3_cursor = (v84_2).read_zipper();
        for v84_3_byte in v84_3_cursor.child_mask().iter() {
          v84_3_cursor.descend_to_byte(v84_3_byte);
          {
          let v84_3_tail = v84_3_cursor.fork_read_zipper();
          let v84_3_head = Path::from_slice(&[v84_3_byte]);
          let v85_2: Space = singleton(&(v84_3_head));
          let v85_3: Space = intersect(&(*CONSTANT_3),&(v85_2));
          let v85_4: Space = if has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
          drop(v85_3);
          let v85_5: Space = subtract(&(*CONSTANT_0),&(v85_4));
          drop(v85_4);
          let v85_7: Space = if (v85_5).is_empty() { Space::new() } else {
            let mut v86_6 = Space::new();
            let mut v86_6_cursor = (v84_3_tail).read_zipper();
            for v86_6_byte in v86_6_cursor.child_mask().iter() {
              v86_6_cursor.descend_to_byte(v86_6_byte);
              {
              let v86_6_tail = v86_6_cursor.fork_read_zipper();
              let v86_6_head = Path::from_slice(&[v86_6_byte]);
              let v87_2: Space = singleton(&(v86_6_head));
              let v87_3: Space = intersect(&(*CONSTANT_3),&(v87_2));
              let v87_4: Space = if has_head(&(v87_3)) { singleton(&[]) } else { Space::new() };
              drop(v87_3);
              let v87_5: Space = subtract(&(*CONSTANT_0),&(v87_4));
              drop(v87_4);
              let v87_8: Space = if (v87_5).is_empty() { Space::new() } else {
                let v88_6: Path = concat_path(&(v84_3_head),&(v86_6_head));
                let v88_7: Space = routine_8(c, &(v88_6), &(v86_6_tail).make_space());
                drop(v88_6);
                compose(&(v87_5),&(v88_7))
              };
              drop(v87_5);
              let v87_9: Space = intersect(&(*CONSTANT_3),&(v87_2));
              drop(v87_2);
              let v87_10: Space = if has_head(&(v87_9)) { singleton(&[]) } else { Space::new() };
              drop(v87_9);
              let v87_11: Space = compose(&(v87_10),&(v86_6_tail));
              drop(v87_10);
              let v87_12: Space = unite(&(v87_8),&(v87_11));
              drop(v87_11);
              v86_6.join_into((v87_12).clone());
              }
              v86_6_cursor.ascend(1);
            }
            drop(v86_6_cursor);
            compose(&(v85_5),&(v86_6))
          };
          drop(v85_5);
          let v85_8: Space = intersect(&(*CONSTANT_3),&(v85_2));
          drop(v85_2);
          let v85_9: Space = if has_head(&(v85_8)) { singleton(&[]) } else { Space::new() };
          drop(v85_8);
          let v85_10: Space = compose(&(v85_9),&(v84_3_tail));
          drop(v85_9);
          let v85_11: Space = unite(&(v85_7),&(v85_10));
          drop(v85_10);
          v84_3.join_into((v85_11).clone());
          }
          v84_3_cursor.ascend(1);
        }
        drop(v84_3_cursor);
        drop(v84_2);
        let v84_4: Space = unite(&(v84_3),&(v83_14));
        let v84_5: Space = intersect(&(v84_4),&(*capture_3));
        if !v83_14.join_into((v84_5).clone()).is_element() { break; }
      }
      let v83_15: Space = subtract(&(*capture_3),&(v83_14));
      let mut v83_16: Space = (v50_5).clone();
      loop {
        let v89_1: Space = intersect(&(v83_16),&(*capture_3));
        let v89_2: Space = restrict_to(&(*capture_1),&(v89_1));
        drop(v89_1);
        let mut v89_3 = Space::new();
        let mut v89_3_cursor = (v89_2).read_zipper();
        for v89_3_byte in v89_3_cursor.child_mask().iter() {
          v89_3_cursor.descend_to_byte(v89_3_byte);
          {
          let v89_3_tail = v89_3_cursor.fork_read_zipper();
          let v89_3_head = Path::from_slice(&[v89_3_byte]);
          let v90_2: Space = singleton(&(v89_3_head));
          let v90_3: Space = intersect(&(*CONSTANT_3),&(v90_2));
          let v90_4: Space = if has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
          drop(v90_3);
          let v90_5: Space = subtract(&(*CONSTANT_0),&(v90_4));
          drop(v90_4);
          let v90_7: Space = if (v90_5).is_empty() { Space::new() } else {
            let mut v91_6 = Space::new();
            let mut v91_6_cursor = (v89_3_tail).read_zipper();
            for v91_6_byte in v91_6_cursor.child_mask().iter() {
              v91_6_cursor.descend_to_byte(v91_6_byte);
              {
              let v91_6_tail = v91_6_cursor.fork_read_zipper();
              let v91_6_head = Path::from_slice(&[v91_6_byte]);
              let v92_2: Space = singleton(&(v91_6_head));
              let v92_3: Space = intersect(&(*CONSTANT_3),&(v92_2));
              let v92_4: Space = if has_head(&(v92_3)) { singleton(&[]) } else { Space::new() };
              drop(v92_3);
              let v92_5: Space = subtract(&(*CONSTANT_0),&(v92_4));
              drop(v92_4);
              let v92_8: Space = if (v92_5).is_empty() { Space::new() } else {
                let v93_6: Path = concat_path(&(v89_3_head),&(v91_6_head));
                let v93_7: Space = routine_8(c, &(v93_6), &(v91_6_tail).make_space());
                drop(v93_6);
                compose(&(v92_5),&(v93_7))
              };
              drop(v92_5);
              let v92_9: Space = intersect(&(*CONSTANT_3),&(v92_2));
              drop(v92_2);
              let v92_10: Space = if has_head(&(v92_9)) { singleton(&[]) } else { Space::new() };
              drop(v92_9);
              let v92_11: Space = compose(&(v92_10),&(v91_6_tail));
              drop(v92_10);
              let v92_12: Space = unite(&(v92_8),&(v92_11));
              drop(v92_11);
              v91_6.join_into((v92_12).clone());
              }
              v91_6_cursor.ascend(1);
            }
            drop(v91_6_cursor);
            compose(&(v90_5),&(v91_6))
          };
          drop(v90_5);
          let v90_8: Space = intersect(&(*CONSTANT_3),&(v90_2));
          drop(v90_2);
          let v90_9: Space = if has_head(&(v90_8)) { singleton(&[]) } else { Space::new() };
          drop(v90_8);
          let v90_10: Space = compose(&(v90_9),&(v89_3_tail));
          drop(v90_9);
          let v90_11: Space = unite(&(v90_7),&(v90_10));
          drop(v90_10);
          v89_3.join_into((v90_11).clone());
          }
          v89_3_cursor.ascend(1);
        }
        drop(v89_3_cursor);
        drop(v89_2);
        let v89_4: Space = unite(&(v89_3),&(v83_16));
        let v89_5: Space = intersect(&(v89_4),&(*capture_3));
        if !v83_16.join_into((v89_5).clone()).is_element() { break; }
      }
      let v83_17: Space = subtract(&(v83_15),&(v83_16));
      let v83_18: Space = routine_5(c, &(v50_67_head), &(v50_67_tail).make_space(), &(*capture_1), &(*capture_2), &(v83_17));
      compose(&(v71_13),&(v83_18))
    };
    drop(v71_13);
    let v71_20: Space = unite(&(v71_11),&(v71_19));
    v50_67.join_into((v71_20).clone());
    }
    v50_67_cursor.ascend(1);
  }
  drop(v50_67_cursor);
  let v50_68: Space = unite(&(v50_22),&(v50_67));
  let mut v50_75: Space = (v50_5).clone();
  loop {
    let v94_1: Space = intersect(&(v50_75),&(*capture_3));
    let v94_2: Space = restrict_to(&(*capture_2),&(v94_1));
    drop(v94_1);
    let mut v94_3 = Space::new();
    let mut v94_3_cursor = (v94_2).read_zipper();
    for v94_3_byte in v94_3_cursor.child_mask().iter() {
      v94_3_cursor.descend_to_byte(v94_3_byte);
      {
      let v94_3_tail = v94_3_cursor.fork_read_zipper();
      let v94_3_head = Path::from_slice(&[v94_3_byte]);
      let v95_2: Space = singleton(&(v94_3_head));
      let v95_3: Space = intersect(&(*CONSTANT_3),&(v95_2));
      let v95_4: Space = if has_head(&(v95_3)) { singleton(&[]) } else { Space::new() };
      drop(v95_3);
      let v95_5: Space = subtract(&(*CONSTANT_0),&(v95_4));
      drop(v95_4);
      let v95_7: Space = if (v95_5).is_empty() { Space::new() } else {
        let mut v96_6 = Space::new();
        let mut v96_6_cursor = (v94_3_tail).read_zipper();
        for v96_6_byte in v96_6_cursor.child_mask().iter() {
          v96_6_cursor.descend_to_byte(v96_6_byte);
          {
          let v96_6_tail = v96_6_cursor.fork_read_zipper();
          let v96_6_head = Path::from_slice(&[v96_6_byte]);
          let v97_2: Space = singleton(&(v96_6_head));
          let v97_3: Space = intersect(&(*CONSTANT_3),&(v97_2));
          let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
          drop(v97_3);
          let v97_5: Space = subtract(&(*CONSTANT_0),&(v97_4));
          drop(v97_4);
          let v97_8: Space = if (v97_5).is_empty() { Space::new() } else {
            let v98_6: Path = concat_path(&(v94_3_head),&(v96_6_head));
            let v98_7: Space = routine_8(c, &(v98_6), &(v96_6_tail).make_space());
            drop(v98_6);
            compose(&(v97_5),&(v98_7))
          };
          drop(v97_5);
          let v97_9: Space = intersect(&(*CONSTANT_3),&(v97_2));
          drop(v97_2);
          let v97_10: Space = if has_head(&(v97_9)) { singleton(&[]) } else { Space::new() };
          drop(v97_9);
          let v97_11: Space = compose(&(v97_10),&(v96_6_tail));
          drop(v97_10);
          let v97_12: Space = unite(&(v97_8),&(v97_11));
          drop(v97_11);
          v96_6.join_into((v97_12).clone());
          }
          v96_6_cursor.ascend(1);
        }
        drop(v96_6_cursor);
        compose(&(v95_5),&(v96_6))
      };
      drop(v95_5);
      let v95_8: Space = intersect(&(*CONSTANT_3),&(v95_2));
      drop(v95_2);
      let v95_9: Space = if has_head(&(v95_8)) { singleton(&[]) } else { Space::new() };
      drop(v95_8);
      let v95_10: Space = compose(&(v95_9),&(v94_3_tail));
      drop(v95_9);
      let v95_11: Space = unite(&(v95_7),&(v95_10));
      drop(v95_10);
      v94_3.join_into((v95_11).clone());
      }
      v94_3_cursor.ascend(1);
    }
    drop(v94_3_cursor);
    drop(v94_2);
    let v94_4: Space = unite(&(v94_3),&(v50_75));
    let v94_5: Space = intersect(&(v94_4),&(*capture_3));
    if !v50_75.join_into((v94_5).clone()).is_element() { break; }
  }

((v50_12).clone(),(v50_19).clone(),(v50_20).clone(),(v50_21).clone(),(v50_22).clone(),(v50_29).clone(),(v50_30).clone(),(v50_37).clone(),(v50_38).clone(),(v50_39).clone(),(v50_5).clone(),(v50_67).clone(),(v50_68).clone(),(v50_75).clone(),)
}

#[inline(never)]
fn native_block_1(c: &mut Context,capture_0: &Space,capture_1: &Space,capture_2: &Space,capture_3: &Space,capture_4: &Space,capture_5: &Space) -> (Space,Space,Space,Space,Space,Space,Space,Space,Space,Space,) {
  let mut v50_82: Space = ((*capture_3)).clone();
  loop {
    let v99_1: Space = intersect(&(v50_82),&(*capture_2));
    let v99_2: Space = restrict_to(&(*capture_0),&(v99_1));
    drop(v99_1);
    let mut v99_3 = Space::new();
    let mut v99_3_cursor = (v99_2).read_zipper();
    for v99_3_byte in v99_3_cursor.child_mask().iter() {
      v99_3_cursor.descend_to_byte(v99_3_byte);
      {
      let v99_3_tail = v99_3_cursor.fork_read_zipper();
      let v99_3_head = Path::from_slice(&[v99_3_byte]);
      let v100_2: Space = singleton(&(v99_3_head));
      let v100_3: Space = intersect(&(*CONSTANT_3),&(v100_2));
      let v100_4: Space = if has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
      drop(v100_3);
      let v100_5: Space = subtract(&(*CONSTANT_0),&(v100_4));
      drop(v100_4);
      let v100_7: Space = if (v100_5).is_empty() { Space::new() } else {
        let mut v101_6 = Space::new();
        let mut v101_6_cursor = (v99_3_tail).read_zipper();
        for v101_6_byte in v101_6_cursor.child_mask().iter() {
          v101_6_cursor.descend_to_byte(v101_6_byte);
          {
          let v101_6_tail = v101_6_cursor.fork_read_zipper();
          let v101_6_head = Path::from_slice(&[v101_6_byte]);
          let v102_2: Space = singleton(&(v101_6_head));
          let v102_3: Space = intersect(&(*CONSTANT_3),&(v102_2));
          let v102_4: Space = if has_head(&(v102_3)) { singleton(&[]) } else { Space::new() };
          drop(v102_3);
          let v102_5: Space = subtract(&(*CONSTANT_0),&(v102_4));
          drop(v102_4);
          let v102_8: Space = if (v102_5).is_empty() { Space::new() } else {
            let v103_6: Path = concat_path(&(v99_3_head),&(v101_6_head));
            let v103_7: Space = routine_8(c, &(v103_6), &(v101_6_tail).make_space());
            drop(v103_6);
            compose(&(v102_5),&(v103_7))
          };
          drop(v102_5);
          let v102_9: Space = intersect(&(*CONSTANT_3),&(v102_2));
          drop(v102_2);
          let v102_10: Space = if has_head(&(v102_9)) { singleton(&[]) } else { Space::new() };
          drop(v102_9);
          let v102_11: Space = compose(&(v102_10),&(v101_6_tail));
          drop(v102_10);
          let v102_12: Space = unite(&(v102_8),&(v102_11));
          drop(v102_11);
          v101_6.join_into((v102_12).clone());
          }
          v101_6_cursor.ascend(1);
        }
        drop(v101_6_cursor);
        compose(&(v100_5),&(v101_6))
      };
      drop(v100_5);
      let v100_8: Space = intersect(&(*CONSTANT_3),&(v100_2));
      drop(v100_2);
      let v100_9: Space = if has_head(&(v100_8)) { singleton(&[]) } else { Space::new() };
      drop(v100_8);
      let v100_10: Space = compose(&(v100_9),&(v99_3_tail));
      drop(v100_9);
      let v100_11: Space = unite(&(v100_7),&(v100_10));
      drop(v100_10);
      v99_3.join_into((v100_11).clone());
      }
      v99_3_cursor.ascend(1);
    }
    drop(v99_3_cursor);
    drop(v99_2);
    let v99_4: Space = unite(&(v99_3),&(v50_82));
    let v99_5: Space = intersect(&(v99_4),&(*capture_2));
    if !v50_82.join_into((v99_5).clone()).is_element() { break; }
  }
  let v50_83: Space = subtract(&((*capture_5)),&(v50_82));
  let v50_84: Space = range_const::<{0},{1}>(&(v50_83));
  let mut v50_112 = Space::new();
  let mut v50_112_cursor = (v50_84).read_zipper();
  for v50_112_byte in v50_112_cursor.child_mask().iter() {
    v50_112_cursor.descend_to_byte(v50_112_byte);
    {
    let v50_112_tail = v50_112_cursor.fork_read_zipper();
    let v50_112_head = Path::from_slice(&[v50_112_byte]);
    let v104_2: Space = singleton(&(v50_112_head));
    let v104_3: Space = intersect(&(*CONSTANT_3),&(v104_2));
    let v104_4: Space = if has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_10: Space = if (v104_5).is_empty() { Space::new() } else {
      let mut v105_6: Space = ((*capture_3)).clone();
      loop {
        let v106_1: Space = intersect(&(v105_6),&(*capture_2));
        let v106_2: Space = restrict_to(&(*capture_1),&(v106_1));
        drop(v106_1);
        let mut v106_3 = Space::new();
        let mut v106_3_cursor = (v106_2).read_zipper();
        for v106_3_byte in v106_3_cursor.child_mask().iter() {
          v106_3_cursor.descend_to_byte(v106_3_byte);
          {
          let v106_3_tail = v106_3_cursor.fork_read_zipper();
          let v106_3_head = Path::from_slice(&[v106_3_byte]);
          let v107_2: Space = singleton(&(v106_3_head));
          let v107_3: Space = intersect(&(*CONSTANT_3),&(v107_2));
          let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
          drop(v107_3);
          let v107_5: Space = subtract(&(*CONSTANT_0),&(v107_4));
          drop(v107_4);
          let v107_7: Space = if (v107_5).is_empty() { Space::new() } else {
            let mut v108_6 = Space::new();
            let mut v108_6_cursor = (v106_3_tail).read_zipper();
            for v108_6_byte in v108_6_cursor.child_mask().iter() {
              v108_6_cursor.descend_to_byte(v108_6_byte);
              {
              let v108_6_tail = v108_6_cursor.fork_read_zipper();
              let v108_6_head = Path::from_slice(&[v108_6_byte]);
              let v109_2: Space = singleton(&(v108_6_head));
              let v109_3: Space = intersect(&(*CONSTANT_3),&(v109_2));
              let v109_4: Space = if has_head(&(v109_3)) { singleton(&[]) } else { Space::new() };
              drop(v109_3);
              let v109_5: Space = subtract(&(*CONSTANT_0),&(v109_4));
              drop(v109_4);
              let v109_8: Space = if (v109_5).is_empty() { Space::new() } else {
                let v110_6: Path = concat_path(&(v106_3_head),&(v108_6_head));
                let v110_7: Space = routine_8(c, &(v110_6), &(v108_6_tail).make_space());
                drop(v110_6);
                compose(&(v109_5),&(v110_7))
              };
              drop(v109_5);
              let v109_9: Space = intersect(&(*CONSTANT_3),&(v109_2));
              drop(v109_2);
              let v109_10: Space = if has_head(&(v109_9)) { singleton(&[]) } else { Space::new() };
              drop(v109_9);
              let v109_11: Space = compose(&(v109_10),&(v108_6_tail));
              drop(v109_10);
              let v109_12: Space = unite(&(v109_8),&(v109_11));
              drop(v109_11);
              v108_6.join_into((v109_12).clone());
              }
              v108_6_cursor.ascend(1);
            }
            drop(v108_6_cursor);
            compose(&(v107_5),&(v108_6))
          };
          drop(v107_5);
          let v107_8: Space = intersect(&(*CONSTANT_3),&(v107_2));
          drop(v107_2);
          let v107_9: Space = if has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
          drop(v107_8);
          let v107_10: Space = compose(&(v107_9),&(v106_3_tail));
          drop(v107_9);
          let v107_11: Space = unite(&(v107_7),&(v107_10));
          drop(v107_10);
          v106_3.join_into((v107_11).clone());
          }
          v106_3_cursor.ascend(1);
        }
        drop(v106_3_cursor);
        drop(v106_2);
        let v106_4: Space = unite(&(v106_3),&(v105_6));
        let v106_5: Space = intersect(&(v106_4),&(*capture_2));
        if !v105_6.join_into((v106_5).clone()).is_element() { break; }
      }
      let mut v105_7: Space = ((*capture_3)).clone();
      loop {
        let v111_1: Space = intersect(&(v105_7),&(*capture_2));
        let v111_2: Space = restrict_to(&(*capture_0),&(v111_1));
        drop(v111_1);
        let mut v111_3 = Space::new();
        let mut v111_3_cursor = (v111_2).read_zipper();
        for v111_3_byte in v111_3_cursor.child_mask().iter() {
          v111_3_cursor.descend_to_byte(v111_3_byte);
          {
          let v111_3_tail = v111_3_cursor.fork_read_zipper();
          let v111_3_head = Path::from_slice(&[v111_3_byte]);
          let v112_2: Space = singleton(&(v111_3_head));
          let v112_3: Space = intersect(&(*CONSTANT_3),&(v112_2));
          let v112_4: Space = if has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
          drop(v112_3);
          let v112_5: Space = subtract(&(*CONSTANT_0),&(v112_4));
          drop(v112_4);
          let v112_7: Space = if (v112_5).is_empty() { Space::new() } else {
            let mut v113_6 = Space::new();
            let mut v113_6_cursor = (v111_3_tail).read_zipper();
            for v113_6_byte in v113_6_cursor.child_mask().iter() {
              v113_6_cursor.descend_to_byte(v113_6_byte);
              {
              let v113_6_tail = v113_6_cursor.fork_read_zipper();
              let v113_6_head = Path::from_slice(&[v113_6_byte]);
              let v114_2: Space = singleton(&(v113_6_head));
              let v114_3: Space = intersect(&(*CONSTANT_3),&(v114_2));
              let v114_4: Space = if has_head(&(v114_3)) { singleton(&[]) } else { Space::new() };
              drop(v114_3);
              let v114_5: Space = subtract(&(*CONSTANT_0),&(v114_4));
              drop(v114_4);
              let v114_8: Space = if (v114_5).is_empty() { Space::new() } else {
                let v115_6: Path = concat_path(&(v111_3_head),&(v113_6_head));
                let v115_7: Space = routine_8(c, &(v115_6), &(v113_6_tail).make_space());
                drop(v115_6);
                compose(&(v114_5),&(v115_7))
              };
              drop(v114_5);
              let v114_9: Space = intersect(&(*CONSTANT_3),&(v114_2));
              drop(v114_2);
              let v114_10: Space = if has_head(&(v114_9)) { singleton(&[]) } else { Space::new() };
              drop(v114_9);
              let v114_11: Space = compose(&(v114_10),&(v113_6_tail));
              drop(v114_10);
              let v114_12: Space = unite(&(v114_8),&(v114_11));
              drop(v114_11);
              v113_6.join_into((v114_12).clone());
              }
              v113_6_cursor.ascend(1);
            }
            drop(v113_6_cursor);
            compose(&(v112_5),&(v113_6))
          };
          drop(v112_5);
          let v112_8: Space = intersect(&(*CONSTANT_3),&(v112_2));
          drop(v112_2);
          let v112_9: Space = if has_head(&(v112_8)) { singleton(&[]) } else { Space::new() };
          drop(v112_8);
          let v112_10: Space = compose(&(v112_9),&(v111_3_tail));
          drop(v112_9);
          let v112_11: Space = unite(&(v112_7),&(v112_10));
          drop(v112_10);
          v111_3.join_into((v112_11).clone());
          }
          v111_3_cursor.ascend(1);
        }
        drop(v111_3_cursor);
        drop(v111_2);
        let v111_4: Space = unite(&(v111_3),&(v105_7));
        let v111_5: Space = intersect(&(v111_4),&(*capture_2));
        if !v105_7.join_into((v111_5).clone()).is_element() { break; }
      }
      let v105_8: Space = subtract(&(v105_6),&(v105_7));
      let v105_9: Space = routine_4(c, &(v50_112_head), &(v50_112_tail).make_space(), &(*capture_0), &(*capture_1), &(v105_8));
      compose(&(v104_5),&(v105_9))
    };
    drop(v104_5);
    let v104_11: Space = intersect(&(*CONSTANT_3),&(v104_2));
    drop(v104_2);
    let v104_12: Space = if has_head(&(v104_11)) { singleton(&[]) } else { Space::new() };
    drop(v104_11);
    let v104_17: Space = if (v104_12).is_empty() { Space::new() } else {
      let mut v116_13: Space = ((*capture_3)).clone();
      loop {
        let v117_1: Space = intersect(&(v116_13),&(*capture_2));
        let v117_2: Space = restrict_to(&(*capture_1),&(v117_1));
        drop(v117_1);
        let mut v117_3 = Space::new();
        let mut v117_3_cursor = (v117_2).read_zipper();
        for v117_3_byte in v117_3_cursor.child_mask().iter() {
          v117_3_cursor.descend_to_byte(v117_3_byte);
          {
          let v117_3_tail = v117_3_cursor.fork_read_zipper();
          let v117_3_head = Path::from_slice(&[v117_3_byte]);
          let v118_2: Space = singleton(&(v117_3_head));
          let v118_3: Space = intersect(&(*CONSTANT_3),&(v118_2));
          let v118_4: Space = if has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
          drop(v118_3);
          let v118_5: Space = subtract(&(*CONSTANT_0),&(v118_4));
          drop(v118_4);
          let v118_7: Space = if (v118_5).is_empty() { Space::new() } else {
            let mut v119_6 = Space::new();
            let mut v119_6_cursor = (v117_3_tail).read_zipper();
            for v119_6_byte in v119_6_cursor.child_mask().iter() {
              v119_6_cursor.descend_to_byte(v119_6_byte);
              {
              let v119_6_tail = v119_6_cursor.fork_read_zipper();
              let v119_6_head = Path::from_slice(&[v119_6_byte]);
              let v120_2: Space = singleton(&(v119_6_head));
              let v120_3: Space = intersect(&(*CONSTANT_3),&(v120_2));
              let v120_4: Space = if has_head(&(v120_3)) { singleton(&[]) } else { Space::new() };
              drop(v120_3);
              let v120_5: Space = subtract(&(*CONSTANT_0),&(v120_4));
              drop(v120_4);
              let v120_8: Space = if (v120_5).is_empty() { Space::new() } else {
                let v121_6: Path = concat_path(&(v117_3_head),&(v119_6_head));
                let v121_7: Space = routine_8(c, &(v121_6), &(v119_6_tail).make_space());
                drop(v121_6);
                compose(&(v120_5),&(v121_7))
              };
              drop(v120_5);
              let v120_9: Space = intersect(&(*CONSTANT_3),&(v120_2));
              drop(v120_2);
              let v120_10: Space = if has_head(&(v120_9)) { singleton(&[]) } else { Space::new() };
              drop(v120_9);
              let v120_11: Space = compose(&(v120_10),&(v119_6_tail));
              drop(v120_10);
              let v120_12: Space = unite(&(v120_8),&(v120_11));
              drop(v120_11);
              v119_6.join_into((v120_12).clone());
              }
              v119_6_cursor.ascend(1);
            }
            drop(v119_6_cursor);
            compose(&(v118_5),&(v119_6))
          };
          drop(v118_5);
          let v118_8: Space = intersect(&(*CONSTANT_3),&(v118_2));
          drop(v118_2);
          let v118_9: Space = if has_head(&(v118_8)) { singleton(&[]) } else { Space::new() };
          drop(v118_8);
          let v118_10: Space = compose(&(v118_9),&(v117_3_tail));
          drop(v118_9);
          let v118_11: Space = unite(&(v118_7),&(v118_10));
          drop(v118_10);
          v117_3.join_into((v118_11).clone());
          }
          v117_3_cursor.ascend(1);
        }
        drop(v117_3_cursor);
        drop(v117_2);
        let v117_4: Space = unite(&(v117_3),&(v116_13));
        let v117_5: Space = intersect(&(v117_4),&(*capture_2));
        if !v116_13.join_into((v117_5).clone()).is_element() { break; }
      }
      let mut v116_14: Space = ((*capture_3)).clone();
      loop {
        let v122_1: Space = intersect(&(v116_14),&(*capture_2));
        let v122_2: Space = restrict_to(&(*capture_0),&(v122_1));
        drop(v122_1);
        let mut v122_3 = Space::new();
        let mut v122_3_cursor = (v122_2).read_zipper();
        for v122_3_byte in v122_3_cursor.child_mask().iter() {
          v122_3_cursor.descend_to_byte(v122_3_byte);
          {
          let v122_3_tail = v122_3_cursor.fork_read_zipper();
          let v122_3_head = Path::from_slice(&[v122_3_byte]);
          let v123_2: Space = singleton(&(v122_3_head));
          let v123_3: Space = intersect(&(*CONSTANT_3),&(v123_2));
          let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
          drop(v123_3);
          let v123_5: Space = subtract(&(*CONSTANT_0),&(v123_4));
          drop(v123_4);
          let v123_7: Space = if (v123_5).is_empty() { Space::new() } else {
            let mut v124_6 = Space::new();
            let mut v124_6_cursor = (v122_3_tail).read_zipper();
            for v124_6_byte in v124_6_cursor.child_mask().iter() {
              v124_6_cursor.descend_to_byte(v124_6_byte);
              {
              let v124_6_tail = v124_6_cursor.fork_read_zipper();
              let v124_6_head = Path::from_slice(&[v124_6_byte]);
              let v125_2: Space = singleton(&(v124_6_head));
              let v125_3: Space = intersect(&(*CONSTANT_3),&(v125_2));
              let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
              drop(v125_3);
              let v125_5: Space = subtract(&(*CONSTANT_0),&(v125_4));
              drop(v125_4);
              let v125_8: Space = if (v125_5).is_empty() { Space::new() } else {
                let v126_6: Path = concat_path(&(v122_3_head),&(v124_6_head));
                let v126_7: Space = routine_8(c, &(v126_6), &(v124_6_tail).make_space());
                drop(v126_6);
                compose(&(v125_5),&(v126_7))
              };
              drop(v125_5);
              let v125_9: Space = intersect(&(*CONSTANT_3),&(v125_2));
              drop(v125_2);
              let v125_10: Space = if has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
              drop(v125_9);
              let v125_11: Space = compose(&(v125_10),&(v124_6_tail));
              drop(v125_10);
              let v125_12: Space = unite(&(v125_8),&(v125_11));
              drop(v125_11);
              v124_6.join_into((v125_12).clone());
              }
              v124_6_cursor.ascend(1);
            }
            drop(v124_6_cursor);
            compose(&(v123_5),&(v124_6))
          };
          drop(v123_5);
          let v123_8: Space = intersect(&(*CONSTANT_3),&(v123_2));
          drop(v123_2);
          let v123_9: Space = if has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
          drop(v123_8);
          let v123_10: Space = compose(&(v123_9),&(v122_3_tail));
          drop(v123_9);
          let v123_11: Space = unite(&(v123_7),&(v123_10));
          drop(v123_10);
          v122_3.join_into((v123_11).clone());
          }
          v122_3_cursor.ascend(1);
        }
        drop(v122_3_cursor);
        drop(v122_2);
        let v122_4: Space = unite(&(v122_3),&(v116_14));
        let v122_5: Space = intersect(&(v122_4),&(*capture_2));
        if !v116_14.join_into((v122_5).clone()).is_element() { break; }
      }
      let v116_15: Space = subtract(&(v116_13),&(v116_14));
      let v116_16: Space = routine_5(c, &(v50_112_head), &(v50_112_tail).make_space(), &(*capture_0), &(*capture_1), &(v116_15));
      compose(&(v104_12),&(v116_16))
    };
    drop(v104_12);
    let v104_18: Space = unite(&(v104_10),&(v104_17));
    v50_112.join_into((v104_18).clone());
    }
    v50_112_cursor.ascend(1);
  }
  drop(v50_112_cursor);
  let v50_113: Space = unite(&((*capture_4)),&(v50_112));
  let mut v50_120: Space = ((*capture_3)).clone();
  loop {
    let v127_1: Space = intersect(&(v50_120),&(*capture_2));
    let v127_2: Space = restrict_to(&(*capture_0),&(v127_1));
    drop(v127_1);
    let mut v127_3 = Space::new();
    let mut v127_3_cursor = (v127_2).read_zipper();
    for v127_3_byte in v127_3_cursor.child_mask().iter() {
      v127_3_cursor.descend_to_byte(v127_3_byte);
      {
      let v127_3_tail = v127_3_cursor.fork_read_zipper();
      let v127_3_head = Path::from_slice(&[v127_3_byte]);
      let v128_2: Space = singleton(&(v127_3_head));
      let v128_3: Space = intersect(&(*CONSTANT_3),&(v128_2));
      let v128_4: Space = if has_head(&(v128_3)) { singleton(&[]) } else { Space::new() };
      drop(v128_3);
      let v128_5: Space = subtract(&(*CONSTANT_0),&(v128_4));
      drop(v128_4);
      let v128_7: Space = if (v128_5).is_empty() { Space::new() } else {
        let mut v129_6 = Space::new();
        let mut v129_6_cursor = (v127_3_tail).read_zipper();
        for v129_6_byte in v129_6_cursor.child_mask().iter() {
          v129_6_cursor.descend_to_byte(v129_6_byte);
          {
          let v129_6_tail = v129_6_cursor.fork_read_zipper();
          let v129_6_head = Path::from_slice(&[v129_6_byte]);
          let v130_2: Space = singleton(&(v129_6_head));
          let v130_3: Space = intersect(&(*CONSTANT_3),&(v130_2));
          let v130_4: Space = if has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
          drop(v130_3);
          let v130_5: Space = subtract(&(*CONSTANT_0),&(v130_4));
          drop(v130_4);
          let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
            let v131_6: Path = concat_path(&(v127_3_head),&(v129_6_head));
            let v131_7: Space = routine_8(c, &(v131_6), &(v129_6_tail).make_space());
            drop(v131_6);
            compose(&(v130_5),&(v131_7))
          };
          drop(v130_5);
          let v130_9: Space = intersect(&(*CONSTANT_3),&(v130_2));
          drop(v130_2);
          let v130_10: Space = if has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
          drop(v130_9);
          let v130_11: Space = compose(&(v130_10),&(v129_6_tail));
          drop(v130_10);
          let v130_12: Space = unite(&(v130_8),&(v130_11));
          drop(v130_11);
          v129_6.join_into((v130_12).clone());
          }
          v129_6_cursor.ascend(1);
        }
        drop(v129_6_cursor);
        compose(&(v128_5),&(v129_6))
      };
      drop(v128_5);
      let v128_8: Space = intersect(&(*CONSTANT_3),&(v128_2));
      drop(v128_2);
      let v128_9: Space = if has_head(&(v128_8)) { singleton(&[]) } else { Space::new() };
      drop(v128_8);
      let v128_10: Space = compose(&(v128_9),&(v127_3_tail));
      drop(v128_9);
      let v128_11: Space = unite(&(v128_7),&(v128_10));
      drop(v128_10);
      v127_3.join_into((v128_11).clone());
      }
      v127_3_cursor.ascend(1);
    }
    drop(v127_3_cursor);
    drop(v127_2);
    let v127_4: Space = unite(&(v127_3),&(v50_120));
    let v127_5: Space = intersect(&(v127_4),&(*capture_2));
    if !v50_120.join_into((v127_5).clone()).is_element() { break; }
  }
  let mut v50_127: Space = ((*capture_3)).clone();
  loop {
    let v132_1: Space = intersect(&(v50_127),&(*capture_2));
    let v132_2: Space = restrict_to(&(*capture_1),&(v132_1));
    drop(v132_1);
    let mut v132_3 = Space::new();
    let mut v132_3_cursor = (v132_2).read_zipper();
    for v132_3_byte in v132_3_cursor.child_mask().iter() {
      v132_3_cursor.descend_to_byte(v132_3_byte);
      {
      let v132_3_tail = v132_3_cursor.fork_read_zipper();
      let v132_3_head = Path::from_slice(&[v132_3_byte]);
      let v133_2: Space = singleton(&(v132_3_head));
      let v133_3: Space = intersect(&(*CONSTANT_3),&(v133_2));
      let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
      drop(v133_3);
      let v133_5: Space = subtract(&(*CONSTANT_0),&(v133_4));
      drop(v133_4);
      let v133_7: Space = if (v133_5).is_empty() { Space::new() } else {
        let mut v134_6 = Space::new();
        let mut v134_6_cursor = (v132_3_tail).read_zipper();
        for v134_6_byte in v134_6_cursor.child_mask().iter() {
          v134_6_cursor.descend_to_byte(v134_6_byte);
          {
          let v134_6_tail = v134_6_cursor.fork_read_zipper();
          let v134_6_head = Path::from_slice(&[v134_6_byte]);
          let v135_2: Space = singleton(&(v134_6_head));
          let v135_3: Space = intersect(&(*CONSTANT_3),&(v135_2));
          let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
          drop(v135_3);
          let v135_5: Space = subtract(&(*CONSTANT_0),&(v135_4));
          drop(v135_4);
          let v135_8: Space = if (v135_5).is_empty() { Space::new() } else {
            let v136_6: Path = concat_path(&(v132_3_head),&(v134_6_head));
            let v136_7: Space = routine_8(c, &(v136_6), &(v134_6_tail).make_space());
            drop(v136_6);
            compose(&(v135_5),&(v136_7))
          };
          drop(v135_5);
          let v135_9: Space = intersect(&(*CONSTANT_3),&(v135_2));
          drop(v135_2);
          let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
          drop(v135_9);
          let v135_11: Space = compose(&(v135_10),&(v134_6_tail));
          drop(v135_10);
          let v135_12: Space = unite(&(v135_8),&(v135_11));
          drop(v135_11);
          v134_6.join_into((v135_12).clone());
          }
          v134_6_cursor.ascend(1);
        }
        drop(v134_6_cursor);
        compose(&(v133_5),&(v134_6))
      };
      drop(v133_5);
      let v133_8: Space = intersect(&(*CONSTANT_3),&(v133_2));
      drop(v133_2);
      let v133_9: Space = if has_head(&(v133_8)) { singleton(&[]) } else { Space::new() };
      drop(v133_8);
      let v133_10: Space = compose(&(v133_9),&(v132_3_tail));
      drop(v133_9);
      let v133_11: Space = unite(&(v133_7),&(v133_10));
      drop(v133_10);
      v132_3.join_into((v133_11).clone());
      }
      v132_3_cursor.ascend(1);
    }
    drop(v132_3_cursor);
    drop(v132_2);
    let v132_4: Space = unite(&(v132_3),&(v50_127));
    let v132_5: Space = intersect(&(v132_4),&(*capture_2));
    if !v50_127.join_into((v132_5).clone()).is_element() { break; }
  }
  let v50_128: Space = subtract(&(v50_120),&(v50_127));
  let v50_129: Space = range_const::<{0},{1}>(&(v50_128));
  let mut v50_157 = Space::new();
  let mut v50_157_cursor = (v50_129).read_zipper();
  for v50_157_byte in v50_157_cursor.child_mask().iter() {
    v50_157_cursor.descend_to_byte(v50_157_byte);
    {
    let v50_157_tail = v50_157_cursor.fork_read_zipper();
    let v50_157_head = Path::from_slice(&[v50_157_byte]);
    let v137_2: Space = singleton(&(v50_157_head));
    let v137_3: Space = intersect(&(*CONSTANT_3),&(v137_2));
    let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
    drop(v137_3);
    let v137_5: Space = subtract(&(*CONSTANT_0),&(v137_4));
    drop(v137_4);
    let v137_10: Space = if (v137_5).is_empty() { Space::new() } else {
      let mut v138_6: Space = ((*capture_3)).clone();
      loop {
        let v139_1: Space = intersect(&(v138_6),&(*capture_2));
        let v139_2: Space = restrict_to(&(*capture_0),&(v139_1));
        drop(v139_1);
        let mut v139_3 = Space::new();
        let mut v139_3_cursor = (v139_2).read_zipper();
        for v139_3_byte in v139_3_cursor.child_mask().iter() {
          v139_3_cursor.descend_to_byte(v139_3_byte);
          {
          let v139_3_tail = v139_3_cursor.fork_read_zipper();
          let v139_3_head = Path::from_slice(&[v139_3_byte]);
          let v140_2: Space = singleton(&(v139_3_head));
          let v140_3: Space = intersect(&(*CONSTANT_3),&(v140_2));
          let v140_4: Space = if has_head(&(v140_3)) { singleton(&[]) } else { Space::new() };
          drop(v140_3);
          let v140_5: Space = subtract(&(*CONSTANT_0),&(v140_4));
          drop(v140_4);
          let v140_7: Space = if (v140_5).is_empty() { Space::new() } else {
            let mut v141_6 = Space::new();
            let mut v141_6_cursor = (v139_3_tail).read_zipper();
            for v141_6_byte in v141_6_cursor.child_mask().iter() {
              v141_6_cursor.descend_to_byte(v141_6_byte);
              {
              let v141_6_tail = v141_6_cursor.fork_read_zipper();
              let v141_6_head = Path::from_slice(&[v141_6_byte]);
              let v142_2: Space = singleton(&(v141_6_head));
              let v142_3: Space = intersect(&(*CONSTANT_3),&(v142_2));
              let v142_4: Space = if has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
              drop(v142_3);
              let v142_5: Space = subtract(&(*CONSTANT_0),&(v142_4));
              drop(v142_4);
              let v142_8: Space = if (v142_5).is_empty() { Space::new() } else {
                let v143_6: Path = concat_path(&(v139_3_head),&(v141_6_head));
                let v143_7: Space = routine_8(c, &(v143_6), &(v141_6_tail).make_space());
                drop(v143_6);
                compose(&(v142_5),&(v143_7))
              };
              drop(v142_5);
              let v142_9: Space = intersect(&(*CONSTANT_3),&(v142_2));
              drop(v142_2);
              let v142_10: Space = if has_head(&(v142_9)) { singleton(&[]) } else { Space::new() };
              drop(v142_9);
              let v142_11: Space = compose(&(v142_10),&(v141_6_tail));
              drop(v142_10);
              let v142_12: Space = unite(&(v142_8),&(v142_11));
              drop(v142_11);
              v141_6.join_into((v142_12).clone());
              }
              v141_6_cursor.ascend(1);
            }
            drop(v141_6_cursor);
            compose(&(v140_5),&(v141_6))
          };
          drop(v140_5);
          let v140_8: Space = intersect(&(*CONSTANT_3),&(v140_2));
          drop(v140_2);
          let v140_9: Space = if has_head(&(v140_8)) { singleton(&[]) } else { Space::new() };
          drop(v140_8);
          let v140_10: Space = compose(&(v140_9),&(v139_3_tail));
          drop(v140_9);
          let v140_11: Space = unite(&(v140_7),&(v140_10));
          drop(v140_10);
          v139_3.join_into((v140_11).clone());
          }
          v139_3_cursor.ascend(1);
        }
        drop(v139_3_cursor);
        drop(v139_2);
        let v139_4: Space = unite(&(v139_3),&(v138_6));
        let v139_5: Space = intersect(&(v139_4),&(*capture_2));
        if !v138_6.join_into((v139_5).clone()).is_element() { break; }
      }
      let mut v138_7: Space = ((*capture_3)).clone();
      loop {
        let v144_1: Space = intersect(&(v138_7),&(*capture_2));
        let v144_2: Space = restrict_to(&(*capture_1),&(v144_1));
        drop(v144_1);
        let mut v144_3 = Space::new();
        let mut v144_3_cursor = (v144_2).read_zipper();
        for v144_3_byte in v144_3_cursor.child_mask().iter() {
          v144_3_cursor.descend_to_byte(v144_3_byte);
          {
          let v144_3_tail = v144_3_cursor.fork_read_zipper();
          let v144_3_head = Path::from_slice(&[v144_3_byte]);
          let v145_2: Space = singleton(&(v144_3_head));
          let v145_3: Space = intersect(&(*CONSTANT_3),&(v145_2));
          let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
          drop(v145_3);
          let v145_5: Space = subtract(&(*CONSTANT_0),&(v145_4));
          drop(v145_4);
          let v145_7: Space = if (v145_5).is_empty() { Space::new() } else {
            let mut v146_6 = Space::new();
            let mut v146_6_cursor = (v144_3_tail).read_zipper();
            for v146_6_byte in v146_6_cursor.child_mask().iter() {
              v146_6_cursor.descend_to_byte(v146_6_byte);
              {
              let v146_6_tail = v146_6_cursor.fork_read_zipper();
              let v146_6_head = Path::from_slice(&[v146_6_byte]);
              let v147_2: Space = singleton(&(v146_6_head));
              let v147_3: Space = intersect(&(*CONSTANT_3),&(v147_2));
              let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
              drop(v147_3);
              let v147_5: Space = subtract(&(*CONSTANT_0),&(v147_4));
              drop(v147_4);
              let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
                let v148_6: Path = concat_path(&(v144_3_head),&(v146_6_head));
                let v148_7: Space = routine_8(c, &(v148_6), &(v146_6_tail).make_space());
                drop(v148_6);
                compose(&(v147_5),&(v148_7))
              };
              drop(v147_5);
              let v147_9: Space = intersect(&(*CONSTANT_3),&(v147_2));
              drop(v147_2);
              let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
              drop(v147_9);
              let v147_11: Space = compose(&(v147_10),&(v146_6_tail));
              drop(v147_10);
              let v147_12: Space = unite(&(v147_8),&(v147_11));
              drop(v147_11);
              v146_6.join_into((v147_12).clone());
              }
              v146_6_cursor.ascend(1);
            }
            drop(v146_6_cursor);
            compose(&(v145_5),&(v146_6))
          };
          drop(v145_5);
          let v145_8: Space = intersect(&(*CONSTANT_3),&(v145_2));
          drop(v145_2);
          let v145_9: Space = if has_head(&(v145_8)) { singleton(&[]) } else { Space::new() };
          drop(v145_8);
          let v145_10: Space = compose(&(v145_9),&(v144_3_tail));
          drop(v145_9);
          let v145_11: Space = unite(&(v145_7),&(v145_10));
          drop(v145_10);
          v144_3.join_into((v145_11).clone());
          }
          v144_3_cursor.ascend(1);
        }
        drop(v144_3_cursor);
        drop(v144_2);
        let v144_4: Space = unite(&(v144_3),&(v138_7));
        let v144_5: Space = intersect(&(v144_4),&(*capture_2));
        if !v138_7.join_into((v144_5).clone()).is_element() { break; }
      }
      let v138_8: Space = subtract(&(v138_6),&(v138_7));
      let v138_9: Space = routine_4(c, &(v50_157_head), &(v50_157_tail).make_space(), &(*capture_0), &(*capture_1), &(v138_8));
      compose(&(v137_5),&(v138_9))
    };
    drop(v137_5);
    let v137_11: Space = intersect(&(*CONSTANT_3),&(v137_2));
    drop(v137_2);
    let v137_12: Space = if has_head(&(v137_11)) { singleton(&[]) } else { Space::new() };
    drop(v137_11);
    let v137_17: Space = if (v137_12).is_empty() { Space::new() } else {
      let mut v149_13: Space = ((*capture_3)).clone();
      loop {
        let v150_1: Space = intersect(&(v149_13),&(*capture_2));
        let v150_2: Space = restrict_to(&(*capture_0),&(v150_1));
        drop(v150_1);
        let mut v150_3 = Space::new();
        let mut v150_3_cursor = (v150_2).read_zipper();
        for v150_3_byte in v150_3_cursor.child_mask().iter() {
          v150_3_cursor.descend_to_byte(v150_3_byte);
          {
          let v150_3_tail = v150_3_cursor.fork_read_zipper();
          let v150_3_head = Path::from_slice(&[v150_3_byte]);
          let v151_2: Space = singleton(&(v150_3_head));
          let v151_3: Space = intersect(&(*CONSTANT_3),&(v151_2));
          let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
          drop(v151_3);
          let v151_5: Space = subtract(&(*CONSTANT_0),&(v151_4));
          drop(v151_4);
          let v151_7: Space = if (v151_5).is_empty() { Space::new() } else {
            let mut v152_6 = Space::new();
            let mut v152_6_cursor = (v150_3_tail).read_zipper();
            for v152_6_byte in v152_6_cursor.child_mask().iter() {
              v152_6_cursor.descend_to_byte(v152_6_byte);
              {
              let v152_6_tail = v152_6_cursor.fork_read_zipper();
              let v152_6_head = Path::from_slice(&[v152_6_byte]);
              let v153_2: Space = singleton(&(v152_6_head));
              let v153_3: Space = intersect(&(*CONSTANT_3),&(v153_2));
              let v153_4: Space = if has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
              drop(v153_3);
              let v153_5: Space = subtract(&(*CONSTANT_0),&(v153_4));
              drop(v153_4);
              let v153_8: Space = if (v153_5).is_empty() { Space::new() } else {
                let v154_6: Path = concat_path(&(v150_3_head),&(v152_6_head));
                let v154_7: Space = routine_8(c, &(v154_6), &(v152_6_tail).make_space());
                drop(v154_6);
                compose(&(v153_5),&(v154_7))
              };
              drop(v153_5);
              let v153_9: Space = intersect(&(*CONSTANT_3),&(v153_2));
              drop(v153_2);
              let v153_10: Space = if has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
              drop(v153_9);
              let v153_11: Space = compose(&(v153_10),&(v152_6_tail));
              drop(v153_10);
              let v153_12: Space = unite(&(v153_8),&(v153_11));
              drop(v153_11);
              v152_6.join_into((v153_12).clone());
              }
              v152_6_cursor.ascend(1);
            }
            drop(v152_6_cursor);
            compose(&(v151_5),&(v152_6))
          };
          drop(v151_5);
          let v151_8: Space = intersect(&(*CONSTANT_3),&(v151_2));
          drop(v151_2);
          let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
          drop(v151_8);
          let v151_10: Space = compose(&(v151_9),&(v150_3_tail));
          drop(v151_9);
          let v151_11: Space = unite(&(v151_7),&(v151_10));
          drop(v151_10);
          v150_3.join_into((v151_11).clone());
          }
          v150_3_cursor.ascend(1);
        }
        drop(v150_3_cursor);
        drop(v150_2);
        let v150_4: Space = unite(&(v150_3),&(v149_13));
        let v150_5: Space = intersect(&(v150_4),&(*capture_2));
        if !v149_13.join_into((v150_5).clone()).is_element() { break; }
      }
      let mut v149_14: Space = ((*capture_3)).clone();
      loop {
        let v155_1: Space = intersect(&(v149_14),&(*capture_2));
        let v155_2: Space = restrict_to(&(*capture_1),&(v155_1));
        drop(v155_1);
        let mut v155_3 = Space::new();
        let mut v155_3_cursor = (v155_2).read_zipper();
        for v155_3_byte in v155_3_cursor.child_mask().iter() {
          v155_3_cursor.descend_to_byte(v155_3_byte);
          {
          let v155_3_tail = v155_3_cursor.fork_read_zipper();
          let v155_3_head = Path::from_slice(&[v155_3_byte]);
          let v156_2: Space = singleton(&(v155_3_head));
          let v156_3: Space = intersect(&(*CONSTANT_3),&(v156_2));
          let v156_4: Space = if has_head(&(v156_3)) { singleton(&[]) } else { Space::new() };
          drop(v156_3);
          let v156_5: Space = subtract(&(*CONSTANT_0),&(v156_4));
          drop(v156_4);
          let v156_7: Space = if (v156_5).is_empty() { Space::new() } else {
            let mut v157_6 = Space::new();
            let mut v157_6_cursor = (v155_3_tail).read_zipper();
            for v157_6_byte in v157_6_cursor.child_mask().iter() {
              v157_6_cursor.descend_to_byte(v157_6_byte);
              {
              let v157_6_tail = v157_6_cursor.fork_read_zipper();
              let v157_6_head = Path::from_slice(&[v157_6_byte]);
              let v158_2: Space = singleton(&(v157_6_head));
              let v158_3: Space = intersect(&(*CONSTANT_3),&(v158_2));
              let v158_4: Space = if has_head(&(v158_3)) { singleton(&[]) } else { Space::new() };
              drop(v158_3);
              let v158_5: Space = subtract(&(*CONSTANT_0),&(v158_4));
              drop(v158_4);
              let v158_8: Space = if (v158_5).is_empty() { Space::new() } else {
                let v159_6: Path = concat_path(&(v155_3_head),&(v157_6_head));
                let v159_7: Space = routine_8(c, &(v159_6), &(v157_6_tail).make_space());
                drop(v159_6);
                compose(&(v158_5),&(v159_7))
              };
              drop(v158_5);
              let v158_9: Space = intersect(&(*CONSTANT_3),&(v158_2));
              drop(v158_2);
              let v158_10: Space = if has_head(&(v158_9)) { singleton(&[]) } else { Space::new() };
              drop(v158_9);
              let v158_11: Space = compose(&(v158_10),&(v157_6_tail));
              drop(v158_10);
              let v158_12: Space = unite(&(v158_8),&(v158_11));
              drop(v158_11);
              v157_6.join_into((v158_12).clone());
              }
              v157_6_cursor.ascend(1);
            }
            drop(v157_6_cursor);
            compose(&(v156_5),&(v157_6))
          };
          drop(v156_5);
          let v156_8: Space = intersect(&(*CONSTANT_3),&(v156_2));
          drop(v156_2);
          let v156_9: Space = if has_head(&(v156_8)) { singleton(&[]) } else { Space::new() };
          drop(v156_8);
          let v156_10: Space = compose(&(v156_9),&(v155_3_tail));
          drop(v156_9);
          let v156_11: Space = unite(&(v156_7),&(v156_10));
          drop(v156_10);
          v155_3.join_into((v156_11).clone());
          }
          v155_3_cursor.ascend(1);
        }
        drop(v155_3_cursor);
        drop(v155_2);
        let v155_4: Space = unite(&(v155_3),&(v149_14));
        let v155_5: Space = intersect(&(v155_4),&(*capture_2));
        if !v149_14.join_into((v155_5).clone()).is_element() { break; }
      }
      let v149_15: Space = subtract(&(v149_13),&(v149_14));
      let v149_16: Space = routine_5(c, &(v50_157_head), &(v50_157_tail).make_space(), &(*capture_0), &(*capture_1), &(v149_15));
      compose(&(v137_12),&(v149_16))
    };
    drop(v137_12);
    let v137_18: Space = unite(&(v137_10),&(v137_17));
    v50_157.join_into((v137_18).clone());
    }
    v50_157_cursor.ascend(1);
  }
  drop(v50_157_cursor);

((v50_112).clone(),(v50_113).clone(),(v50_120).clone(),(v50_127).clone(),(v50_128).clone(),(v50_129).clone(),(v50_157).clone(),(v50_82).clone(),(v50_83).clone(),(v50_84).clone(),)
}

fn routine_0(c: &mut Context) -> Space {
  let v0_32: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
    let v1_31: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
      let v2_30: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v3_6: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2), &(*CONSTANT_3));
        let v3_10: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_5), &(*CONSTANT_3));
        let v3_11: Space = unite(&(v3_6),&(v3_10));
        let v3_14: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_2), &(*CONSTANT_3));
        let v3_15: Space = unite(&(v3_11),&(v3_14));
        let v3_18: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_7), &(*CONSTANT_3));
        let v3_19: Space = unite(&(v3_15),&(v3_18));
        let v3_23: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_9), &(*CONSTANT_3));
        let v3_24: Space = unite(&(v3_19),&(v3_23));
        let v3_28: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_3));
        let v3_29: Space = unite(&(v3_24),&(v3_28));
        compose(&(*CONSTANT_0),&(v3_29))
      };
      compose(&(*CONSTANT_0),&(v2_30))
    };
    compose(&(*CONSTANT_0),&(v1_31))
  };
  let mut v0_39 = Space::new();
  let mut v0_39_cursor = (v0_32).read_zipper();
  for v0_39_byte in v0_39_cursor.child_mask().iter() {
    v0_39_cursor.descend_to_byte(v0_39_byte);
    {
    let v0_39_tail = v0_39_cursor.fork_read_zipper();
    let v0_39_head = Path::from_slice(&[v0_39_byte]);
    let v4_2: Space = singleton(&(v0_39_head));
    let v4_3: Space = intersect(&(*CONSTANT_3),&(v4_2));
    let v4_4: Space = if has_head(&(v4_3)) { singleton(&[]) } else { Space::new() };
    drop(v4_3);
    let v4_5: Space = subtract(&(*CONSTANT_0),&(v4_4));
    drop(v4_4);
    let v4_7: Space = if (v4_5).is_empty() { Space::new() } else {
      let mut v5_6 = Space::new();
      let mut v5_6_cursor = (v0_39_tail).read_zipper();
      for v5_6_byte in v5_6_cursor.child_mask().iter() {
        v5_6_cursor.descend_to_byte(v5_6_byte);
        {
        let v5_6_tail = v5_6_cursor.fork_read_zipper();
        let v5_6_head = Path::from_slice(&[v5_6_byte]);
        let v6_2: Space = singleton(&(v5_6_head));
        let v6_3: Space = intersect(&(*CONSTANT_3),&(v6_2));
        let v6_4: Space = if has_head(&(v6_3)) { singleton(&[]) } else { Space::new() };
        drop(v6_3);
        let v6_5: Space = subtract(&(*CONSTANT_0),&(v6_4));
        drop(v6_4);
        let v6_8: Space = if (v6_5).is_empty() { Space::new() } else {
          let v7_6: Path = concat_path(&(v0_39_head),&(v5_6_head));
          let v7_7: Space = routine_2(c, &(v7_6), &(v5_6_tail).make_space());
          compose(&(v6_5),&(v7_7))
        };
        drop(v6_5);
        let v6_9: Space = intersect(&(*CONSTANT_3),&(v6_2));
        drop(v6_2);
        let v6_10: Space = if has_head(&(v6_9)) { singleton(&[]) } else { Space::new() };
        drop(v6_9);
        let v8_6: Path = concat_path(&(v0_39_head),&(v5_6_head));
        let v6_11: Space = singleton(&(v8_6));
        let v6_12: Space = compose(&(v6_10),&(v6_11));
        drop(v6_10);
        drop(v6_11);
        let v6_13: Space = unite(&(v6_8),&(v6_12));
        drop(v6_12);
        v5_6.join_into((v6_13).clone());
        }
        v5_6_cursor.ascend(1);
      }
      drop(v5_6_cursor);
      compose(&(v4_5),&(v5_6))
    };
    drop(v4_5);
    let v4_8: Space = intersect(&(*CONSTANT_3),&(v4_2));
    let v4_9: Space = if has_head(&(v4_8)) { singleton(&[]) } else { Space::new() };
    drop(v4_8);
    let v4_10: Space = compose(&(v4_9),&(v4_2));
    drop(v4_2);
    drop(v4_9);
    let v4_11: Space = unite(&(v4_7),&(v4_10));
    drop(v4_10);
    v0_39.join_into((v4_11).clone());
    }
    v0_39_cursor.ascend(1);
  }
  drop(v0_39_cursor);
  let v0_41: Space = unite(&(v0_39),&(*CONSTANT_12));
  let v0_42: Space = range_const::<{0},{1}>(&(v0_41));
  let mut v0_98 = Space::new();
  let mut v0_98_cursor = (v0_42).read_zipper();
  for v0_98_byte in v0_98_cursor.child_mask().iter() {
    v0_98_cursor.descend_to_byte(v0_98_byte);
    {
    let v0_98_tail = v0_98_cursor.fork_read_zipper();
    let v0_98_head = Path::from_slice(&[v0_98_byte]);
    let v9_2: Space = singleton(&(v0_98_head));
    let v9_3: Space = intersect(&(*CONSTANT_3),&(v9_2));
    let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
    drop(v9_3);
    let v9_5: Space = subtract(&(*CONSTANT_0),&(v9_4));
    drop(v9_4);
    let v9_37: Space = if (v9_5).is_empty() { Space::new() } else {
      let v10_19: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v11_18: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v12_17: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
            let v13_6: Space = routine_3(c, &(*CONSTANT_1), &(*CONSTANT_2), &(*CONSTANT_3));
            let v13_7: Space = routine_3(c, &(*CONSTANT_4), &(*CONSTANT_5), &(*CONSTANT_3));
            let v13_8: Space = unite(&(v13_6),&(v13_7));
            let v13_9: Space = routine_3(c, &(*CONSTANT_6), &(*CONSTANT_2), &(*CONSTANT_3));
            let v13_10: Space = unite(&(v13_8),&(v13_9));
            let v13_11: Space = routine_3(c, &(*CONSTANT_6), &(*CONSTANT_7), &(*CONSTANT_3));
            let v13_12: Space = unite(&(v13_10),&(v13_11));
            let v13_13: Space = routine_3(c, &(*CONSTANT_8), &(*CONSTANT_9), &(*CONSTANT_3));
            let v13_14: Space = unite(&(v13_12),&(v13_13));
            let v13_15: Space = routine_3(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_3));
            let v13_16: Space = unite(&(v13_14),&(v13_15));
            compose(&(*CONSTANT_0),&(v13_16))
          };
          compose(&(*CONSTANT_0),&(v12_17))
        };
        compose(&(*CONSTANT_0),&(v11_18))
      };
      let v10_33: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v14_32: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v15_31: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
            let v16_20: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2), &(*CONSTANT_3));
            let v16_21: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_5), &(*CONSTANT_3));
            let v16_22: Space = unite(&(v16_20),&(v16_21));
            let v16_23: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_2), &(*CONSTANT_3));
            let v16_24: Space = unite(&(v16_22),&(v16_23));
            let v16_25: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_7), &(*CONSTANT_3));
            let v16_26: Space = unite(&(v16_24),&(v16_25));
            let v16_27: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_9), &(*CONSTANT_3));
            let v16_28: Space = unite(&(v16_26),&(v16_27));
            let v16_29: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_3));
            let v16_30: Space = unite(&(v16_28),&(v16_29));
            compose(&(*CONSTANT_0),&(v16_30))
          };
          compose(&(*CONSTANT_0),&(v15_31))
        };
        compose(&(*CONSTANT_0),&(v14_32))
      };
      let mut v10_34 = Space::new();
      let mut v10_34_cursor = (v10_33).read_zipper();
      for v10_34_byte in v10_34_cursor.child_mask().iter() {
        v10_34_cursor.descend_to_byte(v10_34_byte);
        {
        let v10_34_tail = v10_34_cursor.fork_read_zipper();
        let v10_34_head = Path::from_slice(&[v10_34_byte]);
        let v17_2: Space = singleton(&(v10_34_head));
        let v17_3: Space = intersect(&(*CONSTANT_3),&(v17_2));
        let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
        drop(v17_3);
        let v17_5: Space = subtract(&(*CONSTANT_0),&(v17_4));
        drop(v17_4);
        let v17_7: Space = if (v17_5).is_empty() { Space::new() } else {
          let mut v18_6 = Space::new();
          let mut v18_6_cursor = (v10_34_tail).read_zipper();
          for v18_6_byte in v18_6_cursor.child_mask().iter() {
            v18_6_cursor.descend_to_byte(v18_6_byte);
            {
            let v18_6_tail = v18_6_cursor.fork_read_zipper();
            let v18_6_head = Path::from_slice(&[v18_6_byte]);
            let v19_2: Space = singleton(&(v18_6_head));
            let v19_3: Space = intersect(&(*CONSTANT_3),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (v19_5).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v10_34_head),&(v18_6_head));
              let v20_7: Space = routine_2(c, &(v20_6), &(v18_6_tail).make_space());
              compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = intersect(&(*CONSTANT_3),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v21_6: Path = concat_path(&(v10_34_head),&(v18_6_head));
            let v19_11: Space = singleton(&(v21_6));
            let v19_12: Space = compose(&(v19_10),&(v19_11));
            drop(v19_10);
            drop(v19_11);
            let v19_13: Space = unite(&(v19_8),&(v19_12));
            drop(v19_12);
            v18_6.join_into((v19_13).clone());
            }
            v18_6_cursor.ascend(1);
          }
          drop(v18_6_cursor);
          compose(&(v17_5),&(v18_6))
        };
        drop(v17_5);
        let v17_8: Space = intersect(&(*CONSTANT_3),&(v17_2));
        let v17_9: Space = if has_head(&(v17_8)) { singleton(&[]) } else { Space::new() };
        drop(v17_8);
        let v17_10: Space = compose(&(v17_9),&(v17_2));
        drop(v17_2);
        drop(v17_9);
        let v17_11: Space = unite(&(v17_7),&(v17_10));
        drop(v17_10);
        v10_34.join_into((v17_11).clone());
        }
        v10_34_cursor.ascend(1);
      }
      drop(v10_34_cursor);
      let v10_35: Space = unite(&(v10_34),&(*CONSTANT_12));
      let v10_36: Space = routine_4(c, &(v0_98_head), &(v0_98_tail).make_space(), &(v10_19), &(*CONSTANT_13), &(v10_35));
      compose(&(v9_5),&(v10_36))
    };
    drop(v9_5);
    let v9_38: Space = intersect(&(*CONSTANT_3),&(v9_2));
    drop(v9_2);
    let v9_39: Space = if has_head(&(v9_38)) { singleton(&[]) } else { Space::new() };
    drop(v9_38);
    let v9_71: Space = if (v9_39).is_empty() { Space::new() } else {
      let v22_53: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v23_52: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v24_51: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
            let v25_40: Space = routine_3(c, &(*CONSTANT_1), &(*CONSTANT_2), &(*CONSTANT_3));
            let v25_41: Space = routine_3(c, &(*CONSTANT_4), &(*CONSTANT_5), &(*CONSTANT_3));
            let v25_42: Space = unite(&(v25_40),&(v25_41));
            let v25_43: Space = routine_3(c, &(*CONSTANT_6), &(*CONSTANT_2), &(*CONSTANT_3));
            let v25_44: Space = unite(&(v25_42),&(v25_43));
            let v25_45: Space = routine_3(c, &(*CONSTANT_6), &(*CONSTANT_7), &(*CONSTANT_3));
            let v25_46: Space = unite(&(v25_44),&(v25_45));
            let v25_47: Space = routine_3(c, &(*CONSTANT_8), &(*CONSTANT_9), &(*CONSTANT_3));
            let v25_48: Space = unite(&(v25_46),&(v25_47));
            let v25_49: Space = routine_3(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_3));
            let v25_50: Space = unite(&(v25_48),&(v25_49));
            compose(&(*CONSTANT_0),&(v25_50))
          };
          compose(&(*CONSTANT_0),&(v24_51))
        };
        compose(&(*CONSTANT_0),&(v23_52))
      };
      let v22_67: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
        let v26_66: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
          let v27_65: Space = if (*CONSTANT_0).is_empty() { Space::new() } else {
            let v28_54: Space = routine_1(c, &(*CONSTANT_1), &(*CONSTANT_2), &(*CONSTANT_3));
            let v28_55: Space = routine_1(c, &(*CONSTANT_4), &(*CONSTANT_5), &(*CONSTANT_3));
            let v28_56: Space = unite(&(v28_54),&(v28_55));
            let v28_57: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_2), &(*CONSTANT_3));
            let v28_58: Space = unite(&(v28_56),&(v28_57));
            let v28_59: Space = routine_1(c, &(*CONSTANT_6), &(*CONSTANT_7), &(*CONSTANT_3));
            let v28_60: Space = unite(&(v28_58),&(v28_59));
            let v28_61: Space = routine_1(c, &(*CONSTANT_8), &(*CONSTANT_9), &(*CONSTANT_3));
            let v28_62: Space = unite(&(v28_60),&(v28_61));
            let v28_63: Space = routine_1(c, &(*CONSTANT_10), &(*CONSTANT_11), &(*CONSTANT_3));
            let v28_64: Space = unite(&(v28_62),&(v28_63));
            compose(&(*CONSTANT_0),&(v28_64))
          };
          compose(&(*CONSTANT_0),&(v27_65))
        };
        compose(&(*CONSTANT_0),&(v26_66))
      };
      let mut v22_68 = Space::new();
      let mut v22_68_cursor = (v22_67).read_zipper();
      for v22_68_byte in v22_68_cursor.child_mask().iter() {
        v22_68_cursor.descend_to_byte(v22_68_byte);
        {
        let v22_68_tail = v22_68_cursor.fork_read_zipper();
        let v22_68_head = Path::from_slice(&[v22_68_byte]);
        let v29_2: Space = singleton(&(v22_68_head));
        let v29_3: Space = intersect(&(*CONSTANT_3),&(v29_2));
        let v29_4: Space = if has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
        drop(v29_3);
        let v29_5: Space = subtract(&(*CONSTANT_0),&(v29_4));
        drop(v29_4);
        let v29_7: Space = if (v29_5).is_empty() { Space::new() } else {
          let mut v30_6 = Space::new();
          let mut v30_6_cursor = (v22_68_tail).read_zipper();
          for v30_6_byte in v30_6_cursor.child_mask().iter() {
            v30_6_cursor.descend_to_byte(v30_6_byte);
            {
            let v30_6_tail = v30_6_cursor.fork_read_zipper();
            let v30_6_head = Path::from_slice(&[v30_6_byte]);
            let v31_2: Space = singleton(&(v30_6_head));
            let v31_3: Space = intersect(&(*CONSTANT_3),&(v31_2));
            let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
            drop(v31_3);
            let v31_5: Space = subtract(&(*CONSTANT_0),&(v31_4));
            drop(v31_4);
            let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
              let v32_6: Path = concat_path(&(v22_68_head),&(v30_6_head));
              let v32_7: Space = routine_2(c, &(v32_6), &(v30_6_tail).make_space());
              compose(&(v31_5),&(v32_7))
            };
            drop(v31_5);
            let v31_9: Space = intersect(&(*CONSTANT_3),&(v31_2));
            drop(v31_2);
            let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
            drop(v31_9);
            let v33_6: Path = concat_path(&(v22_68_head),&(v30_6_head));
            let v31_11: Space = singleton(&(v33_6));
            let v31_12: Space = compose(&(v31_10),&(v31_11));
            drop(v31_10);
            drop(v31_11);
            let v31_13: Space = unite(&(v31_8),&(v31_12));
            drop(v31_12);
            v30_6.join_into((v31_13).clone());
            }
            v30_6_cursor.ascend(1);
          }
          drop(v30_6_cursor);
          compose(&(v29_5),&(v30_6))
        };
        drop(v29_5);
        let v29_8: Space = intersect(&(*CONSTANT_3),&(v29_2));
        let v29_9: Space = if has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
        drop(v29_8);
        let v29_10: Space = compose(&(v29_9),&(v29_2));
        drop(v29_2);
        drop(v29_9);
        let v29_11: Space = unite(&(v29_7),&(v29_10));
        drop(v29_10);
        v22_68.join_into((v29_11).clone());
        }
        v22_68_cursor.ascend(1);
      }
      drop(v22_68_cursor);
      let v22_69: Space = unite(&(v22_68),&(*CONSTANT_12));
      let v22_70: Space = routine_5(c, &(v0_98_head), &(v0_98_tail).make_space(), &(v22_53), &(*CONSTANT_13), &(v22_69));
      compose(&(v9_39),&(v22_70))
    };
    drop(v9_39);
    let v9_72: Space = unite(&(v9_37),&(v9_71));
    v0_98.join_into((v9_72).clone());
    }
    v0_98_cursor.ascend(1);
  }
  drop(v0_98_cursor);
  (v0_98).clone()
}

fn routine_1(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v34_6 = Space::new();
  let mut v34_6_cursor = (*s0).read_zipper();
  for v34_6_byte in v34_6_cursor.child_mask().iter() {
    v34_6_cursor.descend_to_byte(v34_6_byte);
    {
    let v34_6_tail = v34_6_cursor.fork_read_zipper();
    let v34_6_head = Path::from_slice(&[v34_6_byte]);
    let v35_2: Space = singleton(&(v34_6_head));
    let v35_3: Space = intersect(&(*CONSTANT_3),&(v35_2));
    let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
    drop(v35_3);
    let v35_5: Space = subtract(&(*CONSTANT_0),&(v35_4));
    drop(v35_4);
    let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
      let v36_6: Path = concat_path(&(*p0),&(v34_6_head));
      let v36_7: Space = routine_1(c, &(v36_6), &(*p1), &(v34_6_tail).make_space());
      compose(&(v35_5),&(v36_7))
    };
    drop(v35_5);
    let v35_9: Space = intersect(&(*CONSTANT_3),&(v35_2));
    drop(v35_2);
    let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
    drop(v35_9);
    let v35_13: Space = if (v35_10).is_empty() { Space::new() } else {
      let v37_6: Path = concat_path(&(*p0),&(v34_6_head));
      let v37_11: Path = concat_path(&(v37_6),&(*p1));
      drop(v37_6);
      let v37_12: Space = singleton(&(v37_11));
      drop(v37_11);
      compose(&(v35_10),&(v37_12))
    };
    drop(v35_10);
    let v35_14: Space = unite(&(v35_8),&(v35_13));
    drop(v35_13);
    v34_6.join_into((v35_14).clone());
    }
    v34_6_cursor.ascend(1);
  }
  drop(v34_6_cursor);
  (v34_6).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v38_5 = Space::new();
  let mut v38_5_cursor = (*s0).read_zipper();
  for v38_5_byte in v38_5_cursor.child_mask().iter() {
    v38_5_cursor.descend_to_byte(v38_5_byte);
    {
    let v38_5_tail = v38_5_cursor.fork_read_zipper();
    let v38_5_head = Path::from_slice(&[v38_5_byte]);
    let v39_2: Space = singleton(&(v38_5_head));
    let v39_3: Space = intersect(&(*CONSTANT_3),&(v39_2));
    let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
    drop(v39_3);
    let v39_5: Space = subtract(&(*CONSTANT_0),&(v39_4));
    drop(v39_4);
    let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
      let v40_6: Path = concat_path(&(*p0),&(v38_5_head));
      let v40_7: Space = routine_2(c, &(v40_6), &(v38_5_tail).make_space());
      compose(&(v39_5),&(v40_7))
    };
    drop(v39_5);
    let v39_9: Space = intersect(&(*CONSTANT_3),&(v39_2));
    drop(v39_2);
    let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
    drop(v39_9);
    let v39_12: Space = if (v39_10).is_empty() { Space::new() } else {
      let v41_6: Path = concat_path(&(*p0),&(v38_5_head));
      let v41_11: Space = singleton(&(v41_6));
      drop(v41_6);
      compose(&(v39_10),&(v41_11))
    };
    drop(v39_10);
    let v39_13: Space = unite(&(v39_8),&(v39_12));
    drop(v39_12);
    v38_5.join_into((v39_13).clone());
    }
    v38_5_cursor.ascend(1);
  }
  drop(v38_5_cursor);
  (v38_5).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v42_6 = Space::new();
  let mut v42_6_cursor = (*s0).read_zipper();
  for v42_6_byte in v42_6_cursor.child_mask().iter() {
    v42_6_cursor.descend_to_byte(v42_6_byte);
    {
    let v42_6_tail = v42_6_cursor.fork_read_zipper();
    let v42_6_head = Path::from_slice(&[v42_6_byte]);
    let v43_2: Space = singleton(&(v42_6_head));
    let v43_3: Space = intersect(&(*CONSTANT_3),&(v43_2));
    let v43_4: Space = if has_head(&(v43_3)) { singleton(&[]) } else { Space::new() };
    drop(v43_3);
    let v43_5: Space = subtract(&(*CONSTANT_0),&(v43_4));
    drop(v43_4);
    let v43_8: Space = if (v43_5).is_empty() { Space::new() } else {
      let v44_6: Path = concat_path(&(*p0),&(v42_6_head));
      let v44_7: Space = routine_3(c, &(v44_6), &(*p1), &(v42_6_tail).make_space());
      compose(&(v43_5),&(v44_7))
    };
    drop(v43_5);
    let v43_9: Space = intersect(&(*CONSTANT_3),&(v43_2));
    drop(v43_2);
    let v43_10: Space = if has_head(&(v43_9)) { singleton(&[]) } else { Space::new() };
    drop(v43_9);
    let v43_13: Space = if (v43_10).is_empty() { Space::new() } else {
      let v45_6: Path = concat_path(&(*p0),&(v42_6_head));
      let v45_11: Path = concat_path(&(v45_6),&(*p1));
      drop(v45_6);
      let v45_12: Space = singleton(&(v45_11));
      drop(v45_11);
      compose(&(v43_10),&(v45_12))
    };
    drop(v43_10);
    let v43_14: Space = unite(&(v43_8),&(v43_13));
    drop(v43_13);
    v42_6.join_into((v43_14).clone());
    }
    v42_6_cursor.ascend(1);
  }
  drop(v42_6_cursor);
  (v42_6).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let mut v46_8 = Space::new();
  let mut v46_8_cursor = (*s0).read_zipper();
  for v46_8_byte in v46_8_cursor.child_mask().iter() {
    v46_8_cursor.descend_to_byte(v46_8_byte);
    {
    let v46_8_tail = v46_8_cursor.fork_read_zipper();
    let v46_8_head = Path::from_slice(&[v46_8_byte]);
    let v47_2: Space = singleton(&(v46_8_head));
    let v47_3: Space = intersect(&(*CONSTANT_3),&(v47_2));
    let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
    drop(v47_3);
    let v47_5: Space = subtract(&(*CONSTANT_0),&(v47_4));
    drop(v47_4);
    let v47_8: Space = if (v47_5).is_empty() { Space::new() } else {
      let v48_6: Path = concat_path(&(*p0),&(v46_8_head));
      let v48_7: Space = routine_4(c, &(v48_6), &(v46_8_tail).make_space(), &(*s1), &(*s2), &(*s3));
      compose(&(v47_5),&(v48_7))
    };
    drop(v47_5);
    let v47_9: Space = intersect(&(*CONSTANT_3),&(v47_2));
    drop(v47_2);
    let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
    drop(v47_9);
    let v47_27: Space = if (v47_10).is_empty() { Space::new() } else {
      let v49_6: Path = concat_path(&(*p0),&(v46_8_head));
      let v49_11: Space = singleton(&(v49_6));
      let v49_12: Space = routine_6(c, &(*s1), &(*s3), &(v49_11));
      let v49_13: Space = routine_6(c, &(*s2), &(*s3), &(v49_11));
      let v49_14: Space = intersect(&(v49_12),&(v49_13));
      let v49_15: Space = subtract(&(v49_14),&(v49_11));
      drop(v49_11);
      let v49_16: Space = wrap(&(v49_15),&(v49_6));
      drop(v49_6);
      let v49_17: Space = subtract(&(*s3),&(v49_13));
      let v49_18: Space = subtract(&(v49_17),&(v49_12));
      let v49_19: Space = routine_7(c, &(*s2), &(*s1), &(v49_18));
      let v49_20: Space = unite(&(v49_16),&(v49_19));
      let v49_21: Space = subtract(&(v49_12),&(v49_13));
      let v49_22: Space = routine_7(c, &(*s2), &(*s1), &(v49_21));
      let v49_23: Space = unite(&(v49_20),&(v49_22));
      let v49_24: Space = subtract(&(v49_13),&(v49_12));
      let v49_25: Space = routine_7(c, &(*s2), &(*s1), &(v49_24));
      let v49_26: Space = unite(&(v49_23),&(v49_25));
      compose(&(v47_10),&(v49_26))
    };
    drop(v47_10);
    let v47_28: Space = unite(&(v47_8),&(v47_27));
    v46_8.join_into((v47_28).clone());
    }
    v46_8_cursor.ascend(1);
  }
  drop(v46_8_cursor);
  (v46_8).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space, s2: &Space, s3: &Space) -> Space {
  let (v50_12,v50_19,v50_20,v50_21,v50_22,v50_29,v50_30,v50_37,v50_38,v50_39,v50_5,v50_67,v50_68,v50_75,) = native_block_0(c, p0, s1, s2, s3);
  let (v50_112,v50_113,v50_120,v50_127,v50_128,v50_129,v50_157,v50_82,v50_83,v50_84,) = native_block_1(c, s1, s2, s3, &v50_5, &v50_68, &v50_75);
  drop(v50_5);
  let v50_158: Space = unite(&(v50_113),&(v50_157));
  (v50_158).clone()
}

fn routine_6(c: &mut Context, s0: &Space, s1: &Space, s2: &Space) -> Space {
  let v160_3: Space = intersect(&(*s1),&(*s2));
  let v160_4: Space = restrict_to(&(*s0),&(v160_3));
  drop(v160_3);
  let mut v160_11 = Space::new();
  let mut v160_11_cursor = (v160_4).read_zipper();
  for v160_11_byte in v160_11_cursor.child_mask().iter() {
    v160_11_cursor.descend_to_byte(v160_11_byte);
    {
    let v160_11_tail = v160_11_cursor.fork_read_zipper();
    let v160_11_head = Path::from_slice(&[v160_11_byte]);
    let v161_2: Space = singleton(&(v160_11_head));
    let v161_3: Space = intersect(&(*CONSTANT_3),&(v161_2));
    let v161_4: Space = if has_head(&(v161_3)) { singleton(&[]) } else { Space::new() };
    drop(v161_3);
    let v161_5: Space = subtract(&(*CONSTANT_0),&(v161_4));
    drop(v161_4);
    let v161_7: Space = if (v161_5).is_empty() { Space::new() } else {
      let mut v162_6 = Space::new();
      let mut v162_6_cursor = (v160_11_tail).read_zipper();
      for v162_6_byte in v162_6_cursor.child_mask().iter() {
        v162_6_cursor.descend_to_byte(v162_6_byte);
        {
        let v162_6_tail = v162_6_cursor.fork_read_zipper();
        let v162_6_head = Path::from_slice(&[v162_6_byte]);
        let v163_2: Space = singleton(&(v162_6_head));
        let v163_3: Space = intersect(&(*CONSTANT_3),&(v163_2));
        let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
        drop(v163_3);
        let v163_5: Space = subtract(&(*CONSTANT_0),&(v163_4));
        drop(v163_4);
        let v163_8: Space = if (v163_5).is_empty() { Space::new() } else {
          let v164_6: Path = concat_path(&(v160_11_head),&(v162_6_head));
          let v164_7: Space = routine_8(c, &(v164_6), &(v162_6_tail).make_space());
          drop(v164_6);
          compose(&(v163_5),&(v164_7))
        };
        drop(v163_5);
        let v163_9: Space = intersect(&(*CONSTANT_3),&(v163_2));
        drop(v163_2);
        let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
        drop(v163_9);
        let v163_11: Space = compose(&(v163_10),&(v162_6_tail));
        drop(v163_10);
        let v163_12: Space = unite(&(v163_8),&(v163_11));
        drop(v163_11);
        v162_6.join_into((v163_12).clone());
        }
        v162_6_cursor.ascend(1);
      }
      drop(v162_6_cursor);
      compose(&(v161_5),&(v162_6))
    };
    drop(v161_5);
    let v161_8: Space = intersect(&(*CONSTANT_3),&(v161_2));
    drop(v161_2);
    let v161_9: Space = if has_head(&(v161_8)) { singleton(&[]) } else { Space::new() };
    drop(v161_8);
    let v161_10: Space = compose(&(v161_9),&(v160_11_tail));
    drop(v161_9);
    let v161_11: Space = unite(&(v161_7),&(v161_10));
    drop(v161_10);
    v160_11.join_into((v161_11).clone());
    }
    v160_11_cursor.ascend(1);
  }
  drop(v160_11_cursor);
  drop(v160_4);
  let v160_12: Space = unite(&(v160_11),&(*s2));
  let v160_13: Space = intersect(&(v160_12),&(*s1));
  let mut v160_20: Space = (v160_13).clone();
  loop {
    let v165_1: Space = intersect(&(v160_20),&(*s1));
    let v165_2: Space = restrict_to(&(*s0),&(v165_1));
    drop(v165_1);
    let mut v165_3 = Space::new();
    let mut v165_3_cursor = (v165_2).read_zipper();
    for v165_3_byte in v165_3_cursor.child_mask().iter() {
      v165_3_cursor.descend_to_byte(v165_3_byte);
      {
      let v165_3_tail = v165_3_cursor.fork_read_zipper();
      let v165_3_head = Path::from_slice(&[v165_3_byte]);
      let v166_2: Space = singleton(&(v165_3_head));
      let v166_3: Space = intersect(&(*CONSTANT_3),&(v166_2));
      let v166_4: Space = if has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
      drop(v166_3);
      let v166_5: Space = subtract(&(*CONSTANT_0),&(v166_4));
      drop(v166_4);
      let v166_7: Space = if (v166_5).is_empty() { Space::new() } else {
        let mut v167_6 = Space::new();
        let mut v167_6_cursor = (v165_3_tail).read_zipper();
        for v167_6_byte in v167_6_cursor.child_mask().iter() {
          v167_6_cursor.descend_to_byte(v167_6_byte);
          {
          let v167_6_tail = v167_6_cursor.fork_read_zipper();
          let v167_6_head = Path::from_slice(&[v167_6_byte]);
          let v168_2: Space = singleton(&(v167_6_head));
          let v168_3: Space = intersect(&(*CONSTANT_3),&(v168_2));
          let v168_4: Space = if has_head(&(v168_3)) { singleton(&[]) } else { Space::new() };
          drop(v168_3);
          let v168_5: Space = subtract(&(*CONSTANT_0),&(v168_4));
          drop(v168_4);
          let v168_8: Space = if (v168_5).is_empty() { Space::new() } else {
            let v169_6: Path = concat_path(&(v165_3_head),&(v167_6_head));
            let v169_7: Space = routine_8(c, &(v169_6), &(v167_6_tail).make_space());
            drop(v169_6);
            compose(&(v168_5),&(v169_7))
          };
          drop(v168_5);
          let v168_9: Space = intersect(&(*CONSTANT_3),&(v168_2));
          drop(v168_2);
          let v168_10: Space = if has_head(&(v168_9)) { singleton(&[]) } else { Space::new() };
          drop(v168_9);
          let v168_11: Space = compose(&(v168_10),&(v167_6_tail));
          drop(v168_10);
          let v168_12: Space = unite(&(v168_8),&(v168_11));
          drop(v168_11);
          v167_6.join_into((v168_12).clone());
          }
          v167_6_cursor.ascend(1);
        }
        drop(v167_6_cursor);
        compose(&(v166_5),&(v167_6))
      };
      drop(v166_5);
      let v166_8: Space = intersect(&(*CONSTANT_3),&(v166_2));
      drop(v166_2);
      let v166_9: Space = if has_head(&(v166_8)) { singleton(&[]) } else { Space::new() };
      drop(v166_8);
      let v166_10: Space = compose(&(v166_9),&(v165_3_tail));
      drop(v166_9);
      let v166_11: Space = unite(&(v166_7),&(v166_10));
      drop(v166_10);
      v165_3.join_into((v166_11).clone());
      }
      v165_3_cursor.ascend(1);
    }
    drop(v165_3_cursor);
    drop(v165_2);
    let v165_4: Space = unite(&(v165_3),&(v160_20));
    let v165_5: Space = intersect(&(v165_4),&(*s1));
    if !v160_20.join_into((v165_5).clone()).is_element() { break; }
  }
  let v160_21: Space = unite(&(*s2),&(v160_20));
  (v160_21).clone()
}

fn routine_7(c: &mut Context, s0: &Space, s1: &Space, s2: &Space) -> Space {
  let v170_3: Space = range_const::<{0},{1}>(&(*s2));
  let mut v170_10 = Space::new();
  let mut v170_10_cursor = (v170_3).read_zipper();
  for v170_10_byte in v170_10_cursor.child_mask().iter() {
    v170_10_cursor.descend_to_byte(v170_10_byte);
    {
    let v170_10_tail = v170_10_cursor.fork_read_zipper();
    let v170_10_head = Path::from_slice(&[v170_10_byte]);
    let v171_2: Space = singleton(&(v170_10_head));
    let v171_3: Space = intersect(&(*CONSTANT_3),&(v171_2));
    let v171_4: Space = if has_head(&(v171_3)) { singleton(&[]) } else { Space::new() };
    drop(v171_3);
    let v171_5: Space = subtract(&(*CONSTANT_0),&(v171_4));
    drop(v171_4);
    let v171_7: Space = if (v171_5).is_empty() { Space::new() } else {
      let mut v172_6 = Space::new();
      let mut v172_6_cursor = (v170_10_tail).read_zipper();
      for v172_6_byte in v172_6_cursor.child_mask().iter() {
        v172_6_cursor.descend_to_byte(v172_6_byte);
        {
        let v172_6_tail = v172_6_cursor.fork_read_zipper();
        let v172_6_head = Path::from_slice(&[v172_6_byte]);
        let v173_2: Space = singleton(&(v172_6_head));
        let v173_3: Space = intersect(&(*CONSTANT_3),&(v173_2));
        let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
        drop(v173_3);
        let v173_5: Space = subtract(&(*CONSTANT_0),&(v173_4));
        drop(v173_4);
        let v173_8: Space = if (v173_5).is_empty() { Space::new() } else {
          let v174_6: Path = concat_path(&(v170_10_head),&(v172_6_head));
          let v174_7: Space = routine_4(c, &(v174_6), &(v172_6_tail).make_space(), &(*s1), &(*s0), &(*s2));
          compose(&(v173_5),&(v174_7))
        };
        drop(v173_5);
        let v173_9: Space = intersect(&(*CONSTANT_3),&(v173_2));
        drop(v173_2);
        let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
        drop(v173_9);
        let v173_12: Space = if (v173_10).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v170_10_head),&(v172_6_head));
          let v175_11: Space = routine_5(c, &(v175_6), &(v172_6_tail).make_space(), &(*s1), &(*s0), &(*s2));
          drop(v175_6);
          compose(&(v173_10),&(v175_11))
        };
        drop(v173_10);
        let v173_13: Space = unite(&(v173_8),&(v173_12));
        v172_6.join_into((v173_13).clone());
        }
        v172_6_cursor.ascend(1);
      }
      drop(v172_6_cursor);
      compose(&(v171_5),&(v172_6))
    };
    drop(v171_5);
    let v171_8: Space = intersect(&(*CONSTANT_3),&(v171_2));
    let v171_9: Space = if has_head(&(v171_8)) { singleton(&[]) } else { Space::new() };
    drop(v171_8);
    let v171_25: Space = if (v171_9).is_empty() { Space::new() } else {
      let v176_10: Space = routine_6(c, &(*s1), &(*s2), &(v171_2));
      let v176_11: Space = routine_6(c, &(*s0), &(*s2), &(v171_2));
      let v176_12: Space = intersect(&(v176_10),&(v176_11));
      let v176_13: Space = subtract(&(v176_12),&(v171_2));
      let v176_14: Space = wrap(&(v176_13),&(v170_10_head));
      let v176_15: Space = subtract(&(*s2),&(v176_11));
      let v176_16: Space = subtract(&(v176_15),&(v176_10));
      let v176_17: Space = routine_7(c, &(*s0), &(*s1), &(v176_16));
      let v176_18: Space = unite(&(v176_14),&(v176_17));
      let v176_19: Space = subtract(&(v176_10),&(v176_11));
      let v176_20: Space = routine_7(c, &(*s0), &(*s1), &(v176_19));
      let v176_21: Space = unite(&(v176_18),&(v176_20));
      let v176_22: Space = subtract(&(v176_11),&(v176_10));
      let v176_23: Space = routine_7(c, &(*s0), &(*s1), &(v176_22));
      let v176_24: Space = unite(&(v176_21),&(v176_23));
      compose(&(v171_9),&(v176_24))
    };
    drop(v171_9);
    let v171_26: Space = unite(&(v171_7),&(v171_25));
    v170_10.join_into((v171_26).clone());
    }
    v170_10_cursor.ascend(1);
  }
  drop(v170_10_cursor);
  drop(v170_3);
  (v170_10).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v177_5 = Space::new();
  let mut v177_5_cursor = (*s0).read_zipper();
  for v177_5_byte in v177_5_cursor.child_mask().iter() {
    v177_5_cursor.descend_to_byte(v177_5_byte);
    {
    let v177_5_tail = v177_5_cursor.fork_read_zipper();
    let v177_5_head = Path::from_slice(&[v177_5_byte]);
    let v178_2: Space = singleton(&(v177_5_head));
    let v178_3: Space = intersect(&(*CONSTANT_3),&(v178_2));
    let v178_4: Space = if has_head(&(v178_3)) { singleton(&[]) } else { Space::new() };
    drop(v178_3);
    let v178_5: Space = subtract(&(*CONSTANT_0),&(v178_4));
    drop(v178_4);
    let v178_8: Space = if (v178_5).is_empty() { Space::new() } else {
      let v179_6: Path = concat_path(&(*p0),&(v177_5_head));
      let v179_7: Space = routine_8(c, &(v179_6), &(v177_5_tail).make_space());
      drop(v179_6);
      compose(&(v178_5),&(v179_7))
    };
    drop(v178_5);
    let v178_9: Space = intersect(&(*CONSTANT_3),&(v178_2));
    drop(v178_2);
    let v178_10: Space = if has_head(&(v178_9)) { singleton(&[]) } else { Space::new() };
    drop(v178_9);
    let v178_11: Space = compose(&(v178_10),&(v177_5_tail));
    drop(v178_10);
    let v178_12: Space = unite(&(v178_8),&(v178_11));
    drop(v178_11);
    v177_5.join_into((v178_12).clone());
    }
    v177_5_cursor.ascend(1);
  }
  drop(v177_5_cursor);
  (v177_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
