#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,0,0,1,0,0,1,0,0,1,0,0,0,1,1]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,1,0,0,0,1,0,0,1,0,0,0,1,1]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1,0,0,1,0,0,1,0,0,0,1,1]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>, s1: Option<&Space>) -> Space {
  let mut v0_11 = Space::new();
  let mut v0_11_cursor = (*s1.expect("unbound native input")).read_zipper();
  for v0_11_byte in v0_11_cursor.child_mask().iter() {
    v0_11_cursor.descend_to_byte(v0_11_byte);
    {
    let v0_11_tail = v0_11_cursor.fork_read_zipper();
    let v0_11_head = Path::from_slice(&[v0_11_byte]);
    let v1_2: Space = singleton(&(v0_11_head));
    let v1_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1_2));
    let v1_4: Space = if map_kernels::has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_11_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v3_2));
        let v3_4: Space = if map_kernels::has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_11_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail).make_space(), &(*s0.expect("unbound native input")));
          map_map_kernels::compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if map_kernels::has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_11_head),&(v2_6_head));
          let v5_11: Space = routine_2(c, &(v5_6), &(v2_6_tail).make_space(), &(*s0.expect("unbound native input")));
          drop(v5_6);
          map_map_kernels::compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = map_map_kernels::unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      map_map_kernels::compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if map_kernels::has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v6_10 = Space::new();
      let mut v6_10_cursor = (v0_11_tail).read_zipper();
      for v6_10_byte in v6_10_cursor.child_mask().iter() {
        v6_10_cursor.descend_to_byte(v6_10_byte);
        {
        let v6_10_tail = v6_10_cursor.fork_read_zipper();
        let v6_10_head = Path::from_slice(&[v6_10_byte]);
        let v7_2: Space = singleton(&(v6_10_head));
        let v7_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v7_2));
        let v7_4: Space = if map_kernels::has_head(&(v7_3)) { singleton(&[]) } else { Space::new() };
        drop(v7_3);
        let v7_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v7_4));
        drop(v7_4);
        let v7_8: Space = if (v7_5).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_11_head),&(v6_10_head));
          let v8_7: Space = routine_1(c, &(v8_6), &(v6_10_tail).make_space(), &(*s0.expect("unbound native input")));
          map_map_kernels::compose(&(v7_5),&(v8_7))
        };
        drop(v7_5);
        let v7_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v7_2));
        drop(v7_2);
        let v7_10: Space = if map_kernels::has_head(&(v7_9)) { singleton(&[]) } else { Space::new() };
        drop(v7_9);
        let v7_12: Space = if (v7_10).is_empty() { Space::new() } else {
          let v9_6: Path = concat_path(&(v0_11_head),&(v6_10_head));
          let v9_11: Space = routine_3(c, &(v9_6), &(v6_10_tail).make_space(), &(*s0.expect("unbound native input")));
          drop(v9_6);
          map_map_kernels::compose(&(v7_10),&(v9_11))
        };
        drop(v7_10);
        let v7_13: Space = map_map_kernels::unite(&(v7_8),&(v7_12));
        v6_10.join_into((v7_13).clone());
        }
        v6_10_cursor.ascend(1);
      }
      drop(v6_10_cursor);
      map_map_kernels::compose(&(v1_9),&(v6_10))
    };
    drop(v1_9);
    let v1_12: Space = map_map_kernels::unite(&(v1_7),&(v1_11));
    v0_11.join_into((v1_12).clone());
    }
    v0_11_cursor.ascend(1);
  }
  drop(v0_11_cursor);
  let v0_13: Space = map_kernels::wrap(&(v0_11),&(*CONSTANT_2));
  (v0_13).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v10_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v10_22: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_4));
  let v10_23: Space = map_kernels::unwrap(&(v10_22),&(*p0));
  let v10_24: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
  let mut v10_34 = Space::new();
  let mut v10_34_cursor = (*s0).read_zipper();
  for v10_34_byte in v10_34_cursor.child_mask().iter() {
    v10_34_cursor.descend_to_byte(v10_34_byte);
    {
    let v10_34_tail = v10_34_cursor.fork_read_zipper();
    let v10_34_head = Path::from_slice(&[v10_34_byte]);
    let v11_2: Space = singleton(&(v10_34_head));
    let v11_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v11_2));
    let v11_4: Space = if map_kernels::has_head(&(v11_3)) { singleton(&[]) } else { Space::new() };
    drop(v11_3);
    let v11_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v11_4));
    drop(v11_4);
    let v11_8: Space = if (v11_5).is_empty() { Space::new() } else {
      let v12_6: Path = concat_path(&(*p0),&(v10_34_head));
      let mut v12_7 = Space::new();
      let mut v12_7_cursor = (v10_34_tail).read_zipper();
      for v12_7_byte in v12_7_cursor.child_mask().iter() {
        v12_7_cursor.descend_to_byte(v12_7_byte);
        {
        let v12_7_tail = v12_7_cursor.fork_read_zipper();
        let v12_7_head = Path::from_slice(&[v12_7_byte]);
        let v13_2: Space = singleton(&(v12_7_head));
        let v13_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v13_2));
        let v13_4: Space = if map_kernels::has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let mut v14_7 = Space::new();
          let mut v14_7_cursor = (v12_7_tail).read_zipper();
          for v14_7_byte in v14_7_cursor.child_mask().iter() {
            v14_7_cursor.descend_to_byte(v14_7_byte);
            {
            let v14_7_tail = v14_7_cursor.fork_read_zipper();
            let v14_7_head = Path::from_slice(&[v14_7_byte]);
            let v15_2: Space = singleton(&(v14_7_head));
            let v15_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v15_2));
            let v15_4: Space = if map_kernels::has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v16_7: Space = routine_4(c, &(v16_6), &(v14_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if map_kernels::has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v17_11: Space = routine_5(c, &(v17_6), &(v14_7_tail).make_space(), &(*s1));
              drop(v17_6);
              map_map_kernels::compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = map_map_kernels::unite(&(v15_8),&(v15_12));
            v14_7.join_into((v15_13).clone());
            }
            v14_7_cursor.ascend(1);
          }
          drop(v14_7_cursor);
          map_map_kernels::compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if map_kernels::has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v12_6),&(v12_7_head));
          let mut v18_11 = Space::new();
          let mut v18_11_cursor = (v12_7_tail).read_zipper();
          for v18_11_byte in v18_11_cursor.child_mask().iter() {
            v18_11_cursor.descend_to_byte(v18_11_byte);
            {
            let v18_11_tail = v18_11_cursor.fork_read_zipper();
            let v18_11_head = Path::from_slice(&[v18_11_byte]);
            let v19_2: Space = singleton(&(v18_11_head));
            let v19_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v19_2));
            let v19_4: Space = if map_kernels::has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v19_4));
            drop(v19_4);
            let v19_8: Space = if (v19_5).is_empty() { Space::new() } else {
              let v20_6: Path = concat_path(&(v18_6),&(v18_11_head));
              let v20_7: Space = routine_4(c, &(v20_6), &(v18_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v19_5),&(v20_7))
            };
            drop(v19_5);
            let v19_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v19_2));
            drop(v19_2);
            let v19_10: Space = if map_kernels::has_head(&(v19_9)) { singleton(&[]) } else { Space::new() };
            drop(v19_9);
            let v19_12: Space = if (v19_10).is_empty() { Space::new() } else {
              let v21_6: Path = concat_path(&(v18_6),&(v18_11_head));
              let v21_11: Space = routine_3(c, &(v21_6), &(v18_11_tail).make_space(), &(*s1));
              drop(v21_6);
              map_map_kernels::compose(&(v19_10),&(v21_11))
            };
            drop(v19_10);
            let v19_13: Space = map_map_kernels::unite(&(v19_8),&(v19_12));
            v18_11.join_into((v19_13).clone());
            }
            v18_11_cursor.ascend(1);
          }
          drop(v18_11_cursor);
          drop(v18_6);
          map_map_kernels::compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = map_map_kernels::unite(&(v13_8),&(v13_12));
        v12_7.join_into((v13_13).clone());
        }
        v12_7_cursor.ascend(1);
      }
      drop(v12_7_cursor);
      map_map_kernels::compose(&(v11_5),&(v12_7))
    };
    drop(v11_5);
    let v11_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v11_2));
    drop(v11_2);
    let v11_10: Space = if map_kernels::has_head(&(v11_9)) { singleton(&[]) } else { Space::new() };
    drop(v11_9);
    let v11_13: Space = if (v11_10).is_empty() { Space::new() } else {
      let v22_6: Path = concat_path(&(*p0),&(v10_34_head));
      let v22_11: Space = map_kernels::unwrap(&(v10_23),&(v10_34_head));
      let mut v22_12 = Space::new();
      let mut v22_12_cursor = (v10_34_tail).read_zipper();
      for v22_12_byte in v22_12_cursor.child_mask().iter() {
        v22_12_cursor.descend_to_byte(v22_12_byte);
        {
        let v22_12_tail = v22_12_cursor.fork_read_zipper();
        let v22_12_head = Path::from_slice(&[v22_12_byte]);
        let v23_2: Space = singleton(&(v22_12_head));
        let v23_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v23_2));
        let v23_4: Space = if map_kernels::has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
        drop(v23_3);
        let v23_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v23_4));
        drop(v23_4);
        let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
          let v24_6: Path = concat_path(&(v22_6),&(v22_12_head));
          let mut v24_7 = Space::new();
          let mut v24_7_cursor = (v22_12_tail).read_zipper();
          for v24_7_byte in v24_7_cursor.child_mask().iter() {
            v24_7_cursor.descend_to_byte(v24_7_byte);
            {
            let v24_7_tail = v24_7_cursor.fork_read_zipper();
            let v24_7_head = Path::from_slice(&[v24_7_byte]);
            let v25_2: Space = singleton(&(v24_7_head));
            let v25_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v25_2));
            let v25_4: Space = if map_kernels::has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
            drop(v25_3);
            let v25_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v25_4));
            drop(v25_4);
            let v25_8: Space = if (v25_5).is_empty() { Space::new() } else {
              let v26_6: Path = concat_path(&(v24_6),&(v24_7_head));
              let v26_7: Space = routine_4(c, &(v26_6), &(v24_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v25_5),&(v26_7))
            };
            drop(v25_5);
            let v25_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v25_2));
            drop(v25_2);
            let v25_10: Space = if map_kernels::has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
            drop(v25_9);
            let v25_12: Space = if (v25_10).is_empty() { Space::new() } else {
              let v27_6: Path = concat_path(&(v24_6),&(v24_7_head));
              let v27_11: Space = routine_5(c, &(v27_6), &(v24_7_tail).make_space(), &(*s1));
              drop(v27_6);
              map_map_kernels::compose(&(v25_10),&(v27_11))
            };
            drop(v25_10);
            let v25_13: Space = map_map_kernels::unite(&(v25_8),&(v25_12));
            v24_7.join_into((v25_13).clone());
            }
            v24_7_cursor.ascend(1);
          }
          drop(v24_7_cursor);
          map_map_kernels::compose(&(v23_5),&(v24_7))
        };
        drop(v23_5);
        let v23_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v23_2));
        drop(v23_2);
        let v23_10: Space = if map_kernels::has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
        drop(v23_9);
        let v23_18: Space = if (v23_10).is_empty() { Space::new() } else {
          let v28_11: Space = map_kernels::unwrap(&(v22_11),&(v22_12_head));
          let v28_12: Space = map_map_kernels::restrict_to(&(v10_22),&(v28_11));
          let mut v28_13 = Space::new();
          let mut v28_13_cursor = (v28_12).read_zipper();
          for v28_13_byte in v28_13_cursor.child_mask().iter() {
            v28_13_cursor.descend_to_byte(v28_13_byte);
            {
            let v28_13_tail = v28_13_cursor.fork_read_zipper();
            let v28_13_head = Path::from_slice(&[v28_13_byte]);
            let v29_2: Space = singleton(&(v28_13_head));
            let v29_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v29_2));
            let v29_4: Space = if map_kernels::has_head(&(v29_3)) { singleton(&[]) } else { Space::new() };
            drop(v29_3);
            let v29_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v29_4));
            drop(v29_4);
            let v29_7: Space = if (v29_5).is_empty() { Space::new() } else {
              let v30_6: Space = routine_6(c, &(v28_13_head), &(v28_13_tail).make_space());
              map_map_kernels::compose(&(v29_5),&(v30_6))
            };
            drop(v29_5);
            let v29_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v29_2));
            drop(v29_2);
            let v29_9: Space = if map_kernels::has_head(&(v29_8)) { singleton(&[]) } else { Space::new() };
            drop(v29_8);
            let v29_11: Space = if (v29_9).is_empty() { Space::new() } else {
              let v31_10: Space = routine_7(c, &(v28_13_head), &(v28_13_tail).make_space());
              map_map_kernels::compose(&(v29_9),&(v31_10))
            };
            drop(v29_9);
            let v29_12: Space = map_map_kernels::unite(&(v29_7),&(v29_11));
            v28_13.join_into((v29_12).clone());
            }
            v28_13_cursor.ascend(1);
          }
          drop(v28_13_cursor);
          drop(v28_12);
          let v28_14: Space = map_map_kernels::restrict_to(&(v10_21),&(v28_13));
          let mut v28_15 = Space::new();
          let mut v28_15_cursor = (v28_14).read_zipper();
          for v28_15_byte in v28_15_cursor.child_mask().iter() {
            v28_15_cursor.descend_to_byte(v28_15_byte);
            {
            let v28_15_tail = v28_15_cursor.fork_read_zipper();
            let v28_15_head = Path::from_slice(&[v28_15_byte]);
            let v32_2: Space = singleton(&(v28_15_head));
            let v32_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v32_2));
            let v32_4: Space = if map_kernels::has_head(&(v32_3)) { singleton(&[]) } else { Space::new() };
            drop(v32_3);
            let v32_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v32_4));
            drop(v32_4);
            let v32_7: Space = if (v32_5).is_empty() { Space::new() } else {
              let v33_6: Space = routine_8(c, &(v28_15_head), &(v28_15_tail).make_space());
              map_map_kernels::compose(&(v32_5),&(v33_6))
            };
            drop(v32_5);
            let v32_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v32_2));
            drop(v32_2);
            let v32_9: Space = if map_kernels::has_head(&(v32_8)) { singleton(&[]) } else { Space::new() };
            drop(v32_8);
            let v32_11: Space = if (v32_9).is_empty() { Space::new() } else {
              let v34_10: Space = routine_9(c, &(v28_15_head), &(v28_15_tail).make_space());
              map_map_kernels::compose(&(v32_9),&(v34_10))
            };
            drop(v32_9);
            let v32_12: Space = map_map_kernels::unite(&(v32_7),&(v32_11));
            v28_15.join_into((v32_12).clone());
            }
            v28_15_cursor.ascend(1);
          }
          drop(v28_15_cursor);
          let v28_16: Space = map_map_kernels::subtract(&(v28_15),&(v28_11));
          drop(v28_11);
          let v28_17: Space = map_map_kernels::intersect(&(v28_16),&(v10_24));
          map_map_kernels::compose(&(v23_10),&(v28_17))
        };
        drop(v23_10);
        let v35_6: Path = concat_path(&(v22_6),&(v22_12_head));
        let v23_19: Space = map_kernels::wrap(&(v23_18),&(v35_6));
        let v23_20: Space = map_map_kernels::unite(&(v23_8),&(v23_19));
        v22_12.join_into((v23_20).clone());
        }
        v22_12_cursor.ascend(1);
      }
      drop(v22_12_cursor);
      drop(v22_6);
      drop(v22_11);
      map_map_kernels::compose(&(v11_10),&(v22_12))
    };
    drop(v11_10);
    let v11_14: Space = map_map_kernels::unite(&(v11_8),&(v11_13));
    v10_34.join_into((v11_14).clone());
    }
    v10_34_cursor.ascend(1);
  }
  drop(v10_34_cursor);
  drop(v10_21);
  drop(v10_22);
  drop(v10_23);
  drop(v10_24);
  (v10_34).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v36_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v36_9: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_4));
  let v36_10: Space = map_kernels::unwrap(&(v36_9),&(*p0));
  let v36_12: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
  let mut v36_40 = Space::new();
  let mut v36_40_cursor = (*s0).read_zipper();
  for v36_40_byte in v36_40_cursor.child_mask().iter() {
    v36_40_cursor.descend_to_byte(v36_40_byte);
    {
    let v36_40_tail = v36_40_cursor.fork_read_zipper();
    let v36_40_head = Path::from_slice(&[v36_40_byte]);
    let v37_2: Space = singleton(&(v36_40_head));
    let v37_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v37_2));
    let v37_4: Space = if map_kernels::has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
    drop(v37_3);
    let v37_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v37_4));
    drop(v37_4);
    let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
      let v38_6: Path = concat_path(&(*p0),&(v36_40_head));
      let mut v38_7 = Space::new();
      let mut v38_7_cursor = (v36_40_tail).read_zipper();
      for v38_7_byte in v38_7_cursor.child_mask().iter() {
        v38_7_cursor.descend_to_byte(v38_7_byte);
        {
        let v38_7_tail = v38_7_cursor.fork_read_zipper();
        let v38_7_head = Path::from_slice(&[v38_7_byte]);
        let v39_2: Space = singleton(&(v38_7_head));
        let v39_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v39_2));
        let v39_4: Space = if map_kernels::has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
        drop(v39_3);
        let v39_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v39_4));
        drop(v39_4);
        let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v38_6),&(v38_7_head));
          let mut v40_7 = Space::new();
          let mut v40_7_cursor = (v38_7_tail).read_zipper();
          for v40_7_byte in v40_7_cursor.child_mask().iter() {
            v40_7_cursor.descend_to_byte(v40_7_byte);
            {
            let v40_7_tail = v40_7_cursor.fork_read_zipper();
            let v40_7_head = Path::from_slice(&[v40_7_byte]);
            let v41_2: Space = singleton(&(v40_7_head));
            let v41_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v41_2));
            let v41_4: Space = if map_kernels::has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v41_4));
            drop(v41_4);
            let v41_8: Space = if (v41_5).is_empty() { Space::new() } else {
              let v42_6: Path = concat_path(&(v40_6),&(v40_7_head));
              let v42_7: Space = routine_4(c, &(v42_6), &(v40_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v41_5),&(v42_7))
            };
            drop(v41_5);
            let v41_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v41_2));
            drop(v41_2);
            let v41_10: Space = if map_kernels::has_head(&(v41_9)) { singleton(&[]) } else { Space::new() };
            drop(v41_9);
            let v41_12: Space = if (v41_10).is_empty() { Space::new() } else {
              let v43_6: Path = concat_path(&(v40_6),&(v40_7_head));
              let v43_11: Space = routine_5(c, &(v43_6), &(v40_7_tail).make_space(), &(*s1));
              drop(v43_6);
              map_map_kernels::compose(&(v41_10),&(v43_11))
            };
            drop(v41_10);
            let v41_13: Space = map_map_kernels::unite(&(v41_8),&(v41_12));
            v40_7.join_into((v41_13).clone());
            }
            v40_7_cursor.ascend(1);
          }
          drop(v40_7_cursor);
          map_map_kernels::compose(&(v39_5),&(v40_7))
        };
        drop(v39_5);
        let v39_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v39_2));
        drop(v39_2);
        let v39_10: Space = if map_kernels::has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
        drop(v39_9);
        let v39_12: Space = if (v39_10).is_empty() { Space::new() } else {
          let v44_6: Path = concat_path(&(v38_6),&(v38_7_head));
          let mut v44_11 = Space::new();
          let mut v44_11_cursor = (v38_7_tail).read_zipper();
          for v44_11_byte in v44_11_cursor.child_mask().iter() {
            v44_11_cursor.descend_to_byte(v44_11_byte);
            {
            let v44_11_tail = v44_11_cursor.fork_read_zipper();
            let v44_11_head = Path::from_slice(&[v44_11_byte]);
            let v45_2: Space = singleton(&(v44_11_head));
            let v45_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v45_2));
            let v45_4: Space = if map_kernels::has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
            drop(v45_3);
            let v45_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v45_4));
            drop(v45_4);
            let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
              let v46_6: Path = concat_path(&(v44_6),&(v44_11_head));
              let v46_7: Space = routine_4(c, &(v46_6), &(v44_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v45_5),&(v46_7))
            };
            drop(v45_5);
            let v45_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v45_2));
            drop(v45_2);
            let v45_10: Space = if map_kernels::has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
            drop(v45_9);
            let v45_12: Space = if (v45_10).is_empty() { Space::new() } else {
              let v47_6: Path = concat_path(&(v44_6),&(v44_11_head));
              let v47_11: Space = routine_3(c, &(v47_6), &(v44_11_tail).make_space(), &(*s1));
              drop(v47_6);
              map_map_kernels::compose(&(v45_10),&(v47_11))
            };
            drop(v45_10);
            let v45_13: Space = map_map_kernels::unite(&(v45_8),&(v45_12));
            v44_11.join_into((v45_13).clone());
            }
            v44_11_cursor.ascend(1);
          }
          drop(v44_11_cursor);
          drop(v44_6);
          map_map_kernels::compose(&(v39_10),&(v44_11))
        };
        drop(v39_10);
        let v39_13: Space = map_map_kernels::unite(&(v39_8),&(v39_12));
        v38_7.join_into((v39_13).clone());
        }
        v38_7_cursor.ascend(1);
      }
      drop(v38_7_cursor);
      map_map_kernels::compose(&(v37_5),&(v38_7))
    };
    drop(v37_5);
    let v37_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v37_2));
    drop(v37_2);
    let v37_10: Space = if map_kernels::has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
    drop(v37_9);
    let v37_18: Space = if (v37_10).is_empty() { Space::new() } else {
      let v48_11: Space = map_kernels::unwrap(&(v36_10),&(v36_40_head));
      let v48_12: Space = map_map_kernels::restrict_to(&(v36_9),&(v48_11));
      let mut v48_13 = Space::new();
      let mut v48_13_cursor = (v48_12).read_zipper();
      for v48_13_byte in v48_13_cursor.child_mask().iter() {
        v48_13_cursor.descend_to_byte(v48_13_byte);
        {
        let v48_13_tail = v48_13_cursor.fork_read_zipper();
        let v48_13_head = Path::from_slice(&[v48_13_byte]);
        let v49_2: Space = singleton(&(v48_13_head));
        let v49_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v49_2));
        let v49_4: Space = if map_kernels::has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
        drop(v49_3);
        let v49_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v49_4));
        drop(v49_4);
        let v49_7: Space = if (v49_5).is_empty() { Space::new() } else {
          let mut v50_6 = Space::new();
          let mut v50_6_cursor = (v48_13_tail).read_zipper();
          for v50_6_byte in v50_6_cursor.child_mask().iter() {
            v50_6_cursor.descend_to_byte(v50_6_byte);
            {
            let v50_6_tail = v50_6_cursor.fork_read_zipper();
            let v50_6_head = Path::from_slice(&[v50_6_byte]);
            let v51_2: Space = singleton(&(v50_6_head));
            let v51_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v51_2));
            let v51_4: Space = if map_kernels::has_head(&(v51_3)) { singleton(&[]) } else { Space::new() };
            drop(v51_3);
            let v51_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v51_4));
            drop(v51_4);
            let v51_8: Space = if (v51_5).is_empty() { Space::new() } else {
              let v52_6: Path = concat_path(&(v48_13_head),&(v50_6_head));
              let v52_7: Space = routine_10(c, &(v52_6), &(v50_6_tail).make_space());
              map_map_kernels::compose(&(v51_5),&(v52_7))
            };
            drop(v51_5);
            let v51_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v51_2));
            drop(v51_2);
            let v51_10: Space = if map_kernels::has_head(&(v51_9)) { singleton(&[]) } else { Space::new() };
            drop(v51_9);
            let v51_12: Space = if (v51_10).is_empty() { Space::new() } else {
              let v53_6: Path = concat_path(&(v48_13_head),&(v50_6_head));
              let v53_11: Space = routine_11(c, &(v53_6), &(v50_6_tail).make_space());
              drop(v53_6);
              map_map_kernels::compose(&(v51_10),&(v53_11))
            };
            drop(v51_10);
            let v51_13: Space = map_map_kernels::unite(&(v51_8),&(v51_12));
            v50_6.join_into((v51_13).clone());
            }
            v50_6_cursor.ascend(1);
          }
          drop(v50_6_cursor);
          map_map_kernels::compose(&(v49_5),&(v50_6))
        };
        drop(v49_5);
        let v49_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v49_2));
        drop(v49_2);
        let v49_9: Space = if map_kernels::has_head(&(v49_8)) { singleton(&[]) } else { Space::new() };
        drop(v49_8);
        let v49_11: Space = if (v49_9).is_empty() { Space::new() } else {
          let mut v54_10 = Space::new();
          let mut v54_10_cursor = (v48_13_tail).read_zipper();
          for v54_10_byte in v54_10_cursor.child_mask().iter() {
            v54_10_cursor.descend_to_byte(v54_10_byte);
            {
            let v54_10_tail = v54_10_cursor.fork_read_zipper();
            let v54_10_head = Path::from_slice(&[v54_10_byte]);
            let v55_2: Space = singleton(&(v54_10_head));
            let v55_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v55_2));
            let v55_4: Space = if map_kernels::has_head(&(v55_3)) { singleton(&[]) } else { Space::new() };
            drop(v55_3);
            let v55_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v55_4));
            drop(v55_4);
            let v55_8: Space = if (v55_5).is_empty() { Space::new() } else {
              let v56_6: Path = concat_path(&(v48_13_head),&(v54_10_head));
              let v56_7: Space = routine_10(c, &(v56_6), &(v54_10_tail).make_space());
              map_map_kernels::compose(&(v55_5),&(v56_7))
            };
            drop(v55_5);
            let v55_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v55_2));
            drop(v55_2);
            let v55_10: Space = if map_kernels::has_head(&(v55_9)) { singleton(&[]) } else { Space::new() };
            drop(v55_9);
            let v55_12: Space = if (v55_10).is_empty() { Space::new() } else {
              let v57_6: Path = concat_path(&(v48_13_head),&(v54_10_head));
              let v57_11: Space = routine_12(c, &(v57_6), &(v54_10_tail).make_space());
              drop(v57_6);
              map_map_kernels::compose(&(v55_10),&(v57_11))
            };
            drop(v55_10);
            let v55_13: Space = map_map_kernels::unite(&(v55_8),&(v55_12));
            v54_10.join_into((v55_13).clone());
            }
            v54_10_cursor.ascend(1);
          }
          drop(v54_10_cursor);
          map_map_kernels::compose(&(v49_9),&(v54_10))
        };
        drop(v49_9);
        let v49_12: Space = map_map_kernels::unite(&(v49_7),&(v49_11));
        v48_13.join_into((v49_12).clone());
        }
        v48_13_cursor.ascend(1);
      }
      drop(v48_13_cursor);
      drop(v48_12);
      let v48_14: Space = map_map_kernels::restrict_to(&(v36_7),&(v48_13));
      let mut v48_15 = Space::new();
      let mut v48_15_cursor = (v48_14).read_zipper();
      for v48_15_byte in v48_15_cursor.child_mask().iter() {
        v48_15_cursor.descend_to_byte(v48_15_byte);
        {
        let v48_15_tail = v48_15_cursor.fork_read_zipper();
        let v48_15_head = Path::from_slice(&[v48_15_byte]);
        let v58_2: Space = singleton(&(v48_15_head));
        let v58_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v58_2));
        let v58_4: Space = if map_kernels::has_head(&(v58_3)) { singleton(&[]) } else { Space::new() };
        drop(v58_3);
        let v58_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v58_4));
        drop(v58_4);
        let v58_7: Space = if (v58_5).is_empty() { Space::new() } else {
          let mut v59_6 = Space::new();
          let mut v59_6_cursor = (v48_15_tail).read_zipper();
          for v59_6_byte in v59_6_cursor.child_mask().iter() {
            v59_6_cursor.descend_to_byte(v59_6_byte);
            {
            let v59_6_tail = v59_6_cursor.fork_read_zipper();
            let v59_6_head = Path::from_slice(&[v59_6_byte]);
            let v60_2: Space = singleton(&(v59_6_head));
            let v60_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v60_2));
            let v60_4: Space = if map_kernels::has_head(&(v60_3)) { singleton(&[]) } else { Space::new() };
            drop(v60_3);
            let v60_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v60_4));
            drop(v60_4);
            let v60_8: Space = if (v60_5).is_empty() { Space::new() } else {
              let v61_6: Path = concat_path(&(v48_15_head),&(v59_6_head));
              let v61_7: Space = routine_13(c, &(v61_6), &(v59_6_tail).make_space());
              map_map_kernels::compose(&(v60_5),&(v61_7))
            };
            drop(v60_5);
            let v60_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v60_2));
            drop(v60_2);
            let v60_10: Space = if map_kernels::has_head(&(v60_9)) { singleton(&[]) } else { Space::new() };
            drop(v60_9);
            let v60_12: Space = if (v60_10).is_empty() { Space::new() } else {
              let v62_6: Path = concat_path(&(v48_15_head),&(v59_6_head));
              let v62_11: Space = routine_14(c, &(v62_6), &(v59_6_tail).make_space());
              drop(v62_6);
              map_map_kernels::compose(&(v60_10),&(v62_11))
            };
            drop(v60_10);
            let v60_13: Space = map_map_kernels::unite(&(v60_8),&(v60_12));
            v59_6.join_into((v60_13).clone());
            }
            v59_6_cursor.ascend(1);
          }
          drop(v59_6_cursor);
          map_map_kernels::compose(&(v58_5),&(v59_6))
        };
        drop(v58_5);
        let v58_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v58_2));
        drop(v58_2);
        let v58_9: Space = if map_kernels::has_head(&(v58_8)) { singleton(&[]) } else { Space::new() };
        drop(v58_8);
        let v58_11: Space = if (v58_9).is_empty() { Space::new() } else {
          let mut v63_10 = Space::new();
          let mut v63_10_cursor = (v48_15_tail).read_zipper();
          for v63_10_byte in v63_10_cursor.child_mask().iter() {
            v63_10_cursor.descend_to_byte(v63_10_byte);
            {
            let v63_10_tail = v63_10_cursor.fork_read_zipper();
            let v63_10_head = Path::from_slice(&[v63_10_byte]);
            let v64_2: Space = singleton(&(v63_10_head));
            let v64_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v64_2));
            let v64_4: Space = if map_kernels::has_head(&(v64_3)) { singleton(&[]) } else { Space::new() };
            drop(v64_3);
            let v64_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v64_4));
            drop(v64_4);
            let v64_8: Space = if (v64_5).is_empty() { Space::new() } else {
              let v65_6: Path = concat_path(&(v48_15_head),&(v63_10_head));
              let v65_7: Space = routine_13(c, &(v65_6), &(v63_10_tail).make_space());
              map_map_kernels::compose(&(v64_5),&(v65_7))
            };
            drop(v64_5);
            let v64_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v64_2));
            drop(v64_2);
            let v64_10: Space = if map_kernels::has_head(&(v64_9)) { singleton(&[]) } else { Space::new() };
            drop(v64_9);
            let v64_12: Space = if (v64_10).is_empty() { Space::new() } else {
              let v66_6: Path = concat_path(&(v48_15_head),&(v63_10_head));
              let v66_11: Space = routine_15(c, &(v66_6), &(v63_10_tail).make_space());
              drop(v66_6);
              map_map_kernels::compose(&(v64_10),&(v66_11))
            };
            drop(v64_10);
            let v64_13: Space = map_map_kernels::unite(&(v64_8),&(v64_12));
            v63_10.join_into((v64_13).clone());
            }
            v63_10_cursor.ascend(1);
          }
          drop(v63_10_cursor);
          map_map_kernels::compose(&(v58_9),&(v63_10))
        };
        drop(v58_9);
        let v58_12: Space = map_map_kernels::unite(&(v58_7),&(v58_11));
        v48_15.join_into((v58_12).clone());
        }
        v48_15_cursor.ascend(1);
      }
      drop(v48_15_cursor);
      let v48_16: Space = map_map_kernels::subtract(&(v48_15),&(v48_11));
      drop(v48_11);
      let v48_17: Space = map_map_kernels::intersect(&(v48_16),&(v36_12));
      map_map_kernels::compose(&(v37_10),&(v48_17))
    };
    drop(v37_10);
    let v67_6: Path = concat_path(&(*p0),&(v36_40_head));
    let v37_19: Space = map_kernels::wrap(&(v37_18),&(v67_6));
    let v37_20: Space = map_map_kernels::unite(&(v37_8),&(v37_19));
    v36_40.join_into((v37_20).clone());
    }
    v36_40_cursor.ascend(1);
  }
  drop(v36_40_cursor);
  drop(v36_7);
  drop(v36_9);
  drop(v36_10);
  drop(v36_12);
  (v36_40).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v68_4: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v68_6: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_4));
  let v68_7: Space = map_kernels::unwrap(&(v68_6),&(*p0));
  let v68_8: Space = map_map_kernels::restrict_to(&(v68_6),&(v68_7));
  drop(v68_6);
  let mut v68_27 = Space::new();
  let mut v68_27_cursor = (v68_8).read_zipper();
  for v68_27_byte in v68_27_cursor.child_mask().iter() {
    v68_27_cursor.descend_to_byte(v68_27_byte);
    {
    let v68_27_tail = v68_27_cursor.fork_read_zipper();
    let v68_27_head = Path::from_slice(&[v68_27_byte]);
    let v69_2: Space = singleton(&(v68_27_head));
    let v69_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v69_2));
    let v69_4: Space = if map_kernels::has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
    drop(v69_3);
    let v69_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v69_4));
    drop(v69_4);
    let v69_7: Space = if (v69_5).is_empty() { Space::new() } else {
      let mut v70_6 = Space::new();
      let mut v70_6_cursor = (v68_27_tail).read_zipper();
      for v70_6_byte in v70_6_cursor.child_mask().iter() {
        v70_6_cursor.descend_to_byte(v70_6_byte);
        {
        let v70_6_tail = v70_6_cursor.fork_read_zipper();
        let v70_6_head = Path::from_slice(&[v70_6_byte]);
        let v71_2: Space = singleton(&(v70_6_head));
        let v71_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v71_2));
        let v71_4: Space = if map_kernels::has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
        drop(v71_3);
        let v71_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v71_4));
        drop(v71_4);
        let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
          let v72_6: Path = concat_path(&(v68_27_head),&(v70_6_head));
          let mut v72_7 = Space::new();
          let mut v72_7_cursor = (v70_6_tail).read_zipper();
          for v72_7_byte in v72_7_cursor.child_mask().iter() {
            v72_7_cursor.descend_to_byte(v72_7_byte);
            {
            let v72_7_tail = v72_7_cursor.fork_read_zipper();
            let v72_7_head = Path::from_slice(&[v72_7_byte]);
            let v73_2: Space = singleton(&(v72_7_head));
            let v73_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v73_2));
            let v73_4: Space = if map_kernels::has_head(&(v73_3)) { singleton(&[]) } else { Space::new() };
            drop(v73_3);
            let v73_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v73_4));
            drop(v73_4);
            let v73_8: Space = if (v73_5).is_empty() { Space::new() } else {
              let v74_6: Path = concat_path(&(v72_6),&(v72_7_head));
              let v74_7: Space = routine_16(c, &(v74_6), &(v72_7_tail).make_space());
              map_map_kernels::compose(&(v73_5),&(v74_7))
            };
            drop(v73_5);
            let v73_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v73_2));
            drop(v73_2);
            let v73_10: Space = if map_kernels::has_head(&(v73_9)) { singleton(&[]) } else { Space::new() };
            drop(v73_9);
            let v73_12: Space = if (v73_10).is_empty() { Space::new() } else {
              let v75_6: Path = concat_path(&(v72_6),&(v72_7_head));
              let v75_11: Space = routine_17(c, &(v75_6), &(v72_7_tail).make_space());
              drop(v75_6);
              map_map_kernels::compose(&(v73_10),&(v75_11))
            };
            drop(v73_10);
            let v73_13: Space = map_map_kernels::unite(&(v73_8),&(v73_12));
            v72_7.join_into((v73_13).clone());
            }
            v72_7_cursor.ascend(1);
          }
          drop(v72_7_cursor);
          map_map_kernels::compose(&(v71_5),&(v72_7))
        };
        drop(v71_5);
        let v71_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v71_2));
        drop(v71_2);
        let v71_10: Space = if map_kernels::has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
        drop(v71_9);
        let v71_12: Space = if (v71_10).is_empty() { Space::new() } else {
          let v76_6: Path = concat_path(&(v68_27_head),&(v70_6_head));
          let mut v76_11 = Space::new();
          let mut v76_11_cursor = (v70_6_tail).read_zipper();
          for v76_11_byte in v76_11_cursor.child_mask().iter() {
            v76_11_cursor.descend_to_byte(v76_11_byte);
            {
            let v76_11_tail = v76_11_cursor.fork_read_zipper();
            let v76_11_head = Path::from_slice(&[v76_11_byte]);
            let v77_2: Space = singleton(&(v76_11_head));
            let v77_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v77_2));
            let v77_4: Space = if map_kernels::has_head(&(v77_3)) { singleton(&[]) } else { Space::new() };
            drop(v77_3);
            let v77_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v77_4));
            drop(v77_4);
            let v77_8: Space = if (v77_5).is_empty() { Space::new() } else {
              let v78_6: Path = concat_path(&(v76_6),&(v76_11_head));
              let v78_7: Space = routine_16(c, &(v78_6), &(v76_11_tail).make_space());
              map_map_kernels::compose(&(v77_5),&(v78_7))
            };
            drop(v77_5);
            let v77_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v77_2));
            drop(v77_2);
            let v77_10: Space = if map_kernels::has_head(&(v77_9)) { singleton(&[]) } else { Space::new() };
            drop(v77_9);
            let v77_12: Space = if (v77_10).is_empty() { Space::new() } else {
              let v79_6: Path = concat_path(&(v76_6),&(v76_11_head));
              let v79_11: Space = routine_12(c, &(v79_6), &(v76_11_tail).make_space());
              drop(v79_6);
              map_map_kernels::compose(&(v77_10),&(v79_11))
            };
            drop(v77_10);
            let v77_13: Space = map_map_kernels::unite(&(v77_8),&(v77_12));
            v76_11.join_into((v77_13).clone());
            }
            v76_11_cursor.ascend(1);
          }
          drop(v76_11_cursor);
          drop(v76_6);
          map_map_kernels::compose(&(v71_10),&(v76_11))
        };
        drop(v71_10);
        let v71_13: Space = map_map_kernels::unite(&(v71_8),&(v71_12));
        v70_6.join_into((v71_13).clone());
        }
        v70_6_cursor.ascend(1);
      }
      drop(v70_6_cursor);
      map_map_kernels::compose(&(v69_5),&(v70_6))
    };
    drop(v69_5);
    let v69_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v69_2));
    drop(v69_2);
    let v69_9: Space = if map_kernels::has_head(&(v69_8)) { singleton(&[]) } else { Space::new() };
    drop(v69_8);
    let v69_11: Space = if (v69_9).is_empty() { Space::new() } else {
      let mut v80_10 = Space::new();
      let mut v80_10_cursor = (v68_27_tail).read_zipper();
      for v80_10_byte in v80_10_cursor.child_mask().iter() {
        v80_10_cursor.descend_to_byte(v80_10_byte);
        {
        let v80_10_tail = v80_10_cursor.fork_read_zipper();
        let v80_10_head = Path::from_slice(&[v80_10_byte]);
        let v81_2: Space = singleton(&(v80_10_head));
        let v81_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v81_2));
        let v81_4: Space = if map_kernels::has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
        drop(v81_3);
        let v81_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v81_4));
        drop(v81_4);
        let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
          let v82_6: Path = concat_path(&(v68_27_head),&(v80_10_head));
          let mut v82_7 = Space::new();
          let mut v82_7_cursor = (v80_10_tail).read_zipper();
          for v82_7_byte in v82_7_cursor.child_mask().iter() {
            v82_7_cursor.descend_to_byte(v82_7_byte);
            {
            let v82_7_tail = v82_7_cursor.fork_read_zipper();
            let v82_7_head = Path::from_slice(&[v82_7_byte]);
            let v83_2: Space = singleton(&(v82_7_head));
            let v83_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v83_2));
            let v83_4: Space = if map_kernels::has_head(&(v83_3)) { singleton(&[]) } else { Space::new() };
            drop(v83_3);
            let v83_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v83_4));
            drop(v83_4);
            let v83_8: Space = if (v83_5).is_empty() { Space::new() } else {
              let v84_6: Path = concat_path(&(v82_6),&(v82_7_head));
              let v84_7: Space = routine_16(c, &(v84_6), &(v82_7_tail).make_space());
              map_map_kernels::compose(&(v83_5),&(v84_7))
            };
            drop(v83_5);
            let v83_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v83_2));
            drop(v83_2);
            let v83_10: Space = if map_kernels::has_head(&(v83_9)) { singleton(&[]) } else { Space::new() };
            drop(v83_9);
            let v83_12: Space = if (v83_10).is_empty() { Space::new() } else {
              let v85_6: Path = concat_path(&(v82_6),&(v82_7_head));
              let v85_11: Space = routine_17(c, &(v85_6), &(v82_7_tail).make_space());
              drop(v85_6);
              map_map_kernels::compose(&(v83_10),&(v85_11))
            };
            drop(v83_10);
            let v83_13: Space = map_map_kernels::unite(&(v83_8),&(v83_12));
            v82_7.join_into((v83_13).clone());
            }
            v82_7_cursor.ascend(1);
          }
          drop(v82_7_cursor);
          drop(v82_6);
          map_map_kernels::compose(&(v81_5),&(v82_7))
        };
        drop(v81_5);
        let v81_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v81_2));
        drop(v81_2);
        let v81_10: Space = if map_kernels::has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
        drop(v81_9);
        let v81_11: Space = map_view_kernels::compose(&(v81_10),&(v80_10_tail));
        drop(v81_10);
        let v81_12: Space = map_map_kernels::unite(&(v81_8),&(v81_11));
        drop(v81_11);
        v80_10.join_into((v81_12).clone());
        }
        v80_10_cursor.ascend(1);
      }
      drop(v80_10_cursor);
      map_map_kernels::compose(&(v69_9),&(v80_10))
    };
    drop(v69_9);
    let v69_12: Space = map_map_kernels::unite(&(v69_7),&(v69_11));
    v68_27.join_into((v69_12).clone());
    }
    v68_27_cursor.ascend(1);
  }
  drop(v68_27_cursor);
  drop(v68_8);
  let v68_28: Space = map_map_kernels::restrict_to(&(v68_4),&(v68_27));
  drop(v68_4);
  let mut v68_47 = Space::new();
  let mut v68_47_cursor = (v68_28).read_zipper();
  for v68_47_byte in v68_47_cursor.child_mask().iter() {
    v68_47_cursor.descend_to_byte(v68_47_byte);
    {
    let v68_47_tail = v68_47_cursor.fork_read_zipper();
    let v68_47_head = Path::from_slice(&[v68_47_byte]);
    let v86_2: Space = singleton(&(v68_47_head));
    let v86_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v86_2));
    let v86_4: Space = if map_kernels::has_head(&(v86_3)) { singleton(&[]) } else { Space::new() };
    drop(v86_3);
    let v86_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v86_4));
    drop(v86_4);
    let v86_7: Space = if (v86_5).is_empty() { Space::new() } else {
      let mut v87_6 = Space::new();
      let mut v87_6_cursor = (v68_47_tail).read_zipper();
      for v87_6_byte in v87_6_cursor.child_mask().iter() {
        v87_6_cursor.descend_to_byte(v87_6_byte);
        {
        let v87_6_tail = v87_6_cursor.fork_read_zipper();
        let v87_6_head = Path::from_slice(&[v87_6_byte]);
        let v88_2: Space = singleton(&(v87_6_head));
        let v88_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v88_2));
        let v88_4: Space = if map_kernels::has_head(&(v88_3)) { singleton(&[]) } else { Space::new() };
        drop(v88_3);
        let v88_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v88_4));
        drop(v88_4);
        let v88_8: Space = if (v88_5).is_empty() { Space::new() } else {
          let v89_6: Path = concat_path(&(v68_47_head),&(v87_6_head));
          let mut v89_7 = Space::new();
          let mut v89_7_cursor = (v87_6_tail).read_zipper();
          for v89_7_byte in v89_7_cursor.child_mask().iter() {
            v89_7_cursor.descend_to_byte(v89_7_byte);
            {
            let v89_7_tail = v89_7_cursor.fork_read_zipper();
            let v89_7_head = Path::from_slice(&[v89_7_byte]);
            let v90_2: Space = singleton(&(v89_7_head));
            let v90_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v90_2));
            let v90_4: Space = if map_kernels::has_head(&(v90_3)) { singleton(&[]) } else { Space::new() };
            drop(v90_3);
            let v90_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v90_4));
            drop(v90_4);
            let v90_8: Space = if (v90_5).is_empty() { Space::new() } else {
              let v91_6: Path = concat_path(&(v89_6),&(v89_7_head));
              let v91_7: Space = routine_18(c, &(v91_6), &(v89_7_tail).make_space());
              map_map_kernels::compose(&(v90_5),&(v91_7))
            };
            drop(v90_5);
            let v90_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v90_2));
            drop(v90_2);
            let v90_10: Space = if map_kernels::has_head(&(v90_9)) { singleton(&[]) } else { Space::new() };
            drop(v90_9);
            let v90_12: Space = if (v90_10).is_empty() { Space::new() } else {
              let v92_6: Path = concat_path(&(v89_6),&(v89_7_head));
              let v92_11: Space = routine_19(c, &(v92_6), &(v89_7_tail).make_space());
              drop(v92_6);
              map_map_kernels::compose(&(v90_10),&(v92_11))
            };
            drop(v90_10);
            let v90_13: Space = map_map_kernels::unite(&(v90_8),&(v90_12));
            v89_7.join_into((v90_13).clone());
            }
            v89_7_cursor.ascend(1);
          }
          drop(v89_7_cursor);
          map_map_kernels::compose(&(v88_5),&(v89_7))
        };
        drop(v88_5);
        let v88_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v88_2));
        drop(v88_2);
        let v88_10: Space = if map_kernels::has_head(&(v88_9)) { singleton(&[]) } else { Space::new() };
        drop(v88_9);
        let v88_12: Space = if (v88_10).is_empty() { Space::new() } else {
          let v93_6: Path = concat_path(&(v68_47_head),&(v87_6_head));
          let mut v93_11 = Space::new();
          let mut v93_11_cursor = (v87_6_tail).read_zipper();
          for v93_11_byte in v93_11_cursor.child_mask().iter() {
            v93_11_cursor.descend_to_byte(v93_11_byte);
            {
            let v93_11_tail = v93_11_cursor.fork_read_zipper();
            let v93_11_head = Path::from_slice(&[v93_11_byte]);
            let v94_2: Space = singleton(&(v93_11_head));
            let v94_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v94_2));
            let v94_4: Space = if map_kernels::has_head(&(v94_3)) { singleton(&[]) } else { Space::new() };
            drop(v94_3);
            let v94_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v94_4));
            drop(v94_4);
            let v94_8: Space = if (v94_5).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v93_6),&(v93_11_head));
              let v95_7: Space = routine_18(c, &(v95_6), &(v93_11_tail).make_space());
              map_map_kernels::compose(&(v94_5),&(v95_7))
            };
            drop(v94_5);
            let v94_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v94_2));
            drop(v94_2);
            let v94_10: Space = if map_kernels::has_head(&(v94_9)) { singleton(&[]) } else { Space::new() };
            drop(v94_9);
            let v94_12: Space = if (v94_10).is_empty() { Space::new() } else {
              let v96_6: Path = concat_path(&(v93_6),&(v93_11_head));
              let v96_11: Space = routine_15(c, &(v96_6), &(v93_11_tail).make_space());
              drop(v96_6);
              map_map_kernels::compose(&(v94_10),&(v96_11))
            };
            drop(v94_10);
            let v94_13: Space = map_map_kernels::unite(&(v94_8),&(v94_12));
            v93_11.join_into((v94_13).clone());
            }
            v93_11_cursor.ascend(1);
          }
          drop(v93_11_cursor);
          drop(v93_6);
          map_map_kernels::compose(&(v88_10),&(v93_11))
        };
        drop(v88_10);
        let v88_13: Space = map_map_kernels::unite(&(v88_8),&(v88_12));
        v87_6.join_into((v88_13).clone());
        }
        v87_6_cursor.ascend(1);
      }
      drop(v87_6_cursor);
      map_map_kernels::compose(&(v86_5),&(v87_6))
    };
    drop(v86_5);
    let v86_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v86_2));
    drop(v86_2);
    let v86_9: Space = if map_kernels::has_head(&(v86_8)) { singleton(&[]) } else { Space::new() };
    drop(v86_8);
    let v86_11: Space = if (v86_9).is_empty() { Space::new() } else {
      let mut v97_10 = Space::new();
      let mut v97_10_cursor = (v68_47_tail).read_zipper();
      for v97_10_byte in v97_10_cursor.child_mask().iter() {
        v97_10_cursor.descend_to_byte(v97_10_byte);
        {
        let v97_10_tail = v97_10_cursor.fork_read_zipper();
        let v97_10_head = Path::from_slice(&[v97_10_byte]);
        let v98_2: Space = singleton(&(v97_10_head));
        let v98_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v98_2));
        let v98_4: Space = if map_kernels::has_head(&(v98_3)) { singleton(&[]) } else { Space::new() };
        drop(v98_3);
        let v98_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v98_4));
        drop(v98_4);
        let v98_8: Space = if (v98_5).is_empty() { Space::new() } else {
          let v99_6: Path = concat_path(&(v68_47_head),&(v97_10_head));
          let mut v99_7 = Space::new();
          let mut v99_7_cursor = (v97_10_tail).read_zipper();
          for v99_7_byte in v99_7_cursor.child_mask().iter() {
            v99_7_cursor.descend_to_byte(v99_7_byte);
            {
            let v99_7_tail = v99_7_cursor.fork_read_zipper();
            let v99_7_head = Path::from_slice(&[v99_7_byte]);
            let v100_2: Space = singleton(&(v99_7_head));
            let v100_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v100_2));
            let v100_4: Space = if map_kernels::has_head(&(v100_3)) { singleton(&[]) } else { Space::new() };
            drop(v100_3);
            let v100_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v100_4));
            drop(v100_4);
            let v100_8: Space = if (v100_5).is_empty() { Space::new() } else {
              let v101_6: Path = concat_path(&(v99_6),&(v99_7_head));
              let v101_7: Space = routine_18(c, &(v101_6), &(v99_7_tail).make_space());
              map_map_kernels::compose(&(v100_5),&(v101_7))
            };
            drop(v100_5);
            let v100_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v100_2));
            drop(v100_2);
            let v100_10: Space = if map_kernels::has_head(&(v100_9)) { singleton(&[]) } else { Space::new() };
            drop(v100_9);
            let v100_12: Space = if (v100_10).is_empty() { Space::new() } else {
              let v102_6: Path = concat_path(&(v99_6),&(v99_7_head));
              let v102_11: Space = routine_19(c, &(v102_6), &(v99_7_tail).make_space());
              drop(v102_6);
              map_map_kernels::compose(&(v100_10),&(v102_11))
            };
            drop(v100_10);
            let v100_13: Space = map_map_kernels::unite(&(v100_8),&(v100_12));
            v99_7.join_into((v100_13).clone());
            }
            v99_7_cursor.ascend(1);
          }
          drop(v99_7_cursor);
          drop(v99_6);
          map_map_kernels::compose(&(v98_5),&(v99_7))
        };
        drop(v98_5);
        let v98_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v98_2));
        drop(v98_2);
        let v98_10: Space = if map_kernels::has_head(&(v98_9)) { singleton(&[]) } else { Space::new() };
        drop(v98_9);
        let v98_11: Space = map_view_kernels::compose(&(v98_10),&(v97_10_tail));
        drop(v98_10);
        let v98_12: Space = map_map_kernels::unite(&(v98_8),&(v98_11));
        drop(v98_11);
        v97_10.join_into((v98_12).clone());
        }
        v97_10_cursor.ascend(1);
      }
      drop(v97_10_cursor);
      map_map_kernels::compose(&(v86_9),&(v97_10))
    };
    drop(v86_9);
    let v86_12: Space = map_map_kernels::unite(&(v86_7),&(v86_11));
    v68_47.join_into((v86_12).clone());
    }
    v68_47_cursor.ascend(1);
  }
  drop(v68_47_cursor);
  let v68_48: Space = map_map_kernels::subtract(&(v68_47),&(v68_7));
  drop(v68_7);
  let v68_50: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
  let v68_51: Space = map_map_kernels::intersect(&(v68_48),&(v68_50));
  drop(v68_50);
  let v68_52: Space = map_kernels::wrap(&(v68_51),&(*p0));
  (v68_52).clone()
}

fn routine_4(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v103_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v103_22: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_4));
  let v103_23: Space = map_kernels::unwrap(&(v103_22),&(*p0));
  let v103_24: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
  let mut v103_34 = Space::new();
  let mut v103_34_cursor = (*s0).read_zipper();
  for v103_34_byte in v103_34_cursor.child_mask().iter() {
    v103_34_cursor.descend_to_byte(v103_34_byte);
    {
    let v103_34_tail = v103_34_cursor.fork_read_zipper();
    let v103_34_head = Path::from_slice(&[v103_34_byte]);
    let v104_2: Space = singleton(&(v103_34_head));
    let v104_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v104_2));
    let v104_4: Space = if map_kernels::has_head(&(v104_3)) { singleton(&[]) } else { Space::new() };
    drop(v104_3);
    let v104_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v104_4));
    drop(v104_4);
    let v104_8: Space = if (v104_5).is_empty() { Space::new() } else {
      let v105_6: Path = concat_path(&(*p0),&(v103_34_head));
      let mut v105_7 = Space::new();
      let mut v105_7_cursor = (v103_34_tail).read_zipper();
      for v105_7_byte in v105_7_cursor.child_mask().iter() {
        v105_7_cursor.descend_to_byte(v105_7_byte);
        {
        let v105_7_tail = v105_7_cursor.fork_read_zipper();
        let v105_7_head = Path::from_slice(&[v105_7_byte]);
        let v106_2: Space = singleton(&(v105_7_head));
        let v106_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v106_2));
        let v106_4: Space = if map_kernels::has_head(&(v106_3)) { singleton(&[]) } else { Space::new() };
        drop(v106_3);
        let v106_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v106_4));
        drop(v106_4);
        let v106_8: Space = if (v106_5).is_empty() { Space::new() } else {
          let v107_6: Path = concat_path(&(v105_6),&(v105_7_head));
          let mut v107_7 = Space::new();
          let mut v107_7_cursor = (v105_7_tail).read_zipper();
          for v107_7_byte in v107_7_cursor.child_mask().iter() {
            v107_7_cursor.descend_to_byte(v107_7_byte);
            {
            let v107_7_tail = v107_7_cursor.fork_read_zipper();
            let v107_7_head = Path::from_slice(&[v107_7_byte]);
            let v108_2: Space = singleton(&(v107_7_head));
            let v108_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v108_2));
            let v108_4: Space = if map_kernels::has_head(&(v108_3)) { singleton(&[]) } else { Space::new() };
            drop(v108_3);
            let v108_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v108_4));
            drop(v108_4);
            let v108_8: Space = if (v108_5).is_empty() { Space::new() } else {
              let v109_6: Path = concat_path(&(v107_6),&(v107_7_head));
              let v109_7: Space = routine_20(c, &(v109_6), &(v107_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v108_5),&(v109_7))
            };
            drop(v108_5);
            let v108_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v108_2));
            drop(v108_2);
            let v108_10: Space = if map_kernels::has_head(&(v108_9)) { singleton(&[]) } else { Space::new() };
            drop(v108_9);
            let v108_12: Space = if (v108_10).is_empty() { Space::new() } else {
              let v110_6: Path = concat_path(&(v107_6),&(v107_7_head));
              let v110_11: Space = routine_21(c, &(v110_6), &(v107_7_tail).make_space(), &(*s1));
              drop(v110_6);
              map_map_kernels::compose(&(v108_10),&(v110_11))
            };
            drop(v108_10);
            let v108_13: Space = map_map_kernels::unite(&(v108_8),&(v108_12));
            v107_7.join_into((v108_13).clone());
            }
            v107_7_cursor.ascend(1);
          }
          drop(v107_7_cursor);
          map_map_kernels::compose(&(v106_5),&(v107_7))
        };
        drop(v106_5);
        let v106_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v106_2));
        drop(v106_2);
        let v106_10: Space = if map_kernels::has_head(&(v106_9)) { singleton(&[]) } else { Space::new() };
        drop(v106_9);
        let v106_12: Space = if (v106_10).is_empty() { Space::new() } else {
          let v111_6: Path = concat_path(&(v105_6),&(v105_7_head));
          let mut v111_11 = Space::new();
          let mut v111_11_cursor = (v105_7_tail).read_zipper();
          for v111_11_byte in v111_11_cursor.child_mask().iter() {
            v111_11_cursor.descend_to_byte(v111_11_byte);
            {
            let v111_11_tail = v111_11_cursor.fork_read_zipper();
            let v111_11_head = Path::from_slice(&[v111_11_byte]);
            let v112_2: Space = singleton(&(v111_11_head));
            let v112_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v112_2));
            let v112_4: Space = if map_kernels::has_head(&(v112_3)) { singleton(&[]) } else { Space::new() };
            drop(v112_3);
            let v112_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v112_4));
            drop(v112_4);
            let v112_8: Space = if (v112_5).is_empty() { Space::new() } else {
              let v113_6: Path = concat_path(&(v111_6),&(v111_11_head));
              let v113_7: Space = routine_20(c, &(v113_6), &(v111_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v112_5),&(v113_7))
            };
            drop(v112_5);
            let v112_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v112_2));
            drop(v112_2);
            let v112_10: Space = if map_kernels::has_head(&(v112_9)) { singleton(&[]) } else { Space::new() };
            drop(v112_9);
            let v112_12: Space = if (v112_10).is_empty() { Space::new() } else {
              let v114_6: Path = concat_path(&(v111_6),&(v111_11_head));
              let v114_11: Space = routine_3(c, &(v114_6), &(v111_11_tail).make_space(), &(*s1));
              drop(v114_6);
              map_map_kernels::compose(&(v112_10),&(v114_11))
            };
            drop(v112_10);
            let v112_13: Space = map_map_kernels::unite(&(v112_8),&(v112_12));
            v111_11.join_into((v112_13).clone());
            }
            v111_11_cursor.ascend(1);
          }
          drop(v111_11_cursor);
          drop(v111_6);
          map_map_kernels::compose(&(v106_10),&(v111_11))
        };
        drop(v106_10);
        let v106_13: Space = map_map_kernels::unite(&(v106_8),&(v106_12));
        v105_7.join_into((v106_13).clone());
        }
        v105_7_cursor.ascend(1);
      }
      drop(v105_7_cursor);
      map_map_kernels::compose(&(v104_5),&(v105_7))
    };
    drop(v104_5);
    let v104_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v104_2));
    drop(v104_2);
    let v104_10: Space = if map_kernels::has_head(&(v104_9)) { singleton(&[]) } else { Space::new() };
    drop(v104_9);
    let v104_13: Space = if (v104_10).is_empty() { Space::new() } else {
      let v115_6: Path = concat_path(&(*p0),&(v103_34_head));
      let v115_11: Space = map_kernels::unwrap(&(v103_23),&(v103_34_head));
      let mut v115_12 = Space::new();
      let mut v115_12_cursor = (v103_34_tail).read_zipper();
      for v115_12_byte in v115_12_cursor.child_mask().iter() {
        v115_12_cursor.descend_to_byte(v115_12_byte);
        {
        let v115_12_tail = v115_12_cursor.fork_read_zipper();
        let v115_12_head = Path::from_slice(&[v115_12_byte]);
        let v116_2: Space = singleton(&(v115_12_head));
        let v116_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v116_2));
        let v116_4: Space = if map_kernels::has_head(&(v116_3)) { singleton(&[]) } else { Space::new() };
        drop(v116_3);
        let v116_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v116_4));
        drop(v116_4);
        let v116_8: Space = if (v116_5).is_empty() { Space::new() } else {
          let v117_6: Path = concat_path(&(v115_6),&(v115_12_head));
          let mut v117_7 = Space::new();
          let mut v117_7_cursor = (v115_12_tail).read_zipper();
          for v117_7_byte in v117_7_cursor.child_mask().iter() {
            v117_7_cursor.descend_to_byte(v117_7_byte);
            {
            let v117_7_tail = v117_7_cursor.fork_read_zipper();
            let v117_7_head = Path::from_slice(&[v117_7_byte]);
            let v118_2: Space = singleton(&(v117_7_head));
            let v118_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v118_2));
            let v118_4: Space = if map_kernels::has_head(&(v118_3)) { singleton(&[]) } else { Space::new() };
            drop(v118_3);
            let v118_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v118_4));
            drop(v118_4);
            let v118_8: Space = if (v118_5).is_empty() { Space::new() } else {
              let v119_6: Path = concat_path(&(v117_6),&(v117_7_head));
              let v119_7: Space = routine_20(c, &(v119_6), &(v117_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v118_5),&(v119_7))
            };
            drop(v118_5);
            let v118_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v118_2));
            drop(v118_2);
            let v118_10: Space = if map_kernels::has_head(&(v118_9)) { singleton(&[]) } else { Space::new() };
            drop(v118_9);
            let v118_12: Space = if (v118_10).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v117_6),&(v117_7_head));
              let v120_11: Space = routine_21(c, &(v120_6), &(v117_7_tail).make_space(), &(*s1));
              drop(v120_6);
              map_map_kernels::compose(&(v118_10),&(v120_11))
            };
            drop(v118_10);
            let v118_13: Space = map_map_kernels::unite(&(v118_8),&(v118_12));
            v117_7.join_into((v118_13).clone());
            }
            v117_7_cursor.ascend(1);
          }
          drop(v117_7_cursor);
          map_map_kernels::compose(&(v116_5),&(v117_7))
        };
        drop(v116_5);
        let v116_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v116_2));
        drop(v116_2);
        let v116_10: Space = if map_kernels::has_head(&(v116_9)) { singleton(&[]) } else { Space::new() };
        drop(v116_9);
        let v116_18: Space = if (v116_10).is_empty() { Space::new() } else {
          let v121_11: Space = map_kernels::unwrap(&(v115_11),&(v115_12_head));
          let v121_12: Space = map_map_kernels::restrict_to(&(v103_22),&(v121_11));
          let mut v121_13 = Space::new();
          let mut v121_13_cursor = (v121_12).read_zipper();
          for v121_13_byte in v121_13_cursor.child_mask().iter() {
            v121_13_cursor.descend_to_byte(v121_13_byte);
            {
            let v121_13_tail = v121_13_cursor.fork_read_zipper();
            let v121_13_head = Path::from_slice(&[v121_13_byte]);
            let v122_2: Space = singleton(&(v121_13_head));
            let v122_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v122_2));
            let v122_4: Space = if map_kernels::has_head(&(v122_3)) { singleton(&[]) } else { Space::new() };
            drop(v122_3);
            let v122_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v122_4));
            drop(v122_4);
            let v122_7: Space = if (v122_5).is_empty() { Space::new() } else {
              let v123_6: Space = routine_6(c, &(v121_13_head), &(v121_13_tail).make_space());
              map_map_kernels::compose(&(v122_5),&(v123_6))
            };
            drop(v122_5);
            let v122_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v122_2));
            drop(v122_2);
            let v122_9: Space = if map_kernels::has_head(&(v122_8)) { singleton(&[]) } else { Space::new() };
            drop(v122_8);
            let v122_11: Space = if (v122_9).is_empty() { Space::new() } else {
              let v124_10: Space = routine_7(c, &(v121_13_head), &(v121_13_tail).make_space());
              map_map_kernels::compose(&(v122_9),&(v124_10))
            };
            drop(v122_9);
            let v122_12: Space = map_map_kernels::unite(&(v122_7),&(v122_11));
            v121_13.join_into((v122_12).clone());
            }
            v121_13_cursor.ascend(1);
          }
          drop(v121_13_cursor);
          drop(v121_12);
          let v121_14: Space = map_map_kernels::restrict_to(&(v103_21),&(v121_13));
          let mut v121_15 = Space::new();
          let mut v121_15_cursor = (v121_14).read_zipper();
          for v121_15_byte in v121_15_cursor.child_mask().iter() {
            v121_15_cursor.descend_to_byte(v121_15_byte);
            {
            let v121_15_tail = v121_15_cursor.fork_read_zipper();
            let v121_15_head = Path::from_slice(&[v121_15_byte]);
            let v125_2: Space = singleton(&(v121_15_head));
            let v125_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v125_2));
            let v125_4: Space = if map_kernels::has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v125_4));
            drop(v125_4);
            let v125_7: Space = if (v125_5).is_empty() { Space::new() } else {
              let v126_6: Space = routine_8(c, &(v121_15_head), &(v121_15_tail).make_space());
              map_map_kernels::compose(&(v125_5),&(v126_6))
            };
            drop(v125_5);
            let v125_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v125_2));
            drop(v125_2);
            let v125_9: Space = if map_kernels::has_head(&(v125_8)) { singleton(&[]) } else { Space::new() };
            drop(v125_8);
            let v125_11: Space = if (v125_9).is_empty() { Space::new() } else {
              let v127_10: Space = routine_9(c, &(v121_15_head), &(v121_15_tail).make_space());
              map_map_kernels::compose(&(v125_9),&(v127_10))
            };
            drop(v125_9);
            let v125_12: Space = map_map_kernels::unite(&(v125_7),&(v125_11));
            v121_15.join_into((v125_12).clone());
            }
            v121_15_cursor.ascend(1);
          }
          drop(v121_15_cursor);
          let v121_16: Space = map_map_kernels::subtract(&(v121_15),&(v121_11));
          drop(v121_11);
          let v121_17: Space = map_map_kernels::intersect(&(v121_16),&(v103_24));
          map_map_kernels::compose(&(v116_10),&(v121_17))
        };
        drop(v116_10);
        let v128_6: Path = concat_path(&(v115_6),&(v115_12_head));
        let v116_19: Space = map_kernels::wrap(&(v116_18),&(v128_6));
        let v116_20: Space = map_map_kernels::unite(&(v116_8),&(v116_19));
        v115_12.join_into((v116_20).clone());
        }
        v115_12_cursor.ascend(1);
      }
      drop(v115_12_cursor);
      drop(v115_6);
      drop(v115_11);
      map_map_kernels::compose(&(v104_10),&(v115_12))
    };
    drop(v104_10);
    let v104_14: Space = map_map_kernels::unite(&(v104_8),&(v104_13));
    v103_34.join_into((v104_14).clone());
    }
    v103_34_cursor.ascend(1);
  }
  drop(v103_34_cursor);
  drop(v103_21);
  drop(v103_22);
  drop(v103_23);
  drop(v103_24);
  (v103_34).clone()
}

fn routine_5(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v129_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v129_9: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_4));
  let v129_10: Space = map_kernels::unwrap(&(v129_9),&(*p0));
  let v129_12: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
  let mut v129_40 = Space::new();
  let mut v129_40_cursor = (*s0).read_zipper();
  for v129_40_byte in v129_40_cursor.child_mask().iter() {
    v129_40_cursor.descend_to_byte(v129_40_byte);
    {
    let v129_40_tail = v129_40_cursor.fork_read_zipper();
    let v129_40_head = Path::from_slice(&[v129_40_byte]);
    let v130_2: Space = singleton(&(v129_40_head));
    let v130_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v130_2));
    let v130_4: Space = if map_kernels::has_head(&(v130_3)) { singleton(&[]) } else { Space::new() };
    drop(v130_3);
    let v130_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v130_4));
    drop(v130_4);
    let v130_8: Space = if (v130_5).is_empty() { Space::new() } else {
      let v131_6: Path = concat_path(&(*p0),&(v129_40_head));
      let mut v131_7 = Space::new();
      let mut v131_7_cursor = (v129_40_tail).read_zipper();
      for v131_7_byte in v131_7_cursor.child_mask().iter() {
        v131_7_cursor.descend_to_byte(v131_7_byte);
        {
        let v131_7_tail = v131_7_cursor.fork_read_zipper();
        let v131_7_head = Path::from_slice(&[v131_7_byte]);
        let v132_2: Space = singleton(&(v131_7_head));
        let v132_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v132_2));
        let v132_4: Space = if map_kernels::has_head(&(v132_3)) { singleton(&[]) } else { Space::new() };
        drop(v132_3);
        let v132_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v132_4));
        drop(v132_4);
        let v132_8: Space = if (v132_5).is_empty() { Space::new() } else {
          let v133_6: Path = concat_path(&(v131_6),&(v131_7_head));
          let mut v133_7 = Space::new();
          let mut v133_7_cursor = (v131_7_tail).read_zipper();
          for v133_7_byte in v133_7_cursor.child_mask().iter() {
            v133_7_cursor.descend_to_byte(v133_7_byte);
            {
            let v133_7_tail = v133_7_cursor.fork_read_zipper();
            let v133_7_head = Path::from_slice(&[v133_7_byte]);
            let v134_2: Space = singleton(&(v133_7_head));
            let v134_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v134_2));
            let v134_4: Space = if map_kernels::has_head(&(v134_3)) { singleton(&[]) } else { Space::new() };
            drop(v134_3);
            let v134_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v134_4));
            drop(v134_4);
            let v134_8: Space = if (v134_5).is_empty() { Space::new() } else {
              let v135_6: Path = concat_path(&(v133_6),&(v133_7_head));
              let v135_7: Space = routine_20(c, &(v135_6), &(v133_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v134_5),&(v135_7))
            };
            drop(v134_5);
            let v134_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v134_2));
            drop(v134_2);
            let v134_10: Space = if map_kernels::has_head(&(v134_9)) { singleton(&[]) } else { Space::new() };
            drop(v134_9);
            let v134_12: Space = if (v134_10).is_empty() { Space::new() } else {
              let v136_6: Path = concat_path(&(v133_6),&(v133_7_head));
              let v136_11: Space = routine_21(c, &(v136_6), &(v133_7_tail).make_space(), &(*s1));
              drop(v136_6);
              map_map_kernels::compose(&(v134_10),&(v136_11))
            };
            drop(v134_10);
            let v134_13: Space = map_map_kernels::unite(&(v134_8),&(v134_12));
            v133_7.join_into((v134_13).clone());
            }
            v133_7_cursor.ascend(1);
          }
          drop(v133_7_cursor);
          map_map_kernels::compose(&(v132_5),&(v133_7))
        };
        drop(v132_5);
        let v132_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v132_2));
        drop(v132_2);
        let v132_10: Space = if map_kernels::has_head(&(v132_9)) { singleton(&[]) } else { Space::new() };
        drop(v132_9);
        let v132_12: Space = if (v132_10).is_empty() { Space::new() } else {
          let v137_6: Path = concat_path(&(v131_6),&(v131_7_head));
          let mut v137_11 = Space::new();
          let mut v137_11_cursor = (v131_7_tail).read_zipper();
          for v137_11_byte in v137_11_cursor.child_mask().iter() {
            v137_11_cursor.descend_to_byte(v137_11_byte);
            {
            let v137_11_tail = v137_11_cursor.fork_read_zipper();
            let v137_11_head = Path::from_slice(&[v137_11_byte]);
            let v138_2: Space = singleton(&(v137_11_head));
            let v138_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v138_2));
            let v138_4: Space = if map_kernels::has_head(&(v138_3)) { singleton(&[]) } else { Space::new() };
            drop(v138_3);
            let v138_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v138_4));
            drop(v138_4);
            let v138_8: Space = if (v138_5).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v137_6),&(v137_11_head));
              let v139_7: Space = routine_20(c, &(v139_6), &(v137_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v138_5),&(v139_7))
            };
            drop(v138_5);
            let v138_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v138_2));
            drop(v138_2);
            let v138_10: Space = if map_kernels::has_head(&(v138_9)) { singleton(&[]) } else { Space::new() };
            drop(v138_9);
            let v138_12: Space = if (v138_10).is_empty() { Space::new() } else {
              let v140_6: Path = concat_path(&(v137_6),&(v137_11_head));
              let v140_11: Space = routine_3(c, &(v140_6), &(v137_11_tail).make_space(), &(*s1));
              drop(v140_6);
              map_map_kernels::compose(&(v138_10),&(v140_11))
            };
            drop(v138_10);
            let v138_13: Space = map_map_kernels::unite(&(v138_8),&(v138_12));
            v137_11.join_into((v138_13).clone());
            }
            v137_11_cursor.ascend(1);
          }
          drop(v137_11_cursor);
          drop(v137_6);
          map_map_kernels::compose(&(v132_10),&(v137_11))
        };
        drop(v132_10);
        let v132_13: Space = map_map_kernels::unite(&(v132_8),&(v132_12));
        v131_7.join_into((v132_13).clone());
        }
        v131_7_cursor.ascend(1);
      }
      drop(v131_7_cursor);
      map_map_kernels::compose(&(v130_5),&(v131_7))
    };
    drop(v130_5);
    let v130_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v130_2));
    drop(v130_2);
    let v130_10: Space = if map_kernels::has_head(&(v130_9)) { singleton(&[]) } else { Space::new() };
    drop(v130_9);
    let v130_18: Space = if (v130_10).is_empty() { Space::new() } else {
      let v141_11: Space = map_kernels::unwrap(&(v129_10),&(v129_40_head));
      let v141_12: Space = map_map_kernels::restrict_to(&(v129_9),&(v141_11));
      let mut v141_13 = Space::new();
      let mut v141_13_cursor = (v141_12).read_zipper();
      for v141_13_byte in v141_13_cursor.child_mask().iter() {
        v141_13_cursor.descend_to_byte(v141_13_byte);
        {
        let v141_13_tail = v141_13_cursor.fork_read_zipper();
        let v141_13_head = Path::from_slice(&[v141_13_byte]);
        let v142_2: Space = singleton(&(v141_13_head));
        let v142_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v142_2));
        let v142_4: Space = if map_kernels::has_head(&(v142_3)) { singleton(&[]) } else { Space::new() };
        drop(v142_3);
        let v142_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v142_4));
        drop(v142_4);
        let v142_7: Space = if (v142_5).is_empty() { Space::new() } else {
          let mut v143_6 = Space::new();
          let mut v143_6_cursor = (v141_13_tail).read_zipper();
          for v143_6_byte in v143_6_cursor.child_mask().iter() {
            v143_6_cursor.descend_to_byte(v143_6_byte);
            {
            let v143_6_tail = v143_6_cursor.fork_read_zipper();
            let v143_6_head = Path::from_slice(&[v143_6_byte]);
            let v144_2: Space = singleton(&(v143_6_head));
            let v144_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v144_2));
            let v144_4: Space = if map_kernels::has_head(&(v144_3)) { singleton(&[]) } else { Space::new() };
            drop(v144_3);
            let v144_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v144_4));
            drop(v144_4);
            let v144_8: Space = if (v144_5).is_empty() { Space::new() } else {
              let v145_6: Path = concat_path(&(v141_13_head),&(v143_6_head));
              let v145_7: Space = routine_10(c, &(v145_6), &(v143_6_tail).make_space());
              map_map_kernels::compose(&(v144_5),&(v145_7))
            };
            drop(v144_5);
            let v144_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v144_2));
            drop(v144_2);
            let v144_10: Space = if map_kernels::has_head(&(v144_9)) { singleton(&[]) } else { Space::new() };
            drop(v144_9);
            let v144_12: Space = if (v144_10).is_empty() { Space::new() } else {
              let v146_6: Path = concat_path(&(v141_13_head),&(v143_6_head));
              let v146_11: Space = routine_11(c, &(v146_6), &(v143_6_tail).make_space());
              drop(v146_6);
              map_map_kernels::compose(&(v144_10),&(v146_11))
            };
            drop(v144_10);
            let v144_13: Space = map_map_kernels::unite(&(v144_8),&(v144_12));
            v143_6.join_into((v144_13).clone());
            }
            v143_6_cursor.ascend(1);
          }
          drop(v143_6_cursor);
          map_map_kernels::compose(&(v142_5),&(v143_6))
        };
        drop(v142_5);
        let v142_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v142_2));
        drop(v142_2);
        let v142_9: Space = if map_kernels::has_head(&(v142_8)) { singleton(&[]) } else { Space::new() };
        drop(v142_8);
        let v142_11: Space = if (v142_9).is_empty() { Space::new() } else {
          let mut v147_10 = Space::new();
          let mut v147_10_cursor = (v141_13_tail).read_zipper();
          for v147_10_byte in v147_10_cursor.child_mask().iter() {
            v147_10_cursor.descend_to_byte(v147_10_byte);
            {
            let v147_10_tail = v147_10_cursor.fork_read_zipper();
            let v147_10_head = Path::from_slice(&[v147_10_byte]);
            let v148_2: Space = singleton(&(v147_10_head));
            let v148_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v148_2));
            let v148_4: Space = if map_kernels::has_head(&(v148_3)) { singleton(&[]) } else { Space::new() };
            drop(v148_3);
            let v148_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v148_4));
            drop(v148_4);
            let v148_8: Space = if (v148_5).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v141_13_head),&(v147_10_head));
              let v149_7: Space = routine_10(c, &(v149_6), &(v147_10_tail).make_space());
              map_map_kernels::compose(&(v148_5),&(v149_7))
            };
            drop(v148_5);
            let v148_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v148_2));
            drop(v148_2);
            let v148_10: Space = if map_kernels::has_head(&(v148_9)) { singleton(&[]) } else { Space::new() };
            drop(v148_9);
            let v148_12: Space = if (v148_10).is_empty() { Space::new() } else {
              let v150_6: Path = concat_path(&(v141_13_head),&(v147_10_head));
              let v150_11: Space = routine_12(c, &(v150_6), &(v147_10_tail).make_space());
              drop(v150_6);
              map_map_kernels::compose(&(v148_10),&(v150_11))
            };
            drop(v148_10);
            let v148_13: Space = map_map_kernels::unite(&(v148_8),&(v148_12));
            v147_10.join_into((v148_13).clone());
            }
            v147_10_cursor.ascend(1);
          }
          drop(v147_10_cursor);
          map_map_kernels::compose(&(v142_9),&(v147_10))
        };
        drop(v142_9);
        let v142_12: Space = map_map_kernels::unite(&(v142_7),&(v142_11));
        v141_13.join_into((v142_12).clone());
        }
        v141_13_cursor.ascend(1);
      }
      drop(v141_13_cursor);
      drop(v141_12);
      let v141_14: Space = map_map_kernels::restrict_to(&(v129_7),&(v141_13));
      let mut v141_15 = Space::new();
      let mut v141_15_cursor = (v141_14).read_zipper();
      for v141_15_byte in v141_15_cursor.child_mask().iter() {
        v141_15_cursor.descend_to_byte(v141_15_byte);
        {
        let v141_15_tail = v141_15_cursor.fork_read_zipper();
        let v141_15_head = Path::from_slice(&[v141_15_byte]);
        let v151_2: Space = singleton(&(v141_15_head));
        let v151_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v151_2));
        let v151_4: Space = if map_kernels::has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
        drop(v151_3);
        let v151_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v151_4));
        drop(v151_4);
        let v151_7: Space = if (v151_5).is_empty() { Space::new() } else {
          let mut v152_6 = Space::new();
          let mut v152_6_cursor = (v141_15_tail).read_zipper();
          for v152_6_byte in v152_6_cursor.child_mask().iter() {
            v152_6_cursor.descend_to_byte(v152_6_byte);
            {
            let v152_6_tail = v152_6_cursor.fork_read_zipper();
            let v152_6_head = Path::from_slice(&[v152_6_byte]);
            let v153_2: Space = singleton(&(v152_6_head));
            let v153_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v153_2));
            let v153_4: Space = if map_kernels::has_head(&(v153_3)) { singleton(&[]) } else { Space::new() };
            drop(v153_3);
            let v153_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v153_4));
            drop(v153_4);
            let v153_8: Space = if (v153_5).is_empty() { Space::new() } else {
              let v154_6: Path = concat_path(&(v141_15_head),&(v152_6_head));
              let v154_7: Space = routine_13(c, &(v154_6), &(v152_6_tail).make_space());
              map_map_kernels::compose(&(v153_5),&(v154_7))
            };
            drop(v153_5);
            let v153_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v153_2));
            drop(v153_2);
            let v153_10: Space = if map_kernels::has_head(&(v153_9)) { singleton(&[]) } else { Space::new() };
            drop(v153_9);
            let v153_12: Space = if (v153_10).is_empty() { Space::new() } else {
              let v155_6: Path = concat_path(&(v141_15_head),&(v152_6_head));
              let v155_11: Space = routine_14(c, &(v155_6), &(v152_6_tail).make_space());
              drop(v155_6);
              map_map_kernels::compose(&(v153_10),&(v155_11))
            };
            drop(v153_10);
            let v153_13: Space = map_map_kernels::unite(&(v153_8),&(v153_12));
            v152_6.join_into((v153_13).clone());
            }
            v152_6_cursor.ascend(1);
          }
          drop(v152_6_cursor);
          map_map_kernels::compose(&(v151_5),&(v152_6))
        };
        drop(v151_5);
        let v151_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v151_2));
        drop(v151_2);
        let v151_9: Space = if map_kernels::has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
        drop(v151_8);
        let v151_11: Space = if (v151_9).is_empty() { Space::new() } else {
          let mut v156_10 = Space::new();
          let mut v156_10_cursor = (v141_15_tail).read_zipper();
          for v156_10_byte in v156_10_cursor.child_mask().iter() {
            v156_10_cursor.descend_to_byte(v156_10_byte);
            {
            let v156_10_tail = v156_10_cursor.fork_read_zipper();
            let v156_10_head = Path::from_slice(&[v156_10_byte]);
            let v157_2: Space = singleton(&(v156_10_head));
            let v157_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v157_2));
            let v157_4: Space = if map_kernels::has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
            drop(v157_3);
            let v157_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v157_4));
            drop(v157_4);
            let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
              let v158_6: Path = concat_path(&(v141_15_head),&(v156_10_head));
              let v158_7: Space = routine_13(c, &(v158_6), &(v156_10_tail).make_space());
              map_map_kernels::compose(&(v157_5),&(v158_7))
            };
            drop(v157_5);
            let v157_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v157_2));
            drop(v157_2);
            let v157_10: Space = if map_kernels::has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
            drop(v157_9);
            let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
              let v159_6: Path = concat_path(&(v141_15_head),&(v156_10_head));
              let v159_11: Space = routine_15(c, &(v159_6), &(v156_10_tail).make_space());
              drop(v159_6);
              map_map_kernels::compose(&(v157_10),&(v159_11))
            };
            drop(v157_10);
            let v157_13: Space = map_map_kernels::unite(&(v157_8),&(v157_12));
            v156_10.join_into((v157_13).clone());
            }
            v156_10_cursor.ascend(1);
          }
          drop(v156_10_cursor);
          map_map_kernels::compose(&(v151_9),&(v156_10))
        };
        drop(v151_9);
        let v151_12: Space = map_map_kernels::unite(&(v151_7),&(v151_11));
        v141_15.join_into((v151_12).clone());
        }
        v141_15_cursor.ascend(1);
      }
      drop(v141_15_cursor);
      let v141_16: Space = map_map_kernels::subtract(&(v141_15),&(v141_11));
      drop(v141_11);
      let v141_17: Space = map_map_kernels::intersect(&(v141_16),&(v129_12));
      map_map_kernels::compose(&(v130_10),&(v141_17))
    };
    drop(v130_10);
    let v160_6: Path = concat_path(&(*p0),&(v129_40_head));
    let v130_19: Space = map_kernels::wrap(&(v130_18),&(v160_6));
    let v130_20: Space = map_map_kernels::unite(&(v130_8),&(v130_19));
    v129_40.join_into((v130_20).clone());
    }
    v129_40_cursor.ascend(1);
  }
  drop(v129_40_cursor);
  drop(v129_7);
  drop(v129_9);
  drop(v129_10);
  drop(v129_12);
  (v129_40).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v161_20 = Space::new();
  let mut v161_20_cursor = (*s0).read_zipper();
  for v161_20_byte in v161_20_cursor.child_mask().iter() {
    v161_20_cursor.descend_to_byte(v161_20_byte);
    {
    let v161_20_tail = v161_20_cursor.fork_read_zipper();
    let v161_20_head = Path::from_slice(&[v161_20_byte]);
    let v162_2: Space = singleton(&(v161_20_head));
    let v162_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v162_2));
    let v162_4: Space = if map_kernels::has_head(&(v162_3)) { singleton(&[]) } else { Space::new() };
    drop(v162_3);
    let v162_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v162_4));
    drop(v162_4);
    let v162_8: Space = if (v162_5).is_empty() { Space::new() } else {
      let v163_6: Path = concat_path(&(*p0),&(v161_20_head));
      let mut v163_7 = Space::new();
      let mut v163_7_cursor = (v161_20_tail).read_zipper();
      for v163_7_byte in v163_7_cursor.child_mask().iter() {
        v163_7_cursor.descend_to_byte(v163_7_byte);
        {
        let v163_7_tail = v163_7_cursor.fork_read_zipper();
        let v163_7_head = Path::from_slice(&[v163_7_byte]);
        let v164_2: Space = singleton(&(v163_7_head));
        let v164_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v164_2));
        let v164_4: Space = if map_kernels::has_head(&(v164_3)) { singleton(&[]) } else { Space::new() };
        drop(v164_3);
        let v164_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v164_4));
        drop(v164_4);
        let v164_8: Space = if (v164_5).is_empty() { Space::new() } else {
          let v165_6: Path = concat_path(&(v163_6),&(v163_7_head));
          let mut v165_7 = Space::new();
          let mut v165_7_cursor = (v163_7_tail).read_zipper();
          for v165_7_byte in v165_7_cursor.child_mask().iter() {
            v165_7_cursor.descend_to_byte(v165_7_byte);
            {
            let v165_7_tail = v165_7_cursor.fork_read_zipper();
            let v165_7_head = Path::from_slice(&[v165_7_byte]);
            let v166_2: Space = singleton(&(v165_7_head));
            let v166_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v166_2));
            let v166_4: Space = if map_kernels::has_head(&(v166_3)) { singleton(&[]) } else { Space::new() };
            drop(v166_3);
            let v166_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v166_4));
            drop(v166_4);
            let v166_8: Space = if (v166_5).is_empty() { Space::new() } else {
              let v167_6: Path = concat_path(&(v165_6),&(v165_7_head));
              let v167_7: Space = routine_22(c, &(v167_6), &(v165_7_tail).make_space());
              map_map_kernels::compose(&(v166_5),&(v167_7))
            };
            drop(v166_5);
            let v166_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v166_2));
            drop(v166_2);
            let v166_10: Space = if map_kernels::has_head(&(v166_9)) { singleton(&[]) } else { Space::new() };
            drop(v166_9);
            let v166_12: Space = if (v166_10).is_empty() { Space::new() } else {
              let v168_6: Path = concat_path(&(v165_6),&(v165_7_head));
              let v168_11: Space = routine_23(c, &(v168_6), &(v165_7_tail).make_space());
              drop(v168_6);
              map_map_kernels::compose(&(v166_10),&(v168_11))
            };
            drop(v166_10);
            let v166_13: Space = map_map_kernels::unite(&(v166_8),&(v166_12));
            v165_7.join_into((v166_13).clone());
            }
            v165_7_cursor.ascend(1);
          }
          drop(v165_7_cursor);
          map_map_kernels::compose(&(v164_5),&(v165_7))
        };
        drop(v164_5);
        let v164_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v164_2));
        drop(v164_2);
        let v164_10: Space = if map_kernels::has_head(&(v164_9)) { singleton(&[]) } else { Space::new() };
        drop(v164_9);
        let v164_12: Space = if (v164_10).is_empty() { Space::new() } else {
          let v169_6: Path = concat_path(&(v163_6),&(v163_7_head));
          let mut v169_11 = Space::new();
          let mut v169_11_cursor = (v163_7_tail).read_zipper();
          for v169_11_byte in v169_11_cursor.child_mask().iter() {
            v169_11_cursor.descend_to_byte(v169_11_byte);
            {
            let v169_11_tail = v169_11_cursor.fork_read_zipper();
            let v169_11_head = Path::from_slice(&[v169_11_byte]);
            let v170_2: Space = singleton(&(v169_11_head));
            let v170_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v170_2));
            let v170_4: Space = if map_kernels::has_head(&(v170_3)) { singleton(&[]) } else { Space::new() };
            drop(v170_3);
            let v170_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v170_4));
            drop(v170_4);
            let v170_8: Space = if (v170_5).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v169_6),&(v169_11_head));
              let v171_7: Space = routine_22(c, &(v171_6), &(v169_11_tail).make_space());
              map_map_kernels::compose(&(v170_5),&(v171_7))
            };
            drop(v170_5);
            let v170_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v170_2));
            drop(v170_2);
            let v170_10: Space = if map_kernels::has_head(&(v170_9)) { singleton(&[]) } else { Space::new() };
            drop(v170_9);
            let v170_12: Space = if (v170_10).is_empty() { Space::new() } else {
              let v172_6: Path = concat_path(&(v169_6),&(v169_11_head));
              let v172_11: Space = routine_12(c, &(v172_6), &(v169_11_tail).make_space());
              drop(v172_6);
              map_map_kernels::compose(&(v170_10),&(v172_11))
            };
            drop(v170_10);
            let v170_13: Space = map_map_kernels::unite(&(v170_8),&(v170_12));
            v169_11.join_into((v170_13).clone());
            }
            v169_11_cursor.ascend(1);
          }
          drop(v169_11_cursor);
          drop(v169_6);
          map_map_kernels::compose(&(v164_10),&(v169_11))
        };
        drop(v164_10);
        let v164_13: Space = map_map_kernels::unite(&(v164_8),&(v164_12));
        v163_7.join_into((v164_13).clone());
        }
        v163_7_cursor.ascend(1);
      }
      drop(v163_7_cursor);
      map_map_kernels::compose(&(v162_5),&(v163_7))
    };
    drop(v162_5);
    let v162_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v162_2));
    drop(v162_2);
    let v162_10: Space = if map_kernels::has_head(&(v162_9)) { singleton(&[]) } else { Space::new() };
    drop(v162_9);
    let v162_12: Space = if (v162_10).is_empty() { Space::new() } else {
      let v173_6: Path = concat_path(&(*p0),&(v161_20_head));
      let mut v173_11 = Space::new();
      let mut v173_11_cursor = (v161_20_tail).read_zipper();
      for v173_11_byte in v173_11_cursor.child_mask().iter() {
        v173_11_cursor.descend_to_byte(v173_11_byte);
        {
        let v173_11_tail = v173_11_cursor.fork_read_zipper();
        let v173_11_head = Path::from_slice(&[v173_11_byte]);
        let v174_2: Space = singleton(&(v173_11_head));
        let v174_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v174_2));
        let v174_4: Space = if map_kernels::has_head(&(v174_3)) { singleton(&[]) } else { Space::new() };
        drop(v174_3);
        let v174_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v174_4));
        drop(v174_4);
        let v174_8: Space = if (v174_5).is_empty() { Space::new() } else {
          let v175_6: Path = concat_path(&(v173_6),&(v173_11_head));
          let mut v175_7 = Space::new();
          let mut v175_7_cursor = (v173_11_tail).read_zipper();
          for v175_7_byte in v175_7_cursor.child_mask().iter() {
            v175_7_cursor.descend_to_byte(v175_7_byte);
            {
            let v175_7_tail = v175_7_cursor.fork_read_zipper();
            let v175_7_head = Path::from_slice(&[v175_7_byte]);
            let v176_2: Space = singleton(&(v175_7_head));
            let v176_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v176_2));
            let v176_4: Space = if map_kernels::has_head(&(v176_3)) { singleton(&[]) } else { Space::new() };
            drop(v176_3);
            let v176_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v176_4));
            drop(v176_4);
            let v176_8: Space = if (v176_5).is_empty() { Space::new() } else {
              let v177_6: Path = concat_path(&(v175_6),&(v175_7_head));
              let v177_7: Space = routine_22(c, &(v177_6), &(v175_7_tail).make_space());
              map_map_kernels::compose(&(v176_5),&(v177_7))
            };
            drop(v176_5);
            let v176_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v176_2));
            drop(v176_2);
            let v176_10: Space = if map_kernels::has_head(&(v176_9)) { singleton(&[]) } else { Space::new() };
            drop(v176_9);
            let v176_12: Space = if (v176_10).is_empty() { Space::new() } else {
              let v178_6: Path = concat_path(&(v175_6),&(v175_7_head));
              let v178_11: Space = routine_23(c, &(v178_6), &(v175_7_tail).make_space());
              drop(v178_6);
              map_map_kernels::compose(&(v176_10),&(v178_11))
            };
            drop(v176_10);
            let v176_13: Space = map_map_kernels::unite(&(v176_8),&(v176_12));
            v175_7.join_into((v176_13).clone());
            }
            v175_7_cursor.ascend(1);
          }
          drop(v175_7_cursor);
          drop(v175_6);
          map_map_kernels::compose(&(v174_5),&(v175_7))
        };
        drop(v174_5);
        let v174_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v174_2));
        drop(v174_2);
        let v174_10: Space = if map_kernels::has_head(&(v174_9)) { singleton(&[]) } else { Space::new() };
        drop(v174_9);
        let v174_11: Space = map_view_kernels::compose(&(v174_10),&(v173_11_tail));
        drop(v174_10);
        let v174_12: Space = map_map_kernels::unite(&(v174_8),&(v174_11));
        drop(v174_11);
        v173_11.join_into((v174_12).clone());
        }
        v173_11_cursor.ascend(1);
      }
      drop(v173_11_cursor);
      drop(v173_6);
      map_map_kernels::compose(&(v162_10),&(v173_11))
    };
    drop(v162_10);
    let v162_13: Space = map_map_kernels::unite(&(v162_8),&(v162_12));
    v161_20.join_into((v162_13).clone());
    }
    v161_20_cursor.ascend(1);
  }
  drop(v161_20_cursor);
  (v161_20).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v179_14 = Space::new();
  let mut v179_14_cursor = (*s0).read_zipper();
  for v179_14_byte in v179_14_cursor.child_mask().iter() {
    v179_14_cursor.descend_to_byte(v179_14_byte);
    {
    let v179_14_tail = v179_14_cursor.fork_read_zipper();
    let v179_14_head = Path::from_slice(&[v179_14_byte]);
    let v180_2: Space = singleton(&(v179_14_head));
    let v180_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v180_2));
    let v180_4: Space = if map_kernels::has_head(&(v180_3)) { singleton(&[]) } else { Space::new() };
    drop(v180_3);
    let v180_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v180_4));
    drop(v180_4);
    let v180_8: Space = if (v180_5).is_empty() { Space::new() } else {
      let v181_6: Path = concat_path(&(*p0),&(v179_14_head));
      let mut v181_7 = Space::new();
      let mut v181_7_cursor = (v179_14_tail).read_zipper();
      for v181_7_byte in v181_7_cursor.child_mask().iter() {
        v181_7_cursor.descend_to_byte(v181_7_byte);
        {
        let v181_7_tail = v181_7_cursor.fork_read_zipper();
        let v181_7_head = Path::from_slice(&[v181_7_byte]);
        let v182_2: Space = singleton(&(v181_7_head));
        let v182_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v182_2));
        let v182_4: Space = if map_kernels::has_head(&(v182_3)) { singleton(&[]) } else { Space::new() };
        drop(v182_3);
        let v182_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v182_4));
        drop(v182_4);
        let v182_8: Space = if (v182_5).is_empty() { Space::new() } else {
          let v183_6: Path = concat_path(&(v181_6),&(v181_7_head));
          let mut v183_7 = Space::new();
          let mut v183_7_cursor = (v181_7_tail).read_zipper();
          for v183_7_byte in v183_7_cursor.child_mask().iter() {
            v183_7_cursor.descend_to_byte(v183_7_byte);
            {
            let v183_7_tail = v183_7_cursor.fork_read_zipper();
            let v183_7_head = Path::from_slice(&[v183_7_byte]);
            let v184_2: Space = singleton(&(v183_7_head));
            let v184_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v184_2));
            let v184_4: Space = if map_kernels::has_head(&(v184_3)) { singleton(&[]) } else { Space::new() };
            drop(v184_3);
            let v184_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v184_4));
            drop(v184_4);
            let v184_8: Space = if (v184_5).is_empty() { Space::new() } else {
              let v185_6: Path = concat_path(&(v183_6),&(v183_7_head));
              let v185_7: Space = routine_22(c, &(v185_6), &(v183_7_tail).make_space());
              map_map_kernels::compose(&(v184_5),&(v185_7))
            };
            drop(v184_5);
            let v184_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v184_2));
            drop(v184_2);
            let v184_10: Space = if map_kernels::has_head(&(v184_9)) { singleton(&[]) } else { Space::new() };
            drop(v184_9);
            let v184_12: Space = if (v184_10).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v183_6),&(v183_7_head));
              let v186_11: Space = routine_23(c, &(v186_6), &(v183_7_tail).make_space());
              drop(v186_6);
              map_map_kernels::compose(&(v184_10),&(v186_11))
            };
            drop(v184_10);
            let v184_13: Space = map_map_kernels::unite(&(v184_8),&(v184_12));
            v183_7.join_into((v184_13).clone());
            }
            v183_7_cursor.ascend(1);
          }
          drop(v183_7_cursor);
          map_map_kernels::compose(&(v182_5),&(v183_7))
        };
        drop(v182_5);
        let v182_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v182_2));
        drop(v182_2);
        let v182_10: Space = if map_kernels::has_head(&(v182_9)) { singleton(&[]) } else { Space::new() };
        drop(v182_9);
        let v182_12: Space = if (v182_10).is_empty() { Space::new() } else {
          let v187_6: Path = concat_path(&(v181_6),&(v181_7_head));
          let mut v187_11 = Space::new();
          let mut v187_11_cursor = (v181_7_tail).read_zipper();
          for v187_11_byte in v187_11_cursor.child_mask().iter() {
            v187_11_cursor.descend_to_byte(v187_11_byte);
            {
            let v187_11_tail = v187_11_cursor.fork_read_zipper();
            let v187_11_head = Path::from_slice(&[v187_11_byte]);
            let v188_2: Space = singleton(&(v187_11_head));
            let v188_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v188_2));
            let v188_4: Space = if map_kernels::has_head(&(v188_3)) { singleton(&[]) } else { Space::new() };
            drop(v188_3);
            let v188_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v188_4));
            drop(v188_4);
            let v188_8: Space = if (v188_5).is_empty() { Space::new() } else {
              let v189_6: Path = concat_path(&(v187_6),&(v187_11_head));
              let v189_7: Space = routine_22(c, &(v189_6), &(v187_11_tail).make_space());
              map_map_kernels::compose(&(v188_5),&(v189_7))
            };
            drop(v188_5);
            let v188_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v188_2));
            drop(v188_2);
            let v188_10: Space = if map_kernels::has_head(&(v188_9)) { singleton(&[]) } else { Space::new() };
            drop(v188_9);
            let v188_12: Space = if (v188_10).is_empty() { Space::new() } else {
              let v190_6: Path = concat_path(&(v187_6),&(v187_11_head));
              let v190_11: Space = routine_12(c, &(v190_6), &(v187_11_tail).make_space());
              drop(v190_6);
              map_map_kernels::compose(&(v188_10),&(v190_11))
            };
            drop(v188_10);
            let v188_13: Space = map_map_kernels::unite(&(v188_8),&(v188_12));
            v187_11.join_into((v188_13).clone());
            }
            v187_11_cursor.ascend(1);
          }
          drop(v187_11_cursor);
          drop(v187_6);
          map_map_kernels::compose(&(v182_10),&(v187_11))
        };
        drop(v182_10);
        let v182_13: Space = map_map_kernels::unite(&(v182_8),&(v182_12));
        v181_7.join_into((v182_13).clone());
        }
        v181_7_cursor.ascend(1);
      }
      drop(v181_7_cursor);
      drop(v181_6);
      map_map_kernels::compose(&(v180_5),&(v181_7))
    };
    drop(v180_5);
    let v180_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v180_2));
    drop(v180_2);
    let v180_10: Space = if map_kernels::has_head(&(v180_9)) { singleton(&[]) } else { Space::new() };
    drop(v180_9);
    let v180_11: Space = map_view_kernels::compose(&(v180_10),&(v179_14_tail));
    drop(v180_10);
    let v180_12: Space = map_map_kernels::unite(&(v180_8),&(v180_11));
    drop(v180_11);
    v179_14.join_into((v180_12).clone());
    }
    v179_14_cursor.ascend(1);
  }
  drop(v179_14_cursor);
  (v179_14).clone()
}

fn routine_8(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v191_20 = Space::new();
  let mut v191_20_cursor = (*s0).read_zipper();
  for v191_20_byte in v191_20_cursor.child_mask().iter() {
    v191_20_cursor.descend_to_byte(v191_20_byte);
    {
    let v191_20_tail = v191_20_cursor.fork_read_zipper();
    let v191_20_head = Path::from_slice(&[v191_20_byte]);
    let v192_2: Space = singleton(&(v191_20_head));
    let v192_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v192_2));
    let v192_4: Space = if map_kernels::has_head(&(v192_3)) { singleton(&[]) } else { Space::new() };
    drop(v192_3);
    let v192_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v192_4));
    drop(v192_4);
    let v192_8: Space = if (v192_5).is_empty() { Space::new() } else {
      let v193_6: Path = concat_path(&(*p0),&(v191_20_head));
      let mut v193_7 = Space::new();
      let mut v193_7_cursor = (v191_20_tail).read_zipper();
      for v193_7_byte in v193_7_cursor.child_mask().iter() {
        v193_7_cursor.descend_to_byte(v193_7_byte);
        {
        let v193_7_tail = v193_7_cursor.fork_read_zipper();
        let v193_7_head = Path::from_slice(&[v193_7_byte]);
        let v194_2: Space = singleton(&(v193_7_head));
        let v194_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v194_2));
        let v194_4: Space = if map_kernels::has_head(&(v194_3)) { singleton(&[]) } else { Space::new() };
        drop(v194_3);
        let v194_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v194_4));
        drop(v194_4);
        let v194_8: Space = if (v194_5).is_empty() { Space::new() } else {
          let v195_6: Path = concat_path(&(v193_6),&(v193_7_head));
          let mut v195_7 = Space::new();
          let mut v195_7_cursor = (v193_7_tail).read_zipper();
          for v195_7_byte in v195_7_cursor.child_mask().iter() {
            v195_7_cursor.descend_to_byte(v195_7_byte);
            {
            let v195_7_tail = v195_7_cursor.fork_read_zipper();
            let v195_7_head = Path::from_slice(&[v195_7_byte]);
            let v196_2: Space = singleton(&(v195_7_head));
            let v196_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v196_2));
            let v196_4: Space = if map_kernels::has_head(&(v196_3)) { singleton(&[]) } else { Space::new() };
            drop(v196_3);
            let v196_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v196_4));
            drop(v196_4);
            let v196_8: Space = if (v196_5).is_empty() { Space::new() } else {
              let v197_6: Path = concat_path(&(v195_6),&(v195_7_head));
              let v197_7: Space = routine_24(c, &(v197_6), &(v195_7_tail).make_space());
              map_map_kernels::compose(&(v196_5),&(v197_7))
            };
            drop(v196_5);
            let v196_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v196_2));
            drop(v196_2);
            let v196_10: Space = if map_kernels::has_head(&(v196_9)) { singleton(&[]) } else { Space::new() };
            drop(v196_9);
            let v196_12: Space = if (v196_10).is_empty() { Space::new() } else {
              let v198_6: Path = concat_path(&(v195_6),&(v195_7_head));
              let v198_11: Space = routine_25(c, &(v198_6), &(v195_7_tail).make_space());
              drop(v198_6);
              map_map_kernels::compose(&(v196_10),&(v198_11))
            };
            drop(v196_10);
            let v196_13: Space = map_map_kernels::unite(&(v196_8),&(v196_12));
            v195_7.join_into((v196_13).clone());
            }
            v195_7_cursor.ascend(1);
          }
          drop(v195_7_cursor);
          map_map_kernels::compose(&(v194_5),&(v195_7))
        };
        drop(v194_5);
        let v194_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v194_2));
        drop(v194_2);
        let v194_10: Space = if map_kernels::has_head(&(v194_9)) { singleton(&[]) } else { Space::new() };
        drop(v194_9);
        let v194_12: Space = if (v194_10).is_empty() { Space::new() } else {
          let v199_6: Path = concat_path(&(v193_6),&(v193_7_head));
          let mut v199_11 = Space::new();
          let mut v199_11_cursor = (v193_7_tail).read_zipper();
          for v199_11_byte in v199_11_cursor.child_mask().iter() {
            v199_11_cursor.descend_to_byte(v199_11_byte);
            {
            let v199_11_tail = v199_11_cursor.fork_read_zipper();
            let v199_11_head = Path::from_slice(&[v199_11_byte]);
            let v200_2: Space = singleton(&(v199_11_head));
            let v200_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v200_2));
            let v200_4: Space = if map_kernels::has_head(&(v200_3)) { singleton(&[]) } else { Space::new() };
            drop(v200_3);
            let v200_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v200_4));
            drop(v200_4);
            let v200_8: Space = if (v200_5).is_empty() { Space::new() } else {
              let v201_6: Path = concat_path(&(v199_6),&(v199_11_head));
              let v201_7: Space = routine_24(c, &(v201_6), &(v199_11_tail).make_space());
              map_map_kernels::compose(&(v200_5),&(v201_7))
            };
            drop(v200_5);
            let v200_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v200_2));
            drop(v200_2);
            let v200_10: Space = if map_kernels::has_head(&(v200_9)) { singleton(&[]) } else { Space::new() };
            drop(v200_9);
            let v200_12: Space = if (v200_10).is_empty() { Space::new() } else {
              let v202_6: Path = concat_path(&(v199_6),&(v199_11_head));
              let v202_11: Space = routine_15(c, &(v202_6), &(v199_11_tail).make_space());
              drop(v202_6);
              map_map_kernels::compose(&(v200_10),&(v202_11))
            };
            drop(v200_10);
            let v200_13: Space = map_map_kernels::unite(&(v200_8),&(v200_12));
            v199_11.join_into((v200_13).clone());
            }
            v199_11_cursor.ascend(1);
          }
          drop(v199_11_cursor);
          drop(v199_6);
          map_map_kernels::compose(&(v194_10),&(v199_11))
        };
        drop(v194_10);
        let v194_13: Space = map_map_kernels::unite(&(v194_8),&(v194_12));
        v193_7.join_into((v194_13).clone());
        }
        v193_7_cursor.ascend(1);
      }
      drop(v193_7_cursor);
      map_map_kernels::compose(&(v192_5),&(v193_7))
    };
    drop(v192_5);
    let v192_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v192_2));
    drop(v192_2);
    let v192_10: Space = if map_kernels::has_head(&(v192_9)) { singleton(&[]) } else { Space::new() };
    drop(v192_9);
    let v192_12: Space = if (v192_10).is_empty() { Space::new() } else {
      let v203_6: Path = concat_path(&(*p0),&(v191_20_head));
      let mut v203_11 = Space::new();
      let mut v203_11_cursor = (v191_20_tail).read_zipper();
      for v203_11_byte in v203_11_cursor.child_mask().iter() {
        v203_11_cursor.descend_to_byte(v203_11_byte);
        {
        let v203_11_tail = v203_11_cursor.fork_read_zipper();
        let v203_11_head = Path::from_slice(&[v203_11_byte]);
        let v204_2: Space = singleton(&(v203_11_head));
        let v204_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v204_2));
        let v204_4: Space = if map_kernels::has_head(&(v204_3)) { singleton(&[]) } else { Space::new() };
        drop(v204_3);
        let v204_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v204_4));
        drop(v204_4);
        let v204_8: Space = if (v204_5).is_empty() { Space::new() } else {
          let v205_6: Path = concat_path(&(v203_6),&(v203_11_head));
          let mut v205_7 = Space::new();
          let mut v205_7_cursor = (v203_11_tail).read_zipper();
          for v205_7_byte in v205_7_cursor.child_mask().iter() {
            v205_7_cursor.descend_to_byte(v205_7_byte);
            {
            let v205_7_tail = v205_7_cursor.fork_read_zipper();
            let v205_7_head = Path::from_slice(&[v205_7_byte]);
            let v206_2: Space = singleton(&(v205_7_head));
            let v206_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v206_2));
            let v206_4: Space = if map_kernels::has_head(&(v206_3)) { singleton(&[]) } else { Space::new() };
            drop(v206_3);
            let v206_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v206_4));
            drop(v206_4);
            let v206_8: Space = if (v206_5).is_empty() { Space::new() } else {
              let v207_6: Path = concat_path(&(v205_6),&(v205_7_head));
              let v207_7: Space = routine_24(c, &(v207_6), &(v205_7_tail).make_space());
              map_map_kernels::compose(&(v206_5),&(v207_7))
            };
            drop(v206_5);
            let v206_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v206_2));
            drop(v206_2);
            let v206_10: Space = if map_kernels::has_head(&(v206_9)) { singleton(&[]) } else { Space::new() };
            drop(v206_9);
            let v206_12: Space = if (v206_10).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v205_6),&(v205_7_head));
              let v208_11: Space = routine_25(c, &(v208_6), &(v205_7_tail).make_space());
              drop(v208_6);
              map_map_kernels::compose(&(v206_10),&(v208_11))
            };
            drop(v206_10);
            let v206_13: Space = map_map_kernels::unite(&(v206_8),&(v206_12));
            v205_7.join_into((v206_13).clone());
            }
            v205_7_cursor.ascend(1);
          }
          drop(v205_7_cursor);
          drop(v205_6);
          map_map_kernels::compose(&(v204_5),&(v205_7))
        };
        drop(v204_5);
        let v204_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v204_2));
        drop(v204_2);
        let v204_10: Space = if map_kernels::has_head(&(v204_9)) { singleton(&[]) } else { Space::new() };
        drop(v204_9);
        let v204_11: Space = map_view_kernels::compose(&(v204_10),&(v203_11_tail));
        drop(v204_10);
        let v204_12: Space = map_map_kernels::unite(&(v204_8),&(v204_11));
        drop(v204_11);
        v203_11.join_into((v204_12).clone());
        }
        v203_11_cursor.ascend(1);
      }
      drop(v203_11_cursor);
      drop(v203_6);
      map_map_kernels::compose(&(v192_10),&(v203_11))
    };
    drop(v192_10);
    let v192_13: Space = map_map_kernels::unite(&(v192_8),&(v192_12));
    v191_20.join_into((v192_13).clone());
    }
    v191_20_cursor.ascend(1);
  }
  drop(v191_20_cursor);
  (v191_20).clone()
}

fn routine_9(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v209_14 = Space::new();
  let mut v209_14_cursor = (*s0).read_zipper();
  for v209_14_byte in v209_14_cursor.child_mask().iter() {
    v209_14_cursor.descend_to_byte(v209_14_byte);
    {
    let v209_14_tail = v209_14_cursor.fork_read_zipper();
    let v209_14_head = Path::from_slice(&[v209_14_byte]);
    let v210_2: Space = singleton(&(v209_14_head));
    let v210_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v210_2));
    let v210_4: Space = if map_kernels::has_head(&(v210_3)) { singleton(&[]) } else { Space::new() };
    drop(v210_3);
    let v210_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v210_4));
    drop(v210_4);
    let v210_8: Space = if (v210_5).is_empty() { Space::new() } else {
      let v211_6: Path = concat_path(&(*p0),&(v209_14_head));
      let mut v211_7 = Space::new();
      let mut v211_7_cursor = (v209_14_tail).read_zipper();
      for v211_7_byte in v211_7_cursor.child_mask().iter() {
        v211_7_cursor.descend_to_byte(v211_7_byte);
        {
        let v211_7_tail = v211_7_cursor.fork_read_zipper();
        let v211_7_head = Path::from_slice(&[v211_7_byte]);
        let v212_2: Space = singleton(&(v211_7_head));
        let v212_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v212_2));
        let v212_4: Space = if map_kernels::has_head(&(v212_3)) { singleton(&[]) } else { Space::new() };
        drop(v212_3);
        let v212_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v212_4));
        drop(v212_4);
        let v212_8: Space = if (v212_5).is_empty() { Space::new() } else {
          let v213_6: Path = concat_path(&(v211_6),&(v211_7_head));
          let mut v213_7 = Space::new();
          let mut v213_7_cursor = (v211_7_tail).read_zipper();
          for v213_7_byte in v213_7_cursor.child_mask().iter() {
            v213_7_cursor.descend_to_byte(v213_7_byte);
            {
            let v213_7_tail = v213_7_cursor.fork_read_zipper();
            let v213_7_head = Path::from_slice(&[v213_7_byte]);
            let v214_2: Space = singleton(&(v213_7_head));
            let v214_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v214_2));
            let v214_4: Space = if map_kernels::has_head(&(v214_3)) { singleton(&[]) } else { Space::new() };
            drop(v214_3);
            let v214_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v214_4));
            drop(v214_4);
            let v214_8: Space = if (v214_5).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v213_6),&(v213_7_head));
              let v215_7: Space = routine_24(c, &(v215_6), &(v213_7_tail).make_space());
              map_map_kernels::compose(&(v214_5),&(v215_7))
            };
            drop(v214_5);
            let v214_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v214_2));
            drop(v214_2);
            let v214_10: Space = if map_kernels::has_head(&(v214_9)) { singleton(&[]) } else { Space::new() };
            drop(v214_9);
            let v214_12: Space = if (v214_10).is_empty() { Space::new() } else {
              let v216_6: Path = concat_path(&(v213_6),&(v213_7_head));
              let v216_11: Space = routine_25(c, &(v216_6), &(v213_7_tail).make_space());
              drop(v216_6);
              map_map_kernels::compose(&(v214_10),&(v216_11))
            };
            drop(v214_10);
            let v214_13: Space = map_map_kernels::unite(&(v214_8),&(v214_12));
            v213_7.join_into((v214_13).clone());
            }
            v213_7_cursor.ascend(1);
          }
          drop(v213_7_cursor);
          map_map_kernels::compose(&(v212_5),&(v213_7))
        };
        drop(v212_5);
        let v212_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v212_2));
        drop(v212_2);
        let v212_10: Space = if map_kernels::has_head(&(v212_9)) { singleton(&[]) } else { Space::new() };
        drop(v212_9);
        let v212_12: Space = if (v212_10).is_empty() { Space::new() } else {
          let v217_6: Path = concat_path(&(v211_6),&(v211_7_head));
          let mut v217_11 = Space::new();
          let mut v217_11_cursor = (v211_7_tail).read_zipper();
          for v217_11_byte in v217_11_cursor.child_mask().iter() {
            v217_11_cursor.descend_to_byte(v217_11_byte);
            {
            let v217_11_tail = v217_11_cursor.fork_read_zipper();
            let v217_11_head = Path::from_slice(&[v217_11_byte]);
            let v218_2: Space = singleton(&(v217_11_head));
            let v218_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v218_2));
            let v218_4: Space = if map_kernels::has_head(&(v218_3)) { singleton(&[]) } else { Space::new() };
            drop(v218_3);
            let v218_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v218_4));
            drop(v218_4);
            let v218_8: Space = if (v218_5).is_empty() { Space::new() } else {
              let v219_6: Path = concat_path(&(v217_6),&(v217_11_head));
              let v219_7: Space = routine_24(c, &(v219_6), &(v217_11_tail).make_space());
              map_map_kernels::compose(&(v218_5),&(v219_7))
            };
            drop(v218_5);
            let v218_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v218_2));
            drop(v218_2);
            let v218_10: Space = if map_kernels::has_head(&(v218_9)) { singleton(&[]) } else { Space::new() };
            drop(v218_9);
            let v218_12: Space = if (v218_10).is_empty() { Space::new() } else {
              let v220_6: Path = concat_path(&(v217_6),&(v217_11_head));
              let v220_11: Space = routine_15(c, &(v220_6), &(v217_11_tail).make_space());
              drop(v220_6);
              map_map_kernels::compose(&(v218_10),&(v220_11))
            };
            drop(v218_10);
            let v218_13: Space = map_map_kernels::unite(&(v218_8),&(v218_12));
            v217_11.join_into((v218_13).clone());
            }
            v217_11_cursor.ascend(1);
          }
          drop(v217_11_cursor);
          drop(v217_6);
          map_map_kernels::compose(&(v212_10),&(v217_11))
        };
        drop(v212_10);
        let v212_13: Space = map_map_kernels::unite(&(v212_8),&(v212_12));
        v211_7.join_into((v212_13).clone());
        }
        v211_7_cursor.ascend(1);
      }
      drop(v211_7_cursor);
      drop(v211_6);
      map_map_kernels::compose(&(v210_5),&(v211_7))
    };
    drop(v210_5);
    let v210_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v210_2));
    drop(v210_2);
    let v210_10: Space = if map_kernels::has_head(&(v210_9)) { singleton(&[]) } else { Space::new() };
    drop(v210_9);
    let v210_11: Space = map_view_kernels::compose(&(v210_10),&(v209_14_tail));
    drop(v210_10);
    let v210_12: Space = map_map_kernels::unite(&(v210_8),&(v210_11));
    drop(v210_11);
    v209_14.join_into((v210_12).clone());
    }
    v209_14_cursor.ascend(1);
  }
  drop(v209_14_cursor);
  (v209_14).clone()
}

fn routine_10(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v221_20 = Space::new();
  let mut v221_20_cursor = (*s0).read_zipper();
  for v221_20_byte in v221_20_cursor.child_mask().iter() {
    v221_20_cursor.descend_to_byte(v221_20_byte);
    {
    let v221_20_tail = v221_20_cursor.fork_read_zipper();
    let v221_20_head = Path::from_slice(&[v221_20_byte]);
    let v222_2: Space = singleton(&(v221_20_head));
    let v222_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v222_2));
    let v222_4: Space = if map_kernels::has_head(&(v222_3)) { singleton(&[]) } else { Space::new() };
    drop(v222_3);
    let v222_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v222_4));
    drop(v222_4);
    let v222_8: Space = if (v222_5).is_empty() { Space::new() } else {
      let v223_6: Path = concat_path(&(*p0),&(v221_20_head));
      let mut v223_7 = Space::new();
      let mut v223_7_cursor = (v221_20_tail).read_zipper();
      for v223_7_byte in v223_7_cursor.child_mask().iter() {
        v223_7_cursor.descend_to_byte(v223_7_byte);
        {
        let v223_7_tail = v223_7_cursor.fork_read_zipper();
        let v223_7_head = Path::from_slice(&[v223_7_byte]);
        let v224_2: Space = singleton(&(v223_7_head));
        let v224_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v224_2));
        let v224_4: Space = if map_kernels::has_head(&(v224_3)) { singleton(&[]) } else { Space::new() };
        drop(v224_3);
        let v224_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v224_4));
        drop(v224_4);
        let v224_8: Space = if (v224_5).is_empty() { Space::new() } else {
          let v225_6: Path = concat_path(&(v223_6),&(v223_7_head));
          let mut v225_7 = Space::new();
          let mut v225_7_cursor = (v223_7_tail).read_zipper();
          for v225_7_byte in v225_7_cursor.child_mask().iter() {
            v225_7_cursor.descend_to_byte(v225_7_byte);
            {
            let v225_7_tail = v225_7_cursor.fork_read_zipper();
            let v225_7_head = Path::from_slice(&[v225_7_byte]);
            let v226_2: Space = singleton(&(v225_7_head));
            let v226_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v226_2));
            let v226_4: Space = if map_kernels::has_head(&(v226_3)) { singleton(&[]) } else { Space::new() };
            drop(v226_3);
            let v226_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v226_4));
            drop(v226_4);
            let v226_8: Space = if (v226_5).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v225_6),&(v225_7_head));
              let v227_7: Space = routine_26(c, &(v227_6), &(v225_7_tail).make_space());
              map_map_kernels::compose(&(v226_5),&(v227_7))
            };
            drop(v226_5);
            let v226_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v226_2));
            drop(v226_2);
            let v226_10: Space = if map_kernels::has_head(&(v226_9)) { singleton(&[]) } else { Space::new() };
            drop(v226_9);
            let v226_12: Space = if (v226_10).is_empty() { Space::new() } else {
              let v228_6: Path = concat_path(&(v225_6),&(v225_7_head));
              let v228_11: Space = routine_27(c, &(v228_6), &(v225_7_tail).make_space());
              drop(v228_6);
              map_map_kernels::compose(&(v226_10),&(v228_11))
            };
            drop(v226_10);
            let v226_13: Space = map_map_kernels::unite(&(v226_8),&(v226_12));
            v225_7.join_into((v226_13).clone());
            }
            v225_7_cursor.ascend(1);
          }
          drop(v225_7_cursor);
          map_map_kernels::compose(&(v224_5),&(v225_7))
        };
        drop(v224_5);
        let v224_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v224_2));
        drop(v224_2);
        let v224_10: Space = if map_kernels::has_head(&(v224_9)) { singleton(&[]) } else { Space::new() };
        drop(v224_9);
        let v224_12: Space = if (v224_10).is_empty() { Space::new() } else {
          let v229_6: Path = concat_path(&(v223_6),&(v223_7_head));
          let mut v229_11 = Space::new();
          let mut v229_11_cursor = (v223_7_tail).read_zipper();
          for v229_11_byte in v229_11_cursor.child_mask().iter() {
            v229_11_cursor.descend_to_byte(v229_11_byte);
            {
            let v229_11_tail = v229_11_cursor.fork_read_zipper();
            let v229_11_head = Path::from_slice(&[v229_11_byte]);
            let v230_2: Space = singleton(&(v229_11_head));
            let v230_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v230_2));
            let v230_4: Space = if map_kernels::has_head(&(v230_3)) { singleton(&[]) } else { Space::new() };
            drop(v230_3);
            let v230_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v230_4));
            drop(v230_4);
            let v230_8: Space = if (v230_5).is_empty() { Space::new() } else {
              let v231_6: Path = concat_path(&(v229_6),&(v229_11_head));
              let v231_7: Space = routine_26(c, &(v231_6), &(v229_11_tail).make_space());
              map_map_kernels::compose(&(v230_5),&(v231_7))
            };
            drop(v230_5);
            let v230_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v230_2));
            drop(v230_2);
            let v230_10: Space = if map_kernels::has_head(&(v230_9)) { singleton(&[]) } else { Space::new() };
            drop(v230_9);
            let v230_12: Space = if (v230_10).is_empty() { Space::new() } else {
              let v232_6: Path = concat_path(&(v229_6),&(v229_11_head));
              let v232_11: Space = routine_12(c, &(v232_6), &(v229_11_tail).make_space());
              drop(v232_6);
              map_map_kernels::compose(&(v230_10),&(v232_11))
            };
            drop(v230_10);
            let v230_13: Space = map_map_kernels::unite(&(v230_8),&(v230_12));
            v229_11.join_into((v230_13).clone());
            }
            v229_11_cursor.ascend(1);
          }
          drop(v229_11_cursor);
          drop(v229_6);
          map_map_kernels::compose(&(v224_10),&(v229_11))
        };
        drop(v224_10);
        let v224_13: Space = map_map_kernels::unite(&(v224_8),&(v224_12));
        v223_7.join_into((v224_13).clone());
        }
        v223_7_cursor.ascend(1);
      }
      drop(v223_7_cursor);
      map_map_kernels::compose(&(v222_5),&(v223_7))
    };
    drop(v222_5);
    let v222_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v222_2));
    drop(v222_2);
    let v222_10: Space = if map_kernels::has_head(&(v222_9)) { singleton(&[]) } else { Space::new() };
    drop(v222_9);
    let v222_12: Space = if (v222_10).is_empty() { Space::new() } else {
      let v233_6: Path = concat_path(&(*p0),&(v221_20_head));
      let mut v233_11 = Space::new();
      let mut v233_11_cursor = (v221_20_tail).read_zipper();
      for v233_11_byte in v233_11_cursor.child_mask().iter() {
        v233_11_cursor.descend_to_byte(v233_11_byte);
        {
        let v233_11_tail = v233_11_cursor.fork_read_zipper();
        let v233_11_head = Path::from_slice(&[v233_11_byte]);
        let v234_2: Space = singleton(&(v233_11_head));
        let v234_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v234_2));
        let v234_4: Space = if map_kernels::has_head(&(v234_3)) { singleton(&[]) } else { Space::new() };
        drop(v234_3);
        let v234_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v234_4));
        drop(v234_4);
        let v234_8: Space = if (v234_5).is_empty() { Space::new() } else {
          let v235_6: Path = concat_path(&(v233_6),&(v233_11_head));
          let mut v235_7 = Space::new();
          let mut v235_7_cursor = (v233_11_tail).read_zipper();
          for v235_7_byte in v235_7_cursor.child_mask().iter() {
            v235_7_cursor.descend_to_byte(v235_7_byte);
            {
            let v235_7_tail = v235_7_cursor.fork_read_zipper();
            let v235_7_head = Path::from_slice(&[v235_7_byte]);
            let v236_2: Space = singleton(&(v235_7_head));
            let v236_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v236_2));
            let v236_4: Space = if map_kernels::has_head(&(v236_3)) { singleton(&[]) } else { Space::new() };
            drop(v236_3);
            let v236_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v236_4));
            drop(v236_4);
            let v236_8: Space = if (v236_5).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v235_6),&(v235_7_head));
              let v237_7: Space = routine_26(c, &(v237_6), &(v235_7_tail).make_space());
              map_map_kernels::compose(&(v236_5),&(v237_7))
            };
            drop(v236_5);
            let v236_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v236_2));
            drop(v236_2);
            let v236_10: Space = if map_kernels::has_head(&(v236_9)) { singleton(&[]) } else { Space::new() };
            drop(v236_9);
            let v236_12: Space = if (v236_10).is_empty() { Space::new() } else {
              let v238_6: Path = concat_path(&(v235_6),&(v235_7_head));
              let v238_11: Space = routine_27(c, &(v238_6), &(v235_7_tail).make_space());
              drop(v238_6);
              map_map_kernels::compose(&(v236_10),&(v238_11))
            };
            drop(v236_10);
            let v236_13: Space = map_map_kernels::unite(&(v236_8),&(v236_12));
            v235_7.join_into((v236_13).clone());
            }
            v235_7_cursor.ascend(1);
          }
          drop(v235_7_cursor);
          drop(v235_6);
          map_map_kernels::compose(&(v234_5),&(v235_7))
        };
        drop(v234_5);
        let v234_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v234_2));
        drop(v234_2);
        let v234_10: Space = if map_kernels::has_head(&(v234_9)) { singleton(&[]) } else { Space::new() };
        drop(v234_9);
        let v234_11: Space = map_view_kernels::compose(&(v234_10),&(v233_11_tail));
        drop(v234_10);
        let v234_12: Space = map_map_kernels::unite(&(v234_8),&(v234_11));
        drop(v234_11);
        v233_11.join_into((v234_12).clone());
        }
        v233_11_cursor.ascend(1);
      }
      drop(v233_11_cursor);
      drop(v233_6);
      map_map_kernels::compose(&(v222_10),&(v233_11))
    };
    drop(v222_10);
    let v222_13: Space = map_map_kernels::unite(&(v222_8),&(v222_12));
    v221_20.join_into((v222_13).clone());
    }
    v221_20_cursor.ascend(1);
  }
  drop(v221_20_cursor);
  (v221_20).clone()
}

fn routine_11(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v239_14 = Space::new();
  let mut v239_14_cursor = (*s0).read_zipper();
  for v239_14_byte in v239_14_cursor.child_mask().iter() {
    v239_14_cursor.descend_to_byte(v239_14_byte);
    {
    let v239_14_tail = v239_14_cursor.fork_read_zipper();
    let v239_14_head = Path::from_slice(&[v239_14_byte]);
    let v240_2: Space = singleton(&(v239_14_head));
    let v240_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v240_2));
    let v240_4: Space = if map_kernels::has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (v240_5).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&(v239_14_head));
      let mut v241_7 = Space::new();
      let mut v241_7_cursor = (v239_14_tail).read_zipper();
      for v241_7_byte in v241_7_cursor.child_mask().iter() {
        v241_7_cursor.descend_to_byte(v241_7_byte);
        {
        let v241_7_tail = v241_7_cursor.fork_read_zipper();
        let v241_7_head = Path::from_slice(&[v241_7_byte]);
        let v242_2: Space = singleton(&(v241_7_head));
        let v242_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v242_2));
        let v242_4: Space = if map_kernels::has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (v242_5).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&(v241_7_head));
          let mut v243_7 = Space::new();
          let mut v243_7_cursor = (v241_7_tail).read_zipper();
          for v243_7_byte in v243_7_cursor.child_mask().iter() {
            v243_7_cursor.descend_to_byte(v243_7_byte);
            {
            let v243_7_tail = v243_7_cursor.fork_read_zipper();
            let v243_7_head = Path::from_slice(&[v243_7_byte]);
            let v244_2: Space = singleton(&(v243_7_head));
            let v244_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v244_2));
            let v244_4: Space = if map_kernels::has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (v244_5).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&(v243_7_head));
              let v245_7: Space = routine_26(c, &(v245_6), &(v243_7_tail).make_space());
              map_map_kernels::compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if map_kernels::has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (v244_10).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&(v243_7_head));
              let v246_11: Space = routine_27(c, &(v246_6), &(v243_7_tail).make_space());
              drop(v246_6);
              map_map_kernels::compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = map_map_kernels::unite(&(v244_8),&(v244_12));
            v243_7.join_into((v244_13).clone());
            }
            v243_7_cursor.ascend(1);
          }
          drop(v243_7_cursor);
          map_map_kernels::compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if map_kernels::has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (v242_10).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&(v241_7_head));
          let mut v247_11 = Space::new();
          let mut v247_11_cursor = (v241_7_tail).read_zipper();
          for v247_11_byte in v247_11_cursor.child_mask().iter() {
            v247_11_cursor.descend_to_byte(v247_11_byte);
            {
            let v247_11_tail = v247_11_cursor.fork_read_zipper();
            let v247_11_head = Path::from_slice(&[v247_11_byte]);
            let v248_2: Space = singleton(&(v247_11_head));
            let v248_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v248_2));
            let v248_4: Space = if map_kernels::has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&(v247_11_head));
              let v249_7: Space = routine_26(c, &(v249_6), &(v247_11_tail).make_space());
              map_map_kernels::compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if map_kernels::has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&(v247_11_head));
              let v250_11: Space = routine_12(c, &(v250_6), &(v247_11_tail).make_space());
              drop(v250_6);
              map_map_kernels::compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = map_map_kernels::unite(&(v248_8),&(v248_12));
            v247_11.join_into((v248_13).clone());
            }
            v247_11_cursor.ascend(1);
          }
          drop(v247_11_cursor);
          drop(v247_6);
          map_map_kernels::compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = map_map_kernels::unite(&(v242_8),&(v242_12));
        v241_7.join_into((v242_13).clone());
        }
        v241_7_cursor.ascend(1);
      }
      drop(v241_7_cursor);
      drop(v241_6);
      map_map_kernels::compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if map_kernels::has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_11: Space = map_view_kernels::compose(&(v240_10),&(v239_14_tail));
    drop(v240_10);
    let v240_12: Space = map_map_kernels::unite(&(v240_8),&(v240_11));
    drop(v240_11);
    v239_14.join_into((v240_12).clone());
    }
    v239_14_cursor.ascend(1);
  }
  drop(v239_14_cursor);
  (v239_14).clone()
}

fn routine_12(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_13(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v252_20 = Space::new();
  let mut v252_20_cursor = (*s0).read_zipper();
  for v252_20_byte in v252_20_cursor.child_mask().iter() {
    v252_20_cursor.descend_to_byte(v252_20_byte);
    {
    let v252_20_tail = v252_20_cursor.fork_read_zipper();
    let v252_20_head = Path::from_slice(&[v252_20_byte]);
    let v253_2: Space = singleton(&(v252_20_head));
    let v253_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v253_2));
    let v253_4: Space = if map_kernels::has_head(&(v253_3)) { singleton(&[]) } else { Space::new() };
    drop(v253_3);
    let v253_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v253_4));
    drop(v253_4);
    let v253_8: Space = if (v253_5).is_empty() { Space::new() } else {
      let v254_6: Path = concat_path(&(*p0),&(v252_20_head));
      let mut v254_7 = Space::new();
      let mut v254_7_cursor = (v252_20_tail).read_zipper();
      for v254_7_byte in v254_7_cursor.child_mask().iter() {
        v254_7_cursor.descend_to_byte(v254_7_byte);
        {
        let v254_7_tail = v254_7_cursor.fork_read_zipper();
        let v254_7_head = Path::from_slice(&[v254_7_byte]);
        let v255_2: Space = singleton(&(v254_7_head));
        let v255_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v255_2));
        let v255_4: Space = if map_kernels::has_head(&(v255_3)) { singleton(&[]) } else { Space::new() };
        drop(v255_3);
        let v255_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v255_4));
        drop(v255_4);
        let v255_8: Space = if (v255_5).is_empty() { Space::new() } else {
          let v256_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let mut v256_7 = Space::new();
          let mut v256_7_cursor = (v254_7_tail).read_zipper();
          for v256_7_byte in v256_7_cursor.child_mask().iter() {
            v256_7_cursor.descend_to_byte(v256_7_byte);
            {
            let v256_7_tail = v256_7_cursor.fork_read_zipper();
            let v256_7_head = Path::from_slice(&[v256_7_byte]);
            let v257_2: Space = singleton(&(v256_7_head));
            let v257_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v257_2));
            let v257_4: Space = if map_kernels::has_head(&(v257_3)) { singleton(&[]) } else { Space::new() };
            drop(v257_3);
            let v257_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v257_4));
            drop(v257_4);
            let v257_8: Space = if (v257_5).is_empty() { Space::new() } else {
              let v258_6: Path = concat_path(&(v256_6),&(v256_7_head));
              let v258_7: Space = routine_28(c, &(v258_6), &(v256_7_tail).make_space());
              map_map_kernels::compose(&(v257_5),&(v258_7))
            };
            drop(v257_5);
            let v257_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v257_2));
            drop(v257_2);
            let v257_10: Space = if map_kernels::has_head(&(v257_9)) { singleton(&[]) } else { Space::new() };
            drop(v257_9);
            let v257_12: Space = if (v257_10).is_empty() { Space::new() } else {
              let v259_6: Path = concat_path(&(v256_6),&(v256_7_head));
              let v259_11: Space = routine_29(c, &(v259_6), &(v256_7_tail).make_space());
              drop(v259_6);
              map_map_kernels::compose(&(v257_10),&(v259_11))
            };
            drop(v257_10);
            let v257_13: Space = map_map_kernels::unite(&(v257_8),&(v257_12));
            v256_7.join_into((v257_13).clone());
            }
            v256_7_cursor.ascend(1);
          }
          drop(v256_7_cursor);
          map_map_kernels::compose(&(v255_5),&(v256_7))
        };
        drop(v255_5);
        let v255_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v255_2));
        drop(v255_2);
        let v255_10: Space = if map_kernels::has_head(&(v255_9)) { singleton(&[]) } else { Space::new() };
        drop(v255_9);
        let v255_12: Space = if (v255_10).is_empty() { Space::new() } else {
          let v260_6: Path = concat_path(&(v254_6),&(v254_7_head));
          let mut v260_11 = Space::new();
          let mut v260_11_cursor = (v254_7_tail).read_zipper();
          for v260_11_byte in v260_11_cursor.child_mask().iter() {
            v260_11_cursor.descend_to_byte(v260_11_byte);
            {
            let v260_11_tail = v260_11_cursor.fork_read_zipper();
            let v260_11_head = Path::from_slice(&[v260_11_byte]);
            let v261_2: Space = singleton(&(v260_11_head));
            let v261_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v261_2));
            let v261_4: Space = if map_kernels::has_head(&(v261_3)) { singleton(&[]) } else { Space::new() };
            drop(v261_3);
            let v261_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v261_4));
            drop(v261_4);
            let v261_8: Space = if (v261_5).is_empty() { Space::new() } else {
              let v262_6: Path = concat_path(&(v260_6),&(v260_11_head));
              let v262_7: Space = routine_28(c, &(v262_6), &(v260_11_tail).make_space());
              map_map_kernels::compose(&(v261_5),&(v262_7))
            };
            drop(v261_5);
            let v261_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v261_2));
            drop(v261_2);
            let v261_10: Space = if map_kernels::has_head(&(v261_9)) { singleton(&[]) } else { Space::new() };
            drop(v261_9);
            let v261_12: Space = if (v261_10).is_empty() { Space::new() } else {
              let v263_6: Path = concat_path(&(v260_6),&(v260_11_head));
              let v263_11: Space = routine_15(c, &(v263_6), &(v260_11_tail).make_space());
              drop(v263_6);
              map_map_kernels::compose(&(v261_10),&(v263_11))
            };
            drop(v261_10);
            let v261_13: Space = map_map_kernels::unite(&(v261_8),&(v261_12));
            v260_11.join_into((v261_13).clone());
            }
            v260_11_cursor.ascend(1);
          }
          drop(v260_11_cursor);
          drop(v260_6);
          map_map_kernels::compose(&(v255_10),&(v260_11))
        };
        drop(v255_10);
        let v255_13: Space = map_map_kernels::unite(&(v255_8),&(v255_12));
        v254_7.join_into((v255_13).clone());
        }
        v254_7_cursor.ascend(1);
      }
      drop(v254_7_cursor);
      map_map_kernels::compose(&(v253_5),&(v254_7))
    };
    drop(v253_5);
    let v253_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v253_2));
    drop(v253_2);
    let v253_10: Space = if map_kernels::has_head(&(v253_9)) { singleton(&[]) } else { Space::new() };
    drop(v253_9);
    let v253_12: Space = if (v253_10).is_empty() { Space::new() } else {
      let v264_6: Path = concat_path(&(*p0),&(v252_20_head));
      let mut v264_11 = Space::new();
      let mut v264_11_cursor = (v252_20_tail).read_zipper();
      for v264_11_byte in v264_11_cursor.child_mask().iter() {
        v264_11_cursor.descend_to_byte(v264_11_byte);
        {
        let v264_11_tail = v264_11_cursor.fork_read_zipper();
        let v264_11_head = Path::from_slice(&[v264_11_byte]);
        let v265_2: Space = singleton(&(v264_11_head));
        let v265_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v265_2));
        let v265_4: Space = if map_kernels::has_head(&(v265_3)) { singleton(&[]) } else { Space::new() };
        drop(v265_3);
        let v265_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v265_4));
        drop(v265_4);
        let v265_8: Space = if (v265_5).is_empty() { Space::new() } else {
          let v266_6: Path = concat_path(&(v264_6),&(v264_11_head));
          let mut v266_7 = Space::new();
          let mut v266_7_cursor = (v264_11_tail).read_zipper();
          for v266_7_byte in v266_7_cursor.child_mask().iter() {
            v266_7_cursor.descend_to_byte(v266_7_byte);
            {
            let v266_7_tail = v266_7_cursor.fork_read_zipper();
            let v266_7_head = Path::from_slice(&[v266_7_byte]);
            let v267_2: Space = singleton(&(v266_7_head));
            let v267_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v267_2));
            let v267_4: Space = if map_kernels::has_head(&(v267_3)) { singleton(&[]) } else { Space::new() };
            drop(v267_3);
            let v267_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v267_4));
            drop(v267_4);
            let v267_8: Space = if (v267_5).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v266_6),&(v266_7_head));
              let v268_7: Space = routine_28(c, &(v268_6), &(v266_7_tail).make_space());
              map_map_kernels::compose(&(v267_5),&(v268_7))
            };
            drop(v267_5);
            let v267_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v267_2));
            drop(v267_2);
            let v267_10: Space = if map_kernels::has_head(&(v267_9)) { singleton(&[]) } else { Space::new() };
            drop(v267_9);
            let v267_12: Space = if (v267_10).is_empty() { Space::new() } else {
              let v269_6: Path = concat_path(&(v266_6),&(v266_7_head));
              let v269_11: Space = routine_29(c, &(v269_6), &(v266_7_tail).make_space());
              drop(v269_6);
              map_map_kernels::compose(&(v267_10),&(v269_11))
            };
            drop(v267_10);
            let v267_13: Space = map_map_kernels::unite(&(v267_8),&(v267_12));
            v266_7.join_into((v267_13).clone());
            }
            v266_7_cursor.ascend(1);
          }
          drop(v266_7_cursor);
          drop(v266_6);
          map_map_kernels::compose(&(v265_5),&(v266_7))
        };
        drop(v265_5);
        let v265_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v265_2));
        drop(v265_2);
        let v265_10: Space = if map_kernels::has_head(&(v265_9)) { singleton(&[]) } else { Space::new() };
        drop(v265_9);
        let v265_11: Space = map_view_kernels::compose(&(v265_10),&(v264_11_tail));
        drop(v265_10);
        let v265_12: Space = map_map_kernels::unite(&(v265_8),&(v265_11));
        drop(v265_11);
        v264_11.join_into((v265_12).clone());
        }
        v264_11_cursor.ascend(1);
      }
      drop(v264_11_cursor);
      drop(v264_6);
      map_map_kernels::compose(&(v253_10),&(v264_11))
    };
    drop(v253_10);
    let v253_13: Space = map_map_kernels::unite(&(v253_8),&(v253_12));
    v252_20.join_into((v253_13).clone());
    }
    v252_20_cursor.ascend(1);
  }
  drop(v252_20_cursor);
  (v252_20).clone()
}

fn routine_14(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v270_14 = Space::new();
  let mut v270_14_cursor = (*s0).read_zipper();
  for v270_14_byte in v270_14_cursor.child_mask().iter() {
    v270_14_cursor.descend_to_byte(v270_14_byte);
    {
    let v270_14_tail = v270_14_cursor.fork_read_zipper();
    let v270_14_head = Path::from_slice(&[v270_14_byte]);
    let v271_2: Space = singleton(&(v270_14_head));
    let v271_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v271_2));
    let v271_4: Space = if map_kernels::has_head(&(v271_3)) { singleton(&[]) } else { Space::new() };
    drop(v271_3);
    let v271_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v271_4));
    drop(v271_4);
    let v271_8: Space = if (v271_5).is_empty() { Space::new() } else {
      let v272_6: Path = concat_path(&(*p0),&(v270_14_head));
      let mut v272_7 = Space::new();
      let mut v272_7_cursor = (v270_14_tail).read_zipper();
      for v272_7_byte in v272_7_cursor.child_mask().iter() {
        v272_7_cursor.descend_to_byte(v272_7_byte);
        {
        let v272_7_tail = v272_7_cursor.fork_read_zipper();
        let v272_7_head = Path::from_slice(&[v272_7_byte]);
        let v273_2: Space = singleton(&(v272_7_head));
        let v273_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v273_2));
        let v273_4: Space = if map_kernels::has_head(&(v273_3)) { singleton(&[]) } else { Space::new() };
        drop(v273_3);
        let v273_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v273_4));
        drop(v273_4);
        let v273_8: Space = if (v273_5).is_empty() { Space::new() } else {
          let v274_6: Path = concat_path(&(v272_6),&(v272_7_head));
          let mut v274_7 = Space::new();
          let mut v274_7_cursor = (v272_7_tail).read_zipper();
          for v274_7_byte in v274_7_cursor.child_mask().iter() {
            v274_7_cursor.descend_to_byte(v274_7_byte);
            {
            let v274_7_tail = v274_7_cursor.fork_read_zipper();
            let v274_7_head = Path::from_slice(&[v274_7_byte]);
            let v275_2: Space = singleton(&(v274_7_head));
            let v275_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v275_2));
            let v275_4: Space = if map_kernels::has_head(&(v275_3)) { singleton(&[]) } else { Space::new() };
            drop(v275_3);
            let v275_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v275_4));
            drop(v275_4);
            let v275_8: Space = if (v275_5).is_empty() { Space::new() } else {
              let v276_6: Path = concat_path(&(v274_6),&(v274_7_head));
              let v276_7: Space = routine_28(c, &(v276_6), &(v274_7_tail).make_space());
              map_map_kernels::compose(&(v275_5),&(v276_7))
            };
            drop(v275_5);
            let v275_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v275_2));
            drop(v275_2);
            let v275_10: Space = if map_kernels::has_head(&(v275_9)) { singleton(&[]) } else { Space::new() };
            drop(v275_9);
            let v275_12: Space = if (v275_10).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v274_6),&(v274_7_head));
              let v277_11: Space = routine_29(c, &(v277_6), &(v274_7_tail).make_space());
              drop(v277_6);
              map_map_kernels::compose(&(v275_10),&(v277_11))
            };
            drop(v275_10);
            let v275_13: Space = map_map_kernels::unite(&(v275_8),&(v275_12));
            v274_7.join_into((v275_13).clone());
            }
            v274_7_cursor.ascend(1);
          }
          drop(v274_7_cursor);
          map_map_kernels::compose(&(v273_5),&(v274_7))
        };
        drop(v273_5);
        let v273_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v273_2));
        drop(v273_2);
        let v273_10: Space = if map_kernels::has_head(&(v273_9)) { singleton(&[]) } else { Space::new() };
        drop(v273_9);
        let v273_12: Space = if (v273_10).is_empty() { Space::new() } else {
          let v278_6: Path = concat_path(&(v272_6),&(v272_7_head));
          let mut v278_11 = Space::new();
          let mut v278_11_cursor = (v272_7_tail).read_zipper();
          for v278_11_byte in v278_11_cursor.child_mask().iter() {
            v278_11_cursor.descend_to_byte(v278_11_byte);
            {
            let v278_11_tail = v278_11_cursor.fork_read_zipper();
            let v278_11_head = Path::from_slice(&[v278_11_byte]);
            let v279_2: Space = singleton(&(v278_11_head));
            let v279_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v279_2));
            let v279_4: Space = if map_kernels::has_head(&(v279_3)) { singleton(&[]) } else { Space::new() };
            drop(v279_3);
            let v279_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v279_4));
            drop(v279_4);
            let v279_8: Space = if (v279_5).is_empty() { Space::new() } else {
              let v280_6: Path = concat_path(&(v278_6),&(v278_11_head));
              let v280_7: Space = routine_28(c, &(v280_6), &(v278_11_tail).make_space());
              map_map_kernels::compose(&(v279_5),&(v280_7))
            };
            drop(v279_5);
            let v279_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v279_2));
            drop(v279_2);
            let v279_10: Space = if map_kernels::has_head(&(v279_9)) { singleton(&[]) } else { Space::new() };
            drop(v279_9);
            let v279_12: Space = if (v279_10).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v278_6),&(v278_11_head));
              let v281_11: Space = routine_15(c, &(v281_6), &(v278_11_tail).make_space());
              drop(v281_6);
              map_map_kernels::compose(&(v279_10),&(v281_11))
            };
            drop(v279_10);
            let v279_13: Space = map_map_kernels::unite(&(v279_8),&(v279_12));
            v278_11.join_into((v279_13).clone());
            }
            v278_11_cursor.ascend(1);
          }
          drop(v278_11_cursor);
          drop(v278_6);
          map_map_kernels::compose(&(v273_10),&(v278_11))
        };
        drop(v273_10);
        let v273_13: Space = map_map_kernels::unite(&(v273_8),&(v273_12));
        v272_7.join_into((v273_13).clone());
        }
        v272_7_cursor.ascend(1);
      }
      drop(v272_7_cursor);
      drop(v272_6);
      map_map_kernels::compose(&(v271_5),&(v272_7))
    };
    drop(v271_5);
    let v271_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v271_2));
    drop(v271_2);
    let v271_10: Space = if map_kernels::has_head(&(v271_9)) { singleton(&[]) } else { Space::new() };
    drop(v271_9);
    let v271_11: Space = map_view_kernels::compose(&(v271_10),&(v270_14_tail));
    drop(v271_10);
    let v271_12: Space = map_map_kernels::unite(&(v271_8),&(v271_11));
    drop(v271_11);
    v270_14.join_into((v271_12).clone());
    }
    v270_14_cursor.ascend(1);
  }
  drop(v270_14_cursor);
  (v270_14).clone()
}

fn routine_15(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  (*s0).clone()
}

fn routine_16(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v283_20 = Space::new();
  let mut v283_20_cursor = (*s0).read_zipper();
  for v283_20_byte in v283_20_cursor.child_mask().iter() {
    v283_20_cursor.descend_to_byte(v283_20_byte);
    {
    let v283_20_tail = v283_20_cursor.fork_read_zipper();
    let v283_20_head = Path::from_slice(&[v283_20_byte]);
    let v284_2: Space = singleton(&(v283_20_head));
    let v284_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v284_2));
    let v284_4: Space = if map_kernels::has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (v284_5).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&(v283_20_head));
      let mut v285_7 = Space::new();
      let mut v285_7_cursor = (v283_20_tail).read_zipper();
      for v285_7_byte in v285_7_cursor.child_mask().iter() {
        v285_7_cursor.descend_to_byte(v285_7_byte);
        {
        let v285_7_tail = v285_7_cursor.fork_read_zipper();
        let v285_7_head = Path::from_slice(&[v285_7_byte]);
        let v286_2: Space = singleton(&(v285_7_head));
        let v286_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v286_2));
        let v286_4: Space = if map_kernels::has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (v286_5).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&(v285_7_head));
          let mut v287_7 = Space::new();
          let mut v287_7_cursor = (v285_7_tail).read_zipper();
          for v287_7_byte in v287_7_cursor.child_mask().iter() {
            v287_7_cursor.descend_to_byte(v287_7_byte);
            {
            let v287_7_tail = v287_7_cursor.fork_read_zipper();
            let v287_7_head = Path::from_slice(&[v287_7_byte]);
            let v288_2: Space = singleton(&(v287_7_head));
            let v288_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v288_2));
            let v288_4: Space = if map_kernels::has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (v288_5).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&(v287_7_head));
              let v289_7: Space = routine_30(c, &(v289_6), &(v287_7_tail).make_space());
              map_map_kernels::compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if map_kernels::has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (v288_10).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&(v287_7_head));
              let v290_11: Space = routine_31(c, &(v290_6), &(v287_7_tail).make_space());
              drop(v290_6);
              map_map_kernels::compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = map_map_kernels::unite(&(v288_8),&(v288_12));
            v287_7.join_into((v288_13).clone());
            }
            v287_7_cursor.ascend(1);
          }
          drop(v287_7_cursor);
          map_map_kernels::compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if map_kernels::has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (v286_10).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&(v285_7_head));
          let mut v291_11 = Space::new();
          let mut v291_11_cursor = (v285_7_tail).read_zipper();
          for v291_11_byte in v291_11_cursor.child_mask().iter() {
            v291_11_cursor.descend_to_byte(v291_11_byte);
            {
            let v291_11_tail = v291_11_cursor.fork_read_zipper();
            let v291_11_head = Path::from_slice(&[v291_11_byte]);
            let v292_2: Space = singleton(&(v291_11_head));
            let v292_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v292_2));
            let v292_4: Space = if map_kernels::has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&(v291_11_head));
              let v293_7: Space = routine_30(c, &(v293_6), &(v291_11_tail).make_space());
              map_map_kernels::compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if map_kernels::has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (v292_10).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&(v291_11_head));
              let v294_11: Space = routine_12(c, &(v294_6), &(v291_11_tail).make_space());
              drop(v294_6);
              map_map_kernels::compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = map_map_kernels::unite(&(v292_8),&(v292_12));
            v291_11.join_into((v292_13).clone());
            }
            v291_11_cursor.ascend(1);
          }
          drop(v291_11_cursor);
          drop(v291_6);
          map_map_kernels::compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = map_map_kernels::unite(&(v286_8),&(v286_12));
        v285_7.join_into((v286_13).clone());
        }
        v285_7_cursor.ascend(1);
      }
      drop(v285_7_cursor);
      map_map_kernels::compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if map_kernels::has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (v284_10).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&(v283_20_head));
      let mut v295_11 = Space::new();
      let mut v295_11_cursor = (v283_20_tail).read_zipper();
      for v295_11_byte in v295_11_cursor.child_mask().iter() {
        v295_11_cursor.descend_to_byte(v295_11_byte);
        {
        let v295_11_tail = v295_11_cursor.fork_read_zipper();
        let v295_11_head = Path::from_slice(&[v295_11_byte]);
        let v296_2: Space = singleton(&(v295_11_head));
        let v296_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v296_2));
        let v296_4: Space = if map_kernels::has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (v296_5).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&(v295_11_head));
          let mut v297_7 = Space::new();
          let mut v297_7_cursor = (v295_11_tail).read_zipper();
          for v297_7_byte in v297_7_cursor.child_mask().iter() {
            v297_7_cursor.descend_to_byte(v297_7_byte);
            {
            let v297_7_tail = v297_7_cursor.fork_read_zipper();
            let v297_7_head = Path::from_slice(&[v297_7_byte]);
            let v298_2: Space = singleton(&(v297_7_head));
            let v298_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v298_2));
            let v298_4: Space = if map_kernels::has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (v298_5).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&(v297_7_head));
              let v299_7: Space = routine_30(c, &(v299_6), &(v297_7_tail).make_space());
              map_map_kernels::compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if map_kernels::has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (v298_10).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&(v297_7_head));
              let v300_11: Space = routine_31(c, &(v300_6), &(v297_7_tail).make_space());
              drop(v300_6);
              map_map_kernels::compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = map_map_kernels::unite(&(v298_8),&(v298_12));
            v297_7.join_into((v298_13).clone());
            }
            v297_7_cursor.ascend(1);
          }
          drop(v297_7_cursor);
          drop(v297_6);
          map_map_kernels::compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if map_kernels::has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = map_view_kernels::compose(&(v296_10),&(v295_11_tail));
        drop(v296_10);
        let v296_12: Space = map_map_kernels::unite(&(v296_8),&(v296_11));
        drop(v296_11);
        v295_11.join_into((v296_12).clone());
        }
        v295_11_cursor.ascend(1);
      }
      drop(v295_11_cursor);
      drop(v295_6);
      map_map_kernels::compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = map_map_kernels::unite(&(v284_8),&(v284_12));
    v283_20.join_into((v284_13).clone());
    }
    v283_20_cursor.ascend(1);
  }
  drop(v283_20_cursor);
  (v283_20).clone()
}

fn routine_17(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v301_14 = Space::new();
  let mut v301_14_cursor = (*s0).read_zipper();
  for v301_14_byte in v301_14_cursor.child_mask().iter() {
    v301_14_cursor.descend_to_byte(v301_14_byte);
    {
    let v301_14_tail = v301_14_cursor.fork_read_zipper();
    let v301_14_head = Path::from_slice(&[v301_14_byte]);
    let v302_2: Space = singleton(&(v301_14_head));
    let v302_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v302_2));
    let v302_4: Space = if map_kernels::has_head(&(v302_3)) { singleton(&[]) } else { Space::new() };
    drop(v302_3);
    let v302_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v302_4));
    drop(v302_4);
    let v302_8: Space = if (v302_5).is_empty() { Space::new() } else {
      let v303_6: Path = concat_path(&(*p0),&(v301_14_head));
      let mut v303_7 = Space::new();
      let mut v303_7_cursor = (v301_14_tail).read_zipper();
      for v303_7_byte in v303_7_cursor.child_mask().iter() {
        v303_7_cursor.descend_to_byte(v303_7_byte);
        {
        let v303_7_tail = v303_7_cursor.fork_read_zipper();
        let v303_7_head = Path::from_slice(&[v303_7_byte]);
        let v304_2: Space = singleton(&(v303_7_head));
        let v304_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v304_2));
        let v304_4: Space = if map_kernels::has_head(&(v304_3)) { singleton(&[]) } else { Space::new() };
        drop(v304_3);
        let v304_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v304_4));
        drop(v304_4);
        let v304_8: Space = if (v304_5).is_empty() { Space::new() } else {
          let v305_6: Path = concat_path(&(v303_6),&(v303_7_head));
          let mut v305_7 = Space::new();
          let mut v305_7_cursor = (v303_7_tail).read_zipper();
          for v305_7_byte in v305_7_cursor.child_mask().iter() {
            v305_7_cursor.descend_to_byte(v305_7_byte);
            {
            let v305_7_tail = v305_7_cursor.fork_read_zipper();
            let v305_7_head = Path::from_slice(&[v305_7_byte]);
            let v306_2: Space = singleton(&(v305_7_head));
            let v306_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v306_2));
            let v306_4: Space = if map_kernels::has_head(&(v306_3)) { singleton(&[]) } else { Space::new() };
            drop(v306_3);
            let v306_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v306_4));
            drop(v306_4);
            let v306_8: Space = if (v306_5).is_empty() { Space::new() } else {
              let v307_6: Path = concat_path(&(v305_6),&(v305_7_head));
              let v307_7: Space = routine_30(c, &(v307_6), &(v305_7_tail).make_space());
              map_map_kernels::compose(&(v306_5),&(v307_7))
            };
            drop(v306_5);
            let v306_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v306_2));
            drop(v306_2);
            let v306_10: Space = if map_kernels::has_head(&(v306_9)) { singleton(&[]) } else { Space::new() };
            drop(v306_9);
            let v306_12: Space = if (v306_10).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v305_6),&(v305_7_head));
              let v308_11: Space = routine_31(c, &(v308_6), &(v305_7_tail).make_space());
              drop(v308_6);
              map_map_kernels::compose(&(v306_10),&(v308_11))
            };
            drop(v306_10);
            let v306_13: Space = map_map_kernels::unite(&(v306_8),&(v306_12));
            v305_7.join_into((v306_13).clone());
            }
            v305_7_cursor.ascend(1);
          }
          drop(v305_7_cursor);
          map_map_kernels::compose(&(v304_5),&(v305_7))
        };
        drop(v304_5);
        let v304_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v304_2));
        drop(v304_2);
        let v304_10: Space = if map_kernels::has_head(&(v304_9)) { singleton(&[]) } else { Space::new() };
        drop(v304_9);
        let v304_12: Space = if (v304_10).is_empty() { Space::new() } else {
          let v309_6: Path = concat_path(&(v303_6),&(v303_7_head));
          let mut v309_11 = Space::new();
          let mut v309_11_cursor = (v303_7_tail).read_zipper();
          for v309_11_byte in v309_11_cursor.child_mask().iter() {
            v309_11_cursor.descend_to_byte(v309_11_byte);
            {
            let v309_11_tail = v309_11_cursor.fork_read_zipper();
            let v309_11_head = Path::from_slice(&[v309_11_byte]);
            let v310_2: Space = singleton(&(v309_11_head));
            let v310_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v310_2));
            let v310_4: Space = if map_kernels::has_head(&(v310_3)) { singleton(&[]) } else { Space::new() };
            drop(v310_3);
            let v310_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v310_4));
            drop(v310_4);
            let v310_8: Space = if (v310_5).is_empty() { Space::new() } else {
              let v311_6: Path = concat_path(&(v309_6),&(v309_11_head));
              let v311_7: Space = routine_30(c, &(v311_6), &(v309_11_tail).make_space());
              map_map_kernels::compose(&(v310_5),&(v311_7))
            };
            drop(v310_5);
            let v310_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v310_2));
            drop(v310_2);
            let v310_10: Space = if map_kernels::has_head(&(v310_9)) { singleton(&[]) } else { Space::new() };
            drop(v310_9);
            let v310_12: Space = if (v310_10).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v309_6),&(v309_11_head));
              let v312_11: Space = routine_12(c, &(v312_6), &(v309_11_tail).make_space());
              drop(v312_6);
              map_map_kernels::compose(&(v310_10),&(v312_11))
            };
            drop(v310_10);
            let v310_13: Space = map_map_kernels::unite(&(v310_8),&(v310_12));
            v309_11.join_into((v310_13).clone());
            }
            v309_11_cursor.ascend(1);
          }
          drop(v309_11_cursor);
          drop(v309_6);
          map_map_kernels::compose(&(v304_10),&(v309_11))
        };
        drop(v304_10);
        let v304_13: Space = map_map_kernels::unite(&(v304_8),&(v304_12));
        v303_7.join_into((v304_13).clone());
        }
        v303_7_cursor.ascend(1);
      }
      drop(v303_7_cursor);
      drop(v303_6);
      map_map_kernels::compose(&(v302_5),&(v303_7))
    };
    drop(v302_5);
    let v302_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v302_2));
    drop(v302_2);
    let v302_10: Space = if map_kernels::has_head(&(v302_9)) { singleton(&[]) } else { Space::new() };
    drop(v302_9);
    let v302_11: Space = map_view_kernels::compose(&(v302_10),&(v301_14_tail));
    drop(v302_10);
    let v302_12: Space = map_map_kernels::unite(&(v302_8),&(v302_11));
    drop(v302_11);
    v301_14.join_into((v302_12).clone());
    }
    v301_14_cursor.ascend(1);
  }
  drop(v301_14_cursor);
  (v301_14).clone()
}

fn routine_18(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v313_20 = Space::new();
  let mut v313_20_cursor = (*s0).read_zipper();
  for v313_20_byte in v313_20_cursor.child_mask().iter() {
    v313_20_cursor.descend_to_byte(v313_20_byte);
    {
    let v313_20_tail = v313_20_cursor.fork_read_zipper();
    let v313_20_head = Path::from_slice(&[v313_20_byte]);
    let v314_2: Space = singleton(&(v313_20_head));
    let v314_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v314_2));
    let v314_4: Space = if map_kernels::has_head(&(v314_3)) { singleton(&[]) } else { Space::new() };
    drop(v314_3);
    let v314_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v314_4));
    drop(v314_4);
    let v314_8: Space = if (v314_5).is_empty() { Space::new() } else {
      let v315_6: Path = concat_path(&(*p0),&(v313_20_head));
      let mut v315_7 = Space::new();
      let mut v315_7_cursor = (v313_20_tail).read_zipper();
      for v315_7_byte in v315_7_cursor.child_mask().iter() {
        v315_7_cursor.descend_to_byte(v315_7_byte);
        {
        let v315_7_tail = v315_7_cursor.fork_read_zipper();
        let v315_7_head = Path::from_slice(&[v315_7_byte]);
        let v316_2: Space = singleton(&(v315_7_head));
        let v316_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v316_2));
        let v316_4: Space = if map_kernels::has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
        drop(v316_3);
        let v316_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v316_4));
        drop(v316_4);
        let v316_8: Space = if (v316_5).is_empty() { Space::new() } else {
          let v317_6: Path = concat_path(&(v315_6),&(v315_7_head));
          let mut v317_7 = Space::new();
          let mut v317_7_cursor = (v315_7_tail).read_zipper();
          for v317_7_byte in v317_7_cursor.child_mask().iter() {
            v317_7_cursor.descend_to_byte(v317_7_byte);
            {
            let v317_7_tail = v317_7_cursor.fork_read_zipper();
            let v317_7_head = Path::from_slice(&[v317_7_byte]);
            let v318_2: Space = singleton(&(v317_7_head));
            let v318_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v318_2));
            let v318_4: Space = if map_kernels::has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
            drop(v318_3);
            let v318_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v318_4));
            drop(v318_4);
            let v318_8: Space = if (v318_5).is_empty() { Space::new() } else {
              let v319_6: Path = concat_path(&(v317_6),&(v317_7_head));
              let v319_7: Space = routine_32(c, &(v319_6), &(v317_7_tail).make_space());
              map_map_kernels::compose(&(v318_5),&(v319_7))
            };
            drop(v318_5);
            let v318_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v318_2));
            drop(v318_2);
            let v318_10: Space = if map_kernels::has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
            drop(v318_9);
            let v318_12: Space = if (v318_10).is_empty() { Space::new() } else {
              let v320_6: Path = concat_path(&(v317_6),&(v317_7_head));
              let v320_11: Space = routine_33(c, &(v320_6), &(v317_7_tail).make_space());
              drop(v320_6);
              map_map_kernels::compose(&(v318_10),&(v320_11))
            };
            drop(v318_10);
            let v318_13: Space = map_map_kernels::unite(&(v318_8),&(v318_12));
            v317_7.join_into((v318_13).clone());
            }
            v317_7_cursor.ascend(1);
          }
          drop(v317_7_cursor);
          map_map_kernels::compose(&(v316_5),&(v317_7))
        };
        drop(v316_5);
        let v316_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v316_2));
        drop(v316_2);
        let v316_10: Space = if map_kernels::has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
        drop(v316_9);
        let v316_12: Space = if (v316_10).is_empty() { Space::new() } else {
          let v321_6: Path = concat_path(&(v315_6),&(v315_7_head));
          let mut v321_11 = Space::new();
          let mut v321_11_cursor = (v315_7_tail).read_zipper();
          for v321_11_byte in v321_11_cursor.child_mask().iter() {
            v321_11_cursor.descend_to_byte(v321_11_byte);
            {
            let v321_11_tail = v321_11_cursor.fork_read_zipper();
            let v321_11_head = Path::from_slice(&[v321_11_byte]);
            let v322_2: Space = singleton(&(v321_11_head));
            let v322_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v322_2));
            let v322_4: Space = if map_kernels::has_head(&(v322_3)) { singleton(&[]) } else { Space::new() };
            drop(v322_3);
            let v322_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v322_4));
            drop(v322_4);
            let v322_8: Space = if (v322_5).is_empty() { Space::new() } else {
              let v323_6: Path = concat_path(&(v321_6),&(v321_11_head));
              let v323_7: Space = routine_32(c, &(v323_6), &(v321_11_tail).make_space());
              map_map_kernels::compose(&(v322_5),&(v323_7))
            };
            drop(v322_5);
            let v322_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v322_2));
            drop(v322_2);
            let v322_10: Space = if map_kernels::has_head(&(v322_9)) { singleton(&[]) } else { Space::new() };
            drop(v322_9);
            let v322_12: Space = if (v322_10).is_empty() { Space::new() } else {
              let v324_6: Path = concat_path(&(v321_6),&(v321_11_head));
              let v324_11: Space = routine_15(c, &(v324_6), &(v321_11_tail).make_space());
              drop(v324_6);
              map_map_kernels::compose(&(v322_10),&(v324_11))
            };
            drop(v322_10);
            let v322_13: Space = map_map_kernels::unite(&(v322_8),&(v322_12));
            v321_11.join_into((v322_13).clone());
            }
            v321_11_cursor.ascend(1);
          }
          drop(v321_11_cursor);
          drop(v321_6);
          map_map_kernels::compose(&(v316_10),&(v321_11))
        };
        drop(v316_10);
        let v316_13: Space = map_map_kernels::unite(&(v316_8),&(v316_12));
        v315_7.join_into((v316_13).clone());
        }
        v315_7_cursor.ascend(1);
      }
      drop(v315_7_cursor);
      map_map_kernels::compose(&(v314_5),&(v315_7))
    };
    drop(v314_5);
    let v314_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v314_2));
    drop(v314_2);
    let v314_10: Space = if map_kernels::has_head(&(v314_9)) { singleton(&[]) } else { Space::new() };
    drop(v314_9);
    let v314_12: Space = if (v314_10).is_empty() { Space::new() } else {
      let v325_6: Path = concat_path(&(*p0),&(v313_20_head));
      let mut v325_11 = Space::new();
      let mut v325_11_cursor = (v313_20_tail).read_zipper();
      for v325_11_byte in v325_11_cursor.child_mask().iter() {
        v325_11_cursor.descend_to_byte(v325_11_byte);
        {
        let v325_11_tail = v325_11_cursor.fork_read_zipper();
        let v325_11_head = Path::from_slice(&[v325_11_byte]);
        let v326_2: Space = singleton(&(v325_11_head));
        let v326_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v326_2));
        let v326_4: Space = if map_kernels::has_head(&(v326_3)) { singleton(&[]) } else { Space::new() };
        drop(v326_3);
        let v326_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v326_4));
        drop(v326_4);
        let v326_8: Space = if (v326_5).is_empty() { Space::new() } else {
          let v327_6: Path = concat_path(&(v325_6),&(v325_11_head));
          let mut v327_7 = Space::new();
          let mut v327_7_cursor = (v325_11_tail).read_zipper();
          for v327_7_byte in v327_7_cursor.child_mask().iter() {
            v327_7_cursor.descend_to_byte(v327_7_byte);
            {
            let v327_7_tail = v327_7_cursor.fork_read_zipper();
            let v327_7_head = Path::from_slice(&[v327_7_byte]);
            let v328_2: Space = singleton(&(v327_7_head));
            let v328_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v328_2));
            let v328_4: Space = if map_kernels::has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
            drop(v328_3);
            let v328_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v328_4));
            drop(v328_4);
            let v328_8: Space = if (v328_5).is_empty() { Space::new() } else {
              let v329_6: Path = concat_path(&(v327_6),&(v327_7_head));
              let v329_7: Space = routine_32(c, &(v329_6), &(v327_7_tail).make_space());
              map_map_kernels::compose(&(v328_5),&(v329_7))
            };
            drop(v328_5);
            let v328_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v328_2));
            drop(v328_2);
            let v328_10: Space = if map_kernels::has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
            drop(v328_9);
            let v328_12: Space = if (v328_10).is_empty() { Space::new() } else {
              let v330_6: Path = concat_path(&(v327_6),&(v327_7_head));
              let v330_11: Space = routine_33(c, &(v330_6), &(v327_7_tail).make_space());
              drop(v330_6);
              map_map_kernels::compose(&(v328_10),&(v330_11))
            };
            drop(v328_10);
            let v328_13: Space = map_map_kernels::unite(&(v328_8),&(v328_12));
            v327_7.join_into((v328_13).clone());
            }
            v327_7_cursor.ascend(1);
          }
          drop(v327_7_cursor);
          drop(v327_6);
          map_map_kernels::compose(&(v326_5),&(v327_7))
        };
        drop(v326_5);
        let v326_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v326_2));
        drop(v326_2);
        let v326_10: Space = if map_kernels::has_head(&(v326_9)) { singleton(&[]) } else { Space::new() };
        drop(v326_9);
        let v326_11: Space = map_view_kernels::compose(&(v326_10),&(v325_11_tail));
        drop(v326_10);
        let v326_12: Space = map_map_kernels::unite(&(v326_8),&(v326_11));
        drop(v326_11);
        v325_11.join_into((v326_12).clone());
        }
        v325_11_cursor.ascend(1);
      }
      drop(v325_11_cursor);
      drop(v325_6);
      map_map_kernels::compose(&(v314_10),&(v325_11))
    };
    drop(v314_10);
    let v314_13: Space = map_map_kernels::unite(&(v314_8),&(v314_12));
    v313_20.join_into((v314_13).clone());
    }
    v313_20_cursor.ascend(1);
  }
  drop(v313_20_cursor);
  (v313_20).clone()
}

fn routine_19(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v331_14 = Space::new();
  let mut v331_14_cursor = (*s0).read_zipper();
  for v331_14_byte in v331_14_cursor.child_mask().iter() {
    v331_14_cursor.descend_to_byte(v331_14_byte);
    {
    let v331_14_tail = v331_14_cursor.fork_read_zipper();
    let v331_14_head = Path::from_slice(&[v331_14_byte]);
    let v332_2: Space = singleton(&(v331_14_head));
    let v332_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v332_2));
    let v332_4: Space = if map_kernels::has_head(&(v332_3)) { singleton(&[]) } else { Space::new() };
    drop(v332_3);
    let v332_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v332_4));
    drop(v332_4);
    let v332_8: Space = if (v332_5).is_empty() { Space::new() } else {
      let v333_6: Path = concat_path(&(*p0),&(v331_14_head));
      let mut v333_7 = Space::new();
      let mut v333_7_cursor = (v331_14_tail).read_zipper();
      for v333_7_byte in v333_7_cursor.child_mask().iter() {
        v333_7_cursor.descend_to_byte(v333_7_byte);
        {
        let v333_7_tail = v333_7_cursor.fork_read_zipper();
        let v333_7_head = Path::from_slice(&[v333_7_byte]);
        let v334_2: Space = singleton(&(v333_7_head));
        let v334_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v334_2));
        let v334_4: Space = if map_kernels::has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
        drop(v334_3);
        let v334_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v334_4));
        drop(v334_4);
        let v334_8: Space = if (v334_5).is_empty() { Space::new() } else {
          let v335_6: Path = concat_path(&(v333_6),&(v333_7_head));
          let mut v335_7 = Space::new();
          let mut v335_7_cursor = (v333_7_tail).read_zipper();
          for v335_7_byte in v335_7_cursor.child_mask().iter() {
            v335_7_cursor.descend_to_byte(v335_7_byte);
            {
            let v335_7_tail = v335_7_cursor.fork_read_zipper();
            let v335_7_head = Path::from_slice(&[v335_7_byte]);
            let v336_2: Space = singleton(&(v335_7_head));
            let v336_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v336_2));
            let v336_4: Space = if map_kernels::has_head(&(v336_3)) { singleton(&[]) } else { Space::new() };
            drop(v336_3);
            let v336_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v336_4));
            drop(v336_4);
            let v336_8: Space = if (v336_5).is_empty() { Space::new() } else {
              let v337_6: Path = concat_path(&(v335_6),&(v335_7_head));
              let v337_7: Space = routine_32(c, &(v337_6), &(v335_7_tail).make_space());
              map_map_kernels::compose(&(v336_5),&(v337_7))
            };
            drop(v336_5);
            let v336_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v336_2));
            drop(v336_2);
            let v336_10: Space = if map_kernels::has_head(&(v336_9)) { singleton(&[]) } else { Space::new() };
            drop(v336_9);
            let v336_12: Space = if (v336_10).is_empty() { Space::new() } else {
              let v338_6: Path = concat_path(&(v335_6),&(v335_7_head));
              let v338_11: Space = routine_33(c, &(v338_6), &(v335_7_tail).make_space());
              drop(v338_6);
              map_map_kernels::compose(&(v336_10),&(v338_11))
            };
            drop(v336_10);
            let v336_13: Space = map_map_kernels::unite(&(v336_8),&(v336_12));
            v335_7.join_into((v336_13).clone());
            }
            v335_7_cursor.ascend(1);
          }
          drop(v335_7_cursor);
          map_map_kernels::compose(&(v334_5),&(v335_7))
        };
        drop(v334_5);
        let v334_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v334_2));
        drop(v334_2);
        let v334_10: Space = if map_kernels::has_head(&(v334_9)) { singleton(&[]) } else { Space::new() };
        drop(v334_9);
        let v334_12: Space = if (v334_10).is_empty() { Space::new() } else {
          let v339_6: Path = concat_path(&(v333_6),&(v333_7_head));
          let mut v339_11 = Space::new();
          let mut v339_11_cursor = (v333_7_tail).read_zipper();
          for v339_11_byte in v339_11_cursor.child_mask().iter() {
            v339_11_cursor.descend_to_byte(v339_11_byte);
            {
            let v339_11_tail = v339_11_cursor.fork_read_zipper();
            let v339_11_head = Path::from_slice(&[v339_11_byte]);
            let v340_2: Space = singleton(&(v339_11_head));
            let v340_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v340_2));
            let v340_4: Space = if map_kernels::has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
            drop(v340_3);
            let v340_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v340_4));
            drop(v340_4);
            let v340_8: Space = if (v340_5).is_empty() { Space::new() } else {
              let v341_6: Path = concat_path(&(v339_6),&(v339_11_head));
              let v341_7: Space = routine_32(c, &(v341_6), &(v339_11_tail).make_space());
              map_map_kernels::compose(&(v340_5),&(v341_7))
            };
            drop(v340_5);
            let v340_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v340_2));
            drop(v340_2);
            let v340_10: Space = if map_kernels::has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
            drop(v340_9);
            let v340_12: Space = if (v340_10).is_empty() { Space::new() } else {
              let v342_6: Path = concat_path(&(v339_6),&(v339_11_head));
              let v342_11: Space = routine_15(c, &(v342_6), &(v339_11_tail).make_space());
              drop(v342_6);
              map_map_kernels::compose(&(v340_10),&(v342_11))
            };
            drop(v340_10);
            let v340_13: Space = map_map_kernels::unite(&(v340_8),&(v340_12));
            v339_11.join_into((v340_13).clone());
            }
            v339_11_cursor.ascend(1);
          }
          drop(v339_11_cursor);
          drop(v339_6);
          map_map_kernels::compose(&(v334_10),&(v339_11))
        };
        drop(v334_10);
        let v334_13: Space = map_map_kernels::unite(&(v334_8),&(v334_12));
        v333_7.join_into((v334_13).clone());
        }
        v333_7_cursor.ascend(1);
      }
      drop(v333_7_cursor);
      drop(v333_6);
      map_map_kernels::compose(&(v332_5),&(v333_7))
    };
    drop(v332_5);
    let v332_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v332_2));
    drop(v332_2);
    let v332_10: Space = if map_kernels::has_head(&(v332_9)) { singleton(&[]) } else { Space::new() };
    drop(v332_9);
    let v332_11: Space = map_view_kernels::compose(&(v332_10),&(v331_14_tail));
    drop(v332_10);
    let v332_12: Space = map_map_kernels::unite(&(v332_8),&(v332_11));
    drop(v332_11);
    v331_14.join_into((v332_12).clone());
    }
    v331_14_cursor.ascend(1);
  }
  drop(v331_14_cursor);
  (v331_14).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v343_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v343_22: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_4));
  let v343_23: Space = map_kernels::unwrap(&(v343_22),&(*p0));
  let v343_24: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
  let mut v343_34 = Space::new();
  let mut v343_34_cursor = (*s0).read_zipper();
  for v343_34_byte in v343_34_cursor.child_mask().iter() {
    v343_34_cursor.descend_to_byte(v343_34_byte);
    {
    let v343_34_tail = v343_34_cursor.fork_read_zipper();
    let v343_34_head = Path::from_slice(&[v343_34_byte]);
    let v344_2: Space = singleton(&(v343_34_head));
    let v344_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v344_2));
    let v344_4: Space = if map_kernels::has_head(&(v344_3)) { singleton(&[]) } else { Space::new() };
    drop(v344_3);
    let v344_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v344_4));
    drop(v344_4);
    let v344_8: Space = if (v344_5).is_empty() { Space::new() } else {
      let v345_6: Path = concat_path(&(*p0),&(v343_34_head));
      let mut v345_7 = Space::new();
      let mut v345_7_cursor = (v343_34_tail).read_zipper();
      for v345_7_byte in v345_7_cursor.child_mask().iter() {
        v345_7_cursor.descend_to_byte(v345_7_byte);
        {
        let v345_7_tail = v345_7_cursor.fork_read_zipper();
        let v345_7_head = Path::from_slice(&[v345_7_byte]);
        let v346_2: Space = singleton(&(v345_7_head));
        let v346_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v346_2));
        let v346_4: Space = if map_kernels::has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
        drop(v346_3);
        let v346_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v346_4));
        drop(v346_4);
        let v346_8: Space = if (v346_5).is_empty() { Space::new() } else {
          let v347_6: Path = concat_path(&(v345_6),&(v345_7_head));
          let mut v347_7 = Space::new();
          let mut v347_7_cursor = (v345_7_tail).read_zipper();
          for v347_7_byte in v347_7_cursor.child_mask().iter() {
            v347_7_cursor.descend_to_byte(v347_7_byte);
            {
            let v347_7_tail = v347_7_cursor.fork_read_zipper();
            let v347_7_head = Path::from_slice(&[v347_7_byte]);
            let v348_2: Space = singleton(&(v347_7_head));
            let v348_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v348_2));
            let v348_4: Space = if map_kernels::has_head(&(v348_3)) { singleton(&[]) } else { Space::new() };
            drop(v348_3);
            let v348_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v348_4));
            drop(v348_4);
            let v348_8: Space = if (v348_5).is_empty() { Space::new() } else {
              let v349_6: Path = concat_path(&(v347_6),&(v347_7_head));
              let v349_7: Space = routine_34(c, &(v349_6), &(v347_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v348_5),&(v349_7))
            };
            drop(v348_5);
            let v348_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v348_2));
            drop(v348_2);
            let v348_10: Space = if map_kernels::has_head(&(v348_9)) { singleton(&[]) } else { Space::new() };
            drop(v348_9);
            let v348_12: Space = if (v348_10).is_empty() { Space::new() } else {
              let v350_6: Path = concat_path(&(v347_6),&(v347_7_head));
              let v350_11: Space = routine_35(c, &(v350_6), &(v347_7_tail).make_space(), &(*s1));
              drop(v350_6);
              map_map_kernels::compose(&(v348_10),&(v350_11))
            };
            drop(v348_10);
            let v348_13: Space = map_map_kernels::unite(&(v348_8),&(v348_12));
            v347_7.join_into((v348_13).clone());
            }
            v347_7_cursor.ascend(1);
          }
          drop(v347_7_cursor);
          map_map_kernels::compose(&(v346_5),&(v347_7))
        };
        drop(v346_5);
        let v346_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v346_2));
        drop(v346_2);
        let v346_10: Space = if map_kernels::has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
        drop(v346_9);
        let v346_12: Space = if (v346_10).is_empty() { Space::new() } else {
          let v351_6: Path = concat_path(&(v345_6),&(v345_7_head));
          let mut v351_11 = Space::new();
          let mut v351_11_cursor = (v345_7_tail).read_zipper();
          for v351_11_byte in v351_11_cursor.child_mask().iter() {
            v351_11_cursor.descend_to_byte(v351_11_byte);
            {
            let v351_11_tail = v351_11_cursor.fork_read_zipper();
            let v351_11_head = Path::from_slice(&[v351_11_byte]);
            let v352_2: Space = singleton(&(v351_11_head));
            let v352_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v352_2));
            let v352_4: Space = if map_kernels::has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v352_4));
            drop(v352_4);
            let v352_8: Space = if (v352_5).is_empty() { Space::new() } else {
              let v353_6: Path = concat_path(&(v351_6),&(v351_11_head));
              let v353_7: Space = routine_34(c, &(v353_6), &(v351_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v352_5),&(v353_7))
            };
            drop(v352_5);
            let v352_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v352_2));
            drop(v352_2);
            let v352_10: Space = if map_kernels::has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
            drop(v352_9);
            let v352_12: Space = if (v352_10).is_empty() { Space::new() } else {
              let v354_6: Path = concat_path(&(v351_6),&(v351_11_head));
              let v354_11: Space = routine_3(c, &(v354_6), &(v351_11_tail).make_space(), &(*s1));
              drop(v354_6);
              map_map_kernels::compose(&(v352_10),&(v354_11))
            };
            drop(v352_10);
            let v352_13: Space = map_map_kernels::unite(&(v352_8),&(v352_12));
            v351_11.join_into((v352_13).clone());
            }
            v351_11_cursor.ascend(1);
          }
          drop(v351_11_cursor);
          drop(v351_6);
          map_map_kernels::compose(&(v346_10),&(v351_11))
        };
        drop(v346_10);
        let v346_13: Space = map_map_kernels::unite(&(v346_8),&(v346_12));
        v345_7.join_into((v346_13).clone());
        }
        v345_7_cursor.ascend(1);
      }
      drop(v345_7_cursor);
      map_map_kernels::compose(&(v344_5),&(v345_7))
    };
    drop(v344_5);
    let v344_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v344_2));
    drop(v344_2);
    let v344_10: Space = if map_kernels::has_head(&(v344_9)) { singleton(&[]) } else { Space::new() };
    drop(v344_9);
    let v344_13: Space = if (v344_10).is_empty() { Space::new() } else {
      let v355_6: Path = concat_path(&(*p0),&(v343_34_head));
      let v355_11: Space = map_kernels::unwrap(&(v343_23),&(v343_34_head));
      let mut v355_12 = Space::new();
      let mut v355_12_cursor = (v343_34_tail).read_zipper();
      for v355_12_byte in v355_12_cursor.child_mask().iter() {
        v355_12_cursor.descend_to_byte(v355_12_byte);
        {
        let v355_12_tail = v355_12_cursor.fork_read_zipper();
        let v355_12_head = Path::from_slice(&[v355_12_byte]);
        let v356_2: Space = singleton(&(v355_12_head));
        let v356_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v356_2));
        let v356_4: Space = if map_kernels::has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
        drop(v356_3);
        let v356_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v356_4));
        drop(v356_4);
        let v356_8: Space = if (v356_5).is_empty() { Space::new() } else {
          let v357_6: Path = concat_path(&(v355_6),&(v355_12_head));
          let mut v357_7 = Space::new();
          let mut v357_7_cursor = (v355_12_tail).read_zipper();
          for v357_7_byte in v357_7_cursor.child_mask().iter() {
            v357_7_cursor.descend_to_byte(v357_7_byte);
            {
            let v357_7_tail = v357_7_cursor.fork_read_zipper();
            let v357_7_head = Path::from_slice(&[v357_7_byte]);
            let v358_2: Space = singleton(&(v357_7_head));
            let v358_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v358_2));
            let v358_4: Space = if map_kernels::has_head(&(v358_3)) { singleton(&[]) } else { Space::new() };
            drop(v358_3);
            let v358_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v358_4));
            drop(v358_4);
            let v358_8: Space = if (v358_5).is_empty() { Space::new() } else {
              let v359_6: Path = concat_path(&(v357_6),&(v357_7_head));
              let v359_7: Space = routine_34(c, &(v359_6), &(v357_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v358_5),&(v359_7))
            };
            drop(v358_5);
            let v358_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v358_2));
            drop(v358_2);
            let v358_10: Space = if map_kernels::has_head(&(v358_9)) { singleton(&[]) } else { Space::new() };
            drop(v358_9);
            let v358_12: Space = if (v358_10).is_empty() { Space::new() } else {
              let v360_6: Path = concat_path(&(v357_6),&(v357_7_head));
              let v360_11: Space = routine_35(c, &(v360_6), &(v357_7_tail).make_space(), &(*s1));
              drop(v360_6);
              map_map_kernels::compose(&(v358_10),&(v360_11))
            };
            drop(v358_10);
            let v358_13: Space = map_map_kernels::unite(&(v358_8),&(v358_12));
            v357_7.join_into((v358_13).clone());
            }
            v357_7_cursor.ascend(1);
          }
          drop(v357_7_cursor);
          map_map_kernels::compose(&(v356_5),&(v357_7))
        };
        drop(v356_5);
        let v356_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v356_2));
        drop(v356_2);
        let v356_10: Space = if map_kernels::has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
        drop(v356_9);
        let v356_18: Space = if (v356_10).is_empty() { Space::new() } else {
          let v361_11: Space = map_kernels::unwrap(&(v355_11),&(v355_12_head));
          let v361_12: Space = map_map_kernels::restrict_to(&(v343_22),&(v361_11));
          let mut v361_13 = Space::new();
          let mut v361_13_cursor = (v361_12).read_zipper();
          for v361_13_byte in v361_13_cursor.child_mask().iter() {
            v361_13_cursor.descend_to_byte(v361_13_byte);
            {
            let v361_13_tail = v361_13_cursor.fork_read_zipper();
            let v361_13_head = Path::from_slice(&[v361_13_byte]);
            let v362_2: Space = singleton(&(v361_13_head));
            let v362_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v362_2));
            let v362_4: Space = if map_kernels::has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
            drop(v362_3);
            let v362_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v362_4));
            drop(v362_4);
            let v362_7: Space = if (v362_5).is_empty() { Space::new() } else {
              let v363_6: Space = routine_6(c, &(v361_13_head), &(v361_13_tail).make_space());
              map_map_kernels::compose(&(v362_5),&(v363_6))
            };
            drop(v362_5);
            let v362_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v362_2));
            drop(v362_2);
            let v362_9: Space = if map_kernels::has_head(&(v362_8)) { singleton(&[]) } else { Space::new() };
            drop(v362_8);
            let v362_11: Space = if (v362_9).is_empty() { Space::new() } else {
              let v364_10: Space = routine_7(c, &(v361_13_head), &(v361_13_tail).make_space());
              map_map_kernels::compose(&(v362_9),&(v364_10))
            };
            drop(v362_9);
            let v362_12: Space = map_map_kernels::unite(&(v362_7),&(v362_11));
            v361_13.join_into((v362_12).clone());
            }
            v361_13_cursor.ascend(1);
          }
          drop(v361_13_cursor);
          drop(v361_12);
          let v361_14: Space = map_map_kernels::restrict_to(&(v343_21),&(v361_13));
          let mut v361_15 = Space::new();
          let mut v361_15_cursor = (v361_14).read_zipper();
          for v361_15_byte in v361_15_cursor.child_mask().iter() {
            v361_15_cursor.descend_to_byte(v361_15_byte);
            {
            let v361_15_tail = v361_15_cursor.fork_read_zipper();
            let v361_15_head = Path::from_slice(&[v361_15_byte]);
            let v365_2: Space = singleton(&(v361_15_head));
            let v365_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v365_2));
            let v365_4: Space = if map_kernels::has_head(&(v365_3)) { singleton(&[]) } else { Space::new() };
            drop(v365_3);
            let v365_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v365_4));
            drop(v365_4);
            let v365_7: Space = if (v365_5).is_empty() { Space::new() } else {
              let v366_6: Space = routine_8(c, &(v361_15_head), &(v361_15_tail).make_space());
              map_map_kernels::compose(&(v365_5),&(v366_6))
            };
            drop(v365_5);
            let v365_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v365_2));
            drop(v365_2);
            let v365_9: Space = if map_kernels::has_head(&(v365_8)) { singleton(&[]) } else { Space::new() };
            drop(v365_8);
            let v365_11: Space = if (v365_9).is_empty() { Space::new() } else {
              let v367_10: Space = routine_9(c, &(v361_15_head), &(v361_15_tail).make_space());
              map_map_kernels::compose(&(v365_9),&(v367_10))
            };
            drop(v365_9);
            let v365_12: Space = map_map_kernels::unite(&(v365_7),&(v365_11));
            v361_15.join_into((v365_12).clone());
            }
            v361_15_cursor.ascend(1);
          }
          drop(v361_15_cursor);
          let v361_16: Space = map_map_kernels::subtract(&(v361_15),&(v361_11));
          drop(v361_11);
          let v361_17: Space = map_map_kernels::intersect(&(v361_16),&(v343_24));
          map_map_kernels::compose(&(v356_10),&(v361_17))
        };
        drop(v356_10);
        let v368_6: Path = concat_path(&(v355_6),&(v355_12_head));
        let v356_19: Space = map_kernels::wrap(&(v356_18),&(v368_6));
        let v356_20: Space = map_map_kernels::unite(&(v356_8),&(v356_19));
        v355_12.join_into((v356_20).clone());
        }
        v355_12_cursor.ascend(1);
      }
      drop(v355_12_cursor);
      drop(v355_6);
      drop(v355_11);
      map_map_kernels::compose(&(v344_10),&(v355_12))
    };
    drop(v344_10);
    let v344_14: Space = map_map_kernels::unite(&(v344_8),&(v344_13));
    v343_34.join_into((v344_14).clone());
    }
    v343_34_cursor.ascend(1);
  }
  drop(v343_34_cursor);
  drop(v343_21);
  drop(v343_22);
  drop(v343_23);
  drop(v343_24);
  (v343_34).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v369_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v369_9: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_4));
  let v369_10: Space = map_kernels::unwrap(&(v369_9),&(*p0));
  let v369_12: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
  let mut v369_40 = Space::new();
  let mut v369_40_cursor = (*s0).read_zipper();
  for v369_40_byte in v369_40_cursor.child_mask().iter() {
    v369_40_cursor.descend_to_byte(v369_40_byte);
    {
    let v369_40_tail = v369_40_cursor.fork_read_zipper();
    let v369_40_head = Path::from_slice(&[v369_40_byte]);
    let v370_2: Space = singleton(&(v369_40_head));
    let v370_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v370_2));
    let v370_4: Space = if map_kernels::has_head(&(v370_3)) { singleton(&[]) } else { Space::new() };
    drop(v370_3);
    let v370_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v370_4));
    drop(v370_4);
    let v370_8: Space = if (v370_5).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&(v369_40_head));
      let mut v371_7 = Space::new();
      let mut v371_7_cursor = (v369_40_tail).read_zipper();
      for v371_7_byte in v371_7_cursor.child_mask().iter() {
        v371_7_cursor.descend_to_byte(v371_7_byte);
        {
        let v371_7_tail = v371_7_cursor.fork_read_zipper();
        let v371_7_head = Path::from_slice(&[v371_7_byte]);
        let v372_2: Space = singleton(&(v371_7_head));
        let v372_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v372_2));
        let v372_4: Space = if map_kernels::has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (v372_5).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&(v371_7_head));
          let mut v373_7 = Space::new();
          let mut v373_7_cursor = (v371_7_tail).read_zipper();
          for v373_7_byte in v373_7_cursor.child_mask().iter() {
            v373_7_cursor.descend_to_byte(v373_7_byte);
            {
            let v373_7_tail = v373_7_cursor.fork_read_zipper();
            let v373_7_head = Path::from_slice(&[v373_7_byte]);
            let v374_2: Space = singleton(&(v373_7_head));
            let v374_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v374_2));
            let v374_4: Space = if map_kernels::has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (v374_5).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&(v373_7_head));
              let v375_7: Space = routine_34(c, &(v375_6), &(v373_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if map_kernels::has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (v374_10).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&(v373_7_head));
              let v376_11: Space = routine_35(c, &(v376_6), &(v373_7_tail).make_space(), &(*s1));
              drop(v376_6);
              map_map_kernels::compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = map_map_kernels::unite(&(v374_8),&(v374_12));
            v373_7.join_into((v374_13).clone());
            }
            v373_7_cursor.ascend(1);
          }
          drop(v373_7_cursor);
          map_map_kernels::compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if map_kernels::has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_12: Space = if (v372_10).is_empty() { Space::new() } else {
          let v377_6: Path = concat_path(&(v371_6),&(v371_7_head));
          let mut v377_11 = Space::new();
          let mut v377_11_cursor = (v371_7_tail).read_zipper();
          for v377_11_byte in v377_11_cursor.child_mask().iter() {
            v377_11_cursor.descend_to_byte(v377_11_byte);
            {
            let v377_11_tail = v377_11_cursor.fork_read_zipper();
            let v377_11_head = Path::from_slice(&[v377_11_byte]);
            let v378_2: Space = singleton(&(v377_11_head));
            let v378_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v378_2));
            let v378_4: Space = if map_kernels::has_head(&(v378_3)) { singleton(&[]) } else { Space::new() };
            drop(v378_3);
            let v378_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v378_4));
            drop(v378_4);
            let v378_8: Space = if (v378_5).is_empty() { Space::new() } else {
              let v379_6: Path = concat_path(&(v377_6),&(v377_11_head));
              let v379_7: Space = routine_34(c, &(v379_6), &(v377_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v378_5),&(v379_7))
            };
            drop(v378_5);
            let v378_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v378_2));
            drop(v378_2);
            let v378_10: Space = if map_kernels::has_head(&(v378_9)) { singleton(&[]) } else { Space::new() };
            drop(v378_9);
            let v378_12: Space = if (v378_10).is_empty() { Space::new() } else {
              let v380_6: Path = concat_path(&(v377_6),&(v377_11_head));
              let v380_11: Space = routine_3(c, &(v380_6), &(v377_11_tail).make_space(), &(*s1));
              drop(v380_6);
              map_map_kernels::compose(&(v378_10),&(v380_11))
            };
            drop(v378_10);
            let v378_13: Space = map_map_kernels::unite(&(v378_8),&(v378_12));
            v377_11.join_into((v378_13).clone());
            }
            v377_11_cursor.ascend(1);
          }
          drop(v377_11_cursor);
          drop(v377_6);
          map_map_kernels::compose(&(v372_10),&(v377_11))
        };
        drop(v372_10);
        let v372_13: Space = map_map_kernels::unite(&(v372_8),&(v372_12));
        v371_7.join_into((v372_13).clone());
        }
        v371_7_cursor.ascend(1);
      }
      drop(v371_7_cursor);
      map_map_kernels::compose(&(v370_5),&(v371_7))
    };
    drop(v370_5);
    let v370_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v370_2));
    drop(v370_2);
    let v370_10: Space = if map_kernels::has_head(&(v370_9)) { singleton(&[]) } else { Space::new() };
    drop(v370_9);
    let v370_18: Space = if (v370_10).is_empty() { Space::new() } else {
      let v381_11: Space = map_kernels::unwrap(&(v369_10),&(v369_40_head));
      let v381_12: Space = map_map_kernels::restrict_to(&(v369_9),&(v381_11));
      let mut v381_13 = Space::new();
      let mut v381_13_cursor = (v381_12).read_zipper();
      for v381_13_byte in v381_13_cursor.child_mask().iter() {
        v381_13_cursor.descend_to_byte(v381_13_byte);
        {
        let v381_13_tail = v381_13_cursor.fork_read_zipper();
        let v381_13_head = Path::from_slice(&[v381_13_byte]);
        let v382_2: Space = singleton(&(v381_13_head));
        let v382_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v382_2));
        let v382_4: Space = if map_kernels::has_head(&(v382_3)) { singleton(&[]) } else { Space::new() };
        drop(v382_3);
        let v382_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v382_4));
        drop(v382_4);
        let v382_7: Space = if (v382_5).is_empty() { Space::new() } else {
          let mut v383_6 = Space::new();
          let mut v383_6_cursor = (v381_13_tail).read_zipper();
          for v383_6_byte in v383_6_cursor.child_mask().iter() {
            v383_6_cursor.descend_to_byte(v383_6_byte);
            {
            let v383_6_tail = v383_6_cursor.fork_read_zipper();
            let v383_6_head = Path::from_slice(&[v383_6_byte]);
            let v384_2: Space = singleton(&(v383_6_head));
            let v384_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v384_2));
            let v384_4: Space = if map_kernels::has_head(&(v384_3)) { singleton(&[]) } else { Space::new() };
            drop(v384_3);
            let v384_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v384_4));
            drop(v384_4);
            let v384_8: Space = if (v384_5).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v381_13_head),&(v383_6_head));
              let v385_7: Space = routine_10(c, &(v385_6), &(v383_6_tail).make_space());
              map_map_kernels::compose(&(v384_5),&(v385_7))
            };
            drop(v384_5);
            let v384_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v384_2));
            drop(v384_2);
            let v384_10: Space = if map_kernels::has_head(&(v384_9)) { singleton(&[]) } else { Space::new() };
            drop(v384_9);
            let v384_12: Space = if (v384_10).is_empty() { Space::new() } else {
              let v386_6: Path = concat_path(&(v381_13_head),&(v383_6_head));
              let v386_11: Space = routine_11(c, &(v386_6), &(v383_6_tail).make_space());
              drop(v386_6);
              map_map_kernels::compose(&(v384_10),&(v386_11))
            };
            drop(v384_10);
            let v384_13: Space = map_map_kernels::unite(&(v384_8),&(v384_12));
            v383_6.join_into((v384_13).clone());
            }
            v383_6_cursor.ascend(1);
          }
          drop(v383_6_cursor);
          map_map_kernels::compose(&(v382_5),&(v383_6))
        };
        drop(v382_5);
        let v382_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v382_2));
        drop(v382_2);
        let v382_9: Space = if map_kernels::has_head(&(v382_8)) { singleton(&[]) } else { Space::new() };
        drop(v382_8);
        let v382_11: Space = if (v382_9).is_empty() { Space::new() } else {
          let mut v387_10 = Space::new();
          let mut v387_10_cursor = (v381_13_tail).read_zipper();
          for v387_10_byte in v387_10_cursor.child_mask().iter() {
            v387_10_cursor.descend_to_byte(v387_10_byte);
            {
            let v387_10_tail = v387_10_cursor.fork_read_zipper();
            let v387_10_head = Path::from_slice(&[v387_10_byte]);
            let v388_2: Space = singleton(&(v387_10_head));
            let v388_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v388_2));
            let v388_4: Space = if map_kernels::has_head(&(v388_3)) { singleton(&[]) } else { Space::new() };
            drop(v388_3);
            let v388_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v388_4));
            drop(v388_4);
            let v388_8: Space = if (v388_5).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v381_13_head),&(v387_10_head));
              let v389_7: Space = routine_10(c, &(v389_6), &(v387_10_tail).make_space());
              map_map_kernels::compose(&(v388_5),&(v389_7))
            };
            drop(v388_5);
            let v388_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v388_2));
            drop(v388_2);
            let v388_10: Space = if map_kernels::has_head(&(v388_9)) { singleton(&[]) } else { Space::new() };
            drop(v388_9);
            let v388_12: Space = if (v388_10).is_empty() { Space::new() } else {
              let v390_6: Path = concat_path(&(v381_13_head),&(v387_10_head));
              let v390_11: Space = routine_12(c, &(v390_6), &(v387_10_tail).make_space());
              drop(v390_6);
              map_map_kernels::compose(&(v388_10),&(v390_11))
            };
            drop(v388_10);
            let v388_13: Space = map_map_kernels::unite(&(v388_8),&(v388_12));
            v387_10.join_into((v388_13).clone());
            }
            v387_10_cursor.ascend(1);
          }
          drop(v387_10_cursor);
          map_map_kernels::compose(&(v382_9),&(v387_10))
        };
        drop(v382_9);
        let v382_12: Space = map_map_kernels::unite(&(v382_7),&(v382_11));
        v381_13.join_into((v382_12).clone());
        }
        v381_13_cursor.ascend(1);
      }
      drop(v381_13_cursor);
      drop(v381_12);
      let v381_14: Space = map_map_kernels::restrict_to(&(v369_7),&(v381_13));
      let mut v381_15 = Space::new();
      let mut v381_15_cursor = (v381_14).read_zipper();
      for v381_15_byte in v381_15_cursor.child_mask().iter() {
        v381_15_cursor.descend_to_byte(v381_15_byte);
        {
        let v381_15_tail = v381_15_cursor.fork_read_zipper();
        let v381_15_head = Path::from_slice(&[v381_15_byte]);
        let v391_2: Space = singleton(&(v381_15_head));
        let v391_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v391_2));
        let v391_4: Space = if map_kernels::has_head(&(v391_3)) { singleton(&[]) } else { Space::new() };
        drop(v391_3);
        let v391_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v391_4));
        drop(v391_4);
        let v391_7: Space = if (v391_5).is_empty() { Space::new() } else {
          let mut v392_6 = Space::new();
          let mut v392_6_cursor = (v381_15_tail).read_zipper();
          for v392_6_byte in v392_6_cursor.child_mask().iter() {
            v392_6_cursor.descend_to_byte(v392_6_byte);
            {
            let v392_6_tail = v392_6_cursor.fork_read_zipper();
            let v392_6_head = Path::from_slice(&[v392_6_byte]);
            let v393_2: Space = singleton(&(v392_6_head));
            let v393_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v393_2));
            let v393_4: Space = if map_kernels::has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
            drop(v393_3);
            let v393_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v393_4));
            drop(v393_4);
            let v393_8: Space = if (v393_5).is_empty() { Space::new() } else {
              let v394_6: Path = concat_path(&(v381_15_head),&(v392_6_head));
              let v394_7: Space = routine_13(c, &(v394_6), &(v392_6_tail).make_space());
              map_map_kernels::compose(&(v393_5),&(v394_7))
            };
            drop(v393_5);
            let v393_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v393_2));
            drop(v393_2);
            let v393_10: Space = if map_kernels::has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
            drop(v393_9);
            let v393_12: Space = if (v393_10).is_empty() { Space::new() } else {
              let v395_6: Path = concat_path(&(v381_15_head),&(v392_6_head));
              let v395_11: Space = routine_14(c, &(v395_6), &(v392_6_tail).make_space());
              drop(v395_6);
              map_map_kernels::compose(&(v393_10),&(v395_11))
            };
            drop(v393_10);
            let v393_13: Space = map_map_kernels::unite(&(v393_8),&(v393_12));
            v392_6.join_into((v393_13).clone());
            }
            v392_6_cursor.ascend(1);
          }
          drop(v392_6_cursor);
          map_map_kernels::compose(&(v391_5),&(v392_6))
        };
        drop(v391_5);
        let v391_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v391_2));
        drop(v391_2);
        let v391_9: Space = if map_kernels::has_head(&(v391_8)) { singleton(&[]) } else { Space::new() };
        drop(v391_8);
        let v391_11: Space = if (v391_9).is_empty() { Space::new() } else {
          let mut v396_10 = Space::new();
          let mut v396_10_cursor = (v381_15_tail).read_zipper();
          for v396_10_byte in v396_10_cursor.child_mask().iter() {
            v396_10_cursor.descend_to_byte(v396_10_byte);
            {
            let v396_10_tail = v396_10_cursor.fork_read_zipper();
            let v396_10_head = Path::from_slice(&[v396_10_byte]);
            let v397_2: Space = singleton(&(v396_10_head));
            let v397_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v397_2));
            let v397_4: Space = if map_kernels::has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
            drop(v397_3);
            let v397_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v397_4));
            drop(v397_4);
            let v397_8: Space = if (v397_5).is_empty() { Space::new() } else {
              let v398_6: Path = concat_path(&(v381_15_head),&(v396_10_head));
              let v398_7: Space = routine_13(c, &(v398_6), &(v396_10_tail).make_space());
              map_map_kernels::compose(&(v397_5),&(v398_7))
            };
            drop(v397_5);
            let v397_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v397_2));
            drop(v397_2);
            let v397_10: Space = if map_kernels::has_head(&(v397_9)) { singleton(&[]) } else { Space::new() };
            drop(v397_9);
            let v397_12: Space = if (v397_10).is_empty() { Space::new() } else {
              let v399_6: Path = concat_path(&(v381_15_head),&(v396_10_head));
              let v399_11: Space = routine_15(c, &(v399_6), &(v396_10_tail).make_space());
              drop(v399_6);
              map_map_kernels::compose(&(v397_10),&(v399_11))
            };
            drop(v397_10);
            let v397_13: Space = map_map_kernels::unite(&(v397_8),&(v397_12));
            v396_10.join_into((v397_13).clone());
            }
            v396_10_cursor.ascend(1);
          }
          drop(v396_10_cursor);
          map_map_kernels::compose(&(v391_9),&(v396_10))
        };
        drop(v391_9);
        let v391_12: Space = map_map_kernels::unite(&(v391_7),&(v391_11));
        v381_15.join_into((v391_12).clone());
        }
        v381_15_cursor.ascend(1);
      }
      drop(v381_15_cursor);
      let v381_16: Space = map_map_kernels::subtract(&(v381_15),&(v381_11));
      drop(v381_11);
      let v381_17: Space = map_map_kernels::intersect(&(v381_16),&(v369_12));
      map_map_kernels::compose(&(v370_10),&(v381_17))
    };
    drop(v370_10);
    let v400_6: Path = concat_path(&(*p0),&(v369_40_head));
    let v370_19: Space = map_kernels::wrap(&(v370_18),&(v400_6));
    let v370_20: Space = map_map_kernels::unite(&(v370_8),&(v370_19));
    v369_40.join_into((v370_20).clone());
    }
    v369_40_cursor.ascend(1);
  }
  drop(v369_40_cursor);
  drop(v369_7);
  drop(v369_9);
  drop(v369_10);
  drop(v369_12);
  (v369_40).clone()
}

fn routine_22(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v401_20 = Space::new();
  let mut v401_20_cursor = (*s0).read_zipper();
  for v401_20_byte in v401_20_cursor.child_mask().iter() {
    v401_20_cursor.descend_to_byte(v401_20_byte);
    {
    let v401_20_tail = v401_20_cursor.fork_read_zipper();
    let v401_20_head = Path::from_slice(&[v401_20_byte]);
    let v402_2: Space = singleton(&(v401_20_head));
    let v402_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v402_2));
    let v402_4: Space = if map_kernels::has_head(&(v402_3)) { singleton(&[]) } else { Space::new() };
    drop(v402_3);
    let v402_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v402_4));
    drop(v402_4);
    let v402_8: Space = if (v402_5).is_empty() { Space::new() } else {
      let v403_6: Path = concat_path(&(*p0),&(v401_20_head));
      let mut v403_7 = Space::new();
      let mut v403_7_cursor = (v401_20_tail).read_zipper();
      for v403_7_byte in v403_7_cursor.child_mask().iter() {
        v403_7_cursor.descend_to_byte(v403_7_byte);
        {
        let v403_7_tail = v403_7_cursor.fork_read_zipper();
        let v403_7_head = Path::from_slice(&[v403_7_byte]);
        let v404_2: Space = singleton(&(v403_7_head));
        let v404_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v404_2));
        let v404_4: Space = if map_kernels::has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
        drop(v404_3);
        let v404_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v404_4));
        drop(v404_4);
        let v404_8: Space = if (v404_5).is_empty() { Space::new() } else {
          let v405_6: Path = concat_path(&(v403_6),&(v403_7_head));
          let mut v405_7 = Space::new();
          let mut v405_7_cursor = (v403_7_tail).read_zipper();
          for v405_7_byte in v405_7_cursor.child_mask().iter() {
            v405_7_cursor.descend_to_byte(v405_7_byte);
            {
            let v405_7_tail = v405_7_cursor.fork_read_zipper();
            let v405_7_head = Path::from_slice(&[v405_7_byte]);
            let v406_2: Space = singleton(&(v405_7_head));
            let v406_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v406_2));
            let v406_4: Space = if map_kernels::has_head(&(v406_3)) { singleton(&[]) } else { Space::new() };
            drop(v406_3);
            let v406_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v406_4));
            drop(v406_4);
            let v406_8: Space = if (v406_5).is_empty() { Space::new() } else {
              let v407_6: Path = concat_path(&(v405_6),&(v405_7_head));
              let v407_7: Space = routine_36(c, &(v407_6), &(v405_7_tail).make_space());
              map_map_kernels::compose(&(v406_5),&(v407_7))
            };
            drop(v406_5);
            let v406_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v406_2));
            drop(v406_2);
            let v406_10: Space = if map_kernels::has_head(&(v406_9)) { singleton(&[]) } else { Space::new() };
            drop(v406_9);
            let v406_12: Space = if (v406_10).is_empty() { Space::new() } else {
              let v408_6: Path = concat_path(&(v405_6),&(v405_7_head));
              let v408_11: Space = routine_37(c, &(v408_6), &(v405_7_tail).make_space());
              drop(v408_6);
              map_map_kernels::compose(&(v406_10),&(v408_11))
            };
            drop(v406_10);
            let v406_13: Space = map_map_kernels::unite(&(v406_8),&(v406_12));
            v405_7.join_into((v406_13).clone());
            }
            v405_7_cursor.ascend(1);
          }
          drop(v405_7_cursor);
          map_map_kernels::compose(&(v404_5),&(v405_7))
        };
        drop(v404_5);
        let v404_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v404_2));
        drop(v404_2);
        let v404_10: Space = if map_kernels::has_head(&(v404_9)) { singleton(&[]) } else { Space::new() };
        drop(v404_9);
        let v404_12: Space = if (v404_10).is_empty() { Space::new() } else {
          let v409_6: Path = concat_path(&(v403_6),&(v403_7_head));
          let mut v409_11 = Space::new();
          let mut v409_11_cursor = (v403_7_tail).read_zipper();
          for v409_11_byte in v409_11_cursor.child_mask().iter() {
            v409_11_cursor.descend_to_byte(v409_11_byte);
            {
            let v409_11_tail = v409_11_cursor.fork_read_zipper();
            let v409_11_head = Path::from_slice(&[v409_11_byte]);
            let v410_2: Space = singleton(&(v409_11_head));
            let v410_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v410_2));
            let v410_4: Space = if map_kernels::has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
            drop(v410_3);
            let v410_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v410_4));
            drop(v410_4);
            let v410_8: Space = if (v410_5).is_empty() { Space::new() } else {
              let v411_6: Path = concat_path(&(v409_6),&(v409_11_head));
              let v411_7: Space = routine_36(c, &(v411_6), &(v409_11_tail).make_space());
              map_map_kernels::compose(&(v410_5),&(v411_7))
            };
            drop(v410_5);
            let v410_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v410_2));
            drop(v410_2);
            let v410_10: Space = if map_kernels::has_head(&(v410_9)) { singleton(&[]) } else { Space::new() };
            drop(v410_9);
            let v410_12: Space = if (v410_10).is_empty() { Space::new() } else {
              let v412_6: Path = concat_path(&(v409_6),&(v409_11_head));
              let v412_11: Space = routine_12(c, &(v412_6), &(v409_11_tail).make_space());
              drop(v412_6);
              map_map_kernels::compose(&(v410_10),&(v412_11))
            };
            drop(v410_10);
            let v410_13: Space = map_map_kernels::unite(&(v410_8),&(v410_12));
            v409_11.join_into((v410_13).clone());
            }
            v409_11_cursor.ascend(1);
          }
          drop(v409_11_cursor);
          drop(v409_6);
          map_map_kernels::compose(&(v404_10),&(v409_11))
        };
        drop(v404_10);
        let v404_13: Space = map_map_kernels::unite(&(v404_8),&(v404_12));
        v403_7.join_into((v404_13).clone());
        }
        v403_7_cursor.ascend(1);
      }
      drop(v403_7_cursor);
      map_map_kernels::compose(&(v402_5),&(v403_7))
    };
    drop(v402_5);
    let v402_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v402_2));
    drop(v402_2);
    let v402_10: Space = if map_kernels::has_head(&(v402_9)) { singleton(&[]) } else { Space::new() };
    drop(v402_9);
    let v402_12: Space = if (v402_10).is_empty() { Space::new() } else {
      let v413_6: Path = concat_path(&(*p0),&(v401_20_head));
      let mut v413_11 = Space::new();
      let mut v413_11_cursor = (v401_20_tail).read_zipper();
      for v413_11_byte in v413_11_cursor.child_mask().iter() {
        v413_11_cursor.descend_to_byte(v413_11_byte);
        {
        let v413_11_tail = v413_11_cursor.fork_read_zipper();
        let v413_11_head = Path::from_slice(&[v413_11_byte]);
        let v414_2: Space = singleton(&(v413_11_head));
        let v414_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v414_2));
        let v414_4: Space = if map_kernels::has_head(&(v414_3)) { singleton(&[]) } else { Space::new() };
        drop(v414_3);
        let v414_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v414_4));
        drop(v414_4);
        let v414_8: Space = if (v414_5).is_empty() { Space::new() } else {
          let v415_6: Path = concat_path(&(v413_6),&(v413_11_head));
          let mut v415_7 = Space::new();
          let mut v415_7_cursor = (v413_11_tail).read_zipper();
          for v415_7_byte in v415_7_cursor.child_mask().iter() {
            v415_7_cursor.descend_to_byte(v415_7_byte);
            {
            let v415_7_tail = v415_7_cursor.fork_read_zipper();
            let v415_7_head = Path::from_slice(&[v415_7_byte]);
            let v416_2: Space = singleton(&(v415_7_head));
            let v416_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v416_2));
            let v416_4: Space = if map_kernels::has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
            drop(v416_3);
            let v416_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v416_4));
            drop(v416_4);
            let v416_8: Space = if (v416_5).is_empty() { Space::new() } else {
              let v417_6: Path = concat_path(&(v415_6),&(v415_7_head));
              let v417_7: Space = routine_36(c, &(v417_6), &(v415_7_tail).make_space());
              map_map_kernels::compose(&(v416_5),&(v417_7))
            };
            drop(v416_5);
            let v416_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v416_2));
            drop(v416_2);
            let v416_10: Space = if map_kernels::has_head(&(v416_9)) { singleton(&[]) } else { Space::new() };
            drop(v416_9);
            let v416_12: Space = if (v416_10).is_empty() { Space::new() } else {
              let v418_6: Path = concat_path(&(v415_6),&(v415_7_head));
              let v418_11: Space = routine_37(c, &(v418_6), &(v415_7_tail).make_space());
              drop(v418_6);
              map_map_kernels::compose(&(v416_10),&(v418_11))
            };
            drop(v416_10);
            let v416_13: Space = map_map_kernels::unite(&(v416_8),&(v416_12));
            v415_7.join_into((v416_13).clone());
            }
            v415_7_cursor.ascend(1);
          }
          drop(v415_7_cursor);
          drop(v415_6);
          map_map_kernels::compose(&(v414_5),&(v415_7))
        };
        drop(v414_5);
        let v414_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v414_2));
        drop(v414_2);
        let v414_10: Space = if map_kernels::has_head(&(v414_9)) { singleton(&[]) } else { Space::new() };
        drop(v414_9);
        let v414_11: Space = map_view_kernels::compose(&(v414_10),&(v413_11_tail));
        drop(v414_10);
        let v414_12: Space = map_map_kernels::unite(&(v414_8),&(v414_11));
        drop(v414_11);
        v413_11.join_into((v414_12).clone());
        }
        v413_11_cursor.ascend(1);
      }
      drop(v413_11_cursor);
      drop(v413_6);
      map_map_kernels::compose(&(v402_10),&(v413_11))
    };
    drop(v402_10);
    let v402_13: Space = map_map_kernels::unite(&(v402_8),&(v402_12));
    v401_20.join_into((v402_13).clone());
    }
    v401_20_cursor.ascend(1);
  }
  drop(v401_20_cursor);
  (v401_20).clone()
}

fn routine_23(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v419_14 = Space::new();
  let mut v419_14_cursor = (*s0).read_zipper();
  for v419_14_byte in v419_14_cursor.child_mask().iter() {
    v419_14_cursor.descend_to_byte(v419_14_byte);
    {
    let v419_14_tail = v419_14_cursor.fork_read_zipper();
    let v419_14_head = Path::from_slice(&[v419_14_byte]);
    let v420_2: Space = singleton(&(v419_14_head));
    let v420_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v420_2));
    let v420_4: Space = if map_kernels::has_head(&(v420_3)) { singleton(&[]) } else { Space::new() };
    drop(v420_3);
    let v420_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v420_4));
    drop(v420_4);
    let v420_8: Space = if (v420_5).is_empty() { Space::new() } else {
      let v421_6: Path = concat_path(&(*p0),&(v419_14_head));
      let mut v421_7 = Space::new();
      let mut v421_7_cursor = (v419_14_tail).read_zipper();
      for v421_7_byte in v421_7_cursor.child_mask().iter() {
        v421_7_cursor.descend_to_byte(v421_7_byte);
        {
        let v421_7_tail = v421_7_cursor.fork_read_zipper();
        let v421_7_head = Path::from_slice(&[v421_7_byte]);
        let v422_2: Space = singleton(&(v421_7_head));
        let v422_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v422_2));
        let v422_4: Space = if map_kernels::has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
        drop(v422_3);
        let v422_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v422_4));
        drop(v422_4);
        let v422_8: Space = if (v422_5).is_empty() { Space::new() } else {
          let v423_6: Path = concat_path(&(v421_6),&(v421_7_head));
          let mut v423_7 = Space::new();
          let mut v423_7_cursor = (v421_7_tail).read_zipper();
          for v423_7_byte in v423_7_cursor.child_mask().iter() {
            v423_7_cursor.descend_to_byte(v423_7_byte);
            {
            let v423_7_tail = v423_7_cursor.fork_read_zipper();
            let v423_7_head = Path::from_slice(&[v423_7_byte]);
            let v424_2: Space = singleton(&(v423_7_head));
            let v424_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v424_2));
            let v424_4: Space = if map_kernels::has_head(&(v424_3)) { singleton(&[]) } else { Space::new() };
            drop(v424_3);
            let v424_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v424_4));
            drop(v424_4);
            let v424_8: Space = if (v424_5).is_empty() { Space::new() } else {
              let v425_6: Path = concat_path(&(v423_6),&(v423_7_head));
              let v425_7: Space = routine_36(c, &(v425_6), &(v423_7_tail).make_space());
              map_map_kernels::compose(&(v424_5),&(v425_7))
            };
            drop(v424_5);
            let v424_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v424_2));
            drop(v424_2);
            let v424_10: Space = if map_kernels::has_head(&(v424_9)) { singleton(&[]) } else { Space::new() };
            drop(v424_9);
            let v424_12: Space = if (v424_10).is_empty() { Space::new() } else {
              let v426_6: Path = concat_path(&(v423_6),&(v423_7_head));
              let v426_11: Space = routine_37(c, &(v426_6), &(v423_7_tail).make_space());
              drop(v426_6);
              map_map_kernels::compose(&(v424_10),&(v426_11))
            };
            drop(v424_10);
            let v424_13: Space = map_map_kernels::unite(&(v424_8),&(v424_12));
            v423_7.join_into((v424_13).clone());
            }
            v423_7_cursor.ascend(1);
          }
          drop(v423_7_cursor);
          map_map_kernels::compose(&(v422_5),&(v423_7))
        };
        drop(v422_5);
        let v422_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v422_2));
        drop(v422_2);
        let v422_10: Space = if map_kernels::has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
        drop(v422_9);
        let v422_12: Space = if (v422_10).is_empty() { Space::new() } else {
          let v427_6: Path = concat_path(&(v421_6),&(v421_7_head));
          let mut v427_11 = Space::new();
          let mut v427_11_cursor = (v421_7_tail).read_zipper();
          for v427_11_byte in v427_11_cursor.child_mask().iter() {
            v427_11_cursor.descend_to_byte(v427_11_byte);
            {
            let v427_11_tail = v427_11_cursor.fork_read_zipper();
            let v427_11_head = Path::from_slice(&[v427_11_byte]);
            let v428_2: Space = singleton(&(v427_11_head));
            let v428_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v428_2));
            let v428_4: Space = if map_kernels::has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
            drop(v428_3);
            let v428_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v428_4));
            drop(v428_4);
            let v428_8: Space = if (v428_5).is_empty() { Space::new() } else {
              let v429_6: Path = concat_path(&(v427_6),&(v427_11_head));
              let v429_7: Space = routine_36(c, &(v429_6), &(v427_11_tail).make_space());
              map_map_kernels::compose(&(v428_5),&(v429_7))
            };
            drop(v428_5);
            let v428_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v428_2));
            drop(v428_2);
            let v428_10: Space = if map_kernels::has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
            drop(v428_9);
            let v428_12: Space = if (v428_10).is_empty() { Space::new() } else {
              let v430_6: Path = concat_path(&(v427_6),&(v427_11_head));
              let v430_11: Space = routine_12(c, &(v430_6), &(v427_11_tail).make_space());
              drop(v430_6);
              map_map_kernels::compose(&(v428_10),&(v430_11))
            };
            drop(v428_10);
            let v428_13: Space = map_map_kernels::unite(&(v428_8),&(v428_12));
            v427_11.join_into((v428_13).clone());
            }
            v427_11_cursor.ascend(1);
          }
          drop(v427_11_cursor);
          drop(v427_6);
          map_map_kernels::compose(&(v422_10),&(v427_11))
        };
        drop(v422_10);
        let v422_13: Space = map_map_kernels::unite(&(v422_8),&(v422_12));
        v421_7.join_into((v422_13).clone());
        }
        v421_7_cursor.ascend(1);
      }
      drop(v421_7_cursor);
      drop(v421_6);
      map_map_kernels::compose(&(v420_5),&(v421_7))
    };
    drop(v420_5);
    let v420_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v420_2));
    drop(v420_2);
    let v420_10: Space = if map_kernels::has_head(&(v420_9)) { singleton(&[]) } else { Space::new() };
    drop(v420_9);
    let v420_11: Space = map_view_kernels::compose(&(v420_10),&(v419_14_tail));
    drop(v420_10);
    let v420_12: Space = map_map_kernels::unite(&(v420_8),&(v420_11));
    drop(v420_11);
    v419_14.join_into((v420_12).clone());
    }
    v419_14_cursor.ascend(1);
  }
  drop(v419_14_cursor);
  (v419_14).clone()
}

fn routine_24(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v431_20 = Space::new();
  let mut v431_20_cursor = (*s0).read_zipper();
  for v431_20_byte in v431_20_cursor.child_mask().iter() {
    v431_20_cursor.descend_to_byte(v431_20_byte);
    {
    let v431_20_tail = v431_20_cursor.fork_read_zipper();
    let v431_20_head = Path::from_slice(&[v431_20_byte]);
    let v432_2: Space = singleton(&(v431_20_head));
    let v432_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v432_2));
    let v432_4: Space = if map_kernels::has_head(&(v432_3)) { singleton(&[]) } else { Space::new() };
    drop(v432_3);
    let v432_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v432_4));
    drop(v432_4);
    let v432_8: Space = if (v432_5).is_empty() { Space::new() } else {
      let v433_6: Path = concat_path(&(*p0),&(v431_20_head));
      let mut v433_7 = Space::new();
      let mut v433_7_cursor = (v431_20_tail).read_zipper();
      for v433_7_byte in v433_7_cursor.child_mask().iter() {
        v433_7_cursor.descend_to_byte(v433_7_byte);
        {
        let v433_7_tail = v433_7_cursor.fork_read_zipper();
        let v433_7_head = Path::from_slice(&[v433_7_byte]);
        let v434_2: Space = singleton(&(v433_7_head));
        let v434_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v434_2));
        let v434_4: Space = if map_kernels::has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
        drop(v434_3);
        let v434_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v434_4));
        drop(v434_4);
        let v434_8: Space = if (v434_5).is_empty() { Space::new() } else {
          let v435_6: Path = concat_path(&(v433_6),&(v433_7_head));
          let mut v435_7 = Space::new();
          let mut v435_7_cursor = (v433_7_tail).read_zipper();
          for v435_7_byte in v435_7_cursor.child_mask().iter() {
            v435_7_cursor.descend_to_byte(v435_7_byte);
            {
            let v435_7_tail = v435_7_cursor.fork_read_zipper();
            let v435_7_head = Path::from_slice(&[v435_7_byte]);
            let v436_2: Space = singleton(&(v435_7_head));
            let v436_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v436_2));
            let v436_4: Space = if map_kernels::has_head(&(v436_3)) { singleton(&[]) } else { Space::new() };
            drop(v436_3);
            let v436_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v436_4));
            drop(v436_4);
            let v436_8: Space = if (v436_5).is_empty() { Space::new() } else {
              let v437_6: Path = concat_path(&(v435_6),&(v435_7_head));
              let v437_7: Space = routine_38(c, &(v437_6), &(v435_7_tail).make_space());
              map_map_kernels::compose(&(v436_5),&(v437_7))
            };
            drop(v436_5);
            let v436_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v436_2));
            drop(v436_2);
            let v436_10: Space = if map_kernels::has_head(&(v436_9)) { singleton(&[]) } else { Space::new() };
            drop(v436_9);
            let v436_12: Space = if (v436_10).is_empty() { Space::new() } else {
              let v438_6: Path = concat_path(&(v435_6),&(v435_7_head));
              let v438_11: Space = routine_39(c, &(v438_6), &(v435_7_tail).make_space());
              drop(v438_6);
              map_map_kernels::compose(&(v436_10),&(v438_11))
            };
            drop(v436_10);
            let v436_13: Space = map_map_kernels::unite(&(v436_8),&(v436_12));
            v435_7.join_into((v436_13).clone());
            }
            v435_7_cursor.ascend(1);
          }
          drop(v435_7_cursor);
          map_map_kernels::compose(&(v434_5),&(v435_7))
        };
        drop(v434_5);
        let v434_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v434_2));
        drop(v434_2);
        let v434_10: Space = if map_kernels::has_head(&(v434_9)) { singleton(&[]) } else { Space::new() };
        drop(v434_9);
        let v434_12: Space = if (v434_10).is_empty() { Space::new() } else {
          let v439_6: Path = concat_path(&(v433_6),&(v433_7_head));
          let mut v439_11 = Space::new();
          let mut v439_11_cursor = (v433_7_tail).read_zipper();
          for v439_11_byte in v439_11_cursor.child_mask().iter() {
            v439_11_cursor.descend_to_byte(v439_11_byte);
            {
            let v439_11_tail = v439_11_cursor.fork_read_zipper();
            let v439_11_head = Path::from_slice(&[v439_11_byte]);
            let v440_2: Space = singleton(&(v439_11_head));
            let v440_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v440_2));
            let v440_4: Space = if map_kernels::has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
            drop(v440_3);
            let v440_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v440_4));
            drop(v440_4);
            let v440_8: Space = if (v440_5).is_empty() { Space::new() } else {
              let v441_6: Path = concat_path(&(v439_6),&(v439_11_head));
              let v441_7: Space = routine_38(c, &(v441_6), &(v439_11_tail).make_space());
              map_map_kernels::compose(&(v440_5),&(v441_7))
            };
            drop(v440_5);
            let v440_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v440_2));
            drop(v440_2);
            let v440_10: Space = if map_kernels::has_head(&(v440_9)) { singleton(&[]) } else { Space::new() };
            drop(v440_9);
            let v440_12: Space = if (v440_10).is_empty() { Space::new() } else {
              let v442_6: Path = concat_path(&(v439_6),&(v439_11_head));
              let v442_11: Space = routine_15(c, &(v442_6), &(v439_11_tail).make_space());
              drop(v442_6);
              map_map_kernels::compose(&(v440_10),&(v442_11))
            };
            drop(v440_10);
            let v440_13: Space = map_map_kernels::unite(&(v440_8),&(v440_12));
            v439_11.join_into((v440_13).clone());
            }
            v439_11_cursor.ascend(1);
          }
          drop(v439_11_cursor);
          drop(v439_6);
          map_map_kernels::compose(&(v434_10),&(v439_11))
        };
        drop(v434_10);
        let v434_13: Space = map_map_kernels::unite(&(v434_8),&(v434_12));
        v433_7.join_into((v434_13).clone());
        }
        v433_7_cursor.ascend(1);
      }
      drop(v433_7_cursor);
      map_map_kernels::compose(&(v432_5),&(v433_7))
    };
    drop(v432_5);
    let v432_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v432_2));
    drop(v432_2);
    let v432_10: Space = if map_kernels::has_head(&(v432_9)) { singleton(&[]) } else { Space::new() };
    drop(v432_9);
    let v432_12: Space = if (v432_10).is_empty() { Space::new() } else {
      let v443_6: Path = concat_path(&(*p0),&(v431_20_head));
      let mut v443_11 = Space::new();
      let mut v443_11_cursor = (v431_20_tail).read_zipper();
      for v443_11_byte in v443_11_cursor.child_mask().iter() {
        v443_11_cursor.descend_to_byte(v443_11_byte);
        {
        let v443_11_tail = v443_11_cursor.fork_read_zipper();
        let v443_11_head = Path::from_slice(&[v443_11_byte]);
        let v444_2: Space = singleton(&(v443_11_head));
        let v444_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v444_2));
        let v444_4: Space = if map_kernels::has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
        drop(v444_3);
        let v444_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v444_4));
        drop(v444_4);
        let v444_8: Space = if (v444_5).is_empty() { Space::new() } else {
          let v445_6: Path = concat_path(&(v443_6),&(v443_11_head));
          let mut v445_7 = Space::new();
          let mut v445_7_cursor = (v443_11_tail).read_zipper();
          for v445_7_byte in v445_7_cursor.child_mask().iter() {
            v445_7_cursor.descend_to_byte(v445_7_byte);
            {
            let v445_7_tail = v445_7_cursor.fork_read_zipper();
            let v445_7_head = Path::from_slice(&[v445_7_byte]);
            let v446_2: Space = singleton(&(v445_7_head));
            let v446_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v446_2));
            let v446_4: Space = if map_kernels::has_head(&(v446_3)) { singleton(&[]) } else { Space::new() };
            drop(v446_3);
            let v446_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v446_4));
            drop(v446_4);
            let v446_8: Space = if (v446_5).is_empty() { Space::new() } else {
              let v447_6: Path = concat_path(&(v445_6),&(v445_7_head));
              let v447_7: Space = routine_38(c, &(v447_6), &(v445_7_tail).make_space());
              map_map_kernels::compose(&(v446_5),&(v447_7))
            };
            drop(v446_5);
            let v446_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v446_2));
            drop(v446_2);
            let v446_10: Space = if map_kernels::has_head(&(v446_9)) { singleton(&[]) } else { Space::new() };
            drop(v446_9);
            let v446_12: Space = if (v446_10).is_empty() { Space::new() } else {
              let v448_6: Path = concat_path(&(v445_6),&(v445_7_head));
              let v448_11: Space = routine_39(c, &(v448_6), &(v445_7_tail).make_space());
              drop(v448_6);
              map_map_kernels::compose(&(v446_10),&(v448_11))
            };
            drop(v446_10);
            let v446_13: Space = map_map_kernels::unite(&(v446_8),&(v446_12));
            v445_7.join_into((v446_13).clone());
            }
            v445_7_cursor.ascend(1);
          }
          drop(v445_7_cursor);
          drop(v445_6);
          map_map_kernels::compose(&(v444_5),&(v445_7))
        };
        drop(v444_5);
        let v444_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v444_2));
        drop(v444_2);
        let v444_10: Space = if map_kernels::has_head(&(v444_9)) { singleton(&[]) } else { Space::new() };
        drop(v444_9);
        let v444_11: Space = map_view_kernels::compose(&(v444_10),&(v443_11_tail));
        drop(v444_10);
        let v444_12: Space = map_map_kernels::unite(&(v444_8),&(v444_11));
        drop(v444_11);
        v443_11.join_into((v444_12).clone());
        }
        v443_11_cursor.ascend(1);
      }
      drop(v443_11_cursor);
      drop(v443_6);
      map_map_kernels::compose(&(v432_10),&(v443_11))
    };
    drop(v432_10);
    let v432_13: Space = map_map_kernels::unite(&(v432_8),&(v432_12));
    v431_20.join_into((v432_13).clone());
    }
    v431_20_cursor.ascend(1);
  }
  drop(v431_20_cursor);
  (v431_20).clone()
}

fn routine_25(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v449_14 = Space::new();
  let mut v449_14_cursor = (*s0).read_zipper();
  for v449_14_byte in v449_14_cursor.child_mask().iter() {
    v449_14_cursor.descend_to_byte(v449_14_byte);
    {
    let v449_14_tail = v449_14_cursor.fork_read_zipper();
    let v449_14_head = Path::from_slice(&[v449_14_byte]);
    let v450_2: Space = singleton(&(v449_14_head));
    let v450_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v450_2));
    let v450_4: Space = if map_kernels::has_head(&(v450_3)) { singleton(&[]) } else { Space::new() };
    drop(v450_3);
    let v450_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v450_4));
    drop(v450_4);
    let v450_8: Space = if (v450_5).is_empty() { Space::new() } else {
      let v451_6: Path = concat_path(&(*p0),&(v449_14_head));
      let mut v451_7 = Space::new();
      let mut v451_7_cursor = (v449_14_tail).read_zipper();
      for v451_7_byte in v451_7_cursor.child_mask().iter() {
        v451_7_cursor.descend_to_byte(v451_7_byte);
        {
        let v451_7_tail = v451_7_cursor.fork_read_zipper();
        let v451_7_head = Path::from_slice(&[v451_7_byte]);
        let v452_2: Space = singleton(&(v451_7_head));
        let v452_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v452_2));
        let v452_4: Space = if map_kernels::has_head(&(v452_3)) { singleton(&[]) } else { Space::new() };
        drop(v452_3);
        let v452_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v452_4));
        drop(v452_4);
        let v452_8: Space = if (v452_5).is_empty() { Space::new() } else {
          let v453_6: Path = concat_path(&(v451_6),&(v451_7_head));
          let mut v453_7 = Space::new();
          let mut v453_7_cursor = (v451_7_tail).read_zipper();
          for v453_7_byte in v453_7_cursor.child_mask().iter() {
            v453_7_cursor.descend_to_byte(v453_7_byte);
            {
            let v453_7_tail = v453_7_cursor.fork_read_zipper();
            let v453_7_head = Path::from_slice(&[v453_7_byte]);
            let v454_2: Space = singleton(&(v453_7_head));
            let v454_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v454_2));
            let v454_4: Space = if map_kernels::has_head(&(v454_3)) { singleton(&[]) } else { Space::new() };
            drop(v454_3);
            let v454_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v454_4));
            drop(v454_4);
            let v454_8: Space = if (v454_5).is_empty() { Space::new() } else {
              let v455_6: Path = concat_path(&(v453_6),&(v453_7_head));
              let v455_7: Space = routine_38(c, &(v455_6), &(v453_7_tail).make_space());
              map_map_kernels::compose(&(v454_5),&(v455_7))
            };
            drop(v454_5);
            let v454_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v454_2));
            drop(v454_2);
            let v454_10: Space = if map_kernels::has_head(&(v454_9)) { singleton(&[]) } else { Space::new() };
            drop(v454_9);
            let v454_12: Space = if (v454_10).is_empty() { Space::new() } else {
              let v456_6: Path = concat_path(&(v453_6),&(v453_7_head));
              let v456_11: Space = routine_39(c, &(v456_6), &(v453_7_tail).make_space());
              drop(v456_6);
              map_map_kernels::compose(&(v454_10),&(v456_11))
            };
            drop(v454_10);
            let v454_13: Space = map_map_kernels::unite(&(v454_8),&(v454_12));
            v453_7.join_into((v454_13).clone());
            }
            v453_7_cursor.ascend(1);
          }
          drop(v453_7_cursor);
          map_map_kernels::compose(&(v452_5),&(v453_7))
        };
        drop(v452_5);
        let v452_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v452_2));
        drop(v452_2);
        let v452_10: Space = if map_kernels::has_head(&(v452_9)) { singleton(&[]) } else { Space::new() };
        drop(v452_9);
        let v452_12: Space = if (v452_10).is_empty() { Space::new() } else {
          let v457_6: Path = concat_path(&(v451_6),&(v451_7_head));
          let mut v457_11 = Space::new();
          let mut v457_11_cursor = (v451_7_tail).read_zipper();
          for v457_11_byte in v457_11_cursor.child_mask().iter() {
            v457_11_cursor.descend_to_byte(v457_11_byte);
            {
            let v457_11_tail = v457_11_cursor.fork_read_zipper();
            let v457_11_head = Path::from_slice(&[v457_11_byte]);
            let v458_2: Space = singleton(&(v457_11_head));
            let v458_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v458_2));
            let v458_4: Space = if map_kernels::has_head(&(v458_3)) { singleton(&[]) } else { Space::new() };
            drop(v458_3);
            let v458_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v458_4));
            drop(v458_4);
            let v458_8: Space = if (v458_5).is_empty() { Space::new() } else {
              let v459_6: Path = concat_path(&(v457_6),&(v457_11_head));
              let v459_7: Space = routine_38(c, &(v459_6), &(v457_11_tail).make_space());
              map_map_kernels::compose(&(v458_5),&(v459_7))
            };
            drop(v458_5);
            let v458_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v458_2));
            drop(v458_2);
            let v458_10: Space = if map_kernels::has_head(&(v458_9)) { singleton(&[]) } else { Space::new() };
            drop(v458_9);
            let v458_12: Space = if (v458_10).is_empty() { Space::new() } else {
              let v460_6: Path = concat_path(&(v457_6),&(v457_11_head));
              let v460_11: Space = routine_15(c, &(v460_6), &(v457_11_tail).make_space());
              drop(v460_6);
              map_map_kernels::compose(&(v458_10),&(v460_11))
            };
            drop(v458_10);
            let v458_13: Space = map_map_kernels::unite(&(v458_8),&(v458_12));
            v457_11.join_into((v458_13).clone());
            }
            v457_11_cursor.ascend(1);
          }
          drop(v457_11_cursor);
          drop(v457_6);
          map_map_kernels::compose(&(v452_10),&(v457_11))
        };
        drop(v452_10);
        let v452_13: Space = map_map_kernels::unite(&(v452_8),&(v452_12));
        v451_7.join_into((v452_13).clone());
        }
        v451_7_cursor.ascend(1);
      }
      drop(v451_7_cursor);
      drop(v451_6);
      map_map_kernels::compose(&(v450_5),&(v451_7))
    };
    drop(v450_5);
    let v450_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v450_2));
    drop(v450_2);
    let v450_10: Space = if map_kernels::has_head(&(v450_9)) { singleton(&[]) } else { Space::new() };
    drop(v450_9);
    let v450_11: Space = map_view_kernels::compose(&(v450_10),&(v449_14_tail));
    drop(v450_10);
    let v450_12: Space = map_map_kernels::unite(&(v450_8),&(v450_11));
    drop(v450_11);
    v449_14.join_into((v450_12).clone());
    }
    v449_14_cursor.ascend(1);
  }
  drop(v449_14_cursor);
  (v449_14).clone()
}

fn routine_26(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v461_20 = Space::new();
  let mut v461_20_cursor = (*s0).read_zipper();
  for v461_20_byte in v461_20_cursor.child_mask().iter() {
    v461_20_cursor.descend_to_byte(v461_20_byte);
    {
    let v461_20_tail = v461_20_cursor.fork_read_zipper();
    let v461_20_head = Path::from_slice(&[v461_20_byte]);
    let v462_2: Space = singleton(&(v461_20_head));
    let v462_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v462_2));
    let v462_4: Space = if map_kernels::has_head(&(v462_3)) { singleton(&[]) } else { Space::new() };
    drop(v462_3);
    let v462_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v462_4));
    drop(v462_4);
    let v462_8: Space = if (v462_5).is_empty() { Space::new() } else {
      let v463_6: Path = concat_path(&(*p0),&(v461_20_head));
      let mut v463_7 = Space::new();
      let mut v463_7_cursor = (v461_20_tail).read_zipper();
      for v463_7_byte in v463_7_cursor.child_mask().iter() {
        v463_7_cursor.descend_to_byte(v463_7_byte);
        {
        let v463_7_tail = v463_7_cursor.fork_read_zipper();
        let v463_7_head = Path::from_slice(&[v463_7_byte]);
        let v464_2: Space = singleton(&(v463_7_head));
        let v464_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v464_2));
        let v464_4: Space = if map_kernels::has_head(&(v464_3)) { singleton(&[]) } else { Space::new() };
        drop(v464_3);
        let v464_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v464_4));
        drop(v464_4);
        let v464_8: Space = if (v464_5).is_empty() { Space::new() } else {
          let v465_6: Path = concat_path(&(v463_6),&(v463_7_head));
          let mut v465_7 = Space::new();
          let mut v465_7_cursor = (v463_7_tail).read_zipper();
          for v465_7_byte in v465_7_cursor.child_mask().iter() {
            v465_7_cursor.descend_to_byte(v465_7_byte);
            {
            let v465_7_tail = v465_7_cursor.fork_read_zipper();
            let v465_7_head = Path::from_slice(&[v465_7_byte]);
            let v466_2: Space = singleton(&(v465_7_head));
            let v466_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v466_2));
            let v466_4: Space = if map_kernels::has_head(&(v466_3)) { singleton(&[]) } else { Space::new() };
            drop(v466_3);
            let v466_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v466_4));
            drop(v466_4);
            let v466_8: Space = if (v466_5).is_empty() { Space::new() } else {
              let v467_6: Path = concat_path(&(v465_6),&(v465_7_head));
              let v467_7: Space = routine_40(c, &(v467_6), &(v465_7_tail).make_space());
              map_map_kernels::compose(&(v466_5),&(v467_7))
            };
            drop(v466_5);
            let v466_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v466_2));
            drop(v466_2);
            let v466_10: Space = if map_kernels::has_head(&(v466_9)) { singleton(&[]) } else { Space::new() };
            drop(v466_9);
            let v466_12: Space = if (v466_10).is_empty() { Space::new() } else {
              let v468_6: Path = concat_path(&(v465_6),&(v465_7_head));
              let v468_11: Space = routine_41(c, &(v468_6), &(v465_7_tail).make_space());
              drop(v468_6);
              map_map_kernels::compose(&(v466_10),&(v468_11))
            };
            drop(v466_10);
            let v466_13: Space = map_map_kernels::unite(&(v466_8),&(v466_12));
            v465_7.join_into((v466_13).clone());
            }
            v465_7_cursor.ascend(1);
          }
          drop(v465_7_cursor);
          map_map_kernels::compose(&(v464_5),&(v465_7))
        };
        drop(v464_5);
        let v464_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v464_2));
        drop(v464_2);
        let v464_10: Space = if map_kernels::has_head(&(v464_9)) { singleton(&[]) } else { Space::new() };
        drop(v464_9);
        let v464_12: Space = if (v464_10).is_empty() { Space::new() } else {
          let v469_6: Path = concat_path(&(v463_6),&(v463_7_head));
          let mut v469_11 = Space::new();
          let mut v469_11_cursor = (v463_7_tail).read_zipper();
          for v469_11_byte in v469_11_cursor.child_mask().iter() {
            v469_11_cursor.descend_to_byte(v469_11_byte);
            {
            let v469_11_tail = v469_11_cursor.fork_read_zipper();
            let v469_11_head = Path::from_slice(&[v469_11_byte]);
            let v470_2: Space = singleton(&(v469_11_head));
            let v470_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v470_2));
            let v470_4: Space = if map_kernels::has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
            drop(v470_3);
            let v470_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v470_4));
            drop(v470_4);
            let v470_8: Space = if (v470_5).is_empty() { Space::new() } else {
              let v471_6: Path = concat_path(&(v469_6),&(v469_11_head));
              let v471_7: Space = routine_40(c, &(v471_6), &(v469_11_tail).make_space());
              map_map_kernels::compose(&(v470_5),&(v471_7))
            };
            drop(v470_5);
            let v470_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v470_2));
            drop(v470_2);
            let v470_10: Space = if map_kernels::has_head(&(v470_9)) { singleton(&[]) } else { Space::new() };
            drop(v470_9);
            let v470_12: Space = if (v470_10).is_empty() { Space::new() } else {
              let v472_6: Path = concat_path(&(v469_6),&(v469_11_head));
              let v472_11: Space = routine_12(c, &(v472_6), &(v469_11_tail).make_space());
              drop(v472_6);
              map_map_kernels::compose(&(v470_10),&(v472_11))
            };
            drop(v470_10);
            let v470_13: Space = map_map_kernels::unite(&(v470_8),&(v470_12));
            v469_11.join_into((v470_13).clone());
            }
            v469_11_cursor.ascend(1);
          }
          drop(v469_11_cursor);
          drop(v469_6);
          map_map_kernels::compose(&(v464_10),&(v469_11))
        };
        drop(v464_10);
        let v464_13: Space = map_map_kernels::unite(&(v464_8),&(v464_12));
        v463_7.join_into((v464_13).clone());
        }
        v463_7_cursor.ascend(1);
      }
      drop(v463_7_cursor);
      map_map_kernels::compose(&(v462_5),&(v463_7))
    };
    drop(v462_5);
    let v462_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v462_2));
    drop(v462_2);
    let v462_10: Space = if map_kernels::has_head(&(v462_9)) { singleton(&[]) } else { Space::new() };
    drop(v462_9);
    let v462_12: Space = if (v462_10).is_empty() { Space::new() } else {
      let v473_6: Path = concat_path(&(*p0),&(v461_20_head));
      let mut v473_11 = Space::new();
      let mut v473_11_cursor = (v461_20_tail).read_zipper();
      for v473_11_byte in v473_11_cursor.child_mask().iter() {
        v473_11_cursor.descend_to_byte(v473_11_byte);
        {
        let v473_11_tail = v473_11_cursor.fork_read_zipper();
        let v473_11_head = Path::from_slice(&[v473_11_byte]);
        let v474_2: Space = singleton(&(v473_11_head));
        let v474_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v474_2));
        let v474_4: Space = if map_kernels::has_head(&(v474_3)) { singleton(&[]) } else { Space::new() };
        drop(v474_3);
        let v474_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v474_4));
        drop(v474_4);
        let v474_8: Space = if (v474_5).is_empty() { Space::new() } else {
          let v475_6: Path = concat_path(&(v473_6),&(v473_11_head));
          let mut v475_7 = Space::new();
          let mut v475_7_cursor = (v473_11_tail).read_zipper();
          for v475_7_byte in v475_7_cursor.child_mask().iter() {
            v475_7_cursor.descend_to_byte(v475_7_byte);
            {
            let v475_7_tail = v475_7_cursor.fork_read_zipper();
            let v475_7_head = Path::from_slice(&[v475_7_byte]);
            let v476_2: Space = singleton(&(v475_7_head));
            let v476_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v476_2));
            let v476_4: Space = if map_kernels::has_head(&(v476_3)) { singleton(&[]) } else { Space::new() };
            drop(v476_3);
            let v476_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v476_4));
            drop(v476_4);
            let v476_8: Space = if (v476_5).is_empty() { Space::new() } else {
              let v477_6: Path = concat_path(&(v475_6),&(v475_7_head));
              let v477_7: Space = routine_40(c, &(v477_6), &(v475_7_tail).make_space());
              map_map_kernels::compose(&(v476_5),&(v477_7))
            };
            drop(v476_5);
            let v476_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v476_2));
            drop(v476_2);
            let v476_10: Space = if map_kernels::has_head(&(v476_9)) { singleton(&[]) } else { Space::new() };
            drop(v476_9);
            let v476_12: Space = if (v476_10).is_empty() { Space::new() } else {
              let v478_6: Path = concat_path(&(v475_6),&(v475_7_head));
              let v478_11: Space = routine_41(c, &(v478_6), &(v475_7_tail).make_space());
              drop(v478_6);
              map_map_kernels::compose(&(v476_10),&(v478_11))
            };
            drop(v476_10);
            let v476_13: Space = map_map_kernels::unite(&(v476_8),&(v476_12));
            v475_7.join_into((v476_13).clone());
            }
            v475_7_cursor.ascend(1);
          }
          drop(v475_7_cursor);
          drop(v475_6);
          map_map_kernels::compose(&(v474_5),&(v475_7))
        };
        drop(v474_5);
        let v474_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v474_2));
        drop(v474_2);
        let v474_10: Space = if map_kernels::has_head(&(v474_9)) { singleton(&[]) } else { Space::new() };
        drop(v474_9);
        let v474_11: Space = map_view_kernels::compose(&(v474_10),&(v473_11_tail));
        drop(v474_10);
        let v474_12: Space = map_map_kernels::unite(&(v474_8),&(v474_11));
        drop(v474_11);
        v473_11.join_into((v474_12).clone());
        }
        v473_11_cursor.ascend(1);
      }
      drop(v473_11_cursor);
      drop(v473_6);
      map_map_kernels::compose(&(v462_10),&(v473_11))
    };
    drop(v462_10);
    let v462_13: Space = map_map_kernels::unite(&(v462_8),&(v462_12));
    v461_20.join_into((v462_13).clone());
    }
    v461_20_cursor.ascend(1);
  }
  drop(v461_20_cursor);
  (v461_20).clone()
}

fn routine_27(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v479_14 = Space::new();
  let mut v479_14_cursor = (*s0).read_zipper();
  for v479_14_byte in v479_14_cursor.child_mask().iter() {
    v479_14_cursor.descend_to_byte(v479_14_byte);
    {
    let v479_14_tail = v479_14_cursor.fork_read_zipper();
    let v479_14_head = Path::from_slice(&[v479_14_byte]);
    let v480_2: Space = singleton(&(v479_14_head));
    let v480_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v480_2));
    let v480_4: Space = if map_kernels::has_head(&(v480_3)) { singleton(&[]) } else { Space::new() };
    drop(v480_3);
    let v480_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v480_4));
    drop(v480_4);
    let v480_8: Space = if (v480_5).is_empty() { Space::new() } else {
      let v481_6: Path = concat_path(&(*p0),&(v479_14_head));
      let mut v481_7 = Space::new();
      let mut v481_7_cursor = (v479_14_tail).read_zipper();
      for v481_7_byte in v481_7_cursor.child_mask().iter() {
        v481_7_cursor.descend_to_byte(v481_7_byte);
        {
        let v481_7_tail = v481_7_cursor.fork_read_zipper();
        let v481_7_head = Path::from_slice(&[v481_7_byte]);
        let v482_2: Space = singleton(&(v481_7_head));
        let v482_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v482_2));
        let v482_4: Space = if map_kernels::has_head(&(v482_3)) { singleton(&[]) } else { Space::new() };
        drop(v482_3);
        let v482_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v482_4));
        drop(v482_4);
        let v482_8: Space = if (v482_5).is_empty() { Space::new() } else {
          let v483_6: Path = concat_path(&(v481_6),&(v481_7_head));
          let mut v483_7 = Space::new();
          let mut v483_7_cursor = (v481_7_tail).read_zipper();
          for v483_7_byte in v483_7_cursor.child_mask().iter() {
            v483_7_cursor.descend_to_byte(v483_7_byte);
            {
            let v483_7_tail = v483_7_cursor.fork_read_zipper();
            let v483_7_head = Path::from_slice(&[v483_7_byte]);
            let v484_2: Space = singleton(&(v483_7_head));
            let v484_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v484_2));
            let v484_4: Space = if map_kernels::has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
            drop(v484_3);
            let v484_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v484_4));
            drop(v484_4);
            let v484_8: Space = if (v484_5).is_empty() { Space::new() } else {
              let v485_6: Path = concat_path(&(v483_6),&(v483_7_head));
              let v485_7: Space = routine_40(c, &(v485_6), &(v483_7_tail).make_space());
              map_map_kernels::compose(&(v484_5),&(v485_7))
            };
            drop(v484_5);
            let v484_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v484_2));
            drop(v484_2);
            let v484_10: Space = if map_kernels::has_head(&(v484_9)) { singleton(&[]) } else { Space::new() };
            drop(v484_9);
            let v484_12: Space = if (v484_10).is_empty() { Space::new() } else {
              let v486_6: Path = concat_path(&(v483_6),&(v483_7_head));
              let v486_11: Space = routine_41(c, &(v486_6), &(v483_7_tail).make_space());
              drop(v486_6);
              map_map_kernels::compose(&(v484_10),&(v486_11))
            };
            drop(v484_10);
            let v484_13: Space = map_map_kernels::unite(&(v484_8),&(v484_12));
            v483_7.join_into((v484_13).clone());
            }
            v483_7_cursor.ascend(1);
          }
          drop(v483_7_cursor);
          map_map_kernels::compose(&(v482_5),&(v483_7))
        };
        drop(v482_5);
        let v482_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v482_2));
        drop(v482_2);
        let v482_10: Space = if map_kernels::has_head(&(v482_9)) { singleton(&[]) } else { Space::new() };
        drop(v482_9);
        let v482_12: Space = if (v482_10).is_empty() { Space::new() } else {
          let v487_6: Path = concat_path(&(v481_6),&(v481_7_head));
          let mut v487_11 = Space::new();
          let mut v487_11_cursor = (v481_7_tail).read_zipper();
          for v487_11_byte in v487_11_cursor.child_mask().iter() {
            v487_11_cursor.descend_to_byte(v487_11_byte);
            {
            let v487_11_tail = v487_11_cursor.fork_read_zipper();
            let v487_11_head = Path::from_slice(&[v487_11_byte]);
            let v488_2: Space = singleton(&(v487_11_head));
            let v488_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v488_2));
            let v488_4: Space = if map_kernels::has_head(&(v488_3)) { singleton(&[]) } else { Space::new() };
            drop(v488_3);
            let v488_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v488_4));
            drop(v488_4);
            let v488_8: Space = if (v488_5).is_empty() { Space::new() } else {
              let v489_6: Path = concat_path(&(v487_6),&(v487_11_head));
              let v489_7: Space = routine_40(c, &(v489_6), &(v487_11_tail).make_space());
              map_map_kernels::compose(&(v488_5),&(v489_7))
            };
            drop(v488_5);
            let v488_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v488_2));
            drop(v488_2);
            let v488_10: Space = if map_kernels::has_head(&(v488_9)) { singleton(&[]) } else { Space::new() };
            drop(v488_9);
            let v488_12: Space = if (v488_10).is_empty() { Space::new() } else {
              let v490_6: Path = concat_path(&(v487_6),&(v487_11_head));
              let v490_11: Space = routine_12(c, &(v490_6), &(v487_11_tail).make_space());
              drop(v490_6);
              map_map_kernels::compose(&(v488_10),&(v490_11))
            };
            drop(v488_10);
            let v488_13: Space = map_map_kernels::unite(&(v488_8),&(v488_12));
            v487_11.join_into((v488_13).clone());
            }
            v487_11_cursor.ascend(1);
          }
          drop(v487_11_cursor);
          drop(v487_6);
          map_map_kernels::compose(&(v482_10),&(v487_11))
        };
        drop(v482_10);
        let v482_13: Space = map_map_kernels::unite(&(v482_8),&(v482_12));
        v481_7.join_into((v482_13).clone());
        }
        v481_7_cursor.ascend(1);
      }
      drop(v481_7_cursor);
      drop(v481_6);
      map_map_kernels::compose(&(v480_5),&(v481_7))
    };
    drop(v480_5);
    let v480_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v480_2));
    drop(v480_2);
    let v480_10: Space = if map_kernels::has_head(&(v480_9)) { singleton(&[]) } else { Space::new() };
    drop(v480_9);
    let v480_11: Space = map_view_kernels::compose(&(v480_10),&(v479_14_tail));
    drop(v480_10);
    let v480_12: Space = map_map_kernels::unite(&(v480_8),&(v480_11));
    drop(v480_11);
    v479_14.join_into((v480_12).clone());
    }
    v479_14_cursor.ascend(1);
  }
  drop(v479_14_cursor);
  (v479_14).clone()
}

fn routine_28(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v491_20 = Space::new();
  let mut v491_20_cursor = (*s0).read_zipper();
  for v491_20_byte in v491_20_cursor.child_mask().iter() {
    v491_20_cursor.descend_to_byte(v491_20_byte);
    {
    let v491_20_tail = v491_20_cursor.fork_read_zipper();
    let v491_20_head = Path::from_slice(&[v491_20_byte]);
    let v492_2: Space = singleton(&(v491_20_head));
    let v492_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v492_2));
    let v492_4: Space = if map_kernels::has_head(&(v492_3)) { singleton(&[]) } else { Space::new() };
    drop(v492_3);
    let v492_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v492_4));
    drop(v492_4);
    let v492_8: Space = if (v492_5).is_empty() { Space::new() } else {
      let v493_6: Path = concat_path(&(*p0),&(v491_20_head));
      let mut v493_7 = Space::new();
      let mut v493_7_cursor = (v491_20_tail).read_zipper();
      for v493_7_byte in v493_7_cursor.child_mask().iter() {
        v493_7_cursor.descend_to_byte(v493_7_byte);
        {
        let v493_7_tail = v493_7_cursor.fork_read_zipper();
        let v493_7_head = Path::from_slice(&[v493_7_byte]);
        let v494_2: Space = singleton(&(v493_7_head));
        let v494_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v494_2));
        let v494_4: Space = if map_kernels::has_head(&(v494_3)) { singleton(&[]) } else { Space::new() };
        drop(v494_3);
        let v494_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v494_4));
        drop(v494_4);
        let v494_8: Space = if (v494_5).is_empty() { Space::new() } else {
          let v495_6: Path = concat_path(&(v493_6),&(v493_7_head));
          let mut v495_7 = Space::new();
          let mut v495_7_cursor = (v493_7_tail).read_zipper();
          for v495_7_byte in v495_7_cursor.child_mask().iter() {
            v495_7_cursor.descend_to_byte(v495_7_byte);
            {
            let v495_7_tail = v495_7_cursor.fork_read_zipper();
            let v495_7_head = Path::from_slice(&[v495_7_byte]);
            let v496_2: Space = singleton(&(v495_7_head));
            let v496_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v496_2));
            let v496_4: Space = if map_kernels::has_head(&(v496_3)) { singleton(&[]) } else { Space::new() };
            drop(v496_3);
            let v496_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v496_4));
            drop(v496_4);
            let v496_8: Space = if (v496_5).is_empty() { Space::new() } else {
              let v497_6: Path = concat_path(&(v495_6),&(v495_7_head));
              let v497_7: Space = routine_42(c, &(v497_6), &(v495_7_tail).make_space());
              map_map_kernels::compose(&(v496_5),&(v497_7))
            };
            drop(v496_5);
            let v496_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v496_2));
            drop(v496_2);
            let v496_10: Space = if map_kernels::has_head(&(v496_9)) { singleton(&[]) } else { Space::new() };
            drop(v496_9);
            let v496_12: Space = if (v496_10).is_empty() { Space::new() } else {
              let v498_6: Path = concat_path(&(v495_6),&(v495_7_head));
              let v498_11: Space = routine_43(c, &(v498_6), &(v495_7_tail).make_space());
              drop(v498_6);
              map_map_kernels::compose(&(v496_10),&(v498_11))
            };
            drop(v496_10);
            let v496_13: Space = map_map_kernels::unite(&(v496_8),&(v496_12));
            v495_7.join_into((v496_13).clone());
            }
            v495_7_cursor.ascend(1);
          }
          drop(v495_7_cursor);
          map_map_kernels::compose(&(v494_5),&(v495_7))
        };
        drop(v494_5);
        let v494_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v494_2));
        drop(v494_2);
        let v494_10: Space = if map_kernels::has_head(&(v494_9)) { singleton(&[]) } else { Space::new() };
        drop(v494_9);
        let v494_12: Space = if (v494_10).is_empty() { Space::new() } else {
          let v499_6: Path = concat_path(&(v493_6),&(v493_7_head));
          let mut v499_11 = Space::new();
          let mut v499_11_cursor = (v493_7_tail).read_zipper();
          for v499_11_byte in v499_11_cursor.child_mask().iter() {
            v499_11_cursor.descend_to_byte(v499_11_byte);
            {
            let v499_11_tail = v499_11_cursor.fork_read_zipper();
            let v499_11_head = Path::from_slice(&[v499_11_byte]);
            let v500_2: Space = singleton(&(v499_11_head));
            let v500_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v500_2));
            let v500_4: Space = if map_kernels::has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
            drop(v500_3);
            let v500_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v500_4));
            drop(v500_4);
            let v500_8: Space = if (v500_5).is_empty() { Space::new() } else {
              let v501_6: Path = concat_path(&(v499_6),&(v499_11_head));
              let v501_7: Space = routine_42(c, &(v501_6), &(v499_11_tail).make_space());
              map_map_kernels::compose(&(v500_5),&(v501_7))
            };
            drop(v500_5);
            let v500_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v500_2));
            drop(v500_2);
            let v500_10: Space = if map_kernels::has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
            drop(v500_9);
            let v500_12: Space = if (v500_10).is_empty() { Space::new() } else {
              let v502_6: Path = concat_path(&(v499_6),&(v499_11_head));
              let v502_11: Space = routine_15(c, &(v502_6), &(v499_11_tail).make_space());
              drop(v502_6);
              map_map_kernels::compose(&(v500_10),&(v502_11))
            };
            drop(v500_10);
            let v500_13: Space = map_map_kernels::unite(&(v500_8),&(v500_12));
            v499_11.join_into((v500_13).clone());
            }
            v499_11_cursor.ascend(1);
          }
          drop(v499_11_cursor);
          drop(v499_6);
          map_map_kernels::compose(&(v494_10),&(v499_11))
        };
        drop(v494_10);
        let v494_13: Space = map_map_kernels::unite(&(v494_8),&(v494_12));
        v493_7.join_into((v494_13).clone());
        }
        v493_7_cursor.ascend(1);
      }
      drop(v493_7_cursor);
      map_map_kernels::compose(&(v492_5),&(v493_7))
    };
    drop(v492_5);
    let v492_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v492_2));
    drop(v492_2);
    let v492_10: Space = if map_kernels::has_head(&(v492_9)) { singleton(&[]) } else { Space::new() };
    drop(v492_9);
    let v492_12: Space = if (v492_10).is_empty() { Space::new() } else {
      let v503_6: Path = concat_path(&(*p0),&(v491_20_head));
      let mut v503_11 = Space::new();
      let mut v503_11_cursor = (v491_20_tail).read_zipper();
      for v503_11_byte in v503_11_cursor.child_mask().iter() {
        v503_11_cursor.descend_to_byte(v503_11_byte);
        {
        let v503_11_tail = v503_11_cursor.fork_read_zipper();
        let v503_11_head = Path::from_slice(&[v503_11_byte]);
        let v504_2: Space = singleton(&(v503_11_head));
        let v504_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v504_2));
        let v504_4: Space = if map_kernels::has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
        drop(v504_3);
        let v504_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v504_4));
        drop(v504_4);
        let v504_8: Space = if (v504_5).is_empty() { Space::new() } else {
          let v505_6: Path = concat_path(&(v503_6),&(v503_11_head));
          let mut v505_7 = Space::new();
          let mut v505_7_cursor = (v503_11_tail).read_zipper();
          for v505_7_byte in v505_7_cursor.child_mask().iter() {
            v505_7_cursor.descend_to_byte(v505_7_byte);
            {
            let v505_7_tail = v505_7_cursor.fork_read_zipper();
            let v505_7_head = Path::from_slice(&[v505_7_byte]);
            let v506_2: Space = singleton(&(v505_7_head));
            let v506_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v506_2));
            let v506_4: Space = if map_kernels::has_head(&(v506_3)) { singleton(&[]) } else { Space::new() };
            drop(v506_3);
            let v506_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v506_4));
            drop(v506_4);
            let v506_8: Space = if (v506_5).is_empty() { Space::new() } else {
              let v507_6: Path = concat_path(&(v505_6),&(v505_7_head));
              let v507_7: Space = routine_42(c, &(v507_6), &(v505_7_tail).make_space());
              map_map_kernels::compose(&(v506_5),&(v507_7))
            };
            drop(v506_5);
            let v506_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v506_2));
            drop(v506_2);
            let v506_10: Space = if map_kernels::has_head(&(v506_9)) { singleton(&[]) } else { Space::new() };
            drop(v506_9);
            let v506_12: Space = if (v506_10).is_empty() { Space::new() } else {
              let v508_6: Path = concat_path(&(v505_6),&(v505_7_head));
              let v508_11: Space = routine_43(c, &(v508_6), &(v505_7_tail).make_space());
              drop(v508_6);
              map_map_kernels::compose(&(v506_10),&(v508_11))
            };
            drop(v506_10);
            let v506_13: Space = map_map_kernels::unite(&(v506_8),&(v506_12));
            v505_7.join_into((v506_13).clone());
            }
            v505_7_cursor.ascend(1);
          }
          drop(v505_7_cursor);
          drop(v505_6);
          map_map_kernels::compose(&(v504_5),&(v505_7))
        };
        drop(v504_5);
        let v504_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v504_2));
        drop(v504_2);
        let v504_10: Space = if map_kernels::has_head(&(v504_9)) { singleton(&[]) } else { Space::new() };
        drop(v504_9);
        let v504_11: Space = map_view_kernels::compose(&(v504_10),&(v503_11_tail));
        drop(v504_10);
        let v504_12: Space = map_map_kernels::unite(&(v504_8),&(v504_11));
        drop(v504_11);
        v503_11.join_into((v504_12).clone());
        }
        v503_11_cursor.ascend(1);
      }
      drop(v503_11_cursor);
      drop(v503_6);
      map_map_kernels::compose(&(v492_10),&(v503_11))
    };
    drop(v492_10);
    let v492_13: Space = map_map_kernels::unite(&(v492_8),&(v492_12));
    v491_20.join_into((v492_13).clone());
    }
    v491_20_cursor.ascend(1);
  }
  drop(v491_20_cursor);
  (v491_20).clone()
}

fn routine_29(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v509_14 = Space::new();
  let mut v509_14_cursor = (*s0).read_zipper();
  for v509_14_byte in v509_14_cursor.child_mask().iter() {
    v509_14_cursor.descend_to_byte(v509_14_byte);
    {
    let v509_14_tail = v509_14_cursor.fork_read_zipper();
    let v509_14_head = Path::from_slice(&[v509_14_byte]);
    let v510_2: Space = singleton(&(v509_14_head));
    let v510_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v510_2));
    let v510_4: Space = if map_kernels::has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
    drop(v510_3);
    let v510_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v510_4));
    drop(v510_4);
    let v510_8: Space = if (v510_5).is_empty() { Space::new() } else {
      let v511_6: Path = concat_path(&(*p0),&(v509_14_head));
      let mut v511_7 = Space::new();
      let mut v511_7_cursor = (v509_14_tail).read_zipper();
      for v511_7_byte in v511_7_cursor.child_mask().iter() {
        v511_7_cursor.descend_to_byte(v511_7_byte);
        {
        let v511_7_tail = v511_7_cursor.fork_read_zipper();
        let v511_7_head = Path::from_slice(&[v511_7_byte]);
        let v512_2: Space = singleton(&(v511_7_head));
        let v512_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v512_2));
        let v512_4: Space = if map_kernels::has_head(&(v512_3)) { singleton(&[]) } else { Space::new() };
        drop(v512_3);
        let v512_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v512_4));
        drop(v512_4);
        let v512_8: Space = if (v512_5).is_empty() { Space::new() } else {
          let v513_6: Path = concat_path(&(v511_6),&(v511_7_head));
          let mut v513_7 = Space::new();
          let mut v513_7_cursor = (v511_7_tail).read_zipper();
          for v513_7_byte in v513_7_cursor.child_mask().iter() {
            v513_7_cursor.descend_to_byte(v513_7_byte);
            {
            let v513_7_tail = v513_7_cursor.fork_read_zipper();
            let v513_7_head = Path::from_slice(&[v513_7_byte]);
            let v514_2: Space = singleton(&(v513_7_head));
            let v514_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v514_2));
            let v514_4: Space = if map_kernels::has_head(&(v514_3)) { singleton(&[]) } else { Space::new() };
            drop(v514_3);
            let v514_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v514_4));
            drop(v514_4);
            let v514_8: Space = if (v514_5).is_empty() { Space::new() } else {
              let v515_6: Path = concat_path(&(v513_6),&(v513_7_head));
              let v515_7: Space = routine_42(c, &(v515_6), &(v513_7_tail).make_space());
              map_map_kernels::compose(&(v514_5),&(v515_7))
            };
            drop(v514_5);
            let v514_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v514_2));
            drop(v514_2);
            let v514_10: Space = if map_kernels::has_head(&(v514_9)) { singleton(&[]) } else { Space::new() };
            drop(v514_9);
            let v514_12: Space = if (v514_10).is_empty() { Space::new() } else {
              let v516_6: Path = concat_path(&(v513_6),&(v513_7_head));
              let v516_11: Space = routine_43(c, &(v516_6), &(v513_7_tail).make_space());
              drop(v516_6);
              map_map_kernels::compose(&(v514_10),&(v516_11))
            };
            drop(v514_10);
            let v514_13: Space = map_map_kernels::unite(&(v514_8),&(v514_12));
            v513_7.join_into((v514_13).clone());
            }
            v513_7_cursor.ascend(1);
          }
          drop(v513_7_cursor);
          map_map_kernels::compose(&(v512_5),&(v513_7))
        };
        drop(v512_5);
        let v512_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v512_2));
        drop(v512_2);
        let v512_10: Space = if map_kernels::has_head(&(v512_9)) { singleton(&[]) } else { Space::new() };
        drop(v512_9);
        let v512_12: Space = if (v512_10).is_empty() { Space::new() } else {
          let v517_6: Path = concat_path(&(v511_6),&(v511_7_head));
          let mut v517_11 = Space::new();
          let mut v517_11_cursor = (v511_7_tail).read_zipper();
          for v517_11_byte in v517_11_cursor.child_mask().iter() {
            v517_11_cursor.descend_to_byte(v517_11_byte);
            {
            let v517_11_tail = v517_11_cursor.fork_read_zipper();
            let v517_11_head = Path::from_slice(&[v517_11_byte]);
            let v518_2: Space = singleton(&(v517_11_head));
            let v518_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v518_2));
            let v518_4: Space = if map_kernels::has_head(&(v518_3)) { singleton(&[]) } else { Space::new() };
            drop(v518_3);
            let v518_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v518_4));
            drop(v518_4);
            let v518_8: Space = if (v518_5).is_empty() { Space::new() } else {
              let v519_6: Path = concat_path(&(v517_6),&(v517_11_head));
              let v519_7: Space = routine_42(c, &(v519_6), &(v517_11_tail).make_space());
              map_map_kernels::compose(&(v518_5),&(v519_7))
            };
            drop(v518_5);
            let v518_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v518_2));
            drop(v518_2);
            let v518_10: Space = if map_kernels::has_head(&(v518_9)) { singleton(&[]) } else { Space::new() };
            drop(v518_9);
            let v518_12: Space = if (v518_10).is_empty() { Space::new() } else {
              let v520_6: Path = concat_path(&(v517_6),&(v517_11_head));
              let v520_11: Space = routine_15(c, &(v520_6), &(v517_11_tail).make_space());
              drop(v520_6);
              map_map_kernels::compose(&(v518_10),&(v520_11))
            };
            drop(v518_10);
            let v518_13: Space = map_map_kernels::unite(&(v518_8),&(v518_12));
            v517_11.join_into((v518_13).clone());
            }
            v517_11_cursor.ascend(1);
          }
          drop(v517_11_cursor);
          drop(v517_6);
          map_map_kernels::compose(&(v512_10),&(v517_11))
        };
        drop(v512_10);
        let v512_13: Space = map_map_kernels::unite(&(v512_8),&(v512_12));
        v511_7.join_into((v512_13).clone());
        }
        v511_7_cursor.ascend(1);
      }
      drop(v511_7_cursor);
      drop(v511_6);
      map_map_kernels::compose(&(v510_5),&(v511_7))
    };
    drop(v510_5);
    let v510_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v510_2));
    drop(v510_2);
    let v510_10: Space = if map_kernels::has_head(&(v510_9)) { singleton(&[]) } else { Space::new() };
    drop(v510_9);
    let v510_11: Space = map_view_kernels::compose(&(v510_10),&(v509_14_tail));
    drop(v510_10);
    let v510_12: Space = map_map_kernels::unite(&(v510_8),&(v510_11));
    drop(v510_11);
    v509_14.join_into((v510_12).clone());
    }
    v509_14_cursor.ascend(1);
  }
  drop(v509_14_cursor);
  (v509_14).clone()
}

fn routine_30(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v521_20 = Space::new();
  let mut v521_20_cursor = (*s0).read_zipper();
  for v521_20_byte in v521_20_cursor.child_mask().iter() {
    v521_20_cursor.descend_to_byte(v521_20_byte);
    {
    let v521_20_tail = v521_20_cursor.fork_read_zipper();
    let v521_20_head = Path::from_slice(&[v521_20_byte]);
    let v522_2: Space = singleton(&(v521_20_head));
    let v522_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v522_2));
    let v522_4: Space = if map_kernels::has_head(&(v522_3)) { singleton(&[]) } else { Space::new() };
    drop(v522_3);
    let v522_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v522_4));
    drop(v522_4);
    let v522_8: Space = if (v522_5).is_empty() { Space::new() } else {
      let v523_6: Path = concat_path(&(*p0),&(v521_20_head));
      let mut v523_7 = Space::new();
      let mut v523_7_cursor = (v521_20_tail).read_zipper();
      for v523_7_byte in v523_7_cursor.child_mask().iter() {
        v523_7_cursor.descend_to_byte(v523_7_byte);
        {
        let v523_7_tail = v523_7_cursor.fork_read_zipper();
        let v523_7_head = Path::from_slice(&[v523_7_byte]);
        let v524_2: Space = singleton(&(v523_7_head));
        let v524_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v524_2));
        let v524_4: Space = if map_kernels::has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
        drop(v524_3);
        let v524_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v524_4));
        drop(v524_4);
        let v524_8: Space = if (v524_5).is_empty() { Space::new() } else {
          let v525_6: Path = concat_path(&(v523_6),&(v523_7_head));
          let mut v525_7 = Space::new();
          let mut v525_7_cursor = (v523_7_tail).read_zipper();
          for v525_7_byte in v525_7_cursor.child_mask().iter() {
            v525_7_cursor.descend_to_byte(v525_7_byte);
            {
            let v525_7_tail = v525_7_cursor.fork_read_zipper();
            let v525_7_head = Path::from_slice(&[v525_7_byte]);
            let v526_2: Space = singleton(&(v525_7_head));
            let v526_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v526_2));
            let v526_4: Space = if map_kernels::has_head(&(v526_3)) { singleton(&[]) } else { Space::new() };
            drop(v526_3);
            let v526_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v526_4));
            drop(v526_4);
            let v526_8: Space = if (v526_5).is_empty() { Space::new() } else {
              let v527_6: Path = concat_path(&(v525_6),&(v525_7_head));
              let v527_7: Space = routine_44(c, &(v527_6), &(v525_7_tail).make_space());
              map_map_kernels::compose(&(v526_5),&(v527_7))
            };
            drop(v526_5);
            let v526_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v526_2));
            drop(v526_2);
            let v526_10: Space = if map_kernels::has_head(&(v526_9)) { singleton(&[]) } else { Space::new() };
            drop(v526_9);
            let v526_12: Space = if (v526_10).is_empty() { Space::new() } else {
              let v528_6: Path = concat_path(&(v525_6),&(v525_7_head));
              let v528_11: Space = routine_45(c, &(v528_6), &(v525_7_tail).make_space());
              drop(v528_6);
              map_map_kernels::compose(&(v526_10),&(v528_11))
            };
            drop(v526_10);
            let v526_13: Space = map_map_kernels::unite(&(v526_8),&(v526_12));
            v525_7.join_into((v526_13).clone());
            }
            v525_7_cursor.ascend(1);
          }
          drop(v525_7_cursor);
          map_map_kernels::compose(&(v524_5),&(v525_7))
        };
        drop(v524_5);
        let v524_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v524_2));
        drop(v524_2);
        let v524_10: Space = if map_kernels::has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
        drop(v524_9);
        let v524_12: Space = if (v524_10).is_empty() { Space::new() } else {
          let v529_6: Path = concat_path(&(v523_6),&(v523_7_head));
          let mut v529_11 = Space::new();
          let mut v529_11_cursor = (v523_7_tail).read_zipper();
          for v529_11_byte in v529_11_cursor.child_mask().iter() {
            v529_11_cursor.descend_to_byte(v529_11_byte);
            {
            let v529_11_tail = v529_11_cursor.fork_read_zipper();
            let v529_11_head = Path::from_slice(&[v529_11_byte]);
            let v530_2: Space = singleton(&(v529_11_head));
            let v530_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v530_2));
            let v530_4: Space = if map_kernels::has_head(&(v530_3)) { singleton(&[]) } else { Space::new() };
            drop(v530_3);
            let v530_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v530_4));
            drop(v530_4);
            let v530_8: Space = if (v530_5).is_empty() { Space::new() } else {
              let v531_6: Path = concat_path(&(v529_6),&(v529_11_head));
              let v531_7: Space = routine_44(c, &(v531_6), &(v529_11_tail).make_space());
              map_map_kernels::compose(&(v530_5),&(v531_7))
            };
            drop(v530_5);
            let v530_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v530_2));
            drop(v530_2);
            let v530_10: Space = if map_kernels::has_head(&(v530_9)) { singleton(&[]) } else { Space::new() };
            drop(v530_9);
            let v530_12: Space = if (v530_10).is_empty() { Space::new() } else {
              let v532_6: Path = concat_path(&(v529_6),&(v529_11_head));
              let v532_11: Space = routine_12(c, &(v532_6), &(v529_11_tail).make_space());
              drop(v532_6);
              map_map_kernels::compose(&(v530_10),&(v532_11))
            };
            drop(v530_10);
            let v530_13: Space = map_map_kernels::unite(&(v530_8),&(v530_12));
            v529_11.join_into((v530_13).clone());
            }
            v529_11_cursor.ascend(1);
          }
          drop(v529_11_cursor);
          drop(v529_6);
          map_map_kernels::compose(&(v524_10),&(v529_11))
        };
        drop(v524_10);
        let v524_13: Space = map_map_kernels::unite(&(v524_8),&(v524_12));
        v523_7.join_into((v524_13).clone());
        }
        v523_7_cursor.ascend(1);
      }
      drop(v523_7_cursor);
      map_map_kernels::compose(&(v522_5),&(v523_7))
    };
    drop(v522_5);
    let v522_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v522_2));
    drop(v522_2);
    let v522_10: Space = if map_kernels::has_head(&(v522_9)) { singleton(&[]) } else { Space::new() };
    drop(v522_9);
    let v522_12: Space = if (v522_10).is_empty() { Space::new() } else {
      let v533_6: Path = concat_path(&(*p0),&(v521_20_head));
      let mut v533_11 = Space::new();
      let mut v533_11_cursor = (v521_20_tail).read_zipper();
      for v533_11_byte in v533_11_cursor.child_mask().iter() {
        v533_11_cursor.descend_to_byte(v533_11_byte);
        {
        let v533_11_tail = v533_11_cursor.fork_read_zipper();
        let v533_11_head = Path::from_slice(&[v533_11_byte]);
        let v534_2: Space = singleton(&(v533_11_head));
        let v534_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v534_2));
        let v534_4: Space = if map_kernels::has_head(&(v534_3)) { singleton(&[]) } else { Space::new() };
        drop(v534_3);
        let v534_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v534_4));
        drop(v534_4);
        let v534_8: Space = if (v534_5).is_empty() { Space::new() } else {
          let v535_6: Path = concat_path(&(v533_6),&(v533_11_head));
          let mut v535_7 = Space::new();
          let mut v535_7_cursor = (v533_11_tail).read_zipper();
          for v535_7_byte in v535_7_cursor.child_mask().iter() {
            v535_7_cursor.descend_to_byte(v535_7_byte);
            {
            let v535_7_tail = v535_7_cursor.fork_read_zipper();
            let v535_7_head = Path::from_slice(&[v535_7_byte]);
            let v536_2: Space = singleton(&(v535_7_head));
            let v536_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v536_2));
            let v536_4: Space = if map_kernels::has_head(&(v536_3)) { singleton(&[]) } else { Space::new() };
            drop(v536_3);
            let v536_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v536_4));
            drop(v536_4);
            let v536_8: Space = if (v536_5).is_empty() { Space::new() } else {
              let v537_6: Path = concat_path(&(v535_6),&(v535_7_head));
              let v537_7: Space = routine_44(c, &(v537_6), &(v535_7_tail).make_space());
              map_map_kernels::compose(&(v536_5),&(v537_7))
            };
            drop(v536_5);
            let v536_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v536_2));
            drop(v536_2);
            let v536_10: Space = if map_kernels::has_head(&(v536_9)) { singleton(&[]) } else { Space::new() };
            drop(v536_9);
            let v536_12: Space = if (v536_10).is_empty() { Space::new() } else {
              let v538_6: Path = concat_path(&(v535_6),&(v535_7_head));
              let v538_11: Space = routine_45(c, &(v538_6), &(v535_7_tail).make_space());
              drop(v538_6);
              map_map_kernels::compose(&(v536_10),&(v538_11))
            };
            drop(v536_10);
            let v536_13: Space = map_map_kernels::unite(&(v536_8),&(v536_12));
            v535_7.join_into((v536_13).clone());
            }
            v535_7_cursor.ascend(1);
          }
          drop(v535_7_cursor);
          drop(v535_6);
          map_map_kernels::compose(&(v534_5),&(v535_7))
        };
        drop(v534_5);
        let v534_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v534_2));
        drop(v534_2);
        let v534_10: Space = if map_kernels::has_head(&(v534_9)) { singleton(&[]) } else { Space::new() };
        drop(v534_9);
        let v534_11: Space = map_view_kernels::compose(&(v534_10),&(v533_11_tail));
        drop(v534_10);
        let v534_12: Space = map_map_kernels::unite(&(v534_8),&(v534_11));
        drop(v534_11);
        v533_11.join_into((v534_12).clone());
        }
        v533_11_cursor.ascend(1);
      }
      drop(v533_11_cursor);
      drop(v533_6);
      map_map_kernels::compose(&(v522_10),&(v533_11))
    };
    drop(v522_10);
    let v522_13: Space = map_map_kernels::unite(&(v522_8),&(v522_12));
    v521_20.join_into((v522_13).clone());
    }
    v521_20_cursor.ascend(1);
  }
  drop(v521_20_cursor);
  (v521_20).clone()
}

fn routine_31(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v539_14 = Space::new();
  let mut v539_14_cursor = (*s0).read_zipper();
  for v539_14_byte in v539_14_cursor.child_mask().iter() {
    v539_14_cursor.descend_to_byte(v539_14_byte);
    {
    let v539_14_tail = v539_14_cursor.fork_read_zipper();
    let v539_14_head = Path::from_slice(&[v539_14_byte]);
    let v540_2: Space = singleton(&(v539_14_head));
    let v540_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v540_2));
    let v540_4: Space = if map_kernels::has_head(&(v540_3)) { singleton(&[]) } else { Space::new() };
    drop(v540_3);
    let v540_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v540_4));
    drop(v540_4);
    let v540_8: Space = if (v540_5).is_empty() { Space::new() } else {
      let v541_6: Path = concat_path(&(*p0),&(v539_14_head));
      let mut v541_7 = Space::new();
      let mut v541_7_cursor = (v539_14_tail).read_zipper();
      for v541_7_byte in v541_7_cursor.child_mask().iter() {
        v541_7_cursor.descend_to_byte(v541_7_byte);
        {
        let v541_7_tail = v541_7_cursor.fork_read_zipper();
        let v541_7_head = Path::from_slice(&[v541_7_byte]);
        let v542_2: Space = singleton(&(v541_7_head));
        let v542_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v542_2));
        let v542_4: Space = if map_kernels::has_head(&(v542_3)) { singleton(&[]) } else { Space::new() };
        drop(v542_3);
        let v542_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v542_4));
        drop(v542_4);
        let v542_8: Space = if (v542_5).is_empty() { Space::new() } else {
          let v543_6: Path = concat_path(&(v541_6),&(v541_7_head));
          let mut v543_7 = Space::new();
          let mut v543_7_cursor = (v541_7_tail).read_zipper();
          for v543_7_byte in v543_7_cursor.child_mask().iter() {
            v543_7_cursor.descend_to_byte(v543_7_byte);
            {
            let v543_7_tail = v543_7_cursor.fork_read_zipper();
            let v543_7_head = Path::from_slice(&[v543_7_byte]);
            let v544_2: Space = singleton(&(v543_7_head));
            let v544_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v544_2));
            let v544_4: Space = if map_kernels::has_head(&(v544_3)) { singleton(&[]) } else { Space::new() };
            drop(v544_3);
            let v544_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v544_4));
            drop(v544_4);
            let v544_8: Space = if (v544_5).is_empty() { Space::new() } else {
              let v545_6: Path = concat_path(&(v543_6),&(v543_7_head));
              let v545_7: Space = routine_44(c, &(v545_6), &(v543_7_tail).make_space());
              map_map_kernels::compose(&(v544_5),&(v545_7))
            };
            drop(v544_5);
            let v544_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v544_2));
            drop(v544_2);
            let v544_10: Space = if map_kernels::has_head(&(v544_9)) { singleton(&[]) } else { Space::new() };
            drop(v544_9);
            let v544_12: Space = if (v544_10).is_empty() { Space::new() } else {
              let v546_6: Path = concat_path(&(v543_6),&(v543_7_head));
              let v546_11: Space = routine_45(c, &(v546_6), &(v543_7_tail).make_space());
              drop(v546_6);
              map_map_kernels::compose(&(v544_10),&(v546_11))
            };
            drop(v544_10);
            let v544_13: Space = map_map_kernels::unite(&(v544_8),&(v544_12));
            v543_7.join_into((v544_13).clone());
            }
            v543_7_cursor.ascend(1);
          }
          drop(v543_7_cursor);
          map_map_kernels::compose(&(v542_5),&(v543_7))
        };
        drop(v542_5);
        let v542_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v542_2));
        drop(v542_2);
        let v542_10: Space = if map_kernels::has_head(&(v542_9)) { singleton(&[]) } else { Space::new() };
        drop(v542_9);
        let v542_12: Space = if (v542_10).is_empty() { Space::new() } else {
          let v547_6: Path = concat_path(&(v541_6),&(v541_7_head));
          let mut v547_11 = Space::new();
          let mut v547_11_cursor = (v541_7_tail).read_zipper();
          for v547_11_byte in v547_11_cursor.child_mask().iter() {
            v547_11_cursor.descend_to_byte(v547_11_byte);
            {
            let v547_11_tail = v547_11_cursor.fork_read_zipper();
            let v547_11_head = Path::from_slice(&[v547_11_byte]);
            let v548_2: Space = singleton(&(v547_11_head));
            let v548_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v548_2));
            let v548_4: Space = if map_kernels::has_head(&(v548_3)) { singleton(&[]) } else { Space::new() };
            drop(v548_3);
            let v548_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v548_4));
            drop(v548_4);
            let v548_8: Space = if (v548_5).is_empty() { Space::new() } else {
              let v549_6: Path = concat_path(&(v547_6),&(v547_11_head));
              let v549_7: Space = routine_44(c, &(v549_6), &(v547_11_tail).make_space());
              map_map_kernels::compose(&(v548_5),&(v549_7))
            };
            drop(v548_5);
            let v548_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v548_2));
            drop(v548_2);
            let v548_10: Space = if map_kernels::has_head(&(v548_9)) { singleton(&[]) } else { Space::new() };
            drop(v548_9);
            let v548_12: Space = if (v548_10).is_empty() { Space::new() } else {
              let v550_6: Path = concat_path(&(v547_6),&(v547_11_head));
              let v550_11: Space = routine_12(c, &(v550_6), &(v547_11_tail).make_space());
              drop(v550_6);
              map_map_kernels::compose(&(v548_10),&(v550_11))
            };
            drop(v548_10);
            let v548_13: Space = map_map_kernels::unite(&(v548_8),&(v548_12));
            v547_11.join_into((v548_13).clone());
            }
            v547_11_cursor.ascend(1);
          }
          drop(v547_11_cursor);
          drop(v547_6);
          map_map_kernels::compose(&(v542_10),&(v547_11))
        };
        drop(v542_10);
        let v542_13: Space = map_map_kernels::unite(&(v542_8),&(v542_12));
        v541_7.join_into((v542_13).clone());
        }
        v541_7_cursor.ascend(1);
      }
      drop(v541_7_cursor);
      drop(v541_6);
      map_map_kernels::compose(&(v540_5),&(v541_7))
    };
    drop(v540_5);
    let v540_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v540_2));
    drop(v540_2);
    let v540_10: Space = if map_kernels::has_head(&(v540_9)) { singleton(&[]) } else { Space::new() };
    drop(v540_9);
    let v540_11: Space = map_view_kernels::compose(&(v540_10),&(v539_14_tail));
    drop(v540_10);
    let v540_12: Space = map_map_kernels::unite(&(v540_8),&(v540_11));
    drop(v540_11);
    v539_14.join_into((v540_12).clone());
    }
    v539_14_cursor.ascend(1);
  }
  drop(v539_14_cursor);
  (v539_14).clone()
}

fn routine_32(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v551_20 = Space::new();
  let mut v551_20_cursor = (*s0).read_zipper();
  for v551_20_byte in v551_20_cursor.child_mask().iter() {
    v551_20_cursor.descend_to_byte(v551_20_byte);
    {
    let v551_20_tail = v551_20_cursor.fork_read_zipper();
    let v551_20_head = Path::from_slice(&[v551_20_byte]);
    let v552_2: Space = singleton(&(v551_20_head));
    let v552_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v552_2));
    let v552_4: Space = if map_kernels::has_head(&(v552_3)) { singleton(&[]) } else { Space::new() };
    drop(v552_3);
    let v552_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v552_4));
    drop(v552_4);
    let v552_8: Space = if (v552_5).is_empty() { Space::new() } else {
      let v553_6: Path = concat_path(&(*p0),&(v551_20_head));
      let mut v553_7 = Space::new();
      let mut v553_7_cursor = (v551_20_tail).read_zipper();
      for v553_7_byte in v553_7_cursor.child_mask().iter() {
        v553_7_cursor.descend_to_byte(v553_7_byte);
        {
        let v553_7_tail = v553_7_cursor.fork_read_zipper();
        let v553_7_head = Path::from_slice(&[v553_7_byte]);
        let v554_2: Space = singleton(&(v553_7_head));
        let v554_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v554_2));
        let v554_4: Space = if map_kernels::has_head(&(v554_3)) { singleton(&[]) } else { Space::new() };
        drop(v554_3);
        let v554_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v554_4));
        drop(v554_4);
        let v554_8: Space = if (v554_5).is_empty() { Space::new() } else {
          let v555_6: Path = concat_path(&(v553_6),&(v553_7_head));
          let mut v555_7 = Space::new();
          let mut v555_7_cursor = (v553_7_tail).read_zipper();
          for v555_7_byte in v555_7_cursor.child_mask().iter() {
            v555_7_cursor.descend_to_byte(v555_7_byte);
            {
            let v555_7_tail = v555_7_cursor.fork_read_zipper();
            let v555_7_head = Path::from_slice(&[v555_7_byte]);
            let v556_2: Space = singleton(&(v555_7_head));
            let v556_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v556_2));
            let v556_4: Space = if map_kernels::has_head(&(v556_3)) { singleton(&[]) } else { Space::new() };
            drop(v556_3);
            let v556_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v556_4));
            drop(v556_4);
            let v556_8: Space = if (v556_5).is_empty() { Space::new() } else {
              let v557_6: Path = concat_path(&(v555_6),&(v555_7_head));
              let v557_7: Space = routine_46(c, &(v557_6), &(v555_7_tail).make_space());
              map_map_kernels::compose(&(v556_5),&(v557_7))
            };
            drop(v556_5);
            let v556_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v556_2));
            drop(v556_2);
            let v556_10: Space = if map_kernels::has_head(&(v556_9)) { singleton(&[]) } else { Space::new() };
            drop(v556_9);
            let v556_12: Space = if (v556_10).is_empty() { Space::new() } else {
              let v558_6: Path = concat_path(&(v555_6),&(v555_7_head));
              let v558_11: Space = routine_47(c, &(v558_6), &(v555_7_tail).make_space());
              drop(v558_6);
              map_map_kernels::compose(&(v556_10),&(v558_11))
            };
            drop(v556_10);
            let v556_13: Space = map_map_kernels::unite(&(v556_8),&(v556_12));
            v555_7.join_into((v556_13).clone());
            }
            v555_7_cursor.ascend(1);
          }
          drop(v555_7_cursor);
          map_map_kernels::compose(&(v554_5),&(v555_7))
        };
        drop(v554_5);
        let v554_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v554_2));
        drop(v554_2);
        let v554_10: Space = if map_kernels::has_head(&(v554_9)) { singleton(&[]) } else { Space::new() };
        drop(v554_9);
        let v554_12: Space = if (v554_10).is_empty() { Space::new() } else {
          let v559_6: Path = concat_path(&(v553_6),&(v553_7_head));
          let mut v559_11 = Space::new();
          let mut v559_11_cursor = (v553_7_tail).read_zipper();
          for v559_11_byte in v559_11_cursor.child_mask().iter() {
            v559_11_cursor.descend_to_byte(v559_11_byte);
            {
            let v559_11_tail = v559_11_cursor.fork_read_zipper();
            let v559_11_head = Path::from_slice(&[v559_11_byte]);
            let v560_2: Space = singleton(&(v559_11_head));
            let v560_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v560_2));
            let v560_4: Space = if map_kernels::has_head(&(v560_3)) { singleton(&[]) } else { Space::new() };
            drop(v560_3);
            let v560_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v560_4));
            drop(v560_4);
            let v560_8: Space = if (v560_5).is_empty() { Space::new() } else {
              let v561_6: Path = concat_path(&(v559_6),&(v559_11_head));
              let v561_7: Space = routine_46(c, &(v561_6), &(v559_11_tail).make_space());
              map_map_kernels::compose(&(v560_5),&(v561_7))
            };
            drop(v560_5);
            let v560_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v560_2));
            drop(v560_2);
            let v560_10: Space = if map_kernels::has_head(&(v560_9)) { singleton(&[]) } else { Space::new() };
            drop(v560_9);
            let v560_12: Space = if (v560_10).is_empty() { Space::new() } else {
              let v562_6: Path = concat_path(&(v559_6),&(v559_11_head));
              let v562_11: Space = routine_15(c, &(v562_6), &(v559_11_tail).make_space());
              drop(v562_6);
              map_map_kernels::compose(&(v560_10),&(v562_11))
            };
            drop(v560_10);
            let v560_13: Space = map_map_kernels::unite(&(v560_8),&(v560_12));
            v559_11.join_into((v560_13).clone());
            }
            v559_11_cursor.ascend(1);
          }
          drop(v559_11_cursor);
          drop(v559_6);
          map_map_kernels::compose(&(v554_10),&(v559_11))
        };
        drop(v554_10);
        let v554_13: Space = map_map_kernels::unite(&(v554_8),&(v554_12));
        v553_7.join_into((v554_13).clone());
        }
        v553_7_cursor.ascend(1);
      }
      drop(v553_7_cursor);
      map_map_kernels::compose(&(v552_5),&(v553_7))
    };
    drop(v552_5);
    let v552_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v552_2));
    drop(v552_2);
    let v552_10: Space = if map_kernels::has_head(&(v552_9)) { singleton(&[]) } else { Space::new() };
    drop(v552_9);
    let v552_12: Space = if (v552_10).is_empty() { Space::new() } else {
      let v563_6: Path = concat_path(&(*p0),&(v551_20_head));
      let mut v563_11 = Space::new();
      let mut v563_11_cursor = (v551_20_tail).read_zipper();
      for v563_11_byte in v563_11_cursor.child_mask().iter() {
        v563_11_cursor.descend_to_byte(v563_11_byte);
        {
        let v563_11_tail = v563_11_cursor.fork_read_zipper();
        let v563_11_head = Path::from_slice(&[v563_11_byte]);
        let v564_2: Space = singleton(&(v563_11_head));
        let v564_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v564_2));
        let v564_4: Space = if map_kernels::has_head(&(v564_3)) { singleton(&[]) } else { Space::new() };
        drop(v564_3);
        let v564_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v564_4));
        drop(v564_4);
        let v564_8: Space = if (v564_5).is_empty() { Space::new() } else {
          let v565_6: Path = concat_path(&(v563_6),&(v563_11_head));
          let mut v565_7 = Space::new();
          let mut v565_7_cursor = (v563_11_tail).read_zipper();
          for v565_7_byte in v565_7_cursor.child_mask().iter() {
            v565_7_cursor.descend_to_byte(v565_7_byte);
            {
            let v565_7_tail = v565_7_cursor.fork_read_zipper();
            let v565_7_head = Path::from_slice(&[v565_7_byte]);
            let v566_2: Space = singleton(&(v565_7_head));
            let v566_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v566_2));
            let v566_4: Space = if map_kernels::has_head(&(v566_3)) { singleton(&[]) } else { Space::new() };
            drop(v566_3);
            let v566_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v566_4));
            drop(v566_4);
            let v566_8: Space = if (v566_5).is_empty() { Space::new() } else {
              let v567_6: Path = concat_path(&(v565_6),&(v565_7_head));
              let v567_7: Space = routine_46(c, &(v567_6), &(v565_7_tail).make_space());
              map_map_kernels::compose(&(v566_5),&(v567_7))
            };
            drop(v566_5);
            let v566_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v566_2));
            drop(v566_2);
            let v566_10: Space = if map_kernels::has_head(&(v566_9)) { singleton(&[]) } else { Space::new() };
            drop(v566_9);
            let v566_12: Space = if (v566_10).is_empty() { Space::new() } else {
              let v568_6: Path = concat_path(&(v565_6),&(v565_7_head));
              let v568_11: Space = routine_47(c, &(v568_6), &(v565_7_tail).make_space());
              drop(v568_6);
              map_map_kernels::compose(&(v566_10),&(v568_11))
            };
            drop(v566_10);
            let v566_13: Space = map_map_kernels::unite(&(v566_8),&(v566_12));
            v565_7.join_into((v566_13).clone());
            }
            v565_7_cursor.ascend(1);
          }
          drop(v565_7_cursor);
          drop(v565_6);
          map_map_kernels::compose(&(v564_5),&(v565_7))
        };
        drop(v564_5);
        let v564_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v564_2));
        drop(v564_2);
        let v564_10: Space = if map_kernels::has_head(&(v564_9)) { singleton(&[]) } else { Space::new() };
        drop(v564_9);
        let v564_11: Space = map_view_kernels::compose(&(v564_10),&(v563_11_tail));
        drop(v564_10);
        let v564_12: Space = map_map_kernels::unite(&(v564_8),&(v564_11));
        drop(v564_11);
        v563_11.join_into((v564_12).clone());
        }
        v563_11_cursor.ascend(1);
      }
      drop(v563_11_cursor);
      drop(v563_6);
      map_map_kernels::compose(&(v552_10),&(v563_11))
    };
    drop(v552_10);
    let v552_13: Space = map_map_kernels::unite(&(v552_8),&(v552_12));
    v551_20.join_into((v552_13).clone());
    }
    v551_20_cursor.ascend(1);
  }
  drop(v551_20_cursor);
  (v551_20).clone()
}

fn routine_33(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v569_14 = Space::new();
  let mut v569_14_cursor = (*s0).read_zipper();
  for v569_14_byte in v569_14_cursor.child_mask().iter() {
    v569_14_cursor.descend_to_byte(v569_14_byte);
    {
    let v569_14_tail = v569_14_cursor.fork_read_zipper();
    let v569_14_head = Path::from_slice(&[v569_14_byte]);
    let v570_2: Space = singleton(&(v569_14_head));
    let v570_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v570_2));
    let v570_4: Space = if map_kernels::has_head(&(v570_3)) { singleton(&[]) } else { Space::new() };
    drop(v570_3);
    let v570_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v570_4));
    drop(v570_4);
    let v570_8: Space = if (v570_5).is_empty() { Space::new() } else {
      let v571_6: Path = concat_path(&(*p0),&(v569_14_head));
      let mut v571_7 = Space::new();
      let mut v571_7_cursor = (v569_14_tail).read_zipper();
      for v571_7_byte in v571_7_cursor.child_mask().iter() {
        v571_7_cursor.descend_to_byte(v571_7_byte);
        {
        let v571_7_tail = v571_7_cursor.fork_read_zipper();
        let v571_7_head = Path::from_slice(&[v571_7_byte]);
        let v572_2: Space = singleton(&(v571_7_head));
        let v572_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v572_2));
        let v572_4: Space = if map_kernels::has_head(&(v572_3)) { singleton(&[]) } else { Space::new() };
        drop(v572_3);
        let v572_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v572_4));
        drop(v572_4);
        let v572_8: Space = if (v572_5).is_empty() { Space::new() } else {
          let v573_6: Path = concat_path(&(v571_6),&(v571_7_head));
          let mut v573_7 = Space::new();
          let mut v573_7_cursor = (v571_7_tail).read_zipper();
          for v573_7_byte in v573_7_cursor.child_mask().iter() {
            v573_7_cursor.descend_to_byte(v573_7_byte);
            {
            let v573_7_tail = v573_7_cursor.fork_read_zipper();
            let v573_7_head = Path::from_slice(&[v573_7_byte]);
            let v574_2: Space = singleton(&(v573_7_head));
            let v574_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v574_2));
            let v574_4: Space = if map_kernels::has_head(&(v574_3)) { singleton(&[]) } else { Space::new() };
            drop(v574_3);
            let v574_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v574_4));
            drop(v574_4);
            let v574_8: Space = if (v574_5).is_empty() { Space::new() } else {
              let v575_6: Path = concat_path(&(v573_6),&(v573_7_head));
              let v575_7: Space = routine_46(c, &(v575_6), &(v573_7_tail).make_space());
              map_map_kernels::compose(&(v574_5),&(v575_7))
            };
            drop(v574_5);
            let v574_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v574_2));
            drop(v574_2);
            let v574_10: Space = if map_kernels::has_head(&(v574_9)) { singleton(&[]) } else { Space::new() };
            drop(v574_9);
            let v574_12: Space = if (v574_10).is_empty() { Space::new() } else {
              let v576_6: Path = concat_path(&(v573_6),&(v573_7_head));
              let v576_11: Space = routine_47(c, &(v576_6), &(v573_7_tail).make_space());
              drop(v576_6);
              map_map_kernels::compose(&(v574_10),&(v576_11))
            };
            drop(v574_10);
            let v574_13: Space = map_map_kernels::unite(&(v574_8),&(v574_12));
            v573_7.join_into((v574_13).clone());
            }
            v573_7_cursor.ascend(1);
          }
          drop(v573_7_cursor);
          map_map_kernels::compose(&(v572_5),&(v573_7))
        };
        drop(v572_5);
        let v572_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v572_2));
        drop(v572_2);
        let v572_10: Space = if map_kernels::has_head(&(v572_9)) { singleton(&[]) } else { Space::new() };
        drop(v572_9);
        let v572_12: Space = if (v572_10).is_empty() { Space::new() } else {
          let v577_6: Path = concat_path(&(v571_6),&(v571_7_head));
          let mut v577_11 = Space::new();
          let mut v577_11_cursor = (v571_7_tail).read_zipper();
          for v577_11_byte in v577_11_cursor.child_mask().iter() {
            v577_11_cursor.descend_to_byte(v577_11_byte);
            {
            let v577_11_tail = v577_11_cursor.fork_read_zipper();
            let v577_11_head = Path::from_slice(&[v577_11_byte]);
            let v578_2: Space = singleton(&(v577_11_head));
            let v578_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v578_2));
            let v578_4: Space = if map_kernels::has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
            drop(v578_3);
            let v578_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v578_4));
            drop(v578_4);
            let v578_8: Space = if (v578_5).is_empty() { Space::new() } else {
              let v579_6: Path = concat_path(&(v577_6),&(v577_11_head));
              let v579_7: Space = routine_46(c, &(v579_6), &(v577_11_tail).make_space());
              map_map_kernels::compose(&(v578_5),&(v579_7))
            };
            drop(v578_5);
            let v578_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v578_2));
            drop(v578_2);
            let v578_10: Space = if map_kernels::has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
            drop(v578_9);
            let v578_12: Space = if (v578_10).is_empty() { Space::new() } else {
              let v580_6: Path = concat_path(&(v577_6),&(v577_11_head));
              let v580_11: Space = routine_15(c, &(v580_6), &(v577_11_tail).make_space());
              drop(v580_6);
              map_map_kernels::compose(&(v578_10),&(v580_11))
            };
            drop(v578_10);
            let v578_13: Space = map_map_kernels::unite(&(v578_8),&(v578_12));
            v577_11.join_into((v578_13).clone());
            }
            v577_11_cursor.ascend(1);
          }
          drop(v577_11_cursor);
          drop(v577_6);
          map_map_kernels::compose(&(v572_10),&(v577_11))
        };
        drop(v572_10);
        let v572_13: Space = map_map_kernels::unite(&(v572_8),&(v572_12));
        v571_7.join_into((v572_13).clone());
        }
        v571_7_cursor.ascend(1);
      }
      drop(v571_7_cursor);
      drop(v571_6);
      map_map_kernels::compose(&(v570_5),&(v571_7))
    };
    drop(v570_5);
    let v570_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v570_2));
    drop(v570_2);
    let v570_10: Space = if map_kernels::has_head(&(v570_9)) { singleton(&[]) } else { Space::new() };
    drop(v570_9);
    let v570_11: Space = map_view_kernels::compose(&(v570_10),&(v569_14_tail));
    drop(v570_10);
    let v570_12: Space = map_map_kernels::unite(&(v570_8),&(v570_11));
    drop(v570_11);
    v569_14.join_into((v570_12).clone());
    }
    v569_14_cursor.ascend(1);
  }
  drop(v569_14_cursor);
  (v569_14).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v581_21: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v581_22: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_4));
  let v581_23: Space = map_kernels::unwrap(&(v581_22),&(*p0));
  let v581_24: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
  let mut v581_34 = Space::new();
  let mut v581_34_cursor = (*s0).read_zipper();
  for v581_34_byte in v581_34_cursor.child_mask().iter() {
    v581_34_cursor.descend_to_byte(v581_34_byte);
    {
    let v581_34_tail = v581_34_cursor.fork_read_zipper();
    let v581_34_head = Path::from_slice(&[v581_34_byte]);
    let v582_2: Space = singleton(&(v581_34_head));
    let v582_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v582_2));
    let v582_4: Space = if map_kernels::has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
    drop(v582_3);
    let v582_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v582_4));
    drop(v582_4);
    let v582_8: Space = if (v582_5).is_empty() { Space::new() } else {
      let v583_6: Path = concat_path(&(*p0),&(v581_34_head));
      let mut v583_7 = Space::new();
      let mut v583_7_cursor = (v581_34_tail).read_zipper();
      for v583_7_byte in v583_7_cursor.child_mask().iter() {
        v583_7_cursor.descend_to_byte(v583_7_byte);
        {
        let v583_7_tail = v583_7_cursor.fork_read_zipper();
        let v583_7_head = Path::from_slice(&[v583_7_byte]);
        let v584_2: Space = singleton(&(v583_7_head));
        let v584_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v584_2));
        let v584_4: Space = if map_kernels::has_head(&(v584_3)) { singleton(&[]) } else { Space::new() };
        drop(v584_3);
        let v584_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v584_4));
        drop(v584_4);
        let v584_8: Space = if (v584_5).is_empty() { Space::new() } else {
          let v585_6: Path = concat_path(&(v583_6),&(v583_7_head));
          let mut v585_7 = Space::new();
          let mut v585_7_cursor = (v583_7_tail).read_zipper();
          for v585_7_byte in v585_7_cursor.child_mask().iter() {
            v585_7_cursor.descend_to_byte(v585_7_byte);
            {
            let v585_7_tail = v585_7_cursor.fork_read_zipper();
            let v585_7_head = Path::from_slice(&[v585_7_byte]);
            let v586_2: Space = singleton(&(v585_7_head));
            let v586_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v586_2));
            let v586_4: Space = if map_kernels::has_head(&(v586_3)) { singleton(&[]) } else { Space::new() };
            drop(v586_3);
            let v586_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v586_4));
            drop(v586_4);
            let v586_8: Space = if (v586_5).is_empty() { Space::new() } else {
              let v587_6: Path = concat_path(&(v585_6),&(v585_7_head));
              let v587_7: Space = routine_48(c, &(v587_6), &(v585_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v586_5),&(v587_7))
            };
            drop(v586_5);
            let v586_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v586_2));
            drop(v586_2);
            let v586_10: Space = if map_kernels::has_head(&(v586_9)) { singleton(&[]) } else { Space::new() };
            drop(v586_9);
            let v586_12: Space = if (v586_10).is_empty() { Space::new() } else {
              let v588_6: Path = concat_path(&(v585_6),&(v585_7_head));
              let v588_11: Space = routine_49(c, &(v588_6), &(v585_7_tail).make_space(), &(*s1));
              drop(v588_6);
              map_map_kernels::compose(&(v586_10),&(v588_11))
            };
            drop(v586_10);
            let v586_13: Space = map_map_kernels::unite(&(v586_8),&(v586_12));
            v585_7.join_into((v586_13).clone());
            }
            v585_7_cursor.ascend(1);
          }
          drop(v585_7_cursor);
          map_map_kernels::compose(&(v584_5),&(v585_7))
        };
        drop(v584_5);
        let v584_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v584_2));
        drop(v584_2);
        let v584_10: Space = if map_kernels::has_head(&(v584_9)) { singleton(&[]) } else { Space::new() };
        drop(v584_9);
        let v584_12: Space = if (v584_10).is_empty() { Space::new() } else {
          let v589_6: Path = concat_path(&(v583_6),&(v583_7_head));
          let mut v589_11 = Space::new();
          let mut v589_11_cursor = (v583_7_tail).read_zipper();
          for v589_11_byte in v589_11_cursor.child_mask().iter() {
            v589_11_cursor.descend_to_byte(v589_11_byte);
            {
            let v589_11_tail = v589_11_cursor.fork_read_zipper();
            let v589_11_head = Path::from_slice(&[v589_11_byte]);
            let v590_2: Space = singleton(&(v589_11_head));
            let v590_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v590_2));
            let v590_4: Space = if map_kernels::has_head(&(v590_3)) { singleton(&[]) } else { Space::new() };
            drop(v590_3);
            let v590_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v590_4));
            drop(v590_4);
            let v590_8: Space = if (v590_5).is_empty() { Space::new() } else {
              let v591_6: Path = concat_path(&(v589_6),&(v589_11_head));
              let v591_7: Space = routine_48(c, &(v591_6), &(v589_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v590_5),&(v591_7))
            };
            drop(v590_5);
            let v590_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v590_2));
            drop(v590_2);
            let v590_10: Space = if map_kernels::has_head(&(v590_9)) { singleton(&[]) } else { Space::new() };
            drop(v590_9);
            let v590_12: Space = if (v590_10).is_empty() { Space::new() } else {
              let v592_6: Path = concat_path(&(v589_6),&(v589_11_head));
              let v592_11: Space = routine_3(c, &(v592_6), &(v589_11_tail).make_space(), &(*s1));
              drop(v592_6);
              map_map_kernels::compose(&(v590_10),&(v592_11))
            };
            drop(v590_10);
            let v590_13: Space = map_map_kernels::unite(&(v590_8),&(v590_12));
            v589_11.join_into((v590_13).clone());
            }
            v589_11_cursor.ascend(1);
          }
          drop(v589_11_cursor);
          drop(v589_6);
          map_map_kernels::compose(&(v584_10),&(v589_11))
        };
        drop(v584_10);
        let v584_13: Space = map_map_kernels::unite(&(v584_8),&(v584_12));
        v583_7.join_into((v584_13).clone());
        }
        v583_7_cursor.ascend(1);
      }
      drop(v583_7_cursor);
      map_map_kernels::compose(&(v582_5),&(v583_7))
    };
    drop(v582_5);
    let v582_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v582_2));
    drop(v582_2);
    let v582_10: Space = if map_kernels::has_head(&(v582_9)) { singleton(&[]) } else { Space::new() };
    drop(v582_9);
    let v582_13: Space = if (v582_10).is_empty() { Space::new() } else {
      let v593_6: Path = concat_path(&(*p0),&(v581_34_head));
      let v593_11: Space = map_kernels::unwrap(&(v581_23),&(v581_34_head));
      let mut v593_12 = Space::new();
      let mut v593_12_cursor = (v581_34_tail).read_zipper();
      for v593_12_byte in v593_12_cursor.child_mask().iter() {
        v593_12_cursor.descend_to_byte(v593_12_byte);
        {
        let v593_12_tail = v593_12_cursor.fork_read_zipper();
        let v593_12_head = Path::from_slice(&[v593_12_byte]);
        let v594_2: Space = singleton(&(v593_12_head));
        let v594_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v594_2));
        let v594_4: Space = if map_kernels::has_head(&(v594_3)) { singleton(&[]) } else { Space::new() };
        drop(v594_3);
        let v594_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v594_4));
        drop(v594_4);
        let v594_8: Space = if (v594_5).is_empty() { Space::new() } else {
          let v595_6: Path = concat_path(&(v593_6),&(v593_12_head));
          let mut v595_7 = Space::new();
          let mut v595_7_cursor = (v593_12_tail).read_zipper();
          for v595_7_byte in v595_7_cursor.child_mask().iter() {
            v595_7_cursor.descend_to_byte(v595_7_byte);
            {
            let v595_7_tail = v595_7_cursor.fork_read_zipper();
            let v595_7_head = Path::from_slice(&[v595_7_byte]);
            let v596_2: Space = singleton(&(v595_7_head));
            let v596_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v596_2));
            let v596_4: Space = if map_kernels::has_head(&(v596_3)) { singleton(&[]) } else { Space::new() };
            drop(v596_3);
            let v596_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v596_4));
            drop(v596_4);
            let v596_8: Space = if (v596_5).is_empty() { Space::new() } else {
              let v597_6: Path = concat_path(&(v595_6),&(v595_7_head));
              let v597_7: Space = routine_48(c, &(v597_6), &(v595_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v596_5),&(v597_7))
            };
            drop(v596_5);
            let v596_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v596_2));
            drop(v596_2);
            let v596_10: Space = if map_kernels::has_head(&(v596_9)) { singleton(&[]) } else { Space::new() };
            drop(v596_9);
            let v596_12: Space = if (v596_10).is_empty() { Space::new() } else {
              let v598_6: Path = concat_path(&(v595_6),&(v595_7_head));
              let v598_11: Space = routine_49(c, &(v598_6), &(v595_7_tail).make_space(), &(*s1));
              drop(v598_6);
              map_map_kernels::compose(&(v596_10),&(v598_11))
            };
            drop(v596_10);
            let v596_13: Space = map_map_kernels::unite(&(v596_8),&(v596_12));
            v595_7.join_into((v596_13).clone());
            }
            v595_7_cursor.ascend(1);
          }
          drop(v595_7_cursor);
          map_map_kernels::compose(&(v594_5),&(v595_7))
        };
        drop(v594_5);
        let v594_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v594_2));
        drop(v594_2);
        let v594_10: Space = if map_kernels::has_head(&(v594_9)) { singleton(&[]) } else { Space::new() };
        drop(v594_9);
        let v594_18: Space = if (v594_10).is_empty() { Space::new() } else {
          let v599_11: Space = map_kernels::unwrap(&(v593_11),&(v593_12_head));
          let v599_12: Space = map_map_kernels::restrict_to(&(v581_22),&(v599_11));
          let mut v599_13 = Space::new();
          let mut v599_13_cursor = (v599_12).read_zipper();
          for v599_13_byte in v599_13_cursor.child_mask().iter() {
            v599_13_cursor.descend_to_byte(v599_13_byte);
            {
            let v599_13_tail = v599_13_cursor.fork_read_zipper();
            let v599_13_head = Path::from_slice(&[v599_13_byte]);
            let v600_2: Space = singleton(&(v599_13_head));
            let v600_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v600_2));
            let v600_4: Space = if map_kernels::has_head(&(v600_3)) { singleton(&[]) } else { Space::new() };
            drop(v600_3);
            let v600_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v600_4));
            drop(v600_4);
            let v600_7: Space = if (v600_5).is_empty() { Space::new() } else {
              let v601_6: Space = routine_6(c, &(v599_13_head), &(v599_13_tail).make_space());
              map_map_kernels::compose(&(v600_5),&(v601_6))
            };
            drop(v600_5);
            let v600_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v600_2));
            drop(v600_2);
            let v600_9: Space = if map_kernels::has_head(&(v600_8)) { singleton(&[]) } else { Space::new() };
            drop(v600_8);
            let v600_11: Space = if (v600_9).is_empty() { Space::new() } else {
              let v602_10: Space = routine_7(c, &(v599_13_head), &(v599_13_tail).make_space());
              map_map_kernels::compose(&(v600_9),&(v602_10))
            };
            drop(v600_9);
            let v600_12: Space = map_map_kernels::unite(&(v600_7),&(v600_11));
            v599_13.join_into((v600_12).clone());
            }
            v599_13_cursor.ascend(1);
          }
          drop(v599_13_cursor);
          drop(v599_12);
          let v599_14: Space = map_map_kernels::restrict_to(&(v581_21),&(v599_13));
          let mut v599_15 = Space::new();
          let mut v599_15_cursor = (v599_14).read_zipper();
          for v599_15_byte in v599_15_cursor.child_mask().iter() {
            v599_15_cursor.descend_to_byte(v599_15_byte);
            {
            let v599_15_tail = v599_15_cursor.fork_read_zipper();
            let v599_15_head = Path::from_slice(&[v599_15_byte]);
            let v603_2: Space = singleton(&(v599_15_head));
            let v603_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v603_2));
            let v603_4: Space = if map_kernels::has_head(&(v603_3)) { singleton(&[]) } else { Space::new() };
            drop(v603_3);
            let v603_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v603_4));
            drop(v603_4);
            let v603_7: Space = if (v603_5).is_empty() { Space::new() } else {
              let v604_6: Space = routine_8(c, &(v599_15_head), &(v599_15_tail).make_space());
              map_map_kernels::compose(&(v603_5),&(v604_6))
            };
            drop(v603_5);
            let v603_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v603_2));
            drop(v603_2);
            let v603_9: Space = if map_kernels::has_head(&(v603_8)) { singleton(&[]) } else { Space::new() };
            drop(v603_8);
            let v603_11: Space = if (v603_9).is_empty() { Space::new() } else {
              let v605_10: Space = routine_9(c, &(v599_15_head), &(v599_15_tail).make_space());
              map_map_kernels::compose(&(v603_9),&(v605_10))
            };
            drop(v603_9);
            let v603_12: Space = map_map_kernels::unite(&(v603_7),&(v603_11));
            v599_15.join_into((v603_12).clone());
            }
            v599_15_cursor.ascend(1);
          }
          drop(v599_15_cursor);
          let v599_16: Space = map_map_kernels::subtract(&(v599_15),&(v599_11));
          drop(v599_11);
          let v599_17: Space = map_map_kernels::intersect(&(v599_16),&(v581_24));
          map_map_kernels::compose(&(v594_10),&(v599_17))
        };
        drop(v594_10);
        let v606_6: Path = concat_path(&(v593_6),&(v593_12_head));
        let v594_19: Space = map_kernels::wrap(&(v594_18),&(v606_6));
        let v594_20: Space = map_map_kernels::unite(&(v594_8),&(v594_19));
        v593_12.join_into((v594_20).clone());
        }
        v593_12_cursor.ascend(1);
      }
      drop(v593_12_cursor);
      drop(v593_6);
      drop(v593_11);
      map_map_kernels::compose(&(v582_10),&(v593_12))
    };
    drop(v582_10);
    let v582_14: Space = map_map_kernels::unite(&(v582_8),&(v582_13));
    v581_34.join_into((v582_14).clone());
    }
    v581_34_cursor.ascend(1);
  }
  drop(v581_34_cursor);
  drop(v581_21);
  drop(v581_22);
  drop(v581_23);
  drop(v581_24);
  (v581_34).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v607_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v607_9: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_4));
  let v607_10: Space = map_kernels::unwrap(&(v607_9),&(*p0));
  let v607_12: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
  let mut v607_40 = Space::new();
  let mut v607_40_cursor = (*s0).read_zipper();
  for v607_40_byte in v607_40_cursor.child_mask().iter() {
    v607_40_cursor.descend_to_byte(v607_40_byte);
    {
    let v607_40_tail = v607_40_cursor.fork_read_zipper();
    let v607_40_head = Path::from_slice(&[v607_40_byte]);
    let v608_2: Space = singleton(&(v607_40_head));
    let v608_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v608_2));
    let v608_4: Space = if map_kernels::has_head(&(v608_3)) { singleton(&[]) } else { Space::new() };
    drop(v608_3);
    let v608_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v608_4));
    drop(v608_4);
    let v608_8: Space = if (v608_5).is_empty() { Space::new() } else {
      let v609_6: Path = concat_path(&(*p0),&(v607_40_head));
      let mut v609_7 = Space::new();
      let mut v609_7_cursor = (v607_40_tail).read_zipper();
      for v609_7_byte in v609_7_cursor.child_mask().iter() {
        v609_7_cursor.descend_to_byte(v609_7_byte);
        {
        let v609_7_tail = v609_7_cursor.fork_read_zipper();
        let v609_7_head = Path::from_slice(&[v609_7_byte]);
        let v610_2: Space = singleton(&(v609_7_head));
        let v610_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v610_2));
        let v610_4: Space = if map_kernels::has_head(&(v610_3)) { singleton(&[]) } else { Space::new() };
        drop(v610_3);
        let v610_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v610_4));
        drop(v610_4);
        let v610_8: Space = if (v610_5).is_empty() { Space::new() } else {
          let v611_6: Path = concat_path(&(v609_6),&(v609_7_head));
          let mut v611_7 = Space::new();
          let mut v611_7_cursor = (v609_7_tail).read_zipper();
          for v611_7_byte in v611_7_cursor.child_mask().iter() {
            v611_7_cursor.descend_to_byte(v611_7_byte);
            {
            let v611_7_tail = v611_7_cursor.fork_read_zipper();
            let v611_7_head = Path::from_slice(&[v611_7_byte]);
            let v612_2: Space = singleton(&(v611_7_head));
            let v612_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v612_2));
            let v612_4: Space = if map_kernels::has_head(&(v612_3)) { singleton(&[]) } else { Space::new() };
            drop(v612_3);
            let v612_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v612_4));
            drop(v612_4);
            let v612_8: Space = if (v612_5).is_empty() { Space::new() } else {
              let v613_6: Path = concat_path(&(v611_6),&(v611_7_head));
              let v613_7: Space = routine_48(c, &(v613_6), &(v611_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v612_5),&(v613_7))
            };
            drop(v612_5);
            let v612_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v612_2));
            drop(v612_2);
            let v612_10: Space = if map_kernels::has_head(&(v612_9)) { singleton(&[]) } else { Space::new() };
            drop(v612_9);
            let v612_12: Space = if (v612_10).is_empty() { Space::new() } else {
              let v614_6: Path = concat_path(&(v611_6),&(v611_7_head));
              let v614_11: Space = routine_49(c, &(v614_6), &(v611_7_tail).make_space(), &(*s1));
              drop(v614_6);
              map_map_kernels::compose(&(v612_10),&(v614_11))
            };
            drop(v612_10);
            let v612_13: Space = map_map_kernels::unite(&(v612_8),&(v612_12));
            v611_7.join_into((v612_13).clone());
            }
            v611_7_cursor.ascend(1);
          }
          drop(v611_7_cursor);
          map_map_kernels::compose(&(v610_5),&(v611_7))
        };
        drop(v610_5);
        let v610_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v610_2));
        drop(v610_2);
        let v610_10: Space = if map_kernels::has_head(&(v610_9)) { singleton(&[]) } else { Space::new() };
        drop(v610_9);
        let v610_12: Space = if (v610_10).is_empty() { Space::new() } else {
          let v615_6: Path = concat_path(&(v609_6),&(v609_7_head));
          let mut v615_11 = Space::new();
          let mut v615_11_cursor = (v609_7_tail).read_zipper();
          for v615_11_byte in v615_11_cursor.child_mask().iter() {
            v615_11_cursor.descend_to_byte(v615_11_byte);
            {
            let v615_11_tail = v615_11_cursor.fork_read_zipper();
            let v615_11_head = Path::from_slice(&[v615_11_byte]);
            let v616_2: Space = singleton(&(v615_11_head));
            let v616_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v616_2));
            let v616_4: Space = if map_kernels::has_head(&(v616_3)) { singleton(&[]) } else { Space::new() };
            drop(v616_3);
            let v616_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v616_4));
            drop(v616_4);
            let v616_8: Space = if (v616_5).is_empty() { Space::new() } else {
              let v617_6: Path = concat_path(&(v615_6),&(v615_11_head));
              let v617_7: Space = routine_48(c, &(v617_6), &(v615_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v616_5),&(v617_7))
            };
            drop(v616_5);
            let v616_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v616_2));
            drop(v616_2);
            let v616_10: Space = if map_kernels::has_head(&(v616_9)) { singleton(&[]) } else { Space::new() };
            drop(v616_9);
            let v616_12: Space = if (v616_10).is_empty() { Space::new() } else {
              let v618_6: Path = concat_path(&(v615_6),&(v615_11_head));
              let v618_11: Space = routine_3(c, &(v618_6), &(v615_11_tail).make_space(), &(*s1));
              drop(v618_6);
              map_map_kernels::compose(&(v616_10),&(v618_11))
            };
            drop(v616_10);
            let v616_13: Space = map_map_kernels::unite(&(v616_8),&(v616_12));
            v615_11.join_into((v616_13).clone());
            }
            v615_11_cursor.ascend(1);
          }
          drop(v615_11_cursor);
          drop(v615_6);
          map_map_kernels::compose(&(v610_10),&(v615_11))
        };
        drop(v610_10);
        let v610_13: Space = map_map_kernels::unite(&(v610_8),&(v610_12));
        v609_7.join_into((v610_13).clone());
        }
        v609_7_cursor.ascend(1);
      }
      drop(v609_7_cursor);
      map_map_kernels::compose(&(v608_5),&(v609_7))
    };
    drop(v608_5);
    let v608_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v608_2));
    drop(v608_2);
    let v608_10: Space = if map_kernels::has_head(&(v608_9)) { singleton(&[]) } else { Space::new() };
    drop(v608_9);
    let v608_18: Space = if (v608_10).is_empty() { Space::new() } else {
      let v619_11: Space = map_kernels::unwrap(&(v607_10),&(v607_40_head));
      let v619_12: Space = map_map_kernels::restrict_to(&(v607_9),&(v619_11));
      let mut v619_13 = Space::new();
      let mut v619_13_cursor = (v619_12).read_zipper();
      for v619_13_byte in v619_13_cursor.child_mask().iter() {
        v619_13_cursor.descend_to_byte(v619_13_byte);
        {
        let v619_13_tail = v619_13_cursor.fork_read_zipper();
        let v619_13_head = Path::from_slice(&[v619_13_byte]);
        let v620_2: Space = singleton(&(v619_13_head));
        let v620_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v620_2));
        let v620_4: Space = if map_kernels::has_head(&(v620_3)) { singleton(&[]) } else { Space::new() };
        drop(v620_3);
        let v620_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v620_4));
        drop(v620_4);
        let v620_7: Space = if (v620_5).is_empty() { Space::new() } else {
          let mut v621_6 = Space::new();
          let mut v621_6_cursor = (v619_13_tail).read_zipper();
          for v621_6_byte in v621_6_cursor.child_mask().iter() {
            v621_6_cursor.descend_to_byte(v621_6_byte);
            {
            let v621_6_tail = v621_6_cursor.fork_read_zipper();
            let v621_6_head = Path::from_slice(&[v621_6_byte]);
            let v622_2: Space = singleton(&(v621_6_head));
            let v622_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v622_2));
            let v622_4: Space = if map_kernels::has_head(&(v622_3)) { singleton(&[]) } else { Space::new() };
            drop(v622_3);
            let v622_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v622_4));
            drop(v622_4);
            let v622_8: Space = if (v622_5).is_empty() { Space::new() } else {
              let v623_6: Path = concat_path(&(v619_13_head),&(v621_6_head));
              let v623_7: Space = routine_10(c, &(v623_6), &(v621_6_tail).make_space());
              map_map_kernels::compose(&(v622_5),&(v623_7))
            };
            drop(v622_5);
            let v622_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v622_2));
            drop(v622_2);
            let v622_10: Space = if map_kernels::has_head(&(v622_9)) { singleton(&[]) } else { Space::new() };
            drop(v622_9);
            let v622_12: Space = if (v622_10).is_empty() { Space::new() } else {
              let v624_6: Path = concat_path(&(v619_13_head),&(v621_6_head));
              let v624_11: Space = routine_11(c, &(v624_6), &(v621_6_tail).make_space());
              drop(v624_6);
              map_map_kernels::compose(&(v622_10),&(v624_11))
            };
            drop(v622_10);
            let v622_13: Space = map_map_kernels::unite(&(v622_8),&(v622_12));
            v621_6.join_into((v622_13).clone());
            }
            v621_6_cursor.ascend(1);
          }
          drop(v621_6_cursor);
          map_map_kernels::compose(&(v620_5),&(v621_6))
        };
        drop(v620_5);
        let v620_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v620_2));
        drop(v620_2);
        let v620_9: Space = if map_kernels::has_head(&(v620_8)) { singleton(&[]) } else { Space::new() };
        drop(v620_8);
        let v620_11: Space = if (v620_9).is_empty() { Space::new() } else {
          let mut v625_10 = Space::new();
          let mut v625_10_cursor = (v619_13_tail).read_zipper();
          for v625_10_byte in v625_10_cursor.child_mask().iter() {
            v625_10_cursor.descend_to_byte(v625_10_byte);
            {
            let v625_10_tail = v625_10_cursor.fork_read_zipper();
            let v625_10_head = Path::from_slice(&[v625_10_byte]);
            let v626_2: Space = singleton(&(v625_10_head));
            let v626_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v626_2));
            let v626_4: Space = if map_kernels::has_head(&(v626_3)) { singleton(&[]) } else { Space::new() };
            drop(v626_3);
            let v626_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v626_4));
            drop(v626_4);
            let v626_8: Space = if (v626_5).is_empty() { Space::new() } else {
              let v627_6: Path = concat_path(&(v619_13_head),&(v625_10_head));
              let v627_7: Space = routine_10(c, &(v627_6), &(v625_10_tail).make_space());
              map_map_kernels::compose(&(v626_5),&(v627_7))
            };
            drop(v626_5);
            let v626_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v626_2));
            drop(v626_2);
            let v626_10: Space = if map_kernels::has_head(&(v626_9)) { singleton(&[]) } else { Space::new() };
            drop(v626_9);
            let v626_12: Space = if (v626_10).is_empty() { Space::new() } else {
              let v628_6: Path = concat_path(&(v619_13_head),&(v625_10_head));
              let v628_11: Space = routine_12(c, &(v628_6), &(v625_10_tail).make_space());
              drop(v628_6);
              map_map_kernels::compose(&(v626_10),&(v628_11))
            };
            drop(v626_10);
            let v626_13: Space = map_map_kernels::unite(&(v626_8),&(v626_12));
            v625_10.join_into((v626_13).clone());
            }
            v625_10_cursor.ascend(1);
          }
          drop(v625_10_cursor);
          map_map_kernels::compose(&(v620_9),&(v625_10))
        };
        drop(v620_9);
        let v620_12: Space = map_map_kernels::unite(&(v620_7),&(v620_11));
        v619_13.join_into((v620_12).clone());
        }
        v619_13_cursor.ascend(1);
      }
      drop(v619_13_cursor);
      drop(v619_12);
      let v619_14: Space = map_map_kernels::restrict_to(&(v607_7),&(v619_13));
      let mut v619_15 = Space::new();
      let mut v619_15_cursor = (v619_14).read_zipper();
      for v619_15_byte in v619_15_cursor.child_mask().iter() {
        v619_15_cursor.descend_to_byte(v619_15_byte);
        {
        let v619_15_tail = v619_15_cursor.fork_read_zipper();
        let v619_15_head = Path::from_slice(&[v619_15_byte]);
        let v629_2: Space = singleton(&(v619_15_head));
        let v629_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v629_2));
        let v629_4: Space = if map_kernels::has_head(&(v629_3)) { singleton(&[]) } else { Space::new() };
        drop(v629_3);
        let v629_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v629_4));
        drop(v629_4);
        let v629_7: Space = if (v629_5).is_empty() { Space::new() } else {
          let mut v630_6 = Space::new();
          let mut v630_6_cursor = (v619_15_tail).read_zipper();
          for v630_6_byte in v630_6_cursor.child_mask().iter() {
            v630_6_cursor.descend_to_byte(v630_6_byte);
            {
            let v630_6_tail = v630_6_cursor.fork_read_zipper();
            let v630_6_head = Path::from_slice(&[v630_6_byte]);
            let v631_2: Space = singleton(&(v630_6_head));
            let v631_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v631_2));
            let v631_4: Space = if map_kernels::has_head(&(v631_3)) { singleton(&[]) } else { Space::new() };
            drop(v631_3);
            let v631_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v631_4));
            drop(v631_4);
            let v631_8: Space = if (v631_5).is_empty() { Space::new() } else {
              let v632_6: Path = concat_path(&(v619_15_head),&(v630_6_head));
              let v632_7: Space = routine_13(c, &(v632_6), &(v630_6_tail).make_space());
              map_map_kernels::compose(&(v631_5),&(v632_7))
            };
            drop(v631_5);
            let v631_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v631_2));
            drop(v631_2);
            let v631_10: Space = if map_kernels::has_head(&(v631_9)) { singleton(&[]) } else { Space::new() };
            drop(v631_9);
            let v631_12: Space = if (v631_10).is_empty() { Space::new() } else {
              let v633_6: Path = concat_path(&(v619_15_head),&(v630_6_head));
              let v633_11: Space = routine_14(c, &(v633_6), &(v630_6_tail).make_space());
              drop(v633_6);
              map_map_kernels::compose(&(v631_10),&(v633_11))
            };
            drop(v631_10);
            let v631_13: Space = map_map_kernels::unite(&(v631_8),&(v631_12));
            v630_6.join_into((v631_13).clone());
            }
            v630_6_cursor.ascend(1);
          }
          drop(v630_6_cursor);
          map_map_kernels::compose(&(v629_5),&(v630_6))
        };
        drop(v629_5);
        let v629_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v629_2));
        drop(v629_2);
        let v629_9: Space = if map_kernels::has_head(&(v629_8)) { singleton(&[]) } else { Space::new() };
        drop(v629_8);
        let v629_11: Space = if (v629_9).is_empty() { Space::new() } else {
          let mut v634_10 = Space::new();
          let mut v634_10_cursor = (v619_15_tail).read_zipper();
          for v634_10_byte in v634_10_cursor.child_mask().iter() {
            v634_10_cursor.descend_to_byte(v634_10_byte);
            {
            let v634_10_tail = v634_10_cursor.fork_read_zipper();
            let v634_10_head = Path::from_slice(&[v634_10_byte]);
            let v635_2: Space = singleton(&(v634_10_head));
            let v635_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v635_2));
            let v635_4: Space = if map_kernels::has_head(&(v635_3)) { singleton(&[]) } else { Space::new() };
            drop(v635_3);
            let v635_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v635_4));
            drop(v635_4);
            let v635_8: Space = if (v635_5).is_empty() { Space::new() } else {
              let v636_6: Path = concat_path(&(v619_15_head),&(v634_10_head));
              let v636_7: Space = routine_13(c, &(v636_6), &(v634_10_tail).make_space());
              map_map_kernels::compose(&(v635_5),&(v636_7))
            };
            drop(v635_5);
            let v635_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v635_2));
            drop(v635_2);
            let v635_10: Space = if map_kernels::has_head(&(v635_9)) { singleton(&[]) } else { Space::new() };
            drop(v635_9);
            let v635_12: Space = if (v635_10).is_empty() { Space::new() } else {
              let v637_6: Path = concat_path(&(v619_15_head),&(v634_10_head));
              let v637_11: Space = routine_15(c, &(v637_6), &(v634_10_tail).make_space());
              drop(v637_6);
              map_map_kernels::compose(&(v635_10),&(v637_11))
            };
            drop(v635_10);
            let v635_13: Space = map_map_kernels::unite(&(v635_8),&(v635_12));
            v634_10.join_into((v635_13).clone());
            }
            v634_10_cursor.ascend(1);
          }
          drop(v634_10_cursor);
          map_map_kernels::compose(&(v629_9),&(v634_10))
        };
        drop(v629_9);
        let v629_12: Space = map_map_kernels::unite(&(v629_7),&(v629_11));
        v619_15.join_into((v629_12).clone());
        }
        v619_15_cursor.ascend(1);
      }
      drop(v619_15_cursor);
      let v619_16: Space = map_map_kernels::subtract(&(v619_15),&(v619_11));
      drop(v619_11);
      let v619_17: Space = map_map_kernels::intersect(&(v619_16),&(v607_12));
      map_map_kernels::compose(&(v608_10),&(v619_17))
    };
    drop(v608_10);
    let v638_6: Path = concat_path(&(*p0),&(v607_40_head));
    let v608_19: Space = map_kernels::wrap(&(v608_18),&(v638_6));
    let v608_20: Space = map_map_kernels::unite(&(v608_8),&(v608_19));
    v607_40.join_into((v608_20).clone());
    }
    v607_40_cursor.ascend(1);
  }
  drop(v607_40_cursor);
  drop(v607_7);
  drop(v607_9);
  drop(v607_10);
  drop(v607_12);
  (v607_40).clone()
}

fn routine_36(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v639_20 = Space::new();
  let mut v639_20_cursor = (*s0).read_zipper();
  for v639_20_byte in v639_20_cursor.child_mask().iter() {
    v639_20_cursor.descend_to_byte(v639_20_byte);
    {
    let v639_20_tail = v639_20_cursor.fork_read_zipper();
    let v639_20_head = Path::from_slice(&[v639_20_byte]);
    let v640_2: Space = singleton(&(v639_20_head));
    let v640_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v640_2));
    let v640_4: Space = if map_kernels::has_head(&(v640_3)) { singleton(&[]) } else { Space::new() };
    drop(v640_3);
    let v640_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v640_4));
    drop(v640_4);
    let v640_8: Space = if (v640_5).is_empty() { Space::new() } else {
      let v641_6: Path = concat_path(&(*p0),&(v639_20_head));
      let mut v641_7 = Space::new();
      let mut v641_7_cursor = (v639_20_tail).read_zipper();
      for v641_7_byte in v641_7_cursor.child_mask().iter() {
        v641_7_cursor.descend_to_byte(v641_7_byte);
        {
        let v641_7_tail = v641_7_cursor.fork_read_zipper();
        let v641_7_head = Path::from_slice(&[v641_7_byte]);
        let v642_2: Space = singleton(&(v641_7_head));
        let v642_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v642_2));
        let v642_4: Space = if map_kernels::has_head(&(v642_3)) { singleton(&[]) } else { Space::new() };
        drop(v642_3);
        let v642_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v642_4));
        drop(v642_4);
        let v642_8: Space = if (v642_5).is_empty() { Space::new() } else {
          let v643_6: Path = concat_path(&(v641_6),&(v641_7_head));
          let mut v643_7 = Space::new();
          let mut v643_7_cursor = (v641_7_tail).read_zipper();
          for v643_7_byte in v643_7_cursor.child_mask().iter() {
            v643_7_cursor.descend_to_byte(v643_7_byte);
            {
            let v643_7_tail = v643_7_cursor.fork_read_zipper();
            let v643_7_head = Path::from_slice(&[v643_7_byte]);
            let v644_2: Space = singleton(&(v643_7_head));
            let v644_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v644_2));
            let v644_4: Space = if map_kernels::has_head(&(v644_3)) { singleton(&[]) } else { Space::new() };
            drop(v644_3);
            let v644_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v644_4));
            drop(v644_4);
            let v644_8: Space = if (v644_5).is_empty() { Space::new() } else {
              let v645_6: Path = concat_path(&(v643_6),&(v643_7_head));
              let v645_7: Space = routine_50(c, &(v645_6), &(v643_7_tail).make_space());
              map_map_kernels::compose(&(v644_5),&(v645_7))
            };
            drop(v644_5);
            let v644_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v644_2));
            drop(v644_2);
            let v644_10: Space = if map_kernels::has_head(&(v644_9)) { singleton(&[]) } else { Space::new() };
            drop(v644_9);
            let v644_12: Space = if (v644_10).is_empty() { Space::new() } else {
              let v646_6: Path = concat_path(&(v643_6),&(v643_7_head));
              let v646_11: Space = routine_51(c, &(v646_6), &(v643_7_tail).make_space());
              drop(v646_6);
              map_map_kernels::compose(&(v644_10),&(v646_11))
            };
            drop(v644_10);
            let v644_13: Space = map_map_kernels::unite(&(v644_8),&(v644_12));
            v643_7.join_into((v644_13).clone());
            }
            v643_7_cursor.ascend(1);
          }
          drop(v643_7_cursor);
          map_map_kernels::compose(&(v642_5),&(v643_7))
        };
        drop(v642_5);
        let v642_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v642_2));
        drop(v642_2);
        let v642_10: Space = if map_kernels::has_head(&(v642_9)) { singleton(&[]) } else { Space::new() };
        drop(v642_9);
        let v642_12: Space = if (v642_10).is_empty() { Space::new() } else {
          let v647_6: Path = concat_path(&(v641_6),&(v641_7_head));
          let mut v647_11 = Space::new();
          let mut v647_11_cursor = (v641_7_tail).read_zipper();
          for v647_11_byte in v647_11_cursor.child_mask().iter() {
            v647_11_cursor.descend_to_byte(v647_11_byte);
            {
            let v647_11_tail = v647_11_cursor.fork_read_zipper();
            let v647_11_head = Path::from_slice(&[v647_11_byte]);
            let v648_2: Space = singleton(&(v647_11_head));
            let v648_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v648_2));
            let v648_4: Space = if map_kernels::has_head(&(v648_3)) { singleton(&[]) } else { Space::new() };
            drop(v648_3);
            let v648_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v648_4));
            drop(v648_4);
            let v648_8: Space = if (v648_5).is_empty() { Space::new() } else {
              let v649_6: Path = concat_path(&(v647_6),&(v647_11_head));
              let v649_7: Space = routine_50(c, &(v649_6), &(v647_11_tail).make_space());
              map_map_kernels::compose(&(v648_5),&(v649_7))
            };
            drop(v648_5);
            let v648_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v648_2));
            drop(v648_2);
            let v648_10: Space = if map_kernels::has_head(&(v648_9)) { singleton(&[]) } else { Space::new() };
            drop(v648_9);
            let v648_12: Space = if (v648_10).is_empty() { Space::new() } else {
              let v650_6: Path = concat_path(&(v647_6),&(v647_11_head));
              let v650_11: Space = routine_12(c, &(v650_6), &(v647_11_tail).make_space());
              drop(v650_6);
              map_map_kernels::compose(&(v648_10),&(v650_11))
            };
            drop(v648_10);
            let v648_13: Space = map_map_kernels::unite(&(v648_8),&(v648_12));
            v647_11.join_into((v648_13).clone());
            }
            v647_11_cursor.ascend(1);
          }
          drop(v647_11_cursor);
          drop(v647_6);
          map_map_kernels::compose(&(v642_10),&(v647_11))
        };
        drop(v642_10);
        let v642_13: Space = map_map_kernels::unite(&(v642_8),&(v642_12));
        v641_7.join_into((v642_13).clone());
        }
        v641_7_cursor.ascend(1);
      }
      drop(v641_7_cursor);
      map_map_kernels::compose(&(v640_5),&(v641_7))
    };
    drop(v640_5);
    let v640_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v640_2));
    drop(v640_2);
    let v640_10: Space = if map_kernels::has_head(&(v640_9)) { singleton(&[]) } else { Space::new() };
    drop(v640_9);
    let v640_12: Space = if (v640_10).is_empty() { Space::new() } else {
      let v651_6: Path = concat_path(&(*p0),&(v639_20_head));
      let mut v651_11 = Space::new();
      let mut v651_11_cursor = (v639_20_tail).read_zipper();
      for v651_11_byte in v651_11_cursor.child_mask().iter() {
        v651_11_cursor.descend_to_byte(v651_11_byte);
        {
        let v651_11_tail = v651_11_cursor.fork_read_zipper();
        let v651_11_head = Path::from_slice(&[v651_11_byte]);
        let v652_2: Space = singleton(&(v651_11_head));
        let v652_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v652_2));
        let v652_4: Space = if map_kernels::has_head(&(v652_3)) { singleton(&[]) } else { Space::new() };
        drop(v652_3);
        let v652_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v652_4));
        drop(v652_4);
        let v652_8: Space = if (v652_5).is_empty() { Space::new() } else {
          let v653_6: Path = concat_path(&(v651_6),&(v651_11_head));
          let mut v653_7 = Space::new();
          let mut v653_7_cursor = (v651_11_tail).read_zipper();
          for v653_7_byte in v653_7_cursor.child_mask().iter() {
            v653_7_cursor.descend_to_byte(v653_7_byte);
            {
            let v653_7_tail = v653_7_cursor.fork_read_zipper();
            let v653_7_head = Path::from_slice(&[v653_7_byte]);
            let v654_2: Space = singleton(&(v653_7_head));
            let v654_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v654_2));
            let v654_4: Space = if map_kernels::has_head(&(v654_3)) { singleton(&[]) } else { Space::new() };
            drop(v654_3);
            let v654_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v654_4));
            drop(v654_4);
            let v654_8: Space = if (v654_5).is_empty() { Space::new() } else {
              let v655_6: Path = concat_path(&(v653_6),&(v653_7_head));
              let v655_7: Space = routine_50(c, &(v655_6), &(v653_7_tail).make_space());
              map_map_kernels::compose(&(v654_5),&(v655_7))
            };
            drop(v654_5);
            let v654_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v654_2));
            drop(v654_2);
            let v654_10: Space = if map_kernels::has_head(&(v654_9)) { singleton(&[]) } else { Space::new() };
            drop(v654_9);
            let v654_12: Space = if (v654_10).is_empty() { Space::new() } else {
              let v656_6: Path = concat_path(&(v653_6),&(v653_7_head));
              let v656_11: Space = routine_51(c, &(v656_6), &(v653_7_tail).make_space());
              drop(v656_6);
              map_map_kernels::compose(&(v654_10),&(v656_11))
            };
            drop(v654_10);
            let v654_13: Space = map_map_kernels::unite(&(v654_8),&(v654_12));
            v653_7.join_into((v654_13).clone());
            }
            v653_7_cursor.ascend(1);
          }
          drop(v653_7_cursor);
          drop(v653_6);
          map_map_kernels::compose(&(v652_5),&(v653_7))
        };
        drop(v652_5);
        let v652_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v652_2));
        drop(v652_2);
        let v652_10: Space = if map_kernels::has_head(&(v652_9)) { singleton(&[]) } else { Space::new() };
        drop(v652_9);
        let v652_11: Space = map_view_kernels::compose(&(v652_10),&(v651_11_tail));
        drop(v652_10);
        let v652_12: Space = map_map_kernels::unite(&(v652_8),&(v652_11));
        drop(v652_11);
        v651_11.join_into((v652_12).clone());
        }
        v651_11_cursor.ascend(1);
      }
      drop(v651_11_cursor);
      drop(v651_6);
      map_map_kernels::compose(&(v640_10),&(v651_11))
    };
    drop(v640_10);
    let v640_13: Space = map_map_kernels::unite(&(v640_8),&(v640_12));
    v639_20.join_into((v640_13).clone());
    }
    v639_20_cursor.ascend(1);
  }
  drop(v639_20_cursor);
  (v639_20).clone()
}

fn routine_37(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v657_14 = Space::new();
  let mut v657_14_cursor = (*s0).read_zipper();
  for v657_14_byte in v657_14_cursor.child_mask().iter() {
    v657_14_cursor.descend_to_byte(v657_14_byte);
    {
    let v657_14_tail = v657_14_cursor.fork_read_zipper();
    let v657_14_head = Path::from_slice(&[v657_14_byte]);
    let v658_2: Space = singleton(&(v657_14_head));
    let v658_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v658_2));
    let v658_4: Space = if map_kernels::has_head(&(v658_3)) { singleton(&[]) } else { Space::new() };
    drop(v658_3);
    let v658_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v658_4));
    drop(v658_4);
    let v658_8: Space = if (v658_5).is_empty() { Space::new() } else {
      let v659_6: Path = concat_path(&(*p0),&(v657_14_head));
      let mut v659_7 = Space::new();
      let mut v659_7_cursor = (v657_14_tail).read_zipper();
      for v659_7_byte in v659_7_cursor.child_mask().iter() {
        v659_7_cursor.descend_to_byte(v659_7_byte);
        {
        let v659_7_tail = v659_7_cursor.fork_read_zipper();
        let v659_7_head = Path::from_slice(&[v659_7_byte]);
        let v660_2: Space = singleton(&(v659_7_head));
        let v660_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v660_2));
        let v660_4: Space = if map_kernels::has_head(&(v660_3)) { singleton(&[]) } else { Space::new() };
        drop(v660_3);
        let v660_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v660_4));
        drop(v660_4);
        let v660_8: Space = if (v660_5).is_empty() { Space::new() } else {
          let v661_6: Path = concat_path(&(v659_6),&(v659_7_head));
          let mut v661_7 = Space::new();
          let mut v661_7_cursor = (v659_7_tail).read_zipper();
          for v661_7_byte in v661_7_cursor.child_mask().iter() {
            v661_7_cursor.descend_to_byte(v661_7_byte);
            {
            let v661_7_tail = v661_7_cursor.fork_read_zipper();
            let v661_7_head = Path::from_slice(&[v661_7_byte]);
            let v662_2: Space = singleton(&(v661_7_head));
            let v662_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v662_2));
            let v662_4: Space = if map_kernels::has_head(&(v662_3)) { singleton(&[]) } else { Space::new() };
            drop(v662_3);
            let v662_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v662_4));
            drop(v662_4);
            let v662_8: Space = if (v662_5).is_empty() { Space::new() } else {
              let v663_6: Path = concat_path(&(v661_6),&(v661_7_head));
              let v663_7: Space = routine_50(c, &(v663_6), &(v661_7_tail).make_space());
              map_map_kernels::compose(&(v662_5),&(v663_7))
            };
            drop(v662_5);
            let v662_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v662_2));
            drop(v662_2);
            let v662_10: Space = if map_kernels::has_head(&(v662_9)) { singleton(&[]) } else { Space::new() };
            drop(v662_9);
            let v662_12: Space = if (v662_10).is_empty() { Space::new() } else {
              let v664_6: Path = concat_path(&(v661_6),&(v661_7_head));
              let v664_11: Space = routine_51(c, &(v664_6), &(v661_7_tail).make_space());
              drop(v664_6);
              map_map_kernels::compose(&(v662_10),&(v664_11))
            };
            drop(v662_10);
            let v662_13: Space = map_map_kernels::unite(&(v662_8),&(v662_12));
            v661_7.join_into((v662_13).clone());
            }
            v661_7_cursor.ascend(1);
          }
          drop(v661_7_cursor);
          map_map_kernels::compose(&(v660_5),&(v661_7))
        };
        drop(v660_5);
        let v660_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v660_2));
        drop(v660_2);
        let v660_10: Space = if map_kernels::has_head(&(v660_9)) { singleton(&[]) } else { Space::new() };
        drop(v660_9);
        let v660_12: Space = if (v660_10).is_empty() { Space::new() } else {
          let v665_6: Path = concat_path(&(v659_6),&(v659_7_head));
          let mut v665_11 = Space::new();
          let mut v665_11_cursor = (v659_7_tail).read_zipper();
          for v665_11_byte in v665_11_cursor.child_mask().iter() {
            v665_11_cursor.descend_to_byte(v665_11_byte);
            {
            let v665_11_tail = v665_11_cursor.fork_read_zipper();
            let v665_11_head = Path::from_slice(&[v665_11_byte]);
            let v666_2: Space = singleton(&(v665_11_head));
            let v666_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v666_2));
            let v666_4: Space = if map_kernels::has_head(&(v666_3)) { singleton(&[]) } else { Space::new() };
            drop(v666_3);
            let v666_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v666_4));
            drop(v666_4);
            let v666_8: Space = if (v666_5).is_empty() { Space::new() } else {
              let v667_6: Path = concat_path(&(v665_6),&(v665_11_head));
              let v667_7: Space = routine_50(c, &(v667_6), &(v665_11_tail).make_space());
              map_map_kernels::compose(&(v666_5),&(v667_7))
            };
            drop(v666_5);
            let v666_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v666_2));
            drop(v666_2);
            let v666_10: Space = if map_kernels::has_head(&(v666_9)) { singleton(&[]) } else { Space::new() };
            drop(v666_9);
            let v666_12: Space = if (v666_10).is_empty() { Space::new() } else {
              let v668_6: Path = concat_path(&(v665_6),&(v665_11_head));
              let v668_11: Space = routine_12(c, &(v668_6), &(v665_11_tail).make_space());
              drop(v668_6);
              map_map_kernels::compose(&(v666_10),&(v668_11))
            };
            drop(v666_10);
            let v666_13: Space = map_map_kernels::unite(&(v666_8),&(v666_12));
            v665_11.join_into((v666_13).clone());
            }
            v665_11_cursor.ascend(1);
          }
          drop(v665_11_cursor);
          drop(v665_6);
          map_map_kernels::compose(&(v660_10),&(v665_11))
        };
        drop(v660_10);
        let v660_13: Space = map_map_kernels::unite(&(v660_8),&(v660_12));
        v659_7.join_into((v660_13).clone());
        }
        v659_7_cursor.ascend(1);
      }
      drop(v659_7_cursor);
      drop(v659_6);
      map_map_kernels::compose(&(v658_5),&(v659_7))
    };
    drop(v658_5);
    let v658_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v658_2));
    drop(v658_2);
    let v658_10: Space = if map_kernels::has_head(&(v658_9)) { singleton(&[]) } else { Space::new() };
    drop(v658_9);
    let v658_11: Space = map_view_kernels::compose(&(v658_10),&(v657_14_tail));
    drop(v658_10);
    let v658_12: Space = map_map_kernels::unite(&(v658_8),&(v658_11));
    drop(v658_11);
    v657_14.join_into((v658_12).clone());
    }
    v657_14_cursor.ascend(1);
  }
  drop(v657_14_cursor);
  (v657_14).clone()
}

fn routine_38(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v669_20 = Space::new();
  let mut v669_20_cursor = (*s0).read_zipper();
  for v669_20_byte in v669_20_cursor.child_mask().iter() {
    v669_20_cursor.descend_to_byte(v669_20_byte);
    {
    let v669_20_tail = v669_20_cursor.fork_read_zipper();
    let v669_20_head = Path::from_slice(&[v669_20_byte]);
    let v670_2: Space = singleton(&(v669_20_head));
    let v670_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v670_2));
    let v670_4: Space = if map_kernels::has_head(&(v670_3)) { singleton(&[]) } else { Space::new() };
    drop(v670_3);
    let v670_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v670_4));
    drop(v670_4);
    let v670_8: Space = if (v670_5).is_empty() { Space::new() } else {
      let v671_6: Path = concat_path(&(*p0),&(v669_20_head));
      let mut v671_7 = Space::new();
      let mut v671_7_cursor = (v669_20_tail).read_zipper();
      for v671_7_byte in v671_7_cursor.child_mask().iter() {
        v671_7_cursor.descend_to_byte(v671_7_byte);
        {
        let v671_7_tail = v671_7_cursor.fork_read_zipper();
        let v671_7_head = Path::from_slice(&[v671_7_byte]);
        let v672_2: Space = singleton(&(v671_7_head));
        let v672_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v672_2));
        let v672_4: Space = if map_kernels::has_head(&(v672_3)) { singleton(&[]) } else { Space::new() };
        drop(v672_3);
        let v672_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v672_4));
        drop(v672_4);
        let v672_8: Space = if (v672_5).is_empty() { Space::new() } else {
          let v673_6: Path = concat_path(&(v671_6),&(v671_7_head));
          let mut v673_7 = Space::new();
          let mut v673_7_cursor = (v671_7_tail).read_zipper();
          for v673_7_byte in v673_7_cursor.child_mask().iter() {
            v673_7_cursor.descend_to_byte(v673_7_byte);
            {
            let v673_7_tail = v673_7_cursor.fork_read_zipper();
            let v673_7_head = Path::from_slice(&[v673_7_byte]);
            let v674_2: Space = singleton(&(v673_7_head));
            let v674_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v674_2));
            let v674_4: Space = if map_kernels::has_head(&(v674_3)) { singleton(&[]) } else { Space::new() };
            drop(v674_3);
            let v674_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v674_4));
            drop(v674_4);
            let v674_8: Space = if (v674_5).is_empty() { Space::new() } else {
              let v675_6: Path = concat_path(&(v673_6),&(v673_7_head));
              let v675_7: Space = routine_52(c, &(v675_6), &(v673_7_tail).make_space());
              map_map_kernels::compose(&(v674_5),&(v675_7))
            };
            drop(v674_5);
            let v674_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v674_2));
            drop(v674_2);
            let v674_10: Space = if map_kernels::has_head(&(v674_9)) { singleton(&[]) } else { Space::new() };
            drop(v674_9);
            let v674_12: Space = if (v674_10).is_empty() { Space::new() } else {
              let v676_6: Path = concat_path(&(v673_6),&(v673_7_head));
              let v676_11: Space = routine_53(c, &(v676_6), &(v673_7_tail).make_space());
              drop(v676_6);
              map_map_kernels::compose(&(v674_10),&(v676_11))
            };
            drop(v674_10);
            let v674_13: Space = map_map_kernels::unite(&(v674_8),&(v674_12));
            v673_7.join_into((v674_13).clone());
            }
            v673_7_cursor.ascend(1);
          }
          drop(v673_7_cursor);
          map_map_kernels::compose(&(v672_5),&(v673_7))
        };
        drop(v672_5);
        let v672_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v672_2));
        drop(v672_2);
        let v672_10: Space = if map_kernels::has_head(&(v672_9)) { singleton(&[]) } else { Space::new() };
        drop(v672_9);
        let v672_12: Space = if (v672_10).is_empty() { Space::new() } else {
          let v677_6: Path = concat_path(&(v671_6),&(v671_7_head));
          let mut v677_11 = Space::new();
          let mut v677_11_cursor = (v671_7_tail).read_zipper();
          for v677_11_byte in v677_11_cursor.child_mask().iter() {
            v677_11_cursor.descend_to_byte(v677_11_byte);
            {
            let v677_11_tail = v677_11_cursor.fork_read_zipper();
            let v677_11_head = Path::from_slice(&[v677_11_byte]);
            let v678_2: Space = singleton(&(v677_11_head));
            let v678_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v678_2));
            let v678_4: Space = if map_kernels::has_head(&(v678_3)) { singleton(&[]) } else { Space::new() };
            drop(v678_3);
            let v678_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v678_4));
            drop(v678_4);
            let v678_8: Space = if (v678_5).is_empty() { Space::new() } else {
              let v679_6: Path = concat_path(&(v677_6),&(v677_11_head));
              let v679_7: Space = routine_52(c, &(v679_6), &(v677_11_tail).make_space());
              map_map_kernels::compose(&(v678_5),&(v679_7))
            };
            drop(v678_5);
            let v678_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v678_2));
            drop(v678_2);
            let v678_10: Space = if map_kernels::has_head(&(v678_9)) { singleton(&[]) } else { Space::new() };
            drop(v678_9);
            let v678_12: Space = if (v678_10).is_empty() { Space::new() } else {
              let v680_6: Path = concat_path(&(v677_6),&(v677_11_head));
              let v680_11: Space = routine_15(c, &(v680_6), &(v677_11_tail).make_space());
              drop(v680_6);
              map_map_kernels::compose(&(v678_10),&(v680_11))
            };
            drop(v678_10);
            let v678_13: Space = map_map_kernels::unite(&(v678_8),&(v678_12));
            v677_11.join_into((v678_13).clone());
            }
            v677_11_cursor.ascend(1);
          }
          drop(v677_11_cursor);
          drop(v677_6);
          map_map_kernels::compose(&(v672_10),&(v677_11))
        };
        drop(v672_10);
        let v672_13: Space = map_map_kernels::unite(&(v672_8),&(v672_12));
        v671_7.join_into((v672_13).clone());
        }
        v671_7_cursor.ascend(1);
      }
      drop(v671_7_cursor);
      map_map_kernels::compose(&(v670_5),&(v671_7))
    };
    drop(v670_5);
    let v670_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v670_2));
    drop(v670_2);
    let v670_10: Space = if map_kernels::has_head(&(v670_9)) { singleton(&[]) } else { Space::new() };
    drop(v670_9);
    let v670_12: Space = if (v670_10).is_empty() { Space::new() } else {
      let v681_6: Path = concat_path(&(*p0),&(v669_20_head));
      let mut v681_11 = Space::new();
      let mut v681_11_cursor = (v669_20_tail).read_zipper();
      for v681_11_byte in v681_11_cursor.child_mask().iter() {
        v681_11_cursor.descend_to_byte(v681_11_byte);
        {
        let v681_11_tail = v681_11_cursor.fork_read_zipper();
        let v681_11_head = Path::from_slice(&[v681_11_byte]);
        let v682_2: Space = singleton(&(v681_11_head));
        let v682_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v682_2));
        let v682_4: Space = if map_kernels::has_head(&(v682_3)) { singleton(&[]) } else { Space::new() };
        drop(v682_3);
        let v682_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v682_4));
        drop(v682_4);
        let v682_8: Space = if (v682_5).is_empty() { Space::new() } else {
          let v683_6: Path = concat_path(&(v681_6),&(v681_11_head));
          let mut v683_7 = Space::new();
          let mut v683_7_cursor = (v681_11_tail).read_zipper();
          for v683_7_byte in v683_7_cursor.child_mask().iter() {
            v683_7_cursor.descend_to_byte(v683_7_byte);
            {
            let v683_7_tail = v683_7_cursor.fork_read_zipper();
            let v683_7_head = Path::from_slice(&[v683_7_byte]);
            let v684_2: Space = singleton(&(v683_7_head));
            let v684_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v684_2));
            let v684_4: Space = if map_kernels::has_head(&(v684_3)) { singleton(&[]) } else { Space::new() };
            drop(v684_3);
            let v684_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v684_4));
            drop(v684_4);
            let v684_8: Space = if (v684_5).is_empty() { Space::new() } else {
              let v685_6: Path = concat_path(&(v683_6),&(v683_7_head));
              let v685_7: Space = routine_52(c, &(v685_6), &(v683_7_tail).make_space());
              map_map_kernels::compose(&(v684_5),&(v685_7))
            };
            drop(v684_5);
            let v684_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v684_2));
            drop(v684_2);
            let v684_10: Space = if map_kernels::has_head(&(v684_9)) { singleton(&[]) } else { Space::new() };
            drop(v684_9);
            let v684_12: Space = if (v684_10).is_empty() { Space::new() } else {
              let v686_6: Path = concat_path(&(v683_6),&(v683_7_head));
              let v686_11: Space = routine_53(c, &(v686_6), &(v683_7_tail).make_space());
              drop(v686_6);
              map_map_kernels::compose(&(v684_10),&(v686_11))
            };
            drop(v684_10);
            let v684_13: Space = map_map_kernels::unite(&(v684_8),&(v684_12));
            v683_7.join_into((v684_13).clone());
            }
            v683_7_cursor.ascend(1);
          }
          drop(v683_7_cursor);
          drop(v683_6);
          map_map_kernels::compose(&(v682_5),&(v683_7))
        };
        drop(v682_5);
        let v682_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v682_2));
        drop(v682_2);
        let v682_10: Space = if map_kernels::has_head(&(v682_9)) { singleton(&[]) } else { Space::new() };
        drop(v682_9);
        let v682_11: Space = map_view_kernels::compose(&(v682_10),&(v681_11_tail));
        drop(v682_10);
        let v682_12: Space = map_map_kernels::unite(&(v682_8),&(v682_11));
        drop(v682_11);
        v681_11.join_into((v682_12).clone());
        }
        v681_11_cursor.ascend(1);
      }
      drop(v681_11_cursor);
      drop(v681_6);
      map_map_kernels::compose(&(v670_10),&(v681_11))
    };
    drop(v670_10);
    let v670_13: Space = map_map_kernels::unite(&(v670_8),&(v670_12));
    v669_20.join_into((v670_13).clone());
    }
    v669_20_cursor.ascend(1);
  }
  drop(v669_20_cursor);
  (v669_20).clone()
}

fn routine_39(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v687_14 = Space::new();
  let mut v687_14_cursor = (*s0).read_zipper();
  for v687_14_byte in v687_14_cursor.child_mask().iter() {
    v687_14_cursor.descend_to_byte(v687_14_byte);
    {
    let v687_14_tail = v687_14_cursor.fork_read_zipper();
    let v687_14_head = Path::from_slice(&[v687_14_byte]);
    let v688_2: Space = singleton(&(v687_14_head));
    let v688_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v688_2));
    let v688_4: Space = if map_kernels::has_head(&(v688_3)) { singleton(&[]) } else { Space::new() };
    drop(v688_3);
    let v688_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v688_4));
    drop(v688_4);
    let v688_8: Space = if (v688_5).is_empty() { Space::new() } else {
      let v689_6: Path = concat_path(&(*p0),&(v687_14_head));
      let mut v689_7 = Space::new();
      let mut v689_7_cursor = (v687_14_tail).read_zipper();
      for v689_7_byte in v689_7_cursor.child_mask().iter() {
        v689_7_cursor.descend_to_byte(v689_7_byte);
        {
        let v689_7_tail = v689_7_cursor.fork_read_zipper();
        let v689_7_head = Path::from_slice(&[v689_7_byte]);
        let v690_2: Space = singleton(&(v689_7_head));
        let v690_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v690_2));
        let v690_4: Space = if map_kernels::has_head(&(v690_3)) { singleton(&[]) } else { Space::new() };
        drop(v690_3);
        let v690_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v690_4));
        drop(v690_4);
        let v690_8: Space = if (v690_5).is_empty() { Space::new() } else {
          let v691_6: Path = concat_path(&(v689_6),&(v689_7_head));
          let mut v691_7 = Space::new();
          let mut v691_7_cursor = (v689_7_tail).read_zipper();
          for v691_7_byte in v691_7_cursor.child_mask().iter() {
            v691_7_cursor.descend_to_byte(v691_7_byte);
            {
            let v691_7_tail = v691_7_cursor.fork_read_zipper();
            let v691_7_head = Path::from_slice(&[v691_7_byte]);
            let v692_2: Space = singleton(&(v691_7_head));
            let v692_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v692_2));
            let v692_4: Space = if map_kernels::has_head(&(v692_3)) { singleton(&[]) } else { Space::new() };
            drop(v692_3);
            let v692_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v692_4));
            drop(v692_4);
            let v692_8: Space = if (v692_5).is_empty() { Space::new() } else {
              let v693_6: Path = concat_path(&(v691_6),&(v691_7_head));
              let v693_7: Space = routine_52(c, &(v693_6), &(v691_7_tail).make_space());
              map_map_kernels::compose(&(v692_5),&(v693_7))
            };
            drop(v692_5);
            let v692_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v692_2));
            drop(v692_2);
            let v692_10: Space = if map_kernels::has_head(&(v692_9)) { singleton(&[]) } else { Space::new() };
            drop(v692_9);
            let v692_12: Space = if (v692_10).is_empty() { Space::new() } else {
              let v694_6: Path = concat_path(&(v691_6),&(v691_7_head));
              let v694_11: Space = routine_53(c, &(v694_6), &(v691_7_tail).make_space());
              drop(v694_6);
              map_map_kernels::compose(&(v692_10),&(v694_11))
            };
            drop(v692_10);
            let v692_13: Space = map_map_kernels::unite(&(v692_8),&(v692_12));
            v691_7.join_into((v692_13).clone());
            }
            v691_7_cursor.ascend(1);
          }
          drop(v691_7_cursor);
          map_map_kernels::compose(&(v690_5),&(v691_7))
        };
        drop(v690_5);
        let v690_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v690_2));
        drop(v690_2);
        let v690_10: Space = if map_kernels::has_head(&(v690_9)) { singleton(&[]) } else { Space::new() };
        drop(v690_9);
        let v690_12: Space = if (v690_10).is_empty() { Space::new() } else {
          let v695_6: Path = concat_path(&(v689_6),&(v689_7_head));
          let mut v695_11 = Space::new();
          let mut v695_11_cursor = (v689_7_tail).read_zipper();
          for v695_11_byte in v695_11_cursor.child_mask().iter() {
            v695_11_cursor.descend_to_byte(v695_11_byte);
            {
            let v695_11_tail = v695_11_cursor.fork_read_zipper();
            let v695_11_head = Path::from_slice(&[v695_11_byte]);
            let v696_2: Space = singleton(&(v695_11_head));
            let v696_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v696_2));
            let v696_4: Space = if map_kernels::has_head(&(v696_3)) { singleton(&[]) } else { Space::new() };
            drop(v696_3);
            let v696_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v696_4));
            drop(v696_4);
            let v696_8: Space = if (v696_5).is_empty() { Space::new() } else {
              let v697_6: Path = concat_path(&(v695_6),&(v695_11_head));
              let v697_7: Space = routine_52(c, &(v697_6), &(v695_11_tail).make_space());
              map_map_kernels::compose(&(v696_5),&(v697_7))
            };
            drop(v696_5);
            let v696_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v696_2));
            drop(v696_2);
            let v696_10: Space = if map_kernels::has_head(&(v696_9)) { singleton(&[]) } else { Space::new() };
            drop(v696_9);
            let v696_12: Space = if (v696_10).is_empty() { Space::new() } else {
              let v698_6: Path = concat_path(&(v695_6),&(v695_11_head));
              let v698_11: Space = routine_15(c, &(v698_6), &(v695_11_tail).make_space());
              drop(v698_6);
              map_map_kernels::compose(&(v696_10),&(v698_11))
            };
            drop(v696_10);
            let v696_13: Space = map_map_kernels::unite(&(v696_8),&(v696_12));
            v695_11.join_into((v696_13).clone());
            }
            v695_11_cursor.ascend(1);
          }
          drop(v695_11_cursor);
          drop(v695_6);
          map_map_kernels::compose(&(v690_10),&(v695_11))
        };
        drop(v690_10);
        let v690_13: Space = map_map_kernels::unite(&(v690_8),&(v690_12));
        v689_7.join_into((v690_13).clone());
        }
        v689_7_cursor.ascend(1);
      }
      drop(v689_7_cursor);
      drop(v689_6);
      map_map_kernels::compose(&(v688_5),&(v689_7))
    };
    drop(v688_5);
    let v688_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v688_2));
    drop(v688_2);
    let v688_10: Space = if map_kernels::has_head(&(v688_9)) { singleton(&[]) } else { Space::new() };
    drop(v688_9);
    let v688_11: Space = map_view_kernels::compose(&(v688_10),&(v687_14_tail));
    drop(v688_10);
    let v688_12: Space = map_map_kernels::unite(&(v688_8),&(v688_11));
    drop(v688_11);
    v687_14.join_into((v688_12).clone());
    }
    v687_14_cursor.ascend(1);
  }
  drop(v687_14_cursor);
  (v687_14).clone()
}

fn routine_40(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v699_20 = Space::new();
  let mut v699_20_cursor = (*s0).read_zipper();
  for v699_20_byte in v699_20_cursor.child_mask().iter() {
    v699_20_cursor.descend_to_byte(v699_20_byte);
    {
    let v699_20_tail = v699_20_cursor.fork_read_zipper();
    let v699_20_head = Path::from_slice(&[v699_20_byte]);
    let v700_2: Space = singleton(&(v699_20_head));
    let v700_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v700_2));
    let v700_4: Space = if map_kernels::has_head(&(v700_3)) { singleton(&[]) } else { Space::new() };
    drop(v700_3);
    let v700_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v700_4));
    drop(v700_4);
    let v700_8: Space = if (v700_5).is_empty() { Space::new() } else {
      let v701_6: Path = concat_path(&(*p0),&(v699_20_head));
      let mut v701_7 = Space::new();
      let mut v701_7_cursor = (v699_20_tail).read_zipper();
      for v701_7_byte in v701_7_cursor.child_mask().iter() {
        v701_7_cursor.descend_to_byte(v701_7_byte);
        {
        let v701_7_tail = v701_7_cursor.fork_read_zipper();
        let v701_7_head = Path::from_slice(&[v701_7_byte]);
        let v702_2: Space = singleton(&(v701_7_head));
        let v702_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v702_2));
        let v702_4: Space = if map_kernels::has_head(&(v702_3)) { singleton(&[]) } else { Space::new() };
        drop(v702_3);
        let v702_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v702_4));
        drop(v702_4);
        let v702_8: Space = if (v702_5).is_empty() { Space::new() } else {
          let v703_6: Path = concat_path(&(v701_6),&(v701_7_head));
          let mut v703_7 = Space::new();
          let mut v703_7_cursor = (v701_7_tail).read_zipper();
          for v703_7_byte in v703_7_cursor.child_mask().iter() {
            v703_7_cursor.descend_to_byte(v703_7_byte);
            {
            let v703_7_tail = v703_7_cursor.fork_read_zipper();
            let v703_7_head = Path::from_slice(&[v703_7_byte]);
            let v704_2: Space = singleton(&(v703_7_head));
            let v704_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v704_2));
            let v704_4: Space = if map_kernels::has_head(&(v704_3)) { singleton(&[]) } else { Space::new() };
            drop(v704_3);
            let v704_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v704_4));
            drop(v704_4);
            let v704_8: Space = if (v704_5).is_empty() { Space::new() } else {
              let v705_6: Path = concat_path(&(v703_6),&(v703_7_head));
              let v705_7: Space = routine_54(c, &(v705_6), &(v703_7_tail).make_space());
              map_map_kernels::compose(&(v704_5),&(v705_7))
            };
            drop(v704_5);
            let v704_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v704_2));
            drop(v704_2);
            let v704_10: Space = if map_kernels::has_head(&(v704_9)) { singleton(&[]) } else { Space::new() };
            drop(v704_9);
            let v704_12: Space = if (v704_10).is_empty() { Space::new() } else {
              let v706_6: Path = concat_path(&(v703_6),&(v703_7_head));
              let v706_11: Space = routine_55(c, &(v706_6), &(v703_7_tail).make_space());
              drop(v706_6);
              map_map_kernels::compose(&(v704_10),&(v706_11))
            };
            drop(v704_10);
            let v704_13: Space = map_map_kernels::unite(&(v704_8),&(v704_12));
            v703_7.join_into((v704_13).clone());
            }
            v703_7_cursor.ascend(1);
          }
          drop(v703_7_cursor);
          map_map_kernels::compose(&(v702_5),&(v703_7))
        };
        drop(v702_5);
        let v702_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v702_2));
        drop(v702_2);
        let v702_10: Space = if map_kernels::has_head(&(v702_9)) { singleton(&[]) } else { Space::new() };
        drop(v702_9);
        let v702_12: Space = if (v702_10).is_empty() { Space::new() } else {
          let v707_6: Path = concat_path(&(v701_6),&(v701_7_head));
          let mut v707_11 = Space::new();
          let mut v707_11_cursor = (v701_7_tail).read_zipper();
          for v707_11_byte in v707_11_cursor.child_mask().iter() {
            v707_11_cursor.descend_to_byte(v707_11_byte);
            {
            let v707_11_tail = v707_11_cursor.fork_read_zipper();
            let v707_11_head = Path::from_slice(&[v707_11_byte]);
            let v708_2: Space = singleton(&(v707_11_head));
            let v708_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v708_2));
            let v708_4: Space = if map_kernels::has_head(&(v708_3)) { singleton(&[]) } else { Space::new() };
            drop(v708_3);
            let v708_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v708_4));
            drop(v708_4);
            let v708_8: Space = if (v708_5).is_empty() { Space::new() } else {
              let v709_6: Path = concat_path(&(v707_6),&(v707_11_head));
              let v709_7: Space = routine_54(c, &(v709_6), &(v707_11_tail).make_space());
              map_map_kernels::compose(&(v708_5),&(v709_7))
            };
            drop(v708_5);
            let v708_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v708_2));
            drop(v708_2);
            let v708_10: Space = if map_kernels::has_head(&(v708_9)) { singleton(&[]) } else { Space::new() };
            drop(v708_9);
            let v708_12: Space = if (v708_10).is_empty() { Space::new() } else {
              let v710_6: Path = concat_path(&(v707_6),&(v707_11_head));
              let v710_11: Space = routine_12(c, &(v710_6), &(v707_11_tail).make_space());
              drop(v710_6);
              map_map_kernels::compose(&(v708_10),&(v710_11))
            };
            drop(v708_10);
            let v708_13: Space = map_map_kernels::unite(&(v708_8),&(v708_12));
            v707_11.join_into((v708_13).clone());
            }
            v707_11_cursor.ascend(1);
          }
          drop(v707_11_cursor);
          drop(v707_6);
          map_map_kernels::compose(&(v702_10),&(v707_11))
        };
        drop(v702_10);
        let v702_13: Space = map_map_kernels::unite(&(v702_8),&(v702_12));
        v701_7.join_into((v702_13).clone());
        }
        v701_7_cursor.ascend(1);
      }
      drop(v701_7_cursor);
      map_map_kernels::compose(&(v700_5),&(v701_7))
    };
    drop(v700_5);
    let v700_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v700_2));
    drop(v700_2);
    let v700_10: Space = if map_kernels::has_head(&(v700_9)) { singleton(&[]) } else { Space::new() };
    drop(v700_9);
    let v700_12: Space = if (v700_10).is_empty() { Space::new() } else {
      let v711_6: Path = concat_path(&(*p0),&(v699_20_head));
      let mut v711_11 = Space::new();
      let mut v711_11_cursor = (v699_20_tail).read_zipper();
      for v711_11_byte in v711_11_cursor.child_mask().iter() {
        v711_11_cursor.descend_to_byte(v711_11_byte);
        {
        let v711_11_tail = v711_11_cursor.fork_read_zipper();
        let v711_11_head = Path::from_slice(&[v711_11_byte]);
        let v712_2: Space = singleton(&(v711_11_head));
        let v712_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v712_2));
        let v712_4: Space = if map_kernels::has_head(&(v712_3)) { singleton(&[]) } else { Space::new() };
        drop(v712_3);
        let v712_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v712_4));
        drop(v712_4);
        let v712_8: Space = if (v712_5).is_empty() { Space::new() } else {
          let v713_6: Path = concat_path(&(v711_6),&(v711_11_head));
          let mut v713_7 = Space::new();
          let mut v713_7_cursor = (v711_11_tail).read_zipper();
          for v713_7_byte in v713_7_cursor.child_mask().iter() {
            v713_7_cursor.descend_to_byte(v713_7_byte);
            {
            let v713_7_tail = v713_7_cursor.fork_read_zipper();
            let v713_7_head = Path::from_slice(&[v713_7_byte]);
            let v714_2: Space = singleton(&(v713_7_head));
            let v714_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v714_2));
            let v714_4: Space = if map_kernels::has_head(&(v714_3)) { singleton(&[]) } else { Space::new() };
            drop(v714_3);
            let v714_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v714_4));
            drop(v714_4);
            let v714_8: Space = if (v714_5).is_empty() { Space::new() } else {
              let v715_6: Path = concat_path(&(v713_6),&(v713_7_head));
              let v715_7: Space = routine_54(c, &(v715_6), &(v713_7_tail).make_space());
              map_map_kernels::compose(&(v714_5),&(v715_7))
            };
            drop(v714_5);
            let v714_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v714_2));
            drop(v714_2);
            let v714_10: Space = if map_kernels::has_head(&(v714_9)) { singleton(&[]) } else { Space::new() };
            drop(v714_9);
            let v714_12: Space = if (v714_10).is_empty() { Space::new() } else {
              let v716_6: Path = concat_path(&(v713_6),&(v713_7_head));
              let v716_11: Space = routine_55(c, &(v716_6), &(v713_7_tail).make_space());
              drop(v716_6);
              map_map_kernels::compose(&(v714_10),&(v716_11))
            };
            drop(v714_10);
            let v714_13: Space = map_map_kernels::unite(&(v714_8),&(v714_12));
            v713_7.join_into((v714_13).clone());
            }
            v713_7_cursor.ascend(1);
          }
          drop(v713_7_cursor);
          drop(v713_6);
          map_map_kernels::compose(&(v712_5),&(v713_7))
        };
        drop(v712_5);
        let v712_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v712_2));
        drop(v712_2);
        let v712_10: Space = if map_kernels::has_head(&(v712_9)) { singleton(&[]) } else { Space::new() };
        drop(v712_9);
        let v712_11: Space = map_view_kernels::compose(&(v712_10),&(v711_11_tail));
        drop(v712_10);
        let v712_12: Space = map_map_kernels::unite(&(v712_8),&(v712_11));
        drop(v712_11);
        v711_11.join_into((v712_12).clone());
        }
        v711_11_cursor.ascend(1);
      }
      drop(v711_11_cursor);
      drop(v711_6);
      map_map_kernels::compose(&(v700_10),&(v711_11))
    };
    drop(v700_10);
    let v700_13: Space = map_map_kernels::unite(&(v700_8),&(v700_12));
    v699_20.join_into((v700_13).clone());
    }
    v699_20_cursor.ascend(1);
  }
  drop(v699_20_cursor);
  (v699_20).clone()
}

fn routine_41(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v717_14 = Space::new();
  let mut v717_14_cursor = (*s0).read_zipper();
  for v717_14_byte in v717_14_cursor.child_mask().iter() {
    v717_14_cursor.descend_to_byte(v717_14_byte);
    {
    let v717_14_tail = v717_14_cursor.fork_read_zipper();
    let v717_14_head = Path::from_slice(&[v717_14_byte]);
    let v718_2: Space = singleton(&(v717_14_head));
    let v718_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v718_2));
    let v718_4: Space = if map_kernels::has_head(&(v718_3)) { singleton(&[]) } else { Space::new() };
    drop(v718_3);
    let v718_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v718_4));
    drop(v718_4);
    let v718_8: Space = if (v718_5).is_empty() { Space::new() } else {
      let v719_6: Path = concat_path(&(*p0),&(v717_14_head));
      let mut v719_7 = Space::new();
      let mut v719_7_cursor = (v717_14_tail).read_zipper();
      for v719_7_byte in v719_7_cursor.child_mask().iter() {
        v719_7_cursor.descend_to_byte(v719_7_byte);
        {
        let v719_7_tail = v719_7_cursor.fork_read_zipper();
        let v719_7_head = Path::from_slice(&[v719_7_byte]);
        let v720_2: Space = singleton(&(v719_7_head));
        let v720_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v720_2));
        let v720_4: Space = if map_kernels::has_head(&(v720_3)) { singleton(&[]) } else { Space::new() };
        drop(v720_3);
        let v720_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v720_4));
        drop(v720_4);
        let v720_8: Space = if (v720_5).is_empty() { Space::new() } else {
          let v721_6: Path = concat_path(&(v719_6),&(v719_7_head));
          let mut v721_7 = Space::new();
          let mut v721_7_cursor = (v719_7_tail).read_zipper();
          for v721_7_byte in v721_7_cursor.child_mask().iter() {
            v721_7_cursor.descend_to_byte(v721_7_byte);
            {
            let v721_7_tail = v721_7_cursor.fork_read_zipper();
            let v721_7_head = Path::from_slice(&[v721_7_byte]);
            let v722_2: Space = singleton(&(v721_7_head));
            let v722_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v722_2));
            let v722_4: Space = if map_kernels::has_head(&(v722_3)) { singleton(&[]) } else { Space::new() };
            drop(v722_3);
            let v722_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v722_4));
            drop(v722_4);
            let v722_8: Space = if (v722_5).is_empty() { Space::new() } else {
              let v723_6: Path = concat_path(&(v721_6),&(v721_7_head));
              let v723_7: Space = routine_54(c, &(v723_6), &(v721_7_tail).make_space());
              map_map_kernels::compose(&(v722_5),&(v723_7))
            };
            drop(v722_5);
            let v722_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v722_2));
            drop(v722_2);
            let v722_10: Space = if map_kernels::has_head(&(v722_9)) { singleton(&[]) } else { Space::new() };
            drop(v722_9);
            let v722_12: Space = if (v722_10).is_empty() { Space::new() } else {
              let v724_6: Path = concat_path(&(v721_6),&(v721_7_head));
              let v724_11: Space = routine_55(c, &(v724_6), &(v721_7_tail).make_space());
              drop(v724_6);
              map_map_kernels::compose(&(v722_10),&(v724_11))
            };
            drop(v722_10);
            let v722_13: Space = map_map_kernels::unite(&(v722_8),&(v722_12));
            v721_7.join_into((v722_13).clone());
            }
            v721_7_cursor.ascend(1);
          }
          drop(v721_7_cursor);
          map_map_kernels::compose(&(v720_5),&(v721_7))
        };
        drop(v720_5);
        let v720_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v720_2));
        drop(v720_2);
        let v720_10: Space = if map_kernels::has_head(&(v720_9)) { singleton(&[]) } else { Space::new() };
        drop(v720_9);
        let v720_12: Space = if (v720_10).is_empty() { Space::new() } else {
          let v725_6: Path = concat_path(&(v719_6),&(v719_7_head));
          let mut v725_11 = Space::new();
          let mut v725_11_cursor = (v719_7_tail).read_zipper();
          for v725_11_byte in v725_11_cursor.child_mask().iter() {
            v725_11_cursor.descend_to_byte(v725_11_byte);
            {
            let v725_11_tail = v725_11_cursor.fork_read_zipper();
            let v725_11_head = Path::from_slice(&[v725_11_byte]);
            let v726_2: Space = singleton(&(v725_11_head));
            let v726_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v726_2));
            let v726_4: Space = if map_kernels::has_head(&(v726_3)) { singleton(&[]) } else { Space::new() };
            drop(v726_3);
            let v726_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v726_4));
            drop(v726_4);
            let v726_8: Space = if (v726_5).is_empty() { Space::new() } else {
              let v727_6: Path = concat_path(&(v725_6),&(v725_11_head));
              let v727_7: Space = routine_54(c, &(v727_6), &(v725_11_tail).make_space());
              map_map_kernels::compose(&(v726_5),&(v727_7))
            };
            drop(v726_5);
            let v726_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v726_2));
            drop(v726_2);
            let v726_10: Space = if map_kernels::has_head(&(v726_9)) { singleton(&[]) } else { Space::new() };
            drop(v726_9);
            let v726_12: Space = if (v726_10).is_empty() { Space::new() } else {
              let v728_6: Path = concat_path(&(v725_6),&(v725_11_head));
              let v728_11: Space = routine_12(c, &(v728_6), &(v725_11_tail).make_space());
              drop(v728_6);
              map_map_kernels::compose(&(v726_10),&(v728_11))
            };
            drop(v726_10);
            let v726_13: Space = map_map_kernels::unite(&(v726_8),&(v726_12));
            v725_11.join_into((v726_13).clone());
            }
            v725_11_cursor.ascend(1);
          }
          drop(v725_11_cursor);
          drop(v725_6);
          map_map_kernels::compose(&(v720_10),&(v725_11))
        };
        drop(v720_10);
        let v720_13: Space = map_map_kernels::unite(&(v720_8),&(v720_12));
        v719_7.join_into((v720_13).clone());
        }
        v719_7_cursor.ascend(1);
      }
      drop(v719_7_cursor);
      drop(v719_6);
      map_map_kernels::compose(&(v718_5),&(v719_7))
    };
    drop(v718_5);
    let v718_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v718_2));
    drop(v718_2);
    let v718_10: Space = if map_kernels::has_head(&(v718_9)) { singleton(&[]) } else { Space::new() };
    drop(v718_9);
    let v718_11: Space = map_view_kernels::compose(&(v718_10),&(v717_14_tail));
    drop(v718_10);
    let v718_12: Space = map_map_kernels::unite(&(v718_8),&(v718_11));
    drop(v718_11);
    v717_14.join_into((v718_12).clone());
    }
    v717_14_cursor.ascend(1);
  }
  drop(v717_14_cursor);
  (v717_14).clone()
}

fn routine_42(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v729_20 = Space::new();
  let mut v729_20_cursor = (*s0).read_zipper();
  for v729_20_byte in v729_20_cursor.child_mask().iter() {
    v729_20_cursor.descend_to_byte(v729_20_byte);
    {
    let v729_20_tail = v729_20_cursor.fork_read_zipper();
    let v729_20_head = Path::from_slice(&[v729_20_byte]);
    let v730_2: Space = singleton(&(v729_20_head));
    let v730_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v730_2));
    let v730_4: Space = if map_kernels::has_head(&(v730_3)) { singleton(&[]) } else { Space::new() };
    drop(v730_3);
    let v730_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v730_4));
    drop(v730_4);
    let v730_8: Space = if (v730_5).is_empty() { Space::new() } else {
      let v731_6: Path = concat_path(&(*p0),&(v729_20_head));
      let mut v731_7 = Space::new();
      let mut v731_7_cursor = (v729_20_tail).read_zipper();
      for v731_7_byte in v731_7_cursor.child_mask().iter() {
        v731_7_cursor.descend_to_byte(v731_7_byte);
        {
        let v731_7_tail = v731_7_cursor.fork_read_zipper();
        let v731_7_head = Path::from_slice(&[v731_7_byte]);
        let v732_2: Space = singleton(&(v731_7_head));
        let v732_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v732_2));
        let v732_4: Space = if map_kernels::has_head(&(v732_3)) { singleton(&[]) } else { Space::new() };
        drop(v732_3);
        let v732_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v732_4));
        drop(v732_4);
        let v732_8: Space = if (v732_5).is_empty() { Space::new() } else {
          let v733_6: Path = concat_path(&(v731_6),&(v731_7_head));
          let mut v733_7 = Space::new();
          let mut v733_7_cursor = (v731_7_tail).read_zipper();
          for v733_7_byte in v733_7_cursor.child_mask().iter() {
            v733_7_cursor.descend_to_byte(v733_7_byte);
            {
            let v733_7_tail = v733_7_cursor.fork_read_zipper();
            let v733_7_head = Path::from_slice(&[v733_7_byte]);
            let v734_2: Space = singleton(&(v733_7_head));
            let v734_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v734_2));
            let v734_4: Space = if map_kernels::has_head(&(v734_3)) { singleton(&[]) } else { Space::new() };
            drop(v734_3);
            let v734_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v734_4));
            drop(v734_4);
            let v734_8: Space = if (v734_5).is_empty() { Space::new() } else {
              let v735_6: Path = concat_path(&(v733_6),&(v733_7_head));
              let v735_7: Space = routine_56(c, &(v735_6), &(v733_7_tail).make_space());
              map_map_kernels::compose(&(v734_5),&(v735_7))
            };
            drop(v734_5);
            let v734_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v734_2));
            drop(v734_2);
            let v734_10: Space = if map_kernels::has_head(&(v734_9)) { singleton(&[]) } else { Space::new() };
            drop(v734_9);
            let v734_12: Space = if (v734_10).is_empty() { Space::new() } else {
              let v736_6: Path = concat_path(&(v733_6),&(v733_7_head));
              let v736_11: Space = routine_57(c, &(v736_6), &(v733_7_tail).make_space());
              drop(v736_6);
              map_map_kernels::compose(&(v734_10),&(v736_11))
            };
            drop(v734_10);
            let v734_13: Space = map_map_kernels::unite(&(v734_8),&(v734_12));
            v733_7.join_into((v734_13).clone());
            }
            v733_7_cursor.ascend(1);
          }
          drop(v733_7_cursor);
          map_map_kernels::compose(&(v732_5),&(v733_7))
        };
        drop(v732_5);
        let v732_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v732_2));
        drop(v732_2);
        let v732_10: Space = if map_kernels::has_head(&(v732_9)) { singleton(&[]) } else { Space::new() };
        drop(v732_9);
        let v732_12: Space = if (v732_10).is_empty() { Space::new() } else {
          let v737_6: Path = concat_path(&(v731_6),&(v731_7_head));
          let mut v737_11 = Space::new();
          let mut v737_11_cursor = (v731_7_tail).read_zipper();
          for v737_11_byte in v737_11_cursor.child_mask().iter() {
            v737_11_cursor.descend_to_byte(v737_11_byte);
            {
            let v737_11_tail = v737_11_cursor.fork_read_zipper();
            let v737_11_head = Path::from_slice(&[v737_11_byte]);
            let v738_2: Space = singleton(&(v737_11_head));
            let v738_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v738_2));
            let v738_4: Space = if map_kernels::has_head(&(v738_3)) { singleton(&[]) } else { Space::new() };
            drop(v738_3);
            let v738_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v738_4));
            drop(v738_4);
            let v738_8: Space = if (v738_5).is_empty() { Space::new() } else {
              let v739_6: Path = concat_path(&(v737_6),&(v737_11_head));
              let v739_7: Space = routine_56(c, &(v739_6), &(v737_11_tail).make_space());
              map_map_kernels::compose(&(v738_5),&(v739_7))
            };
            drop(v738_5);
            let v738_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v738_2));
            drop(v738_2);
            let v738_10: Space = if map_kernels::has_head(&(v738_9)) { singleton(&[]) } else { Space::new() };
            drop(v738_9);
            let v738_12: Space = if (v738_10).is_empty() { Space::new() } else {
              let v740_6: Path = concat_path(&(v737_6),&(v737_11_head));
              let v740_11: Space = routine_15(c, &(v740_6), &(v737_11_tail).make_space());
              drop(v740_6);
              map_map_kernels::compose(&(v738_10),&(v740_11))
            };
            drop(v738_10);
            let v738_13: Space = map_map_kernels::unite(&(v738_8),&(v738_12));
            v737_11.join_into((v738_13).clone());
            }
            v737_11_cursor.ascend(1);
          }
          drop(v737_11_cursor);
          drop(v737_6);
          map_map_kernels::compose(&(v732_10),&(v737_11))
        };
        drop(v732_10);
        let v732_13: Space = map_map_kernels::unite(&(v732_8),&(v732_12));
        v731_7.join_into((v732_13).clone());
        }
        v731_7_cursor.ascend(1);
      }
      drop(v731_7_cursor);
      map_map_kernels::compose(&(v730_5),&(v731_7))
    };
    drop(v730_5);
    let v730_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v730_2));
    drop(v730_2);
    let v730_10: Space = if map_kernels::has_head(&(v730_9)) { singleton(&[]) } else { Space::new() };
    drop(v730_9);
    let v730_12: Space = if (v730_10).is_empty() { Space::new() } else {
      let v741_6: Path = concat_path(&(*p0),&(v729_20_head));
      let mut v741_11 = Space::new();
      let mut v741_11_cursor = (v729_20_tail).read_zipper();
      for v741_11_byte in v741_11_cursor.child_mask().iter() {
        v741_11_cursor.descend_to_byte(v741_11_byte);
        {
        let v741_11_tail = v741_11_cursor.fork_read_zipper();
        let v741_11_head = Path::from_slice(&[v741_11_byte]);
        let v742_2: Space = singleton(&(v741_11_head));
        let v742_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v742_2));
        let v742_4: Space = if map_kernels::has_head(&(v742_3)) { singleton(&[]) } else { Space::new() };
        drop(v742_3);
        let v742_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v742_4));
        drop(v742_4);
        let v742_8: Space = if (v742_5).is_empty() { Space::new() } else {
          let v743_6: Path = concat_path(&(v741_6),&(v741_11_head));
          let mut v743_7 = Space::new();
          let mut v743_7_cursor = (v741_11_tail).read_zipper();
          for v743_7_byte in v743_7_cursor.child_mask().iter() {
            v743_7_cursor.descend_to_byte(v743_7_byte);
            {
            let v743_7_tail = v743_7_cursor.fork_read_zipper();
            let v743_7_head = Path::from_slice(&[v743_7_byte]);
            let v744_2: Space = singleton(&(v743_7_head));
            let v744_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v744_2));
            let v744_4: Space = if map_kernels::has_head(&(v744_3)) { singleton(&[]) } else { Space::new() };
            drop(v744_3);
            let v744_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v744_4));
            drop(v744_4);
            let v744_8: Space = if (v744_5).is_empty() { Space::new() } else {
              let v745_6: Path = concat_path(&(v743_6),&(v743_7_head));
              let v745_7: Space = routine_56(c, &(v745_6), &(v743_7_tail).make_space());
              map_map_kernels::compose(&(v744_5),&(v745_7))
            };
            drop(v744_5);
            let v744_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v744_2));
            drop(v744_2);
            let v744_10: Space = if map_kernels::has_head(&(v744_9)) { singleton(&[]) } else { Space::new() };
            drop(v744_9);
            let v744_12: Space = if (v744_10).is_empty() { Space::new() } else {
              let v746_6: Path = concat_path(&(v743_6),&(v743_7_head));
              let v746_11: Space = routine_57(c, &(v746_6), &(v743_7_tail).make_space());
              drop(v746_6);
              map_map_kernels::compose(&(v744_10),&(v746_11))
            };
            drop(v744_10);
            let v744_13: Space = map_map_kernels::unite(&(v744_8),&(v744_12));
            v743_7.join_into((v744_13).clone());
            }
            v743_7_cursor.ascend(1);
          }
          drop(v743_7_cursor);
          drop(v743_6);
          map_map_kernels::compose(&(v742_5),&(v743_7))
        };
        drop(v742_5);
        let v742_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v742_2));
        drop(v742_2);
        let v742_10: Space = if map_kernels::has_head(&(v742_9)) { singleton(&[]) } else { Space::new() };
        drop(v742_9);
        let v742_11: Space = map_view_kernels::compose(&(v742_10),&(v741_11_tail));
        drop(v742_10);
        let v742_12: Space = map_map_kernels::unite(&(v742_8),&(v742_11));
        drop(v742_11);
        v741_11.join_into((v742_12).clone());
        }
        v741_11_cursor.ascend(1);
      }
      drop(v741_11_cursor);
      drop(v741_6);
      map_map_kernels::compose(&(v730_10),&(v741_11))
    };
    drop(v730_10);
    let v730_13: Space = map_map_kernels::unite(&(v730_8),&(v730_12));
    v729_20.join_into((v730_13).clone());
    }
    v729_20_cursor.ascend(1);
  }
  drop(v729_20_cursor);
  (v729_20).clone()
}

fn routine_43(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v747_14 = Space::new();
  let mut v747_14_cursor = (*s0).read_zipper();
  for v747_14_byte in v747_14_cursor.child_mask().iter() {
    v747_14_cursor.descend_to_byte(v747_14_byte);
    {
    let v747_14_tail = v747_14_cursor.fork_read_zipper();
    let v747_14_head = Path::from_slice(&[v747_14_byte]);
    let v748_2: Space = singleton(&(v747_14_head));
    let v748_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v748_2));
    let v748_4: Space = if map_kernels::has_head(&(v748_3)) { singleton(&[]) } else { Space::new() };
    drop(v748_3);
    let v748_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v748_4));
    drop(v748_4);
    let v748_8: Space = if (v748_5).is_empty() { Space::new() } else {
      let v749_6: Path = concat_path(&(*p0),&(v747_14_head));
      let mut v749_7 = Space::new();
      let mut v749_7_cursor = (v747_14_tail).read_zipper();
      for v749_7_byte in v749_7_cursor.child_mask().iter() {
        v749_7_cursor.descend_to_byte(v749_7_byte);
        {
        let v749_7_tail = v749_7_cursor.fork_read_zipper();
        let v749_7_head = Path::from_slice(&[v749_7_byte]);
        let v750_2: Space = singleton(&(v749_7_head));
        let v750_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v750_2));
        let v750_4: Space = if map_kernels::has_head(&(v750_3)) { singleton(&[]) } else { Space::new() };
        drop(v750_3);
        let v750_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v750_4));
        drop(v750_4);
        let v750_8: Space = if (v750_5).is_empty() { Space::new() } else {
          let v751_6: Path = concat_path(&(v749_6),&(v749_7_head));
          let mut v751_7 = Space::new();
          let mut v751_7_cursor = (v749_7_tail).read_zipper();
          for v751_7_byte in v751_7_cursor.child_mask().iter() {
            v751_7_cursor.descend_to_byte(v751_7_byte);
            {
            let v751_7_tail = v751_7_cursor.fork_read_zipper();
            let v751_7_head = Path::from_slice(&[v751_7_byte]);
            let v752_2: Space = singleton(&(v751_7_head));
            let v752_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v752_2));
            let v752_4: Space = if map_kernels::has_head(&(v752_3)) { singleton(&[]) } else { Space::new() };
            drop(v752_3);
            let v752_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v752_4));
            drop(v752_4);
            let v752_8: Space = if (v752_5).is_empty() { Space::new() } else {
              let v753_6: Path = concat_path(&(v751_6),&(v751_7_head));
              let v753_7: Space = routine_56(c, &(v753_6), &(v751_7_tail).make_space());
              map_map_kernels::compose(&(v752_5),&(v753_7))
            };
            drop(v752_5);
            let v752_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v752_2));
            drop(v752_2);
            let v752_10: Space = if map_kernels::has_head(&(v752_9)) { singleton(&[]) } else { Space::new() };
            drop(v752_9);
            let v752_12: Space = if (v752_10).is_empty() { Space::new() } else {
              let v754_6: Path = concat_path(&(v751_6),&(v751_7_head));
              let v754_11: Space = routine_57(c, &(v754_6), &(v751_7_tail).make_space());
              drop(v754_6);
              map_map_kernels::compose(&(v752_10),&(v754_11))
            };
            drop(v752_10);
            let v752_13: Space = map_map_kernels::unite(&(v752_8),&(v752_12));
            v751_7.join_into((v752_13).clone());
            }
            v751_7_cursor.ascend(1);
          }
          drop(v751_7_cursor);
          map_map_kernels::compose(&(v750_5),&(v751_7))
        };
        drop(v750_5);
        let v750_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v750_2));
        drop(v750_2);
        let v750_10: Space = if map_kernels::has_head(&(v750_9)) { singleton(&[]) } else { Space::new() };
        drop(v750_9);
        let v750_12: Space = if (v750_10).is_empty() { Space::new() } else {
          let v755_6: Path = concat_path(&(v749_6),&(v749_7_head));
          let mut v755_11 = Space::new();
          let mut v755_11_cursor = (v749_7_tail).read_zipper();
          for v755_11_byte in v755_11_cursor.child_mask().iter() {
            v755_11_cursor.descend_to_byte(v755_11_byte);
            {
            let v755_11_tail = v755_11_cursor.fork_read_zipper();
            let v755_11_head = Path::from_slice(&[v755_11_byte]);
            let v756_2: Space = singleton(&(v755_11_head));
            let v756_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v756_2));
            let v756_4: Space = if map_kernels::has_head(&(v756_3)) { singleton(&[]) } else { Space::new() };
            drop(v756_3);
            let v756_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v756_4));
            drop(v756_4);
            let v756_8: Space = if (v756_5).is_empty() { Space::new() } else {
              let v757_6: Path = concat_path(&(v755_6),&(v755_11_head));
              let v757_7: Space = routine_56(c, &(v757_6), &(v755_11_tail).make_space());
              map_map_kernels::compose(&(v756_5),&(v757_7))
            };
            drop(v756_5);
            let v756_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v756_2));
            drop(v756_2);
            let v756_10: Space = if map_kernels::has_head(&(v756_9)) { singleton(&[]) } else { Space::new() };
            drop(v756_9);
            let v756_12: Space = if (v756_10).is_empty() { Space::new() } else {
              let v758_6: Path = concat_path(&(v755_6),&(v755_11_head));
              let v758_11: Space = routine_15(c, &(v758_6), &(v755_11_tail).make_space());
              drop(v758_6);
              map_map_kernels::compose(&(v756_10),&(v758_11))
            };
            drop(v756_10);
            let v756_13: Space = map_map_kernels::unite(&(v756_8),&(v756_12));
            v755_11.join_into((v756_13).clone());
            }
            v755_11_cursor.ascend(1);
          }
          drop(v755_11_cursor);
          drop(v755_6);
          map_map_kernels::compose(&(v750_10),&(v755_11))
        };
        drop(v750_10);
        let v750_13: Space = map_map_kernels::unite(&(v750_8),&(v750_12));
        v749_7.join_into((v750_13).clone());
        }
        v749_7_cursor.ascend(1);
      }
      drop(v749_7_cursor);
      drop(v749_6);
      map_map_kernels::compose(&(v748_5),&(v749_7))
    };
    drop(v748_5);
    let v748_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v748_2));
    drop(v748_2);
    let v748_10: Space = if map_kernels::has_head(&(v748_9)) { singleton(&[]) } else { Space::new() };
    drop(v748_9);
    let v748_11: Space = map_view_kernels::compose(&(v748_10),&(v747_14_tail));
    drop(v748_10);
    let v748_12: Space = map_map_kernels::unite(&(v748_8),&(v748_11));
    drop(v748_11);
    v747_14.join_into((v748_12).clone());
    }
    v747_14_cursor.ascend(1);
  }
  drop(v747_14_cursor);
  (v747_14).clone()
}

fn routine_44(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v759_20 = Space::new();
  let mut v759_20_cursor = (*s0).read_zipper();
  for v759_20_byte in v759_20_cursor.child_mask().iter() {
    v759_20_cursor.descend_to_byte(v759_20_byte);
    {
    let v759_20_tail = v759_20_cursor.fork_read_zipper();
    let v759_20_head = Path::from_slice(&[v759_20_byte]);
    let v760_2: Space = singleton(&(v759_20_head));
    let v760_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v760_2));
    let v760_4: Space = if map_kernels::has_head(&(v760_3)) { singleton(&[]) } else { Space::new() };
    drop(v760_3);
    let v760_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v760_4));
    drop(v760_4);
    let v760_8: Space = if (v760_5).is_empty() { Space::new() } else {
      let v761_6: Path = concat_path(&(*p0),&(v759_20_head));
      let mut v761_7 = Space::new();
      let mut v761_7_cursor = (v759_20_tail).read_zipper();
      for v761_7_byte in v761_7_cursor.child_mask().iter() {
        v761_7_cursor.descend_to_byte(v761_7_byte);
        {
        let v761_7_tail = v761_7_cursor.fork_read_zipper();
        let v761_7_head = Path::from_slice(&[v761_7_byte]);
        let v762_2: Space = singleton(&(v761_7_head));
        let v762_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v762_2));
        let v762_4: Space = if map_kernels::has_head(&(v762_3)) { singleton(&[]) } else { Space::new() };
        drop(v762_3);
        let v762_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v762_4));
        drop(v762_4);
        let v762_8: Space = if (v762_5).is_empty() { Space::new() } else {
          let v763_6: Path = concat_path(&(v761_6),&(v761_7_head));
          let mut v763_7 = Space::new();
          let mut v763_7_cursor = (v761_7_tail).read_zipper();
          for v763_7_byte in v763_7_cursor.child_mask().iter() {
            v763_7_cursor.descend_to_byte(v763_7_byte);
            {
            let v763_7_tail = v763_7_cursor.fork_read_zipper();
            let v763_7_head = Path::from_slice(&[v763_7_byte]);
            let v764_2: Space = singleton(&(v763_7_head));
            let v764_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v764_2));
            let v764_4: Space = if map_kernels::has_head(&(v764_3)) { singleton(&[]) } else { Space::new() };
            drop(v764_3);
            let v764_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v764_4));
            drop(v764_4);
            let v764_8: Space = if (v764_5).is_empty() { Space::new() } else {
              let v765_6: Path = concat_path(&(v763_6),&(v763_7_head));
              let v765_7: Space = routine_58(c, &(v765_6), &(v763_7_tail).make_space());
              map_map_kernels::compose(&(v764_5),&(v765_7))
            };
            drop(v764_5);
            let v764_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v764_2));
            drop(v764_2);
            let v764_10: Space = if map_kernels::has_head(&(v764_9)) { singleton(&[]) } else { Space::new() };
            drop(v764_9);
            let v764_12: Space = if (v764_10).is_empty() { Space::new() } else {
              let v766_6: Path = concat_path(&(v763_6),&(v763_7_head));
              let v766_11: Space = routine_59(c, &(v766_6), &(v763_7_tail).make_space());
              drop(v766_6);
              map_map_kernels::compose(&(v764_10),&(v766_11))
            };
            drop(v764_10);
            let v764_13: Space = map_map_kernels::unite(&(v764_8),&(v764_12));
            v763_7.join_into((v764_13).clone());
            }
            v763_7_cursor.ascend(1);
          }
          drop(v763_7_cursor);
          map_map_kernels::compose(&(v762_5),&(v763_7))
        };
        drop(v762_5);
        let v762_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v762_2));
        drop(v762_2);
        let v762_10: Space = if map_kernels::has_head(&(v762_9)) { singleton(&[]) } else { Space::new() };
        drop(v762_9);
        let v762_12: Space = if (v762_10).is_empty() { Space::new() } else {
          let v767_6: Path = concat_path(&(v761_6),&(v761_7_head));
          let mut v767_11 = Space::new();
          let mut v767_11_cursor = (v761_7_tail).read_zipper();
          for v767_11_byte in v767_11_cursor.child_mask().iter() {
            v767_11_cursor.descend_to_byte(v767_11_byte);
            {
            let v767_11_tail = v767_11_cursor.fork_read_zipper();
            let v767_11_head = Path::from_slice(&[v767_11_byte]);
            let v768_2: Space = singleton(&(v767_11_head));
            let v768_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v768_2));
            let v768_4: Space = if map_kernels::has_head(&(v768_3)) { singleton(&[]) } else { Space::new() };
            drop(v768_3);
            let v768_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v768_4));
            drop(v768_4);
            let v768_8: Space = if (v768_5).is_empty() { Space::new() } else {
              let v769_6: Path = concat_path(&(v767_6),&(v767_11_head));
              let v769_7: Space = routine_58(c, &(v769_6), &(v767_11_tail).make_space());
              map_map_kernels::compose(&(v768_5),&(v769_7))
            };
            drop(v768_5);
            let v768_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v768_2));
            drop(v768_2);
            let v768_10: Space = if map_kernels::has_head(&(v768_9)) { singleton(&[]) } else { Space::new() };
            drop(v768_9);
            let v768_12: Space = if (v768_10).is_empty() { Space::new() } else {
              let v770_6: Path = concat_path(&(v767_6),&(v767_11_head));
              let v770_11: Space = routine_12(c, &(v770_6), &(v767_11_tail).make_space());
              drop(v770_6);
              map_map_kernels::compose(&(v768_10),&(v770_11))
            };
            drop(v768_10);
            let v768_13: Space = map_map_kernels::unite(&(v768_8),&(v768_12));
            v767_11.join_into((v768_13).clone());
            }
            v767_11_cursor.ascend(1);
          }
          drop(v767_11_cursor);
          drop(v767_6);
          map_map_kernels::compose(&(v762_10),&(v767_11))
        };
        drop(v762_10);
        let v762_13: Space = map_map_kernels::unite(&(v762_8),&(v762_12));
        v761_7.join_into((v762_13).clone());
        }
        v761_7_cursor.ascend(1);
      }
      drop(v761_7_cursor);
      map_map_kernels::compose(&(v760_5),&(v761_7))
    };
    drop(v760_5);
    let v760_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v760_2));
    drop(v760_2);
    let v760_10: Space = if map_kernels::has_head(&(v760_9)) { singleton(&[]) } else { Space::new() };
    drop(v760_9);
    let v760_12: Space = if (v760_10).is_empty() { Space::new() } else {
      let v771_6: Path = concat_path(&(*p0),&(v759_20_head));
      let mut v771_11 = Space::new();
      let mut v771_11_cursor = (v759_20_tail).read_zipper();
      for v771_11_byte in v771_11_cursor.child_mask().iter() {
        v771_11_cursor.descend_to_byte(v771_11_byte);
        {
        let v771_11_tail = v771_11_cursor.fork_read_zipper();
        let v771_11_head = Path::from_slice(&[v771_11_byte]);
        let v772_2: Space = singleton(&(v771_11_head));
        let v772_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v772_2));
        let v772_4: Space = if map_kernels::has_head(&(v772_3)) { singleton(&[]) } else { Space::new() };
        drop(v772_3);
        let v772_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v772_4));
        drop(v772_4);
        let v772_8: Space = if (v772_5).is_empty() { Space::new() } else {
          let v773_6: Path = concat_path(&(v771_6),&(v771_11_head));
          let mut v773_7 = Space::new();
          let mut v773_7_cursor = (v771_11_tail).read_zipper();
          for v773_7_byte in v773_7_cursor.child_mask().iter() {
            v773_7_cursor.descend_to_byte(v773_7_byte);
            {
            let v773_7_tail = v773_7_cursor.fork_read_zipper();
            let v773_7_head = Path::from_slice(&[v773_7_byte]);
            let v774_2: Space = singleton(&(v773_7_head));
            let v774_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v774_2));
            let v774_4: Space = if map_kernels::has_head(&(v774_3)) { singleton(&[]) } else { Space::new() };
            drop(v774_3);
            let v774_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v774_4));
            drop(v774_4);
            let v774_8: Space = if (v774_5).is_empty() { Space::new() } else {
              let v775_6: Path = concat_path(&(v773_6),&(v773_7_head));
              let v775_7: Space = routine_58(c, &(v775_6), &(v773_7_tail).make_space());
              map_map_kernels::compose(&(v774_5),&(v775_7))
            };
            drop(v774_5);
            let v774_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v774_2));
            drop(v774_2);
            let v774_10: Space = if map_kernels::has_head(&(v774_9)) { singleton(&[]) } else { Space::new() };
            drop(v774_9);
            let v774_12: Space = if (v774_10).is_empty() { Space::new() } else {
              let v776_6: Path = concat_path(&(v773_6),&(v773_7_head));
              let v776_11: Space = routine_59(c, &(v776_6), &(v773_7_tail).make_space());
              drop(v776_6);
              map_map_kernels::compose(&(v774_10),&(v776_11))
            };
            drop(v774_10);
            let v774_13: Space = map_map_kernels::unite(&(v774_8),&(v774_12));
            v773_7.join_into((v774_13).clone());
            }
            v773_7_cursor.ascend(1);
          }
          drop(v773_7_cursor);
          drop(v773_6);
          map_map_kernels::compose(&(v772_5),&(v773_7))
        };
        drop(v772_5);
        let v772_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v772_2));
        drop(v772_2);
        let v772_10: Space = if map_kernels::has_head(&(v772_9)) { singleton(&[]) } else { Space::new() };
        drop(v772_9);
        let v772_11: Space = map_view_kernels::compose(&(v772_10),&(v771_11_tail));
        drop(v772_10);
        let v772_12: Space = map_map_kernels::unite(&(v772_8),&(v772_11));
        drop(v772_11);
        v771_11.join_into((v772_12).clone());
        }
        v771_11_cursor.ascend(1);
      }
      drop(v771_11_cursor);
      drop(v771_6);
      map_map_kernels::compose(&(v760_10),&(v771_11))
    };
    drop(v760_10);
    let v760_13: Space = map_map_kernels::unite(&(v760_8),&(v760_12));
    v759_20.join_into((v760_13).clone());
    }
    v759_20_cursor.ascend(1);
  }
  drop(v759_20_cursor);
  (v759_20).clone()
}

fn routine_45(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v777_14 = Space::new();
  let mut v777_14_cursor = (*s0).read_zipper();
  for v777_14_byte in v777_14_cursor.child_mask().iter() {
    v777_14_cursor.descend_to_byte(v777_14_byte);
    {
    let v777_14_tail = v777_14_cursor.fork_read_zipper();
    let v777_14_head = Path::from_slice(&[v777_14_byte]);
    let v778_2: Space = singleton(&(v777_14_head));
    let v778_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v778_2));
    let v778_4: Space = if map_kernels::has_head(&(v778_3)) { singleton(&[]) } else { Space::new() };
    drop(v778_3);
    let v778_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v778_4));
    drop(v778_4);
    let v778_8: Space = if (v778_5).is_empty() { Space::new() } else {
      let v779_6: Path = concat_path(&(*p0),&(v777_14_head));
      let mut v779_7 = Space::new();
      let mut v779_7_cursor = (v777_14_tail).read_zipper();
      for v779_7_byte in v779_7_cursor.child_mask().iter() {
        v779_7_cursor.descend_to_byte(v779_7_byte);
        {
        let v779_7_tail = v779_7_cursor.fork_read_zipper();
        let v779_7_head = Path::from_slice(&[v779_7_byte]);
        let v780_2: Space = singleton(&(v779_7_head));
        let v780_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v780_2));
        let v780_4: Space = if map_kernels::has_head(&(v780_3)) { singleton(&[]) } else { Space::new() };
        drop(v780_3);
        let v780_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v780_4));
        drop(v780_4);
        let v780_8: Space = if (v780_5).is_empty() { Space::new() } else {
          let v781_6: Path = concat_path(&(v779_6),&(v779_7_head));
          let mut v781_7 = Space::new();
          let mut v781_7_cursor = (v779_7_tail).read_zipper();
          for v781_7_byte in v781_7_cursor.child_mask().iter() {
            v781_7_cursor.descend_to_byte(v781_7_byte);
            {
            let v781_7_tail = v781_7_cursor.fork_read_zipper();
            let v781_7_head = Path::from_slice(&[v781_7_byte]);
            let v782_2: Space = singleton(&(v781_7_head));
            let v782_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v782_2));
            let v782_4: Space = if map_kernels::has_head(&(v782_3)) { singleton(&[]) } else { Space::new() };
            drop(v782_3);
            let v782_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v782_4));
            drop(v782_4);
            let v782_8: Space = if (v782_5).is_empty() { Space::new() } else {
              let v783_6: Path = concat_path(&(v781_6),&(v781_7_head));
              let v783_7: Space = routine_58(c, &(v783_6), &(v781_7_tail).make_space());
              map_map_kernels::compose(&(v782_5),&(v783_7))
            };
            drop(v782_5);
            let v782_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v782_2));
            drop(v782_2);
            let v782_10: Space = if map_kernels::has_head(&(v782_9)) { singleton(&[]) } else { Space::new() };
            drop(v782_9);
            let v782_12: Space = if (v782_10).is_empty() { Space::new() } else {
              let v784_6: Path = concat_path(&(v781_6),&(v781_7_head));
              let v784_11: Space = routine_59(c, &(v784_6), &(v781_7_tail).make_space());
              drop(v784_6);
              map_map_kernels::compose(&(v782_10),&(v784_11))
            };
            drop(v782_10);
            let v782_13: Space = map_map_kernels::unite(&(v782_8),&(v782_12));
            v781_7.join_into((v782_13).clone());
            }
            v781_7_cursor.ascend(1);
          }
          drop(v781_7_cursor);
          map_map_kernels::compose(&(v780_5),&(v781_7))
        };
        drop(v780_5);
        let v780_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v780_2));
        drop(v780_2);
        let v780_10: Space = if map_kernels::has_head(&(v780_9)) { singleton(&[]) } else { Space::new() };
        drop(v780_9);
        let v780_12: Space = if (v780_10).is_empty() { Space::new() } else {
          let v785_6: Path = concat_path(&(v779_6),&(v779_7_head));
          let mut v785_11 = Space::new();
          let mut v785_11_cursor = (v779_7_tail).read_zipper();
          for v785_11_byte in v785_11_cursor.child_mask().iter() {
            v785_11_cursor.descend_to_byte(v785_11_byte);
            {
            let v785_11_tail = v785_11_cursor.fork_read_zipper();
            let v785_11_head = Path::from_slice(&[v785_11_byte]);
            let v786_2: Space = singleton(&(v785_11_head));
            let v786_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v786_2));
            let v786_4: Space = if map_kernels::has_head(&(v786_3)) { singleton(&[]) } else { Space::new() };
            drop(v786_3);
            let v786_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v786_4));
            drop(v786_4);
            let v786_8: Space = if (v786_5).is_empty() { Space::new() } else {
              let v787_6: Path = concat_path(&(v785_6),&(v785_11_head));
              let v787_7: Space = routine_58(c, &(v787_6), &(v785_11_tail).make_space());
              map_map_kernels::compose(&(v786_5),&(v787_7))
            };
            drop(v786_5);
            let v786_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v786_2));
            drop(v786_2);
            let v786_10: Space = if map_kernels::has_head(&(v786_9)) { singleton(&[]) } else { Space::new() };
            drop(v786_9);
            let v786_12: Space = if (v786_10).is_empty() { Space::new() } else {
              let v788_6: Path = concat_path(&(v785_6),&(v785_11_head));
              let v788_11: Space = routine_12(c, &(v788_6), &(v785_11_tail).make_space());
              drop(v788_6);
              map_map_kernels::compose(&(v786_10),&(v788_11))
            };
            drop(v786_10);
            let v786_13: Space = map_map_kernels::unite(&(v786_8),&(v786_12));
            v785_11.join_into((v786_13).clone());
            }
            v785_11_cursor.ascend(1);
          }
          drop(v785_11_cursor);
          drop(v785_6);
          map_map_kernels::compose(&(v780_10),&(v785_11))
        };
        drop(v780_10);
        let v780_13: Space = map_map_kernels::unite(&(v780_8),&(v780_12));
        v779_7.join_into((v780_13).clone());
        }
        v779_7_cursor.ascend(1);
      }
      drop(v779_7_cursor);
      drop(v779_6);
      map_map_kernels::compose(&(v778_5),&(v779_7))
    };
    drop(v778_5);
    let v778_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v778_2));
    drop(v778_2);
    let v778_10: Space = if map_kernels::has_head(&(v778_9)) { singleton(&[]) } else { Space::new() };
    drop(v778_9);
    let v778_11: Space = map_view_kernels::compose(&(v778_10),&(v777_14_tail));
    drop(v778_10);
    let v778_12: Space = map_map_kernels::unite(&(v778_8),&(v778_11));
    drop(v778_11);
    v777_14.join_into((v778_12).clone());
    }
    v777_14_cursor.ascend(1);
  }
  drop(v777_14_cursor);
  (v777_14).clone()
}

fn routine_46(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v789_20 = Space::new();
  let mut v789_20_cursor = (*s0).read_zipper();
  for v789_20_byte in v789_20_cursor.child_mask().iter() {
    v789_20_cursor.descend_to_byte(v789_20_byte);
    {
    let v789_20_tail = v789_20_cursor.fork_read_zipper();
    let v789_20_head = Path::from_slice(&[v789_20_byte]);
    let v790_2: Space = singleton(&(v789_20_head));
    let v790_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v790_2));
    let v790_4: Space = if map_kernels::has_head(&(v790_3)) { singleton(&[]) } else { Space::new() };
    drop(v790_3);
    let v790_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v790_4));
    drop(v790_4);
    let v790_8: Space = if (v790_5).is_empty() { Space::new() } else {
      let v791_6: Path = concat_path(&(*p0),&(v789_20_head));
      let mut v791_7 = Space::new();
      let mut v791_7_cursor = (v789_20_tail).read_zipper();
      for v791_7_byte in v791_7_cursor.child_mask().iter() {
        v791_7_cursor.descend_to_byte(v791_7_byte);
        {
        let v791_7_tail = v791_7_cursor.fork_read_zipper();
        let v791_7_head = Path::from_slice(&[v791_7_byte]);
        let v792_2: Space = singleton(&(v791_7_head));
        let v792_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v792_2));
        let v792_4: Space = if map_kernels::has_head(&(v792_3)) { singleton(&[]) } else { Space::new() };
        drop(v792_3);
        let v792_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v792_4));
        drop(v792_4);
        let v792_8: Space = if (v792_5).is_empty() { Space::new() } else {
          let v793_6: Path = concat_path(&(v791_6),&(v791_7_head));
          let mut v793_7 = Space::new();
          let mut v793_7_cursor = (v791_7_tail).read_zipper();
          for v793_7_byte in v793_7_cursor.child_mask().iter() {
            v793_7_cursor.descend_to_byte(v793_7_byte);
            {
            let v793_7_tail = v793_7_cursor.fork_read_zipper();
            let v793_7_head = Path::from_slice(&[v793_7_byte]);
            let v794_2: Space = singleton(&(v793_7_head));
            let v794_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v794_2));
            let v794_4: Space = if map_kernels::has_head(&(v794_3)) { singleton(&[]) } else { Space::new() };
            drop(v794_3);
            let v794_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v794_4));
            drop(v794_4);
            let v794_8: Space = if (v794_5).is_empty() { Space::new() } else {
              let v795_6: Path = concat_path(&(v793_6),&(v793_7_head));
              let v795_7: Space = routine_60(c, &(v795_6), &(v793_7_tail).make_space());
              map_map_kernels::compose(&(v794_5),&(v795_7))
            };
            drop(v794_5);
            let v794_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v794_2));
            drop(v794_2);
            let v794_10: Space = if map_kernels::has_head(&(v794_9)) { singleton(&[]) } else { Space::new() };
            drop(v794_9);
            let v794_12: Space = if (v794_10).is_empty() { Space::new() } else {
              let v796_6: Path = concat_path(&(v793_6),&(v793_7_head));
              let v796_11: Space = routine_61(c, &(v796_6), &(v793_7_tail).make_space());
              drop(v796_6);
              map_map_kernels::compose(&(v794_10),&(v796_11))
            };
            drop(v794_10);
            let v794_13: Space = map_map_kernels::unite(&(v794_8),&(v794_12));
            v793_7.join_into((v794_13).clone());
            }
            v793_7_cursor.ascend(1);
          }
          drop(v793_7_cursor);
          map_map_kernels::compose(&(v792_5),&(v793_7))
        };
        drop(v792_5);
        let v792_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v792_2));
        drop(v792_2);
        let v792_10: Space = if map_kernels::has_head(&(v792_9)) { singleton(&[]) } else { Space::new() };
        drop(v792_9);
        let v792_12: Space = if (v792_10).is_empty() { Space::new() } else {
          let v797_6: Path = concat_path(&(v791_6),&(v791_7_head));
          let mut v797_11 = Space::new();
          let mut v797_11_cursor = (v791_7_tail).read_zipper();
          for v797_11_byte in v797_11_cursor.child_mask().iter() {
            v797_11_cursor.descend_to_byte(v797_11_byte);
            {
            let v797_11_tail = v797_11_cursor.fork_read_zipper();
            let v797_11_head = Path::from_slice(&[v797_11_byte]);
            let v798_2: Space = singleton(&(v797_11_head));
            let v798_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v798_2));
            let v798_4: Space = if map_kernels::has_head(&(v798_3)) { singleton(&[]) } else { Space::new() };
            drop(v798_3);
            let v798_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v798_4));
            drop(v798_4);
            let v798_8: Space = if (v798_5).is_empty() { Space::new() } else {
              let v799_6: Path = concat_path(&(v797_6),&(v797_11_head));
              let v799_7: Space = routine_60(c, &(v799_6), &(v797_11_tail).make_space());
              map_map_kernels::compose(&(v798_5),&(v799_7))
            };
            drop(v798_5);
            let v798_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v798_2));
            drop(v798_2);
            let v798_10: Space = if map_kernels::has_head(&(v798_9)) { singleton(&[]) } else { Space::new() };
            drop(v798_9);
            let v798_12: Space = if (v798_10).is_empty() { Space::new() } else {
              let v800_6: Path = concat_path(&(v797_6),&(v797_11_head));
              let v800_11: Space = routine_15(c, &(v800_6), &(v797_11_tail).make_space());
              drop(v800_6);
              map_map_kernels::compose(&(v798_10),&(v800_11))
            };
            drop(v798_10);
            let v798_13: Space = map_map_kernels::unite(&(v798_8),&(v798_12));
            v797_11.join_into((v798_13).clone());
            }
            v797_11_cursor.ascend(1);
          }
          drop(v797_11_cursor);
          drop(v797_6);
          map_map_kernels::compose(&(v792_10),&(v797_11))
        };
        drop(v792_10);
        let v792_13: Space = map_map_kernels::unite(&(v792_8),&(v792_12));
        v791_7.join_into((v792_13).clone());
        }
        v791_7_cursor.ascend(1);
      }
      drop(v791_7_cursor);
      map_map_kernels::compose(&(v790_5),&(v791_7))
    };
    drop(v790_5);
    let v790_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v790_2));
    drop(v790_2);
    let v790_10: Space = if map_kernels::has_head(&(v790_9)) { singleton(&[]) } else { Space::new() };
    drop(v790_9);
    let v790_12: Space = if (v790_10).is_empty() { Space::new() } else {
      let v801_6: Path = concat_path(&(*p0),&(v789_20_head));
      let mut v801_11 = Space::new();
      let mut v801_11_cursor = (v789_20_tail).read_zipper();
      for v801_11_byte in v801_11_cursor.child_mask().iter() {
        v801_11_cursor.descend_to_byte(v801_11_byte);
        {
        let v801_11_tail = v801_11_cursor.fork_read_zipper();
        let v801_11_head = Path::from_slice(&[v801_11_byte]);
        let v802_2: Space = singleton(&(v801_11_head));
        let v802_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v802_2));
        let v802_4: Space = if map_kernels::has_head(&(v802_3)) { singleton(&[]) } else { Space::new() };
        drop(v802_3);
        let v802_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v802_4));
        drop(v802_4);
        let v802_8: Space = if (v802_5).is_empty() { Space::new() } else {
          let v803_6: Path = concat_path(&(v801_6),&(v801_11_head));
          let mut v803_7 = Space::new();
          let mut v803_7_cursor = (v801_11_tail).read_zipper();
          for v803_7_byte in v803_7_cursor.child_mask().iter() {
            v803_7_cursor.descend_to_byte(v803_7_byte);
            {
            let v803_7_tail = v803_7_cursor.fork_read_zipper();
            let v803_7_head = Path::from_slice(&[v803_7_byte]);
            let v804_2: Space = singleton(&(v803_7_head));
            let v804_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v804_2));
            let v804_4: Space = if map_kernels::has_head(&(v804_3)) { singleton(&[]) } else { Space::new() };
            drop(v804_3);
            let v804_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v804_4));
            drop(v804_4);
            let v804_8: Space = if (v804_5).is_empty() { Space::new() } else {
              let v805_6: Path = concat_path(&(v803_6),&(v803_7_head));
              let v805_7: Space = routine_60(c, &(v805_6), &(v803_7_tail).make_space());
              map_map_kernels::compose(&(v804_5),&(v805_7))
            };
            drop(v804_5);
            let v804_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v804_2));
            drop(v804_2);
            let v804_10: Space = if map_kernels::has_head(&(v804_9)) { singleton(&[]) } else { Space::new() };
            drop(v804_9);
            let v804_12: Space = if (v804_10).is_empty() { Space::new() } else {
              let v806_6: Path = concat_path(&(v803_6),&(v803_7_head));
              let v806_11: Space = routine_61(c, &(v806_6), &(v803_7_tail).make_space());
              drop(v806_6);
              map_map_kernels::compose(&(v804_10),&(v806_11))
            };
            drop(v804_10);
            let v804_13: Space = map_map_kernels::unite(&(v804_8),&(v804_12));
            v803_7.join_into((v804_13).clone());
            }
            v803_7_cursor.ascend(1);
          }
          drop(v803_7_cursor);
          drop(v803_6);
          map_map_kernels::compose(&(v802_5),&(v803_7))
        };
        drop(v802_5);
        let v802_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v802_2));
        drop(v802_2);
        let v802_10: Space = if map_kernels::has_head(&(v802_9)) { singleton(&[]) } else { Space::new() };
        drop(v802_9);
        let v802_11: Space = map_view_kernels::compose(&(v802_10),&(v801_11_tail));
        drop(v802_10);
        let v802_12: Space = map_map_kernels::unite(&(v802_8),&(v802_11));
        drop(v802_11);
        v801_11.join_into((v802_12).clone());
        }
        v801_11_cursor.ascend(1);
      }
      drop(v801_11_cursor);
      drop(v801_6);
      map_map_kernels::compose(&(v790_10),&(v801_11))
    };
    drop(v790_10);
    let v790_13: Space = map_map_kernels::unite(&(v790_8),&(v790_12));
    v789_20.join_into((v790_13).clone());
    }
    v789_20_cursor.ascend(1);
  }
  drop(v789_20_cursor);
  (v789_20).clone()
}

fn routine_47(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v807_14 = Space::new();
  let mut v807_14_cursor = (*s0).read_zipper();
  for v807_14_byte in v807_14_cursor.child_mask().iter() {
    v807_14_cursor.descend_to_byte(v807_14_byte);
    {
    let v807_14_tail = v807_14_cursor.fork_read_zipper();
    let v807_14_head = Path::from_slice(&[v807_14_byte]);
    let v808_2: Space = singleton(&(v807_14_head));
    let v808_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v808_2));
    let v808_4: Space = if map_kernels::has_head(&(v808_3)) { singleton(&[]) } else { Space::new() };
    drop(v808_3);
    let v808_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v808_4));
    drop(v808_4);
    let v808_8: Space = if (v808_5).is_empty() { Space::new() } else {
      let v809_6: Path = concat_path(&(*p0),&(v807_14_head));
      let mut v809_7 = Space::new();
      let mut v809_7_cursor = (v807_14_tail).read_zipper();
      for v809_7_byte in v809_7_cursor.child_mask().iter() {
        v809_7_cursor.descend_to_byte(v809_7_byte);
        {
        let v809_7_tail = v809_7_cursor.fork_read_zipper();
        let v809_7_head = Path::from_slice(&[v809_7_byte]);
        let v810_2: Space = singleton(&(v809_7_head));
        let v810_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v810_2));
        let v810_4: Space = if map_kernels::has_head(&(v810_3)) { singleton(&[]) } else { Space::new() };
        drop(v810_3);
        let v810_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v810_4));
        drop(v810_4);
        let v810_8: Space = if (v810_5).is_empty() { Space::new() } else {
          let v811_6: Path = concat_path(&(v809_6),&(v809_7_head));
          let mut v811_7 = Space::new();
          let mut v811_7_cursor = (v809_7_tail).read_zipper();
          for v811_7_byte in v811_7_cursor.child_mask().iter() {
            v811_7_cursor.descend_to_byte(v811_7_byte);
            {
            let v811_7_tail = v811_7_cursor.fork_read_zipper();
            let v811_7_head = Path::from_slice(&[v811_7_byte]);
            let v812_2: Space = singleton(&(v811_7_head));
            let v812_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v812_2));
            let v812_4: Space = if map_kernels::has_head(&(v812_3)) { singleton(&[]) } else { Space::new() };
            drop(v812_3);
            let v812_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v812_4));
            drop(v812_4);
            let v812_8: Space = if (v812_5).is_empty() { Space::new() } else {
              let v813_6: Path = concat_path(&(v811_6),&(v811_7_head));
              let v813_7: Space = routine_60(c, &(v813_6), &(v811_7_tail).make_space());
              map_map_kernels::compose(&(v812_5),&(v813_7))
            };
            drop(v812_5);
            let v812_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v812_2));
            drop(v812_2);
            let v812_10: Space = if map_kernels::has_head(&(v812_9)) { singleton(&[]) } else { Space::new() };
            drop(v812_9);
            let v812_12: Space = if (v812_10).is_empty() { Space::new() } else {
              let v814_6: Path = concat_path(&(v811_6),&(v811_7_head));
              let v814_11: Space = routine_61(c, &(v814_6), &(v811_7_tail).make_space());
              drop(v814_6);
              map_map_kernels::compose(&(v812_10),&(v814_11))
            };
            drop(v812_10);
            let v812_13: Space = map_map_kernels::unite(&(v812_8),&(v812_12));
            v811_7.join_into((v812_13).clone());
            }
            v811_7_cursor.ascend(1);
          }
          drop(v811_7_cursor);
          map_map_kernels::compose(&(v810_5),&(v811_7))
        };
        drop(v810_5);
        let v810_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v810_2));
        drop(v810_2);
        let v810_10: Space = if map_kernels::has_head(&(v810_9)) { singleton(&[]) } else { Space::new() };
        drop(v810_9);
        let v810_12: Space = if (v810_10).is_empty() { Space::new() } else {
          let v815_6: Path = concat_path(&(v809_6),&(v809_7_head));
          let mut v815_11 = Space::new();
          let mut v815_11_cursor = (v809_7_tail).read_zipper();
          for v815_11_byte in v815_11_cursor.child_mask().iter() {
            v815_11_cursor.descend_to_byte(v815_11_byte);
            {
            let v815_11_tail = v815_11_cursor.fork_read_zipper();
            let v815_11_head = Path::from_slice(&[v815_11_byte]);
            let v816_2: Space = singleton(&(v815_11_head));
            let v816_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v816_2));
            let v816_4: Space = if map_kernels::has_head(&(v816_3)) { singleton(&[]) } else { Space::new() };
            drop(v816_3);
            let v816_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v816_4));
            drop(v816_4);
            let v816_8: Space = if (v816_5).is_empty() { Space::new() } else {
              let v817_6: Path = concat_path(&(v815_6),&(v815_11_head));
              let v817_7: Space = routine_60(c, &(v817_6), &(v815_11_tail).make_space());
              map_map_kernels::compose(&(v816_5),&(v817_7))
            };
            drop(v816_5);
            let v816_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v816_2));
            drop(v816_2);
            let v816_10: Space = if map_kernels::has_head(&(v816_9)) { singleton(&[]) } else { Space::new() };
            drop(v816_9);
            let v816_12: Space = if (v816_10).is_empty() { Space::new() } else {
              let v818_6: Path = concat_path(&(v815_6),&(v815_11_head));
              let v818_11: Space = routine_15(c, &(v818_6), &(v815_11_tail).make_space());
              drop(v818_6);
              map_map_kernels::compose(&(v816_10),&(v818_11))
            };
            drop(v816_10);
            let v816_13: Space = map_map_kernels::unite(&(v816_8),&(v816_12));
            v815_11.join_into((v816_13).clone());
            }
            v815_11_cursor.ascend(1);
          }
          drop(v815_11_cursor);
          drop(v815_6);
          map_map_kernels::compose(&(v810_10),&(v815_11))
        };
        drop(v810_10);
        let v810_13: Space = map_map_kernels::unite(&(v810_8),&(v810_12));
        v809_7.join_into((v810_13).clone());
        }
        v809_7_cursor.ascend(1);
      }
      drop(v809_7_cursor);
      drop(v809_6);
      map_map_kernels::compose(&(v808_5),&(v809_7))
    };
    drop(v808_5);
    let v808_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v808_2));
    drop(v808_2);
    let v808_10: Space = if map_kernels::has_head(&(v808_9)) { singleton(&[]) } else { Space::new() };
    drop(v808_9);
    let v808_11: Space = map_view_kernels::compose(&(v808_10),&(v807_14_tail));
    drop(v808_10);
    let v808_12: Space = map_map_kernels::unite(&(v808_8),&(v808_11));
    drop(v808_11);
    v807_14.join_into((v808_12).clone());
    }
    v807_14_cursor.ascend(1);
  }
  drop(v807_14_cursor);
  (v807_14).clone()
}

fn routine_48(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v819_3 = Space::new();
  let mut v819_3_cursor = (*s0).read_zipper();
  for v819_3_byte in v819_3_cursor.child_mask().iter() {
    v819_3_cursor.descend_to_byte(v819_3_byte);
    {
    let v819_3_tail = v819_3_cursor.fork_read_zipper();
    let v819_3_head = Path::from_slice(&[v819_3_byte]);
    let v820_2: Space = Space::new();
    v819_3.join_into((v820_2).clone());
    }
    v819_3_cursor.ascend(1);
  }
  drop(v819_3_cursor);
  (v819_3).clone()
}

fn routine_49(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v821_5: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_3));
  let v821_7: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_4));
  let v821_8: Space = map_kernels::unwrap(&(v821_7),&(*p0));
  let v821_10: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_5));
  let mut v821_29 = Space::new();
  let mut v821_29_cursor = (*s0).read_zipper();
  for v821_29_byte in v821_29_cursor.child_mask().iter() {
    v821_29_cursor.descend_to_byte(v821_29_byte);
    {
    let v821_29_tail = v821_29_cursor.fork_read_zipper();
    let v821_29_head = Path::from_slice(&[v821_29_byte]);
    let v822_2: Space = singleton(&(v821_29_head));
    let v822_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v822_2));
    drop(v822_2);
    let v822_4: Space = if map_kernels::has_head(&(v822_3)) { singleton(&[]) } else { Space::new() };
    drop(v822_3);
    let v822_12: Space = if (v822_4).is_empty() { Space::new() } else {
      let v823_5: Space = map_kernels::unwrap(&(v821_8),&(v821_29_head));
      let v823_6: Space = map_map_kernels::restrict_to(&(v821_7),&(v823_5));
      let mut v823_7 = Space::new();
      let mut v823_7_cursor = (v823_6).read_zipper();
      for v823_7_byte in v823_7_cursor.child_mask().iter() {
        v823_7_cursor.descend_to_byte(v823_7_byte);
        {
        let v823_7_tail = v823_7_cursor.fork_read_zipper();
        let v823_7_head = Path::from_slice(&[v823_7_byte]);
        let v824_2: Space = singleton(&(v823_7_head));
        let v824_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v824_2));
        let v824_4: Space = if map_kernels::has_head(&(v824_3)) { singleton(&[]) } else { Space::new() };
        drop(v824_3);
        let v824_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v824_4));
        drop(v824_4);
        let v824_7: Space = if (v824_5).is_empty() { Space::new() } else {
          let mut v825_6 = Space::new();
          let mut v825_6_cursor = (v823_7_tail).read_zipper();
          for v825_6_byte in v825_6_cursor.child_mask().iter() {
            v825_6_cursor.descend_to_byte(v825_6_byte);
            {
            let v825_6_tail = v825_6_cursor.fork_read_zipper();
            let v825_6_head = Path::from_slice(&[v825_6_byte]);
            let v826_2: Space = singleton(&(v825_6_head));
            let v826_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v826_2));
            let v826_4: Space = if map_kernels::has_head(&(v826_3)) { singleton(&[]) } else { Space::new() };
            drop(v826_3);
            let v826_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v826_4));
            drop(v826_4);
            let v826_8: Space = if (v826_5).is_empty() { Space::new() } else {
              let v827_6: Path = concat_path(&(v823_7_head),&(v825_6_head));
              let v827_7: Space = routine_10(c, &(v827_6), &(v825_6_tail).make_space());
              map_map_kernels::compose(&(v826_5),&(v827_7))
            };
            drop(v826_5);
            let v826_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v826_2));
            drop(v826_2);
            let v826_10: Space = if map_kernels::has_head(&(v826_9)) { singleton(&[]) } else { Space::new() };
            drop(v826_9);
            let v826_12: Space = if (v826_10).is_empty() { Space::new() } else {
              let v828_6: Path = concat_path(&(v823_7_head),&(v825_6_head));
              let v828_11: Space = routine_11(c, &(v828_6), &(v825_6_tail).make_space());
              drop(v828_6);
              map_map_kernels::compose(&(v826_10),&(v828_11))
            };
            drop(v826_10);
            let v826_13: Space = map_map_kernels::unite(&(v826_8),&(v826_12));
            v825_6.join_into((v826_13).clone());
            }
            v825_6_cursor.ascend(1);
          }
          drop(v825_6_cursor);
          map_map_kernels::compose(&(v824_5),&(v825_6))
        };
        drop(v824_5);
        let v824_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v824_2));
        drop(v824_2);
        let v824_9: Space = if map_kernels::has_head(&(v824_8)) { singleton(&[]) } else { Space::new() };
        drop(v824_8);
        let v824_11: Space = if (v824_9).is_empty() { Space::new() } else {
          let mut v829_10 = Space::new();
          let mut v829_10_cursor = (v823_7_tail).read_zipper();
          for v829_10_byte in v829_10_cursor.child_mask().iter() {
            v829_10_cursor.descend_to_byte(v829_10_byte);
            {
            let v829_10_tail = v829_10_cursor.fork_read_zipper();
            let v829_10_head = Path::from_slice(&[v829_10_byte]);
            let v830_2: Space = singleton(&(v829_10_head));
            let v830_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v830_2));
            let v830_4: Space = if map_kernels::has_head(&(v830_3)) { singleton(&[]) } else { Space::new() };
            drop(v830_3);
            let v830_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v830_4));
            drop(v830_4);
            let v830_8: Space = if (v830_5).is_empty() { Space::new() } else {
              let v831_6: Path = concat_path(&(v823_7_head),&(v829_10_head));
              let v831_7: Space = routine_10(c, &(v831_6), &(v829_10_tail).make_space());
              map_map_kernels::compose(&(v830_5),&(v831_7))
            };
            drop(v830_5);
            let v830_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v830_2));
            drop(v830_2);
            let v830_10: Space = if map_kernels::has_head(&(v830_9)) { singleton(&[]) } else { Space::new() };
            drop(v830_9);
            let v830_12: Space = if (v830_10).is_empty() { Space::new() } else {
              let v832_6: Path = concat_path(&(v823_7_head),&(v829_10_head));
              let v832_11: Space = routine_12(c, &(v832_6), &(v829_10_tail).make_space());
              drop(v832_6);
              map_map_kernels::compose(&(v830_10),&(v832_11))
            };
            drop(v830_10);
            let v830_13: Space = map_map_kernels::unite(&(v830_8),&(v830_12));
            v829_10.join_into((v830_13).clone());
            }
            v829_10_cursor.ascend(1);
          }
          drop(v829_10_cursor);
          map_map_kernels::compose(&(v824_9),&(v829_10))
        };
        drop(v824_9);
        let v824_12: Space = map_map_kernels::unite(&(v824_7),&(v824_11));
        v823_7.join_into((v824_12).clone());
        }
        v823_7_cursor.ascend(1);
      }
      drop(v823_7_cursor);
      drop(v823_6);
      let v823_8: Space = map_map_kernels::restrict_to(&(v821_5),&(v823_7));
      let mut v823_9 = Space::new();
      let mut v823_9_cursor = (v823_8).read_zipper();
      for v823_9_byte in v823_9_cursor.child_mask().iter() {
        v823_9_cursor.descend_to_byte(v823_9_byte);
        {
        let v823_9_tail = v823_9_cursor.fork_read_zipper();
        let v823_9_head = Path::from_slice(&[v823_9_byte]);
        let v833_2: Space = singleton(&(v823_9_head));
        let v833_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v833_2));
        let v833_4: Space = if map_kernels::has_head(&(v833_3)) { singleton(&[]) } else { Space::new() };
        drop(v833_3);
        let v833_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v833_4));
        drop(v833_4);
        let v833_7: Space = if (v833_5).is_empty() { Space::new() } else {
          let mut v834_6 = Space::new();
          let mut v834_6_cursor = (v823_9_tail).read_zipper();
          for v834_6_byte in v834_6_cursor.child_mask().iter() {
            v834_6_cursor.descend_to_byte(v834_6_byte);
            {
            let v834_6_tail = v834_6_cursor.fork_read_zipper();
            let v834_6_head = Path::from_slice(&[v834_6_byte]);
            let v835_2: Space = singleton(&(v834_6_head));
            let v835_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v835_2));
            let v835_4: Space = if map_kernels::has_head(&(v835_3)) { singleton(&[]) } else { Space::new() };
            drop(v835_3);
            let v835_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v835_4));
            drop(v835_4);
            let v835_8: Space = if (v835_5).is_empty() { Space::new() } else {
              let v836_6: Path = concat_path(&(v823_9_head),&(v834_6_head));
              let v836_7: Space = routine_13(c, &(v836_6), &(v834_6_tail).make_space());
              map_map_kernels::compose(&(v835_5),&(v836_7))
            };
            drop(v835_5);
            let v835_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v835_2));
            drop(v835_2);
            let v835_10: Space = if map_kernels::has_head(&(v835_9)) { singleton(&[]) } else { Space::new() };
            drop(v835_9);
            let v835_12: Space = if (v835_10).is_empty() { Space::new() } else {
              let v837_6: Path = concat_path(&(v823_9_head),&(v834_6_head));
              let v837_11: Space = routine_14(c, &(v837_6), &(v834_6_tail).make_space());
              drop(v837_6);
              map_map_kernels::compose(&(v835_10),&(v837_11))
            };
            drop(v835_10);
            let v835_13: Space = map_map_kernels::unite(&(v835_8),&(v835_12));
            v834_6.join_into((v835_13).clone());
            }
            v834_6_cursor.ascend(1);
          }
          drop(v834_6_cursor);
          map_map_kernels::compose(&(v833_5),&(v834_6))
        };
        drop(v833_5);
        let v833_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v833_2));
        drop(v833_2);
        let v833_9: Space = if map_kernels::has_head(&(v833_8)) { singleton(&[]) } else { Space::new() };
        drop(v833_8);
        let v833_11: Space = if (v833_9).is_empty() { Space::new() } else {
          let mut v838_10 = Space::new();
          let mut v838_10_cursor = (v823_9_tail).read_zipper();
          for v838_10_byte in v838_10_cursor.child_mask().iter() {
            v838_10_cursor.descend_to_byte(v838_10_byte);
            {
            let v838_10_tail = v838_10_cursor.fork_read_zipper();
            let v838_10_head = Path::from_slice(&[v838_10_byte]);
            let v839_2: Space = singleton(&(v838_10_head));
            let v839_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v839_2));
            let v839_4: Space = if map_kernels::has_head(&(v839_3)) { singleton(&[]) } else { Space::new() };
            drop(v839_3);
            let v839_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v839_4));
            drop(v839_4);
            let v839_8: Space = if (v839_5).is_empty() { Space::new() } else {
              let v840_6: Path = concat_path(&(v823_9_head),&(v838_10_head));
              let v840_7: Space = routine_13(c, &(v840_6), &(v838_10_tail).make_space());
              map_map_kernels::compose(&(v839_5),&(v840_7))
            };
            drop(v839_5);
            let v839_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v839_2));
            drop(v839_2);
            let v839_10: Space = if map_kernels::has_head(&(v839_9)) { singleton(&[]) } else { Space::new() };
            drop(v839_9);
            let v839_12: Space = if (v839_10).is_empty() { Space::new() } else {
              let v841_6: Path = concat_path(&(v823_9_head),&(v838_10_head));
              let v841_11: Space = routine_15(c, &(v841_6), &(v838_10_tail).make_space());
              drop(v841_6);
              map_map_kernels::compose(&(v839_10),&(v841_11))
            };
            drop(v839_10);
            let v839_13: Space = map_map_kernels::unite(&(v839_8),&(v839_12));
            v838_10.join_into((v839_13).clone());
            }
            v838_10_cursor.ascend(1);
          }
          drop(v838_10_cursor);
          map_map_kernels::compose(&(v833_9),&(v838_10))
        };
        drop(v833_9);
        let v833_12: Space = map_map_kernels::unite(&(v833_7),&(v833_11));
        v823_9.join_into((v833_12).clone());
        }
        v823_9_cursor.ascend(1);
      }
      drop(v823_9_cursor);
      let v823_10: Space = map_map_kernels::subtract(&(v823_9),&(v823_5));
      drop(v823_5);
      let v823_11: Space = map_map_kernels::intersect(&(v823_10),&(v821_10));
      map_map_kernels::compose(&(v822_4),&(v823_11))
    };
    drop(v822_4);
    let v822_13: Path = concat_path(&(*p0),&(v821_29_head));
    let v822_14: Space = map_kernels::wrap(&(v822_12),&(v822_13));
    drop(v822_13);
    v821_29.join_into((v822_14).clone());
    }
    v821_29_cursor.ascend(1);
  }
  drop(v821_29_cursor);
  drop(v821_5);
  drop(v821_7);
  drop(v821_8);
  drop(v821_10);
  (v821_29).clone()
}

fn routine_50(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v842_20 = Space::new();
  let mut v842_20_cursor = (*s0).read_zipper();
  for v842_20_byte in v842_20_cursor.child_mask().iter() {
    v842_20_cursor.descend_to_byte(v842_20_byte);
    {
    let v842_20_tail = v842_20_cursor.fork_read_zipper();
    let v842_20_head = Path::from_slice(&[v842_20_byte]);
    let v843_2: Space = singleton(&(v842_20_head));
    let v843_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v843_2));
    let v843_4: Space = if map_kernels::has_head(&(v843_3)) { singleton(&[]) } else { Space::new() };
    drop(v843_3);
    let v843_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v843_4));
    drop(v843_4);
    let v843_8: Space = if (v843_5).is_empty() { Space::new() } else {
      let v844_6: Path = concat_path(&(*p0),&(v842_20_head));
      let mut v844_7 = Space::new();
      let mut v844_7_cursor = (v842_20_tail).read_zipper();
      for v844_7_byte in v844_7_cursor.child_mask().iter() {
        v844_7_cursor.descend_to_byte(v844_7_byte);
        {
        let v844_7_tail = v844_7_cursor.fork_read_zipper();
        let v844_7_head = Path::from_slice(&[v844_7_byte]);
        let v845_2: Space = singleton(&(v844_7_head));
        let v845_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v845_2));
        let v845_4: Space = if map_kernels::has_head(&(v845_3)) { singleton(&[]) } else { Space::new() };
        drop(v845_3);
        let v845_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v845_4));
        drop(v845_4);
        let v845_8: Space = if (v845_5).is_empty() { Space::new() } else {
          let v846_6: Path = concat_path(&(v844_6),&(v844_7_head));
          let mut v846_7 = Space::new();
          let mut v846_7_cursor = (v844_7_tail).read_zipper();
          for v846_7_byte in v846_7_cursor.child_mask().iter() {
            v846_7_cursor.descend_to_byte(v846_7_byte);
            {
            let v846_7_tail = v846_7_cursor.fork_read_zipper();
            let v846_7_head = Path::from_slice(&[v846_7_byte]);
            let v847_2: Space = singleton(&(v846_7_head));
            let v847_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v847_2));
            let v847_4: Space = if map_kernels::has_head(&(v847_3)) { singleton(&[]) } else { Space::new() };
            drop(v847_3);
            let v847_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v847_4));
            drop(v847_4);
            let v847_8: Space = if (v847_5).is_empty() { Space::new() } else {
              let v848_6: Path = concat_path(&(v846_6),&(v846_7_head));
              let v848_7: Space = routine_62(c, &(v848_6), &(v846_7_tail).make_space());
              map_map_kernels::compose(&(v847_5),&(v848_7))
            };
            drop(v847_5);
            let v847_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v847_2));
            drop(v847_2);
            let v847_10: Space = if map_kernels::has_head(&(v847_9)) { singleton(&[]) } else { Space::new() };
            drop(v847_9);
            let v847_12: Space = if (v847_10).is_empty() { Space::new() } else {
              let v849_6: Path = concat_path(&(v846_6),&(v846_7_head));
              let v849_11: Space = routine_63(c, &(v849_6), &(v846_7_tail).make_space());
              drop(v849_6);
              map_map_kernels::compose(&(v847_10),&(v849_11))
            };
            drop(v847_10);
            let v847_13: Space = map_map_kernels::unite(&(v847_8),&(v847_12));
            v846_7.join_into((v847_13).clone());
            }
            v846_7_cursor.ascend(1);
          }
          drop(v846_7_cursor);
          map_map_kernels::compose(&(v845_5),&(v846_7))
        };
        drop(v845_5);
        let v845_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v845_2));
        drop(v845_2);
        let v845_10: Space = if map_kernels::has_head(&(v845_9)) { singleton(&[]) } else { Space::new() };
        drop(v845_9);
        let v845_12: Space = if (v845_10).is_empty() { Space::new() } else {
          let v850_6: Path = concat_path(&(v844_6),&(v844_7_head));
          let mut v850_11 = Space::new();
          let mut v850_11_cursor = (v844_7_tail).read_zipper();
          for v850_11_byte in v850_11_cursor.child_mask().iter() {
            v850_11_cursor.descend_to_byte(v850_11_byte);
            {
            let v850_11_tail = v850_11_cursor.fork_read_zipper();
            let v850_11_head = Path::from_slice(&[v850_11_byte]);
            let v851_2: Space = singleton(&(v850_11_head));
            let v851_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v851_2));
            let v851_4: Space = if map_kernels::has_head(&(v851_3)) { singleton(&[]) } else { Space::new() };
            drop(v851_3);
            let v851_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v851_4));
            drop(v851_4);
            let v851_8: Space = if (v851_5).is_empty() { Space::new() } else {
              let v852_6: Path = concat_path(&(v850_6),&(v850_11_head));
              let v852_7: Space = routine_62(c, &(v852_6), &(v850_11_tail).make_space());
              map_map_kernels::compose(&(v851_5),&(v852_7))
            };
            drop(v851_5);
            let v851_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v851_2));
            drop(v851_2);
            let v851_10: Space = if map_kernels::has_head(&(v851_9)) { singleton(&[]) } else { Space::new() };
            drop(v851_9);
            let v851_12: Space = if (v851_10).is_empty() { Space::new() } else {
              let v853_6: Path = concat_path(&(v850_6),&(v850_11_head));
              let v853_11: Space = routine_12(c, &(v853_6), &(v850_11_tail).make_space());
              drop(v853_6);
              map_map_kernels::compose(&(v851_10),&(v853_11))
            };
            drop(v851_10);
            let v851_13: Space = map_map_kernels::unite(&(v851_8),&(v851_12));
            v850_11.join_into((v851_13).clone());
            }
            v850_11_cursor.ascend(1);
          }
          drop(v850_11_cursor);
          drop(v850_6);
          map_map_kernels::compose(&(v845_10),&(v850_11))
        };
        drop(v845_10);
        let v845_13: Space = map_map_kernels::unite(&(v845_8),&(v845_12));
        v844_7.join_into((v845_13).clone());
        }
        v844_7_cursor.ascend(1);
      }
      drop(v844_7_cursor);
      map_map_kernels::compose(&(v843_5),&(v844_7))
    };
    drop(v843_5);
    let v843_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v843_2));
    drop(v843_2);
    let v843_10: Space = if map_kernels::has_head(&(v843_9)) { singleton(&[]) } else { Space::new() };
    drop(v843_9);
    let v843_12: Space = if (v843_10).is_empty() { Space::new() } else {
      let v854_6: Path = concat_path(&(*p0),&(v842_20_head));
      let mut v854_11 = Space::new();
      let mut v854_11_cursor = (v842_20_tail).read_zipper();
      for v854_11_byte in v854_11_cursor.child_mask().iter() {
        v854_11_cursor.descend_to_byte(v854_11_byte);
        {
        let v854_11_tail = v854_11_cursor.fork_read_zipper();
        let v854_11_head = Path::from_slice(&[v854_11_byte]);
        let v855_2: Space = singleton(&(v854_11_head));
        let v855_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v855_2));
        let v855_4: Space = if map_kernels::has_head(&(v855_3)) { singleton(&[]) } else { Space::new() };
        drop(v855_3);
        let v855_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v855_4));
        drop(v855_4);
        let v855_8: Space = if (v855_5).is_empty() { Space::new() } else {
          let v856_6: Path = concat_path(&(v854_6),&(v854_11_head));
          let mut v856_7 = Space::new();
          let mut v856_7_cursor = (v854_11_tail).read_zipper();
          for v856_7_byte in v856_7_cursor.child_mask().iter() {
            v856_7_cursor.descend_to_byte(v856_7_byte);
            {
            let v856_7_tail = v856_7_cursor.fork_read_zipper();
            let v856_7_head = Path::from_slice(&[v856_7_byte]);
            let v857_2: Space = singleton(&(v856_7_head));
            let v857_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v857_2));
            let v857_4: Space = if map_kernels::has_head(&(v857_3)) { singleton(&[]) } else { Space::new() };
            drop(v857_3);
            let v857_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v857_4));
            drop(v857_4);
            let v857_8: Space = if (v857_5).is_empty() { Space::new() } else {
              let v858_6: Path = concat_path(&(v856_6),&(v856_7_head));
              let v858_7: Space = routine_62(c, &(v858_6), &(v856_7_tail).make_space());
              map_map_kernels::compose(&(v857_5),&(v858_7))
            };
            drop(v857_5);
            let v857_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v857_2));
            drop(v857_2);
            let v857_10: Space = if map_kernels::has_head(&(v857_9)) { singleton(&[]) } else { Space::new() };
            drop(v857_9);
            let v857_12: Space = if (v857_10).is_empty() { Space::new() } else {
              let v859_6: Path = concat_path(&(v856_6),&(v856_7_head));
              let v859_11: Space = routine_63(c, &(v859_6), &(v856_7_tail).make_space());
              drop(v859_6);
              map_map_kernels::compose(&(v857_10),&(v859_11))
            };
            drop(v857_10);
            let v857_13: Space = map_map_kernels::unite(&(v857_8),&(v857_12));
            v856_7.join_into((v857_13).clone());
            }
            v856_7_cursor.ascend(1);
          }
          drop(v856_7_cursor);
          drop(v856_6);
          map_map_kernels::compose(&(v855_5),&(v856_7))
        };
        drop(v855_5);
        let v855_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v855_2));
        drop(v855_2);
        let v855_10: Space = if map_kernels::has_head(&(v855_9)) { singleton(&[]) } else { Space::new() };
        drop(v855_9);
        let v855_11: Space = map_view_kernels::compose(&(v855_10),&(v854_11_tail));
        drop(v855_10);
        let v855_12: Space = map_map_kernels::unite(&(v855_8),&(v855_11));
        drop(v855_11);
        v854_11.join_into((v855_12).clone());
        }
        v854_11_cursor.ascend(1);
      }
      drop(v854_11_cursor);
      drop(v854_6);
      map_map_kernels::compose(&(v843_10),&(v854_11))
    };
    drop(v843_10);
    let v843_13: Space = map_map_kernels::unite(&(v843_8),&(v843_12));
    v842_20.join_into((v843_13).clone());
    }
    v842_20_cursor.ascend(1);
  }
  drop(v842_20_cursor);
  (v842_20).clone()
}

fn routine_51(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v860_14 = Space::new();
  let mut v860_14_cursor = (*s0).read_zipper();
  for v860_14_byte in v860_14_cursor.child_mask().iter() {
    v860_14_cursor.descend_to_byte(v860_14_byte);
    {
    let v860_14_tail = v860_14_cursor.fork_read_zipper();
    let v860_14_head = Path::from_slice(&[v860_14_byte]);
    let v861_2: Space = singleton(&(v860_14_head));
    let v861_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v861_2));
    let v861_4: Space = if map_kernels::has_head(&(v861_3)) { singleton(&[]) } else { Space::new() };
    drop(v861_3);
    let v861_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v861_4));
    drop(v861_4);
    let v861_8: Space = if (v861_5).is_empty() { Space::new() } else {
      let v862_6: Path = concat_path(&(*p0),&(v860_14_head));
      let mut v862_7 = Space::new();
      let mut v862_7_cursor = (v860_14_tail).read_zipper();
      for v862_7_byte in v862_7_cursor.child_mask().iter() {
        v862_7_cursor.descend_to_byte(v862_7_byte);
        {
        let v862_7_tail = v862_7_cursor.fork_read_zipper();
        let v862_7_head = Path::from_slice(&[v862_7_byte]);
        let v863_2: Space = singleton(&(v862_7_head));
        let v863_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v863_2));
        let v863_4: Space = if map_kernels::has_head(&(v863_3)) { singleton(&[]) } else { Space::new() };
        drop(v863_3);
        let v863_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v863_4));
        drop(v863_4);
        let v863_8: Space = if (v863_5).is_empty() { Space::new() } else {
          let v864_6: Path = concat_path(&(v862_6),&(v862_7_head));
          let mut v864_7 = Space::new();
          let mut v864_7_cursor = (v862_7_tail).read_zipper();
          for v864_7_byte in v864_7_cursor.child_mask().iter() {
            v864_7_cursor.descend_to_byte(v864_7_byte);
            {
            let v864_7_tail = v864_7_cursor.fork_read_zipper();
            let v864_7_head = Path::from_slice(&[v864_7_byte]);
            let v865_2: Space = singleton(&(v864_7_head));
            let v865_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v865_2));
            let v865_4: Space = if map_kernels::has_head(&(v865_3)) { singleton(&[]) } else { Space::new() };
            drop(v865_3);
            let v865_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v865_4));
            drop(v865_4);
            let v865_8: Space = if (v865_5).is_empty() { Space::new() } else {
              let v866_6: Path = concat_path(&(v864_6),&(v864_7_head));
              let v866_7: Space = routine_62(c, &(v866_6), &(v864_7_tail).make_space());
              map_map_kernels::compose(&(v865_5),&(v866_7))
            };
            drop(v865_5);
            let v865_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v865_2));
            drop(v865_2);
            let v865_10: Space = if map_kernels::has_head(&(v865_9)) { singleton(&[]) } else { Space::new() };
            drop(v865_9);
            let v865_12: Space = if (v865_10).is_empty() { Space::new() } else {
              let v867_6: Path = concat_path(&(v864_6),&(v864_7_head));
              let v867_11: Space = routine_63(c, &(v867_6), &(v864_7_tail).make_space());
              drop(v867_6);
              map_map_kernels::compose(&(v865_10),&(v867_11))
            };
            drop(v865_10);
            let v865_13: Space = map_map_kernels::unite(&(v865_8),&(v865_12));
            v864_7.join_into((v865_13).clone());
            }
            v864_7_cursor.ascend(1);
          }
          drop(v864_7_cursor);
          map_map_kernels::compose(&(v863_5),&(v864_7))
        };
        drop(v863_5);
        let v863_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v863_2));
        drop(v863_2);
        let v863_10: Space = if map_kernels::has_head(&(v863_9)) { singleton(&[]) } else { Space::new() };
        drop(v863_9);
        let v863_12: Space = if (v863_10).is_empty() { Space::new() } else {
          let v868_6: Path = concat_path(&(v862_6),&(v862_7_head));
          let mut v868_11 = Space::new();
          let mut v868_11_cursor = (v862_7_tail).read_zipper();
          for v868_11_byte in v868_11_cursor.child_mask().iter() {
            v868_11_cursor.descend_to_byte(v868_11_byte);
            {
            let v868_11_tail = v868_11_cursor.fork_read_zipper();
            let v868_11_head = Path::from_slice(&[v868_11_byte]);
            let v869_2: Space = singleton(&(v868_11_head));
            let v869_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v869_2));
            let v869_4: Space = if map_kernels::has_head(&(v869_3)) { singleton(&[]) } else { Space::new() };
            drop(v869_3);
            let v869_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v869_4));
            drop(v869_4);
            let v869_8: Space = if (v869_5).is_empty() { Space::new() } else {
              let v870_6: Path = concat_path(&(v868_6),&(v868_11_head));
              let v870_7: Space = routine_62(c, &(v870_6), &(v868_11_tail).make_space());
              map_map_kernels::compose(&(v869_5),&(v870_7))
            };
            drop(v869_5);
            let v869_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v869_2));
            drop(v869_2);
            let v869_10: Space = if map_kernels::has_head(&(v869_9)) { singleton(&[]) } else { Space::new() };
            drop(v869_9);
            let v869_12: Space = if (v869_10).is_empty() { Space::new() } else {
              let v871_6: Path = concat_path(&(v868_6),&(v868_11_head));
              let v871_11: Space = routine_12(c, &(v871_6), &(v868_11_tail).make_space());
              drop(v871_6);
              map_map_kernels::compose(&(v869_10),&(v871_11))
            };
            drop(v869_10);
            let v869_13: Space = map_map_kernels::unite(&(v869_8),&(v869_12));
            v868_11.join_into((v869_13).clone());
            }
            v868_11_cursor.ascend(1);
          }
          drop(v868_11_cursor);
          drop(v868_6);
          map_map_kernels::compose(&(v863_10),&(v868_11))
        };
        drop(v863_10);
        let v863_13: Space = map_map_kernels::unite(&(v863_8),&(v863_12));
        v862_7.join_into((v863_13).clone());
        }
        v862_7_cursor.ascend(1);
      }
      drop(v862_7_cursor);
      drop(v862_6);
      map_map_kernels::compose(&(v861_5),&(v862_7))
    };
    drop(v861_5);
    let v861_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v861_2));
    drop(v861_2);
    let v861_10: Space = if map_kernels::has_head(&(v861_9)) { singleton(&[]) } else { Space::new() };
    drop(v861_9);
    let v861_11: Space = map_view_kernels::compose(&(v861_10),&(v860_14_tail));
    drop(v861_10);
    let v861_12: Space = map_map_kernels::unite(&(v861_8),&(v861_11));
    drop(v861_11);
    v860_14.join_into((v861_12).clone());
    }
    v860_14_cursor.ascend(1);
  }
  drop(v860_14_cursor);
  (v860_14).clone()
}

fn routine_52(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v872_20 = Space::new();
  let mut v872_20_cursor = (*s0).read_zipper();
  for v872_20_byte in v872_20_cursor.child_mask().iter() {
    v872_20_cursor.descend_to_byte(v872_20_byte);
    {
    let v872_20_tail = v872_20_cursor.fork_read_zipper();
    let v872_20_head = Path::from_slice(&[v872_20_byte]);
    let v873_2: Space = singleton(&(v872_20_head));
    let v873_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v873_2));
    let v873_4: Space = if map_kernels::has_head(&(v873_3)) { singleton(&[]) } else { Space::new() };
    drop(v873_3);
    let v873_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v873_4));
    drop(v873_4);
    let v873_8: Space = if (v873_5).is_empty() { Space::new() } else {
      let v874_6: Path = concat_path(&(*p0),&(v872_20_head));
      let mut v874_7 = Space::new();
      let mut v874_7_cursor = (v872_20_tail).read_zipper();
      for v874_7_byte in v874_7_cursor.child_mask().iter() {
        v874_7_cursor.descend_to_byte(v874_7_byte);
        {
        let v874_7_tail = v874_7_cursor.fork_read_zipper();
        let v874_7_head = Path::from_slice(&[v874_7_byte]);
        let v875_2: Space = singleton(&(v874_7_head));
        let v875_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v875_2));
        let v875_4: Space = if map_kernels::has_head(&(v875_3)) { singleton(&[]) } else { Space::new() };
        drop(v875_3);
        let v875_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v875_4));
        drop(v875_4);
        let v875_8: Space = if (v875_5).is_empty() { Space::new() } else {
          let v876_6: Path = concat_path(&(v874_6),&(v874_7_head));
          let mut v876_7 = Space::new();
          let mut v876_7_cursor = (v874_7_tail).read_zipper();
          for v876_7_byte in v876_7_cursor.child_mask().iter() {
            v876_7_cursor.descend_to_byte(v876_7_byte);
            {
            let v876_7_tail = v876_7_cursor.fork_read_zipper();
            let v876_7_head = Path::from_slice(&[v876_7_byte]);
            let v877_2: Space = singleton(&(v876_7_head));
            let v877_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v877_2));
            let v877_4: Space = if map_kernels::has_head(&(v877_3)) { singleton(&[]) } else { Space::new() };
            drop(v877_3);
            let v877_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v877_4));
            drop(v877_4);
            let v877_8: Space = if (v877_5).is_empty() { Space::new() } else {
              let v878_6: Path = concat_path(&(v876_6),&(v876_7_head));
              let v878_7: Space = routine_64(c, &(v878_6), &(v876_7_tail).make_space());
              map_map_kernels::compose(&(v877_5),&(v878_7))
            };
            drop(v877_5);
            let v877_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v877_2));
            drop(v877_2);
            let v877_10: Space = if map_kernels::has_head(&(v877_9)) { singleton(&[]) } else { Space::new() };
            drop(v877_9);
            let v877_12: Space = if (v877_10).is_empty() { Space::new() } else {
              let v879_6: Path = concat_path(&(v876_6),&(v876_7_head));
              let v879_11: Space = routine_65(c, &(v879_6), &(v876_7_tail).make_space());
              drop(v879_6);
              map_map_kernels::compose(&(v877_10),&(v879_11))
            };
            drop(v877_10);
            let v877_13: Space = map_map_kernels::unite(&(v877_8),&(v877_12));
            v876_7.join_into((v877_13).clone());
            }
            v876_7_cursor.ascend(1);
          }
          drop(v876_7_cursor);
          map_map_kernels::compose(&(v875_5),&(v876_7))
        };
        drop(v875_5);
        let v875_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v875_2));
        drop(v875_2);
        let v875_10: Space = if map_kernels::has_head(&(v875_9)) { singleton(&[]) } else { Space::new() };
        drop(v875_9);
        let v875_12: Space = if (v875_10).is_empty() { Space::new() } else {
          let v880_6: Path = concat_path(&(v874_6),&(v874_7_head));
          let mut v880_11 = Space::new();
          let mut v880_11_cursor = (v874_7_tail).read_zipper();
          for v880_11_byte in v880_11_cursor.child_mask().iter() {
            v880_11_cursor.descend_to_byte(v880_11_byte);
            {
            let v880_11_tail = v880_11_cursor.fork_read_zipper();
            let v880_11_head = Path::from_slice(&[v880_11_byte]);
            let v881_2: Space = singleton(&(v880_11_head));
            let v881_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v881_2));
            let v881_4: Space = if map_kernels::has_head(&(v881_3)) { singleton(&[]) } else { Space::new() };
            drop(v881_3);
            let v881_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v881_4));
            drop(v881_4);
            let v881_8: Space = if (v881_5).is_empty() { Space::new() } else {
              let v882_6: Path = concat_path(&(v880_6),&(v880_11_head));
              let v882_7: Space = routine_64(c, &(v882_6), &(v880_11_tail).make_space());
              map_map_kernels::compose(&(v881_5),&(v882_7))
            };
            drop(v881_5);
            let v881_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v881_2));
            drop(v881_2);
            let v881_10: Space = if map_kernels::has_head(&(v881_9)) { singleton(&[]) } else { Space::new() };
            drop(v881_9);
            let v881_12: Space = if (v881_10).is_empty() { Space::new() } else {
              let v883_6: Path = concat_path(&(v880_6),&(v880_11_head));
              let v883_11: Space = routine_15(c, &(v883_6), &(v880_11_tail).make_space());
              drop(v883_6);
              map_map_kernels::compose(&(v881_10),&(v883_11))
            };
            drop(v881_10);
            let v881_13: Space = map_map_kernels::unite(&(v881_8),&(v881_12));
            v880_11.join_into((v881_13).clone());
            }
            v880_11_cursor.ascend(1);
          }
          drop(v880_11_cursor);
          drop(v880_6);
          map_map_kernels::compose(&(v875_10),&(v880_11))
        };
        drop(v875_10);
        let v875_13: Space = map_map_kernels::unite(&(v875_8),&(v875_12));
        v874_7.join_into((v875_13).clone());
        }
        v874_7_cursor.ascend(1);
      }
      drop(v874_7_cursor);
      map_map_kernels::compose(&(v873_5),&(v874_7))
    };
    drop(v873_5);
    let v873_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v873_2));
    drop(v873_2);
    let v873_10: Space = if map_kernels::has_head(&(v873_9)) { singleton(&[]) } else { Space::new() };
    drop(v873_9);
    let v873_12: Space = if (v873_10).is_empty() { Space::new() } else {
      let v884_6: Path = concat_path(&(*p0),&(v872_20_head));
      let mut v884_11 = Space::new();
      let mut v884_11_cursor = (v872_20_tail).read_zipper();
      for v884_11_byte in v884_11_cursor.child_mask().iter() {
        v884_11_cursor.descend_to_byte(v884_11_byte);
        {
        let v884_11_tail = v884_11_cursor.fork_read_zipper();
        let v884_11_head = Path::from_slice(&[v884_11_byte]);
        let v885_2: Space = singleton(&(v884_11_head));
        let v885_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v885_2));
        let v885_4: Space = if map_kernels::has_head(&(v885_3)) { singleton(&[]) } else { Space::new() };
        drop(v885_3);
        let v885_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v885_4));
        drop(v885_4);
        let v885_8: Space = if (v885_5).is_empty() { Space::new() } else {
          let v886_6: Path = concat_path(&(v884_6),&(v884_11_head));
          let mut v886_7 = Space::new();
          let mut v886_7_cursor = (v884_11_tail).read_zipper();
          for v886_7_byte in v886_7_cursor.child_mask().iter() {
            v886_7_cursor.descend_to_byte(v886_7_byte);
            {
            let v886_7_tail = v886_7_cursor.fork_read_zipper();
            let v886_7_head = Path::from_slice(&[v886_7_byte]);
            let v887_2: Space = singleton(&(v886_7_head));
            let v887_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v887_2));
            let v887_4: Space = if map_kernels::has_head(&(v887_3)) { singleton(&[]) } else { Space::new() };
            drop(v887_3);
            let v887_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v887_4));
            drop(v887_4);
            let v887_8: Space = if (v887_5).is_empty() { Space::new() } else {
              let v888_6: Path = concat_path(&(v886_6),&(v886_7_head));
              let v888_7: Space = routine_64(c, &(v888_6), &(v886_7_tail).make_space());
              map_map_kernels::compose(&(v887_5),&(v888_7))
            };
            drop(v887_5);
            let v887_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v887_2));
            drop(v887_2);
            let v887_10: Space = if map_kernels::has_head(&(v887_9)) { singleton(&[]) } else { Space::new() };
            drop(v887_9);
            let v887_12: Space = if (v887_10).is_empty() { Space::new() } else {
              let v889_6: Path = concat_path(&(v886_6),&(v886_7_head));
              let v889_11: Space = routine_65(c, &(v889_6), &(v886_7_tail).make_space());
              drop(v889_6);
              map_map_kernels::compose(&(v887_10),&(v889_11))
            };
            drop(v887_10);
            let v887_13: Space = map_map_kernels::unite(&(v887_8),&(v887_12));
            v886_7.join_into((v887_13).clone());
            }
            v886_7_cursor.ascend(1);
          }
          drop(v886_7_cursor);
          drop(v886_6);
          map_map_kernels::compose(&(v885_5),&(v886_7))
        };
        drop(v885_5);
        let v885_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v885_2));
        drop(v885_2);
        let v885_10: Space = if map_kernels::has_head(&(v885_9)) { singleton(&[]) } else { Space::new() };
        drop(v885_9);
        let v885_11: Space = map_view_kernels::compose(&(v885_10),&(v884_11_tail));
        drop(v885_10);
        let v885_12: Space = map_map_kernels::unite(&(v885_8),&(v885_11));
        drop(v885_11);
        v884_11.join_into((v885_12).clone());
        }
        v884_11_cursor.ascend(1);
      }
      drop(v884_11_cursor);
      drop(v884_6);
      map_map_kernels::compose(&(v873_10),&(v884_11))
    };
    drop(v873_10);
    let v873_13: Space = map_map_kernels::unite(&(v873_8),&(v873_12));
    v872_20.join_into((v873_13).clone());
    }
    v872_20_cursor.ascend(1);
  }
  drop(v872_20_cursor);
  (v872_20).clone()
}

fn routine_53(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v890_14 = Space::new();
  let mut v890_14_cursor = (*s0).read_zipper();
  for v890_14_byte in v890_14_cursor.child_mask().iter() {
    v890_14_cursor.descend_to_byte(v890_14_byte);
    {
    let v890_14_tail = v890_14_cursor.fork_read_zipper();
    let v890_14_head = Path::from_slice(&[v890_14_byte]);
    let v891_2: Space = singleton(&(v890_14_head));
    let v891_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v891_2));
    let v891_4: Space = if map_kernels::has_head(&(v891_3)) { singleton(&[]) } else { Space::new() };
    drop(v891_3);
    let v891_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v891_4));
    drop(v891_4);
    let v891_8: Space = if (v891_5).is_empty() { Space::new() } else {
      let v892_6: Path = concat_path(&(*p0),&(v890_14_head));
      let mut v892_7 = Space::new();
      let mut v892_7_cursor = (v890_14_tail).read_zipper();
      for v892_7_byte in v892_7_cursor.child_mask().iter() {
        v892_7_cursor.descend_to_byte(v892_7_byte);
        {
        let v892_7_tail = v892_7_cursor.fork_read_zipper();
        let v892_7_head = Path::from_slice(&[v892_7_byte]);
        let v893_2: Space = singleton(&(v892_7_head));
        let v893_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v893_2));
        let v893_4: Space = if map_kernels::has_head(&(v893_3)) { singleton(&[]) } else { Space::new() };
        drop(v893_3);
        let v893_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v893_4));
        drop(v893_4);
        let v893_8: Space = if (v893_5).is_empty() { Space::new() } else {
          let v894_6: Path = concat_path(&(v892_6),&(v892_7_head));
          let mut v894_7 = Space::new();
          let mut v894_7_cursor = (v892_7_tail).read_zipper();
          for v894_7_byte in v894_7_cursor.child_mask().iter() {
            v894_7_cursor.descend_to_byte(v894_7_byte);
            {
            let v894_7_tail = v894_7_cursor.fork_read_zipper();
            let v894_7_head = Path::from_slice(&[v894_7_byte]);
            let v895_2: Space = singleton(&(v894_7_head));
            let v895_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v895_2));
            let v895_4: Space = if map_kernels::has_head(&(v895_3)) { singleton(&[]) } else { Space::new() };
            drop(v895_3);
            let v895_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v895_4));
            drop(v895_4);
            let v895_8: Space = if (v895_5).is_empty() { Space::new() } else {
              let v896_6: Path = concat_path(&(v894_6),&(v894_7_head));
              let v896_7: Space = routine_64(c, &(v896_6), &(v894_7_tail).make_space());
              map_map_kernels::compose(&(v895_5),&(v896_7))
            };
            drop(v895_5);
            let v895_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v895_2));
            drop(v895_2);
            let v895_10: Space = if map_kernels::has_head(&(v895_9)) { singleton(&[]) } else { Space::new() };
            drop(v895_9);
            let v895_12: Space = if (v895_10).is_empty() { Space::new() } else {
              let v897_6: Path = concat_path(&(v894_6),&(v894_7_head));
              let v897_11: Space = routine_65(c, &(v897_6), &(v894_7_tail).make_space());
              drop(v897_6);
              map_map_kernels::compose(&(v895_10),&(v897_11))
            };
            drop(v895_10);
            let v895_13: Space = map_map_kernels::unite(&(v895_8),&(v895_12));
            v894_7.join_into((v895_13).clone());
            }
            v894_7_cursor.ascend(1);
          }
          drop(v894_7_cursor);
          map_map_kernels::compose(&(v893_5),&(v894_7))
        };
        drop(v893_5);
        let v893_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v893_2));
        drop(v893_2);
        let v893_10: Space = if map_kernels::has_head(&(v893_9)) { singleton(&[]) } else { Space::new() };
        drop(v893_9);
        let v893_12: Space = if (v893_10).is_empty() { Space::new() } else {
          let v898_6: Path = concat_path(&(v892_6),&(v892_7_head));
          let mut v898_11 = Space::new();
          let mut v898_11_cursor = (v892_7_tail).read_zipper();
          for v898_11_byte in v898_11_cursor.child_mask().iter() {
            v898_11_cursor.descend_to_byte(v898_11_byte);
            {
            let v898_11_tail = v898_11_cursor.fork_read_zipper();
            let v898_11_head = Path::from_slice(&[v898_11_byte]);
            let v899_2: Space = singleton(&(v898_11_head));
            let v899_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v899_2));
            let v899_4: Space = if map_kernels::has_head(&(v899_3)) { singleton(&[]) } else { Space::new() };
            drop(v899_3);
            let v899_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v899_4));
            drop(v899_4);
            let v899_8: Space = if (v899_5).is_empty() { Space::new() } else {
              let v900_6: Path = concat_path(&(v898_6),&(v898_11_head));
              let v900_7: Space = routine_64(c, &(v900_6), &(v898_11_tail).make_space());
              map_map_kernels::compose(&(v899_5),&(v900_7))
            };
            drop(v899_5);
            let v899_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v899_2));
            drop(v899_2);
            let v899_10: Space = if map_kernels::has_head(&(v899_9)) { singleton(&[]) } else { Space::new() };
            drop(v899_9);
            let v899_12: Space = if (v899_10).is_empty() { Space::new() } else {
              let v901_6: Path = concat_path(&(v898_6),&(v898_11_head));
              let v901_11: Space = routine_15(c, &(v901_6), &(v898_11_tail).make_space());
              drop(v901_6);
              map_map_kernels::compose(&(v899_10),&(v901_11))
            };
            drop(v899_10);
            let v899_13: Space = map_map_kernels::unite(&(v899_8),&(v899_12));
            v898_11.join_into((v899_13).clone());
            }
            v898_11_cursor.ascend(1);
          }
          drop(v898_11_cursor);
          drop(v898_6);
          map_map_kernels::compose(&(v893_10),&(v898_11))
        };
        drop(v893_10);
        let v893_13: Space = map_map_kernels::unite(&(v893_8),&(v893_12));
        v892_7.join_into((v893_13).clone());
        }
        v892_7_cursor.ascend(1);
      }
      drop(v892_7_cursor);
      drop(v892_6);
      map_map_kernels::compose(&(v891_5),&(v892_7))
    };
    drop(v891_5);
    let v891_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v891_2));
    drop(v891_2);
    let v891_10: Space = if map_kernels::has_head(&(v891_9)) { singleton(&[]) } else { Space::new() };
    drop(v891_9);
    let v891_11: Space = map_view_kernels::compose(&(v891_10),&(v890_14_tail));
    drop(v891_10);
    let v891_12: Space = map_map_kernels::unite(&(v891_8),&(v891_11));
    drop(v891_11);
    v890_14.join_into((v891_12).clone());
    }
    v890_14_cursor.ascend(1);
  }
  drop(v890_14_cursor);
  (v890_14).clone()
}

fn routine_54(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v902_20 = Space::new();
  let mut v902_20_cursor = (*s0).read_zipper();
  for v902_20_byte in v902_20_cursor.child_mask().iter() {
    v902_20_cursor.descend_to_byte(v902_20_byte);
    {
    let v902_20_tail = v902_20_cursor.fork_read_zipper();
    let v902_20_head = Path::from_slice(&[v902_20_byte]);
    let v903_2: Space = singleton(&(v902_20_head));
    let v903_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v903_2));
    let v903_4: Space = if map_kernels::has_head(&(v903_3)) { singleton(&[]) } else { Space::new() };
    drop(v903_3);
    let v903_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v903_4));
    drop(v903_4);
    let v903_8: Space = if (v903_5).is_empty() { Space::new() } else {
      let v904_6: Path = concat_path(&(*p0),&(v902_20_head));
      let mut v904_7 = Space::new();
      let mut v904_7_cursor = (v902_20_tail).read_zipper();
      for v904_7_byte in v904_7_cursor.child_mask().iter() {
        v904_7_cursor.descend_to_byte(v904_7_byte);
        {
        let v904_7_tail = v904_7_cursor.fork_read_zipper();
        let v904_7_head = Path::from_slice(&[v904_7_byte]);
        let v905_2: Space = singleton(&(v904_7_head));
        let v905_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v905_2));
        let v905_4: Space = if map_kernels::has_head(&(v905_3)) { singleton(&[]) } else { Space::new() };
        drop(v905_3);
        let v905_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v905_4));
        drop(v905_4);
        let v905_8: Space = if (v905_5).is_empty() { Space::new() } else {
          let v906_6: Path = concat_path(&(v904_6),&(v904_7_head));
          let mut v906_7 = Space::new();
          let mut v906_7_cursor = (v904_7_tail).read_zipper();
          for v906_7_byte in v906_7_cursor.child_mask().iter() {
            v906_7_cursor.descend_to_byte(v906_7_byte);
            {
            let v906_7_tail = v906_7_cursor.fork_read_zipper();
            let v906_7_head = Path::from_slice(&[v906_7_byte]);
            let v907_2: Space = singleton(&(v906_7_head));
            let v907_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v907_2));
            let v907_4: Space = if map_kernels::has_head(&(v907_3)) { singleton(&[]) } else { Space::new() };
            drop(v907_3);
            let v907_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v907_4));
            drop(v907_4);
            let v907_8: Space = if (v907_5).is_empty() { Space::new() } else {
              let v908_6: Path = concat_path(&(v906_6),&(v906_7_head));
              let v908_7: Space = routine_66(c, &(v908_6), &(v906_7_tail).make_space());
              map_map_kernels::compose(&(v907_5),&(v908_7))
            };
            drop(v907_5);
            let v907_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v907_2));
            drop(v907_2);
            let v907_10: Space = if map_kernels::has_head(&(v907_9)) { singleton(&[]) } else { Space::new() };
            drop(v907_9);
            let v907_12: Space = if (v907_10).is_empty() { Space::new() } else {
              let v909_6: Path = concat_path(&(v906_6),&(v906_7_head));
              let v909_11: Space = routine_67(c, &(v909_6), &(v906_7_tail).make_space());
              drop(v909_6);
              map_map_kernels::compose(&(v907_10),&(v909_11))
            };
            drop(v907_10);
            let v907_13: Space = map_map_kernels::unite(&(v907_8),&(v907_12));
            v906_7.join_into((v907_13).clone());
            }
            v906_7_cursor.ascend(1);
          }
          drop(v906_7_cursor);
          map_map_kernels::compose(&(v905_5),&(v906_7))
        };
        drop(v905_5);
        let v905_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v905_2));
        drop(v905_2);
        let v905_10: Space = if map_kernels::has_head(&(v905_9)) { singleton(&[]) } else { Space::new() };
        drop(v905_9);
        let v905_12: Space = if (v905_10).is_empty() { Space::new() } else {
          let v910_6: Path = concat_path(&(v904_6),&(v904_7_head));
          let mut v910_11 = Space::new();
          let mut v910_11_cursor = (v904_7_tail).read_zipper();
          for v910_11_byte in v910_11_cursor.child_mask().iter() {
            v910_11_cursor.descend_to_byte(v910_11_byte);
            {
            let v910_11_tail = v910_11_cursor.fork_read_zipper();
            let v910_11_head = Path::from_slice(&[v910_11_byte]);
            let v911_2: Space = singleton(&(v910_11_head));
            let v911_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v911_2));
            let v911_4: Space = if map_kernels::has_head(&(v911_3)) { singleton(&[]) } else { Space::new() };
            drop(v911_3);
            let v911_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v911_4));
            drop(v911_4);
            let v911_8: Space = if (v911_5).is_empty() { Space::new() } else {
              let v912_6: Path = concat_path(&(v910_6),&(v910_11_head));
              let v912_7: Space = routine_66(c, &(v912_6), &(v910_11_tail).make_space());
              map_map_kernels::compose(&(v911_5),&(v912_7))
            };
            drop(v911_5);
            let v911_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v911_2));
            drop(v911_2);
            let v911_10: Space = if map_kernels::has_head(&(v911_9)) { singleton(&[]) } else { Space::new() };
            drop(v911_9);
            let v911_12: Space = if (v911_10).is_empty() { Space::new() } else {
              let v913_6: Path = concat_path(&(v910_6),&(v910_11_head));
              let v913_11: Space = routine_12(c, &(v913_6), &(v910_11_tail).make_space());
              drop(v913_6);
              map_map_kernels::compose(&(v911_10),&(v913_11))
            };
            drop(v911_10);
            let v911_13: Space = map_map_kernels::unite(&(v911_8),&(v911_12));
            v910_11.join_into((v911_13).clone());
            }
            v910_11_cursor.ascend(1);
          }
          drop(v910_11_cursor);
          drop(v910_6);
          map_map_kernels::compose(&(v905_10),&(v910_11))
        };
        drop(v905_10);
        let v905_13: Space = map_map_kernels::unite(&(v905_8),&(v905_12));
        v904_7.join_into((v905_13).clone());
        }
        v904_7_cursor.ascend(1);
      }
      drop(v904_7_cursor);
      map_map_kernels::compose(&(v903_5),&(v904_7))
    };
    drop(v903_5);
    let v903_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v903_2));
    drop(v903_2);
    let v903_10: Space = if map_kernels::has_head(&(v903_9)) { singleton(&[]) } else { Space::new() };
    drop(v903_9);
    let v903_12: Space = if (v903_10).is_empty() { Space::new() } else {
      let v914_6: Path = concat_path(&(*p0),&(v902_20_head));
      let mut v914_11 = Space::new();
      let mut v914_11_cursor = (v902_20_tail).read_zipper();
      for v914_11_byte in v914_11_cursor.child_mask().iter() {
        v914_11_cursor.descend_to_byte(v914_11_byte);
        {
        let v914_11_tail = v914_11_cursor.fork_read_zipper();
        let v914_11_head = Path::from_slice(&[v914_11_byte]);
        let v915_2: Space = singleton(&(v914_11_head));
        let v915_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v915_2));
        let v915_4: Space = if map_kernels::has_head(&(v915_3)) { singleton(&[]) } else { Space::new() };
        drop(v915_3);
        let v915_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v915_4));
        drop(v915_4);
        let v915_8: Space = if (v915_5).is_empty() { Space::new() } else {
          let v916_6: Path = concat_path(&(v914_6),&(v914_11_head));
          let mut v916_7 = Space::new();
          let mut v916_7_cursor = (v914_11_tail).read_zipper();
          for v916_7_byte in v916_7_cursor.child_mask().iter() {
            v916_7_cursor.descend_to_byte(v916_7_byte);
            {
            let v916_7_tail = v916_7_cursor.fork_read_zipper();
            let v916_7_head = Path::from_slice(&[v916_7_byte]);
            let v917_2: Space = singleton(&(v916_7_head));
            let v917_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v917_2));
            let v917_4: Space = if map_kernels::has_head(&(v917_3)) { singleton(&[]) } else { Space::new() };
            drop(v917_3);
            let v917_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v917_4));
            drop(v917_4);
            let v917_8: Space = if (v917_5).is_empty() { Space::new() } else {
              let v918_6: Path = concat_path(&(v916_6),&(v916_7_head));
              let v918_7: Space = routine_66(c, &(v918_6), &(v916_7_tail).make_space());
              map_map_kernels::compose(&(v917_5),&(v918_7))
            };
            drop(v917_5);
            let v917_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v917_2));
            drop(v917_2);
            let v917_10: Space = if map_kernels::has_head(&(v917_9)) { singleton(&[]) } else { Space::new() };
            drop(v917_9);
            let v917_12: Space = if (v917_10).is_empty() { Space::new() } else {
              let v919_6: Path = concat_path(&(v916_6),&(v916_7_head));
              let v919_11: Space = routine_67(c, &(v919_6), &(v916_7_tail).make_space());
              drop(v919_6);
              map_map_kernels::compose(&(v917_10),&(v919_11))
            };
            drop(v917_10);
            let v917_13: Space = map_map_kernels::unite(&(v917_8),&(v917_12));
            v916_7.join_into((v917_13).clone());
            }
            v916_7_cursor.ascend(1);
          }
          drop(v916_7_cursor);
          drop(v916_6);
          map_map_kernels::compose(&(v915_5),&(v916_7))
        };
        drop(v915_5);
        let v915_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v915_2));
        drop(v915_2);
        let v915_10: Space = if map_kernels::has_head(&(v915_9)) { singleton(&[]) } else { Space::new() };
        drop(v915_9);
        let v915_11: Space = map_view_kernels::compose(&(v915_10),&(v914_11_tail));
        drop(v915_10);
        let v915_12: Space = map_map_kernels::unite(&(v915_8),&(v915_11));
        drop(v915_11);
        v914_11.join_into((v915_12).clone());
        }
        v914_11_cursor.ascend(1);
      }
      drop(v914_11_cursor);
      drop(v914_6);
      map_map_kernels::compose(&(v903_10),&(v914_11))
    };
    drop(v903_10);
    let v903_13: Space = map_map_kernels::unite(&(v903_8),&(v903_12));
    v902_20.join_into((v903_13).clone());
    }
    v902_20_cursor.ascend(1);
  }
  drop(v902_20_cursor);
  (v902_20).clone()
}

fn routine_55(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v920_14 = Space::new();
  let mut v920_14_cursor = (*s0).read_zipper();
  for v920_14_byte in v920_14_cursor.child_mask().iter() {
    v920_14_cursor.descend_to_byte(v920_14_byte);
    {
    let v920_14_tail = v920_14_cursor.fork_read_zipper();
    let v920_14_head = Path::from_slice(&[v920_14_byte]);
    let v921_2: Space = singleton(&(v920_14_head));
    let v921_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v921_2));
    let v921_4: Space = if map_kernels::has_head(&(v921_3)) { singleton(&[]) } else { Space::new() };
    drop(v921_3);
    let v921_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v921_4));
    drop(v921_4);
    let v921_8: Space = if (v921_5).is_empty() { Space::new() } else {
      let v922_6: Path = concat_path(&(*p0),&(v920_14_head));
      let mut v922_7 = Space::new();
      let mut v922_7_cursor = (v920_14_tail).read_zipper();
      for v922_7_byte in v922_7_cursor.child_mask().iter() {
        v922_7_cursor.descend_to_byte(v922_7_byte);
        {
        let v922_7_tail = v922_7_cursor.fork_read_zipper();
        let v922_7_head = Path::from_slice(&[v922_7_byte]);
        let v923_2: Space = singleton(&(v922_7_head));
        let v923_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v923_2));
        let v923_4: Space = if map_kernels::has_head(&(v923_3)) { singleton(&[]) } else { Space::new() };
        drop(v923_3);
        let v923_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v923_4));
        drop(v923_4);
        let v923_8: Space = if (v923_5).is_empty() { Space::new() } else {
          let v924_6: Path = concat_path(&(v922_6),&(v922_7_head));
          let mut v924_7 = Space::new();
          let mut v924_7_cursor = (v922_7_tail).read_zipper();
          for v924_7_byte in v924_7_cursor.child_mask().iter() {
            v924_7_cursor.descend_to_byte(v924_7_byte);
            {
            let v924_7_tail = v924_7_cursor.fork_read_zipper();
            let v924_7_head = Path::from_slice(&[v924_7_byte]);
            let v925_2: Space = singleton(&(v924_7_head));
            let v925_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v925_2));
            let v925_4: Space = if map_kernels::has_head(&(v925_3)) { singleton(&[]) } else { Space::new() };
            drop(v925_3);
            let v925_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v925_4));
            drop(v925_4);
            let v925_8: Space = if (v925_5).is_empty() { Space::new() } else {
              let v926_6: Path = concat_path(&(v924_6),&(v924_7_head));
              let v926_7: Space = routine_66(c, &(v926_6), &(v924_7_tail).make_space());
              map_map_kernels::compose(&(v925_5),&(v926_7))
            };
            drop(v925_5);
            let v925_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v925_2));
            drop(v925_2);
            let v925_10: Space = if map_kernels::has_head(&(v925_9)) { singleton(&[]) } else { Space::new() };
            drop(v925_9);
            let v925_12: Space = if (v925_10).is_empty() { Space::new() } else {
              let v927_6: Path = concat_path(&(v924_6),&(v924_7_head));
              let v927_11: Space = routine_67(c, &(v927_6), &(v924_7_tail).make_space());
              drop(v927_6);
              map_map_kernels::compose(&(v925_10),&(v927_11))
            };
            drop(v925_10);
            let v925_13: Space = map_map_kernels::unite(&(v925_8),&(v925_12));
            v924_7.join_into((v925_13).clone());
            }
            v924_7_cursor.ascend(1);
          }
          drop(v924_7_cursor);
          map_map_kernels::compose(&(v923_5),&(v924_7))
        };
        drop(v923_5);
        let v923_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v923_2));
        drop(v923_2);
        let v923_10: Space = if map_kernels::has_head(&(v923_9)) { singleton(&[]) } else { Space::new() };
        drop(v923_9);
        let v923_12: Space = if (v923_10).is_empty() { Space::new() } else {
          let v928_6: Path = concat_path(&(v922_6),&(v922_7_head));
          let mut v928_11 = Space::new();
          let mut v928_11_cursor = (v922_7_tail).read_zipper();
          for v928_11_byte in v928_11_cursor.child_mask().iter() {
            v928_11_cursor.descend_to_byte(v928_11_byte);
            {
            let v928_11_tail = v928_11_cursor.fork_read_zipper();
            let v928_11_head = Path::from_slice(&[v928_11_byte]);
            let v929_2: Space = singleton(&(v928_11_head));
            let v929_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v929_2));
            let v929_4: Space = if map_kernels::has_head(&(v929_3)) { singleton(&[]) } else { Space::new() };
            drop(v929_3);
            let v929_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v929_4));
            drop(v929_4);
            let v929_8: Space = if (v929_5).is_empty() { Space::new() } else {
              let v930_6: Path = concat_path(&(v928_6),&(v928_11_head));
              let v930_7: Space = routine_66(c, &(v930_6), &(v928_11_tail).make_space());
              map_map_kernels::compose(&(v929_5),&(v930_7))
            };
            drop(v929_5);
            let v929_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v929_2));
            drop(v929_2);
            let v929_10: Space = if map_kernels::has_head(&(v929_9)) { singleton(&[]) } else { Space::new() };
            drop(v929_9);
            let v929_12: Space = if (v929_10).is_empty() { Space::new() } else {
              let v931_6: Path = concat_path(&(v928_6),&(v928_11_head));
              let v931_11: Space = routine_12(c, &(v931_6), &(v928_11_tail).make_space());
              drop(v931_6);
              map_map_kernels::compose(&(v929_10),&(v931_11))
            };
            drop(v929_10);
            let v929_13: Space = map_map_kernels::unite(&(v929_8),&(v929_12));
            v928_11.join_into((v929_13).clone());
            }
            v928_11_cursor.ascend(1);
          }
          drop(v928_11_cursor);
          drop(v928_6);
          map_map_kernels::compose(&(v923_10),&(v928_11))
        };
        drop(v923_10);
        let v923_13: Space = map_map_kernels::unite(&(v923_8),&(v923_12));
        v922_7.join_into((v923_13).clone());
        }
        v922_7_cursor.ascend(1);
      }
      drop(v922_7_cursor);
      drop(v922_6);
      map_map_kernels::compose(&(v921_5),&(v922_7))
    };
    drop(v921_5);
    let v921_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v921_2));
    drop(v921_2);
    let v921_10: Space = if map_kernels::has_head(&(v921_9)) { singleton(&[]) } else { Space::new() };
    drop(v921_9);
    let v921_11: Space = map_view_kernels::compose(&(v921_10),&(v920_14_tail));
    drop(v921_10);
    let v921_12: Space = map_map_kernels::unite(&(v921_8),&(v921_11));
    drop(v921_11);
    v920_14.join_into((v921_12).clone());
    }
    v920_14_cursor.ascend(1);
  }
  drop(v920_14_cursor);
  (v920_14).clone()
}

fn routine_56(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v932_20 = Space::new();
  let mut v932_20_cursor = (*s0).read_zipper();
  for v932_20_byte in v932_20_cursor.child_mask().iter() {
    v932_20_cursor.descend_to_byte(v932_20_byte);
    {
    let v932_20_tail = v932_20_cursor.fork_read_zipper();
    let v932_20_head = Path::from_slice(&[v932_20_byte]);
    let v933_2: Space = singleton(&(v932_20_head));
    let v933_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v933_2));
    let v933_4: Space = if map_kernels::has_head(&(v933_3)) { singleton(&[]) } else { Space::new() };
    drop(v933_3);
    let v933_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v933_4));
    drop(v933_4);
    let v933_8: Space = if (v933_5).is_empty() { Space::new() } else {
      let v934_6: Path = concat_path(&(*p0),&(v932_20_head));
      let mut v934_7 = Space::new();
      let mut v934_7_cursor = (v932_20_tail).read_zipper();
      for v934_7_byte in v934_7_cursor.child_mask().iter() {
        v934_7_cursor.descend_to_byte(v934_7_byte);
        {
        let v934_7_tail = v934_7_cursor.fork_read_zipper();
        let v934_7_head = Path::from_slice(&[v934_7_byte]);
        let v935_2: Space = singleton(&(v934_7_head));
        let v935_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v935_2));
        let v935_4: Space = if map_kernels::has_head(&(v935_3)) { singleton(&[]) } else { Space::new() };
        drop(v935_3);
        let v935_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v935_4));
        drop(v935_4);
        let v935_8: Space = if (v935_5).is_empty() { Space::new() } else {
          let v936_6: Path = concat_path(&(v934_6),&(v934_7_head));
          let mut v936_7 = Space::new();
          let mut v936_7_cursor = (v934_7_tail).read_zipper();
          for v936_7_byte in v936_7_cursor.child_mask().iter() {
            v936_7_cursor.descend_to_byte(v936_7_byte);
            {
            let v936_7_tail = v936_7_cursor.fork_read_zipper();
            let v936_7_head = Path::from_slice(&[v936_7_byte]);
            let v937_2: Space = singleton(&(v936_7_head));
            let v937_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v937_2));
            let v937_4: Space = if map_kernels::has_head(&(v937_3)) { singleton(&[]) } else { Space::new() };
            drop(v937_3);
            let v937_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v937_4));
            drop(v937_4);
            let v937_8: Space = if (v937_5).is_empty() { Space::new() } else {
              let v938_6: Path = concat_path(&(v936_6),&(v936_7_head));
              let v938_7: Space = routine_68(c, &(v938_6), &(v936_7_tail).make_space());
              map_map_kernels::compose(&(v937_5),&(v938_7))
            };
            drop(v937_5);
            let v937_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v937_2));
            drop(v937_2);
            let v937_10: Space = if map_kernels::has_head(&(v937_9)) { singleton(&[]) } else { Space::new() };
            drop(v937_9);
            let v937_12: Space = if (v937_10).is_empty() { Space::new() } else {
              let v939_6: Path = concat_path(&(v936_6),&(v936_7_head));
              let v939_11: Space = routine_69(c, &(v939_6), &(v936_7_tail).make_space());
              drop(v939_6);
              map_map_kernels::compose(&(v937_10),&(v939_11))
            };
            drop(v937_10);
            let v937_13: Space = map_map_kernels::unite(&(v937_8),&(v937_12));
            v936_7.join_into((v937_13).clone());
            }
            v936_7_cursor.ascend(1);
          }
          drop(v936_7_cursor);
          map_map_kernels::compose(&(v935_5),&(v936_7))
        };
        drop(v935_5);
        let v935_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v935_2));
        drop(v935_2);
        let v935_10: Space = if map_kernels::has_head(&(v935_9)) { singleton(&[]) } else { Space::new() };
        drop(v935_9);
        let v935_12: Space = if (v935_10).is_empty() { Space::new() } else {
          let v940_6: Path = concat_path(&(v934_6),&(v934_7_head));
          let mut v940_11 = Space::new();
          let mut v940_11_cursor = (v934_7_tail).read_zipper();
          for v940_11_byte in v940_11_cursor.child_mask().iter() {
            v940_11_cursor.descend_to_byte(v940_11_byte);
            {
            let v940_11_tail = v940_11_cursor.fork_read_zipper();
            let v940_11_head = Path::from_slice(&[v940_11_byte]);
            let v941_2: Space = singleton(&(v940_11_head));
            let v941_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v941_2));
            let v941_4: Space = if map_kernels::has_head(&(v941_3)) { singleton(&[]) } else { Space::new() };
            drop(v941_3);
            let v941_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v941_4));
            drop(v941_4);
            let v941_8: Space = if (v941_5).is_empty() { Space::new() } else {
              let v942_6: Path = concat_path(&(v940_6),&(v940_11_head));
              let v942_7: Space = routine_68(c, &(v942_6), &(v940_11_tail).make_space());
              map_map_kernels::compose(&(v941_5),&(v942_7))
            };
            drop(v941_5);
            let v941_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v941_2));
            drop(v941_2);
            let v941_10: Space = if map_kernels::has_head(&(v941_9)) { singleton(&[]) } else { Space::new() };
            drop(v941_9);
            let v941_12: Space = if (v941_10).is_empty() { Space::new() } else {
              let v943_6: Path = concat_path(&(v940_6),&(v940_11_head));
              let v943_11: Space = routine_15(c, &(v943_6), &(v940_11_tail).make_space());
              drop(v943_6);
              map_map_kernels::compose(&(v941_10),&(v943_11))
            };
            drop(v941_10);
            let v941_13: Space = map_map_kernels::unite(&(v941_8),&(v941_12));
            v940_11.join_into((v941_13).clone());
            }
            v940_11_cursor.ascend(1);
          }
          drop(v940_11_cursor);
          drop(v940_6);
          map_map_kernels::compose(&(v935_10),&(v940_11))
        };
        drop(v935_10);
        let v935_13: Space = map_map_kernels::unite(&(v935_8),&(v935_12));
        v934_7.join_into((v935_13).clone());
        }
        v934_7_cursor.ascend(1);
      }
      drop(v934_7_cursor);
      map_map_kernels::compose(&(v933_5),&(v934_7))
    };
    drop(v933_5);
    let v933_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v933_2));
    drop(v933_2);
    let v933_10: Space = if map_kernels::has_head(&(v933_9)) { singleton(&[]) } else { Space::new() };
    drop(v933_9);
    let v933_12: Space = if (v933_10).is_empty() { Space::new() } else {
      let v944_6: Path = concat_path(&(*p0),&(v932_20_head));
      let mut v944_11 = Space::new();
      let mut v944_11_cursor = (v932_20_tail).read_zipper();
      for v944_11_byte in v944_11_cursor.child_mask().iter() {
        v944_11_cursor.descend_to_byte(v944_11_byte);
        {
        let v944_11_tail = v944_11_cursor.fork_read_zipper();
        let v944_11_head = Path::from_slice(&[v944_11_byte]);
        let v945_2: Space = singleton(&(v944_11_head));
        let v945_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v945_2));
        let v945_4: Space = if map_kernels::has_head(&(v945_3)) { singleton(&[]) } else { Space::new() };
        drop(v945_3);
        let v945_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v945_4));
        drop(v945_4);
        let v945_8: Space = if (v945_5).is_empty() { Space::new() } else {
          let v946_6: Path = concat_path(&(v944_6),&(v944_11_head));
          let mut v946_7 = Space::new();
          let mut v946_7_cursor = (v944_11_tail).read_zipper();
          for v946_7_byte in v946_7_cursor.child_mask().iter() {
            v946_7_cursor.descend_to_byte(v946_7_byte);
            {
            let v946_7_tail = v946_7_cursor.fork_read_zipper();
            let v946_7_head = Path::from_slice(&[v946_7_byte]);
            let v947_2: Space = singleton(&(v946_7_head));
            let v947_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v947_2));
            let v947_4: Space = if map_kernels::has_head(&(v947_3)) { singleton(&[]) } else { Space::new() };
            drop(v947_3);
            let v947_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v947_4));
            drop(v947_4);
            let v947_8: Space = if (v947_5).is_empty() { Space::new() } else {
              let v948_6: Path = concat_path(&(v946_6),&(v946_7_head));
              let v948_7: Space = routine_68(c, &(v948_6), &(v946_7_tail).make_space());
              map_map_kernels::compose(&(v947_5),&(v948_7))
            };
            drop(v947_5);
            let v947_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v947_2));
            drop(v947_2);
            let v947_10: Space = if map_kernels::has_head(&(v947_9)) { singleton(&[]) } else { Space::new() };
            drop(v947_9);
            let v947_12: Space = if (v947_10).is_empty() { Space::new() } else {
              let v949_6: Path = concat_path(&(v946_6),&(v946_7_head));
              let v949_11: Space = routine_69(c, &(v949_6), &(v946_7_tail).make_space());
              drop(v949_6);
              map_map_kernels::compose(&(v947_10),&(v949_11))
            };
            drop(v947_10);
            let v947_13: Space = map_map_kernels::unite(&(v947_8),&(v947_12));
            v946_7.join_into((v947_13).clone());
            }
            v946_7_cursor.ascend(1);
          }
          drop(v946_7_cursor);
          drop(v946_6);
          map_map_kernels::compose(&(v945_5),&(v946_7))
        };
        drop(v945_5);
        let v945_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v945_2));
        drop(v945_2);
        let v945_10: Space = if map_kernels::has_head(&(v945_9)) { singleton(&[]) } else { Space::new() };
        drop(v945_9);
        let v945_11: Space = map_view_kernels::compose(&(v945_10),&(v944_11_tail));
        drop(v945_10);
        let v945_12: Space = map_map_kernels::unite(&(v945_8),&(v945_11));
        drop(v945_11);
        v944_11.join_into((v945_12).clone());
        }
        v944_11_cursor.ascend(1);
      }
      drop(v944_11_cursor);
      drop(v944_6);
      map_map_kernels::compose(&(v933_10),&(v944_11))
    };
    drop(v933_10);
    let v933_13: Space = map_map_kernels::unite(&(v933_8),&(v933_12));
    v932_20.join_into((v933_13).clone());
    }
    v932_20_cursor.ascend(1);
  }
  drop(v932_20_cursor);
  (v932_20).clone()
}

fn routine_57(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v950_14 = Space::new();
  let mut v950_14_cursor = (*s0).read_zipper();
  for v950_14_byte in v950_14_cursor.child_mask().iter() {
    v950_14_cursor.descend_to_byte(v950_14_byte);
    {
    let v950_14_tail = v950_14_cursor.fork_read_zipper();
    let v950_14_head = Path::from_slice(&[v950_14_byte]);
    let v951_2: Space = singleton(&(v950_14_head));
    let v951_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v951_2));
    let v951_4: Space = if map_kernels::has_head(&(v951_3)) { singleton(&[]) } else { Space::new() };
    drop(v951_3);
    let v951_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v951_4));
    drop(v951_4);
    let v951_8: Space = if (v951_5).is_empty() { Space::new() } else {
      let v952_6: Path = concat_path(&(*p0),&(v950_14_head));
      let mut v952_7 = Space::new();
      let mut v952_7_cursor = (v950_14_tail).read_zipper();
      for v952_7_byte in v952_7_cursor.child_mask().iter() {
        v952_7_cursor.descend_to_byte(v952_7_byte);
        {
        let v952_7_tail = v952_7_cursor.fork_read_zipper();
        let v952_7_head = Path::from_slice(&[v952_7_byte]);
        let v953_2: Space = singleton(&(v952_7_head));
        let v953_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v953_2));
        let v953_4: Space = if map_kernels::has_head(&(v953_3)) { singleton(&[]) } else { Space::new() };
        drop(v953_3);
        let v953_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v953_4));
        drop(v953_4);
        let v953_8: Space = if (v953_5).is_empty() { Space::new() } else {
          let v954_6: Path = concat_path(&(v952_6),&(v952_7_head));
          let mut v954_7 = Space::new();
          let mut v954_7_cursor = (v952_7_tail).read_zipper();
          for v954_7_byte in v954_7_cursor.child_mask().iter() {
            v954_7_cursor.descend_to_byte(v954_7_byte);
            {
            let v954_7_tail = v954_7_cursor.fork_read_zipper();
            let v954_7_head = Path::from_slice(&[v954_7_byte]);
            let v955_2: Space = singleton(&(v954_7_head));
            let v955_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v955_2));
            let v955_4: Space = if map_kernels::has_head(&(v955_3)) { singleton(&[]) } else { Space::new() };
            drop(v955_3);
            let v955_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v955_4));
            drop(v955_4);
            let v955_8: Space = if (v955_5).is_empty() { Space::new() } else {
              let v956_6: Path = concat_path(&(v954_6),&(v954_7_head));
              let v956_7: Space = routine_68(c, &(v956_6), &(v954_7_tail).make_space());
              map_map_kernels::compose(&(v955_5),&(v956_7))
            };
            drop(v955_5);
            let v955_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v955_2));
            drop(v955_2);
            let v955_10: Space = if map_kernels::has_head(&(v955_9)) { singleton(&[]) } else { Space::new() };
            drop(v955_9);
            let v955_12: Space = if (v955_10).is_empty() { Space::new() } else {
              let v957_6: Path = concat_path(&(v954_6),&(v954_7_head));
              let v957_11: Space = routine_69(c, &(v957_6), &(v954_7_tail).make_space());
              drop(v957_6);
              map_map_kernels::compose(&(v955_10),&(v957_11))
            };
            drop(v955_10);
            let v955_13: Space = map_map_kernels::unite(&(v955_8),&(v955_12));
            v954_7.join_into((v955_13).clone());
            }
            v954_7_cursor.ascend(1);
          }
          drop(v954_7_cursor);
          map_map_kernels::compose(&(v953_5),&(v954_7))
        };
        drop(v953_5);
        let v953_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v953_2));
        drop(v953_2);
        let v953_10: Space = if map_kernels::has_head(&(v953_9)) { singleton(&[]) } else { Space::new() };
        drop(v953_9);
        let v953_12: Space = if (v953_10).is_empty() { Space::new() } else {
          let v958_6: Path = concat_path(&(v952_6),&(v952_7_head));
          let mut v958_11 = Space::new();
          let mut v958_11_cursor = (v952_7_tail).read_zipper();
          for v958_11_byte in v958_11_cursor.child_mask().iter() {
            v958_11_cursor.descend_to_byte(v958_11_byte);
            {
            let v958_11_tail = v958_11_cursor.fork_read_zipper();
            let v958_11_head = Path::from_slice(&[v958_11_byte]);
            let v959_2: Space = singleton(&(v958_11_head));
            let v959_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v959_2));
            let v959_4: Space = if map_kernels::has_head(&(v959_3)) { singleton(&[]) } else { Space::new() };
            drop(v959_3);
            let v959_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v959_4));
            drop(v959_4);
            let v959_8: Space = if (v959_5).is_empty() { Space::new() } else {
              let v960_6: Path = concat_path(&(v958_6),&(v958_11_head));
              let v960_7: Space = routine_68(c, &(v960_6), &(v958_11_tail).make_space());
              map_map_kernels::compose(&(v959_5),&(v960_7))
            };
            drop(v959_5);
            let v959_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v959_2));
            drop(v959_2);
            let v959_10: Space = if map_kernels::has_head(&(v959_9)) { singleton(&[]) } else { Space::new() };
            drop(v959_9);
            let v959_12: Space = if (v959_10).is_empty() { Space::new() } else {
              let v961_6: Path = concat_path(&(v958_6),&(v958_11_head));
              let v961_11: Space = routine_15(c, &(v961_6), &(v958_11_tail).make_space());
              drop(v961_6);
              map_map_kernels::compose(&(v959_10),&(v961_11))
            };
            drop(v959_10);
            let v959_13: Space = map_map_kernels::unite(&(v959_8),&(v959_12));
            v958_11.join_into((v959_13).clone());
            }
            v958_11_cursor.ascend(1);
          }
          drop(v958_11_cursor);
          drop(v958_6);
          map_map_kernels::compose(&(v953_10),&(v958_11))
        };
        drop(v953_10);
        let v953_13: Space = map_map_kernels::unite(&(v953_8),&(v953_12));
        v952_7.join_into((v953_13).clone());
        }
        v952_7_cursor.ascend(1);
      }
      drop(v952_7_cursor);
      drop(v952_6);
      map_map_kernels::compose(&(v951_5),&(v952_7))
    };
    drop(v951_5);
    let v951_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v951_2));
    drop(v951_2);
    let v951_10: Space = if map_kernels::has_head(&(v951_9)) { singleton(&[]) } else { Space::new() };
    drop(v951_9);
    let v951_11: Space = map_view_kernels::compose(&(v951_10),&(v950_14_tail));
    drop(v951_10);
    let v951_12: Space = map_map_kernels::unite(&(v951_8),&(v951_11));
    drop(v951_11);
    v950_14.join_into((v951_12).clone());
    }
    v950_14_cursor.ascend(1);
  }
  drop(v950_14_cursor);
  (v950_14).clone()
}

fn routine_58(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v962_12 = Space::new();
  let mut v962_12_cursor = (*s0).read_zipper();
  for v962_12_byte in v962_12_cursor.child_mask().iter() {
    v962_12_cursor.descend_to_byte(v962_12_byte);
    {
    let v962_12_tail = v962_12_cursor.fork_read_zipper();
    let v962_12_head = Path::from_slice(&[v962_12_byte]);
    let v963_2: Space = singleton(&(v962_12_head));
    let v963_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v963_2));
    let v963_4: Space = if map_kernels::has_head(&(v963_3)) { singleton(&[]) } else { Space::new() };
    drop(v963_3);
    let v963_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v963_4));
    drop(v963_4);
    let v963_8: Space = if (v963_5).is_empty() { Space::new() } else {
      let v964_6: Path = concat_path(&(*p0),&(v962_12_head));
      let mut v964_7 = Space::new();
      let mut v964_7_cursor = (v962_12_tail).read_zipper();
      for v964_7_byte in v964_7_cursor.child_mask().iter() {
        v964_7_cursor.descend_to_byte(v964_7_byte);
        {
        let v964_7_tail = v964_7_cursor.fork_read_zipper();
        let v964_7_head = Path::from_slice(&[v964_7_byte]);
        let v965_2: Space = singleton(&(v964_7_head));
        let v965_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v965_2));
        let v965_4: Space = if map_kernels::has_head(&(v965_3)) { singleton(&[]) } else { Space::new() };
        drop(v965_3);
        let v965_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v965_4));
        drop(v965_4);
        let mut v965_6 = Space::new();
        let mut v965_6_cursor = (v964_7_tail).read_zipper();
        for v965_6_byte in v965_6_cursor.child_mask().iter() {
          v965_6_cursor.descend_to_byte(v965_6_byte);
          {
          let v965_6_tail = v965_6_cursor.fork_read_zipper();
          let v965_6_head = Path::from_slice(&[v965_6_byte]);
          let v966_2: Space = Space::new();
          v965_6.join_into((v966_2).clone());
          }
          v965_6_cursor.ascend(1);
        }
        drop(v965_6_cursor);
        let v965_7: Space = map_map_kernels::compose(&(v965_5),&(v965_6));
        drop(v965_5);
        drop(v965_6);
        let v965_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v965_2));
        drop(v965_2);
        let v965_9: Space = if map_kernels::has_head(&(v965_8)) { singleton(&[]) } else { Space::new() };
        drop(v965_8);
        let v965_12: Space = if (v965_9).is_empty() { Space::new() } else {
          let v967_10: Path = concat_path(&(v964_6),&(v964_7_head));
          let mut v967_11 = Space::new();
          let mut v967_11_cursor = (v964_7_tail).read_zipper();
          for v967_11_byte in v967_11_cursor.child_mask().iter() {
            v967_11_cursor.descend_to_byte(v967_11_byte);
            {
            let v967_11_tail = v967_11_cursor.fork_read_zipper();
            let v967_11_head = Path::from_slice(&[v967_11_byte]);
            let v968_2: Space = singleton(&(v967_11_head));
            let v968_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v968_2));
            drop(v968_2);
            let v968_4: Space = if map_kernels::has_head(&(v968_3)) { singleton(&[]) } else { Space::new() };
            drop(v968_3);
            let v968_7: Space = if (v968_4).is_empty() { Space::new() } else {
              let v969_5: Path = concat_path(&(v967_10),&(v967_11_head));
              let v969_6: Space = routine_12(c, &(v969_5), &(v967_11_tail).make_space());
              drop(v969_5);
              map_map_kernels::compose(&(v968_4),&(v969_6))
            };
            drop(v968_4);
            v967_11.join_into((v968_7).clone());
            }
            v967_11_cursor.ascend(1);
          }
          drop(v967_11_cursor);
          drop(v967_10);
          map_map_kernels::compose(&(v965_9),&(v967_11))
        };
        drop(v965_9);
        let v965_13: Space = map_map_kernels::unite(&(v965_7),&(v965_12));
        drop(v965_7);
        v964_7.join_into((v965_13).clone());
        }
        v964_7_cursor.ascend(1);
      }
      drop(v964_7_cursor);
      drop(v964_6);
      map_map_kernels::compose(&(v963_5),&(v964_7))
    };
    drop(v963_5);
    let v963_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v963_2));
    drop(v963_2);
    let v963_10: Space = if map_kernels::has_head(&(v963_9)) { singleton(&[]) } else { Space::new() };
    drop(v963_9);
    let mut v963_11 = Space::new();
    let mut v963_11_cursor = (v962_12_tail).read_zipper();
    for v963_11_byte in v963_11_cursor.child_mask().iter() {
      v963_11_cursor.descend_to_byte(v963_11_byte);
      {
      let v963_11_tail = v963_11_cursor.fork_read_zipper();
      let v963_11_head = Path::from_slice(&[v963_11_byte]);
      let v970_2: Space = singleton(&(v963_11_head));
      let v970_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v970_2));
      let v970_4: Space = if map_kernels::has_head(&(v970_3)) { singleton(&[]) } else { Space::new() };
      drop(v970_3);
      let v970_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v970_4));
      drop(v970_4);
      let mut v970_6 = Space::new();
      let mut v970_6_cursor = (v963_11_tail).read_zipper();
      for v970_6_byte in v970_6_cursor.child_mask().iter() {
        v970_6_cursor.descend_to_byte(v970_6_byte);
        {
        let v970_6_tail = v970_6_cursor.fork_read_zipper();
        let v970_6_head = Path::from_slice(&[v970_6_byte]);
        let v971_2: Space = Space::new();
        v970_6.join_into((v971_2).clone());
        }
        v970_6_cursor.ascend(1);
      }
      drop(v970_6_cursor);
      let v970_7: Space = map_map_kernels::compose(&(v970_5),&(v970_6));
      drop(v970_5);
      drop(v970_6);
      let v970_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v970_2));
      drop(v970_2);
      let v970_9: Space = if map_kernels::has_head(&(v970_8)) { singleton(&[]) } else { Space::new() };
      drop(v970_8);
      let v970_10: Space = map_view_kernels::compose(&(v970_9),&(v963_11_tail));
      drop(v970_9);
      let v970_11: Space = map_map_kernels::unite(&(v970_7),&(v970_10));
      drop(v970_7);
      drop(v970_10);
      v963_11.join_into((v970_11).clone());
      }
      v963_11_cursor.ascend(1);
    }
    drop(v963_11_cursor);
    let v963_12: Space = map_map_kernels::compose(&(v963_10),&(v963_11));
    drop(v963_10);
    drop(v963_11);
    let v963_13: Space = map_map_kernels::unite(&(v963_8),&(v963_12));
    drop(v963_12);
    v962_12.join_into((v963_13).clone());
    }
    v962_12_cursor.ascend(1);
  }
  drop(v962_12_cursor);
  (v962_12).clone()
}

fn routine_59(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v972_9 = Space::new();
  let mut v972_9_cursor = (*s0).read_zipper();
  for v972_9_byte in v972_9_cursor.child_mask().iter() {
    v972_9_cursor.descend_to_byte(v972_9_byte);
    {
    let v972_9_tail = v972_9_cursor.fork_read_zipper();
    let v972_9_head = Path::from_slice(&[v972_9_byte]);
    let v973_2: Space = singleton(&(v972_9_head));
    let v973_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v973_2));
    let v973_4: Space = if map_kernels::has_head(&(v973_3)) { singleton(&[]) } else { Space::new() };
    drop(v973_3);
    let v973_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v973_4));
    drop(v973_4);
    let v973_8: Space = if (v973_5).is_empty() { Space::new() } else {
      let v974_6: Path = concat_path(&(*p0),&(v972_9_head));
      let mut v974_7 = Space::new();
      let mut v974_7_cursor = (v972_9_tail).read_zipper();
      for v974_7_byte in v974_7_cursor.child_mask().iter() {
        v974_7_cursor.descend_to_byte(v974_7_byte);
        {
        let v974_7_tail = v974_7_cursor.fork_read_zipper();
        let v974_7_head = Path::from_slice(&[v974_7_byte]);
        let v975_2: Space = singleton(&(v974_7_head));
        let v975_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v975_2));
        let v975_4: Space = if map_kernels::has_head(&(v975_3)) { singleton(&[]) } else { Space::new() };
        drop(v975_3);
        let v975_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v975_4));
        drop(v975_4);
        let mut v975_6 = Space::new();
        let mut v975_6_cursor = (v974_7_tail).read_zipper();
        for v975_6_byte in v975_6_cursor.child_mask().iter() {
          v975_6_cursor.descend_to_byte(v975_6_byte);
          {
          let v975_6_tail = v975_6_cursor.fork_read_zipper();
          let v975_6_head = Path::from_slice(&[v975_6_byte]);
          let v976_2: Space = Space::new();
          v975_6.join_into((v976_2).clone());
          }
          v975_6_cursor.ascend(1);
        }
        drop(v975_6_cursor);
        let v975_7: Space = map_map_kernels::compose(&(v975_5),&(v975_6));
        drop(v975_5);
        drop(v975_6);
        let v975_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v975_2));
        drop(v975_2);
        let v975_9: Space = if map_kernels::has_head(&(v975_8)) { singleton(&[]) } else { Space::new() };
        drop(v975_8);
        let v975_12: Space = if (v975_9).is_empty() { Space::new() } else {
          let v977_10: Path = concat_path(&(v974_6),&(v974_7_head));
          let mut v977_11 = Space::new();
          let mut v977_11_cursor = (v974_7_tail).read_zipper();
          for v977_11_byte in v977_11_cursor.child_mask().iter() {
            v977_11_cursor.descend_to_byte(v977_11_byte);
            {
            let v977_11_tail = v977_11_cursor.fork_read_zipper();
            let v977_11_head = Path::from_slice(&[v977_11_byte]);
            let v978_2: Space = singleton(&(v977_11_head));
            let v978_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v978_2));
            drop(v978_2);
            let v978_4: Space = if map_kernels::has_head(&(v978_3)) { singleton(&[]) } else { Space::new() };
            drop(v978_3);
            let v978_7: Space = if (v978_4).is_empty() { Space::new() } else {
              let v979_5: Path = concat_path(&(v977_10),&(v977_11_head));
              let v979_6: Space = routine_12(c, &(v979_5), &(v977_11_tail).make_space());
              drop(v979_5);
              map_map_kernels::compose(&(v978_4),&(v979_6))
            };
            drop(v978_4);
            v977_11.join_into((v978_7).clone());
            }
            v977_11_cursor.ascend(1);
          }
          drop(v977_11_cursor);
          drop(v977_10);
          map_map_kernels::compose(&(v975_9),&(v977_11))
        };
        drop(v975_9);
        let v975_13: Space = map_map_kernels::unite(&(v975_7),&(v975_12));
        drop(v975_7);
        v974_7.join_into((v975_13).clone());
        }
        v974_7_cursor.ascend(1);
      }
      drop(v974_7_cursor);
      drop(v974_6);
      map_map_kernels::compose(&(v973_5),&(v974_7))
    };
    drop(v973_5);
    let v973_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v973_2));
    drop(v973_2);
    let v973_10: Space = if map_kernels::has_head(&(v973_9)) { singleton(&[]) } else { Space::new() };
    drop(v973_9);
    let v973_11: Space = map_view_kernels::compose(&(v973_10),&(v972_9_tail));
    drop(v973_10);
    let v973_12: Space = map_map_kernels::unite(&(v973_8),&(v973_11));
    drop(v973_11);
    v972_9.join_into((v973_12).clone());
    }
    v972_9_cursor.ascend(1);
  }
  drop(v972_9_cursor);
  (v972_9).clone()
}

fn routine_60(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v980_12 = Space::new();
  let mut v980_12_cursor = (*s0).read_zipper();
  for v980_12_byte in v980_12_cursor.child_mask().iter() {
    v980_12_cursor.descend_to_byte(v980_12_byte);
    {
    let v980_12_tail = v980_12_cursor.fork_read_zipper();
    let v980_12_head = Path::from_slice(&[v980_12_byte]);
    let v981_2: Space = singleton(&(v980_12_head));
    let v981_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v981_2));
    let v981_4: Space = if map_kernels::has_head(&(v981_3)) { singleton(&[]) } else { Space::new() };
    drop(v981_3);
    let v981_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v981_4));
    drop(v981_4);
    let v981_8: Space = if (v981_5).is_empty() { Space::new() } else {
      let v982_6: Path = concat_path(&(*p0),&(v980_12_head));
      let mut v982_7 = Space::new();
      let mut v982_7_cursor = (v980_12_tail).read_zipper();
      for v982_7_byte in v982_7_cursor.child_mask().iter() {
        v982_7_cursor.descend_to_byte(v982_7_byte);
        {
        let v982_7_tail = v982_7_cursor.fork_read_zipper();
        let v982_7_head = Path::from_slice(&[v982_7_byte]);
        let v983_2: Space = singleton(&(v982_7_head));
        let v983_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v983_2));
        let v983_4: Space = if map_kernels::has_head(&(v983_3)) { singleton(&[]) } else { Space::new() };
        drop(v983_3);
        let v983_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v983_4));
        drop(v983_4);
        let mut v983_6 = Space::new();
        let mut v983_6_cursor = (v982_7_tail).read_zipper();
        for v983_6_byte in v983_6_cursor.child_mask().iter() {
          v983_6_cursor.descend_to_byte(v983_6_byte);
          {
          let v983_6_tail = v983_6_cursor.fork_read_zipper();
          let v983_6_head = Path::from_slice(&[v983_6_byte]);
          let v984_2: Space = Space::new();
          v983_6.join_into((v984_2).clone());
          }
          v983_6_cursor.ascend(1);
        }
        drop(v983_6_cursor);
        let v983_7: Space = map_map_kernels::compose(&(v983_5),&(v983_6));
        drop(v983_5);
        drop(v983_6);
        let v983_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v983_2));
        drop(v983_2);
        let v983_9: Space = if map_kernels::has_head(&(v983_8)) { singleton(&[]) } else { Space::new() };
        drop(v983_8);
        let v983_12: Space = if (v983_9).is_empty() { Space::new() } else {
          let v985_10: Path = concat_path(&(v982_6),&(v982_7_head));
          let mut v985_11 = Space::new();
          let mut v985_11_cursor = (v982_7_tail).read_zipper();
          for v985_11_byte in v985_11_cursor.child_mask().iter() {
            v985_11_cursor.descend_to_byte(v985_11_byte);
            {
            let v985_11_tail = v985_11_cursor.fork_read_zipper();
            let v985_11_head = Path::from_slice(&[v985_11_byte]);
            let v986_2: Space = singleton(&(v985_11_head));
            let v986_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v986_2));
            drop(v986_2);
            let v986_4: Space = if map_kernels::has_head(&(v986_3)) { singleton(&[]) } else { Space::new() };
            drop(v986_3);
            let v986_7: Space = if (v986_4).is_empty() { Space::new() } else {
              let v987_5: Path = concat_path(&(v985_10),&(v985_11_head));
              let v987_6: Space = routine_15(c, &(v987_5), &(v985_11_tail).make_space());
              drop(v987_5);
              map_map_kernels::compose(&(v986_4),&(v987_6))
            };
            drop(v986_4);
            v985_11.join_into((v986_7).clone());
            }
            v985_11_cursor.ascend(1);
          }
          drop(v985_11_cursor);
          drop(v985_10);
          map_map_kernels::compose(&(v983_9),&(v985_11))
        };
        drop(v983_9);
        let v983_13: Space = map_map_kernels::unite(&(v983_7),&(v983_12));
        drop(v983_7);
        v982_7.join_into((v983_13).clone());
        }
        v982_7_cursor.ascend(1);
      }
      drop(v982_7_cursor);
      drop(v982_6);
      map_map_kernels::compose(&(v981_5),&(v982_7))
    };
    drop(v981_5);
    let v981_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v981_2));
    drop(v981_2);
    let v981_10: Space = if map_kernels::has_head(&(v981_9)) { singleton(&[]) } else { Space::new() };
    drop(v981_9);
    let mut v981_11 = Space::new();
    let mut v981_11_cursor = (v980_12_tail).read_zipper();
    for v981_11_byte in v981_11_cursor.child_mask().iter() {
      v981_11_cursor.descend_to_byte(v981_11_byte);
      {
      let v981_11_tail = v981_11_cursor.fork_read_zipper();
      let v981_11_head = Path::from_slice(&[v981_11_byte]);
      let v988_2: Space = singleton(&(v981_11_head));
      let v988_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v988_2));
      let v988_4: Space = if map_kernels::has_head(&(v988_3)) { singleton(&[]) } else { Space::new() };
      drop(v988_3);
      let v988_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v988_4));
      drop(v988_4);
      let mut v988_6 = Space::new();
      let mut v988_6_cursor = (v981_11_tail).read_zipper();
      for v988_6_byte in v988_6_cursor.child_mask().iter() {
        v988_6_cursor.descend_to_byte(v988_6_byte);
        {
        let v988_6_tail = v988_6_cursor.fork_read_zipper();
        let v988_6_head = Path::from_slice(&[v988_6_byte]);
        let v989_2: Space = Space::new();
        v988_6.join_into((v989_2).clone());
        }
        v988_6_cursor.ascend(1);
      }
      drop(v988_6_cursor);
      let v988_7: Space = map_map_kernels::compose(&(v988_5),&(v988_6));
      drop(v988_5);
      drop(v988_6);
      let v988_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v988_2));
      drop(v988_2);
      let v988_9: Space = if map_kernels::has_head(&(v988_8)) { singleton(&[]) } else { Space::new() };
      drop(v988_8);
      let v988_10: Space = map_view_kernels::compose(&(v988_9),&(v981_11_tail));
      drop(v988_9);
      let v988_11: Space = map_map_kernels::unite(&(v988_7),&(v988_10));
      drop(v988_7);
      drop(v988_10);
      v981_11.join_into((v988_11).clone());
      }
      v981_11_cursor.ascend(1);
    }
    drop(v981_11_cursor);
    let v981_12: Space = map_map_kernels::compose(&(v981_10),&(v981_11));
    drop(v981_10);
    drop(v981_11);
    let v981_13: Space = map_map_kernels::unite(&(v981_8),&(v981_12));
    drop(v981_12);
    v980_12.join_into((v981_13).clone());
    }
    v980_12_cursor.ascend(1);
  }
  drop(v980_12_cursor);
  (v980_12).clone()
}

fn routine_61(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v990_9 = Space::new();
  let mut v990_9_cursor = (*s0).read_zipper();
  for v990_9_byte in v990_9_cursor.child_mask().iter() {
    v990_9_cursor.descend_to_byte(v990_9_byte);
    {
    let v990_9_tail = v990_9_cursor.fork_read_zipper();
    let v990_9_head = Path::from_slice(&[v990_9_byte]);
    let v991_2: Space = singleton(&(v990_9_head));
    let v991_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v991_2));
    let v991_4: Space = if map_kernels::has_head(&(v991_3)) { singleton(&[]) } else { Space::new() };
    drop(v991_3);
    let v991_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v991_4));
    drop(v991_4);
    let v991_8: Space = if (v991_5).is_empty() { Space::new() } else {
      let v992_6: Path = concat_path(&(*p0),&(v990_9_head));
      let mut v992_7 = Space::new();
      let mut v992_7_cursor = (v990_9_tail).read_zipper();
      for v992_7_byte in v992_7_cursor.child_mask().iter() {
        v992_7_cursor.descend_to_byte(v992_7_byte);
        {
        let v992_7_tail = v992_7_cursor.fork_read_zipper();
        let v992_7_head = Path::from_slice(&[v992_7_byte]);
        let v993_2: Space = singleton(&(v992_7_head));
        let v993_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v993_2));
        let v993_4: Space = if map_kernels::has_head(&(v993_3)) { singleton(&[]) } else { Space::new() };
        drop(v993_3);
        let v993_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v993_4));
        drop(v993_4);
        let mut v993_6 = Space::new();
        let mut v993_6_cursor = (v992_7_tail).read_zipper();
        for v993_6_byte in v993_6_cursor.child_mask().iter() {
          v993_6_cursor.descend_to_byte(v993_6_byte);
          {
          let v993_6_tail = v993_6_cursor.fork_read_zipper();
          let v993_6_head = Path::from_slice(&[v993_6_byte]);
          let v994_2: Space = Space::new();
          v993_6.join_into((v994_2).clone());
          }
          v993_6_cursor.ascend(1);
        }
        drop(v993_6_cursor);
        let v993_7: Space = map_map_kernels::compose(&(v993_5),&(v993_6));
        drop(v993_5);
        drop(v993_6);
        let v993_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v993_2));
        drop(v993_2);
        let v993_9: Space = if map_kernels::has_head(&(v993_8)) { singleton(&[]) } else { Space::new() };
        drop(v993_8);
        let v993_12: Space = if (v993_9).is_empty() { Space::new() } else {
          let v995_10: Path = concat_path(&(v992_6),&(v992_7_head));
          let mut v995_11 = Space::new();
          let mut v995_11_cursor = (v992_7_tail).read_zipper();
          for v995_11_byte in v995_11_cursor.child_mask().iter() {
            v995_11_cursor.descend_to_byte(v995_11_byte);
            {
            let v995_11_tail = v995_11_cursor.fork_read_zipper();
            let v995_11_head = Path::from_slice(&[v995_11_byte]);
            let v996_2: Space = singleton(&(v995_11_head));
            let v996_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v996_2));
            drop(v996_2);
            let v996_4: Space = if map_kernels::has_head(&(v996_3)) { singleton(&[]) } else { Space::new() };
            drop(v996_3);
            let v996_7: Space = if (v996_4).is_empty() { Space::new() } else {
              let v997_5: Path = concat_path(&(v995_10),&(v995_11_head));
              let v997_6: Space = routine_15(c, &(v997_5), &(v995_11_tail).make_space());
              drop(v997_5);
              map_map_kernels::compose(&(v996_4),&(v997_6))
            };
            drop(v996_4);
            v995_11.join_into((v996_7).clone());
            }
            v995_11_cursor.ascend(1);
          }
          drop(v995_11_cursor);
          drop(v995_10);
          map_map_kernels::compose(&(v993_9),&(v995_11))
        };
        drop(v993_9);
        let v993_13: Space = map_map_kernels::unite(&(v993_7),&(v993_12));
        drop(v993_7);
        v992_7.join_into((v993_13).clone());
        }
        v992_7_cursor.ascend(1);
      }
      drop(v992_7_cursor);
      drop(v992_6);
      map_map_kernels::compose(&(v991_5),&(v992_7))
    };
    drop(v991_5);
    let v991_9: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v991_2));
    drop(v991_2);
    let v991_10: Space = if map_kernels::has_head(&(v991_9)) { singleton(&[]) } else { Space::new() };
    drop(v991_9);
    let v991_11: Space = map_view_kernels::compose(&(v991_10),&(v990_9_tail));
    drop(v991_10);
    let v991_12: Space = map_map_kernels::unite(&(v991_8),&(v991_11));
    drop(v991_11);
    v990_9.join_into((v991_12).clone());
    }
    v990_9_cursor.ascend(1);
  }
  drop(v990_9_cursor);
  (v990_9).clone()
}

fn routine_62(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v998_6 = Space::new();
  let mut v998_6_cursor = (*s0).read_zipper();
  for v998_6_byte in v998_6_cursor.child_mask().iter() {
    v998_6_cursor.descend_to_byte(v998_6_byte);
    {
    let v998_6_tail = v998_6_cursor.fork_read_zipper();
    let v998_6_head = Path::from_slice(&[v998_6_byte]);
    let v999_2: Space = singleton(&(v998_6_head));
    let v999_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v999_2));
    let v999_4: Space = if map_kernels::has_head(&(v999_3)) { singleton(&[]) } else { Space::new() };
    drop(v999_3);
    let v999_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v999_4));
    drop(v999_4);
    let mut v999_6 = Space::new();
    let mut v999_6_cursor = (v998_6_tail).read_zipper();
    for v999_6_byte in v999_6_cursor.child_mask().iter() {
      v999_6_cursor.descend_to_byte(v999_6_byte);
      {
      let v999_6_tail = v999_6_cursor.fork_read_zipper();
      let v999_6_head = Path::from_slice(&[v999_6_byte]);
      let v1000_2: Space = Space::new();
      v999_6.join_into((v1000_2).clone());
      }
      v999_6_cursor.ascend(1);
    }
    drop(v999_6_cursor);
    let v999_7: Space = map_map_kernels::compose(&(v999_5),&(v999_6));
    drop(v999_5);
    drop(v999_6);
    let v999_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v999_2));
    drop(v999_2);
    let v999_9: Space = if map_kernels::has_head(&(v999_8)) { singleton(&[]) } else { Space::new() };
    drop(v999_8);
    let mut v999_10 = Space::new();
    let mut v999_10_cursor = (v998_6_tail).read_zipper();
    for v999_10_byte in v999_10_cursor.child_mask().iter() {
      v999_10_cursor.descend_to_byte(v999_10_byte);
      {
      let v999_10_tail = v999_10_cursor.fork_read_zipper();
      let v999_10_head = Path::from_slice(&[v999_10_byte]);
      let v1001_2: Space = singleton(&(v999_10_head));
      let v1001_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1001_2));
      drop(v1001_2);
      let v1001_4: Space = if map_kernels::has_head(&(v1001_3)) { singleton(&[]) } else { Space::new() };
      drop(v1001_3);
      let v1001_5: Space = map_view_kernels::compose(&(v1001_4),&(v999_10_tail));
      drop(v1001_4);
      v999_10.join_into((v1001_5).clone());
      }
      v999_10_cursor.ascend(1);
    }
    drop(v999_10_cursor);
    let v999_11: Space = map_map_kernels::compose(&(v999_9),&(v999_10));
    drop(v999_9);
    drop(v999_10);
    let v999_12: Space = map_map_kernels::unite(&(v999_7),&(v999_11));
    drop(v999_7);
    drop(v999_11);
    v998_6.join_into((v999_12).clone());
    }
    v998_6_cursor.ascend(1);
  }
  drop(v998_6_cursor);
  (v998_6).clone()
}

fn routine_63(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1002_5 = Space::new();
  let mut v1002_5_cursor = (*s0).read_zipper();
  for v1002_5_byte in v1002_5_cursor.child_mask().iter() {
    v1002_5_cursor.descend_to_byte(v1002_5_byte);
    {
    let v1002_5_tail = v1002_5_cursor.fork_read_zipper();
    let v1002_5_head = Path::from_slice(&[v1002_5_byte]);
    let v1003_2: Space = singleton(&(v1002_5_head));
    let v1003_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1003_2));
    let v1003_4: Space = if map_kernels::has_head(&(v1003_3)) { singleton(&[]) } else { Space::new() };
    drop(v1003_3);
    let v1003_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1003_4));
    drop(v1003_4);
    let mut v1003_6 = Space::new();
    let mut v1003_6_cursor = (v1002_5_tail).read_zipper();
    for v1003_6_byte in v1003_6_cursor.child_mask().iter() {
      v1003_6_cursor.descend_to_byte(v1003_6_byte);
      {
      let v1003_6_tail = v1003_6_cursor.fork_read_zipper();
      let v1003_6_head = Path::from_slice(&[v1003_6_byte]);
      let v1004_2: Space = Space::new();
      v1003_6.join_into((v1004_2).clone());
      }
      v1003_6_cursor.ascend(1);
    }
    drop(v1003_6_cursor);
    let v1003_7: Space = map_map_kernels::compose(&(v1003_5),&(v1003_6));
    drop(v1003_5);
    drop(v1003_6);
    let v1003_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1003_2));
    drop(v1003_2);
    let v1003_9: Space = if map_kernels::has_head(&(v1003_8)) { singleton(&[]) } else { Space::new() };
    drop(v1003_8);
    let v1003_10: Space = map_view_kernels::compose(&(v1003_9),&(v1002_5_tail));
    drop(v1003_9);
    let v1003_11: Space = map_map_kernels::unite(&(v1003_7),&(v1003_10));
    drop(v1003_7);
    drop(v1003_10);
    v1002_5.join_into((v1003_11).clone());
    }
    v1002_5_cursor.ascend(1);
  }
  drop(v1002_5_cursor);
  (v1002_5).clone()
}

fn routine_64(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1005_6 = Space::new();
  let mut v1005_6_cursor = (*s0).read_zipper();
  for v1005_6_byte in v1005_6_cursor.child_mask().iter() {
    v1005_6_cursor.descend_to_byte(v1005_6_byte);
    {
    let v1005_6_tail = v1005_6_cursor.fork_read_zipper();
    let v1005_6_head = Path::from_slice(&[v1005_6_byte]);
    let v1006_2: Space = singleton(&(v1005_6_head));
    let v1006_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1006_2));
    let v1006_4: Space = if map_kernels::has_head(&(v1006_3)) { singleton(&[]) } else { Space::new() };
    drop(v1006_3);
    let v1006_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1006_4));
    drop(v1006_4);
    let mut v1006_6 = Space::new();
    let mut v1006_6_cursor = (v1005_6_tail).read_zipper();
    for v1006_6_byte in v1006_6_cursor.child_mask().iter() {
      v1006_6_cursor.descend_to_byte(v1006_6_byte);
      {
      let v1006_6_tail = v1006_6_cursor.fork_read_zipper();
      let v1006_6_head = Path::from_slice(&[v1006_6_byte]);
      let v1007_2: Space = Space::new();
      v1006_6.join_into((v1007_2).clone());
      }
      v1006_6_cursor.ascend(1);
    }
    drop(v1006_6_cursor);
    let v1006_7: Space = map_map_kernels::compose(&(v1006_5),&(v1006_6));
    drop(v1006_5);
    drop(v1006_6);
    let v1006_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1006_2));
    drop(v1006_2);
    let v1006_9: Space = if map_kernels::has_head(&(v1006_8)) { singleton(&[]) } else { Space::new() };
    drop(v1006_8);
    let mut v1006_10 = Space::new();
    let mut v1006_10_cursor = (v1005_6_tail).read_zipper();
    for v1006_10_byte in v1006_10_cursor.child_mask().iter() {
      v1006_10_cursor.descend_to_byte(v1006_10_byte);
      {
      let v1006_10_tail = v1006_10_cursor.fork_read_zipper();
      let v1006_10_head = Path::from_slice(&[v1006_10_byte]);
      let v1008_2: Space = singleton(&(v1006_10_head));
      let v1008_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1008_2));
      drop(v1008_2);
      let v1008_4: Space = if map_kernels::has_head(&(v1008_3)) { singleton(&[]) } else { Space::new() };
      drop(v1008_3);
      let v1008_5: Space = map_view_kernels::compose(&(v1008_4),&(v1006_10_tail));
      drop(v1008_4);
      v1006_10.join_into((v1008_5).clone());
      }
      v1006_10_cursor.ascend(1);
    }
    drop(v1006_10_cursor);
    let v1006_11: Space = map_map_kernels::compose(&(v1006_9),&(v1006_10));
    drop(v1006_9);
    drop(v1006_10);
    let v1006_12: Space = map_map_kernels::unite(&(v1006_7),&(v1006_11));
    drop(v1006_7);
    drop(v1006_11);
    v1005_6.join_into((v1006_12).clone());
    }
    v1005_6_cursor.ascend(1);
  }
  drop(v1005_6_cursor);
  (v1005_6).clone()
}

fn routine_65(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1009_5 = Space::new();
  let mut v1009_5_cursor = (*s0).read_zipper();
  for v1009_5_byte in v1009_5_cursor.child_mask().iter() {
    v1009_5_cursor.descend_to_byte(v1009_5_byte);
    {
    let v1009_5_tail = v1009_5_cursor.fork_read_zipper();
    let v1009_5_head = Path::from_slice(&[v1009_5_byte]);
    let v1010_2: Space = singleton(&(v1009_5_head));
    let v1010_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1010_2));
    let v1010_4: Space = if map_kernels::has_head(&(v1010_3)) { singleton(&[]) } else { Space::new() };
    drop(v1010_3);
    let v1010_5: Space = map_map_kernels::subtract(&(*CONSTANT_0),&(v1010_4));
    drop(v1010_4);
    let mut v1010_6 = Space::new();
    let mut v1010_6_cursor = (v1009_5_tail).read_zipper();
    for v1010_6_byte in v1010_6_cursor.child_mask().iter() {
      v1010_6_cursor.descend_to_byte(v1010_6_byte);
      {
      let v1010_6_tail = v1010_6_cursor.fork_read_zipper();
      let v1010_6_head = Path::from_slice(&[v1010_6_byte]);
      let v1011_2: Space = Space::new();
      v1010_6.join_into((v1011_2).clone());
      }
      v1010_6_cursor.ascend(1);
    }
    drop(v1010_6_cursor);
    let v1010_7: Space = map_map_kernels::compose(&(v1010_5),&(v1010_6));
    drop(v1010_5);
    drop(v1010_6);
    let v1010_8: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1010_2));
    drop(v1010_2);
    let v1010_9: Space = if map_kernels::has_head(&(v1010_8)) { singleton(&[]) } else { Space::new() };
    drop(v1010_8);
    let v1010_10: Space = map_view_kernels::compose(&(v1010_9),&(v1009_5_tail));
    drop(v1010_9);
    let v1010_11: Space = map_map_kernels::unite(&(v1010_7),&(v1010_10));
    drop(v1010_7);
    drop(v1010_10);
    v1009_5.join_into((v1010_11).clone());
    }
    v1009_5_cursor.ascend(1);
  }
  drop(v1009_5_cursor);
  (v1009_5).clone()
}

fn routine_66(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1012_2 = Space::new();
  let mut v1012_2_cursor = (*s0).read_zipper();
  for v1012_2_byte in v1012_2_cursor.child_mask().iter() {
    v1012_2_cursor.descend_to_byte(v1012_2_byte);
    {
    let v1012_2_tail = v1012_2_cursor.fork_read_zipper();
    let v1012_2_head = Path::from_slice(&[v1012_2_byte]);
    let v1013_2: Space = Space::new();
    v1012_2.join_into((v1013_2).clone());
    }
    v1012_2_cursor.ascend(1);
  }
  drop(v1012_2_cursor);
  (v1012_2).clone()
}

fn routine_67(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1014_3 = Space::new();
  let mut v1014_3_cursor = (*s0).read_zipper();
  for v1014_3_byte in v1014_3_cursor.child_mask().iter() {
    v1014_3_cursor.descend_to_byte(v1014_3_byte);
    {
    let v1014_3_tail = v1014_3_cursor.fork_read_zipper();
    let v1014_3_head = Path::from_slice(&[v1014_3_byte]);
    let v1015_2: Space = singleton(&(v1014_3_head));
    let v1015_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1015_2));
    drop(v1015_2);
    let v1015_4: Space = if map_kernels::has_head(&(v1015_3)) { singleton(&[]) } else { Space::new() };
    drop(v1015_3);
    let v1015_5: Space = map_view_kernels::compose(&(v1015_4),&(v1014_3_tail));
    drop(v1015_4);
    v1014_3.join_into((v1015_5).clone());
    }
    v1014_3_cursor.ascend(1);
  }
  drop(v1014_3_cursor);
  (v1014_3).clone()
}

fn routine_68(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1016_2 = Space::new();
  let mut v1016_2_cursor = (*s0).read_zipper();
  for v1016_2_byte in v1016_2_cursor.child_mask().iter() {
    v1016_2_cursor.descend_to_byte(v1016_2_byte);
    {
    let v1016_2_tail = v1016_2_cursor.fork_read_zipper();
    let v1016_2_head = Path::from_slice(&[v1016_2_byte]);
    let v1017_2: Space = Space::new();
    v1016_2.join_into((v1017_2).clone());
    }
    v1016_2_cursor.ascend(1);
  }
  drop(v1016_2_cursor);
  (v1016_2).clone()
}

fn routine_69(c: &mut Context, p0: &Path, s0: &Space) -> Space {
  let mut v1018_3 = Space::new();
  let mut v1018_3_cursor = (*s0).read_zipper();
  for v1018_3_byte in v1018_3_cursor.child_mask().iter() {
    v1018_3_cursor.descend_to_byte(v1018_3_byte);
    {
    let v1018_3_tail = v1018_3_cursor.fork_read_zipper();
    let v1018_3_head = Path::from_slice(&[v1018_3_byte]);
    let v1019_2: Space = singleton(&(v1018_3_head));
    let v1019_3: Space = map_map_kernels::intersect(&(*CONSTANT_1),&(v1019_2));
    drop(v1019_2);
    let v1019_4: Space = if map_kernels::has_head(&(v1019_3)) { singleton(&[]) } else { Space::new() };
    drop(v1019_3);
    let v1019_5: Space = map_view_kernels::compose(&(v1019_4),&(v1018_3_tail));
    drop(v1019_4);
    v1018_3.join_into((v1019_5).clone());
    }
    v1018_3_cursor.ascend(1);
  }
  drop(v1018_3_cursor);
  (v1018_3).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0),e.space(1)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
