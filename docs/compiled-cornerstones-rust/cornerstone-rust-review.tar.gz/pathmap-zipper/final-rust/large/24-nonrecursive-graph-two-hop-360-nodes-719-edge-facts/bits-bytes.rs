#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,1,0,1,0,0,0,1,0,1,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = map_kernels::unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_24 = Space::new();
  let mut v0_24_cursor = (v0_2).read_zipper();
  for v0_24_byte in v0_24_cursor.child_mask().iter() {
    v0_24_cursor.descend_to_byte(v0_24_byte);
    {
    let v0_24_tail = v0_24_cursor.fork_read_zipper();
    let v0_24_head = Path::from_slice(&[v0_24_byte]);
    let v1_2: Space = singleton(&(v0_24_head));
    let v1_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if map_kernels::has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_24_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if map_kernels::has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_24_head),&(v2_6_head));
          let mut v4_7 = Space::new();
          let mut v4_7_cursor = (v2_6_tail).read_zipper();
          for v4_7_byte in v4_7_cursor.child_mask().iter() {
            v4_7_cursor.descend_to_byte(v4_7_byte);
            {
            let v4_7_tail = v4_7_cursor.fork_read_zipper();
            let v4_7_head = Path::from_slice(&[v4_7_byte]);
            let v5_2: Space = singleton(&(v4_7_head));
            let v5_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v5_2));
            let v5_4: Space = if map_kernels::has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
            drop(v5_3);
            let v5_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v5_4));
            drop(v5_4);
            let v5_8: Space = if (v5_5).is_empty() { Space::new() } else {
              let v6_6: Path = concat_path(&(v4_6),&(v4_7_head));
              let v6_7: Space = routine_1(c, &(v6_6), &(v4_7_tail).make_space(), &(*s0.expect("unbound native input")));
              map_map_kernels::compose(&(v5_5),&(v6_7))
            };
            drop(v5_5);
            let v5_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v5_2));
            drop(v5_2);
            let v5_10: Space = if map_kernels::has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
            drop(v5_9);
            let v5_12: Space = if (v5_10).is_empty() { Space::new() } else {
              let v7_6: Path = concat_path(&(v4_6),&(v4_7_head));
              let v7_11: Space = routine_2(c, &(v7_6), &(v4_7_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v7_6);
              map_map_kernels::compose(&(v5_10),&(v7_11))
            };
            drop(v5_10);
            let v5_13: Space = map_map_kernels::unite(&(v5_8),&(v5_12));
            v4_7.join_into((v5_13).clone());
            }
            v4_7_cursor.ascend(1);
          }
          drop(v4_7_cursor);
          map_map_kernels::compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if map_kernels::has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_24_head),&(v2_6_head));
          let mut v8_11 = Space::new();
          let mut v8_11_cursor = (v2_6_tail).read_zipper();
          for v8_11_byte in v8_11_cursor.child_mask().iter() {
            v8_11_cursor.descend_to_byte(v8_11_byte);
            {
            let v8_11_tail = v8_11_cursor.fork_read_zipper();
            let v8_11_head = Path::from_slice(&[v8_11_byte]);
            let v9_2: Space = singleton(&(v8_11_head));
            let v9_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v9_2));
            let v9_4: Space = if map_kernels::has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
            drop(v9_3);
            let v9_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v9_4));
            drop(v9_4);
            let v9_8: Space = if (v9_5).is_empty() { Space::new() } else {
              let v10_6: Path = concat_path(&(v8_6),&(v8_11_head));
              let v10_7: Space = routine_1(c, &(v10_6), &(v8_11_tail).make_space(), &(*s0.expect("unbound native input")));
              map_map_kernels::compose(&(v9_5),&(v10_7))
            };
            drop(v9_5);
            let v9_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v9_2));
            drop(v9_2);
            let v9_10: Space = if map_kernels::has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
            drop(v9_9);
            let v9_12: Space = if (v9_10).is_empty() { Space::new() } else {
              let v11_6: Path = concat_path(&(v8_6),&(v8_11_head));
              let v11_11: Space = routine_3(c, &(v11_6), &(v8_11_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v11_6);
              map_map_kernels::compose(&(v9_10),&(v11_11))
            };
            drop(v9_10);
            let v9_13: Space = map_map_kernels::unite(&(v9_8),&(v9_12));
            v8_11.join_into((v9_13).clone());
            }
            v8_11_cursor.ascend(1);
          }
          drop(v8_11_cursor);
          drop(v8_6);
          map_map_kernels::compose(&(v3_10),&(v8_11))
        };
        drop(v3_10);
        let v3_13: Space = map_map_kernels::unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      map_map_kernels::compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if map_kernels::has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v12_10 = Space::new();
      let mut v12_10_cursor = (v0_24_tail).read_zipper();
      for v12_10_byte in v12_10_cursor.child_mask().iter() {
        v12_10_cursor.descend_to_byte(v12_10_byte);
        {
        let v12_10_tail = v12_10_cursor.fork_read_zipper();
        let v12_10_head = Path::from_slice(&[v12_10_byte]);
        let v13_2: Space = singleton(&(v12_10_head));
        let v13_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if map_kernels::has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v0_24_head),&(v12_10_head));
          let mut v14_7 = Space::new();
          let mut v14_7_cursor = (v12_10_tail).read_zipper();
          for v14_7_byte in v14_7_cursor.child_mask().iter() {
            v14_7_cursor.descend_to_byte(v14_7_byte);
            {
            let v14_7_tail = v14_7_cursor.fork_read_zipper();
            let v14_7_head = Path::from_slice(&[v14_7_byte]);
            let v15_2: Space = singleton(&(v14_7_head));
            let v15_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v15_2));
            let v15_4: Space = if map_kernels::has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v16_7: Space = routine_1(c, &(v16_6), &(v14_7_tail).make_space(), &(*s0.expect("unbound native input")));
              map_map_kernels::compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if map_kernels::has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v17_11: Space = routine_2(c, &(v17_6), &(v14_7_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v17_6);
              map_map_kernels::compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = map_map_kernels::unite(&(v15_8),&(v15_12));
            v14_7.join_into((v15_13).clone());
            }
            v14_7_cursor.ascend(1);
          }
          drop(v14_7_cursor);
          map_map_kernels::compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if map_kernels::has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v0_24_head),&(v12_10_head));
          let mut v18_11 = Space::new();
          let mut v18_11_cursor = (v12_10_tail).read_zipper();
          for v18_11_byte in v18_11_cursor.child_mask().iter() {
            v18_11_cursor.descend_to_byte(v18_11_byte);
            {
            let v18_11_tail = v18_11_cursor.fork_read_zipper();
            let v18_11_head = Path::from_slice(&[v18_11_byte]);
            let v19_2: Space = singleton(&(v18_11_head));
            let v19_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v19_2));
            let v19_4: Space = if map_kernels::has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v19_4));
            drop(v19_4);
            let v19_7: Space = if (v19_5).is_empty() { Space::new() } else {
              let v20_6: Space = routine_4(c, &(v18_11_head), &(v18_6), &(v18_11_tail).make_space(), &(*s0.expect("unbound native input")));
              map_map_kernels::compose(&(v19_5),&(v20_6))
            };
            drop(v19_5);
            let v19_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v19_2));
            drop(v19_2);
            let v19_9: Space = if map_kernels::has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
            drop(v19_8);
            let v19_11: Space = if (v19_9).is_empty() { Space::new() } else {
              let v21_10: Space = routine_5(c, &(v18_11_head), &(v18_6), &(v18_11_tail).make_space(), &(*s0.expect("unbound native input")));
              map_map_kernels::compose(&(v19_9),&(v21_10))
            };
            drop(v19_9);
            let v19_12: Space = map_map_kernels::unite(&(v19_7),&(v19_11));
            v18_11.join_into((v19_12).clone());
            }
            v18_11_cursor.ascend(1);
          }
          drop(v18_11_cursor);
          drop(v18_6);
          map_map_kernels::compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = map_map_kernels::unite(&(v13_8),&(v13_12));
        v12_10.join_into((v13_13).clone());
        }
        v12_10_cursor.ascend(1);
      }
      drop(v12_10_cursor);
      map_map_kernels::compose(&(v1_9),&(v12_10))
    };
    drop(v1_9);
    let v1_12: Space = map_map_kernels::unite(&(v1_7),&(v1_11));
    v0_24.join_into((v1_12).clone());
    }
    v0_24_cursor.ascend(1);
  }
  drop(v0_24_cursor);
  drop(v0_2);
  let v0_26: Space = map_kernels::wrap(&(v0_24),&(*CONSTANT_3));
  (v0_26).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v22_24 = Space::new();
  let mut v22_24_cursor = (*s0).read_zipper();
  for v22_24_byte in v22_24_cursor.child_mask().iter() {
    v22_24_cursor.descend_to_byte(v22_24_byte);
    {
    let v22_24_tail = v22_24_cursor.fork_read_zipper();
    let v22_24_head = Path::from_slice(&[v22_24_byte]);
    let v23_2: Space = singleton(&(v22_24_head));
    let v23_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v23_2));
    let v23_4: Space = if map_kernels::has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
    drop(v23_3);
    let v23_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v23_4));
    drop(v23_4);
    let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
      let v24_6: Path = concat_path(&(*p0),&(v22_24_head));
      let mut v24_7 = Space::new();
      let mut v24_7_cursor = (v22_24_tail).read_zipper();
      for v24_7_byte in v24_7_cursor.child_mask().iter() {
        v24_7_cursor.descend_to_byte(v24_7_byte);
        {
        let v24_7_tail = v24_7_cursor.fork_read_zipper();
        let v24_7_head = Path::from_slice(&[v24_7_byte]);
        let v25_2: Space = singleton(&(v24_7_head));
        let v25_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v25_2));
        let v25_4: Space = if map_kernels::has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
        drop(v25_3);
        let v25_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v25_4));
        drop(v25_4);
        let v25_8: Space = if (v25_5).is_empty() { Space::new() } else {
          let v26_6: Path = concat_path(&(v24_6),&(v24_7_head));
          let mut v26_7 = Space::new();
          let mut v26_7_cursor = (v24_7_tail).read_zipper();
          for v26_7_byte in v26_7_cursor.child_mask().iter() {
            v26_7_cursor.descend_to_byte(v26_7_byte);
            {
            let v26_7_tail = v26_7_cursor.fork_read_zipper();
            let v26_7_head = Path::from_slice(&[v26_7_byte]);
            let v27_2: Space = singleton(&(v26_7_head));
            let v27_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v27_2));
            let v27_4: Space = if map_kernels::has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
            drop(v27_3);
            let v27_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v27_4));
            drop(v27_4);
            let v27_8: Space = if (v27_5).is_empty() { Space::new() } else {
              let v28_6: Path = concat_path(&(v26_6),&(v26_7_head));
              let v28_7: Space = routine_6(c, &(v28_6), &(v26_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v27_5),&(v28_7))
            };
            drop(v27_5);
            let v27_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v27_2));
            drop(v27_2);
            let v27_10: Space = if map_kernels::has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
            drop(v27_9);
            let v27_12: Space = if (v27_10).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v26_6),&(v26_7_head));
              let v29_11: Space = routine_7(c, &(v29_6), &(v26_7_tail).make_space(), &(*s1));
              drop(v29_6);
              map_map_kernels::compose(&(v27_10),&(v29_11))
            };
            drop(v27_10);
            let v27_13: Space = map_map_kernels::unite(&(v27_8),&(v27_12));
            v26_7.join_into((v27_13).clone());
            }
            v26_7_cursor.ascend(1);
          }
          drop(v26_7_cursor);
          map_map_kernels::compose(&(v25_5),&(v26_7))
        };
        drop(v25_5);
        let v25_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v25_2));
        drop(v25_2);
        let v25_10: Space = if map_kernels::has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
        drop(v25_9);
        let v25_12: Space = if (v25_10).is_empty() { Space::new() } else {
          let v30_6: Path = concat_path(&(v24_6),&(v24_7_head));
          let mut v30_11 = Space::new();
          let mut v30_11_cursor = (v24_7_tail).read_zipper();
          for v30_11_byte in v30_11_cursor.child_mask().iter() {
            v30_11_cursor.descend_to_byte(v30_11_byte);
            {
            let v30_11_tail = v30_11_cursor.fork_read_zipper();
            let v30_11_head = Path::from_slice(&[v30_11_byte]);
            let v31_2: Space = singleton(&(v30_11_head));
            let v31_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v31_2));
            let v31_4: Space = if map_kernels::has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
            drop(v31_3);
            let v31_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v31_4));
            drop(v31_4);
            let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
              let v32_6: Path = concat_path(&(v30_6),&(v30_11_head));
              let v32_7: Space = routine_6(c, &(v32_6), &(v30_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v31_5),&(v32_7))
            };
            drop(v31_5);
            let v31_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v31_2));
            drop(v31_2);
            let v31_10: Space = if map_kernels::has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
            drop(v31_9);
            let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v30_6),&(v30_11_head));
              let v33_11: Space = routine_3(c, &(v33_6), &(v30_11_tail).make_space(), &(*s1));
              drop(v33_6);
              map_map_kernels::compose(&(v31_10),&(v33_11))
            };
            drop(v31_10);
            let v31_13: Space = map_map_kernels::unite(&(v31_8),&(v31_12));
            v30_11.join_into((v31_13).clone());
            }
            v30_11_cursor.ascend(1);
          }
          drop(v30_11_cursor);
          drop(v30_6);
          map_map_kernels::compose(&(v25_10),&(v30_11))
        };
        drop(v25_10);
        let v25_13: Space = map_map_kernels::unite(&(v25_8),&(v25_12));
        v24_7.join_into((v25_13).clone());
        }
        v24_7_cursor.ascend(1);
      }
      drop(v24_7_cursor);
      map_map_kernels::compose(&(v23_5),&(v24_7))
    };
    drop(v23_5);
    let v23_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v23_2));
    drop(v23_2);
    let v23_10: Space = if map_kernels::has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
    drop(v23_9);
    let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&(v22_24_head));
      let mut v34_11 = Space::new();
      let mut v34_11_cursor = (v22_24_tail).read_zipper();
      for v34_11_byte in v34_11_cursor.child_mask().iter() {
        v34_11_cursor.descend_to_byte(v34_11_byte);
        {
        let v34_11_tail = v34_11_cursor.fork_read_zipper();
        let v34_11_head = Path::from_slice(&[v34_11_byte]);
        let v35_2: Space = singleton(&(v34_11_head));
        let v35_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v35_2));
        let v35_4: Space = if map_kernels::has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let mut v36_7 = Space::new();
          let mut v36_7_cursor = (v34_11_tail).read_zipper();
          for v36_7_byte in v36_7_cursor.child_mask().iter() {
            v36_7_cursor.descend_to_byte(v36_7_byte);
            {
            let v36_7_tail = v36_7_cursor.fork_read_zipper();
            let v36_7_head = Path::from_slice(&[v36_7_byte]);
            let v37_2: Space = singleton(&(v36_7_head));
            let v37_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v37_2));
            let v37_4: Space = if map_kernels::has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
            drop(v37_3);
            let v37_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v37_4));
            drop(v37_4);
            let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
              let v38_6: Path = concat_path(&(v36_6),&(v36_7_head));
              let v38_7: Space = routine_6(c, &(v38_6), &(v36_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v37_5),&(v38_7))
            };
            drop(v37_5);
            let v37_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v37_2));
            drop(v37_2);
            let v37_10: Space = if map_kernels::has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
            drop(v37_9);
            let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v36_6),&(v36_7_head));
              let v39_11: Space = routine_7(c, &(v39_6), &(v36_7_tail).make_space(), &(*s1));
              drop(v39_6);
              map_map_kernels::compose(&(v37_10),&(v39_11))
            };
            drop(v37_10);
            let v37_13: Space = map_map_kernels::unite(&(v37_8),&(v37_12));
            v36_7.join_into((v37_13).clone());
            }
            v36_7_cursor.ascend(1);
          }
          drop(v36_7_cursor);
          map_map_kernels::compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if map_kernels::has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let mut v40_11 = Space::new();
          let mut v40_11_cursor = (v34_11_tail).read_zipper();
          for v40_11_byte in v40_11_cursor.child_mask().iter() {
            v40_11_cursor.descend_to_byte(v40_11_byte);
            {
            let v40_11_tail = v40_11_cursor.fork_read_zipper();
            let v40_11_head = Path::from_slice(&[v40_11_byte]);
            let v41_2: Space = singleton(&(v40_11_head));
            let v41_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v41_2));
            let v41_4: Space = if map_kernels::has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v41_4));
            drop(v41_4);
            let v41_7: Space = if (v41_5).is_empty() { Space::new() } else {
              let v42_6: Space = routine_4(c, &(v40_11_head), &(v40_6), &(v40_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v41_5),&(v42_6))
            };
            drop(v41_5);
            let v41_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v41_2));
            drop(v41_2);
            let v41_9: Space = if map_kernels::has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
            drop(v41_8);
            let v41_11: Space = if (v41_9).is_empty() { Space::new() } else {
              let v43_10: Space = routine_5(c, &(v40_11_head), &(v40_6), &(v40_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v41_9),&(v43_10))
            };
            drop(v41_9);
            let v41_12: Space = map_map_kernels::unite(&(v41_7),&(v41_11));
            v40_11.join_into((v41_12).clone());
            }
            v40_11_cursor.ascend(1);
          }
          drop(v40_11_cursor);
          drop(v40_6);
          map_map_kernels::compose(&(v35_10),&(v40_11))
        };
        drop(v35_10);
        let v35_13: Space = map_map_kernels::unite(&(v35_8),&(v35_12));
        v34_11.join_into((v35_13).clone());
        }
        v34_11_cursor.ascend(1);
      }
      drop(v34_11_cursor);
      drop(v34_6);
      map_map_kernels::compose(&(v23_10),&(v34_11))
    };
    drop(v23_10);
    let v23_13: Space = map_map_kernels::unite(&(v23_8),&(v23_12));
    v22_24.join_into((v23_13).clone());
    }
    v22_24_cursor.ascend(1);
  }
  drop(v22_24_cursor);
  (v22_24).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v44_24 = Space::new();
  let mut v44_24_cursor = (*s0).read_zipper();
  for v44_24_byte in v44_24_cursor.child_mask().iter() {
    v44_24_cursor.descend_to_byte(v44_24_byte);
    {
    let v44_24_tail = v44_24_cursor.fork_read_zipper();
    let v44_24_head = Path::from_slice(&[v44_24_byte]);
    let v45_2: Space = singleton(&(v44_24_head));
    let v45_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v45_2));
    let v45_4: Space = if map_kernels::has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v44_24_head));
      let mut v46_7 = Space::new();
      let mut v46_7_cursor = (v44_24_tail).read_zipper();
      for v46_7_byte in v46_7_cursor.child_mask().iter() {
        v46_7_cursor.descend_to_byte(v46_7_byte);
        {
        let v46_7_tail = v46_7_cursor.fork_read_zipper();
        let v46_7_head = Path::from_slice(&[v46_7_byte]);
        let v47_2: Space = singleton(&(v46_7_head));
        let v47_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if map_kernels::has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (v47_5).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&(v46_7_head));
          let mut v48_7 = Space::new();
          let mut v48_7_cursor = (v46_7_tail).read_zipper();
          for v48_7_byte in v48_7_cursor.child_mask().iter() {
            v48_7_cursor.descend_to_byte(v48_7_byte);
            {
            let v48_7_tail = v48_7_cursor.fork_read_zipper();
            let v48_7_head = Path::from_slice(&[v48_7_byte]);
            let v49_2: Space = singleton(&(v48_7_head));
            let v49_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v49_2));
            let v49_4: Space = if map_kernels::has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
            drop(v49_3);
            let v49_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v49_4));
            drop(v49_4);
            let v49_8: Space = if (v49_5).is_empty() { Space::new() } else {
              let v50_6: Path = concat_path(&(v48_6),&(v48_7_head));
              let v50_7: Space = routine_6(c, &(v50_6), &(v48_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v49_5),&(v50_7))
            };
            drop(v49_5);
            let v49_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v49_2));
            drop(v49_2);
            let v49_10: Space = if map_kernels::has_head(&(v49_9)) { singleton(&[]) } else { Space::new() };
            drop(v49_9);
            let v49_12: Space = if (v49_10).is_empty() { Space::new() } else {
              let v51_6: Path = concat_path(&(v48_6),&(v48_7_head));
              let v51_11: Space = routine_7(c, &(v51_6), &(v48_7_tail).make_space(), &(*s1));
              drop(v51_6);
              map_map_kernels::compose(&(v49_10),&(v51_11))
            };
            drop(v49_10);
            let v49_13: Space = map_map_kernels::unite(&(v49_8),&(v49_12));
            v48_7.join_into((v49_13).clone());
            }
            v48_7_cursor.ascend(1);
          }
          drop(v48_7_cursor);
          map_map_kernels::compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if map_kernels::has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (v47_10).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v46_6),&(v46_7_head));
          let mut v52_11 = Space::new();
          let mut v52_11_cursor = (v46_7_tail).read_zipper();
          for v52_11_byte in v52_11_cursor.child_mask().iter() {
            v52_11_cursor.descend_to_byte(v52_11_byte);
            {
            let v52_11_tail = v52_11_cursor.fork_read_zipper();
            let v52_11_head = Path::from_slice(&[v52_11_byte]);
            let v53_2: Space = singleton(&(v52_11_head));
            let v53_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v53_2));
            let v53_4: Space = if map_kernels::has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
            drop(v53_3);
            let v53_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v53_4));
            drop(v53_4);
            let v53_8: Space = if (v53_5).is_empty() { Space::new() } else {
              let v54_6: Path = concat_path(&(v52_6),&(v52_11_head));
              let v54_7: Space = routine_6(c, &(v54_6), &(v52_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v53_5),&(v54_7))
            };
            drop(v53_5);
            let v53_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v53_2));
            drop(v53_2);
            let v53_10: Space = if map_kernels::has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
            drop(v53_9);
            let v53_12: Space = if (v53_10).is_empty() { Space::new() } else {
              let v55_6: Path = concat_path(&(v52_6),&(v52_11_head));
              let v55_11: Space = routine_3(c, &(v55_6), &(v52_11_tail).make_space(), &(*s1));
              drop(v55_6);
              map_map_kernels::compose(&(v53_10),&(v55_11))
            };
            drop(v53_10);
            let v53_13: Space = map_map_kernels::unite(&(v53_8),&(v53_12));
            v52_11.join_into((v53_13).clone());
            }
            v52_11_cursor.ascend(1);
          }
          drop(v52_11_cursor);
          drop(v52_6);
          map_map_kernels::compose(&(v47_10),&(v52_11))
        };
        drop(v47_10);
        let v47_13: Space = map_map_kernels::unite(&(v47_8),&(v47_12));
        v46_7.join_into((v47_13).clone());
        }
        v46_7_cursor.ascend(1);
      }
      drop(v46_7_cursor);
      map_map_kernels::compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if map_kernels::has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_12: Space = if (v45_10).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&(v44_24_head));
      let mut v56_11 = Space::new();
      let mut v56_11_cursor = (v44_24_tail).read_zipper();
      for v56_11_byte in v56_11_cursor.child_mask().iter() {
        v56_11_cursor.descend_to_byte(v56_11_byte);
        {
        let v56_11_tail = v56_11_cursor.fork_read_zipper();
        let v56_11_head = Path::from_slice(&[v56_11_byte]);
        let v57_2: Space = singleton(&(v56_11_head));
        let v57_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if map_kernels::has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
          let mut v58_6 = Space::new();
          let mut v58_6_cursor = (v56_11_tail).read_zipper();
          for v58_6_byte in v58_6_cursor.child_mask().iter() {
            v58_6_cursor.descend_to_byte(v58_6_byte);
            {
            let v58_6_tail = v58_6_cursor.fork_read_zipper();
            let v58_6_head = Path::from_slice(&[v58_6_byte]);
            let v59_2: Space = singleton(&(v58_6_head));
            let v59_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v59_2));
            let v59_4: Space = if map_kernels::has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
            drop(v59_3);
            let v59_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v59_4));
            drop(v59_4);
            let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
              let v60_6: Path = concat_path(&(v56_11_head),&(v58_6_head));
              let v60_7: Space = routine_8(c, &(v60_6), &(v56_6), &(v58_6_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v59_5),&(v60_7))
            };
            drop(v59_5);
            let v59_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v59_2));
            drop(v59_2);
            let v59_10: Space = if map_kernels::has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
            drop(v59_9);
            let v59_12: Space = if (v59_10).is_empty() { Space::new() } else {
              let v61_6: Path = concat_path(&(v56_11_head),&(v58_6_head));
              let v61_11: Space = routine_9(c, &(v61_6), &(v56_6), &(v58_6_tail).make_space(), &(*s1));
              drop(v61_6);
              map_map_kernels::compose(&(v59_10),&(v61_11))
            };
            drop(v59_10);
            let v59_13: Space = map_map_kernels::unite(&(v59_8),&(v59_12));
            v58_6.join_into((v59_13).clone());
            }
            v58_6_cursor.ascend(1);
          }
          drop(v58_6_cursor);
          map_map_kernels::compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if map_kernels::has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
          let mut v62_10 = Space::new();
          let mut v62_10_cursor = (v56_11_tail).read_zipper();
          for v62_10_byte in v62_10_cursor.child_mask().iter() {
            v62_10_cursor.descend_to_byte(v62_10_byte);
            {
            let v62_10_tail = v62_10_cursor.fork_read_zipper();
            let v62_10_head = Path::from_slice(&[v62_10_byte]);
            let v63_2: Space = singleton(&(v62_10_head));
            let v63_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v63_2));
            let v63_4: Space = if map_kernels::has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
            drop(v63_3);
            let v63_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v63_4));
            drop(v63_4);
            let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
              let v64_6: Path = concat_path(&(v56_11_head),&(v62_10_head));
              let v64_7: Space = routine_8(c, &(v64_6), &(v56_6), &(v62_10_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v63_5),&(v64_7))
            };
            drop(v63_5);
            let v63_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v63_2));
            drop(v63_2);
            let v63_10: Space = if map_kernels::has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
            drop(v63_9);
            let v63_12: Space = if (v63_10).is_empty() { Space::new() } else {
              let v65_6: Path = concat_path(&(v56_11_head),&(v62_10_head));
              let v65_11: Space = routine_10(c, &(v65_6), &(v56_6), &(v62_10_tail).make_space(), &(*s1));
              drop(v65_6);
              map_map_kernels::compose(&(v63_10),&(v65_11))
            };
            drop(v63_10);
            let v63_13: Space = map_map_kernels::unite(&(v63_8),&(v63_12));
            v62_10.join_into((v63_13).clone());
            }
            v62_10_cursor.ascend(1);
          }
          drop(v62_10_cursor);
          map_map_kernels::compose(&(v57_9),&(v62_10))
        };
        drop(v57_9);
        let v57_12: Space = map_map_kernels::unite(&(v57_7),&(v57_11));
        v56_11.join_into((v57_12).clone());
        }
        v56_11_cursor.ascend(1);
      }
      drop(v56_11_cursor);
      drop(v56_6);
      map_map_kernels::compose(&(v45_10),&(v56_11))
    };
    drop(v45_10);
    let v45_13: Space = map_map_kernels::unite(&(v45_8),&(v45_12));
    v44_24.join_into((v45_13).clone());
    }
    v44_24_cursor.ascend(1);
  }
  drop(v44_24_cursor);
  (v44_24).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v66_19: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let mut v66_26 = Space::new();
  let mut v66_26_cursor = (*s0).read_zipper();
  for v66_26_byte in v66_26_cursor.child_mask().iter() {
    v66_26_cursor.descend_to_byte(v66_26_byte);
    {
    let v66_26_tail = v66_26_cursor.fork_read_zipper();
    let v66_26_head = Path::from_slice(&[v66_26_byte]);
    let v67_2: Space = singleton(&(v66_26_head));
    let v67_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v67_2));
    let v67_4: Space = if map_kernels::has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (v67_5).is_empty() { Space::new() } else {
      let mut v68_6 = Space::new();
      let mut v68_6_cursor = (v66_26_tail).read_zipper();
      for v68_6_byte in v68_6_cursor.child_mask().iter() {
        v68_6_cursor.descend_to_byte(v68_6_byte);
        {
        let v68_6_tail = v68_6_cursor.fork_read_zipper();
        let v68_6_head = Path::from_slice(&[v68_6_byte]);
        let v69_2: Space = singleton(&(v68_6_head));
        let v69_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v69_2));
        let v69_4: Space = if map_kernels::has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v69_4));
        drop(v69_4);
        let v69_8: Space = if (v69_5).is_empty() { Space::new() } else {
          let v70_6: Path = concat_path(&(v66_26_head),&(v68_6_head));
          let mut v70_7 = Space::new();
          let mut v70_7_cursor = (v68_6_tail).read_zipper();
          for v70_7_byte in v70_7_cursor.child_mask().iter() {
            v70_7_cursor.descend_to_byte(v70_7_byte);
            {
            let v70_7_tail = v70_7_cursor.fork_read_zipper();
            let v70_7_head = Path::from_slice(&[v70_7_byte]);
            let v71_2: Space = singleton(&(v70_7_head));
            let v71_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v71_2));
            let v71_4: Space = if map_kernels::has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
            drop(v71_3);
            let v71_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v71_4));
            drop(v71_4);
            let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
              let v72_6: Path = concat_path(&(v70_6),&(v70_7_head));
              let v72_7: Space = routine_11(c, &(v72_6), &(*p0), &(v70_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v71_5),&(v72_7))
            };
            drop(v71_5);
            let v71_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v71_2));
            drop(v71_2);
            let v71_10: Space = if map_kernels::has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
            drop(v71_9);
            let v71_12: Space = if (v71_10).is_empty() { Space::new() } else {
              let v73_6: Path = concat_path(&(v70_6),&(v70_7_head));
              let v73_11: Space = routine_12(c, &(v73_6), &(*p0), &(v70_7_tail).make_space(), &(*s1));
              drop(v73_6);
              map_map_kernels::compose(&(v71_10),&(v73_11))
            };
            drop(v71_10);
            let v71_13: Space = map_map_kernels::unite(&(v71_8),&(v71_12));
            v70_7.join_into((v71_13).clone());
            }
            v70_7_cursor.ascend(1);
          }
          drop(v70_7_cursor);
          map_map_kernels::compose(&(v69_5),&(v70_7))
        };
        drop(v69_5);
        let v69_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v69_2));
        drop(v69_2);
        let v69_10: Space = if map_kernels::has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
        drop(v69_9);
        let v69_12: Space = if (v69_10).is_empty() { Space::new() } else {
          let v74_6: Path = concat_path(&(v66_26_head),&(v68_6_head));
          let mut v74_11 = Space::new();
          let mut v74_11_cursor = (v68_6_tail).read_zipper();
          for v74_11_byte in v74_11_cursor.child_mask().iter() {
            v74_11_cursor.descend_to_byte(v74_11_byte);
            {
            let v74_11_tail = v74_11_cursor.fork_read_zipper();
            let v74_11_head = Path::from_slice(&[v74_11_byte]);
            let v75_2: Space = singleton(&(v74_11_head));
            let v75_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v75_2));
            let v75_4: Space = if map_kernels::has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
            drop(v75_3);
            let v75_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v75_4));
            drop(v75_4);
            let v75_8: Space = if (v75_5).is_empty() { Space::new() } else {
              let v76_6: Path = concat_path(&(v74_6),&(v74_11_head));
              let v76_7: Space = routine_11(c, &(v76_6), &(*p0), &(v74_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v75_5),&(v76_7))
            };
            drop(v75_5);
            let v75_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v75_2));
            drop(v75_2);
            let v75_10: Space = if map_kernels::has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
            drop(v75_9);
            let v75_12: Space = if (v75_10).is_empty() { Space::new() } else {
              let v77_6: Path = concat_path(&(v74_6),&(v74_11_head));
              let v77_11: Space = routine_10(c, &(v77_6), &(*p0), &(v74_11_tail).make_space(), &(*s1));
              drop(v77_6);
              map_map_kernels::compose(&(v75_10),&(v77_11))
            };
            drop(v75_10);
            let v75_13: Space = map_map_kernels::unite(&(v75_8),&(v75_12));
            v74_11.join_into((v75_13).clone());
            }
            v74_11_cursor.ascend(1);
          }
          drop(v74_11_cursor);
          drop(v74_6);
          map_map_kernels::compose(&(v69_10),&(v74_11))
        };
        drop(v69_10);
        let v69_13: Space = map_map_kernels::unite(&(v69_8),&(v69_12));
        v68_6.join_into((v69_13).clone());
        }
        v68_6_cursor.ascend(1);
      }
      drop(v68_6_cursor);
      map_map_kernels::compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if map_kernels::has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_12: Space = if (v67_9).is_empty() { Space::new() } else {
      let v78_10: Space = map_kernels::unwrap(&(v66_19),&(v66_26_head));
      let mut v78_11 = Space::new();
      let mut v78_11_cursor = (v66_26_tail).read_zipper();
      for v78_11_byte in v78_11_cursor.child_mask().iter() {
        v78_11_cursor.descend_to_byte(v78_11_byte);
        {
        let v78_11_tail = v78_11_cursor.fork_read_zipper();
        let v78_11_head = Path::from_slice(&[v78_11_byte]);
        let v79_2: Space = singleton(&(v78_11_head));
        let v79_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v79_2));
        let v79_4: Space = if map_kernels::has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
        drop(v79_3);
        let v79_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v79_4));
        drop(v79_4);
        let v79_8: Space = if (v79_5).is_empty() { Space::new() } else {
          let v80_6: Path = concat_path(&(v66_26_head),&(v78_11_head));
          let mut v80_7 = Space::new();
          let mut v80_7_cursor = (v78_11_tail).read_zipper();
          for v80_7_byte in v80_7_cursor.child_mask().iter() {
            v80_7_cursor.descend_to_byte(v80_7_byte);
            {
            let v80_7_tail = v80_7_cursor.fork_read_zipper();
            let v80_7_head = Path::from_slice(&[v80_7_byte]);
            let v81_2: Space = singleton(&(v80_7_head));
            let v81_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v81_2));
            let v81_4: Space = if map_kernels::has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
            drop(v81_3);
            let v81_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v81_4));
            drop(v81_4);
            let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
              let v82_6: Path = concat_path(&(v80_6),&(v80_7_head));
              let v82_7: Space = routine_11(c, &(v82_6), &(*p0), &(v80_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v81_5),&(v82_7))
            };
            drop(v81_5);
            let v81_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v81_2));
            drop(v81_2);
            let v81_10: Space = if map_kernels::has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
            drop(v81_9);
            let v81_12: Space = if (v81_10).is_empty() { Space::new() } else {
              let v83_6: Path = concat_path(&(v80_6),&(v80_7_head));
              let v83_11: Space = routine_12(c, &(v83_6), &(*p0), &(v80_7_tail).make_space(), &(*s1));
              drop(v83_6);
              map_map_kernels::compose(&(v81_10),&(v83_11))
            };
            drop(v81_10);
            let v81_13: Space = map_map_kernels::unite(&(v81_8),&(v81_12));
            v80_7.join_into((v81_13).clone());
            }
            v80_7_cursor.ascend(1);
          }
          drop(v80_7_cursor);
          drop(v80_6);
          map_map_kernels::compose(&(v79_5),&(v80_7))
        };
        drop(v79_5);
        let v79_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v79_2));
        drop(v79_2);
        let v79_10: Space = if map_kernels::has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
        drop(v79_9);
        let v79_13: Space = if (v79_10).is_empty() { Space::new() } else {
          let v84_11: Space = map_kernels::unwrap(&(v78_10),&(v78_11_head));
          let mut v84_12 = Space::new();
          let mut v84_12_cursor = (v84_11).read_zipper();
          for v84_12_byte in v84_12_cursor.child_mask().iter() {
            v84_12_cursor.descend_to_byte(v84_12_byte);
            {
            let v84_12_tail = v84_12_cursor.fork_read_zipper();
            let v84_12_head = Path::from_slice(&[v84_12_byte]);
            let v85_2: Space = singleton(&(v84_12_head));
            let v85_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v85_2));
            let v85_4: Space = if map_kernels::has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
            drop(v85_3);
            let v85_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v85_4));
            drop(v85_4);
            let v85_7: Space = if (v85_5).is_empty() { Space::new() } else {
              let v86_6: Space = routine_13(c, &(v84_12_head), &(*p0), &(v84_12_tail).make_space());
              map_map_kernels::compose(&(v85_5),&(v86_6))
            };
            drop(v85_5);
            let v85_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v85_2));
            drop(v85_2);
            let v85_9: Space = if map_kernels::has_head(&(v85_8)) { singleton(&[]) } else { Space::new() };
            drop(v85_8);
            let v85_11: Space = if (v85_9).is_empty() { Space::new() } else {
              let v87_10: Space = routine_14(c, &(v84_12_head), &(*p0), &(v84_12_tail).make_space());
              map_map_kernels::compose(&(v85_9),&(v87_10))
            };
            drop(v85_9);
            let v85_12: Space = map_map_kernels::unite(&(v85_7),&(v85_11));
            v84_12.join_into((v85_12).clone());
            }
            v84_12_cursor.ascend(1);
          }
          drop(v84_12_cursor);
          drop(v84_11);
          map_map_kernels::compose(&(v79_10),&(v84_12))
        };
        drop(v79_10);
        let v79_14: Space = map_map_kernels::unite(&(v79_8),&(v79_13));
        v78_11.join_into((v79_14).clone());
        }
        v78_11_cursor.ascend(1);
      }
      drop(v78_11_cursor);
      drop(v78_10);
      map_map_kernels::compose(&(v67_9),&(v78_11))
    };
    drop(v67_9);
    let v67_13: Space = map_map_kernels::unite(&(v67_7),&(v67_12));
    v66_26.join_into((v67_13).clone());
    }
    v66_26_cursor.ascend(1);
  }
  drop(v66_26_cursor);
  drop(v66_19);
  (v66_26).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v88_20: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v88_21: Space = map_kernels::unwrap(&(v88_20),&(*p0));
  drop(v88_20);
  let mut v88_28 = Space::new();
  let mut v88_28_cursor = (*s0).read_zipper();
  for v88_28_byte in v88_28_cursor.child_mask().iter() {
    v88_28_cursor.descend_to_byte(v88_28_byte);
    {
    let v88_28_tail = v88_28_cursor.fork_read_zipper();
    let v88_28_head = Path::from_slice(&[v88_28_byte]);
    let v89_2: Space = singleton(&(v88_28_head));
    let v89_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v89_2));
    let v89_4: Space = if map_kernels::has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
    drop(v89_3);
    let v89_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v89_4));
    drop(v89_4);
    let v89_8: Space = if (v89_5).is_empty() { Space::new() } else {
      let v90_6: Path = concat_path(&(*p0),&(v88_28_head));
      let mut v90_7 = Space::new();
      let mut v90_7_cursor = (v88_28_tail).read_zipper();
      for v90_7_byte in v90_7_cursor.child_mask().iter() {
        v90_7_cursor.descend_to_byte(v90_7_byte);
        {
        let v90_7_tail = v90_7_cursor.fork_read_zipper();
        let v90_7_head = Path::from_slice(&[v90_7_byte]);
        let v91_2: Space = singleton(&(v90_7_head));
        let v91_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v91_2));
        let v91_4: Space = if map_kernels::has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v91_4));
        drop(v91_4);
        let v91_8: Space = if (v91_5).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v90_6),&(v90_7_head));
          let mut v92_7 = Space::new();
          let mut v92_7_cursor = (v90_7_tail).read_zipper();
          for v92_7_byte in v92_7_cursor.child_mask().iter() {
            v92_7_cursor.descend_to_byte(v92_7_byte);
            {
            let v92_7_tail = v92_7_cursor.fork_read_zipper();
            let v92_7_head = Path::from_slice(&[v92_7_byte]);
            let v93_2: Space = singleton(&(v92_7_head));
            let v93_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v93_2));
            let v93_4: Space = if map_kernels::has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
            drop(v93_3);
            let v93_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v93_4));
            drop(v93_4);
            let v93_8: Space = if (v93_5).is_empty() { Space::new() } else {
              let v94_6: Path = concat_path(&(v92_6),&(v92_7_head));
              let v94_7: Space = routine_15(c, &(v94_6), &(*p1), &(v92_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v93_5),&(v94_7))
            };
            drop(v93_5);
            let v93_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v93_2));
            drop(v93_2);
            let v93_10: Space = if map_kernels::has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
            drop(v93_9);
            let v93_12: Space = if (v93_10).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v92_6),&(v92_7_head));
              let v95_11: Space = routine_16(c, &(v95_6), &(*p1), &(v92_7_tail).make_space(), &(*s1));
              drop(v95_6);
              map_map_kernels::compose(&(v93_10),&(v95_11))
            };
            drop(v93_10);
            let v93_13: Space = map_map_kernels::unite(&(v93_8),&(v93_12));
            v92_7.join_into((v93_13).clone());
            }
            v92_7_cursor.ascend(1);
          }
          drop(v92_7_cursor);
          map_map_kernels::compose(&(v91_5),&(v92_7))
        };
        drop(v91_5);
        let v91_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v91_2));
        drop(v91_2);
        let v91_10: Space = if map_kernels::has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
        drop(v91_9);
        let v91_12: Space = if (v91_10).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v90_6),&(v90_7_head));
          let mut v96_11 = Space::new();
          let mut v96_11_cursor = (v90_7_tail).read_zipper();
          for v96_11_byte in v96_11_cursor.child_mask().iter() {
            v96_11_cursor.descend_to_byte(v96_11_byte);
            {
            let v96_11_tail = v96_11_cursor.fork_read_zipper();
            let v96_11_head = Path::from_slice(&[v96_11_byte]);
            let v97_2: Space = singleton(&(v96_11_head));
            let v97_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v97_2));
            let v97_4: Space = if map_kernels::has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
            drop(v97_3);
            let v97_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v97_4));
            drop(v97_4);
            let v97_8: Space = if (v97_5).is_empty() { Space::new() } else {
              let v98_6: Path = concat_path(&(v96_6),&(v96_11_head));
              let v98_7: Space = routine_15(c, &(v98_6), &(*p1), &(v96_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v97_5),&(v98_7))
            };
            drop(v97_5);
            let v97_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v97_2));
            drop(v97_2);
            let v97_10: Space = if map_kernels::has_head(&(v97_9)) { singleton(&[]) } else { Space::new() };
            drop(v97_9);
            let v97_12: Space = if (v97_10).is_empty() { Space::new() } else {
              let v99_6: Path = concat_path(&(v96_6),&(v96_11_head));
              let v99_11: Space = routine_10(c, &(v99_6), &(*p1), &(v96_11_tail).make_space(), &(*s1));
              drop(v99_6);
              map_map_kernels::compose(&(v97_10),&(v99_11))
            };
            drop(v97_10);
            let v97_13: Space = map_map_kernels::unite(&(v97_8),&(v97_12));
            v96_11.join_into((v97_13).clone());
            }
            v96_11_cursor.ascend(1);
          }
          drop(v96_11_cursor);
          drop(v96_6);
          map_map_kernels::compose(&(v91_10),&(v96_11))
        };
        drop(v91_10);
        let v91_13: Space = map_map_kernels::unite(&(v91_8),&(v91_12));
        v90_7.join_into((v91_13).clone());
        }
        v90_7_cursor.ascend(1);
      }
      drop(v90_7_cursor);
      map_map_kernels::compose(&(v89_5),&(v90_7))
    };
    drop(v89_5);
    let v89_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v89_2));
    drop(v89_2);
    let v89_10: Space = if map_kernels::has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
    drop(v89_9);
    let v89_13: Space = if (v89_10).is_empty() { Space::new() } else {
      let v100_6: Path = concat_path(&(*p0),&(v88_28_head));
      let v100_11: Space = map_kernels::unwrap(&(v88_21),&(v88_28_head));
      let mut v100_12 = Space::new();
      let mut v100_12_cursor = (v88_28_tail).read_zipper();
      for v100_12_byte in v100_12_cursor.child_mask().iter() {
        v100_12_cursor.descend_to_byte(v100_12_byte);
        {
        let v100_12_tail = v100_12_cursor.fork_read_zipper();
        let v100_12_head = Path::from_slice(&[v100_12_byte]);
        let v101_2: Space = singleton(&(v100_12_head));
        let v101_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v101_2));
        let v101_4: Space = if map_kernels::has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
        drop(v101_3);
        let v101_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v101_4));
        drop(v101_4);
        let v101_8: Space = if (v101_5).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v100_6),&(v100_12_head));
          let mut v102_7 = Space::new();
          let mut v102_7_cursor = (v100_12_tail).read_zipper();
          for v102_7_byte in v102_7_cursor.child_mask().iter() {
            v102_7_cursor.descend_to_byte(v102_7_byte);
            {
            let v102_7_tail = v102_7_cursor.fork_read_zipper();
            let v102_7_head = Path::from_slice(&[v102_7_byte]);
            let v103_2: Space = singleton(&(v102_7_head));
            let v103_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v103_2));
            let v103_4: Space = if map_kernels::has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
            drop(v103_3);
            let v103_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v103_4));
            drop(v103_4);
            let v103_8: Space = if (v103_5).is_empty() { Space::new() } else {
              let v104_6: Path = concat_path(&(v102_6),&(v102_7_head));
              let v104_7: Space = routine_15(c, &(v104_6), &(*p1), &(v102_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v103_5),&(v104_7))
            };
            drop(v103_5);
            let v103_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v103_2));
            drop(v103_2);
            let v103_10: Space = if map_kernels::has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
            drop(v103_9);
            let v103_12: Space = if (v103_10).is_empty() { Space::new() } else {
              let v105_6: Path = concat_path(&(v102_6),&(v102_7_head));
              let v105_11: Space = routine_16(c, &(v105_6), &(*p1), &(v102_7_tail).make_space(), &(*s1));
              drop(v105_6);
              map_map_kernels::compose(&(v103_10),&(v105_11))
            };
            drop(v103_10);
            let v103_13: Space = map_map_kernels::unite(&(v103_8),&(v103_12));
            v102_7.join_into((v103_13).clone());
            }
            v102_7_cursor.ascend(1);
          }
          drop(v102_7_cursor);
          drop(v102_6);
          map_map_kernels::compose(&(v101_5),&(v102_7))
        };
        drop(v101_5);
        let v101_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v101_2));
        drop(v101_2);
        let v101_10: Space = if map_kernels::has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
        drop(v101_9);
        let v101_13: Space = if (v101_10).is_empty() { Space::new() } else {
          let v106_11: Space = map_kernels::unwrap(&(v100_11),&(v100_12_head));
          let mut v106_12 = Space::new();
          let mut v106_12_cursor = (v106_11).read_zipper();
          for v106_12_byte in v106_12_cursor.child_mask().iter() {
            v106_12_cursor.descend_to_byte(v106_12_byte);
            {
            let v106_12_tail = v106_12_cursor.fork_read_zipper();
            let v106_12_head = Path::from_slice(&[v106_12_byte]);
            let v107_2: Space = singleton(&(v106_12_head));
            let v107_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v107_2));
            let v107_4: Space = if map_kernels::has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
            drop(v107_3);
            let v107_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v107_4));
            drop(v107_4);
            let v107_7: Space = if (v107_5).is_empty() { Space::new() } else {
              let v108_6: Space = routine_13(c, &(v106_12_head), &(*p1), &(v106_12_tail).make_space());
              map_map_kernels::compose(&(v107_5),&(v108_6))
            };
            drop(v107_5);
            let v107_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v107_2));
            drop(v107_2);
            let v107_9: Space = if map_kernels::has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
            drop(v107_8);
            let v107_11: Space = if (v107_9).is_empty() { Space::new() } else {
              let v109_10: Space = routine_14(c, &(v106_12_head), &(*p1), &(v106_12_tail).make_space());
              map_map_kernels::compose(&(v107_9),&(v109_10))
            };
            drop(v107_9);
            let v107_12: Space = map_map_kernels::unite(&(v107_7),&(v107_11));
            v106_12.join_into((v107_12).clone());
            }
            v106_12_cursor.ascend(1);
          }
          drop(v106_12_cursor);
          drop(v106_11);
          map_map_kernels::compose(&(v101_10),&(v106_12))
        };
        drop(v101_10);
        let v101_14: Space = map_map_kernels::unite(&(v101_8),&(v101_13));
        v100_12.join_into((v101_14).clone());
        }
        v100_12_cursor.ascend(1);
      }
      drop(v100_12_cursor);
      drop(v100_6);
      drop(v100_11);
      map_map_kernels::compose(&(v89_10),&(v100_12))
    };
    drop(v89_10);
    let v89_14: Space = map_map_kernels::unite(&(v89_8),&(v89_13));
    v88_28.join_into((v89_14).clone());
    }
    v88_28_cursor.ascend(1);
  }
  drop(v88_28_cursor);
  drop(v88_21);
  (v88_28).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v110_8: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v110_9: Space = map_kernels::unwrap(&(v110_8),&(*p0));
  drop(v110_8);
  let mut v110_28 = Space::new();
  let mut v110_28_cursor = (*s0).read_zipper();
  for v110_28_byte in v110_28_cursor.child_mask().iter() {
    v110_28_cursor.descend_to_byte(v110_28_byte);
    {
    let v110_28_tail = v110_28_cursor.fork_read_zipper();
    let v110_28_head = Path::from_slice(&[v110_28_byte]);
    let v111_2: Space = singleton(&(v110_28_head));
    let v111_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v111_2));
    let v111_4: Space = if map_kernels::has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (v111_5).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&(v110_28_head));
      let mut v112_7 = Space::new();
      let mut v112_7_cursor = (v110_28_tail).read_zipper();
      for v112_7_byte in v112_7_cursor.child_mask().iter() {
        v112_7_cursor.descend_to_byte(v112_7_byte);
        {
        let v112_7_tail = v112_7_cursor.fork_read_zipper();
        let v112_7_head = Path::from_slice(&[v112_7_byte]);
        let v113_2: Space = singleton(&(v112_7_head));
        let v113_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v113_2));
        let v113_4: Space = if map_kernels::has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let mut v114_7 = Space::new();
          let mut v114_7_cursor = (v112_7_tail).read_zipper();
          for v114_7_byte in v114_7_cursor.child_mask().iter() {
            v114_7_cursor.descend_to_byte(v114_7_byte);
            {
            let v114_7_tail = v114_7_cursor.fork_read_zipper();
            let v114_7_head = Path::from_slice(&[v114_7_byte]);
            let v115_2: Space = singleton(&(v114_7_head));
            let v115_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v115_2));
            let v115_4: Space = if map_kernels::has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v115_4));
            drop(v115_4);
            let v115_8: Space = if (v115_5).is_empty() { Space::new() } else {
              let v116_6: Path = concat_path(&(v114_6),&(v114_7_head));
              let v116_7: Space = routine_15(c, &(v116_6), &(*p1), &(v114_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v115_5),&(v116_7))
            };
            drop(v115_5);
            let v115_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v115_2));
            drop(v115_2);
            let v115_10: Space = if map_kernels::has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
            drop(v115_9);
            let v115_12: Space = if (v115_10).is_empty() { Space::new() } else {
              let v117_6: Path = concat_path(&(v114_6),&(v114_7_head));
              let v117_11: Space = routine_16(c, &(v117_6), &(*p1), &(v114_7_tail).make_space(), &(*s1));
              drop(v117_6);
              map_map_kernels::compose(&(v115_10),&(v117_11))
            };
            drop(v115_10);
            let v115_13: Space = map_map_kernels::unite(&(v115_8),&(v115_12));
            v114_7.join_into((v115_13).clone());
            }
            v114_7_cursor.ascend(1);
          }
          drop(v114_7_cursor);
          map_map_kernels::compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if map_kernels::has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (v113_10).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let mut v118_11 = Space::new();
          let mut v118_11_cursor = (v112_7_tail).read_zipper();
          for v118_11_byte in v118_11_cursor.child_mask().iter() {
            v118_11_cursor.descend_to_byte(v118_11_byte);
            {
            let v118_11_tail = v118_11_cursor.fork_read_zipper();
            let v118_11_head = Path::from_slice(&[v118_11_byte]);
            let v119_2: Space = singleton(&(v118_11_head));
            let v119_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v119_2));
            let v119_4: Space = if map_kernels::has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
            drop(v119_3);
            let v119_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v119_4));
            drop(v119_4);
            let v119_8: Space = if (v119_5).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v118_6),&(v118_11_head));
              let v120_7: Space = routine_15(c, &(v120_6), &(*p1), &(v118_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v119_5),&(v120_7))
            };
            drop(v119_5);
            let v119_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v119_2));
            drop(v119_2);
            let v119_10: Space = if map_kernels::has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
            drop(v119_9);
            let v119_12: Space = if (v119_10).is_empty() { Space::new() } else {
              let v121_6: Path = concat_path(&(v118_6),&(v118_11_head));
              let v121_11: Space = routine_10(c, &(v121_6), &(*p1), &(v118_11_tail).make_space(), &(*s1));
              drop(v121_6);
              map_map_kernels::compose(&(v119_10),&(v121_11))
            };
            drop(v119_10);
            let v119_13: Space = map_map_kernels::unite(&(v119_8),&(v119_12));
            v118_11.join_into((v119_13).clone());
            }
            v118_11_cursor.ascend(1);
          }
          drop(v118_11_cursor);
          drop(v118_6);
          map_map_kernels::compose(&(v113_10),&(v118_11))
        };
        drop(v113_10);
        let v113_13: Space = map_map_kernels::unite(&(v113_8),&(v113_12));
        v112_7.join_into((v113_13).clone());
        }
        v112_7_cursor.ascend(1);
      }
      drop(v112_7_cursor);
      drop(v112_6);
      map_map_kernels::compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if map_kernels::has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_13: Space = if (v111_10).is_empty() { Space::new() } else {
      let v122_11: Space = map_kernels::unwrap(&(v110_9),&(v110_28_head));
      let mut v122_12 = Space::new();
      let mut v122_12_cursor = (v122_11).read_zipper();
      for v122_12_byte in v122_12_cursor.child_mask().iter() {
        v122_12_cursor.descend_to_byte(v122_12_byte);
        {
        let v122_12_tail = v122_12_cursor.fork_read_zipper();
        let v122_12_head = Path::from_slice(&[v122_12_byte]);
        let v123_2: Space = singleton(&(v122_12_head));
        let v123_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if map_kernels::has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (v123_5).is_empty() { Space::new() } else {
          let mut v124_6 = Space::new();
          let mut v124_6_cursor = (v122_12_tail).read_zipper();
          for v124_6_byte in v124_6_cursor.child_mask().iter() {
            v124_6_cursor.descend_to_byte(v124_6_byte);
            {
            let v124_6_tail = v124_6_cursor.fork_read_zipper();
            let v124_6_head = Path::from_slice(&[v124_6_byte]);
            let v125_2: Space = singleton(&(v124_6_head));
            let v125_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v125_2));
            let v125_4: Space = if map_kernels::has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v125_4));
            drop(v125_4);
            let v125_8: Space = if (v125_5).is_empty() { Space::new() } else {
              let v126_6: Path = concat_path(&(v122_12_head),&(v124_6_head));
              let v126_7: Space = routine_17(c, &(v126_6), &(*p1), &(v124_6_tail).make_space());
              map_map_kernels::compose(&(v125_5),&(v126_7))
            };
            drop(v125_5);
            let v125_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v125_2));
            drop(v125_2);
            let v125_10: Space = if map_kernels::has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
            drop(v125_9);
            let v125_12: Space = if (v125_10).is_empty() { Space::new() } else {
              let v127_6: Path = concat_path(&(v122_12_head),&(v124_6_head));
              let v127_11: Space = routine_18(c, &(v127_6), &(*p1), &(v124_6_tail).make_space());
              drop(v127_6);
              map_map_kernels::compose(&(v125_10),&(v127_11))
            };
            drop(v125_10);
            let v125_13: Space = map_map_kernels::unite(&(v125_8),&(v125_12));
            v124_6.join_into((v125_13).clone());
            }
            v124_6_cursor.ascend(1);
          }
          drop(v124_6_cursor);
          map_map_kernels::compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if map_kernels::has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (v123_9).is_empty() { Space::new() } else {
          let mut v128_10 = Space::new();
          let mut v128_10_cursor = (v122_12_tail).read_zipper();
          for v128_10_byte in v128_10_cursor.child_mask().iter() {
            v128_10_cursor.descend_to_byte(v128_10_byte);
            {
            let v128_10_tail = v128_10_cursor.fork_read_zipper();
            let v128_10_head = Path::from_slice(&[v128_10_byte]);
            let v129_2: Space = singleton(&(v128_10_head));
            let v129_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v129_2));
            let v129_4: Space = if map_kernels::has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
            drop(v129_3);
            let v129_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v129_4));
            drop(v129_4);
            let v129_8: Space = if (v129_5).is_empty() { Space::new() } else {
              let v130_6: Path = concat_path(&(v122_12_head),&(v128_10_head));
              let v130_7: Space = routine_17(c, &(v130_6), &(*p1), &(v128_10_tail).make_space());
              map_map_kernels::compose(&(v129_5),&(v130_7))
            };
            drop(v129_5);
            let v129_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v129_2));
            drop(v129_2);
            let v129_10: Space = if map_kernels::has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
            drop(v129_9);
            let v129_12: Space = if (v129_10).is_empty() { Space::new() } else {
              let v131_6: Path = concat_path(&(v122_12_head),&(v128_10_head));
              let v131_11: Space = routine_19(c, &(v131_6), &(*p1), &(v128_10_tail).make_space());
              drop(v131_6);
              map_map_kernels::compose(&(v129_10),&(v131_11))
            };
            drop(v129_10);
            let v129_13: Space = map_map_kernels::unite(&(v129_8),&(v129_12));
            v128_10.join_into((v129_13).clone());
            }
            v128_10_cursor.ascend(1);
          }
          drop(v128_10_cursor);
          map_map_kernels::compose(&(v123_9),&(v128_10))
        };
        drop(v123_9);
        let v123_12: Space = map_map_kernels::unite(&(v123_7),&(v123_11));
        v122_12.join_into((v123_12).clone());
        }
        v122_12_cursor.ascend(1);
      }
      drop(v122_12_cursor);
      drop(v122_11);
      map_map_kernels::compose(&(v111_10),&(v122_12))
    };
    drop(v111_10);
    let v111_14: Space = map_map_kernels::unite(&(v111_8),&(v111_13));
    v110_28.join_into((v111_14).clone());
    }
    v110_28_cursor.ascend(1);
  }
  drop(v110_28_cursor);
  drop(v110_9);
  (v110_28).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v132_24 = Space::new();
  let mut v132_24_cursor = (*s0).read_zipper();
  for v132_24_byte in v132_24_cursor.child_mask().iter() {
    v132_24_cursor.descend_to_byte(v132_24_byte);
    {
    let v132_24_tail = v132_24_cursor.fork_read_zipper();
    let v132_24_head = Path::from_slice(&[v132_24_byte]);
    let v133_2: Space = singleton(&(v132_24_head));
    let v133_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v133_2));
    let v133_4: Space = if map_kernels::has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
    drop(v133_3);
    let v133_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v133_4));
    drop(v133_4);
    let v133_8: Space = if (v133_5).is_empty() { Space::new() } else {
      let v134_6: Path = concat_path(&(*p0),&(v132_24_head));
      let mut v134_7 = Space::new();
      let mut v134_7_cursor = (v132_24_tail).read_zipper();
      for v134_7_byte in v134_7_cursor.child_mask().iter() {
        v134_7_cursor.descend_to_byte(v134_7_byte);
        {
        let v134_7_tail = v134_7_cursor.fork_read_zipper();
        let v134_7_head = Path::from_slice(&[v134_7_byte]);
        let v135_2: Space = singleton(&(v134_7_head));
        let v135_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v135_2));
        let v135_4: Space = if map_kernels::has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
        drop(v135_3);
        let v135_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v135_4));
        drop(v135_4);
        let v135_8: Space = if (v135_5).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v134_6),&(v134_7_head));
          let mut v136_7 = Space::new();
          let mut v136_7_cursor = (v134_7_tail).read_zipper();
          for v136_7_byte in v136_7_cursor.child_mask().iter() {
            v136_7_cursor.descend_to_byte(v136_7_byte);
            {
            let v136_7_tail = v136_7_cursor.fork_read_zipper();
            let v136_7_head = Path::from_slice(&[v136_7_byte]);
            let v137_2: Space = singleton(&(v136_7_head));
            let v137_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v137_2));
            let v137_4: Space = if map_kernels::has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
            drop(v137_3);
            let v137_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v137_4));
            drop(v137_4);
            let v137_8: Space = if (v137_5).is_empty() { Space::new() } else {
              let v138_6: Path = concat_path(&(v136_6),&(v136_7_head));
              let v138_7: Space = routine_20(c, &(v138_6), &(v136_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v137_5),&(v138_7))
            };
            drop(v137_5);
            let v137_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v137_2));
            drop(v137_2);
            let v137_10: Space = if map_kernels::has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
            drop(v137_9);
            let v137_12: Space = if (v137_10).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v136_6),&(v136_7_head));
              let v139_11: Space = routine_21(c, &(v139_6), &(v136_7_tail).make_space(), &(*s1));
              drop(v139_6);
              map_map_kernels::compose(&(v137_10),&(v139_11))
            };
            drop(v137_10);
            let v137_13: Space = map_map_kernels::unite(&(v137_8),&(v137_12));
            v136_7.join_into((v137_13).clone());
            }
            v136_7_cursor.ascend(1);
          }
          drop(v136_7_cursor);
          map_map_kernels::compose(&(v135_5),&(v136_7))
        };
        drop(v135_5);
        let v135_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v135_2));
        drop(v135_2);
        let v135_10: Space = if map_kernels::has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
        drop(v135_9);
        let v135_12: Space = if (v135_10).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v134_6),&(v134_7_head));
          let mut v140_11 = Space::new();
          let mut v140_11_cursor = (v134_7_tail).read_zipper();
          for v140_11_byte in v140_11_cursor.child_mask().iter() {
            v140_11_cursor.descend_to_byte(v140_11_byte);
            {
            let v140_11_tail = v140_11_cursor.fork_read_zipper();
            let v140_11_head = Path::from_slice(&[v140_11_byte]);
            let v141_2: Space = singleton(&(v140_11_head));
            let v141_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v141_2));
            let v141_4: Space = if map_kernels::has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
            drop(v141_3);
            let v141_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v141_4));
            drop(v141_4);
            let v141_8: Space = if (v141_5).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v140_6),&(v140_11_head));
              let v142_7: Space = routine_20(c, &(v142_6), &(v140_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v141_5),&(v142_7))
            };
            drop(v141_5);
            let v141_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v141_2));
            drop(v141_2);
            let v141_10: Space = if map_kernels::has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
            drop(v141_9);
            let v141_12: Space = if (v141_10).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v140_6),&(v140_11_head));
              let v143_11: Space = routine_3(c, &(v143_6), &(v140_11_tail).make_space(), &(*s1));
              drop(v143_6);
              map_map_kernels::compose(&(v141_10),&(v143_11))
            };
            drop(v141_10);
            let v141_13: Space = map_map_kernels::unite(&(v141_8),&(v141_12));
            v140_11.join_into((v141_13).clone());
            }
            v140_11_cursor.ascend(1);
          }
          drop(v140_11_cursor);
          drop(v140_6);
          map_map_kernels::compose(&(v135_10),&(v140_11))
        };
        drop(v135_10);
        let v135_13: Space = map_map_kernels::unite(&(v135_8),&(v135_12));
        v134_7.join_into((v135_13).clone());
        }
        v134_7_cursor.ascend(1);
      }
      drop(v134_7_cursor);
      map_map_kernels::compose(&(v133_5),&(v134_7))
    };
    drop(v133_5);
    let v133_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v133_2));
    drop(v133_2);
    let v133_10: Space = if map_kernels::has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
    drop(v133_9);
    let v133_12: Space = if (v133_10).is_empty() { Space::new() } else {
      let v144_6: Path = concat_path(&(*p0),&(v132_24_head));
      let mut v144_11 = Space::new();
      let mut v144_11_cursor = (v132_24_tail).read_zipper();
      for v144_11_byte in v144_11_cursor.child_mask().iter() {
        v144_11_cursor.descend_to_byte(v144_11_byte);
        {
        let v144_11_tail = v144_11_cursor.fork_read_zipper();
        let v144_11_head = Path::from_slice(&[v144_11_byte]);
        let v145_2: Space = singleton(&(v144_11_head));
        let v145_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v145_2));
        let v145_4: Space = if map_kernels::has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v145_4));
        drop(v145_4);
        let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v144_6),&(v144_11_head));
          let mut v146_7 = Space::new();
          let mut v146_7_cursor = (v144_11_tail).read_zipper();
          for v146_7_byte in v146_7_cursor.child_mask().iter() {
            v146_7_cursor.descend_to_byte(v146_7_byte);
            {
            let v146_7_tail = v146_7_cursor.fork_read_zipper();
            let v146_7_head = Path::from_slice(&[v146_7_byte]);
            let v147_2: Space = singleton(&(v146_7_head));
            let v147_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v147_2));
            let v147_4: Space = if map_kernels::has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
            drop(v147_3);
            let v147_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v147_4));
            drop(v147_4);
            let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
              let v148_6: Path = concat_path(&(v146_6),&(v146_7_head));
              let v148_7: Space = routine_20(c, &(v148_6), &(v146_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v147_5),&(v148_7))
            };
            drop(v147_5);
            let v147_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v147_2));
            drop(v147_2);
            let v147_10: Space = if map_kernels::has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
            drop(v147_9);
            let v147_12: Space = if (v147_10).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v146_6),&(v146_7_head));
              let v149_11: Space = routine_21(c, &(v149_6), &(v146_7_tail).make_space(), &(*s1));
              drop(v149_6);
              map_map_kernels::compose(&(v147_10),&(v149_11))
            };
            drop(v147_10);
            let v147_13: Space = map_map_kernels::unite(&(v147_8),&(v147_12));
            v146_7.join_into((v147_13).clone());
            }
            v146_7_cursor.ascend(1);
          }
          drop(v146_7_cursor);
          map_map_kernels::compose(&(v145_5),&(v146_7))
        };
        drop(v145_5);
        let v145_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v145_2));
        drop(v145_2);
        let v145_10: Space = if map_kernels::has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
        drop(v145_9);
        let v145_12: Space = if (v145_10).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v144_6),&(v144_11_head));
          let mut v150_11 = Space::new();
          let mut v150_11_cursor = (v144_11_tail).read_zipper();
          for v150_11_byte in v150_11_cursor.child_mask().iter() {
            v150_11_cursor.descend_to_byte(v150_11_byte);
            {
            let v150_11_tail = v150_11_cursor.fork_read_zipper();
            let v150_11_head = Path::from_slice(&[v150_11_byte]);
            let v151_2: Space = singleton(&(v150_11_head));
            let v151_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v151_2));
            let v151_4: Space = if map_kernels::has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
            drop(v151_3);
            let v151_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v151_4));
            drop(v151_4);
            let v151_7: Space = if (v151_5).is_empty() { Space::new() } else {
              let v152_6: Space = routine_4(c, &(v150_11_head), &(v150_6), &(v150_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v151_5),&(v152_6))
            };
            drop(v151_5);
            let v151_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v151_2));
            drop(v151_2);
            let v151_9: Space = if map_kernels::has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
            drop(v151_8);
            let v151_11: Space = if (v151_9).is_empty() { Space::new() } else {
              let v153_10: Space = routine_5(c, &(v150_11_head), &(v150_6), &(v150_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v151_9),&(v153_10))
            };
            drop(v151_9);
            let v151_12: Space = map_map_kernels::unite(&(v151_7),&(v151_11));
            v150_11.join_into((v151_12).clone());
            }
            v150_11_cursor.ascend(1);
          }
          drop(v150_11_cursor);
          drop(v150_6);
          map_map_kernels::compose(&(v145_10),&(v150_11))
        };
        drop(v145_10);
        let v145_13: Space = map_map_kernels::unite(&(v145_8),&(v145_12));
        v144_11.join_into((v145_13).clone());
        }
        v144_11_cursor.ascend(1);
      }
      drop(v144_11_cursor);
      drop(v144_6);
      map_map_kernels::compose(&(v133_10),&(v144_11))
    };
    drop(v133_10);
    let v133_13: Space = map_map_kernels::unite(&(v133_8),&(v133_12));
    v132_24.join_into((v133_13).clone());
    }
    v132_24_cursor.ascend(1);
  }
  drop(v132_24_cursor);
  (v132_24).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v154_24 = Space::new();
  let mut v154_24_cursor = (*s0).read_zipper();
  for v154_24_byte in v154_24_cursor.child_mask().iter() {
    v154_24_cursor.descend_to_byte(v154_24_byte);
    {
    let v154_24_tail = v154_24_cursor.fork_read_zipper();
    let v154_24_head = Path::from_slice(&[v154_24_byte]);
    let v155_2: Space = singleton(&(v154_24_head));
    let v155_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v155_2));
    let v155_4: Space = if map_kernels::has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v155_4));
    drop(v155_4);
    let v155_8: Space = if (v155_5).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&(v154_24_head));
      let mut v156_7 = Space::new();
      let mut v156_7_cursor = (v154_24_tail).read_zipper();
      for v156_7_byte in v156_7_cursor.child_mask().iter() {
        v156_7_cursor.descend_to_byte(v156_7_byte);
        {
        let v156_7_tail = v156_7_cursor.fork_read_zipper();
        let v156_7_head = Path::from_slice(&[v156_7_byte]);
        let v157_2: Space = singleton(&(v156_7_head));
        let v157_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v157_2));
        let v157_4: Space = if map_kernels::has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let mut v158_7 = Space::new();
          let mut v158_7_cursor = (v156_7_tail).read_zipper();
          for v158_7_byte in v158_7_cursor.child_mask().iter() {
            v158_7_cursor.descend_to_byte(v158_7_byte);
            {
            let v158_7_tail = v158_7_cursor.fork_read_zipper();
            let v158_7_head = Path::from_slice(&[v158_7_byte]);
            let v159_2: Space = singleton(&(v158_7_head));
            let v159_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v159_2));
            let v159_4: Space = if map_kernels::has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
            drop(v159_3);
            let v159_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v159_4));
            drop(v159_4);
            let v159_8: Space = if (v159_5).is_empty() { Space::new() } else {
              let v160_6: Path = concat_path(&(v158_6),&(v158_7_head));
              let v160_7: Space = routine_20(c, &(v160_6), &(v158_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v159_5),&(v160_7))
            };
            drop(v159_5);
            let v159_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v159_2));
            drop(v159_2);
            let v159_10: Space = if map_kernels::has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
            drop(v159_9);
            let v159_12: Space = if (v159_10).is_empty() { Space::new() } else {
              let v161_6: Path = concat_path(&(v158_6),&(v158_7_head));
              let v161_11: Space = routine_21(c, &(v161_6), &(v158_7_tail).make_space(), &(*s1));
              drop(v161_6);
              map_map_kernels::compose(&(v159_10),&(v161_11))
            };
            drop(v159_10);
            let v159_13: Space = map_map_kernels::unite(&(v159_8),&(v159_12));
            v158_7.join_into((v159_13).clone());
            }
            v158_7_cursor.ascend(1);
          }
          drop(v158_7_cursor);
          map_map_kernels::compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if map_kernels::has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let mut v162_11 = Space::new();
          let mut v162_11_cursor = (v156_7_tail).read_zipper();
          for v162_11_byte in v162_11_cursor.child_mask().iter() {
            v162_11_cursor.descend_to_byte(v162_11_byte);
            {
            let v162_11_tail = v162_11_cursor.fork_read_zipper();
            let v162_11_head = Path::from_slice(&[v162_11_byte]);
            let v163_2: Space = singleton(&(v162_11_head));
            let v163_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v163_2));
            let v163_4: Space = if map_kernels::has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
            drop(v163_3);
            let v163_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v163_4));
            drop(v163_4);
            let v163_8: Space = if (v163_5).is_empty() { Space::new() } else {
              let v164_6: Path = concat_path(&(v162_6),&(v162_11_head));
              let v164_7: Space = routine_20(c, &(v164_6), &(v162_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v163_5),&(v164_7))
            };
            drop(v163_5);
            let v163_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v163_2));
            drop(v163_2);
            let v163_10: Space = if map_kernels::has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
            drop(v163_9);
            let v163_12: Space = if (v163_10).is_empty() { Space::new() } else {
              let v165_6: Path = concat_path(&(v162_6),&(v162_11_head));
              let v165_11: Space = routine_3(c, &(v165_6), &(v162_11_tail).make_space(), &(*s1));
              drop(v165_6);
              map_map_kernels::compose(&(v163_10),&(v165_11))
            };
            drop(v163_10);
            let v163_13: Space = map_map_kernels::unite(&(v163_8),&(v163_12));
            v162_11.join_into((v163_13).clone());
            }
            v162_11_cursor.ascend(1);
          }
          drop(v162_11_cursor);
          drop(v162_6);
          map_map_kernels::compose(&(v157_10),&(v162_11))
        };
        drop(v157_10);
        let v157_13: Space = map_map_kernels::unite(&(v157_8),&(v157_12));
        v156_7.join_into((v157_13).clone());
        }
        v156_7_cursor.ascend(1);
      }
      drop(v156_7_cursor);
      map_map_kernels::compose(&(v155_5),&(v156_7))
    };
    drop(v155_5);
    let v155_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v155_2));
    drop(v155_2);
    let v155_10: Space = if map_kernels::has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
    drop(v155_9);
    let v155_12: Space = if (v155_10).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&(v154_24_head));
      let mut v166_11 = Space::new();
      let mut v166_11_cursor = (v154_24_tail).read_zipper();
      for v166_11_byte in v166_11_cursor.child_mask().iter() {
        v166_11_cursor.descend_to_byte(v166_11_byte);
        {
        let v166_11_tail = v166_11_cursor.fork_read_zipper();
        let v166_11_head = Path::from_slice(&[v166_11_byte]);
        let v167_2: Space = singleton(&(v166_11_head));
        let v167_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v167_2));
        let v167_4: Space = if map_kernels::has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v167_4));
        drop(v167_4);
        let v167_7: Space = if (v167_5).is_empty() { Space::new() } else {
          let mut v168_6 = Space::new();
          let mut v168_6_cursor = (v166_11_tail).read_zipper();
          for v168_6_byte in v168_6_cursor.child_mask().iter() {
            v168_6_cursor.descend_to_byte(v168_6_byte);
            {
            let v168_6_tail = v168_6_cursor.fork_read_zipper();
            let v168_6_head = Path::from_slice(&[v168_6_byte]);
            let v169_2: Space = singleton(&(v168_6_head));
            let v169_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v169_2));
            let v169_4: Space = if map_kernels::has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (v169_5).is_empty() { Space::new() } else {
              let v170_6: Path = concat_path(&(v166_11_head),&(v168_6_head));
              let v170_7: Space = routine_8(c, &(v170_6), &(v166_6), &(v168_6_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if map_kernels::has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (v169_10).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v166_11_head),&(v168_6_head));
              let v171_11: Space = routine_9(c, &(v171_6), &(v166_6), &(v168_6_tail).make_space(), &(*s1));
              drop(v171_6);
              map_map_kernels::compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = map_map_kernels::unite(&(v169_8),&(v169_12));
            v168_6.join_into((v169_13).clone());
            }
            v168_6_cursor.ascend(1);
          }
          drop(v168_6_cursor);
          map_map_kernels::compose(&(v167_5),&(v168_6))
        };
        drop(v167_5);
        let v167_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v167_2));
        drop(v167_2);
        let v167_9: Space = if map_kernels::has_head(&(v167_8)) { singleton(&[]) } else { Space::new() };
        drop(v167_8);
        let v167_11: Space = if (v167_9).is_empty() { Space::new() } else {
          let mut v172_10 = Space::new();
          let mut v172_10_cursor = (v166_11_tail).read_zipper();
          for v172_10_byte in v172_10_cursor.child_mask().iter() {
            v172_10_cursor.descend_to_byte(v172_10_byte);
            {
            let v172_10_tail = v172_10_cursor.fork_read_zipper();
            let v172_10_head = Path::from_slice(&[v172_10_byte]);
            let v173_2: Space = singleton(&(v172_10_head));
            let v173_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v173_2));
            let v173_4: Space = if map_kernels::has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
            drop(v173_3);
            let v173_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v173_4));
            drop(v173_4);
            let v173_8: Space = if (v173_5).is_empty() { Space::new() } else {
              let v174_6: Path = concat_path(&(v166_11_head),&(v172_10_head));
              let v174_7: Space = routine_8(c, &(v174_6), &(v166_6), &(v172_10_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v173_5),&(v174_7))
            };
            drop(v173_5);
            let v173_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v173_2));
            drop(v173_2);
            let v173_10: Space = if map_kernels::has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
            drop(v173_9);
            let v173_12: Space = if (v173_10).is_empty() { Space::new() } else {
              let v175_6: Path = concat_path(&(v166_11_head),&(v172_10_head));
              let v175_11: Space = routine_10(c, &(v175_6), &(v166_6), &(v172_10_tail).make_space(), &(*s1));
              drop(v175_6);
              map_map_kernels::compose(&(v173_10),&(v175_11))
            };
            drop(v173_10);
            let v173_13: Space = map_map_kernels::unite(&(v173_8),&(v173_12));
            v172_10.join_into((v173_13).clone());
            }
            v172_10_cursor.ascend(1);
          }
          drop(v172_10_cursor);
          map_map_kernels::compose(&(v167_9),&(v172_10))
        };
        drop(v167_9);
        let v167_12: Space = map_map_kernels::unite(&(v167_7),&(v167_11));
        v166_11.join_into((v167_12).clone());
        }
        v166_11_cursor.ascend(1);
      }
      drop(v166_11_cursor);
      drop(v166_6);
      map_map_kernels::compose(&(v155_10),&(v166_11))
    };
    drop(v155_10);
    let v155_13: Space = map_map_kernels::unite(&(v155_8),&(v155_12));
    v154_24.join_into((v155_13).clone());
    }
    v154_24_cursor.ascend(1);
  }
  drop(v154_24_cursor);
  (v154_24).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v176_20: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v176_21: Space = map_kernels::unwrap(&(v176_20),&(*p0));
  drop(v176_20);
  let mut v176_28 = Space::new();
  let mut v176_28_cursor = (*s0).read_zipper();
  for v176_28_byte in v176_28_cursor.child_mask().iter() {
    v176_28_cursor.descend_to_byte(v176_28_byte);
    {
    let v176_28_tail = v176_28_cursor.fork_read_zipper();
    let v176_28_head = Path::from_slice(&[v176_28_byte]);
    let v177_2: Space = singleton(&(v176_28_head));
    let v177_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v177_2));
    let v177_4: Space = if map_kernels::has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
    drop(v177_3);
    let v177_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v177_4));
    drop(v177_4);
    let v177_8: Space = if (v177_5).is_empty() { Space::new() } else {
      let v178_6: Path = concat_path(&(*p0),&(v176_28_head));
      let mut v178_7 = Space::new();
      let mut v178_7_cursor = (v176_28_tail).read_zipper();
      for v178_7_byte in v178_7_cursor.child_mask().iter() {
        v178_7_cursor.descend_to_byte(v178_7_byte);
        {
        let v178_7_tail = v178_7_cursor.fork_read_zipper();
        let v178_7_head = Path::from_slice(&[v178_7_byte]);
        let v179_2: Space = singleton(&(v178_7_head));
        let v179_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v179_2));
        let v179_4: Space = if map_kernels::has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
        drop(v179_3);
        let v179_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v179_4));
        drop(v179_4);
        let v179_8: Space = if (v179_5).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v178_6),&(v178_7_head));
          let mut v180_7 = Space::new();
          let mut v180_7_cursor = (v178_7_tail).read_zipper();
          for v180_7_byte in v180_7_cursor.child_mask().iter() {
            v180_7_cursor.descend_to_byte(v180_7_byte);
            {
            let v180_7_tail = v180_7_cursor.fork_read_zipper();
            let v180_7_head = Path::from_slice(&[v180_7_byte]);
            let v181_2: Space = singleton(&(v180_7_head));
            let v181_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v181_2));
            let v181_4: Space = if map_kernels::has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
            drop(v181_3);
            let v181_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v181_4));
            drop(v181_4);
            let v181_8: Space = if (v181_5).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v180_6),&(v180_7_head));
              let v182_7: Space = routine_22(c, &(v182_6), &(*p1), &(v180_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v181_5),&(v182_7))
            };
            drop(v181_5);
            let v181_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v181_2));
            drop(v181_2);
            let v181_10: Space = if map_kernels::has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
            drop(v181_9);
            let v181_12: Space = if (v181_10).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v180_6),&(v180_7_head));
              let v183_11: Space = routine_23(c, &(v183_6), &(*p1), &(v180_7_tail).make_space(), &(*s1));
              drop(v183_6);
              map_map_kernels::compose(&(v181_10),&(v183_11))
            };
            drop(v181_10);
            let v181_13: Space = map_map_kernels::unite(&(v181_8),&(v181_12));
            v180_7.join_into((v181_13).clone());
            }
            v180_7_cursor.ascend(1);
          }
          drop(v180_7_cursor);
          map_map_kernels::compose(&(v179_5),&(v180_7))
        };
        drop(v179_5);
        let v179_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v179_2));
        drop(v179_2);
        let v179_10: Space = if map_kernels::has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
        drop(v179_9);
        let v179_12: Space = if (v179_10).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v178_6),&(v178_7_head));
          let mut v184_11 = Space::new();
          let mut v184_11_cursor = (v178_7_tail).read_zipper();
          for v184_11_byte in v184_11_cursor.child_mask().iter() {
            v184_11_cursor.descend_to_byte(v184_11_byte);
            {
            let v184_11_tail = v184_11_cursor.fork_read_zipper();
            let v184_11_head = Path::from_slice(&[v184_11_byte]);
            let v185_2: Space = singleton(&(v184_11_head));
            let v185_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v185_2));
            let v185_4: Space = if map_kernels::has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
            drop(v185_3);
            let v185_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v185_4));
            drop(v185_4);
            let v185_8: Space = if (v185_5).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v184_6),&(v184_11_head));
              let v186_7: Space = routine_22(c, &(v186_6), &(*p1), &(v184_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v185_5),&(v186_7))
            };
            drop(v185_5);
            let v185_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v185_2));
            drop(v185_2);
            let v185_10: Space = if map_kernels::has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
            drop(v185_9);
            let v185_12: Space = if (v185_10).is_empty() { Space::new() } else {
              let v187_6: Path = concat_path(&(v184_6),&(v184_11_head));
              let v187_11: Space = routine_10(c, &(v187_6), &(*p1), &(v184_11_tail).make_space(), &(*s1));
              drop(v187_6);
              map_map_kernels::compose(&(v185_10),&(v187_11))
            };
            drop(v185_10);
            let v185_13: Space = map_map_kernels::unite(&(v185_8),&(v185_12));
            v184_11.join_into((v185_13).clone());
            }
            v184_11_cursor.ascend(1);
          }
          drop(v184_11_cursor);
          drop(v184_6);
          map_map_kernels::compose(&(v179_10),&(v184_11))
        };
        drop(v179_10);
        let v179_13: Space = map_map_kernels::unite(&(v179_8),&(v179_12));
        v178_7.join_into((v179_13).clone());
        }
        v178_7_cursor.ascend(1);
      }
      drop(v178_7_cursor);
      map_map_kernels::compose(&(v177_5),&(v178_7))
    };
    drop(v177_5);
    let v177_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v177_2));
    drop(v177_2);
    let v177_10: Space = if map_kernels::has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
    drop(v177_9);
    let v177_13: Space = if (v177_10).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&(v176_28_head));
      let v188_11: Space = map_kernels::unwrap(&(v176_21),&(v176_28_head));
      let mut v188_12 = Space::new();
      let mut v188_12_cursor = (v176_28_tail).read_zipper();
      for v188_12_byte in v188_12_cursor.child_mask().iter() {
        v188_12_cursor.descend_to_byte(v188_12_byte);
        {
        let v188_12_tail = v188_12_cursor.fork_read_zipper();
        let v188_12_head = Path::from_slice(&[v188_12_byte]);
        let v189_2: Space = singleton(&(v188_12_head));
        let v189_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v189_2));
        let v189_4: Space = if map_kernels::has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (v189_5).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&(v188_12_head));
          let mut v190_7 = Space::new();
          let mut v190_7_cursor = (v188_12_tail).read_zipper();
          for v190_7_byte in v190_7_cursor.child_mask().iter() {
            v190_7_cursor.descend_to_byte(v190_7_byte);
            {
            let v190_7_tail = v190_7_cursor.fork_read_zipper();
            let v190_7_head = Path::from_slice(&[v190_7_byte]);
            let v191_2: Space = singleton(&(v190_7_head));
            let v191_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v191_2));
            let v191_4: Space = if map_kernels::has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (v191_5).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&(v190_7_head));
              let v192_7: Space = routine_22(c, &(v192_6), &(*p1), &(v190_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if map_kernels::has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (v191_10).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&(v190_7_head));
              let v193_11: Space = routine_23(c, &(v193_6), &(*p1), &(v190_7_tail).make_space(), &(*s1));
              drop(v193_6);
              map_map_kernels::compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = map_map_kernels::unite(&(v191_8),&(v191_12));
            v190_7.join_into((v191_13).clone());
            }
            v190_7_cursor.ascend(1);
          }
          drop(v190_7_cursor);
          drop(v190_6);
          map_map_kernels::compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if map_kernels::has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_13: Space = if (v189_10).is_empty() { Space::new() } else {
          let v194_11: Space = map_kernels::unwrap(&(v188_11),&(v188_12_head));
          let mut v194_12 = Space::new();
          let mut v194_12_cursor = (v194_11).read_zipper();
          for v194_12_byte in v194_12_cursor.child_mask().iter() {
            v194_12_cursor.descend_to_byte(v194_12_byte);
            {
            let v194_12_tail = v194_12_cursor.fork_read_zipper();
            let v194_12_head = Path::from_slice(&[v194_12_byte]);
            let v195_2: Space = singleton(&(v194_12_head));
            let v195_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v195_2));
            let v195_4: Space = if map_kernels::has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
            drop(v195_3);
            let v195_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v195_4));
            drop(v195_4);
            let v195_7: Space = if (v195_5).is_empty() { Space::new() } else {
              let v196_6: Space = routine_13(c, &(v194_12_head), &(*p1), &(v194_12_tail).make_space());
              map_map_kernels::compose(&(v195_5),&(v196_6))
            };
            drop(v195_5);
            let v195_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v195_2));
            drop(v195_2);
            let v195_9: Space = if map_kernels::has_head(&(v195_8)) { singleton(&[]) } else { Space::new() };
            drop(v195_8);
            let v195_11: Space = if (v195_9).is_empty() { Space::new() } else {
              let v197_10: Space = routine_14(c, &(v194_12_head), &(*p1), &(v194_12_tail).make_space());
              map_map_kernels::compose(&(v195_9),&(v197_10))
            };
            drop(v195_9);
            let v195_12: Space = map_map_kernels::unite(&(v195_7),&(v195_11));
            v194_12.join_into((v195_12).clone());
            }
            v194_12_cursor.ascend(1);
          }
          drop(v194_12_cursor);
          drop(v194_11);
          map_map_kernels::compose(&(v189_10),&(v194_12))
        };
        drop(v189_10);
        let v189_14: Space = map_map_kernels::unite(&(v189_8),&(v189_13));
        v188_12.join_into((v189_14).clone());
        }
        v188_12_cursor.ascend(1);
      }
      drop(v188_12_cursor);
      drop(v188_6);
      drop(v188_11);
      map_map_kernels::compose(&(v177_10),&(v188_12))
    };
    drop(v177_10);
    let v177_14: Space = map_map_kernels::unite(&(v177_8),&(v177_13));
    v176_28.join_into((v177_14).clone());
    }
    v176_28_cursor.ascend(1);
  }
  drop(v176_28_cursor);
  drop(v176_21);
  (v176_28).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v198_8: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v198_9: Space = map_kernels::unwrap(&(v198_8),&(*p0));
  drop(v198_8);
  let mut v198_28 = Space::new();
  let mut v198_28_cursor = (*s0).read_zipper();
  for v198_28_byte in v198_28_cursor.child_mask().iter() {
    v198_28_cursor.descend_to_byte(v198_28_byte);
    {
    let v198_28_tail = v198_28_cursor.fork_read_zipper();
    let v198_28_head = Path::from_slice(&[v198_28_byte]);
    let v199_2: Space = singleton(&(v198_28_head));
    let v199_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v199_2));
    let v199_4: Space = if map_kernels::has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
    drop(v199_3);
    let v199_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v199_4));
    drop(v199_4);
    let v199_8: Space = if (v199_5).is_empty() { Space::new() } else {
      let v200_6: Path = concat_path(&(*p0),&(v198_28_head));
      let mut v200_7 = Space::new();
      let mut v200_7_cursor = (v198_28_tail).read_zipper();
      for v200_7_byte in v200_7_cursor.child_mask().iter() {
        v200_7_cursor.descend_to_byte(v200_7_byte);
        {
        let v200_7_tail = v200_7_cursor.fork_read_zipper();
        let v200_7_head = Path::from_slice(&[v200_7_byte]);
        let v201_2: Space = singleton(&(v200_7_head));
        let v201_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v201_2));
        let v201_4: Space = if map_kernels::has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
        drop(v201_3);
        let v201_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v201_4));
        drop(v201_4);
        let v201_8: Space = if (v201_5).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v200_6),&(v200_7_head));
          let mut v202_7 = Space::new();
          let mut v202_7_cursor = (v200_7_tail).read_zipper();
          for v202_7_byte in v202_7_cursor.child_mask().iter() {
            v202_7_cursor.descend_to_byte(v202_7_byte);
            {
            let v202_7_tail = v202_7_cursor.fork_read_zipper();
            let v202_7_head = Path::from_slice(&[v202_7_byte]);
            let v203_2: Space = singleton(&(v202_7_head));
            let v203_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v203_2));
            let v203_4: Space = if map_kernels::has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
            drop(v203_3);
            let v203_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v203_4));
            drop(v203_4);
            let v203_8: Space = if (v203_5).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v202_6),&(v202_7_head));
              let v204_7: Space = routine_22(c, &(v204_6), &(*p1), &(v202_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v203_5),&(v204_7))
            };
            drop(v203_5);
            let v203_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v203_2));
            drop(v203_2);
            let v203_10: Space = if map_kernels::has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
            drop(v203_9);
            let v203_12: Space = if (v203_10).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v202_6),&(v202_7_head));
              let v205_11: Space = routine_23(c, &(v205_6), &(*p1), &(v202_7_tail).make_space(), &(*s1));
              drop(v205_6);
              map_map_kernels::compose(&(v203_10),&(v205_11))
            };
            drop(v203_10);
            let v203_13: Space = map_map_kernels::unite(&(v203_8),&(v203_12));
            v202_7.join_into((v203_13).clone());
            }
            v202_7_cursor.ascend(1);
          }
          drop(v202_7_cursor);
          map_map_kernels::compose(&(v201_5),&(v202_7))
        };
        drop(v201_5);
        let v201_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v201_2));
        drop(v201_2);
        let v201_10: Space = if map_kernels::has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
        drop(v201_9);
        let v201_12: Space = if (v201_10).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v200_6),&(v200_7_head));
          let mut v206_11 = Space::new();
          let mut v206_11_cursor = (v200_7_tail).read_zipper();
          for v206_11_byte in v206_11_cursor.child_mask().iter() {
            v206_11_cursor.descend_to_byte(v206_11_byte);
            {
            let v206_11_tail = v206_11_cursor.fork_read_zipper();
            let v206_11_head = Path::from_slice(&[v206_11_byte]);
            let v207_2: Space = singleton(&(v206_11_head));
            let v207_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v207_2));
            let v207_4: Space = if map_kernels::has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
            drop(v207_3);
            let v207_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v207_4));
            drop(v207_4);
            let v207_8: Space = if (v207_5).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v206_6),&(v206_11_head));
              let v208_7: Space = routine_22(c, &(v208_6), &(*p1), &(v206_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v207_5),&(v208_7))
            };
            drop(v207_5);
            let v207_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v207_2));
            drop(v207_2);
            let v207_10: Space = if map_kernels::has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
            drop(v207_9);
            let v207_12: Space = if (v207_10).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v206_6),&(v206_11_head));
              let v209_11: Space = routine_10(c, &(v209_6), &(*p1), &(v206_11_tail).make_space(), &(*s1));
              drop(v209_6);
              map_map_kernels::compose(&(v207_10),&(v209_11))
            };
            drop(v207_10);
            let v207_13: Space = map_map_kernels::unite(&(v207_8),&(v207_12));
            v206_11.join_into((v207_13).clone());
            }
            v206_11_cursor.ascend(1);
          }
          drop(v206_11_cursor);
          drop(v206_6);
          map_map_kernels::compose(&(v201_10),&(v206_11))
        };
        drop(v201_10);
        let v201_13: Space = map_map_kernels::unite(&(v201_8),&(v201_12));
        v200_7.join_into((v201_13).clone());
        }
        v200_7_cursor.ascend(1);
      }
      drop(v200_7_cursor);
      drop(v200_6);
      map_map_kernels::compose(&(v199_5),&(v200_7))
    };
    drop(v199_5);
    let v199_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v199_2));
    drop(v199_2);
    let v199_10: Space = if map_kernels::has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
    drop(v199_9);
    let v199_13: Space = if (v199_10).is_empty() { Space::new() } else {
      let v210_11: Space = map_kernels::unwrap(&(v198_9),&(v198_28_head));
      let mut v210_12 = Space::new();
      let mut v210_12_cursor = (v210_11).read_zipper();
      for v210_12_byte in v210_12_cursor.child_mask().iter() {
        v210_12_cursor.descend_to_byte(v210_12_byte);
        {
        let v210_12_tail = v210_12_cursor.fork_read_zipper();
        let v210_12_head = Path::from_slice(&[v210_12_byte]);
        let v211_2: Space = singleton(&(v210_12_head));
        let v211_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v211_2));
        let v211_4: Space = if map_kernels::has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
        drop(v211_3);
        let v211_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v211_4));
        drop(v211_4);
        let v211_7: Space = if (v211_5).is_empty() { Space::new() } else {
          let mut v212_6 = Space::new();
          let mut v212_6_cursor = (v210_12_tail).read_zipper();
          for v212_6_byte in v212_6_cursor.child_mask().iter() {
            v212_6_cursor.descend_to_byte(v212_6_byte);
            {
            let v212_6_tail = v212_6_cursor.fork_read_zipper();
            let v212_6_head = Path::from_slice(&[v212_6_byte]);
            let v213_2: Space = singleton(&(v212_6_head));
            let v213_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v213_2));
            let v213_4: Space = if map_kernels::has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
            drop(v213_3);
            let v213_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v213_4));
            drop(v213_4);
            let v213_8: Space = if (v213_5).is_empty() { Space::new() } else {
              let v214_6: Path = concat_path(&(v210_12_head),&(v212_6_head));
              let v214_7: Space = routine_17(c, &(v214_6), &(*p1), &(v212_6_tail).make_space());
              map_map_kernels::compose(&(v213_5),&(v214_7))
            };
            drop(v213_5);
            let v213_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v213_2));
            drop(v213_2);
            let v213_10: Space = if map_kernels::has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
            drop(v213_9);
            let v213_12: Space = if (v213_10).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v210_12_head),&(v212_6_head));
              let v215_11: Space = routine_18(c, &(v215_6), &(*p1), &(v212_6_tail).make_space());
              drop(v215_6);
              map_map_kernels::compose(&(v213_10),&(v215_11))
            };
            drop(v213_10);
            let v213_13: Space = map_map_kernels::unite(&(v213_8),&(v213_12));
            v212_6.join_into((v213_13).clone());
            }
            v212_6_cursor.ascend(1);
          }
          drop(v212_6_cursor);
          map_map_kernels::compose(&(v211_5),&(v212_6))
        };
        drop(v211_5);
        let v211_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v211_2));
        drop(v211_2);
        let v211_9: Space = if map_kernels::has_head(&(v211_8)) { singleton(&[]) } else { Space::new() };
        drop(v211_8);
        let v211_11: Space = if (v211_9).is_empty() { Space::new() } else {
          let mut v216_10 = Space::new();
          let mut v216_10_cursor = (v210_12_tail).read_zipper();
          for v216_10_byte in v216_10_cursor.child_mask().iter() {
            v216_10_cursor.descend_to_byte(v216_10_byte);
            {
            let v216_10_tail = v216_10_cursor.fork_read_zipper();
            let v216_10_head = Path::from_slice(&[v216_10_byte]);
            let v217_2: Space = singleton(&(v216_10_head));
            let v217_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v217_2));
            let v217_4: Space = if map_kernels::has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
            drop(v217_3);
            let v217_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v217_4));
            drop(v217_4);
            let v217_8: Space = if (v217_5).is_empty() { Space::new() } else {
              let v218_6: Path = concat_path(&(v210_12_head),&(v216_10_head));
              let v218_7: Space = routine_17(c, &(v218_6), &(*p1), &(v216_10_tail).make_space());
              map_map_kernels::compose(&(v217_5),&(v218_7))
            };
            drop(v217_5);
            let v217_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v217_2));
            drop(v217_2);
            let v217_10: Space = if map_kernels::has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
            drop(v217_9);
            let v217_12: Space = if (v217_10).is_empty() { Space::new() } else {
              let v219_6: Path = concat_path(&(v210_12_head),&(v216_10_head));
              let v219_11: Space = routine_19(c, &(v219_6), &(*p1), &(v216_10_tail).make_space());
              drop(v219_6);
              map_map_kernels::compose(&(v217_10),&(v219_11))
            };
            drop(v217_10);
            let v217_13: Space = map_map_kernels::unite(&(v217_8),&(v217_12));
            v216_10.join_into((v217_13).clone());
            }
            v216_10_cursor.ascend(1);
          }
          drop(v216_10_cursor);
          map_map_kernels::compose(&(v211_9),&(v216_10))
        };
        drop(v211_9);
        let v211_12: Space = map_map_kernels::unite(&(v211_7),&(v211_11));
        v210_12.join_into((v211_12).clone());
        }
        v210_12_cursor.ascend(1);
      }
      drop(v210_12_cursor);
      drop(v210_11);
      map_map_kernels::compose(&(v199_10),&(v210_12))
    };
    drop(v199_10);
    let v199_14: Space = map_map_kernels::unite(&(v199_8),&(v199_13));
    v198_28.join_into((v199_14).clone());
    }
    v198_28_cursor.ascend(1);
  }
  drop(v198_28_cursor);
  drop(v198_9);
  (v198_28).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v220_5: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v220_6: Space = map_kernels::unwrap(&(v220_5),&(*p0));
  drop(v220_5);
  let mut v220_25 = Space::new();
  let mut v220_25_cursor = (v220_6).read_zipper();
  for v220_25_byte in v220_25_cursor.child_mask().iter() {
    v220_25_cursor.descend_to_byte(v220_25_byte);
    {
    let v220_25_tail = v220_25_cursor.fork_read_zipper();
    let v220_25_head = Path::from_slice(&[v220_25_byte]);
    let v221_2: Space = singleton(&(v220_25_head));
    let v221_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v221_2));
    let v221_4: Space = if map_kernels::has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
    drop(v221_3);
    let v221_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v221_4));
    drop(v221_4);
    let v221_7: Space = if (v221_5).is_empty() { Space::new() } else {
      let mut v222_6 = Space::new();
      let mut v222_6_cursor = (v220_25_tail).read_zipper();
      for v222_6_byte in v222_6_cursor.child_mask().iter() {
        v222_6_cursor.descend_to_byte(v222_6_byte);
        {
        let v222_6_tail = v222_6_cursor.fork_read_zipper();
        let v222_6_head = Path::from_slice(&[v222_6_byte]);
        let v223_2: Space = singleton(&(v222_6_head));
        let v223_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v223_2));
        let v223_4: Space = if map_kernels::has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v223_4));
        drop(v223_4);
        let v223_8: Space = if (v223_5).is_empty() { Space::new() } else {
          let v224_6: Path = concat_path(&(v220_25_head),&(v222_6_head));
          let mut v224_7 = Space::new();
          let mut v224_7_cursor = (v222_6_tail).read_zipper();
          for v224_7_byte in v224_7_cursor.child_mask().iter() {
            v224_7_cursor.descend_to_byte(v224_7_byte);
            {
            let v224_7_tail = v224_7_cursor.fork_read_zipper();
            let v224_7_head = Path::from_slice(&[v224_7_byte]);
            let v225_2: Space = singleton(&(v224_7_head));
            let v225_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v225_2));
            let v225_4: Space = if map_kernels::has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
            drop(v225_3);
            let v225_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v225_4));
            drop(v225_4);
            let v225_8: Space = if (v225_5).is_empty() { Space::new() } else {
              let v226_6: Path = concat_path(&(v224_6),&(v224_7_head));
              let v226_7: Space = routine_24(c, &(v226_6), &(*p1), &(v224_7_tail).make_space());
              map_map_kernels::compose(&(v225_5),&(v226_7))
            };
            drop(v225_5);
            let v225_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v225_2));
            drop(v225_2);
            let v225_10: Space = if map_kernels::has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
            drop(v225_9);
            let v225_12: Space = if (v225_10).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v224_6),&(v224_7_head));
              let v227_11: Space = routine_25(c, &(v227_6), &(*p1), &(v224_7_tail).make_space());
              drop(v227_6);
              map_map_kernels::compose(&(v225_10),&(v227_11))
            };
            drop(v225_10);
            let v225_13: Space = map_map_kernels::unite(&(v225_8),&(v225_12));
            v224_7.join_into((v225_13).clone());
            }
            v224_7_cursor.ascend(1);
          }
          drop(v224_7_cursor);
          map_map_kernels::compose(&(v223_5),&(v224_7))
        };
        drop(v223_5);
        let v223_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v223_2));
        drop(v223_2);
        let v223_10: Space = if map_kernels::has_head(&(v223_9)) { singleton(&[]) } else { Space::new() };
        drop(v223_9);
        let v223_12: Space = if (v223_10).is_empty() { Space::new() } else {
          let v228_6: Path = concat_path(&(v220_25_head),&(v222_6_head));
          let mut v228_11 = Space::new();
          let mut v228_11_cursor = (v222_6_tail).read_zipper();
          for v228_11_byte in v228_11_cursor.child_mask().iter() {
            v228_11_cursor.descend_to_byte(v228_11_byte);
            {
            let v228_11_tail = v228_11_cursor.fork_read_zipper();
            let v228_11_head = Path::from_slice(&[v228_11_byte]);
            let v229_2: Space = singleton(&(v228_11_head));
            let v229_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v229_2));
            let v229_4: Space = if map_kernels::has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
            drop(v229_3);
            let v229_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v229_4));
            drop(v229_4);
            let v229_8: Space = if (v229_5).is_empty() { Space::new() } else {
              let v230_6: Path = concat_path(&(v228_6),&(v228_11_head));
              let v230_7: Space = routine_24(c, &(v230_6), &(*p1), &(v228_11_tail).make_space());
              map_map_kernels::compose(&(v229_5),&(v230_7))
            };
            drop(v229_5);
            let v229_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v229_2));
            drop(v229_2);
            let v229_10: Space = if map_kernels::has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
            drop(v229_9);
            let v229_12: Space = if (v229_10).is_empty() { Space::new() } else {
              let v231_6: Path = concat_path(&(v228_6),&(v228_11_head));
              let v231_11: Space = routine_19(c, &(v231_6), &(*p1), &(v228_11_tail).make_space());
              drop(v231_6);
              map_map_kernels::compose(&(v229_10),&(v231_11))
            };
            drop(v229_10);
            let v229_13: Space = map_map_kernels::unite(&(v229_8),&(v229_12));
            v228_11.join_into((v229_13).clone());
            }
            v228_11_cursor.ascend(1);
          }
          drop(v228_11_cursor);
          drop(v228_6);
          map_map_kernels::compose(&(v223_10),&(v228_11))
        };
        drop(v223_10);
        let v223_13: Space = map_map_kernels::unite(&(v223_8),&(v223_12));
        v222_6.join_into((v223_13).clone());
        }
        v222_6_cursor.ascend(1);
      }
      drop(v222_6_cursor);
      map_map_kernels::compose(&(v221_5),&(v222_6))
    };
    drop(v221_5);
    let v221_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v221_2));
    drop(v221_2);
    let v221_9: Space = if map_kernels::has_head(&(v221_8)) { singleton(&[]) } else { Space::new() };
    drop(v221_8);
    let v221_11: Space = if (v221_9).is_empty() { Space::new() } else {
      let mut v232_10 = Space::new();
      let mut v232_10_cursor = (v220_25_tail).read_zipper();
      for v232_10_byte in v232_10_cursor.child_mask().iter() {
        v232_10_cursor.descend_to_byte(v232_10_byte);
        {
        let v232_10_tail = v232_10_cursor.fork_read_zipper();
        let v232_10_head = Path::from_slice(&[v232_10_byte]);
        let v233_2: Space = singleton(&(v232_10_head));
        let v233_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v233_2));
        let v233_4: Space = if map_kernels::has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (v233_5).is_empty() { Space::new() } else {
          let v234_6: Path = concat_path(&(v220_25_head),&(v232_10_head));
          let mut v234_7 = Space::new();
          let mut v234_7_cursor = (v232_10_tail).read_zipper();
          for v234_7_byte in v234_7_cursor.child_mask().iter() {
            v234_7_cursor.descend_to_byte(v234_7_byte);
            {
            let v234_7_tail = v234_7_cursor.fork_read_zipper();
            let v234_7_head = Path::from_slice(&[v234_7_byte]);
            let v235_2: Space = singleton(&(v234_7_head));
            let v235_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v235_2));
            let v235_4: Space = if map_kernels::has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
            drop(v235_3);
            let v235_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v235_4));
            drop(v235_4);
            let v235_8: Space = if (v235_5).is_empty() { Space::new() } else {
              let v236_6: Path = concat_path(&(v234_6),&(v234_7_head));
              let v236_7: Space = routine_24(c, &(v236_6), &(*p1), &(v234_7_tail).make_space());
              map_map_kernels::compose(&(v235_5),&(v236_7))
            };
            drop(v235_5);
            let v235_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v235_2));
            drop(v235_2);
            let v235_10: Space = if map_kernels::has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
            drop(v235_9);
            let v235_12: Space = if (v235_10).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v234_6),&(v234_7_head));
              let v237_11: Space = routine_25(c, &(v237_6), &(*p1), &(v234_7_tail).make_space());
              drop(v237_6);
              map_map_kernels::compose(&(v235_10),&(v237_11))
            };
            drop(v235_10);
            let v235_13: Space = map_map_kernels::unite(&(v235_8),&(v235_12));
            v234_7.join_into((v235_13).clone());
            }
            v234_7_cursor.ascend(1);
          }
          drop(v234_7_cursor);
          map_map_kernels::compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if map_kernels::has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_11: Space = map_view_kernels::compose(&(v233_10),&(v232_10_tail));
        drop(v233_10);
        let v238_6: Path = concat_path(&(v220_25_head),&(v232_10_head));
        let v233_12: Space = map_kernels::wrap(&(v233_11),&(v238_6));
        drop(v233_11);
        let v233_13: Space = map_kernels::wrap(&(v233_12),&(*p1));
        drop(v233_12);
        let v233_14: Space = map_map_kernels::unite(&(v233_8),&(v233_13));
        drop(v233_13);
        v232_10.join_into((v233_14).clone());
        }
        v232_10_cursor.ascend(1);
      }
      drop(v232_10_cursor);
      map_map_kernels::compose(&(v221_9),&(v232_10))
    };
    drop(v221_9);
    let v221_12: Space = map_map_kernels::unite(&(v221_7),&(v221_11));
    v220_25.join_into((v221_12).clone());
    }
    v220_25_cursor.ascend(1);
  }
  drop(v220_25_cursor);
  drop(v220_6);
  (v220_25).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v239_20: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v239_21: Space = map_kernels::unwrap(&(v239_20),&(*p0));
  drop(v239_20);
  let mut v239_28 = Space::new();
  let mut v239_28_cursor = (*s0).read_zipper();
  for v239_28_byte in v239_28_cursor.child_mask().iter() {
    v239_28_cursor.descend_to_byte(v239_28_byte);
    {
    let v239_28_tail = v239_28_cursor.fork_read_zipper();
    let v239_28_head = Path::from_slice(&[v239_28_byte]);
    let v240_2: Space = singleton(&(v239_28_head));
    let v240_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v240_2));
    let v240_4: Space = if map_kernels::has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (v240_5).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&(v239_28_head));
      let mut v241_7 = Space::new();
      let mut v241_7_cursor = (v239_28_tail).read_zipper();
      for v241_7_byte in v241_7_cursor.child_mask().iter() {
        v241_7_cursor.descend_to_byte(v241_7_byte);
        {
        let v241_7_tail = v241_7_cursor.fork_read_zipper();
        let v241_7_head = Path::from_slice(&[v241_7_byte]);
        let v242_2: Space = singleton(&(v241_7_head));
        let v242_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if map_kernels::has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (v242_5).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&(v241_7_head));
          let mut v243_7 = Space::new();
          let mut v243_7_cursor = (v241_7_tail).read_zipper();
          for v243_7_byte in v243_7_cursor.child_mask().iter() {
            v243_7_cursor.descend_to_byte(v243_7_byte);
            {
            let v243_7_tail = v243_7_cursor.fork_read_zipper();
            let v243_7_head = Path::from_slice(&[v243_7_byte]);
            let v244_2: Space = singleton(&(v243_7_head));
            let v244_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v244_2));
            let v244_4: Space = if map_kernels::has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (v244_5).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&(v243_7_head));
              let v245_7: Space = routine_26(c, &(v245_6), &(*p1), &(v243_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if map_kernels::has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (v244_10).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&(v243_7_head));
              let v246_11: Space = routine_27(c, &(v246_6), &(*p1), &(v243_7_tail).make_space(), &(*s1));
              drop(v246_6);
              map_map_kernels::compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = map_map_kernels::unite(&(v244_8),&(v244_12));
            v243_7.join_into((v244_13).clone());
            }
            v243_7_cursor.ascend(1);
          }
          drop(v243_7_cursor);
          map_map_kernels::compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if map_kernels::has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (v242_10).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&(v241_7_head));
          let mut v247_11 = Space::new();
          let mut v247_11_cursor = (v241_7_tail).read_zipper();
          for v247_11_byte in v247_11_cursor.child_mask().iter() {
            v247_11_cursor.descend_to_byte(v247_11_byte);
            {
            let v247_11_tail = v247_11_cursor.fork_read_zipper();
            let v247_11_head = Path::from_slice(&[v247_11_byte]);
            let v248_2: Space = singleton(&(v247_11_head));
            let v248_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v248_2));
            let v248_4: Space = if map_kernels::has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&(v247_11_head));
              let v249_7: Space = routine_26(c, &(v249_6), &(*p1), &(v247_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if map_kernels::has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&(v247_11_head));
              let v250_11: Space = routine_10(c, &(v250_6), &(*p1), &(v247_11_tail).make_space(), &(*s1));
              drop(v250_6);
              map_map_kernels::compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = map_map_kernels::unite(&(v248_8),&(v248_12));
            v247_11.join_into((v248_13).clone());
            }
            v247_11_cursor.ascend(1);
          }
          drop(v247_11_cursor);
          drop(v247_6);
          map_map_kernels::compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = map_map_kernels::unite(&(v242_8),&(v242_12));
        v241_7.join_into((v242_13).clone());
        }
        v241_7_cursor.ascend(1);
      }
      drop(v241_7_cursor);
      map_map_kernels::compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if map_kernels::has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_13: Space = if (v240_10).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&(v239_28_head));
      let v251_11: Space = map_kernels::unwrap(&(v239_21),&(v239_28_head));
      let mut v251_12 = Space::new();
      let mut v251_12_cursor = (v239_28_tail).read_zipper();
      for v251_12_byte in v251_12_cursor.child_mask().iter() {
        v251_12_cursor.descend_to_byte(v251_12_byte);
        {
        let v251_12_tail = v251_12_cursor.fork_read_zipper();
        let v251_12_head = Path::from_slice(&[v251_12_byte]);
        let v252_2: Space = singleton(&(v251_12_head));
        let v252_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v252_2));
        let v252_4: Space = if map_kernels::has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (v252_5).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&(v251_12_head));
          let mut v253_7 = Space::new();
          let mut v253_7_cursor = (v251_12_tail).read_zipper();
          for v253_7_byte in v253_7_cursor.child_mask().iter() {
            v253_7_cursor.descend_to_byte(v253_7_byte);
            {
            let v253_7_tail = v253_7_cursor.fork_read_zipper();
            let v253_7_head = Path::from_slice(&[v253_7_byte]);
            let v254_2: Space = singleton(&(v253_7_head));
            let v254_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v254_2));
            let v254_4: Space = if map_kernels::has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
            drop(v254_3);
            let v254_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v254_4));
            drop(v254_4);
            let v254_8: Space = if (v254_5).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v253_6),&(v253_7_head));
              let v255_7: Space = routine_26(c, &(v255_6), &(*p1), &(v253_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v254_5),&(v255_7))
            };
            drop(v254_5);
            let v254_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v254_2));
            drop(v254_2);
            let v254_10: Space = if map_kernels::has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
            drop(v254_9);
            let v254_12: Space = if (v254_10).is_empty() { Space::new() } else {
              let v256_6: Path = concat_path(&(v253_6),&(v253_7_head));
              let v256_11: Space = routine_27(c, &(v256_6), &(*p1), &(v253_7_tail).make_space(), &(*s1));
              drop(v256_6);
              map_map_kernels::compose(&(v254_10),&(v256_11))
            };
            drop(v254_10);
            let v254_13: Space = map_map_kernels::unite(&(v254_8),&(v254_12));
            v253_7.join_into((v254_13).clone());
            }
            v253_7_cursor.ascend(1);
          }
          drop(v253_7_cursor);
          drop(v253_6);
          map_map_kernels::compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if map_kernels::has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_13: Space = if (v252_10).is_empty() { Space::new() } else {
          let v257_11: Space = map_kernels::unwrap(&(v251_11),&(v251_12_head));
          let mut v257_12 = Space::new();
          let mut v257_12_cursor = (v257_11).read_zipper();
          for v257_12_byte in v257_12_cursor.child_mask().iter() {
            v257_12_cursor.descend_to_byte(v257_12_byte);
            {
            let v257_12_tail = v257_12_cursor.fork_read_zipper();
            let v257_12_head = Path::from_slice(&[v257_12_byte]);
            let v258_2: Space = singleton(&(v257_12_head));
            let v258_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v258_2));
            let v258_4: Space = if map_kernels::has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v258_4));
            drop(v258_4);
            let v258_7: Space = if (v258_5).is_empty() { Space::new() } else {
              let v259_6: Space = routine_13(c, &(v257_12_head), &(*p1), &(v257_12_tail).make_space());
              map_map_kernels::compose(&(v258_5),&(v259_6))
            };
            drop(v258_5);
            let v258_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v258_2));
            drop(v258_2);
            let v258_9: Space = if map_kernels::has_head(&(v258_8)) { singleton(&[]) } else { Space::new() };
            drop(v258_8);
            let v258_11: Space = if (v258_9).is_empty() { Space::new() } else {
              let v260_10: Space = routine_14(c, &(v257_12_head), &(*p1), &(v257_12_tail).make_space());
              map_map_kernels::compose(&(v258_9),&(v260_10))
            };
            drop(v258_9);
            let v258_12: Space = map_map_kernels::unite(&(v258_7),&(v258_11));
            v257_12.join_into((v258_12).clone());
            }
            v257_12_cursor.ascend(1);
          }
          drop(v257_12_cursor);
          drop(v257_11);
          map_map_kernels::compose(&(v252_10),&(v257_12))
        };
        drop(v252_10);
        let v252_14: Space = map_map_kernels::unite(&(v252_8),&(v252_13));
        v251_12.join_into((v252_14).clone());
        }
        v251_12_cursor.ascend(1);
      }
      drop(v251_12_cursor);
      drop(v251_6);
      drop(v251_11);
      map_map_kernels::compose(&(v240_10),&(v251_12))
    };
    drop(v240_10);
    let v240_14: Space = map_map_kernels::unite(&(v240_8),&(v240_13));
    v239_28.join_into((v240_14).clone());
    }
    v239_28_cursor.ascend(1);
  }
  drop(v239_28_cursor);
  drop(v239_21);
  (v239_28).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v261_8: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v261_9: Space = map_kernels::unwrap(&(v261_8),&(*p0));
  drop(v261_8);
  let mut v261_28 = Space::new();
  let mut v261_28_cursor = (*s0).read_zipper();
  for v261_28_byte in v261_28_cursor.child_mask().iter() {
    v261_28_cursor.descend_to_byte(v261_28_byte);
    {
    let v261_28_tail = v261_28_cursor.fork_read_zipper();
    let v261_28_head = Path::from_slice(&[v261_28_byte]);
    let v262_2: Space = singleton(&(v261_28_head));
    let v262_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v262_2));
    let v262_4: Space = if map_kernels::has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (v262_5).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&(v261_28_head));
      let mut v263_7 = Space::new();
      let mut v263_7_cursor = (v261_28_tail).read_zipper();
      for v263_7_byte in v263_7_cursor.child_mask().iter() {
        v263_7_cursor.descend_to_byte(v263_7_byte);
        {
        let v263_7_tail = v263_7_cursor.fork_read_zipper();
        let v263_7_head = Path::from_slice(&[v263_7_byte]);
        let v264_2: Space = singleton(&(v263_7_head));
        let v264_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v264_2));
        let v264_4: Space = if map_kernels::has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v264_4));
        drop(v264_4);
        let v264_8: Space = if (v264_5).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v263_6),&(v263_7_head));
          let mut v265_7 = Space::new();
          let mut v265_7_cursor = (v263_7_tail).read_zipper();
          for v265_7_byte in v265_7_cursor.child_mask().iter() {
            v265_7_cursor.descend_to_byte(v265_7_byte);
            {
            let v265_7_tail = v265_7_cursor.fork_read_zipper();
            let v265_7_head = Path::from_slice(&[v265_7_byte]);
            let v266_2: Space = singleton(&(v265_7_head));
            let v266_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v266_2));
            let v266_4: Space = if map_kernels::has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (v266_5).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&(v265_7_head));
              let v267_7: Space = routine_26(c, &(v267_6), &(*p1), &(v265_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if map_kernels::has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (v266_10).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&(v265_7_head));
              let v268_11: Space = routine_27(c, &(v268_6), &(*p1), &(v265_7_tail).make_space(), &(*s1));
              drop(v268_6);
              map_map_kernels::compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = map_map_kernels::unite(&(v266_8),&(v266_12));
            v265_7.join_into((v266_13).clone());
            }
            v265_7_cursor.ascend(1);
          }
          drop(v265_7_cursor);
          map_map_kernels::compose(&(v264_5),&(v265_7))
        };
        drop(v264_5);
        let v264_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v264_2));
        drop(v264_2);
        let v264_10: Space = if map_kernels::has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
        drop(v264_9);
        let v264_12: Space = if (v264_10).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v263_6),&(v263_7_head));
          let mut v269_11 = Space::new();
          let mut v269_11_cursor = (v263_7_tail).read_zipper();
          for v269_11_byte in v269_11_cursor.child_mask().iter() {
            v269_11_cursor.descend_to_byte(v269_11_byte);
            {
            let v269_11_tail = v269_11_cursor.fork_read_zipper();
            let v269_11_head = Path::from_slice(&[v269_11_byte]);
            let v270_2: Space = singleton(&(v269_11_head));
            let v270_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v270_2));
            let v270_4: Space = if map_kernels::has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
            drop(v270_3);
            let v270_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v270_4));
            drop(v270_4);
            let v270_8: Space = if (v270_5).is_empty() { Space::new() } else {
              let v271_6: Path = concat_path(&(v269_6),&(v269_11_head));
              let v271_7: Space = routine_26(c, &(v271_6), &(*p1), &(v269_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v270_5),&(v271_7))
            };
            drop(v270_5);
            let v270_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v270_2));
            drop(v270_2);
            let v270_10: Space = if map_kernels::has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
            drop(v270_9);
            let v270_12: Space = if (v270_10).is_empty() { Space::new() } else {
              let v272_6: Path = concat_path(&(v269_6),&(v269_11_head));
              let v272_11: Space = routine_10(c, &(v272_6), &(*p1), &(v269_11_tail).make_space(), &(*s1));
              drop(v272_6);
              map_map_kernels::compose(&(v270_10),&(v272_11))
            };
            drop(v270_10);
            let v270_13: Space = map_map_kernels::unite(&(v270_8),&(v270_12));
            v269_11.join_into((v270_13).clone());
            }
            v269_11_cursor.ascend(1);
          }
          drop(v269_11_cursor);
          drop(v269_6);
          map_map_kernels::compose(&(v264_10),&(v269_11))
        };
        drop(v264_10);
        let v264_13: Space = map_map_kernels::unite(&(v264_8),&(v264_12));
        v263_7.join_into((v264_13).clone());
        }
        v263_7_cursor.ascend(1);
      }
      drop(v263_7_cursor);
      drop(v263_6);
      map_map_kernels::compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if map_kernels::has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_13: Space = if (v262_10).is_empty() { Space::new() } else {
      let v273_11: Space = map_kernels::unwrap(&(v261_9),&(v261_28_head));
      let mut v273_12 = Space::new();
      let mut v273_12_cursor = (v273_11).read_zipper();
      for v273_12_byte in v273_12_cursor.child_mask().iter() {
        v273_12_cursor.descend_to_byte(v273_12_byte);
        {
        let v273_12_tail = v273_12_cursor.fork_read_zipper();
        let v273_12_head = Path::from_slice(&[v273_12_byte]);
        let v274_2: Space = singleton(&(v273_12_head));
        let v274_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v274_2));
        let v274_4: Space = if map_kernels::has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v274_4));
        drop(v274_4);
        let v274_7: Space = if (v274_5).is_empty() { Space::new() } else {
          let mut v275_6 = Space::new();
          let mut v275_6_cursor = (v273_12_tail).read_zipper();
          for v275_6_byte in v275_6_cursor.child_mask().iter() {
            v275_6_cursor.descend_to_byte(v275_6_byte);
            {
            let v275_6_tail = v275_6_cursor.fork_read_zipper();
            let v275_6_head = Path::from_slice(&[v275_6_byte]);
            let v276_2: Space = singleton(&(v275_6_head));
            let v276_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v276_2));
            let v276_4: Space = if map_kernels::has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
            drop(v276_3);
            let v276_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v276_4));
            drop(v276_4);
            let v276_8: Space = if (v276_5).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v273_12_head),&(v275_6_head));
              let v277_7: Space = routine_17(c, &(v277_6), &(*p1), &(v275_6_tail).make_space());
              map_map_kernels::compose(&(v276_5),&(v277_7))
            };
            drop(v276_5);
            let v276_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v276_2));
            drop(v276_2);
            let v276_10: Space = if map_kernels::has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
            drop(v276_9);
            let v276_12: Space = if (v276_10).is_empty() { Space::new() } else {
              let v278_6: Path = concat_path(&(v273_12_head),&(v275_6_head));
              let v278_11: Space = routine_18(c, &(v278_6), &(*p1), &(v275_6_tail).make_space());
              drop(v278_6);
              map_map_kernels::compose(&(v276_10),&(v278_11))
            };
            drop(v276_10);
            let v276_13: Space = map_map_kernels::unite(&(v276_8),&(v276_12));
            v275_6.join_into((v276_13).clone());
            }
            v275_6_cursor.ascend(1);
          }
          drop(v275_6_cursor);
          map_map_kernels::compose(&(v274_5),&(v275_6))
        };
        drop(v274_5);
        let v274_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v274_2));
        drop(v274_2);
        let v274_9: Space = if map_kernels::has_head(&(v274_8)) { singleton(&[]) } else { Space::new() };
        drop(v274_8);
        let v274_11: Space = if (v274_9).is_empty() { Space::new() } else {
          let mut v279_10 = Space::new();
          let mut v279_10_cursor = (v273_12_tail).read_zipper();
          for v279_10_byte in v279_10_cursor.child_mask().iter() {
            v279_10_cursor.descend_to_byte(v279_10_byte);
            {
            let v279_10_tail = v279_10_cursor.fork_read_zipper();
            let v279_10_head = Path::from_slice(&[v279_10_byte]);
            let v280_2: Space = singleton(&(v279_10_head));
            let v280_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v280_2));
            let v280_4: Space = if map_kernels::has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
            drop(v280_3);
            let v280_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v280_4));
            drop(v280_4);
            let v280_8: Space = if (v280_5).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v273_12_head),&(v279_10_head));
              let v281_7: Space = routine_17(c, &(v281_6), &(*p1), &(v279_10_tail).make_space());
              map_map_kernels::compose(&(v280_5),&(v281_7))
            };
            drop(v280_5);
            let v280_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v280_2));
            drop(v280_2);
            let v280_10: Space = if map_kernels::has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
            drop(v280_9);
            let v280_12: Space = if (v280_10).is_empty() { Space::new() } else {
              let v282_6: Path = concat_path(&(v273_12_head),&(v279_10_head));
              let v282_11: Space = routine_19(c, &(v282_6), &(*p1), &(v279_10_tail).make_space());
              drop(v282_6);
              map_map_kernels::compose(&(v280_10),&(v282_11))
            };
            drop(v280_10);
            let v280_13: Space = map_map_kernels::unite(&(v280_8),&(v280_12));
            v279_10.join_into((v280_13).clone());
            }
            v279_10_cursor.ascend(1);
          }
          drop(v279_10_cursor);
          map_map_kernels::compose(&(v274_9),&(v279_10))
        };
        drop(v274_9);
        let v274_12: Space = map_map_kernels::unite(&(v274_7),&(v274_11));
        v273_12.join_into((v274_12).clone());
        }
        v273_12_cursor.ascend(1);
      }
      drop(v273_12_cursor);
      drop(v273_11);
      map_map_kernels::compose(&(v262_10),&(v273_12))
    };
    drop(v262_10);
    let v262_14: Space = map_map_kernels::unite(&(v262_8),&(v262_13));
    v261_28.join_into((v262_14).clone());
    }
    v261_28_cursor.ascend(1);
  }
  drop(v261_28_cursor);
  drop(v261_9);
  (v261_28).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v283_21 = Space::new();
  let mut v283_21_cursor = (*s0).read_zipper();
  for v283_21_byte in v283_21_cursor.child_mask().iter() {
    v283_21_cursor.descend_to_byte(v283_21_byte);
    {
    let v283_21_tail = v283_21_cursor.fork_read_zipper();
    let v283_21_head = Path::from_slice(&[v283_21_byte]);
    let v284_2: Space = singleton(&(v283_21_head));
    let v284_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v284_2));
    let v284_4: Space = if map_kernels::has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (v284_5).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&(v283_21_head));
      let mut v285_7 = Space::new();
      let mut v285_7_cursor = (v283_21_tail).read_zipper();
      for v285_7_byte in v285_7_cursor.child_mask().iter() {
        v285_7_cursor.descend_to_byte(v285_7_byte);
        {
        let v285_7_tail = v285_7_cursor.fork_read_zipper();
        let v285_7_head = Path::from_slice(&[v285_7_byte]);
        let v286_2: Space = singleton(&(v285_7_head));
        let v286_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v286_2));
        let v286_4: Space = if map_kernels::has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (v286_5).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&(v285_7_head));
          let mut v287_7 = Space::new();
          let mut v287_7_cursor = (v285_7_tail).read_zipper();
          for v287_7_byte in v287_7_cursor.child_mask().iter() {
            v287_7_cursor.descend_to_byte(v287_7_byte);
            {
            let v287_7_tail = v287_7_cursor.fork_read_zipper();
            let v287_7_head = Path::from_slice(&[v287_7_byte]);
            let v288_2: Space = singleton(&(v287_7_head));
            let v288_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v288_2));
            let v288_4: Space = if map_kernels::has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (v288_5).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&(v287_7_head));
              let v289_7: Space = routine_28(c, &(v289_6), &(*p1), &(v287_7_tail).make_space());
              map_map_kernels::compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if map_kernels::has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (v288_10).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&(v287_7_head));
              let v290_11: Space = routine_29(c, &(v290_6), &(*p1), &(v287_7_tail).make_space());
              drop(v290_6);
              map_map_kernels::compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = map_map_kernels::unite(&(v288_8),&(v288_12));
            v287_7.join_into((v288_13).clone());
            }
            v287_7_cursor.ascend(1);
          }
          drop(v287_7_cursor);
          map_map_kernels::compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if map_kernels::has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (v286_10).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&(v285_7_head));
          let mut v291_11 = Space::new();
          let mut v291_11_cursor = (v285_7_tail).read_zipper();
          for v291_11_byte in v291_11_cursor.child_mask().iter() {
            v291_11_cursor.descend_to_byte(v291_11_byte);
            {
            let v291_11_tail = v291_11_cursor.fork_read_zipper();
            let v291_11_head = Path::from_slice(&[v291_11_byte]);
            let v292_2: Space = singleton(&(v291_11_head));
            let v292_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v292_2));
            let v292_4: Space = if map_kernels::has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&(v291_11_head));
              let v293_7: Space = routine_28(c, &(v293_6), &(*p1), &(v291_11_tail).make_space());
              map_map_kernels::compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if map_kernels::has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (v292_10).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&(v291_11_head));
              let v294_11: Space = routine_19(c, &(v294_6), &(*p1), &(v291_11_tail).make_space());
              drop(v294_6);
              map_map_kernels::compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = map_map_kernels::unite(&(v292_8),&(v292_12));
            v291_11.join_into((v292_13).clone());
            }
            v291_11_cursor.ascend(1);
          }
          drop(v291_11_cursor);
          drop(v291_6);
          map_map_kernels::compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = map_map_kernels::unite(&(v286_8),&(v286_12));
        v285_7.join_into((v286_13).clone());
        }
        v285_7_cursor.ascend(1);
      }
      drop(v285_7_cursor);
      map_map_kernels::compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if map_kernels::has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (v284_10).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&(v283_21_head));
      let mut v295_11 = Space::new();
      let mut v295_11_cursor = (v283_21_tail).read_zipper();
      for v295_11_byte in v295_11_cursor.child_mask().iter() {
        v295_11_cursor.descend_to_byte(v295_11_byte);
        {
        let v295_11_tail = v295_11_cursor.fork_read_zipper();
        let v295_11_head = Path::from_slice(&[v295_11_byte]);
        let v296_2: Space = singleton(&(v295_11_head));
        let v296_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v296_2));
        let v296_4: Space = if map_kernels::has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (v296_5).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&(v295_11_head));
          let mut v297_7 = Space::new();
          let mut v297_7_cursor = (v295_11_tail).read_zipper();
          for v297_7_byte in v297_7_cursor.child_mask().iter() {
            v297_7_cursor.descend_to_byte(v297_7_byte);
            {
            let v297_7_tail = v297_7_cursor.fork_read_zipper();
            let v297_7_head = Path::from_slice(&[v297_7_byte]);
            let v298_2: Space = singleton(&(v297_7_head));
            let v298_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v298_2));
            let v298_4: Space = if map_kernels::has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (v298_5).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&(v297_7_head));
              let v299_7: Space = routine_28(c, &(v299_6), &(*p1), &(v297_7_tail).make_space());
              map_map_kernels::compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if map_kernels::has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (v298_10).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&(v297_7_head));
              let v300_11: Space = routine_29(c, &(v300_6), &(*p1), &(v297_7_tail).make_space());
              drop(v300_6);
              map_map_kernels::compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = map_map_kernels::unite(&(v298_8),&(v298_12));
            v297_7.join_into((v298_13).clone());
            }
            v297_7_cursor.ascend(1);
          }
          drop(v297_7_cursor);
          map_map_kernels::compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if map_kernels::has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = map_view_kernels::compose(&(v296_10),&(v295_11_tail));
        drop(v296_10);
        let v301_6: Path = concat_path(&(v295_6),&(v295_11_head));
        let v296_12: Space = map_kernels::wrap(&(v296_11),&(v301_6));
        drop(v296_11);
        let v296_13: Space = map_kernels::wrap(&(v296_12),&(*p1));
        drop(v296_12);
        let v296_14: Space = map_map_kernels::unite(&(v296_8),&(v296_13));
        drop(v296_13);
        v295_11.join_into((v296_14).clone());
        }
        v295_11_cursor.ascend(1);
      }
      drop(v295_11_cursor);
      drop(v295_6);
      map_map_kernels::compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = map_map_kernels::unite(&(v284_8),&(v284_12));
    v283_21.join_into((v284_13).clone());
    }
    v283_21_cursor.ascend(1);
  }
  drop(v283_21_cursor);
  (v283_21).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v302_15 = Space::new();
  let mut v302_15_cursor = (*s0).read_zipper();
  for v302_15_byte in v302_15_cursor.child_mask().iter() {
    v302_15_cursor.descend_to_byte(v302_15_byte);
    {
    let v302_15_tail = v302_15_cursor.fork_read_zipper();
    let v302_15_head = Path::from_slice(&[v302_15_byte]);
    let v303_2: Space = singleton(&(v302_15_head));
    let v303_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v303_2));
    let v303_4: Space = if map_kernels::has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (v303_5).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&(v302_15_head));
      let mut v304_7 = Space::new();
      let mut v304_7_cursor = (v302_15_tail).read_zipper();
      for v304_7_byte in v304_7_cursor.child_mask().iter() {
        v304_7_cursor.descend_to_byte(v304_7_byte);
        {
        let v304_7_tail = v304_7_cursor.fork_read_zipper();
        let v304_7_head = Path::from_slice(&[v304_7_byte]);
        let v305_2: Space = singleton(&(v304_7_head));
        let v305_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v305_2));
        let v305_4: Space = if map_kernels::has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (v305_5).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let mut v306_7 = Space::new();
          let mut v306_7_cursor = (v304_7_tail).read_zipper();
          for v306_7_byte in v306_7_cursor.child_mask().iter() {
            v306_7_cursor.descend_to_byte(v306_7_byte);
            {
            let v306_7_tail = v306_7_cursor.fork_read_zipper();
            let v306_7_head = Path::from_slice(&[v306_7_byte]);
            let v307_2: Space = singleton(&(v306_7_head));
            let v307_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v307_2));
            let v307_4: Space = if map_kernels::has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
            drop(v307_3);
            let v307_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v307_4));
            drop(v307_4);
            let v307_8: Space = if (v307_5).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v306_6),&(v306_7_head));
              let v308_7: Space = routine_28(c, &(v308_6), &(*p1), &(v306_7_tail).make_space());
              map_map_kernels::compose(&(v307_5),&(v308_7))
            };
            drop(v307_5);
            let v307_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v307_2));
            drop(v307_2);
            let v307_10: Space = if map_kernels::has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
            drop(v307_9);
            let v307_12: Space = if (v307_10).is_empty() { Space::new() } else {
              let v309_6: Path = concat_path(&(v306_6),&(v306_7_head));
              let v309_11: Space = routine_29(c, &(v309_6), &(*p1), &(v306_7_tail).make_space());
              drop(v309_6);
              map_map_kernels::compose(&(v307_10),&(v309_11))
            };
            drop(v307_10);
            let v307_13: Space = map_map_kernels::unite(&(v307_8),&(v307_12));
            v306_7.join_into((v307_13).clone());
            }
            v306_7_cursor.ascend(1);
          }
          drop(v306_7_cursor);
          map_map_kernels::compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if map_kernels::has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (v305_10).is_empty() { Space::new() } else {
          let v310_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let mut v310_11 = Space::new();
          let mut v310_11_cursor = (v304_7_tail).read_zipper();
          for v310_11_byte in v310_11_cursor.child_mask().iter() {
            v310_11_cursor.descend_to_byte(v310_11_byte);
            {
            let v310_11_tail = v310_11_cursor.fork_read_zipper();
            let v310_11_head = Path::from_slice(&[v310_11_byte]);
            let v311_2: Space = singleton(&(v310_11_head));
            let v311_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v311_2));
            let v311_4: Space = if map_kernels::has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
            drop(v311_3);
            let v311_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v311_4));
            drop(v311_4);
            let v311_8: Space = if (v311_5).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v310_6),&(v310_11_head));
              let v312_7: Space = routine_28(c, &(v312_6), &(*p1), &(v310_11_tail).make_space());
              map_map_kernels::compose(&(v311_5),&(v312_7))
            };
            drop(v311_5);
            let v311_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v311_2));
            drop(v311_2);
            let v311_10: Space = if map_kernels::has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
            drop(v311_9);
            let v311_12: Space = if (v311_10).is_empty() { Space::new() } else {
              let v313_6: Path = concat_path(&(v310_6),&(v310_11_head));
              let v313_11: Space = routine_19(c, &(v313_6), &(*p1), &(v310_11_tail).make_space());
              drop(v313_6);
              map_map_kernels::compose(&(v311_10),&(v313_11))
            };
            drop(v311_10);
            let v311_13: Space = map_map_kernels::unite(&(v311_8),&(v311_12));
            v310_11.join_into((v311_13).clone());
            }
            v310_11_cursor.ascend(1);
          }
          drop(v310_11_cursor);
          drop(v310_6);
          map_map_kernels::compose(&(v305_10),&(v310_11))
        };
        drop(v305_10);
        let v305_13: Space = map_map_kernels::unite(&(v305_8),&(v305_12));
        v304_7.join_into((v305_13).clone());
        }
        v304_7_cursor.ascend(1);
      }
      drop(v304_7_cursor);
      map_map_kernels::compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if map_kernels::has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_11: Space = map_view_kernels::compose(&(v303_10),&(v302_15_tail));
    drop(v303_10);
    let v314_6: Path = concat_path(&(*p0),&(v302_15_head));
    let v303_12: Space = map_kernels::wrap(&(v303_11),&(v314_6));
    drop(v303_11);
    let v303_13: Space = map_kernels::wrap(&(v303_12),&(*p1));
    drop(v303_12);
    let v303_14: Space = map_map_kernels::unite(&(v303_8),&(v303_13));
    drop(v303_13);
    v302_15.join_into((v303_14).clone());
    }
    v302_15_cursor.ascend(1);
  }
  drop(v302_15_cursor);
  (v302_15).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v315_20: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v315_21: Space = map_kernels::unwrap(&(v315_20),&(*p0));
  drop(v315_20);
  let mut v315_28 = Space::new();
  let mut v315_28_cursor = (*s0).read_zipper();
  for v315_28_byte in v315_28_cursor.child_mask().iter() {
    v315_28_cursor.descend_to_byte(v315_28_byte);
    {
    let v315_28_tail = v315_28_cursor.fork_read_zipper();
    let v315_28_head = Path::from_slice(&[v315_28_byte]);
    let v316_2: Space = singleton(&(v315_28_head));
    let v316_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v316_2));
    let v316_4: Space = if map_kernels::has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
    drop(v316_3);
    let v316_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v316_4));
    drop(v316_4);
    let v316_8: Space = if (v316_5).is_empty() { Space::new() } else {
      let v317_6: Path = concat_path(&(*p0),&(v315_28_head));
      let mut v317_7 = Space::new();
      let mut v317_7_cursor = (v315_28_tail).read_zipper();
      for v317_7_byte in v317_7_cursor.child_mask().iter() {
        v317_7_cursor.descend_to_byte(v317_7_byte);
        {
        let v317_7_tail = v317_7_cursor.fork_read_zipper();
        let v317_7_head = Path::from_slice(&[v317_7_byte]);
        let v318_2: Space = singleton(&(v317_7_head));
        let v318_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v318_2));
        let v318_4: Space = if map_kernels::has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
        drop(v318_3);
        let v318_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v318_4));
        drop(v318_4);
        let v318_8: Space = if (v318_5).is_empty() { Space::new() } else {
          let v319_6: Path = concat_path(&(v317_6),&(v317_7_head));
          let mut v319_7 = Space::new();
          let mut v319_7_cursor = (v317_7_tail).read_zipper();
          for v319_7_byte in v319_7_cursor.child_mask().iter() {
            v319_7_cursor.descend_to_byte(v319_7_byte);
            {
            let v319_7_tail = v319_7_cursor.fork_read_zipper();
            let v319_7_head = Path::from_slice(&[v319_7_byte]);
            let v320_2: Space = singleton(&(v319_7_head));
            let v320_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v320_2));
            let v320_4: Space = if map_kernels::has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
            drop(v320_3);
            let v320_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v320_4));
            drop(v320_4);
            let v320_8: Space = if (v320_5).is_empty() { Space::new() } else {
              let v321_6: Path = concat_path(&(v319_6),&(v319_7_head));
              let v321_7: Space = routine_30(c, &(v321_6), &(*p1), &(v319_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v320_5),&(v321_7))
            };
            drop(v320_5);
            let v320_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v320_2));
            drop(v320_2);
            let v320_10: Space = if map_kernels::has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
            drop(v320_9);
            let v320_12: Space = if (v320_10).is_empty() { Space::new() } else {
              let v322_6: Path = concat_path(&(v319_6),&(v319_7_head));
              let v322_11: Space = routine_31(c, &(v322_6), &(*p1), &(v319_7_tail).make_space(), &(*s1));
              drop(v322_6);
              map_map_kernels::compose(&(v320_10),&(v322_11))
            };
            drop(v320_10);
            let v320_13: Space = map_map_kernels::unite(&(v320_8),&(v320_12));
            v319_7.join_into((v320_13).clone());
            }
            v319_7_cursor.ascend(1);
          }
          drop(v319_7_cursor);
          map_map_kernels::compose(&(v318_5),&(v319_7))
        };
        drop(v318_5);
        let v318_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v318_2));
        drop(v318_2);
        let v318_10: Space = if map_kernels::has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
        drop(v318_9);
        let v318_12: Space = if (v318_10).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v317_6),&(v317_7_head));
          let mut v323_11 = Space::new();
          let mut v323_11_cursor = (v317_7_tail).read_zipper();
          for v323_11_byte in v323_11_cursor.child_mask().iter() {
            v323_11_cursor.descend_to_byte(v323_11_byte);
            {
            let v323_11_tail = v323_11_cursor.fork_read_zipper();
            let v323_11_head = Path::from_slice(&[v323_11_byte]);
            let v324_2: Space = singleton(&(v323_11_head));
            let v324_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v324_2));
            let v324_4: Space = if map_kernels::has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
            drop(v324_3);
            let v324_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v324_4));
            drop(v324_4);
            let v324_8: Space = if (v324_5).is_empty() { Space::new() } else {
              let v325_6: Path = concat_path(&(v323_6),&(v323_11_head));
              let v325_7: Space = routine_30(c, &(v325_6), &(*p1), &(v323_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v324_5),&(v325_7))
            };
            drop(v324_5);
            let v324_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v324_2));
            drop(v324_2);
            let v324_10: Space = if map_kernels::has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
            drop(v324_9);
            let v324_12: Space = if (v324_10).is_empty() { Space::new() } else {
              let v326_6: Path = concat_path(&(v323_6),&(v323_11_head));
              let v326_11: Space = routine_10(c, &(v326_6), &(*p1), &(v323_11_tail).make_space(), &(*s1));
              drop(v326_6);
              map_map_kernels::compose(&(v324_10),&(v326_11))
            };
            drop(v324_10);
            let v324_13: Space = map_map_kernels::unite(&(v324_8),&(v324_12));
            v323_11.join_into((v324_13).clone());
            }
            v323_11_cursor.ascend(1);
          }
          drop(v323_11_cursor);
          drop(v323_6);
          map_map_kernels::compose(&(v318_10),&(v323_11))
        };
        drop(v318_10);
        let v318_13: Space = map_map_kernels::unite(&(v318_8),&(v318_12));
        v317_7.join_into((v318_13).clone());
        }
        v317_7_cursor.ascend(1);
      }
      drop(v317_7_cursor);
      map_map_kernels::compose(&(v316_5),&(v317_7))
    };
    drop(v316_5);
    let v316_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v316_2));
    drop(v316_2);
    let v316_10: Space = if map_kernels::has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
    drop(v316_9);
    let v316_13: Space = if (v316_10).is_empty() { Space::new() } else {
      let v327_6: Path = concat_path(&(*p0),&(v315_28_head));
      let v327_11: Space = map_kernels::unwrap(&(v315_21),&(v315_28_head));
      let mut v327_12 = Space::new();
      let mut v327_12_cursor = (v315_28_tail).read_zipper();
      for v327_12_byte in v327_12_cursor.child_mask().iter() {
        v327_12_cursor.descend_to_byte(v327_12_byte);
        {
        let v327_12_tail = v327_12_cursor.fork_read_zipper();
        let v327_12_head = Path::from_slice(&[v327_12_byte]);
        let v328_2: Space = singleton(&(v327_12_head));
        let v328_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v328_2));
        let v328_4: Space = if map_kernels::has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
        drop(v328_3);
        let v328_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v328_4));
        drop(v328_4);
        let v328_8: Space = if (v328_5).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v327_6),&(v327_12_head));
          let mut v329_7 = Space::new();
          let mut v329_7_cursor = (v327_12_tail).read_zipper();
          for v329_7_byte in v329_7_cursor.child_mask().iter() {
            v329_7_cursor.descend_to_byte(v329_7_byte);
            {
            let v329_7_tail = v329_7_cursor.fork_read_zipper();
            let v329_7_head = Path::from_slice(&[v329_7_byte]);
            let v330_2: Space = singleton(&(v329_7_head));
            let v330_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v330_2));
            let v330_4: Space = if map_kernels::has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
            drop(v330_3);
            let v330_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v330_4));
            drop(v330_4);
            let v330_8: Space = if (v330_5).is_empty() { Space::new() } else {
              let v331_6: Path = concat_path(&(v329_6),&(v329_7_head));
              let v331_7: Space = routine_30(c, &(v331_6), &(*p1), &(v329_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v330_5),&(v331_7))
            };
            drop(v330_5);
            let v330_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v330_2));
            drop(v330_2);
            let v330_10: Space = if map_kernels::has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
            drop(v330_9);
            let v330_12: Space = if (v330_10).is_empty() { Space::new() } else {
              let v332_6: Path = concat_path(&(v329_6),&(v329_7_head));
              let v332_11: Space = routine_31(c, &(v332_6), &(*p1), &(v329_7_tail).make_space(), &(*s1));
              drop(v332_6);
              map_map_kernels::compose(&(v330_10),&(v332_11))
            };
            drop(v330_10);
            let v330_13: Space = map_map_kernels::unite(&(v330_8),&(v330_12));
            v329_7.join_into((v330_13).clone());
            }
            v329_7_cursor.ascend(1);
          }
          drop(v329_7_cursor);
          drop(v329_6);
          map_map_kernels::compose(&(v328_5),&(v329_7))
        };
        drop(v328_5);
        let v328_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v328_2));
        drop(v328_2);
        let v328_10: Space = if map_kernels::has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
        drop(v328_9);
        let v328_13: Space = if (v328_10).is_empty() { Space::new() } else {
          let v333_11: Space = map_kernels::unwrap(&(v327_11),&(v327_12_head));
          let mut v333_12 = Space::new();
          let mut v333_12_cursor = (v333_11).read_zipper();
          for v333_12_byte in v333_12_cursor.child_mask().iter() {
            v333_12_cursor.descend_to_byte(v333_12_byte);
            {
            let v333_12_tail = v333_12_cursor.fork_read_zipper();
            let v333_12_head = Path::from_slice(&[v333_12_byte]);
            let v334_2: Space = singleton(&(v333_12_head));
            let v334_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v334_2));
            let v334_4: Space = if map_kernels::has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
            drop(v334_3);
            let v334_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v334_4));
            drop(v334_4);
            let v334_7: Space = if (v334_5).is_empty() { Space::new() } else {
              let v335_6: Space = routine_13(c, &(v333_12_head), &(*p1), &(v333_12_tail).make_space());
              map_map_kernels::compose(&(v334_5),&(v335_6))
            };
            drop(v334_5);
            let v334_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v334_2));
            drop(v334_2);
            let v334_9: Space = if map_kernels::has_head(&(v334_8)) { singleton(&[]) } else { Space::new() };
            drop(v334_8);
            let v334_11: Space = if (v334_9).is_empty() { Space::new() } else {
              let v336_10: Space = routine_14(c, &(v333_12_head), &(*p1), &(v333_12_tail).make_space());
              map_map_kernels::compose(&(v334_9),&(v336_10))
            };
            drop(v334_9);
            let v334_12: Space = map_map_kernels::unite(&(v334_7),&(v334_11));
            v333_12.join_into((v334_12).clone());
            }
            v333_12_cursor.ascend(1);
          }
          drop(v333_12_cursor);
          drop(v333_11);
          map_map_kernels::compose(&(v328_10),&(v333_12))
        };
        drop(v328_10);
        let v328_14: Space = map_map_kernels::unite(&(v328_8),&(v328_13));
        v327_12.join_into((v328_14).clone());
        }
        v327_12_cursor.ascend(1);
      }
      drop(v327_12_cursor);
      drop(v327_6);
      drop(v327_11);
      map_map_kernels::compose(&(v316_10),&(v327_12))
    };
    drop(v316_10);
    let v316_14: Space = map_map_kernels::unite(&(v316_8),&(v316_13));
    v315_28.join_into((v316_14).clone());
    }
    v315_28_cursor.ascend(1);
  }
  drop(v315_28_cursor);
  drop(v315_21);
  (v315_28).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v337_8: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v337_9: Space = map_kernels::unwrap(&(v337_8),&(*p0));
  drop(v337_8);
  let mut v337_28 = Space::new();
  let mut v337_28_cursor = (*s0).read_zipper();
  for v337_28_byte in v337_28_cursor.child_mask().iter() {
    v337_28_cursor.descend_to_byte(v337_28_byte);
    {
    let v337_28_tail = v337_28_cursor.fork_read_zipper();
    let v337_28_head = Path::from_slice(&[v337_28_byte]);
    let v338_2: Space = singleton(&(v337_28_head));
    let v338_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v338_2));
    let v338_4: Space = if map_kernels::has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
    drop(v338_3);
    let v338_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v338_4));
    drop(v338_4);
    let v338_8: Space = if (v338_5).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&(v337_28_head));
      let mut v339_7 = Space::new();
      let mut v339_7_cursor = (v337_28_tail).read_zipper();
      for v339_7_byte in v339_7_cursor.child_mask().iter() {
        v339_7_cursor.descend_to_byte(v339_7_byte);
        {
        let v339_7_tail = v339_7_cursor.fork_read_zipper();
        let v339_7_head = Path::from_slice(&[v339_7_byte]);
        let v340_2: Space = singleton(&(v339_7_head));
        let v340_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v340_2));
        let v340_4: Space = if map_kernels::has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v340_4));
        drop(v340_4);
        let v340_8: Space = if (v340_5).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v339_6),&(v339_7_head));
          let mut v341_7 = Space::new();
          let mut v341_7_cursor = (v339_7_tail).read_zipper();
          for v341_7_byte in v341_7_cursor.child_mask().iter() {
            v341_7_cursor.descend_to_byte(v341_7_byte);
            {
            let v341_7_tail = v341_7_cursor.fork_read_zipper();
            let v341_7_head = Path::from_slice(&[v341_7_byte]);
            let v342_2: Space = singleton(&(v341_7_head));
            let v342_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v342_2));
            let v342_4: Space = if map_kernels::has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
            drop(v342_3);
            let v342_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v342_4));
            drop(v342_4);
            let v342_8: Space = if (v342_5).is_empty() { Space::new() } else {
              let v343_6: Path = concat_path(&(v341_6),&(v341_7_head));
              let v343_7: Space = routine_30(c, &(v343_6), &(*p1), &(v341_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v342_5),&(v343_7))
            };
            drop(v342_5);
            let v342_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v342_2));
            drop(v342_2);
            let v342_10: Space = if map_kernels::has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
            drop(v342_9);
            let v342_12: Space = if (v342_10).is_empty() { Space::new() } else {
              let v344_6: Path = concat_path(&(v341_6),&(v341_7_head));
              let v344_11: Space = routine_31(c, &(v344_6), &(*p1), &(v341_7_tail).make_space(), &(*s1));
              drop(v344_6);
              map_map_kernels::compose(&(v342_10),&(v344_11))
            };
            drop(v342_10);
            let v342_13: Space = map_map_kernels::unite(&(v342_8),&(v342_12));
            v341_7.join_into((v342_13).clone());
            }
            v341_7_cursor.ascend(1);
          }
          drop(v341_7_cursor);
          map_map_kernels::compose(&(v340_5),&(v341_7))
        };
        drop(v340_5);
        let v340_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v340_2));
        drop(v340_2);
        let v340_10: Space = if map_kernels::has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
        drop(v340_9);
        let v340_12: Space = if (v340_10).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v339_6),&(v339_7_head));
          let mut v345_11 = Space::new();
          let mut v345_11_cursor = (v339_7_tail).read_zipper();
          for v345_11_byte in v345_11_cursor.child_mask().iter() {
            v345_11_cursor.descend_to_byte(v345_11_byte);
            {
            let v345_11_tail = v345_11_cursor.fork_read_zipper();
            let v345_11_head = Path::from_slice(&[v345_11_byte]);
            let v346_2: Space = singleton(&(v345_11_head));
            let v346_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v346_2));
            let v346_4: Space = if map_kernels::has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
            drop(v346_3);
            let v346_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v346_4));
            drop(v346_4);
            let v346_8: Space = if (v346_5).is_empty() { Space::new() } else {
              let v347_6: Path = concat_path(&(v345_6),&(v345_11_head));
              let v347_7: Space = routine_30(c, &(v347_6), &(*p1), &(v345_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v346_5),&(v347_7))
            };
            drop(v346_5);
            let v346_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v346_2));
            drop(v346_2);
            let v346_10: Space = if map_kernels::has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
            drop(v346_9);
            let v346_12: Space = if (v346_10).is_empty() { Space::new() } else {
              let v348_6: Path = concat_path(&(v345_6),&(v345_11_head));
              let v348_11: Space = routine_10(c, &(v348_6), &(*p1), &(v345_11_tail).make_space(), &(*s1));
              drop(v348_6);
              map_map_kernels::compose(&(v346_10),&(v348_11))
            };
            drop(v346_10);
            let v346_13: Space = map_map_kernels::unite(&(v346_8),&(v346_12));
            v345_11.join_into((v346_13).clone());
            }
            v345_11_cursor.ascend(1);
          }
          drop(v345_11_cursor);
          drop(v345_6);
          map_map_kernels::compose(&(v340_10),&(v345_11))
        };
        drop(v340_10);
        let v340_13: Space = map_map_kernels::unite(&(v340_8),&(v340_12));
        v339_7.join_into((v340_13).clone());
        }
        v339_7_cursor.ascend(1);
      }
      drop(v339_7_cursor);
      drop(v339_6);
      map_map_kernels::compose(&(v338_5),&(v339_7))
    };
    drop(v338_5);
    let v338_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v338_2));
    drop(v338_2);
    let v338_10: Space = if map_kernels::has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
    drop(v338_9);
    let v338_13: Space = if (v338_10).is_empty() { Space::new() } else {
      let v349_11: Space = map_kernels::unwrap(&(v337_9),&(v337_28_head));
      let mut v349_12 = Space::new();
      let mut v349_12_cursor = (v349_11).read_zipper();
      for v349_12_byte in v349_12_cursor.child_mask().iter() {
        v349_12_cursor.descend_to_byte(v349_12_byte);
        {
        let v349_12_tail = v349_12_cursor.fork_read_zipper();
        let v349_12_head = Path::from_slice(&[v349_12_byte]);
        let v350_2: Space = singleton(&(v349_12_head));
        let v350_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v350_2));
        let v350_4: Space = if map_kernels::has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
        drop(v350_3);
        let v350_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v350_4));
        drop(v350_4);
        let v350_7: Space = if (v350_5).is_empty() { Space::new() } else {
          let mut v351_6 = Space::new();
          let mut v351_6_cursor = (v349_12_tail).read_zipper();
          for v351_6_byte in v351_6_cursor.child_mask().iter() {
            v351_6_cursor.descend_to_byte(v351_6_byte);
            {
            let v351_6_tail = v351_6_cursor.fork_read_zipper();
            let v351_6_head = Path::from_slice(&[v351_6_byte]);
            let v352_2: Space = singleton(&(v351_6_head));
            let v352_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v352_2));
            let v352_4: Space = if map_kernels::has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v352_4));
            drop(v352_4);
            let v352_8: Space = if (v352_5).is_empty() { Space::new() } else {
              let v353_6: Path = concat_path(&(v349_12_head),&(v351_6_head));
              let v353_7: Space = routine_17(c, &(v353_6), &(*p1), &(v351_6_tail).make_space());
              map_map_kernels::compose(&(v352_5),&(v353_7))
            };
            drop(v352_5);
            let v352_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v352_2));
            drop(v352_2);
            let v352_10: Space = if map_kernels::has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
            drop(v352_9);
            let v352_12: Space = if (v352_10).is_empty() { Space::new() } else {
              let v354_6: Path = concat_path(&(v349_12_head),&(v351_6_head));
              let v354_11: Space = routine_18(c, &(v354_6), &(*p1), &(v351_6_tail).make_space());
              drop(v354_6);
              map_map_kernels::compose(&(v352_10),&(v354_11))
            };
            drop(v352_10);
            let v352_13: Space = map_map_kernels::unite(&(v352_8),&(v352_12));
            v351_6.join_into((v352_13).clone());
            }
            v351_6_cursor.ascend(1);
          }
          drop(v351_6_cursor);
          map_map_kernels::compose(&(v350_5),&(v351_6))
        };
        drop(v350_5);
        let v350_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v350_2));
        drop(v350_2);
        let v350_9: Space = if map_kernels::has_head(&(v350_8)) { singleton(&[]) } else { Space::new() };
        drop(v350_8);
        let v350_11: Space = if (v350_9).is_empty() { Space::new() } else {
          let mut v355_10 = Space::new();
          let mut v355_10_cursor = (v349_12_tail).read_zipper();
          for v355_10_byte in v355_10_cursor.child_mask().iter() {
            v355_10_cursor.descend_to_byte(v355_10_byte);
            {
            let v355_10_tail = v355_10_cursor.fork_read_zipper();
            let v355_10_head = Path::from_slice(&[v355_10_byte]);
            let v356_2: Space = singleton(&(v355_10_head));
            let v356_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v356_2));
            let v356_4: Space = if map_kernels::has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
            drop(v356_3);
            let v356_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v356_4));
            drop(v356_4);
            let v356_8: Space = if (v356_5).is_empty() { Space::new() } else {
              let v357_6: Path = concat_path(&(v349_12_head),&(v355_10_head));
              let v357_7: Space = routine_17(c, &(v357_6), &(*p1), &(v355_10_tail).make_space());
              map_map_kernels::compose(&(v356_5),&(v357_7))
            };
            drop(v356_5);
            let v356_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v356_2));
            drop(v356_2);
            let v356_10: Space = if map_kernels::has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
            drop(v356_9);
            let v356_12: Space = if (v356_10).is_empty() { Space::new() } else {
              let v358_6: Path = concat_path(&(v349_12_head),&(v355_10_head));
              let v358_11: Space = routine_19(c, &(v358_6), &(*p1), &(v355_10_tail).make_space());
              drop(v358_6);
              map_map_kernels::compose(&(v356_10),&(v358_11))
            };
            drop(v356_10);
            let v356_13: Space = map_map_kernels::unite(&(v356_8),&(v356_12));
            v355_10.join_into((v356_13).clone());
            }
            v355_10_cursor.ascend(1);
          }
          drop(v355_10_cursor);
          map_map_kernels::compose(&(v350_9),&(v355_10))
        };
        drop(v350_9);
        let v350_12: Space = map_map_kernels::unite(&(v350_7),&(v350_11));
        v349_12.join_into((v350_12).clone());
        }
        v349_12_cursor.ascend(1);
      }
      drop(v349_12_cursor);
      drop(v349_11);
      map_map_kernels::compose(&(v338_10),&(v349_12))
    };
    drop(v338_10);
    let v338_14: Space = map_map_kernels::unite(&(v338_8),&(v338_13));
    v337_28.join_into((v338_14).clone());
    }
    v337_28_cursor.ascend(1);
  }
  drop(v337_28_cursor);
  drop(v337_9);
  (v337_28).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v359_21 = Space::new();
  let mut v359_21_cursor = (*s0).read_zipper();
  for v359_21_byte in v359_21_cursor.child_mask().iter() {
    v359_21_cursor.descend_to_byte(v359_21_byte);
    {
    let v359_21_tail = v359_21_cursor.fork_read_zipper();
    let v359_21_head = Path::from_slice(&[v359_21_byte]);
    let v360_2: Space = singleton(&(v359_21_head));
    let v360_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v360_2));
    let v360_4: Space = if map_kernels::has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v360_4));
    drop(v360_4);
    let v360_8: Space = if (v360_5).is_empty() { Space::new() } else {
      let v361_6: Path = concat_path(&(*p0),&(v359_21_head));
      let mut v361_7 = Space::new();
      let mut v361_7_cursor = (v359_21_tail).read_zipper();
      for v361_7_byte in v361_7_cursor.child_mask().iter() {
        v361_7_cursor.descend_to_byte(v361_7_byte);
        {
        let v361_7_tail = v361_7_cursor.fork_read_zipper();
        let v361_7_head = Path::from_slice(&[v361_7_byte]);
        let v362_2: Space = singleton(&(v361_7_head));
        let v362_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v362_2));
        let v362_4: Space = if map_kernels::has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
        drop(v362_3);
        let v362_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v362_4));
        drop(v362_4);
        let v362_8: Space = if (v362_5).is_empty() { Space::new() } else {
          let v363_6: Path = concat_path(&(v361_6),&(v361_7_head));
          let mut v363_7 = Space::new();
          let mut v363_7_cursor = (v361_7_tail).read_zipper();
          for v363_7_byte in v363_7_cursor.child_mask().iter() {
            v363_7_cursor.descend_to_byte(v363_7_byte);
            {
            let v363_7_tail = v363_7_cursor.fork_read_zipper();
            let v363_7_head = Path::from_slice(&[v363_7_byte]);
            let v364_2: Space = singleton(&(v363_7_head));
            let v364_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v364_2));
            let v364_4: Space = if map_kernels::has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
            drop(v364_3);
            let v364_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v364_4));
            drop(v364_4);
            let v364_8: Space = if (v364_5).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v363_6),&(v363_7_head));
              let v365_7: Space = routine_32(c, &(v365_6), &(*p1), &(v363_7_tail).make_space());
              map_map_kernels::compose(&(v364_5),&(v365_7))
            };
            drop(v364_5);
            let v364_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v364_2));
            drop(v364_2);
            let v364_10: Space = if map_kernels::has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
            drop(v364_9);
            let v364_12: Space = if (v364_10).is_empty() { Space::new() } else {
              let v366_6: Path = concat_path(&(v363_6),&(v363_7_head));
              let v366_11: Space = routine_33(c, &(v366_6), &(*p1), &(v363_7_tail).make_space());
              drop(v366_6);
              map_map_kernels::compose(&(v364_10),&(v366_11))
            };
            drop(v364_10);
            let v364_13: Space = map_map_kernels::unite(&(v364_8),&(v364_12));
            v363_7.join_into((v364_13).clone());
            }
            v363_7_cursor.ascend(1);
          }
          drop(v363_7_cursor);
          map_map_kernels::compose(&(v362_5),&(v363_7))
        };
        drop(v362_5);
        let v362_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v362_2));
        drop(v362_2);
        let v362_10: Space = if map_kernels::has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
        drop(v362_9);
        let v362_12: Space = if (v362_10).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v361_6),&(v361_7_head));
          let mut v367_11 = Space::new();
          let mut v367_11_cursor = (v361_7_tail).read_zipper();
          for v367_11_byte in v367_11_cursor.child_mask().iter() {
            v367_11_cursor.descend_to_byte(v367_11_byte);
            {
            let v367_11_tail = v367_11_cursor.fork_read_zipper();
            let v367_11_head = Path::from_slice(&[v367_11_byte]);
            let v368_2: Space = singleton(&(v367_11_head));
            let v368_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v368_2));
            let v368_4: Space = if map_kernels::has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
            drop(v368_3);
            let v368_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v368_4));
            drop(v368_4);
            let v368_8: Space = if (v368_5).is_empty() { Space::new() } else {
              let v369_6: Path = concat_path(&(v367_6),&(v367_11_head));
              let v369_7: Space = routine_32(c, &(v369_6), &(*p1), &(v367_11_tail).make_space());
              map_map_kernels::compose(&(v368_5),&(v369_7))
            };
            drop(v368_5);
            let v368_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v368_2));
            drop(v368_2);
            let v368_10: Space = if map_kernels::has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
            drop(v368_9);
            let v368_12: Space = if (v368_10).is_empty() { Space::new() } else {
              let v370_6: Path = concat_path(&(v367_6),&(v367_11_head));
              let v370_11: Space = routine_19(c, &(v370_6), &(*p1), &(v367_11_tail).make_space());
              drop(v370_6);
              map_map_kernels::compose(&(v368_10),&(v370_11))
            };
            drop(v368_10);
            let v368_13: Space = map_map_kernels::unite(&(v368_8),&(v368_12));
            v367_11.join_into((v368_13).clone());
            }
            v367_11_cursor.ascend(1);
          }
          drop(v367_11_cursor);
          drop(v367_6);
          map_map_kernels::compose(&(v362_10),&(v367_11))
        };
        drop(v362_10);
        let v362_13: Space = map_map_kernels::unite(&(v362_8),&(v362_12));
        v361_7.join_into((v362_13).clone());
        }
        v361_7_cursor.ascend(1);
      }
      drop(v361_7_cursor);
      map_map_kernels::compose(&(v360_5),&(v361_7))
    };
    drop(v360_5);
    let v360_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v360_2));
    drop(v360_2);
    let v360_10: Space = if map_kernels::has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
    drop(v360_9);
    let v360_12: Space = if (v360_10).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&(v359_21_head));
      let mut v371_11 = Space::new();
      let mut v371_11_cursor = (v359_21_tail).read_zipper();
      for v371_11_byte in v371_11_cursor.child_mask().iter() {
        v371_11_cursor.descend_to_byte(v371_11_byte);
        {
        let v371_11_tail = v371_11_cursor.fork_read_zipper();
        let v371_11_head = Path::from_slice(&[v371_11_byte]);
        let v372_2: Space = singleton(&(v371_11_head));
        let v372_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v372_2));
        let v372_4: Space = if map_kernels::has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (v372_5).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&(v371_11_head));
          let mut v373_7 = Space::new();
          let mut v373_7_cursor = (v371_11_tail).read_zipper();
          for v373_7_byte in v373_7_cursor.child_mask().iter() {
            v373_7_cursor.descend_to_byte(v373_7_byte);
            {
            let v373_7_tail = v373_7_cursor.fork_read_zipper();
            let v373_7_head = Path::from_slice(&[v373_7_byte]);
            let v374_2: Space = singleton(&(v373_7_head));
            let v374_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v374_2));
            let v374_4: Space = if map_kernels::has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (v374_5).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&(v373_7_head));
              let v375_7: Space = routine_32(c, &(v375_6), &(*p1), &(v373_7_tail).make_space());
              map_map_kernels::compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if map_kernels::has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (v374_10).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&(v373_7_head));
              let v376_11: Space = routine_33(c, &(v376_6), &(*p1), &(v373_7_tail).make_space());
              drop(v376_6);
              map_map_kernels::compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = map_map_kernels::unite(&(v374_8),&(v374_12));
            v373_7.join_into((v374_13).clone());
            }
            v373_7_cursor.ascend(1);
          }
          drop(v373_7_cursor);
          map_map_kernels::compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if map_kernels::has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_11: Space = map_view_kernels::compose(&(v372_10),&(v371_11_tail));
        drop(v372_10);
        let v377_6: Path = concat_path(&(v371_6),&(v371_11_head));
        let v372_12: Space = map_kernels::wrap(&(v372_11),&(v377_6));
        drop(v372_11);
        let v372_13: Space = map_kernels::wrap(&(v372_12),&(*p1));
        drop(v372_12);
        let v372_14: Space = map_map_kernels::unite(&(v372_8),&(v372_13));
        drop(v372_13);
        v371_11.join_into((v372_14).clone());
        }
        v371_11_cursor.ascend(1);
      }
      drop(v371_11_cursor);
      drop(v371_6);
      map_map_kernels::compose(&(v360_10),&(v371_11))
    };
    drop(v360_10);
    let v360_13: Space = map_map_kernels::unite(&(v360_8),&(v360_12));
    v359_21.join_into((v360_13).clone());
    }
    v359_21_cursor.ascend(1);
  }
  drop(v359_21_cursor);
  (v359_21).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v378_15 = Space::new();
  let mut v378_15_cursor = (*s0).read_zipper();
  for v378_15_byte in v378_15_cursor.child_mask().iter() {
    v378_15_cursor.descend_to_byte(v378_15_byte);
    {
    let v378_15_tail = v378_15_cursor.fork_read_zipper();
    let v378_15_head = Path::from_slice(&[v378_15_byte]);
    let v379_2: Space = singleton(&(v378_15_head));
    let v379_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v379_2));
    let v379_4: Space = if map_kernels::has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
    drop(v379_3);
    let v379_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v379_4));
    drop(v379_4);
    let v379_8: Space = if (v379_5).is_empty() { Space::new() } else {
      let v380_6: Path = concat_path(&(*p0),&(v378_15_head));
      let mut v380_7 = Space::new();
      let mut v380_7_cursor = (v378_15_tail).read_zipper();
      for v380_7_byte in v380_7_cursor.child_mask().iter() {
        v380_7_cursor.descend_to_byte(v380_7_byte);
        {
        let v380_7_tail = v380_7_cursor.fork_read_zipper();
        let v380_7_head = Path::from_slice(&[v380_7_byte]);
        let v381_2: Space = singleton(&(v380_7_head));
        let v381_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v381_2));
        let v381_4: Space = if map_kernels::has_head(&(v381_3)) { singleton(&[]) } else { Space::new() };
        drop(v381_3);
        let v381_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v381_4));
        drop(v381_4);
        let v381_8: Space = if (v381_5).is_empty() { Space::new() } else {
          let v382_6: Path = concat_path(&(v380_6),&(v380_7_head));
          let mut v382_7 = Space::new();
          let mut v382_7_cursor = (v380_7_tail).read_zipper();
          for v382_7_byte in v382_7_cursor.child_mask().iter() {
            v382_7_cursor.descend_to_byte(v382_7_byte);
            {
            let v382_7_tail = v382_7_cursor.fork_read_zipper();
            let v382_7_head = Path::from_slice(&[v382_7_byte]);
            let v383_2: Space = singleton(&(v382_7_head));
            let v383_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v383_2));
            let v383_4: Space = if map_kernels::has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
            drop(v383_3);
            let v383_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v383_4));
            drop(v383_4);
            let v383_8: Space = if (v383_5).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v382_6),&(v382_7_head));
              let v384_7: Space = routine_32(c, &(v384_6), &(*p1), &(v382_7_tail).make_space());
              map_map_kernels::compose(&(v383_5),&(v384_7))
            };
            drop(v383_5);
            let v383_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v383_2));
            drop(v383_2);
            let v383_10: Space = if map_kernels::has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
            drop(v383_9);
            let v383_12: Space = if (v383_10).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v382_6),&(v382_7_head));
              let v385_11: Space = routine_33(c, &(v385_6), &(*p1), &(v382_7_tail).make_space());
              drop(v385_6);
              map_map_kernels::compose(&(v383_10),&(v385_11))
            };
            drop(v383_10);
            let v383_13: Space = map_map_kernels::unite(&(v383_8),&(v383_12));
            v382_7.join_into((v383_13).clone());
            }
            v382_7_cursor.ascend(1);
          }
          drop(v382_7_cursor);
          map_map_kernels::compose(&(v381_5),&(v382_7))
        };
        drop(v381_5);
        let v381_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v381_2));
        drop(v381_2);
        let v381_10: Space = if map_kernels::has_head(&(v381_9)) { singleton(&[]) } else { Space::new() };
        drop(v381_9);
        let v381_12: Space = if (v381_10).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v380_6),&(v380_7_head));
          let mut v386_11 = Space::new();
          let mut v386_11_cursor = (v380_7_tail).read_zipper();
          for v386_11_byte in v386_11_cursor.child_mask().iter() {
            v386_11_cursor.descend_to_byte(v386_11_byte);
            {
            let v386_11_tail = v386_11_cursor.fork_read_zipper();
            let v386_11_head = Path::from_slice(&[v386_11_byte]);
            let v387_2: Space = singleton(&(v386_11_head));
            let v387_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v387_2));
            let v387_4: Space = if map_kernels::has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
            drop(v387_3);
            let v387_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v387_4));
            drop(v387_4);
            let v387_8: Space = if (v387_5).is_empty() { Space::new() } else {
              let v388_6: Path = concat_path(&(v386_6),&(v386_11_head));
              let v388_7: Space = routine_32(c, &(v388_6), &(*p1), &(v386_11_tail).make_space());
              map_map_kernels::compose(&(v387_5),&(v388_7))
            };
            drop(v387_5);
            let v387_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v387_2));
            drop(v387_2);
            let v387_10: Space = if map_kernels::has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
            drop(v387_9);
            let v387_12: Space = if (v387_10).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v386_6),&(v386_11_head));
              let v389_11: Space = routine_19(c, &(v389_6), &(*p1), &(v386_11_tail).make_space());
              drop(v389_6);
              map_map_kernels::compose(&(v387_10),&(v389_11))
            };
            drop(v387_10);
            let v387_13: Space = map_map_kernels::unite(&(v387_8),&(v387_12));
            v386_11.join_into((v387_13).clone());
            }
            v386_11_cursor.ascend(1);
          }
          drop(v386_11_cursor);
          drop(v386_6);
          map_map_kernels::compose(&(v381_10),&(v386_11))
        };
        drop(v381_10);
        let v381_13: Space = map_map_kernels::unite(&(v381_8),&(v381_12));
        v380_7.join_into((v381_13).clone());
        }
        v380_7_cursor.ascend(1);
      }
      drop(v380_7_cursor);
      map_map_kernels::compose(&(v379_5),&(v380_7))
    };
    drop(v379_5);
    let v379_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v379_2));
    drop(v379_2);
    let v379_10: Space = if map_kernels::has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
    drop(v379_9);
    let v379_11: Space = map_view_kernels::compose(&(v379_10),&(v378_15_tail));
    drop(v379_10);
    let v390_6: Path = concat_path(&(*p0),&(v378_15_head));
    let v379_12: Space = map_kernels::wrap(&(v379_11),&(v390_6));
    drop(v379_11);
    let v379_13: Space = map_kernels::wrap(&(v379_12),&(*p1));
    drop(v379_12);
    let v379_14: Space = map_map_kernels::unite(&(v379_8),&(v379_13));
    drop(v379_13);
    v378_15.join_into((v379_14).clone());
    }
    v378_15_cursor.ascend(1);
  }
  drop(v378_15_cursor);
  (v378_15).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v391_3: Space = map_kernels::wrap(&(*s0),&(*p0));
  let v391_4: Space = map_kernels::wrap(&(v391_3),&(*p1));
  drop(v391_3);
  (v391_4).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v392_24 = Space::new();
  let mut v392_24_cursor = (*s0).read_zipper();
  for v392_24_byte in v392_24_cursor.child_mask().iter() {
    v392_24_cursor.descend_to_byte(v392_24_byte);
    {
    let v392_24_tail = v392_24_cursor.fork_read_zipper();
    let v392_24_head = Path::from_slice(&[v392_24_byte]);
    let v393_2: Space = singleton(&(v392_24_head));
    let v393_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v393_2));
    let v393_4: Space = if map_kernels::has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v393_4));
    drop(v393_4);
    let v393_8: Space = if (v393_5).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&(v392_24_head));
      let mut v394_7 = Space::new();
      let mut v394_7_cursor = (v392_24_tail).read_zipper();
      for v394_7_byte in v394_7_cursor.child_mask().iter() {
        v394_7_cursor.descend_to_byte(v394_7_byte);
        {
        let v394_7_tail = v394_7_cursor.fork_read_zipper();
        let v394_7_head = Path::from_slice(&[v394_7_byte]);
        let v395_2: Space = singleton(&(v394_7_head));
        let v395_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v395_2));
        let v395_4: Space = if map_kernels::has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
        drop(v395_3);
        let v395_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v395_4));
        drop(v395_4);
        let v395_8: Space = if (v395_5).is_empty() { Space::new() } else {
          let v396_6: Path = concat_path(&(v394_6),&(v394_7_head));
          let mut v396_7 = Space::new();
          let mut v396_7_cursor = (v394_7_tail).read_zipper();
          for v396_7_byte in v396_7_cursor.child_mask().iter() {
            v396_7_cursor.descend_to_byte(v396_7_byte);
            {
            let v396_7_tail = v396_7_cursor.fork_read_zipper();
            let v396_7_head = Path::from_slice(&[v396_7_byte]);
            let v397_2: Space = singleton(&(v396_7_head));
            let v397_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v397_2));
            let v397_4: Space = if map_kernels::has_head(&(v397_3)) { singleton(&[]) } else { Space::new() };
            drop(v397_3);
            let v397_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v397_4));
            drop(v397_4);
            let v397_8: Space = if (v397_5).is_empty() { Space::new() } else {
              let v398_6: Path = concat_path(&(v396_6),&(v396_7_head));
              let v398_7: Space = routine_34(c, &(v398_6), &(v396_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v397_5),&(v398_7))
            };
            drop(v397_5);
            let v397_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v397_2));
            drop(v397_2);
            let v397_10: Space = if map_kernels::has_head(&(v397_9)) { singleton(&[]) } else { Space::new() };
            drop(v397_9);
            let v397_12: Space = if (v397_10).is_empty() { Space::new() } else {
              let v399_6: Path = concat_path(&(v396_6),&(v396_7_head));
              let v399_11: Space = routine_35(c, &(v399_6), &(v396_7_tail).make_space(), &(*s1));
              drop(v399_6);
              map_map_kernels::compose(&(v397_10),&(v399_11))
            };
            drop(v397_10);
            let v397_13: Space = map_map_kernels::unite(&(v397_8),&(v397_12));
            v396_7.join_into((v397_13).clone());
            }
            v396_7_cursor.ascend(1);
          }
          drop(v396_7_cursor);
          map_map_kernels::compose(&(v395_5),&(v396_7))
        };
        drop(v395_5);
        let v395_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v395_2));
        drop(v395_2);
        let v395_10: Space = if map_kernels::has_head(&(v395_9)) { singleton(&[]) } else { Space::new() };
        drop(v395_9);
        let v395_12: Space = if (v395_10).is_empty() { Space::new() } else {
          let v400_6: Path = concat_path(&(v394_6),&(v394_7_head));
          let mut v400_11 = Space::new();
          let mut v400_11_cursor = (v394_7_tail).read_zipper();
          for v400_11_byte in v400_11_cursor.child_mask().iter() {
            v400_11_cursor.descend_to_byte(v400_11_byte);
            {
            let v400_11_tail = v400_11_cursor.fork_read_zipper();
            let v400_11_head = Path::from_slice(&[v400_11_byte]);
            let v401_2: Space = singleton(&(v400_11_head));
            let v401_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v401_2));
            let v401_4: Space = if map_kernels::has_head(&(v401_3)) { singleton(&[]) } else { Space::new() };
            drop(v401_3);
            let v401_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v401_4));
            drop(v401_4);
            let v401_8: Space = if (v401_5).is_empty() { Space::new() } else {
              let v402_6: Path = concat_path(&(v400_6),&(v400_11_head));
              let v402_7: Space = routine_34(c, &(v402_6), &(v400_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v401_5),&(v402_7))
            };
            drop(v401_5);
            let v401_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v401_2));
            drop(v401_2);
            let v401_10: Space = if map_kernels::has_head(&(v401_9)) { singleton(&[]) } else { Space::new() };
            drop(v401_9);
            let v401_12: Space = if (v401_10).is_empty() { Space::new() } else {
              let v403_6: Path = concat_path(&(v400_6),&(v400_11_head));
              let v403_11: Space = routine_3(c, &(v403_6), &(v400_11_tail).make_space(), &(*s1));
              drop(v403_6);
              map_map_kernels::compose(&(v401_10),&(v403_11))
            };
            drop(v401_10);
            let v401_13: Space = map_map_kernels::unite(&(v401_8),&(v401_12));
            v400_11.join_into((v401_13).clone());
            }
            v400_11_cursor.ascend(1);
          }
          drop(v400_11_cursor);
          drop(v400_6);
          map_map_kernels::compose(&(v395_10),&(v400_11))
        };
        drop(v395_10);
        let v395_13: Space = map_map_kernels::unite(&(v395_8),&(v395_12));
        v394_7.join_into((v395_13).clone());
        }
        v394_7_cursor.ascend(1);
      }
      drop(v394_7_cursor);
      map_map_kernels::compose(&(v393_5),&(v394_7))
    };
    drop(v393_5);
    let v393_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v393_2));
    drop(v393_2);
    let v393_10: Space = if map_kernels::has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
    drop(v393_9);
    let v393_12: Space = if (v393_10).is_empty() { Space::new() } else {
      let v404_6: Path = concat_path(&(*p0),&(v392_24_head));
      let mut v404_11 = Space::new();
      let mut v404_11_cursor = (v392_24_tail).read_zipper();
      for v404_11_byte in v404_11_cursor.child_mask().iter() {
        v404_11_cursor.descend_to_byte(v404_11_byte);
        {
        let v404_11_tail = v404_11_cursor.fork_read_zipper();
        let v404_11_head = Path::from_slice(&[v404_11_byte]);
        let v405_2: Space = singleton(&(v404_11_head));
        let v405_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v405_2));
        let v405_4: Space = if map_kernels::has_head(&(v405_3)) { singleton(&[]) } else { Space::new() };
        drop(v405_3);
        let v405_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v405_4));
        drop(v405_4);
        let v405_8: Space = if (v405_5).is_empty() { Space::new() } else {
          let v406_6: Path = concat_path(&(v404_6),&(v404_11_head));
          let mut v406_7 = Space::new();
          let mut v406_7_cursor = (v404_11_tail).read_zipper();
          for v406_7_byte in v406_7_cursor.child_mask().iter() {
            v406_7_cursor.descend_to_byte(v406_7_byte);
            {
            let v406_7_tail = v406_7_cursor.fork_read_zipper();
            let v406_7_head = Path::from_slice(&[v406_7_byte]);
            let v407_2: Space = singleton(&(v406_7_head));
            let v407_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v407_2));
            let v407_4: Space = if map_kernels::has_head(&(v407_3)) { singleton(&[]) } else { Space::new() };
            drop(v407_3);
            let v407_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v407_4));
            drop(v407_4);
            let v407_8: Space = if (v407_5).is_empty() { Space::new() } else {
              let v408_6: Path = concat_path(&(v406_6),&(v406_7_head));
              let v408_7: Space = routine_34(c, &(v408_6), &(v406_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v407_5),&(v408_7))
            };
            drop(v407_5);
            let v407_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v407_2));
            drop(v407_2);
            let v407_10: Space = if map_kernels::has_head(&(v407_9)) { singleton(&[]) } else { Space::new() };
            drop(v407_9);
            let v407_12: Space = if (v407_10).is_empty() { Space::new() } else {
              let v409_6: Path = concat_path(&(v406_6),&(v406_7_head));
              let v409_11: Space = routine_35(c, &(v409_6), &(v406_7_tail).make_space(), &(*s1));
              drop(v409_6);
              map_map_kernels::compose(&(v407_10),&(v409_11))
            };
            drop(v407_10);
            let v407_13: Space = map_map_kernels::unite(&(v407_8),&(v407_12));
            v406_7.join_into((v407_13).clone());
            }
            v406_7_cursor.ascend(1);
          }
          drop(v406_7_cursor);
          map_map_kernels::compose(&(v405_5),&(v406_7))
        };
        drop(v405_5);
        let v405_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v405_2));
        drop(v405_2);
        let v405_10: Space = if map_kernels::has_head(&(v405_9)) { singleton(&[]) } else { Space::new() };
        drop(v405_9);
        let v405_12: Space = if (v405_10).is_empty() { Space::new() } else {
          let v410_6: Path = concat_path(&(v404_6),&(v404_11_head));
          let mut v410_11 = Space::new();
          let mut v410_11_cursor = (v404_11_tail).read_zipper();
          for v410_11_byte in v410_11_cursor.child_mask().iter() {
            v410_11_cursor.descend_to_byte(v410_11_byte);
            {
            let v410_11_tail = v410_11_cursor.fork_read_zipper();
            let v410_11_head = Path::from_slice(&[v410_11_byte]);
            let v411_2: Space = singleton(&(v410_11_head));
            let v411_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v411_2));
            let v411_4: Space = if map_kernels::has_head(&(v411_3)) { singleton(&[]) } else { Space::new() };
            drop(v411_3);
            let v411_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v411_4));
            drop(v411_4);
            let v411_7: Space = if (v411_5).is_empty() { Space::new() } else {
              let v412_6: Space = routine_4(c, &(v410_11_head), &(v410_6), &(v410_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v411_5),&(v412_6))
            };
            drop(v411_5);
            let v411_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v411_2));
            drop(v411_2);
            let v411_9: Space = if map_kernels::has_head(&(v411_8)) { singleton(&[]) } else { Space::new() };
            drop(v411_8);
            let v411_11: Space = if (v411_9).is_empty() { Space::new() } else {
              let v413_10: Space = routine_5(c, &(v410_11_head), &(v410_6), &(v410_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v411_9),&(v413_10))
            };
            drop(v411_9);
            let v411_12: Space = map_map_kernels::unite(&(v411_7),&(v411_11));
            v410_11.join_into((v411_12).clone());
            }
            v410_11_cursor.ascend(1);
          }
          drop(v410_11_cursor);
          drop(v410_6);
          map_map_kernels::compose(&(v405_10),&(v410_11))
        };
        drop(v405_10);
        let v405_13: Space = map_map_kernels::unite(&(v405_8),&(v405_12));
        v404_11.join_into((v405_13).clone());
        }
        v404_11_cursor.ascend(1);
      }
      drop(v404_11_cursor);
      drop(v404_6);
      map_map_kernels::compose(&(v393_10),&(v404_11))
    };
    drop(v393_10);
    let v393_13: Space = map_map_kernels::unite(&(v393_8),&(v393_12));
    v392_24.join_into((v393_13).clone());
    }
    v392_24_cursor.ascend(1);
  }
  drop(v392_24_cursor);
  (v392_24).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v414_24 = Space::new();
  let mut v414_24_cursor = (*s0).read_zipper();
  for v414_24_byte in v414_24_cursor.child_mask().iter() {
    v414_24_cursor.descend_to_byte(v414_24_byte);
    {
    let v414_24_tail = v414_24_cursor.fork_read_zipper();
    let v414_24_head = Path::from_slice(&[v414_24_byte]);
    let v415_2: Space = singleton(&(v414_24_head));
    let v415_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v415_2));
    let v415_4: Space = if map_kernels::has_head(&(v415_3)) { singleton(&[]) } else { Space::new() };
    drop(v415_3);
    let v415_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v415_4));
    drop(v415_4);
    let v415_8: Space = if (v415_5).is_empty() { Space::new() } else {
      let v416_6: Path = concat_path(&(*p0),&(v414_24_head));
      let mut v416_7 = Space::new();
      let mut v416_7_cursor = (v414_24_tail).read_zipper();
      for v416_7_byte in v416_7_cursor.child_mask().iter() {
        v416_7_cursor.descend_to_byte(v416_7_byte);
        {
        let v416_7_tail = v416_7_cursor.fork_read_zipper();
        let v416_7_head = Path::from_slice(&[v416_7_byte]);
        let v417_2: Space = singleton(&(v416_7_head));
        let v417_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v417_2));
        let v417_4: Space = if map_kernels::has_head(&(v417_3)) { singleton(&[]) } else { Space::new() };
        drop(v417_3);
        let v417_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v417_4));
        drop(v417_4);
        let v417_8: Space = if (v417_5).is_empty() { Space::new() } else {
          let v418_6: Path = concat_path(&(v416_6),&(v416_7_head));
          let mut v418_7 = Space::new();
          let mut v418_7_cursor = (v416_7_tail).read_zipper();
          for v418_7_byte in v418_7_cursor.child_mask().iter() {
            v418_7_cursor.descend_to_byte(v418_7_byte);
            {
            let v418_7_tail = v418_7_cursor.fork_read_zipper();
            let v418_7_head = Path::from_slice(&[v418_7_byte]);
            let v419_2: Space = singleton(&(v418_7_head));
            let v419_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v419_2));
            let v419_4: Space = if map_kernels::has_head(&(v419_3)) { singleton(&[]) } else { Space::new() };
            drop(v419_3);
            let v419_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v419_4));
            drop(v419_4);
            let v419_8: Space = if (v419_5).is_empty() { Space::new() } else {
              let v420_6: Path = concat_path(&(v418_6),&(v418_7_head));
              let v420_7: Space = routine_34(c, &(v420_6), &(v418_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v419_5),&(v420_7))
            };
            drop(v419_5);
            let v419_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v419_2));
            drop(v419_2);
            let v419_10: Space = if map_kernels::has_head(&(v419_9)) { singleton(&[]) } else { Space::new() };
            drop(v419_9);
            let v419_12: Space = if (v419_10).is_empty() { Space::new() } else {
              let v421_6: Path = concat_path(&(v418_6),&(v418_7_head));
              let v421_11: Space = routine_35(c, &(v421_6), &(v418_7_tail).make_space(), &(*s1));
              drop(v421_6);
              map_map_kernels::compose(&(v419_10),&(v421_11))
            };
            drop(v419_10);
            let v419_13: Space = map_map_kernels::unite(&(v419_8),&(v419_12));
            v418_7.join_into((v419_13).clone());
            }
            v418_7_cursor.ascend(1);
          }
          drop(v418_7_cursor);
          map_map_kernels::compose(&(v417_5),&(v418_7))
        };
        drop(v417_5);
        let v417_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v417_2));
        drop(v417_2);
        let v417_10: Space = if map_kernels::has_head(&(v417_9)) { singleton(&[]) } else { Space::new() };
        drop(v417_9);
        let v417_12: Space = if (v417_10).is_empty() { Space::new() } else {
          let v422_6: Path = concat_path(&(v416_6),&(v416_7_head));
          let mut v422_11 = Space::new();
          let mut v422_11_cursor = (v416_7_tail).read_zipper();
          for v422_11_byte in v422_11_cursor.child_mask().iter() {
            v422_11_cursor.descend_to_byte(v422_11_byte);
            {
            let v422_11_tail = v422_11_cursor.fork_read_zipper();
            let v422_11_head = Path::from_slice(&[v422_11_byte]);
            let v423_2: Space = singleton(&(v422_11_head));
            let v423_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v423_2));
            let v423_4: Space = if map_kernels::has_head(&(v423_3)) { singleton(&[]) } else { Space::new() };
            drop(v423_3);
            let v423_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v423_4));
            drop(v423_4);
            let v423_8: Space = if (v423_5).is_empty() { Space::new() } else {
              let v424_6: Path = concat_path(&(v422_6),&(v422_11_head));
              let v424_7: Space = routine_34(c, &(v424_6), &(v422_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v423_5),&(v424_7))
            };
            drop(v423_5);
            let v423_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v423_2));
            drop(v423_2);
            let v423_10: Space = if map_kernels::has_head(&(v423_9)) { singleton(&[]) } else { Space::new() };
            drop(v423_9);
            let v423_12: Space = if (v423_10).is_empty() { Space::new() } else {
              let v425_6: Path = concat_path(&(v422_6),&(v422_11_head));
              let v425_11: Space = routine_3(c, &(v425_6), &(v422_11_tail).make_space(), &(*s1));
              drop(v425_6);
              map_map_kernels::compose(&(v423_10),&(v425_11))
            };
            drop(v423_10);
            let v423_13: Space = map_map_kernels::unite(&(v423_8),&(v423_12));
            v422_11.join_into((v423_13).clone());
            }
            v422_11_cursor.ascend(1);
          }
          drop(v422_11_cursor);
          drop(v422_6);
          map_map_kernels::compose(&(v417_10),&(v422_11))
        };
        drop(v417_10);
        let v417_13: Space = map_map_kernels::unite(&(v417_8),&(v417_12));
        v416_7.join_into((v417_13).clone());
        }
        v416_7_cursor.ascend(1);
      }
      drop(v416_7_cursor);
      map_map_kernels::compose(&(v415_5),&(v416_7))
    };
    drop(v415_5);
    let v415_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v415_2));
    drop(v415_2);
    let v415_10: Space = if map_kernels::has_head(&(v415_9)) { singleton(&[]) } else { Space::new() };
    drop(v415_9);
    let v415_12: Space = if (v415_10).is_empty() { Space::new() } else {
      let v426_6: Path = concat_path(&(*p0),&(v414_24_head));
      let mut v426_11 = Space::new();
      let mut v426_11_cursor = (v414_24_tail).read_zipper();
      for v426_11_byte in v426_11_cursor.child_mask().iter() {
        v426_11_cursor.descend_to_byte(v426_11_byte);
        {
        let v426_11_tail = v426_11_cursor.fork_read_zipper();
        let v426_11_head = Path::from_slice(&[v426_11_byte]);
        let v427_2: Space = singleton(&(v426_11_head));
        let v427_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v427_2));
        let v427_4: Space = if map_kernels::has_head(&(v427_3)) { singleton(&[]) } else { Space::new() };
        drop(v427_3);
        let v427_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v427_4));
        drop(v427_4);
        let v427_7: Space = if (v427_5).is_empty() { Space::new() } else {
          let mut v428_6 = Space::new();
          let mut v428_6_cursor = (v426_11_tail).read_zipper();
          for v428_6_byte in v428_6_cursor.child_mask().iter() {
            v428_6_cursor.descend_to_byte(v428_6_byte);
            {
            let v428_6_tail = v428_6_cursor.fork_read_zipper();
            let v428_6_head = Path::from_slice(&[v428_6_byte]);
            let v429_2: Space = singleton(&(v428_6_head));
            let v429_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v429_2));
            let v429_4: Space = if map_kernels::has_head(&(v429_3)) { singleton(&[]) } else { Space::new() };
            drop(v429_3);
            let v429_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v429_4));
            drop(v429_4);
            let v429_8: Space = if (v429_5).is_empty() { Space::new() } else {
              let v430_6: Path = concat_path(&(v426_11_head),&(v428_6_head));
              let v430_7: Space = routine_8(c, &(v430_6), &(v426_6), &(v428_6_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v429_5),&(v430_7))
            };
            drop(v429_5);
            let v429_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v429_2));
            drop(v429_2);
            let v429_10: Space = if map_kernels::has_head(&(v429_9)) { singleton(&[]) } else { Space::new() };
            drop(v429_9);
            let v429_12: Space = if (v429_10).is_empty() { Space::new() } else {
              let v431_6: Path = concat_path(&(v426_11_head),&(v428_6_head));
              let v431_11: Space = routine_9(c, &(v431_6), &(v426_6), &(v428_6_tail).make_space(), &(*s1));
              drop(v431_6);
              map_map_kernels::compose(&(v429_10),&(v431_11))
            };
            drop(v429_10);
            let v429_13: Space = map_map_kernels::unite(&(v429_8),&(v429_12));
            v428_6.join_into((v429_13).clone());
            }
            v428_6_cursor.ascend(1);
          }
          drop(v428_6_cursor);
          map_map_kernels::compose(&(v427_5),&(v428_6))
        };
        drop(v427_5);
        let v427_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v427_2));
        drop(v427_2);
        let v427_9: Space = if map_kernels::has_head(&(v427_8)) { singleton(&[]) } else { Space::new() };
        drop(v427_8);
        let v427_11: Space = if (v427_9).is_empty() { Space::new() } else {
          let mut v432_10 = Space::new();
          let mut v432_10_cursor = (v426_11_tail).read_zipper();
          for v432_10_byte in v432_10_cursor.child_mask().iter() {
            v432_10_cursor.descend_to_byte(v432_10_byte);
            {
            let v432_10_tail = v432_10_cursor.fork_read_zipper();
            let v432_10_head = Path::from_slice(&[v432_10_byte]);
            let v433_2: Space = singleton(&(v432_10_head));
            let v433_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v433_2));
            let v433_4: Space = if map_kernels::has_head(&(v433_3)) { singleton(&[]) } else { Space::new() };
            drop(v433_3);
            let v433_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v433_4));
            drop(v433_4);
            let v433_8: Space = if (v433_5).is_empty() { Space::new() } else {
              let v434_6: Path = concat_path(&(v426_11_head),&(v432_10_head));
              let v434_7: Space = routine_8(c, &(v434_6), &(v426_6), &(v432_10_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v433_5),&(v434_7))
            };
            drop(v433_5);
            let v433_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v433_2));
            drop(v433_2);
            let v433_10: Space = if map_kernels::has_head(&(v433_9)) { singleton(&[]) } else { Space::new() };
            drop(v433_9);
            let v433_12: Space = if (v433_10).is_empty() { Space::new() } else {
              let v435_6: Path = concat_path(&(v426_11_head),&(v432_10_head));
              let v435_11: Space = routine_10(c, &(v435_6), &(v426_6), &(v432_10_tail).make_space(), &(*s1));
              drop(v435_6);
              map_map_kernels::compose(&(v433_10),&(v435_11))
            };
            drop(v433_10);
            let v433_13: Space = map_map_kernels::unite(&(v433_8),&(v433_12));
            v432_10.join_into((v433_13).clone());
            }
            v432_10_cursor.ascend(1);
          }
          drop(v432_10_cursor);
          map_map_kernels::compose(&(v427_9),&(v432_10))
        };
        drop(v427_9);
        let v427_12: Space = map_map_kernels::unite(&(v427_7),&(v427_11));
        v426_11.join_into((v427_12).clone());
        }
        v426_11_cursor.ascend(1);
      }
      drop(v426_11_cursor);
      drop(v426_6);
      map_map_kernels::compose(&(v415_10),&(v426_11))
    };
    drop(v415_10);
    let v415_13: Space = map_map_kernels::unite(&(v415_8),&(v415_12));
    v414_24.join_into((v415_13).clone());
    }
    v414_24_cursor.ascend(1);
  }
  drop(v414_24_cursor);
  (v414_24).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v436_20: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v436_21: Space = map_kernels::unwrap(&(v436_20),&(*p0));
  drop(v436_20);
  let mut v436_28 = Space::new();
  let mut v436_28_cursor = (*s0).read_zipper();
  for v436_28_byte in v436_28_cursor.child_mask().iter() {
    v436_28_cursor.descend_to_byte(v436_28_byte);
    {
    let v436_28_tail = v436_28_cursor.fork_read_zipper();
    let v436_28_head = Path::from_slice(&[v436_28_byte]);
    let v437_2: Space = singleton(&(v436_28_head));
    let v437_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v437_2));
    let v437_4: Space = if map_kernels::has_head(&(v437_3)) { singleton(&[]) } else { Space::new() };
    drop(v437_3);
    let v437_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v437_4));
    drop(v437_4);
    let v437_8: Space = if (v437_5).is_empty() { Space::new() } else {
      let v438_6: Path = concat_path(&(*p0),&(v436_28_head));
      let mut v438_7 = Space::new();
      let mut v438_7_cursor = (v436_28_tail).read_zipper();
      for v438_7_byte in v438_7_cursor.child_mask().iter() {
        v438_7_cursor.descend_to_byte(v438_7_byte);
        {
        let v438_7_tail = v438_7_cursor.fork_read_zipper();
        let v438_7_head = Path::from_slice(&[v438_7_byte]);
        let v439_2: Space = singleton(&(v438_7_head));
        let v439_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v439_2));
        let v439_4: Space = if map_kernels::has_head(&(v439_3)) { singleton(&[]) } else { Space::new() };
        drop(v439_3);
        let v439_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v439_4));
        drop(v439_4);
        let v439_8: Space = if (v439_5).is_empty() { Space::new() } else {
          let v440_6: Path = concat_path(&(v438_6),&(v438_7_head));
          let mut v440_7 = Space::new();
          let mut v440_7_cursor = (v438_7_tail).read_zipper();
          for v440_7_byte in v440_7_cursor.child_mask().iter() {
            v440_7_cursor.descend_to_byte(v440_7_byte);
            {
            let v440_7_tail = v440_7_cursor.fork_read_zipper();
            let v440_7_head = Path::from_slice(&[v440_7_byte]);
            let v441_2: Space = singleton(&(v440_7_head));
            let v441_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v441_2));
            let v441_4: Space = if map_kernels::has_head(&(v441_3)) { singleton(&[]) } else { Space::new() };
            drop(v441_3);
            let v441_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v441_4));
            drop(v441_4);
            let v441_8: Space = if (v441_5).is_empty() { Space::new() } else {
              let v442_6: Path = concat_path(&(v440_6),&(v440_7_head));
              let v442_7: Space = routine_36(c, &(v442_6), &(*p1), &(v440_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v441_5),&(v442_7))
            };
            drop(v441_5);
            let v441_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v441_2));
            drop(v441_2);
            let v441_10: Space = if map_kernels::has_head(&(v441_9)) { singleton(&[]) } else { Space::new() };
            drop(v441_9);
            let v441_12: Space = if (v441_10).is_empty() { Space::new() } else {
              let v443_6: Path = concat_path(&(v440_6),&(v440_7_head));
              let v443_11: Space = routine_37(c, &(v443_6), &(*p1), &(v440_7_tail).make_space(), &(*s1));
              drop(v443_6);
              map_map_kernels::compose(&(v441_10),&(v443_11))
            };
            drop(v441_10);
            let v441_13: Space = map_map_kernels::unite(&(v441_8),&(v441_12));
            v440_7.join_into((v441_13).clone());
            }
            v440_7_cursor.ascend(1);
          }
          drop(v440_7_cursor);
          map_map_kernels::compose(&(v439_5),&(v440_7))
        };
        drop(v439_5);
        let v439_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v439_2));
        drop(v439_2);
        let v439_10: Space = if map_kernels::has_head(&(v439_9)) { singleton(&[]) } else { Space::new() };
        drop(v439_9);
        let v439_12: Space = if (v439_10).is_empty() { Space::new() } else {
          let v444_6: Path = concat_path(&(v438_6),&(v438_7_head));
          let mut v444_11 = Space::new();
          let mut v444_11_cursor = (v438_7_tail).read_zipper();
          for v444_11_byte in v444_11_cursor.child_mask().iter() {
            v444_11_cursor.descend_to_byte(v444_11_byte);
            {
            let v444_11_tail = v444_11_cursor.fork_read_zipper();
            let v444_11_head = Path::from_slice(&[v444_11_byte]);
            let v445_2: Space = singleton(&(v444_11_head));
            let v445_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v445_2));
            let v445_4: Space = if map_kernels::has_head(&(v445_3)) { singleton(&[]) } else { Space::new() };
            drop(v445_3);
            let v445_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v445_4));
            drop(v445_4);
            let v445_8: Space = if (v445_5).is_empty() { Space::new() } else {
              let v446_6: Path = concat_path(&(v444_6),&(v444_11_head));
              let v446_7: Space = routine_36(c, &(v446_6), &(*p1), &(v444_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v445_5),&(v446_7))
            };
            drop(v445_5);
            let v445_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v445_2));
            drop(v445_2);
            let v445_10: Space = if map_kernels::has_head(&(v445_9)) { singleton(&[]) } else { Space::new() };
            drop(v445_9);
            let v445_12: Space = if (v445_10).is_empty() { Space::new() } else {
              let v447_6: Path = concat_path(&(v444_6),&(v444_11_head));
              let v447_11: Space = routine_10(c, &(v447_6), &(*p1), &(v444_11_tail).make_space(), &(*s1));
              drop(v447_6);
              map_map_kernels::compose(&(v445_10),&(v447_11))
            };
            drop(v445_10);
            let v445_13: Space = map_map_kernels::unite(&(v445_8),&(v445_12));
            v444_11.join_into((v445_13).clone());
            }
            v444_11_cursor.ascend(1);
          }
          drop(v444_11_cursor);
          drop(v444_6);
          map_map_kernels::compose(&(v439_10),&(v444_11))
        };
        drop(v439_10);
        let v439_13: Space = map_map_kernels::unite(&(v439_8),&(v439_12));
        v438_7.join_into((v439_13).clone());
        }
        v438_7_cursor.ascend(1);
      }
      drop(v438_7_cursor);
      map_map_kernels::compose(&(v437_5),&(v438_7))
    };
    drop(v437_5);
    let v437_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v437_2));
    drop(v437_2);
    let v437_10: Space = if map_kernels::has_head(&(v437_9)) { singleton(&[]) } else { Space::new() };
    drop(v437_9);
    let v437_13: Space = if (v437_10).is_empty() { Space::new() } else {
      let v448_6: Path = concat_path(&(*p0),&(v436_28_head));
      let v448_11: Space = map_kernels::unwrap(&(v436_21),&(v436_28_head));
      let mut v448_12 = Space::new();
      let mut v448_12_cursor = (v436_28_tail).read_zipper();
      for v448_12_byte in v448_12_cursor.child_mask().iter() {
        v448_12_cursor.descend_to_byte(v448_12_byte);
        {
        let v448_12_tail = v448_12_cursor.fork_read_zipper();
        let v448_12_head = Path::from_slice(&[v448_12_byte]);
        let v449_2: Space = singleton(&(v448_12_head));
        let v449_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v449_2));
        let v449_4: Space = if map_kernels::has_head(&(v449_3)) { singleton(&[]) } else { Space::new() };
        drop(v449_3);
        let v449_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v449_4));
        drop(v449_4);
        let v449_8: Space = if (v449_5).is_empty() { Space::new() } else {
          let v450_6: Path = concat_path(&(v448_6),&(v448_12_head));
          let mut v450_7 = Space::new();
          let mut v450_7_cursor = (v448_12_tail).read_zipper();
          for v450_7_byte in v450_7_cursor.child_mask().iter() {
            v450_7_cursor.descend_to_byte(v450_7_byte);
            {
            let v450_7_tail = v450_7_cursor.fork_read_zipper();
            let v450_7_head = Path::from_slice(&[v450_7_byte]);
            let v451_2: Space = singleton(&(v450_7_head));
            let v451_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v451_2));
            let v451_4: Space = if map_kernels::has_head(&(v451_3)) { singleton(&[]) } else { Space::new() };
            drop(v451_3);
            let v451_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v451_4));
            drop(v451_4);
            let v451_8: Space = if (v451_5).is_empty() { Space::new() } else {
              let v452_6: Path = concat_path(&(v450_6),&(v450_7_head));
              let v452_7: Space = routine_36(c, &(v452_6), &(*p1), &(v450_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v451_5),&(v452_7))
            };
            drop(v451_5);
            let v451_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v451_2));
            drop(v451_2);
            let v451_10: Space = if map_kernels::has_head(&(v451_9)) { singleton(&[]) } else { Space::new() };
            drop(v451_9);
            let v451_12: Space = if (v451_10).is_empty() { Space::new() } else {
              let v453_6: Path = concat_path(&(v450_6),&(v450_7_head));
              let v453_11: Space = routine_37(c, &(v453_6), &(*p1), &(v450_7_tail).make_space(), &(*s1));
              drop(v453_6);
              map_map_kernels::compose(&(v451_10),&(v453_11))
            };
            drop(v451_10);
            let v451_13: Space = map_map_kernels::unite(&(v451_8),&(v451_12));
            v450_7.join_into((v451_13).clone());
            }
            v450_7_cursor.ascend(1);
          }
          drop(v450_7_cursor);
          drop(v450_6);
          map_map_kernels::compose(&(v449_5),&(v450_7))
        };
        drop(v449_5);
        let v449_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v449_2));
        drop(v449_2);
        let v449_10: Space = if map_kernels::has_head(&(v449_9)) { singleton(&[]) } else { Space::new() };
        drop(v449_9);
        let v449_13: Space = if (v449_10).is_empty() { Space::new() } else {
          let v454_11: Space = map_kernels::unwrap(&(v448_11),&(v448_12_head));
          let mut v454_12 = Space::new();
          let mut v454_12_cursor = (v454_11).read_zipper();
          for v454_12_byte in v454_12_cursor.child_mask().iter() {
            v454_12_cursor.descend_to_byte(v454_12_byte);
            {
            let v454_12_tail = v454_12_cursor.fork_read_zipper();
            let v454_12_head = Path::from_slice(&[v454_12_byte]);
            let v455_2: Space = singleton(&(v454_12_head));
            let v455_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v455_2));
            let v455_4: Space = if map_kernels::has_head(&(v455_3)) { singleton(&[]) } else { Space::new() };
            drop(v455_3);
            let v455_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v455_4));
            drop(v455_4);
            let v455_7: Space = if (v455_5).is_empty() { Space::new() } else {
              let v456_6: Space = routine_13(c, &(v454_12_head), &(*p1), &(v454_12_tail).make_space());
              map_map_kernels::compose(&(v455_5),&(v456_6))
            };
            drop(v455_5);
            let v455_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v455_2));
            drop(v455_2);
            let v455_9: Space = if map_kernels::has_head(&(v455_8)) { singleton(&[]) } else { Space::new() };
            drop(v455_8);
            let v455_11: Space = if (v455_9).is_empty() { Space::new() } else {
              let v457_10: Space = routine_14(c, &(v454_12_head), &(*p1), &(v454_12_tail).make_space());
              map_map_kernels::compose(&(v455_9),&(v457_10))
            };
            drop(v455_9);
            let v455_12: Space = map_map_kernels::unite(&(v455_7),&(v455_11));
            v454_12.join_into((v455_12).clone());
            }
            v454_12_cursor.ascend(1);
          }
          drop(v454_12_cursor);
          drop(v454_11);
          map_map_kernels::compose(&(v449_10),&(v454_12))
        };
        drop(v449_10);
        let v449_14: Space = map_map_kernels::unite(&(v449_8),&(v449_13));
        v448_12.join_into((v449_14).clone());
        }
        v448_12_cursor.ascend(1);
      }
      drop(v448_12_cursor);
      drop(v448_6);
      drop(v448_11);
      map_map_kernels::compose(&(v437_10),&(v448_12))
    };
    drop(v437_10);
    let v437_14: Space = map_map_kernels::unite(&(v437_8),&(v437_13));
    v436_28.join_into((v437_14).clone());
    }
    v436_28_cursor.ascend(1);
  }
  drop(v436_28_cursor);
  drop(v436_21);
  (v436_28).clone()
}

fn routine_23(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v458_8: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v458_9: Space = map_kernels::unwrap(&(v458_8),&(*p0));
  drop(v458_8);
  let mut v458_28 = Space::new();
  let mut v458_28_cursor = (*s0).read_zipper();
  for v458_28_byte in v458_28_cursor.child_mask().iter() {
    v458_28_cursor.descend_to_byte(v458_28_byte);
    {
    let v458_28_tail = v458_28_cursor.fork_read_zipper();
    let v458_28_head = Path::from_slice(&[v458_28_byte]);
    let v459_2: Space = singleton(&(v458_28_head));
    let v459_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v459_2));
    let v459_4: Space = if map_kernels::has_head(&(v459_3)) { singleton(&[]) } else { Space::new() };
    drop(v459_3);
    let v459_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v459_4));
    drop(v459_4);
    let v459_8: Space = if (v459_5).is_empty() { Space::new() } else {
      let v460_6: Path = concat_path(&(*p0),&(v458_28_head));
      let mut v460_7 = Space::new();
      let mut v460_7_cursor = (v458_28_tail).read_zipper();
      for v460_7_byte in v460_7_cursor.child_mask().iter() {
        v460_7_cursor.descend_to_byte(v460_7_byte);
        {
        let v460_7_tail = v460_7_cursor.fork_read_zipper();
        let v460_7_head = Path::from_slice(&[v460_7_byte]);
        let v461_2: Space = singleton(&(v460_7_head));
        let v461_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v461_2));
        let v461_4: Space = if map_kernels::has_head(&(v461_3)) { singleton(&[]) } else { Space::new() };
        drop(v461_3);
        let v461_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v461_4));
        drop(v461_4);
        let v461_8: Space = if (v461_5).is_empty() { Space::new() } else {
          let v462_6: Path = concat_path(&(v460_6),&(v460_7_head));
          let mut v462_7 = Space::new();
          let mut v462_7_cursor = (v460_7_tail).read_zipper();
          for v462_7_byte in v462_7_cursor.child_mask().iter() {
            v462_7_cursor.descend_to_byte(v462_7_byte);
            {
            let v462_7_tail = v462_7_cursor.fork_read_zipper();
            let v462_7_head = Path::from_slice(&[v462_7_byte]);
            let v463_2: Space = singleton(&(v462_7_head));
            let v463_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v463_2));
            let v463_4: Space = if map_kernels::has_head(&(v463_3)) { singleton(&[]) } else { Space::new() };
            drop(v463_3);
            let v463_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v463_4));
            drop(v463_4);
            let v463_8: Space = if (v463_5).is_empty() { Space::new() } else {
              let v464_6: Path = concat_path(&(v462_6),&(v462_7_head));
              let v464_7: Space = routine_36(c, &(v464_6), &(*p1), &(v462_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v463_5),&(v464_7))
            };
            drop(v463_5);
            let v463_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v463_2));
            drop(v463_2);
            let v463_10: Space = if map_kernels::has_head(&(v463_9)) { singleton(&[]) } else { Space::new() };
            drop(v463_9);
            let v463_12: Space = if (v463_10).is_empty() { Space::new() } else {
              let v465_6: Path = concat_path(&(v462_6),&(v462_7_head));
              let v465_11: Space = routine_37(c, &(v465_6), &(*p1), &(v462_7_tail).make_space(), &(*s1));
              drop(v465_6);
              map_map_kernels::compose(&(v463_10),&(v465_11))
            };
            drop(v463_10);
            let v463_13: Space = map_map_kernels::unite(&(v463_8),&(v463_12));
            v462_7.join_into((v463_13).clone());
            }
            v462_7_cursor.ascend(1);
          }
          drop(v462_7_cursor);
          map_map_kernels::compose(&(v461_5),&(v462_7))
        };
        drop(v461_5);
        let v461_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v461_2));
        drop(v461_2);
        let v461_10: Space = if map_kernels::has_head(&(v461_9)) { singleton(&[]) } else { Space::new() };
        drop(v461_9);
        let v461_12: Space = if (v461_10).is_empty() { Space::new() } else {
          let v466_6: Path = concat_path(&(v460_6),&(v460_7_head));
          let mut v466_11 = Space::new();
          let mut v466_11_cursor = (v460_7_tail).read_zipper();
          for v466_11_byte in v466_11_cursor.child_mask().iter() {
            v466_11_cursor.descend_to_byte(v466_11_byte);
            {
            let v466_11_tail = v466_11_cursor.fork_read_zipper();
            let v466_11_head = Path::from_slice(&[v466_11_byte]);
            let v467_2: Space = singleton(&(v466_11_head));
            let v467_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v467_2));
            let v467_4: Space = if map_kernels::has_head(&(v467_3)) { singleton(&[]) } else { Space::new() };
            drop(v467_3);
            let v467_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v467_4));
            drop(v467_4);
            let v467_8: Space = if (v467_5).is_empty() { Space::new() } else {
              let v468_6: Path = concat_path(&(v466_6),&(v466_11_head));
              let v468_7: Space = routine_36(c, &(v468_6), &(*p1), &(v466_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v467_5),&(v468_7))
            };
            drop(v467_5);
            let v467_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v467_2));
            drop(v467_2);
            let v467_10: Space = if map_kernels::has_head(&(v467_9)) { singleton(&[]) } else { Space::new() };
            drop(v467_9);
            let v467_12: Space = if (v467_10).is_empty() { Space::new() } else {
              let v469_6: Path = concat_path(&(v466_6),&(v466_11_head));
              let v469_11: Space = routine_10(c, &(v469_6), &(*p1), &(v466_11_tail).make_space(), &(*s1));
              drop(v469_6);
              map_map_kernels::compose(&(v467_10),&(v469_11))
            };
            drop(v467_10);
            let v467_13: Space = map_map_kernels::unite(&(v467_8),&(v467_12));
            v466_11.join_into((v467_13).clone());
            }
            v466_11_cursor.ascend(1);
          }
          drop(v466_11_cursor);
          drop(v466_6);
          map_map_kernels::compose(&(v461_10),&(v466_11))
        };
        drop(v461_10);
        let v461_13: Space = map_map_kernels::unite(&(v461_8),&(v461_12));
        v460_7.join_into((v461_13).clone());
        }
        v460_7_cursor.ascend(1);
      }
      drop(v460_7_cursor);
      drop(v460_6);
      map_map_kernels::compose(&(v459_5),&(v460_7))
    };
    drop(v459_5);
    let v459_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v459_2));
    drop(v459_2);
    let v459_10: Space = if map_kernels::has_head(&(v459_9)) { singleton(&[]) } else { Space::new() };
    drop(v459_9);
    let v459_13: Space = if (v459_10).is_empty() { Space::new() } else {
      let v470_11: Space = map_kernels::unwrap(&(v458_9),&(v458_28_head));
      let mut v470_12 = Space::new();
      let mut v470_12_cursor = (v470_11).read_zipper();
      for v470_12_byte in v470_12_cursor.child_mask().iter() {
        v470_12_cursor.descend_to_byte(v470_12_byte);
        {
        let v470_12_tail = v470_12_cursor.fork_read_zipper();
        let v470_12_head = Path::from_slice(&[v470_12_byte]);
        let v471_2: Space = singleton(&(v470_12_head));
        let v471_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v471_2));
        let v471_4: Space = if map_kernels::has_head(&(v471_3)) { singleton(&[]) } else { Space::new() };
        drop(v471_3);
        let v471_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v471_4));
        drop(v471_4);
        let v471_7: Space = if (v471_5).is_empty() { Space::new() } else {
          let mut v472_6 = Space::new();
          let mut v472_6_cursor = (v470_12_tail).read_zipper();
          for v472_6_byte in v472_6_cursor.child_mask().iter() {
            v472_6_cursor.descend_to_byte(v472_6_byte);
            {
            let v472_6_tail = v472_6_cursor.fork_read_zipper();
            let v472_6_head = Path::from_slice(&[v472_6_byte]);
            let v473_2: Space = singleton(&(v472_6_head));
            let v473_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v473_2));
            let v473_4: Space = if map_kernels::has_head(&(v473_3)) { singleton(&[]) } else { Space::new() };
            drop(v473_3);
            let v473_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v473_4));
            drop(v473_4);
            let v473_8: Space = if (v473_5).is_empty() { Space::new() } else {
              let v474_6: Path = concat_path(&(v470_12_head),&(v472_6_head));
              let v474_7: Space = routine_17(c, &(v474_6), &(*p1), &(v472_6_tail).make_space());
              map_map_kernels::compose(&(v473_5),&(v474_7))
            };
            drop(v473_5);
            let v473_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v473_2));
            drop(v473_2);
            let v473_10: Space = if map_kernels::has_head(&(v473_9)) { singleton(&[]) } else { Space::new() };
            drop(v473_9);
            let v473_12: Space = if (v473_10).is_empty() { Space::new() } else {
              let v475_6: Path = concat_path(&(v470_12_head),&(v472_6_head));
              let v475_11: Space = routine_18(c, &(v475_6), &(*p1), &(v472_6_tail).make_space());
              drop(v475_6);
              map_map_kernels::compose(&(v473_10),&(v475_11))
            };
            drop(v473_10);
            let v473_13: Space = map_map_kernels::unite(&(v473_8),&(v473_12));
            v472_6.join_into((v473_13).clone());
            }
            v472_6_cursor.ascend(1);
          }
          drop(v472_6_cursor);
          map_map_kernels::compose(&(v471_5),&(v472_6))
        };
        drop(v471_5);
        let v471_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v471_2));
        drop(v471_2);
        let v471_9: Space = if map_kernels::has_head(&(v471_8)) { singleton(&[]) } else { Space::new() };
        drop(v471_8);
        let v471_11: Space = if (v471_9).is_empty() { Space::new() } else {
          let mut v476_10 = Space::new();
          let mut v476_10_cursor = (v470_12_tail).read_zipper();
          for v476_10_byte in v476_10_cursor.child_mask().iter() {
            v476_10_cursor.descend_to_byte(v476_10_byte);
            {
            let v476_10_tail = v476_10_cursor.fork_read_zipper();
            let v476_10_head = Path::from_slice(&[v476_10_byte]);
            let v477_2: Space = singleton(&(v476_10_head));
            let v477_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v477_2));
            let v477_4: Space = if map_kernels::has_head(&(v477_3)) { singleton(&[]) } else { Space::new() };
            drop(v477_3);
            let v477_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v477_4));
            drop(v477_4);
            let v477_8: Space = if (v477_5).is_empty() { Space::new() } else {
              let v478_6: Path = concat_path(&(v470_12_head),&(v476_10_head));
              let v478_7: Space = routine_17(c, &(v478_6), &(*p1), &(v476_10_tail).make_space());
              map_map_kernels::compose(&(v477_5),&(v478_7))
            };
            drop(v477_5);
            let v477_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v477_2));
            drop(v477_2);
            let v477_10: Space = if map_kernels::has_head(&(v477_9)) { singleton(&[]) } else { Space::new() };
            drop(v477_9);
            let v477_12: Space = if (v477_10).is_empty() { Space::new() } else {
              let v479_6: Path = concat_path(&(v470_12_head),&(v476_10_head));
              let v479_11: Space = routine_19(c, &(v479_6), &(*p1), &(v476_10_tail).make_space());
              drop(v479_6);
              map_map_kernels::compose(&(v477_10),&(v479_11))
            };
            drop(v477_10);
            let v477_13: Space = map_map_kernels::unite(&(v477_8),&(v477_12));
            v476_10.join_into((v477_13).clone());
            }
            v476_10_cursor.ascend(1);
          }
          drop(v476_10_cursor);
          map_map_kernels::compose(&(v471_9),&(v476_10))
        };
        drop(v471_9);
        let v471_12: Space = map_map_kernels::unite(&(v471_7),&(v471_11));
        v470_12.join_into((v471_12).clone());
        }
        v470_12_cursor.ascend(1);
      }
      drop(v470_12_cursor);
      drop(v470_11);
      map_map_kernels::compose(&(v459_10),&(v470_12))
    };
    drop(v459_10);
    let v459_14: Space = map_map_kernels::unite(&(v459_8),&(v459_13));
    v458_28.join_into((v459_14).clone());
    }
    v458_28_cursor.ascend(1);
  }
  drop(v458_28_cursor);
  drop(v458_9);
  (v458_28).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v480_21 = Space::new();
  let mut v480_21_cursor = (*s0).read_zipper();
  for v480_21_byte in v480_21_cursor.child_mask().iter() {
    v480_21_cursor.descend_to_byte(v480_21_byte);
    {
    let v480_21_tail = v480_21_cursor.fork_read_zipper();
    let v480_21_head = Path::from_slice(&[v480_21_byte]);
    let v481_2: Space = singleton(&(v480_21_head));
    let v481_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v481_2));
    let v481_4: Space = if map_kernels::has_head(&(v481_3)) { singleton(&[]) } else { Space::new() };
    drop(v481_3);
    let v481_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v481_4));
    drop(v481_4);
    let v481_8: Space = if (v481_5).is_empty() { Space::new() } else {
      let v482_6: Path = concat_path(&(*p0),&(v480_21_head));
      let mut v482_7 = Space::new();
      let mut v482_7_cursor = (v480_21_tail).read_zipper();
      for v482_7_byte in v482_7_cursor.child_mask().iter() {
        v482_7_cursor.descend_to_byte(v482_7_byte);
        {
        let v482_7_tail = v482_7_cursor.fork_read_zipper();
        let v482_7_head = Path::from_slice(&[v482_7_byte]);
        let v483_2: Space = singleton(&(v482_7_head));
        let v483_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v483_2));
        let v483_4: Space = if map_kernels::has_head(&(v483_3)) { singleton(&[]) } else { Space::new() };
        drop(v483_3);
        let v483_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v483_4));
        drop(v483_4);
        let v483_8: Space = if (v483_5).is_empty() { Space::new() } else {
          let v484_6: Path = concat_path(&(v482_6),&(v482_7_head));
          let mut v484_7 = Space::new();
          let mut v484_7_cursor = (v482_7_tail).read_zipper();
          for v484_7_byte in v484_7_cursor.child_mask().iter() {
            v484_7_cursor.descend_to_byte(v484_7_byte);
            {
            let v484_7_tail = v484_7_cursor.fork_read_zipper();
            let v484_7_head = Path::from_slice(&[v484_7_byte]);
            let v485_2: Space = singleton(&(v484_7_head));
            let v485_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v485_2));
            let v485_4: Space = if map_kernels::has_head(&(v485_3)) { singleton(&[]) } else { Space::new() };
            drop(v485_3);
            let v485_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v485_4));
            drop(v485_4);
            let v485_8: Space = if (v485_5).is_empty() { Space::new() } else {
              let v486_6: Path = concat_path(&(v484_6),&(v484_7_head));
              let v486_7: Space = routine_38(c, &(v486_6), &(*p1), &(v484_7_tail).make_space());
              map_map_kernels::compose(&(v485_5),&(v486_7))
            };
            drop(v485_5);
            let v485_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v485_2));
            drop(v485_2);
            let v485_10: Space = if map_kernels::has_head(&(v485_9)) { singleton(&[]) } else { Space::new() };
            drop(v485_9);
            let v485_12: Space = if (v485_10).is_empty() { Space::new() } else {
              let v487_6: Path = concat_path(&(v484_6),&(v484_7_head));
              let v487_11: Space = routine_39(c, &(v487_6), &(*p1), &(v484_7_tail).make_space());
              drop(v487_6);
              map_map_kernels::compose(&(v485_10),&(v487_11))
            };
            drop(v485_10);
            let v485_13: Space = map_map_kernels::unite(&(v485_8),&(v485_12));
            v484_7.join_into((v485_13).clone());
            }
            v484_7_cursor.ascend(1);
          }
          drop(v484_7_cursor);
          map_map_kernels::compose(&(v483_5),&(v484_7))
        };
        drop(v483_5);
        let v483_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v483_2));
        drop(v483_2);
        let v483_10: Space = if map_kernels::has_head(&(v483_9)) { singleton(&[]) } else { Space::new() };
        drop(v483_9);
        let v483_12: Space = if (v483_10).is_empty() { Space::new() } else {
          let v488_6: Path = concat_path(&(v482_6),&(v482_7_head));
          let mut v488_11 = Space::new();
          let mut v488_11_cursor = (v482_7_tail).read_zipper();
          for v488_11_byte in v488_11_cursor.child_mask().iter() {
            v488_11_cursor.descend_to_byte(v488_11_byte);
            {
            let v488_11_tail = v488_11_cursor.fork_read_zipper();
            let v488_11_head = Path::from_slice(&[v488_11_byte]);
            let v489_2: Space = singleton(&(v488_11_head));
            let v489_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v489_2));
            let v489_4: Space = if map_kernels::has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
            drop(v489_3);
            let v489_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v489_4));
            drop(v489_4);
            let v489_8: Space = if (v489_5).is_empty() { Space::new() } else {
              let v490_6: Path = concat_path(&(v488_6),&(v488_11_head));
              let v490_7: Space = routine_38(c, &(v490_6), &(*p1), &(v488_11_tail).make_space());
              map_map_kernels::compose(&(v489_5),&(v490_7))
            };
            drop(v489_5);
            let v489_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v489_2));
            drop(v489_2);
            let v489_10: Space = if map_kernels::has_head(&(v489_9)) { singleton(&[]) } else { Space::new() };
            drop(v489_9);
            let v489_12: Space = if (v489_10).is_empty() { Space::new() } else {
              let v491_6: Path = concat_path(&(v488_6),&(v488_11_head));
              let v491_11: Space = routine_19(c, &(v491_6), &(*p1), &(v488_11_tail).make_space());
              drop(v491_6);
              map_map_kernels::compose(&(v489_10),&(v491_11))
            };
            drop(v489_10);
            let v489_13: Space = map_map_kernels::unite(&(v489_8),&(v489_12));
            v488_11.join_into((v489_13).clone());
            }
            v488_11_cursor.ascend(1);
          }
          drop(v488_11_cursor);
          drop(v488_6);
          map_map_kernels::compose(&(v483_10),&(v488_11))
        };
        drop(v483_10);
        let v483_13: Space = map_map_kernels::unite(&(v483_8),&(v483_12));
        v482_7.join_into((v483_13).clone());
        }
        v482_7_cursor.ascend(1);
      }
      drop(v482_7_cursor);
      map_map_kernels::compose(&(v481_5),&(v482_7))
    };
    drop(v481_5);
    let v481_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v481_2));
    drop(v481_2);
    let v481_10: Space = if map_kernels::has_head(&(v481_9)) { singleton(&[]) } else { Space::new() };
    drop(v481_9);
    let v481_12: Space = if (v481_10).is_empty() { Space::new() } else {
      let v492_6: Path = concat_path(&(*p0),&(v480_21_head));
      let mut v492_11 = Space::new();
      let mut v492_11_cursor = (v480_21_tail).read_zipper();
      for v492_11_byte in v492_11_cursor.child_mask().iter() {
        v492_11_cursor.descend_to_byte(v492_11_byte);
        {
        let v492_11_tail = v492_11_cursor.fork_read_zipper();
        let v492_11_head = Path::from_slice(&[v492_11_byte]);
        let v493_2: Space = singleton(&(v492_11_head));
        let v493_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v493_2));
        let v493_4: Space = if map_kernels::has_head(&(v493_3)) { singleton(&[]) } else { Space::new() };
        drop(v493_3);
        let v493_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v493_4));
        drop(v493_4);
        let v493_8: Space = if (v493_5).is_empty() { Space::new() } else {
          let v494_6: Path = concat_path(&(v492_6),&(v492_11_head));
          let mut v494_7 = Space::new();
          let mut v494_7_cursor = (v492_11_tail).read_zipper();
          for v494_7_byte in v494_7_cursor.child_mask().iter() {
            v494_7_cursor.descend_to_byte(v494_7_byte);
            {
            let v494_7_tail = v494_7_cursor.fork_read_zipper();
            let v494_7_head = Path::from_slice(&[v494_7_byte]);
            let v495_2: Space = singleton(&(v494_7_head));
            let v495_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v495_2));
            let v495_4: Space = if map_kernels::has_head(&(v495_3)) { singleton(&[]) } else { Space::new() };
            drop(v495_3);
            let v495_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v495_4));
            drop(v495_4);
            let v495_8: Space = if (v495_5).is_empty() { Space::new() } else {
              let v496_6: Path = concat_path(&(v494_6),&(v494_7_head));
              let v496_7: Space = routine_38(c, &(v496_6), &(*p1), &(v494_7_tail).make_space());
              map_map_kernels::compose(&(v495_5),&(v496_7))
            };
            drop(v495_5);
            let v495_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v495_2));
            drop(v495_2);
            let v495_10: Space = if map_kernels::has_head(&(v495_9)) { singleton(&[]) } else { Space::new() };
            drop(v495_9);
            let v495_12: Space = if (v495_10).is_empty() { Space::new() } else {
              let v497_6: Path = concat_path(&(v494_6),&(v494_7_head));
              let v497_11: Space = routine_39(c, &(v497_6), &(*p1), &(v494_7_tail).make_space());
              drop(v497_6);
              map_map_kernels::compose(&(v495_10),&(v497_11))
            };
            drop(v495_10);
            let v495_13: Space = map_map_kernels::unite(&(v495_8),&(v495_12));
            v494_7.join_into((v495_13).clone());
            }
            v494_7_cursor.ascend(1);
          }
          drop(v494_7_cursor);
          map_map_kernels::compose(&(v493_5),&(v494_7))
        };
        drop(v493_5);
        let v493_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v493_2));
        drop(v493_2);
        let v493_10: Space = if map_kernels::has_head(&(v493_9)) { singleton(&[]) } else { Space::new() };
        drop(v493_9);
        let v493_11: Space = map_view_kernels::compose(&(v493_10),&(v492_11_tail));
        drop(v493_10);
        let v498_6: Path = concat_path(&(v492_6),&(v492_11_head));
        let v493_12: Space = map_kernels::wrap(&(v493_11),&(v498_6));
        drop(v493_11);
        let v493_13: Space = map_kernels::wrap(&(v493_12),&(*p1));
        drop(v493_12);
        let v493_14: Space = map_map_kernels::unite(&(v493_8),&(v493_13));
        drop(v493_13);
        v492_11.join_into((v493_14).clone());
        }
        v492_11_cursor.ascend(1);
      }
      drop(v492_11_cursor);
      drop(v492_6);
      map_map_kernels::compose(&(v481_10),&(v492_11))
    };
    drop(v481_10);
    let v481_13: Space = map_map_kernels::unite(&(v481_8),&(v481_12));
    v480_21.join_into((v481_13).clone());
    }
    v480_21_cursor.ascend(1);
  }
  drop(v480_21_cursor);
  (v480_21).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v499_15 = Space::new();
  let mut v499_15_cursor = (*s0).read_zipper();
  for v499_15_byte in v499_15_cursor.child_mask().iter() {
    v499_15_cursor.descend_to_byte(v499_15_byte);
    {
    let v499_15_tail = v499_15_cursor.fork_read_zipper();
    let v499_15_head = Path::from_slice(&[v499_15_byte]);
    let v500_2: Space = singleton(&(v499_15_head));
    let v500_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v500_2));
    let v500_4: Space = if map_kernels::has_head(&(v500_3)) { singleton(&[]) } else { Space::new() };
    drop(v500_3);
    let v500_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v500_4));
    drop(v500_4);
    let v500_8: Space = if (v500_5).is_empty() { Space::new() } else {
      let v501_6: Path = concat_path(&(*p0),&(v499_15_head));
      let mut v501_7 = Space::new();
      let mut v501_7_cursor = (v499_15_tail).read_zipper();
      for v501_7_byte in v501_7_cursor.child_mask().iter() {
        v501_7_cursor.descend_to_byte(v501_7_byte);
        {
        let v501_7_tail = v501_7_cursor.fork_read_zipper();
        let v501_7_head = Path::from_slice(&[v501_7_byte]);
        let v502_2: Space = singleton(&(v501_7_head));
        let v502_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v502_2));
        let v502_4: Space = if map_kernels::has_head(&(v502_3)) { singleton(&[]) } else { Space::new() };
        drop(v502_3);
        let v502_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v502_4));
        drop(v502_4);
        let v502_8: Space = if (v502_5).is_empty() { Space::new() } else {
          let v503_6: Path = concat_path(&(v501_6),&(v501_7_head));
          let mut v503_7 = Space::new();
          let mut v503_7_cursor = (v501_7_tail).read_zipper();
          for v503_7_byte in v503_7_cursor.child_mask().iter() {
            v503_7_cursor.descend_to_byte(v503_7_byte);
            {
            let v503_7_tail = v503_7_cursor.fork_read_zipper();
            let v503_7_head = Path::from_slice(&[v503_7_byte]);
            let v504_2: Space = singleton(&(v503_7_head));
            let v504_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v504_2));
            let v504_4: Space = if map_kernels::has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
            drop(v504_3);
            let v504_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v504_4));
            drop(v504_4);
            let v504_8: Space = if (v504_5).is_empty() { Space::new() } else {
              let v505_6: Path = concat_path(&(v503_6),&(v503_7_head));
              let v505_7: Space = routine_38(c, &(v505_6), &(*p1), &(v503_7_tail).make_space());
              map_map_kernels::compose(&(v504_5),&(v505_7))
            };
            drop(v504_5);
            let v504_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v504_2));
            drop(v504_2);
            let v504_10: Space = if map_kernels::has_head(&(v504_9)) { singleton(&[]) } else { Space::new() };
            drop(v504_9);
            let v504_12: Space = if (v504_10).is_empty() { Space::new() } else {
              let v506_6: Path = concat_path(&(v503_6),&(v503_7_head));
              let v506_11: Space = routine_39(c, &(v506_6), &(*p1), &(v503_7_tail).make_space());
              drop(v506_6);
              map_map_kernels::compose(&(v504_10),&(v506_11))
            };
            drop(v504_10);
            let v504_13: Space = map_map_kernels::unite(&(v504_8),&(v504_12));
            v503_7.join_into((v504_13).clone());
            }
            v503_7_cursor.ascend(1);
          }
          drop(v503_7_cursor);
          map_map_kernels::compose(&(v502_5),&(v503_7))
        };
        drop(v502_5);
        let v502_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v502_2));
        drop(v502_2);
        let v502_10: Space = if map_kernels::has_head(&(v502_9)) { singleton(&[]) } else { Space::new() };
        drop(v502_9);
        let v502_12: Space = if (v502_10).is_empty() { Space::new() } else {
          let v507_6: Path = concat_path(&(v501_6),&(v501_7_head));
          let mut v507_11 = Space::new();
          let mut v507_11_cursor = (v501_7_tail).read_zipper();
          for v507_11_byte in v507_11_cursor.child_mask().iter() {
            v507_11_cursor.descend_to_byte(v507_11_byte);
            {
            let v507_11_tail = v507_11_cursor.fork_read_zipper();
            let v507_11_head = Path::from_slice(&[v507_11_byte]);
            let v508_2: Space = singleton(&(v507_11_head));
            let v508_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v508_2));
            let v508_4: Space = if map_kernels::has_head(&(v508_3)) { singleton(&[]) } else { Space::new() };
            drop(v508_3);
            let v508_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v508_4));
            drop(v508_4);
            let v508_8: Space = if (v508_5).is_empty() { Space::new() } else {
              let v509_6: Path = concat_path(&(v507_6),&(v507_11_head));
              let v509_7: Space = routine_38(c, &(v509_6), &(*p1), &(v507_11_tail).make_space());
              map_map_kernels::compose(&(v508_5),&(v509_7))
            };
            drop(v508_5);
            let v508_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v508_2));
            drop(v508_2);
            let v508_10: Space = if map_kernels::has_head(&(v508_9)) { singleton(&[]) } else { Space::new() };
            drop(v508_9);
            let v508_12: Space = if (v508_10).is_empty() { Space::new() } else {
              let v510_6: Path = concat_path(&(v507_6),&(v507_11_head));
              let v510_11: Space = routine_19(c, &(v510_6), &(*p1), &(v507_11_tail).make_space());
              drop(v510_6);
              map_map_kernels::compose(&(v508_10),&(v510_11))
            };
            drop(v508_10);
            let v508_13: Space = map_map_kernels::unite(&(v508_8),&(v508_12));
            v507_11.join_into((v508_13).clone());
            }
            v507_11_cursor.ascend(1);
          }
          drop(v507_11_cursor);
          drop(v507_6);
          map_map_kernels::compose(&(v502_10),&(v507_11))
        };
        drop(v502_10);
        let v502_13: Space = map_map_kernels::unite(&(v502_8),&(v502_12));
        v501_7.join_into((v502_13).clone());
        }
        v501_7_cursor.ascend(1);
      }
      drop(v501_7_cursor);
      map_map_kernels::compose(&(v500_5),&(v501_7))
    };
    drop(v500_5);
    let v500_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v500_2));
    drop(v500_2);
    let v500_10: Space = if map_kernels::has_head(&(v500_9)) { singleton(&[]) } else { Space::new() };
    drop(v500_9);
    let v500_11: Space = map_view_kernels::compose(&(v500_10),&(v499_15_tail));
    drop(v500_10);
    let v511_6: Path = concat_path(&(*p0),&(v499_15_head));
    let v500_12: Space = map_kernels::wrap(&(v500_11),&(v511_6));
    drop(v500_11);
    let v500_13: Space = map_kernels::wrap(&(v500_12),&(*p1));
    drop(v500_12);
    let v500_14: Space = map_map_kernels::unite(&(v500_8),&(v500_13));
    drop(v500_13);
    v499_15.join_into((v500_14).clone());
    }
    v499_15_cursor.ascend(1);
  }
  drop(v499_15_cursor);
  (v499_15).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v512_20: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v512_21: Space = map_kernels::unwrap(&(v512_20),&(*p0));
  drop(v512_20);
  let mut v512_28 = Space::new();
  let mut v512_28_cursor = (*s0).read_zipper();
  for v512_28_byte in v512_28_cursor.child_mask().iter() {
    v512_28_cursor.descend_to_byte(v512_28_byte);
    {
    let v512_28_tail = v512_28_cursor.fork_read_zipper();
    let v512_28_head = Path::from_slice(&[v512_28_byte]);
    let v513_2: Space = singleton(&(v512_28_head));
    let v513_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v513_2));
    let v513_4: Space = if map_kernels::has_head(&(v513_3)) { singleton(&[]) } else { Space::new() };
    drop(v513_3);
    let v513_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v513_4));
    drop(v513_4);
    let v513_8: Space = if (v513_5).is_empty() { Space::new() } else {
      let v514_6: Path = concat_path(&(*p0),&(v512_28_head));
      let mut v514_7 = Space::new();
      let mut v514_7_cursor = (v512_28_tail).read_zipper();
      for v514_7_byte in v514_7_cursor.child_mask().iter() {
        v514_7_cursor.descend_to_byte(v514_7_byte);
        {
        let v514_7_tail = v514_7_cursor.fork_read_zipper();
        let v514_7_head = Path::from_slice(&[v514_7_byte]);
        let v515_2: Space = singleton(&(v514_7_head));
        let v515_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v515_2));
        let v515_4: Space = if map_kernels::has_head(&(v515_3)) { singleton(&[]) } else { Space::new() };
        drop(v515_3);
        let v515_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v515_4));
        drop(v515_4);
        let v515_8: Space = if (v515_5).is_empty() { Space::new() } else {
          let v516_6: Path = concat_path(&(v514_6),&(v514_7_head));
          let mut v516_7 = Space::new();
          let mut v516_7_cursor = (v514_7_tail).read_zipper();
          for v516_7_byte in v516_7_cursor.child_mask().iter() {
            v516_7_cursor.descend_to_byte(v516_7_byte);
            {
            let v516_7_tail = v516_7_cursor.fork_read_zipper();
            let v516_7_head = Path::from_slice(&[v516_7_byte]);
            let v517_2: Space = singleton(&(v516_7_head));
            let v517_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v517_2));
            let v517_4: Space = if map_kernels::has_head(&(v517_3)) { singleton(&[]) } else { Space::new() };
            drop(v517_3);
            let v517_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v517_4));
            drop(v517_4);
            let v517_8: Space = if (v517_5).is_empty() { Space::new() } else {
              let v518_6: Path = concat_path(&(v516_6),&(v516_7_head));
              let v518_7: Space = routine_40(c, &(v518_6), &(*p1), &(v516_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v517_5),&(v518_7))
            };
            drop(v517_5);
            let v517_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v517_2));
            drop(v517_2);
            let v517_10: Space = if map_kernels::has_head(&(v517_9)) { singleton(&[]) } else { Space::new() };
            drop(v517_9);
            let v517_12: Space = if (v517_10).is_empty() { Space::new() } else {
              let v519_6: Path = concat_path(&(v516_6),&(v516_7_head));
              let v519_11: Space = routine_41(c, &(v519_6), &(*p1), &(v516_7_tail).make_space(), &(*s1));
              drop(v519_6);
              map_map_kernels::compose(&(v517_10),&(v519_11))
            };
            drop(v517_10);
            let v517_13: Space = map_map_kernels::unite(&(v517_8),&(v517_12));
            v516_7.join_into((v517_13).clone());
            }
            v516_7_cursor.ascend(1);
          }
          drop(v516_7_cursor);
          map_map_kernels::compose(&(v515_5),&(v516_7))
        };
        drop(v515_5);
        let v515_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v515_2));
        drop(v515_2);
        let v515_10: Space = if map_kernels::has_head(&(v515_9)) { singleton(&[]) } else { Space::new() };
        drop(v515_9);
        let v515_12: Space = if (v515_10).is_empty() { Space::new() } else {
          let v520_6: Path = concat_path(&(v514_6),&(v514_7_head));
          let mut v520_11 = Space::new();
          let mut v520_11_cursor = (v514_7_tail).read_zipper();
          for v520_11_byte in v520_11_cursor.child_mask().iter() {
            v520_11_cursor.descend_to_byte(v520_11_byte);
            {
            let v520_11_tail = v520_11_cursor.fork_read_zipper();
            let v520_11_head = Path::from_slice(&[v520_11_byte]);
            let v521_2: Space = singleton(&(v520_11_head));
            let v521_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v521_2));
            let v521_4: Space = if map_kernels::has_head(&(v521_3)) { singleton(&[]) } else { Space::new() };
            drop(v521_3);
            let v521_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v521_4));
            drop(v521_4);
            let v521_8: Space = if (v521_5).is_empty() { Space::new() } else {
              let v522_6: Path = concat_path(&(v520_6),&(v520_11_head));
              let v522_7: Space = routine_40(c, &(v522_6), &(*p1), &(v520_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v521_5),&(v522_7))
            };
            drop(v521_5);
            let v521_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v521_2));
            drop(v521_2);
            let v521_10: Space = if map_kernels::has_head(&(v521_9)) { singleton(&[]) } else { Space::new() };
            drop(v521_9);
            let v521_12: Space = if (v521_10).is_empty() { Space::new() } else {
              let v523_6: Path = concat_path(&(v520_6),&(v520_11_head));
              let v523_11: Space = routine_10(c, &(v523_6), &(*p1), &(v520_11_tail).make_space(), &(*s1));
              drop(v523_6);
              map_map_kernels::compose(&(v521_10),&(v523_11))
            };
            drop(v521_10);
            let v521_13: Space = map_map_kernels::unite(&(v521_8),&(v521_12));
            v520_11.join_into((v521_13).clone());
            }
            v520_11_cursor.ascend(1);
          }
          drop(v520_11_cursor);
          drop(v520_6);
          map_map_kernels::compose(&(v515_10),&(v520_11))
        };
        drop(v515_10);
        let v515_13: Space = map_map_kernels::unite(&(v515_8),&(v515_12));
        v514_7.join_into((v515_13).clone());
        }
        v514_7_cursor.ascend(1);
      }
      drop(v514_7_cursor);
      map_map_kernels::compose(&(v513_5),&(v514_7))
    };
    drop(v513_5);
    let v513_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v513_2));
    drop(v513_2);
    let v513_10: Space = if map_kernels::has_head(&(v513_9)) { singleton(&[]) } else { Space::new() };
    drop(v513_9);
    let v513_13: Space = if (v513_10).is_empty() { Space::new() } else {
      let v524_6: Path = concat_path(&(*p0),&(v512_28_head));
      let v524_11: Space = map_kernels::unwrap(&(v512_21),&(v512_28_head));
      let mut v524_12 = Space::new();
      let mut v524_12_cursor = (v512_28_tail).read_zipper();
      for v524_12_byte in v524_12_cursor.child_mask().iter() {
        v524_12_cursor.descend_to_byte(v524_12_byte);
        {
        let v524_12_tail = v524_12_cursor.fork_read_zipper();
        let v524_12_head = Path::from_slice(&[v524_12_byte]);
        let v525_2: Space = singleton(&(v524_12_head));
        let v525_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v525_2));
        let v525_4: Space = if map_kernels::has_head(&(v525_3)) { singleton(&[]) } else { Space::new() };
        drop(v525_3);
        let v525_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v525_4));
        drop(v525_4);
        let v525_8: Space = if (v525_5).is_empty() { Space::new() } else {
          let v526_6: Path = concat_path(&(v524_6),&(v524_12_head));
          let mut v526_7 = Space::new();
          let mut v526_7_cursor = (v524_12_tail).read_zipper();
          for v526_7_byte in v526_7_cursor.child_mask().iter() {
            v526_7_cursor.descend_to_byte(v526_7_byte);
            {
            let v526_7_tail = v526_7_cursor.fork_read_zipper();
            let v526_7_head = Path::from_slice(&[v526_7_byte]);
            let v527_2: Space = singleton(&(v526_7_head));
            let v527_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v527_2));
            let v527_4: Space = if map_kernels::has_head(&(v527_3)) { singleton(&[]) } else { Space::new() };
            drop(v527_3);
            let v527_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v527_4));
            drop(v527_4);
            let v527_8: Space = if (v527_5).is_empty() { Space::new() } else {
              let v528_6: Path = concat_path(&(v526_6),&(v526_7_head));
              let v528_7: Space = routine_40(c, &(v528_6), &(*p1), &(v526_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v527_5),&(v528_7))
            };
            drop(v527_5);
            let v527_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v527_2));
            drop(v527_2);
            let v527_10: Space = if map_kernels::has_head(&(v527_9)) { singleton(&[]) } else { Space::new() };
            drop(v527_9);
            let v527_12: Space = if (v527_10).is_empty() { Space::new() } else {
              let v529_6: Path = concat_path(&(v526_6),&(v526_7_head));
              let v529_11: Space = routine_41(c, &(v529_6), &(*p1), &(v526_7_tail).make_space(), &(*s1));
              drop(v529_6);
              map_map_kernels::compose(&(v527_10),&(v529_11))
            };
            drop(v527_10);
            let v527_13: Space = map_map_kernels::unite(&(v527_8),&(v527_12));
            v526_7.join_into((v527_13).clone());
            }
            v526_7_cursor.ascend(1);
          }
          drop(v526_7_cursor);
          drop(v526_6);
          map_map_kernels::compose(&(v525_5),&(v526_7))
        };
        drop(v525_5);
        let v525_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v525_2));
        drop(v525_2);
        let v525_10: Space = if map_kernels::has_head(&(v525_9)) { singleton(&[]) } else { Space::new() };
        drop(v525_9);
        let v525_13: Space = if (v525_10).is_empty() { Space::new() } else {
          let v530_11: Space = map_kernels::unwrap(&(v524_11),&(v524_12_head));
          let mut v530_12 = Space::new();
          let mut v530_12_cursor = (v530_11).read_zipper();
          for v530_12_byte in v530_12_cursor.child_mask().iter() {
            v530_12_cursor.descend_to_byte(v530_12_byte);
            {
            let v530_12_tail = v530_12_cursor.fork_read_zipper();
            let v530_12_head = Path::from_slice(&[v530_12_byte]);
            let v531_2: Space = singleton(&(v530_12_head));
            let v531_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v531_2));
            let v531_4: Space = if map_kernels::has_head(&(v531_3)) { singleton(&[]) } else { Space::new() };
            drop(v531_3);
            let v531_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v531_4));
            drop(v531_4);
            let v531_7: Space = if (v531_5).is_empty() { Space::new() } else {
              let v532_6: Space = routine_13(c, &(v530_12_head), &(*p1), &(v530_12_tail).make_space());
              map_map_kernels::compose(&(v531_5),&(v532_6))
            };
            drop(v531_5);
            let v531_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v531_2));
            drop(v531_2);
            let v531_9: Space = if map_kernels::has_head(&(v531_8)) { singleton(&[]) } else { Space::new() };
            drop(v531_8);
            let v531_11: Space = if (v531_9).is_empty() { Space::new() } else {
              let v533_10: Space = routine_14(c, &(v530_12_head), &(*p1), &(v530_12_tail).make_space());
              map_map_kernels::compose(&(v531_9),&(v533_10))
            };
            drop(v531_9);
            let v531_12: Space = map_map_kernels::unite(&(v531_7),&(v531_11));
            v530_12.join_into((v531_12).clone());
            }
            v530_12_cursor.ascend(1);
          }
          drop(v530_12_cursor);
          drop(v530_11);
          map_map_kernels::compose(&(v525_10),&(v530_12))
        };
        drop(v525_10);
        let v525_14: Space = map_map_kernels::unite(&(v525_8),&(v525_13));
        v524_12.join_into((v525_14).clone());
        }
        v524_12_cursor.ascend(1);
      }
      drop(v524_12_cursor);
      drop(v524_6);
      drop(v524_11);
      map_map_kernels::compose(&(v513_10),&(v524_12))
    };
    drop(v513_10);
    let v513_14: Space = map_map_kernels::unite(&(v513_8),&(v513_13));
    v512_28.join_into((v513_14).clone());
    }
    v512_28_cursor.ascend(1);
  }
  drop(v512_28_cursor);
  drop(v512_21);
  (v512_28).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v534_8: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v534_9: Space = map_kernels::unwrap(&(v534_8),&(*p0));
  drop(v534_8);
  let mut v534_28 = Space::new();
  let mut v534_28_cursor = (*s0).read_zipper();
  for v534_28_byte in v534_28_cursor.child_mask().iter() {
    v534_28_cursor.descend_to_byte(v534_28_byte);
    {
    let v534_28_tail = v534_28_cursor.fork_read_zipper();
    let v534_28_head = Path::from_slice(&[v534_28_byte]);
    let v535_2: Space = singleton(&(v534_28_head));
    let v535_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v535_2));
    let v535_4: Space = if map_kernels::has_head(&(v535_3)) { singleton(&[]) } else { Space::new() };
    drop(v535_3);
    let v535_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v535_4));
    drop(v535_4);
    let v535_8: Space = if (v535_5).is_empty() { Space::new() } else {
      let v536_6: Path = concat_path(&(*p0),&(v534_28_head));
      let mut v536_7 = Space::new();
      let mut v536_7_cursor = (v534_28_tail).read_zipper();
      for v536_7_byte in v536_7_cursor.child_mask().iter() {
        v536_7_cursor.descend_to_byte(v536_7_byte);
        {
        let v536_7_tail = v536_7_cursor.fork_read_zipper();
        let v536_7_head = Path::from_slice(&[v536_7_byte]);
        let v537_2: Space = singleton(&(v536_7_head));
        let v537_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v537_2));
        let v537_4: Space = if map_kernels::has_head(&(v537_3)) { singleton(&[]) } else { Space::new() };
        drop(v537_3);
        let v537_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v537_4));
        drop(v537_4);
        let v537_8: Space = if (v537_5).is_empty() { Space::new() } else {
          let v538_6: Path = concat_path(&(v536_6),&(v536_7_head));
          let mut v538_7 = Space::new();
          let mut v538_7_cursor = (v536_7_tail).read_zipper();
          for v538_7_byte in v538_7_cursor.child_mask().iter() {
            v538_7_cursor.descend_to_byte(v538_7_byte);
            {
            let v538_7_tail = v538_7_cursor.fork_read_zipper();
            let v538_7_head = Path::from_slice(&[v538_7_byte]);
            let v539_2: Space = singleton(&(v538_7_head));
            let v539_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v539_2));
            let v539_4: Space = if map_kernels::has_head(&(v539_3)) { singleton(&[]) } else { Space::new() };
            drop(v539_3);
            let v539_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v539_4));
            drop(v539_4);
            let v539_8: Space = if (v539_5).is_empty() { Space::new() } else {
              let v540_6: Path = concat_path(&(v538_6),&(v538_7_head));
              let v540_7: Space = routine_40(c, &(v540_6), &(*p1), &(v538_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v539_5),&(v540_7))
            };
            drop(v539_5);
            let v539_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v539_2));
            drop(v539_2);
            let v539_10: Space = if map_kernels::has_head(&(v539_9)) { singleton(&[]) } else { Space::new() };
            drop(v539_9);
            let v539_12: Space = if (v539_10).is_empty() { Space::new() } else {
              let v541_6: Path = concat_path(&(v538_6),&(v538_7_head));
              let v541_11: Space = routine_41(c, &(v541_6), &(*p1), &(v538_7_tail).make_space(), &(*s1));
              drop(v541_6);
              map_map_kernels::compose(&(v539_10),&(v541_11))
            };
            drop(v539_10);
            let v539_13: Space = map_map_kernels::unite(&(v539_8),&(v539_12));
            v538_7.join_into((v539_13).clone());
            }
            v538_7_cursor.ascend(1);
          }
          drop(v538_7_cursor);
          map_map_kernels::compose(&(v537_5),&(v538_7))
        };
        drop(v537_5);
        let v537_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v537_2));
        drop(v537_2);
        let v537_10: Space = if map_kernels::has_head(&(v537_9)) { singleton(&[]) } else { Space::new() };
        drop(v537_9);
        let v537_12: Space = if (v537_10).is_empty() { Space::new() } else {
          let v542_6: Path = concat_path(&(v536_6),&(v536_7_head));
          let mut v542_11 = Space::new();
          let mut v542_11_cursor = (v536_7_tail).read_zipper();
          for v542_11_byte in v542_11_cursor.child_mask().iter() {
            v542_11_cursor.descend_to_byte(v542_11_byte);
            {
            let v542_11_tail = v542_11_cursor.fork_read_zipper();
            let v542_11_head = Path::from_slice(&[v542_11_byte]);
            let v543_2: Space = singleton(&(v542_11_head));
            let v543_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v543_2));
            let v543_4: Space = if map_kernels::has_head(&(v543_3)) { singleton(&[]) } else { Space::new() };
            drop(v543_3);
            let v543_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v543_4));
            drop(v543_4);
            let v543_8: Space = if (v543_5).is_empty() { Space::new() } else {
              let v544_6: Path = concat_path(&(v542_6),&(v542_11_head));
              let v544_7: Space = routine_40(c, &(v544_6), &(*p1), &(v542_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v543_5),&(v544_7))
            };
            drop(v543_5);
            let v543_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v543_2));
            drop(v543_2);
            let v543_10: Space = if map_kernels::has_head(&(v543_9)) { singleton(&[]) } else { Space::new() };
            drop(v543_9);
            let v543_12: Space = if (v543_10).is_empty() { Space::new() } else {
              let v545_6: Path = concat_path(&(v542_6),&(v542_11_head));
              let v545_11: Space = routine_10(c, &(v545_6), &(*p1), &(v542_11_tail).make_space(), &(*s1));
              drop(v545_6);
              map_map_kernels::compose(&(v543_10),&(v545_11))
            };
            drop(v543_10);
            let v543_13: Space = map_map_kernels::unite(&(v543_8),&(v543_12));
            v542_11.join_into((v543_13).clone());
            }
            v542_11_cursor.ascend(1);
          }
          drop(v542_11_cursor);
          drop(v542_6);
          map_map_kernels::compose(&(v537_10),&(v542_11))
        };
        drop(v537_10);
        let v537_13: Space = map_map_kernels::unite(&(v537_8),&(v537_12));
        v536_7.join_into((v537_13).clone());
        }
        v536_7_cursor.ascend(1);
      }
      drop(v536_7_cursor);
      drop(v536_6);
      map_map_kernels::compose(&(v535_5),&(v536_7))
    };
    drop(v535_5);
    let v535_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v535_2));
    drop(v535_2);
    let v535_10: Space = if map_kernels::has_head(&(v535_9)) { singleton(&[]) } else { Space::new() };
    drop(v535_9);
    let v535_13: Space = if (v535_10).is_empty() { Space::new() } else {
      let v546_11: Space = map_kernels::unwrap(&(v534_9),&(v534_28_head));
      let mut v546_12 = Space::new();
      let mut v546_12_cursor = (v546_11).read_zipper();
      for v546_12_byte in v546_12_cursor.child_mask().iter() {
        v546_12_cursor.descend_to_byte(v546_12_byte);
        {
        let v546_12_tail = v546_12_cursor.fork_read_zipper();
        let v546_12_head = Path::from_slice(&[v546_12_byte]);
        let v547_2: Space = singleton(&(v546_12_head));
        let v547_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v547_2));
        let v547_4: Space = if map_kernels::has_head(&(v547_3)) { singleton(&[]) } else { Space::new() };
        drop(v547_3);
        let v547_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v547_4));
        drop(v547_4);
        let v547_7: Space = if (v547_5).is_empty() { Space::new() } else {
          let mut v548_6 = Space::new();
          let mut v548_6_cursor = (v546_12_tail).read_zipper();
          for v548_6_byte in v548_6_cursor.child_mask().iter() {
            v548_6_cursor.descend_to_byte(v548_6_byte);
            {
            let v548_6_tail = v548_6_cursor.fork_read_zipper();
            let v548_6_head = Path::from_slice(&[v548_6_byte]);
            let v549_2: Space = singleton(&(v548_6_head));
            let v549_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v549_2));
            let v549_4: Space = if map_kernels::has_head(&(v549_3)) { singleton(&[]) } else { Space::new() };
            drop(v549_3);
            let v549_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v549_4));
            drop(v549_4);
            let v549_8: Space = if (v549_5).is_empty() { Space::new() } else {
              let v550_6: Path = concat_path(&(v546_12_head),&(v548_6_head));
              let v550_7: Space = routine_17(c, &(v550_6), &(*p1), &(v548_6_tail).make_space());
              map_map_kernels::compose(&(v549_5),&(v550_7))
            };
            drop(v549_5);
            let v549_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v549_2));
            drop(v549_2);
            let v549_10: Space = if map_kernels::has_head(&(v549_9)) { singleton(&[]) } else { Space::new() };
            drop(v549_9);
            let v549_12: Space = if (v549_10).is_empty() { Space::new() } else {
              let v551_6: Path = concat_path(&(v546_12_head),&(v548_6_head));
              let v551_11: Space = routine_18(c, &(v551_6), &(*p1), &(v548_6_tail).make_space());
              drop(v551_6);
              map_map_kernels::compose(&(v549_10),&(v551_11))
            };
            drop(v549_10);
            let v549_13: Space = map_map_kernels::unite(&(v549_8),&(v549_12));
            v548_6.join_into((v549_13).clone());
            }
            v548_6_cursor.ascend(1);
          }
          drop(v548_6_cursor);
          map_map_kernels::compose(&(v547_5),&(v548_6))
        };
        drop(v547_5);
        let v547_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v547_2));
        drop(v547_2);
        let v547_9: Space = if map_kernels::has_head(&(v547_8)) { singleton(&[]) } else { Space::new() };
        drop(v547_8);
        let v547_11: Space = if (v547_9).is_empty() { Space::new() } else {
          let mut v552_10 = Space::new();
          let mut v552_10_cursor = (v546_12_tail).read_zipper();
          for v552_10_byte in v552_10_cursor.child_mask().iter() {
            v552_10_cursor.descend_to_byte(v552_10_byte);
            {
            let v552_10_tail = v552_10_cursor.fork_read_zipper();
            let v552_10_head = Path::from_slice(&[v552_10_byte]);
            let v553_2: Space = singleton(&(v552_10_head));
            let v553_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v553_2));
            let v553_4: Space = if map_kernels::has_head(&(v553_3)) { singleton(&[]) } else { Space::new() };
            drop(v553_3);
            let v553_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v553_4));
            drop(v553_4);
            let v553_8: Space = if (v553_5).is_empty() { Space::new() } else {
              let v554_6: Path = concat_path(&(v546_12_head),&(v552_10_head));
              let v554_7: Space = routine_17(c, &(v554_6), &(*p1), &(v552_10_tail).make_space());
              map_map_kernels::compose(&(v553_5),&(v554_7))
            };
            drop(v553_5);
            let v553_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v553_2));
            drop(v553_2);
            let v553_10: Space = if map_kernels::has_head(&(v553_9)) { singleton(&[]) } else { Space::new() };
            drop(v553_9);
            let v553_12: Space = if (v553_10).is_empty() { Space::new() } else {
              let v555_6: Path = concat_path(&(v546_12_head),&(v552_10_head));
              let v555_11: Space = routine_19(c, &(v555_6), &(*p1), &(v552_10_tail).make_space());
              drop(v555_6);
              map_map_kernels::compose(&(v553_10),&(v555_11))
            };
            drop(v553_10);
            let v553_13: Space = map_map_kernels::unite(&(v553_8),&(v553_12));
            v552_10.join_into((v553_13).clone());
            }
            v552_10_cursor.ascend(1);
          }
          drop(v552_10_cursor);
          map_map_kernels::compose(&(v547_9),&(v552_10))
        };
        drop(v547_9);
        let v547_12: Space = map_map_kernels::unite(&(v547_7),&(v547_11));
        v546_12.join_into((v547_12).clone());
        }
        v546_12_cursor.ascend(1);
      }
      drop(v546_12_cursor);
      drop(v546_11);
      map_map_kernels::compose(&(v535_10),&(v546_12))
    };
    drop(v535_10);
    let v535_14: Space = map_map_kernels::unite(&(v535_8),&(v535_13));
    v534_28.join_into((v535_14).clone());
    }
    v534_28_cursor.ascend(1);
  }
  drop(v534_28_cursor);
  drop(v534_9);
  (v534_28).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v556_21 = Space::new();
  let mut v556_21_cursor = (*s0).read_zipper();
  for v556_21_byte in v556_21_cursor.child_mask().iter() {
    v556_21_cursor.descend_to_byte(v556_21_byte);
    {
    let v556_21_tail = v556_21_cursor.fork_read_zipper();
    let v556_21_head = Path::from_slice(&[v556_21_byte]);
    let v557_2: Space = singleton(&(v556_21_head));
    let v557_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v557_2));
    let v557_4: Space = if map_kernels::has_head(&(v557_3)) { singleton(&[]) } else { Space::new() };
    drop(v557_3);
    let v557_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v557_4));
    drop(v557_4);
    let v557_8: Space = if (v557_5).is_empty() { Space::new() } else {
      let v558_6: Path = concat_path(&(*p0),&(v556_21_head));
      let mut v558_7 = Space::new();
      let mut v558_7_cursor = (v556_21_tail).read_zipper();
      for v558_7_byte in v558_7_cursor.child_mask().iter() {
        v558_7_cursor.descend_to_byte(v558_7_byte);
        {
        let v558_7_tail = v558_7_cursor.fork_read_zipper();
        let v558_7_head = Path::from_slice(&[v558_7_byte]);
        let v559_2: Space = singleton(&(v558_7_head));
        let v559_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v559_2));
        let v559_4: Space = if map_kernels::has_head(&(v559_3)) { singleton(&[]) } else { Space::new() };
        drop(v559_3);
        let v559_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v559_4));
        drop(v559_4);
        let v559_8: Space = if (v559_5).is_empty() { Space::new() } else {
          let v560_6: Path = concat_path(&(v558_6),&(v558_7_head));
          let mut v560_7 = Space::new();
          let mut v560_7_cursor = (v558_7_tail).read_zipper();
          for v560_7_byte in v560_7_cursor.child_mask().iter() {
            v560_7_cursor.descend_to_byte(v560_7_byte);
            {
            let v560_7_tail = v560_7_cursor.fork_read_zipper();
            let v560_7_head = Path::from_slice(&[v560_7_byte]);
            let v561_2: Space = singleton(&(v560_7_head));
            let v561_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v561_2));
            let v561_4: Space = if map_kernels::has_head(&(v561_3)) { singleton(&[]) } else { Space::new() };
            drop(v561_3);
            let v561_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v561_4));
            drop(v561_4);
            let v561_8: Space = if (v561_5).is_empty() { Space::new() } else {
              let v562_6: Path = concat_path(&(v560_6),&(v560_7_head));
              let v562_7: Space = routine_42(c, &(v562_6), &(*p1), &(v560_7_tail).make_space());
              map_map_kernels::compose(&(v561_5),&(v562_7))
            };
            drop(v561_5);
            let v561_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v561_2));
            drop(v561_2);
            let v561_10: Space = if map_kernels::has_head(&(v561_9)) { singleton(&[]) } else { Space::new() };
            drop(v561_9);
            let v561_12: Space = if (v561_10).is_empty() { Space::new() } else {
              let v563_6: Path = concat_path(&(v560_6),&(v560_7_head));
              let v563_11: Space = routine_43(c, &(v563_6), &(*p1), &(v560_7_tail).make_space());
              drop(v563_6);
              map_map_kernels::compose(&(v561_10),&(v563_11))
            };
            drop(v561_10);
            let v561_13: Space = map_map_kernels::unite(&(v561_8),&(v561_12));
            v560_7.join_into((v561_13).clone());
            }
            v560_7_cursor.ascend(1);
          }
          drop(v560_7_cursor);
          map_map_kernels::compose(&(v559_5),&(v560_7))
        };
        drop(v559_5);
        let v559_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v559_2));
        drop(v559_2);
        let v559_10: Space = if map_kernels::has_head(&(v559_9)) { singleton(&[]) } else { Space::new() };
        drop(v559_9);
        let v559_12: Space = if (v559_10).is_empty() { Space::new() } else {
          let v564_6: Path = concat_path(&(v558_6),&(v558_7_head));
          let mut v564_11 = Space::new();
          let mut v564_11_cursor = (v558_7_tail).read_zipper();
          for v564_11_byte in v564_11_cursor.child_mask().iter() {
            v564_11_cursor.descend_to_byte(v564_11_byte);
            {
            let v564_11_tail = v564_11_cursor.fork_read_zipper();
            let v564_11_head = Path::from_slice(&[v564_11_byte]);
            let v565_2: Space = singleton(&(v564_11_head));
            let v565_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v565_2));
            let v565_4: Space = if map_kernels::has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
            drop(v565_3);
            let v565_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v565_4));
            drop(v565_4);
            let v565_8: Space = if (v565_5).is_empty() { Space::new() } else {
              let v566_6: Path = concat_path(&(v564_6),&(v564_11_head));
              let v566_7: Space = routine_42(c, &(v566_6), &(*p1), &(v564_11_tail).make_space());
              map_map_kernels::compose(&(v565_5),&(v566_7))
            };
            drop(v565_5);
            let v565_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v565_2));
            drop(v565_2);
            let v565_10: Space = if map_kernels::has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
            drop(v565_9);
            let v565_12: Space = if (v565_10).is_empty() { Space::new() } else {
              let v567_6: Path = concat_path(&(v564_6),&(v564_11_head));
              let v567_11: Space = routine_19(c, &(v567_6), &(*p1), &(v564_11_tail).make_space());
              drop(v567_6);
              map_map_kernels::compose(&(v565_10),&(v567_11))
            };
            drop(v565_10);
            let v565_13: Space = map_map_kernels::unite(&(v565_8),&(v565_12));
            v564_11.join_into((v565_13).clone());
            }
            v564_11_cursor.ascend(1);
          }
          drop(v564_11_cursor);
          drop(v564_6);
          map_map_kernels::compose(&(v559_10),&(v564_11))
        };
        drop(v559_10);
        let v559_13: Space = map_map_kernels::unite(&(v559_8),&(v559_12));
        v558_7.join_into((v559_13).clone());
        }
        v558_7_cursor.ascend(1);
      }
      drop(v558_7_cursor);
      map_map_kernels::compose(&(v557_5),&(v558_7))
    };
    drop(v557_5);
    let v557_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v557_2));
    drop(v557_2);
    let v557_10: Space = if map_kernels::has_head(&(v557_9)) { singleton(&[]) } else { Space::new() };
    drop(v557_9);
    let v557_12: Space = if (v557_10).is_empty() { Space::new() } else {
      let v568_6: Path = concat_path(&(*p0),&(v556_21_head));
      let mut v568_11 = Space::new();
      let mut v568_11_cursor = (v556_21_tail).read_zipper();
      for v568_11_byte in v568_11_cursor.child_mask().iter() {
        v568_11_cursor.descend_to_byte(v568_11_byte);
        {
        let v568_11_tail = v568_11_cursor.fork_read_zipper();
        let v568_11_head = Path::from_slice(&[v568_11_byte]);
        let v569_2: Space = singleton(&(v568_11_head));
        let v569_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v569_2));
        let v569_4: Space = if map_kernels::has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
        drop(v569_3);
        let v569_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v569_4));
        drop(v569_4);
        let v569_8: Space = if (v569_5).is_empty() { Space::new() } else {
          let v570_6: Path = concat_path(&(v568_6),&(v568_11_head));
          let mut v570_7 = Space::new();
          let mut v570_7_cursor = (v568_11_tail).read_zipper();
          for v570_7_byte in v570_7_cursor.child_mask().iter() {
            v570_7_cursor.descend_to_byte(v570_7_byte);
            {
            let v570_7_tail = v570_7_cursor.fork_read_zipper();
            let v570_7_head = Path::from_slice(&[v570_7_byte]);
            let v571_2: Space = singleton(&(v570_7_head));
            let v571_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v571_2));
            let v571_4: Space = if map_kernels::has_head(&(v571_3)) { singleton(&[]) } else { Space::new() };
            drop(v571_3);
            let v571_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v571_4));
            drop(v571_4);
            let v571_8: Space = if (v571_5).is_empty() { Space::new() } else {
              let v572_6: Path = concat_path(&(v570_6),&(v570_7_head));
              let v572_7: Space = routine_42(c, &(v572_6), &(*p1), &(v570_7_tail).make_space());
              map_map_kernels::compose(&(v571_5),&(v572_7))
            };
            drop(v571_5);
            let v571_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v571_2));
            drop(v571_2);
            let v571_10: Space = if map_kernels::has_head(&(v571_9)) { singleton(&[]) } else { Space::new() };
            drop(v571_9);
            let v571_12: Space = if (v571_10).is_empty() { Space::new() } else {
              let v573_6: Path = concat_path(&(v570_6),&(v570_7_head));
              let v573_11: Space = routine_43(c, &(v573_6), &(*p1), &(v570_7_tail).make_space());
              drop(v573_6);
              map_map_kernels::compose(&(v571_10),&(v573_11))
            };
            drop(v571_10);
            let v571_13: Space = map_map_kernels::unite(&(v571_8),&(v571_12));
            v570_7.join_into((v571_13).clone());
            }
            v570_7_cursor.ascend(1);
          }
          drop(v570_7_cursor);
          map_map_kernels::compose(&(v569_5),&(v570_7))
        };
        drop(v569_5);
        let v569_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v569_2));
        drop(v569_2);
        let v569_10: Space = if map_kernels::has_head(&(v569_9)) { singleton(&[]) } else { Space::new() };
        drop(v569_9);
        let v569_11: Space = map_view_kernels::compose(&(v569_10),&(v568_11_tail));
        drop(v569_10);
        let v574_6: Path = concat_path(&(v568_6),&(v568_11_head));
        let v569_12: Space = map_kernels::wrap(&(v569_11),&(v574_6));
        drop(v569_11);
        let v569_13: Space = map_kernels::wrap(&(v569_12),&(*p1));
        drop(v569_12);
        let v569_14: Space = map_map_kernels::unite(&(v569_8),&(v569_13));
        drop(v569_13);
        v568_11.join_into((v569_14).clone());
        }
        v568_11_cursor.ascend(1);
      }
      drop(v568_11_cursor);
      drop(v568_6);
      map_map_kernels::compose(&(v557_10),&(v568_11))
    };
    drop(v557_10);
    let v557_13: Space = map_map_kernels::unite(&(v557_8),&(v557_12));
    v556_21.join_into((v557_13).clone());
    }
    v556_21_cursor.ascend(1);
  }
  drop(v556_21_cursor);
  (v556_21).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v575_15 = Space::new();
  let mut v575_15_cursor = (*s0).read_zipper();
  for v575_15_byte in v575_15_cursor.child_mask().iter() {
    v575_15_cursor.descend_to_byte(v575_15_byte);
    {
    let v575_15_tail = v575_15_cursor.fork_read_zipper();
    let v575_15_head = Path::from_slice(&[v575_15_byte]);
    let v576_2: Space = singleton(&(v575_15_head));
    let v576_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v576_2));
    let v576_4: Space = if map_kernels::has_head(&(v576_3)) { singleton(&[]) } else { Space::new() };
    drop(v576_3);
    let v576_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v576_4));
    drop(v576_4);
    let v576_8: Space = if (v576_5).is_empty() { Space::new() } else {
      let v577_6: Path = concat_path(&(*p0),&(v575_15_head));
      let mut v577_7 = Space::new();
      let mut v577_7_cursor = (v575_15_tail).read_zipper();
      for v577_7_byte in v577_7_cursor.child_mask().iter() {
        v577_7_cursor.descend_to_byte(v577_7_byte);
        {
        let v577_7_tail = v577_7_cursor.fork_read_zipper();
        let v577_7_head = Path::from_slice(&[v577_7_byte]);
        let v578_2: Space = singleton(&(v577_7_head));
        let v578_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v578_2));
        let v578_4: Space = if map_kernels::has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
        drop(v578_3);
        let v578_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v578_4));
        drop(v578_4);
        let v578_8: Space = if (v578_5).is_empty() { Space::new() } else {
          let v579_6: Path = concat_path(&(v577_6),&(v577_7_head));
          let mut v579_7 = Space::new();
          let mut v579_7_cursor = (v577_7_tail).read_zipper();
          for v579_7_byte in v579_7_cursor.child_mask().iter() {
            v579_7_cursor.descend_to_byte(v579_7_byte);
            {
            let v579_7_tail = v579_7_cursor.fork_read_zipper();
            let v579_7_head = Path::from_slice(&[v579_7_byte]);
            let v580_2: Space = singleton(&(v579_7_head));
            let v580_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v580_2));
            let v580_4: Space = if map_kernels::has_head(&(v580_3)) { singleton(&[]) } else { Space::new() };
            drop(v580_3);
            let v580_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v580_4));
            drop(v580_4);
            let v580_8: Space = if (v580_5).is_empty() { Space::new() } else {
              let v581_6: Path = concat_path(&(v579_6),&(v579_7_head));
              let v581_7: Space = routine_42(c, &(v581_6), &(*p1), &(v579_7_tail).make_space());
              map_map_kernels::compose(&(v580_5),&(v581_7))
            };
            drop(v580_5);
            let v580_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v580_2));
            drop(v580_2);
            let v580_10: Space = if map_kernels::has_head(&(v580_9)) { singleton(&[]) } else { Space::new() };
            drop(v580_9);
            let v580_12: Space = if (v580_10).is_empty() { Space::new() } else {
              let v582_6: Path = concat_path(&(v579_6),&(v579_7_head));
              let v582_11: Space = routine_43(c, &(v582_6), &(*p1), &(v579_7_tail).make_space());
              drop(v582_6);
              map_map_kernels::compose(&(v580_10),&(v582_11))
            };
            drop(v580_10);
            let v580_13: Space = map_map_kernels::unite(&(v580_8),&(v580_12));
            v579_7.join_into((v580_13).clone());
            }
            v579_7_cursor.ascend(1);
          }
          drop(v579_7_cursor);
          map_map_kernels::compose(&(v578_5),&(v579_7))
        };
        drop(v578_5);
        let v578_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v578_2));
        drop(v578_2);
        let v578_10: Space = if map_kernels::has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
        drop(v578_9);
        let v578_12: Space = if (v578_10).is_empty() { Space::new() } else {
          let v583_6: Path = concat_path(&(v577_6),&(v577_7_head));
          let mut v583_11 = Space::new();
          let mut v583_11_cursor = (v577_7_tail).read_zipper();
          for v583_11_byte in v583_11_cursor.child_mask().iter() {
            v583_11_cursor.descend_to_byte(v583_11_byte);
            {
            let v583_11_tail = v583_11_cursor.fork_read_zipper();
            let v583_11_head = Path::from_slice(&[v583_11_byte]);
            let v584_2: Space = singleton(&(v583_11_head));
            let v584_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v584_2));
            let v584_4: Space = if map_kernels::has_head(&(v584_3)) { singleton(&[]) } else { Space::new() };
            drop(v584_3);
            let v584_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v584_4));
            drop(v584_4);
            let v584_8: Space = if (v584_5).is_empty() { Space::new() } else {
              let v585_6: Path = concat_path(&(v583_6),&(v583_11_head));
              let v585_7: Space = routine_42(c, &(v585_6), &(*p1), &(v583_11_tail).make_space());
              map_map_kernels::compose(&(v584_5),&(v585_7))
            };
            drop(v584_5);
            let v584_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v584_2));
            drop(v584_2);
            let v584_10: Space = if map_kernels::has_head(&(v584_9)) { singleton(&[]) } else { Space::new() };
            drop(v584_9);
            let v584_12: Space = if (v584_10).is_empty() { Space::new() } else {
              let v586_6: Path = concat_path(&(v583_6),&(v583_11_head));
              let v586_11: Space = routine_19(c, &(v586_6), &(*p1), &(v583_11_tail).make_space());
              drop(v586_6);
              map_map_kernels::compose(&(v584_10),&(v586_11))
            };
            drop(v584_10);
            let v584_13: Space = map_map_kernels::unite(&(v584_8),&(v584_12));
            v583_11.join_into((v584_13).clone());
            }
            v583_11_cursor.ascend(1);
          }
          drop(v583_11_cursor);
          drop(v583_6);
          map_map_kernels::compose(&(v578_10),&(v583_11))
        };
        drop(v578_10);
        let v578_13: Space = map_map_kernels::unite(&(v578_8),&(v578_12));
        v577_7.join_into((v578_13).clone());
        }
        v577_7_cursor.ascend(1);
      }
      drop(v577_7_cursor);
      map_map_kernels::compose(&(v576_5),&(v577_7))
    };
    drop(v576_5);
    let v576_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v576_2));
    drop(v576_2);
    let v576_10: Space = if map_kernels::has_head(&(v576_9)) { singleton(&[]) } else { Space::new() };
    drop(v576_9);
    let v576_11: Space = map_view_kernels::compose(&(v576_10),&(v575_15_tail));
    drop(v576_10);
    let v587_6: Path = concat_path(&(*p0),&(v575_15_head));
    let v576_12: Space = map_kernels::wrap(&(v576_11),&(v587_6));
    drop(v576_11);
    let v576_13: Space = map_kernels::wrap(&(v576_12),&(*p1));
    drop(v576_12);
    let v576_14: Space = map_map_kernels::unite(&(v576_8),&(v576_13));
    drop(v576_13);
    v575_15.join_into((v576_14).clone());
    }
    v575_15_cursor.ascend(1);
  }
  drop(v575_15_cursor);
  (v575_15).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v588_20: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v588_21: Space = map_kernels::unwrap(&(v588_20),&(*p0));
  drop(v588_20);
  let mut v588_28 = Space::new();
  let mut v588_28_cursor = (*s0).read_zipper();
  for v588_28_byte in v588_28_cursor.child_mask().iter() {
    v588_28_cursor.descend_to_byte(v588_28_byte);
    {
    let v588_28_tail = v588_28_cursor.fork_read_zipper();
    let v588_28_head = Path::from_slice(&[v588_28_byte]);
    let v589_2: Space = singleton(&(v588_28_head));
    let v589_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v589_2));
    let v589_4: Space = if map_kernels::has_head(&(v589_3)) { singleton(&[]) } else { Space::new() };
    drop(v589_3);
    let v589_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v589_4));
    drop(v589_4);
    let v589_8: Space = if (v589_5).is_empty() { Space::new() } else {
      let v590_6: Path = concat_path(&(*p0),&(v588_28_head));
      let mut v590_7 = Space::new();
      let mut v590_7_cursor = (v588_28_tail).read_zipper();
      for v590_7_byte in v590_7_cursor.child_mask().iter() {
        v590_7_cursor.descend_to_byte(v590_7_byte);
        {
        let v590_7_tail = v590_7_cursor.fork_read_zipper();
        let v590_7_head = Path::from_slice(&[v590_7_byte]);
        let v591_2: Space = singleton(&(v590_7_head));
        let v591_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v591_2));
        let v591_4: Space = if map_kernels::has_head(&(v591_3)) { singleton(&[]) } else { Space::new() };
        drop(v591_3);
        let v591_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v591_4));
        drop(v591_4);
        let v591_8: Space = if (v591_5).is_empty() { Space::new() } else {
          let v592_6: Path = concat_path(&(v590_6),&(v590_7_head));
          let mut v592_7 = Space::new();
          let mut v592_7_cursor = (v590_7_tail).read_zipper();
          for v592_7_byte in v592_7_cursor.child_mask().iter() {
            v592_7_cursor.descend_to_byte(v592_7_byte);
            {
            let v592_7_tail = v592_7_cursor.fork_read_zipper();
            let v592_7_head = Path::from_slice(&[v592_7_byte]);
            let v593_2: Space = singleton(&(v592_7_head));
            let v593_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v593_2));
            let v593_4: Space = if map_kernels::has_head(&(v593_3)) { singleton(&[]) } else { Space::new() };
            drop(v593_3);
            let v593_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v593_4));
            drop(v593_4);
            let v593_8: Space = if (v593_5).is_empty() { Space::new() } else {
              let v594_6: Path = concat_path(&(v592_6),&(v592_7_head));
              let v594_7: Space = routine_44(c, &(v594_6), &(*p1), &(v592_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v593_5),&(v594_7))
            };
            drop(v593_5);
            let v593_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v593_2));
            drop(v593_2);
            let v593_10: Space = if map_kernels::has_head(&(v593_9)) { singleton(&[]) } else { Space::new() };
            drop(v593_9);
            let v593_12: Space = if (v593_10).is_empty() { Space::new() } else {
              let v595_6: Path = concat_path(&(v592_6),&(v592_7_head));
              let v595_11: Space = routine_45(c, &(v595_6), &(*p1), &(v592_7_tail).make_space(), &(*s1));
              drop(v595_6);
              map_map_kernels::compose(&(v593_10),&(v595_11))
            };
            drop(v593_10);
            let v593_13: Space = map_map_kernels::unite(&(v593_8),&(v593_12));
            v592_7.join_into((v593_13).clone());
            }
            v592_7_cursor.ascend(1);
          }
          drop(v592_7_cursor);
          map_map_kernels::compose(&(v591_5),&(v592_7))
        };
        drop(v591_5);
        let v591_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v591_2));
        drop(v591_2);
        let v591_10: Space = if map_kernels::has_head(&(v591_9)) { singleton(&[]) } else { Space::new() };
        drop(v591_9);
        let v591_12: Space = if (v591_10).is_empty() { Space::new() } else {
          let v596_6: Path = concat_path(&(v590_6),&(v590_7_head));
          let mut v596_11 = Space::new();
          let mut v596_11_cursor = (v590_7_tail).read_zipper();
          for v596_11_byte in v596_11_cursor.child_mask().iter() {
            v596_11_cursor.descend_to_byte(v596_11_byte);
            {
            let v596_11_tail = v596_11_cursor.fork_read_zipper();
            let v596_11_head = Path::from_slice(&[v596_11_byte]);
            let v597_2: Space = singleton(&(v596_11_head));
            let v597_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v597_2));
            let v597_4: Space = if map_kernels::has_head(&(v597_3)) { singleton(&[]) } else { Space::new() };
            drop(v597_3);
            let v597_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v597_4));
            drop(v597_4);
            let v597_8: Space = if (v597_5).is_empty() { Space::new() } else {
              let v598_6: Path = concat_path(&(v596_6),&(v596_11_head));
              let v598_7: Space = routine_44(c, &(v598_6), &(*p1), &(v596_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v597_5),&(v598_7))
            };
            drop(v597_5);
            let v597_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v597_2));
            drop(v597_2);
            let v597_10: Space = if map_kernels::has_head(&(v597_9)) { singleton(&[]) } else { Space::new() };
            drop(v597_9);
            let v597_12: Space = if (v597_10).is_empty() { Space::new() } else {
              let v599_6: Path = concat_path(&(v596_6),&(v596_11_head));
              let v599_11: Space = routine_10(c, &(v599_6), &(*p1), &(v596_11_tail).make_space(), &(*s1));
              drop(v599_6);
              map_map_kernels::compose(&(v597_10),&(v599_11))
            };
            drop(v597_10);
            let v597_13: Space = map_map_kernels::unite(&(v597_8),&(v597_12));
            v596_11.join_into((v597_13).clone());
            }
            v596_11_cursor.ascend(1);
          }
          drop(v596_11_cursor);
          drop(v596_6);
          map_map_kernels::compose(&(v591_10),&(v596_11))
        };
        drop(v591_10);
        let v591_13: Space = map_map_kernels::unite(&(v591_8),&(v591_12));
        v590_7.join_into((v591_13).clone());
        }
        v590_7_cursor.ascend(1);
      }
      drop(v590_7_cursor);
      map_map_kernels::compose(&(v589_5),&(v590_7))
    };
    drop(v589_5);
    let v589_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v589_2));
    drop(v589_2);
    let v589_10: Space = if map_kernels::has_head(&(v589_9)) { singleton(&[]) } else { Space::new() };
    drop(v589_9);
    let v589_13: Space = if (v589_10).is_empty() { Space::new() } else {
      let v600_6: Path = concat_path(&(*p0),&(v588_28_head));
      let v600_11: Space = map_kernels::unwrap(&(v588_21),&(v588_28_head));
      let mut v600_12 = Space::new();
      let mut v600_12_cursor = (v588_28_tail).read_zipper();
      for v600_12_byte in v600_12_cursor.child_mask().iter() {
        v600_12_cursor.descend_to_byte(v600_12_byte);
        {
        let v600_12_tail = v600_12_cursor.fork_read_zipper();
        let v600_12_head = Path::from_slice(&[v600_12_byte]);
        let v601_2: Space = singleton(&(v600_12_head));
        let v601_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v601_2));
        let v601_4: Space = if map_kernels::has_head(&(v601_3)) { singleton(&[]) } else { Space::new() };
        drop(v601_3);
        let v601_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v601_4));
        drop(v601_4);
        let v601_8: Space = if (v601_5).is_empty() { Space::new() } else {
          let v602_6: Path = concat_path(&(v600_6),&(v600_12_head));
          let mut v602_7 = Space::new();
          let mut v602_7_cursor = (v600_12_tail).read_zipper();
          for v602_7_byte in v602_7_cursor.child_mask().iter() {
            v602_7_cursor.descend_to_byte(v602_7_byte);
            {
            let v602_7_tail = v602_7_cursor.fork_read_zipper();
            let v602_7_head = Path::from_slice(&[v602_7_byte]);
            let v603_2: Space = singleton(&(v602_7_head));
            let v603_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v603_2));
            let v603_4: Space = if map_kernels::has_head(&(v603_3)) { singleton(&[]) } else { Space::new() };
            drop(v603_3);
            let v603_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v603_4));
            drop(v603_4);
            let v603_8: Space = if (v603_5).is_empty() { Space::new() } else {
              let v604_6: Path = concat_path(&(v602_6),&(v602_7_head));
              let v604_7: Space = routine_44(c, &(v604_6), &(*p1), &(v602_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v603_5),&(v604_7))
            };
            drop(v603_5);
            let v603_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v603_2));
            drop(v603_2);
            let v603_10: Space = if map_kernels::has_head(&(v603_9)) { singleton(&[]) } else { Space::new() };
            drop(v603_9);
            let v603_12: Space = if (v603_10).is_empty() { Space::new() } else {
              let v605_6: Path = concat_path(&(v602_6),&(v602_7_head));
              let v605_11: Space = routine_45(c, &(v605_6), &(*p1), &(v602_7_tail).make_space(), &(*s1));
              drop(v605_6);
              map_map_kernels::compose(&(v603_10),&(v605_11))
            };
            drop(v603_10);
            let v603_13: Space = map_map_kernels::unite(&(v603_8),&(v603_12));
            v602_7.join_into((v603_13).clone());
            }
            v602_7_cursor.ascend(1);
          }
          drop(v602_7_cursor);
          drop(v602_6);
          map_map_kernels::compose(&(v601_5),&(v602_7))
        };
        drop(v601_5);
        let v601_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v601_2));
        drop(v601_2);
        let v601_10: Space = if map_kernels::has_head(&(v601_9)) { singleton(&[]) } else { Space::new() };
        drop(v601_9);
        let v601_13: Space = if (v601_10).is_empty() { Space::new() } else {
          let v606_11: Space = map_kernels::unwrap(&(v600_11),&(v600_12_head));
          let mut v606_12 = Space::new();
          let mut v606_12_cursor = (v606_11).read_zipper();
          for v606_12_byte in v606_12_cursor.child_mask().iter() {
            v606_12_cursor.descend_to_byte(v606_12_byte);
            {
            let v606_12_tail = v606_12_cursor.fork_read_zipper();
            let v606_12_head = Path::from_slice(&[v606_12_byte]);
            let v607_2: Space = singleton(&(v606_12_head));
            let v607_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v607_2));
            let v607_4: Space = if map_kernels::has_head(&(v607_3)) { singleton(&[]) } else { Space::new() };
            drop(v607_3);
            let v607_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v607_4));
            drop(v607_4);
            let v607_7: Space = if (v607_5).is_empty() { Space::new() } else {
              let v608_6: Space = routine_13(c, &(v606_12_head), &(*p1), &(v606_12_tail).make_space());
              map_map_kernels::compose(&(v607_5),&(v608_6))
            };
            drop(v607_5);
            let v607_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v607_2));
            drop(v607_2);
            let v607_9: Space = if map_kernels::has_head(&(v607_8)) { singleton(&[]) } else { Space::new() };
            drop(v607_8);
            let v607_11: Space = if (v607_9).is_empty() { Space::new() } else {
              let v609_10: Space = routine_14(c, &(v606_12_head), &(*p1), &(v606_12_tail).make_space());
              map_map_kernels::compose(&(v607_9),&(v609_10))
            };
            drop(v607_9);
            let v607_12: Space = map_map_kernels::unite(&(v607_7),&(v607_11));
            v606_12.join_into((v607_12).clone());
            }
            v606_12_cursor.ascend(1);
          }
          drop(v606_12_cursor);
          drop(v606_11);
          map_map_kernels::compose(&(v601_10),&(v606_12))
        };
        drop(v601_10);
        let v601_14: Space = map_map_kernels::unite(&(v601_8),&(v601_13));
        v600_12.join_into((v601_14).clone());
        }
        v600_12_cursor.ascend(1);
      }
      drop(v600_12_cursor);
      drop(v600_6);
      drop(v600_11);
      map_map_kernels::compose(&(v589_10),&(v600_12))
    };
    drop(v589_10);
    let v589_14: Space = map_map_kernels::unite(&(v589_8),&(v589_13));
    v588_28.join_into((v589_14).clone());
    }
    v588_28_cursor.ascend(1);
  }
  drop(v588_28_cursor);
  drop(v588_21);
  (v588_28).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v610_8: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v610_9: Space = map_kernels::unwrap(&(v610_8),&(*p0));
  drop(v610_8);
  let mut v610_28 = Space::new();
  let mut v610_28_cursor = (*s0).read_zipper();
  for v610_28_byte in v610_28_cursor.child_mask().iter() {
    v610_28_cursor.descend_to_byte(v610_28_byte);
    {
    let v610_28_tail = v610_28_cursor.fork_read_zipper();
    let v610_28_head = Path::from_slice(&[v610_28_byte]);
    let v611_2: Space = singleton(&(v610_28_head));
    let v611_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v611_2));
    let v611_4: Space = if map_kernels::has_head(&(v611_3)) { singleton(&[]) } else { Space::new() };
    drop(v611_3);
    let v611_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v611_4));
    drop(v611_4);
    let v611_8: Space = if (v611_5).is_empty() { Space::new() } else {
      let v612_6: Path = concat_path(&(*p0),&(v610_28_head));
      let mut v612_7 = Space::new();
      let mut v612_7_cursor = (v610_28_tail).read_zipper();
      for v612_7_byte in v612_7_cursor.child_mask().iter() {
        v612_7_cursor.descend_to_byte(v612_7_byte);
        {
        let v612_7_tail = v612_7_cursor.fork_read_zipper();
        let v612_7_head = Path::from_slice(&[v612_7_byte]);
        let v613_2: Space = singleton(&(v612_7_head));
        let v613_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v613_2));
        let v613_4: Space = if map_kernels::has_head(&(v613_3)) { singleton(&[]) } else { Space::new() };
        drop(v613_3);
        let v613_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v613_4));
        drop(v613_4);
        let v613_8: Space = if (v613_5).is_empty() { Space::new() } else {
          let v614_6: Path = concat_path(&(v612_6),&(v612_7_head));
          let mut v614_7 = Space::new();
          let mut v614_7_cursor = (v612_7_tail).read_zipper();
          for v614_7_byte in v614_7_cursor.child_mask().iter() {
            v614_7_cursor.descend_to_byte(v614_7_byte);
            {
            let v614_7_tail = v614_7_cursor.fork_read_zipper();
            let v614_7_head = Path::from_slice(&[v614_7_byte]);
            let v615_2: Space = singleton(&(v614_7_head));
            let v615_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v615_2));
            let v615_4: Space = if map_kernels::has_head(&(v615_3)) { singleton(&[]) } else { Space::new() };
            drop(v615_3);
            let v615_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v615_4));
            drop(v615_4);
            let v615_8: Space = if (v615_5).is_empty() { Space::new() } else {
              let v616_6: Path = concat_path(&(v614_6),&(v614_7_head));
              let v616_7: Space = routine_44(c, &(v616_6), &(*p1), &(v614_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v615_5),&(v616_7))
            };
            drop(v615_5);
            let v615_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v615_2));
            drop(v615_2);
            let v615_10: Space = if map_kernels::has_head(&(v615_9)) { singleton(&[]) } else { Space::new() };
            drop(v615_9);
            let v615_12: Space = if (v615_10).is_empty() { Space::new() } else {
              let v617_6: Path = concat_path(&(v614_6),&(v614_7_head));
              let v617_11: Space = routine_45(c, &(v617_6), &(*p1), &(v614_7_tail).make_space(), &(*s1));
              drop(v617_6);
              map_map_kernels::compose(&(v615_10),&(v617_11))
            };
            drop(v615_10);
            let v615_13: Space = map_map_kernels::unite(&(v615_8),&(v615_12));
            v614_7.join_into((v615_13).clone());
            }
            v614_7_cursor.ascend(1);
          }
          drop(v614_7_cursor);
          map_map_kernels::compose(&(v613_5),&(v614_7))
        };
        drop(v613_5);
        let v613_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v613_2));
        drop(v613_2);
        let v613_10: Space = if map_kernels::has_head(&(v613_9)) { singleton(&[]) } else { Space::new() };
        drop(v613_9);
        let v613_12: Space = if (v613_10).is_empty() { Space::new() } else {
          let v618_6: Path = concat_path(&(v612_6),&(v612_7_head));
          let mut v618_11 = Space::new();
          let mut v618_11_cursor = (v612_7_tail).read_zipper();
          for v618_11_byte in v618_11_cursor.child_mask().iter() {
            v618_11_cursor.descend_to_byte(v618_11_byte);
            {
            let v618_11_tail = v618_11_cursor.fork_read_zipper();
            let v618_11_head = Path::from_slice(&[v618_11_byte]);
            let v619_2: Space = singleton(&(v618_11_head));
            let v619_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v619_2));
            let v619_4: Space = if map_kernels::has_head(&(v619_3)) { singleton(&[]) } else { Space::new() };
            drop(v619_3);
            let v619_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v619_4));
            drop(v619_4);
            let v619_8: Space = if (v619_5).is_empty() { Space::new() } else {
              let v620_6: Path = concat_path(&(v618_6),&(v618_11_head));
              let v620_7: Space = routine_44(c, &(v620_6), &(*p1), &(v618_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v619_5),&(v620_7))
            };
            drop(v619_5);
            let v619_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v619_2));
            drop(v619_2);
            let v619_10: Space = if map_kernels::has_head(&(v619_9)) { singleton(&[]) } else { Space::new() };
            drop(v619_9);
            let v619_12: Space = if (v619_10).is_empty() { Space::new() } else {
              let v621_6: Path = concat_path(&(v618_6),&(v618_11_head));
              let v621_11: Space = routine_10(c, &(v621_6), &(*p1), &(v618_11_tail).make_space(), &(*s1));
              drop(v621_6);
              map_map_kernels::compose(&(v619_10),&(v621_11))
            };
            drop(v619_10);
            let v619_13: Space = map_map_kernels::unite(&(v619_8),&(v619_12));
            v618_11.join_into((v619_13).clone());
            }
            v618_11_cursor.ascend(1);
          }
          drop(v618_11_cursor);
          drop(v618_6);
          map_map_kernels::compose(&(v613_10),&(v618_11))
        };
        drop(v613_10);
        let v613_13: Space = map_map_kernels::unite(&(v613_8),&(v613_12));
        v612_7.join_into((v613_13).clone());
        }
        v612_7_cursor.ascend(1);
      }
      drop(v612_7_cursor);
      drop(v612_6);
      map_map_kernels::compose(&(v611_5),&(v612_7))
    };
    drop(v611_5);
    let v611_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v611_2));
    drop(v611_2);
    let v611_10: Space = if map_kernels::has_head(&(v611_9)) { singleton(&[]) } else { Space::new() };
    drop(v611_9);
    let v611_13: Space = if (v611_10).is_empty() { Space::new() } else {
      let v622_11: Space = map_kernels::unwrap(&(v610_9),&(v610_28_head));
      let mut v622_12 = Space::new();
      let mut v622_12_cursor = (v622_11).read_zipper();
      for v622_12_byte in v622_12_cursor.child_mask().iter() {
        v622_12_cursor.descend_to_byte(v622_12_byte);
        {
        let v622_12_tail = v622_12_cursor.fork_read_zipper();
        let v622_12_head = Path::from_slice(&[v622_12_byte]);
        let v623_2: Space = singleton(&(v622_12_head));
        let v623_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v623_2));
        let v623_4: Space = if map_kernels::has_head(&(v623_3)) { singleton(&[]) } else { Space::new() };
        drop(v623_3);
        let v623_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v623_4));
        drop(v623_4);
        let v623_7: Space = if (v623_5).is_empty() { Space::new() } else {
          let mut v624_6 = Space::new();
          let mut v624_6_cursor = (v622_12_tail).read_zipper();
          for v624_6_byte in v624_6_cursor.child_mask().iter() {
            v624_6_cursor.descend_to_byte(v624_6_byte);
            {
            let v624_6_tail = v624_6_cursor.fork_read_zipper();
            let v624_6_head = Path::from_slice(&[v624_6_byte]);
            let v625_2: Space = singleton(&(v624_6_head));
            let v625_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v625_2));
            let v625_4: Space = if map_kernels::has_head(&(v625_3)) { singleton(&[]) } else { Space::new() };
            drop(v625_3);
            let v625_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v625_4));
            drop(v625_4);
            let v625_8: Space = if (v625_5).is_empty() { Space::new() } else {
              let v626_6: Path = concat_path(&(v622_12_head),&(v624_6_head));
              let v626_7: Space = routine_17(c, &(v626_6), &(*p1), &(v624_6_tail).make_space());
              map_map_kernels::compose(&(v625_5),&(v626_7))
            };
            drop(v625_5);
            let v625_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v625_2));
            drop(v625_2);
            let v625_10: Space = if map_kernels::has_head(&(v625_9)) { singleton(&[]) } else { Space::new() };
            drop(v625_9);
            let v625_12: Space = if (v625_10).is_empty() { Space::new() } else {
              let v627_6: Path = concat_path(&(v622_12_head),&(v624_6_head));
              let v627_11: Space = routine_18(c, &(v627_6), &(*p1), &(v624_6_tail).make_space());
              drop(v627_6);
              map_map_kernels::compose(&(v625_10),&(v627_11))
            };
            drop(v625_10);
            let v625_13: Space = map_map_kernels::unite(&(v625_8),&(v625_12));
            v624_6.join_into((v625_13).clone());
            }
            v624_6_cursor.ascend(1);
          }
          drop(v624_6_cursor);
          map_map_kernels::compose(&(v623_5),&(v624_6))
        };
        drop(v623_5);
        let v623_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v623_2));
        drop(v623_2);
        let v623_9: Space = if map_kernels::has_head(&(v623_8)) { singleton(&[]) } else { Space::new() };
        drop(v623_8);
        let v623_11: Space = if (v623_9).is_empty() { Space::new() } else {
          let mut v628_10 = Space::new();
          let mut v628_10_cursor = (v622_12_tail).read_zipper();
          for v628_10_byte in v628_10_cursor.child_mask().iter() {
            v628_10_cursor.descend_to_byte(v628_10_byte);
            {
            let v628_10_tail = v628_10_cursor.fork_read_zipper();
            let v628_10_head = Path::from_slice(&[v628_10_byte]);
            let v629_2: Space = singleton(&(v628_10_head));
            let v629_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v629_2));
            let v629_4: Space = if map_kernels::has_head(&(v629_3)) { singleton(&[]) } else { Space::new() };
            drop(v629_3);
            let v629_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v629_4));
            drop(v629_4);
            let v629_8: Space = if (v629_5).is_empty() { Space::new() } else {
              let v630_6: Path = concat_path(&(v622_12_head),&(v628_10_head));
              let v630_7: Space = routine_17(c, &(v630_6), &(*p1), &(v628_10_tail).make_space());
              map_map_kernels::compose(&(v629_5),&(v630_7))
            };
            drop(v629_5);
            let v629_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v629_2));
            drop(v629_2);
            let v629_10: Space = if map_kernels::has_head(&(v629_9)) { singleton(&[]) } else { Space::new() };
            drop(v629_9);
            let v629_12: Space = if (v629_10).is_empty() { Space::new() } else {
              let v631_6: Path = concat_path(&(v622_12_head),&(v628_10_head));
              let v631_11: Space = routine_19(c, &(v631_6), &(*p1), &(v628_10_tail).make_space());
              drop(v631_6);
              map_map_kernels::compose(&(v629_10),&(v631_11))
            };
            drop(v629_10);
            let v629_13: Space = map_map_kernels::unite(&(v629_8),&(v629_12));
            v628_10.join_into((v629_13).clone());
            }
            v628_10_cursor.ascend(1);
          }
          drop(v628_10_cursor);
          map_map_kernels::compose(&(v623_9),&(v628_10))
        };
        drop(v623_9);
        let v623_12: Space = map_map_kernels::unite(&(v623_7),&(v623_11));
        v622_12.join_into((v623_12).clone());
        }
        v622_12_cursor.ascend(1);
      }
      drop(v622_12_cursor);
      drop(v622_11);
      map_map_kernels::compose(&(v611_10),&(v622_12))
    };
    drop(v611_10);
    let v611_14: Space = map_map_kernels::unite(&(v611_8),&(v611_13));
    v610_28.join_into((v611_14).clone());
    }
    v610_28_cursor.ascend(1);
  }
  drop(v610_28_cursor);
  drop(v610_9);
  (v610_28).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v632_21 = Space::new();
  let mut v632_21_cursor = (*s0).read_zipper();
  for v632_21_byte in v632_21_cursor.child_mask().iter() {
    v632_21_cursor.descend_to_byte(v632_21_byte);
    {
    let v632_21_tail = v632_21_cursor.fork_read_zipper();
    let v632_21_head = Path::from_slice(&[v632_21_byte]);
    let v633_2: Space = singleton(&(v632_21_head));
    let v633_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v633_2));
    let v633_4: Space = if map_kernels::has_head(&(v633_3)) { singleton(&[]) } else { Space::new() };
    drop(v633_3);
    let v633_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v633_4));
    drop(v633_4);
    let v633_8: Space = if (v633_5).is_empty() { Space::new() } else {
      let v634_6: Path = concat_path(&(*p0),&(v632_21_head));
      let mut v634_7 = Space::new();
      let mut v634_7_cursor = (v632_21_tail).read_zipper();
      for v634_7_byte in v634_7_cursor.child_mask().iter() {
        v634_7_cursor.descend_to_byte(v634_7_byte);
        {
        let v634_7_tail = v634_7_cursor.fork_read_zipper();
        let v634_7_head = Path::from_slice(&[v634_7_byte]);
        let v635_2: Space = singleton(&(v634_7_head));
        let v635_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v635_2));
        let v635_4: Space = if map_kernels::has_head(&(v635_3)) { singleton(&[]) } else { Space::new() };
        drop(v635_3);
        let v635_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v635_4));
        drop(v635_4);
        let v635_8: Space = if (v635_5).is_empty() { Space::new() } else {
          let v636_6: Path = concat_path(&(v634_6),&(v634_7_head));
          let mut v636_7 = Space::new();
          let mut v636_7_cursor = (v634_7_tail).read_zipper();
          for v636_7_byte in v636_7_cursor.child_mask().iter() {
            v636_7_cursor.descend_to_byte(v636_7_byte);
            {
            let v636_7_tail = v636_7_cursor.fork_read_zipper();
            let v636_7_head = Path::from_slice(&[v636_7_byte]);
            let v637_2: Space = singleton(&(v636_7_head));
            let v637_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v637_2));
            let v637_4: Space = if map_kernels::has_head(&(v637_3)) { singleton(&[]) } else { Space::new() };
            drop(v637_3);
            let v637_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v637_4));
            drop(v637_4);
            let v637_8: Space = if (v637_5).is_empty() { Space::new() } else {
              let v638_6: Path = concat_path(&(v636_6),&(v636_7_head));
              let v638_7: Space = routine_46(c, &(v638_6), &(*p1), &(v636_7_tail).make_space());
              map_map_kernels::compose(&(v637_5),&(v638_7))
            };
            drop(v637_5);
            let v637_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v637_2));
            drop(v637_2);
            let v637_10: Space = if map_kernels::has_head(&(v637_9)) { singleton(&[]) } else { Space::new() };
            drop(v637_9);
            let v637_12: Space = if (v637_10).is_empty() { Space::new() } else {
              let v639_6: Path = concat_path(&(v636_6),&(v636_7_head));
              let v639_11: Space = routine_47(c, &(v639_6), &(*p1), &(v636_7_tail).make_space());
              drop(v639_6);
              map_map_kernels::compose(&(v637_10),&(v639_11))
            };
            drop(v637_10);
            let v637_13: Space = map_map_kernels::unite(&(v637_8),&(v637_12));
            v636_7.join_into((v637_13).clone());
            }
            v636_7_cursor.ascend(1);
          }
          drop(v636_7_cursor);
          map_map_kernels::compose(&(v635_5),&(v636_7))
        };
        drop(v635_5);
        let v635_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v635_2));
        drop(v635_2);
        let v635_10: Space = if map_kernels::has_head(&(v635_9)) { singleton(&[]) } else { Space::new() };
        drop(v635_9);
        let v635_12: Space = if (v635_10).is_empty() { Space::new() } else {
          let v640_6: Path = concat_path(&(v634_6),&(v634_7_head));
          let mut v640_11 = Space::new();
          let mut v640_11_cursor = (v634_7_tail).read_zipper();
          for v640_11_byte in v640_11_cursor.child_mask().iter() {
            v640_11_cursor.descend_to_byte(v640_11_byte);
            {
            let v640_11_tail = v640_11_cursor.fork_read_zipper();
            let v640_11_head = Path::from_slice(&[v640_11_byte]);
            let v641_2: Space = singleton(&(v640_11_head));
            let v641_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v641_2));
            let v641_4: Space = if map_kernels::has_head(&(v641_3)) { singleton(&[]) } else { Space::new() };
            drop(v641_3);
            let v641_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v641_4));
            drop(v641_4);
            let v641_8: Space = if (v641_5).is_empty() { Space::new() } else {
              let v642_6: Path = concat_path(&(v640_6),&(v640_11_head));
              let v642_7: Space = routine_46(c, &(v642_6), &(*p1), &(v640_11_tail).make_space());
              map_map_kernels::compose(&(v641_5),&(v642_7))
            };
            drop(v641_5);
            let v641_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v641_2));
            drop(v641_2);
            let v641_10: Space = if map_kernels::has_head(&(v641_9)) { singleton(&[]) } else { Space::new() };
            drop(v641_9);
            let v641_12: Space = if (v641_10).is_empty() { Space::new() } else {
              let v643_6: Path = concat_path(&(v640_6),&(v640_11_head));
              let v643_11: Space = routine_19(c, &(v643_6), &(*p1), &(v640_11_tail).make_space());
              drop(v643_6);
              map_map_kernels::compose(&(v641_10),&(v643_11))
            };
            drop(v641_10);
            let v641_13: Space = map_map_kernels::unite(&(v641_8),&(v641_12));
            v640_11.join_into((v641_13).clone());
            }
            v640_11_cursor.ascend(1);
          }
          drop(v640_11_cursor);
          drop(v640_6);
          map_map_kernels::compose(&(v635_10),&(v640_11))
        };
        drop(v635_10);
        let v635_13: Space = map_map_kernels::unite(&(v635_8),&(v635_12));
        v634_7.join_into((v635_13).clone());
        }
        v634_7_cursor.ascend(1);
      }
      drop(v634_7_cursor);
      map_map_kernels::compose(&(v633_5),&(v634_7))
    };
    drop(v633_5);
    let v633_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v633_2));
    drop(v633_2);
    let v633_10: Space = if map_kernels::has_head(&(v633_9)) { singleton(&[]) } else { Space::new() };
    drop(v633_9);
    let v633_12: Space = if (v633_10).is_empty() { Space::new() } else {
      let v644_6: Path = concat_path(&(*p0),&(v632_21_head));
      let mut v644_11 = Space::new();
      let mut v644_11_cursor = (v632_21_tail).read_zipper();
      for v644_11_byte in v644_11_cursor.child_mask().iter() {
        v644_11_cursor.descend_to_byte(v644_11_byte);
        {
        let v644_11_tail = v644_11_cursor.fork_read_zipper();
        let v644_11_head = Path::from_slice(&[v644_11_byte]);
        let v645_2: Space = singleton(&(v644_11_head));
        let v645_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v645_2));
        let v645_4: Space = if map_kernels::has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
        drop(v645_3);
        let v645_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v645_4));
        drop(v645_4);
        let v645_8: Space = if (v645_5).is_empty() { Space::new() } else {
          let v646_6: Path = concat_path(&(v644_6),&(v644_11_head));
          let mut v646_7 = Space::new();
          let mut v646_7_cursor = (v644_11_tail).read_zipper();
          for v646_7_byte in v646_7_cursor.child_mask().iter() {
            v646_7_cursor.descend_to_byte(v646_7_byte);
            {
            let v646_7_tail = v646_7_cursor.fork_read_zipper();
            let v646_7_head = Path::from_slice(&[v646_7_byte]);
            let v647_2: Space = singleton(&(v646_7_head));
            let v647_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v647_2));
            let v647_4: Space = if map_kernels::has_head(&(v647_3)) { singleton(&[]) } else { Space::new() };
            drop(v647_3);
            let v647_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v647_4));
            drop(v647_4);
            let v647_8: Space = if (v647_5).is_empty() { Space::new() } else {
              let v648_6: Path = concat_path(&(v646_6),&(v646_7_head));
              let v648_7: Space = routine_46(c, &(v648_6), &(*p1), &(v646_7_tail).make_space());
              map_map_kernels::compose(&(v647_5),&(v648_7))
            };
            drop(v647_5);
            let v647_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v647_2));
            drop(v647_2);
            let v647_10: Space = if map_kernels::has_head(&(v647_9)) { singleton(&[]) } else { Space::new() };
            drop(v647_9);
            let v647_12: Space = if (v647_10).is_empty() { Space::new() } else {
              let v649_6: Path = concat_path(&(v646_6),&(v646_7_head));
              let v649_11: Space = routine_47(c, &(v649_6), &(*p1), &(v646_7_tail).make_space());
              drop(v649_6);
              map_map_kernels::compose(&(v647_10),&(v649_11))
            };
            drop(v647_10);
            let v647_13: Space = map_map_kernels::unite(&(v647_8),&(v647_12));
            v646_7.join_into((v647_13).clone());
            }
            v646_7_cursor.ascend(1);
          }
          drop(v646_7_cursor);
          map_map_kernels::compose(&(v645_5),&(v646_7))
        };
        drop(v645_5);
        let v645_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v645_2));
        drop(v645_2);
        let v645_10: Space = if map_kernels::has_head(&(v645_9)) { singleton(&[]) } else { Space::new() };
        drop(v645_9);
        let v645_11: Space = map_view_kernels::compose(&(v645_10),&(v644_11_tail));
        drop(v645_10);
        let v650_6: Path = concat_path(&(v644_6),&(v644_11_head));
        let v645_12: Space = map_kernels::wrap(&(v645_11),&(v650_6));
        drop(v645_11);
        let v645_13: Space = map_kernels::wrap(&(v645_12),&(*p1));
        drop(v645_12);
        let v645_14: Space = map_map_kernels::unite(&(v645_8),&(v645_13));
        drop(v645_13);
        v644_11.join_into((v645_14).clone());
        }
        v644_11_cursor.ascend(1);
      }
      drop(v644_11_cursor);
      drop(v644_6);
      map_map_kernels::compose(&(v633_10),&(v644_11))
    };
    drop(v633_10);
    let v633_13: Space = map_map_kernels::unite(&(v633_8),&(v633_12));
    v632_21.join_into((v633_13).clone());
    }
    v632_21_cursor.ascend(1);
  }
  drop(v632_21_cursor);
  (v632_21).clone()
}

fn routine_33(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v651_15 = Space::new();
  let mut v651_15_cursor = (*s0).read_zipper();
  for v651_15_byte in v651_15_cursor.child_mask().iter() {
    v651_15_cursor.descend_to_byte(v651_15_byte);
    {
    let v651_15_tail = v651_15_cursor.fork_read_zipper();
    let v651_15_head = Path::from_slice(&[v651_15_byte]);
    let v652_2: Space = singleton(&(v651_15_head));
    let v652_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v652_2));
    let v652_4: Space = if map_kernels::has_head(&(v652_3)) { singleton(&[]) } else { Space::new() };
    drop(v652_3);
    let v652_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v652_4));
    drop(v652_4);
    let v652_8: Space = if (v652_5).is_empty() { Space::new() } else {
      let v653_6: Path = concat_path(&(*p0),&(v651_15_head));
      let mut v653_7 = Space::new();
      let mut v653_7_cursor = (v651_15_tail).read_zipper();
      for v653_7_byte in v653_7_cursor.child_mask().iter() {
        v653_7_cursor.descend_to_byte(v653_7_byte);
        {
        let v653_7_tail = v653_7_cursor.fork_read_zipper();
        let v653_7_head = Path::from_slice(&[v653_7_byte]);
        let v654_2: Space = singleton(&(v653_7_head));
        let v654_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v654_2));
        let v654_4: Space = if map_kernels::has_head(&(v654_3)) { singleton(&[]) } else { Space::new() };
        drop(v654_3);
        let v654_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v654_4));
        drop(v654_4);
        let v654_8: Space = if (v654_5).is_empty() { Space::new() } else {
          let v655_6: Path = concat_path(&(v653_6),&(v653_7_head));
          let mut v655_7 = Space::new();
          let mut v655_7_cursor = (v653_7_tail).read_zipper();
          for v655_7_byte in v655_7_cursor.child_mask().iter() {
            v655_7_cursor.descend_to_byte(v655_7_byte);
            {
            let v655_7_tail = v655_7_cursor.fork_read_zipper();
            let v655_7_head = Path::from_slice(&[v655_7_byte]);
            let v656_2: Space = singleton(&(v655_7_head));
            let v656_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v656_2));
            let v656_4: Space = if map_kernels::has_head(&(v656_3)) { singleton(&[]) } else { Space::new() };
            drop(v656_3);
            let v656_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v656_4));
            drop(v656_4);
            let v656_8: Space = if (v656_5).is_empty() { Space::new() } else {
              let v657_6: Path = concat_path(&(v655_6),&(v655_7_head));
              let v657_7: Space = routine_46(c, &(v657_6), &(*p1), &(v655_7_tail).make_space());
              map_map_kernels::compose(&(v656_5),&(v657_7))
            };
            drop(v656_5);
            let v656_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v656_2));
            drop(v656_2);
            let v656_10: Space = if map_kernels::has_head(&(v656_9)) { singleton(&[]) } else { Space::new() };
            drop(v656_9);
            let v656_12: Space = if (v656_10).is_empty() { Space::new() } else {
              let v658_6: Path = concat_path(&(v655_6),&(v655_7_head));
              let v658_11: Space = routine_47(c, &(v658_6), &(*p1), &(v655_7_tail).make_space());
              drop(v658_6);
              map_map_kernels::compose(&(v656_10),&(v658_11))
            };
            drop(v656_10);
            let v656_13: Space = map_map_kernels::unite(&(v656_8),&(v656_12));
            v655_7.join_into((v656_13).clone());
            }
            v655_7_cursor.ascend(1);
          }
          drop(v655_7_cursor);
          map_map_kernels::compose(&(v654_5),&(v655_7))
        };
        drop(v654_5);
        let v654_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v654_2));
        drop(v654_2);
        let v654_10: Space = if map_kernels::has_head(&(v654_9)) { singleton(&[]) } else { Space::new() };
        drop(v654_9);
        let v654_12: Space = if (v654_10).is_empty() { Space::new() } else {
          let v659_6: Path = concat_path(&(v653_6),&(v653_7_head));
          let mut v659_11 = Space::new();
          let mut v659_11_cursor = (v653_7_tail).read_zipper();
          for v659_11_byte in v659_11_cursor.child_mask().iter() {
            v659_11_cursor.descend_to_byte(v659_11_byte);
            {
            let v659_11_tail = v659_11_cursor.fork_read_zipper();
            let v659_11_head = Path::from_slice(&[v659_11_byte]);
            let v660_2: Space = singleton(&(v659_11_head));
            let v660_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v660_2));
            let v660_4: Space = if map_kernels::has_head(&(v660_3)) { singleton(&[]) } else { Space::new() };
            drop(v660_3);
            let v660_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v660_4));
            drop(v660_4);
            let v660_8: Space = if (v660_5).is_empty() { Space::new() } else {
              let v661_6: Path = concat_path(&(v659_6),&(v659_11_head));
              let v661_7: Space = routine_46(c, &(v661_6), &(*p1), &(v659_11_tail).make_space());
              map_map_kernels::compose(&(v660_5),&(v661_7))
            };
            drop(v660_5);
            let v660_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v660_2));
            drop(v660_2);
            let v660_10: Space = if map_kernels::has_head(&(v660_9)) { singleton(&[]) } else { Space::new() };
            drop(v660_9);
            let v660_12: Space = if (v660_10).is_empty() { Space::new() } else {
              let v662_6: Path = concat_path(&(v659_6),&(v659_11_head));
              let v662_11: Space = routine_19(c, &(v662_6), &(*p1), &(v659_11_tail).make_space());
              drop(v662_6);
              map_map_kernels::compose(&(v660_10),&(v662_11))
            };
            drop(v660_10);
            let v660_13: Space = map_map_kernels::unite(&(v660_8),&(v660_12));
            v659_11.join_into((v660_13).clone());
            }
            v659_11_cursor.ascend(1);
          }
          drop(v659_11_cursor);
          drop(v659_6);
          map_map_kernels::compose(&(v654_10),&(v659_11))
        };
        drop(v654_10);
        let v654_13: Space = map_map_kernels::unite(&(v654_8),&(v654_12));
        v653_7.join_into((v654_13).clone());
        }
        v653_7_cursor.ascend(1);
      }
      drop(v653_7_cursor);
      map_map_kernels::compose(&(v652_5),&(v653_7))
    };
    drop(v652_5);
    let v652_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v652_2));
    drop(v652_2);
    let v652_10: Space = if map_kernels::has_head(&(v652_9)) { singleton(&[]) } else { Space::new() };
    drop(v652_9);
    let v652_11: Space = map_view_kernels::compose(&(v652_10),&(v651_15_tail));
    drop(v652_10);
    let v663_6: Path = concat_path(&(*p0),&(v651_15_head));
    let v652_12: Space = map_kernels::wrap(&(v652_11),&(v663_6));
    drop(v652_11);
    let v652_13: Space = map_kernels::wrap(&(v652_12),&(*p1));
    drop(v652_12);
    let v652_14: Space = map_map_kernels::unite(&(v652_8),&(v652_13));
    drop(v652_13);
    v651_15.join_into((v652_14).clone());
    }
    v651_15_cursor.ascend(1);
  }
  drop(v651_15_cursor);
  (v651_15).clone()
}

fn routine_34(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v664_3 = Space::new();
  let mut v664_3_cursor = (*s0).read_zipper();
  for v664_3_byte in v664_3_cursor.child_mask().iter() {
    v664_3_cursor.descend_to_byte(v664_3_byte);
    {
    let v664_3_tail = v664_3_cursor.fork_read_zipper();
    let v664_3_head = Path::from_slice(&[v664_3_byte]);
    let v665_2: Space = Space::new();
    v664_3.join_into((v665_2).clone());
    }
    v664_3_cursor.ascend(1);
  }
  drop(v664_3_cursor);
  (v664_3).clone()
}

fn routine_35(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v666_13 = Space::new();
  let mut v666_13_cursor = (*s0).read_zipper();
  for v666_13_byte in v666_13_cursor.child_mask().iter() {
    v666_13_cursor.descend_to_byte(v666_13_byte);
    {
    let v666_13_tail = v666_13_cursor.fork_read_zipper();
    let v666_13_head = Path::from_slice(&[v666_13_byte]);
    let v667_2: Space = singleton(&(v666_13_head));
    let v667_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v667_2));
    drop(v667_2);
    let v667_4: Space = if map_kernels::has_head(&(v667_3)) { singleton(&[]) } else { Space::new() };
    drop(v667_3);
    let v667_7: Space = if (v667_4).is_empty() { Space::new() } else {
      let v668_5: Path = concat_path(&(*p0),&(v666_13_head));
      let mut v668_6 = Space::new();
      let mut v668_6_cursor = (v666_13_tail).read_zipper();
      for v668_6_byte in v668_6_cursor.child_mask().iter() {
        v668_6_cursor.descend_to_byte(v668_6_byte);
        {
        let v668_6_tail = v668_6_cursor.fork_read_zipper();
        let v668_6_head = Path::from_slice(&[v668_6_byte]);
        let v669_2: Space = singleton(&(v668_6_head));
        let v669_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v669_2));
        let v669_4: Space = if map_kernels::has_head(&(v669_3)) { singleton(&[]) } else { Space::new() };
        drop(v669_3);
        let v669_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v669_4));
        drop(v669_4);
        let v669_7: Space = if (v669_5).is_empty() { Space::new() } else {
          let mut v670_6 = Space::new();
          let mut v670_6_cursor = (v668_6_tail).read_zipper();
          for v670_6_byte in v670_6_cursor.child_mask().iter() {
            v670_6_cursor.descend_to_byte(v670_6_byte);
            {
            let v670_6_tail = v670_6_cursor.fork_read_zipper();
            let v670_6_head = Path::from_slice(&[v670_6_byte]);
            let v671_2: Space = singleton(&(v670_6_head));
            let v671_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v671_2));
            let v671_4: Space = if map_kernels::has_head(&(v671_3)) { singleton(&[]) } else { Space::new() };
            drop(v671_3);
            let v671_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v671_4));
            drop(v671_4);
            let v671_8: Space = if (v671_5).is_empty() { Space::new() } else {
              let v672_6: Path = concat_path(&(v668_6_head),&(v670_6_head));
              let v672_7: Space = routine_8(c, &(v672_6), &(v668_5), &(v670_6_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v671_5),&(v672_7))
            };
            drop(v671_5);
            let v671_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v671_2));
            drop(v671_2);
            let v671_10: Space = if map_kernels::has_head(&(v671_9)) { singleton(&[]) } else { Space::new() };
            drop(v671_9);
            let v671_12: Space = if (v671_10).is_empty() { Space::new() } else {
              let v673_6: Path = concat_path(&(v668_6_head),&(v670_6_head));
              let v673_11: Space = routine_9(c, &(v673_6), &(v668_5), &(v670_6_tail).make_space(), &(*s1));
              drop(v673_6);
              map_map_kernels::compose(&(v671_10),&(v673_11))
            };
            drop(v671_10);
            let v671_13: Space = map_map_kernels::unite(&(v671_8),&(v671_12));
            v670_6.join_into((v671_13).clone());
            }
            v670_6_cursor.ascend(1);
          }
          drop(v670_6_cursor);
          map_map_kernels::compose(&(v669_5),&(v670_6))
        };
        drop(v669_5);
        let v669_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v669_2));
        drop(v669_2);
        let v669_9: Space = if map_kernels::has_head(&(v669_8)) { singleton(&[]) } else { Space::new() };
        drop(v669_8);
        let v669_11: Space = if (v669_9).is_empty() { Space::new() } else {
          let mut v674_10 = Space::new();
          let mut v674_10_cursor = (v668_6_tail).read_zipper();
          for v674_10_byte in v674_10_cursor.child_mask().iter() {
            v674_10_cursor.descend_to_byte(v674_10_byte);
            {
            let v674_10_tail = v674_10_cursor.fork_read_zipper();
            let v674_10_head = Path::from_slice(&[v674_10_byte]);
            let v675_2: Space = singleton(&(v674_10_head));
            let v675_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v675_2));
            let v675_4: Space = if map_kernels::has_head(&(v675_3)) { singleton(&[]) } else { Space::new() };
            drop(v675_3);
            let v675_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v675_4));
            drop(v675_4);
            let v675_8: Space = if (v675_5).is_empty() { Space::new() } else {
              let v676_6: Path = concat_path(&(v668_6_head),&(v674_10_head));
              let v676_7: Space = routine_8(c, &(v676_6), &(v668_5), &(v674_10_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v675_5),&(v676_7))
            };
            drop(v675_5);
            let v675_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v675_2));
            drop(v675_2);
            let v675_10: Space = if map_kernels::has_head(&(v675_9)) { singleton(&[]) } else { Space::new() };
            drop(v675_9);
            let v675_12: Space = if (v675_10).is_empty() { Space::new() } else {
              let v677_6: Path = concat_path(&(v668_6_head),&(v674_10_head));
              let v677_11: Space = routine_10(c, &(v677_6), &(v668_5), &(v674_10_tail).make_space(), &(*s1));
              drop(v677_6);
              map_map_kernels::compose(&(v675_10),&(v677_11))
            };
            drop(v675_10);
            let v675_13: Space = map_map_kernels::unite(&(v675_8),&(v675_12));
            v674_10.join_into((v675_13).clone());
            }
            v674_10_cursor.ascend(1);
          }
          drop(v674_10_cursor);
          map_map_kernels::compose(&(v669_9),&(v674_10))
        };
        drop(v669_9);
        let v669_12: Space = map_map_kernels::unite(&(v669_7),&(v669_11));
        v668_6.join_into((v669_12).clone());
        }
        v668_6_cursor.ascend(1);
      }
      drop(v668_6_cursor);
      drop(v668_5);
      map_map_kernels::compose(&(v667_4),&(v668_6))
    };
    drop(v667_4);
    v666_13.join_into((v667_7).clone());
    }
    v666_13_cursor.ascend(1);
  }
  drop(v666_13_cursor);
  (v666_13).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v678_20: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v678_21: Space = map_kernels::unwrap(&(v678_20),&(*p0));
  drop(v678_20);
  let mut v678_28 = Space::new();
  let mut v678_28_cursor = (*s0).read_zipper();
  for v678_28_byte in v678_28_cursor.child_mask().iter() {
    v678_28_cursor.descend_to_byte(v678_28_byte);
    {
    let v678_28_tail = v678_28_cursor.fork_read_zipper();
    let v678_28_head = Path::from_slice(&[v678_28_byte]);
    let v679_2: Space = singleton(&(v678_28_head));
    let v679_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v679_2));
    let v679_4: Space = if map_kernels::has_head(&(v679_3)) { singleton(&[]) } else { Space::new() };
    drop(v679_3);
    let v679_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v679_4));
    drop(v679_4);
    let v679_8: Space = if (v679_5).is_empty() { Space::new() } else {
      let v680_6: Path = concat_path(&(*p0),&(v678_28_head));
      let mut v680_7 = Space::new();
      let mut v680_7_cursor = (v678_28_tail).read_zipper();
      for v680_7_byte in v680_7_cursor.child_mask().iter() {
        v680_7_cursor.descend_to_byte(v680_7_byte);
        {
        let v680_7_tail = v680_7_cursor.fork_read_zipper();
        let v680_7_head = Path::from_slice(&[v680_7_byte]);
        let v681_2: Space = singleton(&(v680_7_head));
        let v681_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v681_2));
        let v681_4: Space = if map_kernels::has_head(&(v681_3)) { singleton(&[]) } else { Space::new() };
        drop(v681_3);
        let v681_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v681_4));
        drop(v681_4);
        let v681_8: Space = if (v681_5).is_empty() { Space::new() } else {
          let v682_6: Path = concat_path(&(v680_6),&(v680_7_head));
          let mut v682_7 = Space::new();
          let mut v682_7_cursor = (v680_7_tail).read_zipper();
          for v682_7_byte in v682_7_cursor.child_mask().iter() {
            v682_7_cursor.descend_to_byte(v682_7_byte);
            {
            let v682_7_tail = v682_7_cursor.fork_read_zipper();
            let v682_7_head = Path::from_slice(&[v682_7_byte]);
            let v683_2: Space = singleton(&(v682_7_head));
            let v683_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v683_2));
            let v683_4: Space = if map_kernels::has_head(&(v683_3)) { singleton(&[]) } else { Space::new() };
            drop(v683_3);
            let v683_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v683_4));
            drop(v683_4);
            let v683_8: Space = if (v683_5).is_empty() { Space::new() } else {
              let v684_6: Path = concat_path(&(v682_6),&(v682_7_head));
              let v684_7: Space = routine_48(c, &(v684_6), &(*p1), &(v682_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v683_5),&(v684_7))
            };
            drop(v683_5);
            let v683_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v683_2));
            drop(v683_2);
            let v683_10: Space = if map_kernels::has_head(&(v683_9)) { singleton(&[]) } else { Space::new() };
            drop(v683_9);
            let v683_12: Space = if (v683_10).is_empty() { Space::new() } else {
              let v685_6: Path = concat_path(&(v682_6),&(v682_7_head));
              let v685_11: Space = routine_49(c, &(v685_6), &(*p1), &(v682_7_tail).make_space(), &(*s1));
              drop(v685_6);
              map_map_kernels::compose(&(v683_10),&(v685_11))
            };
            drop(v683_10);
            let v683_13: Space = map_map_kernels::unite(&(v683_8),&(v683_12));
            v682_7.join_into((v683_13).clone());
            }
            v682_7_cursor.ascend(1);
          }
          drop(v682_7_cursor);
          map_map_kernels::compose(&(v681_5),&(v682_7))
        };
        drop(v681_5);
        let v681_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v681_2));
        drop(v681_2);
        let v681_10: Space = if map_kernels::has_head(&(v681_9)) { singleton(&[]) } else { Space::new() };
        drop(v681_9);
        let v681_12: Space = if (v681_10).is_empty() { Space::new() } else {
          let v686_6: Path = concat_path(&(v680_6),&(v680_7_head));
          let mut v686_11 = Space::new();
          let mut v686_11_cursor = (v680_7_tail).read_zipper();
          for v686_11_byte in v686_11_cursor.child_mask().iter() {
            v686_11_cursor.descend_to_byte(v686_11_byte);
            {
            let v686_11_tail = v686_11_cursor.fork_read_zipper();
            let v686_11_head = Path::from_slice(&[v686_11_byte]);
            let v687_2: Space = singleton(&(v686_11_head));
            let v687_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v687_2));
            let v687_4: Space = if map_kernels::has_head(&(v687_3)) { singleton(&[]) } else { Space::new() };
            drop(v687_3);
            let v687_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v687_4));
            drop(v687_4);
            let v687_8: Space = if (v687_5).is_empty() { Space::new() } else {
              let v688_6: Path = concat_path(&(v686_6),&(v686_11_head));
              let v688_7: Space = routine_48(c, &(v688_6), &(*p1), &(v686_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v687_5),&(v688_7))
            };
            drop(v687_5);
            let v687_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v687_2));
            drop(v687_2);
            let v687_10: Space = if map_kernels::has_head(&(v687_9)) { singleton(&[]) } else { Space::new() };
            drop(v687_9);
            let v687_12: Space = if (v687_10).is_empty() { Space::new() } else {
              let v689_6: Path = concat_path(&(v686_6),&(v686_11_head));
              let v689_11: Space = routine_10(c, &(v689_6), &(*p1), &(v686_11_tail).make_space(), &(*s1));
              drop(v689_6);
              map_map_kernels::compose(&(v687_10),&(v689_11))
            };
            drop(v687_10);
            let v687_13: Space = map_map_kernels::unite(&(v687_8),&(v687_12));
            v686_11.join_into((v687_13).clone());
            }
            v686_11_cursor.ascend(1);
          }
          drop(v686_11_cursor);
          drop(v686_6);
          map_map_kernels::compose(&(v681_10),&(v686_11))
        };
        drop(v681_10);
        let v681_13: Space = map_map_kernels::unite(&(v681_8),&(v681_12));
        v680_7.join_into((v681_13).clone());
        }
        v680_7_cursor.ascend(1);
      }
      drop(v680_7_cursor);
      map_map_kernels::compose(&(v679_5),&(v680_7))
    };
    drop(v679_5);
    let v679_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v679_2));
    drop(v679_2);
    let v679_10: Space = if map_kernels::has_head(&(v679_9)) { singleton(&[]) } else { Space::new() };
    drop(v679_9);
    let v679_13: Space = if (v679_10).is_empty() { Space::new() } else {
      let v690_6: Path = concat_path(&(*p0),&(v678_28_head));
      let v690_11: Space = map_kernels::unwrap(&(v678_21),&(v678_28_head));
      let mut v690_12 = Space::new();
      let mut v690_12_cursor = (v678_28_tail).read_zipper();
      for v690_12_byte in v690_12_cursor.child_mask().iter() {
        v690_12_cursor.descend_to_byte(v690_12_byte);
        {
        let v690_12_tail = v690_12_cursor.fork_read_zipper();
        let v690_12_head = Path::from_slice(&[v690_12_byte]);
        let v691_2: Space = singleton(&(v690_12_head));
        let v691_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v691_2));
        let v691_4: Space = if map_kernels::has_head(&(v691_3)) { singleton(&[]) } else { Space::new() };
        drop(v691_3);
        let v691_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v691_4));
        drop(v691_4);
        let v691_8: Space = if (v691_5).is_empty() { Space::new() } else {
          let v692_6: Path = concat_path(&(v690_6),&(v690_12_head));
          let mut v692_7 = Space::new();
          let mut v692_7_cursor = (v690_12_tail).read_zipper();
          for v692_7_byte in v692_7_cursor.child_mask().iter() {
            v692_7_cursor.descend_to_byte(v692_7_byte);
            {
            let v692_7_tail = v692_7_cursor.fork_read_zipper();
            let v692_7_head = Path::from_slice(&[v692_7_byte]);
            let v693_2: Space = singleton(&(v692_7_head));
            let v693_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v693_2));
            let v693_4: Space = if map_kernels::has_head(&(v693_3)) { singleton(&[]) } else { Space::new() };
            drop(v693_3);
            let v693_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v693_4));
            drop(v693_4);
            let v693_8: Space = if (v693_5).is_empty() { Space::new() } else {
              let v694_6: Path = concat_path(&(v692_6),&(v692_7_head));
              let v694_7: Space = routine_48(c, &(v694_6), &(*p1), &(v692_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v693_5),&(v694_7))
            };
            drop(v693_5);
            let v693_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v693_2));
            drop(v693_2);
            let v693_10: Space = if map_kernels::has_head(&(v693_9)) { singleton(&[]) } else { Space::new() };
            drop(v693_9);
            let v693_12: Space = if (v693_10).is_empty() { Space::new() } else {
              let v695_6: Path = concat_path(&(v692_6),&(v692_7_head));
              let v695_11: Space = routine_49(c, &(v695_6), &(*p1), &(v692_7_tail).make_space(), &(*s1));
              drop(v695_6);
              map_map_kernels::compose(&(v693_10),&(v695_11))
            };
            drop(v693_10);
            let v693_13: Space = map_map_kernels::unite(&(v693_8),&(v693_12));
            v692_7.join_into((v693_13).clone());
            }
            v692_7_cursor.ascend(1);
          }
          drop(v692_7_cursor);
          drop(v692_6);
          map_map_kernels::compose(&(v691_5),&(v692_7))
        };
        drop(v691_5);
        let v691_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v691_2));
        drop(v691_2);
        let v691_10: Space = if map_kernels::has_head(&(v691_9)) { singleton(&[]) } else { Space::new() };
        drop(v691_9);
        let v691_13: Space = if (v691_10).is_empty() { Space::new() } else {
          let v696_11: Space = map_kernels::unwrap(&(v690_11),&(v690_12_head));
          let mut v696_12 = Space::new();
          let mut v696_12_cursor = (v696_11).read_zipper();
          for v696_12_byte in v696_12_cursor.child_mask().iter() {
            v696_12_cursor.descend_to_byte(v696_12_byte);
            {
            let v696_12_tail = v696_12_cursor.fork_read_zipper();
            let v696_12_head = Path::from_slice(&[v696_12_byte]);
            let v697_2: Space = singleton(&(v696_12_head));
            let v697_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v697_2));
            let v697_4: Space = if map_kernels::has_head(&(v697_3)) { singleton(&[]) } else { Space::new() };
            drop(v697_3);
            let v697_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v697_4));
            drop(v697_4);
            let v697_7: Space = if (v697_5).is_empty() { Space::new() } else {
              let v698_6: Space = routine_13(c, &(v696_12_head), &(*p1), &(v696_12_tail).make_space());
              map_map_kernels::compose(&(v697_5),&(v698_6))
            };
            drop(v697_5);
            let v697_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v697_2));
            drop(v697_2);
            let v697_9: Space = if map_kernels::has_head(&(v697_8)) { singleton(&[]) } else { Space::new() };
            drop(v697_8);
            let v697_11: Space = if (v697_9).is_empty() { Space::new() } else {
              let v699_10: Space = routine_14(c, &(v696_12_head), &(*p1), &(v696_12_tail).make_space());
              map_map_kernels::compose(&(v697_9),&(v699_10))
            };
            drop(v697_9);
            let v697_12: Space = map_map_kernels::unite(&(v697_7),&(v697_11));
            v696_12.join_into((v697_12).clone());
            }
            v696_12_cursor.ascend(1);
          }
          drop(v696_12_cursor);
          drop(v696_11);
          map_map_kernels::compose(&(v691_10),&(v696_12))
        };
        drop(v691_10);
        let v691_14: Space = map_map_kernels::unite(&(v691_8),&(v691_13));
        v690_12.join_into((v691_14).clone());
        }
        v690_12_cursor.ascend(1);
      }
      drop(v690_12_cursor);
      drop(v690_6);
      drop(v690_11);
      map_map_kernels::compose(&(v679_10),&(v690_12))
    };
    drop(v679_10);
    let v679_14: Space = map_map_kernels::unite(&(v679_8),&(v679_13));
    v678_28.join_into((v679_14).clone());
    }
    v678_28_cursor.ascend(1);
  }
  drop(v678_28_cursor);
  drop(v678_21);
  (v678_28).clone()
}

fn routine_37(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v700_8: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v700_9: Space = map_kernels::unwrap(&(v700_8),&(*p0));
  drop(v700_8);
  let mut v700_28 = Space::new();
  let mut v700_28_cursor = (*s0).read_zipper();
  for v700_28_byte in v700_28_cursor.child_mask().iter() {
    v700_28_cursor.descend_to_byte(v700_28_byte);
    {
    let v700_28_tail = v700_28_cursor.fork_read_zipper();
    let v700_28_head = Path::from_slice(&[v700_28_byte]);
    let v701_2: Space = singleton(&(v700_28_head));
    let v701_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v701_2));
    let v701_4: Space = if map_kernels::has_head(&(v701_3)) { singleton(&[]) } else { Space::new() };
    drop(v701_3);
    let v701_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v701_4));
    drop(v701_4);
    let v701_8: Space = if (v701_5).is_empty() { Space::new() } else {
      let v702_6: Path = concat_path(&(*p0),&(v700_28_head));
      let mut v702_7 = Space::new();
      let mut v702_7_cursor = (v700_28_tail).read_zipper();
      for v702_7_byte in v702_7_cursor.child_mask().iter() {
        v702_7_cursor.descend_to_byte(v702_7_byte);
        {
        let v702_7_tail = v702_7_cursor.fork_read_zipper();
        let v702_7_head = Path::from_slice(&[v702_7_byte]);
        let v703_2: Space = singleton(&(v702_7_head));
        let v703_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v703_2));
        let v703_4: Space = if map_kernels::has_head(&(v703_3)) { singleton(&[]) } else { Space::new() };
        drop(v703_3);
        let v703_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v703_4));
        drop(v703_4);
        let v703_8: Space = if (v703_5).is_empty() { Space::new() } else {
          let v704_6: Path = concat_path(&(v702_6),&(v702_7_head));
          let mut v704_7 = Space::new();
          let mut v704_7_cursor = (v702_7_tail).read_zipper();
          for v704_7_byte in v704_7_cursor.child_mask().iter() {
            v704_7_cursor.descend_to_byte(v704_7_byte);
            {
            let v704_7_tail = v704_7_cursor.fork_read_zipper();
            let v704_7_head = Path::from_slice(&[v704_7_byte]);
            let v705_2: Space = singleton(&(v704_7_head));
            let v705_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v705_2));
            let v705_4: Space = if map_kernels::has_head(&(v705_3)) { singleton(&[]) } else { Space::new() };
            drop(v705_3);
            let v705_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v705_4));
            drop(v705_4);
            let v705_8: Space = if (v705_5).is_empty() { Space::new() } else {
              let v706_6: Path = concat_path(&(v704_6),&(v704_7_head));
              let v706_7: Space = routine_48(c, &(v706_6), &(*p1), &(v704_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v705_5),&(v706_7))
            };
            drop(v705_5);
            let v705_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v705_2));
            drop(v705_2);
            let v705_10: Space = if map_kernels::has_head(&(v705_9)) { singleton(&[]) } else { Space::new() };
            drop(v705_9);
            let v705_12: Space = if (v705_10).is_empty() { Space::new() } else {
              let v707_6: Path = concat_path(&(v704_6),&(v704_7_head));
              let v707_11: Space = routine_49(c, &(v707_6), &(*p1), &(v704_7_tail).make_space(), &(*s1));
              drop(v707_6);
              map_map_kernels::compose(&(v705_10),&(v707_11))
            };
            drop(v705_10);
            let v705_13: Space = map_map_kernels::unite(&(v705_8),&(v705_12));
            v704_7.join_into((v705_13).clone());
            }
            v704_7_cursor.ascend(1);
          }
          drop(v704_7_cursor);
          map_map_kernels::compose(&(v703_5),&(v704_7))
        };
        drop(v703_5);
        let v703_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v703_2));
        drop(v703_2);
        let v703_10: Space = if map_kernels::has_head(&(v703_9)) { singleton(&[]) } else { Space::new() };
        drop(v703_9);
        let v703_12: Space = if (v703_10).is_empty() { Space::new() } else {
          let v708_6: Path = concat_path(&(v702_6),&(v702_7_head));
          let mut v708_11 = Space::new();
          let mut v708_11_cursor = (v702_7_tail).read_zipper();
          for v708_11_byte in v708_11_cursor.child_mask().iter() {
            v708_11_cursor.descend_to_byte(v708_11_byte);
            {
            let v708_11_tail = v708_11_cursor.fork_read_zipper();
            let v708_11_head = Path::from_slice(&[v708_11_byte]);
            let v709_2: Space = singleton(&(v708_11_head));
            let v709_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v709_2));
            let v709_4: Space = if map_kernels::has_head(&(v709_3)) { singleton(&[]) } else { Space::new() };
            drop(v709_3);
            let v709_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v709_4));
            drop(v709_4);
            let v709_8: Space = if (v709_5).is_empty() { Space::new() } else {
              let v710_6: Path = concat_path(&(v708_6),&(v708_11_head));
              let v710_7: Space = routine_48(c, &(v710_6), &(*p1), &(v708_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v709_5),&(v710_7))
            };
            drop(v709_5);
            let v709_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v709_2));
            drop(v709_2);
            let v709_10: Space = if map_kernels::has_head(&(v709_9)) { singleton(&[]) } else { Space::new() };
            drop(v709_9);
            let v709_12: Space = if (v709_10).is_empty() { Space::new() } else {
              let v711_6: Path = concat_path(&(v708_6),&(v708_11_head));
              let v711_11: Space = routine_10(c, &(v711_6), &(*p1), &(v708_11_tail).make_space(), &(*s1));
              drop(v711_6);
              map_map_kernels::compose(&(v709_10),&(v711_11))
            };
            drop(v709_10);
            let v709_13: Space = map_map_kernels::unite(&(v709_8),&(v709_12));
            v708_11.join_into((v709_13).clone());
            }
            v708_11_cursor.ascend(1);
          }
          drop(v708_11_cursor);
          drop(v708_6);
          map_map_kernels::compose(&(v703_10),&(v708_11))
        };
        drop(v703_10);
        let v703_13: Space = map_map_kernels::unite(&(v703_8),&(v703_12));
        v702_7.join_into((v703_13).clone());
        }
        v702_7_cursor.ascend(1);
      }
      drop(v702_7_cursor);
      drop(v702_6);
      map_map_kernels::compose(&(v701_5),&(v702_7))
    };
    drop(v701_5);
    let v701_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v701_2));
    drop(v701_2);
    let v701_10: Space = if map_kernels::has_head(&(v701_9)) { singleton(&[]) } else { Space::new() };
    drop(v701_9);
    let v701_13: Space = if (v701_10).is_empty() { Space::new() } else {
      let v712_11: Space = map_kernels::unwrap(&(v700_9),&(v700_28_head));
      let mut v712_12 = Space::new();
      let mut v712_12_cursor = (v712_11).read_zipper();
      for v712_12_byte in v712_12_cursor.child_mask().iter() {
        v712_12_cursor.descend_to_byte(v712_12_byte);
        {
        let v712_12_tail = v712_12_cursor.fork_read_zipper();
        let v712_12_head = Path::from_slice(&[v712_12_byte]);
        let v713_2: Space = singleton(&(v712_12_head));
        let v713_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v713_2));
        let v713_4: Space = if map_kernels::has_head(&(v713_3)) { singleton(&[]) } else { Space::new() };
        drop(v713_3);
        let v713_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v713_4));
        drop(v713_4);
        let v713_7: Space = if (v713_5).is_empty() { Space::new() } else {
          let mut v714_6 = Space::new();
          let mut v714_6_cursor = (v712_12_tail).read_zipper();
          for v714_6_byte in v714_6_cursor.child_mask().iter() {
            v714_6_cursor.descend_to_byte(v714_6_byte);
            {
            let v714_6_tail = v714_6_cursor.fork_read_zipper();
            let v714_6_head = Path::from_slice(&[v714_6_byte]);
            let v715_2: Space = singleton(&(v714_6_head));
            let v715_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v715_2));
            let v715_4: Space = if map_kernels::has_head(&(v715_3)) { singleton(&[]) } else { Space::new() };
            drop(v715_3);
            let v715_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v715_4));
            drop(v715_4);
            let v715_8: Space = if (v715_5).is_empty() { Space::new() } else {
              let v716_6: Path = concat_path(&(v712_12_head),&(v714_6_head));
              let v716_7: Space = routine_17(c, &(v716_6), &(*p1), &(v714_6_tail).make_space());
              map_map_kernels::compose(&(v715_5),&(v716_7))
            };
            drop(v715_5);
            let v715_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v715_2));
            drop(v715_2);
            let v715_10: Space = if map_kernels::has_head(&(v715_9)) { singleton(&[]) } else { Space::new() };
            drop(v715_9);
            let v715_12: Space = if (v715_10).is_empty() { Space::new() } else {
              let v717_6: Path = concat_path(&(v712_12_head),&(v714_6_head));
              let v717_11: Space = routine_18(c, &(v717_6), &(*p1), &(v714_6_tail).make_space());
              drop(v717_6);
              map_map_kernels::compose(&(v715_10),&(v717_11))
            };
            drop(v715_10);
            let v715_13: Space = map_map_kernels::unite(&(v715_8),&(v715_12));
            v714_6.join_into((v715_13).clone());
            }
            v714_6_cursor.ascend(1);
          }
          drop(v714_6_cursor);
          map_map_kernels::compose(&(v713_5),&(v714_6))
        };
        drop(v713_5);
        let v713_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v713_2));
        drop(v713_2);
        let v713_9: Space = if map_kernels::has_head(&(v713_8)) { singleton(&[]) } else { Space::new() };
        drop(v713_8);
        let v713_11: Space = if (v713_9).is_empty() { Space::new() } else {
          let mut v718_10 = Space::new();
          let mut v718_10_cursor = (v712_12_tail).read_zipper();
          for v718_10_byte in v718_10_cursor.child_mask().iter() {
            v718_10_cursor.descend_to_byte(v718_10_byte);
            {
            let v718_10_tail = v718_10_cursor.fork_read_zipper();
            let v718_10_head = Path::from_slice(&[v718_10_byte]);
            let v719_2: Space = singleton(&(v718_10_head));
            let v719_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v719_2));
            let v719_4: Space = if map_kernels::has_head(&(v719_3)) { singleton(&[]) } else { Space::new() };
            drop(v719_3);
            let v719_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v719_4));
            drop(v719_4);
            let v719_8: Space = if (v719_5).is_empty() { Space::new() } else {
              let v720_6: Path = concat_path(&(v712_12_head),&(v718_10_head));
              let v720_7: Space = routine_17(c, &(v720_6), &(*p1), &(v718_10_tail).make_space());
              map_map_kernels::compose(&(v719_5),&(v720_7))
            };
            drop(v719_5);
            let v719_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v719_2));
            drop(v719_2);
            let v719_10: Space = if map_kernels::has_head(&(v719_9)) { singleton(&[]) } else { Space::new() };
            drop(v719_9);
            let v719_12: Space = if (v719_10).is_empty() { Space::new() } else {
              let v721_6: Path = concat_path(&(v712_12_head),&(v718_10_head));
              let v721_11: Space = routine_19(c, &(v721_6), &(*p1), &(v718_10_tail).make_space());
              drop(v721_6);
              map_map_kernels::compose(&(v719_10),&(v721_11))
            };
            drop(v719_10);
            let v719_13: Space = map_map_kernels::unite(&(v719_8),&(v719_12));
            v718_10.join_into((v719_13).clone());
            }
            v718_10_cursor.ascend(1);
          }
          drop(v718_10_cursor);
          map_map_kernels::compose(&(v713_9),&(v718_10))
        };
        drop(v713_9);
        let v713_12: Space = map_map_kernels::unite(&(v713_7),&(v713_11));
        v712_12.join_into((v713_12).clone());
        }
        v712_12_cursor.ascend(1);
      }
      drop(v712_12_cursor);
      drop(v712_11);
      map_map_kernels::compose(&(v701_10),&(v712_12))
    };
    drop(v701_10);
    let v701_14: Space = map_map_kernels::unite(&(v701_8),&(v701_13));
    v700_28.join_into((v701_14).clone());
    }
    v700_28_cursor.ascend(1);
  }
  drop(v700_28_cursor);
  drop(v700_9);
  (v700_28).clone()
}

fn routine_38(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v722_21 = Space::new();
  let mut v722_21_cursor = (*s0).read_zipper();
  for v722_21_byte in v722_21_cursor.child_mask().iter() {
    v722_21_cursor.descend_to_byte(v722_21_byte);
    {
    let v722_21_tail = v722_21_cursor.fork_read_zipper();
    let v722_21_head = Path::from_slice(&[v722_21_byte]);
    let v723_2: Space = singleton(&(v722_21_head));
    let v723_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v723_2));
    let v723_4: Space = if map_kernels::has_head(&(v723_3)) { singleton(&[]) } else { Space::new() };
    drop(v723_3);
    let v723_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v723_4));
    drop(v723_4);
    let v723_8: Space = if (v723_5).is_empty() { Space::new() } else {
      let v724_6: Path = concat_path(&(*p0),&(v722_21_head));
      let mut v724_7 = Space::new();
      let mut v724_7_cursor = (v722_21_tail).read_zipper();
      for v724_7_byte in v724_7_cursor.child_mask().iter() {
        v724_7_cursor.descend_to_byte(v724_7_byte);
        {
        let v724_7_tail = v724_7_cursor.fork_read_zipper();
        let v724_7_head = Path::from_slice(&[v724_7_byte]);
        let v725_2: Space = singleton(&(v724_7_head));
        let v725_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v725_2));
        let v725_4: Space = if map_kernels::has_head(&(v725_3)) { singleton(&[]) } else { Space::new() };
        drop(v725_3);
        let v725_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v725_4));
        drop(v725_4);
        let v725_8: Space = if (v725_5).is_empty() { Space::new() } else {
          let v726_6: Path = concat_path(&(v724_6),&(v724_7_head));
          let mut v726_7 = Space::new();
          let mut v726_7_cursor = (v724_7_tail).read_zipper();
          for v726_7_byte in v726_7_cursor.child_mask().iter() {
            v726_7_cursor.descend_to_byte(v726_7_byte);
            {
            let v726_7_tail = v726_7_cursor.fork_read_zipper();
            let v726_7_head = Path::from_slice(&[v726_7_byte]);
            let v727_2: Space = singleton(&(v726_7_head));
            let v727_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v727_2));
            let v727_4: Space = if map_kernels::has_head(&(v727_3)) { singleton(&[]) } else { Space::new() };
            drop(v727_3);
            let v727_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v727_4));
            drop(v727_4);
            let v727_8: Space = if (v727_5).is_empty() { Space::new() } else {
              let v728_6: Path = concat_path(&(v726_6),&(v726_7_head));
              let v728_7: Space = routine_50(c, &(v728_6), &(*p1), &(v726_7_tail).make_space());
              map_map_kernels::compose(&(v727_5),&(v728_7))
            };
            drop(v727_5);
            let v727_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v727_2));
            drop(v727_2);
            let v727_10: Space = if map_kernels::has_head(&(v727_9)) { singleton(&[]) } else { Space::new() };
            drop(v727_9);
            let v727_12: Space = if (v727_10).is_empty() { Space::new() } else {
              let v729_6: Path = concat_path(&(v726_6),&(v726_7_head));
              let v729_11: Space = routine_51(c, &(v729_6), &(*p1), &(v726_7_tail).make_space());
              drop(v729_6);
              map_map_kernels::compose(&(v727_10),&(v729_11))
            };
            drop(v727_10);
            let v727_13: Space = map_map_kernels::unite(&(v727_8),&(v727_12));
            v726_7.join_into((v727_13).clone());
            }
            v726_7_cursor.ascend(1);
          }
          drop(v726_7_cursor);
          map_map_kernels::compose(&(v725_5),&(v726_7))
        };
        drop(v725_5);
        let v725_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v725_2));
        drop(v725_2);
        let v725_10: Space = if map_kernels::has_head(&(v725_9)) { singleton(&[]) } else { Space::new() };
        drop(v725_9);
        let v725_12: Space = if (v725_10).is_empty() { Space::new() } else {
          let v730_6: Path = concat_path(&(v724_6),&(v724_7_head));
          let mut v730_11 = Space::new();
          let mut v730_11_cursor = (v724_7_tail).read_zipper();
          for v730_11_byte in v730_11_cursor.child_mask().iter() {
            v730_11_cursor.descend_to_byte(v730_11_byte);
            {
            let v730_11_tail = v730_11_cursor.fork_read_zipper();
            let v730_11_head = Path::from_slice(&[v730_11_byte]);
            let v731_2: Space = singleton(&(v730_11_head));
            let v731_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v731_2));
            let v731_4: Space = if map_kernels::has_head(&(v731_3)) { singleton(&[]) } else { Space::new() };
            drop(v731_3);
            let v731_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v731_4));
            drop(v731_4);
            let v731_8: Space = if (v731_5).is_empty() { Space::new() } else {
              let v732_6: Path = concat_path(&(v730_6),&(v730_11_head));
              let v732_7: Space = routine_50(c, &(v732_6), &(*p1), &(v730_11_tail).make_space());
              map_map_kernels::compose(&(v731_5),&(v732_7))
            };
            drop(v731_5);
            let v731_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v731_2));
            drop(v731_2);
            let v731_10: Space = if map_kernels::has_head(&(v731_9)) { singleton(&[]) } else { Space::new() };
            drop(v731_9);
            let v731_12: Space = if (v731_10).is_empty() { Space::new() } else {
              let v733_6: Path = concat_path(&(v730_6),&(v730_11_head));
              let v733_11: Space = routine_19(c, &(v733_6), &(*p1), &(v730_11_tail).make_space());
              drop(v733_6);
              map_map_kernels::compose(&(v731_10),&(v733_11))
            };
            drop(v731_10);
            let v731_13: Space = map_map_kernels::unite(&(v731_8),&(v731_12));
            v730_11.join_into((v731_13).clone());
            }
            v730_11_cursor.ascend(1);
          }
          drop(v730_11_cursor);
          drop(v730_6);
          map_map_kernels::compose(&(v725_10),&(v730_11))
        };
        drop(v725_10);
        let v725_13: Space = map_map_kernels::unite(&(v725_8),&(v725_12));
        v724_7.join_into((v725_13).clone());
        }
        v724_7_cursor.ascend(1);
      }
      drop(v724_7_cursor);
      map_map_kernels::compose(&(v723_5),&(v724_7))
    };
    drop(v723_5);
    let v723_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v723_2));
    drop(v723_2);
    let v723_10: Space = if map_kernels::has_head(&(v723_9)) { singleton(&[]) } else { Space::new() };
    drop(v723_9);
    let v723_12: Space = if (v723_10).is_empty() { Space::new() } else {
      let v734_6: Path = concat_path(&(*p0),&(v722_21_head));
      let mut v734_11 = Space::new();
      let mut v734_11_cursor = (v722_21_tail).read_zipper();
      for v734_11_byte in v734_11_cursor.child_mask().iter() {
        v734_11_cursor.descend_to_byte(v734_11_byte);
        {
        let v734_11_tail = v734_11_cursor.fork_read_zipper();
        let v734_11_head = Path::from_slice(&[v734_11_byte]);
        let v735_2: Space = singleton(&(v734_11_head));
        let v735_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v735_2));
        let v735_4: Space = if map_kernels::has_head(&(v735_3)) { singleton(&[]) } else { Space::new() };
        drop(v735_3);
        let v735_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v735_4));
        drop(v735_4);
        let v735_8: Space = if (v735_5).is_empty() { Space::new() } else {
          let v736_6: Path = concat_path(&(v734_6),&(v734_11_head));
          let mut v736_7 = Space::new();
          let mut v736_7_cursor = (v734_11_tail).read_zipper();
          for v736_7_byte in v736_7_cursor.child_mask().iter() {
            v736_7_cursor.descend_to_byte(v736_7_byte);
            {
            let v736_7_tail = v736_7_cursor.fork_read_zipper();
            let v736_7_head = Path::from_slice(&[v736_7_byte]);
            let v737_2: Space = singleton(&(v736_7_head));
            let v737_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v737_2));
            let v737_4: Space = if map_kernels::has_head(&(v737_3)) { singleton(&[]) } else { Space::new() };
            drop(v737_3);
            let v737_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v737_4));
            drop(v737_4);
            let v737_8: Space = if (v737_5).is_empty() { Space::new() } else {
              let v738_6: Path = concat_path(&(v736_6),&(v736_7_head));
              let v738_7: Space = routine_50(c, &(v738_6), &(*p1), &(v736_7_tail).make_space());
              map_map_kernels::compose(&(v737_5),&(v738_7))
            };
            drop(v737_5);
            let v737_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v737_2));
            drop(v737_2);
            let v737_10: Space = if map_kernels::has_head(&(v737_9)) { singleton(&[]) } else { Space::new() };
            drop(v737_9);
            let v737_12: Space = if (v737_10).is_empty() { Space::new() } else {
              let v739_6: Path = concat_path(&(v736_6),&(v736_7_head));
              let v739_11: Space = routine_51(c, &(v739_6), &(*p1), &(v736_7_tail).make_space());
              drop(v739_6);
              map_map_kernels::compose(&(v737_10),&(v739_11))
            };
            drop(v737_10);
            let v737_13: Space = map_map_kernels::unite(&(v737_8),&(v737_12));
            v736_7.join_into((v737_13).clone());
            }
            v736_7_cursor.ascend(1);
          }
          drop(v736_7_cursor);
          map_map_kernels::compose(&(v735_5),&(v736_7))
        };
        drop(v735_5);
        let v735_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v735_2));
        drop(v735_2);
        let v735_10: Space = if map_kernels::has_head(&(v735_9)) { singleton(&[]) } else { Space::new() };
        drop(v735_9);
        let v735_11: Space = map_view_kernels::compose(&(v735_10),&(v734_11_tail));
        drop(v735_10);
        let v740_6: Path = concat_path(&(v734_6),&(v734_11_head));
        let v735_12: Space = map_kernels::wrap(&(v735_11),&(v740_6));
        drop(v735_11);
        let v735_13: Space = map_kernels::wrap(&(v735_12),&(*p1));
        drop(v735_12);
        let v735_14: Space = map_map_kernels::unite(&(v735_8),&(v735_13));
        drop(v735_13);
        v734_11.join_into((v735_14).clone());
        }
        v734_11_cursor.ascend(1);
      }
      drop(v734_11_cursor);
      drop(v734_6);
      map_map_kernels::compose(&(v723_10),&(v734_11))
    };
    drop(v723_10);
    let v723_13: Space = map_map_kernels::unite(&(v723_8),&(v723_12));
    v722_21.join_into((v723_13).clone());
    }
    v722_21_cursor.ascend(1);
  }
  drop(v722_21_cursor);
  (v722_21).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v741_15 = Space::new();
  let mut v741_15_cursor = (*s0).read_zipper();
  for v741_15_byte in v741_15_cursor.child_mask().iter() {
    v741_15_cursor.descend_to_byte(v741_15_byte);
    {
    let v741_15_tail = v741_15_cursor.fork_read_zipper();
    let v741_15_head = Path::from_slice(&[v741_15_byte]);
    let v742_2: Space = singleton(&(v741_15_head));
    let v742_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v742_2));
    let v742_4: Space = if map_kernels::has_head(&(v742_3)) { singleton(&[]) } else { Space::new() };
    drop(v742_3);
    let v742_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v742_4));
    drop(v742_4);
    let v742_8: Space = if (v742_5).is_empty() { Space::new() } else {
      let v743_6: Path = concat_path(&(*p0),&(v741_15_head));
      let mut v743_7 = Space::new();
      let mut v743_7_cursor = (v741_15_tail).read_zipper();
      for v743_7_byte in v743_7_cursor.child_mask().iter() {
        v743_7_cursor.descend_to_byte(v743_7_byte);
        {
        let v743_7_tail = v743_7_cursor.fork_read_zipper();
        let v743_7_head = Path::from_slice(&[v743_7_byte]);
        let v744_2: Space = singleton(&(v743_7_head));
        let v744_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v744_2));
        let v744_4: Space = if map_kernels::has_head(&(v744_3)) { singleton(&[]) } else { Space::new() };
        drop(v744_3);
        let v744_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v744_4));
        drop(v744_4);
        let v744_8: Space = if (v744_5).is_empty() { Space::new() } else {
          let v745_6: Path = concat_path(&(v743_6),&(v743_7_head));
          let mut v745_7 = Space::new();
          let mut v745_7_cursor = (v743_7_tail).read_zipper();
          for v745_7_byte in v745_7_cursor.child_mask().iter() {
            v745_7_cursor.descend_to_byte(v745_7_byte);
            {
            let v745_7_tail = v745_7_cursor.fork_read_zipper();
            let v745_7_head = Path::from_slice(&[v745_7_byte]);
            let v746_2: Space = singleton(&(v745_7_head));
            let v746_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v746_2));
            let v746_4: Space = if map_kernels::has_head(&(v746_3)) { singleton(&[]) } else { Space::new() };
            drop(v746_3);
            let v746_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v746_4));
            drop(v746_4);
            let v746_8: Space = if (v746_5).is_empty() { Space::new() } else {
              let v747_6: Path = concat_path(&(v745_6),&(v745_7_head));
              let v747_7: Space = routine_50(c, &(v747_6), &(*p1), &(v745_7_tail).make_space());
              map_map_kernels::compose(&(v746_5),&(v747_7))
            };
            drop(v746_5);
            let v746_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v746_2));
            drop(v746_2);
            let v746_10: Space = if map_kernels::has_head(&(v746_9)) { singleton(&[]) } else { Space::new() };
            drop(v746_9);
            let v746_12: Space = if (v746_10).is_empty() { Space::new() } else {
              let v748_6: Path = concat_path(&(v745_6),&(v745_7_head));
              let v748_11: Space = routine_51(c, &(v748_6), &(*p1), &(v745_7_tail).make_space());
              drop(v748_6);
              map_map_kernels::compose(&(v746_10),&(v748_11))
            };
            drop(v746_10);
            let v746_13: Space = map_map_kernels::unite(&(v746_8),&(v746_12));
            v745_7.join_into((v746_13).clone());
            }
            v745_7_cursor.ascend(1);
          }
          drop(v745_7_cursor);
          map_map_kernels::compose(&(v744_5),&(v745_7))
        };
        drop(v744_5);
        let v744_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v744_2));
        drop(v744_2);
        let v744_10: Space = if map_kernels::has_head(&(v744_9)) { singleton(&[]) } else { Space::new() };
        drop(v744_9);
        let v744_12: Space = if (v744_10).is_empty() { Space::new() } else {
          let v749_6: Path = concat_path(&(v743_6),&(v743_7_head));
          let mut v749_11 = Space::new();
          let mut v749_11_cursor = (v743_7_tail).read_zipper();
          for v749_11_byte in v749_11_cursor.child_mask().iter() {
            v749_11_cursor.descend_to_byte(v749_11_byte);
            {
            let v749_11_tail = v749_11_cursor.fork_read_zipper();
            let v749_11_head = Path::from_slice(&[v749_11_byte]);
            let v750_2: Space = singleton(&(v749_11_head));
            let v750_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v750_2));
            let v750_4: Space = if map_kernels::has_head(&(v750_3)) { singleton(&[]) } else { Space::new() };
            drop(v750_3);
            let v750_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v750_4));
            drop(v750_4);
            let v750_8: Space = if (v750_5).is_empty() { Space::new() } else {
              let v751_6: Path = concat_path(&(v749_6),&(v749_11_head));
              let v751_7: Space = routine_50(c, &(v751_6), &(*p1), &(v749_11_tail).make_space());
              map_map_kernels::compose(&(v750_5),&(v751_7))
            };
            drop(v750_5);
            let v750_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v750_2));
            drop(v750_2);
            let v750_10: Space = if map_kernels::has_head(&(v750_9)) { singleton(&[]) } else { Space::new() };
            drop(v750_9);
            let v750_12: Space = if (v750_10).is_empty() { Space::new() } else {
              let v752_6: Path = concat_path(&(v749_6),&(v749_11_head));
              let v752_11: Space = routine_19(c, &(v752_6), &(*p1), &(v749_11_tail).make_space());
              drop(v752_6);
              map_map_kernels::compose(&(v750_10),&(v752_11))
            };
            drop(v750_10);
            let v750_13: Space = map_map_kernels::unite(&(v750_8),&(v750_12));
            v749_11.join_into((v750_13).clone());
            }
            v749_11_cursor.ascend(1);
          }
          drop(v749_11_cursor);
          drop(v749_6);
          map_map_kernels::compose(&(v744_10),&(v749_11))
        };
        drop(v744_10);
        let v744_13: Space = map_map_kernels::unite(&(v744_8),&(v744_12));
        v743_7.join_into((v744_13).clone());
        }
        v743_7_cursor.ascend(1);
      }
      drop(v743_7_cursor);
      map_map_kernels::compose(&(v742_5),&(v743_7))
    };
    drop(v742_5);
    let v742_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v742_2));
    drop(v742_2);
    let v742_10: Space = if map_kernels::has_head(&(v742_9)) { singleton(&[]) } else { Space::new() };
    drop(v742_9);
    let v742_11: Space = map_view_kernels::compose(&(v742_10),&(v741_15_tail));
    drop(v742_10);
    let v753_6: Path = concat_path(&(*p0),&(v741_15_head));
    let v742_12: Space = map_kernels::wrap(&(v742_11),&(v753_6));
    drop(v742_11);
    let v742_13: Space = map_kernels::wrap(&(v742_12),&(*p1));
    drop(v742_12);
    let v742_14: Space = map_map_kernels::unite(&(v742_8),&(v742_13));
    drop(v742_13);
    v741_15.join_into((v742_14).clone());
    }
    v741_15_cursor.ascend(1);
  }
  drop(v741_15_cursor);
  (v741_15).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v754_20: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v754_21: Space = map_kernels::unwrap(&(v754_20),&(*p0));
  drop(v754_20);
  let mut v754_28 = Space::new();
  let mut v754_28_cursor = (*s0).read_zipper();
  for v754_28_byte in v754_28_cursor.child_mask().iter() {
    v754_28_cursor.descend_to_byte(v754_28_byte);
    {
    let v754_28_tail = v754_28_cursor.fork_read_zipper();
    let v754_28_head = Path::from_slice(&[v754_28_byte]);
    let v755_2: Space = singleton(&(v754_28_head));
    let v755_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v755_2));
    let v755_4: Space = if map_kernels::has_head(&(v755_3)) { singleton(&[]) } else { Space::new() };
    drop(v755_3);
    let v755_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v755_4));
    drop(v755_4);
    let v755_8: Space = if (v755_5).is_empty() { Space::new() } else {
      let v756_6: Path = concat_path(&(*p0),&(v754_28_head));
      let mut v756_7 = Space::new();
      let mut v756_7_cursor = (v754_28_tail).read_zipper();
      for v756_7_byte in v756_7_cursor.child_mask().iter() {
        v756_7_cursor.descend_to_byte(v756_7_byte);
        {
        let v756_7_tail = v756_7_cursor.fork_read_zipper();
        let v756_7_head = Path::from_slice(&[v756_7_byte]);
        let v757_2: Space = singleton(&(v756_7_head));
        let v757_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v757_2));
        let v757_4: Space = if map_kernels::has_head(&(v757_3)) { singleton(&[]) } else { Space::new() };
        drop(v757_3);
        let v757_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v757_4));
        drop(v757_4);
        let v757_8: Space = if (v757_5).is_empty() { Space::new() } else {
          let v758_6: Path = concat_path(&(v756_6),&(v756_7_head));
          let mut v758_7 = Space::new();
          let mut v758_7_cursor = (v756_7_tail).read_zipper();
          for v758_7_byte in v758_7_cursor.child_mask().iter() {
            v758_7_cursor.descend_to_byte(v758_7_byte);
            {
            let v758_7_tail = v758_7_cursor.fork_read_zipper();
            let v758_7_head = Path::from_slice(&[v758_7_byte]);
            let v759_2: Space = singleton(&(v758_7_head));
            let v759_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v759_2));
            let v759_4: Space = if map_kernels::has_head(&(v759_3)) { singleton(&[]) } else { Space::new() };
            drop(v759_3);
            let v759_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v759_4));
            drop(v759_4);
            let v759_8: Space = if (v759_5).is_empty() { Space::new() } else {
              let v760_6: Path = concat_path(&(v758_6),&(v758_7_head));
              let v760_7: Space = routine_52(c, &(v760_6), &(*p1), &(v758_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v759_5),&(v760_7))
            };
            drop(v759_5);
            let v759_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v759_2));
            drop(v759_2);
            let v759_10: Space = if map_kernels::has_head(&(v759_9)) { singleton(&[]) } else { Space::new() };
            drop(v759_9);
            let v759_12: Space = if (v759_10).is_empty() { Space::new() } else {
              let v761_6: Path = concat_path(&(v758_6),&(v758_7_head));
              let v761_11: Space = routine_53(c, &(v761_6), &(*p1), &(v758_7_tail).make_space(), &(*s1));
              drop(v761_6);
              map_map_kernels::compose(&(v759_10),&(v761_11))
            };
            drop(v759_10);
            let v759_13: Space = map_map_kernels::unite(&(v759_8),&(v759_12));
            v758_7.join_into((v759_13).clone());
            }
            v758_7_cursor.ascend(1);
          }
          drop(v758_7_cursor);
          map_map_kernels::compose(&(v757_5),&(v758_7))
        };
        drop(v757_5);
        let v757_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v757_2));
        drop(v757_2);
        let v757_10: Space = if map_kernels::has_head(&(v757_9)) { singleton(&[]) } else { Space::new() };
        drop(v757_9);
        let v757_12: Space = if (v757_10).is_empty() { Space::new() } else {
          let v762_6: Path = concat_path(&(v756_6),&(v756_7_head));
          let mut v762_11 = Space::new();
          let mut v762_11_cursor = (v756_7_tail).read_zipper();
          for v762_11_byte in v762_11_cursor.child_mask().iter() {
            v762_11_cursor.descend_to_byte(v762_11_byte);
            {
            let v762_11_tail = v762_11_cursor.fork_read_zipper();
            let v762_11_head = Path::from_slice(&[v762_11_byte]);
            let v763_2: Space = singleton(&(v762_11_head));
            let v763_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v763_2));
            let v763_4: Space = if map_kernels::has_head(&(v763_3)) { singleton(&[]) } else { Space::new() };
            drop(v763_3);
            let v763_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v763_4));
            drop(v763_4);
            let v763_8: Space = if (v763_5).is_empty() { Space::new() } else {
              let v764_6: Path = concat_path(&(v762_6),&(v762_11_head));
              let v764_7: Space = routine_52(c, &(v764_6), &(*p1), &(v762_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v763_5),&(v764_7))
            };
            drop(v763_5);
            let v763_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v763_2));
            drop(v763_2);
            let v763_10: Space = if map_kernels::has_head(&(v763_9)) { singleton(&[]) } else { Space::new() };
            drop(v763_9);
            let v763_12: Space = if (v763_10).is_empty() { Space::new() } else {
              let v765_6: Path = concat_path(&(v762_6),&(v762_11_head));
              let v765_11: Space = routine_10(c, &(v765_6), &(*p1), &(v762_11_tail).make_space(), &(*s1));
              drop(v765_6);
              map_map_kernels::compose(&(v763_10),&(v765_11))
            };
            drop(v763_10);
            let v763_13: Space = map_map_kernels::unite(&(v763_8),&(v763_12));
            v762_11.join_into((v763_13).clone());
            }
            v762_11_cursor.ascend(1);
          }
          drop(v762_11_cursor);
          drop(v762_6);
          map_map_kernels::compose(&(v757_10),&(v762_11))
        };
        drop(v757_10);
        let v757_13: Space = map_map_kernels::unite(&(v757_8),&(v757_12));
        v756_7.join_into((v757_13).clone());
        }
        v756_7_cursor.ascend(1);
      }
      drop(v756_7_cursor);
      map_map_kernels::compose(&(v755_5),&(v756_7))
    };
    drop(v755_5);
    let v755_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v755_2));
    drop(v755_2);
    let v755_10: Space = if map_kernels::has_head(&(v755_9)) { singleton(&[]) } else { Space::new() };
    drop(v755_9);
    let v755_13: Space = if (v755_10).is_empty() { Space::new() } else {
      let v766_6: Path = concat_path(&(*p0),&(v754_28_head));
      let v766_11: Space = map_kernels::unwrap(&(v754_21),&(v754_28_head));
      let mut v766_12 = Space::new();
      let mut v766_12_cursor = (v754_28_tail).read_zipper();
      for v766_12_byte in v766_12_cursor.child_mask().iter() {
        v766_12_cursor.descend_to_byte(v766_12_byte);
        {
        let v766_12_tail = v766_12_cursor.fork_read_zipper();
        let v766_12_head = Path::from_slice(&[v766_12_byte]);
        let v767_2: Space = singleton(&(v766_12_head));
        let v767_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v767_2));
        let v767_4: Space = if map_kernels::has_head(&(v767_3)) { singleton(&[]) } else { Space::new() };
        drop(v767_3);
        let v767_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v767_4));
        drop(v767_4);
        let v767_8: Space = if (v767_5).is_empty() { Space::new() } else {
          let v768_6: Path = concat_path(&(v766_6),&(v766_12_head));
          let mut v768_7 = Space::new();
          let mut v768_7_cursor = (v766_12_tail).read_zipper();
          for v768_7_byte in v768_7_cursor.child_mask().iter() {
            v768_7_cursor.descend_to_byte(v768_7_byte);
            {
            let v768_7_tail = v768_7_cursor.fork_read_zipper();
            let v768_7_head = Path::from_slice(&[v768_7_byte]);
            let v769_2: Space = singleton(&(v768_7_head));
            let v769_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v769_2));
            let v769_4: Space = if map_kernels::has_head(&(v769_3)) { singleton(&[]) } else { Space::new() };
            drop(v769_3);
            let v769_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v769_4));
            drop(v769_4);
            let v769_8: Space = if (v769_5).is_empty() { Space::new() } else {
              let v770_6: Path = concat_path(&(v768_6),&(v768_7_head));
              let v770_7: Space = routine_52(c, &(v770_6), &(*p1), &(v768_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v769_5),&(v770_7))
            };
            drop(v769_5);
            let v769_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v769_2));
            drop(v769_2);
            let v769_10: Space = if map_kernels::has_head(&(v769_9)) { singleton(&[]) } else { Space::new() };
            drop(v769_9);
            let v769_12: Space = if (v769_10).is_empty() { Space::new() } else {
              let v771_6: Path = concat_path(&(v768_6),&(v768_7_head));
              let v771_11: Space = routine_53(c, &(v771_6), &(*p1), &(v768_7_tail).make_space(), &(*s1));
              drop(v771_6);
              map_map_kernels::compose(&(v769_10),&(v771_11))
            };
            drop(v769_10);
            let v769_13: Space = map_map_kernels::unite(&(v769_8),&(v769_12));
            v768_7.join_into((v769_13).clone());
            }
            v768_7_cursor.ascend(1);
          }
          drop(v768_7_cursor);
          drop(v768_6);
          map_map_kernels::compose(&(v767_5),&(v768_7))
        };
        drop(v767_5);
        let v767_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v767_2));
        drop(v767_2);
        let v767_10: Space = if map_kernels::has_head(&(v767_9)) { singleton(&[]) } else { Space::new() };
        drop(v767_9);
        let v767_13: Space = if (v767_10).is_empty() { Space::new() } else {
          let v772_11: Space = map_kernels::unwrap(&(v766_11),&(v766_12_head));
          let mut v772_12 = Space::new();
          let mut v772_12_cursor = (v772_11).read_zipper();
          for v772_12_byte in v772_12_cursor.child_mask().iter() {
            v772_12_cursor.descend_to_byte(v772_12_byte);
            {
            let v772_12_tail = v772_12_cursor.fork_read_zipper();
            let v772_12_head = Path::from_slice(&[v772_12_byte]);
            let v773_2: Space = singleton(&(v772_12_head));
            let v773_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v773_2));
            let v773_4: Space = if map_kernels::has_head(&(v773_3)) { singleton(&[]) } else { Space::new() };
            drop(v773_3);
            let v773_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v773_4));
            drop(v773_4);
            let v773_7: Space = if (v773_5).is_empty() { Space::new() } else {
              let v774_6: Space = routine_13(c, &(v772_12_head), &(*p1), &(v772_12_tail).make_space());
              map_map_kernels::compose(&(v773_5),&(v774_6))
            };
            drop(v773_5);
            let v773_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v773_2));
            drop(v773_2);
            let v773_9: Space = if map_kernels::has_head(&(v773_8)) { singleton(&[]) } else { Space::new() };
            drop(v773_8);
            let v773_11: Space = if (v773_9).is_empty() { Space::new() } else {
              let v775_10: Space = routine_14(c, &(v772_12_head), &(*p1), &(v772_12_tail).make_space());
              map_map_kernels::compose(&(v773_9),&(v775_10))
            };
            drop(v773_9);
            let v773_12: Space = map_map_kernels::unite(&(v773_7),&(v773_11));
            v772_12.join_into((v773_12).clone());
            }
            v772_12_cursor.ascend(1);
          }
          drop(v772_12_cursor);
          drop(v772_11);
          map_map_kernels::compose(&(v767_10),&(v772_12))
        };
        drop(v767_10);
        let v767_14: Space = map_map_kernels::unite(&(v767_8),&(v767_13));
        v766_12.join_into((v767_14).clone());
        }
        v766_12_cursor.ascend(1);
      }
      drop(v766_12_cursor);
      drop(v766_6);
      drop(v766_11);
      map_map_kernels::compose(&(v755_10),&(v766_12))
    };
    drop(v755_10);
    let v755_14: Space = map_map_kernels::unite(&(v755_8),&(v755_13));
    v754_28.join_into((v755_14).clone());
    }
    v754_28_cursor.ascend(1);
  }
  drop(v754_28_cursor);
  drop(v754_21);
  (v754_28).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v776_8: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v776_9: Space = map_kernels::unwrap(&(v776_8),&(*p0));
  drop(v776_8);
  let mut v776_28 = Space::new();
  let mut v776_28_cursor = (*s0).read_zipper();
  for v776_28_byte in v776_28_cursor.child_mask().iter() {
    v776_28_cursor.descend_to_byte(v776_28_byte);
    {
    let v776_28_tail = v776_28_cursor.fork_read_zipper();
    let v776_28_head = Path::from_slice(&[v776_28_byte]);
    let v777_2: Space = singleton(&(v776_28_head));
    let v777_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v777_2));
    let v777_4: Space = if map_kernels::has_head(&(v777_3)) { singleton(&[]) } else { Space::new() };
    drop(v777_3);
    let v777_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v777_4));
    drop(v777_4);
    let v777_8: Space = if (v777_5).is_empty() { Space::new() } else {
      let v778_6: Path = concat_path(&(*p0),&(v776_28_head));
      let mut v778_7 = Space::new();
      let mut v778_7_cursor = (v776_28_tail).read_zipper();
      for v778_7_byte in v778_7_cursor.child_mask().iter() {
        v778_7_cursor.descend_to_byte(v778_7_byte);
        {
        let v778_7_tail = v778_7_cursor.fork_read_zipper();
        let v778_7_head = Path::from_slice(&[v778_7_byte]);
        let v779_2: Space = singleton(&(v778_7_head));
        let v779_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v779_2));
        let v779_4: Space = if map_kernels::has_head(&(v779_3)) { singleton(&[]) } else { Space::new() };
        drop(v779_3);
        let v779_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v779_4));
        drop(v779_4);
        let v779_8: Space = if (v779_5).is_empty() { Space::new() } else {
          let v780_6: Path = concat_path(&(v778_6),&(v778_7_head));
          let mut v780_7 = Space::new();
          let mut v780_7_cursor = (v778_7_tail).read_zipper();
          for v780_7_byte in v780_7_cursor.child_mask().iter() {
            v780_7_cursor.descend_to_byte(v780_7_byte);
            {
            let v780_7_tail = v780_7_cursor.fork_read_zipper();
            let v780_7_head = Path::from_slice(&[v780_7_byte]);
            let v781_2: Space = singleton(&(v780_7_head));
            let v781_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v781_2));
            let v781_4: Space = if map_kernels::has_head(&(v781_3)) { singleton(&[]) } else { Space::new() };
            drop(v781_3);
            let v781_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v781_4));
            drop(v781_4);
            let v781_8: Space = if (v781_5).is_empty() { Space::new() } else {
              let v782_6: Path = concat_path(&(v780_6),&(v780_7_head));
              let v782_7: Space = routine_52(c, &(v782_6), &(*p1), &(v780_7_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v781_5),&(v782_7))
            };
            drop(v781_5);
            let v781_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v781_2));
            drop(v781_2);
            let v781_10: Space = if map_kernels::has_head(&(v781_9)) { singleton(&[]) } else { Space::new() };
            drop(v781_9);
            let v781_12: Space = if (v781_10).is_empty() { Space::new() } else {
              let v783_6: Path = concat_path(&(v780_6),&(v780_7_head));
              let v783_11: Space = routine_53(c, &(v783_6), &(*p1), &(v780_7_tail).make_space(), &(*s1));
              drop(v783_6);
              map_map_kernels::compose(&(v781_10),&(v783_11))
            };
            drop(v781_10);
            let v781_13: Space = map_map_kernels::unite(&(v781_8),&(v781_12));
            v780_7.join_into((v781_13).clone());
            }
            v780_7_cursor.ascend(1);
          }
          drop(v780_7_cursor);
          map_map_kernels::compose(&(v779_5),&(v780_7))
        };
        drop(v779_5);
        let v779_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v779_2));
        drop(v779_2);
        let v779_10: Space = if map_kernels::has_head(&(v779_9)) { singleton(&[]) } else { Space::new() };
        drop(v779_9);
        let v779_12: Space = if (v779_10).is_empty() { Space::new() } else {
          let v784_6: Path = concat_path(&(v778_6),&(v778_7_head));
          let mut v784_11 = Space::new();
          let mut v784_11_cursor = (v778_7_tail).read_zipper();
          for v784_11_byte in v784_11_cursor.child_mask().iter() {
            v784_11_cursor.descend_to_byte(v784_11_byte);
            {
            let v784_11_tail = v784_11_cursor.fork_read_zipper();
            let v784_11_head = Path::from_slice(&[v784_11_byte]);
            let v785_2: Space = singleton(&(v784_11_head));
            let v785_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v785_2));
            let v785_4: Space = if map_kernels::has_head(&(v785_3)) { singleton(&[]) } else { Space::new() };
            drop(v785_3);
            let v785_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v785_4));
            drop(v785_4);
            let v785_8: Space = if (v785_5).is_empty() { Space::new() } else {
              let v786_6: Path = concat_path(&(v784_6),&(v784_11_head));
              let v786_7: Space = routine_52(c, &(v786_6), &(*p1), &(v784_11_tail).make_space(), &(*s1));
              map_map_kernels::compose(&(v785_5),&(v786_7))
            };
            drop(v785_5);
            let v785_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v785_2));
            drop(v785_2);
            let v785_10: Space = if map_kernels::has_head(&(v785_9)) { singleton(&[]) } else { Space::new() };
            drop(v785_9);
            let v785_12: Space = if (v785_10).is_empty() { Space::new() } else {
              let v787_6: Path = concat_path(&(v784_6),&(v784_11_head));
              let v787_11: Space = routine_10(c, &(v787_6), &(*p1), &(v784_11_tail).make_space(), &(*s1));
              drop(v787_6);
              map_map_kernels::compose(&(v785_10),&(v787_11))
            };
            drop(v785_10);
            let v785_13: Space = map_map_kernels::unite(&(v785_8),&(v785_12));
            v784_11.join_into((v785_13).clone());
            }
            v784_11_cursor.ascend(1);
          }
          drop(v784_11_cursor);
          drop(v784_6);
          map_map_kernels::compose(&(v779_10),&(v784_11))
        };
        drop(v779_10);
        let v779_13: Space = map_map_kernels::unite(&(v779_8),&(v779_12));
        v778_7.join_into((v779_13).clone());
        }
        v778_7_cursor.ascend(1);
      }
      drop(v778_7_cursor);
      drop(v778_6);
      map_map_kernels::compose(&(v777_5),&(v778_7))
    };
    drop(v777_5);
    let v777_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v777_2));
    drop(v777_2);
    let v777_10: Space = if map_kernels::has_head(&(v777_9)) { singleton(&[]) } else { Space::new() };
    drop(v777_9);
    let v777_13: Space = if (v777_10).is_empty() { Space::new() } else {
      let v788_11: Space = map_kernels::unwrap(&(v776_9),&(v776_28_head));
      let mut v788_12 = Space::new();
      let mut v788_12_cursor = (v788_11).read_zipper();
      for v788_12_byte in v788_12_cursor.child_mask().iter() {
        v788_12_cursor.descend_to_byte(v788_12_byte);
        {
        let v788_12_tail = v788_12_cursor.fork_read_zipper();
        let v788_12_head = Path::from_slice(&[v788_12_byte]);
        let v789_2: Space = singleton(&(v788_12_head));
        let v789_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v789_2));
        let v789_4: Space = if map_kernels::has_head(&(v789_3)) { singleton(&[]) } else { Space::new() };
        drop(v789_3);
        let v789_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v789_4));
        drop(v789_4);
        let v789_7: Space = if (v789_5).is_empty() { Space::new() } else {
          let mut v790_6 = Space::new();
          let mut v790_6_cursor = (v788_12_tail).read_zipper();
          for v790_6_byte in v790_6_cursor.child_mask().iter() {
            v790_6_cursor.descend_to_byte(v790_6_byte);
            {
            let v790_6_tail = v790_6_cursor.fork_read_zipper();
            let v790_6_head = Path::from_slice(&[v790_6_byte]);
            let v791_2: Space = singleton(&(v790_6_head));
            let v791_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v791_2));
            let v791_4: Space = if map_kernels::has_head(&(v791_3)) { singleton(&[]) } else { Space::new() };
            drop(v791_3);
            let v791_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v791_4));
            drop(v791_4);
            let v791_8: Space = if (v791_5).is_empty() { Space::new() } else {
              let v792_6: Path = concat_path(&(v788_12_head),&(v790_6_head));
              let v792_7: Space = routine_17(c, &(v792_6), &(*p1), &(v790_6_tail).make_space());
              map_map_kernels::compose(&(v791_5),&(v792_7))
            };
            drop(v791_5);
            let v791_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v791_2));
            drop(v791_2);
            let v791_10: Space = if map_kernels::has_head(&(v791_9)) { singleton(&[]) } else { Space::new() };
            drop(v791_9);
            let v791_12: Space = if (v791_10).is_empty() { Space::new() } else {
              let v793_6: Path = concat_path(&(v788_12_head),&(v790_6_head));
              let v793_11: Space = routine_18(c, &(v793_6), &(*p1), &(v790_6_tail).make_space());
              drop(v793_6);
              map_map_kernels::compose(&(v791_10),&(v793_11))
            };
            drop(v791_10);
            let v791_13: Space = map_map_kernels::unite(&(v791_8),&(v791_12));
            v790_6.join_into((v791_13).clone());
            }
            v790_6_cursor.ascend(1);
          }
          drop(v790_6_cursor);
          map_map_kernels::compose(&(v789_5),&(v790_6))
        };
        drop(v789_5);
        let v789_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v789_2));
        drop(v789_2);
        let v789_9: Space = if map_kernels::has_head(&(v789_8)) { singleton(&[]) } else { Space::new() };
        drop(v789_8);
        let v789_11: Space = if (v789_9).is_empty() { Space::new() } else {
          let mut v794_10 = Space::new();
          let mut v794_10_cursor = (v788_12_tail).read_zipper();
          for v794_10_byte in v794_10_cursor.child_mask().iter() {
            v794_10_cursor.descend_to_byte(v794_10_byte);
            {
            let v794_10_tail = v794_10_cursor.fork_read_zipper();
            let v794_10_head = Path::from_slice(&[v794_10_byte]);
            let v795_2: Space = singleton(&(v794_10_head));
            let v795_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v795_2));
            let v795_4: Space = if map_kernels::has_head(&(v795_3)) { singleton(&[]) } else { Space::new() };
            drop(v795_3);
            let v795_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v795_4));
            drop(v795_4);
            let v795_8: Space = if (v795_5).is_empty() { Space::new() } else {
              let v796_6: Path = concat_path(&(v788_12_head),&(v794_10_head));
              let v796_7: Space = routine_17(c, &(v796_6), &(*p1), &(v794_10_tail).make_space());
              map_map_kernels::compose(&(v795_5),&(v796_7))
            };
            drop(v795_5);
            let v795_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v795_2));
            drop(v795_2);
            let v795_10: Space = if map_kernels::has_head(&(v795_9)) { singleton(&[]) } else { Space::new() };
            drop(v795_9);
            let v795_12: Space = if (v795_10).is_empty() { Space::new() } else {
              let v797_6: Path = concat_path(&(v788_12_head),&(v794_10_head));
              let v797_11: Space = routine_19(c, &(v797_6), &(*p1), &(v794_10_tail).make_space());
              drop(v797_6);
              map_map_kernels::compose(&(v795_10),&(v797_11))
            };
            drop(v795_10);
            let v795_13: Space = map_map_kernels::unite(&(v795_8),&(v795_12));
            v794_10.join_into((v795_13).clone());
            }
            v794_10_cursor.ascend(1);
          }
          drop(v794_10_cursor);
          map_map_kernels::compose(&(v789_9),&(v794_10))
        };
        drop(v789_9);
        let v789_12: Space = map_map_kernels::unite(&(v789_7),&(v789_11));
        v788_12.join_into((v789_12).clone());
        }
        v788_12_cursor.ascend(1);
      }
      drop(v788_12_cursor);
      drop(v788_11);
      map_map_kernels::compose(&(v777_10),&(v788_12))
    };
    drop(v777_10);
    let v777_14: Space = map_map_kernels::unite(&(v777_8),&(v777_13));
    v776_28.join_into((v777_14).clone());
    }
    v776_28_cursor.ascend(1);
  }
  drop(v776_28_cursor);
  drop(v776_9);
  (v776_28).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v798_21 = Space::new();
  let mut v798_21_cursor = (*s0).read_zipper();
  for v798_21_byte in v798_21_cursor.child_mask().iter() {
    v798_21_cursor.descend_to_byte(v798_21_byte);
    {
    let v798_21_tail = v798_21_cursor.fork_read_zipper();
    let v798_21_head = Path::from_slice(&[v798_21_byte]);
    let v799_2: Space = singleton(&(v798_21_head));
    let v799_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v799_2));
    let v799_4: Space = if map_kernels::has_head(&(v799_3)) { singleton(&[]) } else { Space::new() };
    drop(v799_3);
    let v799_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v799_4));
    drop(v799_4);
    let v799_8: Space = if (v799_5).is_empty() { Space::new() } else {
      let v800_6: Path = concat_path(&(*p0),&(v798_21_head));
      let mut v800_7 = Space::new();
      let mut v800_7_cursor = (v798_21_tail).read_zipper();
      for v800_7_byte in v800_7_cursor.child_mask().iter() {
        v800_7_cursor.descend_to_byte(v800_7_byte);
        {
        let v800_7_tail = v800_7_cursor.fork_read_zipper();
        let v800_7_head = Path::from_slice(&[v800_7_byte]);
        let v801_2: Space = singleton(&(v800_7_head));
        let v801_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v801_2));
        let v801_4: Space = if map_kernels::has_head(&(v801_3)) { singleton(&[]) } else { Space::new() };
        drop(v801_3);
        let v801_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v801_4));
        drop(v801_4);
        let v801_8: Space = if (v801_5).is_empty() { Space::new() } else {
          let v802_6: Path = concat_path(&(v800_6),&(v800_7_head));
          let mut v802_7 = Space::new();
          let mut v802_7_cursor = (v800_7_tail).read_zipper();
          for v802_7_byte in v802_7_cursor.child_mask().iter() {
            v802_7_cursor.descend_to_byte(v802_7_byte);
            {
            let v802_7_tail = v802_7_cursor.fork_read_zipper();
            let v802_7_head = Path::from_slice(&[v802_7_byte]);
            let v803_2: Space = singleton(&(v802_7_head));
            let v803_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v803_2));
            let v803_4: Space = if map_kernels::has_head(&(v803_3)) { singleton(&[]) } else { Space::new() };
            drop(v803_3);
            let v803_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v803_4));
            drop(v803_4);
            let v803_8: Space = if (v803_5).is_empty() { Space::new() } else {
              let v804_6: Path = concat_path(&(v802_6),&(v802_7_head));
              let v804_7: Space = routine_54(c, &(v804_6), &(*p1), &(v802_7_tail).make_space());
              map_map_kernels::compose(&(v803_5),&(v804_7))
            };
            drop(v803_5);
            let v803_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v803_2));
            drop(v803_2);
            let v803_10: Space = if map_kernels::has_head(&(v803_9)) { singleton(&[]) } else { Space::new() };
            drop(v803_9);
            let v803_12: Space = if (v803_10).is_empty() { Space::new() } else {
              let v805_6: Path = concat_path(&(v802_6),&(v802_7_head));
              let v805_11: Space = routine_55(c, &(v805_6), &(*p1), &(v802_7_tail).make_space());
              drop(v805_6);
              map_map_kernels::compose(&(v803_10),&(v805_11))
            };
            drop(v803_10);
            let v803_13: Space = map_map_kernels::unite(&(v803_8),&(v803_12));
            v802_7.join_into((v803_13).clone());
            }
            v802_7_cursor.ascend(1);
          }
          drop(v802_7_cursor);
          map_map_kernels::compose(&(v801_5),&(v802_7))
        };
        drop(v801_5);
        let v801_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v801_2));
        drop(v801_2);
        let v801_10: Space = if map_kernels::has_head(&(v801_9)) { singleton(&[]) } else { Space::new() };
        drop(v801_9);
        let v801_12: Space = if (v801_10).is_empty() { Space::new() } else {
          let v806_6: Path = concat_path(&(v800_6),&(v800_7_head));
          let mut v806_11 = Space::new();
          let mut v806_11_cursor = (v800_7_tail).read_zipper();
          for v806_11_byte in v806_11_cursor.child_mask().iter() {
            v806_11_cursor.descend_to_byte(v806_11_byte);
            {
            let v806_11_tail = v806_11_cursor.fork_read_zipper();
            let v806_11_head = Path::from_slice(&[v806_11_byte]);
            let v807_2: Space = singleton(&(v806_11_head));
            let v807_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v807_2));
            let v807_4: Space = if map_kernels::has_head(&(v807_3)) { singleton(&[]) } else { Space::new() };
            drop(v807_3);
            let v807_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v807_4));
            drop(v807_4);
            let v807_8: Space = if (v807_5).is_empty() { Space::new() } else {
              let v808_6: Path = concat_path(&(v806_6),&(v806_11_head));
              let v808_7: Space = routine_54(c, &(v808_6), &(*p1), &(v806_11_tail).make_space());
              map_map_kernels::compose(&(v807_5),&(v808_7))
            };
            drop(v807_5);
            let v807_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v807_2));
            drop(v807_2);
            let v807_10: Space = if map_kernels::has_head(&(v807_9)) { singleton(&[]) } else { Space::new() };
            drop(v807_9);
            let v807_12: Space = if (v807_10).is_empty() { Space::new() } else {
              let v809_6: Path = concat_path(&(v806_6),&(v806_11_head));
              let v809_11: Space = routine_19(c, &(v809_6), &(*p1), &(v806_11_tail).make_space());
              drop(v809_6);
              map_map_kernels::compose(&(v807_10),&(v809_11))
            };
            drop(v807_10);
            let v807_13: Space = map_map_kernels::unite(&(v807_8),&(v807_12));
            v806_11.join_into((v807_13).clone());
            }
            v806_11_cursor.ascend(1);
          }
          drop(v806_11_cursor);
          drop(v806_6);
          map_map_kernels::compose(&(v801_10),&(v806_11))
        };
        drop(v801_10);
        let v801_13: Space = map_map_kernels::unite(&(v801_8),&(v801_12));
        v800_7.join_into((v801_13).clone());
        }
        v800_7_cursor.ascend(1);
      }
      drop(v800_7_cursor);
      map_map_kernels::compose(&(v799_5),&(v800_7))
    };
    drop(v799_5);
    let v799_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v799_2));
    drop(v799_2);
    let v799_10: Space = if map_kernels::has_head(&(v799_9)) { singleton(&[]) } else { Space::new() };
    drop(v799_9);
    let v799_12: Space = if (v799_10).is_empty() { Space::new() } else {
      let v810_6: Path = concat_path(&(*p0),&(v798_21_head));
      let mut v810_11 = Space::new();
      let mut v810_11_cursor = (v798_21_tail).read_zipper();
      for v810_11_byte in v810_11_cursor.child_mask().iter() {
        v810_11_cursor.descend_to_byte(v810_11_byte);
        {
        let v810_11_tail = v810_11_cursor.fork_read_zipper();
        let v810_11_head = Path::from_slice(&[v810_11_byte]);
        let v811_2: Space = singleton(&(v810_11_head));
        let v811_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v811_2));
        let v811_4: Space = if map_kernels::has_head(&(v811_3)) { singleton(&[]) } else { Space::new() };
        drop(v811_3);
        let v811_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v811_4));
        drop(v811_4);
        let v811_8: Space = if (v811_5).is_empty() { Space::new() } else {
          let v812_6: Path = concat_path(&(v810_6),&(v810_11_head));
          let mut v812_7 = Space::new();
          let mut v812_7_cursor = (v810_11_tail).read_zipper();
          for v812_7_byte in v812_7_cursor.child_mask().iter() {
            v812_7_cursor.descend_to_byte(v812_7_byte);
            {
            let v812_7_tail = v812_7_cursor.fork_read_zipper();
            let v812_7_head = Path::from_slice(&[v812_7_byte]);
            let v813_2: Space = singleton(&(v812_7_head));
            let v813_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v813_2));
            let v813_4: Space = if map_kernels::has_head(&(v813_3)) { singleton(&[]) } else { Space::new() };
            drop(v813_3);
            let v813_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v813_4));
            drop(v813_4);
            let v813_8: Space = if (v813_5).is_empty() { Space::new() } else {
              let v814_6: Path = concat_path(&(v812_6),&(v812_7_head));
              let v814_7: Space = routine_54(c, &(v814_6), &(*p1), &(v812_7_tail).make_space());
              map_map_kernels::compose(&(v813_5),&(v814_7))
            };
            drop(v813_5);
            let v813_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v813_2));
            drop(v813_2);
            let v813_10: Space = if map_kernels::has_head(&(v813_9)) { singleton(&[]) } else { Space::new() };
            drop(v813_9);
            let v813_12: Space = if (v813_10).is_empty() { Space::new() } else {
              let v815_6: Path = concat_path(&(v812_6),&(v812_7_head));
              let v815_11: Space = routine_55(c, &(v815_6), &(*p1), &(v812_7_tail).make_space());
              drop(v815_6);
              map_map_kernels::compose(&(v813_10),&(v815_11))
            };
            drop(v813_10);
            let v813_13: Space = map_map_kernels::unite(&(v813_8),&(v813_12));
            v812_7.join_into((v813_13).clone());
            }
            v812_7_cursor.ascend(1);
          }
          drop(v812_7_cursor);
          map_map_kernels::compose(&(v811_5),&(v812_7))
        };
        drop(v811_5);
        let v811_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v811_2));
        drop(v811_2);
        let v811_10: Space = if map_kernels::has_head(&(v811_9)) { singleton(&[]) } else { Space::new() };
        drop(v811_9);
        let v811_11: Space = map_view_kernels::compose(&(v811_10),&(v810_11_tail));
        drop(v811_10);
        let v816_6: Path = concat_path(&(v810_6),&(v810_11_head));
        let v811_12: Space = map_kernels::wrap(&(v811_11),&(v816_6));
        drop(v811_11);
        let v811_13: Space = map_kernels::wrap(&(v811_12),&(*p1));
        drop(v811_12);
        let v811_14: Space = map_map_kernels::unite(&(v811_8),&(v811_13));
        drop(v811_13);
        v810_11.join_into((v811_14).clone());
        }
        v810_11_cursor.ascend(1);
      }
      drop(v810_11_cursor);
      drop(v810_6);
      map_map_kernels::compose(&(v799_10),&(v810_11))
    };
    drop(v799_10);
    let v799_13: Space = map_map_kernels::unite(&(v799_8),&(v799_12));
    v798_21.join_into((v799_13).clone());
    }
    v798_21_cursor.ascend(1);
  }
  drop(v798_21_cursor);
  (v798_21).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v817_15 = Space::new();
  let mut v817_15_cursor = (*s0).read_zipper();
  for v817_15_byte in v817_15_cursor.child_mask().iter() {
    v817_15_cursor.descend_to_byte(v817_15_byte);
    {
    let v817_15_tail = v817_15_cursor.fork_read_zipper();
    let v817_15_head = Path::from_slice(&[v817_15_byte]);
    let v818_2: Space = singleton(&(v817_15_head));
    let v818_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v818_2));
    let v818_4: Space = if map_kernels::has_head(&(v818_3)) { singleton(&[]) } else { Space::new() };
    drop(v818_3);
    let v818_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v818_4));
    drop(v818_4);
    let v818_8: Space = if (v818_5).is_empty() { Space::new() } else {
      let v819_6: Path = concat_path(&(*p0),&(v817_15_head));
      let mut v819_7 = Space::new();
      let mut v819_7_cursor = (v817_15_tail).read_zipper();
      for v819_7_byte in v819_7_cursor.child_mask().iter() {
        v819_7_cursor.descend_to_byte(v819_7_byte);
        {
        let v819_7_tail = v819_7_cursor.fork_read_zipper();
        let v819_7_head = Path::from_slice(&[v819_7_byte]);
        let v820_2: Space = singleton(&(v819_7_head));
        let v820_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v820_2));
        let v820_4: Space = if map_kernels::has_head(&(v820_3)) { singleton(&[]) } else { Space::new() };
        drop(v820_3);
        let v820_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v820_4));
        drop(v820_4);
        let v820_8: Space = if (v820_5).is_empty() { Space::new() } else {
          let v821_6: Path = concat_path(&(v819_6),&(v819_7_head));
          let mut v821_7 = Space::new();
          let mut v821_7_cursor = (v819_7_tail).read_zipper();
          for v821_7_byte in v821_7_cursor.child_mask().iter() {
            v821_7_cursor.descend_to_byte(v821_7_byte);
            {
            let v821_7_tail = v821_7_cursor.fork_read_zipper();
            let v821_7_head = Path::from_slice(&[v821_7_byte]);
            let v822_2: Space = singleton(&(v821_7_head));
            let v822_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v822_2));
            let v822_4: Space = if map_kernels::has_head(&(v822_3)) { singleton(&[]) } else { Space::new() };
            drop(v822_3);
            let v822_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v822_4));
            drop(v822_4);
            let v822_8: Space = if (v822_5).is_empty() { Space::new() } else {
              let v823_6: Path = concat_path(&(v821_6),&(v821_7_head));
              let v823_7: Space = routine_54(c, &(v823_6), &(*p1), &(v821_7_tail).make_space());
              map_map_kernels::compose(&(v822_5),&(v823_7))
            };
            drop(v822_5);
            let v822_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v822_2));
            drop(v822_2);
            let v822_10: Space = if map_kernels::has_head(&(v822_9)) { singleton(&[]) } else { Space::new() };
            drop(v822_9);
            let v822_12: Space = if (v822_10).is_empty() { Space::new() } else {
              let v824_6: Path = concat_path(&(v821_6),&(v821_7_head));
              let v824_11: Space = routine_55(c, &(v824_6), &(*p1), &(v821_7_tail).make_space());
              drop(v824_6);
              map_map_kernels::compose(&(v822_10),&(v824_11))
            };
            drop(v822_10);
            let v822_13: Space = map_map_kernels::unite(&(v822_8),&(v822_12));
            v821_7.join_into((v822_13).clone());
            }
            v821_7_cursor.ascend(1);
          }
          drop(v821_7_cursor);
          map_map_kernels::compose(&(v820_5),&(v821_7))
        };
        drop(v820_5);
        let v820_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v820_2));
        drop(v820_2);
        let v820_10: Space = if map_kernels::has_head(&(v820_9)) { singleton(&[]) } else { Space::new() };
        drop(v820_9);
        let v820_12: Space = if (v820_10).is_empty() { Space::new() } else {
          let v825_6: Path = concat_path(&(v819_6),&(v819_7_head));
          let mut v825_11 = Space::new();
          let mut v825_11_cursor = (v819_7_tail).read_zipper();
          for v825_11_byte in v825_11_cursor.child_mask().iter() {
            v825_11_cursor.descend_to_byte(v825_11_byte);
            {
            let v825_11_tail = v825_11_cursor.fork_read_zipper();
            let v825_11_head = Path::from_slice(&[v825_11_byte]);
            let v826_2: Space = singleton(&(v825_11_head));
            let v826_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v826_2));
            let v826_4: Space = if map_kernels::has_head(&(v826_3)) { singleton(&[]) } else { Space::new() };
            drop(v826_3);
            let v826_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v826_4));
            drop(v826_4);
            let v826_8: Space = if (v826_5).is_empty() { Space::new() } else {
              let v827_6: Path = concat_path(&(v825_6),&(v825_11_head));
              let v827_7: Space = routine_54(c, &(v827_6), &(*p1), &(v825_11_tail).make_space());
              map_map_kernels::compose(&(v826_5),&(v827_7))
            };
            drop(v826_5);
            let v826_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v826_2));
            drop(v826_2);
            let v826_10: Space = if map_kernels::has_head(&(v826_9)) { singleton(&[]) } else { Space::new() };
            drop(v826_9);
            let v826_12: Space = if (v826_10).is_empty() { Space::new() } else {
              let v828_6: Path = concat_path(&(v825_6),&(v825_11_head));
              let v828_11: Space = routine_19(c, &(v828_6), &(*p1), &(v825_11_tail).make_space());
              drop(v828_6);
              map_map_kernels::compose(&(v826_10),&(v828_11))
            };
            drop(v826_10);
            let v826_13: Space = map_map_kernels::unite(&(v826_8),&(v826_12));
            v825_11.join_into((v826_13).clone());
            }
            v825_11_cursor.ascend(1);
          }
          drop(v825_11_cursor);
          drop(v825_6);
          map_map_kernels::compose(&(v820_10),&(v825_11))
        };
        drop(v820_10);
        let v820_13: Space = map_map_kernels::unite(&(v820_8),&(v820_12));
        v819_7.join_into((v820_13).clone());
        }
        v819_7_cursor.ascend(1);
      }
      drop(v819_7_cursor);
      map_map_kernels::compose(&(v818_5),&(v819_7))
    };
    drop(v818_5);
    let v818_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v818_2));
    drop(v818_2);
    let v818_10: Space = if map_kernels::has_head(&(v818_9)) { singleton(&[]) } else { Space::new() };
    drop(v818_9);
    let v818_11: Space = map_view_kernels::compose(&(v818_10),&(v817_15_tail));
    drop(v818_10);
    let v829_6: Path = concat_path(&(*p0),&(v817_15_head));
    let v818_12: Space = map_kernels::wrap(&(v818_11),&(v829_6));
    drop(v818_11);
    let v818_13: Space = map_kernels::wrap(&(v818_12),&(*p1));
    drop(v818_12);
    let v818_14: Space = map_map_kernels::unite(&(v818_8),&(v818_13));
    drop(v818_13);
    v817_15.join_into((v818_14).clone());
    }
    v817_15_cursor.ascend(1);
  }
  drop(v817_15_cursor);
  (v817_15).clone()
}

fn routine_44(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v830_15: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v830_16: Space = map_kernels::unwrap(&(v830_15),&(*p0));
  drop(v830_15);
  let mut v830_20 = Space::new();
  let mut v830_20_cursor = (*s0).read_zipper();
  for v830_20_byte in v830_20_cursor.child_mask().iter() {
    v830_20_cursor.descend_to_byte(v830_20_byte);
    {
    let v830_20_tail = v830_20_cursor.fork_read_zipper();
    let v830_20_head = Path::from_slice(&[v830_20_byte]);
    let v831_2: Space = singleton(&(v830_20_head));
    let v831_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v831_2));
    let v831_4: Space = if map_kernels::has_head(&(v831_3)) { singleton(&[]) } else { Space::new() };
    drop(v831_3);
    let v831_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v831_4));
    drop(v831_4);
    let v831_8: Space = if (v831_5).is_empty() { Space::new() } else {
      let v832_6: Path = concat_path(&(*p0),&(v830_20_head));
      let mut v832_7 = Space::new();
      let mut v832_7_cursor = (v830_20_tail).read_zipper();
      for v832_7_byte in v832_7_cursor.child_mask().iter() {
        v832_7_cursor.descend_to_byte(v832_7_byte);
        {
        let v832_7_tail = v832_7_cursor.fork_read_zipper();
        let v832_7_head = Path::from_slice(&[v832_7_byte]);
        let v833_2: Space = singleton(&(v832_7_head));
        let v833_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v833_2));
        let v833_4: Space = if map_kernels::has_head(&(v833_3)) { singleton(&[]) } else { Space::new() };
        drop(v833_3);
        let v833_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v833_4));
        drop(v833_4);
        let mut v833_6 = Space::new();
        let mut v833_6_cursor = (v832_7_tail).read_zipper();
        for v833_6_byte in v833_6_cursor.child_mask().iter() {
          v833_6_cursor.descend_to_byte(v833_6_byte);
          {
          let v833_6_tail = v833_6_cursor.fork_read_zipper();
          let v833_6_head = Path::from_slice(&[v833_6_byte]);
          let v834_2: Space = Space::new();
          v833_6.join_into((v834_2).clone());
          }
          v833_6_cursor.ascend(1);
        }
        drop(v833_6_cursor);
        let v833_7: Space = map_map_kernels::compose(&(v833_5),&(v833_6));
        drop(v833_5);
        drop(v833_6);
        let v833_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v833_2));
        drop(v833_2);
        let v833_9: Space = if map_kernels::has_head(&(v833_8)) { singleton(&[]) } else { Space::new() };
        drop(v833_8);
        let v833_12: Space = if (v833_9).is_empty() { Space::new() } else {
          let v835_10: Path = concat_path(&(v832_6),&(v832_7_head));
          let mut v835_11 = Space::new();
          let mut v835_11_cursor = (v832_7_tail).read_zipper();
          for v835_11_byte in v835_11_cursor.child_mask().iter() {
            v835_11_cursor.descend_to_byte(v835_11_byte);
            {
            let v835_11_tail = v835_11_cursor.fork_read_zipper();
            let v835_11_head = Path::from_slice(&[v835_11_byte]);
            let v836_2: Space = singleton(&(v835_11_head));
            let v836_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v836_2));
            drop(v836_2);
            let v836_4: Space = if map_kernels::has_head(&(v836_3)) { singleton(&[]) } else { Space::new() };
            drop(v836_3);
            let v836_7: Space = if (v836_4).is_empty() { Space::new() } else {
              let v837_5: Path = concat_path(&(v835_10),&(v835_11_head));
              let v837_6: Space = routine_10(c, &(v837_5), &(*p1), &(v835_11_tail).make_space(), &(*s1));
              drop(v837_5);
              map_map_kernels::compose(&(v836_4),&(v837_6))
            };
            drop(v836_4);
            v835_11.join_into((v836_7).clone());
            }
            v835_11_cursor.ascend(1);
          }
          drop(v835_11_cursor);
          drop(v835_10);
          map_map_kernels::compose(&(v833_9),&(v835_11))
        };
        drop(v833_9);
        let v833_13: Space = map_map_kernels::unite(&(v833_7),&(v833_12));
        drop(v833_7);
        v832_7.join_into((v833_13).clone());
        }
        v832_7_cursor.ascend(1);
      }
      drop(v832_7_cursor);
      drop(v832_6);
      map_map_kernels::compose(&(v831_5),&(v832_7))
    };
    drop(v831_5);
    let v831_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v831_2));
    drop(v831_2);
    let v831_10: Space = if map_kernels::has_head(&(v831_9)) { singleton(&[]) } else { Space::new() };
    drop(v831_9);
    let v831_13: Space = if (v831_10).is_empty() { Space::new() } else {
      let v838_11: Space = map_kernels::unwrap(&(v830_16),&(v830_20_head));
      let mut v838_12 = Space::new();
      let mut v838_12_cursor = (v830_20_tail).read_zipper();
      for v838_12_byte in v838_12_cursor.child_mask().iter() {
        v838_12_cursor.descend_to_byte(v838_12_byte);
        {
        let v838_12_tail = v838_12_cursor.fork_read_zipper();
        let v838_12_head = Path::from_slice(&[v838_12_byte]);
        let v839_2: Space = singleton(&(v838_12_head));
        let v839_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v839_2));
        let v839_4: Space = if map_kernels::has_head(&(v839_3)) { singleton(&[]) } else { Space::new() };
        drop(v839_3);
        let v839_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v839_4));
        drop(v839_4);
        let mut v839_6 = Space::new();
        let mut v839_6_cursor = (v838_12_tail).read_zipper();
        for v839_6_byte in v839_6_cursor.child_mask().iter() {
          v839_6_cursor.descend_to_byte(v839_6_byte);
          {
          let v839_6_tail = v839_6_cursor.fork_read_zipper();
          let v839_6_head = Path::from_slice(&[v839_6_byte]);
          let v840_2: Space = Space::new();
          v839_6.join_into((v840_2).clone());
          }
          v839_6_cursor.ascend(1);
        }
        drop(v839_6_cursor);
        let v839_7: Space = map_map_kernels::compose(&(v839_5),&(v839_6));
        drop(v839_5);
        drop(v839_6);
        let v839_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v839_2));
        drop(v839_2);
        let v839_9: Space = if map_kernels::has_head(&(v839_8)) { singleton(&[]) } else { Space::new() };
        drop(v839_8);
        let v839_12: Space = if (v839_9).is_empty() { Space::new() } else {
          let v841_10: Space = map_kernels::unwrap(&(v838_11),&(v838_12_head));
          let mut v841_11 = Space::new();
          let mut v841_11_cursor = (v841_10).read_zipper();
          for v841_11_byte in v841_11_cursor.child_mask().iter() {
            v841_11_cursor.descend_to_byte(v841_11_byte);
            {
            let v841_11_tail = v841_11_cursor.fork_read_zipper();
            let v841_11_head = Path::from_slice(&[v841_11_byte]);
            let v842_2: Space = singleton(&(v841_11_head));
            let v842_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v842_2));
            let v842_4: Space = if map_kernels::has_head(&(v842_3)) { singleton(&[]) } else { Space::new() };
            drop(v842_3);
            let v842_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v842_4));
            drop(v842_4);
            let v842_7: Space = if (v842_5).is_empty() { Space::new() } else {
              let v843_6: Space = routine_13(c, &(v841_11_head), &(*p1), &(v841_11_tail).make_space());
              map_map_kernels::compose(&(v842_5),&(v843_6))
            };
            drop(v842_5);
            let v842_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v842_2));
            drop(v842_2);
            let v842_9: Space = if map_kernels::has_head(&(v842_8)) { singleton(&[]) } else { Space::new() };
            drop(v842_8);
            let v842_11: Space = if (v842_9).is_empty() { Space::new() } else {
              let v844_10: Space = routine_14(c, &(v841_11_head), &(*p1), &(v841_11_tail).make_space());
              map_map_kernels::compose(&(v842_9),&(v844_10))
            };
            drop(v842_9);
            let v842_12: Space = map_map_kernels::unite(&(v842_7),&(v842_11));
            v841_11.join_into((v842_12).clone());
            }
            v841_11_cursor.ascend(1);
          }
          drop(v841_11_cursor);
          drop(v841_10);
          map_map_kernels::compose(&(v839_9),&(v841_11))
        };
        drop(v839_9);
        let v839_13: Space = map_map_kernels::unite(&(v839_7),&(v839_12));
        drop(v839_7);
        v838_12.join_into((v839_13).clone());
        }
        v838_12_cursor.ascend(1);
      }
      drop(v838_12_cursor);
      drop(v838_11);
      map_map_kernels::compose(&(v831_10),&(v838_12))
    };
    drop(v831_10);
    let v831_14: Space = map_map_kernels::unite(&(v831_8),&(v831_13));
    v830_20.join_into((v831_14).clone());
    }
    v830_20_cursor.ascend(1);
  }
  drop(v830_20_cursor);
  drop(v830_16);
  (v830_20).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v845_8: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v845_9: Space = map_kernels::unwrap(&(v845_8),&(*p0));
  drop(v845_8);
  let mut v845_23 = Space::new();
  let mut v845_23_cursor = (*s0).read_zipper();
  for v845_23_byte in v845_23_cursor.child_mask().iter() {
    v845_23_cursor.descend_to_byte(v845_23_byte);
    {
    let v845_23_tail = v845_23_cursor.fork_read_zipper();
    let v845_23_head = Path::from_slice(&[v845_23_byte]);
    let v846_2: Space = singleton(&(v845_23_head));
    let v846_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v846_2));
    let v846_4: Space = if map_kernels::has_head(&(v846_3)) { singleton(&[]) } else { Space::new() };
    drop(v846_3);
    let v846_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v846_4));
    drop(v846_4);
    let v846_8: Space = if (v846_5).is_empty() { Space::new() } else {
      let v847_6: Path = concat_path(&(*p0),&(v845_23_head));
      let mut v847_7 = Space::new();
      let mut v847_7_cursor = (v845_23_tail).read_zipper();
      for v847_7_byte in v847_7_cursor.child_mask().iter() {
        v847_7_cursor.descend_to_byte(v847_7_byte);
        {
        let v847_7_tail = v847_7_cursor.fork_read_zipper();
        let v847_7_head = Path::from_slice(&[v847_7_byte]);
        let v848_2: Space = singleton(&(v847_7_head));
        let v848_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v848_2));
        let v848_4: Space = if map_kernels::has_head(&(v848_3)) { singleton(&[]) } else { Space::new() };
        drop(v848_3);
        let v848_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v848_4));
        drop(v848_4);
        let mut v848_6 = Space::new();
        let mut v848_6_cursor = (v847_7_tail).read_zipper();
        for v848_6_byte in v848_6_cursor.child_mask().iter() {
          v848_6_cursor.descend_to_byte(v848_6_byte);
          {
          let v848_6_tail = v848_6_cursor.fork_read_zipper();
          let v848_6_head = Path::from_slice(&[v848_6_byte]);
          let v849_2: Space = Space::new();
          v848_6.join_into((v849_2).clone());
          }
          v848_6_cursor.ascend(1);
        }
        drop(v848_6_cursor);
        let v848_7: Space = map_map_kernels::compose(&(v848_5),&(v848_6));
        drop(v848_5);
        drop(v848_6);
        let v848_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v848_2));
        drop(v848_2);
        let v848_9: Space = if map_kernels::has_head(&(v848_8)) { singleton(&[]) } else { Space::new() };
        drop(v848_8);
        let v848_12: Space = if (v848_9).is_empty() { Space::new() } else {
          let v850_10: Path = concat_path(&(v847_6),&(v847_7_head));
          let mut v850_11 = Space::new();
          let mut v850_11_cursor = (v847_7_tail).read_zipper();
          for v850_11_byte in v850_11_cursor.child_mask().iter() {
            v850_11_cursor.descend_to_byte(v850_11_byte);
            {
            let v850_11_tail = v850_11_cursor.fork_read_zipper();
            let v850_11_head = Path::from_slice(&[v850_11_byte]);
            let v851_2: Space = singleton(&(v850_11_head));
            let v851_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v851_2));
            drop(v851_2);
            let v851_4: Space = if map_kernels::has_head(&(v851_3)) { singleton(&[]) } else { Space::new() };
            drop(v851_3);
            let v851_7: Space = if (v851_4).is_empty() { Space::new() } else {
              let v852_5: Path = concat_path(&(v850_10),&(v850_11_head));
              let v852_6: Space = routine_10(c, &(v852_5), &(*p1), &(v850_11_tail).make_space(), &(*s1));
              drop(v852_5);
              map_map_kernels::compose(&(v851_4),&(v852_6))
            };
            drop(v851_4);
            v850_11.join_into((v851_7).clone());
            }
            v850_11_cursor.ascend(1);
          }
          drop(v850_11_cursor);
          drop(v850_10);
          map_map_kernels::compose(&(v848_9),&(v850_11))
        };
        drop(v848_9);
        let v848_13: Space = map_map_kernels::unite(&(v848_7),&(v848_12));
        drop(v848_7);
        v847_7.join_into((v848_13).clone());
        }
        v847_7_cursor.ascend(1);
      }
      drop(v847_7_cursor);
      drop(v847_6);
      map_map_kernels::compose(&(v846_5),&(v847_7))
    };
    drop(v846_5);
    let v846_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v846_2));
    drop(v846_2);
    let v846_10: Space = if map_kernels::has_head(&(v846_9)) { singleton(&[]) } else { Space::new() };
    drop(v846_9);
    let v846_13: Space = if (v846_10).is_empty() { Space::new() } else {
      let v853_11: Space = map_kernels::unwrap(&(v845_9),&(v845_23_head));
      let mut v853_12 = Space::new();
      let mut v853_12_cursor = (v853_11).read_zipper();
      for v853_12_byte in v853_12_cursor.child_mask().iter() {
        v853_12_cursor.descend_to_byte(v853_12_byte);
        {
        let v853_12_tail = v853_12_cursor.fork_read_zipper();
        let v853_12_head = Path::from_slice(&[v853_12_byte]);
        let v854_2: Space = singleton(&(v853_12_head));
        let v854_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v854_2));
        let v854_4: Space = if map_kernels::has_head(&(v854_3)) { singleton(&[]) } else { Space::new() };
        drop(v854_3);
        let v854_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v854_4));
        drop(v854_4);
        let v854_7: Space = if (v854_5).is_empty() { Space::new() } else {
          let mut v855_6 = Space::new();
          let mut v855_6_cursor = (v853_12_tail).read_zipper();
          for v855_6_byte in v855_6_cursor.child_mask().iter() {
            v855_6_cursor.descend_to_byte(v855_6_byte);
            {
            let v855_6_tail = v855_6_cursor.fork_read_zipper();
            let v855_6_head = Path::from_slice(&[v855_6_byte]);
            let v856_2: Space = singleton(&(v855_6_head));
            let v856_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v856_2));
            let v856_4: Space = if map_kernels::has_head(&(v856_3)) { singleton(&[]) } else { Space::new() };
            drop(v856_3);
            let v856_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v856_4));
            drop(v856_4);
            let v856_8: Space = if (v856_5).is_empty() { Space::new() } else {
              let v857_6: Path = concat_path(&(v853_12_head),&(v855_6_head));
              let v857_7: Space = routine_17(c, &(v857_6), &(*p1), &(v855_6_tail).make_space());
              map_map_kernels::compose(&(v856_5),&(v857_7))
            };
            drop(v856_5);
            let v856_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v856_2));
            drop(v856_2);
            let v856_10: Space = if map_kernels::has_head(&(v856_9)) { singleton(&[]) } else { Space::new() };
            drop(v856_9);
            let v856_12: Space = if (v856_10).is_empty() { Space::new() } else {
              let v858_6: Path = concat_path(&(v853_12_head),&(v855_6_head));
              let v858_11: Space = routine_18(c, &(v858_6), &(*p1), &(v855_6_tail).make_space());
              drop(v858_6);
              map_map_kernels::compose(&(v856_10),&(v858_11))
            };
            drop(v856_10);
            let v856_13: Space = map_map_kernels::unite(&(v856_8),&(v856_12));
            v855_6.join_into((v856_13).clone());
            }
            v855_6_cursor.ascend(1);
          }
          drop(v855_6_cursor);
          map_map_kernels::compose(&(v854_5),&(v855_6))
        };
        drop(v854_5);
        let v854_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v854_2));
        drop(v854_2);
        let v854_9: Space = if map_kernels::has_head(&(v854_8)) { singleton(&[]) } else { Space::new() };
        drop(v854_8);
        let v854_11: Space = if (v854_9).is_empty() { Space::new() } else {
          let mut v859_10 = Space::new();
          let mut v859_10_cursor = (v853_12_tail).read_zipper();
          for v859_10_byte in v859_10_cursor.child_mask().iter() {
            v859_10_cursor.descend_to_byte(v859_10_byte);
            {
            let v859_10_tail = v859_10_cursor.fork_read_zipper();
            let v859_10_head = Path::from_slice(&[v859_10_byte]);
            let v860_2: Space = singleton(&(v859_10_head));
            let v860_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v860_2));
            let v860_4: Space = if map_kernels::has_head(&(v860_3)) { singleton(&[]) } else { Space::new() };
            drop(v860_3);
            let v860_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v860_4));
            drop(v860_4);
            let v860_8: Space = if (v860_5).is_empty() { Space::new() } else {
              let v861_6: Path = concat_path(&(v853_12_head),&(v859_10_head));
              let v861_7: Space = routine_17(c, &(v861_6), &(*p1), &(v859_10_tail).make_space());
              map_map_kernels::compose(&(v860_5),&(v861_7))
            };
            drop(v860_5);
            let v860_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v860_2));
            drop(v860_2);
            let v860_10: Space = if map_kernels::has_head(&(v860_9)) { singleton(&[]) } else { Space::new() };
            drop(v860_9);
            let v860_12: Space = if (v860_10).is_empty() { Space::new() } else {
              let v862_6: Path = concat_path(&(v853_12_head),&(v859_10_head));
              let v862_11: Space = routine_19(c, &(v862_6), &(*p1), &(v859_10_tail).make_space());
              drop(v862_6);
              map_map_kernels::compose(&(v860_10),&(v862_11))
            };
            drop(v860_10);
            let v860_13: Space = map_map_kernels::unite(&(v860_8),&(v860_12));
            v859_10.join_into((v860_13).clone());
            }
            v859_10_cursor.ascend(1);
          }
          drop(v859_10_cursor);
          map_map_kernels::compose(&(v854_9),&(v859_10))
        };
        drop(v854_9);
        let v854_12: Space = map_map_kernels::unite(&(v854_7),&(v854_11));
        v853_12.join_into((v854_12).clone());
        }
        v853_12_cursor.ascend(1);
      }
      drop(v853_12_cursor);
      drop(v853_11);
      map_map_kernels::compose(&(v846_10),&(v853_12))
    };
    drop(v846_10);
    let v846_14: Space = map_map_kernels::unite(&(v846_8),&(v846_13));
    v845_23.join_into((v846_14).clone());
    }
    v845_23_cursor.ascend(1);
  }
  drop(v845_23_cursor);
  drop(v845_9);
  (v845_23).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v863_21 = Space::new();
  let mut v863_21_cursor = (*s0).read_zipper();
  for v863_21_byte in v863_21_cursor.child_mask().iter() {
    v863_21_cursor.descend_to_byte(v863_21_byte);
    {
    let v863_21_tail = v863_21_cursor.fork_read_zipper();
    let v863_21_head = Path::from_slice(&[v863_21_byte]);
    let v864_2: Space = singleton(&(v863_21_head));
    let v864_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v864_2));
    let v864_4: Space = if map_kernels::has_head(&(v864_3)) { singleton(&[]) } else { Space::new() };
    drop(v864_3);
    let v864_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v864_4));
    drop(v864_4);
    let v864_8: Space = if (v864_5).is_empty() { Space::new() } else {
      let v865_6: Path = concat_path(&(*p0),&(v863_21_head));
      let mut v865_7 = Space::new();
      let mut v865_7_cursor = (v863_21_tail).read_zipper();
      for v865_7_byte in v865_7_cursor.child_mask().iter() {
        v865_7_cursor.descend_to_byte(v865_7_byte);
        {
        let v865_7_tail = v865_7_cursor.fork_read_zipper();
        let v865_7_head = Path::from_slice(&[v865_7_byte]);
        let v866_2: Space = singleton(&(v865_7_head));
        let v866_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v866_2));
        let v866_4: Space = if map_kernels::has_head(&(v866_3)) { singleton(&[]) } else { Space::new() };
        drop(v866_3);
        let v866_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v866_4));
        drop(v866_4);
        let v866_8: Space = if (v866_5).is_empty() { Space::new() } else {
          let v867_6: Path = concat_path(&(v865_6),&(v865_7_head));
          let mut v867_7 = Space::new();
          let mut v867_7_cursor = (v865_7_tail).read_zipper();
          for v867_7_byte in v867_7_cursor.child_mask().iter() {
            v867_7_cursor.descend_to_byte(v867_7_byte);
            {
            let v867_7_tail = v867_7_cursor.fork_read_zipper();
            let v867_7_head = Path::from_slice(&[v867_7_byte]);
            let v868_2: Space = singleton(&(v867_7_head));
            let v868_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v868_2));
            let v868_4: Space = if map_kernels::has_head(&(v868_3)) { singleton(&[]) } else { Space::new() };
            drop(v868_3);
            let v868_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v868_4));
            drop(v868_4);
            let v868_8: Space = if (v868_5).is_empty() { Space::new() } else {
              let v869_6: Path = concat_path(&(v867_6),&(v867_7_head));
              let v869_7: Space = routine_56(c, &(v869_6), &(*p1), &(v867_7_tail).make_space());
              map_map_kernels::compose(&(v868_5),&(v869_7))
            };
            drop(v868_5);
            let v868_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v868_2));
            drop(v868_2);
            let v868_10: Space = if map_kernels::has_head(&(v868_9)) { singleton(&[]) } else { Space::new() };
            drop(v868_9);
            let v868_12: Space = if (v868_10).is_empty() { Space::new() } else {
              let v870_6: Path = concat_path(&(v867_6),&(v867_7_head));
              let v870_11: Space = routine_57(c, &(v870_6), &(*p1), &(v867_7_tail).make_space());
              drop(v870_6);
              map_map_kernels::compose(&(v868_10),&(v870_11))
            };
            drop(v868_10);
            let v868_13: Space = map_map_kernels::unite(&(v868_8),&(v868_12));
            v867_7.join_into((v868_13).clone());
            }
            v867_7_cursor.ascend(1);
          }
          drop(v867_7_cursor);
          map_map_kernels::compose(&(v866_5),&(v867_7))
        };
        drop(v866_5);
        let v866_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v866_2));
        drop(v866_2);
        let v866_10: Space = if map_kernels::has_head(&(v866_9)) { singleton(&[]) } else { Space::new() };
        drop(v866_9);
        let v866_12: Space = if (v866_10).is_empty() { Space::new() } else {
          let v871_6: Path = concat_path(&(v865_6),&(v865_7_head));
          let mut v871_11 = Space::new();
          let mut v871_11_cursor = (v865_7_tail).read_zipper();
          for v871_11_byte in v871_11_cursor.child_mask().iter() {
            v871_11_cursor.descend_to_byte(v871_11_byte);
            {
            let v871_11_tail = v871_11_cursor.fork_read_zipper();
            let v871_11_head = Path::from_slice(&[v871_11_byte]);
            let v872_2: Space = singleton(&(v871_11_head));
            let v872_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v872_2));
            let v872_4: Space = if map_kernels::has_head(&(v872_3)) { singleton(&[]) } else { Space::new() };
            drop(v872_3);
            let v872_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v872_4));
            drop(v872_4);
            let v872_8: Space = if (v872_5).is_empty() { Space::new() } else {
              let v873_6: Path = concat_path(&(v871_6),&(v871_11_head));
              let v873_7: Space = routine_56(c, &(v873_6), &(*p1), &(v871_11_tail).make_space());
              map_map_kernels::compose(&(v872_5),&(v873_7))
            };
            drop(v872_5);
            let v872_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v872_2));
            drop(v872_2);
            let v872_10: Space = if map_kernels::has_head(&(v872_9)) { singleton(&[]) } else { Space::new() };
            drop(v872_9);
            let v872_12: Space = if (v872_10).is_empty() { Space::new() } else {
              let v874_6: Path = concat_path(&(v871_6),&(v871_11_head));
              let v874_11: Space = routine_19(c, &(v874_6), &(*p1), &(v871_11_tail).make_space());
              drop(v874_6);
              map_map_kernels::compose(&(v872_10),&(v874_11))
            };
            drop(v872_10);
            let v872_13: Space = map_map_kernels::unite(&(v872_8),&(v872_12));
            v871_11.join_into((v872_13).clone());
            }
            v871_11_cursor.ascend(1);
          }
          drop(v871_11_cursor);
          drop(v871_6);
          map_map_kernels::compose(&(v866_10),&(v871_11))
        };
        drop(v866_10);
        let v866_13: Space = map_map_kernels::unite(&(v866_8),&(v866_12));
        v865_7.join_into((v866_13).clone());
        }
        v865_7_cursor.ascend(1);
      }
      drop(v865_7_cursor);
      map_map_kernels::compose(&(v864_5),&(v865_7))
    };
    drop(v864_5);
    let v864_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v864_2));
    drop(v864_2);
    let v864_10: Space = if map_kernels::has_head(&(v864_9)) { singleton(&[]) } else { Space::new() };
    drop(v864_9);
    let v864_12: Space = if (v864_10).is_empty() { Space::new() } else {
      let v875_6: Path = concat_path(&(*p0),&(v863_21_head));
      let mut v875_11 = Space::new();
      let mut v875_11_cursor = (v863_21_tail).read_zipper();
      for v875_11_byte in v875_11_cursor.child_mask().iter() {
        v875_11_cursor.descend_to_byte(v875_11_byte);
        {
        let v875_11_tail = v875_11_cursor.fork_read_zipper();
        let v875_11_head = Path::from_slice(&[v875_11_byte]);
        let v876_2: Space = singleton(&(v875_11_head));
        let v876_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v876_2));
        let v876_4: Space = if map_kernels::has_head(&(v876_3)) { singleton(&[]) } else { Space::new() };
        drop(v876_3);
        let v876_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v876_4));
        drop(v876_4);
        let v876_8: Space = if (v876_5).is_empty() { Space::new() } else {
          let v877_6: Path = concat_path(&(v875_6),&(v875_11_head));
          let mut v877_7 = Space::new();
          let mut v877_7_cursor = (v875_11_tail).read_zipper();
          for v877_7_byte in v877_7_cursor.child_mask().iter() {
            v877_7_cursor.descend_to_byte(v877_7_byte);
            {
            let v877_7_tail = v877_7_cursor.fork_read_zipper();
            let v877_7_head = Path::from_slice(&[v877_7_byte]);
            let v878_2: Space = singleton(&(v877_7_head));
            let v878_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v878_2));
            let v878_4: Space = if map_kernels::has_head(&(v878_3)) { singleton(&[]) } else { Space::new() };
            drop(v878_3);
            let v878_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v878_4));
            drop(v878_4);
            let v878_8: Space = if (v878_5).is_empty() { Space::new() } else {
              let v879_6: Path = concat_path(&(v877_6),&(v877_7_head));
              let v879_7: Space = routine_56(c, &(v879_6), &(*p1), &(v877_7_tail).make_space());
              map_map_kernels::compose(&(v878_5),&(v879_7))
            };
            drop(v878_5);
            let v878_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v878_2));
            drop(v878_2);
            let v878_10: Space = if map_kernels::has_head(&(v878_9)) { singleton(&[]) } else { Space::new() };
            drop(v878_9);
            let v878_12: Space = if (v878_10).is_empty() { Space::new() } else {
              let v880_6: Path = concat_path(&(v877_6),&(v877_7_head));
              let v880_11: Space = routine_57(c, &(v880_6), &(*p1), &(v877_7_tail).make_space());
              drop(v880_6);
              map_map_kernels::compose(&(v878_10),&(v880_11))
            };
            drop(v878_10);
            let v878_13: Space = map_map_kernels::unite(&(v878_8),&(v878_12));
            v877_7.join_into((v878_13).clone());
            }
            v877_7_cursor.ascend(1);
          }
          drop(v877_7_cursor);
          map_map_kernels::compose(&(v876_5),&(v877_7))
        };
        drop(v876_5);
        let v876_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v876_2));
        drop(v876_2);
        let v876_10: Space = if map_kernels::has_head(&(v876_9)) { singleton(&[]) } else { Space::new() };
        drop(v876_9);
        let v876_11: Space = map_view_kernels::compose(&(v876_10),&(v875_11_tail));
        drop(v876_10);
        let v881_6: Path = concat_path(&(v875_6),&(v875_11_head));
        let v876_12: Space = map_kernels::wrap(&(v876_11),&(v881_6));
        drop(v876_11);
        let v876_13: Space = map_kernels::wrap(&(v876_12),&(*p1));
        drop(v876_12);
        let v876_14: Space = map_map_kernels::unite(&(v876_8),&(v876_13));
        drop(v876_13);
        v875_11.join_into((v876_14).clone());
        }
        v875_11_cursor.ascend(1);
      }
      drop(v875_11_cursor);
      drop(v875_6);
      map_map_kernels::compose(&(v864_10),&(v875_11))
    };
    drop(v864_10);
    let v864_13: Space = map_map_kernels::unite(&(v864_8),&(v864_12));
    v863_21.join_into((v864_13).clone());
    }
    v863_21_cursor.ascend(1);
  }
  drop(v863_21_cursor);
  (v863_21).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v882_15 = Space::new();
  let mut v882_15_cursor = (*s0).read_zipper();
  for v882_15_byte in v882_15_cursor.child_mask().iter() {
    v882_15_cursor.descend_to_byte(v882_15_byte);
    {
    let v882_15_tail = v882_15_cursor.fork_read_zipper();
    let v882_15_head = Path::from_slice(&[v882_15_byte]);
    let v883_2: Space = singleton(&(v882_15_head));
    let v883_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v883_2));
    let v883_4: Space = if map_kernels::has_head(&(v883_3)) { singleton(&[]) } else { Space::new() };
    drop(v883_3);
    let v883_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v883_4));
    drop(v883_4);
    let v883_8: Space = if (v883_5).is_empty() { Space::new() } else {
      let v884_6: Path = concat_path(&(*p0),&(v882_15_head));
      let mut v884_7 = Space::new();
      let mut v884_7_cursor = (v882_15_tail).read_zipper();
      for v884_7_byte in v884_7_cursor.child_mask().iter() {
        v884_7_cursor.descend_to_byte(v884_7_byte);
        {
        let v884_7_tail = v884_7_cursor.fork_read_zipper();
        let v884_7_head = Path::from_slice(&[v884_7_byte]);
        let v885_2: Space = singleton(&(v884_7_head));
        let v885_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v885_2));
        let v885_4: Space = if map_kernels::has_head(&(v885_3)) { singleton(&[]) } else { Space::new() };
        drop(v885_3);
        let v885_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v885_4));
        drop(v885_4);
        let v885_8: Space = if (v885_5).is_empty() { Space::new() } else {
          let v886_6: Path = concat_path(&(v884_6),&(v884_7_head));
          let mut v886_7 = Space::new();
          let mut v886_7_cursor = (v884_7_tail).read_zipper();
          for v886_7_byte in v886_7_cursor.child_mask().iter() {
            v886_7_cursor.descend_to_byte(v886_7_byte);
            {
            let v886_7_tail = v886_7_cursor.fork_read_zipper();
            let v886_7_head = Path::from_slice(&[v886_7_byte]);
            let v887_2: Space = singleton(&(v886_7_head));
            let v887_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v887_2));
            let v887_4: Space = if map_kernels::has_head(&(v887_3)) { singleton(&[]) } else { Space::new() };
            drop(v887_3);
            let v887_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v887_4));
            drop(v887_4);
            let v887_8: Space = if (v887_5).is_empty() { Space::new() } else {
              let v888_6: Path = concat_path(&(v886_6),&(v886_7_head));
              let v888_7: Space = routine_56(c, &(v888_6), &(*p1), &(v886_7_tail).make_space());
              map_map_kernels::compose(&(v887_5),&(v888_7))
            };
            drop(v887_5);
            let v887_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v887_2));
            drop(v887_2);
            let v887_10: Space = if map_kernels::has_head(&(v887_9)) { singleton(&[]) } else { Space::new() };
            drop(v887_9);
            let v887_12: Space = if (v887_10).is_empty() { Space::new() } else {
              let v889_6: Path = concat_path(&(v886_6),&(v886_7_head));
              let v889_11: Space = routine_57(c, &(v889_6), &(*p1), &(v886_7_tail).make_space());
              drop(v889_6);
              map_map_kernels::compose(&(v887_10),&(v889_11))
            };
            drop(v887_10);
            let v887_13: Space = map_map_kernels::unite(&(v887_8),&(v887_12));
            v886_7.join_into((v887_13).clone());
            }
            v886_7_cursor.ascend(1);
          }
          drop(v886_7_cursor);
          map_map_kernels::compose(&(v885_5),&(v886_7))
        };
        drop(v885_5);
        let v885_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v885_2));
        drop(v885_2);
        let v885_10: Space = if map_kernels::has_head(&(v885_9)) { singleton(&[]) } else { Space::new() };
        drop(v885_9);
        let v885_12: Space = if (v885_10).is_empty() { Space::new() } else {
          let v890_6: Path = concat_path(&(v884_6),&(v884_7_head));
          let mut v890_11 = Space::new();
          let mut v890_11_cursor = (v884_7_tail).read_zipper();
          for v890_11_byte in v890_11_cursor.child_mask().iter() {
            v890_11_cursor.descend_to_byte(v890_11_byte);
            {
            let v890_11_tail = v890_11_cursor.fork_read_zipper();
            let v890_11_head = Path::from_slice(&[v890_11_byte]);
            let v891_2: Space = singleton(&(v890_11_head));
            let v891_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v891_2));
            let v891_4: Space = if map_kernels::has_head(&(v891_3)) { singleton(&[]) } else { Space::new() };
            drop(v891_3);
            let v891_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v891_4));
            drop(v891_4);
            let v891_8: Space = if (v891_5).is_empty() { Space::new() } else {
              let v892_6: Path = concat_path(&(v890_6),&(v890_11_head));
              let v892_7: Space = routine_56(c, &(v892_6), &(*p1), &(v890_11_tail).make_space());
              map_map_kernels::compose(&(v891_5),&(v892_7))
            };
            drop(v891_5);
            let v891_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v891_2));
            drop(v891_2);
            let v891_10: Space = if map_kernels::has_head(&(v891_9)) { singleton(&[]) } else { Space::new() };
            drop(v891_9);
            let v891_12: Space = if (v891_10).is_empty() { Space::new() } else {
              let v893_6: Path = concat_path(&(v890_6),&(v890_11_head));
              let v893_11: Space = routine_19(c, &(v893_6), &(*p1), &(v890_11_tail).make_space());
              drop(v893_6);
              map_map_kernels::compose(&(v891_10),&(v893_11))
            };
            drop(v891_10);
            let v891_13: Space = map_map_kernels::unite(&(v891_8),&(v891_12));
            v890_11.join_into((v891_13).clone());
            }
            v890_11_cursor.ascend(1);
          }
          drop(v890_11_cursor);
          drop(v890_6);
          map_map_kernels::compose(&(v885_10),&(v890_11))
        };
        drop(v885_10);
        let v885_13: Space = map_map_kernels::unite(&(v885_8),&(v885_12));
        v884_7.join_into((v885_13).clone());
        }
        v884_7_cursor.ascend(1);
      }
      drop(v884_7_cursor);
      map_map_kernels::compose(&(v883_5),&(v884_7))
    };
    drop(v883_5);
    let v883_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v883_2));
    drop(v883_2);
    let v883_10: Space = if map_kernels::has_head(&(v883_9)) { singleton(&[]) } else { Space::new() };
    drop(v883_9);
    let v883_11: Space = map_view_kernels::compose(&(v883_10),&(v882_15_tail));
    drop(v883_10);
    let v894_6: Path = concat_path(&(*p0),&(v882_15_head));
    let v883_12: Space = map_kernels::wrap(&(v883_11),&(v894_6));
    drop(v883_11);
    let v883_13: Space = map_kernels::wrap(&(v883_12),&(*p1));
    drop(v883_12);
    let v883_14: Space = map_map_kernels::unite(&(v883_8),&(v883_13));
    drop(v883_13);
    v882_15.join_into((v883_14).clone());
    }
    v882_15_cursor.ascend(1);
  }
  drop(v882_15_cursor);
  (v882_15).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v895_9: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v895_10: Space = map_kernels::unwrap(&(v895_9),&(*p0));
  drop(v895_9);
  let mut v895_14 = Space::new();
  let mut v895_14_cursor = (*s0).read_zipper();
  for v895_14_byte in v895_14_cursor.child_mask().iter() {
    v895_14_cursor.descend_to_byte(v895_14_byte);
    {
    let v895_14_tail = v895_14_cursor.fork_read_zipper();
    let v895_14_head = Path::from_slice(&[v895_14_byte]);
    let v896_2: Space = singleton(&(v895_14_head));
    let v896_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v896_2));
    let v896_4: Space = if map_kernels::has_head(&(v896_3)) { singleton(&[]) } else { Space::new() };
    drop(v896_3);
    let v896_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v896_4));
    drop(v896_4);
    let mut v896_6 = Space::new();
    let mut v896_6_cursor = (v895_14_tail).read_zipper();
    for v896_6_byte in v896_6_cursor.child_mask().iter() {
      v896_6_cursor.descend_to_byte(v896_6_byte);
      {
      let v896_6_tail = v896_6_cursor.fork_read_zipper();
      let v896_6_head = Path::from_slice(&[v896_6_byte]);
      let v897_2: Space = Space::new();
      v896_6.join_into((v897_2).clone());
      }
      v896_6_cursor.ascend(1);
    }
    drop(v896_6_cursor);
    let v896_7: Space = map_map_kernels::compose(&(v896_5),&(v896_6));
    drop(v896_5);
    drop(v896_6);
    let v896_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v896_2));
    drop(v896_2);
    let v896_9: Space = if map_kernels::has_head(&(v896_8)) { singleton(&[]) } else { Space::new() };
    drop(v896_8);
    let v896_12: Space = if (v896_9).is_empty() { Space::new() } else {
      let v898_10: Space = map_kernels::unwrap(&(v895_10),&(v895_14_head));
      let mut v898_11 = Space::new();
      let mut v898_11_cursor = (v895_14_tail).read_zipper();
      for v898_11_byte in v898_11_cursor.child_mask().iter() {
        v898_11_cursor.descend_to_byte(v898_11_byte);
        {
        let v898_11_tail = v898_11_cursor.fork_read_zipper();
        let v898_11_head = Path::from_slice(&[v898_11_byte]);
        let v899_2: Space = singleton(&(v898_11_head));
        let v899_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v899_2));
        drop(v899_2);
        let v899_4: Space = if map_kernels::has_head(&(v899_3)) { singleton(&[]) } else { Space::new() };
        drop(v899_3);
        let v899_7: Space = if (v899_4).is_empty() { Space::new() } else {
          let v900_5: Space = map_kernels::unwrap(&(v898_10),&(v898_11_head));
          let mut v900_6 = Space::new();
          let mut v900_6_cursor = (v900_5).read_zipper();
          for v900_6_byte in v900_6_cursor.child_mask().iter() {
            v900_6_cursor.descend_to_byte(v900_6_byte);
            {
            let v900_6_tail = v900_6_cursor.fork_read_zipper();
            let v900_6_head = Path::from_slice(&[v900_6_byte]);
            let v901_2: Space = singleton(&(v900_6_head));
            let v901_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v901_2));
            let v901_4: Space = if map_kernels::has_head(&(v901_3)) { singleton(&[]) } else { Space::new() };
            drop(v901_3);
            let v901_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v901_4));
            drop(v901_4);
            let v901_7: Space = if (v901_5).is_empty() { Space::new() } else {
              let v902_6: Space = routine_13(c, &(v900_6_head), &(*p1), &(v900_6_tail).make_space());
              map_map_kernels::compose(&(v901_5),&(v902_6))
            };
            drop(v901_5);
            let v901_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v901_2));
            drop(v901_2);
            let v901_9: Space = if map_kernels::has_head(&(v901_8)) { singleton(&[]) } else { Space::new() };
            drop(v901_8);
            let v901_11: Space = if (v901_9).is_empty() { Space::new() } else {
              let v903_10: Space = routine_14(c, &(v900_6_head), &(*p1), &(v900_6_tail).make_space());
              map_map_kernels::compose(&(v901_9),&(v903_10))
            };
            drop(v901_9);
            let v901_12: Space = map_map_kernels::unite(&(v901_7),&(v901_11));
            v900_6.join_into((v901_12).clone());
            }
            v900_6_cursor.ascend(1);
          }
          drop(v900_6_cursor);
          drop(v900_5);
          map_map_kernels::compose(&(v899_4),&(v900_6))
        };
        drop(v899_4);
        v898_11.join_into((v899_7).clone());
        }
        v898_11_cursor.ascend(1);
      }
      drop(v898_11_cursor);
      drop(v898_10);
      map_map_kernels::compose(&(v896_9),&(v898_11))
    };
    drop(v896_9);
    let v896_13: Space = map_map_kernels::unite(&(v896_7),&(v896_12));
    drop(v896_7);
    v895_14.join_into((v896_13).clone());
    }
    v895_14_cursor.ascend(1);
  }
  drop(v895_14_cursor);
  drop(v895_10);
  (v895_14).clone()
}

fn routine_49(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v904_8: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v904_9: Space = map_kernels::unwrap(&(v904_8),&(*p0));
  drop(v904_8);
  let mut v904_19 = Space::new();
  let mut v904_19_cursor = (*s0).read_zipper();
  for v904_19_byte in v904_19_cursor.child_mask().iter() {
    v904_19_cursor.descend_to_byte(v904_19_byte);
    {
    let v904_19_tail = v904_19_cursor.fork_read_zipper();
    let v904_19_head = Path::from_slice(&[v904_19_byte]);
    let v905_2: Space = singleton(&(v904_19_head));
    let v905_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v905_2));
    let v905_4: Space = if map_kernels::has_head(&(v905_3)) { singleton(&[]) } else { Space::new() };
    drop(v905_3);
    let v905_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v905_4));
    drop(v905_4);
    let mut v905_6 = Space::new();
    let mut v905_6_cursor = (v904_19_tail).read_zipper();
    for v905_6_byte in v905_6_cursor.child_mask().iter() {
      v905_6_cursor.descend_to_byte(v905_6_byte);
      {
      let v905_6_tail = v905_6_cursor.fork_read_zipper();
      let v905_6_head = Path::from_slice(&[v905_6_byte]);
      let v906_2: Space = Space::new();
      v905_6.join_into((v906_2).clone());
      }
      v905_6_cursor.ascend(1);
    }
    drop(v905_6_cursor);
    let v905_7: Space = map_map_kernels::compose(&(v905_5),&(v905_6));
    drop(v905_5);
    drop(v905_6);
    let v905_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v905_2));
    drop(v905_2);
    let v905_9: Space = if map_kernels::has_head(&(v905_8)) { singleton(&[]) } else { Space::new() };
    drop(v905_8);
    let v905_12: Space = if (v905_9).is_empty() { Space::new() } else {
      let v907_10: Space = map_kernels::unwrap(&(v904_9),&(v904_19_head));
      let mut v907_11 = Space::new();
      let mut v907_11_cursor = (v907_10).read_zipper();
      for v907_11_byte in v907_11_cursor.child_mask().iter() {
        v907_11_cursor.descend_to_byte(v907_11_byte);
        {
        let v907_11_tail = v907_11_cursor.fork_read_zipper();
        let v907_11_head = Path::from_slice(&[v907_11_byte]);
        let v908_2: Space = singleton(&(v907_11_head));
        let v908_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v908_2));
        let v908_4: Space = if map_kernels::has_head(&(v908_3)) { singleton(&[]) } else { Space::new() };
        drop(v908_3);
        let v908_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v908_4));
        drop(v908_4);
        let v908_7: Space = if (v908_5).is_empty() { Space::new() } else {
          let mut v909_6 = Space::new();
          let mut v909_6_cursor = (v907_11_tail).read_zipper();
          for v909_6_byte in v909_6_cursor.child_mask().iter() {
            v909_6_cursor.descend_to_byte(v909_6_byte);
            {
            let v909_6_tail = v909_6_cursor.fork_read_zipper();
            let v909_6_head = Path::from_slice(&[v909_6_byte]);
            let v910_2: Space = singleton(&(v909_6_head));
            let v910_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v910_2));
            let v910_4: Space = if map_kernels::has_head(&(v910_3)) { singleton(&[]) } else { Space::new() };
            drop(v910_3);
            let v910_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v910_4));
            drop(v910_4);
            let v910_8: Space = if (v910_5).is_empty() { Space::new() } else {
              let v911_6: Path = concat_path(&(v907_11_head),&(v909_6_head));
              let v911_7: Space = routine_17(c, &(v911_6), &(*p1), &(v909_6_tail).make_space());
              map_map_kernels::compose(&(v910_5),&(v911_7))
            };
            drop(v910_5);
            let v910_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v910_2));
            drop(v910_2);
            let v910_10: Space = if map_kernels::has_head(&(v910_9)) { singleton(&[]) } else { Space::new() };
            drop(v910_9);
            let v910_12: Space = if (v910_10).is_empty() { Space::new() } else {
              let v912_6: Path = concat_path(&(v907_11_head),&(v909_6_head));
              let v912_11: Space = routine_18(c, &(v912_6), &(*p1), &(v909_6_tail).make_space());
              drop(v912_6);
              map_map_kernels::compose(&(v910_10),&(v912_11))
            };
            drop(v910_10);
            let v910_13: Space = map_map_kernels::unite(&(v910_8),&(v910_12));
            v909_6.join_into((v910_13).clone());
            }
            v909_6_cursor.ascend(1);
          }
          drop(v909_6_cursor);
          map_map_kernels::compose(&(v908_5),&(v909_6))
        };
        drop(v908_5);
        let v908_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v908_2));
        drop(v908_2);
        let v908_9: Space = if map_kernels::has_head(&(v908_8)) { singleton(&[]) } else { Space::new() };
        drop(v908_8);
        let v908_11: Space = if (v908_9).is_empty() { Space::new() } else {
          let mut v913_10 = Space::new();
          let mut v913_10_cursor = (v907_11_tail).read_zipper();
          for v913_10_byte in v913_10_cursor.child_mask().iter() {
            v913_10_cursor.descend_to_byte(v913_10_byte);
            {
            let v913_10_tail = v913_10_cursor.fork_read_zipper();
            let v913_10_head = Path::from_slice(&[v913_10_byte]);
            let v914_2: Space = singleton(&(v913_10_head));
            let v914_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v914_2));
            let v914_4: Space = if map_kernels::has_head(&(v914_3)) { singleton(&[]) } else { Space::new() };
            drop(v914_3);
            let v914_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v914_4));
            drop(v914_4);
            let v914_8: Space = if (v914_5).is_empty() { Space::new() } else {
              let v915_6: Path = concat_path(&(v907_11_head),&(v913_10_head));
              let v915_7: Space = routine_17(c, &(v915_6), &(*p1), &(v913_10_tail).make_space());
              map_map_kernels::compose(&(v914_5),&(v915_7))
            };
            drop(v914_5);
            let v914_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v914_2));
            drop(v914_2);
            let v914_10: Space = if map_kernels::has_head(&(v914_9)) { singleton(&[]) } else { Space::new() };
            drop(v914_9);
            let v914_12: Space = if (v914_10).is_empty() { Space::new() } else {
              let v916_6: Path = concat_path(&(v907_11_head),&(v913_10_head));
              let v916_11: Space = routine_19(c, &(v916_6), &(*p1), &(v913_10_tail).make_space());
              drop(v916_6);
              map_map_kernels::compose(&(v914_10),&(v916_11))
            };
            drop(v914_10);
            let v914_13: Space = map_map_kernels::unite(&(v914_8),&(v914_12));
            v913_10.join_into((v914_13).clone());
            }
            v913_10_cursor.ascend(1);
          }
          drop(v913_10_cursor);
          map_map_kernels::compose(&(v908_9),&(v913_10))
        };
        drop(v908_9);
        let v908_12: Space = map_map_kernels::unite(&(v908_7),&(v908_11));
        v907_11.join_into((v908_12).clone());
        }
        v907_11_cursor.ascend(1);
      }
      drop(v907_11_cursor);
      drop(v907_10);
      map_map_kernels::compose(&(v905_9),&(v907_11))
    };
    drop(v905_9);
    let v905_13: Space = map_map_kernels::unite(&(v905_7),&(v905_12));
    drop(v905_7);
    v904_19.join_into((v905_13).clone());
    }
    v904_19_cursor.ascend(1);
  }
  drop(v904_19_cursor);
  drop(v904_9);
  (v904_19).clone()
}

fn routine_50(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v917_21 = Space::new();
  let mut v917_21_cursor = (*s0).read_zipper();
  for v917_21_byte in v917_21_cursor.child_mask().iter() {
    v917_21_cursor.descend_to_byte(v917_21_byte);
    {
    let v917_21_tail = v917_21_cursor.fork_read_zipper();
    let v917_21_head = Path::from_slice(&[v917_21_byte]);
    let v918_2: Space = singleton(&(v917_21_head));
    let v918_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v918_2));
    let v918_4: Space = if map_kernels::has_head(&(v918_3)) { singleton(&[]) } else { Space::new() };
    drop(v918_3);
    let v918_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v918_4));
    drop(v918_4);
    let v918_8: Space = if (v918_5).is_empty() { Space::new() } else {
      let v919_6: Path = concat_path(&(*p0),&(v917_21_head));
      let mut v919_7 = Space::new();
      let mut v919_7_cursor = (v917_21_tail).read_zipper();
      for v919_7_byte in v919_7_cursor.child_mask().iter() {
        v919_7_cursor.descend_to_byte(v919_7_byte);
        {
        let v919_7_tail = v919_7_cursor.fork_read_zipper();
        let v919_7_head = Path::from_slice(&[v919_7_byte]);
        let v920_2: Space = singleton(&(v919_7_head));
        let v920_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v920_2));
        let v920_4: Space = if map_kernels::has_head(&(v920_3)) { singleton(&[]) } else { Space::new() };
        drop(v920_3);
        let v920_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v920_4));
        drop(v920_4);
        let v920_8: Space = if (v920_5).is_empty() { Space::new() } else {
          let v921_6: Path = concat_path(&(v919_6),&(v919_7_head));
          let mut v921_7 = Space::new();
          let mut v921_7_cursor = (v919_7_tail).read_zipper();
          for v921_7_byte in v921_7_cursor.child_mask().iter() {
            v921_7_cursor.descend_to_byte(v921_7_byte);
            {
            let v921_7_tail = v921_7_cursor.fork_read_zipper();
            let v921_7_head = Path::from_slice(&[v921_7_byte]);
            let v922_2: Space = singleton(&(v921_7_head));
            let v922_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v922_2));
            let v922_4: Space = if map_kernels::has_head(&(v922_3)) { singleton(&[]) } else { Space::new() };
            drop(v922_3);
            let v922_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v922_4));
            drop(v922_4);
            let v922_8: Space = if (v922_5).is_empty() { Space::new() } else {
              let v923_6: Path = concat_path(&(v921_6),&(v921_7_head));
              let v923_7: Space = routine_58(c, &(v923_6), &(*p1), &(v921_7_tail).make_space());
              map_map_kernels::compose(&(v922_5),&(v923_7))
            };
            drop(v922_5);
            let v922_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v922_2));
            drop(v922_2);
            let v922_10: Space = if map_kernels::has_head(&(v922_9)) { singleton(&[]) } else { Space::new() };
            drop(v922_9);
            let v922_12: Space = if (v922_10).is_empty() { Space::new() } else {
              let v924_6: Path = concat_path(&(v921_6),&(v921_7_head));
              let v924_11: Space = routine_59(c, &(v924_6), &(*p1), &(v921_7_tail).make_space());
              drop(v924_6);
              map_map_kernels::compose(&(v922_10),&(v924_11))
            };
            drop(v922_10);
            let v922_13: Space = map_map_kernels::unite(&(v922_8),&(v922_12));
            v921_7.join_into((v922_13).clone());
            }
            v921_7_cursor.ascend(1);
          }
          drop(v921_7_cursor);
          map_map_kernels::compose(&(v920_5),&(v921_7))
        };
        drop(v920_5);
        let v920_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v920_2));
        drop(v920_2);
        let v920_10: Space = if map_kernels::has_head(&(v920_9)) { singleton(&[]) } else { Space::new() };
        drop(v920_9);
        let v920_12: Space = if (v920_10).is_empty() { Space::new() } else {
          let v925_6: Path = concat_path(&(v919_6),&(v919_7_head));
          let mut v925_11 = Space::new();
          let mut v925_11_cursor = (v919_7_tail).read_zipper();
          for v925_11_byte in v925_11_cursor.child_mask().iter() {
            v925_11_cursor.descend_to_byte(v925_11_byte);
            {
            let v925_11_tail = v925_11_cursor.fork_read_zipper();
            let v925_11_head = Path::from_slice(&[v925_11_byte]);
            let v926_2: Space = singleton(&(v925_11_head));
            let v926_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v926_2));
            let v926_4: Space = if map_kernels::has_head(&(v926_3)) { singleton(&[]) } else { Space::new() };
            drop(v926_3);
            let v926_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v926_4));
            drop(v926_4);
            let v926_8: Space = if (v926_5).is_empty() { Space::new() } else {
              let v927_6: Path = concat_path(&(v925_6),&(v925_11_head));
              let v927_7: Space = routine_58(c, &(v927_6), &(*p1), &(v925_11_tail).make_space());
              map_map_kernels::compose(&(v926_5),&(v927_7))
            };
            drop(v926_5);
            let v926_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v926_2));
            drop(v926_2);
            let v926_10: Space = if map_kernels::has_head(&(v926_9)) { singleton(&[]) } else { Space::new() };
            drop(v926_9);
            let v926_12: Space = if (v926_10).is_empty() { Space::new() } else {
              let v928_6: Path = concat_path(&(v925_6),&(v925_11_head));
              let v928_11: Space = routine_19(c, &(v928_6), &(*p1), &(v925_11_tail).make_space());
              drop(v928_6);
              map_map_kernels::compose(&(v926_10),&(v928_11))
            };
            drop(v926_10);
            let v926_13: Space = map_map_kernels::unite(&(v926_8),&(v926_12));
            v925_11.join_into((v926_13).clone());
            }
            v925_11_cursor.ascend(1);
          }
          drop(v925_11_cursor);
          drop(v925_6);
          map_map_kernels::compose(&(v920_10),&(v925_11))
        };
        drop(v920_10);
        let v920_13: Space = map_map_kernels::unite(&(v920_8),&(v920_12));
        v919_7.join_into((v920_13).clone());
        }
        v919_7_cursor.ascend(1);
      }
      drop(v919_7_cursor);
      map_map_kernels::compose(&(v918_5),&(v919_7))
    };
    drop(v918_5);
    let v918_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v918_2));
    drop(v918_2);
    let v918_10: Space = if map_kernels::has_head(&(v918_9)) { singleton(&[]) } else { Space::new() };
    drop(v918_9);
    let v918_12: Space = if (v918_10).is_empty() { Space::new() } else {
      let v929_6: Path = concat_path(&(*p0),&(v917_21_head));
      let mut v929_11 = Space::new();
      let mut v929_11_cursor = (v917_21_tail).read_zipper();
      for v929_11_byte in v929_11_cursor.child_mask().iter() {
        v929_11_cursor.descend_to_byte(v929_11_byte);
        {
        let v929_11_tail = v929_11_cursor.fork_read_zipper();
        let v929_11_head = Path::from_slice(&[v929_11_byte]);
        let v930_2: Space = singleton(&(v929_11_head));
        let v930_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v930_2));
        let v930_4: Space = if map_kernels::has_head(&(v930_3)) { singleton(&[]) } else { Space::new() };
        drop(v930_3);
        let v930_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v930_4));
        drop(v930_4);
        let v930_8: Space = if (v930_5).is_empty() { Space::new() } else {
          let v931_6: Path = concat_path(&(v929_6),&(v929_11_head));
          let mut v931_7 = Space::new();
          let mut v931_7_cursor = (v929_11_tail).read_zipper();
          for v931_7_byte in v931_7_cursor.child_mask().iter() {
            v931_7_cursor.descend_to_byte(v931_7_byte);
            {
            let v931_7_tail = v931_7_cursor.fork_read_zipper();
            let v931_7_head = Path::from_slice(&[v931_7_byte]);
            let v932_2: Space = singleton(&(v931_7_head));
            let v932_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v932_2));
            let v932_4: Space = if map_kernels::has_head(&(v932_3)) { singleton(&[]) } else { Space::new() };
            drop(v932_3);
            let v932_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v932_4));
            drop(v932_4);
            let v932_8: Space = if (v932_5).is_empty() { Space::new() } else {
              let v933_6: Path = concat_path(&(v931_6),&(v931_7_head));
              let v933_7: Space = routine_58(c, &(v933_6), &(*p1), &(v931_7_tail).make_space());
              map_map_kernels::compose(&(v932_5),&(v933_7))
            };
            drop(v932_5);
            let v932_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v932_2));
            drop(v932_2);
            let v932_10: Space = if map_kernels::has_head(&(v932_9)) { singleton(&[]) } else { Space::new() };
            drop(v932_9);
            let v932_12: Space = if (v932_10).is_empty() { Space::new() } else {
              let v934_6: Path = concat_path(&(v931_6),&(v931_7_head));
              let v934_11: Space = routine_59(c, &(v934_6), &(*p1), &(v931_7_tail).make_space());
              drop(v934_6);
              map_map_kernels::compose(&(v932_10),&(v934_11))
            };
            drop(v932_10);
            let v932_13: Space = map_map_kernels::unite(&(v932_8),&(v932_12));
            v931_7.join_into((v932_13).clone());
            }
            v931_7_cursor.ascend(1);
          }
          drop(v931_7_cursor);
          map_map_kernels::compose(&(v930_5),&(v931_7))
        };
        drop(v930_5);
        let v930_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v930_2));
        drop(v930_2);
        let v930_10: Space = if map_kernels::has_head(&(v930_9)) { singleton(&[]) } else { Space::new() };
        drop(v930_9);
        let v930_11: Space = map_view_kernels::compose(&(v930_10),&(v929_11_tail));
        drop(v930_10);
        let v935_6: Path = concat_path(&(v929_6),&(v929_11_head));
        let v930_12: Space = map_kernels::wrap(&(v930_11),&(v935_6));
        drop(v930_11);
        let v930_13: Space = map_kernels::wrap(&(v930_12),&(*p1));
        drop(v930_12);
        let v930_14: Space = map_map_kernels::unite(&(v930_8),&(v930_13));
        drop(v930_13);
        v929_11.join_into((v930_14).clone());
        }
        v929_11_cursor.ascend(1);
      }
      drop(v929_11_cursor);
      drop(v929_6);
      map_map_kernels::compose(&(v918_10),&(v929_11))
    };
    drop(v918_10);
    let v918_13: Space = map_map_kernels::unite(&(v918_8),&(v918_12));
    v917_21.join_into((v918_13).clone());
    }
    v917_21_cursor.ascend(1);
  }
  drop(v917_21_cursor);
  (v917_21).clone()
}

fn routine_51(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v936_15 = Space::new();
  let mut v936_15_cursor = (*s0).read_zipper();
  for v936_15_byte in v936_15_cursor.child_mask().iter() {
    v936_15_cursor.descend_to_byte(v936_15_byte);
    {
    let v936_15_tail = v936_15_cursor.fork_read_zipper();
    let v936_15_head = Path::from_slice(&[v936_15_byte]);
    let v937_2: Space = singleton(&(v936_15_head));
    let v937_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v937_2));
    let v937_4: Space = if map_kernels::has_head(&(v937_3)) { singleton(&[]) } else { Space::new() };
    drop(v937_3);
    let v937_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v937_4));
    drop(v937_4);
    let v937_8: Space = if (v937_5).is_empty() { Space::new() } else {
      let v938_6: Path = concat_path(&(*p0),&(v936_15_head));
      let mut v938_7 = Space::new();
      let mut v938_7_cursor = (v936_15_tail).read_zipper();
      for v938_7_byte in v938_7_cursor.child_mask().iter() {
        v938_7_cursor.descend_to_byte(v938_7_byte);
        {
        let v938_7_tail = v938_7_cursor.fork_read_zipper();
        let v938_7_head = Path::from_slice(&[v938_7_byte]);
        let v939_2: Space = singleton(&(v938_7_head));
        let v939_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v939_2));
        let v939_4: Space = if map_kernels::has_head(&(v939_3)) { singleton(&[]) } else { Space::new() };
        drop(v939_3);
        let v939_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v939_4));
        drop(v939_4);
        let v939_8: Space = if (v939_5).is_empty() { Space::new() } else {
          let v940_6: Path = concat_path(&(v938_6),&(v938_7_head));
          let mut v940_7 = Space::new();
          let mut v940_7_cursor = (v938_7_tail).read_zipper();
          for v940_7_byte in v940_7_cursor.child_mask().iter() {
            v940_7_cursor.descend_to_byte(v940_7_byte);
            {
            let v940_7_tail = v940_7_cursor.fork_read_zipper();
            let v940_7_head = Path::from_slice(&[v940_7_byte]);
            let v941_2: Space = singleton(&(v940_7_head));
            let v941_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v941_2));
            let v941_4: Space = if map_kernels::has_head(&(v941_3)) { singleton(&[]) } else { Space::new() };
            drop(v941_3);
            let v941_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v941_4));
            drop(v941_4);
            let v941_8: Space = if (v941_5).is_empty() { Space::new() } else {
              let v942_6: Path = concat_path(&(v940_6),&(v940_7_head));
              let v942_7: Space = routine_58(c, &(v942_6), &(*p1), &(v940_7_tail).make_space());
              map_map_kernels::compose(&(v941_5),&(v942_7))
            };
            drop(v941_5);
            let v941_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v941_2));
            drop(v941_2);
            let v941_10: Space = if map_kernels::has_head(&(v941_9)) { singleton(&[]) } else { Space::new() };
            drop(v941_9);
            let v941_12: Space = if (v941_10).is_empty() { Space::new() } else {
              let v943_6: Path = concat_path(&(v940_6),&(v940_7_head));
              let v943_11: Space = routine_59(c, &(v943_6), &(*p1), &(v940_7_tail).make_space());
              drop(v943_6);
              map_map_kernels::compose(&(v941_10),&(v943_11))
            };
            drop(v941_10);
            let v941_13: Space = map_map_kernels::unite(&(v941_8),&(v941_12));
            v940_7.join_into((v941_13).clone());
            }
            v940_7_cursor.ascend(1);
          }
          drop(v940_7_cursor);
          map_map_kernels::compose(&(v939_5),&(v940_7))
        };
        drop(v939_5);
        let v939_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v939_2));
        drop(v939_2);
        let v939_10: Space = if map_kernels::has_head(&(v939_9)) { singleton(&[]) } else { Space::new() };
        drop(v939_9);
        let v939_12: Space = if (v939_10).is_empty() { Space::new() } else {
          let v944_6: Path = concat_path(&(v938_6),&(v938_7_head));
          let mut v944_11 = Space::new();
          let mut v944_11_cursor = (v938_7_tail).read_zipper();
          for v944_11_byte in v944_11_cursor.child_mask().iter() {
            v944_11_cursor.descend_to_byte(v944_11_byte);
            {
            let v944_11_tail = v944_11_cursor.fork_read_zipper();
            let v944_11_head = Path::from_slice(&[v944_11_byte]);
            let v945_2: Space = singleton(&(v944_11_head));
            let v945_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v945_2));
            let v945_4: Space = if map_kernels::has_head(&(v945_3)) { singleton(&[]) } else { Space::new() };
            drop(v945_3);
            let v945_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v945_4));
            drop(v945_4);
            let v945_8: Space = if (v945_5).is_empty() { Space::new() } else {
              let v946_6: Path = concat_path(&(v944_6),&(v944_11_head));
              let v946_7: Space = routine_58(c, &(v946_6), &(*p1), &(v944_11_tail).make_space());
              map_map_kernels::compose(&(v945_5),&(v946_7))
            };
            drop(v945_5);
            let v945_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v945_2));
            drop(v945_2);
            let v945_10: Space = if map_kernels::has_head(&(v945_9)) { singleton(&[]) } else { Space::new() };
            drop(v945_9);
            let v945_12: Space = if (v945_10).is_empty() { Space::new() } else {
              let v947_6: Path = concat_path(&(v944_6),&(v944_11_head));
              let v947_11: Space = routine_19(c, &(v947_6), &(*p1), &(v944_11_tail).make_space());
              drop(v947_6);
              map_map_kernels::compose(&(v945_10),&(v947_11))
            };
            drop(v945_10);
            let v945_13: Space = map_map_kernels::unite(&(v945_8),&(v945_12));
            v944_11.join_into((v945_13).clone());
            }
            v944_11_cursor.ascend(1);
          }
          drop(v944_11_cursor);
          drop(v944_6);
          map_map_kernels::compose(&(v939_10),&(v944_11))
        };
        drop(v939_10);
        let v939_13: Space = map_map_kernels::unite(&(v939_8),&(v939_12));
        v938_7.join_into((v939_13).clone());
        }
        v938_7_cursor.ascend(1);
      }
      drop(v938_7_cursor);
      map_map_kernels::compose(&(v937_5),&(v938_7))
    };
    drop(v937_5);
    let v937_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v937_2));
    drop(v937_2);
    let v937_10: Space = if map_kernels::has_head(&(v937_9)) { singleton(&[]) } else { Space::new() };
    drop(v937_9);
    let v937_11: Space = map_view_kernels::compose(&(v937_10),&(v936_15_tail));
    drop(v937_10);
    let v948_6: Path = concat_path(&(*p0),&(v936_15_head));
    let v937_12: Space = map_kernels::wrap(&(v937_11),&(v948_6));
    drop(v937_11);
    let v937_13: Space = map_kernels::wrap(&(v937_12),&(*p1));
    drop(v937_12);
    let v937_14: Space = map_map_kernels::unite(&(v937_8),&(v937_13));
    drop(v937_13);
    v936_15.join_into((v937_14).clone());
    }
    v936_15_cursor.ascend(1);
  }
  drop(v936_15_cursor);
  (v936_15).clone()
}

fn routine_52(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v949_4 = Space::new();
  let mut v949_4_cursor = (*s0).read_zipper();
  for v949_4_byte in v949_4_cursor.child_mask().iter() {
    v949_4_cursor.descend_to_byte(v949_4_byte);
    {
    let v949_4_tail = v949_4_cursor.fork_read_zipper();
    let v949_4_head = Path::from_slice(&[v949_4_byte]);
    let v950_2: Space = Space::new();
    v949_4.join_into((v950_2).clone());
    }
    v949_4_cursor.ascend(1);
  }
  drop(v949_4_cursor);
  (v949_4).clone()
}

fn routine_53(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v951_6: Space = map_kernels::unwrap(&(*s1),&(*CONSTANT_0));
  let v951_7: Space = map_kernels::unwrap(&(v951_6),&(*p0));
  drop(v951_6);
  let mut v951_17 = Space::new();
  let mut v951_17_cursor = (*s0).read_zipper();
  for v951_17_byte in v951_17_cursor.child_mask().iter() {
    v951_17_cursor.descend_to_byte(v951_17_byte);
    {
    let v951_17_tail = v951_17_cursor.fork_read_zipper();
    let v951_17_head = Path::from_slice(&[v951_17_byte]);
    let v952_2: Space = singleton(&(v951_17_head));
    let v952_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v952_2));
    drop(v952_2);
    let v952_4: Space = if map_kernels::has_head(&(v952_3)) { singleton(&[]) } else { Space::new() };
    drop(v952_3);
    let v952_7: Space = if (v952_4).is_empty() { Space::new() } else {
      let v953_5: Space = map_kernels::unwrap(&(v951_7),&(v951_17_head));
      let mut v953_6 = Space::new();
      let mut v953_6_cursor = (v953_5).read_zipper();
      for v953_6_byte in v953_6_cursor.child_mask().iter() {
        v953_6_cursor.descend_to_byte(v953_6_byte);
        {
        let v953_6_tail = v953_6_cursor.fork_read_zipper();
        let v953_6_head = Path::from_slice(&[v953_6_byte]);
        let v954_2: Space = singleton(&(v953_6_head));
        let v954_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v954_2));
        let v954_4: Space = if map_kernels::has_head(&(v954_3)) { singleton(&[]) } else { Space::new() };
        drop(v954_3);
        let v954_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v954_4));
        drop(v954_4);
        let v954_7: Space = if (v954_5).is_empty() { Space::new() } else {
          let mut v955_6 = Space::new();
          let mut v955_6_cursor = (v953_6_tail).read_zipper();
          for v955_6_byte in v955_6_cursor.child_mask().iter() {
            v955_6_cursor.descend_to_byte(v955_6_byte);
            {
            let v955_6_tail = v955_6_cursor.fork_read_zipper();
            let v955_6_head = Path::from_slice(&[v955_6_byte]);
            let v956_2: Space = singleton(&(v955_6_head));
            let v956_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v956_2));
            let v956_4: Space = if map_kernels::has_head(&(v956_3)) { singleton(&[]) } else { Space::new() };
            drop(v956_3);
            let v956_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v956_4));
            drop(v956_4);
            let v956_8: Space = if (v956_5).is_empty() { Space::new() } else {
              let v957_6: Path = concat_path(&(v953_6_head),&(v955_6_head));
              let v957_7: Space = routine_17(c, &(v957_6), &(*p1), &(v955_6_tail).make_space());
              map_map_kernels::compose(&(v956_5),&(v957_7))
            };
            drop(v956_5);
            let v956_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v956_2));
            drop(v956_2);
            let v956_10: Space = if map_kernels::has_head(&(v956_9)) { singleton(&[]) } else { Space::new() };
            drop(v956_9);
            let v956_12: Space = if (v956_10).is_empty() { Space::new() } else {
              let v958_6: Path = concat_path(&(v953_6_head),&(v955_6_head));
              let v958_11: Space = routine_18(c, &(v958_6), &(*p1), &(v955_6_tail).make_space());
              drop(v958_6);
              map_map_kernels::compose(&(v956_10),&(v958_11))
            };
            drop(v956_10);
            let v956_13: Space = map_map_kernels::unite(&(v956_8),&(v956_12));
            v955_6.join_into((v956_13).clone());
            }
            v955_6_cursor.ascend(1);
          }
          drop(v955_6_cursor);
          map_map_kernels::compose(&(v954_5),&(v955_6))
        };
        drop(v954_5);
        let v954_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v954_2));
        drop(v954_2);
        let v954_9: Space = if map_kernels::has_head(&(v954_8)) { singleton(&[]) } else { Space::new() };
        drop(v954_8);
        let v954_11: Space = if (v954_9).is_empty() { Space::new() } else {
          let mut v959_10 = Space::new();
          let mut v959_10_cursor = (v953_6_tail).read_zipper();
          for v959_10_byte in v959_10_cursor.child_mask().iter() {
            v959_10_cursor.descend_to_byte(v959_10_byte);
            {
            let v959_10_tail = v959_10_cursor.fork_read_zipper();
            let v959_10_head = Path::from_slice(&[v959_10_byte]);
            let v960_2: Space = singleton(&(v959_10_head));
            let v960_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v960_2));
            let v960_4: Space = if map_kernels::has_head(&(v960_3)) { singleton(&[]) } else { Space::new() };
            drop(v960_3);
            let v960_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v960_4));
            drop(v960_4);
            let v960_8: Space = if (v960_5).is_empty() { Space::new() } else {
              let v961_6: Path = concat_path(&(v953_6_head),&(v959_10_head));
              let v961_7: Space = routine_17(c, &(v961_6), &(*p1), &(v959_10_tail).make_space());
              map_map_kernels::compose(&(v960_5),&(v961_7))
            };
            drop(v960_5);
            let v960_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v960_2));
            drop(v960_2);
            let v960_10: Space = if map_kernels::has_head(&(v960_9)) { singleton(&[]) } else { Space::new() };
            drop(v960_9);
            let v960_12: Space = if (v960_10).is_empty() { Space::new() } else {
              let v962_6: Path = concat_path(&(v953_6_head),&(v959_10_head));
              let v962_11: Space = routine_19(c, &(v962_6), &(*p1), &(v959_10_tail).make_space());
              drop(v962_6);
              map_map_kernels::compose(&(v960_10),&(v962_11))
            };
            drop(v960_10);
            let v960_13: Space = map_map_kernels::unite(&(v960_8),&(v960_12));
            v959_10.join_into((v960_13).clone());
            }
            v959_10_cursor.ascend(1);
          }
          drop(v959_10_cursor);
          map_map_kernels::compose(&(v954_9),&(v959_10))
        };
        drop(v954_9);
        let v954_12: Space = map_map_kernels::unite(&(v954_7),&(v954_11));
        v953_6.join_into((v954_12).clone());
        }
        v953_6_cursor.ascend(1);
      }
      drop(v953_6_cursor);
      drop(v953_5);
      map_map_kernels::compose(&(v952_4),&(v953_6))
    };
    drop(v952_4);
    v951_17.join_into((v952_7).clone());
    }
    v951_17_cursor.ascend(1);
  }
  drop(v951_17_cursor);
  drop(v951_7);
  (v951_17).clone()
}

fn routine_54(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v963_13 = Space::new();
  let mut v963_13_cursor = (*s0).read_zipper();
  for v963_13_byte in v963_13_cursor.child_mask().iter() {
    v963_13_cursor.descend_to_byte(v963_13_byte);
    {
    let v963_13_tail = v963_13_cursor.fork_read_zipper();
    let v963_13_head = Path::from_slice(&[v963_13_byte]);
    let v964_2: Space = singleton(&(v963_13_head));
    let v964_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v964_2));
    let v964_4: Space = if map_kernels::has_head(&(v964_3)) { singleton(&[]) } else { Space::new() };
    drop(v964_3);
    let v964_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v964_4));
    drop(v964_4);
    let v964_8: Space = if (v964_5).is_empty() { Space::new() } else {
      let v965_6: Path = concat_path(&(*p0),&(v963_13_head));
      let mut v965_7 = Space::new();
      let mut v965_7_cursor = (v963_13_tail).read_zipper();
      for v965_7_byte in v965_7_cursor.child_mask().iter() {
        v965_7_cursor.descend_to_byte(v965_7_byte);
        {
        let v965_7_tail = v965_7_cursor.fork_read_zipper();
        let v965_7_head = Path::from_slice(&[v965_7_byte]);
        let v966_2: Space = singleton(&(v965_7_head));
        let v966_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v966_2));
        let v966_4: Space = if map_kernels::has_head(&(v966_3)) { singleton(&[]) } else { Space::new() };
        drop(v966_3);
        let v966_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v966_4));
        drop(v966_4);
        let mut v966_6 = Space::new();
        let mut v966_6_cursor = (v965_7_tail).read_zipper();
        for v966_6_byte in v966_6_cursor.child_mask().iter() {
          v966_6_cursor.descend_to_byte(v966_6_byte);
          {
          let v966_6_tail = v966_6_cursor.fork_read_zipper();
          let v966_6_head = Path::from_slice(&[v966_6_byte]);
          let v967_2: Space = Space::new();
          v966_6.join_into((v967_2).clone());
          }
          v966_6_cursor.ascend(1);
        }
        drop(v966_6_cursor);
        let v966_7: Space = map_map_kernels::compose(&(v966_5),&(v966_6));
        drop(v966_5);
        drop(v966_6);
        let v966_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v966_2));
        drop(v966_2);
        let v966_9: Space = if map_kernels::has_head(&(v966_8)) { singleton(&[]) } else { Space::new() };
        drop(v966_8);
        let v966_12: Space = if (v966_9).is_empty() { Space::new() } else {
          let v968_10: Path = concat_path(&(v965_6),&(v965_7_head));
          let mut v968_11 = Space::new();
          let mut v968_11_cursor = (v965_7_tail).read_zipper();
          for v968_11_byte in v968_11_cursor.child_mask().iter() {
            v968_11_cursor.descend_to_byte(v968_11_byte);
            {
            let v968_11_tail = v968_11_cursor.fork_read_zipper();
            let v968_11_head = Path::from_slice(&[v968_11_byte]);
            let v969_2: Space = singleton(&(v968_11_head));
            let v969_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v969_2));
            drop(v969_2);
            let v969_4: Space = if map_kernels::has_head(&(v969_3)) { singleton(&[]) } else { Space::new() };
            drop(v969_3);
            let v969_7: Space = if (v969_4).is_empty() { Space::new() } else {
              let v970_5: Path = concat_path(&(v968_10),&(v968_11_head));
              let v970_6: Space = routine_19(c, &(v970_5), &(*p1), &(v968_11_tail).make_space());
              drop(v970_5);
              map_map_kernels::compose(&(v969_4),&(v970_6))
            };
            drop(v969_4);
            v968_11.join_into((v969_7).clone());
            }
            v968_11_cursor.ascend(1);
          }
          drop(v968_11_cursor);
          drop(v968_10);
          map_map_kernels::compose(&(v966_9),&(v968_11))
        };
        drop(v966_9);
        let v966_13: Space = map_map_kernels::unite(&(v966_7),&(v966_12));
        drop(v966_7);
        v965_7.join_into((v966_13).clone());
        }
        v965_7_cursor.ascend(1);
      }
      drop(v965_7_cursor);
      map_map_kernels::compose(&(v964_5),&(v965_7))
    };
    drop(v964_5);
    let v964_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v964_2));
    drop(v964_2);
    let v964_10: Space = if map_kernels::has_head(&(v964_9)) { singleton(&[]) } else { Space::new() };
    drop(v964_9);
    let v964_12: Space = if (v964_10).is_empty() { Space::new() } else {
      let v971_6: Path = concat_path(&(*p0),&(v963_13_head));
      let mut v971_11 = Space::new();
      let mut v971_11_cursor = (v963_13_tail).read_zipper();
      for v971_11_byte in v971_11_cursor.child_mask().iter() {
        v971_11_cursor.descend_to_byte(v971_11_byte);
        {
        let v971_11_tail = v971_11_cursor.fork_read_zipper();
        let v971_11_head = Path::from_slice(&[v971_11_byte]);
        let v972_2: Space = singleton(&(v971_11_head));
        let v972_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v972_2));
        let v972_4: Space = if map_kernels::has_head(&(v972_3)) { singleton(&[]) } else { Space::new() };
        drop(v972_3);
        let v972_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v972_4));
        drop(v972_4);
        let mut v972_6 = Space::new();
        let mut v972_6_cursor = (v971_11_tail).read_zipper();
        for v972_6_byte in v972_6_cursor.child_mask().iter() {
          v972_6_cursor.descend_to_byte(v972_6_byte);
          {
          let v972_6_tail = v972_6_cursor.fork_read_zipper();
          let v972_6_head = Path::from_slice(&[v972_6_byte]);
          let v973_2: Space = Space::new();
          v972_6.join_into((v973_2).clone());
          }
          v972_6_cursor.ascend(1);
        }
        drop(v972_6_cursor);
        let v972_7: Space = map_map_kernels::compose(&(v972_5),&(v972_6));
        drop(v972_5);
        drop(v972_6);
        let v972_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v972_2));
        drop(v972_2);
        let v972_9: Space = if map_kernels::has_head(&(v972_8)) { singleton(&[]) } else { Space::new() };
        drop(v972_8);
        let v972_10: Space = map_view_kernels::compose(&(v972_9),&(v971_11_tail));
        drop(v972_9);
        let v972_11: Path = concat_path(&(v971_6),&(v971_11_head));
        let v972_12: Space = map_kernels::wrap(&(v972_10),&(v972_11));
        drop(v972_10);
        drop(v972_11);
        let v972_13: Space = map_kernels::wrap(&(v972_12),&(*p1));
        drop(v972_12);
        let v972_14: Space = map_map_kernels::unite(&(v972_7),&(v972_13));
        drop(v972_7);
        drop(v972_13);
        v971_11.join_into((v972_14).clone());
        }
        v971_11_cursor.ascend(1);
      }
      drop(v971_11_cursor);
      drop(v971_6);
      map_map_kernels::compose(&(v964_10),&(v971_11))
    };
    drop(v964_10);
    let v964_13: Space = map_map_kernels::unite(&(v964_8),&(v964_12));
    drop(v964_12);
    v963_13.join_into((v964_13).clone());
    }
    v963_13_cursor.ascend(1);
  }
  drop(v963_13_cursor);
  (v963_13).clone()
}

fn routine_55(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v974_10 = Space::new();
  let mut v974_10_cursor = (*s0).read_zipper();
  for v974_10_byte in v974_10_cursor.child_mask().iter() {
    v974_10_cursor.descend_to_byte(v974_10_byte);
    {
    let v974_10_tail = v974_10_cursor.fork_read_zipper();
    let v974_10_head = Path::from_slice(&[v974_10_byte]);
    let v975_2: Space = singleton(&(v974_10_head));
    let v975_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v975_2));
    let v975_4: Space = if map_kernels::has_head(&(v975_3)) { singleton(&[]) } else { Space::new() };
    drop(v975_3);
    let v975_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v975_4));
    drop(v975_4);
    let v975_8: Space = if (v975_5).is_empty() { Space::new() } else {
      let v976_6: Path = concat_path(&(*p0),&(v974_10_head));
      let mut v976_7 = Space::new();
      let mut v976_7_cursor = (v974_10_tail).read_zipper();
      for v976_7_byte in v976_7_cursor.child_mask().iter() {
        v976_7_cursor.descend_to_byte(v976_7_byte);
        {
        let v976_7_tail = v976_7_cursor.fork_read_zipper();
        let v976_7_head = Path::from_slice(&[v976_7_byte]);
        let v977_2: Space = singleton(&(v976_7_head));
        let v977_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v977_2));
        let v977_4: Space = if map_kernels::has_head(&(v977_3)) { singleton(&[]) } else { Space::new() };
        drop(v977_3);
        let v977_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v977_4));
        drop(v977_4);
        let mut v977_6 = Space::new();
        let mut v977_6_cursor = (v976_7_tail).read_zipper();
        for v977_6_byte in v977_6_cursor.child_mask().iter() {
          v977_6_cursor.descend_to_byte(v977_6_byte);
          {
          let v977_6_tail = v977_6_cursor.fork_read_zipper();
          let v977_6_head = Path::from_slice(&[v977_6_byte]);
          let v978_2: Space = Space::new();
          v977_6.join_into((v978_2).clone());
          }
          v977_6_cursor.ascend(1);
        }
        drop(v977_6_cursor);
        let v977_7: Space = map_map_kernels::compose(&(v977_5),&(v977_6));
        drop(v977_5);
        drop(v977_6);
        let v977_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v977_2));
        drop(v977_2);
        let v977_9: Space = if map_kernels::has_head(&(v977_8)) { singleton(&[]) } else { Space::new() };
        drop(v977_8);
        let v977_12: Space = if (v977_9).is_empty() { Space::new() } else {
          let v979_10: Path = concat_path(&(v976_6),&(v976_7_head));
          let mut v979_11 = Space::new();
          let mut v979_11_cursor = (v976_7_tail).read_zipper();
          for v979_11_byte in v979_11_cursor.child_mask().iter() {
            v979_11_cursor.descend_to_byte(v979_11_byte);
            {
            let v979_11_tail = v979_11_cursor.fork_read_zipper();
            let v979_11_head = Path::from_slice(&[v979_11_byte]);
            let v980_2: Space = singleton(&(v979_11_head));
            let v980_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v980_2));
            drop(v980_2);
            let v980_4: Space = if map_kernels::has_head(&(v980_3)) { singleton(&[]) } else { Space::new() };
            drop(v980_3);
            let v980_7: Space = if (v980_4).is_empty() { Space::new() } else {
              let v981_5: Path = concat_path(&(v979_10),&(v979_11_head));
              let v981_6: Space = routine_19(c, &(v981_5), &(*p1), &(v979_11_tail).make_space());
              drop(v981_5);
              map_map_kernels::compose(&(v980_4),&(v981_6))
            };
            drop(v980_4);
            v979_11.join_into((v980_7).clone());
            }
            v979_11_cursor.ascend(1);
          }
          drop(v979_11_cursor);
          drop(v979_10);
          map_map_kernels::compose(&(v977_9),&(v979_11))
        };
        drop(v977_9);
        let v977_13: Space = map_map_kernels::unite(&(v977_7),&(v977_12));
        drop(v977_7);
        v976_7.join_into((v977_13).clone());
        }
        v976_7_cursor.ascend(1);
      }
      drop(v976_7_cursor);
      map_map_kernels::compose(&(v975_5),&(v976_7))
    };
    drop(v975_5);
    let v975_9: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v975_2));
    drop(v975_2);
    let v975_10: Space = if map_kernels::has_head(&(v975_9)) { singleton(&[]) } else { Space::new() };
    drop(v975_9);
    let v975_11: Space = map_view_kernels::compose(&(v975_10),&(v974_10_tail));
    drop(v975_10);
    let v982_6: Path = concat_path(&(*p0),&(v974_10_head));
    let v975_12: Space = map_kernels::wrap(&(v975_11),&(v982_6));
    drop(v975_11);
    let v975_13: Space = map_kernels::wrap(&(v975_12),&(*p1));
    drop(v975_12);
    let v975_14: Space = map_map_kernels::unite(&(v975_8),&(v975_13));
    drop(v975_13);
    v974_10.join_into((v975_14).clone());
    }
    v974_10_cursor.ascend(1);
  }
  drop(v974_10_cursor);
  (v974_10).clone()
}

fn routine_56(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v983_7 = Space::new();
  let mut v983_7_cursor = (*s0).read_zipper();
  for v983_7_byte in v983_7_cursor.child_mask().iter() {
    v983_7_cursor.descend_to_byte(v983_7_byte);
    {
    let v983_7_tail = v983_7_cursor.fork_read_zipper();
    let v983_7_head = Path::from_slice(&[v983_7_byte]);
    let v984_2: Space = singleton(&(v983_7_head));
    let v984_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v984_2));
    let v984_4: Space = if map_kernels::has_head(&(v984_3)) { singleton(&[]) } else { Space::new() };
    drop(v984_3);
    let v984_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v984_4));
    drop(v984_4);
    let mut v984_6 = Space::new();
    let mut v984_6_cursor = (v983_7_tail).read_zipper();
    for v984_6_byte in v984_6_cursor.child_mask().iter() {
      v984_6_cursor.descend_to_byte(v984_6_byte);
      {
      let v984_6_tail = v984_6_cursor.fork_read_zipper();
      let v984_6_head = Path::from_slice(&[v984_6_byte]);
      let v985_2: Space = Space::new();
      v984_6.join_into((v985_2).clone());
      }
      v984_6_cursor.ascend(1);
    }
    drop(v984_6_cursor);
    let v984_7: Space = map_map_kernels::compose(&(v984_5),&(v984_6));
    drop(v984_5);
    drop(v984_6);
    let v984_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v984_2));
    drop(v984_2);
    let v984_9: Space = if map_kernels::has_head(&(v984_8)) { singleton(&[]) } else { Space::new() };
    drop(v984_8);
    let v984_12: Space = if (v984_9).is_empty() { Space::new() } else {
      let v986_10: Path = concat_path(&(*p0),&(v983_7_head));
      let mut v986_11 = Space::new();
      let mut v986_11_cursor = (v983_7_tail).read_zipper();
      for v986_11_byte in v986_11_cursor.child_mask().iter() {
        v986_11_cursor.descend_to_byte(v986_11_byte);
        {
        let v986_11_tail = v986_11_cursor.fork_read_zipper();
        let v986_11_head = Path::from_slice(&[v986_11_byte]);
        let v987_2: Space = singleton(&(v986_11_head));
        let v987_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v987_2));
        drop(v987_2);
        let v987_4: Space = if map_kernels::has_head(&(v987_3)) { singleton(&[]) } else { Space::new() };
        drop(v987_3);
        let v987_5: Space = map_view_kernels::compose(&(v987_4),&(v986_11_tail));
        drop(v987_4);
        let v987_6: Path = concat_path(&(v986_10),&(v986_11_head));
        let v987_7: Space = map_kernels::wrap(&(v987_5),&(v987_6));
        drop(v987_5);
        drop(v987_6);
        v986_11.join_into((v987_7).clone());
        }
        v986_11_cursor.ascend(1);
      }
      drop(v986_11_cursor);
      drop(v986_10);
      map_map_kernels::compose(&(v984_9),&(v986_11))
    };
    drop(v984_9);
    let v984_13: Space = map_kernels::wrap(&(v984_12),&(*p1));
    drop(v984_12);
    let v984_14: Space = map_map_kernels::unite(&(v984_7),&(v984_13));
    drop(v984_7);
    drop(v984_13);
    v983_7.join_into((v984_14).clone());
    }
    v983_7_cursor.ascend(1);
  }
  drop(v983_7_cursor);
  (v983_7).clone()
}

fn routine_57(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v988_6 = Space::new();
  let mut v988_6_cursor = (*s0).read_zipper();
  for v988_6_byte in v988_6_cursor.child_mask().iter() {
    v988_6_cursor.descend_to_byte(v988_6_byte);
    {
    let v988_6_tail = v988_6_cursor.fork_read_zipper();
    let v988_6_head = Path::from_slice(&[v988_6_byte]);
    let v989_2: Space = singleton(&(v988_6_head));
    let v989_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v989_2));
    let v989_4: Space = if map_kernels::has_head(&(v989_3)) { singleton(&[]) } else { Space::new() };
    drop(v989_3);
    let v989_5: Space = map_map_kernels::subtract(&(*CONSTANT_1),&(v989_4));
    drop(v989_4);
    let mut v989_6 = Space::new();
    let mut v989_6_cursor = (v988_6_tail).read_zipper();
    for v989_6_byte in v989_6_cursor.child_mask().iter() {
      v989_6_cursor.descend_to_byte(v989_6_byte);
      {
      let v989_6_tail = v989_6_cursor.fork_read_zipper();
      let v989_6_head = Path::from_slice(&[v989_6_byte]);
      let v990_2: Space = Space::new();
      v989_6.join_into((v990_2).clone());
      }
      v989_6_cursor.ascend(1);
    }
    drop(v989_6_cursor);
    let v989_7: Space = map_map_kernels::compose(&(v989_5),&(v989_6));
    drop(v989_5);
    drop(v989_6);
    let v989_8: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v989_2));
    drop(v989_2);
    let v989_9: Space = if map_kernels::has_head(&(v989_8)) { singleton(&[]) } else { Space::new() };
    drop(v989_8);
    let v989_10: Space = map_view_kernels::compose(&(v989_9),&(v988_6_tail));
    drop(v989_9);
    let v989_11: Path = concat_path(&(*p0),&(v988_6_head));
    let v989_12: Space = map_kernels::wrap(&(v989_10),&(v989_11));
    drop(v989_10);
    drop(v989_11);
    let v989_13: Space = map_kernels::wrap(&(v989_12),&(*p1));
    drop(v989_12);
    let v989_14: Space = map_map_kernels::unite(&(v989_7),&(v989_13));
    drop(v989_7);
    drop(v989_13);
    v988_6.join_into((v989_14).clone());
    }
    v988_6_cursor.ascend(1);
  }
  drop(v988_6_cursor);
  (v988_6).clone()
}

fn routine_58(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v991_3 = Space::new();
  let mut v991_3_cursor = (*s0).read_zipper();
  for v991_3_byte in v991_3_cursor.child_mask().iter() {
    v991_3_cursor.descend_to_byte(v991_3_byte);
    {
    let v991_3_tail = v991_3_cursor.fork_read_zipper();
    let v991_3_head = Path::from_slice(&[v991_3_byte]);
    let v992_2: Space = Space::new();
    v991_3.join_into((v992_2).clone());
    }
    v991_3_cursor.ascend(1);
  }
  drop(v991_3_cursor);
  (v991_3).clone()
}

fn routine_59(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v993_4 = Space::new();
  let mut v993_4_cursor = (*s0).read_zipper();
  for v993_4_byte in v993_4_cursor.child_mask().iter() {
    v993_4_cursor.descend_to_byte(v993_4_byte);
    {
    let v993_4_tail = v993_4_cursor.fork_read_zipper();
    let v993_4_head = Path::from_slice(&[v993_4_byte]);
    let v994_2: Space = singleton(&(v993_4_head));
    let v994_3: Space = map_map_kernels::intersect(&(*CONSTANT_2),&(v994_2));
    drop(v994_2);
    let v994_4: Space = if map_kernels::has_head(&(v994_3)) { singleton(&[]) } else { Space::new() };
    drop(v994_3);
    let v994_5: Space = map_view_kernels::compose(&(v994_4),&(v993_4_tail));
    drop(v994_4);
    let v994_6: Path = concat_path(&(*p0),&(v993_4_head));
    let v994_7: Space = map_kernels::wrap(&(v994_5),&(v994_6));
    drop(v994_5);
    drop(v994_6);
    v993_4.join_into((v994_7).clone());
    }
    v993_4_cursor.ascend(1);
  }
  drop(v993_4_cursor);
  let v993_5: Space = map_kernels::wrap(&(v993_4),&(*p1));
  drop(v993_4);
  (v993_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
