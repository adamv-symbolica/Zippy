#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[1,1]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 1"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,1,0,0,0,1,0,0,1,1]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_24 = Space::new();
  let mut v0_24_cursor = (v0_2).read_zipper();
  for v0_24_byte in v0_24_cursor.child_mask().iter() {
    v0_24_cursor.descend_to_byte(v0_24_byte);
    {
    let v0_24_tail = v0_24_cursor.fork_read_zipper();
    let v0_24_head = Path::from_slice(&[v0_24_byte]);
    let v1_2: Space = singleton(&(v0_24_head));
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_24_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_24_head),&(v2_6_head));
          let mut v4_7 = Space::new();
          let mut v4_7_cursor = (v2_6_tail).read_zipper();
          for v4_7_byte in v4_7_cursor.child_mask().iter() {
            v4_7_cursor.descend_to_byte(v4_7_byte);
            {
            let v4_7_tail = v4_7_cursor.fork_read_zipper();
            let v4_7_head = Path::from_slice(&[v4_7_byte]);
            let v5_2: Space = singleton(&(v4_7_head));
            let v5_3: Space = intersect(&(*CONSTANT_2),&(v5_2));
            let v5_4: Space = if has_head(&(v5_3)) { singleton(&[]) } else { Space::new() };
            drop(v5_3);
            let v5_5: Space = subtract(&(*CONSTANT_1),&(v5_4));
            drop(v5_4);
            let v5_8: Space = if (v5_5).is_empty() { Space::new() } else {
              let v6_6: Path = concat_path(&(v4_6),&(v4_7_head));
              let v6_7: Space = routine_1(c, &(v6_6), &(v4_7_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v5_5),&(v6_7))
            };
            drop(v5_5);
            let v5_9: Space = intersect(&(*CONSTANT_2),&(v5_2));
            drop(v5_2);
            let v5_10: Space = if has_head(&(v5_9)) { singleton(&[]) } else { Space::new() };
            drop(v5_9);
            let v5_12: Space = if (v5_10).is_empty() { Space::new() } else {
              let v7_6: Path = concat_path(&(v4_6),&(v4_7_head));
              let v7_11: Space = routine_2(c, &(v7_6), &(v4_7_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v7_6);
              compose(&(v5_10),&(v7_11))
            };
            drop(v5_10);
            let v5_13: Space = unite(&(v5_8),&(v5_12));
            v4_7.join_into((v5_13).clone());
            }
            v4_7_cursor.ascend(1);
          }
          drop(v4_7_cursor);
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v8_6: Path = concat_path(&(v0_24_head),&(v2_6_head));
          let mut v8_11 = Space::new();
          let mut v8_11_cursor = (v2_6_tail).read_zipper();
          for v8_11_byte in v8_11_cursor.child_mask().iter() {
            v8_11_cursor.descend_to_byte(v8_11_byte);
            {
            let v8_11_tail = v8_11_cursor.fork_read_zipper();
            let v8_11_head = Path::from_slice(&[v8_11_byte]);
            let v9_2: Space = singleton(&(v8_11_head));
            let v9_3: Space = intersect(&(*CONSTANT_2),&(v9_2));
            let v9_4: Space = if has_head(&(v9_3)) { singleton(&[]) } else { Space::new() };
            drop(v9_3);
            let v9_5: Space = subtract(&(*CONSTANT_1),&(v9_4));
            drop(v9_4);
            let v9_8: Space = if (v9_5).is_empty() { Space::new() } else {
              let v10_6: Path = concat_path(&(v8_6),&(v8_11_head));
              let v10_7: Space = routine_1(c, &(v10_6), &(v8_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v9_5),&(v10_7))
            };
            drop(v9_5);
            let v9_9: Space = intersect(&(*CONSTANT_2),&(v9_2));
            drop(v9_2);
            let v9_10: Space = if has_head(&(v9_9)) { singleton(&[]) } else { Space::new() };
            drop(v9_9);
            let v9_12: Space = if (v9_10).is_empty() { Space::new() } else {
              let v11_6: Path = concat_path(&(v8_6),&(v8_11_head));
              let v11_11: Space = routine_3(c, &(v11_6), &(v8_11_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v11_6);
              compose(&(v9_10),&(v11_11))
            };
            drop(v9_10);
            let v9_13: Space = unite(&(v9_8),&(v9_12));
            v8_11.join_into((v9_13).clone());
            }
            v8_11_cursor.ascend(1);
          }
          drop(v8_11_cursor);
          drop(v8_6);
          compose(&(v3_10),&(v8_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v12_10 = Space::new();
      let mut v12_10_cursor = (v0_24_tail).read_zipper();
      for v12_10_byte in v12_10_cursor.child_mask().iter() {
        v12_10_cursor.descend_to_byte(v12_10_byte);
        {
        let v12_10_tail = v12_10_cursor.fork_read_zipper();
        let v12_10_head = Path::from_slice(&[v12_10_byte]);
        let v13_2: Space = singleton(&(v12_10_head));
        let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
        let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
        drop(v13_3);
        let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
        drop(v13_4);
        let v13_8: Space = if (v13_5).is_empty() { Space::new() } else {
          let v14_6: Path = concat_path(&(v0_24_head),&(v12_10_head));
          let mut v14_7 = Space::new();
          let mut v14_7_cursor = (v12_10_tail).read_zipper();
          for v14_7_byte in v14_7_cursor.child_mask().iter() {
            v14_7_cursor.descend_to_byte(v14_7_byte);
            {
            let v14_7_tail = v14_7_cursor.fork_read_zipper();
            let v14_7_head = Path::from_slice(&[v14_7_byte]);
            let v15_2: Space = singleton(&(v14_7_head));
            let v15_3: Space = intersect(&(*CONSTANT_2),&(v15_2));
            let v15_4: Space = if has_head(&(v15_3)) { singleton(&[]) } else { Space::new() };
            drop(v15_3);
            let v15_5: Space = subtract(&(*CONSTANT_1),&(v15_4));
            drop(v15_4);
            let v15_8: Space = if (v15_5).is_empty() { Space::new() } else {
              let v16_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v16_7: Space = routine_1(c, &(v16_6), &(v14_7_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v15_5),&(v16_7))
            };
            drop(v15_5);
            let v15_9: Space = intersect(&(*CONSTANT_2),&(v15_2));
            drop(v15_2);
            let v15_10: Space = if has_head(&(v15_9)) { singleton(&[]) } else { Space::new() };
            drop(v15_9);
            let v15_12: Space = if (v15_10).is_empty() { Space::new() } else {
              let v17_6: Path = concat_path(&(v14_6),&(v14_7_head));
              let v17_11: Space = routine_2(c, &(v17_6), &(v14_7_tail).make_space(), &(*s0.expect("unbound native input")));
              drop(v17_6);
              compose(&(v15_10),&(v17_11))
            };
            drop(v15_10);
            let v15_13: Space = unite(&(v15_8),&(v15_12));
            v14_7.join_into((v15_13).clone());
            }
            v14_7_cursor.ascend(1);
          }
          drop(v14_7_cursor);
          compose(&(v13_5),&(v14_7))
        };
        drop(v13_5);
        let v13_9: Space = intersect(&(*CONSTANT_2),&(v13_2));
        drop(v13_2);
        let v13_10: Space = if has_head(&(v13_9)) { singleton(&[]) } else { Space::new() };
        drop(v13_9);
        let v13_12: Space = if (v13_10).is_empty() { Space::new() } else {
          let v18_6: Path = concat_path(&(v0_24_head),&(v12_10_head));
          let mut v18_11 = Space::new();
          let mut v18_11_cursor = (v12_10_tail).read_zipper();
          for v18_11_byte in v18_11_cursor.child_mask().iter() {
            v18_11_cursor.descend_to_byte(v18_11_byte);
            {
            let v18_11_tail = v18_11_cursor.fork_read_zipper();
            let v18_11_head = Path::from_slice(&[v18_11_byte]);
            let v19_2: Space = singleton(&(v18_11_head));
            let v19_3: Space = intersect(&(*CONSTANT_2),&(v19_2));
            let v19_4: Space = if has_head(&(v19_3)) { singleton(&[]) } else { Space::new() };
            drop(v19_3);
            let v19_5: Space = subtract(&(*CONSTANT_1),&(v19_4));
            drop(v19_4);
            let v19_7: Space = if (v19_5).is_empty() { Space::new() } else {
              let v20_6: Space = routine_4(c, &(v18_11_head), &(v18_6), &(v18_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v19_5),&(v20_6))
            };
            drop(v19_5);
            let v19_8: Space = intersect(&(*CONSTANT_2),&(v19_2));
            drop(v19_2);
            let v19_9: Space = if has_head(&(v19_8)) { singleton(&[]) } else { Space::new() };
            drop(v19_8);
            let v19_11: Space = if (v19_9).is_empty() { Space::new() } else {
              let v21_10: Space = routine_5(c, &(v18_11_head), &(v18_6), &(v18_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v19_9),&(v21_10))
            };
            drop(v19_9);
            let v19_12: Space = unite(&(v19_7),&(v19_11));
            v18_11.join_into((v19_12).clone());
            }
            v18_11_cursor.ascend(1);
          }
          drop(v18_11_cursor);
          drop(v18_6);
          compose(&(v13_10),&(v18_11))
        };
        drop(v13_10);
        let v13_13: Space = unite(&(v13_8),&(v13_12));
        v12_10.join_into((v13_13).clone());
        }
        v12_10_cursor.ascend(1);
      }
      drop(v12_10_cursor);
      compose(&(v1_9),&(v12_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_24.join_into((v1_12).clone());
    }
    v0_24_cursor.ascend(1);
  }
  drop(v0_24_cursor);
  drop(v0_2);
  let v0_26: Space = wrap(&(v0_24),&(*CONSTANT_3));
  (v0_26).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v22_24 = Space::new();
  let mut v22_24_cursor = (*s0).read_zipper();
  for v22_24_byte in v22_24_cursor.child_mask().iter() {
    v22_24_cursor.descend_to_byte(v22_24_byte);
    {
    let v22_24_tail = v22_24_cursor.fork_read_zipper();
    let v22_24_head = Path::from_slice(&[v22_24_byte]);
    let v23_2: Space = singleton(&(v22_24_head));
    let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
    let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
    drop(v23_3);
    let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
    drop(v23_4);
    let v23_8: Space = if (v23_5).is_empty() { Space::new() } else {
      let v24_6: Path = concat_path(&(*p0),&(v22_24_head));
      let mut v24_7 = Space::new();
      let mut v24_7_cursor = (v22_24_tail).read_zipper();
      for v24_7_byte in v24_7_cursor.child_mask().iter() {
        v24_7_cursor.descend_to_byte(v24_7_byte);
        {
        let v24_7_tail = v24_7_cursor.fork_read_zipper();
        let v24_7_head = Path::from_slice(&[v24_7_byte]);
        let v25_2: Space = singleton(&(v24_7_head));
        let v25_3: Space = intersect(&(*CONSTANT_2),&(v25_2));
        let v25_4: Space = if has_head(&(v25_3)) { singleton(&[]) } else { Space::new() };
        drop(v25_3);
        let v25_5: Space = subtract(&(*CONSTANT_1),&(v25_4));
        drop(v25_4);
        let v25_8: Space = if (v25_5).is_empty() { Space::new() } else {
          let v26_6: Path = concat_path(&(v24_6),&(v24_7_head));
          let mut v26_7 = Space::new();
          let mut v26_7_cursor = (v24_7_tail).read_zipper();
          for v26_7_byte in v26_7_cursor.child_mask().iter() {
            v26_7_cursor.descend_to_byte(v26_7_byte);
            {
            let v26_7_tail = v26_7_cursor.fork_read_zipper();
            let v26_7_head = Path::from_slice(&[v26_7_byte]);
            let v27_2: Space = singleton(&(v26_7_head));
            let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
            let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
            drop(v27_3);
            let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
            drop(v27_4);
            let v27_8: Space = if (v27_5).is_empty() { Space::new() } else {
              let v28_6: Path = concat_path(&(v26_6),&(v26_7_head));
              let v28_7: Space = routine_6(c, &(v28_6), &(v26_7_tail).make_space(), &(*s1));
              compose(&(v27_5),&(v28_7))
            };
            drop(v27_5);
            let v27_9: Space = intersect(&(*CONSTANT_2),&(v27_2));
            drop(v27_2);
            let v27_10: Space = if has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
            drop(v27_9);
            let v27_12: Space = if (v27_10).is_empty() { Space::new() } else {
              let v29_6: Path = concat_path(&(v26_6),&(v26_7_head));
              let v29_11: Space = routine_7(c, &(v29_6), &(v26_7_tail).make_space(), &(*s1));
              drop(v29_6);
              compose(&(v27_10),&(v29_11))
            };
            drop(v27_10);
            let v27_13: Space = unite(&(v27_8),&(v27_12));
            v26_7.join_into((v27_13).clone());
            }
            v26_7_cursor.ascend(1);
          }
          drop(v26_7_cursor);
          compose(&(v25_5),&(v26_7))
        };
        drop(v25_5);
        let v25_9: Space = intersect(&(*CONSTANT_2),&(v25_2));
        drop(v25_2);
        let v25_10: Space = if has_head(&(v25_9)) { singleton(&[]) } else { Space::new() };
        drop(v25_9);
        let v25_12: Space = if (v25_10).is_empty() { Space::new() } else {
          let v30_6: Path = concat_path(&(v24_6),&(v24_7_head));
          let mut v30_11 = Space::new();
          let mut v30_11_cursor = (v24_7_tail).read_zipper();
          for v30_11_byte in v30_11_cursor.child_mask().iter() {
            v30_11_cursor.descend_to_byte(v30_11_byte);
            {
            let v30_11_tail = v30_11_cursor.fork_read_zipper();
            let v30_11_head = Path::from_slice(&[v30_11_byte]);
            let v31_2: Space = singleton(&(v30_11_head));
            let v31_3: Space = intersect(&(*CONSTANT_2),&(v31_2));
            let v31_4: Space = if has_head(&(v31_3)) { singleton(&[]) } else { Space::new() };
            drop(v31_3);
            let v31_5: Space = subtract(&(*CONSTANT_1),&(v31_4));
            drop(v31_4);
            let v31_8: Space = if (v31_5).is_empty() { Space::new() } else {
              let v32_6: Path = concat_path(&(v30_6),&(v30_11_head));
              let v32_7: Space = routine_6(c, &(v32_6), &(v30_11_tail).make_space(), &(*s1));
              compose(&(v31_5),&(v32_7))
            };
            drop(v31_5);
            let v31_9: Space = intersect(&(*CONSTANT_2),&(v31_2));
            drop(v31_2);
            let v31_10: Space = if has_head(&(v31_9)) { singleton(&[]) } else { Space::new() };
            drop(v31_9);
            let v31_12: Space = if (v31_10).is_empty() { Space::new() } else {
              let v33_6: Path = concat_path(&(v30_6),&(v30_11_head));
              let v33_11: Space = routine_3(c, &(v33_6), &(v30_11_tail).make_space(), &(*s1));
              drop(v33_6);
              compose(&(v31_10),&(v33_11))
            };
            drop(v31_10);
            let v31_13: Space = unite(&(v31_8),&(v31_12));
            v30_11.join_into((v31_13).clone());
            }
            v30_11_cursor.ascend(1);
          }
          drop(v30_11_cursor);
          drop(v30_6);
          compose(&(v25_10),&(v30_11))
        };
        drop(v25_10);
        let v25_13: Space = unite(&(v25_8),&(v25_12));
        v24_7.join_into((v25_13).clone());
        }
        v24_7_cursor.ascend(1);
      }
      drop(v24_7_cursor);
      compose(&(v23_5),&(v24_7))
    };
    drop(v23_5);
    let v23_9: Space = intersect(&(*CONSTANT_2),&(v23_2));
    drop(v23_2);
    let v23_10: Space = if has_head(&(v23_9)) { singleton(&[]) } else { Space::new() };
    drop(v23_9);
    let v23_12: Space = if (v23_10).is_empty() { Space::new() } else {
      let v34_6: Path = concat_path(&(*p0),&(v22_24_head));
      let mut v34_11 = Space::new();
      let mut v34_11_cursor = (v22_24_tail).read_zipper();
      for v34_11_byte in v34_11_cursor.child_mask().iter() {
        v34_11_cursor.descend_to_byte(v34_11_byte);
        {
        let v34_11_tail = v34_11_cursor.fork_read_zipper();
        let v34_11_head = Path::from_slice(&[v34_11_byte]);
        let v35_2: Space = singleton(&(v34_11_head));
        let v35_3: Space = intersect(&(*CONSTANT_2),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_1),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let mut v36_7 = Space::new();
          let mut v36_7_cursor = (v34_11_tail).read_zipper();
          for v36_7_byte in v36_7_cursor.child_mask().iter() {
            v36_7_cursor.descend_to_byte(v36_7_byte);
            {
            let v36_7_tail = v36_7_cursor.fork_read_zipper();
            let v36_7_head = Path::from_slice(&[v36_7_byte]);
            let v37_2: Space = singleton(&(v36_7_head));
            let v37_3: Space = intersect(&(*CONSTANT_2),&(v37_2));
            let v37_4: Space = if has_head(&(v37_3)) { singleton(&[]) } else { Space::new() };
            drop(v37_3);
            let v37_5: Space = subtract(&(*CONSTANT_1),&(v37_4));
            drop(v37_4);
            let v37_8: Space = if (v37_5).is_empty() { Space::new() } else {
              let v38_6: Path = concat_path(&(v36_6),&(v36_7_head));
              let v38_7: Space = routine_6(c, &(v38_6), &(v36_7_tail).make_space(), &(*s1));
              compose(&(v37_5),&(v38_7))
            };
            drop(v37_5);
            let v37_9: Space = intersect(&(*CONSTANT_2),&(v37_2));
            drop(v37_2);
            let v37_10: Space = if has_head(&(v37_9)) { singleton(&[]) } else { Space::new() };
            drop(v37_9);
            let v37_12: Space = if (v37_10).is_empty() { Space::new() } else {
              let v39_6: Path = concat_path(&(v36_6),&(v36_7_head));
              let v39_11: Space = routine_7(c, &(v39_6), &(v36_7_tail).make_space(), &(*s1));
              drop(v39_6);
              compose(&(v37_10),&(v39_11))
            };
            drop(v37_10);
            let v37_13: Space = unite(&(v37_8),&(v37_12));
            v36_7.join_into((v37_13).clone());
            }
            v36_7_cursor.ascend(1);
          }
          drop(v36_7_cursor);
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_2),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_12: Space = if (v35_10).is_empty() { Space::new() } else {
          let v40_6: Path = concat_path(&(v34_6),&(v34_11_head));
          let mut v40_11 = Space::new();
          let mut v40_11_cursor = (v34_11_tail).read_zipper();
          for v40_11_byte in v40_11_cursor.child_mask().iter() {
            v40_11_cursor.descend_to_byte(v40_11_byte);
            {
            let v40_11_tail = v40_11_cursor.fork_read_zipper();
            let v40_11_head = Path::from_slice(&[v40_11_byte]);
            let v41_2: Space = singleton(&(v40_11_head));
            let v41_3: Space = intersect(&(*CONSTANT_2),&(v41_2));
            let v41_4: Space = if has_head(&(v41_3)) { singleton(&[]) } else { Space::new() };
            drop(v41_3);
            let v41_5: Space = subtract(&(*CONSTANT_1),&(v41_4));
            drop(v41_4);
            let v41_7: Space = if (v41_5).is_empty() { Space::new() } else {
              let v42_6: Space = routine_4(c, &(v40_11_head), &(v40_6), &(v40_11_tail).make_space(), &(*s1));
              compose(&(v41_5),&(v42_6))
            };
            drop(v41_5);
            let v41_8: Space = intersect(&(*CONSTANT_2),&(v41_2));
            drop(v41_2);
            let v41_9: Space = if has_head(&(v41_8)) { singleton(&[]) } else { Space::new() };
            drop(v41_8);
            let v41_11: Space = if (v41_9).is_empty() { Space::new() } else {
              let v43_10: Space = routine_5(c, &(v40_11_head), &(v40_6), &(v40_11_tail).make_space(), &(*s1));
              compose(&(v41_9),&(v43_10))
            };
            drop(v41_9);
            let v41_12: Space = unite(&(v41_7),&(v41_11));
            v40_11.join_into((v41_12).clone());
            }
            v40_11_cursor.ascend(1);
          }
          drop(v40_11_cursor);
          drop(v40_6);
          compose(&(v35_10),&(v40_11))
        };
        drop(v35_10);
        let v35_13: Space = unite(&(v35_8),&(v35_12));
        v34_11.join_into((v35_13).clone());
        }
        v34_11_cursor.ascend(1);
      }
      drop(v34_11_cursor);
      drop(v34_6);
      compose(&(v23_10),&(v34_11))
    };
    drop(v23_10);
    let v23_13: Space = unite(&(v23_8),&(v23_12));
    v22_24.join_into((v23_13).clone());
    }
    v22_24_cursor.ascend(1);
  }
  drop(v22_24_cursor);
  (v22_24).clone()
}

fn routine_2(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v44_24 = Space::new();
  let mut v44_24_cursor = (*s0).read_zipper();
  for v44_24_byte in v44_24_cursor.child_mask().iter() {
    v44_24_cursor.descend_to_byte(v44_24_byte);
    {
    let v44_24_tail = v44_24_cursor.fork_read_zipper();
    let v44_24_head = Path::from_slice(&[v44_24_byte]);
    let v45_2: Space = singleton(&(v44_24_head));
    let v45_3: Space = intersect(&(*CONSTANT_2),&(v45_2));
    let v45_4: Space = if has_head(&(v45_3)) { singleton(&[]) } else { Space::new() };
    drop(v45_3);
    let v45_5: Space = subtract(&(*CONSTANT_1),&(v45_4));
    drop(v45_4);
    let v45_8: Space = if (v45_5).is_empty() { Space::new() } else {
      let v46_6: Path = concat_path(&(*p0),&(v44_24_head));
      let mut v46_7 = Space::new();
      let mut v46_7_cursor = (v44_24_tail).read_zipper();
      for v46_7_byte in v46_7_cursor.child_mask().iter() {
        v46_7_cursor.descend_to_byte(v46_7_byte);
        {
        let v46_7_tail = v46_7_cursor.fork_read_zipper();
        let v46_7_head = Path::from_slice(&[v46_7_byte]);
        let v47_2: Space = singleton(&(v46_7_head));
        let v47_3: Space = intersect(&(*CONSTANT_2),&(v47_2));
        let v47_4: Space = if has_head(&(v47_3)) { singleton(&[]) } else { Space::new() };
        drop(v47_3);
        let v47_5: Space = subtract(&(*CONSTANT_1),&(v47_4));
        drop(v47_4);
        let v47_8: Space = if (v47_5).is_empty() { Space::new() } else {
          let v48_6: Path = concat_path(&(v46_6),&(v46_7_head));
          let mut v48_7 = Space::new();
          let mut v48_7_cursor = (v46_7_tail).read_zipper();
          for v48_7_byte in v48_7_cursor.child_mask().iter() {
            v48_7_cursor.descend_to_byte(v48_7_byte);
            {
            let v48_7_tail = v48_7_cursor.fork_read_zipper();
            let v48_7_head = Path::from_slice(&[v48_7_byte]);
            let v49_2: Space = singleton(&(v48_7_head));
            let v49_3: Space = intersect(&(*CONSTANT_2),&(v49_2));
            let v49_4: Space = if has_head(&(v49_3)) { singleton(&[]) } else { Space::new() };
            drop(v49_3);
            let v49_5: Space = subtract(&(*CONSTANT_1),&(v49_4));
            drop(v49_4);
            let v49_8: Space = if (v49_5).is_empty() { Space::new() } else {
              let v50_6: Path = concat_path(&(v48_6),&(v48_7_head));
              let v50_7: Space = routine_6(c, &(v50_6), &(v48_7_tail).make_space(), &(*s1));
              compose(&(v49_5),&(v50_7))
            };
            drop(v49_5);
            let v49_9: Space = intersect(&(*CONSTANT_2),&(v49_2));
            drop(v49_2);
            let v49_10: Space = if has_head(&(v49_9)) { singleton(&[]) } else { Space::new() };
            drop(v49_9);
            let v49_12: Space = if (v49_10).is_empty() { Space::new() } else {
              let v51_6: Path = concat_path(&(v48_6),&(v48_7_head));
              let v51_11: Space = routine_7(c, &(v51_6), &(v48_7_tail).make_space(), &(*s1));
              drop(v51_6);
              compose(&(v49_10),&(v51_11))
            };
            drop(v49_10);
            let v49_13: Space = unite(&(v49_8),&(v49_12));
            v48_7.join_into((v49_13).clone());
            }
            v48_7_cursor.ascend(1);
          }
          drop(v48_7_cursor);
          compose(&(v47_5),&(v48_7))
        };
        drop(v47_5);
        let v47_9: Space = intersect(&(*CONSTANT_2),&(v47_2));
        drop(v47_2);
        let v47_10: Space = if has_head(&(v47_9)) { singleton(&[]) } else { Space::new() };
        drop(v47_9);
        let v47_12: Space = if (v47_10).is_empty() { Space::new() } else {
          let v52_6: Path = concat_path(&(v46_6),&(v46_7_head));
          let mut v52_11 = Space::new();
          let mut v52_11_cursor = (v46_7_tail).read_zipper();
          for v52_11_byte in v52_11_cursor.child_mask().iter() {
            v52_11_cursor.descend_to_byte(v52_11_byte);
            {
            let v52_11_tail = v52_11_cursor.fork_read_zipper();
            let v52_11_head = Path::from_slice(&[v52_11_byte]);
            let v53_2: Space = singleton(&(v52_11_head));
            let v53_3: Space = intersect(&(*CONSTANT_2),&(v53_2));
            let v53_4: Space = if has_head(&(v53_3)) { singleton(&[]) } else { Space::new() };
            drop(v53_3);
            let v53_5: Space = subtract(&(*CONSTANT_1),&(v53_4));
            drop(v53_4);
            let v53_8: Space = if (v53_5).is_empty() { Space::new() } else {
              let v54_6: Path = concat_path(&(v52_6),&(v52_11_head));
              let v54_7: Space = routine_6(c, &(v54_6), &(v52_11_tail).make_space(), &(*s1));
              compose(&(v53_5),&(v54_7))
            };
            drop(v53_5);
            let v53_9: Space = intersect(&(*CONSTANT_2),&(v53_2));
            drop(v53_2);
            let v53_10: Space = if has_head(&(v53_9)) { singleton(&[]) } else { Space::new() };
            drop(v53_9);
            let v53_12: Space = if (v53_10).is_empty() { Space::new() } else {
              let v55_6: Path = concat_path(&(v52_6),&(v52_11_head));
              let v55_11: Space = routine_3(c, &(v55_6), &(v52_11_tail).make_space(), &(*s1));
              drop(v55_6);
              compose(&(v53_10),&(v55_11))
            };
            drop(v53_10);
            let v53_13: Space = unite(&(v53_8),&(v53_12));
            v52_11.join_into((v53_13).clone());
            }
            v52_11_cursor.ascend(1);
          }
          drop(v52_11_cursor);
          drop(v52_6);
          compose(&(v47_10),&(v52_11))
        };
        drop(v47_10);
        let v47_13: Space = unite(&(v47_8),&(v47_12));
        v46_7.join_into((v47_13).clone());
        }
        v46_7_cursor.ascend(1);
      }
      drop(v46_7_cursor);
      compose(&(v45_5),&(v46_7))
    };
    drop(v45_5);
    let v45_9: Space = intersect(&(*CONSTANT_2),&(v45_2));
    drop(v45_2);
    let v45_10: Space = if has_head(&(v45_9)) { singleton(&[]) } else { Space::new() };
    drop(v45_9);
    let v45_12: Space = if (v45_10).is_empty() { Space::new() } else {
      let v56_6: Path = concat_path(&(*p0),&(v44_24_head));
      let mut v56_11 = Space::new();
      let mut v56_11_cursor = (v44_24_tail).read_zipper();
      for v56_11_byte in v56_11_cursor.child_mask().iter() {
        v56_11_cursor.descend_to_byte(v56_11_byte);
        {
        let v56_11_tail = v56_11_cursor.fork_read_zipper();
        let v56_11_head = Path::from_slice(&[v56_11_byte]);
        let v57_2: Space = singleton(&(v56_11_head));
        let v57_3: Space = intersect(&(*CONSTANT_2),&(v57_2));
        let v57_4: Space = if has_head(&(v57_3)) { singleton(&[]) } else { Space::new() };
        drop(v57_3);
        let v57_5: Space = subtract(&(*CONSTANT_1),&(v57_4));
        drop(v57_4);
        let v57_7: Space = if (v57_5).is_empty() { Space::new() } else {
          let mut v58_6 = Space::new();
          let mut v58_6_cursor = (v56_11_tail).read_zipper();
          for v58_6_byte in v58_6_cursor.child_mask().iter() {
            v58_6_cursor.descend_to_byte(v58_6_byte);
            {
            let v58_6_tail = v58_6_cursor.fork_read_zipper();
            let v58_6_head = Path::from_slice(&[v58_6_byte]);
            let v59_2: Space = singleton(&(v58_6_head));
            let v59_3: Space = intersect(&(*CONSTANT_2),&(v59_2));
            let v59_4: Space = if has_head(&(v59_3)) { singleton(&[]) } else { Space::new() };
            drop(v59_3);
            let v59_5: Space = subtract(&(*CONSTANT_1),&(v59_4));
            drop(v59_4);
            let v59_8: Space = if (v59_5).is_empty() { Space::new() } else {
              let v60_6: Path = concat_path(&(v56_11_head),&(v58_6_head));
              let v60_7: Space = routine_8(c, &(v60_6), &(v56_6), &(v58_6_tail).make_space(), &(*s1));
              compose(&(v59_5),&(v60_7))
            };
            drop(v59_5);
            let v59_9: Space = intersect(&(*CONSTANT_2),&(v59_2));
            drop(v59_2);
            let v59_10: Space = if has_head(&(v59_9)) { singleton(&[]) } else { Space::new() };
            drop(v59_9);
            let v59_12: Space = if (v59_10).is_empty() { Space::new() } else {
              let v61_6: Path = concat_path(&(v56_11_head),&(v58_6_head));
              let v61_11: Space = routine_9(c, &(v61_6), &(v56_6), &(v58_6_tail).make_space(), &(*s1));
              drop(v61_6);
              compose(&(v59_10),&(v61_11))
            };
            drop(v59_10);
            let v59_13: Space = unite(&(v59_8),&(v59_12));
            v58_6.join_into((v59_13).clone());
            }
            v58_6_cursor.ascend(1);
          }
          drop(v58_6_cursor);
          compose(&(v57_5),&(v58_6))
        };
        drop(v57_5);
        let v57_8: Space = intersect(&(*CONSTANT_2),&(v57_2));
        drop(v57_2);
        let v57_9: Space = if has_head(&(v57_8)) { singleton(&[]) } else { Space::new() };
        drop(v57_8);
        let v57_11: Space = if (v57_9).is_empty() { Space::new() } else {
          let mut v62_10 = Space::new();
          let mut v62_10_cursor = (v56_11_tail).read_zipper();
          for v62_10_byte in v62_10_cursor.child_mask().iter() {
            v62_10_cursor.descend_to_byte(v62_10_byte);
            {
            let v62_10_tail = v62_10_cursor.fork_read_zipper();
            let v62_10_head = Path::from_slice(&[v62_10_byte]);
            let v63_2: Space = singleton(&(v62_10_head));
            let v63_3: Space = intersect(&(*CONSTANT_2),&(v63_2));
            let v63_4: Space = if has_head(&(v63_3)) { singleton(&[]) } else { Space::new() };
            drop(v63_3);
            let v63_5: Space = subtract(&(*CONSTANT_1),&(v63_4));
            drop(v63_4);
            let v63_8: Space = if (v63_5).is_empty() { Space::new() } else {
              let v64_6: Path = concat_path(&(v56_11_head),&(v62_10_head));
              let v64_7: Space = routine_8(c, &(v64_6), &(v56_6), &(v62_10_tail).make_space(), &(*s1));
              compose(&(v63_5),&(v64_7))
            };
            drop(v63_5);
            let v63_9: Space = intersect(&(*CONSTANT_2),&(v63_2));
            drop(v63_2);
            let v63_10: Space = if has_head(&(v63_9)) { singleton(&[]) } else { Space::new() };
            drop(v63_9);
            let v63_12: Space = if (v63_10).is_empty() { Space::new() } else {
              let v65_6: Path = concat_path(&(v56_11_head),&(v62_10_head));
              let v65_11: Space = routine_10(c, &(v65_6), &(v56_6), &(v62_10_tail).make_space(), &(*s1));
              drop(v65_6);
              compose(&(v63_10),&(v65_11))
            };
            drop(v63_10);
            let v63_13: Space = unite(&(v63_8),&(v63_12));
            v62_10.join_into((v63_13).clone());
            }
            v62_10_cursor.ascend(1);
          }
          drop(v62_10_cursor);
          compose(&(v57_9),&(v62_10))
        };
        drop(v57_9);
        let v57_12: Space = unite(&(v57_7),&(v57_11));
        v56_11.join_into((v57_12).clone());
        }
        v56_11_cursor.ascend(1);
      }
      drop(v56_11_cursor);
      drop(v56_6);
      compose(&(v45_10),&(v56_11))
    };
    drop(v45_10);
    let v45_13: Space = unite(&(v45_8),&(v45_12));
    v44_24.join_into((v45_13).clone());
    }
    v44_24_cursor.ascend(1);
  }
  drop(v44_24_cursor);
  (v44_24).clone()
}

fn routine_3(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v66_19: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let mut v66_26 = Space::new();
  let mut v66_26_cursor = (*s0).read_zipper();
  for v66_26_byte in v66_26_cursor.child_mask().iter() {
    v66_26_cursor.descend_to_byte(v66_26_byte);
    {
    let v66_26_tail = v66_26_cursor.fork_read_zipper();
    let v66_26_head = Path::from_slice(&[v66_26_byte]);
    let v67_2: Space = singleton(&(v66_26_head));
    let v67_3: Space = intersect(&(*CONSTANT_2),&(v67_2));
    let v67_4: Space = if has_head(&(v67_3)) { singleton(&[]) } else { Space::new() };
    drop(v67_3);
    let v67_5: Space = subtract(&(*CONSTANT_1),&(v67_4));
    drop(v67_4);
    let v67_7: Space = if (v67_5).is_empty() { Space::new() } else {
      let mut v68_6 = Space::new();
      let mut v68_6_cursor = (v66_26_tail).read_zipper();
      for v68_6_byte in v68_6_cursor.child_mask().iter() {
        v68_6_cursor.descend_to_byte(v68_6_byte);
        {
        let v68_6_tail = v68_6_cursor.fork_read_zipper();
        let v68_6_head = Path::from_slice(&[v68_6_byte]);
        let v69_2: Space = singleton(&(v68_6_head));
        let v69_3: Space = intersect(&(*CONSTANT_2),&(v69_2));
        let v69_4: Space = if has_head(&(v69_3)) { singleton(&[]) } else { Space::new() };
        drop(v69_3);
        let v69_5: Space = subtract(&(*CONSTANT_1),&(v69_4));
        drop(v69_4);
        let v69_8: Space = if (v69_5).is_empty() { Space::new() } else {
          let v70_6: Path = concat_path(&(v66_26_head),&(v68_6_head));
          let mut v70_7 = Space::new();
          let mut v70_7_cursor = (v68_6_tail).read_zipper();
          for v70_7_byte in v70_7_cursor.child_mask().iter() {
            v70_7_cursor.descend_to_byte(v70_7_byte);
            {
            let v70_7_tail = v70_7_cursor.fork_read_zipper();
            let v70_7_head = Path::from_slice(&[v70_7_byte]);
            let v71_2: Space = singleton(&(v70_7_head));
            let v71_3: Space = intersect(&(*CONSTANT_2),&(v71_2));
            let v71_4: Space = if has_head(&(v71_3)) { singleton(&[]) } else { Space::new() };
            drop(v71_3);
            let v71_5: Space = subtract(&(*CONSTANT_1),&(v71_4));
            drop(v71_4);
            let v71_8: Space = if (v71_5).is_empty() { Space::new() } else {
              let v72_6: Path = concat_path(&(v70_6),&(v70_7_head));
              let v72_7: Space = routine_11(c, &(v72_6), &(*p0), &(v70_7_tail).make_space(), &(*s1));
              compose(&(v71_5),&(v72_7))
            };
            drop(v71_5);
            let v71_9: Space = intersect(&(*CONSTANT_2),&(v71_2));
            drop(v71_2);
            let v71_10: Space = if has_head(&(v71_9)) { singleton(&[]) } else { Space::new() };
            drop(v71_9);
            let v71_12: Space = if (v71_10).is_empty() { Space::new() } else {
              let v73_6: Path = concat_path(&(v70_6),&(v70_7_head));
              let v73_11: Space = routine_12(c, &(v73_6), &(*p0), &(v70_7_tail).make_space(), &(*s1));
              drop(v73_6);
              compose(&(v71_10),&(v73_11))
            };
            drop(v71_10);
            let v71_13: Space = unite(&(v71_8),&(v71_12));
            v70_7.join_into((v71_13).clone());
            }
            v70_7_cursor.ascend(1);
          }
          drop(v70_7_cursor);
          compose(&(v69_5),&(v70_7))
        };
        drop(v69_5);
        let v69_9: Space = intersect(&(*CONSTANT_2),&(v69_2));
        drop(v69_2);
        let v69_10: Space = if has_head(&(v69_9)) { singleton(&[]) } else { Space::new() };
        drop(v69_9);
        let v69_12: Space = if (v69_10).is_empty() { Space::new() } else {
          let v74_6: Path = concat_path(&(v66_26_head),&(v68_6_head));
          let mut v74_11 = Space::new();
          let mut v74_11_cursor = (v68_6_tail).read_zipper();
          for v74_11_byte in v74_11_cursor.child_mask().iter() {
            v74_11_cursor.descend_to_byte(v74_11_byte);
            {
            let v74_11_tail = v74_11_cursor.fork_read_zipper();
            let v74_11_head = Path::from_slice(&[v74_11_byte]);
            let v75_2: Space = singleton(&(v74_11_head));
            let v75_3: Space = intersect(&(*CONSTANT_2),&(v75_2));
            let v75_4: Space = if has_head(&(v75_3)) { singleton(&[]) } else { Space::new() };
            drop(v75_3);
            let v75_5: Space = subtract(&(*CONSTANT_1),&(v75_4));
            drop(v75_4);
            let v75_8: Space = if (v75_5).is_empty() { Space::new() } else {
              let v76_6: Path = concat_path(&(v74_6),&(v74_11_head));
              let v76_7: Space = routine_11(c, &(v76_6), &(*p0), &(v74_11_tail).make_space(), &(*s1));
              compose(&(v75_5),&(v76_7))
            };
            drop(v75_5);
            let v75_9: Space = intersect(&(*CONSTANT_2),&(v75_2));
            drop(v75_2);
            let v75_10: Space = if has_head(&(v75_9)) { singleton(&[]) } else { Space::new() };
            drop(v75_9);
            let v75_12: Space = if (v75_10).is_empty() { Space::new() } else {
              let v77_6: Path = concat_path(&(v74_6),&(v74_11_head));
              let v77_11: Space = routine_10(c, &(v77_6), &(*p0), &(v74_11_tail).make_space(), &(*s1));
              drop(v77_6);
              compose(&(v75_10),&(v77_11))
            };
            drop(v75_10);
            let v75_13: Space = unite(&(v75_8),&(v75_12));
            v74_11.join_into((v75_13).clone());
            }
            v74_11_cursor.ascend(1);
          }
          drop(v74_11_cursor);
          drop(v74_6);
          compose(&(v69_10),&(v74_11))
        };
        drop(v69_10);
        let v69_13: Space = unite(&(v69_8),&(v69_12));
        v68_6.join_into((v69_13).clone());
        }
        v68_6_cursor.ascend(1);
      }
      drop(v68_6_cursor);
      compose(&(v67_5),&(v68_6))
    };
    drop(v67_5);
    let v67_8: Space = intersect(&(*CONSTANT_2),&(v67_2));
    drop(v67_2);
    let v67_9: Space = if has_head(&(v67_8)) { singleton(&[]) } else { Space::new() };
    drop(v67_8);
    let v67_12: Space = if (v67_9).is_empty() { Space::new() } else {
      let v78_10: Space = unwrap(&(v66_19),&(v66_26_head));
      let mut v78_11 = Space::new();
      let mut v78_11_cursor = (v66_26_tail).read_zipper();
      for v78_11_byte in v78_11_cursor.child_mask().iter() {
        v78_11_cursor.descend_to_byte(v78_11_byte);
        {
        let v78_11_tail = v78_11_cursor.fork_read_zipper();
        let v78_11_head = Path::from_slice(&[v78_11_byte]);
        let v79_2: Space = singleton(&(v78_11_head));
        let v79_3: Space = intersect(&(*CONSTANT_2),&(v79_2));
        let v79_4: Space = if has_head(&(v79_3)) { singleton(&[]) } else { Space::new() };
        drop(v79_3);
        let v79_5: Space = subtract(&(*CONSTANT_1),&(v79_4));
        drop(v79_4);
        let v79_8: Space = if (v79_5).is_empty() { Space::new() } else {
          let v80_6: Path = concat_path(&(v66_26_head),&(v78_11_head));
          let mut v80_7 = Space::new();
          let mut v80_7_cursor = (v78_11_tail).read_zipper();
          for v80_7_byte in v80_7_cursor.child_mask().iter() {
            v80_7_cursor.descend_to_byte(v80_7_byte);
            {
            let v80_7_tail = v80_7_cursor.fork_read_zipper();
            let v80_7_head = Path::from_slice(&[v80_7_byte]);
            let v81_2: Space = singleton(&(v80_7_head));
            let v81_3: Space = intersect(&(*CONSTANT_2),&(v81_2));
            let v81_4: Space = if has_head(&(v81_3)) { singleton(&[]) } else { Space::new() };
            drop(v81_3);
            let v81_5: Space = subtract(&(*CONSTANT_1),&(v81_4));
            drop(v81_4);
            let v81_8: Space = if (v81_5).is_empty() { Space::new() } else {
              let v82_6: Path = concat_path(&(v80_6),&(v80_7_head));
              let v82_7: Space = routine_11(c, &(v82_6), &(*p0), &(v80_7_tail).make_space(), &(*s1));
              compose(&(v81_5),&(v82_7))
            };
            drop(v81_5);
            let v81_9: Space = intersect(&(*CONSTANT_2),&(v81_2));
            drop(v81_2);
            let v81_10: Space = if has_head(&(v81_9)) { singleton(&[]) } else { Space::new() };
            drop(v81_9);
            let v81_12: Space = if (v81_10).is_empty() { Space::new() } else {
              let v83_6: Path = concat_path(&(v80_6),&(v80_7_head));
              let v83_11: Space = routine_12(c, &(v83_6), &(*p0), &(v80_7_tail).make_space(), &(*s1));
              drop(v83_6);
              compose(&(v81_10),&(v83_11))
            };
            drop(v81_10);
            let v81_13: Space = unite(&(v81_8),&(v81_12));
            v80_7.join_into((v81_13).clone());
            }
            v80_7_cursor.ascend(1);
          }
          drop(v80_7_cursor);
          drop(v80_6);
          compose(&(v79_5),&(v80_7))
        };
        drop(v79_5);
        let v79_9: Space = intersect(&(*CONSTANT_2),&(v79_2));
        drop(v79_2);
        let v79_10: Space = if has_head(&(v79_9)) { singleton(&[]) } else { Space::new() };
        drop(v79_9);
        let v79_13: Space = if (v79_10).is_empty() { Space::new() } else {
          let v84_11: Space = unwrap(&(v78_10),&(v78_11_head));
          let mut v84_12 = Space::new();
          let mut v84_12_cursor = (v84_11).read_zipper();
          for v84_12_byte in v84_12_cursor.child_mask().iter() {
            v84_12_cursor.descend_to_byte(v84_12_byte);
            {
            let v84_12_tail = v84_12_cursor.fork_read_zipper();
            let v84_12_head = Path::from_slice(&[v84_12_byte]);
            let v85_2: Space = singleton(&(v84_12_head));
            let v85_3: Space = intersect(&(*CONSTANT_2),&(v85_2));
            let v85_4: Space = if has_head(&(v85_3)) { singleton(&[]) } else { Space::new() };
            drop(v85_3);
            let v85_5: Space = subtract(&(*CONSTANT_1),&(v85_4));
            drop(v85_4);
            let v85_7: Space = if (v85_5).is_empty() { Space::new() } else {
              let v86_6: Space = routine_13(c, &(v84_12_head), &(*p0), &(v84_12_tail).make_space());
              compose(&(v85_5),&(v86_6))
            };
            drop(v85_5);
            let v85_8: Space = intersect(&(*CONSTANT_2),&(v85_2));
            drop(v85_2);
            let v85_9: Space = if has_head(&(v85_8)) { singleton(&[]) } else { Space::new() };
            drop(v85_8);
            let v85_11: Space = if (v85_9).is_empty() { Space::new() } else {
              let v87_10: Space = routine_14(c, &(v84_12_head), &(*p0), &(v84_12_tail).make_space());
              compose(&(v85_9),&(v87_10))
            };
            drop(v85_9);
            let v85_12: Space = unite(&(v85_7),&(v85_11));
            v84_12.join_into((v85_12).clone());
            }
            v84_12_cursor.ascend(1);
          }
          drop(v84_12_cursor);
          drop(v84_11);
          compose(&(v79_10),&(v84_12))
        };
        drop(v79_10);
        let v79_14: Space = unite(&(v79_8),&(v79_13));
        v78_11.join_into((v79_14).clone());
        }
        v78_11_cursor.ascend(1);
      }
      drop(v78_11_cursor);
      drop(v78_10);
      compose(&(v67_9),&(v78_11))
    };
    drop(v67_9);
    let v67_13: Space = unite(&(v67_7),&(v67_12));
    v66_26.join_into((v67_13).clone());
    }
    v66_26_cursor.ascend(1);
  }
  drop(v66_26_cursor);
  drop(v66_19);
  (v66_26).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v88_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v88_21: Space = unwrap(&(v88_20),&(*p0));
  drop(v88_20);
  let mut v88_28 = Space::new();
  let mut v88_28_cursor = (*s0).read_zipper();
  for v88_28_byte in v88_28_cursor.child_mask().iter() {
    v88_28_cursor.descend_to_byte(v88_28_byte);
    {
    let v88_28_tail = v88_28_cursor.fork_read_zipper();
    let v88_28_head = Path::from_slice(&[v88_28_byte]);
    let v89_2: Space = singleton(&(v88_28_head));
    let v89_3: Space = intersect(&(*CONSTANT_2),&(v89_2));
    let v89_4: Space = if has_head(&(v89_3)) { singleton(&[]) } else { Space::new() };
    drop(v89_3);
    let v89_5: Space = subtract(&(*CONSTANT_1),&(v89_4));
    drop(v89_4);
    let v89_8: Space = if (v89_5).is_empty() { Space::new() } else {
      let v90_6: Path = concat_path(&(*p0),&(v88_28_head));
      let mut v90_7 = Space::new();
      let mut v90_7_cursor = (v88_28_tail).read_zipper();
      for v90_7_byte in v90_7_cursor.child_mask().iter() {
        v90_7_cursor.descend_to_byte(v90_7_byte);
        {
        let v90_7_tail = v90_7_cursor.fork_read_zipper();
        let v90_7_head = Path::from_slice(&[v90_7_byte]);
        let v91_2: Space = singleton(&(v90_7_head));
        let v91_3: Space = intersect(&(*CONSTANT_2),&(v91_2));
        let v91_4: Space = if has_head(&(v91_3)) { singleton(&[]) } else { Space::new() };
        drop(v91_3);
        let v91_5: Space = subtract(&(*CONSTANT_1),&(v91_4));
        drop(v91_4);
        let v91_8: Space = if (v91_5).is_empty() { Space::new() } else {
          let v92_6: Path = concat_path(&(v90_6),&(v90_7_head));
          let mut v92_7 = Space::new();
          let mut v92_7_cursor = (v90_7_tail).read_zipper();
          for v92_7_byte in v92_7_cursor.child_mask().iter() {
            v92_7_cursor.descend_to_byte(v92_7_byte);
            {
            let v92_7_tail = v92_7_cursor.fork_read_zipper();
            let v92_7_head = Path::from_slice(&[v92_7_byte]);
            let v93_2: Space = singleton(&(v92_7_head));
            let v93_3: Space = intersect(&(*CONSTANT_2),&(v93_2));
            let v93_4: Space = if has_head(&(v93_3)) { singleton(&[]) } else { Space::new() };
            drop(v93_3);
            let v93_5: Space = subtract(&(*CONSTANT_1),&(v93_4));
            drop(v93_4);
            let v93_8: Space = if (v93_5).is_empty() { Space::new() } else {
              let v94_6: Path = concat_path(&(v92_6),&(v92_7_head));
              let v94_7: Space = routine_15(c, &(v94_6), &(*p1), &(v92_7_tail).make_space(), &(*s1));
              compose(&(v93_5),&(v94_7))
            };
            drop(v93_5);
            let v93_9: Space = intersect(&(*CONSTANT_2),&(v93_2));
            drop(v93_2);
            let v93_10: Space = if has_head(&(v93_9)) { singleton(&[]) } else { Space::new() };
            drop(v93_9);
            let v93_12: Space = if (v93_10).is_empty() { Space::new() } else {
              let v95_6: Path = concat_path(&(v92_6),&(v92_7_head));
              let v95_11: Space = routine_16(c, &(v95_6), &(*p1), &(v92_7_tail).make_space(), &(*s1));
              drop(v95_6);
              compose(&(v93_10),&(v95_11))
            };
            drop(v93_10);
            let v93_13: Space = unite(&(v93_8),&(v93_12));
            v92_7.join_into((v93_13).clone());
            }
            v92_7_cursor.ascend(1);
          }
          drop(v92_7_cursor);
          compose(&(v91_5),&(v92_7))
        };
        drop(v91_5);
        let v91_9: Space = intersect(&(*CONSTANT_2),&(v91_2));
        drop(v91_2);
        let v91_10: Space = if has_head(&(v91_9)) { singleton(&[]) } else { Space::new() };
        drop(v91_9);
        let v91_12: Space = if (v91_10).is_empty() { Space::new() } else {
          let v96_6: Path = concat_path(&(v90_6),&(v90_7_head));
          let mut v96_11 = Space::new();
          let mut v96_11_cursor = (v90_7_tail).read_zipper();
          for v96_11_byte in v96_11_cursor.child_mask().iter() {
            v96_11_cursor.descend_to_byte(v96_11_byte);
            {
            let v96_11_tail = v96_11_cursor.fork_read_zipper();
            let v96_11_head = Path::from_slice(&[v96_11_byte]);
            let v97_2: Space = singleton(&(v96_11_head));
            let v97_3: Space = intersect(&(*CONSTANT_2),&(v97_2));
            let v97_4: Space = if has_head(&(v97_3)) { singleton(&[]) } else { Space::new() };
            drop(v97_3);
            let v97_5: Space = subtract(&(*CONSTANT_1),&(v97_4));
            drop(v97_4);
            let v97_8: Space = if (v97_5).is_empty() { Space::new() } else {
              let v98_6: Path = concat_path(&(v96_6),&(v96_11_head));
              let v98_7: Space = routine_15(c, &(v98_6), &(*p1), &(v96_11_tail).make_space(), &(*s1));
              compose(&(v97_5),&(v98_7))
            };
            drop(v97_5);
            let v97_9: Space = intersect(&(*CONSTANT_2),&(v97_2));
            drop(v97_2);
            let v97_10: Space = if has_head(&(v97_9)) { singleton(&[]) } else { Space::new() };
            drop(v97_9);
            let v97_12: Space = if (v97_10).is_empty() { Space::new() } else {
              let v99_6: Path = concat_path(&(v96_6),&(v96_11_head));
              let v99_11: Space = routine_10(c, &(v99_6), &(*p1), &(v96_11_tail).make_space(), &(*s1));
              drop(v99_6);
              compose(&(v97_10),&(v99_11))
            };
            drop(v97_10);
            let v97_13: Space = unite(&(v97_8),&(v97_12));
            v96_11.join_into((v97_13).clone());
            }
            v96_11_cursor.ascend(1);
          }
          drop(v96_11_cursor);
          drop(v96_6);
          compose(&(v91_10),&(v96_11))
        };
        drop(v91_10);
        let v91_13: Space = unite(&(v91_8),&(v91_12));
        v90_7.join_into((v91_13).clone());
        }
        v90_7_cursor.ascend(1);
      }
      drop(v90_7_cursor);
      compose(&(v89_5),&(v90_7))
    };
    drop(v89_5);
    let v89_9: Space = intersect(&(*CONSTANT_2),&(v89_2));
    drop(v89_2);
    let v89_10: Space = if has_head(&(v89_9)) { singleton(&[]) } else { Space::new() };
    drop(v89_9);
    let v89_13: Space = if (v89_10).is_empty() { Space::new() } else {
      let v100_6: Path = concat_path(&(*p0),&(v88_28_head));
      let v100_11: Space = unwrap(&(v88_21),&(v88_28_head));
      let mut v100_12 = Space::new();
      let mut v100_12_cursor = (v88_28_tail).read_zipper();
      for v100_12_byte in v100_12_cursor.child_mask().iter() {
        v100_12_cursor.descend_to_byte(v100_12_byte);
        {
        let v100_12_tail = v100_12_cursor.fork_read_zipper();
        let v100_12_head = Path::from_slice(&[v100_12_byte]);
        let v101_2: Space = singleton(&(v100_12_head));
        let v101_3: Space = intersect(&(*CONSTANT_2),&(v101_2));
        let v101_4: Space = if has_head(&(v101_3)) { singleton(&[]) } else { Space::new() };
        drop(v101_3);
        let v101_5: Space = subtract(&(*CONSTANT_1),&(v101_4));
        drop(v101_4);
        let v101_8: Space = if (v101_5).is_empty() { Space::new() } else {
          let v102_6: Path = concat_path(&(v100_6),&(v100_12_head));
          let mut v102_7 = Space::new();
          let mut v102_7_cursor = (v100_12_tail).read_zipper();
          for v102_7_byte in v102_7_cursor.child_mask().iter() {
            v102_7_cursor.descend_to_byte(v102_7_byte);
            {
            let v102_7_tail = v102_7_cursor.fork_read_zipper();
            let v102_7_head = Path::from_slice(&[v102_7_byte]);
            let v103_2: Space = singleton(&(v102_7_head));
            let v103_3: Space = intersect(&(*CONSTANT_2),&(v103_2));
            let v103_4: Space = if has_head(&(v103_3)) { singleton(&[]) } else { Space::new() };
            drop(v103_3);
            let v103_5: Space = subtract(&(*CONSTANT_1),&(v103_4));
            drop(v103_4);
            let v103_8: Space = if (v103_5).is_empty() { Space::new() } else {
              let v104_6: Path = concat_path(&(v102_6),&(v102_7_head));
              let v104_7: Space = routine_15(c, &(v104_6), &(*p1), &(v102_7_tail).make_space(), &(*s1));
              compose(&(v103_5),&(v104_7))
            };
            drop(v103_5);
            let v103_9: Space = intersect(&(*CONSTANT_2),&(v103_2));
            drop(v103_2);
            let v103_10: Space = if has_head(&(v103_9)) { singleton(&[]) } else { Space::new() };
            drop(v103_9);
            let v103_12: Space = if (v103_10).is_empty() { Space::new() } else {
              let v105_6: Path = concat_path(&(v102_6),&(v102_7_head));
              let v105_11: Space = routine_16(c, &(v105_6), &(*p1), &(v102_7_tail).make_space(), &(*s1));
              drop(v105_6);
              compose(&(v103_10),&(v105_11))
            };
            drop(v103_10);
            let v103_13: Space = unite(&(v103_8),&(v103_12));
            v102_7.join_into((v103_13).clone());
            }
            v102_7_cursor.ascend(1);
          }
          drop(v102_7_cursor);
          drop(v102_6);
          compose(&(v101_5),&(v102_7))
        };
        drop(v101_5);
        let v101_9: Space = intersect(&(*CONSTANT_2),&(v101_2));
        drop(v101_2);
        let v101_10: Space = if has_head(&(v101_9)) { singleton(&[]) } else { Space::new() };
        drop(v101_9);
        let v101_13: Space = if (v101_10).is_empty() { Space::new() } else {
          let v106_11: Space = unwrap(&(v100_11),&(v100_12_head));
          let mut v106_12 = Space::new();
          let mut v106_12_cursor = (v106_11).read_zipper();
          for v106_12_byte in v106_12_cursor.child_mask().iter() {
            v106_12_cursor.descend_to_byte(v106_12_byte);
            {
            let v106_12_tail = v106_12_cursor.fork_read_zipper();
            let v106_12_head = Path::from_slice(&[v106_12_byte]);
            let v107_2: Space = singleton(&(v106_12_head));
            let v107_3: Space = intersect(&(*CONSTANT_2),&(v107_2));
            let v107_4: Space = if has_head(&(v107_3)) { singleton(&[]) } else { Space::new() };
            drop(v107_3);
            let v107_5: Space = subtract(&(*CONSTANT_1),&(v107_4));
            drop(v107_4);
            let v107_7: Space = if (v107_5).is_empty() { Space::new() } else {
              let v108_6: Space = routine_13(c, &(v106_12_head), &(*p1), &(v106_12_tail).make_space());
              compose(&(v107_5),&(v108_6))
            };
            drop(v107_5);
            let v107_8: Space = intersect(&(*CONSTANT_2),&(v107_2));
            drop(v107_2);
            let v107_9: Space = if has_head(&(v107_8)) { singleton(&[]) } else { Space::new() };
            drop(v107_8);
            let v107_11: Space = if (v107_9).is_empty() { Space::new() } else {
              let v109_10: Space = routine_14(c, &(v106_12_head), &(*p1), &(v106_12_tail).make_space());
              compose(&(v107_9),&(v109_10))
            };
            drop(v107_9);
            let v107_12: Space = unite(&(v107_7),&(v107_11));
            v106_12.join_into((v107_12).clone());
            }
            v106_12_cursor.ascend(1);
          }
          drop(v106_12_cursor);
          drop(v106_11);
          compose(&(v101_10),&(v106_12))
        };
        drop(v101_10);
        let v101_14: Space = unite(&(v101_8),&(v101_13));
        v100_12.join_into((v101_14).clone());
        }
        v100_12_cursor.ascend(1);
      }
      drop(v100_12_cursor);
      drop(v100_6);
      drop(v100_11);
      compose(&(v89_10),&(v100_12))
    };
    drop(v89_10);
    let v89_14: Space = unite(&(v89_8),&(v89_13));
    v88_28.join_into((v89_14).clone());
    }
    v88_28_cursor.ascend(1);
  }
  drop(v88_28_cursor);
  drop(v88_21);
  (v88_28).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v110_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v110_9: Space = unwrap(&(v110_8),&(*p0));
  drop(v110_8);
  let mut v110_28 = Space::new();
  let mut v110_28_cursor = (*s0).read_zipper();
  for v110_28_byte in v110_28_cursor.child_mask().iter() {
    v110_28_cursor.descend_to_byte(v110_28_byte);
    {
    let v110_28_tail = v110_28_cursor.fork_read_zipper();
    let v110_28_head = Path::from_slice(&[v110_28_byte]);
    let v111_2: Space = singleton(&(v110_28_head));
    let v111_3: Space = intersect(&(*CONSTANT_2),&(v111_2));
    let v111_4: Space = if has_head(&(v111_3)) { singleton(&[]) } else { Space::new() };
    drop(v111_3);
    let v111_5: Space = subtract(&(*CONSTANT_1),&(v111_4));
    drop(v111_4);
    let v111_8: Space = if (v111_5).is_empty() { Space::new() } else {
      let v112_6: Path = concat_path(&(*p0),&(v110_28_head));
      let mut v112_7 = Space::new();
      let mut v112_7_cursor = (v110_28_tail).read_zipper();
      for v112_7_byte in v112_7_cursor.child_mask().iter() {
        v112_7_cursor.descend_to_byte(v112_7_byte);
        {
        let v112_7_tail = v112_7_cursor.fork_read_zipper();
        let v112_7_head = Path::from_slice(&[v112_7_byte]);
        let v113_2: Space = singleton(&(v112_7_head));
        let v113_3: Space = intersect(&(*CONSTANT_2),&(v113_2));
        let v113_4: Space = if has_head(&(v113_3)) { singleton(&[]) } else { Space::new() };
        drop(v113_3);
        let v113_5: Space = subtract(&(*CONSTANT_1),&(v113_4));
        drop(v113_4);
        let v113_8: Space = if (v113_5).is_empty() { Space::new() } else {
          let v114_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let mut v114_7 = Space::new();
          let mut v114_7_cursor = (v112_7_tail).read_zipper();
          for v114_7_byte in v114_7_cursor.child_mask().iter() {
            v114_7_cursor.descend_to_byte(v114_7_byte);
            {
            let v114_7_tail = v114_7_cursor.fork_read_zipper();
            let v114_7_head = Path::from_slice(&[v114_7_byte]);
            let v115_2: Space = singleton(&(v114_7_head));
            let v115_3: Space = intersect(&(*CONSTANT_2),&(v115_2));
            let v115_4: Space = if has_head(&(v115_3)) { singleton(&[]) } else { Space::new() };
            drop(v115_3);
            let v115_5: Space = subtract(&(*CONSTANT_1),&(v115_4));
            drop(v115_4);
            let v115_8: Space = if (v115_5).is_empty() { Space::new() } else {
              let v116_6: Path = concat_path(&(v114_6),&(v114_7_head));
              let v116_7: Space = routine_15(c, &(v116_6), &(*p1), &(v114_7_tail).make_space(), &(*s1));
              compose(&(v115_5),&(v116_7))
            };
            drop(v115_5);
            let v115_9: Space = intersect(&(*CONSTANT_2),&(v115_2));
            drop(v115_2);
            let v115_10: Space = if has_head(&(v115_9)) { singleton(&[]) } else { Space::new() };
            drop(v115_9);
            let v115_12: Space = if (v115_10).is_empty() { Space::new() } else {
              let v117_6: Path = concat_path(&(v114_6),&(v114_7_head));
              let v117_11: Space = routine_16(c, &(v117_6), &(*p1), &(v114_7_tail).make_space(), &(*s1));
              drop(v117_6);
              compose(&(v115_10),&(v117_11))
            };
            drop(v115_10);
            let v115_13: Space = unite(&(v115_8),&(v115_12));
            v114_7.join_into((v115_13).clone());
            }
            v114_7_cursor.ascend(1);
          }
          drop(v114_7_cursor);
          compose(&(v113_5),&(v114_7))
        };
        drop(v113_5);
        let v113_9: Space = intersect(&(*CONSTANT_2),&(v113_2));
        drop(v113_2);
        let v113_10: Space = if has_head(&(v113_9)) { singleton(&[]) } else { Space::new() };
        drop(v113_9);
        let v113_12: Space = if (v113_10).is_empty() { Space::new() } else {
          let v118_6: Path = concat_path(&(v112_6),&(v112_7_head));
          let mut v118_11 = Space::new();
          let mut v118_11_cursor = (v112_7_tail).read_zipper();
          for v118_11_byte in v118_11_cursor.child_mask().iter() {
            v118_11_cursor.descend_to_byte(v118_11_byte);
            {
            let v118_11_tail = v118_11_cursor.fork_read_zipper();
            let v118_11_head = Path::from_slice(&[v118_11_byte]);
            let v119_2: Space = singleton(&(v118_11_head));
            let v119_3: Space = intersect(&(*CONSTANT_2),&(v119_2));
            let v119_4: Space = if has_head(&(v119_3)) { singleton(&[]) } else { Space::new() };
            drop(v119_3);
            let v119_5: Space = subtract(&(*CONSTANT_1),&(v119_4));
            drop(v119_4);
            let v119_8: Space = if (v119_5).is_empty() { Space::new() } else {
              let v120_6: Path = concat_path(&(v118_6),&(v118_11_head));
              let v120_7: Space = routine_15(c, &(v120_6), &(*p1), &(v118_11_tail).make_space(), &(*s1));
              compose(&(v119_5),&(v120_7))
            };
            drop(v119_5);
            let v119_9: Space = intersect(&(*CONSTANT_2),&(v119_2));
            drop(v119_2);
            let v119_10: Space = if has_head(&(v119_9)) { singleton(&[]) } else { Space::new() };
            drop(v119_9);
            let v119_12: Space = if (v119_10).is_empty() { Space::new() } else {
              let v121_6: Path = concat_path(&(v118_6),&(v118_11_head));
              let v121_11: Space = routine_10(c, &(v121_6), &(*p1), &(v118_11_tail).make_space(), &(*s1));
              drop(v121_6);
              compose(&(v119_10),&(v121_11))
            };
            drop(v119_10);
            let v119_13: Space = unite(&(v119_8),&(v119_12));
            v118_11.join_into((v119_13).clone());
            }
            v118_11_cursor.ascend(1);
          }
          drop(v118_11_cursor);
          drop(v118_6);
          compose(&(v113_10),&(v118_11))
        };
        drop(v113_10);
        let v113_13: Space = unite(&(v113_8),&(v113_12));
        v112_7.join_into((v113_13).clone());
        }
        v112_7_cursor.ascend(1);
      }
      drop(v112_7_cursor);
      drop(v112_6);
      compose(&(v111_5),&(v112_7))
    };
    drop(v111_5);
    let v111_9: Space = intersect(&(*CONSTANT_2),&(v111_2));
    drop(v111_2);
    let v111_10: Space = if has_head(&(v111_9)) { singleton(&[]) } else { Space::new() };
    drop(v111_9);
    let v111_13: Space = if (v111_10).is_empty() { Space::new() } else {
      let v122_11: Space = unwrap(&(v110_9),&(v110_28_head));
      let mut v122_12 = Space::new();
      let mut v122_12_cursor = (v122_11).read_zipper();
      for v122_12_byte in v122_12_cursor.child_mask().iter() {
        v122_12_cursor.descend_to_byte(v122_12_byte);
        {
        let v122_12_tail = v122_12_cursor.fork_read_zipper();
        let v122_12_head = Path::from_slice(&[v122_12_byte]);
        let v123_2: Space = singleton(&(v122_12_head));
        let v123_3: Space = intersect(&(*CONSTANT_2),&(v123_2));
        let v123_4: Space = if has_head(&(v123_3)) { singleton(&[]) } else { Space::new() };
        drop(v123_3);
        let v123_5: Space = subtract(&(*CONSTANT_1),&(v123_4));
        drop(v123_4);
        let v123_7: Space = if (v123_5).is_empty() { Space::new() } else {
          let mut v124_6 = Space::new();
          let mut v124_6_cursor = (v122_12_tail).read_zipper();
          for v124_6_byte in v124_6_cursor.child_mask().iter() {
            v124_6_cursor.descend_to_byte(v124_6_byte);
            {
            let v124_6_tail = v124_6_cursor.fork_read_zipper();
            let v124_6_head = Path::from_slice(&[v124_6_byte]);
            let v125_2: Space = singleton(&(v124_6_head));
            let v125_3: Space = intersect(&(*CONSTANT_2),&(v125_2));
            let v125_4: Space = if has_head(&(v125_3)) { singleton(&[]) } else { Space::new() };
            drop(v125_3);
            let v125_5: Space = subtract(&(*CONSTANT_1),&(v125_4));
            drop(v125_4);
            let v125_8: Space = if (v125_5).is_empty() { Space::new() } else {
              let v126_6: Path = concat_path(&(v122_12_head),&(v124_6_head));
              let v126_7: Space = routine_17(c, &(v126_6), &(*p1), &(v124_6_tail).make_space());
              compose(&(v125_5),&(v126_7))
            };
            drop(v125_5);
            let v125_9: Space = intersect(&(*CONSTANT_2),&(v125_2));
            drop(v125_2);
            let v125_10: Space = if has_head(&(v125_9)) { singleton(&[]) } else { Space::new() };
            drop(v125_9);
            let v125_12: Space = if (v125_10).is_empty() { Space::new() } else {
              let v127_6: Path = concat_path(&(v122_12_head),&(v124_6_head));
              let v127_11: Space = routine_18(c, &(v127_6), &(*p1), &(v124_6_tail).make_space());
              drop(v127_6);
              compose(&(v125_10),&(v127_11))
            };
            drop(v125_10);
            let v125_13: Space = unite(&(v125_8),&(v125_12));
            v124_6.join_into((v125_13).clone());
            }
            v124_6_cursor.ascend(1);
          }
          drop(v124_6_cursor);
          compose(&(v123_5),&(v124_6))
        };
        drop(v123_5);
        let v123_8: Space = intersect(&(*CONSTANT_2),&(v123_2));
        drop(v123_2);
        let v123_9: Space = if has_head(&(v123_8)) { singleton(&[]) } else { Space::new() };
        drop(v123_8);
        let v123_11: Space = if (v123_9).is_empty() { Space::new() } else {
          let mut v128_10 = Space::new();
          let mut v128_10_cursor = (v122_12_tail).read_zipper();
          for v128_10_byte in v128_10_cursor.child_mask().iter() {
            v128_10_cursor.descend_to_byte(v128_10_byte);
            {
            let v128_10_tail = v128_10_cursor.fork_read_zipper();
            let v128_10_head = Path::from_slice(&[v128_10_byte]);
            let v129_2: Space = singleton(&(v128_10_head));
            let v129_3: Space = intersect(&(*CONSTANT_2),&(v129_2));
            let v129_4: Space = if has_head(&(v129_3)) { singleton(&[]) } else { Space::new() };
            drop(v129_3);
            let v129_5: Space = subtract(&(*CONSTANT_1),&(v129_4));
            drop(v129_4);
            let v129_8: Space = if (v129_5).is_empty() { Space::new() } else {
              let v130_6: Path = concat_path(&(v122_12_head),&(v128_10_head));
              let v130_7: Space = routine_17(c, &(v130_6), &(*p1), &(v128_10_tail).make_space());
              compose(&(v129_5),&(v130_7))
            };
            drop(v129_5);
            let v129_9: Space = intersect(&(*CONSTANT_2),&(v129_2));
            drop(v129_2);
            let v129_10: Space = if has_head(&(v129_9)) { singleton(&[]) } else { Space::new() };
            drop(v129_9);
            let v129_12: Space = if (v129_10).is_empty() { Space::new() } else {
              let v131_6: Path = concat_path(&(v122_12_head),&(v128_10_head));
              let v131_11: Space = routine_19(c, &(v131_6), &(*p1), &(v128_10_tail).make_space());
              drop(v131_6);
              compose(&(v129_10),&(v131_11))
            };
            drop(v129_10);
            let v129_13: Space = unite(&(v129_8),&(v129_12));
            v128_10.join_into((v129_13).clone());
            }
            v128_10_cursor.ascend(1);
          }
          drop(v128_10_cursor);
          compose(&(v123_9),&(v128_10))
        };
        drop(v123_9);
        let v123_12: Space = unite(&(v123_7),&(v123_11));
        v122_12.join_into((v123_12).clone());
        }
        v122_12_cursor.ascend(1);
      }
      drop(v122_12_cursor);
      drop(v122_11);
      compose(&(v111_10),&(v122_12))
    };
    drop(v111_10);
    let v111_14: Space = unite(&(v111_8),&(v111_13));
    v110_28.join_into((v111_14).clone());
    }
    v110_28_cursor.ascend(1);
  }
  drop(v110_28_cursor);
  drop(v110_9);
  (v110_28).clone()
}

fn routine_6(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v132_24 = Space::new();
  let mut v132_24_cursor = (*s0).read_zipper();
  for v132_24_byte in v132_24_cursor.child_mask().iter() {
    v132_24_cursor.descend_to_byte(v132_24_byte);
    {
    let v132_24_tail = v132_24_cursor.fork_read_zipper();
    let v132_24_head = Path::from_slice(&[v132_24_byte]);
    let v133_2: Space = singleton(&(v132_24_head));
    let v133_3: Space = intersect(&(*CONSTANT_2),&(v133_2));
    let v133_4: Space = if has_head(&(v133_3)) { singleton(&[]) } else { Space::new() };
    drop(v133_3);
    let v133_5: Space = subtract(&(*CONSTANT_1),&(v133_4));
    drop(v133_4);
    let v133_8: Space = if (v133_5).is_empty() { Space::new() } else {
      let v134_6: Path = concat_path(&(*p0),&(v132_24_head));
      let mut v134_7 = Space::new();
      let mut v134_7_cursor = (v132_24_tail).read_zipper();
      for v134_7_byte in v134_7_cursor.child_mask().iter() {
        v134_7_cursor.descend_to_byte(v134_7_byte);
        {
        let v134_7_tail = v134_7_cursor.fork_read_zipper();
        let v134_7_head = Path::from_slice(&[v134_7_byte]);
        let v135_2: Space = singleton(&(v134_7_head));
        let v135_3: Space = intersect(&(*CONSTANT_2),&(v135_2));
        let v135_4: Space = if has_head(&(v135_3)) { singleton(&[]) } else { Space::new() };
        drop(v135_3);
        let v135_5: Space = subtract(&(*CONSTANT_1),&(v135_4));
        drop(v135_4);
        let v135_8: Space = if (v135_5).is_empty() { Space::new() } else {
          let v136_6: Path = concat_path(&(v134_6),&(v134_7_head));
          let mut v136_7 = Space::new();
          let mut v136_7_cursor = (v134_7_tail).read_zipper();
          for v136_7_byte in v136_7_cursor.child_mask().iter() {
            v136_7_cursor.descend_to_byte(v136_7_byte);
            {
            let v136_7_tail = v136_7_cursor.fork_read_zipper();
            let v136_7_head = Path::from_slice(&[v136_7_byte]);
            let v137_2: Space = singleton(&(v136_7_head));
            let v137_3: Space = intersect(&(*CONSTANT_2),&(v137_2));
            let v137_4: Space = if has_head(&(v137_3)) { singleton(&[]) } else { Space::new() };
            drop(v137_3);
            let v137_5: Space = subtract(&(*CONSTANT_1),&(v137_4));
            drop(v137_4);
            let v137_8: Space = if (v137_5).is_empty() { Space::new() } else {
              let v138_6: Path = concat_path(&(v136_6),&(v136_7_head));
              let v138_7: Space = routine_20(c, &(v138_6), &(v136_7_tail).make_space(), &(*s1));
              compose(&(v137_5),&(v138_7))
            };
            drop(v137_5);
            let v137_9: Space = intersect(&(*CONSTANT_2),&(v137_2));
            drop(v137_2);
            let v137_10: Space = if has_head(&(v137_9)) { singleton(&[]) } else { Space::new() };
            drop(v137_9);
            let v137_12: Space = if (v137_10).is_empty() { Space::new() } else {
              let v139_6: Path = concat_path(&(v136_6),&(v136_7_head));
              let v139_11: Space = routine_21(c, &(v139_6), &(v136_7_tail).make_space(), &(*s1));
              drop(v139_6);
              compose(&(v137_10),&(v139_11))
            };
            drop(v137_10);
            let v137_13: Space = unite(&(v137_8),&(v137_12));
            v136_7.join_into((v137_13).clone());
            }
            v136_7_cursor.ascend(1);
          }
          drop(v136_7_cursor);
          compose(&(v135_5),&(v136_7))
        };
        drop(v135_5);
        let v135_9: Space = intersect(&(*CONSTANT_2),&(v135_2));
        drop(v135_2);
        let v135_10: Space = if has_head(&(v135_9)) { singleton(&[]) } else { Space::new() };
        drop(v135_9);
        let v135_12: Space = if (v135_10).is_empty() { Space::new() } else {
          let v140_6: Path = concat_path(&(v134_6),&(v134_7_head));
          let mut v140_11 = Space::new();
          let mut v140_11_cursor = (v134_7_tail).read_zipper();
          for v140_11_byte in v140_11_cursor.child_mask().iter() {
            v140_11_cursor.descend_to_byte(v140_11_byte);
            {
            let v140_11_tail = v140_11_cursor.fork_read_zipper();
            let v140_11_head = Path::from_slice(&[v140_11_byte]);
            let v141_2: Space = singleton(&(v140_11_head));
            let v141_3: Space = intersect(&(*CONSTANT_2),&(v141_2));
            let v141_4: Space = if has_head(&(v141_3)) { singleton(&[]) } else { Space::new() };
            drop(v141_3);
            let v141_5: Space = subtract(&(*CONSTANT_1),&(v141_4));
            drop(v141_4);
            let v141_8: Space = if (v141_5).is_empty() { Space::new() } else {
              let v142_6: Path = concat_path(&(v140_6),&(v140_11_head));
              let v142_7: Space = routine_20(c, &(v142_6), &(v140_11_tail).make_space(), &(*s1));
              compose(&(v141_5),&(v142_7))
            };
            drop(v141_5);
            let v141_9: Space = intersect(&(*CONSTANT_2),&(v141_2));
            drop(v141_2);
            let v141_10: Space = if has_head(&(v141_9)) { singleton(&[]) } else { Space::new() };
            drop(v141_9);
            let v141_12: Space = if (v141_10).is_empty() { Space::new() } else {
              let v143_6: Path = concat_path(&(v140_6),&(v140_11_head));
              let v143_11: Space = routine_3(c, &(v143_6), &(v140_11_tail).make_space(), &(*s1));
              drop(v143_6);
              compose(&(v141_10),&(v143_11))
            };
            drop(v141_10);
            let v141_13: Space = unite(&(v141_8),&(v141_12));
            v140_11.join_into((v141_13).clone());
            }
            v140_11_cursor.ascend(1);
          }
          drop(v140_11_cursor);
          drop(v140_6);
          compose(&(v135_10),&(v140_11))
        };
        drop(v135_10);
        let v135_13: Space = unite(&(v135_8),&(v135_12));
        v134_7.join_into((v135_13).clone());
        }
        v134_7_cursor.ascend(1);
      }
      drop(v134_7_cursor);
      compose(&(v133_5),&(v134_7))
    };
    drop(v133_5);
    let v133_9: Space = intersect(&(*CONSTANT_2),&(v133_2));
    drop(v133_2);
    let v133_10: Space = if has_head(&(v133_9)) { singleton(&[]) } else { Space::new() };
    drop(v133_9);
    let v133_12: Space = if (v133_10).is_empty() { Space::new() } else {
      let v144_6: Path = concat_path(&(*p0),&(v132_24_head));
      let mut v144_11 = Space::new();
      let mut v144_11_cursor = (v132_24_tail).read_zipper();
      for v144_11_byte in v144_11_cursor.child_mask().iter() {
        v144_11_cursor.descend_to_byte(v144_11_byte);
        {
        let v144_11_tail = v144_11_cursor.fork_read_zipper();
        let v144_11_head = Path::from_slice(&[v144_11_byte]);
        let v145_2: Space = singleton(&(v144_11_head));
        let v145_3: Space = intersect(&(*CONSTANT_2),&(v145_2));
        let v145_4: Space = if has_head(&(v145_3)) { singleton(&[]) } else { Space::new() };
        drop(v145_3);
        let v145_5: Space = subtract(&(*CONSTANT_1),&(v145_4));
        drop(v145_4);
        let v145_8: Space = if (v145_5).is_empty() { Space::new() } else {
          let v146_6: Path = concat_path(&(v144_6),&(v144_11_head));
          let mut v146_7 = Space::new();
          let mut v146_7_cursor = (v144_11_tail).read_zipper();
          for v146_7_byte in v146_7_cursor.child_mask().iter() {
            v146_7_cursor.descend_to_byte(v146_7_byte);
            {
            let v146_7_tail = v146_7_cursor.fork_read_zipper();
            let v146_7_head = Path::from_slice(&[v146_7_byte]);
            let v147_2: Space = singleton(&(v146_7_head));
            let v147_3: Space = intersect(&(*CONSTANT_2),&(v147_2));
            let v147_4: Space = if has_head(&(v147_3)) { singleton(&[]) } else { Space::new() };
            drop(v147_3);
            let v147_5: Space = subtract(&(*CONSTANT_1),&(v147_4));
            drop(v147_4);
            let v147_8: Space = if (v147_5).is_empty() { Space::new() } else {
              let v148_6: Path = concat_path(&(v146_6),&(v146_7_head));
              let v148_7: Space = routine_20(c, &(v148_6), &(v146_7_tail).make_space(), &(*s1));
              compose(&(v147_5),&(v148_7))
            };
            drop(v147_5);
            let v147_9: Space = intersect(&(*CONSTANT_2),&(v147_2));
            drop(v147_2);
            let v147_10: Space = if has_head(&(v147_9)) { singleton(&[]) } else { Space::new() };
            drop(v147_9);
            let v147_12: Space = if (v147_10).is_empty() { Space::new() } else {
              let v149_6: Path = concat_path(&(v146_6),&(v146_7_head));
              let v149_11: Space = routine_21(c, &(v149_6), &(v146_7_tail).make_space(), &(*s1));
              drop(v149_6);
              compose(&(v147_10),&(v149_11))
            };
            drop(v147_10);
            let v147_13: Space = unite(&(v147_8),&(v147_12));
            v146_7.join_into((v147_13).clone());
            }
            v146_7_cursor.ascend(1);
          }
          drop(v146_7_cursor);
          compose(&(v145_5),&(v146_7))
        };
        drop(v145_5);
        let v145_9: Space = intersect(&(*CONSTANT_2),&(v145_2));
        drop(v145_2);
        let v145_10: Space = if has_head(&(v145_9)) { singleton(&[]) } else { Space::new() };
        drop(v145_9);
        let v145_12: Space = if (v145_10).is_empty() { Space::new() } else {
          let v150_6: Path = concat_path(&(v144_6),&(v144_11_head));
          let mut v150_11 = Space::new();
          let mut v150_11_cursor = (v144_11_tail).read_zipper();
          for v150_11_byte in v150_11_cursor.child_mask().iter() {
            v150_11_cursor.descend_to_byte(v150_11_byte);
            {
            let v150_11_tail = v150_11_cursor.fork_read_zipper();
            let v150_11_head = Path::from_slice(&[v150_11_byte]);
            let v151_2: Space = singleton(&(v150_11_head));
            let v151_3: Space = intersect(&(*CONSTANT_2),&(v151_2));
            let v151_4: Space = if has_head(&(v151_3)) { singleton(&[]) } else { Space::new() };
            drop(v151_3);
            let v151_5: Space = subtract(&(*CONSTANT_1),&(v151_4));
            drop(v151_4);
            let v151_7: Space = if (v151_5).is_empty() { Space::new() } else {
              let v152_6: Space = routine_4(c, &(v150_11_head), &(v150_6), &(v150_11_tail).make_space(), &(*s1));
              compose(&(v151_5),&(v152_6))
            };
            drop(v151_5);
            let v151_8: Space = intersect(&(*CONSTANT_2),&(v151_2));
            drop(v151_2);
            let v151_9: Space = if has_head(&(v151_8)) { singleton(&[]) } else { Space::new() };
            drop(v151_8);
            let v151_11: Space = if (v151_9).is_empty() { Space::new() } else {
              let v153_10: Space = routine_5(c, &(v150_11_head), &(v150_6), &(v150_11_tail).make_space(), &(*s1));
              compose(&(v151_9),&(v153_10))
            };
            drop(v151_9);
            let v151_12: Space = unite(&(v151_7),&(v151_11));
            v150_11.join_into((v151_12).clone());
            }
            v150_11_cursor.ascend(1);
          }
          drop(v150_11_cursor);
          drop(v150_6);
          compose(&(v145_10),&(v150_11))
        };
        drop(v145_10);
        let v145_13: Space = unite(&(v145_8),&(v145_12));
        v144_11.join_into((v145_13).clone());
        }
        v144_11_cursor.ascend(1);
      }
      drop(v144_11_cursor);
      drop(v144_6);
      compose(&(v133_10),&(v144_11))
    };
    drop(v133_10);
    let v133_13: Space = unite(&(v133_8),&(v133_12));
    v132_24.join_into((v133_13).clone());
    }
    v132_24_cursor.ascend(1);
  }
  drop(v132_24_cursor);
  (v132_24).clone()
}

fn routine_7(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v154_24 = Space::new();
  let mut v154_24_cursor = (*s0).read_zipper();
  for v154_24_byte in v154_24_cursor.child_mask().iter() {
    v154_24_cursor.descend_to_byte(v154_24_byte);
    {
    let v154_24_tail = v154_24_cursor.fork_read_zipper();
    let v154_24_head = Path::from_slice(&[v154_24_byte]);
    let v155_2: Space = singleton(&(v154_24_head));
    let v155_3: Space = intersect(&(*CONSTANT_2),&(v155_2));
    let v155_4: Space = if has_head(&(v155_3)) { singleton(&[]) } else { Space::new() };
    drop(v155_3);
    let v155_5: Space = subtract(&(*CONSTANT_1),&(v155_4));
    drop(v155_4);
    let v155_8: Space = if (v155_5).is_empty() { Space::new() } else {
      let v156_6: Path = concat_path(&(*p0),&(v154_24_head));
      let mut v156_7 = Space::new();
      let mut v156_7_cursor = (v154_24_tail).read_zipper();
      for v156_7_byte in v156_7_cursor.child_mask().iter() {
        v156_7_cursor.descend_to_byte(v156_7_byte);
        {
        let v156_7_tail = v156_7_cursor.fork_read_zipper();
        let v156_7_head = Path::from_slice(&[v156_7_byte]);
        let v157_2: Space = singleton(&(v156_7_head));
        let v157_3: Space = intersect(&(*CONSTANT_2),&(v157_2));
        let v157_4: Space = if has_head(&(v157_3)) { singleton(&[]) } else { Space::new() };
        drop(v157_3);
        let v157_5: Space = subtract(&(*CONSTANT_1),&(v157_4));
        drop(v157_4);
        let v157_8: Space = if (v157_5).is_empty() { Space::new() } else {
          let v158_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let mut v158_7 = Space::new();
          let mut v158_7_cursor = (v156_7_tail).read_zipper();
          for v158_7_byte in v158_7_cursor.child_mask().iter() {
            v158_7_cursor.descend_to_byte(v158_7_byte);
            {
            let v158_7_tail = v158_7_cursor.fork_read_zipper();
            let v158_7_head = Path::from_slice(&[v158_7_byte]);
            let v159_2: Space = singleton(&(v158_7_head));
            let v159_3: Space = intersect(&(*CONSTANT_2),&(v159_2));
            let v159_4: Space = if has_head(&(v159_3)) { singleton(&[]) } else { Space::new() };
            drop(v159_3);
            let v159_5: Space = subtract(&(*CONSTANT_1),&(v159_4));
            drop(v159_4);
            let v159_8: Space = if (v159_5).is_empty() { Space::new() } else {
              let v160_6: Path = concat_path(&(v158_6),&(v158_7_head));
              let v160_7: Space = routine_20(c, &(v160_6), &(v158_7_tail).make_space(), &(*s1));
              compose(&(v159_5),&(v160_7))
            };
            drop(v159_5);
            let v159_9: Space = intersect(&(*CONSTANT_2),&(v159_2));
            drop(v159_2);
            let v159_10: Space = if has_head(&(v159_9)) { singleton(&[]) } else { Space::new() };
            drop(v159_9);
            let v159_12: Space = if (v159_10).is_empty() { Space::new() } else {
              let v161_6: Path = concat_path(&(v158_6),&(v158_7_head));
              let v161_11: Space = routine_21(c, &(v161_6), &(v158_7_tail).make_space(), &(*s1));
              drop(v161_6);
              compose(&(v159_10),&(v161_11))
            };
            drop(v159_10);
            let v159_13: Space = unite(&(v159_8),&(v159_12));
            v158_7.join_into((v159_13).clone());
            }
            v158_7_cursor.ascend(1);
          }
          drop(v158_7_cursor);
          compose(&(v157_5),&(v158_7))
        };
        drop(v157_5);
        let v157_9: Space = intersect(&(*CONSTANT_2),&(v157_2));
        drop(v157_2);
        let v157_10: Space = if has_head(&(v157_9)) { singleton(&[]) } else { Space::new() };
        drop(v157_9);
        let v157_12: Space = if (v157_10).is_empty() { Space::new() } else {
          let v162_6: Path = concat_path(&(v156_6),&(v156_7_head));
          let mut v162_11 = Space::new();
          let mut v162_11_cursor = (v156_7_tail).read_zipper();
          for v162_11_byte in v162_11_cursor.child_mask().iter() {
            v162_11_cursor.descend_to_byte(v162_11_byte);
            {
            let v162_11_tail = v162_11_cursor.fork_read_zipper();
            let v162_11_head = Path::from_slice(&[v162_11_byte]);
            let v163_2: Space = singleton(&(v162_11_head));
            let v163_3: Space = intersect(&(*CONSTANT_2),&(v163_2));
            let v163_4: Space = if has_head(&(v163_3)) { singleton(&[]) } else { Space::new() };
            drop(v163_3);
            let v163_5: Space = subtract(&(*CONSTANT_1),&(v163_4));
            drop(v163_4);
            let v163_8: Space = if (v163_5).is_empty() { Space::new() } else {
              let v164_6: Path = concat_path(&(v162_6),&(v162_11_head));
              let v164_7: Space = routine_20(c, &(v164_6), &(v162_11_tail).make_space(), &(*s1));
              compose(&(v163_5),&(v164_7))
            };
            drop(v163_5);
            let v163_9: Space = intersect(&(*CONSTANT_2),&(v163_2));
            drop(v163_2);
            let v163_10: Space = if has_head(&(v163_9)) { singleton(&[]) } else { Space::new() };
            drop(v163_9);
            let v163_12: Space = if (v163_10).is_empty() { Space::new() } else {
              let v165_6: Path = concat_path(&(v162_6),&(v162_11_head));
              let v165_11: Space = routine_3(c, &(v165_6), &(v162_11_tail).make_space(), &(*s1));
              drop(v165_6);
              compose(&(v163_10),&(v165_11))
            };
            drop(v163_10);
            let v163_13: Space = unite(&(v163_8),&(v163_12));
            v162_11.join_into((v163_13).clone());
            }
            v162_11_cursor.ascend(1);
          }
          drop(v162_11_cursor);
          drop(v162_6);
          compose(&(v157_10),&(v162_11))
        };
        drop(v157_10);
        let v157_13: Space = unite(&(v157_8),&(v157_12));
        v156_7.join_into((v157_13).clone());
        }
        v156_7_cursor.ascend(1);
      }
      drop(v156_7_cursor);
      compose(&(v155_5),&(v156_7))
    };
    drop(v155_5);
    let v155_9: Space = intersect(&(*CONSTANT_2),&(v155_2));
    drop(v155_2);
    let v155_10: Space = if has_head(&(v155_9)) { singleton(&[]) } else { Space::new() };
    drop(v155_9);
    let v155_12: Space = if (v155_10).is_empty() { Space::new() } else {
      let v166_6: Path = concat_path(&(*p0),&(v154_24_head));
      let mut v166_11 = Space::new();
      let mut v166_11_cursor = (v154_24_tail).read_zipper();
      for v166_11_byte in v166_11_cursor.child_mask().iter() {
        v166_11_cursor.descend_to_byte(v166_11_byte);
        {
        let v166_11_tail = v166_11_cursor.fork_read_zipper();
        let v166_11_head = Path::from_slice(&[v166_11_byte]);
        let v167_2: Space = singleton(&(v166_11_head));
        let v167_3: Space = intersect(&(*CONSTANT_2),&(v167_2));
        let v167_4: Space = if has_head(&(v167_3)) { singleton(&[]) } else { Space::new() };
        drop(v167_3);
        let v167_5: Space = subtract(&(*CONSTANT_1),&(v167_4));
        drop(v167_4);
        let v167_7: Space = if (v167_5).is_empty() { Space::new() } else {
          let mut v168_6 = Space::new();
          let mut v168_6_cursor = (v166_11_tail).read_zipper();
          for v168_6_byte in v168_6_cursor.child_mask().iter() {
            v168_6_cursor.descend_to_byte(v168_6_byte);
            {
            let v168_6_tail = v168_6_cursor.fork_read_zipper();
            let v168_6_head = Path::from_slice(&[v168_6_byte]);
            let v169_2: Space = singleton(&(v168_6_head));
            let v169_3: Space = intersect(&(*CONSTANT_2),&(v169_2));
            let v169_4: Space = if has_head(&(v169_3)) { singleton(&[]) } else { Space::new() };
            drop(v169_3);
            let v169_5: Space = subtract(&(*CONSTANT_1),&(v169_4));
            drop(v169_4);
            let v169_8: Space = if (v169_5).is_empty() { Space::new() } else {
              let v170_6: Path = concat_path(&(v166_11_head),&(v168_6_head));
              let v170_7: Space = routine_8(c, &(v170_6), &(v166_6), &(v168_6_tail).make_space(), &(*s1));
              compose(&(v169_5),&(v170_7))
            };
            drop(v169_5);
            let v169_9: Space = intersect(&(*CONSTANT_2),&(v169_2));
            drop(v169_2);
            let v169_10: Space = if has_head(&(v169_9)) { singleton(&[]) } else { Space::new() };
            drop(v169_9);
            let v169_12: Space = if (v169_10).is_empty() { Space::new() } else {
              let v171_6: Path = concat_path(&(v166_11_head),&(v168_6_head));
              let v171_11: Space = routine_9(c, &(v171_6), &(v166_6), &(v168_6_tail).make_space(), &(*s1));
              drop(v171_6);
              compose(&(v169_10),&(v171_11))
            };
            drop(v169_10);
            let v169_13: Space = unite(&(v169_8),&(v169_12));
            v168_6.join_into((v169_13).clone());
            }
            v168_6_cursor.ascend(1);
          }
          drop(v168_6_cursor);
          compose(&(v167_5),&(v168_6))
        };
        drop(v167_5);
        let v167_8: Space = intersect(&(*CONSTANT_2),&(v167_2));
        drop(v167_2);
        let v167_9: Space = if has_head(&(v167_8)) { singleton(&[]) } else { Space::new() };
        drop(v167_8);
        let v167_11: Space = if (v167_9).is_empty() { Space::new() } else {
          let mut v172_10 = Space::new();
          let mut v172_10_cursor = (v166_11_tail).read_zipper();
          for v172_10_byte in v172_10_cursor.child_mask().iter() {
            v172_10_cursor.descend_to_byte(v172_10_byte);
            {
            let v172_10_tail = v172_10_cursor.fork_read_zipper();
            let v172_10_head = Path::from_slice(&[v172_10_byte]);
            let v173_2: Space = singleton(&(v172_10_head));
            let v173_3: Space = intersect(&(*CONSTANT_2),&(v173_2));
            let v173_4: Space = if has_head(&(v173_3)) { singleton(&[]) } else { Space::new() };
            drop(v173_3);
            let v173_5: Space = subtract(&(*CONSTANT_1),&(v173_4));
            drop(v173_4);
            let v173_8: Space = if (v173_5).is_empty() { Space::new() } else {
              let v174_6: Path = concat_path(&(v166_11_head),&(v172_10_head));
              let v174_7: Space = routine_8(c, &(v174_6), &(v166_6), &(v172_10_tail).make_space(), &(*s1));
              compose(&(v173_5),&(v174_7))
            };
            drop(v173_5);
            let v173_9: Space = intersect(&(*CONSTANT_2),&(v173_2));
            drop(v173_2);
            let v173_10: Space = if has_head(&(v173_9)) { singleton(&[]) } else { Space::new() };
            drop(v173_9);
            let v173_12: Space = if (v173_10).is_empty() { Space::new() } else {
              let v175_6: Path = concat_path(&(v166_11_head),&(v172_10_head));
              let v175_11: Space = routine_10(c, &(v175_6), &(v166_6), &(v172_10_tail).make_space(), &(*s1));
              drop(v175_6);
              compose(&(v173_10),&(v175_11))
            };
            drop(v173_10);
            let v173_13: Space = unite(&(v173_8),&(v173_12));
            v172_10.join_into((v173_13).clone());
            }
            v172_10_cursor.ascend(1);
          }
          drop(v172_10_cursor);
          compose(&(v167_9),&(v172_10))
        };
        drop(v167_9);
        let v167_12: Space = unite(&(v167_7),&(v167_11));
        v166_11.join_into((v167_12).clone());
        }
        v166_11_cursor.ascend(1);
      }
      drop(v166_11_cursor);
      drop(v166_6);
      compose(&(v155_10),&(v166_11))
    };
    drop(v155_10);
    let v155_13: Space = unite(&(v155_8),&(v155_12));
    v154_24.join_into((v155_13).clone());
    }
    v154_24_cursor.ascend(1);
  }
  drop(v154_24_cursor);
  (v154_24).clone()
}

fn routine_8(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v176_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v176_21: Space = unwrap(&(v176_20),&(*p0));
  drop(v176_20);
  let mut v176_28 = Space::new();
  let mut v176_28_cursor = (*s0).read_zipper();
  for v176_28_byte in v176_28_cursor.child_mask().iter() {
    v176_28_cursor.descend_to_byte(v176_28_byte);
    {
    let v176_28_tail = v176_28_cursor.fork_read_zipper();
    let v176_28_head = Path::from_slice(&[v176_28_byte]);
    let v177_2: Space = singleton(&(v176_28_head));
    let v177_3: Space = intersect(&(*CONSTANT_2),&(v177_2));
    let v177_4: Space = if has_head(&(v177_3)) { singleton(&[]) } else { Space::new() };
    drop(v177_3);
    let v177_5: Space = subtract(&(*CONSTANT_1),&(v177_4));
    drop(v177_4);
    let v177_8: Space = if (v177_5).is_empty() { Space::new() } else {
      let v178_6: Path = concat_path(&(*p0),&(v176_28_head));
      let mut v178_7 = Space::new();
      let mut v178_7_cursor = (v176_28_tail).read_zipper();
      for v178_7_byte in v178_7_cursor.child_mask().iter() {
        v178_7_cursor.descend_to_byte(v178_7_byte);
        {
        let v178_7_tail = v178_7_cursor.fork_read_zipper();
        let v178_7_head = Path::from_slice(&[v178_7_byte]);
        let v179_2: Space = singleton(&(v178_7_head));
        let v179_3: Space = intersect(&(*CONSTANT_2),&(v179_2));
        let v179_4: Space = if has_head(&(v179_3)) { singleton(&[]) } else { Space::new() };
        drop(v179_3);
        let v179_5: Space = subtract(&(*CONSTANT_1),&(v179_4));
        drop(v179_4);
        let v179_8: Space = if (v179_5).is_empty() { Space::new() } else {
          let v180_6: Path = concat_path(&(v178_6),&(v178_7_head));
          let mut v180_7 = Space::new();
          let mut v180_7_cursor = (v178_7_tail).read_zipper();
          for v180_7_byte in v180_7_cursor.child_mask().iter() {
            v180_7_cursor.descend_to_byte(v180_7_byte);
            {
            let v180_7_tail = v180_7_cursor.fork_read_zipper();
            let v180_7_head = Path::from_slice(&[v180_7_byte]);
            let v181_2: Space = singleton(&(v180_7_head));
            let v181_3: Space = intersect(&(*CONSTANT_2),&(v181_2));
            let v181_4: Space = if has_head(&(v181_3)) { singleton(&[]) } else { Space::new() };
            drop(v181_3);
            let v181_5: Space = subtract(&(*CONSTANT_1),&(v181_4));
            drop(v181_4);
            let v181_8: Space = if (v181_5).is_empty() { Space::new() } else {
              let v182_6: Path = concat_path(&(v180_6),&(v180_7_head));
              let v182_7: Space = routine_22(c, &(v182_6), &(*p1), &(v180_7_tail).make_space(), &(*s1));
              compose(&(v181_5),&(v182_7))
            };
            drop(v181_5);
            let v181_9: Space = intersect(&(*CONSTANT_2),&(v181_2));
            drop(v181_2);
            let v181_10: Space = if has_head(&(v181_9)) { singleton(&[]) } else { Space::new() };
            drop(v181_9);
            let v181_12: Space = if (v181_10).is_empty() { Space::new() } else {
              let v183_6: Path = concat_path(&(v180_6),&(v180_7_head));
              let v183_11: Space = routine_23(c, &(v183_6), &(*p1), &(v180_7_tail).make_space(), &(*s1));
              drop(v183_6);
              compose(&(v181_10),&(v183_11))
            };
            drop(v181_10);
            let v181_13: Space = unite(&(v181_8),&(v181_12));
            v180_7.join_into((v181_13).clone());
            }
            v180_7_cursor.ascend(1);
          }
          drop(v180_7_cursor);
          compose(&(v179_5),&(v180_7))
        };
        drop(v179_5);
        let v179_9: Space = intersect(&(*CONSTANT_2),&(v179_2));
        drop(v179_2);
        let v179_10: Space = if has_head(&(v179_9)) { singleton(&[]) } else { Space::new() };
        drop(v179_9);
        let v179_12: Space = if (v179_10).is_empty() { Space::new() } else {
          let v184_6: Path = concat_path(&(v178_6),&(v178_7_head));
          let mut v184_11 = Space::new();
          let mut v184_11_cursor = (v178_7_tail).read_zipper();
          for v184_11_byte in v184_11_cursor.child_mask().iter() {
            v184_11_cursor.descend_to_byte(v184_11_byte);
            {
            let v184_11_tail = v184_11_cursor.fork_read_zipper();
            let v184_11_head = Path::from_slice(&[v184_11_byte]);
            let v185_2: Space = singleton(&(v184_11_head));
            let v185_3: Space = intersect(&(*CONSTANT_2),&(v185_2));
            let v185_4: Space = if has_head(&(v185_3)) { singleton(&[]) } else { Space::new() };
            drop(v185_3);
            let v185_5: Space = subtract(&(*CONSTANT_1),&(v185_4));
            drop(v185_4);
            let v185_8: Space = if (v185_5).is_empty() { Space::new() } else {
              let v186_6: Path = concat_path(&(v184_6),&(v184_11_head));
              let v186_7: Space = routine_22(c, &(v186_6), &(*p1), &(v184_11_tail).make_space(), &(*s1));
              compose(&(v185_5),&(v186_7))
            };
            drop(v185_5);
            let v185_9: Space = intersect(&(*CONSTANT_2),&(v185_2));
            drop(v185_2);
            let v185_10: Space = if has_head(&(v185_9)) { singleton(&[]) } else { Space::new() };
            drop(v185_9);
            let v185_12: Space = if (v185_10).is_empty() { Space::new() } else {
              let v187_6: Path = concat_path(&(v184_6),&(v184_11_head));
              let v187_11: Space = routine_10(c, &(v187_6), &(*p1), &(v184_11_tail).make_space(), &(*s1));
              drop(v187_6);
              compose(&(v185_10),&(v187_11))
            };
            drop(v185_10);
            let v185_13: Space = unite(&(v185_8),&(v185_12));
            v184_11.join_into((v185_13).clone());
            }
            v184_11_cursor.ascend(1);
          }
          drop(v184_11_cursor);
          drop(v184_6);
          compose(&(v179_10),&(v184_11))
        };
        drop(v179_10);
        let v179_13: Space = unite(&(v179_8),&(v179_12));
        v178_7.join_into((v179_13).clone());
        }
        v178_7_cursor.ascend(1);
      }
      drop(v178_7_cursor);
      compose(&(v177_5),&(v178_7))
    };
    drop(v177_5);
    let v177_9: Space = intersect(&(*CONSTANT_2),&(v177_2));
    drop(v177_2);
    let v177_10: Space = if has_head(&(v177_9)) { singleton(&[]) } else { Space::new() };
    drop(v177_9);
    let v177_13: Space = if (v177_10).is_empty() { Space::new() } else {
      let v188_6: Path = concat_path(&(*p0),&(v176_28_head));
      let v188_11: Space = unwrap(&(v176_21),&(v176_28_head));
      let mut v188_12 = Space::new();
      let mut v188_12_cursor = (v176_28_tail).read_zipper();
      for v188_12_byte in v188_12_cursor.child_mask().iter() {
        v188_12_cursor.descend_to_byte(v188_12_byte);
        {
        let v188_12_tail = v188_12_cursor.fork_read_zipper();
        let v188_12_head = Path::from_slice(&[v188_12_byte]);
        let v189_2: Space = singleton(&(v188_12_head));
        let v189_3: Space = intersect(&(*CONSTANT_2),&(v189_2));
        let v189_4: Space = if has_head(&(v189_3)) { singleton(&[]) } else { Space::new() };
        drop(v189_3);
        let v189_5: Space = subtract(&(*CONSTANT_1),&(v189_4));
        drop(v189_4);
        let v189_8: Space = if (v189_5).is_empty() { Space::new() } else {
          let v190_6: Path = concat_path(&(v188_6),&(v188_12_head));
          let mut v190_7 = Space::new();
          let mut v190_7_cursor = (v188_12_tail).read_zipper();
          for v190_7_byte in v190_7_cursor.child_mask().iter() {
            v190_7_cursor.descend_to_byte(v190_7_byte);
            {
            let v190_7_tail = v190_7_cursor.fork_read_zipper();
            let v190_7_head = Path::from_slice(&[v190_7_byte]);
            let v191_2: Space = singleton(&(v190_7_head));
            let v191_3: Space = intersect(&(*CONSTANT_2),&(v191_2));
            let v191_4: Space = if has_head(&(v191_3)) { singleton(&[]) } else { Space::new() };
            drop(v191_3);
            let v191_5: Space = subtract(&(*CONSTANT_1),&(v191_4));
            drop(v191_4);
            let v191_8: Space = if (v191_5).is_empty() { Space::new() } else {
              let v192_6: Path = concat_path(&(v190_6),&(v190_7_head));
              let v192_7: Space = routine_22(c, &(v192_6), &(*p1), &(v190_7_tail).make_space(), &(*s1));
              compose(&(v191_5),&(v192_7))
            };
            drop(v191_5);
            let v191_9: Space = intersect(&(*CONSTANT_2),&(v191_2));
            drop(v191_2);
            let v191_10: Space = if has_head(&(v191_9)) { singleton(&[]) } else { Space::new() };
            drop(v191_9);
            let v191_12: Space = if (v191_10).is_empty() { Space::new() } else {
              let v193_6: Path = concat_path(&(v190_6),&(v190_7_head));
              let v193_11: Space = routine_23(c, &(v193_6), &(*p1), &(v190_7_tail).make_space(), &(*s1));
              drop(v193_6);
              compose(&(v191_10),&(v193_11))
            };
            drop(v191_10);
            let v191_13: Space = unite(&(v191_8),&(v191_12));
            v190_7.join_into((v191_13).clone());
            }
            v190_7_cursor.ascend(1);
          }
          drop(v190_7_cursor);
          drop(v190_6);
          compose(&(v189_5),&(v190_7))
        };
        drop(v189_5);
        let v189_9: Space = intersect(&(*CONSTANT_2),&(v189_2));
        drop(v189_2);
        let v189_10: Space = if has_head(&(v189_9)) { singleton(&[]) } else { Space::new() };
        drop(v189_9);
        let v189_13: Space = if (v189_10).is_empty() { Space::new() } else {
          let v194_11: Space = unwrap(&(v188_11),&(v188_12_head));
          let mut v194_12 = Space::new();
          let mut v194_12_cursor = (v194_11).read_zipper();
          for v194_12_byte in v194_12_cursor.child_mask().iter() {
            v194_12_cursor.descend_to_byte(v194_12_byte);
            {
            let v194_12_tail = v194_12_cursor.fork_read_zipper();
            let v194_12_head = Path::from_slice(&[v194_12_byte]);
            let v195_2: Space = singleton(&(v194_12_head));
            let v195_3: Space = intersect(&(*CONSTANT_2),&(v195_2));
            let v195_4: Space = if has_head(&(v195_3)) { singleton(&[]) } else { Space::new() };
            drop(v195_3);
            let v195_5: Space = subtract(&(*CONSTANT_1),&(v195_4));
            drop(v195_4);
            let v195_7: Space = if (v195_5).is_empty() { Space::new() } else {
              let v196_6: Space = routine_13(c, &(v194_12_head), &(*p1), &(v194_12_tail).make_space());
              compose(&(v195_5),&(v196_6))
            };
            drop(v195_5);
            let v195_8: Space = intersect(&(*CONSTANT_2),&(v195_2));
            drop(v195_2);
            let v195_9: Space = if has_head(&(v195_8)) { singleton(&[]) } else { Space::new() };
            drop(v195_8);
            let v195_11: Space = if (v195_9).is_empty() { Space::new() } else {
              let v197_10: Space = routine_14(c, &(v194_12_head), &(*p1), &(v194_12_tail).make_space());
              compose(&(v195_9),&(v197_10))
            };
            drop(v195_9);
            let v195_12: Space = unite(&(v195_7),&(v195_11));
            v194_12.join_into((v195_12).clone());
            }
            v194_12_cursor.ascend(1);
          }
          drop(v194_12_cursor);
          drop(v194_11);
          compose(&(v189_10),&(v194_12))
        };
        drop(v189_10);
        let v189_14: Space = unite(&(v189_8),&(v189_13));
        v188_12.join_into((v189_14).clone());
        }
        v188_12_cursor.ascend(1);
      }
      drop(v188_12_cursor);
      drop(v188_6);
      drop(v188_11);
      compose(&(v177_10),&(v188_12))
    };
    drop(v177_10);
    let v177_14: Space = unite(&(v177_8),&(v177_13));
    v176_28.join_into((v177_14).clone());
    }
    v176_28_cursor.ascend(1);
  }
  drop(v176_28_cursor);
  drop(v176_21);
  (v176_28).clone()
}

fn routine_9(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v198_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v198_9: Space = unwrap(&(v198_8),&(*p0));
  drop(v198_8);
  let mut v198_28 = Space::new();
  let mut v198_28_cursor = (*s0).read_zipper();
  for v198_28_byte in v198_28_cursor.child_mask().iter() {
    v198_28_cursor.descend_to_byte(v198_28_byte);
    {
    let v198_28_tail = v198_28_cursor.fork_read_zipper();
    let v198_28_head = Path::from_slice(&[v198_28_byte]);
    let v199_2: Space = singleton(&(v198_28_head));
    let v199_3: Space = intersect(&(*CONSTANT_2),&(v199_2));
    let v199_4: Space = if has_head(&(v199_3)) { singleton(&[]) } else { Space::new() };
    drop(v199_3);
    let v199_5: Space = subtract(&(*CONSTANT_1),&(v199_4));
    drop(v199_4);
    let v199_8: Space = if (v199_5).is_empty() { Space::new() } else {
      let v200_6: Path = concat_path(&(*p0),&(v198_28_head));
      let mut v200_7 = Space::new();
      let mut v200_7_cursor = (v198_28_tail).read_zipper();
      for v200_7_byte in v200_7_cursor.child_mask().iter() {
        v200_7_cursor.descend_to_byte(v200_7_byte);
        {
        let v200_7_tail = v200_7_cursor.fork_read_zipper();
        let v200_7_head = Path::from_slice(&[v200_7_byte]);
        let v201_2: Space = singleton(&(v200_7_head));
        let v201_3: Space = intersect(&(*CONSTANT_2),&(v201_2));
        let v201_4: Space = if has_head(&(v201_3)) { singleton(&[]) } else { Space::new() };
        drop(v201_3);
        let v201_5: Space = subtract(&(*CONSTANT_1),&(v201_4));
        drop(v201_4);
        let v201_8: Space = if (v201_5).is_empty() { Space::new() } else {
          let v202_6: Path = concat_path(&(v200_6),&(v200_7_head));
          let mut v202_7 = Space::new();
          let mut v202_7_cursor = (v200_7_tail).read_zipper();
          for v202_7_byte in v202_7_cursor.child_mask().iter() {
            v202_7_cursor.descend_to_byte(v202_7_byte);
            {
            let v202_7_tail = v202_7_cursor.fork_read_zipper();
            let v202_7_head = Path::from_slice(&[v202_7_byte]);
            let v203_2: Space = singleton(&(v202_7_head));
            let v203_3: Space = intersect(&(*CONSTANT_2),&(v203_2));
            let v203_4: Space = if has_head(&(v203_3)) { singleton(&[]) } else { Space::new() };
            drop(v203_3);
            let v203_5: Space = subtract(&(*CONSTANT_1),&(v203_4));
            drop(v203_4);
            let v203_8: Space = if (v203_5).is_empty() { Space::new() } else {
              let v204_6: Path = concat_path(&(v202_6),&(v202_7_head));
              let v204_7: Space = routine_22(c, &(v204_6), &(*p1), &(v202_7_tail).make_space(), &(*s1));
              compose(&(v203_5),&(v204_7))
            };
            drop(v203_5);
            let v203_9: Space = intersect(&(*CONSTANT_2),&(v203_2));
            drop(v203_2);
            let v203_10: Space = if has_head(&(v203_9)) { singleton(&[]) } else { Space::new() };
            drop(v203_9);
            let v203_12: Space = if (v203_10).is_empty() { Space::new() } else {
              let v205_6: Path = concat_path(&(v202_6),&(v202_7_head));
              let v205_11: Space = routine_23(c, &(v205_6), &(*p1), &(v202_7_tail).make_space(), &(*s1));
              drop(v205_6);
              compose(&(v203_10),&(v205_11))
            };
            drop(v203_10);
            let v203_13: Space = unite(&(v203_8),&(v203_12));
            v202_7.join_into((v203_13).clone());
            }
            v202_7_cursor.ascend(1);
          }
          drop(v202_7_cursor);
          compose(&(v201_5),&(v202_7))
        };
        drop(v201_5);
        let v201_9: Space = intersect(&(*CONSTANT_2),&(v201_2));
        drop(v201_2);
        let v201_10: Space = if has_head(&(v201_9)) { singleton(&[]) } else { Space::new() };
        drop(v201_9);
        let v201_12: Space = if (v201_10).is_empty() { Space::new() } else {
          let v206_6: Path = concat_path(&(v200_6),&(v200_7_head));
          let mut v206_11 = Space::new();
          let mut v206_11_cursor = (v200_7_tail).read_zipper();
          for v206_11_byte in v206_11_cursor.child_mask().iter() {
            v206_11_cursor.descend_to_byte(v206_11_byte);
            {
            let v206_11_tail = v206_11_cursor.fork_read_zipper();
            let v206_11_head = Path::from_slice(&[v206_11_byte]);
            let v207_2: Space = singleton(&(v206_11_head));
            let v207_3: Space = intersect(&(*CONSTANT_2),&(v207_2));
            let v207_4: Space = if has_head(&(v207_3)) { singleton(&[]) } else { Space::new() };
            drop(v207_3);
            let v207_5: Space = subtract(&(*CONSTANT_1),&(v207_4));
            drop(v207_4);
            let v207_8: Space = if (v207_5).is_empty() { Space::new() } else {
              let v208_6: Path = concat_path(&(v206_6),&(v206_11_head));
              let v208_7: Space = routine_22(c, &(v208_6), &(*p1), &(v206_11_tail).make_space(), &(*s1));
              compose(&(v207_5),&(v208_7))
            };
            drop(v207_5);
            let v207_9: Space = intersect(&(*CONSTANT_2),&(v207_2));
            drop(v207_2);
            let v207_10: Space = if has_head(&(v207_9)) { singleton(&[]) } else { Space::new() };
            drop(v207_9);
            let v207_12: Space = if (v207_10).is_empty() { Space::new() } else {
              let v209_6: Path = concat_path(&(v206_6),&(v206_11_head));
              let v209_11: Space = routine_10(c, &(v209_6), &(*p1), &(v206_11_tail).make_space(), &(*s1));
              drop(v209_6);
              compose(&(v207_10),&(v209_11))
            };
            drop(v207_10);
            let v207_13: Space = unite(&(v207_8),&(v207_12));
            v206_11.join_into((v207_13).clone());
            }
            v206_11_cursor.ascend(1);
          }
          drop(v206_11_cursor);
          drop(v206_6);
          compose(&(v201_10),&(v206_11))
        };
        drop(v201_10);
        let v201_13: Space = unite(&(v201_8),&(v201_12));
        v200_7.join_into((v201_13).clone());
        }
        v200_7_cursor.ascend(1);
      }
      drop(v200_7_cursor);
      drop(v200_6);
      compose(&(v199_5),&(v200_7))
    };
    drop(v199_5);
    let v199_9: Space = intersect(&(*CONSTANT_2),&(v199_2));
    drop(v199_2);
    let v199_10: Space = if has_head(&(v199_9)) { singleton(&[]) } else { Space::new() };
    drop(v199_9);
    let v199_13: Space = if (v199_10).is_empty() { Space::new() } else {
      let v210_11: Space = unwrap(&(v198_9),&(v198_28_head));
      let mut v210_12 = Space::new();
      let mut v210_12_cursor = (v210_11).read_zipper();
      for v210_12_byte in v210_12_cursor.child_mask().iter() {
        v210_12_cursor.descend_to_byte(v210_12_byte);
        {
        let v210_12_tail = v210_12_cursor.fork_read_zipper();
        let v210_12_head = Path::from_slice(&[v210_12_byte]);
        let v211_2: Space = singleton(&(v210_12_head));
        let v211_3: Space = intersect(&(*CONSTANT_2),&(v211_2));
        let v211_4: Space = if has_head(&(v211_3)) { singleton(&[]) } else { Space::new() };
        drop(v211_3);
        let v211_5: Space = subtract(&(*CONSTANT_1),&(v211_4));
        drop(v211_4);
        let v211_7: Space = if (v211_5).is_empty() { Space::new() } else {
          let mut v212_6 = Space::new();
          let mut v212_6_cursor = (v210_12_tail).read_zipper();
          for v212_6_byte in v212_6_cursor.child_mask().iter() {
            v212_6_cursor.descend_to_byte(v212_6_byte);
            {
            let v212_6_tail = v212_6_cursor.fork_read_zipper();
            let v212_6_head = Path::from_slice(&[v212_6_byte]);
            let v213_2: Space = singleton(&(v212_6_head));
            let v213_3: Space = intersect(&(*CONSTANT_2),&(v213_2));
            let v213_4: Space = if has_head(&(v213_3)) { singleton(&[]) } else { Space::new() };
            drop(v213_3);
            let v213_5: Space = subtract(&(*CONSTANT_1),&(v213_4));
            drop(v213_4);
            let v213_8: Space = if (v213_5).is_empty() { Space::new() } else {
              let v214_6: Path = concat_path(&(v210_12_head),&(v212_6_head));
              let v214_7: Space = routine_17(c, &(v214_6), &(*p1), &(v212_6_tail).make_space());
              compose(&(v213_5),&(v214_7))
            };
            drop(v213_5);
            let v213_9: Space = intersect(&(*CONSTANT_2),&(v213_2));
            drop(v213_2);
            let v213_10: Space = if has_head(&(v213_9)) { singleton(&[]) } else { Space::new() };
            drop(v213_9);
            let v213_12: Space = if (v213_10).is_empty() { Space::new() } else {
              let v215_6: Path = concat_path(&(v210_12_head),&(v212_6_head));
              let v215_11: Space = routine_18(c, &(v215_6), &(*p1), &(v212_6_tail).make_space());
              drop(v215_6);
              compose(&(v213_10),&(v215_11))
            };
            drop(v213_10);
            let v213_13: Space = unite(&(v213_8),&(v213_12));
            v212_6.join_into((v213_13).clone());
            }
            v212_6_cursor.ascend(1);
          }
          drop(v212_6_cursor);
          compose(&(v211_5),&(v212_6))
        };
        drop(v211_5);
        let v211_8: Space = intersect(&(*CONSTANT_2),&(v211_2));
        drop(v211_2);
        let v211_9: Space = if has_head(&(v211_8)) { singleton(&[]) } else { Space::new() };
        drop(v211_8);
        let v211_11: Space = if (v211_9).is_empty() { Space::new() } else {
          let mut v216_10 = Space::new();
          let mut v216_10_cursor = (v210_12_tail).read_zipper();
          for v216_10_byte in v216_10_cursor.child_mask().iter() {
            v216_10_cursor.descend_to_byte(v216_10_byte);
            {
            let v216_10_tail = v216_10_cursor.fork_read_zipper();
            let v216_10_head = Path::from_slice(&[v216_10_byte]);
            let v217_2: Space = singleton(&(v216_10_head));
            let v217_3: Space = intersect(&(*CONSTANT_2),&(v217_2));
            let v217_4: Space = if has_head(&(v217_3)) { singleton(&[]) } else { Space::new() };
            drop(v217_3);
            let v217_5: Space = subtract(&(*CONSTANT_1),&(v217_4));
            drop(v217_4);
            let v217_8: Space = if (v217_5).is_empty() { Space::new() } else {
              let v218_6: Path = concat_path(&(v210_12_head),&(v216_10_head));
              let v218_7: Space = routine_17(c, &(v218_6), &(*p1), &(v216_10_tail).make_space());
              compose(&(v217_5),&(v218_7))
            };
            drop(v217_5);
            let v217_9: Space = intersect(&(*CONSTANT_2),&(v217_2));
            drop(v217_2);
            let v217_10: Space = if has_head(&(v217_9)) { singleton(&[]) } else { Space::new() };
            drop(v217_9);
            let v217_12: Space = if (v217_10).is_empty() { Space::new() } else {
              let v219_6: Path = concat_path(&(v210_12_head),&(v216_10_head));
              let v219_11: Space = routine_19(c, &(v219_6), &(*p1), &(v216_10_tail).make_space());
              drop(v219_6);
              compose(&(v217_10),&(v219_11))
            };
            drop(v217_10);
            let v217_13: Space = unite(&(v217_8),&(v217_12));
            v216_10.join_into((v217_13).clone());
            }
            v216_10_cursor.ascend(1);
          }
          drop(v216_10_cursor);
          compose(&(v211_9),&(v216_10))
        };
        drop(v211_9);
        let v211_12: Space = unite(&(v211_7),&(v211_11));
        v210_12.join_into((v211_12).clone());
        }
        v210_12_cursor.ascend(1);
      }
      drop(v210_12_cursor);
      drop(v210_11);
      compose(&(v199_10),&(v210_12))
    };
    drop(v199_10);
    let v199_14: Space = unite(&(v199_8),&(v199_13));
    v198_28.join_into((v199_14).clone());
    }
    v198_28_cursor.ascend(1);
  }
  drop(v198_28_cursor);
  drop(v198_9);
  (v198_28).clone()
}

fn routine_10(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v220_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v220_6: Space = unwrap(&(v220_5),&(*p0));
  drop(v220_5);
  let mut v220_25 = Space::new();
  let mut v220_25_cursor = (v220_6).read_zipper();
  for v220_25_byte in v220_25_cursor.child_mask().iter() {
    v220_25_cursor.descend_to_byte(v220_25_byte);
    {
    let v220_25_tail = v220_25_cursor.fork_read_zipper();
    let v220_25_head = Path::from_slice(&[v220_25_byte]);
    let v221_2: Space = singleton(&(v220_25_head));
    let v221_3: Space = intersect(&(*CONSTANT_2),&(v221_2));
    let v221_4: Space = if has_head(&(v221_3)) { singleton(&[]) } else { Space::new() };
    drop(v221_3);
    let v221_5: Space = subtract(&(*CONSTANT_1),&(v221_4));
    drop(v221_4);
    let v221_7: Space = if (v221_5).is_empty() { Space::new() } else {
      let mut v222_6 = Space::new();
      let mut v222_6_cursor = (v220_25_tail).read_zipper();
      for v222_6_byte in v222_6_cursor.child_mask().iter() {
        v222_6_cursor.descend_to_byte(v222_6_byte);
        {
        let v222_6_tail = v222_6_cursor.fork_read_zipper();
        let v222_6_head = Path::from_slice(&[v222_6_byte]);
        let v223_2: Space = singleton(&(v222_6_head));
        let v223_3: Space = intersect(&(*CONSTANT_2),&(v223_2));
        let v223_4: Space = if has_head(&(v223_3)) { singleton(&[]) } else { Space::new() };
        drop(v223_3);
        let v223_5: Space = subtract(&(*CONSTANT_1),&(v223_4));
        drop(v223_4);
        let v223_8: Space = if (v223_5).is_empty() { Space::new() } else {
          let v224_6: Path = concat_path(&(v220_25_head),&(v222_6_head));
          let mut v224_7 = Space::new();
          let mut v224_7_cursor = (v222_6_tail).read_zipper();
          for v224_7_byte in v224_7_cursor.child_mask().iter() {
            v224_7_cursor.descend_to_byte(v224_7_byte);
            {
            let v224_7_tail = v224_7_cursor.fork_read_zipper();
            let v224_7_head = Path::from_slice(&[v224_7_byte]);
            let v225_2: Space = singleton(&(v224_7_head));
            let v225_3: Space = intersect(&(*CONSTANT_2),&(v225_2));
            let v225_4: Space = if has_head(&(v225_3)) { singleton(&[]) } else { Space::new() };
            drop(v225_3);
            let v225_5: Space = subtract(&(*CONSTANT_1),&(v225_4));
            drop(v225_4);
            let v225_8: Space = if (v225_5).is_empty() { Space::new() } else {
              let v226_6: Path = concat_path(&(v224_6),&(v224_7_head));
              let v226_7: Space = routine_24(c, &(v226_6), &(*p1), &(v224_7_tail).make_space());
              compose(&(v225_5),&(v226_7))
            };
            drop(v225_5);
            let v225_9: Space = intersect(&(*CONSTANT_2),&(v225_2));
            drop(v225_2);
            let v225_10: Space = if has_head(&(v225_9)) { singleton(&[]) } else { Space::new() };
            drop(v225_9);
            let v225_12: Space = if (v225_10).is_empty() { Space::new() } else {
              let v227_6: Path = concat_path(&(v224_6),&(v224_7_head));
              let v227_11: Space = routine_25(c, &(v227_6), &(*p1), &(v224_7_tail).make_space());
              drop(v227_6);
              compose(&(v225_10),&(v227_11))
            };
            drop(v225_10);
            let v225_13: Space = unite(&(v225_8),&(v225_12));
            v224_7.join_into((v225_13).clone());
            }
            v224_7_cursor.ascend(1);
          }
          drop(v224_7_cursor);
          compose(&(v223_5),&(v224_7))
        };
        drop(v223_5);
        let v223_9: Space = intersect(&(*CONSTANT_2),&(v223_2));
        drop(v223_2);
        let v223_10: Space = if has_head(&(v223_9)) { singleton(&[]) } else { Space::new() };
        drop(v223_9);
        let v223_12: Space = if (v223_10).is_empty() { Space::new() } else {
          let v228_6: Path = concat_path(&(v220_25_head),&(v222_6_head));
          let mut v228_11 = Space::new();
          let mut v228_11_cursor = (v222_6_tail).read_zipper();
          for v228_11_byte in v228_11_cursor.child_mask().iter() {
            v228_11_cursor.descend_to_byte(v228_11_byte);
            {
            let v228_11_tail = v228_11_cursor.fork_read_zipper();
            let v228_11_head = Path::from_slice(&[v228_11_byte]);
            let v229_2: Space = singleton(&(v228_11_head));
            let v229_3: Space = intersect(&(*CONSTANT_2),&(v229_2));
            let v229_4: Space = if has_head(&(v229_3)) { singleton(&[]) } else { Space::new() };
            drop(v229_3);
            let v229_5: Space = subtract(&(*CONSTANT_1),&(v229_4));
            drop(v229_4);
            let v229_8: Space = if (v229_5).is_empty() { Space::new() } else {
              let v230_6: Path = concat_path(&(v228_6),&(v228_11_head));
              let v230_7: Space = routine_24(c, &(v230_6), &(*p1), &(v228_11_tail).make_space());
              compose(&(v229_5),&(v230_7))
            };
            drop(v229_5);
            let v229_9: Space = intersect(&(*CONSTANT_2),&(v229_2));
            drop(v229_2);
            let v229_10: Space = if has_head(&(v229_9)) { singleton(&[]) } else { Space::new() };
            drop(v229_9);
            let v229_12: Space = if (v229_10).is_empty() { Space::new() } else {
              let v231_6: Path = concat_path(&(v228_6),&(v228_11_head));
              let v231_11: Space = routine_19(c, &(v231_6), &(*p1), &(v228_11_tail).make_space());
              drop(v231_6);
              compose(&(v229_10),&(v231_11))
            };
            drop(v229_10);
            let v229_13: Space = unite(&(v229_8),&(v229_12));
            v228_11.join_into((v229_13).clone());
            }
            v228_11_cursor.ascend(1);
          }
          drop(v228_11_cursor);
          drop(v228_6);
          compose(&(v223_10),&(v228_11))
        };
        drop(v223_10);
        let v223_13: Space = unite(&(v223_8),&(v223_12));
        v222_6.join_into((v223_13).clone());
        }
        v222_6_cursor.ascend(1);
      }
      drop(v222_6_cursor);
      compose(&(v221_5),&(v222_6))
    };
    drop(v221_5);
    let v221_8: Space = intersect(&(*CONSTANT_2),&(v221_2));
    drop(v221_2);
    let v221_9: Space = if has_head(&(v221_8)) { singleton(&[]) } else { Space::new() };
    drop(v221_8);
    let v221_11: Space = if (v221_9).is_empty() { Space::new() } else {
      let mut v232_10 = Space::new();
      let mut v232_10_cursor = (v220_25_tail).read_zipper();
      for v232_10_byte in v232_10_cursor.child_mask().iter() {
        v232_10_cursor.descend_to_byte(v232_10_byte);
        {
        let v232_10_tail = v232_10_cursor.fork_read_zipper();
        let v232_10_head = Path::from_slice(&[v232_10_byte]);
        let v233_2: Space = singleton(&(v232_10_head));
        let v233_3: Space = intersect(&(*CONSTANT_2),&(v233_2));
        let v233_4: Space = if has_head(&(v233_3)) { singleton(&[]) } else { Space::new() };
        drop(v233_3);
        let v233_5: Space = subtract(&(*CONSTANT_1),&(v233_4));
        drop(v233_4);
        let v233_8: Space = if (v233_5).is_empty() { Space::new() } else {
          let v234_6: Path = concat_path(&(v220_25_head),&(v232_10_head));
          let mut v234_7 = Space::new();
          let mut v234_7_cursor = (v232_10_tail).read_zipper();
          for v234_7_byte in v234_7_cursor.child_mask().iter() {
            v234_7_cursor.descend_to_byte(v234_7_byte);
            {
            let v234_7_tail = v234_7_cursor.fork_read_zipper();
            let v234_7_head = Path::from_slice(&[v234_7_byte]);
            let v235_2: Space = singleton(&(v234_7_head));
            let v235_3: Space = intersect(&(*CONSTANT_2),&(v235_2));
            let v235_4: Space = if has_head(&(v235_3)) { singleton(&[]) } else { Space::new() };
            drop(v235_3);
            let v235_5: Space = subtract(&(*CONSTANT_1),&(v235_4));
            drop(v235_4);
            let v235_8: Space = if (v235_5).is_empty() { Space::new() } else {
              let v236_6: Path = concat_path(&(v234_6),&(v234_7_head));
              let v236_7: Space = routine_24(c, &(v236_6), &(*p1), &(v234_7_tail).make_space());
              compose(&(v235_5),&(v236_7))
            };
            drop(v235_5);
            let v235_9: Space = intersect(&(*CONSTANT_2),&(v235_2));
            drop(v235_2);
            let v235_10: Space = if has_head(&(v235_9)) { singleton(&[]) } else { Space::new() };
            drop(v235_9);
            let v235_12: Space = if (v235_10).is_empty() { Space::new() } else {
              let v237_6: Path = concat_path(&(v234_6),&(v234_7_head));
              let v237_11: Space = routine_25(c, &(v237_6), &(*p1), &(v234_7_tail).make_space());
              drop(v237_6);
              compose(&(v235_10),&(v237_11))
            };
            drop(v235_10);
            let v235_13: Space = unite(&(v235_8),&(v235_12));
            v234_7.join_into((v235_13).clone());
            }
            v234_7_cursor.ascend(1);
          }
          drop(v234_7_cursor);
          compose(&(v233_5),&(v234_7))
        };
        drop(v233_5);
        let v233_9: Space = intersect(&(*CONSTANT_2),&(v233_2));
        drop(v233_2);
        let v233_10: Space = if has_head(&(v233_9)) { singleton(&[]) } else { Space::new() };
        drop(v233_9);
        let v233_11: Space = compose(&(v233_10),&(v232_10_tail));
        drop(v233_10);
        let v238_6: Path = concat_path(&(v220_25_head),&(v232_10_head));
        let v233_12: Space = wrap(&(v233_11),&(v238_6));
        drop(v233_11);
        let v233_13: Space = wrap(&(v233_12),&(*p1));
        drop(v233_12);
        let v233_14: Space = unite(&(v233_8),&(v233_13));
        drop(v233_13);
        v232_10.join_into((v233_14).clone());
        }
        v232_10_cursor.ascend(1);
      }
      drop(v232_10_cursor);
      compose(&(v221_9),&(v232_10))
    };
    drop(v221_9);
    let v221_12: Space = unite(&(v221_7),&(v221_11));
    v220_25.join_into((v221_12).clone());
    }
    v220_25_cursor.ascend(1);
  }
  drop(v220_25_cursor);
  drop(v220_6);
  (v220_25).clone()
}

fn routine_11(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v239_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v239_21: Space = unwrap(&(v239_20),&(*p0));
  drop(v239_20);
  let mut v239_28 = Space::new();
  let mut v239_28_cursor = (*s0).read_zipper();
  for v239_28_byte in v239_28_cursor.child_mask().iter() {
    v239_28_cursor.descend_to_byte(v239_28_byte);
    {
    let v239_28_tail = v239_28_cursor.fork_read_zipper();
    let v239_28_head = Path::from_slice(&[v239_28_byte]);
    let v240_2: Space = singleton(&(v239_28_head));
    let v240_3: Space = intersect(&(*CONSTANT_2),&(v240_2));
    let v240_4: Space = if has_head(&(v240_3)) { singleton(&[]) } else { Space::new() };
    drop(v240_3);
    let v240_5: Space = subtract(&(*CONSTANT_1),&(v240_4));
    drop(v240_4);
    let v240_8: Space = if (v240_5).is_empty() { Space::new() } else {
      let v241_6: Path = concat_path(&(*p0),&(v239_28_head));
      let mut v241_7 = Space::new();
      let mut v241_7_cursor = (v239_28_tail).read_zipper();
      for v241_7_byte in v241_7_cursor.child_mask().iter() {
        v241_7_cursor.descend_to_byte(v241_7_byte);
        {
        let v241_7_tail = v241_7_cursor.fork_read_zipper();
        let v241_7_head = Path::from_slice(&[v241_7_byte]);
        let v242_2: Space = singleton(&(v241_7_head));
        let v242_3: Space = intersect(&(*CONSTANT_2),&(v242_2));
        let v242_4: Space = if has_head(&(v242_3)) { singleton(&[]) } else { Space::new() };
        drop(v242_3);
        let v242_5: Space = subtract(&(*CONSTANT_1),&(v242_4));
        drop(v242_4);
        let v242_8: Space = if (v242_5).is_empty() { Space::new() } else {
          let v243_6: Path = concat_path(&(v241_6),&(v241_7_head));
          let mut v243_7 = Space::new();
          let mut v243_7_cursor = (v241_7_tail).read_zipper();
          for v243_7_byte in v243_7_cursor.child_mask().iter() {
            v243_7_cursor.descend_to_byte(v243_7_byte);
            {
            let v243_7_tail = v243_7_cursor.fork_read_zipper();
            let v243_7_head = Path::from_slice(&[v243_7_byte]);
            let v244_2: Space = singleton(&(v243_7_head));
            let v244_3: Space = intersect(&(*CONSTANT_2),&(v244_2));
            let v244_4: Space = if has_head(&(v244_3)) { singleton(&[]) } else { Space::new() };
            drop(v244_3);
            let v244_5: Space = subtract(&(*CONSTANT_1),&(v244_4));
            drop(v244_4);
            let v244_8: Space = if (v244_5).is_empty() { Space::new() } else {
              let v245_6: Path = concat_path(&(v243_6),&(v243_7_head));
              let v245_7: Space = routine_26(c, &(v245_6), &(*p1), &(v243_7_tail).make_space(), &(*s1));
              compose(&(v244_5),&(v245_7))
            };
            drop(v244_5);
            let v244_9: Space = intersect(&(*CONSTANT_2),&(v244_2));
            drop(v244_2);
            let v244_10: Space = if has_head(&(v244_9)) { singleton(&[]) } else { Space::new() };
            drop(v244_9);
            let v244_12: Space = if (v244_10).is_empty() { Space::new() } else {
              let v246_6: Path = concat_path(&(v243_6),&(v243_7_head));
              let v246_11: Space = routine_27(c, &(v246_6), &(*p1), &(v243_7_tail).make_space(), &(*s1));
              drop(v246_6);
              compose(&(v244_10),&(v246_11))
            };
            drop(v244_10);
            let v244_13: Space = unite(&(v244_8),&(v244_12));
            v243_7.join_into((v244_13).clone());
            }
            v243_7_cursor.ascend(1);
          }
          drop(v243_7_cursor);
          compose(&(v242_5),&(v243_7))
        };
        drop(v242_5);
        let v242_9: Space = intersect(&(*CONSTANT_2),&(v242_2));
        drop(v242_2);
        let v242_10: Space = if has_head(&(v242_9)) { singleton(&[]) } else { Space::new() };
        drop(v242_9);
        let v242_12: Space = if (v242_10).is_empty() { Space::new() } else {
          let v247_6: Path = concat_path(&(v241_6),&(v241_7_head));
          let mut v247_11 = Space::new();
          let mut v247_11_cursor = (v241_7_tail).read_zipper();
          for v247_11_byte in v247_11_cursor.child_mask().iter() {
            v247_11_cursor.descend_to_byte(v247_11_byte);
            {
            let v247_11_tail = v247_11_cursor.fork_read_zipper();
            let v247_11_head = Path::from_slice(&[v247_11_byte]);
            let v248_2: Space = singleton(&(v247_11_head));
            let v248_3: Space = intersect(&(*CONSTANT_2),&(v248_2));
            let v248_4: Space = if has_head(&(v248_3)) { singleton(&[]) } else { Space::new() };
            drop(v248_3);
            let v248_5: Space = subtract(&(*CONSTANT_1),&(v248_4));
            drop(v248_4);
            let v248_8: Space = if (v248_5).is_empty() { Space::new() } else {
              let v249_6: Path = concat_path(&(v247_6),&(v247_11_head));
              let v249_7: Space = routine_26(c, &(v249_6), &(*p1), &(v247_11_tail).make_space(), &(*s1));
              compose(&(v248_5),&(v249_7))
            };
            drop(v248_5);
            let v248_9: Space = intersect(&(*CONSTANT_2),&(v248_2));
            drop(v248_2);
            let v248_10: Space = if has_head(&(v248_9)) { singleton(&[]) } else { Space::new() };
            drop(v248_9);
            let v248_12: Space = if (v248_10).is_empty() { Space::new() } else {
              let v250_6: Path = concat_path(&(v247_6),&(v247_11_head));
              let v250_11: Space = routine_10(c, &(v250_6), &(*p1), &(v247_11_tail).make_space(), &(*s1));
              drop(v250_6);
              compose(&(v248_10),&(v250_11))
            };
            drop(v248_10);
            let v248_13: Space = unite(&(v248_8),&(v248_12));
            v247_11.join_into((v248_13).clone());
            }
            v247_11_cursor.ascend(1);
          }
          drop(v247_11_cursor);
          drop(v247_6);
          compose(&(v242_10),&(v247_11))
        };
        drop(v242_10);
        let v242_13: Space = unite(&(v242_8),&(v242_12));
        v241_7.join_into((v242_13).clone());
        }
        v241_7_cursor.ascend(1);
      }
      drop(v241_7_cursor);
      compose(&(v240_5),&(v241_7))
    };
    drop(v240_5);
    let v240_9: Space = intersect(&(*CONSTANT_2),&(v240_2));
    drop(v240_2);
    let v240_10: Space = if has_head(&(v240_9)) { singleton(&[]) } else { Space::new() };
    drop(v240_9);
    let v240_13: Space = if (v240_10).is_empty() { Space::new() } else {
      let v251_6: Path = concat_path(&(*p0),&(v239_28_head));
      let v251_11: Space = unwrap(&(v239_21),&(v239_28_head));
      let mut v251_12 = Space::new();
      let mut v251_12_cursor = (v239_28_tail).read_zipper();
      for v251_12_byte in v251_12_cursor.child_mask().iter() {
        v251_12_cursor.descend_to_byte(v251_12_byte);
        {
        let v251_12_tail = v251_12_cursor.fork_read_zipper();
        let v251_12_head = Path::from_slice(&[v251_12_byte]);
        let v252_2: Space = singleton(&(v251_12_head));
        let v252_3: Space = intersect(&(*CONSTANT_2),&(v252_2));
        let v252_4: Space = if has_head(&(v252_3)) { singleton(&[]) } else { Space::new() };
        drop(v252_3);
        let v252_5: Space = subtract(&(*CONSTANT_1),&(v252_4));
        drop(v252_4);
        let v252_8: Space = if (v252_5).is_empty() { Space::new() } else {
          let v253_6: Path = concat_path(&(v251_6),&(v251_12_head));
          let mut v253_7 = Space::new();
          let mut v253_7_cursor = (v251_12_tail).read_zipper();
          for v253_7_byte in v253_7_cursor.child_mask().iter() {
            v253_7_cursor.descend_to_byte(v253_7_byte);
            {
            let v253_7_tail = v253_7_cursor.fork_read_zipper();
            let v253_7_head = Path::from_slice(&[v253_7_byte]);
            let v254_2: Space = singleton(&(v253_7_head));
            let v254_3: Space = intersect(&(*CONSTANT_2),&(v254_2));
            let v254_4: Space = if has_head(&(v254_3)) { singleton(&[]) } else { Space::new() };
            drop(v254_3);
            let v254_5: Space = subtract(&(*CONSTANT_1),&(v254_4));
            drop(v254_4);
            let v254_8: Space = if (v254_5).is_empty() { Space::new() } else {
              let v255_6: Path = concat_path(&(v253_6),&(v253_7_head));
              let v255_7: Space = routine_26(c, &(v255_6), &(*p1), &(v253_7_tail).make_space(), &(*s1));
              compose(&(v254_5),&(v255_7))
            };
            drop(v254_5);
            let v254_9: Space = intersect(&(*CONSTANT_2),&(v254_2));
            drop(v254_2);
            let v254_10: Space = if has_head(&(v254_9)) { singleton(&[]) } else { Space::new() };
            drop(v254_9);
            let v254_12: Space = if (v254_10).is_empty() { Space::new() } else {
              let v256_6: Path = concat_path(&(v253_6),&(v253_7_head));
              let v256_11: Space = routine_27(c, &(v256_6), &(*p1), &(v253_7_tail).make_space(), &(*s1));
              drop(v256_6);
              compose(&(v254_10),&(v256_11))
            };
            drop(v254_10);
            let v254_13: Space = unite(&(v254_8),&(v254_12));
            v253_7.join_into((v254_13).clone());
            }
            v253_7_cursor.ascend(1);
          }
          drop(v253_7_cursor);
          drop(v253_6);
          compose(&(v252_5),&(v253_7))
        };
        drop(v252_5);
        let v252_9: Space = intersect(&(*CONSTANT_2),&(v252_2));
        drop(v252_2);
        let v252_10: Space = if has_head(&(v252_9)) { singleton(&[]) } else { Space::new() };
        drop(v252_9);
        let v252_13: Space = if (v252_10).is_empty() { Space::new() } else {
          let v257_11: Space = unwrap(&(v251_11),&(v251_12_head));
          let mut v257_12 = Space::new();
          let mut v257_12_cursor = (v257_11).read_zipper();
          for v257_12_byte in v257_12_cursor.child_mask().iter() {
            v257_12_cursor.descend_to_byte(v257_12_byte);
            {
            let v257_12_tail = v257_12_cursor.fork_read_zipper();
            let v257_12_head = Path::from_slice(&[v257_12_byte]);
            let v258_2: Space = singleton(&(v257_12_head));
            let v258_3: Space = intersect(&(*CONSTANT_2),&(v258_2));
            let v258_4: Space = if has_head(&(v258_3)) { singleton(&[]) } else { Space::new() };
            drop(v258_3);
            let v258_5: Space = subtract(&(*CONSTANT_1),&(v258_4));
            drop(v258_4);
            let v258_7: Space = if (v258_5).is_empty() { Space::new() } else {
              let v259_6: Space = routine_13(c, &(v257_12_head), &(*p1), &(v257_12_tail).make_space());
              compose(&(v258_5),&(v259_6))
            };
            drop(v258_5);
            let v258_8: Space = intersect(&(*CONSTANT_2),&(v258_2));
            drop(v258_2);
            let v258_9: Space = if has_head(&(v258_8)) { singleton(&[]) } else { Space::new() };
            drop(v258_8);
            let v258_11: Space = if (v258_9).is_empty() { Space::new() } else {
              let v260_10: Space = routine_14(c, &(v257_12_head), &(*p1), &(v257_12_tail).make_space());
              compose(&(v258_9),&(v260_10))
            };
            drop(v258_9);
            let v258_12: Space = unite(&(v258_7),&(v258_11));
            v257_12.join_into((v258_12).clone());
            }
            v257_12_cursor.ascend(1);
          }
          drop(v257_12_cursor);
          drop(v257_11);
          compose(&(v252_10),&(v257_12))
        };
        drop(v252_10);
        let v252_14: Space = unite(&(v252_8),&(v252_13));
        v251_12.join_into((v252_14).clone());
        }
        v251_12_cursor.ascend(1);
      }
      drop(v251_12_cursor);
      drop(v251_6);
      drop(v251_11);
      compose(&(v240_10),&(v251_12))
    };
    drop(v240_10);
    let v240_14: Space = unite(&(v240_8),&(v240_13));
    v239_28.join_into((v240_14).clone());
    }
    v239_28_cursor.ascend(1);
  }
  drop(v239_28_cursor);
  drop(v239_21);
  (v239_28).clone()
}

fn routine_12(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v261_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v261_9: Space = unwrap(&(v261_8),&(*p0));
  drop(v261_8);
  let mut v261_28 = Space::new();
  let mut v261_28_cursor = (*s0).read_zipper();
  for v261_28_byte in v261_28_cursor.child_mask().iter() {
    v261_28_cursor.descend_to_byte(v261_28_byte);
    {
    let v261_28_tail = v261_28_cursor.fork_read_zipper();
    let v261_28_head = Path::from_slice(&[v261_28_byte]);
    let v262_2: Space = singleton(&(v261_28_head));
    let v262_3: Space = intersect(&(*CONSTANT_2),&(v262_2));
    let v262_4: Space = if has_head(&(v262_3)) { singleton(&[]) } else { Space::new() };
    drop(v262_3);
    let v262_5: Space = subtract(&(*CONSTANT_1),&(v262_4));
    drop(v262_4);
    let v262_8: Space = if (v262_5).is_empty() { Space::new() } else {
      let v263_6: Path = concat_path(&(*p0),&(v261_28_head));
      let mut v263_7 = Space::new();
      let mut v263_7_cursor = (v261_28_tail).read_zipper();
      for v263_7_byte in v263_7_cursor.child_mask().iter() {
        v263_7_cursor.descend_to_byte(v263_7_byte);
        {
        let v263_7_tail = v263_7_cursor.fork_read_zipper();
        let v263_7_head = Path::from_slice(&[v263_7_byte]);
        let v264_2: Space = singleton(&(v263_7_head));
        let v264_3: Space = intersect(&(*CONSTANT_2),&(v264_2));
        let v264_4: Space = if has_head(&(v264_3)) { singleton(&[]) } else { Space::new() };
        drop(v264_3);
        let v264_5: Space = subtract(&(*CONSTANT_1),&(v264_4));
        drop(v264_4);
        let v264_8: Space = if (v264_5).is_empty() { Space::new() } else {
          let v265_6: Path = concat_path(&(v263_6),&(v263_7_head));
          let mut v265_7 = Space::new();
          let mut v265_7_cursor = (v263_7_tail).read_zipper();
          for v265_7_byte in v265_7_cursor.child_mask().iter() {
            v265_7_cursor.descend_to_byte(v265_7_byte);
            {
            let v265_7_tail = v265_7_cursor.fork_read_zipper();
            let v265_7_head = Path::from_slice(&[v265_7_byte]);
            let v266_2: Space = singleton(&(v265_7_head));
            let v266_3: Space = intersect(&(*CONSTANT_2),&(v266_2));
            let v266_4: Space = if has_head(&(v266_3)) { singleton(&[]) } else { Space::new() };
            drop(v266_3);
            let v266_5: Space = subtract(&(*CONSTANT_1),&(v266_4));
            drop(v266_4);
            let v266_8: Space = if (v266_5).is_empty() { Space::new() } else {
              let v267_6: Path = concat_path(&(v265_6),&(v265_7_head));
              let v267_7: Space = routine_26(c, &(v267_6), &(*p1), &(v265_7_tail).make_space(), &(*s1));
              compose(&(v266_5),&(v267_7))
            };
            drop(v266_5);
            let v266_9: Space = intersect(&(*CONSTANT_2),&(v266_2));
            drop(v266_2);
            let v266_10: Space = if has_head(&(v266_9)) { singleton(&[]) } else { Space::new() };
            drop(v266_9);
            let v266_12: Space = if (v266_10).is_empty() { Space::new() } else {
              let v268_6: Path = concat_path(&(v265_6),&(v265_7_head));
              let v268_11: Space = routine_27(c, &(v268_6), &(*p1), &(v265_7_tail).make_space(), &(*s1));
              drop(v268_6);
              compose(&(v266_10),&(v268_11))
            };
            drop(v266_10);
            let v266_13: Space = unite(&(v266_8),&(v266_12));
            v265_7.join_into((v266_13).clone());
            }
            v265_7_cursor.ascend(1);
          }
          drop(v265_7_cursor);
          compose(&(v264_5),&(v265_7))
        };
        drop(v264_5);
        let v264_9: Space = intersect(&(*CONSTANT_2),&(v264_2));
        drop(v264_2);
        let v264_10: Space = if has_head(&(v264_9)) { singleton(&[]) } else { Space::new() };
        drop(v264_9);
        let v264_12: Space = if (v264_10).is_empty() { Space::new() } else {
          let v269_6: Path = concat_path(&(v263_6),&(v263_7_head));
          let mut v269_11 = Space::new();
          let mut v269_11_cursor = (v263_7_tail).read_zipper();
          for v269_11_byte in v269_11_cursor.child_mask().iter() {
            v269_11_cursor.descend_to_byte(v269_11_byte);
            {
            let v269_11_tail = v269_11_cursor.fork_read_zipper();
            let v269_11_head = Path::from_slice(&[v269_11_byte]);
            let v270_2: Space = singleton(&(v269_11_head));
            let v270_3: Space = intersect(&(*CONSTANT_2),&(v270_2));
            let v270_4: Space = if has_head(&(v270_3)) { singleton(&[]) } else { Space::new() };
            drop(v270_3);
            let v270_5: Space = subtract(&(*CONSTANT_1),&(v270_4));
            drop(v270_4);
            let v270_8: Space = if (v270_5).is_empty() { Space::new() } else {
              let v271_6: Path = concat_path(&(v269_6),&(v269_11_head));
              let v271_7: Space = routine_26(c, &(v271_6), &(*p1), &(v269_11_tail).make_space(), &(*s1));
              compose(&(v270_5),&(v271_7))
            };
            drop(v270_5);
            let v270_9: Space = intersect(&(*CONSTANT_2),&(v270_2));
            drop(v270_2);
            let v270_10: Space = if has_head(&(v270_9)) { singleton(&[]) } else { Space::new() };
            drop(v270_9);
            let v270_12: Space = if (v270_10).is_empty() { Space::new() } else {
              let v272_6: Path = concat_path(&(v269_6),&(v269_11_head));
              let v272_11: Space = routine_10(c, &(v272_6), &(*p1), &(v269_11_tail).make_space(), &(*s1));
              drop(v272_6);
              compose(&(v270_10),&(v272_11))
            };
            drop(v270_10);
            let v270_13: Space = unite(&(v270_8),&(v270_12));
            v269_11.join_into((v270_13).clone());
            }
            v269_11_cursor.ascend(1);
          }
          drop(v269_11_cursor);
          drop(v269_6);
          compose(&(v264_10),&(v269_11))
        };
        drop(v264_10);
        let v264_13: Space = unite(&(v264_8),&(v264_12));
        v263_7.join_into((v264_13).clone());
        }
        v263_7_cursor.ascend(1);
      }
      drop(v263_7_cursor);
      drop(v263_6);
      compose(&(v262_5),&(v263_7))
    };
    drop(v262_5);
    let v262_9: Space = intersect(&(*CONSTANT_2),&(v262_2));
    drop(v262_2);
    let v262_10: Space = if has_head(&(v262_9)) { singleton(&[]) } else { Space::new() };
    drop(v262_9);
    let v262_13: Space = if (v262_10).is_empty() { Space::new() } else {
      let v273_11: Space = unwrap(&(v261_9),&(v261_28_head));
      let mut v273_12 = Space::new();
      let mut v273_12_cursor = (v273_11).read_zipper();
      for v273_12_byte in v273_12_cursor.child_mask().iter() {
        v273_12_cursor.descend_to_byte(v273_12_byte);
        {
        let v273_12_tail = v273_12_cursor.fork_read_zipper();
        let v273_12_head = Path::from_slice(&[v273_12_byte]);
        let v274_2: Space = singleton(&(v273_12_head));
        let v274_3: Space = intersect(&(*CONSTANT_2),&(v274_2));
        let v274_4: Space = if has_head(&(v274_3)) { singleton(&[]) } else { Space::new() };
        drop(v274_3);
        let v274_5: Space = subtract(&(*CONSTANT_1),&(v274_4));
        drop(v274_4);
        let v274_7: Space = if (v274_5).is_empty() { Space::new() } else {
          let mut v275_6 = Space::new();
          let mut v275_6_cursor = (v273_12_tail).read_zipper();
          for v275_6_byte in v275_6_cursor.child_mask().iter() {
            v275_6_cursor.descend_to_byte(v275_6_byte);
            {
            let v275_6_tail = v275_6_cursor.fork_read_zipper();
            let v275_6_head = Path::from_slice(&[v275_6_byte]);
            let v276_2: Space = singleton(&(v275_6_head));
            let v276_3: Space = intersect(&(*CONSTANT_2),&(v276_2));
            let v276_4: Space = if has_head(&(v276_3)) { singleton(&[]) } else { Space::new() };
            drop(v276_3);
            let v276_5: Space = subtract(&(*CONSTANT_1),&(v276_4));
            drop(v276_4);
            let v276_8: Space = if (v276_5).is_empty() { Space::new() } else {
              let v277_6: Path = concat_path(&(v273_12_head),&(v275_6_head));
              let v277_7: Space = routine_17(c, &(v277_6), &(*p1), &(v275_6_tail).make_space());
              compose(&(v276_5),&(v277_7))
            };
            drop(v276_5);
            let v276_9: Space = intersect(&(*CONSTANT_2),&(v276_2));
            drop(v276_2);
            let v276_10: Space = if has_head(&(v276_9)) { singleton(&[]) } else { Space::new() };
            drop(v276_9);
            let v276_12: Space = if (v276_10).is_empty() { Space::new() } else {
              let v278_6: Path = concat_path(&(v273_12_head),&(v275_6_head));
              let v278_11: Space = routine_18(c, &(v278_6), &(*p1), &(v275_6_tail).make_space());
              drop(v278_6);
              compose(&(v276_10),&(v278_11))
            };
            drop(v276_10);
            let v276_13: Space = unite(&(v276_8),&(v276_12));
            v275_6.join_into((v276_13).clone());
            }
            v275_6_cursor.ascend(1);
          }
          drop(v275_6_cursor);
          compose(&(v274_5),&(v275_6))
        };
        drop(v274_5);
        let v274_8: Space = intersect(&(*CONSTANT_2),&(v274_2));
        drop(v274_2);
        let v274_9: Space = if has_head(&(v274_8)) { singleton(&[]) } else { Space::new() };
        drop(v274_8);
        let v274_11: Space = if (v274_9).is_empty() { Space::new() } else {
          let mut v279_10 = Space::new();
          let mut v279_10_cursor = (v273_12_tail).read_zipper();
          for v279_10_byte in v279_10_cursor.child_mask().iter() {
            v279_10_cursor.descend_to_byte(v279_10_byte);
            {
            let v279_10_tail = v279_10_cursor.fork_read_zipper();
            let v279_10_head = Path::from_slice(&[v279_10_byte]);
            let v280_2: Space = singleton(&(v279_10_head));
            let v280_3: Space = intersect(&(*CONSTANT_2),&(v280_2));
            let v280_4: Space = if has_head(&(v280_3)) { singleton(&[]) } else { Space::new() };
            drop(v280_3);
            let v280_5: Space = subtract(&(*CONSTANT_1),&(v280_4));
            drop(v280_4);
            let v280_8: Space = if (v280_5).is_empty() { Space::new() } else {
              let v281_6: Path = concat_path(&(v273_12_head),&(v279_10_head));
              let v281_7: Space = routine_17(c, &(v281_6), &(*p1), &(v279_10_tail).make_space());
              compose(&(v280_5),&(v281_7))
            };
            drop(v280_5);
            let v280_9: Space = intersect(&(*CONSTANT_2),&(v280_2));
            drop(v280_2);
            let v280_10: Space = if has_head(&(v280_9)) { singleton(&[]) } else { Space::new() };
            drop(v280_9);
            let v280_12: Space = if (v280_10).is_empty() { Space::new() } else {
              let v282_6: Path = concat_path(&(v273_12_head),&(v279_10_head));
              let v282_11: Space = routine_19(c, &(v282_6), &(*p1), &(v279_10_tail).make_space());
              drop(v282_6);
              compose(&(v280_10),&(v282_11))
            };
            drop(v280_10);
            let v280_13: Space = unite(&(v280_8),&(v280_12));
            v279_10.join_into((v280_13).clone());
            }
            v279_10_cursor.ascend(1);
          }
          drop(v279_10_cursor);
          compose(&(v274_9),&(v279_10))
        };
        drop(v274_9);
        let v274_12: Space = unite(&(v274_7),&(v274_11));
        v273_12.join_into((v274_12).clone());
        }
        v273_12_cursor.ascend(1);
      }
      drop(v273_12_cursor);
      drop(v273_11);
      compose(&(v262_10),&(v273_12))
    };
    drop(v262_10);
    let v262_14: Space = unite(&(v262_8),&(v262_13));
    v261_28.join_into((v262_14).clone());
    }
    v261_28_cursor.ascend(1);
  }
  drop(v261_28_cursor);
  drop(v261_9);
  (v261_28).clone()
}

fn routine_13(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v283_21 = Space::new();
  let mut v283_21_cursor = (*s0).read_zipper();
  for v283_21_byte in v283_21_cursor.child_mask().iter() {
    v283_21_cursor.descend_to_byte(v283_21_byte);
    {
    let v283_21_tail = v283_21_cursor.fork_read_zipper();
    let v283_21_head = Path::from_slice(&[v283_21_byte]);
    let v284_2: Space = singleton(&(v283_21_head));
    let v284_3: Space = intersect(&(*CONSTANT_2),&(v284_2));
    let v284_4: Space = if has_head(&(v284_3)) { singleton(&[]) } else { Space::new() };
    drop(v284_3);
    let v284_5: Space = subtract(&(*CONSTANT_1),&(v284_4));
    drop(v284_4);
    let v284_8: Space = if (v284_5).is_empty() { Space::new() } else {
      let v285_6: Path = concat_path(&(*p0),&(v283_21_head));
      let mut v285_7 = Space::new();
      let mut v285_7_cursor = (v283_21_tail).read_zipper();
      for v285_7_byte in v285_7_cursor.child_mask().iter() {
        v285_7_cursor.descend_to_byte(v285_7_byte);
        {
        let v285_7_tail = v285_7_cursor.fork_read_zipper();
        let v285_7_head = Path::from_slice(&[v285_7_byte]);
        let v286_2: Space = singleton(&(v285_7_head));
        let v286_3: Space = intersect(&(*CONSTANT_2),&(v286_2));
        let v286_4: Space = if has_head(&(v286_3)) { singleton(&[]) } else { Space::new() };
        drop(v286_3);
        let v286_5: Space = subtract(&(*CONSTANT_1),&(v286_4));
        drop(v286_4);
        let v286_8: Space = if (v286_5).is_empty() { Space::new() } else {
          let v287_6: Path = concat_path(&(v285_6),&(v285_7_head));
          let mut v287_7 = Space::new();
          let mut v287_7_cursor = (v285_7_tail).read_zipper();
          for v287_7_byte in v287_7_cursor.child_mask().iter() {
            v287_7_cursor.descend_to_byte(v287_7_byte);
            {
            let v287_7_tail = v287_7_cursor.fork_read_zipper();
            let v287_7_head = Path::from_slice(&[v287_7_byte]);
            let v288_2: Space = singleton(&(v287_7_head));
            let v288_3: Space = intersect(&(*CONSTANT_2),&(v288_2));
            let v288_4: Space = if has_head(&(v288_3)) { singleton(&[]) } else { Space::new() };
            drop(v288_3);
            let v288_5: Space = subtract(&(*CONSTANT_1),&(v288_4));
            drop(v288_4);
            let v288_8: Space = if (v288_5).is_empty() { Space::new() } else {
              let v289_6: Path = concat_path(&(v287_6),&(v287_7_head));
              let v289_7: Space = routine_28(c, &(v289_6), &(*p1), &(v287_7_tail).make_space());
              compose(&(v288_5),&(v289_7))
            };
            drop(v288_5);
            let v288_9: Space = intersect(&(*CONSTANT_2),&(v288_2));
            drop(v288_2);
            let v288_10: Space = if has_head(&(v288_9)) { singleton(&[]) } else { Space::new() };
            drop(v288_9);
            let v288_12: Space = if (v288_10).is_empty() { Space::new() } else {
              let v290_6: Path = concat_path(&(v287_6),&(v287_7_head));
              let v290_11: Space = routine_29(c, &(v290_6), &(*p1), &(v287_7_tail).make_space());
              drop(v290_6);
              compose(&(v288_10),&(v290_11))
            };
            drop(v288_10);
            let v288_13: Space = unite(&(v288_8),&(v288_12));
            v287_7.join_into((v288_13).clone());
            }
            v287_7_cursor.ascend(1);
          }
          drop(v287_7_cursor);
          compose(&(v286_5),&(v287_7))
        };
        drop(v286_5);
        let v286_9: Space = intersect(&(*CONSTANT_2),&(v286_2));
        drop(v286_2);
        let v286_10: Space = if has_head(&(v286_9)) { singleton(&[]) } else { Space::new() };
        drop(v286_9);
        let v286_12: Space = if (v286_10).is_empty() { Space::new() } else {
          let v291_6: Path = concat_path(&(v285_6),&(v285_7_head));
          let mut v291_11 = Space::new();
          let mut v291_11_cursor = (v285_7_tail).read_zipper();
          for v291_11_byte in v291_11_cursor.child_mask().iter() {
            v291_11_cursor.descend_to_byte(v291_11_byte);
            {
            let v291_11_tail = v291_11_cursor.fork_read_zipper();
            let v291_11_head = Path::from_slice(&[v291_11_byte]);
            let v292_2: Space = singleton(&(v291_11_head));
            let v292_3: Space = intersect(&(*CONSTANT_2),&(v292_2));
            let v292_4: Space = if has_head(&(v292_3)) { singleton(&[]) } else { Space::new() };
            drop(v292_3);
            let v292_5: Space = subtract(&(*CONSTANT_1),&(v292_4));
            drop(v292_4);
            let v292_8: Space = if (v292_5).is_empty() { Space::new() } else {
              let v293_6: Path = concat_path(&(v291_6),&(v291_11_head));
              let v293_7: Space = routine_28(c, &(v293_6), &(*p1), &(v291_11_tail).make_space());
              compose(&(v292_5),&(v293_7))
            };
            drop(v292_5);
            let v292_9: Space = intersect(&(*CONSTANT_2),&(v292_2));
            drop(v292_2);
            let v292_10: Space = if has_head(&(v292_9)) { singleton(&[]) } else { Space::new() };
            drop(v292_9);
            let v292_12: Space = if (v292_10).is_empty() { Space::new() } else {
              let v294_6: Path = concat_path(&(v291_6),&(v291_11_head));
              let v294_11: Space = routine_19(c, &(v294_6), &(*p1), &(v291_11_tail).make_space());
              drop(v294_6);
              compose(&(v292_10),&(v294_11))
            };
            drop(v292_10);
            let v292_13: Space = unite(&(v292_8),&(v292_12));
            v291_11.join_into((v292_13).clone());
            }
            v291_11_cursor.ascend(1);
          }
          drop(v291_11_cursor);
          drop(v291_6);
          compose(&(v286_10),&(v291_11))
        };
        drop(v286_10);
        let v286_13: Space = unite(&(v286_8),&(v286_12));
        v285_7.join_into((v286_13).clone());
        }
        v285_7_cursor.ascend(1);
      }
      drop(v285_7_cursor);
      compose(&(v284_5),&(v285_7))
    };
    drop(v284_5);
    let v284_9: Space = intersect(&(*CONSTANT_2),&(v284_2));
    drop(v284_2);
    let v284_10: Space = if has_head(&(v284_9)) { singleton(&[]) } else { Space::new() };
    drop(v284_9);
    let v284_12: Space = if (v284_10).is_empty() { Space::new() } else {
      let v295_6: Path = concat_path(&(*p0),&(v283_21_head));
      let mut v295_11 = Space::new();
      let mut v295_11_cursor = (v283_21_tail).read_zipper();
      for v295_11_byte in v295_11_cursor.child_mask().iter() {
        v295_11_cursor.descend_to_byte(v295_11_byte);
        {
        let v295_11_tail = v295_11_cursor.fork_read_zipper();
        let v295_11_head = Path::from_slice(&[v295_11_byte]);
        let v296_2: Space = singleton(&(v295_11_head));
        let v296_3: Space = intersect(&(*CONSTANT_2),&(v296_2));
        let v296_4: Space = if has_head(&(v296_3)) { singleton(&[]) } else { Space::new() };
        drop(v296_3);
        let v296_5: Space = subtract(&(*CONSTANT_1),&(v296_4));
        drop(v296_4);
        let v296_8: Space = if (v296_5).is_empty() { Space::new() } else {
          let v297_6: Path = concat_path(&(v295_6),&(v295_11_head));
          let mut v297_7 = Space::new();
          let mut v297_7_cursor = (v295_11_tail).read_zipper();
          for v297_7_byte in v297_7_cursor.child_mask().iter() {
            v297_7_cursor.descend_to_byte(v297_7_byte);
            {
            let v297_7_tail = v297_7_cursor.fork_read_zipper();
            let v297_7_head = Path::from_slice(&[v297_7_byte]);
            let v298_2: Space = singleton(&(v297_7_head));
            let v298_3: Space = intersect(&(*CONSTANT_2),&(v298_2));
            let v298_4: Space = if has_head(&(v298_3)) { singleton(&[]) } else { Space::new() };
            drop(v298_3);
            let v298_5: Space = subtract(&(*CONSTANT_1),&(v298_4));
            drop(v298_4);
            let v298_8: Space = if (v298_5).is_empty() { Space::new() } else {
              let v299_6: Path = concat_path(&(v297_6),&(v297_7_head));
              let v299_7: Space = routine_28(c, &(v299_6), &(*p1), &(v297_7_tail).make_space());
              compose(&(v298_5),&(v299_7))
            };
            drop(v298_5);
            let v298_9: Space = intersect(&(*CONSTANT_2),&(v298_2));
            drop(v298_2);
            let v298_10: Space = if has_head(&(v298_9)) { singleton(&[]) } else { Space::new() };
            drop(v298_9);
            let v298_12: Space = if (v298_10).is_empty() { Space::new() } else {
              let v300_6: Path = concat_path(&(v297_6),&(v297_7_head));
              let v300_11: Space = routine_29(c, &(v300_6), &(*p1), &(v297_7_tail).make_space());
              drop(v300_6);
              compose(&(v298_10),&(v300_11))
            };
            drop(v298_10);
            let v298_13: Space = unite(&(v298_8),&(v298_12));
            v297_7.join_into((v298_13).clone());
            }
            v297_7_cursor.ascend(1);
          }
          drop(v297_7_cursor);
          compose(&(v296_5),&(v297_7))
        };
        drop(v296_5);
        let v296_9: Space = intersect(&(*CONSTANT_2),&(v296_2));
        drop(v296_2);
        let v296_10: Space = if has_head(&(v296_9)) { singleton(&[]) } else { Space::new() };
        drop(v296_9);
        let v296_11: Space = compose(&(v296_10),&(v295_11_tail));
        drop(v296_10);
        let v301_6: Path = concat_path(&(v295_6),&(v295_11_head));
        let v296_12: Space = wrap(&(v296_11),&(v301_6));
        drop(v296_11);
        let v296_13: Space = wrap(&(v296_12),&(*p1));
        drop(v296_12);
        let v296_14: Space = unite(&(v296_8),&(v296_13));
        drop(v296_13);
        v295_11.join_into((v296_14).clone());
        }
        v295_11_cursor.ascend(1);
      }
      drop(v295_11_cursor);
      drop(v295_6);
      compose(&(v284_10),&(v295_11))
    };
    drop(v284_10);
    let v284_13: Space = unite(&(v284_8),&(v284_12));
    v283_21.join_into((v284_13).clone());
    }
    v283_21_cursor.ascend(1);
  }
  drop(v283_21_cursor);
  (v283_21).clone()
}

fn routine_14(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v302_15 = Space::new();
  let mut v302_15_cursor = (*s0).read_zipper();
  for v302_15_byte in v302_15_cursor.child_mask().iter() {
    v302_15_cursor.descend_to_byte(v302_15_byte);
    {
    let v302_15_tail = v302_15_cursor.fork_read_zipper();
    let v302_15_head = Path::from_slice(&[v302_15_byte]);
    let v303_2: Space = singleton(&(v302_15_head));
    let v303_3: Space = intersect(&(*CONSTANT_2),&(v303_2));
    let v303_4: Space = if has_head(&(v303_3)) { singleton(&[]) } else { Space::new() };
    drop(v303_3);
    let v303_5: Space = subtract(&(*CONSTANT_1),&(v303_4));
    drop(v303_4);
    let v303_8: Space = if (v303_5).is_empty() { Space::new() } else {
      let v304_6: Path = concat_path(&(*p0),&(v302_15_head));
      let mut v304_7 = Space::new();
      let mut v304_7_cursor = (v302_15_tail).read_zipper();
      for v304_7_byte in v304_7_cursor.child_mask().iter() {
        v304_7_cursor.descend_to_byte(v304_7_byte);
        {
        let v304_7_tail = v304_7_cursor.fork_read_zipper();
        let v304_7_head = Path::from_slice(&[v304_7_byte]);
        let v305_2: Space = singleton(&(v304_7_head));
        let v305_3: Space = intersect(&(*CONSTANT_2),&(v305_2));
        let v305_4: Space = if has_head(&(v305_3)) { singleton(&[]) } else { Space::new() };
        drop(v305_3);
        let v305_5: Space = subtract(&(*CONSTANT_1),&(v305_4));
        drop(v305_4);
        let v305_8: Space = if (v305_5).is_empty() { Space::new() } else {
          let v306_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let mut v306_7 = Space::new();
          let mut v306_7_cursor = (v304_7_tail).read_zipper();
          for v306_7_byte in v306_7_cursor.child_mask().iter() {
            v306_7_cursor.descend_to_byte(v306_7_byte);
            {
            let v306_7_tail = v306_7_cursor.fork_read_zipper();
            let v306_7_head = Path::from_slice(&[v306_7_byte]);
            let v307_2: Space = singleton(&(v306_7_head));
            let v307_3: Space = intersect(&(*CONSTANT_2),&(v307_2));
            let v307_4: Space = if has_head(&(v307_3)) { singleton(&[]) } else { Space::new() };
            drop(v307_3);
            let v307_5: Space = subtract(&(*CONSTANT_1),&(v307_4));
            drop(v307_4);
            let v307_8: Space = if (v307_5).is_empty() { Space::new() } else {
              let v308_6: Path = concat_path(&(v306_6),&(v306_7_head));
              let v308_7: Space = routine_28(c, &(v308_6), &(*p1), &(v306_7_tail).make_space());
              compose(&(v307_5),&(v308_7))
            };
            drop(v307_5);
            let v307_9: Space = intersect(&(*CONSTANT_2),&(v307_2));
            drop(v307_2);
            let v307_10: Space = if has_head(&(v307_9)) { singleton(&[]) } else { Space::new() };
            drop(v307_9);
            let v307_12: Space = if (v307_10).is_empty() { Space::new() } else {
              let v309_6: Path = concat_path(&(v306_6),&(v306_7_head));
              let v309_11: Space = routine_29(c, &(v309_6), &(*p1), &(v306_7_tail).make_space());
              drop(v309_6);
              compose(&(v307_10),&(v309_11))
            };
            drop(v307_10);
            let v307_13: Space = unite(&(v307_8),&(v307_12));
            v306_7.join_into((v307_13).clone());
            }
            v306_7_cursor.ascend(1);
          }
          drop(v306_7_cursor);
          compose(&(v305_5),&(v306_7))
        };
        drop(v305_5);
        let v305_9: Space = intersect(&(*CONSTANT_2),&(v305_2));
        drop(v305_2);
        let v305_10: Space = if has_head(&(v305_9)) { singleton(&[]) } else { Space::new() };
        drop(v305_9);
        let v305_12: Space = if (v305_10).is_empty() { Space::new() } else {
          let v310_6: Path = concat_path(&(v304_6),&(v304_7_head));
          let mut v310_11 = Space::new();
          let mut v310_11_cursor = (v304_7_tail).read_zipper();
          for v310_11_byte in v310_11_cursor.child_mask().iter() {
            v310_11_cursor.descend_to_byte(v310_11_byte);
            {
            let v310_11_tail = v310_11_cursor.fork_read_zipper();
            let v310_11_head = Path::from_slice(&[v310_11_byte]);
            let v311_2: Space = singleton(&(v310_11_head));
            let v311_3: Space = intersect(&(*CONSTANT_2),&(v311_2));
            let v311_4: Space = if has_head(&(v311_3)) { singleton(&[]) } else { Space::new() };
            drop(v311_3);
            let v311_5: Space = subtract(&(*CONSTANT_1),&(v311_4));
            drop(v311_4);
            let v311_8: Space = if (v311_5).is_empty() { Space::new() } else {
              let v312_6: Path = concat_path(&(v310_6),&(v310_11_head));
              let v312_7: Space = routine_28(c, &(v312_6), &(*p1), &(v310_11_tail).make_space());
              compose(&(v311_5),&(v312_7))
            };
            drop(v311_5);
            let v311_9: Space = intersect(&(*CONSTANT_2),&(v311_2));
            drop(v311_2);
            let v311_10: Space = if has_head(&(v311_9)) { singleton(&[]) } else { Space::new() };
            drop(v311_9);
            let v311_12: Space = if (v311_10).is_empty() { Space::new() } else {
              let v313_6: Path = concat_path(&(v310_6),&(v310_11_head));
              let v313_11: Space = routine_19(c, &(v313_6), &(*p1), &(v310_11_tail).make_space());
              drop(v313_6);
              compose(&(v311_10),&(v313_11))
            };
            drop(v311_10);
            let v311_13: Space = unite(&(v311_8),&(v311_12));
            v310_11.join_into((v311_13).clone());
            }
            v310_11_cursor.ascend(1);
          }
          drop(v310_11_cursor);
          drop(v310_6);
          compose(&(v305_10),&(v310_11))
        };
        drop(v305_10);
        let v305_13: Space = unite(&(v305_8),&(v305_12));
        v304_7.join_into((v305_13).clone());
        }
        v304_7_cursor.ascend(1);
      }
      drop(v304_7_cursor);
      compose(&(v303_5),&(v304_7))
    };
    drop(v303_5);
    let v303_9: Space = intersect(&(*CONSTANT_2),&(v303_2));
    drop(v303_2);
    let v303_10: Space = if has_head(&(v303_9)) { singleton(&[]) } else { Space::new() };
    drop(v303_9);
    let v303_11: Space = compose(&(v303_10),&(v302_15_tail));
    drop(v303_10);
    let v314_6: Path = concat_path(&(*p0),&(v302_15_head));
    let v303_12: Space = wrap(&(v303_11),&(v314_6));
    drop(v303_11);
    let v303_13: Space = wrap(&(v303_12),&(*p1));
    drop(v303_12);
    let v303_14: Space = unite(&(v303_8),&(v303_13));
    drop(v303_13);
    v302_15.join_into((v303_14).clone());
    }
    v302_15_cursor.ascend(1);
  }
  drop(v302_15_cursor);
  (v302_15).clone()
}

fn routine_15(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v315_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v315_21: Space = unwrap(&(v315_20),&(*p0));
  drop(v315_20);
  let mut v315_28 = Space::new();
  let mut v315_28_cursor = (*s0).read_zipper();
  for v315_28_byte in v315_28_cursor.child_mask().iter() {
    v315_28_cursor.descend_to_byte(v315_28_byte);
    {
    let v315_28_tail = v315_28_cursor.fork_read_zipper();
    let v315_28_head = Path::from_slice(&[v315_28_byte]);
    let v316_2: Space = singleton(&(v315_28_head));
    let v316_3: Space = intersect(&(*CONSTANT_2),&(v316_2));
    let v316_4: Space = if has_head(&(v316_3)) { singleton(&[]) } else { Space::new() };
    drop(v316_3);
    let v316_5: Space = subtract(&(*CONSTANT_1),&(v316_4));
    drop(v316_4);
    let v316_8: Space = if (v316_5).is_empty() { Space::new() } else {
      let v317_6: Path = concat_path(&(*p0),&(v315_28_head));
      let mut v317_7 = Space::new();
      let mut v317_7_cursor = (v315_28_tail).read_zipper();
      for v317_7_byte in v317_7_cursor.child_mask().iter() {
        v317_7_cursor.descend_to_byte(v317_7_byte);
        {
        let v317_7_tail = v317_7_cursor.fork_read_zipper();
        let v317_7_head = Path::from_slice(&[v317_7_byte]);
        let v318_2: Space = singleton(&(v317_7_head));
        let v318_3: Space = intersect(&(*CONSTANT_2),&(v318_2));
        let v318_4: Space = if has_head(&(v318_3)) { singleton(&[]) } else { Space::new() };
        drop(v318_3);
        let v318_5: Space = subtract(&(*CONSTANT_1),&(v318_4));
        drop(v318_4);
        let v318_8: Space = if (v318_5).is_empty() { Space::new() } else {
          let v319_6: Path = concat_path(&(v317_6),&(v317_7_head));
          let mut v319_7 = Space::new();
          let mut v319_7_cursor = (v317_7_tail).read_zipper();
          for v319_7_byte in v319_7_cursor.child_mask().iter() {
            v319_7_cursor.descend_to_byte(v319_7_byte);
            {
            let v319_7_tail = v319_7_cursor.fork_read_zipper();
            let v319_7_head = Path::from_slice(&[v319_7_byte]);
            let v320_2: Space = singleton(&(v319_7_head));
            let v320_3: Space = intersect(&(*CONSTANT_2),&(v320_2));
            let v320_4: Space = if has_head(&(v320_3)) { singleton(&[]) } else { Space::new() };
            drop(v320_3);
            let v320_5: Space = subtract(&(*CONSTANT_1),&(v320_4));
            drop(v320_4);
            let v320_8: Space = if (v320_5).is_empty() { Space::new() } else {
              let v321_6: Path = concat_path(&(v319_6),&(v319_7_head));
              let v321_7: Space = routine_30(c, &(v321_6), &(*p1), &(v319_7_tail).make_space(), &(*s1));
              compose(&(v320_5),&(v321_7))
            };
            drop(v320_5);
            let v320_9: Space = intersect(&(*CONSTANT_2),&(v320_2));
            drop(v320_2);
            let v320_10: Space = if has_head(&(v320_9)) { singleton(&[]) } else { Space::new() };
            drop(v320_9);
            let v320_12: Space = if (v320_10).is_empty() { Space::new() } else {
              let v322_6: Path = concat_path(&(v319_6),&(v319_7_head));
              let v322_11: Space = routine_31(c, &(v322_6), &(*p1), &(v319_7_tail).make_space(), &(*s1));
              drop(v322_6);
              compose(&(v320_10),&(v322_11))
            };
            drop(v320_10);
            let v320_13: Space = unite(&(v320_8),&(v320_12));
            v319_7.join_into((v320_13).clone());
            }
            v319_7_cursor.ascend(1);
          }
          drop(v319_7_cursor);
          compose(&(v318_5),&(v319_7))
        };
        drop(v318_5);
        let v318_9: Space = intersect(&(*CONSTANT_2),&(v318_2));
        drop(v318_2);
        let v318_10: Space = if has_head(&(v318_9)) { singleton(&[]) } else { Space::new() };
        drop(v318_9);
        let v318_12: Space = if (v318_10).is_empty() { Space::new() } else {
          let v323_6: Path = concat_path(&(v317_6),&(v317_7_head));
          let mut v323_11 = Space::new();
          let mut v323_11_cursor = (v317_7_tail).read_zipper();
          for v323_11_byte in v323_11_cursor.child_mask().iter() {
            v323_11_cursor.descend_to_byte(v323_11_byte);
            {
            let v323_11_tail = v323_11_cursor.fork_read_zipper();
            let v323_11_head = Path::from_slice(&[v323_11_byte]);
            let v324_2: Space = singleton(&(v323_11_head));
            let v324_3: Space = intersect(&(*CONSTANT_2),&(v324_2));
            let v324_4: Space = if has_head(&(v324_3)) { singleton(&[]) } else { Space::new() };
            drop(v324_3);
            let v324_5: Space = subtract(&(*CONSTANT_1),&(v324_4));
            drop(v324_4);
            let v324_8: Space = if (v324_5).is_empty() { Space::new() } else {
              let v325_6: Path = concat_path(&(v323_6),&(v323_11_head));
              let v325_7: Space = routine_30(c, &(v325_6), &(*p1), &(v323_11_tail).make_space(), &(*s1));
              compose(&(v324_5),&(v325_7))
            };
            drop(v324_5);
            let v324_9: Space = intersect(&(*CONSTANT_2),&(v324_2));
            drop(v324_2);
            let v324_10: Space = if has_head(&(v324_9)) { singleton(&[]) } else { Space::new() };
            drop(v324_9);
            let v324_12: Space = if (v324_10).is_empty() { Space::new() } else {
              let v326_6: Path = concat_path(&(v323_6),&(v323_11_head));
              let v326_11: Space = routine_10(c, &(v326_6), &(*p1), &(v323_11_tail).make_space(), &(*s1));
              drop(v326_6);
              compose(&(v324_10),&(v326_11))
            };
            drop(v324_10);
            let v324_13: Space = unite(&(v324_8),&(v324_12));
            v323_11.join_into((v324_13).clone());
            }
            v323_11_cursor.ascend(1);
          }
          drop(v323_11_cursor);
          drop(v323_6);
          compose(&(v318_10),&(v323_11))
        };
        drop(v318_10);
        let v318_13: Space = unite(&(v318_8),&(v318_12));
        v317_7.join_into((v318_13).clone());
        }
        v317_7_cursor.ascend(1);
      }
      drop(v317_7_cursor);
      compose(&(v316_5),&(v317_7))
    };
    drop(v316_5);
    let v316_9: Space = intersect(&(*CONSTANT_2),&(v316_2));
    drop(v316_2);
    let v316_10: Space = if has_head(&(v316_9)) { singleton(&[]) } else { Space::new() };
    drop(v316_9);
    let v316_13: Space = if (v316_10).is_empty() { Space::new() } else {
      let v327_6: Path = concat_path(&(*p0),&(v315_28_head));
      let v327_11: Space = unwrap(&(v315_21),&(v315_28_head));
      let mut v327_12 = Space::new();
      let mut v327_12_cursor = (v315_28_tail).read_zipper();
      for v327_12_byte in v327_12_cursor.child_mask().iter() {
        v327_12_cursor.descend_to_byte(v327_12_byte);
        {
        let v327_12_tail = v327_12_cursor.fork_read_zipper();
        let v327_12_head = Path::from_slice(&[v327_12_byte]);
        let v328_2: Space = singleton(&(v327_12_head));
        let v328_3: Space = intersect(&(*CONSTANT_2),&(v328_2));
        let v328_4: Space = if has_head(&(v328_3)) { singleton(&[]) } else { Space::new() };
        drop(v328_3);
        let v328_5: Space = subtract(&(*CONSTANT_1),&(v328_4));
        drop(v328_4);
        let v328_8: Space = if (v328_5).is_empty() { Space::new() } else {
          let v329_6: Path = concat_path(&(v327_6),&(v327_12_head));
          let mut v329_7 = Space::new();
          let mut v329_7_cursor = (v327_12_tail).read_zipper();
          for v329_7_byte in v329_7_cursor.child_mask().iter() {
            v329_7_cursor.descend_to_byte(v329_7_byte);
            {
            let v329_7_tail = v329_7_cursor.fork_read_zipper();
            let v329_7_head = Path::from_slice(&[v329_7_byte]);
            let v330_2: Space = singleton(&(v329_7_head));
            let v330_3: Space = intersect(&(*CONSTANT_2),&(v330_2));
            let v330_4: Space = if has_head(&(v330_3)) { singleton(&[]) } else { Space::new() };
            drop(v330_3);
            let v330_5: Space = subtract(&(*CONSTANT_1),&(v330_4));
            drop(v330_4);
            let v330_8: Space = if (v330_5).is_empty() { Space::new() } else {
              let v331_6: Path = concat_path(&(v329_6),&(v329_7_head));
              let v331_7: Space = routine_30(c, &(v331_6), &(*p1), &(v329_7_tail).make_space(), &(*s1));
              compose(&(v330_5),&(v331_7))
            };
            drop(v330_5);
            let v330_9: Space = intersect(&(*CONSTANT_2),&(v330_2));
            drop(v330_2);
            let v330_10: Space = if has_head(&(v330_9)) { singleton(&[]) } else { Space::new() };
            drop(v330_9);
            let v330_12: Space = if (v330_10).is_empty() { Space::new() } else {
              let v332_6: Path = concat_path(&(v329_6),&(v329_7_head));
              let v332_11: Space = routine_31(c, &(v332_6), &(*p1), &(v329_7_tail).make_space(), &(*s1));
              drop(v332_6);
              compose(&(v330_10),&(v332_11))
            };
            drop(v330_10);
            let v330_13: Space = unite(&(v330_8),&(v330_12));
            v329_7.join_into((v330_13).clone());
            }
            v329_7_cursor.ascend(1);
          }
          drop(v329_7_cursor);
          drop(v329_6);
          compose(&(v328_5),&(v329_7))
        };
        drop(v328_5);
        let v328_9: Space = intersect(&(*CONSTANT_2),&(v328_2));
        drop(v328_2);
        let v328_10: Space = if has_head(&(v328_9)) { singleton(&[]) } else { Space::new() };
        drop(v328_9);
        let v328_13: Space = if (v328_10).is_empty() { Space::new() } else {
          let v333_11: Space = unwrap(&(v327_11),&(v327_12_head));
          let mut v333_12 = Space::new();
          let mut v333_12_cursor = (v333_11).read_zipper();
          for v333_12_byte in v333_12_cursor.child_mask().iter() {
            v333_12_cursor.descend_to_byte(v333_12_byte);
            {
            let v333_12_tail = v333_12_cursor.fork_read_zipper();
            let v333_12_head = Path::from_slice(&[v333_12_byte]);
            let v334_2: Space = singleton(&(v333_12_head));
            let v334_3: Space = intersect(&(*CONSTANT_2),&(v334_2));
            let v334_4: Space = if has_head(&(v334_3)) { singleton(&[]) } else { Space::new() };
            drop(v334_3);
            let v334_5: Space = subtract(&(*CONSTANT_1),&(v334_4));
            drop(v334_4);
            let v334_7: Space = if (v334_5).is_empty() { Space::new() } else {
              let v335_6: Space = routine_13(c, &(v333_12_head), &(*p1), &(v333_12_tail).make_space());
              compose(&(v334_5),&(v335_6))
            };
            drop(v334_5);
            let v334_8: Space = intersect(&(*CONSTANT_2),&(v334_2));
            drop(v334_2);
            let v334_9: Space = if has_head(&(v334_8)) { singleton(&[]) } else { Space::new() };
            drop(v334_8);
            let v334_11: Space = if (v334_9).is_empty() { Space::new() } else {
              let v336_10: Space = routine_14(c, &(v333_12_head), &(*p1), &(v333_12_tail).make_space());
              compose(&(v334_9),&(v336_10))
            };
            drop(v334_9);
            let v334_12: Space = unite(&(v334_7),&(v334_11));
            v333_12.join_into((v334_12).clone());
            }
            v333_12_cursor.ascend(1);
          }
          drop(v333_12_cursor);
          drop(v333_11);
          compose(&(v328_10),&(v333_12))
        };
        drop(v328_10);
        let v328_14: Space = unite(&(v328_8),&(v328_13));
        v327_12.join_into((v328_14).clone());
        }
        v327_12_cursor.ascend(1);
      }
      drop(v327_12_cursor);
      drop(v327_6);
      drop(v327_11);
      compose(&(v316_10),&(v327_12))
    };
    drop(v316_10);
    let v316_14: Space = unite(&(v316_8),&(v316_13));
    v315_28.join_into((v316_14).clone());
    }
    v315_28_cursor.ascend(1);
  }
  drop(v315_28_cursor);
  drop(v315_21);
  (v315_28).clone()
}

fn routine_16(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v337_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v337_9: Space = unwrap(&(v337_8),&(*p0));
  drop(v337_8);
  let mut v337_28 = Space::new();
  let mut v337_28_cursor = (*s0).read_zipper();
  for v337_28_byte in v337_28_cursor.child_mask().iter() {
    v337_28_cursor.descend_to_byte(v337_28_byte);
    {
    let v337_28_tail = v337_28_cursor.fork_read_zipper();
    let v337_28_head = Path::from_slice(&[v337_28_byte]);
    let v338_2: Space = singleton(&(v337_28_head));
    let v338_3: Space = intersect(&(*CONSTANT_2),&(v338_2));
    let v338_4: Space = if has_head(&(v338_3)) { singleton(&[]) } else { Space::new() };
    drop(v338_3);
    let v338_5: Space = subtract(&(*CONSTANT_1),&(v338_4));
    drop(v338_4);
    let v338_8: Space = if (v338_5).is_empty() { Space::new() } else {
      let v339_6: Path = concat_path(&(*p0),&(v337_28_head));
      let mut v339_7 = Space::new();
      let mut v339_7_cursor = (v337_28_tail).read_zipper();
      for v339_7_byte in v339_7_cursor.child_mask().iter() {
        v339_7_cursor.descend_to_byte(v339_7_byte);
        {
        let v339_7_tail = v339_7_cursor.fork_read_zipper();
        let v339_7_head = Path::from_slice(&[v339_7_byte]);
        let v340_2: Space = singleton(&(v339_7_head));
        let v340_3: Space = intersect(&(*CONSTANT_2),&(v340_2));
        let v340_4: Space = if has_head(&(v340_3)) { singleton(&[]) } else { Space::new() };
        drop(v340_3);
        let v340_5: Space = subtract(&(*CONSTANT_1),&(v340_4));
        drop(v340_4);
        let v340_8: Space = if (v340_5).is_empty() { Space::new() } else {
          let v341_6: Path = concat_path(&(v339_6),&(v339_7_head));
          let mut v341_7 = Space::new();
          let mut v341_7_cursor = (v339_7_tail).read_zipper();
          for v341_7_byte in v341_7_cursor.child_mask().iter() {
            v341_7_cursor.descend_to_byte(v341_7_byte);
            {
            let v341_7_tail = v341_7_cursor.fork_read_zipper();
            let v341_7_head = Path::from_slice(&[v341_7_byte]);
            let v342_2: Space = singleton(&(v341_7_head));
            let v342_3: Space = intersect(&(*CONSTANT_2),&(v342_2));
            let v342_4: Space = if has_head(&(v342_3)) { singleton(&[]) } else { Space::new() };
            drop(v342_3);
            let v342_5: Space = subtract(&(*CONSTANT_1),&(v342_4));
            drop(v342_4);
            let v342_8: Space = if (v342_5).is_empty() { Space::new() } else {
              let v343_6: Path = concat_path(&(v341_6),&(v341_7_head));
              let v343_7: Space = routine_30(c, &(v343_6), &(*p1), &(v341_7_tail).make_space(), &(*s1));
              compose(&(v342_5),&(v343_7))
            };
            drop(v342_5);
            let v342_9: Space = intersect(&(*CONSTANT_2),&(v342_2));
            drop(v342_2);
            let v342_10: Space = if has_head(&(v342_9)) { singleton(&[]) } else { Space::new() };
            drop(v342_9);
            let v342_12: Space = if (v342_10).is_empty() { Space::new() } else {
              let v344_6: Path = concat_path(&(v341_6),&(v341_7_head));
              let v344_11: Space = routine_31(c, &(v344_6), &(*p1), &(v341_7_tail).make_space(), &(*s1));
              drop(v344_6);
              compose(&(v342_10),&(v344_11))
            };
            drop(v342_10);
            let v342_13: Space = unite(&(v342_8),&(v342_12));
            v341_7.join_into((v342_13).clone());
            }
            v341_7_cursor.ascend(1);
          }
          drop(v341_7_cursor);
          compose(&(v340_5),&(v341_7))
        };
        drop(v340_5);
        let v340_9: Space = intersect(&(*CONSTANT_2),&(v340_2));
        drop(v340_2);
        let v340_10: Space = if has_head(&(v340_9)) { singleton(&[]) } else { Space::new() };
        drop(v340_9);
        let v340_12: Space = if (v340_10).is_empty() { Space::new() } else {
          let v345_6: Path = concat_path(&(v339_6),&(v339_7_head));
          let mut v345_11 = Space::new();
          let mut v345_11_cursor = (v339_7_tail).read_zipper();
          for v345_11_byte in v345_11_cursor.child_mask().iter() {
            v345_11_cursor.descend_to_byte(v345_11_byte);
            {
            let v345_11_tail = v345_11_cursor.fork_read_zipper();
            let v345_11_head = Path::from_slice(&[v345_11_byte]);
            let v346_2: Space = singleton(&(v345_11_head));
            let v346_3: Space = intersect(&(*CONSTANT_2),&(v346_2));
            let v346_4: Space = if has_head(&(v346_3)) { singleton(&[]) } else { Space::new() };
            drop(v346_3);
            let v346_5: Space = subtract(&(*CONSTANT_1),&(v346_4));
            drop(v346_4);
            let v346_8: Space = if (v346_5).is_empty() { Space::new() } else {
              let v347_6: Path = concat_path(&(v345_6),&(v345_11_head));
              let v347_7: Space = routine_30(c, &(v347_6), &(*p1), &(v345_11_tail).make_space(), &(*s1));
              compose(&(v346_5),&(v347_7))
            };
            drop(v346_5);
            let v346_9: Space = intersect(&(*CONSTANT_2),&(v346_2));
            drop(v346_2);
            let v346_10: Space = if has_head(&(v346_9)) { singleton(&[]) } else { Space::new() };
            drop(v346_9);
            let v346_12: Space = if (v346_10).is_empty() { Space::new() } else {
              let v348_6: Path = concat_path(&(v345_6),&(v345_11_head));
              let v348_11: Space = routine_10(c, &(v348_6), &(*p1), &(v345_11_tail).make_space(), &(*s1));
              drop(v348_6);
              compose(&(v346_10),&(v348_11))
            };
            drop(v346_10);
            let v346_13: Space = unite(&(v346_8),&(v346_12));
            v345_11.join_into((v346_13).clone());
            }
            v345_11_cursor.ascend(1);
          }
          drop(v345_11_cursor);
          drop(v345_6);
          compose(&(v340_10),&(v345_11))
        };
        drop(v340_10);
        let v340_13: Space = unite(&(v340_8),&(v340_12));
        v339_7.join_into((v340_13).clone());
        }
        v339_7_cursor.ascend(1);
      }
      drop(v339_7_cursor);
      drop(v339_6);
      compose(&(v338_5),&(v339_7))
    };
    drop(v338_5);
    let v338_9: Space = intersect(&(*CONSTANT_2),&(v338_2));
    drop(v338_2);
    let v338_10: Space = if has_head(&(v338_9)) { singleton(&[]) } else { Space::new() };
    drop(v338_9);
    let v338_13: Space = if (v338_10).is_empty() { Space::new() } else {
      let v349_11: Space = unwrap(&(v337_9),&(v337_28_head));
      let mut v349_12 = Space::new();
      let mut v349_12_cursor = (v349_11).read_zipper();
      for v349_12_byte in v349_12_cursor.child_mask().iter() {
        v349_12_cursor.descend_to_byte(v349_12_byte);
        {
        let v349_12_tail = v349_12_cursor.fork_read_zipper();
        let v349_12_head = Path::from_slice(&[v349_12_byte]);
        let v350_2: Space = singleton(&(v349_12_head));
        let v350_3: Space = intersect(&(*CONSTANT_2),&(v350_2));
        let v350_4: Space = if has_head(&(v350_3)) { singleton(&[]) } else { Space::new() };
        drop(v350_3);
        let v350_5: Space = subtract(&(*CONSTANT_1),&(v350_4));
        drop(v350_4);
        let v350_7: Space = if (v350_5).is_empty() { Space::new() } else {
          let mut v351_6 = Space::new();
          let mut v351_6_cursor = (v349_12_tail).read_zipper();
          for v351_6_byte in v351_6_cursor.child_mask().iter() {
            v351_6_cursor.descend_to_byte(v351_6_byte);
            {
            let v351_6_tail = v351_6_cursor.fork_read_zipper();
            let v351_6_head = Path::from_slice(&[v351_6_byte]);
            let v352_2: Space = singleton(&(v351_6_head));
            let v352_3: Space = intersect(&(*CONSTANT_2),&(v352_2));
            let v352_4: Space = if has_head(&(v352_3)) { singleton(&[]) } else { Space::new() };
            drop(v352_3);
            let v352_5: Space = subtract(&(*CONSTANT_1),&(v352_4));
            drop(v352_4);
            let v352_8: Space = if (v352_5).is_empty() { Space::new() } else {
              let v353_6: Path = concat_path(&(v349_12_head),&(v351_6_head));
              let v353_7: Space = routine_17(c, &(v353_6), &(*p1), &(v351_6_tail).make_space());
              compose(&(v352_5),&(v353_7))
            };
            drop(v352_5);
            let v352_9: Space = intersect(&(*CONSTANT_2),&(v352_2));
            drop(v352_2);
            let v352_10: Space = if has_head(&(v352_9)) { singleton(&[]) } else { Space::new() };
            drop(v352_9);
            let v352_12: Space = if (v352_10).is_empty() { Space::new() } else {
              let v354_6: Path = concat_path(&(v349_12_head),&(v351_6_head));
              let v354_11: Space = routine_18(c, &(v354_6), &(*p1), &(v351_6_tail).make_space());
              drop(v354_6);
              compose(&(v352_10),&(v354_11))
            };
            drop(v352_10);
            let v352_13: Space = unite(&(v352_8),&(v352_12));
            v351_6.join_into((v352_13).clone());
            }
            v351_6_cursor.ascend(1);
          }
          drop(v351_6_cursor);
          compose(&(v350_5),&(v351_6))
        };
        drop(v350_5);
        let v350_8: Space = intersect(&(*CONSTANT_2),&(v350_2));
        drop(v350_2);
        let v350_9: Space = if has_head(&(v350_8)) { singleton(&[]) } else { Space::new() };
        drop(v350_8);
        let v350_11: Space = if (v350_9).is_empty() { Space::new() } else {
          let mut v355_10 = Space::new();
          let mut v355_10_cursor = (v349_12_tail).read_zipper();
          for v355_10_byte in v355_10_cursor.child_mask().iter() {
            v355_10_cursor.descend_to_byte(v355_10_byte);
            {
            let v355_10_tail = v355_10_cursor.fork_read_zipper();
            let v355_10_head = Path::from_slice(&[v355_10_byte]);
            let v356_2: Space = singleton(&(v355_10_head));
            let v356_3: Space = intersect(&(*CONSTANT_2),&(v356_2));
            let v356_4: Space = if has_head(&(v356_3)) { singleton(&[]) } else { Space::new() };
            drop(v356_3);
            let v356_5: Space = subtract(&(*CONSTANT_1),&(v356_4));
            drop(v356_4);
            let v356_8: Space = if (v356_5).is_empty() { Space::new() } else {
              let v357_6: Path = concat_path(&(v349_12_head),&(v355_10_head));
              let v357_7: Space = routine_17(c, &(v357_6), &(*p1), &(v355_10_tail).make_space());
              compose(&(v356_5),&(v357_7))
            };
            drop(v356_5);
            let v356_9: Space = intersect(&(*CONSTANT_2),&(v356_2));
            drop(v356_2);
            let v356_10: Space = if has_head(&(v356_9)) { singleton(&[]) } else { Space::new() };
            drop(v356_9);
            let v356_12: Space = if (v356_10).is_empty() { Space::new() } else {
              let v358_6: Path = concat_path(&(v349_12_head),&(v355_10_head));
              let v358_11: Space = routine_19(c, &(v358_6), &(*p1), &(v355_10_tail).make_space());
              drop(v358_6);
              compose(&(v356_10),&(v358_11))
            };
            drop(v356_10);
            let v356_13: Space = unite(&(v356_8),&(v356_12));
            v355_10.join_into((v356_13).clone());
            }
            v355_10_cursor.ascend(1);
          }
          drop(v355_10_cursor);
          compose(&(v350_9),&(v355_10))
        };
        drop(v350_9);
        let v350_12: Space = unite(&(v350_7),&(v350_11));
        v349_12.join_into((v350_12).clone());
        }
        v349_12_cursor.ascend(1);
      }
      drop(v349_12_cursor);
      drop(v349_11);
      compose(&(v338_10),&(v349_12))
    };
    drop(v338_10);
    let v338_14: Space = unite(&(v338_8),&(v338_13));
    v337_28.join_into((v338_14).clone());
    }
    v337_28_cursor.ascend(1);
  }
  drop(v337_28_cursor);
  drop(v337_9);
  (v337_28).clone()
}

fn routine_17(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v359_21 = Space::new();
  let mut v359_21_cursor = (*s0).read_zipper();
  for v359_21_byte in v359_21_cursor.child_mask().iter() {
    v359_21_cursor.descend_to_byte(v359_21_byte);
    {
    let v359_21_tail = v359_21_cursor.fork_read_zipper();
    let v359_21_head = Path::from_slice(&[v359_21_byte]);
    let v360_2: Space = singleton(&(v359_21_head));
    let v360_3: Space = intersect(&(*CONSTANT_2),&(v360_2));
    let v360_4: Space = if has_head(&(v360_3)) { singleton(&[]) } else { Space::new() };
    drop(v360_3);
    let v360_5: Space = subtract(&(*CONSTANT_1),&(v360_4));
    drop(v360_4);
    let v360_8: Space = if (v360_5).is_empty() { Space::new() } else {
      let v361_6: Path = concat_path(&(*p0),&(v359_21_head));
      let mut v361_7 = Space::new();
      let mut v361_7_cursor = (v359_21_tail).read_zipper();
      for v361_7_byte in v361_7_cursor.child_mask().iter() {
        v361_7_cursor.descend_to_byte(v361_7_byte);
        {
        let v361_7_tail = v361_7_cursor.fork_read_zipper();
        let v361_7_head = Path::from_slice(&[v361_7_byte]);
        let v362_2: Space = singleton(&(v361_7_head));
        let v362_3: Space = intersect(&(*CONSTANT_2),&(v362_2));
        let v362_4: Space = if has_head(&(v362_3)) { singleton(&[]) } else { Space::new() };
        drop(v362_3);
        let v362_5: Space = subtract(&(*CONSTANT_1),&(v362_4));
        drop(v362_4);
        let v362_8: Space = if (v362_5).is_empty() { Space::new() } else {
          let v363_6: Path = concat_path(&(v361_6),&(v361_7_head));
          let mut v363_7 = Space::new();
          let mut v363_7_cursor = (v361_7_tail).read_zipper();
          for v363_7_byte in v363_7_cursor.child_mask().iter() {
            v363_7_cursor.descend_to_byte(v363_7_byte);
            {
            let v363_7_tail = v363_7_cursor.fork_read_zipper();
            let v363_7_head = Path::from_slice(&[v363_7_byte]);
            let v364_2: Space = singleton(&(v363_7_head));
            let v364_3: Space = intersect(&(*CONSTANT_2),&(v364_2));
            let v364_4: Space = if has_head(&(v364_3)) { singleton(&[]) } else { Space::new() };
            drop(v364_3);
            let v364_5: Space = subtract(&(*CONSTANT_1),&(v364_4));
            drop(v364_4);
            let v364_8: Space = if (v364_5).is_empty() { Space::new() } else {
              let v365_6: Path = concat_path(&(v363_6),&(v363_7_head));
              let v365_7: Space = routine_32(c, &(v365_6), &(*p1), &(v363_7_tail).make_space());
              compose(&(v364_5),&(v365_7))
            };
            drop(v364_5);
            let v364_9: Space = intersect(&(*CONSTANT_2),&(v364_2));
            drop(v364_2);
            let v364_10: Space = if has_head(&(v364_9)) { singleton(&[]) } else { Space::new() };
            drop(v364_9);
            let v364_12: Space = if (v364_10).is_empty() { Space::new() } else {
              let v366_6: Path = concat_path(&(v363_6),&(v363_7_head));
              let v366_11: Space = routine_33(c, &(v366_6), &(*p1), &(v363_7_tail).make_space());
              drop(v366_6);
              compose(&(v364_10),&(v366_11))
            };
            drop(v364_10);
            let v364_13: Space = unite(&(v364_8),&(v364_12));
            v363_7.join_into((v364_13).clone());
            }
            v363_7_cursor.ascend(1);
          }
          drop(v363_7_cursor);
          compose(&(v362_5),&(v363_7))
        };
        drop(v362_5);
        let v362_9: Space = intersect(&(*CONSTANT_2),&(v362_2));
        drop(v362_2);
        let v362_10: Space = if has_head(&(v362_9)) { singleton(&[]) } else { Space::new() };
        drop(v362_9);
        let v362_12: Space = if (v362_10).is_empty() { Space::new() } else {
          let v367_6: Path = concat_path(&(v361_6),&(v361_7_head));
          let mut v367_11 = Space::new();
          let mut v367_11_cursor = (v361_7_tail).read_zipper();
          for v367_11_byte in v367_11_cursor.child_mask().iter() {
            v367_11_cursor.descend_to_byte(v367_11_byte);
            {
            let v367_11_tail = v367_11_cursor.fork_read_zipper();
            let v367_11_head = Path::from_slice(&[v367_11_byte]);
            let v368_2: Space = singleton(&(v367_11_head));
            let v368_3: Space = intersect(&(*CONSTANT_2),&(v368_2));
            let v368_4: Space = if has_head(&(v368_3)) { singleton(&[]) } else { Space::new() };
            drop(v368_3);
            let v368_5: Space = subtract(&(*CONSTANT_1),&(v368_4));
            drop(v368_4);
            let v368_8: Space = if (v368_5).is_empty() { Space::new() } else {
              let v369_6: Path = concat_path(&(v367_6),&(v367_11_head));
              let v369_7: Space = routine_32(c, &(v369_6), &(*p1), &(v367_11_tail).make_space());
              compose(&(v368_5),&(v369_7))
            };
            drop(v368_5);
            let v368_9: Space = intersect(&(*CONSTANT_2),&(v368_2));
            drop(v368_2);
            let v368_10: Space = if has_head(&(v368_9)) { singleton(&[]) } else { Space::new() };
            drop(v368_9);
            let v368_12: Space = if (v368_10).is_empty() { Space::new() } else {
              let v370_6: Path = concat_path(&(v367_6),&(v367_11_head));
              let v370_11: Space = routine_19(c, &(v370_6), &(*p1), &(v367_11_tail).make_space());
              drop(v370_6);
              compose(&(v368_10),&(v370_11))
            };
            drop(v368_10);
            let v368_13: Space = unite(&(v368_8),&(v368_12));
            v367_11.join_into((v368_13).clone());
            }
            v367_11_cursor.ascend(1);
          }
          drop(v367_11_cursor);
          drop(v367_6);
          compose(&(v362_10),&(v367_11))
        };
        drop(v362_10);
        let v362_13: Space = unite(&(v362_8),&(v362_12));
        v361_7.join_into((v362_13).clone());
        }
        v361_7_cursor.ascend(1);
      }
      drop(v361_7_cursor);
      compose(&(v360_5),&(v361_7))
    };
    drop(v360_5);
    let v360_9: Space = intersect(&(*CONSTANT_2),&(v360_2));
    drop(v360_2);
    let v360_10: Space = if has_head(&(v360_9)) { singleton(&[]) } else { Space::new() };
    drop(v360_9);
    let v360_12: Space = if (v360_10).is_empty() { Space::new() } else {
      let v371_6: Path = concat_path(&(*p0),&(v359_21_head));
      let mut v371_11 = Space::new();
      let mut v371_11_cursor = (v359_21_tail).read_zipper();
      for v371_11_byte in v371_11_cursor.child_mask().iter() {
        v371_11_cursor.descend_to_byte(v371_11_byte);
        {
        let v371_11_tail = v371_11_cursor.fork_read_zipper();
        let v371_11_head = Path::from_slice(&[v371_11_byte]);
        let v372_2: Space = singleton(&(v371_11_head));
        let v372_3: Space = intersect(&(*CONSTANT_2),&(v372_2));
        let v372_4: Space = if has_head(&(v372_3)) { singleton(&[]) } else { Space::new() };
        drop(v372_3);
        let v372_5: Space = subtract(&(*CONSTANT_1),&(v372_4));
        drop(v372_4);
        let v372_8: Space = if (v372_5).is_empty() { Space::new() } else {
          let v373_6: Path = concat_path(&(v371_6),&(v371_11_head));
          let mut v373_7 = Space::new();
          let mut v373_7_cursor = (v371_11_tail).read_zipper();
          for v373_7_byte in v373_7_cursor.child_mask().iter() {
            v373_7_cursor.descend_to_byte(v373_7_byte);
            {
            let v373_7_tail = v373_7_cursor.fork_read_zipper();
            let v373_7_head = Path::from_slice(&[v373_7_byte]);
            let v374_2: Space = singleton(&(v373_7_head));
            let v374_3: Space = intersect(&(*CONSTANT_2),&(v374_2));
            let v374_4: Space = if has_head(&(v374_3)) { singleton(&[]) } else { Space::new() };
            drop(v374_3);
            let v374_5: Space = subtract(&(*CONSTANT_1),&(v374_4));
            drop(v374_4);
            let v374_8: Space = if (v374_5).is_empty() { Space::new() } else {
              let v375_6: Path = concat_path(&(v373_6),&(v373_7_head));
              let v375_7: Space = routine_32(c, &(v375_6), &(*p1), &(v373_7_tail).make_space());
              compose(&(v374_5),&(v375_7))
            };
            drop(v374_5);
            let v374_9: Space = intersect(&(*CONSTANT_2),&(v374_2));
            drop(v374_2);
            let v374_10: Space = if has_head(&(v374_9)) { singleton(&[]) } else { Space::new() };
            drop(v374_9);
            let v374_12: Space = if (v374_10).is_empty() { Space::new() } else {
              let v376_6: Path = concat_path(&(v373_6),&(v373_7_head));
              let v376_11: Space = routine_33(c, &(v376_6), &(*p1), &(v373_7_tail).make_space());
              drop(v376_6);
              compose(&(v374_10),&(v376_11))
            };
            drop(v374_10);
            let v374_13: Space = unite(&(v374_8),&(v374_12));
            v373_7.join_into((v374_13).clone());
            }
            v373_7_cursor.ascend(1);
          }
          drop(v373_7_cursor);
          compose(&(v372_5),&(v373_7))
        };
        drop(v372_5);
        let v372_9: Space = intersect(&(*CONSTANT_2),&(v372_2));
        drop(v372_2);
        let v372_10: Space = if has_head(&(v372_9)) { singleton(&[]) } else { Space::new() };
        drop(v372_9);
        let v372_11: Space = compose(&(v372_10),&(v371_11_tail));
        drop(v372_10);
        let v377_6: Path = concat_path(&(v371_6),&(v371_11_head));
        let v372_12: Space = wrap(&(v372_11),&(v377_6));
        drop(v372_11);
        let v372_13: Space = wrap(&(v372_12),&(*p1));
        drop(v372_12);
        let v372_14: Space = unite(&(v372_8),&(v372_13));
        drop(v372_13);
        v371_11.join_into((v372_14).clone());
        }
        v371_11_cursor.ascend(1);
      }
      drop(v371_11_cursor);
      drop(v371_6);
      compose(&(v360_10),&(v371_11))
    };
    drop(v360_10);
    let v360_13: Space = unite(&(v360_8),&(v360_12));
    v359_21.join_into((v360_13).clone());
    }
    v359_21_cursor.ascend(1);
  }
  drop(v359_21_cursor);
  (v359_21).clone()
}

fn routine_18(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v378_15 = Space::new();
  let mut v378_15_cursor = (*s0).read_zipper();
  for v378_15_byte in v378_15_cursor.child_mask().iter() {
    v378_15_cursor.descend_to_byte(v378_15_byte);
    {
    let v378_15_tail = v378_15_cursor.fork_read_zipper();
    let v378_15_head = Path::from_slice(&[v378_15_byte]);
    let v379_2: Space = singleton(&(v378_15_head));
    let v379_3: Space = intersect(&(*CONSTANT_2),&(v379_2));
    let v379_4: Space = if has_head(&(v379_3)) { singleton(&[]) } else { Space::new() };
    drop(v379_3);
    let v379_5: Space = subtract(&(*CONSTANT_1),&(v379_4));
    drop(v379_4);
    let v379_8: Space = if (v379_5).is_empty() { Space::new() } else {
      let v380_6: Path = concat_path(&(*p0),&(v378_15_head));
      let mut v380_7 = Space::new();
      let mut v380_7_cursor = (v378_15_tail).read_zipper();
      for v380_7_byte in v380_7_cursor.child_mask().iter() {
        v380_7_cursor.descend_to_byte(v380_7_byte);
        {
        let v380_7_tail = v380_7_cursor.fork_read_zipper();
        let v380_7_head = Path::from_slice(&[v380_7_byte]);
        let v381_2: Space = singleton(&(v380_7_head));
        let v381_3: Space = intersect(&(*CONSTANT_2),&(v381_2));
        let v381_4: Space = if has_head(&(v381_3)) { singleton(&[]) } else { Space::new() };
        drop(v381_3);
        let v381_5: Space = subtract(&(*CONSTANT_1),&(v381_4));
        drop(v381_4);
        let v381_8: Space = if (v381_5).is_empty() { Space::new() } else {
          let v382_6: Path = concat_path(&(v380_6),&(v380_7_head));
          let mut v382_7 = Space::new();
          let mut v382_7_cursor = (v380_7_tail).read_zipper();
          for v382_7_byte in v382_7_cursor.child_mask().iter() {
            v382_7_cursor.descend_to_byte(v382_7_byte);
            {
            let v382_7_tail = v382_7_cursor.fork_read_zipper();
            let v382_7_head = Path::from_slice(&[v382_7_byte]);
            let v383_2: Space = singleton(&(v382_7_head));
            let v383_3: Space = intersect(&(*CONSTANT_2),&(v383_2));
            let v383_4: Space = if has_head(&(v383_3)) { singleton(&[]) } else { Space::new() };
            drop(v383_3);
            let v383_5: Space = subtract(&(*CONSTANT_1),&(v383_4));
            drop(v383_4);
            let v383_8: Space = if (v383_5).is_empty() { Space::new() } else {
              let v384_6: Path = concat_path(&(v382_6),&(v382_7_head));
              let v384_7: Space = routine_32(c, &(v384_6), &(*p1), &(v382_7_tail).make_space());
              compose(&(v383_5),&(v384_7))
            };
            drop(v383_5);
            let v383_9: Space = intersect(&(*CONSTANT_2),&(v383_2));
            drop(v383_2);
            let v383_10: Space = if has_head(&(v383_9)) { singleton(&[]) } else { Space::new() };
            drop(v383_9);
            let v383_12: Space = if (v383_10).is_empty() { Space::new() } else {
              let v385_6: Path = concat_path(&(v382_6),&(v382_7_head));
              let v385_11: Space = routine_33(c, &(v385_6), &(*p1), &(v382_7_tail).make_space());
              drop(v385_6);
              compose(&(v383_10),&(v385_11))
            };
            drop(v383_10);
            let v383_13: Space = unite(&(v383_8),&(v383_12));
            v382_7.join_into((v383_13).clone());
            }
            v382_7_cursor.ascend(1);
          }
          drop(v382_7_cursor);
          compose(&(v381_5),&(v382_7))
        };
        drop(v381_5);
        let v381_9: Space = intersect(&(*CONSTANT_2),&(v381_2));
        drop(v381_2);
        let v381_10: Space = if has_head(&(v381_9)) { singleton(&[]) } else { Space::new() };
        drop(v381_9);
        let v381_12: Space = if (v381_10).is_empty() { Space::new() } else {
          let v386_6: Path = concat_path(&(v380_6),&(v380_7_head));
          let mut v386_11 = Space::new();
          let mut v386_11_cursor = (v380_7_tail).read_zipper();
          for v386_11_byte in v386_11_cursor.child_mask().iter() {
            v386_11_cursor.descend_to_byte(v386_11_byte);
            {
            let v386_11_tail = v386_11_cursor.fork_read_zipper();
            let v386_11_head = Path::from_slice(&[v386_11_byte]);
            let v387_2: Space = singleton(&(v386_11_head));
            let v387_3: Space = intersect(&(*CONSTANT_2),&(v387_2));
            let v387_4: Space = if has_head(&(v387_3)) { singleton(&[]) } else { Space::new() };
            drop(v387_3);
            let v387_5: Space = subtract(&(*CONSTANT_1),&(v387_4));
            drop(v387_4);
            let v387_8: Space = if (v387_5).is_empty() { Space::new() } else {
              let v388_6: Path = concat_path(&(v386_6),&(v386_11_head));
              let v388_7: Space = routine_32(c, &(v388_6), &(*p1), &(v386_11_tail).make_space());
              compose(&(v387_5),&(v388_7))
            };
            drop(v387_5);
            let v387_9: Space = intersect(&(*CONSTANT_2),&(v387_2));
            drop(v387_2);
            let v387_10: Space = if has_head(&(v387_9)) { singleton(&[]) } else { Space::new() };
            drop(v387_9);
            let v387_12: Space = if (v387_10).is_empty() { Space::new() } else {
              let v389_6: Path = concat_path(&(v386_6),&(v386_11_head));
              let v389_11: Space = routine_19(c, &(v389_6), &(*p1), &(v386_11_tail).make_space());
              drop(v389_6);
              compose(&(v387_10),&(v389_11))
            };
            drop(v387_10);
            let v387_13: Space = unite(&(v387_8),&(v387_12));
            v386_11.join_into((v387_13).clone());
            }
            v386_11_cursor.ascend(1);
          }
          drop(v386_11_cursor);
          drop(v386_6);
          compose(&(v381_10),&(v386_11))
        };
        drop(v381_10);
        let v381_13: Space = unite(&(v381_8),&(v381_12));
        v380_7.join_into((v381_13).clone());
        }
        v380_7_cursor.ascend(1);
      }
      drop(v380_7_cursor);
      compose(&(v379_5),&(v380_7))
    };
    drop(v379_5);
    let v379_9: Space = intersect(&(*CONSTANT_2),&(v379_2));
    drop(v379_2);
    let v379_10: Space = if has_head(&(v379_9)) { singleton(&[]) } else { Space::new() };
    drop(v379_9);
    let v379_11: Space = compose(&(v379_10),&(v378_15_tail));
    drop(v379_10);
    let v390_6: Path = concat_path(&(*p0),&(v378_15_head));
    let v379_12: Space = wrap(&(v379_11),&(v390_6));
    drop(v379_11);
    let v379_13: Space = wrap(&(v379_12),&(*p1));
    drop(v379_12);
    let v379_14: Space = unite(&(v379_8),&(v379_13));
    drop(v379_13);
    v378_15.join_into((v379_14).clone());
    }
    v378_15_cursor.ascend(1);
  }
  drop(v378_15_cursor);
  (v378_15).clone()
}

fn routine_19(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v391_3: Space = wrap(&(*s0),&(*p0));
  let v391_4: Space = wrap(&(v391_3),&(*p1));
  drop(v391_3);
  (v391_4).clone()
}

fn routine_20(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v392_16 = Space::new();
  let mut v392_16_cursor = (*s0).read_zipper();
  for v392_16_byte in v392_16_cursor.child_mask().iter() {
    v392_16_cursor.descend_to_byte(v392_16_byte);
    {
    let v392_16_tail = v392_16_cursor.fork_read_zipper();
    let v392_16_head = Path::from_slice(&[v392_16_byte]);
    let v393_2: Space = singleton(&(v392_16_head));
    let v393_3: Space = intersect(&(*CONSTANT_2),&(v393_2));
    let v393_4: Space = if has_head(&(v393_3)) { singleton(&[]) } else { Space::new() };
    drop(v393_3);
    let v393_5: Space = subtract(&(*CONSTANT_1),&(v393_4));
    drop(v393_4);
    let v393_8: Space = if (v393_5).is_empty() { Space::new() } else {
      let v394_6: Path = concat_path(&(*p0),&(v392_16_head));
      let mut v394_7 = Space::new();
      let mut v394_7_cursor = (v392_16_tail).read_zipper();
      for v394_7_byte in v394_7_cursor.child_mask().iter() {
        v394_7_cursor.descend_to_byte(v394_7_byte);
        {
        let v394_7_tail = v394_7_cursor.fork_read_zipper();
        let v394_7_head = Path::from_slice(&[v394_7_byte]);
        let v395_2: Space = singleton(&(v394_7_head));
        let v395_3: Space = intersect(&(*CONSTANT_2),&(v395_2));
        let v395_4: Space = if has_head(&(v395_3)) { singleton(&[]) } else { Space::new() };
        drop(v395_3);
        let v395_5: Space = subtract(&(*CONSTANT_1),&(v395_4));
        drop(v395_4);
        let mut v395_6 = Space::new();
        let mut v395_6_cursor = (v394_7_tail).read_zipper();
        for v395_6_byte in v395_6_cursor.child_mask().iter() {
          v395_6_cursor.descend_to_byte(v395_6_byte);
          {
          let v395_6_tail = v395_6_cursor.fork_read_zipper();
          let v395_6_head = Path::from_slice(&[v395_6_byte]);
          let v396_2: Space = Space::new();
          v395_6.join_into((v396_2).clone());
          }
          v395_6_cursor.ascend(1);
        }
        drop(v395_6_cursor);
        let v395_7: Space = compose(&(v395_5),&(v395_6));
        drop(v395_5);
        drop(v395_6);
        let v395_8: Space = intersect(&(*CONSTANT_2),&(v395_2));
        drop(v395_2);
        let v395_9: Space = if has_head(&(v395_8)) { singleton(&[]) } else { Space::new() };
        drop(v395_8);
        let v395_12: Space = if (v395_9).is_empty() { Space::new() } else {
          let v397_10: Path = concat_path(&(v394_6),&(v394_7_head));
          let mut v397_11 = Space::new();
          let mut v397_11_cursor = (v394_7_tail).read_zipper();
          for v397_11_byte in v397_11_cursor.child_mask().iter() {
            v397_11_cursor.descend_to_byte(v397_11_byte);
            {
            let v397_11_tail = v397_11_cursor.fork_read_zipper();
            let v397_11_head = Path::from_slice(&[v397_11_byte]);
            let v398_2: Space = singleton(&(v397_11_head));
            let v398_3: Space = intersect(&(*CONSTANT_2),&(v398_2));
            drop(v398_2);
            let v398_4: Space = if has_head(&(v398_3)) { singleton(&[]) } else { Space::new() };
            drop(v398_3);
            let v398_7: Space = if (v398_4).is_empty() { Space::new() } else {
              let v399_5: Path = concat_path(&(v397_10),&(v397_11_head));
              let v399_6: Space = routine_3(c, &(v399_5), &(v397_11_tail).make_space(), &(*s1));
              drop(v399_5);
              compose(&(v398_4),&(v399_6))
            };
            drop(v398_4);
            v397_11.join_into((v398_7).clone());
            }
            v397_11_cursor.ascend(1);
          }
          drop(v397_11_cursor);
          drop(v397_10);
          compose(&(v395_9),&(v397_11))
        };
        drop(v395_9);
        let v395_13: Space = unite(&(v395_7),&(v395_12));
        drop(v395_7);
        v394_7.join_into((v395_13).clone());
        }
        v394_7_cursor.ascend(1);
      }
      drop(v394_7_cursor);
      compose(&(v393_5),&(v394_7))
    };
    drop(v393_5);
    let v393_9: Space = intersect(&(*CONSTANT_2),&(v393_2));
    drop(v393_2);
    let v393_10: Space = if has_head(&(v393_9)) { singleton(&[]) } else { Space::new() };
    drop(v393_9);
    let v393_12: Space = if (v393_10).is_empty() { Space::new() } else {
      let v400_6: Path = concat_path(&(*p0),&(v392_16_head));
      let mut v400_11 = Space::new();
      let mut v400_11_cursor = (v392_16_tail).read_zipper();
      for v400_11_byte in v400_11_cursor.child_mask().iter() {
        v400_11_cursor.descend_to_byte(v400_11_byte);
        {
        let v400_11_tail = v400_11_cursor.fork_read_zipper();
        let v400_11_head = Path::from_slice(&[v400_11_byte]);
        let v401_2: Space = singleton(&(v400_11_head));
        let v401_3: Space = intersect(&(*CONSTANT_2),&(v401_2));
        let v401_4: Space = if has_head(&(v401_3)) { singleton(&[]) } else { Space::new() };
        drop(v401_3);
        let v401_5: Space = subtract(&(*CONSTANT_1),&(v401_4));
        drop(v401_4);
        let mut v401_6 = Space::new();
        let mut v401_6_cursor = (v400_11_tail).read_zipper();
        for v401_6_byte in v401_6_cursor.child_mask().iter() {
          v401_6_cursor.descend_to_byte(v401_6_byte);
          {
          let v401_6_tail = v401_6_cursor.fork_read_zipper();
          let v401_6_head = Path::from_slice(&[v401_6_byte]);
          let v402_2: Space = Space::new();
          v401_6.join_into((v402_2).clone());
          }
          v401_6_cursor.ascend(1);
        }
        drop(v401_6_cursor);
        let v401_7: Space = compose(&(v401_5),&(v401_6));
        drop(v401_5);
        drop(v401_6);
        let v401_8: Space = intersect(&(*CONSTANT_2),&(v401_2));
        drop(v401_2);
        let v401_9: Space = if has_head(&(v401_8)) { singleton(&[]) } else { Space::new() };
        drop(v401_8);
        let v401_12: Space = if (v401_9).is_empty() { Space::new() } else {
          let v403_10: Path = concat_path(&(v400_6),&(v400_11_head));
          let mut v403_11 = Space::new();
          let mut v403_11_cursor = (v400_11_tail).read_zipper();
          for v403_11_byte in v403_11_cursor.child_mask().iter() {
            v403_11_cursor.descend_to_byte(v403_11_byte);
            {
            let v403_11_tail = v403_11_cursor.fork_read_zipper();
            let v403_11_head = Path::from_slice(&[v403_11_byte]);
            let v404_2: Space = singleton(&(v403_11_head));
            let v404_3: Space = intersect(&(*CONSTANT_2),&(v404_2));
            let v404_4: Space = if has_head(&(v404_3)) { singleton(&[]) } else { Space::new() };
            drop(v404_3);
            let v404_5: Space = subtract(&(*CONSTANT_1),&(v404_4));
            drop(v404_4);
            let v404_7: Space = if (v404_5).is_empty() { Space::new() } else {
              let v405_6: Space = routine_4(c, &(v403_11_head), &(v403_10), &(v403_11_tail).make_space(), &(*s1));
              compose(&(v404_5),&(v405_6))
            };
            drop(v404_5);
            let v404_8: Space = intersect(&(*CONSTANT_2),&(v404_2));
            drop(v404_2);
            let v404_9: Space = if has_head(&(v404_8)) { singleton(&[]) } else { Space::new() };
            drop(v404_8);
            let v404_11: Space = if (v404_9).is_empty() { Space::new() } else {
              let v406_10: Space = routine_5(c, &(v403_11_head), &(v403_10), &(v403_11_tail).make_space(), &(*s1));
              compose(&(v404_9),&(v406_10))
            };
            drop(v404_9);
            let v404_12: Space = unite(&(v404_7),&(v404_11));
            v403_11.join_into((v404_12).clone());
            }
            v403_11_cursor.ascend(1);
          }
          drop(v403_11_cursor);
          drop(v403_10);
          compose(&(v401_9),&(v403_11))
        };
        drop(v401_9);
        let v401_13: Space = unite(&(v401_7),&(v401_12));
        drop(v401_7);
        v400_11.join_into((v401_13).clone());
        }
        v400_11_cursor.ascend(1);
      }
      drop(v400_11_cursor);
      drop(v400_6);
      compose(&(v393_10),&(v400_11))
    };
    drop(v393_10);
    let v393_13: Space = unite(&(v393_8),&(v393_12));
    v392_16.join_into((v393_13).clone());
    }
    v392_16_cursor.ascend(1);
  }
  drop(v392_16_cursor);
  (v392_16).clone()
}

fn routine_21(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v407_19 = Space::new();
  let mut v407_19_cursor = (*s0).read_zipper();
  for v407_19_byte in v407_19_cursor.child_mask().iter() {
    v407_19_cursor.descend_to_byte(v407_19_byte);
    {
    let v407_19_tail = v407_19_cursor.fork_read_zipper();
    let v407_19_head = Path::from_slice(&[v407_19_byte]);
    let v408_2: Space = singleton(&(v407_19_head));
    let v408_3: Space = intersect(&(*CONSTANT_2),&(v408_2));
    let v408_4: Space = if has_head(&(v408_3)) { singleton(&[]) } else { Space::new() };
    drop(v408_3);
    let v408_5: Space = subtract(&(*CONSTANT_1),&(v408_4));
    drop(v408_4);
    let v408_8: Space = if (v408_5).is_empty() { Space::new() } else {
      let v409_6: Path = concat_path(&(*p0),&(v407_19_head));
      let mut v409_7 = Space::new();
      let mut v409_7_cursor = (v407_19_tail).read_zipper();
      for v409_7_byte in v409_7_cursor.child_mask().iter() {
        v409_7_cursor.descend_to_byte(v409_7_byte);
        {
        let v409_7_tail = v409_7_cursor.fork_read_zipper();
        let v409_7_head = Path::from_slice(&[v409_7_byte]);
        let v410_2: Space = singleton(&(v409_7_head));
        let v410_3: Space = intersect(&(*CONSTANT_2),&(v410_2));
        let v410_4: Space = if has_head(&(v410_3)) { singleton(&[]) } else { Space::new() };
        drop(v410_3);
        let v410_5: Space = subtract(&(*CONSTANT_1),&(v410_4));
        drop(v410_4);
        let mut v410_6 = Space::new();
        let mut v410_6_cursor = (v409_7_tail).read_zipper();
        for v410_6_byte in v410_6_cursor.child_mask().iter() {
          v410_6_cursor.descend_to_byte(v410_6_byte);
          {
          let v410_6_tail = v410_6_cursor.fork_read_zipper();
          let v410_6_head = Path::from_slice(&[v410_6_byte]);
          let v411_2: Space = Space::new();
          v410_6.join_into((v411_2).clone());
          }
          v410_6_cursor.ascend(1);
        }
        drop(v410_6_cursor);
        let v410_7: Space = compose(&(v410_5),&(v410_6));
        drop(v410_5);
        drop(v410_6);
        let v410_8: Space = intersect(&(*CONSTANT_2),&(v410_2));
        drop(v410_2);
        let v410_9: Space = if has_head(&(v410_8)) { singleton(&[]) } else { Space::new() };
        drop(v410_8);
        let v410_12: Space = if (v410_9).is_empty() { Space::new() } else {
          let v412_10: Path = concat_path(&(v409_6),&(v409_7_head));
          let mut v412_11 = Space::new();
          let mut v412_11_cursor = (v409_7_tail).read_zipper();
          for v412_11_byte in v412_11_cursor.child_mask().iter() {
            v412_11_cursor.descend_to_byte(v412_11_byte);
            {
            let v412_11_tail = v412_11_cursor.fork_read_zipper();
            let v412_11_head = Path::from_slice(&[v412_11_byte]);
            let v413_2: Space = singleton(&(v412_11_head));
            let v413_3: Space = intersect(&(*CONSTANT_2),&(v413_2));
            drop(v413_2);
            let v413_4: Space = if has_head(&(v413_3)) { singleton(&[]) } else { Space::new() };
            drop(v413_3);
            let v413_7: Space = if (v413_4).is_empty() { Space::new() } else {
              let v414_5: Path = concat_path(&(v412_10),&(v412_11_head));
              let v414_6: Space = routine_3(c, &(v414_5), &(v412_11_tail).make_space(), &(*s1));
              drop(v414_5);
              compose(&(v413_4),&(v414_6))
            };
            drop(v413_4);
            v412_11.join_into((v413_7).clone());
            }
            v412_11_cursor.ascend(1);
          }
          drop(v412_11_cursor);
          drop(v412_10);
          compose(&(v410_9),&(v412_11))
        };
        drop(v410_9);
        let v410_13: Space = unite(&(v410_7),&(v410_12));
        drop(v410_7);
        v409_7.join_into((v410_13).clone());
        }
        v409_7_cursor.ascend(1);
      }
      drop(v409_7_cursor);
      compose(&(v408_5),&(v409_7))
    };
    drop(v408_5);
    let v408_9: Space = intersect(&(*CONSTANT_2),&(v408_2));
    drop(v408_2);
    let v408_10: Space = if has_head(&(v408_9)) { singleton(&[]) } else { Space::new() };
    drop(v408_9);
    let v408_12: Space = if (v408_10).is_empty() { Space::new() } else {
      let v415_6: Path = concat_path(&(*p0),&(v407_19_head));
      let mut v415_11 = Space::new();
      let mut v415_11_cursor = (v407_19_tail).read_zipper();
      for v415_11_byte in v415_11_cursor.child_mask().iter() {
        v415_11_cursor.descend_to_byte(v415_11_byte);
        {
        let v415_11_tail = v415_11_cursor.fork_read_zipper();
        let v415_11_head = Path::from_slice(&[v415_11_byte]);
        let v416_2: Space = singleton(&(v415_11_head));
        let v416_3: Space = intersect(&(*CONSTANT_2),&(v416_2));
        let v416_4: Space = if has_head(&(v416_3)) { singleton(&[]) } else { Space::new() };
        drop(v416_3);
        let v416_5: Space = subtract(&(*CONSTANT_1),&(v416_4));
        drop(v416_4);
        let v416_7: Space = if (v416_5).is_empty() { Space::new() } else {
          let mut v417_6 = Space::new();
          let mut v417_6_cursor = (v415_11_tail).read_zipper();
          for v417_6_byte in v417_6_cursor.child_mask().iter() {
            v417_6_cursor.descend_to_byte(v417_6_byte);
            {
            let v417_6_tail = v417_6_cursor.fork_read_zipper();
            let v417_6_head = Path::from_slice(&[v417_6_byte]);
            let v418_2: Space = singleton(&(v417_6_head));
            let v418_3: Space = intersect(&(*CONSTANT_2),&(v418_2));
            let v418_4: Space = if has_head(&(v418_3)) { singleton(&[]) } else { Space::new() };
            drop(v418_3);
            let v418_5: Space = subtract(&(*CONSTANT_1),&(v418_4));
            drop(v418_4);
            let v418_8: Space = if (v418_5).is_empty() { Space::new() } else {
              let v419_6: Path = concat_path(&(v415_11_head),&(v417_6_head));
              let v419_7: Space = routine_8(c, &(v419_6), &(v415_6), &(v417_6_tail).make_space(), &(*s1));
              compose(&(v418_5),&(v419_7))
            };
            drop(v418_5);
            let v418_9: Space = intersect(&(*CONSTANT_2),&(v418_2));
            drop(v418_2);
            let v418_10: Space = if has_head(&(v418_9)) { singleton(&[]) } else { Space::new() };
            drop(v418_9);
            let v418_12: Space = if (v418_10).is_empty() { Space::new() } else {
              let v420_6: Path = concat_path(&(v415_11_head),&(v417_6_head));
              let v420_11: Space = routine_9(c, &(v420_6), &(v415_6), &(v417_6_tail).make_space(), &(*s1));
              drop(v420_6);
              compose(&(v418_10),&(v420_11))
            };
            drop(v418_10);
            let v418_13: Space = unite(&(v418_8),&(v418_12));
            v417_6.join_into((v418_13).clone());
            }
            v417_6_cursor.ascend(1);
          }
          drop(v417_6_cursor);
          compose(&(v416_5),&(v417_6))
        };
        drop(v416_5);
        let v416_8: Space = intersect(&(*CONSTANT_2),&(v416_2));
        drop(v416_2);
        let v416_9: Space = if has_head(&(v416_8)) { singleton(&[]) } else { Space::new() };
        drop(v416_8);
        let v416_11: Space = if (v416_9).is_empty() { Space::new() } else {
          let mut v421_10 = Space::new();
          let mut v421_10_cursor = (v415_11_tail).read_zipper();
          for v421_10_byte in v421_10_cursor.child_mask().iter() {
            v421_10_cursor.descend_to_byte(v421_10_byte);
            {
            let v421_10_tail = v421_10_cursor.fork_read_zipper();
            let v421_10_head = Path::from_slice(&[v421_10_byte]);
            let v422_2: Space = singleton(&(v421_10_head));
            let v422_3: Space = intersect(&(*CONSTANT_2),&(v422_2));
            let v422_4: Space = if has_head(&(v422_3)) { singleton(&[]) } else { Space::new() };
            drop(v422_3);
            let v422_5: Space = subtract(&(*CONSTANT_1),&(v422_4));
            drop(v422_4);
            let v422_8: Space = if (v422_5).is_empty() { Space::new() } else {
              let v423_6: Path = concat_path(&(v415_11_head),&(v421_10_head));
              let v423_7: Space = routine_8(c, &(v423_6), &(v415_6), &(v421_10_tail).make_space(), &(*s1));
              compose(&(v422_5),&(v423_7))
            };
            drop(v422_5);
            let v422_9: Space = intersect(&(*CONSTANT_2),&(v422_2));
            drop(v422_2);
            let v422_10: Space = if has_head(&(v422_9)) { singleton(&[]) } else { Space::new() };
            drop(v422_9);
            let v422_12: Space = if (v422_10).is_empty() { Space::new() } else {
              let v424_6: Path = concat_path(&(v415_11_head),&(v421_10_head));
              let v424_11: Space = routine_10(c, &(v424_6), &(v415_6), &(v421_10_tail).make_space(), &(*s1));
              drop(v424_6);
              compose(&(v422_10),&(v424_11))
            };
            drop(v422_10);
            let v422_13: Space = unite(&(v422_8),&(v422_12));
            v421_10.join_into((v422_13).clone());
            }
            v421_10_cursor.ascend(1);
          }
          drop(v421_10_cursor);
          compose(&(v416_9),&(v421_10))
        };
        drop(v416_9);
        let v416_12: Space = unite(&(v416_7),&(v416_11));
        v415_11.join_into((v416_12).clone());
        }
        v415_11_cursor.ascend(1);
      }
      drop(v415_11_cursor);
      drop(v415_6);
      compose(&(v408_10),&(v415_11))
    };
    drop(v408_10);
    let v408_13: Space = unite(&(v408_8),&(v408_12));
    v407_19.join_into((v408_13).clone());
    }
    v407_19_cursor.ascend(1);
  }
  drop(v407_19_cursor);
  (v407_19).clone()
}

fn routine_22(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v425_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v425_21: Space = unwrap(&(v425_20),&(*p0));
  drop(v425_20);
  let mut v425_28 = Space::new();
  let mut v425_28_cursor = (*s0).read_zipper();
  for v425_28_byte in v425_28_cursor.child_mask().iter() {
    v425_28_cursor.descend_to_byte(v425_28_byte);
    {
    let v425_28_tail = v425_28_cursor.fork_read_zipper();
    let v425_28_head = Path::from_slice(&[v425_28_byte]);
    let v426_2: Space = singleton(&(v425_28_head));
    let v426_3: Space = intersect(&(*CONSTANT_2),&(v426_2));
    let v426_4: Space = if has_head(&(v426_3)) { singleton(&[]) } else { Space::new() };
    drop(v426_3);
    let v426_5: Space = subtract(&(*CONSTANT_1),&(v426_4));
    drop(v426_4);
    let v426_8: Space = if (v426_5).is_empty() { Space::new() } else {
      let v427_6: Path = concat_path(&(*p0),&(v425_28_head));
      let mut v427_7 = Space::new();
      let mut v427_7_cursor = (v425_28_tail).read_zipper();
      for v427_7_byte in v427_7_cursor.child_mask().iter() {
        v427_7_cursor.descend_to_byte(v427_7_byte);
        {
        let v427_7_tail = v427_7_cursor.fork_read_zipper();
        let v427_7_head = Path::from_slice(&[v427_7_byte]);
        let v428_2: Space = singleton(&(v427_7_head));
        let v428_3: Space = intersect(&(*CONSTANT_2),&(v428_2));
        let v428_4: Space = if has_head(&(v428_3)) { singleton(&[]) } else { Space::new() };
        drop(v428_3);
        let v428_5: Space = subtract(&(*CONSTANT_1),&(v428_4));
        drop(v428_4);
        let v428_8: Space = if (v428_5).is_empty() { Space::new() } else {
          let v429_6: Path = concat_path(&(v427_6),&(v427_7_head));
          let mut v429_7 = Space::new();
          let mut v429_7_cursor = (v427_7_tail).read_zipper();
          for v429_7_byte in v429_7_cursor.child_mask().iter() {
            v429_7_cursor.descend_to_byte(v429_7_byte);
            {
            let v429_7_tail = v429_7_cursor.fork_read_zipper();
            let v429_7_head = Path::from_slice(&[v429_7_byte]);
            let v430_2: Space = singleton(&(v429_7_head));
            let v430_3: Space = intersect(&(*CONSTANT_2),&(v430_2));
            let v430_4: Space = if has_head(&(v430_3)) { singleton(&[]) } else { Space::new() };
            drop(v430_3);
            let v430_5: Space = subtract(&(*CONSTANT_1),&(v430_4));
            drop(v430_4);
            let v430_8: Space = if (v430_5).is_empty() { Space::new() } else {
              let v431_6: Path = concat_path(&(v429_6),&(v429_7_head));
              let v431_7: Space = routine_34(c, &(v431_6), &(*p1), &(v429_7_tail).make_space(), &(*s1));
              compose(&(v430_5),&(v431_7))
            };
            drop(v430_5);
            let v430_9: Space = intersect(&(*CONSTANT_2),&(v430_2));
            drop(v430_2);
            let v430_10: Space = if has_head(&(v430_9)) { singleton(&[]) } else { Space::new() };
            drop(v430_9);
            let v430_12: Space = if (v430_10).is_empty() { Space::new() } else {
              let v432_6: Path = concat_path(&(v429_6),&(v429_7_head));
              let v432_11: Space = routine_35(c, &(v432_6), &(*p1), &(v429_7_tail).make_space(), &(*s1));
              drop(v432_6);
              compose(&(v430_10),&(v432_11))
            };
            drop(v430_10);
            let v430_13: Space = unite(&(v430_8),&(v430_12));
            v429_7.join_into((v430_13).clone());
            }
            v429_7_cursor.ascend(1);
          }
          drop(v429_7_cursor);
          compose(&(v428_5),&(v429_7))
        };
        drop(v428_5);
        let v428_9: Space = intersect(&(*CONSTANT_2),&(v428_2));
        drop(v428_2);
        let v428_10: Space = if has_head(&(v428_9)) { singleton(&[]) } else { Space::new() };
        drop(v428_9);
        let v428_12: Space = if (v428_10).is_empty() { Space::new() } else {
          let v433_6: Path = concat_path(&(v427_6),&(v427_7_head));
          let mut v433_11 = Space::new();
          let mut v433_11_cursor = (v427_7_tail).read_zipper();
          for v433_11_byte in v433_11_cursor.child_mask().iter() {
            v433_11_cursor.descend_to_byte(v433_11_byte);
            {
            let v433_11_tail = v433_11_cursor.fork_read_zipper();
            let v433_11_head = Path::from_slice(&[v433_11_byte]);
            let v434_2: Space = singleton(&(v433_11_head));
            let v434_3: Space = intersect(&(*CONSTANT_2),&(v434_2));
            let v434_4: Space = if has_head(&(v434_3)) { singleton(&[]) } else { Space::new() };
            drop(v434_3);
            let v434_5: Space = subtract(&(*CONSTANT_1),&(v434_4));
            drop(v434_4);
            let v434_8: Space = if (v434_5).is_empty() { Space::new() } else {
              let v435_6: Path = concat_path(&(v433_6),&(v433_11_head));
              let v435_7: Space = routine_34(c, &(v435_6), &(*p1), &(v433_11_tail).make_space(), &(*s1));
              compose(&(v434_5),&(v435_7))
            };
            drop(v434_5);
            let v434_9: Space = intersect(&(*CONSTANT_2),&(v434_2));
            drop(v434_2);
            let v434_10: Space = if has_head(&(v434_9)) { singleton(&[]) } else { Space::new() };
            drop(v434_9);
            let v434_12: Space = if (v434_10).is_empty() { Space::new() } else {
              let v436_6: Path = concat_path(&(v433_6),&(v433_11_head));
              let v436_11: Space = routine_10(c, &(v436_6), &(*p1), &(v433_11_tail).make_space(), &(*s1));
              drop(v436_6);
              compose(&(v434_10),&(v436_11))
            };
            drop(v434_10);
            let v434_13: Space = unite(&(v434_8),&(v434_12));
            v433_11.join_into((v434_13).clone());
            }
            v433_11_cursor.ascend(1);
          }
          drop(v433_11_cursor);
          drop(v433_6);
          compose(&(v428_10),&(v433_11))
        };
        drop(v428_10);
        let v428_13: Space = unite(&(v428_8),&(v428_12));
        v427_7.join_into((v428_13).clone());
        }
        v427_7_cursor.ascend(1);
      }
      drop(v427_7_cursor);
      compose(&(v426_5),&(v427_7))
    };
    drop(v426_5);
    let v426_9: Space = intersect(&(*CONSTANT_2),&(v426_2));
    drop(v426_2);
    let v426_10: Space = if has_head(&(v426_9)) { singleton(&[]) } else { Space::new() };
    drop(v426_9);
    let v426_13: Space = if (v426_10).is_empty() { Space::new() } else {
      let v437_6: Path = concat_path(&(*p0),&(v425_28_head));
      let v437_11: Space = unwrap(&(v425_21),&(v425_28_head));
      let mut v437_12 = Space::new();
      let mut v437_12_cursor = (v425_28_tail).read_zipper();
      for v437_12_byte in v437_12_cursor.child_mask().iter() {
        v437_12_cursor.descend_to_byte(v437_12_byte);
        {
        let v437_12_tail = v437_12_cursor.fork_read_zipper();
        let v437_12_head = Path::from_slice(&[v437_12_byte]);
        let v438_2: Space = singleton(&(v437_12_head));
        let v438_3: Space = intersect(&(*CONSTANT_2),&(v438_2));
        let v438_4: Space = if has_head(&(v438_3)) { singleton(&[]) } else { Space::new() };
        drop(v438_3);
        let v438_5: Space = subtract(&(*CONSTANT_1),&(v438_4));
        drop(v438_4);
        let v438_8: Space = if (v438_5).is_empty() { Space::new() } else {
          let v439_6: Path = concat_path(&(v437_6),&(v437_12_head));
          let mut v439_7 = Space::new();
          let mut v439_7_cursor = (v437_12_tail).read_zipper();
          for v439_7_byte in v439_7_cursor.child_mask().iter() {
            v439_7_cursor.descend_to_byte(v439_7_byte);
            {
            let v439_7_tail = v439_7_cursor.fork_read_zipper();
            let v439_7_head = Path::from_slice(&[v439_7_byte]);
            let v440_2: Space = singleton(&(v439_7_head));
            let v440_3: Space = intersect(&(*CONSTANT_2),&(v440_2));
            let v440_4: Space = if has_head(&(v440_3)) { singleton(&[]) } else { Space::new() };
            drop(v440_3);
            let v440_5: Space = subtract(&(*CONSTANT_1),&(v440_4));
            drop(v440_4);
            let v440_8: Space = if (v440_5).is_empty() { Space::new() } else {
              let v441_6: Path = concat_path(&(v439_6),&(v439_7_head));
              let v441_7: Space = routine_34(c, &(v441_6), &(*p1), &(v439_7_tail).make_space(), &(*s1));
              compose(&(v440_5),&(v441_7))
            };
            drop(v440_5);
            let v440_9: Space = intersect(&(*CONSTANT_2),&(v440_2));
            drop(v440_2);
            let v440_10: Space = if has_head(&(v440_9)) { singleton(&[]) } else { Space::new() };
            drop(v440_9);
            let v440_12: Space = if (v440_10).is_empty() { Space::new() } else {
              let v442_6: Path = concat_path(&(v439_6),&(v439_7_head));
              let v442_11: Space = routine_35(c, &(v442_6), &(*p1), &(v439_7_tail).make_space(), &(*s1));
              drop(v442_6);
              compose(&(v440_10),&(v442_11))
            };
            drop(v440_10);
            let v440_13: Space = unite(&(v440_8),&(v440_12));
            v439_7.join_into((v440_13).clone());
            }
            v439_7_cursor.ascend(1);
          }
          drop(v439_7_cursor);
          drop(v439_6);
          compose(&(v438_5),&(v439_7))
        };
        drop(v438_5);
        let v438_9: Space = intersect(&(*CONSTANT_2),&(v438_2));
        drop(v438_2);
        let v438_10: Space = if has_head(&(v438_9)) { singleton(&[]) } else { Space::new() };
        drop(v438_9);
        let v438_13: Space = if (v438_10).is_empty() { Space::new() } else {
          let v443_11: Space = unwrap(&(v437_11),&(v437_12_head));
          let mut v443_12 = Space::new();
          let mut v443_12_cursor = (v443_11).read_zipper();
          for v443_12_byte in v443_12_cursor.child_mask().iter() {
            v443_12_cursor.descend_to_byte(v443_12_byte);
            {
            let v443_12_tail = v443_12_cursor.fork_read_zipper();
            let v443_12_head = Path::from_slice(&[v443_12_byte]);
            let v444_2: Space = singleton(&(v443_12_head));
            let v444_3: Space = intersect(&(*CONSTANT_2),&(v444_2));
            let v444_4: Space = if has_head(&(v444_3)) { singleton(&[]) } else { Space::new() };
            drop(v444_3);
            let v444_5: Space = subtract(&(*CONSTANT_1),&(v444_4));
            drop(v444_4);
            let v444_7: Space = if (v444_5).is_empty() { Space::new() } else {
              let v445_6: Space = routine_13(c, &(v443_12_head), &(*p1), &(v443_12_tail).make_space());
              compose(&(v444_5),&(v445_6))
            };
            drop(v444_5);
            let v444_8: Space = intersect(&(*CONSTANT_2),&(v444_2));
            drop(v444_2);
            let v444_9: Space = if has_head(&(v444_8)) { singleton(&[]) } else { Space::new() };
            drop(v444_8);
            let v444_11: Space = if (v444_9).is_empty() { Space::new() } else {
              let v446_10: Space = routine_14(c, &(v443_12_head), &(*p1), &(v443_12_tail).make_space());
              compose(&(v444_9),&(v446_10))
            };
            drop(v444_9);
            let v444_12: Space = unite(&(v444_7),&(v444_11));
            v443_12.join_into((v444_12).clone());
            }
            v443_12_cursor.ascend(1);
          }
          drop(v443_12_cursor);
          drop(v443_11);
          compose(&(v438_10),&(v443_12))
        };
        drop(v438_10);
        let v438_14: Space = unite(&(v438_8),&(v438_13));
        v437_12.join_into((v438_14).clone());
        }
        v437_12_cursor.ascend(1);
      }
      drop(v437_12_cursor);
      drop(v437_6);
      drop(v437_11);
      compose(&(v426_10),&(v437_12))
    };
    drop(v426_10);
    let v426_14: Space = unite(&(v426_8),&(v426_13));
    v425_28.join_into((v426_14).clone());
    }
    v425_28_cursor.ascend(1);
  }
  drop(v425_28_cursor);
  drop(v425_21);
  (v425_28).clone()
}

fn routine_23(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v447_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v447_9: Space = unwrap(&(v447_8),&(*p0));
  drop(v447_8);
  let mut v447_28 = Space::new();
  let mut v447_28_cursor = (*s0).read_zipper();
  for v447_28_byte in v447_28_cursor.child_mask().iter() {
    v447_28_cursor.descend_to_byte(v447_28_byte);
    {
    let v447_28_tail = v447_28_cursor.fork_read_zipper();
    let v447_28_head = Path::from_slice(&[v447_28_byte]);
    let v448_2: Space = singleton(&(v447_28_head));
    let v448_3: Space = intersect(&(*CONSTANT_2),&(v448_2));
    let v448_4: Space = if has_head(&(v448_3)) { singleton(&[]) } else { Space::new() };
    drop(v448_3);
    let v448_5: Space = subtract(&(*CONSTANT_1),&(v448_4));
    drop(v448_4);
    let v448_8: Space = if (v448_5).is_empty() { Space::new() } else {
      let v449_6: Path = concat_path(&(*p0),&(v447_28_head));
      let mut v449_7 = Space::new();
      let mut v449_7_cursor = (v447_28_tail).read_zipper();
      for v449_7_byte in v449_7_cursor.child_mask().iter() {
        v449_7_cursor.descend_to_byte(v449_7_byte);
        {
        let v449_7_tail = v449_7_cursor.fork_read_zipper();
        let v449_7_head = Path::from_slice(&[v449_7_byte]);
        let v450_2: Space = singleton(&(v449_7_head));
        let v450_3: Space = intersect(&(*CONSTANT_2),&(v450_2));
        let v450_4: Space = if has_head(&(v450_3)) { singleton(&[]) } else { Space::new() };
        drop(v450_3);
        let v450_5: Space = subtract(&(*CONSTANT_1),&(v450_4));
        drop(v450_4);
        let v450_8: Space = if (v450_5).is_empty() { Space::new() } else {
          let v451_6: Path = concat_path(&(v449_6),&(v449_7_head));
          let mut v451_7 = Space::new();
          let mut v451_7_cursor = (v449_7_tail).read_zipper();
          for v451_7_byte in v451_7_cursor.child_mask().iter() {
            v451_7_cursor.descend_to_byte(v451_7_byte);
            {
            let v451_7_tail = v451_7_cursor.fork_read_zipper();
            let v451_7_head = Path::from_slice(&[v451_7_byte]);
            let v452_2: Space = singleton(&(v451_7_head));
            let v452_3: Space = intersect(&(*CONSTANT_2),&(v452_2));
            let v452_4: Space = if has_head(&(v452_3)) { singleton(&[]) } else { Space::new() };
            drop(v452_3);
            let v452_5: Space = subtract(&(*CONSTANT_1),&(v452_4));
            drop(v452_4);
            let v452_8: Space = if (v452_5).is_empty() { Space::new() } else {
              let v453_6: Path = concat_path(&(v451_6),&(v451_7_head));
              let v453_7: Space = routine_34(c, &(v453_6), &(*p1), &(v451_7_tail).make_space(), &(*s1));
              compose(&(v452_5),&(v453_7))
            };
            drop(v452_5);
            let v452_9: Space = intersect(&(*CONSTANT_2),&(v452_2));
            drop(v452_2);
            let v452_10: Space = if has_head(&(v452_9)) { singleton(&[]) } else { Space::new() };
            drop(v452_9);
            let v452_12: Space = if (v452_10).is_empty() { Space::new() } else {
              let v454_6: Path = concat_path(&(v451_6),&(v451_7_head));
              let v454_11: Space = routine_35(c, &(v454_6), &(*p1), &(v451_7_tail).make_space(), &(*s1));
              drop(v454_6);
              compose(&(v452_10),&(v454_11))
            };
            drop(v452_10);
            let v452_13: Space = unite(&(v452_8),&(v452_12));
            v451_7.join_into((v452_13).clone());
            }
            v451_7_cursor.ascend(1);
          }
          drop(v451_7_cursor);
          compose(&(v450_5),&(v451_7))
        };
        drop(v450_5);
        let v450_9: Space = intersect(&(*CONSTANT_2),&(v450_2));
        drop(v450_2);
        let v450_10: Space = if has_head(&(v450_9)) { singleton(&[]) } else { Space::new() };
        drop(v450_9);
        let v450_12: Space = if (v450_10).is_empty() { Space::new() } else {
          let v455_6: Path = concat_path(&(v449_6),&(v449_7_head));
          let mut v455_11 = Space::new();
          let mut v455_11_cursor = (v449_7_tail).read_zipper();
          for v455_11_byte in v455_11_cursor.child_mask().iter() {
            v455_11_cursor.descend_to_byte(v455_11_byte);
            {
            let v455_11_tail = v455_11_cursor.fork_read_zipper();
            let v455_11_head = Path::from_slice(&[v455_11_byte]);
            let v456_2: Space = singleton(&(v455_11_head));
            let v456_3: Space = intersect(&(*CONSTANT_2),&(v456_2));
            let v456_4: Space = if has_head(&(v456_3)) { singleton(&[]) } else { Space::new() };
            drop(v456_3);
            let v456_5: Space = subtract(&(*CONSTANT_1),&(v456_4));
            drop(v456_4);
            let v456_8: Space = if (v456_5).is_empty() { Space::new() } else {
              let v457_6: Path = concat_path(&(v455_6),&(v455_11_head));
              let v457_7: Space = routine_34(c, &(v457_6), &(*p1), &(v455_11_tail).make_space(), &(*s1));
              compose(&(v456_5),&(v457_7))
            };
            drop(v456_5);
            let v456_9: Space = intersect(&(*CONSTANT_2),&(v456_2));
            drop(v456_2);
            let v456_10: Space = if has_head(&(v456_9)) { singleton(&[]) } else { Space::new() };
            drop(v456_9);
            let v456_12: Space = if (v456_10).is_empty() { Space::new() } else {
              let v458_6: Path = concat_path(&(v455_6),&(v455_11_head));
              let v458_11: Space = routine_10(c, &(v458_6), &(*p1), &(v455_11_tail).make_space(), &(*s1));
              drop(v458_6);
              compose(&(v456_10),&(v458_11))
            };
            drop(v456_10);
            let v456_13: Space = unite(&(v456_8),&(v456_12));
            v455_11.join_into((v456_13).clone());
            }
            v455_11_cursor.ascend(1);
          }
          drop(v455_11_cursor);
          drop(v455_6);
          compose(&(v450_10),&(v455_11))
        };
        drop(v450_10);
        let v450_13: Space = unite(&(v450_8),&(v450_12));
        v449_7.join_into((v450_13).clone());
        }
        v449_7_cursor.ascend(1);
      }
      drop(v449_7_cursor);
      drop(v449_6);
      compose(&(v448_5),&(v449_7))
    };
    drop(v448_5);
    let v448_9: Space = intersect(&(*CONSTANT_2),&(v448_2));
    drop(v448_2);
    let v448_10: Space = if has_head(&(v448_9)) { singleton(&[]) } else { Space::new() };
    drop(v448_9);
    let v448_13: Space = if (v448_10).is_empty() { Space::new() } else {
      let v459_11: Space = unwrap(&(v447_9),&(v447_28_head));
      let mut v459_12 = Space::new();
      let mut v459_12_cursor = (v459_11).read_zipper();
      for v459_12_byte in v459_12_cursor.child_mask().iter() {
        v459_12_cursor.descend_to_byte(v459_12_byte);
        {
        let v459_12_tail = v459_12_cursor.fork_read_zipper();
        let v459_12_head = Path::from_slice(&[v459_12_byte]);
        let v460_2: Space = singleton(&(v459_12_head));
        let v460_3: Space = intersect(&(*CONSTANT_2),&(v460_2));
        let v460_4: Space = if has_head(&(v460_3)) { singleton(&[]) } else { Space::new() };
        drop(v460_3);
        let v460_5: Space = subtract(&(*CONSTANT_1),&(v460_4));
        drop(v460_4);
        let v460_7: Space = if (v460_5).is_empty() { Space::new() } else {
          let mut v461_6 = Space::new();
          let mut v461_6_cursor = (v459_12_tail).read_zipper();
          for v461_6_byte in v461_6_cursor.child_mask().iter() {
            v461_6_cursor.descend_to_byte(v461_6_byte);
            {
            let v461_6_tail = v461_6_cursor.fork_read_zipper();
            let v461_6_head = Path::from_slice(&[v461_6_byte]);
            let v462_2: Space = singleton(&(v461_6_head));
            let v462_3: Space = intersect(&(*CONSTANT_2),&(v462_2));
            let v462_4: Space = if has_head(&(v462_3)) { singleton(&[]) } else { Space::new() };
            drop(v462_3);
            let v462_5: Space = subtract(&(*CONSTANT_1),&(v462_4));
            drop(v462_4);
            let v462_8: Space = if (v462_5).is_empty() { Space::new() } else {
              let v463_6: Path = concat_path(&(v459_12_head),&(v461_6_head));
              let v463_7: Space = routine_17(c, &(v463_6), &(*p1), &(v461_6_tail).make_space());
              compose(&(v462_5),&(v463_7))
            };
            drop(v462_5);
            let v462_9: Space = intersect(&(*CONSTANT_2),&(v462_2));
            drop(v462_2);
            let v462_10: Space = if has_head(&(v462_9)) { singleton(&[]) } else { Space::new() };
            drop(v462_9);
            let v462_12: Space = if (v462_10).is_empty() { Space::new() } else {
              let v464_6: Path = concat_path(&(v459_12_head),&(v461_6_head));
              let v464_11: Space = routine_18(c, &(v464_6), &(*p1), &(v461_6_tail).make_space());
              drop(v464_6);
              compose(&(v462_10),&(v464_11))
            };
            drop(v462_10);
            let v462_13: Space = unite(&(v462_8),&(v462_12));
            v461_6.join_into((v462_13).clone());
            }
            v461_6_cursor.ascend(1);
          }
          drop(v461_6_cursor);
          compose(&(v460_5),&(v461_6))
        };
        drop(v460_5);
        let v460_8: Space = intersect(&(*CONSTANT_2),&(v460_2));
        drop(v460_2);
        let v460_9: Space = if has_head(&(v460_8)) { singleton(&[]) } else { Space::new() };
        drop(v460_8);
        let v460_11: Space = if (v460_9).is_empty() { Space::new() } else {
          let mut v465_10 = Space::new();
          let mut v465_10_cursor = (v459_12_tail).read_zipper();
          for v465_10_byte in v465_10_cursor.child_mask().iter() {
            v465_10_cursor.descend_to_byte(v465_10_byte);
            {
            let v465_10_tail = v465_10_cursor.fork_read_zipper();
            let v465_10_head = Path::from_slice(&[v465_10_byte]);
            let v466_2: Space = singleton(&(v465_10_head));
            let v466_3: Space = intersect(&(*CONSTANT_2),&(v466_2));
            let v466_4: Space = if has_head(&(v466_3)) { singleton(&[]) } else { Space::new() };
            drop(v466_3);
            let v466_5: Space = subtract(&(*CONSTANT_1),&(v466_4));
            drop(v466_4);
            let v466_8: Space = if (v466_5).is_empty() { Space::new() } else {
              let v467_6: Path = concat_path(&(v459_12_head),&(v465_10_head));
              let v467_7: Space = routine_17(c, &(v467_6), &(*p1), &(v465_10_tail).make_space());
              compose(&(v466_5),&(v467_7))
            };
            drop(v466_5);
            let v466_9: Space = intersect(&(*CONSTANT_2),&(v466_2));
            drop(v466_2);
            let v466_10: Space = if has_head(&(v466_9)) { singleton(&[]) } else { Space::new() };
            drop(v466_9);
            let v466_12: Space = if (v466_10).is_empty() { Space::new() } else {
              let v468_6: Path = concat_path(&(v459_12_head),&(v465_10_head));
              let v468_11: Space = routine_19(c, &(v468_6), &(*p1), &(v465_10_tail).make_space());
              drop(v468_6);
              compose(&(v466_10),&(v468_11))
            };
            drop(v466_10);
            let v466_13: Space = unite(&(v466_8),&(v466_12));
            v465_10.join_into((v466_13).clone());
            }
            v465_10_cursor.ascend(1);
          }
          drop(v465_10_cursor);
          compose(&(v460_9),&(v465_10))
        };
        drop(v460_9);
        let v460_12: Space = unite(&(v460_7),&(v460_11));
        v459_12.join_into((v460_12).clone());
        }
        v459_12_cursor.ascend(1);
      }
      drop(v459_12_cursor);
      drop(v459_11);
      compose(&(v448_10),&(v459_12))
    };
    drop(v448_10);
    let v448_14: Space = unite(&(v448_8),&(v448_13));
    v447_28.join_into((v448_14).clone());
    }
    v447_28_cursor.ascend(1);
  }
  drop(v447_28_cursor);
  drop(v447_9);
  (v447_28).clone()
}

fn routine_24(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v469_21 = Space::new();
  let mut v469_21_cursor = (*s0).read_zipper();
  for v469_21_byte in v469_21_cursor.child_mask().iter() {
    v469_21_cursor.descend_to_byte(v469_21_byte);
    {
    let v469_21_tail = v469_21_cursor.fork_read_zipper();
    let v469_21_head = Path::from_slice(&[v469_21_byte]);
    let v470_2: Space = singleton(&(v469_21_head));
    let v470_3: Space = intersect(&(*CONSTANT_2),&(v470_2));
    let v470_4: Space = if has_head(&(v470_3)) { singleton(&[]) } else { Space::new() };
    drop(v470_3);
    let v470_5: Space = subtract(&(*CONSTANT_1),&(v470_4));
    drop(v470_4);
    let v470_8: Space = if (v470_5).is_empty() { Space::new() } else {
      let v471_6: Path = concat_path(&(*p0),&(v469_21_head));
      let mut v471_7 = Space::new();
      let mut v471_7_cursor = (v469_21_tail).read_zipper();
      for v471_7_byte in v471_7_cursor.child_mask().iter() {
        v471_7_cursor.descend_to_byte(v471_7_byte);
        {
        let v471_7_tail = v471_7_cursor.fork_read_zipper();
        let v471_7_head = Path::from_slice(&[v471_7_byte]);
        let v472_2: Space = singleton(&(v471_7_head));
        let v472_3: Space = intersect(&(*CONSTANT_2),&(v472_2));
        let v472_4: Space = if has_head(&(v472_3)) { singleton(&[]) } else { Space::new() };
        drop(v472_3);
        let v472_5: Space = subtract(&(*CONSTANT_1),&(v472_4));
        drop(v472_4);
        let v472_8: Space = if (v472_5).is_empty() { Space::new() } else {
          let v473_6: Path = concat_path(&(v471_6),&(v471_7_head));
          let mut v473_7 = Space::new();
          let mut v473_7_cursor = (v471_7_tail).read_zipper();
          for v473_7_byte in v473_7_cursor.child_mask().iter() {
            v473_7_cursor.descend_to_byte(v473_7_byte);
            {
            let v473_7_tail = v473_7_cursor.fork_read_zipper();
            let v473_7_head = Path::from_slice(&[v473_7_byte]);
            let v474_2: Space = singleton(&(v473_7_head));
            let v474_3: Space = intersect(&(*CONSTANT_2),&(v474_2));
            let v474_4: Space = if has_head(&(v474_3)) { singleton(&[]) } else { Space::new() };
            drop(v474_3);
            let v474_5: Space = subtract(&(*CONSTANT_1),&(v474_4));
            drop(v474_4);
            let v474_8: Space = if (v474_5).is_empty() { Space::new() } else {
              let v475_6: Path = concat_path(&(v473_6),&(v473_7_head));
              let v475_7: Space = routine_36(c, &(v475_6), &(*p1), &(v473_7_tail).make_space());
              compose(&(v474_5),&(v475_7))
            };
            drop(v474_5);
            let v474_9: Space = intersect(&(*CONSTANT_2),&(v474_2));
            drop(v474_2);
            let v474_10: Space = if has_head(&(v474_9)) { singleton(&[]) } else { Space::new() };
            drop(v474_9);
            let v474_12: Space = if (v474_10).is_empty() { Space::new() } else {
              let v476_6: Path = concat_path(&(v473_6),&(v473_7_head));
              let v476_11: Space = routine_37(c, &(v476_6), &(*p1), &(v473_7_tail).make_space());
              drop(v476_6);
              compose(&(v474_10),&(v476_11))
            };
            drop(v474_10);
            let v474_13: Space = unite(&(v474_8),&(v474_12));
            v473_7.join_into((v474_13).clone());
            }
            v473_7_cursor.ascend(1);
          }
          drop(v473_7_cursor);
          compose(&(v472_5),&(v473_7))
        };
        drop(v472_5);
        let v472_9: Space = intersect(&(*CONSTANT_2),&(v472_2));
        drop(v472_2);
        let v472_10: Space = if has_head(&(v472_9)) { singleton(&[]) } else { Space::new() };
        drop(v472_9);
        let v472_12: Space = if (v472_10).is_empty() { Space::new() } else {
          let v477_6: Path = concat_path(&(v471_6),&(v471_7_head));
          let mut v477_11 = Space::new();
          let mut v477_11_cursor = (v471_7_tail).read_zipper();
          for v477_11_byte in v477_11_cursor.child_mask().iter() {
            v477_11_cursor.descend_to_byte(v477_11_byte);
            {
            let v477_11_tail = v477_11_cursor.fork_read_zipper();
            let v477_11_head = Path::from_slice(&[v477_11_byte]);
            let v478_2: Space = singleton(&(v477_11_head));
            let v478_3: Space = intersect(&(*CONSTANT_2),&(v478_2));
            let v478_4: Space = if has_head(&(v478_3)) { singleton(&[]) } else { Space::new() };
            drop(v478_3);
            let v478_5: Space = subtract(&(*CONSTANT_1),&(v478_4));
            drop(v478_4);
            let v478_8: Space = if (v478_5).is_empty() { Space::new() } else {
              let v479_6: Path = concat_path(&(v477_6),&(v477_11_head));
              let v479_7: Space = routine_36(c, &(v479_6), &(*p1), &(v477_11_tail).make_space());
              compose(&(v478_5),&(v479_7))
            };
            drop(v478_5);
            let v478_9: Space = intersect(&(*CONSTANT_2),&(v478_2));
            drop(v478_2);
            let v478_10: Space = if has_head(&(v478_9)) { singleton(&[]) } else { Space::new() };
            drop(v478_9);
            let v478_12: Space = if (v478_10).is_empty() { Space::new() } else {
              let v480_6: Path = concat_path(&(v477_6),&(v477_11_head));
              let v480_11: Space = routine_19(c, &(v480_6), &(*p1), &(v477_11_tail).make_space());
              drop(v480_6);
              compose(&(v478_10),&(v480_11))
            };
            drop(v478_10);
            let v478_13: Space = unite(&(v478_8),&(v478_12));
            v477_11.join_into((v478_13).clone());
            }
            v477_11_cursor.ascend(1);
          }
          drop(v477_11_cursor);
          drop(v477_6);
          compose(&(v472_10),&(v477_11))
        };
        drop(v472_10);
        let v472_13: Space = unite(&(v472_8),&(v472_12));
        v471_7.join_into((v472_13).clone());
        }
        v471_7_cursor.ascend(1);
      }
      drop(v471_7_cursor);
      compose(&(v470_5),&(v471_7))
    };
    drop(v470_5);
    let v470_9: Space = intersect(&(*CONSTANT_2),&(v470_2));
    drop(v470_2);
    let v470_10: Space = if has_head(&(v470_9)) { singleton(&[]) } else { Space::new() };
    drop(v470_9);
    let v470_12: Space = if (v470_10).is_empty() { Space::new() } else {
      let v481_6: Path = concat_path(&(*p0),&(v469_21_head));
      let mut v481_11 = Space::new();
      let mut v481_11_cursor = (v469_21_tail).read_zipper();
      for v481_11_byte in v481_11_cursor.child_mask().iter() {
        v481_11_cursor.descend_to_byte(v481_11_byte);
        {
        let v481_11_tail = v481_11_cursor.fork_read_zipper();
        let v481_11_head = Path::from_slice(&[v481_11_byte]);
        let v482_2: Space = singleton(&(v481_11_head));
        let v482_3: Space = intersect(&(*CONSTANT_2),&(v482_2));
        let v482_4: Space = if has_head(&(v482_3)) { singleton(&[]) } else { Space::new() };
        drop(v482_3);
        let v482_5: Space = subtract(&(*CONSTANT_1),&(v482_4));
        drop(v482_4);
        let v482_8: Space = if (v482_5).is_empty() { Space::new() } else {
          let v483_6: Path = concat_path(&(v481_6),&(v481_11_head));
          let mut v483_7 = Space::new();
          let mut v483_7_cursor = (v481_11_tail).read_zipper();
          for v483_7_byte in v483_7_cursor.child_mask().iter() {
            v483_7_cursor.descend_to_byte(v483_7_byte);
            {
            let v483_7_tail = v483_7_cursor.fork_read_zipper();
            let v483_7_head = Path::from_slice(&[v483_7_byte]);
            let v484_2: Space = singleton(&(v483_7_head));
            let v484_3: Space = intersect(&(*CONSTANT_2),&(v484_2));
            let v484_4: Space = if has_head(&(v484_3)) { singleton(&[]) } else { Space::new() };
            drop(v484_3);
            let v484_5: Space = subtract(&(*CONSTANT_1),&(v484_4));
            drop(v484_4);
            let v484_8: Space = if (v484_5).is_empty() { Space::new() } else {
              let v485_6: Path = concat_path(&(v483_6),&(v483_7_head));
              let v485_7: Space = routine_36(c, &(v485_6), &(*p1), &(v483_7_tail).make_space());
              compose(&(v484_5),&(v485_7))
            };
            drop(v484_5);
            let v484_9: Space = intersect(&(*CONSTANT_2),&(v484_2));
            drop(v484_2);
            let v484_10: Space = if has_head(&(v484_9)) { singleton(&[]) } else { Space::new() };
            drop(v484_9);
            let v484_12: Space = if (v484_10).is_empty() { Space::new() } else {
              let v486_6: Path = concat_path(&(v483_6),&(v483_7_head));
              let v486_11: Space = routine_37(c, &(v486_6), &(*p1), &(v483_7_tail).make_space());
              drop(v486_6);
              compose(&(v484_10),&(v486_11))
            };
            drop(v484_10);
            let v484_13: Space = unite(&(v484_8),&(v484_12));
            v483_7.join_into((v484_13).clone());
            }
            v483_7_cursor.ascend(1);
          }
          drop(v483_7_cursor);
          compose(&(v482_5),&(v483_7))
        };
        drop(v482_5);
        let v482_9: Space = intersect(&(*CONSTANT_2),&(v482_2));
        drop(v482_2);
        let v482_10: Space = if has_head(&(v482_9)) { singleton(&[]) } else { Space::new() };
        drop(v482_9);
        let v482_11: Space = compose(&(v482_10),&(v481_11_tail));
        drop(v482_10);
        let v487_6: Path = concat_path(&(v481_6),&(v481_11_head));
        let v482_12: Space = wrap(&(v482_11),&(v487_6));
        drop(v482_11);
        let v482_13: Space = wrap(&(v482_12),&(*p1));
        drop(v482_12);
        let v482_14: Space = unite(&(v482_8),&(v482_13));
        drop(v482_13);
        v481_11.join_into((v482_14).clone());
        }
        v481_11_cursor.ascend(1);
      }
      drop(v481_11_cursor);
      drop(v481_6);
      compose(&(v470_10),&(v481_11))
    };
    drop(v470_10);
    let v470_13: Space = unite(&(v470_8),&(v470_12));
    v469_21.join_into((v470_13).clone());
    }
    v469_21_cursor.ascend(1);
  }
  drop(v469_21_cursor);
  (v469_21).clone()
}

fn routine_25(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v488_15 = Space::new();
  let mut v488_15_cursor = (*s0).read_zipper();
  for v488_15_byte in v488_15_cursor.child_mask().iter() {
    v488_15_cursor.descend_to_byte(v488_15_byte);
    {
    let v488_15_tail = v488_15_cursor.fork_read_zipper();
    let v488_15_head = Path::from_slice(&[v488_15_byte]);
    let v489_2: Space = singleton(&(v488_15_head));
    let v489_3: Space = intersect(&(*CONSTANT_2),&(v489_2));
    let v489_4: Space = if has_head(&(v489_3)) { singleton(&[]) } else { Space::new() };
    drop(v489_3);
    let v489_5: Space = subtract(&(*CONSTANT_1),&(v489_4));
    drop(v489_4);
    let v489_8: Space = if (v489_5).is_empty() { Space::new() } else {
      let v490_6: Path = concat_path(&(*p0),&(v488_15_head));
      let mut v490_7 = Space::new();
      let mut v490_7_cursor = (v488_15_tail).read_zipper();
      for v490_7_byte in v490_7_cursor.child_mask().iter() {
        v490_7_cursor.descend_to_byte(v490_7_byte);
        {
        let v490_7_tail = v490_7_cursor.fork_read_zipper();
        let v490_7_head = Path::from_slice(&[v490_7_byte]);
        let v491_2: Space = singleton(&(v490_7_head));
        let v491_3: Space = intersect(&(*CONSTANT_2),&(v491_2));
        let v491_4: Space = if has_head(&(v491_3)) { singleton(&[]) } else { Space::new() };
        drop(v491_3);
        let v491_5: Space = subtract(&(*CONSTANT_1),&(v491_4));
        drop(v491_4);
        let v491_8: Space = if (v491_5).is_empty() { Space::new() } else {
          let v492_6: Path = concat_path(&(v490_6),&(v490_7_head));
          let mut v492_7 = Space::new();
          let mut v492_7_cursor = (v490_7_tail).read_zipper();
          for v492_7_byte in v492_7_cursor.child_mask().iter() {
            v492_7_cursor.descend_to_byte(v492_7_byte);
            {
            let v492_7_tail = v492_7_cursor.fork_read_zipper();
            let v492_7_head = Path::from_slice(&[v492_7_byte]);
            let v493_2: Space = singleton(&(v492_7_head));
            let v493_3: Space = intersect(&(*CONSTANT_2),&(v493_2));
            let v493_4: Space = if has_head(&(v493_3)) { singleton(&[]) } else { Space::new() };
            drop(v493_3);
            let v493_5: Space = subtract(&(*CONSTANT_1),&(v493_4));
            drop(v493_4);
            let v493_8: Space = if (v493_5).is_empty() { Space::new() } else {
              let v494_6: Path = concat_path(&(v492_6),&(v492_7_head));
              let v494_7: Space = routine_36(c, &(v494_6), &(*p1), &(v492_7_tail).make_space());
              compose(&(v493_5),&(v494_7))
            };
            drop(v493_5);
            let v493_9: Space = intersect(&(*CONSTANT_2),&(v493_2));
            drop(v493_2);
            let v493_10: Space = if has_head(&(v493_9)) { singleton(&[]) } else { Space::new() };
            drop(v493_9);
            let v493_12: Space = if (v493_10).is_empty() { Space::new() } else {
              let v495_6: Path = concat_path(&(v492_6),&(v492_7_head));
              let v495_11: Space = routine_37(c, &(v495_6), &(*p1), &(v492_7_tail).make_space());
              drop(v495_6);
              compose(&(v493_10),&(v495_11))
            };
            drop(v493_10);
            let v493_13: Space = unite(&(v493_8),&(v493_12));
            v492_7.join_into((v493_13).clone());
            }
            v492_7_cursor.ascend(1);
          }
          drop(v492_7_cursor);
          compose(&(v491_5),&(v492_7))
        };
        drop(v491_5);
        let v491_9: Space = intersect(&(*CONSTANT_2),&(v491_2));
        drop(v491_2);
        let v491_10: Space = if has_head(&(v491_9)) { singleton(&[]) } else { Space::new() };
        drop(v491_9);
        let v491_12: Space = if (v491_10).is_empty() { Space::new() } else {
          let v496_6: Path = concat_path(&(v490_6),&(v490_7_head));
          let mut v496_11 = Space::new();
          let mut v496_11_cursor = (v490_7_tail).read_zipper();
          for v496_11_byte in v496_11_cursor.child_mask().iter() {
            v496_11_cursor.descend_to_byte(v496_11_byte);
            {
            let v496_11_tail = v496_11_cursor.fork_read_zipper();
            let v496_11_head = Path::from_slice(&[v496_11_byte]);
            let v497_2: Space = singleton(&(v496_11_head));
            let v497_3: Space = intersect(&(*CONSTANT_2),&(v497_2));
            let v497_4: Space = if has_head(&(v497_3)) { singleton(&[]) } else { Space::new() };
            drop(v497_3);
            let v497_5: Space = subtract(&(*CONSTANT_1),&(v497_4));
            drop(v497_4);
            let v497_8: Space = if (v497_5).is_empty() { Space::new() } else {
              let v498_6: Path = concat_path(&(v496_6),&(v496_11_head));
              let v498_7: Space = routine_36(c, &(v498_6), &(*p1), &(v496_11_tail).make_space());
              compose(&(v497_5),&(v498_7))
            };
            drop(v497_5);
            let v497_9: Space = intersect(&(*CONSTANT_2),&(v497_2));
            drop(v497_2);
            let v497_10: Space = if has_head(&(v497_9)) { singleton(&[]) } else { Space::new() };
            drop(v497_9);
            let v497_12: Space = if (v497_10).is_empty() { Space::new() } else {
              let v499_6: Path = concat_path(&(v496_6),&(v496_11_head));
              let v499_11: Space = routine_19(c, &(v499_6), &(*p1), &(v496_11_tail).make_space());
              drop(v499_6);
              compose(&(v497_10),&(v499_11))
            };
            drop(v497_10);
            let v497_13: Space = unite(&(v497_8),&(v497_12));
            v496_11.join_into((v497_13).clone());
            }
            v496_11_cursor.ascend(1);
          }
          drop(v496_11_cursor);
          drop(v496_6);
          compose(&(v491_10),&(v496_11))
        };
        drop(v491_10);
        let v491_13: Space = unite(&(v491_8),&(v491_12));
        v490_7.join_into((v491_13).clone());
        }
        v490_7_cursor.ascend(1);
      }
      drop(v490_7_cursor);
      compose(&(v489_5),&(v490_7))
    };
    drop(v489_5);
    let v489_9: Space = intersect(&(*CONSTANT_2),&(v489_2));
    drop(v489_2);
    let v489_10: Space = if has_head(&(v489_9)) { singleton(&[]) } else { Space::new() };
    drop(v489_9);
    let v489_11: Space = compose(&(v489_10),&(v488_15_tail));
    drop(v489_10);
    let v500_6: Path = concat_path(&(*p0),&(v488_15_head));
    let v489_12: Space = wrap(&(v489_11),&(v500_6));
    drop(v489_11);
    let v489_13: Space = wrap(&(v489_12),&(*p1));
    drop(v489_12);
    let v489_14: Space = unite(&(v489_8),&(v489_13));
    drop(v489_13);
    v488_15.join_into((v489_14).clone());
    }
    v488_15_cursor.ascend(1);
  }
  drop(v488_15_cursor);
  (v488_15).clone()
}

fn routine_26(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v501_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v501_21: Space = unwrap(&(v501_20),&(*p0));
  drop(v501_20);
  let mut v501_28 = Space::new();
  let mut v501_28_cursor = (*s0).read_zipper();
  for v501_28_byte in v501_28_cursor.child_mask().iter() {
    v501_28_cursor.descend_to_byte(v501_28_byte);
    {
    let v501_28_tail = v501_28_cursor.fork_read_zipper();
    let v501_28_head = Path::from_slice(&[v501_28_byte]);
    let v502_2: Space = singleton(&(v501_28_head));
    let v502_3: Space = intersect(&(*CONSTANT_2),&(v502_2));
    let v502_4: Space = if has_head(&(v502_3)) { singleton(&[]) } else { Space::new() };
    drop(v502_3);
    let v502_5: Space = subtract(&(*CONSTANT_1),&(v502_4));
    drop(v502_4);
    let v502_8: Space = if (v502_5).is_empty() { Space::new() } else {
      let v503_6: Path = concat_path(&(*p0),&(v501_28_head));
      let mut v503_7 = Space::new();
      let mut v503_7_cursor = (v501_28_tail).read_zipper();
      for v503_7_byte in v503_7_cursor.child_mask().iter() {
        v503_7_cursor.descend_to_byte(v503_7_byte);
        {
        let v503_7_tail = v503_7_cursor.fork_read_zipper();
        let v503_7_head = Path::from_slice(&[v503_7_byte]);
        let v504_2: Space = singleton(&(v503_7_head));
        let v504_3: Space = intersect(&(*CONSTANT_2),&(v504_2));
        let v504_4: Space = if has_head(&(v504_3)) { singleton(&[]) } else { Space::new() };
        drop(v504_3);
        let v504_5: Space = subtract(&(*CONSTANT_1),&(v504_4));
        drop(v504_4);
        let v504_8: Space = if (v504_5).is_empty() { Space::new() } else {
          let v505_6: Path = concat_path(&(v503_6),&(v503_7_head));
          let mut v505_7 = Space::new();
          let mut v505_7_cursor = (v503_7_tail).read_zipper();
          for v505_7_byte in v505_7_cursor.child_mask().iter() {
            v505_7_cursor.descend_to_byte(v505_7_byte);
            {
            let v505_7_tail = v505_7_cursor.fork_read_zipper();
            let v505_7_head = Path::from_slice(&[v505_7_byte]);
            let v506_2: Space = singleton(&(v505_7_head));
            let v506_3: Space = intersect(&(*CONSTANT_2),&(v506_2));
            let v506_4: Space = if has_head(&(v506_3)) { singleton(&[]) } else { Space::new() };
            drop(v506_3);
            let v506_5: Space = subtract(&(*CONSTANT_1),&(v506_4));
            drop(v506_4);
            let v506_8: Space = if (v506_5).is_empty() { Space::new() } else {
              let v507_6: Path = concat_path(&(v505_6),&(v505_7_head));
              let v507_7: Space = routine_38(c, &(v507_6), &(*p1), &(v505_7_tail).make_space(), &(*s1));
              compose(&(v506_5),&(v507_7))
            };
            drop(v506_5);
            let v506_9: Space = intersect(&(*CONSTANT_2),&(v506_2));
            drop(v506_2);
            let v506_10: Space = if has_head(&(v506_9)) { singleton(&[]) } else { Space::new() };
            drop(v506_9);
            let v506_12: Space = if (v506_10).is_empty() { Space::new() } else {
              let v508_6: Path = concat_path(&(v505_6),&(v505_7_head));
              let v508_11: Space = routine_39(c, &(v508_6), &(*p1), &(v505_7_tail).make_space(), &(*s1));
              drop(v508_6);
              compose(&(v506_10),&(v508_11))
            };
            drop(v506_10);
            let v506_13: Space = unite(&(v506_8),&(v506_12));
            v505_7.join_into((v506_13).clone());
            }
            v505_7_cursor.ascend(1);
          }
          drop(v505_7_cursor);
          compose(&(v504_5),&(v505_7))
        };
        drop(v504_5);
        let v504_9: Space = intersect(&(*CONSTANT_2),&(v504_2));
        drop(v504_2);
        let v504_10: Space = if has_head(&(v504_9)) { singleton(&[]) } else { Space::new() };
        drop(v504_9);
        let v504_12: Space = if (v504_10).is_empty() { Space::new() } else {
          let v509_6: Path = concat_path(&(v503_6),&(v503_7_head));
          let mut v509_11 = Space::new();
          let mut v509_11_cursor = (v503_7_tail).read_zipper();
          for v509_11_byte in v509_11_cursor.child_mask().iter() {
            v509_11_cursor.descend_to_byte(v509_11_byte);
            {
            let v509_11_tail = v509_11_cursor.fork_read_zipper();
            let v509_11_head = Path::from_slice(&[v509_11_byte]);
            let v510_2: Space = singleton(&(v509_11_head));
            let v510_3: Space = intersect(&(*CONSTANT_2),&(v510_2));
            let v510_4: Space = if has_head(&(v510_3)) { singleton(&[]) } else { Space::new() };
            drop(v510_3);
            let v510_5: Space = subtract(&(*CONSTANT_1),&(v510_4));
            drop(v510_4);
            let v510_8: Space = if (v510_5).is_empty() { Space::new() } else {
              let v511_6: Path = concat_path(&(v509_6),&(v509_11_head));
              let v511_7: Space = routine_38(c, &(v511_6), &(*p1), &(v509_11_tail).make_space(), &(*s1));
              compose(&(v510_5),&(v511_7))
            };
            drop(v510_5);
            let v510_9: Space = intersect(&(*CONSTANT_2),&(v510_2));
            drop(v510_2);
            let v510_10: Space = if has_head(&(v510_9)) { singleton(&[]) } else { Space::new() };
            drop(v510_9);
            let v510_12: Space = if (v510_10).is_empty() { Space::new() } else {
              let v512_6: Path = concat_path(&(v509_6),&(v509_11_head));
              let v512_11: Space = routine_10(c, &(v512_6), &(*p1), &(v509_11_tail).make_space(), &(*s1));
              drop(v512_6);
              compose(&(v510_10),&(v512_11))
            };
            drop(v510_10);
            let v510_13: Space = unite(&(v510_8),&(v510_12));
            v509_11.join_into((v510_13).clone());
            }
            v509_11_cursor.ascend(1);
          }
          drop(v509_11_cursor);
          drop(v509_6);
          compose(&(v504_10),&(v509_11))
        };
        drop(v504_10);
        let v504_13: Space = unite(&(v504_8),&(v504_12));
        v503_7.join_into((v504_13).clone());
        }
        v503_7_cursor.ascend(1);
      }
      drop(v503_7_cursor);
      compose(&(v502_5),&(v503_7))
    };
    drop(v502_5);
    let v502_9: Space = intersect(&(*CONSTANT_2),&(v502_2));
    drop(v502_2);
    let v502_10: Space = if has_head(&(v502_9)) { singleton(&[]) } else { Space::new() };
    drop(v502_9);
    let v502_13: Space = if (v502_10).is_empty() { Space::new() } else {
      let v513_6: Path = concat_path(&(*p0),&(v501_28_head));
      let v513_11: Space = unwrap(&(v501_21),&(v501_28_head));
      let mut v513_12 = Space::new();
      let mut v513_12_cursor = (v501_28_tail).read_zipper();
      for v513_12_byte in v513_12_cursor.child_mask().iter() {
        v513_12_cursor.descend_to_byte(v513_12_byte);
        {
        let v513_12_tail = v513_12_cursor.fork_read_zipper();
        let v513_12_head = Path::from_slice(&[v513_12_byte]);
        let v514_2: Space = singleton(&(v513_12_head));
        let v514_3: Space = intersect(&(*CONSTANT_2),&(v514_2));
        let v514_4: Space = if has_head(&(v514_3)) { singleton(&[]) } else { Space::new() };
        drop(v514_3);
        let v514_5: Space = subtract(&(*CONSTANT_1),&(v514_4));
        drop(v514_4);
        let v514_8: Space = if (v514_5).is_empty() { Space::new() } else {
          let v515_6: Path = concat_path(&(v513_6),&(v513_12_head));
          let mut v515_7 = Space::new();
          let mut v515_7_cursor = (v513_12_tail).read_zipper();
          for v515_7_byte in v515_7_cursor.child_mask().iter() {
            v515_7_cursor.descend_to_byte(v515_7_byte);
            {
            let v515_7_tail = v515_7_cursor.fork_read_zipper();
            let v515_7_head = Path::from_slice(&[v515_7_byte]);
            let v516_2: Space = singleton(&(v515_7_head));
            let v516_3: Space = intersect(&(*CONSTANT_2),&(v516_2));
            let v516_4: Space = if has_head(&(v516_3)) { singleton(&[]) } else { Space::new() };
            drop(v516_3);
            let v516_5: Space = subtract(&(*CONSTANT_1),&(v516_4));
            drop(v516_4);
            let v516_8: Space = if (v516_5).is_empty() { Space::new() } else {
              let v517_6: Path = concat_path(&(v515_6),&(v515_7_head));
              let v517_7: Space = routine_38(c, &(v517_6), &(*p1), &(v515_7_tail).make_space(), &(*s1));
              compose(&(v516_5),&(v517_7))
            };
            drop(v516_5);
            let v516_9: Space = intersect(&(*CONSTANT_2),&(v516_2));
            drop(v516_2);
            let v516_10: Space = if has_head(&(v516_9)) { singleton(&[]) } else { Space::new() };
            drop(v516_9);
            let v516_12: Space = if (v516_10).is_empty() { Space::new() } else {
              let v518_6: Path = concat_path(&(v515_6),&(v515_7_head));
              let v518_11: Space = routine_39(c, &(v518_6), &(*p1), &(v515_7_tail).make_space(), &(*s1));
              drop(v518_6);
              compose(&(v516_10),&(v518_11))
            };
            drop(v516_10);
            let v516_13: Space = unite(&(v516_8),&(v516_12));
            v515_7.join_into((v516_13).clone());
            }
            v515_7_cursor.ascend(1);
          }
          drop(v515_7_cursor);
          drop(v515_6);
          compose(&(v514_5),&(v515_7))
        };
        drop(v514_5);
        let v514_9: Space = intersect(&(*CONSTANT_2),&(v514_2));
        drop(v514_2);
        let v514_10: Space = if has_head(&(v514_9)) { singleton(&[]) } else { Space::new() };
        drop(v514_9);
        let v514_13: Space = if (v514_10).is_empty() { Space::new() } else {
          let v519_11: Space = unwrap(&(v513_11),&(v513_12_head));
          let mut v519_12 = Space::new();
          let mut v519_12_cursor = (v519_11).read_zipper();
          for v519_12_byte in v519_12_cursor.child_mask().iter() {
            v519_12_cursor.descend_to_byte(v519_12_byte);
            {
            let v519_12_tail = v519_12_cursor.fork_read_zipper();
            let v519_12_head = Path::from_slice(&[v519_12_byte]);
            let v520_2: Space = singleton(&(v519_12_head));
            let v520_3: Space = intersect(&(*CONSTANT_2),&(v520_2));
            let v520_4: Space = if has_head(&(v520_3)) { singleton(&[]) } else { Space::new() };
            drop(v520_3);
            let v520_5: Space = subtract(&(*CONSTANT_1),&(v520_4));
            drop(v520_4);
            let v520_7: Space = if (v520_5).is_empty() { Space::new() } else {
              let v521_6: Space = routine_13(c, &(v519_12_head), &(*p1), &(v519_12_tail).make_space());
              compose(&(v520_5),&(v521_6))
            };
            drop(v520_5);
            let v520_8: Space = intersect(&(*CONSTANT_2),&(v520_2));
            drop(v520_2);
            let v520_9: Space = if has_head(&(v520_8)) { singleton(&[]) } else { Space::new() };
            drop(v520_8);
            let v520_11: Space = if (v520_9).is_empty() { Space::new() } else {
              let v522_10: Space = routine_14(c, &(v519_12_head), &(*p1), &(v519_12_tail).make_space());
              compose(&(v520_9),&(v522_10))
            };
            drop(v520_9);
            let v520_12: Space = unite(&(v520_7),&(v520_11));
            v519_12.join_into((v520_12).clone());
            }
            v519_12_cursor.ascend(1);
          }
          drop(v519_12_cursor);
          drop(v519_11);
          compose(&(v514_10),&(v519_12))
        };
        drop(v514_10);
        let v514_14: Space = unite(&(v514_8),&(v514_13));
        v513_12.join_into((v514_14).clone());
        }
        v513_12_cursor.ascend(1);
      }
      drop(v513_12_cursor);
      drop(v513_6);
      drop(v513_11);
      compose(&(v502_10),&(v513_12))
    };
    drop(v502_10);
    let v502_14: Space = unite(&(v502_8),&(v502_13));
    v501_28.join_into((v502_14).clone());
    }
    v501_28_cursor.ascend(1);
  }
  drop(v501_28_cursor);
  drop(v501_21);
  (v501_28).clone()
}

fn routine_27(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v523_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v523_9: Space = unwrap(&(v523_8),&(*p0));
  drop(v523_8);
  let mut v523_28 = Space::new();
  let mut v523_28_cursor = (*s0).read_zipper();
  for v523_28_byte in v523_28_cursor.child_mask().iter() {
    v523_28_cursor.descend_to_byte(v523_28_byte);
    {
    let v523_28_tail = v523_28_cursor.fork_read_zipper();
    let v523_28_head = Path::from_slice(&[v523_28_byte]);
    let v524_2: Space = singleton(&(v523_28_head));
    let v524_3: Space = intersect(&(*CONSTANT_2),&(v524_2));
    let v524_4: Space = if has_head(&(v524_3)) { singleton(&[]) } else { Space::new() };
    drop(v524_3);
    let v524_5: Space = subtract(&(*CONSTANT_1),&(v524_4));
    drop(v524_4);
    let v524_8: Space = if (v524_5).is_empty() { Space::new() } else {
      let v525_6: Path = concat_path(&(*p0),&(v523_28_head));
      let mut v525_7 = Space::new();
      let mut v525_7_cursor = (v523_28_tail).read_zipper();
      for v525_7_byte in v525_7_cursor.child_mask().iter() {
        v525_7_cursor.descend_to_byte(v525_7_byte);
        {
        let v525_7_tail = v525_7_cursor.fork_read_zipper();
        let v525_7_head = Path::from_slice(&[v525_7_byte]);
        let v526_2: Space = singleton(&(v525_7_head));
        let v526_3: Space = intersect(&(*CONSTANT_2),&(v526_2));
        let v526_4: Space = if has_head(&(v526_3)) { singleton(&[]) } else { Space::new() };
        drop(v526_3);
        let v526_5: Space = subtract(&(*CONSTANT_1),&(v526_4));
        drop(v526_4);
        let v526_8: Space = if (v526_5).is_empty() { Space::new() } else {
          let v527_6: Path = concat_path(&(v525_6),&(v525_7_head));
          let mut v527_7 = Space::new();
          let mut v527_7_cursor = (v525_7_tail).read_zipper();
          for v527_7_byte in v527_7_cursor.child_mask().iter() {
            v527_7_cursor.descend_to_byte(v527_7_byte);
            {
            let v527_7_tail = v527_7_cursor.fork_read_zipper();
            let v527_7_head = Path::from_slice(&[v527_7_byte]);
            let v528_2: Space = singleton(&(v527_7_head));
            let v528_3: Space = intersect(&(*CONSTANT_2),&(v528_2));
            let v528_4: Space = if has_head(&(v528_3)) { singleton(&[]) } else { Space::new() };
            drop(v528_3);
            let v528_5: Space = subtract(&(*CONSTANT_1),&(v528_4));
            drop(v528_4);
            let v528_8: Space = if (v528_5).is_empty() { Space::new() } else {
              let v529_6: Path = concat_path(&(v527_6),&(v527_7_head));
              let v529_7: Space = routine_38(c, &(v529_6), &(*p1), &(v527_7_tail).make_space(), &(*s1));
              compose(&(v528_5),&(v529_7))
            };
            drop(v528_5);
            let v528_9: Space = intersect(&(*CONSTANT_2),&(v528_2));
            drop(v528_2);
            let v528_10: Space = if has_head(&(v528_9)) { singleton(&[]) } else { Space::new() };
            drop(v528_9);
            let v528_12: Space = if (v528_10).is_empty() { Space::new() } else {
              let v530_6: Path = concat_path(&(v527_6),&(v527_7_head));
              let v530_11: Space = routine_39(c, &(v530_6), &(*p1), &(v527_7_tail).make_space(), &(*s1));
              drop(v530_6);
              compose(&(v528_10),&(v530_11))
            };
            drop(v528_10);
            let v528_13: Space = unite(&(v528_8),&(v528_12));
            v527_7.join_into((v528_13).clone());
            }
            v527_7_cursor.ascend(1);
          }
          drop(v527_7_cursor);
          compose(&(v526_5),&(v527_7))
        };
        drop(v526_5);
        let v526_9: Space = intersect(&(*CONSTANT_2),&(v526_2));
        drop(v526_2);
        let v526_10: Space = if has_head(&(v526_9)) { singleton(&[]) } else { Space::new() };
        drop(v526_9);
        let v526_12: Space = if (v526_10).is_empty() { Space::new() } else {
          let v531_6: Path = concat_path(&(v525_6),&(v525_7_head));
          let mut v531_11 = Space::new();
          let mut v531_11_cursor = (v525_7_tail).read_zipper();
          for v531_11_byte in v531_11_cursor.child_mask().iter() {
            v531_11_cursor.descend_to_byte(v531_11_byte);
            {
            let v531_11_tail = v531_11_cursor.fork_read_zipper();
            let v531_11_head = Path::from_slice(&[v531_11_byte]);
            let v532_2: Space = singleton(&(v531_11_head));
            let v532_3: Space = intersect(&(*CONSTANT_2),&(v532_2));
            let v532_4: Space = if has_head(&(v532_3)) { singleton(&[]) } else { Space::new() };
            drop(v532_3);
            let v532_5: Space = subtract(&(*CONSTANT_1),&(v532_4));
            drop(v532_4);
            let v532_8: Space = if (v532_5).is_empty() { Space::new() } else {
              let v533_6: Path = concat_path(&(v531_6),&(v531_11_head));
              let v533_7: Space = routine_38(c, &(v533_6), &(*p1), &(v531_11_tail).make_space(), &(*s1));
              compose(&(v532_5),&(v533_7))
            };
            drop(v532_5);
            let v532_9: Space = intersect(&(*CONSTANT_2),&(v532_2));
            drop(v532_2);
            let v532_10: Space = if has_head(&(v532_9)) { singleton(&[]) } else { Space::new() };
            drop(v532_9);
            let v532_12: Space = if (v532_10).is_empty() { Space::new() } else {
              let v534_6: Path = concat_path(&(v531_6),&(v531_11_head));
              let v534_11: Space = routine_10(c, &(v534_6), &(*p1), &(v531_11_tail).make_space(), &(*s1));
              drop(v534_6);
              compose(&(v532_10),&(v534_11))
            };
            drop(v532_10);
            let v532_13: Space = unite(&(v532_8),&(v532_12));
            v531_11.join_into((v532_13).clone());
            }
            v531_11_cursor.ascend(1);
          }
          drop(v531_11_cursor);
          drop(v531_6);
          compose(&(v526_10),&(v531_11))
        };
        drop(v526_10);
        let v526_13: Space = unite(&(v526_8),&(v526_12));
        v525_7.join_into((v526_13).clone());
        }
        v525_7_cursor.ascend(1);
      }
      drop(v525_7_cursor);
      drop(v525_6);
      compose(&(v524_5),&(v525_7))
    };
    drop(v524_5);
    let v524_9: Space = intersect(&(*CONSTANT_2),&(v524_2));
    drop(v524_2);
    let v524_10: Space = if has_head(&(v524_9)) { singleton(&[]) } else { Space::new() };
    drop(v524_9);
    let v524_13: Space = if (v524_10).is_empty() { Space::new() } else {
      let v535_11: Space = unwrap(&(v523_9),&(v523_28_head));
      let mut v535_12 = Space::new();
      let mut v535_12_cursor = (v535_11).read_zipper();
      for v535_12_byte in v535_12_cursor.child_mask().iter() {
        v535_12_cursor.descend_to_byte(v535_12_byte);
        {
        let v535_12_tail = v535_12_cursor.fork_read_zipper();
        let v535_12_head = Path::from_slice(&[v535_12_byte]);
        let v536_2: Space = singleton(&(v535_12_head));
        let v536_3: Space = intersect(&(*CONSTANT_2),&(v536_2));
        let v536_4: Space = if has_head(&(v536_3)) { singleton(&[]) } else { Space::new() };
        drop(v536_3);
        let v536_5: Space = subtract(&(*CONSTANT_1),&(v536_4));
        drop(v536_4);
        let v536_7: Space = if (v536_5).is_empty() { Space::new() } else {
          let mut v537_6 = Space::new();
          let mut v537_6_cursor = (v535_12_tail).read_zipper();
          for v537_6_byte in v537_6_cursor.child_mask().iter() {
            v537_6_cursor.descend_to_byte(v537_6_byte);
            {
            let v537_6_tail = v537_6_cursor.fork_read_zipper();
            let v537_6_head = Path::from_slice(&[v537_6_byte]);
            let v538_2: Space = singleton(&(v537_6_head));
            let v538_3: Space = intersect(&(*CONSTANT_2),&(v538_2));
            let v538_4: Space = if has_head(&(v538_3)) { singleton(&[]) } else { Space::new() };
            drop(v538_3);
            let v538_5: Space = subtract(&(*CONSTANT_1),&(v538_4));
            drop(v538_4);
            let v538_8: Space = if (v538_5).is_empty() { Space::new() } else {
              let v539_6: Path = concat_path(&(v535_12_head),&(v537_6_head));
              let v539_7: Space = routine_17(c, &(v539_6), &(*p1), &(v537_6_tail).make_space());
              compose(&(v538_5),&(v539_7))
            };
            drop(v538_5);
            let v538_9: Space = intersect(&(*CONSTANT_2),&(v538_2));
            drop(v538_2);
            let v538_10: Space = if has_head(&(v538_9)) { singleton(&[]) } else { Space::new() };
            drop(v538_9);
            let v538_12: Space = if (v538_10).is_empty() { Space::new() } else {
              let v540_6: Path = concat_path(&(v535_12_head),&(v537_6_head));
              let v540_11: Space = routine_18(c, &(v540_6), &(*p1), &(v537_6_tail).make_space());
              drop(v540_6);
              compose(&(v538_10),&(v540_11))
            };
            drop(v538_10);
            let v538_13: Space = unite(&(v538_8),&(v538_12));
            v537_6.join_into((v538_13).clone());
            }
            v537_6_cursor.ascend(1);
          }
          drop(v537_6_cursor);
          compose(&(v536_5),&(v537_6))
        };
        drop(v536_5);
        let v536_8: Space = intersect(&(*CONSTANT_2),&(v536_2));
        drop(v536_2);
        let v536_9: Space = if has_head(&(v536_8)) { singleton(&[]) } else { Space::new() };
        drop(v536_8);
        let v536_11: Space = if (v536_9).is_empty() { Space::new() } else {
          let mut v541_10 = Space::new();
          let mut v541_10_cursor = (v535_12_tail).read_zipper();
          for v541_10_byte in v541_10_cursor.child_mask().iter() {
            v541_10_cursor.descend_to_byte(v541_10_byte);
            {
            let v541_10_tail = v541_10_cursor.fork_read_zipper();
            let v541_10_head = Path::from_slice(&[v541_10_byte]);
            let v542_2: Space = singleton(&(v541_10_head));
            let v542_3: Space = intersect(&(*CONSTANT_2),&(v542_2));
            let v542_4: Space = if has_head(&(v542_3)) { singleton(&[]) } else { Space::new() };
            drop(v542_3);
            let v542_5: Space = subtract(&(*CONSTANT_1),&(v542_4));
            drop(v542_4);
            let v542_8: Space = if (v542_5).is_empty() { Space::new() } else {
              let v543_6: Path = concat_path(&(v535_12_head),&(v541_10_head));
              let v543_7: Space = routine_17(c, &(v543_6), &(*p1), &(v541_10_tail).make_space());
              compose(&(v542_5),&(v543_7))
            };
            drop(v542_5);
            let v542_9: Space = intersect(&(*CONSTANT_2),&(v542_2));
            drop(v542_2);
            let v542_10: Space = if has_head(&(v542_9)) { singleton(&[]) } else { Space::new() };
            drop(v542_9);
            let v542_12: Space = if (v542_10).is_empty() { Space::new() } else {
              let v544_6: Path = concat_path(&(v535_12_head),&(v541_10_head));
              let v544_11: Space = routine_19(c, &(v544_6), &(*p1), &(v541_10_tail).make_space());
              drop(v544_6);
              compose(&(v542_10),&(v544_11))
            };
            drop(v542_10);
            let v542_13: Space = unite(&(v542_8),&(v542_12));
            v541_10.join_into((v542_13).clone());
            }
            v541_10_cursor.ascend(1);
          }
          drop(v541_10_cursor);
          compose(&(v536_9),&(v541_10))
        };
        drop(v536_9);
        let v536_12: Space = unite(&(v536_7),&(v536_11));
        v535_12.join_into((v536_12).clone());
        }
        v535_12_cursor.ascend(1);
      }
      drop(v535_12_cursor);
      drop(v535_11);
      compose(&(v524_10),&(v535_12))
    };
    drop(v524_10);
    let v524_14: Space = unite(&(v524_8),&(v524_13));
    v523_28.join_into((v524_14).clone());
    }
    v523_28_cursor.ascend(1);
  }
  drop(v523_28_cursor);
  drop(v523_9);
  (v523_28).clone()
}

fn routine_28(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v545_21 = Space::new();
  let mut v545_21_cursor = (*s0).read_zipper();
  for v545_21_byte in v545_21_cursor.child_mask().iter() {
    v545_21_cursor.descend_to_byte(v545_21_byte);
    {
    let v545_21_tail = v545_21_cursor.fork_read_zipper();
    let v545_21_head = Path::from_slice(&[v545_21_byte]);
    let v546_2: Space = singleton(&(v545_21_head));
    let v546_3: Space = intersect(&(*CONSTANT_2),&(v546_2));
    let v546_4: Space = if has_head(&(v546_3)) { singleton(&[]) } else { Space::new() };
    drop(v546_3);
    let v546_5: Space = subtract(&(*CONSTANT_1),&(v546_4));
    drop(v546_4);
    let v546_8: Space = if (v546_5).is_empty() { Space::new() } else {
      let v547_6: Path = concat_path(&(*p0),&(v545_21_head));
      let mut v547_7 = Space::new();
      let mut v547_7_cursor = (v545_21_tail).read_zipper();
      for v547_7_byte in v547_7_cursor.child_mask().iter() {
        v547_7_cursor.descend_to_byte(v547_7_byte);
        {
        let v547_7_tail = v547_7_cursor.fork_read_zipper();
        let v547_7_head = Path::from_slice(&[v547_7_byte]);
        let v548_2: Space = singleton(&(v547_7_head));
        let v548_3: Space = intersect(&(*CONSTANT_2),&(v548_2));
        let v548_4: Space = if has_head(&(v548_3)) { singleton(&[]) } else { Space::new() };
        drop(v548_3);
        let v548_5: Space = subtract(&(*CONSTANT_1),&(v548_4));
        drop(v548_4);
        let v548_8: Space = if (v548_5).is_empty() { Space::new() } else {
          let v549_6: Path = concat_path(&(v547_6),&(v547_7_head));
          let mut v549_7 = Space::new();
          let mut v549_7_cursor = (v547_7_tail).read_zipper();
          for v549_7_byte in v549_7_cursor.child_mask().iter() {
            v549_7_cursor.descend_to_byte(v549_7_byte);
            {
            let v549_7_tail = v549_7_cursor.fork_read_zipper();
            let v549_7_head = Path::from_slice(&[v549_7_byte]);
            let v550_2: Space = singleton(&(v549_7_head));
            let v550_3: Space = intersect(&(*CONSTANT_2),&(v550_2));
            let v550_4: Space = if has_head(&(v550_3)) { singleton(&[]) } else { Space::new() };
            drop(v550_3);
            let v550_5: Space = subtract(&(*CONSTANT_1),&(v550_4));
            drop(v550_4);
            let v550_8: Space = if (v550_5).is_empty() { Space::new() } else {
              let v551_6: Path = concat_path(&(v549_6),&(v549_7_head));
              let v551_7: Space = routine_40(c, &(v551_6), &(*p1), &(v549_7_tail).make_space());
              compose(&(v550_5),&(v551_7))
            };
            drop(v550_5);
            let v550_9: Space = intersect(&(*CONSTANT_2),&(v550_2));
            drop(v550_2);
            let v550_10: Space = if has_head(&(v550_9)) { singleton(&[]) } else { Space::new() };
            drop(v550_9);
            let v550_12: Space = if (v550_10).is_empty() { Space::new() } else {
              let v552_6: Path = concat_path(&(v549_6),&(v549_7_head));
              let v552_11: Space = routine_41(c, &(v552_6), &(*p1), &(v549_7_tail).make_space());
              drop(v552_6);
              compose(&(v550_10),&(v552_11))
            };
            drop(v550_10);
            let v550_13: Space = unite(&(v550_8),&(v550_12));
            v549_7.join_into((v550_13).clone());
            }
            v549_7_cursor.ascend(1);
          }
          drop(v549_7_cursor);
          compose(&(v548_5),&(v549_7))
        };
        drop(v548_5);
        let v548_9: Space = intersect(&(*CONSTANT_2),&(v548_2));
        drop(v548_2);
        let v548_10: Space = if has_head(&(v548_9)) { singleton(&[]) } else { Space::new() };
        drop(v548_9);
        let v548_12: Space = if (v548_10).is_empty() { Space::new() } else {
          let v553_6: Path = concat_path(&(v547_6),&(v547_7_head));
          let mut v553_11 = Space::new();
          let mut v553_11_cursor = (v547_7_tail).read_zipper();
          for v553_11_byte in v553_11_cursor.child_mask().iter() {
            v553_11_cursor.descend_to_byte(v553_11_byte);
            {
            let v553_11_tail = v553_11_cursor.fork_read_zipper();
            let v553_11_head = Path::from_slice(&[v553_11_byte]);
            let v554_2: Space = singleton(&(v553_11_head));
            let v554_3: Space = intersect(&(*CONSTANT_2),&(v554_2));
            let v554_4: Space = if has_head(&(v554_3)) { singleton(&[]) } else { Space::new() };
            drop(v554_3);
            let v554_5: Space = subtract(&(*CONSTANT_1),&(v554_4));
            drop(v554_4);
            let v554_8: Space = if (v554_5).is_empty() { Space::new() } else {
              let v555_6: Path = concat_path(&(v553_6),&(v553_11_head));
              let v555_7: Space = routine_40(c, &(v555_6), &(*p1), &(v553_11_tail).make_space());
              compose(&(v554_5),&(v555_7))
            };
            drop(v554_5);
            let v554_9: Space = intersect(&(*CONSTANT_2),&(v554_2));
            drop(v554_2);
            let v554_10: Space = if has_head(&(v554_9)) { singleton(&[]) } else { Space::new() };
            drop(v554_9);
            let v554_12: Space = if (v554_10).is_empty() { Space::new() } else {
              let v556_6: Path = concat_path(&(v553_6),&(v553_11_head));
              let v556_11: Space = routine_19(c, &(v556_6), &(*p1), &(v553_11_tail).make_space());
              drop(v556_6);
              compose(&(v554_10),&(v556_11))
            };
            drop(v554_10);
            let v554_13: Space = unite(&(v554_8),&(v554_12));
            v553_11.join_into((v554_13).clone());
            }
            v553_11_cursor.ascend(1);
          }
          drop(v553_11_cursor);
          drop(v553_6);
          compose(&(v548_10),&(v553_11))
        };
        drop(v548_10);
        let v548_13: Space = unite(&(v548_8),&(v548_12));
        v547_7.join_into((v548_13).clone());
        }
        v547_7_cursor.ascend(1);
      }
      drop(v547_7_cursor);
      compose(&(v546_5),&(v547_7))
    };
    drop(v546_5);
    let v546_9: Space = intersect(&(*CONSTANT_2),&(v546_2));
    drop(v546_2);
    let v546_10: Space = if has_head(&(v546_9)) { singleton(&[]) } else { Space::new() };
    drop(v546_9);
    let v546_12: Space = if (v546_10).is_empty() { Space::new() } else {
      let v557_6: Path = concat_path(&(*p0),&(v545_21_head));
      let mut v557_11 = Space::new();
      let mut v557_11_cursor = (v545_21_tail).read_zipper();
      for v557_11_byte in v557_11_cursor.child_mask().iter() {
        v557_11_cursor.descend_to_byte(v557_11_byte);
        {
        let v557_11_tail = v557_11_cursor.fork_read_zipper();
        let v557_11_head = Path::from_slice(&[v557_11_byte]);
        let v558_2: Space = singleton(&(v557_11_head));
        let v558_3: Space = intersect(&(*CONSTANT_2),&(v558_2));
        let v558_4: Space = if has_head(&(v558_3)) { singleton(&[]) } else { Space::new() };
        drop(v558_3);
        let v558_5: Space = subtract(&(*CONSTANT_1),&(v558_4));
        drop(v558_4);
        let v558_8: Space = if (v558_5).is_empty() { Space::new() } else {
          let v559_6: Path = concat_path(&(v557_6),&(v557_11_head));
          let mut v559_7 = Space::new();
          let mut v559_7_cursor = (v557_11_tail).read_zipper();
          for v559_7_byte in v559_7_cursor.child_mask().iter() {
            v559_7_cursor.descend_to_byte(v559_7_byte);
            {
            let v559_7_tail = v559_7_cursor.fork_read_zipper();
            let v559_7_head = Path::from_slice(&[v559_7_byte]);
            let v560_2: Space = singleton(&(v559_7_head));
            let v560_3: Space = intersect(&(*CONSTANT_2),&(v560_2));
            let v560_4: Space = if has_head(&(v560_3)) { singleton(&[]) } else { Space::new() };
            drop(v560_3);
            let v560_5: Space = subtract(&(*CONSTANT_1),&(v560_4));
            drop(v560_4);
            let v560_8: Space = if (v560_5).is_empty() { Space::new() } else {
              let v561_6: Path = concat_path(&(v559_6),&(v559_7_head));
              let v561_7: Space = routine_40(c, &(v561_6), &(*p1), &(v559_7_tail).make_space());
              compose(&(v560_5),&(v561_7))
            };
            drop(v560_5);
            let v560_9: Space = intersect(&(*CONSTANT_2),&(v560_2));
            drop(v560_2);
            let v560_10: Space = if has_head(&(v560_9)) { singleton(&[]) } else { Space::new() };
            drop(v560_9);
            let v560_12: Space = if (v560_10).is_empty() { Space::new() } else {
              let v562_6: Path = concat_path(&(v559_6),&(v559_7_head));
              let v562_11: Space = routine_41(c, &(v562_6), &(*p1), &(v559_7_tail).make_space());
              drop(v562_6);
              compose(&(v560_10),&(v562_11))
            };
            drop(v560_10);
            let v560_13: Space = unite(&(v560_8),&(v560_12));
            v559_7.join_into((v560_13).clone());
            }
            v559_7_cursor.ascend(1);
          }
          drop(v559_7_cursor);
          compose(&(v558_5),&(v559_7))
        };
        drop(v558_5);
        let v558_9: Space = intersect(&(*CONSTANT_2),&(v558_2));
        drop(v558_2);
        let v558_10: Space = if has_head(&(v558_9)) { singleton(&[]) } else { Space::new() };
        drop(v558_9);
        let v558_11: Space = compose(&(v558_10),&(v557_11_tail));
        drop(v558_10);
        let v563_6: Path = concat_path(&(v557_6),&(v557_11_head));
        let v558_12: Space = wrap(&(v558_11),&(v563_6));
        drop(v558_11);
        let v558_13: Space = wrap(&(v558_12),&(*p1));
        drop(v558_12);
        let v558_14: Space = unite(&(v558_8),&(v558_13));
        drop(v558_13);
        v557_11.join_into((v558_14).clone());
        }
        v557_11_cursor.ascend(1);
      }
      drop(v557_11_cursor);
      drop(v557_6);
      compose(&(v546_10),&(v557_11))
    };
    drop(v546_10);
    let v546_13: Space = unite(&(v546_8),&(v546_12));
    v545_21.join_into((v546_13).clone());
    }
    v545_21_cursor.ascend(1);
  }
  drop(v545_21_cursor);
  (v545_21).clone()
}

fn routine_29(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v564_15 = Space::new();
  let mut v564_15_cursor = (*s0).read_zipper();
  for v564_15_byte in v564_15_cursor.child_mask().iter() {
    v564_15_cursor.descend_to_byte(v564_15_byte);
    {
    let v564_15_tail = v564_15_cursor.fork_read_zipper();
    let v564_15_head = Path::from_slice(&[v564_15_byte]);
    let v565_2: Space = singleton(&(v564_15_head));
    let v565_3: Space = intersect(&(*CONSTANT_2),&(v565_2));
    let v565_4: Space = if has_head(&(v565_3)) { singleton(&[]) } else { Space::new() };
    drop(v565_3);
    let v565_5: Space = subtract(&(*CONSTANT_1),&(v565_4));
    drop(v565_4);
    let v565_8: Space = if (v565_5).is_empty() { Space::new() } else {
      let v566_6: Path = concat_path(&(*p0),&(v564_15_head));
      let mut v566_7 = Space::new();
      let mut v566_7_cursor = (v564_15_tail).read_zipper();
      for v566_7_byte in v566_7_cursor.child_mask().iter() {
        v566_7_cursor.descend_to_byte(v566_7_byte);
        {
        let v566_7_tail = v566_7_cursor.fork_read_zipper();
        let v566_7_head = Path::from_slice(&[v566_7_byte]);
        let v567_2: Space = singleton(&(v566_7_head));
        let v567_3: Space = intersect(&(*CONSTANT_2),&(v567_2));
        let v567_4: Space = if has_head(&(v567_3)) { singleton(&[]) } else { Space::new() };
        drop(v567_3);
        let v567_5: Space = subtract(&(*CONSTANT_1),&(v567_4));
        drop(v567_4);
        let v567_8: Space = if (v567_5).is_empty() { Space::new() } else {
          let v568_6: Path = concat_path(&(v566_6),&(v566_7_head));
          let mut v568_7 = Space::new();
          let mut v568_7_cursor = (v566_7_tail).read_zipper();
          for v568_7_byte in v568_7_cursor.child_mask().iter() {
            v568_7_cursor.descend_to_byte(v568_7_byte);
            {
            let v568_7_tail = v568_7_cursor.fork_read_zipper();
            let v568_7_head = Path::from_slice(&[v568_7_byte]);
            let v569_2: Space = singleton(&(v568_7_head));
            let v569_3: Space = intersect(&(*CONSTANT_2),&(v569_2));
            let v569_4: Space = if has_head(&(v569_3)) { singleton(&[]) } else { Space::new() };
            drop(v569_3);
            let v569_5: Space = subtract(&(*CONSTANT_1),&(v569_4));
            drop(v569_4);
            let v569_8: Space = if (v569_5).is_empty() { Space::new() } else {
              let v570_6: Path = concat_path(&(v568_6),&(v568_7_head));
              let v570_7: Space = routine_40(c, &(v570_6), &(*p1), &(v568_7_tail).make_space());
              compose(&(v569_5),&(v570_7))
            };
            drop(v569_5);
            let v569_9: Space = intersect(&(*CONSTANT_2),&(v569_2));
            drop(v569_2);
            let v569_10: Space = if has_head(&(v569_9)) { singleton(&[]) } else { Space::new() };
            drop(v569_9);
            let v569_12: Space = if (v569_10).is_empty() { Space::new() } else {
              let v571_6: Path = concat_path(&(v568_6),&(v568_7_head));
              let v571_11: Space = routine_41(c, &(v571_6), &(*p1), &(v568_7_tail).make_space());
              drop(v571_6);
              compose(&(v569_10),&(v571_11))
            };
            drop(v569_10);
            let v569_13: Space = unite(&(v569_8),&(v569_12));
            v568_7.join_into((v569_13).clone());
            }
            v568_7_cursor.ascend(1);
          }
          drop(v568_7_cursor);
          compose(&(v567_5),&(v568_7))
        };
        drop(v567_5);
        let v567_9: Space = intersect(&(*CONSTANT_2),&(v567_2));
        drop(v567_2);
        let v567_10: Space = if has_head(&(v567_9)) { singleton(&[]) } else { Space::new() };
        drop(v567_9);
        let v567_12: Space = if (v567_10).is_empty() { Space::new() } else {
          let v572_6: Path = concat_path(&(v566_6),&(v566_7_head));
          let mut v572_11 = Space::new();
          let mut v572_11_cursor = (v566_7_tail).read_zipper();
          for v572_11_byte in v572_11_cursor.child_mask().iter() {
            v572_11_cursor.descend_to_byte(v572_11_byte);
            {
            let v572_11_tail = v572_11_cursor.fork_read_zipper();
            let v572_11_head = Path::from_slice(&[v572_11_byte]);
            let v573_2: Space = singleton(&(v572_11_head));
            let v573_3: Space = intersect(&(*CONSTANT_2),&(v573_2));
            let v573_4: Space = if has_head(&(v573_3)) { singleton(&[]) } else { Space::new() };
            drop(v573_3);
            let v573_5: Space = subtract(&(*CONSTANT_1),&(v573_4));
            drop(v573_4);
            let v573_8: Space = if (v573_5).is_empty() { Space::new() } else {
              let v574_6: Path = concat_path(&(v572_6),&(v572_11_head));
              let v574_7: Space = routine_40(c, &(v574_6), &(*p1), &(v572_11_tail).make_space());
              compose(&(v573_5),&(v574_7))
            };
            drop(v573_5);
            let v573_9: Space = intersect(&(*CONSTANT_2),&(v573_2));
            drop(v573_2);
            let v573_10: Space = if has_head(&(v573_9)) { singleton(&[]) } else { Space::new() };
            drop(v573_9);
            let v573_12: Space = if (v573_10).is_empty() { Space::new() } else {
              let v575_6: Path = concat_path(&(v572_6),&(v572_11_head));
              let v575_11: Space = routine_19(c, &(v575_6), &(*p1), &(v572_11_tail).make_space());
              drop(v575_6);
              compose(&(v573_10),&(v575_11))
            };
            drop(v573_10);
            let v573_13: Space = unite(&(v573_8),&(v573_12));
            v572_11.join_into((v573_13).clone());
            }
            v572_11_cursor.ascend(1);
          }
          drop(v572_11_cursor);
          drop(v572_6);
          compose(&(v567_10),&(v572_11))
        };
        drop(v567_10);
        let v567_13: Space = unite(&(v567_8),&(v567_12));
        v566_7.join_into((v567_13).clone());
        }
        v566_7_cursor.ascend(1);
      }
      drop(v566_7_cursor);
      compose(&(v565_5),&(v566_7))
    };
    drop(v565_5);
    let v565_9: Space = intersect(&(*CONSTANT_2),&(v565_2));
    drop(v565_2);
    let v565_10: Space = if has_head(&(v565_9)) { singleton(&[]) } else { Space::new() };
    drop(v565_9);
    let v565_11: Space = compose(&(v565_10),&(v564_15_tail));
    drop(v565_10);
    let v576_6: Path = concat_path(&(*p0),&(v564_15_head));
    let v565_12: Space = wrap(&(v565_11),&(v576_6));
    drop(v565_11);
    let v565_13: Space = wrap(&(v565_12),&(*p1));
    drop(v565_12);
    let v565_14: Space = unite(&(v565_8),&(v565_13));
    drop(v565_13);
    v564_15.join_into((v565_14).clone());
    }
    v564_15_cursor.ascend(1);
  }
  drop(v564_15_cursor);
  (v564_15).clone()
}

fn routine_30(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v577_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v577_21: Space = unwrap(&(v577_20),&(*p0));
  drop(v577_20);
  let mut v577_28 = Space::new();
  let mut v577_28_cursor = (*s0).read_zipper();
  for v577_28_byte in v577_28_cursor.child_mask().iter() {
    v577_28_cursor.descend_to_byte(v577_28_byte);
    {
    let v577_28_tail = v577_28_cursor.fork_read_zipper();
    let v577_28_head = Path::from_slice(&[v577_28_byte]);
    let v578_2: Space = singleton(&(v577_28_head));
    let v578_3: Space = intersect(&(*CONSTANT_2),&(v578_2));
    let v578_4: Space = if has_head(&(v578_3)) { singleton(&[]) } else { Space::new() };
    drop(v578_3);
    let v578_5: Space = subtract(&(*CONSTANT_1),&(v578_4));
    drop(v578_4);
    let v578_8: Space = if (v578_5).is_empty() { Space::new() } else {
      let v579_6: Path = concat_path(&(*p0),&(v577_28_head));
      let mut v579_7 = Space::new();
      let mut v579_7_cursor = (v577_28_tail).read_zipper();
      for v579_7_byte in v579_7_cursor.child_mask().iter() {
        v579_7_cursor.descend_to_byte(v579_7_byte);
        {
        let v579_7_tail = v579_7_cursor.fork_read_zipper();
        let v579_7_head = Path::from_slice(&[v579_7_byte]);
        let v580_2: Space = singleton(&(v579_7_head));
        let v580_3: Space = intersect(&(*CONSTANT_2),&(v580_2));
        let v580_4: Space = if has_head(&(v580_3)) { singleton(&[]) } else { Space::new() };
        drop(v580_3);
        let v580_5: Space = subtract(&(*CONSTANT_1),&(v580_4));
        drop(v580_4);
        let v580_8: Space = if (v580_5).is_empty() { Space::new() } else {
          let v581_6: Path = concat_path(&(v579_6),&(v579_7_head));
          let mut v581_7 = Space::new();
          let mut v581_7_cursor = (v579_7_tail).read_zipper();
          for v581_7_byte in v581_7_cursor.child_mask().iter() {
            v581_7_cursor.descend_to_byte(v581_7_byte);
            {
            let v581_7_tail = v581_7_cursor.fork_read_zipper();
            let v581_7_head = Path::from_slice(&[v581_7_byte]);
            let v582_2: Space = singleton(&(v581_7_head));
            let v582_3: Space = intersect(&(*CONSTANT_2),&(v582_2));
            let v582_4: Space = if has_head(&(v582_3)) { singleton(&[]) } else { Space::new() };
            drop(v582_3);
            let v582_5: Space = subtract(&(*CONSTANT_1),&(v582_4));
            drop(v582_4);
            let v582_8: Space = if (v582_5).is_empty() { Space::new() } else {
              let v583_6: Path = concat_path(&(v581_6),&(v581_7_head));
              let v583_7: Space = routine_42(c, &(v583_6), &(*p1), &(v581_7_tail).make_space(), &(*s1));
              compose(&(v582_5),&(v583_7))
            };
            drop(v582_5);
            let v582_9: Space = intersect(&(*CONSTANT_2),&(v582_2));
            drop(v582_2);
            let v582_10: Space = if has_head(&(v582_9)) { singleton(&[]) } else { Space::new() };
            drop(v582_9);
            let v582_12: Space = if (v582_10).is_empty() { Space::new() } else {
              let v584_6: Path = concat_path(&(v581_6),&(v581_7_head));
              let v584_11: Space = routine_43(c, &(v584_6), &(*p1), &(v581_7_tail).make_space(), &(*s1));
              drop(v584_6);
              compose(&(v582_10),&(v584_11))
            };
            drop(v582_10);
            let v582_13: Space = unite(&(v582_8),&(v582_12));
            v581_7.join_into((v582_13).clone());
            }
            v581_7_cursor.ascend(1);
          }
          drop(v581_7_cursor);
          compose(&(v580_5),&(v581_7))
        };
        drop(v580_5);
        let v580_9: Space = intersect(&(*CONSTANT_2),&(v580_2));
        drop(v580_2);
        let v580_10: Space = if has_head(&(v580_9)) { singleton(&[]) } else { Space::new() };
        drop(v580_9);
        let v580_12: Space = if (v580_10).is_empty() { Space::new() } else {
          let v585_6: Path = concat_path(&(v579_6),&(v579_7_head));
          let mut v585_11 = Space::new();
          let mut v585_11_cursor = (v579_7_tail).read_zipper();
          for v585_11_byte in v585_11_cursor.child_mask().iter() {
            v585_11_cursor.descend_to_byte(v585_11_byte);
            {
            let v585_11_tail = v585_11_cursor.fork_read_zipper();
            let v585_11_head = Path::from_slice(&[v585_11_byte]);
            let v586_2: Space = singleton(&(v585_11_head));
            let v586_3: Space = intersect(&(*CONSTANT_2),&(v586_2));
            let v586_4: Space = if has_head(&(v586_3)) { singleton(&[]) } else { Space::new() };
            drop(v586_3);
            let v586_5: Space = subtract(&(*CONSTANT_1),&(v586_4));
            drop(v586_4);
            let v586_8: Space = if (v586_5).is_empty() { Space::new() } else {
              let v587_6: Path = concat_path(&(v585_6),&(v585_11_head));
              let v587_7: Space = routine_42(c, &(v587_6), &(*p1), &(v585_11_tail).make_space(), &(*s1));
              compose(&(v586_5),&(v587_7))
            };
            drop(v586_5);
            let v586_9: Space = intersect(&(*CONSTANT_2),&(v586_2));
            drop(v586_2);
            let v586_10: Space = if has_head(&(v586_9)) { singleton(&[]) } else { Space::new() };
            drop(v586_9);
            let v586_12: Space = if (v586_10).is_empty() { Space::new() } else {
              let v588_6: Path = concat_path(&(v585_6),&(v585_11_head));
              let v588_11: Space = routine_10(c, &(v588_6), &(*p1), &(v585_11_tail).make_space(), &(*s1));
              drop(v588_6);
              compose(&(v586_10),&(v588_11))
            };
            drop(v586_10);
            let v586_13: Space = unite(&(v586_8),&(v586_12));
            v585_11.join_into((v586_13).clone());
            }
            v585_11_cursor.ascend(1);
          }
          drop(v585_11_cursor);
          drop(v585_6);
          compose(&(v580_10),&(v585_11))
        };
        drop(v580_10);
        let v580_13: Space = unite(&(v580_8),&(v580_12));
        v579_7.join_into((v580_13).clone());
        }
        v579_7_cursor.ascend(1);
      }
      drop(v579_7_cursor);
      compose(&(v578_5),&(v579_7))
    };
    drop(v578_5);
    let v578_9: Space = intersect(&(*CONSTANT_2),&(v578_2));
    drop(v578_2);
    let v578_10: Space = if has_head(&(v578_9)) { singleton(&[]) } else { Space::new() };
    drop(v578_9);
    let v578_13: Space = if (v578_10).is_empty() { Space::new() } else {
      let v589_6: Path = concat_path(&(*p0),&(v577_28_head));
      let v589_11: Space = unwrap(&(v577_21),&(v577_28_head));
      let mut v589_12 = Space::new();
      let mut v589_12_cursor = (v577_28_tail).read_zipper();
      for v589_12_byte in v589_12_cursor.child_mask().iter() {
        v589_12_cursor.descend_to_byte(v589_12_byte);
        {
        let v589_12_tail = v589_12_cursor.fork_read_zipper();
        let v589_12_head = Path::from_slice(&[v589_12_byte]);
        let v590_2: Space = singleton(&(v589_12_head));
        let v590_3: Space = intersect(&(*CONSTANT_2),&(v590_2));
        let v590_4: Space = if has_head(&(v590_3)) { singleton(&[]) } else { Space::new() };
        drop(v590_3);
        let v590_5: Space = subtract(&(*CONSTANT_1),&(v590_4));
        drop(v590_4);
        let v590_8: Space = if (v590_5).is_empty() { Space::new() } else {
          let v591_6: Path = concat_path(&(v589_6),&(v589_12_head));
          let mut v591_7 = Space::new();
          let mut v591_7_cursor = (v589_12_tail).read_zipper();
          for v591_7_byte in v591_7_cursor.child_mask().iter() {
            v591_7_cursor.descend_to_byte(v591_7_byte);
            {
            let v591_7_tail = v591_7_cursor.fork_read_zipper();
            let v591_7_head = Path::from_slice(&[v591_7_byte]);
            let v592_2: Space = singleton(&(v591_7_head));
            let v592_3: Space = intersect(&(*CONSTANT_2),&(v592_2));
            let v592_4: Space = if has_head(&(v592_3)) { singleton(&[]) } else { Space::new() };
            drop(v592_3);
            let v592_5: Space = subtract(&(*CONSTANT_1),&(v592_4));
            drop(v592_4);
            let v592_8: Space = if (v592_5).is_empty() { Space::new() } else {
              let v593_6: Path = concat_path(&(v591_6),&(v591_7_head));
              let v593_7: Space = routine_42(c, &(v593_6), &(*p1), &(v591_7_tail).make_space(), &(*s1));
              compose(&(v592_5),&(v593_7))
            };
            drop(v592_5);
            let v592_9: Space = intersect(&(*CONSTANT_2),&(v592_2));
            drop(v592_2);
            let v592_10: Space = if has_head(&(v592_9)) { singleton(&[]) } else { Space::new() };
            drop(v592_9);
            let v592_12: Space = if (v592_10).is_empty() { Space::new() } else {
              let v594_6: Path = concat_path(&(v591_6),&(v591_7_head));
              let v594_11: Space = routine_43(c, &(v594_6), &(*p1), &(v591_7_tail).make_space(), &(*s1));
              drop(v594_6);
              compose(&(v592_10),&(v594_11))
            };
            drop(v592_10);
            let v592_13: Space = unite(&(v592_8),&(v592_12));
            v591_7.join_into((v592_13).clone());
            }
            v591_7_cursor.ascend(1);
          }
          drop(v591_7_cursor);
          drop(v591_6);
          compose(&(v590_5),&(v591_7))
        };
        drop(v590_5);
        let v590_9: Space = intersect(&(*CONSTANT_2),&(v590_2));
        drop(v590_2);
        let v590_10: Space = if has_head(&(v590_9)) { singleton(&[]) } else { Space::new() };
        drop(v590_9);
        let v590_13: Space = if (v590_10).is_empty() { Space::new() } else {
          let v595_11: Space = unwrap(&(v589_11),&(v589_12_head));
          let mut v595_12 = Space::new();
          let mut v595_12_cursor = (v595_11).read_zipper();
          for v595_12_byte in v595_12_cursor.child_mask().iter() {
            v595_12_cursor.descend_to_byte(v595_12_byte);
            {
            let v595_12_tail = v595_12_cursor.fork_read_zipper();
            let v595_12_head = Path::from_slice(&[v595_12_byte]);
            let v596_2: Space = singleton(&(v595_12_head));
            let v596_3: Space = intersect(&(*CONSTANT_2),&(v596_2));
            let v596_4: Space = if has_head(&(v596_3)) { singleton(&[]) } else { Space::new() };
            drop(v596_3);
            let v596_5: Space = subtract(&(*CONSTANT_1),&(v596_4));
            drop(v596_4);
            let v596_7: Space = if (v596_5).is_empty() { Space::new() } else {
              let v597_6: Space = routine_13(c, &(v595_12_head), &(*p1), &(v595_12_tail).make_space());
              compose(&(v596_5),&(v597_6))
            };
            drop(v596_5);
            let v596_8: Space = intersect(&(*CONSTANT_2),&(v596_2));
            drop(v596_2);
            let v596_9: Space = if has_head(&(v596_8)) { singleton(&[]) } else { Space::new() };
            drop(v596_8);
            let v596_11: Space = if (v596_9).is_empty() { Space::new() } else {
              let v598_10: Space = routine_14(c, &(v595_12_head), &(*p1), &(v595_12_tail).make_space());
              compose(&(v596_9),&(v598_10))
            };
            drop(v596_9);
            let v596_12: Space = unite(&(v596_7),&(v596_11));
            v595_12.join_into((v596_12).clone());
            }
            v595_12_cursor.ascend(1);
          }
          drop(v595_12_cursor);
          drop(v595_11);
          compose(&(v590_10),&(v595_12))
        };
        drop(v590_10);
        let v590_14: Space = unite(&(v590_8),&(v590_13));
        v589_12.join_into((v590_14).clone());
        }
        v589_12_cursor.ascend(1);
      }
      drop(v589_12_cursor);
      drop(v589_6);
      drop(v589_11);
      compose(&(v578_10),&(v589_12))
    };
    drop(v578_10);
    let v578_14: Space = unite(&(v578_8),&(v578_13));
    v577_28.join_into((v578_14).clone());
    }
    v577_28_cursor.ascend(1);
  }
  drop(v577_28_cursor);
  drop(v577_21);
  (v577_28).clone()
}

fn routine_31(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v599_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v599_9: Space = unwrap(&(v599_8),&(*p0));
  drop(v599_8);
  let mut v599_28 = Space::new();
  let mut v599_28_cursor = (*s0).read_zipper();
  for v599_28_byte in v599_28_cursor.child_mask().iter() {
    v599_28_cursor.descend_to_byte(v599_28_byte);
    {
    let v599_28_tail = v599_28_cursor.fork_read_zipper();
    let v599_28_head = Path::from_slice(&[v599_28_byte]);
    let v600_2: Space = singleton(&(v599_28_head));
    let v600_3: Space = intersect(&(*CONSTANT_2),&(v600_2));
    let v600_4: Space = if has_head(&(v600_3)) { singleton(&[]) } else { Space::new() };
    drop(v600_3);
    let v600_5: Space = subtract(&(*CONSTANT_1),&(v600_4));
    drop(v600_4);
    let v600_8: Space = if (v600_5).is_empty() { Space::new() } else {
      let v601_6: Path = concat_path(&(*p0),&(v599_28_head));
      let mut v601_7 = Space::new();
      let mut v601_7_cursor = (v599_28_tail).read_zipper();
      for v601_7_byte in v601_7_cursor.child_mask().iter() {
        v601_7_cursor.descend_to_byte(v601_7_byte);
        {
        let v601_7_tail = v601_7_cursor.fork_read_zipper();
        let v601_7_head = Path::from_slice(&[v601_7_byte]);
        let v602_2: Space = singleton(&(v601_7_head));
        let v602_3: Space = intersect(&(*CONSTANT_2),&(v602_2));
        let v602_4: Space = if has_head(&(v602_3)) { singleton(&[]) } else { Space::new() };
        drop(v602_3);
        let v602_5: Space = subtract(&(*CONSTANT_1),&(v602_4));
        drop(v602_4);
        let v602_8: Space = if (v602_5).is_empty() { Space::new() } else {
          let v603_6: Path = concat_path(&(v601_6),&(v601_7_head));
          let mut v603_7 = Space::new();
          let mut v603_7_cursor = (v601_7_tail).read_zipper();
          for v603_7_byte in v603_7_cursor.child_mask().iter() {
            v603_7_cursor.descend_to_byte(v603_7_byte);
            {
            let v603_7_tail = v603_7_cursor.fork_read_zipper();
            let v603_7_head = Path::from_slice(&[v603_7_byte]);
            let v604_2: Space = singleton(&(v603_7_head));
            let v604_3: Space = intersect(&(*CONSTANT_2),&(v604_2));
            let v604_4: Space = if has_head(&(v604_3)) { singleton(&[]) } else { Space::new() };
            drop(v604_3);
            let v604_5: Space = subtract(&(*CONSTANT_1),&(v604_4));
            drop(v604_4);
            let v604_8: Space = if (v604_5).is_empty() { Space::new() } else {
              let v605_6: Path = concat_path(&(v603_6),&(v603_7_head));
              let v605_7: Space = routine_42(c, &(v605_6), &(*p1), &(v603_7_tail).make_space(), &(*s1));
              compose(&(v604_5),&(v605_7))
            };
            drop(v604_5);
            let v604_9: Space = intersect(&(*CONSTANT_2),&(v604_2));
            drop(v604_2);
            let v604_10: Space = if has_head(&(v604_9)) { singleton(&[]) } else { Space::new() };
            drop(v604_9);
            let v604_12: Space = if (v604_10).is_empty() { Space::new() } else {
              let v606_6: Path = concat_path(&(v603_6),&(v603_7_head));
              let v606_11: Space = routine_43(c, &(v606_6), &(*p1), &(v603_7_tail).make_space(), &(*s1));
              drop(v606_6);
              compose(&(v604_10),&(v606_11))
            };
            drop(v604_10);
            let v604_13: Space = unite(&(v604_8),&(v604_12));
            v603_7.join_into((v604_13).clone());
            }
            v603_7_cursor.ascend(1);
          }
          drop(v603_7_cursor);
          compose(&(v602_5),&(v603_7))
        };
        drop(v602_5);
        let v602_9: Space = intersect(&(*CONSTANT_2),&(v602_2));
        drop(v602_2);
        let v602_10: Space = if has_head(&(v602_9)) { singleton(&[]) } else { Space::new() };
        drop(v602_9);
        let v602_12: Space = if (v602_10).is_empty() { Space::new() } else {
          let v607_6: Path = concat_path(&(v601_6),&(v601_7_head));
          let mut v607_11 = Space::new();
          let mut v607_11_cursor = (v601_7_tail).read_zipper();
          for v607_11_byte in v607_11_cursor.child_mask().iter() {
            v607_11_cursor.descend_to_byte(v607_11_byte);
            {
            let v607_11_tail = v607_11_cursor.fork_read_zipper();
            let v607_11_head = Path::from_slice(&[v607_11_byte]);
            let v608_2: Space = singleton(&(v607_11_head));
            let v608_3: Space = intersect(&(*CONSTANT_2),&(v608_2));
            let v608_4: Space = if has_head(&(v608_3)) { singleton(&[]) } else { Space::new() };
            drop(v608_3);
            let v608_5: Space = subtract(&(*CONSTANT_1),&(v608_4));
            drop(v608_4);
            let v608_8: Space = if (v608_5).is_empty() { Space::new() } else {
              let v609_6: Path = concat_path(&(v607_6),&(v607_11_head));
              let v609_7: Space = routine_42(c, &(v609_6), &(*p1), &(v607_11_tail).make_space(), &(*s1));
              compose(&(v608_5),&(v609_7))
            };
            drop(v608_5);
            let v608_9: Space = intersect(&(*CONSTANT_2),&(v608_2));
            drop(v608_2);
            let v608_10: Space = if has_head(&(v608_9)) { singleton(&[]) } else { Space::new() };
            drop(v608_9);
            let v608_12: Space = if (v608_10).is_empty() { Space::new() } else {
              let v610_6: Path = concat_path(&(v607_6),&(v607_11_head));
              let v610_11: Space = routine_10(c, &(v610_6), &(*p1), &(v607_11_tail).make_space(), &(*s1));
              drop(v610_6);
              compose(&(v608_10),&(v610_11))
            };
            drop(v608_10);
            let v608_13: Space = unite(&(v608_8),&(v608_12));
            v607_11.join_into((v608_13).clone());
            }
            v607_11_cursor.ascend(1);
          }
          drop(v607_11_cursor);
          drop(v607_6);
          compose(&(v602_10),&(v607_11))
        };
        drop(v602_10);
        let v602_13: Space = unite(&(v602_8),&(v602_12));
        v601_7.join_into((v602_13).clone());
        }
        v601_7_cursor.ascend(1);
      }
      drop(v601_7_cursor);
      drop(v601_6);
      compose(&(v600_5),&(v601_7))
    };
    drop(v600_5);
    let v600_9: Space = intersect(&(*CONSTANT_2),&(v600_2));
    drop(v600_2);
    let v600_10: Space = if has_head(&(v600_9)) { singleton(&[]) } else { Space::new() };
    drop(v600_9);
    let v600_13: Space = if (v600_10).is_empty() { Space::new() } else {
      let v611_11: Space = unwrap(&(v599_9),&(v599_28_head));
      let mut v611_12 = Space::new();
      let mut v611_12_cursor = (v611_11).read_zipper();
      for v611_12_byte in v611_12_cursor.child_mask().iter() {
        v611_12_cursor.descend_to_byte(v611_12_byte);
        {
        let v611_12_tail = v611_12_cursor.fork_read_zipper();
        let v611_12_head = Path::from_slice(&[v611_12_byte]);
        let v612_2: Space = singleton(&(v611_12_head));
        let v612_3: Space = intersect(&(*CONSTANT_2),&(v612_2));
        let v612_4: Space = if has_head(&(v612_3)) { singleton(&[]) } else { Space::new() };
        drop(v612_3);
        let v612_5: Space = subtract(&(*CONSTANT_1),&(v612_4));
        drop(v612_4);
        let v612_7: Space = if (v612_5).is_empty() { Space::new() } else {
          let mut v613_6 = Space::new();
          let mut v613_6_cursor = (v611_12_tail).read_zipper();
          for v613_6_byte in v613_6_cursor.child_mask().iter() {
            v613_6_cursor.descend_to_byte(v613_6_byte);
            {
            let v613_6_tail = v613_6_cursor.fork_read_zipper();
            let v613_6_head = Path::from_slice(&[v613_6_byte]);
            let v614_2: Space = singleton(&(v613_6_head));
            let v614_3: Space = intersect(&(*CONSTANT_2),&(v614_2));
            let v614_4: Space = if has_head(&(v614_3)) { singleton(&[]) } else { Space::new() };
            drop(v614_3);
            let v614_5: Space = subtract(&(*CONSTANT_1),&(v614_4));
            drop(v614_4);
            let v614_8: Space = if (v614_5).is_empty() { Space::new() } else {
              let v615_6: Path = concat_path(&(v611_12_head),&(v613_6_head));
              let v615_7: Space = routine_17(c, &(v615_6), &(*p1), &(v613_6_tail).make_space());
              compose(&(v614_5),&(v615_7))
            };
            drop(v614_5);
            let v614_9: Space = intersect(&(*CONSTANT_2),&(v614_2));
            drop(v614_2);
            let v614_10: Space = if has_head(&(v614_9)) { singleton(&[]) } else { Space::new() };
            drop(v614_9);
            let v614_12: Space = if (v614_10).is_empty() { Space::new() } else {
              let v616_6: Path = concat_path(&(v611_12_head),&(v613_6_head));
              let v616_11: Space = routine_18(c, &(v616_6), &(*p1), &(v613_6_tail).make_space());
              drop(v616_6);
              compose(&(v614_10),&(v616_11))
            };
            drop(v614_10);
            let v614_13: Space = unite(&(v614_8),&(v614_12));
            v613_6.join_into((v614_13).clone());
            }
            v613_6_cursor.ascend(1);
          }
          drop(v613_6_cursor);
          compose(&(v612_5),&(v613_6))
        };
        drop(v612_5);
        let v612_8: Space = intersect(&(*CONSTANT_2),&(v612_2));
        drop(v612_2);
        let v612_9: Space = if has_head(&(v612_8)) { singleton(&[]) } else { Space::new() };
        drop(v612_8);
        let v612_11: Space = if (v612_9).is_empty() { Space::new() } else {
          let mut v617_10 = Space::new();
          let mut v617_10_cursor = (v611_12_tail).read_zipper();
          for v617_10_byte in v617_10_cursor.child_mask().iter() {
            v617_10_cursor.descend_to_byte(v617_10_byte);
            {
            let v617_10_tail = v617_10_cursor.fork_read_zipper();
            let v617_10_head = Path::from_slice(&[v617_10_byte]);
            let v618_2: Space = singleton(&(v617_10_head));
            let v618_3: Space = intersect(&(*CONSTANT_2),&(v618_2));
            let v618_4: Space = if has_head(&(v618_3)) { singleton(&[]) } else { Space::new() };
            drop(v618_3);
            let v618_5: Space = subtract(&(*CONSTANT_1),&(v618_4));
            drop(v618_4);
            let v618_8: Space = if (v618_5).is_empty() { Space::new() } else {
              let v619_6: Path = concat_path(&(v611_12_head),&(v617_10_head));
              let v619_7: Space = routine_17(c, &(v619_6), &(*p1), &(v617_10_tail).make_space());
              compose(&(v618_5),&(v619_7))
            };
            drop(v618_5);
            let v618_9: Space = intersect(&(*CONSTANT_2),&(v618_2));
            drop(v618_2);
            let v618_10: Space = if has_head(&(v618_9)) { singleton(&[]) } else { Space::new() };
            drop(v618_9);
            let v618_12: Space = if (v618_10).is_empty() { Space::new() } else {
              let v620_6: Path = concat_path(&(v611_12_head),&(v617_10_head));
              let v620_11: Space = routine_19(c, &(v620_6), &(*p1), &(v617_10_tail).make_space());
              drop(v620_6);
              compose(&(v618_10),&(v620_11))
            };
            drop(v618_10);
            let v618_13: Space = unite(&(v618_8),&(v618_12));
            v617_10.join_into((v618_13).clone());
            }
            v617_10_cursor.ascend(1);
          }
          drop(v617_10_cursor);
          compose(&(v612_9),&(v617_10))
        };
        drop(v612_9);
        let v612_12: Space = unite(&(v612_7),&(v612_11));
        v611_12.join_into((v612_12).clone());
        }
        v611_12_cursor.ascend(1);
      }
      drop(v611_12_cursor);
      drop(v611_11);
      compose(&(v600_10),&(v611_12))
    };
    drop(v600_10);
    let v600_14: Space = unite(&(v600_8),&(v600_13));
    v599_28.join_into((v600_14).clone());
    }
    v599_28_cursor.ascend(1);
  }
  drop(v599_28_cursor);
  drop(v599_9);
  (v599_28).clone()
}

fn routine_32(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v621_21 = Space::new();
  let mut v621_21_cursor = (*s0).read_zipper();
  for v621_21_byte in v621_21_cursor.child_mask().iter() {
    v621_21_cursor.descend_to_byte(v621_21_byte);
    {
    let v621_21_tail = v621_21_cursor.fork_read_zipper();
    let v621_21_head = Path::from_slice(&[v621_21_byte]);
    let v622_2: Space = singleton(&(v621_21_head));
    let v622_3: Space = intersect(&(*CONSTANT_2),&(v622_2));
    let v622_4: Space = if has_head(&(v622_3)) { singleton(&[]) } else { Space::new() };
    drop(v622_3);
    let v622_5: Space = subtract(&(*CONSTANT_1),&(v622_4));
    drop(v622_4);
    let v622_8: Space = if (v622_5).is_empty() { Space::new() } else {
      let v623_6: Path = concat_path(&(*p0),&(v621_21_head));
      let mut v623_7 = Space::new();
      let mut v623_7_cursor = (v621_21_tail).read_zipper();
      for v623_7_byte in v623_7_cursor.child_mask().iter() {
        v623_7_cursor.descend_to_byte(v623_7_byte);
        {
        let v623_7_tail = v623_7_cursor.fork_read_zipper();
        let v623_7_head = Path::from_slice(&[v623_7_byte]);
        let v624_2: Space = singleton(&(v623_7_head));
        let v624_3: Space = intersect(&(*CONSTANT_2),&(v624_2));
        let v624_4: Space = if has_head(&(v624_3)) { singleton(&[]) } else { Space::new() };
        drop(v624_3);
        let v624_5: Space = subtract(&(*CONSTANT_1),&(v624_4));
        drop(v624_4);
        let v624_8: Space = if (v624_5).is_empty() { Space::new() } else {
          let v625_6: Path = concat_path(&(v623_6),&(v623_7_head));
          let mut v625_7 = Space::new();
          let mut v625_7_cursor = (v623_7_tail).read_zipper();
          for v625_7_byte in v625_7_cursor.child_mask().iter() {
            v625_7_cursor.descend_to_byte(v625_7_byte);
            {
            let v625_7_tail = v625_7_cursor.fork_read_zipper();
            let v625_7_head = Path::from_slice(&[v625_7_byte]);
            let v626_2: Space = singleton(&(v625_7_head));
            let v626_3: Space = intersect(&(*CONSTANT_2),&(v626_2));
            let v626_4: Space = if has_head(&(v626_3)) { singleton(&[]) } else { Space::new() };
            drop(v626_3);
            let v626_5: Space = subtract(&(*CONSTANT_1),&(v626_4));
            drop(v626_4);
            let v626_8: Space = if (v626_5).is_empty() { Space::new() } else {
              let v627_6: Path = concat_path(&(v625_6),&(v625_7_head));
              let v627_7: Space = routine_44(c, &(v627_6), &(*p1), &(v625_7_tail).make_space());
              compose(&(v626_5),&(v627_7))
            };
            drop(v626_5);
            let v626_9: Space = intersect(&(*CONSTANT_2),&(v626_2));
            drop(v626_2);
            let v626_10: Space = if has_head(&(v626_9)) { singleton(&[]) } else { Space::new() };
            drop(v626_9);
            let v626_12: Space = if (v626_10).is_empty() { Space::new() } else {
              let v628_6: Path = concat_path(&(v625_6),&(v625_7_head));
              let v628_11: Space = routine_45(c, &(v628_6), &(*p1), &(v625_7_tail).make_space());
              drop(v628_6);
              compose(&(v626_10),&(v628_11))
            };
            drop(v626_10);
            let v626_13: Space = unite(&(v626_8),&(v626_12));
            v625_7.join_into((v626_13).clone());
            }
            v625_7_cursor.ascend(1);
          }
          drop(v625_7_cursor);
          compose(&(v624_5),&(v625_7))
        };
        drop(v624_5);
        let v624_9: Space = intersect(&(*CONSTANT_2),&(v624_2));
        drop(v624_2);
        let v624_10: Space = if has_head(&(v624_9)) { singleton(&[]) } else { Space::new() };
        drop(v624_9);
        let v624_12: Space = if (v624_10).is_empty() { Space::new() } else {
          let v629_6: Path = concat_path(&(v623_6),&(v623_7_head));
          let mut v629_11 = Space::new();
          let mut v629_11_cursor = (v623_7_tail).read_zipper();
          for v629_11_byte in v629_11_cursor.child_mask().iter() {
            v629_11_cursor.descend_to_byte(v629_11_byte);
            {
            let v629_11_tail = v629_11_cursor.fork_read_zipper();
            let v629_11_head = Path::from_slice(&[v629_11_byte]);
            let v630_2: Space = singleton(&(v629_11_head));
            let v630_3: Space = intersect(&(*CONSTANT_2),&(v630_2));
            let v630_4: Space = if has_head(&(v630_3)) { singleton(&[]) } else { Space::new() };
            drop(v630_3);
            let v630_5: Space = subtract(&(*CONSTANT_1),&(v630_4));
            drop(v630_4);
            let v630_8: Space = if (v630_5).is_empty() { Space::new() } else {
              let v631_6: Path = concat_path(&(v629_6),&(v629_11_head));
              let v631_7: Space = routine_44(c, &(v631_6), &(*p1), &(v629_11_tail).make_space());
              compose(&(v630_5),&(v631_7))
            };
            drop(v630_5);
            let v630_9: Space = intersect(&(*CONSTANT_2),&(v630_2));
            drop(v630_2);
            let v630_10: Space = if has_head(&(v630_9)) { singleton(&[]) } else { Space::new() };
            drop(v630_9);
            let v630_12: Space = if (v630_10).is_empty() { Space::new() } else {
              let v632_6: Path = concat_path(&(v629_6),&(v629_11_head));
              let v632_11: Space = routine_19(c, &(v632_6), &(*p1), &(v629_11_tail).make_space());
              drop(v632_6);
              compose(&(v630_10),&(v632_11))
            };
            drop(v630_10);
            let v630_13: Space = unite(&(v630_8),&(v630_12));
            v629_11.join_into((v630_13).clone());
            }
            v629_11_cursor.ascend(1);
          }
          drop(v629_11_cursor);
          drop(v629_6);
          compose(&(v624_10),&(v629_11))
        };
        drop(v624_10);
        let v624_13: Space = unite(&(v624_8),&(v624_12));
        v623_7.join_into((v624_13).clone());
        }
        v623_7_cursor.ascend(1);
      }
      drop(v623_7_cursor);
      compose(&(v622_5),&(v623_7))
    };
    drop(v622_5);
    let v622_9: Space = intersect(&(*CONSTANT_2),&(v622_2));
    drop(v622_2);
    let v622_10: Space = if has_head(&(v622_9)) { singleton(&[]) } else { Space::new() };
    drop(v622_9);
    let v622_12: Space = if (v622_10).is_empty() { Space::new() } else {
      let v633_6: Path = concat_path(&(*p0),&(v621_21_head));
      let mut v633_11 = Space::new();
      let mut v633_11_cursor = (v621_21_tail).read_zipper();
      for v633_11_byte in v633_11_cursor.child_mask().iter() {
        v633_11_cursor.descend_to_byte(v633_11_byte);
        {
        let v633_11_tail = v633_11_cursor.fork_read_zipper();
        let v633_11_head = Path::from_slice(&[v633_11_byte]);
        let v634_2: Space = singleton(&(v633_11_head));
        let v634_3: Space = intersect(&(*CONSTANT_2),&(v634_2));
        let v634_4: Space = if has_head(&(v634_3)) { singleton(&[]) } else { Space::new() };
        drop(v634_3);
        let v634_5: Space = subtract(&(*CONSTANT_1),&(v634_4));
        drop(v634_4);
        let v634_8: Space = if (v634_5).is_empty() { Space::new() } else {
          let v635_6: Path = concat_path(&(v633_6),&(v633_11_head));
          let mut v635_7 = Space::new();
          let mut v635_7_cursor = (v633_11_tail).read_zipper();
          for v635_7_byte in v635_7_cursor.child_mask().iter() {
            v635_7_cursor.descend_to_byte(v635_7_byte);
            {
            let v635_7_tail = v635_7_cursor.fork_read_zipper();
            let v635_7_head = Path::from_slice(&[v635_7_byte]);
            let v636_2: Space = singleton(&(v635_7_head));
            let v636_3: Space = intersect(&(*CONSTANT_2),&(v636_2));
            let v636_4: Space = if has_head(&(v636_3)) { singleton(&[]) } else { Space::new() };
            drop(v636_3);
            let v636_5: Space = subtract(&(*CONSTANT_1),&(v636_4));
            drop(v636_4);
            let v636_8: Space = if (v636_5).is_empty() { Space::new() } else {
              let v637_6: Path = concat_path(&(v635_6),&(v635_7_head));
              let v637_7: Space = routine_44(c, &(v637_6), &(*p1), &(v635_7_tail).make_space());
              compose(&(v636_5),&(v637_7))
            };
            drop(v636_5);
            let v636_9: Space = intersect(&(*CONSTANT_2),&(v636_2));
            drop(v636_2);
            let v636_10: Space = if has_head(&(v636_9)) { singleton(&[]) } else { Space::new() };
            drop(v636_9);
            let v636_12: Space = if (v636_10).is_empty() { Space::new() } else {
              let v638_6: Path = concat_path(&(v635_6),&(v635_7_head));
              let v638_11: Space = routine_45(c, &(v638_6), &(*p1), &(v635_7_tail).make_space());
              drop(v638_6);
              compose(&(v636_10),&(v638_11))
            };
            drop(v636_10);
            let v636_13: Space = unite(&(v636_8),&(v636_12));
            v635_7.join_into((v636_13).clone());
            }
            v635_7_cursor.ascend(1);
          }
          drop(v635_7_cursor);
          compose(&(v634_5),&(v635_7))
        };
        drop(v634_5);
        let v634_9: Space = intersect(&(*CONSTANT_2),&(v634_2));
        drop(v634_2);
        let v634_10: Space = if has_head(&(v634_9)) { singleton(&[]) } else { Space::new() };
        drop(v634_9);
        let v634_11: Space = compose(&(v634_10),&(v633_11_tail));
        drop(v634_10);
        let v639_6: Path = concat_path(&(v633_6),&(v633_11_head));
        let v634_12: Space = wrap(&(v634_11),&(v639_6));
        drop(v634_11);
        let v634_13: Space = wrap(&(v634_12),&(*p1));
        drop(v634_12);
        let v634_14: Space = unite(&(v634_8),&(v634_13));
        drop(v634_13);
        v633_11.join_into((v634_14).clone());
        }
        v633_11_cursor.ascend(1);
      }
      drop(v633_11_cursor);
      drop(v633_6);
      compose(&(v622_10),&(v633_11))
    };
    drop(v622_10);
    let v622_13: Space = unite(&(v622_8),&(v622_12));
    v621_21.join_into((v622_13).clone());
    }
    v621_21_cursor.ascend(1);
  }
  drop(v621_21_cursor);
  (v621_21).clone()
}

fn routine_33(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v640_15 = Space::new();
  let mut v640_15_cursor = (*s0).read_zipper();
  for v640_15_byte in v640_15_cursor.child_mask().iter() {
    v640_15_cursor.descend_to_byte(v640_15_byte);
    {
    let v640_15_tail = v640_15_cursor.fork_read_zipper();
    let v640_15_head = Path::from_slice(&[v640_15_byte]);
    let v641_2: Space = singleton(&(v640_15_head));
    let v641_3: Space = intersect(&(*CONSTANT_2),&(v641_2));
    let v641_4: Space = if has_head(&(v641_3)) { singleton(&[]) } else { Space::new() };
    drop(v641_3);
    let v641_5: Space = subtract(&(*CONSTANT_1),&(v641_4));
    drop(v641_4);
    let v641_8: Space = if (v641_5).is_empty() { Space::new() } else {
      let v642_6: Path = concat_path(&(*p0),&(v640_15_head));
      let mut v642_7 = Space::new();
      let mut v642_7_cursor = (v640_15_tail).read_zipper();
      for v642_7_byte in v642_7_cursor.child_mask().iter() {
        v642_7_cursor.descend_to_byte(v642_7_byte);
        {
        let v642_7_tail = v642_7_cursor.fork_read_zipper();
        let v642_7_head = Path::from_slice(&[v642_7_byte]);
        let v643_2: Space = singleton(&(v642_7_head));
        let v643_3: Space = intersect(&(*CONSTANT_2),&(v643_2));
        let v643_4: Space = if has_head(&(v643_3)) { singleton(&[]) } else { Space::new() };
        drop(v643_3);
        let v643_5: Space = subtract(&(*CONSTANT_1),&(v643_4));
        drop(v643_4);
        let v643_8: Space = if (v643_5).is_empty() { Space::new() } else {
          let v644_6: Path = concat_path(&(v642_6),&(v642_7_head));
          let mut v644_7 = Space::new();
          let mut v644_7_cursor = (v642_7_tail).read_zipper();
          for v644_7_byte in v644_7_cursor.child_mask().iter() {
            v644_7_cursor.descend_to_byte(v644_7_byte);
            {
            let v644_7_tail = v644_7_cursor.fork_read_zipper();
            let v644_7_head = Path::from_slice(&[v644_7_byte]);
            let v645_2: Space = singleton(&(v644_7_head));
            let v645_3: Space = intersect(&(*CONSTANT_2),&(v645_2));
            let v645_4: Space = if has_head(&(v645_3)) { singleton(&[]) } else { Space::new() };
            drop(v645_3);
            let v645_5: Space = subtract(&(*CONSTANT_1),&(v645_4));
            drop(v645_4);
            let v645_8: Space = if (v645_5).is_empty() { Space::new() } else {
              let v646_6: Path = concat_path(&(v644_6),&(v644_7_head));
              let v646_7: Space = routine_44(c, &(v646_6), &(*p1), &(v644_7_tail).make_space());
              compose(&(v645_5),&(v646_7))
            };
            drop(v645_5);
            let v645_9: Space = intersect(&(*CONSTANT_2),&(v645_2));
            drop(v645_2);
            let v645_10: Space = if has_head(&(v645_9)) { singleton(&[]) } else { Space::new() };
            drop(v645_9);
            let v645_12: Space = if (v645_10).is_empty() { Space::new() } else {
              let v647_6: Path = concat_path(&(v644_6),&(v644_7_head));
              let v647_11: Space = routine_45(c, &(v647_6), &(*p1), &(v644_7_tail).make_space());
              drop(v647_6);
              compose(&(v645_10),&(v647_11))
            };
            drop(v645_10);
            let v645_13: Space = unite(&(v645_8),&(v645_12));
            v644_7.join_into((v645_13).clone());
            }
            v644_7_cursor.ascend(1);
          }
          drop(v644_7_cursor);
          compose(&(v643_5),&(v644_7))
        };
        drop(v643_5);
        let v643_9: Space = intersect(&(*CONSTANT_2),&(v643_2));
        drop(v643_2);
        let v643_10: Space = if has_head(&(v643_9)) { singleton(&[]) } else { Space::new() };
        drop(v643_9);
        let v643_12: Space = if (v643_10).is_empty() { Space::new() } else {
          let v648_6: Path = concat_path(&(v642_6),&(v642_7_head));
          let mut v648_11 = Space::new();
          let mut v648_11_cursor = (v642_7_tail).read_zipper();
          for v648_11_byte in v648_11_cursor.child_mask().iter() {
            v648_11_cursor.descend_to_byte(v648_11_byte);
            {
            let v648_11_tail = v648_11_cursor.fork_read_zipper();
            let v648_11_head = Path::from_slice(&[v648_11_byte]);
            let v649_2: Space = singleton(&(v648_11_head));
            let v649_3: Space = intersect(&(*CONSTANT_2),&(v649_2));
            let v649_4: Space = if has_head(&(v649_3)) { singleton(&[]) } else { Space::new() };
            drop(v649_3);
            let v649_5: Space = subtract(&(*CONSTANT_1),&(v649_4));
            drop(v649_4);
            let v649_8: Space = if (v649_5).is_empty() { Space::new() } else {
              let v650_6: Path = concat_path(&(v648_6),&(v648_11_head));
              let v650_7: Space = routine_44(c, &(v650_6), &(*p1), &(v648_11_tail).make_space());
              compose(&(v649_5),&(v650_7))
            };
            drop(v649_5);
            let v649_9: Space = intersect(&(*CONSTANT_2),&(v649_2));
            drop(v649_2);
            let v649_10: Space = if has_head(&(v649_9)) { singleton(&[]) } else { Space::new() };
            drop(v649_9);
            let v649_12: Space = if (v649_10).is_empty() { Space::new() } else {
              let v651_6: Path = concat_path(&(v648_6),&(v648_11_head));
              let v651_11: Space = routine_19(c, &(v651_6), &(*p1), &(v648_11_tail).make_space());
              drop(v651_6);
              compose(&(v649_10),&(v651_11))
            };
            drop(v649_10);
            let v649_13: Space = unite(&(v649_8),&(v649_12));
            v648_11.join_into((v649_13).clone());
            }
            v648_11_cursor.ascend(1);
          }
          drop(v648_11_cursor);
          drop(v648_6);
          compose(&(v643_10),&(v648_11))
        };
        drop(v643_10);
        let v643_13: Space = unite(&(v643_8),&(v643_12));
        v642_7.join_into((v643_13).clone());
        }
        v642_7_cursor.ascend(1);
      }
      drop(v642_7_cursor);
      compose(&(v641_5),&(v642_7))
    };
    drop(v641_5);
    let v641_9: Space = intersect(&(*CONSTANT_2),&(v641_2));
    drop(v641_2);
    let v641_10: Space = if has_head(&(v641_9)) { singleton(&[]) } else { Space::new() };
    drop(v641_9);
    let v641_11: Space = compose(&(v641_10),&(v640_15_tail));
    drop(v641_10);
    let v652_6: Path = concat_path(&(*p0),&(v640_15_head));
    let v641_12: Space = wrap(&(v641_11),&(v652_6));
    drop(v641_11);
    let v641_13: Space = wrap(&(v641_12),&(*p1));
    drop(v641_12);
    let v641_14: Space = unite(&(v641_8),&(v641_13));
    drop(v641_13);
    v640_15.join_into((v641_14).clone());
    }
    v640_15_cursor.ascend(1);
  }
  drop(v640_15_cursor);
  (v640_15).clone()
}

fn routine_34(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v653_20: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v653_21: Space = unwrap(&(v653_20),&(*p0));
  drop(v653_20);
  let mut v653_28 = Space::new();
  let mut v653_28_cursor = (*s0).read_zipper();
  for v653_28_byte in v653_28_cursor.child_mask().iter() {
    v653_28_cursor.descend_to_byte(v653_28_byte);
    {
    let v653_28_tail = v653_28_cursor.fork_read_zipper();
    let v653_28_head = Path::from_slice(&[v653_28_byte]);
    let v654_2: Space = singleton(&(v653_28_head));
    let v654_3: Space = intersect(&(*CONSTANT_2),&(v654_2));
    let v654_4: Space = if has_head(&(v654_3)) { singleton(&[]) } else { Space::new() };
    drop(v654_3);
    let v654_5: Space = subtract(&(*CONSTANT_1),&(v654_4));
    drop(v654_4);
    let v654_8: Space = if (v654_5).is_empty() { Space::new() } else {
      let v655_6: Path = concat_path(&(*p0),&(v653_28_head));
      let mut v655_7 = Space::new();
      let mut v655_7_cursor = (v653_28_tail).read_zipper();
      for v655_7_byte in v655_7_cursor.child_mask().iter() {
        v655_7_cursor.descend_to_byte(v655_7_byte);
        {
        let v655_7_tail = v655_7_cursor.fork_read_zipper();
        let v655_7_head = Path::from_slice(&[v655_7_byte]);
        let v656_2: Space = singleton(&(v655_7_head));
        let v656_3: Space = intersect(&(*CONSTANT_2),&(v656_2));
        let v656_4: Space = if has_head(&(v656_3)) { singleton(&[]) } else { Space::new() };
        drop(v656_3);
        let v656_5: Space = subtract(&(*CONSTANT_1),&(v656_4));
        drop(v656_4);
        let v656_8: Space = if (v656_5).is_empty() { Space::new() } else {
          let v657_6: Path = concat_path(&(v655_6),&(v655_7_head));
          let mut v657_7 = Space::new();
          let mut v657_7_cursor = (v655_7_tail).read_zipper();
          for v657_7_byte in v657_7_cursor.child_mask().iter() {
            v657_7_cursor.descend_to_byte(v657_7_byte);
            {
            let v657_7_tail = v657_7_cursor.fork_read_zipper();
            let v657_7_head = Path::from_slice(&[v657_7_byte]);
            let v658_2: Space = singleton(&(v657_7_head));
            let v658_3: Space = intersect(&(*CONSTANT_2),&(v658_2));
            let v658_4: Space = if has_head(&(v658_3)) { singleton(&[]) } else { Space::new() };
            drop(v658_3);
            let v658_5: Space = subtract(&(*CONSTANT_1),&(v658_4));
            drop(v658_4);
            let v658_8: Space = if (v658_5).is_empty() { Space::new() } else {
              let v659_6: Path = concat_path(&(v657_6),&(v657_7_head));
              let v659_7: Space = routine_46(c, &(v659_6), &(*p1), &(v657_7_tail).make_space(), &(*s1));
              compose(&(v658_5),&(v659_7))
            };
            drop(v658_5);
            let v658_9: Space = intersect(&(*CONSTANT_2),&(v658_2));
            drop(v658_2);
            let v658_10: Space = if has_head(&(v658_9)) { singleton(&[]) } else { Space::new() };
            drop(v658_9);
            let v658_12: Space = if (v658_10).is_empty() { Space::new() } else {
              let v660_6: Path = concat_path(&(v657_6),&(v657_7_head));
              let v660_11: Space = routine_47(c, &(v660_6), &(*p1), &(v657_7_tail).make_space(), &(*s1));
              drop(v660_6);
              compose(&(v658_10),&(v660_11))
            };
            drop(v658_10);
            let v658_13: Space = unite(&(v658_8),&(v658_12));
            v657_7.join_into((v658_13).clone());
            }
            v657_7_cursor.ascend(1);
          }
          drop(v657_7_cursor);
          compose(&(v656_5),&(v657_7))
        };
        drop(v656_5);
        let v656_9: Space = intersect(&(*CONSTANT_2),&(v656_2));
        drop(v656_2);
        let v656_10: Space = if has_head(&(v656_9)) { singleton(&[]) } else { Space::new() };
        drop(v656_9);
        let v656_12: Space = if (v656_10).is_empty() { Space::new() } else {
          let v661_6: Path = concat_path(&(v655_6),&(v655_7_head));
          let mut v661_11 = Space::new();
          let mut v661_11_cursor = (v655_7_tail).read_zipper();
          for v661_11_byte in v661_11_cursor.child_mask().iter() {
            v661_11_cursor.descend_to_byte(v661_11_byte);
            {
            let v661_11_tail = v661_11_cursor.fork_read_zipper();
            let v661_11_head = Path::from_slice(&[v661_11_byte]);
            let v662_2: Space = singleton(&(v661_11_head));
            let v662_3: Space = intersect(&(*CONSTANT_2),&(v662_2));
            let v662_4: Space = if has_head(&(v662_3)) { singleton(&[]) } else { Space::new() };
            drop(v662_3);
            let v662_5: Space = subtract(&(*CONSTANT_1),&(v662_4));
            drop(v662_4);
            let v662_8: Space = if (v662_5).is_empty() { Space::new() } else {
              let v663_6: Path = concat_path(&(v661_6),&(v661_11_head));
              let v663_7: Space = routine_46(c, &(v663_6), &(*p1), &(v661_11_tail).make_space(), &(*s1));
              compose(&(v662_5),&(v663_7))
            };
            drop(v662_5);
            let v662_9: Space = intersect(&(*CONSTANT_2),&(v662_2));
            drop(v662_2);
            let v662_10: Space = if has_head(&(v662_9)) { singleton(&[]) } else { Space::new() };
            drop(v662_9);
            let v662_12: Space = if (v662_10).is_empty() { Space::new() } else {
              let v664_6: Path = concat_path(&(v661_6),&(v661_11_head));
              let v664_11: Space = routine_10(c, &(v664_6), &(*p1), &(v661_11_tail).make_space(), &(*s1));
              drop(v664_6);
              compose(&(v662_10),&(v664_11))
            };
            drop(v662_10);
            let v662_13: Space = unite(&(v662_8),&(v662_12));
            v661_11.join_into((v662_13).clone());
            }
            v661_11_cursor.ascend(1);
          }
          drop(v661_11_cursor);
          drop(v661_6);
          compose(&(v656_10),&(v661_11))
        };
        drop(v656_10);
        let v656_13: Space = unite(&(v656_8),&(v656_12));
        v655_7.join_into((v656_13).clone());
        }
        v655_7_cursor.ascend(1);
      }
      drop(v655_7_cursor);
      compose(&(v654_5),&(v655_7))
    };
    drop(v654_5);
    let v654_9: Space = intersect(&(*CONSTANT_2),&(v654_2));
    drop(v654_2);
    let v654_10: Space = if has_head(&(v654_9)) { singleton(&[]) } else { Space::new() };
    drop(v654_9);
    let v654_13: Space = if (v654_10).is_empty() { Space::new() } else {
      let v665_6: Path = concat_path(&(*p0),&(v653_28_head));
      let v665_11: Space = unwrap(&(v653_21),&(v653_28_head));
      let mut v665_12 = Space::new();
      let mut v665_12_cursor = (v653_28_tail).read_zipper();
      for v665_12_byte in v665_12_cursor.child_mask().iter() {
        v665_12_cursor.descend_to_byte(v665_12_byte);
        {
        let v665_12_tail = v665_12_cursor.fork_read_zipper();
        let v665_12_head = Path::from_slice(&[v665_12_byte]);
        let v666_2: Space = singleton(&(v665_12_head));
        let v666_3: Space = intersect(&(*CONSTANT_2),&(v666_2));
        let v666_4: Space = if has_head(&(v666_3)) { singleton(&[]) } else { Space::new() };
        drop(v666_3);
        let v666_5: Space = subtract(&(*CONSTANT_1),&(v666_4));
        drop(v666_4);
        let v666_8: Space = if (v666_5).is_empty() { Space::new() } else {
          let v667_6: Path = concat_path(&(v665_6),&(v665_12_head));
          let mut v667_7 = Space::new();
          let mut v667_7_cursor = (v665_12_tail).read_zipper();
          for v667_7_byte in v667_7_cursor.child_mask().iter() {
            v667_7_cursor.descend_to_byte(v667_7_byte);
            {
            let v667_7_tail = v667_7_cursor.fork_read_zipper();
            let v667_7_head = Path::from_slice(&[v667_7_byte]);
            let v668_2: Space = singleton(&(v667_7_head));
            let v668_3: Space = intersect(&(*CONSTANT_2),&(v668_2));
            let v668_4: Space = if has_head(&(v668_3)) { singleton(&[]) } else { Space::new() };
            drop(v668_3);
            let v668_5: Space = subtract(&(*CONSTANT_1),&(v668_4));
            drop(v668_4);
            let v668_8: Space = if (v668_5).is_empty() { Space::new() } else {
              let v669_6: Path = concat_path(&(v667_6),&(v667_7_head));
              let v669_7: Space = routine_46(c, &(v669_6), &(*p1), &(v667_7_tail).make_space(), &(*s1));
              compose(&(v668_5),&(v669_7))
            };
            drop(v668_5);
            let v668_9: Space = intersect(&(*CONSTANT_2),&(v668_2));
            drop(v668_2);
            let v668_10: Space = if has_head(&(v668_9)) { singleton(&[]) } else { Space::new() };
            drop(v668_9);
            let v668_12: Space = if (v668_10).is_empty() { Space::new() } else {
              let v670_6: Path = concat_path(&(v667_6),&(v667_7_head));
              let v670_11: Space = routine_47(c, &(v670_6), &(*p1), &(v667_7_tail).make_space(), &(*s1));
              drop(v670_6);
              compose(&(v668_10),&(v670_11))
            };
            drop(v668_10);
            let v668_13: Space = unite(&(v668_8),&(v668_12));
            v667_7.join_into((v668_13).clone());
            }
            v667_7_cursor.ascend(1);
          }
          drop(v667_7_cursor);
          drop(v667_6);
          compose(&(v666_5),&(v667_7))
        };
        drop(v666_5);
        let v666_9: Space = intersect(&(*CONSTANT_2),&(v666_2));
        drop(v666_2);
        let v666_10: Space = if has_head(&(v666_9)) { singleton(&[]) } else { Space::new() };
        drop(v666_9);
        let v666_13: Space = if (v666_10).is_empty() { Space::new() } else {
          let v671_11: Space = unwrap(&(v665_11),&(v665_12_head));
          let mut v671_12 = Space::new();
          let mut v671_12_cursor = (v671_11).read_zipper();
          for v671_12_byte in v671_12_cursor.child_mask().iter() {
            v671_12_cursor.descend_to_byte(v671_12_byte);
            {
            let v671_12_tail = v671_12_cursor.fork_read_zipper();
            let v671_12_head = Path::from_slice(&[v671_12_byte]);
            let v672_2: Space = singleton(&(v671_12_head));
            let v672_3: Space = intersect(&(*CONSTANT_2),&(v672_2));
            let v672_4: Space = if has_head(&(v672_3)) { singleton(&[]) } else { Space::new() };
            drop(v672_3);
            let v672_5: Space = subtract(&(*CONSTANT_1),&(v672_4));
            drop(v672_4);
            let v672_7: Space = if (v672_5).is_empty() { Space::new() } else {
              let v673_6: Space = routine_13(c, &(v671_12_head), &(*p1), &(v671_12_tail).make_space());
              compose(&(v672_5),&(v673_6))
            };
            drop(v672_5);
            let v672_8: Space = intersect(&(*CONSTANT_2),&(v672_2));
            drop(v672_2);
            let v672_9: Space = if has_head(&(v672_8)) { singleton(&[]) } else { Space::new() };
            drop(v672_8);
            let v672_11: Space = if (v672_9).is_empty() { Space::new() } else {
              let v674_10: Space = routine_14(c, &(v671_12_head), &(*p1), &(v671_12_tail).make_space());
              compose(&(v672_9),&(v674_10))
            };
            drop(v672_9);
            let v672_12: Space = unite(&(v672_7),&(v672_11));
            v671_12.join_into((v672_12).clone());
            }
            v671_12_cursor.ascend(1);
          }
          drop(v671_12_cursor);
          drop(v671_11);
          compose(&(v666_10),&(v671_12))
        };
        drop(v666_10);
        let v666_14: Space = unite(&(v666_8),&(v666_13));
        v665_12.join_into((v666_14).clone());
        }
        v665_12_cursor.ascend(1);
      }
      drop(v665_12_cursor);
      drop(v665_6);
      drop(v665_11);
      compose(&(v654_10),&(v665_12))
    };
    drop(v654_10);
    let v654_14: Space = unite(&(v654_8),&(v654_13));
    v653_28.join_into((v654_14).clone());
    }
    v653_28_cursor.ascend(1);
  }
  drop(v653_28_cursor);
  drop(v653_21);
  (v653_28).clone()
}

fn routine_35(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v675_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v675_9: Space = unwrap(&(v675_8),&(*p0));
  drop(v675_8);
  let mut v675_28 = Space::new();
  let mut v675_28_cursor = (*s0).read_zipper();
  for v675_28_byte in v675_28_cursor.child_mask().iter() {
    v675_28_cursor.descend_to_byte(v675_28_byte);
    {
    let v675_28_tail = v675_28_cursor.fork_read_zipper();
    let v675_28_head = Path::from_slice(&[v675_28_byte]);
    let v676_2: Space = singleton(&(v675_28_head));
    let v676_3: Space = intersect(&(*CONSTANT_2),&(v676_2));
    let v676_4: Space = if has_head(&(v676_3)) { singleton(&[]) } else { Space::new() };
    drop(v676_3);
    let v676_5: Space = subtract(&(*CONSTANT_1),&(v676_4));
    drop(v676_4);
    let v676_8: Space = if (v676_5).is_empty() { Space::new() } else {
      let v677_6: Path = concat_path(&(*p0),&(v675_28_head));
      let mut v677_7 = Space::new();
      let mut v677_7_cursor = (v675_28_tail).read_zipper();
      for v677_7_byte in v677_7_cursor.child_mask().iter() {
        v677_7_cursor.descend_to_byte(v677_7_byte);
        {
        let v677_7_tail = v677_7_cursor.fork_read_zipper();
        let v677_7_head = Path::from_slice(&[v677_7_byte]);
        let v678_2: Space = singleton(&(v677_7_head));
        let v678_3: Space = intersect(&(*CONSTANT_2),&(v678_2));
        let v678_4: Space = if has_head(&(v678_3)) { singleton(&[]) } else { Space::new() };
        drop(v678_3);
        let v678_5: Space = subtract(&(*CONSTANT_1),&(v678_4));
        drop(v678_4);
        let v678_8: Space = if (v678_5).is_empty() { Space::new() } else {
          let v679_6: Path = concat_path(&(v677_6),&(v677_7_head));
          let mut v679_7 = Space::new();
          let mut v679_7_cursor = (v677_7_tail).read_zipper();
          for v679_7_byte in v679_7_cursor.child_mask().iter() {
            v679_7_cursor.descend_to_byte(v679_7_byte);
            {
            let v679_7_tail = v679_7_cursor.fork_read_zipper();
            let v679_7_head = Path::from_slice(&[v679_7_byte]);
            let v680_2: Space = singleton(&(v679_7_head));
            let v680_3: Space = intersect(&(*CONSTANT_2),&(v680_2));
            let v680_4: Space = if has_head(&(v680_3)) { singleton(&[]) } else { Space::new() };
            drop(v680_3);
            let v680_5: Space = subtract(&(*CONSTANT_1),&(v680_4));
            drop(v680_4);
            let v680_8: Space = if (v680_5).is_empty() { Space::new() } else {
              let v681_6: Path = concat_path(&(v679_6),&(v679_7_head));
              let v681_7: Space = routine_46(c, &(v681_6), &(*p1), &(v679_7_tail).make_space(), &(*s1));
              compose(&(v680_5),&(v681_7))
            };
            drop(v680_5);
            let v680_9: Space = intersect(&(*CONSTANT_2),&(v680_2));
            drop(v680_2);
            let v680_10: Space = if has_head(&(v680_9)) { singleton(&[]) } else { Space::new() };
            drop(v680_9);
            let v680_12: Space = if (v680_10).is_empty() { Space::new() } else {
              let v682_6: Path = concat_path(&(v679_6),&(v679_7_head));
              let v682_11: Space = routine_47(c, &(v682_6), &(*p1), &(v679_7_tail).make_space(), &(*s1));
              drop(v682_6);
              compose(&(v680_10),&(v682_11))
            };
            drop(v680_10);
            let v680_13: Space = unite(&(v680_8),&(v680_12));
            v679_7.join_into((v680_13).clone());
            }
            v679_7_cursor.ascend(1);
          }
          drop(v679_7_cursor);
          compose(&(v678_5),&(v679_7))
        };
        drop(v678_5);
        let v678_9: Space = intersect(&(*CONSTANT_2),&(v678_2));
        drop(v678_2);
        let v678_10: Space = if has_head(&(v678_9)) { singleton(&[]) } else { Space::new() };
        drop(v678_9);
        let v678_12: Space = if (v678_10).is_empty() { Space::new() } else {
          let v683_6: Path = concat_path(&(v677_6),&(v677_7_head));
          let mut v683_11 = Space::new();
          let mut v683_11_cursor = (v677_7_tail).read_zipper();
          for v683_11_byte in v683_11_cursor.child_mask().iter() {
            v683_11_cursor.descend_to_byte(v683_11_byte);
            {
            let v683_11_tail = v683_11_cursor.fork_read_zipper();
            let v683_11_head = Path::from_slice(&[v683_11_byte]);
            let v684_2: Space = singleton(&(v683_11_head));
            let v684_3: Space = intersect(&(*CONSTANT_2),&(v684_2));
            let v684_4: Space = if has_head(&(v684_3)) { singleton(&[]) } else { Space::new() };
            drop(v684_3);
            let v684_5: Space = subtract(&(*CONSTANT_1),&(v684_4));
            drop(v684_4);
            let v684_8: Space = if (v684_5).is_empty() { Space::new() } else {
              let v685_6: Path = concat_path(&(v683_6),&(v683_11_head));
              let v685_7: Space = routine_46(c, &(v685_6), &(*p1), &(v683_11_tail).make_space(), &(*s1));
              compose(&(v684_5),&(v685_7))
            };
            drop(v684_5);
            let v684_9: Space = intersect(&(*CONSTANT_2),&(v684_2));
            drop(v684_2);
            let v684_10: Space = if has_head(&(v684_9)) { singleton(&[]) } else { Space::new() };
            drop(v684_9);
            let v684_12: Space = if (v684_10).is_empty() { Space::new() } else {
              let v686_6: Path = concat_path(&(v683_6),&(v683_11_head));
              let v686_11: Space = routine_10(c, &(v686_6), &(*p1), &(v683_11_tail).make_space(), &(*s1));
              drop(v686_6);
              compose(&(v684_10),&(v686_11))
            };
            drop(v684_10);
            let v684_13: Space = unite(&(v684_8),&(v684_12));
            v683_11.join_into((v684_13).clone());
            }
            v683_11_cursor.ascend(1);
          }
          drop(v683_11_cursor);
          drop(v683_6);
          compose(&(v678_10),&(v683_11))
        };
        drop(v678_10);
        let v678_13: Space = unite(&(v678_8),&(v678_12));
        v677_7.join_into((v678_13).clone());
        }
        v677_7_cursor.ascend(1);
      }
      drop(v677_7_cursor);
      drop(v677_6);
      compose(&(v676_5),&(v677_7))
    };
    drop(v676_5);
    let v676_9: Space = intersect(&(*CONSTANT_2),&(v676_2));
    drop(v676_2);
    let v676_10: Space = if has_head(&(v676_9)) { singleton(&[]) } else { Space::new() };
    drop(v676_9);
    let v676_13: Space = if (v676_10).is_empty() { Space::new() } else {
      let v687_11: Space = unwrap(&(v675_9),&(v675_28_head));
      let mut v687_12 = Space::new();
      let mut v687_12_cursor = (v687_11).read_zipper();
      for v687_12_byte in v687_12_cursor.child_mask().iter() {
        v687_12_cursor.descend_to_byte(v687_12_byte);
        {
        let v687_12_tail = v687_12_cursor.fork_read_zipper();
        let v687_12_head = Path::from_slice(&[v687_12_byte]);
        let v688_2: Space = singleton(&(v687_12_head));
        let v688_3: Space = intersect(&(*CONSTANT_2),&(v688_2));
        let v688_4: Space = if has_head(&(v688_3)) { singleton(&[]) } else { Space::new() };
        drop(v688_3);
        let v688_5: Space = subtract(&(*CONSTANT_1),&(v688_4));
        drop(v688_4);
        let v688_7: Space = if (v688_5).is_empty() { Space::new() } else {
          let mut v689_6 = Space::new();
          let mut v689_6_cursor = (v687_12_tail).read_zipper();
          for v689_6_byte in v689_6_cursor.child_mask().iter() {
            v689_6_cursor.descend_to_byte(v689_6_byte);
            {
            let v689_6_tail = v689_6_cursor.fork_read_zipper();
            let v689_6_head = Path::from_slice(&[v689_6_byte]);
            let v690_2: Space = singleton(&(v689_6_head));
            let v690_3: Space = intersect(&(*CONSTANT_2),&(v690_2));
            let v690_4: Space = if has_head(&(v690_3)) { singleton(&[]) } else { Space::new() };
            drop(v690_3);
            let v690_5: Space = subtract(&(*CONSTANT_1),&(v690_4));
            drop(v690_4);
            let v690_8: Space = if (v690_5).is_empty() { Space::new() } else {
              let v691_6: Path = concat_path(&(v687_12_head),&(v689_6_head));
              let v691_7: Space = routine_17(c, &(v691_6), &(*p1), &(v689_6_tail).make_space());
              compose(&(v690_5),&(v691_7))
            };
            drop(v690_5);
            let v690_9: Space = intersect(&(*CONSTANT_2),&(v690_2));
            drop(v690_2);
            let v690_10: Space = if has_head(&(v690_9)) { singleton(&[]) } else { Space::new() };
            drop(v690_9);
            let v690_12: Space = if (v690_10).is_empty() { Space::new() } else {
              let v692_6: Path = concat_path(&(v687_12_head),&(v689_6_head));
              let v692_11: Space = routine_18(c, &(v692_6), &(*p1), &(v689_6_tail).make_space());
              drop(v692_6);
              compose(&(v690_10),&(v692_11))
            };
            drop(v690_10);
            let v690_13: Space = unite(&(v690_8),&(v690_12));
            v689_6.join_into((v690_13).clone());
            }
            v689_6_cursor.ascend(1);
          }
          drop(v689_6_cursor);
          compose(&(v688_5),&(v689_6))
        };
        drop(v688_5);
        let v688_8: Space = intersect(&(*CONSTANT_2),&(v688_2));
        drop(v688_2);
        let v688_9: Space = if has_head(&(v688_8)) { singleton(&[]) } else { Space::new() };
        drop(v688_8);
        let v688_11: Space = if (v688_9).is_empty() { Space::new() } else {
          let mut v693_10 = Space::new();
          let mut v693_10_cursor = (v687_12_tail).read_zipper();
          for v693_10_byte in v693_10_cursor.child_mask().iter() {
            v693_10_cursor.descend_to_byte(v693_10_byte);
            {
            let v693_10_tail = v693_10_cursor.fork_read_zipper();
            let v693_10_head = Path::from_slice(&[v693_10_byte]);
            let v694_2: Space = singleton(&(v693_10_head));
            let v694_3: Space = intersect(&(*CONSTANT_2),&(v694_2));
            let v694_4: Space = if has_head(&(v694_3)) { singleton(&[]) } else { Space::new() };
            drop(v694_3);
            let v694_5: Space = subtract(&(*CONSTANT_1),&(v694_4));
            drop(v694_4);
            let v694_8: Space = if (v694_5).is_empty() { Space::new() } else {
              let v695_6: Path = concat_path(&(v687_12_head),&(v693_10_head));
              let v695_7: Space = routine_17(c, &(v695_6), &(*p1), &(v693_10_tail).make_space());
              compose(&(v694_5),&(v695_7))
            };
            drop(v694_5);
            let v694_9: Space = intersect(&(*CONSTANT_2),&(v694_2));
            drop(v694_2);
            let v694_10: Space = if has_head(&(v694_9)) { singleton(&[]) } else { Space::new() };
            drop(v694_9);
            let v694_12: Space = if (v694_10).is_empty() { Space::new() } else {
              let v696_6: Path = concat_path(&(v687_12_head),&(v693_10_head));
              let v696_11: Space = routine_19(c, &(v696_6), &(*p1), &(v693_10_tail).make_space());
              drop(v696_6);
              compose(&(v694_10),&(v696_11))
            };
            drop(v694_10);
            let v694_13: Space = unite(&(v694_8),&(v694_12));
            v693_10.join_into((v694_13).clone());
            }
            v693_10_cursor.ascend(1);
          }
          drop(v693_10_cursor);
          compose(&(v688_9),&(v693_10))
        };
        drop(v688_9);
        let v688_12: Space = unite(&(v688_7),&(v688_11));
        v687_12.join_into((v688_12).clone());
        }
        v687_12_cursor.ascend(1);
      }
      drop(v687_12_cursor);
      drop(v687_11);
      compose(&(v676_10),&(v687_12))
    };
    drop(v676_10);
    let v676_14: Space = unite(&(v676_8),&(v676_13));
    v675_28.join_into((v676_14).clone());
    }
    v675_28_cursor.ascend(1);
  }
  drop(v675_28_cursor);
  drop(v675_9);
  (v675_28).clone()
}

fn routine_36(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v697_21 = Space::new();
  let mut v697_21_cursor = (*s0).read_zipper();
  for v697_21_byte in v697_21_cursor.child_mask().iter() {
    v697_21_cursor.descend_to_byte(v697_21_byte);
    {
    let v697_21_tail = v697_21_cursor.fork_read_zipper();
    let v697_21_head = Path::from_slice(&[v697_21_byte]);
    let v698_2: Space = singleton(&(v697_21_head));
    let v698_3: Space = intersect(&(*CONSTANT_2),&(v698_2));
    let v698_4: Space = if has_head(&(v698_3)) { singleton(&[]) } else { Space::new() };
    drop(v698_3);
    let v698_5: Space = subtract(&(*CONSTANT_1),&(v698_4));
    drop(v698_4);
    let v698_8: Space = if (v698_5).is_empty() { Space::new() } else {
      let v699_6: Path = concat_path(&(*p0),&(v697_21_head));
      let mut v699_7 = Space::new();
      let mut v699_7_cursor = (v697_21_tail).read_zipper();
      for v699_7_byte in v699_7_cursor.child_mask().iter() {
        v699_7_cursor.descend_to_byte(v699_7_byte);
        {
        let v699_7_tail = v699_7_cursor.fork_read_zipper();
        let v699_7_head = Path::from_slice(&[v699_7_byte]);
        let v700_2: Space = singleton(&(v699_7_head));
        let v700_3: Space = intersect(&(*CONSTANT_2),&(v700_2));
        let v700_4: Space = if has_head(&(v700_3)) { singleton(&[]) } else { Space::new() };
        drop(v700_3);
        let v700_5: Space = subtract(&(*CONSTANT_1),&(v700_4));
        drop(v700_4);
        let v700_8: Space = if (v700_5).is_empty() { Space::new() } else {
          let v701_6: Path = concat_path(&(v699_6),&(v699_7_head));
          let mut v701_7 = Space::new();
          let mut v701_7_cursor = (v699_7_tail).read_zipper();
          for v701_7_byte in v701_7_cursor.child_mask().iter() {
            v701_7_cursor.descend_to_byte(v701_7_byte);
            {
            let v701_7_tail = v701_7_cursor.fork_read_zipper();
            let v701_7_head = Path::from_slice(&[v701_7_byte]);
            let v702_2: Space = singleton(&(v701_7_head));
            let v702_3: Space = intersect(&(*CONSTANT_2),&(v702_2));
            let v702_4: Space = if has_head(&(v702_3)) { singleton(&[]) } else { Space::new() };
            drop(v702_3);
            let v702_5: Space = subtract(&(*CONSTANT_1),&(v702_4));
            drop(v702_4);
            let v702_8: Space = if (v702_5).is_empty() { Space::new() } else {
              let v703_6: Path = concat_path(&(v701_6),&(v701_7_head));
              let v703_7: Space = routine_48(c, &(v703_6), &(*p1), &(v701_7_tail).make_space());
              compose(&(v702_5),&(v703_7))
            };
            drop(v702_5);
            let v702_9: Space = intersect(&(*CONSTANT_2),&(v702_2));
            drop(v702_2);
            let v702_10: Space = if has_head(&(v702_9)) { singleton(&[]) } else { Space::new() };
            drop(v702_9);
            let v702_12: Space = if (v702_10).is_empty() { Space::new() } else {
              let v704_6: Path = concat_path(&(v701_6),&(v701_7_head));
              let v704_11: Space = routine_49(c, &(v704_6), &(*p1), &(v701_7_tail).make_space());
              drop(v704_6);
              compose(&(v702_10),&(v704_11))
            };
            drop(v702_10);
            let v702_13: Space = unite(&(v702_8),&(v702_12));
            v701_7.join_into((v702_13).clone());
            }
            v701_7_cursor.ascend(1);
          }
          drop(v701_7_cursor);
          compose(&(v700_5),&(v701_7))
        };
        drop(v700_5);
        let v700_9: Space = intersect(&(*CONSTANT_2),&(v700_2));
        drop(v700_2);
        let v700_10: Space = if has_head(&(v700_9)) { singleton(&[]) } else { Space::new() };
        drop(v700_9);
        let v700_12: Space = if (v700_10).is_empty() { Space::new() } else {
          let v705_6: Path = concat_path(&(v699_6),&(v699_7_head));
          let mut v705_11 = Space::new();
          let mut v705_11_cursor = (v699_7_tail).read_zipper();
          for v705_11_byte in v705_11_cursor.child_mask().iter() {
            v705_11_cursor.descend_to_byte(v705_11_byte);
            {
            let v705_11_tail = v705_11_cursor.fork_read_zipper();
            let v705_11_head = Path::from_slice(&[v705_11_byte]);
            let v706_2: Space = singleton(&(v705_11_head));
            let v706_3: Space = intersect(&(*CONSTANT_2),&(v706_2));
            let v706_4: Space = if has_head(&(v706_3)) { singleton(&[]) } else { Space::new() };
            drop(v706_3);
            let v706_5: Space = subtract(&(*CONSTANT_1),&(v706_4));
            drop(v706_4);
            let v706_8: Space = if (v706_5).is_empty() { Space::new() } else {
              let v707_6: Path = concat_path(&(v705_6),&(v705_11_head));
              let v707_7: Space = routine_48(c, &(v707_6), &(*p1), &(v705_11_tail).make_space());
              compose(&(v706_5),&(v707_7))
            };
            drop(v706_5);
            let v706_9: Space = intersect(&(*CONSTANT_2),&(v706_2));
            drop(v706_2);
            let v706_10: Space = if has_head(&(v706_9)) { singleton(&[]) } else { Space::new() };
            drop(v706_9);
            let v706_12: Space = if (v706_10).is_empty() { Space::new() } else {
              let v708_6: Path = concat_path(&(v705_6),&(v705_11_head));
              let v708_11: Space = routine_19(c, &(v708_6), &(*p1), &(v705_11_tail).make_space());
              drop(v708_6);
              compose(&(v706_10),&(v708_11))
            };
            drop(v706_10);
            let v706_13: Space = unite(&(v706_8),&(v706_12));
            v705_11.join_into((v706_13).clone());
            }
            v705_11_cursor.ascend(1);
          }
          drop(v705_11_cursor);
          drop(v705_6);
          compose(&(v700_10),&(v705_11))
        };
        drop(v700_10);
        let v700_13: Space = unite(&(v700_8),&(v700_12));
        v699_7.join_into((v700_13).clone());
        }
        v699_7_cursor.ascend(1);
      }
      drop(v699_7_cursor);
      compose(&(v698_5),&(v699_7))
    };
    drop(v698_5);
    let v698_9: Space = intersect(&(*CONSTANT_2),&(v698_2));
    drop(v698_2);
    let v698_10: Space = if has_head(&(v698_9)) { singleton(&[]) } else { Space::new() };
    drop(v698_9);
    let v698_12: Space = if (v698_10).is_empty() { Space::new() } else {
      let v709_6: Path = concat_path(&(*p0),&(v697_21_head));
      let mut v709_11 = Space::new();
      let mut v709_11_cursor = (v697_21_tail).read_zipper();
      for v709_11_byte in v709_11_cursor.child_mask().iter() {
        v709_11_cursor.descend_to_byte(v709_11_byte);
        {
        let v709_11_tail = v709_11_cursor.fork_read_zipper();
        let v709_11_head = Path::from_slice(&[v709_11_byte]);
        let v710_2: Space = singleton(&(v709_11_head));
        let v710_3: Space = intersect(&(*CONSTANT_2),&(v710_2));
        let v710_4: Space = if has_head(&(v710_3)) { singleton(&[]) } else { Space::new() };
        drop(v710_3);
        let v710_5: Space = subtract(&(*CONSTANT_1),&(v710_4));
        drop(v710_4);
        let v710_8: Space = if (v710_5).is_empty() { Space::new() } else {
          let v711_6: Path = concat_path(&(v709_6),&(v709_11_head));
          let mut v711_7 = Space::new();
          let mut v711_7_cursor = (v709_11_tail).read_zipper();
          for v711_7_byte in v711_7_cursor.child_mask().iter() {
            v711_7_cursor.descend_to_byte(v711_7_byte);
            {
            let v711_7_tail = v711_7_cursor.fork_read_zipper();
            let v711_7_head = Path::from_slice(&[v711_7_byte]);
            let v712_2: Space = singleton(&(v711_7_head));
            let v712_3: Space = intersect(&(*CONSTANT_2),&(v712_2));
            let v712_4: Space = if has_head(&(v712_3)) { singleton(&[]) } else { Space::new() };
            drop(v712_3);
            let v712_5: Space = subtract(&(*CONSTANT_1),&(v712_4));
            drop(v712_4);
            let v712_8: Space = if (v712_5).is_empty() { Space::new() } else {
              let v713_6: Path = concat_path(&(v711_6),&(v711_7_head));
              let v713_7: Space = routine_48(c, &(v713_6), &(*p1), &(v711_7_tail).make_space());
              compose(&(v712_5),&(v713_7))
            };
            drop(v712_5);
            let v712_9: Space = intersect(&(*CONSTANT_2),&(v712_2));
            drop(v712_2);
            let v712_10: Space = if has_head(&(v712_9)) { singleton(&[]) } else { Space::new() };
            drop(v712_9);
            let v712_12: Space = if (v712_10).is_empty() { Space::new() } else {
              let v714_6: Path = concat_path(&(v711_6),&(v711_7_head));
              let v714_11: Space = routine_49(c, &(v714_6), &(*p1), &(v711_7_tail).make_space());
              drop(v714_6);
              compose(&(v712_10),&(v714_11))
            };
            drop(v712_10);
            let v712_13: Space = unite(&(v712_8),&(v712_12));
            v711_7.join_into((v712_13).clone());
            }
            v711_7_cursor.ascend(1);
          }
          drop(v711_7_cursor);
          compose(&(v710_5),&(v711_7))
        };
        drop(v710_5);
        let v710_9: Space = intersect(&(*CONSTANT_2),&(v710_2));
        drop(v710_2);
        let v710_10: Space = if has_head(&(v710_9)) { singleton(&[]) } else { Space::new() };
        drop(v710_9);
        let v710_11: Space = compose(&(v710_10),&(v709_11_tail));
        drop(v710_10);
        let v715_6: Path = concat_path(&(v709_6),&(v709_11_head));
        let v710_12: Space = wrap(&(v710_11),&(v715_6));
        drop(v710_11);
        let v710_13: Space = wrap(&(v710_12),&(*p1));
        drop(v710_12);
        let v710_14: Space = unite(&(v710_8),&(v710_13));
        drop(v710_13);
        v709_11.join_into((v710_14).clone());
        }
        v709_11_cursor.ascend(1);
      }
      drop(v709_11_cursor);
      drop(v709_6);
      compose(&(v698_10),&(v709_11))
    };
    drop(v698_10);
    let v698_13: Space = unite(&(v698_8),&(v698_12));
    v697_21.join_into((v698_13).clone());
    }
    v697_21_cursor.ascend(1);
  }
  drop(v697_21_cursor);
  (v697_21).clone()
}

fn routine_37(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v716_15 = Space::new();
  let mut v716_15_cursor = (*s0).read_zipper();
  for v716_15_byte in v716_15_cursor.child_mask().iter() {
    v716_15_cursor.descend_to_byte(v716_15_byte);
    {
    let v716_15_tail = v716_15_cursor.fork_read_zipper();
    let v716_15_head = Path::from_slice(&[v716_15_byte]);
    let v717_2: Space = singleton(&(v716_15_head));
    let v717_3: Space = intersect(&(*CONSTANT_2),&(v717_2));
    let v717_4: Space = if has_head(&(v717_3)) { singleton(&[]) } else { Space::new() };
    drop(v717_3);
    let v717_5: Space = subtract(&(*CONSTANT_1),&(v717_4));
    drop(v717_4);
    let v717_8: Space = if (v717_5).is_empty() { Space::new() } else {
      let v718_6: Path = concat_path(&(*p0),&(v716_15_head));
      let mut v718_7 = Space::new();
      let mut v718_7_cursor = (v716_15_tail).read_zipper();
      for v718_7_byte in v718_7_cursor.child_mask().iter() {
        v718_7_cursor.descend_to_byte(v718_7_byte);
        {
        let v718_7_tail = v718_7_cursor.fork_read_zipper();
        let v718_7_head = Path::from_slice(&[v718_7_byte]);
        let v719_2: Space = singleton(&(v718_7_head));
        let v719_3: Space = intersect(&(*CONSTANT_2),&(v719_2));
        let v719_4: Space = if has_head(&(v719_3)) { singleton(&[]) } else { Space::new() };
        drop(v719_3);
        let v719_5: Space = subtract(&(*CONSTANT_1),&(v719_4));
        drop(v719_4);
        let v719_8: Space = if (v719_5).is_empty() { Space::new() } else {
          let v720_6: Path = concat_path(&(v718_6),&(v718_7_head));
          let mut v720_7 = Space::new();
          let mut v720_7_cursor = (v718_7_tail).read_zipper();
          for v720_7_byte in v720_7_cursor.child_mask().iter() {
            v720_7_cursor.descend_to_byte(v720_7_byte);
            {
            let v720_7_tail = v720_7_cursor.fork_read_zipper();
            let v720_7_head = Path::from_slice(&[v720_7_byte]);
            let v721_2: Space = singleton(&(v720_7_head));
            let v721_3: Space = intersect(&(*CONSTANT_2),&(v721_2));
            let v721_4: Space = if has_head(&(v721_3)) { singleton(&[]) } else { Space::new() };
            drop(v721_3);
            let v721_5: Space = subtract(&(*CONSTANT_1),&(v721_4));
            drop(v721_4);
            let v721_8: Space = if (v721_5).is_empty() { Space::new() } else {
              let v722_6: Path = concat_path(&(v720_6),&(v720_7_head));
              let v722_7: Space = routine_48(c, &(v722_6), &(*p1), &(v720_7_tail).make_space());
              compose(&(v721_5),&(v722_7))
            };
            drop(v721_5);
            let v721_9: Space = intersect(&(*CONSTANT_2),&(v721_2));
            drop(v721_2);
            let v721_10: Space = if has_head(&(v721_9)) { singleton(&[]) } else { Space::new() };
            drop(v721_9);
            let v721_12: Space = if (v721_10).is_empty() { Space::new() } else {
              let v723_6: Path = concat_path(&(v720_6),&(v720_7_head));
              let v723_11: Space = routine_49(c, &(v723_6), &(*p1), &(v720_7_tail).make_space());
              drop(v723_6);
              compose(&(v721_10),&(v723_11))
            };
            drop(v721_10);
            let v721_13: Space = unite(&(v721_8),&(v721_12));
            v720_7.join_into((v721_13).clone());
            }
            v720_7_cursor.ascend(1);
          }
          drop(v720_7_cursor);
          compose(&(v719_5),&(v720_7))
        };
        drop(v719_5);
        let v719_9: Space = intersect(&(*CONSTANT_2),&(v719_2));
        drop(v719_2);
        let v719_10: Space = if has_head(&(v719_9)) { singleton(&[]) } else { Space::new() };
        drop(v719_9);
        let v719_12: Space = if (v719_10).is_empty() { Space::new() } else {
          let v724_6: Path = concat_path(&(v718_6),&(v718_7_head));
          let mut v724_11 = Space::new();
          let mut v724_11_cursor = (v718_7_tail).read_zipper();
          for v724_11_byte in v724_11_cursor.child_mask().iter() {
            v724_11_cursor.descend_to_byte(v724_11_byte);
            {
            let v724_11_tail = v724_11_cursor.fork_read_zipper();
            let v724_11_head = Path::from_slice(&[v724_11_byte]);
            let v725_2: Space = singleton(&(v724_11_head));
            let v725_3: Space = intersect(&(*CONSTANT_2),&(v725_2));
            let v725_4: Space = if has_head(&(v725_3)) { singleton(&[]) } else { Space::new() };
            drop(v725_3);
            let v725_5: Space = subtract(&(*CONSTANT_1),&(v725_4));
            drop(v725_4);
            let v725_8: Space = if (v725_5).is_empty() { Space::new() } else {
              let v726_6: Path = concat_path(&(v724_6),&(v724_11_head));
              let v726_7: Space = routine_48(c, &(v726_6), &(*p1), &(v724_11_tail).make_space());
              compose(&(v725_5),&(v726_7))
            };
            drop(v725_5);
            let v725_9: Space = intersect(&(*CONSTANT_2),&(v725_2));
            drop(v725_2);
            let v725_10: Space = if has_head(&(v725_9)) { singleton(&[]) } else { Space::new() };
            drop(v725_9);
            let v725_12: Space = if (v725_10).is_empty() { Space::new() } else {
              let v727_6: Path = concat_path(&(v724_6),&(v724_11_head));
              let v727_11: Space = routine_19(c, &(v727_6), &(*p1), &(v724_11_tail).make_space());
              drop(v727_6);
              compose(&(v725_10),&(v727_11))
            };
            drop(v725_10);
            let v725_13: Space = unite(&(v725_8),&(v725_12));
            v724_11.join_into((v725_13).clone());
            }
            v724_11_cursor.ascend(1);
          }
          drop(v724_11_cursor);
          drop(v724_6);
          compose(&(v719_10),&(v724_11))
        };
        drop(v719_10);
        let v719_13: Space = unite(&(v719_8),&(v719_12));
        v718_7.join_into((v719_13).clone());
        }
        v718_7_cursor.ascend(1);
      }
      drop(v718_7_cursor);
      compose(&(v717_5),&(v718_7))
    };
    drop(v717_5);
    let v717_9: Space = intersect(&(*CONSTANT_2),&(v717_2));
    drop(v717_2);
    let v717_10: Space = if has_head(&(v717_9)) { singleton(&[]) } else { Space::new() };
    drop(v717_9);
    let v717_11: Space = compose(&(v717_10),&(v716_15_tail));
    drop(v717_10);
    let v728_6: Path = concat_path(&(*p0),&(v716_15_head));
    let v717_12: Space = wrap(&(v717_11),&(v728_6));
    drop(v717_11);
    let v717_13: Space = wrap(&(v717_12),&(*p1));
    drop(v717_12);
    let v717_14: Space = unite(&(v717_8),&(v717_13));
    drop(v717_13);
    v716_15.join_into((v717_14).clone());
    }
    v716_15_cursor.ascend(1);
  }
  drop(v716_15_cursor);
  (v716_15).clone()
}

fn routine_38(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v729_15: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v729_16: Space = unwrap(&(v729_15),&(*p0));
  drop(v729_15);
  let mut v729_20 = Space::new();
  let mut v729_20_cursor = (*s0).read_zipper();
  for v729_20_byte in v729_20_cursor.child_mask().iter() {
    v729_20_cursor.descend_to_byte(v729_20_byte);
    {
    let v729_20_tail = v729_20_cursor.fork_read_zipper();
    let v729_20_head = Path::from_slice(&[v729_20_byte]);
    let v730_2: Space = singleton(&(v729_20_head));
    let v730_3: Space = intersect(&(*CONSTANT_2),&(v730_2));
    let v730_4: Space = if has_head(&(v730_3)) { singleton(&[]) } else { Space::new() };
    drop(v730_3);
    let v730_5: Space = subtract(&(*CONSTANT_1),&(v730_4));
    drop(v730_4);
    let v730_8: Space = if (v730_5).is_empty() { Space::new() } else {
      let v731_6: Path = concat_path(&(*p0),&(v729_20_head));
      let mut v731_7 = Space::new();
      let mut v731_7_cursor = (v729_20_tail).read_zipper();
      for v731_7_byte in v731_7_cursor.child_mask().iter() {
        v731_7_cursor.descend_to_byte(v731_7_byte);
        {
        let v731_7_tail = v731_7_cursor.fork_read_zipper();
        let v731_7_head = Path::from_slice(&[v731_7_byte]);
        let v732_2: Space = singleton(&(v731_7_head));
        let v732_3: Space = intersect(&(*CONSTANT_2),&(v732_2));
        let v732_4: Space = if has_head(&(v732_3)) { singleton(&[]) } else { Space::new() };
        drop(v732_3);
        let v732_5: Space = subtract(&(*CONSTANT_1),&(v732_4));
        drop(v732_4);
        let mut v732_6 = Space::new();
        let mut v732_6_cursor = (v731_7_tail).read_zipper();
        for v732_6_byte in v732_6_cursor.child_mask().iter() {
          v732_6_cursor.descend_to_byte(v732_6_byte);
          {
          let v732_6_tail = v732_6_cursor.fork_read_zipper();
          let v732_6_head = Path::from_slice(&[v732_6_byte]);
          let v733_2: Space = Space::new();
          v732_6.join_into((v733_2).clone());
          }
          v732_6_cursor.ascend(1);
        }
        drop(v732_6_cursor);
        let v732_7: Space = compose(&(v732_5),&(v732_6));
        drop(v732_5);
        drop(v732_6);
        let v732_8: Space = intersect(&(*CONSTANT_2),&(v732_2));
        drop(v732_2);
        let v732_9: Space = if has_head(&(v732_8)) { singleton(&[]) } else { Space::new() };
        drop(v732_8);
        let v732_12: Space = if (v732_9).is_empty() { Space::new() } else {
          let v734_10: Path = concat_path(&(v731_6),&(v731_7_head));
          let mut v734_11 = Space::new();
          let mut v734_11_cursor = (v731_7_tail).read_zipper();
          for v734_11_byte in v734_11_cursor.child_mask().iter() {
            v734_11_cursor.descend_to_byte(v734_11_byte);
            {
            let v734_11_tail = v734_11_cursor.fork_read_zipper();
            let v734_11_head = Path::from_slice(&[v734_11_byte]);
            let v735_2: Space = singleton(&(v734_11_head));
            let v735_3: Space = intersect(&(*CONSTANT_2),&(v735_2));
            drop(v735_2);
            let v735_4: Space = if has_head(&(v735_3)) { singleton(&[]) } else { Space::new() };
            drop(v735_3);
            let v735_7: Space = if (v735_4).is_empty() { Space::new() } else {
              let v736_5: Path = concat_path(&(v734_10),&(v734_11_head));
              let v736_6: Space = routine_10(c, &(v736_5), &(*p1), &(v734_11_tail).make_space(), &(*s1));
              drop(v736_5);
              compose(&(v735_4),&(v736_6))
            };
            drop(v735_4);
            v734_11.join_into((v735_7).clone());
            }
            v734_11_cursor.ascend(1);
          }
          drop(v734_11_cursor);
          drop(v734_10);
          compose(&(v732_9),&(v734_11))
        };
        drop(v732_9);
        let v732_13: Space = unite(&(v732_7),&(v732_12));
        drop(v732_7);
        v731_7.join_into((v732_13).clone());
        }
        v731_7_cursor.ascend(1);
      }
      drop(v731_7_cursor);
      drop(v731_6);
      compose(&(v730_5),&(v731_7))
    };
    drop(v730_5);
    let v730_9: Space = intersect(&(*CONSTANT_2),&(v730_2));
    drop(v730_2);
    let v730_10: Space = if has_head(&(v730_9)) { singleton(&[]) } else { Space::new() };
    drop(v730_9);
    let v730_13: Space = if (v730_10).is_empty() { Space::new() } else {
      let v737_11: Space = unwrap(&(v729_16),&(v729_20_head));
      let mut v737_12 = Space::new();
      let mut v737_12_cursor = (v729_20_tail).read_zipper();
      for v737_12_byte in v737_12_cursor.child_mask().iter() {
        v737_12_cursor.descend_to_byte(v737_12_byte);
        {
        let v737_12_tail = v737_12_cursor.fork_read_zipper();
        let v737_12_head = Path::from_slice(&[v737_12_byte]);
        let v738_2: Space = singleton(&(v737_12_head));
        let v738_3: Space = intersect(&(*CONSTANT_2),&(v738_2));
        let v738_4: Space = if has_head(&(v738_3)) { singleton(&[]) } else { Space::new() };
        drop(v738_3);
        let v738_5: Space = subtract(&(*CONSTANT_1),&(v738_4));
        drop(v738_4);
        let mut v738_6 = Space::new();
        let mut v738_6_cursor = (v737_12_tail).read_zipper();
        for v738_6_byte in v738_6_cursor.child_mask().iter() {
          v738_6_cursor.descend_to_byte(v738_6_byte);
          {
          let v738_6_tail = v738_6_cursor.fork_read_zipper();
          let v738_6_head = Path::from_slice(&[v738_6_byte]);
          let v739_2: Space = Space::new();
          v738_6.join_into((v739_2).clone());
          }
          v738_6_cursor.ascend(1);
        }
        drop(v738_6_cursor);
        let v738_7: Space = compose(&(v738_5),&(v738_6));
        drop(v738_5);
        drop(v738_6);
        let v738_8: Space = intersect(&(*CONSTANT_2),&(v738_2));
        drop(v738_2);
        let v738_9: Space = if has_head(&(v738_8)) { singleton(&[]) } else { Space::new() };
        drop(v738_8);
        let v738_12: Space = if (v738_9).is_empty() { Space::new() } else {
          let v740_10: Space = unwrap(&(v737_11),&(v737_12_head));
          let mut v740_11 = Space::new();
          let mut v740_11_cursor = (v740_10).read_zipper();
          for v740_11_byte in v740_11_cursor.child_mask().iter() {
            v740_11_cursor.descend_to_byte(v740_11_byte);
            {
            let v740_11_tail = v740_11_cursor.fork_read_zipper();
            let v740_11_head = Path::from_slice(&[v740_11_byte]);
            let v741_2: Space = singleton(&(v740_11_head));
            let v741_3: Space = intersect(&(*CONSTANT_2),&(v741_2));
            let v741_4: Space = if has_head(&(v741_3)) { singleton(&[]) } else { Space::new() };
            drop(v741_3);
            let v741_5: Space = subtract(&(*CONSTANT_1),&(v741_4));
            drop(v741_4);
            let v741_7: Space = if (v741_5).is_empty() { Space::new() } else {
              let v742_6: Space = routine_13(c, &(v740_11_head), &(*p1), &(v740_11_tail).make_space());
              compose(&(v741_5),&(v742_6))
            };
            drop(v741_5);
            let v741_8: Space = intersect(&(*CONSTANT_2),&(v741_2));
            drop(v741_2);
            let v741_9: Space = if has_head(&(v741_8)) { singleton(&[]) } else { Space::new() };
            drop(v741_8);
            let v741_11: Space = if (v741_9).is_empty() { Space::new() } else {
              let v743_10: Space = routine_14(c, &(v740_11_head), &(*p1), &(v740_11_tail).make_space());
              compose(&(v741_9),&(v743_10))
            };
            drop(v741_9);
            let v741_12: Space = unite(&(v741_7),&(v741_11));
            v740_11.join_into((v741_12).clone());
            }
            v740_11_cursor.ascend(1);
          }
          drop(v740_11_cursor);
          drop(v740_10);
          compose(&(v738_9),&(v740_11))
        };
        drop(v738_9);
        let v738_13: Space = unite(&(v738_7),&(v738_12));
        drop(v738_7);
        v737_12.join_into((v738_13).clone());
        }
        v737_12_cursor.ascend(1);
      }
      drop(v737_12_cursor);
      drop(v737_11);
      compose(&(v730_10),&(v737_12))
    };
    drop(v730_10);
    let v730_14: Space = unite(&(v730_8),&(v730_13));
    v729_20.join_into((v730_14).clone());
    }
    v729_20_cursor.ascend(1);
  }
  drop(v729_20_cursor);
  drop(v729_16);
  (v729_20).clone()
}

fn routine_39(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v744_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v744_9: Space = unwrap(&(v744_8),&(*p0));
  drop(v744_8);
  let mut v744_23 = Space::new();
  let mut v744_23_cursor = (*s0).read_zipper();
  for v744_23_byte in v744_23_cursor.child_mask().iter() {
    v744_23_cursor.descend_to_byte(v744_23_byte);
    {
    let v744_23_tail = v744_23_cursor.fork_read_zipper();
    let v744_23_head = Path::from_slice(&[v744_23_byte]);
    let v745_2: Space = singleton(&(v744_23_head));
    let v745_3: Space = intersect(&(*CONSTANT_2),&(v745_2));
    let v745_4: Space = if has_head(&(v745_3)) { singleton(&[]) } else { Space::new() };
    drop(v745_3);
    let v745_5: Space = subtract(&(*CONSTANT_1),&(v745_4));
    drop(v745_4);
    let v745_8: Space = if (v745_5).is_empty() { Space::new() } else {
      let v746_6: Path = concat_path(&(*p0),&(v744_23_head));
      let mut v746_7 = Space::new();
      let mut v746_7_cursor = (v744_23_tail).read_zipper();
      for v746_7_byte in v746_7_cursor.child_mask().iter() {
        v746_7_cursor.descend_to_byte(v746_7_byte);
        {
        let v746_7_tail = v746_7_cursor.fork_read_zipper();
        let v746_7_head = Path::from_slice(&[v746_7_byte]);
        let v747_2: Space = singleton(&(v746_7_head));
        let v747_3: Space = intersect(&(*CONSTANT_2),&(v747_2));
        let v747_4: Space = if has_head(&(v747_3)) { singleton(&[]) } else { Space::new() };
        drop(v747_3);
        let v747_5: Space = subtract(&(*CONSTANT_1),&(v747_4));
        drop(v747_4);
        let mut v747_6 = Space::new();
        let mut v747_6_cursor = (v746_7_tail).read_zipper();
        for v747_6_byte in v747_6_cursor.child_mask().iter() {
          v747_6_cursor.descend_to_byte(v747_6_byte);
          {
          let v747_6_tail = v747_6_cursor.fork_read_zipper();
          let v747_6_head = Path::from_slice(&[v747_6_byte]);
          let v748_2: Space = Space::new();
          v747_6.join_into((v748_2).clone());
          }
          v747_6_cursor.ascend(1);
        }
        drop(v747_6_cursor);
        let v747_7: Space = compose(&(v747_5),&(v747_6));
        drop(v747_5);
        drop(v747_6);
        let v747_8: Space = intersect(&(*CONSTANT_2),&(v747_2));
        drop(v747_2);
        let v747_9: Space = if has_head(&(v747_8)) { singleton(&[]) } else { Space::new() };
        drop(v747_8);
        let v747_12: Space = if (v747_9).is_empty() { Space::new() } else {
          let v749_10: Path = concat_path(&(v746_6),&(v746_7_head));
          let mut v749_11 = Space::new();
          let mut v749_11_cursor = (v746_7_tail).read_zipper();
          for v749_11_byte in v749_11_cursor.child_mask().iter() {
            v749_11_cursor.descend_to_byte(v749_11_byte);
            {
            let v749_11_tail = v749_11_cursor.fork_read_zipper();
            let v749_11_head = Path::from_slice(&[v749_11_byte]);
            let v750_2: Space = singleton(&(v749_11_head));
            let v750_3: Space = intersect(&(*CONSTANT_2),&(v750_2));
            drop(v750_2);
            let v750_4: Space = if has_head(&(v750_3)) { singleton(&[]) } else { Space::new() };
            drop(v750_3);
            let v750_7: Space = if (v750_4).is_empty() { Space::new() } else {
              let v751_5: Path = concat_path(&(v749_10),&(v749_11_head));
              let v751_6: Space = routine_10(c, &(v751_5), &(*p1), &(v749_11_tail).make_space(), &(*s1));
              drop(v751_5);
              compose(&(v750_4),&(v751_6))
            };
            drop(v750_4);
            v749_11.join_into((v750_7).clone());
            }
            v749_11_cursor.ascend(1);
          }
          drop(v749_11_cursor);
          drop(v749_10);
          compose(&(v747_9),&(v749_11))
        };
        drop(v747_9);
        let v747_13: Space = unite(&(v747_7),&(v747_12));
        drop(v747_7);
        v746_7.join_into((v747_13).clone());
        }
        v746_7_cursor.ascend(1);
      }
      drop(v746_7_cursor);
      drop(v746_6);
      compose(&(v745_5),&(v746_7))
    };
    drop(v745_5);
    let v745_9: Space = intersect(&(*CONSTANT_2),&(v745_2));
    drop(v745_2);
    let v745_10: Space = if has_head(&(v745_9)) { singleton(&[]) } else { Space::new() };
    drop(v745_9);
    let v745_13: Space = if (v745_10).is_empty() { Space::new() } else {
      let v752_11: Space = unwrap(&(v744_9),&(v744_23_head));
      let mut v752_12 = Space::new();
      let mut v752_12_cursor = (v752_11).read_zipper();
      for v752_12_byte in v752_12_cursor.child_mask().iter() {
        v752_12_cursor.descend_to_byte(v752_12_byte);
        {
        let v752_12_tail = v752_12_cursor.fork_read_zipper();
        let v752_12_head = Path::from_slice(&[v752_12_byte]);
        let v753_2: Space = singleton(&(v752_12_head));
        let v753_3: Space = intersect(&(*CONSTANT_2),&(v753_2));
        let v753_4: Space = if has_head(&(v753_3)) { singleton(&[]) } else { Space::new() };
        drop(v753_3);
        let v753_5: Space = subtract(&(*CONSTANT_1),&(v753_4));
        drop(v753_4);
        let v753_7: Space = if (v753_5).is_empty() { Space::new() } else {
          let mut v754_6 = Space::new();
          let mut v754_6_cursor = (v752_12_tail).read_zipper();
          for v754_6_byte in v754_6_cursor.child_mask().iter() {
            v754_6_cursor.descend_to_byte(v754_6_byte);
            {
            let v754_6_tail = v754_6_cursor.fork_read_zipper();
            let v754_6_head = Path::from_slice(&[v754_6_byte]);
            let v755_2: Space = singleton(&(v754_6_head));
            let v755_3: Space = intersect(&(*CONSTANT_2),&(v755_2));
            let v755_4: Space = if has_head(&(v755_3)) { singleton(&[]) } else { Space::new() };
            drop(v755_3);
            let v755_5: Space = subtract(&(*CONSTANT_1),&(v755_4));
            drop(v755_4);
            let v755_8: Space = if (v755_5).is_empty() { Space::new() } else {
              let v756_6: Path = concat_path(&(v752_12_head),&(v754_6_head));
              let v756_7: Space = routine_17(c, &(v756_6), &(*p1), &(v754_6_tail).make_space());
              compose(&(v755_5),&(v756_7))
            };
            drop(v755_5);
            let v755_9: Space = intersect(&(*CONSTANT_2),&(v755_2));
            drop(v755_2);
            let v755_10: Space = if has_head(&(v755_9)) { singleton(&[]) } else { Space::new() };
            drop(v755_9);
            let v755_12: Space = if (v755_10).is_empty() { Space::new() } else {
              let v757_6: Path = concat_path(&(v752_12_head),&(v754_6_head));
              let v757_11: Space = routine_18(c, &(v757_6), &(*p1), &(v754_6_tail).make_space());
              drop(v757_6);
              compose(&(v755_10),&(v757_11))
            };
            drop(v755_10);
            let v755_13: Space = unite(&(v755_8),&(v755_12));
            v754_6.join_into((v755_13).clone());
            }
            v754_6_cursor.ascend(1);
          }
          drop(v754_6_cursor);
          compose(&(v753_5),&(v754_6))
        };
        drop(v753_5);
        let v753_8: Space = intersect(&(*CONSTANT_2),&(v753_2));
        drop(v753_2);
        let v753_9: Space = if has_head(&(v753_8)) { singleton(&[]) } else { Space::new() };
        drop(v753_8);
        let v753_11: Space = if (v753_9).is_empty() { Space::new() } else {
          let mut v758_10 = Space::new();
          let mut v758_10_cursor = (v752_12_tail).read_zipper();
          for v758_10_byte in v758_10_cursor.child_mask().iter() {
            v758_10_cursor.descend_to_byte(v758_10_byte);
            {
            let v758_10_tail = v758_10_cursor.fork_read_zipper();
            let v758_10_head = Path::from_slice(&[v758_10_byte]);
            let v759_2: Space = singleton(&(v758_10_head));
            let v759_3: Space = intersect(&(*CONSTANT_2),&(v759_2));
            let v759_4: Space = if has_head(&(v759_3)) { singleton(&[]) } else { Space::new() };
            drop(v759_3);
            let v759_5: Space = subtract(&(*CONSTANT_1),&(v759_4));
            drop(v759_4);
            let v759_8: Space = if (v759_5).is_empty() { Space::new() } else {
              let v760_6: Path = concat_path(&(v752_12_head),&(v758_10_head));
              let v760_7: Space = routine_17(c, &(v760_6), &(*p1), &(v758_10_tail).make_space());
              compose(&(v759_5),&(v760_7))
            };
            drop(v759_5);
            let v759_9: Space = intersect(&(*CONSTANT_2),&(v759_2));
            drop(v759_2);
            let v759_10: Space = if has_head(&(v759_9)) { singleton(&[]) } else { Space::new() };
            drop(v759_9);
            let v759_12: Space = if (v759_10).is_empty() { Space::new() } else {
              let v761_6: Path = concat_path(&(v752_12_head),&(v758_10_head));
              let v761_11: Space = routine_19(c, &(v761_6), &(*p1), &(v758_10_tail).make_space());
              drop(v761_6);
              compose(&(v759_10),&(v761_11))
            };
            drop(v759_10);
            let v759_13: Space = unite(&(v759_8),&(v759_12));
            v758_10.join_into((v759_13).clone());
            }
            v758_10_cursor.ascend(1);
          }
          drop(v758_10_cursor);
          compose(&(v753_9),&(v758_10))
        };
        drop(v753_9);
        let v753_12: Space = unite(&(v753_7),&(v753_11));
        v752_12.join_into((v753_12).clone());
        }
        v752_12_cursor.ascend(1);
      }
      drop(v752_12_cursor);
      drop(v752_11);
      compose(&(v745_10),&(v752_12))
    };
    drop(v745_10);
    let v745_14: Space = unite(&(v745_8),&(v745_13));
    v744_23.join_into((v745_14).clone());
    }
    v744_23_cursor.ascend(1);
  }
  drop(v744_23_cursor);
  drop(v744_9);
  (v744_23).clone()
}

fn routine_40(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v762_21 = Space::new();
  let mut v762_21_cursor = (*s0).read_zipper();
  for v762_21_byte in v762_21_cursor.child_mask().iter() {
    v762_21_cursor.descend_to_byte(v762_21_byte);
    {
    let v762_21_tail = v762_21_cursor.fork_read_zipper();
    let v762_21_head = Path::from_slice(&[v762_21_byte]);
    let v763_2: Space = singleton(&(v762_21_head));
    let v763_3: Space = intersect(&(*CONSTANT_2),&(v763_2));
    let v763_4: Space = if has_head(&(v763_3)) { singleton(&[]) } else { Space::new() };
    drop(v763_3);
    let v763_5: Space = subtract(&(*CONSTANT_1),&(v763_4));
    drop(v763_4);
    let v763_8: Space = if (v763_5).is_empty() { Space::new() } else {
      let v764_6: Path = concat_path(&(*p0),&(v762_21_head));
      let mut v764_7 = Space::new();
      let mut v764_7_cursor = (v762_21_tail).read_zipper();
      for v764_7_byte in v764_7_cursor.child_mask().iter() {
        v764_7_cursor.descend_to_byte(v764_7_byte);
        {
        let v764_7_tail = v764_7_cursor.fork_read_zipper();
        let v764_7_head = Path::from_slice(&[v764_7_byte]);
        let v765_2: Space = singleton(&(v764_7_head));
        let v765_3: Space = intersect(&(*CONSTANT_2),&(v765_2));
        let v765_4: Space = if has_head(&(v765_3)) { singleton(&[]) } else { Space::new() };
        drop(v765_3);
        let v765_5: Space = subtract(&(*CONSTANT_1),&(v765_4));
        drop(v765_4);
        let v765_8: Space = if (v765_5).is_empty() { Space::new() } else {
          let v766_6: Path = concat_path(&(v764_6),&(v764_7_head));
          let mut v766_7 = Space::new();
          let mut v766_7_cursor = (v764_7_tail).read_zipper();
          for v766_7_byte in v766_7_cursor.child_mask().iter() {
            v766_7_cursor.descend_to_byte(v766_7_byte);
            {
            let v766_7_tail = v766_7_cursor.fork_read_zipper();
            let v766_7_head = Path::from_slice(&[v766_7_byte]);
            let v767_2: Space = singleton(&(v766_7_head));
            let v767_3: Space = intersect(&(*CONSTANT_2),&(v767_2));
            let v767_4: Space = if has_head(&(v767_3)) { singleton(&[]) } else { Space::new() };
            drop(v767_3);
            let v767_5: Space = subtract(&(*CONSTANT_1),&(v767_4));
            drop(v767_4);
            let v767_8: Space = if (v767_5).is_empty() { Space::new() } else {
              let v768_6: Path = concat_path(&(v766_6),&(v766_7_head));
              let v768_7: Space = routine_50(c, &(v768_6), &(*p1), &(v766_7_tail).make_space());
              compose(&(v767_5),&(v768_7))
            };
            drop(v767_5);
            let v767_9: Space = intersect(&(*CONSTANT_2),&(v767_2));
            drop(v767_2);
            let v767_10: Space = if has_head(&(v767_9)) { singleton(&[]) } else { Space::new() };
            drop(v767_9);
            let v767_12: Space = if (v767_10).is_empty() { Space::new() } else {
              let v769_6: Path = concat_path(&(v766_6),&(v766_7_head));
              let v769_11: Space = routine_51(c, &(v769_6), &(*p1), &(v766_7_tail).make_space());
              drop(v769_6);
              compose(&(v767_10),&(v769_11))
            };
            drop(v767_10);
            let v767_13: Space = unite(&(v767_8),&(v767_12));
            v766_7.join_into((v767_13).clone());
            }
            v766_7_cursor.ascend(1);
          }
          drop(v766_7_cursor);
          compose(&(v765_5),&(v766_7))
        };
        drop(v765_5);
        let v765_9: Space = intersect(&(*CONSTANT_2),&(v765_2));
        drop(v765_2);
        let v765_10: Space = if has_head(&(v765_9)) { singleton(&[]) } else { Space::new() };
        drop(v765_9);
        let v765_12: Space = if (v765_10).is_empty() { Space::new() } else {
          let v770_6: Path = concat_path(&(v764_6),&(v764_7_head));
          let mut v770_11 = Space::new();
          let mut v770_11_cursor = (v764_7_tail).read_zipper();
          for v770_11_byte in v770_11_cursor.child_mask().iter() {
            v770_11_cursor.descend_to_byte(v770_11_byte);
            {
            let v770_11_tail = v770_11_cursor.fork_read_zipper();
            let v770_11_head = Path::from_slice(&[v770_11_byte]);
            let v771_2: Space = singleton(&(v770_11_head));
            let v771_3: Space = intersect(&(*CONSTANT_2),&(v771_2));
            let v771_4: Space = if has_head(&(v771_3)) { singleton(&[]) } else { Space::new() };
            drop(v771_3);
            let v771_5: Space = subtract(&(*CONSTANT_1),&(v771_4));
            drop(v771_4);
            let v771_8: Space = if (v771_5).is_empty() { Space::new() } else {
              let v772_6: Path = concat_path(&(v770_6),&(v770_11_head));
              let v772_7: Space = routine_50(c, &(v772_6), &(*p1), &(v770_11_tail).make_space());
              compose(&(v771_5),&(v772_7))
            };
            drop(v771_5);
            let v771_9: Space = intersect(&(*CONSTANT_2),&(v771_2));
            drop(v771_2);
            let v771_10: Space = if has_head(&(v771_9)) { singleton(&[]) } else { Space::new() };
            drop(v771_9);
            let v771_12: Space = if (v771_10).is_empty() { Space::new() } else {
              let v773_6: Path = concat_path(&(v770_6),&(v770_11_head));
              let v773_11: Space = routine_19(c, &(v773_6), &(*p1), &(v770_11_tail).make_space());
              drop(v773_6);
              compose(&(v771_10),&(v773_11))
            };
            drop(v771_10);
            let v771_13: Space = unite(&(v771_8),&(v771_12));
            v770_11.join_into((v771_13).clone());
            }
            v770_11_cursor.ascend(1);
          }
          drop(v770_11_cursor);
          drop(v770_6);
          compose(&(v765_10),&(v770_11))
        };
        drop(v765_10);
        let v765_13: Space = unite(&(v765_8),&(v765_12));
        v764_7.join_into((v765_13).clone());
        }
        v764_7_cursor.ascend(1);
      }
      drop(v764_7_cursor);
      compose(&(v763_5),&(v764_7))
    };
    drop(v763_5);
    let v763_9: Space = intersect(&(*CONSTANT_2),&(v763_2));
    drop(v763_2);
    let v763_10: Space = if has_head(&(v763_9)) { singleton(&[]) } else { Space::new() };
    drop(v763_9);
    let v763_12: Space = if (v763_10).is_empty() { Space::new() } else {
      let v774_6: Path = concat_path(&(*p0),&(v762_21_head));
      let mut v774_11 = Space::new();
      let mut v774_11_cursor = (v762_21_tail).read_zipper();
      for v774_11_byte in v774_11_cursor.child_mask().iter() {
        v774_11_cursor.descend_to_byte(v774_11_byte);
        {
        let v774_11_tail = v774_11_cursor.fork_read_zipper();
        let v774_11_head = Path::from_slice(&[v774_11_byte]);
        let v775_2: Space = singleton(&(v774_11_head));
        let v775_3: Space = intersect(&(*CONSTANT_2),&(v775_2));
        let v775_4: Space = if has_head(&(v775_3)) { singleton(&[]) } else { Space::new() };
        drop(v775_3);
        let v775_5: Space = subtract(&(*CONSTANT_1),&(v775_4));
        drop(v775_4);
        let v775_8: Space = if (v775_5).is_empty() { Space::new() } else {
          let v776_6: Path = concat_path(&(v774_6),&(v774_11_head));
          let mut v776_7 = Space::new();
          let mut v776_7_cursor = (v774_11_tail).read_zipper();
          for v776_7_byte in v776_7_cursor.child_mask().iter() {
            v776_7_cursor.descend_to_byte(v776_7_byte);
            {
            let v776_7_tail = v776_7_cursor.fork_read_zipper();
            let v776_7_head = Path::from_slice(&[v776_7_byte]);
            let v777_2: Space = singleton(&(v776_7_head));
            let v777_3: Space = intersect(&(*CONSTANT_2),&(v777_2));
            let v777_4: Space = if has_head(&(v777_3)) { singleton(&[]) } else { Space::new() };
            drop(v777_3);
            let v777_5: Space = subtract(&(*CONSTANT_1),&(v777_4));
            drop(v777_4);
            let v777_8: Space = if (v777_5).is_empty() { Space::new() } else {
              let v778_6: Path = concat_path(&(v776_6),&(v776_7_head));
              let v778_7: Space = routine_50(c, &(v778_6), &(*p1), &(v776_7_tail).make_space());
              compose(&(v777_5),&(v778_7))
            };
            drop(v777_5);
            let v777_9: Space = intersect(&(*CONSTANT_2),&(v777_2));
            drop(v777_2);
            let v777_10: Space = if has_head(&(v777_9)) { singleton(&[]) } else { Space::new() };
            drop(v777_9);
            let v777_12: Space = if (v777_10).is_empty() { Space::new() } else {
              let v779_6: Path = concat_path(&(v776_6),&(v776_7_head));
              let v779_11: Space = routine_51(c, &(v779_6), &(*p1), &(v776_7_tail).make_space());
              drop(v779_6);
              compose(&(v777_10),&(v779_11))
            };
            drop(v777_10);
            let v777_13: Space = unite(&(v777_8),&(v777_12));
            v776_7.join_into((v777_13).clone());
            }
            v776_7_cursor.ascend(1);
          }
          drop(v776_7_cursor);
          compose(&(v775_5),&(v776_7))
        };
        drop(v775_5);
        let v775_9: Space = intersect(&(*CONSTANT_2),&(v775_2));
        drop(v775_2);
        let v775_10: Space = if has_head(&(v775_9)) { singleton(&[]) } else { Space::new() };
        drop(v775_9);
        let v775_11: Space = compose(&(v775_10),&(v774_11_tail));
        drop(v775_10);
        let v780_6: Path = concat_path(&(v774_6),&(v774_11_head));
        let v775_12: Space = wrap(&(v775_11),&(v780_6));
        drop(v775_11);
        let v775_13: Space = wrap(&(v775_12),&(*p1));
        drop(v775_12);
        let v775_14: Space = unite(&(v775_8),&(v775_13));
        drop(v775_13);
        v774_11.join_into((v775_14).clone());
        }
        v774_11_cursor.ascend(1);
      }
      drop(v774_11_cursor);
      drop(v774_6);
      compose(&(v763_10),&(v774_11))
    };
    drop(v763_10);
    let v763_13: Space = unite(&(v763_8),&(v763_12));
    v762_21.join_into((v763_13).clone());
    }
    v762_21_cursor.ascend(1);
  }
  drop(v762_21_cursor);
  (v762_21).clone()
}

fn routine_41(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v781_15 = Space::new();
  let mut v781_15_cursor = (*s0).read_zipper();
  for v781_15_byte in v781_15_cursor.child_mask().iter() {
    v781_15_cursor.descend_to_byte(v781_15_byte);
    {
    let v781_15_tail = v781_15_cursor.fork_read_zipper();
    let v781_15_head = Path::from_slice(&[v781_15_byte]);
    let v782_2: Space = singleton(&(v781_15_head));
    let v782_3: Space = intersect(&(*CONSTANT_2),&(v782_2));
    let v782_4: Space = if has_head(&(v782_3)) { singleton(&[]) } else { Space::new() };
    drop(v782_3);
    let v782_5: Space = subtract(&(*CONSTANT_1),&(v782_4));
    drop(v782_4);
    let v782_8: Space = if (v782_5).is_empty() { Space::new() } else {
      let v783_6: Path = concat_path(&(*p0),&(v781_15_head));
      let mut v783_7 = Space::new();
      let mut v783_7_cursor = (v781_15_tail).read_zipper();
      for v783_7_byte in v783_7_cursor.child_mask().iter() {
        v783_7_cursor.descend_to_byte(v783_7_byte);
        {
        let v783_7_tail = v783_7_cursor.fork_read_zipper();
        let v783_7_head = Path::from_slice(&[v783_7_byte]);
        let v784_2: Space = singleton(&(v783_7_head));
        let v784_3: Space = intersect(&(*CONSTANT_2),&(v784_2));
        let v784_4: Space = if has_head(&(v784_3)) { singleton(&[]) } else { Space::new() };
        drop(v784_3);
        let v784_5: Space = subtract(&(*CONSTANT_1),&(v784_4));
        drop(v784_4);
        let v784_8: Space = if (v784_5).is_empty() { Space::new() } else {
          let v785_6: Path = concat_path(&(v783_6),&(v783_7_head));
          let mut v785_7 = Space::new();
          let mut v785_7_cursor = (v783_7_tail).read_zipper();
          for v785_7_byte in v785_7_cursor.child_mask().iter() {
            v785_7_cursor.descend_to_byte(v785_7_byte);
            {
            let v785_7_tail = v785_7_cursor.fork_read_zipper();
            let v785_7_head = Path::from_slice(&[v785_7_byte]);
            let v786_2: Space = singleton(&(v785_7_head));
            let v786_3: Space = intersect(&(*CONSTANT_2),&(v786_2));
            let v786_4: Space = if has_head(&(v786_3)) { singleton(&[]) } else { Space::new() };
            drop(v786_3);
            let v786_5: Space = subtract(&(*CONSTANT_1),&(v786_4));
            drop(v786_4);
            let v786_8: Space = if (v786_5).is_empty() { Space::new() } else {
              let v787_6: Path = concat_path(&(v785_6),&(v785_7_head));
              let v787_7: Space = routine_50(c, &(v787_6), &(*p1), &(v785_7_tail).make_space());
              compose(&(v786_5),&(v787_7))
            };
            drop(v786_5);
            let v786_9: Space = intersect(&(*CONSTANT_2),&(v786_2));
            drop(v786_2);
            let v786_10: Space = if has_head(&(v786_9)) { singleton(&[]) } else { Space::new() };
            drop(v786_9);
            let v786_12: Space = if (v786_10).is_empty() { Space::new() } else {
              let v788_6: Path = concat_path(&(v785_6),&(v785_7_head));
              let v788_11: Space = routine_51(c, &(v788_6), &(*p1), &(v785_7_tail).make_space());
              drop(v788_6);
              compose(&(v786_10),&(v788_11))
            };
            drop(v786_10);
            let v786_13: Space = unite(&(v786_8),&(v786_12));
            v785_7.join_into((v786_13).clone());
            }
            v785_7_cursor.ascend(1);
          }
          drop(v785_7_cursor);
          compose(&(v784_5),&(v785_7))
        };
        drop(v784_5);
        let v784_9: Space = intersect(&(*CONSTANT_2),&(v784_2));
        drop(v784_2);
        let v784_10: Space = if has_head(&(v784_9)) { singleton(&[]) } else { Space::new() };
        drop(v784_9);
        let v784_12: Space = if (v784_10).is_empty() { Space::new() } else {
          let v789_6: Path = concat_path(&(v783_6),&(v783_7_head));
          let mut v789_11 = Space::new();
          let mut v789_11_cursor = (v783_7_tail).read_zipper();
          for v789_11_byte in v789_11_cursor.child_mask().iter() {
            v789_11_cursor.descend_to_byte(v789_11_byte);
            {
            let v789_11_tail = v789_11_cursor.fork_read_zipper();
            let v789_11_head = Path::from_slice(&[v789_11_byte]);
            let v790_2: Space = singleton(&(v789_11_head));
            let v790_3: Space = intersect(&(*CONSTANT_2),&(v790_2));
            let v790_4: Space = if has_head(&(v790_3)) { singleton(&[]) } else { Space::new() };
            drop(v790_3);
            let v790_5: Space = subtract(&(*CONSTANT_1),&(v790_4));
            drop(v790_4);
            let v790_8: Space = if (v790_5).is_empty() { Space::new() } else {
              let v791_6: Path = concat_path(&(v789_6),&(v789_11_head));
              let v791_7: Space = routine_50(c, &(v791_6), &(*p1), &(v789_11_tail).make_space());
              compose(&(v790_5),&(v791_7))
            };
            drop(v790_5);
            let v790_9: Space = intersect(&(*CONSTANT_2),&(v790_2));
            drop(v790_2);
            let v790_10: Space = if has_head(&(v790_9)) { singleton(&[]) } else { Space::new() };
            drop(v790_9);
            let v790_12: Space = if (v790_10).is_empty() { Space::new() } else {
              let v792_6: Path = concat_path(&(v789_6),&(v789_11_head));
              let v792_11: Space = routine_19(c, &(v792_6), &(*p1), &(v789_11_tail).make_space());
              drop(v792_6);
              compose(&(v790_10),&(v792_11))
            };
            drop(v790_10);
            let v790_13: Space = unite(&(v790_8),&(v790_12));
            v789_11.join_into((v790_13).clone());
            }
            v789_11_cursor.ascend(1);
          }
          drop(v789_11_cursor);
          drop(v789_6);
          compose(&(v784_10),&(v789_11))
        };
        drop(v784_10);
        let v784_13: Space = unite(&(v784_8),&(v784_12));
        v783_7.join_into((v784_13).clone());
        }
        v783_7_cursor.ascend(1);
      }
      drop(v783_7_cursor);
      compose(&(v782_5),&(v783_7))
    };
    drop(v782_5);
    let v782_9: Space = intersect(&(*CONSTANT_2),&(v782_2));
    drop(v782_2);
    let v782_10: Space = if has_head(&(v782_9)) { singleton(&[]) } else { Space::new() };
    drop(v782_9);
    let v782_11: Space = compose(&(v782_10),&(v781_15_tail));
    drop(v782_10);
    let v793_6: Path = concat_path(&(*p0),&(v781_15_head));
    let v782_12: Space = wrap(&(v782_11),&(v793_6));
    drop(v782_11);
    let v782_13: Space = wrap(&(v782_12),&(*p1));
    drop(v782_12);
    let v782_14: Space = unite(&(v782_8),&(v782_13));
    drop(v782_13);
    v781_15.join_into((v782_14).clone());
    }
    v781_15_cursor.ascend(1);
  }
  drop(v781_15_cursor);
  (v781_15).clone()
}

fn routine_42(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v794_9: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v794_10: Space = unwrap(&(v794_9),&(*p0));
  drop(v794_9);
  let mut v794_14 = Space::new();
  let mut v794_14_cursor = (*s0).read_zipper();
  for v794_14_byte in v794_14_cursor.child_mask().iter() {
    v794_14_cursor.descend_to_byte(v794_14_byte);
    {
    let v794_14_tail = v794_14_cursor.fork_read_zipper();
    let v794_14_head = Path::from_slice(&[v794_14_byte]);
    let v795_2: Space = singleton(&(v794_14_head));
    let v795_3: Space = intersect(&(*CONSTANT_2),&(v795_2));
    let v795_4: Space = if has_head(&(v795_3)) { singleton(&[]) } else { Space::new() };
    drop(v795_3);
    let v795_5: Space = subtract(&(*CONSTANT_1),&(v795_4));
    drop(v795_4);
    let mut v795_6 = Space::new();
    let mut v795_6_cursor = (v794_14_tail).read_zipper();
    for v795_6_byte in v795_6_cursor.child_mask().iter() {
      v795_6_cursor.descend_to_byte(v795_6_byte);
      {
      let v795_6_tail = v795_6_cursor.fork_read_zipper();
      let v795_6_head = Path::from_slice(&[v795_6_byte]);
      let v796_2: Space = Space::new();
      v795_6.join_into((v796_2).clone());
      }
      v795_6_cursor.ascend(1);
    }
    drop(v795_6_cursor);
    let v795_7: Space = compose(&(v795_5),&(v795_6));
    drop(v795_5);
    drop(v795_6);
    let v795_8: Space = intersect(&(*CONSTANT_2),&(v795_2));
    drop(v795_2);
    let v795_9: Space = if has_head(&(v795_8)) { singleton(&[]) } else { Space::new() };
    drop(v795_8);
    let v795_12: Space = if (v795_9).is_empty() { Space::new() } else {
      let v797_10: Space = unwrap(&(v794_10),&(v794_14_head));
      let mut v797_11 = Space::new();
      let mut v797_11_cursor = (v794_14_tail).read_zipper();
      for v797_11_byte in v797_11_cursor.child_mask().iter() {
        v797_11_cursor.descend_to_byte(v797_11_byte);
        {
        let v797_11_tail = v797_11_cursor.fork_read_zipper();
        let v797_11_head = Path::from_slice(&[v797_11_byte]);
        let v798_2: Space = singleton(&(v797_11_head));
        let v798_3: Space = intersect(&(*CONSTANT_2),&(v798_2));
        drop(v798_2);
        let v798_4: Space = if has_head(&(v798_3)) { singleton(&[]) } else { Space::new() };
        drop(v798_3);
        let v798_7: Space = if (v798_4).is_empty() { Space::new() } else {
          let v799_5: Space = unwrap(&(v797_10),&(v797_11_head));
          let mut v799_6 = Space::new();
          let mut v799_6_cursor = (v799_5).read_zipper();
          for v799_6_byte in v799_6_cursor.child_mask().iter() {
            v799_6_cursor.descend_to_byte(v799_6_byte);
            {
            let v799_6_tail = v799_6_cursor.fork_read_zipper();
            let v799_6_head = Path::from_slice(&[v799_6_byte]);
            let v800_2: Space = singleton(&(v799_6_head));
            let v800_3: Space = intersect(&(*CONSTANT_2),&(v800_2));
            let v800_4: Space = if has_head(&(v800_3)) { singleton(&[]) } else { Space::new() };
            drop(v800_3);
            let v800_5: Space = subtract(&(*CONSTANT_1),&(v800_4));
            drop(v800_4);
            let v800_7: Space = if (v800_5).is_empty() { Space::new() } else {
              let v801_6: Space = routine_13(c, &(v799_6_head), &(*p1), &(v799_6_tail).make_space());
              compose(&(v800_5),&(v801_6))
            };
            drop(v800_5);
            let v800_8: Space = intersect(&(*CONSTANT_2),&(v800_2));
            drop(v800_2);
            let v800_9: Space = if has_head(&(v800_8)) { singleton(&[]) } else { Space::new() };
            drop(v800_8);
            let v800_11: Space = if (v800_9).is_empty() { Space::new() } else {
              let v802_10: Space = routine_14(c, &(v799_6_head), &(*p1), &(v799_6_tail).make_space());
              compose(&(v800_9),&(v802_10))
            };
            drop(v800_9);
            let v800_12: Space = unite(&(v800_7),&(v800_11));
            v799_6.join_into((v800_12).clone());
            }
            v799_6_cursor.ascend(1);
          }
          drop(v799_6_cursor);
          drop(v799_5);
          compose(&(v798_4),&(v799_6))
        };
        drop(v798_4);
        v797_11.join_into((v798_7).clone());
        }
        v797_11_cursor.ascend(1);
      }
      drop(v797_11_cursor);
      drop(v797_10);
      compose(&(v795_9),&(v797_11))
    };
    drop(v795_9);
    let v795_13: Space = unite(&(v795_7),&(v795_12));
    drop(v795_7);
    v794_14.join_into((v795_13).clone());
    }
    v794_14_cursor.ascend(1);
  }
  drop(v794_14_cursor);
  drop(v794_10);
  (v794_14).clone()
}

fn routine_43(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v803_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v803_9: Space = unwrap(&(v803_8),&(*p0));
  drop(v803_8);
  let mut v803_19 = Space::new();
  let mut v803_19_cursor = (*s0).read_zipper();
  for v803_19_byte in v803_19_cursor.child_mask().iter() {
    v803_19_cursor.descend_to_byte(v803_19_byte);
    {
    let v803_19_tail = v803_19_cursor.fork_read_zipper();
    let v803_19_head = Path::from_slice(&[v803_19_byte]);
    let v804_2: Space = singleton(&(v803_19_head));
    let v804_3: Space = intersect(&(*CONSTANT_2),&(v804_2));
    let v804_4: Space = if has_head(&(v804_3)) { singleton(&[]) } else { Space::new() };
    drop(v804_3);
    let v804_5: Space = subtract(&(*CONSTANT_1),&(v804_4));
    drop(v804_4);
    let mut v804_6 = Space::new();
    let mut v804_6_cursor = (v803_19_tail).read_zipper();
    for v804_6_byte in v804_6_cursor.child_mask().iter() {
      v804_6_cursor.descend_to_byte(v804_6_byte);
      {
      let v804_6_tail = v804_6_cursor.fork_read_zipper();
      let v804_6_head = Path::from_slice(&[v804_6_byte]);
      let v805_2: Space = Space::new();
      v804_6.join_into((v805_2).clone());
      }
      v804_6_cursor.ascend(1);
    }
    drop(v804_6_cursor);
    let v804_7: Space = compose(&(v804_5),&(v804_6));
    drop(v804_5);
    drop(v804_6);
    let v804_8: Space = intersect(&(*CONSTANT_2),&(v804_2));
    drop(v804_2);
    let v804_9: Space = if has_head(&(v804_8)) { singleton(&[]) } else { Space::new() };
    drop(v804_8);
    let v804_12: Space = if (v804_9).is_empty() { Space::new() } else {
      let v806_10: Space = unwrap(&(v803_9),&(v803_19_head));
      let mut v806_11 = Space::new();
      let mut v806_11_cursor = (v806_10).read_zipper();
      for v806_11_byte in v806_11_cursor.child_mask().iter() {
        v806_11_cursor.descend_to_byte(v806_11_byte);
        {
        let v806_11_tail = v806_11_cursor.fork_read_zipper();
        let v806_11_head = Path::from_slice(&[v806_11_byte]);
        let v807_2: Space = singleton(&(v806_11_head));
        let v807_3: Space = intersect(&(*CONSTANT_2),&(v807_2));
        let v807_4: Space = if has_head(&(v807_3)) { singleton(&[]) } else { Space::new() };
        drop(v807_3);
        let v807_5: Space = subtract(&(*CONSTANT_1),&(v807_4));
        drop(v807_4);
        let v807_7: Space = if (v807_5).is_empty() { Space::new() } else {
          let mut v808_6 = Space::new();
          let mut v808_6_cursor = (v806_11_tail).read_zipper();
          for v808_6_byte in v808_6_cursor.child_mask().iter() {
            v808_6_cursor.descend_to_byte(v808_6_byte);
            {
            let v808_6_tail = v808_6_cursor.fork_read_zipper();
            let v808_6_head = Path::from_slice(&[v808_6_byte]);
            let v809_2: Space = singleton(&(v808_6_head));
            let v809_3: Space = intersect(&(*CONSTANT_2),&(v809_2));
            let v809_4: Space = if has_head(&(v809_3)) { singleton(&[]) } else { Space::new() };
            drop(v809_3);
            let v809_5: Space = subtract(&(*CONSTANT_1),&(v809_4));
            drop(v809_4);
            let v809_8: Space = if (v809_5).is_empty() { Space::new() } else {
              let v810_6: Path = concat_path(&(v806_11_head),&(v808_6_head));
              let v810_7: Space = routine_17(c, &(v810_6), &(*p1), &(v808_6_tail).make_space());
              compose(&(v809_5),&(v810_7))
            };
            drop(v809_5);
            let v809_9: Space = intersect(&(*CONSTANT_2),&(v809_2));
            drop(v809_2);
            let v809_10: Space = if has_head(&(v809_9)) { singleton(&[]) } else { Space::new() };
            drop(v809_9);
            let v809_12: Space = if (v809_10).is_empty() { Space::new() } else {
              let v811_6: Path = concat_path(&(v806_11_head),&(v808_6_head));
              let v811_11: Space = routine_18(c, &(v811_6), &(*p1), &(v808_6_tail).make_space());
              drop(v811_6);
              compose(&(v809_10),&(v811_11))
            };
            drop(v809_10);
            let v809_13: Space = unite(&(v809_8),&(v809_12));
            v808_6.join_into((v809_13).clone());
            }
            v808_6_cursor.ascend(1);
          }
          drop(v808_6_cursor);
          compose(&(v807_5),&(v808_6))
        };
        drop(v807_5);
        let v807_8: Space = intersect(&(*CONSTANT_2),&(v807_2));
        drop(v807_2);
        let v807_9: Space = if has_head(&(v807_8)) { singleton(&[]) } else { Space::new() };
        drop(v807_8);
        let v807_11: Space = if (v807_9).is_empty() { Space::new() } else {
          let mut v812_10 = Space::new();
          let mut v812_10_cursor = (v806_11_tail).read_zipper();
          for v812_10_byte in v812_10_cursor.child_mask().iter() {
            v812_10_cursor.descend_to_byte(v812_10_byte);
            {
            let v812_10_tail = v812_10_cursor.fork_read_zipper();
            let v812_10_head = Path::from_slice(&[v812_10_byte]);
            let v813_2: Space = singleton(&(v812_10_head));
            let v813_3: Space = intersect(&(*CONSTANT_2),&(v813_2));
            let v813_4: Space = if has_head(&(v813_3)) { singleton(&[]) } else { Space::new() };
            drop(v813_3);
            let v813_5: Space = subtract(&(*CONSTANT_1),&(v813_4));
            drop(v813_4);
            let v813_8: Space = if (v813_5).is_empty() { Space::new() } else {
              let v814_6: Path = concat_path(&(v806_11_head),&(v812_10_head));
              let v814_7: Space = routine_17(c, &(v814_6), &(*p1), &(v812_10_tail).make_space());
              compose(&(v813_5),&(v814_7))
            };
            drop(v813_5);
            let v813_9: Space = intersect(&(*CONSTANT_2),&(v813_2));
            drop(v813_2);
            let v813_10: Space = if has_head(&(v813_9)) { singleton(&[]) } else { Space::new() };
            drop(v813_9);
            let v813_12: Space = if (v813_10).is_empty() { Space::new() } else {
              let v815_6: Path = concat_path(&(v806_11_head),&(v812_10_head));
              let v815_11: Space = routine_19(c, &(v815_6), &(*p1), &(v812_10_tail).make_space());
              drop(v815_6);
              compose(&(v813_10),&(v815_11))
            };
            drop(v813_10);
            let v813_13: Space = unite(&(v813_8),&(v813_12));
            v812_10.join_into((v813_13).clone());
            }
            v812_10_cursor.ascend(1);
          }
          drop(v812_10_cursor);
          compose(&(v807_9),&(v812_10))
        };
        drop(v807_9);
        let v807_12: Space = unite(&(v807_7),&(v807_11));
        v806_11.join_into((v807_12).clone());
        }
        v806_11_cursor.ascend(1);
      }
      drop(v806_11_cursor);
      drop(v806_10);
      compose(&(v804_9),&(v806_11))
    };
    drop(v804_9);
    let v804_13: Space = unite(&(v804_7),&(v804_12));
    drop(v804_7);
    v803_19.join_into((v804_13).clone());
    }
    v803_19_cursor.ascend(1);
  }
  drop(v803_19_cursor);
  drop(v803_9);
  (v803_19).clone()
}

fn routine_44(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v816_21 = Space::new();
  let mut v816_21_cursor = (*s0).read_zipper();
  for v816_21_byte in v816_21_cursor.child_mask().iter() {
    v816_21_cursor.descend_to_byte(v816_21_byte);
    {
    let v816_21_tail = v816_21_cursor.fork_read_zipper();
    let v816_21_head = Path::from_slice(&[v816_21_byte]);
    let v817_2: Space = singleton(&(v816_21_head));
    let v817_3: Space = intersect(&(*CONSTANT_2),&(v817_2));
    let v817_4: Space = if has_head(&(v817_3)) { singleton(&[]) } else { Space::new() };
    drop(v817_3);
    let v817_5: Space = subtract(&(*CONSTANT_1),&(v817_4));
    drop(v817_4);
    let v817_8: Space = if (v817_5).is_empty() { Space::new() } else {
      let v818_6: Path = concat_path(&(*p0),&(v816_21_head));
      let mut v818_7 = Space::new();
      let mut v818_7_cursor = (v816_21_tail).read_zipper();
      for v818_7_byte in v818_7_cursor.child_mask().iter() {
        v818_7_cursor.descend_to_byte(v818_7_byte);
        {
        let v818_7_tail = v818_7_cursor.fork_read_zipper();
        let v818_7_head = Path::from_slice(&[v818_7_byte]);
        let v819_2: Space = singleton(&(v818_7_head));
        let v819_3: Space = intersect(&(*CONSTANT_2),&(v819_2));
        let v819_4: Space = if has_head(&(v819_3)) { singleton(&[]) } else { Space::new() };
        drop(v819_3);
        let v819_5: Space = subtract(&(*CONSTANT_1),&(v819_4));
        drop(v819_4);
        let v819_8: Space = if (v819_5).is_empty() { Space::new() } else {
          let v820_6: Path = concat_path(&(v818_6),&(v818_7_head));
          let mut v820_7 = Space::new();
          let mut v820_7_cursor = (v818_7_tail).read_zipper();
          for v820_7_byte in v820_7_cursor.child_mask().iter() {
            v820_7_cursor.descend_to_byte(v820_7_byte);
            {
            let v820_7_tail = v820_7_cursor.fork_read_zipper();
            let v820_7_head = Path::from_slice(&[v820_7_byte]);
            let v821_2: Space = singleton(&(v820_7_head));
            let v821_3: Space = intersect(&(*CONSTANT_2),&(v821_2));
            let v821_4: Space = if has_head(&(v821_3)) { singleton(&[]) } else { Space::new() };
            drop(v821_3);
            let v821_5: Space = subtract(&(*CONSTANT_1),&(v821_4));
            drop(v821_4);
            let v821_8: Space = if (v821_5).is_empty() { Space::new() } else {
              let v822_6: Path = concat_path(&(v820_6),&(v820_7_head));
              let v822_7: Space = routine_52(c, &(v822_6), &(*p1), &(v820_7_tail).make_space());
              compose(&(v821_5),&(v822_7))
            };
            drop(v821_5);
            let v821_9: Space = intersect(&(*CONSTANT_2),&(v821_2));
            drop(v821_2);
            let v821_10: Space = if has_head(&(v821_9)) { singleton(&[]) } else { Space::new() };
            drop(v821_9);
            let v821_12: Space = if (v821_10).is_empty() { Space::new() } else {
              let v823_6: Path = concat_path(&(v820_6),&(v820_7_head));
              let v823_11: Space = routine_53(c, &(v823_6), &(*p1), &(v820_7_tail).make_space());
              drop(v823_6);
              compose(&(v821_10),&(v823_11))
            };
            drop(v821_10);
            let v821_13: Space = unite(&(v821_8),&(v821_12));
            v820_7.join_into((v821_13).clone());
            }
            v820_7_cursor.ascend(1);
          }
          drop(v820_7_cursor);
          compose(&(v819_5),&(v820_7))
        };
        drop(v819_5);
        let v819_9: Space = intersect(&(*CONSTANT_2),&(v819_2));
        drop(v819_2);
        let v819_10: Space = if has_head(&(v819_9)) { singleton(&[]) } else { Space::new() };
        drop(v819_9);
        let v819_12: Space = if (v819_10).is_empty() { Space::new() } else {
          let v824_6: Path = concat_path(&(v818_6),&(v818_7_head));
          let mut v824_11 = Space::new();
          let mut v824_11_cursor = (v818_7_tail).read_zipper();
          for v824_11_byte in v824_11_cursor.child_mask().iter() {
            v824_11_cursor.descend_to_byte(v824_11_byte);
            {
            let v824_11_tail = v824_11_cursor.fork_read_zipper();
            let v824_11_head = Path::from_slice(&[v824_11_byte]);
            let v825_2: Space = singleton(&(v824_11_head));
            let v825_3: Space = intersect(&(*CONSTANT_2),&(v825_2));
            let v825_4: Space = if has_head(&(v825_3)) { singleton(&[]) } else { Space::new() };
            drop(v825_3);
            let v825_5: Space = subtract(&(*CONSTANT_1),&(v825_4));
            drop(v825_4);
            let v825_8: Space = if (v825_5).is_empty() { Space::new() } else {
              let v826_6: Path = concat_path(&(v824_6),&(v824_11_head));
              let v826_7: Space = routine_52(c, &(v826_6), &(*p1), &(v824_11_tail).make_space());
              compose(&(v825_5),&(v826_7))
            };
            drop(v825_5);
            let v825_9: Space = intersect(&(*CONSTANT_2),&(v825_2));
            drop(v825_2);
            let v825_10: Space = if has_head(&(v825_9)) { singleton(&[]) } else { Space::new() };
            drop(v825_9);
            let v825_12: Space = if (v825_10).is_empty() { Space::new() } else {
              let v827_6: Path = concat_path(&(v824_6),&(v824_11_head));
              let v827_11: Space = routine_19(c, &(v827_6), &(*p1), &(v824_11_tail).make_space());
              drop(v827_6);
              compose(&(v825_10),&(v827_11))
            };
            drop(v825_10);
            let v825_13: Space = unite(&(v825_8),&(v825_12));
            v824_11.join_into((v825_13).clone());
            }
            v824_11_cursor.ascend(1);
          }
          drop(v824_11_cursor);
          drop(v824_6);
          compose(&(v819_10),&(v824_11))
        };
        drop(v819_10);
        let v819_13: Space = unite(&(v819_8),&(v819_12));
        v818_7.join_into((v819_13).clone());
        }
        v818_7_cursor.ascend(1);
      }
      drop(v818_7_cursor);
      compose(&(v817_5),&(v818_7))
    };
    drop(v817_5);
    let v817_9: Space = intersect(&(*CONSTANT_2),&(v817_2));
    drop(v817_2);
    let v817_10: Space = if has_head(&(v817_9)) { singleton(&[]) } else { Space::new() };
    drop(v817_9);
    let v817_12: Space = if (v817_10).is_empty() { Space::new() } else {
      let v828_6: Path = concat_path(&(*p0),&(v816_21_head));
      let mut v828_11 = Space::new();
      let mut v828_11_cursor = (v816_21_tail).read_zipper();
      for v828_11_byte in v828_11_cursor.child_mask().iter() {
        v828_11_cursor.descend_to_byte(v828_11_byte);
        {
        let v828_11_tail = v828_11_cursor.fork_read_zipper();
        let v828_11_head = Path::from_slice(&[v828_11_byte]);
        let v829_2: Space = singleton(&(v828_11_head));
        let v829_3: Space = intersect(&(*CONSTANT_2),&(v829_2));
        let v829_4: Space = if has_head(&(v829_3)) { singleton(&[]) } else { Space::new() };
        drop(v829_3);
        let v829_5: Space = subtract(&(*CONSTANT_1),&(v829_4));
        drop(v829_4);
        let v829_8: Space = if (v829_5).is_empty() { Space::new() } else {
          let v830_6: Path = concat_path(&(v828_6),&(v828_11_head));
          let mut v830_7 = Space::new();
          let mut v830_7_cursor = (v828_11_tail).read_zipper();
          for v830_7_byte in v830_7_cursor.child_mask().iter() {
            v830_7_cursor.descend_to_byte(v830_7_byte);
            {
            let v830_7_tail = v830_7_cursor.fork_read_zipper();
            let v830_7_head = Path::from_slice(&[v830_7_byte]);
            let v831_2: Space = singleton(&(v830_7_head));
            let v831_3: Space = intersect(&(*CONSTANT_2),&(v831_2));
            let v831_4: Space = if has_head(&(v831_3)) { singleton(&[]) } else { Space::new() };
            drop(v831_3);
            let v831_5: Space = subtract(&(*CONSTANT_1),&(v831_4));
            drop(v831_4);
            let v831_8: Space = if (v831_5).is_empty() { Space::new() } else {
              let v832_6: Path = concat_path(&(v830_6),&(v830_7_head));
              let v832_7: Space = routine_52(c, &(v832_6), &(*p1), &(v830_7_tail).make_space());
              compose(&(v831_5),&(v832_7))
            };
            drop(v831_5);
            let v831_9: Space = intersect(&(*CONSTANT_2),&(v831_2));
            drop(v831_2);
            let v831_10: Space = if has_head(&(v831_9)) { singleton(&[]) } else { Space::new() };
            drop(v831_9);
            let v831_12: Space = if (v831_10).is_empty() { Space::new() } else {
              let v833_6: Path = concat_path(&(v830_6),&(v830_7_head));
              let v833_11: Space = routine_53(c, &(v833_6), &(*p1), &(v830_7_tail).make_space());
              drop(v833_6);
              compose(&(v831_10),&(v833_11))
            };
            drop(v831_10);
            let v831_13: Space = unite(&(v831_8),&(v831_12));
            v830_7.join_into((v831_13).clone());
            }
            v830_7_cursor.ascend(1);
          }
          drop(v830_7_cursor);
          compose(&(v829_5),&(v830_7))
        };
        drop(v829_5);
        let v829_9: Space = intersect(&(*CONSTANT_2),&(v829_2));
        drop(v829_2);
        let v829_10: Space = if has_head(&(v829_9)) { singleton(&[]) } else { Space::new() };
        drop(v829_9);
        let v829_11: Space = compose(&(v829_10),&(v828_11_tail));
        drop(v829_10);
        let v834_6: Path = concat_path(&(v828_6),&(v828_11_head));
        let v829_12: Space = wrap(&(v829_11),&(v834_6));
        drop(v829_11);
        let v829_13: Space = wrap(&(v829_12),&(*p1));
        drop(v829_12);
        let v829_14: Space = unite(&(v829_8),&(v829_13));
        drop(v829_13);
        v828_11.join_into((v829_14).clone());
        }
        v828_11_cursor.ascend(1);
      }
      drop(v828_11_cursor);
      drop(v828_6);
      compose(&(v817_10),&(v828_11))
    };
    drop(v817_10);
    let v817_13: Space = unite(&(v817_8),&(v817_12));
    v816_21.join_into((v817_13).clone());
    }
    v816_21_cursor.ascend(1);
  }
  drop(v816_21_cursor);
  (v816_21).clone()
}

fn routine_45(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v835_15 = Space::new();
  let mut v835_15_cursor = (*s0).read_zipper();
  for v835_15_byte in v835_15_cursor.child_mask().iter() {
    v835_15_cursor.descend_to_byte(v835_15_byte);
    {
    let v835_15_tail = v835_15_cursor.fork_read_zipper();
    let v835_15_head = Path::from_slice(&[v835_15_byte]);
    let v836_2: Space = singleton(&(v835_15_head));
    let v836_3: Space = intersect(&(*CONSTANT_2),&(v836_2));
    let v836_4: Space = if has_head(&(v836_3)) { singleton(&[]) } else { Space::new() };
    drop(v836_3);
    let v836_5: Space = subtract(&(*CONSTANT_1),&(v836_4));
    drop(v836_4);
    let v836_8: Space = if (v836_5).is_empty() { Space::new() } else {
      let v837_6: Path = concat_path(&(*p0),&(v835_15_head));
      let mut v837_7 = Space::new();
      let mut v837_7_cursor = (v835_15_tail).read_zipper();
      for v837_7_byte in v837_7_cursor.child_mask().iter() {
        v837_7_cursor.descend_to_byte(v837_7_byte);
        {
        let v837_7_tail = v837_7_cursor.fork_read_zipper();
        let v837_7_head = Path::from_slice(&[v837_7_byte]);
        let v838_2: Space = singleton(&(v837_7_head));
        let v838_3: Space = intersect(&(*CONSTANT_2),&(v838_2));
        let v838_4: Space = if has_head(&(v838_3)) { singleton(&[]) } else { Space::new() };
        drop(v838_3);
        let v838_5: Space = subtract(&(*CONSTANT_1),&(v838_4));
        drop(v838_4);
        let v838_8: Space = if (v838_5).is_empty() { Space::new() } else {
          let v839_6: Path = concat_path(&(v837_6),&(v837_7_head));
          let mut v839_7 = Space::new();
          let mut v839_7_cursor = (v837_7_tail).read_zipper();
          for v839_7_byte in v839_7_cursor.child_mask().iter() {
            v839_7_cursor.descend_to_byte(v839_7_byte);
            {
            let v839_7_tail = v839_7_cursor.fork_read_zipper();
            let v839_7_head = Path::from_slice(&[v839_7_byte]);
            let v840_2: Space = singleton(&(v839_7_head));
            let v840_3: Space = intersect(&(*CONSTANT_2),&(v840_2));
            let v840_4: Space = if has_head(&(v840_3)) { singleton(&[]) } else { Space::new() };
            drop(v840_3);
            let v840_5: Space = subtract(&(*CONSTANT_1),&(v840_4));
            drop(v840_4);
            let v840_8: Space = if (v840_5).is_empty() { Space::new() } else {
              let v841_6: Path = concat_path(&(v839_6),&(v839_7_head));
              let v841_7: Space = routine_52(c, &(v841_6), &(*p1), &(v839_7_tail).make_space());
              compose(&(v840_5),&(v841_7))
            };
            drop(v840_5);
            let v840_9: Space = intersect(&(*CONSTANT_2),&(v840_2));
            drop(v840_2);
            let v840_10: Space = if has_head(&(v840_9)) { singleton(&[]) } else { Space::new() };
            drop(v840_9);
            let v840_12: Space = if (v840_10).is_empty() { Space::new() } else {
              let v842_6: Path = concat_path(&(v839_6),&(v839_7_head));
              let v842_11: Space = routine_53(c, &(v842_6), &(*p1), &(v839_7_tail).make_space());
              drop(v842_6);
              compose(&(v840_10),&(v842_11))
            };
            drop(v840_10);
            let v840_13: Space = unite(&(v840_8),&(v840_12));
            v839_7.join_into((v840_13).clone());
            }
            v839_7_cursor.ascend(1);
          }
          drop(v839_7_cursor);
          compose(&(v838_5),&(v839_7))
        };
        drop(v838_5);
        let v838_9: Space = intersect(&(*CONSTANT_2),&(v838_2));
        drop(v838_2);
        let v838_10: Space = if has_head(&(v838_9)) { singleton(&[]) } else { Space::new() };
        drop(v838_9);
        let v838_12: Space = if (v838_10).is_empty() { Space::new() } else {
          let v843_6: Path = concat_path(&(v837_6),&(v837_7_head));
          let mut v843_11 = Space::new();
          let mut v843_11_cursor = (v837_7_tail).read_zipper();
          for v843_11_byte in v843_11_cursor.child_mask().iter() {
            v843_11_cursor.descend_to_byte(v843_11_byte);
            {
            let v843_11_tail = v843_11_cursor.fork_read_zipper();
            let v843_11_head = Path::from_slice(&[v843_11_byte]);
            let v844_2: Space = singleton(&(v843_11_head));
            let v844_3: Space = intersect(&(*CONSTANT_2),&(v844_2));
            let v844_4: Space = if has_head(&(v844_3)) { singleton(&[]) } else { Space::new() };
            drop(v844_3);
            let v844_5: Space = subtract(&(*CONSTANT_1),&(v844_4));
            drop(v844_4);
            let v844_8: Space = if (v844_5).is_empty() { Space::new() } else {
              let v845_6: Path = concat_path(&(v843_6),&(v843_11_head));
              let v845_7: Space = routine_52(c, &(v845_6), &(*p1), &(v843_11_tail).make_space());
              compose(&(v844_5),&(v845_7))
            };
            drop(v844_5);
            let v844_9: Space = intersect(&(*CONSTANT_2),&(v844_2));
            drop(v844_2);
            let v844_10: Space = if has_head(&(v844_9)) { singleton(&[]) } else { Space::new() };
            drop(v844_9);
            let v844_12: Space = if (v844_10).is_empty() { Space::new() } else {
              let v846_6: Path = concat_path(&(v843_6),&(v843_11_head));
              let v846_11: Space = routine_19(c, &(v846_6), &(*p1), &(v843_11_tail).make_space());
              drop(v846_6);
              compose(&(v844_10),&(v846_11))
            };
            drop(v844_10);
            let v844_13: Space = unite(&(v844_8),&(v844_12));
            v843_11.join_into((v844_13).clone());
            }
            v843_11_cursor.ascend(1);
          }
          drop(v843_11_cursor);
          drop(v843_6);
          compose(&(v838_10),&(v843_11))
        };
        drop(v838_10);
        let v838_13: Space = unite(&(v838_8),&(v838_12));
        v837_7.join_into((v838_13).clone());
        }
        v837_7_cursor.ascend(1);
      }
      drop(v837_7_cursor);
      compose(&(v836_5),&(v837_7))
    };
    drop(v836_5);
    let v836_9: Space = intersect(&(*CONSTANT_2),&(v836_2));
    drop(v836_2);
    let v836_10: Space = if has_head(&(v836_9)) { singleton(&[]) } else { Space::new() };
    drop(v836_9);
    let v836_11: Space = compose(&(v836_10),&(v835_15_tail));
    drop(v836_10);
    let v847_6: Path = concat_path(&(*p0),&(v835_15_head));
    let v836_12: Space = wrap(&(v836_11),&(v847_6));
    drop(v836_11);
    let v836_13: Space = wrap(&(v836_12),&(*p1));
    drop(v836_12);
    let v836_14: Space = unite(&(v836_8),&(v836_13));
    drop(v836_13);
    v835_15.join_into((v836_14).clone());
    }
    v835_15_cursor.ascend(1);
  }
  drop(v835_15_cursor);
  (v835_15).clone()
}

fn routine_46(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let mut v848_4 = Space::new();
  let mut v848_4_cursor = (*s0).read_zipper();
  for v848_4_byte in v848_4_cursor.child_mask().iter() {
    v848_4_cursor.descend_to_byte(v848_4_byte);
    {
    let v848_4_tail = v848_4_cursor.fork_read_zipper();
    let v848_4_head = Path::from_slice(&[v848_4_byte]);
    let v849_2: Space = Space::new();
    v848_4.join_into((v849_2).clone());
    }
    v848_4_cursor.ascend(1);
  }
  drop(v848_4_cursor);
  (v848_4).clone()
}

fn routine_47(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v850_6: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v850_7: Space = unwrap(&(v850_6),&(*p0));
  drop(v850_6);
  let mut v850_17 = Space::new();
  let mut v850_17_cursor = (*s0).read_zipper();
  for v850_17_byte in v850_17_cursor.child_mask().iter() {
    v850_17_cursor.descend_to_byte(v850_17_byte);
    {
    let v850_17_tail = v850_17_cursor.fork_read_zipper();
    let v850_17_head = Path::from_slice(&[v850_17_byte]);
    let v851_2: Space = singleton(&(v850_17_head));
    let v851_3: Space = intersect(&(*CONSTANT_2),&(v851_2));
    drop(v851_2);
    let v851_4: Space = if has_head(&(v851_3)) { singleton(&[]) } else { Space::new() };
    drop(v851_3);
    let v851_7: Space = if (v851_4).is_empty() { Space::new() } else {
      let v852_5: Space = unwrap(&(v850_7),&(v850_17_head));
      let mut v852_6 = Space::new();
      let mut v852_6_cursor = (v852_5).read_zipper();
      for v852_6_byte in v852_6_cursor.child_mask().iter() {
        v852_6_cursor.descend_to_byte(v852_6_byte);
        {
        let v852_6_tail = v852_6_cursor.fork_read_zipper();
        let v852_6_head = Path::from_slice(&[v852_6_byte]);
        let v853_2: Space = singleton(&(v852_6_head));
        let v853_3: Space = intersect(&(*CONSTANT_2),&(v853_2));
        let v853_4: Space = if has_head(&(v853_3)) { singleton(&[]) } else { Space::new() };
        drop(v853_3);
        let v853_5: Space = subtract(&(*CONSTANT_1),&(v853_4));
        drop(v853_4);
        let v853_7: Space = if (v853_5).is_empty() { Space::new() } else {
          let mut v854_6 = Space::new();
          let mut v854_6_cursor = (v852_6_tail).read_zipper();
          for v854_6_byte in v854_6_cursor.child_mask().iter() {
            v854_6_cursor.descend_to_byte(v854_6_byte);
            {
            let v854_6_tail = v854_6_cursor.fork_read_zipper();
            let v854_6_head = Path::from_slice(&[v854_6_byte]);
            let v855_2: Space = singleton(&(v854_6_head));
            let v855_3: Space = intersect(&(*CONSTANT_2),&(v855_2));
            let v855_4: Space = if has_head(&(v855_3)) { singleton(&[]) } else { Space::new() };
            drop(v855_3);
            let v855_5: Space = subtract(&(*CONSTANT_1),&(v855_4));
            drop(v855_4);
            let v855_8: Space = if (v855_5).is_empty() { Space::new() } else {
              let v856_6: Path = concat_path(&(v852_6_head),&(v854_6_head));
              let v856_7: Space = routine_17(c, &(v856_6), &(*p1), &(v854_6_tail).make_space());
              compose(&(v855_5),&(v856_7))
            };
            drop(v855_5);
            let v855_9: Space = intersect(&(*CONSTANT_2),&(v855_2));
            drop(v855_2);
            let v855_10: Space = if has_head(&(v855_9)) { singleton(&[]) } else { Space::new() };
            drop(v855_9);
            let v855_12: Space = if (v855_10).is_empty() { Space::new() } else {
              let v857_6: Path = concat_path(&(v852_6_head),&(v854_6_head));
              let v857_11: Space = routine_18(c, &(v857_6), &(*p1), &(v854_6_tail).make_space());
              drop(v857_6);
              compose(&(v855_10),&(v857_11))
            };
            drop(v855_10);
            let v855_13: Space = unite(&(v855_8),&(v855_12));
            v854_6.join_into((v855_13).clone());
            }
            v854_6_cursor.ascend(1);
          }
          drop(v854_6_cursor);
          compose(&(v853_5),&(v854_6))
        };
        drop(v853_5);
        let v853_8: Space = intersect(&(*CONSTANT_2),&(v853_2));
        drop(v853_2);
        let v853_9: Space = if has_head(&(v853_8)) { singleton(&[]) } else { Space::new() };
        drop(v853_8);
        let v853_11: Space = if (v853_9).is_empty() { Space::new() } else {
          let mut v858_10 = Space::new();
          let mut v858_10_cursor = (v852_6_tail).read_zipper();
          for v858_10_byte in v858_10_cursor.child_mask().iter() {
            v858_10_cursor.descend_to_byte(v858_10_byte);
            {
            let v858_10_tail = v858_10_cursor.fork_read_zipper();
            let v858_10_head = Path::from_slice(&[v858_10_byte]);
            let v859_2: Space = singleton(&(v858_10_head));
            let v859_3: Space = intersect(&(*CONSTANT_2),&(v859_2));
            let v859_4: Space = if has_head(&(v859_3)) { singleton(&[]) } else { Space::new() };
            drop(v859_3);
            let v859_5: Space = subtract(&(*CONSTANT_1),&(v859_4));
            drop(v859_4);
            let v859_8: Space = if (v859_5).is_empty() { Space::new() } else {
              let v860_6: Path = concat_path(&(v852_6_head),&(v858_10_head));
              let v860_7: Space = routine_17(c, &(v860_6), &(*p1), &(v858_10_tail).make_space());
              compose(&(v859_5),&(v860_7))
            };
            drop(v859_5);
            let v859_9: Space = intersect(&(*CONSTANT_2),&(v859_2));
            drop(v859_2);
            let v859_10: Space = if has_head(&(v859_9)) { singleton(&[]) } else { Space::new() };
            drop(v859_9);
            let v859_12: Space = if (v859_10).is_empty() { Space::new() } else {
              let v861_6: Path = concat_path(&(v852_6_head),&(v858_10_head));
              let v861_11: Space = routine_19(c, &(v861_6), &(*p1), &(v858_10_tail).make_space());
              drop(v861_6);
              compose(&(v859_10),&(v861_11))
            };
            drop(v859_10);
            let v859_13: Space = unite(&(v859_8),&(v859_12));
            v858_10.join_into((v859_13).clone());
            }
            v858_10_cursor.ascend(1);
          }
          drop(v858_10_cursor);
          compose(&(v853_9),&(v858_10))
        };
        drop(v853_9);
        let v853_12: Space = unite(&(v853_7),&(v853_11));
        v852_6.join_into((v853_12).clone());
        }
        v852_6_cursor.ascend(1);
      }
      drop(v852_6_cursor);
      drop(v852_5);
      compose(&(v851_4),&(v852_6))
    };
    drop(v851_4);
    v850_17.join_into((v851_7).clone());
    }
    v850_17_cursor.ascend(1);
  }
  drop(v850_17_cursor);
  drop(v850_7);
  (v850_17).clone()
}

fn routine_48(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v862_13 = Space::new();
  let mut v862_13_cursor = (*s0).read_zipper();
  for v862_13_byte in v862_13_cursor.child_mask().iter() {
    v862_13_cursor.descend_to_byte(v862_13_byte);
    {
    let v862_13_tail = v862_13_cursor.fork_read_zipper();
    let v862_13_head = Path::from_slice(&[v862_13_byte]);
    let v863_2: Space = singleton(&(v862_13_head));
    let v863_3: Space = intersect(&(*CONSTANT_2),&(v863_2));
    let v863_4: Space = if has_head(&(v863_3)) { singleton(&[]) } else { Space::new() };
    drop(v863_3);
    let v863_5: Space = subtract(&(*CONSTANT_1),&(v863_4));
    drop(v863_4);
    let v863_8: Space = if (v863_5).is_empty() { Space::new() } else {
      let v864_6: Path = concat_path(&(*p0),&(v862_13_head));
      let mut v864_7 = Space::new();
      let mut v864_7_cursor = (v862_13_tail).read_zipper();
      for v864_7_byte in v864_7_cursor.child_mask().iter() {
        v864_7_cursor.descend_to_byte(v864_7_byte);
        {
        let v864_7_tail = v864_7_cursor.fork_read_zipper();
        let v864_7_head = Path::from_slice(&[v864_7_byte]);
        let v865_2: Space = singleton(&(v864_7_head));
        let v865_3: Space = intersect(&(*CONSTANT_2),&(v865_2));
        let v865_4: Space = if has_head(&(v865_3)) { singleton(&[]) } else { Space::new() };
        drop(v865_3);
        let v865_5: Space = subtract(&(*CONSTANT_1),&(v865_4));
        drop(v865_4);
        let mut v865_6 = Space::new();
        let mut v865_6_cursor = (v864_7_tail).read_zipper();
        for v865_6_byte in v865_6_cursor.child_mask().iter() {
          v865_6_cursor.descend_to_byte(v865_6_byte);
          {
          let v865_6_tail = v865_6_cursor.fork_read_zipper();
          let v865_6_head = Path::from_slice(&[v865_6_byte]);
          let v866_2: Space = Space::new();
          v865_6.join_into((v866_2).clone());
          }
          v865_6_cursor.ascend(1);
        }
        drop(v865_6_cursor);
        let v865_7: Space = compose(&(v865_5),&(v865_6));
        drop(v865_5);
        drop(v865_6);
        let v865_8: Space = intersect(&(*CONSTANT_2),&(v865_2));
        drop(v865_2);
        let v865_9: Space = if has_head(&(v865_8)) { singleton(&[]) } else { Space::new() };
        drop(v865_8);
        let v865_12: Space = if (v865_9).is_empty() { Space::new() } else {
          let v867_10: Path = concat_path(&(v864_6),&(v864_7_head));
          let mut v867_11 = Space::new();
          let mut v867_11_cursor = (v864_7_tail).read_zipper();
          for v867_11_byte in v867_11_cursor.child_mask().iter() {
            v867_11_cursor.descend_to_byte(v867_11_byte);
            {
            let v867_11_tail = v867_11_cursor.fork_read_zipper();
            let v867_11_head = Path::from_slice(&[v867_11_byte]);
            let v868_2: Space = singleton(&(v867_11_head));
            let v868_3: Space = intersect(&(*CONSTANT_2),&(v868_2));
            drop(v868_2);
            let v868_4: Space = if has_head(&(v868_3)) { singleton(&[]) } else { Space::new() };
            drop(v868_3);
            let v868_7: Space = if (v868_4).is_empty() { Space::new() } else {
              let v869_5: Path = concat_path(&(v867_10),&(v867_11_head));
              let v869_6: Space = routine_19(c, &(v869_5), &(*p1), &(v867_11_tail).make_space());
              drop(v869_5);
              compose(&(v868_4),&(v869_6))
            };
            drop(v868_4);
            v867_11.join_into((v868_7).clone());
            }
            v867_11_cursor.ascend(1);
          }
          drop(v867_11_cursor);
          drop(v867_10);
          compose(&(v865_9),&(v867_11))
        };
        drop(v865_9);
        let v865_13: Space = unite(&(v865_7),&(v865_12));
        drop(v865_7);
        v864_7.join_into((v865_13).clone());
        }
        v864_7_cursor.ascend(1);
      }
      drop(v864_7_cursor);
      compose(&(v863_5),&(v864_7))
    };
    drop(v863_5);
    let v863_9: Space = intersect(&(*CONSTANT_2),&(v863_2));
    drop(v863_2);
    let v863_10: Space = if has_head(&(v863_9)) { singleton(&[]) } else { Space::new() };
    drop(v863_9);
    let v863_12: Space = if (v863_10).is_empty() { Space::new() } else {
      let v870_6: Path = concat_path(&(*p0),&(v862_13_head));
      let mut v870_11 = Space::new();
      let mut v870_11_cursor = (v862_13_tail).read_zipper();
      for v870_11_byte in v870_11_cursor.child_mask().iter() {
        v870_11_cursor.descend_to_byte(v870_11_byte);
        {
        let v870_11_tail = v870_11_cursor.fork_read_zipper();
        let v870_11_head = Path::from_slice(&[v870_11_byte]);
        let v871_2: Space = singleton(&(v870_11_head));
        let v871_3: Space = intersect(&(*CONSTANT_2),&(v871_2));
        let v871_4: Space = if has_head(&(v871_3)) { singleton(&[]) } else { Space::new() };
        drop(v871_3);
        let v871_5: Space = subtract(&(*CONSTANT_1),&(v871_4));
        drop(v871_4);
        let mut v871_6 = Space::new();
        let mut v871_6_cursor = (v870_11_tail).read_zipper();
        for v871_6_byte in v871_6_cursor.child_mask().iter() {
          v871_6_cursor.descend_to_byte(v871_6_byte);
          {
          let v871_6_tail = v871_6_cursor.fork_read_zipper();
          let v871_6_head = Path::from_slice(&[v871_6_byte]);
          let v872_2: Space = Space::new();
          v871_6.join_into((v872_2).clone());
          }
          v871_6_cursor.ascend(1);
        }
        drop(v871_6_cursor);
        let v871_7: Space = compose(&(v871_5),&(v871_6));
        drop(v871_5);
        drop(v871_6);
        let v871_8: Space = intersect(&(*CONSTANT_2),&(v871_2));
        drop(v871_2);
        let v871_9: Space = if has_head(&(v871_8)) { singleton(&[]) } else { Space::new() };
        drop(v871_8);
        let v871_10: Space = compose(&(v871_9),&(v870_11_tail));
        drop(v871_9);
        let v871_11: Path = concat_path(&(v870_6),&(v870_11_head));
        let v871_12: Space = wrap(&(v871_10),&(v871_11));
        drop(v871_10);
        drop(v871_11);
        let v871_13: Space = wrap(&(v871_12),&(*p1));
        drop(v871_12);
        let v871_14: Space = unite(&(v871_7),&(v871_13));
        drop(v871_7);
        drop(v871_13);
        v870_11.join_into((v871_14).clone());
        }
        v870_11_cursor.ascend(1);
      }
      drop(v870_11_cursor);
      drop(v870_6);
      compose(&(v863_10),&(v870_11))
    };
    drop(v863_10);
    let v863_13: Space = unite(&(v863_8),&(v863_12));
    drop(v863_12);
    v862_13.join_into((v863_13).clone());
    }
    v862_13_cursor.ascend(1);
  }
  drop(v862_13_cursor);
  (v862_13).clone()
}

fn routine_49(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v873_10 = Space::new();
  let mut v873_10_cursor = (*s0).read_zipper();
  for v873_10_byte in v873_10_cursor.child_mask().iter() {
    v873_10_cursor.descend_to_byte(v873_10_byte);
    {
    let v873_10_tail = v873_10_cursor.fork_read_zipper();
    let v873_10_head = Path::from_slice(&[v873_10_byte]);
    let v874_2: Space = singleton(&(v873_10_head));
    let v874_3: Space = intersect(&(*CONSTANT_2),&(v874_2));
    let v874_4: Space = if has_head(&(v874_3)) { singleton(&[]) } else { Space::new() };
    drop(v874_3);
    let v874_5: Space = subtract(&(*CONSTANT_1),&(v874_4));
    drop(v874_4);
    let v874_8: Space = if (v874_5).is_empty() { Space::new() } else {
      let v875_6: Path = concat_path(&(*p0),&(v873_10_head));
      let mut v875_7 = Space::new();
      let mut v875_7_cursor = (v873_10_tail).read_zipper();
      for v875_7_byte in v875_7_cursor.child_mask().iter() {
        v875_7_cursor.descend_to_byte(v875_7_byte);
        {
        let v875_7_tail = v875_7_cursor.fork_read_zipper();
        let v875_7_head = Path::from_slice(&[v875_7_byte]);
        let v876_2: Space = singleton(&(v875_7_head));
        let v876_3: Space = intersect(&(*CONSTANT_2),&(v876_2));
        let v876_4: Space = if has_head(&(v876_3)) { singleton(&[]) } else { Space::new() };
        drop(v876_3);
        let v876_5: Space = subtract(&(*CONSTANT_1),&(v876_4));
        drop(v876_4);
        let mut v876_6 = Space::new();
        let mut v876_6_cursor = (v875_7_tail).read_zipper();
        for v876_6_byte in v876_6_cursor.child_mask().iter() {
          v876_6_cursor.descend_to_byte(v876_6_byte);
          {
          let v876_6_tail = v876_6_cursor.fork_read_zipper();
          let v876_6_head = Path::from_slice(&[v876_6_byte]);
          let v877_2: Space = Space::new();
          v876_6.join_into((v877_2).clone());
          }
          v876_6_cursor.ascend(1);
        }
        drop(v876_6_cursor);
        let v876_7: Space = compose(&(v876_5),&(v876_6));
        drop(v876_5);
        drop(v876_6);
        let v876_8: Space = intersect(&(*CONSTANT_2),&(v876_2));
        drop(v876_2);
        let v876_9: Space = if has_head(&(v876_8)) { singleton(&[]) } else { Space::new() };
        drop(v876_8);
        let v876_12: Space = if (v876_9).is_empty() { Space::new() } else {
          let v878_10: Path = concat_path(&(v875_6),&(v875_7_head));
          let mut v878_11 = Space::new();
          let mut v878_11_cursor = (v875_7_tail).read_zipper();
          for v878_11_byte in v878_11_cursor.child_mask().iter() {
            v878_11_cursor.descend_to_byte(v878_11_byte);
            {
            let v878_11_tail = v878_11_cursor.fork_read_zipper();
            let v878_11_head = Path::from_slice(&[v878_11_byte]);
            let v879_2: Space = singleton(&(v878_11_head));
            let v879_3: Space = intersect(&(*CONSTANT_2),&(v879_2));
            drop(v879_2);
            let v879_4: Space = if has_head(&(v879_3)) { singleton(&[]) } else { Space::new() };
            drop(v879_3);
            let v879_7: Space = if (v879_4).is_empty() { Space::new() } else {
              let v880_5: Path = concat_path(&(v878_10),&(v878_11_head));
              let v880_6: Space = routine_19(c, &(v880_5), &(*p1), &(v878_11_tail).make_space());
              drop(v880_5);
              compose(&(v879_4),&(v880_6))
            };
            drop(v879_4);
            v878_11.join_into((v879_7).clone());
            }
            v878_11_cursor.ascend(1);
          }
          drop(v878_11_cursor);
          drop(v878_10);
          compose(&(v876_9),&(v878_11))
        };
        drop(v876_9);
        let v876_13: Space = unite(&(v876_7),&(v876_12));
        drop(v876_7);
        v875_7.join_into((v876_13).clone());
        }
        v875_7_cursor.ascend(1);
      }
      drop(v875_7_cursor);
      compose(&(v874_5),&(v875_7))
    };
    drop(v874_5);
    let v874_9: Space = intersect(&(*CONSTANT_2),&(v874_2));
    drop(v874_2);
    let v874_10: Space = if has_head(&(v874_9)) { singleton(&[]) } else { Space::new() };
    drop(v874_9);
    let v874_11: Space = compose(&(v874_10),&(v873_10_tail));
    drop(v874_10);
    let v881_6: Path = concat_path(&(*p0),&(v873_10_head));
    let v874_12: Space = wrap(&(v874_11),&(v881_6));
    drop(v874_11);
    let v874_13: Space = wrap(&(v874_12),&(*p1));
    drop(v874_12);
    let v874_14: Space = unite(&(v874_8),&(v874_13));
    drop(v874_13);
    v873_10.join_into((v874_14).clone());
    }
    v873_10_cursor.ascend(1);
  }
  drop(v873_10_cursor);
  (v873_10).clone()
}

fn routine_50(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v882_7 = Space::new();
  let mut v882_7_cursor = (*s0).read_zipper();
  for v882_7_byte in v882_7_cursor.child_mask().iter() {
    v882_7_cursor.descend_to_byte(v882_7_byte);
    {
    let v882_7_tail = v882_7_cursor.fork_read_zipper();
    let v882_7_head = Path::from_slice(&[v882_7_byte]);
    let v883_2: Space = singleton(&(v882_7_head));
    let v883_3: Space = intersect(&(*CONSTANT_2),&(v883_2));
    let v883_4: Space = if has_head(&(v883_3)) { singleton(&[]) } else { Space::new() };
    drop(v883_3);
    let v883_5: Space = subtract(&(*CONSTANT_1),&(v883_4));
    drop(v883_4);
    let mut v883_6 = Space::new();
    let mut v883_6_cursor = (v882_7_tail).read_zipper();
    for v883_6_byte in v883_6_cursor.child_mask().iter() {
      v883_6_cursor.descend_to_byte(v883_6_byte);
      {
      let v883_6_tail = v883_6_cursor.fork_read_zipper();
      let v883_6_head = Path::from_slice(&[v883_6_byte]);
      let v884_2: Space = Space::new();
      v883_6.join_into((v884_2).clone());
      }
      v883_6_cursor.ascend(1);
    }
    drop(v883_6_cursor);
    let v883_7: Space = compose(&(v883_5),&(v883_6));
    drop(v883_5);
    drop(v883_6);
    let v883_8: Space = intersect(&(*CONSTANT_2),&(v883_2));
    drop(v883_2);
    let v883_9: Space = if has_head(&(v883_8)) { singleton(&[]) } else { Space::new() };
    drop(v883_8);
    let v883_12: Space = if (v883_9).is_empty() { Space::new() } else {
      let v885_10: Path = concat_path(&(*p0),&(v882_7_head));
      let mut v885_11 = Space::new();
      let mut v885_11_cursor = (v882_7_tail).read_zipper();
      for v885_11_byte in v885_11_cursor.child_mask().iter() {
        v885_11_cursor.descend_to_byte(v885_11_byte);
        {
        let v885_11_tail = v885_11_cursor.fork_read_zipper();
        let v885_11_head = Path::from_slice(&[v885_11_byte]);
        let v886_2: Space = singleton(&(v885_11_head));
        let v886_3: Space = intersect(&(*CONSTANT_2),&(v886_2));
        drop(v886_2);
        let v886_4: Space = if has_head(&(v886_3)) { singleton(&[]) } else { Space::new() };
        drop(v886_3);
        let v886_5: Space = compose(&(v886_4),&(v885_11_tail));
        drop(v886_4);
        let v886_6: Path = concat_path(&(v885_10),&(v885_11_head));
        let v886_7: Space = wrap(&(v886_5),&(v886_6));
        drop(v886_5);
        drop(v886_6);
        v885_11.join_into((v886_7).clone());
        }
        v885_11_cursor.ascend(1);
      }
      drop(v885_11_cursor);
      drop(v885_10);
      compose(&(v883_9),&(v885_11))
    };
    drop(v883_9);
    let v883_13: Space = wrap(&(v883_12),&(*p1));
    drop(v883_12);
    let v883_14: Space = unite(&(v883_7),&(v883_13));
    drop(v883_7);
    drop(v883_13);
    v882_7.join_into((v883_14).clone());
    }
    v882_7_cursor.ascend(1);
  }
  drop(v882_7_cursor);
  (v882_7).clone()
}

fn routine_51(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v887_6 = Space::new();
  let mut v887_6_cursor = (*s0).read_zipper();
  for v887_6_byte in v887_6_cursor.child_mask().iter() {
    v887_6_cursor.descend_to_byte(v887_6_byte);
    {
    let v887_6_tail = v887_6_cursor.fork_read_zipper();
    let v887_6_head = Path::from_slice(&[v887_6_byte]);
    let v888_2: Space = singleton(&(v887_6_head));
    let v888_3: Space = intersect(&(*CONSTANT_2),&(v888_2));
    let v888_4: Space = if has_head(&(v888_3)) { singleton(&[]) } else { Space::new() };
    drop(v888_3);
    let v888_5: Space = subtract(&(*CONSTANT_1),&(v888_4));
    drop(v888_4);
    let mut v888_6 = Space::new();
    let mut v888_6_cursor = (v887_6_tail).read_zipper();
    for v888_6_byte in v888_6_cursor.child_mask().iter() {
      v888_6_cursor.descend_to_byte(v888_6_byte);
      {
      let v888_6_tail = v888_6_cursor.fork_read_zipper();
      let v888_6_head = Path::from_slice(&[v888_6_byte]);
      let v889_2: Space = Space::new();
      v888_6.join_into((v889_2).clone());
      }
      v888_6_cursor.ascend(1);
    }
    drop(v888_6_cursor);
    let v888_7: Space = compose(&(v888_5),&(v888_6));
    drop(v888_5);
    drop(v888_6);
    let v888_8: Space = intersect(&(*CONSTANT_2),&(v888_2));
    drop(v888_2);
    let v888_9: Space = if has_head(&(v888_8)) { singleton(&[]) } else { Space::new() };
    drop(v888_8);
    let v888_10: Space = compose(&(v888_9),&(v887_6_tail));
    drop(v888_9);
    let v888_11: Path = concat_path(&(*p0),&(v887_6_head));
    let v888_12: Space = wrap(&(v888_10),&(v888_11));
    drop(v888_10);
    drop(v888_11);
    let v888_13: Space = wrap(&(v888_12),&(*p1));
    drop(v888_12);
    let v888_14: Space = unite(&(v888_7),&(v888_13));
    drop(v888_7);
    drop(v888_13);
    v887_6.join_into((v888_14).clone());
    }
    v887_6_cursor.ascend(1);
  }
  drop(v887_6_cursor);
  (v887_6).clone()
}

fn routine_52(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v890_3 = Space::new();
  let mut v890_3_cursor = (*s0).read_zipper();
  for v890_3_byte in v890_3_cursor.child_mask().iter() {
    v890_3_cursor.descend_to_byte(v890_3_byte);
    {
    let v890_3_tail = v890_3_cursor.fork_read_zipper();
    let v890_3_head = Path::from_slice(&[v890_3_byte]);
    let v891_2: Space = Space::new();
    v890_3.join_into((v891_2).clone());
    }
    v890_3_cursor.ascend(1);
  }
  drop(v890_3_cursor);
  (v890_3).clone()
}

fn routine_53(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v892_4 = Space::new();
  let mut v892_4_cursor = (*s0).read_zipper();
  for v892_4_byte in v892_4_cursor.child_mask().iter() {
    v892_4_cursor.descend_to_byte(v892_4_byte);
    {
    let v892_4_tail = v892_4_cursor.fork_read_zipper();
    let v892_4_head = Path::from_slice(&[v892_4_byte]);
    let v893_2: Space = singleton(&(v892_4_head));
    let v893_3: Space = intersect(&(*CONSTANT_2),&(v893_2));
    drop(v893_2);
    let v893_4: Space = if has_head(&(v893_3)) { singleton(&[]) } else { Space::new() };
    drop(v893_3);
    let v893_5: Space = compose(&(v893_4),&(v892_4_tail));
    drop(v893_4);
    let v893_6: Path = concat_path(&(*p0),&(v892_4_head));
    let v893_7: Space = wrap(&(v893_5),&(v893_6));
    drop(v893_5);
    drop(v893_6);
    v892_4.join_into((v893_7).clone());
    }
    v892_4_cursor.ascend(1);
  }
  drop(v892_4_cursor);
  let v892_5: Space = wrap(&(v892_4),&(*p1));
  drop(v892_4);
  (v892_5).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
