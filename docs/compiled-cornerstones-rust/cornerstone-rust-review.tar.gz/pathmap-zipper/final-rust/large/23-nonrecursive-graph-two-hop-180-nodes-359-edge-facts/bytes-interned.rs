#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,182]));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_3 = Space::new();
  let mut v0_3_cursor = (v0_2).read_zipper();
  for v0_3_byte in v0_3_cursor.child_mask().iter() {
    v0_3_cursor.descend_to_byte(v0_3_byte);
    {
    let v0_3_tail = v0_3_cursor.fork_read_zipper();
    let v0_3_head = Path::from_slice(&[v0_3_byte]);
    let mut v1_2 = Space::new();
    let mut v1_2_cursor = (v0_3_tail).read_zipper();
    for v1_2_byte in v1_2_cursor.child_mask().iter() {
      v1_2_cursor.descend_to_byte(v1_2_byte);
      {
      let v1_2_tail = v1_2_cursor.fork_read_zipper();
      let v1_2_head = Path::from_slice(&[v1_2_byte]);
      let v2_2: Path = concat_path(&(v0_3_head),&(v1_2_head));
      let mut v2_3 = Space::new();
      let mut v2_3_cursor = (v1_2_tail).read_zipper();
      for v2_3_byte in v2_3_cursor.child_mask().iter() {
        v2_3_cursor.descend_to_byte(v2_3_byte);
        {
        let v2_3_tail = v2_3_cursor.fork_read_zipper();
        let v2_3_head = Path::from_slice(&[v2_3_byte]);
        let v3_2: Path = concat_path(&(v2_2),&(v2_3_head));
        let mut v3_3 = Space::new();
        let mut v3_3_cursor = (v2_3_tail).read_zipper();
        for v3_3_byte in v3_3_cursor.child_mask().iter() {
          v3_3_cursor.descend_to_byte(v3_3_byte);
          {
          let v3_3_tail = v3_3_cursor.fork_read_zipper();
          let v3_3_head = Path::from_slice(&[v3_3_byte]);
          let v4_2: Path = concat_path(&(v3_2),&(v3_3_head));
          let mut v4_3 = Space::new();
          let mut v4_3_cursor = (v3_3_tail).read_zipper();
          for v4_3_byte in v4_3_cursor.child_mask().iter() {
            v4_3_cursor.descend_to_byte(v4_3_byte);
            {
            let v4_3_tail = v4_3_cursor.fork_read_zipper();
            let v4_3_head = Path::from_slice(&[v4_3_byte]);
            let mut v5_2 = Space::new();
            let mut v5_2_cursor = (v4_3_tail).read_zipper();
            for v5_2_byte in v5_2_cursor.child_mask().iter() {
              v5_2_cursor.descend_to_byte(v5_2_byte);
              {
              let v5_2_tail = v5_2_cursor.fork_read_zipper();
              let v5_2_head = Path::from_slice(&[v5_2_byte]);
              let v6_2: Path = concat_path(&(v4_3_head),&(v5_2_head));
              let mut v6_3 = Space::new();
              let mut v6_3_cursor = (v5_2_tail).read_zipper();
              for v6_3_byte in v6_3_cursor.child_mask().iter() {
                v6_3_cursor.descend_to_byte(v6_3_byte);
                {
                let v6_3_tail = v6_3_cursor.fork_read_zipper();
                let v6_3_head = Path::from_slice(&[v6_3_byte]);
                let v7_2: Path = concat_path(&(v6_2),&(v6_3_head));
                let mut v7_3 = Space::new();
                let mut v7_3_cursor = (v6_3_tail).read_zipper();
                for v7_3_byte in v7_3_cursor.child_mask().iter() {
                  v7_3_cursor.descend_to_byte(v7_3_byte);
                  {
                  let v7_3_tail = v7_3_cursor.fork_read_zipper();
                  let v7_3_head = Path::from_slice(&[v7_3_byte]);
                  let v8_2: Path = concat_path(&(v7_2),&(v7_3_head));
                  let v8_3: Space = routine_1(c, &(v8_2), &(v4_2), &(v7_3_tail).make_space(), &(*s0.expect("unbound native input")));
                  drop(v8_2);
                  v7_3.join_into((v8_3).clone());
                  }
                  v7_3_cursor.ascend(1);
                }
                drop(v7_3_cursor);
                drop(v7_2);
                v6_3.join_into((v7_3).clone());
                }
                v6_3_cursor.ascend(1);
              }
              drop(v6_3_cursor);
              drop(v6_2);
              v5_2.join_into((v6_3).clone());
              }
              v5_2_cursor.ascend(1);
            }
            drop(v5_2_cursor);
            v4_3.join_into((v5_2).clone());
            }
            v4_3_cursor.ascend(1);
          }
          drop(v4_3_cursor);
          drop(v4_2);
          v3_3.join_into((v4_3).clone());
          }
          v3_3_cursor.ascend(1);
        }
        drop(v3_3_cursor);
        drop(v3_2);
        v2_3.join_into((v3_3).clone());
        }
        v2_3_cursor.ascend(1);
      }
      drop(v2_3_cursor);
      drop(v2_2);
      v1_2.join_into((v2_3).clone());
      }
      v1_2_cursor.ascend(1);
    }
    drop(v1_2_cursor);
    v0_3.join_into((v1_2).clone());
    }
    v0_3_cursor.ascend(1);
  }
  drop(v0_3_cursor);
  drop(v0_2);
  let v0_5: Space = wrap(&(v0_3),&(*CONSTANT_1));
  (v0_5).clone()
}

fn routine_1(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v9_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v9_6: Space = unwrap(&(v9_5),&(*p0));
  drop(v9_5);
  let mut v9_8 = Space::new();
  let mut v9_8_cursor = (v9_6).read_zipper();
  for v9_8_byte in v9_8_cursor.child_mask().iter() {
    v9_8_cursor.descend_to_byte(v9_8_byte);
    {
    let v9_8_tail = v9_8_cursor.fork_read_zipper();
    let v9_8_head = Path::from_slice(&[v9_8_byte]);
    let mut v10_2 = Space::new();
    let mut v10_2_cursor = (v9_8_tail).read_zipper();
    for v10_2_byte in v10_2_cursor.child_mask().iter() {
      v10_2_cursor.descend_to_byte(v10_2_byte);
      {
      let v10_2_tail = v10_2_cursor.fork_read_zipper();
      let v10_2_head = Path::from_slice(&[v10_2_byte]);
      let v11_2: Path = concat_path(&(v9_8_head),&(v10_2_head));
      let mut v11_3 = Space::new();
      let mut v11_3_cursor = (v10_2_tail).read_zipper();
      for v11_3_byte in v11_3_cursor.child_mask().iter() {
        v11_3_cursor.descend_to_byte(v11_3_byte);
        {
        let v11_3_tail = v11_3_cursor.fork_read_zipper();
        let v11_3_head = Path::from_slice(&[v11_3_byte]);
        let v12_2: Space = subtract(&(v11_3_tail),&(*CONSTANT_2));
        let v12_3: Path = concat_path(&(v11_2),&(v11_3_head));
        let v12_4: Space = wrap(&(v12_2),&(v12_3));
        drop(v12_2);
        drop(v12_3);
        v11_3.join_into((v12_4).clone());
        }
        v11_3_cursor.ascend(1);
      }
      drop(v11_3_cursor);
      drop(v11_2);
      v10_2.join_into((v11_3).clone());
      }
      v10_2_cursor.ascend(1);
    }
    drop(v10_2_cursor);
    v9_8.join_into((v10_2).clone());
    }
    v9_8_cursor.ascend(1);
  }
  drop(v9_8_cursor);
  drop(v9_6);
  let v9_9: Space = wrap(&(v9_8),&(*p1));
  drop(v9_8);
  (v9_9).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
