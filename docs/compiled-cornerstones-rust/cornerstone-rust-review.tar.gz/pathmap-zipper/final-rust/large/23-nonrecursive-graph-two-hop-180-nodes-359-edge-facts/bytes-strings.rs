#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[101,100,103,101,0]));
static CONSTANT_1: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
static CONSTANT_2: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 1 0"));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[84,119,111,72,111,112,0]));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_18 = Space::new();
  let mut v0_18_cursor = (v0_2).read_zipper();
  for v0_18_byte in v0_18_cursor.child_mask().iter() {
    v0_18_cursor.descend_to_byte(v0_18_byte);
    {
    let v0_18_tail = v0_18_cursor.fork_read_zipper();
    let v0_18_head = Path::from_slice(&[v0_18_byte]);
    let v1_2: Space = singleton(&(v0_18_head));
    let v1_3: Space = intersect(&(*CONSTANT_2),&(v1_2));
    let v1_4: Space = if has_head(&(v1_3)) { singleton(&[]) } else { Space::new() };
    drop(v1_3);
    let v1_5: Space = subtract(&(*CONSTANT_1),&(v1_4));
    drop(v1_4);
    let v1_7: Space = if (v1_5).is_empty() { Space::new() } else {
      let mut v2_6 = Space::new();
      let mut v2_6_cursor = (v0_18_tail).read_zipper();
      for v2_6_byte in v2_6_cursor.child_mask().iter() {
        v2_6_cursor.descend_to_byte(v2_6_byte);
        {
        let v2_6_tail = v2_6_cursor.fork_read_zipper();
        let v2_6_head = Path::from_slice(&[v2_6_byte]);
        let v3_2: Space = singleton(&(v2_6_head));
        let v3_3: Space = intersect(&(*CONSTANT_2),&(v3_2));
        let v3_4: Space = if has_head(&(v3_3)) { singleton(&[]) } else { Space::new() };
        drop(v3_3);
        let v3_5: Space = subtract(&(*CONSTANT_1),&(v3_4));
        drop(v3_4);
        let v3_8: Space = if (v3_5).is_empty() { Space::new() } else {
          let v4_6: Path = concat_path(&(v0_18_head),&(v2_6_head));
          let v4_7: Space = routine_1(c, &(v4_6), &(v2_6_tail).make_space(), &(*s0.expect("unbound native input")));
          compose(&(v3_5),&(v4_7))
        };
        drop(v3_5);
        let v3_9: Space = intersect(&(*CONSTANT_2),&(v3_2));
        drop(v3_2);
        let v3_10: Space = if has_head(&(v3_9)) { singleton(&[]) } else { Space::new() };
        drop(v3_9);
        let v3_12: Space = if (v3_10).is_empty() { Space::new() } else {
          let v5_6: Path = concat_path(&(v0_18_head),&(v2_6_head));
          let mut v5_11 = Space::new();
          let mut v5_11_cursor = (v2_6_tail).read_zipper();
          for v5_11_byte in v5_11_cursor.child_mask().iter() {
            v5_11_cursor.descend_to_byte(v5_11_byte);
            {
            let v5_11_tail = v5_11_cursor.fork_read_zipper();
            let v5_11_head = Path::from_slice(&[v5_11_byte]);
            let v6_2: Space = singleton(&(v5_11_head));
            let v6_3: Space = intersect(&(*CONSTANT_2),&(v6_2));
            let v6_4: Space = if has_head(&(v6_3)) { singleton(&[]) } else { Space::new() };
            drop(v6_3);
            let v6_5: Space = subtract(&(*CONSTANT_1),&(v6_4));
            drop(v6_4);
            let v6_7: Space = if (v6_5).is_empty() { Space::new() } else {
              let v7_6: Space = routine_2(c, &(v5_11_head), &(v5_6), &(v5_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v6_5),&(v7_6))
            };
            drop(v6_5);
            let v6_8: Space = intersect(&(*CONSTANT_2),&(v6_2));
            drop(v6_2);
            let v6_9: Space = if has_head(&(v6_8)) { singleton(&[]) } else { Space::new() };
            drop(v6_8);
            let v6_11: Space = if (v6_9).is_empty() { Space::new() } else {
              let v8_10: Space = routine_3(c, &(v5_11_head), &(v5_6), &(v5_11_tail).make_space(), &(*s0.expect("unbound native input")));
              compose(&(v6_9),&(v8_10))
            };
            drop(v6_9);
            let v6_12: Space = unite(&(v6_7),&(v6_11));
            v5_11.join_into((v6_12).clone());
            }
            v5_11_cursor.ascend(1);
          }
          drop(v5_11_cursor);
          drop(v5_6);
          compose(&(v3_10),&(v5_11))
        };
        drop(v3_10);
        let v3_13: Space = unite(&(v3_8),&(v3_12));
        v2_6.join_into((v3_13).clone());
        }
        v2_6_cursor.ascend(1);
      }
      drop(v2_6_cursor);
      compose(&(v1_5),&(v2_6))
    };
    drop(v1_5);
    let v1_8: Space = intersect(&(*CONSTANT_2),&(v1_2));
    drop(v1_2);
    let v1_9: Space = if has_head(&(v1_8)) { singleton(&[]) } else { Space::new() };
    drop(v1_8);
    let v1_11: Space = if (v1_9).is_empty() { Space::new() } else {
      let mut v9_10 = Space::new();
      let mut v9_10_cursor = (v0_18_tail).read_zipper();
      for v9_10_byte in v9_10_cursor.child_mask().iter() {
        v9_10_cursor.descend_to_byte(v9_10_byte);
        {
        let v9_10_tail = v9_10_cursor.fork_read_zipper();
        let v9_10_head = Path::from_slice(&[v9_10_byte]);
        let v10_2: Space = singleton(&(v9_10_head));
        let v10_3: Space = intersect(&(*CONSTANT_2),&(v10_2));
        let v10_4: Space = if has_head(&(v10_3)) { singleton(&[]) } else { Space::new() };
        drop(v10_3);
        let v10_5: Space = subtract(&(*CONSTANT_1),&(v10_4));
        drop(v10_4);
        let v10_7: Space = if (v10_5).is_empty() { Space::new() } else {
          let v11_6: Space = routine_2(c, &(v9_10_head), &(v0_18_head), &(v9_10_tail).make_space(), &(*s0.expect("unbound native input")));
          compose(&(v10_5),&(v11_6))
        };
        drop(v10_5);
        let v10_8: Space = intersect(&(*CONSTANT_2),&(v10_2));
        drop(v10_2);
        let v10_9: Space = if has_head(&(v10_8)) { singleton(&[]) } else { Space::new() };
        drop(v10_8);
        let v10_12: Space = if (v10_9).is_empty() { Space::new() } else {
          let v12_10: Space = unwrap(&(v0_2),&(v9_10_head));
          let mut v12_11 = Space::new();
          let mut v12_11_cursor = (v12_10).read_zipper();
          for v12_11_byte in v12_11_cursor.child_mask().iter() {
            v12_11_cursor.descend_to_byte(v12_11_byte);
            {
            let v12_11_tail = v12_11_cursor.fork_read_zipper();
            let v12_11_head = Path::from_slice(&[v12_11_byte]);
            let v13_2: Space = singleton(&(v12_11_head));
            let v13_3: Space = intersect(&(*CONSTANT_2),&(v13_2));
            let v13_4: Space = if has_head(&(v13_3)) { singleton(&[]) } else { Space::new() };
            drop(v13_3);
            let v13_5: Space = subtract(&(*CONSTANT_1),&(v13_4));
            drop(v13_4);
            let v13_7: Space = if (v13_5).is_empty() { Space::new() } else {
              let v14_6: Space = routine_4(c, &(v12_11_head), &(v0_18_head), &(v12_11_tail).make_space());
              compose(&(v13_5),&(v14_6))
            };
            drop(v13_5);
            let v13_8: Space = intersect(&(*CONSTANT_2),&(v13_2));
            drop(v13_2);
            let v13_9: Space = if has_head(&(v13_8)) { singleton(&[]) } else { Space::new() };
            drop(v13_8);
            let v13_11: Space = if (v13_9).is_empty() { Space::new() } else {
              let v15_10: Space = routine_5(c, &(v12_11_head), &(v0_18_head), &(v12_11_tail).make_space());
              compose(&(v13_9),&(v15_10))
            };
            drop(v13_9);
            let v13_12: Space = unite(&(v13_7),&(v13_11));
            v12_11.join_into((v13_12).clone());
            }
            v12_11_cursor.ascend(1);
          }
          drop(v12_11_cursor);
          drop(v12_10);
          compose(&(v10_9),&(v12_11))
        };
        drop(v10_9);
        let v10_13: Space = unite(&(v10_7),&(v10_12));
        v9_10.join_into((v10_13).clone());
        }
        v9_10_cursor.ascend(1);
      }
      drop(v9_10_cursor);
      compose(&(v1_9),&(v9_10))
    };
    drop(v1_9);
    let v1_12: Space = unite(&(v1_7),&(v1_11));
    v0_18.join_into((v1_12).clone());
    }
    v0_18_cursor.ascend(1);
  }
  drop(v0_18_cursor);
  drop(v0_2);
  let v0_20: Space = wrap(&(v0_18),&(*CONSTANT_3));
  (v0_20).clone()
}

fn routine_1(c: &mut Context, p0: &Path, s0: &Space, s1: &Space) -> Space {
  let v16_10: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let mut v16_14 = Space::new();
  let mut v16_14_cursor = (*s0).read_zipper();
  for v16_14_byte in v16_14_cursor.child_mask().iter() {
    v16_14_cursor.descend_to_byte(v16_14_byte);
    {
    let v16_14_tail = v16_14_cursor.fork_read_zipper();
    let v16_14_head = Path::from_slice(&[v16_14_byte]);
    let v17_2: Space = singleton(&(v16_14_head));
    let v17_3: Space = intersect(&(*CONSTANT_2),&(v17_2));
    let v17_4: Space = if has_head(&(v17_3)) { singleton(&[]) } else { Space::new() };
    drop(v17_3);
    let v17_5: Space = subtract(&(*CONSTANT_1),&(v17_4));
    drop(v17_4);
    let v17_8: Space = if (v17_5).is_empty() { Space::new() } else {
      let v18_6: Path = concat_path(&(*p0),&(v16_14_head));
      let v18_7: Space = routine_1(c, &(v18_6), &(v16_14_tail).make_space(), &(*s1));
      compose(&(v17_5),&(v18_7))
    };
    drop(v17_5);
    let v17_9: Space = intersect(&(*CONSTANT_2),&(v17_2));
    drop(v17_2);
    let v17_10: Space = if has_head(&(v17_9)) { singleton(&[]) } else { Space::new() };
    drop(v17_9);
    let v17_12: Space = if (v17_10).is_empty() { Space::new() } else {
      let v19_6: Path = concat_path(&(*p0),&(v16_14_head));
      let mut v19_11 = Space::new();
      let mut v19_11_cursor = (v16_14_tail).read_zipper();
      for v19_11_byte in v19_11_cursor.child_mask().iter() {
        v19_11_cursor.descend_to_byte(v19_11_byte);
        {
        let v19_11_tail = v19_11_cursor.fork_read_zipper();
        let v19_11_head = Path::from_slice(&[v19_11_byte]);
        let v20_2: Space = singleton(&(v19_11_head));
        let v20_3: Space = intersect(&(*CONSTANT_2),&(v20_2));
        let v20_4: Space = if has_head(&(v20_3)) { singleton(&[]) } else { Space::new() };
        drop(v20_3);
        let v20_5: Space = subtract(&(*CONSTANT_1),&(v20_4));
        drop(v20_4);
        let v20_7: Space = if (v20_5).is_empty() { Space::new() } else {
          let v21_6: Space = routine_2(c, &(v19_11_head), &(v19_6), &(v19_11_tail).make_space(), &(*s1));
          compose(&(v20_5),&(v21_6))
        };
        drop(v20_5);
        let v20_8: Space = intersect(&(*CONSTANT_2),&(v20_2));
        drop(v20_2);
        let v20_9: Space = if has_head(&(v20_8)) { singleton(&[]) } else { Space::new() };
        drop(v20_8);
        let v20_12: Space = if (v20_9).is_empty() { Space::new() } else {
          let v22_10: Space = unwrap(&(v16_10),&(v19_11_head));
          let mut v22_11 = Space::new();
          let mut v22_11_cursor = (v22_10).read_zipper();
          for v22_11_byte in v22_11_cursor.child_mask().iter() {
            v22_11_cursor.descend_to_byte(v22_11_byte);
            {
            let v22_11_tail = v22_11_cursor.fork_read_zipper();
            let v22_11_head = Path::from_slice(&[v22_11_byte]);
            let v23_2: Space = singleton(&(v22_11_head));
            let v23_3: Space = intersect(&(*CONSTANT_2),&(v23_2));
            let v23_4: Space = if has_head(&(v23_3)) { singleton(&[]) } else { Space::new() };
            drop(v23_3);
            let v23_5: Space = subtract(&(*CONSTANT_1),&(v23_4));
            drop(v23_4);
            let v23_7: Space = if (v23_5).is_empty() { Space::new() } else {
              let v24_6: Space = routine_4(c, &(v22_11_head), &(v19_6), &(v22_11_tail).make_space());
              compose(&(v23_5),&(v24_6))
            };
            drop(v23_5);
            let v23_8: Space = intersect(&(*CONSTANT_2),&(v23_2));
            drop(v23_2);
            let v23_9: Space = if has_head(&(v23_8)) { singleton(&[]) } else { Space::new() };
            drop(v23_8);
            let v23_11: Space = if (v23_9).is_empty() { Space::new() } else {
              let v25_10: Space = routine_5(c, &(v22_11_head), &(v19_6), &(v22_11_tail).make_space());
              compose(&(v23_9),&(v25_10))
            };
            drop(v23_9);
            let v23_12: Space = unite(&(v23_7),&(v23_11));
            v22_11.join_into((v23_12).clone());
            }
            v22_11_cursor.ascend(1);
          }
          drop(v22_11_cursor);
          drop(v22_10);
          compose(&(v20_9),&(v22_11))
        };
        drop(v20_9);
        let v20_13: Space = unite(&(v20_7),&(v20_12));
        v19_11.join_into((v20_13).clone());
        }
        v19_11_cursor.ascend(1);
      }
      drop(v19_11_cursor);
      drop(v19_6);
      compose(&(v17_10),&(v19_11))
    };
    drop(v17_10);
    let v17_13: Space = unite(&(v17_8),&(v17_12));
    v16_14.join_into((v17_13).clone());
    }
    v16_14_cursor.ascend(1);
  }
  drop(v16_14_cursor);
  drop(v16_10);
  (v16_14).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v26_8: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v26_9: Space = unwrap(&(v26_8),&(*p0));
  drop(v26_8);
  let mut v26_13 = Space::new();
  let mut v26_13_cursor = (*s0).read_zipper();
  for v26_13_byte in v26_13_cursor.child_mask().iter() {
    v26_13_cursor.descend_to_byte(v26_13_byte);
    {
    let v26_13_tail = v26_13_cursor.fork_read_zipper();
    let v26_13_head = Path::from_slice(&[v26_13_byte]);
    let v27_2: Space = singleton(&(v26_13_head));
    let v27_3: Space = intersect(&(*CONSTANT_2),&(v27_2));
    let v27_4: Space = if has_head(&(v27_3)) { singleton(&[]) } else { Space::new() };
    drop(v27_3);
    let v27_5: Space = subtract(&(*CONSTANT_1),&(v27_4));
    drop(v27_4);
    let v27_8: Space = if (v27_5).is_empty() { Space::new() } else {
      let v28_6: Path = concat_path(&(*p0),&(v26_13_head));
      let v28_7: Space = routine_2(c, &(v28_6), &(*p1), &(v26_13_tail).make_space(), &(*s1));
      drop(v28_6);
      compose(&(v27_5),&(v28_7))
    };
    drop(v27_5);
    let v27_9: Space = intersect(&(*CONSTANT_2),&(v27_2));
    drop(v27_2);
    let v27_10: Space = if has_head(&(v27_9)) { singleton(&[]) } else { Space::new() };
    drop(v27_9);
    let v27_13: Space = if (v27_10).is_empty() { Space::new() } else {
      let v29_11: Space = unwrap(&(v26_9),&(v26_13_head));
      let mut v29_12 = Space::new();
      let mut v29_12_cursor = (v29_11).read_zipper();
      for v29_12_byte in v29_12_cursor.child_mask().iter() {
        v29_12_cursor.descend_to_byte(v29_12_byte);
        {
        let v29_12_tail = v29_12_cursor.fork_read_zipper();
        let v29_12_head = Path::from_slice(&[v29_12_byte]);
        let v30_2: Space = singleton(&(v29_12_head));
        let v30_3: Space = intersect(&(*CONSTANT_2),&(v30_2));
        let v30_4: Space = if has_head(&(v30_3)) { singleton(&[]) } else { Space::new() };
        drop(v30_3);
        let v30_5: Space = subtract(&(*CONSTANT_1),&(v30_4));
        drop(v30_4);
        let v30_7: Space = if (v30_5).is_empty() { Space::new() } else {
          let v31_6: Space = routine_4(c, &(v29_12_head), &(*p1), &(v29_12_tail).make_space());
          compose(&(v30_5),&(v31_6))
        };
        drop(v30_5);
        let v30_8: Space = intersect(&(*CONSTANT_2),&(v30_2));
        drop(v30_2);
        let v30_9: Space = if has_head(&(v30_8)) { singleton(&[]) } else { Space::new() };
        drop(v30_8);
        let v30_10: Space = compose(&(v30_9),&(v29_12_tail));
        drop(v30_9);
        let v30_11: Space = wrap(&(v30_10),&(v29_12_head));
        drop(v30_10);
        let v30_12: Space = wrap(&(v30_11),&(*p1));
        drop(v30_11);
        let v30_13: Space = unite(&(v30_7),&(v30_12));
        drop(v30_12);
        v29_12.join_into((v30_13).clone());
        }
        v29_12_cursor.ascend(1);
      }
      drop(v29_12_cursor);
      drop(v29_11);
      compose(&(v27_10),&(v29_12))
    };
    drop(v27_10);
    let v27_14: Space = unite(&(v27_8),&(v27_13));
    v26_13.join_into((v27_14).clone());
    }
    v26_13_cursor.ascend(1);
  }
  drop(v26_13_cursor);
  drop(v26_9);
  (v26_13).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v32_5: Space = unwrap(&(*s1),&(*CONSTANT_0));
  let v32_6: Space = unwrap(&(v32_5),&(*p0));
  drop(v32_5);
  let mut v32_13 = Space::new();
  let mut v32_13_cursor = (v32_6).read_zipper();
  for v32_13_byte in v32_13_cursor.child_mask().iter() {
    v32_13_cursor.descend_to_byte(v32_13_byte);
    {
    let v32_13_tail = v32_13_cursor.fork_read_zipper();
    let v32_13_head = Path::from_slice(&[v32_13_byte]);
    let v33_2: Space = singleton(&(v32_13_head));
    let v33_3: Space = intersect(&(*CONSTANT_2),&(v33_2));
    let v33_4: Space = if has_head(&(v33_3)) { singleton(&[]) } else { Space::new() };
    drop(v33_3);
    let v33_5: Space = subtract(&(*CONSTANT_1),&(v33_4));
    drop(v33_4);
    let v33_7: Space = if (v33_5).is_empty() { Space::new() } else {
      let mut v34_6 = Space::new();
      let mut v34_6_cursor = (v32_13_tail).read_zipper();
      for v34_6_byte in v34_6_cursor.child_mask().iter() {
        v34_6_cursor.descend_to_byte(v34_6_byte);
        {
        let v34_6_tail = v34_6_cursor.fork_read_zipper();
        let v34_6_head = Path::from_slice(&[v34_6_byte]);
        let v35_2: Space = singleton(&(v34_6_head));
        let v35_3: Space = intersect(&(*CONSTANT_2),&(v35_2));
        let v35_4: Space = if has_head(&(v35_3)) { singleton(&[]) } else { Space::new() };
        drop(v35_3);
        let v35_5: Space = subtract(&(*CONSTANT_1),&(v35_4));
        drop(v35_4);
        let v35_8: Space = if (v35_5).is_empty() { Space::new() } else {
          let v36_6: Path = concat_path(&(v32_13_head),&(v34_6_head));
          let v36_7: Space = routine_4(c, &(v36_6), &(*p1), &(v34_6_tail).make_space());
          compose(&(v35_5),&(v36_7))
        };
        drop(v35_5);
        let v35_9: Space = intersect(&(*CONSTANT_2),&(v35_2));
        drop(v35_2);
        let v35_10: Space = if has_head(&(v35_9)) { singleton(&[]) } else { Space::new() };
        drop(v35_9);
        let v35_11: Space = compose(&(v35_10),&(v34_6_tail));
        drop(v35_10);
        let v37_6: Path = concat_path(&(v32_13_head),&(v34_6_head));
        let v35_12: Space = wrap(&(v35_11),&(v37_6));
        drop(v35_11);
        let v35_13: Space = wrap(&(v35_12),&(*p1));
        drop(v35_12);
        let v35_14: Space = unite(&(v35_8),&(v35_13));
        drop(v35_13);
        v34_6.join_into((v35_14).clone());
        }
        v34_6_cursor.ascend(1);
      }
      drop(v34_6_cursor);
      compose(&(v33_5),&(v34_6))
    };
    drop(v33_5);
    let v33_8: Space = intersect(&(*CONSTANT_2),&(v33_2));
    drop(v33_2);
    let v33_9: Space = if has_head(&(v33_8)) { singleton(&[]) } else { Space::new() };
    drop(v33_8);
    let v33_10: Space = compose(&(v33_9),&(v32_13_tail));
    drop(v33_9);
    let v33_11: Space = wrap(&(v33_10),&(v32_13_head));
    drop(v33_10);
    let v33_12: Space = wrap(&(v33_11),&(*p1));
    drop(v33_11);
    let v33_13: Space = unite(&(v33_7),&(v33_12));
    drop(v33_12);
    v32_13.join_into((v33_13).clone());
    }
    v32_13_cursor.ascend(1);
  }
  drop(v32_13_cursor);
  drop(v32_6);
  (v32_13).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let mut v38_6 = Space::new();
  let mut v38_6_cursor = (*s0).read_zipper();
  for v38_6_byte in v38_6_cursor.child_mask().iter() {
    v38_6_cursor.descend_to_byte(v38_6_byte);
    {
    let v38_6_tail = v38_6_cursor.fork_read_zipper();
    let v38_6_head = Path::from_slice(&[v38_6_byte]);
    let v39_2: Space = singleton(&(v38_6_head));
    let v39_3: Space = intersect(&(*CONSTANT_2),&(v39_2));
    let v39_4: Space = if has_head(&(v39_3)) { singleton(&[]) } else { Space::new() };
    drop(v39_3);
    let v39_5: Space = subtract(&(*CONSTANT_1),&(v39_4));
    drop(v39_4);
    let v39_8: Space = if (v39_5).is_empty() { Space::new() } else {
      let v40_6: Path = concat_path(&(*p0),&(v38_6_head));
      let v40_7: Space = routine_4(c, &(v40_6), &(*p1), &(v38_6_tail).make_space());
      compose(&(v39_5),&(v40_7))
    };
    drop(v39_5);
    let v39_9: Space = intersect(&(*CONSTANT_2),&(v39_2));
    drop(v39_2);
    let v39_10: Space = if has_head(&(v39_9)) { singleton(&[]) } else { Space::new() };
    drop(v39_9);
    let v39_11: Space = compose(&(v39_10),&(v38_6_tail));
    drop(v39_10);
    let v41_6: Path = concat_path(&(*p0),&(v38_6_head));
    let v39_12: Space = wrap(&(v39_11),&(v41_6));
    drop(v39_11);
    let v39_13: Space = wrap(&(v39_12),&(*p1));
    drop(v39_12);
    let v39_14: Space = unite(&(v39_8),&(v39_13));
    drop(v39_13);
    v38_6.join_into((v39_14).clone());
    }
    v38_6_cursor.ascend(1);
  }
  drop(v38_6_cursor);
  (v38_6).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v42_3: Space = wrap(&(*s0),&(*p0));
  let v42_4: Space = wrap(&(v42_3),&(*p1));
  drop(v42_3);
  (v42_4).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
