#![allow(unused_imports,unused_variables,unused_mut,unused_parens,dead_code)]
use zippy_pathmap::*;
mod program_0 { use super::*;
static CONSTANT_0: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,0]));
static CONSTANT_1: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,83]));
static CONSTANT_2: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,84]));
static CONSTANT_3: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,82]));
static CONSTANT_4: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,83,0,0,0,82]));
static CONSTANT_5: std::sync::LazyLock<Path> = std::sync::LazyLock::new(|| Path::from_slice(&[0,0,0,84,0,0,0,82]));
static CONSTANT_6: std::sync::LazyLock<Space> = std::sync::LazyLock::new(|| literal_text("1 0 "));
fn routine_0(c: &mut Context, s0: Option<&Space>) -> Space {
  let v0_2: Space = unwrap(&(*s0.expect("unbound native input")),&(*CONSTANT_0));
  let mut v0_3 = Space::new();
  let mut v0_3_cursor = (v0_2).read_zipper();
  for v0_3_byte in v0_3_cursor.child_mask().iter() {
    v0_3_cursor.descend_to_byte(v0_3_byte);
    {
    let v0_3_tail = v0_3_cursor.fork_read_zipper();
    let v0_3_head = Path::from_slice(&[v0_3_byte]);
    let mut v1_2 = Space::new();
    let mut v1_2_cursor = (v0_3_tail).read_zipper();
    for v1_2_byte in v1_2_cursor.child_mask().iter() {
      v1_2_cursor.descend_to_byte(v1_2_byte);
      {
      let v1_2_tail = v1_2_cursor.fork_read_zipper();
      let v1_2_head = Path::from_slice(&[v1_2_byte]);
      let v2_2: Path = concat_path(&(v0_3_head),&(v1_2_head));
      let mut v2_3 = Space::new();
      let mut v2_3_cursor = (v1_2_tail).read_zipper();
      for v2_3_byte in v2_3_cursor.child_mask().iter() {
        v2_3_cursor.descend_to_byte(v2_3_byte);
        {
        let v2_3_tail = v2_3_cursor.fork_read_zipper();
        let v2_3_head = Path::from_slice(&[v2_3_byte]);
        let v3_2: Path = concat_path(&(v2_2),&(v2_3_head));
        let mut v3_3 = Space::new();
        let mut v3_3_cursor = (v2_3_tail).read_zipper();
        for v3_3_byte in v3_3_cursor.child_mask().iter() {
          v3_3_cursor.descend_to_byte(v3_3_byte);
          {
          let v3_3_tail = v3_3_cursor.fork_read_zipper();
          let v3_3_head = Path::from_slice(&[v3_3_byte]);
          let v4_2: Path = concat_path(&(v3_2),&(v3_3_head));
          let mut v4_3 = Space::new();
          let mut v4_3_cursor = (v3_3_tail).read_zipper();
          for v4_3_byte in v4_3_cursor.child_mask().iter() {
            v4_3_cursor.descend_to_byte(v4_3_byte);
            {
            let v4_3_tail = v4_3_cursor.fork_read_zipper();
            let v4_3_head = Path::from_slice(&[v4_3_byte]);
            let mut v5_2 = Space::new();
            let mut v5_2_cursor = (v4_3_tail).read_zipper();
            for v5_2_byte in v5_2_cursor.child_mask().iter() {
              v5_2_cursor.descend_to_byte(v5_2_byte);
              {
              let v5_2_tail = v5_2_cursor.fork_read_zipper();
              let v5_2_head = Path::from_slice(&[v5_2_byte]);
              let v6_2: Path = concat_path(&(v4_3_head),&(v5_2_head));
              let mut v6_3 = Space::new();
              let mut v6_3_cursor = (v5_2_tail).read_zipper();
              for v6_3_byte in v6_3_cursor.child_mask().iter() {
                v6_3_cursor.descend_to_byte(v6_3_byte);
                {
                let v6_3_tail = v6_3_cursor.fork_read_zipper();
                let v6_3_head = Path::from_slice(&[v6_3_byte]);
                let v7_2: Path = concat_path(&(v6_2),&(v6_3_head));
                let mut v7_3 = Space::new();
                let mut v7_3_cursor = (v6_3_tail).read_zipper();
                for v7_3_byte in v7_3_cursor.child_mask().iter() {
                  v7_3_cursor.descend_to_byte(v7_3_byte);
                  {
                  let v7_3_tail = v7_3_cursor.fork_read_zipper();
                  let v7_3_head = Path::from_slice(&[v7_3_byte]);
                  let v8_2: Path = concat_path(&(v7_2),&(v7_3_head));
                  let v8_3: Space = routine_1(c, &(v8_2), &(v4_2), &(v7_3_tail).make_space());
                  drop(v8_2);
                  v7_3.join_into((v8_3).clone());
                  }
                  v7_3_cursor.ascend(1);
                }
                drop(v7_3_cursor);
                drop(v7_2);
                v6_3.join_into((v7_3).clone());
                }
                v6_3_cursor.ascend(1);
              }
              drop(v6_3_cursor);
              drop(v6_2);
              v5_2.join_into((v6_3).clone());
              }
              v5_2_cursor.ascend(1);
            }
            drop(v5_2_cursor);
            v4_3.join_into((v5_2).clone());
            }
            v4_3_cursor.ascend(1);
          }
          drop(v4_3_cursor);
          drop(v4_2);
          v3_3.join_into((v4_3).clone());
          }
          v3_3_cursor.ascend(1);
        }
        drop(v3_3_cursor);
        drop(v3_2);
        v2_3.join_into((v3_3).clone());
        }
        v2_3_cursor.ascend(1);
      }
      drop(v2_3_cursor);
      drop(v2_2);
      v1_2.join_into((v2_3).clone());
      }
      v1_2_cursor.ascend(1);
    }
    drop(v1_2_cursor);
    v0_3.join_into((v1_2).clone());
    }
    v0_3_cursor.ascend(1);
  }
  drop(v0_3_cursor);
  drop(v0_2);
  let v0_5: Space = wrap(&(v0_3),&(*CONSTANT_1));
  let v0_7: Space = wrap(&(*s0.expect("unbound native input")),&(*CONSTANT_2));
  let v0_8: Space = unite(&(v0_5),&(v0_7));
  drop(v0_7);
  let mut v0_12: Space = (v0_8).clone();
  loop {
    let v9_1: Space = unwrap(&(v0_12),&(*CONSTANT_1));
    let v9_2: Space = unwrap(&(v9_1),&(*CONSTANT_3));
    let mut v9_3 = Space::new();
    let mut v9_3_cursor = (v9_2).read_zipper();
    for v9_3_byte in v9_3_cursor.child_mask().iter() {
      v9_3_cursor.descend_to_byte(v9_3_byte);
      {
      let v9_3_tail = v9_3_cursor.fork_read_zipper();
      let v9_3_head = Path::from_slice(&[v9_3_byte]);
      let mut v10_2 = Space::new();
      let mut v10_2_cursor = (v9_3_tail).read_zipper();
      for v10_2_byte in v10_2_cursor.child_mask().iter() {
        v10_2_cursor.descend_to_byte(v10_2_byte);
        {
        let v10_2_tail = v10_2_cursor.fork_read_zipper();
        let v10_2_head = Path::from_slice(&[v10_2_byte]);
        let v11_2: Path = concat_path(&(v9_3_head),&(v10_2_head));
        let mut v11_3 = Space::new();
        let mut v11_3_cursor = (v10_2_tail).read_zipper();
        for v11_3_byte in v11_3_cursor.child_mask().iter() {
          v11_3_cursor.descend_to_byte(v11_3_byte);
          {
          let v11_3_tail = v11_3_cursor.fork_read_zipper();
          let v11_3_head = Path::from_slice(&[v11_3_byte]);
          let v12_2: Path = concat_path(&(v11_2),&(v11_3_head));
          let mut v12_3 = Space::new();
          let mut v12_3_cursor = (v11_3_tail).read_zipper();
          for v12_3_byte in v12_3_cursor.child_mask().iter() {
            v12_3_cursor.descend_to_byte(v12_3_byte);
            {
            let v12_3_tail = v12_3_cursor.fork_read_zipper();
            let v12_3_head = Path::from_slice(&[v12_3_byte]);
            let v13_2: Path = concat_path(&(v12_2),&(v12_3_head));
            let mut v13_3 = Space::new();
            let mut v13_3_cursor = (v12_3_tail).read_zipper();
            for v13_3_byte in v13_3_cursor.child_mask().iter() {
              v13_3_cursor.descend_to_byte(v13_3_byte);
              {
              let v13_3_tail = v13_3_cursor.fork_read_zipper();
              let v13_3_head = Path::from_slice(&[v13_3_byte]);
              let mut v14_2 = Space::new();
              let mut v14_2_cursor = (v13_3_tail).read_zipper();
              for v14_2_byte in v14_2_cursor.child_mask().iter() {
                v14_2_cursor.descend_to_byte(v14_2_byte);
                {
                let v14_2_tail = v14_2_cursor.fork_read_zipper();
                let v14_2_head = Path::from_slice(&[v14_2_byte]);
                let v15_2: Path = concat_path(&(v13_3_head),&(v14_2_head));
                let mut v15_3 = Space::new();
                let mut v15_3_cursor = (v14_2_tail).read_zipper();
                for v15_3_byte in v15_3_cursor.child_mask().iter() {
                  v15_3_cursor.descend_to_byte(v15_3_byte);
                  {
                  let v15_3_tail = v15_3_cursor.fork_read_zipper();
                  let v15_3_head = Path::from_slice(&[v15_3_byte]);
                  let v16_2: Path = concat_path(&(v15_2),&(v15_3_head));
                  let mut v16_3 = Space::new();
                  let mut v16_3_cursor = (v15_3_tail).read_zipper();
                  for v16_3_byte in v16_3_cursor.child_mask().iter() {
                    v16_3_cursor.descend_to_byte(v16_3_byte);
                    {
                    let v16_3_tail = v16_3_cursor.fork_read_zipper();
                    let v16_3_head = Path::from_slice(&[v16_3_byte]);
                    let v17_2: Path = concat_path(&(v16_2),&(v16_3_head));
                    let v17_3: Space = routine_2(c, &(v17_2), &(v13_2), &(v16_3_tail).make_space(), &(v0_12));
                    drop(v17_2);
                    v16_3.join_into((v17_3).clone());
                    }
                    v16_3_cursor.ascend(1);
                  }
                  drop(v16_3_cursor);
                  drop(v16_2);
                  v15_3.join_into((v16_3).clone());
                  }
                  v15_3_cursor.ascend(1);
                }
                drop(v15_3_cursor);
                drop(v15_2);
                v14_2.join_into((v15_3).clone());
                }
                v14_2_cursor.ascend(1);
              }
              drop(v14_2_cursor);
              v13_3.join_into((v14_2).clone());
              }
              v13_3_cursor.ascend(1);
            }
            drop(v13_3_cursor);
            drop(v13_2);
            v12_3.join_into((v13_3).clone());
            }
            v12_3_cursor.ascend(1);
          }
          drop(v12_3_cursor);
          drop(v12_2);
          v11_3.join_into((v12_3).clone());
          }
          v11_3_cursor.ascend(1);
        }
        drop(v11_3_cursor);
        drop(v11_2);
        v10_2.join_into((v11_3).clone());
        }
        v10_2_cursor.ascend(1);
      }
      drop(v10_2_cursor);
      v9_3.join_into((v10_2).clone());
      }
      v9_3_cursor.ascend(1);
    }
    drop(v9_3_cursor);
    let mut v9_4 = Space::new();
    let mut v9_4_cursor = (v9_2).read_zipper();
    for v9_4_byte in v9_4_cursor.child_mask().iter() {
      v9_4_cursor.descend_to_byte(v9_4_byte);
      {
      let v9_4_tail = v9_4_cursor.fork_read_zipper();
      let v9_4_head = Path::from_slice(&[v9_4_byte]);
      let mut v18_2 = Space::new();
      let mut v18_2_cursor = (v9_4_tail).read_zipper();
      for v18_2_byte in v18_2_cursor.child_mask().iter() {
        v18_2_cursor.descend_to_byte(v18_2_byte);
        {
        let v18_2_tail = v18_2_cursor.fork_read_zipper();
        let v18_2_head = Path::from_slice(&[v18_2_byte]);
        let v19_2: Path = concat_path(&(v9_4_head),&(v18_2_head));
        let mut v19_3 = Space::new();
        let mut v19_3_cursor = (v18_2_tail).read_zipper();
        for v19_3_byte in v19_3_cursor.child_mask().iter() {
          v19_3_cursor.descend_to_byte(v19_3_byte);
          {
          let v19_3_tail = v19_3_cursor.fork_read_zipper();
          let v19_3_head = Path::from_slice(&[v19_3_byte]);
          let v20_2: Path = concat_path(&(v19_2),&(v19_3_head));
          let mut v20_3 = Space::new();
          let mut v20_3_cursor = (v19_3_tail).read_zipper();
          for v20_3_byte in v20_3_cursor.child_mask().iter() {
            v20_3_cursor.descend_to_byte(v20_3_byte);
            {
            let v20_3_tail = v20_3_cursor.fork_read_zipper();
            let v20_3_head = Path::from_slice(&[v20_3_byte]);
            let v21_2: Path = concat_path(&(v20_2),&(v20_3_head));
            let mut v21_3 = Space::new();
            let mut v21_3_cursor = (v20_3_tail).read_zipper();
            for v21_3_byte in v21_3_cursor.child_mask().iter() {
              v21_3_cursor.descend_to_byte(v21_3_byte);
              {
              let v21_3_tail = v21_3_cursor.fork_read_zipper();
              let v21_3_head = Path::from_slice(&[v21_3_byte]);
              let mut v22_2 = Space::new();
              let mut v22_2_cursor = (v21_3_tail).read_zipper();
              for v22_2_byte in v22_2_cursor.child_mask().iter() {
                v22_2_cursor.descend_to_byte(v22_2_byte);
                {
                let v22_2_tail = v22_2_cursor.fork_read_zipper();
                let v22_2_head = Path::from_slice(&[v22_2_byte]);
                let v23_2: Path = concat_path(&(v21_3_head),&(v22_2_head));
                let mut v23_3 = Space::new();
                let mut v23_3_cursor = (v22_2_tail).read_zipper();
                for v23_3_byte in v23_3_cursor.child_mask().iter() {
                  v23_3_cursor.descend_to_byte(v23_3_byte);
                  {
                  let v23_3_tail = v23_3_cursor.fork_read_zipper();
                  let v23_3_head = Path::from_slice(&[v23_3_byte]);
                  let v24_2: Path = concat_path(&(v23_2),&(v23_3_head));
                  let mut v24_3 = Space::new();
                  let mut v24_3_cursor = (v23_3_tail).read_zipper();
                  for v24_3_byte in v24_3_cursor.child_mask().iter() {
                    v24_3_cursor.descend_to_byte(v24_3_byte);
                    {
                    let v24_3_tail = v24_3_cursor.fork_read_zipper();
                    let v24_3_head = Path::from_slice(&[v24_3_byte]);
                    let v25_2: Path = concat_path(&(v24_2),&(v24_3_head));
                    let v25_3: Space = routine_3(c, &(v25_2), &(v21_2), &(v24_3_tail).make_space(), &(v0_12));
                    drop(v25_2);
                    v24_3.join_into((v25_3).clone());
                    }
                    v24_3_cursor.ascend(1);
                  }
                  drop(v24_3_cursor);
                  drop(v24_2);
                  v23_3.join_into((v24_3).clone());
                  }
                  v23_3_cursor.ascend(1);
                }
                drop(v23_3_cursor);
                drop(v23_2);
                v22_2.join_into((v23_3).clone());
                }
                v22_2_cursor.ascend(1);
              }
              drop(v22_2_cursor);
              v21_3.join_into((v22_2).clone());
              }
              v21_3_cursor.ascend(1);
            }
            drop(v21_3_cursor);
            drop(v21_2);
            v20_3.join_into((v21_3).clone());
            }
            v20_3_cursor.ascend(1);
          }
          drop(v20_3_cursor);
          drop(v20_2);
          v19_3.join_into((v20_3).clone());
          }
          v19_3_cursor.ascend(1);
        }
        drop(v19_3_cursor);
        drop(v19_2);
        v18_2.join_into((v19_3).clone());
        }
        v18_2_cursor.ascend(1);
      }
      drop(v18_2_cursor);
      v9_4.join_into((v18_2).clone());
      }
      v9_4_cursor.ascend(1);
    }
    drop(v9_4_cursor);
    drop(v9_2);
    let v9_5: Space = unite(&(v9_3),&(v9_4));
    let v9_6: Space = unwrap(&(v0_12),&(*CONSTANT_2));
    let v9_7: Space = unwrap(&(v9_6),&(*CONSTANT_0));
    let mut v9_8 = Space::new();
    let mut v9_8_cursor = (v9_7).read_zipper();
    for v9_8_byte in v9_8_cursor.child_mask().iter() {
      v9_8_cursor.descend_to_byte(v9_8_byte);
      {
      let v9_8_tail = v9_8_cursor.fork_read_zipper();
      let v9_8_head = Path::from_slice(&[v9_8_byte]);
      let mut v26_2 = Space::new();
      let mut v26_2_cursor = (v9_8_tail).read_zipper();
      for v26_2_byte in v26_2_cursor.child_mask().iter() {
        v26_2_cursor.descend_to_byte(v26_2_byte);
        {
        let v26_2_tail = v26_2_cursor.fork_read_zipper();
        let v26_2_head = Path::from_slice(&[v26_2_byte]);
        let v27_2: Path = concat_path(&(v9_8_head),&(v26_2_head));
        let mut v27_3 = Space::new();
        let mut v27_3_cursor = (v26_2_tail).read_zipper();
        for v27_3_byte in v27_3_cursor.child_mask().iter() {
          v27_3_cursor.descend_to_byte(v27_3_byte);
          {
          let v27_3_tail = v27_3_cursor.fork_read_zipper();
          let v27_3_head = Path::from_slice(&[v27_3_byte]);
          let v28_2: Path = concat_path(&(v27_2),&(v27_3_head));
          let mut v28_3 = Space::new();
          let mut v28_3_cursor = (v27_3_tail).read_zipper();
          for v28_3_byte in v28_3_cursor.child_mask().iter() {
            v28_3_cursor.descend_to_byte(v28_3_byte);
            {
            let v28_3_tail = v28_3_cursor.fork_read_zipper();
            let v28_3_head = Path::from_slice(&[v28_3_byte]);
            let v29_2: Path = concat_path(&(v28_2),&(v28_3_head));
            let mut v29_3 = Space::new();
            let mut v29_3_cursor = (v28_3_tail).read_zipper();
            for v29_3_byte in v29_3_cursor.child_mask().iter() {
              v29_3_cursor.descend_to_byte(v29_3_byte);
              {
              let v29_3_tail = v29_3_cursor.fork_read_zipper();
              let v29_3_head = Path::from_slice(&[v29_3_byte]);
              let mut v30_2 = Space::new();
              let mut v30_2_cursor = (v29_3_tail).read_zipper();
              for v30_2_byte in v30_2_cursor.child_mask().iter() {
                v30_2_cursor.descend_to_byte(v30_2_byte);
                {
                let v30_2_tail = v30_2_cursor.fork_read_zipper();
                let v30_2_head = Path::from_slice(&[v30_2_byte]);
                let v31_2: Path = concat_path(&(v29_3_head),&(v30_2_head));
                let mut v31_3 = Space::new();
                let mut v31_3_cursor = (v30_2_tail).read_zipper();
                for v31_3_byte in v31_3_cursor.child_mask().iter() {
                  v31_3_cursor.descend_to_byte(v31_3_byte);
                  {
                  let v31_3_tail = v31_3_cursor.fork_read_zipper();
                  let v31_3_head = Path::from_slice(&[v31_3_byte]);
                  let v32_2: Path = concat_path(&(v31_2),&(v31_3_head));
                  let mut v32_3 = Space::new();
                  let mut v32_3_cursor = (v31_3_tail).read_zipper();
                  for v32_3_byte in v32_3_cursor.child_mask().iter() {
                    v32_3_cursor.descend_to_byte(v32_3_byte);
                    {
                    let v32_3_tail = v32_3_cursor.fork_read_zipper();
                    let v32_3_head = Path::from_slice(&[v32_3_byte]);
                    let v33_2: Path = concat_path(&(v32_2),&(v32_3_head));
                    let v33_3: Space = routine_4(c, &(v33_2), &(v29_2), &(v32_3_tail).make_space());
                    drop(v33_2);
                    v32_3.join_into((v33_3).clone());
                    }
                    v32_3_cursor.ascend(1);
                  }
                  drop(v32_3_cursor);
                  drop(v32_2);
                  v31_3.join_into((v32_3).clone());
                  }
                  v31_3_cursor.ascend(1);
                }
                drop(v31_3_cursor);
                drop(v31_2);
                v30_2.join_into((v31_3).clone());
                }
                v30_2_cursor.ascend(1);
              }
              drop(v30_2_cursor);
              v29_3.join_into((v30_2).clone());
              }
              v29_3_cursor.ascend(1);
            }
            drop(v29_3_cursor);
            drop(v29_2);
            v28_3.join_into((v29_3).clone());
            }
            v28_3_cursor.ascend(1);
          }
          drop(v28_3_cursor);
          drop(v28_2);
          v27_3.join_into((v28_3).clone());
          }
          v27_3_cursor.ascend(1);
        }
        drop(v27_3_cursor);
        drop(v27_2);
        v26_2.join_into((v27_3).clone());
        }
        v26_2_cursor.ascend(1);
      }
      drop(v26_2_cursor);
      v9_8.join_into((v26_2).clone());
      }
      v9_8_cursor.ascend(1);
    }
    drop(v9_8_cursor);
    drop(v9_7);
    let v9_9: Space = unite(&(v9_5),&(v9_8));
    let v9_10: Space = unwrap(&(v9_6),&(*CONSTANT_3));
    let mut v9_11 = Space::new();
    let mut v9_11_cursor = (v9_10).read_zipper();
    for v9_11_byte in v9_11_cursor.child_mask().iter() {
      v9_11_cursor.descend_to_byte(v9_11_byte);
      {
      let v9_11_tail = v9_11_cursor.fork_read_zipper();
      let v9_11_head = Path::from_slice(&[v9_11_byte]);
      let mut v34_2 = Space::new();
      let mut v34_2_cursor = (v9_11_tail).read_zipper();
      for v34_2_byte in v34_2_cursor.child_mask().iter() {
        v34_2_cursor.descend_to_byte(v34_2_byte);
        {
        let v34_2_tail = v34_2_cursor.fork_read_zipper();
        let v34_2_head = Path::from_slice(&[v34_2_byte]);
        let v35_2: Path = concat_path(&(v9_11_head),&(v34_2_head));
        let mut v35_3 = Space::new();
        let mut v35_3_cursor = (v34_2_tail).read_zipper();
        for v35_3_byte in v35_3_cursor.child_mask().iter() {
          v35_3_cursor.descend_to_byte(v35_3_byte);
          {
          let v35_3_tail = v35_3_cursor.fork_read_zipper();
          let v35_3_head = Path::from_slice(&[v35_3_byte]);
          let v36_2: Path = concat_path(&(v35_2),&(v35_3_head));
          let mut v36_3 = Space::new();
          let mut v36_3_cursor = (v35_3_tail).read_zipper();
          for v36_3_byte in v36_3_cursor.child_mask().iter() {
            v36_3_cursor.descend_to_byte(v36_3_byte);
            {
            let v36_3_tail = v36_3_cursor.fork_read_zipper();
            let v36_3_head = Path::from_slice(&[v36_3_byte]);
            let v37_2: Path = concat_path(&(v36_2),&(v36_3_head));
            let mut v37_3 = Space::new();
            let mut v37_3_cursor = (v36_3_tail).read_zipper();
            for v37_3_byte in v37_3_cursor.child_mask().iter() {
              v37_3_cursor.descend_to_byte(v37_3_byte);
              {
              let v37_3_tail = v37_3_cursor.fork_read_zipper();
              let v37_3_head = Path::from_slice(&[v37_3_byte]);
              let mut v38_2 = Space::new();
              let mut v38_2_cursor = (v37_3_tail).read_zipper();
              for v38_2_byte in v38_2_cursor.child_mask().iter() {
                v38_2_cursor.descend_to_byte(v38_2_byte);
                {
                let v38_2_tail = v38_2_cursor.fork_read_zipper();
                let v38_2_head = Path::from_slice(&[v38_2_byte]);
                let v39_2: Path = concat_path(&(v37_3_head),&(v38_2_head));
                let mut v39_3 = Space::new();
                let mut v39_3_cursor = (v38_2_tail).read_zipper();
                for v39_3_byte in v39_3_cursor.child_mask().iter() {
                  v39_3_cursor.descend_to_byte(v39_3_byte);
                  {
                  let v39_3_tail = v39_3_cursor.fork_read_zipper();
                  let v39_3_head = Path::from_slice(&[v39_3_byte]);
                  let v40_2: Path = concat_path(&(v39_2),&(v39_3_head));
                  let mut v40_3 = Space::new();
                  let mut v40_3_cursor = (v39_3_tail).read_zipper();
                  for v40_3_byte in v40_3_cursor.child_mask().iter() {
                    v40_3_cursor.descend_to_byte(v40_3_byte);
                    {
                    let v40_3_tail = v40_3_cursor.fork_read_zipper();
                    let v40_3_head = Path::from_slice(&[v40_3_byte]);
                    let v41_2: Path = concat_path(&(v40_2),&(v40_3_head));
                    let v41_3: Space = routine_5(c, &(v41_2), &(v37_2), &(v40_3_tail).make_space(), &(v0_12));
                    drop(v41_2);
                    v40_3.join_into((v41_3).clone());
                    }
                    v40_3_cursor.ascend(1);
                  }
                  drop(v40_3_cursor);
                  drop(v40_2);
                  v39_3.join_into((v40_3).clone());
                  }
                  v39_3_cursor.ascend(1);
                }
                drop(v39_3_cursor);
                drop(v39_2);
                v38_2.join_into((v39_3).clone());
                }
                v38_2_cursor.ascend(1);
              }
              drop(v38_2_cursor);
              v37_3.join_into((v38_2).clone());
              }
              v37_3_cursor.ascend(1);
            }
            drop(v37_3_cursor);
            drop(v37_2);
            v36_3.join_into((v37_3).clone());
            }
            v36_3_cursor.ascend(1);
          }
          drop(v36_3_cursor);
          drop(v36_2);
          v35_3.join_into((v36_3).clone());
          }
          v35_3_cursor.ascend(1);
        }
        drop(v35_3_cursor);
        drop(v35_2);
        v34_2.join_into((v35_3).clone());
        }
        v34_2_cursor.ascend(1);
      }
      drop(v34_2_cursor);
      v9_11.join_into((v34_2).clone());
      }
      v9_11_cursor.ascend(1);
    }
    drop(v9_11_cursor);
    drop(v9_10);
    let v9_12: Space = unite(&(v9_9),&(v9_11));
    let v9_13: Space = unwrap(&(v0_12),&(*CONSTANT_4));
    let v9_14: Space = subtract(&(v9_12),&(v9_13));
    drop(v9_13);
    let v9_15: Space = unwrap(&(v0_12),&(*CONSTANT_5));
    let v9_16: Space = subtract(&(v9_14),&(v9_15));
    drop(v9_15);
    let v9_17: Space = wrap(&(v9_16),&(*CONSTANT_4));
    let v9_18: Space = unite(&(v9_1),&(v9_6));
    drop(v9_1);
    drop(v9_6);
    let v9_19: Space = wrap(&(v9_18),&(*CONSTANT_2));
    drop(v9_18);
    let v9_20: Space = unite(&(v9_17),&(v9_19));
    drop(v9_19);
    let v9_21: Space = unite(&(v9_20),&(v0_12));
    if !v0_12.join_into((v9_21).clone()).is_element() { break; }
  }
  let v0_13: Space = unwrap(&(v0_12),&(*CONSTANT_5));
  (v0_13).clone()
}

fn routine_1(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v42_3: Space = wrap(&(*s0),&(*p0));
  let v42_4: Space = wrap(&(v42_3),&(*p1));
  drop(v42_3);
  let v42_6: Space = wrap(&(v42_4),&(*CONSTANT_3));
  drop(v42_4);
  (v42_6).clone()
}

fn routine_2(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v43_5: Space = unwrap(&(*s1),&(*CONSTANT_2));
  let v43_7: Space = unwrap(&(v43_5),&(*CONSTANT_3));
  drop(v43_5);
  let v43_8: Space = unwrap(&(v43_7),&(*p0));
  drop(v43_7);
  let mut v43_10 = Space::new();
  let mut v43_10_cursor = (v43_8).read_zipper();
  for v43_10_byte in v43_10_cursor.child_mask().iter() {
    v43_10_cursor.descend_to_byte(v43_10_byte);
    {
    let v43_10_tail = v43_10_cursor.fork_read_zipper();
    let v43_10_head = Path::from_slice(&[v43_10_byte]);
    let mut v44_2 = Space::new();
    let mut v44_2_cursor = (v43_10_tail).read_zipper();
    for v44_2_byte in v44_2_cursor.child_mask().iter() {
      v44_2_cursor.descend_to_byte(v44_2_byte);
      {
      let v44_2_tail = v44_2_cursor.fork_read_zipper();
      let v44_2_head = Path::from_slice(&[v44_2_byte]);
      let v45_2: Path = concat_path(&(v43_10_head),&(v44_2_head));
      let mut v45_3 = Space::new();
      let mut v45_3_cursor = (v44_2_tail).read_zipper();
      for v45_3_byte in v45_3_cursor.child_mask().iter() {
        v45_3_cursor.descend_to_byte(v45_3_byte);
        {
        let v45_3_tail = v45_3_cursor.fork_read_zipper();
        let v45_3_head = Path::from_slice(&[v45_3_byte]);
        let v46_2: Space = subtract(&(v45_3_tail),&(*CONSTANT_6));
        let v46_3: Path = concat_path(&(v45_2),&(v45_3_head));
        let v46_4: Space = wrap(&(v46_2),&(v46_3));
        drop(v46_2);
        drop(v46_3);
        v45_3.join_into((v46_4).clone());
        }
        v45_3_cursor.ascend(1);
      }
      drop(v45_3_cursor);
      drop(v45_2);
      v44_2.join_into((v45_3).clone());
      }
      v44_2_cursor.ascend(1);
    }
    drop(v44_2_cursor);
    v43_10.join_into((v44_2).clone());
    }
    v43_10_cursor.ascend(1);
  }
  drop(v43_10_cursor);
  drop(v43_8);
  let v43_11: Space = wrap(&(v43_10),&(*p1));
  drop(v43_10);
  (v43_11).clone()
}

fn routine_3(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v47_5: Space = unwrap(&(*s1),&(*CONSTANT_1));
  let v47_7: Space = unwrap(&(v47_5),&(*CONSTANT_3));
  drop(v47_5);
  let v47_8: Space = unwrap(&(v47_7),&(*p0));
  drop(v47_7);
  let mut v47_10 = Space::new();
  let mut v47_10_cursor = (v47_8).read_zipper();
  for v47_10_byte in v47_10_cursor.child_mask().iter() {
    v47_10_cursor.descend_to_byte(v47_10_byte);
    {
    let v47_10_tail = v47_10_cursor.fork_read_zipper();
    let v47_10_head = Path::from_slice(&[v47_10_byte]);
    let mut v48_2 = Space::new();
    let mut v48_2_cursor = (v47_10_tail).read_zipper();
    for v48_2_byte in v48_2_cursor.child_mask().iter() {
      v48_2_cursor.descend_to_byte(v48_2_byte);
      {
      let v48_2_tail = v48_2_cursor.fork_read_zipper();
      let v48_2_head = Path::from_slice(&[v48_2_byte]);
      let v49_2: Path = concat_path(&(v47_10_head),&(v48_2_head));
      let mut v49_3 = Space::new();
      let mut v49_3_cursor = (v48_2_tail).read_zipper();
      for v49_3_byte in v49_3_cursor.child_mask().iter() {
        v49_3_cursor.descend_to_byte(v49_3_byte);
        {
        let v49_3_tail = v49_3_cursor.fork_read_zipper();
        let v49_3_head = Path::from_slice(&[v49_3_byte]);
        let v50_2: Space = subtract(&(v49_3_tail),&(*CONSTANT_6));
        let v50_3: Path = concat_path(&(v49_2),&(v49_3_head));
        let v50_4: Space = wrap(&(v50_2),&(v50_3));
        drop(v50_2);
        drop(v50_3);
        v49_3.join_into((v50_4).clone());
        }
        v49_3_cursor.ascend(1);
      }
      drop(v49_3_cursor);
      drop(v49_2);
      v48_2.join_into((v49_3).clone());
      }
      v48_2_cursor.ascend(1);
    }
    drop(v48_2_cursor);
    v47_10.join_into((v48_2).clone());
    }
    v47_10_cursor.ascend(1);
  }
  drop(v47_10_cursor);
  drop(v47_8);
  let v47_11: Space = wrap(&(v47_10),&(*p1));
  drop(v47_10);
  (v47_11).clone()
}

fn routine_4(c: &mut Context, p0: &Path, p1: &Path, s0: &Space) -> Space {
  let v51_3: Space = wrap(&(*s0),&(*p0));
  let v51_4: Space = wrap(&(v51_3),&(*p1));
  drop(v51_3);
  (v51_4).clone()
}

fn routine_5(c: &mut Context, p0: &Path, p1: &Path, s0: &Space, s1: &Space) -> Space {
  let v52_5: Space = unwrap(&(*s1),&(*CONSTANT_1));
  let v52_7: Space = unwrap(&(v52_5),&(*CONSTANT_3));
  drop(v52_5);
  let v52_8: Space = unwrap(&(v52_7),&(*p0));
  drop(v52_7);
  let mut v52_10 = Space::new();
  let mut v52_10_cursor = (v52_8).read_zipper();
  for v52_10_byte in v52_10_cursor.child_mask().iter() {
    v52_10_cursor.descend_to_byte(v52_10_byte);
    {
    let v52_10_tail = v52_10_cursor.fork_read_zipper();
    let v52_10_head = Path::from_slice(&[v52_10_byte]);
    let mut v53_2 = Space::new();
    let mut v53_2_cursor = (v52_10_tail).read_zipper();
    for v53_2_byte in v53_2_cursor.child_mask().iter() {
      v53_2_cursor.descend_to_byte(v53_2_byte);
      {
      let v53_2_tail = v53_2_cursor.fork_read_zipper();
      let v53_2_head = Path::from_slice(&[v53_2_byte]);
      let v54_2: Path = concat_path(&(v52_10_head),&(v53_2_head));
      let mut v54_3 = Space::new();
      let mut v54_3_cursor = (v53_2_tail).read_zipper();
      for v54_3_byte in v54_3_cursor.child_mask().iter() {
        v54_3_cursor.descend_to_byte(v54_3_byte);
        {
        let v54_3_tail = v54_3_cursor.fork_read_zipper();
        let v54_3_head = Path::from_slice(&[v54_3_byte]);
        let v55_2: Space = subtract(&(v54_3_tail),&(*CONSTANT_6));
        let v55_3: Path = concat_path(&(v54_2),&(v54_3_head));
        let v55_4: Space = wrap(&(v55_2),&(v55_3));
        drop(v55_2);
        drop(v55_3);
        v54_3.join_into((v55_4).clone());
        }
        v54_3_cursor.ascend(1);
      }
      drop(v54_3_cursor);
      drop(v54_2);
      v53_2.join_into((v54_3).clone());
      }
      v53_2_cursor.ascend(1);
    }
    drop(v53_2_cursor);
    v52_10.join_into((v53_2).clone());
    }
    v52_10_cursor.ascend(1);
  }
  drop(v52_10_cursor);
  drop(v52_8);
  let v52_11: Space = wrap(&(v52_10),&(*p1));
  drop(v52_10);
  (v52_11).clone()
}

pub fn entry(c: &mut Context, e: &Env) -> Space { routine_0(c,e.space(0)) }

}
fn main() { run(|id,c,e| match id { 0 => program_0::entry(c,e), _ => panic!("unknown program") }); }
