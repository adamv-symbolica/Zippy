# Rust cornerstone review

36 logical cases, each compiled from its optimized executor graph for three byte encodings.
Each case contains the symbolic source, Rust translation units, graph dumps,
wire-protocol inputs, codeword dictionary and the independent Scala trie result.
Runtime PathMap labels are actual bytes 0..255; only protocol labels use byte+1.
No encoding dictionary is loaded into a runtime space.

Build the runtime with `cd runtime && cargo build --release --locked`.
Compile a source with `rustc --edition=2024 -O -C target-cpu=native
-L dependency=runtime/target/release/deps
--extern zippy_pathmap=runtime/target/release/libzippy_pathmap.rlib CASE.rs -o program`.
Run `./program < CASE.input.txt`. Use the repository's `tools/check_cornerstone_rust.py`
to compile every source and compare its decoded result with expected.json.
For large generated files use `-C opt-level=LEVEL -C codegen-units=16` instead of
`-O`, where LEVEL is the manifest's rustOptLevel (1 above 500k logical source characters and
0 above 2M, excluding concrete kernel namespace qualification); the shared runtime remains release level 3.
