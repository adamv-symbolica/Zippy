# product restricted by one first-level prefix — 30000 x 30000 product, 30000 result paths

Family: `large`. The entry expression and reachable symbolic routines are in [symbolic.zippy](symbolic.zippy).

| Generated source | Encoding | Source bytes | Host callbacks | Standalone |
|---|---|---:|---:|---|
| [symbols.cpp](symbols.cpp) | symbol labels | 1443 | 0 | true |
 [bits.cpp](bits.cpp) | Fibonacci-coded intern IDs | 1444 | 0 | true |
 [bytes.cpp](bytes.cpp) | four-byte big-endian intern IDs | 1444 | 0 | true |

Each translation unit contains `main`, the generated expression functions, and all reachable routines.
[encodings.json](encodings.json) maps every interned symbol to its actual bit and byte codewords.
The corresponding `*.input.txt` contains the numeric protocol request for this exact fixture;
`*.bindings.json` identifies environment slots and symbolic labels. Digit labels are offset by one (OpenFst reserves zero).
The path slot list includes routine-local slots; the top-level request has no free path bindings.
A callback count above zero requires the JVM callback bridge or explicit native function bindings;
its input file alone cannot supply those callbacks. See the bundle README for compilation.
