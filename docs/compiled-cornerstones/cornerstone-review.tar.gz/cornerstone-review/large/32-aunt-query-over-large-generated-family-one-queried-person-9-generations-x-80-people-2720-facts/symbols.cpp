#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n3(Context&, const Env&);
static ZIPPY_NOINLINE Path n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Path n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Space n13(Context&, const Env&);
static ZIPPY_NOINLINE Space n14(Context&, const Env&);
static ZIPPY_NOINLINE Space n15(Context&, const Env&);
static ZIPPY_NOINLINE Path n16(Context&, const Env&);
static ZIPPY_NOINLINE Path n17(Context&, const Env&);
static ZIPPY_NOINLINE Path n18(Context&, const Env&);
static ZIPPY_NOINLINE Space n19(Context&, const Env&);
static ZIPPY_NOINLINE Space n20(Context&, const Env&);
static ZIPPY_NOINLINE Path n21(Context&, const Env&);
static ZIPPY_NOINLINE Space n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n23(Context&, const Env&);
static ZIPPY_NOINLINE Path n24(Context&, const Env&);
static ZIPPY_NOINLINE Space n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Path n27(Context&, const Env&);
static ZIPPY_NOINLINE Path n28(Context&, const Env&);
static ZIPPY_NOINLINE Path n29(Context&, const Env&);
static ZIPPY_NOINLINE Space n30(Context&, const Env&);
static ZIPPY_NOINLINE Space n31(Context&, const Env&);
static ZIPPY_NOINLINE Path n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n1(c,e),n2(c,e)}; Env n; n.spaces[0]=sv[0];n.spaces[1]=sv[1];  return routine_0(c,n); }
static ZIPPY_NOINLINE Path n4(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Path n8(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n17(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n18(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n16(Context& c, const Env& e) { auto a=n17(c,e); auto b=n18(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n19(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n15(Context& c, const Env& e) { auto p=n16(c,e); return unwrap(n19(c,e),p); }
static ZIPPY_NOINLINE Path n21(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n22(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n20(Context& c, const Env& e) { auto p=n21(c,e); return unwrap(n22(c,e),p); }
static ZIPPY_NOINLINE Space n14(Context& c, const Env& e) { auto b=n15(c,e); auto a=n20(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n13(Context& c, const Env& e) { return tails_union(n14(c,e)); }
static ZIPPY_NOINLINE Path n24(Context& c, const Env& e) { return Path{3}; }
static ZIPPY_NOINLINE Space n25(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n23(Context& c, const Env& e) { auto p=n24(c,e); return unwrap(n25(c,e),p); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { auto b=n13(c,e); auto a=n23(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { return tails_union(n12(c,e)); }
static ZIPPY_NOINLINE Path n28(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n29(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n27(Context& c, const Env& e) { auto a=n28(c,e); auto b=n29(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n30(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { auto p=n27(c,e); return unwrap(n30(c,e),p); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { auto a=n11(c,e); auto b=n26(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n32(Context& c, const Env& e) { return Path{4}; }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n31(Context& c, const Env& e) { auto p=n32(c,e); return unwrap(n33(c,e),p); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { auto a=n10(c,e); auto b=n31(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { auto p=n8(c,e); return wrap(n9(c,e),p); }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return iterate(c,e,n6(c,e),0,-1,n7); }
static ZIPPY_NOINLINE Space n3(Context& c, const Env& e) { auto p=n4(c,e); return wrap(n5(c,e),p); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n3(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"4 1 4 65 117 110 116 2 5 99 104 105 108 100 3 6 112 97 114 101 110 116 4 6 102 101 109 97 108 101"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
