#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_3(Context&, const Env&);
static ZIPPY_NOINLINE Space n3(Context&, const Env&);
static ZIPPY_NOINLINE Path n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Space n13(Context&, const Env&);
static ZIPPY_NOINLINE Path n14(Context&, const Env&);
static ZIPPY_NOINLINE Path n15(Context&, const Env&);
static ZIPPY_NOINLINE Path n16(Context&, const Env&);
static ZIPPY_NOINLINE Path n17(Context&, const Env&);
static ZIPPY_NOINLINE Path n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n19(Context&, const Env&);
static ZIPPY_NOINLINE Path n20(Context&, const Env&);
static ZIPPY_NOINLINE Path n21(Context&, const Env&);
static ZIPPY_NOINLINE Path n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n23(Context&, const Env&);
static ZIPPY_NOINLINE Space n24(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_1(Context&, const Env&);
static ZIPPY_NOINLINE Space n25(Context&, const Env&);
static ZIPPY_NOINLINE Path n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Space n29(Context&, const Env&);
static ZIPPY_NOINLINE Space n30(Context&, const Env&);
static ZIPPY_NOINLINE Space n31(Context&, const Env&);
static ZIPPY_NOINLINE Space n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Path n34(Context&, const Env&);
static ZIPPY_NOINLINE Path n35(Context&, const Env&);
static ZIPPY_NOINLINE Path n36(Context&, const Env&);
static ZIPPY_NOINLINE Space n37(Context&, const Env&);
static ZIPPY_NOINLINE Space n38(Context&, const Env&);
static ZIPPY_NOINLINE Path n39(Context&, const Env&);
static ZIPPY_NOINLINE Space n40(Context&, const Env&);
static ZIPPY_NOINLINE Space n41(Context&, const Env&);
static ZIPPY_NOINLINE Space n42(Context&, const Env&);
static ZIPPY_NOINLINE Space n43(Context&, const Env&);
static ZIPPY_NOINLINE Space n44(Context&, const Env&);
static ZIPPY_NOINLINE Space n45(Context&, const Env&);
static ZIPPY_NOINLINE Space n46(Context&, const Env&);
static ZIPPY_NOINLINE Space n47(Context&, const Env&);
static ZIPPY_NOINLINE Path n48(Context&, const Env&);
static ZIPPY_NOINLINE Path n49(Context&, const Env&);
static ZIPPY_NOINLINE Path n50(Context&, const Env&);
static ZIPPY_NOINLINE Path n51(Context&, const Env&);
static ZIPPY_NOINLINE Path n52(Context&, const Env&);
static ZIPPY_NOINLINE Path n53(Context&, const Env&);
static ZIPPY_NOINLINE Path n54(Context&, const Env&);
static ZIPPY_NOINLINE Path n55(Context&, const Env&);
static ZIPPY_NOINLINE Space n56(Context&, const Env&);
static ZIPPY_NOINLINE Space n57(Context&, const Env&);
static ZIPPY_NOINLINE Path n58(Context&, const Env&);
static ZIPPY_NOINLINE Space n59(Context&, const Env&);
static ZIPPY_NOINLINE Space n60(Context&, const Env&);
static ZIPPY_NOINLINE Space n61(Context&, const Env&);
static ZIPPY_NOINLINE Space n62(Context&, const Env&);
static ZIPPY_NOINLINE Space n63(Context&, const Env&);
static ZIPPY_NOINLINE Space n64(Context&, const Env&);
static ZIPPY_NOINLINE Space n65(Context&, const Env&);
static ZIPPY_NOINLINE Space n66(Context&, const Env&);
static ZIPPY_NOINLINE Path n67(Context&, const Env&);
static ZIPPY_NOINLINE Path n68(Context&, const Env&);
static ZIPPY_NOINLINE Path n69(Context&, const Env&);
static ZIPPY_NOINLINE Path n70(Context&, const Env&);
static ZIPPY_NOINLINE Path n71(Context&, const Env&);
static ZIPPY_NOINLINE Path n72(Context&, const Env&);
static ZIPPY_NOINLINE Path n73(Context&, const Env&);
static ZIPPY_NOINLINE Path n74(Context&, const Env&);
static ZIPPY_NOINLINE Space n75(Context&, const Env&);
static ZIPPY_NOINLINE Space n76(Context&, const Env&);
static ZIPPY_NOINLINE Path n77(Context&, const Env&);
static ZIPPY_NOINLINE Path n78(Context&, const Env&);
static ZIPPY_NOINLINE Path n79(Context&, const Env&);
static ZIPPY_NOINLINE Space n80(Context&, const Env&);
static ZIPPY_NOINLINE Space n81(Context&, const Env&);
static ZIPPY_NOINLINE Path n82(Context&, const Env&);
static ZIPPY_NOINLINE Space n83(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_2(Context&, const Env&);
static ZIPPY_NOINLINE Space n84(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n85(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n1(c,e),n2(c,e)}; Env n; n.spaces[0]=sv[0];n.spaces[1]=sv[1];  return routine_3(c,n); }
static ZIPPY_NOINLINE Path n4(Context& c, const Env& e) { return Path{1,1,3,214}; }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Path n18(Context& c, const Env& e) { return Path{}; }
static ZIPPY_NOINLINE Path n19(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n17(Context& c, const Env& e) { auto a=n18(c,e); auto b=n19(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n20(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n16(Context& c, const Env& e) { auto a=n17(c,e); auto b=n20(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n21(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n15(Context& c, const Env& e) { auto a=n16(c,e); auto b=n21(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n22(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Path n14(Context& c, const Env& e) { auto a=n15(c,e); auto b=n22(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n23(Context& c, const Env& e) { return e.spaces.at(5); }
static ZIPPY_NOINLINE Space n24(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n13(Context& c, const Env& e) { std::vector<Path> pv{n14(c,e)}; std::vector<Space> sv{n23(c,e),n24(c,e)}; Env n; n.paths[4]=pv[0];n.spaces[6]=sv[0];n.spaces[0]=sv[1];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { return iterate(c,e,n12(c,e),3,5,n13); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { return iterate(c,e,n10(c,e),2,4,n11); }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { return iterate(c,e,n8(c,e),1,3,n9); }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return iterate(c,e,n6(c,e),0,2,n7); }
static ZIPPY_NOINLINE Space n3(Context& c, const Env& e) { auto p=n4(c,e); return wrap(n5(c,e),p); }
static ZIPPY_NOINLINE Space routine_3(Context& c,const Env& e) { return n3(c,e); }
static ZIPPY_NOINLINE Path n26(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n35(Context& c, const Env& e) { return Path{1,1,3,213}; }
static ZIPPY_NOINLINE Path n36(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n34(Context& c, const Env& e) { auto a=n35(c,e); auto b=n36(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n37(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { auto p=n34(c,e); return unwrap(n37(c,e),p); }
static ZIPPY_NOINLINE Path n39(Context& c, const Env& e) { return Path{1,1,3,213}; }
static ZIPPY_NOINLINE Space n40(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n38(Context& c, const Env& e) { auto p=n39(c,e); return unwrap(n40(c,e),p); }
static ZIPPY_NOINLINE Space n32(Context& c, const Env& e) { auto b=n33(c,e); auto a=n38(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n42(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n44(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n46(Context& c, const Env& e) { return e.spaces.at(9); }
static ZIPPY_NOINLINE Path n52(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Path n51(Context& c, const Env& e) { auto a=n18(c,e); auto b=n52(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n53(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Path n50(Context& c, const Env& e) { auto a=n51(c,e); auto b=n53(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n54(Context& c, const Env& e) { return e.paths.at(7); }
static ZIPPY_NOINLINE Path n49(Context& c, const Env& e) { auto a=n50(c,e); auto b=n54(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n55(Context& c, const Env& e) { return e.paths.at(8); }
static ZIPPY_NOINLINE Path n48(Context& c, const Env& e) { auto a=n49(c,e); auto b=n55(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n56(Context& c, const Env& e) { return e.spaces.at(10); }
static ZIPPY_NOINLINE Space n47(Context& c, const Env& e) { std::vector<Path> pv{n48(c,e)}; std::vector<Space> sv{n56(c,e)}; Env n; n.paths[9]=pv[0];n.spaces[11]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n45(Context& c, const Env& e) { return iterate(c,e,n46(c,e),8,10,n47); }
static ZIPPY_NOINLINE Space n43(Context& c, const Env& e) { return iterate(c,e,n44(c,e),7,9,n45); }
static ZIPPY_NOINLINE Space n41(Context& c, const Env& e) { return iterate(c,e,n42(c,e),6,8,n43); }
static ZIPPY_NOINLINE Space n31(Context& c, const Env& e) { return iterate(c,e,n32(c,e),5,7,n41); }
static ZIPPY_NOINLINE Path n58(Context& c, const Env& e) { return Path{1,1,3,211}; }
static ZIPPY_NOINLINE Space n59(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n57(Context& c, const Env& e) { auto p=n58(c,e); return unwrap(n59(c,e),p); }
static ZIPPY_NOINLINE Space n30(Context& c, const Env& e) { auto b=n31(c,e); auto a=n57(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n61(Context& c, const Env& e) { return e.spaces.at(12); }
static ZIPPY_NOINLINE Space n63(Context& c, const Env& e) { return e.spaces.at(13); }
static ZIPPY_NOINLINE Space n65(Context& c, const Env& e) { return e.spaces.at(14); }
static ZIPPY_NOINLINE Path n71(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n70(Context& c, const Env& e) { auto a=n18(c,e); auto b=n71(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n72(Context& c, const Env& e) { return e.paths.at(11); }
static ZIPPY_NOINLINE Path n69(Context& c, const Env& e) { auto a=n70(c,e); auto b=n72(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n73(Context& c, const Env& e) { return e.paths.at(12); }
static ZIPPY_NOINLINE Path n68(Context& c, const Env& e) { auto a=n69(c,e); auto b=n73(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n74(Context& c, const Env& e) { return e.paths.at(13); }
static ZIPPY_NOINLINE Path n67(Context& c, const Env& e) { auto a=n68(c,e); auto b=n74(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n75(Context& c, const Env& e) { return e.spaces.at(15); }
static ZIPPY_NOINLINE Space n66(Context& c, const Env& e) { std::vector<Path> pv{n67(c,e)}; std::vector<Space> sv{n75(c,e)}; Env n; n.paths[14]=pv[0];n.spaces[16]=sv[0];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n64(Context& c, const Env& e) { return iterate(c,e,n65(c,e),13,15,n66); }
static ZIPPY_NOINLINE Space n62(Context& c, const Env& e) { return iterate(c,e,n63(c,e),12,14,n64); }
static ZIPPY_NOINLINE Space n60(Context& c, const Env& e) { return iterate(c,e,n61(c,e),11,13,n62); }
static ZIPPY_NOINLINE Space n29(Context& c, const Env& e) { return iterate(c,e,n30(c,e),10,12,n60); }
static ZIPPY_NOINLINE Path n78(Context& c, const Env& e) { return Path{1,1,3,213}; }
static ZIPPY_NOINLINE Path n79(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n77(Context& c, const Env& e) { auto a=n78(c,e); auto b=n79(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n80(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n76(Context& c, const Env& e) { auto p=n77(c,e); return unwrap(n80(c,e),p); }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { auto a=n29(c,e); auto b=n76(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n82(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n83(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n81(Context& c, const Env& e) { auto p=n82(c,e); return unwrap(n83(c,e),p); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { auto a=n28(c,e); auto b=n81(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n25(Context& c, const Env& e) { auto p=n26(c,e); return wrap(n27(c,e),p); }
static ZIPPY_NOINLINE Space routine_1(Context& c,const Env& e) { return n25(c,e); }
static ZIPPY_NOINLINE Space n84(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Space routine_2(Context& c,const Env& e) { return n84(c,e); }
static ZIPPY_NOINLINE Space n85(Context& c, const Env& e) { return e.spaces.at(16); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n85(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
