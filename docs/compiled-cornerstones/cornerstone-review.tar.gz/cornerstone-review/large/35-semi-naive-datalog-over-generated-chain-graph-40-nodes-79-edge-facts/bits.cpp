#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,2,1,2,1,1,2,2};
static const Path constant_1 = Path{2,2};
static const Space constant_2 = literal_text("1 0 ");
static const Space constant_3 = literal_text("1 1 2");
static const Space constant_4 = singleton(Path{});
static const Path constant_5 = Path{1,2,1,1,2,1,1,2,2};
static const Path constant_6 = Path{2,1,1,1,2,1,1,2,2};
static const Path constant_7 = Path{1,1,2,1,2,1,1,2,2,2,1,1,1,2,1,1,2,2};
static const Path constant_8 = Path{1,2,1,1,2,1,1,2,2,2,1,1,1,2,1,1,2,2};
static Space routine_0(Context& c, const Space* s0);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_78(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_89(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_79(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_65(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_82(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_66(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_83(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_70(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_87(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_71(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_88(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_44(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_30(Context& c, const Path& p0, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_72(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_110(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_80(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_56(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_73(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_111(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_64(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_24(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_38(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_98(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_144(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_104(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_156(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_120(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_164(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_99(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_145(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_105(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_157(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_121(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_165(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_85(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_100(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_68(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Space& s0);
static Space routine_116(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_57(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_160(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_74(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_168(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_86(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_101(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_69(Context& c, const Path& p0, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Space& s0);
static Space routine_117(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_75(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_142(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_178(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_151(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_171(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_143(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_175(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_179(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_163(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_128(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_140(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_112(Context& c, const Path& p0, const Space& s0);
static Space routine_96(Context& c, const Path& p0, const Space& s0);
static Space routine_152(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_172(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_102(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_176(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_158(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_118(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_180(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_166(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_129(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_141(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_113(Context& c, const Path& p0, const Space& s0);
static Space routine_97(Context& c, const Path& p0, const Space& s0);
static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_103(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_177(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_159(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_119(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_181(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_67(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_84(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_15(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_0(Context& c, const Space* s0) {
  const Space v0_2 = wrap(bound_space(s0),constant_0);
  const Space v0_4 = unwrap(bound_space(s0),constant_1);
  Space v0_14_result;
  for (int v0_14_label = 1; v0_14_label <= 2; ++v0_14_label) {
    const Space v0_14_tail = child(v0_4,v0_14_label);
    if (v0_14_tail.empty()) continue;
    const Path v0_14_head{v0_14_label};
    const Space v1_2 = singleton(v0_14_head);
    const Space v1_3 = intersect(constant_3,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_4 : Space{});
    const Space v1_5 = subtract(constant_2,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      Space v2_6_result;
      for (int v2_6_label = 1; v2_6_label <= 2; ++v2_6_label) {
        const Space v2_6_tail = child(v0_14_tail,v2_6_label);
        if (v2_6_tail.empty()) continue;
        const Path v2_6_head{v2_6_label};
        const Space v3_2 = singleton(v2_6_head);
        const Space v3_3 = intersect(constant_3,v3_2);
        const Space v3_4 = (has_head(v3_3) ? constant_4 : Space{});
        const Space v3_5 = subtract(constant_2,v3_4);
        Space v3_8;
        if (!v3_5.empty()) {
          const Path v4_6 = concat_path(v0_14_head,v2_6_head);
          const Space v4_7 = routine_1(c, v4_6, v2_6_tail);
          v3_8 = compose(v3_5,v4_7);
        }
        const Space v3_9 = intersect(constant_3,v3_2);
        const Space v3_10 = (has_head(v3_9) ? constant_4 : Space{});
        Space v3_12;
        if (!v3_10.empty()) {
          const Path v5_6 = concat_path(v0_14_head,v2_6_head);
          const Space v5_11 = routine_2(c, v5_6, v2_6_tail);
          v3_12 = compose(v3_10,v5_11);
        }
        const Space v3_13 = unite(v3_8,v3_12);
        v2_6_result = unite(v2_6_result,v3_13);
      }
      const Space v2_6 = std::move(v2_6_result);
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_3,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_4 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      Space v6_10_result;
      for (int v6_10_label = 1; v6_10_label <= 2; ++v6_10_label) {
        const Space v6_10_tail = child(v0_14_tail,v6_10_label);
        if (v6_10_tail.empty()) continue;
        const Path v6_10_head{v6_10_label};
        const Space v7_2 = singleton(v6_10_head);
        const Space v7_3 = intersect(constant_3,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_4 : Space{});
        const Space v7_5 = subtract(constant_2,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v0_14_head,v6_10_head);
          const Space v8_7 = routine_1(c, v8_6, v6_10_tail);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_3,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_4 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v0_14_head,v6_10_head);
          const Space v9_11 = routine_3(c, v9_6, v6_10_tail);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_10_result = unite(v6_10_result,v7_13);
      }
      const Space v6_10 = std::move(v6_10_result);
      v1_11 = compose(v1_9,v6_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_14_result = unite(v0_14_result,v1_12);
  }
  const Space v0_14 = std::move(v0_14_result);
  const Space v0_16 = wrap(v0_14,constant_5);
  const Space v0_17 = unite(v0_2,v0_16);
  Space v0_57 = v0_17;
  for (;;) {
    const Space v10_1 = unwrap(v0_57,constant_0);
    const Space v10_2 = unwrap(v0_57,constant_5);
    const Space v10_3 = unite(v10_1,v10_2);
    const Space v10_4 = wrap(v10_3,constant_0);
    const Space v10_5 = unwrap(v10_1,constant_6);
    Space v10_6_result;
    for (int v10_6_label = 1; v10_6_label <= 2; ++v10_6_label) {
      const Space v10_6_tail = child(v10_5,v10_6_label);
      if (v10_6_tail.empty()) continue;
      const Path v10_6_head{v10_6_label};
      const Space v11_2 = singleton(v10_6_head);
      const Space v11_3 = intersect(constant_3,v11_2);
      const Space v11_4 = (has_head(v11_3) ? constant_4 : Space{});
      const Space v11_5 = subtract(constant_2,v11_4);
      Space v11_7;
      if (!v11_5.empty()) {
        Space v12_6_result;
        for (int v12_6_label = 1; v12_6_label <= 2; ++v12_6_label) {
          const Space v12_6_tail = child(v10_6_tail,v12_6_label);
          if (v12_6_tail.empty()) continue;
          const Path v12_6_head{v12_6_label};
          const Space v13_2 = singleton(v12_6_head);
          const Space v13_3 = intersect(constant_3,v13_2);
          const Space v13_4 = (has_head(v13_3) ? constant_4 : Space{});
          const Space v13_5 = subtract(constant_2,v13_4);
          Space v13_8;
          if (!v13_5.empty()) {
            const Path v14_6 = concat_path(v10_6_head,v12_6_head);
            const Space v14_7 = routine_4(c, v14_6, v12_6_tail, v0_57);
            v13_8 = compose(v13_5,v14_7);
          }
          const Space v13_9 = intersect(constant_3,v13_2);
          const Space v13_10 = (has_head(v13_9) ? constant_4 : Space{});
          Space v13_12;
          if (!v13_10.empty()) {
            const Path v15_6 = concat_path(v10_6_head,v12_6_head);
            const Space v15_11 = routine_5(c, v15_6, v12_6_tail, v0_57);
            v13_12 = compose(v13_10,v15_11);
          }
          const Space v13_13 = unite(v13_8,v13_12);
          v12_6_result = unite(v12_6_result,v13_13);
        }
        const Space v12_6 = std::move(v12_6_result);
        v11_7 = compose(v11_5,v12_6);
      }
      const Space v11_8 = intersect(constant_3,v11_2);
      const Space v11_9 = (has_head(v11_8) ? constant_4 : Space{});
      Space v11_11;
      if (!v11_9.empty()) {
        Space v16_10_result;
        for (int v16_10_label = 1; v16_10_label <= 2; ++v16_10_label) {
          const Space v16_10_tail = child(v10_6_tail,v16_10_label);
          if (v16_10_tail.empty()) continue;
          const Path v16_10_head{v16_10_label};
          const Space v17_2 = singleton(v16_10_head);
          const Space v17_3 = intersect(constant_3,v17_2);
          const Space v17_4 = (has_head(v17_3) ? constant_4 : Space{});
          const Space v17_5 = subtract(constant_2,v17_4);
          Space v17_8;
          if (!v17_5.empty()) {
            const Path v18_6 = concat_path(v10_6_head,v16_10_head);
            const Space v18_7 = routine_4(c, v18_6, v16_10_tail, v0_57);
            v17_8 = compose(v17_5,v18_7);
          }
          const Space v17_9 = intersect(constant_3,v17_2);
          const Space v17_10 = (has_head(v17_9) ? constant_4 : Space{});
          Space v17_12;
          if (!v17_10.empty()) {
            const Path v19_6 = concat_path(v10_6_head,v16_10_head);
            const Space v19_11 = routine_6(c, v19_6, v16_10_tail, v0_57);
            v17_12 = compose(v17_10,v19_11);
          }
          const Space v17_13 = unite(v17_8,v17_12);
          v16_10_result = unite(v16_10_result,v17_13);
        }
        const Space v16_10 = std::move(v16_10_result);
        v11_11 = compose(v11_9,v16_10);
      }
      const Space v11_12 = unite(v11_7,v11_11);
      v10_6_result = unite(v10_6_result,v11_12);
    }
    const Space v10_6 = std::move(v10_6_result);
    const Space v10_7 = unwrap(v10_1,constant_1);
    Space v10_8_result;
    for (int v10_8_label = 1; v10_8_label <= 2; ++v10_8_label) {
      const Space v10_8_tail = child(v10_7,v10_8_label);
      if (v10_8_tail.empty()) continue;
      const Path v10_8_head{v10_8_label};
      const Space v20_2 = singleton(v10_8_head);
      const Space v20_3 = intersect(constant_3,v20_2);
      const Space v20_4 = (has_head(v20_3) ? constant_4 : Space{});
      const Space v20_5 = subtract(constant_2,v20_4);
      Space v20_7;
      if (!v20_5.empty()) {
        Space v21_6_result;
        for (int v21_6_label = 1; v21_6_label <= 2; ++v21_6_label) {
          const Space v21_6_tail = child(v10_8_tail,v21_6_label);
          if (v21_6_tail.empty()) continue;
          const Path v21_6_head{v21_6_label};
          const Space v22_2 = singleton(v21_6_head);
          const Space v22_3 = intersect(constant_3,v22_2);
          const Space v22_4 = (has_head(v22_3) ? constant_4 : Space{});
          const Space v22_5 = subtract(constant_2,v22_4);
          Space v22_8;
          if (!v22_5.empty()) {
            const Path v23_6 = concat_path(v10_8_head,v21_6_head);
            const Space v23_7 = routine_7(c, v23_6, v21_6_tail);
            v22_8 = compose(v22_5,v23_7);
          }
          const Space v22_9 = intersect(constant_3,v22_2);
          const Space v22_10 = (has_head(v22_9) ? constant_4 : Space{});
          Space v22_12;
          if (!v22_10.empty()) {
            const Path v24_6 = concat_path(v10_8_head,v21_6_head);
            const Space v24_11 = routine_8(c, v24_6, v21_6_tail);
            v22_12 = compose(v22_10,v24_11);
          }
          const Space v22_13 = unite(v22_8,v22_12);
          v21_6_result = unite(v21_6_result,v22_13);
        }
        const Space v21_6 = std::move(v21_6_result);
        v20_7 = compose(v20_5,v21_6);
      }
      const Space v20_8 = intersect(constant_3,v20_2);
      const Space v20_9 = (has_head(v20_8) ? constant_4 : Space{});
      Space v20_11;
      if (!v20_9.empty()) {
        Space v25_10_result;
        for (int v25_10_label = 1; v25_10_label <= 2; ++v25_10_label) {
          const Space v25_10_tail = child(v10_8_tail,v25_10_label);
          if (v25_10_tail.empty()) continue;
          const Path v25_10_head{v25_10_label};
          const Space v26_2 = singleton(v25_10_head);
          const Space v26_3 = intersect(constant_3,v26_2);
          const Space v26_4 = (has_head(v26_3) ? constant_4 : Space{});
          const Space v26_5 = subtract(constant_2,v26_4);
          Space v26_8;
          if (!v26_5.empty()) {
            const Path v27_6 = concat_path(v10_8_head,v25_10_head);
            const Space v27_7 = routine_7(c, v27_6, v25_10_tail);
            v26_8 = compose(v26_5,v27_7);
          }
          const Space v26_9 = intersect(constant_3,v26_2);
          const Space v26_10 = (has_head(v26_9) ? constant_4 : Space{});
          Space v26_12;
          if (!v26_10.empty()) {
            const Path v28_6 = concat_path(v10_8_head,v25_10_head);
            const Space v28_11 = routine_9(c, v28_6, v25_10_tail);
            v26_12 = compose(v26_10,v28_11);
          }
          const Space v26_13 = unite(v26_8,v26_12);
          v25_10_result = unite(v25_10_result,v26_13);
        }
        const Space v25_10 = std::move(v25_10_result);
        v20_11 = compose(v20_9,v25_10);
      }
      const Space v20_12 = unite(v20_7,v20_11);
      v10_8_result = unite(v10_8_result,v20_12);
    }
    const Space v10_8 = std::move(v10_8_result);
    const Space v10_9 = unite(v10_6,v10_8);
    const Space v10_10 = unwrap(v10_2,constant_6);
    Space v10_11_result;
    for (int v10_11_label = 1; v10_11_label <= 2; ++v10_11_label) {
      const Space v10_11_tail = child(v10_10,v10_11_label);
      if (v10_11_tail.empty()) continue;
      const Path v10_11_head{v10_11_label};
      const Space v29_2 = singleton(v10_11_head);
      const Space v29_3 = intersect(constant_3,v29_2);
      const Space v29_4 = (has_head(v29_3) ? constant_4 : Space{});
      const Space v29_5 = subtract(constant_2,v29_4);
      Space v29_7;
      if (!v29_5.empty()) {
        Space v30_6_result;
        for (int v30_6_label = 1; v30_6_label <= 2; ++v30_6_label) {
          const Space v30_6_tail = child(v10_11_tail,v30_6_label);
          if (v30_6_tail.empty()) continue;
          const Path v30_6_head{v30_6_label};
          const Space v31_2 = singleton(v30_6_head);
          const Space v31_3 = intersect(constant_3,v31_2);
          const Space v31_4 = (has_head(v31_3) ? constant_4 : Space{});
          const Space v31_5 = subtract(constant_2,v31_4);
          Space v31_8;
          if (!v31_5.empty()) {
            const Path v32_6 = concat_path(v10_11_head,v30_6_head);
            const Space v32_7 = routine_10(c, v32_6, v30_6_tail, v0_57);
            v31_8 = compose(v31_5,v32_7);
          }
          const Space v31_9 = intersect(constant_3,v31_2);
          const Space v31_10 = (has_head(v31_9) ? constant_4 : Space{});
          Space v31_12;
          if (!v31_10.empty()) {
            const Path v33_6 = concat_path(v10_11_head,v30_6_head);
            const Space v33_11 = routine_11(c, v33_6, v30_6_tail, v0_57);
            v31_12 = compose(v31_10,v33_11);
          }
          const Space v31_13 = unite(v31_8,v31_12);
          v30_6_result = unite(v30_6_result,v31_13);
        }
        const Space v30_6 = std::move(v30_6_result);
        v29_7 = compose(v29_5,v30_6);
      }
      const Space v29_8 = intersect(constant_3,v29_2);
      const Space v29_9 = (has_head(v29_8) ? constant_4 : Space{});
      Space v29_11;
      if (!v29_9.empty()) {
        Space v34_10_result;
        for (int v34_10_label = 1; v34_10_label <= 2; ++v34_10_label) {
          const Space v34_10_tail = child(v10_11_tail,v34_10_label);
          if (v34_10_tail.empty()) continue;
          const Path v34_10_head{v34_10_label};
          const Space v35_2 = singleton(v34_10_head);
          const Space v35_3 = intersect(constant_3,v35_2);
          const Space v35_4 = (has_head(v35_3) ? constant_4 : Space{});
          const Space v35_5 = subtract(constant_2,v35_4);
          Space v35_8;
          if (!v35_5.empty()) {
            const Path v36_6 = concat_path(v10_11_head,v34_10_head);
            const Space v36_7 = routine_10(c, v36_6, v34_10_tail, v0_57);
            v35_8 = compose(v35_5,v36_7);
          }
          const Space v35_9 = intersect(constant_3,v35_2);
          const Space v35_10 = (has_head(v35_9) ? constant_4 : Space{});
          Space v35_12;
          if (!v35_10.empty()) {
            const Path v37_6 = concat_path(v10_11_head,v34_10_head);
            const Space v37_11 = routine_12(c, v37_6, v34_10_tail, v0_57);
            v35_12 = compose(v35_10,v37_11);
          }
          const Space v35_13 = unite(v35_8,v35_12);
          v34_10_result = unite(v34_10_result,v35_13);
        }
        const Space v34_10 = std::move(v34_10_result);
        v29_11 = compose(v29_9,v34_10);
      }
      const Space v29_12 = unite(v29_7,v29_11);
      v10_11_result = unite(v10_11_result,v29_12);
    }
    const Space v10_11 = std::move(v10_11_result);
    const Space v10_12 = unite(v10_9,v10_11);
    Space v10_13_result;
    for (int v10_13_label = 1; v10_13_label <= 2; ++v10_13_label) {
      const Space v10_13_tail = child(v10_10,v10_13_label);
      if (v10_13_tail.empty()) continue;
      const Path v10_13_head{v10_13_label};
      const Space v38_2 = singleton(v10_13_head);
      const Space v38_3 = intersect(constant_3,v38_2);
      const Space v38_4 = (has_head(v38_3) ? constant_4 : Space{});
      const Space v38_5 = subtract(constant_2,v38_4);
      Space v38_7;
      if (!v38_5.empty()) {
        Space v39_6_result;
        for (int v39_6_label = 1; v39_6_label <= 2; ++v39_6_label) {
          const Space v39_6_tail = child(v10_13_tail,v39_6_label);
          if (v39_6_tail.empty()) continue;
          const Path v39_6_head{v39_6_label};
          const Space v40_2 = singleton(v39_6_head);
          const Space v40_3 = intersect(constant_3,v40_2);
          const Space v40_4 = (has_head(v40_3) ? constant_4 : Space{});
          const Space v40_5 = subtract(constant_2,v40_4);
          Space v40_8;
          if (!v40_5.empty()) {
            const Path v41_6 = concat_path(v10_13_head,v39_6_head);
            const Space v41_7 = routine_13(c, v41_6, v39_6_tail, v0_57);
            v40_8 = compose(v40_5,v41_7);
          }
          const Space v40_9 = intersect(constant_3,v40_2);
          const Space v40_10 = (has_head(v40_9) ? constant_4 : Space{});
          Space v40_12;
          if (!v40_10.empty()) {
            const Path v42_6 = concat_path(v10_13_head,v39_6_head);
            const Space v42_11 = routine_14(c, v42_6, v39_6_tail, v0_57);
            v40_12 = compose(v40_10,v42_11);
          }
          const Space v40_13 = unite(v40_8,v40_12);
          v39_6_result = unite(v39_6_result,v40_13);
        }
        const Space v39_6 = std::move(v39_6_result);
        v38_7 = compose(v38_5,v39_6);
      }
      const Space v38_8 = intersect(constant_3,v38_2);
      const Space v38_9 = (has_head(v38_8) ? constant_4 : Space{});
      Space v38_11;
      if (!v38_9.empty()) {
        Space v43_10_result;
        for (int v43_10_label = 1; v43_10_label <= 2; ++v43_10_label) {
          const Space v43_10_tail = child(v10_13_tail,v43_10_label);
          if (v43_10_tail.empty()) continue;
          const Path v43_10_head{v43_10_label};
          const Space v44_2 = singleton(v43_10_head);
          const Space v44_3 = intersect(constant_3,v44_2);
          const Space v44_4 = (has_head(v44_3) ? constant_4 : Space{});
          const Space v44_5 = subtract(constant_2,v44_4);
          Space v44_8;
          if (!v44_5.empty()) {
            const Path v45_6 = concat_path(v10_13_head,v43_10_head);
            const Space v45_7 = routine_13(c, v45_6, v43_10_tail, v0_57);
            v44_8 = compose(v44_5,v45_7);
          }
          const Space v44_9 = intersect(constant_3,v44_2);
          const Space v44_10 = (has_head(v44_9) ? constant_4 : Space{});
          Space v44_12;
          if (!v44_10.empty()) {
            const Path v46_6 = concat_path(v10_13_head,v43_10_head);
            const Space v46_11 = routine_15(c, v46_6, v43_10_tail, v0_57);
            v44_12 = compose(v44_10,v46_11);
          }
          const Space v44_13 = unite(v44_8,v44_12);
          v43_10_result = unite(v43_10_result,v44_13);
        }
        const Space v43_10 = std::move(v43_10_result);
        v38_11 = compose(v38_9,v43_10);
      }
      const Space v38_12 = unite(v38_7,v38_11);
      v10_13_result = unite(v10_13_result,v38_12);
    }
    const Space v10_13 = std::move(v10_13_result);
    const Space v10_14 = unite(v10_12,v10_13);
    const Space v10_15 = unwrap(v0_57,constant_7);
    const Space v10_16 = subtract(v10_14,v10_15);
    const Space v10_17 = unwrap(v0_57,constant_8);
    const Space v10_18 = subtract(v10_16,v10_17);
    const Space v10_19 = wrap(v10_18,constant_8);
    const Space v10_20 = unite(v10_4,v10_19);
    const Space v10_21 = unite(v10_20,v0_57);
    Space v0_57_next = unite(v0_57,v10_21);
    if (equal(v0_57_next,v0_57)) break;
    v0_57 = std::move(v0_57_next);
  }
  const Space v0_58 = unwrap(v0_57,constant_7);
  return v0_58;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v47_11_result;
  for (int v47_11_label = 1; v47_11_label <= 2; ++v47_11_label) {
    const Space v47_11_tail = child(s0,v47_11_label);
    if (v47_11_tail.empty()) continue;
    const Path v47_11_head{v47_11_label};
    const Space v48_2 = singleton(v47_11_head);
    const Space v48_3 = intersect(constant_3,v48_2);
    const Space v48_4 = (has_head(v48_3) ? constant_4 : Space{});
    const Space v48_5 = subtract(constant_2,v48_4);
    Space v48_8;
    if (!v48_5.empty()) {
      const Path v49_6 = concat_path(p0,v47_11_head);
      Space v49_7_result;
      for (int v49_7_label = 1; v49_7_label <= 2; ++v49_7_label) {
        const Space v49_7_tail = child(v47_11_tail,v49_7_label);
        if (v49_7_tail.empty()) continue;
        const Path v49_7_head{v49_7_label};
        const Space v50_2 = singleton(v49_7_head);
        const Space v50_3 = intersect(constant_3,v50_2);
        const Space v50_4 = (has_head(v50_3) ? constant_4 : Space{});
        const Space v50_5 = subtract(constant_2,v50_4);
        Space v50_8;
        if (!v50_5.empty()) {
          const Path v51_6 = concat_path(v49_6,v49_7_head);
          const Space v51_7 = routine_16(c, v51_6, v49_7_tail);
          v50_8 = compose(v50_5,v51_7);
        }
        const Space v50_9 = intersect(constant_3,v50_2);
        const Space v50_10 = (has_head(v50_9) ? constant_4 : Space{});
        Space v50_12;
        if (!v50_10.empty()) {
          const Path v52_6 = concat_path(v49_6,v49_7_head);
          const Space v52_11 = routine_17(c, v52_6, v49_7_tail);
          v50_12 = compose(v50_10,v52_11);
        }
        const Space v50_13 = unite(v50_8,v50_12);
        v49_7_result = unite(v49_7_result,v50_13);
      }
      const Space v49_7 = std::move(v49_7_result);
      v48_8 = compose(v48_5,v49_7);
    }
    const Space v48_9 = intersect(constant_3,v48_2);
    const Space v48_10 = (has_head(v48_9) ? constant_4 : Space{});
    Space v48_12;
    if (!v48_10.empty()) {
      const Path v53_6 = concat_path(p0,v47_11_head);
      Space v53_11_result;
      for (int v53_11_label = 1; v53_11_label <= 2; ++v53_11_label) {
        const Space v53_11_tail = child(v47_11_tail,v53_11_label);
        if (v53_11_tail.empty()) continue;
        const Path v53_11_head{v53_11_label};
        const Space v54_2 = singleton(v53_11_head);
        const Space v54_3 = intersect(constant_3,v54_2);
        const Space v54_4 = (has_head(v54_3) ? constant_4 : Space{});
        const Space v54_5 = subtract(constant_2,v54_4);
        Space v54_8;
        if (!v54_5.empty()) {
          const Path v55_6 = concat_path(v53_6,v53_11_head);
          const Space v55_7 = routine_16(c, v55_6, v53_11_tail);
          v54_8 = compose(v54_5,v55_7);
        }
        const Space v54_9 = intersect(constant_3,v54_2);
        const Space v54_10 = (has_head(v54_9) ? constant_4 : Space{});
        Space v54_12;
        if (!v54_10.empty()) {
          const Path v56_6 = concat_path(v53_6,v53_11_head);
          const Space v56_11 = routine_3(c, v56_6, v53_11_tail);
          v54_12 = compose(v54_10,v56_11);
        }
        const Space v54_13 = unite(v54_8,v54_12);
        v53_11_result = unite(v53_11_result,v54_13);
      }
      const Space v53_11 = std::move(v53_11_result);
      v48_12 = compose(v48_10,v53_11);
    }
    const Space v48_13 = unite(v48_8,v48_12);
    v47_11_result = unite(v47_11_result,v48_13);
  }
  const Space v47_11 = std::move(v47_11_result);
  return v47_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  Space v57_11_result;
  for (int v57_11_label = 1; v57_11_label <= 2; ++v57_11_label) {
    const Space v57_11_tail = child(s0,v57_11_label);
    if (v57_11_tail.empty()) continue;
    const Path v57_11_head{v57_11_label};
    const Space v58_2 = singleton(v57_11_head);
    const Space v58_3 = intersect(constant_3,v58_2);
    const Space v58_4 = (has_head(v58_3) ? constant_4 : Space{});
    const Space v58_5 = subtract(constant_2,v58_4);
    Space v58_8;
    if (!v58_5.empty()) {
      const Path v59_6 = concat_path(p0,v57_11_head);
      Space v59_7_result;
      for (int v59_7_label = 1; v59_7_label <= 2; ++v59_7_label) {
        const Space v59_7_tail = child(v57_11_tail,v59_7_label);
        if (v59_7_tail.empty()) continue;
        const Path v59_7_head{v59_7_label};
        const Space v60_2 = singleton(v59_7_head);
        const Space v60_3 = intersect(constant_3,v60_2);
        const Space v60_4 = (has_head(v60_3) ? constant_4 : Space{});
        const Space v60_5 = subtract(constant_2,v60_4);
        Space v60_8;
        if (!v60_5.empty()) {
          const Path v61_6 = concat_path(v59_6,v59_7_head);
          const Space v61_7 = routine_16(c, v61_6, v59_7_tail);
          v60_8 = compose(v60_5,v61_7);
        }
        const Space v60_9 = intersect(constant_3,v60_2);
        const Space v60_10 = (has_head(v60_9) ? constant_4 : Space{});
        Space v60_12;
        if (!v60_10.empty()) {
          const Path v62_6 = concat_path(v59_6,v59_7_head);
          const Space v62_11 = routine_17(c, v62_6, v59_7_tail);
          v60_12 = compose(v60_10,v62_11);
        }
        const Space v60_13 = unite(v60_8,v60_12);
        v59_7_result = unite(v59_7_result,v60_13);
      }
      const Space v59_7 = std::move(v59_7_result);
      v58_8 = compose(v58_5,v59_7);
    }
    const Space v58_9 = intersect(constant_3,v58_2);
    const Space v58_10 = (has_head(v58_9) ? constant_4 : Space{});
    Space v58_12;
    if (!v58_10.empty()) {
      const Path v63_6 = concat_path(p0,v57_11_head);
      Space v63_11_result;
      for (int v63_11_label = 1; v63_11_label <= 2; ++v63_11_label) {
        const Space v63_11_tail = child(v57_11_tail,v63_11_label);
        if (v63_11_tail.empty()) continue;
        const Path v63_11_head{v63_11_label};
        const Space v64_2 = singleton(v63_11_head);
        const Space v64_3 = intersect(constant_3,v64_2);
        const Space v64_4 = (has_head(v64_3) ? constant_4 : Space{});
        const Space v64_5 = subtract(constant_2,v64_4);
        Space v64_7;
        if (!v64_5.empty()) {
          const Space v65_6 = routine_18(c, v63_11_head, v63_6, v63_11_tail);
          v64_7 = compose(v64_5,v65_6);
        }
        const Space v64_8 = intersect(constant_3,v64_2);
        const Space v64_9 = (has_head(v64_8) ? constant_4 : Space{});
        Space v64_11;
        if (!v64_9.empty()) {
          const Space v66_10 = routine_19(c, v63_11_head, v63_6, v63_11_tail);
          v64_11 = compose(v64_9,v66_10);
        }
        const Space v64_12 = unite(v64_7,v64_11);
        v63_11_result = unite(v63_11_result,v64_12);
      }
      const Space v63_11 = std::move(v63_11_result);
      v58_12 = compose(v58_10,v63_11);
    }
    const Space v58_13 = unite(v58_8,v58_12);
    v57_11_result = unite(v57_11_result,v58_13);
  }
  const Space v57_11 = std::move(v57_11_result);
  return v57_11;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  Space v67_11_result;
  for (int v67_11_label = 1; v67_11_label <= 2; ++v67_11_label) {
    const Space v67_11_tail = child(s0,v67_11_label);
    if (v67_11_tail.empty()) continue;
    const Path v67_11_head{v67_11_label};
    const Space v68_2 = singleton(v67_11_head);
    const Space v68_3 = intersect(constant_3,v68_2);
    const Space v68_4 = (has_head(v68_3) ? constant_4 : Space{});
    const Space v68_5 = subtract(constant_2,v68_4);
    Space v68_7;
    if (!v68_5.empty()) {
      Space v69_6_result;
      for (int v69_6_label = 1; v69_6_label <= 2; ++v69_6_label) {
        const Space v69_6_tail = child(v67_11_tail,v69_6_label);
        if (v69_6_tail.empty()) continue;
        const Path v69_6_head{v69_6_label};
        const Space v70_2 = singleton(v69_6_head);
        const Space v70_3 = intersect(constant_3,v70_2);
        const Space v70_4 = (has_head(v70_3) ? constant_4 : Space{});
        const Space v70_5 = subtract(constant_2,v70_4);
        Space v70_8;
        if (!v70_5.empty()) {
          const Path v71_6 = concat_path(v67_11_head,v69_6_head);
          const Space v71_7 = routine_20(c, v71_6, p0, v69_6_tail);
          v70_8 = compose(v70_5,v71_7);
        }
        const Space v70_9 = intersect(constant_3,v70_2);
        const Space v70_10 = (has_head(v70_9) ? constant_4 : Space{});
        Space v70_12;
        if (!v70_10.empty()) {
          const Path v72_6 = concat_path(v67_11_head,v69_6_head);
          const Space v72_11 = routine_21(c, v72_6, p0, v69_6_tail);
          v70_12 = compose(v70_10,v72_11);
        }
        const Space v70_13 = unite(v70_8,v70_12);
        v69_6_result = unite(v69_6_result,v70_13);
      }
      const Space v69_6 = std::move(v69_6_result);
      v68_7 = compose(v68_5,v69_6);
    }
    const Space v68_8 = intersect(constant_3,v68_2);
    const Space v68_9 = (has_head(v68_8) ? constant_4 : Space{});
    Space v68_11;
    if (!v68_9.empty()) {
      Space v73_10_result;
      for (int v73_10_label = 1; v73_10_label <= 2; ++v73_10_label) {
        const Space v73_10_tail = child(v67_11_tail,v73_10_label);
        if (v73_10_tail.empty()) continue;
        const Path v73_10_head{v73_10_label};
        const Space v74_2 = singleton(v73_10_head);
        const Space v74_3 = intersect(constant_3,v74_2);
        const Space v74_4 = (has_head(v74_3) ? constant_4 : Space{});
        const Space v74_5 = subtract(constant_2,v74_4);
        Space v74_8;
        if (!v74_5.empty()) {
          const Path v75_6 = concat_path(v67_11_head,v73_10_head);
          const Space v75_7 = routine_20(c, v75_6, p0, v73_10_tail);
          v74_8 = compose(v74_5,v75_7);
        }
        const Space v74_9 = intersect(constant_3,v74_2);
        const Space v74_10 = (has_head(v74_9) ? constant_4 : Space{});
        Space v74_12;
        if (!v74_10.empty()) {
          const Path v76_6 = concat_path(v67_11_head,v73_10_head);
          const Space v76_11 = routine_22(c, v76_6, p0, v73_10_tail);
          v74_12 = compose(v74_10,v76_11);
        }
        const Space v74_13 = unite(v74_8,v74_12);
        v73_10_result = unite(v73_10_result,v74_13);
      }
      const Space v73_10 = std::move(v73_10_result);
      v68_11 = compose(v68_9,v73_10);
    }
    const Space v68_12 = unite(v68_7,v68_11);
    v67_11_result = unite(v67_11_result,v68_12);
  }
  const Space v67_11 = std::move(v67_11_result);
  return v67_11;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v77_12_result;
  for (int v77_12_label = 1; v77_12_label <= 2; ++v77_12_label) {
    const Space v77_12_tail = child(s0,v77_12_label);
    if (v77_12_tail.empty()) continue;
    const Path v77_12_head{v77_12_label};
    const Space v78_2 = singleton(v77_12_head);
    const Space v78_3 = intersect(constant_3,v78_2);
    const Space v78_4 = (has_head(v78_3) ? constant_4 : Space{});
    const Space v78_5 = subtract(constant_2,v78_4);
    Space v78_8;
    if (!v78_5.empty()) {
      const Path v79_6 = concat_path(p0,v77_12_head);
      Space v79_7_result;
      for (int v79_7_label = 1; v79_7_label <= 2; ++v79_7_label) {
        const Space v79_7_tail = child(v77_12_tail,v79_7_label);
        if (v79_7_tail.empty()) continue;
        const Path v79_7_head{v79_7_label};
        const Space v80_2 = singleton(v79_7_head);
        const Space v80_3 = intersect(constant_3,v80_2);
        const Space v80_4 = (has_head(v80_3) ? constant_4 : Space{});
        const Space v80_5 = subtract(constant_2,v80_4);
        Space v80_8;
        if (!v80_5.empty()) {
          const Path v81_6 = concat_path(v79_6,v79_7_head);
          const Space v81_7 = routine_23(c, v81_6, v79_7_tail, s1);
          v80_8 = compose(v80_5,v81_7);
        }
        const Space v80_9 = intersect(constant_3,v80_2);
        const Space v80_10 = (has_head(v80_9) ? constant_4 : Space{});
        Space v80_12;
        if (!v80_10.empty()) {
          const Path v82_6 = concat_path(v79_6,v79_7_head);
          const Space v82_11 = routine_24(c, v82_6, v79_7_tail, s1);
          v80_12 = compose(v80_10,v82_11);
        }
        const Space v80_13 = unite(v80_8,v80_12);
        v79_7_result = unite(v79_7_result,v80_13);
      }
      const Space v79_7 = std::move(v79_7_result);
      v78_8 = compose(v78_5,v79_7);
    }
    const Space v78_9 = intersect(constant_3,v78_2);
    const Space v78_10 = (has_head(v78_9) ? constant_4 : Space{});
    Space v78_12;
    if (!v78_10.empty()) {
      const Path v83_6 = concat_path(p0,v77_12_head);
      Space v83_11_result;
      for (int v83_11_label = 1; v83_11_label <= 2; ++v83_11_label) {
        const Space v83_11_tail = child(v77_12_tail,v83_11_label);
        if (v83_11_tail.empty()) continue;
        const Path v83_11_head{v83_11_label};
        const Space v84_2 = singleton(v83_11_head);
        const Space v84_3 = intersect(constant_3,v84_2);
        const Space v84_4 = (has_head(v84_3) ? constant_4 : Space{});
        const Space v84_5 = subtract(constant_2,v84_4);
        Space v84_8;
        if (!v84_5.empty()) {
          const Path v85_6 = concat_path(v83_6,v83_11_head);
          const Space v85_7 = routine_23(c, v85_6, v83_11_tail, s1);
          v84_8 = compose(v84_5,v85_7);
        }
        const Space v84_9 = intersect(constant_3,v84_2);
        const Space v84_10 = (has_head(v84_9) ? constant_4 : Space{});
        Space v84_12;
        if (!v84_10.empty()) {
          const Path v86_6 = concat_path(v83_6,v83_11_head);
          const Space v86_11 = routine_6(c, v86_6, v83_11_tail, s1);
          v84_12 = compose(v84_10,v86_11);
        }
        const Space v84_13 = unite(v84_8,v84_12);
        v83_11_result = unite(v83_11_result,v84_13);
      }
      const Space v83_11 = std::move(v83_11_result);
      v78_12 = compose(v78_10,v83_11);
    }
    const Space v78_13 = unite(v78_8,v78_12);
    v77_12_result = unite(v77_12_result,v78_13);
  }
  const Space v77_12 = std::move(v77_12_result);
  return v77_12;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v87_12_result;
  for (int v87_12_label = 1; v87_12_label <= 2; ++v87_12_label) {
    const Space v87_12_tail = child(s0,v87_12_label);
    if (v87_12_tail.empty()) continue;
    const Path v87_12_head{v87_12_label};
    const Space v88_2 = singleton(v87_12_head);
    const Space v88_3 = intersect(constant_3,v88_2);
    const Space v88_4 = (has_head(v88_3) ? constant_4 : Space{});
    const Space v88_5 = subtract(constant_2,v88_4);
    Space v88_8;
    if (!v88_5.empty()) {
      const Path v89_6 = concat_path(p0,v87_12_head);
      Space v89_7_result;
      for (int v89_7_label = 1; v89_7_label <= 2; ++v89_7_label) {
        const Space v89_7_tail = child(v87_12_tail,v89_7_label);
        if (v89_7_tail.empty()) continue;
        const Path v89_7_head{v89_7_label};
        const Space v90_2 = singleton(v89_7_head);
        const Space v90_3 = intersect(constant_3,v90_2);
        const Space v90_4 = (has_head(v90_3) ? constant_4 : Space{});
        const Space v90_5 = subtract(constant_2,v90_4);
        Space v90_8;
        if (!v90_5.empty()) {
          const Path v91_6 = concat_path(v89_6,v89_7_head);
          const Space v91_7 = routine_23(c, v91_6, v89_7_tail, s1);
          v90_8 = compose(v90_5,v91_7);
        }
        const Space v90_9 = intersect(constant_3,v90_2);
        const Space v90_10 = (has_head(v90_9) ? constant_4 : Space{});
        Space v90_12;
        if (!v90_10.empty()) {
          const Path v92_6 = concat_path(v89_6,v89_7_head);
          const Space v92_11 = routine_24(c, v92_6, v89_7_tail, s1);
          v90_12 = compose(v90_10,v92_11);
        }
        const Space v90_13 = unite(v90_8,v90_12);
        v89_7_result = unite(v89_7_result,v90_13);
      }
      const Space v89_7 = std::move(v89_7_result);
      v88_8 = compose(v88_5,v89_7);
    }
    const Space v88_9 = intersect(constant_3,v88_2);
    const Space v88_10 = (has_head(v88_9) ? constant_4 : Space{});
    Space v88_12;
    if (!v88_10.empty()) {
      const Path v93_6 = concat_path(p0,v87_12_head);
      Space v93_11_result;
      for (int v93_11_label = 1; v93_11_label <= 2; ++v93_11_label) {
        const Space v93_11_tail = child(v87_12_tail,v93_11_label);
        if (v93_11_tail.empty()) continue;
        const Path v93_11_head{v93_11_label};
        const Space v94_2 = singleton(v93_11_head);
        const Space v94_3 = intersect(constant_3,v94_2);
        const Space v94_4 = (has_head(v94_3) ? constant_4 : Space{});
        const Space v94_5 = subtract(constant_2,v94_4);
        Space v94_7;
        if (!v94_5.empty()) {
          const Space v95_6 = routine_25(c, v93_11_head, v93_6, v93_11_tail, s1);
          v94_7 = compose(v94_5,v95_6);
        }
        const Space v94_8 = intersect(constant_3,v94_2);
        const Space v94_9 = (has_head(v94_8) ? constant_4 : Space{});
        Space v94_11;
        if (!v94_9.empty()) {
          const Space v96_10 = routine_26(c, v93_11_head, v93_6, v93_11_tail, s1);
          v94_11 = compose(v94_9,v96_10);
        }
        const Space v94_12 = unite(v94_7,v94_11);
        v93_11_result = unite(v93_11_result,v94_12);
      }
      const Space v93_11 = std::move(v93_11_result);
      v88_12 = compose(v88_10,v93_11);
    }
    const Space v88_13 = unite(v88_8,v88_12);
    v87_12_result = unite(v87_12_result,v88_13);
  }
  const Space v87_12 = std::move(v87_12_result);
  return v87_12;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v97_12_result;
  for (int v97_12_label = 1; v97_12_label <= 2; ++v97_12_label) {
    const Space v97_12_tail = child(s0,v97_12_label);
    if (v97_12_tail.empty()) continue;
    const Path v97_12_head{v97_12_label};
    const Space v98_2 = singleton(v97_12_head);
    const Space v98_3 = intersect(constant_3,v98_2);
    const Space v98_4 = (has_head(v98_3) ? constant_4 : Space{});
    const Space v98_5 = subtract(constant_2,v98_4);
    Space v98_7;
    if (!v98_5.empty()) {
      Space v99_6_result;
      for (int v99_6_label = 1; v99_6_label <= 2; ++v99_6_label) {
        const Space v99_6_tail = child(v97_12_tail,v99_6_label);
        if (v99_6_tail.empty()) continue;
        const Path v99_6_head{v99_6_label};
        const Space v100_2 = singleton(v99_6_head);
        const Space v100_3 = intersect(constant_3,v100_2);
        const Space v100_4 = (has_head(v100_3) ? constant_4 : Space{});
        const Space v100_5 = subtract(constant_2,v100_4);
        Space v100_8;
        if (!v100_5.empty()) {
          const Path v101_6 = concat_path(v97_12_head,v99_6_head);
          const Space v101_7 = routine_27(c, v101_6, p0, v99_6_tail, s1);
          v100_8 = compose(v100_5,v101_7);
        }
        const Space v100_9 = intersect(constant_3,v100_2);
        const Space v100_10 = (has_head(v100_9) ? constant_4 : Space{});
        Space v100_12;
        if (!v100_10.empty()) {
          const Path v102_6 = concat_path(v97_12_head,v99_6_head);
          const Space v102_11 = routine_28(c, v102_6, p0, v99_6_tail, s1);
          v100_12 = compose(v100_10,v102_11);
        }
        const Space v100_13 = unite(v100_8,v100_12);
        v99_6_result = unite(v99_6_result,v100_13);
      }
      const Space v99_6 = std::move(v99_6_result);
      v98_7 = compose(v98_5,v99_6);
    }
    const Space v98_8 = intersect(constant_3,v98_2);
    const Space v98_9 = (has_head(v98_8) ? constant_4 : Space{});
    Space v98_11;
    if (!v98_9.empty()) {
      Space v103_10_result;
      for (int v103_10_label = 1; v103_10_label <= 2; ++v103_10_label) {
        const Space v103_10_tail = child(v97_12_tail,v103_10_label);
        if (v103_10_tail.empty()) continue;
        const Path v103_10_head{v103_10_label};
        const Space v104_2 = singleton(v103_10_head);
        const Space v104_3 = intersect(constant_3,v104_2);
        const Space v104_4 = (has_head(v104_3) ? constant_4 : Space{});
        const Space v104_5 = subtract(constant_2,v104_4);
        Space v104_8;
        if (!v104_5.empty()) {
          const Path v105_6 = concat_path(v97_12_head,v103_10_head);
          const Space v105_7 = routine_27(c, v105_6, p0, v103_10_tail, s1);
          v104_8 = compose(v104_5,v105_7);
        }
        const Space v104_9 = intersect(constant_3,v104_2);
        const Space v104_10 = (has_head(v104_9) ? constant_4 : Space{});
        Space v104_12;
        if (!v104_10.empty()) {
          const Path v106_6 = concat_path(v97_12_head,v103_10_head);
          const Space v106_11 = routine_29(c, v106_6, p0, v103_10_tail, s1);
          v104_12 = compose(v104_10,v106_11);
        }
        const Space v104_13 = unite(v104_8,v104_12);
        v103_10_result = unite(v103_10_result,v104_13);
      }
      const Space v103_10 = std::move(v103_10_result);
      v98_11 = compose(v98_9,v103_10);
    }
    const Space v98_12 = unite(v98_7,v98_11);
    v97_12_result = unite(v97_12_result,v98_12);
  }
  const Space v97_12 = std::move(v97_12_result);
  return v97_12;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v107_11_result;
  for (int v107_11_label = 1; v107_11_label <= 2; ++v107_11_label) {
    const Space v107_11_tail = child(s0,v107_11_label);
    if (v107_11_tail.empty()) continue;
    const Path v107_11_head{v107_11_label};
    const Space v108_2 = singleton(v107_11_head);
    const Space v108_3 = intersect(constant_3,v108_2);
    const Space v108_4 = (has_head(v108_3) ? constant_4 : Space{});
    const Space v108_5 = subtract(constant_2,v108_4);
    Space v108_8;
    if (!v108_5.empty()) {
      const Path v109_6 = concat_path(p0,v107_11_head);
      Space v109_7_result;
      for (int v109_7_label = 1; v109_7_label <= 2; ++v109_7_label) {
        const Space v109_7_tail = child(v107_11_tail,v109_7_label);
        if (v109_7_tail.empty()) continue;
        const Path v109_7_head{v109_7_label};
        const Space v110_2 = singleton(v109_7_head);
        const Space v110_3 = intersect(constant_3,v110_2);
        const Space v110_4 = (has_head(v110_3) ? constant_4 : Space{});
        const Space v110_5 = subtract(constant_2,v110_4);
        Space v110_8;
        if (!v110_5.empty()) {
          const Path v111_6 = concat_path(v109_6,v109_7_head);
          const Space v111_7 = routine_30(c, v111_6, v109_7_tail);
          v110_8 = compose(v110_5,v111_7);
        }
        const Space v110_9 = intersect(constant_3,v110_2);
        const Space v110_10 = (has_head(v110_9) ? constant_4 : Space{});
        Space v110_12;
        if (!v110_10.empty()) {
          const Path v112_6 = concat_path(v109_6,v109_7_head);
          const Space v112_11 = routine_31(c, v112_6, v109_7_tail);
          v110_12 = compose(v110_10,v112_11);
        }
        const Space v110_13 = unite(v110_8,v110_12);
        v109_7_result = unite(v109_7_result,v110_13);
      }
      const Space v109_7 = std::move(v109_7_result);
      v108_8 = compose(v108_5,v109_7);
    }
    const Space v108_9 = intersect(constant_3,v108_2);
    const Space v108_10 = (has_head(v108_9) ? constant_4 : Space{});
    Space v108_12;
    if (!v108_10.empty()) {
      const Path v113_6 = concat_path(p0,v107_11_head);
      Space v113_11_result;
      for (int v113_11_label = 1; v113_11_label <= 2; ++v113_11_label) {
        const Space v113_11_tail = child(v107_11_tail,v113_11_label);
        if (v113_11_tail.empty()) continue;
        const Path v113_11_head{v113_11_label};
        const Space v114_2 = singleton(v113_11_head);
        const Space v114_3 = intersect(constant_3,v114_2);
        const Space v114_4 = (has_head(v114_3) ? constant_4 : Space{});
        const Space v114_5 = subtract(constant_2,v114_4);
        Space v114_8;
        if (!v114_5.empty()) {
          const Path v115_6 = concat_path(v113_6,v113_11_head);
          const Space v115_7 = routine_30(c, v115_6, v113_11_tail);
          v114_8 = compose(v114_5,v115_7);
        }
        const Space v114_9 = intersect(constant_3,v114_2);
        const Space v114_10 = (has_head(v114_9) ? constant_4 : Space{});
        Space v114_12;
        if (!v114_10.empty()) {
          const Path v116_6 = concat_path(v113_6,v113_11_head);
          const Space v116_11 = routine_9(c, v116_6, v113_11_tail);
          v114_12 = compose(v114_10,v116_11);
        }
        const Space v114_13 = unite(v114_8,v114_12);
        v113_11_result = unite(v113_11_result,v114_13);
      }
      const Space v113_11 = std::move(v113_11_result);
      v108_12 = compose(v108_10,v113_11);
    }
    const Space v108_13 = unite(v108_8,v108_12);
    v107_11_result = unite(v107_11_result,v108_13);
  }
  const Space v107_11 = std::move(v107_11_result);
  return v107_11;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v117_11_result;
  for (int v117_11_label = 1; v117_11_label <= 2; ++v117_11_label) {
    const Space v117_11_tail = child(s0,v117_11_label);
    if (v117_11_tail.empty()) continue;
    const Path v117_11_head{v117_11_label};
    const Space v118_2 = singleton(v117_11_head);
    const Space v118_3 = intersect(constant_3,v118_2);
    const Space v118_4 = (has_head(v118_3) ? constant_4 : Space{});
    const Space v118_5 = subtract(constant_2,v118_4);
    Space v118_8;
    if (!v118_5.empty()) {
      const Path v119_6 = concat_path(p0,v117_11_head);
      Space v119_7_result;
      for (int v119_7_label = 1; v119_7_label <= 2; ++v119_7_label) {
        const Space v119_7_tail = child(v117_11_tail,v119_7_label);
        if (v119_7_tail.empty()) continue;
        const Path v119_7_head{v119_7_label};
        const Space v120_2 = singleton(v119_7_head);
        const Space v120_3 = intersect(constant_3,v120_2);
        const Space v120_4 = (has_head(v120_3) ? constant_4 : Space{});
        const Space v120_5 = subtract(constant_2,v120_4);
        Space v120_8;
        if (!v120_5.empty()) {
          const Path v121_6 = concat_path(v119_6,v119_7_head);
          const Space v121_7 = routine_30(c, v121_6, v119_7_tail);
          v120_8 = compose(v120_5,v121_7);
        }
        const Space v120_9 = intersect(constant_3,v120_2);
        const Space v120_10 = (has_head(v120_9) ? constant_4 : Space{});
        Space v120_12;
        if (!v120_10.empty()) {
          const Path v122_6 = concat_path(v119_6,v119_7_head);
          const Space v122_11 = routine_31(c, v122_6, v119_7_tail);
          v120_12 = compose(v120_10,v122_11);
        }
        const Space v120_13 = unite(v120_8,v120_12);
        v119_7_result = unite(v119_7_result,v120_13);
      }
      const Space v119_7 = std::move(v119_7_result);
      v118_8 = compose(v118_5,v119_7);
    }
    const Space v118_9 = intersect(constant_3,v118_2);
    const Space v118_10 = (has_head(v118_9) ? constant_4 : Space{});
    Space v118_12;
    if (!v118_10.empty()) {
      const Path v123_6 = concat_path(p0,v117_11_head);
      Space v123_11_result;
      for (int v123_11_label = 1; v123_11_label <= 2; ++v123_11_label) {
        const Space v123_11_tail = child(v117_11_tail,v123_11_label);
        if (v123_11_tail.empty()) continue;
        const Path v123_11_head{v123_11_label};
        const Space v124_2 = singleton(v123_11_head);
        const Space v124_3 = intersect(constant_3,v124_2);
        const Space v124_4 = (has_head(v124_3) ? constant_4 : Space{});
        const Space v124_5 = subtract(constant_2,v124_4);
        Space v124_7;
        if (!v124_5.empty()) {
          const Space v125_6 = routine_32(c, v123_11_head, v123_6, v123_11_tail);
          v124_7 = compose(v124_5,v125_6);
        }
        const Space v124_8 = intersect(constant_3,v124_2);
        const Space v124_9 = (has_head(v124_8) ? constant_4 : Space{});
        Space v124_11;
        if (!v124_9.empty()) {
          const Space v126_10 = routine_33(c, v123_11_head, v123_6, v123_11_tail);
          v124_11 = compose(v124_9,v126_10);
        }
        const Space v124_12 = unite(v124_7,v124_11);
        v123_11_result = unite(v123_11_result,v124_12);
      }
      const Space v123_11 = std::move(v123_11_result);
      v118_12 = compose(v118_10,v123_11);
    }
    const Space v118_13 = unite(v118_8,v118_12);
    v117_11_result = unite(v117_11_result,v118_13);
  }
  const Space v117_11 = std::move(v117_11_result);
  return v117_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  Space v127_11_result;
  for (int v127_11_label = 1; v127_11_label <= 2; ++v127_11_label) {
    const Space v127_11_tail = child(s0,v127_11_label);
    if (v127_11_tail.empty()) continue;
    const Path v127_11_head{v127_11_label};
    const Space v128_2 = singleton(v127_11_head);
    const Space v128_3 = intersect(constant_3,v128_2);
    const Space v128_4 = (has_head(v128_3) ? constant_4 : Space{});
    const Space v128_5 = subtract(constant_2,v128_4);
    Space v128_7;
    if (!v128_5.empty()) {
      Space v129_6_result;
      for (int v129_6_label = 1; v129_6_label <= 2; ++v129_6_label) {
        const Space v129_6_tail = child(v127_11_tail,v129_6_label);
        if (v129_6_tail.empty()) continue;
        const Path v129_6_head{v129_6_label};
        const Space v130_2 = singleton(v129_6_head);
        const Space v130_3 = intersect(constant_3,v130_2);
        const Space v130_4 = (has_head(v130_3) ? constant_4 : Space{});
        const Space v130_5 = subtract(constant_2,v130_4);
        Space v130_8;
        if (!v130_5.empty()) {
          const Path v131_6 = concat_path(v127_11_head,v129_6_head);
          const Space v131_7 = routine_34(c, v131_6, p0, v129_6_tail);
          v130_8 = compose(v130_5,v131_7);
        }
        const Space v130_9 = intersect(constant_3,v130_2);
        const Space v130_10 = (has_head(v130_9) ? constant_4 : Space{});
        Space v130_12;
        if (!v130_10.empty()) {
          const Path v132_6 = concat_path(v127_11_head,v129_6_head);
          const Space v132_11 = routine_35(c, v132_6, p0, v129_6_tail);
          v130_12 = compose(v130_10,v132_11);
        }
        const Space v130_13 = unite(v130_8,v130_12);
        v129_6_result = unite(v129_6_result,v130_13);
      }
      const Space v129_6 = std::move(v129_6_result);
      v128_7 = compose(v128_5,v129_6);
    }
    const Space v128_8 = intersect(constant_3,v128_2);
    const Space v128_9 = (has_head(v128_8) ? constant_4 : Space{});
    Space v128_11;
    if (!v128_9.empty()) {
      Space v133_10_result;
      for (int v133_10_label = 1; v133_10_label <= 2; ++v133_10_label) {
        const Space v133_10_tail = child(v127_11_tail,v133_10_label);
        if (v133_10_tail.empty()) continue;
        const Path v133_10_head{v133_10_label};
        const Space v134_2 = singleton(v133_10_head);
        const Space v134_3 = intersect(constant_3,v134_2);
        const Space v134_4 = (has_head(v134_3) ? constant_4 : Space{});
        const Space v134_5 = subtract(constant_2,v134_4);
        Space v134_8;
        if (!v134_5.empty()) {
          const Path v135_6 = concat_path(v127_11_head,v133_10_head);
          const Space v135_7 = routine_34(c, v135_6, p0, v133_10_tail);
          v134_8 = compose(v134_5,v135_7);
        }
        const Space v134_9 = intersect(constant_3,v134_2);
        const Space v134_10 = (has_head(v134_9) ? constant_4 : Space{});
        Space v134_12;
        if (!v134_10.empty()) {
          const Path v136_6 = concat_path(v127_11_head,v133_10_head);
          const Space v136_11 = routine_36(c, v136_6, p0, v133_10_tail);
          v134_12 = compose(v134_10,v136_11);
        }
        const Space v134_13 = unite(v134_8,v134_12);
        v133_10_result = unite(v133_10_result,v134_13);
      }
      const Space v133_10 = std::move(v133_10_result);
      v128_11 = compose(v128_9,v133_10);
    }
    const Space v128_12 = unite(v128_7,v128_11);
    v127_11_result = unite(v127_11_result,v128_12);
  }
  const Space v127_11 = std::move(v127_11_result);
  return v127_11;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v137_12_result;
  for (int v137_12_label = 1; v137_12_label <= 2; ++v137_12_label) {
    const Space v137_12_tail = child(s0,v137_12_label);
    if (v137_12_tail.empty()) continue;
    const Path v137_12_head{v137_12_label};
    const Space v138_2 = singleton(v137_12_head);
    const Space v138_3 = intersect(constant_3,v138_2);
    const Space v138_4 = (has_head(v138_3) ? constant_4 : Space{});
    const Space v138_5 = subtract(constant_2,v138_4);
    Space v138_8;
    if (!v138_5.empty()) {
      const Path v139_6 = concat_path(p0,v137_12_head);
      Space v139_7_result;
      for (int v139_7_label = 1; v139_7_label <= 2; ++v139_7_label) {
        const Space v139_7_tail = child(v137_12_tail,v139_7_label);
        if (v139_7_tail.empty()) continue;
        const Path v139_7_head{v139_7_label};
        const Space v140_2 = singleton(v139_7_head);
        const Space v140_3 = intersect(constant_3,v140_2);
        const Space v140_4 = (has_head(v140_3) ? constant_4 : Space{});
        const Space v140_5 = subtract(constant_2,v140_4);
        Space v140_8;
        if (!v140_5.empty()) {
          const Path v141_6 = concat_path(v139_6,v139_7_head);
          const Space v141_7 = routine_37(c, v141_6, v139_7_tail, s1);
          v140_8 = compose(v140_5,v141_7);
        }
        const Space v140_9 = intersect(constant_3,v140_2);
        const Space v140_10 = (has_head(v140_9) ? constant_4 : Space{});
        Space v140_12;
        if (!v140_10.empty()) {
          const Path v142_6 = concat_path(v139_6,v139_7_head);
          const Space v142_11 = routine_38(c, v142_6, v139_7_tail, s1);
          v140_12 = compose(v140_10,v142_11);
        }
        const Space v140_13 = unite(v140_8,v140_12);
        v139_7_result = unite(v139_7_result,v140_13);
      }
      const Space v139_7 = std::move(v139_7_result);
      v138_8 = compose(v138_5,v139_7);
    }
    const Space v138_9 = intersect(constant_3,v138_2);
    const Space v138_10 = (has_head(v138_9) ? constant_4 : Space{});
    Space v138_12;
    if (!v138_10.empty()) {
      const Path v143_6 = concat_path(p0,v137_12_head);
      Space v143_11_result;
      for (int v143_11_label = 1; v143_11_label <= 2; ++v143_11_label) {
        const Space v143_11_tail = child(v137_12_tail,v143_11_label);
        if (v143_11_tail.empty()) continue;
        const Path v143_11_head{v143_11_label};
        const Space v144_2 = singleton(v143_11_head);
        const Space v144_3 = intersect(constant_3,v144_2);
        const Space v144_4 = (has_head(v144_3) ? constant_4 : Space{});
        const Space v144_5 = subtract(constant_2,v144_4);
        Space v144_8;
        if (!v144_5.empty()) {
          const Path v145_6 = concat_path(v143_6,v143_11_head);
          const Space v145_7 = routine_37(c, v145_6, v143_11_tail, s1);
          v144_8 = compose(v144_5,v145_7);
        }
        const Space v144_9 = intersect(constant_3,v144_2);
        const Space v144_10 = (has_head(v144_9) ? constant_4 : Space{});
        Space v144_12;
        if (!v144_10.empty()) {
          const Path v146_6 = concat_path(v143_6,v143_11_head);
          const Space v146_11 = routine_12(c, v146_6, v143_11_tail, s1);
          v144_12 = compose(v144_10,v146_11);
        }
        const Space v144_13 = unite(v144_8,v144_12);
        v143_11_result = unite(v143_11_result,v144_13);
      }
      const Space v143_11 = std::move(v143_11_result);
      v138_12 = compose(v138_10,v143_11);
    }
    const Space v138_13 = unite(v138_8,v138_12);
    v137_12_result = unite(v137_12_result,v138_13);
  }
  const Space v137_12 = std::move(v137_12_result);
  return v137_12;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v147_12_result;
  for (int v147_12_label = 1; v147_12_label <= 2; ++v147_12_label) {
    const Space v147_12_tail = child(s0,v147_12_label);
    if (v147_12_tail.empty()) continue;
    const Path v147_12_head{v147_12_label};
    const Space v148_2 = singleton(v147_12_head);
    const Space v148_3 = intersect(constant_3,v148_2);
    const Space v148_4 = (has_head(v148_3) ? constant_4 : Space{});
    const Space v148_5 = subtract(constant_2,v148_4);
    Space v148_8;
    if (!v148_5.empty()) {
      const Path v149_6 = concat_path(p0,v147_12_head);
      Space v149_7_result;
      for (int v149_7_label = 1; v149_7_label <= 2; ++v149_7_label) {
        const Space v149_7_tail = child(v147_12_tail,v149_7_label);
        if (v149_7_tail.empty()) continue;
        const Path v149_7_head{v149_7_label};
        const Space v150_2 = singleton(v149_7_head);
        const Space v150_3 = intersect(constant_3,v150_2);
        const Space v150_4 = (has_head(v150_3) ? constant_4 : Space{});
        const Space v150_5 = subtract(constant_2,v150_4);
        Space v150_8;
        if (!v150_5.empty()) {
          const Path v151_6 = concat_path(v149_6,v149_7_head);
          const Space v151_7 = routine_37(c, v151_6, v149_7_tail, s1);
          v150_8 = compose(v150_5,v151_7);
        }
        const Space v150_9 = intersect(constant_3,v150_2);
        const Space v150_10 = (has_head(v150_9) ? constant_4 : Space{});
        Space v150_12;
        if (!v150_10.empty()) {
          const Path v152_6 = concat_path(v149_6,v149_7_head);
          const Space v152_11 = routine_38(c, v152_6, v149_7_tail, s1);
          v150_12 = compose(v150_10,v152_11);
        }
        const Space v150_13 = unite(v150_8,v150_12);
        v149_7_result = unite(v149_7_result,v150_13);
      }
      const Space v149_7 = std::move(v149_7_result);
      v148_8 = compose(v148_5,v149_7);
    }
    const Space v148_9 = intersect(constant_3,v148_2);
    const Space v148_10 = (has_head(v148_9) ? constant_4 : Space{});
    Space v148_12;
    if (!v148_10.empty()) {
      const Path v153_6 = concat_path(p0,v147_12_head);
      Space v153_11_result;
      for (int v153_11_label = 1; v153_11_label <= 2; ++v153_11_label) {
        const Space v153_11_tail = child(v147_12_tail,v153_11_label);
        if (v153_11_tail.empty()) continue;
        const Path v153_11_head{v153_11_label};
        const Space v154_2 = singleton(v153_11_head);
        const Space v154_3 = intersect(constant_3,v154_2);
        const Space v154_4 = (has_head(v154_3) ? constant_4 : Space{});
        const Space v154_5 = subtract(constant_2,v154_4);
        Space v154_7;
        if (!v154_5.empty()) {
          const Space v155_6 = routine_39(c, v153_11_head, v153_6, v153_11_tail, s1);
          v154_7 = compose(v154_5,v155_6);
        }
        const Space v154_8 = intersect(constant_3,v154_2);
        const Space v154_9 = (has_head(v154_8) ? constant_4 : Space{});
        Space v154_11;
        if (!v154_9.empty()) {
          const Space v156_10 = routine_40(c, v153_11_head, v153_6, v153_11_tail, s1);
          v154_11 = compose(v154_9,v156_10);
        }
        const Space v154_12 = unite(v154_7,v154_11);
        v153_11_result = unite(v153_11_result,v154_12);
      }
      const Space v153_11 = std::move(v153_11_result);
      v148_12 = compose(v148_10,v153_11);
    }
    const Space v148_13 = unite(v148_8,v148_12);
    v147_12_result = unite(v147_12_result,v148_13);
  }
  const Space v147_12 = std::move(v147_12_result);
  return v147_12;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v157_12_result;
  for (int v157_12_label = 1; v157_12_label <= 2; ++v157_12_label) {
    const Space v157_12_tail = child(s0,v157_12_label);
    if (v157_12_tail.empty()) continue;
    const Path v157_12_head{v157_12_label};
    const Space v158_2 = singleton(v157_12_head);
    const Space v158_3 = intersect(constant_3,v158_2);
    const Space v158_4 = (has_head(v158_3) ? constant_4 : Space{});
    const Space v158_5 = subtract(constant_2,v158_4);
    Space v158_7;
    if (!v158_5.empty()) {
      Space v159_6_result;
      for (int v159_6_label = 1; v159_6_label <= 2; ++v159_6_label) {
        const Space v159_6_tail = child(v157_12_tail,v159_6_label);
        if (v159_6_tail.empty()) continue;
        const Path v159_6_head{v159_6_label};
        const Space v160_2 = singleton(v159_6_head);
        const Space v160_3 = intersect(constant_3,v160_2);
        const Space v160_4 = (has_head(v160_3) ? constant_4 : Space{});
        const Space v160_5 = subtract(constant_2,v160_4);
        Space v160_8;
        if (!v160_5.empty()) {
          const Path v161_6 = concat_path(v157_12_head,v159_6_head);
          const Space v161_7 = routine_41(c, v161_6, p0, v159_6_tail, s1);
          v160_8 = compose(v160_5,v161_7);
        }
        const Space v160_9 = intersect(constant_3,v160_2);
        const Space v160_10 = (has_head(v160_9) ? constant_4 : Space{});
        Space v160_12;
        if (!v160_10.empty()) {
          const Path v162_6 = concat_path(v157_12_head,v159_6_head);
          const Space v162_11 = routine_42(c, v162_6, p0, v159_6_tail, s1);
          v160_12 = compose(v160_10,v162_11);
        }
        const Space v160_13 = unite(v160_8,v160_12);
        v159_6_result = unite(v159_6_result,v160_13);
      }
      const Space v159_6 = std::move(v159_6_result);
      v158_7 = compose(v158_5,v159_6);
    }
    const Space v158_8 = intersect(constant_3,v158_2);
    const Space v158_9 = (has_head(v158_8) ? constant_4 : Space{});
    Space v158_11;
    if (!v158_9.empty()) {
      Space v163_10_result;
      for (int v163_10_label = 1; v163_10_label <= 2; ++v163_10_label) {
        const Space v163_10_tail = child(v157_12_tail,v163_10_label);
        if (v163_10_tail.empty()) continue;
        const Path v163_10_head{v163_10_label};
        const Space v164_2 = singleton(v163_10_head);
        const Space v164_3 = intersect(constant_3,v164_2);
        const Space v164_4 = (has_head(v164_3) ? constant_4 : Space{});
        const Space v164_5 = subtract(constant_2,v164_4);
        Space v164_8;
        if (!v164_5.empty()) {
          const Path v165_6 = concat_path(v157_12_head,v163_10_head);
          const Space v165_7 = routine_41(c, v165_6, p0, v163_10_tail, s1);
          v164_8 = compose(v164_5,v165_7);
        }
        const Space v164_9 = intersect(constant_3,v164_2);
        const Space v164_10 = (has_head(v164_9) ? constant_4 : Space{});
        Space v164_12;
        if (!v164_10.empty()) {
          const Path v166_6 = concat_path(v157_12_head,v163_10_head);
          const Space v166_11 = routine_43(c, v166_6, p0, v163_10_tail, s1);
          v164_12 = compose(v164_10,v166_11);
        }
        const Space v164_13 = unite(v164_8,v164_12);
        v163_10_result = unite(v163_10_result,v164_13);
      }
      const Space v163_10 = std::move(v163_10_result);
      v158_11 = compose(v158_9,v163_10);
    }
    const Space v158_12 = unite(v158_7,v158_11);
    v157_12_result = unite(v157_12_result,v158_12);
  }
  const Space v157_12 = std::move(v157_12_result);
  return v157_12;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v167_12_result;
  for (int v167_12_label = 1; v167_12_label <= 2; ++v167_12_label) {
    const Space v167_12_tail = child(s0,v167_12_label);
    if (v167_12_tail.empty()) continue;
    const Path v167_12_head{v167_12_label};
    const Space v168_2 = singleton(v167_12_head);
    const Space v168_3 = intersect(constant_3,v168_2);
    const Space v168_4 = (has_head(v168_3) ? constant_4 : Space{});
    const Space v168_5 = subtract(constant_2,v168_4);
    Space v168_8;
    if (!v168_5.empty()) {
      const Path v169_6 = concat_path(p0,v167_12_head);
      Space v169_7_result;
      for (int v169_7_label = 1; v169_7_label <= 2; ++v169_7_label) {
        const Space v169_7_tail = child(v167_12_tail,v169_7_label);
        if (v169_7_tail.empty()) continue;
        const Path v169_7_head{v169_7_label};
        const Space v170_2 = singleton(v169_7_head);
        const Space v170_3 = intersect(constant_3,v170_2);
        const Space v170_4 = (has_head(v170_3) ? constant_4 : Space{});
        const Space v170_5 = subtract(constant_2,v170_4);
        Space v170_8;
        if (!v170_5.empty()) {
          const Path v171_6 = concat_path(v169_6,v169_7_head);
          const Space v171_7 = routine_44(c, v171_6, v169_7_tail, s1);
          v170_8 = compose(v170_5,v171_7);
        }
        const Space v170_9 = intersect(constant_3,v170_2);
        const Space v170_10 = (has_head(v170_9) ? constant_4 : Space{});
        Space v170_12;
        if (!v170_10.empty()) {
          const Path v172_6 = concat_path(v169_6,v169_7_head);
          const Space v172_11 = routine_45(c, v172_6, v169_7_tail, s1);
          v170_12 = compose(v170_10,v172_11);
        }
        const Space v170_13 = unite(v170_8,v170_12);
        v169_7_result = unite(v169_7_result,v170_13);
      }
      const Space v169_7 = std::move(v169_7_result);
      v168_8 = compose(v168_5,v169_7);
    }
    const Space v168_9 = intersect(constant_3,v168_2);
    const Space v168_10 = (has_head(v168_9) ? constant_4 : Space{});
    Space v168_12;
    if (!v168_10.empty()) {
      const Path v173_6 = concat_path(p0,v167_12_head);
      Space v173_11_result;
      for (int v173_11_label = 1; v173_11_label <= 2; ++v173_11_label) {
        const Space v173_11_tail = child(v167_12_tail,v173_11_label);
        if (v173_11_tail.empty()) continue;
        const Path v173_11_head{v173_11_label};
        const Space v174_2 = singleton(v173_11_head);
        const Space v174_3 = intersect(constant_3,v174_2);
        const Space v174_4 = (has_head(v174_3) ? constant_4 : Space{});
        const Space v174_5 = subtract(constant_2,v174_4);
        Space v174_8;
        if (!v174_5.empty()) {
          const Path v175_6 = concat_path(v173_6,v173_11_head);
          const Space v175_7 = routine_44(c, v175_6, v173_11_tail, s1);
          v174_8 = compose(v174_5,v175_7);
        }
        const Space v174_9 = intersect(constant_3,v174_2);
        const Space v174_10 = (has_head(v174_9) ? constant_4 : Space{});
        Space v174_12;
        if (!v174_10.empty()) {
          const Path v176_6 = concat_path(v173_6,v173_11_head);
          const Space v176_11 = routine_15(c, v176_6, v173_11_tail, s1);
          v174_12 = compose(v174_10,v176_11);
        }
        const Space v174_13 = unite(v174_8,v174_12);
        v173_11_result = unite(v173_11_result,v174_13);
      }
      const Space v173_11 = std::move(v173_11_result);
      v168_12 = compose(v168_10,v173_11);
    }
    const Space v168_13 = unite(v168_8,v168_12);
    v167_12_result = unite(v167_12_result,v168_13);
  }
  const Space v167_12 = std::move(v167_12_result);
  return v167_12;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v177_12_result;
  for (int v177_12_label = 1; v177_12_label <= 2; ++v177_12_label) {
    const Space v177_12_tail = child(s0,v177_12_label);
    if (v177_12_tail.empty()) continue;
    const Path v177_12_head{v177_12_label};
    const Space v178_2 = singleton(v177_12_head);
    const Space v178_3 = intersect(constant_3,v178_2);
    const Space v178_4 = (has_head(v178_3) ? constant_4 : Space{});
    const Space v178_5 = subtract(constant_2,v178_4);
    Space v178_8;
    if (!v178_5.empty()) {
      const Path v179_6 = concat_path(p0,v177_12_head);
      Space v179_7_result;
      for (int v179_7_label = 1; v179_7_label <= 2; ++v179_7_label) {
        const Space v179_7_tail = child(v177_12_tail,v179_7_label);
        if (v179_7_tail.empty()) continue;
        const Path v179_7_head{v179_7_label};
        const Space v180_2 = singleton(v179_7_head);
        const Space v180_3 = intersect(constant_3,v180_2);
        const Space v180_4 = (has_head(v180_3) ? constant_4 : Space{});
        const Space v180_5 = subtract(constant_2,v180_4);
        Space v180_8;
        if (!v180_5.empty()) {
          const Path v181_6 = concat_path(v179_6,v179_7_head);
          const Space v181_7 = routine_44(c, v181_6, v179_7_tail, s1);
          v180_8 = compose(v180_5,v181_7);
        }
        const Space v180_9 = intersect(constant_3,v180_2);
        const Space v180_10 = (has_head(v180_9) ? constant_4 : Space{});
        Space v180_12;
        if (!v180_10.empty()) {
          const Path v182_6 = concat_path(v179_6,v179_7_head);
          const Space v182_11 = routine_45(c, v182_6, v179_7_tail, s1);
          v180_12 = compose(v180_10,v182_11);
        }
        const Space v180_13 = unite(v180_8,v180_12);
        v179_7_result = unite(v179_7_result,v180_13);
      }
      const Space v179_7 = std::move(v179_7_result);
      v178_8 = compose(v178_5,v179_7);
    }
    const Space v178_9 = intersect(constant_3,v178_2);
    const Space v178_10 = (has_head(v178_9) ? constant_4 : Space{});
    Space v178_12;
    if (!v178_10.empty()) {
      const Path v183_6 = concat_path(p0,v177_12_head);
      Space v183_11_result;
      for (int v183_11_label = 1; v183_11_label <= 2; ++v183_11_label) {
        const Space v183_11_tail = child(v177_12_tail,v183_11_label);
        if (v183_11_tail.empty()) continue;
        const Path v183_11_head{v183_11_label};
        const Space v184_2 = singleton(v183_11_head);
        const Space v184_3 = intersect(constant_3,v184_2);
        const Space v184_4 = (has_head(v184_3) ? constant_4 : Space{});
        const Space v184_5 = subtract(constant_2,v184_4);
        Space v184_7;
        if (!v184_5.empty()) {
          const Space v185_6 = routine_46(c, v183_11_head, v183_6, v183_11_tail, s1);
          v184_7 = compose(v184_5,v185_6);
        }
        const Space v184_8 = intersect(constant_3,v184_2);
        const Space v184_9 = (has_head(v184_8) ? constant_4 : Space{});
        Space v184_11;
        if (!v184_9.empty()) {
          const Space v186_10 = routine_47(c, v183_11_head, v183_6, v183_11_tail, s1);
          v184_11 = compose(v184_9,v186_10);
        }
        const Space v184_12 = unite(v184_7,v184_11);
        v183_11_result = unite(v183_11_result,v184_12);
      }
      const Space v183_11 = std::move(v183_11_result);
      v178_12 = compose(v178_10,v183_11);
    }
    const Space v178_13 = unite(v178_8,v178_12);
    v177_12_result = unite(v177_12_result,v178_13);
  }
  const Space v177_12 = std::move(v177_12_result);
  return v177_12;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v187_12_result;
  for (int v187_12_label = 1; v187_12_label <= 2; ++v187_12_label) {
    const Space v187_12_tail = child(s0,v187_12_label);
    if (v187_12_tail.empty()) continue;
    const Path v187_12_head{v187_12_label};
    const Space v188_2 = singleton(v187_12_head);
    const Space v188_3 = intersect(constant_3,v188_2);
    const Space v188_4 = (has_head(v188_3) ? constant_4 : Space{});
    const Space v188_5 = subtract(constant_2,v188_4);
    Space v188_7;
    if (!v188_5.empty()) {
      Space v189_6_result;
      for (int v189_6_label = 1; v189_6_label <= 2; ++v189_6_label) {
        const Space v189_6_tail = child(v187_12_tail,v189_6_label);
        if (v189_6_tail.empty()) continue;
        const Path v189_6_head{v189_6_label};
        const Space v190_2 = singleton(v189_6_head);
        const Space v190_3 = intersect(constant_3,v190_2);
        const Space v190_4 = (has_head(v190_3) ? constant_4 : Space{});
        const Space v190_5 = subtract(constant_2,v190_4);
        Space v190_8;
        if (!v190_5.empty()) {
          const Path v191_6 = concat_path(v187_12_head,v189_6_head);
          const Space v191_7 = routine_48(c, v191_6, p0, v189_6_tail, s1);
          v190_8 = compose(v190_5,v191_7);
        }
        const Space v190_9 = intersect(constant_3,v190_2);
        const Space v190_10 = (has_head(v190_9) ? constant_4 : Space{});
        Space v190_12;
        if (!v190_10.empty()) {
          const Path v192_6 = concat_path(v187_12_head,v189_6_head);
          const Space v192_11 = routine_49(c, v192_6, p0, v189_6_tail, s1);
          v190_12 = compose(v190_10,v192_11);
        }
        const Space v190_13 = unite(v190_8,v190_12);
        v189_6_result = unite(v189_6_result,v190_13);
      }
      const Space v189_6 = std::move(v189_6_result);
      v188_7 = compose(v188_5,v189_6);
    }
    const Space v188_8 = intersect(constant_3,v188_2);
    const Space v188_9 = (has_head(v188_8) ? constant_4 : Space{});
    Space v188_11;
    if (!v188_9.empty()) {
      Space v193_10_result;
      for (int v193_10_label = 1; v193_10_label <= 2; ++v193_10_label) {
        const Space v193_10_tail = child(v187_12_tail,v193_10_label);
        if (v193_10_tail.empty()) continue;
        const Path v193_10_head{v193_10_label};
        const Space v194_2 = singleton(v193_10_head);
        const Space v194_3 = intersect(constant_3,v194_2);
        const Space v194_4 = (has_head(v194_3) ? constant_4 : Space{});
        const Space v194_5 = subtract(constant_2,v194_4);
        Space v194_8;
        if (!v194_5.empty()) {
          const Path v195_6 = concat_path(v187_12_head,v193_10_head);
          const Space v195_7 = routine_48(c, v195_6, p0, v193_10_tail, s1);
          v194_8 = compose(v194_5,v195_7);
        }
        const Space v194_9 = intersect(constant_3,v194_2);
        const Space v194_10 = (has_head(v194_9) ? constant_4 : Space{});
        Space v194_12;
        if (!v194_10.empty()) {
          const Path v196_6 = concat_path(v187_12_head,v193_10_head);
          const Space v196_11 = routine_50(c, v196_6, p0, v193_10_tail, s1);
          v194_12 = compose(v194_10,v196_11);
        }
        const Space v194_13 = unite(v194_8,v194_12);
        v193_10_result = unite(v193_10_result,v194_13);
      }
      const Space v193_10 = std::move(v193_10_result);
      v188_11 = compose(v188_9,v193_10);
    }
    const Space v188_12 = unite(v188_7,v188_11);
    v187_12_result = unite(v187_12_result,v188_12);
  }
  const Space v187_12 = std::move(v187_12_result);
  return v187_12;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v197_11_result;
  for (int v197_11_label = 1; v197_11_label <= 2; ++v197_11_label) {
    const Space v197_11_tail = child(s0,v197_11_label);
    if (v197_11_tail.empty()) continue;
    const Path v197_11_head{v197_11_label};
    const Space v198_2 = singleton(v197_11_head);
    const Space v198_3 = intersect(constant_3,v198_2);
    const Space v198_4 = (has_head(v198_3) ? constant_4 : Space{});
    const Space v198_5 = subtract(constant_2,v198_4);
    Space v198_8;
    if (!v198_5.empty()) {
      const Path v199_6 = concat_path(p0,v197_11_head);
      Space v199_7_result;
      for (int v199_7_label = 1; v199_7_label <= 2; ++v199_7_label) {
        const Space v199_7_tail = child(v197_11_tail,v199_7_label);
        if (v199_7_tail.empty()) continue;
        const Path v199_7_head{v199_7_label};
        const Space v200_2 = singleton(v199_7_head);
        const Space v200_3 = intersect(constant_3,v200_2);
        const Space v200_4 = (has_head(v200_3) ? constant_4 : Space{});
        const Space v200_5 = subtract(constant_2,v200_4);
        Space v200_8;
        if (!v200_5.empty()) {
          const Path v201_6 = concat_path(v199_6,v199_7_head);
          const Space v201_7 = routine_51(c, v201_6, v199_7_tail);
          v200_8 = compose(v200_5,v201_7);
        }
        const Space v200_9 = intersect(constant_3,v200_2);
        const Space v200_10 = (has_head(v200_9) ? constant_4 : Space{});
        Space v200_12;
        if (!v200_10.empty()) {
          const Path v202_6 = concat_path(v199_6,v199_7_head);
          const Space v202_11 = routine_52(c, v202_6, v199_7_tail);
          v200_12 = compose(v200_10,v202_11);
        }
        const Space v200_13 = unite(v200_8,v200_12);
        v199_7_result = unite(v199_7_result,v200_13);
      }
      const Space v199_7 = std::move(v199_7_result);
      v198_8 = compose(v198_5,v199_7);
    }
    const Space v198_9 = intersect(constant_3,v198_2);
    const Space v198_10 = (has_head(v198_9) ? constant_4 : Space{});
    Space v198_12;
    if (!v198_10.empty()) {
      const Path v203_6 = concat_path(p0,v197_11_head);
      Space v203_11_result;
      for (int v203_11_label = 1; v203_11_label <= 2; ++v203_11_label) {
        const Space v203_11_tail = child(v197_11_tail,v203_11_label);
        if (v203_11_tail.empty()) continue;
        const Path v203_11_head{v203_11_label};
        const Space v204_2 = singleton(v203_11_head);
        const Space v204_3 = intersect(constant_3,v204_2);
        const Space v204_4 = (has_head(v204_3) ? constant_4 : Space{});
        const Space v204_5 = subtract(constant_2,v204_4);
        Space v204_8;
        if (!v204_5.empty()) {
          const Path v205_6 = concat_path(v203_6,v203_11_head);
          const Space v205_7 = routine_51(c, v205_6, v203_11_tail);
          v204_8 = compose(v204_5,v205_7);
        }
        const Space v204_9 = intersect(constant_3,v204_2);
        const Space v204_10 = (has_head(v204_9) ? constant_4 : Space{});
        Space v204_12;
        if (!v204_10.empty()) {
          const Path v206_6 = concat_path(v203_6,v203_11_head);
          const Space v206_11 = routine_3(c, v206_6, v203_11_tail);
          v204_12 = compose(v204_10,v206_11);
        }
        const Space v204_13 = unite(v204_8,v204_12);
        v203_11_result = unite(v203_11_result,v204_13);
      }
      const Space v203_11 = std::move(v203_11_result);
      v198_12 = compose(v198_10,v203_11);
    }
    const Space v198_13 = unite(v198_8,v198_12);
    v197_11_result = unite(v197_11_result,v198_13);
  }
  const Space v197_11 = std::move(v197_11_result);
  return v197_11;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  Space v207_11_result;
  for (int v207_11_label = 1; v207_11_label <= 2; ++v207_11_label) {
    const Space v207_11_tail = child(s0,v207_11_label);
    if (v207_11_tail.empty()) continue;
    const Path v207_11_head{v207_11_label};
    const Space v208_2 = singleton(v207_11_head);
    const Space v208_3 = intersect(constant_3,v208_2);
    const Space v208_4 = (has_head(v208_3) ? constant_4 : Space{});
    const Space v208_5 = subtract(constant_2,v208_4);
    Space v208_8;
    if (!v208_5.empty()) {
      const Path v209_6 = concat_path(p0,v207_11_head);
      Space v209_7_result;
      for (int v209_7_label = 1; v209_7_label <= 2; ++v209_7_label) {
        const Space v209_7_tail = child(v207_11_tail,v209_7_label);
        if (v209_7_tail.empty()) continue;
        const Path v209_7_head{v209_7_label};
        const Space v210_2 = singleton(v209_7_head);
        const Space v210_3 = intersect(constant_3,v210_2);
        const Space v210_4 = (has_head(v210_3) ? constant_4 : Space{});
        const Space v210_5 = subtract(constant_2,v210_4);
        Space v210_8;
        if (!v210_5.empty()) {
          const Path v211_6 = concat_path(v209_6,v209_7_head);
          const Space v211_7 = routine_51(c, v211_6, v209_7_tail);
          v210_8 = compose(v210_5,v211_7);
        }
        const Space v210_9 = intersect(constant_3,v210_2);
        const Space v210_10 = (has_head(v210_9) ? constant_4 : Space{});
        Space v210_12;
        if (!v210_10.empty()) {
          const Path v212_6 = concat_path(v209_6,v209_7_head);
          const Space v212_11 = routine_52(c, v212_6, v209_7_tail);
          v210_12 = compose(v210_10,v212_11);
        }
        const Space v210_13 = unite(v210_8,v210_12);
        v209_7_result = unite(v209_7_result,v210_13);
      }
      const Space v209_7 = std::move(v209_7_result);
      v208_8 = compose(v208_5,v209_7);
    }
    const Space v208_9 = intersect(constant_3,v208_2);
    const Space v208_10 = (has_head(v208_9) ? constant_4 : Space{});
    Space v208_12;
    if (!v208_10.empty()) {
      const Path v213_6 = concat_path(p0,v207_11_head);
      Space v213_11_result;
      for (int v213_11_label = 1; v213_11_label <= 2; ++v213_11_label) {
        const Space v213_11_tail = child(v207_11_tail,v213_11_label);
        if (v213_11_tail.empty()) continue;
        const Path v213_11_head{v213_11_label};
        const Space v214_2 = singleton(v213_11_head);
        const Space v214_3 = intersect(constant_3,v214_2);
        const Space v214_4 = (has_head(v214_3) ? constant_4 : Space{});
        const Space v214_5 = subtract(constant_2,v214_4);
        Space v214_7;
        if (!v214_5.empty()) {
          const Space v215_6 = routine_18(c, v213_11_head, v213_6, v213_11_tail);
          v214_7 = compose(v214_5,v215_6);
        }
        const Space v214_8 = intersect(constant_3,v214_2);
        const Space v214_9 = (has_head(v214_8) ? constant_4 : Space{});
        Space v214_11;
        if (!v214_9.empty()) {
          const Space v216_10 = routine_19(c, v213_11_head, v213_6, v213_11_tail);
          v214_11 = compose(v214_9,v216_10);
        }
        const Space v214_12 = unite(v214_7,v214_11);
        v213_11_result = unite(v213_11_result,v214_12);
      }
      const Space v213_11 = std::move(v213_11_result);
      v208_12 = compose(v208_10,v213_11);
    }
    const Space v208_13 = unite(v208_8,v208_12);
    v207_11_result = unite(v207_11_result,v208_13);
  }
  const Space v207_11 = std::move(v207_11_result);
  return v207_11;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v217_12_result;
  for (int v217_12_label = 1; v217_12_label <= 2; ++v217_12_label) {
    const Space v217_12_tail = child(s0,v217_12_label);
    if (v217_12_tail.empty()) continue;
    const Path v217_12_head{v217_12_label};
    const Space v218_2 = singleton(v217_12_head);
    const Space v218_3 = intersect(constant_3,v218_2);
    const Space v218_4 = (has_head(v218_3) ? constant_4 : Space{});
    const Space v218_5 = subtract(constant_2,v218_4);
    Space v218_8;
    if (!v218_5.empty()) {
      const Path v219_6 = concat_path(p0,v217_12_head);
      Space v219_7_result;
      for (int v219_7_label = 1; v219_7_label <= 2; ++v219_7_label) {
        const Space v219_7_tail = child(v217_12_tail,v219_7_label);
        if (v219_7_tail.empty()) continue;
        const Path v219_7_head{v219_7_label};
        const Space v220_2 = singleton(v219_7_head);
        const Space v220_3 = intersect(constant_3,v220_2);
        const Space v220_4 = (has_head(v220_3) ? constant_4 : Space{});
        const Space v220_5 = subtract(constant_2,v220_4);
        Space v220_8;
        if (!v220_5.empty()) {
          const Path v221_6 = concat_path(v219_6,v219_7_head);
          const Space v221_7 = routine_53(c, v221_6, p1, v219_7_tail);
          v220_8 = compose(v220_5,v221_7);
        }
        const Space v220_9 = intersect(constant_3,v220_2);
        const Space v220_10 = (has_head(v220_9) ? constant_4 : Space{});
        Space v220_12;
        if (!v220_10.empty()) {
          const Path v222_6 = concat_path(v219_6,v219_7_head);
          const Space v222_11 = routine_54(c, v222_6, p1, v219_7_tail);
          v220_12 = compose(v220_10,v222_11);
        }
        const Space v220_13 = unite(v220_8,v220_12);
        v219_7_result = unite(v219_7_result,v220_13);
      }
      const Space v219_7 = std::move(v219_7_result);
      v218_8 = compose(v218_5,v219_7);
    }
    const Space v218_9 = intersect(constant_3,v218_2);
    const Space v218_10 = (has_head(v218_9) ? constant_4 : Space{});
    Space v218_12;
    if (!v218_10.empty()) {
      const Path v223_6 = concat_path(p0,v217_12_head);
      Space v223_11_result;
      for (int v223_11_label = 1; v223_11_label <= 2; ++v223_11_label) {
        const Space v223_11_tail = child(v217_12_tail,v223_11_label);
        if (v223_11_tail.empty()) continue;
        const Path v223_11_head{v223_11_label};
        const Space v224_2 = singleton(v223_11_head);
        const Space v224_3 = intersect(constant_3,v224_2);
        const Space v224_4 = (has_head(v224_3) ? constant_4 : Space{});
        const Space v224_5 = subtract(constant_2,v224_4);
        Space v224_8;
        if (!v224_5.empty()) {
          const Path v225_6 = concat_path(v223_6,v223_11_head);
          const Space v225_7 = routine_53(c, v225_6, p1, v223_11_tail);
          v224_8 = compose(v224_5,v225_7);
        }
        const Space v224_9 = intersect(constant_3,v224_2);
        const Space v224_10 = (has_head(v224_9) ? constant_4 : Space{});
        Space v224_12;
        if (!v224_10.empty()) {
          const Path v226_6 = concat_path(v223_6,v223_11_head);
          const Space v226_11 = routine_22(c, v226_6, p1, v223_11_tail);
          v224_12 = compose(v224_10,v226_11);
        }
        const Space v224_13 = unite(v224_8,v224_12);
        v223_11_result = unite(v223_11_result,v224_13);
      }
      const Space v223_11 = std::move(v223_11_result);
      v218_12 = compose(v218_10,v223_11);
    }
    const Space v218_13 = unite(v218_8,v218_12);
    v217_12_result = unite(v217_12_result,v218_13);
  }
  const Space v217_12 = std::move(v217_12_result);
  return v217_12;
}

static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v227_10_result;
  for (int v227_10_label = 1; v227_10_label <= 2; ++v227_10_label) {
    const Space v227_10_tail = child(s0,v227_10_label);
    if (v227_10_tail.empty()) continue;
    const Path v227_10_head{v227_10_label};
    const Space v228_2 = singleton(v227_10_head);
    const Space v228_3 = intersect(constant_3,v228_2);
    const Space v228_4 = (has_head(v228_3) ? constant_4 : Space{});
    const Space v228_5 = compose(v228_4,v227_10_tail);
    const Path v229_6 = concat_path(p0,v227_10_head);
    const Space v228_7 = wrap(v228_5,v229_6);
    const Space v228_8 = wrap(v228_7,p1);
    const Space v228_9 = wrap(v228_8,constant_6);
    const Space v228_10 = intersect(constant_3,v228_2);
    const Space v228_11 = (has_head(v228_10) ? constant_4 : Space{});
    const Space v228_12 = subtract(constant_2,v228_11);
    Space v228_14;
    if (!v228_12.empty()) {
      Space v230_13_result;
      for (int v230_13_label = 1; v230_13_label <= 2; ++v230_13_label) {
        const Space v230_13_tail = child(v227_10_tail,v230_13_label);
        if (v230_13_tail.empty()) continue;
        const Path v230_13_head{v230_13_label};
        const Space v231_2 = singleton(v230_13_head);
        const Space v231_3 = intersect(constant_3,v231_2);
        const Space v231_4 = (has_head(v231_3) ? constant_4 : Space{});
        const Space v231_5 = subtract(constant_2,v231_4);
        Space v231_8;
        if (!v231_5.empty()) {
          const Path v232_6 = concat_path(v229_6,v230_13_head);
          const Space v232_7 = routine_53(c, v232_6, p1, v230_13_tail);
          v231_8 = compose(v231_5,v232_7);
        }
        const Space v231_9 = intersect(constant_3,v231_2);
        const Space v231_10 = (has_head(v231_9) ? constant_4 : Space{});
        Space v231_12;
        if (!v231_10.empty()) {
          const Path v233_6 = concat_path(v229_6,v230_13_head);
          const Space v233_11 = routine_54(c, v233_6, p1, v230_13_tail);
          v231_12 = compose(v231_10,v233_11);
        }
        const Space v231_13 = unite(v231_8,v231_12);
        v230_13_result = unite(v230_13_result,v231_13);
      }
      const Space v230_13 = std::move(v230_13_result);
      v228_14 = compose(v228_12,v230_13);
    }
    const Space v228_15 = unite(v228_9,v228_14);
    v227_10_result = unite(v227_10_result,v228_15);
  }
  const Space v227_10 = std::move(v227_10_result);
  return v227_10;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v234_12_result;
  for (int v234_12_label = 1; v234_12_label <= 2; ++v234_12_label) {
    const Space v234_12_tail = child(s0,v234_12_label);
    if (v234_12_tail.empty()) continue;
    const Path v234_12_head{v234_12_label};
    const Space v235_2 = singleton(v234_12_head);
    const Space v235_3 = intersect(constant_3,v235_2);
    const Space v235_4 = (has_head(v235_3) ? constant_4 : Space{});
    const Space v235_5 = subtract(constant_2,v235_4);
    Space v235_8;
    if (!v235_5.empty()) {
      const Path v236_6 = concat_path(p0,v234_12_head);
      Space v236_7_result;
      for (int v236_7_label = 1; v236_7_label <= 2; ++v236_7_label) {
        const Space v236_7_tail = child(v234_12_tail,v236_7_label);
        if (v236_7_tail.empty()) continue;
        const Path v236_7_head{v236_7_label};
        const Space v237_2 = singleton(v236_7_head);
        const Space v237_3 = intersect(constant_3,v237_2);
        const Space v237_4 = (has_head(v237_3) ? constant_4 : Space{});
        const Space v237_5 = subtract(constant_2,v237_4);
        Space v237_8;
        if (!v237_5.empty()) {
          const Path v238_6 = concat_path(v236_6,v236_7_head);
          const Space v238_7 = routine_55(c, v238_6, p1, v236_7_tail);
          v237_8 = compose(v237_5,v238_7);
        }
        const Space v237_9 = intersect(constant_3,v237_2);
        const Space v237_10 = (has_head(v237_9) ? constant_4 : Space{});
        Space v237_12;
        if (!v237_10.empty()) {
          const Path v239_6 = concat_path(v236_6,v236_7_head);
          const Space v239_11 = routine_56(c, v239_6, p1, v236_7_tail);
          v237_12 = compose(v237_10,v239_11);
        }
        const Space v237_13 = unite(v237_8,v237_12);
        v236_7_result = unite(v236_7_result,v237_13);
      }
      const Space v236_7 = std::move(v236_7_result);
      v235_8 = compose(v235_5,v236_7);
    }
    const Space v235_9 = intersect(constant_3,v235_2);
    const Space v235_10 = (has_head(v235_9) ? constant_4 : Space{});
    Space v235_12;
    if (!v235_10.empty()) {
      const Path v240_6 = concat_path(p0,v234_12_head);
      Space v240_11_result;
      for (int v240_11_label = 1; v240_11_label <= 2; ++v240_11_label) {
        const Space v240_11_tail = child(v234_12_tail,v240_11_label);
        if (v240_11_tail.empty()) continue;
        const Path v240_11_head{v240_11_label};
        const Space v241_2 = singleton(v240_11_head);
        const Space v241_3 = intersect(constant_3,v241_2);
        const Space v241_4 = (has_head(v241_3) ? constant_4 : Space{});
        const Space v241_5 = subtract(constant_2,v241_4);
        Space v241_8;
        if (!v241_5.empty()) {
          const Path v242_6 = concat_path(v240_6,v240_11_head);
          const Space v242_7 = routine_55(c, v242_6, p1, v240_11_tail);
          v241_8 = compose(v241_5,v242_7);
        }
        const Space v241_9 = intersect(constant_3,v241_2);
        const Space v241_10 = (has_head(v241_9) ? constant_4 : Space{});
        Space v241_12;
        if (!v241_10.empty()) {
          const Path v243_6 = concat_path(v240_6,v240_11_head);
          const Space v243_11 = routine_22(c, v243_6, p1, v240_11_tail);
          v241_12 = compose(v241_10,v243_11);
        }
        const Space v241_13 = unite(v241_8,v241_12);
        v240_11_result = unite(v240_11_result,v241_13);
      }
      const Space v240_11 = std::move(v240_11_result);
      v235_12 = compose(v235_10,v240_11);
    }
    const Space v235_13 = unite(v235_8,v235_12);
    v234_12_result = unite(v234_12_result,v235_13);
  }
  const Space v234_12 = std::move(v234_12_result);
  return v234_12;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v244_10_result;
  for (int v244_10_label = 1; v244_10_label <= 2; ++v244_10_label) {
    const Space v244_10_tail = child(s0,v244_10_label);
    if (v244_10_tail.empty()) continue;
    const Path v244_10_head{v244_10_label};
    const Space v245_2 = singleton(v244_10_head);
    const Space v245_3 = intersect(constant_3,v245_2);
    const Space v245_4 = (has_head(v245_3) ? constant_4 : Space{});
    const Space v245_5 = compose(v245_4,v244_10_tail);
    const Path v246_6 = concat_path(p0,v244_10_head);
    const Space v245_7 = wrap(v245_5,v246_6);
    const Space v245_8 = wrap(v245_7,p1);
    const Space v245_9 = wrap(v245_8,constant_6);
    const Space v245_10 = intersect(constant_3,v245_2);
    const Space v245_11 = (has_head(v245_10) ? constant_4 : Space{});
    const Space v245_12 = subtract(constant_2,v245_11);
    Space v245_14;
    if (!v245_12.empty()) {
      Space v247_13_result;
      for (int v247_13_label = 1; v247_13_label <= 2; ++v247_13_label) {
        const Space v247_13_tail = child(v244_10_tail,v247_13_label);
        if (v247_13_tail.empty()) continue;
        const Path v247_13_head{v247_13_label};
        const Space v248_2 = singleton(v247_13_head);
        const Space v248_3 = intersect(constant_3,v248_2);
        const Space v248_4 = (has_head(v248_3) ? constant_4 : Space{});
        const Space v248_5 = subtract(constant_2,v248_4);
        Space v248_8;
        if (!v248_5.empty()) {
          const Path v249_6 = concat_path(v246_6,v247_13_head);
          const Space v249_7 = routine_55(c, v249_6, p1, v247_13_tail);
          v248_8 = compose(v248_5,v249_7);
        }
        const Space v248_9 = intersect(constant_3,v248_2);
        const Space v248_10 = (has_head(v248_9) ? constant_4 : Space{});
        Space v248_12;
        if (!v248_10.empty()) {
          const Path v250_6 = concat_path(v246_6,v247_13_head);
          const Space v250_11 = routine_56(c, v250_6, p1, v247_13_tail);
          v248_12 = compose(v248_10,v250_11);
        }
        const Space v248_13 = unite(v248_8,v248_12);
        v247_13_result = unite(v247_13_result,v248_13);
      }
      const Space v247_13 = std::move(v247_13_result);
      v245_14 = compose(v245_12,v247_13);
    }
    const Space v245_15 = unite(v245_9,v245_14);
    v244_10_result = unite(v244_10_result,v245_15);
  }
  const Space v244_10 = std::move(v244_10_result);
  return v244_10;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v251_3 = wrap(s0,p0);
  const Space v251_4 = wrap(v251_3,p1);
  const Space v251_6 = wrap(v251_4,constant_6);
  return v251_6;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v252_12_result;
  for (int v252_12_label = 1; v252_12_label <= 2; ++v252_12_label) {
    const Space v252_12_tail = child(s0,v252_12_label);
    if (v252_12_tail.empty()) continue;
    const Path v252_12_head{v252_12_label};
    const Space v253_2 = singleton(v252_12_head);
    const Space v253_3 = intersect(constant_3,v253_2);
    const Space v253_4 = (has_head(v253_3) ? constant_4 : Space{});
    const Space v253_5 = subtract(constant_2,v253_4);
    Space v253_8;
    if (!v253_5.empty()) {
      const Path v254_6 = concat_path(p0,v252_12_head);
      Space v254_7_result;
      for (int v254_7_label = 1; v254_7_label <= 2; ++v254_7_label) {
        const Space v254_7_tail = child(v252_12_tail,v254_7_label);
        if (v254_7_tail.empty()) continue;
        const Path v254_7_head{v254_7_label};
        const Space v255_2 = singleton(v254_7_head);
        const Space v255_3 = intersect(constant_3,v255_2);
        const Space v255_4 = (has_head(v255_3) ? constant_4 : Space{});
        const Space v255_5 = subtract(constant_2,v255_4);
        Space v255_8;
        if (!v255_5.empty()) {
          const Path v256_6 = concat_path(v254_6,v254_7_head);
          const Space v256_7 = routine_57(c, v256_6, v254_7_tail, s1);
          v255_8 = compose(v255_5,v256_7);
        }
        const Space v255_9 = intersect(constant_3,v255_2);
        const Space v255_10 = (has_head(v255_9) ? constant_4 : Space{});
        Space v255_12;
        if (!v255_10.empty()) {
          const Path v257_6 = concat_path(v254_6,v254_7_head);
          const Space v257_11 = routine_58(c, v257_6, v254_7_tail, s1);
          v255_12 = compose(v255_10,v257_11);
        }
        const Space v255_13 = unite(v255_8,v255_12);
        v254_7_result = unite(v254_7_result,v255_13);
      }
      const Space v254_7 = std::move(v254_7_result);
      v253_8 = compose(v253_5,v254_7);
    }
    const Space v253_9 = intersect(constant_3,v253_2);
    const Space v253_10 = (has_head(v253_9) ? constant_4 : Space{});
    Space v253_12;
    if (!v253_10.empty()) {
      const Path v258_6 = concat_path(p0,v252_12_head);
      Space v258_11_result;
      for (int v258_11_label = 1; v258_11_label <= 2; ++v258_11_label) {
        const Space v258_11_tail = child(v252_12_tail,v258_11_label);
        if (v258_11_tail.empty()) continue;
        const Path v258_11_head{v258_11_label};
        const Space v259_2 = singleton(v258_11_head);
        const Space v259_3 = intersect(constant_3,v259_2);
        const Space v259_4 = (has_head(v259_3) ? constant_4 : Space{});
        const Space v259_5 = subtract(constant_2,v259_4);
        Space v259_8;
        if (!v259_5.empty()) {
          const Path v260_6 = concat_path(v258_6,v258_11_head);
          const Space v260_7 = routine_57(c, v260_6, v258_11_tail, s1);
          v259_8 = compose(v259_5,v260_7);
        }
        const Space v259_9 = intersect(constant_3,v259_2);
        const Space v259_10 = (has_head(v259_9) ? constant_4 : Space{});
        Space v259_12;
        if (!v259_10.empty()) {
          const Path v261_6 = concat_path(v258_6,v258_11_head);
          const Space v261_11 = routine_6(c, v261_6, v258_11_tail, s1);
          v259_12 = compose(v259_10,v261_11);
        }
        const Space v259_13 = unite(v259_8,v259_12);
        v258_11_result = unite(v258_11_result,v259_13);
      }
      const Space v258_11 = std::move(v258_11_result);
      v253_12 = compose(v253_10,v258_11);
    }
    const Space v253_13 = unite(v253_8,v253_12);
    v252_12_result = unite(v252_12_result,v253_13);
  }
  const Space v252_12 = std::move(v252_12_result);
  return v252_12;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v262_12_result;
  for (int v262_12_label = 1; v262_12_label <= 2; ++v262_12_label) {
    const Space v262_12_tail = child(s0,v262_12_label);
    if (v262_12_tail.empty()) continue;
    const Path v262_12_head{v262_12_label};
    const Space v263_2 = singleton(v262_12_head);
    const Space v263_3 = intersect(constant_3,v263_2);
    const Space v263_4 = (has_head(v263_3) ? constant_4 : Space{});
    const Space v263_5 = subtract(constant_2,v263_4);
    Space v263_8;
    if (!v263_5.empty()) {
      const Path v264_6 = concat_path(p0,v262_12_head);
      Space v264_7_result;
      for (int v264_7_label = 1; v264_7_label <= 2; ++v264_7_label) {
        const Space v264_7_tail = child(v262_12_tail,v264_7_label);
        if (v264_7_tail.empty()) continue;
        const Path v264_7_head{v264_7_label};
        const Space v265_2 = singleton(v264_7_head);
        const Space v265_3 = intersect(constant_3,v265_2);
        const Space v265_4 = (has_head(v265_3) ? constant_4 : Space{});
        const Space v265_5 = subtract(constant_2,v265_4);
        Space v265_8;
        if (!v265_5.empty()) {
          const Path v266_6 = concat_path(v264_6,v264_7_head);
          const Space v266_7 = routine_57(c, v266_6, v264_7_tail, s1);
          v265_8 = compose(v265_5,v266_7);
        }
        const Space v265_9 = intersect(constant_3,v265_2);
        const Space v265_10 = (has_head(v265_9) ? constant_4 : Space{});
        Space v265_12;
        if (!v265_10.empty()) {
          const Path v267_6 = concat_path(v264_6,v264_7_head);
          const Space v267_11 = routine_58(c, v267_6, v264_7_tail, s1);
          v265_12 = compose(v265_10,v267_11);
        }
        const Space v265_13 = unite(v265_8,v265_12);
        v264_7_result = unite(v264_7_result,v265_13);
      }
      const Space v264_7 = std::move(v264_7_result);
      v263_8 = compose(v263_5,v264_7);
    }
    const Space v263_9 = intersect(constant_3,v263_2);
    const Space v263_10 = (has_head(v263_9) ? constant_4 : Space{});
    Space v263_12;
    if (!v263_10.empty()) {
      const Path v268_6 = concat_path(p0,v262_12_head);
      Space v268_11_result;
      for (int v268_11_label = 1; v268_11_label <= 2; ++v268_11_label) {
        const Space v268_11_tail = child(v262_12_tail,v268_11_label);
        if (v268_11_tail.empty()) continue;
        const Path v268_11_head{v268_11_label};
        const Space v269_2 = singleton(v268_11_head);
        const Space v269_3 = intersect(constant_3,v269_2);
        const Space v269_4 = (has_head(v269_3) ? constant_4 : Space{});
        const Space v269_5 = subtract(constant_2,v269_4);
        Space v269_7;
        if (!v269_5.empty()) {
          const Space v270_6 = routine_25(c, v268_11_head, v268_6, v268_11_tail, s1);
          v269_7 = compose(v269_5,v270_6);
        }
        const Space v269_8 = intersect(constant_3,v269_2);
        const Space v269_9 = (has_head(v269_8) ? constant_4 : Space{});
        Space v269_11;
        if (!v269_9.empty()) {
          const Space v271_10 = routine_26(c, v268_11_head, v268_6, v268_11_tail, s1);
          v269_11 = compose(v269_9,v271_10);
        }
        const Space v269_12 = unite(v269_7,v269_11);
        v268_11_result = unite(v268_11_result,v269_12);
      }
      const Space v268_11 = std::move(v268_11_result);
      v263_12 = compose(v263_10,v268_11);
    }
    const Space v263_13 = unite(v263_8,v263_12);
    v262_12_result = unite(v262_12_result,v263_13);
  }
  const Space v262_12 = std::move(v262_12_result);
  return v262_12;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v272_13_result;
  for (int v272_13_label = 1; v272_13_label <= 2; ++v272_13_label) {
    const Space v272_13_tail = child(s0,v272_13_label);
    if (v272_13_tail.empty()) continue;
    const Path v272_13_head{v272_13_label};
    const Space v273_2 = singleton(v272_13_head);
    const Space v273_3 = intersect(constant_3,v273_2);
    const Space v273_4 = (has_head(v273_3) ? constant_4 : Space{});
    const Space v273_5 = subtract(constant_2,v273_4);
    Space v273_8;
    if (!v273_5.empty()) {
      const Path v274_6 = concat_path(p0,v272_13_head);
      Space v274_7_result;
      for (int v274_7_label = 1; v274_7_label <= 2; ++v274_7_label) {
        const Space v274_7_tail = child(v272_13_tail,v274_7_label);
        if (v274_7_tail.empty()) continue;
        const Path v274_7_head{v274_7_label};
        const Space v275_2 = singleton(v274_7_head);
        const Space v275_3 = intersect(constant_3,v275_2);
        const Space v275_4 = (has_head(v275_3) ? constant_4 : Space{});
        const Space v275_5 = subtract(constant_2,v275_4);
        Space v275_8;
        if (!v275_5.empty()) {
          const Path v276_6 = concat_path(v274_6,v274_7_head);
          const Space v276_7 = routine_59(c, v276_6, p1, v274_7_tail, s1);
          v275_8 = compose(v275_5,v276_7);
        }
        const Space v275_9 = intersect(constant_3,v275_2);
        const Space v275_10 = (has_head(v275_9) ? constant_4 : Space{});
        Space v275_12;
        if (!v275_10.empty()) {
          const Path v277_6 = concat_path(v274_6,v274_7_head);
          const Space v277_11 = routine_60(c, v277_6, p1, v274_7_tail, s1);
          v275_12 = compose(v275_10,v277_11);
        }
        const Space v275_13 = unite(v275_8,v275_12);
        v274_7_result = unite(v274_7_result,v275_13);
      }
      const Space v274_7 = std::move(v274_7_result);
      v273_8 = compose(v273_5,v274_7);
    }
    const Space v273_9 = intersect(constant_3,v273_2);
    const Space v273_10 = (has_head(v273_9) ? constant_4 : Space{});
    Space v273_12;
    if (!v273_10.empty()) {
      const Path v278_6 = concat_path(p0,v272_13_head);
      Space v278_11_result;
      for (int v278_11_label = 1; v278_11_label <= 2; ++v278_11_label) {
        const Space v278_11_tail = child(v272_13_tail,v278_11_label);
        if (v278_11_tail.empty()) continue;
        const Path v278_11_head{v278_11_label};
        const Space v279_2 = singleton(v278_11_head);
        const Space v279_3 = intersect(constant_3,v279_2);
        const Space v279_4 = (has_head(v279_3) ? constant_4 : Space{});
        const Space v279_5 = subtract(constant_2,v279_4);
        Space v279_8;
        if (!v279_5.empty()) {
          const Path v280_6 = concat_path(v278_6,v278_11_head);
          const Space v280_7 = routine_59(c, v280_6, p1, v278_11_tail, s1);
          v279_8 = compose(v279_5,v280_7);
        }
        const Space v279_9 = intersect(constant_3,v279_2);
        const Space v279_10 = (has_head(v279_9) ? constant_4 : Space{});
        Space v279_12;
        if (!v279_10.empty()) {
          const Path v281_6 = concat_path(v278_6,v278_11_head);
          const Space v281_11 = routine_29(c, v281_6, p1, v278_11_tail, s1);
          v279_12 = compose(v279_10,v281_11);
        }
        const Space v279_13 = unite(v279_8,v279_12);
        v278_11_result = unite(v278_11_result,v279_13);
      }
      const Space v278_11 = std::move(v278_11_result);
      v273_12 = compose(v273_10,v278_11);
    }
    const Space v273_13 = unite(v273_8,v273_12);
    v272_13_result = unite(v272_13_result,v273_13);
  }
  const Space v272_13 = std::move(v272_13_result);
  return v272_13;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v282_8 = unwrap(s1,constant_5);
  const Space v282_10 = unwrap(v282_8,constant_6);
  const Space v282_11 = unwrap(v282_10,p0);
  Space v282_18_result;
  for (int v282_18_label = 1; v282_18_label <= 2; ++v282_18_label) {
    const Space v282_18_tail = child(s0,v282_18_label);
    if (v282_18_tail.empty()) continue;
    const Path v282_18_head{v282_18_label};
    const Space v283_2 = singleton(v282_18_head);
    const Space v283_3 = intersect(constant_3,v283_2);
    const Space v283_4 = (has_head(v283_3) ? constant_4 : Space{});
    const Space v283_5 = subtract(constant_2,v283_4);
    Space v283_8;
    if (!v283_5.empty()) {
      const Path v284_6 = concat_path(p0,v282_18_head);
      Space v284_7_result;
      for (int v284_7_label = 1; v284_7_label <= 2; ++v284_7_label) {
        const Space v284_7_tail = child(v282_18_tail,v284_7_label);
        if (v284_7_tail.empty()) continue;
        const Path v284_7_head{v284_7_label};
        const Space v285_2 = singleton(v284_7_head);
        const Space v285_3 = intersect(constant_3,v285_2);
        const Space v285_4 = (has_head(v285_3) ? constant_4 : Space{});
        const Space v285_5 = subtract(constant_2,v285_4);
        Space v285_8;
        if (!v285_5.empty()) {
          const Path v286_6 = concat_path(v284_6,v284_7_head);
          const Space v286_7 = routine_59(c, v286_6, p1, v284_7_tail, s1);
          v285_8 = compose(v285_5,v286_7);
        }
        const Space v285_9 = intersect(constant_3,v285_2);
        const Space v285_10 = (has_head(v285_9) ? constant_4 : Space{});
        Space v285_12;
        if (!v285_10.empty()) {
          const Path v287_6 = concat_path(v284_6,v284_7_head);
          const Space v287_11 = routine_60(c, v287_6, p1, v284_7_tail, s1);
          v285_12 = compose(v285_10,v287_11);
        }
        const Space v285_13 = unite(v285_8,v285_12);
        v284_7_result = unite(v284_7_result,v285_13);
      }
      const Space v284_7 = std::move(v284_7_result);
      v283_8 = compose(v283_5,v284_7);
    }
    const Space v283_9 = intersect(constant_3,v283_2);
    const Space v283_10 = (has_head(v283_9) ? constant_4 : Space{});
    Space v283_13;
    if (!v283_10.empty()) {
      const Space v288_11 = unwrap(v282_11,v282_18_head);
      Space v288_12_result;
      for (int v288_12_label = 1; v288_12_label <= 2; ++v288_12_label) {
        const Space v288_12_tail = child(v288_11,v288_12_label);
        if (v288_12_tail.empty()) continue;
        const Path v288_12_head{v288_12_label};
        const Space v289_2 = singleton(v288_12_head);
        const Space v289_3 = intersect(constant_3,v289_2);
        const Space v289_4 = (has_head(v289_3) ? constant_4 : Space{});
        const Space v289_5 = subtract(constant_2,v289_4);
        Space v289_7;
        if (!v289_5.empty()) {
          const Space v290_6 = routine_61(c, v288_12_head, p1, v288_12_tail);
          v289_7 = compose(v289_5,v290_6);
        }
        const Space v289_8 = intersect(constant_3,v289_2);
        const Space v289_9 = (has_head(v289_8) ? constant_4 : Space{});
        Space v289_11;
        if (!v289_9.empty()) {
          const Space v291_10 = routine_62(c, v288_12_head, p1, v288_12_tail);
          v289_11 = compose(v289_9,v291_10);
        }
        const Space v289_12 = unite(v289_7,v289_11);
        v288_12_result = unite(v288_12_result,v289_12);
      }
      const Space v288_12 = std::move(v288_12_result);
      v283_13 = compose(v283_10,v288_12);
    }
    const Space v283_14 = unite(v283_8,v283_13);
    v282_18_result = unite(v282_18_result,v283_14);
  }
  const Space v282_18 = std::move(v282_18_result);
  return v282_18;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v292_13_result;
  for (int v292_13_label = 1; v292_13_label <= 2; ++v292_13_label) {
    const Space v292_13_tail = child(s0,v292_13_label);
    if (v292_13_tail.empty()) continue;
    const Path v292_13_head{v292_13_label};
    const Space v293_2 = singleton(v292_13_head);
    const Space v293_3 = intersect(constant_3,v293_2);
    const Space v293_4 = (has_head(v293_3) ? constant_4 : Space{});
    const Space v293_5 = subtract(constant_2,v293_4);
    Space v293_8;
    if (!v293_5.empty()) {
      const Path v294_6 = concat_path(p0,v292_13_head);
      Space v294_7_result;
      for (int v294_7_label = 1; v294_7_label <= 2; ++v294_7_label) {
        const Space v294_7_tail = child(v292_13_tail,v294_7_label);
        if (v294_7_tail.empty()) continue;
        const Path v294_7_head{v294_7_label};
        const Space v295_2 = singleton(v294_7_head);
        const Space v295_3 = intersect(constant_3,v295_2);
        const Space v295_4 = (has_head(v295_3) ? constant_4 : Space{});
        const Space v295_5 = subtract(constant_2,v295_4);
        Space v295_8;
        if (!v295_5.empty()) {
          const Path v296_6 = concat_path(v294_6,v294_7_head);
          const Space v296_7 = routine_63(c, v296_6, p1, v294_7_tail, s1);
          v295_8 = compose(v295_5,v296_7);
        }
        const Space v295_9 = intersect(constant_3,v295_2);
        const Space v295_10 = (has_head(v295_9) ? constant_4 : Space{});
        Space v295_12;
        if (!v295_10.empty()) {
          const Path v297_6 = concat_path(v294_6,v294_7_head);
          const Space v297_11 = routine_64(c, v297_6, p1, v294_7_tail, s1);
          v295_12 = compose(v295_10,v297_11);
        }
        const Space v295_13 = unite(v295_8,v295_12);
        v294_7_result = unite(v294_7_result,v295_13);
      }
      const Space v294_7 = std::move(v294_7_result);
      v293_8 = compose(v293_5,v294_7);
    }
    const Space v293_9 = intersect(constant_3,v293_2);
    const Space v293_10 = (has_head(v293_9) ? constant_4 : Space{});
    Space v293_12;
    if (!v293_10.empty()) {
      const Path v298_6 = concat_path(p0,v292_13_head);
      Space v298_11_result;
      for (int v298_11_label = 1; v298_11_label <= 2; ++v298_11_label) {
        const Space v298_11_tail = child(v292_13_tail,v298_11_label);
        if (v298_11_tail.empty()) continue;
        const Path v298_11_head{v298_11_label};
        const Space v299_2 = singleton(v298_11_head);
        const Space v299_3 = intersect(constant_3,v299_2);
        const Space v299_4 = (has_head(v299_3) ? constant_4 : Space{});
        const Space v299_5 = subtract(constant_2,v299_4);
        Space v299_8;
        if (!v299_5.empty()) {
          const Path v300_6 = concat_path(v298_6,v298_11_head);
          const Space v300_7 = routine_63(c, v300_6, p1, v298_11_tail, s1);
          v299_8 = compose(v299_5,v300_7);
        }
        const Space v299_9 = intersect(constant_3,v299_2);
        const Space v299_10 = (has_head(v299_9) ? constant_4 : Space{});
        Space v299_12;
        if (!v299_10.empty()) {
          const Path v301_6 = concat_path(v298_6,v298_11_head);
          const Space v301_11 = routine_29(c, v301_6, p1, v298_11_tail, s1);
          v299_12 = compose(v299_10,v301_11);
        }
        const Space v299_13 = unite(v299_8,v299_12);
        v298_11_result = unite(v298_11_result,v299_13);
      }
      const Space v298_11 = std::move(v298_11_result);
      v293_12 = compose(v293_10,v298_11);
    }
    const Space v293_13 = unite(v293_8,v293_12);
    v292_13_result = unite(v292_13_result,v293_13);
  }
  const Space v292_13 = std::move(v292_13_result);
  return v292_13;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v302_8 = unwrap(s1,constant_5);
  const Space v302_10 = unwrap(v302_8,constant_6);
  const Space v302_11 = unwrap(v302_10,p0);
  Space v302_18_result;
  for (int v302_18_label = 1; v302_18_label <= 2; ++v302_18_label) {
    const Space v302_18_tail = child(s0,v302_18_label);
    if (v302_18_tail.empty()) continue;
    const Path v302_18_head{v302_18_label};
    const Space v303_2 = singleton(v302_18_head);
    const Space v303_3 = intersect(constant_3,v303_2);
    const Space v303_4 = (has_head(v303_3) ? constant_4 : Space{});
    const Space v303_5 = subtract(constant_2,v303_4);
    Space v303_8;
    if (!v303_5.empty()) {
      const Path v304_6 = concat_path(p0,v302_18_head);
      Space v304_7_result;
      for (int v304_7_label = 1; v304_7_label <= 2; ++v304_7_label) {
        const Space v304_7_tail = child(v302_18_tail,v304_7_label);
        if (v304_7_tail.empty()) continue;
        const Path v304_7_head{v304_7_label};
        const Space v305_2 = singleton(v304_7_head);
        const Space v305_3 = intersect(constant_3,v305_2);
        const Space v305_4 = (has_head(v305_3) ? constant_4 : Space{});
        const Space v305_5 = subtract(constant_2,v305_4);
        Space v305_8;
        if (!v305_5.empty()) {
          const Path v306_6 = concat_path(v304_6,v304_7_head);
          const Space v306_7 = routine_63(c, v306_6, p1, v304_7_tail, s1);
          v305_8 = compose(v305_5,v306_7);
        }
        const Space v305_9 = intersect(constant_3,v305_2);
        const Space v305_10 = (has_head(v305_9) ? constant_4 : Space{});
        Space v305_12;
        if (!v305_10.empty()) {
          const Path v307_6 = concat_path(v304_6,v304_7_head);
          const Space v307_11 = routine_64(c, v307_6, p1, v304_7_tail, s1);
          v305_12 = compose(v305_10,v307_11);
        }
        const Space v305_13 = unite(v305_8,v305_12);
        v304_7_result = unite(v304_7_result,v305_13);
      }
      const Space v304_7 = std::move(v304_7_result);
      v303_8 = compose(v303_5,v304_7);
    }
    const Space v303_9 = intersect(constant_3,v303_2);
    const Space v303_10 = (has_head(v303_9) ? constant_4 : Space{});
    Space v303_13;
    if (!v303_10.empty()) {
      const Space v308_11 = unwrap(v302_11,v302_18_head);
      Space v308_12_result;
      for (int v308_12_label = 1; v308_12_label <= 2; ++v308_12_label) {
        const Space v308_12_tail = child(v308_11,v308_12_label);
        if (v308_12_tail.empty()) continue;
        const Path v308_12_head{v308_12_label};
        const Space v309_2 = singleton(v308_12_head);
        const Space v309_3 = intersect(constant_3,v309_2);
        const Space v309_4 = (has_head(v309_3) ? constant_4 : Space{});
        const Space v309_5 = subtract(constant_2,v309_4);
        Space v309_7;
        if (!v309_5.empty()) {
          const Space v310_6 = routine_61(c, v308_12_head, p1, v308_12_tail);
          v309_7 = compose(v309_5,v310_6);
        }
        const Space v309_8 = intersect(constant_3,v309_2);
        const Space v309_9 = (has_head(v309_8) ? constant_4 : Space{});
        Space v309_11;
        if (!v309_9.empty()) {
          const Space v311_10 = routine_62(c, v308_12_head, p1, v308_12_tail);
          v309_11 = compose(v309_9,v311_10);
        }
        const Space v309_12 = unite(v309_7,v309_11);
        v308_12_result = unite(v308_12_result,v309_12);
      }
      const Space v308_12 = std::move(v308_12_result);
      v303_13 = compose(v303_10,v308_12);
    }
    const Space v303_14 = unite(v303_8,v303_13);
    v302_18_result = unite(v302_18_result,v303_14);
  }
  const Space v302_18 = std::move(v302_18_result);
  return v302_18;
}

static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v312_5 = unwrap(s1,constant_5);
  const Space v312_7 = unwrap(v312_5,constant_6);
  const Space v312_8 = unwrap(v312_7,p0);
  Space v312_18_result;
  for (int v312_18_label = 1; v312_18_label <= 2; ++v312_18_label) {
    const Space v312_18_tail = child(v312_8,v312_18_label);
    if (v312_18_tail.empty()) continue;
    const Path v312_18_head{v312_18_label};
    const Space v313_2 = singleton(v312_18_head);
    const Space v313_3 = intersect(constant_3,v313_2);
    const Space v313_4 = (has_head(v313_3) ? constant_4 : Space{});
    const Space v313_5 = subtract(constant_2,v313_4);
    Space v313_7;
    if (!v313_5.empty()) {
      Space v314_6_result;
      for (int v314_6_label = 1; v314_6_label <= 2; ++v314_6_label) {
        const Space v314_6_tail = child(v312_18_tail,v314_6_label);
        if (v314_6_tail.empty()) continue;
        const Path v314_6_head{v314_6_label};
        const Space v315_2 = singleton(v314_6_head);
        const Space v315_3 = intersect(constant_3,v315_2);
        const Space v315_4 = (has_head(v315_3) ? constant_4 : Space{});
        const Space v315_5 = subtract(constant_2,v315_4);
        Space v315_8;
        if (!v315_5.empty()) {
          const Path v316_6 = concat_path(v312_18_head,v314_6_head);
          const Space v316_7 = routine_65(c, v316_6, p1, v314_6_tail);
          v315_8 = compose(v315_5,v316_7);
        }
        const Space v315_9 = intersect(constant_3,v315_2);
        const Space v315_10 = (has_head(v315_9) ? constant_4 : Space{});
        Space v315_12;
        if (!v315_10.empty()) {
          const Path v317_6 = concat_path(v312_18_head,v314_6_head);
          const Space v317_11 = routine_66(c, v317_6, p1, v314_6_tail);
          v315_12 = compose(v315_10,v317_11);
        }
        const Space v315_13 = unite(v315_8,v315_12);
        v314_6_result = unite(v314_6_result,v315_13);
      }
      const Space v314_6 = std::move(v314_6_result);
      v313_7 = compose(v313_5,v314_6);
    }
    const Space v313_8 = intersect(constant_3,v313_2);
    const Space v313_9 = (has_head(v313_8) ? constant_4 : Space{});
    Space v313_11;
    if (!v313_9.empty()) {
      Space v318_10_result;
      for (int v318_10_label = 1; v318_10_label <= 2; ++v318_10_label) {
        const Space v318_10_tail = child(v312_18_tail,v318_10_label);
        if (v318_10_tail.empty()) continue;
        const Path v318_10_head{v318_10_label};
        const Space v319_2 = singleton(v318_10_head);
        const Space v319_3 = intersect(constant_3,v319_2);
        const Space v319_4 = (has_head(v319_3) ? constant_4 : Space{});
        const Space v319_5 = subtract(constant_2,v319_4);
        Space v319_8;
        if (!v319_5.empty()) {
          const Path v320_6 = concat_path(v312_18_head,v318_10_head);
          const Space v320_7 = routine_65(c, v320_6, p1, v318_10_tail);
          v319_8 = compose(v319_5,v320_7);
        }
        const Space v319_9 = intersect(constant_3,v319_2);
        const Space v319_10 = (has_head(v319_9) ? constant_4 : Space{});
        Space v319_12;
        if (!v319_10.empty()) {
          const Path v321_6 = concat_path(v312_18_head,v318_10_head);
          const Space v321_11 = routine_67(c, v321_6, p1, v318_10_tail);
          v319_12 = compose(v319_10,v321_11);
        }
        const Space v319_13 = unite(v319_8,v319_12);
        v318_10_result = unite(v318_10_result,v319_13);
      }
      const Space v318_10 = std::move(v318_10_result);
      v313_11 = compose(v313_9,v318_10);
    }
    const Space v313_12 = unite(v313_7,v313_11);
    v312_18_result = unite(v312_18_result,v313_12);
  }
  const Space v312_18 = std::move(v312_18_result);
  return v312_18;
}

static Space routine_30(Context& c, const Path& p0, const Space& s0) {
  Space v322_11_result;
  for (int v322_11_label = 1; v322_11_label <= 2; ++v322_11_label) {
    const Space v322_11_tail = child(s0,v322_11_label);
    if (v322_11_tail.empty()) continue;
    const Path v322_11_head{v322_11_label};
    const Space v323_2 = singleton(v322_11_head);
    const Space v323_3 = intersect(constant_3,v323_2);
    const Space v323_4 = (has_head(v323_3) ? constant_4 : Space{});
    const Space v323_5 = subtract(constant_2,v323_4);
    Space v323_8;
    if (!v323_5.empty()) {
      const Path v324_6 = concat_path(p0,v322_11_head);
      Space v324_7_result;
      for (int v324_7_label = 1; v324_7_label <= 2; ++v324_7_label) {
        const Space v324_7_tail = child(v322_11_tail,v324_7_label);
        if (v324_7_tail.empty()) continue;
        const Path v324_7_head{v324_7_label};
        const Space v325_2 = singleton(v324_7_head);
        const Space v325_3 = intersect(constant_3,v325_2);
        const Space v325_4 = (has_head(v325_3) ? constant_4 : Space{});
        const Space v325_5 = subtract(constant_2,v325_4);
        Space v325_8;
        if (!v325_5.empty()) {
          const Path v326_6 = concat_path(v324_6,v324_7_head);
          const Space v326_7 = routine_68(c, v326_6, v324_7_tail);
          v325_8 = compose(v325_5,v326_7);
        }
        const Space v325_9 = intersect(constant_3,v325_2);
        const Space v325_10 = (has_head(v325_9) ? constant_4 : Space{});
        Space v325_12;
        if (!v325_10.empty()) {
          const Path v327_6 = concat_path(v324_6,v324_7_head);
          const Space v327_11 = routine_69(c, v327_6, v324_7_tail);
          v325_12 = compose(v325_10,v327_11);
        }
        const Space v325_13 = unite(v325_8,v325_12);
        v324_7_result = unite(v324_7_result,v325_13);
      }
      const Space v324_7 = std::move(v324_7_result);
      v323_8 = compose(v323_5,v324_7);
    }
    const Space v323_9 = intersect(constant_3,v323_2);
    const Space v323_10 = (has_head(v323_9) ? constant_4 : Space{});
    Space v323_12;
    if (!v323_10.empty()) {
      const Path v328_6 = concat_path(p0,v322_11_head);
      Space v328_11_result;
      for (int v328_11_label = 1; v328_11_label <= 2; ++v328_11_label) {
        const Space v328_11_tail = child(v322_11_tail,v328_11_label);
        if (v328_11_tail.empty()) continue;
        const Path v328_11_head{v328_11_label};
        const Space v329_2 = singleton(v328_11_head);
        const Space v329_3 = intersect(constant_3,v329_2);
        const Space v329_4 = (has_head(v329_3) ? constant_4 : Space{});
        const Space v329_5 = subtract(constant_2,v329_4);
        Space v329_8;
        if (!v329_5.empty()) {
          const Path v330_6 = concat_path(v328_6,v328_11_head);
          const Space v330_7 = routine_68(c, v330_6, v328_11_tail);
          v329_8 = compose(v329_5,v330_7);
        }
        const Space v329_9 = intersect(constant_3,v329_2);
        const Space v329_10 = (has_head(v329_9) ? constant_4 : Space{});
        Space v329_12;
        if (!v329_10.empty()) {
          const Path v331_6 = concat_path(v328_6,v328_11_head);
          const Space v331_11 = routine_9(c, v331_6, v328_11_tail);
          v329_12 = compose(v329_10,v331_11);
        }
        const Space v329_13 = unite(v329_8,v329_12);
        v328_11_result = unite(v328_11_result,v329_13);
      }
      const Space v328_11 = std::move(v328_11_result);
      v323_12 = compose(v323_10,v328_11);
    }
    const Space v323_13 = unite(v323_8,v323_12);
    v322_11_result = unite(v322_11_result,v323_13);
  }
  const Space v322_11 = std::move(v322_11_result);
  return v322_11;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0) {
  Space v332_11_result;
  for (int v332_11_label = 1; v332_11_label <= 2; ++v332_11_label) {
    const Space v332_11_tail = child(s0,v332_11_label);
    if (v332_11_tail.empty()) continue;
    const Path v332_11_head{v332_11_label};
    const Space v333_2 = singleton(v332_11_head);
    const Space v333_3 = intersect(constant_3,v333_2);
    const Space v333_4 = (has_head(v333_3) ? constant_4 : Space{});
    const Space v333_5 = subtract(constant_2,v333_4);
    Space v333_8;
    if (!v333_5.empty()) {
      const Path v334_6 = concat_path(p0,v332_11_head);
      Space v334_7_result;
      for (int v334_7_label = 1; v334_7_label <= 2; ++v334_7_label) {
        const Space v334_7_tail = child(v332_11_tail,v334_7_label);
        if (v334_7_tail.empty()) continue;
        const Path v334_7_head{v334_7_label};
        const Space v335_2 = singleton(v334_7_head);
        const Space v335_3 = intersect(constant_3,v335_2);
        const Space v335_4 = (has_head(v335_3) ? constant_4 : Space{});
        const Space v335_5 = subtract(constant_2,v335_4);
        Space v335_8;
        if (!v335_5.empty()) {
          const Path v336_6 = concat_path(v334_6,v334_7_head);
          const Space v336_7 = routine_68(c, v336_6, v334_7_tail);
          v335_8 = compose(v335_5,v336_7);
        }
        const Space v335_9 = intersect(constant_3,v335_2);
        const Space v335_10 = (has_head(v335_9) ? constant_4 : Space{});
        Space v335_12;
        if (!v335_10.empty()) {
          const Path v337_6 = concat_path(v334_6,v334_7_head);
          const Space v337_11 = routine_69(c, v337_6, v334_7_tail);
          v335_12 = compose(v335_10,v337_11);
        }
        const Space v335_13 = unite(v335_8,v335_12);
        v334_7_result = unite(v334_7_result,v335_13);
      }
      const Space v334_7 = std::move(v334_7_result);
      v333_8 = compose(v333_5,v334_7);
    }
    const Space v333_9 = intersect(constant_3,v333_2);
    const Space v333_10 = (has_head(v333_9) ? constant_4 : Space{});
    Space v333_12;
    if (!v333_10.empty()) {
      const Path v338_6 = concat_path(p0,v332_11_head);
      Space v338_11_result;
      for (int v338_11_label = 1; v338_11_label <= 2; ++v338_11_label) {
        const Space v338_11_tail = child(v332_11_tail,v338_11_label);
        if (v338_11_tail.empty()) continue;
        const Path v338_11_head{v338_11_label};
        const Space v339_2 = singleton(v338_11_head);
        const Space v339_3 = intersect(constant_3,v339_2);
        const Space v339_4 = (has_head(v339_3) ? constant_4 : Space{});
        const Space v339_5 = subtract(constant_2,v339_4);
        Space v339_7;
        if (!v339_5.empty()) {
          const Space v340_6 = routine_32(c, v338_11_head, v338_6, v338_11_tail);
          v339_7 = compose(v339_5,v340_6);
        }
        const Space v339_8 = intersect(constant_3,v339_2);
        const Space v339_9 = (has_head(v339_8) ? constant_4 : Space{});
        Space v339_11;
        if (!v339_9.empty()) {
          const Space v341_10 = routine_33(c, v338_11_head, v338_6, v338_11_tail);
          v339_11 = compose(v339_9,v341_10);
        }
        const Space v339_12 = unite(v339_7,v339_11);
        v338_11_result = unite(v338_11_result,v339_12);
      }
      const Space v338_11 = std::move(v338_11_result);
      v333_12 = compose(v333_10,v338_11);
    }
    const Space v333_13 = unite(v333_8,v333_12);
    v332_11_result = unite(v332_11_result,v333_13);
  }
  const Space v332_11 = std::move(v332_11_result);
  return v332_11;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v342_12_result;
  for (int v342_12_label = 1; v342_12_label <= 2; ++v342_12_label) {
    const Space v342_12_tail = child(s0,v342_12_label);
    if (v342_12_tail.empty()) continue;
    const Path v342_12_head{v342_12_label};
    const Space v343_2 = singleton(v342_12_head);
    const Space v343_3 = intersect(constant_3,v343_2);
    const Space v343_4 = (has_head(v343_3) ? constant_4 : Space{});
    const Space v343_5 = subtract(constant_2,v343_4);
    Space v343_8;
    if (!v343_5.empty()) {
      const Path v344_6 = concat_path(p0,v342_12_head);
      Space v344_7_result;
      for (int v344_7_label = 1; v344_7_label <= 2; ++v344_7_label) {
        const Space v344_7_tail = child(v342_12_tail,v344_7_label);
        if (v344_7_tail.empty()) continue;
        const Path v344_7_head{v344_7_label};
        const Space v345_2 = singleton(v344_7_head);
        const Space v345_3 = intersect(constant_3,v345_2);
        const Space v345_4 = (has_head(v345_3) ? constant_4 : Space{});
        const Space v345_5 = subtract(constant_2,v345_4);
        Space v345_8;
        if (!v345_5.empty()) {
          const Path v346_6 = concat_path(v344_6,v344_7_head);
          const Space v346_7 = routine_70(c, v346_6, p1, v344_7_tail);
          v345_8 = compose(v345_5,v346_7);
        }
        const Space v345_9 = intersect(constant_3,v345_2);
        const Space v345_10 = (has_head(v345_9) ? constant_4 : Space{});
        Space v345_12;
        if (!v345_10.empty()) {
          const Path v347_6 = concat_path(v344_6,v344_7_head);
          const Space v347_11 = routine_71(c, v347_6, p1, v344_7_tail);
          v345_12 = compose(v345_10,v347_11);
        }
        const Space v345_13 = unite(v345_8,v345_12);
        v344_7_result = unite(v344_7_result,v345_13);
      }
      const Space v344_7 = std::move(v344_7_result);
      v343_8 = compose(v343_5,v344_7);
    }
    const Space v343_9 = intersect(constant_3,v343_2);
    const Space v343_10 = (has_head(v343_9) ? constant_4 : Space{});
    Space v343_12;
    if (!v343_10.empty()) {
      const Path v348_6 = concat_path(p0,v342_12_head);
      Space v348_11_result;
      for (int v348_11_label = 1; v348_11_label <= 2; ++v348_11_label) {
        const Space v348_11_tail = child(v342_12_tail,v348_11_label);
        if (v348_11_tail.empty()) continue;
        const Path v348_11_head{v348_11_label};
        const Space v349_2 = singleton(v348_11_head);
        const Space v349_3 = intersect(constant_3,v349_2);
        const Space v349_4 = (has_head(v349_3) ? constant_4 : Space{});
        const Space v349_5 = subtract(constant_2,v349_4);
        Space v349_8;
        if (!v349_5.empty()) {
          const Path v350_6 = concat_path(v348_6,v348_11_head);
          const Space v350_7 = routine_70(c, v350_6, p1, v348_11_tail);
          v349_8 = compose(v349_5,v350_7);
        }
        const Space v349_9 = intersect(constant_3,v349_2);
        const Space v349_10 = (has_head(v349_9) ? constant_4 : Space{});
        Space v349_12;
        if (!v349_10.empty()) {
          const Path v351_6 = concat_path(v348_6,v348_11_head);
          const Space v351_11 = routine_36(c, v351_6, p1, v348_11_tail);
          v349_12 = compose(v349_10,v351_11);
        }
        const Space v349_13 = unite(v349_8,v349_12);
        v348_11_result = unite(v348_11_result,v349_13);
      }
      const Space v348_11 = std::move(v348_11_result);
      v343_12 = compose(v343_10,v348_11);
    }
    const Space v343_13 = unite(v343_8,v343_12);
    v342_12_result = unite(v342_12_result,v343_13);
  }
  const Space v342_12 = std::move(v342_12_result);
  return v342_12;
}

static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v352_9_result;
  for (int v352_9_label = 1; v352_9_label <= 2; ++v352_9_label) {
    const Space v352_9_tail = child(s0,v352_9_label);
    if (v352_9_tail.empty()) continue;
    const Path v352_9_head{v352_9_label};
    const Space v353_2 = singleton(v352_9_head);
    const Space v353_3 = intersect(constant_3,v353_2);
    const Space v353_4 = (has_head(v353_3) ? constant_4 : Space{});
    const Space v353_5 = subtract(constant_2,v353_4);
    Space v353_8;
    if (!v353_5.empty()) {
      const Path v354_6 = concat_path(p0,v352_9_head);
      Space v354_7_result;
      for (int v354_7_label = 1; v354_7_label <= 2; ++v354_7_label) {
        const Space v354_7_tail = child(v352_9_tail,v354_7_label);
        if (v354_7_tail.empty()) continue;
        const Path v354_7_head{v354_7_label};
        const Space v355_2 = singleton(v354_7_head);
        const Space v355_3 = intersect(constant_3,v355_2);
        const Space v355_4 = (has_head(v355_3) ? constant_4 : Space{});
        const Space v355_5 = subtract(constant_2,v355_4);
        Space v355_8;
        if (!v355_5.empty()) {
          const Path v356_6 = concat_path(v354_6,v354_7_head);
          const Space v356_7 = routine_70(c, v356_6, p1, v354_7_tail);
          v355_8 = compose(v355_5,v356_7);
        }
        const Space v355_9 = intersect(constant_3,v355_2);
        const Space v355_10 = (has_head(v355_9) ? constant_4 : Space{});
        Space v355_12;
        if (!v355_10.empty()) {
          const Path v357_6 = concat_path(v354_6,v354_7_head);
          const Space v357_11 = routine_71(c, v357_6, p1, v354_7_tail);
          v355_12 = compose(v355_10,v357_11);
        }
        const Space v355_13 = unite(v355_8,v355_12);
        v354_7_result = unite(v354_7_result,v355_13);
      }
      const Space v354_7 = std::move(v354_7_result);
      v353_8 = compose(v353_5,v354_7);
    }
    const Space v353_9 = intersect(constant_3,v353_2);
    const Space v353_10 = (has_head(v353_9) ? constant_4 : Space{});
    const Space v353_11 = compose(v353_10,v352_9_tail);
    const Path v358_6 = concat_path(p0,v352_9_head);
    const Space v353_12 = wrap(v353_11,v358_6);
    const Space v353_13 = wrap(v353_12,p1);
    const Space v353_14 = unite(v353_8,v353_13);
    v352_9_result = unite(v352_9_result,v353_14);
  }
  const Space v352_9 = std::move(v352_9_result);
  return v352_9;
}

static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v359_12_result;
  for (int v359_12_label = 1; v359_12_label <= 2; ++v359_12_label) {
    const Space v359_12_tail = child(s0,v359_12_label);
    if (v359_12_tail.empty()) continue;
    const Path v359_12_head{v359_12_label};
    const Space v360_2 = singleton(v359_12_head);
    const Space v360_3 = intersect(constant_3,v360_2);
    const Space v360_4 = (has_head(v360_3) ? constant_4 : Space{});
    const Space v360_5 = subtract(constant_2,v360_4);
    Space v360_8;
    if (!v360_5.empty()) {
      const Path v361_6 = concat_path(p0,v359_12_head);
      Space v361_7_result;
      for (int v361_7_label = 1; v361_7_label <= 2; ++v361_7_label) {
        const Space v361_7_tail = child(v359_12_tail,v361_7_label);
        if (v361_7_tail.empty()) continue;
        const Path v361_7_head{v361_7_label};
        const Space v362_2 = singleton(v361_7_head);
        const Space v362_3 = intersect(constant_3,v362_2);
        const Space v362_4 = (has_head(v362_3) ? constant_4 : Space{});
        const Space v362_5 = subtract(constant_2,v362_4);
        Space v362_8;
        if (!v362_5.empty()) {
          const Path v363_6 = concat_path(v361_6,v361_7_head);
          const Space v363_7 = routine_72(c, v363_6, p1, v361_7_tail);
          v362_8 = compose(v362_5,v363_7);
        }
        const Space v362_9 = intersect(constant_3,v362_2);
        const Space v362_10 = (has_head(v362_9) ? constant_4 : Space{});
        Space v362_12;
        if (!v362_10.empty()) {
          const Path v364_6 = concat_path(v361_6,v361_7_head);
          const Space v364_11 = routine_73(c, v364_6, p1, v361_7_tail);
          v362_12 = compose(v362_10,v364_11);
        }
        const Space v362_13 = unite(v362_8,v362_12);
        v361_7_result = unite(v361_7_result,v362_13);
      }
      const Space v361_7 = std::move(v361_7_result);
      v360_8 = compose(v360_5,v361_7);
    }
    const Space v360_9 = intersect(constant_3,v360_2);
    const Space v360_10 = (has_head(v360_9) ? constant_4 : Space{});
    Space v360_12;
    if (!v360_10.empty()) {
      const Path v365_6 = concat_path(p0,v359_12_head);
      Space v365_11_result;
      for (int v365_11_label = 1; v365_11_label <= 2; ++v365_11_label) {
        const Space v365_11_tail = child(v359_12_tail,v365_11_label);
        if (v365_11_tail.empty()) continue;
        const Path v365_11_head{v365_11_label};
        const Space v366_2 = singleton(v365_11_head);
        const Space v366_3 = intersect(constant_3,v366_2);
        const Space v366_4 = (has_head(v366_3) ? constant_4 : Space{});
        const Space v366_5 = subtract(constant_2,v366_4);
        Space v366_8;
        if (!v366_5.empty()) {
          const Path v367_6 = concat_path(v365_6,v365_11_head);
          const Space v367_7 = routine_72(c, v367_6, p1, v365_11_tail);
          v366_8 = compose(v366_5,v367_7);
        }
        const Space v366_9 = intersect(constant_3,v366_2);
        const Space v366_10 = (has_head(v366_9) ? constant_4 : Space{});
        Space v366_12;
        if (!v366_10.empty()) {
          const Path v368_6 = concat_path(v365_6,v365_11_head);
          const Space v368_11 = routine_36(c, v368_6, p1, v365_11_tail);
          v366_12 = compose(v366_10,v368_11);
        }
        const Space v366_13 = unite(v366_8,v366_12);
        v365_11_result = unite(v365_11_result,v366_13);
      }
      const Space v365_11 = std::move(v365_11_result);
      v360_12 = compose(v360_10,v365_11);
    }
    const Space v360_13 = unite(v360_8,v360_12);
    v359_12_result = unite(v359_12_result,v360_13);
  }
  const Space v359_12 = std::move(v359_12_result);
  return v359_12;
}

static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v369_9_result;
  for (int v369_9_label = 1; v369_9_label <= 2; ++v369_9_label) {
    const Space v369_9_tail = child(s0,v369_9_label);
    if (v369_9_tail.empty()) continue;
    const Path v369_9_head{v369_9_label};
    const Space v370_2 = singleton(v369_9_head);
    const Space v370_3 = intersect(constant_3,v370_2);
    const Space v370_4 = (has_head(v370_3) ? constant_4 : Space{});
    const Space v370_5 = subtract(constant_2,v370_4);
    Space v370_8;
    if (!v370_5.empty()) {
      const Path v371_6 = concat_path(p0,v369_9_head);
      Space v371_7_result;
      for (int v371_7_label = 1; v371_7_label <= 2; ++v371_7_label) {
        const Space v371_7_tail = child(v369_9_tail,v371_7_label);
        if (v371_7_tail.empty()) continue;
        const Path v371_7_head{v371_7_label};
        const Space v372_2 = singleton(v371_7_head);
        const Space v372_3 = intersect(constant_3,v372_2);
        const Space v372_4 = (has_head(v372_3) ? constant_4 : Space{});
        const Space v372_5 = subtract(constant_2,v372_4);
        Space v372_8;
        if (!v372_5.empty()) {
          const Path v373_6 = concat_path(v371_6,v371_7_head);
          const Space v373_7 = routine_72(c, v373_6, p1, v371_7_tail);
          v372_8 = compose(v372_5,v373_7);
        }
        const Space v372_9 = intersect(constant_3,v372_2);
        const Space v372_10 = (has_head(v372_9) ? constant_4 : Space{});
        Space v372_12;
        if (!v372_10.empty()) {
          const Path v374_6 = concat_path(v371_6,v371_7_head);
          const Space v374_11 = routine_73(c, v374_6, p1, v371_7_tail);
          v372_12 = compose(v372_10,v374_11);
        }
        const Space v372_13 = unite(v372_8,v372_12);
        v371_7_result = unite(v371_7_result,v372_13);
      }
      const Space v371_7 = std::move(v371_7_result);
      v370_8 = compose(v370_5,v371_7);
    }
    const Space v370_9 = intersect(constant_3,v370_2);
    const Space v370_10 = (has_head(v370_9) ? constant_4 : Space{});
    const Space v370_11 = compose(v370_10,v369_9_tail);
    const Path v375_6 = concat_path(p0,v369_9_head);
    const Space v370_12 = wrap(v370_11,v375_6);
    const Space v370_13 = wrap(v370_12,p1);
    const Space v370_14 = unite(v370_8,v370_13);
    v369_9_result = unite(v369_9_result,v370_14);
  }
  const Space v369_9 = std::move(v369_9_result);
  return v369_9;
}

static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v376_3 = wrap(s0,p0);
  const Space v376_4 = wrap(v376_3,p1);
  return v376_4;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v377_12_result;
  for (int v377_12_label = 1; v377_12_label <= 2; ++v377_12_label) {
    const Space v377_12_tail = child(s0,v377_12_label);
    if (v377_12_tail.empty()) continue;
    const Path v377_12_head{v377_12_label};
    const Space v378_2 = singleton(v377_12_head);
    const Space v378_3 = intersect(constant_3,v378_2);
    const Space v378_4 = (has_head(v378_3) ? constant_4 : Space{});
    const Space v378_5 = subtract(constant_2,v378_4);
    Space v378_8;
    if (!v378_5.empty()) {
      const Path v379_6 = concat_path(p0,v377_12_head);
      Space v379_7_result;
      for (int v379_7_label = 1; v379_7_label <= 2; ++v379_7_label) {
        const Space v379_7_tail = child(v377_12_tail,v379_7_label);
        if (v379_7_tail.empty()) continue;
        const Path v379_7_head{v379_7_label};
        const Space v380_2 = singleton(v379_7_head);
        const Space v380_3 = intersect(constant_3,v380_2);
        const Space v380_4 = (has_head(v380_3) ? constant_4 : Space{});
        const Space v380_5 = subtract(constant_2,v380_4);
        Space v380_8;
        if (!v380_5.empty()) {
          const Path v381_6 = concat_path(v379_6,v379_7_head);
          const Space v381_7 = routine_74(c, v381_6, v379_7_tail, s1);
          v380_8 = compose(v380_5,v381_7);
        }
        const Space v380_9 = intersect(constant_3,v380_2);
        const Space v380_10 = (has_head(v380_9) ? constant_4 : Space{});
        Space v380_12;
        if (!v380_10.empty()) {
          const Path v382_6 = concat_path(v379_6,v379_7_head);
          const Space v382_11 = routine_75(c, v382_6, v379_7_tail, s1);
          v380_12 = compose(v380_10,v382_11);
        }
        const Space v380_13 = unite(v380_8,v380_12);
        v379_7_result = unite(v379_7_result,v380_13);
      }
      const Space v379_7 = std::move(v379_7_result);
      v378_8 = compose(v378_5,v379_7);
    }
    const Space v378_9 = intersect(constant_3,v378_2);
    const Space v378_10 = (has_head(v378_9) ? constant_4 : Space{});
    Space v378_12;
    if (!v378_10.empty()) {
      const Path v383_6 = concat_path(p0,v377_12_head);
      Space v383_11_result;
      for (int v383_11_label = 1; v383_11_label <= 2; ++v383_11_label) {
        const Space v383_11_tail = child(v377_12_tail,v383_11_label);
        if (v383_11_tail.empty()) continue;
        const Path v383_11_head{v383_11_label};
        const Space v384_2 = singleton(v383_11_head);
        const Space v384_3 = intersect(constant_3,v384_2);
        const Space v384_4 = (has_head(v384_3) ? constant_4 : Space{});
        const Space v384_5 = subtract(constant_2,v384_4);
        Space v384_8;
        if (!v384_5.empty()) {
          const Path v385_6 = concat_path(v383_6,v383_11_head);
          const Space v385_7 = routine_74(c, v385_6, v383_11_tail, s1);
          v384_8 = compose(v384_5,v385_7);
        }
        const Space v384_9 = intersect(constant_3,v384_2);
        const Space v384_10 = (has_head(v384_9) ? constant_4 : Space{});
        Space v384_12;
        if (!v384_10.empty()) {
          const Path v386_6 = concat_path(v383_6,v383_11_head);
          const Space v386_11 = routine_12(c, v386_6, v383_11_tail, s1);
          v384_12 = compose(v384_10,v386_11);
        }
        const Space v384_13 = unite(v384_8,v384_12);
        v383_11_result = unite(v383_11_result,v384_13);
      }
      const Space v383_11 = std::move(v383_11_result);
      v378_12 = compose(v378_10,v383_11);
    }
    const Space v378_13 = unite(v378_8,v378_12);
    v377_12_result = unite(v377_12_result,v378_13);
  }
  const Space v377_12 = std::move(v377_12_result);
  return v377_12;
}

static Space routine_38(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v387_12_result;
  for (int v387_12_label = 1; v387_12_label <= 2; ++v387_12_label) {
    const Space v387_12_tail = child(s0,v387_12_label);
    if (v387_12_tail.empty()) continue;
    const Path v387_12_head{v387_12_label};
    const Space v388_2 = singleton(v387_12_head);
    const Space v388_3 = intersect(constant_3,v388_2);
    const Space v388_4 = (has_head(v388_3) ? constant_4 : Space{});
    const Space v388_5 = subtract(constant_2,v388_4);
    Space v388_8;
    if (!v388_5.empty()) {
      const Path v389_6 = concat_path(p0,v387_12_head);
      Space v389_7_result;
      for (int v389_7_label = 1; v389_7_label <= 2; ++v389_7_label) {
        const Space v389_7_tail = child(v387_12_tail,v389_7_label);
        if (v389_7_tail.empty()) continue;
        const Path v389_7_head{v389_7_label};
        const Space v390_2 = singleton(v389_7_head);
        const Space v390_3 = intersect(constant_3,v390_2);
        const Space v390_4 = (has_head(v390_3) ? constant_4 : Space{});
        const Space v390_5 = subtract(constant_2,v390_4);
        Space v390_8;
        if (!v390_5.empty()) {
          const Path v391_6 = concat_path(v389_6,v389_7_head);
          const Space v391_7 = routine_74(c, v391_6, v389_7_tail, s1);
          v390_8 = compose(v390_5,v391_7);
        }
        const Space v390_9 = intersect(constant_3,v390_2);
        const Space v390_10 = (has_head(v390_9) ? constant_4 : Space{});
        Space v390_12;
        if (!v390_10.empty()) {
          const Path v392_6 = concat_path(v389_6,v389_7_head);
          const Space v392_11 = routine_75(c, v392_6, v389_7_tail, s1);
          v390_12 = compose(v390_10,v392_11);
        }
        const Space v390_13 = unite(v390_8,v390_12);
        v389_7_result = unite(v389_7_result,v390_13);
      }
      const Space v389_7 = std::move(v389_7_result);
      v388_8 = compose(v388_5,v389_7);
    }
    const Space v388_9 = intersect(constant_3,v388_2);
    const Space v388_10 = (has_head(v388_9) ? constant_4 : Space{});
    Space v388_12;
    if (!v388_10.empty()) {
      const Path v393_6 = concat_path(p0,v387_12_head);
      Space v393_11_result;
      for (int v393_11_label = 1; v393_11_label <= 2; ++v393_11_label) {
        const Space v393_11_tail = child(v387_12_tail,v393_11_label);
        if (v393_11_tail.empty()) continue;
        const Path v393_11_head{v393_11_label};
        const Space v394_2 = singleton(v393_11_head);
        const Space v394_3 = intersect(constant_3,v394_2);
        const Space v394_4 = (has_head(v394_3) ? constant_4 : Space{});
        const Space v394_5 = subtract(constant_2,v394_4);
        Space v394_7;
        if (!v394_5.empty()) {
          const Space v395_6 = routine_39(c, v393_11_head, v393_6, v393_11_tail, s1);
          v394_7 = compose(v394_5,v395_6);
        }
        const Space v394_8 = intersect(constant_3,v394_2);
        const Space v394_9 = (has_head(v394_8) ? constant_4 : Space{});
        Space v394_11;
        if (!v394_9.empty()) {
          const Space v396_10 = routine_40(c, v393_11_head, v393_6, v393_11_tail, s1);
          v394_11 = compose(v394_9,v396_10);
        }
        const Space v394_12 = unite(v394_7,v394_11);
        v393_11_result = unite(v393_11_result,v394_12);
      }
      const Space v393_11 = std::move(v393_11_result);
      v388_12 = compose(v388_10,v393_11);
    }
    const Space v388_13 = unite(v388_8,v388_12);
    v387_12_result = unite(v387_12_result,v388_13);
  }
  const Space v387_12 = std::move(v387_12_result);
  return v387_12;
}

static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v397_13_result;
  for (int v397_13_label = 1; v397_13_label <= 2; ++v397_13_label) {
    const Space v397_13_tail = child(s0,v397_13_label);
    if (v397_13_tail.empty()) continue;
    const Path v397_13_head{v397_13_label};
    const Space v398_2 = singleton(v397_13_head);
    const Space v398_3 = intersect(constant_3,v398_2);
    const Space v398_4 = (has_head(v398_3) ? constant_4 : Space{});
    const Space v398_5 = subtract(constant_2,v398_4);
    Space v398_8;
    if (!v398_5.empty()) {
      const Path v399_6 = concat_path(p0,v397_13_head);
      Space v399_7_result;
      for (int v399_7_label = 1; v399_7_label <= 2; ++v399_7_label) {
        const Space v399_7_tail = child(v397_13_tail,v399_7_label);
        if (v399_7_tail.empty()) continue;
        const Path v399_7_head{v399_7_label};
        const Space v400_2 = singleton(v399_7_head);
        const Space v400_3 = intersect(constant_3,v400_2);
        const Space v400_4 = (has_head(v400_3) ? constant_4 : Space{});
        const Space v400_5 = subtract(constant_2,v400_4);
        Space v400_8;
        if (!v400_5.empty()) {
          const Path v401_6 = concat_path(v399_6,v399_7_head);
          const Space v401_7 = routine_76(c, v401_6, p1, v399_7_tail, s1);
          v400_8 = compose(v400_5,v401_7);
        }
        const Space v400_9 = intersect(constant_3,v400_2);
        const Space v400_10 = (has_head(v400_9) ? constant_4 : Space{});
        Space v400_12;
        if (!v400_10.empty()) {
          const Path v402_6 = concat_path(v399_6,v399_7_head);
          const Space v402_11 = routine_77(c, v402_6, p1, v399_7_tail, s1);
          v400_12 = compose(v400_10,v402_11);
        }
        const Space v400_13 = unite(v400_8,v400_12);
        v399_7_result = unite(v399_7_result,v400_13);
      }
      const Space v399_7 = std::move(v399_7_result);
      v398_8 = compose(v398_5,v399_7);
    }
    const Space v398_9 = intersect(constant_3,v398_2);
    const Space v398_10 = (has_head(v398_9) ? constant_4 : Space{});
    Space v398_12;
    if (!v398_10.empty()) {
      const Path v403_6 = concat_path(p0,v397_13_head);
      Space v403_11_result;
      for (int v403_11_label = 1; v403_11_label <= 2; ++v403_11_label) {
        const Space v403_11_tail = child(v397_13_tail,v403_11_label);
        if (v403_11_tail.empty()) continue;
        const Path v403_11_head{v403_11_label};
        const Space v404_2 = singleton(v403_11_head);
        const Space v404_3 = intersect(constant_3,v404_2);
        const Space v404_4 = (has_head(v404_3) ? constant_4 : Space{});
        const Space v404_5 = subtract(constant_2,v404_4);
        Space v404_8;
        if (!v404_5.empty()) {
          const Path v405_6 = concat_path(v403_6,v403_11_head);
          const Space v405_7 = routine_76(c, v405_6, p1, v403_11_tail, s1);
          v404_8 = compose(v404_5,v405_7);
        }
        const Space v404_9 = intersect(constant_3,v404_2);
        const Space v404_10 = (has_head(v404_9) ? constant_4 : Space{});
        Space v404_12;
        if (!v404_10.empty()) {
          const Path v406_6 = concat_path(v403_6,v403_11_head);
          const Space v406_11 = routine_43(c, v406_6, p1, v403_11_tail, s1);
          v404_12 = compose(v404_10,v406_11);
        }
        const Space v404_13 = unite(v404_8,v404_12);
        v403_11_result = unite(v403_11_result,v404_13);
      }
      const Space v403_11 = std::move(v403_11_result);
      v398_12 = compose(v398_10,v403_11);
    }
    const Space v398_13 = unite(v398_8,v398_12);
    v397_13_result = unite(v397_13_result,v398_13);
  }
  const Space v397_13 = std::move(v397_13_result);
  return v397_13;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v407_8 = unwrap(s1,constant_0);
  const Space v407_10 = unwrap(v407_8,constant_6);
  const Space v407_11 = unwrap(v407_10,p0);
  Space v407_18_result;
  for (int v407_18_label = 1; v407_18_label <= 2; ++v407_18_label) {
    const Space v407_18_tail = child(s0,v407_18_label);
    if (v407_18_tail.empty()) continue;
    const Path v407_18_head{v407_18_label};
    const Space v408_2 = singleton(v407_18_head);
    const Space v408_3 = intersect(constant_3,v408_2);
    const Space v408_4 = (has_head(v408_3) ? constant_4 : Space{});
    const Space v408_5 = subtract(constant_2,v408_4);
    Space v408_8;
    if (!v408_5.empty()) {
      const Path v409_6 = concat_path(p0,v407_18_head);
      Space v409_7_result;
      for (int v409_7_label = 1; v409_7_label <= 2; ++v409_7_label) {
        const Space v409_7_tail = child(v407_18_tail,v409_7_label);
        if (v409_7_tail.empty()) continue;
        const Path v409_7_head{v409_7_label};
        const Space v410_2 = singleton(v409_7_head);
        const Space v410_3 = intersect(constant_3,v410_2);
        const Space v410_4 = (has_head(v410_3) ? constant_4 : Space{});
        const Space v410_5 = subtract(constant_2,v410_4);
        Space v410_8;
        if (!v410_5.empty()) {
          const Path v411_6 = concat_path(v409_6,v409_7_head);
          const Space v411_7 = routine_76(c, v411_6, p1, v409_7_tail, s1);
          v410_8 = compose(v410_5,v411_7);
        }
        const Space v410_9 = intersect(constant_3,v410_2);
        const Space v410_10 = (has_head(v410_9) ? constant_4 : Space{});
        Space v410_12;
        if (!v410_10.empty()) {
          const Path v412_6 = concat_path(v409_6,v409_7_head);
          const Space v412_11 = routine_77(c, v412_6, p1, v409_7_tail, s1);
          v410_12 = compose(v410_10,v412_11);
        }
        const Space v410_13 = unite(v410_8,v410_12);
        v409_7_result = unite(v409_7_result,v410_13);
      }
      const Space v409_7 = std::move(v409_7_result);
      v408_8 = compose(v408_5,v409_7);
    }
    const Space v408_9 = intersect(constant_3,v408_2);
    const Space v408_10 = (has_head(v408_9) ? constant_4 : Space{});
    Space v408_13;
    if (!v408_10.empty()) {
      const Space v413_11 = unwrap(v407_11,v407_18_head);
      Space v413_12_result;
      for (int v413_12_label = 1; v413_12_label <= 2; ++v413_12_label) {
        const Space v413_12_tail = child(v413_11,v413_12_label);
        if (v413_12_tail.empty()) continue;
        const Path v413_12_head{v413_12_label};
        const Space v414_2 = singleton(v413_12_head);
        const Space v414_3 = intersect(constant_3,v414_2);
        const Space v414_4 = (has_head(v414_3) ? constant_4 : Space{});
        const Space v414_5 = subtract(constant_2,v414_4);
        Space v414_7;
        if (!v414_5.empty()) {
          const Space v415_6 = routine_78(c, v413_12_head, p1, v413_12_tail);
          v414_7 = compose(v414_5,v415_6);
        }
        const Space v414_8 = intersect(constant_3,v414_2);
        const Space v414_9 = (has_head(v414_8) ? constant_4 : Space{});
        Space v414_11;
        if (!v414_9.empty()) {
          const Space v416_10 = routine_79(c, v413_12_head, p1, v413_12_tail);
          v414_11 = compose(v414_9,v416_10);
        }
        const Space v414_12 = unite(v414_7,v414_11);
        v413_12_result = unite(v413_12_result,v414_12);
      }
      const Space v413_12 = std::move(v413_12_result);
      v408_13 = compose(v408_10,v413_12);
    }
    const Space v408_14 = unite(v408_8,v408_13);
    v407_18_result = unite(v407_18_result,v408_14);
  }
  const Space v407_18 = std::move(v407_18_result);
  return v407_18;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v417_13_result;
  for (int v417_13_label = 1; v417_13_label <= 2; ++v417_13_label) {
    const Space v417_13_tail = child(s0,v417_13_label);
    if (v417_13_tail.empty()) continue;
    const Path v417_13_head{v417_13_label};
    const Space v418_2 = singleton(v417_13_head);
    const Space v418_3 = intersect(constant_3,v418_2);
    const Space v418_4 = (has_head(v418_3) ? constant_4 : Space{});
    const Space v418_5 = subtract(constant_2,v418_4);
    Space v418_8;
    if (!v418_5.empty()) {
      const Path v419_6 = concat_path(p0,v417_13_head);
      Space v419_7_result;
      for (int v419_7_label = 1; v419_7_label <= 2; ++v419_7_label) {
        const Space v419_7_tail = child(v417_13_tail,v419_7_label);
        if (v419_7_tail.empty()) continue;
        const Path v419_7_head{v419_7_label};
        const Space v420_2 = singleton(v419_7_head);
        const Space v420_3 = intersect(constant_3,v420_2);
        const Space v420_4 = (has_head(v420_3) ? constant_4 : Space{});
        const Space v420_5 = subtract(constant_2,v420_4);
        Space v420_8;
        if (!v420_5.empty()) {
          const Path v421_6 = concat_path(v419_6,v419_7_head);
          const Space v421_7 = routine_80(c, v421_6, p1, v419_7_tail, s1);
          v420_8 = compose(v420_5,v421_7);
        }
        const Space v420_9 = intersect(constant_3,v420_2);
        const Space v420_10 = (has_head(v420_9) ? constant_4 : Space{});
        Space v420_12;
        if (!v420_10.empty()) {
          const Path v422_6 = concat_path(v419_6,v419_7_head);
          const Space v422_11 = routine_81(c, v422_6, p1, v419_7_tail, s1);
          v420_12 = compose(v420_10,v422_11);
        }
        const Space v420_13 = unite(v420_8,v420_12);
        v419_7_result = unite(v419_7_result,v420_13);
      }
      const Space v419_7 = std::move(v419_7_result);
      v418_8 = compose(v418_5,v419_7);
    }
    const Space v418_9 = intersect(constant_3,v418_2);
    const Space v418_10 = (has_head(v418_9) ? constant_4 : Space{});
    Space v418_12;
    if (!v418_10.empty()) {
      const Path v423_6 = concat_path(p0,v417_13_head);
      Space v423_11_result;
      for (int v423_11_label = 1; v423_11_label <= 2; ++v423_11_label) {
        const Space v423_11_tail = child(v417_13_tail,v423_11_label);
        if (v423_11_tail.empty()) continue;
        const Path v423_11_head{v423_11_label};
        const Space v424_2 = singleton(v423_11_head);
        const Space v424_3 = intersect(constant_3,v424_2);
        const Space v424_4 = (has_head(v424_3) ? constant_4 : Space{});
        const Space v424_5 = subtract(constant_2,v424_4);
        Space v424_8;
        if (!v424_5.empty()) {
          const Path v425_6 = concat_path(v423_6,v423_11_head);
          const Space v425_7 = routine_80(c, v425_6, p1, v423_11_tail, s1);
          v424_8 = compose(v424_5,v425_7);
        }
        const Space v424_9 = intersect(constant_3,v424_2);
        const Space v424_10 = (has_head(v424_9) ? constant_4 : Space{});
        Space v424_12;
        if (!v424_10.empty()) {
          const Path v426_6 = concat_path(v423_6,v423_11_head);
          const Space v426_11 = routine_43(c, v426_6, p1, v423_11_tail, s1);
          v424_12 = compose(v424_10,v426_11);
        }
        const Space v424_13 = unite(v424_8,v424_12);
        v423_11_result = unite(v423_11_result,v424_13);
      }
      const Space v423_11 = std::move(v423_11_result);
      v418_12 = compose(v418_10,v423_11);
    }
    const Space v418_13 = unite(v418_8,v418_12);
    v417_13_result = unite(v417_13_result,v418_13);
  }
  const Space v417_13 = std::move(v417_13_result);
  return v417_13;
}

static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v427_8 = unwrap(s1,constant_0);
  const Space v427_10 = unwrap(v427_8,constant_6);
  const Space v427_11 = unwrap(v427_10,p0);
  Space v427_18_result;
  for (int v427_18_label = 1; v427_18_label <= 2; ++v427_18_label) {
    const Space v427_18_tail = child(s0,v427_18_label);
    if (v427_18_tail.empty()) continue;
    const Path v427_18_head{v427_18_label};
    const Space v428_2 = singleton(v427_18_head);
    const Space v428_3 = intersect(constant_3,v428_2);
    const Space v428_4 = (has_head(v428_3) ? constant_4 : Space{});
    const Space v428_5 = subtract(constant_2,v428_4);
    Space v428_8;
    if (!v428_5.empty()) {
      const Path v429_6 = concat_path(p0,v427_18_head);
      Space v429_7_result;
      for (int v429_7_label = 1; v429_7_label <= 2; ++v429_7_label) {
        const Space v429_7_tail = child(v427_18_tail,v429_7_label);
        if (v429_7_tail.empty()) continue;
        const Path v429_7_head{v429_7_label};
        const Space v430_2 = singleton(v429_7_head);
        const Space v430_3 = intersect(constant_3,v430_2);
        const Space v430_4 = (has_head(v430_3) ? constant_4 : Space{});
        const Space v430_5 = subtract(constant_2,v430_4);
        Space v430_8;
        if (!v430_5.empty()) {
          const Path v431_6 = concat_path(v429_6,v429_7_head);
          const Space v431_7 = routine_80(c, v431_6, p1, v429_7_tail, s1);
          v430_8 = compose(v430_5,v431_7);
        }
        const Space v430_9 = intersect(constant_3,v430_2);
        const Space v430_10 = (has_head(v430_9) ? constant_4 : Space{});
        Space v430_12;
        if (!v430_10.empty()) {
          const Path v432_6 = concat_path(v429_6,v429_7_head);
          const Space v432_11 = routine_81(c, v432_6, p1, v429_7_tail, s1);
          v430_12 = compose(v430_10,v432_11);
        }
        const Space v430_13 = unite(v430_8,v430_12);
        v429_7_result = unite(v429_7_result,v430_13);
      }
      const Space v429_7 = std::move(v429_7_result);
      v428_8 = compose(v428_5,v429_7);
    }
    const Space v428_9 = intersect(constant_3,v428_2);
    const Space v428_10 = (has_head(v428_9) ? constant_4 : Space{});
    Space v428_13;
    if (!v428_10.empty()) {
      const Space v433_11 = unwrap(v427_11,v427_18_head);
      Space v433_12_result;
      for (int v433_12_label = 1; v433_12_label <= 2; ++v433_12_label) {
        const Space v433_12_tail = child(v433_11,v433_12_label);
        if (v433_12_tail.empty()) continue;
        const Path v433_12_head{v433_12_label};
        const Space v434_2 = singleton(v433_12_head);
        const Space v434_3 = intersect(constant_3,v434_2);
        const Space v434_4 = (has_head(v434_3) ? constant_4 : Space{});
        const Space v434_5 = subtract(constant_2,v434_4);
        Space v434_7;
        if (!v434_5.empty()) {
          const Space v435_6 = routine_78(c, v433_12_head, p1, v433_12_tail);
          v434_7 = compose(v434_5,v435_6);
        }
        const Space v434_8 = intersect(constant_3,v434_2);
        const Space v434_9 = (has_head(v434_8) ? constant_4 : Space{});
        Space v434_11;
        if (!v434_9.empty()) {
          const Space v436_10 = routine_79(c, v433_12_head, p1, v433_12_tail);
          v434_11 = compose(v434_9,v436_10);
        }
        const Space v434_12 = unite(v434_7,v434_11);
        v433_12_result = unite(v433_12_result,v434_12);
      }
      const Space v433_12 = std::move(v433_12_result);
      v428_13 = compose(v428_10,v433_12);
    }
    const Space v428_14 = unite(v428_8,v428_13);
    v427_18_result = unite(v427_18_result,v428_14);
  }
  const Space v427_18 = std::move(v427_18_result);
  return v427_18;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v437_5 = unwrap(s1,constant_0);
  const Space v437_7 = unwrap(v437_5,constant_6);
  const Space v437_8 = unwrap(v437_7,p0);
  Space v437_18_result;
  for (int v437_18_label = 1; v437_18_label <= 2; ++v437_18_label) {
    const Space v437_18_tail = child(v437_8,v437_18_label);
    if (v437_18_tail.empty()) continue;
    const Path v437_18_head{v437_18_label};
    const Space v438_2 = singleton(v437_18_head);
    const Space v438_3 = intersect(constant_3,v438_2);
    const Space v438_4 = (has_head(v438_3) ? constant_4 : Space{});
    const Space v438_5 = subtract(constant_2,v438_4);
    Space v438_7;
    if (!v438_5.empty()) {
      Space v439_6_result;
      for (int v439_6_label = 1; v439_6_label <= 2; ++v439_6_label) {
        const Space v439_6_tail = child(v437_18_tail,v439_6_label);
        if (v439_6_tail.empty()) continue;
        const Path v439_6_head{v439_6_label};
        const Space v440_2 = singleton(v439_6_head);
        const Space v440_3 = intersect(constant_3,v440_2);
        const Space v440_4 = (has_head(v440_3) ? constant_4 : Space{});
        const Space v440_5 = subtract(constant_2,v440_4);
        Space v440_8;
        if (!v440_5.empty()) {
          const Path v441_6 = concat_path(v437_18_head,v439_6_head);
          const Space v441_7 = routine_82(c, v441_6, p1, v439_6_tail);
          v440_8 = compose(v440_5,v441_7);
        }
        const Space v440_9 = intersect(constant_3,v440_2);
        const Space v440_10 = (has_head(v440_9) ? constant_4 : Space{});
        Space v440_12;
        if (!v440_10.empty()) {
          const Path v442_6 = concat_path(v437_18_head,v439_6_head);
          const Space v442_11 = routine_83(c, v442_6, p1, v439_6_tail);
          v440_12 = compose(v440_10,v442_11);
        }
        const Space v440_13 = unite(v440_8,v440_12);
        v439_6_result = unite(v439_6_result,v440_13);
      }
      const Space v439_6 = std::move(v439_6_result);
      v438_7 = compose(v438_5,v439_6);
    }
    const Space v438_8 = intersect(constant_3,v438_2);
    const Space v438_9 = (has_head(v438_8) ? constant_4 : Space{});
    Space v438_11;
    if (!v438_9.empty()) {
      Space v443_10_result;
      for (int v443_10_label = 1; v443_10_label <= 2; ++v443_10_label) {
        const Space v443_10_tail = child(v437_18_tail,v443_10_label);
        if (v443_10_tail.empty()) continue;
        const Path v443_10_head{v443_10_label};
        const Space v444_2 = singleton(v443_10_head);
        const Space v444_3 = intersect(constant_3,v444_2);
        const Space v444_4 = (has_head(v444_3) ? constant_4 : Space{});
        const Space v444_5 = subtract(constant_2,v444_4);
        Space v444_8;
        if (!v444_5.empty()) {
          const Path v445_6 = concat_path(v437_18_head,v443_10_head);
          const Space v445_7 = routine_82(c, v445_6, p1, v443_10_tail);
          v444_8 = compose(v444_5,v445_7);
        }
        const Space v444_9 = intersect(constant_3,v444_2);
        const Space v444_10 = (has_head(v444_9) ? constant_4 : Space{});
        Space v444_12;
        if (!v444_10.empty()) {
          const Path v446_6 = concat_path(v437_18_head,v443_10_head);
          const Space v446_11 = routine_84(c, v446_6, p1, v443_10_tail);
          v444_12 = compose(v444_10,v446_11);
        }
        const Space v444_13 = unite(v444_8,v444_12);
        v443_10_result = unite(v443_10_result,v444_13);
      }
      const Space v443_10 = std::move(v443_10_result);
      v438_11 = compose(v438_9,v443_10);
    }
    const Space v438_12 = unite(v438_7,v438_11);
    v437_18_result = unite(v437_18_result,v438_12);
  }
  const Space v437_18 = std::move(v437_18_result);
  return v437_18;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v447_12_result;
  for (int v447_12_label = 1; v447_12_label <= 2; ++v447_12_label) {
    const Space v447_12_tail = child(s0,v447_12_label);
    if (v447_12_tail.empty()) continue;
    const Path v447_12_head{v447_12_label};
    const Space v448_2 = singleton(v447_12_head);
    const Space v448_3 = intersect(constant_3,v448_2);
    const Space v448_4 = (has_head(v448_3) ? constant_4 : Space{});
    const Space v448_5 = subtract(constant_2,v448_4);
    Space v448_8;
    if (!v448_5.empty()) {
      const Path v449_6 = concat_path(p0,v447_12_head);
      Space v449_7_result;
      for (int v449_7_label = 1; v449_7_label <= 2; ++v449_7_label) {
        const Space v449_7_tail = child(v447_12_tail,v449_7_label);
        if (v449_7_tail.empty()) continue;
        const Path v449_7_head{v449_7_label};
        const Space v450_2 = singleton(v449_7_head);
        const Space v450_3 = intersect(constant_3,v450_2);
        const Space v450_4 = (has_head(v450_3) ? constant_4 : Space{});
        const Space v450_5 = subtract(constant_2,v450_4);
        Space v450_8;
        if (!v450_5.empty()) {
          const Path v451_6 = concat_path(v449_6,v449_7_head);
          const Space v451_7 = routine_85(c, v451_6, v449_7_tail, s1);
          v450_8 = compose(v450_5,v451_7);
        }
        const Space v450_9 = intersect(constant_3,v450_2);
        const Space v450_10 = (has_head(v450_9) ? constant_4 : Space{});
        Space v450_12;
        if (!v450_10.empty()) {
          const Path v452_6 = concat_path(v449_6,v449_7_head);
          const Space v452_11 = routine_86(c, v452_6, v449_7_tail, s1);
          v450_12 = compose(v450_10,v452_11);
        }
        const Space v450_13 = unite(v450_8,v450_12);
        v449_7_result = unite(v449_7_result,v450_13);
      }
      const Space v449_7 = std::move(v449_7_result);
      v448_8 = compose(v448_5,v449_7);
    }
    const Space v448_9 = intersect(constant_3,v448_2);
    const Space v448_10 = (has_head(v448_9) ? constant_4 : Space{});
    Space v448_12;
    if (!v448_10.empty()) {
      const Path v453_6 = concat_path(p0,v447_12_head);
      Space v453_11_result;
      for (int v453_11_label = 1; v453_11_label <= 2; ++v453_11_label) {
        const Space v453_11_tail = child(v447_12_tail,v453_11_label);
        if (v453_11_tail.empty()) continue;
        const Path v453_11_head{v453_11_label};
        const Space v454_2 = singleton(v453_11_head);
        const Space v454_3 = intersect(constant_3,v454_2);
        const Space v454_4 = (has_head(v454_3) ? constant_4 : Space{});
        const Space v454_5 = subtract(constant_2,v454_4);
        Space v454_8;
        if (!v454_5.empty()) {
          const Path v455_6 = concat_path(v453_6,v453_11_head);
          const Space v455_7 = routine_85(c, v455_6, v453_11_tail, s1);
          v454_8 = compose(v454_5,v455_7);
        }
        const Space v454_9 = intersect(constant_3,v454_2);
        const Space v454_10 = (has_head(v454_9) ? constant_4 : Space{});
        Space v454_12;
        if (!v454_10.empty()) {
          const Path v456_6 = concat_path(v453_6,v453_11_head);
          const Space v456_11 = routine_15(c, v456_6, v453_11_tail, s1);
          v454_12 = compose(v454_10,v456_11);
        }
        const Space v454_13 = unite(v454_8,v454_12);
        v453_11_result = unite(v453_11_result,v454_13);
      }
      const Space v453_11 = std::move(v453_11_result);
      v448_12 = compose(v448_10,v453_11);
    }
    const Space v448_13 = unite(v448_8,v448_12);
    v447_12_result = unite(v447_12_result,v448_13);
  }
  const Space v447_12 = std::move(v447_12_result);
  return v447_12;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v457_12_result;
  for (int v457_12_label = 1; v457_12_label <= 2; ++v457_12_label) {
    const Space v457_12_tail = child(s0,v457_12_label);
    if (v457_12_tail.empty()) continue;
    const Path v457_12_head{v457_12_label};
    const Space v458_2 = singleton(v457_12_head);
    const Space v458_3 = intersect(constant_3,v458_2);
    const Space v458_4 = (has_head(v458_3) ? constant_4 : Space{});
    const Space v458_5 = subtract(constant_2,v458_4);
    Space v458_8;
    if (!v458_5.empty()) {
      const Path v459_6 = concat_path(p0,v457_12_head);
      Space v459_7_result;
      for (int v459_7_label = 1; v459_7_label <= 2; ++v459_7_label) {
        const Space v459_7_tail = child(v457_12_tail,v459_7_label);
        if (v459_7_tail.empty()) continue;
        const Path v459_7_head{v459_7_label};
        const Space v460_2 = singleton(v459_7_head);
        const Space v460_3 = intersect(constant_3,v460_2);
        const Space v460_4 = (has_head(v460_3) ? constant_4 : Space{});
        const Space v460_5 = subtract(constant_2,v460_4);
        Space v460_8;
        if (!v460_5.empty()) {
          const Path v461_6 = concat_path(v459_6,v459_7_head);
          const Space v461_7 = routine_85(c, v461_6, v459_7_tail, s1);
          v460_8 = compose(v460_5,v461_7);
        }
        const Space v460_9 = intersect(constant_3,v460_2);
        const Space v460_10 = (has_head(v460_9) ? constant_4 : Space{});
        Space v460_12;
        if (!v460_10.empty()) {
          const Path v462_6 = concat_path(v459_6,v459_7_head);
          const Space v462_11 = routine_86(c, v462_6, v459_7_tail, s1);
          v460_12 = compose(v460_10,v462_11);
        }
        const Space v460_13 = unite(v460_8,v460_12);
        v459_7_result = unite(v459_7_result,v460_13);
      }
      const Space v459_7 = std::move(v459_7_result);
      v458_8 = compose(v458_5,v459_7);
    }
    const Space v458_9 = intersect(constant_3,v458_2);
    const Space v458_10 = (has_head(v458_9) ? constant_4 : Space{});
    Space v458_12;
    if (!v458_10.empty()) {
      const Path v463_6 = concat_path(p0,v457_12_head);
      Space v463_11_result;
      for (int v463_11_label = 1; v463_11_label <= 2; ++v463_11_label) {
        const Space v463_11_tail = child(v457_12_tail,v463_11_label);
        if (v463_11_tail.empty()) continue;
        const Path v463_11_head{v463_11_label};
        const Space v464_2 = singleton(v463_11_head);
        const Space v464_3 = intersect(constant_3,v464_2);
        const Space v464_4 = (has_head(v464_3) ? constant_4 : Space{});
        const Space v464_5 = subtract(constant_2,v464_4);
        Space v464_7;
        if (!v464_5.empty()) {
          const Space v465_6 = routine_46(c, v463_11_head, v463_6, v463_11_tail, s1);
          v464_7 = compose(v464_5,v465_6);
        }
        const Space v464_8 = intersect(constant_3,v464_2);
        const Space v464_9 = (has_head(v464_8) ? constant_4 : Space{});
        Space v464_11;
        if (!v464_9.empty()) {
          const Space v466_10 = routine_47(c, v463_11_head, v463_6, v463_11_tail, s1);
          v464_11 = compose(v464_9,v466_10);
        }
        const Space v464_12 = unite(v464_7,v464_11);
        v463_11_result = unite(v463_11_result,v464_12);
      }
      const Space v463_11 = std::move(v463_11_result);
      v458_12 = compose(v458_10,v463_11);
    }
    const Space v458_13 = unite(v458_8,v458_12);
    v457_12_result = unite(v457_12_result,v458_13);
  }
  const Space v457_12 = std::move(v457_12_result);
  return v457_12;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v467_13_result;
  for (int v467_13_label = 1; v467_13_label <= 2; ++v467_13_label) {
    const Space v467_13_tail = child(s0,v467_13_label);
    if (v467_13_tail.empty()) continue;
    const Path v467_13_head{v467_13_label};
    const Space v468_2 = singleton(v467_13_head);
    const Space v468_3 = intersect(constant_3,v468_2);
    const Space v468_4 = (has_head(v468_3) ? constant_4 : Space{});
    const Space v468_5 = subtract(constant_2,v468_4);
    Space v468_8;
    if (!v468_5.empty()) {
      const Path v469_6 = concat_path(p0,v467_13_head);
      Space v469_7_result;
      for (int v469_7_label = 1; v469_7_label <= 2; ++v469_7_label) {
        const Space v469_7_tail = child(v467_13_tail,v469_7_label);
        if (v469_7_tail.empty()) continue;
        const Path v469_7_head{v469_7_label};
        const Space v470_2 = singleton(v469_7_head);
        const Space v470_3 = intersect(constant_3,v470_2);
        const Space v470_4 = (has_head(v470_3) ? constant_4 : Space{});
        const Space v470_5 = subtract(constant_2,v470_4);
        Space v470_8;
        if (!v470_5.empty()) {
          const Path v471_6 = concat_path(v469_6,v469_7_head);
          const Space v471_7 = routine_87(c, v471_6, p1, v469_7_tail, s1);
          v470_8 = compose(v470_5,v471_7);
        }
        const Space v470_9 = intersect(constant_3,v470_2);
        const Space v470_10 = (has_head(v470_9) ? constant_4 : Space{});
        Space v470_12;
        if (!v470_10.empty()) {
          const Path v472_6 = concat_path(v469_6,v469_7_head);
          const Space v472_11 = routine_88(c, v472_6, p1, v469_7_tail, s1);
          v470_12 = compose(v470_10,v472_11);
        }
        const Space v470_13 = unite(v470_8,v470_12);
        v469_7_result = unite(v469_7_result,v470_13);
      }
      const Space v469_7 = std::move(v469_7_result);
      v468_8 = compose(v468_5,v469_7);
    }
    const Space v468_9 = intersect(constant_3,v468_2);
    const Space v468_10 = (has_head(v468_9) ? constant_4 : Space{});
    Space v468_12;
    if (!v468_10.empty()) {
      const Path v473_6 = concat_path(p0,v467_13_head);
      Space v473_11_result;
      for (int v473_11_label = 1; v473_11_label <= 2; ++v473_11_label) {
        const Space v473_11_tail = child(v467_13_tail,v473_11_label);
        if (v473_11_tail.empty()) continue;
        const Path v473_11_head{v473_11_label};
        const Space v474_2 = singleton(v473_11_head);
        const Space v474_3 = intersect(constant_3,v474_2);
        const Space v474_4 = (has_head(v474_3) ? constant_4 : Space{});
        const Space v474_5 = subtract(constant_2,v474_4);
        Space v474_8;
        if (!v474_5.empty()) {
          const Path v475_6 = concat_path(v473_6,v473_11_head);
          const Space v475_7 = routine_87(c, v475_6, p1, v473_11_tail, s1);
          v474_8 = compose(v474_5,v475_7);
        }
        const Space v474_9 = intersect(constant_3,v474_2);
        const Space v474_10 = (has_head(v474_9) ? constant_4 : Space{});
        Space v474_12;
        if (!v474_10.empty()) {
          const Path v476_6 = concat_path(v473_6,v473_11_head);
          const Space v476_11 = routine_50(c, v476_6, p1, v473_11_tail, s1);
          v474_12 = compose(v474_10,v476_11);
        }
        const Space v474_13 = unite(v474_8,v474_12);
        v473_11_result = unite(v473_11_result,v474_13);
      }
      const Space v473_11 = std::move(v473_11_result);
      v468_12 = compose(v468_10,v473_11);
    }
    const Space v468_13 = unite(v468_8,v468_12);
    v467_13_result = unite(v467_13_result,v468_13);
  }
  const Space v467_13 = std::move(v467_13_result);
  return v467_13;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v477_8 = unwrap(s1,constant_5);
  const Space v477_10 = unwrap(v477_8,constant_6);
  const Space v477_11 = unwrap(v477_10,p0);
  Space v477_18_result;
  for (int v477_18_label = 1; v477_18_label <= 2; ++v477_18_label) {
    const Space v477_18_tail = child(s0,v477_18_label);
    if (v477_18_tail.empty()) continue;
    const Path v477_18_head{v477_18_label};
    const Space v478_2 = singleton(v477_18_head);
    const Space v478_3 = intersect(constant_3,v478_2);
    const Space v478_4 = (has_head(v478_3) ? constant_4 : Space{});
    const Space v478_5 = subtract(constant_2,v478_4);
    Space v478_8;
    if (!v478_5.empty()) {
      const Path v479_6 = concat_path(p0,v477_18_head);
      Space v479_7_result;
      for (int v479_7_label = 1; v479_7_label <= 2; ++v479_7_label) {
        const Space v479_7_tail = child(v477_18_tail,v479_7_label);
        if (v479_7_tail.empty()) continue;
        const Path v479_7_head{v479_7_label};
        const Space v480_2 = singleton(v479_7_head);
        const Space v480_3 = intersect(constant_3,v480_2);
        const Space v480_4 = (has_head(v480_3) ? constant_4 : Space{});
        const Space v480_5 = subtract(constant_2,v480_4);
        Space v480_8;
        if (!v480_5.empty()) {
          const Path v481_6 = concat_path(v479_6,v479_7_head);
          const Space v481_7 = routine_87(c, v481_6, p1, v479_7_tail, s1);
          v480_8 = compose(v480_5,v481_7);
        }
        const Space v480_9 = intersect(constant_3,v480_2);
        const Space v480_10 = (has_head(v480_9) ? constant_4 : Space{});
        Space v480_12;
        if (!v480_10.empty()) {
          const Path v482_6 = concat_path(v479_6,v479_7_head);
          const Space v482_11 = routine_88(c, v482_6, p1, v479_7_tail, s1);
          v480_12 = compose(v480_10,v482_11);
        }
        const Space v480_13 = unite(v480_8,v480_12);
        v479_7_result = unite(v479_7_result,v480_13);
      }
      const Space v479_7 = std::move(v479_7_result);
      v478_8 = compose(v478_5,v479_7);
    }
    const Space v478_9 = intersect(constant_3,v478_2);
    const Space v478_10 = (has_head(v478_9) ? constant_4 : Space{});
    Space v478_13;
    if (!v478_10.empty()) {
      const Space v483_11 = unwrap(v477_11,v477_18_head);
      Space v483_12_result;
      for (int v483_12_label = 1; v483_12_label <= 2; ++v483_12_label) {
        const Space v483_12_tail = child(v483_11,v483_12_label);
        if (v483_12_tail.empty()) continue;
        const Path v483_12_head{v483_12_label};
        const Space v484_2 = singleton(v483_12_head);
        const Space v484_3 = intersect(constant_3,v484_2);
        const Space v484_4 = (has_head(v484_3) ? constant_4 : Space{});
        const Space v484_5 = subtract(constant_2,v484_4);
        Space v484_7;
        if (!v484_5.empty()) {
          const Space v485_6 = routine_89(c, v483_12_head, p1, v483_12_tail);
          v484_7 = compose(v484_5,v485_6);
        }
        const Space v484_8 = intersect(constant_3,v484_2);
        const Space v484_9 = (has_head(v484_8) ? constant_4 : Space{});
        Space v484_11;
        if (!v484_9.empty()) {
          const Space v486_10 = routine_90(c, v483_12_head, p1, v483_12_tail);
          v484_11 = compose(v484_9,v486_10);
        }
        const Space v484_12 = unite(v484_7,v484_11);
        v483_12_result = unite(v483_12_result,v484_12);
      }
      const Space v483_12 = std::move(v483_12_result);
      v478_13 = compose(v478_10,v483_12);
    }
    const Space v478_14 = unite(v478_8,v478_13);
    v477_18_result = unite(v477_18_result,v478_14);
  }
  const Space v477_18 = std::move(v477_18_result);
  return v477_18;
}

static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v487_13_result;
  for (int v487_13_label = 1; v487_13_label <= 2; ++v487_13_label) {
    const Space v487_13_tail = child(s0,v487_13_label);
    if (v487_13_tail.empty()) continue;
    const Path v487_13_head{v487_13_label};
    const Space v488_2 = singleton(v487_13_head);
    const Space v488_3 = intersect(constant_3,v488_2);
    const Space v488_4 = (has_head(v488_3) ? constant_4 : Space{});
    const Space v488_5 = subtract(constant_2,v488_4);
    Space v488_8;
    if (!v488_5.empty()) {
      const Path v489_6 = concat_path(p0,v487_13_head);
      Space v489_7_result;
      for (int v489_7_label = 1; v489_7_label <= 2; ++v489_7_label) {
        const Space v489_7_tail = child(v487_13_tail,v489_7_label);
        if (v489_7_tail.empty()) continue;
        const Path v489_7_head{v489_7_label};
        const Space v490_2 = singleton(v489_7_head);
        const Space v490_3 = intersect(constant_3,v490_2);
        const Space v490_4 = (has_head(v490_3) ? constant_4 : Space{});
        const Space v490_5 = subtract(constant_2,v490_4);
        Space v490_8;
        if (!v490_5.empty()) {
          const Path v491_6 = concat_path(v489_6,v489_7_head);
          const Space v491_7 = routine_91(c, v491_6, p1, v489_7_tail, s1);
          v490_8 = compose(v490_5,v491_7);
        }
        const Space v490_9 = intersect(constant_3,v490_2);
        const Space v490_10 = (has_head(v490_9) ? constant_4 : Space{});
        Space v490_12;
        if (!v490_10.empty()) {
          const Path v492_6 = concat_path(v489_6,v489_7_head);
          const Space v492_11 = routine_92(c, v492_6, p1, v489_7_tail, s1);
          v490_12 = compose(v490_10,v492_11);
        }
        const Space v490_13 = unite(v490_8,v490_12);
        v489_7_result = unite(v489_7_result,v490_13);
      }
      const Space v489_7 = std::move(v489_7_result);
      v488_8 = compose(v488_5,v489_7);
    }
    const Space v488_9 = intersect(constant_3,v488_2);
    const Space v488_10 = (has_head(v488_9) ? constant_4 : Space{});
    Space v488_12;
    if (!v488_10.empty()) {
      const Path v493_6 = concat_path(p0,v487_13_head);
      Space v493_11_result;
      for (int v493_11_label = 1; v493_11_label <= 2; ++v493_11_label) {
        const Space v493_11_tail = child(v487_13_tail,v493_11_label);
        if (v493_11_tail.empty()) continue;
        const Path v493_11_head{v493_11_label};
        const Space v494_2 = singleton(v493_11_head);
        const Space v494_3 = intersect(constant_3,v494_2);
        const Space v494_4 = (has_head(v494_3) ? constant_4 : Space{});
        const Space v494_5 = subtract(constant_2,v494_4);
        Space v494_8;
        if (!v494_5.empty()) {
          const Path v495_6 = concat_path(v493_6,v493_11_head);
          const Space v495_7 = routine_91(c, v495_6, p1, v493_11_tail, s1);
          v494_8 = compose(v494_5,v495_7);
        }
        const Space v494_9 = intersect(constant_3,v494_2);
        const Space v494_10 = (has_head(v494_9) ? constant_4 : Space{});
        Space v494_12;
        if (!v494_10.empty()) {
          const Path v496_6 = concat_path(v493_6,v493_11_head);
          const Space v496_11 = routine_50(c, v496_6, p1, v493_11_tail, s1);
          v494_12 = compose(v494_10,v496_11);
        }
        const Space v494_13 = unite(v494_8,v494_12);
        v493_11_result = unite(v493_11_result,v494_13);
      }
      const Space v493_11 = std::move(v493_11_result);
      v488_12 = compose(v488_10,v493_11);
    }
    const Space v488_13 = unite(v488_8,v488_12);
    v487_13_result = unite(v487_13_result,v488_13);
  }
  const Space v487_13 = std::move(v487_13_result);
  return v487_13;
}

static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v497_8 = unwrap(s1,constant_5);
  const Space v497_10 = unwrap(v497_8,constant_6);
  const Space v497_11 = unwrap(v497_10,p0);
  Space v497_18_result;
  for (int v497_18_label = 1; v497_18_label <= 2; ++v497_18_label) {
    const Space v497_18_tail = child(s0,v497_18_label);
    if (v497_18_tail.empty()) continue;
    const Path v497_18_head{v497_18_label};
    const Space v498_2 = singleton(v497_18_head);
    const Space v498_3 = intersect(constant_3,v498_2);
    const Space v498_4 = (has_head(v498_3) ? constant_4 : Space{});
    const Space v498_5 = subtract(constant_2,v498_4);
    Space v498_8;
    if (!v498_5.empty()) {
      const Path v499_6 = concat_path(p0,v497_18_head);
      Space v499_7_result;
      for (int v499_7_label = 1; v499_7_label <= 2; ++v499_7_label) {
        const Space v499_7_tail = child(v497_18_tail,v499_7_label);
        if (v499_7_tail.empty()) continue;
        const Path v499_7_head{v499_7_label};
        const Space v500_2 = singleton(v499_7_head);
        const Space v500_3 = intersect(constant_3,v500_2);
        const Space v500_4 = (has_head(v500_3) ? constant_4 : Space{});
        const Space v500_5 = subtract(constant_2,v500_4);
        Space v500_8;
        if (!v500_5.empty()) {
          const Path v501_6 = concat_path(v499_6,v499_7_head);
          const Space v501_7 = routine_91(c, v501_6, p1, v499_7_tail, s1);
          v500_8 = compose(v500_5,v501_7);
        }
        const Space v500_9 = intersect(constant_3,v500_2);
        const Space v500_10 = (has_head(v500_9) ? constant_4 : Space{});
        Space v500_12;
        if (!v500_10.empty()) {
          const Path v502_6 = concat_path(v499_6,v499_7_head);
          const Space v502_11 = routine_92(c, v502_6, p1, v499_7_tail, s1);
          v500_12 = compose(v500_10,v502_11);
        }
        const Space v500_13 = unite(v500_8,v500_12);
        v499_7_result = unite(v499_7_result,v500_13);
      }
      const Space v499_7 = std::move(v499_7_result);
      v498_8 = compose(v498_5,v499_7);
    }
    const Space v498_9 = intersect(constant_3,v498_2);
    const Space v498_10 = (has_head(v498_9) ? constant_4 : Space{});
    Space v498_13;
    if (!v498_10.empty()) {
      const Space v503_11 = unwrap(v497_11,v497_18_head);
      Space v503_12_result;
      for (int v503_12_label = 1; v503_12_label <= 2; ++v503_12_label) {
        const Space v503_12_tail = child(v503_11,v503_12_label);
        if (v503_12_tail.empty()) continue;
        const Path v503_12_head{v503_12_label};
        const Space v504_2 = singleton(v503_12_head);
        const Space v504_3 = intersect(constant_3,v504_2);
        const Space v504_4 = (has_head(v504_3) ? constant_4 : Space{});
        const Space v504_5 = subtract(constant_2,v504_4);
        Space v504_7;
        if (!v504_5.empty()) {
          const Space v505_6 = routine_89(c, v503_12_head, p1, v503_12_tail);
          v504_7 = compose(v504_5,v505_6);
        }
        const Space v504_8 = intersect(constant_3,v504_2);
        const Space v504_9 = (has_head(v504_8) ? constant_4 : Space{});
        Space v504_11;
        if (!v504_9.empty()) {
          const Space v506_10 = routine_90(c, v503_12_head, p1, v503_12_tail);
          v504_11 = compose(v504_9,v506_10);
        }
        const Space v504_12 = unite(v504_7,v504_11);
        v503_12_result = unite(v503_12_result,v504_12);
      }
      const Space v503_12 = std::move(v503_12_result);
      v498_13 = compose(v498_10,v503_12);
    }
    const Space v498_14 = unite(v498_8,v498_13);
    v497_18_result = unite(v497_18_result,v498_14);
  }
  const Space v497_18 = std::move(v497_18_result);
  return v497_18;
}

static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v507_5 = unwrap(s1,constant_5);
  const Space v507_7 = unwrap(v507_5,constant_6);
  const Space v507_8 = unwrap(v507_7,p0);
  Space v507_18_result;
  for (int v507_18_label = 1; v507_18_label <= 2; ++v507_18_label) {
    const Space v507_18_tail = child(v507_8,v507_18_label);
    if (v507_18_tail.empty()) continue;
    const Path v507_18_head{v507_18_label};
    const Space v508_2 = singleton(v507_18_head);
    const Space v508_3 = intersect(constant_3,v508_2);
    const Space v508_4 = (has_head(v508_3) ? constant_4 : Space{});
    const Space v508_5 = subtract(constant_2,v508_4);
    Space v508_7;
    if (!v508_5.empty()) {
      Space v509_6_result;
      for (int v509_6_label = 1; v509_6_label <= 2; ++v509_6_label) {
        const Space v509_6_tail = child(v507_18_tail,v509_6_label);
        if (v509_6_tail.empty()) continue;
        const Path v509_6_head{v509_6_label};
        const Space v510_2 = singleton(v509_6_head);
        const Space v510_3 = intersect(constant_3,v510_2);
        const Space v510_4 = (has_head(v510_3) ? constant_4 : Space{});
        const Space v510_5 = subtract(constant_2,v510_4);
        Space v510_8;
        if (!v510_5.empty()) {
          const Path v511_6 = concat_path(v507_18_head,v509_6_head);
          const Space v511_7 = routine_93(c, v511_6, p1, v509_6_tail);
          v510_8 = compose(v510_5,v511_7);
        }
        const Space v510_9 = intersect(constant_3,v510_2);
        const Space v510_10 = (has_head(v510_9) ? constant_4 : Space{});
        Space v510_12;
        if (!v510_10.empty()) {
          const Path v512_6 = concat_path(v507_18_head,v509_6_head);
          const Space v512_11 = routine_94(c, v512_6, p1, v509_6_tail);
          v510_12 = compose(v510_10,v512_11);
        }
        const Space v510_13 = unite(v510_8,v510_12);
        v509_6_result = unite(v509_6_result,v510_13);
      }
      const Space v509_6 = std::move(v509_6_result);
      v508_7 = compose(v508_5,v509_6);
    }
    const Space v508_8 = intersect(constant_3,v508_2);
    const Space v508_9 = (has_head(v508_8) ? constant_4 : Space{});
    Space v508_11;
    if (!v508_9.empty()) {
      Space v513_10_result;
      for (int v513_10_label = 1; v513_10_label <= 2; ++v513_10_label) {
        const Space v513_10_tail = child(v507_18_tail,v513_10_label);
        if (v513_10_tail.empty()) continue;
        const Path v513_10_head{v513_10_label};
        const Space v514_2 = singleton(v513_10_head);
        const Space v514_3 = intersect(constant_3,v514_2);
        const Space v514_4 = (has_head(v514_3) ? constant_4 : Space{});
        const Space v514_5 = subtract(constant_2,v514_4);
        Space v514_8;
        if (!v514_5.empty()) {
          const Path v515_6 = concat_path(v507_18_head,v513_10_head);
          const Space v515_7 = routine_93(c, v515_6, p1, v513_10_tail);
          v514_8 = compose(v514_5,v515_7);
        }
        const Space v514_9 = intersect(constant_3,v514_2);
        const Space v514_10 = (has_head(v514_9) ? constant_4 : Space{});
        Space v514_12;
        if (!v514_10.empty()) {
          const Path v516_6 = concat_path(v507_18_head,v513_10_head);
          const Space v516_11 = routine_95(c, v516_6, p1, v513_10_tail);
          v514_12 = compose(v514_10,v516_11);
        }
        const Space v514_13 = unite(v514_8,v514_12);
        v513_10_result = unite(v513_10_result,v514_13);
      }
      const Space v513_10 = std::move(v513_10_result);
      v508_11 = compose(v508_9,v513_10);
    }
    const Space v508_12 = unite(v508_7,v508_11);
    v507_18_result = unite(v507_18_result,v508_12);
  }
  const Space v507_18 = std::move(v507_18_result);
  return v507_18;
}

static Space routine_51(Context& c, const Path& p0, const Space& s0) {
  Space v517_11_result;
  for (int v517_11_label = 1; v517_11_label <= 2; ++v517_11_label) {
    const Space v517_11_tail = child(s0,v517_11_label);
    if (v517_11_tail.empty()) continue;
    const Path v517_11_head{v517_11_label};
    const Space v518_2 = singleton(v517_11_head);
    const Space v518_3 = intersect(constant_3,v518_2);
    const Space v518_4 = (has_head(v518_3) ? constant_4 : Space{});
    const Space v518_5 = subtract(constant_2,v518_4);
    Space v518_8;
    if (!v518_5.empty()) {
      const Path v519_6 = concat_path(p0,v517_11_head);
      Space v519_7_result;
      for (int v519_7_label = 1; v519_7_label <= 2; ++v519_7_label) {
        const Space v519_7_tail = child(v517_11_tail,v519_7_label);
        if (v519_7_tail.empty()) continue;
        const Path v519_7_head{v519_7_label};
        const Space v520_2 = singleton(v519_7_head);
        const Space v520_3 = intersect(constant_3,v520_2);
        const Space v520_4 = (has_head(v520_3) ? constant_4 : Space{});
        const Space v520_5 = subtract(constant_2,v520_4);
        Space v520_8;
        if (!v520_5.empty()) {
          const Path v521_6 = concat_path(v519_6,v519_7_head);
          const Space v521_7 = routine_96(c, v521_6, v519_7_tail);
          v520_8 = compose(v520_5,v521_7);
        }
        const Space v520_9 = intersect(constant_3,v520_2);
        const Space v520_10 = (has_head(v520_9) ? constant_4 : Space{});
        Space v520_12;
        if (!v520_10.empty()) {
          const Path v522_6 = concat_path(v519_6,v519_7_head);
          const Space v522_11 = routine_97(c, v522_6, v519_7_tail);
          v520_12 = compose(v520_10,v522_11);
        }
        const Space v520_13 = unite(v520_8,v520_12);
        v519_7_result = unite(v519_7_result,v520_13);
      }
      const Space v519_7 = std::move(v519_7_result);
      v518_8 = compose(v518_5,v519_7);
    }
    const Space v518_9 = intersect(constant_3,v518_2);
    const Space v518_10 = (has_head(v518_9) ? constant_4 : Space{});
    Space v518_12;
    if (!v518_10.empty()) {
      const Path v523_6 = concat_path(p0,v517_11_head);
      Space v523_11_result;
      for (int v523_11_label = 1; v523_11_label <= 2; ++v523_11_label) {
        const Space v523_11_tail = child(v517_11_tail,v523_11_label);
        if (v523_11_tail.empty()) continue;
        const Path v523_11_head{v523_11_label};
        const Space v524_2 = singleton(v523_11_head);
        const Space v524_3 = intersect(constant_3,v524_2);
        const Space v524_4 = (has_head(v524_3) ? constant_4 : Space{});
        const Space v524_5 = subtract(constant_2,v524_4);
        Space v524_8;
        if (!v524_5.empty()) {
          const Path v525_6 = concat_path(v523_6,v523_11_head);
          const Space v525_7 = routine_96(c, v525_6, v523_11_tail);
          v524_8 = compose(v524_5,v525_7);
        }
        const Space v524_9 = intersect(constant_3,v524_2);
        const Space v524_10 = (has_head(v524_9) ? constant_4 : Space{});
        Space v524_12;
        if (!v524_10.empty()) {
          const Path v526_6 = concat_path(v523_6,v523_11_head);
          const Space v526_11 = routine_3(c, v526_6, v523_11_tail);
          v524_12 = compose(v524_10,v526_11);
        }
        const Space v524_13 = unite(v524_8,v524_12);
        v523_11_result = unite(v523_11_result,v524_13);
      }
      const Space v523_11 = std::move(v523_11_result);
      v518_12 = compose(v518_10,v523_11);
    }
    const Space v518_13 = unite(v518_8,v518_12);
    v517_11_result = unite(v517_11_result,v518_13);
  }
  const Space v517_11 = std::move(v517_11_result);
  return v517_11;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0) {
  Space v527_11_result;
  for (int v527_11_label = 1; v527_11_label <= 2; ++v527_11_label) {
    const Space v527_11_tail = child(s0,v527_11_label);
    if (v527_11_tail.empty()) continue;
    const Path v527_11_head{v527_11_label};
    const Space v528_2 = singleton(v527_11_head);
    const Space v528_3 = intersect(constant_3,v528_2);
    const Space v528_4 = (has_head(v528_3) ? constant_4 : Space{});
    const Space v528_5 = subtract(constant_2,v528_4);
    Space v528_8;
    if (!v528_5.empty()) {
      const Path v529_6 = concat_path(p0,v527_11_head);
      Space v529_7_result;
      for (int v529_7_label = 1; v529_7_label <= 2; ++v529_7_label) {
        const Space v529_7_tail = child(v527_11_tail,v529_7_label);
        if (v529_7_tail.empty()) continue;
        const Path v529_7_head{v529_7_label};
        const Space v530_2 = singleton(v529_7_head);
        const Space v530_3 = intersect(constant_3,v530_2);
        const Space v530_4 = (has_head(v530_3) ? constant_4 : Space{});
        const Space v530_5 = subtract(constant_2,v530_4);
        Space v530_8;
        if (!v530_5.empty()) {
          const Path v531_6 = concat_path(v529_6,v529_7_head);
          const Space v531_7 = routine_96(c, v531_6, v529_7_tail);
          v530_8 = compose(v530_5,v531_7);
        }
        const Space v530_9 = intersect(constant_3,v530_2);
        const Space v530_10 = (has_head(v530_9) ? constant_4 : Space{});
        Space v530_12;
        if (!v530_10.empty()) {
          const Path v532_6 = concat_path(v529_6,v529_7_head);
          const Space v532_11 = routine_97(c, v532_6, v529_7_tail);
          v530_12 = compose(v530_10,v532_11);
        }
        const Space v530_13 = unite(v530_8,v530_12);
        v529_7_result = unite(v529_7_result,v530_13);
      }
      const Space v529_7 = std::move(v529_7_result);
      v528_8 = compose(v528_5,v529_7);
    }
    const Space v528_9 = intersect(constant_3,v528_2);
    const Space v528_10 = (has_head(v528_9) ? constant_4 : Space{});
    Space v528_12;
    if (!v528_10.empty()) {
      const Path v533_6 = concat_path(p0,v527_11_head);
      Space v533_11_result;
      for (int v533_11_label = 1; v533_11_label <= 2; ++v533_11_label) {
        const Space v533_11_tail = child(v527_11_tail,v533_11_label);
        if (v533_11_tail.empty()) continue;
        const Path v533_11_head{v533_11_label};
        const Space v534_2 = singleton(v533_11_head);
        const Space v534_3 = intersect(constant_3,v534_2);
        const Space v534_4 = (has_head(v534_3) ? constant_4 : Space{});
        const Space v534_5 = subtract(constant_2,v534_4);
        Space v534_7;
        if (!v534_5.empty()) {
          const Space v535_6 = routine_18(c, v533_11_head, v533_6, v533_11_tail);
          v534_7 = compose(v534_5,v535_6);
        }
        const Space v534_8 = intersect(constant_3,v534_2);
        const Space v534_9 = (has_head(v534_8) ? constant_4 : Space{});
        Space v534_11;
        if (!v534_9.empty()) {
          const Space v536_10 = routine_19(c, v533_11_head, v533_6, v533_11_tail);
          v534_11 = compose(v534_9,v536_10);
        }
        const Space v534_12 = unite(v534_7,v534_11);
        v533_11_result = unite(v533_11_result,v534_12);
      }
      const Space v533_11 = std::move(v533_11_result);
      v528_12 = compose(v528_10,v533_11);
    }
    const Space v528_13 = unite(v528_8,v528_12);
    v527_11_result = unite(v527_11_result,v528_13);
  }
  const Space v527_11 = std::move(v527_11_result);
  return v527_11;
}

static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v537_12_result;
  for (int v537_12_label = 1; v537_12_label <= 2; ++v537_12_label) {
    const Space v537_12_tail = child(s0,v537_12_label);
    if (v537_12_tail.empty()) continue;
    const Path v537_12_head{v537_12_label};
    const Space v538_2 = singleton(v537_12_head);
    const Space v538_3 = intersect(constant_3,v538_2);
    const Space v538_4 = (has_head(v538_3) ? constant_4 : Space{});
    const Space v538_5 = subtract(constant_2,v538_4);
    Space v538_8;
    if (!v538_5.empty()) {
      const Path v539_6 = concat_path(p0,v537_12_head);
      Space v539_7_result;
      for (int v539_7_label = 1; v539_7_label <= 2; ++v539_7_label) {
        const Space v539_7_tail = child(v537_12_tail,v539_7_label);
        if (v539_7_tail.empty()) continue;
        const Path v539_7_head{v539_7_label};
        const Space v540_2 = singleton(v539_7_head);
        const Space v540_3 = intersect(constant_3,v540_2);
        const Space v540_4 = (has_head(v540_3) ? constant_4 : Space{});
        const Space v540_5 = subtract(constant_2,v540_4);
        Space v540_8;
        if (!v540_5.empty()) {
          const Path v541_6 = concat_path(v539_6,v539_7_head);
          const Space v541_7 = routine_98(c, v541_6, p1, v539_7_tail);
          v540_8 = compose(v540_5,v541_7);
        }
        const Space v540_9 = intersect(constant_3,v540_2);
        const Space v540_10 = (has_head(v540_9) ? constant_4 : Space{});
        Space v540_12;
        if (!v540_10.empty()) {
          const Path v542_6 = concat_path(v539_6,v539_7_head);
          const Space v542_11 = routine_99(c, v542_6, p1, v539_7_tail);
          v540_12 = compose(v540_10,v542_11);
        }
        const Space v540_13 = unite(v540_8,v540_12);
        v539_7_result = unite(v539_7_result,v540_13);
      }
      const Space v539_7 = std::move(v539_7_result);
      v538_8 = compose(v538_5,v539_7);
    }
    const Space v538_9 = intersect(constant_3,v538_2);
    const Space v538_10 = (has_head(v538_9) ? constant_4 : Space{});
    Space v538_12;
    if (!v538_10.empty()) {
      const Path v543_6 = concat_path(p0,v537_12_head);
      Space v543_11_result;
      for (int v543_11_label = 1; v543_11_label <= 2; ++v543_11_label) {
        const Space v543_11_tail = child(v537_12_tail,v543_11_label);
        if (v543_11_tail.empty()) continue;
        const Path v543_11_head{v543_11_label};
        const Space v544_2 = singleton(v543_11_head);
        const Space v544_3 = intersect(constant_3,v544_2);
        const Space v544_4 = (has_head(v544_3) ? constant_4 : Space{});
        const Space v544_5 = subtract(constant_2,v544_4);
        Space v544_8;
        if (!v544_5.empty()) {
          const Path v545_6 = concat_path(v543_6,v543_11_head);
          const Space v545_7 = routine_98(c, v545_6, p1, v543_11_tail);
          v544_8 = compose(v544_5,v545_7);
        }
        const Space v544_9 = intersect(constant_3,v544_2);
        const Space v544_10 = (has_head(v544_9) ? constant_4 : Space{});
        Space v544_12;
        if (!v544_10.empty()) {
          const Path v546_6 = concat_path(v543_6,v543_11_head);
          const Space v546_11 = routine_22(c, v546_6, p1, v543_11_tail);
          v544_12 = compose(v544_10,v546_11);
        }
        const Space v544_13 = unite(v544_8,v544_12);
        v543_11_result = unite(v543_11_result,v544_13);
      }
      const Space v543_11 = std::move(v543_11_result);
      v538_12 = compose(v538_10,v543_11);
    }
    const Space v538_13 = unite(v538_8,v538_12);
    v537_12_result = unite(v537_12_result,v538_13);
  }
  const Space v537_12 = std::move(v537_12_result);
  return v537_12;
}

static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v547_10_result;
  for (int v547_10_label = 1; v547_10_label <= 2; ++v547_10_label) {
    const Space v547_10_tail = child(s0,v547_10_label);
    if (v547_10_tail.empty()) continue;
    const Path v547_10_head{v547_10_label};
    const Space v548_2 = singleton(v547_10_head);
    const Space v548_3 = intersect(constant_3,v548_2);
    const Space v548_4 = (has_head(v548_3) ? constant_4 : Space{});
    const Space v548_5 = compose(v548_4,v547_10_tail);
    const Path v549_6 = concat_path(p0,v547_10_head);
    const Space v548_7 = wrap(v548_5,v549_6);
    const Space v548_8 = wrap(v548_7,p1);
    const Space v548_9 = wrap(v548_8,constant_6);
    const Space v548_10 = intersect(constant_3,v548_2);
    const Space v548_11 = (has_head(v548_10) ? constant_4 : Space{});
    const Space v548_12 = subtract(constant_2,v548_11);
    Space v548_14;
    if (!v548_12.empty()) {
      Space v550_13_result;
      for (int v550_13_label = 1; v550_13_label <= 2; ++v550_13_label) {
        const Space v550_13_tail = child(v547_10_tail,v550_13_label);
        if (v550_13_tail.empty()) continue;
        const Path v550_13_head{v550_13_label};
        const Space v551_2 = singleton(v550_13_head);
        const Space v551_3 = intersect(constant_3,v551_2);
        const Space v551_4 = (has_head(v551_3) ? constant_4 : Space{});
        const Space v551_5 = subtract(constant_2,v551_4);
        Space v551_8;
        if (!v551_5.empty()) {
          const Path v552_6 = concat_path(v549_6,v550_13_head);
          const Space v552_7 = routine_98(c, v552_6, p1, v550_13_tail);
          v551_8 = compose(v551_5,v552_7);
        }
        const Space v551_9 = intersect(constant_3,v551_2);
        const Space v551_10 = (has_head(v551_9) ? constant_4 : Space{});
        Space v551_12;
        if (!v551_10.empty()) {
          const Path v553_6 = concat_path(v549_6,v550_13_head);
          const Space v553_11 = routine_99(c, v553_6, p1, v550_13_tail);
          v551_12 = compose(v551_10,v553_11);
        }
        const Space v551_13 = unite(v551_8,v551_12);
        v550_13_result = unite(v550_13_result,v551_13);
      }
      const Space v550_13 = std::move(v550_13_result);
      v548_14 = compose(v548_12,v550_13);
    }
    const Space v548_15 = unite(v548_9,v548_14);
    v547_10_result = unite(v547_10_result,v548_15);
  }
  const Space v547_10 = std::move(v547_10_result);
  return v547_10;
}

static Space routine_55(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v554_12_result;
  for (int v554_12_label = 1; v554_12_label <= 2; ++v554_12_label) {
    const Space v554_12_tail = child(s0,v554_12_label);
    if (v554_12_tail.empty()) continue;
    const Path v554_12_head{v554_12_label};
    const Space v555_2 = singleton(v554_12_head);
    const Space v555_3 = intersect(constant_3,v555_2);
    const Space v555_4 = (has_head(v555_3) ? constant_4 : Space{});
    const Space v555_5 = subtract(constant_2,v555_4);
    Space v555_8;
    if (!v555_5.empty()) {
      const Path v556_6 = concat_path(p0,v554_12_head);
      Space v556_7_result;
      for (int v556_7_label = 1; v556_7_label <= 2; ++v556_7_label) {
        const Space v556_7_tail = child(v554_12_tail,v556_7_label);
        if (v556_7_tail.empty()) continue;
        const Path v556_7_head{v556_7_label};
        const Space v557_2 = singleton(v556_7_head);
        const Space v557_3 = intersect(constant_3,v557_2);
        const Space v557_4 = (has_head(v557_3) ? constant_4 : Space{});
        const Space v557_5 = subtract(constant_2,v557_4);
        Space v557_8;
        if (!v557_5.empty()) {
          const Path v558_6 = concat_path(v556_6,v556_7_head);
          const Space v558_7 = routine_100(c, v558_6, p1, v556_7_tail);
          v557_8 = compose(v557_5,v558_7);
        }
        const Space v557_9 = intersect(constant_3,v557_2);
        const Space v557_10 = (has_head(v557_9) ? constant_4 : Space{});
        Space v557_12;
        if (!v557_10.empty()) {
          const Path v559_6 = concat_path(v556_6,v556_7_head);
          const Space v559_11 = routine_101(c, v559_6, p1, v556_7_tail);
          v557_12 = compose(v557_10,v559_11);
        }
        const Space v557_13 = unite(v557_8,v557_12);
        v556_7_result = unite(v556_7_result,v557_13);
      }
      const Space v556_7 = std::move(v556_7_result);
      v555_8 = compose(v555_5,v556_7);
    }
    const Space v555_9 = intersect(constant_3,v555_2);
    const Space v555_10 = (has_head(v555_9) ? constant_4 : Space{});
    Space v555_12;
    if (!v555_10.empty()) {
      const Path v560_6 = concat_path(p0,v554_12_head);
      Space v560_11_result;
      for (int v560_11_label = 1; v560_11_label <= 2; ++v560_11_label) {
        const Space v560_11_tail = child(v554_12_tail,v560_11_label);
        if (v560_11_tail.empty()) continue;
        const Path v560_11_head{v560_11_label};
        const Space v561_2 = singleton(v560_11_head);
        const Space v561_3 = intersect(constant_3,v561_2);
        const Space v561_4 = (has_head(v561_3) ? constant_4 : Space{});
        const Space v561_5 = subtract(constant_2,v561_4);
        Space v561_8;
        if (!v561_5.empty()) {
          const Path v562_6 = concat_path(v560_6,v560_11_head);
          const Space v562_7 = routine_100(c, v562_6, p1, v560_11_tail);
          v561_8 = compose(v561_5,v562_7);
        }
        const Space v561_9 = intersect(constant_3,v561_2);
        const Space v561_10 = (has_head(v561_9) ? constant_4 : Space{});
        Space v561_12;
        if (!v561_10.empty()) {
          const Path v563_6 = concat_path(v560_6,v560_11_head);
          const Space v563_11 = routine_22(c, v563_6, p1, v560_11_tail);
          v561_12 = compose(v561_10,v563_11);
        }
        const Space v561_13 = unite(v561_8,v561_12);
        v560_11_result = unite(v560_11_result,v561_13);
      }
      const Space v560_11 = std::move(v560_11_result);
      v555_12 = compose(v555_10,v560_11);
    }
    const Space v555_13 = unite(v555_8,v555_12);
    v554_12_result = unite(v554_12_result,v555_13);
  }
  const Space v554_12 = std::move(v554_12_result);
  return v554_12;
}

static Space routine_56(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v564_10_result;
  for (int v564_10_label = 1; v564_10_label <= 2; ++v564_10_label) {
    const Space v564_10_tail = child(s0,v564_10_label);
    if (v564_10_tail.empty()) continue;
    const Path v564_10_head{v564_10_label};
    const Space v565_2 = singleton(v564_10_head);
    const Space v565_3 = intersect(constant_3,v565_2);
    const Space v565_4 = (has_head(v565_3) ? constant_4 : Space{});
    const Space v565_5 = compose(v565_4,v564_10_tail);
    const Path v566_6 = concat_path(p0,v564_10_head);
    const Space v565_7 = wrap(v565_5,v566_6);
    const Space v565_8 = wrap(v565_7,p1);
    const Space v565_9 = wrap(v565_8,constant_6);
    const Space v565_10 = intersect(constant_3,v565_2);
    const Space v565_11 = (has_head(v565_10) ? constant_4 : Space{});
    const Space v565_12 = subtract(constant_2,v565_11);
    Space v565_14;
    if (!v565_12.empty()) {
      Space v567_13_result;
      for (int v567_13_label = 1; v567_13_label <= 2; ++v567_13_label) {
        const Space v567_13_tail = child(v564_10_tail,v567_13_label);
        if (v567_13_tail.empty()) continue;
        const Path v567_13_head{v567_13_label};
        const Space v568_2 = singleton(v567_13_head);
        const Space v568_3 = intersect(constant_3,v568_2);
        const Space v568_4 = (has_head(v568_3) ? constant_4 : Space{});
        const Space v568_5 = subtract(constant_2,v568_4);
        Space v568_8;
        if (!v568_5.empty()) {
          const Path v569_6 = concat_path(v566_6,v567_13_head);
          const Space v569_7 = routine_100(c, v569_6, p1, v567_13_tail);
          v568_8 = compose(v568_5,v569_7);
        }
        const Space v568_9 = intersect(constant_3,v568_2);
        const Space v568_10 = (has_head(v568_9) ? constant_4 : Space{});
        Space v568_12;
        if (!v568_10.empty()) {
          const Path v570_6 = concat_path(v566_6,v567_13_head);
          const Space v570_11 = routine_101(c, v570_6, p1, v567_13_tail);
          v568_12 = compose(v568_10,v570_11);
        }
        const Space v568_13 = unite(v568_8,v568_12);
        v567_13_result = unite(v567_13_result,v568_13);
      }
      const Space v567_13 = std::move(v567_13_result);
      v565_14 = compose(v565_12,v567_13);
    }
    const Space v565_15 = unite(v565_9,v565_14);
    v564_10_result = unite(v564_10_result,v565_15);
  }
  const Space v564_10 = std::move(v564_10_result);
  return v564_10;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v571_12_result;
  for (int v571_12_label = 1; v571_12_label <= 2; ++v571_12_label) {
    const Space v571_12_tail = child(s0,v571_12_label);
    if (v571_12_tail.empty()) continue;
    const Path v571_12_head{v571_12_label};
    const Space v572_2 = singleton(v571_12_head);
    const Space v572_3 = intersect(constant_3,v572_2);
    const Space v572_4 = (has_head(v572_3) ? constant_4 : Space{});
    const Space v572_5 = subtract(constant_2,v572_4);
    Space v572_8;
    if (!v572_5.empty()) {
      const Path v573_6 = concat_path(p0,v571_12_head);
      Space v573_7_result;
      for (int v573_7_label = 1; v573_7_label <= 2; ++v573_7_label) {
        const Space v573_7_tail = child(v571_12_tail,v573_7_label);
        if (v573_7_tail.empty()) continue;
        const Path v573_7_head{v573_7_label};
        const Space v574_2 = singleton(v573_7_head);
        const Space v574_3 = intersect(constant_3,v574_2);
        const Space v574_4 = (has_head(v574_3) ? constant_4 : Space{});
        const Space v574_5 = subtract(constant_2,v574_4);
        Space v574_8;
        if (!v574_5.empty()) {
          const Path v575_6 = concat_path(v573_6,v573_7_head);
          const Space v575_7 = routine_102(c, v575_6, v573_7_tail, s1);
          v574_8 = compose(v574_5,v575_7);
        }
        const Space v574_9 = intersect(constant_3,v574_2);
        const Space v574_10 = (has_head(v574_9) ? constant_4 : Space{});
        Space v574_12;
        if (!v574_10.empty()) {
          const Path v576_6 = concat_path(v573_6,v573_7_head);
          const Space v576_11 = routine_103(c, v576_6, v573_7_tail, s1);
          v574_12 = compose(v574_10,v576_11);
        }
        const Space v574_13 = unite(v574_8,v574_12);
        v573_7_result = unite(v573_7_result,v574_13);
      }
      const Space v573_7 = std::move(v573_7_result);
      v572_8 = compose(v572_5,v573_7);
    }
    const Space v572_9 = intersect(constant_3,v572_2);
    const Space v572_10 = (has_head(v572_9) ? constant_4 : Space{});
    Space v572_12;
    if (!v572_10.empty()) {
      const Path v577_6 = concat_path(p0,v571_12_head);
      Space v577_11_result;
      for (int v577_11_label = 1; v577_11_label <= 2; ++v577_11_label) {
        const Space v577_11_tail = child(v571_12_tail,v577_11_label);
        if (v577_11_tail.empty()) continue;
        const Path v577_11_head{v577_11_label};
        const Space v578_2 = singleton(v577_11_head);
        const Space v578_3 = intersect(constant_3,v578_2);
        const Space v578_4 = (has_head(v578_3) ? constant_4 : Space{});
        const Space v578_5 = subtract(constant_2,v578_4);
        Space v578_8;
        if (!v578_5.empty()) {
          const Path v579_6 = concat_path(v577_6,v577_11_head);
          const Space v579_7 = routine_102(c, v579_6, v577_11_tail, s1);
          v578_8 = compose(v578_5,v579_7);
        }
        const Space v578_9 = intersect(constant_3,v578_2);
        const Space v578_10 = (has_head(v578_9) ? constant_4 : Space{});
        Space v578_12;
        if (!v578_10.empty()) {
          const Path v580_6 = concat_path(v577_6,v577_11_head);
          const Space v580_11 = routine_6(c, v580_6, v577_11_tail, s1);
          v578_12 = compose(v578_10,v580_11);
        }
        const Space v578_13 = unite(v578_8,v578_12);
        v577_11_result = unite(v577_11_result,v578_13);
      }
      const Space v577_11 = std::move(v577_11_result);
      v572_12 = compose(v572_10,v577_11);
    }
    const Space v572_13 = unite(v572_8,v572_12);
    v571_12_result = unite(v571_12_result,v572_13);
  }
  const Space v571_12 = std::move(v571_12_result);
  return v571_12;
}

static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v581_12_result;
  for (int v581_12_label = 1; v581_12_label <= 2; ++v581_12_label) {
    const Space v581_12_tail = child(s0,v581_12_label);
    if (v581_12_tail.empty()) continue;
    const Path v581_12_head{v581_12_label};
    const Space v582_2 = singleton(v581_12_head);
    const Space v582_3 = intersect(constant_3,v582_2);
    const Space v582_4 = (has_head(v582_3) ? constant_4 : Space{});
    const Space v582_5 = subtract(constant_2,v582_4);
    Space v582_8;
    if (!v582_5.empty()) {
      const Path v583_6 = concat_path(p0,v581_12_head);
      Space v583_7_result;
      for (int v583_7_label = 1; v583_7_label <= 2; ++v583_7_label) {
        const Space v583_7_tail = child(v581_12_tail,v583_7_label);
        if (v583_7_tail.empty()) continue;
        const Path v583_7_head{v583_7_label};
        const Space v584_2 = singleton(v583_7_head);
        const Space v584_3 = intersect(constant_3,v584_2);
        const Space v584_4 = (has_head(v584_3) ? constant_4 : Space{});
        const Space v584_5 = subtract(constant_2,v584_4);
        Space v584_8;
        if (!v584_5.empty()) {
          const Path v585_6 = concat_path(v583_6,v583_7_head);
          const Space v585_7 = routine_102(c, v585_6, v583_7_tail, s1);
          v584_8 = compose(v584_5,v585_7);
        }
        const Space v584_9 = intersect(constant_3,v584_2);
        const Space v584_10 = (has_head(v584_9) ? constant_4 : Space{});
        Space v584_12;
        if (!v584_10.empty()) {
          const Path v586_6 = concat_path(v583_6,v583_7_head);
          const Space v586_11 = routine_103(c, v586_6, v583_7_tail, s1);
          v584_12 = compose(v584_10,v586_11);
        }
        const Space v584_13 = unite(v584_8,v584_12);
        v583_7_result = unite(v583_7_result,v584_13);
      }
      const Space v583_7 = std::move(v583_7_result);
      v582_8 = compose(v582_5,v583_7);
    }
    const Space v582_9 = intersect(constant_3,v582_2);
    const Space v582_10 = (has_head(v582_9) ? constant_4 : Space{});
    Space v582_12;
    if (!v582_10.empty()) {
      const Path v587_6 = concat_path(p0,v581_12_head);
      Space v587_11_result;
      for (int v587_11_label = 1; v587_11_label <= 2; ++v587_11_label) {
        const Space v587_11_tail = child(v581_12_tail,v587_11_label);
        if (v587_11_tail.empty()) continue;
        const Path v587_11_head{v587_11_label};
        const Space v588_2 = singleton(v587_11_head);
        const Space v588_3 = intersect(constant_3,v588_2);
        const Space v588_4 = (has_head(v588_3) ? constant_4 : Space{});
        const Space v588_5 = subtract(constant_2,v588_4);
        Space v588_7;
        if (!v588_5.empty()) {
          const Space v589_6 = routine_25(c, v587_11_head, v587_6, v587_11_tail, s1);
          v588_7 = compose(v588_5,v589_6);
        }
        const Space v588_8 = intersect(constant_3,v588_2);
        const Space v588_9 = (has_head(v588_8) ? constant_4 : Space{});
        Space v588_11;
        if (!v588_9.empty()) {
          const Space v590_10 = routine_26(c, v587_11_head, v587_6, v587_11_tail, s1);
          v588_11 = compose(v588_9,v590_10);
        }
        const Space v588_12 = unite(v588_7,v588_11);
        v587_11_result = unite(v587_11_result,v588_12);
      }
      const Space v587_11 = std::move(v587_11_result);
      v582_12 = compose(v582_10,v587_11);
    }
    const Space v582_13 = unite(v582_8,v582_12);
    v581_12_result = unite(v581_12_result,v582_13);
  }
  const Space v581_12 = std::move(v581_12_result);
  return v581_12;
}

static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v591_13_result;
  for (int v591_13_label = 1; v591_13_label <= 2; ++v591_13_label) {
    const Space v591_13_tail = child(s0,v591_13_label);
    if (v591_13_tail.empty()) continue;
    const Path v591_13_head{v591_13_label};
    const Space v592_2 = singleton(v591_13_head);
    const Space v592_3 = intersect(constant_3,v592_2);
    const Space v592_4 = (has_head(v592_3) ? constant_4 : Space{});
    const Space v592_5 = subtract(constant_2,v592_4);
    Space v592_8;
    if (!v592_5.empty()) {
      const Path v593_6 = concat_path(p0,v591_13_head);
      Space v593_7_result;
      for (int v593_7_label = 1; v593_7_label <= 2; ++v593_7_label) {
        const Space v593_7_tail = child(v591_13_tail,v593_7_label);
        if (v593_7_tail.empty()) continue;
        const Path v593_7_head{v593_7_label};
        const Space v594_2 = singleton(v593_7_head);
        const Space v594_3 = intersect(constant_3,v594_2);
        const Space v594_4 = (has_head(v594_3) ? constant_4 : Space{});
        const Space v594_5 = subtract(constant_2,v594_4);
        Space v594_8;
        if (!v594_5.empty()) {
          const Path v595_6 = concat_path(v593_6,v593_7_head);
          const Space v595_7 = routine_104(c, v595_6, p1, v593_7_tail, s1);
          v594_8 = compose(v594_5,v595_7);
        }
        const Space v594_9 = intersect(constant_3,v594_2);
        const Space v594_10 = (has_head(v594_9) ? constant_4 : Space{});
        Space v594_12;
        if (!v594_10.empty()) {
          const Path v596_6 = concat_path(v593_6,v593_7_head);
          const Space v596_11 = routine_105(c, v596_6, p1, v593_7_tail, s1);
          v594_12 = compose(v594_10,v596_11);
        }
        const Space v594_13 = unite(v594_8,v594_12);
        v593_7_result = unite(v593_7_result,v594_13);
      }
      const Space v593_7 = std::move(v593_7_result);
      v592_8 = compose(v592_5,v593_7);
    }
    const Space v592_9 = intersect(constant_3,v592_2);
    const Space v592_10 = (has_head(v592_9) ? constant_4 : Space{});
    Space v592_12;
    if (!v592_10.empty()) {
      const Path v597_6 = concat_path(p0,v591_13_head);
      Space v597_11_result;
      for (int v597_11_label = 1; v597_11_label <= 2; ++v597_11_label) {
        const Space v597_11_tail = child(v591_13_tail,v597_11_label);
        if (v597_11_tail.empty()) continue;
        const Path v597_11_head{v597_11_label};
        const Space v598_2 = singleton(v597_11_head);
        const Space v598_3 = intersect(constant_3,v598_2);
        const Space v598_4 = (has_head(v598_3) ? constant_4 : Space{});
        const Space v598_5 = subtract(constant_2,v598_4);
        Space v598_8;
        if (!v598_5.empty()) {
          const Path v599_6 = concat_path(v597_6,v597_11_head);
          const Space v599_7 = routine_104(c, v599_6, p1, v597_11_tail, s1);
          v598_8 = compose(v598_5,v599_7);
        }
        const Space v598_9 = intersect(constant_3,v598_2);
        const Space v598_10 = (has_head(v598_9) ? constant_4 : Space{});
        Space v598_12;
        if (!v598_10.empty()) {
          const Path v600_6 = concat_path(v597_6,v597_11_head);
          const Space v600_11 = routine_29(c, v600_6, p1, v597_11_tail, s1);
          v598_12 = compose(v598_10,v600_11);
        }
        const Space v598_13 = unite(v598_8,v598_12);
        v597_11_result = unite(v597_11_result,v598_13);
      }
      const Space v597_11 = std::move(v597_11_result);
      v592_12 = compose(v592_10,v597_11);
    }
    const Space v592_13 = unite(v592_8,v592_12);
    v591_13_result = unite(v591_13_result,v592_13);
  }
  const Space v591_13 = std::move(v591_13_result);
  return v591_13;
}

static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v601_8 = unwrap(s1,constant_5);
  const Space v601_10 = unwrap(v601_8,constant_6);
  const Space v601_11 = unwrap(v601_10,p0);
  Space v601_18_result;
  for (int v601_18_label = 1; v601_18_label <= 2; ++v601_18_label) {
    const Space v601_18_tail = child(s0,v601_18_label);
    if (v601_18_tail.empty()) continue;
    const Path v601_18_head{v601_18_label};
    const Space v602_2 = singleton(v601_18_head);
    const Space v602_3 = intersect(constant_3,v602_2);
    const Space v602_4 = (has_head(v602_3) ? constant_4 : Space{});
    const Space v602_5 = subtract(constant_2,v602_4);
    Space v602_8;
    if (!v602_5.empty()) {
      const Path v603_6 = concat_path(p0,v601_18_head);
      Space v603_7_result;
      for (int v603_7_label = 1; v603_7_label <= 2; ++v603_7_label) {
        const Space v603_7_tail = child(v601_18_tail,v603_7_label);
        if (v603_7_tail.empty()) continue;
        const Path v603_7_head{v603_7_label};
        const Space v604_2 = singleton(v603_7_head);
        const Space v604_3 = intersect(constant_3,v604_2);
        const Space v604_4 = (has_head(v604_3) ? constant_4 : Space{});
        const Space v604_5 = subtract(constant_2,v604_4);
        Space v604_8;
        if (!v604_5.empty()) {
          const Path v605_6 = concat_path(v603_6,v603_7_head);
          const Space v605_7 = routine_104(c, v605_6, p1, v603_7_tail, s1);
          v604_8 = compose(v604_5,v605_7);
        }
        const Space v604_9 = intersect(constant_3,v604_2);
        const Space v604_10 = (has_head(v604_9) ? constant_4 : Space{});
        Space v604_12;
        if (!v604_10.empty()) {
          const Path v606_6 = concat_path(v603_6,v603_7_head);
          const Space v606_11 = routine_105(c, v606_6, p1, v603_7_tail, s1);
          v604_12 = compose(v604_10,v606_11);
        }
        const Space v604_13 = unite(v604_8,v604_12);
        v603_7_result = unite(v603_7_result,v604_13);
      }
      const Space v603_7 = std::move(v603_7_result);
      v602_8 = compose(v602_5,v603_7);
    }
    const Space v602_9 = intersect(constant_3,v602_2);
    const Space v602_10 = (has_head(v602_9) ? constant_4 : Space{});
    Space v602_13;
    if (!v602_10.empty()) {
      const Space v607_11 = unwrap(v601_11,v601_18_head);
      Space v607_12_result;
      for (int v607_12_label = 1; v607_12_label <= 2; ++v607_12_label) {
        const Space v607_12_tail = child(v607_11,v607_12_label);
        if (v607_12_tail.empty()) continue;
        const Path v607_12_head{v607_12_label};
        const Space v608_2 = singleton(v607_12_head);
        const Space v608_3 = intersect(constant_3,v608_2);
        const Space v608_4 = (has_head(v608_3) ? constant_4 : Space{});
        const Space v608_5 = subtract(constant_2,v608_4);
        Space v608_7;
        if (!v608_5.empty()) {
          const Space v609_6 = routine_61(c, v607_12_head, p1, v607_12_tail);
          v608_7 = compose(v608_5,v609_6);
        }
        const Space v608_8 = intersect(constant_3,v608_2);
        const Space v608_9 = (has_head(v608_8) ? constant_4 : Space{});
        Space v608_11;
        if (!v608_9.empty()) {
          const Space v610_10 = routine_62(c, v607_12_head, p1, v607_12_tail);
          v608_11 = compose(v608_9,v610_10);
        }
        const Space v608_12 = unite(v608_7,v608_11);
        v607_12_result = unite(v607_12_result,v608_12);
      }
      const Space v607_12 = std::move(v607_12_result);
      v602_13 = compose(v602_10,v607_12);
    }
    const Space v602_14 = unite(v602_8,v602_13);
    v601_18_result = unite(v601_18_result,v602_14);
  }
  const Space v601_18 = std::move(v601_18_result);
  return v601_18;
}

static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v611_12_result;
  for (int v611_12_label = 1; v611_12_label <= 2; ++v611_12_label) {
    const Space v611_12_tail = child(s0,v611_12_label);
    if (v611_12_tail.empty()) continue;
    const Path v611_12_head{v611_12_label};
    const Space v612_2 = singleton(v611_12_head);
    const Space v612_3 = intersect(constant_3,v612_2);
    const Space v612_4 = (has_head(v612_3) ? constant_4 : Space{});
    const Space v612_5 = subtract(constant_2,v612_4);
    Space v612_8;
    if (!v612_5.empty()) {
      const Path v613_6 = concat_path(p0,v611_12_head);
      Space v613_7_result;
      for (int v613_7_label = 1; v613_7_label <= 2; ++v613_7_label) {
        const Space v613_7_tail = child(v611_12_tail,v613_7_label);
        if (v613_7_tail.empty()) continue;
        const Path v613_7_head{v613_7_label};
        const Space v614_2 = singleton(v613_7_head);
        const Space v614_3 = intersect(constant_3,v614_2);
        const Space v614_4 = (has_head(v614_3) ? constant_4 : Space{});
        const Space v614_5 = subtract(constant_2,v614_4);
        Space v614_8;
        if (!v614_5.empty()) {
          const Path v615_6 = concat_path(v613_6,v613_7_head);
          const Space v615_7 = routine_106(c, v615_6, p1, v613_7_tail);
          v614_8 = compose(v614_5,v615_7);
        }
        const Space v614_9 = intersect(constant_3,v614_2);
        const Space v614_10 = (has_head(v614_9) ? constant_4 : Space{});
        Space v614_12;
        if (!v614_10.empty()) {
          const Path v616_6 = concat_path(v613_6,v613_7_head);
          const Space v616_11 = routine_107(c, v616_6, p1, v613_7_tail);
          v614_12 = compose(v614_10,v616_11);
        }
        const Space v614_13 = unite(v614_8,v614_12);
        v613_7_result = unite(v613_7_result,v614_13);
      }
      const Space v613_7 = std::move(v613_7_result);
      v612_8 = compose(v612_5,v613_7);
    }
    const Space v612_9 = intersect(constant_3,v612_2);
    const Space v612_10 = (has_head(v612_9) ? constant_4 : Space{});
    Space v612_12;
    if (!v612_10.empty()) {
      const Path v617_6 = concat_path(p0,v611_12_head);
      Space v617_11_result;
      for (int v617_11_label = 1; v617_11_label <= 2; ++v617_11_label) {
        const Space v617_11_tail = child(v611_12_tail,v617_11_label);
        if (v617_11_tail.empty()) continue;
        const Path v617_11_head{v617_11_label};
        const Space v618_2 = singleton(v617_11_head);
        const Space v618_3 = intersect(constant_3,v618_2);
        const Space v618_4 = (has_head(v618_3) ? constant_4 : Space{});
        const Space v618_5 = subtract(constant_2,v618_4);
        Space v618_8;
        if (!v618_5.empty()) {
          const Path v619_6 = concat_path(v617_6,v617_11_head);
          const Space v619_7 = routine_106(c, v619_6, p1, v617_11_tail);
          v618_8 = compose(v618_5,v619_7);
        }
        const Space v618_9 = intersect(constant_3,v618_2);
        const Space v618_10 = (has_head(v618_9) ? constant_4 : Space{});
        Space v618_12;
        if (!v618_10.empty()) {
          const Path v620_6 = concat_path(v617_6,v617_11_head);
          const Space v620_11 = routine_67(c, v620_6, p1, v617_11_tail);
          v618_12 = compose(v618_10,v620_11);
        }
        const Space v618_13 = unite(v618_8,v618_12);
        v617_11_result = unite(v617_11_result,v618_13);
      }
      const Space v617_11 = std::move(v617_11_result);
      v612_12 = compose(v612_10,v617_11);
    }
    const Space v612_13 = unite(v612_8,v612_12);
    v611_12_result = unite(v611_12_result,v612_13);
  }
  const Space v611_12 = std::move(v611_12_result);
  return v611_12;
}

static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v621_9_result;
  for (int v621_9_label = 1; v621_9_label <= 2; ++v621_9_label) {
    const Space v621_9_tail = child(s0,v621_9_label);
    if (v621_9_tail.empty()) continue;
    const Path v621_9_head{v621_9_label};
    const Space v622_2 = singleton(v621_9_head);
    const Space v622_3 = intersect(constant_3,v622_2);
    const Space v622_4 = (has_head(v622_3) ? constant_4 : Space{});
    const Space v622_5 = subtract(constant_2,v622_4);
    Space v622_8;
    if (!v622_5.empty()) {
      const Path v623_6 = concat_path(p0,v621_9_head);
      Space v623_7_result;
      for (int v623_7_label = 1; v623_7_label <= 2; ++v623_7_label) {
        const Space v623_7_tail = child(v621_9_tail,v623_7_label);
        if (v623_7_tail.empty()) continue;
        const Path v623_7_head{v623_7_label};
        const Space v624_2 = singleton(v623_7_head);
        const Space v624_3 = intersect(constant_3,v624_2);
        const Space v624_4 = (has_head(v624_3) ? constant_4 : Space{});
        const Space v624_5 = subtract(constant_2,v624_4);
        Space v624_8;
        if (!v624_5.empty()) {
          const Path v625_6 = concat_path(v623_6,v623_7_head);
          const Space v625_7 = routine_106(c, v625_6, p1, v623_7_tail);
          v624_8 = compose(v624_5,v625_7);
        }
        const Space v624_9 = intersect(constant_3,v624_2);
        const Space v624_10 = (has_head(v624_9) ? constant_4 : Space{});
        Space v624_12;
        if (!v624_10.empty()) {
          const Path v626_6 = concat_path(v623_6,v623_7_head);
          const Space v626_11 = routine_107(c, v626_6, p1, v623_7_tail);
          v624_12 = compose(v624_10,v626_11);
        }
        const Space v624_13 = unite(v624_8,v624_12);
        v623_7_result = unite(v623_7_result,v624_13);
      }
      const Space v623_7 = std::move(v623_7_result);
      v622_8 = compose(v622_5,v623_7);
    }
    const Space v622_9 = intersect(constant_3,v622_2);
    const Space v622_10 = (has_head(v622_9) ? constant_4 : Space{});
    const Space v622_11 = compose(v622_10,v621_9_tail);
    const Path v627_6 = concat_path(p0,v621_9_head);
    const Space v622_12 = wrap(v622_11,v627_6);
    const Space v622_13 = wrap(v622_12,p1);
    const Space v622_14 = unite(v622_8,v622_13);
    v621_9_result = unite(v621_9_result,v622_14);
  }
  const Space v621_9 = std::move(v621_9_result);
  return v621_9;
}

static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v628_13_result;
  for (int v628_13_label = 1; v628_13_label <= 2; ++v628_13_label) {
    const Space v628_13_tail = child(s0,v628_13_label);
    if (v628_13_tail.empty()) continue;
    const Path v628_13_head{v628_13_label};
    const Space v629_2 = singleton(v628_13_head);
    const Space v629_3 = intersect(constant_3,v629_2);
    const Space v629_4 = (has_head(v629_3) ? constant_4 : Space{});
    const Space v629_5 = subtract(constant_2,v629_4);
    Space v629_8;
    if (!v629_5.empty()) {
      const Path v630_6 = concat_path(p0,v628_13_head);
      Space v630_7_result;
      for (int v630_7_label = 1; v630_7_label <= 2; ++v630_7_label) {
        const Space v630_7_tail = child(v628_13_tail,v630_7_label);
        if (v630_7_tail.empty()) continue;
        const Path v630_7_head{v630_7_label};
        const Space v631_2 = singleton(v630_7_head);
        const Space v631_3 = intersect(constant_3,v631_2);
        const Space v631_4 = (has_head(v631_3) ? constant_4 : Space{});
        const Space v631_5 = subtract(constant_2,v631_4);
        Space v631_8;
        if (!v631_5.empty()) {
          const Path v632_6 = concat_path(v630_6,v630_7_head);
          const Space v632_7 = routine_108(c, v632_6, p1, v630_7_tail, s1);
          v631_8 = compose(v631_5,v632_7);
        }
        const Space v631_9 = intersect(constant_3,v631_2);
        const Space v631_10 = (has_head(v631_9) ? constant_4 : Space{});
        Space v631_12;
        if (!v631_10.empty()) {
          const Path v633_6 = concat_path(v630_6,v630_7_head);
          const Space v633_11 = routine_109(c, v633_6, p1, v630_7_tail, s1);
          v631_12 = compose(v631_10,v633_11);
        }
        const Space v631_13 = unite(v631_8,v631_12);
        v630_7_result = unite(v630_7_result,v631_13);
      }
      const Space v630_7 = std::move(v630_7_result);
      v629_8 = compose(v629_5,v630_7);
    }
    const Space v629_9 = intersect(constant_3,v629_2);
    const Space v629_10 = (has_head(v629_9) ? constant_4 : Space{});
    Space v629_12;
    if (!v629_10.empty()) {
      const Path v634_6 = concat_path(p0,v628_13_head);
      Space v634_11_result;
      for (int v634_11_label = 1; v634_11_label <= 2; ++v634_11_label) {
        const Space v634_11_tail = child(v628_13_tail,v634_11_label);
        if (v634_11_tail.empty()) continue;
        const Path v634_11_head{v634_11_label};
        const Space v635_2 = singleton(v634_11_head);
        const Space v635_3 = intersect(constant_3,v635_2);
        const Space v635_4 = (has_head(v635_3) ? constant_4 : Space{});
        const Space v635_5 = subtract(constant_2,v635_4);
        Space v635_8;
        if (!v635_5.empty()) {
          const Path v636_6 = concat_path(v634_6,v634_11_head);
          const Space v636_7 = routine_108(c, v636_6, p1, v634_11_tail, s1);
          v635_8 = compose(v635_5,v636_7);
        }
        const Space v635_9 = intersect(constant_3,v635_2);
        const Space v635_10 = (has_head(v635_9) ? constant_4 : Space{});
        Space v635_12;
        if (!v635_10.empty()) {
          const Path v637_6 = concat_path(v634_6,v634_11_head);
          const Space v637_11 = routine_29(c, v637_6, p1, v634_11_tail, s1);
          v635_12 = compose(v635_10,v637_11);
        }
        const Space v635_13 = unite(v635_8,v635_12);
        v634_11_result = unite(v634_11_result,v635_13);
      }
      const Space v634_11 = std::move(v634_11_result);
      v629_12 = compose(v629_10,v634_11);
    }
    const Space v629_13 = unite(v629_8,v629_12);
    v628_13_result = unite(v628_13_result,v629_13);
  }
  const Space v628_13 = std::move(v628_13_result);
  return v628_13;
}

static Space routine_64(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v638_8 = unwrap(s1,constant_5);
  const Space v638_10 = unwrap(v638_8,constant_6);
  const Space v638_11 = unwrap(v638_10,p0);
  Space v638_18_result;
  for (int v638_18_label = 1; v638_18_label <= 2; ++v638_18_label) {
    const Space v638_18_tail = child(s0,v638_18_label);
    if (v638_18_tail.empty()) continue;
    const Path v638_18_head{v638_18_label};
    const Space v639_2 = singleton(v638_18_head);
    const Space v639_3 = intersect(constant_3,v639_2);
    const Space v639_4 = (has_head(v639_3) ? constant_4 : Space{});
    const Space v639_5 = subtract(constant_2,v639_4);
    Space v639_8;
    if (!v639_5.empty()) {
      const Path v640_6 = concat_path(p0,v638_18_head);
      Space v640_7_result;
      for (int v640_7_label = 1; v640_7_label <= 2; ++v640_7_label) {
        const Space v640_7_tail = child(v638_18_tail,v640_7_label);
        if (v640_7_tail.empty()) continue;
        const Path v640_7_head{v640_7_label};
        const Space v641_2 = singleton(v640_7_head);
        const Space v641_3 = intersect(constant_3,v641_2);
        const Space v641_4 = (has_head(v641_3) ? constant_4 : Space{});
        const Space v641_5 = subtract(constant_2,v641_4);
        Space v641_8;
        if (!v641_5.empty()) {
          const Path v642_6 = concat_path(v640_6,v640_7_head);
          const Space v642_7 = routine_108(c, v642_6, p1, v640_7_tail, s1);
          v641_8 = compose(v641_5,v642_7);
        }
        const Space v641_9 = intersect(constant_3,v641_2);
        const Space v641_10 = (has_head(v641_9) ? constant_4 : Space{});
        Space v641_12;
        if (!v641_10.empty()) {
          const Path v643_6 = concat_path(v640_6,v640_7_head);
          const Space v643_11 = routine_109(c, v643_6, p1, v640_7_tail, s1);
          v641_12 = compose(v641_10,v643_11);
        }
        const Space v641_13 = unite(v641_8,v641_12);
        v640_7_result = unite(v640_7_result,v641_13);
      }
      const Space v640_7 = std::move(v640_7_result);
      v639_8 = compose(v639_5,v640_7);
    }
    const Space v639_9 = intersect(constant_3,v639_2);
    const Space v639_10 = (has_head(v639_9) ? constant_4 : Space{});
    Space v639_13;
    if (!v639_10.empty()) {
      const Space v644_11 = unwrap(v638_11,v638_18_head);
      Space v644_12_result;
      for (int v644_12_label = 1; v644_12_label <= 2; ++v644_12_label) {
        const Space v644_12_tail = child(v644_11,v644_12_label);
        if (v644_12_tail.empty()) continue;
        const Path v644_12_head{v644_12_label};
        const Space v645_2 = singleton(v644_12_head);
        const Space v645_3 = intersect(constant_3,v645_2);
        const Space v645_4 = (has_head(v645_3) ? constant_4 : Space{});
        const Space v645_5 = subtract(constant_2,v645_4);
        Space v645_7;
        if (!v645_5.empty()) {
          const Space v646_6 = routine_61(c, v644_12_head, p1, v644_12_tail);
          v645_7 = compose(v645_5,v646_6);
        }
        const Space v645_8 = intersect(constant_3,v645_2);
        const Space v645_9 = (has_head(v645_8) ? constant_4 : Space{});
        Space v645_11;
        if (!v645_9.empty()) {
          const Space v647_10 = routine_62(c, v644_12_head, p1, v644_12_tail);
          v645_11 = compose(v645_9,v647_10);
        }
        const Space v645_12 = unite(v645_7,v645_11);
        v644_12_result = unite(v644_12_result,v645_12);
      }
      const Space v644_12 = std::move(v644_12_result);
      v639_13 = compose(v639_10,v644_12);
    }
    const Space v639_14 = unite(v639_8,v639_13);
    v638_18_result = unite(v638_18_result,v639_14);
  }
  const Space v638_18 = std::move(v638_18_result);
  return v638_18;
}

static Space routine_65(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v648_12_result;
  for (int v648_12_label = 1; v648_12_label <= 2; ++v648_12_label) {
    const Space v648_12_tail = child(s0,v648_12_label);
    if (v648_12_tail.empty()) continue;
    const Path v648_12_head{v648_12_label};
    const Space v649_2 = singleton(v648_12_head);
    const Space v649_3 = intersect(constant_3,v649_2);
    const Space v649_4 = (has_head(v649_3) ? constant_4 : Space{});
    const Space v649_5 = subtract(constant_2,v649_4);
    Space v649_8;
    if (!v649_5.empty()) {
      const Path v650_6 = concat_path(p0,v648_12_head);
      Space v650_7_result;
      for (int v650_7_label = 1; v650_7_label <= 2; ++v650_7_label) {
        const Space v650_7_tail = child(v648_12_tail,v650_7_label);
        if (v650_7_tail.empty()) continue;
        const Path v650_7_head{v650_7_label};
        const Space v651_2 = singleton(v650_7_head);
        const Space v651_3 = intersect(constant_3,v651_2);
        const Space v651_4 = (has_head(v651_3) ? constant_4 : Space{});
        const Space v651_5 = subtract(constant_2,v651_4);
        Space v651_8;
        if (!v651_5.empty()) {
          const Path v652_6 = concat_path(v650_6,v650_7_head);
          const Space v652_7 = routine_110(c, v652_6, p1, v650_7_tail);
          v651_8 = compose(v651_5,v652_7);
        }
        const Space v651_9 = intersect(constant_3,v651_2);
        const Space v651_10 = (has_head(v651_9) ? constant_4 : Space{});
        Space v651_12;
        if (!v651_10.empty()) {
          const Path v653_6 = concat_path(v650_6,v650_7_head);
          const Space v653_11 = routine_111(c, v653_6, p1, v650_7_tail);
          v651_12 = compose(v651_10,v653_11);
        }
        const Space v651_13 = unite(v651_8,v651_12);
        v650_7_result = unite(v650_7_result,v651_13);
      }
      const Space v650_7 = std::move(v650_7_result);
      v649_8 = compose(v649_5,v650_7);
    }
    const Space v649_9 = intersect(constant_3,v649_2);
    const Space v649_10 = (has_head(v649_9) ? constant_4 : Space{});
    Space v649_12;
    if (!v649_10.empty()) {
      const Path v654_6 = concat_path(p0,v648_12_head);
      Space v654_11_result;
      for (int v654_11_label = 1; v654_11_label <= 2; ++v654_11_label) {
        const Space v654_11_tail = child(v648_12_tail,v654_11_label);
        if (v654_11_tail.empty()) continue;
        const Path v654_11_head{v654_11_label};
        const Space v655_2 = singleton(v654_11_head);
        const Space v655_3 = intersect(constant_3,v655_2);
        const Space v655_4 = (has_head(v655_3) ? constant_4 : Space{});
        const Space v655_5 = subtract(constant_2,v655_4);
        Space v655_8;
        if (!v655_5.empty()) {
          const Path v656_6 = concat_path(v654_6,v654_11_head);
          const Space v656_7 = routine_110(c, v656_6, p1, v654_11_tail);
          v655_8 = compose(v655_5,v656_7);
        }
        const Space v655_9 = intersect(constant_3,v655_2);
        const Space v655_10 = (has_head(v655_9) ? constant_4 : Space{});
        Space v655_12;
        if (!v655_10.empty()) {
          const Path v657_6 = concat_path(v654_6,v654_11_head);
          const Space v657_11 = routine_67(c, v657_6, p1, v654_11_tail);
          v655_12 = compose(v655_10,v657_11);
        }
        const Space v655_13 = unite(v655_8,v655_12);
        v654_11_result = unite(v654_11_result,v655_13);
      }
      const Space v654_11 = std::move(v654_11_result);
      v649_12 = compose(v649_10,v654_11);
    }
    const Space v649_13 = unite(v649_8,v649_12);
    v648_12_result = unite(v648_12_result,v649_13);
  }
  const Space v648_12 = std::move(v648_12_result);
  return v648_12;
}

static Space routine_66(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v658_9_result;
  for (int v658_9_label = 1; v658_9_label <= 2; ++v658_9_label) {
    const Space v658_9_tail = child(s0,v658_9_label);
    if (v658_9_tail.empty()) continue;
    const Path v658_9_head{v658_9_label};
    const Space v659_2 = singleton(v658_9_head);
    const Space v659_3 = intersect(constant_3,v659_2);
    const Space v659_4 = (has_head(v659_3) ? constant_4 : Space{});
    const Space v659_5 = subtract(constant_2,v659_4);
    Space v659_8;
    if (!v659_5.empty()) {
      const Path v660_6 = concat_path(p0,v658_9_head);
      Space v660_7_result;
      for (int v660_7_label = 1; v660_7_label <= 2; ++v660_7_label) {
        const Space v660_7_tail = child(v658_9_tail,v660_7_label);
        if (v660_7_tail.empty()) continue;
        const Path v660_7_head{v660_7_label};
        const Space v661_2 = singleton(v660_7_head);
        const Space v661_3 = intersect(constant_3,v661_2);
        const Space v661_4 = (has_head(v661_3) ? constant_4 : Space{});
        const Space v661_5 = subtract(constant_2,v661_4);
        Space v661_8;
        if (!v661_5.empty()) {
          const Path v662_6 = concat_path(v660_6,v660_7_head);
          const Space v662_7 = routine_110(c, v662_6, p1, v660_7_tail);
          v661_8 = compose(v661_5,v662_7);
        }
        const Space v661_9 = intersect(constant_3,v661_2);
        const Space v661_10 = (has_head(v661_9) ? constant_4 : Space{});
        Space v661_12;
        if (!v661_10.empty()) {
          const Path v663_6 = concat_path(v660_6,v660_7_head);
          const Space v663_11 = routine_111(c, v663_6, p1, v660_7_tail);
          v661_12 = compose(v661_10,v663_11);
        }
        const Space v661_13 = unite(v661_8,v661_12);
        v660_7_result = unite(v660_7_result,v661_13);
      }
      const Space v660_7 = std::move(v660_7_result);
      v659_8 = compose(v659_5,v660_7);
    }
    const Space v659_9 = intersect(constant_3,v659_2);
    const Space v659_10 = (has_head(v659_9) ? constant_4 : Space{});
    const Space v659_11 = compose(v659_10,v658_9_tail);
    const Path v664_6 = concat_path(p0,v658_9_head);
    const Space v659_12 = wrap(v659_11,v664_6);
    const Space v659_13 = wrap(v659_12,p1);
    const Space v659_14 = unite(v659_8,v659_13);
    v658_9_result = unite(v658_9_result,v659_14);
  }
  const Space v658_9 = std::move(v658_9_result);
  return v658_9;
}

static Space routine_67(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v665_3 = wrap(s0,p0);
  const Space v665_4 = wrap(v665_3,p1);
  return v665_4;
}

static Space routine_68(Context& c, const Path& p0, const Space& s0) {
  Space v666_11_result;
  for (int v666_11_label = 1; v666_11_label <= 2; ++v666_11_label) {
    const Space v666_11_tail = child(s0,v666_11_label);
    if (v666_11_tail.empty()) continue;
    const Path v666_11_head{v666_11_label};
    const Space v667_2 = singleton(v666_11_head);
    const Space v667_3 = intersect(constant_3,v667_2);
    const Space v667_4 = (has_head(v667_3) ? constant_4 : Space{});
    const Space v667_5 = subtract(constant_2,v667_4);
    Space v667_8;
    if (!v667_5.empty()) {
      const Path v668_6 = concat_path(p0,v666_11_head);
      Space v668_7_result;
      for (int v668_7_label = 1; v668_7_label <= 2; ++v668_7_label) {
        const Space v668_7_tail = child(v666_11_tail,v668_7_label);
        if (v668_7_tail.empty()) continue;
        const Path v668_7_head{v668_7_label};
        const Space v669_2 = singleton(v668_7_head);
        const Space v669_3 = intersect(constant_3,v669_2);
        const Space v669_4 = (has_head(v669_3) ? constant_4 : Space{});
        const Space v669_5 = subtract(constant_2,v669_4);
        Space v669_8;
        if (!v669_5.empty()) {
          const Path v670_6 = concat_path(v668_6,v668_7_head);
          const Space v670_7 = routine_112(c, v670_6, v668_7_tail);
          v669_8 = compose(v669_5,v670_7);
        }
        const Space v669_9 = intersect(constant_3,v669_2);
        const Space v669_10 = (has_head(v669_9) ? constant_4 : Space{});
        Space v669_12;
        if (!v669_10.empty()) {
          const Path v671_6 = concat_path(v668_6,v668_7_head);
          const Space v671_11 = routine_113(c, v671_6, v668_7_tail);
          v669_12 = compose(v669_10,v671_11);
        }
        const Space v669_13 = unite(v669_8,v669_12);
        v668_7_result = unite(v668_7_result,v669_13);
      }
      const Space v668_7 = std::move(v668_7_result);
      v667_8 = compose(v667_5,v668_7);
    }
    const Space v667_9 = intersect(constant_3,v667_2);
    const Space v667_10 = (has_head(v667_9) ? constant_4 : Space{});
    Space v667_12;
    if (!v667_10.empty()) {
      const Path v672_6 = concat_path(p0,v666_11_head);
      Space v672_11_result;
      for (int v672_11_label = 1; v672_11_label <= 2; ++v672_11_label) {
        const Space v672_11_tail = child(v666_11_tail,v672_11_label);
        if (v672_11_tail.empty()) continue;
        const Path v672_11_head{v672_11_label};
        const Space v673_2 = singleton(v672_11_head);
        const Space v673_3 = intersect(constant_3,v673_2);
        const Space v673_4 = (has_head(v673_3) ? constant_4 : Space{});
        const Space v673_5 = subtract(constant_2,v673_4);
        Space v673_8;
        if (!v673_5.empty()) {
          const Path v674_6 = concat_path(v672_6,v672_11_head);
          const Space v674_7 = routine_112(c, v674_6, v672_11_tail);
          v673_8 = compose(v673_5,v674_7);
        }
        const Space v673_9 = intersect(constant_3,v673_2);
        const Space v673_10 = (has_head(v673_9) ? constant_4 : Space{});
        Space v673_12;
        if (!v673_10.empty()) {
          const Path v675_6 = concat_path(v672_6,v672_11_head);
          const Space v675_11 = routine_9(c, v675_6, v672_11_tail);
          v673_12 = compose(v673_10,v675_11);
        }
        const Space v673_13 = unite(v673_8,v673_12);
        v672_11_result = unite(v672_11_result,v673_13);
      }
      const Space v672_11 = std::move(v672_11_result);
      v667_12 = compose(v667_10,v672_11);
    }
    const Space v667_13 = unite(v667_8,v667_12);
    v666_11_result = unite(v666_11_result,v667_13);
  }
  const Space v666_11 = std::move(v666_11_result);
  return v666_11;
}

static Space routine_69(Context& c, const Path& p0, const Space& s0) {
  Space v676_11_result;
  for (int v676_11_label = 1; v676_11_label <= 2; ++v676_11_label) {
    const Space v676_11_tail = child(s0,v676_11_label);
    if (v676_11_tail.empty()) continue;
    const Path v676_11_head{v676_11_label};
    const Space v677_2 = singleton(v676_11_head);
    const Space v677_3 = intersect(constant_3,v677_2);
    const Space v677_4 = (has_head(v677_3) ? constant_4 : Space{});
    const Space v677_5 = subtract(constant_2,v677_4);
    Space v677_8;
    if (!v677_5.empty()) {
      const Path v678_6 = concat_path(p0,v676_11_head);
      Space v678_7_result;
      for (int v678_7_label = 1; v678_7_label <= 2; ++v678_7_label) {
        const Space v678_7_tail = child(v676_11_tail,v678_7_label);
        if (v678_7_tail.empty()) continue;
        const Path v678_7_head{v678_7_label};
        const Space v679_2 = singleton(v678_7_head);
        const Space v679_3 = intersect(constant_3,v679_2);
        const Space v679_4 = (has_head(v679_3) ? constant_4 : Space{});
        const Space v679_5 = subtract(constant_2,v679_4);
        Space v679_8;
        if (!v679_5.empty()) {
          const Path v680_6 = concat_path(v678_6,v678_7_head);
          const Space v680_7 = routine_112(c, v680_6, v678_7_tail);
          v679_8 = compose(v679_5,v680_7);
        }
        const Space v679_9 = intersect(constant_3,v679_2);
        const Space v679_10 = (has_head(v679_9) ? constant_4 : Space{});
        Space v679_12;
        if (!v679_10.empty()) {
          const Path v681_6 = concat_path(v678_6,v678_7_head);
          const Space v681_11 = routine_113(c, v681_6, v678_7_tail);
          v679_12 = compose(v679_10,v681_11);
        }
        const Space v679_13 = unite(v679_8,v679_12);
        v678_7_result = unite(v678_7_result,v679_13);
      }
      const Space v678_7 = std::move(v678_7_result);
      v677_8 = compose(v677_5,v678_7);
    }
    const Space v677_9 = intersect(constant_3,v677_2);
    const Space v677_10 = (has_head(v677_9) ? constant_4 : Space{});
    Space v677_12;
    if (!v677_10.empty()) {
      const Path v682_6 = concat_path(p0,v676_11_head);
      Space v682_11_result;
      for (int v682_11_label = 1; v682_11_label <= 2; ++v682_11_label) {
        const Space v682_11_tail = child(v676_11_tail,v682_11_label);
        if (v682_11_tail.empty()) continue;
        const Path v682_11_head{v682_11_label};
        const Space v683_2 = singleton(v682_11_head);
        const Space v683_3 = intersect(constant_3,v683_2);
        const Space v683_4 = (has_head(v683_3) ? constant_4 : Space{});
        const Space v683_5 = subtract(constant_2,v683_4);
        Space v683_7;
        if (!v683_5.empty()) {
          const Space v684_6 = routine_32(c, v682_11_head, v682_6, v682_11_tail);
          v683_7 = compose(v683_5,v684_6);
        }
        const Space v683_8 = intersect(constant_3,v683_2);
        const Space v683_9 = (has_head(v683_8) ? constant_4 : Space{});
        Space v683_11;
        if (!v683_9.empty()) {
          const Space v685_10 = routine_33(c, v682_11_head, v682_6, v682_11_tail);
          v683_11 = compose(v683_9,v685_10);
        }
        const Space v683_12 = unite(v683_7,v683_11);
        v682_11_result = unite(v682_11_result,v683_12);
      }
      const Space v682_11 = std::move(v682_11_result);
      v677_12 = compose(v677_10,v682_11);
    }
    const Space v677_13 = unite(v677_8,v677_12);
    v676_11_result = unite(v676_11_result,v677_13);
  }
  const Space v676_11 = std::move(v676_11_result);
  return v676_11;
}

static Space routine_70(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v686_12_result;
  for (int v686_12_label = 1; v686_12_label <= 2; ++v686_12_label) {
    const Space v686_12_tail = child(s0,v686_12_label);
    if (v686_12_tail.empty()) continue;
    const Path v686_12_head{v686_12_label};
    const Space v687_2 = singleton(v686_12_head);
    const Space v687_3 = intersect(constant_3,v687_2);
    const Space v687_4 = (has_head(v687_3) ? constant_4 : Space{});
    const Space v687_5 = subtract(constant_2,v687_4);
    Space v687_8;
    if (!v687_5.empty()) {
      const Path v688_6 = concat_path(p0,v686_12_head);
      Space v688_7_result;
      for (int v688_7_label = 1; v688_7_label <= 2; ++v688_7_label) {
        const Space v688_7_tail = child(v686_12_tail,v688_7_label);
        if (v688_7_tail.empty()) continue;
        const Path v688_7_head{v688_7_label};
        const Space v689_2 = singleton(v688_7_head);
        const Space v689_3 = intersect(constant_3,v689_2);
        const Space v689_4 = (has_head(v689_3) ? constant_4 : Space{});
        const Space v689_5 = subtract(constant_2,v689_4);
        Space v689_8;
        if (!v689_5.empty()) {
          const Path v690_6 = concat_path(v688_6,v688_7_head);
          const Space v690_7 = routine_114(c, v690_6, p1, v688_7_tail);
          v689_8 = compose(v689_5,v690_7);
        }
        const Space v689_9 = intersect(constant_3,v689_2);
        const Space v689_10 = (has_head(v689_9) ? constant_4 : Space{});
        Space v689_12;
        if (!v689_10.empty()) {
          const Path v691_6 = concat_path(v688_6,v688_7_head);
          const Space v691_11 = routine_115(c, v691_6, p1, v688_7_tail);
          v689_12 = compose(v689_10,v691_11);
        }
        const Space v689_13 = unite(v689_8,v689_12);
        v688_7_result = unite(v688_7_result,v689_13);
      }
      const Space v688_7 = std::move(v688_7_result);
      v687_8 = compose(v687_5,v688_7);
    }
    const Space v687_9 = intersect(constant_3,v687_2);
    const Space v687_10 = (has_head(v687_9) ? constant_4 : Space{});
    Space v687_12;
    if (!v687_10.empty()) {
      const Path v692_6 = concat_path(p0,v686_12_head);
      Space v692_11_result;
      for (int v692_11_label = 1; v692_11_label <= 2; ++v692_11_label) {
        const Space v692_11_tail = child(v686_12_tail,v692_11_label);
        if (v692_11_tail.empty()) continue;
        const Path v692_11_head{v692_11_label};
        const Space v693_2 = singleton(v692_11_head);
        const Space v693_3 = intersect(constant_3,v693_2);
        const Space v693_4 = (has_head(v693_3) ? constant_4 : Space{});
        const Space v693_5 = subtract(constant_2,v693_4);
        Space v693_8;
        if (!v693_5.empty()) {
          const Path v694_6 = concat_path(v692_6,v692_11_head);
          const Space v694_7 = routine_114(c, v694_6, p1, v692_11_tail);
          v693_8 = compose(v693_5,v694_7);
        }
        const Space v693_9 = intersect(constant_3,v693_2);
        const Space v693_10 = (has_head(v693_9) ? constant_4 : Space{});
        Space v693_12;
        if (!v693_10.empty()) {
          const Path v695_6 = concat_path(v692_6,v692_11_head);
          const Space v695_11 = routine_36(c, v695_6, p1, v692_11_tail);
          v693_12 = compose(v693_10,v695_11);
        }
        const Space v693_13 = unite(v693_8,v693_12);
        v692_11_result = unite(v692_11_result,v693_13);
      }
      const Space v692_11 = std::move(v692_11_result);
      v687_12 = compose(v687_10,v692_11);
    }
    const Space v687_13 = unite(v687_8,v687_12);
    v686_12_result = unite(v686_12_result,v687_13);
  }
  const Space v686_12 = std::move(v686_12_result);
  return v686_12;
}

static Space routine_71(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v696_9_result;
  for (int v696_9_label = 1; v696_9_label <= 2; ++v696_9_label) {
    const Space v696_9_tail = child(s0,v696_9_label);
    if (v696_9_tail.empty()) continue;
    const Path v696_9_head{v696_9_label};
    const Space v697_2 = singleton(v696_9_head);
    const Space v697_3 = intersect(constant_3,v697_2);
    const Space v697_4 = (has_head(v697_3) ? constant_4 : Space{});
    const Space v697_5 = subtract(constant_2,v697_4);
    Space v697_8;
    if (!v697_5.empty()) {
      const Path v698_6 = concat_path(p0,v696_9_head);
      Space v698_7_result;
      for (int v698_7_label = 1; v698_7_label <= 2; ++v698_7_label) {
        const Space v698_7_tail = child(v696_9_tail,v698_7_label);
        if (v698_7_tail.empty()) continue;
        const Path v698_7_head{v698_7_label};
        const Space v699_2 = singleton(v698_7_head);
        const Space v699_3 = intersect(constant_3,v699_2);
        const Space v699_4 = (has_head(v699_3) ? constant_4 : Space{});
        const Space v699_5 = subtract(constant_2,v699_4);
        Space v699_8;
        if (!v699_5.empty()) {
          const Path v700_6 = concat_path(v698_6,v698_7_head);
          const Space v700_7 = routine_114(c, v700_6, p1, v698_7_tail);
          v699_8 = compose(v699_5,v700_7);
        }
        const Space v699_9 = intersect(constant_3,v699_2);
        const Space v699_10 = (has_head(v699_9) ? constant_4 : Space{});
        Space v699_12;
        if (!v699_10.empty()) {
          const Path v701_6 = concat_path(v698_6,v698_7_head);
          const Space v701_11 = routine_115(c, v701_6, p1, v698_7_tail);
          v699_12 = compose(v699_10,v701_11);
        }
        const Space v699_13 = unite(v699_8,v699_12);
        v698_7_result = unite(v698_7_result,v699_13);
      }
      const Space v698_7 = std::move(v698_7_result);
      v697_8 = compose(v697_5,v698_7);
    }
    const Space v697_9 = intersect(constant_3,v697_2);
    const Space v697_10 = (has_head(v697_9) ? constant_4 : Space{});
    const Space v697_11 = compose(v697_10,v696_9_tail);
    const Path v702_6 = concat_path(p0,v696_9_head);
    const Space v697_12 = wrap(v697_11,v702_6);
    const Space v697_13 = wrap(v697_12,p1);
    const Space v697_14 = unite(v697_8,v697_13);
    v696_9_result = unite(v696_9_result,v697_14);
  }
  const Space v696_9 = std::move(v696_9_result);
  return v696_9;
}

static Space routine_72(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v703_12_result;
  for (int v703_12_label = 1; v703_12_label <= 2; ++v703_12_label) {
    const Space v703_12_tail = child(s0,v703_12_label);
    if (v703_12_tail.empty()) continue;
    const Path v703_12_head{v703_12_label};
    const Space v704_2 = singleton(v703_12_head);
    const Space v704_3 = intersect(constant_3,v704_2);
    const Space v704_4 = (has_head(v704_3) ? constant_4 : Space{});
    const Space v704_5 = subtract(constant_2,v704_4);
    Space v704_8;
    if (!v704_5.empty()) {
      const Path v705_6 = concat_path(p0,v703_12_head);
      Space v705_7_result;
      for (int v705_7_label = 1; v705_7_label <= 2; ++v705_7_label) {
        const Space v705_7_tail = child(v703_12_tail,v705_7_label);
        if (v705_7_tail.empty()) continue;
        const Path v705_7_head{v705_7_label};
        const Space v706_2 = singleton(v705_7_head);
        const Space v706_3 = intersect(constant_3,v706_2);
        const Space v706_4 = (has_head(v706_3) ? constant_4 : Space{});
        const Space v706_5 = subtract(constant_2,v706_4);
        Space v706_8;
        if (!v706_5.empty()) {
          const Path v707_6 = concat_path(v705_6,v705_7_head);
          const Space v707_7 = routine_116(c, v707_6, p1, v705_7_tail);
          v706_8 = compose(v706_5,v707_7);
        }
        const Space v706_9 = intersect(constant_3,v706_2);
        const Space v706_10 = (has_head(v706_9) ? constant_4 : Space{});
        Space v706_12;
        if (!v706_10.empty()) {
          const Path v708_6 = concat_path(v705_6,v705_7_head);
          const Space v708_11 = routine_117(c, v708_6, p1, v705_7_tail);
          v706_12 = compose(v706_10,v708_11);
        }
        const Space v706_13 = unite(v706_8,v706_12);
        v705_7_result = unite(v705_7_result,v706_13);
      }
      const Space v705_7 = std::move(v705_7_result);
      v704_8 = compose(v704_5,v705_7);
    }
    const Space v704_9 = intersect(constant_3,v704_2);
    const Space v704_10 = (has_head(v704_9) ? constant_4 : Space{});
    Space v704_12;
    if (!v704_10.empty()) {
      const Path v709_6 = concat_path(p0,v703_12_head);
      Space v709_11_result;
      for (int v709_11_label = 1; v709_11_label <= 2; ++v709_11_label) {
        const Space v709_11_tail = child(v703_12_tail,v709_11_label);
        if (v709_11_tail.empty()) continue;
        const Path v709_11_head{v709_11_label};
        const Space v710_2 = singleton(v709_11_head);
        const Space v710_3 = intersect(constant_3,v710_2);
        const Space v710_4 = (has_head(v710_3) ? constant_4 : Space{});
        const Space v710_5 = subtract(constant_2,v710_4);
        Space v710_8;
        if (!v710_5.empty()) {
          const Path v711_6 = concat_path(v709_6,v709_11_head);
          const Space v711_7 = routine_116(c, v711_6, p1, v709_11_tail);
          v710_8 = compose(v710_5,v711_7);
        }
        const Space v710_9 = intersect(constant_3,v710_2);
        const Space v710_10 = (has_head(v710_9) ? constant_4 : Space{});
        Space v710_12;
        if (!v710_10.empty()) {
          const Path v712_6 = concat_path(v709_6,v709_11_head);
          const Space v712_11 = routine_36(c, v712_6, p1, v709_11_tail);
          v710_12 = compose(v710_10,v712_11);
        }
        const Space v710_13 = unite(v710_8,v710_12);
        v709_11_result = unite(v709_11_result,v710_13);
      }
      const Space v709_11 = std::move(v709_11_result);
      v704_12 = compose(v704_10,v709_11);
    }
    const Space v704_13 = unite(v704_8,v704_12);
    v703_12_result = unite(v703_12_result,v704_13);
  }
  const Space v703_12 = std::move(v703_12_result);
  return v703_12;
}

static Space routine_73(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v713_9_result;
  for (int v713_9_label = 1; v713_9_label <= 2; ++v713_9_label) {
    const Space v713_9_tail = child(s0,v713_9_label);
    if (v713_9_tail.empty()) continue;
    const Path v713_9_head{v713_9_label};
    const Space v714_2 = singleton(v713_9_head);
    const Space v714_3 = intersect(constant_3,v714_2);
    const Space v714_4 = (has_head(v714_3) ? constant_4 : Space{});
    const Space v714_5 = subtract(constant_2,v714_4);
    Space v714_8;
    if (!v714_5.empty()) {
      const Path v715_6 = concat_path(p0,v713_9_head);
      Space v715_7_result;
      for (int v715_7_label = 1; v715_7_label <= 2; ++v715_7_label) {
        const Space v715_7_tail = child(v713_9_tail,v715_7_label);
        if (v715_7_tail.empty()) continue;
        const Path v715_7_head{v715_7_label};
        const Space v716_2 = singleton(v715_7_head);
        const Space v716_3 = intersect(constant_3,v716_2);
        const Space v716_4 = (has_head(v716_3) ? constant_4 : Space{});
        const Space v716_5 = subtract(constant_2,v716_4);
        Space v716_8;
        if (!v716_5.empty()) {
          const Path v717_6 = concat_path(v715_6,v715_7_head);
          const Space v717_7 = routine_116(c, v717_6, p1, v715_7_tail);
          v716_8 = compose(v716_5,v717_7);
        }
        const Space v716_9 = intersect(constant_3,v716_2);
        const Space v716_10 = (has_head(v716_9) ? constant_4 : Space{});
        Space v716_12;
        if (!v716_10.empty()) {
          const Path v718_6 = concat_path(v715_6,v715_7_head);
          const Space v718_11 = routine_117(c, v718_6, p1, v715_7_tail);
          v716_12 = compose(v716_10,v718_11);
        }
        const Space v716_13 = unite(v716_8,v716_12);
        v715_7_result = unite(v715_7_result,v716_13);
      }
      const Space v715_7 = std::move(v715_7_result);
      v714_8 = compose(v714_5,v715_7);
    }
    const Space v714_9 = intersect(constant_3,v714_2);
    const Space v714_10 = (has_head(v714_9) ? constant_4 : Space{});
    const Space v714_11 = compose(v714_10,v713_9_tail);
    const Path v719_6 = concat_path(p0,v713_9_head);
    const Space v714_12 = wrap(v714_11,v719_6);
    const Space v714_13 = wrap(v714_12,p1);
    const Space v714_14 = unite(v714_8,v714_13);
    v713_9_result = unite(v713_9_result,v714_14);
  }
  const Space v713_9 = std::move(v713_9_result);
  return v713_9;
}

static Space routine_74(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v720_12_result;
  for (int v720_12_label = 1; v720_12_label <= 2; ++v720_12_label) {
    const Space v720_12_tail = child(s0,v720_12_label);
    if (v720_12_tail.empty()) continue;
    const Path v720_12_head{v720_12_label};
    const Space v721_2 = singleton(v720_12_head);
    const Space v721_3 = intersect(constant_3,v721_2);
    const Space v721_4 = (has_head(v721_3) ? constant_4 : Space{});
    const Space v721_5 = subtract(constant_2,v721_4);
    Space v721_8;
    if (!v721_5.empty()) {
      const Path v722_6 = concat_path(p0,v720_12_head);
      Space v722_7_result;
      for (int v722_7_label = 1; v722_7_label <= 2; ++v722_7_label) {
        const Space v722_7_tail = child(v720_12_tail,v722_7_label);
        if (v722_7_tail.empty()) continue;
        const Path v722_7_head{v722_7_label};
        const Space v723_2 = singleton(v722_7_head);
        const Space v723_3 = intersect(constant_3,v723_2);
        const Space v723_4 = (has_head(v723_3) ? constant_4 : Space{});
        const Space v723_5 = subtract(constant_2,v723_4);
        Space v723_8;
        if (!v723_5.empty()) {
          const Path v724_6 = concat_path(v722_6,v722_7_head);
          const Space v724_7 = routine_118(c, v724_6, v722_7_tail, s1);
          v723_8 = compose(v723_5,v724_7);
        }
        const Space v723_9 = intersect(constant_3,v723_2);
        const Space v723_10 = (has_head(v723_9) ? constant_4 : Space{});
        Space v723_12;
        if (!v723_10.empty()) {
          const Path v725_6 = concat_path(v722_6,v722_7_head);
          const Space v725_11 = routine_119(c, v725_6, v722_7_tail, s1);
          v723_12 = compose(v723_10,v725_11);
        }
        const Space v723_13 = unite(v723_8,v723_12);
        v722_7_result = unite(v722_7_result,v723_13);
      }
      const Space v722_7 = std::move(v722_7_result);
      v721_8 = compose(v721_5,v722_7);
    }
    const Space v721_9 = intersect(constant_3,v721_2);
    const Space v721_10 = (has_head(v721_9) ? constant_4 : Space{});
    Space v721_12;
    if (!v721_10.empty()) {
      const Path v726_6 = concat_path(p0,v720_12_head);
      Space v726_11_result;
      for (int v726_11_label = 1; v726_11_label <= 2; ++v726_11_label) {
        const Space v726_11_tail = child(v720_12_tail,v726_11_label);
        if (v726_11_tail.empty()) continue;
        const Path v726_11_head{v726_11_label};
        const Space v727_2 = singleton(v726_11_head);
        const Space v727_3 = intersect(constant_3,v727_2);
        const Space v727_4 = (has_head(v727_3) ? constant_4 : Space{});
        const Space v727_5 = subtract(constant_2,v727_4);
        Space v727_8;
        if (!v727_5.empty()) {
          const Path v728_6 = concat_path(v726_6,v726_11_head);
          const Space v728_7 = routine_118(c, v728_6, v726_11_tail, s1);
          v727_8 = compose(v727_5,v728_7);
        }
        const Space v727_9 = intersect(constant_3,v727_2);
        const Space v727_10 = (has_head(v727_9) ? constant_4 : Space{});
        Space v727_12;
        if (!v727_10.empty()) {
          const Path v729_6 = concat_path(v726_6,v726_11_head);
          const Space v729_11 = routine_12(c, v729_6, v726_11_tail, s1);
          v727_12 = compose(v727_10,v729_11);
        }
        const Space v727_13 = unite(v727_8,v727_12);
        v726_11_result = unite(v726_11_result,v727_13);
      }
      const Space v726_11 = std::move(v726_11_result);
      v721_12 = compose(v721_10,v726_11);
    }
    const Space v721_13 = unite(v721_8,v721_12);
    v720_12_result = unite(v720_12_result,v721_13);
  }
  const Space v720_12 = std::move(v720_12_result);
  return v720_12;
}

static Space routine_75(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v730_12_result;
  for (int v730_12_label = 1; v730_12_label <= 2; ++v730_12_label) {
    const Space v730_12_tail = child(s0,v730_12_label);
    if (v730_12_tail.empty()) continue;
    const Path v730_12_head{v730_12_label};
    const Space v731_2 = singleton(v730_12_head);
    const Space v731_3 = intersect(constant_3,v731_2);
    const Space v731_4 = (has_head(v731_3) ? constant_4 : Space{});
    const Space v731_5 = subtract(constant_2,v731_4);
    Space v731_8;
    if (!v731_5.empty()) {
      const Path v732_6 = concat_path(p0,v730_12_head);
      Space v732_7_result;
      for (int v732_7_label = 1; v732_7_label <= 2; ++v732_7_label) {
        const Space v732_7_tail = child(v730_12_tail,v732_7_label);
        if (v732_7_tail.empty()) continue;
        const Path v732_7_head{v732_7_label};
        const Space v733_2 = singleton(v732_7_head);
        const Space v733_3 = intersect(constant_3,v733_2);
        const Space v733_4 = (has_head(v733_3) ? constant_4 : Space{});
        const Space v733_5 = subtract(constant_2,v733_4);
        Space v733_8;
        if (!v733_5.empty()) {
          const Path v734_6 = concat_path(v732_6,v732_7_head);
          const Space v734_7 = routine_118(c, v734_6, v732_7_tail, s1);
          v733_8 = compose(v733_5,v734_7);
        }
        const Space v733_9 = intersect(constant_3,v733_2);
        const Space v733_10 = (has_head(v733_9) ? constant_4 : Space{});
        Space v733_12;
        if (!v733_10.empty()) {
          const Path v735_6 = concat_path(v732_6,v732_7_head);
          const Space v735_11 = routine_119(c, v735_6, v732_7_tail, s1);
          v733_12 = compose(v733_10,v735_11);
        }
        const Space v733_13 = unite(v733_8,v733_12);
        v732_7_result = unite(v732_7_result,v733_13);
      }
      const Space v732_7 = std::move(v732_7_result);
      v731_8 = compose(v731_5,v732_7);
    }
    const Space v731_9 = intersect(constant_3,v731_2);
    const Space v731_10 = (has_head(v731_9) ? constant_4 : Space{});
    Space v731_12;
    if (!v731_10.empty()) {
      const Path v736_6 = concat_path(p0,v730_12_head);
      Space v736_11_result;
      for (int v736_11_label = 1; v736_11_label <= 2; ++v736_11_label) {
        const Space v736_11_tail = child(v730_12_tail,v736_11_label);
        if (v736_11_tail.empty()) continue;
        const Path v736_11_head{v736_11_label};
        const Space v737_2 = singleton(v736_11_head);
        const Space v737_3 = intersect(constant_3,v737_2);
        const Space v737_4 = (has_head(v737_3) ? constant_4 : Space{});
        const Space v737_5 = subtract(constant_2,v737_4);
        Space v737_7;
        if (!v737_5.empty()) {
          const Space v738_6 = routine_39(c, v736_11_head, v736_6, v736_11_tail, s1);
          v737_7 = compose(v737_5,v738_6);
        }
        const Space v737_8 = intersect(constant_3,v737_2);
        const Space v737_9 = (has_head(v737_8) ? constant_4 : Space{});
        Space v737_11;
        if (!v737_9.empty()) {
          const Space v739_10 = routine_40(c, v736_11_head, v736_6, v736_11_tail, s1);
          v737_11 = compose(v737_9,v739_10);
        }
        const Space v737_12 = unite(v737_7,v737_11);
        v736_11_result = unite(v736_11_result,v737_12);
      }
      const Space v736_11 = std::move(v736_11_result);
      v731_12 = compose(v731_10,v736_11);
    }
    const Space v731_13 = unite(v731_8,v731_12);
    v730_12_result = unite(v730_12_result,v731_13);
  }
  const Space v730_12 = std::move(v730_12_result);
  return v730_12;
}

static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v740_13_result;
  for (int v740_13_label = 1; v740_13_label <= 2; ++v740_13_label) {
    const Space v740_13_tail = child(s0,v740_13_label);
    if (v740_13_tail.empty()) continue;
    const Path v740_13_head{v740_13_label};
    const Space v741_2 = singleton(v740_13_head);
    const Space v741_3 = intersect(constant_3,v741_2);
    const Space v741_4 = (has_head(v741_3) ? constant_4 : Space{});
    const Space v741_5 = subtract(constant_2,v741_4);
    Space v741_8;
    if (!v741_5.empty()) {
      const Path v742_6 = concat_path(p0,v740_13_head);
      Space v742_7_result;
      for (int v742_7_label = 1; v742_7_label <= 2; ++v742_7_label) {
        const Space v742_7_tail = child(v740_13_tail,v742_7_label);
        if (v742_7_tail.empty()) continue;
        const Path v742_7_head{v742_7_label};
        const Space v743_2 = singleton(v742_7_head);
        const Space v743_3 = intersect(constant_3,v743_2);
        const Space v743_4 = (has_head(v743_3) ? constant_4 : Space{});
        const Space v743_5 = subtract(constant_2,v743_4);
        Space v743_8;
        if (!v743_5.empty()) {
          const Path v744_6 = concat_path(v742_6,v742_7_head);
          const Space v744_7 = routine_120(c, v744_6, p1, v742_7_tail, s1);
          v743_8 = compose(v743_5,v744_7);
        }
        const Space v743_9 = intersect(constant_3,v743_2);
        const Space v743_10 = (has_head(v743_9) ? constant_4 : Space{});
        Space v743_12;
        if (!v743_10.empty()) {
          const Path v745_6 = concat_path(v742_6,v742_7_head);
          const Space v745_11 = routine_121(c, v745_6, p1, v742_7_tail, s1);
          v743_12 = compose(v743_10,v745_11);
        }
        const Space v743_13 = unite(v743_8,v743_12);
        v742_7_result = unite(v742_7_result,v743_13);
      }
      const Space v742_7 = std::move(v742_7_result);
      v741_8 = compose(v741_5,v742_7);
    }
    const Space v741_9 = intersect(constant_3,v741_2);
    const Space v741_10 = (has_head(v741_9) ? constant_4 : Space{});
    Space v741_12;
    if (!v741_10.empty()) {
      const Path v746_6 = concat_path(p0,v740_13_head);
      Space v746_11_result;
      for (int v746_11_label = 1; v746_11_label <= 2; ++v746_11_label) {
        const Space v746_11_tail = child(v740_13_tail,v746_11_label);
        if (v746_11_tail.empty()) continue;
        const Path v746_11_head{v746_11_label};
        const Space v747_2 = singleton(v746_11_head);
        const Space v747_3 = intersect(constant_3,v747_2);
        const Space v747_4 = (has_head(v747_3) ? constant_4 : Space{});
        const Space v747_5 = subtract(constant_2,v747_4);
        Space v747_8;
        if (!v747_5.empty()) {
          const Path v748_6 = concat_path(v746_6,v746_11_head);
          const Space v748_7 = routine_120(c, v748_6, p1, v746_11_tail, s1);
          v747_8 = compose(v747_5,v748_7);
        }
        const Space v747_9 = intersect(constant_3,v747_2);
        const Space v747_10 = (has_head(v747_9) ? constant_4 : Space{});
        Space v747_12;
        if (!v747_10.empty()) {
          const Path v749_6 = concat_path(v746_6,v746_11_head);
          const Space v749_11 = routine_43(c, v749_6, p1, v746_11_tail, s1);
          v747_12 = compose(v747_10,v749_11);
        }
        const Space v747_13 = unite(v747_8,v747_12);
        v746_11_result = unite(v746_11_result,v747_13);
      }
      const Space v746_11 = std::move(v746_11_result);
      v741_12 = compose(v741_10,v746_11);
    }
    const Space v741_13 = unite(v741_8,v741_12);
    v740_13_result = unite(v740_13_result,v741_13);
  }
  const Space v740_13 = std::move(v740_13_result);
  return v740_13;
}

static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v750_8 = unwrap(s1,constant_0);
  const Space v750_10 = unwrap(v750_8,constant_6);
  const Space v750_11 = unwrap(v750_10,p0);
  Space v750_18_result;
  for (int v750_18_label = 1; v750_18_label <= 2; ++v750_18_label) {
    const Space v750_18_tail = child(s0,v750_18_label);
    if (v750_18_tail.empty()) continue;
    const Path v750_18_head{v750_18_label};
    const Space v751_2 = singleton(v750_18_head);
    const Space v751_3 = intersect(constant_3,v751_2);
    const Space v751_4 = (has_head(v751_3) ? constant_4 : Space{});
    const Space v751_5 = subtract(constant_2,v751_4);
    Space v751_8;
    if (!v751_5.empty()) {
      const Path v752_6 = concat_path(p0,v750_18_head);
      Space v752_7_result;
      for (int v752_7_label = 1; v752_7_label <= 2; ++v752_7_label) {
        const Space v752_7_tail = child(v750_18_tail,v752_7_label);
        if (v752_7_tail.empty()) continue;
        const Path v752_7_head{v752_7_label};
        const Space v753_2 = singleton(v752_7_head);
        const Space v753_3 = intersect(constant_3,v753_2);
        const Space v753_4 = (has_head(v753_3) ? constant_4 : Space{});
        const Space v753_5 = subtract(constant_2,v753_4);
        Space v753_8;
        if (!v753_5.empty()) {
          const Path v754_6 = concat_path(v752_6,v752_7_head);
          const Space v754_7 = routine_120(c, v754_6, p1, v752_7_tail, s1);
          v753_8 = compose(v753_5,v754_7);
        }
        const Space v753_9 = intersect(constant_3,v753_2);
        const Space v753_10 = (has_head(v753_9) ? constant_4 : Space{});
        Space v753_12;
        if (!v753_10.empty()) {
          const Path v755_6 = concat_path(v752_6,v752_7_head);
          const Space v755_11 = routine_121(c, v755_6, p1, v752_7_tail, s1);
          v753_12 = compose(v753_10,v755_11);
        }
        const Space v753_13 = unite(v753_8,v753_12);
        v752_7_result = unite(v752_7_result,v753_13);
      }
      const Space v752_7 = std::move(v752_7_result);
      v751_8 = compose(v751_5,v752_7);
    }
    const Space v751_9 = intersect(constant_3,v751_2);
    const Space v751_10 = (has_head(v751_9) ? constant_4 : Space{});
    Space v751_13;
    if (!v751_10.empty()) {
      const Space v756_11 = unwrap(v750_11,v750_18_head);
      Space v756_12_result;
      for (int v756_12_label = 1; v756_12_label <= 2; ++v756_12_label) {
        const Space v756_12_tail = child(v756_11,v756_12_label);
        if (v756_12_tail.empty()) continue;
        const Path v756_12_head{v756_12_label};
        const Space v757_2 = singleton(v756_12_head);
        const Space v757_3 = intersect(constant_3,v757_2);
        const Space v757_4 = (has_head(v757_3) ? constant_4 : Space{});
        const Space v757_5 = subtract(constant_2,v757_4);
        Space v757_7;
        if (!v757_5.empty()) {
          const Space v758_6 = routine_78(c, v756_12_head, p1, v756_12_tail);
          v757_7 = compose(v757_5,v758_6);
        }
        const Space v757_8 = intersect(constant_3,v757_2);
        const Space v757_9 = (has_head(v757_8) ? constant_4 : Space{});
        Space v757_11;
        if (!v757_9.empty()) {
          const Space v759_10 = routine_79(c, v756_12_head, p1, v756_12_tail);
          v757_11 = compose(v757_9,v759_10);
        }
        const Space v757_12 = unite(v757_7,v757_11);
        v756_12_result = unite(v756_12_result,v757_12);
      }
      const Space v756_12 = std::move(v756_12_result);
      v751_13 = compose(v751_10,v756_12);
    }
    const Space v751_14 = unite(v751_8,v751_13);
    v750_18_result = unite(v750_18_result,v751_14);
  }
  const Space v750_18 = std::move(v750_18_result);
  return v750_18;
}

static Space routine_78(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v760_12_result;
  for (int v760_12_label = 1; v760_12_label <= 2; ++v760_12_label) {
    const Space v760_12_tail = child(s0,v760_12_label);
    if (v760_12_tail.empty()) continue;
    const Path v760_12_head{v760_12_label};
    const Space v761_2 = singleton(v760_12_head);
    const Space v761_3 = intersect(constant_3,v761_2);
    const Space v761_4 = (has_head(v761_3) ? constant_4 : Space{});
    const Space v761_5 = subtract(constant_2,v761_4);
    Space v761_8;
    if (!v761_5.empty()) {
      const Path v762_6 = concat_path(p0,v760_12_head);
      Space v762_7_result;
      for (int v762_7_label = 1; v762_7_label <= 2; ++v762_7_label) {
        const Space v762_7_tail = child(v760_12_tail,v762_7_label);
        if (v762_7_tail.empty()) continue;
        const Path v762_7_head{v762_7_label};
        const Space v763_2 = singleton(v762_7_head);
        const Space v763_3 = intersect(constant_3,v763_2);
        const Space v763_4 = (has_head(v763_3) ? constant_4 : Space{});
        const Space v763_5 = subtract(constant_2,v763_4);
        Space v763_8;
        if (!v763_5.empty()) {
          const Path v764_6 = concat_path(v762_6,v762_7_head);
          const Space v764_7 = routine_122(c, v764_6, p1, v762_7_tail);
          v763_8 = compose(v763_5,v764_7);
        }
        const Space v763_9 = intersect(constant_3,v763_2);
        const Space v763_10 = (has_head(v763_9) ? constant_4 : Space{});
        Space v763_12;
        if (!v763_10.empty()) {
          const Path v765_6 = concat_path(v762_6,v762_7_head);
          const Space v765_11 = routine_123(c, v765_6, p1, v762_7_tail);
          v763_12 = compose(v763_10,v765_11);
        }
        const Space v763_13 = unite(v763_8,v763_12);
        v762_7_result = unite(v762_7_result,v763_13);
      }
      const Space v762_7 = std::move(v762_7_result);
      v761_8 = compose(v761_5,v762_7);
    }
    const Space v761_9 = intersect(constant_3,v761_2);
    const Space v761_10 = (has_head(v761_9) ? constant_4 : Space{});
    Space v761_12;
    if (!v761_10.empty()) {
      const Path v766_6 = concat_path(p0,v760_12_head);
      Space v766_11_result;
      for (int v766_11_label = 1; v766_11_label <= 2; ++v766_11_label) {
        const Space v766_11_tail = child(v760_12_tail,v766_11_label);
        if (v766_11_tail.empty()) continue;
        const Path v766_11_head{v766_11_label};
        const Space v767_2 = singleton(v766_11_head);
        const Space v767_3 = intersect(constant_3,v767_2);
        const Space v767_4 = (has_head(v767_3) ? constant_4 : Space{});
        const Space v767_5 = subtract(constant_2,v767_4);
        Space v767_8;
        if (!v767_5.empty()) {
          const Path v768_6 = concat_path(v766_6,v766_11_head);
          const Space v768_7 = routine_122(c, v768_6, p1, v766_11_tail);
          v767_8 = compose(v767_5,v768_7);
        }
        const Space v767_9 = intersect(constant_3,v767_2);
        const Space v767_10 = (has_head(v767_9) ? constant_4 : Space{});
        Space v767_12;
        if (!v767_10.empty()) {
          const Path v769_6 = concat_path(v766_6,v766_11_head);
          const Space v769_11 = routine_84(c, v769_6, p1, v766_11_tail);
          v767_12 = compose(v767_10,v769_11);
        }
        const Space v767_13 = unite(v767_8,v767_12);
        v766_11_result = unite(v766_11_result,v767_13);
      }
      const Space v766_11 = std::move(v766_11_result);
      v761_12 = compose(v761_10,v766_11);
    }
    const Space v761_13 = unite(v761_8,v761_12);
    v760_12_result = unite(v760_12_result,v761_13);
  }
  const Space v760_12 = std::move(v760_12_result);
  return v760_12;
}

static Space routine_79(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v770_9_result;
  for (int v770_9_label = 1; v770_9_label <= 2; ++v770_9_label) {
    const Space v770_9_tail = child(s0,v770_9_label);
    if (v770_9_tail.empty()) continue;
    const Path v770_9_head{v770_9_label};
    const Space v771_2 = singleton(v770_9_head);
    const Space v771_3 = intersect(constant_3,v771_2);
    const Space v771_4 = (has_head(v771_3) ? constant_4 : Space{});
    const Space v771_5 = subtract(constant_2,v771_4);
    Space v771_8;
    if (!v771_5.empty()) {
      const Path v772_6 = concat_path(p0,v770_9_head);
      Space v772_7_result;
      for (int v772_7_label = 1; v772_7_label <= 2; ++v772_7_label) {
        const Space v772_7_tail = child(v770_9_tail,v772_7_label);
        if (v772_7_tail.empty()) continue;
        const Path v772_7_head{v772_7_label};
        const Space v773_2 = singleton(v772_7_head);
        const Space v773_3 = intersect(constant_3,v773_2);
        const Space v773_4 = (has_head(v773_3) ? constant_4 : Space{});
        const Space v773_5 = subtract(constant_2,v773_4);
        Space v773_8;
        if (!v773_5.empty()) {
          const Path v774_6 = concat_path(v772_6,v772_7_head);
          const Space v774_7 = routine_122(c, v774_6, p1, v772_7_tail);
          v773_8 = compose(v773_5,v774_7);
        }
        const Space v773_9 = intersect(constant_3,v773_2);
        const Space v773_10 = (has_head(v773_9) ? constant_4 : Space{});
        Space v773_12;
        if (!v773_10.empty()) {
          const Path v775_6 = concat_path(v772_6,v772_7_head);
          const Space v775_11 = routine_123(c, v775_6, p1, v772_7_tail);
          v773_12 = compose(v773_10,v775_11);
        }
        const Space v773_13 = unite(v773_8,v773_12);
        v772_7_result = unite(v772_7_result,v773_13);
      }
      const Space v772_7 = std::move(v772_7_result);
      v771_8 = compose(v771_5,v772_7);
    }
    const Space v771_9 = intersect(constant_3,v771_2);
    const Space v771_10 = (has_head(v771_9) ? constant_4 : Space{});
    const Space v771_11 = compose(v771_10,v770_9_tail);
    const Path v776_6 = concat_path(p0,v770_9_head);
    const Space v771_12 = wrap(v771_11,v776_6);
    const Space v771_13 = wrap(v771_12,p1);
    const Space v771_14 = unite(v771_8,v771_13);
    v770_9_result = unite(v770_9_result,v771_14);
  }
  const Space v770_9 = std::move(v770_9_result);
  return v770_9;
}

static Space routine_80(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v777_13_result;
  for (int v777_13_label = 1; v777_13_label <= 2; ++v777_13_label) {
    const Space v777_13_tail = child(s0,v777_13_label);
    if (v777_13_tail.empty()) continue;
    const Path v777_13_head{v777_13_label};
    const Space v778_2 = singleton(v777_13_head);
    const Space v778_3 = intersect(constant_3,v778_2);
    const Space v778_4 = (has_head(v778_3) ? constant_4 : Space{});
    const Space v778_5 = subtract(constant_2,v778_4);
    Space v778_8;
    if (!v778_5.empty()) {
      const Path v779_6 = concat_path(p0,v777_13_head);
      Space v779_7_result;
      for (int v779_7_label = 1; v779_7_label <= 2; ++v779_7_label) {
        const Space v779_7_tail = child(v777_13_tail,v779_7_label);
        if (v779_7_tail.empty()) continue;
        const Path v779_7_head{v779_7_label};
        const Space v780_2 = singleton(v779_7_head);
        const Space v780_3 = intersect(constant_3,v780_2);
        const Space v780_4 = (has_head(v780_3) ? constant_4 : Space{});
        const Space v780_5 = subtract(constant_2,v780_4);
        Space v780_8;
        if (!v780_5.empty()) {
          const Path v781_6 = concat_path(v779_6,v779_7_head);
          const Space v781_7 = routine_124(c, v781_6, p1, v779_7_tail, s1);
          v780_8 = compose(v780_5,v781_7);
        }
        const Space v780_9 = intersect(constant_3,v780_2);
        const Space v780_10 = (has_head(v780_9) ? constant_4 : Space{});
        Space v780_12;
        if (!v780_10.empty()) {
          const Path v782_6 = concat_path(v779_6,v779_7_head);
          const Space v782_11 = routine_125(c, v782_6, p1, v779_7_tail, s1);
          v780_12 = compose(v780_10,v782_11);
        }
        const Space v780_13 = unite(v780_8,v780_12);
        v779_7_result = unite(v779_7_result,v780_13);
      }
      const Space v779_7 = std::move(v779_7_result);
      v778_8 = compose(v778_5,v779_7);
    }
    const Space v778_9 = intersect(constant_3,v778_2);
    const Space v778_10 = (has_head(v778_9) ? constant_4 : Space{});
    Space v778_12;
    if (!v778_10.empty()) {
      const Path v783_6 = concat_path(p0,v777_13_head);
      Space v783_11_result;
      for (int v783_11_label = 1; v783_11_label <= 2; ++v783_11_label) {
        const Space v783_11_tail = child(v777_13_tail,v783_11_label);
        if (v783_11_tail.empty()) continue;
        const Path v783_11_head{v783_11_label};
        const Space v784_2 = singleton(v783_11_head);
        const Space v784_3 = intersect(constant_3,v784_2);
        const Space v784_4 = (has_head(v784_3) ? constant_4 : Space{});
        const Space v784_5 = subtract(constant_2,v784_4);
        Space v784_8;
        if (!v784_5.empty()) {
          const Path v785_6 = concat_path(v783_6,v783_11_head);
          const Space v785_7 = routine_124(c, v785_6, p1, v783_11_tail, s1);
          v784_8 = compose(v784_5,v785_7);
        }
        const Space v784_9 = intersect(constant_3,v784_2);
        const Space v784_10 = (has_head(v784_9) ? constant_4 : Space{});
        Space v784_12;
        if (!v784_10.empty()) {
          const Path v786_6 = concat_path(v783_6,v783_11_head);
          const Space v786_11 = routine_43(c, v786_6, p1, v783_11_tail, s1);
          v784_12 = compose(v784_10,v786_11);
        }
        const Space v784_13 = unite(v784_8,v784_12);
        v783_11_result = unite(v783_11_result,v784_13);
      }
      const Space v783_11 = std::move(v783_11_result);
      v778_12 = compose(v778_10,v783_11);
    }
    const Space v778_13 = unite(v778_8,v778_12);
    v777_13_result = unite(v777_13_result,v778_13);
  }
  const Space v777_13 = std::move(v777_13_result);
  return v777_13;
}

static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v787_8 = unwrap(s1,constant_0);
  const Space v787_10 = unwrap(v787_8,constant_6);
  const Space v787_11 = unwrap(v787_10,p0);
  Space v787_18_result;
  for (int v787_18_label = 1; v787_18_label <= 2; ++v787_18_label) {
    const Space v787_18_tail = child(s0,v787_18_label);
    if (v787_18_tail.empty()) continue;
    const Path v787_18_head{v787_18_label};
    const Space v788_2 = singleton(v787_18_head);
    const Space v788_3 = intersect(constant_3,v788_2);
    const Space v788_4 = (has_head(v788_3) ? constant_4 : Space{});
    const Space v788_5 = subtract(constant_2,v788_4);
    Space v788_8;
    if (!v788_5.empty()) {
      const Path v789_6 = concat_path(p0,v787_18_head);
      Space v789_7_result;
      for (int v789_7_label = 1; v789_7_label <= 2; ++v789_7_label) {
        const Space v789_7_tail = child(v787_18_tail,v789_7_label);
        if (v789_7_tail.empty()) continue;
        const Path v789_7_head{v789_7_label};
        const Space v790_2 = singleton(v789_7_head);
        const Space v790_3 = intersect(constant_3,v790_2);
        const Space v790_4 = (has_head(v790_3) ? constant_4 : Space{});
        const Space v790_5 = subtract(constant_2,v790_4);
        Space v790_8;
        if (!v790_5.empty()) {
          const Path v791_6 = concat_path(v789_6,v789_7_head);
          const Space v791_7 = routine_124(c, v791_6, p1, v789_7_tail, s1);
          v790_8 = compose(v790_5,v791_7);
        }
        const Space v790_9 = intersect(constant_3,v790_2);
        const Space v790_10 = (has_head(v790_9) ? constant_4 : Space{});
        Space v790_12;
        if (!v790_10.empty()) {
          const Path v792_6 = concat_path(v789_6,v789_7_head);
          const Space v792_11 = routine_125(c, v792_6, p1, v789_7_tail, s1);
          v790_12 = compose(v790_10,v792_11);
        }
        const Space v790_13 = unite(v790_8,v790_12);
        v789_7_result = unite(v789_7_result,v790_13);
      }
      const Space v789_7 = std::move(v789_7_result);
      v788_8 = compose(v788_5,v789_7);
    }
    const Space v788_9 = intersect(constant_3,v788_2);
    const Space v788_10 = (has_head(v788_9) ? constant_4 : Space{});
    Space v788_13;
    if (!v788_10.empty()) {
      const Space v793_11 = unwrap(v787_11,v787_18_head);
      Space v793_12_result;
      for (int v793_12_label = 1; v793_12_label <= 2; ++v793_12_label) {
        const Space v793_12_tail = child(v793_11,v793_12_label);
        if (v793_12_tail.empty()) continue;
        const Path v793_12_head{v793_12_label};
        const Space v794_2 = singleton(v793_12_head);
        const Space v794_3 = intersect(constant_3,v794_2);
        const Space v794_4 = (has_head(v794_3) ? constant_4 : Space{});
        const Space v794_5 = subtract(constant_2,v794_4);
        Space v794_7;
        if (!v794_5.empty()) {
          const Space v795_6 = routine_78(c, v793_12_head, p1, v793_12_tail);
          v794_7 = compose(v794_5,v795_6);
        }
        const Space v794_8 = intersect(constant_3,v794_2);
        const Space v794_9 = (has_head(v794_8) ? constant_4 : Space{});
        Space v794_11;
        if (!v794_9.empty()) {
          const Space v796_10 = routine_79(c, v793_12_head, p1, v793_12_tail);
          v794_11 = compose(v794_9,v796_10);
        }
        const Space v794_12 = unite(v794_7,v794_11);
        v793_12_result = unite(v793_12_result,v794_12);
      }
      const Space v793_12 = std::move(v793_12_result);
      v788_13 = compose(v788_10,v793_12);
    }
    const Space v788_14 = unite(v788_8,v788_13);
    v787_18_result = unite(v787_18_result,v788_14);
  }
  const Space v787_18 = std::move(v787_18_result);
  return v787_18;
}

static Space routine_82(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v797_12_result;
  for (int v797_12_label = 1; v797_12_label <= 2; ++v797_12_label) {
    const Space v797_12_tail = child(s0,v797_12_label);
    if (v797_12_tail.empty()) continue;
    const Path v797_12_head{v797_12_label};
    const Space v798_2 = singleton(v797_12_head);
    const Space v798_3 = intersect(constant_3,v798_2);
    const Space v798_4 = (has_head(v798_3) ? constant_4 : Space{});
    const Space v798_5 = subtract(constant_2,v798_4);
    Space v798_8;
    if (!v798_5.empty()) {
      const Path v799_6 = concat_path(p0,v797_12_head);
      Space v799_7_result;
      for (int v799_7_label = 1; v799_7_label <= 2; ++v799_7_label) {
        const Space v799_7_tail = child(v797_12_tail,v799_7_label);
        if (v799_7_tail.empty()) continue;
        const Path v799_7_head{v799_7_label};
        const Space v800_2 = singleton(v799_7_head);
        const Space v800_3 = intersect(constant_3,v800_2);
        const Space v800_4 = (has_head(v800_3) ? constant_4 : Space{});
        const Space v800_5 = subtract(constant_2,v800_4);
        Space v800_8;
        if (!v800_5.empty()) {
          const Path v801_6 = concat_path(v799_6,v799_7_head);
          const Space v801_7 = routine_126(c, v801_6, p1, v799_7_tail);
          v800_8 = compose(v800_5,v801_7);
        }
        const Space v800_9 = intersect(constant_3,v800_2);
        const Space v800_10 = (has_head(v800_9) ? constant_4 : Space{});
        Space v800_12;
        if (!v800_10.empty()) {
          const Path v802_6 = concat_path(v799_6,v799_7_head);
          const Space v802_11 = routine_127(c, v802_6, p1, v799_7_tail);
          v800_12 = compose(v800_10,v802_11);
        }
        const Space v800_13 = unite(v800_8,v800_12);
        v799_7_result = unite(v799_7_result,v800_13);
      }
      const Space v799_7 = std::move(v799_7_result);
      v798_8 = compose(v798_5,v799_7);
    }
    const Space v798_9 = intersect(constant_3,v798_2);
    const Space v798_10 = (has_head(v798_9) ? constant_4 : Space{});
    Space v798_12;
    if (!v798_10.empty()) {
      const Path v803_6 = concat_path(p0,v797_12_head);
      Space v803_11_result;
      for (int v803_11_label = 1; v803_11_label <= 2; ++v803_11_label) {
        const Space v803_11_tail = child(v797_12_tail,v803_11_label);
        if (v803_11_tail.empty()) continue;
        const Path v803_11_head{v803_11_label};
        const Space v804_2 = singleton(v803_11_head);
        const Space v804_3 = intersect(constant_3,v804_2);
        const Space v804_4 = (has_head(v804_3) ? constant_4 : Space{});
        const Space v804_5 = subtract(constant_2,v804_4);
        Space v804_8;
        if (!v804_5.empty()) {
          const Path v805_6 = concat_path(v803_6,v803_11_head);
          const Space v805_7 = routine_126(c, v805_6, p1, v803_11_tail);
          v804_8 = compose(v804_5,v805_7);
        }
        const Space v804_9 = intersect(constant_3,v804_2);
        const Space v804_10 = (has_head(v804_9) ? constant_4 : Space{});
        Space v804_12;
        if (!v804_10.empty()) {
          const Path v806_6 = concat_path(v803_6,v803_11_head);
          const Space v806_11 = routine_84(c, v806_6, p1, v803_11_tail);
          v804_12 = compose(v804_10,v806_11);
        }
        const Space v804_13 = unite(v804_8,v804_12);
        v803_11_result = unite(v803_11_result,v804_13);
      }
      const Space v803_11 = std::move(v803_11_result);
      v798_12 = compose(v798_10,v803_11);
    }
    const Space v798_13 = unite(v798_8,v798_12);
    v797_12_result = unite(v797_12_result,v798_13);
  }
  const Space v797_12 = std::move(v797_12_result);
  return v797_12;
}

static Space routine_83(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v807_9_result;
  for (int v807_9_label = 1; v807_9_label <= 2; ++v807_9_label) {
    const Space v807_9_tail = child(s0,v807_9_label);
    if (v807_9_tail.empty()) continue;
    const Path v807_9_head{v807_9_label};
    const Space v808_2 = singleton(v807_9_head);
    const Space v808_3 = intersect(constant_3,v808_2);
    const Space v808_4 = (has_head(v808_3) ? constant_4 : Space{});
    const Space v808_5 = subtract(constant_2,v808_4);
    Space v808_8;
    if (!v808_5.empty()) {
      const Path v809_6 = concat_path(p0,v807_9_head);
      Space v809_7_result;
      for (int v809_7_label = 1; v809_7_label <= 2; ++v809_7_label) {
        const Space v809_7_tail = child(v807_9_tail,v809_7_label);
        if (v809_7_tail.empty()) continue;
        const Path v809_7_head{v809_7_label};
        const Space v810_2 = singleton(v809_7_head);
        const Space v810_3 = intersect(constant_3,v810_2);
        const Space v810_4 = (has_head(v810_3) ? constant_4 : Space{});
        const Space v810_5 = subtract(constant_2,v810_4);
        Space v810_8;
        if (!v810_5.empty()) {
          const Path v811_6 = concat_path(v809_6,v809_7_head);
          const Space v811_7 = routine_126(c, v811_6, p1, v809_7_tail);
          v810_8 = compose(v810_5,v811_7);
        }
        const Space v810_9 = intersect(constant_3,v810_2);
        const Space v810_10 = (has_head(v810_9) ? constant_4 : Space{});
        Space v810_12;
        if (!v810_10.empty()) {
          const Path v812_6 = concat_path(v809_6,v809_7_head);
          const Space v812_11 = routine_127(c, v812_6, p1, v809_7_tail);
          v810_12 = compose(v810_10,v812_11);
        }
        const Space v810_13 = unite(v810_8,v810_12);
        v809_7_result = unite(v809_7_result,v810_13);
      }
      const Space v809_7 = std::move(v809_7_result);
      v808_8 = compose(v808_5,v809_7);
    }
    const Space v808_9 = intersect(constant_3,v808_2);
    const Space v808_10 = (has_head(v808_9) ? constant_4 : Space{});
    const Space v808_11 = compose(v808_10,v807_9_tail);
    const Path v813_6 = concat_path(p0,v807_9_head);
    const Space v808_12 = wrap(v808_11,v813_6);
    const Space v808_13 = wrap(v808_12,p1);
    const Space v808_14 = unite(v808_8,v808_13);
    v807_9_result = unite(v807_9_result,v808_14);
  }
  const Space v807_9 = std::move(v807_9_result);
  return v807_9;
}

static Space routine_84(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v814_3 = wrap(s0,p0);
  const Space v814_4 = wrap(v814_3,p1);
  return v814_4;
}

static Space routine_85(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v815_12_result;
  for (int v815_12_label = 1; v815_12_label <= 2; ++v815_12_label) {
    const Space v815_12_tail = child(s0,v815_12_label);
    if (v815_12_tail.empty()) continue;
    const Path v815_12_head{v815_12_label};
    const Space v816_2 = singleton(v815_12_head);
    const Space v816_3 = intersect(constant_3,v816_2);
    const Space v816_4 = (has_head(v816_3) ? constant_4 : Space{});
    const Space v816_5 = subtract(constant_2,v816_4);
    Space v816_8;
    if (!v816_5.empty()) {
      const Path v817_6 = concat_path(p0,v815_12_head);
      Space v817_7_result;
      for (int v817_7_label = 1; v817_7_label <= 2; ++v817_7_label) {
        const Space v817_7_tail = child(v815_12_tail,v817_7_label);
        if (v817_7_tail.empty()) continue;
        const Path v817_7_head{v817_7_label};
        const Space v818_2 = singleton(v817_7_head);
        const Space v818_3 = intersect(constant_3,v818_2);
        const Space v818_4 = (has_head(v818_3) ? constant_4 : Space{});
        const Space v818_5 = subtract(constant_2,v818_4);
        Space v818_8;
        if (!v818_5.empty()) {
          const Path v819_6 = concat_path(v817_6,v817_7_head);
          const Space v819_7 = routine_128(c, v819_6, v817_7_tail, s1);
          v818_8 = compose(v818_5,v819_7);
        }
        const Space v818_9 = intersect(constant_3,v818_2);
        const Space v818_10 = (has_head(v818_9) ? constant_4 : Space{});
        Space v818_12;
        if (!v818_10.empty()) {
          const Path v820_6 = concat_path(v817_6,v817_7_head);
          const Space v820_11 = routine_129(c, v820_6, v817_7_tail, s1);
          v818_12 = compose(v818_10,v820_11);
        }
        const Space v818_13 = unite(v818_8,v818_12);
        v817_7_result = unite(v817_7_result,v818_13);
      }
      const Space v817_7 = std::move(v817_7_result);
      v816_8 = compose(v816_5,v817_7);
    }
    const Space v816_9 = intersect(constant_3,v816_2);
    const Space v816_10 = (has_head(v816_9) ? constant_4 : Space{});
    Space v816_12;
    if (!v816_10.empty()) {
      const Path v821_6 = concat_path(p0,v815_12_head);
      Space v821_11_result;
      for (int v821_11_label = 1; v821_11_label <= 2; ++v821_11_label) {
        const Space v821_11_tail = child(v815_12_tail,v821_11_label);
        if (v821_11_tail.empty()) continue;
        const Path v821_11_head{v821_11_label};
        const Space v822_2 = singleton(v821_11_head);
        const Space v822_3 = intersect(constant_3,v822_2);
        const Space v822_4 = (has_head(v822_3) ? constant_4 : Space{});
        const Space v822_5 = subtract(constant_2,v822_4);
        Space v822_8;
        if (!v822_5.empty()) {
          const Path v823_6 = concat_path(v821_6,v821_11_head);
          const Space v823_7 = routine_128(c, v823_6, v821_11_tail, s1);
          v822_8 = compose(v822_5,v823_7);
        }
        const Space v822_9 = intersect(constant_3,v822_2);
        const Space v822_10 = (has_head(v822_9) ? constant_4 : Space{});
        Space v822_12;
        if (!v822_10.empty()) {
          const Path v824_6 = concat_path(v821_6,v821_11_head);
          const Space v824_11 = routine_15(c, v824_6, v821_11_tail, s1);
          v822_12 = compose(v822_10,v824_11);
        }
        const Space v822_13 = unite(v822_8,v822_12);
        v821_11_result = unite(v821_11_result,v822_13);
      }
      const Space v821_11 = std::move(v821_11_result);
      v816_12 = compose(v816_10,v821_11);
    }
    const Space v816_13 = unite(v816_8,v816_12);
    v815_12_result = unite(v815_12_result,v816_13);
  }
  const Space v815_12 = std::move(v815_12_result);
  return v815_12;
}

static Space routine_86(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v825_12_result;
  for (int v825_12_label = 1; v825_12_label <= 2; ++v825_12_label) {
    const Space v825_12_tail = child(s0,v825_12_label);
    if (v825_12_tail.empty()) continue;
    const Path v825_12_head{v825_12_label};
    const Space v826_2 = singleton(v825_12_head);
    const Space v826_3 = intersect(constant_3,v826_2);
    const Space v826_4 = (has_head(v826_3) ? constant_4 : Space{});
    const Space v826_5 = subtract(constant_2,v826_4);
    Space v826_8;
    if (!v826_5.empty()) {
      const Path v827_6 = concat_path(p0,v825_12_head);
      Space v827_7_result;
      for (int v827_7_label = 1; v827_7_label <= 2; ++v827_7_label) {
        const Space v827_7_tail = child(v825_12_tail,v827_7_label);
        if (v827_7_tail.empty()) continue;
        const Path v827_7_head{v827_7_label};
        const Space v828_2 = singleton(v827_7_head);
        const Space v828_3 = intersect(constant_3,v828_2);
        const Space v828_4 = (has_head(v828_3) ? constant_4 : Space{});
        const Space v828_5 = subtract(constant_2,v828_4);
        Space v828_8;
        if (!v828_5.empty()) {
          const Path v829_6 = concat_path(v827_6,v827_7_head);
          const Space v829_7 = routine_128(c, v829_6, v827_7_tail, s1);
          v828_8 = compose(v828_5,v829_7);
        }
        const Space v828_9 = intersect(constant_3,v828_2);
        const Space v828_10 = (has_head(v828_9) ? constant_4 : Space{});
        Space v828_12;
        if (!v828_10.empty()) {
          const Path v830_6 = concat_path(v827_6,v827_7_head);
          const Space v830_11 = routine_129(c, v830_6, v827_7_tail, s1);
          v828_12 = compose(v828_10,v830_11);
        }
        const Space v828_13 = unite(v828_8,v828_12);
        v827_7_result = unite(v827_7_result,v828_13);
      }
      const Space v827_7 = std::move(v827_7_result);
      v826_8 = compose(v826_5,v827_7);
    }
    const Space v826_9 = intersect(constant_3,v826_2);
    const Space v826_10 = (has_head(v826_9) ? constant_4 : Space{});
    Space v826_12;
    if (!v826_10.empty()) {
      const Path v831_6 = concat_path(p0,v825_12_head);
      Space v831_11_result;
      for (int v831_11_label = 1; v831_11_label <= 2; ++v831_11_label) {
        const Space v831_11_tail = child(v825_12_tail,v831_11_label);
        if (v831_11_tail.empty()) continue;
        const Path v831_11_head{v831_11_label};
        const Space v832_2 = singleton(v831_11_head);
        const Space v832_3 = intersect(constant_3,v832_2);
        const Space v832_4 = (has_head(v832_3) ? constant_4 : Space{});
        const Space v832_5 = subtract(constant_2,v832_4);
        Space v832_7;
        if (!v832_5.empty()) {
          const Space v833_6 = routine_46(c, v831_11_head, v831_6, v831_11_tail, s1);
          v832_7 = compose(v832_5,v833_6);
        }
        const Space v832_8 = intersect(constant_3,v832_2);
        const Space v832_9 = (has_head(v832_8) ? constant_4 : Space{});
        Space v832_11;
        if (!v832_9.empty()) {
          const Space v834_10 = routine_47(c, v831_11_head, v831_6, v831_11_tail, s1);
          v832_11 = compose(v832_9,v834_10);
        }
        const Space v832_12 = unite(v832_7,v832_11);
        v831_11_result = unite(v831_11_result,v832_12);
      }
      const Space v831_11 = std::move(v831_11_result);
      v826_12 = compose(v826_10,v831_11);
    }
    const Space v826_13 = unite(v826_8,v826_12);
    v825_12_result = unite(v825_12_result,v826_13);
  }
  const Space v825_12 = std::move(v825_12_result);
  return v825_12;
}

static Space routine_87(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v835_13_result;
  for (int v835_13_label = 1; v835_13_label <= 2; ++v835_13_label) {
    const Space v835_13_tail = child(s0,v835_13_label);
    if (v835_13_tail.empty()) continue;
    const Path v835_13_head{v835_13_label};
    const Space v836_2 = singleton(v835_13_head);
    const Space v836_3 = intersect(constant_3,v836_2);
    const Space v836_4 = (has_head(v836_3) ? constant_4 : Space{});
    const Space v836_5 = subtract(constant_2,v836_4);
    Space v836_8;
    if (!v836_5.empty()) {
      const Path v837_6 = concat_path(p0,v835_13_head);
      Space v837_7_result;
      for (int v837_7_label = 1; v837_7_label <= 2; ++v837_7_label) {
        const Space v837_7_tail = child(v835_13_tail,v837_7_label);
        if (v837_7_tail.empty()) continue;
        const Path v837_7_head{v837_7_label};
        const Space v838_2 = singleton(v837_7_head);
        const Space v838_3 = intersect(constant_3,v838_2);
        const Space v838_4 = (has_head(v838_3) ? constant_4 : Space{});
        const Space v838_5 = subtract(constant_2,v838_4);
        Space v838_8;
        if (!v838_5.empty()) {
          const Path v839_6 = concat_path(v837_6,v837_7_head);
          const Space v839_7 = routine_130(c, v839_6, p1, v837_7_tail, s1);
          v838_8 = compose(v838_5,v839_7);
        }
        const Space v838_9 = intersect(constant_3,v838_2);
        const Space v838_10 = (has_head(v838_9) ? constant_4 : Space{});
        Space v838_12;
        if (!v838_10.empty()) {
          const Path v840_6 = concat_path(v837_6,v837_7_head);
          const Space v840_11 = routine_131(c, v840_6, p1, v837_7_tail, s1);
          v838_12 = compose(v838_10,v840_11);
        }
        const Space v838_13 = unite(v838_8,v838_12);
        v837_7_result = unite(v837_7_result,v838_13);
      }
      const Space v837_7 = std::move(v837_7_result);
      v836_8 = compose(v836_5,v837_7);
    }
    const Space v836_9 = intersect(constant_3,v836_2);
    const Space v836_10 = (has_head(v836_9) ? constant_4 : Space{});
    Space v836_12;
    if (!v836_10.empty()) {
      const Path v841_6 = concat_path(p0,v835_13_head);
      Space v841_11_result;
      for (int v841_11_label = 1; v841_11_label <= 2; ++v841_11_label) {
        const Space v841_11_tail = child(v835_13_tail,v841_11_label);
        if (v841_11_tail.empty()) continue;
        const Path v841_11_head{v841_11_label};
        const Space v842_2 = singleton(v841_11_head);
        const Space v842_3 = intersect(constant_3,v842_2);
        const Space v842_4 = (has_head(v842_3) ? constant_4 : Space{});
        const Space v842_5 = subtract(constant_2,v842_4);
        Space v842_8;
        if (!v842_5.empty()) {
          const Path v843_6 = concat_path(v841_6,v841_11_head);
          const Space v843_7 = routine_130(c, v843_6, p1, v841_11_tail, s1);
          v842_8 = compose(v842_5,v843_7);
        }
        const Space v842_9 = intersect(constant_3,v842_2);
        const Space v842_10 = (has_head(v842_9) ? constant_4 : Space{});
        Space v842_12;
        if (!v842_10.empty()) {
          const Path v844_6 = concat_path(v841_6,v841_11_head);
          const Space v844_11 = routine_50(c, v844_6, p1, v841_11_tail, s1);
          v842_12 = compose(v842_10,v844_11);
        }
        const Space v842_13 = unite(v842_8,v842_12);
        v841_11_result = unite(v841_11_result,v842_13);
      }
      const Space v841_11 = std::move(v841_11_result);
      v836_12 = compose(v836_10,v841_11);
    }
    const Space v836_13 = unite(v836_8,v836_12);
    v835_13_result = unite(v835_13_result,v836_13);
  }
  const Space v835_13 = std::move(v835_13_result);
  return v835_13;
}

static Space routine_88(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v845_8 = unwrap(s1,constant_5);
  const Space v845_10 = unwrap(v845_8,constant_6);
  const Space v845_11 = unwrap(v845_10,p0);
  Space v845_18_result;
  for (int v845_18_label = 1; v845_18_label <= 2; ++v845_18_label) {
    const Space v845_18_tail = child(s0,v845_18_label);
    if (v845_18_tail.empty()) continue;
    const Path v845_18_head{v845_18_label};
    const Space v846_2 = singleton(v845_18_head);
    const Space v846_3 = intersect(constant_3,v846_2);
    const Space v846_4 = (has_head(v846_3) ? constant_4 : Space{});
    const Space v846_5 = subtract(constant_2,v846_4);
    Space v846_8;
    if (!v846_5.empty()) {
      const Path v847_6 = concat_path(p0,v845_18_head);
      Space v847_7_result;
      for (int v847_7_label = 1; v847_7_label <= 2; ++v847_7_label) {
        const Space v847_7_tail = child(v845_18_tail,v847_7_label);
        if (v847_7_tail.empty()) continue;
        const Path v847_7_head{v847_7_label};
        const Space v848_2 = singleton(v847_7_head);
        const Space v848_3 = intersect(constant_3,v848_2);
        const Space v848_4 = (has_head(v848_3) ? constant_4 : Space{});
        const Space v848_5 = subtract(constant_2,v848_4);
        Space v848_8;
        if (!v848_5.empty()) {
          const Path v849_6 = concat_path(v847_6,v847_7_head);
          const Space v849_7 = routine_130(c, v849_6, p1, v847_7_tail, s1);
          v848_8 = compose(v848_5,v849_7);
        }
        const Space v848_9 = intersect(constant_3,v848_2);
        const Space v848_10 = (has_head(v848_9) ? constant_4 : Space{});
        Space v848_12;
        if (!v848_10.empty()) {
          const Path v850_6 = concat_path(v847_6,v847_7_head);
          const Space v850_11 = routine_131(c, v850_6, p1, v847_7_tail, s1);
          v848_12 = compose(v848_10,v850_11);
        }
        const Space v848_13 = unite(v848_8,v848_12);
        v847_7_result = unite(v847_7_result,v848_13);
      }
      const Space v847_7 = std::move(v847_7_result);
      v846_8 = compose(v846_5,v847_7);
    }
    const Space v846_9 = intersect(constant_3,v846_2);
    const Space v846_10 = (has_head(v846_9) ? constant_4 : Space{});
    Space v846_13;
    if (!v846_10.empty()) {
      const Space v851_11 = unwrap(v845_11,v845_18_head);
      Space v851_12_result;
      for (int v851_12_label = 1; v851_12_label <= 2; ++v851_12_label) {
        const Space v851_12_tail = child(v851_11,v851_12_label);
        if (v851_12_tail.empty()) continue;
        const Path v851_12_head{v851_12_label};
        const Space v852_2 = singleton(v851_12_head);
        const Space v852_3 = intersect(constant_3,v852_2);
        const Space v852_4 = (has_head(v852_3) ? constant_4 : Space{});
        const Space v852_5 = subtract(constant_2,v852_4);
        Space v852_7;
        if (!v852_5.empty()) {
          const Space v853_6 = routine_89(c, v851_12_head, p1, v851_12_tail);
          v852_7 = compose(v852_5,v853_6);
        }
        const Space v852_8 = intersect(constant_3,v852_2);
        const Space v852_9 = (has_head(v852_8) ? constant_4 : Space{});
        Space v852_11;
        if (!v852_9.empty()) {
          const Space v854_10 = routine_90(c, v851_12_head, p1, v851_12_tail);
          v852_11 = compose(v852_9,v854_10);
        }
        const Space v852_12 = unite(v852_7,v852_11);
        v851_12_result = unite(v851_12_result,v852_12);
      }
      const Space v851_12 = std::move(v851_12_result);
      v846_13 = compose(v846_10,v851_12);
    }
    const Space v846_14 = unite(v846_8,v846_13);
    v845_18_result = unite(v845_18_result,v846_14);
  }
  const Space v845_18 = std::move(v845_18_result);
  return v845_18;
}

static Space routine_89(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v855_12_result;
  for (int v855_12_label = 1; v855_12_label <= 2; ++v855_12_label) {
    const Space v855_12_tail = child(s0,v855_12_label);
    if (v855_12_tail.empty()) continue;
    const Path v855_12_head{v855_12_label};
    const Space v856_2 = singleton(v855_12_head);
    const Space v856_3 = intersect(constant_3,v856_2);
    const Space v856_4 = (has_head(v856_3) ? constant_4 : Space{});
    const Space v856_5 = subtract(constant_2,v856_4);
    Space v856_8;
    if (!v856_5.empty()) {
      const Path v857_6 = concat_path(p0,v855_12_head);
      Space v857_7_result;
      for (int v857_7_label = 1; v857_7_label <= 2; ++v857_7_label) {
        const Space v857_7_tail = child(v855_12_tail,v857_7_label);
        if (v857_7_tail.empty()) continue;
        const Path v857_7_head{v857_7_label};
        const Space v858_2 = singleton(v857_7_head);
        const Space v858_3 = intersect(constant_3,v858_2);
        const Space v858_4 = (has_head(v858_3) ? constant_4 : Space{});
        const Space v858_5 = subtract(constant_2,v858_4);
        Space v858_8;
        if (!v858_5.empty()) {
          const Path v859_6 = concat_path(v857_6,v857_7_head);
          const Space v859_7 = routine_132(c, v859_6, p1, v857_7_tail);
          v858_8 = compose(v858_5,v859_7);
        }
        const Space v858_9 = intersect(constant_3,v858_2);
        const Space v858_10 = (has_head(v858_9) ? constant_4 : Space{});
        Space v858_12;
        if (!v858_10.empty()) {
          const Path v860_6 = concat_path(v857_6,v857_7_head);
          const Space v860_11 = routine_133(c, v860_6, p1, v857_7_tail);
          v858_12 = compose(v858_10,v860_11);
        }
        const Space v858_13 = unite(v858_8,v858_12);
        v857_7_result = unite(v857_7_result,v858_13);
      }
      const Space v857_7 = std::move(v857_7_result);
      v856_8 = compose(v856_5,v857_7);
    }
    const Space v856_9 = intersect(constant_3,v856_2);
    const Space v856_10 = (has_head(v856_9) ? constant_4 : Space{});
    Space v856_12;
    if (!v856_10.empty()) {
      const Path v861_6 = concat_path(p0,v855_12_head);
      Space v861_11_result;
      for (int v861_11_label = 1; v861_11_label <= 2; ++v861_11_label) {
        const Space v861_11_tail = child(v855_12_tail,v861_11_label);
        if (v861_11_tail.empty()) continue;
        const Path v861_11_head{v861_11_label};
        const Space v862_2 = singleton(v861_11_head);
        const Space v862_3 = intersect(constant_3,v862_2);
        const Space v862_4 = (has_head(v862_3) ? constant_4 : Space{});
        const Space v862_5 = subtract(constant_2,v862_4);
        Space v862_8;
        if (!v862_5.empty()) {
          const Path v863_6 = concat_path(v861_6,v861_11_head);
          const Space v863_7 = routine_132(c, v863_6, p1, v861_11_tail);
          v862_8 = compose(v862_5,v863_7);
        }
        const Space v862_9 = intersect(constant_3,v862_2);
        const Space v862_10 = (has_head(v862_9) ? constant_4 : Space{});
        Space v862_12;
        if (!v862_10.empty()) {
          const Path v864_6 = concat_path(v861_6,v861_11_head);
          const Space v864_11 = routine_95(c, v864_6, p1, v861_11_tail);
          v862_12 = compose(v862_10,v864_11);
        }
        const Space v862_13 = unite(v862_8,v862_12);
        v861_11_result = unite(v861_11_result,v862_13);
      }
      const Space v861_11 = std::move(v861_11_result);
      v856_12 = compose(v856_10,v861_11);
    }
    const Space v856_13 = unite(v856_8,v856_12);
    v855_12_result = unite(v855_12_result,v856_13);
  }
  const Space v855_12 = std::move(v855_12_result);
  return v855_12;
}

static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v865_9_result;
  for (int v865_9_label = 1; v865_9_label <= 2; ++v865_9_label) {
    const Space v865_9_tail = child(s0,v865_9_label);
    if (v865_9_tail.empty()) continue;
    const Path v865_9_head{v865_9_label};
    const Space v866_2 = singleton(v865_9_head);
    const Space v866_3 = intersect(constant_3,v866_2);
    const Space v866_4 = (has_head(v866_3) ? constant_4 : Space{});
    const Space v866_5 = subtract(constant_2,v866_4);
    Space v866_8;
    if (!v866_5.empty()) {
      const Path v867_6 = concat_path(p0,v865_9_head);
      Space v867_7_result;
      for (int v867_7_label = 1; v867_7_label <= 2; ++v867_7_label) {
        const Space v867_7_tail = child(v865_9_tail,v867_7_label);
        if (v867_7_tail.empty()) continue;
        const Path v867_7_head{v867_7_label};
        const Space v868_2 = singleton(v867_7_head);
        const Space v868_3 = intersect(constant_3,v868_2);
        const Space v868_4 = (has_head(v868_3) ? constant_4 : Space{});
        const Space v868_5 = subtract(constant_2,v868_4);
        Space v868_8;
        if (!v868_5.empty()) {
          const Path v869_6 = concat_path(v867_6,v867_7_head);
          const Space v869_7 = routine_132(c, v869_6, p1, v867_7_tail);
          v868_8 = compose(v868_5,v869_7);
        }
        const Space v868_9 = intersect(constant_3,v868_2);
        const Space v868_10 = (has_head(v868_9) ? constant_4 : Space{});
        Space v868_12;
        if (!v868_10.empty()) {
          const Path v870_6 = concat_path(v867_6,v867_7_head);
          const Space v870_11 = routine_133(c, v870_6, p1, v867_7_tail);
          v868_12 = compose(v868_10,v870_11);
        }
        const Space v868_13 = unite(v868_8,v868_12);
        v867_7_result = unite(v867_7_result,v868_13);
      }
      const Space v867_7 = std::move(v867_7_result);
      v866_8 = compose(v866_5,v867_7);
    }
    const Space v866_9 = intersect(constant_3,v866_2);
    const Space v866_10 = (has_head(v866_9) ? constant_4 : Space{});
    const Space v866_11 = compose(v866_10,v865_9_tail);
    const Path v871_6 = concat_path(p0,v865_9_head);
    const Space v866_12 = wrap(v866_11,v871_6);
    const Space v866_13 = wrap(v866_12,p1);
    const Space v866_14 = unite(v866_8,v866_13);
    v865_9_result = unite(v865_9_result,v866_14);
  }
  const Space v865_9 = std::move(v865_9_result);
  return v865_9;
}

static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v872_13_result;
  for (int v872_13_label = 1; v872_13_label <= 2; ++v872_13_label) {
    const Space v872_13_tail = child(s0,v872_13_label);
    if (v872_13_tail.empty()) continue;
    const Path v872_13_head{v872_13_label};
    const Space v873_2 = singleton(v872_13_head);
    const Space v873_3 = intersect(constant_3,v873_2);
    const Space v873_4 = (has_head(v873_3) ? constant_4 : Space{});
    const Space v873_5 = subtract(constant_2,v873_4);
    Space v873_8;
    if (!v873_5.empty()) {
      const Path v874_6 = concat_path(p0,v872_13_head);
      Space v874_7_result;
      for (int v874_7_label = 1; v874_7_label <= 2; ++v874_7_label) {
        const Space v874_7_tail = child(v872_13_tail,v874_7_label);
        if (v874_7_tail.empty()) continue;
        const Path v874_7_head{v874_7_label};
        const Space v875_2 = singleton(v874_7_head);
        const Space v875_3 = intersect(constant_3,v875_2);
        const Space v875_4 = (has_head(v875_3) ? constant_4 : Space{});
        const Space v875_5 = subtract(constant_2,v875_4);
        Space v875_8;
        if (!v875_5.empty()) {
          const Path v876_6 = concat_path(v874_6,v874_7_head);
          const Space v876_7 = routine_134(c, v876_6, p1, v874_7_tail, s1);
          v875_8 = compose(v875_5,v876_7);
        }
        const Space v875_9 = intersect(constant_3,v875_2);
        const Space v875_10 = (has_head(v875_9) ? constant_4 : Space{});
        Space v875_12;
        if (!v875_10.empty()) {
          const Path v877_6 = concat_path(v874_6,v874_7_head);
          const Space v877_11 = routine_135(c, v877_6, p1, v874_7_tail, s1);
          v875_12 = compose(v875_10,v877_11);
        }
        const Space v875_13 = unite(v875_8,v875_12);
        v874_7_result = unite(v874_7_result,v875_13);
      }
      const Space v874_7 = std::move(v874_7_result);
      v873_8 = compose(v873_5,v874_7);
    }
    const Space v873_9 = intersect(constant_3,v873_2);
    const Space v873_10 = (has_head(v873_9) ? constant_4 : Space{});
    Space v873_12;
    if (!v873_10.empty()) {
      const Path v878_6 = concat_path(p0,v872_13_head);
      Space v878_11_result;
      for (int v878_11_label = 1; v878_11_label <= 2; ++v878_11_label) {
        const Space v878_11_tail = child(v872_13_tail,v878_11_label);
        if (v878_11_tail.empty()) continue;
        const Path v878_11_head{v878_11_label};
        const Space v879_2 = singleton(v878_11_head);
        const Space v879_3 = intersect(constant_3,v879_2);
        const Space v879_4 = (has_head(v879_3) ? constant_4 : Space{});
        const Space v879_5 = subtract(constant_2,v879_4);
        Space v879_8;
        if (!v879_5.empty()) {
          const Path v880_6 = concat_path(v878_6,v878_11_head);
          const Space v880_7 = routine_134(c, v880_6, p1, v878_11_tail, s1);
          v879_8 = compose(v879_5,v880_7);
        }
        const Space v879_9 = intersect(constant_3,v879_2);
        const Space v879_10 = (has_head(v879_9) ? constant_4 : Space{});
        Space v879_12;
        if (!v879_10.empty()) {
          const Path v881_6 = concat_path(v878_6,v878_11_head);
          const Space v881_11 = routine_50(c, v881_6, p1, v878_11_tail, s1);
          v879_12 = compose(v879_10,v881_11);
        }
        const Space v879_13 = unite(v879_8,v879_12);
        v878_11_result = unite(v878_11_result,v879_13);
      }
      const Space v878_11 = std::move(v878_11_result);
      v873_12 = compose(v873_10,v878_11);
    }
    const Space v873_13 = unite(v873_8,v873_12);
    v872_13_result = unite(v872_13_result,v873_13);
  }
  const Space v872_13 = std::move(v872_13_result);
  return v872_13;
}

static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v882_8 = unwrap(s1,constant_5);
  const Space v882_10 = unwrap(v882_8,constant_6);
  const Space v882_11 = unwrap(v882_10,p0);
  Space v882_18_result;
  for (int v882_18_label = 1; v882_18_label <= 2; ++v882_18_label) {
    const Space v882_18_tail = child(s0,v882_18_label);
    if (v882_18_tail.empty()) continue;
    const Path v882_18_head{v882_18_label};
    const Space v883_2 = singleton(v882_18_head);
    const Space v883_3 = intersect(constant_3,v883_2);
    const Space v883_4 = (has_head(v883_3) ? constant_4 : Space{});
    const Space v883_5 = subtract(constant_2,v883_4);
    Space v883_8;
    if (!v883_5.empty()) {
      const Path v884_6 = concat_path(p0,v882_18_head);
      Space v884_7_result;
      for (int v884_7_label = 1; v884_7_label <= 2; ++v884_7_label) {
        const Space v884_7_tail = child(v882_18_tail,v884_7_label);
        if (v884_7_tail.empty()) continue;
        const Path v884_7_head{v884_7_label};
        const Space v885_2 = singleton(v884_7_head);
        const Space v885_3 = intersect(constant_3,v885_2);
        const Space v885_4 = (has_head(v885_3) ? constant_4 : Space{});
        const Space v885_5 = subtract(constant_2,v885_4);
        Space v885_8;
        if (!v885_5.empty()) {
          const Path v886_6 = concat_path(v884_6,v884_7_head);
          const Space v886_7 = routine_134(c, v886_6, p1, v884_7_tail, s1);
          v885_8 = compose(v885_5,v886_7);
        }
        const Space v885_9 = intersect(constant_3,v885_2);
        const Space v885_10 = (has_head(v885_9) ? constant_4 : Space{});
        Space v885_12;
        if (!v885_10.empty()) {
          const Path v887_6 = concat_path(v884_6,v884_7_head);
          const Space v887_11 = routine_135(c, v887_6, p1, v884_7_tail, s1);
          v885_12 = compose(v885_10,v887_11);
        }
        const Space v885_13 = unite(v885_8,v885_12);
        v884_7_result = unite(v884_7_result,v885_13);
      }
      const Space v884_7 = std::move(v884_7_result);
      v883_8 = compose(v883_5,v884_7);
    }
    const Space v883_9 = intersect(constant_3,v883_2);
    const Space v883_10 = (has_head(v883_9) ? constant_4 : Space{});
    Space v883_13;
    if (!v883_10.empty()) {
      const Space v888_11 = unwrap(v882_11,v882_18_head);
      Space v888_12_result;
      for (int v888_12_label = 1; v888_12_label <= 2; ++v888_12_label) {
        const Space v888_12_tail = child(v888_11,v888_12_label);
        if (v888_12_tail.empty()) continue;
        const Path v888_12_head{v888_12_label};
        const Space v889_2 = singleton(v888_12_head);
        const Space v889_3 = intersect(constant_3,v889_2);
        const Space v889_4 = (has_head(v889_3) ? constant_4 : Space{});
        const Space v889_5 = subtract(constant_2,v889_4);
        Space v889_7;
        if (!v889_5.empty()) {
          const Space v890_6 = routine_89(c, v888_12_head, p1, v888_12_tail);
          v889_7 = compose(v889_5,v890_6);
        }
        const Space v889_8 = intersect(constant_3,v889_2);
        const Space v889_9 = (has_head(v889_8) ? constant_4 : Space{});
        Space v889_11;
        if (!v889_9.empty()) {
          const Space v891_10 = routine_90(c, v888_12_head, p1, v888_12_tail);
          v889_11 = compose(v889_9,v891_10);
        }
        const Space v889_12 = unite(v889_7,v889_11);
        v888_12_result = unite(v888_12_result,v889_12);
      }
      const Space v888_12 = std::move(v888_12_result);
      v883_13 = compose(v883_10,v888_12);
    }
    const Space v883_14 = unite(v883_8,v883_13);
    v882_18_result = unite(v882_18_result,v883_14);
  }
  const Space v882_18 = std::move(v882_18_result);
  return v882_18;
}

static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v892_12_result;
  for (int v892_12_label = 1; v892_12_label <= 2; ++v892_12_label) {
    const Space v892_12_tail = child(s0,v892_12_label);
    if (v892_12_tail.empty()) continue;
    const Path v892_12_head{v892_12_label};
    const Space v893_2 = singleton(v892_12_head);
    const Space v893_3 = intersect(constant_3,v893_2);
    const Space v893_4 = (has_head(v893_3) ? constant_4 : Space{});
    const Space v893_5 = subtract(constant_2,v893_4);
    Space v893_8;
    if (!v893_5.empty()) {
      const Path v894_6 = concat_path(p0,v892_12_head);
      Space v894_7_result;
      for (int v894_7_label = 1; v894_7_label <= 2; ++v894_7_label) {
        const Space v894_7_tail = child(v892_12_tail,v894_7_label);
        if (v894_7_tail.empty()) continue;
        const Path v894_7_head{v894_7_label};
        const Space v895_2 = singleton(v894_7_head);
        const Space v895_3 = intersect(constant_3,v895_2);
        const Space v895_4 = (has_head(v895_3) ? constant_4 : Space{});
        const Space v895_5 = subtract(constant_2,v895_4);
        Space v895_8;
        if (!v895_5.empty()) {
          const Path v896_6 = concat_path(v894_6,v894_7_head);
          const Space v896_7 = routine_136(c, v896_6, p1, v894_7_tail);
          v895_8 = compose(v895_5,v896_7);
        }
        const Space v895_9 = intersect(constant_3,v895_2);
        const Space v895_10 = (has_head(v895_9) ? constant_4 : Space{});
        Space v895_12;
        if (!v895_10.empty()) {
          const Path v897_6 = concat_path(v894_6,v894_7_head);
          const Space v897_11 = routine_137(c, v897_6, p1, v894_7_tail);
          v895_12 = compose(v895_10,v897_11);
        }
        const Space v895_13 = unite(v895_8,v895_12);
        v894_7_result = unite(v894_7_result,v895_13);
      }
      const Space v894_7 = std::move(v894_7_result);
      v893_8 = compose(v893_5,v894_7);
    }
    const Space v893_9 = intersect(constant_3,v893_2);
    const Space v893_10 = (has_head(v893_9) ? constant_4 : Space{});
    Space v893_12;
    if (!v893_10.empty()) {
      const Path v898_6 = concat_path(p0,v892_12_head);
      Space v898_11_result;
      for (int v898_11_label = 1; v898_11_label <= 2; ++v898_11_label) {
        const Space v898_11_tail = child(v892_12_tail,v898_11_label);
        if (v898_11_tail.empty()) continue;
        const Path v898_11_head{v898_11_label};
        const Space v899_2 = singleton(v898_11_head);
        const Space v899_3 = intersect(constant_3,v899_2);
        const Space v899_4 = (has_head(v899_3) ? constant_4 : Space{});
        const Space v899_5 = subtract(constant_2,v899_4);
        Space v899_8;
        if (!v899_5.empty()) {
          const Path v900_6 = concat_path(v898_6,v898_11_head);
          const Space v900_7 = routine_136(c, v900_6, p1, v898_11_tail);
          v899_8 = compose(v899_5,v900_7);
        }
        const Space v899_9 = intersect(constant_3,v899_2);
        const Space v899_10 = (has_head(v899_9) ? constant_4 : Space{});
        Space v899_12;
        if (!v899_10.empty()) {
          const Path v901_6 = concat_path(v898_6,v898_11_head);
          const Space v901_11 = routine_95(c, v901_6, p1, v898_11_tail);
          v899_12 = compose(v899_10,v901_11);
        }
        const Space v899_13 = unite(v899_8,v899_12);
        v898_11_result = unite(v898_11_result,v899_13);
      }
      const Space v898_11 = std::move(v898_11_result);
      v893_12 = compose(v893_10,v898_11);
    }
    const Space v893_13 = unite(v893_8,v893_12);
    v892_12_result = unite(v892_12_result,v893_13);
  }
  const Space v892_12 = std::move(v892_12_result);
  return v892_12;
}

static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v902_9_result;
  for (int v902_9_label = 1; v902_9_label <= 2; ++v902_9_label) {
    const Space v902_9_tail = child(s0,v902_9_label);
    if (v902_9_tail.empty()) continue;
    const Path v902_9_head{v902_9_label};
    const Space v903_2 = singleton(v902_9_head);
    const Space v903_3 = intersect(constant_3,v903_2);
    const Space v903_4 = (has_head(v903_3) ? constant_4 : Space{});
    const Space v903_5 = subtract(constant_2,v903_4);
    Space v903_8;
    if (!v903_5.empty()) {
      const Path v904_6 = concat_path(p0,v902_9_head);
      Space v904_7_result;
      for (int v904_7_label = 1; v904_7_label <= 2; ++v904_7_label) {
        const Space v904_7_tail = child(v902_9_tail,v904_7_label);
        if (v904_7_tail.empty()) continue;
        const Path v904_7_head{v904_7_label};
        const Space v905_2 = singleton(v904_7_head);
        const Space v905_3 = intersect(constant_3,v905_2);
        const Space v905_4 = (has_head(v905_3) ? constant_4 : Space{});
        const Space v905_5 = subtract(constant_2,v905_4);
        Space v905_8;
        if (!v905_5.empty()) {
          const Path v906_6 = concat_path(v904_6,v904_7_head);
          const Space v906_7 = routine_136(c, v906_6, p1, v904_7_tail);
          v905_8 = compose(v905_5,v906_7);
        }
        const Space v905_9 = intersect(constant_3,v905_2);
        const Space v905_10 = (has_head(v905_9) ? constant_4 : Space{});
        Space v905_12;
        if (!v905_10.empty()) {
          const Path v907_6 = concat_path(v904_6,v904_7_head);
          const Space v907_11 = routine_137(c, v907_6, p1, v904_7_tail);
          v905_12 = compose(v905_10,v907_11);
        }
        const Space v905_13 = unite(v905_8,v905_12);
        v904_7_result = unite(v904_7_result,v905_13);
      }
      const Space v904_7 = std::move(v904_7_result);
      v903_8 = compose(v903_5,v904_7);
    }
    const Space v903_9 = intersect(constant_3,v903_2);
    const Space v903_10 = (has_head(v903_9) ? constant_4 : Space{});
    const Space v903_11 = compose(v903_10,v902_9_tail);
    const Path v908_6 = concat_path(p0,v902_9_head);
    const Space v903_12 = wrap(v903_11,v908_6);
    const Space v903_13 = wrap(v903_12,p1);
    const Space v903_14 = unite(v903_8,v903_13);
    v902_9_result = unite(v902_9_result,v903_14);
  }
  const Space v902_9 = std::move(v902_9_result);
  return v902_9;
}

static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v909_3 = wrap(s0,p0);
  const Space v909_4 = wrap(v909_3,p1);
  return v909_4;
}

static Space routine_96(Context& c, const Path& p0, const Space& s0) {
  Space v910_2_result;
  for (int v910_2_label = 1; v910_2_label <= 2; ++v910_2_label) {
    const Space v910_2_tail = child(s0,v910_2_label);
    if (v910_2_tail.empty()) continue;
    const Path v910_2_head{v910_2_label};
    const Space v911_2 = Space{};
    v910_2_result = unite(v910_2_result,v911_2);
  }
  const Space v910_2 = std::move(v910_2_result);
  return v910_2;
}

static Space routine_97(Context& c, const Path& p0, const Space& s0) {
  Space v912_6_result;
  for (int v912_6_label = 1; v912_6_label <= 2; ++v912_6_label) {
    const Space v912_6_tail = child(s0,v912_6_label);
    if (v912_6_tail.empty()) continue;
    const Path v912_6_head{v912_6_label};
    const Space v913_2 = singleton(v912_6_head);
    const Space v913_3 = intersect(constant_3,v913_2);
    const Space v913_4 = (has_head(v913_3) ? constant_4 : Space{});
    Space v913_7;
    if (!v913_4.empty()) {
      const Path v914_5 = concat_path(p0,v912_6_head);
      Space v914_6_result;
      for (int v914_6_label = 1; v914_6_label <= 2; ++v914_6_label) {
        const Space v914_6_tail = child(v912_6_tail,v914_6_label);
        if (v914_6_tail.empty()) continue;
        const Path v914_6_head{v914_6_label};
        const Space v915_2 = singleton(v914_6_head);
        const Space v915_3 = intersect(constant_3,v915_2);
        const Space v915_4 = (has_head(v915_3) ? constant_4 : Space{});
        const Space v915_5 = subtract(constant_2,v915_4);
        Space v915_7;
        if (!v915_5.empty()) {
          const Space v916_6 = routine_18(c, v914_6_head, v914_5, v914_6_tail);
          v915_7 = compose(v915_5,v916_6);
        }
        const Space v915_8 = intersect(constant_3,v915_2);
        const Space v915_9 = (has_head(v915_8) ? constant_4 : Space{});
        Space v915_11;
        if (!v915_9.empty()) {
          const Space v917_10 = routine_19(c, v914_6_head, v914_5, v914_6_tail);
          v915_11 = compose(v915_9,v917_10);
        }
        const Space v915_12 = unite(v915_7,v915_11);
        v914_6_result = unite(v914_6_result,v915_12);
      }
      const Space v914_6 = std::move(v914_6_result);
      v913_7 = compose(v913_4,v914_6);
    }
    v912_6_result = unite(v912_6_result,v913_7);
  }
  const Space v912_6 = std::move(v912_6_result);
  return v912_6;
}

static Space routine_98(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v918_12_result;
  for (int v918_12_label = 1; v918_12_label <= 2; ++v918_12_label) {
    const Space v918_12_tail = child(s0,v918_12_label);
    if (v918_12_tail.empty()) continue;
    const Path v918_12_head{v918_12_label};
    const Space v919_2 = singleton(v918_12_head);
    const Space v919_3 = intersect(constant_3,v919_2);
    const Space v919_4 = (has_head(v919_3) ? constant_4 : Space{});
    const Space v919_5 = subtract(constant_2,v919_4);
    Space v919_8;
    if (!v919_5.empty()) {
      const Path v920_6 = concat_path(p0,v918_12_head);
      Space v920_7_result;
      for (int v920_7_label = 1; v920_7_label <= 2; ++v920_7_label) {
        const Space v920_7_tail = child(v918_12_tail,v920_7_label);
        if (v920_7_tail.empty()) continue;
        const Path v920_7_head{v920_7_label};
        const Space v921_2 = singleton(v920_7_head);
        const Space v921_3 = intersect(constant_3,v921_2);
        const Space v921_4 = (has_head(v921_3) ? constant_4 : Space{});
        const Space v921_5 = subtract(constant_2,v921_4);
        Space v921_8;
        if (!v921_5.empty()) {
          const Path v922_6 = concat_path(v920_6,v920_7_head);
          const Space v922_7 = routine_138(c, v922_6, p1, v920_7_tail);
          v921_8 = compose(v921_5,v922_7);
        }
        const Space v921_9 = intersect(constant_3,v921_2);
        const Space v921_10 = (has_head(v921_9) ? constant_4 : Space{});
        Space v921_12;
        if (!v921_10.empty()) {
          const Path v923_6 = concat_path(v920_6,v920_7_head);
          const Space v923_11 = routine_139(c, v923_6, p1, v920_7_tail);
          v921_12 = compose(v921_10,v923_11);
        }
        const Space v921_13 = unite(v921_8,v921_12);
        v920_7_result = unite(v920_7_result,v921_13);
      }
      const Space v920_7 = std::move(v920_7_result);
      v919_8 = compose(v919_5,v920_7);
    }
    const Space v919_9 = intersect(constant_3,v919_2);
    const Space v919_10 = (has_head(v919_9) ? constant_4 : Space{});
    Space v919_12;
    if (!v919_10.empty()) {
      const Path v924_6 = concat_path(p0,v918_12_head);
      Space v924_11_result;
      for (int v924_11_label = 1; v924_11_label <= 2; ++v924_11_label) {
        const Space v924_11_tail = child(v918_12_tail,v924_11_label);
        if (v924_11_tail.empty()) continue;
        const Path v924_11_head{v924_11_label};
        const Space v925_2 = singleton(v924_11_head);
        const Space v925_3 = intersect(constant_3,v925_2);
        const Space v925_4 = (has_head(v925_3) ? constant_4 : Space{});
        const Space v925_5 = subtract(constant_2,v925_4);
        Space v925_8;
        if (!v925_5.empty()) {
          const Path v926_6 = concat_path(v924_6,v924_11_head);
          const Space v926_7 = routine_138(c, v926_6, p1, v924_11_tail);
          v925_8 = compose(v925_5,v926_7);
        }
        const Space v925_9 = intersect(constant_3,v925_2);
        const Space v925_10 = (has_head(v925_9) ? constant_4 : Space{});
        Space v925_12;
        if (!v925_10.empty()) {
          const Path v927_6 = concat_path(v924_6,v924_11_head);
          const Space v927_11 = routine_22(c, v927_6, p1, v924_11_tail);
          v925_12 = compose(v925_10,v927_11);
        }
        const Space v925_13 = unite(v925_8,v925_12);
        v924_11_result = unite(v924_11_result,v925_13);
      }
      const Space v924_11 = std::move(v924_11_result);
      v919_12 = compose(v919_10,v924_11);
    }
    const Space v919_13 = unite(v919_8,v919_12);
    v918_12_result = unite(v918_12_result,v919_13);
  }
  const Space v918_12 = std::move(v918_12_result);
  return v918_12;
}

static Space routine_99(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v928_10_result;
  for (int v928_10_label = 1; v928_10_label <= 2; ++v928_10_label) {
    const Space v928_10_tail = child(s0,v928_10_label);
    if (v928_10_tail.empty()) continue;
    const Path v928_10_head{v928_10_label};
    const Space v929_2 = singleton(v928_10_head);
    const Space v929_3 = intersect(constant_3,v929_2);
    const Space v929_4 = (has_head(v929_3) ? constant_4 : Space{});
    const Space v929_5 = compose(v929_4,v928_10_tail);
    const Path v930_6 = concat_path(p0,v928_10_head);
    const Space v929_7 = wrap(v929_5,v930_6);
    const Space v929_8 = wrap(v929_7,p1);
    const Space v929_9 = wrap(v929_8,constant_6);
    const Space v929_10 = intersect(constant_3,v929_2);
    const Space v929_11 = (has_head(v929_10) ? constant_4 : Space{});
    const Space v929_12 = subtract(constant_2,v929_11);
    Space v929_14;
    if (!v929_12.empty()) {
      Space v931_13_result;
      for (int v931_13_label = 1; v931_13_label <= 2; ++v931_13_label) {
        const Space v931_13_tail = child(v928_10_tail,v931_13_label);
        if (v931_13_tail.empty()) continue;
        const Path v931_13_head{v931_13_label};
        const Space v932_2 = singleton(v931_13_head);
        const Space v932_3 = intersect(constant_3,v932_2);
        const Space v932_4 = (has_head(v932_3) ? constant_4 : Space{});
        const Space v932_5 = subtract(constant_2,v932_4);
        Space v932_8;
        if (!v932_5.empty()) {
          const Path v933_6 = concat_path(v930_6,v931_13_head);
          const Space v933_7 = routine_138(c, v933_6, p1, v931_13_tail);
          v932_8 = compose(v932_5,v933_7);
        }
        const Space v932_9 = intersect(constant_3,v932_2);
        const Space v932_10 = (has_head(v932_9) ? constant_4 : Space{});
        Space v932_12;
        if (!v932_10.empty()) {
          const Path v934_6 = concat_path(v930_6,v931_13_head);
          const Space v934_11 = routine_139(c, v934_6, p1, v931_13_tail);
          v932_12 = compose(v932_10,v934_11);
        }
        const Space v932_13 = unite(v932_8,v932_12);
        v931_13_result = unite(v931_13_result,v932_13);
      }
      const Space v931_13 = std::move(v931_13_result);
      v929_14 = compose(v929_12,v931_13);
    }
    const Space v929_15 = unite(v929_9,v929_14);
    v928_10_result = unite(v928_10_result,v929_15);
  }
  const Space v928_10 = std::move(v928_10_result);
  return v928_10;
}

static Space routine_100(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v935_12_result;
  for (int v935_12_label = 1; v935_12_label <= 2; ++v935_12_label) {
    const Space v935_12_tail = child(s0,v935_12_label);
    if (v935_12_tail.empty()) continue;
    const Path v935_12_head{v935_12_label};
    const Space v936_2 = singleton(v935_12_head);
    const Space v936_3 = intersect(constant_3,v936_2);
    const Space v936_4 = (has_head(v936_3) ? constant_4 : Space{});
    const Space v936_5 = subtract(constant_2,v936_4);
    Space v936_8;
    if (!v936_5.empty()) {
      const Path v937_6 = concat_path(p0,v935_12_head);
      Space v937_7_result;
      for (int v937_7_label = 1; v937_7_label <= 2; ++v937_7_label) {
        const Space v937_7_tail = child(v935_12_tail,v937_7_label);
        if (v937_7_tail.empty()) continue;
        const Path v937_7_head{v937_7_label};
        const Space v938_2 = singleton(v937_7_head);
        const Space v938_3 = intersect(constant_3,v938_2);
        const Space v938_4 = (has_head(v938_3) ? constant_4 : Space{});
        const Space v938_5 = subtract(constant_2,v938_4);
        Space v938_8;
        if (!v938_5.empty()) {
          const Path v939_6 = concat_path(v937_6,v937_7_head);
          const Space v939_7 = routine_140(c, v939_6, p1, v937_7_tail);
          v938_8 = compose(v938_5,v939_7);
        }
        const Space v938_9 = intersect(constant_3,v938_2);
        const Space v938_10 = (has_head(v938_9) ? constant_4 : Space{});
        Space v938_12;
        if (!v938_10.empty()) {
          const Path v940_6 = concat_path(v937_6,v937_7_head);
          const Space v940_11 = routine_141(c, v940_6, p1, v937_7_tail);
          v938_12 = compose(v938_10,v940_11);
        }
        const Space v938_13 = unite(v938_8,v938_12);
        v937_7_result = unite(v937_7_result,v938_13);
      }
      const Space v937_7 = std::move(v937_7_result);
      v936_8 = compose(v936_5,v937_7);
    }
    const Space v936_9 = intersect(constant_3,v936_2);
    const Space v936_10 = (has_head(v936_9) ? constant_4 : Space{});
    Space v936_12;
    if (!v936_10.empty()) {
      const Path v941_6 = concat_path(p0,v935_12_head);
      Space v941_11_result;
      for (int v941_11_label = 1; v941_11_label <= 2; ++v941_11_label) {
        const Space v941_11_tail = child(v935_12_tail,v941_11_label);
        if (v941_11_tail.empty()) continue;
        const Path v941_11_head{v941_11_label};
        const Space v942_2 = singleton(v941_11_head);
        const Space v942_3 = intersect(constant_3,v942_2);
        const Space v942_4 = (has_head(v942_3) ? constant_4 : Space{});
        const Space v942_5 = subtract(constant_2,v942_4);
        Space v942_8;
        if (!v942_5.empty()) {
          const Path v943_6 = concat_path(v941_6,v941_11_head);
          const Space v943_7 = routine_140(c, v943_6, p1, v941_11_tail);
          v942_8 = compose(v942_5,v943_7);
        }
        const Space v942_9 = intersect(constant_3,v942_2);
        const Space v942_10 = (has_head(v942_9) ? constant_4 : Space{});
        Space v942_12;
        if (!v942_10.empty()) {
          const Path v944_6 = concat_path(v941_6,v941_11_head);
          const Space v944_11 = routine_22(c, v944_6, p1, v941_11_tail);
          v942_12 = compose(v942_10,v944_11);
        }
        const Space v942_13 = unite(v942_8,v942_12);
        v941_11_result = unite(v941_11_result,v942_13);
      }
      const Space v941_11 = std::move(v941_11_result);
      v936_12 = compose(v936_10,v941_11);
    }
    const Space v936_13 = unite(v936_8,v936_12);
    v935_12_result = unite(v935_12_result,v936_13);
  }
  const Space v935_12 = std::move(v935_12_result);
  return v935_12;
}

static Space routine_101(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v945_10_result;
  for (int v945_10_label = 1; v945_10_label <= 2; ++v945_10_label) {
    const Space v945_10_tail = child(s0,v945_10_label);
    if (v945_10_tail.empty()) continue;
    const Path v945_10_head{v945_10_label};
    const Space v946_2 = singleton(v945_10_head);
    const Space v946_3 = intersect(constant_3,v946_2);
    const Space v946_4 = (has_head(v946_3) ? constant_4 : Space{});
    const Space v946_5 = compose(v946_4,v945_10_tail);
    const Path v947_6 = concat_path(p0,v945_10_head);
    const Space v946_7 = wrap(v946_5,v947_6);
    const Space v946_8 = wrap(v946_7,p1);
    const Space v946_9 = wrap(v946_8,constant_6);
    const Space v946_10 = intersect(constant_3,v946_2);
    const Space v946_11 = (has_head(v946_10) ? constant_4 : Space{});
    const Space v946_12 = subtract(constant_2,v946_11);
    Space v946_14;
    if (!v946_12.empty()) {
      Space v948_13_result;
      for (int v948_13_label = 1; v948_13_label <= 2; ++v948_13_label) {
        const Space v948_13_tail = child(v945_10_tail,v948_13_label);
        if (v948_13_tail.empty()) continue;
        const Path v948_13_head{v948_13_label};
        const Space v949_2 = singleton(v948_13_head);
        const Space v949_3 = intersect(constant_3,v949_2);
        const Space v949_4 = (has_head(v949_3) ? constant_4 : Space{});
        const Space v949_5 = subtract(constant_2,v949_4);
        Space v949_8;
        if (!v949_5.empty()) {
          const Path v950_6 = concat_path(v947_6,v948_13_head);
          const Space v950_7 = routine_140(c, v950_6, p1, v948_13_tail);
          v949_8 = compose(v949_5,v950_7);
        }
        const Space v949_9 = intersect(constant_3,v949_2);
        const Space v949_10 = (has_head(v949_9) ? constant_4 : Space{});
        Space v949_12;
        if (!v949_10.empty()) {
          const Path v951_6 = concat_path(v947_6,v948_13_head);
          const Space v951_11 = routine_141(c, v951_6, p1, v948_13_tail);
          v949_12 = compose(v949_10,v951_11);
        }
        const Space v949_13 = unite(v949_8,v949_12);
        v948_13_result = unite(v948_13_result,v949_13);
      }
      const Space v948_13 = std::move(v948_13_result);
      v946_14 = compose(v946_12,v948_13);
    }
    const Space v946_15 = unite(v946_9,v946_14);
    v945_10_result = unite(v945_10_result,v946_15);
  }
  const Space v945_10 = std::move(v945_10_result);
  return v945_10;
}

static Space routine_102(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v952_3_result;
  for (int v952_3_label = 1; v952_3_label <= 2; ++v952_3_label) {
    const Space v952_3_tail = child(s0,v952_3_label);
    if (v952_3_tail.empty()) continue;
    const Path v952_3_head{v952_3_label};
    const Space v953_2 = Space{};
    v952_3_result = unite(v952_3_result,v953_2);
  }
  const Space v952_3 = std::move(v952_3_result);
  return v952_3;
}

static Space routine_103(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v954_7_result;
  for (int v954_7_label = 1; v954_7_label <= 2; ++v954_7_label) {
    const Space v954_7_tail = child(s0,v954_7_label);
    if (v954_7_tail.empty()) continue;
    const Path v954_7_head{v954_7_label};
    const Space v955_2 = singleton(v954_7_head);
    const Space v955_3 = intersect(constant_3,v955_2);
    const Space v955_4 = (has_head(v955_3) ? constant_4 : Space{});
    Space v955_7;
    if (!v955_4.empty()) {
      const Path v956_5 = concat_path(p0,v954_7_head);
      Space v956_6_result;
      for (int v956_6_label = 1; v956_6_label <= 2; ++v956_6_label) {
        const Space v956_6_tail = child(v954_7_tail,v956_6_label);
        if (v956_6_tail.empty()) continue;
        const Path v956_6_head{v956_6_label};
        const Space v957_2 = singleton(v956_6_head);
        const Space v957_3 = intersect(constant_3,v957_2);
        const Space v957_4 = (has_head(v957_3) ? constant_4 : Space{});
        const Space v957_5 = subtract(constant_2,v957_4);
        Space v957_7;
        if (!v957_5.empty()) {
          const Space v958_6 = routine_25(c, v956_6_head, v956_5, v956_6_tail, s1);
          v957_7 = compose(v957_5,v958_6);
        }
        const Space v957_8 = intersect(constant_3,v957_2);
        const Space v957_9 = (has_head(v957_8) ? constant_4 : Space{});
        Space v957_11;
        if (!v957_9.empty()) {
          const Space v959_10 = routine_26(c, v956_6_head, v956_5, v956_6_tail, s1);
          v957_11 = compose(v957_9,v959_10);
        }
        const Space v957_12 = unite(v957_7,v957_11);
        v956_6_result = unite(v956_6_result,v957_12);
      }
      const Space v956_6 = std::move(v956_6_result);
      v955_7 = compose(v955_4,v956_6);
    }
    v954_7_result = unite(v954_7_result,v955_7);
  }
  const Space v954_7 = std::move(v954_7_result);
  return v954_7;
}

static Space routine_104(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v960_13_result;
  for (int v960_13_label = 1; v960_13_label <= 2; ++v960_13_label) {
    const Space v960_13_tail = child(s0,v960_13_label);
    if (v960_13_tail.empty()) continue;
    const Path v960_13_head{v960_13_label};
    const Space v961_2 = singleton(v960_13_head);
    const Space v961_3 = intersect(constant_3,v961_2);
    const Space v961_4 = (has_head(v961_3) ? constant_4 : Space{});
    const Space v961_5 = subtract(constant_2,v961_4);
    Space v961_8;
    if (!v961_5.empty()) {
      const Path v962_6 = concat_path(p0,v960_13_head);
      Space v962_7_result;
      for (int v962_7_label = 1; v962_7_label <= 2; ++v962_7_label) {
        const Space v962_7_tail = child(v960_13_tail,v962_7_label);
        if (v962_7_tail.empty()) continue;
        const Path v962_7_head{v962_7_label};
        const Space v963_2 = singleton(v962_7_head);
        const Space v963_3 = intersect(constant_3,v963_2);
        const Space v963_4 = (has_head(v963_3) ? constant_4 : Space{});
        const Space v963_5 = subtract(constant_2,v963_4);
        Space v963_8;
        if (!v963_5.empty()) {
          const Path v964_6 = concat_path(v962_6,v962_7_head);
          const Space v964_7 = routine_142(c, v964_6, p1, v962_7_tail, s1);
          v963_8 = compose(v963_5,v964_7);
        }
        const Space v963_9 = intersect(constant_3,v963_2);
        const Space v963_10 = (has_head(v963_9) ? constant_4 : Space{});
        Space v963_12;
        if (!v963_10.empty()) {
          const Path v965_6 = concat_path(v962_6,v962_7_head);
          const Space v965_11 = routine_143(c, v965_6, p1, v962_7_tail, s1);
          v963_12 = compose(v963_10,v965_11);
        }
        const Space v963_13 = unite(v963_8,v963_12);
        v962_7_result = unite(v962_7_result,v963_13);
      }
      const Space v962_7 = std::move(v962_7_result);
      v961_8 = compose(v961_5,v962_7);
    }
    const Space v961_9 = intersect(constant_3,v961_2);
    const Space v961_10 = (has_head(v961_9) ? constant_4 : Space{});
    Space v961_12;
    if (!v961_10.empty()) {
      const Path v966_6 = concat_path(p0,v960_13_head);
      Space v966_11_result;
      for (int v966_11_label = 1; v966_11_label <= 2; ++v966_11_label) {
        const Space v966_11_tail = child(v960_13_tail,v966_11_label);
        if (v966_11_tail.empty()) continue;
        const Path v966_11_head{v966_11_label};
        const Space v967_2 = singleton(v966_11_head);
        const Space v967_3 = intersect(constant_3,v967_2);
        const Space v967_4 = (has_head(v967_3) ? constant_4 : Space{});
        const Space v967_5 = subtract(constant_2,v967_4);
        Space v967_8;
        if (!v967_5.empty()) {
          const Path v968_6 = concat_path(v966_6,v966_11_head);
          const Space v968_7 = routine_142(c, v968_6, p1, v966_11_tail, s1);
          v967_8 = compose(v967_5,v968_7);
        }
        const Space v967_9 = intersect(constant_3,v967_2);
        const Space v967_10 = (has_head(v967_9) ? constant_4 : Space{});
        Space v967_12;
        if (!v967_10.empty()) {
          const Path v969_6 = concat_path(v966_6,v966_11_head);
          const Space v969_11 = routine_29(c, v969_6, p1, v966_11_tail, s1);
          v967_12 = compose(v967_10,v969_11);
        }
        const Space v967_13 = unite(v967_8,v967_12);
        v966_11_result = unite(v966_11_result,v967_13);
      }
      const Space v966_11 = std::move(v966_11_result);
      v961_12 = compose(v961_10,v966_11);
    }
    const Space v961_13 = unite(v961_8,v961_12);
    v960_13_result = unite(v960_13_result,v961_13);
  }
  const Space v960_13 = std::move(v960_13_result);
  return v960_13;
}

static Space routine_105(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v970_8 = unwrap(s1,constant_5);
  const Space v970_10 = unwrap(v970_8,constant_6);
  const Space v970_11 = unwrap(v970_10,p0);
  Space v970_18_result;
  for (int v970_18_label = 1; v970_18_label <= 2; ++v970_18_label) {
    const Space v970_18_tail = child(s0,v970_18_label);
    if (v970_18_tail.empty()) continue;
    const Path v970_18_head{v970_18_label};
    const Space v971_2 = singleton(v970_18_head);
    const Space v971_3 = intersect(constant_3,v971_2);
    const Space v971_4 = (has_head(v971_3) ? constant_4 : Space{});
    const Space v971_5 = subtract(constant_2,v971_4);
    Space v971_8;
    if (!v971_5.empty()) {
      const Path v972_6 = concat_path(p0,v970_18_head);
      Space v972_7_result;
      for (int v972_7_label = 1; v972_7_label <= 2; ++v972_7_label) {
        const Space v972_7_tail = child(v970_18_tail,v972_7_label);
        if (v972_7_tail.empty()) continue;
        const Path v972_7_head{v972_7_label};
        const Space v973_2 = singleton(v972_7_head);
        const Space v973_3 = intersect(constant_3,v973_2);
        const Space v973_4 = (has_head(v973_3) ? constant_4 : Space{});
        const Space v973_5 = subtract(constant_2,v973_4);
        Space v973_8;
        if (!v973_5.empty()) {
          const Path v974_6 = concat_path(v972_6,v972_7_head);
          const Space v974_7 = routine_142(c, v974_6, p1, v972_7_tail, s1);
          v973_8 = compose(v973_5,v974_7);
        }
        const Space v973_9 = intersect(constant_3,v973_2);
        const Space v973_10 = (has_head(v973_9) ? constant_4 : Space{});
        Space v973_12;
        if (!v973_10.empty()) {
          const Path v975_6 = concat_path(v972_6,v972_7_head);
          const Space v975_11 = routine_143(c, v975_6, p1, v972_7_tail, s1);
          v973_12 = compose(v973_10,v975_11);
        }
        const Space v973_13 = unite(v973_8,v973_12);
        v972_7_result = unite(v972_7_result,v973_13);
      }
      const Space v972_7 = std::move(v972_7_result);
      v971_8 = compose(v971_5,v972_7);
    }
    const Space v971_9 = intersect(constant_3,v971_2);
    const Space v971_10 = (has_head(v971_9) ? constant_4 : Space{});
    Space v971_13;
    if (!v971_10.empty()) {
      const Space v976_11 = unwrap(v970_11,v970_18_head);
      Space v976_12_result;
      for (int v976_12_label = 1; v976_12_label <= 2; ++v976_12_label) {
        const Space v976_12_tail = child(v976_11,v976_12_label);
        if (v976_12_tail.empty()) continue;
        const Path v976_12_head{v976_12_label};
        const Space v977_2 = singleton(v976_12_head);
        const Space v977_3 = intersect(constant_3,v977_2);
        const Space v977_4 = (has_head(v977_3) ? constant_4 : Space{});
        const Space v977_5 = subtract(constant_2,v977_4);
        Space v977_7;
        if (!v977_5.empty()) {
          const Space v978_6 = routine_61(c, v976_12_head, p1, v976_12_tail);
          v977_7 = compose(v977_5,v978_6);
        }
        const Space v977_8 = intersect(constant_3,v977_2);
        const Space v977_9 = (has_head(v977_8) ? constant_4 : Space{});
        Space v977_11;
        if (!v977_9.empty()) {
          const Space v979_10 = routine_62(c, v976_12_head, p1, v976_12_tail);
          v977_11 = compose(v977_9,v979_10);
        }
        const Space v977_12 = unite(v977_7,v977_11);
        v976_12_result = unite(v976_12_result,v977_12);
      }
      const Space v976_12 = std::move(v976_12_result);
      v971_13 = compose(v971_10,v976_12);
    }
    const Space v971_14 = unite(v971_8,v971_13);
    v970_18_result = unite(v970_18_result,v971_14);
  }
  const Space v970_18 = std::move(v970_18_result);
  return v970_18;
}

static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v980_12_result;
  for (int v980_12_label = 1; v980_12_label <= 2; ++v980_12_label) {
    const Space v980_12_tail = child(s0,v980_12_label);
    if (v980_12_tail.empty()) continue;
    const Path v980_12_head{v980_12_label};
    const Space v981_2 = singleton(v980_12_head);
    const Space v981_3 = intersect(constant_3,v981_2);
    const Space v981_4 = (has_head(v981_3) ? constant_4 : Space{});
    const Space v981_5 = subtract(constant_2,v981_4);
    Space v981_8;
    if (!v981_5.empty()) {
      const Path v982_6 = concat_path(p0,v980_12_head);
      Space v982_7_result;
      for (int v982_7_label = 1; v982_7_label <= 2; ++v982_7_label) {
        const Space v982_7_tail = child(v980_12_tail,v982_7_label);
        if (v982_7_tail.empty()) continue;
        const Path v982_7_head{v982_7_label};
        const Space v983_2 = singleton(v982_7_head);
        const Space v983_3 = intersect(constant_3,v983_2);
        const Space v983_4 = (has_head(v983_3) ? constant_4 : Space{});
        const Space v983_5 = subtract(constant_2,v983_4);
        Space v983_8;
        if (!v983_5.empty()) {
          const Path v984_6 = concat_path(v982_6,v982_7_head);
          const Space v984_7 = routine_144(c, v984_6, p1, v982_7_tail);
          v983_8 = compose(v983_5,v984_7);
        }
        const Space v983_9 = intersect(constant_3,v983_2);
        const Space v983_10 = (has_head(v983_9) ? constant_4 : Space{});
        Space v983_12;
        if (!v983_10.empty()) {
          const Path v985_6 = concat_path(v982_6,v982_7_head);
          const Space v985_11 = routine_145(c, v985_6, p1, v982_7_tail);
          v983_12 = compose(v983_10,v985_11);
        }
        const Space v983_13 = unite(v983_8,v983_12);
        v982_7_result = unite(v982_7_result,v983_13);
      }
      const Space v982_7 = std::move(v982_7_result);
      v981_8 = compose(v981_5,v982_7);
    }
    const Space v981_9 = intersect(constant_3,v981_2);
    const Space v981_10 = (has_head(v981_9) ? constant_4 : Space{});
    Space v981_12;
    if (!v981_10.empty()) {
      const Path v986_6 = concat_path(p0,v980_12_head);
      Space v986_11_result;
      for (int v986_11_label = 1; v986_11_label <= 2; ++v986_11_label) {
        const Space v986_11_tail = child(v980_12_tail,v986_11_label);
        if (v986_11_tail.empty()) continue;
        const Path v986_11_head{v986_11_label};
        const Space v987_2 = singleton(v986_11_head);
        const Space v987_3 = intersect(constant_3,v987_2);
        const Space v987_4 = (has_head(v987_3) ? constant_4 : Space{});
        const Space v987_5 = subtract(constant_2,v987_4);
        Space v987_8;
        if (!v987_5.empty()) {
          const Path v988_6 = concat_path(v986_6,v986_11_head);
          const Space v988_7 = routine_144(c, v988_6, p1, v986_11_tail);
          v987_8 = compose(v987_5,v988_7);
        }
        const Space v987_9 = intersect(constant_3,v987_2);
        const Space v987_10 = (has_head(v987_9) ? constant_4 : Space{});
        Space v987_12;
        if (!v987_10.empty()) {
          const Path v989_6 = concat_path(v986_6,v986_11_head);
          const Space v989_11 = routine_67(c, v989_6, p1, v986_11_tail);
          v987_12 = compose(v987_10,v989_11);
        }
        const Space v987_13 = unite(v987_8,v987_12);
        v986_11_result = unite(v986_11_result,v987_13);
      }
      const Space v986_11 = std::move(v986_11_result);
      v981_12 = compose(v981_10,v986_11);
    }
    const Space v981_13 = unite(v981_8,v981_12);
    v980_12_result = unite(v980_12_result,v981_13);
  }
  const Space v980_12 = std::move(v980_12_result);
  return v980_12;
}

static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v990_9_result;
  for (int v990_9_label = 1; v990_9_label <= 2; ++v990_9_label) {
    const Space v990_9_tail = child(s0,v990_9_label);
    if (v990_9_tail.empty()) continue;
    const Path v990_9_head{v990_9_label};
    const Space v991_2 = singleton(v990_9_head);
    const Space v991_3 = intersect(constant_3,v991_2);
    const Space v991_4 = (has_head(v991_3) ? constant_4 : Space{});
    const Space v991_5 = subtract(constant_2,v991_4);
    Space v991_8;
    if (!v991_5.empty()) {
      const Path v992_6 = concat_path(p0,v990_9_head);
      Space v992_7_result;
      for (int v992_7_label = 1; v992_7_label <= 2; ++v992_7_label) {
        const Space v992_7_tail = child(v990_9_tail,v992_7_label);
        if (v992_7_tail.empty()) continue;
        const Path v992_7_head{v992_7_label};
        const Space v993_2 = singleton(v992_7_head);
        const Space v993_3 = intersect(constant_3,v993_2);
        const Space v993_4 = (has_head(v993_3) ? constant_4 : Space{});
        const Space v993_5 = subtract(constant_2,v993_4);
        Space v993_8;
        if (!v993_5.empty()) {
          const Path v994_6 = concat_path(v992_6,v992_7_head);
          const Space v994_7 = routine_144(c, v994_6, p1, v992_7_tail);
          v993_8 = compose(v993_5,v994_7);
        }
        const Space v993_9 = intersect(constant_3,v993_2);
        const Space v993_10 = (has_head(v993_9) ? constant_4 : Space{});
        Space v993_12;
        if (!v993_10.empty()) {
          const Path v995_6 = concat_path(v992_6,v992_7_head);
          const Space v995_11 = routine_145(c, v995_6, p1, v992_7_tail);
          v993_12 = compose(v993_10,v995_11);
        }
        const Space v993_13 = unite(v993_8,v993_12);
        v992_7_result = unite(v992_7_result,v993_13);
      }
      const Space v992_7 = std::move(v992_7_result);
      v991_8 = compose(v991_5,v992_7);
    }
    const Space v991_9 = intersect(constant_3,v991_2);
    const Space v991_10 = (has_head(v991_9) ? constant_4 : Space{});
    const Space v991_11 = compose(v991_10,v990_9_tail);
    const Path v996_6 = concat_path(p0,v990_9_head);
    const Space v991_12 = wrap(v991_11,v996_6);
    const Space v991_13 = wrap(v991_12,p1);
    const Space v991_14 = unite(v991_8,v991_13);
    v990_9_result = unite(v990_9_result,v991_14);
  }
  const Space v990_9 = std::move(v990_9_result);
  return v990_9;
}

static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v997_13_result;
  for (int v997_13_label = 1; v997_13_label <= 2; ++v997_13_label) {
    const Space v997_13_tail = child(s0,v997_13_label);
    if (v997_13_tail.empty()) continue;
    const Path v997_13_head{v997_13_label};
    const Space v998_2 = singleton(v997_13_head);
    const Space v998_3 = intersect(constant_3,v998_2);
    const Space v998_4 = (has_head(v998_3) ? constant_4 : Space{});
    const Space v998_5 = subtract(constant_2,v998_4);
    Space v998_8;
    if (!v998_5.empty()) {
      const Path v999_6 = concat_path(p0,v997_13_head);
      Space v999_7_result;
      for (int v999_7_label = 1; v999_7_label <= 2; ++v999_7_label) {
        const Space v999_7_tail = child(v997_13_tail,v999_7_label);
        if (v999_7_tail.empty()) continue;
        const Path v999_7_head{v999_7_label};
        const Space v1000_2 = singleton(v999_7_head);
        const Space v1000_3 = intersect(constant_3,v1000_2);
        const Space v1000_4 = (has_head(v1000_3) ? constant_4 : Space{});
        const Space v1000_5 = subtract(constant_2,v1000_4);
        Space v1000_8;
        if (!v1000_5.empty()) {
          const Path v1001_6 = concat_path(v999_6,v999_7_head);
          const Space v1001_7 = routine_146(c, v1001_6, p1, v999_7_tail, s1);
          v1000_8 = compose(v1000_5,v1001_7);
        }
        const Space v1000_9 = intersect(constant_3,v1000_2);
        const Space v1000_10 = (has_head(v1000_9) ? constant_4 : Space{});
        Space v1000_12;
        if (!v1000_10.empty()) {
          const Path v1002_6 = concat_path(v999_6,v999_7_head);
          const Space v1002_11 = routine_147(c, v1002_6, p1, v999_7_tail, s1);
          v1000_12 = compose(v1000_10,v1002_11);
        }
        const Space v1000_13 = unite(v1000_8,v1000_12);
        v999_7_result = unite(v999_7_result,v1000_13);
      }
      const Space v999_7 = std::move(v999_7_result);
      v998_8 = compose(v998_5,v999_7);
    }
    const Space v998_9 = intersect(constant_3,v998_2);
    const Space v998_10 = (has_head(v998_9) ? constant_4 : Space{});
    Space v998_12;
    if (!v998_10.empty()) {
      const Path v1003_6 = concat_path(p0,v997_13_head);
      Space v1003_11_result;
      for (int v1003_11_label = 1; v1003_11_label <= 2; ++v1003_11_label) {
        const Space v1003_11_tail = child(v997_13_tail,v1003_11_label);
        if (v1003_11_tail.empty()) continue;
        const Path v1003_11_head{v1003_11_label};
        const Space v1004_2 = singleton(v1003_11_head);
        const Space v1004_3 = intersect(constant_3,v1004_2);
        const Space v1004_4 = (has_head(v1004_3) ? constant_4 : Space{});
        const Space v1004_5 = subtract(constant_2,v1004_4);
        Space v1004_8;
        if (!v1004_5.empty()) {
          const Path v1005_6 = concat_path(v1003_6,v1003_11_head);
          const Space v1005_7 = routine_146(c, v1005_6, p1, v1003_11_tail, s1);
          v1004_8 = compose(v1004_5,v1005_7);
        }
        const Space v1004_9 = intersect(constant_3,v1004_2);
        const Space v1004_10 = (has_head(v1004_9) ? constant_4 : Space{});
        Space v1004_12;
        if (!v1004_10.empty()) {
          const Path v1006_6 = concat_path(v1003_6,v1003_11_head);
          const Space v1006_11 = routine_29(c, v1006_6, p1, v1003_11_tail, s1);
          v1004_12 = compose(v1004_10,v1006_11);
        }
        const Space v1004_13 = unite(v1004_8,v1004_12);
        v1003_11_result = unite(v1003_11_result,v1004_13);
      }
      const Space v1003_11 = std::move(v1003_11_result);
      v998_12 = compose(v998_10,v1003_11);
    }
    const Space v998_13 = unite(v998_8,v998_12);
    v997_13_result = unite(v997_13_result,v998_13);
  }
  const Space v997_13 = std::move(v997_13_result);
  return v997_13;
}

static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1007_8 = unwrap(s1,constant_5);
  const Space v1007_10 = unwrap(v1007_8,constant_6);
  const Space v1007_11 = unwrap(v1007_10,p0);
  Space v1007_18_result;
  for (int v1007_18_label = 1; v1007_18_label <= 2; ++v1007_18_label) {
    const Space v1007_18_tail = child(s0,v1007_18_label);
    if (v1007_18_tail.empty()) continue;
    const Path v1007_18_head{v1007_18_label};
    const Space v1008_2 = singleton(v1007_18_head);
    const Space v1008_3 = intersect(constant_3,v1008_2);
    const Space v1008_4 = (has_head(v1008_3) ? constant_4 : Space{});
    const Space v1008_5 = subtract(constant_2,v1008_4);
    Space v1008_8;
    if (!v1008_5.empty()) {
      const Path v1009_6 = concat_path(p0,v1007_18_head);
      Space v1009_7_result;
      for (int v1009_7_label = 1; v1009_7_label <= 2; ++v1009_7_label) {
        const Space v1009_7_tail = child(v1007_18_tail,v1009_7_label);
        if (v1009_7_tail.empty()) continue;
        const Path v1009_7_head{v1009_7_label};
        const Space v1010_2 = singleton(v1009_7_head);
        const Space v1010_3 = intersect(constant_3,v1010_2);
        const Space v1010_4 = (has_head(v1010_3) ? constant_4 : Space{});
        const Space v1010_5 = subtract(constant_2,v1010_4);
        Space v1010_8;
        if (!v1010_5.empty()) {
          const Path v1011_6 = concat_path(v1009_6,v1009_7_head);
          const Space v1011_7 = routine_146(c, v1011_6, p1, v1009_7_tail, s1);
          v1010_8 = compose(v1010_5,v1011_7);
        }
        const Space v1010_9 = intersect(constant_3,v1010_2);
        const Space v1010_10 = (has_head(v1010_9) ? constant_4 : Space{});
        Space v1010_12;
        if (!v1010_10.empty()) {
          const Path v1012_6 = concat_path(v1009_6,v1009_7_head);
          const Space v1012_11 = routine_147(c, v1012_6, p1, v1009_7_tail, s1);
          v1010_12 = compose(v1010_10,v1012_11);
        }
        const Space v1010_13 = unite(v1010_8,v1010_12);
        v1009_7_result = unite(v1009_7_result,v1010_13);
      }
      const Space v1009_7 = std::move(v1009_7_result);
      v1008_8 = compose(v1008_5,v1009_7);
    }
    const Space v1008_9 = intersect(constant_3,v1008_2);
    const Space v1008_10 = (has_head(v1008_9) ? constant_4 : Space{});
    Space v1008_13;
    if (!v1008_10.empty()) {
      const Space v1013_11 = unwrap(v1007_11,v1007_18_head);
      Space v1013_12_result;
      for (int v1013_12_label = 1; v1013_12_label <= 2; ++v1013_12_label) {
        const Space v1013_12_tail = child(v1013_11,v1013_12_label);
        if (v1013_12_tail.empty()) continue;
        const Path v1013_12_head{v1013_12_label};
        const Space v1014_2 = singleton(v1013_12_head);
        const Space v1014_3 = intersect(constant_3,v1014_2);
        const Space v1014_4 = (has_head(v1014_3) ? constant_4 : Space{});
        const Space v1014_5 = subtract(constant_2,v1014_4);
        Space v1014_7;
        if (!v1014_5.empty()) {
          const Space v1015_6 = routine_61(c, v1013_12_head, p1, v1013_12_tail);
          v1014_7 = compose(v1014_5,v1015_6);
        }
        const Space v1014_8 = intersect(constant_3,v1014_2);
        const Space v1014_9 = (has_head(v1014_8) ? constant_4 : Space{});
        Space v1014_11;
        if (!v1014_9.empty()) {
          const Space v1016_10 = routine_62(c, v1013_12_head, p1, v1013_12_tail);
          v1014_11 = compose(v1014_9,v1016_10);
        }
        const Space v1014_12 = unite(v1014_7,v1014_11);
        v1013_12_result = unite(v1013_12_result,v1014_12);
      }
      const Space v1013_12 = std::move(v1013_12_result);
      v1008_13 = compose(v1008_10,v1013_12);
    }
    const Space v1008_14 = unite(v1008_8,v1008_13);
    v1007_18_result = unite(v1007_18_result,v1008_14);
  }
  const Space v1007_18 = std::move(v1007_18_result);
  return v1007_18;
}

static Space routine_110(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1017_12_result;
  for (int v1017_12_label = 1; v1017_12_label <= 2; ++v1017_12_label) {
    const Space v1017_12_tail = child(s0,v1017_12_label);
    if (v1017_12_tail.empty()) continue;
    const Path v1017_12_head{v1017_12_label};
    const Space v1018_2 = singleton(v1017_12_head);
    const Space v1018_3 = intersect(constant_3,v1018_2);
    const Space v1018_4 = (has_head(v1018_3) ? constant_4 : Space{});
    const Space v1018_5 = subtract(constant_2,v1018_4);
    Space v1018_8;
    if (!v1018_5.empty()) {
      const Path v1019_6 = concat_path(p0,v1017_12_head);
      Space v1019_7_result;
      for (int v1019_7_label = 1; v1019_7_label <= 2; ++v1019_7_label) {
        const Space v1019_7_tail = child(v1017_12_tail,v1019_7_label);
        if (v1019_7_tail.empty()) continue;
        const Path v1019_7_head{v1019_7_label};
        const Space v1020_2 = singleton(v1019_7_head);
        const Space v1020_3 = intersect(constant_3,v1020_2);
        const Space v1020_4 = (has_head(v1020_3) ? constant_4 : Space{});
        const Space v1020_5 = subtract(constant_2,v1020_4);
        Space v1020_8;
        if (!v1020_5.empty()) {
          const Path v1021_6 = concat_path(v1019_6,v1019_7_head);
          const Space v1021_7 = routine_148(c, v1021_6, p1, v1019_7_tail);
          v1020_8 = compose(v1020_5,v1021_7);
        }
        const Space v1020_9 = intersect(constant_3,v1020_2);
        const Space v1020_10 = (has_head(v1020_9) ? constant_4 : Space{});
        Space v1020_12;
        if (!v1020_10.empty()) {
          const Path v1022_6 = concat_path(v1019_6,v1019_7_head);
          const Space v1022_11 = routine_149(c, v1022_6, p1, v1019_7_tail);
          v1020_12 = compose(v1020_10,v1022_11);
        }
        const Space v1020_13 = unite(v1020_8,v1020_12);
        v1019_7_result = unite(v1019_7_result,v1020_13);
      }
      const Space v1019_7 = std::move(v1019_7_result);
      v1018_8 = compose(v1018_5,v1019_7);
    }
    const Space v1018_9 = intersect(constant_3,v1018_2);
    const Space v1018_10 = (has_head(v1018_9) ? constant_4 : Space{});
    Space v1018_12;
    if (!v1018_10.empty()) {
      const Path v1023_6 = concat_path(p0,v1017_12_head);
      Space v1023_11_result;
      for (int v1023_11_label = 1; v1023_11_label <= 2; ++v1023_11_label) {
        const Space v1023_11_tail = child(v1017_12_tail,v1023_11_label);
        if (v1023_11_tail.empty()) continue;
        const Path v1023_11_head{v1023_11_label};
        const Space v1024_2 = singleton(v1023_11_head);
        const Space v1024_3 = intersect(constant_3,v1024_2);
        const Space v1024_4 = (has_head(v1024_3) ? constant_4 : Space{});
        const Space v1024_5 = subtract(constant_2,v1024_4);
        Space v1024_8;
        if (!v1024_5.empty()) {
          const Path v1025_6 = concat_path(v1023_6,v1023_11_head);
          const Space v1025_7 = routine_148(c, v1025_6, p1, v1023_11_tail);
          v1024_8 = compose(v1024_5,v1025_7);
        }
        const Space v1024_9 = intersect(constant_3,v1024_2);
        const Space v1024_10 = (has_head(v1024_9) ? constant_4 : Space{});
        Space v1024_12;
        if (!v1024_10.empty()) {
          const Path v1026_6 = concat_path(v1023_6,v1023_11_head);
          const Space v1026_11 = routine_67(c, v1026_6, p1, v1023_11_tail);
          v1024_12 = compose(v1024_10,v1026_11);
        }
        const Space v1024_13 = unite(v1024_8,v1024_12);
        v1023_11_result = unite(v1023_11_result,v1024_13);
      }
      const Space v1023_11 = std::move(v1023_11_result);
      v1018_12 = compose(v1018_10,v1023_11);
    }
    const Space v1018_13 = unite(v1018_8,v1018_12);
    v1017_12_result = unite(v1017_12_result,v1018_13);
  }
  const Space v1017_12 = std::move(v1017_12_result);
  return v1017_12;
}

static Space routine_111(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1027_9_result;
  for (int v1027_9_label = 1; v1027_9_label <= 2; ++v1027_9_label) {
    const Space v1027_9_tail = child(s0,v1027_9_label);
    if (v1027_9_tail.empty()) continue;
    const Path v1027_9_head{v1027_9_label};
    const Space v1028_2 = singleton(v1027_9_head);
    const Space v1028_3 = intersect(constant_3,v1028_2);
    const Space v1028_4 = (has_head(v1028_3) ? constant_4 : Space{});
    const Space v1028_5 = subtract(constant_2,v1028_4);
    Space v1028_8;
    if (!v1028_5.empty()) {
      const Path v1029_6 = concat_path(p0,v1027_9_head);
      Space v1029_7_result;
      for (int v1029_7_label = 1; v1029_7_label <= 2; ++v1029_7_label) {
        const Space v1029_7_tail = child(v1027_9_tail,v1029_7_label);
        if (v1029_7_tail.empty()) continue;
        const Path v1029_7_head{v1029_7_label};
        const Space v1030_2 = singleton(v1029_7_head);
        const Space v1030_3 = intersect(constant_3,v1030_2);
        const Space v1030_4 = (has_head(v1030_3) ? constant_4 : Space{});
        const Space v1030_5 = subtract(constant_2,v1030_4);
        Space v1030_8;
        if (!v1030_5.empty()) {
          const Path v1031_6 = concat_path(v1029_6,v1029_7_head);
          const Space v1031_7 = routine_148(c, v1031_6, p1, v1029_7_tail);
          v1030_8 = compose(v1030_5,v1031_7);
        }
        const Space v1030_9 = intersect(constant_3,v1030_2);
        const Space v1030_10 = (has_head(v1030_9) ? constant_4 : Space{});
        Space v1030_12;
        if (!v1030_10.empty()) {
          const Path v1032_6 = concat_path(v1029_6,v1029_7_head);
          const Space v1032_11 = routine_149(c, v1032_6, p1, v1029_7_tail);
          v1030_12 = compose(v1030_10,v1032_11);
        }
        const Space v1030_13 = unite(v1030_8,v1030_12);
        v1029_7_result = unite(v1029_7_result,v1030_13);
      }
      const Space v1029_7 = std::move(v1029_7_result);
      v1028_8 = compose(v1028_5,v1029_7);
    }
    const Space v1028_9 = intersect(constant_3,v1028_2);
    const Space v1028_10 = (has_head(v1028_9) ? constant_4 : Space{});
    const Space v1028_11 = compose(v1028_10,v1027_9_tail);
    const Path v1033_6 = concat_path(p0,v1027_9_head);
    const Space v1028_12 = wrap(v1028_11,v1033_6);
    const Space v1028_13 = wrap(v1028_12,p1);
    const Space v1028_14 = unite(v1028_8,v1028_13);
    v1027_9_result = unite(v1027_9_result,v1028_14);
  }
  const Space v1027_9 = std::move(v1027_9_result);
  return v1027_9;
}

static Space routine_112(Context& c, const Path& p0, const Space& s0) {
  Space v1034_2_result;
  for (int v1034_2_label = 1; v1034_2_label <= 2; ++v1034_2_label) {
    const Space v1034_2_tail = child(s0,v1034_2_label);
    if (v1034_2_tail.empty()) continue;
    const Path v1034_2_head{v1034_2_label};
    const Space v1035_2 = Space{};
    v1034_2_result = unite(v1034_2_result,v1035_2);
  }
  const Space v1034_2 = std::move(v1034_2_result);
  return v1034_2;
}

static Space routine_113(Context& c, const Path& p0, const Space& s0) {
  Space v1036_6_result;
  for (int v1036_6_label = 1; v1036_6_label <= 2; ++v1036_6_label) {
    const Space v1036_6_tail = child(s0,v1036_6_label);
    if (v1036_6_tail.empty()) continue;
    const Path v1036_6_head{v1036_6_label};
    const Space v1037_2 = singleton(v1036_6_head);
    const Space v1037_3 = intersect(constant_3,v1037_2);
    const Space v1037_4 = (has_head(v1037_3) ? constant_4 : Space{});
    Space v1037_7;
    if (!v1037_4.empty()) {
      const Path v1038_5 = concat_path(p0,v1036_6_head);
      Space v1038_6_result;
      for (int v1038_6_label = 1; v1038_6_label <= 2; ++v1038_6_label) {
        const Space v1038_6_tail = child(v1036_6_tail,v1038_6_label);
        if (v1038_6_tail.empty()) continue;
        const Path v1038_6_head{v1038_6_label};
        const Space v1039_2 = singleton(v1038_6_head);
        const Space v1039_3 = intersect(constant_3,v1039_2);
        const Space v1039_4 = (has_head(v1039_3) ? constant_4 : Space{});
        const Space v1039_5 = subtract(constant_2,v1039_4);
        Space v1039_7;
        if (!v1039_5.empty()) {
          const Space v1040_6 = routine_32(c, v1038_6_head, v1038_5, v1038_6_tail);
          v1039_7 = compose(v1039_5,v1040_6);
        }
        const Space v1039_8 = intersect(constant_3,v1039_2);
        const Space v1039_9 = (has_head(v1039_8) ? constant_4 : Space{});
        Space v1039_11;
        if (!v1039_9.empty()) {
          const Space v1041_10 = routine_33(c, v1038_6_head, v1038_5, v1038_6_tail);
          v1039_11 = compose(v1039_9,v1041_10);
        }
        const Space v1039_12 = unite(v1039_7,v1039_11);
        v1038_6_result = unite(v1038_6_result,v1039_12);
      }
      const Space v1038_6 = std::move(v1038_6_result);
      v1037_7 = compose(v1037_4,v1038_6);
    }
    v1036_6_result = unite(v1036_6_result,v1037_7);
  }
  const Space v1036_6 = std::move(v1036_6_result);
  return v1036_6;
}

static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1042_12_result;
  for (int v1042_12_label = 1; v1042_12_label <= 2; ++v1042_12_label) {
    const Space v1042_12_tail = child(s0,v1042_12_label);
    if (v1042_12_tail.empty()) continue;
    const Path v1042_12_head{v1042_12_label};
    const Space v1043_2 = singleton(v1042_12_head);
    const Space v1043_3 = intersect(constant_3,v1043_2);
    const Space v1043_4 = (has_head(v1043_3) ? constant_4 : Space{});
    const Space v1043_5 = subtract(constant_2,v1043_4);
    Space v1043_8;
    if (!v1043_5.empty()) {
      const Path v1044_6 = concat_path(p0,v1042_12_head);
      Space v1044_7_result;
      for (int v1044_7_label = 1; v1044_7_label <= 2; ++v1044_7_label) {
        const Space v1044_7_tail = child(v1042_12_tail,v1044_7_label);
        if (v1044_7_tail.empty()) continue;
        const Path v1044_7_head{v1044_7_label};
        const Space v1045_2 = singleton(v1044_7_head);
        const Space v1045_3 = intersect(constant_3,v1045_2);
        const Space v1045_4 = (has_head(v1045_3) ? constant_4 : Space{});
        const Space v1045_5 = subtract(constant_2,v1045_4);
        Space v1045_8;
        if (!v1045_5.empty()) {
          const Path v1046_6 = concat_path(v1044_6,v1044_7_head);
          const Space v1046_7 = routine_150(c, v1046_6, p1, v1044_7_tail);
          v1045_8 = compose(v1045_5,v1046_7);
        }
        const Space v1045_9 = intersect(constant_3,v1045_2);
        const Space v1045_10 = (has_head(v1045_9) ? constant_4 : Space{});
        Space v1045_12;
        if (!v1045_10.empty()) {
          const Path v1047_6 = concat_path(v1044_6,v1044_7_head);
          const Space v1047_11 = routine_151(c, v1047_6, p1, v1044_7_tail);
          v1045_12 = compose(v1045_10,v1047_11);
        }
        const Space v1045_13 = unite(v1045_8,v1045_12);
        v1044_7_result = unite(v1044_7_result,v1045_13);
      }
      const Space v1044_7 = std::move(v1044_7_result);
      v1043_8 = compose(v1043_5,v1044_7);
    }
    const Space v1043_9 = intersect(constant_3,v1043_2);
    const Space v1043_10 = (has_head(v1043_9) ? constant_4 : Space{});
    Space v1043_12;
    if (!v1043_10.empty()) {
      const Path v1048_6 = concat_path(p0,v1042_12_head);
      Space v1048_11_result;
      for (int v1048_11_label = 1; v1048_11_label <= 2; ++v1048_11_label) {
        const Space v1048_11_tail = child(v1042_12_tail,v1048_11_label);
        if (v1048_11_tail.empty()) continue;
        const Path v1048_11_head{v1048_11_label};
        const Space v1049_2 = singleton(v1048_11_head);
        const Space v1049_3 = intersect(constant_3,v1049_2);
        const Space v1049_4 = (has_head(v1049_3) ? constant_4 : Space{});
        const Space v1049_5 = subtract(constant_2,v1049_4);
        Space v1049_8;
        if (!v1049_5.empty()) {
          const Path v1050_6 = concat_path(v1048_6,v1048_11_head);
          const Space v1050_7 = routine_150(c, v1050_6, p1, v1048_11_tail);
          v1049_8 = compose(v1049_5,v1050_7);
        }
        const Space v1049_9 = intersect(constant_3,v1049_2);
        const Space v1049_10 = (has_head(v1049_9) ? constant_4 : Space{});
        Space v1049_12;
        if (!v1049_10.empty()) {
          const Path v1051_6 = concat_path(v1048_6,v1048_11_head);
          const Space v1051_11 = routine_36(c, v1051_6, p1, v1048_11_tail);
          v1049_12 = compose(v1049_10,v1051_11);
        }
        const Space v1049_13 = unite(v1049_8,v1049_12);
        v1048_11_result = unite(v1048_11_result,v1049_13);
      }
      const Space v1048_11 = std::move(v1048_11_result);
      v1043_12 = compose(v1043_10,v1048_11);
    }
    const Space v1043_13 = unite(v1043_8,v1043_12);
    v1042_12_result = unite(v1042_12_result,v1043_13);
  }
  const Space v1042_12 = std::move(v1042_12_result);
  return v1042_12;
}

static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1052_9_result;
  for (int v1052_9_label = 1; v1052_9_label <= 2; ++v1052_9_label) {
    const Space v1052_9_tail = child(s0,v1052_9_label);
    if (v1052_9_tail.empty()) continue;
    const Path v1052_9_head{v1052_9_label};
    const Space v1053_2 = singleton(v1052_9_head);
    const Space v1053_3 = intersect(constant_3,v1053_2);
    const Space v1053_4 = (has_head(v1053_3) ? constant_4 : Space{});
    const Space v1053_5 = subtract(constant_2,v1053_4);
    Space v1053_8;
    if (!v1053_5.empty()) {
      const Path v1054_6 = concat_path(p0,v1052_9_head);
      Space v1054_7_result;
      for (int v1054_7_label = 1; v1054_7_label <= 2; ++v1054_7_label) {
        const Space v1054_7_tail = child(v1052_9_tail,v1054_7_label);
        if (v1054_7_tail.empty()) continue;
        const Path v1054_7_head{v1054_7_label};
        const Space v1055_2 = singleton(v1054_7_head);
        const Space v1055_3 = intersect(constant_3,v1055_2);
        const Space v1055_4 = (has_head(v1055_3) ? constant_4 : Space{});
        const Space v1055_5 = subtract(constant_2,v1055_4);
        Space v1055_8;
        if (!v1055_5.empty()) {
          const Path v1056_6 = concat_path(v1054_6,v1054_7_head);
          const Space v1056_7 = routine_150(c, v1056_6, p1, v1054_7_tail);
          v1055_8 = compose(v1055_5,v1056_7);
        }
        const Space v1055_9 = intersect(constant_3,v1055_2);
        const Space v1055_10 = (has_head(v1055_9) ? constant_4 : Space{});
        Space v1055_12;
        if (!v1055_10.empty()) {
          const Path v1057_6 = concat_path(v1054_6,v1054_7_head);
          const Space v1057_11 = routine_151(c, v1057_6, p1, v1054_7_tail);
          v1055_12 = compose(v1055_10,v1057_11);
        }
        const Space v1055_13 = unite(v1055_8,v1055_12);
        v1054_7_result = unite(v1054_7_result,v1055_13);
      }
      const Space v1054_7 = std::move(v1054_7_result);
      v1053_8 = compose(v1053_5,v1054_7);
    }
    const Space v1053_9 = intersect(constant_3,v1053_2);
    const Space v1053_10 = (has_head(v1053_9) ? constant_4 : Space{});
    const Space v1053_11 = compose(v1053_10,v1052_9_tail);
    const Path v1058_6 = concat_path(p0,v1052_9_head);
    const Space v1053_12 = wrap(v1053_11,v1058_6);
    const Space v1053_13 = wrap(v1053_12,p1);
    const Space v1053_14 = unite(v1053_8,v1053_13);
    v1052_9_result = unite(v1052_9_result,v1053_14);
  }
  const Space v1052_9 = std::move(v1052_9_result);
  return v1052_9;
}

static Space routine_116(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1059_12_result;
  for (int v1059_12_label = 1; v1059_12_label <= 2; ++v1059_12_label) {
    const Space v1059_12_tail = child(s0,v1059_12_label);
    if (v1059_12_tail.empty()) continue;
    const Path v1059_12_head{v1059_12_label};
    const Space v1060_2 = singleton(v1059_12_head);
    const Space v1060_3 = intersect(constant_3,v1060_2);
    const Space v1060_4 = (has_head(v1060_3) ? constant_4 : Space{});
    const Space v1060_5 = subtract(constant_2,v1060_4);
    Space v1060_8;
    if (!v1060_5.empty()) {
      const Path v1061_6 = concat_path(p0,v1059_12_head);
      Space v1061_7_result;
      for (int v1061_7_label = 1; v1061_7_label <= 2; ++v1061_7_label) {
        const Space v1061_7_tail = child(v1059_12_tail,v1061_7_label);
        if (v1061_7_tail.empty()) continue;
        const Path v1061_7_head{v1061_7_label};
        const Space v1062_2 = singleton(v1061_7_head);
        const Space v1062_3 = intersect(constant_3,v1062_2);
        const Space v1062_4 = (has_head(v1062_3) ? constant_4 : Space{});
        const Space v1062_5 = subtract(constant_2,v1062_4);
        Space v1062_8;
        if (!v1062_5.empty()) {
          const Path v1063_6 = concat_path(v1061_6,v1061_7_head);
          const Space v1063_7 = routine_152(c, v1063_6, p1, v1061_7_tail);
          v1062_8 = compose(v1062_5,v1063_7);
        }
        const Space v1062_9 = intersect(constant_3,v1062_2);
        const Space v1062_10 = (has_head(v1062_9) ? constant_4 : Space{});
        Space v1062_12;
        if (!v1062_10.empty()) {
          const Path v1064_6 = concat_path(v1061_6,v1061_7_head);
          const Space v1064_11 = routine_153(c, v1064_6, p1, v1061_7_tail);
          v1062_12 = compose(v1062_10,v1064_11);
        }
        const Space v1062_13 = unite(v1062_8,v1062_12);
        v1061_7_result = unite(v1061_7_result,v1062_13);
      }
      const Space v1061_7 = std::move(v1061_7_result);
      v1060_8 = compose(v1060_5,v1061_7);
    }
    const Space v1060_9 = intersect(constant_3,v1060_2);
    const Space v1060_10 = (has_head(v1060_9) ? constant_4 : Space{});
    Space v1060_12;
    if (!v1060_10.empty()) {
      const Path v1065_6 = concat_path(p0,v1059_12_head);
      Space v1065_11_result;
      for (int v1065_11_label = 1; v1065_11_label <= 2; ++v1065_11_label) {
        const Space v1065_11_tail = child(v1059_12_tail,v1065_11_label);
        if (v1065_11_tail.empty()) continue;
        const Path v1065_11_head{v1065_11_label};
        const Space v1066_2 = singleton(v1065_11_head);
        const Space v1066_3 = intersect(constant_3,v1066_2);
        const Space v1066_4 = (has_head(v1066_3) ? constant_4 : Space{});
        const Space v1066_5 = subtract(constant_2,v1066_4);
        Space v1066_8;
        if (!v1066_5.empty()) {
          const Path v1067_6 = concat_path(v1065_6,v1065_11_head);
          const Space v1067_7 = routine_152(c, v1067_6, p1, v1065_11_tail);
          v1066_8 = compose(v1066_5,v1067_7);
        }
        const Space v1066_9 = intersect(constant_3,v1066_2);
        const Space v1066_10 = (has_head(v1066_9) ? constant_4 : Space{});
        Space v1066_12;
        if (!v1066_10.empty()) {
          const Path v1068_6 = concat_path(v1065_6,v1065_11_head);
          const Space v1068_11 = routine_36(c, v1068_6, p1, v1065_11_tail);
          v1066_12 = compose(v1066_10,v1068_11);
        }
        const Space v1066_13 = unite(v1066_8,v1066_12);
        v1065_11_result = unite(v1065_11_result,v1066_13);
      }
      const Space v1065_11 = std::move(v1065_11_result);
      v1060_12 = compose(v1060_10,v1065_11);
    }
    const Space v1060_13 = unite(v1060_8,v1060_12);
    v1059_12_result = unite(v1059_12_result,v1060_13);
  }
  const Space v1059_12 = std::move(v1059_12_result);
  return v1059_12;
}

static Space routine_117(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1069_9_result;
  for (int v1069_9_label = 1; v1069_9_label <= 2; ++v1069_9_label) {
    const Space v1069_9_tail = child(s0,v1069_9_label);
    if (v1069_9_tail.empty()) continue;
    const Path v1069_9_head{v1069_9_label};
    const Space v1070_2 = singleton(v1069_9_head);
    const Space v1070_3 = intersect(constant_3,v1070_2);
    const Space v1070_4 = (has_head(v1070_3) ? constant_4 : Space{});
    const Space v1070_5 = subtract(constant_2,v1070_4);
    Space v1070_8;
    if (!v1070_5.empty()) {
      const Path v1071_6 = concat_path(p0,v1069_9_head);
      Space v1071_7_result;
      for (int v1071_7_label = 1; v1071_7_label <= 2; ++v1071_7_label) {
        const Space v1071_7_tail = child(v1069_9_tail,v1071_7_label);
        if (v1071_7_tail.empty()) continue;
        const Path v1071_7_head{v1071_7_label};
        const Space v1072_2 = singleton(v1071_7_head);
        const Space v1072_3 = intersect(constant_3,v1072_2);
        const Space v1072_4 = (has_head(v1072_3) ? constant_4 : Space{});
        const Space v1072_5 = subtract(constant_2,v1072_4);
        Space v1072_8;
        if (!v1072_5.empty()) {
          const Path v1073_6 = concat_path(v1071_6,v1071_7_head);
          const Space v1073_7 = routine_152(c, v1073_6, p1, v1071_7_tail);
          v1072_8 = compose(v1072_5,v1073_7);
        }
        const Space v1072_9 = intersect(constant_3,v1072_2);
        const Space v1072_10 = (has_head(v1072_9) ? constant_4 : Space{});
        Space v1072_12;
        if (!v1072_10.empty()) {
          const Path v1074_6 = concat_path(v1071_6,v1071_7_head);
          const Space v1074_11 = routine_153(c, v1074_6, p1, v1071_7_tail);
          v1072_12 = compose(v1072_10,v1074_11);
        }
        const Space v1072_13 = unite(v1072_8,v1072_12);
        v1071_7_result = unite(v1071_7_result,v1072_13);
      }
      const Space v1071_7 = std::move(v1071_7_result);
      v1070_8 = compose(v1070_5,v1071_7);
    }
    const Space v1070_9 = intersect(constant_3,v1070_2);
    const Space v1070_10 = (has_head(v1070_9) ? constant_4 : Space{});
    const Space v1070_11 = compose(v1070_10,v1069_9_tail);
    const Path v1075_6 = concat_path(p0,v1069_9_head);
    const Space v1070_12 = wrap(v1070_11,v1075_6);
    const Space v1070_13 = wrap(v1070_12,p1);
    const Space v1070_14 = unite(v1070_8,v1070_13);
    v1069_9_result = unite(v1069_9_result,v1070_14);
  }
  const Space v1069_9 = std::move(v1069_9_result);
  return v1069_9;
}

static Space routine_118(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1076_3_result;
  for (int v1076_3_label = 1; v1076_3_label <= 2; ++v1076_3_label) {
    const Space v1076_3_tail = child(s0,v1076_3_label);
    if (v1076_3_tail.empty()) continue;
    const Path v1076_3_head{v1076_3_label};
    const Space v1077_2 = Space{};
    v1076_3_result = unite(v1076_3_result,v1077_2);
  }
  const Space v1076_3 = std::move(v1076_3_result);
  return v1076_3;
}

static Space routine_119(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1078_7_result;
  for (int v1078_7_label = 1; v1078_7_label <= 2; ++v1078_7_label) {
    const Space v1078_7_tail = child(s0,v1078_7_label);
    if (v1078_7_tail.empty()) continue;
    const Path v1078_7_head{v1078_7_label};
    const Space v1079_2 = singleton(v1078_7_head);
    const Space v1079_3 = intersect(constant_3,v1079_2);
    const Space v1079_4 = (has_head(v1079_3) ? constant_4 : Space{});
    Space v1079_7;
    if (!v1079_4.empty()) {
      const Path v1080_5 = concat_path(p0,v1078_7_head);
      Space v1080_6_result;
      for (int v1080_6_label = 1; v1080_6_label <= 2; ++v1080_6_label) {
        const Space v1080_6_tail = child(v1078_7_tail,v1080_6_label);
        if (v1080_6_tail.empty()) continue;
        const Path v1080_6_head{v1080_6_label};
        const Space v1081_2 = singleton(v1080_6_head);
        const Space v1081_3 = intersect(constant_3,v1081_2);
        const Space v1081_4 = (has_head(v1081_3) ? constant_4 : Space{});
        const Space v1081_5 = subtract(constant_2,v1081_4);
        Space v1081_7;
        if (!v1081_5.empty()) {
          const Space v1082_6 = routine_39(c, v1080_6_head, v1080_5, v1080_6_tail, s1);
          v1081_7 = compose(v1081_5,v1082_6);
        }
        const Space v1081_8 = intersect(constant_3,v1081_2);
        const Space v1081_9 = (has_head(v1081_8) ? constant_4 : Space{});
        Space v1081_11;
        if (!v1081_9.empty()) {
          const Space v1083_10 = routine_40(c, v1080_6_head, v1080_5, v1080_6_tail, s1);
          v1081_11 = compose(v1081_9,v1083_10);
        }
        const Space v1081_12 = unite(v1081_7,v1081_11);
        v1080_6_result = unite(v1080_6_result,v1081_12);
      }
      const Space v1080_6 = std::move(v1080_6_result);
      v1079_7 = compose(v1079_4,v1080_6);
    }
    v1078_7_result = unite(v1078_7_result,v1079_7);
  }
  const Space v1078_7 = std::move(v1078_7_result);
  return v1078_7;
}

static Space routine_120(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1084_13_result;
  for (int v1084_13_label = 1; v1084_13_label <= 2; ++v1084_13_label) {
    const Space v1084_13_tail = child(s0,v1084_13_label);
    if (v1084_13_tail.empty()) continue;
    const Path v1084_13_head{v1084_13_label};
    const Space v1085_2 = singleton(v1084_13_head);
    const Space v1085_3 = intersect(constant_3,v1085_2);
    const Space v1085_4 = (has_head(v1085_3) ? constant_4 : Space{});
    const Space v1085_5 = subtract(constant_2,v1085_4);
    Space v1085_8;
    if (!v1085_5.empty()) {
      const Path v1086_6 = concat_path(p0,v1084_13_head);
      Space v1086_7_result;
      for (int v1086_7_label = 1; v1086_7_label <= 2; ++v1086_7_label) {
        const Space v1086_7_tail = child(v1084_13_tail,v1086_7_label);
        if (v1086_7_tail.empty()) continue;
        const Path v1086_7_head{v1086_7_label};
        const Space v1087_2 = singleton(v1086_7_head);
        const Space v1087_3 = intersect(constant_3,v1087_2);
        const Space v1087_4 = (has_head(v1087_3) ? constant_4 : Space{});
        const Space v1087_5 = subtract(constant_2,v1087_4);
        Space v1087_8;
        if (!v1087_5.empty()) {
          const Path v1088_6 = concat_path(v1086_6,v1086_7_head);
          const Space v1088_7 = routine_154(c, v1088_6, p1, v1086_7_tail, s1);
          v1087_8 = compose(v1087_5,v1088_7);
        }
        const Space v1087_9 = intersect(constant_3,v1087_2);
        const Space v1087_10 = (has_head(v1087_9) ? constant_4 : Space{});
        Space v1087_12;
        if (!v1087_10.empty()) {
          const Path v1089_6 = concat_path(v1086_6,v1086_7_head);
          const Space v1089_11 = routine_155(c, v1089_6, p1, v1086_7_tail, s1);
          v1087_12 = compose(v1087_10,v1089_11);
        }
        const Space v1087_13 = unite(v1087_8,v1087_12);
        v1086_7_result = unite(v1086_7_result,v1087_13);
      }
      const Space v1086_7 = std::move(v1086_7_result);
      v1085_8 = compose(v1085_5,v1086_7);
    }
    const Space v1085_9 = intersect(constant_3,v1085_2);
    const Space v1085_10 = (has_head(v1085_9) ? constant_4 : Space{});
    Space v1085_12;
    if (!v1085_10.empty()) {
      const Path v1090_6 = concat_path(p0,v1084_13_head);
      Space v1090_11_result;
      for (int v1090_11_label = 1; v1090_11_label <= 2; ++v1090_11_label) {
        const Space v1090_11_tail = child(v1084_13_tail,v1090_11_label);
        if (v1090_11_tail.empty()) continue;
        const Path v1090_11_head{v1090_11_label};
        const Space v1091_2 = singleton(v1090_11_head);
        const Space v1091_3 = intersect(constant_3,v1091_2);
        const Space v1091_4 = (has_head(v1091_3) ? constant_4 : Space{});
        const Space v1091_5 = subtract(constant_2,v1091_4);
        Space v1091_8;
        if (!v1091_5.empty()) {
          const Path v1092_6 = concat_path(v1090_6,v1090_11_head);
          const Space v1092_7 = routine_154(c, v1092_6, p1, v1090_11_tail, s1);
          v1091_8 = compose(v1091_5,v1092_7);
        }
        const Space v1091_9 = intersect(constant_3,v1091_2);
        const Space v1091_10 = (has_head(v1091_9) ? constant_4 : Space{});
        Space v1091_12;
        if (!v1091_10.empty()) {
          const Path v1093_6 = concat_path(v1090_6,v1090_11_head);
          const Space v1093_11 = routine_43(c, v1093_6, p1, v1090_11_tail, s1);
          v1091_12 = compose(v1091_10,v1093_11);
        }
        const Space v1091_13 = unite(v1091_8,v1091_12);
        v1090_11_result = unite(v1090_11_result,v1091_13);
      }
      const Space v1090_11 = std::move(v1090_11_result);
      v1085_12 = compose(v1085_10,v1090_11);
    }
    const Space v1085_13 = unite(v1085_8,v1085_12);
    v1084_13_result = unite(v1084_13_result,v1085_13);
  }
  const Space v1084_13 = std::move(v1084_13_result);
  return v1084_13;
}

static Space routine_121(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1094_8 = unwrap(s1,constant_0);
  const Space v1094_10 = unwrap(v1094_8,constant_6);
  const Space v1094_11 = unwrap(v1094_10,p0);
  Space v1094_18_result;
  for (int v1094_18_label = 1; v1094_18_label <= 2; ++v1094_18_label) {
    const Space v1094_18_tail = child(s0,v1094_18_label);
    if (v1094_18_tail.empty()) continue;
    const Path v1094_18_head{v1094_18_label};
    const Space v1095_2 = singleton(v1094_18_head);
    const Space v1095_3 = intersect(constant_3,v1095_2);
    const Space v1095_4 = (has_head(v1095_3) ? constant_4 : Space{});
    const Space v1095_5 = subtract(constant_2,v1095_4);
    Space v1095_8;
    if (!v1095_5.empty()) {
      const Path v1096_6 = concat_path(p0,v1094_18_head);
      Space v1096_7_result;
      for (int v1096_7_label = 1; v1096_7_label <= 2; ++v1096_7_label) {
        const Space v1096_7_tail = child(v1094_18_tail,v1096_7_label);
        if (v1096_7_tail.empty()) continue;
        const Path v1096_7_head{v1096_7_label};
        const Space v1097_2 = singleton(v1096_7_head);
        const Space v1097_3 = intersect(constant_3,v1097_2);
        const Space v1097_4 = (has_head(v1097_3) ? constant_4 : Space{});
        const Space v1097_5 = subtract(constant_2,v1097_4);
        Space v1097_8;
        if (!v1097_5.empty()) {
          const Path v1098_6 = concat_path(v1096_6,v1096_7_head);
          const Space v1098_7 = routine_154(c, v1098_6, p1, v1096_7_tail, s1);
          v1097_8 = compose(v1097_5,v1098_7);
        }
        const Space v1097_9 = intersect(constant_3,v1097_2);
        const Space v1097_10 = (has_head(v1097_9) ? constant_4 : Space{});
        Space v1097_12;
        if (!v1097_10.empty()) {
          const Path v1099_6 = concat_path(v1096_6,v1096_7_head);
          const Space v1099_11 = routine_155(c, v1099_6, p1, v1096_7_tail, s1);
          v1097_12 = compose(v1097_10,v1099_11);
        }
        const Space v1097_13 = unite(v1097_8,v1097_12);
        v1096_7_result = unite(v1096_7_result,v1097_13);
      }
      const Space v1096_7 = std::move(v1096_7_result);
      v1095_8 = compose(v1095_5,v1096_7);
    }
    const Space v1095_9 = intersect(constant_3,v1095_2);
    const Space v1095_10 = (has_head(v1095_9) ? constant_4 : Space{});
    Space v1095_13;
    if (!v1095_10.empty()) {
      const Space v1100_11 = unwrap(v1094_11,v1094_18_head);
      Space v1100_12_result;
      for (int v1100_12_label = 1; v1100_12_label <= 2; ++v1100_12_label) {
        const Space v1100_12_tail = child(v1100_11,v1100_12_label);
        if (v1100_12_tail.empty()) continue;
        const Path v1100_12_head{v1100_12_label};
        const Space v1101_2 = singleton(v1100_12_head);
        const Space v1101_3 = intersect(constant_3,v1101_2);
        const Space v1101_4 = (has_head(v1101_3) ? constant_4 : Space{});
        const Space v1101_5 = subtract(constant_2,v1101_4);
        Space v1101_7;
        if (!v1101_5.empty()) {
          const Space v1102_6 = routine_78(c, v1100_12_head, p1, v1100_12_tail);
          v1101_7 = compose(v1101_5,v1102_6);
        }
        const Space v1101_8 = intersect(constant_3,v1101_2);
        const Space v1101_9 = (has_head(v1101_8) ? constant_4 : Space{});
        Space v1101_11;
        if (!v1101_9.empty()) {
          const Space v1103_10 = routine_79(c, v1100_12_head, p1, v1100_12_tail);
          v1101_11 = compose(v1101_9,v1103_10);
        }
        const Space v1101_12 = unite(v1101_7,v1101_11);
        v1100_12_result = unite(v1100_12_result,v1101_12);
      }
      const Space v1100_12 = std::move(v1100_12_result);
      v1095_13 = compose(v1095_10,v1100_12);
    }
    const Space v1095_14 = unite(v1095_8,v1095_13);
    v1094_18_result = unite(v1094_18_result,v1095_14);
  }
  const Space v1094_18 = std::move(v1094_18_result);
  return v1094_18;
}

static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1104_12_result;
  for (int v1104_12_label = 1; v1104_12_label <= 2; ++v1104_12_label) {
    const Space v1104_12_tail = child(s0,v1104_12_label);
    if (v1104_12_tail.empty()) continue;
    const Path v1104_12_head{v1104_12_label};
    const Space v1105_2 = singleton(v1104_12_head);
    const Space v1105_3 = intersect(constant_3,v1105_2);
    const Space v1105_4 = (has_head(v1105_3) ? constant_4 : Space{});
    const Space v1105_5 = subtract(constant_2,v1105_4);
    Space v1105_8;
    if (!v1105_5.empty()) {
      const Path v1106_6 = concat_path(p0,v1104_12_head);
      Space v1106_7_result;
      for (int v1106_7_label = 1; v1106_7_label <= 2; ++v1106_7_label) {
        const Space v1106_7_tail = child(v1104_12_tail,v1106_7_label);
        if (v1106_7_tail.empty()) continue;
        const Path v1106_7_head{v1106_7_label};
        const Space v1107_2 = singleton(v1106_7_head);
        const Space v1107_3 = intersect(constant_3,v1107_2);
        const Space v1107_4 = (has_head(v1107_3) ? constant_4 : Space{});
        const Space v1107_5 = subtract(constant_2,v1107_4);
        Space v1107_8;
        if (!v1107_5.empty()) {
          const Path v1108_6 = concat_path(v1106_6,v1106_7_head);
          const Space v1108_7 = routine_156(c, v1108_6, p1, v1106_7_tail);
          v1107_8 = compose(v1107_5,v1108_7);
        }
        const Space v1107_9 = intersect(constant_3,v1107_2);
        const Space v1107_10 = (has_head(v1107_9) ? constant_4 : Space{});
        Space v1107_12;
        if (!v1107_10.empty()) {
          const Path v1109_6 = concat_path(v1106_6,v1106_7_head);
          const Space v1109_11 = routine_157(c, v1109_6, p1, v1106_7_tail);
          v1107_12 = compose(v1107_10,v1109_11);
        }
        const Space v1107_13 = unite(v1107_8,v1107_12);
        v1106_7_result = unite(v1106_7_result,v1107_13);
      }
      const Space v1106_7 = std::move(v1106_7_result);
      v1105_8 = compose(v1105_5,v1106_7);
    }
    const Space v1105_9 = intersect(constant_3,v1105_2);
    const Space v1105_10 = (has_head(v1105_9) ? constant_4 : Space{});
    Space v1105_12;
    if (!v1105_10.empty()) {
      const Path v1110_6 = concat_path(p0,v1104_12_head);
      Space v1110_11_result;
      for (int v1110_11_label = 1; v1110_11_label <= 2; ++v1110_11_label) {
        const Space v1110_11_tail = child(v1104_12_tail,v1110_11_label);
        if (v1110_11_tail.empty()) continue;
        const Path v1110_11_head{v1110_11_label};
        const Space v1111_2 = singleton(v1110_11_head);
        const Space v1111_3 = intersect(constant_3,v1111_2);
        const Space v1111_4 = (has_head(v1111_3) ? constant_4 : Space{});
        const Space v1111_5 = subtract(constant_2,v1111_4);
        Space v1111_8;
        if (!v1111_5.empty()) {
          const Path v1112_6 = concat_path(v1110_6,v1110_11_head);
          const Space v1112_7 = routine_156(c, v1112_6, p1, v1110_11_tail);
          v1111_8 = compose(v1111_5,v1112_7);
        }
        const Space v1111_9 = intersect(constant_3,v1111_2);
        const Space v1111_10 = (has_head(v1111_9) ? constant_4 : Space{});
        Space v1111_12;
        if (!v1111_10.empty()) {
          const Path v1113_6 = concat_path(v1110_6,v1110_11_head);
          const Space v1113_11 = routine_84(c, v1113_6, p1, v1110_11_tail);
          v1111_12 = compose(v1111_10,v1113_11);
        }
        const Space v1111_13 = unite(v1111_8,v1111_12);
        v1110_11_result = unite(v1110_11_result,v1111_13);
      }
      const Space v1110_11 = std::move(v1110_11_result);
      v1105_12 = compose(v1105_10,v1110_11);
    }
    const Space v1105_13 = unite(v1105_8,v1105_12);
    v1104_12_result = unite(v1104_12_result,v1105_13);
  }
  const Space v1104_12 = std::move(v1104_12_result);
  return v1104_12;
}

static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1114_9_result;
  for (int v1114_9_label = 1; v1114_9_label <= 2; ++v1114_9_label) {
    const Space v1114_9_tail = child(s0,v1114_9_label);
    if (v1114_9_tail.empty()) continue;
    const Path v1114_9_head{v1114_9_label};
    const Space v1115_2 = singleton(v1114_9_head);
    const Space v1115_3 = intersect(constant_3,v1115_2);
    const Space v1115_4 = (has_head(v1115_3) ? constant_4 : Space{});
    const Space v1115_5 = subtract(constant_2,v1115_4);
    Space v1115_8;
    if (!v1115_5.empty()) {
      const Path v1116_6 = concat_path(p0,v1114_9_head);
      Space v1116_7_result;
      for (int v1116_7_label = 1; v1116_7_label <= 2; ++v1116_7_label) {
        const Space v1116_7_tail = child(v1114_9_tail,v1116_7_label);
        if (v1116_7_tail.empty()) continue;
        const Path v1116_7_head{v1116_7_label};
        const Space v1117_2 = singleton(v1116_7_head);
        const Space v1117_3 = intersect(constant_3,v1117_2);
        const Space v1117_4 = (has_head(v1117_3) ? constant_4 : Space{});
        const Space v1117_5 = subtract(constant_2,v1117_4);
        Space v1117_8;
        if (!v1117_5.empty()) {
          const Path v1118_6 = concat_path(v1116_6,v1116_7_head);
          const Space v1118_7 = routine_156(c, v1118_6, p1, v1116_7_tail);
          v1117_8 = compose(v1117_5,v1118_7);
        }
        const Space v1117_9 = intersect(constant_3,v1117_2);
        const Space v1117_10 = (has_head(v1117_9) ? constant_4 : Space{});
        Space v1117_12;
        if (!v1117_10.empty()) {
          const Path v1119_6 = concat_path(v1116_6,v1116_7_head);
          const Space v1119_11 = routine_157(c, v1119_6, p1, v1116_7_tail);
          v1117_12 = compose(v1117_10,v1119_11);
        }
        const Space v1117_13 = unite(v1117_8,v1117_12);
        v1116_7_result = unite(v1116_7_result,v1117_13);
      }
      const Space v1116_7 = std::move(v1116_7_result);
      v1115_8 = compose(v1115_5,v1116_7);
    }
    const Space v1115_9 = intersect(constant_3,v1115_2);
    const Space v1115_10 = (has_head(v1115_9) ? constant_4 : Space{});
    const Space v1115_11 = compose(v1115_10,v1114_9_tail);
    const Path v1120_6 = concat_path(p0,v1114_9_head);
    const Space v1115_12 = wrap(v1115_11,v1120_6);
    const Space v1115_13 = wrap(v1115_12,p1);
    const Space v1115_14 = unite(v1115_8,v1115_13);
    v1114_9_result = unite(v1114_9_result,v1115_14);
  }
  const Space v1114_9 = std::move(v1114_9_result);
  return v1114_9;
}

static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1121_13_result;
  for (int v1121_13_label = 1; v1121_13_label <= 2; ++v1121_13_label) {
    const Space v1121_13_tail = child(s0,v1121_13_label);
    if (v1121_13_tail.empty()) continue;
    const Path v1121_13_head{v1121_13_label};
    const Space v1122_2 = singleton(v1121_13_head);
    const Space v1122_3 = intersect(constant_3,v1122_2);
    const Space v1122_4 = (has_head(v1122_3) ? constant_4 : Space{});
    const Space v1122_5 = subtract(constant_2,v1122_4);
    Space v1122_8;
    if (!v1122_5.empty()) {
      const Path v1123_6 = concat_path(p0,v1121_13_head);
      Space v1123_7_result;
      for (int v1123_7_label = 1; v1123_7_label <= 2; ++v1123_7_label) {
        const Space v1123_7_tail = child(v1121_13_tail,v1123_7_label);
        if (v1123_7_tail.empty()) continue;
        const Path v1123_7_head{v1123_7_label};
        const Space v1124_2 = singleton(v1123_7_head);
        const Space v1124_3 = intersect(constant_3,v1124_2);
        const Space v1124_4 = (has_head(v1124_3) ? constant_4 : Space{});
        const Space v1124_5 = subtract(constant_2,v1124_4);
        Space v1124_8;
        if (!v1124_5.empty()) {
          const Path v1125_6 = concat_path(v1123_6,v1123_7_head);
          const Space v1125_7 = routine_158(c, v1125_6, p1, v1123_7_tail, s1);
          v1124_8 = compose(v1124_5,v1125_7);
        }
        const Space v1124_9 = intersect(constant_3,v1124_2);
        const Space v1124_10 = (has_head(v1124_9) ? constant_4 : Space{});
        Space v1124_12;
        if (!v1124_10.empty()) {
          const Path v1126_6 = concat_path(v1123_6,v1123_7_head);
          const Space v1126_11 = routine_159(c, v1126_6, p1, v1123_7_tail, s1);
          v1124_12 = compose(v1124_10,v1126_11);
        }
        const Space v1124_13 = unite(v1124_8,v1124_12);
        v1123_7_result = unite(v1123_7_result,v1124_13);
      }
      const Space v1123_7 = std::move(v1123_7_result);
      v1122_8 = compose(v1122_5,v1123_7);
    }
    const Space v1122_9 = intersect(constant_3,v1122_2);
    const Space v1122_10 = (has_head(v1122_9) ? constant_4 : Space{});
    Space v1122_12;
    if (!v1122_10.empty()) {
      const Path v1127_6 = concat_path(p0,v1121_13_head);
      Space v1127_11_result;
      for (int v1127_11_label = 1; v1127_11_label <= 2; ++v1127_11_label) {
        const Space v1127_11_tail = child(v1121_13_tail,v1127_11_label);
        if (v1127_11_tail.empty()) continue;
        const Path v1127_11_head{v1127_11_label};
        const Space v1128_2 = singleton(v1127_11_head);
        const Space v1128_3 = intersect(constant_3,v1128_2);
        const Space v1128_4 = (has_head(v1128_3) ? constant_4 : Space{});
        const Space v1128_5 = subtract(constant_2,v1128_4);
        Space v1128_8;
        if (!v1128_5.empty()) {
          const Path v1129_6 = concat_path(v1127_6,v1127_11_head);
          const Space v1129_7 = routine_158(c, v1129_6, p1, v1127_11_tail, s1);
          v1128_8 = compose(v1128_5,v1129_7);
        }
        const Space v1128_9 = intersect(constant_3,v1128_2);
        const Space v1128_10 = (has_head(v1128_9) ? constant_4 : Space{});
        Space v1128_12;
        if (!v1128_10.empty()) {
          const Path v1130_6 = concat_path(v1127_6,v1127_11_head);
          const Space v1130_11 = routine_43(c, v1130_6, p1, v1127_11_tail, s1);
          v1128_12 = compose(v1128_10,v1130_11);
        }
        const Space v1128_13 = unite(v1128_8,v1128_12);
        v1127_11_result = unite(v1127_11_result,v1128_13);
      }
      const Space v1127_11 = std::move(v1127_11_result);
      v1122_12 = compose(v1122_10,v1127_11);
    }
    const Space v1122_13 = unite(v1122_8,v1122_12);
    v1121_13_result = unite(v1121_13_result,v1122_13);
  }
  const Space v1121_13 = std::move(v1121_13_result);
  return v1121_13;
}

static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1131_8 = unwrap(s1,constant_0);
  const Space v1131_10 = unwrap(v1131_8,constant_6);
  const Space v1131_11 = unwrap(v1131_10,p0);
  Space v1131_18_result;
  for (int v1131_18_label = 1; v1131_18_label <= 2; ++v1131_18_label) {
    const Space v1131_18_tail = child(s0,v1131_18_label);
    if (v1131_18_tail.empty()) continue;
    const Path v1131_18_head{v1131_18_label};
    const Space v1132_2 = singleton(v1131_18_head);
    const Space v1132_3 = intersect(constant_3,v1132_2);
    const Space v1132_4 = (has_head(v1132_3) ? constant_4 : Space{});
    const Space v1132_5 = subtract(constant_2,v1132_4);
    Space v1132_8;
    if (!v1132_5.empty()) {
      const Path v1133_6 = concat_path(p0,v1131_18_head);
      Space v1133_7_result;
      for (int v1133_7_label = 1; v1133_7_label <= 2; ++v1133_7_label) {
        const Space v1133_7_tail = child(v1131_18_tail,v1133_7_label);
        if (v1133_7_tail.empty()) continue;
        const Path v1133_7_head{v1133_7_label};
        const Space v1134_2 = singleton(v1133_7_head);
        const Space v1134_3 = intersect(constant_3,v1134_2);
        const Space v1134_4 = (has_head(v1134_3) ? constant_4 : Space{});
        const Space v1134_5 = subtract(constant_2,v1134_4);
        Space v1134_8;
        if (!v1134_5.empty()) {
          const Path v1135_6 = concat_path(v1133_6,v1133_7_head);
          const Space v1135_7 = routine_158(c, v1135_6, p1, v1133_7_tail, s1);
          v1134_8 = compose(v1134_5,v1135_7);
        }
        const Space v1134_9 = intersect(constant_3,v1134_2);
        const Space v1134_10 = (has_head(v1134_9) ? constant_4 : Space{});
        Space v1134_12;
        if (!v1134_10.empty()) {
          const Path v1136_6 = concat_path(v1133_6,v1133_7_head);
          const Space v1136_11 = routine_159(c, v1136_6, p1, v1133_7_tail, s1);
          v1134_12 = compose(v1134_10,v1136_11);
        }
        const Space v1134_13 = unite(v1134_8,v1134_12);
        v1133_7_result = unite(v1133_7_result,v1134_13);
      }
      const Space v1133_7 = std::move(v1133_7_result);
      v1132_8 = compose(v1132_5,v1133_7);
    }
    const Space v1132_9 = intersect(constant_3,v1132_2);
    const Space v1132_10 = (has_head(v1132_9) ? constant_4 : Space{});
    Space v1132_13;
    if (!v1132_10.empty()) {
      const Space v1137_11 = unwrap(v1131_11,v1131_18_head);
      Space v1137_12_result;
      for (int v1137_12_label = 1; v1137_12_label <= 2; ++v1137_12_label) {
        const Space v1137_12_tail = child(v1137_11,v1137_12_label);
        if (v1137_12_tail.empty()) continue;
        const Path v1137_12_head{v1137_12_label};
        const Space v1138_2 = singleton(v1137_12_head);
        const Space v1138_3 = intersect(constant_3,v1138_2);
        const Space v1138_4 = (has_head(v1138_3) ? constant_4 : Space{});
        const Space v1138_5 = subtract(constant_2,v1138_4);
        Space v1138_7;
        if (!v1138_5.empty()) {
          const Space v1139_6 = routine_78(c, v1137_12_head, p1, v1137_12_tail);
          v1138_7 = compose(v1138_5,v1139_6);
        }
        const Space v1138_8 = intersect(constant_3,v1138_2);
        const Space v1138_9 = (has_head(v1138_8) ? constant_4 : Space{});
        Space v1138_11;
        if (!v1138_9.empty()) {
          const Space v1140_10 = routine_79(c, v1137_12_head, p1, v1137_12_tail);
          v1138_11 = compose(v1138_9,v1140_10);
        }
        const Space v1138_12 = unite(v1138_7,v1138_11);
        v1137_12_result = unite(v1137_12_result,v1138_12);
      }
      const Space v1137_12 = std::move(v1137_12_result);
      v1132_13 = compose(v1132_10,v1137_12);
    }
    const Space v1132_14 = unite(v1132_8,v1132_13);
    v1131_18_result = unite(v1131_18_result,v1132_14);
  }
  const Space v1131_18 = std::move(v1131_18_result);
  return v1131_18;
}

static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1141_12_result;
  for (int v1141_12_label = 1; v1141_12_label <= 2; ++v1141_12_label) {
    const Space v1141_12_tail = child(s0,v1141_12_label);
    if (v1141_12_tail.empty()) continue;
    const Path v1141_12_head{v1141_12_label};
    const Space v1142_2 = singleton(v1141_12_head);
    const Space v1142_3 = intersect(constant_3,v1142_2);
    const Space v1142_4 = (has_head(v1142_3) ? constant_4 : Space{});
    const Space v1142_5 = subtract(constant_2,v1142_4);
    Space v1142_8;
    if (!v1142_5.empty()) {
      const Path v1143_6 = concat_path(p0,v1141_12_head);
      Space v1143_7_result;
      for (int v1143_7_label = 1; v1143_7_label <= 2; ++v1143_7_label) {
        const Space v1143_7_tail = child(v1141_12_tail,v1143_7_label);
        if (v1143_7_tail.empty()) continue;
        const Path v1143_7_head{v1143_7_label};
        const Space v1144_2 = singleton(v1143_7_head);
        const Space v1144_3 = intersect(constant_3,v1144_2);
        const Space v1144_4 = (has_head(v1144_3) ? constant_4 : Space{});
        const Space v1144_5 = subtract(constant_2,v1144_4);
        Space v1144_8;
        if (!v1144_5.empty()) {
          const Path v1145_6 = concat_path(v1143_6,v1143_7_head);
          const Space v1145_7 = routine_160(c, v1145_6, p1, v1143_7_tail);
          v1144_8 = compose(v1144_5,v1145_7);
        }
        const Space v1144_9 = intersect(constant_3,v1144_2);
        const Space v1144_10 = (has_head(v1144_9) ? constant_4 : Space{});
        Space v1144_12;
        if (!v1144_10.empty()) {
          const Path v1146_6 = concat_path(v1143_6,v1143_7_head);
          const Space v1146_11 = routine_161(c, v1146_6, p1, v1143_7_tail);
          v1144_12 = compose(v1144_10,v1146_11);
        }
        const Space v1144_13 = unite(v1144_8,v1144_12);
        v1143_7_result = unite(v1143_7_result,v1144_13);
      }
      const Space v1143_7 = std::move(v1143_7_result);
      v1142_8 = compose(v1142_5,v1143_7);
    }
    const Space v1142_9 = intersect(constant_3,v1142_2);
    const Space v1142_10 = (has_head(v1142_9) ? constant_4 : Space{});
    Space v1142_12;
    if (!v1142_10.empty()) {
      const Path v1147_6 = concat_path(p0,v1141_12_head);
      Space v1147_11_result;
      for (int v1147_11_label = 1; v1147_11_label <= 2; ++v1147_11_label) {
        const Space v1147_11_tail = child(v1141_12_tail,v1147_11_label);
        if (v1147_11_tail.empty()) continue;
        const Path v1147_11_head{v1147_11_label};
        const Space v1148_2 = singleton(v1147_11_head);
        const Space v1148_3 = intersect(constant_3,v1148_2);
        const Space v1148_4 = (has_head(v1148_3) ? constant_4 : Space{});
        const Space v1148_5 = subtract(constant_2,v1148_4);
        Space v1148_8;
        if (!v1148_5.empty()) {
          const Path v1149_6 = concat_path(v1147_6,v1147_11_head);
          const Space v1149_7 = routine_160(c, v1149_6, p1, v1147_11_tail);
          v1148_8 = compose(v1148_5,v1149_7);
        }
        const Space v1148_9 = intersect(constant_3,v1148_2);
        const Space v1148_10 = (has_head(v1148_9) ? constant_4 : Space{});
        Space v1148_12;
        if (!v1148_10.empty()) {
          const Path v1150_6 = concat_path(v1147_6,v1147_11_head);
          const Space v1150_11 = routine_84(c, v1150_6, p1, v1147_11_tail);
          v1148_12 = compose(v1148_10,v1150_11);
        }
        const Space v1148_13 = unite(v1148_8,v1148_12);
        v1147_11_result = unite(v1147_11_result,v1148_13);
      }
      const Space v1147_11 = std::move(v1147_11_result);
      v1142_12 = compose(v1142_10,v1147_11);
    }
    const Space v1142_13 = unite(v1142_8,v1142_12);
    v1141_12_result = unite(v1141_12_result,v1142_13);
  }
  const Space v1141_12 = std::move(v1141_12_result);
  return v1141_12;
}

static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1151_9_result;
  for (int v1151_9_label = 1; v1151_9_label <= 2; ++v1151_9_label) {
    const Space v1151_9_tail = child(s0,v1151_9_label);
    if (v1151_9_tail.empty()) continue;
    const Path v1151_9_head{v1151_9_label};
    const Space v1152_2 = singleton(v1151_9_head);
    const Space v1152_3 = intersect(constant_3,v1152_2);
    const Space v1152_4 = (has_head(v1152_3) ? constant_4 : Space{});
    const Space v1152_5 = subtract(constant_2,v1152_4);
    Space v1152_8;
    if (!v1152_5.empty()) {
      const Path v1153_6 = concat_path(p0,v1151_9_head);
      Space v1153_7_result;
      for (int v1153_7_label = 1; v1153_7_label <= 2; ++v1153_7_label) {
        const Space v1153_7_tail = child(v1151_9_tail,v1153_7_label);
        if (v1153_7_tail.empty()) continue;
        const Path v1153_7_head{v1153_7_label};
        const Space v1154_2 = singleton(v1153_7_head);
        const Space v1154_3 = intersect(constant_3,v1154_2);
        const Space v1154_4 = (has_head(v1154_3) ? constant_4 : Space{});
        const Space v1154_5 = subtract(constant_2,v1154_4);
        Space v1154_8;
        if (!v1154_5.empty()) {
          const Path v1155_6 = concat_path(v1153_6,v1153_7_head);
          const Space v1155_7 = routine_160(c, v1155_6, p1, v1153_7_tail);
          v1154_8 = compose(v1154_5,v1155_7);
        }
        const Space v1154_9 = intersect(constant_3,v1154_2);
        const Space v1154_10 = (has_head(v1154_9) ? constant_4 : Space{});
        Space v1154_12;
        if (!v1154_10.empty()) {
          const Path v1156_6 = concat_path(v1153_6,v1153_7_head);
          const Space v1156_11 = routine_161(c, v1156_6, p1, v1153_7_tail);
          v1154_12 = compose(v1154_10,v1156_11);
        }
        const Space v1154_13 = unite(v1154_8,v1154_12);
        v1153_7_result = unite(v1153_7_result,v1154_13);
      }
      const Space v1153_7 = std::move(v1153_7_result);
      v1152_8 = compose(v1152_5,v1153_7);
    }
    const Space v1152_9 = intersect(constant_3,v1152_2);
    const Space v1152_10 = (has_head(v1152_9) ? constant_4 : Space{});
    const Space v1152_11 = compose(v1152_10,v1151_9_tail);
    const Path v1157_6 = concat_path(p0,v1151_9_head);
    const Space v1152_12 = wrap(v1152_11,v1157_6);
    const Space v1152_13 = wrap(v1152_12,p1);
    const Space v1152_14 = unite(v1152_8,v1152_13);
    v1151_9_result = unite(v1151_9_result,v1152_14);
  }
  const Space v1151_9 = std::move(v1151_9_result);
  return v1151_9;
}

static Space routine_128(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1158_3_result;
  for (int v1158_3_label = 1; v1158_3_label <= 2; ++v1158_3_label) {
    const Space v1158_3_tail = child(s0,v1158_3_label);
    if (v1158_3_tail.empty()) continue;
    const Path v1158_3_head{v1158_3_label};
    const Space v1159_2 = Space{};
    v1158_3_result = unite(v1158_3_result,v1159_2);
  }
  const Space v1158_3 = std::move(v1158_3_result);
  return v1158_3;
}

static Space routine_129(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1160_7_result;
  for (int v1160_7_label = 1; v1160_7_label <= 2; ++v1160_7_label) {
    const Space v1160_7_tail = child(s0,v1160_7_label);
    if (v1160_7_tail.empty()) continue;
    const Path v1160_7_head{v1160_7_label};
    const Space v1161_2 = singleton(v1160_7_head);
    const Space v1161_3 = intersect(constant_3,v1161_2);
    const Space v1161_4 = (has_head(v1161_3) ? constant_4 : Space{});
    Space v1161_7;
    if (!v1161_4.empty()) {
      const Path v1162_5 = concat_path(p0,v1160_7_head);
      Space v1162_6_result;
      for (int v1162_6_label = 1; v1162_6_label <= 2; ++v1162_6_label) {
        const Space v1162_6_tail = child(v1160_7_tail,v1162_6_label);
        if (v1162_6_tail.empty()) continue;
        const Path v1162_6_head{v1162_6_label};
        const Space v1163_2 = singleton(v1162_6_head);
        const Space v1163_3 = intersect(constant_3,v1163_2);
        const Space v1163_4 = (has_head(v1163_3) ? constant_4 : Space{});
        const Space v1163_5 = subtract(constant_2,v1163_4);
        Space v1163_7;
        if (!v1163_5.empty()) {
          const Space v1164_6 = routine_46(c, v1162_6_head, v1162_5, v1162_6_tail, s1);
          v1163_7 = compose(v1163_5,v1164_6);
        }
        const Space v1163_8 = intersect(constant_3,v1163_2);
        const Space v1163_9 = (has_head(v1163_8) ? constant_4 : Space{});
        Space v1163_11;
        if (!v1163_9.empty()) {
          const Space v1165_10 = routine_47(c, v1162_6_head, v1162_5, v1162_6_tail, s1);
          v1163_11 = compose(v1163_9,v1165_10);
        }
        const Space v1163_12 = unite(v1163_7,v1163_11);
        v1162_6_result = unite(v1162_6_result,v1163_12);
      }
      const Space v1162_6 = std::move(v1162_6_result);
      v1161_7 = compose(v1161_4,v1162_6);
    }
    v1160_7_result = unite(v1160_7_result,v1161_7);
  }
  const Space v1160_7 = std::move(v1160_7_result);
  return v1160_7;
}

static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1166_13_result;
  for (int v1166_13_label = 1; v1166_13_label <= 2; ++v1166_13_label) {
    const Space v1166_13_tail = child(s0,v1166_13_label);
    if (v1166_13_tail.empty()) continue;
    const Path v1166_13_head{v1166_13_label};
    const Space v1167_2 = singleton(v1166_13_head);
    const Space v1167_3 = intersect(constant_3,v1167_2);
    const Space v1167_4 = (has_head(v1167_3) ? constant_4 : Space{});
    const Space v1167_5 = subtract(constant_2,v1167_4);
    Space v1167_8;
    if (!v1167_5.empty()) {
      const Path v1168_6 = concat_path(p0,v1166_13_head);
      Space v1168_7_result;
      for (int v1168_7_label = 1; v1168_7_label <= 2; ++v1168_7_label) {
        const Space v1168_7_tail = child(v1166_13_tail,v1168_7_label);
        if (v1168_7_tail.empty()) continue;
        const Path v1168_7_head{v1168_7_label};
        const Space v1169_2 = singleton(v1168_7_head);
        const Space v1169_3 = intersect(constant_3,v1169_2);
        const Space v1169_4 = (has_head(v1169_3) ? constant_4 : Space{});
        const Space v1169_5 = subtract(constant_2,v1169_4);
        Space v1169_8;
        if (!v1169_5.empty()) {
          const Path v1170_6 = concat_path(v1168_6,v1168_7_head);
          const Space v1170_7 = routine_162(c, v1170_6, p1, v1168_7_tail, s1);
          v1169_8 = compose(v1169_5,v1170_7);
        }
        const Space v1169_9 = intersect(constant_3,v1169_2);
        const Space v1169_10 = (has_head(v1169_9) ? constant_4 : Space{});
        Space v1169_12;
        if (!v1169_10.empty()) {
          const Path v1171_6 = concat_path(v1168_6,v1168_7_head);
          const Space v1171_11 = routine_163(c, v1171_6, p1, v1168_7_tail, s1);
          v1169_12 = compose(v1169_10,v1171_11);
        }
        const Space v1169_13 = unite(v1169_8,v1169_12);
        v1168_7_result = unite(v1168_7_result,v1169_13);
      }
      const Space v1168_7 = std::move(v1168_7_result);
      v1167_8 = compose(v1167_5,v1168_7);
    }
    const Space v1167_9 = intersect(constant_3,v1167_2);
    const Space v1167_10 = (has_head(v1167_9) ? constant_4 : Space{});
    Space v1167_12;
    if (!v1167_10.empty()) {
      const Path v1172_6 = concat_path(p0,v1166_13_head);
      Space v1172_11_result;
      for (int v1172_11_label = 1; v1172_11_label <= 2; ++v1172_11_label) {
        const Space v1172_11_tail = child(v1166_13_tail,v1172_11_label);
        if (v1172_11_tail.empty()) continue;
        const Path v1172_11_head{v1172_11_label};
        const Space v1173_2 = singleton(v1172_11_head);
        const Space v1173_3 = intersect(constant_3,v1173_2);
        const Space v1173_4 = (has_head(v1173_3) ? constant_4 : Space{});
        const Space v1173_5 = subtract(constant_2,v1173_4);
        Space v1173_8;
        if (!v1173_5.empty()) {
          const Path v1174_6 = concat_path(v1172_6,v1172_11_head);
          const Space v1174_7 = routine_162(c, v1174_6, p1, v1172_11_tail, s1);
          v1173_8 = compose(v1173_5,v1174_7);
        }
        const Space v1173_9 = intersect(constant_3,v1173_2);
        const Space v1173_10 = (has_head(v1173_9) ? constant_4 : Space{});
        Space v1173_12;
        if (!v1173_10.empty()) {
          const Path v1175_6 = concat_path(v1172_6,v1172_11_head);
          const Space v1175_11 = routine_50(c, v1175_6, p1, v1172_11_tail, s1);
          v1173_12 = compose(v1173_10,v1175_11);
        }
        const Space v1173_13 = unite(v1173_8,v1173_12);
        v1172_11_result = unite(v1172_11_result,v1173_13);
      }
      const Space v1172_11 = std::move(v1172_11_result);
      v1167_12 = compose(v1167_10,v1172_11);
    }
    const Space v1167_13 = unite(v1167_8,v1167_12);
    v1166_13_result = unite(v1166_13_result,v1167_13);
  }
  const Space v1166_13 = std::move(v1166_13_result);
  return v1166_13;
}

static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1176_8 = unwrap(s1,constant_5);
  const Space v1176_10 = unwrap(v1176_8,constant_6);
  const Space v1176_11 = unwrap(v1176_10,p0);
  Space v1176_18_result;
  for (int v1176_18_label = 1; v1176_18_label <= 2; ++v1176_18_label) {
    const Space v1176_18_tail = child(s0,v1176_18_label);
    if (v1176_18_tail.empty()) continue;
    const Path v1176_18_head{v1176_18_label};
    const Space v1177_2 = singleton(v1176_18_head);
    const Space v1177_3 = intersect(constant_3,v1177_2);
    const Space v1177_4 = (has_head(v1177_3) ? constant_4 : Space{});
    const Space v1177_5 = subtract(constant_2,v1177_4);
    Space v1177_8;
    if (!v1177_5.empty()) {
      const Path v1178_6 = concat_path(p0,v1176_18_head);
      Space v1178_7_result;
      for (int v1178_7_label = 1; v1178_7_label <= 2; ++v1178_7_label) {
        const Space v1178_7_tail = child(v1176_18_tail,v1178_7_label);
        if (v1178_7_tail.empty()) continue;
        const Path v1178_7_head{v1178_7_label};
        const Space v1179_2 = singleton(v1178_7_head);
        const Space v1179_3 = intersect(constant_3,v1179_2);
        const Space v1179_4 = (has_head(v1179_3) ? constant_4 : Space{});
        const Space v1179_5 = subtract(constant_2,v1179_4);
        Space v1179_8;
        if (!v1179_5.empty()) {
          const Path v1180_6 = concat_path(v1178_6,v1178_7_head);
          const Space v1180_7 = routine_162(c, v1180_6, p1, v1178_7_tail, s1);
          v1179_8 = compose(v1179_5,v1180_7);
        }
        const Space v1179_9 = intersect(constant_3,v1179_2);
        const Space v1179_10 = (has_head(v1179_9) ? constant_4 : Space{});
        Space v1179_12;
        if (!v1179_10.empty()) {
          const Path v1181_6 = concat_path(v1178_6,v1178_7_head);
          const Space v1181_11 = routine_163(c, v1181_6, p1, v1178_7_tail, s1);
          v1179_12 = compose(v1179_10,v1181_11);
        }
        const Space v1179_13 = unite(v1179_8,v1179_12);
        v1178_7_result = unite(v1178_7_result,v1179_13);
      }
      const Space v1178_7 = std::move(v1178_7_result);
      v1177_8 = compose(v1177_5,v1178_7);
    }
    const Space v1177_9 = intersect(constant_3,v1177_2);
    const Space v1177_10 = (has_head(v1177_9) ? constant_4 : Space{});
    Space v1177_13;
    if (!v1177_10.empty()) {
      const Space v1182_11 = unwrap(v1176_11,v1176_18_head);
      Space v1182_12_result;
      for (int v1182_12_label = 1; v1182_12_label <= 2; ++v1182_12_label) {
        const Space v1182_12_tail = child(v1182_11,v1182_12_label);
        if (v1182_12_tail.empty()) continue;
        const Path v1182_12_head{v1182_12_label};
        const Space v1183_2 = singleton(v1182_12_head);
        const Space v1183_3 = intersect(constant_3,v1183_2);
        const Space v1183_4 = (has_head(v1183_3) ? constant_4 : Space{});
        const Space v1183_5 = subtract(constant_2,v1183_4);
        Space v1183_7;
        if (!v1183_5.empty()) {
          const Space v1184_6 = routine_89(c, v1182_12_head, p1, v1182_12_tail);
          v1183_7 = compose(v1183_5,v1184_6);
        }
        const Space v1183_8 = intersect(constant_3,v1183_2);
        const Space v1183_9 = (has_head(v1183_8) ? constant_4 : Space{});
        Space v1183_11;
        if (!v1183_9.empty()) {
          const Space v1185_10 = routine_90(c, v1182_12_head, p1, v1182_12_tail);
          v1183_11 = compose(v1183_9,v1185_10);
        }
        const Space v1183_12 = unite(v1183_7,v1183_11);
        v1182_12_result = unite(v1182_12_result,v1183_12);
      }
      const Space v1182_12 = std::move(v1182_12_result);
      v1177_13 = compose(v1177_10,v1182_12);
    }
    const Space v1177_14 = unite(v1177_8,v1177_13);
    v1176_18_result = unite(v1176_18_result,v1177_14);
  }
  const Space v1176_18 = std::move(v1176_18_result);
  return v1176_18;
}

static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1186_12_result;
  for (int v1186_12_label = 1; v1186_12_label <= 2; ++v1186_12_label) {
    const Space v1186_12_tail = child(s0,v1186_12_label);
    if (v1186_12_tail.empty()) continue;
    const Path v1186_12_head{v1186_12_label};
    const Space v1187_2 = singleton(v1186_12_head);
    const Space v1187_3 = intersect(constant_3,v1187_2);
    const Space v1187_4 = (has_head(v1187_3) ? constant_4 : Space{});
    const Space v1187_5 = subtract(constant_2,v1187_4);
    Space v1187_8;
    if (!v1187_5.empty()) {
      const Path v1188_6 = concat_path(p0,v1186_12_head);
      Space v1188_7_result;
      for (int v1188_7_label = 1; v1188_7_label <= 2; ++v1188_7_label) {
        const Space v1188_7_tail = child(v1186_12_tail,v1188_7_label);
        if (v1188_7_tail.empty()) continue;
        const Path v1188_7_head{v1188_7_label};
        const Space v1189_2 = singleton(v1188_7_head);
        const Space v1189_3 = intersect(constant_3,v1189_2);
        const Space v1189_4 = (has_head(v1189_3) ? constant_4 : Space{});
        const Space v1189_5 = subtract(constant_2,v1189_4);
        Space v1189_8;
        if (!v1189_5.empty()) {
          const Path v1190_6 = concat_path(v1188_6,v1188_7_head);
          const Space v1190_7 = routine_164(c, v1190_6, p1, v1188_7_tail);
          v1189_8 = compose(v1189_5,v1190_7);
        }
        const Space v1189_9 = intersect(constant_3,v1189_2);
        const Space v1189_10 = (has_head(v1189_9) ? constant_4 : Space{});
        Space v1189_12;
        if (!v1189_10.empty()) {
          const Path v1191_6 = concat_path(v1188_6,v1188_7_head);
          const Space v1191_11 = routine_165(c, v1191_6, p1, v1188_7_tail);
          v1189_12 = compose(v1189_10,v1191_11);
        }
        const Space v1189_13 = unite(v1189_8,v1189_12);
        v1188_7_result = unite(v1188_7_result,v1189_13);
      }
      const Space v1188_7 = std::move(v1188_7_result);
      v1187_8 = compose(v1187_5,v1188_7);
    }
    const Space v1187_9 = intersect(constant_3,v1187_2);
    const Space v1187_10 = (has_head(v1187_9) ? constant_4 : Space{});
    Space v1187_12;
    if (!v1187_10.empty()) {
      const Path v1192_6 = concat_path(p0,v1186_12_head);
      Space v1192_11_result;
      for (int v1192_11_label = 1; v1192_11_label <= 2; ++v1192_11_label) {
        const Space v1192_11_tail = child(v1186_12_tail,v1192_11_label);
        if (v1192_11_tail.empty()) continue;
        const Path v1192_11_head{v1192_11_label};
        const Space v1193_2 = singleton(v1192_11_head);
        const Space v1193_3 = intersect(constant_3,v1193_2);
        const Space v1193_4 = (has_head(v1193_3) ? constant_4 : Space{});
        const Space v1193_5 = subtract(constant_2,v1193_4);
        Space v1193_8;
        if (!v1193_5.empty()) {
          const Path v1194_6 = concat_path(v1192_6,v1192_11_head);
          const Space v1194_7 = routine_164(c, v1194_6, p1, v1192_11_tail);
          v1193_8 = compose(v1193_5,v1194_7);
        }
        const Space v1193_9 = intersect(constant_3,v1193_2);
        const Space v1193_10 = (has_head(v1193_9) ? constant_4 : Space{});
        Space v1193_12;
        if (!v1193_10.empty()) {
          const Path v1195_6 = concat_path(v1192_6,v1192_11_head);
          const Space v1195_11 = routine_95(c, v1195_6, p1, v1192_11_tail);
          v1193_12 = compose(v1193_10,v1195_11);
        }
        const Space v1193_13 = unite(v1193_8,v1193_12);
        v1192_11_result = unite(v1192_11_result,v1193_13);
      }
      const Space v1192_11 = std::move(v1192_11_result);
      v1187_12 = compose(v1187_10,v1192_11);
    }
    const Space v1187_13 = unite(v1187_8,v1187_12);
    v1186_12_result = unite(v1186_12_result,v1187_13);
  }
  const Space v1186_12 = std::move(v1186_12_result);
  return v1186_12;
}

static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1196_9_result;
  for (int v1196_9_label = 1; v1196_9_label <= 2; ++v1196_9_label) {
    const Space v1196_9_tail = child(s0,v1196_9_label);
    if (v1196_9_tail.empty()) continue;
    const Path v1196_9_head{v1196_9_label};
    const Space v1197_2 = singleton(v1196_9_head);
    const Space v1197_3 = intersect(constant_3,v1197_2);
    const Space v1197_4 = (has_head(v1197_3) ? constant_4 : Space{});
    const Space v1197_5 = subtract(constant_2,v1197_4);
    Space v1197_8;
    if (!v1197_5.empty()) {
      const Path v1198_6 = concat_path(p0,v1196_9_head);
      Space v1198_7_result;
      for (int v1198_7_label = 1; v1198_7_label <= 2; ++v1198_7_label) {
        const Space v1198_7_tail = child(v1196_9_tail,v1198_7_label);
        if (v1198_7_tail.empty()) continue;
        const Path v1198_7_head{v1198_7_label};
        const Space v1199_2 = singleton(v1198_7_head);
        const Space v1199_3 = intersect(constant_3,v1199_2);
        const Space v1199_4 = (has_head(v1199_3) ? constant_4 : Space{});
        const Space v1199_5 = subtract(constant_2,v1199_4);
        Space v1199_8;
        if (!v1199_5.empty()) {
          const Path v1200_6 = concat_path(v1198_6,v1198_7_head);
          const Space v1200_7 = routine_164(c, v1200_6, p1, v1198_7_tail);
          v1199_8 = compose(v1199_5,v1200_7);
        }
        const Space v1199_9 = intersect(constant_3,v1199_2);
        const Space v1199_10 = (has_head(v1199_9) ? constant_4 : Space{});
        Space v1199_12;
        if (!v1199_10.empty()) {
          const Path v1201_6 = concat_path(v1198_6,v1198_7_head);
          const Space v1201_11 = routine_165(c, v1201_6, p1, v1198_7_tail);
          v1199_12 = compose(v1199_10,v1201_11);
        }
        const Space v1199_13 = unite(v1199_8,v1199_12);
        v1198_7_result = unite(v1198_7_result,v1199_13);
      }
      const Space v1198_7 = std::move(v1198_7_result);
      v1197_8 = compose(v1197_5,v1198_7);
    }
    const Space v1197_9 = intersect(constant_3,v1197_2);
    const Space v1197_10 = (has_head(v1197_9) ? constant_4 : Space{});
    const Space v1197_11 = compose(v1197_10,v1196_9_tail);
    const Path v1202_6 = concat_path(p0,v1196_9_head);
    const Space v1197_12 = wrap(v1197_11,v1202_6);
    const Space v1197_13 = wrap(v1197_12,p1);
    const Space v1197_14 = unite(v1197_8,v1197_13);
    v1196_9_result = unite(v1196_9_result,v1197_14);
  }
  const Space v1196_9 = std::move(v1196_9_result);
  return v1196_9;
}

static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1203_13_result;
  for (int v1203_13_label = 1; v1203_13_label <= 2; ++v1203_13_label) {
    const Space v1203_13_tail = child(s0,v1203_13_label);
    if (v1203_13_tail.empty()) continue;
    const Path v1203_13_head{v1203_13_label};
    const Space v1204_2 = singleton(v1203_13_head);
    const Space v1204_3 = intersect(constant_3,v1204_2);
    const Space v1204_4 = (has_head(v1204_3) ? constant_4 : Space{});
    const Space v1204_5 = subtract(constant_2,v1204_4);
    Space v1204_8;
    if (!v1204_5.empty()) {
      const Path v1205_6 = concat_path(p0,v1203_13_head);
      Space v1205_7_result;
      for (int v1205_7_label = 1; v1205_7_label <= 2; ++v1205_7_label) {
        const Space v1205_7_tail = child(v1203_13_tail,v1205_7_label);
        if (v1205_7_tail.empty()) continue;
        const Path v1205_7_head{v1205_7_label};
        const Space v1206_2 = singleton(v1205_7_head);
        const Space v1206_3 = intersect(constant_3,v1206_2);
        const Space v1206_4 = (has_head(v1206_3) ? constant_4 : Space{});
        const Space v1206_5 = subtract(constant_2,v1206_4);
        Space v1206_8;
        if (!v1206_5.empty()) {
          const Path v1207_6 = concat_path(v1205_6,v1205_7_head);
          const Space v1207_7 = routine_166(c, v1207_6, p1, v1205_7_tail, s1);
          v1206_8 = compose(v1206_5,v1207_7);
        }
        const Space v1206_9 = intersect(constant_3,v1206_2);
        const Space v1206_10 = (has_head(v1206_9) ? constant_4 : Space{});
        Space v1206_12;
        if (!v1206_10.empty()) {
          const Path v1208_6 = concat_path(v1205_6,v1205_7_head);
          const Space v1208_11 = routine_167(c, v1208_6, p1, v1205_7_tail, s1);
          v1206_12 = compose(v1206_10,v1208_11);
        }
        const Space v1206_13 = unite(v1206_8,v1206_12);
        v1205_7_result = unite(v1205_7_result,v1206_13);
      }
      const Space v1205_7 = std::move(v1205_7_result);
      v1204_8 = compose(v1204_5,v1205_7);
    }
    const Space v1204_9 = intersect(constant_3,v1204_2);
    const Space v1204_10 = (has_head(v1204_9) ? constant_4 : Space{});
    Space v1204_12;
    if (!v1204_10.empty()) {
      const Path v1209_6 = concat_path(p0,v1203_13_head);
      Space v1209_11_result;
      for (int v1209_11_label = 1; v1209_11_label <= 2; ++v1209_11_label) {
        const Space v1209_11_tail = child(v1203_13_tail,v1209_11_label);
        if (v1209_11_tail.empty()) continue;
        const Path v1209_11_head{v1209_11_label};
        const Space v1210_2 = singleton(v1209_11_head);
        const Space v1210_3 = intersect(constant_3,v1210_2);
        const Space v1210_4 = (has_head(v1210_3) ? constant_4 : Space{});
        const Space v1210_5 = subtract(constant_2,v1210_4);
        Space v1210_8;
        if (!v1210_5.empty()) {
          const Path v1211_6 = concat_path(v1209_6,v1209_11_head);
          const Space v1211_7 = routine_166(c, v1211_6, p1, v1209_11_tail, s1);
          v1210_8 = compose(v1210_5,v1211_7);
        }
        const Space v1210_9 = intersect(constant_3,v1210_2);
        const Space v1210_10 = (has_head(v1210_9) ? constant_4 : Space{});
        Space v1210_12;
        if (!v1210_10.empty()) {
          const Path v1212_6 = concat_path(v1209_6,v1209_11_head);
          const Space v1212_11 = routine_50(c, v1212_6, p1, v1209_11_tail, s1);
          v1210_12 = compose(v1210_10,v1212_11);
        }
        const Space v1210_13 = unite(v1210_8,v1210_12);
        v1209_11_result = unite(v1209_11_result,v1210_13);
      }
      const Space v1209_11 = std::move(v1209_11_result);
      v1204_12 = compose(v1204_10,v1209_11);
    }
    const Space v1204_13 = unite(v1204_8,v1204_12);
    v1203_13_result = unite(v1203_13_result,v1204_13);
  }
  const Space v1203_13 = std::move(v1203_13_result);
  return v1203_13;
}

static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1213_8 = unwrap(s1,constant_5);
  const Space v1213_10 = unwrap(v1213_8,constant_6);
  const Space v1213_11 = unwrap(v1213_10,p0);
  Space v1213_18_result;
  for (int v1213_18_label = 1; v1213_18_label <= 2; ++v1213_18_label) {
    const Space v1213_18_tail = child(s0,v1213_18_label);
    if (v1213_18_tail.empty()) continue;
    const Path v1213_18_head{v1213_18_label};
    const Space v1214_2 = singleton(v1213_18_head);
    const Space v1214_3 = intersect(constant_3,v1214_2);
    const Space v1214_4 = (has_head(v1214_3) ? constant_4 : Space{});
    const Space v1214_5 = subtract(constant_2,v1214_4);
    Space v1214_8;
    if (!v1214_5.empty()) {
      const Path v1215_6 = concat_path(p0,v1213_18_head);
      Space v1215_7_result;
      for (int v1215_7_label = 1; v1215_7_label <= 2; ++v1215_7_label) {
        const Space v1215_7_tail = child(v1213_18_tail,v1215_7_label);
        if (v1215_7_tail.empty()) continue;
        const Path v1215_7_head{v1215_7_label};
        const Space v1216_2 = singleton(v1215_7_head);
        const Space v1216_3 = intersect(constant_3,v1216_2);
        const Space v1216_4 = (has_head(v1216_3) ? constant_4 : Space{});
        const Space v1216_5 = subtract(constant_2,v1216_4);
        Space v1216_8;
        if (!v1216_5.empty()) {
          const Path v1217_6 = concat_path(v1215_6,v1215_7_head);
          const Space v1217_7 = routine_166(c, v1217_6, p1, v1215_7_tail, s1);
          v1216_8 = compose(v1216_5,v1217_7);
        }
        const Space v1216_9 = intersect(constant_3,v1216_2);
        const Space v1216_10 = (has_head(v1216_9) ? constant_4 : Space{});
        Space v1216_12;
        if (!v1216_10.empty()) {
          const Path v1218_6 = concat_path(v1215_6,v1215_7_head);
          const Space v1218_11 = routine_167(c, v1218_6, p1, v1215_7_tail, s1);
          v1216_12 = compose(v1216_10,v1218_11);
        }
        const Space v1216_13 = unite(v1216_8,v1216_12);
        v1215_7_result = unite(v1215_7_result,v1216_13);
      }
      const Space v1215_7 = std::move(v1215_7_result);
      v1214_8 = compose(v1214_5,v1215_7);
    }
    const Space v1214_9 = intersect(constant_3,v1214_2);
    const Space v1214_10 = (has_head(v1214_9) ? constant_4 : Space{});
    Space v1214_13;
    if (!v1214_10.empty()) {
      const Space v1219_11 = unwrap(v1213_11,v1213_18_head);
      Space v1219_12_result;
      for (int v1219_12_label = 1; v1219_12_label <= 2; ++v1219_12_label) {
        const Space v1219_12_tail = child(v1219_11,v1219_12_label);
        if (v1219_12_tail.empty()) continue;
        const Path v1219_12_head{v1219_12_label};
        const Space v1220_2 = singleton(v1219_12_head);
        const Space v1220_3 = intersect(constant_3,v1220_2);
        const Space v1220_4 = (has_head(v1220_3) ? constant_4 : Space{});
        const Space v1220_5 = subtract(constant_2,v1220_4);
        Space v1220_7;
        if (!v1220_5.empty()) {
          const Space v1221_6 = routine_89(c, v1219_12_head, p1, v1219_12_tail);
          v1220_7 = compose(v1220_5,v1221_6);
        }
        const Space v1220_8 = intersect(constant_3,v1220_2);
        const Space v1220_9 = (has_head(v1220_8) ? constant_4 : Space{});
        Space v1220_11;
        if (!v1220_9.empty()) {
          const Space v1222_10 = routine_90(c, v1219_12_head, p1, v1219_12_tail);
          v1220_11 = compose(v1220_9,v1222_10);
        }
        const Space v1220_12 = unite(v1220_7,v1220_11);
        v1219_12_result = unite(v1219_12_result,v1220_12);
      }
      const Space v1219_12 = std::move(v1219_12_result);
      v1214_13 = compose(v1214_10,v1219_12);
    }
    const Space v1214_14 = unite(v1214_8,v1214_13);
    v1213_18_result = unite(v1213_18_result,v1214_14);
  }
  const Space v1213_18 = std::move(v1213_18_result);
  return v1213_18;
}

static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1223_12_result;
  for (int v1223_12_label = 1; v1223_12_label <= 2; ++v1223_12_label) {
    const Space v1223_12_tail = child(s0,v1223_12_label);
    if (v1223_12_tail.empty()) continue;
    const Path v1223_12_head{v1223_12_label};
    const Space v1224_2 = singleton(v1223_12_head);
    const Space v1224_3 = intersect(constant_3,v1224_2);
    const Space v1224_4 = (has_head(v1224_3) ? constant_4 : Space{});
    const Space v1224_5 = subtract(constant_2,v1224_4);
    Space v1224_8;
    if (!v1224_5.empty()) {
      const Path v1225_6 = concat_path(p0,v1223_12_head);
      Space v1225_7_result;
      for (int v1225_7_label = 1; v1225_7_label <= 2; ++v1225_7_label) {
        const Space v1225_7_tail = child(v1223_12_tail,v1225_7_label);
        if (v1225_7_tail.empty()) continue;
        const Path v1225_7_head{v1225_7_label};
        const Space v1226_2 = singleton(v1225_7_head);
        const Space v1226_3 = intersect(constant_3,v1226_2);
        const Space v1226_4 = (has_head(v1226_3) ? constant_4 : Space{});
        const Space v1226_5 = subtract(constant_2,v1226_4);
        Space v1226_8;
        if (!v1226_5.empty()) {
          const Path v1227_6 = concat_path(v1225_6,v1225_7_head);
          const Space v1227_7 = routine_168(c, v1227_6, p1, v1225_7_tail);
          v1226_8 = compose(v1226_5,v1227_7);
        }
        const Space v1226_9 = intersect(constant_3,v1226_2);
        const Space v1226_10 = (has_head(v1226_9) ? constant_4 : Space{});
        Space v1226_12;
        if (!v1226_10.empty()) {
          const Path v1228_6 = concat_path(v1225_6,v1225_7_head);
          const Space v1228_11 = routine_169(c, v1228_6, p1, v1225_7_tail);
          v1226_12 = compose(v1226_10,v1228_11);
        }
        const Space v1226_13 = unite(v1226_8,v1226_12);
        v1225_7_result = unite(v1225_7_result,v1226_13);
      }
      const Space v1225_7 = std::move(v1225_7_result);
      v1224_8 = compose(v1224_5,v1225_7);
    }
    const Space v1224_9 = intersect(constant_3,v1224_2);
    const Space v1224_10 = (has_head(v1224_9) ? constant_4 : Space{});
    Space v1224_12;
    if (!v1224_10.empty()) {
      const Path v1229_6 = concat_path(p0,v1223_12_head);
      Space v1229_11_result;
      for (int v1229_11_label = 1; v1229_11_label <= 2; ++v1229_11_label) {
        const Space v1229_11_tail = child(v1223_12_tail,v1229_11_label);
        if (v1229_11_tail.empty()) continue;
        const Path v1229_11_head{v1229_11_label};
        const Space v1230_2 = singleton(v1229_11_head);
        const Space v1230_3 = intersect(constant_3,v1230_2);
        const Space v1230_4 = (has_head(v1230_3) ? constant_4 : Space{});
        const Space v1230_5 = subtract(constant_2,v1230_4);
        Space v1230_8;
        if (!v1230_5.empty()) {
          const Path v1231_6 = concat_path(v1229_6,v1229_11_head);
          const Space v1231_7 = routine_168(c, v1231_6, p1, v1229_11_tail);
          v1230_8 = compose(v1230_5,v1231_7);
        }
        const Space v1230_9 = intersect(constant_3,v1230_2);
        const Space v1230_10 = (has_head(v1230_9) ? constant_4 : Space{});
        Space v1230_12;
        if (!v1230_10.empty()) {
          const Path v1232_6 = concat_path(v1229_6,v1229_11_head);
          const Space v1232_11 = routine_95(c, v1232_6, p1, v1229_11_tail);
          v1230_12 = compose(v1230_10,v1232_11);
        }
        const Space v1230_13 = unite(v1230_8,v1230_12);
        v1229_11_result = unite(v1229_11_result,v1230_13);
      }
      const Space v1229_11 = std::move(v1229_11_result);
      v1224_12 = compose(v1224_10,v1229_11);
    }
    const Space v1224_13 = unite(v1224_8,v1224_12);
    v1223_12_result = unite(v1223_12_result,v1224_13);
  }
  const Space v1223_12 = std::move(v1223_12_result);
  return v1223_12;
}

static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1233_9_result;
  for (int v1233_9_label = 1; v1233_9_label <= 2; ++v1233_9_label) {
    const Space v1233_9_tail = child(s0,v1233_9_label);
    if (v1233_9_tail.empty()) continue;
    const Path v1233_9_head{v1233_9_label};
    const Space v1234_2 = singleton(v1233_9_head);
    const Space v1234_3 = intersect(constant_3,v1234_2);
    const Space v1234_4 = (has_head(v1234_3) ? constant_4 : Space{});
    const Space v1234_5 = subtract(constant_2,v1234_4);
    Space v1234_8;
    if (!v1234_5.empty()) {
      const Path v1235_6 = concat_path(p0,v1233_9_head);
      Space v1235_7_result;
      for (int v1235_7_label = 1; v1235_7_label <= 2; ++v1235_7_label) {
        const Space v1235_7_tail = child(v1233_9_tail,v1235_7_label);
        if (v1235_7_tail.empty()) continue;
        const Path v1235_7_head{v1235_7_label};
        const Space v1236_2 = singleton(v1235_7_head);
        const Space v1236_3 = intersect(constant_3,v1236_2);
        const Space v1236_4 = (has_head(v1236_3) ? constant_4 : Space{});
        const Space v1236_5 = subtract(constant_2,v1236_4);
        Space v1236_8;
        if (!v1236_5.empty()) {
          const Path v1237_6 = concat_path(v1235_6,v1235_7_head);
          const Space v1237_7 = routine_168(c, v1237_6, p1, v1235_7_tail);
          v1236_8 = compose(v1236_5,v1237_7);
        }
        const Space v1236_9 = intersect(constant_3,v1236_2);
        const Space v1236_10 = (has_head(v1236_9) ? constant_4 : Space{});
        Space v1236_12;
        if (!v1236_10.empty()) {
          const Path v1238_6 = concat_path(v1235_6,v1235_7_head);
          const Space v1238_11 = routine_169(c, v1238_6, p1, v1235_7_tail);
          v1236_12 = compose(v1236_10,v1238_11);
        }
        const Space v1236_13 = unite(v1236_8,v1236_12);
        v1235_7_result = unite(v1235_7_result,v1236_13);
      }
      const Space v1235_7 = std::move(v1235_7_result);
      v1234_8 = compose(v1234_5,v1235_7);
    }
    const Space v1234_9 = intersect(constant_3,v1234_2);
    const Space v1234_10 = (has_head(v1234_9) ? constant_4 : Space{});
    const Space v1234_11 = compose(v1234_10,v1233_9_tail);
    const Path v1239_6 = concat_path(p0,v1233_9_head);
    const Space v1234_12 = wrap(v1234_11,v1239_6);
    const Space v1234_13 = wrap(v1234_12,p1);
    const Space v1234_14 = unite(v1234_8,v1234_13);
    v1233_9_result = unite(v1233_9_result,v1234_14);
  }
  const Space v1233_9 = std::move(v1233_9_result);
  return v1233_9;
}

static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1240_7_result;
  for (int v1240_7_label = 1; v1240_7_label <= 2; ++v1240_7_label) {
    const Space v1240_7_tail = child(s0,v1240_7_label);
    if (v1240_7_tail.empty()) continue;
    const Path v1240_7_head{v1240_7_label};
    const Space v1241_2 = singleton(v1240_7_head);
    const Space v1241_3 = intersect(constant_3,v1241_2);
    const Space v1241_4 = (has_head(v1241_3) ? constant_4 : Space{});
    const Space v1241_5 = subtract(constant_2,v1241_4);
    Space v1241_6_result;
    for (int v1241_6_label = 1; v1241_6_label <= 2; ++v1241_6_label) {
      const Space v1241_6_tail = child(v1240_7_tail,v1241_6_label);
      if (v1241_6_tail.empty()) continue;
      const Path v1241_6_head{v1241_6_label};
      const Space v1242_2 = Space{};
      v1241_6_result = unite(v1241_6_result,v1242_2);
    }
    const Space v1241_6 = std::move(v1241_6_result);
    const Space v1241_7 = compose(v1241_5,v1241_6);
    const Space v1241_8 = intersect(constant_3,v1241_2);
    const Space v1241_9 = (has_head(v1241_8) ? constant_4 : Space{});
    Space v1241_12;
    if (!v1241_9.empty()) {
      const Path v1243_10 = concat_path(p0,v1240_7_head);
      Space v1243_11_result;
      for (int v1243_11_label = 1; v1243_11_label <= 2; ++v1243_11_label) {
        const Space v1243_11_tail = child(v1240_7_tail,v1243_11_label);
        if (v1243_11_tail.empty()) continue;
        const Path v1243_11_head{v1243_11_label};
        const Space v1244_2 = singleton(v1243_11_head);
        const Space v1244_3 = intersect(constant_3,v1244_2);
        const Space v1244_4 = (has_head(v1244_3) ? constant_4 : Space{});
        Space v1244_7;
        if (!v1244_4.empty()) {
          const Path v1245_5 = concat_path(v1243_10,v1243_11_head);
          const Space v1245_6 = routine_22(c, v1245_5, p1, v1243_11_tail);
          v1244_7 = compose(v1244_4,v1245_6);
        }
        v1243_11_result = unite(v1243_11_result,v1244_7);
      }
      const Space v1243_11 = std::move(v1243_11_result);
      v1241_12 = compose(v1241_9,v1243_11);
    }
    const Space v1241_13 = unite(v1241_7,v1241_12);
    v1240_7_result = unite(v1240_7_result,v1241_13);
  }
  const Space v1240_7 = std::move(v1240_7_result);
  return v1240_7;
}

static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1246_7_result;
  for (int v1246_7_label = 1; v1246_7_label <= 2; ++v1246_7_label) {
    const Space v1246_7_tail = child(s0,v1246_7_label);
    if (v1246_7_tail.empty()) continue;
    const Path v1246_7_head{v1246_7_label};
    const Space v1247_2 = singleton(v1246_7_head);
    const Space v1247_3 = intersect(constant_3,v1247_2);
    const Space v1247_4 = (has_head(v1247_3) ? constant_4 : Space{});
    const Space v1247_5 = compose(v1247_4,v1246_7_tail);
    const Path v1247_6 = concat_path(p0,v1246_7_head);
    const Space v1247_7 = wrap(v1247_5,v1247_6);
    const Space v1247_8 = wrap(v1247_7,p1);
    const Space v1247_9 = wrap(v1247_8,constant_6);
    const Space v1247_10 = intersect(constant_3,v1247_2);
    const Space v1247_11 = (has_head(v1247_10) ? constant_4 : Space{});
    const Space v1247_12 = subtract(constant_2,v1247_11);
    Space v1247_13_result;
    for (int v1247_13_label = 1; v1247_13_label <= 2; ++v1247_13_label) {
      const Space v1247_13_tail = child(v1246_7_tail,v1247_13_label);
      if (v1247_13_tail.empty()) continue;
      const Path v1247_13_head{v1247_13_label};
      const Space v1248_2 = Space{};
      v1247_13_result = unite(v1247_13_result,v1248_2);
    }
    const Space v1247_13 = std::move(v1247_13_result);
    const Space v1247_14 = compose(v1247_12,v1247_13);
    const Space v1247_15 = unite(v1247_9,v1247_14);
    v1246_7_result = unite(v1246_7_result,v1247_15);
  }
  const Space v1246_7 = std::move(v1246_7_result);
  return v1246_7;
}

static Space routine_140(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1249_3_result;
  for (int v1249_3_label = 1; v1249_3_label <= 2; ++v1249_3_label) {
    const Space v1249_3_tail = child(s0,v1249_3_label);
    if (v1249_3_tail.empty()) continue;
    const Path v1249_3_head{v1249_3_label};
    const Space v1250_2 = Space{};
    v1249_3_result = unite(v1249_3_result,v1250_2);
  }
  const Space v1249_3 = std::move(v1249_3_result);
  return v1249_3;
}

static Space routine_141(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1251_4_result;
  for (int v1251_4_label = 1; v1251_4_label <= 2; ++v1251_4_label) {
    const Space v1251_4_tail = child(s0,v1251_4_label);
    if (v1251_4_tail.empty()) continue;
    const Path v1251_4_head{v1251_4_label};
    const Space v1252_2 = singleton(v1251_4_head);
    const Space v1252_3 = intersect(constant_3,v1252_2);
    const Space v1252_4 = (has_head(v1252_3) ? constant_4 : Space{});
    const Space v1252_5 = compose(v1252_4,v1251_4_tail);
    const Path v1252_6 = concat_path(p0,v1251_4_head);
    const Space v1252_7 = wrap(v1252_5,v1252_6);
    v1251_4_result = unite(v1251_4_result,v1252_7);
  }
  const Space v1251_4 = std::move(v1251_4_result);
  const Space v1251_5 = wrap(v1251_4,p1);
  const Space v1251_7 = wrap(v1251_5,constant_6);
  return v1251_7;
}

static Space routine_142(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1253_8_result;
  for (int v1253_8_label = 1; v1253_8_label <= 2; ++v1253_8_label) {
    const Space v1253_8_tail = child(s0,v1253_8_label);
    if (v1253_8_tail.empty()) continue;
    const Path v1253_8_head{v1253_8_label};
    const Space v1254_2 = singleton(v1253_8_head);
    const Space v1254_3 = intersect(constant_3,v1254_2);
    const Space v1254_4 = (has_head(v1254_3) ? constant_4 : Space{});
    const Space v1254_5 = subtract(constant_2,v1254_4);
    Space v1254_6_result;
    for (int v1254_6_label = 1; v1254_6_label <= 2; ++v1254_6_label) {
      const Space v1254_6_tail = child(v1253_8_tail,v1254_6_label);
      if (v1254_6_tail.empty()) continue;
      const Path v1254_6_head{v1254_6_label};
      const Space v1255_2 = Space{};
      v1254_6_result = unite(v1254_6_result,v1255_2);
    }
    const Space v1254_6 = std::move(v1254_6_result);
    const Space v1254_7 = compose(v1254_5,v1254_6);
    const Space v1254_8 = intersect(constant_3,v1254_2);
    const Space v1254_9 = (has_head(v1254_8) ? constant_4 : Space{});
    Space v1254_12;
    if (!v1254_9.empty()) {
      const Path v1256_10 = concat_path(p0,v1253_8_head);
      Space v1256_11_result;
      for (int v1256_11_label = 1; v1256_11_label <= 2; ++v1256_11_label) {
        const Space v1256_11_tail = child(v1253_8_tail,v1256_11_label);
        if (v1256_11_tail.empty()) continue;
        const Path v1256_11_head{v1256_11_label};
        const Space v1257_2 = singleton(v1256_11_head);
        const Space v1257_3 = intersect(constant_3,v1257_2);
        const Space v1257_4 = (has_head(v1257_3) ? constant_4 : Space{});
        Space v1257_7;
        if (!v1257_4.empty()) {
          const Path v1258_5 = concat_path(v1256_10,v1256_11_head);
          const Space v1258_6 = routine_29(c, v1258_5, p1, v1256_11_tail, s1);
          v1257_7 = compose(v1257_4,v1258_6);
        }
        v1256_11_result = unite(v1256_11_result,v1257_7);
      }
      const Space v1256_11 = std::move(v1256_11_result);
      v1254_12 = compose(v1254_9,v1256_11);
    }
    const Space v1254_13 = unite(v1254_7,v1254_12);
    v1253_8_result = unite(v1253_8_result,v1254_13);
  }
  const Space v1253_8 = std::move(v1253_8_result);
  return v1253_8;
}

static Space routine_143(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1259_8 = unwrap(s1,constant_5);
  const Space v1259_10 = unwrap(v1259_8,constant_6);
  const Space v1259_11 = unwrap(v1259_10,p0);
  Space v1259_15_result;
  for (int v1259_15_label = 1; v1259_15_label <= 2; ++v1259_15_label) {
    const Space v1259_15_tail = child(s0,v1259_15_label);
    if (v1259_15_tail.empty()) continue;
    const Path v1259_15_head{v1259_15_label};
    const Space v1260_2 = singleton(v1259_15_head);
    const Space v1260_3 = intersect(constant_3,v1260_2);
    const Space v1260_4 = (has_head(v1260_3) ? constant_4 : Space{});
    const Space v1260_5 = subtract(constant_2,v1260_4);
    Space v1260_6_result;
    for (int v1260_6_label = 1; v1260_6_label <= 2; ++v1260_6_label) {
      const Space v1260_6_tail = child(v1259_15_tail,v1260_6_label);
      if (v1260_6_tail.empty()) continue;
      const Path v1260_6_head{v1260_6_label};
      const Space v1261_2 = Space{};
      v1260_6_result = unite(v1260_6_result,v1261_2);
    }
    const Space v1260_6 = std::move(v1260_6_result);
    const Space v1260_7 = compose(v1260_5,v1260_6);
    const Space v1260_8 = intersect(constant_3,v1260_2);
    const Space v1260_9 = (has_head(v1260_8) ? constant_4 : Space{});
    Space v1260_12;
    if (!v1260_9.empty()) {
      const Space v1262_10 = unwrap(v1259_11,v1259_15_head);
      Space v1262_11_result;
      for (int v1262_11_label = 1; v1262_11_label <= 2; ++v1262_11_label) {
        const Space v1262_11_tail = child(v1262_10,v1262_11_label);
        if (v1262_11_tail.empty()) continue;
        const Path v1262_11_head{v1262_11_label};
        const Space v1263_2 = singleton(v1262_11_head);
        const Space v1263_3 = intersect(constant_3,v1263_2);
        const Space v1263_4 = (has_head(v1263_3) ? constant_4 : Space{});
        const Space v1263_5 = subtract(constant_2,v1263_4);
        Space v1263_7;
        if (!v1263_5.empty()) {
          const Space v1264_6 = routine_61(c, v1262_11_head, p1, v1262_11_tail);
          v1263_7 = compose(v1263_5,v1264_6);
        }
        const Space v1263_8 = intersect(constant_3,v1263_2);
        const Space v1263_9 = (has_head(v1263_8) ? constant_4 : Space{});
        Space v1263_11;
        if (!v1263_9.empty()) {
          const Space v1265_10 = routine_62(c, v1262_11_head, p1, v1262_11_tail);
          v1263_11 = compose(v1263_9,v1265_10);
        }
        const Space v1263_12 = unite(v1263_7,v1263_11);
        v1262_11_result = unite(v1262_11_result,v1263_12);
      }
      const Space v1262_11 = std::move(v1262_11_result);
      v1260_12 = compose(v1260_9,v1262_11);
    }
    const Space v1260_13 = unite(v1260_7,v1260_12);
    v1259_15_result = unite(v1259_15_result,v1260_13);
  }
  const Space v1259_15 = std::move(v1259_15_result);
  return v1259_15;
}

static Space routine_144(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1266_12_result;
  for (int v1266_12_label = 1; v1266_12_label <= 2; ++v1266_12_label) {
    const Space v1266_12_tail = child(s0,v1266_12_label);
    if (v1266_12_tail.empty()) continue;
    const Path v1266_12_head{v1266_12_label};
    const Space v1267_2 = singleton(v1266_12_head);
    const Space v1267_3 = intersect(constant_3,v1267_2);
    const Space v1267_4 = (has_head(v1267_3) ? constant_4 : Space{});
    const Space v1267_5 = subtract(constant_2,v1267_4);
    Space v1267_8;
    if (!v1267_5.empty()) {
      const Path v1268_6 = concat_path(p0,v1266_12_head);
      Space v1268_7_result;
      for (int v1268_7_label = 1; v1268_7_label <= 2; ++v1268_7_label) {
        const Space v1268_7_tail = child(v1266_12_tail,v1268_7_label);
        if (v1268_7_tail.empty()) continue;
        const Path v1268_7_head{v1268_7_label};
        const Space v1269_2 = singleton(v1268_7_head);
        const Space v1269_3 = intersect(constant_3,v1269_2);
        const Space v1269_4 = (has_head(v1269_3) ? constant_4 : Space{});
        const Space v1269_5 = subtract(constant_2,v1269_4);
        Space v1269_8;
        if (!v1269_5.empty()) {
          const Path v1270_6 = concat_path(v1268_6,v1268_7_head);
          const Space v1270_7 = routine_170(c, v1270_6, p1, v1268_7_tail);
          v1269_8 = compose(v1269_5,v1270_7);
        }
        const Space v1269_9 = intersect(constant_3,v1269_2);
        const Space v1269_10 = (has_head(v1269_9) ? constant_4 : Space{});
        Space v1269_12;
        if (!v1269_10.empty()) {
          const Path v1271_6 = concat_path(v1268_6,v1268_7_head);
          const Space v1271_11 = routine_171(c, v1271_6, p1, v1268_7_tail);
          v1269_12 = compose(v1269_10,v1271_11);
        }
        const Space v1269_13 = unite(v1269_8,v1269_12);
        v1268_7_result = unite(v1268_7_result,v1269_13);
      }
      const Space v1268_7 = std::move(v1268_7_result);
      v1267_8 = compose(v1267_5,v1268_7);
    }
    const Space v1267_9 = intersect(constant_3,v1267_2);
    const Space v1267_10 = (has_head(v1267_9) ? constant_4 : Space{});
    Space v1267_12;
    if (!v1267_10.empty()) {
      const Path v1272_6 = concat_path(p0,v1266_12_head);
      Space v1272_11_result;
      for (int v1272_11_label = 1; v1272_11_label <= 2; ++v1272_11_label) {
        const Space v1272_11_tail = child(v1266_12_tail,v1272_11_label);
        if (v1272_11_tail.empty()) continue;
        const Path v1272_11_head{v1272_11_label};
        const Space v1273_2 = singleton(v1272_11_head);
        const Space v1273_3 = intersect(constant_3,v1273_2);
        const Space v1273_4 = (has_head(v1273_3) ? constant_4 : Space{});
        const Space v1273_5 = subtract(constant_2,v1273_4);
        Space v1273_8;
        if (!v1273_5.empty()) {
          const Path v1274_6 = concat_path(v1272_6,v1272_11_head);
          const Space v1274_7 = routine_170(c, v1274_6, p1, v1272_11_tail);
          v1273_8 = compose(v1273_5,v1274_7);
        }
        const Space v1273_9 = intersect(constant_3,v1273_2);
        const Space v1273_10 = (has_head(v1273_9) ? constant_4 : Space{});
        Space v1273_12;
        if (!v1273_10.empty()) {
          const Path v1275_6 = concat_path(v1272_6,v1272_11_head);
          const Space v1275_11 = routine_67(c, v1275_6, p1, v1272_11_tail);
          v1273_12 = compose(v1273_10,v1275_11);
        }
        const Space v1273_13 = unite(v1273_8,v1273_12);
        v1272_11_result = unite(v1272_11_result,v1273_13);
      }
      const Space v1272_11 = std::move(v1272_11_result);
      v1267_12 = compose(v1267_10,v1272_11);
    }
    const Space v1267_13 = unite(v1267_8,v1267_12);
    v1266_12_result = unite(v1266_12_result,v1267_13);
  }
  const Space v1266_12 = std::move(v1266_12_result);
  return v1266_12;
}

static Space routine_145(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1276_9_result;
  for (int v1276_9_label = 1; v1276_9_label <= 2; ++v1276_9_label) {
    const Space v1276_9_tail = child(s0,v1276_9_label);
    if (v1276_9_tail.empty()) continue;
    const Path v1276_9_head{v1276_9_label};
    const Space v1277_2 = singleton(v1276_9_head);
    const Space v1277_3 = intersect(constant_3,v1277_2);
    const Space v1277_4 = (has_head(v1277_3) ? constant_4 : Space{});
    const Space v1277_5 = subtract(constant_2,v1277_4);
    Space v1277_8;
    if (!v1277_5.empty()) {
      const Path v1278_6 = concat_path(p0,v1276_9_head);
      Space v1278_7_result;
      for (int v1278_7_label = 1; v1278_7_label <= 2; ++v1278_7_label) {
        const Space v1278_7_tail = child(v1276_9_tail,v1278_7_label);
        if (v1278_7_tail.empty()) continue;
        const Path v1278_7_head{v1278_7_label};
        const Space v1279_2 = singleton(v1278_7_head);
        const Space v1279_3 = intersect(constant_3,v1279_2);
        const Space v1279_4 = (has_head(v1279_3) ? constant_4 : Space{});
        const Space v1279_5 = subtract(constant_2,v1279_4);
        Space v1279_8;
        if (!v1279_5.empty()) {
          const Path v1280_6 = concat_path(v1278_6,v1278_7_head);
          const Space v1280_7 = routine_170(c, v1280_6, p1, v1278_7_tail);
          v1279_8 = compose(v1279_5,v1280_7);
        }
        const Space v1279_9 = intersect(constant_3,v1279_2);
        const Space v1279_10 = (has_head(v1279_9) ? constant_4 : Space{});
        Space v1279_12;
        if (!v1279_10.empty()) {
          const Path v1281_6 = concat_path(v1278_6,v1278_7_head);
          const Space v1281_11 = routine_171(c, v1281_6, p1, v1278_7_tail);
          v1279_12 = compose(v1279_10,v1281_11);
        }
        const Space v1279_13 = unite(v1279_8,v1279_12);
        v1278_7_result = unite(v1278_7_result,v1279_13);
      }
      const Space v1278_7 = std::move(v1278_7_result);
      v1277_8 = compose(v1277_5,v1278_7);
    }
    const Space v1277_9 = intersect(constant_3,v1277_2);
    const Space v1277_10 = (has_head(v1277_9) ? constant_4 : Space{});
    const Space v1277_11 = compose(v1277_10,v1276_9_tail);
    const Path v1282_6 = concat_path(p0,v1276_9_head);
    const Space v1277_12 = wrap(v1277_11,v1282_6);
    const Space v1277_13 = wrap(v1277_12,p1);
    const Space v1277_14 = unite(v1277_8,v1277_13);
    v1276_9_result = unite(v1276_9_result,v1277_14);
  }
  const Space v1276_9 = std::move(v1276_9_result);
  return v1276_9;
}

static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1283_4_result;
  for (int v1283_4_label = 1; v1283_4_label <= 2; ++v1283_4_label) {
    const Space v1283_4_tail = child(s0,v1283_4_label);
    if (v1283_4_tail.empty()) continue;
    const Path v1283_4_head{v1283_4_label};
    const Space v1284_2 = Space{};
    v1283_4_result = unite(v1283_4_result,v1284_2);
  }
  const Space v1283_4 = std::move(v1283_4_result);
  return v1283_4;
}

static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1285_6 = unwrap(s1,constant_5);
  const Space v1285_8 = unwrap(v1285_6,constant_6);
  const Space v1285_9 = unwrap(v1285_8,p0);
  Space v1285_13_result;
  for (int v1285_13_label = 1; v1285_13_label <= 2; ++v1285_13_label) {
    const Space v1285_13_tail = child(s0,v1285_13_label);
    if (v1285_13_tail.empty()) continue;
    const Path v1285_13_head{v1285_13_label};
    const Space v1286_2 = singleton(v1285_13_head);
    const Space v1286_3 = intersect(constant_3,v1286_2);
    const Space v1286_4 = (has_head(v1286_3) ? constant_4 : Space{});
    Space v1286_7;
    if (!v1286_4.empty()) {
      const Space v1287_5 = unwrap(v1285_9,v1285_13_head);
      Space v1287_6_result;
      for (int v1287_6_label = 1; v1287_6_label <= 2; ++v1287_6_label) {
        const Space v1287_6_tail = child(v1287_5,v1287_6_label);
        if (v1287_6_tail.empty()) continue;
        const Path v1287_6_head{v1287_6_label};
        const Space v1288_2 = singleton(v1287_6_head);
        const Space v1288_3 = intersect(constant_3,v1288_2);
        const Space v1288_4 = (has_head(v1288_3) ? constant_4 : Space{});
        const Space v1288_5 = subtract(constant_2,v1288_4);
        Space v1288_7;
        if (!v1288_5.empty()) {
          const Space v1289_6 = routine_61(c, v1287_6_head, p1, v1287_6_tail);
          v1288_7 = compose(v1288_5,v1289_6);
        }
        const Space v1288_8 = intersect(constant_3,v1288_2);
        const Space v1288_9 = (has_head(v1288_8) ? constant_4 : Space{});
        Space v1288_11;
        if (!v1288_9.empty()) {
          const Space v1290_10 = routine_62(c, v1287_6_head, p1, v1287_6_tail);
          v1288_11 = compose(v1288_9,v1290_10);
        }
        const Space v1288_12 = unite(v1288_7,v1288_11);
        v1287_6_result = unite(v1287_6_result,v1288_12);
      }
      const Space v1287_6 = std::move(v1287_6_result);
      v1286_7 = compose(v1286_4,v1287_6);
    }
    v1285_13_result = unite(v1285_13_result,v1286_7);
  }
  const Space v1285_13 = std::move(v1285_13_result);
  return v1285_13;
}

static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1291_12_result;
  for (int v1291_12_label = 1; v1291_12_label <= 2; ++v1291_12_label) {
    const Space v1291_12_tail = child(s0,v1291_12_label);
    if (v1291_12_tail.empty()) continue;
    const Path v1291_12_head{v1291_12_label};
    const Space v1292_2 = singleton(v1291_12_head);
    const Space v1292_3 = intersect(constant_3,v1292_2);
    const Space v1292_4 = (has_head(v1292_3) ? constant_4 : Space{});
    const Space v1292_5 = subtract(constant_2,v1292_4);
    Space v1292_8;
    if (!v1292_5.empty()) {
      const Path v1293_6 = concat_path(p0,v1291_12_head);
      Space v1293_7_result;
      for (int v1293_7_label = 1; v1293_7_label <= 2; ++v1293_7_label) {
        const Space v1293_7_tail = child(v1291_12_tail,v1293_7_label);
        if (v1293_7_tail.empty()) continue;
        const Path v1293_7_head{v1293_7_label};
        const Space v1294_2 = singleton(v1293_7_head);
        const Space v1294_3 = intersect(constant_3,v1294_2);
        const Space v1294_4 = (has_head(v1294_3) ? constant_4 : Space{});
        const Space v1294_5 = subtract(constant_2,v1294_4);
        Space v1294_8;
        if (!v1294_5.empty()) {
          const Path v1295_6 = concat_path(v1293_6,v1293_7_head);
          const Space v1295_7 = routine_172(c, v1295_6, p1, v1293_7_tail);
          v1294_8 = compose(v1294_5,v1295_7);
        }
        const Space v1294_9 = intersect(constant_3,v1294_2);
        const Space v1294_10 = (has_head(v1294_9) ? constant_4 : Space{});
        Space v1294_12;
        if (!v1294_10.empty()) {
          const Path v1296_6 = concat_path(v1293_6,v1293_7_head);
          const Space v1296_11 = routine_173(c, v1296_6, p1, v1293_7_tail);
          v1294_12 = compose(v1294_10,v1296_11);
        }
        const Space v1294_13 = unite(v1294_8,v1294_12);
        v1293_7_result = unite(v1293_7_result,v1294_13);
      }
      const Space v1293_7 = std::move(v1293_7_result);
      v1292_8 = compose(v1292_5,v1293_7);
    }
    const Space v1292_9 = intersect(constant_3,v1292_2);
    const Space v1292_10 = (has_head(v1292_9) ? constant_4 : Space{});
    Space v1292_12;
    if (!v1292_10.empty()) {
      const Path v1297_6 = concat_path(p0,v1291_12_head);
      Space v1297_11_result;
      for (int v1297_11_label = 1; v1297_11_label <= 2; ++v1297_11_label) {
        const Space v1297_11_tail = child(v1291_12_tail,v1297_11_label);
        if (v1297_11_tail.empty()) continue;
        const Path v1297_11_head{v1297_11_label};
        const Space v1298_2 = singleton(v1297_11_head);
        const Space v1298_3 = intersect(constant_3,v1298_2);
        const Space v1298_4 = (has_head(v1298_3) ? constant_4 : Space{});
        const Space v1298_5 = subtract(constant_2,v1298_4);
        Space v1298_8;
        if (!v1298_5.empty()) {
          const Path v1299_6 = concat_path(v1297_6,v1297_11_head);
          const Space v1299_7 = routine_172(c, v1299_6, p1, v1297_11_tail);
          v1298_8 = compose(v1298_5,v1299_7);
        }
        const Space v1298_9 = intersect(constant_3,v1298_2);
        const Space v1298_10 = (has_head(v1298_9) ? constant_4 : Space{});
        Space v1298_12;
        if (!v1298_10.empty()) {
          const Path v1300_6 = concat_path(v1297_6,v1297_11_head);
          const Space v1300_11 = routine_67(c, v1300_6, p1, v1297_11_tail);
          v1298_12 = compose(v1298_10,v1300_11);
        }
        const Space v1298_13 = unite(v1298_8,v1298_12);
        v1297_11_result = unite(v1297_11_result,v1298_13);
      }
      const Space v1297_11 = std::move(v1297_11_result);
      v1292_12 = compose(v1292_10,v1297_11);
    }
    const Space v1292_13 = unite(v1292_8,v1292_12);
    v1291_12_result = unite(v1291_12_result,v1292_13);
  }
  const Space v1291_12 = std::move(v1291_12_result);
  return v1291_12;
}

static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1301_9_result;
  for (int v1301_9_label = 1; v1301_9_label <= 2; ++v1301_9_label) {
    const Space v1301_9_tail = child(s0,v1301_9_label);
    if (v1301_9_tail.empty()) continue;
    const Path v1301_9_head{v1301_9_label};
    const Space v1302_2 = singleton(v1301_9_head);
    const Space v1302_3 = intersect(constant_3,v1302_2);
    const Space v1302_4 = (has_head(v1302_3) ? constant_4 : Space{});
    const Space v1302_5 = subtract(constant_2,v1302_4);
    Space v1302_8;
    if (!v1302_5.empty()) {
      const Path v1303_6 = concat_path(p0,v1301_9_head);
      Space v1303_7_result;
      for (int v1303_7_label = 1; v1303_7_label <= 2; ++v1303_7_label) {
        const Space v1303_7_tail = child(v1301_9_tail,v1303_7_label);
        if (v1303_7_tail.empty()) continue;
        const Path v1303_7_head{v1303_7_label};
        const Space v1304_2 = singleton(v1303_7_head);
        const Space v1304_3 = intersect(constant_3,v1304_2);
        const Space v1304_4 = (has_head(v1304_3) ? constant_4 : Space{});
        const Space v1304_5 = subtract(constant_2,v1304_4);
        Space v1304_8;
        if (!v1304_5.empty()) {
          const Path v1305_6 = concat_path(v1303_6,v1303_7_head);
          const Space v1305_7 = routine_172(c, v1305_6, p1, v1303_7_tail);
          v1304_8 = compose(v1304_5,v1305_7);
        }
        const Space v1304_9 = intersect(constant_3,v1304_2);
        const Space v1304_10 = (has_head(v1304_9) ? constant_4 : Space{});
        Space v1304_12;
        if (!v1304_10.empty()) {
          const Path v1306_6 = concat_path(v1303_6,v1303_7_head);
          const Space v1306_11 = routine_173(c, v1306_6, p1, v1303_7_tail);
          v1304_12 = compose(v1304_10,v1306_11);
        }
        const Space v1304_13 = unite(v1304_8,v1304_12);
        v1303_7_result = unite(v1303_7_result,v1304_13);
      }
      const Space v1303_7 = std::move(v1303_7_result);
      v1302_8 = compose(v1302_5,v1303_7);
    }
    const Space v1302_9 = intersect(constant_3,v1302_2);
    const Space v1302_10 = (has_head(v1302_9) ? constant_4 : Space{});
    const Space v1302_11 = compose(v1302_10,v1301_9_tail);
    const Path v1307_6 = concat_path(p0,v1301_9_head);
    const Space v1302_12 = wrap(v1302_11,v1307_6);
    const Space v1302_13 = wrap(v1302_12,p1);
    const Space v1302_14 = unite(v1302_8,v1302_13);
    v1301_9_result = unite(v1301_9_result,v1302_14);
  }
  const Space v1301_9 = std::move(v1301_9_result);
  return v1301_9;
}

static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1308_7_result;
  for (int v1308_7_label = 1; v1308_7_label <= 2; ++v1308_7_label) {
    const Space v1308_7_tail = child(s0,v1308_7_label);
    if (v1308_7_tail.empty()) continue;
    const Path v1308_7_head{v1308_7_label};
    const Space v1309_2 = singleton(v1308_7_head);
    const Space v1309_3 = intersect(constant_3,v1309_2);
    const Space v1309_4 = (has_head(v1309_3) ? constant_4 : Space{});
    const Space v1309_5 = subtract(constant_2,v1309_4);
    Space v1309_6_result;
    for (int v1309_6_label = 1; v1309_6_label <= 2; ++v1309_6_label) {
      const Space v1309_6_tail = child(v1308_7_tail,v1309_6_label);
      if (v1309_6_tail.empty()) continue;
      const Path v1309_6_head{v1309_6_label};
      const Space v1310_2 = Space{};
      v1309_6_result = unite(v1309_6_result,v1310_2);
    }
    const Space v1309_6 = std::move(v1309_6_result);
    const Space v1309_7 = compose(v1309_5,v1309_6);
    const Space v1309_8 = intersect(constant_3,v1309_2);
    const Space v1309_9 = (has_head(v1309_8) ? constant_4 : Space{});
    Space v1309_12;
    if (!v1309_9.empty()) {
      const Path v1311_10 = concat_path(p0,v1308_7_head);
      Space v1311_11_result;
      for (int v1311_11_label = 1; v1311_11_label <= 2; ++v1311_11_label) {
        const Space v1311_11_tail = child(v1308_7_tail,v1311_11_label);
        if (v1311_11_tail.empty()) continue;
        const Path v1311_11_head{v1311_11_label};
        const Space v1312_2 = singleton(v1311_11_head);
        const Space v1312_3 = intersect(constant_3,v1312_2);
        const Space v1312_4 = (has_head(v1312_3) ? constant_4 : Space{});
        Space v1312_7;
        if (!v1312_4.empty()) {
          const Path v1313_5 = concat_path(v1311_10,v1311_11_head);
          const Space v1313_6 = routine_36(c, v1313_5, p1, v1311_11_tail);
          v1312_7 = compose(v1312_4,v1313_6);
        }
        v1311_11_result = unite(v1311_11_result,v1312_7);
      }
      const Space v1311_11 = std::move(v1311_11_result);
      v1309_12 = compose(v1309_9,v1311_11);
    }
    const Space v1309_13 = unite(v1309_7,v1309_12);
    v1308_7_result = unite(v1308_7_result,v1309_13);
  }
  const Space v1308_7 = std::move(v1308_7_result);
  return v1308_7;
}

static Space routine_151(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1314_6_result;
  for (int v1314_6_label = 1; v1314_6_label <= 2; ++v1314_6_label) {
    const Space v1314_6_tail = child(s0,v1314_6_label);
    if (v1314_6_tail.empty()) continue;
    const Path v1314_6_head{v1314_6_label};
    const Space v1315_2 = singleton(v1314_6_head);
    const Space v1315_3 = intersect(constant_3,v1315_2);
    const Space v1315_4 = (has_head(v1315_3) ? constant_4 : Space{});
    const Space v1315_5 = subtract(constant_2,v1315_4);
    Space v1315_6_result;
    for (int v1315_6_label = 1; v1315_6_label <= 2; ++v1315_6_label) {
      const Space v1315_6_tail = child(v1314_6_tail,v1315_6_label);
      if (v1315_6_tail.empty()) continue;
      const Path v1315_6_head{v1315_6_label};
      const Space v1316_2 = Space{};
      v1315_6_result = unite(v1315_6_result,v1316_2);
    }
    const Space v1315_6 = std::move(v1315_6_result);
    const Space v1315_7 = compose(v1315_5,v1315_6);
    const Space v1315_8 = intersect(constant_3,v1315_2);
    const Space v1315_9 = (has_head(v1315_8) ? constant_4 : Space{});
    const Space v1315_10 = compose(v1315_9,v1314_6_tail);
    const Path v1315_11 = concat_path(p0,v1314_6_head);
    const Space v1315_12 = wrap(v1315_10,v1315_11);
    const Space v1315_13 = wrap(v1315_12,p1);
    const Space v1315_14 = unite(v1315_7,v1315_13);
    v1314_6_result = unite(v1314_6_result,v1315_14);
  }
  const Space v1314_6 = std::move(v1314_6_result);
  return v1314_6;
}

static Space routine_152(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1317_3_result;
  for (int v1317_3_label = 1; v1317_3_label <= 2; ++v1317_3_label) {
    const Space v1317_3_tail = child(s0,v1317_3_label);
    if (v1317_3_tail.empty()) continue;
    const Path v1317_3_head{v1317_3_label};
    const Space v1318_2 = Space{};
    v1317_3_result = unite(v1317_3_result,v1318_2);
  }
  const Space v1317_3 = std::move(v1317_3_result);
  return v1317_3;
}

static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1319_4_result;
  for (int v1319_4_label = 1; v1319_4_label <= 2; ++v1319_4_label) {
    const Space v1319_4_tail = child(s0,v1319_4_label);
    if (v1319_4_tail.empty()) continue;
    const Path v1319_4_head{v1319_4_label};
    const Space v1320_2 = singleton(v1319_4_head);
    const Space v1320_3 = intersect(constant_3,v1320_2);
    const Space v1320_4 = (has_head(v1320_3) ? constant_4 : Space{});
    const Space v1320_5 = compose(v1320_4,v1319_4_tail);
    const Path v1320_6 = concat_path(p0,v1319_4_head);
    const Space v1320_7 = wrap(v1320_5,v1320_6);
    v1319_4_result = unite(v1319_4_result,v1320_7);
  }
  const Space v1319_4 = std::move(v1319_4_result);
  const Space v1319_5 = wrap(v1319_4,p1);
  return v1319_5;
}

static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1321_8_result;
  for (int v1321_8_label = 1; v1321_8_label <= 2; ++v1321_8_label) {
    const Space v1321_8_tail = child(s0,v1321_8_label);
    if (v1321_8_tail.empty()) continue;
    const Path v1321_8_head{v1321_8_label};
    const Space v1322_2 = singleton(v1321_8_head);
    const Space v1322_3 = intersect(constant_3,v1322_2);
    const Space v1322_4 = (has_head(v1322_3) ? constant_4 : Space{});
    const Space v1322_5 = subtract(constant_2,v1322_4);
    Space v1322_6_result;
    for (int v1322_6_label = 1; v1322_6_label <= 2; ++v1322_6_label) {
      const Space v1322_6_tail = child(v1321_8_tail,v1322_6_label);
      if (v1322_6_tail.empty()) continue;
      const Path v1322_6_head{v1322_6_label};
      const Space v1323_2 = Space{};
      v1322_6_result = unite(v1322_6_result,v1323_2);
    }
    const Space v1322_6 = std::move(v1322_6_result);
    const Space v1322_7 = compose(v1322_5,v1322_6);
    const Space v1322_8 = intersect(constant_3,v1322_2);
    const Space v1322_9 = (has_head(v1322_8) ? constant_4 : Space{});
    Space v1322_12;
    if (!v1322_9.empty()) {
      const Path v1324_10 = concat_path(p0,v1321_8_head);
      Space v1324_11_result;
      for (int v1324_11_label = 1; v1324_11_label <= 2; ++v1324_11_label) {
        const Space v1324_11_tail = child(v1321_8_tail,v1324_11_label);
        if (v1324_11_tail.empty()) continue;
        const Path v1324_11_head{v1324_11_label};
        const Space v1325_2 = singleton(v1324_11_head);
        const Space v1325_3 = intersect(constant_3,v1325_2);
        const Space v1325_4 = (has_head(v1325_3) ? constant_4 : Space{});
        Space v1325_7;
        if (!v1325_4.empty()) {
          const Path v1326_5 = concat_path(v1324_10,v1324_11_head);
          const Space v1326_6 = routine_43(c, v1326_5, p1, v1324_11_tail, s1);
          v1325_7 = compose(v1325_4,v1326_6);
        }
        v1324_11_result = unite(v1324_11_result,v1325_7);
      }
      const Space v1324_11 = std::move(v1324_11_result);
      v1322_12 = compose(v1322_9,v1324_11);
    }
    const Space v1322_13 = unite(v1322_7,v1322_12);
    v1321_8_result = unite(v1321_8_result,v1322_13);
  }
  const Space v1321_8 = std::move(v1321_8_result);
  return v1321_8;
}

static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1327_8 = unwrap(s1,constant_0);
  const Space v1327_10 = unwrap(v1327_8,constant_6);
  const Space v1327_11 = unwrap(v1327_10,p0);
  Space v1327_15_result;
  for (int v1327_15_label = 1; v1327_15_label <= 2; ++v1327_15_label) {
    const Space v1327_15_tail = child(s0,v1327_15_label);
    if (v1327_15_tail.empty()) continue;
    const Path v1327_15_head{v1327_15_label};
    const Space v1328_2 = singleton(v1327_15_head);
    const Space v1328_3 = intersect(constant_3,v1328_2);
    const Space v1328_4 = (has_head(v1328_3) ? constant_4 : Space{});
    const Space v1328_5 = subtract(constant_2,v1328_4);
    Space v1328_6_result;
    for (int v1328_6_label = 1; v1328_6_label <= 2; ++v1328_6_label) {
      const Space v1328_6_tail = child(v1327_15_tail,v1328_6_label);
      if (v1328_6_tail.empty()) continue;
      const Path v1328_6_head{v1328_6_label};
      const Space v1329_2 = Space{};
      v1328_6_result = unite(v1328_6_result,v1329_2);
    }
    const Space v1328_6 = std::move(v1328_6_result);
    const Space v1328_7 = compose(v1328_5,v1328_6);
    const Space v1328_8 = intersect(constant_3,v1328_2);
    const Space v1328_9 = (has_head(v1328_8) ? constant_4 : Space{});
    Space v1328_12;
    if (!v1328_9.empty()) {
      const Space v1330_10 = unwrap(v1327_11,v1327_15_head);
      Space v1330_11_result;
      for (int v1330_11_label = 1; v1330_11_label <= 2; ++v1330_11_label) {
        const Space v1330_11_tail = child(v1330_10,v1330_11_label);
        if (v1330_11_tail.empty()) continue;
        const Path v1330_11_head{v1330_11_label};
        const Space v1331_2 = singleton(v1330_11_head);
        const Space v1331_3 = intersect(constant_3,v1331_2);
        const Space v1331_4 = (has_head(v1331_3) ? constant_4 : Space{});
        const Space v1331_5 = subtract(constant_2,v1331_4);
        Space v1331_7;
        if (!v1331_5.empty()) {
          const Space v1332_6 = routine_78(c, v1330_11_head, p1, v1330_11_tail);
          v1331_7 = compose(v1331_5,v1332_6);
        }
        const Space v1331_8 = intersect(constant_3,v1331_2);
        const Space v1331_9 = (has_head(v1331_8) ? constant_4 : Space{});
        Space v1331_11;
        if (!v1331_9.empty()) {
          const Space v1333_10 = routine_79(c, v1330_11_head, p1, v1330_11_tail);
          v1331_11 = compose(v1331_9,v1333_10);
        }
        const Space v1331_12 = unite(v1331_7,v1331_11);
        v1330_11_result = unite(v1330_11_result,v1331_12);
      }
      const Space v1330_11 = std::move(v1330_11_result);
      v1328_12 = compose(v1328_9,v1330_11);
    }
    const Space v1328_13 = unite(v1328_7,v1328_12);
    v1327_15_result = unite(v1327_15_result,v1328_13);
  }
  const Space v1327_15 = std::move(v1327_15_result);
  return v1327_15;
}

static Space routine_156(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1334_12_result;
  for (int v1334_12_label = 1; v1334_12_label <= 2; ++v1334_12_label) {
    const Space v1334_12_tail = child(s0,v1334_12_label);
    if (v1334_12_tail.empty()) continue;
    const Path v1334_12_head{v1334_12_label};
    const Space v1335_2 = singleton(v1334_12_head);
    const Space v1335_3 = intersect(constant_3,v1335_2);
    const Space v1335_4 = (has_head(v1335_3) ? constant_4 : Space{});
    const Space v1335_5 = subtract(constant_2,v1335_4);
    Space v1335_8;
    if (!v1335_5.empty()) {
      const Path v1336_6 = concat_path(p0,v1334_12_head);
      Space v1336_7_result;
      for (int v1336_7_label = 1; v1336_7_label <= 2; ++v1336_7_label) {
        const Space v1336_7_tail = child(v1334_12_tail,v1336_7_label);
        if (v1336_7_tail.empty()) continue;
        const Path v1336_7_head{v1336_7_label};
        const Space v1337_2 = singleton(v1336_7_head);
        const Space v1337_3 = intersect(constant_3,v1337_2);
        const Space v1337_4 = (has_head(v1337_3) ? constant_4 : Space{});
        const Space v1337_5 = subtract(constant_2,v1337_4);
        Space v1337_8;
        if (!v1337_5.empty()) {
          const Path v1338_6 = concat_path(v1336_6,v1336_7_head);
          const Space v1338_7 = routine_174(c, v1338_6, p1, v1336_7_tail);
          v1337_8 = compose(v1337_5,v1338_7);
        }
        const Space v1337_9 = intersect(constant_3,v1337_2);
        const Space v1337_10 = (has_head(v1337_9) ? constant_4 : Space{});
        Space v1337_12;
        if (!v1337_10.empty()) {
          const Path v1339_6 = concat_path(v1336_6,v1336_7_head);
          const Space v1339_11 = routine_175(c, v1339_6, p1, v1336_7_tail);
          v1337_12 = compose(v1337_10,v1339_11);
        }
        const Space v1337_13 = unite(v1337_8,v1337_12);
        v1336_7_result = unite(v1336_7_result,v1337_13);
      }
      const Space v1336_7 = std::move(v1336_7_result);
      v1335_8 = compose(v1335_5,v1336_7);
    }
    const Space v1335_9 = intersect(constant_3,v1335_2);
    const Space v1335_10 = (has_head(v1335_9) ? constant_4 : Space{});
    Space v1335_12;
    if (!v1335_10.empty()) {
      const Path v1340_6 = concat_path(p0,v1334_12_head);
      Space v1340_11_result;
      for (int v1340_11_label = 1; v1340_11_label <= 2; ++v1340_11_label) {
        const Space v1340_11_tail = child(v1334_12_tail,v1340_11_label);
        if (v1340_11_tail.empty()) continue;
        const Path v1340_11_head{v1340_11_label};
        const Space v1341_2 = singleton(v1340_11_head);
        const Space v1341_3 = intersect(constant_3,v1341_2);
        const Space v1341_4 = (has_head(v1341_3) ? constant_4 : Space{});
        const Space v1341_5 = subtract(constant_2,v1341_4);
        Space v1341_8;
        if (!v1341_5.empty()) {
          const Path v1342_6 = concat_path(v1340_6,v1340_11_head);
          const Space v1342_7 = routine_174(c, v1342_6, p1, v1340_11_tail);
          v1341_8 = compose(v1341_5,v1342_7);
        }
        const Space v1341_9 = intersect(constant_3,v1341_2);
        const Space v1341_10 = (has_head(v1341_9) ? constant_4 : Space{});
        Space v1341_12;
        if (!v1341_10.empty()) {
          const Path v1343_6 = concat_path(v1340_6,v1340_11_head);
          const Space v1343_11 = routine_84(c, v1343_6, p1, v1340_11_tail);
          v1341_12 = compose(v1341_10,v1343_11);
        }
        const Space v1341_13 = unite(v1341_8,v1341_12);
        v1340_11_result = unite(v1340_11_result,v1341_13);
      }
      const Space v1340_11 = std::move(v1340_11_result);
      v1335_12 = compose(v1335_10,v1340_11);
    }
    const Space v1335_13 = unite(v1335_8,v1335_12);
    v1334_12_result = unite(v1334_12_result,v1335_13);
  }
  const Space v1334_12 = std::move(v1334_12_result);
  return v1334_12;
}

static Space routine_157(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1344_9_result;
  for (int v1344_9_label = 1; v1344_9_label <= 2; ++v1344_9_label) {
    const Space v1344_9_tail = child(s0,v1344_9_label);
    if (v1344_9_tail.empty()) continue;
    const Path v1344_9_head{v1344_9_label};
    const Space v1345_2 = singleton(v1344_9_head);
    const Space v1345_3 = intersect(constant_3,v1345_2);
    const Space v1345_4 = (has_head(v1345_3) ? constant_4 : Space{});
    const Space v1345_5 = subtract(constant_2,v1345_4);
    Space v1345_8;
    if (!v1345_5.empty()) {
      const Path v1346_6 = concat_path(p0,v1344_9_head);
      Space v1346_7_result;
      for (int v1346_7_label = 1; v1346_7_label <= 2; ++v1346_7_label) {
        const Space v1346_7_tail = child(v1344_9_tail,v1346_7_label);
        if (v1346_7_tail.empty()) continue;
        const Path v1346_7_head{v1346_7_label};
        const Space v1347_2 = singleton(v1346_7_head);
        const Space v1347_3 = intersect(constant_3,v1347_2);
        const Space v1347_4 = (has_head(v1347_3) ? constant_4 : Space{});
        const Space v1347_5 = subtract(constant_2,v1347_4);
        Space v1347_8;
        if (!v1347_5.empty()) {
          const Path v1348_6 = concat_path(v1346_6,v1346_7_head);
          const Space v1348_7 = routine_174(c, v1348_6, p1, v1346_7_tail);
          v1347_8 = compose(v1347_5,v1348_7);
        }
        const Space v1347_9 = intersect(constant_3,v1347_2);
        const Space v1347_10 = (has_head(v1347_9) ? constant_4 : Space{});
        Space v1347_12;
        if (!v1347_10.empty()) {
          const Path v1349_6 = concat_path(v1346_6,v1346_7_head);
          const Space v1349_11 = routine_175(c, v1349_6, p1, v1346_7_tail);
          v1347_12 = compose(v1347_10,v1349_11);
        }
        const Space v1347_13 = unite(v1347_8,v1347_12);
        v1346_7_result = unite(v1346_7_result,v1347_13);
      }
      const Space v1346_7 = std::move(v1346_7_result);
      v1345_8 = compose(v1345_5,v1346_7);
    }
    const Space v1345_9 = intersect(constant_3,v1345_2);
    const Space v1345_10 = (has_head(v1345_9) ? constant_4 : Space{});
    const Space v1345_11 = compose(v1345_10,v1344_9_tail);
    const Path v1350_6 = concat_path(p0,v1344_9_head);
    const Space v1345_12 = wrap(v1345_11,v1350_6);
    const Space v1345_13 = wrap(v1345_12,p1);
    const Space v1345_14 = unite(v1345_8,v1345_13);
    v1344_9_result = unite(v1344_9_result,v1345_14);
  }
  const Space v1344_9 = std::move(v1344_9_result);
  return v1344_9;
}

static Space routine_158(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1351_4_result;
  for (int v1351_4_label = 1; v1351_4_label <= 2; ++v1351_4_label) {
    const Space v1351_4_tail = child(s0,v1351_4_label);
    if (v1351_4_tail.empty()) continue;
    const Path v1351_4_head{v1351_4_label};
    const Space v1352_2 = Space{};
    v1351_4_result = unite(v1351_4_result,v1352_2);
  }
  const Space v1351_4 = std::move(v1351_4_result);
  return v1351_4;
}

static Space routine_159(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1353_6 = unwrap(s1,constant_0);
  const Space v1353_8 = unwrap(v1353_6,constant_6);
  const Space v1353_9 = unwrap(v1353_8,p0);
  Space v1353_13_result;
  for (int v1353_13_label = 1; v1353_13_label <= 2; ++v1353_13_label) {
    const Space v1353_13_tail = child(s0,v1353_13_label);
    if (v1353_13_tail.empty()) continue;
    const Path v1353_13_head{v1353_13_label};
    const Space v1354_2 = singleton(v1353_13_head);
    const Space v1354_3 = intersect(constant_3,v1354_2);
    const Space v1354_4 = (has_head(v1354_3) ? constant_4 : Space{});
    Space v1354_7;
    if (!v1354_4.empty()) {
      const Space v1355_5 = unwrap(v1353_9,v1353_13_head);
      Space v1355_6_result;
      for (int v1355_6_label = 1; v1355_6_label <= 2; ++v1355_6_label) {
        const Space v1355_6_tail = child(v1355_5,v1355_6_label);
        if (v1355_6_tail.empty()) continue;
        const Path v1355_6_head{v1355_6_label};
        const Space v1356_2 = singleton(v1355_6_head);
        const Space v1356_3 = intersect(constant_3,v1356_2);
        const Space v1356_4 = (has_head(v1356_3) ? constant_4 : Space{});
        const Space v1356_5 = subtract(constant_2,v1356_4);
        Space v1356_7;
        if (!v1356_5.empty()) {
          const Space v1357_6 = routine_78(c, v1355_6_head, p1, v1355_6_tail);
          v1356_7 = compose(v1356_5,v1357_6);
        }
        const Space v1356_8 = intersect(constant_3,v1356_2);
        const Space v1356_9 = (has_head(v1356_8) ? constant_4 : Space{});
        Space v1356_11;
        if (!v1356_9.empty()) {
          const Space v1358_10 = routine_79(c, v1355_6_head, p1, v1355_6_tail);
          v1356_11 = compose(v1356_9,v1358_10);
        }
        const Space v1356_12 = unite(v1356_7,v1356_11);
        v1355_6_result = unite(v1355_6_result,v1356_12);
      }
      const Space v1355_6 = std::move(v1355_6_result);
      v1354_7 = compose(v1354_4,v1355_6);
    }
    v1353_13_result = unite(v1353_13_result,v1354_7);
  }
  const Space v1353_13 = std::move(v1353_13_result);
  return v1353_13;
}

static Space routine_160(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1359_12_result;
  for (int v1359_12_label = 1; v1359_12_label <= 2; ++v1359_12_label) {
    const Space v1359_12_tail = child(s0,v1359_12_label);
    if (v1359_12_tail.empty()) continue;
    const Path v1359_12_head{v1359_12_label};
    const Space v1360_2 = singleton(v1359_12_head);
    const Space v1360_3 = intersect(constant_3,v1360_2);
    const Space v1360_4 = (has_head(v1360_3) ? constant_4 : Space{});
    const Space v1360_5 = subtract(constant_2,v1360_4);
    Space v1360_8;
    if (!v1360_5.empty()) {
      const Path v1361_6 = concat_path(p0,v1359_12_head);
      Space v1361_7_result;
      for (int v1361_7_label = 1; v1361_7_label <= 2; ++v1361_7_label) {
        const Space v1361_7_tail = child(v1359_12_tail,v1361_7_label);
        if (v1361_7_tail.empty()) continue;
        const Path v1361_7_head{v1361_7_label};
        const Space v1362_2 = singleton(v1361_7_head);
        const Space v1362_3 = intersect(constant_3,v1362_2);
        const Space v1362_4 = (has_head(v1362_3) ? constant_4 : Space{});
        const Space v1362_5 = subtract(constant_2,v1362_4);
        Space v1362_8;
        if (!v1362_5.empty()) {
          const Path v1363_6 = concat_path(v1361_6,v1361_7_head);
          const Space v1363_7 = routine_176(c, v1363_6, p1, v1361_7_tail);
          v1362_8 = compose(v1362_5,v1363_7);
        }
        const Space v1362_9 = intersect(constant_3,v1362_2);
        const Space v1362_10 = (has_head(v1362_9) ? constant_4 : Space{});
        Space v1362_12;
        if (!v1362_10.empty()) {
          const Path v1364_6 = concat_path(v1361_6,v1361_7_head);
          const Space v1364_11 = routine_177(c, v1364_6, p1, v1361_7_tail);
          v1362_12 = compose(v1362_10,v1364_11);
        }
        const Space v1362_13 = unite(v1362_8,v1362_12);
        v1361_7_result = unite(v1361_7_result,v1362_13);
      }
      const Space v1361_7 = std::move(v1361_7_result);
      v1360_8 = compose(v1360_5,v1361_7);
    }
    const Space v1360_9 = intersect(constant_3,v1360_2);
    const Space v1360_10 = (has_head(v1360_9) ? constant_4 : Space{});
    Space v1360_12;
    if (!v1360_10.empty()) {
      const Path v1365_6 = concat_path(p0,v1359_12_head);
      Space v1365_11_result;
      for (int v1365_11_label = 1; v1365_11_label <= 2; ++v1365_11_label) {
        const Space v1365_11_tail = child(v1359_12_tail,v1365_11_label);
        if (v1365_11_tail.empty()) continue;
        const Path v1365_11_head{v1365_11_label};
        const Space v1366_2 = singleton(v1365_11_head);
        const Space v1366_3 = intersect(constant_3,v1366_2);
        const Space v1366_4 = (has_head(v1366_3) ? constant_4 : Space{});
        const Space v1366_5 = subtract(constant_2,v1366_4);
        Space v1366_8;
        if (!v1366_5.empty()) {
          const Path v1367_6 = concat_path(v1365_6,v1365_11_head);
          const Space v1367_7 = routine_176(c, v1367_6, p1, v1365_11_tail);
          v1366_8 = compose(v1366_5,v1367_7);
        }
        const Space v1366_9 = intersect(constant_3,v1366_2);
        const Space v1366_10 = (has_head(v1366_9) ? constant_4 : Space{});
        Space v1366_12;
        if (!v1366_10.empty()) {
          const Path v1368_6 = concat_path(v1365_6,v1365_11_head);
          const Space v1368_11 = routine_84(c, v1368_6, p1, v1365_11_tail);
          v1366_12 = compose(v1366_10,v1368_11);
        }
        const Space v1366_13 = unite(v1366_8,v1366_12);
        v1365_11_result = unite(v1365_11_result,v1366_13);
      }
      const Space v1365_11 = std::move(v1365_11_result);
      v1360_12 = compose(v1360_10,v1365_11);
    }
    const Space v1360_13 = unite(v1360_8,v1360_12);
    v1359_12_result = unite(v1359_12_result,v1360_13);
  }
  const Space v1359_12 = std::move(v1359_12_result);
  return v1359_12;
}

static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1369_9_result;
  for (int v1369_9_label = 1; v1369_9_label <= 2; ++v1369_9_label) {
    const Space v1369_9_tail = child(s0,v1369_9_label);
    if (v1369_9_tail.empty()) continue;
    const Path v1369_9_head{v1369_9_label};
    const Space v1370_2 = singleton(v1369_9_head);
    const Space v1370_3 = intersect(constant_3,v1370_2);
    const Space v1370_4 = (has_head(v1370_3) ? constant_4 : Space{});
    const Space v1370_5 = subtract(constant_2,v1370_4);
    Space v1370_8;
    if (!v1370_5.empty()) {
      const Path v1371_6 = concat_path(p0,v1369_9_head);
      Space v1371_7_result;
      for (int v1371_7_label = 1; v1371_7_label <= 2; ++v1371_7_label) {
        const Space v1371_7_tail = child(v1369_9_tail,v1371_7_label);
        if (v1371_7_tail.empty()) continue;
        const Path v1371_7_head{v1371_7_label};
        const Space v1372_2 = singleton(v1371_7_head);
        const Space v1372_3 = intersect(constant_3,v1372_2);
        const Space v1372_4 = (has_head(v1372_3) ? constant_4 : Space{});
        const Space v1372_5 = subtract(constant_2,v1372_4);
        Space v1372_8;
        if (!v1372_5.empty()) {
          const Path v1373_6 = concat_path(v1371_6,v1371_7_head);
          const Space v1373_7 = routine_176(c, v1373_6, p1, v1371_7_tail);
          v1372_8 = compose(v1372_5,v1373_7);
        }
        const Space v1372_9 = intersect(constant_3,v1372_2);
        const Space v1372_10 = (has_head(v1372_9) ? constant_4 : Space{});
        Space v1372_12;
        if (!v1372_10.empty()) {
          const Path v1374_6 = concat_path(v1371_6,v1371_7_head);
          const Space v1374_11 = routine_177(c, v1374_6, p1, v1371_7_tail);
          v1372_12 = compose(v1372_10,v1374_11);
        }
        const Space v1372_13 = unite(v1372_8,v1372_12);
        v1371_7_result = unite(v1371_7_result,v1372_13);
      }
      const Space v1371_7 = std::move(v1371_7_result);
      v1370_8 = compose(v1370_5,v1371_7);
    }
    const Space v1370_9 = intersect(constant_3,v1370_2);
    const Space v1370_10 = (has_head(v1370_9) ? constant_4 : Space{});
    const Space v1370_11 = compose(v1370_10,v1369_9_tail);
    const Path v1375_6 = concat_path(p0,v1369_9_head);
    const Space v1370_12 = wrap(v1370_11,v1375_6);
    const Space v1370_13 = wrap(v1370_12,p1);
    const Space v1370_14 = unite(v1370_8,v1370_13);
    v1369_9_result = unite(v1369_9_result,v1370_14);
  }
  const Space v1369_9 = std::move(v1369_9_result);
  return v1369_9;
}

static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1376_8_result;
  for (int v1376_8_label = 1; v1376_8_label <= 2; ++v1376_8_label) {
    const Space v1376_8_tail = child(s0,v1376_8_label);
    if (v1376_8_tail.empty()) continue;
    const Path v1376_8_head{v1376_8_label};
    const Space v1377_2 = singleton(v1376_8_head);
    const Space v1377_3 = intersect(constant_3,v1377_2);
    const Space v1377_4 = (has_head(v1377_3) ? constant_4 : Space{});
    const Space v1377_5 = subtract(constant_2,v1377_4);
    Space v1377_6_result;
    for (int v1377_6_label = 1; v1377_6_label <= 2; ++v1377_6_label) {
      const Space v1377_6_tail = child(v1376_8_tail,v1377_6_label);
      if (v1377_6_tail.empty()) continue;
      const Path v1377_6_head{v1377_6_label};
      const Space v1378_2 = Space{};
      v1377_6_result = unite(v1377_6_result,v1378_2);
    }
    const Space v1377_6 = std::move(v1377_6_result);
    const Space v1377_7 = compose(v1377_5,v1377_6);
    const Space v1377_8 = intersect(constant_3,v1377_2);
    const Space v1377_9 = (has_head(v1377_8) ? constant_4 : Space{});
    Space v1377_12;
    if (!v1377_9.empty()) {
      const Path v1379_10 = concat_path(p0,v1376_8_head);
      Space v1379_11_result;
      for (int v1379_11_label = 1; v1379_11_label <= 2; ++v1379_11_label) {
        const Space v1379_11_tail = child(v1376_8_tail,v1379_11_label);
        if (v1379_11_tail.empty()) continue;
        const Path v1379_11_head{v1379_11_label};
        const Space v1380_2 = singleton(v1379_11_head);
        const Space v1380_3 = intersect(constant_3,v1380_2);
        const Space v1380_4 = (has_head(v1380_3) ? constant_4 : Space{});
        Space v1380_7;
        if (!v1380_4.empty()) {
          const Path v1381_5 = concat_path(v1379_10,v1379_11_head);
          const Space v1381_6 = routine_50(c, v1381_5, p1, v1379_11_tail, s1);
          v1380_7 = compose(v1380_4,v1381_6);
        }
        v1379_11_result = unite(v1379_11_result,v1380_7);
      }
      const Space v1379_11 = std::move(v1379_11_result);
      v1377_12 = compose(v1377_9,v1379_11);
    }
    const Space v1377_13 = unite(v1377_7,v1377_12);
    v1376_8_result = unite(v1376_8_result,v1377_13);
  }
  const Space v1376_8 = std::move(v1376_8_result);
  return v1376_8;
}

static Space routine_163(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1382_8 = unwrap(s1,constant_5);
  const Space v1382_10 = unwrap(v1382_8,constant_6);
  const Space v1382_11 = unwrap(v1382_10,p0);
  Space v1382_15_result;
  for (int v1382_15_label = 1; v1382_15_label <= 2; ++v1382_15_label) {
    const Space v1382_15_tail = child(s0,v1382_15_label);
    if (v1382_15_tail.empty()) continue;
    const Path v1382_15_head{v1382_15_label};
    const Space v1383_2 = singleton(v1382_15_head);
    const Space v1383_3 = intersect(constant_3,v1383_2);
    const Space v1383_4 = (has_head(v1383_3) ? constant_4 : Space{});
    const Space v1383_5 = subtract(constant_2,v1383_4);
    Space v1383_6_result;
    for (int v1383_6_label = 1; v1383_6_label <= 2; ++v1383_6_label) {
      const Space v1383_6_tail = child(v1382_15_tail,v1383_6_label);
      if (v1383_6_tail.empty()) continue;
      const Path v1383_6_head{v1383_6_label};
      const Space v1384_2 = Space{};
      v1383_6_result = unite(v1383_6_result,v1384_2);
    }
    const Space v1383_6 = std::move(v1383_6_result);
    const Space v1383_7 = compose(v1383_5,v1383_6);
    const Space v1383_8 = intersect(constant_3,v1383_2);
    const Space v1383_9 = (has_head(v1383_8) ? constant_4 : Space{});
    Space v1383_12;
    if (!v1383_9.empty()) {
      const Space v1385_10 = unwrap(v1382_11,v1382_15_head);
      Space v1385_11_result;
      for (int v1385_11_label = 1; v1385_11_label <= 2; ++v1385_11_label) {
        const Space v1385_11_tail = child(v1385_10,v1385_11_label);
        if (v1385_11_tail.empty()) continue;
        const Path v1385_11_head{v1385_11_label};
        const Space v1386_2 = singleton(v1385_11_head);
        const Space v1386_3 = intersect(constant_3,v1386_2);
        const Space v1386_4 = (has_head(v1386_3) ? constant_4 : Space{});
        const Space v1386_5 = subtract(constant_2,v1386_4);
        Space v1386_7;
        if (!v1386_5.empty()) {
          const Space v1387_6 = routine_89(c, v1385_11_head, p1, v1385_11_tail);
          v1386_7 = compose(v1386_5,v1387_6);
        }
        const Space v1386_8 = intersect(constant_3,v1386_2);
        const Space v1386_9 = (has_head(v1386_8) ? constant_4 : Space{});
        Space v1386_11;
        if (!v1386_9.empty()) {
          const Space v1388_10 = routine_90(c, v1385_11_head, p1, v1385_11_tail);
          v1386_11 = compose(v1386_9,v1388_10);
        }
        const Space v1386_12 = unite(v1386_7,v1386_11);
        v1385_11_result = unite(v1385_11_result,v1386_12);
      }
      const Space v1385_11 = std::move(v1385_11_result);
      v1383_12 = compose(v1383_9,v1385_11);
    }
    const Space v1383_13 = unite(v1383_7,v1383_12);
    v1382_15_result = unite(v1382_15_result,v1383_13);
  }
  const Space v1382_15 = std::move(v1382_15_result);
  return v1382_15;
}

static Space routine_164(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1389_12_result;
  for (int v1389_12_label = 1; v1389_12_label <= 2; ++v1389_12_label) {
    const Space v1389_12_tail = child(s0,v1389_12_label);
    if (v1389_12_tail.empty()) continue;
    const Path v1389_12_head{v1389_12_label};
    const Space v1390_2 = singleton(v1389_12_head);
    const Space v1390_3 = intersect(constant_3,v1390_2);
    const Space v1390_4 = (has_head(v1390_3) ? constant_4 : Space{});
    const Space v1390_5 = subtract(constant_2,v1390_4);
    Space v1390_8;
    if (!v1390_5.empty()) {
      const Path v1391_6 = concat_path(p0,v1389_12_head);
      Space v1391_7_result;
      for (int v1391_7_label = 1; v1391_7_label <= 2; ++v1391_7_label) {
        const Space v1391_7_tail = child(v1389_12_tail,v1391_7_label);
        if (v1391_7_tail.empty()) continue;
        const Path v1391_7_head{v1391_7_label};
        const Space v1392_2 = singleton(v1391_7_head);
        const Space v1392_3 = intersect(constant_3,v1392_2);
        const Space v1392_4 = (has_head(v1392_3) ? constant_4 : Space{});
        const Space v1392_5 = subtract(constant_2,v1392_4);
        Space v1392_8;
        if (!v1392_5.empty()) {
          const Path v1393_6 = concat_path(v1391_6,v1391_7_head);
          const Space v1393_7 = routine_178(c, v1393_6, p1, v1391_7_tail);
          v1392_8 = compose(v1392_5,v1393_7);
        }
        const Space v1392_9 = intersect(constant_3,v1392_2);
        const Space v1392_10 = (has_head(v1392_9) ? constant_4 : Space{});
        Space v1392_12;
        if (!v1392_10.empty()) {
          const Path v1394_6 = concat_path(v1391_6,v1391_7_head);
          const Space v1394_11 = routine_179(c, v1394_6, p1, v1391_7_tail);
          v1392_12 = compose(v1392_10,v1394_11);
        }
        const Space v1392_13 = unite(v1392_8,v1392_12);
        v1391_7_result = unite(v1391_7_result,v1392_13);
      }
      const Space v1391_7 = std::move(v1391_7_result);
      v1390_8 = compose(v1390_5,v1391_7);
    }
    const Space v1390_9 = intersect(constant_3,v1390_2);
    const Space v1390_10 = (has_head(v1390_9) ? constant_4 : Space{});
    Space v1390_12;
    if (!v1390_10.empty()) {
      const Path v1395_6 = concat_path(p0,v1389_12_head);
      Space v1395_11_result;
      for (int v1395_11_label = 1; v1395_11_label <= 2; ++v1395_11_label) {
        const Space v1395_11_tail = child(v1389_12_tail,v1395_11_label);
        if (v1395_11_tail.empty()) continue;
        const Path v1395_11_head{v1395_11_label};
        const Space v1396_2 = singleton(v1395_11_head);
        const Space v1396_3 = intersect(constant_3,v1396_2);
        const Space v1396_4 = (has_head(v1396_3) ? constant_4 : Space{});
        const Space v1396_5 = subtract(constant_2,v1396_4);
        Space v1396_8;
        if (!v1396_5.empty()) {
          const Path v1397_6 = concat_path(v1395_6,v1395_11_head);
          const Space v1397_7 = routine_178(c, v1397_6, p1, v1395_11_tail);
          v1396_8 = compose(v1396_5,v1397_7);
        }
        const Space v1396_9 = intersect(constant_3,v1396_2);
        const Space v1396_10 = (has_head(v1396_9) ? constant_4 : Space{});
        Space v1396_12;
        if (!v1396_10.empty()) {
          const Path v1398_6 = concat_path(v1395_6,v1395_11_head);
          const Space v1398_11 = routine_95(c, v1398_6, p1, v1395_11_tail);
          v1396_12 = compose(v1396_10,v1398_11);
        }
        const Space v1396_13 = unite(v1396_8,v1396_12);
        v1395_11_result = unite(v1395_11_result,v1396_13);
      }
      const Space v1395_11 = std::move(v1395_11_result);
      v1390_12 = compose(v1390_10,v1395_11);
    }
    const Space v1390_13 = unite(v1390_8,v1390_12);
    v1389_12_result = unite(v1389_12_result,v1390_13);
  }
  const Space v1389_12 = std::move(v1389_12_result);
  return v1389_12;
}

static Space routine_165(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1399_9_result;
  for (int v1399_9_label = 1; v1399_9_label <= 2; ++v1399_9_label) {
    const Space v1399_9_tail = child(s0,v1399_9_label);
    if (v1399_9_tail.empty()) continue;
    const Path v1399_9_head{v1399_9_label};
    const Space v1400_2 = singleton(v1399_9_head);
    const Space v1400_3 = intersect(constant_3,v1400_2);
    const Space v1400_4 = (has_head(v1400_3) ? constant_4 : Space{});
    const Space v1400_5 = subtract(constant_2,v1400_4);
    Space v1400_8;
    if (!v1400_5.empty()) {
      const Path v1401_6 = concat_path(p0,v1399_9_head);
      Space v1401_7_result;
      for (int v1401_7_label = 1; v1401_7_label <= 2; ++v1401_7_label) {
        const Space v1401_7_tail = child(v1399_9_tail,v1401_7_label);
        if (v1401_7_tail.empty()) continue;
        const Path v1401_7_head{v1401_7_label};
        const Space v1402_2 = singleton(v1401_7_head);
        const Space v1402_3 = intersect(constant_3,v1402_2);
        const Space v1402_4 = (has_head(v1402_3) ? constant_4 : Space{});
        const Space v1402_5 = subtract(constant_2,v1402_4);
        Space v1402_8;
        if (!v1402_5.empty()) {
          const Path v1403_6 = concat_path(v1401_6,v1401_7_head);
          const Space v1403_7 = routine_178(c, v1403_6, p1, v1401_7_tail);
          v1402_8 = compose(v1402_5,v1403_7);
        }
        const Space v1402_9 = intersect(constant_3,v1402_2);
        const Space v1402_10 = (has_head(v1402_9) ? constant_4 : Space{});
        Space v1402_12;
        if (!v1402_10.empty()) {
          const Path v1404_6 = concat_path(v1401_6,v1401_7_head);
          const Space v1404_11 = routine_179(c, v1404_6, p1, v1401_7_tail);
          v1402_12 = compose(v1402_10,v1404_11);
        }
        const Space v1402_13 = unite(v1402_8,v1402_12);
        v1401_7_result = unite(v1401_7_result,v1402_13);
      }
      const Space v1401_7 = std::move(v1401_7_result);
      v1400_8 = compose(v1400_5,v1401_7);
    }
    const Space v1400_9 = intersect(constant_3,v1400_2);
    const Space v1400_10 = (has_head(v1400_9) ? constant_4 : Space{});
    const Space v1400_11 = compose(v1400_10,v1399_9_tail);
    const Path v1405_6 = concat_path(p0,v1399_9_head);
    const Space v1400_12 = wrap(v1400_11,v1405_6);
    const Space v1400_13 = wrap(v1400_12,p1);
    const Space v1400_14 = unite(v1400_8,v1400_13);
    v1399_9_result = unite(v1399_9_result,v1400_14);
  }
  const Space v1399_9 = std::move(v1399_9_result);
  return v1399_9;
}

static Space routine_166(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1406_4_result;
  for (int v1406_4_label = 1; v1406_4_label <= 2; ++v1406_4_label) {
    const Space v1406_4_tail = child(s0,v1406_4_label);
    if (v1406_4_tail.empty()) continue;
    const Path v1406_4_head{v1406_4_label};
    const Space v1407_2 = Space{};
    v1406_4_result = unite(v1406_4_result,v1407_2);
  }
  const Space v1406_4 = std::move(v1406_4_result);
  return v1406_4;
}

static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1408_6 = unwrap(s1,constant_5);
  const Space v1408_8 = unwrap(v1408_6,constant_6);
  const Space v1408_9 = unwrap(v1408_8,p0);
  Space v1408_13_result;
  for (int v1408_13_label = 1; v1408_13_label <= 2; ++v1408_13_label) {
    const Space v1408_13_tail = child(s0,v1408_13_label);
    if (v1408_13_tail.empty()) continue;
    const Path v1408_13_head{v1408_13_label};
    const Space v1409_2 = singleton(v1408_13_head);
    const Space v1409_3 = intersect(constant_3,v1409_2);
    const Space v1409_4 = (has_head(v1409_3) ? constant_4 : Space{});
    Space v1409_7;
    if (!v1409_4.empty()) {
      const Space v1410_5 = unwrap(v1408_9,v1408_13_head);
      Space v1410_6_result;
      for (int v1410_6_label = 1; v1410_6_label <= 2; ++v1410_6_label) {
        const Space v1410_6_tail = child(v1410_5,v1410_6_label);
        if (v1410_6_tail.empty()) continue;
        const Path v1410_6_head{v1410_6_label};
        const Space v1411_2 = singleton(v1410_6_head);
        const Space v1411_3 = intersect(constant_3,v1411_2);
        const Space v1411_4 = (has_head(v1411_3) ? constant_4 : Space{});
        const Space v1411_5 = subtract(constant_2,v1411_4);
        Space v1411_7;
        if (!v1411_5.empty()) {
          const Space v1412_6 = routine_89(c, v1410_6_head, p1, v1410_6_tail);
          v1411_7 = compose(v1411_5,v1412_6);
        }
        const Space v1411_8 = intersect(constant_3,v1411_2);
        const Space v1411_9 = (has_head(v1411_8) ? constant_4 : Space{});
        Space v1411_11;
        if (!v1411_9.empty()) {
          const Space v1413_10 = routine_90(c, v1410_6_head, p1, v1410_6_tail);
          v1411_11 = compose(v1411_9,v1413_10);
        }
        const Space v1411_12 = unite(v1411_7,v1411_11);
        v1410_6_result = unite(v1410_6_result,v1411_12);
      }
      const Space v1410_6 = std::move(v1410_6_result);
      v1409_7 = compose(v1409_4,v1410_6);
    }
    v1408_13_result = unite(v1408_13_result,v1409_7);
  }
  const Space v1408_13 = std::move(v1408_13_result);
  return v1408_13;
}

static Space routine_168(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1414_12_result;
  for (int v1414_12_label = 1; v1414_12_label <= 2; ++v1414_12_label) {
    const Space v1414_12_tail = child(s0,v1414_12_label);
    if (v1414_12_tail.empty()) continue;
    const Path v1414_12_head{v1414_12_label};
    const Space v1415_2 = singleton(v1414_12_head);
    const Space v1415_3 = intersect(constant_3,v1415_2);
    const Space v1415_4 = (has_head(v1415_3) ? constant_4 : Space{});
    const Space v1415_5 = subtract(constant_2,v1415_4);
    Space v1415_8;
    if (!v1415_5.empty()) {
      const Path v1416_6 = concat_path(p0,v1414_12_head);
      Space v1416_7_result;
      for (int v1416_7_label = 1; v1416_7_label <= 2; ++v1416_7_label) {
        const Space v1416_7_tail = child(v1414_12_tail,v1416_7_label);
        if (v1416_7_tail.empty()) continue;
        const Path v1416_7_head{v1416_7_label};
        const Space v1417_2 = singleton(v1416_7_head);
        const Space v1417_3 = intersect(constant_3,v1417_2);
        const Space v1417_4 = (has_head(v1417_3) ? constant_4 : Space{});
        const Space v1417_5 = subtract(constant_2,v1417_4);
        Space v1417_8;
        if (!v1417_5.empty()) {
          const Path v1418_6 = concat_path(v1416_6,v1416_7_head);
          const Space v1418_7 = routine_180(c, v1418_6, p1, v1416_7_tail);
          v1417_8 = compose(v1417_5,v1418_7);
        }
        const Space v1417_9 = intersect(constant_3,v1417_2);
        const Space v1417_10 = (has_head(v1417_9) ? constant_4 : Space{});
        Space v1417_12;
        if (!v1417_10.empty()) {
          const Path v1419_6 = concat_path(v1416_6,v1416_7_head);
          const Space v1419_11 = routine_181(c, v1419_6, p1, v1416_7_tail);
          v1417_12 = compose(v1417_10,v1419_11);
        }
        const Space v1417_13 = unite(v1417_8,v1417_12);
        v1416_7_result = unite(v1416_7_result,v1417_13);
      }
      const Space v1416_7 = std::move(v1416_7_result);
      v1415_8 = compose(v1415_5,v1416_7);
    }
    const Space v1415_9 = intersect(constant_3,v1415_2);
    const Space v1415_10 = (has_head(v1415_9) ? constant_4 : Space{});
    Space v1415_12;
    if (!v1415_10.empty()) {
      const Path v1420_6 = concat_path(p0,v1414_12_head);
      Space v1420_11_result;
      for (int v1420_11_label = 1; v1420_11_label <= 2; ++v1420_11_label) {
        const Space v1420_11_tail = child(v1414_12_tail,v1420_11_label);
        if (v1420_11_tail.empty()) continue;
        const Path v1420_11_head{v1420_11_label};
        const Space v1421_2 = singleton(v1420_11_head);
        const Space v1421_3 = intersect(constant_3,v1421_2);
        const Space v1421_4 = (has_head(v1421_3) ? constant_4 : Space{});
        const Space v1421_5 = subtract(constant_2,v1421_4);
        Space v1421_8;
        if (!v1421_5.empty()) {
          const Path v1422_6 = concat_path(v1420_6,v1420_11_head);
          const Space v1422_7 = routine_180(c, v1422_6, p1, v1420_11_tail);
          v1421_8 = compose(v1421_5,v1422_7);
        }
        const Space v1421_9 = intersect(constant_3,v1421_2);
        const Space v1421_10 = (has_head(v1421_9) ? constant_4 : Space{});
        Space v1421_12;
        if (!v1421_10.empty()) {
          const Path v1423_6 = concat_path(v1420_6,v1420_11_head);
          const Space v1423_11 = routine_95(c, v1423_6, p1, v1420_11_tail);
          v1421_12 = compose(v1421_10,v1423_11);
        }
        const Space v1421_13 = unite(v1421_8,v1421_12);
        v1420_11_result = unite(v1420_11_result,v1421_13);
      }
      const Space v1420_11 = std::move(v1420_11_result);
      v1415_12 = compose(v1415_10,v1420_11);
    }
    const Space v1415_13 = unite(v1415_8,v1415_12);
    v1414_12_result = unite(v1414_12_result,v1415_13);
  }
  const Space v1414_12 = std::move(v1414_12_result);
  return v1414_12;
}

static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1424_9_result;
  for (int v1424_9_label = 1; v1424_9_label <= 2; ++v1424_9_label) {
    const Space v1424_9_tail = child(s0,v1424_9_label);
    if (v1424_9_tail.empty()) continue;
    const Path v1424_9_head{v1424_9_label};
    const Space v1425_2 = singleton(v1424_9_head);
    const Space v1425_3 = intersect(constant_3,v1425_2);
    const Space v1425_4 = (has_head(v1425_3) ? constant_4 : Space{});
    const Space v1425_5 = subtract(constant_2,v1425_4);
    Space v1425_8;
    if (!v1425_5.empty()) {
      const Path v1426_6 = concat_path(p0,v1424_9_head);
      Space v1426_7_result;
      for (int v1426_7_label = 1; v1426_7_label <= 2; ++v1426_7_label) {
        const Space v1426_7_tail = child(v1424_9_tail,v1426_7_label);
        if (v1426_7_tail.empty()) continue;
        const Path v1426_7_head{v1426_7_label};
        const Space v1427_2 = singleton(v1426_7_head);
        const Space v1427_3 = intersect(constant_3,v1427_2);
        const Space v1427_4 = (has_head(v1427_3) ? constant_4 : Space{});
        const Space v1427_5 = subtract(constant_2,v1427_4);
        Space v1427_8;
        if (!v1427_5.empty()) {
          const Path v1428_6 = concat_path(v1426_6,v1426_7_head);
          const Space v1428_7 = routine_180(c, v1428_6, p1, v1426_7_tail);
          v1427_8 = compose(v1427_5,v1428_7);
        }
        const Space v1427_9 = intersect(constant_3,v1427_2);
        const Space v1427_10 = (has_head(v1427_9) ? constant_4 : Space{});
        Space v1427_12;
        if (!v1427_10.empty()) {
          const Path v1429_6 = concat_path(v1426_6,v1426_7_head);
          const Space v1429_11 = routine_181(c, v1429_6, p1, v1426_7_tail);
          v1427_12 = compose(v1427_10,v1429_11);
        }
        const Space v1427_13 = unite(v1427_8,v1427_12);
        v1426_7_result = unite(v1426_7_result,v1427_13);
      }
      const Space v1426_7 = std::move(v1426_7_result);
      v1425_8 = compose(v1425_5,v1426_7);
    }
    const Space v1425_9 = intersect(constant_3,v1425_2);
    const Space v1425_10 = (has_head(v1425_9) ? constant_4 : Space{});
    const Space v1425_11 = compose(v1425_10,v1424_9_tail);
    const Path v1430_6 = concat_path(p0,v1424_9_head);
    const Space v1425_12 = wrap(v1425_11,v1430_6);
    const Space v1425_13 = wrap(v1425_12,p1);
    const Space v1425_14 = unite(v1425_8,v1425_13);
    v1424_9_result = unite(v1424_9_result,v1425_14);
  }
  const Space v1424_9 = std::move(v1424_9_result);
  return v1424_9;
}

static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1431_7_result;
  for (int v1431_7_label = 1; v1431_7_label <= 2; ++v1431_7_label) {
    const Space v1431_7_tail = child(s0,v1431_7_label);
    if (v1431_7_tail.empty()) continue;
    const Path v1431_7_head{v1431_7_label};
    const Space v1432_2 = singleton(v1431_7_head);
    const Space v1432_3 = intersect(constant_3,v1432_2);
    const Space v1432_4 = (has_head(v1432_3) ? constant_4 : Space{});
    const Space v1432_5 = subtract(constant_2,v1432_4);
    Space v1432_6_result;
    for (int v1432_6_label = 1; v1432_6_label <= 2; ++v1432_6_label) {
      const Space v1432_6_tail = child(v1431_7_tail,v1432_6_label);
      if (v1432_6_tail.empty()) continue;
      const Path v1432_6_head{v1432_6_label};
      const Space v1433_2 = Space{};
      v1432_6_result = unite(v1432_6_result,v1433_2);
    }
    const Space v1432_6 = std::move(v1432_6_result);
    const Space v1432_7 = compose(v1432_5,v1432_6);
    const Space v1432_8 = intersect(constant_3,v1432_2);
    const Space v1432_9 = (has_head(v1432_8) ? constant_4 : Space{});
    Space v1432_12;
    if (!v1432_9.empty()) {
      const Path v1434_10 = concat_path(p0,v1431_7_head);
      Space v1434_11_result;
      for (int v1434_11_label = 1; v1434_11_label <= 2; ++v1434_11_label) {
        const Space v1434_11_tail = child(v1431_7_tail,v1434_11_label);
        if (v1434_11_tail.empty()) continue;
        const Path v1434_11_head{v1434_11_label};
        const Space v1435_2 = singleton(v1434_11_head);
        const Space v1435_3 = intersect(constant_3,v1435_2);
        const Space v1435_4 = (has_head(v1435_3) ? constant_4 : Space{});
        Space v1435_7;
        if (!v1435_4.empty()) {
          const Path v1436_5 = concat_path(v1434_10,v1434_11_head);
          const Space v1436_6 = routine_67(c, v1436_5, p1, v1434_11_tail);
          v1435_7 = compose(v1435_4,v1436_6);
        }
        v1434_11_result = unite(v1434_11_result,v1435_7);
      }
      const Space v1434_11 = std::move(v1434_11_result);
      v1432_12 = compose(v1432_9,v1434_11);
    }
    const Space v1432_13 = unite(v1432_7,v1432_12);
    v1431_7_result = unite(v1431_7_result,v1432_13);
  }
  const Space v1431_7 = std::move(v1431_7_result);
  return v1431_7;
}

static Space routine_171(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1437_6_result;
  for (int v1437_6_label = 1; v1437_6_label <= 2; ++v1437_6_label) {
    const Space v1437_6_tail = child(s0,v1437_6_label);
    if (v1437_6_tail.empty()) continue;
    const Path v1437_6_head{v1437_6_label};
    const Space v1438_2 = singleton(v1437_6_head);
    const Space v1438_3 = intersect(constant_3,v1438_2);
    const Space v1438_4 = (has_head(v1438_3) ? constant_4 : Space{});
    const Space v1438_5 = subtract(constant_2,v1438_4);
    Space v1438_6_result;
    for (int v1438_6_label = 1; v1438_6_label <= 2; ++v1438_6_label) {
      const Space v1438_6_tail = child(v1437_6_tail,v1438_6_label);
      if (v1438_6_tail.empty()) continue;
      const Path v1438_6_head{v1438_6_label};
      const Space v1439_2 = Space{};
      v1438_6_result = unite(v1438_6_result,v1439_2);
    }
    const Space v1438_6 = std::move(v1438_6_result);
    const Space v1438_7 = compose(v1438_5,v1438_6);
    const Space v1438_8 = intersect(constant_3,v1438_2);
    const Space v1438_9 = (has_head(v1438_8) ? constant_4 : Space{});
    const Space v1438_10 = compose(v1438_9,v1437_6_tail);
    const Path v1438_11 = concat_path(p0,v1437_6_head);
    const Space v1438_12 = wrap(v1438_10,v1438_11);
    const Space v1438_13 = wrap(v1438_12,p1);
    const Space v1438_14 = unite(v1438_7,v1438_13);
    v1437_6_result = unite(v1437_6_result,v1438_14);
  }
  const Space v1437_6 = std::move(v1437_6_result);
  return v1437_6;
}

static Space routine_172(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1440_3_result;
  for (int v1440_3_label = 1; v1440_3_label <= 2; ++v1440_3_label) {
    const Space v1440_3_tail = child(s0,v1440_3_label);
    if (v1440_3_tail.empty()) continue;
    const Path v1440_3_head{v1440_3_label};
    const Space v1441_2 = Space{};
    v1440_3_result = unite(v1440_3_result,v1441_2);
  }
  const Space v1440_3 = std::move(v1440_3_result);
  return v1440_3;
}

static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1442_4_result;
  for (int v1442_4_label = 1; v1442_4_label <= 2; ++v1442_4_label) {
    const Space v1442_4_tail = child(s0,v1442_4_label);
    if (v1442_4_tail.empty()) continue;
    const Path v1442_4_head{v1442_4_label};
    const Space v1443_2 = singleton(v1442_4_head);
    const Space v1443_3 = intersect(constant_3,v1443_2);
    const Space v1443_4 = (has_head(v1443_3) ? constant_4 : Space{});
    const Space v1443_5 = compose(v1443_4,v1442_4_tail);
    const Path v1443_6 = concat_path(p0,v1442_4_head);
    const Space v1443_7 = wrap(v1443_5,v1443_6);
    v1442_4_result = unite(v1442_4_result,v1443_7);
  }
  const Space v1442_4 = std::move(v1442_4_result);
  const Space v1442_5 = wrap(v1442_4,p1);
  return v1442_5;
}

static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1444_7_result;
  for (int v1444_7_label = 1; v1444_7_label <= 2; ++v1444_7_label) {
    const Space v1444_7_tail = child(s0,v1444_7_label);
    if (v1444_7_tail.empty()) continue;
    const Path v1444_7_head{v1444_7_label};
    const Space v1445_2 = singleton(v1444_7_head);
    const Space v1445_3 = intersect(constant_3,v1445_2);
    const Space v1445_4 = (has_head(v1445_3) ? constant_4 : Space{});
    const Space v1445_5 = subtract(constant_2,v1445_4);
    Space v1445_6_result;
    for (int v1445_6_label = 1; v1445_6_label <= 2; ++v1445_6_label) {
      const Space v1445_6_tail = child(v1444_7_tail,v1445_6_label);
      if (v1445_6_tail.empty()) continue;
      const Path v1445_6_head{v1445_6_label};
      const Space v1446_2 = Space{};
      v1445_6_result = unite(v1445_6_result,v1446_2);
    }
    const Space v1445_6 = std::move(v1445_6_result);
    const Space v1445_7 = compose(v1445_5,v1445_6);
    const Space v1445_8 = intersect(constant_3,v1445_2);
    const Space v1445_9 = (has_head(v1445_8) ? constant_4 : Space{});
    Space v1445_12;
    if (!v1445_9.empty()) {
      const Path v1447_10 = concat_path(p0,v1444_7_head);
      Space v1447_11_result;
      for (int v1447_11_label = 1; v1447_11_label <= 2; ++v1447_11_label) {
        const Space v1447_11_tail = child(v1444_7_tail,v1447_11_label);
        if (v1447_11_tail.empty()) continue;
        const Path v1447_11_head{v1447_11_label};
        const Space v1448_2 = singleton(v1447_11_head);
        const Space v1448_3 = intersect(constant_3,v1448_2);
        const Space v1448_4 = (has_head(v1448_3) ? constant_4 : Space{});
        Space v1448_7;
        if (!v1448_4.empty()) {
          const Path v1449_5 = concat_path(v1447_10,v1447_11_head);
          const Space v1449_6 = routine_84(c, v1449_5, p1, v1447_11_tail);
          v1448_7 = compose(v1448_4,v1449_6);
        }
        v1447_11_result = unite(v1447_11_result,v1448_7);
      }
      const Space v1447_11 = std::move(v1447_11_result);
      v1445_12 = compose(v1445_9,v1447_11);
    }
    const Space v1445_13 = unite(v1445_7,v1445_12);
    v1444_7_result = unite(v1444_7_result,v1445_13);
  }
  const Space v1444_7 = std::move(v1444_7_result);
  return v1444_7;
}

static Space routine_175(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1450_6_result;
  for (int v1450_6_label = 1; v1450_6_label <= 2; ++v1450_6_label) {
    const Space v1450_6_tail = child(s0,v1450_6_label);
    if (v1450_6_tail.empty()) continue;
    const Path v1450_6_head{v1450_6_label};
    const Space v1451_2 = singleton(v1450_6_head);
    const Space v1451_3 = intersect(constant_3,v1451_2);
    const Space v1451_4 = (has_head(v1451_3) ? constant_4 : Space{});
    const Space v1451_5 = subtract(constant_2,v1451_4);
    Space v1451_6_result;
    for (int v1451_6_label = 1; v1451_6_label <= 2; ++v1451_6_label) {
      const Space v1451_6_tail = child(v1450_6_tail,v1451_6_label);
      if (v1451_6_tail.empty()) continue;
      const Path v1451_6_head{v1451_6_label};
      const Space v1452_2 = Space{};
      v1451_6_result = unite(v1451_6_result,v1452_2);
    }
    const Space v1451_6 = std::move(v1451_6_result);
    const Space v1451_7 = compose(v1451_5,v1451_6);
    const Space v1451_8 = intersect(constant_3,v1451_2);
    const Space v1451_9 = (has_head(v1451_8) ? constant_4 : Space{});
    const Space v1451_10 = compose(v1451_9,v1450_6_tail);
    const Path v1451_11 = concat_path(p0,v1450_6_head);
    const Space v1451_12 = wrap(v1451_10,v1451_11);
    const Space v1451_13 = wrap(v1451_12,p1);
    const Space v1451_14 = unite(v1451_7,v1451_13);
    v1450_6_result = unite(v1450_6_result,v1451_14);
  }
  const Space v1450_6 = std::move(v1450_6_result);
  return v1450_6;
}

static Space routine_176(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1453_3_result;
  for (int v1453_3_label = 1; v1453_3_label <= 2; ++v1453_3_label) {
    const Space v1453_3_tail = child(s0,v1453_3_label);
    if (v1453_3_tail.empty()) continue;
    const Path v1453_3_head{v1453_3_label};
    const Space v1454_2 = Space{};
    v1453_3_result = unite(v1453_3_result,v1454_2);
  }
  const Space v1453_3 = std::move(v1453_3_result);
  return v1453_3;
}

static Space routine_177(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1455_4_result;
  for (int v1455_4_label = 1; v1455_4_label <= 2; ++v1455_4_label) {
    const Space v1455_4_tail = child(s0,v1455_4_label);
    if (v1455_4_tail.empty()) continue;
    const Path v1455_4_head{v1455_4_label};
    const Space v1456_2 = singleton(v1455_4_head);
    const Space v1456_3 = intersect(constant_3,v1456_2);
    const Space v1456_4 = (has_head(v1456_3) ? constant_4 : Space{});
    const Space v1456_5 = compose(v1456_4,v1455_4_tail);
    const Path v1456_6 = concat_path(p0,v1455_4_head);
    const Space v1456_7 = wrap(v1456_5,v1456_6);
    v1455_4_result = unite(v1455_4_result,v1456_7);
  }
  const Space v1455_4 = std::move(v1455_4_result);
  const Space v1455_5 = wrap(v1455_4,p1);
  return v1455_5;
}

static Space routine_178(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1457_7_result;
  for (int v1457_7_label = 1; v1457_7_label <= 2; ++v1457_7_label) {
    const Space v1457_7_tail = child(s0,v1457_7_label);
    if (v1457_7_tail.empty()) continue;
    const Path v1457_7_head{v1457_7_label};
    const Space v1458_2 = singleton(v1457_7_head);
    const Space v1458_3 = intersect(constant_3,v1458_2);
    const Space v1458_4 = (has_head(v1458_3) ? constant_4 : Space{});
    const Space v1458_5 = subtract(constant_2,v1458_4);
    Space v1458_6_result;
    for (int v1458_6_label = 1; v1458_6_label <= 2; ++v1458_6_label) {
      const Space v1458_6_tail = child(v1457_7_tail,v1458_6_label);
      if (v1458_6_tail.empty()) continue;
      const Path v1458_6_head{v1458_6_label};
      const Space v1459_2 = Space{};
      v1458_6_result = unite(v1458_6_result,v1459_2);
    }
    const Space v1458_6 = std::move(v1458_6_result);
    const Space v1458_7 = compose(v1458_5,v1458_6);
    const Space v1458_8 = intersect(constant_3,v1458_2);
    const Space v1458_9 = (has_head(v1458_8) ? constant_4 : Space{});
    Space v1458_12;
    if (!v1458_9.empty()) {
      const Path v1460_10 = concat_path(p0,v1457_7_head);
      Space v1460_11_result;
      for (int v1460_11_label = 1; v1460_11_label <= 2; ++v1460_11_label) {
        const Space v1460_11_tail = child(v1457_7_tail,v1460_11_label);
        if (v1460_11_tail.empty()) continue;
        const Path v1460_11_head{v1460_11_label};
        const Space v1461_2 = singleton(v1460_11_head);
        const Space v1461_3 = intersect(constant_3,v1461_2);
        const Space v1461_4 = (has_head(v1461_3) ? constant_4 : Space{});
        Space v1461_7;
        if (!v1461_4.empty()) {
          const Path v1462_5 = concat_path(v1460_10,v1460_11_head);
          const Space v1462_6 = routine_95(c, v1462_5, p1, v1460_11_tail);
          v1461_7 = compose(v1461_4,v1462_6);
        }
        v1460_11_result = unite(v1460_11_result,v1461_7);
      }
      const Space v1460_11 = std::move(v1460_11_result);
      v1458_12 = compose(v1458_9,v1460_11);
    }
    const Space v1458_13 = unite(v1458_7,v1458_12);
    v1457_7_result = unite(v1457_7_result,v1458_13);
  }
  const Space v1457_7 = std::move(v1457_7_result);
  return v1457_7;
}

static Space routine_179(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1463_6_result;
  for (int v1463_6_label = 1; v1463_6_label <= 2; ++v1463_6_label) {
    const Space v1463_6_tail = child(s0,v1463_6_label);
    if (v1463_6_tail.empty()) continue;
    const Path v1463_6_head{v1463_6_label};
    const Space v1464_2 = singleton(v1463_6_head);
    const Space v1464_3 = intersect(constant_3,v1464_2);
    const Space v1464_4 = (has_head(v1464_3) ? constant_4 : Space{});
    const Space v1464_5 = subtract(constant_2,v1464_4);
    Space v1464_6_result;
    for (int v1464_6_label = 1; v1464_6_label <= 2; ++v1464_6_label) {
      const Space v1464_6_tail = child(v1463_6_tail,v1464_6_label);
      if (v1464_6_tail.empty()) continue;
      const Path v1464_6_head{v1464_6_label};
      const Space v1465_2 = Space{};
      v1464_6_result = unite(v1464_6_result,v1465_2);
    }
    const Space v1464_6 = std::move(v1464_6_result);
    const Space v1464_7 = compose(v1464_5,v1464_6);
    const Space v1464_8 = intersect(constant_3,v1464_2);
    const Space v1464_9 = (has_head(v1464_8) ? constant_4 : Space{});
    const Space v1464_10 = compose(v1464_9,v1463_6_tail);
    const Path v1464_11 = concat_path(p0,v1463_6_head);
    const Space v1464_12 = wrap(v1464_10,v1464_11);
    const Space v1464_13 = wrap(v1464_12,p1);
    const Space v1464_14 = unite(v1464_7,v1464_13);
    v1463_6_result = unite(v1463_6_result,v1464_14);
  }
  const Space v1463_6 = std::move(v1463_6_result);
  return v1463_6;
}

static Space routine_180(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1466_3_result;
  for (int v1466_3_label = 1; v1466_3_label <= 2; ++v1466_3_label) {
    const Space v1466_3_tail = child(s0,v1466_3_label);
    if (v1466_3_tail.empty()) continue;
    const Path v1466_3_head{v1466_3_label};
    const Space v1467_2 = Space{};
    v1466_3_result = unite(v1466_3_result,v1467_2);
  }
  const Space v1466_3 = std::move(v1466_3_result);
  return v1466_3;
}

static Space routine_181(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1468_4_result;
  for (int v1468_4_label = 1; v1468_4_label <= 2; ++v1468_4_label) {
    const Space v1468_4_tail = child(s0,v1468_4_label);
    if (v1468_4_tail.empty()) continue;
    const Path v1468_4_head{v1468_4_label};
    const Space v1469_2 = singleton(v1468_4_head);
    const Space v1469_3 = intersect(constant_3,v1469_2);
    const Space v1469_4 = (has_head(v1469_3) ? constant_4 : Space{});
    const Space v1469_5 = compose(v1469_4,v1468_4_tail);
    const Path v1469_6 = concat_path(p0,v1468_4_head);
    const Space v1469_7 = wrap(v1469_5,v1469_6);
    v1468_4_result = unite(v1468_4_result,v1469_7);
  }
  const Space v1468_4 = std::move(v1468_4_result);
  const Space v1468_5 = wrap(v1468_4,p1);
  return v1468_5;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
