#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{2,2};
static const Space constant_1 = literal_text("1 0 ");
static const Space constant_2 = literal_text("1 1 2");
static const Space constant_3 = singleton(Path{});
static const Path constant_4 = Path{1,1,1,1,2,1,2,1,2,2};
static const Path constant_5 = Path{2,1,1,1,2,1,2,1,2,2};
static const Path constant_6 = Path{1,2,1,2,1,1,2,1,2,2};
static const Path constant_7 = Path{1,1,1,1,2,1,2,1,2,2,1,2,1,2,1,1,2,1,2,2};
static const Path constant_8 = Path{2,1,1,1,2,1,2,1,2,2,1,2,1,2,1,1,2,1,2,2};
static Space routine_0(Context& c, const Space* s0);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_83(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_72(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_84(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_73(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_7(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_87(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_65(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_88(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_66(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_116(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_70(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_82(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_117(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_71(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_30(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_44(Context& c, const Path& p0, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_85(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_110(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_120(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_74(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_31(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_45(Context& c, const Path& p0, const Space& s0);
static Space routine_56(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_86(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_38(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_111(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_64(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_24(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_121(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_75(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_98(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_160(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_144(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_104(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_152(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_99(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_145(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_105(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_68(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_100(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_90(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Space& s0);
static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_164(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_128(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_79(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_57(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_156(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_69(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_101(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_91(Context& c, const Path& p0, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Space& s0);
static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_165(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_129(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_80(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_157(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_166(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_186(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_158(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_142(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_180(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_151(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_187(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_159(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_175(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_143(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_181(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_112(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_140(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_132(Context& c, const Path& p0, const Space& s0);
static Space routine_96(Context& c, const Path& p0, const Space& s0);
static Space routine_168(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_188(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_122(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_176(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_102(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_182(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_113(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_141(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_133(Context& c, const Path& p0, const Space& s0);
static Space routine_97(Context& c, const Path& p0, const Space& s0);
static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_189(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_163(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_123(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_177(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_103(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_183(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_178(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_190(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_196(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_184(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_192(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_172(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_194(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_179(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_171(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_191(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_197(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_185(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_193(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_195(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_15(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_89(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_67(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_78(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_0(Context& c, const Space* s0) {
  const Space v0_2 = unwrap(bound_space(s0),constant_0);
  Space v0_12_result;
  for (int v0_12_label = 1; v0_12_label <= 2; ++v0_12_label) {
    const Space v0_12_tail = child(v0_2,v0_12_label);
    if (v0_12_tail.empty()) continue;
    const Path v0_12_head{v0_12_label};
    const Space v1_2 = singleton(v0_12_head);
    const Space v1_3 = intersect(constant_2,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_3 : Space{});
    const Space v1_5 = subtract(constant_1,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      Space v2_6_result;
      for (int v2_6_label = 1; v2_6_label <= 2; ++v2_6_label) {
        const Space v2_6_tail = child(v0_12_tail,v2_6_label);
        if (v2_6_tail.empty()) continue;
        const Path v2_6_head{v2_6_label};
        const Space v3_2 = singleton(v2_6_head);
        const Space v3_3 = intersect(constant_2,v3_2);
        const Space v3_4 = (has_head(v3_3) ? constant_3 : Space{});
        const Space v3_5 = subtract(constant_1,v3_4);
        Space v3_8;
        if (!v3_5.empty()) {
          const Path v4_6 = concat_path(v0_12_head,v2_6_head);
          const Space v4_7 = routine_1(c, v4_6, v2_6_tail);
          v3_8 = compose(v3_5,v4_7);
        }
        const Space v3_9 = intersect(constant_2,v3_2);
        const Space v3_10 = (has_head(v3_9) ? constant_3 : Space{});
        Space v3_12;
        if (!v3_10.empty()) {
          const Path v5_6 = concat_path(v0_12_head,v2_6_head);
          const Space v5_11 = routine_2(c, v5_6, v2_6_tail);
          v3_12 = compose(v3_10,v5_11);
        }
        const Space v3_13 = unite(v3_8,v3_12);
        v2_6_result = unite(v2_6_result,v3_13);
      }
      const Space v2_6 = std::move(v2_6_result);
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_2,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_3 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      Space v6_10_result;
      for (int v6_10_label = 1; v6_10_label <= 2; ++v6_10_label) {
        const Space v6_10_tail = child(v0_12_tail,v6_10_label);
        if (v6_10_tail.empty()) continue;
        const Path v6_10_head{v6_10_label};
        const Space v7_2 = singleton(v6_10_head);
        const Space v7_3 = intersect(constant_2,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_3 : Space{});
        const Space v7_5 = subtract(constant_1,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v0_12_head,v6_10_head);
          const Space v8_7 = routine_1(c, v8_6, v6_10_tail);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_2,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_3 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v0_12_head,v6_10_head);
          const Space v9_11 = routine_3(c, v9_6, v6_10_tail);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_10_result = unite(v6_10_result,v7_13);
      }
      const Space v6_10 = std::move(v6_10_result);
      v1_11 = compose(v1_9,v6_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_12_result = unite(v0_12_result,v1_12);
  }
  const Space v0_12 = std::move(v0_12_result);
  const Space v0_14 = wrap(v0_12,constant_4);
  const Space v0_16 = wrap(bound_space(s0),constant_5);
  const Space v0_17 = unite(v0_14,v0_16);
  Space v0_57 = v0_17;
  for (;;) {
    const Space v10_1 = unwrap(v0_57,constant_4);
    const Space v10_2 = unwrap(v10_1,constant_6);
    Space v10_3_result;
    for (int v10_3_label = 1; v10_3_label <= 2; ++v10_3_label) {
      const Space v10_3_tail = child(v10_2,v10_3_label);
      if (v10_3_tail.empty()) continue;
      const Path v10_3_head{v10_3_label};
      const Space v11_2 = singleton(v10_3_head);
      const Space v11_3 = intersect(constant_2,v11_2);
      const Space v11_4 = (has_head(v11_3) ? constant_3 : Space{});
      const Space v11_5 = subtract(constant_1,v11_4);
      Space v11_7;
      if (!v11_5.empty()) {
        Space v12_6_result;
        for (int v12_6_label = 1; v12_6_label <= 2; ++v12_6_label) {
          const Space v12_6_tail = child(v10_3_tail,v12_6_label);
          if (v12_6_tail.empty()) continue;
          const Path v12_6_head{v12_6_label};
          const Space v13_2 = singleton(v12_6_head);
          const Space v13_3 = intersect(constant_2,v13_2);
          const Space v13_4 = (has_head(v13_3) ? constant_3 : Space{});
          const Space v13_5 = subtract(constant_1,v13_4);
          Space v13_8;
          if (!v13_5.empty()) {
            const Path v14_6 = concat_path(v10_3_head,v12_6_head);
            const Space v14_7 = routine_4(c, v14_6, v12_6_tail, v0_57);
            v13_8 = compose(v13_5,v14_7);
          }
          const Space v13_9 = intersect(constant_2,v13_2);
          const Space v13_10 = (has_head(v13_9) ? constant_3 : Space{});
          Space v13_12;
          if (!v13_10.empty()) {
            const Path v15_6 = concat_path(v10_3_head,v12_6_head);
            const Space v15_11 = routine_5(c, v15_6, v12_6_tail, v0_57);
            v13_12 = compose(v13_10,v15_11);
          }
          const Space v13_13 = unite(v13_8,v13_12);
          v12_6_result = unite(v12_6_result,v13_13);
        }
        const Space v12_6 = std::move(v12_6_result);
        v11_7 = compose(v11_5,v12_6);
      }
      const Space v11_8 = intersect(constant_2,v11_2);
      const Space v11_9 = (has_head(v11_8) ? constant_3 : Space{});
      Space v11_11;
      if (!v11_9.empty()) {
        Space v16_10_result;
        for (int v16_10_label = 1; v16_10_label <= 2; ++v16_10_label) {
          const Space v16_10_tail = child(v10_3_tail,v16_10_label);
          if (v16_10_tail.empty()) continue;
          const Path v16_10_head{v16_10_label};
          const Space v17_2 = singleton(v16_10_head);
          const Space v17_3 = intersect(constant_2,v17_2);
          const Space v17_4 = (has_head(v17_3) ? constant_3 : Space{});
          const Space v17_5 = subtract(constant_1,v17_4);
          Space v17_8;
          if (!v17_5.empty()) {
            const Path v18_6 = concat_path(v10_3_head,v16_10_head);
            const Space v18_7 = routine_4(c, v18_6, v16_10_tail, v0_57);
            v17_8 = compose(v17_5,v18_7);
          }
          const Space v17_9 = intersect(constant_2,v17_2);
          const Space v17_10 = (has_head(v17_9) ? constant_3 : Space{});
          Space v17_12;
          if (!v17_10.empty()) {
            const Path v19_6 = concat_path(v10_3_head,v16_10_head);
            const Space v19_11 = routine_6(c, v19_6, v16_10_tail, v0_57);
            v17_12 = compose(v17_10,v19_11);
          }
          const Space v17_13 = unite(v17_8,v17_12);
          v16_10_result = unite(v16_10_result,v17_13);
        }
        const Space v16_10 = std::move(v16_10_result);
        v11_11 = compose(v11_9,v16_10);
      }
      const Space v11_12 = unite(v11_7,v11_11);
      v10_3_result = unite(v10_3_result,v11_12);
    }
    const Space v10_3 = std::move(v10_3_result);
    Space v10_4_result;
    for (int v10_4_label = 1; v10_4_label <= 2; ++v10_4_label) {
      const Space v10_4_tail = child(v10_2,v10_4_label);
      if (v10_4_tail.empty()) continue;
      const Path v10_4_head{v10_4_label};
      const Space v20_2 = singleton(v10_4_head);
      const Space v20_3 = intersect(constant_2,v20_2);
      const Space v20_4 = (has_head(v20_3) ? constant_3 : Space{});
      const Space v20_5 = subtract(constant_1,v20_4);
      Space v20_7;
      if (!v20_5.empty()) {
        Space v21_6_result;
        for (int v21_6_label = 1; v21_6_label <= 2; ++v21_6_label) {
          const Space v21_6_tail = child(v10_4_tail,v21_6_label);
          if (v21_6_tail.empty()) continue;
          const Path v21_6_head{v21_6_label};
          const Space v22_2 = singleton(v21_6_head);
          const Space v22_3 = intersect(constant_2,v22_2);
          const Space v22_4 = (has_head(v22_3) ? constant_3 : Space{});
          const Space v22_5 = subtract(constant_1,v22_4);
          Space v22_8;
          if (!v22_5.empty()) {
            const Path v23_6 = concat_path(v10_4_head,v21_6_head);
            const Space v23_7 = routine_7(c, v23_6, v21_6_tail, v0_57);
            v22_8 = compose(v22_5,v23_7);
          }
          const Space v22_9 = intersect(constant_2,v22_2);
          const Space v22_10 = (has_head(v22_9) ? constant_3 : Space{});
          Space v22_12;
          if (!v22_10.empty()) {
            const Path v24_6 = concat_path(v10_4_head,v21_6_head);
            const Space v24_11 = routine_8(c, v24_6, v21_6_tail, v0_57);
            v22_12 = compose(v22_10,v24_11);
          }
          const Space v22_13 = unite(v22_8,v22_12);
          v21_6_result = unite(v21_6_result,v22_13);
        }
        const Space v21_6 = std::move(v21_6_result);
        v20_7 = compose(v20_5,v21_6);
      }
      const Space v20_8 = intersect(constant_2,v20_2);
      const Space v20_9 = (has_head(v20_8) ? constant_3 : Space{});
      Space v20_11;
      if (!v20_9.empty()) {
        Space v25_10_result;
        for (int v25_10_label = 1; v25_10_label <= 2; ++v25_10_label) {
          const Space v25_10_tail = child(v10_4_tail,v25_10_label);
          if (v25_10_tail.empty()) continue;
          const Path v25_10_head{v25_10_label};
          const Space v26_2 = singleton(v25_10_head);
          const Space v26_3 = intersect(constant_2,v26_2);
          const Space v26_4 = (has_head(v26_3) ? constant_3 : Space{});
          const Space v26_5 = subtract(constant_1,v26_4);
          Space v26_8;
          if (!v26_5.empty()) {
            const Path v27_6 = concat_path(v10_4_head,v25_10_head);
            const Space v27_7 = routine_7(c, v27_6, v25_10_tail, v0_57);
            v26_8 = compose(v26_5,v27_7);
          }
          const Space v26_9 = intersect(constant_2,v26_2);
          const Space v26_10 = (has_head(v26_9) ? constant_3 : Space{});
          Space v26_12;
          if (!v26_10.empty()) {
            const Path v28_6 = concat_path(v10_4_head,v25_10_head);
            const Space v28_11 = routine_9(c, v28_6, v25_10_tail, v0_57);
            v26_12 = compose(v26_10,v28_11);
          }
          const Space v26_13 = unite(v26_8,v26_12);
          v25_10_result = unite(v25_10_result,v26_13);
        }
        const Space v25_10 = std::move(v25_10_result);
        v20_11 = compose(v20_9,v25_10);
      }
      const Space v20_12 = unite(v20_7,v20_11);
      v10_4_result = unite(v10_4_result,v20_12);
    }
    const Space v10_4 = std::move(v10_4_result);
    const Space v10_5 = unite(v10_3,v10_4);
    const Space v10_6 = unwrap(v0_57,constant_5);
    const Space v10_7 = unwrap(v10_6,constant_6);
    Space v10_8_result;
    for (int v10_8_label = 1; v10_8_label <= 2; ++v10_8_label) {
      const Space v10_8_tail = child(v10_7,v10_8_label);
      if (v10_8_tail.empty()) continue;
      const Path v10_8_head{v10_8_label};
      const Space v29_2 = singleton(v10_8_head);
      const Space v29_3 = intersect(constant_2,v29_2);
      const Space v29_4 = (has_head(v29_3) ? constant_3 : Space{});
      const Space v29_5 = subtract(constant_1,v29_4);
      Space v29_7;
      if (!v29_5.empty()) {
        Space v30_6_result;
        for (int v30_6_label = 1; v30_6_label <= 2; ++v30_6_label) {
          const Space v30_6_tail = child(v10_8_tail,v30_6_label);
          if (v30_6_tail.empty()) continue;
          const Path v30_6_head{v30_6_label};
          const Space v31_2 = singleton(v30_6_head);
          const Space v31_3 = intersect(constant_2,v31_2);
          const Space v31_4 = (has_head(v31_3) ? constant_3 : Space{});
          const Space v31_5 = subtract(constant_1,v31_4);
          Space v31_8;
          if (!v31_5.empty()) {
            const Path v32_6 = concat_path(v10_8_head,v30_6_head);
            const Space v32_7 = routine_10(c, v32_6, v30_6_tail, v0_57);
            v31_8 = compose(v31_5,v32_7);
          }
          const Space v31_9 = intersect(constant_2,v31_2);
          const Space v31_10 = (has_head(v31_9) ? constant_3 : Space{});
          Space v31_12;
          if (!v31_10.empty()) {
            const Path v33_6 = concat_path(v10_8_head,v30_6_head);
            const Space v33_11 = routine_11(c, v33_6, v30_6_tail, v0_57);
            v31_12 = compose(v31_10,v33_11);
          }
          const Space v31_13 = unite(v31_8,v31_12);
          v30_6_result = unite(v30_6_result,v31_13);
        }
        const Space v30_6 = std::move(v30_6_result);
        v29_7 = compose(v29_5,v30_6);
      }
      const Space v29_8 = intersect(constant_2,v29_2);
      const Space v29_9 = (has_head(v29_8) ? constant_3 : Space{});
      Space v29_11;
      if (!v29_9.empty()) {
        Space v34_10_result;
        for (int v34_10_label = 1; v34_10_label <= 2; ++v34_10_label) {
          const Space v34_10_tail = child(v10_8_tail,v34_10_label);
          if (v34_10_tail.empty()) continue;
          const Path v34_10_head{v34_10_label};
          const Space v35_2 = singleton(v34_10_head);
          const Space v35_3 = intersect(constant_2,v35_2);
          const Space v35_4 = (has_head(v35_3) ? constant_3 : Space{});
          const Space v35_5 = subtract(constant_1,v35_4);
          Space v35_8;
          if (!v35_5.empty()) {
            const Path v36_6 = concat_path(v10_8_head,v34_10_head);
            const Space v36_7 = routine_10(c, v36_6, v34_10_tail, v0_57);
            v35_8 = compose(v35_5,v36_7);
          }
          const Space v35_9 = intersect(constant_2,v35_2);
          const Space v35_10 = (has_head(v35_9) ? constant_3 : Space{});
          Space v35_12;
          if (!v35_10.empty()) {
            const Path v37_6 = concat_path(v10_8_head,v34_10_head);
            const Space v37_11 = routine_12(c, v37_6, v34_10_tail, v0_57);
            v35_12 = compose(v35_10,v37_11);
          }
          const Space v35_13 = unite(v35_8,v35_12);
          v34_10_result = unite(v34_10_result,v35_13);
        }
        const Space v34_10 = std::move(v34_10_result);
        v29_11 = compose(v29_9,v34_10);
      }
      const Space v29_12 = unite(v29_7,v29_11);
      v10_8_result = unite(v10_8_result,v29_12);
    }
    const Space v10_8 = std::move(v10_8_result);
    const Space v10_9 = unite(v10_5,v10_8);
    const Space v10_10 = unwrap(v10_6,constant_0);
    Space v10_11_result;
    for (int v10_11_label = 1; v10_11_label <= 2; ++v10_11_label) {
      const Space v10_11_tail = child(v10_10,v10_11_label);
      if (v10_11_tail.empty()) continue;
      const Path v10_11_head{v10_11_label};
      const Space v38_2 = singleton(v10_11_head);
      const Space v38_3 = intersect(constant_2,v38_2);
      const Space v38_4 = (has_head(v38_3) ? constant_3 : Space{});
      const Space v38_5 = subtract(constant_1,v38_4);
      Space v38_7;
      if (!v38_5.empty()) {
        Space v39_6_result;
        for (int v39_6_label = 1; v39_6_label <= 2; ++v39_6_label) {
          const Space v39_6_tail = child(v10_11_tail,v39_6_label);
          if (v39_6_tail.empty()) continue;
          const Path v39_6_head{v39_6_label};
          const Space v40_2 = singleton(v39_6_head);
          const Space v40_3 = intersect(constant_2,v40_2);
          const Space v40_4 = (has_head(v40_3) ? constant_3 : Space{});
          const Space v40_5 = subtract(constant_1,v40_4);
          Space v40_8;
          if (!v40_5.empty()) {
            const Path v41_6 = concat_path(v10_11_head,v39_6_head);
            const Space v41_7 = routine_13(c, v41_6, v39_6_tail);
            v40_8 = compose(v40_5,v41_7);
          }
          const Space v40_9 = intersect(constant_2,v40_2);
          const Space v40_10 = (has_head(v40_9) ? constant_3 : Space{});
          Space v40_12;
          if (!v40_10.empty()) {
            const Path v42_6 = concat_path(v10_11_head,v39_6_head);
            const Space v42_11 = routine_14(c, v42_6, v39_6_tail);
            v40_12 = compose(v40_10,v42_11);
          }
          const Space v40_13 = unite(v40_8,v40_12);
          v39_6_result = unite(v39_6_result,v40_13);
        }
        const Space v39_6 = std::move(v39_6_result);
        v38_7 = compose(v38_5,v39_6);
      }
      const Space v38_8 = intersect(constant_2,v38_2);
      const Space v38_9 = (has_head(v38_8) ? constant_3 : Space{});
      Space v38_11;
      if (!v38_9.empty()) {
        Space v43_10_result;
        for (int v43_10_label = 1; v43_10_label <= 2; ++v43_10_label) {
          const Space v43_10_tail = child(v10_11_tail,v43_10_label);
          if (v43_10_tail.empty()) continue;
          const Path v43_10_head{v43_10_label};
          const Space v44_2 = singleton(v43_10_head);
          const Space v44_3 = intersect(constant_2,v44_2);
          const Space v44_4 = (has_head(v44_3) ? constant_3 : Space{});
          const Space v44_5 = subtract(constant_1,v44_4);
          Space v44_8;
          if (!v44_5.empty()) {
            const Path v45_6 = concat_path(v10_11_head,v43_10_head);
            const Space v45_7 = routine_13(c, v45_6, v43_10_tail);
            v44_8 = compose(v44_5,v45_7);
          }
          const Space v44_9 = intersect(constant_2,v44_2);
          const Space v44_10 = (has_head(v44_9) ? constant_3 : Space{});
          Space v44_12;
          if (!v44_10.empty()) {
            const Path v46_6 = concat_path(v10_11_head,v43_10_head);
            const Space v46_11 = routine_15(c, v46_6, v43_10_tail);
            v44_12 = compose(v44_10,v46_11);
          }
          const Space v44_13 = unite(v44_8,v44_12);
          v43_10_result = unite(v43_10_result,v44_13);
        }
        const Space v43_10 = std::move(v43_10_result);
        v38_11 = compose(v38_9,v43_10);
      }
      const Space v38_12 = unite(v38_7,v38_11);
      v10_11_result = unite(v10_11_result,v38_12);
    }
    const Space v10_11 = std::move(v10_11_result);
    const Space v10_12 = unite(v10_9,v10_11);
    const Space v10_13 = unwrap(v0_57,constant_7);
    const Space v10_14 = subtract(v10_12,v10_13);
    const Space v10_15 = unwrap(v0_57,constant_8);
    const Space v10_16 = subtract(v10_14,v10_15);
    const Space v10_17 = wrap(v10_16,constant_7);
    const Space v10_18 = unite(v10_1,v10_6);
    const Space v10_19 = wrap(v10_18,constant_5);
    const Space v10_20 = unite(v10_17,v10_19);
    const Space v10_21 = unite(v10_20,v0_57);
    Space v0_57_next = unite(v0_57,v10_21);
    if (equal(v0_57_next,v0_57)) break;
    v0_57 = std::move(v0_57_next);
  }
  const Space v0_58 = unwrap(v0_57,constant_8);
  return v0_58;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v47_11_result;
  for (int v47_11_label = 1; v47_11_label <= 2; ++v47_11_label) {
    const Space v47_11_tail = child(s0,v47_11_label);
    if (v47_11_tail.empty()) continue;
    const Path v47_11_head{v47_11_label};
    const Space v48_2 = singleton(v47_11_head);
    const Space v48_3 = intersect(constant_2,v48_2);
    const Space v48_4 = (has_head(v48_3) ? constant_3 : Space{});
    const Space v48_5 = subtract(constant_1,v48_4);
    Space v48_8;
    if (!v48_5.empty()) {
      const Path v49_6 = concat_path(p0,v47_11_head);
      Space v49_7_result;
      for (int v49_7_label = 1; v49_7_label <= 2; ++v49_7_label) {
        const Space v49_7_tail = child(v47_11_tail,v49_7_label);
        if (v49_7_tail.empty()) continue;
        const Path v49_7_head{v49_7_label};
        const Space v50_2 = singleton(v49_7_head);
        const Space v50_3 = intersect(constant_2,v50_2);
        const Space v50_4 = (has_head(v50_3) ? constant_3 : Space{});
        const Space v50_5 = subtract(constant_1,v50_4);
        Space v50_8;
        if (!v50_5.empty()) {
          const Path v51_6 = concat_path(v49_6,v49_7_head);
          const Space v51_7 = routine_16(c, v51_6, v49_7_tail);
          v50_8 = compose(v50_5,v51_7);
        }
        const Space v50_9 = intersect(constant_2,v50_2);
        const Space v50_10 = (has_head(v50_9) ? constant_3 : Space{});
        Space v50_12;
        if (!v50_10.empty()) {
          const Path v52_6 = concat_path(v49_6,v49_7_head);
          const Space v52_11 = routine_17(c, v52_6, v49_7_tail);
          v50_12 = compose(v50_10,v52_11);
        }
        const Space v50_13 = unite(v50_8,v50_12);
        v49_7_result = unite(v49_7_result,v50_13);
      }
      const Space v49_7 = std::move(v49_7_result);
      v48_8 = compose(v48_5,v49_7);
    }
    const Space v48_9 = intersect(constant_2,v48_2);
    const Space v48_10 = (has_head(v48_9) ? constant_3 : Space{});
    Space v48_12;
    if (!v48_10.empty()) {
      const Path v53_6 = concat_path(p0,v47_11_head);
      Space v53_11_result;
      for (int v53_11_label = 1; v53_11_label <= 2; ++v53_11_label) {
        const Space v53_11_tail = child(v47_11_tail,v53_11_label);
        if (v53_11_tail.empty()) continue;
        const Path v53_11_head{v53_11_label};
        const Space v54_2 = singleton(v53_11_head);
        const Space v54_3 = intersect(constant_2,v54_2);
        const Space v54_4 = (has_head(v54_3) ? constant_3 : Space{});
        const Space v54_5 = subtract(constant_1,v54_4);
        Space v54_8;
        if (!v54_5.empty()) {
          const Path v55_6 = concat_path(v53_6,v53_11_head);
          const Space v55_7 = routine_16(c, v55_6, v53_11_tail);
          v54_8 = compose(v54_5,v55_7);
        }
        const Space v54_9 = intersect(constant_2,v54_2);
        const Space v54_10 = (has_head(v54_9) ? constant_3 : Space{});
        Space v54_12;
        if (!v54_10.empty()) {
          const Path v56_6 = concat_path(v53_6,v53_11_head);
          const Space v56_11 = routine_3(c, v56_6, v53_11_tail);
          v54_12 = compose(v54_10,v56_11);
        }
        const Space v54_13 = unite(v54_8,v54_12);
        v53_11_result = unite(v53_11_result,v54_13);
      }
      const Space v53_11 = std::move(v53_11_result);
      v48_12 = compose(v48_10,v53_11);
    }
    const Space v48_13 = unite(v48_8,v48_12);
    v47_11_result = unite(v47_11_result,v48_13);
  }
  const Space v47_11 = std::move(v47_11_result);
  return v47_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  Space v57_11_result;
  for (int v57_11_label = 1; v57_11_label <= 2; ++v57_11_label) {
    const Space v57_11_tail = child(s0,v57_11_label);
    if (v57_11_tail.empty()) continue;
    const Path v57_11_head{v57_11_label};
    const Space v58_2 = singleton(v57_11_head);
    const Space v58_3 = intersect(constant_2,v58_2);
    const Space v58_4 = (has_head(v58_3) ? constant_3 : Space{});
    const Space v58_5 = subtract(constant_1,v58_4);
    Space v58_8;
    if (!v58_5.empty()) {
      const Path v59_6 = concat_path(p0,v57_11_head);
      Space v59_7_result;
      for (int v59_7_label = 1; v59_7_label <= 2; ++v59_7_label) {
        const Space v59_7_tail = child(v57_11_tail,v59_7_label);
        if (v59_7_tail.empty()) continue;
        const Path v59_7_head{v59_7_label};
        const Space v60_2 = singleton(v59_7_head);
        const Space v60_3 = intersect(constant_2,v60_2);
        const Space v60_4 = (has_head(v60_3) ? constant_3 : Space{});
        const Space v60_5 = subtract(constant_1,v60_4);
        Space v60_8;
        if (!v60_5.empty()) {
          const Path v61_6 = concat_path(v59_6,v59_7_head);
          const Space v61_7 = routine_16(c, v61_6, v59_7_tail);
          v60_8 = compose(v60_5,v61_7);
        }
        const Space v60_9 = intersect(constant_2,v60_2);
        const Space v60_10 = (has_head(v60_9) ? constant_3 : Space{});
        Space v60_12;
        if (!v60_10.empty()) {
          const Path v62_6 = concat_path(v59_6,v59_7_head);
          const Space v62_11 = routine_17(c, v62_6, v59_7_tail);
          v60_12 = compose(v60_10,v62_11);
        }
        const Space v60_13 = unite(v60_8,v60_12);
        v59_7_result = unite(v59_7_result,v60_13);
      }
      const Space v59_7 = std::move(v59_7_result);
      v58_8 = compose(v58_5,v59_7);
    }
    const Space v58_9 = intersect(constant_2,v58_2);
    const Space v58_10 = (has_head(v58_9) ? constant_3 : Space{});
    Space v58_12;
    if (!v58_10.empty()) {
      const Path v63_6 = concat_path(p0,v57_11_head);
      Space v63_11_result;
      for (int v63_11_label = 1; v63_11_label <= 2; ++v63_11_label) {
        const Space v63_11_tail = child(v57_11_tail,v63_11_label);
        if (v63_11_tail.empty()) continue;
        const Path v63_11_head{v63_11_label};
        const Space v64_2 = singleton(v63_11_head);
        const Space v64_3 = intersect(constant_2,v64_2);
        const Space v64_4 = (has_head(v64_3) ? constant_3 : Space{});
        const Space v64_5 = subtract(constant_1,v64_4);
        Space v64_7;
        if (!v64_5.empty()) {
          const Space v65_6 = routine_18(c, v63_11_head, v63_6, v63_11_tail);
          v64_7 = compose(v64_5,v65_6);
        }
        const Space v64_8 = intersect(constant_2,v64_2);
        const Space v64_9 = (has_head(v64_8) ? constant_3 : Space{});
        Space v64_11;
        if (!v64_9.empty()) {
          const Space v66_10 = routine_19(c, v63_11_head, v63_6, v63_11_tail);
          v64_11 = compose(v64_9,v66_10);
        }
        const Space v64_12 = unite(v64_7,v64_11);
        v63_11_result = unite(v63_11_result,v64_12);
      }
      const Space v63_11 = std::move(v63_11_result);
      v58_12 = compose(v58_10,v63_11);
    }
    const Space v58_13 = unite(v58_8,v58_12);
    v57_11_result = unite(v57_11_result,v58_13);
  }
  const Space v57_11 = std::move(v57_11_result);
  return v57_11;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  Space v67_11_result;
  for (int v67_11_label = 1; v67_11_label <= 2; ++v67_11_label) {
    const Space v67_11_tail = child(s0,v67_11_label);
    if (v67_11_tail.empty()) continue;
    const Path v67_11_head{v67_11_label};
    const Space v68_2 = singleton(v67_11_head);
    const Space v68_3 = intersect(constant_2,v68_2);
    const Space v68_4 = (has_head(v68_3) ? constant_3 : Space{});
    const Space v68_5 = subtract(constant_1,v68_4);
    Space v68_7;
    if (!v68_5.empty()) {
      Space v69_6_result;
      for (int v69_6_label = 1; v69_6_label <= 2; ++v69_6_label) {
        const Space v69_6_tail = child(v67_11_tail,v69_6_label);
        if (v69_6_tail.empty()) continue;
        const Path v69_6_head{v69_6_label};
        const Space v70_2 = singleton(v69_6_head);
        const Space v70_3 = intersect(constant_2,v70_2);
        const Space v70_4 = (has_head(v70_3) ? constant_3 : Space{});
        const Space v70_5 = subtract(constant_1,v70_4);
        Space v70_8;
        if (!v70_5.empty()) {
          const Path v71_6 = concat_path(v67_11_head,v69_6_head);
          const Space v71_7 = routine_20(c, v71_6, p0, v69_6_tail);
          v70_8 = compose(v70_5,v71_7);
        }
        const Space v70_9 = intersect(constant_2,v70_2);
        const Space v70_10 = (has_head(v70_9) ? constant_3 : Space{});
        Space v70_12;
        if (!v70_10.empty()) {
          const Path v72_6 = concat_path(v67_11_head,v69_6_head);
          const Space v72_11 = routine_21(c, v72_6, p0, v69_6_tail);
          v70_12 = compose(v70_10,v72_11);
        }
        const Space v70_13 = unite(v70_8,v70_12);
        v69_6_result = unite(v69_6_result,v70_13);
      }
      const Space v69_6 = std::move(v69_6_result);
      v68_7 = compose(v68_5,v69_6);
    }
    const Space v68_8 = intersect(constant_2,v68_2);
    const Space v68_9 = (has_head(v68_8) ? constant_3 : Space{});
    Space v68_11;
    if (!v68_9.empty()) {
      Space v73_10_result;
      for (int v73_10_label = 1; v73_10_label <= 2; ++v73_10_label) {
        const Space v73_10_tail = child(v67_11_tail,v73_10_label);
        if (v73_10_tail.empty()) continue;
        const Path v73_10_head{v73_10_label};
        const Space v74_2 = singleton(v73_10_head);
        const Space v74_3 = intersect(constant_2,v74_2);
        const Space v74_4 = (has_head(v74_3) ? constant_3 : Space{});
        const Space v74_5 = subtract(constant_1,v74_4);
        Space v74_8;
        if (!v74_5.empty()) {
          const Path v75_6 = concat_path(v67_11_head,v73_10_head);
          const Space v75_7 = routine_20(c, v75_6, p0, v73_10_tail);
          v74_8 = compose(v74_5,v75_7);
        }
        const Space v74_9 = intersect(constant_2,v74_2);
        const Space v74_10 = (has_head(v74_9) ? constant_3 : Space{});
        Space v74_12;
        if (!v74_10.empty()) {
          const Path v76_6 = concat_path(v67_11_head,v73_10_head);
          const Space v76_11 = routine_22(c, v76_6, p0, v73_10_tail);
          v74_12 = compose(v74_10,v76_11);
        }
        const Space v74_13 = unite(v74_8,v74_12);
        v73_10_result = unite(v73_10_result,v74_13);
      }
      const Space v73_10 = std::move(v73_10_result);
      v68_11 = compose(v68_9,v73_10);
    }
    const Space v68_12 = unite(v68_7,v68_11);
    v67_11_result = unite(v67_11_result,v68_12);
  }
  const Space v67_11 = std::move(v67_11_result);
  return v67_11;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v77_12_result;
  for (int v77_12_label = 1; v77_12_label <= 2; ++v77_12_label) {
    const Space v77_12_tail = child(s0,v77_12_label);
    if (v77_12_tail.empty()) continue;
    const Path v77_12_head{v77_12_label};
    const Space v78_2 = singleton(v77_12_head);
    const Space v78_3 = intersect(constant_2,v78_2);
    const Space v78_4 = (has_head(v78_3) ? constant_3 : Space{});
    const Space v78_5 = subtract(constant_1,v78_4);
    Space v78_8;
    if (!v78_5.empty()) {
      const Path v79_6 = concat_path(p0,v77_12_head);
      Space v79_7_result;
      for (int v79_7_label = 1; v79_7_label <= 2; ++v79_7_label) {
        const Space v79_7_tail = child(v77_12_tail,v79_7_label);
        if (v79_7_tail.empty()) continue;
        const Path v79_7_head{v79_7_label};
        const Space v80_2 = singleton(v79_7_head);
        const Space v80_3 = intersect(constant_2,v80_2);
        const Space v80_4 = (has_head(v80_3) ? constant_3 : Space{});
        const Space v80_5 = subtract(constant_1,v80_4);
        Space v80_8;
        if (!v80_5.empty()) {
          const Path v81_6 = concat_path(v79_6,v79_7_head);
          const Space v81_7 = routine_23(c, v81_6, v79_7_tail, s1);
          v80_8 = compose(v80_5,v81_7);
        }
        const Space v80_9 = intersect(constant_2,v80_2);
        const Space v80_10 = (has_head(v80_9) ? constant_3 : Space{});
        Space v80_12;
        if (!v80_10.empty()) {
          const Path v82_6 = concat_path(v79_6,v79_7_head);
          const Space v82_11 = routine_24(c, v82_6, v79_7_tail, s1);
          v80_12 = compose(v80_10,v82_11);
        }
        const Space v80_13 = unite(v80_8,v80_12);
        v79_7_result = unite(v79_7_result,v80_13);
      }
      const Space v79_7 = std::move(v79_7_result);
      v78_8 = compose(v78_5,v79_7);
    }
    const Space v78_9 = intersect(constant_2,v78_2);
    const Space v78_10 = (has_head(v78_9) ? constant_3 : Space{});
    Space v78_12;
    if (!v78_10.empty()) {
      const Path v83_6 = concat_path(p0,v77_12_head);
      Space v83_11_result;
      for (int v83_11_label = 1; v83_11_label <= 2; ++v83_11_label) {
        const Space v83_11_tail = child(v77_12_tail,v83_11_label);
        if (v83_11_tail.empty()) continue;
        const Path v83_11_head{v83_11_label};
        const Space v84_2 = singleton(v83_11_head);
        const Space v84_3 = intersect(constant_2,v84_2);
        const Space v84_4 = (has_head(v84_3) ? constant_3 : Space{});
        const Space v84_5 = subtract(constant_1,v84_4);
        Space v84_8;
        if (!v84_5.empty()) {
          const Path v85_6 = concat_path(v83_6,v83_11_head);
          const Space v85_7 = routine_23(c, v85_6, v83_11_tail, s1);
          v84_8 = compose(v84_5,v85_7);
        }
        const Space v84_9 = intersect(constant_2,v84_2);
        const Space v84_10 = (has_head(v84_9) ? constant_3 : Space{});
        Space v84_12;
        if (!v84_10.empty()) {
          const Path v86_6 = concat_path(v83_6,v83_11_head);
          const Space v86_11 = routine_6(c, v86_6, v83_11_tail, s1);
          v84_12 = compose(v84_10,v86_11);
        }
        const Space v84_13 = unite(v84_8,v84_12);
        v83_11_result = unite(v83_11_result,v84_13);
      }
      const Space v83_11 = std::move(v83_11_result);
      v78_12 = compose(v78_10,v83_11);
    }
    const Space v78_13 = unite(v78_8,v78_12);
    v77_12_result = unite(v77_12_result,v78_13);
  }
  const Space v77_12 = std::move(v77_12_result);
  return v77_12;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v87_12_result;
  for (int v87_12_label = 1; v87_12_label <= 2; ++v87_12_label) {
    const Space v87_12_tail = child(s0,v87_12_label);
    if (v87_12_tail.empty()) continue;
    const Path v87_12_head{v87_12_label};
    const Space v88_2 = singleton(v87_12_head);
    const Space v88_3 = intersect(constant_2,v88_2);
    const Space v88_4 = (has_head(v88_3) ? constant_3 : Space{});
    const Space v88_5 = subtract(constant_1,v88_4);
    Space v88_8;
    if (!v88_5.empty()) {
      const Path v89_6 = concat_path(p0,v87_12_head);
      Space v89_7_result;
      for (int v89_7_label = 1; v89_7_label <= 2; ++v89_7_label) {
        const Space v89_7_tail = child(v87_12_tail,v89_7_label);
        if (v89_7_tail.empty()) continue;
        const Path v89_7_head{v89_7_label};
        const Space v90_2 = singleton(v89_7_head);
        const Space v90_3 = intersect(constant_2,v90_2);
        const Space v90_4 = (has_head(v90_3) ? constant_3 : Space{});
        const Space v90_5 = subtract(constant_1,v90_4);
        Space v90_8;
        if (!v90_5.empty()) {
          const Path v91_6 = concat_path(v89_6,v89_7_head);
          const Space v91_7 = routine_23(c, v91_6, v89_7_tail, s1);
          v90_8 = compose(v90_5,v91_7);
        }
        const Space v90_9 = intersect(constant_2,v90_2);
        const Space v90_10 = (has_head(v90_9) ? constant_3 : Space{});
        Space v90_12;
        if (!v90_10.empty()) {
          const Path v92_6 = concat_path(v89_6,v89_7_head);
          const Space v92_11 = routine_24(c, v92_6, v89_7_tail, s1);
          v90_12 = compose(v90_10,v92_11);
        }
        const Space v90_13 = unite(v90_8,v90_12);
        v89_7_result = unite(v89_7_result,v90_13);
      }
      const Space v89_7 = std::move(v89_7_result);
      v88_8 = compose(v88_5,v89_7);
    }
    const Space v88_9 = intersect(constant_2,v88_2);
    const Space v88_10 = (has_head(v88_9) ? constant_3 : Space{});
    Space v88_12;
    if (!v88_10.empty()) {
      const Path v93_6 = concat_path(p0,v87_12_head);
      Space v93_11_result;
      for (int v93_11_label = 1; v93_11_label <= 2; ++v93_11_label) {
        const Space v93_11_tail = child(v87_12_tail,v93_11_label);
        if (v93_11_tail.empty()) continue;
        const Path v93_11_head{v93_11_label};
        const Space v94_2 = singleton(v93_11_head);
        const Space v94_3 = intersect(constant_2,v94_2);
        const Space v94_4 = (has_head(v94_3) ? constant_3 : Space{});
        const Space v94_5 = subtract(constant_1,v94_4);
        Space v94_7;
        if (!v94_5.empty()) {
          const Space v95_6 = routine_25(c, v93_11_head, v93_6, v93_11_tail, s1);
          v94_7 = compose(v94_5,v95_6);
        }
        const Space v94_8 = intersect(constant_2,v94_2);
        const Space v94_9 = (has_head(v94_8) ? constant_3 : Space{});
        Space v94_11;
        if (!v94_9.empty()) {
          const Space v96_10 = routine_26(c, v93_11_head, v93_6, v93_11_tail, s1);
          v94_11 = compose(v94_9,v96_10);
        }
        const Space v94_12 = unite(v94_7,v94_11);
        v93_11_result = unite(v93_11_result,v94_12);
      }
      const Space v93_11 = std::move(v93_11_result);
      v88_12 = compose(v88_10,v93_11);
    }
    const Space v88_13 = unite(v88_8,v88_12);
    v87_12_result = unite(v87_12_result,v88_13);
  }
  const Space v87_12 = std::move(v87_12_result);
  return v87_12;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v97_12_result;
  for (int v97_12_label = 1; v97_12_label <= 2; ++v97_12_label) {
    const Space v97_12_tail = child(s0,v97_12_label);
    if (v97_12_tail.empty()) continue;
    const Path v97_12_head{v97_12_label};
    const Space v98_2 = singleton(v97_12_head);
    const Space v98_3 = intersect(constant_2,v98_2);
    const Space v98_4 = (has_head(v98_3) ? constant_3 : Space{});
    const Space v98_5 = subtract(constant_1,v98_4);
    Space v98_7;
    if (!v98_5.empty()) {
      Space v99_6_result;
      for (int v99_6_label = 1; v99_6_label <= 2; ++v99_6_label) {
        const Space v99_6_tail = child(v97_12_tail,v99_6_label);
        if (v99_6_tail.empty()) continue;
        const Path v99_6_head{v99_6_label};
        const Space v100_2 = singleton(v99_6_head);
        const Space v100_3 = intersect(constant_2,v100_2);
        const Space v100_4 = (has_head(v100_3) ? constant_3 : Space{});
        const Space v100_5 = subtract(constant_1,v100_4);
        Space v100_8;
        if (!v100_5.empty()) {
          const Path v101_6 = concat_path(v97_12_head,v99_6_head);
          const Space v101_7 = routine_27(c, v101_6, p0, v99_6_tail, s1);
          v100_8 = compose(v100_5,v101_7);
        }
        const Space v100_9 = intersect(constant_2,v100_2);
        const Space v100_10 = (has_head(v100_9) ? constant_3 : Space{});
        Space v100_12;
        if (!v100_10.empty()) {
          const Path v102_6 = concat_path(v97_12_head,v99_6_head);
          const Space v102_11 = routine_28(c, v102_6, p0, v99_6_tail, s1);
          v100_12 = compose(v100_10,v102_11);
        }
        const Space v100_13 = unite(v100_8,v100_12);
        v99_6_result = unite(v99_6_result,v100_13);
      }
      const Space v99_6 = std::move(v99_6_result);
      v98_7 = compose(v98_5,v99_6);
    }
    const Space v98_8 = intersect(constant_2,v98_2);
    const Space v98_9 = (has_head(v98_8) ? constant_3 : Space{});
    Space v98_11;
    if (!v98_9.empty()) {
      Space v103_10_result;
      for (int v103_10_label = 1; v103_10_label <= 2; ++v103_10_label) {
        const Space v103_10_tail = child(v97_12_tail,v103_10_label);
        if (v103_10_tail.empty()) continue;
        const Path v103_10_head{v103_10_label};
        const Space v104_2 = singleton(v103_10_head);
        const Space v104_3 = intersect(constant_2,v104_2);
        const Space v104_4 = (has_head(v104_3) ? constant_3 : Space{});
        const Space v104_5 = subtract(constant_1,v104_4);
        Space v104_8;
        if (!v104_5.empty()) {
          const Path v105_6 = concat_path(v97_12_head,v103_10_head);
          const Space v105_7 = routine_27(c, v105_6, p0, v103_10_tail, s1);
          v104_8 = compose(v104_5,v105_7);
        }
        const Space v104_9 = intersect(constant_2,v104_2);
        const Space v104_10 = (has_head(v104_9) ? constant_3 : Space{});
        Space v104_12;
        if (!v104_10.empty()) {
          const Path v106_6 = concat_path(v97_12_head,v103_10_head);
          const Space v106_11 = routine_29(c, v106_6, p0, v103_10_tail, s1);
          v104_12 = compose(v104_10,v106_11);
        }
        const Space v104_13 = unite(v104_8,v104_12);
        v103_10_result = unite(v103_10_result,v104_13);
      }
      const Space v103_10 = std::move(v103_10_result);
      v98_11 = compose(v98_9,v103_10);
    }
    const Space v98_12 = unite(v98_7,v98_11);
    v97_12_result = unite(v97_12_result,v98_12);
  }
  const Space v97_12 = std::move(v97_12_result);
  return v97_12;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v107_12_result;
  for (int v107_12_label = 1; v107_12_label <= 2; ++v107_12_label) {
    const Space v107_12_tail = child(s0,v107_12_label);
    if (v107_12_tail.empty()) continue;
    const Path v107_12_head{v107_12_label};
    const Space v108_2 = singleton(v107_12_head);
    const Space v108_3 = intersect(constant_2,v108_2);
    const Space v108_4 = (has_head(v108_3) ? constant_3 : Space{});
    const Space v108_5 = subtract(constant_1,v108_4);
    Space v108_8;
    if (!v108_5.empty()) {
      const Path v109_6 = concat_path(p0,v107_12_head);
      Space v109_7_result;
      for (int v109_7_label = 1; v109_7_label <= 2; ++v109_7_label) {
        const Space v109_7_tail = child(v107_12_tail,v109_7_label);
        if (v109_7_tail.empty()) continue;
        const Path v109_7_head{v109_7_label};
        const Space v110_2 = singleton(v109_7_head);
        const Space v110_3 = intersect(constant_2,v110_2);
        const Space v110_4 = (has_head(v110_3) ? constant_3 : Space{});
        const Space v110_5 = subtract(constant_1,v110_4);
        Space v110_8;
        if (!v110_5.empty()) {
          const Path v111_6 = concat_path(v109_6,v109_7_head);
          const Space v111_7 = routine_30(c, v111_6, v109_7_tail, s1);
          v110_8 = compose(v110_5,v111_7);
        }
        const Space v110_9 = intersect(constant_2,v110_2);
        const Space v110_10 = (has_head(v110_9) ? constant_3 : Space{});
        Space v110_12;
        if (!v110_10.empty()) {
          const Path v112_6 = concat_path(v109_6,v109_7_head);
          const Space v112_11 = routine_31(c, v112_6, v109_7_tail, s1);
          v110_12 = compose(v110_10,v112_11);
        }
        const Space v110_13 = unite(v110_8,v110_12);
        v109_7_result = unite(v109_7_result,v110_13);
      }
      const Space v109_7 = std::move(v109_7_result);
      v108_8 = compose(v108_5,v109_7);
    }
    const Space v108_9 = intersect(constant_2,v108_2);
    const Space v108_10 = (has_head(v108_9) ? constant_3 : Space{});
    Space v108_12;
    if (!v108_10.empty()) {
      const Path v113_6 = concat_path(p0,v107_12_head);
      Space v113_11_result;
      for (int v113_11_label = 1; v113_11_label <= 2; ++v113_11_label) {
        const Space v113_11_tail = child(v107_12_tail,v113_11_label);
        if (v113_11_tail.empty()) continue;
        const Path v113_11_head{v113_11_label};
        const Space v114_2 = singleton(v113_11_head);
        const Space v114_3 = intersect(constant_2,v114_2);
        const Space v114_4 = (has_head(v114_3) ? constant_3 : Space{});
        const Space v114_5 = subtract(constant_1,v114_4);
        Space v114_8;
        if (!v114_5.empty()) {
          const Path v115_6 = concat_path(v113_6,v113_11_head);
          const Space v115_7 = routine_30(c, v115_6, v113_11_tail, s1);
          v114_8 = compose(v114_5,v115_7);
        }
        const Space v114_9 = intersect(constant_2,v114_2);
        const Space v114_10 = (has_head(v114_9) ? constant_3 : Space{});
        Space v114_12;
        if (!v114_10.empty()) {
          const Path v116_6 = concat_path(v113_6,v113_11_head);
          const Space v116_11 = routine_9(c, v116_6, v113_11_tail, s1);
          v114_12 = compose(v114_10,v116_11);
        }
        const Space v114_13 = unite(v114_8,v114_12);
        v113_11_result = unite(v113_11_result,v114_13);
      }
      const Space v113_11 = std::move(v113_11_result);
      v108_12 = compose(v108_10,v113_11);
    }
    const Space v108_13 = unite(v108_8,v108_12);
    v107_12_result = unite(v107_12_result,v108_13);
  }
  const Space v107_12 = std::move(v107_12_result);
  return v107_12;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v117_12_result;
  for (int v117_12_label = 1; v117_12_label <= 2; ++v117_12_label) {
    const Space v117_12_tail = child(s0,v117_12_label);
    if (v117_12_tail.empty()) continue;
    const Path v117_12_head{v117_12_label};
    const Space v118_2 = singleton(v117_12_head);
    const Space v118_3 = intersect(constant_2,v118_2);
    const Space v118_4 = (has_head(v118_3) ? constant_3 : Space{});
    const Space v118_5 = subtract(constant_1,v118_4);
    Space v118_8;
    if (!v118_5.empty()) {
      const Path v119_6 = concat_path(p0,v117_12_head);
      Space v119_7_result;
      for (int v119_7_label = 1; v119_7_label <= 2; ++v119_7_label) {
        const Space v119_7_tail = child(v117_12_tail,v119_7_label);
        if (v119_7_tail.empty()) continue;
        const Path v119_7_head{v119_7_label};
        const Space v120_2 = singleton(v119_7_head);
        const Space v120_3 = intersect(constant_2,v120_2);
        const Space v120_4 = (has_head(v120_3) ? constant_3 : Space{});
        const Space v120_5 = subtract(constant_1,v120_4);
        Space v120_8;
        if (!v120_5.empty()) {
          const Path v121_6 = concat_path(v119_6,v119_7_head);
          const Space v121_7 = routine_30(c, v121_6, v119_7_tail, s1);
          v120_8 = compose(v120_5,v121_7);
        }
        const Space v120_9 = intersect(constant_2,v120_2);
        const Space v120_10 = (has_head(v120_9) ? constant_3 : Space{});
        Space v120_12;
        if (!v120_10.empty()) {
          const Path v122_6 = concat_path(v119_6,v119_7_head);
          const Space v122_11 = routine_31(c, v122_6, v119_7_tail, s1);
          v120_12 = compose(v120_10,v122_11);
        }
        const Space v120_13 = unite(v120_8,v120_12);
        v119_7_result = unite(v119_7_result,v120_13);
      }
      const Space v119_7 = std::move(v119_7_result);
      v118_8 = compose(v118_5,v119_7);
    }
    const Space v118_9 = intersect(constant_2,v118_2);
    const Space v118_10 = (has_head(v118_9) ? constant_3 : Space{});
    Space v118_12;
    if (!v118_10.empty()) {
      const Path v123_6 = concat_path(p0,v117_12_head);
      Space v123_11_result;
      for (int v123_11_label = 1; v123_11_label <= 2; ++v123_11_label) {
        const Space v123_11_tail = child(v117_12_tail,v123_11_label);
        if (v123_11_tail.empty()) continue;
        const Path v123_11_head{v123_11_label};
        const Space v124_2 = singleton(v123_11_head);
        const Space v124_3 = intersect(constant_2,v124_2);
        const Space v124_4 = (has_head(v124_3) ? constant_3 : Space{});
        const Space v124_5 = subtract(constant_1,v124_4);
        Space v124_7;
        if (!v124_5.empty()) {
          const Space v125_6 = routine_32(c, v123_11_head, v123_6, v123_11_tail, s1);
          v124_7 = compose(v124_5,v125_6);
        }
        const Space v124_8 = intersect(constant_2,v124_2);
        const Space v124_9 = (has_head(v124_8) ? constant_3 : Space{});
        Space v124_11;
        if (!v124_9.empty()) {
          const Space v126_10 = routine_33(c, v123_11_head, v123_6, v123_11_tail, s1);
          v124_11 = compose(v124_9,v126_10);
        }
        const Space v124_12 = unite(v124_7,v124_11);
        v123_11_result = unite(v123_11_result,v124_12);
      }
      const Space v123_11 = std::move(v123_11_result);
      v118_12 = compose(v118_10,v123_11);
    }
    const Space v118_13 = unite(v118_8,v118_12);
    v117_12_result = unite(v117_12_result,v118_13);
  }
  const Space v117_12 = std::move(v117_12_result);
  return v117_12;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v127_12_result;
  for (int v127_12_label = 1; v127_12_label <= 2; ++v127_12_label) {
    const Space v127_12_tail = child(s0,v127_12_label);
    if (v127_12_tail.empty()) continue;
    const Path v127_12_head{v127_12_label};
    const Space v128_2 = singleton(v127_12_head);
    const Space v128_3 = intersect(constant_2,v128_2);
    const Space v128_4 = (has_head(v128_3) ? constant_3 : Space{});
    const Space v128_5 = subtract(constant_1,v128_4);
    Space v128_7;
    if (!v128_5.empty()) {
      Space v129_6_result;
      for (int v129_6_label = 1; v129_6_label <= 2; ++v129_6_label) {
        const Space v129_6_tail = child(v127_12_tail,v129_6_label);
        if (v129_6_tail.empty()) continue;
        const Path v129_6_head{v129_6_label};
        const Space v130_2 = singleton(v129_6_head);
        const Space v130_3 = intersect(constant_2,v130_2);
        const Space v130_4 = (has_head(v130_3) ? constant_3 : Space{});
        const Space v130_5 = subtract(constant_1,v130_4);
        Space v130_8;
        if (!v130_5.empty()) {
          const Path v131_6 = concat_path(v127_12_head,v129_6_head);
          const Space v131_7 = routine_34(c, v131_6, p0, v129_6_tail, s1);
          v130_8 = compose(v130_5,v131_7);
        }
        const Space v130_9 = intersect(constant_2,v130_2);
        const Space v130_10 = (has_head(v130_9) ? constant_3 : Space{});
        Space v130_12;
        if (!v130_10.empty()) {
          const Path v132_6 = concat_path(v127_12_head,v129_6_head);
          const Space v132_11 = routine_35(c, v132_6, p0, v129_6_tail, s1);
          v130_12 = compose(v130_10,v132_11);
        }
        const Space v130_13 = unite(v130_8,v130_12);
        v129_6_result = unite(v129_6_result,v130_13);
      }
      const Space v129_6 = std::move(v129_6_result);
      v128_7 = compose(v128_5,v129_6);
    }
    const Space v128_8 = intersect(constant_2,v128_2);
    const Space v128_9 = (has_head(v128_8) ? constant_3 : Space{});
    Space v128_11;
    if (!v128_9.empty()) {
      Space v133_10_result;
      for (int v133_10_label = 1; v133_10_label <= 2; ++v133_10_label) {
        const Space v133_10_tail = child(v127_12_tail,v133_10_label);
        if (v133_10_tail.empty()) continue;
        const Path v133_10_head{v133_10_label};
        const Space v134_2 = singleton(v133_10_head);
        const Space v134_3 = intersect(constant_2,v134_2);
        const Space v134_4 = (has_head(v134_3) ? constant_3 : Space{});
        const Space v134_5 = subtract(constant_1,v134_4);
        Space v134_8;
        if (!v134_5.empty()) {
          const Path v135_6 = concat_path(v127_12_head,v133_10_head);
          const Space v135_7 = routine_34(c, v135_6, p0, v133_10_tail, s1);
          v134_8 = compose(v134_5,v135_7);
        }
        const Space v134_9 = intersect(constant_2,v134_2);
        const Space v134_10 = (has_head(v134_9) ? constant_3 : Space{});
        Space v134_12;
        if (!v134_10.empty()) {
          const Path v136_6 = concat_path(v127_12_head,v133_10_head);
          const Space v136_11 = routine_36(c, v136_6, p0, v133_10_tail, s1);
          v134_12 = compose(v134_10,v136_11);
        }
        const Space v134_13 = unite(v134_8,v134_12);
        v133_10_result = unite(v133_10_result,v134_13);
      }
      const Space v133_10 = std::move(v133_10_result);
      v128_11 = compose(v128_9,v133_10);
    }
    const Space v128_12 = unite(v128_7,v128_11);
    v127_12_result = unite(v127_12_result,v128_12);
  }
  const Space v127_12 = std::move(v127_12_result);
  return v127_12;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v137_12_result;
  for (int v137_12_label = 1; v137_12_label <= 2; ++v137_12_label) {
    const Space v137_12_tail = child(s0,v137_12_label);
    if (v137_12_tail.empty()) continue;
    const Path v137_12_head{v137_12_label};
    const Space v138_2 = singleton(v137_12_head);
    const Space v138_3 = intersect(constant_2,v138_2);
    const Space v138_4 = (has_head(v138_3) ? constant_3 : Space{});
    const Space v138_5 = subtract(constant_1,v138_4);
    Space v138_8;
    if (!v138_5.empty()) {
      const Path v139_6 = concat_path(p0,v137_12_head);
      Space v139_7_result;
      for (int v139_7_label = 1; v139_7_label <= 2; ++v139_7_label) {
        const Space v139_7_tail = child(v137_12_tail,v139_7_label);
        if (v139_7_tail.empty()) continue;
        const Path v139_7_head{v139_7_label};
        const Space v140_2 = singleton(v139_7_head);
        const Space v140_3 = intersect(constant_2,v140_2);
        const Space v140_4 = (has_head(v140_3) ? constant_3 : Space{});
        const Space v140_5 = subtract(constant_1,v140_4);
        Space v140_8;
        if (!v140_5.empty()) {
          const Path v141_6 = concat_path(v139_6,v139_7_head);
          const Space v141_7 = routine_37(c, v141_6, v139_7_tail, s1);
          v140_8 = compose(v140_5,v141_7);
        }
        const Space v140_9 = intersect(constant_2,v140_2);
        const Space v140_10 = (has_head(v140_9) ? constant_3 : Space{});
        Space v140_12;
        if (!v140_10.empty()) {
          const Path v142_6 = concat_path(v139_6,v139_7_head);
          const Space v142_11 = routine_38(c, v142_6, v139_7_tail, s1);
          v140_12 = compose(v140_10,v142_11);
        }
        const Space v140_13 = unite(v140_8,v140_12);
        v139_7_result = unite(v139_7_result,v140_13);
      }
      const Space v139_7 = std::move(v139_7_result);
      v138_8 = compose(v138_5,v139_7);
    }
    const Space v138_9 = intersect(constant_2,v138_2);
    const Space v138_10 = (has_head(v138_9) ? constant_3 : Space{});
    Space v138_12;
    if (!v138_10.empty()) {
      const Path v143_6 = concat_path(p0,v137_12_head);
      Space v143_11_result;
      for (int v143_11_label = 1; v143_11_label <= 2; ++v143_11_label) {
        const Space v143_11_tail = child(v137_12_tail,v143_11_label);
        if (v143_11_tail.empty()) continue;
        const Path v143_11_head{v143_11_label};
        const Space v144_2 = singleton(v143_11_head);
        const Space v144_3 = intersect(constant_2,v144_2);
        const Space v144_4 = (has_head(v144_3) ? constant_3 : Space{});
        const Space v144_5 = subtract(constant_1,v144_4);
        Space v144_8;
        if (!v144_5.empty()) {
          const Path v145_6 = concat_path(v143_6,v143_11_head);
          const Space v145_7 = routine_37(c, v145_6, v143_11_tail, s1);
          v144_8 = compose(v144_5,v145_7);
        }
        const Space v144_9 = intersect(constant_2,v144_2);
        const Space v144_10 = (has_head(v144_9) ? constant_3 : Space{});
        Space v144_12;
        if (!v144_10.empty()) {
          const Path v146_6 = concat_path(v143_6,v143_11_head);
          const Space v146_11 = routine_12(c, v146_6, v143_11_tail, s1);
          v144_12 = compose(v144_10,v146_11);
        }
        const Space v144_13 = unite(v144_8,v144_12);
        v143_11_result = unite(v143_11_result,v144_13);
      }
      const Space v143_11 = std::move(v143_11_result);
      v138_12 = compose(v138_10,v143_11);
    }
    const Space v138_13 = unite(v138_8,v138_12);
    v137_12_result = unite(v137_12_result,v138_13);
  }
  const Space v137_12 = std::move(v137_12_result);
  return v137_12;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v147_12_result;
  for (int v147_12_label = 1; v147_12_label <= 2; ++v147_12_label) {
    const Space v147_12_tail = child(s0,v147_12_label);
    if (v147_12_tail.empty()) continue;
    const Path v147_12_head{v147_12_label};
    const Space v148_2 = singleton(v147_12_head);
    const Space v148_3 = intersect(constant_2,v148_2);
    const Space v148_4 = (has_head(v148_3) ? constant_3 : Space{});
    const Space v148_5 = subtract(constant_1,v148_4);
    Space v148_8;
    if (!v148_5.empty()) {
      const Path v149_6 = concat_path(p0,v147_12_head);
      Space v149_7_result;
      for (int v149_7_label = 1; v149_7_label <= 2; ++v149_7_label) {
        const Space v149_7_tail = child(v147_12_tail,v149_7_label);
        if (v149_7_tail.empty()) continue;
        const Path v149_7_head{v149_7_label};
        const Space v150_2 = singleton(v149_7_head);
        const Space v150_3 = intersect(constant_2,v150_2);
        const Space v150_4 = (has_head(v150_3) ? constant_3 : Space{});
        const Space v150_5 = subtract(constant_1,v150_4);
        Space v150_8;
        if (!v150_5.empty()) {
          const Path v151_6 = concat_path(v149_6,v149_7_head);
          const Space v151_7 = routine_37(c, v151_6, v149_7_tail, s1);
          v150_8 = compose(v150_5,v151_7);
        }
        const Space v150_9 = intersect(constant_2,v150_2);
        const Space v150_10 = (has_head(v150_9) ? constant_3 : Space{});
        Space v150_12;
        if (!v150_10.empty()) {
          const Path v152_6 = concat_path(v149_6,v149_7_head);
          const Space v152_11 = routine_38(c, v152_6, v149_7_tail, s1);
          v150_12 = compose(v150_10,v152_11);
        }
        const Space v150_13 = unite(v150_8,v150_12);
        v149_7_result = unite(v149_7_result,v150_13);
      }
      const Space v149_7 = std::move(v149_7_result);
      v148_8 = compose(v148_5,v149_7);
    }
    const Space v148_9 = intersect(constant_2,v148_2);
    const Space v148_10 = (has_head(v148_9) ? constant_3 : Space{});
    Space v148_12;
    if (!v148_10.empty()) {
      const Path v153_6 = concat_path(p0,v147_12_head);
      Space v153_11_result;
      for (int v153_11_label = 1; v153_11_label <= 2; ++v153_11_label) {
        const Space v153_11_tail = child(v147_12_tail,v153_11_label);
        if (v153_11_tail.empty()) continue;
        const Path v153_11_head{v153_11_label};
        const Space v154_2 = singleton(v153_11_head);
        const Space v154_3 = intersect(constant_2,v154_2);
        const Space v154_4 = (has_head(v154_3) ? constant_3 : Space{});
        const Space v154_5 = subtract(constant_1,v154_4);
        Space v154_7;
        if (!v154_5.empty()) {
          const Space v155_6 = routine_39(c, v153_11_head, v153_6, v153_11_tail, s1);
          v154_7 = compose(v154_5,v155_6);
        }
        const Space v154_8 = intersect(constant_2,v154_2);
        const Space v154_9 = (has_head(v154_8) ? constant_3 : Space{});
        Space v154_11;
        if (!v154_9.empty()) {
          const Space v156_10 = routine_40(c, v153_11_head, v153_6, v153_11_tail, s1);
          v154_11 = compose(v154_9,v156_10);
        }
        const Space v154_12 = unite(v154_7,v154_11);
        v153_11_result = unite(v153_11_result,v154_12);
      }
      const Space v153_11 = std::move(v153_11_result);
      v148_12 = compose(v148_10,v153_11);
    }
    const Space v148_13 = unite(v148_8,v148_12);
    v147_12_result = unite(v147_12_result,v148_13);
  }
  const Space v147_12 = std::move(v147_12_result);
  return v147_12;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v157_12_result;
  for (int v157_12_label = 1; v157_12_label <= 2; ++v157_12_label) {
    const Space v157_12_tail = child(s0,v157_12_label);
    if (v157_12_tail.empty()) continue;
    const Path v157_12_head{v157_12_label};
    const Space v158_2 = singleton(v157_12_head);
    const Space v158_3 = intersect(constant_2,v158_2);
    const Space v158_4 = (has_head(v158_3) ? constant_3 : Space{});
    const Space v158_5 = subtract(constant_1,v158_4);
    Space v158_7;
    if (!v158_5.empty()) {
      Space v159_6_result;
      for (int v159_6_label = 1; v159_6_label <= 2; ++v159_6_label) {
        const Space v159_6_tail = child(v157_12_tail,v159_6_label);
        if (v159_6_tail.empty()) continue;
        const Path v159_6_head{v159_6_label};
        const Space v160_2 = singleton(v159_6_head);
        const Space v160_3 = intersect(constant_2,v160_2);
        const Space v160_4 = (has_head(v160_3) ? constant_3 : Space{});
        const Space v160_5 = subtract(constant_1,v160_4);
        Space v160_8;
        if (!v160_5.empty()) {
          const Path v161_6 = concat_path(v157_12_head,v159_6_head);
          const Space v161_7 = routine_41(c, v161_6, p0, v159_6_tail, s1);
          v160_8 = compose(v160_5,v161_7);
        }
        const Space v160_9 = intersect(constant_2,v160_2);
        const Space v160_10 = (has_head(v160_9) ? constant_3 : Space{});
        Space v160_12;
        if (!v160_10.empty()) {
          const Path v162_6 = concat_path(v157_12_head,v159_6_head);
          const Space v162_11 = routine_42(c, v162_6, p0, v159_6_tail, s1);
          v160_12 = compose(v160_10,v162_11);
        }
        const Space v160_13 = unite(v160_8,v160_12);
        v159_6_result = unite(v159_6_result,v160_13);
      }
      const Space v159_6 = std::move(v159_6_result);
      v158_7 = compose(v158_5,v159_6);
    }
    const Space v158_8 = intersect(constant_2,v158_2);
    const Space v158_9 = (has_head(v158_8) ? constant_3 : Space{});
    Space v158_11;
    if (!v158_9.empty()) {
      Space v163_10_result;
      for (int v163_10_label = 1; v163_10_label <= 2; ++v163_10_label) {
        const Space v163_10_tail = child(v157_12_tail,v163_10_label);
        if (v163_10_tail.empty()) continue;
        const Path v163_10_head{v163_10_label};
        const Space v164_2 = singleton(v163_10_head);
        const Space v164_3 = intersect(constant_2,v164_2);
        const Space v164_4 = (has_head(v164_3) ? constant_3 : Space{});
        const Space v164_5 = subtract(constant_1,v164_4);
        Space v164_8;
        if (!v164_5.empty()) {
          const Path v165_6 = concat_path(v157_12_head,v163_10_head);
          const Space v165_7 = routine_41(c, v165_6, p0, v163_10_tail, s1);
          v164_8 = compose(v164_5,v165_7);
        }
        const Space v164_9 = intersect(constant_2,v164_2);
        const Space v164_10 = (has_head(v164_9) ? constant_3 : Space{});
        Space v164_12;
        if (!v164_10.empty()) {
          const Path v166_6 = concat_path(v157_12_head,v163_10_head);
          const Space v166_11 = routine_43(c, v166_6, p0, v163_10_tail, s1);
          v164_12 = compose(v164_10,v166_11);
        }
        const Space v164_13 = unite(v164_8,v164_12);
        v163_10_result = unite(v163_10_result,v164_13);
      }
      const Space v163_10 = std::move(v163_10_result);
      v158_11 = compose(v158_9,v163_10);
    }
    const Space v158_12 = unite(v158_7,v158_11);
    v157_12_result = unite(v157_12_result,v158_12);
  }
  const Space v157_12 = std::move(v157_12_result);
  return v157_12;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v167_11_result;
  for (int v167_11_label = 1; v167_11_label <= 2; ++v167_11_label) {
    const Space v167_11_tail = child(s0,v167_11_label);
    if (v167_11_tail.empty()) continue;
    const Path v167_11_head{v167_11_label};
    const Space v168_2 = singleton(v167_11_head);
    const Space v168_3 = intersect(constant_2,v168_2);
    const Space v168_4 = (has_head(v168_3) ? constant_3 : Space{});
    const Space v168_5 = subtract(constant_1,v168_4);
    Space v168_8;
    if (!v168_5.empty()) {
      const Path v169_6 = concat_path(p0,v167_11_head);
      Space v169_7_result;
      for (int v169_7_label = 1; v169_7_label <= 2; ++v169_7_label) {
        const Space v169_7_tail = child(v167_11_tail,v169_7_label);
        if (v169_7_tail.empty()) continue;
        const Path v169_7_head{v169_7_label};
        const Space v170_2 = singleton(v169_7_head);
        const Space v170_3 = intersect(constant_2,v170_2);
        const Space v170_4 = (has_head(v170_3) ? constant_3 : Space{});
        const Space v170_5 = subtract(constant_1,v170_4);
        Space v170_8;
        if (!v170_5.empty()) {
          const Path v171_6 = concat_path(v169_6,v169_7_head);
          const Space v171_7 = routine_44(c, v171_6, v169_7_tail);
          v170_8 = compose(v170_5,v171_7);
        }
        const Space v170_9 = intersect(constant_2,v170_2);
        const Space v170_10 = (has_head(v170_9) ? constant_3 : Space{});
        Space v170_12;
        if (!v170_10.empty()) {
          const Path v172_6 = concat_path(v169_6,v169_7_head);
          const Space v172_11 = routine_45(c, v172_6, v169_7_tail);
          v170_12 = compose(v170_10,v172_11);
        }
        const Space v170_13 = unite(v170_8,v170_12);
        v169_7_result = unite(v169_7_result,v170_13);
      }
      const Space v169_7 = std::move(v169_7_result);
      v168_8 = compose(v168_5,v169_7);
    }
    const Space v168_9 = intersect(constant_2,v168_2);
    const Space v168_10 = (has_head(v168_9) ? constant_3 : Space{});
    Space v168_12;
    if (!v168_10.empty()) {
      const Path v173_6 = concat_path(p0,v167_11_head);
      Space v173_11_result;
      for (int v173_11_label = 1; v173_11_label <= 2; ++v173_11_label) {
        const Space v173_11_tail = child(v167_11_tail,v173_11_label);
        if (v173_11_tail.empty()) continue;
        const Path v173_11_head{v173_11_label};
        const Space v174_2 = singleton(v173_11_head);
        const Space v174_3 = intersect(constant_2,v174_2);
        const Space v174_4 = (has_head(v174_3) ? constant_3 : Space{});
        const Space v174_5 = subtract(constant_1,v174_4);
        Space v174_8;
        if (!v174_5.empty()) {
          const Path v175_6 = concat_path(v173_6,v173_11_head);
          const Space v175_7 = routine_44(c, v175_6, v173_11_tail);
          v174_8 = compose(v174_5,v175_7);
        }
        const Space v174_9 = intersect(constant_2,v174_2);
        const Space v174_10 = (has_head(v174_9) ? constant_3 : Space{});
        Space v174_12;
        if (!v174_10.empty()) {
          const Path v176_6 = concat_path(v173_6,v173_11_head);
          const Space v176_11 = routine_15(c, v176_6, v173_11_tail);
          v174_12 = compose(v174_10,v176_11);
        }
        const Space v174_13 = unite(v174_8,v174_12);
        v173_11_result = unite(v173_11_result,v174_13);
      }
      const Space v173_11 = std::move(v173_11_result);
      v168_12 = compose(v168_10,v173_11);
    }
    const Space v168_13 = unite(v168_8,v168_12);
    v167_11_result = unite(v167_11_result,v168_13);
  }
  const Space v167_11 = std::move(v167_11_result);
  return v167_11;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0) {
  Space v177_11_result;
  for (int v177_11_label = 1; v177_11_label <= 2; ++v177_11_label) {
    const Space v177_11_tail = child(s0,v177_11_label);
    if (v177_11_tail.empty()) continue;
    const Path v177_11_head{v177_11_label};
    const Space v178_2 = singleton(v177_11_head);
    const Space v178_3 = intersect(constant_2,v178_2);
    const Space v178_4 = (has_head(v178_3) ? constant_3 : Space{});
    const Space v178_5 = subtract(constant_1,v178_4);
    Space v178_8;
    if (!v178_5.empty()) {
      const Path v179_6 = concat_path(p0,v177_11_head);
      Space v179_7_result;
      for (int v179_7_label = 1; v179_7_label <= 2; ++v179_7_label) {
        const Space v179_7_tail = child(v177_11_tail,v179_7_label);
        if (v179_7_tail.empty()) continue;
        const Path v179_7_head{v179_7_label};
        const Space v180_2 = singleton(v179_7_head);
        const Space v180_3 = intersect(constant_2,v180_2);
        const Space v180_4 = (has_head(v180_3) ? constant_3 : Space{});
        const Space v180_5 = subtract(constant_1,v180_4);
        Space v180_8;
        if (!v180_5.empty()) {
          const Path v181_6 = concat_path(v179_6,v179_7_head);
          const Space v181_7 = routine_44(c, v181_6, v179_7_tail);
          v180_8 = compose(v180_5,v181_7);
        }
        const Space v180_9 = intersect(constant_2,v180_2);
        const Space v180_10 = (has_head(v180_9) ? constant_3 : Space{});
        Space v180_12;
        if (!v180_10.empty()) {
          const Path v182_6 = concat_path(v179_6,v179_7_head);
          const Space v182_11 = routine_45(c, v182_6, v179_7_tail);
          v180_12 = compose(v180_10,v182_11);
        }
        const Space v180_13 = unite(v180_8,v180_12);
        v179_7_result = unite(v179_7_result,v180_13);
      }
      const Space v179_7 = std::move(v179_7_result);
      v178_8 = compose(v178_5,v179_7);
    }
    const Space v178_9 = intersect(constant_2,v178_2);
    const Space v178_10 = (has_head(v178_9) ? constant_3 : Space{});
    Space v178_12;
    if (!v178_10.empty()) {
      const Path v183_6 = concat_path(p0,v177_11_head);
      Space v183_11_result;
      for (int v183_11_label = 1; v183_11_label <= 2; ++v183_11_label) {
        const Space v183_11_tail = child(v177_11_tail,v183_11_label);
        if (v183_11_tail.empty()) continue;
        const Path v183_11_head{v183_11_label};
        const Space v184_2 = singleton(v183_11_head);
        const Space v184_3 = intersect(constant_2,v184_2);
        const Space v184_4 = (has_head(v184_3) ? constant_3 : Space{});
        const Space v184_5 = subtract(constant_1,v184_4);
        Space v184_7;
        if (!v184_5.empty()) {
          const Space v185_6 = routine_46(c, v183_11_head, v183_6, v183_11_tail);
          v184_7 = compose(v184_5,v185_6);
        }
        const Space v184_8 = intersect(constant_2,v184_2);
        const Space v184_9 = (has_head(v184_8) ? constant_3 : Space{});
        Space v184_11;
        if (!v184_9.empty()) {
          const Space v186_10 = routine_47(c, v183_11_head, v183_6, v183_11_tail);
          v184_11 = compose(v184_9,v186_10);
        }
        const Space v184_12 = unite(v184_7,v184_11);
        v183_11_result = unite(v183_11_result,v184_12);
      }
      const Space v183_11 = std::move(v183_11_result);
      v178_12 = compose(v178_10,v183_11);
    }
    const Space v178_13 = unite(v178_8,v178_12);
    v177_11_result = unite(v177_11_result,v178_13);
  }
  const Space v177_11 = std::move(v177_11_result);
  return v177_11;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0) {
  Space v187_11_result;
  for (int v187_11_label = 1; v187_11_label <= 2; ++v187_11_label) {
    const Space v187_11_tail = child(s0,v187_11_label);
    if (v187_11_tail.empty()) continue;
    const Path v187_11_head{v187_11_label};
    const Space v188_2 = singleton(v187_11_head);
    const Space v188_3 = intersect(constant_2,v188_2);
    const Space v188_4 = (has_head(v188_3) ? constant_3 : Space{});
    const Space v188_5 = subtract(constant_1,v188_4);
    Space v188_7;
    if (!v188_5.empty()) {
      Space v189_6_result;
      for (int v189_6_label = 1; v189_6_label <= 2; ++v189_6_label) {
        const Space v189_6_tail = child(v187_11_tail,v189_6_label);
        if (v189_6_tail.empty()) continue;
        const Path v189_6_head{v189_6_label};
        const Space v190_2 = singleton(v189_6_head);
        const Space v190_3 = intersect(constant_2,v190_2);
        const Space v190_4 = (has_head(v190_3) ? constant_3 : Space{});
        const Space v190_5 = subtract(constant_1,v190_4);
        Space v190_8;
        if (!v190_5.empty()) {
          const Path v191_6 = concat_path(v187_11_head,v189_6_head);
          const Space v191_7 = routine_48(c, v191_6, p0, v189_6_tail);
          v190_8 = compose(v190_5,v191_7);
        }
        const Space v190_9 = intersect(constant_2,v190_2);
        const Space v190_10 = (has_head(v190_9) ? constant_3 : Space{});
        Space v190_12;
        if (!v190_10.empty()) {
          const Path v192_6 = concat_path(v187_11_head,v189_6_head);
          const Space v192_11 = routine_49(c, v192_6, p0, v189_6_tail);
          v190_12 = compose(v190_10,v192_11);
        }
        const Space v190_13 = unite(v190_8,v190_12);
        v189_6_result = unite(v189_6_result,v190_13);
      }
      const Space v189_6 = std::move(v189_6_result);
      v188_7 = compose(v188_5,v189_6);
    }
    const Space v188_8 = intersect(constant_2,v188_2);
    const Space v188_9 = (has_head(v188_8) ? constant_3 : Space{});
    Space v188_11;
    if (!v188_9.empty()) {
      Space v193_10_result;
      for (int v193_10_label = 1; v193_10_label <= 2; ++v193_10_label) {
        const Space v193_10_tail = child(v187_11_tail,v193_10_label);
        if (v193_10_tail.empty()) continue;
        const Path v193_10_head{v193_10_label};
        const Space v194_2 = singleton(v193_10_head);
        const Space v194_3 = intersect(constant_2,v194_2);
        const Space v194_4 = (has_head(v194_3) ? constant_3 : Space{});
        const Space v194_5 = subtract(constant_1,v194_4);
        Space v194_8;
        if (!v194_5.empty()) {
          const Path v195_6 = concat_path(v187_11_head,v193_10_head);
          const Space v195_7 = routine_48(c, v195_6, p0, v193_10_tail);
          v194_8 = compose(v194_5,v195_7);
        }
        const Space v194_9 = intersect(constant_2,v194_2);
        const Space v194_10 = (has_head(v194_9) ? constant_3 : Space{});
        Space v194_12;
        if (!v194_10.empty()) {
          const Path v196_6 = concat_path(v187_11_head,v193_10_head);
          const Space v196_11 = routine_50(c, v196_6, p0, v193_10_tail);
          v194_12 = compose(v194_10,v196_11);
        }
        const Space v194_13 = unite(v194_8,v194_12);
        v193_10_result = unite(v193_10_result,v194_13);
      }
      const Space v193_10 = std::move(v193_10_result);
      v188_11 = compose(v188_9,v193_10);
    }
    const Space v188_12 = unite(v188_7,v188_11);
    v187_11_result = unite(v187_11_result,v188_12);
  }
  const Space v187_11 = std::move(v187_11_result);
  return v187_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v197_11_result;
  for (int v197_11_label = 1; v197_11_label <= 2; ++v197_11_label) {
    const Space v197_11_tail = child(s0,v197_11_label);
    if (v197_11_tail.empty()) continue;
    const Path v197_11_head{v197_11_label};
    const Space v198_2 = singleton(v197_11_head);
    const Space v198_3 = intersect(constant_2,v198_2);
    const Space v198_4 = (has_head(v198_3) ? constant_3 : Space{});
    const Space v198_5 = subtract(constant_1,v198_4);
    Space v198_8;
    if (!v198_5.empty()) {
      const Path v199_6 = concat_path(p0,v197_11_head);
      Space v199_7_result;
      for (int v199_7_label = 1; v199_7_label <= 2; ++v199_7_label) {
        const Space v199_7_tail = child(v197_11_tail,v199_7_label);
        if (v199_7_tail.empty()) continue;
        const Path v199_7_head{v199_7_label};
        const Space v200_2 = singleton(v199_7_head);
        const Space v200_3 = intersect(constant_2,v200_2);
        const Space v200_4 = (has_head(v200_3) ? constant_3 : Space{});
        const Space v200_5 = subtract(constant_1,v200_4);
        Space v200_8;
        if (!v200_5.empty()) {
          const Path v201_6 = concat_path(v199_6,v199_7_head);
          const Space v201_7 = routine_51(c, v201_6, v199_7_tail);
          v200_8 = compose(v200_5,v201_7);
        }
        const Space v200_9 = intersect(constant_2,v200_2);
        const Space v200_10 = (has_head(v200_9) ? constant_3 : Space{});
        Space v200_12;
        if (!v200_10.empty()) {
          const Path v202_6 = concat_path(v199_6,v199_7_head);
          const Space v202_11 = routine_52(c, v202_6, v199_7_tail);
          v200_12 = compose(v200_10,v202_11);
        }
        const Space v200_13 = unite(v200_8,v200_12);
        v199_7_result = unite(v199_7_result,v200_13);
      }
      const Space v199_7 = std::move(v199_7_result);
      v198_8 = compose(v198_5,v199_7);
    }
    const Space v198_9 = intersect(constant_2,v198_2);
    const Space v198_10 = (has_head(v198_9) ? constant_3 : Space{});
    Space v198_12;
    if (!v198_10.empty()) {
      const Path v203_6 = concat_path(p0,v197_11_head);
      Space v203_11_result;
      for (int v203_11_label = 1; v203_11_label <= 2; ++v203_11_label) {
        const Space v203_11_tail = child(v197_11_tail,v203_11_label);
        if (v203_11_tail.empty()) continue;
        const Path v203_11_head{v203_11_label};
        const Space v204_2 = singleton(v203_11_head);
        const Space v204_3 = intersect(constant_2,v204_2);
        const Space v204_4 = (has_head(v204_3) ? constant_3 : Space{});
        const Space v204_5 = subtract(constant_1,v204_4);
        Space v204_8;
        if (!v204_5.empty()) {
          const Path v205_6 = concat_path(v203_6,v203_11_head);
          const Space v205_7 = routine_51(c, v205_6, v203_11_tail);
          v204_8 = compose(v204_5,v205_7);
        }
        const Space v204_9 = intersect(constant_2,v204_2);
        const Space v204_10 = (has_head(v204_9) ? constant_3 : Space{});
        Space v204_12;
        if (!v204_10.empty()) {
          const Path v206_6 = concat_path(v203_6,v203_11_head);
          const Space v206_11 = routine_3(c, v206_6, v203_11_tail);
          v204_12 = compose(v204_10,v206_11);
        }
        const Space v204_13 = unite(v204_8,v204_12);
        v203_11_result = unite(v203_11_result,v204_13);
      }
      const Space v203_11 = std::move(v203_11_result);
      v198_12 = compose(v198_10,v203_11);
    }
    const Space v198_13 = unite(v198_8,v198_12);
    v197_11_result = unite(v197_11_result,v198_13);
  }
  const Space v197_11 = std::move(v197_11_result);
  return v197_11;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  Space v207_11_result;
  for (int v207_11_label = 1; v207_11_label <= 2; ++v207_11_label) {
    const Space v207_11_tail = child(s0,v207_11_label);
    if (v207_11_tail.empty()) continue;
    const Path v207_11_head{v207_11_label};
    const Space v208_2 = singleton(v207_11_head);
    const Space v208_3 = intersect(constant_2,v208_2);
    const Space v208_4 = (has_head(v208_3) ? constant_3 : Space{});
    const Space v208_5 = subtract(constant_1,v208_4);
    Space v208_8;
    if (!v208_5.empty()) {
      const Path v209_6 = concat_path(p0,v207_11_head);
      Space v209_7_result;
      for (int v209_7_label = 1; v209_7_label <= 2; ++v209_7_label) {
        const Space v209_7_tail = child(v207_11_tail,v209_7_label);
        if (v209_7_tail.empty()) continue;
        const Path v209_7_head{v209_7_label};
        const Space v210_2 = singleton(v209_7_head);
        const Space v210_3 = intersect(constant_2,v210_2);
        const Space v210_4 = (has_head(v210_3) ? constant_3 : Space{});
        const Space v210_5 = subtract(constant_1,v210_4);
        Space v210_8;
        if (!v210_5.empty()) {
          const Path v211_6 = concat_path(v209_6,v209_7_head);
          const Space v211_7 = routine_51(c, v211_6, v209_7_tail);
          v210_8 = compose(v210_5,v211_7);
        }
        const Space v210_9 = intersect(constant_2,v210_2);
        const Space v210_10 = (has_head(v210_9) ? constant_3 : Space{});
        Space v210_12;
        if (!v210_10.empty()) {
          const Path v212_6 = concat_path(v209_6,v209_7_head);
          const Space v212_11 = routine_52(c, v212_6, v209_7_tail);
          v210_12 = compose(v210_10,v212_11);
        }
        const Space v210_13 = unite(v210_8,v210_12);
        v209_7_result = unite(v209_7_result,v210_13);
      }
      const Space v209_7 = std::move(v209_7_result);
      v208_8 = compose(v208_5,v209_7);
    }
    const Space v208_9 = intersect(constant_2,v208_2);
    const Space v208_10 = (has_head(v208_9) ? constant_3 : Space{});
    Space v208_12;
    if (!v208_10.empty()) {
      const Path v213_6 = concat_path(p0,v207_11_head);
      Space v213_11_result;
      for (int v213_11_label = 1; v213_11_label <= 2; ++v213_11_label) {
        const Space v213_11_tail = child(v207_11_tail,v213_11_label);
        if (v213_11_tail.empty()) continue;
        const Path v213_11_head{v213_11_label};
        const Space v214_2 = singleton(v213_11_head);
        const Space v214_3 = intersect(constant_2,v214_2);
        const Space v214_4 = (has_head(v214_3) ? constant_3 : Space{});
        const Space v214_5 = subtract(constant_1,v214_4);
        Space v214_7;
        if (!v214_5.empty()) {
          const Space v215_6 = routine_18(c, v213_11_head, v213_6, v213_11_tail);
          v214_7 = compose(v214_5,v215_6);
        }
        const Space v214_8 = intersect(constant_2,v214_2);
        const Space v214_9 = (has_head(v214_8) ? constant_3 : Space{});
        Space v214_11;
        if (!v214_9.empty()) {
          const Space v216_10 = routine_19(c, v213_11_head, v213_6, v213_11_tail);
          v214_11 = compose(v214_9,v216_10);
        }
        const Space v214_12 = unite(v214_7,v214_11);
        v213_11_result = unite(v213_11_result,v214_12);
      }
      const Space v213_11 = std::move(v213_11_result);
      v208_12 = compose(v208_10,v213_11);
    }
    const Space v208_13 = unite(v208_8,v208_12);
    v207_11_result = unite(v207_11_result,v208_13);
  }
  const Space v207_11 = std::move(v207_11_result);
  return v207_11;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v217_12_result;
  for (int v217_12_label = 1; v217_12_label <= 2; ++v217_12_label) {
    const Space v217_12_tail = child(s0,v217_12_label);
    if (v217_12_tail.empty()) continue;
    const Path v217_12_head{v217_12_label};
    const Space v218_2 = singleton(v217_12_head);
    const Space v218_3 = intersect(constant_2,v218_2);
    const Space v218_4 = (has_head(v218_3) ? constant_3 : Space{});
    const Space v218_5 = subtract(constant_1,v218_4);
    Space v218_8;
    if (!v218_5.empty()) {
      const Path v219_6 = concat_path(p0,v217_12_head);
      Space v219_7_result;
      for (int v219_7_label = 1; v219_7_label <= 2; ++v219_7_label) {
        const Space v219_7_tail = child(v217_12_tail,v219_7_label);
        if (v219_7_tail.empty()) continue;
        const Path v219_7_head{v219_7_label};
        const Space v220_2 = singleton(v219_7_head);
        const Space v220_3 = intersect(constant_2,v220_2);
        const Space v220_4 = (has_head(v220_3) ? constant_3 : Space{});
        const Space v220_5 = subtract(constant_1,v220_4);
        Space v220_8;
        if (!v220_5.empty()) {
          const Path v221_6 = concat_path(v219_6,v219_7_head);
          const Space v221_7 = routine_53(c, v221_6, p1, v219_7_tail);
          v220_8 = compose(v220_5,v221_7);
        }
        const Space v220_9 = intersect(constant_2,v220_2);
        const Space v220_10 = (has_head(v220_9) ? constant_3 : Space{});
        Space v220_12;
        if (!v220_10.empty()) {
          const Path v222_6 = concat_path(v219_6,v219_7_head);
          const Space v222_11 = routine_54(c, v222_6, p1, v219_7_tail);
          v220_12 = compose(v220_10,v222_11);
        }
        const Space v220_13 = unite(v220_8,v220_12);
        v219_7_result = unite(v219_7_result,v220_13);
      }
      const Space v219_7 = std::move(v219_7_result);
      v218_8 = compose(v218_5,v219_7);
    }
    const Space v218_9 = intersect(constant_2,v218_2);
    const Space v218_10 = (has_head(v218_9) ? constant_3 : Space{});
    Space v218_12;
    if (!v218_10.empty()) {
      const Path v223_6 = concat_path(p0,v217_12_head);
      Space v223_11_result;
      for (int v223_11_label = 1; v223_11_label <= 2; ++v223_11_label) {
        const Space v223_11_tail = child(v217_12_tail,v223_11_label);
        if (v223_11_tail.empty()) continue;
        const Path v223_11_head{v223_11_label};
        const Space v224_2 = singleton(v223_11_head);
        const Space v224_3 = intersect(constant_2,v224_2);
        const Space v224_4 = (has_head(v224_3) ? constant_3 : Space{});
        const Space v224_5 = subtract(constant_1,v224_4);
        Space v224_8;
        if (!v224_5.empty()) {
          const Path v225_6 = concat_path(v223_6,v223_11_head);
          const Space v225_7 = routine_53(c, v225_6, p1, v223_11_tail);
          v224_8 = compose(v224_5,v225_7);
        }
        const Space v224_9 = intersect(constant_2,v224_2);
        const Space v224_10 = (has_head(v224_9) ? constant_3 : Space{});
        Space v224_12;
        if (!v224_10.empty()) {
          const Path v226_6 = concat_path(v223_6,v223_11_head);
          const Space v226_11 = routine_22(c, v226_6, p1, v223_11_tail);
          v224_12 = compose(v224_10,v226_11);
        }
        const Space v224_13 = unite(v224_8,v224_12);
        v223_11_result = unite(v223_11_result,v224_13);
      }
      const Space v223_11 = std::move(v223_11_result);
      v218_12 = compose(v218_10,v223_11);
    }
    const Space v218_13 = unite(v218_8,v218_12);
    v217_12_result = unite(v217_12_result,v218_13);
  }
  const Space v217_12 = std::move(v217_12_result);
  return v217_12;
}

static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v227_10_result;
  for (int v227_10_label = 1; v227_10_label <= 2; ++v227_10_label) {
    const Space v227_10_tail = child(s0,v227_10_label);
    if (v227_10_tail.empty()) continue;
    const Path v227_10_head{v227_10_label};
    const Space v228_2 = singleton(v227_10_head);
    const Space v228_3 = intersect(constant_2,v228_2);
    const Space v228_4 = (has_head(v228_3) ? constant_3 : Space{});
    const Space v228_5 = compose(v228_4,v227_10_tail);
    const Path v229_6 = concat_path(p0,v227_10_head);
    const Space v228_7 = wrap(v228_5,v229_6);
    const Space v228_8 = wrap(v228_7,p1);
    const Space v228_9 = wrap(v228_8,constant_6);
    const Space v228_10 = intersect(constant_2,v228_2);
    const Space v228_11 = (has_head(v228_10) ? constant_3 : Space{});
    const Space v228_12 = subtract(constant_1,v228_11);
    Space v228_14;
    if (!v228_12.empty()) {
      Space v230_13_result;
      for (int v230_13_label = 1; v230_13_label <= 2; ++v230_13_label) {
        const Space v230_13_tail = child(v227_10_tail,v230_13_label);
        if (v230_13_tail.empty()) continue;
        const Path v230_13_head{v230_13_label};
        const Space v231_2 = singleton(v230_13_head);
        const Space v231_3 = intersect(constant_2,v231_2);
        const Space v231_4 = (has_head(v231_3) ? constant_3 : Space{});
        const Space v231_5 = subtract(constant_1,v231_4);
        Space v231_8;
        if (!v231_5.empty()) {
          const Path v232_6 = concat_path(v229_6,v230_13_head);
          const Space v232_7 = routine_53(c, v232_6, p1, v230_13_tail);
          v231_8 = compose(v231_5,v232_7);
        }
        const Space v231_9 = intersect(constant_2,v231_2);
        const Space v231_10 = (has_head(v231_9) ? constant_3 : Space{});
        Space v231_12;
        if (!v231_10.empty()) {
          const Path v233_6 = concat_path(v229_6,v230_13_head);
          const Space v233_11 = routine_54(c, v233_6, p1, v230_13_tail);
          v231_12 = compose(v231_10,v233_11);
        }
        const Space v231_13 = unite(v231_8,v231_12);
        v230_13_result = unite(v230_13_result,v231_13);
      }
      const Space v230_13 = std::move(v230_13_result);
      v228_14 = compose(v228_12,v230_13);
    }
    const Space v228_15 = unite(v228_9,v228_14);
    v227_10_result = unite(v227_10_result,v228_15);
  }
  const Space v227_10 = std::move(v227_10_result);
  return v227_10;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v234_12_result;
  for (int v234_12_label = 1; v234_12_label <= 2; ++v234_12_label) {
    const Space v234_12_tail = child(s0,v234_12_label);
    if (v234_12_tail.empty()) continue;
    const Path v234_12_head{v234_12_label};
    const Space v235_2 = singleton(v234_12_head);
    const Space v235_3 = intersect(constant_2,v235_2);
    const Space v235_4 = (has_head(v235_3) ? constant_3 : Space{});
    const Space v235_5 = subtract(constant_1,v235_4);
    Space v235_8;
    if (!v235_5.empty()) {
      const Path v236_6 = concat_path(p0,v234_12_head);
      Space v236_7_result;
      for (int v236_7_label = 1; v236_7_label <= 2; ++v236_7_label) {
        const Space v236_7_tail = child(v234_12_tail,v236_7_label);
        if (v236_7_tail.empty()) continue;
        const Path v236_7_head{v236_7_label};
        const Space v237_2 = singleton(v236_7_head);
        const Space v237_3 = intersect(constant_2,v237_2);
        const Space v237_4 = (has_head(v237_3) ? constant_3 : Space{});
        const Space v237_5 = subtract(constant_1,v237_4);
        Space v237_8;
        if (!v237_5.empty()) {
          const Path v238_6 = concat_path(v236_6,v236_7_head);
          const Space v238_7 = routine_55(c, v238_6, p1, v236_7_tail);
          v237_8 = compose(v237_5,v238_7);
        }
        const Space v237_9 = intersect(constant_2,v237_2);
        const Space v237_10 = (has_head(v237_9) ? constant_3 : Space{});
        Space v237_12;
        if (!v237_10.empty()) {
          const Path v239_6 = concat_path(v236_6,v236_7_head);
          const Space v239_11 = routine_56(c, v239_6, p1, v236_7_tail);
          v237_12 = compose(v237_10,v239_11);
        }
        const Space v237_13 = unite(v237_8,v237_12);
        v236_7_result = unite(v236_7_result,v237_13);
      }
      const Space v236_7 = std::move(v236_7_result);
      v235_8 = compose(v235_5,v236_7);
    }
    const Space v235_9 = intersect(constant_2,v235_2);
    const Space v235_10 = (has_head(v235_9) ? constant_3 : Space{});
    Space v235_12;
    if (!v235_10.empty()) {
      const Path v240_6 = concat_path(p0,v234_12_head);
      Space v240_11_result;
      for (int v240_11_label = 1; v240_11_label <= 2; ++v240_11_label) {
        const Space v240_11_tail = child(v234_12_tail,v240_11_label);
        if (v240_11_tail.empty()) continue;
        const Path v240_11_head{v240_11_label};
        const Space v241_2 = singleton(v240_11_head);
        const Space v241_3 = intersect(constant_2,v241_2);
        const Space v241_4 = (has_head(v241_3) ? constant_3 : Space{});
        const Space v241_5 = subtract(constant_1,v241_4);
        Space v241_8;
        if (!v241_5.empty()) {
          const Path v242_6 = concat_path(v240_6,v240_11_head);
          const Space v242_7 = routine_55(c, v242_6, p1, v240_11_tail);
          v241_8 = compose(v241_5,v242_7);
        }
        const Space v241_9 = intersect(constant_2,v241_2);
        const Space v241_10 = (has_head(v241_9) ? constant_3 : Space{});
        Space v241_12;
        if (!v241_10.empty()) {
          const Path v243_6 = concat_path(v240_6,v240_11_head);
          const Space v243_11 = routine_22(c, v243_6, p1, v240_11_tail);
          v241_12 = compose(v241_10,v243_11);
        }
        const Space v241_13 = unite(v241_8,v241_12);
        v240_11_result = unite(v240_11_result,v241_13);
      }
      const Space v240_11 = std::move(v240_11_result);
      v235_12 = compose(v235_10,v240_11);
    }
    const Space v235_13 = unite(v235_8,v235_12);
    v234_12_result = unite(v234_12_result,v235_13);
  }
  const Space v234_12 = std::move(v234_12_result);
  return v234_12;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v244_10_result;
  for (int v244_10_label = 1; v244_10_label <= 2; ++v244_10_label) {
    const Space v244_10_tail = child(s0,v244_10_label);
    if (v244_10_tail.empty()) continue;
    const Path v244_10_head{v244_10_label};
    const Space v245_2 = singleton(v244_10_head);
    const Space v245_3 = intersect(constant_2,v245_2);
    const Space v245_4 = (has_head(v245_3) ? constant_3 : Space{});
    const Space v245_5 = compose(v245_4,v244_10_tail);
    const Path v246_6 = concat_path(p0,v244_10_head);
    const Space v245_7 = wrap(v245_5,v246_6);
    const Space v245_8 = wrap(v245_7,p1);
    const Space v245_9 = wrap(v245_8,constant_6);
    const Space v245_10 = intersect(constant_2,v245_2);
    const Space v245_11 = (has_head(v245_10) ? constant_3 : Space{});
    const Space v245_12 = subtract(constant_1,v245_11);
    Space v245_14;
    if (!v245_12.empty()) {
      Space v247_13_result;
      for (int v247_13_label = 1; v247_13_label <= 2; ++v247_13_label) {
        const Space v247_13_tail = child(v244_10_tail,v247_13_label);
        if (v247_13_tail.empty()) continue;
        const Path v247_13_head{v247_13_label};
        const Space v248_2 = singleton(v247_13_head);
        const Space v248_3 = intersect(constant_2,v248_2);
        const Space v248_4 = (has_head(v248_3) ? constant_3 : Space{});
        const Space v248_5 = subtract(constant_1,v248_4);
        Space v248_8;
        if (!v248_5.empty()) {
          const Path v249_6 = concat_path(v246_6,v247_13_head);
          const Space v249_7 = routine_55(c, v249_6, p1, v247_13_tail);
          v248_8 = compose(v248_5,v249_7);
        }
        const Space v248_9 = intersect(constant_2,v248_2);
        const Space v248_10 = (has_head(v248_9) ? constant_3 : Space{});
        Space v248_12;
        if (!v248_10.empty()) {
          const Path v250_6 = concat_path(v246_6,v247_13_head);
          const Space v250_11 = routine_56(c, v250_6, p1, v247_13_tail);
          v248_12 = compose(v248_10,v250_11);
        }
        const Space v248_13 = unite(v248_8,v248_12);
        v247_13_result = unite(v247_13_result,v248_13);
      }
      const Space v247_13 = std::move(v247_13_result);
      v245_14 = compose(v245_12,v247_13);
    }
    const Space v245_15 = unite(v245_9,v245_14);
    v244_10_result = unite(v244_10_result,v245_15);
  }
  const Space v244_10 = std::move(v244_10_result);
  return v244_10;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v251_3 = wrap(s0,p0);
  const Space v251_4 = wrap(v251_3,p1);
  const Space v251_6 = wrap(v251_4,constant_6);
  return v251_6;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v252_12_result;
  for (int v252_12_label = 1; v252_12_label <= 2; ++v252_12_label) {
    const Space v252_12_tail = child(s0,v252_12_label);
    if (v252_12_tail.empty()) continue;
    const Path v252_12_head{v252_12_label};
    const Space v253_2 = singleton(v252_12_head);
    const Space v253_3 = intersect(constant_2,v253_2);
    const Space v253_4 = (has_head(v253_3) ? constant_3 : Space{});
    const Space v253_5 = subtract(constant_1,v253_4);
    Space v253_8;
    if (!v253_5.empty()) {
      const Path v254_6 = concat_path(p0,v252_12_head);
      Space v254_7_result;
      for (int v254_7_label = 1; v254_7_label <= 2; ++v254_7_label) {
        const Space v254_7_tail = child(v252_12_tail,v254_7_label);
        if (v254_7_tail.empty()) continue;
        const Path v254_7_head{v254_7_label};
        const Space v255_2 = singleton(v254_7_head);
        const Space v255_3 = intersect(constant_2,v255_2);
        const Space v255_4 = (has_head(v255_3) ? constant_3 : Space{});
        const Space v255_5 = subtract(constant_1,v255_4);
        Space v255_8;
        if (!v255_5.empty()) {
          const Path v256_6 = concat_path(v254_6,v254_7_head);
          const Space v256_7 = routine_57(c, v256_6, v254_7_tail, s1);
          v255_8 = compose(v255_5,v256_7);
        }
        const Space v255_9 = intersect(constant_2,v255_2);
        const Space v255_10 = (has_head(v255_9) ? constant_3 : Space{});
        Space v255_12;
        if (!v255_10.empty()) {
          const Path v257_6 = concat_path(v254_6,v254_7_head);
          const Space v257_11 = routine_58(c, v257_6, v254_7_tail, s1);
          v255_12 = compose(v255_10,v257_11);
        }
        const Space v255_13 = unite(v255_8,v255_12);
        v254_7_result = unite(v254_7_result,v255_13);
      }
      const Space v254_7 = std::move(v254_7_result);
      v253_8 = compose(v253_5,v254_7);
    }
    const Space v253_9 = intersect(constant_2,v253_2);
    const Space v253_10 = (has_head(v253_9) ? constant_3 : Space{});
    Space v253_12;
    if (!v253_10.empty()) {
      const Path v258_6 = concat_path(p0,v252_12_head);
      Space v258_11_result;
      for (int v258_11_label = 1; v258_11_label <= 2; ++v258_11_label) {
        const Space v258_11_tail = child(v252_12_tail,v258_11_label);
        if (v258_11_tail.empty()) continue;
        const Path v258_11_head{v258_11_label};
        const Space v259_2 = singleton(v258_11_head);
        const Space v259_3 = intersect(constant_2,v259_2);
        const Space v259_4 = (has_head(v259_3) ? constant_3 : Space{});
        const Space v259_5 = subtract(constant_1,v259_4);
        Space v259_8;
        if (!v259_5.empty()) {
          const Path v260_6 = concat_path(v258_6,v258_11_head);
          const Space v260_7 = routine_57(c, v260_6, v258_11_tail, s1);
          v259_8 = compose(v259_5,v260_7);
        }
        const Space v259_9 = intersect(constant_2,v259_2);
        const Space v259_10 = (has_head(v259_9) ? constant_3 : Space{});
        Space v259_12;
        if (!v259_10.empty()) {
          const Path v261_6 = concat_path(v258_6,v258_11_head);
          const Space v261_11 = routine_6(c, v261_6, v258_11_tail, s1);
          v259_12 = compose(v259_10,v261_11);
        }
        const Space v259_13 = unite(v259_8,v259_12);
        v258_11_result = unite(v258_11_result,v259_13);
      }
      const Space v258_11 = std::move(v258_11_result);
      v253_12 = compose(v253_10,v258_11);
    }
    const Space v253_13 = unite(v253_8,v253_12);
    v252_12_result = unite(v252_12_result,v253_13);
  }
  const Space v252_12 = std::move(v252_12_result);
  return v252_12;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v262_12_result;
  for (int v262_12_label = 1; v262_12_label <= 2; ++v262_12_label) {
    const Space v262_12_tail = child(s0,v262_12_label);
    if (v262_12_tail.empty()) continue;
    const Path v262_12_head{v262_12_label};
    const Space v263_2 = singleton(v262_12_head);
    const Space v263_3 = intersect(constant_2,v263_2);
    const Space v263_4 = (has_head(v263_3) ? constant_3 : Space{});
    const Space v263_5 = subtract(constant_1,v263_4);
    Space v263_8;
    if (!v263_5.empty()) {
      const Path v264_6 = concat_path(p0,v262_12_head);
      Space v264_7_result;
      for (int v264_7_label = 1; v264_7_label <= 2; ++v264_7_label) {
        const Space v264_7_tail = child(v262_12_tail,v264_7_label);
        if (v264_7_tail.empty()) continue;
        const Path v264_7_head{v264_7_label};
        const Space v265_2 = singleton(v264_7_head);
        const Space v265_3 = intersect(constant_2,v265_2);
        const Space v265_4 = (has_head(v265_3) ? constant_3 : Space{});
        const Space v265_5 = subtract(constant_1,v265_4);
        Space v265_8;
        if (!v265_5.empty()) {
          const Path v266_6 = concat_path(v264_6,v264_7_head);
          const Space v266_7 = routine_57(c, v266_6, v264_7_tail, s1);
          v265_8 = compose(v265_5,v266_7);
        }
        const Space v265_9 = intersect(constant_2,v265_2);
        const Space v265_10 = (has_head(v265_9) ? constant_3 : Space{});
        Space v265_12;
        if (!v265_10.empty()) {
          const Path v267_6 = concat_path(v264_6,v264_7_head);
          const Space v267_11 = routine_58(c, v267_6, v264_7_tail, s1);
          v265_12 = compose(v265_10,v267_11);
        }
        const Space v265_13 = unite(v265_8,v265_12);
        v264_7_result = unite(v264_7_result,v265_13);
      }
      const Space v264_7 = std::move(v264_7_result);
      v263_8 = compose(v263_5,v264_7);
    }
    const Space v263_9 = intersect(constant_2,v263_2);
    const Space v263_10 = (has_head(v263_9) ? constant_3 : Space{});
    Space v263_12;
    if (!v263_10.empty()) {
      const Path v268_6 = concat_path(p0,v262_12_head);
      Space v268_11_result;
      for (int v268_11_label = 1; v268_11_label <= 2; ++v268_11_label) {
        const Space v268_11_tail = child(v262_12_tail,v268_11_label);
        if (v268_11_tail.empty()) continue;
        const Path v268_11_head{v268_11_label};
        const Space v269_2 = singleton(v268_11_head);
        const Space v269_3 = intersect(constant_2,v269_2);
        const Space v269_4 = (has_head(v269_3) ? constant_3 : Space{});
        const Space v269_5 = subtract(constant_1,v269_4);
        Space v269_7;
        if (!v269_5.empty()) {
          const Space v270_6 = routine_25(c, v268_11_head, v268_6, v268_11_tail, s1);
          v269_7 = compose(v269_5,v270_6);
        }
        const Space v269_8 = intersect(constant_2,v269_2);
        const Space v269_9 = (has_head(v269_8) ? constant_3 : Space{});
        Space v269_11;
        if (!v269_9.empty()) {
          const Space v271_10 = routine_26(c, v268_11_head, v268_6, v268_11_tail, s1);
          v269_11 = compose(v269_9,v271_10);
        }
        const Space v269_12 = unite(v269_7,v269_11);
        v268_11_result = unite(v268_11_result,v269_12);
      }
      const Space v268_11 = std::move(v268_11_result);
      v263_12 = compose(v263_10,v268_11);
    }
    const Space v263_13 = unite(v263_8,v263_12);
    v262_12_result = unite(v262_12_result,v263_13);
  }
  const Space v262_12 = std::move(v262_12_result);
  return v262_12;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v272_13_result;
  for (int v272_13_label = 1; v272_13_label <= 2; ++v272_13_label) {
    const Space v272_13_tail = child(s0,v272_13_label);
    if (v272_13_tail.empty()) continue;
    const Path v272_13_head{v272_13_label};
    const Space v273_2 = singleton(v272_13_head);
    const Space v273_3 = intersect(constant_2,v273_2);
    const Space v273_4 = (has_head(v273_3) ? constant_3 : Space{});
    const Space v273_5 = subtract(constant_1,v273_4);
    Space v273_8;
    if (!v273_5.empty()) {
      const Path v274_6 = concat_path(p0,v272_13_head);
      Space v274_7_result;
      for (int v274_7_label = 1; v274_7_label <= 2; ++v274_7_label) {
        const Space v274_7_tail = child(v272_13_tail,v274_7_label);
        if (v274_7_tail.empty()) continue;
        const Path v274_7_head{v274_7_label};
        const Space v275_2 = singleton(v274_7_head);
        const Space v275_3 = intersect(constant_2,v275_2);
        const Space v275_4 = (has_head(v275_3) ? constant_3 : Space{});
        const Space v275_5 = subtract(constant_1,v275_4);
        Space v275_8;
        if (!v275_5.empty()) {
          const Path v276_6 = concat_path(v274_6,v274_7_head);
          const Space v276_7 = routine_59(c, v276_6, p1, v274_7_tail, s1);
          v275_8 = compose(v275_5,v276_7);
        }
        const Space v275_9 = intersect(constant_2,v275_2);
        const Space v275_10 = (has_head(v275_9) ? constant_3 : Space{});
        Space v275_12;
        if (!v275_10.empty()) {
          const Path v277_6 = concat_path(v274_6,v274_7_head);
          const Space v277_11 = routine_60(c, v277_6, p1, v274_7_tail, s1);
          v275_12 = compose(v275_10,v277_11);
        }
        const Space v275_13 = unite(v275_8,v275_12);
        v274_7_result = unite(v274_7_result,v275_13);
      }
      const Space v274_7 = std::move(v274_7_result);
      v273_8 = compose(v273_5,v274_7);
    }
    const Space v273_9 = intersect(constant_2,v273_2);
    const Space v273_10 = (has_head(v273_9) ? constant_3 : Space{});
    Space v273_12;
    if (!v273_10.empty()) {
      const Path v278_6 = concat_path(p0,v272_13_head);
      Space v278_11_result;
      for (int v278_11_label = 1; v278_11_label <= 2; ++v278_11_label) {
        const Space v278_11_tail = child(v272_13_tail,v278_11_label);
        if (v278_11_tail.empty()) continue;
        const Path v278_11_head{v278_11_label};
        const Space v279_2 = singleton(v278_11_head);
        const Space v279_3 = intersect(constant_2,v279_2);
        const Space v279_4 = (has_head(v279_3) ? constant_3 : Space{});
        const Space v279_5 = subtract(constant_1,v279_4);
        Space v279_8;
        if (!v279_5.empty()) {
          const Path v280_6 = concat_path(v278_6,v278_11_head);
          const Space v280_7 = routine_59(c, v280_6, p1, v278_11_tail, s1);
          v279_8 = compose(v279_5,v280_7);
        }
        const Space v279_9 = intersect(constant_2,v279_2);
        const Space v279_10 = (has_head(v279_9) ? constant_3 : Space{});
        Space v279_12;
        if (!v279_10.empty()) {
          const Path v281_6 = concat_path(v278_6,v278_11_head);
          const Space v281_11 = routine_29(c, v281_6, p1, v278_11_tail, s1);
          v279_12 = compose(v279_10,v281_11);
        }
        const Space v279_13 = unite(v279_8,v279_12);
        v278_11_result = unite(v278_11_result,v279_13);
      }
      const Space v278_11 = std::move(v278_11_result);
      v273_12 = compose(v273_10,v278_11);
    }
    const Space v273_13 = unite(v273_8,v273_12);
    v272_13_result = unite(v272_13_result,v273_13);
  }
  const Space v272_13 = std::move(v272_13_result);
  return v272_13;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v282_8 = unwrap(s1,constant_5);
  const Space v282_10 = unwrap(v282_8,constant_6);
  const Space v282_11 = unwrap(v282_10,p0);
  Space v282_18_result;
  for (int v282_18_label = 1; v282_18_label <= 2; ++v282_18_label) {
    const Space v282_18_tail = child(s0,v282_18_label);
    if (v282_18_tail.empty()) continue;
    const Path v282_18_head{v282_18_label};
    const Space v283_2 = singleton(v282_18_head);
    const Space v283_3 = intersect(constant_2,v283_2);
    const Space v283_4 = (has_head(v283_3) ? constant_3 : Space{});
    const Space v283_5 = subtract(constant_1,v283_4);
    Space v283_8;
    if (!v283_5.empty()) {
      const Path v284_6 = concat_path(p0,v282_18_head);
      Space v284_7_result;
      for (int v284_7_label = 1; v284_7_label <= 2; ++v284_7_label) {
        const Space v284_7_tail = child(v282_18_tail,v284_7_label);
        if (v284_7_tail.empty()) continue;
        const Path v284_7_head{v284_7_label};
        const Space v285_2 = singleton(v284_7_head);
        const Space v285_3 = intersect(constant_2,v285_2);
        const Space v285_4 = (has_head(v285_3) ? constant_3 : Space{});
        const Space v285_5 = subtract(constant_1,v285_4);
        Space v285_8;
        if (!v285_5.empty()) {
          const Path v286_6 = concat_path(v284_6,v284_7_head);
          const Space v286_7 = routine_59(c, v286_6, p1, v284_7_tail, s1);
          v285_8 = compose(v285_5,v286_7);
        }
        const Space v285_9 = intersect(constant_2,v285_2);
        const Space v285_10 = (has_head(v285_9) ? constant_3 : Space{});
        Space v285_12;
        if (!v285_10.empty()) {
          const Path v287_6 = concat_path(v284_6,v284_7_head);
          const Space v287_11 = routine_60(c, v287_6, p1, v284_7_tail, s1);
          v285_12 = compose(v285_10,v287_11);
        }
        const Space v285_13 = unite(v285_8,v285_12);
        v284_7_result = unite(v284_7_result,v285_13);
      }
      const Space v284_7 = std::move(v284_7_result);
      v283_8 = compose(v283_5,v284_7);
    }
    const Space v283_9 = intersect(constant_2,v283_2);
    const Space v283_10 = (has_head(v283_9) ? constant_3 : Space{});
    Space v283_13;
    if (!v283_10.empty()) {
      const Space v288_11 = unwrap(v282_11,v282_18_head);
      Space v288_12_result;
      for (int v288_12_label = 1; v288_12_label <= 2; ++v288_12_label) {
        const Space v288_12_tail = child(v288_11,v288_12_label);
        if (v288_12_tail.empty()) continue;
        const Path v288_12_head{v288_12_label};
        const Space v289_2 = singleton(v288_12_head);
        const Space v289_3 = intersect(constant_2,v289_2);
        const Space v289_4 = (has_head(v289_3) ? constant_3 : Space{});
        const Space v289_5 = subtract(constant_1,v289_4);
        Space v289_7;
        if (!v289_5.empty()) {
          const Space v290_6 = routine_61(c, v288_12_head, p1, v288_12_tail);
          v289_7 = compose(v289_5,v290_6);
        }
        const Space v289_8 = intersect(constant_2,v289_2);
        const Space v289_9 = (has_head(v289_8) ? constant_3 : Space{});
        Space v289_11;
        if (!v289_9.empty()) {
          const Space v291_10 = routine_62(c, v288_12_head, p1, v288_12_tail);
          v289_11 = compose(v289_9,v291_10);
        }
        const Space v289_12 = unite(v289_7,v289_11);
        v288_12_result = unite(v288_12_result,v289_12);
      }
      const Space v288_12 = std::move(v288_12_result);
      v283_13 = compose(v283_10,v288_12);
    }
    const Space v283_14 = unite(v283_8,v283_13);
    v282_18_result = unite(v282_18_result,v283_14);
  }
  const Space v282_18 = std::move(v282_18_result);
  return v282_18;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v292_13_result;
  for (int v292_13_label = 1; v292_13_label <= 2; ++v292_13_label) {
    const Space v292_13_tail = child(s0,v292_13_label);
    if (v292_13_tail.empty()) continue;
    const Path v292_13_head{v292_13_label};
    const Space v293_2 = singleton(v292_13_head);
    const Space v293_3 = intersect(constant_2,v293_2);
    const Space v293_4 = (has_head(v293_3) ? constant_3 : Space{});
    const Space v293_5 = subtract(constant_1,v293_4);
    Space v293_8;
    if (!v293_5.empty()) {
      const Path v294_6 = concat_path(p0,v292_13_head);
      Space v294_7_result;
      for (int v294_7_label = 1; v294_7_label <= 2; ++v294_7_label) {
        const Space v294_7_tail = child(v292_13_tail,v294_7_label);
        if (v294_7_tail.empty()) continue;
        const Path v294_7_head{v294_7_label};
        const Space v295_2 = singleton(v294_7_head);
        const Space v295_3 = intersect(constant_2,v295_2);
        const Space v295_4 = (has_head(v295_3) ? constant_3 : Space{});
        const Space v295_5 = subtract(constant_1,v295_4);
        Space v295_8;
        if (!v295_5.empty()) {
          const Path v296_6 = concat_path(v294_6,v294_7_head);
          const Space v296_7 = routine_63(c, v296_6, p1, v294_7_tail, s1);
          v295_8 = compose(v295_5,v296_7);
        }
        const Space v295_9 = intersect(constant_2,v295_2);
        const Space v295_10 = (has_head(v295_9) ? constant_3 : Space{});
        Space v295_12;
        if (!v295_10.empty()) {
          const Path v297_6 = concat_path(v294_6,v294_7_head);
          const Space v297_11 = routine_64(c, v297_6, p1, v294_7_tail, s1);
          v295_12 = compose(v295_10,v297_11);
        }
        const Space v295_13 = unite(v295_8,v295_12);
        v294_7_result = unite(v294_7_result,v295_13);
      }
      const Space v294_7 = std::move(v294_7_result);
      v293_8 = compose(v293_5,v294_7);
    }
    const Space v293_9 = intersect(constant_2,v293_2);
    const Space v293_10 = (has_head(v293_9) ? constant_3 : Space{});
    Space v293_12;
    if (!v293_10.empty()) {
      const Path v298_6 = concat_path(p0,v292_13_head);
      Space v298_11_result;
      for (int v298_11_label = 1; v298_11_label <= 2; ++v298_11_label) {
        const Space v298_11_tail = child(v292_13_tail,v298_11_label);
        if (v298_11_tail.empty()) continue;
        const Path v298_11_head{v298_11_label};
        const Space v299_2 = singleton(v298_11_head);
        const Space v299_3 = intersect(constant_2,v299_2);
        const Space v299_4 = (has_head(v299_3) ? constant_3 : Space{});
        const Space v299_5 = subtract(constant_1,v299_4);
        Space v299_8;
        if (!v299_5.empty()) {
          const Path v300_6 = concat_path(v298_6,v298_11_head);
          const Space v300_7 = routine_63(c, v300_6, p1, v298_11_tail, s1);
          v299_8 = compose(v299_5,v300_7);
        }
        const Space v299_9 = intersect(constant_2,v299_2);
        const Space v299_10 = (has_head(v299_9) ? constant_3 : Space{});
        Space v299_12;
        if (!v299_10.empty()) {
          const Path v301_6 = concat_path(v298_6,v298_11_head);
          const Space v301_11 = routine_29(c, v301_6, p1, v298_11_tail, s1);
          v299_12 = compose(v299_10,v301_11);
        }
        const Space v299_13 = unite(v299_8,v299_12);
        v298_11_result = unite(v298_11_result,v299_13);
      }
      const Space v298_11 = std::move(v298_11_result);
      v293_12 = compose(v293_10,v298_11);
    }
    const Space v293_13 = unite(v293_8,v293_12);
    v292_13_result = unite(v292_13_result,v293_13);
  }
  const Space v292_13 = std::move(v292_13_result);
  return v292_13;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v302_8 = unwrap(s1,constant_5);
  const Space v302_10 = unwrap(v302_8,constant_6);
  const Space v302_11 = unwrap(v302_10,p0);
  Space v302_18_result;
  for (int v302_18_label = 1; v302_18_label <= 2; ++v302_18_label) {
    const Space v302_18_tail = child(s0,v302_18_label);
    if (v302_18_tail.empty()) continue;
    const Path v302_18_head{v302_18_label};
    const Space v303_2 = singleton(v302_18_head);
    const Space v303_3 = intersect(constant_2,v303_2);
    const Space v303_4 = (has_head(v303_3) ? constant_3 : Space{});
    const Space v303_5 = subtract(constant_1,v303_4);
    Space v303_8;
    if (!v303_5.empty()) {
      const Path v304_6 = concat_path(p0,v302_18_head);
      Space v304_7_result;
      for (int v304_7_label = 1; v304_7_label <= 2; ++v304_7_label) {
        const Space v304_7_tail = child(v302_18_tail,v304_7_label);
        if (v304_7_tail.empty()) continue;
        const Path v304_7_head{v304_7_label};
        const Space v305_2 = singleton(v304_7_head);
        const Space v305_3 = intersect(constant_2,v305_2);
        const Space v305_4 = (has_head(v305_3) ? constant_3 : Space{});
        const Space v305_5 = subtract(constant_1,v305_4);
        Space v305_8;
        if (!v305_5.empty()) {
          const Path v306_6 = concat_path(v304_6,v304_7_head);
          const Space v306_7 = routine_63(c, v306_6, p1, v304_7_tail, s1);
          v305_8 = compose(v305_5,v306_7);
        }
        const Space v305_9 = intersect(constant_2,v305_2);
        const Space v305_10 = (has_head(v305_9) ? constant_3 : Space{});
        Space v305_12;
        if (!v305_10.empty()) {
          const Path v307_6 = concat_path(v304_6,v304_7_head);
          const Space v307_11 = routine_64(c, v307_6, p1, v304_7_tail, s1);
          v305_12 = compose(v305_10,v307_11);
        }
        const Space v305_13 = unite(v305_8,v305_12);
        v304_7_result = unite(v304_7_result,v305_13);
      }
      const Space v304_7 = std::move(v304_7_result);
      v303_8 = compose(v303_5,v304_7);
    }
    const Space v303_9 = intersect(constant_2,v303_2);
    const Space v303_10 = (has_head(v303_9) ? constant_3 : Space{});
    Space v303_13;
    if (!v303_10.empty()) {
      const Space v308_11 = unwrap(v302_11,v302_18_head);
      Space v308_12_result;
      for (int v308_12_label = 1; v308_12_label <= 2; ++v308_12_label) {
        const Space v308_12_tail = child(v308_11,v308_12_label);
        if (v308_12_tail.empty()) continue;
        const Path v308_12_head{v308_12_label};
        const Space v309_2 = singleton(v308_12_head);
        const Space v309_3 = intersect(constant_2,v309_2);
        const Space v309_4 = (has_head(v309_3) ? constant_3 : Space{});
        const Space v309_5 = subtract(constant_1,v309_4);
        Space v309_7;
        if (!v309_5.empty()) {
          const Space v310_6 = routine_61(c, v308_12_head, p1, v308_12_tail);
          v309_7 = compose(v309_5,v310_6);
        }
        const Space v309_8 = intersect(constant_2,v309_2);
        const Space v309_9 = (has_head(v309_8) ? constant_3 : Space{});
        Space v309_11;
        if (!v309_9.empty()) {
          const Space v311_10 = routine_62(c, v308_12_head, p1, v308_12_tail);
          v309_11 = compose(v309_9,v311_10);
        }
        const Space v309_12 = unite(v309_7,v309_11);
        v308_12_result = unite(v308_12_result,v309_12);
      }
      const Space v308_12 = std::move(v308_12_result);
      v303_13 = compose(v303_10,v308_12);
    }
    const Space v303_14 = unite(v303_8,v303_13);
    v302_18_result = unite(v302_18_result,v303_14);
  }
  const Space v302_18 = std::move(v302_18_result);
  return v302_18;
}

static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v312_5 = unwrap(s1,constant_5);
  const Space v312_7 = unwrap(v312_5,constant_6);
  const Space v312_8 = unwrap(v312_7,p0);
  Space v312_18_result;
  for (int v312_18_label = 1; v312_18_label <= 2; ++v312_18_label) {
    const Space v312_18_tail = child(v312_8,v312_18_label);
    if (v312_18_tail.empty()) continue;
    const Path v312_18_head{v312_18_label};
    const Space v313_2 = singleton(v312_18_head);
    const Space v313_3 = intersect(constant_2,v313_2);
    const Space v313_4 = (has_head(v313_3) ? constant_3 : Space{});
    const Space v313_5 = subtract(constant_1,v313_4);
    Space v313_7;
    if (!v313_5.empty()) {
      Space v314_6_result;
      for (int v314_6_label = 1; v314_6_label <= 2; ++v314_6_label) {
        const Space v314_6_tail = child(v312_18_tail,v314_6_label);
        if (v314_6_tail.empty()) continue;
        const Path v314_6_head{v314_6_label};
        const Space v315_2 = singleton(v314_6_head);
        const Space v315_3 = intersect(constant_2,v315_2);
        const Space v315_4 = (has_head(v315_3) ? constant_3 : Space{});
        const Space v315_5 = subtract(constant_1,v315_4);
        Space v315_8;
        if (!v315_5.empty()) {
          const Path v316_6 = concat_path(v312_18_head,v314_6_head);
          const Space v316_7 = routine_65(c, v316_6, p1, v314_6_tail);
          v315_8 = compose(v315_5,v316_7);
        }
        const Space v315_9 = intersect(constant_2,v315_2);
        const Space v315_10 = (has_head(v315_9) ? constant_3 : Space{});
        Space v315_12;
        if (!v315_10.empty()) {
          const Path v317_6 = concat_path(v312_18_head,v314_6_head);
          const Space v317_11 = routine_66(c, v317_6, p1, v314_6_tail);
          v315_12 = compose(v315_10,v317_11);
        }
        const Space v315_13 = unite(v315_8,v315_12);
        v314_6_result = unite(v314_6_result,v315_13);
      }
      const Space v314_6 = std::move(v314_6_result);
      v313_7 = compose(v313_5,v314_6);
    }
    const Space v313_8 = intersect(constant_2,v313_2);
    const Space v313_9 = (has_head(v313_8) ? constant_3 : Space{});
    Space v313_11;
    if (!v313_9.empty()) {
      Space v318_10_result;
      for (int v318_10_label = 1; v318_10_label <= 2; ++v318_10_label) {
        const Space v318_10_tail = child(v312_18_tail,v318_10_label);
        if (v318_10_tail.empty()) continue;
        const Path v318_10_head{v318_10_label};
        const Space v319_2 = singleton(v318_10_head);
        const Space v319_3 = intersect(constant_2,v319_2);
        const Space v319_4 = (has_head(v319_3) ? constant_3 : Space{});
        const Space v319_5 = subtract(constant_1,v319_4);
        Space v319_8;
        if (!v319_5.empty()) {
          const Path v320_6 = concat_path(v312_18_head,v318_10_head);
          const Space v320_7 = routine_65(c, v320_6, p1, v318_10_tail);
          v319_8 = compose(v319_5,v320_7);
        }
        const Space v319_9 = intersect(constant_2,v319_2);
        const Space v319_10 = (has_head(v319_9) ? constant_3 : Space{});
        Space v319_12;
        if (!v319_10.empty()) {
          const Path v321_6 = concat_path(v312_18_head,v318_10_head);
          const Space v321_11 = routine_67(c, v321_6, p1, v318_10_tail);
          v319_12 = compose(v319_10,v321_11);
        }
        const Space v319_13 = unite(v319_8,v319_12);
        v318_10_result = unite(v318_10_result,v319_13);
      }
      const Space v318_10 = std::move(v318_10_result);
      v313_11 = compose(v313_9,v318_10);
    }
    const Space v313_12 = unite(v313_7,v313_11);
    v312_18_result = unite(v312_18_result,v313_12);
  }
  const Space v312_18 = std::move(v312_18_result);
  return v312_18;
}

static Space routine_30(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v322_12_result;
  for (int v322_12_label = 1; v322_12_label <= 2; ++v322_12_label) {
    const Space v322_12_tail = child(s0,v322_12_label);
    if (v322_12_tail.empty()) continue;
    const Path v322_12_head{v322_12_label};
    const Space v323_2 = singleton(v322_12_head);
    const Space v323_3 = intersect(constant_2,v323_2);
    const Space v323_4 = (has_head(v323_3) ? constant_3 : Space{});
    const Space v323_5 = subtract(constant_1,v323_4);
    Space v323_8;
    if (!v323_5.empty()) {
      const Path v324_6 = concat_path(p0,v322_12_head);
      Space v324_7_result;
      for (int v324_7_label = 1; v324_7_label <= 2; ++v324_7_label) {
        const Space v324_7_tail = child(v322_12_tail,v324_7_label);
        if (v324_7_tail.empty()) continue;
        const Path v324_7_head{v324_7_label};
        const Space v325_2 = singleton(v324_7_head);
        const Space v325_3 = intersect(constant_2,v325_2);
        const Space v325_4 = (has_head(v325_3) ? constant_3 : Space{});
        const Space v325_5 = subtract(constant_1,v325_4);
        Space v325_8;
        if (!v325_5.empty()) {
          const Path v326_6 = concat_path(v324_6,v324_7_head);
          const Space v326_7 = routine_68(c, v326_6, v324_7_tail, s1);
          v325_8 = compose(v325_5,v326_7);
        }
        const Space v325_9 = intersect(constant_2,v325_2);
        const Space v325_10 = (has_head(v325_9) ? constant_3 : Space{});
        Space v325_12;
        if (!v325_10.empty()) {
          const Path v327_6 = concat_path(v324_6,v324_7_head);
          const Space v327_11 = routine_69(c, v327_6, v324_7_tail, s1);
          v325_12 = compose(v325_10,v327_11);
        }
        const Space v325_13 = unite(v325_8,v325_12);
        v324_7_result = unite(v324_7_result,v325_13);
      }
      const Space v324_7 = std::move(v324_7_result);
      v323_8 = compose(v323_5,v324_7);
    }
    const Space v323_9 = intersect(constant_2,v323_2);
    const Space v323_10 = (has_head(v323_9) ? constant_3 : Space{});
    Space v323_12;
    if (!v323_10.empty()) {
      const Path v328_6 = concat_path(p0,v322_12_head);
      Space v328_11_result;
      for (int v328_11_label = 1; v328_11_label <= 2; ++v328_11_label) {
        const Space v328_11_tail = child(v322_12_tail,v328_11_label);
        if (v328_11_tail.empty()) continue;
        const Path v328_11_head{v328_11_label};
        const Space v329_2 = singleton(v328_11_head);
        const Space v329_3 = intersect(constant_2,v329_2);
        const Space v329_4 = (has_head(v329_3) ? constant_3 : Space{});
        const Space v329_5 = subtract(constant_1,v329_4);
        Space v329_8;
        if (!v329_5.empty()) {
          const Path v330_6 = concat_path(v328_6,v328_11_head);
          const Space v330_7 = routine_68(c, v330_6, v328_11_tail, s1);
          v329_8 = compose(v329_5,v330_7);
        }
        const Space v329_9 = intersect(constant_2,v329_2);
        const Space v329_10 = (has_head(v329_9) ? constant_3 : Space{});
        Space v329_12;
        if (!v329_10.empty()) {
          const Path v331_6 = concat_path(v328_6,v328_11_head);
          const Space v331_11 = routine_9(c, v331_6, v328_11_tail, s1);
          v329_12 = compose(v329_10,v331_11);
        }
        const Space v329_13 = unite(v329_8,v329_12);
        v328_11_result = unite(v328_11_result,v329_13);
      }
      const Space v328_11 = std::move(v328_11_result);
      v323_12 = compose(v323_10,v328_11);
    }
    const Space v323_13 = unite(v323_8,v323_12);
    v322_12_result = unite(v322_12_result,v323_13);
  }
  const Space v322_12 = std::move(v322_12_result);
  return v322_12;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v332_12_result;
  for (int v332_12_label = 1; v332_12_label <= 2; ++v332_12_label) {
    const Space v332_12_tail = child(s0,v332_12_label);
    if (v332_12_tail.empty()) continue;
    const Path v332_12_head{v332_12_label};
    const Space v333_2 = singleton(v332_12_head);
    const Space v333_3 = intersect(constant_2,v333_2);
    const Space v333_4 = (has_head(v333_3) ? constant_3 : Space{});
    const Space v333_5 = subtract(constant_1,v333_4);
    Space v333_8;
    if (!v333_5.empty()) {
      const Path v334_6 = concat_path(p0,v332_12_head);
      Space v334_7_result;
      for (int v334_7_label = 1; v334_7_label <= 2; ++v334_7_label) {
        const Space v334_7_tail = child(v332_12_tail,v334_7_label);
        if (v334_7_tail.empty()) continue;
        const Path v334_7_head{v334_7_label};
        const Space v335_2 = singleton(v334_7_head);
        const Space v335_3 = intersect(constant_2,v335_2);
        const Space v335_4 = (has_head(v335_3) ? constant_3 : Space{});
        const Space v335_5 = subtract(constant_1,v335_4);
        Space v335_8;
        if (!v335_5.empty()) {
          const Path v336_6 = concat_path(v334_6,v334_7_head);
          const Space v336_7 = routine_68(c, v336_6, v334_7_tail, s1);
          v335_8 = compose(v335_5,v336_7);
        }
        const Space v335_9 = intersect(constant_2,v335_2);
        const Space v335_10 = (has_head(v335_9) ? constant_3 : Space{});
        Space v335_12;
        if (!v335_10.empty()) {
          const Path v337_6 = concat_path(v334_6,v334_7_head);
          const Space v337_11 = routine_69(c, v337_6, v334_7_tail, s1);
          v335_12 = compose(v335_10,v337_11);
        }
        const Space v335_13 = unite(v335_8,v335_12);
        v334_7_result = unite(v334_7_result,v335_13);
      }
      const Space v334_7 = std::move(v334_7_result);
      v333_8 = compose(v333_5,v334_7);
    }
    const Space v333_9 = intersect(constant_2,v333_2);
    const Space v333_10 = (has_head(v333_9) ? constant_3 : Space{});
    Space v333_12;
    if (!v333_10.empty()) {
      const Path v338_6 = concat_path(p0,v332_12_head);
      Space v338_11_result;
      for (int v338_11_label = 1; v338_11_label <= 2; ++v338_11_label) {
        const Space v338_11_tail = child(v332_12_tail,v338_11_label);
        if (v338_11_tail.empty()) continue;
        const Path v338_11_head{v338_11_label};
        const Space v339_2 = singleton(v338_11_head);
        const Space v339_3 = intersect(constant_2,v339_2);
        const Space v339_4 = (has_head(v339_3) ? constant_3 : Space{});
        const Space v339_5 = subtract(constant_1,v339_4);
        Space v339_7;
        if (!v339_5.empty()) {
          const Space v340_6 = routine_32(c, v338_11_head, v338_6, v338_11_tail, s1);
          v339_7 = compose(v339_5,v340_6);
        }
        const Space v339_8 = intersect(constant_2,v339_2);
        const Space v339_9 = (has_head(v339_8) ? constant_3 : Space{});
        Space v339_11;
        if (!v339_9.empty()) {
          const Space v341_10 = routine_33(c, v338_11_head, v338_6, v338_11_tail, s1);
          v339_11 = compose(v339_9,v341_10);
        }
        const Space v339_12 = unite(v339_7,v339_11);
        v338_11_result = unite(v338_11_result,v339_12);
      }
      const Space v338_11 = std::move(v338_11_result);
      v333_12 = compose(v333_10,v338_11);
    }
    const Space v333_13 = unite(v333_8,v333_12);
    v332_12_result = unite(v332_12_result,v333_13);
  }
  const Space v332_12 = std::move(v332_12_result);
  return v332_12;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v342_13_result;
  for (int v342_13_label = 1; v342_13_label <= 2; ++v342_13_label) {
    const Space v342_13_tail = child(s0,v342_13_label);
    if (v342_13_tail.empty()) continue;
    const Path v342_13_head{v342_13_label};
    const Space v343_2 = singleton(v342_13_head);
    const Space v343_3 = intersect(constant_2,v343_2);
    const Space v343_4 = (has_head(v343_3) ? constant_3 : Space{});
    const Space v343_5 = subtract(constant_1,v343_4);
    Space v343_8;
    if (!v343_5.empty()) {
      const Path v344_6 = concat_path(p0,v342_13_head);
      Space v344_7_result;
      for (int v344_7_label = 1; v344_7_label <= 2; ++v344_7_label) {
        const Space v344_7_tail = child(v342_13_tail,v344_7_label);
        if (v344_7_tail.empty()) continue;
        const Path v344_7_head{v344_7_label};
        const Space v345_2 = singleton(v344_7_head);
        const Space v345_3 = intersect(constant_2,v345_2);
        const Space v345_4 = (has_head(v345_3) ? constant_3 : Space{});
        const Space v345_5 = subtract(constant_1,v345_4);
        Space v345_8;
        if (!v345_5.empty()) {
          const Path v346_6 = concat_path(v344_6,v344_7_head);
          const Space v346_7 = routine_70(c, v346_6, p1, v344_7_tail, s1);
          v345_8 = compose(v345_5,v346_7);
        }
        const Space v345_9 = intersect(constant_2,v345_2);
        const Space v345_10 = (has_head(v345_9) ? constant_3 : Space{});
        Space v345_12;
        if (!v345_10.empty()) {
          const Path v347_6 = concat_path(v344_6,v344_7_head);
          const Space v347_11 = routine_71(c, v347_6, p1, v344_7_tail, s1);
          v345_12 = compose(v345_10,v347_11);
        }
        const Space v345_13 = unite(v345_8,v345_12);
        v344_7_result = unite(v344_7_result,v345_13);
      }
      const Space v344_7 = std::move(v344_7_result);
      v343_8 = compose(v343_5,v344_7);
    }
    const Space v343_9 = intersect(constant_2,v343_2);
    const Space v343_10 = (has_head(v343_9) ? constant_3 : Space{});
    Space v343_12;
    if (!v343_10.empty()) {
      const Path v348_6 = concat_path(p0,v342_13_head);
      Space v348_11_result;
      for (int v348_11_label = 1; v348_11_label <= 2; ++v348_11_label) {
        const Space v348_11_tail = child(v342_13_tail,v348_11_label);
        if (v348_11_tail.empty()) continue;
        const Path v348_11_head{v348_11_label};
        const Space v349_2 = singleton(v348_11_head);
        const Space v349_3 = intersect(constant_2,v349_2);
        const Space v349_4 = (has_head(v349_3) ? constant_3 : Space{});
        const Space v349_5 = subtract(constant_1,v349_4);
        Space v349_8;
        if (!v349_5.empty()) {
          const Path v350_6 = concat_path(v348_6,v348_11_head);
          const Space v350_7 = routine_70(c, v350_6, p1, v348_11_tail, s1);
          v349_8 = compose(v349_5,v350_7);
        }
        const Space v349_9 = intersect(constant_2,v349_2);
        const Space v349_10 = (has_head(v349_9) ? constant_3 : Space{});
        Space v349_12;
        if (!v349_10.empty()) {
          const Path v351_6 = concat_path(v348_6,v348_11_head);
          const Space v351_11 = routine_36(c, v351_6, p1, v348_11_tail, s1);
          v349_12 = compose(v349_10,v351_11);
        }
        const Space v349_13 = unite(v349_8,v349_12);
        v348_11_result = unite(v348_11_result,v349_13);
      }
      const Space v348_11 = std::move(v348_11_result);
      v343_12 = compose(v343_10,v348_11);
    }
    const Space v343_13 = unite(v343_8,v343_12);
    v342_13_result = unite(v342_13_result,v343_13);
  }
  const Space v342_13 = std::move(v342_13_result);
  return v342_13;
}

static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v352_8 = unwrap(s1,constant_4);
  const Space v352_10 = unwrap(v352_8,constant_6);
  const Space v352_11 = unwrap(v352_10,p0);
  Space v352_18_result;
  for (int v352_18_label = 1; v352_18_label <= 2; ++v352_18_label) {
    const Space v352_18_tail = child(s0,v352_18_label);
    if (v352_18_tail.empty()) continue;
    const Path v352_18_head{v352_18_label};
    const Space v353_2 = singleton(v352_18_head);
    const Space v353_3 = intersect(constant_2,v353_2);
    const Space v353_4 = (has_head(v353_3) ? constant_3 : Space{});
    const Space v353_5 = subtract(constant_1,v353_4);
    Space v353_8;
    if (!v353_5.empty()) {
      const Path v354_6 = concat_path(p0,v352_18_head);
      Space v354_7_result;
      for (int v354_7_label = 1; v354_7_label <= 2; ++v354_7_label) {
        const Space v354_7_tail = child(v352_18_tail,v354_7_label);
        if (v354_7_tail.empty()) continue;
        const Path v354_7_head{v354_7_label};
        const Space v355_2 = singleton(v354_7_head);
        const Space v355_3 = intersect(constant_2,v355_2);
        const Space v355_4 = (has_head(v355_3) ? constant_3 : Space{});
        const Space v355_5 = subtract(constant_1,v355_4);
        Space v355_8;
        if (!v355_5.empty()) {
          const Path v356_6 = concat_path(v354_6,v354_7_head);
          const Space v356_7 = routine_70(c, v356_6, p1, v354_7_tail, s1);
          v355_8 = compose(v355_5,v356_7);
        }
        const Space v355_9 = intersect(constant_2,v355_2);
        const Space v355_10 = (has_head(v355_9) ? constant_3 : Space{});
        Space v355_12;
        if (!v355_10.empty()) {
          const Path v357_6 = concat_path(v354_6,v354_7_head);
          const Space v357_11 = routine_71(c, v357_6, p1, v354_7_tail, s1);
          v355_12 = compose(v355_10,v357_11);
        }
        const Space v355_13 = unite(v355_8,v355_12);
        v354_7_result = unite(v354_7_result,v355_13);
      }
      const Space v354_7 = std::move(v354_7_result);
      v353_8 = compose(v353_5,v354_7);
    }
    const Space v353_9 = intersect(constant_2,v353_2);
    const Space v353_10 = (has_head(v353_9) ? constant_3 : Space{});
    Space v353_13;
    if (!v353_10.empty()) {
      const Space v358_11 = unwrap(v352_11,v352_18_head);
      Space v358_12_result;
      for (int v358_12_label = 1; v358_12_label <= 2; ++v358_12_label) {
        const Space v358_12_tail = child(v358_11,v358_12_label);
        if (v358_12_tail.empty()) continue;
        const Path v358_12_head{v358_12_label};
        const Space v359_2 = singleton(v358_12_head);
        const Space v359_3 = intersect(constant_2,v359_2);
        const Space v359_4 = (has_head(v359_3) ? constant_3 : Space{});
        const Space v359_5 = subtract(constant_1,v359_4);
        Space v359_7;
        if (!v359_5.empty()) {
          const Space v360_6 = routine_72(c, v358_12_head, p1, v358_12_tail);
          v359_7 = compose(v359_5,v360_6);
        }
        const Space v359_8 = intersect(constant_2,v359_2);
        const Space v359_9 = (has_head(v359_8) ? constant_3 : Space{});
        Space v359_11;
        if (!v359_9.empty()) {
          const Space v361_10 = routine_73(c, v358_12_head, p1, v358_12_tail);
          v359_11 = compose(v359_9,v361_10);
        }
        const Space v359_12 = unite(v359_7,v359_11);
        v358_12_result = unite(v358_12_result,v359_12);
      }
      const Space v358_12 = std::move(v358_12_result);
      v353_13 = compose(v353_10,v358_12);
    }
    const Space v353_14 = unite(v353_8,v353_13);
    v352_18_result = unite(v352_18_result,v353_14);
  }
  const Space v352_18 = std::move(v352_18_result);
  return v352_18;
}

static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v362_13_result;
  for (int v362_13_label = 1; v362_13_label <= 2; ++v362_13_label) {
    const Space v362_13_tail = child(s0,v362_13_label);
    if (v362_13_tail.empty()) continue;
    const Path v362_13_head{v362_13_label};
    const Space v363_2 = singleton(v362_13_head);
    const Space v363_3 = intersect(constant_2,v363_2);
    const Space v363_4 = (has_head(v363_3) ? constant_3 : Space{});
    const Space v363_5 = subtract(constant_1,v363_4);
    Space v363_8;
    if (!v363_5.empty()) {
      const Path v364_6 = concat_path(p0,v362_13_head);
      Space v364_7_result;
      for (int v364_7_label = 1; v364_7_label <= 2; ++v364_7_label) {
        const Space v364_7_tail = child(v362_13_tail,v364_7_label);
        if (v364_7_tail.empty()) continue;
        const Path v364_7_head{v364_7_label};
        const Space v365_2 = singleton(v364_7_head);
        const Space v365_3 = intersect(constant_2,v365_2);
        const Space v365_4 = (has_head(v365_3) ? constant_3 : Space{});
        const Space v365_5 = subtract(constant_1,v365_4);
        Space v365_8;
        if (!v365_5.empty()) {
          const Path v366_6 = concat_path(v364_6,v364_7_head);
          const Space v366_7 = routine_74(c, v366_6, p1, v364_7_tail, s1);
          v365_8 = compose(v365_5,v366_7);
        }
        const Space v365_9 = intersect(constant_2,v365_2);
        const Space v365_10 = (has_head(v365_9) ? constant_3 : Space{});
        Space v365_12;
        if (!v365_10.empty()) {
          const Path v367_6 = concat_path(v364_6,v364_7_head);
          const Space v367_11 = routine_75(c, v367_6, p1, v364_7_tail, s1);
          v365_12 = compose(v365_10,v367_11);
        }
        const Space v365_13 = unite(v365_8,v365_12);
        v364_7_result = unite(v364_7_result,v365_13);
      }
      const Space v364_7 = std::move(v364_7_result);
      v363_8 = compose(v363_5,v364_7);
    }
    const Space v363_9 = intersect(constant_2,v363_2);
    const Space v363_10 = (has_head(v363_9) ? constant_3 : Space{});
    Space v363_12;
    if (!v363_10.empty()) {
      const Path v368_6 = concat_path(p0,v362_13_head);
      Space v368_11_result;
      for (int v368_11_label = 1; v368_11_label <= 2; ++v368_11_label) {
        const Space v368_11_tail = child(v362_13_tail,v368_11_label);
        if (v368_11_tail.empty()) continue;
        const Path v368_11_head{v368_11_label};
        const Space v369_2 = singleton(v368_11_head);
        const Space v369_3 = intersect(constant_2,v369_2);
        const Space v369_4 = (has_head(v369_3) ? constant_3 : Space{});
        const Space v369_5 = subtract(constant_1,v369_4);
        Space v369_8;
        if (!v369_5.empty()) {
          const Path v370_6 = concat_path(v368_6,v368_11_head);
          const Space v370_7 = routine_74(c, v370_6, p1, v368_11_tail, s1);
          v369_8 = compose(v369_5,v370_7);
        }
        const Space v369_9 = intersect(constant_2,v369_2);
        const Space v369_10 = (has_head(v369_9) ? constant_3 : Space{});
        Space v369_12;
        if (!v369_10.empty()) {
          const Path v371_6 = concat_path(v368_6,v368_11_head);
          const Space v371_11 = routine_36(c, v371_6, p1, v368_11_tail, s1);
          v369_12 = compose(v369_10,v371_11);
        }
        const Space v369_13 = unite(v369_8,v369_12);
        v368_11_result = unite(v368_11_result,v369_13);
      }
      const Space v368_11 = std::move(v368_11_result);
      v363_12 = compose(v363_10,v368_11);
    }
    const Space v363_13 = unite(v363_8,v363_12);
    v362_13_result = unite(v362_13_result,v363_13);
  }
  const Space v362_13 = std::move(v362_13_result);
  return v362_13;
}

static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v372_8 = unwrap(s1,constant_4);
  const Space v372_10 = unwrap(v372_8,constant_6);
  const Space v372_11 = unwrap(v372_10,p0);
  Space v372_18_result;
  for (int v372_18_label = 1; v372_18_label <= 2; ++v372_18_label) {
    const Space v372_18_tail = child(s0,v372_18_label);
    if (v372_18_tail.empty()) continue;
    const Path v372_18_head{v372_18_label};
    const Space v373_2 = singleton(v372_18_head);
    const Space v373_3 = intersect(constant_2,v373_2);
    const Space v373_4 = (has_head(v373_3) ? constant_3 : Space{});
    const Space v373_5 = subtract(constant_1,v373_4);
    Space v373_8;
    if (!v373_5.empty()) {
      const Path v374_6 = concat_path(p0,v372_18_head);
      Space v374_7_result;
      for (int v374_7_label = 1; v374_7_label <= 2; ++v374_7_label) {
        const Space v374_7_tail = child(v372_18_tail,v374_7_label);
        if (v374_7_tail.empty()) continue;
        const Path v374_7_head{v374_7_label};
        const Space v375_2 = singleton(v374_7_head);
        const Space v375_3 = intersect(constant_2,v375_2);
        const Space v375_4 = (has_head(v375_3) ? constant_3 : Space{});
        const Space v375_5 = subtract(constant_1,v375_4);
        Space v375_8;
        if (!v375_5.empty()) {
          const Path v376_6 = concat_path(v374_6,v374_7_head);
          const Space v376_7 = routine_74(c, v376_6, p1, v374_7_tail, s1);
          v375_8 = compose(v375_5,v376_7);
        }
        const Space v375_9 = intersect(constant_2,v375_2);
        const Space v375_10 = (has_head(v375_9) ? constant_3 : Space{});
        Space v375_12;
        if (!v375_10.empty()) {
          const Path v377_6 = concat_path(v374_6,v374_7_head);
          const Space v377_11 = routine_75(c, v377_6, p1, v374_7_tail, s1);
          v375_12 = compose(v375_10,v377_11);
        }
        const Space v375_13 = unite(v375_8,v375_12);
        v374_7_result = unite(v374_7_result,v375_13);
      }
      const Space v374_7 = std::move(v374_7_result);
      v373_8 = compose(v373_5,v374_7);
    }
    const Space v373_9 = intersect(constant_2,v373_2);
    const Space v373_10 = (has_head(v373_9) ? constant_3 : Space{});
    Space v373_13;
    if (!v373_10.empty()) {
      const Space v378_11 = unwrap(v372_11,v372_18_head);
      Space v378_12_result;
      for (int v378_12_label = 1; v378_12_label <= 2; ++v378_12_label) {
        const Space v378_12_tail = child(v378_11,v378_12_label);
        if (v378_12_tail.empty()) continue;
        const Path v378_12_head{v378_12_label};
        const Space v379_2 = singleton(v378_12_head);
        const Space v379_3 = intersect(constant_2,v379_2);
        const Space v379_4 = (has_head(v379_3) ? constant_3 : Space{});
        const Space v379_5 = subtract(constant_1,v379_4);
        Space v379_7;
        if (!v379_5.empty()) {
          const Space v380_6 = routine_72(c, v378_12_head, p1, v378_12_tail);
          v379_7 = compose(v379_5,v380_6);
        }
        const Space v379_8 = intersect(constant_2,v379_2);
        const Space v379_9 = (has_head(v379_8) ? constant_3 : Space{});
        Space v379_11;
        if (!v379_9.empty()) {
          const Space v381_10 = routine_73(c, v378_12_head, p1, v378_12_tail);
          v379_11 = compose(v379_9,v381_10);
        }
        const Space v379_12 = unite(v379_7,v379_11);
        v378_12_result = unite(v378_12_result,v379_12);
      }
      const Space v378_12 = std::move(v378_12_result);
      v373_13 = compose(v373_10,v378_12);
    }
    const Space v373_14 = unite(v373_8,v373_13);
    v372_18_result = unite(v372_18_result,v373_14);
  }
  const Space v372_18 = std::move(v372_18_result);
  return v372_18;
}

static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v382_5 = unwrap(s1,constant_4);
  const Space v382_7 = unwrap(v382_5,constant_6);
  const Space v382_8 = unwrap(v382_7,p0);
  Space v382_18_result;
  for (int v382_18_label = 1; v382_18_label <= 2; ++v382_18_label) {
    const Space v382_18_tail = child(v382_8,v382_18_label);
    if (v382_18_tail.empty()) continue;
    const Path v382_18_head{v382_18_label};
    const Space v383_2 = singleton(v382_18_head);
    const Space v383_3 = intersect(constant_2,v383_2);
    const Space v383_4 = (has_head(v383_3) ? constant_3 : Space{});
    const Space v383_5 = subtract(constant_1,v383_4);
    Space v383_7;
    if (!v383_5.empty()) {
      Space v384_6_result;
      for (int v384_6_label = 1; v384_6_label <= 2; ++v384_6_label) {
        const Space v384_6_tail = child(v382_18_tail,v384_6_label);
        if (v384_6_tail.empty()) continue;
        const Path v384_6_head{v384_6_label};
        const Space v385_2 = singleton(v384_6_head);
        const Space v385_3 = intersect(constant_2,v385_2);
        const Space v385_4 = (has_head(v385_3) ? constant_3 : Space{});
        const Space v385_5 = subtract(constant_1,v385_4);
        Space v385_8;
        if (!v385_5.empty()) {
          const Path v386_6 = concat_path(v382_18_head,v384_6_head);
          const Space v386_7 = routine_76(c, v386_6, p1, v384_6_tail);
          v385_8 = compose(v385_5,v386_7);
        }
        const Space v385_9 = intersect(constant_2,v385_2);
        const Space v385_10 = (has_head(v385_9) ? constant_3 : Space{});
        Space v385_12;
        if (!v385_10.empty()) {
          const Path v387_6 = concat_path(v382_18_head,v384_6_head);
          const Space v387_11 = routine_77(c, v387_6, p1, v384_6_tail);
          v385_12 = compose(v385_10,v387_11);
        }
        const Space v385_13 = unite(v385_8,v385_12);
        v384_6_result = unite(v384_6_result,v385_13);
      }
      const Space v384_6 = std::move(v384_6_result);
      v383_7 = compose(v383_5,v384_6);
    }
    const Space v383_8 = intersect(constant_2,v383_2);
    const Space v383_9 = (has_head(v383_8) ? constant_3 : Space{});
    Space v383_11;
    if (!v383_9.empty()) {
      Space v388_10_result;
      for (int v388_10_label = 1; v388_10_label <= 2; ++v388_10_label) {
        const Space v388_10_tail = child(v382_18_tail,v388_10_label);
        if (v388_10_tail.empty()) continue;
        const Path v388_10_head{v388_10_label};
        const Space v389_2 = singleton(v388_10_head);
        const Space v389_3 = intersect(constant_2,v389_2);
        const Space v389_4 = (has_head(v389_3) ? constant_3 : Space{});
        const Space v389_5 = subtract(constant_1,v389_4);
        Space v389_8;
        if (!v389_5.empty()) {
          const Path v390_6 = concat_path(v382_18_head,v388_10_head);
          const Space v390_7 = routine_76(c, v390_6, p1, v388_10_tail);
          v389_8 = compose(v389_5,v390_7);
        }
        const Space v389_9 = intersect(constant_2,v389_2);
        const Space v389_10 = (has_head(v389_9) ? constant_3 : Space{});
        Space v389_12;
        if (!v389_10.empty()) {
          const Path v391_6 = concat_path(v382_18_head,v388_10_head);
          const Space v391_11 = routine_78(c, v391_6, p1, v388_10_tail);
          v389_12 = compose(v389_10,v391_11);
        }
        const Space v389_13 = unite(v389_8,v389_12);
        v388_10_result = unite(v388_10_result,v389_13);
      }
      const Space v388_10 = std::move(v388_10_result);
      v383_11 = compose(v383_9,v388_10);
    }
    const Space v383_12 = unite(v383_7,v383_11);
    v382_18_result = unite(v382_18_result,v383_12);
  }
  const Space v382_18 = std::move(v382_18_result);
  return v382_18;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v392_12_result;
  for (int v392_12_label = 1; v392_12_label <= 2; ++v392_12_label) {
    const Space v392_12_tail = child(s0,v392_12_label);
    if (v392_12_tail.empty()) continue;
    const Path v392_12_head{v392_12_label};
    const Space v393_2 = singleton(v392_12_head);
    const Space v393_3 = intersect(constant_2,v393_2);
    const Space v393_4 = (has_head(v393_3) ? constant_3 : Space{});
    const Space v393_5 = subtract(constant_1,v393_4);
    Space v393_8;
    if (!v393_5.empty()) {
      const Path v394_6 = concat_path(p0,v392_12_head);
      Space v394_7_result;
      for (int v394_7_label = 1; v394_7_label <= 2; ++v394_7_label) {
        const Space v394_7_tail = child(v392_12_tail,v394_7_label);
        if (v394_7_tail.empty()) continue;
        const Path v394_7_head{v394_7_label};
        const Space v395_2 = singleton(v394_7_head);
        const Space v395_3 = intersect(constant_2,v395_2);
        const Space v395_4 = (has_head(v395_3) ? constant_3 : Space{});
        const Space v395_5 = subtract(constant_1,v395_4);
        Space v395_8;
        if (!v395_5.empty()) {
          const Path v396_6 = concat_path(v394_6,v394_7_head);
          const Space v396_7 = routine_79(c, v396_6, v394_7_tail, s1);
          v395_8 = compose(v395_5,v396_7);
        }
        const Space v395_9 = intersect(constant_2,v395_2);
        const Space v395_10 = (has_head(v395_9) ? constant_3 : Space{});
        Space v395_12;
        if (!v395_10.empty()) {
          const Path v397_6 = concat_path(v394_6,v394_7_head);
          const Space v397_11 = routine_80(c, v397_6, v394_7_tail, s1);
          v395_12 = compose(v395_10,v397_11);
        }
        const Space v395_13 = unite(v395_8,v395_12);
        v394_7_result = unite(v394_7_result,v395_13);
      }
      const Space v394_7 = std::move(v394_7_result);
      v393_8 = compose(v393_5,v394_7);
    }
    const Space v393_9 = intersect(constant_2,v393_2);
    const Space v393_10 = (has_head(v393_9) ? constant_3 : Space{});
    Space v393_12;
    if (!v393_10.empty()) {
      const Path v398_6 = concat_path(p0,v392_12_head);
      Space v398_11_result;
      for (int v398_11_label = 1; v398_11_label <= 2; ++v398_11_label) {
        const Space v398_11_tail = child(v392_12_tail,v398_11_label);
        if (v398_11_tail.empty()) continue;
        const Path v398_11_head{v398_11_label};
        const Space v399_2 = singleton(v398_11_head);
        const Space v399_3 = intersect(constant_2,v399_2);
        const Space v399_4 = (has_head(v399_3) ? constant_3 : Space{});
        const Space v399_5 = subtract(constant_1,v399_4);
        Space v399_8;
        if (!v399_5.empty()) {
          const Path v400_6 = concat_path(v398_6,v398_11_head);
          const Space v400_7 = routine_79(c, v400_6, v398_11_tail, s1);
          v399_8 = compose(v399_5,v400_7);
        }
        const Space v399_9 = intersect(constant_2,v399_2);
        const Space v399_10 = (has_head(v399_9) ? constant_3 : Space{});
        Space v399_12;
        if (!v399_10.empty()) {
          const Path v401_6 = concat_path(v398_6,v398_11_head);
          const Space v401_11 = routine_12(c, v401_6, v398_11_tail, s1);
          v399_12 = compose(v399_10,v401_11);
        }
        const Space v399_13 = unite(v399_8,v399_12);
        v398_11_result = unite(v398_11_result,v399_13);
      }
      const Space v398_11 = std::move(v398_11_result);
      v393_12 = compose(v393_10,v398_11);
    }
    const Space v393_13 = unite(v393_8,v393_12);
    v392_12_result = unite(v392_12_result,v393_13);
  }
  const Space v392_12 = std::move(v392_12_result);
  return v392_12;
}

static Space routine_38(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v402_12_result;
  for (int v402_12_label = 1; v402_12_label <= 2; ++v402_12_label) {
    const Space v402_12_tail = child(s0,v402_12_label);
    if (v402_12_tail.empty()) continue;
    const Path v402_12_head{v402_12_label};
    const Space v403_2 = singleton(v402_12_head);
    const Space v403_3 = intersect(constant_2,v403_2);
    const Space v403_4 = (has_head(v403_3) ? constant_3 : Space{});
    const Space v403_5 = subtract(constant_1,v403_4);
    Space v403_8;
    if (!v403_5.empty()) {
      const Path v404_6 = concat_path(p0,v402_12_head);
      Space v404_7_result;
      for (int v404_7_label = 1; v404_7_label <= 2; ++v404_7_label) {
        const Space v404_7_tail = child(v402_12_tail,v404_7_label);
        if (v404_7_tail.empty()) continue;
        const Path v404_7_head{v404_7_label};
        const Space v405_2 = singleton(v404_7_head);
        const Space v405_3 = intersect(constant_2,v405_2);
        const Space v405_4 = (has_head(v405_3) ? constant_3 : Space{});
        const Space v405_5 = subtract(constant_1,v405_4);
        Space v405_8;
        if (!v405_5.empty()) {
          const Path v406_6 = concat_path(v404_6,v404_7_head);
          const Space v406_7 = routine_79(c, v406_6, v404_7_tail, s1);
          v405_8 = compose(v405_5,v406_7);
        }
        const Space v405_9 = intersect(constant_2,v405_2);
        const Space v405_10 = (has_head(v405_9) ? constant_3 : Space{});
        Space v405_12;
        if (!v405_10.empty()) {
          const Path v407_6 = concat_path(v404_6,v404_7_head);
          const Space v407_11 = routine_80(c, v407_6, v404_7_tail, s1);
          v405_12 = compose(v405_10,v407_11);
        }
        const Space v405_13 = unite(v405_8,v405_12);
        v404_7_result = unite(v404_7_result,v405_13);
      }
      const Space v404_7 = std::move(v404_7_result);
      v403_8 = compose(v403_5,v404_7);
    }
    const Space v403_9 = intersect(constant_2,v403_2);
    const Space v403_10 = (has_head(v403_9) ? constant_3 : Space{});
    Space v403_12;
    if (!v403_10.empty()) {
      const Path v408_6 = concat_path(p0,v402_12_head);
      Space v408_11_result;
      for (int v408_11_label = 1; v408_11_label <= 2; ++v408_11_label) {
        const Space v408_11_tail = child(v402_12_tail,v408_11_label);
        if (v408_11_tail.empty()) continue;
        const Path v408_11_head{v408_11_label};
        const Space v409_2 = singleton(v408_11_head);
        const Space v409_3 = intersect(constant_2,v409_2);
        const Space v409_4 = (has_head(v409_3) ? constant_3 : Space{});
        const Space v409_5 = subtract(constant_1,v409_4);
        Space v409_7;
        if (!v409_5.empty()) {
          const Space v410_6 = routine_39(c, v408_11_head, v408_6, v408_11_tail, s1);
          v409_7 = compose(v409_5,v410_6);
        }
        const Space v409_8 = intersect(constant_2,v409_2);
        const Space v409_9 = (has_head(v409_8) ? constant_3 : Space{});
        Space v409_11;
        if (!v409_9.empty()) {
          const Space v411_10 = routine_40(c, v408_11_head, v408_6, v408_11_tail, s1);
          v409_11 = compose(v409_9,v411_10);
        }
        const Space v409_12 = unite(v409_7,v409_11);
        v408_11_result = unite(v408_11_result,v409_12);
      }
      const Space v408_11 = std::move(v408_11_result);
      v403_12 = compose(v403_10,v408_11);
    }
    const Space v403_13 = unite(v403_8,v403_12);
    v402_12_result = unite(v402_12_result,v403_13);
  }
  const Space v402_12 = std::move(v402_12_result);
  return v402_12;
}

static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v412_13_result;
  for (int v412_13_label = 1; v412_13_label <= 2; ++v412_13_label) {
    const Space v412_13_tail = child(s0,v412_13_label);
    if (v412_13_tail.empty()) continue;
    const Path v412_13_head{v412_13_label};
    const Space v413_2 = singleton(v412_13_head);
    const Space v413_3 = intersect(constant_2,v413_2);
    const Space v413_4 = (has_head(v413_3) ? constant_3 : Space{});
    const Space v413_5 = subtract(constant_1,v413_4);
    Space v413_8;
    if (!v413_5.empty()) {
      const Path v414_6 = concat_path(p0,v412_13_head);
      Space v414_7_result;
      for (int v414_7_label = 1; v414_7_label <= 2; ++v414_7_label) {
        const Space v414_7_tail = child(v412_13_tail,v414_7_label);
        if (v414_7_tail.empty()) continue;
        const Path v414_7_head{v414_7_label};
        const Space v415_2 = singleton(v414_7_head);
        const Space v415_3 = intersect(constant_2,v415_2);
        const Space v415_4 = (has_head(v415_3) ? constant_3 : Space{});
        const Space v415_5 = subtract(constant_1,v415_4);
        Space v415_8;
        if (!v415_5.empty()) {
          const Path v416_6 = concat_path(v414_6,v414_7_head);
          const Space v416_7 = routine_81(c, v416_6, p1, v414_7_tail, s1);
          v415_8 = compose(v415_5,v416_7);
        }
        const Space v415_9 = intersect(constant_2,v415_2);
        const Space v415_10 = (has_head(v415_9) ? constant_3 : Space{});
        Space v415_12;
        if (!v415_10.empty()) {
          const Path v417_6 = concat_path(v414_6,v414_7_head);
          const Space v417_11 = routine_82(c, v417_6, p1, v414_7_tail, s1);
          v415_12 = compose(v415_10,v417_11);
        }
        const Space v415_13 = unite(v415_8,v415_12);
        v414_7_result = unite(v414_7_result,v415_13);
      }
      const Space v414_7 = std::move(v414_7_result);
      v413_8 = compose(v413_5,v414_7);
    }
    const Space v413_9 = intersect(constant_2,v413_2);
    const Space v413_10 = (has_head(v413_9) ? constant_3 : Space{});
    Space v413_12;
    if (!v413_10.empty()) {
      const Path v418_6 = concat_path(p0,v412_13_head);
      Space v418_11_result;
      for (int v418_11_label = 1; v418_11_label <= 2; ++v418_11_label) {
        const Space v418_11_tail = child(v412_13_tail,v418_11_label);
        if (v418_11_tail.empty()) continue;
        const Path v418_11_head{v418_11_label};
        const Space v419_2 = singleton(v418_11_head);
        const Space v419_3 = intersect(constant_2,v419_2);
        const Space v419_4 = (has_head(v419_3) ? constant_3 : Space{});
        const Space v419_5 = subtract(constant_1,v419_4);
        Space v419_8;
        if (!v419_5.empty()) {
          const Path v420_6 = concat_path(v418_6,v418_11_head);
          const Space v420_7 = routine_81(c, v420_6, p1, v418_11_tail, s1);
          v419_8 = compose(v419_5,v420_7);
        }
        const Space v419_9 = intersect(constant_2,v419_2);
        const Space v419_10 = (has_head(v419_9) ? constant_3 : Space{});
        Space v419_12;
        if (!v419_10.empty()) {
          const Path v421_6 = concat_path(v418_6,v418_11_head);
          const Space v421_11 = routine_43(c, v421_6, p1, v418_11_tail, s1);
          v419_12 = compose(v419_10,v421_11);
        }
        const Space v419_13 = unite(v419_8,v419_12);
        v418_11_result = unite(v418_11_result,v419_13);
      }
      const Space v418_11 = std::move(v418_11_result);
      v413_12 = compose(v413_10,v418_11);
    }
    const Space v413_13 = unite(v413_8,v413_12);
    v412_13_result = unite(v412_13_result,v413_13);
  }
  const Space v412_13 = std::move(v412_13_result);
  return v412_13;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v422_8 = unwrap(s1,constant_4);
  const Space v422_10 = unwrap(v422_8,constant_6);
  const Space v422_11 = unwrap(v422_10,p0);
  Space v422_18_result;
  for (int v422_18_label = 1; v422_18_label <= 2; ++v422_18_label) {
    const Space v422_18_tail = child(s0,v422_18_label);
    if (v422_18_tail.empty()) continue;
    const Path v422_18_head{v422_18_label};
    const Space v423_2 = singleton(v422_18_head);
    const Space v423_3 = intersect(constant_2,v423_2);
    const Space v423_4 = (has_head(v423_3) ? constant_3 : Space{});
    const Space v423_5 = subtract(constant_1,v423_4);
    Space v423_8;
    if (!v423_5.empty()) {
      const Path v424_6 = concat_path(p0,v422_18_head);
      Space v424_7_result;
      for (int v424_7_label = 1; v424_7_label <= 2; ++v424_7_label) {
        const Space v424_7_tail = child(v422_18_tail,v424_7_label);
        if (v424_7_tail.empty()) continue;
        const Path v424_7_head{v424_7_label};
        const Space v425_2 = singleton(v424_7_head);
        const Space v425_3 = intersect(constant_2,v425_2);
        const Space v425_4 = (has_head(v425_3) ? constant_3 : Space{});
        const Space v425_5 = subtract(constant_1,v425_4);
        Space v425_8;
        if (!v425_5.empty()) {
          const Path v426_6 = concat_path(v424_6,v424_7_head);
          const Space v426_7 = routine_81(c, v426_6, p1, v424_7_tail, s1);
          v425_8 = compose(v425_5,v426_7);
        }
        const Space v425_9 = intersect(constant_2,v425_2);
        const Space v425_10 = (has_head(v425_9) ? constant_3 : Space{});
        Space v425_12;
        if (!v425_10.empty()) {
          const Path v427_6 = concat_path(v424_6,v424_7_head);
          const Space v427_11 = routine_82(c, v427_6, p1, v424_7_tail, s1);
          v425_12 = compose(v425_10,v427_11);
        }
        const Space v425_13 = unite(v425_8,v425_12);
        v424_7_result = unite(v424_7_result,v425_13);
      }
      const Space v424_7 = std::move(v424_7_result);
      v423_8 = compose(v423_5,v424_7);
    }
    const Space v423_9 = intersect(constant_2,v423_2);
    const Space v423_10 = (has_head(v423_9) ? constant_3 : Space{});
    Space v423_13;
    if (!v423_10.empty()) {
      const Space v428_11 = unwrap(v422_11,v422_18_head);
      Space v428_12_result;
      for (int v428_12_label = 1; v428_12_label <= 2; ++v428_12_label) {
        const Space v428_12_tail = child(v428_11,v428_12_label);
        if (v428_12_tail.empty()) continue;
        const Path v428_12_head{v428_12_label};
        const Space v429_2 = singleton(v428_12_head);
        const Space v429_3 = intersect(constant_2,v429_2);
        const Space v429_4 = (has_head(v429_3) ? constant_3 : Space{});
        const Space v429_5 = subtract(constant_1,v429_4);
        Space v429_7;
        if (!v429_5.empty()) {
          const Space v430_6 = routine_83(c, v428_12_head, p1, v428_12_tail);
          v429_7 = compose(v429_5,v430_6);
        }
        const Space v429_8 = intersect(constant_2,v429_2);
        const Space v429_9 = (has_head(v429_8) ? constant_3 : Space{});
        Space v429_11;
        if (!v429_9.empty()) {
          const Space v431_10 = routine_84(c, v428_12_head, p1, v428_12_tail);
          v429_11 = compose(v429_9,v431_10);
        }
        const Space v429_12 = unite(v429_7,v429_11);
        v428_12_result = unite(v428_12_result,v429_12);
      }
      const Space v428_12 = std::move(v428_12_result);
      v423_13 = compose(v423_10,v428_12);
    }
    const Space v423_14 = unite(v423_8,v423_13);
    v422_18_result = unite(v422_18_result,v423_14);
  }
  const Space v422_18 = std::move(v422_18_result);
  return v422_18;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v432_13_result;
  for (int v432_13_label = 1; v432_13_label <= 2; ++v432_13_label) {
    const Space v432_13_tail = child(s0,v432_13_label);
    if (v432_13_tail.empty()) continue;
    const Path v432_13_head{v432_13_label};
    const Space v433_2 = singleton(v432_13_head);
    const Space v433_3 = intersect(constant_2,v433_2);
    const Space v433_4 = (has_head(v433_3) ? constant_3 : Space{});
    const Space v433_5 = subtract(constant_1,v433_4);
    Space v433_8;
    if (!v433_5.empty()) {
      const Path v434_6 = concat_path(p0,v432_13_head);
      Space v434_7_result;
      for (int v434_7_label = 1; v434_7_label <= 2; ++v434_7_label) {
        const Space v434_7_tail = child(v432_13_tail,v434_7_label);
        if (v434_7_tail.empty()) continue;
        const Path v434_7_head{v434_7_label};
        const Space v435_2 = singleton(v434_7_head);
        const Space v435_3 = intersect(constant_2,v435_2);
        const Space v435_4 = (has_head(v435_3) ? constant_3 : Space{});
        const Space v435_5 = subtract(constant_1,v435_4);
        Space v435_8;
        if (!v435_5.empty()) {
          const Path v436_6 = concat_path(v434_6,v434_7_head);
          const Space v436_7 = routine_85(c, v436_6, p1, v434_7_tail, s1);
          v435_8 = compose(v435_5,v436_7);
        }
        const Space v435_9 = intersect(constant_2,v435_2);
        const Space v435_10 = (has_head(v435_9) ? constant_3 : Space{});
        Space v435_12;
        if (!v435_10.empty()) {
          const Path v437_6 = concat_path(v434_6,v434_7_head);
          const Space v437_11 = routine_86(c, v437_6, p1, v434_7_tail, s1);
          v435_12 = compose(v435_10,v437_11);
        }
        const Space v435_13 = unite(v435_8,v435_12);
        v434_7_result = unite(v434_7_result,v435_13);
      }
      const Space v434_7 = std::move(v434_7_result);
      v433_8 = compose(v433_5,v434_7);
    }
    const Space v433_9 = intersect(constant_2,v433_2);
    const Space v433_10 = (has_head(v433_9) ? constant_3 : Space{});
    Space v433_12;
    if (!v433_10.empty()) {
      const Path v438_6 = concat_path(p0,v432_13_head);
      Space v438_11_result;
      for (int v438_11_label = 1; v438_11_label <= 2; ++v438_11_label) {
        const Space v438_11_tail = child(v432_13_tail,v438_11_label);
        if (v438_11_tail.empty()) continue;
        const Path v438_11_head{v438_11_label};
        const Space v439_2 = singleton(v438_11_head);
        const Space v439_3 = intersect(constant_2,v439_2);
        const Space v439_4 = (has_head(v439_3) ? constant_3 : Space{});
        const Space v439_5 = subtract(constant_1,v439_4);
        Space v439_8;
        if (!v439_5.empty()) {
          const Path v440_6 = concat_path(v438_6,v438_11_head);
          const Space v440_7 = routine_85(c, v440_6, p1, v438_11_tail, s1);
          v439_8 = compose(v439_5,v440_7);
        }
        const Space v439_9 = intersect(constant_2,v439_2);
        const Space v439_10 = (has_head(v439_9) ? constant_3 : Space{});
        Space v439_12;
        if (!v439_10.empty()) {
          const Path v441_6 = concat_path(v438_6,v438_11_head);
          const Space v441_11 = routine_43(c, v441_6, p1, v438_11_tail, s1);
          v439_12 = compose(v439_10,v441_11);
        }
        const Space v439_13 = unite(v439_8,v439_12);
        v438_11_result = unite(v438_11_result,v439_13);
      }
      const Space v438_11 = std::move(v438_11_result);
      v433_12 = compose(v433_10,v438_11);
    }
    const Space v433_13 = unite(v433_8,v433_12);
    v432_13_result = unite(v432_13_result,v433_13);
  }
  const Space v432_13 = std::move(v432_13_result);
  return v432_13;
}

static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v442_8 = unwrap(s1,constant_4);
  const Space v442_10 = unwrap(v442_8,constant_6);
  const Space v442_11 = unwrap(v442_10,p0);
  Space v442_18_result;
  for (int v442_18_label = 1; v442_18_label <= 2; ++v442_18_label) {
    const Space v442_18_tail = child(s0,v442_18_label);
    if (v442_18_tail.empty()) continue;
    const Path v442_18_head{v442_18_label};
    const Space v443_2 = singleton(v442_18_head);
    const Space v443_3 = intersect(constant_2,v443_2);
    const Space v443_4 = (has_head(v443_3) ? constant_3 : Space{});
    const Space v443_5 = subtract(constant_1,v443_4);
    Space v443_8;
    if (!v443_5.empty()) {
      const Path v444_6 = concat_path(p0,v442_18_head);
      Space v444_7_result;
      for (int v444_7_label = 1; v444_7_label <= 2; ++v444_7_label) {
        const Space v444_7_tail = child(v442_18_tail,v444_7_label);
        if (v444_7_tail.empty()) continue;
        const Path v444_7_head{v444_7_label};
        const Space v445_2 = singleton(v444_7_head);
        const Space v445_3 = intersect(constant_2,v445_2);
        const Space v445_4 = (has_head(v445_3) ? constant_3 : Space{});
        const Space v445_5 = subtract(constant_1,v445_4);
        Space v445_8;
        if (!v445_5.empty()) {
          const Path v446_6 = concat_path(v444_6,v444_7_head);
          const Space v446_7 = routine_85(c, v446_6, p1, v444_7_tail, s1);
          v445_8 = compose(v445_5,v446_7);
        }
        const Space v445_9 = intersect(constant_2,v445_2);
        const Space v445_10 = (has_head(v445_9) ? constant_3 : Space{});
        Space v445_12;
        if (!v445_10.empty()) {
          const Path v447_6 = concat_path(v444_6,v444_7_head);
          const Space v447_11 = routine_86(c, v447_6, p1, v444_7_tail, s1);
          v445_12 = compose(v445_10,v447_11);
        }
        const Space v445_13 = unite(v445_8,v445_12);
        v444_7_result = unite(v444_7_result,v445_13);
      }
      const Space v444_7 = std::move(v444_7_result);
      v443_8 = compose(v443_5,v444_7);
    }
    const Space v443_9 = intersect(constant_2,v443_2);
    const Space v443_10 = (has_head(v443_9) ? constant_3 : Space{});
    Space v443_13;
    if (!v443_10.empty()) {
      const Space v448_11 = unwrap(v442_11,v442_18_head);
      Space v448_12_result;
      for (int v448_12_label = 1; v448_12_label <= 2; ++v448_12_label) {
        const Space v448_12_tail = child(v448_11,v448_12_label);
        if (v448_12_tail.empty()) continue;
        const Path v448_12_head{v448_12_label};
        const Space v449_2 = singleton(v448_12_head);
        const Space v449_3 = intersect(constant_2,v449_2);
        const Space v449_4 = (has_head(v449_3) ? constant_3 : Space{});
        const Space v449_5 = subtract(constant_1,v449_4);
        Space v449_7;
        if (!v449_5.empty()) {
          const Space v450_6 = routine_83(c, v448_12_head, p1, v448_12_tail);
          v449_7 = compose(v449_5,v450_6);
        }
        const Space v449_8 = intersect(constant_2,v449_2);
        const Space v449_9 = (has_head(v449_8) ? constant_3 : Space{});
        Space v449_11;
        if (!v449_9.empty()) {
          const Space v451_10 = routine_84(c, v448_12_head, p1, v448_12_tail);
          v449_11 = compose(v449_9,v451_10);
        }
        const Space v449_12 = unite(v449_7,v449_11);
        v448_12_result = unite(v448_12_result,v449_12);
      }
      const Space v448_12 = std::move(v448_12_result);
      v443_13 = compose(v443_10,v448_12);
    }
    const Space v443_14 = unite(v443_8,v443_13);
    v442_18_result = unite(v442_18_result,v443_14);
  }
  const Space v442_18 = std::move(v442_18_result);
  return v442_18;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v452_5 = unwrap(s1,constant_4);
  const Space v452_7 = unwrap(v452_5,constant_6);
  const Space v452_8 = unwrap(v452_7,p0);
  Space v452_18_result;
  for (int v452_18_label = 1; v452_18_label <= 2; ++v452_18_label) {
    const Space v452_18_tail = child(v452_8,v452_18_label);
    if (v452_18_tail.empty()) continue;
    const Path v452_18_head{v452_18_label};
    const Space v453_2 = singleton(v452_18_head);
    const Space v453_3 = intersect(constant_2,v453_2);
    const Space v453_4 = (has_head(v453_3) ? constant_3 : Space{});
    const Space v453_5 = subtract(constant_1,v453_4);
    Space v453_7;
    if (!v453_5.empty()) {
      Space v454_6_result;
      for (int v454_6_label = 1; v454_6_label <= 2; ++v454_6_label) {
        const Space v454_6_tail = child(v452_18_tail,v454_6_label);
        if (v454_6_tail.empty()) continue;
        const Path v454_6_head{v454_6_label};
        const Space v455_2 = singleton(v454_6_head);
        const Space v455_3 = intersect(constant_2,v455_2);
        const Space v455_4 = (has_head(v455_3) ? constant_3 : Space{});
        const Space v455_5 = subtract(constant_1,v455_4);
        Space v455_8;
        if (!v455_5.empty()) {
          const Path v456_6 = concat_path(v452_18_head,v454_6_head);
          const Space v456_7 = routine_87(c, v456_6, p1, v454_6_tail);
          v455_8 = compose(v455_5,v456_7);
        }
        const Space v455_9 = intersect(constant_2,v455_2);
        const Space v455_10 = (has_head(v455_9) ? constant_3 : Space{});
        Space v455_12;
        if (!v455_10.empty()) {
          const Path v457_6 = concat_path(v452_18_head,v454_6_head);
          const Space v457_11 = routine_88(c, v457_6, p1, v454_6_tail);
          v455_12 = compose(v455_10,v457_11);
        }
        const Space v455_13 = unite(v455_8,v455_12);
        v454_6_result = unite(v454_6_result,v455_13);
      }
      const Space v454_6 = std::move(v454_6_result);
      v453_7 = compose(v453_5,v454_6);
    }
    const Space v453_8 = intersect(constant_2,v453_2);
    const Space v453_9 = (has_head(v453_8) ? constant_3 : Space{});
    Space v453_11;
    if (!v453_9.empty()) {
      Space v458_10_result;
      for (int v458_10_label = 1; v458_10_label <= 2; ++v458_10_label) {
        const Space v458_10_tail = child(v452_18_tail,v458_10_label);
        if (v458_10_tail.empty()) continue;
        const Path v458_10_head{v458_10_label};
        const Space v459_2 = singleton(v458_10_head);
        const Space v459_3 = intersect(constant_2,v459_2);
        const Space v459_4 = (has_head(v459_3) ? constant_3 : Space{});
        const Space v459_5 = subtract(constant_1,v459_4);
        Space v459_8;
        if (!v459_5.empty()) {
          const Path v460_6 = concat_path(v452_18_head,v458_10_head);
          const Space v460_7 = routine_87(c, v460_6, p1, v458_10_tail);
          v459_8 = compose(v459_5,v460_7);
        }
        const Space v459_9 = intersect(constant_2,v459_2);
        const Space v459_10 = (has_head(v459_9) ? constant_3 : Space{});
        Space v459_12;
        if (!v459_10.empty()) {
          const Path v461_6 = concat_path(v452_18_head,v458_10_head);
          const Space v461_11 = routine_89(c, v461_6, p1, v458_10_tail);
          v459_12 = compose(v459_10,v461_11);
        }
        const Space v459_13 = unite(v459_8,v459_12);
        v458_10_result = unite(v458_10_result,v459_13);
      }
      const Space v458_10 = std::move(v458_10_result);
      v453_11 = compose(v453_9,v458_10);
    }
    const Space v453_12 = unite(v453_7,v453_11);
    v452_18_result = unite(v452_18_result,v453_12);
  }
  const Space v452_18 = std::move(v452_18_result);
  return v452_18;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0) {
  Space v462_11_result;
  for (int v462_11_label = 1; v462_11_label <= 2; ++v462_11_label) {
    const Space v462_11_tail = child(s0,v462_11_label);
    if (v462_11_tail.empty()) continue;
    const Path v462_11_head{v462_11_label};
    const Space v463_2 = singleton(v462_11_head);
    const Space v463_3 = intersect(constant_2,v463_2);
    const Space v463_4 = (has_head(v463_3) ? constant_3 : Space{});
    const Space v463_5 = subtract(constant_1,v463_4);
    Space v463_8;
    if (!v463_5.empty()) {
      const Path v464_6 = concat_path(p0,v462_11_head);
      Space v464_7_result;
      for (int v464_7_label = 1; v464_7_label <= 2; ++v464_7_label) {
        const Space v464_7_tail = child(v462_11_tail,v464_7_label);
        if (v464_7_tail.empty()) continue;
        const Path v464_7_head{v464_7_label};
        const Space v465_2 = singleton(v464_7_head);
        const Space v465_3 = intersect(constant_2,v465_2);
        const Space v465_4 = (has_head(v465_3) ? constant_3 : Space{});
        const Space v465_5 = subtract(constant_1,v465_4);
        Space v465_8;
        if (!v465_5.empty()) {
          const Path v466_6 = concat_path(v464_6,v464_7_head);
          const Space v466_7 = routine_90(c, v466_6, v464_7_tail);
          v465_8 = compose(v465_5,v466_7);
        }
        const Space v465_9 = intersect(constant_2,v465_2);
        const Space v465_10 = (has_head(v465_9) ? constant_3 : Space{});
        Space v465_12;
        if (!v465_10.empty()) {
          const Path v467_6 = concat_path(v464_6,v464_7_head);
          const Space v467_11 = routine_91(c, v467_6, v464_7_tail);
          v465_12 = compose(v465_10,v467_11);
        }
        const Space v465_13 = unite(v465_8,v465_12);
        v464_7_result = unite(v464_7_result,v465_13);
      }
      const Space v464_7 = std::move(v464_7_result);
      v463_8 = compose(v463_5,v464_7);
    }
    const Space v463_9 = intersect(constant_2,v463_2);
    const Space v463_10 = (has_head(v463_9) ? constant_3 : Space{});
    Space v463_12;
    if (!v463_10.empty()) {
      const Path v468_6 = concat_path(p0,v462_11_head);
      Space v468_11_result;
      for (int v468_11_label = 1; v468_11_label <= 2; ++v468_11_label) {
        const Space v468_11_tail = child(v462_11_tail,v468_11_label);
        if (v468_11_tail.empty()) continue;
        const Path v468_11_head{v468_11_label};
        const Space v469_2 = singleton(v468_11_head);
        const Space v469_3 = intersect(constant_2,v469_2);
        const Space v469_4 = (has_head(v469_3) ? constant_3 : Space{});
        const Space v469_5 = subtract(constant_1,v469_4);
        Space v469_8;
        if (!v469_5.empty()) {
          const Path v470_6 = concat_path(v468_6,v468_11_head);
          const Space v470_7 = routine_90(c, v470_6, v468_11_tail);
          v469_8 = compose(v469_5,v470_7);
        }
        const Space v469_9 = intersect(constant_2,v469_2);
        const Space v469_10 = (has_head(v469_9) ? constant_3 : Space{});
        Space v469_12;
        if (!v469_10.empty()) {
          const Path v471_6 = concat_path(v468_6,v468_11_head);
          const Space v471_11 = routine_15(c, v471_6, v468_11_tail);
          v469_12 = compose(v469_10,v471_11);
        }
        const Space v469_13 = unite(v469_8,v469_12);
        v468_11_result = unite(v468_11_result,v469_13);
      }
      const Space v468_11 = std::move(v468_11_result);
      v463_12 = compose(v463_10,v468_11);
    }
    const Space v463_13 = unite(v463_8,v463_12);
    v462_11_result = unite(v462_11_result,v463_13);
  }
  const Space v462_11 = std::move(v462_11_result);
  return v462_11;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0) {
  Space v472_11_result;
  for (int v472_11_label = 1; v472_11_label <= 2; ++v472_11_label) {
    const Space v472_11_tail = child(s0,v472_11_label);
    if (v472_11_tail.empty()) continue;
    const Path v472_11_head{v472_11_label};
    const Space v473_2 = singleton(v472_11_head);
    const Space v473_3 = intersect(constant_2,v473_2);
    const Space v473_4 = (has_head(v473_3) ? constant_3 : Space{});
    const Space v473_5 = subtract(constant_1,v473_4);
    Space v473_8;
    if (!v473_5.empty()) {
      const Path v474_6 = concat_path(p0,v472_11_head);
      Space v474_7_result;
      for (int v474_7_label = 1; v474_7_label <= 2; ++v474_7_label) {
        const Space v474_7_tail = child(v472_11_tail,v474_7_label);
        if (v474_7_tail.empty()) continue;
        const Path v474_7_head{v474_7_label};
        const Space v475_2 = singleton(v474_7_head);
        const Space v475_3 = intersect(constant_2,v475_2);
        const Space v475_4 = (has_head(v475_3) ? constant_3 : Space{});
        const Space v475_5 = subtract(constant_1,v475_4);
        Space v475_8;
        if (!v475_5.empty()) {
          const Path v476_6 = concat_path(v474_6,v474_7_head);
          const Space v476_7 = routine_90(c, v476_6, v474_7_tail);
          v475_8 = compose(v475_5,v476_7);
        }
        const Space v475_9 = intersect(constant_2,v475_2);
        const Space v475_10 = (has_head(v475_9) ? constant_3 : Space{});
        Space v475_12;
        if (!v475_10.empty()) {
          const Path v477_6 = concat_path(v474_6,v474_7_head);
          const Space v477_11 = routine_91(c, v477_6, v474_7_tail);
          v475_12 = compose(v475_10,v477_11);
        }
        const Space v475_13 = unite(v475_8,v475_12);
        v474_7_result = unite(v474_7_result,v475_13);
      }
      const Space v474_7 = std::move(v474_7_result);
      v473_8 = compose(v473_5,v474_7);
    }
    const Space v473_9 = intersect(constant_2,v473_2);
    const Space v473_10 = (has_head(v473_9) ? constant_3 : Space{});
    Space v473_12;
    if (!v473_10.empty()) {
      const Path v478_6 = concat_path(p0,v472_11_head);
      Space v478_11_result;
      for (int v478_11_label = 1; v478_11_label <= 2; ++v478_11_label) {
        const Space v478_11_tail = child(v472_11_tail,v478_11_label);
        if (v478_11_tail.empty()) continue;
        const Path v478_11_head{v478_11_label};
        const Space v479_2 = singleton(v478_11_head);
        const Space v479_3 = intersect(constant_2,v479_2);
        const Space v479_4 = (has_head(v479_3) ? constant_3 : Space{});
        const Space v479_5 = subtract(constant_1,v479_4);
        Space v479_7;
        if (!v479_5.empty()) {
          const Space v480_6 = routine_46(c, v478_11_head, v478_6, v478_11_tail);
          v479_7 = compose(v479_5,v480_6);
        }
        const Space v479_8 = intersect(constant_2,v479_2);
        const Space v479_9 = (has_head(v479_8) ? constant_3 : Space{});
        Space v479_11;
        if (!v479_9.empty()) {
          const Space v481_10 = routine_47(c, v478_11_head, v478_6, v478_11_tail);
          v479_11 = compose(v479_9,v481_10);
        }
        const Space v479_12 = unite(v479_7,v479_11);
        v478_11_result = unite(v478_11_result,v479_12);
      }
      const Space v478_11 = std::move(v478_11_result);
      v473_12 = compose(v473_10,v478_11);
    }
    const Space v473_13 = unite(v473_8,v473_12);
    v472_11_result = unite(v472_11_result,v473_13);
  }
  const Space v472_11 = std::move(v472_11_result);
  return v472_11;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v482_12_result;
  for (int v482_12_label = 1; v482_12_label <= 2; ++v482_12_label) {
    const Space v482_12_tail = child(s0,v482_12_label);
    if (v482_12_tail.empty()) continue;
    const Path v482_12_head{v482_12_label};
    const Space v483_2 = singleton(v482_12_head);
    const Space v483_3 = intersect(constant_2,v483_2);
    const Space v483_4 = (has_head(v483_3) ? constant_3 : Space{});
    const Space v483_5 = subtract(constant_1,v483_4);
    Space v483_8;
    if (!v483_5.empty()) {
      const Path v484_6 = concat_path(p0,v482_12_head);
      Space v484_7_result;
      for (int v484_7_label = 1; v484_7_label <= 2; ++v484_7_label) {
        const Space v484_7_tail = child(v482_12_tail,v484_7_label);
        if (v484_7_tail.empty()) continue;
        const Path v484_7_head{v484_7_label};
        const Space v485_2 = singleton(v484_7_head);
        const Space v485_3 = intersect(constant_2,v485_2);
        const Space v485_4 = (has_head(v485_3) ? constant_3 : Space{});
        const Space v485_5 = subtract(constant_1,v485_4);
        Space v485_8;
        if (!v485_5.empty()) {
          const Path v486_6 = concat_path(v484_6,v484_7_head);
          const Space v486_7 = routine_92(c, v486_6, p1, v484_7_tail);
          v485_8 = compose(v485_5,v486_7);
        }
        const Space v485_9 = intersect(constant_2,v485_2);
        const Space v485_10 = (has_head(v485_9) ? constant_3 : Space{});
        Space v485_12;
        if (!v485_10.empty()) {
          const Path v487_6 = concat_path(v484_6,v484_7_head);
          const Space v487_11 = routine_93(c, v487_6, p1, v484_7_tail);
          v485_12 = compose(v485_10,v487_11);
        }
        const Space v485_13 = unite(v485_8,v485_12);
        v484_7_result = unite(v484_7_result,v485_13);
      }
      const Space v484_7 = std::move(v484_7_result);
      v483_8 = compose(v483_5,v484_7);
    }
    const Space v483_9 = intersect(constant_2,v483_2);
    const Space v483_10 = (has_head(v483_9) ? constant_3 : Space{});
    Space v483_12;
    if (!v483_10.empty()) {
      const Path v488_6 = concat_path(p0,v482_12_head);
      Space v488_11_result;
      for (int v488_11_label = 1; v488_11_label <= 2; ++v488_11_label) {
        const Space v488_11_tail = child(v482_12_tail,v488_11_label);
        if (v488_11_tail.empty()) continue;
        const Path v488_11_head{v488_11_label};
        const Space v489_2 = singleton(v488_11_head);
        const Space v489_3 = intersect(constant_2,v489_2);
        const Space v489_4 = (has_head(v489_3) ? constant_3 : Space{});
        const Space v489_5 = subtract(constant_1,v489_4);
        Space v489_8;
        if (!v489_5.empty()) {
          const Path v490_6 = concat_path(v488_6,v488_11_head);
          const Space v490_7 = routine_92(c, v490_6, p1, v488_11_tail);
          v489_8 = compose(v489_5,v490_7);
        }
        const Space v489_9 = intersect(constant_2,v489_2);
        const Space v489_10 = (has_head(v489_9) ? constant_3 : Space{});
        Space v489_12;
        if (!v489_10.empty()) {
          const Path v491_6 = concat_path(v488_6,v488_11_head);
          const Space v491_11 = routine_50(c, v491_6, p1, v488_11_tail);
          v489_12 = compose(v489_10,v491_11);
        }
        const Space v489_13 = unite(v489_8,v489_12);
        v488_11_result = unite(v488_11_result,v489_13);
      }
      const Space v488_11 = std::move(v488_11_result);
      v483_12 = compose(v483_10,v488_11);
    }
    const Space v483_13 = unite(v483_8,v483_12);
    v482_12_result = unite(v482_12_result,v483_13);
  }
  const Space v482_12 = std::move(v482_12_result);
  return v482_12;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v492_9_result;
  for (int v492_9_label = 1; v492_9_label <= 2; ++v492_9_label) {
    const Space v492_9_tail = child(s0,v492_9_label);
    if (v492_9_tail.empty()) continue;
    const Path v492_9_head{v492_9_label};
    const Space v493_2 = singleton(v492_9_head);
    const Space v493_3 = intersect(constant_2,v493_2);
    const Space v493_4 = (has_head(v493_3) ? constant_3 : Space{});
    const Space v493_5 = subtract(constant_1,v493_4);
    Space v493_8;
    if (!v493_5.empty()) {
      const Path v494_6 = concat_path(p0,v492_9_head);
      Space v494_7_result;
      for (int v494_7_label = 1; v494_7_label <= 2; ++v494_7_label) {
        const Space v494_7_tail = child(v492_9_tail,v494_7_label);
        if (v494_7_tail.empty()) continue;
        const Path v494_7_head{v494_7_label};
        const Space v495_2 = singleton(v494_7_head);
        const Space v495_3 = intersect(constant_2,v495_2);
        const Space v495_4 = (has_head(v495_3) ? constant_3 : Space{});
        const Space v495_5 = subtract(constant_1,v495_4);
        Space v495_8;
        if (!v495_5.empty()) {
          const Path v496_6 = concat_path(v494_6,v494_7_head);
          const Space v496_7 = routine_92(c, v496_6, p1, v494_7_tail);
          v495_8 = compose(v495_5,v496_7);
        }
        const Space v495_9 = intersect(constant_2,v495_2);
        const Space v495_10 = (has_head(v495_9) ? constant_3 : Space{});
        Space v495_12;
        if (!v495_10.empty()) {
          const Path v497_6 = concat_path(v494_6,v494_7_head);
          const Space v497_11 = routine_93(c, v497_6, p1, v494_7_tail);
          v495_12 = compose(v495_10,v497_11);
        }
        const Space v495_13 = unite(v495_8,v495_12);
        v494_7_result = unite(v494_7_result,v495_13);
      }
      const Space v494_7 = std::move(v494_7_result);
      v493_8 = compose(v493_5,v494_7);
    }
    const Space v493_9 = intersect(constant_2,v493_2);
    const Space v493_10 = (has_head(v493_9) ? constant_3 : Space{});
    const Space v493_11 = compose(v493_10,v492_9_tail);
    const Path v498_6 = concat_path(p0,v492_9_head);
    const Space v493_12 = wrap(v493_11,v498_6);
    const Space v493_13 = wrap(v493_12,p1);
    const Space v493_14 = unite(v493_8,v493_13);
    v492_9_result = unite(v492_9_result,v493_14);
  }
  const Space v492_9 = std::move(v492_9_result);
  return v492_9;
}

static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v499_12_result;
  for (int v499_12_label = 1; v499_12_label <= 2; ++v499_12_label) {
    const Space v499_12_tail = child(s0,v499_12_label);
    if (v499_12_tail.empty()) continue;
    const Path v499_12_head{v499_12_label};
    const Space v500_2 = singleton(v499_12_head);
    const Space v500_3 = intersect(constant_2,v500_2);
    const Space v500_4 = (has_head(v500_3) ? constant_3 : Space{});
    const Space v500_5 = subtract(constant_1,v500_4);
    Space v500_8;
    if (!v500_5.empty()) {
      const Path v501_6 = concat_path(p0,v499_12_head);
      Space v501_7_result;
      for (int v501_7_label = 1; v501_7_label <= 2; ++v501_7_label) {
        const Space v501_7_tail = child(v499_12_tail,v501_7_label);
        if (v501_7_tail.empty()) continue;
        const Path v501_7_head{v501_7_label};
        const Space v502_2 = singleton(v501_7_head);
        const Space v502_3 = intersect(constant_2,v502_2);
        const Space v502_4 = (has_head(v502_3) ? constant_3 : Space{});
        const Space v502_5 = subtract(constant_1,v502_4);
        Space v502_8;
        if (!v502_5.empty()) {
          const Path v503_6 = concat_path(v501_6,v501_7_head);
          const Space v503_7 = routine_94(c, v503_6, p1, v501_7_tail);
          v502_8 = compose(v502_5,v503_7);
        }
        const Space v502_9 = intersect(constant_2,v502_2);
        const Space v502_10 = (has_head(v502_9) ? constant_3 : Space{});
        Space v502_12;
        if (!v502_10.empty()) {
          const Path v504_6 = concat_path(v501_6,v501_7_head);
          const Space v504_11 = routine_95(c, v504_6, p1, v501_7_tail);
          v502_12 = compose(v502_10,v504_11);
        }
        const Space v502_13 = unite(v502_8,v502_12);
        v501_7_result = unite(v501_7_result,v502_13);
      }
      const Space v501_7 = std::move(v501_7_result);
      v500_8 = compose(v500_5,v501_7);
    }
    const Space v500_9 = intersect(constant_2,v500_2);
    const Space v500_10 = (has_head(v500_9) ? constant_3 : Space{});
    Space v500_12;
    if (!v500_10.empty()) {
      const Path v505_6 = concat_path(p0,v499_12_head);
      Space v505_11_result;
      for (int v505_11_label = 1; v505_11_label <= 2; ++v505_11_label) {
        const Space v505_11_tail = child(v499_12_tail,v505_11_label);
        if (v505_11_tail.empty()) continue;
        const Path v505_11_head{v505_11_label};
        const Space v506_2 = singleton(v505_11_head);
        const Space v506_3 = intersect(constant_2,v506_2);
        const Space v506_4 = (has_head(v506_3) ? constant_3 : Space{});
        const Space v506_5 = subtract(constant_1,v506_4);
        Space v506_8;
        if (!v506_5.empty()) {
          const Path v507_6 = concat_path(v505_6,v505_11_head);
          const Space v507_7 = routine_94(c, v507_6, p1, v505_11_tail);
          v506_8 = compose(v506_5,v507_7);
        }
        const Space v506_9 = intersect(constant_2,v506_2);
        const Space v506_10 = (has_head(v506_9) ? constant_3 : Space{});
        Space v506_12;
        if (!v506_10.empty()) {
          const Path v508_6 = concat_path(v505_6,v505_11_head);
          const Space v508_11 = routine_50(c, v508_6, p1, v505_11_tail);
          v506_12 = compose(v506_10,v508_11);
        }
        const Space v506_13 = unite(v506_8,v506_12);
        v505_11_result = unite(v505_11_result,v506_13);
      }
      const Space v505_11 = std::move(v505_11_result);
      v500_12 = compose(v500_10,v505_11);
    }
    const Space v500_13 = unite(v500_8,v500_12);
    v499_12_result = unite(v499_12_result,v500_13);
  }
  const Space v499_12 = std::move(v499_12_result);
  return v499_12;
}

static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v509_9_result;
  for (int v509_9_label = 1; v509_9_label <= 2; ++v509_9_label) {
    const Space v509_9_tail = child(s0,v509_9_label);
    if (v509_9_tail.empty()) continue;
    const Path v509_9_head{v509_9_label};
    const Space v510_2 = singleton(v509_9_head);
    const Space v510_3 = intersect(constant_2,v510_2);
    const Space v510_4 = (has_head(v510_3) ? constant_3 : Space{});
    const Space v510_5 = subtract(constant_1,v510_4);
    Space v510_8;
    if (!v510_5.empty()) {
      const Path v511_6 = concat_path(p0,v509_9_head);
      Space v511_7_result;
      for (int v511_7_label = 1; v511_7_label <= 2; ++v511_7_label) {
        const Space v511_7_tail = child(v509_9_tail,v511_7_label);
        if (v511_7_tail.empty()) continue;
        const Path v511_7_head{v511_7_label};
        const Space v512_2 = singleton(v511_7_head);
        const Space v512_3 = intersect(constant_2,v512_2);
        const Space v512_4 = (has_head(v512_3) ? constant_3 : Space{});
        const Space v512_5 = subtract(constant_1,v512_4);
        Space v512_8;
        if (!v512_5.empty()) {
          const Path v513_6 = concat_path(v511_6,v511_7_head);
          const Space v513_7 = routine_94(c, v513_6, p1, v511_7_tail);
          v512_8 = compose(v512_5,v513_7);
        }
        const Space v512_9 = intersect(constant_2,v512_2);
        const Space v512_10 = (has_head(v512_9) ? constant_3 : Space{});
        Space v512_12;
        if (!v512_10.empty()) {
          const Path v514_6 = concat_path(v511_6,v511_7_head);
          const Space v514_11 = routine_95(c, v514_6, p1, v511_7_tail);
          v512_12 = compose(v512_10,v514_11);
        }
        const Space v512_13 = unite(v512_8,v512_12);
        v511_7_result = unite(v511_7_result,v512_13);
      }
      const Space v511_7 = std::move(v511_7_result);
      v510_8 = compose(v510_5,v511_7);
    }
    const Space v510_9 = intersect(constant_2,v510_2);
    const Space v510_10 = (has_head(v510_9) ? constant_3 : Space{});
    const Space v510_11 = compose(v510_10,v509_9_tail);
    const Path v515_6 = concat_path(p0,v509_9_head);
    const Space v510_12 = wrap(v510_11,v515_6);
    const Space v510_13 = wrap(v510_12,p1);
    const Space v510_14 = unite(v510_8,v510_13);
    v509_9_result = unite(v509_9_result,v510_14);
  }
  const Space v509_9 = std::move(v509_9_result);
  return v509_9;
}

static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v516_3 = wrap(s0,p0);
  const Space v516_4 = wrap(v516_3,p1);
  return v516_4;
}

static Space routine_51(Context& c, const Path& p0, const Space& s0) {
  Space v517_11_result;
  for (int v517_11_label = 1; v517_11_label <= 2; ++v517_11_label) {
    const Space v517_11_tail = child(s0,v517_11_label);
    if (v517_11_tail.empty()) continue;
    const Path v517_11_head{v517_11_label};
    const Space v518_2 = singleton(v517_11_head);
    const Space v518_3 = intersect(constant_2,v518_2);
    const Space v518_4 = (has_head(v518_3) ? constant_3 : Space{});
    const Space v518_5 = subtract(constant_1,v518_4);
    Space v518_8;
    if (!v518_5.empty()) {
      const Path v519_6 = concat_path(p0,v517_11_head);
      Space v519_7_result;
      for (int v519_7_label = 1; v519_7_label <= 2; ++v519_7_label) {
        const Space v519_7_tail = child(v517_11_tail,v519_7_label);
        if (v519_7_tail.empty()) continue;
        const Path v519_7_head{v519_7_label};
        const Space v520_2 = singleton(v519_7_head);
        const Space v520_3 = intersect(constant_2,v520_2);
        const Space v520_4 = (has_head(v520_3) ? constant_3 : Space{});
        const Space v520_5 = subtract(constant_1,v520_4);
        Space v520_8;
        if (!v520_5.empty()) {
          const Path v521_6 = concat_path(v519_6,v519_7_head);
          const Space v521_7 = routine_96(c, v521_6, v519_7_tail);
          v520_8 = compose(v520_5,v521_7);
        }
        const Space v520_9 = intersect(constant_2,v520_2);
        const Space v520_10 = (has_head(v520_9) ? constant_3 : Space{});
        Space v520_12;
        if (!v520_10.empty()) {
          const Path v522_6 = concat_path(v519_6,v519_7_head);
          const Space v522_11 = routine_97(c, v522_6, v519_7_tail);
          v520_12 = compose(v520_10,v522_11);
        }
        const Space v520_13 = unite(v520_8,v520_12);
        v519_7_result = unite(v519_7_result,v520_13);
      }
      const Space v519_7 = std::move(v519_7_result);
      v518_8 = compose(v518_5,v519_7);
    }
    const Space v518_9 = intersect(constant_2,v518_2);
    const Space v518_10 = (has_head(v518_9) ? constant_3 : Space{});
    Space v518_12;
    if (!v518_10.empty()) {
      const Path v523_6 = concat_path(p0,v517_11_head);
      Space v523_11_result;
      for (int v523_11_label = 1; v523_11_label <= 2; ++v523_11_label) {
        const Space v523_11_tail = child(v517_11_tail,v523_11_label);
        if (v523_11_tail.empty()) continue;
        const Path v523_11_head{v523_11_label};
        const Space v524_2 = singleton(v523_11_head);
        const Space v524_3 = intersect(constant_2,v524_2);
        const Space v524_4 = (has_head(v524_3) ? constant_3 : Space{});
        const Space v524_5 = subtract(constant_1,v524_4);
        Space v524_8;
        if (!v524_5.empty()) {
          const Path v525_6 = concat_path(v523_6,v523_11_head);
          const Space v525_7 = routine_96(c, v525_6, v523_11_tail);
          v524_8 = compose(v524_5,v525_7);
        }
        const Space v524_9 = intersect(constant_2,v524_2);
        const Space v524_10 = (has_head(v524_9) ? constant_3 : Space{});
        Space v524_12;
        if (!v524_10.empty()) {
          const Path v526_6 = concat_path(v523_6,v523_11_head);
          const Space v526_11 = routine_3(c, v526_6, v523_11_tail);
          v524_12 = compose(v524_10,v526_11);
        }
        const Space v524_13 = unite(v524_8,v524_12);
        v523_11_result = unite(v523_11_result,v524_13);
      }
      const Space v523_11 = std::move(v523_11_result);
      v518_12 = compose(v518_10,v523_11);
    }
    const Space v518_13 = unite(v518_8,v518_12);
    v517_11_result = unite(v517_11_result,v518_13);
  }
  const Space v517_11 = std::move(v517_11_result);
  return v517_11;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0) {
  Space v527_11_result;
  for (int v527_11_label = 1; v527_11_label <= 2; ++v527_11_label) {
    const Space v527_11_tail = child(s0,v527_11_label);
    if (v527_11_tail.empty()) continue;
    const Path v527_11_head{v527_11_label};
    const Space v528_2 = singleton(v527_11_head);
    const Space v528_3 = intersect(constant_2,v528_2);
    const Space v528_4 = (has_head(v528_3) ? constant_3 : Space{});
    const Space v528_5 = subtract(constant_1,v528_4);
    Space v528_8;
    if (!v528_5.empty()) {
      const Path v529_6 = concat_path(p0,v527_11_head);
      Space v529_7_result;
      for (int v529_7_label = 1; v529_7_label <= 2; ++v529_7_label) {
        const Space v529_7_tail = child(v527_11_tail,v529_7_label);
        if (v529_7_tail.empty()) continue;
        const Path v529_7_head{v529_7_label};
        const Space v530_2 = singleton(v529_7_head);
        const Space v530_3 = intersect(constant_2,v530_2);
        const Space v530_4 = (has_head(v530_3) ? constant_3 : Space{});
        const Space v530_5 = subtract(constant_1,v530_4);
        Space v530_8;
        if (!v530_5.empty()) {
          const Path v531_6 = concat_path(v529_6,v529_7_head);
          const Space v531_7 = routine_96(c, v531_6, v529_7_tail);
          v530_8 = compose(v530_5,v531_7);
        }
        const Space v530_9 = intersect(constant_2,v530_2);
        const Space v530_10 = (has_head(v530_9) ? constant_3 : Space{});
        Space v530_12;
        if (!v530_10.empty()) {
          const Path v532_6 = concat_path(v529_6,v529_7_head);
          const Space v532_11 = routine_97(c, v532_6, v529_7_tail);
          v530_12 = compose(v530_10,v532_11);
        }
        const Space v530_13 = unite(v530_8,v530_12);
        v529_7_result = unite(v529_7_result,v530_13);
      }
      const Space v529_7 = std::move(v529_7_result);
      v528_8 = compose(v528_5,v529_7);
    }
    const Space v528_9 = intersect(constant_2,v528_2);
    const Space v528_10 = (has_head(v528_9) ? constant_3 : Space{});
    Space v528_12;
    if (!v528_10.empty()) {
      const Path v533_6 = concat_path(p0,v527_11_head);
      Space v533_11_result;
      for (int v533_11_label = 1; v533_11_label <= 2; ++v533_11_label) {
        const Space v533_11_tail = child(v527_11_tail,v533_11_label);
        if (v533_11_tail.empty()) continue;
        const Path v533_11_head{v533_11_label};
        const Space v534_2 = singleton(v533_11_head);
        const Space v534_3 = intersect(constant_2,v534_2);
        const Space v534_4 = (has_head(v534_3) ? constant_3 : Space{});
        const Space v534_5 = subtract(constant_1,v534_4);
        Space v534_7;
        if (!v534_5.empty()) {
          const Space v535_6 = routine_18(c, v533_11_head, v533_6, v533_11_tail);
          v534_7 = compose(v534_5,v535_6);
        }
        const Space v534_8 = intersect(constant_2,v534_2);
        const Space v534_9 = (has_head(v534_8) ? constant_3 : Space{});
        Space v534_11;
        if (!v534_9.empty()) {
          const Space v536_10 = routine_19(c, v533_11_head, v533_6, v533_11_tail);
          v534_11 = compose(v534_9,v536_10);
        }
        const Space v534_12 = unite(v534_7,v534_11);
        v533_11_result = unite(v533_11_result,v534_12);
      }
      const Space v533_11 = std::move(v533_11_result);
      v528_12 = compose(v528_10,v533_11);
    }
    const Space v528_13 = unite(v528_8,v528_12);
    v527_11_result = unite(v527_11_result,v528_13);
  }
  const Space v527_11 = std::move(v527_11_result);
  return v527_11;
}

static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v537_12_result;
  for (int v537_12_label = 1; v537_12_label <= 2; ++v537_12_label) {
    const Space v537_12_tail = child(s0,v537_12_label);
    if (v537_12_tail.empty()) continue;
    const Path v537_12_head{v537_12_label};
    const Space v538_2 = singleton(v537_12_head);
    const Space v538_3 = intersect(constant_2,v538_2);
    const Space v538_4 = (has_head(v538_3) ? constant_3 : Space{});
    const Space v538_5 = subtract(constant_1,v538_4);
    Space v538_8;
    if (!v538_5.empty()) {
      const Path v539_6 = concat_path(p0,v537_12_head);
      Space v539_7_result;
      for (int v539_7_label = 1; v539_7_label <= 2; ++v539_7_label) {
        const Space v539_7_tail = child(v537_12_tail,v539_7_label);
        if (v539_7_tail.empty()) continue;
        const Path v539_7_head{v539_7_label};
        const Space v540_2 = singleton(v539_7_head);
        const Space v540_3 = intersect(constant_2,v540_2);
        const Space v540_4 = (has_head(v540_3) ? constant_3 : Space{});
        const Space v540_5 = subtract(constant_1,v540_4);
        Space v540_8;
        if (!v540_5.empty()) {
          const Path v541_6 = concat_path(v539_6,v539_7_head);
          const Space v541_7 = routine_98(c, v541_6, p1, v539_7_tail);
          v540_8 = compose(v540_5,v541_7);
        }
        const Space v540_9 = intersect(constant_2,v540_2);
        const Space v540_10 = (has_head(v540_9) ? constant_3 : Space{});
        Space v540_12;
        if (!v540_10.empty()) {
          const Path v542_6 = concat_path(v539_6,v539_7_head);
          const Space v542_11 = routine_99(c, v542_6, p1, v539_7_tail);
          v540_12 = compose(v540_10,v542_11);
        }
        const Space v540_13 = unite(v540_8,v540_12);
        v539_7_result = unite(v539_7_result,v540_13);
      }
      const Space v539_7 = std::move(v539_7_result);
      v538_8 = compose(v538_5,v539_7);
    }
    const Space v538_9 = intersect(constant_2,v538_2);
    const Space v538_10 = (has_head(v538_9) ? constant_3 : Space{});
    Space v538_12;
    if (!v538_10.empty()) {
      const Path v543_6 = concat_path(p0,v537_12_head);
      Space v543_11_result;
      for (int v543_11_label = 1; v543_11_label <= 2; ++v543_11_label) {
        const Space v543_11_tail = child(v537_12_tail,v543_11_label);
        if (v543_11_tail.empty()) continue;
        const Path v543_11_head{v543_11_label};
        const Space v544_2 = singleton(v543_11_head);
        const Space v544_3 = intersect(constant_2,v544_2);
        const Space v544_4 = (has_head(v544_3) ? constant_3 : Space{});
        const Space v544_5 = subtract(constant_1,v544_4);
        Space v544_8;
        if (!v544_5.empty()) {
          const Path v545_6 = concat_path(v543_6,v543_11_head);
          const Space v545_7 = routine_98(c, v545_6, p1, v543_11_tail);
          v544_8 = compose(v544_5,v545_7);
        }
        const Space v544_9 = intersect(constant_2,v544_2);
        const Space v544_10 = (has_head(v544_9) ? constant_3 : Space{});
        Space v544_12;
        if (!v544_10.empty()) {
          const Path v546_6 = concat_path(v543_6,v543_11_head);
          const Space v546_11 = routine_22(c, v546_6, p1, v543_11_tail);
          v544_12 = compose(v544_10,v546_11);
        }
        const Space v544_13 = unite(v544_8,v544_12);
        v543_11_result = unite(v543_11_result,v544_13);
      }
      const Space v543_11 = std::move(v543_11_result);
      v538_12 = compose(v538_10,v543_11);
    }
    const Space v538_13 = unite(v538_8,v538_12);
    v537_12_result = unite(v537_12_result,v538_13);
  }
  const Space v537_12 = std::move(v537_12_result);
  return v537_12;
}

static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v547_10_result;
  for (int v547_10_label = 1; v547_10_label <= 2; ++v547_10_label) {
    const Space v547_10_tail = child(s0,v547_10_label);
    if (v547_10_tail.empty()) continue;
    const Path v547_10_head{v547_10_label};
    const Space v548_2 = singleton(v547_10_head);
    const Space v548_3 = intersect(constant_2,v548_2);
    const Space v548_4 = (has_head(v548_3) ? constant_3 : Space{});
    const Space v548_5 = compose(v548_4,v547_10_tail);
    const Path v549_6 = concat_path(p0,v547_10_head);
    const Space v548_7 = wrap(v548_5,v549_6);
    const Space v548_8 = wrap(v548_7,p1);
    const Space v548_9 = wrap(v548_8,constant_6);
    const Space v548_10 = intersect(constant_2,v548_2);
    const Space v548_11 = (has_head(v548_10) ? constant_3 : Space{});
    const Space v548_12 = subtract(constant_1,v548_11);
    Space v548_14;
    if (!v548_12.empty()) {
      Space v550_13_result;
      for (int v550_13_label = 1; v550_13_label <= 2; ++v550_13_label) {
        const Space v550_13_tail = child(v547_10_tail,v550_13_label);
        if (v550_13_tail.empty()) continue;
        const Path v550_13_head{v550_13_label};
        const Space v551_2 = singleton(v550_13_head);
        const Space v551_3 = intersect(constant_2,v551_2);
        const Space v551_4 = (has_head(v551_3) ? constant_3 : Space{});
        const Space v551_5 = subtract(constant_1,v551_4);
        Space v551_8;
        if (!v551_5.empty()) {
          const Path v552_6 = concat_path(v549_6,v550_13_head);
          const Space v552_7 = routine_98(c, v552_6, p1, v550_13_tail);
          v551_8 = compose(v551_5,v552_7);
        }
        const Space v551_9 = intersect(constant_2,v551_2);
        const Space v551_10 = (has_head(v551_9) ? constant_3 : Space{});
        Space v551_12;
        if (!v551_10.empty()) {
          const Path v553_6 = concat_path(v549_6,v550_13_head);
          const Space v553_11 = routine_99(c, v553_6, p1, v550_13_tail);
          v551_12 = compose(v551_10,v553_11);
        }
        const Space v551_13 = unite(v551_8,v551_12);
        v550_13_result = unite(v550_13_result,v551_13);
      }
      const Space v550_13 = std::move(v550_13_result);
      v548_14 = compose(v548_12,v550_13);
    }
    const Space v548_15 = unite(v548_9,v548_14);
    v547_10_result = unite(v547_10_result,v548_15);
  }
  const Space v547_10 = std::move(v547_10_result);
  return v547_10;
}

static Space routine_55(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v554_12_result;
  for (int v554_12_label = 1; v554_12_label <= 2; ++v554_12_label) {
    const Space v554_12_tail = child(s0,v554_12_label);
    if (v554_12_tail.empty()) continue;
    const Path v554_12_head{v554_12_label};
    const Space v555_2 = singleton(v554_12_head);
    const Space v555_3 = intersect(constant_2,v555_2);
    const Space v555_4 = (has_head(v555_3) ? constant_3 : Space{});
    const Space v555_5 = subtract(constant_1,v555_4);
    Space v555_8;
    if (!v555_5.empty()) {
      const Path v556_6 = concat_path(p0,v554_12_head);
      Space v556_7_result;
      for (int v556_7_label = 1; v556_7_label <= 2; ++v556_7_label) {
        const Space v556_7_tail = child(v554_12_tail,v556_7_label);
        if (v556_7_tail.empty()) continue;
        const Path v556_7_head{v556_7_label};
        const Space v557_2 = singleton(v556_7_head);
        const Space v557_3 = intersect(constant_2,v557_2);
        const Space v557_4 = (has_head(v557_3) ? constant_3 : Space{});
        const Space v557_5 = subtract(constant_1,v557_4);
        Space v557_8;
        if (!v557_5.empty()) {
          const Path v558_6 = concat_path(v556_6,v556_7_head);
          const Space v558_7 = routine_100(c, v558_6, p1, v556_7_tail);
          v557_8 = compose(v557_5,v558_7);
        }
        const Space v557_9 = intersect(constant_2,v557_2);
        const Space v557_10 = (has_head(v557_9) ? constant_3 : Space{});
        Space v557_12;
        if (!v557_10.empty()) {
          const Path v559_6 = concat_path(v556_6,v556_7_head);
          const Space v559_11 = routine_101(c, v559_6, p1, v556_7_tail);
          v557_12 = compose(v557_10,v559_11);
        }
        const Space v557_13 = unite(v557_8,v557_12);
        v556_7_result = unite(v556_7_result,v557_13);
      }
      const Space v556_7 = std::move(v556_7_result);
      v555_8 = compose(v555_5,v556_7);
    }
    const Space v555_9 = intersect(constant_2,v555_2);
    const Space v555_10 = (has_head(v555_9) ? constant_3 : Space{});
    Space v555_12;
    if (!v555_10.empty()) {
      const Path v560_6 = concat_path(p0,v554_12_head);
      Space v560_11_result;
      for (int v560_11_label = 1; v560_11_label <= 2; ++v560_11_label) {
        const Space v560_11_tail = child(v554_12_tail,v560_11_label);
        if (v560_11_tail.empty()) continue;
        const Path v560_11_head{v560_11_label};
        const Space v561_2 = singleton(v560_11_head);
        const Space v561_3 = intersect(constant_2,v561_2);
        const Space v561_4 = (has_head(v561_3) ? constant_3 : Space{});
        const Space v561_5 = subtract(constant_1,v561_4);
        Space v561_8;
        if (!v561_5.empty()) {
          const Path v562_6 = concat_path(v560_6,v560_11_head);
          const Space v562_7 = routine_100(c, v562_6, p1, v560_11_tail);
          v561_8 = compose(v561_5,v562_7);
        }
        const Space v561_9 = intersect(constant_2,v561_2);
        const Space v561_10 = (has_head(v561_9) ? constant_3 : Space{});
        Space v561_12;
        if (!v561_10.empty()) {
          const Path v563_6 = concat_path(v560_6,v560_11_head);
          const Space v563_11 = routine_22(c, v563_6, p1, v560_11_tail);
          v561_12 = compose(v561_10,v563_11);
        }
        const Space v561_13 = unite(v561_8,v561_12);
        v560_11_result = unite(v560_11_result,v561_13);
      }
      const Space v560_11 = std::move(v560_11_result);
      v555_12 = compose(v555_10,v560_11);
    }
    const Space v555_13 = unite(v555_8,v555_12);
    v554_12_result = unite(v554_12_result,v555_13);
  }
  const Space v554_12 = std::move(v554_12_result);
  return v554_12;
}

static Space routine_56(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v564_10_result;
  for (int v564_10_label = 1; v564_10_label <= 2; ++v564_10_label) {
    const Space v564_10_tail = child(s0,v564_10_label);
    if (v564_10_tail.empty()) continue;
    const Path v564_10_head{v564_10_label};
    const Space v565_2 = singleton(v564_10_head);
    const Space v565_3 = intersect(constant_2,v565_2);
    const Space v565_4 = (has_head(v565_3) ? constant_3 : Space{});
    const Space v565_5 = compose(v565_4,v564_10_tail);
    const Path v566_6 = concat_path(p0,v564_10_head);
    const Space v565_7 = wrap(v565_5,v566_6);
    const Space v565_8 = wrap(v565_7,p1);
    const Space v565_9 = wrap(v565_8,constant_6);
    const Space v565_10 = intersect(constant_2,v565_2);
    const Space v565_11 = (has_head(v565_10) ? constant_3 : Space{});
    const Space v565_12 = subtract(constant_1,v565_11);
    Space v565_14;
    if (!v565_12.empty()) {
      Space v567_13_result;
      for (int v567_13_label = 1; v567_13_label <= 2; ++v567_13_label) {
        const Space v567_13_tail = child(v564_10_tail,v567_13_label);
        if (v567_13_tail.empty()) continue;
        const Path v567_13_head{v567_13_label};
        const Space v568_2 = singleton(v567_13_head);
        const Space v568_3 = intersect(constant_2,v568_2);
        const Space v568_4 = (has_head(v568_3) ? constant_3 : Space{});
        const Space v568_5 = subtract(constant_1,v568_4);
        Space v568_8;
        if (!v568_5.empty()) {
          const Path v569_6 = concat_path(v566_6,v567_13_head);
          const Space v569_7 = routine_100(c, v569_6, p1, v567_13_tail);
          v568_8 = compose(v568_5,v569_7);
        }
        const Space v568_9 = intersect(constant_2,v568_2);
        const Space v568_10 = (has_head(v568_9) ? constant_3 : Space{});
        Space v568_12;
        if (!v568_10.empty()) {
          const Path v570_6 = concat_path(v566_6,v567_13_head);
          const Space v570_11 = routine_101(c, v570_6, p1, v567_13_tail);
          v568_12 = compose(v568_10,v570_11);
        }
        const Space v568_13 = unite(v568_8,v568_12);
        v567_13_result = unite(v567_13_result,v568_13);
      }
      const Space v567_13 = std::move(v567_13_result);
      v565_14 = compose(v565_12,v567_13);
    }
    const Space v565_15 = unite(v565_9,v565_14);
    v564_10_result = unite(v564_10_result,v565_15);
  }
  const Space v564_10 = std::move(v564_10_result);
  return v564_10;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v571_12_result;
  for (int v571_12_label = 1; v571_12_label <= 2; ++v571_12_label) {
    const Space v571_12_tail = child(s0,v571_12_label);
    if (v571_12_tail.empty()) continue;
    const Path v571_12_head{v571_12_label};
    const Space v572_2 = singleton(v571_12_head);
    const Space v572_3 = intersect(constant_2,v572_2);
    const Space v572_4 = (has_head(v572_3) ? constant_3 : Space{});
    const Space v572_5 = subtract(constant_1,v572_4);
    Space v572_8;
    if (!v572_5.empty()) {
      const Path v573_6 = concat_path(p0,v571_12_head);
      Space v573_7_result;
      for (int v573_7_label = 1; v573_7_label <= 2; ++v573_7_label) {
        const Space v573_7_tail = child(v571_12_tail,v573_7_label);
        if (v573_7_tail.empty()) continue;
        const Path v573_7_head{v573_7_label};
        const Space v574_2 = singleton(v573_7_head);
        const Space v574_3 = intersect(constant_2,v574_2);
        const Space v574_4 = (has_head(v574_3) ? constant_3 : Space{});
        const Space v574_5 = subtract(constant_1,v574_4);
        Space v574_8;
        if (!v574_5.empty()) {
          const Path v575_6 = concat_path(v573_6,v573_7_head);
          const Space v575_7 = routine_102(c, v575_6, v573_7_tail, s1);
          v574_8 = compose(v574_5,v575_7);
        }
        const Space v574_9 = intersect(constant_2,v574_2);
        const Space v574_10 = (has_head(v574_9) ? constant_3 : Space{});
        Space v574_12;
        if (!v574_10.empty()) {
          const Path v576_6 = concat_path(v573_6,v573_7_head);
          const Space v576_11 = routine_103(c, v576_6, v573_7_tail, s1);
          v574_12 = compose(v574_10,v576_11);
        }
        const Space v574_13 = unite(v574_8,v574_12);
        v573_7_result = unite(v573_7_result,v574_13);
      }
      const Space v573_7 = std::move(v573_7_result);
      v572_8 = compose(v572_5,v573_7);
    }
    const Space v572_9 = intersect(constant_2,v572_2);
    const Space v572_10 = (has_head(v572_9) ? constant_3 : Space{});
    Space v572_12;
    if (!v572_10.empty()) {
      const Path v577_6 = concat_path(p0,v571_12_head);
      Space v577_11_result;
      for (int v577_11_label = 1; v577_11_label <= 2; ++v577_11_label) {
        const Space v577_11_tail = child(v571_12_tail,v577_11_label);
        if (v577_11_tail.empty()) continue;
        const Path v577_11_head{v577_11_label};
        const Space v578_2 = singleton(v577_11_head);
        const Space v578_3 = intersect(constant_2,v578_2);
        const Space v578_4 = (has_head(v578_3) ? constant_3 : Space{});
        const Space v578_5 = subtract(constant_1,v578_4);
        Space v578_8;
        if (!v578_5.empty()) {
          const Path v579_6 = concat_path(v577_6,v577_11_head);
          const Space v579_7 = routine_102(c, v579_6, v577_11_tail, s1);
          v578_8 = compose(v578_5,v579_7);
        }
        const Space v578_9 = intersect(constant_2,v578_2);
        const Space v578_10 = (has_head(v578_9) ? constant_3 : Space{});
        Space v578_12;
        if (!v578_10.empty()) {
          const Path v580_6 = concat_path(v577_6,v577_11_head);
          const Space v580_11 = routine_6(c, v580_6, v577_11_tail, s1);
          v578_12 = compose(v578_10,v580_11);
        }
        const Space v578_13 = unite(v578_8,v578_12);
        v577_11_result = unite(v577_11_result,v578_13);
      }
      const Space v577_11 = std::move(v577_11_result);
      v572_12 = compose(v572_10,v577_11);
    }
    const Space v572_13 = unite(v572_8,v572_12);
    v571_12_result = unite(v571_12_result,v572_13);
  }
  const Space v571_12 = std::move(v571_12_result);
  return v571_12;
}

static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v581_12_result;
  for (int v581_12_label = 1; v581_12_label <= 2; ++v581_12_label) {
    const Space v581_12_tail = child(s0,v581_12_label);
    if (v581_12_tail.empty()) continue;
    const Path v581_12_head{v581_12_label};
    const Space v582_2 = singleton(v581_12_head);
    const Space v582_3 = intersect(constant_2,v582_2);
    const Space v582_4 = (has_head(v582_3) ? constant_3 : Space{});
    const Space v582_5 = subtract(constant_1,v582_4);
    Space v582_8;
    if (!v582_5.empty()) {
      const Path v583_6 = concat_path(p0,v581_12_head);
      Space v583_7_result;
      for (int v583_7_label = 1; v583_7_label <= 2; ++v583_7_label) {
        const Space v583_7_tail = child(v581_12_tail,v583_7_label);
        if (v583_7_tail.empty()) continue;
        const Path v583_7_head{v583_7_label};
        const Space v584_2 = singleton(v583_7_head);
        const Space v584_3 = intersect(constant_2,v584_2);
        const Space v584_4 = (has_head(v584_3) ? constant_3 : Space{});
        const Space v584_5 = subtract(constant_1,v584_4);
        Space v584_8;
        if (!v584_5.empty()) {
          const Path v585_6 = concat_path(v583_6,v583_7_head);
          const Space v585_7 = routine_102(c, v585_6, v583_7_tail, s1);
          v584_8 = compose(v584_5,v585_7);
        }
        const Space v584_9 = intersect(constant_2,v584_2);
        const Space v584_10 = (has_head(v584_9) ? constant_3 : Space{});
        Space v584_12;
        if (!v584_10.empty()) {
          const Path v586_6 = concat_path(v583_6,v583_7_head);
          const Space v586_11 = routine_103(c, v586_6, v583_7_tail, s1);
          v584_12 = compose(v584_10,v586_11);
        }
        const Space v584_13 = unite(v584_8,v584_12);
        v583_7_result = unite(v583_7_result,v584_13);
      }
      const Space v583_7 = std::move(v583_7_result);
      v582_8 = compose(v582_5,v583_7);
    }
    const Space v582_9 = intersect(constant_2,v582_2);
    const Space v582_10 = (has_head(v582_9) ? constant_3 : Space{});
    Space v582_12;
    if (!v582_10.empty()) {
      const Path v587_6 = concat_path(p0,v581_12_head);
      Space v587_11_result;
      for (int v587_11_label = 1; v587_11_label <= 2; ++v587_11_label) {
        const Space v587_11_tail = child(v581_12_tail,v587_11_label);
        if (v587_11_tail.empty()) continue;
        const Path v587_11_head{v587_11_label};
        const Space v588_2 = singleton(v587_11_head);
        const Space v588_3 = intersect(constant_2,v588_2);
        const Space v588_4 = (has_head(v588_3) ? constant_3 : Space{});
        const Space v588_5 = subtract(constant_1,v588_4);
        Space v588_7;
        if (!v588_5.empty()) {
          const Space v589_6 = routine_25(c, v587_11_head, v587_6, v587_11_tail, s1);
          v588_7 = compose(v588_5,v589_6);
        }
        const Space v588_8 = intersect(constant_2,v588_2);
        const Space v588_9 = (has_head(v588_8) ? constant_3 : Space{});
        Space v588_11;
        if (!v588_9.empty()) {
          const Space v590_10 = routine_26(c, v587_11_head, v587_6, v587_11_tail, s1);
          v588_11 = compose(v588_9,v590_10);
        }
        const Space v588_12 = unite(v588_7,v588_11);
        v587_11_result = unite(v587_11_result,v588_12);
      }
      const Space v587_11 = std::move(v587_11_result);
      v582_12 = compose(v582_10,v587_11);
    }
    const Space v582_13 = unite(v582_8,v582_12);
    v581_12_result = unite(v581_12_result,v582_13);
  }
  const Space v581_12 = std::move(v581_12_result);
  return v581_12;
}

static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v591_13_result;
  for (int v591_13_label = 1; v591_13_label <= 2; ++v591_13_label) {
    const Space v591_13_tail = child(s0,v591_13_label);
    if (v591_13_tail.empty()) continue;
    const Path v591_13_head{v591_13_label};
    const Space v592_2 = singleton(v591_13_head);
    const Space v592_3 = intersect(constant_2,v592_2);
    const Space v592_4 = (has_head(v592_3) ? constant_3 : Space{});
    const Space v592_5 = subtract(constant_1,v592_4);
    Space v592_8;
    if (!v592_5.empty()) {
      const Path v593_6 = concat_path(p0,v591_13_head);
      Space v593_7_result;
      for (int v593_7_label = 1; v593_7_label <= 2; ++v593_7_label) {
        const Space v593_7_tail = child(v591_13_tail,v593_7_label);
        if (v593_7_tail.empty()) continue;
        const Path v593_7_head{v593_7_label};
        const Space v594_2 = singleton(v593_7_head);
        const Space v594_3 = intersect(constant_2,v594_2);
        const Space v594_4 = (has_head(v594_3) ? constant_3 : Space{});
        const Space v594_5 = subtract(constant_1,v594_4);
        Space v594_8;
        if (!v594_5.empty()) {
          const Path v595_6 = concat_path(v593_6,v593_7_head);
          const Space v595_7 = routine_104(c, v595_6, p1, v593_7_tail, s1);
          v594_8 = compose(v594_5,v595_7);
        }
        const Space v594_9 = intersect(constant_2,v594_2);
        const Space v594_10 = (has_head(v594_9) ? constant_3 : Space{});
        Space v594_12;
        if (!v594_10.empty()) {
          const Path v596_6 = concat_path(v593_6,v593_7_head);
          const Space v596_11 = routine_105(c, v596_6, p1, v593_7_tail, s1);
          v594_12 = compose(v594_10,v596_11);
        }
        const Space v594_13 = unite(v594_8,v594_12);
        v593_7_result = unite(v593_7_result,v594_13);
      }
      const Space v593_7 = std::move(v593_7_result);
      v592_8 = compose(v592_5,v593_7);
    }
    const Space v592_9 = intersect(constant_2,v592_2);
    const Space v592_10 = (has_head(v592_9) ? constant_3 : Space{});
    Space v592_12;
    if (!v592_10.empty()) {
      const Path v597_6 = concat_path(p0,v591_13_head);
      Space v597_11_result;
      for (int v597_11_label = 1; v597_11_label <= 2; ++v597_11_label) {
        const Space v597_11_tail = child(v591_13_tail,v597_11_label);
        if (v597_11_tail.empty()) continue;
        const Path v597_11_head{v597_11_label};
        const Space v598_2 = singleton(v597_11_head);
        const Space v598_3 = intersect(constant_2,v598_2);
        const Space v598_4 = (has_head(v598_3) ? constant_3 : Space{});
        const Space v598_5 = subtract(constant_1,v598_4);
        Space v598_8;
        if (!v598_5.empty()) {
          const Path v599_6 = concat_path(v597_6,v597_11_head);
          const Space v599_7 = routine_104(c, v599_6, p1, v597_11_tail, s1);
          v598_8 = compose(v598_5,v599_7);
        }
        const Space v598_9 = intersect(constant_2,v598_2);
        const Space v598_10 = (has_head(v598_9) ? constant_3 : Space{});
        Space v598_12;
        if (!v598_10.empty()) {
          const Path v600_6 = concat_path(v597_6,v597_11_head);
          const Space v600_11 = routine_29(c, v600_6, p1, v597_11_tail, s1);
          v598_12 = compose(v598_10,v600_11);
        }
        const Space v598_13 = unite(v598_8,v598_12);
        v597_11_result = unite(v597_11_result,v598_13);
      }
      const Space v597_11 = std::move(v597_11_result);
      v592_12 = compose(v592_10,v597_11);
    }
    const Space v592_13 = unite(v592_8,v592_12);
    v591_13_result = unite(v591_13_result,v592_13);
  }
  const Space v591_13 = std::move(v591_13_result);
  return v591_13;
}

static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v601_8 = unwrap(s1,constant_5);
  const Space v601_10 = unwrap(v601_8,constant_6);
  const Space v601_11 = unwrap(v601_10,p0);
  Space v601_18_result;
  for (int v601_18_label = 1; v601_18_label <= 2; ++v601_18_label) {
    const Space v601_18_tail = child(s0,v601_18_label);
    if (v601_18_tail.empty()) continue;
    const Path v601_18_head{v601_18_label};
    const Space v602_2 = singleton(v601_18_head);
    const Space v602_3 = intersect(constant_2,v602_2);
    const Space v602_4 = (has_head(v602_3) ? constant_3 : Space{});
    const Space v602_5 = subtract(constant_1,v602_4);
    Space v602_8;
    if (!v602_5.empty()) {
      const Path v603_6 = concat_path(p0,v601_18_head);
      Space v603_7_result;
      for (int v603_7_label = 1; v603_7_label <= 2; ++v603_7_label) {
        const Space v603_7_tail = child(v601_18_tail,v603_7_label);
        if (v603_7_tail.empty()) continue;
        const Path v603_7_head{v603_7_label};
        const Space v604_2 = singleton(v603_7_head);
        const Space v604_3 = intersect(constant_2,v604_2);
        const Space v604_4 = (has_head(v604_3) ? constant_3 : Space{});
        const Space v604_5 = subtract(constant_1,v604_4);
        Space v604_8;
        if (!v604_5.empty()) {
          const Path v605_6 = concat_path(v603_6,v603_7_head);
          const Space v605_7 = routine_104(c, v605_6, p1, v603_7_tail, s1);
          v604_8 = compose(v604_5,v605_7);
        }
        const Space v604_9 = intersect(constant_2,v604_2);
        const Space v604_10 = (has_head(v604_9) ? constant_3 : Space{});
        Space v604_12;
        if (!v604_10.empty()) {
          const Path v606_6 = concat_path(v603_6,v603_7_head);
          const Space v606_11 = routine_105(c, v606_6, p1, v603_7_tail, s1);
          v604_12 = compose(v604_10,v606_11);
        }
        const Space v604_13 = unite(v604_8,v604_12);
        v603_7_result = unite(v603_7_result,v604_13);
      }
      const Space v603_7 = std::move(v603_7_result);
      v602_8 = compose(v602_5,v603_7);
    }
    const Space v602_9 = intersect(constant_2,v602_2);
    const Space v602_10 = (has_head(v602_9) ? constant_3 : Space{});
    Space v602_13;
    if (!v602_10.empty()) {
      const Space v607_11 = unwrap(v601_11,v601_18_head);
      Space v607_12_result;
      for (int v607_12_label = 1; v607_12_label <= 2; ++v607_12_label) {
        const Space v607_12_tail = child(v607_11,v607_12_label);
        if (v607_12_tail.empty()) continue;
        const Path v607_12_head{v607_12_label};
        const Space v608_2 = singleton(v607_12_head);
        const Space v608_3 = intersect(constant_2,v608_2);
        const Space v608_4 = (has_head(v608_3) ? constant_3 : Space{});
        const Space v608_5 = subtract(constant_1,v608_4);
        Space v608_7;
        if (!v608_5.empty()) {
          const Space v609_6 = routine_61(c, v607_12_head, p1, v607_12_tail);
          v608_7 = compose(v608_5,v609_6);
        }
        const Space v608_8 = intersect(constant_2,v608_2);
        const Space v608_9 = (has_head(v608_8) ? constant_3 : Space{});
        Space v608_11;
        if (!v608_9.empty()) {
          const Space v610_10 = routine_62(c, v607_12_head, p1, v607_12_tail);
          v608_11 = compose(v608_9,v610_10);
        }
        const Space v608_12 = unite(v608_7,v608_11);
        v607_12_result = unite(v607_12_result,v608_12);
      }
      const Space v607_12 = std::move(v607_12_result);
      v602_13 = compose(v602_10,v607_12);
    }
    const Space v602_14 = unite(v602_8,v602_13);
    v601_18_result = unite(v601_18_result,v602_14);
  }
  const Space v601_18 = std::move(v601_18_result);
  return v601_18;
}

static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v611_12_result;
  for (int v611_12_label = 1; v611_12_label <= 2; ++v611_12_label) {
    const Space v611_12_tail = child(s0,v611_12_label);
    if (v611_12_tail.empty()) continue;
    const Path v611_12_head{v611_12_label};
    const Space v612_2 = singleton(v611_12_head);
    const Space v612_3 = intersect(constant_2,v612_2);
    const Space v612_4 = (has_head(v612_3) ? constant_3 : Space{});
    const Space v612_5 = subtract(constant_1,v612_4);
    Space v612_8;
    if (!v612_5.empty()) {
      const Path v613_6 = concat_path(p0,v611_12_head);
      Space v613_7_result;
      for (int v613_7_label = 1; v613_7_label <= 2; ++v613_7_label) {
        const Space v613_7_tail = child(v611_12_tail,v613_7_label);
        if (v613_7_tail.empty()) continue;
        const Path v613_7_head{v613_7_label};
        const Space v614_2 = singleton(v613_7_head);
        const Space v614_3 = intersect(constant_2,v614_2);
        const Space v614_4 = (has_head(v614_3) ? constant_3 : Space{});
        const Space v614_5 = subtract(constant_1,v614_4);
        Space v614_8;
        if (!v614_5.empty()) {
          const Path v615_6 = concat_path(v613_6,v613_7_head);
          const Space v615_7 = routine_106(c, v615_6, p1, v613_7_tail);
          v614_8 = compose(v614_5,v615_7);
        }
        const Space v614_9 = intersect(constant_2,v614_2);
        const Space v614_10 = (has_head(v614_9) ? constant_3 : Space{});
        Space v614_12;
        if (!v614_10.empty()) {
          const Path v616_6 = concat_path(v613_6,v613_7_head);
          const Space v616_11 = routine_107(c, v616_6, p1, v613_7_tail);
          v614_12 = compose(v614_10,v616_11);
        }
        const Space v614_13 = unite(v614_8,v614_12);
        v613_7_result = unite(v613_7_result,v614_13);
      }
      const Space v613_7 = std::move(v613_7_result);
      v612_8 = compose(v612_5,v613_7);
    }
    const Space v612_9 = intersect(constant_2,v612_2);
    const Space v612_10 = (has_head(v612_9) ? constant_3 : Space{});
    Space v612_12;
    if (!v612_10.empty()) {
      const Path v617_6 = concat_path(p0,v611_12_head);
      Space v617_11_result;
      for (int v617_11_label = 1; v617_11_label <= 2; ++v617_11_label) {
        const Space v617_11_tail = child(v611_12_tail,v617_11_label);
        if (v617_11_tail.empty()) continue;
        const Path v617_11_head{v617_11_label};
        const Space v618_2 = singleton(v617_11_head);
        const Space v618_3 = intersect(constant_2,v618_2);
        const Space v618_4 = (has_head(v618_3) ? constant_3 : Space{});
        const Space v618_5 = subtract(constant_1,v618_4);
        Space v618_8;
        if (!v618_5.empty()) {
          const Path v619_6 = concat_path(v617_6,v617_11_head);
          const Space v619_7 = routine_106(c, v619_6, p1, v617_11_tail);
          v618_8 = compose(v618_5,v619_7);
        }
        const Space v618_9 = intersect(constant_2,v618_2);
        const Space v618_10 = (has_head(v618_9) ? constant_3 : Space{});
        Space v618_12;
        if (!v618_10.empty()) {
          const Path v620_6 = concat_path(v617_6,v617_11_head);
          const Space v620_11 = routine_67(c, v620_6, p1, v617_11_tail);
          v618_12 = compose(v618_10,v620_11);
        }
        const Space v618_13 = unite(v618_8,v618_12);
        v617_11_result = unite(v617_11_result,v618_13);
      }
      const Space v617_11 = std::move(v617_11_result);
      v612_12 = compose(v612_10,v617_11);
    }
    const Space v612_13 = unite(v612_8,v612_12);
    v611_12_result = unite(v611_12_result,v612_13);
  }
  const Space v611_12 = std::move(v611_12_result);
  return v611_12;
}

static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v621_9_result;
  for (int v621_9_label = 1; v621_9_label <= 2; ++v621_9_label) {
    const Space v621_9_tail = child(s0,v621_9_label);
    if (v621_9_tail.empty()) continue;
    const Path v621_9_head{v621_9_label};
    const Space v622_2 = singleton(v621_9_head);
    const Space v622_3 = intersect(constant_2,v622_2);
    const Space v622_4 = (has_head(v622_3) ? constant_3 : Space{});
    const Space v622_5 = subtract(constant_1,v622_4);
    Space v622_8;
    if (!v622_5.empty()) {
      const Path v623_6 = concat_path(p0,v621_9_head);
      Space v623_7_result;
      for (int v623_7_label = 1; v623_7_label <= 2; ++v623_7_label) {
        const Space v623_7_tail = child(v621_9_tail,v623_7_label);
        if (v623_7_tail.empty()) continue;
        const Path v623_7_head{v623_7_label};
        const Space v624_2 = singleton(v623_7_head);
        const Space v624_3 = intersect(constant_2,v624_2);
        const Space v624_4 = (has_head(v624_3) ? constant_3 : Space{});
        const Space v624_5 = subtract(constant_1,v624_4);
        Space v624_8;
        if (!v624_5.empty()) {
          const Path v625_6 = concat_path(v623_6,v623_7_head);
          const Space v625_7 = routine_106(c, v625_6, p1, v623_7_tail);
          v624_8 = compose(v624_5,v625_7);
        }
        const Space v624_9 = intersect(constant_2,v624_2);
        const Space v624_10 = (has_head(v624_9) ? constant_3 : Space{});
        Space v624_12;
        if (!v624_10.empty()) {
          const Path v626_6 = concat_path(v623_6,v623_7_head);
          const Space v626_11 = routine_107(c, v626_6, p1, v623_7_tail);
          v624_12 = compose(v624_10,v626_11);
        }
        const Space v624_13 = unite(v624_8,v624_12);
        v623_7_result = unite(v623_7_result,v624_13);
      }
      const Space v623_7 = std::move(v623_7_result);
      v622_8 = compose(v622_5,v623_7);
    }
    const Space v622_9 = intersect(constant_2,v622_2);
    const Space v622_10 = (has_head(v622_9) ? constant_3 : Space{});
    const Space v622_11 = compose(v622_10,v621_9_tail);
    const Path v627_6 = concat_path(p0,v621_9_head);
    const Space v622_12 = wrap(v622_11,v627_6);
    const Space v622_13 = wrap(v622_12,p1);
    const Space v622_14 = unite(v622_8,v622_13);
    v621_9_result = unite(v621_9_result,v622_14);
  }
  const Space v621_9 = std::move(v621_9_result);
  return v621_9;
}

static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v628_13_result;
  for (int v628_13_label = 1; v628_13_label <= 2; ++v628_13_label) {
    const Space v628_13_tail = child(s0,v628_13_label);
    if (v628_13_tail.empty()) continue;
    const Path v628_13_head{v628_13_label};
    const Space v629_2 = singleton(v628_13_head);
    const Space v629_3 = intersect(constant_2,v629_2);
    const Space v629_4 = (has_head(v629_3) ? constant_3 : Space{});
    const Space v629_5 = subtract(constant_1,v629_4);
    Space v629_8;
    if (!v629_5.empty()) {
      const Path v630_6 = concat_path(p0,v628_13_head);
      Space v630_7_result;
      for (int v630_7_label = 1; v630_7_label <= 2; ++v630_7_label) {
        const Space v630_7_tail = child(v628_13_tail,v630_7_label);
        if (v630_7_tail.empty()) continue;
        const Path v630_7_head{v630_7_label};
        const Space v631_2 = singleton(v630_7_head);
        const Space v631_3 = intersect(constant_2,v631_2);
        const Space v631_4 = (has_head(v631_3) ? constant_3 : Space{});
        const Space v631_5 = subtract(constant_1,v631_4);
        Space v631_8;
        if (!v631_5.empty()) {
          const Path v632_6 = concat_path(v630_6,v630_7_head);
          const Space v632_7 = routine_108(c, v632_6, p1, v630_7_tail, s1);
          v631_8 = compose(v631_5,v632_7);
        }
        const Space v631_9 = intersect(constant_2,v631_2);
        const Space v631_10 = (has_head(v631_9) ? constant_3 : Space{});
        Space v631_12;
        if (!v631_10.empty()) {
          const Path v633_6 = concat_path(v630_6,v630_7_head);
          const Space v633_11 = routine_109(c, v633_6, p1, v630_7_tail, s1);
          v631_12 = compose(v631_10,v633_11);
        }
        const Space v631_13 = unite(v631_8,v631_12);
        v630_7_result = unite(v630_7_result,v631_13);
      }
      const Space v630_7 = std::move(v630_7_result);
      v629_8 = compose(v629_5,v630_7);
    }
    const Space v629_9 = intersect(constant_2,v629_2);
    const Space v629_10 = (has_head(v629_9) ? constant_3 : Space{});
    Space v629_12;
    if (!v629_10.empty()) {
      const Path v634_6 = concat_path(p0,v628_13_head);
      Space v634_11_result;
      for (int v634_11_label = 1; v634_11_label <= 2; ++v634_11_label) {
        const Space v634_11_tail = child(v628_13_tail,v634_11_label);
        if (v634_11_tail.empty()) continue;
        const Path v634_11_head{v634_11_label};
        const Space v635_2 = singleton(v634_11_head);
        const Space v635_3 = intersect(constant_2,v635_2);
        const Space v635_4 = (has_head(v635_3) ? constant_3 : Space{});
        const Space v635_5 = subtract(constant_1,v635_4);
        Space v635_8;
        if (!v635_5.empty()) {
          const Path v636_6 = concat_path(v634_6,v634_11_head);
          const Space v636_7 = routine_108(c, v636_6, p1, v634_11_tail, s1);
          v635_8 = compose(v635_5,v636_7);
        }
        const Space v635_9 = intersect(constant_2,v635_2);
        const Space v635_10 = (has_head(v635_9) ? constant_3 : Space{});
        Space v635_12;
        if (!v635_10.empty()) {
          const Path v637_6 = concat_path(v634_6,v634_11_head);
          const Space v637_11 = routine_29(c, v637_6, p1, v634_11_tail, s1);
          v635_12 = compose(v635_10,v637_11);
        }
        const Space v635_13 = unite(v635_8,v635_12);
        v634_11_result = unite(v634_11_result,v635_13);
      }
      const Space v634_11 = std::move(v634_11_result);
      v629_12 = compose(v629_10,v634_11);
    }
    const Space v629_13 = unite(v629_8,v629_12);
    v628_13_result = unite(v628_13_result,v629_13);
  }
  const Space v628_13 = std::move(v628_13_result);
  return v628_13;
}

static Space routine_64(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v638_8 = unwrap(s1,constant_5);
  const Space v638_10 = unwrap(v638_8,constant_6);
  const Space v638_11 = unwrap(v638_10,p0);
  Space v638_18_result;
  for (int v638_18_label = 1; v638_18_label <= 2; ++v638_18_label) {
    const Space v638_18_tail = child(s0,v638_18_label);
    if (v638_18_tail.empty()) continue;
    const Path v638_18_head{v638_18_label};
    const Space v639_2 = singleton(v638_18_head);
    const Space v639_3 = intersect(constant_2,v639_2);
    const Space v639_4 = (has_head(v639_3) ? constant_3 : Space{});
    const Space v639_5 = subtract(constant_1,v639_4);
    Space v639_8;
    if (!v639_5.empty()) {
      const Path v640_6 = concat_path(p0,v638_18_head);
      Space v640_7_result;
      for (int v640_7_label = 1; v640_7_label <= 2; ++v640_7_label) {
        const Space v640_7_tail = child(v638_18_tail,v640_7_label);
        if (v640_7_tail.empty()) continue;
        const Path v640_7_head{v640_7_label};
        const Space v641_2 = singleton(v640_7_head);
        const Space v641_3 = intersect(constant_2,v641_2);
        const Space v641_4 = (has_head(v641_3) ? constant_3 : Space{});
        const Space v641_5 = subtract(constant_1,v641_4);
        Space v641_8;
        if (!v641_5.empty()) {
          const Path v642_6 = concat_path(v640_6,v640_7_head);
          const Space v642_7 = routine_108(c, v642_6, p1, v640_7_tail, s1);
          v641_8 = compose(v641_5,v642_7);
        }
        const Space v641_9 = intersect(constant_2,v641_2);
        const Space v641_10 = (has_head(v641_9) ? constant_3 : Space{});
        Space v641_12;
        if (!v641_10.empty()) {
          const Path v643_6 = concat_path(v640_6,v640_7_head);
          const Space v643_11 = routine_109(c, v643_6, p1, v640_7_tail, s1);
          v641_12 = compose(v641_10,v643_11);
        }
        const Space v641_13 = unite(v641_8,v641_12);
        v640_7_result = unite(v640_7_result,v641_13);
      }
      const Space v640_7 = std::move(v640_7_result);
      v639_8 = compose(v639_5,v640_7);
    }
    const Space v639_9 = intersect(constant_2,v639_2);
    const Space v639_10 = (has_head(v639_9) ? constant_3 : Space{});
    Space v639_13;
    if (!v639_10.empty()) {
      const Space v644_11 = unwrap(v638_11,v638_18_head);
      Space v644_12_result;
      for (int v644_12_label = 1; v644_12_label <= 2; ++v644_12_label) {
        const Space v644_12_tail = child(v644_11,v644_12_label);
        if (v644_12_tail.empty()) continue;
        const Path v644_12_head{v644_12_label};
        const Space v645_2 = singleton(v644_12_head);
        const Space v645_3 = intersect(constant_2,v645_2);
        const Space v645_4 = (has_head(v645_3) ? constant_3 : Space{});
        const Space v645_5 = subtract(constant_1,v645_4);
        Space v645_7;
        if (!v645_5.empty()) {
          const Space v646_6 = routine_61(c, v644_12_head, p1, v644_12_tail);
          v645_7 = compose(v645_5,v646_6);
        }
        const Space v645_8 = intersect(constant_2,v645_2);
        const Space v645_9 = (has_head(v645_8) ? constant_3 : Space{});
        Space v645_11;
        if (!v645_9.empty()) {
          const Space v647_10 = routine_62(c, v644_12_head, p1, v644_12_tail);
          v645_11 = compose(v645_9,v647_10);
        }
        const Space v645_12 = unite(v645_7,v645_11);
        v644_12_result = unite(v644_12_result,v645_12);
      }
      const Space v644_12 = std::move(v644_12_result);
      v639_13 = compose(v639_10,v644_12);
    }
    const Space v639_14 = unite(v639_8,v639_13);
    v638_18_result = unite(v638_18_result,v639_14);
  }
  const Space v638_18 = std::move(v638_18_result);
  return v638_18;
}

static Space routine_65(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v648_12_result;
  for (int v648_12_label = 1; v648_12_label <= 2; ++v648_12_label) {
    const Space v648_12_tail = child(s0,v648_12_label);
    if (v648_12_tail.empty()) continue;
    const Path v648_12_head{v648_12_label};
    const Space v649_2 = singleton(v648_12_head);
    const Space v649_3 = intersect(constant_2,v649_2);
    const Space v649_4 = (has_head(v649_3) ? constant_3 : Space{});
    const Space v649_5 = subtract(constant_1,v649_4);
    Space v649_8;
    if (!v649_5.empty()) {
      const Path v650_6 = concat_path(p0,v648_12_head);
      Space v650_7_result;
      for (int v650_7_label = 1; v650_7_label <= 2; ++v650_7_label) {
        const Space v650_7_tail = child(v648_12_tail,v650_7_label);
        if (v650_7_tail.empty()) continue;
        const Path v650_7_head{v650_7_label};
        const Space v651_2 = singleton(v650_7_head);
        const Space v651_3 = intersect(constant_2,v651_2);
        const Space v651_4 = (has_head(v651_3) ? constant_3 : Space{});
        const Space v651_5 = subtract(constant_1,v651_4);
        Space v651_8;
        if (!v651_5.empty()) {
          const Path v652_6 = concat_path(v650_6,v650_7_head);
          const Space v652_7 = routine_110(c, v652_6, p1, v650_7_tail);
          v651_8 = compose(v651_5,v652_7);
        }
        const Space v651_9 = intersect(constant_2,v651_2);
        const Space v651_10 = (has_head(v651_9) ? constant_3 : Space{});
        Space v651_12;
        if (!v651_10.empty()) {
          const Path v653_6 = concat_path(v650_6,v650_7_head);
          const Space v653_11 = routine_111(c, v653_6, p1, v650_7_tail);
          v651_12 = compose(v651_10,v653_11);
        }
        const Space v651_13 = unite(v651_8,v651_12);
        v650_7_result = unite(v650_7_result,v651_13);
      }
      const Space v650_7 = std::move(v650_7_result);
      v649_8 = compose(v649_5,v650_7);
    }
    const Space v649_9 = intersect(constant_2,v649_2);
    const Space v649_10 = (has_head(v649_9) ? constant_3 : Space{});
    Space v649_12;
    if (!v649_10.empty()) {
      const Path v654_6 = concat_path(p0,v648_12_head);
      Space v654_11_result;
      for (int v654_11_label = 1; v654_11_label <= 2; ++v654_11_label) {
        const Space v654_11_tail = child(v648_12_tail,v654_11_label);
        if (v654_11_tail.empty()) continue;
        const Path v654_11_head{v654_11_label};
        const Space v655_2 = singleton(v654_11_head);
        const Space v655_3 = intersect(constant_2,v655_2);
        const Space v655_4 = (has_head(v655_3) ? constant_3 : Space{});
        const Space v655_5 = subtract(constant_1,v655_4);
        Space v655_8;
        if (!v655_5.empty()) {
          const Path v656_6 = concat_path(v654_6,v654_11_head);
          const Space v656_7 = routine_110(c, v656_6, p1, v654_11_tail);
          v655_8 = compose(v655_5,v656_7);
        }
        const Space v655_9 = intersect(constant_2,v655_2);
        const Space v655_10 = (has_head(v655_9) ? constant_3 : Space{});
        Space v655_12;
        if (!v655_10.empty()) {
          const Path v657_6 = concat_path(v654_6,v654_11_head);
          const Space v657_11 = routine_67(c, v657_6, p1, v654_11_tail);
          v655_12 = compose(v655_10,v657_11);
        }
        const Space v655_13 = unite(v655_8,v655_12);
        v654_11_result = unite(v654_11_result,v655_13);
      }
      const Space v654_11 = std::move(v654_11_result);
      v649_12 = compose(v649_10,v654_11);
    }
    const Space v649_13 = unite(v649_8,v649_12);
    v648_12_result = unite(v648_12_result,v649_13);
  }
  const Space v648_12 = std::move(v648_12_result);
  return v648_12;
}

static Space routine_66(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v658_9_result;
  for (int v658_9_label = 1; v658_9_label <= 2; ++v658_9_label) {
    const Space v658_9_tail = child(s0,v658_9_label);
    if (v658_9_tail.empty()) continue;
    const Path v658_9_head{v658_9_label};
    const Space v659_2 = singleton(v658_9_head);
    const Space v659_3 = intersect(constant_2,v659_2);
    const Space v659_4 = (has_head(v659_3) ? constant_3 : Space{});
    const Space v659_5 = subtract(constant_1,v659_4);
    Space v659_8;
    if (!v659_5.empty()) {
      const Path v660_6 = concat_path(p0,v658_9_head);
      Space v660_7_result;
      for (int v660_7_label = 1; v660_7_label <= 2; ++v660_7_label) {
        const Space v660_7_tail = child(v658_9_tail,v660_7_label);
        if (v660_7_tail.empty()) continue;
        const Path v660_7_head{v660_7_label};
        const Space v661_2 = singleton(v660_7_head);
        const Space v661_3 = intersect(constant_2,v661_2);
        const Space v661_4 = (has_head(v661_3) ? constant_3 : Space{});
        const Space v661_5 = subtract(constant_1,v661_4);
        Space v661_8;
        if (!v661_5.empty()) {
          const Path v662_6 = concat_path(v660_6,v660_7_head);
          const Space v662_7 = routine_110(c, v662_6, p1, v660_7_tail);
          v661_8 = compose(v661_5,v662_7);
        }
        const Space v661_9 = intersect(constant_2,v661_2);
        const Space v661_10 = (has_head(v661_9) ? constant_3 : Space{});
        Space v661_12;
        if (!v661_10.empty()) {
          const Path v663_6 = concat_path(v660_6,v660_7_head);
          const Space v663_11 = routine_111(c, v663_6, p1, v660_7_tail);
          v661_12 = compose(v661_10,v663_11);
        }
        const Space v661_13 = unite(v661_8,v661_12);
        v660_7_result = unite(v660_7_result,v661_13);
      }
      const Space v660_7 = std::move(v660_7_result);
      v659_8 = compose(v659_5,v660_7);
    }
    const Space v659_9 = intersect(constant_2,v659_2);
    const Space v659_10 = (has_head(v659_9) ? constant_3 : Space{});
    const Space v659_11 = compose(v659_10,v658_9_tail);
    const Path v664_6 = concat_path(p0,v658_9_head);
    const Space v659_12 = wrap(v659_11,v664_6);
    const Space v659_13 = wrap(v659_12,p1);
    const Space v659_14 = unite(v659_8,v659_13);
    v658_9_result = unite(v658_9_result,v659_14);
  }
  const Space v658_9 = std::move(v658_9_result);
  return v658_9;
}

static Space routine_67(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v665_3 = wrap(s0,p0);
  const Space v665_4 = wrap(v665_3,p1);
  return v665_4;
}

static Space routine_68(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v666_12_result;
  for (int v666_12_label = 1; v666_12_label <= 2; ++v666_12_label) {
    const Space v666_12_tail = child(s0,v666_12_label);
    if (v666_12_tail.empty()) continue;
    const Path v666_12_head{v666_12_label};
    const Space v667_2 = singleton(v666_12_head);
    const Space v667_3 = intersect(constant_2,v667_2);
    const Space v667_4 = (has_head(v667_3) ? constant_3 : Space{});
    const Space v667_5 = subtract(constant_1,v667_4);
    Space v667_8;
    if (!v667_5.empty()) {
      const Path v668_6 = concat_path(p0,v666_12_head);
      Space v668_7_result;
      for (int v668_7_label = 1; v668_7_label <= 2; ++v668_7_label) {
        const Space v668_7_tail = child(v666_12_tail,v668_7_label);
        if (v668_7_tail.empty()) continue;
        const Path v668_7_head{v668_7_label};
        const Space v669_2 = singleton(v668_7_head);
        const Space v669_3 = intersect(constant_2,v669_2);
        const Space v669_4 = (has_head(v669_3) ? constant_3 : Space{});
        const Space v669_5 = subtract(constant_1,v669_4);
        Space v669_8;
        if (!v669_5.empty()) {
          const Path v670_6 = concat_path(v668_6,v668_7_head);
          const Space v670_7 = routine_112(c, v670_6, v668_7_tail, s1);
          v669_8 = compose(v669_5,v670_7);
        }
        const Space v669_9 = intersect(constant_2,v669_2);
        const Space v669_10 = (has_head(v669_9) ? constant_3 : Space{});
        Space v669_12;
        if (!v669_10.empty()) {
          const Path v671_6 = concat_path(v668_6,v668_7_head);
          const Space v671_11 = routine_113(c, v671_6, v668_7_tail, s1);
          v669_12 = compose(v669_10,v671_11);
        }
        const Space v669_13 = unite(v669_8,v669_12);
        v668_7_result = unite(v668_7_result,v669_13);
      }
      const Space v668_7 = std::move(v668_7_result);
      v667_8 = compose(v667_5,v668_7);
    }
    const Space v667_9 = intersect(constant_2,v667_2);
    const Space v667_10 = (has_head(v667_9) ? constant_3 : Space{});
    Space v667_12;
    if (!v667_10.empty()) {
      const Path v672_6 = concat_path(p0,v666_12_head);
      Space v672_11_result;
      for (int v672_11_label = 1; v672_11_label <= 2; ++v672_11_label) {
        const Space v672_11_tail = child(v666_12_tail,v672_11_label);
        if (v672_11_tail.empty()) continue;
        const Path v672_11_head{v672_11_label};
        const Space v673_2 = singleton(v672_11_head);
        const Space v673_3 = intersect(constant_2,v673_2);
        const Space v673_4 = (has_head(v673_3) ? constant_3 : Space{});
        const Space v673_5 = subtract(constant_1,v673_4);
        Space v673_8;
        if (!v673_5.empty()) {
          const Path v674_6 = concat_path(v672_6,v672_11_head);
          const Space v674_7 = routine_112(c, v674_6, v672_11_tail, s1);
          v673_8 = compose(v673_5,v674_7);
        }
        const Space v673_9 = intersect(constant_2,v673_2);
        const Space v673_10 = (has_head(v673_9) ? constant_3 : Space{});
        Space v673_12;
        if (!v673_10.empty()) {
          const Path v675_6 = concat_path(v672_6,v672_11_head);
          const Space v675_11 = routine_9(c, v675_6, v672_11_tail, s1);
          v673_12 = compose(v673_10,v675_11);
        }
        const Space v673_13 = unite(v673_8,v673_12);
        v672_11_result = unite(v672_11_result,v673_13);
      }
      const Space v672_11 = std::move(v672_11_result);
      v667_12 = compose(v667_10,v672_11);
    }
    const Space v667_13 = unite(v667_8,v667_12);
    v666_12_result = unite(v666_12_result,v667_13);
  }
  const Space v666_12 = std::move(v666_12_result);
  return v666_12;
}

static Space routine_69(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v676_12_result;
  for (int v676_12_label = 1; v676_12_label <= 2; ++v676_12_label) {
    const Space v676_12_tail = child(s0,v676_12_label);
    if (v676_12_tail.empty()) continue;
    const Path v676_12_head{v676_12_label};
    const Space v677_2 = singleton(v676_12_head);
    const Space v677_3 = intersect(constant_2,v677_2);
    const Space v677_4 = (has_head(v677_3) ? constant_3 : Space{});
    const Space v677_5 = subtract(constant_1,v677_4);
    Space v677_8;
    if (!v677_5.empty()) {
      const Path v678_6 = concat_path(p0,v676_12_head);
      Space v678_7_result;
      for (int v678_7_label = 1; v678_7_label <= 2; ++v678_7_label) {
        const Space v678_7_tail = child(v676_12_tail,v678_7_label);
        if (v678_7_tail.empty()) continue;
        const Path v678_7_head{v678_7_label};
        const Space v679_2 = singleton(v678_7_head);
        const Space v679_3 = intersect(constant_2,v679_2);
        const Space v679_4 = (has_head(v679_3) ? constant_3 : Space{});
        const Space v679_5 = subtract(constant_1,v679_4);
        Space v679_8;
        if (!v679_5.empty()) {
          const Path v680_6 = concat_path(v678_6,v678_7_head);
          const Space v680_7 = routine_112(c, v680_6, v678_7_tail, s1);
          v679_8 = compose(v679_5,v680_7);
        }
        const Space v679_9 = intersect(constant_2,v679_2);
        const Space v679_10 = (has_head(v679_9) ? constant_3 : Space{});
        Space v679_12;
        if (!v679_10.empty()) {
          const Path v681_6 = concat_path(v678_6,v678_7_head);
          const Space v681_11 = routine_113(c, v681_6, v678_7_tail, s1);
          v679_12 = compose(v679_10,v681_11);
        }
        const Space v679_13 = unite(v679_8,v679_12);
        v678_7_result = unite(v678_7_result,v679_13);
      }
      const Space v678_7 = std::move(v678_7_result);
      v677_8 = compose(v677_5,v678_7);
    }
    const Space v677_9 = intersect(constant_2,v677_2);
    const Space v677_10 = (has_head(v677_9) ? constant_3 : Space{});
    Space v677_12;
    if (!v677_10.empty()) {
      const Path v682_6 = concat_path(p0,v676_12_head);
      Space v682_11_result;
      for (int v682_11_label = 1; v682_11_label <= 2; ++v682_11_label) {
        const Space v682_11_tail = child(v676_12_tail,v682_11_label);
        if (v682_11_tail.empty()) continue;
        const Path v682_11_head{v682_11_label};
        const Space v683_2 = singleton(v682_11_head);
        const Space v683_3 = intersect(constant_2,v683_2);
        const Space v683_4 = (has_head(v683_3) ? constant_3 : Space{});
        const Space v683_5 = subtract(constant_1,v683_4);
        Space v683_7;
        if (!v683_5.empty()) {
          const Space v684_6 = routine_32(c, v682_11_head, v682_6, v682_11_tail, s1);
          v683_7 = compose(v683_5,v684_6);
        }
        const Space v683_8 = intersect(constant_2,v683_2);
        const Space v683_9 = (has_head(v683_8) ? constant_3 : Space{});
        Space v683_11;
        if (!v683_9.empty()) {
          const Space v685_10 = routine_33(c, v682_11_head, v682_6, v682_11_tail, s1);
          v683_11 = compose(v683_9,v685_10);
        }
        const Space v683_12 = unite(v683_7,v683_11);
        v682_11_result = unite(v682_11_result,v683_12);
      }
      const Space v682_11 = std::move(v682_11_result);
      v677_12 = compose(v677_10,v682_11);
    }
    const Space v677_13 = unite(v677_8,v677_12);
    v676_12_result = unite(v676_12_result,v677_13);
  }
  const Space v676_12 = std::move(v676_12_result);
  return v676_12;
}

static Space routine_70(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v686_13_result;
  for (int v686_13_label = 1; v686_13_label <= 2; ++v686_13_label) {
    const Space v686_13_tail = child(s0,v686_13_label);
    if (v686_13_tail.empty()) continue;
    const Path v686_13_head{v686_13_label};
    const Space v687_2 = singleton(v686_13_head);
    const Space v687_3 = intersect(constant_2,v687_2);
    const Space v687_4 = (has_head(v687_3) ? constant_3 : Space{});
    const Space v687_5 = subtract(constant_1,v687_4);
    Space v687_8;
    if (!v687_5.empty()) {
      const Path v688_6 = concat_path(p0,v686_13_head);
      Space v688_7_result;
      for (int v688_7_label = 1; v688_7_label <= 2; ++v688_7_label) {
        const Space v688_7_tail = child(v686_13_tail,v688_7_label);
        if (v688_7_tail.empty()) continue;
        const Path v688_7_head{v688_7_label};
        const Space v689_2 = singleton(v688_7_head);
        const Space v689_3 = intersect(constant_2,v689_2);
        const Space v689_4 = (has_head(v689_3) ? constant_3 : Space{});
        const Space v689_5 = subtract(constant_1,v689_4);
        Space v689_8;
        if (!v689_5.empty()) {
          const Path v690_6 = concat_path(v688_6,v688_7_head);
          const Space v690_7 = routine_114(c, v690_6, p1, v688_7_tail, s1);
          v689_8 = compose(v689_5,v690_7);
        }
        const Space v689_9 = intersect(constant_2,v689_2);
        const Space v689_10 = (has_head(v689_9) ? constant_3 : Space{});
        Space v689_12;
        if (!v689_10.empty()) {
          const Path v691_6 = concat_path(v688_6,v688_7_head);
          const Space v691_11 = routine_115(c, v691_6, p1, v688_7_tail, s1);
          v689_12 = compose(v689_10,v691_11);
        }
        const Space v689_13 = unite(v689_8,v689_12);
        v688_7_result = unite(v688_7_result,v689_13);
      }
      const Space v688_7 = std::move(v688_7_result);
      v687_8 = compose(v687_5,v688_7);
    }
    const Space v687_9 = intersect(constant_2,v687_2);
    const Space v687_10 = (has_head(v687_9) ? constant_3 : Space{});
    Space v687_12;
    if (!v687_10.empty()) {
      const Path v692_6 = concat_path(p0,v686_13_head);
      Space v692_11_result;
      for (int v692_11_label = 1; v692_11_label <= 2; ++v692_11_label) {
        const Space v692_11_tail = child(v686_13_tail,v692_11_label);
        if (v692_11_tail.empty()) continue;
        const Path v692_11_head{v692_11_label};
        const Space v693_2 = singleton(v692_11_head);
        const Space v693_3 = intersect(constant_2,v693_2);
        const Space v693_4 = (has_head(v693_3) ? constant_3 : Space{});
        const Space v693_5 = subtract(constant_1,v693_4);
        Space v693_8;
        if (!v693_5.empty()) {
          const Path v694_6 = concat_path(v692_6,v692_11_head);
          const Space v694_7 = routine_114(c, v694_6, p1, v692_11_tail, s1);
          v693_8 = compose(v693_5,v694_7);
        }
        const Space v693_9 = intersect(constant_2,v693_2);
        const Space v693_10 = (has_head(v693_9) ? constant_3 : Space{});
        Space v693_12;
        if (!v693_10.empty()) {
          const Path v695_6 = concat_path(v692_6,v692_11_head);
          const Space v695_11 = routine_36(c, v695_6, p1, v692_11_tail, s1);
          v693_12 = compose(v693_10,v695_11);
        }
        const Space v693_13 = unite(v693_8,v693_12);
        v692_11_result = unite(v692_11_result,v693_13);
      }
      const Space v692_11 = std::move(v692_11_result);
      v687_12 = compose(v687_10,v692_11);
    }
    const Space v687_13 = unite(v687_8,v687_12);
    v686_13_result = unite(v686_13_result,v687_13);
  }
  const Space v686_13 = std::move(v686_13_result);
  return v686_13;
}

static Space routine_71(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v696_8 = unwrap(s1,constant_4);
  const Space v696_10 = unwrap(v696_8,constant_6);
  const Space v696_11 = unwrap(v696_10,p0);
  Space v696_18_result;
  for (int v696_18_label = 1; v696_18_label <= 2; ++v696_18_label) {
    const Space v696_18_tail = child(s0,v696_18_label);
    if (v696_18_tail.empty()) continue;
    const Path v696_18_head{v696_18_label};
    const Space v697_2 = singleton(v696_18_head);
    const Space v697_3 = intersect(constant_2,v697_2);
    const Space v697_4 = (has_head(v697_3) ? constant_3 : Space{});
    const Space v697_5 = subtract(constant_1,v697_4);
    Space v697_8;
    if (!v697_5.empty()) {
      const Path v698_6 = concat_path(p0,v696_18_head);
      Space v698_7_result;
      for (int v698_7_label = 1; v698_7_label <= 2; ++v698_7_label) {
        const Space v698_7_tail = child(v696_18_tail,v698_7_label);
        if (v698_7_tail.empty()) continue;
        const Path v698_7_head{v698_7_label};
        const Space v699_2 = singleton(v698_7_head);
        const Space v699_3 = intersect(constant_2,v699_2);
        const Space v699_4 = (has_head(v699_3) ? constant_3 : Space{});
        const Space v699_5 = subtract(constant_1,v699_4);
        Space v699_8;
        if (!v699_5.empty()) {
          const Path v700_6 = concat_path(v698_6,v698_7_head);
          const Space v700_7 = routine_114(c, v700_6, p1, v698_7_tail, s1);
          v699_8 = compose(v699_5,v700_7);
        }
        const Space v699_9 = intersect(constant_2,v699_2);
        const Space v699_10 = (has_head(v699_9) ? constant_3 : Space{});
        Space v699_12;
        if (!v699_10.empty()) {
          const Path v701_6 = concat_path(v698_6,v698_7_head);
          const Space v701_11 = routine_115(c, v701_6, p1, v698_7_tail, s1);
          v699_12 = compose(v699_10,v701_11);
        }
        const Space v699_13 = unite(v699_8,v699_12);
        v698_7_result = unite(v698_7_result,v699_13);
      }
      const Space v698_7 = std::move(v698_7_result);
      v697_8 = compose(v697_5,v698_7);
    }
    const Space v697_9 = intersect(constant_2,v697_2);
    const Space v697_10 = (has_head(v697_9) ? constant_3 : Space{});
    Space v697_13;
    if (!v697_10.empty()) {
      const Space v702_11 = unwrap(v696_11,v696_18_head);
      Space v702_12_result;
      for (int v702_12_label = 1; v702_12_label <= 2; ++v702_12_label) {
        const Space v702_12_tail = child(v702_11,v702_12_label);
        if (v702_12_tail.empty()) continue;
        const Path v702_12_head{v702_12_label};
        const Space v703_2 = singleton(v702_12_head);
        const Space v703_3 = intersect(constant_2,v703_2);
        const Space v703_4 = (has_head(v703_3) ? constant_3 : Space{});
        const Space v703_5 = subtract(constant_1,v703_4);
        Space v703_7;
        if (!v703_5.empty()) {
          const Space v704_6 = routine_72(c, v702_12_head, p1, v702_12_tail);
          v703_7 = compose(v703_5,v704_6);
        }
        const Space v703_8 = intersect(constant_2,v703_2);
        const Space v703_9 = (has_head(v703_8) ? constant_3 : Space{});
        Space v703_11;
        if (!v703_9.empty()) {
          const Space v705_10 = routine_73(c, v702_12_head, p1, v702_12_tail);
          v703_11 = compose(v703_9,v705_10);
        }
        const Space v703_12 = unite(v703_7,v703_11);
        v702_12_result = unite(v702_12_result,v703_12);
      }
      const Space v702_12 = std::move(v702_12_result);
      v697_13 = compose(v697_10,v702_12);
    }
    const Space v697_14 = unite(v697_8,v697_13);
    v696_18_result = unite(v696_18_result,v697_14);
  }
  const Space v696_18 = std::move(v696_18_result);
  return v696_18;
}

static Space routine_72(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v706_12_result;
  for (int v706_12_label = 1; v706_12_label <= 2; ++v706_12_label) {
    const Space v706_12_tail = child(s0,v706_12_label);
    if (v706_12_tail.empty()) continue;
    const Path v706_12_head{v706_12_label};
    const Space v707_2 = singleton(v706_12_head);
    const Space v707_3 = intersect(constant_2,v707_2);
    const Space v707_4 = (has_head(v707_3) ? constant_3 : Space{});
    const Space v707_5 = subtract(constant_1,v707_4);
    Space v707_8;
    if (!v707_5.empty()) {
      const Path v708_6 = concat_path(p0,v706_12_head);
      Space v708_7_result;
      for (int v708_7_label = 1; v708_7_label <= 2; ++v708_7_label) {
        const Space v708_7_tail = child(v706_12_tail,v708_7_label);
        if (v708_7_tail.empty()) continue;
        const Path v708_7_head{v708_7_label};
        const Space v709_2 = singleton(v708_7_head);
        const Space v709_3 = intersect(constant_2,v709_2);
        const Space v709_4 = (has_head(v709_3) ? constant_3 : Space{});
        const Space v709_5 = subtract(constant_1,v709_4);
        Space v709_8;
        if (!v709_5.empty()) {
          const Path v710_6 = concat_path(v708_6,v708_7_head);
          const Space v710_7 = routine_116(c, v710_6, p1, v708_7_tail);
          v709_8 = compose(v709_5,v710_7);
        }
        const Space v709_9 = intersect(constant_2,v709_2);
        const Space v709_10 = (has_head(v709_9) ? constant_3 : Space{});
        Space v709_12;
        if (!v709_10.empty()) {
          const Path v711_6 = concat_path(v708_6,v708_7_head);
          const Space v711_11 = routine_117(c, v711_6, p1, v708_7_tail);
          v709_12 = compose(v709_10,v711_11);
        }
        const Space v709_13 = unite(v709_8,v709_12);
        v708_7_result = unite(v708_7_result,v709_13);
      }
      const Space v708_7 = std::move(v708_7_result);
      v707_8 = compose(v707_5,v708_7);
    }
    const Space v707_9 = intersect(constant_2,v707_2);
    const Space v707_10 = (has_head(v707_9) ? constant_3 : Space{});
    Space v707_12;
    if (!v707_10.empty()) {
      const Path v712_6 = concat_path(p0,v706_12_head);
      Space v712_11_result;
      for (int v712_11_label = 1; v712_11_label <= 2; ++v712_11_label) {
        const Space v712_11_tail = child(v706_12_tail,v712_11_label);
        if (v712_11_tail.empty()) continue;
        const Path v712_11_head{v712_11_label};
        const Space v713_2 = singleton(v712_11_head);
        const Space v713_3 = intersect(constant_2,v713_2);
        const Space v713_4 = (has_head(v713_3) ? constant_3 : Space{});
        const Space v713_5 = subtract(constant_1,v713_4);
        Space v713_8;
        if (!v713_5.empty()) {
          const Path v714_6 = concat_path(v712_6,v712_11_head);
          const Space v714_7 = routine_116(c, v714_6, p1, v712_11_tail);
          v713_8 = compose(v713_5,v714_7);
        }
        const Space v713_9 = intersect(constant_2,v713_2);
        const Space v713_10 = (has_head(v713_9) ? constant_3 : Space{});
        Space v713_12;
        if (!v713_10.empty()) {
          const Path v715_6 = concat_path(v712_6,v712_11_head);
          const Space v715_11 = routine_78(c, v715_6, p1, v712_11_tail);
          v713_12 = compose(v713_10,v715_11);
        }
        const Space v713_13 = unite(v713_8,v713_12);
        v712_11_result = unite(v712_11_result,v713_13);
      }
      const Space v712_11 = std::move(v712_11_result);
      v707_12 = compose(v707_10,v712_11);
    }
    const Space v707_13 = unite(v707_8,v707_12);
    v706_12_result = unite(v706_12_result,v707_13);
  }
  const Space v706_12 = std::move(v706_12_result);
  return v706_12;
}

static Space routine_73(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v716_9_result;
  for (int v716_9_label = 1; v716_9_label <= 2; ++v716_9_label) {
    const Space v716_9_tail = child(s0,v716_9_label);
    if (v716_9_tail.empty()) continue;
    const Path v716_9_head{v716_9_label};
    const Space v717_2 = singleton(v716_9_head);
    const Space v717_3 = intersect(constant_2,v717_2);
    const Space v717_4 = (has_head(v717_3) ? constant_3 : Space{});
    const Space v717_5 = subtract(constant_1,v717_4);
    Space v717_8;
    if (!v717_5.empty()) {
      const Path v718_6 = concat_path(p0,v716_9_head);
      Space v718_7_result;
      for (int v718_7_label = 1; v718_7_label <= 2; ++v718_7_label) {
        const Space v718_7_tail = child(v716_9_tail,v718_7_label);
        if (v718_7_tail.empty()) continue;
        const Path v718_7_head{v718_7_label};
        const Space v719_2 = singleton(v718_7_head);
        const Space v719_3 = intersect(constant_2,v719_2);
        const Space v719_4 = (has_head(v719_3) ? constant_3 : Space{});
        const Space v719_5 = subtract(constant_1,v719_4);
        Space v719_8;
        if (!v719_5.empty()) {
          const Path v720_6 = concat_path(v718_6,v718_7_head);
          const Space v720_7 = routine_116(c, v720_6, p1, v718_7_tail);
          v719_8 = compose(v719_5,v720_7);
        }
        const Space v719_9 = intersect(constant_2,v719_2);
        const Space v719_10 = (has_head(v719_9) ? constant_3 : Space{});
        Space v719_12;
        if (!v719_10.empty()) {
          const Path v721_6 = concat_path(v718_6,v718_7_head);
          const Space v721_11 = routine_117(c, v721_6, p1, v718_7_tail);
          v719_12 = compose(v719_10,v721_11);
        }
        const Space v719_13 = unite(v719_8,v719_12);
        v718_7_result = unite(v718_7_result,v719_13);
      }
      const Space v718_7 = std::move(v718_7_result);
      v717_8 = compose(v717_5,v718_7);
    }
    const Space v717_9 = intersect(constant_2,v717_2);
    const Space v717_10 = (has_head(v717_9) ? constant_3 : Space{});
    const Space v717_11 = compose(v717_10,v716_9_tail);
    const Path v722_6 = concat_path(p0,v716_9_head);
    const Space v717_12 = wrap(v717_11,v722_6);
    const Space v717_13 = wrap(v717_12,p1);
    const Space v717_14 = unite(v717_8,v717_13);
    v716_9_result = unite(v716_9_result,v717_14);
  }
  const Space v716_9 = std::move(v716_9_result);
  return v716_9;
}

static Space routine_74(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v723_13_result;
  for (int v723_13_label = 1; v723_13_label <= 2; ++v723_13_label) {
    const Space v723_13_tail = child(s0,v723_13_label);
    if (v723_13_tail.empty()) continue;
    const Path v723_13_head{v723_13_label};
    const Space v724_2 = singleton(v723_13_head);
    const Space v724_3 = intersect(constant_2,v724_2);
    const Space v724_4 = (has_head(v724_3) ? constant_3 : Space{});
    const Space v724_5 = subtract(constant_1,v724_4);
    Space v724_8;
    if (!v724_5.empty()) {
      const Path v725_6 = concat_path(p0,v723_13_head);
      Space v725_7_result;
      for (int v725_7_label = 1; v725_7_label <= 2; ++v725_7_label) {
        const Space v725_7_tail = child(v723_13_tail,v725_7_label);
        if (v725_7_tail.empty()) continue;
        const Path v725_7_head{v725_7_label};
        const Space v726_2 = singleton(v725_7_head);
        const Space v726_3 = intersect(constant_2,v726_2);
        const Space v726_4 = (has_head(v726_3) ? constant_3 : Space{});
        const Space v726_5 = subtract(constant_1,v726_4);
        Space v726_8;
        if (!v726_5.empty()) {
          const Path v727_6 = concat_path(v725_6,v725_7_head);
          const Space v727_7 = routine_118(c, v727_6, p1, v725_7_tail, s1);
          v726_8 = compose(v726_5,v727_7);
        }
        const Space v726_9 = intersect(constant_2,v726_2);
        const Space v726_10 = (has_head(v726_9) ? constant_3 : Space{});
        Space v726_12;
        if (!v726_10.empty()) {
          const Path v728_6 = concat_path(v725_6,v725_7_head);
          const Space v728_11 = routine_119(c, v728_6, p1, v725_7_tail, s1);
          v726_12 = compose(v726_10,v728_11);
        }
        const Space v726_13 = unite(v726_8,v726_12);
        v725_7_result = unite(v725_7_result,v726_13);
      }
      const Space v725_7 = std::move(v725_7_result);
      v724_8 = compose(v724_5,v725_7);
    }
    const Space v724_9 = intersect(constant_2,v724_2);
    const Space v724_10 = (has_head(v724_9) ? constant_3 : Space{});
    Space v724_12;
    if (!v724_10.empty()) {
      const Path v729_6 = concat_path(p0,v723_13_head);
      Space v729_11_result;
      for (int v729_11_label = 1; v729_11_label <= 2; ++v729_11_label) {
        const Space v729_11_tail = child(v723_13_tail,v729_11_label);
        if (v729_11_tail.empty()) continue;
        const Path v729_11_head{v729_11_label};
        const Space v730_2 = singleton(v729_11_head);
        const Space v730_3 = intersect(constant_2,v730_2);
        const Space v730_4 = (has_head(v730_3) ? constant_3 : Space{});
        const Space v730_5 = subtract(constant_1,v730_4);
        Space v730_8;
        if (!v730_5.empty()) {
          const Path v731_6 = concat_path(v729_6,v729_11_head);
          const Space v731_7 = routine_118(c, v731_6, p1, v729_11_tail, s1);
          v730_8 = compose(v730_5,v731_7);
        }
        const Space v730_9 = intersect(constant_2,v730_2);
        const Space v730_10 = (has_head(v730_9) ? constant_3 : Space{});
        Space v730_12;
        if (!v730_10.empty()) {
          const Path v732_6 = concat_path(v729_6,v729_11_head);
          const Space v732_11 = routine_36(c, v732_6, p1, v729_11_tail, s1);
          v730_12 = compose(v730_10,v732_11);
        }
        const Space v730_13 = unite(v730_8,v730_12);
        v729_11_result = unite(v729_11_result,v730_13);
      }
      const Space v729_11 = std::move(v729_11_result);
      v724_12 = compose(v724_10,v729_11);
    }
    const Space v724_13 = unite(v724_8,v724_12);
    v723_13_result = unite(v723_13_result,v724_13);
  }
  const Space v723_13 = std::move(v723_13_result);
  return v723_13;
}

static Space routine_75(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v733_8 = unwrap(s1,constant_4);
  const Space v733_10 = unwrap(v733_8,constant_6);
  const Space v733_11 = unwrap(v733_10,p0);
  Space v733_18_result;
  for (int v733_18_label = 1; v733_18_label <= 2; ++v733_18_label) {
    const Space v733_18_tail = child(s0,v733_18_label);
    if (v733_18_tail.empty()) continue;
    const Path v733_18_head{v733_18_label};
    const Space v734_2 = singleton(v733_18_head);
    const Space v734_3 = intersect(constant_2,v734_2);
    const Space v734_4 = (has_head(v734_3) ? constant_3 : Space{});
    const Space v734_5 = subtract(constant_1,v734_4);
    Space v734_8;
    if (!v734_5.empty()) {
      const Path v735_6 = concat_path(p0,v733_18_head);
      Space v735_7_result;
      for (int v735_7_label = 1; v735_7_label <= 2; ++v735_7_label) {
        const Space v735_7_tail = child(v733_18_tail,v735_7_label);
        if (v735_7_tail.empty()) continue;
        const Path v735_7_head{v735_7_label};
        const Space v736_2 = singleton(v735_7_head);
        const Space v736_3 = intersect(constant_2,v736_2);
        const Space v736_4 = (has_head(v736_3) ? constant_3 : Space{});
        const Space v736_5 = subtract(constant_1,v736_4);
        Space v736_8;
        if (!v736_5.empty()) {
          const Path v737_6 = concat_path(v735_6,v735_7_head);
          const Space v737_7 = routine_118(c, v737_6, p1, v735_7_tail, s1);
          v736_8 = compose(v736_5,v737_7);
        }
        const Space v736_9 = intersect(constant_2,v736_2);
        const Space v736_10 = (has_head(v736_9) ? constant_3 : Space{});
        Space v736_12;
        if (!v736_10.empty()) {
          const Path v738_6 = concat_path(v735_6,v735_7_head);
          const Space v738_11 = routine_119(c, v738_6, p1, v735_7_tail, s1);
          v736_12 = compose(v736_10,v738_11);
        }
        const Space v736_13 = unite(v736_8,v736_12);
        v735_7_result = unite(v735_7_result,v736_13);
      }
      const Space v735_7 = std::move(v735_7_result);
      v734_8 = compose(v734_5,v735_7);
    }
    const Space v734_9 = intersect(constant_2,v734_2);
    const Space v734_10 = (has_head(v734_9) ? constant_3 : Space{});
    Space v734_13;
    if (!v734_10.empty()) {
      const Space v739_11 = unwrap(v733_11,v733_18_head);
      Space v739_12_result;
      for (int v739_12_label = 1; v739_12_label <= 2; ++v739_12_label) {
        const Space v739_12_tail = child(v739_11,v739_12_label);
        if (v739_12_tail.empty()) continue;
        const Path v739_12_head{v739_12_label};
        const Space v740_2 = singleton(v739_12_head);
        const Space v740_3 = intersect(constant_2,v740_2);
        const Space v740_4 = (has_head(v740_3) ? constant_3 : Space{});
        const Space v740_5 = subtract(constant_1,v740_4);
        Space v740_7;
        if (!v740_5.empty()) {
          const Space v741_6 = routine_72(c, v739_12_head, p1, v739_12_tail);
          v740_7 = compose(v740_5,v741_6);
        }
        const Space v740_8 = intersect(constant_2,v740_2);
        const Space v740_9 = (has_head(v740_8) ? constant_3 : Space{});
        Space v740_11;
        if (!v740_9.empty()) {
          const Space v742_10 = routine_73(c, v739_12_head, p1, v739_12_tail);
          v740_11 = compose(v740_9,v742_10);
        }
        const Space v740_12 = unite(v740_7,v740_11);
        v739_12_result = unite(v739_12_result,v740_12);
      }
      const Space v739_12 = std::move(v739_12_result);
      v734_13 = compose(v734_10,v739_12);
    }
    const Space v734_14 = unite(v734_8,v734_13);
    v733_18_result = unite(v733_18_result,v734_14);
  }
  const Space v733_18 = std::move(v733_18_result);
  return v733_18;
}

static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v743_12_result;
  for (int v743_12_label = 1; v743_12_label <= 2; ++v743_12_label) {
    const Space v743_12_tail = child(s0,v743_12_label);
    if (v743_12_tail.empty()) continue;
    const Path v743_12_head{v743_12_label};
    const Space v744_2 = singleton(v743_12_head);
    const Space v744_3 = intersect(constant_2,v744_2);
    const Space v744_4 = (has_head(v744_3) ? constant_3 : Space{});
    const Space v744_5 = subtract(constant_1,v744_4);
    Space v744_8;
    if (!v744_5.empty()) {
      const Path v745_6 = concat_path(p0,v743_12_head);
      Space v745_7_result;
      for (int v745_7_label = 1; v745_7_label <= 2; ++v745_7_label) {
        const Space v745_7_tail = child(v743_12_tail,v745_7_label);
        if (v745_7_tail.empty()) continue;
        const Path v745_7_head{v745_7_label};
        const Space v746_2 = singleton(v745_7_head);
        const Space v746_3 = intersect(constant_2,v746_2);
        const Space v746_4 = (has_head(v746_3) ? constant_3 : Space{});
        const Space v746_5 = subtract(constant_1,v746_4);
        Space v746_8;
        if (!v746_5.empty()) {
          const Path v747_6 = concat_path(v745_6,v745_7_head);
          const Space v747_7 = routine_120(c, v747_6, p1, v745_7_tail);
          v746_8 = compose(v746_5,v747_7);
        }
        const Space v746_9 = intersect(constant_2,v746_2);
        const Space v746_10 = (has_head(v746_9) ? constant_3 : Space{});
        Space v746_12;
        if (!v746_10.empty()) {
          const Path v748_6 = concat_path(v745_6,v745_7_head);
          const Space v748_11 = routine_121(c, v748_6, p1, v745_7_tail);
          v746_12 = compose(v746_10,v748_11);
        }
        const Space v746_13 = unite(v746_8,v746_12);
        v745_7_result = unite(v745_7_result,v746_13);
      }
      const Space v745_7 = std::move(v745_7_result);
      v744_8 = compose(v744_5,v745_7);
    }
    const Space v744_9 = intersect(constant_2,v744_2);
    const Space v744_10 = (has_head(v744_9) ? constant_3 : Space{});
    Space v744_12;
    if (!v744_10.empty()) {
      const Path v749_6 = concat_path(p0,v743_12_head);
      Space v749_11_result;
      for (int v749_11_label = 1; v749_11_label <= 2; ++v749_11_label) {
        const Space v749_11_tail = child(v743_12_tail,v749_11_label);
        if (v749_11_tail.empty()) continue;
        const Path v749_11_head{v749_11_label};
        const Space v750_2 = singleton(v749_11_head);
        const Space v750_3 = intersect(constant_2,v750_2);
        const Space v750_4 = (has_head(v750_3) ? constant_3 : Space{});
        const Space v750_5 = subtract(constant_1,v750_4);
        Space v750_8;
        if (!v750_5.empty()) {
          const Path v751_6 = concat_path(v749_6,v749_11_head);
          const Space v751_7 = routine_120(c, v751_6, p1, v749_11_tail);
          v750_8 = compose(v750_5,v751_7);
        }
        const Space v750_9 = intersect(constant_2,v750_2);
        const Space v750_10 = (has_head(v750_9) ? constant_3 : Space{});
        Space v750_12;
        if (!v750_10.empty()) {
          const Path v752_6 = concat_path(v749_6,v749_11_head);
          const Space v752_11 = routine_78(c, v752_6, p1, v749_11_tail);
          v750_12 = compose(v750_10,v752_11);
        }
        const Space v750_13 = unite(v750_8,v750_12);
        v749_11_result = unite(v749_11_result,v750_13);
      }
      const Space v749_11 = std::move(v749_11_result);
      v744_12 = compose(v744_10,v749_11);
    }
    const Space v744_13 = unite(v744_8,v744_12);
    v743_12_result = unite(v743_12_result,v744_13);
  }
  const Space v743_12 = std::move(v743_12_result);
  return v743_12;
}

static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v753_9_result;
  for (int v753_9_label = 1; v753_9_label <= 2; ++v753_9_label) {
    const Space v753_9_tail = child(s0,v753_9_label);
    if (v753_9_tail.empty()) continue;
    const Path v753_9_head{v753_9_label};
    const Space v754_2 = singleton(v753_9_head);
    const Space v754_3 = intersect(constant_2,v754_2);
    const Space v754_4 = (has_head(v754_3) ? constant_3 : Space{});
    const Space v754_5 = subtract(constant_1,v754_4);
    Space v754_8;
    if (!v754_5.empty()) {
      const Path v755_6 = concat_path(p0,v753_9_head);
      Space v755_7_result;
      for (int v755_7_label = 1; v755_7_label <= 2; ++v755_7_label) {
        const Space v755_7_tail = child(v753_9_tail,v755_7_label);
        if (v755_7_tail.empty()) continue;
        const Path v755_7_head{v755_7_label};
        const Space v756_2 = singleton(v755_7_head);
        const Space v756_3 = intersect(constant_2,v756_2);
        const Space v756_4 = (has_head(v756_3) ? constant_3 : Space{});
        const Space v756_5 = subtract(constant_1,v756_4);
        Space v756_8;
        if (!v756_5.empty()) {
          const Path v757_6 = concat_path(v755_6,v755_7_head);
          const Space v757_7 = routine_120(c, v757_6, p1, v755_7_tail);
          v756_8 = compose(v756_5,v757_7);
        }
        const Space v756_9 = intersect(constant_2,v756_2);
        const Space v756_10 = (has_head(v756_9) ? constant_3 : Space{});
        Space v756_12;
        if (!v756_10.empty()) {
          const Path v758_6 = concat_path(v755_6,v755_7_head);
          const Space v758_11 = routine_121(c, v758_6, p1, v755_7_tail);
          v756_12 = compose(v756_10,v758_11);
        }
        const Space v756_13 = unite(v756_8,v756_12);
        v755_7_result = unite(v755_7_result,v756_13);
      }
      const Space v755_7 = std::move(v755_7_result);
      v754_8 = compose(v754_5,v755_7);
    }
    const Space v754_9 = intersect(constant_2,v754_2);
    const Space v754_10 = (has_head(v754_9) ? constant_3 : Space{});
    const Space v754_11 = compose(v754_10,v753_9_tail);
    const Path v759_6 = concat_path(p0,v753_9_head);
    const Space v754_12 = wrap(v754_11,v759_6);
    const Space v754_13 = wrap(v754_12,p1);
    const Space v754_14 = unite(v754_8,v754_13);
    v753_9_result = unite(v753_9_result,v754_14);
  }
  const Space v753_9 = std::move(v753_9_result);
  return v753_9;
}

static Space routine_78(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v760_3 = wrap(s0,p0);
  const Space v760_4 = wrap(v760_3,p1);
  return v760_4;
}

static Space routine_79(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v761_12_result;
  for (int v761_12_label = 1; v761_12_label <= 2; ++v761_12_label) {
    const Space v761_12_tail = child(s0,v761_12_label);
    if (v761_12_tail.empty()) continue;
    const Path v761_12_head{v761_12_label};
    const Space v762_2 = singleton(v761_12_head);
    const Space v762_3 = intersect(constant_2,v762_2);
    const Space v762_4 = (has_head(v762_3) ? constant_3 : Space{});
    const Space v762_5 = subtract(constant_1,v762_4);
    Space v762_8;
    if (!v762_5.empty()) {
      const Path v763_6 = concat_path(p0,v761_12_head);
      Space v763_7_result;
      for (int v763_7_label = 1; v763_7_label <= 2; ++v763_7_label) {
        const Space v763_7_tail = child(v761_12_tail,v763_7_label);
        if (v763_7_tail.empty()) continue;
        const Path v763_7_head{v763_7_label};
        const Space v764_2 = singleton(v763_7_head);
        const Space v764_3 = intersect(constant_2,v764_2);
        const Space v764_4 = (has_head(v764_3) ? constant_3 : Space{});
        const Space v764_5 = subtract(constant_1,v764_4);
        Space v764_8;
        if (!v764_5.empty()) {
          const Path v765_6 = concat_path(v763_6,v763_7_head);
          const Space v765_7 = routine_122(c, v765_6, v763_7_tail, s1);
          v764_8 = compose(v764_5,v765_7);
        }
        const Space v764_9 = intersect(constant_2,v764_2);
        const Space v764_10 = (has_head(v764_9) ? constant_3 : Space{});
        Space v764_12;
        if (!v764_10.empty()) {
          const Path v766_6 = concat_path(v763_6,v763_7_head);
          const Space v766_11 = routine_123(c, v766_6, v763_7_tail, s1);
          v764_12 = compose(v764_10,v766_11);
        }
        const Space v764_13 = unite(v764_8,v764_12);
        v763_7_result = unite(v763_7_result,v764_13);
      }
      const Space v763_7 = std::move(v763_7_result);
      v762_8 = compose(v762_5,v763_7);
    }
    const Space v762_9 = intersect(constant_2,v762_2);
    const Space v762_10 = (has_head(v762_9) ? constant_3 : Space{});
    Space v762_12;
    if (!v762_10.empty()) {
      const Path v767_6 = concat_path(p0,v761_12_head);
      Space v767_11_result;
      for (int v767_11_label = 1; v767_11_label <= 2; ++v767_11_label) {
        const Space v767_11_tail = child(v761_12_tail,v767_11_label);
        if (v767_11_tail.empty()) continue;
        const Path v767_11_head{v767_11_label};
        const Space v768_2 = singleton(v767_11_head);
        const Space v768_3 = intersect(constant_2,v768_2);
        const Space v768_4 = (has_head(v768_3) ? constant_3 : Space{});
        const Space v768_5 = subtract(constant_1,v768_4);
        Space v768_8;
        if (!v768_5.empty()) {
          const Path v769_6 = concat_path(v767_6,v767_11_head);
          const Space v769_7 = routine_122(c, v769_6, v767_11_tail, s1);
          v768_8 = compose(v768_5,v769_7);
        }
        const Space v768_9 = intersect(constant_2,v768_2);
        const Space v768_10 = (has_head(v768_9) ? constant_3 : Space{});
        Space v768_12;
        if (!v768_10.empty()) {
          const Path v770_6 = concat_path(v767_6,v767_11_head);
          const Space v770_11 = routine_12(c, v770_6, v767_11_tail, s1);
          v768_12 = compose(v768_10,v770_11);
        }
        const Space v768_13 = unite(v768_8,v768_12);
        v767_11_result = unite(v767_11_result,v768_13);
      }
      const Space v767_11 = std::move(v767_11_result);
      v762_12 = compose(v762_10,v767_11);
    }
    const Space v762_13 = unite(v762_8,v762_12);
    v761_12_result = unite(v761_12_result,v762_13);
  }
  const Space v761_12 = std::move(v761_12_result);
  return v761_12;
}

static Space routine_80(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v771_12_result;
  for (int v771_12_label = 1; v771_12_label <= 2; ++v771_12_label) {
    const Space v771_12_tail = child(s0,v771_12_label);
    if (v771_12_tail.empty()) continue;
    const Path v771_12_head{v771_12_label};
    const Space v772_2 = singleton(v771_12_head);
    const Space v772_3 = intersect(constant_2,v772_2);
    const Space v772_4 = (has_head(v772_3) ? constant_3 : Space{});
    const Space v772_5 = subtract(constant_1,v772_4);
    Space v772_8;
    if (!v772_5.empty()) {
      const Path v773_6 = concat_path(p0,v771_12_head);
      Space v773_7_result;
      for (int v773_7_label = 1; v773_7_label <= 2; ++v773_7_label) {
        const Space v773_7_tail = child(v771_12_tail,v773_7_label);
        if (v773_7_tail.empty()) continue;
        const Path v773_7_head{v773_7_label};
        const Space v774_2 = singleton(v773_7_head);
        const Space v774_3 = intersect(constant_2,v774_2);
        const Space v774_4 = (has_head(v774_3) ? constant_3 : Space{});
        const Space v774_5 = subtract(constant_1,v774_4);
        Space v774_8;
        if (!v774_5.empty()) {
          const Path v775_6 = concat_path(v773_6,v773_7_head);
          const Space v775_7 = routine_122(c, v775_6, v773_7_tail, s1);
          v774_8 = compose(v774_5,v775_7);
        }
        const Space v774_9 = intersect(constant_2,v774_2);
        const Space v774_10 = (has_head(v774_9) ? constant_3 : Space{});
        Space v774_12;
        if (!v774_10.empty()) {
          const Path v776_6 = concat_path(v773_6,v773_7_head);
          const Space v776_11 = routine_123(c, v776_6, v773_7_tail, s1);
          v774_12 = compose(v774_10,v776_11);
        }
        const Space v774_13 = unite(v774_8,v774_12);
        v773_7_result = unite(v773_7_result,v774_13);
      }
      const Space v773_7 = std::move(v773_7_result);
      v772_8 = compose(v772_5,v773_7);
    }
    const Space v772_9 = intersect(constant_2,v772_2);
    const Space v772_10 = (has_head(v772_9) ? constant_3 : Space{});
    Space v772_12;
    if (!v772_10.empty()) {
      const Path v777_6 = concat_path(p0,v771_12_head);
      Space v777_11_result;
      for (int v777_11_label = 1; v777_11_label <= 2; ++v777_11_label) {
        const Space v777_11_tail = child(v771_12_tail,v777_11_label);
        if (v777_11_tail.empty()) continue;
        const Path v777_11_head{v777_11_label};
        const Space v778_2 = singleton(v777_11_head);
        const Space v778_3 = intersect(constant_2,v778_2);
        const Space v778_4 = (has_head(v778_3) ? constant_3 : Space{});
        const Space v778_5 = subtract(constant_1,v778_4);
        Space v778_7;
        if (!v778_5.empty()) {
          const Space v779_6 = routine_39(c, v777_11_head, v777_6, v777_11_tail, s1);
          v778_7 = compose(v778_5,v779_6);
        }
        const Space v778_8 = intersect(constant_2,v778_2);
        const Space v778_9 = (has_head(v778_8) ? constant_3 : Space{});
        Space v778_11;
        if (!v778_9.empty()) {
          const Space v780_10 = routine_40(c, v777_11_head, v777_6, v777_11_tail, s1);
          v778_11 = compose(v778_9,v780_10);
        }
        const Space v778_12 = unite(v778_7,v778_11);
        v777_11_result = unite(v777_11_result,v778_12);
      }
      const Space v777_11 = std::move(v777_11_result);
      v772_12 = compose(v772_10,v777_11);
    }
    const Space v772_13 = unite(v772_8,v772_12);
    v771_12_result = unite(v771_12_result,v772_13);
  }
  const Space v771_12 = std::move(v771_12_result);
  return v771_12;
}

static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v781_13_result;
  for (int v781_13_label = 1; v781_13_label <= 2; ++v781_13_label) {
    const Space v781_13_tail = child(s0,v781_13_label);
    if (v781_13_tail.empty()) continue;
    const Path v781_13_head{v781_13_label};
    const Space v782_2 = singleton(v781_13_head);
    const Space v782_3 = intersect(constant_2,v782_2);
    const Space v782_4 = (has_head(v782_3) ? constant_3 : Space{});
    const Space v782_5 = subtract(constant_1,v782_4);
    Space v782_8;
    if (!v782_5.empty()) {
      const Path v783_6 = concat_path(p0,v781_13_head);
      Space v783_7_result;
      for (int v783_7_label = 1; v783_7_label <= 2; ++v783_7_label) {
        const Space v783_7_tail = child(v781_13_tail,v783_7_label);
        if (v783_7_tail.empty()) continue;
        const Path v783_7_head{v783_7_label};
        const Space v784_2 = singleton(v783_7_head);
        const Space v784_3 = intersect(constant_2,v784_2);
        const Space v784_4 = (has_head(v784_3) ? constant_3 : Space{});
        const Space v784_5 = subtract(constant_1,v784_4);
        Space v784_8;
        if (!v784_5.empty()) {
          const Path v785_6 = concat_path(v783_6,v783_7_head);
          const Space v785_7 = routine_124(c, v785_6, p1, v783_7_tail, s1);
          v784_8 = compose(v784_5,v785_7);
        }
        const Space v784_9 = intersect(constant_2,v784_2);
        const Space v784_10 = (has_head(v784_9) ? constant_3 : Space{});
        Space v784_12;
        if (!v784_10.empty()) {
          const Path v786_6 = concat_path(v783_6,v783_7_head);
          const Space v786_11 = routine_125(c, v786_6, p1, v783_7_tail, s1);
          v784_12 = compose(v784_10,v786_11);
        }
        const Space v784_13 = unite(v784_8,v784_12);
        v783_7_result = unite(v783_7_result,v784_13);
      }
      const Space v783_7 = std::move(v783_7_result);
      v782_8 = compose(v782_5,v783_7);
    }
    const Space v782_9 = intersect(constant_2,v782_2);
    const Space v782_10 = (has_head(v782_9) ? constant_3 : Space{});
    Space v782_12;
    if (!v782_10.empty()) {
      const Path v787_6 = concat_path(p0,v781_13_head);
      Space v787_11_result;
      for (int v787_11_label = 1; v787_11_label <= 2; ++v787_11_label) {
        const Space v787_11_tail = child(v781_13_tail,v787_11_label);
        if (v787_11_tail.empty()) continue;
        const Path v787_11_head{v787_11_label};
        const Space v788_2 = singleton(v787_11_head);
        const Space v788_3 = intersect(constant_2,v788_2);
        const Space v788_4 = (has_head(v788_3) ? constant_3 : Space{});
        const Space v788_5 = subtract(constant_1,v788_4);
        Space v788_8;
        if (!v788_5.empty()) {
          const Path v789_6 = concat_path(v787_6,v787_11_head);
          const Space v789_7 = routine_124(c, v789_6, p1, v787_11_tail, s1);
          v788_8 = compose(v788_5,v789_7);
        }
        const Space v788_9 = intersect(constant_2,v788_2);
        const Space v788_10 = (has_head(v788_9) ? constant_3 : Space{});
        Space v788_12;
        if (!v788_10.empty()) {
          const Path v790_6 = concat_path(v787_6,v787_11_head);
          const Space v790_11 = routine_43(c, v790_6, p1, v787_11_tail, s1);
          v788_12 = compose(v788_10,v790_11);
        }
        const Space v788_13 = unite(v788_8,v788_12);
        v787_11_result = unite(v787_11_result,v788_13);
      }
      const Space v787_11 = std::move(v787_11_result);
      v782_12 = compose(v782_10,v787_11);
    }
    const Space v782_13 = unite(v782_8,v782_12);
    v781_13_result = unite(v781_13_result,v782_13);
  }
  const Space v781_13 = std::move(v781_13_result);
  return v781_13;
}

static Space routine_82(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v791_8 = unwrap(s1,constant_4);
  const Space v791_10 = unwrap(v791_8,constant_6);
  const Space v791_11 = unwrap(v791_10,p0);
  Space v791_18_result;
  for (int v791_18_label = 1; v791_18_label <= 2; ++v791_18_label) {
    const Space v791_18_tail = child(s0,v791_18_label);
    if (v791_18_tail.empty()) continue;
    const Path v791_18_head{v791_18_label};
    const Space v792_2 = singleton(v791_18_head);
    const Space v792_3 = intersect(constant_2,v792_2);
    const Space v792_4 = (has_head(v792_3) ? constant_3 : Space{});
    const Space v792_5 = subtract(constant_1,v792_4);
    Space v792_8;
    if (!v792_5.empty()) {
      const Path v793_6 = concat_path(p0,v791_18_head);
      Space v793_7_result;
      for (int v793_7_label = 1; v793_7_label <= 2; ++v793_7_label) {
        const Space v793_7_tail = child(v791_18_tail,v793_7_label);
        if (v793_7_tail.empty()) continue;
        const Path v793_7_head{v793_7_label};
        const Space v794_2 = singleton(v793_7_head);
        const Space v794_3 = intersect(constant_2,v794_2);
        const Space v794_4 = (has_head(v794_3) ? constant_3 : Space{});
        const Space v794_5 = subtract(constant_1,v794_4);
        Space v794_8;
        if (!v794_5.empty()) {
          const Path v795_6 = concat_path(v793_6,v793_7_head);
          const Space v795_7 = routine_124(c, v795_6, p1, v793_7_tail, s1);
          v794_8 = compose(v794_5,v795_7);
        }
        const Space v794_9 = intersect(constant_2,v794_2);
        const Space v794_10 = (has_head(v794_9) ? constant_3 : Space{});
        Space v794_12;
        if (!v794_10.empty()) {
          const Path v796_6 = concat_path(v793_6,v793_7_head);
          const Space v796_11 = routine_125(c, v796_6, p1, v793_7_tail, s1);
          v794_12 = compose(v794_10,v796_11);
        }
        const Space v794_13 = unite(v794_8,v794_12);
        v793_7_result = unite(v793_7_result,v794_13);
      }
      const Space v793_7 = std::move(v793_7_result);
      v792_8 = compose(v792_5,v793_7);
    }
    const Space v792_9 = intersect(constant_2,v792_2);
    const Space v792_10 = (has_head(v792_9) ? constant_3 : Space{});
    Space v792_13;
    if (!v792_10.empty()) {
      const Space v797_11 = unwrap(v791_11,v791_18_head);
      Space v797_12_result;
      for (int v797_12_label = 1; v797_12_label <= 2; ++v797_12_label) {
        const Space v797_12_tail = child(v797_11,v797_12_label);
        if (v797_12_tail.empty()) continue;
        const Path v797_12_head{v797_12_label};
        const Space v798_2 = singleton(v797_12_head);
        const Space v798_3 = intersect(constant_2,v798_2);
        const Space v798_4 = (has_head(v798_3) ? constant_3 : Space{});
        const Space v798_5 = subtract(constant_1,v798_4);
        Space v798_7;
        if (!v798_5.empty()) {
          const Space v799_6 = routine_83(c, v797_12_head, p1, v797_12_tail);
          v798_7 = compose(v798_5,v799_6);
        }
        const Space v798_8 = intersect(constant_2,v798_2);
        const Space v798_9 = (has_head(v798_8) ? constant_3 : Space{});
        Space v798_11;
        if (!v798_9.empty()) {
          const Space v800_10 = routine_84(c, v797_12_head, p1, v797_12_tail);
          v798_11 = compose(v798_9,v800_10);
        }
        const Space v798_12 = unite(v798_7,v798_11);
        v797_12_result = unite(v797_12_result,v798_12);
      }
      const Space v797_12 = std::move(v797_12_result);
      v792_13 = compose(v792_10,v797_12);
    }
    const Space v792_14 = unite(v792_8,v792_13);
    v791_18_result = unite(v791_18_result,v792_14);
  }
  const Space v791_18 = std::move(v791_18_result);
  return v791_18;
}

static Space routine_83(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v801_12_result;
  for (int v801_12_label = 1; v801_12_label <= 2; ++v801_12_label) {
    const Space v801_12_tail = child(s0,v801_12_label);
    if (v801_12_tail.empty()) continue;
    const Path v801_12_head{v801_12_label};
    const Space v802_2 = singleton(v801_12_head);
    const Space v802_3 = intersect(constant_2,v802_2);
    const Space v802_4 = (has_head(v802_3) ? constant_3 : Space{});
    const Space v802_5 = subtract(constant_1,v802_4);
    Space v802_8;
    if (!v802_5.empty()) {
      const Path v803_6 = concat_path(p0,v801_12_head);
      Space v803_7_result;
      for (int v803_7_label = 1; v803_7_label <= 2; ++v803_7_label) {
        const Space v803_7_tail = child(v801_12_tail,v803_7_label);
        if (v803_7_tail.empty()) continue;
        const Path v803_7_head{v803_7_label};
        const Space v804_2 = singleton(v803_7_head);
        const Space v804_3 = intersect(constant_2,v804_2);
        const Space v804_4 = (has_head(v804_3) ? constant_3 : Space{});
        const Space v804_5 = subtract(constant_1,v804_4);
        Space v804_8;
        if (!v804_5.empty()) {
          const Path v805_6 = concat_path(v803_6,v803_7_head);
          const Space v805_7 = routine_126(c, v805_6, p1, v803_7_tail);
          v804_8 = compose(v804_5,v805_7);
        }
        const Space v804_9 = intersect(constant_2,v804_2);
        const Space v804_10 = (has_head(v804_9) ? constant_3 : Space{});
        Space v804_12;
        if (!v804_10.empty()) {
          const Path v806_6 = concat_path(v803_6,v803_7_head);
          const Space v806_11 = routine_127(c, v806_6, p1, v803_7_tail);
          v804_12 = compose(v804_10,v806_11);
        }
        const Space v804_13 = unite(v804_8,v804_12);
        v803_7_result = unite(v803_7_result,v804_13);
      }
      const Space v803_7 = std::move(v803_7_result);
      v802_8 = compose(v802_5,v803_7);
    }
    const Space v802_9 = intersect(constant_2,v802_2);
    const Space v802_10 = (has_head(v802_9) ? constant_3 : Space{});
    Space v802_12;
    if (!v802_10.empty()) {
      const Path v807_6 = concat_path(p0,v801_12_head);
      Space v807_11_result;
      for (int v807_11_label = 1; v807_11_label <= 2; ++v807_11_label) {
        const Space v807_11_tail = child(v801_12_tail,v807_11_label);
        if (v807_11_tail.empty()) continue;
        const Path v807_11_head{v807_11_label};
        const Space v808_2 = singleton(v807_11_head);
        const Space v808_3 = intersect(constant_2,v808_2);
        const Space v808_4 = (has_head(v808_3) ? constant_3 : Space{});
        const Space v808_5 = subtract(constant_1,v808_4);
        Space v808_8;
        if (!v808_5.empty()) {
          const Path v809_6 = concat_path(v807_6,v807_11_head);
          const Space v809_7 = routine_126(c, v809_6, p1, v807_11_tail);
          v808_8 = compose(v808_5,v809_7);
        }
        const Space v808_9 = intersect(constant_2,v808_2);
        const Space v808_10 = (has_head(v808_9) ? constant_3 : Space{});
        Space v808_12;
        if (!v808_10.empty()) {
          const Path v810_6 = concat_path(v807_6,v807_11_head);
          const Space v810_11 = routine_89(c, v810_6, p1, v807_11_tail);
          v808_12 = compose(v808_10,v810_11);
        }
        const Space v808_13 = unite(v808_8,v808_12);
        v807_11_result = unite(v807_11_result,v808_13);
      }
      const Space v807_11 = std::move(v807_11_result);
      v802_12 = compose(v802_10,v807_11);
    }
    const Space v802_13 = unite(v802_8,v802_12);
    v801_12_result = unite(v801_12_result,v802_13);
  }
  const Space v801_12 = std::move(v801_12_result);
  return v801_12;
}

static Space routine_84(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v811_9_result;
  for (int v811_9_label = 1; v811_9_label <= 2; ++v811_9_label) {
    const Space v811_9_tail = child(s0,v811_9_label);
    if (v811_9_tail.empty()) continue;
    const Path v811_9_head{v811_9_label};
    const Space v812_2 = singleton(v811_9_head);
    const Space v812_3 = intersect(constant_2,v812_2);
    const Space v812_4 = (has_head(v812_3) ? constant_3 : Space{});
    const Space v812_5 = subtract(constant_1,v812_4);
    Space v812_8;
    if (!v812_5.empty()) {
      const Path v813_6 = concat_path(p0,v811_9_head);
      Space v813_7_result;
      for (int v813_7_label = 1; v813_7_label <= 2; ++v813_7_label) {
        const Space v813_7_tail = child(v811_9_tail,v813_7_label);
        if (v813_7_tail.empty()) continue;
        const Path v813_7_head{v813_7_label};
        const Space v814_2 = singleton(v813_7_head);
        const Space v814_3 = intersect(constant_2,v814_2);
        const Space v814_4 = (has_head(v814_3) ? constant_3 : Space{});
        const Space v814_5 = subtract(constant_1,v814_4);
        Space v814_8;
        if (!v814_5.empty()) {
          const Path v815_6 = concat_path(v813_6,v813_7_head);
          const Space v815_7 = routine_126(c, v815_6, p1, v813_7_tail);
          v814_8 = compose(v814_5,v815_7);
        }
        const Space v814_9 = intersect(constant_2,v814_2);
        const Space v814_10 = (has_head(v814_9) ? constant_3 : Space{});
        Space v814_12;
        if (!v814_10.empty()) {
          const Path v816_6 = concat_path(v813_6,v813_7_head);
          const Space v816_11 = routine_127(c, v816_6, p1, v813_7_tail);
          v814_12 = compose(v814_10,v816_11);
        }
        const Space v814_13 = unite(v814_8,v814_12);
        v813_7_result = unite(v813_7_result,v814_13);
      }
      const Space v813_7 = std::move(v813_7_result);
      v812_8 = compose(v812_5,v813_7);
    }
    const Space v812_9 = intersect(constant_2,v812_2);
    const Space v812_10 = (has_head(v812_9) ? constant_3 : Space{});
    const Space v812_11 = compose(v812_10,v811_9_tail);
    const Path v817_6 = concat_path(p0,v811_9_head);
    const Space v812_12 = wrap(v812_11,v817_6);
    const Space v812_13 = wrap(v812_12,p1);
    const Space v812_14 = unite(v812_8,v812_13);
    v811_9_result = unite(v811_9_result,v812_14);
  }
  const Space v811_9 = std::move(v811_9_result);
  return v811_9;
}

static Space routine_85(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v818_13_result;
  for (int v818_13_label = 1; v818_13_label <= 2; ++v818_13_label) {
    const Space v818_13_tail = child(s0,v818_13_label);
    if (v818_13_tail.empty()) continue;
    const Path v818_13_head{v818_13_label};
    const Space v819_2 = singleton(v818_13_head);
    const Space v819_3 = intersect(constant_2,v819_2);
    const Space v819_4 = (has_head(v819_3) ? constant_3 : Space{});
    const Space v819_5 = subtract(constant_1,v819_4);
    Space v819_8;
    if (!v819_5.empty()) {
      const Path v820_6 = concat_path(p0,v818_13_head);
      Space v820_7_result;
      for (int v820_7_label = 1; v820_7_label <= 2; ++v820_7_label) {
        const Space v820_7_tail = child(v818_13_tail,v820_7_label);
        if (v820_7_tail.empty()) continue;
        const Path v820_7_head{v820_7_label};
        const Space v821_2 = singleton(v820_7_head);
        const Space v821_3 = intersect(constant_2,v821_2);
        const Space v821_4 = (has_head(v821_3) ? constant_3 : Space{});
        const Space v821_5 = subtract(constant_1,v821_4);
        Space v821_8;
        if (!v821_5.empty()) {
          const Path v822_6 = concat_path(v820_6,v820_7_head);
          const Space v822_7 = routine_128(c, v822_6, p1, v820_7_tail, s1);
          v821_8 = compose(v821_5,v822_7);
        }
        const Space v821_9 = intersect(constant_2,v821_2);
        const Space v821_10 = (has_head(v821_9) ? constant_3 : Space{});
        Space v821_12;
        if (!v821_10.empty()) {
          const Path v823_6 = concat_path(v820_6,v820_7_head);
          const Space v823_11 = routine_129(c, v823_6, p1, v820_7_tail, s1);
          v821_12 = compose(v821_10,v823_11);
        }
        const Space v821_13 = unite(v821_8,v821_12);
        v820_7_result = unite(v820_7_result,v821_13);
      }
      const Space v820_7 = std::move(v820_7_result);
      v819_8 = compose(v819_5,v820_7);
    }
    const Space v819_9 = intersect(constant_2,v819_2);
    const Space v819_10 = (has_head(v819_9) ? constant_3 : Space{});
    Space v819_12;
    if (!v819_10.empty()) {
      const Path v824_6 = concat_path(p0,v818_13_head);
      Space v824_11_result;
      for (int v824_11_label = 1; v824_11_label <= 2; ++v824_11_label) {
        const Space v824_11_tail = child(v818_13_tail,v824_11_label);
        if (v824_11_tail.empty()) continue;
        const Path v824_11_head{v824_11_label};
        const Space v825_2 = singleton(v824_11_head);
        const Space v825_3 = intersect(constant_2,v825_2);
        const Space v825_4 = (has_head(v825_3) ? constant_3 : Space{});
        const Space v825_5 = subtract(constant_1,v825_4);
        Space v825_8;
        if (!v825_5.empty()) {
          const Path v826_6 = concat_path(v824_6,v824_11_head);
          const Space v826_7 = routine_128(c, v826_6, p1, v824_11_tail, s1);
          v825_8 = compose(v825_5,v826_7);
        }
        const Space v825_9 = intersect(constant_2,v825_2);
        const Space v825_10 = (has_head(v825_9) ? constant_3 : Space{});
        Space v825_12;
        if (!v825_10.empty()) {
          const Path v827_6 = concat_path(v824_6,v824_11_head);
          const Space v827_11 = routine_43(c, v827_6, p1, v824_11_tail, s1);
          v825_12 = compose(v825_10,v827_11);
        }
        const Space v825_13 = unite(v825_8,v825_12);
        v824_11_result = unite(v824_11_result,v825_13);
      }
      const Space v824_11 = std::move(v824_11_result);
      v819_12 = compose(v819_10,v824_11);
    }
    const Space v819_13 = unite(v819_8,v819_12);
    v818_13_result = unite(v818_13_result,v819_13);
  }
  const Space v818_13 = std::move(v818_13_result);
  return v818_13;
}

static Space routine_86(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v828_8 = unwrap(s1,constant_4);
  const Space v828_10 = unwrap(v828_8,constant_6);
  const Space v828_11 = unwrap(v828_10,p0);
  Space v828_18_result;
  for (int v828_18_label = 1; v828_18_label <= 2; ++v828_18_label) {
    const Space v828_18_tail = child(s0,v828_18_label);
    if (v828_18_tail.empty()) continue;
    const Path v828_18_head{v828_18_label};
    const Space v829_2 = singleton(v828_18_head);
    const Space v829_3 = intersect(constant_2,v829_2);
    const Space v829_4 = (has_head(v829_3) ? constant_3 : Space{});
    const Space v829_5 = subtract(constant_1,v829_4);
    Space v829_8;
    if (!v829_5.empty()) {
      const Path v830_6 = concat_path(p0,v828_18_head);
      Space v830_7_result;
      for (int v830_7_label = 1; v830_7_label <= 2; ++v830_7_label) {
        const Space v830_7_tail = child(v828_18_tail,v830_7_label);
        if (v830_7_tail.empty()) continue;
        const Path v830_7_head{v830_7_label};
        const Space v831_2 = singleton(v830_7_head);
        const Space v831_3 = intersect(constant_2,v831_2);
        const Space v831_4 = (has_head(v831_3) ? constant_3 : Space{});
        const Space v831_5 = subtract(constant_1,v831_4);
        Space v831_8;
        if (!v831_5.empty()) {
          const Path v832_6 = concat_path(v830_6,v830_7_head);
          const Space v832_7 = routine_128(c, v832_6, p1, v830_7_tail, s1);
          v831_8 = compose(v831_5,v832_7);
        }
        const Space v831_9 = intersect(constant_2,v831_2);
        const Space v831_10 = (has_head(v831_9) ? constant_3 : Space{});
        Space v831_12;
        if (!v831_10.empty()) {
          const Path v833_6 = concat_path(v830_6,v830_7_head);
          const Space v833_11 = routine_129(c, v833_6, p1, v830_7_tail, s1);
          v831_12 = compose(v831_10,v833_11);
        }
        const Space v831_13 = unite(v831_8,v831_12);
        v830_7_result = unite(v830_7_result,v831_13);
      }
      const Space v830_7 = std::move(v830_7_result);
      v829_8 = compose(v829_5,v830_7);
    }
    const Space v829_9 = intersect(constant_2,v829_2);
    const Space v829_10 = (has_head(v829_9) ? constant_3 : Space{});
    Space v829_13;
    if (!v829_10.empty()) {
      const Space v834_11 = unwrap(v828_11,v828_18_head);
      Space v834_12_result;
      for (int v834_12_label = 1; v834_12_label <= 2; ++v834_12_label) {
        const Space v834_12_tail = child(v834_11,v834_12_label);
        if (v834_12_tail.empty()) continue;
        const Path v834_12_head{v834_12_label};
        const Space v835_2 = singleton(v834_12_head);
        const Space v835_3 = intersect(constant_2,v835_2);
        const Space v835_4 = (has_head(v835_3) ? constant_3 : Space{});
        const Space v835_5 = subtract(constant_1,v835_4);
        Space v835_7;
        if (!v835_5.empty()) {
          const Space v836_6 = routine_83(c, v834_12_head, p1, v834_12_tail);
          v835_7 = compose(v835_5,v836_6);
        }
        const Space v835_8 = intersect(constant_2,v835_2);
        const Space v835_9 = (has_head(v835_8) ? constant_3 : Space{});
        Space v835_11;
        if (!v835_9.empty()) {
          const Space v837_10 = routine_84(c, v834_12_head, p1, v834_12_tail);
          v835_11 = compose(v835_9,v837_10);
        }
        const Space v835_12 = unite(v835_7,v835_11);
        v834_12_result = unite(v834_12_result,v835_12);
      }
      const Space v834_12 = std::move(v834_12_result);
      v829_13 = compose(v829_10,v834_12);
    }
    const Space v829_14 = unite(v829_8,v829_13);
    v828_18_result = unite(v828_18_result,v829_14);
  }
  const Space v828_18 = std::move(v828_18_result);
  return v828_18;
}

static Space routine_87(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v838_12_result;
  for (int v838_12_label = 1; v838_12_label <= 2; ++v838_12_label) {
    const Space v838_12_tail = child(s0,v838_12_label);
    if (v838_12_tail.empty()) continue;
    const Path v838_12_head{v838_12_label};
    const Space v839_2 = singleton(v838_12_head);
    const Space v839_3 = intersect(constant_2,v839_2);
    const Space v839_4 = (has_head(v839_3) ? constant_3 : Space{});
    const Space v839_5 = subtract(constant_1,v839_4);
    Space v839_8;
    if (!v839_5.empty()) {
      const Path v840_6 = concat_path(p0,v838_12_head);
      Space v840_7_result;
      for (int v840_7_label = 1; v840_7_label <= 2; ++v840_7_label) {
        const Space v840_7_tail = child(v838_12_tail,v840_7_label);
        if (v840_7_tail.empty()) continue;
        const Path v840_7_head{v840_7_label};
        const Space v841_2 = singleton(v840_7_head);
        const Space v841_3 = intersect(constant_2,v841_2);
        const Space v841_4 = (has_head(v841_3) ? constant_3 : Space{});
        const Space v841_5 = subtract(constant_1,v841_4);
        Space v841_8;
        if (!v841_5.empty()) {
          const Path v842_6 = concat_path(v840_6,v840_7_head);
          const Space v842_7 = routine_130(c, v842_6, p1, v840_7_tail);
          v841_8 = compose(v841_5,v842_7);
        }
        const Space v841_9 = intersect(constant_2,v841_2);
        const Space v841_10 = (has_head(v841_9) ? constant_3 : Space{});
        Space v841_12;
        if (!v841_10.empty()) {
          const Path v843_6 = concat_path(v840_6,v840_7_head);
          const Space v843_11 = routine_131(c, v843_6, p1, v840_7_tail);
          v841_12 = compose(v841_10,v843_11);
        }
        const Space v841_13 = unite(v841_8,v841_12);
        v840_7_result = unite(v840_7_result,v841_13);
      }
      const Space v840_7 = std::move(v840_7_result);
      v839_8 = compose(v839_5,v840_7);
    }
    const Space v839_9 = intersect(constant_2,v839_2);
    const Space v839_10 = (has_head(v839_9) ? constant_3 : Space{});
    Space v839_12;
    if (!v839_10.empty()) {
      const Path v844_6 = concat_path(p0,v838_12_head);
      Space v844_11_result;
      for (int v844_11_label = 1; v844_11_label <= 2; ++v844_11_label) {
        const Space v844_11_tail = child(v838_12_tail,v844_11_label);
        if (v844_11_tail.empty()) continue;
        const Path v844_11_head{v844_11_label};
        const Space v845_2 = singleton(v844_11_head);
        const Space v845_3 = intersect(constant_2,v845_2);
        const Space v845_4 = (has_head(v845_3) ? constant_3 : Space{});
        const Space v845_5 = subtract(constant_1,v845_4);
        Space v845_8;
        if (!v845_5.empty()) {
          const Path v846_6 = concat_path(v844_6,v844_11_head);
          const Space v846_7 = routine_130(c, v846_6, p1, v844_11_tail);
          v845_8 = compose(v845_5,v846_7);
        }
        const Space v845_9 = intersect(constant_2,v845_2);
        const Space v845_10 = (has_head(v845_9) ? constant_3 : Space{});
        Space v845_12;
        if (!v845_10.empty()) {
          const Path v847_6 = concat_path(v844_6,v844_11_head);
          const Space v847_11 = routine_89(c, v847_6, p1, v844_11_tail);
          v845_12 = compose(v845_10,v847_11);
        }
        const Space v845_13 = unite(v845_8,v845_12);
        v844_11_result = unite(v844_11_result,v845_13);
      }
      const Space v844_11 = std::move(v844_11_result);
      v839_12 = compose(v839_10,v844_11);
    }
    const Space v839_13 = unite(v839_8,v839_12);
    v838_12_result = unite(v838_12_result,v839_13);
  }
  const Space v838_12 = std::move(v838_12_result);
  return v838_12;
}

static Space routine_88(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v848_9_result;
  for (int v848_9_label = 1; v848_9_label <= 2; ++v848_9_label) {
    const Space v848_9_tail = child(s0,v848_9_label);
    if (v848_9_tail.empty()) continue;
    const Path v848_9_head{v848_9_label};
    const Space v849_2 = singleton(v848_9_head);
    const Space v849_3 = intersect(constant_2,v849_2);
    const Space v849_4 = (has_head(v849_3) ? constant_3 : Space{});
    const Space v849_5 = subtract(constant_1,v849_4);
    Space v849_8;
    if (!v849_5.empty()) {
      const Path v850_6 = concat_path(p0,v848_9_head);
      Space v850_7_result;
      for (int v850_7_label = 1; v850_7_label <= 2; ++v850_7_label) {
        const Space v850_7_tail = child(v848_9_tail,v850_7_label);
        if (v850_7_tail.empty()) continue;
        const Path v850_7_head{v850_7_label};
        const Space v851_2 = singleton(v850_7_head);
        const Space v851_3 = intersect(constant_2,v851_2);
        const Space v851_4 = (has_head(v851_3) ? constant_3 : Space{});
        const Space v851_5 = subtract(constant_1,v851_4);
        Space v851_8;
        if (!v851_5.empty()) {
          const Path v852_6 = concat_path(v850_6,v850_7_head);
          const Space v852_7 = routine_130(c, v852_6, p1, v850_7_tail);
          v851_8 = compose(v851_5,v852_7);
        }
        const Space v851_9 = intersect(constant_2,v851_2);
        const Space v851_10 = (has_head(v851_9) ? constant_3 : Space{});
        Space v851_12;
        if (!v851_10.empty()) {
          const Path v853_6 = concat_path(v850_6,v850_7_head);
          const Space v853_11 = routine_131(c, v853_6, p1, v850_7_tail);
          v851_12 = compose(v851_10,v853_11);
        }
        const Space v851_13 = unite(v851_8,v851_12);
        v850_7_result = unite(v850_7_result,v851_13);
      }
      const Space v850_7 = std::move(v850_7_result);
      v849_8 = compose(v849_5,v850_7);
    }
    const Space v849_9 = intersect(constant_2,v849_2);
    const Space v849_10 = (has_head(v849_9) ? constant_3 : Space{});
    const Space v849_11 = compose(v849_10,v848_9_tail);
    const Path v854_6 = concat_path(p0,v848_9_head);
    const Space v849_12 = wrap(v849_11,v854_6);
    const Space v849_13 = wrap(v849_12,p1);
    const Space v849_14 = unite(v849_8,v849_13);
    v848_9_result = unite(v848_9_result,v849_14);
  }
  const Space v848_9 = std::move(v848_9_result);
  return v848_9;
}

static Space routine_89(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v855_3 = wrap(s0,p0);
  const Space v855_4 = wrap(v855_3,p1);
  return v855_4;
}

static Space routine_90(Context& c, const Path& p0, const Space& s0) {
  Space v856_11_result;
  for (int v856_11_label = 1; v856_11_label <= 2; ++v856_11_label) {
    const Space v856_11_tail = child(s0,v856_11_label);
    if (v856_11_tail.empty()) continue;
    const Path v856_11_head{v856_11_label};
    const Space v857_2 = singleton(v856_11_head);
    const Space v857_3 = intersect(constant_2,v857_2);
    const Space v857_4 = (has_head(v857_3) ? constant_3 : Space{});
    const Space v857_5 = subtract(constant_1,v857_4);
    Space v857_8;
    if (!v857_5.empty()) {
      const Path v858_6 = concat_path(p0,v856_11_head);
      Space v858_7_result;
      for (int v858_7_label = 1; v858_7_label <= 2; ++v858_7_label) {
        const Space v858_7_tail = child(v856_11_tail,v858_7_label);
        if (v858_7_tail.empty()) continue;
        const Path v858_7_head{v858_7_label};
        const Space v859_2 = singleton(v858_7_head);
        const Space v859_3 = intersect(constant_2,v859_2);
        const Space v859_4 = (has_head(v859_3) ? constant_3 : Space{});
        const Space v859_5 = subtract(constant_1,v859_4);
        Space v859_8;
        if (!v859_5.empty()) {
          const Path v860_6 = concat_path(v858_6,v858_7_head);
          const Space v860_7 = routine_132(c, v860_6, v858_7_tail);
          v859_8 = compose(v859_5,v860_7);
        }
        const Space v859_9 = intersect(constant_2,v859_2);
        const Space v859_10 = (has_head(v859_9) ? constant_3 : Space{});
        Space v859_12;
        if (!v859_10.empty()) {
          const Path v861_6 = concat_path(v858_6,v858_7_head);
          const Space v861_11 = routine_133(c, v861_6, v858_7_tail);
          v859_12 = compose(v859_10,v861_11);
        }
        const Space v859_13 = unite(v859_8,v859_12);
        v858_7_result = unite(v858_7_result,v859_13);
      }
      const Space v858_7 = std::move(v858_7_result);
      v857_8 = compose(v857_5,v858_7);
    }
    const Space v857_9 = intersect(constant_2,v857_2);
    const Space v857_10 = (has_head(v857_9) ? constant_3 : Space{});
    Space v857_12;
    if (!v857_10.empty()) {
      const Path v862_6 = concat_path(p0,v856_11_head);
      Space v862_11_result;
      for (int v862_11_label = 1; v862_11_label <= 2; ++v862_11_label) {
        const Space v862_11_tail = child(v856_11_tail,v862_11_label);
        if (v862_11_tail.empty()) continue;
        const Path v862_11_head{v862_11_label};
        const Space v863_2 = singleton(v862_11_head);
        const Space v863_3 = intersect(constant_2,v863_2);
        const Space v863_4 = (has_head(v863_3) ? constant_3 : Space{});
        const Space v863_5 = subtract(constant_1,v863_4);
        Space v863_8;
        if (!v863_5.empty()) {
          const Path v864_6 = concat_path(v862_6,v862_11_head);
          const Space v864_7 = routine_132(c, v864_6, v862_11_tail);
          v863_8 = compose(v863_5,v864_7);
        }
        const Space v863_9 = intersect(constant_2,v863_2);
        const Space v863_10 = (has_head(v863_9) ? constant_3 : Space{});
        Space v863_12;
        if (!v863_10.empty()) {
          const Path v865_6 = concat_path(v862_6,v862_11_head);
          const Space v865_11 = routine_15(c, v865_6, v862_11_tail);
          v863_12 = compose(v863_10,v865_11);
        }
        const Space v863_13 = unite(v863_8,v863_12);
        v862_11_result = unite(v862_11_result,v863_13);
      }
      const Space v862_11 = std::move(v862_11_result);
      v857_12 = compose(v857_10,v862_11);
    }
    const Space v857_13 = unite(v857_8,v857_12);
    v856_11_result = unite(v856_11_result,v857_13);
  }
  const Space v856_11 = std::move(v856_11_result);
  return v856_11;
}

static Space routine_91(Context& c, const Path& p0, const Space& s0) {
  Space v866_11_result;
  for (int v866_11_label = 1; v866_11_label <= 2; ++v866_11_label) {
    const Space v866_11_tail = child(s0,v866_11_label);
    if (v866_11_tail.empty()) continue;
    const Path v866_11_head{v866_11_label};
    const Space v867_2 = singleton(v866_11_head);
    const Space v867_3 = intersect(constant_2,v867_2);
    const Space v867_4 = (has_head(v867_3) ? constant_3 : Space{});
    const Space v867_5 = subtract(constant_1,v867_4);
    Space v867_8;
    if (!v867_5.empty()) {
      const Path v868_6 = concat_path(p0,v866_11_head);
      Space v868_7_result;
      for (int v868_7_label = 1; v868_7_label <= 2; ++v868_7_label) {
        const Space v868_7_tail = child(v866_11_tail,v868_7_label);
        if (v868_7_tail.empty()) continue;
        const Path v868_7_head{v868_7_label};
        const Space v869_2 = singleton(v868_7_head);
        const Space v869_3 = intersect(constant_2,v869_2);
        const Space v869_4 = (has_head(v869_3) ? constant_3 : Space{});
        const Space v869_5 = subtract(constant_1,v869_4);
        Space v869_8;
        if (!v869_5.empty()) {
          const Path v870_6 = concat_path(v868_6,v868_7_head);
          const Space v870_7 = routine_132(c, v870_6, v868_7_tail);
          v869_8 = compose(v869_5,v870_7);
        }
        const Space v869_9 = intersect(constant_2,v869_2);
        const Space v869_10 = (has_head(v869_9) ? constant_3 : Space{});
        Space v869_12;
        if (!v869_10.empty()) {
          const Path v871_6 = concat_path(v868_6,v868_7_head);
          const Space v871_11 = routine_133(c, v871_6, v868_7_tail);
          v869_12 = compose(v869_10,v871_11);
        }
        const Space v869_13 = unite(v869_8,v869_12);
        v868_7_result = unite(v868_7_result,v869_13);
      }
      const Space v868_7 = std::move(v868_7_result);
      v867_8 = compose(v867_5,v868_7);
    }
    const Space v867_9 = intersect(constant_2,v867_2);
    const Space v867_10 = (has_head(v867_9) ? constant_3 : Space{});
    Space v867_12;
    if (!v867_10.empty()) {
      const Path v872_6 = concat_path(p0,v866_11_head);
      Space v872_11_result;
      for (int v872_11_label = 1; v872_11_label <= 2; ++v872_11_label) {
        const Space v872_11_tail = child(v866_11_tail,v872_11_label);
        if (v872_11_tail.empty()) continue;
        const Path v872_11_head{v872_11_label};
        const Space v873_2 = singleton(v872_11_head);
        const Space v873_3 = intersect(constant_2,v873_2);
        const Space v873_4 = (has_head(v873_3) ? constant_3 : Space{});
        const Space v873_5 = subtract(constant_1,v873_4);
        Space v873_7;
        if (!v873_5.empty()) {
          const Space v874_6 = routine_46(c, v872_11_head, v872_6, v872_11_tail);
          v873_7 = compose(v873_5,v874_6);
        }
        const Space v873_8 = intersect(constant_2,v873_2);
        const Space v873_9 = (has_head(v873_8) ? constant_3 : Space{});
        Space v873_11;
        if (!v873_9.empty()) {
          const Space v875_10 = routine_47(c, v872_11_head, v872_6, v872_11_tail);
          v873_11 = compose(v873_9,v875_10);
        }
        const Space v873_12 = unite(v873_7,v873_11);
        v872_11_result = unite(v872_11_result,v873_12);
      }
      const Space v872_11 = std::move(v872_11_result);
      v867_12 = compose(v867_10,v872_11);
    }
    const Space v867_13 = unite(v867_8,v867_12);
    v866_11_result = unite(v866_11_result,v867_13);
  }
  const Space v866_11 = std::move(v866_11_result);
  return v866_11;
}

static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v876_12_result;
  for (int v876_12_label = 1; v876_12_label <= 2; ++v876_12_label) {
    const Space v876_12_tail = child(s0,v876_12_label);
    if (v876_12_tail.empty()) continue;
    const Path v876_12_head{v876_12_label};
    const Space v877_2 = singleton(v876_12_head);
    const Space v877_3 = intersect(constant_2,v877_2);
    const Space v877_4 = (has_head(v877_3) ? constant_3 : Space{});
    const Space v877_5 = subtract(constant_1,v877_4);
    Space v877_8;
    if (!v877_5.empty()) {
      const Path v878_6 = concat_path(p0,v876_12_head);
      Space v878_7_result;
      for (int v878_7_label = 1; v878_7_label <= 2; ++v878_7_label) {
        const Space v878_7_tail = child(v876_12_tail,v878_7_label);
        if (v878_7_tail.empty()) continue;
        const Path v878_7_head{v878_7_label};
        const Space v879_2 = singleton(v878_7_head);
        const Space v879_3 = intersect(constant_2,v879_2);
        const Space v879_4 = (has_head(v879_3) ? constant_3 : Space{});
        const Space v879_5 = subtract(constant_1,v879_4);
        Space v879_8;
        if (!v879_5.empty()) {
          const Path v880_6 = concat_path(v878_6,v878_7_head);
          const Space v880_7 = routine_134(c, v880_6, p1, v878_7_tail);
          v879_8 = compose(v879_5,v880_7);
        }
        const Space v879_9 = intersect(constant_2,v879_2);
        const Space v879_10 = (has_head(v879_9) ? constant_3 : Space{});
        Space v879_12;
        if (!v879_10.empty()) {
          const Path v881_6 = concat_path(v878_6,v878_7_head);
          const Space v881_11 = routine_135(c, v881_6, p1, v878_7_tail);
          v879_12 = compose(v879_10,v881_11);
        }
        const Space v879_13 = unite(v879_8,v879_12);
        v878_7_result = unite(v878_7_result,v879_13);
      }
      const Space v878_7 = std::move(v878_7_result);
      v877_8 = compose(v877_5,v878_7);
    }
    const Space v877_9 = intersect(constant_2,v877_2);
    const Space v877_10 = (has_head(v877_9) ? constant_3 : Space{});
    Space v877_12;
    if (!v877_10.empty()) {
      const Path v882_6 = concat_path(p0,v876_12_head);
      Space v882_11_result;
      for (int v882_11_label = 1; v882_11_label <= 2; ++v882_11_label) {
        const Space v882_11_tail = child(v876_12_tail,v882_11_label);
        if (v882_11_tail.empty()) continue;
        const Path v882_11_head{v882_11_label};
        const Space v883_2 = singleton(v882_11_head);
        const Space v883_3 = intersect(constant_2,v883_2);
        const Space v883_4 = (has_head(v883_3) ? constant_3 : Space{});
        const Space v883_5 = subtract(constant_1,v883_4);
        Space v883_8;
        if (!v883_5.empty()) {
          const Path v884_6 = concat_path(v882_6,v882_11_head);
          const Space v884_7 = routine_134(c, v884_6, p1, v882_11_tail);
          v883_8 = compose(v883_5,v884_7);
        }
        const Space v883_9 = intersect(constant_2,v883_2);
        const Space v883_10 = (has_head(v883_9) ? constant_3 : Space{});
        Space v883_12;
        if (!v883_10.empty()) {
          const Path v885_6 = concat_path(v882_6,v882_11_head);
          const Space v885_11 = routine_50(c, v885_6, p1, v882_11_tail);
          v883_12 = compose(v883_10,v885_11);
        }
        const Space v883_13 = unite(v883_8,v883_12);
        v882_11_result = unite(v882_11_result,v883_13);
      }
      const Space v882_11 = std::move(v882_11_result);
      v877_12 = compose(v877_10,v882_11);
    }
    const Space v877_13 = unite(v877_8,v877_12);
    v876_12_result = unite(v876_12_result,v877_13);
  }
  const Space v876_12 = std::move(v876_12_result);
  return v876_12;
}

static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v886_9_result;
  for (int v886_9_label = 1; v886_9_label <= 2; ++v886_9_label) {
    const Space v886_9_tail = child(s0,v886_9_label);
    if (v886_9_tail.empty()) continue;
    const Path v886_9_head{v886_9_label};
    const Space v887_2 = singleton(v886_9_head);
    const Space v887_3 = intersect(constant_2,v887_2);
    const Space v887_4 = (has_head(v887_3) ? constant_3 : Space{});
    const Space v887_5 = subtract(constant_1,v887_4);
    Space v887_8;
    if (!v887_5.empty()) {
      const Path v888_6 = concat_path(p0,v886_9_head);
      Space v888_7_result;
      for (int v888_7_label = 1; v888_7_label <= 2; ++v888_7_label) {
        const Space v888_7_tail = child(v886_9_tail,v888_7_label);
        if (v888_7_tail.empty()) continue;
        const Path v888_7_head{v888_7_label};
        const Space v889_2 = singleton(v888_7_head);
        const Space v889_3 = intersect(constant_2,v889_2);
        const Space v889_4 = (has_head(v889_3) ? constant_3 : Space{});
        const Space v889_5 = subtract(constant_1,v889_4);
        Space v889_8;
        if (!v889_5.empty()) {
          const Path v890_6 = concat_path(v888_6,v888_7_head);
          const Space v890_7 = routine_134(c, v890_6, p1, v888_7_tail);
          v889_8 = compose(v889_5,v890_7);
        }
        const Space v889_9 = intersect(constant_2,v889_2);
        const Space v889_10 = (has_head(v889_9) ? constant_3 : Space{});
        Space v889_12;
        if (!v889_10.empty()) {
          const Path v891_6 = concat_path(v888_6,v888_7_head);
          const Space v891_11 = routine_135(c, v891_6, p1, v888_7_tail);
          v889_12 = compose(v889_10,v891_11);
        }
        const Space v889_13 = unite(v889_8,v889_12);
        v888_7_result = unite(v888_7_result,v889_13);
      }
      const Space v888_7 = std::move(v888_7_result);
      v887_8 = compose(v887_5,v888_7);
    }
    const Space v887_9 = intersect(constant_2,v887_2);
    const Space v887_10 = (has_head(v887_9) ? constant_3 : Space{});
    const Space v887_11 = compose(v887_10,v886_9_tail);
    const Path v892_6 = concat_path(p0,v886_9_head);
    const Space v887_12 = wrap(v887_11,v892_6);
    const Space v887_13 = wrap(v887_12,p1);
    const Space v887_14 = unite(v887_8,v887_13);
    v886_9_result = unite(v886_9_result,v887_14);
  }
  const Space v886_9 = std::move(v886_9_result);
  return v886_9;
}

static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v893_12_result;
  for (int v893_12_label = 1; v893_12_label <= 2; ++v893_12_label) {
    const Space v893_12_tail = child(s0,v893_12_label);
    if (v893_12_tail.empty()) continue;
    const Path v893_12_head{v893_12_label};
    const Space v894_2 = singleton(v893_12_head);
    const Space v894_3 = intersect(constant_2,v894_2);
    const Space v894_4 = (has_head(v894_3) ? constant_3 : Space{});
    const Space v894_5 = subtract(constant_1,v894_4);
    Space v894_8;
    if (!v894_5.empty()) {
      const Path v895_6 = concat_path(p0,v893_12_head);
      Space v895_7_result;
      for (int v895_7_label = 1; v895_7_label <= 2; ++v895_7_label) {
        const Space v895_7_tail = child(v893_12_tail,v895_7_label);
        if (v895_7_tail.empty()) continue;
        const Path v895_7_head{v895_7_label};
        const Space v896_2 = singleton(v895_7_head);
        const Space v896_3 = intersect(constant_2,v896_2);
        const Space v896_4 = (has_head(v896_3) ? constant_3 : Space{});
        const Space v896_5 = subtract(constant_1,v896_4);
        Space v896_8;
        if (!v896_5.empty()) {
          const Path v897_6 = concat_path(v895_6,v895_7_head);
          const Space v897_7 = routine_136(c, v897_6, p1, v895_7_tail);
          v896_8 = compose(v896_5,v897_7);
        }
        const Space v896_9 = intersect(constant_2,v896_2);
        const Space v896_10 = (has_head(v896_9) ? constant_3 : Space{});
        Space v896_12;
        if (!v896_10.empty()) {
          const Path v898_6 = concat_path(v895_6,v895_7_head);
          const Space v898_11 = routine_137(c, v898_6, p1, v895_7_tail);
          v896_12 = compose(v896_10,v898_11);
        }
        const Space v896_13 = unite(v896_8,v896_12);
        v895_7_result = unite(v895_7_result,v896_13);
      }
      const Space v895_7 = std::move(v895_7_result);
      v894_8 = compose(v894_5,v895_7);
    }
    const Space v894_9 = intersect(constant_2,v894_2);
    const Space v894_10 = (has_head(v894_9) ? constant_3 : Space{});
    Space v894_12;
    if (!v894_10.empty()) {
      const Path v899_6 = concat_path(p0,v893_12_head);
      Space v899_11_result;
      for (int v899_11_label = 1; v899_11_label <= 2; ++v899_11_label) {
        const Space v899_11_tail = child(v893_12_tail,v899_11_label);
        if (v899_11_tail.empty()) continue;
        const Path v899_11_head{v899_11_label};
        const Space v900_2 = singleton(v899_11_head);
        const Space v900_3 = intersect(constant_2,v900_2);
        const Space v900_4 = (has_head(v900_3) ? constant_3 : Space{});
        const Space v900_5 = subtract(constant_1,v900_4);
        Space v900_8;
        if (!v900_5.empty()) {
          const Path v901_6 = concat_path(v899_6,v899_11_head);
          const Space v901_7 = routine_136(c, v901_6, p1, v899_11_tail);
          v900_8 = compose(v900_5,v901_7);
        }
        const Space v900_9 = intersect(constant_2,v900_2);
        const Space v900_10 = (has_head(v900_9) ? constant_3 : Space{});
        Space v900_12;
        if (!v900_10.empty()) {
          const Path v902_6 = concat_path(v899_6,v899_11_head);
          const Space v902_11 = routine_50(c, v902_6, p1, v899_11_tail);
          v900_12 = compose(v900_10,v902_11);
        }
        const Space v900_13 = unite(v900_8,v900_12);
        v899_11_result = unite(v899_11_result,v900_13);
      }
      const Space v899_11 = std::move(v899_11_result);
      v894_12 = compose(v894_10,v899_11);
    }
    const Space v894_13 = unite(v894_8,v894_12);
    v893_12_result = unite(v893_12_result,v894_13);
  }
  const Space v893_12 = std::move(v893_12_result);
  return v893_12;
}

static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v903_9_result;
  for (int v903_9_label = 1; v903_9_label <= 2; ++v903_9_label) {
    const Space v903_9_tail = child(s0,v903_9_label);
    if (v903_9_tail.empty()) continue;
    const Path v903_9_head{v903_9_label};
    const Space v904_2 = singleton(v903_9_head);
    const Space v904_3 = intersect(constant_2,v904_2);
    const Space v904_4 = (has_head(v904_3) ? constant_3 : Space{});
    const Space v904_5 = subtract(constant_1,v904_4);
    Space v904_8;
    if (!v904_5.empty()) {
      const Path v905_6 = concat_path(p0,v903_9_head);
      Space v905_7_result;
      for (int v905_7_label = 1; v905_7_label <= 2; ++v905_7_label) {
        const Space v905_7_tail = child(v903_9_tail,v905_7_label);
        if (v905_7_tail.empty()) continue;
        const Path v905_7_head{v905_7_label};
        const Space v906_2 = singleton(v905_7_head);
        const Space v906_3 = intersect(constant_2,v906_2);
        const Space v906_4 = (has_head(v906_3) ? constant_3 : Space{});
        const Space v906_5 = subtract(constant_1,v906_4);
        Space v906_8;
        if (!v906_5.empty()) {
          const Path v907_6 = concat_path(v905_6,v905_7_head);
          const Space v907_7 = routine_136(c, v907_6, p1, v905_7_tail);
          v906_8 = compose(v906_5,v907_7);
        }
        const Space v906_9 = intersect(constant_2,v906_2);
        const Space v906_10 = (has_head(v906_9) ? constant_3 : Space{});
        Space v906_12;
        if (!v906_10.empty()) {
          const Path v908_6 = concat_path(v905_6,v905_7_head);
          const Space v908_11 = routine_137(c, v908_6, p1, v905_7_tail);
          v906_12 = compose(v906_10,v908_11);
        }
        const Space v906_13 = unite(v906_8,v906_12);
        v905_7_result = unite(v905_7_result,v906_13);
      }
      const Space v905_7 = std::move(v905_7_result);
      v904_8 = compose(v904_5,v905_7);
    }
    const Space v904_9 = intersect(constant_2,v904_2);
    const Space v904_10 = (has_head(v904_9) ? constant_3 : Space{});
    const Space v904_11 = compose(v904_10,v903_9_tail);
    const Path v909_6 = concat_path(p0,v903_9_head);
    const Space v904_12 = wrap(v904_11,v909_6);
    const Space v904_13 = wrap(v904_12,p1);
    const Space v904_14 = unite(v904_8,v904_13);
    v903_9_result = unite(v903_9_result,v904_14);
  }
  const Space v903_9 = std::move(v903_9_result);
  return v903_9;
}

static Space routine_96(Context& c, const Path& p0, const Space& s0) {
  Space v910_6_result;
  for (int v910_6_label = 1; v910_6_label <= 2; ++v910_6_label) {
    const Space v910_6_tail = child(s0,v910_6_label);
    if (v910_6_tail.empty()) continue;
    const Path v910_6_head{v910_6_label};
    const Space v911_2 = singleton(v910_6_head);
    const Space v911_3 = intersect(constant_2,v911_2);
    const Space v911_4 = (has_head(v911_3) ? constant_3 : Space{});
    const Space v911_5 = subtract(constant_1,v911_4);
    Space v911_6_result;
    for (int v911_6_label = 1; v911_6_label <= 2; ++v911_6_label) {
      const Space v911_6_tail = child(v910_6_tail,v911_6_label);
      if (v911_6_tail.empty()) continue;
      const Path v911_6_head{v911_6_label};
      const Space v912_2 = Space{};
      v911_6_result = unite(v911_6_result,v912_2);
    }
    const Space v911_6 = std::move(v911_6_result);
    const Space v911_7 = compose(v911_5,v911_6);
    const Space v911_8 = intersect(constant_2,v911_2);
    const Space v911_9 = (has_head(v911_8) ? constant_3 : Space{});
    Space v911_12;
    if (!v911_9.empty()) {
      const Path v913_10 = concat_path(p0,v910_6_head);
      Space v913_11_result;
      for (int v913_11_label = 1; v913_11_label <= 2; ++v913_11_label) {
        const Space v913_11_tail = child(v910_6_tail,v913_11_label);
        if (v913_11_tail.empty()) continue;
        const Path v913_11_head{v913_11_label};
        const Space v914_2 = singleton(v913_11_head);
        const Space v914_3 = intersect(constant_2,v914_2);
        const Space v914_4 = (has_head(v914_3) ? constant_3 : Space{});
        Space v914_7;
        if (!v914_4.empty()) {
          const Path v915_5 = concat_path(v913_10,v913_11_head);
          const Space v915_6 = routine_3(c, v915_5, v913_11_tail);
          v914_7 = compose(v914_4,v915_6);
        }
        v913_11_result = unite(v913_11_result,v914_7);
      }
      const Space v913_11 = std::move(v913_11_result);
      v911_12 = compose(v911_9,v913_11);
    }
    const Space v911_13 = unite(v911_7,v911_12);
    v910_6_result = unite(v910_6_result,v911_13);
  }
  const Space v910_6 = std::move(v910_6_result);
  return v910_6;
}

static Space routine_97(Context& c, const Path& p0, const Space& s0) {
  Space v916_8_result;
  for (int v916_8_label = 1; v916_8_label <= 2; ++v916_8_label) {
    const Space v916_8_tail = child(s0,v916_8_label);
    if (v916_8_tail.empty()) continue;
    const Path v916_8_head{v916_8_label};
    const Space v917_2 = singleton(v916_8_head);
    const Space v917_3 = intersect(constant_2,v917_2);
    const Space v917_4 = (has_head(v917_3) ? constant_3 : Space{});
    const Space v917_5 = subtract(constant_1,v917_4);
    Space v917_6_result;
    for (int v917_6_label = 1; v917_6_label <= 2; ++v917_6_label) {
      const Space v917_6_tail = child(v916_8_tail,v917_6_label);
      if (v917_6_tail.empty()) continue;
      const Path v917_6_head{v917_6_label};
      const Space v918_2 = Space{};
      v917_6_result = unite(v917_6_result,v918_2);
    }
    const Space v917_6 = std::move(v917_6_result);
    const Space v917_7 = compose(v917_5,v917_6);
    const Space v917_8 = intersect(constant_2,v917_2);
    const Space v917_9 = (has_head(v917_8) ? constant_3 : Space{});
    Space v917_12;
    if (!v917_9.empty()) {
      const Path v919_10 = concat_path(p0,v916_8_head);
      Space v919_11_result;
      for (int v919_11_label = 1; v919_11_label <= 2; ++v919_11_label) {
        const Space v919_11_tail = child(v916_8_tail,v919_11_label);
        if (v919_11_tail.empty()) continue;
        const Path v919_11_head{v919_11_label};
        const Space v920_2 = singleton(v919_11_head);
        const Space v920_3 = intersect(constant_2,v920_2);
        const Space v920_4 = (has_head(v920_3) ? constant_3 : Space{});
        const Space v920_5 = subtract(constant_1,v920_4);
        Space v920_7;
        if (!v920_5.empty()) {
          const Space v921_6 = routine_18(c, v919_11_head, v919_10, v919_11_tail);
          v920_7 = compose(v920_5,v921_6);
        }
        const Space v920_8 = intersect(constant_2,v920_2);
        const Space v920_9 = (has_head(v920_8) ? constant_3 : Space{});
        Space v920_11;
        if (!v920_9.empty()) {
          const Space v922_10 = routine_19(c, v919_11_head, v919_10, v919_11_tail);
          v920_11 = compose(v920_9,v922_10);
        }
        const Space v920_12 = unite(v920_7,v920_11);
        v919_11_result = unite(v919_11_result,v920_12);
      }
      const Space v919_11 = std::move(v919_11_result);
      v917_12 = compose(v917_9,v919_11);
    }
    const Space v917_13 = unite(v917_7,v917_12);
    v916_8_result = unite(v916_8_result,v917_13);
  }
  const Space v916_8 = std::move(v916_8_result);
  return v916_8;
}

static Space routine_98(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v923_12_result;
  for (int v923_12_label = 1; v923_12_label <= 2; ++v923_12_label) {
    const Space v923_12_tail = child(s0,v923_12_label);
    if (v923_12_tail.empty()) continue;
    const Path v923_12_head{v923_12_label};
    const Space v924_2 = singleton(v923_12_head);
    const Space v924_3 = intersect(constant_2,v924_2);
    const Space v924_4 = (has_head(v924_3) ? constant_3 : Space{});
    const Space v924_5 = subtract(constant_1,v924_4);
    Space v924_8;
    if (!v924_5.empty()) {
      const Path v925_6 = concat_path(p0,v923_12_head);
      Space v925_7_result;
      for (int v925_7_label = 1; v925_7_label <= 2; ++v925_7_label) {
        const Space v925_7_tail = child(v923_12_tail,v925_7_label);
        if (v925_7_tail.empty()) continue;
        const Path v925_7_head{v925_7_label};
        const Space v926_2 = singleton(v925_7_head);
        const Space v926_3 = intersect(constant_2,v926_2);
        const Space v926_4 = (has_head(v926_3) ? constant_3 : Space{});
        const Space v926_5 = subtract(constant_1,v926_4);
        Space v926_8;
        if (!v926_5.empty()) {
          const Path v927_6 = concat_path(v925_6,v925_7_head);
          const Space v927_7 = routine_138(c, v927_6, p1, v925_7_tail);
          v926_8 = compose(v926_5,v927_7);
        }
        const Space v926_9 = intersect(constant_2,v926_2);
        const Space v926_10 = (has_head(v926_9) ? constant_3 : Space{});
        Space v926_12;
        if (!v926_10.empty()) {
          const Path v928_6 = concat_path(v925_6,v925_7_head);
          const Space v928_11 = routine_139(c, v928_6, p1, v925_7_tail);
          v926_12 = compose(v926_10,v928_11);
        }
        const Space v926_13 = unite(v926_8,v926_12);
        v925_7_result = unite(v925_7_result,v926_13);
      }
      const Space v925_7 = std::move(v925_7_result);
      v924_8 = compose(v924_5,v925_7);
    }
    const Space v924_9 = intersect(constant_2,v924_2);
    const Space v924_10 = (has_head(v924_9) ? constant_3 : Space{});
    Space v924_12;
    if (!v924_10.empty()) {
      const Path v929_6 = concat_path(p0,v923_12_head);
      Space v929_11_result;
      for (int v929_11_label = 1; v929_11_label <= 2; ++v929_11_label) {
        const Space v929_11_tail = child(v923_12_tail,v929_11_label);
        if (v929_11_tail.empty()) continue;
        const Path v929_11_head{v929_11_label};
        const Space v930_2 = singleton(v929_11_head);
        const Space v930_3 = intersect(constant_2,v930_2);
        const Space v930_4 = (has_head(v930_3) ? constant_3 : Space{});
        const Space v930_5 = subtract(constant_1,v930_4);
        Space v930_8;
        if (!v930_5.empty()) {
          const Path v931_6 = concat_path(v929_6,v929_11_head);
          const Space v931_7 = routine_138(c, v931_6, p1, v929_11_tail);
          v930_8 = compose(v930_5,v931_7);
        }
        const Space v930_9 = intersect(constant_2,v930_2);
        const Space v930_10 = (has_head(v930_9) ? constant_3 : Space{});
        Space v930_12;
        if (!v930_10.empty()) {
          const Path v932_6 = concat_path(v929_6,v929_11_head);
          const Space v932_11 = routine_22(c, v932_6, p1, v929_11_tail);
          v930_12 = compose(v930_10,v932_11);
        }
        const Space v930_13 = unite(v930_8,v930_12);
        v929_11_result = unite(v929_11_result,v930_13);
      }
      const Space v929_11 = std::move(v929_11_result);
      v924_12 = compose(v924_10,v929_11);
    }
    const Space v924_13 = unite(v924_8,v924_12);
    v923_12_result = unite(v923_12_result,v924_13);
  }
  const Space v923_12 = std::move(v923_12_result);
  return v923_12;
}

static Space routine_99(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v933_10_result;
  for (int v933_10_label = 1; v933_10_label <= 2; ++v933_10_label) {
    const Space v933_10_tail = child(s0,v933_10_label);
    if (v933_10_tail.empty()) continue;
    const Path v933_10_head{v933_10_label};
    const Space v934_2 = singleton(v933_10_head);
    const Space v934_3 = intersect(constant_2,v934_2);
    const Space v934_4 = (has_head(v934_3) ? constant_3 : Space{});
    const Space v934_5 = compose(v934_4,v933_10_tail);
    const Path v935_6 = concat_path(p0,v933_10_head);
    const Space v934_7 = wrap(v934_5,v935_6);
    const Space v934_8 = wrap(v934_7,p1);
    const Space v934_9 = wrap(v934_8,constant_6);
    const Space v934_10 = intersect(constant_2,v934_2);
    const Space v934_11 = (has_head(v934_10) ? constant_3 : Space{});
    const Space v934_12 = subtract(constant_1,v934_11);
    Space v934_14;
    if (!v934_12.empty()) {
      Space v936_13_result;
      for (int v936_13_label = 1; v936_13_label <= 2; ++v936_13_label) {
        const Space v936_13_tail = child(v933_10_tail,v936_13_label);
        if (v936_13_tail.empty()) continue;
        const Path v936_13_head{v936_13_label};
        const Space v937_2 = singleton(v936_13_head);
        const Space v937_3 = intersect(constant_2,v937_2);
        const Space v937_4 = (has_head(v937_3) ? constant_3 : Space{});
        const Space v937_5 = subtract(constant_1,v937_4);
        Space v937_8;
        if (!v937_5.empty()) {
          const Path v938_6 = concat_path(v935_6,v936_13_head);
          const Space v938_7 = routine_138(c, v938_6, p1, v936_13_tail);
          v937_8 = compose(v937_5,v938_7);
        }
        const Space v937_9 = intersect(constant_2,v937_2);
        const Space v937_10 = (has_head(v937_9) ? constant_3 : Space{});
        Space v937_12;
        if (!v937_10.empty()) {
          const Path v939_6 = concat_path(v935_6,v936_13_head);
          const Space v939_11 = routine_139(c, v939_6, p1, v936_13_tail);
          v937_12 = compose(v937_10,v939_11);
        }
        const Space v937_13 = unite(v937_8,v937_12);
        v936_13_result = unite(v936_13_result,v937_13);
      }
      const Space v936_13 = std::move(v936_13_result);
      v934_14 = compose(v934_12,v936_13);
    }
    const Space v934_15 = unite(v934_9,v934_14);
    v933_10_result = unite(v933_10_result,v934_15);
  }
  const Space v933_10 = std::move(v933_10_result);
  return v933_10;
}

static Space routine_100(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v940_12_result;
  for (int v940_12_label = 1; v940_12_label <= 2; ++v940_12_label) {
    const Space v940_12_tail = child(s0,v940_12_label);
    if (v940_12_tail.empty()) continue;
    const Path v940_12_head{v940_12_label};
    const Space v941_2 = singleton(v940_12_head);
    const Space v941_3 = intersect(constant_2,v941_2);
    const Space v941_4 = (has_head(v941_3) ? constant_3 : Space{});
    const Space v941_5 = subtract(constant_1,v941_4);
    Space v941_8;
    if (!v941_5.empty()) {
      const Path v942_6 = concat_path(p0,v940_12_head);
      Space v942_7_result;
      for (int v942_7_label = 1; v942_7_label <= 2; ++v942_7_label) {
        const Space v942_7_tail = child(v940_12_tail,v942_7_label);
        if (v942_7_tail.empty()) continue;
        const Path v942_7_head{v942_7_label};
        const Space v943_2 = singleton(v942_7_head);
        const Space v943_3 = intersect(constant_2,v943_2);
        const Space v943_4 = (has_head(v943_3) ? constant_3 : Space{});
        const Space v943_5 = subtract(constant_1,v943_4);
        Space v943_8;
        if (!v943_5.empty()) {
          const Path v944_6 = concat_path(v942_6,v942_7_head);
          const Space v944_7 = routine_140(c, v944_6, p1, v942_7_tail);
          v943_8 = compose(v943_5,v944_7);
        }
        const Space v943_9 = intersect(constant_2,v943_2);
        const Space v943_10 = (has_head(v943_9) ? constant_3 : Space{});
        Space v943_12;
        if (!v943_10.empty()) {
          const Path v945_6 = concat_path(v942_6,v942_7_head);
          const Space v945_11 = routine_141(c, v945_6, p1, v942_7_tail);
          v943_12 = compose(v943_10,v945_11);
        }
        const Space v943_13 = unite(v943_8,v943_12);
        v942_7_result = unite(v942_7_result,v943_13);
      }
      const Space v942_7 = std::move(v942_7_result);
      v941_8 = compose(v941_5,v942_7);
    }
    const Space v941_9 = intersect(constant_2,v941_2);
    const Space v941_10 = (has_head(v941_9) ? constant_3 : Space{});
    Space v941_12;
    if (!v941_10.empty()) {
      const Path v946_6 = concat_path(p0,v940_12_head);
      Space v946_11_result;
      for (int v946_11_label = 1; v946_11_label <= 2; ++v946_11_label) {
        const Space v946_11_tail = child(v940_12_tail,v946_11_label);
        if (v946_11_tail.empty()) continue;
        const Path v946_11_head{v946_11_label};
        const Space v947_2 = singleton(v946_11_head);
        const Space v947_3 = intersect(constant_2,v947_2);
        const Space v947_4 = (has_head(v947_3) ? constant_3 : Space{});
        const Space v947_5 = subtract(constant_1,v947_4);
        Space v947_8;
        if (!v947_5.empty()) {
          const Path v948_6 = concat_path(v946_6,v946_11_head);
          const Space v948_7 = routine_140(c, v948_6, p1, v946_11_tail);
          v947_8 = compose(v947_5,v948_7);
        }
        const Space v947_9 = intersect(constant_2,v947_2);
        const Space v947_10 = (has_head(v947_9) ? constant_3 : Space{});
        Space v947_12;
        if (!v947_10.empty()) {
          const Path v949_6 = concat_path(v946_6,v946_11_head);
          const Space v949_11 = routine_22(c, v949_6, p1, v946_11_tail);
          v947_12 = compose(v947_10,v949_11);
        }
        const Space v947_13 = unite(v947_8,v947_12);
        v946_11_result = unite(v946_11_result,v947_13);
      }
      const Space v946_11 = std::move(v946_11_result);
      v941_12 = compose(v941_10,v946_11);
    }
    const Space v941_13 = unite(v941_8,v941_12);
    v940_12_result = unite(v940_12_result,v941_13);
  }
  const Space v940_12 = std::move(v940_12_result);
  return v940_12;
}

static Space routine_101(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v950_10_result;
  for (int v950_10_label = 1; v950_10_label <= 2; ++v950_10_label) {
    const Space v950_10_tail = child(s0,v950_10_label);
    if (v950_10_tail.empty()) continue;
    const Path v950_10_head{v950_10_label};
    const Space v951_2 = singleton(v950_10_head);
    const Space v951_3 = intersect(constant_2,v951_2);
    const Space v951_4 = (has_head(v951_3) ? constant_3 : Space{});
    const Space v951_5 = compose(v951_4,v950_10_tail);
    const Path v952_6 = concat_path(p0,v950_10_head);
    const Space v951_7 = wrap(v951_5,v952_6);
    const Space v951_8 = wrap(v951_7,p1);
    const Space v951_9 = wrap(v951_8,constant_6);
    const Space v951_10 = intersect(constant_2,v951_2);
    const Space v951_11 = (has_head(v951_10) ? constant_3 : Space{});
    const Space v951_12 = subtract(constant_1,v951_11);
    Space v951_14;
    if (!v951_12.empty()) {
      Space v953_13_result;
      for (int v953_13_label = 1; v953_13_label <= 2; ++v953_13_label) {
        const Space v953_13_tail = child(v950_10_tail,v953_13_label);
        if (v953_13_tail.empty()) continue;
        const Path v953_13_head{v953_13_label};
        const Space v954_2 = singleton(v953_13_head);
        const Space v954_3 = intersect(constant_2,v954_2);
        const Space v954_4 = (has_head(v954_3) ? constant_3 : Space{});
        const Space v954_5 = subtract(constant_1,v954_4);
        Space v954_8;
        if (!v954_5.empty()) {
          const Path v955_6 = concat_path(v952_6,v953_13_head);
          const Space v955_7 = routine_140(c, v955_6, p1, v953_13_tail);
          v954_8 = compose(v954_5,v955_7);
        }
        const Space v954_9 = intersect(constant_2,v954_2);
        const Space v954_10 = (has_head(v954_9) ? constant_3 : Space{});
        Space v954_12;
        if (!v954_10.empty()) {
          const Path v956_6 = concat_path(v952_6,v953_13_head);
          const Space v956_11 = routine_141(c, v956_6, p1, v953_13_tail);
          v954_12 = compose(v954_10,v956_11);
        }
        const Space v954_13 = unite(v954_8,v954_12);
        v953_13_result = unite(v953_13_result,v954_13);
      }
      const Space v953_13 = std::move(v953_13_result);
      v951_14 = compose(v951_12,v953_13);
    }
    const Space v951_15 = unite(v951_9,v951_14);
    v950_10_result = unite(v950_10_result,v951_15);
  }
  const Space v950_10 = std::move(v950_10_result);
  return v950_10;
}

static Space routine_102(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v957_7_result;
  for (int v957_7_label = 1; v957_7_label <= 2; ++v957_7_label) {
    const Space v957_7_tail = child(s0,v957_7_label);
    if (v957_7_tail.empty()) continue;
    const Path v957_7_head{v957_7_label};
    const Space v958_2 = singleton(v957_7_head);
    const Space v958_3 = intersect(constant_2,v958_2);
    const Space v958_4 = (has_head(v958_3) ? constant_3 : Space{});
    const Space v958_5 = subtract(constant_1,v958_4);
    Space v958_6_result;
    for (int v958_6_label = 1; v958_6_label <= 2; ++v958_6_label) {
      const Space v958_6_tail = child(v957_7_tail,v958_6_label);
      if (v958_6_tail.empty()) continue;
      const Path v958_6_head{v958_6_label};
      const Space v959_2 = Space{};
      v958_6_result = unite(v958_6_result,v959_2);
    }
    const Space v958_6 = std::move(v958_6_result);
    const Space v958_7 = compose(v958_5,v958_6);
    const Space v958_8 = intersect(constant_2,v958_2);
    const Space v958_9 = (has_head(v958_8) ? constant_3 : Space{});
    Space v958_12;
    if (!v958_9.empty()) {
      const Path v960_10 = concat_path(p0,v957_7_head);
      Space v960_11_result;
      for (int v960_11_label = 1; v960_11_label <= 2; ++v960_11_label) {
        const Space v960_11_tail = child(v957_7_tail,v960_11_label);
        if (v960_11_tail.empty()) continue;
        const Path v960_11_head{v960_11_label};
        const Space v961_2 = singleton(v960_11_head);
        const Space v961_3 = intersect(constant_2,v961_2);
        const Space v961_4 = (has_head(v961_3) ? constant_3 : Space{});
        Space v961_7;
        if (!v961_4.empty()) {
          const Path v962_5 = concat_path(v960_10,v960_11_head);
          const Space v962_6 = routine_6(c, v962_5, v960_11_tail, s1);
          v961_7 = compose(v961_4,v962_6);
        }
        v960_11_result = unite(v960_11_result,v961_7);
      }
      const Space v960_11 = std::move(v960_11_result);
      v958_12 = compose(v958_9,v960_11);
    }
    const Space v958_13 = unite(v958_7,v958_12);
    v957_7_result = unite(v957_7_result,v958_13);
  }
  const Space v957_7 = std::move(v957_7_result);
  return v957_7;
}

static Space routine_103(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v963_9_result;
  for (int v963_9_label = 1; v963_9_label <= 2; ++v963_9_label) {
    const Space v963_9_tail = child(s0,v963_9_label);
    if (v963_9_tail.empty()) continue;
    const Path v963_9_head{v963_9_label};
    const Space v964_2 = singleton(v963_9_head);
    const Space v964_3 = intersect(constant_2,v964_2);
    const Space v964_4 = (has_head(v964_3) ? constant_3 : Space{});
    const Space v964_5 = subtract(constant_1,v964_4);
    Space v964_6_result;
    for (int v964_6_label = 1; v964_6_label <= 2; ++v964_6_label) {
      const Space v964_6_tail = child(v963_9_tail,v964_6_label);
      if (v964_6_tail.empty()) continue;
      const Path v964_6_head{v964_6_label};
      const Space v965_2 = Space{};
      v964_6_result = unite(v964_6_result,v965_2);
    }
    const Space v964_6 = std::move(v964_6_result);
    const Space v964_7 = compose(v964_5,v964_6);
    const Space v964_8 = intersect(constant_2,v964_2);
    const Space v964_9 = (has_head(v964_8) ? constant_3 : Space{});
    Space v964_12;
    if (!v964_9.empty()) {
      const Path v966_10 = concat_path(p0,v963_9_head);
      Space v966_11_result;
      for (int v966_11_label = 1; v966_11_label <= 2; ++v966_11_label) {
        const Space v966_11_tail = child(v963_9_tail,v966_11_label);
        if (v966_11_tail.empty()) continue;
        const Path v966_11_head{v966_11_label};
        const Space v967_2 = singleton(v966_11_head);
        const Space v967_3 = intersect(constant_2,v967_2);
        const Space v967_4 = (has_head(v967_3) ? constant_3 : Space{});
        const Space v967_5 = subtract(constant_1,v967_4);
        Space v967_7;
        if (!v967_5.empty()) {
          const Space v968_6 = routine_25(c, v966_11_head, v966_10, v966_11_tail, s1);
          v967_7 = compose(v967_5,v968_6);
        }
        const Space v967_8 = intersect(constant_2,v967_2);
        const Space v967_9 = (has_head(v967_8) ? constant_3 : Space{});
        Space v967_11;
        if (!v967_9.empty()) {
          const Space v969_10 = routine_26(c, v966_11_head, v966_10, v966_11_tail, s1);
          v967_11 = compose(v967_9,v969_10);
        }
        const Space v967_12 = unite(v967_7,v967_11);
        v966_11_result = unite(v966_11_result,v967_12);
      }
      const Space v966_11 = std::move(v966_11_result);
      v964_12 = compose(v964_9,v966_11);
    }
    const Space v964_13 = unite(v964_7,v964_12);
    v963_9_result = unite(v963_9_result,v964_13);
  }
  const Space v963_9 = std::move(v963_9_result);
  return v963_9;
}

static Space routine_104(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v970_13_result;
  for (int v970_13_label = 1; v970_13_label <= 2; ++v970_13_label) {
    const Space v970_13_tail = child(s0,v970_13_label);
    if (v970_13_tail.empty()) continue;
    const Path v970_13_head{v970_13_label};
    const Space v971_2 = singleton(v970_13_head);
    const Space v971_3 = intersect(constant_2,v971_2);
    const Space v971_4 = (has_head(v971_3) ? constant_3 : Space{});
    const Space v971_5 = subtract(constant_1,v971_4);
    Space v971_8;
    if (!v971_5.empty()) {
      const Path v972_6 = concat_path(p0,v970_13_head);
      Space v972_7_result;
      for (int v972_7_label = 1; v972_7_label <= 2; ++v972_7_label) {
        const Space v972_7_tail = child(v970_13_tail,v972_7_label);
        if (v972_7_tail.empty()) continue;
        const Path v972_7_head{v972_7_label};
        const Space v973_2 = singleton(v972_7_head);
        const Space v973_3 = intersect(constant_2,v973_2);
        const Space v973_4 = (has_head(v973_3) ? constant_3 : Space{});
        const Space v973_5 = subtract(constant_1,v973_4);
        Space v973_8;
        if (!v973_5.empty()) {
          const Path v974_6 = concat_path(v972_6,v972_7_head);
          const Space v974_7 = routine_142(c, v974_6, p1, v972_7_tail, s1);
          v973_8 = compose(v973_5,v974_7);
        }
        const Space v973_9 = intersect(constant_2,v973_2);
        const Space v973_10 = (has_head(v973_9) ? constant_3 : Space{});
        Space v973_12;
        if (!v973_10.empty()) {
          const Path v975_6 = concat_path(v972_6,v972_7_head);
          const Space v975_11 = routine_143(c, v975_6, p1, v972_7_tail, s1);
          v973_12 = compose(v973_10,v975_11);
        }
        const Space v973_13 = unite(v973_8,v973_12);
        v972_7_result = unite(v972_7_result,v973_13);
      }
      const Space v972_7 = std::move(v972_7_result);
      v971_8 = compose(v971_5,v972_7);
    }
    const Space v971_9 = intersect(constant_2,v971_2);
    const Space v971_10 = (has_head(v971_9) ? constant_3 : Space{});
    Space v971_12;
    if (!v971_10.empty()) {
      const Path v976_6 = concat_path(p0,v970_13_head);
      Space v976_11_result;
      for (int v976_11_label = 1; v976_11_label <= 2; ++v976_11_label) {
        const Space v976_11_tail = child(v970_13_tail,v976_11_label);
        if (v976_11_tail.empty()) continue;
        const Path v976_11_head{v976_11_label};
        const Space v977_2 = singleton(v976_11_head);
        const Space v977_3 = intersect(constant_2,v977_2);
        const Space v977_4 = (has_head(v977_3) ? constant_3 : Space{});
        const Space v977_5 = subtract(constant_1,v977_4);
        Space v977_8;
        if (!v977_5.empty()) {
          const Path v978_6 = concat_path(v976_6,v976_11_head);
          const Space v978_7 = routine_142(c, v978_6, p1, v976_11_tail, s1);
          v977_8 = compose(v977_5,v978_7);
        }
        const Space v977_9 = intersect(constant_2,v977_2);
        const Space v977_10 = (has_head(v977_9) ? constant_3 : Space{});
        Space v977_12;
        if (!v977_10.empty()) {
          const Path v979_6 = concat_path(v976_6,v976_11_head);
          const Space v979_11 = routine_29(c, v979_6, p1, v976_11_tail, s1);
          v977_12 = compose(v977_10,v979_11);
        }
        const Space v977_13 = unite(v977_8,v977_12);
        v976_11_result = unite(v976_11_result,v977_13);
      }
      const Space v976_11 = std::move(v976_11_result);
      v971_12 = compose(v971_10,v976_11);
    }
    const Space v971_13 = unite(v971_8,v971_12);
    v970_13_result = unite(v970_13_result,v971_13);
  }
  const Space v970_13 = std::move(v970_13_result);
  return v970_13;
}

static Space routine_105(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v980_8 = unwrap(s1,constant_5);
  const Space v980_10 = unwrap(v980_8,constant_6);
  const Space v980_11 = unwrap(v980_10,p0);
  Space v980_18_result;
  for (int v980_18_label = 1; v980_18_label <= 2; ++v980_18_label) {
    const Space v980_18_tail = child(s0,v980_18_label);
    if (v980_18_tail.empty()) continue;
    const Path v980_18_head{v980_18_label};
    const Space v981_2 = singleton(v980_18_head);
    const Space v981_3 = intersect(constant_2,v981_2);
    const Space v981_4 = (has_head(v981_3) ? constant_3 : Space{});
    const Space v981_5 = subtract(constant_1,v981_4);
    Space v981_8;
    if (!v981_5.empty()) {
      const Path v982_6 = concat_path(p0,v980_18_head);
      Space v982_7_result;
      for (int v982_7_label = 1; v982_7_label <= 2; ++v982_7_label) {
        const Space v982_7_tail = child(v980_18_tail,v982_7_label);
        if (v982_7_tail.empty()) continue;
        const Path v982_7_head{v982_7_label};
        const Space v983_2 = singleton(v982_7_head);
        const Space v983_3 = intersect(constant_2,v983_2);
        const Space v983_4 = (has_head(v983_3) ? constant_3 : Space{});
        const Space v983_5 = subtract(constant_1,v983_4);
        Space v983_8;
        if (!v983_5.empty()) {
          const Path v984_6 = concat_path(v982_6,v982_7_head);
          const Space v984_7 = routine_142(c, v984_6, p1, v982_7_tail, s1);
          v983_8 = compose(v983_5,v984_7);
        }
        const Space v983_9 = intersect(constant_2,v983_2);
        const Space v983_10 = (has_head(v983_9) ? constant_3 : Space{});
        Space v983_12;
        if (!v983_10.empty()) {
          const Path v985_6 = concat_path(v982_6,v982_7_head);
          const Space v985_11 = routine_143(c, v985_6, p1, v982_7_tail, s1);
          v983_12 = compose(v983_10,v985_11);
        }
        const Space v983_13 = unite(v983_8,v983_12);
        v982_7_result = unite(v982_7_result,v983_13);
      }
      const Space v982_7 = std::move(v982_7_result);
      v981_8 = compose(v981_5,v982_7);
    }
    const Space v981_9 = intersect(constant_2,v981_2);
    const Space v981_10 = (has_head(v981_9) ? constant_3 : Space{});
    Space v981_13;
    if (!v981_10.empty()) {
      const Space v986_11 = unwrap(v980_11,v980_18_head);
      Space v986_12_result;
      for (int v986_12_label = 1; v986_12_label <= 2; ++v986_12_label) {
        const Space v986_12_tail = child(v986_11,v986_12_label);
        if (v986_12_tail.empty()) continue;
        const Path v986_12_head{v986_12_label};
        const Space v987_2 = singleton(v986_12_head);
        const Space v987_3 = intersect(constant_2,v987_2);
        const Space v987_4 = (has_head(v987_3) ? constant_3 : Space{});
        const Space v987_5 = subtract(constant_1,v987_4);
        Space v987_7;
        if (!v987_5.empty()) {
          const Space v988_6 = routine_61(c, v986_12_head, p1, v986_12_tail);
          v987_7 = compose(v987_5,v988_6);
        }
        const Space v987_8 = intersect(constant_2,v987_2);
        const Space v987_9 = (has_head(v987_8) ? constant_3 : Space{});
        Space v987_11;
        if (!v987_9.empty()) {
          const Space v989_10 = routine_62(c, v986_12_head, p1, v986_12_tail);
          v987_11 = compose(v987_9,v989_10);
        }
        const Space v987_12 = unite(v987_7,v987_11);
        v986_12_result = unite(v986_12_result,v987_12);
      }
      const Space v986_12 = std::move(v986_12_result);
      v981_13 = compose(v981_10,v986_12);
    }
    const Space v981_14 = unite(v981_8,v981_13);
    v980_18_result = unite(v980_18_result,v981_14);
  }
  const Space v980_18 = std::move(v980_18_result);
  return v980_18;
}

static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v990_12_result;
  for (int v990_12_label = 1; v990_12_label <= 2; ++v990_12_label) {
    const Space v990_12_tail = child(s0,v990_12_label);
    if (v990_12_tail.empty()) continue;
    const Path v990_12_head{v990_12_label};
    const Space v991_2 = singleton(v990_12_head);
    const Space v991_3 = intersect(constant_2,v991_2);
    const Space v991_4 = (has_head(v991_3) ? constant_3 : Space{});
    const Space v991_5 = subtract(constant_1,v991_4);
    Space v991_8;
    if (!v991_5.empty()) {
      const Path v992_6 = concat_path(p0,v990_12_head);
      Space v992_7_result;
      for (int v992_7_label = 1; v992_7_label <= 2; ++v992_7_label) {
        const Space v992_7_tail = child(v990_12_tail,v992_7_label);
        if (v992_7_tail.empty()) continue;
        const Path v992_7_head{v992_7_label};
        const Space v993_2 = singleton(v992_7_head);
        const Space v993_3 = intersect(constant_2,v993_2);
        const Space v993_4 = (has_head(v993_3) ? constant_3 : Space{});
        const Space v993_5 = subtract(constant_1,v993_4);
        Space v993_8;
        if (!v993_5.empty()) {
          const Path v994_6 = concat_path(v992_6,v992_7_head);
          const Space v994_7 = routine_144(c, v994_6, p1, v992_7_tail);
          v993_8 = compose(v993_5,v994_7);
        }
        const Space v993_9 = intersect(constant_2,v993_2);
        const Space v993_10 = (has_head(v993_9) ? constant_3 : Space{});
        Space v993_12;
        if (!v993_10.empty()) {
          const Path v995_6 = concat_path(v992_6,v992_7_head);
          const Space v995_11 = routine_145(c, v995_6, p1, v992_7_tail);
          v993_12 = compose(v993_10,v995_11);
        }
        const Space v993_13 = unite(v993_8,v993_12);
        v992_7_result = unite(v992_7_result,v993_13);
      }
      const Space v992_7 = std::move(v992_7_result);
      v991_8 = compose(v991_5,v992_7);
    }
    const Space v991_9 = intersect(constant_2,v991_2);
    const Space v991_10 = (has_head(v991_9) ? constant_3 : Space{});
    Space v991_12;
    if (!v991_10.empty()) {
      const Path v996_6 = concat_path(p0,v990_12_head);
      Space v996_11_result;
      for (int v996_11_label = 1; v996_11_label <= 2; ++v996_11_label) {
        const Space v996_11_tail = child(v990_12_tail,v996_11_label);
        if (v996_11_tail.empty()) continue;
        const Path v996_11_head{v996_11_label};
        const Space v997_2 = singleton(v996_11_head);
        const Space v997_3 = intersect(constant_2,v997_2);
        const Space v997_4 = (has_head(v997_3) ? constant_3 : Space{});
        const Space v997_5 = subtract(constant_1,v997_4);
        Space v997_8;
        if (!v997_5.empty()) {
          const Path v998_6 = concat_path(v996_6,v996_11_head);
          const Space v998_7 = routine_144(c, v998_6, p1, v996_11_tail);
          v997_8 = compose(v997_5,v998_7);
        }
        const Space v997_9 = intersect(constant_2,v997_2);
        const Space v997_10 = (has_head(v997_9) ? constant_3 : Space{});
        Space v997_12;
        if (!v997_10.empty()) {
          const Path v999_6 = concat_path(v996_6,v996_11_head);
          const Space v999_11 = routine_67(c, v999_6, p1, v996_11_tail);
          v997_12 = compose(v997_10,v999_11);
        }
        const Space v997_13 = unite(v997_8,v997_12);
        v996_11_result = unite(v996_11_result,v997_13);
      }
      const Space v996_11 = std::move(v996_11_result);
      v991_12 = compose(v991_10,v996_11);
    }
    const Space v991_13 = unite(v991_8,v991_12);
    v990_12_result = unite(v990_12_result,v991_13);
  }
  const Space v990_12 = std::move(v990_12_result);
  return v990_12;
}

static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1000_9_result;
  for (int v1000_9_label = 1; v1000_9_label <= 2; ++v1000_9_label) {
    const Space v1000_9_tail = child(s0,v1000_9_label);
    if (v1000_9_tail.empty()) continue;
    const Path v1000_9_head{v1000_9_label};
    const Space v1001_2 = singleton(v1000_9_head);
    const Space v1001_3 = intersect(constant_2,v1001_2);
    const Space v1001_4 = (has_head(v1001_3) ? constant_3 : Space{});
    const Space v1001_5 = subtract(constant_1,v1001_4);
    Space v1001_8;
    if (!v1001_5.empty()) {
      const Path v1002_6 = concat_path(p0,v1000_9_head);
      Space v1002_7_result;
      for (int v1002_7_label = 1; v1002_7_label <= 2; ++v1002_7_label) {
        const Space v1002_7_tail = child(v1000_9_tail,v1002_7_label);
        if (v1002_7_tail.empty()) continue;
        const Path v1002_7_head{v1002_7_label};
        const Space v1003_2 = singleton(v1002_7_head);
        const Space v1003_3 = intersect(constant_2,v1003_2);
        const Space v1003_4 = (has_head(v1003_3) ? constant_3 : Space{});
        const Space v1003_5 = subtract(constant_1,v1003_4);
        Space v1003_8;
        if (!v1003_5.empty()) {
          const Path v1004_6 = concat_path(v1002_6,v1002_7_head);
          const Space v1004_7 = routine_144(c, v1004_6, p1, v1002_7_tail);
          v1003_8 = compose(v1003_5,v1004_7);
        }
        const Space v1003_9 = intersect(constant_2,v1003_2);
        const Space v1003_10 = (has_head(v1003_9) ? constant_3 : Space{});
        Space v1003_12;
        if (!v1003_10.empty()) {
          const Path v1005_6 = concat_path(v1002_6,v1002_7_head);
          const Space v1005_11 = routine_145(c, v1005_6, p1, v1002_7_tail);
          v1003_12 = compose(v1003_10,v1005_11);
        }
        const Space v1003_13 = unite(v1003_8,v1003_12);
        v1002_7_result = unite(v1002_7_result,v1003_13);
      }
      const Space v1002_7 = std::move(v1002_7_result);
      v1001_8 = compose(v1001_5,v1002_7);
    }
    const Space v1001_9 = intersect(constant_2,v1001_2);
    const Space v1001_10 = (has_head(v1001_9) ? constant_3 : Space{});
    const Space v1001_11 = compose(v1001_10,v1000_9_tail);
    const Path v1006_6 = concat_path(p0,v1000_9_head);
    const Space v1001_12 = wrap(v1001_11,v1006_6);
    const Space v1001_13 = wrap(v1001_12,p1);
    const Space v1001_14 = unite(v1001_8,v1001_13);
    v1000_9_result = unite(v1000_9_result,v1001_14);
  }
  const Space v1000_9 = std::move(v1000_9_result);
  return v1000_9;
}

static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1007_13_result;
  for (int v1007_13_label = 1; v1007_13_label <= 2; ++v1007_13_label) {
    const Space v1007_13_tail = child(s0,v1007_13_label);
    if (v1007_13_tail.empty()) continue;
    const Path v1007_13_head{v1007_13_label};
    const Space v1008_2 = singleton(v1007_13_head);
    const Space v1008_3 = intersect(constant_2,v1008_2);
    const Space v1008_4 = (has_head(v1008_3) ? constant_3 : Space{});
    const Space v1008_5 = subtract(constant_1,v1008_4);
    Space v1008_8;
    if (!v1008_5.empty()) {
      const Path v1009_6 = concat_path(p0,v1007_13_head);
      Space v1009_7_result;
      for (int v1009_7_label = 1; v1009_7_label <= 2; ++v1009_7_label) {
        const Space v1009_7_tail = child(v1007_13_tail,v1009_7_label);
        if (v1009_7_tail.empty()) continue;
        const Path v1009_7_head{v1009_7_label};
        const Space v1010_2 = singleton(v1009_7_head);
        const Space v1010_3 = intersect(constant_2,v1010_2);
        const Space v1010_4 = (has_head(v1010_3) ? constant_3 : Space{});
        const Space v1010_5 = subtract(constant_1,v1010_4);
        Space v1010_8;
        if (!v1010_5.empty()) {
          const Path v1011_6 = concat_path(v1009_6,v1009_7_head);
          const Space v1011_7 = routine_146(c, v1011_6, p1, v1009_7_tail, s1);
          v1010_8 = compose(v1010_5,v1011_7);
        }
        const Space v1010_9 = intersect(constant_2,v1010_2);
        const Space v1010_10 = (has_head(v1010_9) ? constant_3 : Space{});
        Space v1010_12;
        if (!v1010_10.empty()) {
          const Path v1012_6 = concat_path(v1009_6,v1009_7_head);
          const Space v1012_11 = routine_147(c, v1012_6, p1, v1009_7_tail, s1);
          v1010_12 = compose(v1010_10,v1012_11);
        }
        const Space v1010_13 = unite(v1010_8,v1010_12);
        v1009_7_result = unite(v1009_7_result,v1010_13);
      }
      const Space v1009_7 = std::move(v1009_7_result);
      v1008_8 = compose(v1008_5,v1009_7);
    }
    const Space v1008_9 = intersect(constant_2,v1008_2);
    const Space v1008_10 = (has_head(v1008_9) ? constant_3 : Space{});
    Space v1008_12;
    if (!v1008_10.empty()) {
      const Path v1013_6 = concat_path(p0,v1007_13_head);
      Space v1013_11_result;
      for (int v1013_11_label = 1; v1013_11_label <= 2; ++v1013_11_label) {
        const Space v1013_11_tail = child(v1007_13_tail,v1013_11_label);
        if (v1013_11_tail.empty()) continue;
        const Path v1013_11_head{v1013_11_label};
        const Space v1014_2 = singleton(v1013_11_head);
        const Space v1014_3 = intersect(constant_2,v1014_2);
        const Space v1014_4 = (has_head(v1014_3) ? constant_3 : Space{});
        const Space v1014_5 = subtract(constant_1,v1014_4);
        Space v1014_8;
        if (!v1014_5.empty()) {
          const Path v1015_6 = concat_path(v1013_6,v1013_11_head);
          const Space v1015_7 = routine_146(c, v1015_6, p1, v1013_11_tail, s1);
          v1014_8 = compose(v1014_5,v1015_7);
        }
        const Space v1014_9 = intersect(constant_2,v1014_2);
        const Space v1014_10 = (has_head(v1014_9) ? constant_3 : Space{});
        Space v1014_12;
        if (!v1014_10.empty()) {
          const Path v1016_6 = concat_path(v1013_6,v1013_11_head);
          const Space v1016_11 = routine_29(c, v1016_6, p1, v1013_11_tail, s1);
          v1014_12 = compose(v1014_10,v1016_11);
        }
        const Space v1014_13 = unite(v1014_8,v1014_12);
        v1013_11_result = unite(v1013_11_result,v1014_13);
      }
      const Space v1013_11 = std::move(v1013_11_result);
      v1008_12 = compose(v1008_10,v1013_11);
    }
    const Space v1008_13 = unite(v1008_8,v1008_12);
    v1007_13_result = unite(v1007_13_result,v1008_13);
  }
  const Space v1007_13 = std::move(v1007_13_result);
  return v1007_13;
}

static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1017_8 = unwrap(s1,constant_5);
  const Space v1017_10 = unwrap(v1017_8,constant_6);
  const Space v1017_11 = unwrap(v1017_10,p0);
  Space v1017_18_result;
  for (int v1017_18_label = 1; v1017_18_label <= 2; ++v1017_18_label) {
    const Space v1017_18_tail = child(s0,v1017_18_label);
    if (v1017_18_tail.empty()) continue;
    const Path v1017_18_head{v1017_18_label};
    const Space v1018_2 = singleton(v1017_18_head);
    const Space v1018_3 = intersect(constant_2,v1018_2);
    const Space v1018_4 = (has_head(v1018_3) ? constant_3 : Space{});
    const Space v1018_5 = subtract(constant_1,v1018_4);
    Space v1018_8;
    if (!v1018_5.empty()) {
      const Path v1019_6 = concat_path(p0,v1017_18_head);
      Space v1019_7_result;
      for (int v1019_7_label = 1; v1019_7_label <= 2; ++v1019_7_label) {
        const Space v1019_7_tail = child(v1017_18_tail,v1019_7_label);
        if (v1019_7_tail.empty()) continue;
        const Path v1019_7_head{v1019_7_label};
        const Space v1020_2 = singleton(v1019_7_head);
        const Space v1020_3 = intersect(constant_2,v1020_2);
        const Space v1020_4 = (has_head(v1020_3) ? constant_3 : Space{});
        const Space v1020_5 = subtract(constant_1,v1020_4);
        Space v1020_8;
        if (!v1020_5.empty()) {
          const Path v1021_6 = concat_path(v1019_6,v1019_7_head);
          const Space v1021_7 = routine_146(c, v1021_6, p1, v1019_7_tail, s1);
          v1020_8 = compose(v1020_5,v1021_7);
        }
        const Space v1020_9 = intersect(constant_2,v1020_2);
        const Space v1020_10 = (has_head(v1020_9) ? constant_3 : Space{});
        Space v1020_12;
        if (!v1020_10.empty()) {
          const Path v1022_6 = concat_path(v1019_6,v1019_7_head);
          const Space v1022_11 = routine_147(c, v1022_6, p1, v1019_7_tail, s1);
          v1020_12 = compose(v1020_10,v1022_11);
        }
        const Space v1020_13 = unite(v1020_8,v1020_12);
        v1019_7_result = unite(v1019_7_result,v1020_13);
      }
      const Space v1019_7 = std::move(v1019_7_result);
      v1018_8 = compose(v1018_5,v1019_7);
    }
    const Space v1018_9 = intersect(constant_2,v1018_2);
    const Space v1018_10 = (has_head(v1018_9) ? constant_3 : Space{});
    Space v1018_13;
    if (!v1018_10.empty()) {
      const Space v1023_11 = unwrap(v1017_11,v1017_18_head);
      Space v1023_12_result;
      for (int v1023_12_label = 1; v1023_12_label <= 2; ++v1023_12_label) {
        const Space v1023_12_tail = child(v1023_11,v1023_12_label);
        if (v1023_12_tail.empty()) continue;
        const Path v1023_12_head{v1023_12_label};
        const Space v1024_2 = singleton(v1023_12_head);
        const Space v1024_3 = intersect(constant_2,v1024_2);
        const Space v1024_4 = (has_head(v1024_3) ? constant_3 : Space{});
        const Space v1024_5 = subtract(constant_1,v1024_4);
        Space v1024_7;
        if (!v1024_5.empty()) {
          const Space v1025_6 = routine_61(c, v1023_12_head, p1, v1023_12_tail);
          v1024_7 = compose(v1024_5,v1025_6);
        }
        const Space v1024_8 = intersect(constant_2,v1024_2);
        const Space v1024_9 = (has_head(v1024_8) ? constant_3 : Space{});
        Space v1024_11;
        if (!v1024_9.empty()) {
          const Space v1026_10 = routine_62(c, v1023_12_head, p1, v1023_12_tail);
          v1024_11 = compose(v1024_9,v1026_10);
        }
        const Space v1024_12 = unite(v1024_7,v1024_11);
        v1023_12_result = unite(v1023_12_result,v1024_12);
      }
      const Space v1023_12 = std::move(v1023_12_result);
      v1018_13 = compose(v1018_10,v1023_12);
    }
    const Space v1018_14 = unite(v1018_8,v1018_13);
    v1017_18_result = unite(v1017_18_result,v1018_14);
  }
  const Space v1017_18 = std::move(v1017_18_result);
  return v1017_18;
}

static Space routine_110(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1027_12_result;
  for (int v1027_12_label = 1; v1027_12_label <= 2; ++v1027_12_label) {
    const Space v1027_12_tail = child(s0,v1027_12_label);
    if (v1027_12_tail.empty()) continue;
    const Path v1027_12_head{v1027_12_label};
    const Space v1028_2 = singleton(v1027_12_head);
    const Space v1028_3 = intersect(constant_2,v1028_2);
    const Space v1028_4 = (has_head(v1028_3) ? constant_3 : Space{});
    const Space v1028_5 = subtract(constant_1,v1028_4);
    Space v1028_8;
    if (!v1028_5.empty()) {
      const Path v1029_6 = concat_path(p0,v1027_12_head);
      Space v1029_7_result;
      for (int v1029_7_label = 1; v1029_7_label <= 2; ++v1029_7_label) {
        const Space v1029_7_tail = child(v1027_12_tail,v1029_7_label);
        if (v1029_7_tail.empty()) continue;
        const Path v1029_7_head{v1029_7_label};
        const Space v1030_2 = singleton(v1029_7_head);
        const Space v1030_3 = intersect(constant_2,v1030_2);
        const Space v1030_4 = (has_head(v1030_3) ? constant_3 : Space{});
        const Space v1030_5 = subtract(constant_1,v1030_4);
        Space v1030_8;
        if (!v1030_5.empty()) {
          const Path v1031_6 = concat_path(v1029_6,v1029_7_head);
          const Space v1031_7 = routine_148(c, v1031_6, p1, v1029_7_tail);
          v1030_8 = compose(v1030_5,v1031_7);
        }
        const Space v1030_9 = intersect(constant_2,v1030_2);
        const Space v1030_10 = (has_head(v1030_9) ? constant_3 : Space{});
        Space v1030_12;
        if (!v1030_10.empty()) {
          const Path v1032_6 = concat_path(v1029_6,v1029_7_head);
          const Space v1032_11 = routine_149(c, v1032_6, p1, v1029_7_tail);
          v1030_12 = compose(v1030_10,v1032_11);
        }
        const Space v1030_13 = unite(v1030_8,v1030_12);
        v1029_7_result = unite(v1029_7_result,v1030_13);
      }
      const Space v1029_7 = std::move(v1029_7_result);
      v1028_8 = compose(v1028_5,v1029_7);
    }
    const Space v1028_9 = intersect(constant_2,v1028_2);
    const Space v1028_10 = (has_head(v1028_9) ? constant_3 : Space{});
    Space v1028_12;
    if (!v1028_10.empty()) {
      const Path v1033_6 = concat_path(p0,v1027_12_head);
      Space v1033_11_result;
      for (int v1033_11_label = 1; v1033_11_label <= 2; ++v1033_11_label) {
        const Space v1033_11_tail = child(v1027_12_tail,v1033_11_label);
        if (v1033_11_tail.empty()) continue;
        const Path v1033_11_head{v1033_11_label};
        const Space v1034_2 = singleton(v1033_11_head);
        const Space v1034_3 = intersect(constant_2,v1034_2);
        const Space v1034_4 = (has_head(v1034_3) ? constant_3 : Space{});
        const Space v1034_5 = subtract(constant_1,v1034_4);
        Space v1034_8;
        if (!v1034_5.empty()) {
          const Path v1035_6 = concat_path(v1033_6,v1033_11_head);
          const Space v1035_7 = routine_148(c, v1035_6, p1, v1033_11_tail);
          v1034_8 = compose(v1034_5,v1035_7);
        }
        const Space v1034_9 = intersect(constant_2,v1034_2);
        const Space v1034_10 = (has_head(v1034_9) ? constant_3 : Space{});
        Space v1034_12;
        if (!v1034_10.empty()) {
          const Path v1036_6 = concat_path(v1033_6,v1033_11_head);
          const Space v1036_11 = routine_67(c, v1036_6, p1, v1033_11_tail);
          v1034_12 = compose(v1034_10,v1036_11);
        }
        const Space v1034_13 = unite(v1034_8,v1034_12);
        v1033_11_result = unite(v1033_11_result,v1034_13);
      }
      const Space v1033_11 = std::move(v1033_11_result);
      v1028_12 = compose(v1028_10,v1033_11);
    }
    const Space v1028_13 = unite(v1028_8,v1028_12);
    v1027_12_result = unite(v1027_12_result,v1028_13);
  }
  const Space v1027_12 = std::move(v1027_12_result);
  return v1027_12;
}

static Space routine_111(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1037_9_result;
  for (int v1037_9_label = 1; v1037_9_label <= 2; ++v1037_9_label) {
    const Space v1037_9_tail = child(s0,v1037_9_label);
    if (v1037_9_tail.empty()) continue;
    const Path v1037_9_head{v1037_9_label};
    const Space v1038_2 = singleton(v1037_9_head);
    const Space v1038_3 = intersect(constant_2,v1038_2);
    const Space v1038_4 = (has_head(v1038_3) ? constant_3 : Space{});
    const Space v1038_5 = subtract(constant_1,v1038_4);
    Space v1038_8;
    if (!v1038_5.empty()) {
      const Path v1039_6 = concat_path(p0,v1037_9_head);
      Space v1039_7_result;
      for (int v1039_7_label = 1; v1039_7_label <= 2; ++v1039_7_label) {
        const Space v1039_7_tail = child(v1037_9_tail,v1039_7_label);
        if (v1039_7_tail.empty()) continue;
        const Path v1039_7_head{v1039_7_label};
        const Space v1040_2 = singleton(v1039_7_head);
        const Space v1040_3 = intersect(constant_2,v1040_2);
        const Space v1040_4 = (has_head(v1040_3) ? constant_3 : Space{});
        const Space v1040_5 = subtract(constant_1,v1040_4);
        Space v1040_8;
        if (!v1040_5.empty()) {
          const Path v1041_6 = concat_path(v1039_6,v1039_7_head);
          const Space v1041_7 = routine_148(c, v1041_6, p1, v1039_7_tail);
          v1040_8 = compose(v1040_5,v1041_7);
        }
        const Space v1040_9 = intersect(constant_2,v1040_2);
        const Space v1040_10 = (has_head(v1040_9) ? constant_3 : Space{});
        Space v1040_12;
        if (!v1040_10.empty()) {
          const Path v1042_6 = concat_path(v1039_6,v1039_7_head);
          const Space v1042_11 = routine_149(c, v1042_6, p1, v1039_7_tail);
          v1040_12 = compose(v1040_10,v1042_11);
        }
        const Space v1040_13 = unite(v1040_8,v1040_12);
        v1039_7_result = unite(v1039_7_result,v1040_13);
      }
      const Space v1039_7 = std::move(v1039_7_result);
      v1038_8 = compose(v1038_5,v1039_7);
    }
    const Space v1038_9 = intersect(constant_2,v1038_2);
    const Space v1038_10 = (has_head(v1038_9) ? constant_3 : Space{});
    const Space v1038_11 = compose(v1038_10,v1037_9_tail);
    const Path v1043_6 = concat_path(p0,v1037_9_head);
    const Space v1038_12 = wrap(v1038_11,v1043_6);
    const Space v1038_13 = wrap(v1038_12,p1);
    const Space v1038_14 = unite(v1038_8,v1038_13);
    v1037_9_result = unite(v1037_9_result,v1038_14);
  }
  const Space v1037_9 = std::move(v1037_9_result);
  return v1037_9;
}

static Space routine_112(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1044_7_result;
  for (int v1044_7_label = 1; v1044_7_label <= 2; ++v1044_7_label) {
    const Space v1044_7_tail = child(s0,v1044_7_label);
    if (v1044_7_tail.empty()) continue;
    const Path v1044_7_head{v1044_7_label};
    const Space v1045_2 = singleton(v1044_7_head);
    const Space v1045_3 = intersect(constant_2,v1045_2);
    const Space v1045_4 = (has_head(v1045_3) ? constant_3 : Space{});
    const Space v1045_5 = subtract(constant_1,v1045_4);
    Space v1045_6_result;
    for (int v1045_6_label = 1; v1045_6_label <= 2; ++v1045_6_label) {
      const Space v1045_6_tail = child(v1044_7_tail,v1045_6_label);
      if (v1045_6_tail.empty()) continue;
      const Path v1045_6_head{v1045_6_label};
      const Space v1046_2 = Space{};
      v1045_6_result = unite(v1045_6_result,v1046_2);
    }
    const Space v1045_6 = std::move(v1045_6_result);
    const Space v1045_7 = compose(v1045_5,v1045_6);
    const Space v1045_8 = intersect(constant_2,v1045_2);
    const Space v1045_9 = (has_head(v1045_8) ? constant_3 : Space{});
    Space v1045_12;
    if (!v1045_9.empty()) {
      const Path v1047_10 = concat_path(p0,v1044_7_head);
      Space v1047_11_result;
      for (int v1047_11_label = 1; v1047_11_label <= 2; ++v1047_11_label) {
        const Space v1047_11_tail = child(v1044_7_tail,v1047_11_label);
        if (v1047_11_tail.empty()) continue;
        const Path v1047_11_head{v1047_11_label};
        const Space v1048_2 = singleton(v1047_11_head);
        const Space v1048_3 = intersect(constant_2,v1048_2);
        const Space v1048_4 = (has_head(v1048_3) ? constant_3 : Space{});
        Space v1048_7;
        if (!v1048_4.empty()) {
          const Path v1049_5 = concat_path(v1047_10,v1047_11_head);
          const Space v1049_6 = routine_9(c, v1049_5, v1047_11_tail, s1);
          v1048_7 = compose(v1048_4,v1049_6);
        }
        v1047_11_result = unite(v1047_11_result,v1048_7);
      }
      const Space v1047_11 = std::move(v1047_11_result);
      v1045_12 = compose(v1045_9,v1047_11);
    }
    const Space v1045_13 = unite(v1045_7,v1045_12);
    v1044_7_result = unite(v1044_7_result,v1045_13);
  }
  const Space v1044_7 = std::move(v1044_7_result);
  return v1044_7;
}

static Space routine_113(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1050_9_result;
  for (int v1050_9_label = 1; v1050_9_label <= 2; ++v1050_9_label) {
    const Space v1050_9_tail = child(s0,v1050_9_label);
    if (v1050_9_tail.empty()) continue;
    const Path v1050_9_head{v1050_9_label};
    const Space v1051_2 = singleton(v1050_9_head);
    const Space v1051_3 = intersect(constant_2,v1051_2);
    const Space v1051_4 = (has_head(v1051_3) ? constant_3 : Space{});
    const Space v1051_5 = subtract(constant_1,v1051_4);
    Space v1051_6_result;
    for (int v1051_6_label = 1; v1051_6_label <= 2; ++v1051_6_label) {
      const Space v1051_6_tail = child(v1050_9_tail,v1051_6_label);
      if (v1051_6_tail.empty()) continue;
      const Path v1051_6_head{v1051_6_label};
      const Space v1052_2 = Space{};
      v1051_6_result = unite(v1051_6_result,v1052_2);
    }
    const Space v1051_6 = std::move(v1051_6_result);
    const Space v1051_7 = compose(v1051_5,v1051_6);
    const Space v1051_8 = intersect(constant_2,v1051_2);
    const Space v1051_9 = (has_head(v1051_8) ? constant_3 : Space{});
    Space v1051_12;
    if (!v1051_9.empty()) {
      const Path v1053_10 = concat_path(p0,v1050_9_head);
      Space v1053_11_result;
      for (int v1053_11_label = 1; v1053_11_label <= 2; ++v1053_11_label) {
        const Space v1053_11_tail = child(v1050_9_tail,v1053_11_label);
        if (v1053_11_tail.empty()) continue;
        const Path v1053_11_head{v1053_11_label};
        const Space v1054_2 = singleton(v1053_11_head);
        const Space v1054_3 = intersect(constant_2,v1054_2);
        const Space v1054_4 = (has_head(v1054_3) ? constant_3 : Space{});
        const Space v1054_5 = subtract(constant_1,v1054_4);
        Space v1054_7;
        if (!v1054_5.empty()) {
          const Space v1055_6 = routine_32(c, v1053_11_head, v1053_10, v1053_11_tail, s1);
          v1054_7 = compose(v1054_5,v1055_6);
        }
        const Space v1054_8 = intersect(constant_2,v1054_2);
        const Space v1054_9 = (has_head(v1054_8) ? constant_3 : Space{});
        Space v1054_11;
        if (!v1054_9.empty()) {
          const Space v1056_10 = routine_33(c, v1053_11_head, v1053_10, v1053_11_tail, s1);
          v1054_11 = compose(v1054_9,v1056_10);
        }
        const Space v1054_12 = unite(v1054_7,v1054_11);
        v1053_11_result = unite(v1053_11_result,v1054_12);
      }
      const Space v1053_11 = std::move(v1053_11_result);
      v1051_12 = compose(v1051_9,v1053_11);
    }
    const Space v1051_13 = unite(v1051_7,v1051_12);
    v1050_9_result = unite(v1050_9_result,v1051_13);
  }
  const Space v1050_9 = std::move(v1050_9_result);
  return v1050_9;
}

static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1057_13_result;
  for (int v1057_13_label = 1; v1057_13_label <= 2; ++v1057_13_label) {
    const Space v1057_13_tail = child(s0,v1057_13_label);
    if (v1057_13_tail.empty()) continue;
    const Path v1057_13_head{v1057_13_label};
    const Space v1058_2 = singleton(v1057_13_head);
    const Space v1058_3 = intersect(constant_2,v1058_2);
    const Space v1058_4 = (has_head(v1058_3) ? constant_3 : Space{});
    const Space v1058_5 = subtract(constant_1,v1058_4);
    Space v1058_8;
    if (!v1058_5.empty()) {
      const Path v1059_6 = concat_path(p0,v1057_13_head);
      Space v1059_7_result;
      for (int v1059_7_label = 1; v1059_7_label <= 2; ++v1059_7_label) {
        const Space v1059_7_tail = child(v1057_13_tail,v1059_7_label);
        if (v1059_7_tail.empty()) continue;
        const Path v1059_7_head{v1059_7_label};
        const Space v1060_2 = singleton(v1059_7_head);
        const Space v1060_3 = intersect(constant_2,v1060_2);
        const Space v1060_4 = (has_head(v1060_3) ? constant_3 : Space{});
        const Space v1060_5 = subtract(constant_1,v1060_4);
        Space v1060_8;
        if (!v1060_5.empty()) {
          const Path v1061_6 = concat_path(v1059_6,v1059_7_head);
          const Space v1061_7 = routine_150(c, v1061_6, p1, v1059_7_tail, s1);
          v1060_8 = compose(v1060_5,v1061_7);
        }
        const Space v1060_9 = intersect(constant_2,v1060_2);
        const Space v1060_10 = (has_head(v1060_9) ? constant_3 : Space{});
        Space v1060_12;
        if (!v1060_10.empty()) {
          const Path v1062_6 = concat_path(v1059_6,v1059_7_head);
          const Space v1062_11 = routine_151(c, v1062_6, p1, v1059_7_tail, s1);
          v1060_12 = compose(v1060_10,v1062_11);
        }
        const Space v1060_13 = unite(v1060_8,v1060_12);
        v1059_7_result = unite(v1059_7_result,v1060_13);
      }
      const Space v1059_7 = std::move(v1059_7_result);
      v1058_8 = compose(v1058_5,v1059_7);
    }
    const Space v1058_9 = intersect(constant_2,v1058_2);
    const Space v1058_10 = (has_head(v1058_9) ? constant_3 : Space{});
    Space v1058_12;
    if (!v1058_10.empty()) {
      const Path v1063_6 = concat_path(p0,v1057_13_head);
      Space v1063_11_result;
      for (int v1063_11_label = 1; v1063_11_label <= 2; ++v1063_11_label) {
        const Space v1063_11_tail = child(v1057_13_tail,v1063_11_label);
        if (v1063_11_tail.empty()) continue;
        const Path v1063_11_head{v1063_11_label};
        const Space v1064_2 = singleton(v1063_11_head);
        const Space v1064_3 = intersect(constant_2,v1064_2);
        const Space v1064_4 = (has_head(v1064_3) ? constant_3 : Space{});
        const Space v1064_5 = subtract(constant_1,v1064_4);
        Space v1064_8;
        if (!v1064_5.empty()) {
          const Path v1065_6 = concat_path(v1063_6,v1063_11_head);
          const Space v1065_7 = routine_150(c, v1065_6, p1, v1063_11_tail, s1);
          v1064_8 = compose(v1064_5,v1065_7);
        }
        const Space v1064_9 = intersect(constant_2,v1064_2);
        const Space v1064_10 = (has_head(v1064_9) ? constant_3 : Space{});
        Space v1064_12;
        if (!v1064_10.empty()) {
          const Path v1066_6 = concat_path(v1063_6,v1063_11_head);
          const Space v1066_11 = routine_36(c, v1066_6, p1, v1063_11_tail, s1);
          v1064_12 = compose(v1064_10,v1066_11);
        }
        const Space v1064_13 = unite(v1064_8,v1064_12);
        v1063_11_result = unite(v1063_11_result,v1064_13);
      }
      const Space v1063_11 = std::move(v1063_11_result);
      v1058_12 = compose(v1058_10,v1063_11);
    }
    const Space v1058_13 = unite(v1058_8,v1058_12);
    v1057_13_result = unite(v1057_13_result,v1058_13);
  }
  const Space v1057_13 = std::move(v1057_13_result);
  return v1057_13;
}

static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1067_8 = unwrap(s1,constant_4);
  const Space v1067_10 = unwrap(v1067_8,constant_6);
  const Space v1067_11 = unwrap(v1067_10,p0);
  Space v1067_18_result;
  for (int v1067_18_label = 1; v1067_18_label <= 2; ++v1067_18_label) {
    const Space v1067_18_tail = child(s0,v1067_18_label);
    if (v1067_18_tail.empty()) continue;
    const Path v1067_18_head{v1067_18_label};
    const Space v1068_2 = singleton(v1067_18_head);
    const Space v1068_3 = intersect(constant_2,v1068_2);
    const Space v1068_4 = (has_head(v1068_3) ? constant_3 : Space{});
    const Space v1068_5 = subtract(constant_1,v1068_4);
    Space v1068_8;
    if (!v1068_5.empty()) {
      const Path v1069_6 = concat_path(p0,v1067_18_head);
      Space v1069_7_result;
      for (int v1069_7_label = 1; v1069_7_label <= 2; ++v1069_7_label) {
        const Space v1069_7_tail = child(v1067_18_tail,v1069_7_label);
        if (v1069_7_tail.empty()) continue;
        const Path v1069_7_head{v1069_7_label};
        const Space v1070_2 = singleton(v1069_7_head);
        const Space v1070_3 = intersect(constant_2,v1070_2);
        const Space v1070_4 = (has_head(v1070_3) ? constant_3 : Space{});
        const Space v1070_5 = subtract(constant_1,v1070_4);
        Space v1070_8;
        if (!v1070_5.empty()) {
          const Path v1071_6 = concat_path(v1069_6,v1069_7_head);
          const Space v1071_7 = routine_150(c, v1071_6, p1, v1069_7_tail, s1);
          v1070_8 = compose(v1070_5,v1071_7);
        }
        const Space v1070_9 = intersect(constant_2,v1070_2);
        const Space v1070_10 = (has_head(v1070_9) ? constant_3 : Space{});
        Space v1070_12;
        if (!v1070_10.empty()) {
          const Path v1072_6 = concat_path(v1069_6,v1069_7_head);
          const Space v1072_11 = routine_151(c, v1072_6, p1, v1069_7_tail, s1);
          v1070_12 = compose(v1070_10,v1072_11);
        }
        const Space v1070_13 = unite(v1070_8,v1070_12);
        v1069_7_result = unite(v1069_7_result,v1070_13);
      }
      const Space v1069_7 = std::move(v1069_7_result);
      v1068_8 = compose(v1068_5,v1069_7);
    }
    const Space v1068_9 = intersect(constant_2,v1068_2);
    const Space v1068_10 = (has_head(v1068_9) ? constant_3 : Space{});
    Space v1068_13;
    if (!v1068_10.empty()) {
      const Space v1073_11 = unwrap(v1067_11,v1067_18_head);
      Space v1073_12_result;
      for (int v1073_12_label = 1; v1073_12_label <= 2; ++v1073_12_label) {
        const Space v1073_12_tail = child(v1073_11,v1073_12_label);
        if (v1073_12_tail.empty()) continue;
        const Path v1073_12_head{v1073_12_label};
        const Space v1074_2 = singleton(v1073_12_head);
        const Space v1074_3 = intersect(constant_2,v1074_2);
        const Space v1074_4 = (has_head(v1074_3) ? constant_3 : Space{});
        const Space v1074_5 = subtract(constant_1,v1074_4);
        Space v1074_7;
        if (!v1074_5.empty()) {
          const Space v1075_6 = routine_72(c, v1073_12_head, p1, v1073_12_tail);
          v1074_7 = compose(v1074_5,v1075_6);
        }
        const Space v1074_8 = intersect(constant_2,v1074_2);
        const Space v1074_9 = (has_head(v1074_8) ? constant_3 : Space{});
        Space v1074_11;
        if (!v1074_9.empty()) {
          const Space v1076_10 = routine_73(c, v1073_12_head, p1, v1073_12_tail);
          v1074_11 = compose(v1074_9,v1076_10);
        }
        const Space v1074_12 = unite(v1074_7,v1074_11);
        v1073_12_result = unite(v1073_12_result,v1074_12);
      }
      const Space v1073_12 = std::move(v1073_12_result);
      v1068_13 = compose(v1068_10,v1073_12);
    }
    const Space v1068_14 = unite(v1068_8,v1068_13);
    v1067_18_result = unite(v1067_18_result,v1068_14);
  }
  const Space v1067_18 = std::move(v1067_18_result);
  return v1067_18;
}

static Space routine_116(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1077_12_result;
  for (int v1077_12_label = 1; v1077_12_label <= 2; ++v1077_12_label) {
    const Space v1077_12_tail = child(s0,v1077_12_label);
    if (v1077_12_tail.empty()) continue;
    const Path v1077_12_head{v1077_12_label};
    const Space v1078_2 = singleton(v1077_12_head);
    const Space v1078_3 = intersect(constant_2,v1078_2);
    const Space v1078_4 = (has_head(v1078_3) ? constant_3 : Space{});
    const Space v1078_5 = subtract(constant_1,v1078_4);
    Space v1078_8;
    if (!v1078_5.empty()) {
      const Path v1079_6 = concat_path(p0,v1077_12_head);
      Space v1079_7_result;
      for (int v1079_7_label = 1; v1079_7_label <= 2; ++v1079_7_label) {
        const Space v1079_7_tail = child(v1077_12_tail,v1079_7_label);
        if (v1079_7_tail.empty()) continue;
        const Path v1079_7_head{v1079_7_label};
        const Space v1080_2 = singleton(v1079_7_head);
        const Space v1080_3 = intersect(constant_2,v1080_2);
        const Space v1080_4 = (has_head(v1080_3) ? constant_3 : Space{});
        const Space v1080_5 = subtract(constant_1,v1080_4);
        Space v1080_8;
        if (!v1080_5.empty()) {
          const Path v1081_6 = concat_path(v1079_6,v1079_7_head);
          const Space v1081_7 = routine_152(c, v1081_6, p1, v1079_7_tail);
          v1080_8 = compose(v1080_5,v1081_7);
        }
        const Space v1080_9 = intersect(constant_2,v1080_2);
        const Space v1080_10 = (has_head(v1080_9) ? constant_3 : Space{});
        Space v1080_12;
        if (!v1080_10.empty()) {
          const Path v1082_6 = concat_path(v1079_6,v1079_7_head);
          const Space v1082_11 = routine_153(c, v1082_6, p1, v1079_7_tail);
          v1080_12 = compose(v1080_10,v1082_11);
        }
        const Space v1080_13 = unite(v1080_8,v1080_12);
        v1079_7_result = unite(v1079_7_result,v1080_13);
      }
      const Space v1079_7 = std::move(v1079_7_result);
      v1078_8 = compose(v1078_5,v1079_7);
    }
    const Space v1078_9 = intersect(constant_2,v1078_2);
    const Space v1078_10 = (has_head(v1078_9) ? constant_3 : Space{});
    Space v1078_12;
    if (!v1078_10.empty()) {
      const Path v1083_6 = concat_path(p0,v1077_12_head);
      Space v1083_11_result;
      for (int v1083_11_label = 1; v1083_11_label <= 2; ++v1083_11_label) {
        const Space v1083_11_tail = child(v1077_12_tail,v1083_11_label);
        if (v1083_11_tail.empty()) continue;
        const Path v1083_11_head{v1083_11_label};
        const Space v1084_2 = singleton(v1083_11_head);
        const Space v1084_3 = intersect(constant_2,v1084_2);
        const Space v1084_4 = (has_head(v1084_3) ? constant_3 : Space{});
        const Space v1084_5 = subtract(constant_1,v1084_4);
        Space v1084_8;
        if (!v1084_5.empty()) {
          const Path v1085_6 = concat_path(v1083_6,v1083_11_head);
          const Space v1085_7 = routine_152(c, v1085_6, p1, v1083_11_tail);
          v1084_8 = compose(v1084_5,v1085_7);
        }
        const Space v1084_9 = intersect(constant_2,v1084_2);
        const Space v1084_10 = (has_head(v1084_9) ? constant_3 : Space{});
        Space v1084_12;
        if (!v1084_10.empty()) {
          const Path v1086_6 = concat_path(v1083_6,v1083_11_head);
          const Space v1086_11 = routine_78(c, v1086_6, p1, v1083_11_tail);
          v1084_12 = compose(v1084_10,v1086_11);
        }
        const Space v1084_13 = unite(v1084_8,v1084_12);
        v1083_11_result = unite(v1083_11_result,v1084_13);
      }
      const Space v1083_11 = std::move(v1083_11_result);
      v1078_12 = compose(v1078_10,v1083_11);
    }
    const Space v1078_13 = unite(v1078_8,v1078_12);
    v1077_12_result = unite(v1077_12_result,v1078_13);
  }
  const Space v1077_12 = std::move(v1077_12_result);
  return v1077_12;
}

static Space routine_117(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1087_9_result;
  for (int v1087_9_label = 1; v1087_9_label <= 2; ++v1087_9_label) {
    const Space v1087_9_tail = child(s0,v1087_9_label);
    if (v1087_9_tail.empty()) continue;
    const Path v1087_9_head{v1087_9_label};
    const Space v1088_2 = singleton(v1087_9_head);
    const Space v1088_3 = intersect(constant_2,v1088_2);
    const Space v1088_4 = (has_head(v1088_3) ? constant_3 : Space{});
    const Space v1088_5 = subtract(constant_1,v1088_4);
    Space v1088_8;
    if (!v1088_5.empty()) {
      const Path v1089_6 = concat_path(p0,v1087_9_head);
      Space v1089_7_result;
      for (int v1089_7_label = 1; v1089_7_label <= 2; ++v1089_7_label) {
        const Space v1089_7_tail = child(v1087_9_tail,v1089_7_label);
        if (v1089_7_tail.empty()) continue;
        const Path v1089_7_head{v1089_7_label};
        const Space v1090_2 = singleton(v1089_7_head);
        const Space v1090_3 = intersect(constant_2,v1090_2);
        const Space v1090_4 = (has_head(v1090_3) ? constant_3 : Space{});
        const Space v1090_5 = subtract(constant_1,v1090_4);
        Space v1090_8;
        if (!v1090_5.empty()) {
          const Path v1091_6 = concat_path(v1089_6,v1089_7_head);
          const Space v1091_7 = routine_152(c, v1091_6, p1, v1089_7_tail);
          v1090_8 = compose(v1090_5,v1091_7);
        }
        const Space v1090_9 = intersect(constant_2,v1090_2);
        const Space v1090_10 = (has_head(v1090_9) ? constant_3 : Space{});
        Space v1090_12;
        if (!v1090_10.empty()) {
          const Path v1092_6 = concat_path(v1089_6,v1089_7_head);
          const Space v1092_11 = routine_153(c, v1092_6, p1, v1089_7_tail);
          v1090_12 = compose(v1090_10,v1092_11);
        }
        const Space v1090_13 = unite(v1090_8,v1090_12);
        v1089_7_result = unite(v1089_7_result,v1090_13);
      }
      const Space v1089_7 = std::move(v1089_7_result);
      v1088_8 = compose(v1088_5,v1089_7);
    }
    const Space v1088_9 = intersect(constant_2,v1088_2);
    const Space v1088_10 = (has_head(v1088_9) ? constant_3 : Space{});
    const Space v1088_11 = compose(v1088_10,v1087_9_tail);
    const Path v1093_6 = concat_path(p0,v1087_9_head);
    const Space v1088_12 = wrap(v1088_11,v1093_6);
    const Space v1088_13 = wrap(v1088_12,p1);
    const Space v1088_14 = unite(v1088_8,v1088_13);
    v1087_9_result = unite(v1087_9_result,v1088_14);
  }
  const Space v1087_9 = std::move(v1087_9_result);
  return v1087_9;
}

static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1094_13_result;
  for (int v1094_13_label = 1; v1094_13_label <= 2; ++v1094_13_label) {
    const Space v1094_13_tail = child(s0,v1094_13_label);
    if (v1094_13_tail.empty()) continue;
    const Path v1094_13_head{v1094_13_label};
    const Space v1095_2 = singleton(v1094_13_head);
    const Space v1095_3 = intersect(constant_2,v1095_2);
    const Space v1095_4 = (has_head(v1095_3) ? constant_3 : Space{});
    const Space v1095_5 = subtract(constant_1,v1095_4);
    Space v1095_8;
    if (!v1095_5.empty()) {
      const Path v1096_6 = concat_path(p0,v1094_13_head);
      Space v1096_7_result;
      for (int v1096_7_label = 1; v1096_7_label <= 2; ++v1096_7_label) {
        const Space v1096_7_tail = child(v1094_13_tail,v1096_7_label);
        if (v1096_7_tail.empty()) continue;
        const Path v1096_7_head{v1096_7_label};
        const Space v1097_2 = singleton(v1096_7_head);
        const Space v1097_3 = intersect(constant_2,v1097_2);
        const Space v1097_4 = (has_head(v1097_3) ? constant_3 : Space{});
        const Space v1097_5 = subtract(constant_1,v1097_4);
        Space v1097_8;
        if (!v1097_5.empty()) {
          const Path v1098_6 = concat_path(v1096_6,v1096_7_head);
          const Space v1098_7 = routine_154(c, v1098_6, p1, v1096_7_tail, s1);
          v1097_8 = compose(v1097_5,v1098_7);
        }
        const Space v1097_9 = intersect(constant_2,v1097_2);
        const Space v1097_10 = (has_head(v1097_9) ? constant_3 : Space{});
        Space v1097_12;
        if (!v1097_10.empty()) {
          const Path v1099_6 = concat_path(v1096_6,v1096_7_head);
          const Space v1099_11 = routine_155(c, v1099_6, p1, v1096_7_tail, s1);
          v1097_12 = compose(v1097_10,v1099_11);
        }
        const Space v1097_13 = unite(v1097_8,v1097_12);
        v1096_7_result = unite(v1096_7_result,v1097_13);
      }
      const Space v1096_7 = std::move(v1096_7_result);
      v1095_8 = compose(v1095_5,v1096_7);
    }
    const Space v1095_9 = intersect(constant_2,v1095_2);
    const Space v1095_10 = (has_head(v1095_9) ? constant_3 : Space{});
    Space v1095_12;
    if (!v1095_10.empty()) {
      const Path v1100_6 = concat_path(p0,v1094_13_head);
      Space v1100_11_result;
      for (int v1100_11_label = 1; v1100_11_label <= 2; ++v1100_11_label) {
        const Space v1100_11_tail = child(v1094_13_tail,v1100_11_label);
        if (v1100_11_tail.empty()) continue;
        const Path v1100_11_head{v1100_11_label};
        const Space v1101_2 = singleton(v1100_11_head);
        const Space v1101_3 = intersect(constant_2,v1101_2);
        const Space v1101_4 = (has_head(v1101_3) ? constant_3 : Space{});
        const Space v1101_5 = subtract(constant_1,v1101_4);
        Space v1101_8;
        if (!v1101_5.empty()) {
          const Path v1102_6 = concat_path(v1100_6,v1100_11_head);
          const Space v1102_7 = routine_154(c, v1102_6, p1, v1100_11_tail, s1);
          v1101_8 = compose(v1101_5,v1102_7);
        }
        const Space v1101_9 = intersect(constant_2,v1101_2);
        const Space v1101_10 = (has_head(v1101_9) ? constant_3 : Space{});
        Space v1101_12;
        if (!v1101_10.empty()) {
          const Path v1103_6 = concat_path(v1100_6,v1100_11_head);
          const Space v1103_11 = routine_36(c, v1103_6, p1, v1100_11_tail, s1);
          v1101_12 = compose(v1101_10,v1103_11);
        }
        const Space v1101_13 = unite(v1101_8,v1101_12);
        v1100_11_result = unite(v1100_11_result,v1101_13);
      }
      const Space v1100_11 = std::move(v1100_11_result);
      v1095_12 = compose(v1095_10,v1100_11);
    }
    const Space v1095_13 = unite(v1095_8,v1095_12);
    v1094_13_result = unite(v1094_13_result,v1095_13);
  }
  const Space v1094_13 = std::move(v1094_13_result);
  return v1094_13;
}

static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1104_8 = unwrap(s1,constant_4);
  const Space v1104_10 = unwrap(v1104_8,constant_6);
  const Space v1104_11 = unwrap(v1104_10,p0);
  Space v1104_18_result;
  for (int v1104_18_label = 1; v1104_18_label <= 2; ++v1104_18_label) {
    const Space v1104_18_tail = child(s0,v1104_18_label);
    if (v1104_18_tail.empty()) continue;
    const Path v1104_18_head{v1104_18_label};
    const Space v1105_2 = singleton(v1104_18_head);
    const Space v1105_3 = intersect(constant_2,v1105_2);
    const Space v1105_4 = (has_head(v1105_3) ? constant_3 : Space{});
    const Space v1105_5 = subtract(constant_1,v1105_4);
    Space v1105_8;
    if (!v1105_5.empty()) {
      const Path v1106_6 = concat_path(p0,v1104_18_head);
      Space v1106_7_result;
      for (int v1106_7_label = 1; v1106_7_label <= 2; ++v1106_7_label) {
        const Space v1106_7_tail = child(v1104_18_tail,v1106_7_label);
        if (v1106_7_tail.empty()) continue;
        const Path v1106_7_head{v1106_7_label};
        const Space v1107_2 = singleton(v1106_7_head);
        const Space v1107_3 = intersect(constant_2,v1107_2);
        const Space v1107_4 = (has_head(v1107_3) ? constant_3 : Space{});
        const Space v1107_5 = subtract(constant_1,v1107_4);
        Space v1107_8;
        if (!v1107_5.empty()) {
          const Path v1108_6 = concat_path(v1106_6,v1106_7_head);
          const Space v1108_7 = routine_154(c, v1108_6, p1, v1106_7_tail, s1);
          v1107_8 = compose(v1107_5,v1108_7);
        }
        const Space v1107_9 = intersect(constant_2,v1107_2);
        const Space v1107_10 = (has_head(v1107_9) ? constant_3 : Space{});
        Space v1107_12;
        if (!v1107_10.empty()) {
          const Path v1109_6 = concat_path(v1106_6,v1106_7_head);
          const Space v1109_11 = routine_155(c, v1109_6, p1, v1106_7_tail, s1);
          v1107_12 = compose(v1107_10,v1109_11);
        }
        const Space v1107_13 = unite(v1107_8,v1107_12);
        v1106_7_result = unite(v1106_7_result,v1107_13);
      }
      const Space v1106_7 = std::move(v1106_7_result);
      v1105_8 = compose(v1105_5,v1106_7);
    }
    const Space v1105_9 = intersect(constant_2,v1105_2);
    const Space v1105_10 = (has_head(v1105_9) ? constant_3 : Space{});
    Space v1105_13;
    if (!v1105_10.empty()) {
      const Space v1110_11 = unwrap(v1104_11,v1104_18_head);
      Space v1110_12_result;
      for (int v1110_12_label = 1; v1110_12_label <= 2; ++v1110_12_label) {
        const Space v1110_12_tail = child(v1110_11,v1110_12_label);
        if (v1110_12_tail.empty()) continue;
        const Path v1110_12_head{v1110_12_label};
        const Space v1111_2 = singleton(v1110_12_head);
        const Space v1111_3 = intersect(constant_2,v1111_2);
        const Space v1111_4 = (has_head(v1111_3) ? constant_3 : Space{});
        const Space v1111_5 = subtract(constant_1,v1111_4);
        Space v1111_7;
        if (!v1111_5.empty()) {
          const Space v1112_6 = routine_72(c, v1110_12_head, p1, v1110_12_tail);
          v1111_7 = compose(v1111_5,v1112_6);
        }
        const Space v1111_8 = intersect(constant_2,v1111_2);
        const Space v1111_9 = (has_head(v1111_8) ? constant_3 : Space{});
        Space v1111_11;
        if (!v1111_9.empty()) {
          const Space v1113_10 = routine_73(c, v1110_12_head, p1, v1110_12_tail);
          v1111_11 = compose(v1111_9,v1113_10);
        }
        const Space v1111_12 = unite(v1111_7,v1111_11);
        v1110_12_result = unite(v1110_12_result,v1111_12);
      }
      const Space v1110_12 = std::move(v1110_12_result);
      v1105_13 = compose(v1105_10,v1110_12);
    }
    const Space v1105_14 = unite(v1105_8,v1105_13);
    v1104_18_result = unite(v1104_18_result,v1105_14);
  }
  const Space v1104_18 = std::move(v1104_18_result);
  return v1104_18;
}

static Space routine_120(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1114_12_result;
  for (int v1114_12_label = 1; v1114_12_label <= 2; ++v1114_12_label) {
    const Space v1114_12_tail = child(s0,v1114_12_label);
    if (v1114_12_tail.empty()) continue;
    const Path v1114_12_head{v1114_12_label};
    const Space v1115_2 = singleton(v1114_12_head);
    const Space v1115_3 = intersect(constant_2,v1115_2);
    const Space v1115_4 = (has_head(v1115_3) ? constant_3 : Space{});
    const Space v1115_5 = subtract(constant_1,v1115_4);
    Space v1115_8;
    if (!v1115_5.empty()) {
      const Path v1116_6 = concat_path(p0,v1114_12_head);
      Space v1116_7_result;
      for (int v1116_7_label = 1; v1116_7_label <= 2; ++v1116_7_label) {
        const Space v1116_7_tail = child(v1114_12_tail,v1116_7_label);
        if (v1116_7_tail.empty()) continue;
        const Path v1116_7_head{v1116_7_label};
        const Space v1117_2 = singleton(v1116_7_head);
        const Space v1117_3 = intersect(constant_2,v1117_2);
        const Space v1117_4 = (has_head(v1117_3) ? constant_3 : Space{});
        const Space v1117_5 = subtract(constant_1,v1117_4);
        Space v1117_8;
        if (!v1117_5.empty()) {
          const Path v1118_6 = concat_path(v1116_6,v1116_7_head);
          const Space v1118_7 = routine_156(c, v1118_6, p1, v1116_7_tail);
          v1117_8 = compose(v1117_5,v1118_7);
        }
        const Space v1117_9 = intersect(constant_2,v1117_2);
        const Space v1117_10 = (has_head(v1117_9) ? constant_3 : Space{});
        Space v1117_12;
        if (!v1117_10.empty()) {
          const Path v1119_6 = concat_path(v1116_6,v1116_7_head);
          const Space v1119_11 = routine_157(c, v1119_6, p1, v1116_7_tail);
          v1117_12 = compose(v1117_10,v1119_11);
        }
        const Space v1117_13 = unite(v1117_8,v1117_12);
        v1116_7_result = unite(v1116_7_result,v1117_13);
      }
      const Space v1116_7 = std::move(v1116_7_result);
      v1115_8 = compose(v1115_5,v1116_7);
    }
    const Space v1115_9 = intersect(constant_2,v1115_2);
    const Space v1115_10 = (has_head(v1115_9) ? constant_3 : Space{});
    Space v1115_12;
    if (!v1115_10.empty()) {
      const Path v1120_6 = concat_path(p0,v1114_12_head);
      Space v1120_11_result;
      for (int v1120_11_label = 1; v1120_11_label <= 2; ++v1120_11_label) {
        const Space v1120_11_tail = child(v1114_12_tail,v1120_11_label);
        if (v1120_11_tail.empty()) continue;
        const Path v1120_11_head{v1120_11_label};
        const Space v1121_2 = singleton(v1120_11_head);
        const Space v1121_3 = intersect(constant_2,v1121_2);
        const Space v1121_4 = (has_head(v1121_3) ? constant_3 : Space{});
        const Space v1121_5 = subtract(constant_1,v1121_4);
        Space v1121_8;
        if (!v1121_5.empty()) {
          const Path v1122_6 = concat_path(v1120_6,v1120_11_head);
          const Space v1122_7 = routine_156(c, v1122_6, p1, v1120_11_tail);
          v1121_8 = compose(v1121_5,v1122_7);
        }
        const Space v1121_9 = intersect(constant_2,v1121_2);
        const Space v1121_10 = (has_head(v1121_9) ? constant_3 : Space{});
        Space v1121_12;
        if (!v1121_10.empty()) {
          const Path v1123_6 = concat_path(v1120_6,v1120_11_head);
          const Space v1123_11 = routine_78(c, v1123_6, p1, v1120_11_tail);
          v1121_12 = compose(v1121_10,v1123_11);
        }
        const Space v1121_13 = unite(v1121_8,v1121_12);
        v1120_11_result = unite(v1120_11_result,v1121_13);
      }
      const Space v1120_11 = std::move(v1120_11_result);
      v1115_12 = compose(v1115_10,v1120_11);
    }
    const Space v1115_13 = unite(v1115_8,v1115_12);
    v1114_12_result = unite(v1114_12_result,v1115_13);
  }
  const Space v1114_12 = std::move(v1114_12_result);
  return v1114_12;
}

static Space routine_121(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1124_9_result;
  for (int v1124_9_label = 1; v1124_9_label <= 2; ++v1124_9_label) {
    const Space v1124_9_tail = child(s0,v1124_9_label);
    if (v1124_9_tail.empty()) continue;
    const Path v1124_9_head{v1124_9_label};
    const Space v1125_2 = singleton(v1124_9_head);
    const Space v1125_3 = intersect(constant_2,v1125_2);
    const Space v1125_4 = (has_head(v1125_3) ? constant_3 : Space{});
    const Space v1125_5 = subtract(constant_1,v1125_4);
    Space v1125_8;
    if (!v1125_5.empty()) {
      const Path v1126_6 = concat_path(p0,v1124_9_head);
      Space v1126_7_result;
      for (int v1126_7_label = 1; v1126_7_label <= 2; ++v1126_7_label) {
        const Space v1126_7_tail = child(v1124_9_tail,v1126_7_label);
        if (v1126_7_tail.empty()) continue;
        const Path v1126_7_head{v1126_7_label};
        const Space v1127_2 = singleton(v1126_7_head);
        const Space v1127_3 = intersect(constant_2,v1127_2);
        const Space v1127_4 = (has_head(v1127_3) ? constant_3 : Space{});
        const Space v1127_5 = subtract(constant_1,v1127_4);
        Space v1127_8;
        if (!v1127_5.empty()) {
          const Path v1128_6 = concat_path(v1126_6,v1126_7_head);
          const Space v1128_7 = routine_156(c, v1128_6, p1, v1126_7_tail);
          v1127_8 = compose(v1127_5,v1128_7);
        }
        const Space v1127_9 = intersect(constant_2,v1127_2);
        const Space v1127_10 = (has_head(v1127_9) ? constant_3 : Space{});
        Space v1127_12;
        if (!v1127_10.empty()) {
          const Path v1129_6 = concat_path(v1126_6,v1126_7_head);
          const Space v1129_11 = routine_157(c, v1129_6, p1, v1126_7_tail);
          v1127_12 = compose(v1127_10,v1129_11);
        }
        const Space v1127_13 = unite(v1127_8,v1127_12);
        v1126_7_result = unite(v1126_7_result,v1127_13);
      }
      const Space v1126_7 = std::move(v1126_7_result);
      v1125_8 = compose(v1125_5,v1126_7);
    }
    const Space v1125_9 = intersect(constant_2,v1125_2);
    const Space v1125_10 = (has_head(v1125_9) ? constant_3 : Space{});
    const Space v1125_11 = compose(v1125_10,v1124_9_tail);
    const Path v1130_6 = concat_path(p0,v1124_9_head);
    const Space v1125_12 = wrap(v1125_11,v1130_6);
    const Space v1125_13 = wrap(v1125_12,p1);
    const Space v1125_14 = unite(v1125_8,v1125_13);
    v1124_9_result = unite(v1124_9_result,v1125_14);
  }
  const Space v1124_9 = std::move(v1124_9_result);
  return v1124_9;
}

static Space routine_122(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1131_7_result;
  for (int v1131_7_label = 1; v1131_7_label <= 2; ++v1131_7_label) {
    const Space v1131_7_tail = child(s0,v1131_7_label);
    if (v1131_7_tail.empty()) continue;
    const Path v1131_7_head{v1131_7_label};
    const Space v1132_2 = singleton(v1131_7_head);
    const Space v1132_3 = intersect(constant_2,v1132_2);
    const Space v1132_4 = (has_head(v1132_3) ? constant_3 : Space{});
    const Space v1132_5 = subtract(constant_1,v1132_4);
    Space v1132_6_result;
    for (int v1132_6_label = 1; v1132_6_label <= 2; ++v1132_6_label) {
      const Space v1132_6_tail = child(v1131_7_tail,v1132_6_label);
      if (v1132_6_tail.empty()) continue;
      const Path v1132_6_head{v1132_6_label};
      const Space v1133_2 = Space{};
      v1132_6_result = unite(v1132_6_result,v1133_2);
    }
    const Space v1132_6 = std::move(v1132_6_result);
    const Space v1132_7 = compose(v1132_5,v1132_6);
    const Space v1132_8 = intersect(constant_2,v1132_2);
    const Space v1132_9 = (has_head(v1132_8) ? constant_3 : Space{});
    Space v1132_12;
    if (!v1132_9.empty()) {
      const Path v1134_10 = concat_path(p0,v1131_7_head);
      Space v1134_11_result;
      for (int v1134_11_label = 1; v1134_11_label <= 2; ++v1134_11_label) {
        const Space v1134_11_tail = child(v1131_7_tail,v1134_11_label);
        if (v1134_11_tail.empty()) continue;
        const Path v1134_11_head{v1134_11_label};
        const Space v1135_2 = singleton(v1134_11_head);
        const Space v1135_3 = intersect(constant_2,v1135_2);
        const Space v1135_4 = (has_head(v1135_3) ? constant_3 : Space{});
        Space v1135_7;
        if (!v1135_4.empty()) {
          const Path v1136_5 = concat_path(v1134_10,v1134_11_head);
          const Space v1136_6 = routine_12(c, v1136_5, v1134_11_tail, s1);
          v1135_7 = compose(v1135_4,v1136_6);
        }
        v1134_11_result = unite(v1134_11_result,v1135_7);
      }
      const Space v1134_11 = std::move(v1134_11_result);
      v1132_12 = compose(v1132_9,v1134_11);
    }
    const Space v1132_13 = unite(v1132_7,v1132_12);
    v1131_7_result = unite(v1131_7_result,v1132_13);
  }
  const Space v1131_7 = std::move(v1131_7_result);
  return v1131_7;
}

static Space routine_123(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1137_9_result;
  for (int v1137_9_label = 1; v1137_9_label <= 2; ++v1137_9_label) {
    const Space v1137_9_tail = child(s0,v1137_9_label);
    if (v1137_9_tail.empty()) continue;
    const Path v1137_9_head{v1137_9_label};
    const Space v1138_2 = singleton(v1137_9_head);
    const Space v1138_3 = intersect(constant_2,v1138_2);
    const Space v1138_4 = (has_head(v1138_3) ? constant_3 : Space{});
    const Space v1138_5 = subtract(constant_1,v1138_4);
    Space v1138_6_result;
    for (int v1138_6_label = 1; v1138_6_label <= 2; ++v1138_6_label) {
      const Space v1138_6_tail = child(v1137_9_tail,v1138_6_label);
      if (v1138_6_tail.empty()) continue;
      const Path v1138_6_head{v1138_6_label};
      const Space v1139_2 = Space{};
      v1138_6_result = unite(v1138_6_result,v1139_2);
    }
    const Space v1138_6 = std::move(v1138_6_result);
    const Space v1138_7 = compose(v1138_5,v1138_6);
    const Space v1138_8 = intersect(constant_2,v1138_2);
    const Space v1138_9 = (has_head(v1138_8) ? constant_3 : Space{});
    Space v1138_12;
    if (!v1138_9.empty()) {
      const Path v1140_10 = concat_path(p0,v1137_9_head);
      Space v1140_11_result;
      for (int v1140_11_label = 1; v1140_11_label <= 2; ++v1140_11_label) {
        const Space v1140_11_tail = child(v1137_9_tail,v1140_11_label);
        if (v1140_11_tail.empty()) continue;
        const Path v1140_11_head{v1140_11_label};
        const Space v1141_2 = singleton(v1140_11_head);
        const Space v1141_3 = intersect(constant_2,v1141_2);
        const Space v1141_4 = (has_head(v1141_3) ? constant_3 : Space{});
        const Space v1141_5 = subtract(constant_1,v1141_4);
        Space v1141_7;
        if (!v1141_5.empty()) {
          const Space v1142_6 = routine_39(c, v1140_11_head, v1140_10, v1140_11_tail, s1);
          v1141_7 = compose(v1141_5,v1142_6);
        }
        const Space v1141_8 = intersect(constant_2,v1141_2);
        const Space v1141_9 = (has_head(v1141_8) ? constant_3 : Space{});
        Space v1141_11;
        if (!v1141_9.empty()) {
          const Space v1143_10 = routine_40(c, v1140_11_head, v1140_10, v1140_11_tail, s1);
          v1141_11 = compose(v1141_9,v1143_10);
        }
        const Space v1141_12 = unite(v1141_7,v1141_11);
        v1140_11_result = unite(v1140_11_result,v1141_12);
      }
      const Space v1140_11 = std::move(v1140_11_result);
      v1138_12 = compose(v1138_9,v1140_11);
    }
    const Space v1138_13 = unite(v1138_7,v1138_12);
    v1137_9_result = unite(v1137_9_result,v1138_13);
  }
  const Space v1137_9 = std::move(v1137_9_result);
  return v1137_9;
}

static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1144_13_result;
  for (int v1144_13_label = 1; v1144_13_label <= 2; ++v1144_13_label) {
    const Space v1144_13_tail = child(s0,v1144_13_label);
    if (v1144_13_tail.empty()) continue;
    const Path v1144_13_head{v1144_13_label};
    const Space v1145_2 = singleton(v1144_13_head);
    const Space v1145_3 = intersect(constant_2,v1145_2);
    const Space v1145_4 = (has_head(v1145_3) ? constant_3 : Space{});
    const Space v1145_5 = subtract(constant_1,v1145_4);
    Space v1145_8;
    if (!v1145_5.empty()) {
      const Path v1146_6 = concat_path(p0,v1144_13_head);
      Space v1146_7_result;
      for (int v1146_7_label = 1; v1146_7_label <= 2; ++v1146_7_label) {
        const Space v1146_7_tail = child(v1144_13_tail,v1146_7_label);
        if (v1146_7_tail.empty()) continue;
        const Path v1146_7_head{v1146_7_label};
        const Space v1147_2 = singleton(v1146_7_head);
        const Space v1147_3 = intersect(constant_2,v1147_2);
        const Space v1147_4 = (has_head(v1147_3) ? constant_3 : Space{});
        const Space v1147_5 = subtract(constant_1,v1147_4);
        Space v1147_8;
        if (!v1147_5.empty()) {
          const Path v1148_6 = concat_path(v1146_6,v1146_7_head);
          const Space v1148_7 = routine_158(c, v1148_6, p1, v1146_7_tail, s1);
          v1147_8 = compose(v1147_5,v1148_7);
        }
        const Space v1147_9 = intersect(constant_2,v1147_2);
        const Space v1147_10 = (has_head(v1147_9) ? constant_3 : Space{});
        Space v1147_12;
        if (!v1147_10.empty()) {
          const Path v1149_6 = concat_path(v1146_6,v1146_7_head);
          const Space v1149_11 = routine_159(c, v1149_6, p1, v1146_7_tail, s1);
          v1147_12 = compose(v1147_10,v1149_11);
        }
        const Space v1147_13 = unite(v1147_8,v1147_12);
        v1146_7_result = unite(v1146_7_result,v1147_13);
      }
      const Space v1146_7 = std::move(v1146_7_result);
      v1145_8 = compose(v1145_5,v1146_7);
    }
    const Space v1145_9 = intersect(constant_2,v1145_2);
    const Space v1145_10 = (has_head(v1145_9) ? constant_3 : Space{});
    Space v1145_12;
    if (!v1145_10.empty()) {
      const Path v1150_6 = concat_path(p0,v1144_13_head);
      Space v1150_11_result;
      for (int v1150_11_label = 1; v1150_11_label <= 2; ++v1150_11_label) {
        const Space v1150_11_tail = child(v1144_13_tail,v1150_11_label);
        if (v1150_11_tail.empty()) continue;
        const Path v1150_11_head{v1150_11_label};
        const Space v1151_2 = singleton(v1150_11_head);
        const Space v1151_3 = intersect(constant_2,v1151_2);
        const Space v1151_4 = (has_head(v1151_3) ? constant_3 : Space{});
        const Space v1151_5 = subtract(constant_1,v1151_4);
        Space v1151_8;
        if (!v1151_5.empty()) {
          const Path v1152_6 = concat_path(v1150_6,v1150_11_head);
          const Space v1152_7 = routine_158(c, v1152_6, p1, v1150_11_tail, s1);
          v1151_8 = compose(v1151_5,v1152_7);
        }
        const Space v1151_9 = intersect(constant_2,v1151_2);
        const Space v1151_10 = (has_head(v1151_9) ? constant_3 : Space{});
        Space v1151_12;
        if (!v1151_10.empty()) {
          const Path v1153_6 = concat_path(v1150_6,v1150_11_head);
          const Space v1153_11 = routine_43(c, v1153_6, p1, v1150_11_tail, s1);
          v1151_12 = compose(v1151_10,v1153_11);
        }
        const Space v1151_13 = unite(v1151_8,v1151_12);
        v1150_11_result = unite(v1150_11_result,v1151_13);
      }
      const Space v1150_11 = std::move(v1150_11_result);
      v1145_12 = compose(v1145_10,v1150_11);
    }
    const Space v1145_13 = unite(v1145_8,v1145_12);
    v1144_13_result = unite(v1144_13_result,v1145_13);
  }
  const Space v1144_13 = std::move(v1144_13_result);
  return v1144_13;
}

static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1154_8 = unwrap(s1,constant_4);
  const Space v1154_10 = unwrap(v1154_8,constant_6);
  const Space v1154_11 = unwrap(v1154_10,p0);
  Space v1154_18_result;
  for (int v1154_18_label = 1; v1154_18_label <= 2; ++v1154_18_label) {
    const Space v1154_18_tail = child(s0,v1154_18_label);
    if (v1154_18_tail.empty()) continue;
    const Path v1154_18_head{v1154_18_label};
    const Space v1155_2 = singleton(v1154_18_head);
    const Space v1155_3 = intersect(constant_2,v1155_2);
    const Space v1155_4 = (has_head(v1155_3) ? constant_3 : Space{});
    const Space v1155_5 = subtract(constant_1,v1155_4);
    Space v1155_8;
    if (!v1155_5.empty()) {
      const Path v1156_6 = concat_path(p0,v1154_18_head);
      Space v1156_7_result;
      for (int v1156_7_label = 1; v1156_7_label <= 2; ++v1156_7_label) {
        const Space v1156_7_tail = child(v1154_18_tail,v1156_7_label);
        if (v1156_7_tail.empty()) continue;
        const Path v1156_7_head{v1156_7_label};
        const Space v1157_2 = singleton(v1156_7_head);
        const Space v1157_3 = intersect(constant_2,v1157_2);
        const Space v1157_4 = (has_head(v1157_3) ? constant_3 : Space{});
        const Space v1157_5 = subtract(constant_1,v1157_4);
        Space v1157_8;
        if (!v1157_5.empty()) {
          const Path v1158_6 = concat_path(v1156_6,v1156_7_head);
          const Space v1158_7 = routine_158(c, v1158_6, p1, v1156_7_tail, s1);
          v1157_8 = compose(v1157_5,v1158_7);
        }
        const Space v1157_9 = intersect(constant_2,v1157_2);
        const Space v1157_10 = (has_head(v1157_9) ? constant_3 : Space{});
        Space v1157_12;
        if (!v1157_10.empty()) {
          const Path v1159_6 = concat_path(v1156_6,v1156_7_head);
          const Space v1159_11 = routine_159(c, v1159_6, p1, v1156_7_tail, s1);
          v1157_12 = compose(v1157_10,v1159_11);
        }
        const Space v1157_13 = unite(v1157_8,v1157_12);
        v1156_7_result = unite(v1156_7_result,v1157_13);
      }
      const Space v1156_7 = std::move(v1156_7_result);
      v1155_8 = compose(v1155_5,v1156_7);
    }
    const Space v1155_9 = intersect(constant_2,v1155_2);
    const Space v1155_10 = (has_head(v1155_9) ? constant_3 : Space{});
    Space v1155_13;
    if (!v1155_10.empty()) {
      const Space v1160_11 = unwrap(v1154_11,v1154_18_head);
      Space v1160_12_result;
      for (int v1160_12_label = 1; v1160_12_label <= 2; ++v1160_12_label) {
        const Space v1160_12_tail = child(v1160_11,v1160_12_label);
        if (v1160_12_tail.empty()) continue;
        const Path v1160_12_head{v1160_12_label};
        const Space v1161_2 = singleton(v1160_12_head);
        const Space v1161_3 = intersect(constant_2,v1161_2);
        const Space v1161_4 = (has_head(v1161_3) ? constant_3 : Space{});
        const Space v1161_5 = subtract(constant_1,v1161_4);
        Space v1161_7;
        if (!v1161_5.empty()) {
          const Space v1162_6 = routine_83(c, v1160_12_head, p1, v1160_12_tail);
          v1161_7 = compose(v1161_5,v1162_6);
        }
        const Space v1161_8 = intersect(constant_2,v1161_2);
        const Space v1161_9 = (has_head(v1161_8) ? constant_3 : Space{});
        Space v1161_11;
        if (!v1161_9.empty()) {
          const Space v1163_10 = routine_84(c, v1160_12_head, p1, v1160_12_tail);
          v1161_11 = compose(v1161_9,v1163_10);
        }
        const Space v1161_12 = unite(v1161_7,v1161_11);
        v1160_12_result = unite(v1160_12_result,v1161_12);
      }
      const Space v1160_12 = std::move(v1160_12_result);
      v1155_13 = compose(v1155_10,v1160_12);
    }
    const Space v1155_14 = unite(v1155_8,v1155_13);
    v1154_18_result = unite(v1154_18_result,v1155_14);
  }
  const Space v1154_18 = std::move(v1154_18_result);
  return v1154_18;
}

static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1164_12_result;
  for (int v1164_12_label = 1; v1164_12_label <= 2; ++v1164_12_label) {
    const Space v1164_12_tail = child(s0,v1164_12_label);
    if (v1164_12_tail.empty()) continue;
    const Path v1164_12_head{v1164_12_label};
    const Space v1165_2 = singleton(v1164_12_head);
    const Space v1165_3 = intersect(constant_2,v1165_2);
    const Space v1165_4 = (has_head(v1165_3) ? constant_3 : Space{});
    const Space v1165_5 = subtract(constant_1,v1165_4);
    Space v1165_8;
    if (!v1165_5.empty()) {
      const Path v1166_6 = concat_path(p0,v1164_12_head);
      Space v1166_7_result;
      for (int v1166_7_label = 1; v1166_7_label <= 2; ++v1166_7_label) {
        const Space v1166_7_tail = child(v1164_12_tail,v1166_7_label);
        if (v1166_7_tail.empty()) continue;
        const Path v1166_7_head{v1166_7_label};
        const Space v1167_2 = singleton(v1166_7_head);
        const Space v1167_3 = intersect(constant_2,v1167_2);
        const Space v1167_4 = (has_head(v1167_3) ? constant_3 : Space{});
        const Space v1167_5 = subtract(constant_1,v1167_4);
        Space v1167_8;
        if (!v1167_5.empty()) {
          const Path v1168_6 = concat_path(v1166_6,v1166_7_head);
          const Space v1168_7 = routine_160(c, v1168_6, p1, v1166_7_tail);
          v1167_8 = compose(v1167_5,v1168_7);
        }
        const Space v1167_9 = intersect(constant_2,v1167_2);
        const Space v1167_10 = (has_head(v1167_9) ? constant_3 : Space{});
        Space v1167_12;
        if (!v1167_10.empty()) {
          const Path v1169_6 = concat_path(v1166_6,v1166_7_head);
          const Space v1169_11 = routine_161(c, v1169_6, p1, v1166_7_tail);
          v1167_12 = compose(v1167_10,v1169_11);
        }
        const Space v1167_13 = unite(v1167_8,v1167_12);
        v1166_7_result = unite(v1166_7_result,v1167_13);
      }
      const Space v1166_7 = std::move(v1166_7_result);
      v1165_8 = compose(v1165_5,v1166_7);
    }
    const Space v1165_9 = intersect(constant_2,v1165_2);
    const Space v1165_10 = (has_head(v1165_9) ? constant_3 : Space{});
    Space v1165_12;
    if (!v1165_10.empty()) {
      const Path v1170_6 = concat_path(p0,v1164_12_head);
      Space v1170_11_result;
      for (int v1170_11_label = 1; v1170_11_label <= 2; ++v1170_11_label) {
        const Space v1170_11_tail = child(v1164_12_tail,v1170_11_label);
        if (v1170_11_tail.empty()) continue;
        const Path v1170_11_head{v1170_11_label};
        const Space v1171_2 = singleton(v1170_11_head);
        const Space v1171_3 = intersect(constant_2,v1171_2);
        const Space v1171_4 = (has_head(v1171_3) ? constant_3 : Space{});
        const Space v1171_5 = subtract(constant_1,v1171_4);
        Space v1171_8;
        if (!v1171_5.empty()) {
          const Path v1172_6 = concat_path(v1170_6,v1170_11_head);
          const Space v1172_7 = routine_160(c, v1172_6, p1, v1170_11_tail);
          v1171_8 = compose(v1171_5,v1172_7);
        }
        const Space v1171_9 = intersect(constant_2,v1171_2);
        const Space v1171_10 = (has_head(v1171_9) ? constant_3 : Space{});
        Space v1171_12;
        if (!v1171_10.empty()) {
          const Path v1173_6 = concat_path(v1170_6,v1170_11_head);
          const Space v1173_11 = routine_89(c, v1173_6, p1, v1170_11_tail);
          v1171_12 = compose(v1171_10,v1173_11);
        }
        const Space v1171_13 = unite(v1171_8,v1171_12);
        v1170_11_result = unite(v1170_11_result,v1171_13);
      }
      const Space v1170_11 = std::move(v1170_11_result);
      v1165_12 = compose(v1165_10,v1170_11);
    }
    const Space v1165_13 = unite(v1165_8,v1165_12);
    v1164_12_result = unite(v1164_12_result,v1165_13);
  }
  const Space v1164_12 = std::move(v1164_12_result);
  return v1164_12;
}

static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1174_9_result;
  for (int v1174_9_label = 1; v1174_9_label <= 2; ++v1174_9_label) {
    const Space v1174_9_tail = child(s0,v1174_9_label);
    if (v1174_9_tail.empty()) continue;
    const Path v1174_9_head{v1174_9_label};
    const Space v1175_2 = singleton(v1174_9_head);
    const Space v1175_3 = intersect(constant_2,v1175_2);
    const Space v1175_4 = (has_head(v1175_3) ? constant_3 : Space{});
    const Space v1175_5 = subtract(constant_1,v1175_4);
    Space v1175_8;
    if (!v1175_5.empty()) {
      const Path v1176_6 = concat_path(p0,v1174_9_head);
      Space v1176_7_result;
      for (int v1176_7_label = 1; v1176_7_label <= 2; ++v1176_7_label) {
        const Space v1176_7_tail = child(v1174_9_tail,v1176_7_label);
        if (v1176_7_tail.empty()) continue;
        const Path v1176_7_head{v1176_7_label};
        const Space v1177_2 = singleton(v1176_7_head);
        const Space v1177_3 = intersect(constant_2,v1177_2);
        const Space v1177_4 = (has_head(v1177_3) ? constant_3 : Space{});
        const Space v1177_5 = subtract(constant_1,v1177_4);
        Space v1177_8;
        if (!v1177_5.empty()) {
          const Path v1178_6 = concat_path(v1176_6,v1176_7_head);
          const Space v1178_7 = routine_160(c, v1178_6, p1, v1176_7_tail);
          v1177_8 = compose(v1177_5,v1178_7);
        }
        const Space v1177_9 = intersect(constant_2,v1177_2);
        const Space v1177_10 = (has_head(v1177_9) ? constant_3 : Space{});
        Space v1177_12;
        if (!v1177_10.empty()) {
          const Path v1179_6 = concat_path(v1176_6,v1176_7_head);
          const Space v1179_11 = routine_161(c, v1179_6, p1, v1176_7_tail);
          v1177_12 = compose(v1177_10,v1179_11);
        }
        const Space v1177_13 = unite(v1177_8,v1177_12);
        v1176_7_result = unite(v1176_7_result,v1177_13);
      }
      const Space v1176_7 = std::move(v1176_7_result);
      v1175_8 = compose(v1175_5,v1176_7);
    }
    const Space v1175_9 = intersect(constant_2,v1175_2);
    const Space v1175_10 = (has_head(v1175_9) ? constant_3 : Space{});
    const Space v1175_11 = compose(v1175_10,v1174_9_tail);
    const Path v1180_6 = concat_path(p0,v1174_9_head);
    const Space v1175_12 = wrap(v1175_11,v1180_6);
    const Space v1175_13 = wrap(v1175_12,p1);
    const Space v1175_14 = unite(v1175_8,v1175_13);
    v1174_9_result = unite(v1174_9_result,v1175_14);
  }
  const Space v1174_9 = std::move(v1174_9_result);
  return v1174_9;
}

static Space routine_128(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1181_13_result;
  for (int v1181_13_label = 1; v1181_13_label <= 2; ++v1181_13_label) {
    const Space v1181_13_tail = child(s0,v1181_13_label);
    if (v1181_13_tail.empty()) continue;
    const Path v1181_13_head{v1181_13_label};
    const Space v1182_2 = singleton(v1181_13_head);
    const Space v1182_3 = intersect(constant_2,v1182_2);
    const Space v1182_4 = (has_head(v1182_3) ? constant_3 : Space{});
    const Space v1182_5 = subtract(constant_1,v1182_4);
    Space v1182_8;
    if (!v1182_5.empty()) {
      const Path v1183_6 = concat_path(p0,v1181_13_head);
      Space v1183_7_result;
      for (int v1183_7_label = 1; v1183_7_label <= 2; ++v1183_7_label) {
        const Space v1183_7_tail = child(v1181_13_tail,v1183_7_label);
        if (v1183_7_tail.empty()) continue;
        const Path v1183_7_head{v1183_7_label};
        const Space v1184_2 = singleton(v1183_7_head);
        const Space v1184_3 = intersect(constant_2,v1184_2);
        const Space v1184_4 = (has_head(v1184_3) ? constant_3 : Space{});
        const Space v1184_5 = subtract(constant_1,v1184_4);
        Space v1184_8;
        if (!v1184_5.empty()) {
          const Path v1185_6 = concat_path(v1183_6,v1183_7_head);
          const Space v1185_7 = routine_162(c, v1185_6, p1, v1183_7_tail, s1);
          v1184_8 = compose(v1184_5,v1185_7);
        }
        const Space v1184_9 = intersect(constant_2,v1184_2);
        const Space v1184_10 = (has_head(v1184_9) ? constant_3 : Space{});
        Space v1184_12;
        if (!v1184_10.empty()) {
          const Path v1186_6 = concat_path(v1183_6,v1183_7_head);
          const Space v1186_11 = routine_163(c, v1186_6, p1, v1183_7_tail, s1);
          v1184_12 = compose(v1184_10,v1186_11);
        }
        const Space v1184_13 = unite(v1184_8,v1184_12);
        v1183_7_result = unite(v1183_7_result,v1184_13);
      }
      const Space v1183_7 = std::move(v1183_7_result);
      v1182_8 = compose(v1182_5,v1183_7);
    }
    const Space v1182_9 = intersect(constant_2,v1182_2);
    const Space v1182_10 = (has_head(v1182_9) ? constant_3 : Space{});
    Space v1182_12;
    if (!v1182_10.empty()) {
      const Path v1187_6 = concat_path(p0,v1181_13_head);
      Space v1187_11_result;
      for (int v1187_11_label = 1; v1187_11_label <= 2; ++v1187_11_label) {
        const Space v1187_11_tail = child(v1181_13_tail,v1187_11_label);
        if (v1187_11_tail.empty()) continue;
        const Path v1187_11_head{v1187_11_label};
        const Space v1188_2 = singleton(v1187_11_head);
        const Space v1188_3 = intersect(constant_2,v1188_2);
        const Space v1188_4 = (has_head(v1188_3) ? constant_3 : Space{});
        const Space v1188_5 = subtract(constant_1,v1188_4);
        Space v1188_8;
        if (!v1188_5.empty()) {
          const Path v1189_6 = concat_path(v1187_6,v1187_11_head);
          const Space v1189_7 = routine_162(c, v1189_6, p1, v1187_11_tail, s1);
          v1188_8 = compose(v1188_5,v1189_7);
        }
        const Space v1188_9 = intersect(constant_2,v1188_2);
        const Space v1188_10 = (has_head(v1188_9) ? constant_3 : Space{});
        Space v1188_12;
        if (!v1188_10.empty()) {
          const Path v1190_6 = concat_path(v1187_6,v1187_11_head);
          const Space v1190_11 = routine_43(c, v1190_6, p1, v1187_11_tail, s1);
          v1188_12 = compose(v1188_10,v1190_11);
        }
        const Space v1188_13 = unite(v1188_8,v1188_12);
        v1187_11_result = unite(v1187_11_result,v1188_13);
      }
      const Space v1187_11 = std::move(v1187_11_result);
      v1182_12 = compose(v1182_10,v1187_11);
    }
    const Space v1182_13 = unite(v1182_8,v1182_12);
    v1181_13_result = unite(v1181_13_result,v1182_13);
  }
  const Space v1181_13 = std::move(v1181_13_result);
  return v1181_13;
}

static Space routine_129(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1191_8 = unwrap(s1,constant_4);
  const Space v1191_10 = unwrap(v1191_8,constant_6);
  const Space v1191_11 = unwrap(v1191_10,p0);
  Space v1191_18_result;
  for (int v1191_18_label = 1; v1191_18_label <= 2; ++v1191_18_label) {
    const Space v1191_18_tail = child(s0,v1191_18_label);
    if (v1191_18_tail.empty()) continue;
    const Path v1191_18_head{v1191_18_label};
    const Space v1192_2 = singleton(v1191_18_head);
    const Space v1192_3 = intersect(constant_2,v1192_2);
    const Space v1192_4 = (has_head(v1192_3) ? constant_3 : Space{});
    const Space v1192_5 = subtract(constant_1,v1192_4);
    Space v1192_8;
    if (!v1192_5.empty()) {
      const Path v1193_6 = concat_path(p0,v1191_18_head);
      Space v1193_7_result;
      for (int v1193_7_label = 1; v1193_7_label <= 2; ++v1193_7_label) {
        const Space v1193_7_tail = child(v1191_18_tail,v1193_7_label);
        if (v1193_7_tail.empty()) continue;
        const Path v1193_7_head{v1193_7_label};
        const Space v1194_2 = singleton(v1193_7_head);
        const Space v1194_3 = intersect(constant_2,v1194_2);
        const Space v1194_4 = (has_head(v1194_3) ? constant_3 : Space{});
        const Space v1194_5 = subtract(constant_1,v1194_4);
        Space v1194_8;
        if (!v1194_5.empty()) {
          const Path v1195_6 = concat_path(v1193_6,v1193_7_head);
          const Space v1195_7 = routine_162(c, v1195_6, p1, v1193_7_tail, s1);
          v1194_8 = compose(v1194_5,v1195_7);
        }
        const Space v1194_9 = intersect(constant_2,v1194_2);
        const Space v1194_10 = (has_head(v1194_9) ? constant_3 : Space{});
        Space v1194_12;
        if (!v1194_10.empty()) {
          const Path v1196_6 = concat_path(v1193_6,v1193_7_head);
          const Space v1196_11 = routine_163(c, v1196_6, p1, v1193_7_tail, s1);
          v1194_12 = compose(v1194_10,v1196_11);
        }
        const Space v1194_13 = unite(v1194_8,v1194_12);
        v1193_7_result = unite(v1193_7_result,v1194_13);
      }
      const Space v1193_7 = std::move(v1193_7_result);
      v1192_8 = compose(v1192_5,v1193_7);
    }
    const Space v1192_9 = intersect(constant_2,v1192_2);
    const Space v1192_10 = (has_head(v1192_9) ? constant_3 : Space{});
    Space v1192_13;
    if (!v1192_10.empty()) {
      const Space v1197_11 = unwrap(v1191_11,v1191_18_head);
      Space v1197_12_result;
      for (int v1197_12_label = 1; v1197_12_label <= 2; ++v1197_12_label) {
        const Space v1197_12_tail = child(v1197_11,v1197_12_label);
        if (v1197_12_tail.empty()) continue;
        const Path v1197_12_head{v1197_12_label};
        const Space v1198_2 = singleton(v1197_12_head);
        const Space v1198_3 = intersect(constant_2,v1198_2);
        const Space v1198_4 = (has_head(v1198_3) ? constant_3 : Space{});
        const Space v1198_5 = subtract(constant_1,v1198_4);
        Space v1198_7;
        if (!v1198_5.empty()) {
          const Space v1199_6 = routine_83(c, v1197_12_head, p1, v1197_12_tail);
          v1198_7 = compose(v1198_5,v1199_6);
        }
        const Space v1198_8 = intersect(constant_2,v1198_2);
        const Space v1198_9 = (has_head(v1198_8) ? constant_3 : Space{});
        Space v1198_11;
        if (!v1198_9.empty()) {
          const Space v1200_10 = routine_84(c, v1197_12_head, p1, v1197_12_tail);
          v1198_11 = compose(v1198_9,v1200_10);
        }
        const Space v1198_12 = unite(v1198_7,v1198_11);
        v1197_12_result = unite(v1197_12_result,v1198_12);
      }
      const Space v1197_12 = std::move(v1197_12_result);
      v1192_13 = compose(v1192_10,v1197_12);
    }
    const Space v1192_14 = unite(v1192_8,v1192_13);
    v1191_18_result = unite(v1191_18_result,v1192_14);
  }
  const Space v1191_18 = std::move(v1191_18_result);
  return v1191_18;
}

static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1201_12_result;
  for (int v1201_12_label = 1; v1201_12_label <= 2; ++v1201_12_label) {
    const Space v1201_12_tail = child(s0,v1201_12_label);
    if (v1201_12_tail.empty()) continue;
    const Path v1201_12_head{v1201_12_label};
    const Space v1202_2 = singleton(v1201_12_head);
    const Space v1202_3 = intersect(constant_2,v1202_2);
    const Space v1202_4 = (has_head(v1202_3) ? constant_3 : Space{});
    const Space v1202_5 = subtract(constant_1,v1202_4);
    Space v1202_8;
    if (!v1202_5.empty()) {
      const Path v1203_6 = concat_path(p0,v1201_12_head);
      Space v1203_7_result;
      for (int v1203_7_label = 1; v1203_7_label <= 2; ++v1203_7_label) {
        const Space v1203_7_tail = child(v1201_12_tail,v1203_7_label);
        if (v1203_7_tail.empty()) continue;
        const Path v1203_7_head{v1203_7_label};
        const Space v1204_2 = singleton(v1203_7_head);
        const Space v1204_3 = intersect(constant_2,v1204_2);
        const Space v1204_4 = (has_head(v1204_3) ? constant_3 : Space{});
        const Space v1204_5 = subtract(constant_1,v1204_4);
        Space v1204_8;
        if (!v1204_5.empty()) {
          const Path v1205_6 = concat_path(v1203_6,v1203_7_head);
          const Space v1205_7 = routine_164(c, v1205_6, p1, v1203_7_tail);
          v1204_8 = compose(v1204_5,v1205_7);
        }
        const Space v1204_9 = intersect(constant_2,v1204_2);
        const Space v1204_10 = (has_head(v1204_9) ? constant_3 : Space{});
        Space v1204_12;
        if (!v1204_10.empty()) {
          const Path v1206_6 = concat_path(v1203_6,v1203_7_head);
          const Space v1206_11 = routine_165(c, v1206_6, p1, v1203_7_tail);
          v1204_12 = compose(v1204_10,v1206_11);
        }
        const Space v1204_13 = unite(v1204_8,v1204_12);
        v1203_7_result = unite(v1203_7_result,v1204_13);
      }
      const Space v1203_7 = std::move(v1203_7_result);
      v1202_8 = compose(v1202_5,v1203_7);
    }
    const Space v1202_9 = intersect(constant_2,v1202_2);
    const Space v1202_10 = (has_head(v1202_9) ? constant_3 : Space{});
    Space v1202_12;
    if (!v1202_10.empty()) {
      const Path v1207_6 = concat_path(p0,v1201_12_head);
      Space v1207_11_result;
      for (int v1207_11_label = 1; v1207_11_label <= 2; ++v1207_11_label) {
        const Space v1207_11_tail = child(v1201_12_tail,v1207_11_label);
        if (v1207_11_tail.empty()) continue;
        const Path v1207_11_head{v1207_11_label};
        const Space v1208_2 = singleton(v1207_11_head);
        const Space v1208_3 = intersect(constant_2,v1208_2);
        const Space v1208_4 = (has_head(v1208_3) ? constant_3 : Space{});
        const Space v1208_5 = subtract(constant_1,v1208_4);
        Space v1208_8;
        if (!v1208_5.empty()) {
          const Path v1209_6 = concat_path(v1207_6,v1207_11_head);
          const Space v1209_7 = routine_164(c, v1209_6, p1, v1207_11_tail);
          v1208_8 = compose(v1208_5,v1209_7);
        }
        const Space v1208_9 = intersect(constant_2,v1208_2);
        const Space v1208_10 = (has_head(v1208_9) ? constant_3 : Space{});
        Space v1208_12;
        if (!v1208_10.empty()) {
          const Path v1210_6 = concat_path(v1207_6,v1207_11_head);
          const Space v1210_11 = routine_89(c, v1210_6, p1, v1207_11_tail);
          v1208_12 = compose(v1208_10,v1210_11);
        }
        const Space v1208_13 = unite(v1208_8,v1208_12);
        v1207_11_result = unite(v1207_11_result,v1208_13);
      }
      const Space v1207_11 = std::move(v1207_11_result);
      v1202_12 = compose(v1202_10,v1207_11);
    }
    const Space v1202_13 = unite(v1202_8,v1202_12);
    v1201_12_result = unite(v1201_12_result,v1202_13);
  }
  const Space v1201_12 = std::move(v1201_12_result);
  return v1201_12;
}

static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1211_9_result;
  for (int v1211_9_label = 1; v1211_9_label <= 2; ++v1211_9_label) {
    const Space v1211_9_tail = child(s0,v1211_9_label);
    if (v1211_9_tail.empty()) continue;
    const Path v1211_9_head{v1211_9_label};
    const Space v1212_2 = singleton(v1211_9_head);
    const Space v1212_3 = intersect(constant_2,v1212_2);
    const Space v1212_4 = (has_head(v1212_3) ? constant_3 : Space{});
    const Space v1212_5 = subtract(constant_1,v1212_4);
    Space v1212_8;
    if (!v1212_5.empty()) {
      const Path v1213_6 = concat_path(p0,v1211_9_head);
      Space v1213_7_result;
      for (int v1213_7_label = 1; v1213_7_label <= 2; ++v1213_7_label) {
        const Space v1213_7_tail = child(v1211_9_tail,v1213_7_label);
        if (v1213_7_tail.empty()) continue;
        const Path v1213_7_head{v1213_7_label};
        const Space v1214_2 = singleton(v1213_7_head);
        const Space v1214_3 = intersect(constant_2,v1214_2);
        const Space v1214_4 = (has_head(v1214_3) ? constant_3 : Space{});
        const Space v1214_5 = subtract(constant_1,v1214_4);
        Space v1214_8;
        if (!v1214_5.empty()) {
          const Path v1215_6 = concat_path(v1213_6,v1213_7_head);
          const Space v1215_7 = routine_164(c, v1215_6, p1, v1213_7_tail);
          v1214_8 = compose(v1214_5,v1215_7);
        }
        const Space v1214_9 = intersect(constant_2,v1214_2);
        const Space v1214_10 = (has_head(v1214_9) ? constant_3 : Space{});
        Space v1214_12;
        if (!v1214_10.empty()) {
          const Path v1216_6 = concat_path(v1213_6,v1213_7_head);
          const Space v1216_11 = routine_165(c, v1216_6, p1, v1213_7_tail);
          v1214_12 = compose(v1214_10,v1216_11);
        }
        const Space v1214_13 = unite(v1214_8,v1214_12);
        v1213_7_result = unite(v1213_7_result,v1214_13);
      }
      const Space v1213_7 = std::move(v1213_7_result);
      v1212_8 = compose(v1212_5,v1213_7);
    }
    const Space v1212_9 = intersect(constant_2,v1212_2);
    const Space v1212_10 = (has_head(v1212_9) ? constant_3 : Space{});
    const Space v1212_11 = compose(v1212_10,v1211_9_tail);
    const Path v1217_6 = concat_path(p0,v1211_9_head);
    const Space v1212_12 = wrap(v1212_11,v1217_6);
    const Space v1212_13 = wrap(v1212_12,p1);
    const Space v1212_14 = unite(v1212_8,v1212_13);
    v1211_9_result = unite(v1211_9_result,v1212_14);
  }
  const Space v1211_9 = std::move(v1211_9_result);
  return v1211_9;
}

static Space routine_132(Context& c, const Path& p0, const Space& s0) {
  Space v1218_6_result;
  for (int v1218_6_label = 1; v1218_6_label <= 2; ++v1218_6_label) {
    const Space v1218_6_tail = child(s0,v1218_6_label);
    if (v1218_6_tail.empty()) continue;
    const Path v1218_6_head{v1218_6_label};
    const Space v1219_2 = singleton(v1218_6_head);
    const Space v1219_3 = intersect(constant_2,v1219_2);
    const Space v1219_4 = (has_head(v1219_3) ? constant_3 : Space{});
    const Space v1219_5 = subtract(constant_1,v1219_4);
    Space v1219_6_result;
    for (int v1219_6_label = 1; v1219_6_label <= 2; ++v1219_6_label) {
      const Space v1219_6_tail = child(v1218_6_tail,v1219_6_label);
      if (v1219_6_tail.empty()) continue;
      const Path v1219_6_head{v1219_6_label};
      const Space v1220_2 = Space{};
      v1219_6_result = unite(v1219_6_result,v1220_2);
    }
    const Space v1219_6 = std::move(v1219_6_result);
    const Space v1219_7 = compose(v1219_5,v1219_6);
    const Space v1219_8 = intersect(constant_2,v1219_2);
    const Space v1219_9 = (has_head(v1219_8) ? constant_3 : Space{});
    Space v1219_12;
    if (!v1219_9.empty()) {
      const Path v1221_10 = concat_path(p0,v1218_6_head);
      Space v1221_11_result;
      for (int v1221_11_label = 1; v1221_11_label <= 2; ++v1221_11_label) {
        const Space v1221_11_tail = child(v1218_6_tail,v1221_11_label);
        if (v1221_11_tail.empty()) continue;
        const Path v1221_11_head{v1221_11_label};
        const Space v1222_2 = singleton(v1221_11_head);
        const Space v1222_3 = intersect(constant_2,v1222_2);
        const Space v1222_4 = (has_head(v1222_3) ? constant_3 : Space{});
        Space v1222_7;
        if (!v1222_4.empty()) {
          const Path v1223_5 = concat_path(v1221_10,v1221_11_head);
          const Space v1223_6 = routine_15(c, v1223_5, v1221_11_tail);
          v1222_7 = compose(v1222_4,v1223_6);
        }
        v1221_11_result = unite(v1221_11_result,v1222_7);
      }
      const Space v1221_11 = std::move(v1221_11_result);
      v1219_12 = compose(v1219_9,v1221_11);
    }
    const Space v1219_13 = unite(v1219_7,v1219_12);
    v1218_6_result = unite(v1218_6_result,v1219_13);
  }
  const Space v1218_6 = std::move(v1218_6_result);
  return v1218_6;
}

static Space routine_133(Context& c, const Path& p0, const Space& s0) {
  Space v1224_8_result;
  for (int v1224_8_label = 1; v1224_8_label <= 2; ++v1224_8_label) {
    const Space v1224_8_tail = child(s0,v1224_8_label);
    if (v1224_8_tail.empty()) continue;
    const Path v1224_8_head{v1224_8_label};
    const Space v1225_2 = singleton(v1224_8_head);
    const Space v1225_3 = intersect(constant_2,v1225_2);
    const Space v1225_4 = (has_head(v1225_3) ? constant_3 : Space{});
    const Space v1225_5 = subtract(constant_1,v1225_4);
    Space v1225_6_result;
    for (int v1225_6_label = 1; v1225_6_label <= 2; ++v1225_6_label) {
      const Space v1225_6_tail = child(v1224_8_tail,v1225_6_label);
      if (v1225_6_tail.empty()) continue;
      const Path v1225_6_head{v1225_6_label};
      const Space v1226_2 = Space{};
      v1225_6_result = unite(v1225_6_result,v1226_2);
    }
    const Space v1225_6 = std::move(v1225_6_result);
    const Space v1225_7 = compose(v1225_5,v1225_6);
    const Space v1225_8 = intersect(constant_2,v1225_2);
    const Space v1225_9 = (has_head(v1225_8) ? constant_3 : Space{});
    Space v1225_12;
    if (!v1225_9.empty()) {
      const Path v1227_10 = concat_path(p0,v1224_8_head);
      Space v1227_11_result;
      for (int v1227_11_label = 1; v1227_11_label <= 2; ++v1227_11_label) {
        const Space v1227_11_tail = child(v1224_8_tail,v1227_11_label);
        if (v1227_11_tail.empty()) continue;
        const Path v1227_11_head{v1227_11_label};
        const Space v1228_2 = singleton(v1227_11_head);
        const Space v1228_3 = intersect(constant_2,v1228_2);
        const Space v1228_4 = (has_head(v1228_3) ? constant_3 : Space{});
        const Space v1228_5 = subtract(constant_1,v1228_4);
        Space v1228_7;
        if (!v1228_5.empty()) {
          const Space v1229_6 = routine_46(c, v1227_11_head, v1227_10, v1227_11_tail);
          v1228_7 = compose(v1228_5,v1229_6);
        }
        const Space v1228_8 = intersect(constant_2,v1228_2);
        const Space v1228_9 = (has_head(v1228_8) ? constant_3 : Space{});
        Space v1228_11;
        if (!v1228_9.empty()) {
          const Space v1230_10 = routine_47(c, v1227_11_head, v1227_10, v1227_11_tail);
          v1228_11 = compose(v1228_9,v1230_10);
        }
        const Space v1228_12 = unite(v1228_7,v1228_11);
        v1227_11_result = unite(v1227_11_result,v1228_12);
      }
      const Space v1227_11 = std::move(v1227_11_result);
      v1225_12 = compose(v1225_9,v1227_11);
    }
    const Space v1225_13 = unite(v1225_7,v1225_12);
    v1224_8_result = unite(v1224_8_result,v1225_13);
  }
  const Space v1224_8 = std::move(v1224_8_result);
  return v1224_8;
}

static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1231_12_result;
  for (int v1231_12_label = 1; v1231_12_label <= 2; ++v1231_12_label) {
    const Space v1231_12_tail = child(s0,v1231_12_label);
    if (v1231_12_tail.empty()) continue;
    const Path v1231_12_head{v1231_12_label};
    const Space v1232_2 = singleton(v1231_12_head);
    const Space v1232_3 = intersect(constant_2,v1232_2);
    const Space v1232_4 = (has_head(v1232_3) ? constant_3 : Space{});
    const Space v1232_5 = subtract(constant_1,v1232_4);
    Space v1232_8;
    if (!v1232_5.empty()) {
      const Path v1233_6 = concat_path(p0,v1231_12_head);
      Space v1233_7_result;
      for (int v1233_7_label = 1; v1233_7_label <= 2; ++v1233_7_label) {
        const Space v1233_7_tail = child(v1231_12_tail,v1233_7_label);
        if (v1233_7_tail.empty()) continue;
        const Path v1233_7_head{v1233_7_label};
        const Space v1234_2 = singleton(v1233_7_head);
        const Space v1234_3 = intersect(constant_2,v1234_2);
        const Space v1234_4 = (has_head(v1234_3) ? constant_3 : Space{});
        const Space v1234_5 = subtract(constant_1,v1234_4);
        Space v1234_8;
        if (!v1234_5.empty()) {
          const Path v1235_6 = concat_path(v1233_6,v1233_7_head);
          const Space v1235_7 = routine_166(c, v1235_6, p1, v1233_7_tail);
          v1234_8 = compose(v1234_5,v1235_7);
        }
        const Space v1234_9 = intersect(constant_2,v1234_2);
        const Space v1234_10 = (has_head(v1234_9) ? constant_3 : Space{});
        Space v1234_12;
        if (!v1234_10.empty()) {
          const Path v1236_6 = concat_path(v1233_6,v1233_7_head);
          const Space v1236_11 = routine_167(c, v1236_6, p1, v1233_7_tail);
          v1234_12 = compose(v1234_10,v1236_11);
        }
        const Space v1234_13 = unite(v1234_8,v1234_12);
        v1233_7_result = unite(v1233_7_result,v1234_13);
      }
      const Space v1233_7 = std::move(v1233_7_result);
      v1232_8 = compose(v1232_5,v1233_7);
    }
    const Space v1232_9 = intersect(constant_2,v1232_2);
    const Space v1232_10 = (has_head(v1232_9) ? constant_3 : Space{});
    Space v1232_12;
    if (!v1232_10.empty()) {
      const Path v1237_6 = concat_path(p0,v1231_12_head);
      Space v1237_11_result;
      for (int v1237_11_label = 1; v1237_11_label <= 2; ++v1237_11_label) {
        const Space v1237_11_tail = child(v1231_12_tail,v1237_11_label);
        if (v1237_11_tail.empty()) continue;
        const Path v1237_11_head{v1237_11_label};
        const Space v1238_2 = singleton(v1237_11_head);
        const Space v1238_3 = intersect(constant_2,v1238_2);
        const Space v1238_4 = (has_head(v1238_3) ? constant_3 : Space{});
        const Space v1238_5 = subtract(constant_1,v1238_4);
        Space v1238_8;
        if (!v1238_5.empty()) {
          const Path v1239_6 = concat_path(v1237_6,v1237_11_head);
          const Space v1239_7 = routine_166(c, v1239_6, p1, v1237_11_tail);
          v1238_8 = compose(v1238_5,v1239_7);
        }
        const Space v1238_9 = intersect(constant_2,v1238_2);
        const Space v1238_10 = (has_head(v1238_9) ? constant_3 : Space{});
        Space v1238_12;
        if (!v1238_10.empty()) {
          const Path v1240_6 = concat_path(v1237_6,v1237_11_head);
          const Space v1240_11 = routine_50(c, v1240_6, p1, v1237_11_tail);
          v1238_12 = compose(v1238_10,v1240_11);
        }
        const Space v1238_13 = unite(v1238_8,v1238_12);
        v1237_11_result = unite(v1237_11_result,v1238_13);
      }
      const Space v1237_11 = std::move(v1237_11_result);
      v1232_12 = compose(v1232_10,v1237_11);
    }
    const Space v1232_13 = unite(v1232_8,v1232_12);
    v1231_12_result = unite(v1231_12_result,v1232_13);
  }
  const Space v1231_12 = std::move(v1231_12_result);
  return v1231_12;
}

static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1241_9_result;
  for (int v1241_9_label = 1; v1241_9_label <= 2; ++v1241_9_label) {
    const Space v1241_9_tail = child(s0,v1241_9_label);
    if (v1241_9_tail.empty()) continue;
    const Path v1241_9_head{v1241_9_label};
    const Space v1242_2 = singleton(v1241_9_head);
    const Space v1242_3 = intersect(constant_2,v1242_2);
    const Space v1242_4 = (has_head(v1242_3) ? constant_3 : Space{});
    const Space v1242_5 = subtract(constant_1,v1242_4);
    Space v1242_8;
    if (!v1242_5.empty()) {
      const Path v1243_6 = concat_path(p0,v1241_9_head);
      Space v1243_7_result;
      for (int v1243_7_label = 1; v1243_7_label <= 2; ++v1243_7_label) {
        const Space v1243_7_tail = child(v1241_9_tail,v1243_7_label);
        if (v1243_7_tail.empty()) continue;
        const Path v1243_7_head{v1243_7_label};
        const Space v1244_2 = singleton(v1243_7_head);
        const Space v1244_3 = intersect(constant_2,v1244_2);
        const Space v1244_4 = (has_head(v1244_3) ? constant_3 : Space{});
        const Space v1244_5 = subtract(constant_1,v1244_4);
        Space v1244_8;
        if (!v1244_5.empty()) {
          const Path v1245_6 = concat_path(v1243_6,v1243_7_head);
          const Space v1245_7 = routine_166(c, v1245_6, p1, v1243_7_tail);
          v1244_8 = compose(v1244_5,v1245_7);
        }
        const Space v1244_9 = intersect(constant_2,v1244_2);
        const Space v1244_10 = (has_head(v1244_9) ? constant_3 : Space{});
        Space v1244_12;
        if (!v1244_10.empty()) {
          const Path v1246_6 = concat_path(v1243_6,v1243_7_head);
          const Space v1246_11 = routine_167(c, v1246_6, p1, v1243_7_tail);
          v1244_12 = compose(v1244_10,v1246_11);
        }
        const Space v1244_13 = unite(v1244_8,v1244_12);
        v1243_7_result = unite(v1243_7_result,v1244_13);
      }
      const Space v1243_7 = std::move(v1243_7_result);
      v1242_8 = compose(v1242_5,v1243_7);
    }
    const Space v1242_9 = intersect(constant_2,v1242_2);
    const Space v1242_10 = (has_head(v1242_9) ? constant_3 : Space{});
    const Space v1242_11 = compose(v1242_10,v1241_9_tail);
    const Path v1247_6 = concat_path(p0,v1241_9_head);
    const Space v1242_12 = wrap(v1242_11,v1247_6);
    const Space v1242_13 = wrap(v1242_12,p1);
    const Space v1242_14 = unite(v1242_8,v1242_13);
    v1241_9_result = unite(v1241_9_result,v1242_14);
  }
  const Space v1241_9 = std::move(v1241_9_result);
  return v1241_9;
}

static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1248_12_result;
  for (int v1248_12_label = 1; v1248_12_label <= 2; ++v1248_12_label) {
    const Space v1248_12_tail = child(s0,v1248_12_label);
    if (v1248_12_tail.empty()) continue;
    const Path v1248_12_head{v1248_12_label};
    const Space v1249_2 = singleton(v1248_12_head);
    const Space v1249_3 = intersect(constant_2,v1249_2);
    const Space v1249_4 = (has_head(v1249_3) ? constant_3 : Space{});
    const Space v1249_5 = subtract(constant_1,v1249_4);
    Space v1249_8;
    if (!v1249_5.empty()) {
      const Path v1250_6 = concat_path(p0,v1248_12_head);
      Space v1250_7_result;
      for (int v1250_7_label = 1; v1250_7_label <= 2; ++v1250_7_label) {
        const Space v1250_7_tail = child(v1248_12_tail,v1250_7_label);
        if (v1250_7_tail.empty()) continue;
        const Path v1250_7_head{v1250_7_label};
        const Space v1251_2 = singleton(v1250_7_head);
        const Space v1251_3 = intersect(constant_2,v1251_2);
        const Space v1251_4 = (has_head(v1251_3) ? constant_3 : Space{});
        const Space v1251_5 = subtract(constant_1,v1251_4);
        Space v1251_8;
        if (!v1251_5.empty()) {
          const Path v1252_6 = concat_path(v1250_6,v1250_7_head);
          const Space v1252_7 = routine_168(c, v1252_6, p1, v1250_7_tail);
          v1251_8 = compose(v1251_5,v1252_7);
        }
        const Space v1251_9 = intersect(constant_2,v1251_2);
        const Space v1251_10 = (has_head(v1251_9) ? constant_3 : Space{});
        Space v1251_12;
        if (!v1251_10.empty()) {
          const Path v1253_6 = concat_path(v1250_6,v1250_7_head);
          const Space v1253_11 = routine_169(c, v1253_6, p1, v1250_7_tail);
          v1251_12 = compose(v1251_10,v1253_11);
        }
        const Space v1251_13 = unite(v1251_8,v1251_12);
        v1250_7_result = unite(v1250_7_result,v1251_13);
      }
      const Space v1250_7 = std::move(v1250_7_result);
      v1249_8 = compose(v1249_5,v1250_7);
    }
    const Space v1249_9 = intersect(constant_2,v1249_2);
    const Space v1249_10 = (has_head(v1249_9) ? constant_3 : Space{});
    Space v1249_12;
    if (!v1249_10.empty()) {
      const Path v1254_6 = concat_path(p0,v1248_12_head);
      Space v1254_11_result;
      for (int v1254_11_label = 1; v1254_11_label <= 2; ++v1254_11_label) {
        const Space v1254_11_tail = child(v1248_12_tail,v1254_11_label);
        if (v1254_11_tail.empty()) continue;
        const Path v1254_11_head{v1254_11_label};
        const Space v1255_2 = singleton(v1254_11_head);
        const Space v1255_3 = intersect(constant_2,v1255_2);
        const Space v1255_4 = (has_head(v1255_3) ? constant_3 : Space{});
        const Space v1255_5 = subtract(constant_1,v1255_4);
        Space v1255_8;
        if (!v1255_5.empty()) {
          const Path v1256_6 = concat_path(v1254_6,v1254_11_head);
          const Space v1256_7 = routine_168(c, v1256_6, p1, v1254_11_tail);
          v1255_8 = compose(v1255_5,v1256_7);
        }
        const Space v1255_9 = intersect(constant_2,v1255_2);
        const Space v1255_10 = (has_head(v1255_9) ? constant_3 : Space{});
        Space v1255_12;
        if (!v1255_10.empty()) {
          const Path v1257_6 = concat_path(v1254_6,v1254_11_head);
          const Space v1257_11 = routine_50(c, v1257_6, p1, v1254_11_tail);
          v1255_12 = compose(v1255_10,v1257_11);
        }
        const Space v1255_13 = unite(v1255_8,v1255_12);
        v1254_11_result = unite(v1254_11_result,v1255_13);
      }
      const Space v1254_11 = std::move(v1254_11_result);
      v1249_12 = compose(v1249_10,v1254_11);
    }
    const Space v1249_13 = unite(v1249_8,v1249_12);
    v1248_12_result = unite(v1248_12_result,v1249_13);
  }
  const Space v1248_12 = std::move(v1248_12_result);
  return v1248_12;
}

static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1258_9_result;
  for (int v1258_9_label = 1; v1258_9_label <= 2; ++v1258_9_label) {
    const Space v1258_9_tail = child(s0,v1258_9_label);
    if (v1258_9_tail.empty()) continue;
    const Path v1258_9_head{v1258_9_label};
    const Space v1259_2 = singleton(v1258_9_head);
    const Space v1259_3 = intersect(constant_2,v1259_2);
    const Space v1259_4 = (has_head(v1259_3) ? constant_3 : Space{});
    const Space v1259_5 = subtract(constant_1,v1259_4);
    Space v1259_8;
    if (!v1259_5.empty()) {
      const Path v1260_6 = concat_path(p0,v1258_9_head);
      Space v1260_7_result;
      for (int v1260_7_label = 1; v1260_7_label <= 2; ++v1260_7_label) {
        const Space v1260_7_tail = child(v1258_9_tail,v1260_7_label);
        if (v1260_7_tail.empty()) continue;
        const Path v1260_7_head{v1260_7_label};
        const Space v1261_2 = singleton(v1260_7_head);
        const Space v1261_3 = intersect(constant_2,v1261_2);
        const Space v1261_4 = (has_head(v1261_3) ? constant_3 : Space{});
        const Space v1261_5 = subtract(constant_1,v1261_4);
        Space v1261_8;
        if (!v1261_5.empty()) {
          const Path v1262_6 = concat_path(v1260_6,v1260_7_head);
          const Space v1262_7 = routine_168(c, v1262_6, p1, v1260_7_tail);
          v1261_8 = compose(v1261_5,v1262_7);
        }
        const Space v1261_9 = intersect(constant_2,v1261_2);
        const Space v1261_10 = (has_head(v1261_9) ? constant_3 : Space{});
        Space v1261_12;
        if (!v1261_10.empty()) {
          const Path v1263_6 = concat_path(v1260_6,v1260_7_head);
          const Space v1263_11 = routine_169(c, v1263_6, p1, v1260_7_tail);
          v1261_12 = compose(v1261_10,v1263_11);
        }
        const Space v1261_13 = unite(v1261_8,v1261_12);
        v1260_7_result = unite(v1260_7_result,v1261_13);
      }
      const Space v1260_7 = std::move(v1260_7_result);
      v1259_8 = compose(v1259_5,v1260_7);
    }
    const Space v1259_9 = intersect(constant_2,v1259_2);
    const Space v1259_10 = (has_head(v1259_9) ? constant_3 : Space{});
    const Space v1259_11 = compose(v1259_10,v1258_9_tail);
    const Path v1264_6 = concat_path(p0,v1258_9_head);
    const Space v1259_12 = wrap(v1259_11,v1264_6);
    const Space v1259_13 = wrap(v1259_12,p1);
    const Space v1259_14 = unite(v1259_8,v1259_13);
    v1258_9_result = unite(v1258_9_result,v1259_14);
  }
  const Space v1258_9 = std::move(v1258_9_result);
  return v1258_9;
}

static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1265_12_result;
  for (int v1265_12_label = 1; v1265_12_label <= 2; ++v1265_12_label) {
    const Space v1265_12_tail = child(s0,v1265_12_label);
    if (v1265_12_tail.empty()) continue;
    const Path v1265_12_head{v1265_12_label};
    const Space v1266_2 = singleton(v1265_12_head);
    const Space v1266_3 = intersect(constant_2,v1266_2);
    const Space v1266_4 = (has_head(v1266_3) ? constant_3 : Space{});
    const Space v1266_5 = subtract(constant_1,v1266_4);
    Space v1266_8;
    if (!v1266_5.empty()) {
      const Path v1267_6 = concat_path(p0,v1265_12_head);
      Space v1267_7_result;
      for (int v1267_7_label = 1; v1267_7_label <= 2; ++v1267_7_label) {
        const Space v1267_7_tail = child(v1265_12_tail,v1267_7_label);
        if (v1267_7_tail.empty()) continue;
        const Path v1267_7_head{v1267_7_label};
        const Space v1268_2 = singleton(v1267_7_head);
        const Space v1268_3 = intersect(constant_2,v1268_2);
        const Space v1268_4 = (has_head(v1268_3) ? constant_3 : Space{});
        const Space v1268_5 = subtract(constant_1,v1268_4);
        Space v1268_8;
        if (!v1268_5.empty()) {
          const Path v1269_6 = concat_path(v1267_6,v1267_7_head);
          const Space v1269_7 = routine_170(c, v1269_6, p1, v1267_7_tail);
          v1268_8 = compose(v1268_5,v1269_7);
        }
        const Space v1268_9 = intersect(constant_2,v1268_2);
        const Space v1268_10 = (has_head(v1268_9) ? constant_3 : Space{});
        Space v1268_12;
        if (!v1268_10.empty()) {
          const Path v1270_6 = concat_path(v1267_6,v1267_7_head);
          const Space v1270_11 = routine_171(c, v1270_6, p1, v1267_7_tail);
          v1268_12 = compose(v1268_10,v1270_11);
        }
        const Space v1268_13 = unite(v1268_8,v1268_12);
        v1267_7_result = unite(v1267_7_result,v1268_13);
      }
      const Space v1267_7 = std::move(v1267_7_result);
      v1266_8 = compose(v1266_5,v1267_7);
    }
    const Space v1266_9 = intersect(constant_2,v1266_2);
    const Space v1266_10 = (has_head(v1266_9) ? constant_3 : Space{});
    Space v1266_12;
    if (!v1266_10.empty()) {
      const Path v1271_6 = concat_path(p0,v1265_12_head);
      Space v1271_11_result;
      for (int v1271_11_label = 1; v1271_11_label <= 2; ++v1271_11_label) {
        const Space v1271_11_tail = child(v1265_12_tail,v1271_11_label);
        if (v1271_11_tail.empty()) continue;
        const Path v1271_11_head{v1271_11_label};
        const Space v1272_2 = singleton(v1271_11_head);
        const Space v1272_3 = intersect(constant_2,v1272_2);
        const Space v1272_4 = (has_head(v1272_3) ? constant_3 : Space{});
        const Space v1272_5 = subtract(constant_1,v1272_4);
        Space v1272_8;
        if (!v1272_5.empty()) {
          const Path v1273_6 = concat_path(v1271_6,v1271_11_head);
          const Space v1273_7 = routine_170(c, v1273_6, p1, v1271_11_tail);
          v1272_8 = compose(v1272_5,v1273_7);
        }
        const Space v1272_9 = intersect(constant_2,v1272_2);
        const Space v1272_10 = (has_head(v1272_9) ? constant_3 : Space{});
        Space v1272_12;
        if (!v1272_10.empty()) {
          const Path v1274_6 = concat_path(v1271_6,v1271_11_head);
          const Space v1274_11 = routine_22(c, v1274_6, p1, v1271_11_tail);
          v1272_12 = compose(v1272_10,v1274_11);
        }
        const Space v1272_13 = unite(v1272_8,v1272_12);
        v1271_11_result = unite(v1271_11_result,v1272_13);
      }
      const Space v1271_11 = std::move(v1271_11_result);
      v1266_12 = compose(v1266_10,v1271_11);
    }
    const Space v1266_13 = unite(v1266_8,v1266_12);
    v1265_12_result = unite(v1265_12_result,v1266_13);
  }
  const Space v1265_12 = std::move(v1265_12_result);
  return v1265_12;
}

static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1275_10_result;
  for (int v1275_10_label = 1; v1275_10_label <= 2; ++v1275_10_label) {
    const Space v1275_10_tail = child(s0,v1275_10_label);
    if (v1275_10_tail.empty()) continue;
    const Path v1275_10_head{v1275_10_label};
    const Space v1276_2 = singleton(v1275_10_head);
    const Space v1276_3 = intersect(constant_2,v1276_2);
    const Space v1276_4 = (has_head(v1276_3) ? constant_3 : Space{});
    const Space v1276_5 = compose(v1276_4,v1275_10_tail);
    const Path v1277_6 = concat_path(p0,v1275_10_head);
    const Space v1276_7 = wrap(v1276_5,v1277_6);
    const Space v1276_8 = wrap(v1276_7,p1);
    const Space v1276_9 = wrap(v1276_8,constant_6);
    const Space v1276_10 = intersect(constant_2,v1276_2);
    const Space v1276_11 = (has_head(v1276_10) ? constant_3 : Space{});
    const Space v1276_12 = subtract(constant_1,v1276_11);
    Space v1276_14;
    if (!v1276_12.empty()) {
      Space v1278_13_result;
      for (int v1278_13_label = 1; v1278_13_label <= 2; ++v1278_13_label) {
        const Space v1278_13_tail = child(v1275_10_tail,v1278_13_label);
        if (v1278_13_tail.empty()) continue;
        const Path v1278_13_head{v1278_13_label};
        const Space v1279_2 = singleton(v1278_13_head);
        const Space v1279_3 = intersect(constant_2,v1279_2);
        const Space v1279_4 = (has_head(v1279_3) ? constant_3 : Space{});
        const Space v1279_5 = subtract(constant_1,v1279_4);
        Space v1279_8;
        if (!v1279_5.empty()) {
          const Path v1280_6 = concat_path(v1277_6,v1278_13_head);
          const Space v1280_7 = routine_170(c, v1280_6, p1, v1278_13_tail);
          v1279_8 = compose(v1279_5,v1280_7);
        }
        const Space v1279_9 = intersect(constant_2,v1279_2);
        const Space v1279_10 = (has_head(v1279_9) ? constant_3 : Space{});
        Space v1279_12;
        if (!v1279_10.empty()) {
          const Path v1281_6 = concat_path(v1277_6,v1278_13_head);
          const Space v1281_11 = routine_171(c, v1281_6, p1, v1278_13_tail);
          v1279_12 = compose(v1279_10,v1281_11);
        }
        const Space v1279_13 = unite(v1279_8,v1279_12);
        v1278_13_result = unite(v1278_13_result,v1279_13);
      }
      const Space v1278_13 = std::move(v1278_13_result);
      v1276_14 = compose(v1276_12,v1278_13);
    }
    const Space v1276_15 = unite(v1276_9,v1276_14);
    v1275_10_result = unite(v1275_10_result,v1276_15);
  }
  const Space v1275_10 = std::move(v1275_10_result);
  return v1275_10;
}

static Space routine_140(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1282_7_result;
  for (int v1282_7_label = 1; v1282_7_label <= 2; ++v1282_7_label) {
    const Space v1282_7_tail = child(s0,v1282_7_label);
    if (v1282_7_tail.empty()) continue;
    const Path v1282_7_head{v1282_7_label};
    const Space v1283_2 = singleton(v1282_7_head);
    const Space v1283_3 = intersect(constant_2,v1283_2);
    const Space v1283_4 = (has_head(v1283_3) ? constant_3 : Space{});
    const Space v1283_5 = subtract(constant_1,v1283_4);
    Space v1283_6_result;
    for (int v1283_6_label = 1; v1283_6_label <= 2; ++v1283_6_label) {
      const Space v1283_6_tail = child(v1282_7_tail,v1283_6_label);
      if (v1283_6_tail.empty()) continue;
      const Path v1283_6_head{v1283_6_label};
      const Space v1284_2 = Space{};
      v1283_6_result = unite(v1283_6_result,v1284_2);
    }
    const Space v1283_6 = std::move(v1283_6_result);
    const Space v1283_7 = compose(v1283_5,v1283_6);
    const Space v1283_8 = intersect(constant_2,v1283_2);
    const Space v1283_9 = (has_head(v1283_8) ? constant_3 : Space{});
    Space v1283_12;
    if (!v1283_9.empty()) {
      const Path v1285_10 = concat_path(p0,v1282_7_head);
      Space v1285_11_result;
      for (int v1285_11_label = 1; v1285_11_label <= 2; ++v1285_11_label) {
        const Space v1285_11_tail = child(v1282_7_tail,v1285_11_label);
        if (v1285_11_tail.empty()) continue;
        const Path v1285_11_head{v1285_11_label};
        const Space v1286_2 = singleton(v1285_11_head);
        const Space v1286_3 = intersect(constant_2,v1286_2);
        const Space v1286_4 = (has_head(v1286_3) ? constant_3 : Space{});
        Space v1286_7;
        if (!v1286_4.empty()) {
          const Path v1287_5 = concat_path(v1285_10,v1285_11_head);
          const Space v1287_6 = routine_22(c, v1287_5, p1, v1285_11_tail);
          v1286_7 = compose(v1286_4,v1287_6);
        }
        v1285_11_result = unite(v1285_11_result,v1286_7);
      }
      const Space v1285_11 = std::move(v1285_11_result);
      v1283_12 = compose(v1283_9,v1285_11);
    }
    const Space v1283_13 = unite(v1283_7,v1283_12);
    v1282_7_result = unite(v1282_7_result,v1283_13);
  }
  const Space v1282_7 = std::move(v1282_7_result);
  return v1282_7;
}

static Space routine_141(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1288_7_result;
  for (int v1288_7_label = 1; v1288_7_label <= 2; ++v1288_7_label) {
    const Space v1288_7_tail = child(s0,v1288_7_label);
    if (v1288_7_tail.empty()) continue;
    const Path v1288_7_head{v1288_7_label};
    const Space v1289_2 = singleton(v1288_7_head);
    const Space v1289_3 = intersect(constant_2,v1289_2);
    const Space v1289_4 = (has_head(v1289_3) ? constant_3 : Space{});
    const Space v1289_5 = compose(v1289_4,v1288_7_tail);
    const Path v1289_6 = concat_path(p0,v1288_7_head);
    const Space v1289_7 = wrap(v1289_5,v1289_6);
    const Space v1289_8 = wrap(v1289_7,p1);
    const Space v1289_9 = wrap(v1289_8,constant_6);
    const Space v1289_10 = intersect(constant_2,v1289_2);
    const Space v1289_11 = (has_head(v1289_10) ? constant_3 : Space{});
    const Space v1289_12 = subtract(constant_1,v1289_11);
    Space v1289_13_result;
    for (int v1289_13_label = 1; v1289_13_label <= 2; ++v1289_13_label) {
      const Space v1289_13_tail = child(v1288_7_tail,v1289_13_label);
      if (v1289_13_tail.empty()) continue;
      const Path v1289_13_head{v1289_13_label};
      const Space v1290_2 = Space{};
      v1289_13_result = unite(v1289_13_result,v1290_2);
    }
    const Space v1289_13 = std::move(v1289_13_result);
    const Space v1289_14 = compose(v1289_12,v1289_13);
    const Space v1289_15 = unite(v1289_9,v1289_14);
    v1288_7_result = unite(v1288_7_result,v1289_15);
  }
  const Space v1288_7 = std::move(v1288_7_result);
  return v1288_7;
}

static Space routine_142(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1291_13_result;
  for (int v1291_13_label = 1; v1291_13_label <= 2; ++v1291_13_label) {
    const Space v1291_13_tail = child(s0,v1291_13_label);
    if (v1291_13_tail.empty()) continue;
    const Path v1291_13_head{v1291_13_label};
    const Space v1292_2 = singleton(v1291_13_head);
    const Space v1292_3 = intersect(constant_2,v1292_2);
    const Space v1292_4 = (has_head(v1292_3) ? constant_3 : Space{});
    const Space v1292_5 = subtract(constant_1,v1292_4);
    Space v1292_8;
    if (!v1292_5.empty()) {
      const Path v1293_6 = concat_path(p0,v1291_13_head);
      Space v1293_7_result;
      for (int v1293_7_label = 1; v1293_7_label <= 2; ++v1293_7_label) {
        const Space v1293_7_tail = child(v1291_13_tail,v1293_7_label);
        if (v1293_7_tail.empty()) continue;
        const Path v1293_7_head{v1293_7_label};
        const Space v1294_2 = singleton(v1293_7_head);
        const Space v1294_3 = intersect(constant_2,v1294_2);
        const Space v1294_4 = (has_head(v1294_3) ? constant_3 : Space{});
        const Space v1294_5 = subtract(constant_1,v1294_4);
        Space v1294_8;
        if (!v1294_5.empty()) {
          const Path v1295_6 = concat_path(v1293_6,v1293_7_head);
          const Space v1295_7 = routine_172(c, v1295_6, p1, v1293_7_tail, s1);
          v1294_8 = compose(v1294_5,v1295_7);
        }
        const Space v1294_9 = intersect(constant_2,v1294_2);
        const Space v1294_10 = (has_head(v1294_9) ? constant_3 : Space{});
        Space v1294_12;
        if (!v1294_10.empty()) {
          const Path v1296_6 = concat_path(v1293_6,v1293_7_head);
          const Space v1296_11 = routine_173(c, v1296_6, p1, v1293_7_tail, s1);
          v1294_12 = compose(v1294_10,v1296_11);
        }
        const Space v1294_13 = unite(v1294_8,v1294_12);
        v1293_7_result = unite(v1293_7_result,v1294_13);
      }
      const Space v1293_7 = std::move(v1293_7_result);
      v1292_8 = compose(v1292_5,v1293_7);
    }
    const Space v1292_9 = intersect(constant_2,v1292_2);
    const Space v1292_10 = (has_head(v1292_9) ? constant_3 : Space{});
    Space v1292_12;
    if (!v1292_10.empty()) {
      const Path v1297_6 = concat_path(p0,v1291_13_head);
      Space v1297_11_result;
      for (int v1297_11_label = 1; v1297_11_label <= 2; ++v1297_11_label) {
        const Space v1297_11_tail = child(v1291_13_tail,v1297_11_label);
        if (v1297_11_tail.empty()) continue;
        const Path v1297_11_head{v1297_11_label};
        const Space v1298_2 = singleton(v1297_11_head);
        const Space v1298_3 = intersect(constant_2,v1298_2);
        const Space v1298_4 = (has_head(v1298_3) ? constant_3 : Space{});
        const Space v1298_5 = subtract(constant_1,v1298_4);
        Space v1298_8;
        if (!v1298_5.empty()) {
          const Path v1299_6 = concat_path(v1297_6,v1297_11_head);
          const Space v1299_7 = routine_172(c, v1299_6, p1, v1297_11_tail, s1);
          v1298_8 = compose(v1298_5,v1299_7);
        }
        const Space v1298_9 = intersect(constant_2,v1298_2);
        const Space v1298_10 = (has_head(v1298_9) ? constant_3 : Space{});
        Space v1298_12;
        if (!v1298_10.empty()) {
          const Path v1300_6 = concat_path(v1297_6,v1297_11_head);
          const Space v1300_11 = routine_29(c, v1300_6, p1, v1297_11_tail, s1);
          v1298_12 = compose(v1298_10,v1300_11);
        }
        const Space v1298_13 = unite(v1298_8,v1298_12);
        v1297_11_result = unite(v1297_11_result,v1298_13);
      }
      const Space v1297_11 = std::move(v1297_11_result);
      v1292_12 = compose(v1292_10,v1297_11);
    }
    const Space v1292_13 = unite(v1292_8,v1292_12);
    v1291_13_result = unite(v1291_13_result,v1292_13);
  }
  const Space v1291_13 = std::move(v1291_13_result);
  return v1291_13;
}

static Space routine_143(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1301_8 = unwrap(s1,constant_5);
  const Space v1301_10 = unwrap(v1301_8,constant_6);
  const Space v1301_11 = unwrap(v1301_10,p0);
  Space v1301_18_result;
  for (int v1301_18_label = 1; v1301_18_label <= 2; ++v1301_18_label) {
    const Space v1301_18_tail = child(s0,v1301_18_label);
    if (v1301_18_tail.empty()) continue;
    const Path v1301_18_head{v1301_18_label};
    const Space v1302_2 = singleton(v1301_18_head);
    const Space v1302_3 = intersect(constant_2,v1302_2);
    const Space v1302_4 = (has_head(v1302_3) ? constant_3 : Space{});
    const Space v1302_5 = subtract(constant_1,v1302_4);
    Space v1302_8;
    if (!v1302_5.empty()) {
      const Path v1303_6 = concat_path(p0,v1301_18_head);
      Space v1303_7_result;
      for (int v1303_7_label = 1; v1303_7_label <= 2; ++v1303_7_label) {
        const Space v1303_7_tail = child(v1301_18_tail,v1303_7_label);
        if (v1303_7_tail.empty()) continue;
        const Path v1303_7_head{v1303_7_label};
        const Space v1304_2 = singleton(v1303_7_head);
        const Space v1304_3 = intersect(constant_2,v1304_2);
        const Space v1304_4 = (has_head(v1304_3) ? constant_3 : Space{});
        const Space v1304_5 = subtract(constant_1,v1304_4);
        Space v1304_8;
        if (!v1304_5.empty()) {
          const Path v1305_6 = concat_path(v1303_6,v1303_7_head);
          const Space v1305_7 = routine_172(c, v1305_6, p1, v1303_7_tail, s1);
          v1304_8 = compose(v1304_5,v1305_7);
        }
        const Space v1304_9 = intersect(constant_2,v1304_2);
        const Space v1304_10 = (has_head(v1304_9) ? constant_3 : Space{});
        Space v1304_12;
        if (!v1304_10.empty()) {
          const Path v1306_6 = concat_path(v1303_6,v1303_7_head);
          const Space v1306_11 = routine_173(c, v1306_6, p1, v1303_7_tail, s1);
          v1304_12 = compose(v1304_10,v1306_11);
        }
        const Space v1304_13 = unite(v1304_8,v1304_12);
        v1303_7_result = unite(v1303_7_result,v1304_13);
      }
      const Space v1303_7 = std::move(v1303_7_result);
      v1302_8 = compose(v1302_5,v1303_7);
    }
    const Space v1302_9 = intersect(constant_2,v1302_2);
    const Space v1302_10 = (has_head(v1302_9) ? constant_3 : Space{});
    Space v1302_13;
    if (!v1302_10.empty()) {
      const Space v1307_11 = unwrap(v1301_11,v1301_18_head);
      Space v1307_12_result;
      for (int v1307_12_label = 1; v1307_12_label <= 2; ++v1307_12_label) {
        const Space v1307_12_tail = child(v1307_11,v1307_12_label);
        if (v1307_12_tail.empty()) continue;
        const Path v1307_12_head{v1307_12_label};
        const Space v1308_2 = singleton(v1307_12_head);
        const Space v1308_3 = intersect(constant_2,v1308_2);
        const Space v1308_4 = (has_head(v1308_3) ? constant_3 : Space{});
        const Space v1308_5 = subtract(constant_1,v1308_4);
        Space v1308_7;
        if (!v1308_5.empty()) {
          const Space v1309_6 = routine_61(c, v1307_12_head, p1, v1307_12_tail);
          v1308_7 = compose(v1308_5,v1309_6);
        }
        const Space v1308_8 = intersect(constant_2,v1308_2);
        const Space v1308_9 = (has_head(v1308_8) ? constant_3 : Space{});
        Space v1308_11;
        if (!v1308_9.empty()) {
          const Space v1310_10 = routine_62(c, v1307_12_head, p1, v1307_12_tail);
          v1308_11 = compose(v1308_9,v1310_10);
        }
        const Space v1308_12 = unite(v1308_7,v1308_11);
        v1307_12_result = unite(v1307_12_result,v1308_12);
      }
      const Space v1307_12 = std::move(v1307_12_result);
      v1302_13 = compose(v1302_10,v1307_12);
    }
    const Space v1302_14 = unite(v1302_8,v1302_13);
    v1301_18_result = unite(v1301_18_result,v1302_14);
  }
  const Space v1301_18 = std::move(v1301_18_result);
  return v1301_18;
}

static Space routine_144(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1311_12_result;
  for (int v1311_12_label = 1; v1311_12_label <= 2; ++v1311_12_label) {
    const Space v1311_12_tail = child(s0,v1311_12_label);
    if (v1311_12_tail.empty()) continue;
    const Path v1311_12_head{v1311_12_label};
    const Space v1312_2 = singleton(v1311_12_head);
    const Space v1312_3 = intersect(constant_2,v1312_2);
    const Space v1312_4 = (has_head(v1312_3) ? constant_3 : Space{});
    const Space v1312_5 = subtract(constant_1,v1312_4);
    Space v1312_8;
    if (!v1312_5.empty()) {
      const Path v1313_6 = concat_path(p0,v1311_12_head);
      Space v1313_7_result;
      for (int v1313_7_label = 1; v1313_7_label <= 2; ++v1313_7_label) {
        const Space v1313_7_tail = child(v1311_12_tail,v1313_7_label);
        if (v1313_7_tail.empty()) continue;
        const Path v1313_7_head{v1313_7_label};
        const Space v1314_2 = singleton(v1313_7_head);
        const Space v1314_3 = intersect(constant_2,v1314_2);
        const Space v1314_4 = (has_head(v1314_3) ? constant_3 : Space{});
        const Space v1314_5 = subtract(constant_1,v1314_4);
        Space v1314_8;
        if (!v1314_5.empty()) {
          const Path v1315_6 = concat_path(v1313_6,v1313_7_head);
          const Space v1315_7 = routine_174(c, v1315_6, p1, v1313_7_tail);
          v1314_8 = compose(v1314_5,v1315_7);
        }
        const Space v1314_9 = intersect(constant_2,v1314_2);
        const Space v1314_10 = (has_head(v1314_9) ? constant_3 : Space{});
        Space v1314_12;
        if (!v1314_10.empty()) {
          const Path v1316_6 = concat_path(v1313_6,v1313_7_head);
          const Space v1316_11 = routine_175(c, v1316_6, p1, v1313_7_tail);
          v1314_12 = compose(v1314_10,v1316_11);
        }
        const Space v1314_13 = unite(v1314_8,v1314_12);
        v1313_7_result = unite(v1313_7_result,v1314_13);
      }
      const Space v1313_7 = std::move(v1313_7_result);
      v1312_8 = compose(v1312_5,v1313_7);
    }
    const Space v1312_9 = intersect(constant_2,v1312_2);
    const Space v1312_10 = (has_head(v1312_9) ? constant_3 : Space{});
    Space v1312_12;
    if (!v1312_10.empty()) {
      const Path v1317_6 = concat_path(p0,v1311_12_head);
      Space v1317_11_result;
      for (int v1317_11_label = 1; v1317_11_label <= 2; ++v1317_11_label) {
        const Space v1317_11_tail = child(v1311_12_tail,v1317_11_label);
        if (v1317_11_tail.empty()) continue;
        const Path v1317_11_head{v1317_11_label};
        const Space v1318_2 = singleton(v1317_11_head);
        const Space v1318_3 = intersect(constant_2,v1318_2);
        const Space v1318_4 = (has_head(v1318_3) ? constant_3 : Space{});
        const Space v1318_5 = subtract(constant_1,v1318_4);
        Space v1318_8;
        if (!v1318_5.empty()) {
          const Path v1319_6 = concat_path(v1317_6,v1317_11_head);
          const Space v1319_7 = routine_174(c, v1319_6, p1, v1317_11_tail);
          v1318_8 = compose(v1318_5,v1319_7);
        }
        const Space v1318_9 = intersect(constant_2,v1318_2);
        const Space v1318_10 = (has_head(v1318_9) ? constant_3 : Space{});
        Space v1318_12;
        if (!v1318_10.empty()) {
          const Path v1320_6 = concat_path(v1317_6,v1317_11_head);
          const Space v1320_11 = routine_67(c, v1320_6, p1, v1317_11_tail);
          v1318_12 = compose(v1318_10,v1320_11);
        }
        const Space v1318_13 = unite(v1318_8,v1318_12);
        v1317_11_result = unite(v1317_11_result,v1318_13);
      }
      const Space v1317_11 = std::move(v1317_11_result);
      v1312_12 = compose(v1312_10,v1317_11);
    }
    const Space v1312_13 = unite(v1312_8,v1312_12);
    v1311_12_result = unite(v1311_12_result,v1312_13);
  }
  const Space v1311_12 = std::move(v1311_12_result);
  return v1311_12;
}

static Space routine_145(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1321_9_result;
  for (int v1321_9_label = 1; v1321_9_label <= 2; ++v1321_9_label) {
    const Space v1321_9_tail = child(s0,v1321_9_label);
    if (v1321_9_tail.empty()) continue;
    const Path v1321_9_head{v1321_9_label};
    const Space v1322_2 = singleton(v1321_9_head);
    const Space v1322_3 = intersect(constant_2,v1322_2);
    const Space v1322_4 = (has_head(v1322_3) ? constant_3 : Space{});
    const Space v1322_5 = subtract(constant_1,v1322_4);
    Space v1322_8;
    if (!v1322_5.empty()) {
      const Path v1323_6 = concat_path(p0,v1321_9_head);
      Space v1323_7_result;
      for (int v1323_7_label = 1; v1323_7_label <= 2; ++v1323_7_label) {
        const Space v1323_7_tail = child(v1321_9_tail,v1323_7_label);
        if (v1323_7_tail.empty()) continue;
        const Path v1323_7_head{v1323_7_label};
        const Space v1324_2 = singleton(v1323_7_head);
        const Space v1324_3 = intersect(constant_2,v1324_2);
        const Space v1324_4 = (has_head(v1324_3) ? constant_3 : Space{});
        const Space v1324_5 = subtract(constant_1,v1324_4);
        Space v1324_8;
        if (!v1324_5.empty()) {
          const Path v1325_6 = concat_path(v1323_6,v1323_7_head);
          const Space v1325_7 = routine_174(c, v1325_6, p1, v1323_7_tail);
          v1324_8 = compose(v1324_5,v1325_7);
        }
        const Space v1324_9 = intersect(constant_2,v1324_2);
        const Space v1324_10 = (has_head(v1324_9) ? constant_3 : Space{});
        Space v1324_12;
        if (!v1324_10.empty()) {
          const Path v1326_6 = concat_path(v1323_6,v1323_7_head);
          const Space v1326_11 = routine_175(c, v1326_6, p1, v1323_7_tail);
          v1324_12 = compose(v1324_10,v1326_11);
        }
        const Space v1324_13 = unite(v1324_8,v1324_12);
        v1323_7_result = unite(v1323_7_result,v1324_13);
      }
      const Space v1323_7 = std::move(v1323_7_result);
      v1322_8 = compose(v1322_5,v1323_7);
    }
    const Space v1322_9 = intersect(constant_2,v1322_2);
    const Space v1322_10 = (has_head(v1322_9) ? constant_3 : Space{});
    const Space v1322_11 = compose(v1322_10,v1321_9_tail);
    const Path v1327_6 = concat_path(p0,v1321_9_head);
    const Space v1322_12 = wrap(v1322_11,v1327_6);
    const Space v1322_13 = wrap(v1322_12,p1);
    const Space v1322_14 = unite(v1322_8,v1322_13);
    v1321_9_result = unite(v1321_9_result,v1322_14);
  }
  const Space v1321_9 = std::move(v1321_9_result);
  return v1321_9;
}

static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1328_8_result;
  for (int v1328_8_label = 1; v1328_8_label <= 2; ++v1328_8_label) {
    const Space v1328_8_tail = child(s0,v1328_8_label);
    if (v1328_8_tail.empty()) continue;
    const Path v1328_8_head{v1328_8_label};
    const Space v1329_2 = singleton(v1328_8_head);
    const Space v1329_3 = intersect(constant_2,v1329_2);
    const Space v1329_4 = (has_head(v1329_3) ? constant_3 : Space{});
    const Space v1329_5 = subtract(constant_1,v1329_4);
    Space v1329_6_result;
    for (int v1329_6_label = 1; v1329_6_label <= 2; ++v1329_6_label) {
      const Space v1329_6_tail = child(v1328_8_tail,v1329_6_label);
      if (v1329_6_tail.empty()) continue;
      const Path v1329_6_head{v1329_6_label};
      const Space v1330_2 = Space{};
      v1329_6_result = unite(v1329_6_result,v1330_2);
    }
    const Space v1329_6 = std::move(v1329_6_result);
    const Space v1329_7 = compose(v1329_5,v1329_6);
    const Space v1329_8 = intersect(constant_2,v1329_2);
    const Space v1329_9 = (has_head(v1329_8) ? constant_3 : Space{});
    Space v1329_12;
    if (!v1329_9.empty()) {
      const Path v1331_10 = concat_path(p0,v1328_8_head);
      Space v1331_11_result;
      for (int v1331_11_label = 1; v1331_11_label <= 2; ++v1331_11_label) {
        const Space v1331_11_tail = child(v1328_8_tail,v1331_11_label);
        if (v1331_11_tail.empty()) continue;
        const Path v1331_11_head{v1331_11_label};
        const Space v1332_2 = singleton(v1331_11_head);
        const Space v1332_3 = intersect(constant_2,v1332_2);
        const Space v1332_4 = (has_head(v1332_3) ? constant_3 : Space{});
        Space v1332_7;
        if (!v1332_4.empty()) {
          const Path v1333_5 = concat_path(v1331_10,v1331_11_head);
          const Space v1333_6 = routine_29(c, v1333_5, p1, v1331_11_tail, s1);
          v1332_7 = compose(v1332_4,v1333_6);
        }
        v1331_11_result = unite(v1331_11_result,v1332_7);
      }
      const Space v1331_11 = std::move(v1331_11_result);
      v1329_12 = compose(v1329_9,v1331_11);
    }
    const Space v1329_13 = unite(v1329_7,v1329_12);
    v1328_8_result = unite(v1328_8_result,v1329_13);
  }
  const Space v1328_8 = std::move(v1328_8_result);
  return v1328_8;
}

static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1334_8 = unwrap(s1,constant_5);
  const Space v1334_10 = unwrap(v1334_8,constant_6);
  const Space v1334_11 = unwrap(v1334_10,p0);
  Space v1334_15_result;
  for (int v1334_15_label = 1; v1334_15_label <= 2; ++v1334_15_label) {
    const Space v1334_15_tail = child(s0,v1334_15_label);
    if (v1334_15_tail.empty()) continue;
    const Path v1334_15_head{v1334_15_label};
    const Space v1335_2 = singleton(v1334_15_head);
    const Space v1335_3 = intersect(constant_2,v1335_2);
    const Space v1335_4 = (has_head(v1335_3) ? constant_3 : Space{});
    const Space v1335_5 = subtract(constant_1,v1335_4);
    Space v1335_6_result;
    for (int v1335_6_label = 1; v1335_6_label <= 2; ++v1335_6_label) {
      const Space v1335_6_tail = child(v1334_15_tail,v1335_6_label);
      if (v1335_6_tail.empty()) continue;
      const Path v1335_6_head{v1335_6_label};
      const Space v1336_2 = Space{};
      v1335_6_result = unite(v1335_6_result,v1336_2);
    }
    const Space v1335_6 = std::move(v1335_6_result);
    const Space v1335_7 = compose(v1335_5,v1335_6);
    const Space v1335_8 = intersect(constant_2,v1335_2);
    const Space v1335_9 = (has_head(v1335_8) ? constant_3 : Space{});
    Space v1335_12;
    if (!v1335_9.empty()) {
      const Space v1337_10 = unwrap(v1334_11,v1334_15_head);
      Space v1337_11_result;
      for (int v1337_11_label = 1; v1337_11_label <= 2; ++v1337_11_label) {
        const Space v1337_11_tail = child(v1337_10,v1337_11_label);
        if (v1337_11_tail.empty()) continue;
        const Path v1337_11_head{v1337_11_label};
        const Space v1338_2 = singleton(v1337_11_head);
        const Space v1338_3 = intersect(constant_2,v1338_2);
        const Space v1338_4 = (has_head(v1338_3) ? constant_3 : Space{});
        const Space v1338_5 = subtract(constant_1,v1338_4);
        Space v1338_7;
        if (!v1338_5.empty()) {
          const Space v1339_6 = routine_61(c, v1337_11_head, p1, v1337_11_tail);
          v1338_7 = compose(v1338_5,v1339_6);
        }
        const Space v1338_8 = intersect(constant_2,v1338_2);
        const Space v1338_9 = (has_head(v1338_8) ? constant_3 : Space{});
        Space v1338_11;
        if (!v1338_9.empty()) {
          const Space v1340_10 = routine_62(c, v1337_11_head, p1, v1337_11_tail);
          v1338_11 = compose(v1338_9,v1340_10);
        }
        const Space v1338_12 = unite(v1338_7,v1338_11);
        v1337_11_result = unite(v1337_11_result,v1338_12);
      }
      const Space v1337_11 = std::move(v1337_11_result);
      v1335_12 = compose(v1335_9,v1337_11);
    }
    const Space v1335_13 = unite(v1335_7,v1335_12);
    v1334_15_result = unite(v1334_15_result,v1335_13);
  }
  const Space v1334_15 = std::move(v1334_15_result);
  return v1334_15;
}

static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1341_12_result;
  for (int v1341_12_label = 1; v1341_12_label <= 2; ++v1341_12_label) {
    const Space v1341_12_tail = child(s0,v1341_12_label);
    if (v1341_12_tail.empty()) continue;
    const Path v1341_12_head{v1341_12_label};
    const Space v1342_2 = singleton(v1341_12_head);
    const Space v1342_3 = intersect(constant_2,v1342_2);
    const Space v1342_4 = (has_head(v1342_3) ? constant_3 : Space{});
    const Space v1342_5 = subtract(constant_1,v1342_4);
    Space v1342_8;
    if (!v1342_5.empty()) {
      const Path v1343_6 = concat_path(p0,v1341_12_head);
      Space v1343_7_result;
      for (int v1343_7_label = 1; v1343_7_label <= 2; ++v1343_7_label) {
        const Space v1343_7_tail = child(v1341_12_tail,v1343_7_label);
        if (v1343_7_tail.empty()) continue;
        const Path v1343_7_head{v1343_7_label};
        const Space v1344_2 = singleton(v1343_7_head);
        const Space v1344_3 = intersect(constant_2,v1344_2);
        const Space v1344_4 = (has_head(v1344_3) ? constant_3 : Space{});
        const Space v1344_5 = subtract(constant_1,v1344_4);
        Space v1344_8;
        if (!v1344_5.empty()) {
          const Path v1345_6 = concat_path(v1343_6,v1343_7_head);
          const Space v1345_7 = routine_176(c, v1345_6, p1, v1343_7_tail);
          v1344_8 = compose(v1344_5,v1345_7);
        }
        const Space v1344_9 = intersect(constant_2,v1344_2);
        const Space v1344_10 = (has_head(v1344_9) ? constant_3 : Space{});
        Space v1344_12;
        if (!v1344_10.empty()) {
          const Path v1346_6 = concat_path(v1343_6,v1343_7_head);
          const Space v1346_11 = routine_177(c, v1346_6, p1, v1343_7_tail);
          v1344_12 = compose(v1344_10,v1346_11);
        }
        const Space v1344_13 = unite(v1344_8,v1344_12);
        v1343_7_result = unite(v1343_7_result,v1344_13);
      }
      const Space v1343_7 = std::move(v1343_7_result);
      v1342_8 = compose(v1342_5,v1343_7);
    }
    const Space v1342_9 = intersect(constant_2,v1342_2);
    const Space v1342_10 = (has_head(v1342_9) ? constant_3 : Space{});
    Space v1342_12;
    if (!v1342_10.empty()) {
      const Path v1347_6 = concat_path(p0,v1341_12_head);
      Space v1347_11_result;
      for (int v1347_11_label = 1; v1347_11_label <= 2; ++v1347_11_label) {
        const Space v1347_11_tail = child(v1341_12_tail,v1347_11_label);
        if (v1347_11_tail.empty()) continue;
        const Path v1347_11_head{v1347_11_label};
        const Space v1348_2 = singleton(v1347_11_head);
        const Space v1348_3 = intersect(constant_2,v1348_2);
        const Space v1348_4 = (has_head(v1348_3) ? constant_3 : Space{});
        const Space v1348_5 = subtract(constant_1,v1348_4);
        Space v1348_8;
        if (!v1348_5.empty()) {
          const Path v1349_6 = concat_path(v1347_6,v1347_11_head);
          const Space v1349_7 = routine_176(c, v1349_6, p1, v1347_11_tail);
          v1348_8 = compose(v1348_5,v1349_7);
        }
        const Space v1348_9 = intersect(constant_2,v1348_2);
        const Space v1348_10 = (has_head(v1348_9) ? constant_3 : Space{});
        Space v1348_12;
        if (!v1348_10.empty()) {
          const Path v1350_6 = concat_path(v1347_6,v1347_11_head);
          const Space v1350_11 = routine_67(c, v1350_6, p1, v1347_11_tail);
          v1348_12 = compose(v1348_10,v1350_11);
        }
        const Space v1348_13 = unite(v1348_8,v1348_12);
        v1347_11_result = unite(v1347_11_result,v1348_13);
      }
      const Space v1347_11 = std::move(v1347_11_result);
      v1342_12 = compose(v1342_10,v1347_11);
    }
    const Space v1342_13 = unite(v1342_8,v1342_12);
    v1341_12_result = unite(v1341_12_result,v1342_13);
  }
  const Space v1341_12 = std::move(v1341_12_result);
  return v1341_12;
}

static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1351_9_result;
  for (int v1351_9_label = 1; v1351_9_label <= 2; ++v1351_9_label) {
    const Space v1351_9_tail = child(s0,v1351_9_label);
    if (v1351_9_tail.empty()) continue;
    const Path v1351_9_head{v1351_9_label};
    const Space v1352_2 = singleton(v1351_9_head);
    const Space v1352_3 = intersect(constant_2,v1352_2);
    const Space v1352_4 = (has_head(v1352_3) ? constant_3 : Space{});
    const Space v1352_5 = subtract(constant_1,v1352_4);
    Space v1352_8;
    if (!v1352_5.empty()) {
      const Path v1353_6 = concat_path(p0,v1351_9_head);
      Space v1353_7_result;
      for (int v1353_7_label = 1; v1353_7_label <= 2; ++v1353_7_label) {
        const Space v1353_7_tail = child(v1351_9_tail,v1353_7_label);
        if (v1353_7_tail.empty()) continue;
        const Path v1353_7_head{v1353_7_label};
        const Space v1354_2 = singleton(v1353_7_head);
        const Space v1354_3 = intersect(constant_2,v1354_2);
        const Space v1354_4 = (has_head(v1354_3) ? constant_3 : Space{});
        const Space v1354_5 = subtract(constant_1,v1354_4);
        Space v1354_8;
        if (!v1354_5.empty()) {
          const Path v1355_6 = concat_path(v1353_6,v1353_7_head);
          const Space v1355_7 = routine_176(c, v1355_6, p1, v1353_7_tail);
          v1354_8 = compose(v1354_5,v1355_7);
        }
        const Space v1354_9 = intersect(constant_2,v1354_2);
        const Space v1354_10 = (has_head(v1354_9) ? constant_3 : Space{});
        Space v1354_12;
        if (!v1354_10.empty()) {
          const Path v1356_6 = concat_path(v1353_6,v1353_7_head);
          const Space v1356_11 = routine_177(c, v1356_6, p1, v1353_7_tail);
          v1354_12 = compose(v1354_10,v1356_11);
        }
        const Space v1354_13 = unite(v1354_8,v1354_12);
        v1353_7_result = unite(v1353_7_result,v1354_13);
      }
      const Space v1353_7 = std::move(v1353_7_result);
      v1352_8 = compose(v1352_5,v1353_7);
    }
    const Space v1352_9 = intersect(constant_2,v1352_2);
    const Space v1352_10 = (has_head(v1352_9) ? constant_3 : Space{});
    const Space v1352_11 = compose(v1352_10,v1351_9_tail);
    const Path v1357_6 = concat_path(p0,v1351_9_head);
    const Space v1352_12 = wrap(v1352_11,v1357_6);
    const Space v1352_13 = wrap(v1352_12,p1);
    const Space v1352_14 = unite(v1352_8,v1352_13);
    v1351_9_result = unite(v1351_9_result,v1352_14);
  }
  const Space v1351_9 = std::move(v1351_9_result);
  return v1351_9;
}

static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1358_13_result;
  for (int v1358_13_label = 1; v1358_13_label <= 2; ++v1358_13_label) {
    const Space v1358_13_tail = child(s0,v1358_13_label);
    if (v1358_13_tail.empty()) continue;
    const Path v1358_13_head{v1358_13_label};
    const Space v1359_2 = singleton(v1358_13_head);
    const Space v1359_3 = intersect(constant_2,v1359_2);
    const Space v1359_4 = (has_head(v1359_3) ? constant_3 : Space{});
    const Space v1359_5 = subtract(constant_1,v1359_4);
    Space v1359_8;
    if (!v1359_5.empty()) {
      const Path v1360_6 = concat_path(p0,v1358_13_head);
      Space v1360_7_result;
      for (int v1360_7_label = 1; v1360_7_label <= 2; ++v1360_7_label) {
        const Space v1360_7_tail = child(v1358_13_tail,v1360_7_label);
        if (v1360_7_tail.empty()) continue;
        const Path v1360_7_head{v1360_7_label};
        const Space v1361_2 = singleton(v1360_7_head);
        const Space v1361_3 = intersect(constant_2,v1361_2);
        const Space v1361_4 = (has_head(v1361_3) ? constant_3 : Space{});
        const Space v1361_5 = subtract(constant_1,v1361_4);
        Space v1361_8;
        if (!v1361_5.empty()) {
          const Path v1362_6 = concat_path(v1360_6,v1360_7_head);
          const Space v1362_7 = routine_178(c, v1362_6, p1, v1360_7_tail, s1);
          v1361_8 = compose(v1361_5,v1362_7);
        }
        const Space v1361_9 = intersect(constant_2,v1361_2);
        const Space v1361_10 = (has_head(v1361_9) ? constant_3 : Space{});
        Space v1361_12;
        if (!v1361_10.empty()) {
          const Path v1363_6 = concat_path(v1360_6,v1360_7_head);
          const Space v1363_11 = routine_179(c, v1363_6, p1, v1360_7_tail, s1);
          v1361_12 = compose(v1361_10,v1363_11);
        }
        const Space v1361_13 = unite(v1361_8,v1361_12);
        v1360_7_result = unite(v1360_7_result,v1361_13);
      }
      const Space v1360_7 = std::move(v1360_7_result);
      v1359_8 = compose(v1359_5,v1360_7);
    }
    const Space v1359_9 = intersect(constant_2,v1359_2);
    const Space v1359_10 = (has_head(v1359_9) ? constant_3 : Space{});
    Space v1359_12;
    if (!v1359_10.empty()) {
      const Path v1364_6 = concat_path(p0,v1358_13_head);
      Space v1364_11_result;
      for (int v1364_11_label = 1; v1364_11_label <= 2; ++v1364_11_label) {
        const Space v1364_11_tail = child(v1358_13_tail,v1364_11_label);
        if (v1364_11_tail.empty()) continue;
        const Path v1364_11_head{v1364_11_label};
        const Space v1365_2 = singleton(v1364_11_head);
        const Space v1365_3 = intersect(constant_2,v1365_2);
        const Space v1365_4 = (has_head(v1365_3) ? constant_3 : Space{});
        const Space v1365_5 = subtract(constant_1,v1365_4);
        Space v1365_8;
        if (!v1365_5.empty()) {
          const Path v1366_6 = concat_path(v1364_6,v1364_11_head);
          const Space v1366_7 = routine_178(c, v1366_6, p1, v1364_11_tail, s1);
          v1365_8 = compose(v1365_5,v1366_7);
        }
        const Space v1365_9 = intersect(constant_2,v1365_2);
        const Space v1365_10 = (has_head(v1365_9) ? constant_3 : Space{});
        Space v1365_12;
        if (!v1365_10.empty()) {
          const Path v1367_6 = concat_path(v1364_6,v1364_11_head);
          const Space v1367_11 = routine_36(c, v1367_6, p1, v1364_11_tail, s1);
          v1365_12 = compose(v1365_10,v1367_11);
        }
        const Space v1365_13 = unite(v1365_8,v1365_12);
        v1364_11_result = unite(v1364_11_result,v1365_13);
      }
      const Space v1364_11 = std::move(v1364_11_result);
      v1359_12 = compose(v1359_10,v1364_11);
    }
    const Space v1359_13 = unite(v1359_8,v1359_12);
    v1358_13_result = unite(v1358_13_result,v1359_13);
  }
  const Space v1358_13 = std::move(v1358_13_result);
  return v1358_13;
}

static Space routine_151(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1368_8 = unwrap(s1,constant_4);
  const Space v1368_10 = unwrap(v1368_8,constant_6);
  const Space v1368_11 = unwrap(v1368_10,p0);
  Space v1368_18_result;
  for (int v1368_18_label = 1; v1368_18_label <= 2; ++v1368_18_label) {
    const Space v1368_18_tail = child(s0,v1368_18_label);
    if (v1368_18_tail.empty()) continue;
    const Path v1368_18_head{v1368_18_label};
    const Space v1369_2 = singleton(v1368_18_head);
    const Space v1369_3 = intersect(constant_2,v1369_2);
    const Space v1369_4 = (has_head(v1369_3) ? constant_3 : Space{});
    const Space v1369_5 = subtract(constant_1,v1369_4);
    Space v1369_8;
    if (!v1369_5.empty()) {
      const Path v1370_6 = concat_path(p0,v1368_18_head);
      Space v1370_7_result;
      for (int v1370_7_label = 1; v1370_7_label <= 2; ++v1370_7_label) {
        const Space v1370_7_tail = child(v1368_18_tail,v1370_7_label);
        if (v1370_7_tail.empty()) continue;
        const Path v1370_7_head{v1370_7_label};
        const Space v1371_2 = singleton(v1370_7_head);
        const Space v1371_3 = intersect(constant_2,v1371_2);
        const Space v1371_4 = (has_head(v1371_3) ? constant_3 : Space{});
        const Space v1371_5 = subtract(constant_1,v1371_4);
        Space v1371_8;
        if (!v1371_5.empty()) {
          const Path v1372_6 = concat_path(v1370_6,v1370_7_head);
          const Space v1372_7 = routine_178(c, v1372_6, p1, v1370_7_tail, s1);
          v1371_8 = compose(v1371_5,v1372_7);
        }
        const Space v1371_9 = intersect(constant_2,v1371_2);
        const Space v1371_10 = (has_head(v1371_9) ? constant_3 : Space{});
        Space v1371_12;
        if (!v1371_10.empty()) {
          const Path v1373_6 = concat_path(v1370_6,v1370_7_head);
          const Space v1373_11 = routine_179(c, v1373_6, p1, v1370_7_tail, s1);
          v1371_12 = compose(v1371_10,v1373_11);
        }
        const Space v1371_13 = unite(v1371_8,v1371_12);
        v1370_7_result = unite(v1370_7_result,v1371_13);
      }
      const Space v1370_7 = std::move(v1370_7_result);
      v1369_8 = compose(v1369_5,v1370_7);
    }
    const Space v1369_9 = intersect(constant_2,v1369_2);
    const Space v1369_10 = (has_head(v1369_9) ? constant_3 : Space{});
    Space v1369_13;
    if (!v1369_10.empty()) {
      const Space v1374_11 = unwrap(v1368_11,v1368_18_head);
      Space v1374_12_result;
      for (int v1374_12_label = 1; v1374_12_label <= 2; ++v1374_12_label) {
        const Space v1374_12_tail = child(v1374_11,v1374_12_label);
        if (v1374_12_tail.empty()) continue;
        const Path v1374_12_head{v1374_12_label};
        const Space v1375_2 = singleton(v1374_12_head);
        const Space v1375_3 = intersect(constant_2,v1375_2);
        const Space v1375_4 = (has_head(v1375_3) ? constant_3 : Space{});
        const Space v1375_5 = subtract(constant_1,v1375_4);
        Space v1375_7;
        if (!v1375_5.empty()) {
          const Space v1376_6 = routine_72(c, v1374_12_head, p1, v1374_12_tail);
          v1375_7 = compose(v1375_5,v1376_6);
        }
        const Space v1375_8 = intersect(constant_2,v1375_2);
        const Space v1375_9 = (has_head(v1375_8) ? constant_3 : Space{});
        Space v1375_11;
        if (!v1375_9.empty()) {
          const Space v1377_10 = routine_73(c, v1374_12_head, p1, v1374_12_tail);
          v1375_11 = compose(v1375_9,v1377_10);
        }
        const Space v1375_12 = unite(v1375_7,v1375_11);
        v1374_12_result = unite(v1374_12_result,v1375_12);
      }
      const Space v1374_12 = std::move(v1374_12_result);
      v1369_13 = compose(v1369_10,v1374_12);
    }
    const Space v1369_14 = unite(v1369_8,v1369_13);
    v1368_18_result = unite(v1368_18_result,v1369_14);
  }
  const Space v1368_18 = std::move(v1368_18_result);
  return v1368_18;
}

static Space routine_152(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1378_12_result;
  for (int v1378_12_label = 1; v1378_12_label <= 2; ++v1378_12_label) {
    const Space v1378_12_tail = child(s0,v1378_12_label);
    if (v1378_12_tail.empty()) continue;
    const Path v1378_12_head{v1378_12_label};
    const Space v1379_2 = singleton(v1378_12_head);
    const Space v1379_3 = intersect(constant_2,v1379_2);
    const Space v1379_4 = (has_head(v1379_3) ? constant_3 : Space{});
    const Space v1379_5 = subtract(constant_1,v1379_4);
    Space v1379_8;
    if (!v1379_5.empty()) {
      const Path v1380_6 = concat_path(p0,v1378_12_head);
      Space v1380_7_result;
      for (int v1380_7_label = 1; v1380_7_label <= 2; ++v1380_7_label) {
        const Space v1380_7_tail = child(v1378_12_tail,v1380_7_label);
        if (v1380_7_tail.empty()) continue;
        const Path v1380_7_head{v1380_7_label};
        const Space v1381_2 = singleton(v1380_7_head);
        const Space v1381_3 = intersect(constant_2,v1381_2);
        const Space v1381_4 = (has_head(v1381_3) ? constant_3 : Space{});
        const Space v1381_5 = subtract(constant_1,v1381_4);
        Space v1381_8;
        if (!v1381_5.empty()) {
          const Path v1382_6 = concat_path(v1380_6,v1380_7_head);
          const Space v1382_7 = routine_180(c, v1382_6, p1, v1380_7_tail);
          v1381_8 = compose(v1381_5,v1382_7);
        }
        const Space v1381_9 = intersect(constant_2,v1381_2);
        const Space v1381_10 = (has_head(v1381_9) ? constant_3 : Space{});
        Space v1381_12;
        if (!v1381_10.empty()) {
          const Path v1383_6 = concat_path(v1380_6,v1380_7_head);
          const Space v1383_11 = routine_181(c, v1383_6, p1, v1380_7_tail);
          v1381_12 = compose(v1381_10,v1383_11);
        }
        const Space v1381_13 = unite(v1381_8,v1381_12);
        v1380_7_result = unite(v1380_7_result,v1381_13);
      }
      const Space v1380_7 = std::move(v1380_7_result);
      v1379_8 = compose(v1379_5,v1380_7);
    }
    const Space v1379_9 = intersect(constant_2,v1379_2);
    const Space v1379_10 = (has_head(v1379_9) ? constant_3 : Space{});
    Space v1379_12;
    if (!v1379_10.empty()) {
      const Path v1384_6 = concat_path(p0,v1378_12_head);
      Space v1384_11_result;
      for (int v1384_11_label = 1; v1384_11_label <= 2; ++v1384_11_label) {
        const Space v1384_11_tail = child(v1378_12_tail,v1384_11_label);
        if (v1384_11_tail.empty()) continue;
        const Path v1384_11_head{v1384_11_label};
        const Space v1385_2 = singleton(v1384_11_head);
        const Space v1385_3 = intersect(constant_2,v1385_2);
        const Space v1385_4 = (has_head(v1385_3) ? constant_3 : Space{});
        const Space v1385_5 = subtract(constant_1,v1385_4);
        Space v1385_8;
        if (!v1385_5.empty()) {
          const Path v1386_6 = concat_path(v1384_6,v1384_11_head);
          const Space v1386_7 = routine_180(c, v1386_6, p1, v1384_11_tail);
          v1385_8 = compose(v1385_5,v1386_7);
        }
        const Space v1385_9 = intersect(constant_2,v1385_2);
        const Space v1385_10 = (has_head(v1385_9) ? constant_3 : Space{});
        Space v1385_12;
        if (!v1385_10.empty()) {
          const Path v1387_6 = concat_path(v1384_6,v1384_11_head);
          const Space v1387_11 = routine_78(c, v1387_6, p1, v1384_11_tail);
          v1385_12 = compose(v1385_10,v1387_11);
        }
        const Space v1385_13 = unite(v1385_8,v1385_12);
        v1384_11_result = unite(v1384_11_result,v1385_13);
      }
      const Space v1384_11 = std::move(v1384_11_result);
      v1379_12 = compose(v1379_10,v1384_11);
    }
    const Space v1379_13 = unite(v1379_8,v1379_12);
    v1378_12_result = unite(v1378_12_result,v1379_13);
  }
  const Space v1378_12 = std::move(v1378_12_result);
  return v1378_12;
}

static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1388_9_result;
  for (int v1388_9_label = 1; v1388_9_label <= 2; ++v1388_9_label) {
    const Space v1388_9_tail = child(s0,v1388_9_label);
    if (v1388_9_tail.empty()) continue;
    const Path v1388_9_head{v1388_9_label};
    const Space v1389_2 = singleton(v1388_9_head);
    const Space v1389_3 = intersect(constant_2,v1389_2);
    const Space v1389_4 = (has_head(v1389_3) ? constant_3 : Space{});
    const Space v1389_5 = subtract(constant_1,v1389_4);
    Space v1389_8;
    if (!v1389_5.empty()) {
      const Path v1390_6 = concat_path(p0,v1388_9_head);
      Space v1390_7_result;
      for (int v1390_7_label = 1; v1390_7_label <= 2; ++v1390_7_label) {
        const Space v1390_7_tail = child(v1388_9_tail,v1390_7_label);
        if (v1390_7_tail.empty()) continue;
        const Path v1390_7_head{v1390_7_label};
        const Space v1391_2 = singleton(v1390_7_head);
        const Space v1391_3 = intersect(constant_2,v1391_2);
        const Space v1391_4 = (has_head(v1391_3) ? constant_3 : Space{});
        const Space v1391_5 = subtract(constant_1,v1391_4);
        Space v1391_8;
        if (!v1391_5.empty()) {
          const Path v1392_6 = concat_path(v1390_6,v1390_7_head);
          const Space v1392_7 = routine_180(c, v1392_6, p1, v1390_7_tail);
          v1391_8 = compose(v1391_5,v1392_7);
        }
        const Space v1391_9 = intersect(constant_2,v1391_2);
        const Space v1391_10 = (has_head(v1391_9) ? constant_3 : Space{});
        Space v1391_12;
        if (!v1391_10.empty()) {
          const Path v1393_6 = concat_path(v1390_6,v1390_7_head);
          const Space v1393_11 = routine_181(c, v1393_6, p1, v1390_7_tail);
          v1391_12 = compose(v1391_10,v1393_11);
        }
        const Space v1391_13 = unite(v1391_8,v1391_12);
        v1390_7_result = unite(v1390_7_result,v1391_13);
      }
      const Space v1390_7 = std::move(v1390_7_result);
      v1389_8 = compose(v1389_5,v1390_7);
    }
    const Space v1389_9 = intersect(constant_2,v1389_2);
    const Space v1389_10 = (has_head(v1389_9) ? constant_3 : Space{});
    const Space v1389_11 = compose(v1389_10,v1388_9_tail);
    const Path v1394_6 = concat_path(p0,v1388_9_head);
    const Space v1389_12 = wrap(v1389_11,v1394_6);
    const Space v1389_13 = wrap(v1389_12,p1);
    const Space v1389_14 = unite(v1389_8,v1389_13);
    v1388_9_result = unite(v1388_9_result,v1389_14);
  }
  const Space v1388_9 = std::move(v1388_9_result);
  return v1388_9;
}

static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1395_8_result;
  for (int v1395_8_label = 1; v1395_8_label <= 2; ++v1395_8_label) {
    const Space v1395_8_tail = child(s0,v1395_8_label);
    if (v1395_8_tail.empty()) continue;
    const Path v1395_8_head{v1395_8_label};
    const Space v1396_2 = singleton(v1395_8_head);
    const Space v1396_3 = intersect(constant_2,v1396_2);
    const Space v1396_4 = (has_head(v1396_3) ? constant_3 : Space{});
    const Space v1396_5 = subtract(constant_1,v1396_4);
    Space v1396_6_result;
    for (int v1396_6_label = 1; v1396_6_label <= 2; ++v1396_6_label) {
      const Space v1396_6_tail = child(v1395_8_tail,v1396_6_label);
      if (v1396_6_tail.empty()) continue;
      const Path v1396_6_head{v1396_6_label};
      const Space v1397_2 = Space{};
      v1396_6_result = unite(v1396_6_result,v1397_2);
    }
    const Space v1396_6 = std::move(v1396_6_result);
    const Space v1396_7 = compose(v1396_5,v1396_6);
    const Space v1396_8 = intersect(constant_2,v1396_2);
    const Space v1396_9 = (has_head(v1396_8) ? constant_3 : Space{});
    Space v1396_12;
    if (!v1396_9.empty()) {
      const Path v1398_10 = concat_path(p0,v1395_8_head);
      Space v1398_11_result;
      for (int v1398_11_label = 1; v1398_11_label <= 2; ++v1398_11_label) {
        const Space v1398_11_tail = child(v1395_8_tail,v1398_11_label);
        if (v1398_11_tail.empty()) continue;
        const Path v1398_11_head{v1398_11_label};
        const Space v1399_2 = singleton(v1398_11_head);
        const Space v1399_3 = intersect(constant_2,v1399_2);
        const Space v1399_4 = (has_head(v1399_3) ? constant_3 : Space{});
        Space v1399_7;
        if (!v1399_4.empty()) {
          const Path v1400_5 = concat_path(v1398_10,v1398_11_head);
          const Space v1400_6 = routine_36(c, v1400_5, p1, v1398_11_tail, s1);
          v1399_7 = compose(v1399_4,v1400_6);
        }
        v1398_11_result = unite(v1398_11_result,v1399_7);
      }
      const Space v1398_11 = std::move(v1398_11_result);
      v1396_12 = compose(v1396_9,v1398_11);
    }
    const Space v1396_13 = unite(v1396_7,v1396_12);
    v1395_8_result = unite(v1395_8_result,v1396_13);
  }
  const Space v1395_8 = std::move(v1395_8_result);
  return v1395_8;
}

static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1401_8 = unwrap(s1,constant_4);
  const Space v1401_10 = unwrap(v1401_8,constant_6);
  const Space v1401_11 = unwrap(v1401_10,p0);
  Space v1401_15_result;
  for (int v1401_15_label = 1; v1401_15_label <= 2; ++v1401_15_label) {
    const Space v1401_15_tail = child(s0,v1401_15_label);
    if (v1401_15_tail.empty()) continue;
    const Path v1401_15_head{v1401_15_label};
    const Space v1402_2 = singleton(v1401_15_head);
    const Space v1402_3 = intersect(constant_2,v1402_2);
    const Space v1402_4 = (has_head(v1402_3) ? constant_3 : Space{});
    const Space v1402_5 = subtract(constant_1,v1402_4);
    Space v1402_6_result;
    for (int v1402_6_label = 1; v1402_6_label <= 2; ++v1402_6_label) {
      const Space v1402_6_tail = child(v1401_15_tail,v1402_6_label);
      if (v1402_6_tail.empty()) continue;
      const Path v1402_6_head{v1402_6_label};
      const Space v1403_2 = Space{};
      v1402_6_result = unite(v1402_6_result,v1403_2);
    }
    const Space v1402_6 = std::move(v1402_6_result);
    const Space v1402_7 = compose(v1402_5,v1402_6);
    const Space v1402_8 = intersect(constant_2,v1402_2);
    const Space v1402_9 = (has_head(v1402_8) ? constant_3 : Space{});
    Space v1402_12;
    if (!v1402_9.empty()) {
      const Space v1404_10 = unwrap(v1401_11,v1401_15_head);
      Space v1404_11_result;
      for (int v1404_11_label = 1; v1404_11_label <= 2; ++v1404_11_label) {
        const Space v1404_11_tail = child(v1404_10,v1404_11_label);
        if (v1404_11_tail.empty()) continue;
        const Path v1404_11_head{v1404_11_label};
        const Space v1405_2 = singleton(v1404_11_head);
        const Space v1405_3 = intersect(constant_2,v1405_2);
        const Space v1405_4 = (has_head(v1405_3) ? constant_3 : Space{});
        const Space v1405_5 = subtract(constant_1,v1405_4);
        Space v1405_7;
        if (!v1405_5.empty()) {
          const Space v1406_6 = routine_72(c, v1404_11_head, p1, v1404_11_tail);
          v1405_7 = compose(v1405_5,v1406_6);
        }
        const Space v1405_8 = intersect(constant_2,v1405_2);
        const Space v1405_9 = (has_head(v1405_8) ? constant_3 : Space{});
        Space v1405_11;
        if (!v1405_9.empty()) {
          const Space v1407_10 = routine_73(c, v1404_11_head, p1, v1404_11_tail);
          v1405_11 = compose(v1405_9,v1407_10);
        }
        const Space v1405_12 = unite(v1405_7,v1405_11);
        v1404_11_result = unite(v1404_11_result,v1405_12);
      }
      const Space v1404_11 = std::move(v1404_11_result);
      v1402_12 = compose(v1402_9,v1404_11);
    }
    const Space v1402_13 = unite(v1402_7,v1402_12);
    v1401_15_result = unite(v1401_15_result,v1402_13);
  }
  const Space v1401_15 = std::move(v1401_15_result);
  return v1401_15;
}

static Space routine_156(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1408_12_result;
  for (int v1408_12_label = 1; v1408_12_label <= 2; ++v1408_12_label) {
    const Space v1408_12_tail = child(s0,v1408_12_label);
    if (v1408_12_tail.empty()) continue;
    const Path v1408_12_head{v1408_12_label};
    const Space v1409_2 = singleton(v1408_12_head);
    const Space v1409_3 = intersect(constant_2,v1409_2);
    const Space v1409_4 = (has_head(v1409_3) ? constant_3 : Space{});
    const Space v1409_5 = subtract(constant_1,v1409_4);
    Space v1409_8;
    if (!v1409_5.empty()) {
      const Path v1410_6 = concat_path(p0,v1408_12_head);
      Space v1410_7_result;
      for (int v1410_7_label = 1; v1410_7_label <= 2; ++v1410_7_label) {
        const Space v1410_7_tail = child(v1408_12_tail,v1410_7_label);
        if (v1410_7_tail.empty()) continue;
        const Path v1410_7_head{v1410_7_label};
        const Space v1411_2 = singleton(v1410_7_head);
        const Space v1411_3 = intersect(constant_2,v1411_2);
        const Space v1411_4 = (has_head(v1411_3) ? constant_3 : Space{});
        const Space v1411_5 = subtract(constant_1,v1411_4);
        Space v1411_8;
        if (!v1411_5.empty()) {
          const Path v1412_6 = concat_path(v1410_6,v1410_7_head);
          const Space v1412_7 = routine_182(c, v1412_6, p1, v1410_7_tail);
          v1411_8 = compose(v1411_5,v1412_7);
        }
        const Space v1411_9 = intersect(constant_2,v1411_2);
        const Space v1411_10 = (has_head(v1411_9) ? constant_3 : Space{});
        Space v1411_12;
        if (!v1411_10.empty()) {
          const Path v1413_6 = concat_path(v1410_6,v1410_7_head);
          const Space v1413_11 = routine_183(c, v1413_6, p1, v1410_7_tail);
          v1411_12 = compose(v1411_10,v1413_11);
        }
        const Space v1411_13 = unite(v1411_8,v1411_12);
        v1410_7_result = unite(v1410_7_result,v1411_13);
      }
      const Space v1410_7 = std::move(v1410_7_result);
      v1409_8 = compose(v1409_5,v1410_7);
    }
    const Space v1409_9 = intersect(constant_2,v1409_2);
    const Space v1409_10 = (has_head(v1409_9) ? constant_3 : Space{});
    Space v1409_12;
    if (!v1409_10.empty()) {
      const Path v1414_6 = concat_path(p0,v1408_12_head);
      Space v1414_11_result;
      for (int v1414_11_label = 1; v1414_11_label <= 2; ++v1414_11_label) {
        const Space v1414_11_tail = child(v1408_12_tail,v1414_11_label);
        if (v1414_11_tail.empty()) continue;
        const Path v1414_11_head{v1414_11_label};
        const Space v1415_2 = singleton(v1414_11_head);
        const Space v1415_3 = intersect(constant_2,v1415_2);
        const Space v1415_4 = (has_head(v1415_3) ? constant_3 : Space{});
        const Space v1415_5 = subtract(constant_1,v1415_4);
        Space v1415_8;
        if (!v1415_5.empty()) {
          const Path v1416_6 = concat_path(v1414_6,v1414_11_head);
          const Space v1416_7 = routine_182(c, v1416_6, p1, v1414_11_tail);
          v1415_8 = compose(v1415_5,v1416_7);
        }
        const Space v1415_9 = intersect(constant_2,v1415_2);
        const Space v1415_10 = (has_head(v1415_9) ? constant_3 : Space{});
        Space v1415_12;
        if (!v1415_10.empty()) {
          const Path v1417_6 = concat_path(v1414_6,v1414_11_head);
          const Space v1417_11 = routine_78(c, v1417_6, p1, v1414_11_tail);
          v1415_12 = compose(v1415_10,v1417_11);
        }
        const Space v1415_13 = unite(v1415_8,v1415_12);
        v1414_11_result = unite(v1414_11_result,v1415_13);
      }
      const Space v1414_11 = std::move(v1414_11_result);
      v1409_12 = compose(v1409_10,v1414_11);
    }
    const Space v1409_13 = unite(v1409_8,v1409_12);
    v1408_12_result = unite(v1408_12_result,v1409_13);
  }
  const Space v1408_12 = std::move(v1408_12_result);
  return v1408_12;
}

static Space routine_157(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1418_9_result;
  for (int v1418_9_label = 1; v1418_9_label <= 2; ++v1418_9_label) {
    const Space v1418_9_tail = child(s0,v1418_9_label);
    if (v1418_9_tail.empty()) continue;
    const Path v1418_9_head{v1418_9_label};
    const Space v1419_2 = singleton(v1418_9_head);
    const Space v1419_3 = intersect(constant_2,v1419_2);
    const Space v1419_4 = (has_head(v1419_3) ? constant_3 : Space{});
    const Space v1419_5 = subtract(constant_1,v1419_4);
    Space v1419_8;
    if (!v1419_5.empty()) {
      const Path v1420_6 = concat_path(p0,v1418_9_head);
      Space v1420_7_result;
      for (int v1420_7_label = 1; v1420_7_label <= 2; ++v1420_7_label) {
        const Space v1420_7_tail = child(v1418_9_tail,v1420_7_label);
        if (v1420_7_tail.empty()) continue;
        const Path v1420_7_head{v1420_7_label};
        const Space v1421_2 = singleton(v1420_7_head);
        const Space v1421_3 = intersect(constant_2,v1421_2);
        const Space v1421_4 = (has_head(v1421_3) ? constant_3 : Space{});
        const Space v1421_5 = subtract(constant_1,v1421_4);
        Space v1421_8;
        if (!v1421_5.empty()) {
          const Path v1422_6 = concat_path(v1420_6,v1420_7_head);
          const Space v1422_7 = routine_182(c, v1422_6, p1, v1420_7_tail);
          v1421_8 = compose(v1421_5,v1422_7);
        }
        const Space v1421_9 = intersect(constant_2,v1421_2);
        const Space v1421_10 = (has_head(v1421_9) ? constant_3 : Space{});
        Space v1421_12;
        if (!v1421_10.empty()) {
          const Path v1423_6 = concat_path(v1420_6,v1420_7_head);
          const Space v1423_11 = routine_183(c, v1423_6, p1, v1420_7_tail);
          v1421_12 = compose(v1421_10,v1423_11);
        }
        const Space v1421_13 = unite(v1421_8,v1421_12);
        v1420_7_result = unite(v1420_7_result,v1421_13);
      }
      const Space v1420_7 = std::move(v1420_7_result);
      v1419_8 = compose(v1419_5,v1420_7);
    }
    const Space v1419_9 = intersect(constant_2,v1419_2);
    const Space v1419_10 = (has_head(v1419_9) ? constant_3 : Space{});
    const Space v1419_11 = compose(v1419_10,v1418_9_tail);
    const Path v1424_6 = concat_path(p0,v1418_9_head);
    const Space v1419_12 = wrap(v1419_11,v1424_6);
    const Space v1419_13 = wrap(v1419_12,p1);
    const Space v1419_14 = unite(v1419_8,v1419_13);
    v1418_9_result = unite(v1418_9_result,v1419_14);
  }
  const Space v1418_9 = std::move(v1418_9_result);
  return v1418_9;
}

static Space routine_158(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1425_13_result;
  for (int v1425_13_label = 1; v1425_13_label <= 2; ++v1425_13_label) {
    const Space v1425_13_tail = child(s0,v1425_13_label);
    if (v1425_13_tail.empty()) continue;
    const Path v1425_13_head{v1425_13_label};
    const Space v1426_2 = singleton(v1425_13_head);
    const Space v1426_3 = intersect(constant_2,v1426_2);
    const Space v1426_4 = (has_head(v1426_3) ? constant_3 : Space{});
    const Space v1426_5 = subtract(constant_1,v1426_4);
    Space v1426_8;
    if (!v1426_5.empty()) {
      const Path v1427_6 = concat_path(p0,v1425_13_head);
      Space v1427_7_result;
      for (int v1427_7_label = 1; v1427_7_label <= 2; ++v1427_7_label) {
        const Space v1427_7_tail = child(v1425_13_tail,v1427_7_label);
        if (v1427_7_tail.empty()) continue;
        const Path v1427_7_head{v1427_7_label};
        const Space v1428_2 = singleton(v1427_7_head);
        const Space v1428_3 = intersect(constant_2,v1428_2);
        const Space v1428_4 = (has_head(v1428_3) ? constant_3 : Space{});
        const Space v1428_5 = subtract(constant_1,v1428_4);
        Space v1428_8;
        if (!v1428_5.empty()) {
          const Path v1429_6 = concat_path(v1427_6,v1427_7_head);
          const Space v1429_7 = routine_184(c, v1429_6, p1, v1427_7_tail, s1);
          v1428_8 = compose(v1428_5,v1429_7);
        }
        const Space v1428_9 = intersect(constant_2,v1428_2);
        const Space v1428_10 = (has_head(v1428_9) ? constant_3 : Space{});
        Space v1428_12;
        if (!v1428_10.empty()) {
          const Path v1430_6 = concat_path(v1427_6,v1427_7_head);
          const Space v1430_11 = routine_185(c, v1430_6, p1, v1427_7_tail, s1);
          v1428_12 = compose(v1428_10,v1430_11);
        }
        const Space v1428_13 = unite(v1428_8,v1428_12);
        v1427_7_result = unite(v1427_7_result,v1428_13);
      }
      const Space v1427_7 = std::move(v1427_7_result);
      v1426_8 = compose(v1426_5,v1427_7);
    }
    const Space v1426_9 = intersect(constant_2,v1426_2);
    const Space v1426_10 = (has_head(v1426_9) ? constant_3 : Space{});
    Space v1426_12;
    if (!v1426_10.empty()) {
      const Path v1431_6 = concat_path(p0,v1425_13_head);
      Space v1431_11_result;
      for (int v1431_11_label = 1; v1431_11_label <= 2; ++v1431_11_label) {
        const Space v1431_11_tail = child(v1425_13_tail,v1431_11_label);
        if (v1431_11_tail.empty()) continue;
        const Path v1431_11_head{v1431_11_label};
        const Space v1432_2 = singleton(v1431_11_head);
        const Space v1432_3 = intersect(constant_2,v1432_2);
        const Space v1432_4 = (has_head(v1432_3) ? constant_3 : Space{});
        const Space v1432_5 = subtract(constant_1,v1432_4);
        Space v1432_8;
        if (!v1432_5.empty()) {
          const Path v1433_6 = concat_path(v1431_6,v1431_11_head);
          const Space v1433_7 = routine_184(c, v1433_6, p1, v1431_11_tail, s1);
          v1432_8 = compose(v1432_5,v1433_7);
        }
        const Space v1432_9 = intersect(constant_2,v1432_2);
        const Space v1432_10 = (has_head(v1432_9) ? constant_3 : Space{});
        Space v1432_12;
        if (!v1432_10.empty()) {
          const Path v1434_6 = concat_path(v1431_6,v1431_11_head);
          const Space v1434_11 = routine_43(c, v1434_6, p1, v1431_11_tail, s1);
          v1432_12 = compose(v1432_10,v1434_11);
        }
        const Space v1432_13 = unite(v1432_8,v1432_12);
        v1431_11_result = unite(v1431_11_result,v1432_13);
      }
      const Space v1431_11 = std::move(v1431_11_result);
      v1426_12 = compose(v1426_10,v1431_11);
    }
    const Space v1426_13 = unite(v1426_8,v1426_12);
    v1425_13_result = unite(v1425_13_result,v1426_13);
  }
  const Space v1425_13 = std::move(v1425_13_result);
  return v1425_13;
}

static Space routine_159(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1435_8 = unwrap(s1,constant_4);
  const Space v1435_10 = unwrap(v1435_8,constant_6);
  const Space v1435_11 = unwrap(v1435_10,p0);
  Space v1435_18_result;
  for (int v1435_18_label = 1; v1435_18_label <= 2; ++v1435_18_label) {
    const Space v1435_18_tail = child(s0,v1435_18_label);
    if (v1435_18_tail.empty()) continue;
    const Path v1435_18_head{v1435_18_label};
    const Space v1436_2 = singleton(v1435_18_head);
    const Space v1436_3 = intersect(constant_2,v1436_2);
    const Space v1436_4 = (has_head(v1436_3) ? constant_3 : Space{});
    const Space v1436_5 = subtract(constant_1,v1436_4);
    Space v1436_8;
    if (!v1436_5.empty()) {
      const Path v1437_6 = concat_path(p0,v1435_18_head);
      Space v1437_7_result;
      for (int v1437_7_label = 1; v1437_7_label <= 2; ++v1437_7_label) {
        const Space v1437_7_tail = child(v1435_18_tail,v1437_7_label);
        if (v1437_7_tail.empty()) continue;
        const Path v1437_7_head{v1437_7_label};
        const Space v1438_2 = singleton(v1437_7_head);
        const Space v1438_3 = intersect(constant_2,v1438_2);
        const Space v1438_4 = (has_head(v1438_3) ? constant_3 : Space{});
        const Space v1438_5 = subtract(constant_1,v1438_4);
        Space v1438_8;
        if (!v1438_5.empty()) {
          const Path v1439_6 = concat_path(v1437_6,v1437_7_head);
          const Space v1439_7 = routine_184(c, v1439_6, p1, v1437_7_tail, s1);
          v1438_8 = compose(v1438_5,v1439_7);
        }
        const Space v1438_9 = intersect(constant_2,v1438_2);
        const Space v1438_10 = (has_head(v1438_9) ? constant_3 : Space{});
        Space v1438_12;
        if (!v1438_10.empty()) {
          const Path v1440_6 = concat_path(v1437_6,v1437_7_head);
          const Space v1440_11 = routine_185(c, v1440_6, p1, v1437_7_tail, s1);
          v1438_12 = compose(v1438_10,v1440_11);
        }
        const Space v1438_13 = unite(v1438_8,v1438_12);
        v1437_7_result = unite(v1437_7_result,v1438_13);
      }
      const Space v1437_7 = std::move(v1437_7_result);
      v1436_8 = compose(v1436_5,v1437_7);
    }
    const Space v1436_9 = intersect(constant_2,v1436_2);
    const Space v1436_10 = (has_head(v1436_9) ? constant_3 : Space{});
    Space v1436_13;
    if (!v1436_10.empty()) {
      const Space v1441_11 = unwrap(v1435_11,v1435_18_head);
      Space v1441_12_result;
      for (int v1441_12_label = 1; v1441_12_label <= 2; ++v1441_12_label) {
        const Space v1441_12_tail = child(v1441_11,v1441_12_label);
        if (v1441_12_tail.empty()) continue;
        const Path v1441_12_head{v1441_12_label};
        const Space v1442_2 = singleton(v1441_12_head);
        const Space v1442_3 = intersect(constant_2,v1442_2);
        const Space v1442_4 = (has_head(v1442_3) ? constant_3 : Space{});
        const Space v1442_5 = subtract(constant_1,v1442_4);
        Space v1442_7;
        if (!v1442_5.empty()) {
          const Space v1443_6 = routine_83(c, v1441_12_head, p1, v1441_12_tail);
          v1442_7 = compose(v1442_5,v1443_6);
        }
        const Space v1442_8 = intersect(constant_2,v1442_2);
        const Space v1442_9 = (has_head(v1442_8) ? constant_3 : Space{});
        Space v1442_11;
        if (!v1442_9.empty()) {
          const Space v1444_10 = routine_84(c, v1441_12_head, p1, v1441_12_tail);
          v1442_11 = compose(v1442_9,v1444_10);
        }
        const Space v1442_12 = unite(v1442_7,v1442_11);
        v1441_12_result = unite(v1441_12_result,v1442_12);
      }
      const Space v1441_12 = std::move(v1441_12_result);
      v1436_13 = compose(v1436_10,v1441_12);
    }
    const Space v1436_14 = unite(v1436_8,v1436_13);
    v1435_18_result = unite(v1435_18_result,v1436_14);
  }
  const Space v1435_18 = std::move(v1435_18_result);
  return v1435_18;
}

static Space routine_160(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1445_12_result;
  for (int v1445_12_label = 1; v1445_12_label <= 2; ++v1445_12_label) {
    const Space v1445_12_tail = child(s0,v1445_12_label);
    if (v1445_12_tail.empty()) continue;
    const Path v1445_12_head{v1445_12_label};
    const Space v1446_2 = singleton(v1445_12_head);
    const Space v1446_3 = intersect(constant_2,v1446_2);
    const Space v1446_4 = (has_head(v1446_3) ? constant_3 : Space{});
    const Space v1446_5 = subtract(constant_1,v1446_4);
    Space v1446_8;
    if (!v1446_5.empty()) {
      const Path v1447_6 = concat_path(p0,v1445_12_head);
      Space v1447_7_result;
      for (int v1447_7_label = 1; v1447_7_label <= 2; ++v1447_7_label) {
        const Space v1447_7_tail = child(v1445_12_tail,v1447_7_label);
        if (v1447_7_tail.empty()) continue;
        const Path v1447_7_head{v1447_7_label};
        const Space v1448_2 = singleton(v1447_7_head);
        const Space v1448_3 = intersect(constant_2,v1448_2);
        const Space v1448_4 = (has_head(v1448_3) ? constant_3 : Space{});
        const Space v1448_5 = subtract(constant_1,v1448_4);
        Space v1448_8;
        if (!v1448_5.empty()) {
          const Path v1449_6 = concat_path(v1447_6,v1447_7_head);
          const Space v1449_7 = routine_186(c, v1449_6, p1, v1447_7_tail);
          v1448_8 = compose(v1448_5,v1449_7);
        }
        const Space v1448_9 = intersect(constant_2,v1448_2);
        const Space v1448_10 = (has_head(v1448_9) ? constant_3 : Space{});
        Space v1448_12;
        if (!v1448_10.empty()) {
          const Path v1450_6 = concat_path(v1447_6,v1447_7_head);
          const Space v1450_11 = routine_187(c, v1450_6, p1, v1447_7_tail);
          v1448_12 = compose(v1448_10,v1450_11);
        }
        const Space v1448_13 = unite(v1448_8,v1448_12);
        v1447_7_result = unite(v1447_7_result,v1448_13);
      }
      const Space v1447_7 = std::move(v1447_7_result);
      v1446_8 = compose(v1446_5,v1447_7);
    }
    const Space v1446_9 = intersect(constant_2,v1446_2);
    const Space v1446_10 = (has_head(v1446_9) ? constant_3 : Space{});
    Space v1446_12;
    if (!v1446_10.empty()) {
      const Path v1451_6 = concat_path(p0,v1445_12_head);
      Space v1451_11_result;
      for (int v1451_11_label = 1; v1451_11_label <= 2; ++v1451_11_label) {
        const Space v1451_11_tail = child(v1445_12_tail,v1451_11_label);
        if (v1451_11_tail.empty()) continue;
        const Path v1451_11_head{v1451_11_label};
        const Space v1452_2 = singleton(v1451_11_head);
        const Space v1452_3 = intersect(constant_2,v1452_2);
        const Space v1452_4 = (has_head(v1452_3) ? constant_3 : Space{});
        const Space v1452_5 = subtract(constant_1,v1452_4);
        Space v1452_8;
        if (!v1452_5.empty()) {
          const Path v1453_6 = concat_path(v1451_6,v1451_11_head);
          const Space v1453_7 = routine_186(c, v1453_6, p1, v1451_11_tail);
          v1452_8 = compose(v1452_5,v1453_7);
        }
        const Space v1452_9 = intersect(constant_2,v1452_2);
        const Space v1452_10 = (has_head(v1452_9) ? constant_3 : Space{});
        Space v1452_12;
        if (!v1452_10.empty()) {
          const Path v1454_6 = concat_path(v1451_6,v1451_11_head);
          const Space v1454_11 = routine_89(c, v1454_6, p1, v1451_11_tail);
          v1452_12 = compose(v1452_10,v1454_11);
        }
        const Space v1452_13 = unite(v1452_8,v1452_12);
        v1451_11_result = unite(v1451_11_result,v1452_13);
      }
      const Space v1451_11 = std::move(v1451_11_result);
      v1446_12 = compose(v1446_10,v1451_11);
    }
    const Space v1446_13 = unite(v1446_8,v1446_12);
    v1445_12_result = unite(v1445_12_result,v1446_13);
  }
  const Space v1445_12 = std::move(v1445_12_result);
  return v1445_12;
}

static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1455_9_result;
  for (int v1455_9_label = 1; v1455_9_label <= 2; ++v1455_9_label) {
    const Space v1455_9_tail = child(s0,v1455_9_label);
    if (v1455_9_tail.empty()) continue;
    const Path v1455_9_head{v1455_9_label};
    const Space v1456_2 = singleton(v1455_9_head);
    const Space v1456_3 = intersect(constant_2,v1456_2);
    const Space v1456_4 = (has_head(v1456_3) ? constant_3 : Space{});
    const Space v1456_5 = subtract(constant_1,v1456_4);
    Space v1456_8;
    if (!v1456_5.empty()) {
      const Path v1457_6 = concat_path(p0,v1455_9_head);
      Space v1457_7_result;
      for (int v1457_7_label = 1; v1457_7_label <= 2; ++v1457_7_label) {
        const Space v1457_7_tail = child(v1455_9_tail,v1457_7_label);
        if (v1457_7_tail.empty()) continue;
        const Path v1457_7_head{v1457_7_label};
        const Space v1458_2 = singleton(v1457_7_head);
        const Space v1458_3 = intersect(constant_2,v1458_2);
        const Space v1458_4 = (has_head(v1458_3) ? constant_3 : Space{});
        const Space v1458_5 = subtract(constant_1,v1458_4);
        Space v1458_8;
        if (!v1458_5.empty()) {
          const Path v1459_6 = concat_path(v1457_6,v1457_7_head);
          const Space v1459_7 = routine_186(c, v1459_6, p1, v1457_7_tail);
          v1458_8 = compose(v1458_5,v1459_7);
        }
        const Space v1458_9 = intersect(constant_2,v1458_2);
        const Space v1458_10 = (has_head(v1458_9) ? constant_3 : Space{});
        Space v1458_12;
        if (!v1458_10.empty()) {
          const Path v1460_6 = concat_path(v1457_6,v1457_7_head);
          const Space v1460_11 = routine_187(c, v1460_6, p1, v1457_7_tail);
          v1458_12 = compose(v1458_10,v1460_11);
        }
        const Space v1458_13 = unite(v1458_8,v1458_12);
        v1457_7_result = unite(v1457_7_result,v1458_13);
      }
      const Space v1457_7 = std::move(v1457_7_result);
      v1456_8 = compose(v1456_5,v1457_7);
    }
    const Space v1456_9 = intersect(constant_2,v1456_2);
    const Space v1456_10 = (has_head(v1456_9) ? constant_3 : Space{});
    const Space v1456_11 = compose(v1456_10,v1455_9_tail);
    const Path v1461_6 = concat_path(p0,v1455_9_head);
    const Space v1456_12 = wrap(v1456_11,v1461_6);
    const Space v1456_13 = wrap(v1456_12,p1);
    const Space v1456_14 = unite(v1456_8,v1456_13);
    v1455_9_result = unite(v1455_9_result,v1456_14);
  }
  const Space v1455_9 = std::move(v1455_9_result);
  return v1455_9;
}

static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1462_8_result;
  for (int v1462_8_label = 1; v1462_8_label <= 2; ++v1462_8_label) {
    const Space v1462_8_tail = child(s0,v1462_8_label);
    if (v1462_8_tail.empty()) continue;
    const Path v1462_8_head{v1462_8_label};
    const Space v1463_2 = singleton(v1462_8_head);
    const Space v1463_3 = intersect(constant_2,v1463_2);
    const Space v1463_4 = (has_head(v1463_3) ? constant_3 : Space{});
    const Space v1463_5 = subtract(constant_1,v1463_4);
    Space v1463_6_result;
    for (int v1463_6_label = 1; v1463_6_label <= 2; ++v1463_6_label) {
      const Space v1463_6_tail = child(v1462_8_tail,v1463_6_label);
      if (v1463_6_tail.empty()) continue;
      const Path v1463_6_head{v1463_6_label};
      const Space v1464_2 = Space{};
      v1463_6_result = unite(v1463_6_result,v1464_2);
    }
    const Space v1463_6 = std::move(v1463_6_result);
    const Space v1463_7 = compose(v1463_5,v1463_6);
    const Space v1463_8 = intersect(constant_2,v1463_2);
    const Space v1463_9 = (has_head(v1463_8) ? constant_3 : Space{});
    Space v1463_12;
    if (!v1463_9.empty()) {
      const Path v1465_10 = concat_path(p0,v1462_8_head);
      Space v1465_11_result;
      for (int v1465_11_label = 1; v1465_11_label <= 2; ++v1465_11_label) {
        const Space v1465_11_tail = child(v1462_8_tail,v1465_11_label);
        if (v1465_11_tail.empty()) continue;
        const Path v1465_11_head{v1465_11_label};
        const Space v1466_2 = singleton(v1465_11_head);
        const Space v1466_3 = intersect(constant_2,v1466_2);
        const Space v1466_4 = (has_head(v1466_3) ? constant_3 : Space{});
        Space v1466_7;
        if (!v1466_4.empty()) {
          const Path v1467_5 = concat_path(v1465_10,v1465_11_head);
          const Space v1467_6 = routine_43(c, v1467_5, p1, v1465_11_tail, s1);
          v1466_7 = compose(v1466_4,v1467_6);
        }
        v1465_11_result = unite(v1465_11_result,v1466_7);
      }
      const Space v1465_11 = std::move(v1465_11_result);
      v1463_12 = compose(v1463_9,v1465_11);
    }
    const Space v1463_13 = unite(v1463_7,v1463_12);
    v1462_8_result = unite(v1462_8_result,v1463_13);
  }
  const Space v1462_8 = std::move(v1462_8_result);
  return v1462_8;
}

static Space routine_163(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1468_8 = unwrap(s1,constant_4);
  const Space v1468_10 = unwrap(v1468_8,constant_6);
  const Space v1468_11 = unwrap(v1468_10,p0);
  Space v1468_15_result;
  for (int v1468_15_label = 1; v1468_15_label <= 2; ++v1468_15_label) {
    const Space v1468_15_tail = child(s0,v1468_15_label);
    if (v1468_15_tail.empty()) continue;
    const Path v1468_15_head{v1468_15_label};
    const Space v1469_2 = singleton(v1468_15_head);
    const Space v1469_3 = intersect(constant_2,v1469_2);
    const Space v1469_4 = (has_head(v1469_3) ? constant_3 : Space{});
    const Space v1469_5 = subtract(constant_1,v1469_4);
    Space v1469_6_result;
    for (int v1469_6_label = 1; v1469_6_label <= 2; ++v1469_6_label) {
      const Space v1469_6_tail = child(v1468_15_tail,v1469_6_label);
      if (v1469_6_tail.empty()) continue;
      const Path v1469_6_head{v1469_6_label};
      const Space v1470_2 = Space{};
      v1469_6_result = unite(v1469_6_result,v1470_2);
    }
    const Space v1469_6 = std::move(v1469_6_result);
    const Space v1469_7 = compose(v1469_5,v1469_6);
    const Space v1469_8 = intersect(constant_2,v1469_2);
    const Space v1469_9 = (has_head(v1469_8) ? constant_3 : Space{});
    Space v1469_12;
    if (!v1469_9.empty()) {
      const Space v1471_10 = unwrap(v1468_11,v1468_15_head);
      Space v1471_11_result;
      for (int v1471_11_label = 1; v1471_11_label <= 2; ++v1471_11_label) {
        const Space v1471_11_tail = child(v1471_10,v1471_11_label);
        if (v1471_11_tail.empty()) continue;
        const Path v1471_11_head{v1471_11_label};
        const Space v1472_2 = singleton(v1471_11_head);
        const Space v1472_3 = intersect(constant_2,v1472_2);
        const Space v1472_4 = (has_head(v1472_3) ? constant_3 : Space{});
        const Space v1472_5 = subtract(constant_1,v1472_4);
        Space v1472_7;
        if (!v1472_5.empty()) {
          const Space v1473_6 = routine_83(c, v1471_11_head, p1, v1471_11_tail);
          v1472_7 = compose(v1472_5,v1473_6);
        }
        const Space v1472_8 = intersect(constant_2,v1472_2);
        const Space v1472_9 = (has_head(v1472_8) ? constant_3 : Space{});
        Space v1472_11;
        if (!v1472_9.empty()) {
          const Space v1474_10 = routine_84(c, v1471_11_head, p1, v1471_11_tail);
          v1472_11 = compose(v1472_9,v1474_10);
        }
        const Space v1472_12 = unite(v1472_7,v1472_11);
        v1471_11_result = unite(v1471_11_result,v1472_12);
      }
      const Space v1471_11 = std::move(v1471_11_result);
      v1469_12 = compose(v1469_9,v1471_11);
    }
    const Space v1469_13 = unite(v1469_7,v1469_12);
    v1468_15_result = unite(v1468_15_result,v1469_13);
  }
  const Space v1468_15 = std::move(v1468_15_result);
  return v1468_15;
}

static Space routine_164(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1475_12_result;
  for (int v1475_12_label = 1; v1475_12_label <= 2; ++v1475_12_label) {
    const Space v1475_12_tail = child(s0,v1475_12_label);
    if (v1475_12_tail.empty()) continue;
    const Path v1475_12_head{v1475_12_label};
    const Space v1476_2 = singleton(v1475_12_head);
    const Space v1476_3 = intersect(constant_2,v1476_2);
    const Space v1476_4 = (has_head(v1476_3) ? constant_3 : Space{});
    const Space v1476_5 = subtract(constant_1,v1476_4);
    Space v1476_8;
    if (!v1476_5.empty()) {
      const Path v1477_6 = concat_path(p0,v1475_12_head);
      Space v1477_7_result;
      for (int v1477_7_label = 1; v1477_7_label <= 2; ++v1477_7_label) {
        const Space v1477_7_tail = child(v1475_12_tail,v1477_7_label);
        if (v1477_7_tail.empty()) continue;
        const Path v1477_7_head{v1477_7_label};
        const Space v1478_2 = singleton(v1477_7_head);
        const Space v1478_3 = intersect(constant_2,v1478_2);
        const Space v1478_4 = (has_head(v1478_3) ? constant_3 : Space{});
        const Space v1478_5 = subtract(constant_1,v1478_4);
        Space v1478_8;
        if (!v1478_5.empty()) {
          const Path v1479_6 = concat_path(v1477_6,v1477_7_head);
          const Space v1479_7 = routine_188(c, v1479_6, p1, v1477_7_tail);
          v1478_8 = compose(v1478_5,v1479_7);
        }
        const Space v1478_9 = intersect(constant_2,v1478_2);
        const Space v1478_10 = (has_head(v1478_9) ? constant_3 : Space{});
        Space v1478_12;
        if (!v1478_10.empty()) {
          const Path v1480_6 = concat_path(v1477_6,v1477_7_head);
          const Space v1480_11 = routine_189(c, v1480_6, p1, v1477_7_tail);
          v1478_12 = compose(v1478_10,v1480_11);
        }
        const Space v1478_13 = unite(v1478_8,v1478_12);
        v1477_7_result = unite(v1477_7_result,v1478_13);
      }
      const Space v1477_7 = std::move(v1477_7_result);
      v1476_8 = compose(v1476_5,v1477_7);
    }
    const Space v1476_9 = intersect(constant_2,v1476_2);
    const Space v1476_10 = (has_head(v1476_9) ? constant_3 : Space{});
    Space v1476_12;
    if (!v1476_10.empty()) {
      const Path v1481_6 = concat_path(p0,v1475_12_head);
      Space v1481_11_result;
      for (int v1481_11_label = 1; v1481_11_label <= 2; ++v1481_11_label) {
        const Space v1481_11_tail = child(v1475_12_tail,v1481_11_label);
        if (v1481_11_tail.empty()) continue;
        const Path v1481_11_head{v1481_11_label};
        const Space v1482_2 = singleton(v1481_11_head);
        const Space v1482_3 = intersect(constant_2,v1482_2);
        const Space v1482_4 = (has_head(v1482_3) ? constant_3 : Space{});
        const Space v1482_5 = subtract(constant_1,v1482_4);
        Space v1482_8;
        if (!v1482_5.empty()) {
          const Path v1483_6 = concat_path(v1481_6,v1481_11_head);
          const Space v1483_7 = routine_188(c, v1483_6, p1, v1481_11_tail);
          v1482_8 = compose(v1482_5,v1483_7);
        }
        const Space v1482_9 = intersect(constant_2,v1482_2);
        const Space v1482_10 = (has_head(v1482_9) ? constant_3 : Space{});
        Space v1482_12;
        if (!v1482_10.empty()) {
          const Path v1484_6 = concat_path(v1481_6,v1481_11_head);
          const Space v1484_11 = routine_89(c, v1484_6, p1, v1481_11_tail);
          v1482_12 = compose(v1482_10,v1484_11);
        }
        const Space v1482_13 = unite(v1482_8,v1482_12);
        v1481_11_result = unite(v1481_11_result,v1482_13);
      }
      const Space v1481_11 = std::move(v1481_11_result);
      v1476_12 = compose(v1476_10,v1481_11);
    }
    const Space v1476_13 = unite(v1476_8,v1476_12);
    v1475_12_result = unite(v1475_12_result,v1476_13);
  }
  const Space v1475_12 = std::move(v1475_12_result);
  return v1475_12;
}

static Space routine_165(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1485_9_result;
  for (int v1485_9_label = 1; v1485_9_label <= 2; ++v1485_9_label) {
    const Space v1485_9_tail = child(s0,v1485_9_label);
    if (v1485_9_tail.empty()) continue;
    const Path v1485_9_head{v1485_9_label};
    const Space v1486_2 = singleton(v1485_9_head);
    const Space v1486_3 = intersect(constant_2,v1486_2);
    const Space v1486_4 = (has_head(v1486_3) ? constant_3 : Space{});
    const Space v1486_5 = subtract(constant_1,v1486_4);
    Space v1486_8;
    if (!v1486_5.empty()) {
      const Path v1487_6 = concat_path(p0,v1485_9_head);
      Space v1487_7_result;
      for (int v1487_7_label = 1; v1487_7_label <= 2; ++v1487_7_label) {
        const Space v1487_7_tail = child(v1485_9_tail,v1487_7_label);
        if (v1487_7_tail.empty()) continue;
        const Path v1487_7_head{v1487_7_label};
        const Space v1488_2 = singleton(v1487_7_head);
        const Space v1488_3 = intersect(constant_2,v1488_2);
        const Space v1488_4 = (has_head(v1488_3) ? constant_3 : Space{});
        const Space v1488_5 = subtract(constant_1,v1488_4);
        Space v1488_8;
        if (!v1488_5.empty()) {
          const Path v1489_6 = concat_path(v1487_6,v1487_7_head);
          const Space v1489_7 = routine_188(c, v1489_6, p1, v1487_7_tail);
          v1488_8 = compose(v1488_5,v1489_7);
        }
        const Space v1488_9 = intersect(constant_2,v1488_2);
        const Space v1488_10 = (has_head(v1488_9) ? constant_3 : Space{});
        Space v1488_12;
        if (!v1488_10.empty()) {
          const Path v1490_6 = concat_path(v1487_6,v1487_7_head);
          const Space v1490_11 = routine_189(c, v1490_6, p1, v1487_7_tail);
          v1488_12 = compose(v1488_10,v1490_11);
        }
        const Space v1488_13 = unite(v1488_8,v1488_12);
        v1487_7_result = unite(v1487_7_result,v1488_13);
      }
      const Space v1487_7 = std::move(v1487_7_result);
      v1486_8 = compose(v1486_5,v1487_7);
    }
    const Space v1486_9 = intersect(constant_2,v1486_2);
    const Space v1486_10 = (has_head(v1486_9) ? constant_3 : Space{});
    const Space v1486_11 = compose(v1486_10,v1485_9_tail);
    const Path v1491_6 = concat_path(p0,v1485_9_head);
    const Space v1486_12 = wrap(v1486_11,v1491_6);
    const Space v1486_13 = wrap(v1486_12,p1);
    const Space v1486_14 = unite(v1486_8,v1486_13);
    v1485_9_result = unite(v1485_9_result,v1486_14);
  }
  const Space v1485_9 = std::move(v1485_9_result);
  return v1485_9;
}

static Space routine_166(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1492_12_result;
  for (int v1492_12_label = 1; v1492_12_label <= 2; ++v1492_12_label) {
    const Space v1492_12_tail = child(s0,v1492_12_label);
    if (v1492_12_tail.empty()) continue;
    const Path v1492_12_head{v1492_12_label};
    const Space v1493_2 = singleton(v1492_12_head);
    const Space v1493_3 = intersect(constant_2,v1493_2);
    const Space v1493_4 = (has_head(v1493_3) ? constant_3 : Space{});
    const Space v1493_5 = subtract(constant_1,v1493_4);
    Space v1493_8;
    if (!v1493_5.empty()) {
      const Path v1494_6 = concat_path(p0,v1492_12_head);
      Space v1494_7_result;
      for (int v1494_7_label = 1; v1494_7_label <= 2; ++v1494_7_label) {
        const Space v1494_7_tail = child(v1492_12_tail,v1494_7_label);
        if (v1494_7_tail.empty()) continue;
        const Path v1494_7_head{v1494_7_label};
        const Space v1495_2 = singleton(v1494_7_head);
        const Space v1495_3 = intersect(constant_2,v1495_2);
        const Space v1495_4 = (has_head(v1495_3) ? constant_3 : Space{});
        const Space v1495_5 = subtract(constant_1,v1495_4);
        Space v1495_8;
        if (!v1495_5.empty()) {
          const Path v1496_6 = concat_path(v1494_6,v1494_7_head);
          const Space v1496_7 = routine_190(c, v1496_6, p1, v1494_7_tail);
          v1495_8 = compose(v1495_5,v1496_7);
        }
        const Space v1495_9 = intersect(constant_2,v1495_2);
        const Space v1495_10 = (has_head(v1495_9) ? constant_3 : Space{});
        Space v1495_12;
        if (!v1495_10.empty()) {
          const Path v1497_6 = concat_path(v1494_6,v1494_7_head);
          const Space v1497_11 = routine_191(c, v1497_6, p1, v1494_7_tail);
          v1495_12 = compose(v1495_10,v1497_11);
        }
        const Space v1495_13 = unite(v1495_8,v1495_12);
        v1494_7_result = unite(v1494_7_result,v1495_13);
      }
      const Space v1494_7 = std::move(v1494_7_result);
      v1493_8 = compose(v1493_5,v1494_7);
    }
    const Space v1493_9 = intersect(constant_2,v1493_2);
    const Space v1493_10 = (has_head(v1493_9) ? constant_3 : Space{});
    Space v1493_12;
    if (!v1493_10.empty()) {
      const Path v1498_6 = concat_path(p0,v1492_12_head);
      Space v1498_11_result;
      for (int v1498_11_label = 1; v1498_11_label <= 2; ++v1498_11_label) {
        const Space v1498_11_tail = child(v1492_12_tail,v1498_11_label);
        if (v1498_11_tail.empty()) continue;
        const Path v1498_11_head{v1498_11_label};
        const Space v1499_2 = singleton(v1498_11_head);
        const Space v1499_3 = intersect(constant_2,v1499_2);
        const Space v1499_4 = (has_head(v1499_3) ? constant_3 : Space{});
        const Space v1499_5 = subtract(constant_1,v1499_4);
        Space v1499_8;
        if (!v1499_5.empty()) {
          const Path v1500_6 = concat_path(v1498_6,v1498_11_head);
          const Space v1500_7 = routine_190(c, v1500_6, p1, v1498_11_tail);
          v1499_8 = compose(v1499_5,v1500_7);
        }
        const Space v1499_9 = intersect(constant_2,v1499_2);
        const Space v1499_10 = (has_head(v1499_9) ? constant_3 : Space{});
        Space v1499_12;
        if (!v1499_10.empty()) {
          const Path v1501_6 = concat_path(v1498_6,v1498_11_head);
          const Space v1501_11 = routine_50(c, v1501_6, p1, v1498_11_tail);
          v1499_12 = compose(v1499_10,v1501_11);
        }
        const Space v1499_13 = unite(v1499_8,v1499_12);
        v1498_11_result = unite(v1498_11_result,v1499_13);
      }
      const Space v1498_11 = std::move(v1498_11_result);
      v1493_12 = compose(v1493_10,v1498_11);
    }
    const Space v1493_13 = unite(v1493_8,v1493_12);
    v1492_12_result = unite(v1492_12_result,v1493_13);
  }
  const Space v1492_12 = std::move(v1492_12_result);
  return v1492_12;
}

static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1502_9_result;
  for (int v1502_9_label = 1; v1502_9_label <= 2; ++v1502_9_label) {
    const Space v1502_9_tail = child(s0,v1502_9_label);
    if (v1502_9_tail.empty()) continue;
    const Path v1502_9_head{v1502_9_label};
    const Space v1503_2 = singleton(v1502_9_head);
    const Space v1503_3 = intersect(constant_2,v1503_2);
    const Space v1503_4 = (has_head(v1503_3) ? constant_3 : Space{});
    const Space v1503_5 = subtract(constant_1,v1503_4);
    Space v1503_8;
    if (!v1503_5.empty()) {
      const Path v1504_6 = concat_path(p0,v1502_9_head);
      Space v1504_7_result;
      for (int v1504_7_label = 1; v1504_7_label <= 2; ++v1504_7_label) {
        const Space v1504_7_tail = child(v1502_9_tail,v1504_7_label);
        if (v1504_7_tail.empty()) continue;
        const Path v1504_7_head{v1504_7_label};
        const Space v1505_2 = singleton(v1504_7_head);
        const Space v1505_3 = intersect(constant_2,v1505_2);
        const Space v1505_4 = (has_head(v1505_3) ? constant_3 : Space{});
        const Space v1505_5 = subtract(constant_1,v1505_4);
        Space v1505_8;
        if (!v1505_5.empty()) {
          const Path v1506_6 = concat_path(v1504_6,v1504_7_head);
          const Space v1506_7 = routine_190(c, v1506_6, p1, v1504_7_tail);
          v1505_8 = compose(v1505_5,v1506_7);
        }
        const Space v1505_9 = intersect(constant_2,v1505_2);
        const Space v1505_10 = (has_head(v1505_9) ? constant_3 : Space{});
        Space v1505_12;
        if (!v1505_10.empty()) {
          const Path v1507_6 = concat_path(v1504_6,v1504_7_head);
          const Space v1507_11 = routine_191(c, v1507_6, p1, v1504_7_tail);
          v1505_12 = compose(v1505_10,v1507_11);
        }
        const Space v1505_13 = unite(v1505_8,v1505_12);
        v1504_7_result = unite(v1504_7_result,v1505_13);
      }
      const Space v1504_7 = std::move(v1504_7_result);
      v1503_8 = compose(v1503_5,v1504_7);
    }
    const Space v1503_9 = intersect(constant_2,v1503_2);
    const Space v1503_10 = (has_head(v1503_9) ? constant_3 : Space{});
    const Space v1503_11 = compose(v1503_10,v1502_9_tail);
    const Path v1508_6 = concat_path(p0,v1502_9_head);
    const Space v1503_12 = wrap(v1503_11,v1508_6);
    const Space v1503_13 = wrap(v1503_12,p1);
    const Space v1503_14 = unite(v1503_8,v1503_13);
    v1502_9_result = unite(v1502_9_result,v1503_14);
  }
  const Space v1502_9 = std::move(v1502_9_result);
  return v1502_9;
}

static Space routine_168(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1509_7_result;
  for (int v1509_7_label = 1; v1509_7_label <= 2; ++v1509_7_label) {
    const Space v1509_7_tail = child(s0,v1509_7_label);
    if (v1509_7_tail.empty()) continue;
    const Path v1509_7_head{v1509_7_label};
    const Space v1510_2 = singleton(v1509_7_head);
    const Space v1510_3 = intersect(constant_2,v1510_2);
    const Space v1510_4 = (has_head(v1510_3) ? constant_3 : Space{});
    const Space v1510_5 = subtract(constant_1,v1510_4);
    Space v1510_6_result;
    for (int v1510_6_label = 1; v1510_6_label <= 2; ++v1510_6_label) {
      const Space v1510_6_tail = child(v1509_7_tail,v1510_6_label);
      if (v1510_6_tail.empty()) continue;
      const Path v1510_6_head{v1510_6_label};
      const Space v1511_2 = Space{};
      v1510_6_result = unite(v1510_6_result,v1511_2);
    }
    const Space v1510_6 = std::move(v1510_6_result);
    const Space v1510_7 = compose(v1510_5,v1510_6);
    const Space v1510_8 = intersect(constant_2,v1510_2);
    const Space v1510_9 = (has_head(v1510_8) ? constant_3 : Space{});
    Space v1510_12;
    if (!v1510_9.empty()) {
      const Path v1512_10 = concat_path(p0,v1509_7_head);
      Space v1512_11_result;
      for (int v1512_11_label = 1; v1512_11_label <= 2; ++v1512_11_label) {
        const Space v1512_11_tail = child(v1509_7_tail,v1512_11_label);
        if (v1512_11_tail.empty()) continue;
        const Path v1512_11_head{v1512_11_label};
        const Space v1513_2 = singleton(v1512_11_head);
        const Space v1513_3 = intersect(constant_2,v1513_2);
        const Space v1513_4 = (has_head(v1513_3) ? constant_3 : Space{});
        Space v1513_7;
        if (!v1513_4.empty()) {
          const Path v1514_5 = concat_path(v1512_10,v1512_11_head);
          const Space v1514_6 = routine_50(c, v1514_5, p1, v1512_11_tail);
          v1513_7 = compose(v1513_4,v1514_6);
        }
        v1512_11_result = unite(v1512_11_result,v1513_7);
      }
      const Space v1512_11 = std::move(v1512_11_result);
      v1510_12 = compose(v1510_9,v1512_11);
    }
    const Space v1510_13 = unite(v1510_7,v1510_12);
    v1509_7_result = unite(v1509_7_result,v1510_13);
  }
  const Space v1509_7 = std::move(v1509_7_result);
  return v1509_7;
}

static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1515_6_result;
  for (int v1515_6_label = 1; v1515_6_label <= 2; ++v1515_6_label) {
    const Space v1515_6_tail = child(s0,v1515_6_label);
    if (v1515_6_tail.empty()) continue;
    const Path v1515_6_head{v1515_6_label};
    const Space v1516_2 = singleton(v1515_6_head);
    const Space v1516_3 = intersect(constant_2,v1516_2);
    const Space v1516_4 = (has_head(v1516_3) ? constant_3 : Space{});
    const Space v1516_5 = subtract(constant_1,v1516_4);
    Space v1516_6_result;
    for (int v1516_6_label = 1; v1516_6_label <= 2; ++v1516_6_label) {
      const Space v1516_6_tail = child(v1515_6_tail,v1516_6_label);
      if (v1516_6_tail.empty()) continue;
      const Path v1516_6_head{v1516_6_label};
      const Space v1517_2 = Space{};
      v1516_6_result = unite(v1516_6_result,v1517_2);
    }
    const Space v1516_6 = std::move(v1516_6_result);
    const Space v1516_7 = compose(v1516_5,v1516_6);
    const Space v1516_8 = intersect(constant_2,v1516_2);
    const Space v1516_9 = (has_head(v1516_8) ? constant_3 : Space{});
    const Space v1516_10 = compose(v1516_9,v1515_6_tail);
    const Path v1516_11 = concat_path(p0,v1515_6_head);
    const Space v1516_12 = wrap(v1516_10,v1516_11);
    const Space v1516_13 = wrap(v1516_12,p1);
    const Space v1516_14 = unite(v1516_7,v1516_13);
    v1515_6_result = unite(v1515_6_result,v1516_14);
  }
  const Space v1515_6 = std::move(v1515_6_result);
  return v1515_6;
}

static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1518_3_result;
  for (int v1518_3_label = 1; v1518_3_label <= 2; ++v1518_3_label) {
    const Space v1518_3_tail = child(s0,v1518_3_label);
    if (v1518_3_tail.empty()) continue;
    const Path v1518_3_head{v1518_3_label};
    const Space v1519_2 = Space{};
    v1518_3_result = unite(v1518_3_result,v1519_2);
  }
  const Space v1518_3 = std::move(v1518_3_result);
  return v1518_3;
}

static Space routine_171(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1520_4_result;
  for (int v1520_4_label = 1; v1520_4_label <= 2; ++v1520_4_label) {
    const Space v1520_4_tail = child(s0,v1520_4_label);
    if (v1520_4_tail.empty()) continue;
    const Path v1520_4_head{v1520_4_label};
    const Space v1521_2 = singleton(v1520_4_head);
    const Space v1521_3 = intersect(constant_2,v1521_2);
    const Space v1521_4 = (has_head(v1521_3) ? constant_3 : Space{});
    const Space v1521_5 = compose(v1521_4,v1520_4_tail);
    const Path v1521_6 = concat_path(p0,v1520_4_head);
    const Space v1521_7 = wrap(v1521_5,v1521_6);
    v1520_4_result = unite(v1520_4_result,v1521_7);
  }
  const Space v1520_4 = std::move(v1520_4_result);
  const Space v1520_5 = wrap(v1520_4,p1);
  const Space v1520_7 = wrap(v1520_5,constant_6);
  return v1520_7;
}

static Space routine_172(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1522_4_result;
  for (int v1522_4_label = 1; v1522_4_label <= 2; ++v1522_4_label) {
    const Space v1522_4_tail = child(s0,v1522_4_label);
    if (v1522_4_tail.empty()) continue;
    const Path v1522_4_head{v1522_4_label};
    const Space v1523_2 = Space{};
    v1522_4_result = unite(v1522_4_result,v1523_2);
  }
  const Space v1522_4 = std::move(v1522_4_result);
  return v1522_4;
}

static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1524_6 = unwrap(s1,constant_5);
  const Space v1524_8 = unwrap(v1524_6,constant_6);
  const Space v1524_9 = unwrap(v1524_8,p0);
  Space v1524_13_result;
  for (int v1524_13_label = 1; v1524_13_label <= 2; ++v1524_13_label) {
    const Space v1524_13_tail = child(s0,v1524_13_label);
    if (v1524_13_tail.empty()) continue;
    const Path v1524_13_head{v1524_13_label};
    const Space v1525_2 = singleton(v1524_13_head);
    const Space v1525_3 = intersect(constant_2,v1525_2);
    const Space v1525_4 = (has_head(v1525_3) ? constant_3 : Space{});
    Space v1525_7;
    if (!v1525_4.empty()) {
      const Space v1526_5 = unwrap(v1524_9,v1524_13_head);
      Space v1526_6_result;
      for (int v1526_6_label = 1; v1526_6_label <= 2; ++v1526_6_label) {
        const Space v1526_6_tail = child(v1526_5,v1526_6_label);
        if (v1526_6_tail.empty()) continue;
        const Path v1526_6_head{v1526_6_label};
        const Space v1527_2 = singleton(v1526_6_head);
        const Space v1527_3 = intersect(constant_2,v1527_2);
        const Space v1527_4 = (has_head(v1527_3) ? constant_3 : Space{});
        const Space v1527_5 = subtract(constant_1,v1527_4);
        Space v1527_7;
        if (!v1527_5.empty()) {
          const Space v1528_6 = routine_61(c, v1526_6_head, p1, v1526_6_tail);
          v1527_7 = compose(v1527_5,v1528_6);
        }
        const Space v1527_8 = intersect(constant_2,v1527_2);
        const Space v1527_9 = (has_head(v1527_8) ? constant_3 : Space{});
        Space v1527_11;
        if (!v1527_9.empty()) {
          const Space v1529_10 = routine_62(c, v1526_6_head, p1, v1526_6_tail);
          v1527_11 = compose(v1527_9,v1529_10);
        }
        const Space v1527_12 = unite(v1527_7,v1527_11);
        v1526_6_result = unite(v1526_6_result,v1527_12);
      }
      const Space v1526_6 = std::move(v1526_6_result);
      v1525_7 = compose(v1525_4,v1526_6);
    }
    v1524_13_result = unite(v1524_13_result,v1525_7);
  }
  const Space v1524_13 = std::move(v1524_13_result);
  return v1524_13;
}

static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1530_12_result;
  for (int v1530_12_label = 1; v1530_12_label <= 2; ++v1530_12_label) {
    const Space v1530_12_tail = child(s0,v1530_12_label);
    if (v1530_12_tail.empty()) continue;
    const Path v1530_12_head{v1530_12_label};
    const Space v1531_2 = singleton(v1530_12_head);
    const Space v1531_3 = intersect(constant_2,v1531_2);
    const Space v1531_4 = (has_head(v1531_3) ? constant_3 : Space{});
    const Space v1531_5 = subtract(constant_1,v1531_4);
    Space v1531_8;
    if (!v1531_5.empty()) {
      const Path v1532_6 = concat_path(p0,v1530_12_head);
      Space v1532_7_result;
      for (int v1532_7_label = 1; v1532_7_label <= 2; ++v1532_7_label) {
        const Space v1532_7_tail = child(v1530_12_tail,v1532_7_label);
        if (v1532_7_tail.empty()) continue;
        const Path v1532_7_head{v1532_7_label};
        const Space v1533_2 = singleton(v1532_7_head);
        const Space v1533_3 = intersect(constant_2,v1533_2);
        const Space v1533_4 = (has_head(v1533_3) ? constant_3 : Space{});
        const Space v1533_5 = subtract(constant_1,v1533_4);
        Space v1533_8;
        if (!v1533_5.empty()) {
          const Path v1534_6 = concat_path(v1532_6,v1532_7_head);
          const Space v1534_7 = routine_192(c, v1534_6, p1, v1532_7_tail);
          v1533_8 = compose(v1533_5,v1534_7);
        }
        const Space v1533_9 = intersect(constant_2,v1533_2);
        const Space v1533_10 = (has_head(v1533_9) ? constant_3 : Space{});
        Space v1533_12;
        if (!v1533_10.empty()) {
          const Path v1535_6 = concat_path(v1532_6,v1532_7_head);
          const Space v1535_11 = routine_193(c, v1535_6, p1, v1532_7_tail);
          v1533_12 = compose(v1533_10,v1535_11);
        }
        const Space v1533_13 = unite(v1533_8,v1533_12);
        v1532_7_result = unite(v1532_7_result,v1533_13);
      }
      const Space v1532_7 = std::move(v1532_7_result);
      v1531_8 = compose(v1531_5,v1532_7);
    }
    const Space v1531_9 = intersect(constant_2,v1531_2);
    const Space v1531_10 = (has_head(v1531_9) ? constant_3 : Space{});
    Space v1531_12;
    if (!v1531_10.empty()) {
      const Path v1536_6 = concat_path(p0,v1530_12_head);
      Space v1536_11_result;
      for (int v1536_11_label = 1; v1536_11_label <= 2; ++v1536_11_label) {
        const Space v1536_11_tail = child(v1530_12_tail,v1536_11_label);
        if (v1536_11_tail.empty()) continue;
        const Path v1536_11_head{v1536_11_label};
        const Space v1537_2 = singleton(v1536_11_head);
        const Space v1537_3 = intersect(constant_2,v1537_2);
        const Space v1537_4 = (has_head(v1537_3) ? constant_3 : Space{});
        const Space v1537_5 = subtract(constant_1,v1537_4);
        Space v1537_8;
        if (!v1537_5.empty()) {
          const Path v1538_6 = concat_path(v1536_6,v1536_11_head);
          const Space v1538_7 = routine_192(c, v1538_6, p1, v1536_11_tail);
          v1537_8 = compose(v1537_5,v1538_7);
        }
        const Space v1537_9 = intersect(constant_2,v1537_2);
        const Space v1537_10 = (has_head(v1537_9) ? constant_3 : Space{});
        Space v1537_12;
        if (!v1537_10.empty()) {
          const Path v1539_6 = concat_path(v1536_6,v1536_11_head);
          const Space v1539_11 = routine_67(c, v1539_6, p1, v1536_11_tail);
          v1537_12 = compose(v1537_10,v1539_11);
        }
        const Space v1537_13 = unite(v1537_8,v1537_12);
        v1536_11_result = unite(v1536_11_result,v1537_13);
      }
      const Space v1536_11 = std::move(v1536_11_result);
      v1531_12 = compose(v1531_10,v1536_11);
    }
    const Space v1531_13 = unite(v1531_8,v1531_12);
    v1530_12_result = unite(v1530_12_result,v1531_13);
  }
  const Space v1530_12 = std::move(v1530_12_result);
  return v1530_12;
}

static Space routine_175(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1540_9_result;
  for (int v1540_9_label = 1; v1540_9_label <= 2; ++v1540_9_label) {
    const Space v1540_9_tail = child(s0,v1540_9_label);
    if (v1540_9_tail.empty()) continue;
    const Path v1540_9_head{v1540_9_label};
    const Space v1541_2 = singleton(v1540_9_head);
    const Space v1541_3 = intersect(constant_2,v1541_2);
    const Space v1541_4 = (has_head(v1541_3) ? constant_3 : Space{});
    const Space v1541_5 = subtract(constant_1,v1541_4);
    Space v1541_8;
    if (!v1541_5.empty()) {
      const Path v1542_6 = concat_path(p0,v1540_9_head);
      Space v1542_7_result;
      for (int v1542_7_label = 1; v1542_7_label <= 2; ++v1542_7_label) {
        const Space v1542_7_tail = child(v1540_9_tail,v1542_7_label);
        if (v1542_7_tail.empty()) continue;
        const Path v1542_7_head{v1542_7_label};
        const Space v1543_2 = singleton(v1542_7_head);
        const Space v1543_3 = intersect(constant_2,v1543_2);
        const Space v1543_4 = (has_head(v1543_3) ? constant_3 : Space{});
        const Space v1543_5 = subtract(constant_1,v1543_4);
        Space v1543_8;
        if (!v1543_5.empty()) {
          const Path v1544_6 = concat_path(v1542_6,v1542_7_head);
          const Space v1544_7 = routine_192(c, v1544_6, p1, v1542_7_tail);
          v1543_8 = compose(v1543_5,v1544_7);
        }
        const Space v1543_9 = intersect(constant_2,v1543_2);
        const Space v1543_10 = (has_head(v1543_9) ? constant_3 : Space{});
        Space v1543_12;
        if (!v1543_10.empty()) {
          const Path v1545_6 = concat_path(v1542_6,v1542_7_head);
          const Space v1545_11 = routine_193(c, v1545_6, p1, v1542_7_tail);
          v1543_12 = compose(v1543_10,v1545_11);
        }
        const Space v1543_13 = unite(v1543_8,v1543_12);
        v1542_7_result = unite(v1542_7_result,v1543_13);
      }
      const Space v1542_7 = std::move(v1542_7_result);
      v1541_8 = compose(v1541_5,v1542_7);
    }
    const Space v1541_9 = intersect(constant_2,v1541_2);
    const Space v1541_10 = (has_head(v1541_9) ? constant_3 : Space{});
    const Space v1541_11 = compose(v1541_10,v1540_9_tail);
    const Path v1546_6 = concat_path(p0,v1540_9_head);
    const Space v1541_12 = wrap(v1541_11,v1546_6);
    const Space v1541_13 = wrap(v1541_12,p1);
    const Space v1541_14 = unite(v1541_8,v1541_13);
    v1540_9_result = unite(v1540_9_result,v1541_14);
  }
  const Space v1540_9 = std::move(v1540_9_result);
  return v1540_9;
}

static Space routine_176(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1547_7_result;
  for (int v1547_7_label = 1; v1547_7_label <= 2; ++v1547_7_label) {
    const Space v1547_7_tail = child(s0,v1547_7_label);
    if (v1547_7_tail.empty()) continue;
    const Path v1547_7_head{v1547_7_label};
    const Space v1548_2 = singleton(v1547_7_head);
    const Space v1548_3 = intersect(constant_2,v1548_2);
    const Space v1548_4 = (has_head(v1548_3) ? constant_3 : Space{});
    const Space v1548_5 = subtract(constant_1,v1548_4);
    Space v1548_6_result;
    for (int v1548_6_label = 1; v1548_6_label <= 2; ++v1548_6_label) {
      const Space v1548_6_tail = child(v1547_7_tail,v1548_6_label);
      if (v1548_6_tail.empty()) continue;
      const Path v1548_6_head{v1548_6_label};
      const Space v1549_2 = Space{};
      v1548_6_result = unite(v1548_6_result,v1549_2);
    }
    const Space v1548_6 = std::move(v1548_6_result);
    const Space v1548_7 = compose(v1548_5,v1548_6);
    const Space v1548_8 = intersect(constant_2,v1548_2);
    const Space v1548_9 = (has_head(v1548_8) ? constant_3 : Space{});
    Space v1548_12;
    if (!v1548_9.empty()) {
      const Path v1550_10 = concat_path(p0,v1547_7_head);
      Space v1550_11_result;
      for (int v1550_11_label = 1; v1550_11_label <= 2; ++v1550_11_label) {
        const Space v1550_11_tail = child(v1547_7_tail,v1550_11_label);
        if (v1550_11_tail.empty()) continue;
        const Path v1550_11_head{v1550_11_label};
        const Space v1551_2 = singleton(v1550_11_head);
        const Space v1551_3 = intersect(constant_2,v1551_2);
        const Space v1551_4 = (has_head(v1551_3) ? constant_3 : Space{});
        Space v1551_7;
        if (!v1551_4.empty()) {
          const Path v1552_5 = concat_path(v1550_10,v1550_11_head);
          const Space v1552_6 = routine_67(c, v1552_5, p1, v1550_11_tail);
          v1551_7 = compose(v1551_4,v1552_6);
        }
        v1550_11_result = unite(v1550_11_result,v1551_7);
      }
      const Space v1550_11 = std::move(v1550_11_result);
      v1548_12 = compose(v1548_9,v1550_11);
    }
    const Space v1548_13 = unite(v1548_7,v1548_12);
    v1547_7_result = unite(v1547_7_result,v1548_13);
  }
  const Space v1547_7 = std::move(v1547_7_result);
  return v1547_7;
}

static Space routine_177(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1553_6_result;
  for (int v1553_6_label = 1; v1553_6_label <= 2; ++v1553_6_label) {
    const Space v1553_6_tail = child(s0,v1553_6_label);
    if (v1553_6_tail.empty()) continue;
    const Path v1553_6_head{v1553_6_label};
    const Space v1554_2 = singleton(v1553_6_head);
    const Space v1554_3 = intersect(constant_2,v1554_2);
    const Space v1554_4 = (has_head(v1554_3) ? constant_3 : Space{});
    const Space v1554_5 = subtract(constant_1,v1554_4);
    Space v1554_6_result;
    for (int v1554_6_label = 1; v1554_6_label <= 2; ++v1554_6_label) {
      const Space v1554_6_tail = child(v1553_6_tail,v1554_6_label);
      if (v1554_6_tail.empty()) continue;
      const Path v1554_6_head{v1554_6_label};
      const Space v1555_2 = Space{};
      v1554_6_result = unite(v1554_6_result,v1555_2);
    }
    const Space v1554_6 = std::move(v1554_6_result);
    const Space v1554_7 = compose(v1554_5,v1554_6);
    const Space v1554_8 = intersect(constant_2,v1554_2);
    const Space v1554_9 = (has_head(v1554_8) ? constant_3 : Space{});
    const Space v1554_10 = compose(v1554_9,v1553_6_tail);
    const Path v1554_11 = concat_path(p0,v1553_6_head);
    const Space v1554_12 = wrap(v1554_10,v1554_11);
    const Space v1554_13 = wrap(v1554_12,p1);
    const Space v1554_14 = unite(v1554_7,v1554_13);
    v1553_6_result = unite(v1553_6_result,v1554_14);
  }
  const Space v1553_6 = std::move(v1553_6_result);
  return v1553_6;
}

static Space routine_178(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1556_4_result;
  for (int v1556_4_label = 1; v1556_4_label <= 2; ++v1556_4_label) {
    const Space v1556_4_tail = child(s0,v1556_4_label);
    if (v1556_4_tail.empty()) continue;
    const Path v1556_4_head{v1556_4_label};
    const Space v1557_2 = Space{};
    v1556_4_result = unite(v1556_4_result,v1557_2);
  }
  const Space v1556_4 = std::move(v1556_4_result);
  return v1556_4;
}

static Space routine_179(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1558_6 = unwrap(s1,constant_4);
  const Space v1558_8 = unwrap(v1558_6,constant_6);
  const Space v1558_9 = unwrap(v1558_8,p0);
  Space v1558_13_result;
  for (int v1558_13_label = 1; v1558_13_label <= 2; ++v1558_13_label) {
    const Space v1558_13_tail = child(s0,v1558_13_label);
    if (v1558_13_tail.empty()) continue;
    const Path v1558_13_head{v1558_13_label};
    const Space v1559_2 = singleton(v1558_13_head);
    const Space v1559_3 = intersect(constant_2,v1559_2);
    const Space v1559_4 = (has_head(v1559_3) ? constant_3 : Space{});
    Space v1559_7;
    if (!v1559_4.empty()) {
      const Space v1560_5 = unwrap(v1558_9,v1558_13_head);
      Space v1560_6_result;
      for (int v1560_6_label = 1; v1560_6_label <= 2; ++v1560_6_label) {
        const Space v1560_6_tail = child(v1560_5,v1560_6_label);
        if (v1560_6_tail.empty()) continue;
        const Path v1560_6_head{v1560_6_label};
        const Space v1561_2 = singleton(v1560_6_head);
        const Space v1561_3 = intersect(constant_2,v1561_2);
        const Space v1561_4 = (has_head(v1561_3) ? constant_3 : Space{});
        const Space v1561_5 = subtract(constant_1,v1561_4);
        Space v1561_7;
        if (!v1561_5.empty()) {
          const Space v1562_6 = routine_72(c, v1560_6_head, p1, v1560_6_tail);
          v1561_7 = compose(v1561_5,v1562_6);
        }
        const Space v1561_8 = intersect(constant_2,v1561_2);
        const Space v1561_9 = (has_head(v1561_8) ? constant_3 : Space{});
        Space v1561_11;
        if (!v1561_9.empty()) {
          const Space v1563_10 = routine_73(c, v1560_6_head, p1, v1560_6_tail);
          v1561_11 = compose(v1561_9,v1563_10);
        }
        const Space v1561_12 = unite(v1561_7,v1561_11);
        v1560_6_result = unite(v1560_6_result,v1561_12);
      }
      const Space v1560_6 = std::move(v1560_6_result);
      v1559_7 = compose(v1559_4,v1560_6);
    }
    v1558_13_result = unite(v1558_13_result,v1559_7);
  }
  const Space v1558_13 = std::move(v1558_13_result);
  return v1558_13;
}

static Space routine_180(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1564_12_result;
  for (int v1564_12_label = 1; v1564_12_label <= 2; ++v1564_12_label) {
    const Space v1564_12_tail = child(s0,v1564_12_label);
    if (v1564_12_tail.empty()) continue;
    const Path v1564_12_head{v1564_12_label};
    const Space v1565_2 = singleton(v1564_12_head);
    const Space v1565_3 = intersect(constant_2,v1565_2);
    const Space v1565_4 = (has_head(v1565_3) ? constant_3 : Space{});
    const Space v1565_5 = subtract(constant_1,v1565_4);
    Space v1565_8;
    if (!v1565_5.empty()) {
      const Path v1566_6 = concat_path(p0,v1564_12_head);
      Space v1566_7_result;
      for (int v1566_7_label = 1; v1566_7_label <= 2; ++v1566_7_label) {
        const Space v1566_7_tail = child(v1564_12_tail,v1566_7_label);
        if (v1566_7_tail.empty()) continue;
        const Path v1566_7_head{v1566_7_label};
        const Space v1567_2 = singleton(v1566_7_head);
        const Space v1567_3 = intersect(constant_2,v1567_2);
        const Space v1567_4 = (has_head(v1567_3) ? constant_3 : Space{});
        const Space v1567_5 = subtract(constant_1,v1567_4);
        Space v1567_8;
        if (!v1567_5.empty()) {
          const Path v1568_6 = concat_path(v1566_6,v1566_7_head);
          const Space v1568_7 = routine_194(c, v1568_6, p1, v1566_7_tail);
          v1567_8 = compose(v1567_5,v1568_7);
        }
        const Space v1567_9 = intersect(constant_2,v1567_2);
        const Space v1567_10 = (has_head(v1567_9) ? constant_3 : Space{});
        Space v1567_12;
        if (!v1567_10.empty()) {
          const Path v1569_6 = concat_path(v1566_6,v1566_7_head);
          const Space v1569_11 = routine_195(c, v1569_6, p1, v1566_7_tail);
          v1567_12 = compose(v1567_10,v1569_11);
        }
        const Space v1567_13 = unite(v1567_8,v1567_12);
        v1566_7_result = unite(v1566_7_result,v1567_13);
      }
      const Space v1566_7 = std::move(v1566_7_result);
      v1565_8 = compose(v1565_5,v1566_7);
    }
    const Space v1565_9 = intersect(constant_2,v1565_2);
    const Space v1565_10 = (has_head(v1565_9) ? constant_3 : Space{});
    Space v1565_12;
    if (!v1565_10.empty()) {
      const Path v1570_6 = concat_path(p0,v1564_12_head);
      Space v1570_11_result;
      for (int v1570_11_label = 1; v1570_11_label <= 2; ++v1570_11_label) {
        const Space v1570_11_tail = child(v1564_12_tail,v1570_11_label);
        if (v1570_11_tail.empty()) continue;
        const Path v1570_11_head{v1570_11_label};
        const Space v1571_2 = singleton(v1570_11_head);
        const Space v1571_3 = intersect(constant_2,v1571_2);
        const Space v1571_4 = (has_head(v1571_3) ? constant_3 : Space{});
        const Space v1571_5 = subtract(constant_1,v1571_4);
        Space v1571_8;
        if (!v1571_5.empty()) {
          const Path v1572_6 = concat_path(v1570_6,v1570_11_head);
          const Space v1572_7 = routine_194(c, v1572_6, p1, v1570_11_tail);
          v1571_8 = compose(v1571_5,v1572_7);
        }
        const Space v1571_9 = intersect(constant_2,v1571_2);
        const Space v1571_10 = (has_head(v1571_9) ? constant_3 : Space{});
        Space v1571_12;
        if (!v1571_10.empty()) {
          const Path v1573_6 = concat_path(v1570_6,v1570_11_head);
          const Space v1573_11 = routine_78(c, v1573_6, p1, v1570_11_tail);
          v1571_12 = compose(v1571_10,v1573_11);
        }
        const Space v1571_13 = unite(v1571_8,v1571_12);
        v1570_11_result = unite(v1570_11_result,v1571_13);
      }
      const Space v1570_11 = std::move(v1570_11_result);
      v1565_12 = compose(v1565_10,v1570_11);
    }
    const Space v1565_13 = unite(v1565_8,v1565_12);
    v1564_12_result = unite(v1564_12_result,v1565_13);
  }
  const Space v1564_12 = std::move(v1564_12_result);
  return v1564_12;
}

static Space routine_181(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1574_9_result;
  for (int v1574_9_label = 1; v1574_9_label <= 2; ++v1574_9_label) {
    const Space v1574_9_tail = child(s0,v1574_9_label);
    if (v1574_9_tail.empty()) continue;
    const Path v1574_9_head{v1574_9_label};
    const Space v1575_2 = singleton(v1574_9_head);
    const Space v1575_3 = intersect(constant_2,v1575_2);
    const Space v1575_4 = (has_head(v1575_3) ? constant_3 : Space{});
    const Space v1575_5 = subtract(constant_1,v1575_4);
    Space v1575_8;
    if (!v1575_5.empty()) {
      const Path v1576_6 = concat_path(p0,v1574_9_head);
      Space v1576_7_result;
      for (int v1576_7_label = 1; v1576_7_label <= 2; ++v1576_7_label) {
        const Space v1576_7_tail = child(v1574_9_tail,v1576_7_label);
        if (v1576_7_tail.empty()) continue;
        const Path v1576_7_head{v1576_7_label};
        const Space v1577_2 = singleton(v1576_7_head);
        const Space v1577_3 = intersect(constant_2,v1577_2);
        const Space v1577_4 = (has_head(v1577_3) ? constant_3 : Space{});
        const Space v1577_5 = subtract(constant_1,v1577_4);
        Space v1577_8;
        if (!v1577_5.empty()) {
          const Path v1578_6 = concat_path(v1576_6,v1576_7_head);
          const Space v1578_7 = routine_194(c, v1578_6, p1, v1576_7_tail);
          v1577_8 = compose(v1577_5,v1578_7);
        }
        const Space v1577_9 = intersect(constant_2,v1577_2);
        const Space v1577_10 = (has_head(v1577_9) ? constant_3 : Space{});
        Space v1577_12;
        if (!v1577_10.empty()) {
          const Path v1579_6 = concat_path(v1576_6,v1576_7_head);
          const Space v1579_11 = routine_195(c, v1579_6, p1, v1576_7_tail);
          v1577_12 = compose(v1577_10,v1579_11);
        }
        const Space v1577_13 = unite(v1577_8,v1577_12);
        v1576_7_result = unite(v1576_7_result,v1577_13);
      }
      const Space v1576_7 = std::move(v1576_7_result);
      v1575_8 = compose(v1575_5,v1576_7);
    }
    const Space v1575_9 = intersect(constant_2,v1575_2);
    const Space v1575_10 = (has_head(v1575_9) ? constant_3 : Space{});
    const Space v1575_11 = compose(v1575_10,v1574_9_tail);
    const Path v1580_6 = concat_path(p0,v1574_9_head);
    const Space v1575_12 = wrap(v1575_11,v1580_6);
    const Space v1575_13 = wrap(v1575_12,p1);
    const Space v1575_14 = unite(v1575_8,v1575_13);
    v1574_9_result = unite(v1574_9_result,v1575_14);
  }
  const Space v1574_9 = std::move(v1574_9_result);
  return v1574_9;
}

static Space routine_182(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1581_7_result;
  for (int v1581_7_label = 1; v1581_7_label <= 2; ++v1581_7_label) {
    const Space v1581_7_tail = child(s0,v1581_7_label);
    if (v1581_7_tail.empty()) continue;
    const Path v1581_7_head{v1581_7_label};
    const Space v1582_2 = singleton(v1581_7_head);
    const Space v1582_3 = intersect(constant_2,v1582_2);
    const Space v1582_4 = (has_head(v1582_3) ? constant_3 : Space{});
    const Space v1582_5 = subtract(constant_1,v1582_4);
    Space v1582_6_result;
    for (int v1582_6_label = 1; v1582_6_label <= 2; ++v1582_6_label) {
      const Space v1582_6_tail = child(v1581_7_tail,v1582_6_label);
      if (v1582_6_tail.empty()) continue;
      const Path v1582_6_head{v1582_6_label};
      const Space v1583_2 = Space{};
      v1582_6_result = unite(v1582_6_result,v1583_2);
    }
    const Space v1582_6 = std::move(v1582_6_result);
    const Space v1582_7 = compose(v1582_5,v1582_6);
    const Space v1582_8 = intersect(constant_2,v1582_2);
    const Space v1582_9 = (has_head(v1582_8) ? constant_3 : Space{});
    Space v1582_12;
    if (!v1582_9.empty()) {
      const Path v1584_10 = concat_path(p0,v1581_7_head);
      Space v1584_11_result;
      for (int v1584_11_label = 1; v1584_11_label <= 2; ++v1584_11_label) {
        const Space v1584_11_tail = child(v1581_7_tail,v1584_11_label);
        if (v1584_11_tail.empty()) continue;
        const Path v1584_11_head{v1584_11_label};
        const Space v1585_2 = singleton(v1584_11_head);
        const Space v1585_3 = intersect(constant_2,v1585_2);
        const Space v1585_4 = (has_head(v1585_3) ? constant_3 : Space{});
        Space v1585_7;
        if (!v1585_4.empty()) {
          const Path v1586_5 = concat_path(v1584_10,v1584_11_head);
          const Space v1586_6 = routine_78(c, v1586_5, p1, v1584_11_tail);
          v1585_7 = compose(v1585_4,v1586_6);
        }
        v1584_11_result = unite(v1584_11_result,v1585_7);
      }
      const Space v1584_11 = std::move(v1584_11_result);
      v1582_12 = compose(v1582_9,v1584_11);
    }
    const Space v1582_13 = unite(v1582_7,v1582_12);
    v1581_7_result = unite(v1581_7_result,v1582_13);
  }
  const Space v1581_7 = std::move(v1581_7_result);
  return v1581_7;
}

static Space routine_183(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1587_6_result;
  for (int v1587_6_label = 1; v1587_6_label <= 2; ++v1587_6_label) {
    const Space v1587_6_tail = child(s0,v1587_6_label);
    if (v1587_6_tail.empty()) continue;
    const Path v1587_6_head{v1587_6_label};
    const Space v1588_2 = singleton(v1587_6_head);
    const Space v1588_3 = intersect(constant_2,v1588_2);
    const Space v1588_4 = (has_head(v1588_3) ? constant_3 : Space{});
    const Space v1588_5 = subtract(constant_1,v1588_4);
    Space v1588_6_result;
    for (int v1588_6_label = 1; v1588_6_label <= 2; ++v1588_6_label) {
      const Space v1588_6_tail = child(v1587_6_tail,v1588_6_label);
      if (v1588_6_tail.empty()) continue;
      const Path v1588_6_head{v1588_6_label};
      const Space v1589_2 = Space{};
      v1588_6_result = unite(v1588_6_result,v1589_2);
    }
    const Space v1588_6 = std::move(v1588_6_result);
    const Space v1588_7 = compose(v1588_5,v1588_6);
    const Space v1588_8 = intersect(constant_2,v1588_2);
    const Space v1588_9 = (has_head(v1588_8) ? constant_3 : Space{});
    const Space v1588_10 = compose(v1588_9,v1587_6_tail);
    const Path v1588_11 = concat_path(p0,v1587_6_head);
    const Space v1588_12 = wrap(v1588_10,v1588_11);
    const Space v1588_13 = wrap(v1588_12,p1);
    const Space v1588_14 = unite(v1588_7,v1588_13);
    v1587_6_result = unite(v1587_6_result,v1588_14);
  }
  const Space v1587_6 = std::move(v1587_6_result);
  return v1587_6;
}

static Space routine_184(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1590_4_result;
  for (int v1590_4_label = 1; v1590_4_label <= 2; ++v1590_4_label) {
    const Space v1590_4_tail = child(s0,v1590_4_label);
    if (v1590_4_tail.empty()) continue;
    const Path v1590_4_head{v1590_4_label};
    const Space v1591_2 = Space{};
    v1590_4_result = unite(v1590_4_result,v1591_2);
  }
  const Space v1590_4 = std::move(v1590_4_result);
  return v1590_4;
}

static Space routine_185(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1592_6 = unwrap(s1,constant_4);
  const Space v1592_8 = unwrap(v1592_6,constant_6);
  const Space v1592_9 = unwrap(v1592_8,p0);
  Space v1592_13_result;
  for (int v1592_13_label = 1; v1592_13_label <= 2; ++v1592_13_label) {
    const Space v1592_13_tail = child(s0,v1592_13_label);
    if (v1592_13_tail.empty()) continue;
    const Path v1592_13_head{v1592_13_label};
    const Space v1593_2 = singleton(v1592_13_head);
    const Space v1593_3 = intersect(constant_2,v1593_2);
    const Space v1593_4 = (has_head(v1593_3) ? constant_3 : Space{});
    Space v1593_7;
    if (!v1593_4.empty()) {
      const Space v1594_5 = unwrap(v1592_9,v1592_13_head);
      Space v1594_6_result;
      for (int v1594_6_label = 1; v1594_6_label <= 2; ++v1594_6_label) {
        const Space v1594_6_tail = child(v1594_5,v1594_6_label);
        if (v1594_6_tail.empty()) continue;
        const Path v1594_6_head{v1594_6_label};
        const Space v1595_2 = singleton(v1594_6_head);
        const Space v1595_3 = intersect(constant_2,v1595_2);
        const Space v1595_4 = (has_head(v1595_3) ? constant_3 : Space{});
        const Space v1595_5 = subtract(constant_1,v1595_4);
        Space v1595_7;
        if (!v1595_5.empty()) {
          const Space v1596_6 = routine_83(c, v1594_6_head, p1, v1594_6_tail);
          v1595_7 = compose(v1595_5,v1596_6);
        }
        const Space v1595_8 = intersect(constant_2,v1595_2);
        const Space v1595_9 = (has_head(v1595_8) ? constant_3 : Space{});
        Space v1595_11;
        if (!v1595_9.empty()) {
          const Space v1597_10 = routine_84(c, v1594_6_head, p1, v1594_6_tail);
          v1595_11 = compose(v1595_9,v1597_10);
        }
        const Space v1595_12 = unite(v1595_7,v1595_11);
        v1594_6_result = unite(v1594_6_result,v1595_12);
      }
      const Space v1594_6 = std::move(v1594_6_result);
      v1593_7 = compose(v1593_4,v1594_6);
    }
    v1592_13_result = unite(v1592_13_result,v1593_7);
  }
  const Space v1592_13 = std::move(v1592_13_result);
  return v1592_13;
}

static Space routine_186(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1598_12_result;
  for (int v1598_12_label = 1; v1598_12_label <= 2; ++v1598_12_label) {
    const Space v1598_12_tail = child(s0,v1598_12_label);
    if (v1598_12_tail.empty()) continue;
    const Path v1598_12_head{v1598_12_label};
    const Space v1599_2 = singleton(v1598_12_head);
    const Space v1599_3 = intersect(constant_2,v1599_2);
    const Space v1599_4 = (has_head(v1599_3) ? constant_3 : Space{});
    const Space v1599_5 = subtract(constant_1,v1599_4);
    Space v1599_8;
    if (!v1599_5.empty()) {
      const Path v1600_6 = concat_path(p0,v1598_12_head);
      Space v1600_7_result;
      for (int v1600_7_label = 1; v1600_7_label <= 2; ++v1600_7_label) {
        const Space v1600_7_tail = child(v1598_12_tail,v1600_7_label);
        if (v1600_7_tail.empty()) continue;
        const Path v1600_7_head{v1600_7_label};
        const Space v1601_2 = singleton(v1600_7_head);
        const Space v1601_3 = intersect(constant_2,v1601_2);
        const Space v1601_4 = (has_head(v1601_3) ? constant_3 : Space{});
        const Space v1601_5 = subtract(constant_1,v1601_4);
        Space v1601_8;
        if (!v1601_5.empty()) {
          const Path v1602_6 = concat_path(v1600_6,v1600_7_head);
          const Space v1602_7 = routine_196(c, v1602_6, p1, v1600_7_tail);
          v1601_8 = compose(v1601_5,v1602_7);
        }
        const Space v1601_9 = intersect(constant_2,v1601_2);
        const Space v1601_10 = (has_head(v1601_9) ? constant_3 : Space{});
        Space v1601_12;
        if (!v1601_10.empty()) {
          const Path v1603_6 = concat_path(v1600_6,v1600_7_head);
          const Space v1603_11 = routine_197(c, v1603_6, p1, v1600_7_tail);
          v1601_12 = compose(v1601_10,v1603_11);
        }
        const Space v1601_13 = unite(v1601_8,v1601_12);
        v1600_7_result = unite(v1600_7_result,v1601_13);
      }
      const Space v1600_7 = std::move(v1600_7_result);
      v1599_8 = compose(v1599_5,v1600_7);
    }
    const Space v1599_9 = intersect(constant_2,v1599_2);
    const Space v1599_10 = (has_head(v1599_9) ? constant_3 : Space{});
    Space v1599_12;
    if (!v1599_10.empty()) {
      const Path v1604_6 = concat_path(p0,v1598_12_head);
      Space v1604_11_result;
      for (int v1604_11_label = 1; v1604_11_label <= 2; ++v1604_11_label) {
        const Space v1604_11_tail = child(v1598_12_tail,v1604_11_label);
        if (v1604_11_tail.empty()) continue;
        const Path v1604_11_head{v1604_11_label};
        const Space v1605_2 = singleton(v1604_11_head);
        const Space v1605_3 = intersect(constant_2,v1605_2);
        const Space v1605_4 = (has_head(v1605_3) ? constant_3 : Space{});
        const Space v1605_5 = subtract(constant_1,v1605_4);
        Space v1605_8;
        if (!v1605_5.empty()) {
          const Path v1606_6 = concat_path(v1604_6,v1604_11_head);
          const Space v1606_7 = routine_196(c, v1606_6, p1, v1604_11_tail);
          v1605_8 = compose(v1605_5,v1606_7);
        }
        const Space v1605_9 = intersect(constant_2,v1605_2);
        const Space v1605_10 = (has_head(v1605_9) ? constant_3 : Space{});
        Space v1605_12;
        if (!v1605_10.empty()) {
          const Path v1607_6 = concat_path(v1604_6,v1604_11_head);
          const Space v1607_11 = routine_89(c, v1607_6, p1, v1604_11_tail);
          v1605_12 = compose(v1605_10,v1607_11);
        }
        const Space v1605_13 = unite(v1605_8,v1605_12);
        v1604_11_result = unite(v1604_11_result,v1605_13);
      }
      const Space v1604_11 = std::move(v1604_11_result);
      v1599_12 = compose(v1599_10,v1604_11);
    }
    const Space v1599_13 = unite(v1599_8,v1599_12);
    v1598_12_result = unite(v1598_12_result,v1599_13);
  }
  const Space v1598_12 = std::move(v1598_12_result);
  return v1598_12;
}

static Space routine_187(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1608_9_result;
  for (int v1608_9_label = 1; v1608_9_label <= 2; ++v1608_9_label) {
    const Space v1608_9_tail = child(s0,v1608_9_label);
    if (v1608_9_tail.empty()) continue;
    const Path v1608_9_head{v1608_9_label};
    const Space v1609_2 = singleton(v1608_9_head);
    const Space v1609_3 = intersect(constant_2,v1609_2);
    const Space v1609_4 = (has_head(v1609_3) ? constant_3 : Space{});
    const Space v1609_5 = subtract(constant_1,v1609_4);
    Space v1609_8;
    if (!v1609_5.empty()) {
      const Path v1610_6 = concat_path(p0,v1608_9_head);
      Space v1610_7_result;
      for (int v1610_7_label = 1; v1610_7_label <= 2; ++v1610_7_label) {
        const Space v1610_7_tail = child(v1608_9_tail,v1610_7_label);
        if (v1610_7_tail.empty()) continue;
        const Path v1610_7_head{v1610_7_label};
        const Space v1611_2 = singleton(v1610_7_head);
        const Space v1611_3 = intersect(constant_2,v1611_2);
        const Space v1611_4 = (has_head(v1611_3) ? constant_3 : Space{});
        const Space v1611_5 = subtract(constant_1,v1611_4);
        Space v1611_8;
        if (!v1611_5.empty()) {
          const Path v1612_6 = concat_path(v1610_6,v1610_7_head);
          const Space v1612_7 = routine_196(c, v1612_6, p1, v1610_7_tail);
          v1611_8 = compose(v1611_5,v1612_7);
        }
        const Space v1611_9 = intersect(constant_2,v1611_2);
        const Space v1611_10 = (has_head(v1611_9) ? constant_3 : Space{});
        Space v1611_12;
        if (!v1611_10.empty()) {
          const Path v1613_6 = concat_path(v1610_6,v1610_7_head);
          const Space v1613_11 = routine_197(c, v1613_6, p1, v1610_7_tail);
          v1611_12 = compose(v1611_10,v1613_11);
        }
        const Space v1611_13 = unite(v1611_8,v1611_12);
        v1610_7_result = unite(v1610_7_result,v1611_13);
      }
      const Space v1610_7 = std::move(v1610_7_result);
      v1609_8 = compose(v1609_5,v1610_7);
    }
    const Space v1609_9 = intersect(constant_2,v1609_2);
    const Space v1609_10 = (has_head(v1609_9) ? constant_3 : Space{});
    const Space v1609_11 = compose(v1609_10,v1608_9_tail);
    const Path v1614_6 = concat_path(p0,v1608_9_head);
    const Space v1609_12 = wrap(v1609_11,v1614_6);
    const Space v1609_13 = wrap(v1609_12,p1);
    const Space v1609_14 = unite(v1609_8,v1609_13);
    v1608_9_result = unite(v1608_9_result,v1609_14);
  }
  const Space v1608_9 = std::move(v1608_9_result);
  return v1608_9;
}

static Space routine_188(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1615_7_result;
  for (int v1615_7_label = 1; v1615_7_label <= 2; ++v1615_7_label) {
    const Space v1615_7_tail = child(s0,v1615_7_label);
    if (v1615_7_tail.empty()) continue;
    const Path v1615_7_head{v1615_7_label};
    const Space v1616_2 = singleton(v1615_7_head);
    const Space v1616_3 = intersect(constant_2,v1616_2);
    const Space v1616_4 = (has_head(v1616_3) ? constant_3 : Space{});
    const Space v1616_5 = subtract(constant_1,v1616_4);
    Space v1616_6_result;
    for (int v1616_6_label = 1; v1616_6_label <= 2; ++v1616_6_label) {
      const Space v1616_6_tail = child(v1615_7_tail,v1616_6_label);
      if (v1616_6_tail.empty()) continue;
      const Path v1616_6_head{v1616_6_label};
      const Space v1617_2 = Space{};
      v1616_6_result = unite(v1616_6_result,v1617_2);
    }
    const Space v1616_6 = std::move(v1616_6_result);
    const Space v1616_7 = compose(v1616_5,v1616_6);
    const Space v1616_8 = intersect(constant_2,v1616_2);
    const Space v1616_9 = (has_head(v1616_8) ? constant_3 : Space{});
    Space v1616_12;
    if (!v1616_9.empty()) {
      const Path v1618_10 = concat_path(p0,v1615_7_head);
      Space v1618_11_result;
      for (int v1618_11_label = 1; v1618_11_label <= 2; ++v1618_11_label) {
        const Space v1618_11_tail = child(v1615_7_tail,v1618_11_label);
        if (v1618_11_tail.empty()) continue;
        const Path v1618_11_head{v1618_11_label};
        const Space v1619_2 = singleton(v1618_11_head);
        const Space v1619_3 = intersect(constant_2,v1619_2);
        const Space v1619_4 = (has_head(v1619_3) ? constant_3 : Space{});
        Space v1619_7;
        if (!v1619_4.empty()) {
          const Path v1620_5 = concat_path(v1618_10,v1618_11_head);
          const Space v1620_6 = routine_89(c, v1620_5, p1, v1618_11_tail);
          v1619_7 = compose(v1619_4,v1620_6);
        }
        v1618_11_result = unite(v1618_11_result,v1619_7);
      }
      const Space v1618_11 = std::move(v1618_11_result);
      v1616_12 = compose(v1616_9,v1618_11);
    }
    const Space v1616_13 = unite(v1616_7,v1616_12);
    v1615_7_result = unite(v1615_7_result,v1616_13);
  }
  const Space v1615_7 = std::move(v1615_7_result);
  return v1615_7;
}

static Space routine_189(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1621_6_result;
  for (int v1621_6_label = 1; v1621_6_label <= 2; ++v1621_6_label) {
    const Space v1621_6_tail = child(s0,v1621_6_label);
    if (v1621_6_tail.empty()) continue;
    const Path v1621_6_head{v1621_6_label};
    const Space v1622_2 = singleton(v1621_6_head);
    const Space v1622_3 = intersect(constant_2,v1622_2);
    const Space v1622_4 = (has_head(v1622_3) ? constant_3 : Space{});
    const Space v1622_5 = subtract(constant_1,v1622_4);
    Space v1622_6_result;
    for (int v1622_6_label = 1; v1622_6_label <= 2; ++v1622_6_label) {
      const Space v1622_6_tail = child(v1621_6_tail,v1622_6_label);
      if (v1622_6_tail.empty()) continue;
      const Path v1622_6_head{v1622_6_label};
      const Space v1623_2 = Space{};
      v1622_6_result = unite(v1622_6_result,v1623_2);
    }
    const Space v1622_6 = std::move(v1622_6_result);
    const Space v1622_7 = compose(v1622_5,v1622_6);
    const Space v1622_8 = intersect(constant_2,v1622_2);
    const Space v1622_9 = (has_head(v1622_8) ? constant_3 : Space{});
    const Space v1622_10 = compose(v1622_9,v1621_6_tail);
    const Path v1622_11 = concat_path(p0,v1621_6_head);
    const Space v1622_12 = wrap(v1622_10,v1622_11);
    const Space v1622_13 = wrap(v1622_12,p1);
    const Space v1622_14 = unite(v1622_7,v1622_13);
    v1621_6_result = unite(v1621_6_result,v1622_14);
  }
  const Space v1621_6 = std::move(v1621_6_result);
  return v1621_6;
}

static Space routine_190(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1624_3_result;
  for (int v1624_3_label = 1; v1624_3_label <= 2; ++v1624_3_label) {
    const Space v1624_3_tail = child(s0,v1624_3_label);
    if (v1624_3_tail.empty()) continue;
    const Path v1624_3_head{v1624_3_label};
    const Space v1625_2 = Space{};
    v1624_3_result = unite(v1624_3_result,v1625_2);
  }
  const Space v1624_3 = std::move(v1624_3_result);
  return v1624_3;
}

static Space routine_191(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1626_4_result;
  for (int v1626_4_label = 1; v1626_4_label <= 2; ++v1626_4_label) {
    const Space v1626_4_tail = child(s0,v1626_4_label);
    if (v1626_4_tail.empty()) continue;
    const Path v1626_4_head{v1626_4_label};
    const Space v1627_2 = singleton(v1626_4_head);
    const Space v1627_3 = intersect(constant_2,v1627_2);
    const Space v1627_4 = (has_head(v1627_3) ? constant_3 : Space{});
    const Space v1627_5 = compose(v1627_4,v1626_4_tail);
    const Path v1627_6 = concat_path(p0,v1626_4_head);
    const Space v1627_7 = wrap(v1627_5,v1627_6);
    v1626_4_result = unite(v1626_4_result,v1627_7);
  }
  const Space v1626_4 = std::move(v1626_4_result);
  const Space v1626_5 = wrap(v1626_4,p1);
  return v1626_5;
}

static Space routine_192(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1628_3_result;
  for (int v1628_3_label = 1; v1628_3_label <= 2; ++v1628_3_label) {
    const Space v1628_3_tail = child(s0,v1628_3_label);
    if (v1628_3_tail.empty()) continue;
    const Path v1628_3_head{v1628_3_label};
    const Space v1629_2 = Space{};
    v1628_3_result = unite(v1628_3_result,v1629_2);
  }
  const Space v1628_3 = std::move(v1628_3_result);
  return v1628_3;
}

static Space routine_193(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1630_4_result;
  for (int v1630_4_label = 1; v1630_4_label <= 2; ++v1630_4_label) {
    const Space v1630_4_tail = child(s0,v1630_4_label);
    if (v1630_4_tail.empty()) continue;
    const Path v1630_4_head{v1630_4_label};
    const Space v1631_2 = singleton(v1630_4_head);
    const Space v1631_3 = intersect(constant_2,v1631_2);
    const Space v1631_4 = (has_head(v1631_3) ? constant_3 : Space{});
    const Space v1631_5 = compose(v1631_4,v1630_4_tail);
    const Path v1631_6 = concat_path(p0,v1630_4_head);
    const Space v1631_7 = wrap(v1631_5,v1631_6);
    v1630_4_result = unite(v1630_4_result,v1631_7);
  }
  const Space v1630_4 = std::move(v1630_4_result);
  const Space v1630_5 = wrap(v1630_4,p1);
  return v1630_5;
}

static Space routine_194(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1632_3_result;
  for (int v1632_3_label = 1; v1632_3_label <= 2; ++v1632_3_label) {
    const Space v1632_3_tail = child(s0,v1632_3_label);
    if (v1632_3_tail.empty()) continue;
    const Path v1632_3_head{v1632_3_label};
    const Space v1633_2 = Space{};
    v1632_3_result = unite(v1632_3_result,v1633_2);
  }
  const Space v1632_3 = std::move(v1632_3_result);
  return v1632_3;
}

static Space routine_195(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1634_4_result;
  for (int v1634_4_label = 1; v1634_4_label <= 2; ++v1634_4_label) {
    const Space v1634_4_tail = child(s0,v1634_4_label);
    if (v1634_4_tail.empty()) continue;
    const Path v1634_4_head{v1634_4_label};
    const Space v1635_2 = singleton(v1634_4_head);
    const Space v1635_3 = intersect(constant_2,v1635_2);
    const Space v1635_4 = (has_head(v1635_3) ? constant_3 : Space{});
    const Space v1635_5 = compose(v1635_4,v1634_4_tail);
    const Path v1635_6 = concat_path(p0,v1634_4_head);
    const Space v1635_7 = wrap(v1635_5,v1635_6);
    v1634_4_result = unite(v1634_4_result,v1635_7);
  }
  const Space v1634_4 = std::move(v1634_4_result);
  const Space v1634_5 = wrap(v1634_4,p1);
  return v1634_5;
}

static Space routine_196(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1636_3_result;
  for (int v1636_3_label = 1; v1636_3_label <= 2; ++v1636_3_label) {
    const Space v1636_3_tail = child(s0,v1636_3_label);
    if (v1636_3_tail.empty()) continue;
    const Path v1636_3_head{v1636_3_label};
    const Space v1637_2 = Space{};
    v1636_3_result = unite(v1636_3_result,v1637_2);
  }
  const Space v1636_3 = std::move(v1636_3_result);
  return v1636_3;
}

static Space routine_197(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1638_4_result;
  for (int v1638_4_label = 1; v1638_4_label <= 2; ++v1638_4_label) {
    const Space v1638_4_tail = child(s0,v1638_4_label);
    if (v1638_4_tail.empty()) continue;
    const Path v1638_4_head{v1638_4_label};
    const Space v1639_2 = singleton(v1638_4_head);
    const Space v1639_3 = intersect(constant_2,v1639_2);
    const Space v1639_4 = (has_head(v1639_3) ? constant_3 : Space{});
    const Space v1639_5 = compose(v1639_4,v1638_4_tail);
    const Path v1639_6 = concat_path(p0,v1638_4_head);
    const Space v1639_7 = wrap(v1639_5,v1639_6);
    v1638_4_result = unite(v1638_4_result,v1639_7);
  }
  const Space v1638_4 = std::move(v1638_4_result);
  const Space v1638_5 = wrap(v1638_4,p1);
  return v1638_5;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
