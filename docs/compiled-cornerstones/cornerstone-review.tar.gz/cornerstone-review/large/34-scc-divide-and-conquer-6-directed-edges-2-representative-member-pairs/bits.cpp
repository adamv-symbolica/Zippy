#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Path constant_1 = Path{1,1};
static const Space constant_2 = literal_text("2 8 1 2 2 2 1 1 2 2 6 2 2 2 1 2 2");
static const Path constant_3 = Path{2,1};
static const Space constant_4 = literal_text("1 6 2 2 1 1 2 2");
static const Path constant_5 = Path{1,2};
static const Space constant_6 = literal_text("2 5 2 1 1 2 2 3 2 2 2");
static const Path constant_7 = Path{2,2};
static const Space constant_8 = literal_text("1 3 1 2 2");
static const Space constant_9 = literal_text("1 1 2");
static const Space constant_10 = singleton(Path{});
static const Space constant_11 = literal_text("6 10 1 1 1 2 2 2 1 1 2 2 8 1 1 2 2 2 1 2 2 7 1 2 2 1 1 2 2 5 1 2 2 2 2 8 2 1 2 2 1 1 2 2 5 2 2 1 2 2");
static const Path constant_12 = Path{};
static Space routine_0(Context& c);
static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_53(Context& c, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_54(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_36(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_56(Context& c, const Path& p0, const Space& s0);
static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Space& s0);
static Space routine_57(Context& c, const Path& p0, const Space& s0);
static Space routine_59(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Space& s0);
static Space routine_10(Context& c, const Space& s0);
static Space routine_44(Context& c, const Path& p0, const Space& s0);
static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3);
static Space routine_52(Context& c, const Path& p0, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_38(Context& c, const Space& s0, const Space& s1, const Space& s2);
static Space routine_39(Context& c, const Space& s0, const Space& s1, const Space& s2);
static Space routine_0(Context& c) {
  Space v0_18;
  if (!constant_0.empty()) {
    Space v1_17;
    if (!constant_0.empty()) {
      const Space v2_4 = routine_1(c, constant_1, constant_2);
      const Space v2_7 = routine_1(c, constant_3, constant_4);
      const Space v2_8 = unite(v2_4,v2_7);
      const Space v2_11 = routine_2(c, constant_5, constant_6);
      const Space v2_12 = unite(v2_8,v2_11);
      const Space v2_15 = routine_3(c, constant_7, constant_8);
      const Space v2_16 = unite(v2_12,v2_15);
      v1_17 = compose(constant_0,v2_16);
    }
    v0_18 = compose(constant_0,v1_17);
  }
  Space v0_33;
  if (!constant_0.empty()) {
    Space v3_32;
    if (!constant_0.empty()) {
      const Space v4_22 = routine_4(c, constant_1, constant_2);
      const Space v4_24 = routine_4(c, constant_3, constant_4);
      const Space v4_25 = unite(v4_22,v4_24);
      const Space v4_27 = routine_5(c, constant_5, constant_6);
      const Space v4_28 = unite(v4_25,v4_27);
      const Space v4_30 = routine_6(c, constant_7, constant_8);
      const Space v4_31 = unite(v4_28,v4_30);
      v3_32 = compose(constant_0,v4_31);
    }
    v0_33 = compose(constant_0,v3_32);
  }
  Space v0_43_result;
  for (int v0_43_label = 1; v0_43_label <= 2; ++v0_43_label) {
    const Space v0_43_tail = child(v0_33,v0_43_label);
    if (v0_43_tail.empty()) continue;
    const Path v0_43_head{v0_43_label};
    const Space v5_2 = singleton(v0_43_head);
    const Space v5_3 = intersect(constant_9,v5_2);
    const Space v5_4 = (has_head(v5_3) ? constant_10 : Space{});
    const Space v5_5 = subtract(constant_0,v5_4);
    Space v5_7;
    if (!v5_5.empty()) {
      Space v6_6_result;
      for (int v6_6_label = 1; v6_6_label <= 2; ++v6_6_label) {
        const Space v6_6_tail = child(v0_43_tail,v6_6_label);
        if (v6_6_tail.empty()) continue;
        const Path v6_6_head{v6_6_label};
        const Space v7_2 = singleton(v6_6_head);
        const Space v7_3 = intersect(constant_9,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_10 : Space{});
        const Space v7_5 = subtract(constant_0,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v0_43_head,v6_6_head);
          const Space v8_7 = routine_7(c, v8_6, v6_6_tail);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_9,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_10 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v0_43_head,v6_6_head);
          const Space v9_11 = routine_8(c, v9_6, v6_6_tail);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_6_result = unite(v6_6_result,v7_13);
      }
      const Space v6_6 = std::move(v6_6_result);
      v5_7 = compose(v5_5,v6_6);
    }
    const Space v5_8 = intersect(constant_9,v5_2);
    const Space v5_9 = (has_head(v5_8) ? constant_10 : Space{});
    Space v5_11;
    if (!v5_9.empty()) {
      Space v10_10_result;
      for (int v10_10_label = 1; v10_10_label <= 2; ++v10_10_label) {
        const Space v10_10_tail = child(v0_43_tail,v10_10_label);
        if (v10_10_tail.empty()) continue;
        const Path v10_10_head{v10_10_label};
        const Space v11_2 = singleton(v10_10_head);
        const Space v11_3 = intersect(constant_9,v11_2);
        const Space v11_4 = (has_head(v11_3) ? constant_10 : Space{});
        const Space v11_5 = subtract(constant_0,v11_4);
        Space v11_8;
        if (!v11_5.empty()) {
          const Path v12_6 = concat_path(v0_43_head,v10_10_head);
          const Space v12_7 = routine_7(c, v12_6, v10_10_tail);
          v11_8 = compose(v11_5,v12_7);
        }
        const Space v11_9 = intersect(constant_9,v11_2);
        const Space v11_10 = (has_head(v11_9) ? constant_10 : Space{});
        Space v11_12;
        if (!v11_10.empty()) {
          const Path v13_6 = concat_path(v0_43_head,v10_10_head);
          const Space v13_11 = routine_9(c, v13_6, v10_10_tail);
          v11_12 = compose(v11_10,v13_11);
        }
        const Space v11_13 = unite(v11_8,v11_12);
        v10_10_result = unite(v10_10_result,v11_13);
      }
      const Space v10_10 = std::move(v10_10_result);
      v5_11 = compose(v5_9,v10_10);
    }
    const Space v5_12 = unite(v5_7,v5_11);
    v0_43_result = unite(v0_43_result,v5_12);
  }
  const Space v0_43 = std::move(v0_43_result);
  const Space v0_44 = unite(v0_18,v0_43);
  const Space v0_45 = routine_10(c, v0_44);
  Space v0_105_result;
  for (int v0_105_label = 1; v0_105_label <= 2; ++v0_105_label) {
    const Space v0_105_tail = child(v0_45,v0_105_label);
    if (v0_105_tail.empty()) continue;
    const Path v0_105_head{v0_105_label};
    const Space v14_2 = singleton(v0_105_head);
    const Space v14_3 = intersect(constant_9,v14_2);
    const Space v14_4 = (has_head(v14_3) ? constant_10 : Space{});
    const Space v14_5 = subtract(constant_0,v14_4);
    Space v14_36;
    if (!v14_5.empty()) {
      Space v15_14;
      if (!constant_0.empty()) {
        Space v16_13;
        if (!constant_0.empty()) {
          const Space v17_6 = routine_11(c, constant_1, constant_2);
          const Space v17_7 = routine_11(c, constant_3, constant_4);
          const Space v17_8 = unite(v17_6,v17_7);
          const Space v17_9 = routine_12(c, constant_5, constant_6);
          const Space v17_10 = unite(v17_8,v17_9);
          const Space v17_11 = routine_13(c, constant_7, constant_8);
          const Space v17_12 = unite(v17_10,v17_11);
          v16_13 = compose(constant_0,v17_12);
        }
        v15_14 = compose(constant_0,v16_13);
      }
      Space v15_23;
      if (!constant_0.empty()) {
        Space v18_22;
        if (!constant_0.empty()) {
          const Space v19_15 = routine_1(c, constant_1, constant_2);
          const Space v19_16 = routine_1(c, constant_3, constant_4);
          const Space v19_17 = unite(v19_15,v19_16);
          const Space v19_18 = routine_2(c, constant_5, constant_6);
          const Space v19_19 = unite(v19_17,v19_18);
          const Space v19_20 = routine_3(c, constant_7, constant_8);
          const Space v19_21 = unite(v19_19,v19_20);
          v18_22 = compose(constant_0,v19_21);
        }
        v15_23 = compose(constant_0,v18_22);
      }
      Space v15_32;
      if (!constant_0.empty()) {
        Space v20_31;
        if (!constant_0.empty()) {
          const Space v21_24 = routine_4(c, constant_1, constant_2);
          const Space v21_25 = routine_4(c, constant_3, constant_4);
          const Space v21_26 = unite(v21_24,v21_25);
          const Space v21_27 = routine_5(c, constant_5, constant_6);
          const Space v21_28 = unite(v21_26,v21_27);
          const Space v21_29 = routine_6(c, constant_7, constant_8);
          const Space v21_30 = unite(v21_28,v21_29);
          v20_31 = compose(constant_0,v21_30);
        }
        v15_32 = compose(constant_0,v20_31);
      }
      Space v15_33_result;
      for (int v15_33_label = 1; v15_33_label <= 2; ++v15_33_label) {
        const Space v15_33_tail = child(v15_32,v15_33_label);
        if (v15_33_tail.empty()) continue;
        const Path v15_33_head{v15_33_label};
        const Space v22_2 = singleton(v15_33_head);
        const Space v22_3 = intersect(constant_9,v22_2);
        const Space v22_4 = (has_head(v22_3) ? constant_10 : Space{});
        const Space v22_5 = subtract(constant_0,v22_4);
        Space v22_7;
        if (!v22_5.empty()) {
          Space v23_6_result;
          for (int v23_6_label = 1; v23_6_label <= 2; ++v23_6_label) {
            const Space v23_6_tail = child(v15_33_tail,v23_6_label);
            if (v23_6_tail.empty()) continue;
            const Path v23_6_head{v23_6_label};
            const Space v24_2 = singleton(v23_6_head);
            const Space v24_3 = intersect(constant_9,v24_2);
            const Space v24_4 = (has_head(v24_3) ? constant_10 : Space{});
            const Space v24_5 = subtract(constant_0,v24_4);
            Space v24_8;
            if (!v24_5.empty()) {
              const Path v25_6 = concat_path(v15_33_head,v23_6_head);
              const Space v25_7 = routine_7(c, v25_6, v23_6_tail);
              v24_8 = compose(v24_5,v25_7);
            }
            const Space v24_9 = intersect(constant_9,v24_2);
            const Space v24_10 = (has_head(v24_9) ? constant_10 : Space{});
            Space v24_12;
            if (!v24_10.empty()) {
              const Path v26_6 = concat_path(v15_33_head,v23_6_head);
              const Space v26_11 = routine_8(c, v26_6, v23_6_tail);
              v24_12 = compose(v24_10,v26_11);
            }
            const Space v24_13 = unite(v24_8,v24_12);
            v23_6_result = unite(v23_6_result,v24_13);
          }
          const Space v23_6 = std::move(v23_6_result);
          v22_7 = compose(v22_5,v23_6);
        }
        const Space v22_8 = intersect(constant_9,v22_2);
        const Space v22_9 = (has_head(v22_8) ? constant_10 : Space{});
        Space v22_11;
        if (!v22_9.empty()) {
          Space v27_10_result;
          for (int v27_10_label = 1; v27_10_label <= 2; ++v27_10_label) {
            const Space v27_10_tail = child(v15_33_tail,v27_10_label);
            if (v27_10_tail.empty()) continue;
            const Path v27_10_head{v27_10_label};
            const Space v28_2 = singleton(v27_10_head);
            const Space v28_3 = intersect(constant_9,v28_2);
            const Space v28_4 = (has_head(v28_3) ? constant_10 : Space{});
            const Space v28_5 = subtract(constant_0,v28_4);
            Space v28_8;
            if (!v28_5.empty()) {
              const Path v29_6 = concat_path(v15_33_head,v27_10_head);
              const Space v29_7 = routine_7(c, v29_6, v27_10_tail);
              v28_8 = compose(v28_5,v29_7);
            }
            const Space v28_9 = intersect(constant_9,v28_2);
            const Space v28_10 = (has_head(v28_9) ? constant_10 : Space{});
            Space v28_12;
            if (!v28_10.empty()) {
              const Path v30_6 = concat_path(v15_33_head,v27_10_head);
              const Space v30_11 = routine_9(c, v30_6, v27_10_tail);
              v28_12 = compose(v28_10,v30_11);
            }
            const Space v28_13 = unite(v28_8,v28_12);
            v27_10_result = unite(v27_10_result,v28_13);
          }
          const Space v27_10 = std::move(v27_10_result);
          v22_11 = compose(v22_9,v27_10);
        }
        const Space v22_12 = unite(v22_7,v22_11);
        v15_33_result = unite(v15_33_result,v22_12);
      }
      const Space v15_33 = std::move(v15_33_result);
      const Space v15_34 = unite(v15_23,v15_33);
      const Space v15_35 = routine_14(c, v0_105_head, v0_105_tail, v15_14, constant_11, v15_34);
      v14_36 = compose(v14_5,v15_35);
    }
    const Space v14_37 = intersect(constant_9,v14_2);
    const Space v14_38 = (has_head(v14_37) ? constant_10 : Space{});
    Space v14_69;
    if (!v14_38.empty()) {
      Space v31_47;
      if (!constant_0.empty()) {
        Space v32_46;
        if (!constant_0.empty()) {
          const Space v33_39 = routine_11(c, constant_1, constant_2);
          const Space v33_40 = routine_11(c, constant_3, constant_4);
          const Space v33_41 = unite(v33_39,v33_40);
          const Space v33_42 = routine_12(c, constant_5, constant_6);
          const Space v33_43 = unite(v33_41,v33_42);
          const Space v33_44 = routine_13(c, constant_7, constant_8);
          const Space v33_45 = unite(v33_43,v33_44);
          v32_46 = compose(constant_0,v33_45);
        }
        v31_47 = compose(constant_0,v32_46);
      }
      Space v31_56;
      if (!constant_0.empty()) {
        Space v34_55;
        if (!constant_0.empty()) {
          const Space v35_48 = routine_1(c, constant_1, constant_2);
          const Space v35_49 = routine_1(c, constant_3, constant_4);
          const Space v35_50 = unite(v35_48,v35_49);
          const Space v35_51 = routine_2(c, constant_5, constant_6);
          const Space v35_52 = unite(v35_50,v35_51);
          const Space v35_53 = routine_3(c, constant_7, constant_8);
          const Space v35_54 = unite(v35_52,v35_53);
          v34_55 = compose(constant_0,v35_54);
        }
        v31_56 = compose(constant_0,v34_55);
      }
      Space v31_65;
      if (!constant_0.empty()) {
        Space v36_64;
        if (!constant_0.empty()) {
          const Space v37_57 = routine_4(c, constant_1, constant_2);
          const Space v37_58 = routine_4(c, constant_3, constant_4);
          const Space v37_59 = unite(v37_57,v37_58);
          const Space v37_60 = routine_5(c, constant_5, constant_6);
          const Space v37_61 = unite(v37_59,v37_60);
          const Space v37_62 = routine_6(c, constant_7, constant_8);
          const Space v37_63 = unite(v37_61,v37_62);
          v36_64 = compose(constant_0,v37_63);
        }
        v31_65 = compose(constant_0,v36_64);
      }
      Space v31_66_result;
      for (int v31_66_label = 1; v31_66_label <= 2; ++v31_66_label) {
        const Space v31_66_tail = child(v31_65,v31_66_label);
        if (v31_66_tail.empty()) continue;
        const Path v31_66_head{v31_66_label};
        const Space v38_2 = singleton(v31_66_head);
        const Space v38_3 = intersect(constant_9,v38_2);
        const Space v38_4 = (has_head(v38_3) ? constant_10 : Space{});
        const Space v38_5 = subtract(constant_0,v38_4);
        Space v38_7;
        if (!v38_5.empty()) {
          Space v39_6_result;
          for (int v39_6_label = 1; v39_6_label <= 2; ++v39_6_label) {
            const Space v39_6_tail = child(v31_66_tail,v39_6_label);
            if (v39_6_tail.empty()) continue;
            const Path v39_6_head{v39_6_label};
            const Space v40_2 = singleton(v39_6_head);
            const Space v40_3 = intersect(constant_9,v40_2);
            const Space v40_4 = (has_head(v40_3) ? constant_10 : Space{});
            const Space v40_5 = subtract(constant_0,v40_4);
            Space v40_8;
            if (!v40_5.empty()) {
              const Path v41_6 = concat_path(v31_66_head,v39_6_head);
              const Space v41_7 = routine_7(c, v41_6, v39_6_tail);
              v40_8 = compose(v40_5,v41_7);
            }
            const Space v40_9 = intersect(constant_9,v40_2);
            const Space v40_10 = (has_head(v40_9) ? constant_10 : Space{});
            Space v40_12;
            if (!v40_10.empty()) {
              const Path v42_6 = concat_path(v31_66_head,v39_6_head);
              const Space v42_11 = routine_8(c, v42_6, v39_6_tail);
              v40_12 = compose(v40_10,v42_11);
            }
            const Space v40_13 = unite(v40_8,v40_12);
            v39_6_result = unite(v39_6_result,v40_13);
          }
          const Space v39_6 = std::move(v39_6_result);
          v38_7 = compose(v38_5,v39_6);
        }
        const Space v38_8 = intersect(constant_9,v38_2);
        const Space v38_9 = (has_head(v38_8) ? constant_10 : Space{});
        Space v38_11;
        if (!v38_9.empty()) {
          Space v43_10_result;
          for (int v43_10_label = 1; v43_10_label <= 2; ++v43_10_label) {
            const Space v43_10_tail = child(v31_66_tail,v43_10_label);
            if (v43_10_tail.empty()) continue;
            const Path v43_10_head{v43_10_label};
            const Space v44_2 = singleton(v43_10_head);
            const Space v44_3 = intersect(constant_9,v44_2);
            const Space v44_4 = (has_head(v44_3) ? constant_10 : Space{});
            const Space v44_5 = subtract(constant_0,v44_4);
            Space v44_8;
            if (!v44_5.empty()) {
              const Path v45_6 = concat_path(v31_66_head,v43_10_head);
              const Space v45_7 = routine_7(c, v45_6, v43_10_tail);
              v44_8 = compose(v44_5,v45_7);
            }
            const Space v44_9 = intersect(constant_9,v44_2);
            const Space v44_10 = (has_head(v44_9) ? constant_10 : Space{});
            Space v44_12;
            if (!v44_10.empty()) {
              const Path v46_6 = concat_path(v31_66_head,v43_10_head);
              const Space v46_11 = routine_9(c, v46_6, v43_10_tail);
              v44_12 = compose(v44_10,v46_11);
            }
            const Space v44_13 = unite(v44_8,v44_12);
            v43_10_result = unite(v43_10_result,v44_13);
          }
          const Space v43_10 = std::move(v43_10_result);
          v38_11 = compose(v38_9,v43_10);
        }
        const Space v38_12 = unite(v38_7,v38_11);
        v31_66_result = unite(v31_66_result,v38_12);
      }
      const Space v31_66 = std::move(v31_66_result);
      const Space v31_67 = unite(v31_56,v31_66);
      const Space v31_68 = routine_15(c, v0_105_head, v0_105_tail, v31_47, constant_11, v31_67);
      v14_69 = compose(v14_38,v31_68);
    }
    const Space v14_70 = unite(v14_36,v14_69);
    v0_105_result = unite(v0_105_result,v14_70);
  }
  const Space v0_105 = std::move(v0_105_result);
  return v0_105;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v47_11_result;
  for (int v47_11_label = 1; v47_11_label <= 2; ++v47_11_label) {
    const Space v47_11_tail = child(s0,v47_11_label);
    if (v47_11_tail.empty()) continue;
    const Path v47_11_head{v47_11_label};
    const Space v48_2 = singleton(v47_11_head);
    const Space v48_3 = intersect(constant_9,v48_2);
    const Space v48_4 = (has_head(v48_3) ? constant_10 : Space{});
    const Space v48_5 = subtract(constant_0,v48_4);
    Space v48_8;
    if (!v48_5.empty()) {
      const Path v49_6 = concat_path(p0,v47_11_head);
      Space v49_7_result;
      for (int v49_7_label = 1; v49_7_label <= 2; ++v49_7_label) {
        const Space v49_7_tail = child(v47_11_tail,v49_7_label);
        if (v49_7_tail.empty()) continue;
        const Path v49_7_head{v49_7_label};
        const Space v50_2 = singleton(v49_7_head);
        const Space v50_3 = intersect(constant_9,v50_2);
        const Space v50_4 = (has_head(v50_3) ? constant_10 : Space{});
        const Space v50_5 = subtract(constant_0,v50_4);
        Space v50_8;
        if (!v50_5.empty()) {
          const Path v51_6 = concat_path(v49_6,v49_7_head);
          const Space v51_7 = routine_16(c, v51_6, v49_7_tail);
          v50_8 = compose(v50_5,v51_7);
        }
        const Space v50_9 = intersect(constant_9,v50_2);
        const Space v50_10 = (has_head(v50_9) ? constant_10 : Space{});
        Space v50_12;
        if (!v50_10.empty()) {
          const Path v52_6 = concat_path(v49_6,v49_7_head);
          const Space v52_11 = routine_17(c, v52_6, v49_7_tail);
          v50_12 = compose(v50_10,v52_11);
        }
        const Space v50_13 = unite(v50_8,v50_12);
        v49_7_result = unite(v49_7_result,v50_13);
      }
      const Space v49_7 = std::move(v49_7_result);
      v48_8 = compose(v48_5,v49_7);
    }
    const Space v48_9 = intersect(constant_9,v48_2);
    const Space v48_10 = (has_head(v48_9) ? constant_10 : Space{});
    Space v48_12;
    if (!v48_10.empty()) {
      const Path v53_6 = concat_path(p0,v47_11_head);
      Space v53_11_result;
      for (int v53_11_label = 1; v53_11_label <= 2; ++v53_11_label) {
        const Space v53_11_tail = child(v47_11_tail,v53_11_label);
        if (v53_11_tail.empty()) continue;
        const Path v53_11_head{v53_11_label};
        const Space v54_2 = singleton(v53_11_head);
        const Space v54_3 = intersect(constant_9,v54_2);
        const Space v54_4 = (has_head(v54_3) ? constant_10 : Space{});
        const Space v54_5 = subtract(constant_0,v54_4);
        Space v54_8;
        if (!v54_5.empty()) {
          const Path v55_6 = concat_path(v53_6,v53_11_head);
          const Space v55_7 = routine_16(c, v55_6, v53_11_tail);
          v54_8 = compose(v54_5,v55_7);
        }
        const Space v54_9 = intersect(constant_9,v54_2);
        const Space v54_10 = (has_head(v54_9) ? constant_10 : Space{});
        Space v54_12;
        if (!v54_10.empty()) {
          const Path v56_6 = concat_path(v53_6,v53_11_head);
          const Space v56_11 = routine_3(c, v56_6, v53_11_tail);
          v54_12 = compose(v54_10,v56_11);
        }
        const Space v54_13 = unite(v54_8,v54_12);
        v53_11_result = unite(v53_11_result,v54_13);
      }
      const Space v53_11 = std::move(v53_11_result);
      v48_12 = compose(v48_10,v53_11);
    }
    const Space v48_13 = unite(v48_8,v48_12);
    v47_11_result = unite(v47_11_result,v48_13);
  }
  const Space v47_11 = std::move(v47_11_result);
  return v47_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  Space v57_8_result;
  for (int v57_8_label = 1; v57_8_label <= 2; ++v57_8_label) {
    const Space v57_8_tail = child(s0,v57_8_label);
    if (v57_8_tail.empty()) continue;
    const Path v57_8_head{v57_8_label};
    const Space v58_2 = singleton(v57_8_head);
    const Space v58_3 = intersect(constant_9,v58_2);
    const Space v58_4 = (has_head(v58_3) ? constant_10 : Space{});
    const Space v58_5 = subtract(constant_0,v58_4);
    Space v58_8;
    if (!v58_5.empty()) {
      const Path v59_6 = concat_path(p0,v57_8_head);
      Space v59_7_result;
      for (int v59_7_label = 1; v59_7_label <= 2; ++v59_7_label) {
        const Space v59_7_tail = child(v57_8_tail,v59_7_label);
        if (v59_7_tail.empty()) continue;
        const Path v59_7_head{v59_7_label};
        const Space v60_2 = singleton(v59_7_head);
        const Space v60_3 = intersect(constant_9,v60_2);
        const Space v60_4 = (has_head(v60_3) ? constant_10 : Space{});
        const Space v60_5 = subtract(constant_0,v60_4);
        Space v60_8;
        if (!v60_5.empty()) {
          const Path v61_6 = concat_path(v59_6,v59_7_head);
          const Space v61_7 = routine_16(c, v61_6, v59_7_tail);
          v60_8 = compose(v60_5,v61_7);
        }
        const Space v60_9 = intersect(constant_9,v60_2);
        const Space v60_10 = (has_head(v60_9) ? constant_10 : Space{});
        Space v60_12;
        if (!v60_10.empty()) {
          const Path v62_6 = concat_path(v59_6,v59_7_head);
          const Space v62_11 = routine_17(c, v62_6, v59_7_tail);
          v60_12 = compose(v60_10,v62_11);
        }
        const Space v60_13 = unite(v60_8,v60_12);
        v59_7_result = unite(v59_7_result,v60_13);
      }
      const Space v59_7 = std::move(v59_7_result);
      v58_8 = compose(v58_5,v59_7);
    }
    const Space v58_9 = intersect(constant_9,v58_2);
    const Space v58_10 = (has_head(v58_9) ? constant_10 : Space{});
    const Path v63_6 = concat_path(p0,v57_8_head);
    const Space v58_11 = singleton(v63_6);
    const Space v58_12 = compose(v58_10,v58_11);
    const Space v58_13 = unite(v58_8,v58_12);
    v57_8_result = unite(v57_8_result,v58_13);
  }
  const Space v57_8 = std::move(v57_8_result);
  return v57_8;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  const Space v64_2 = singleton(p0);
  return v64_2;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0) {
  Space v65_11_result;
  for (int v65_11_label = 1; v65_11_label <= 2; ++v65_11_label) {
    const Space v65_11_tail = child(s0,v65_11_label);
    if (v65_11_tail.empty()) continue;
    const Path v65_11_head{v65_11_label};
    const Space v66_2 = singleton(v65_11_head);
    const Space v66_3 = intersect(constant_9,v66_2);
    const Space v66_4 = (has_head(v66_3) ? constant_10 : Space{});
    const Space v66_5 = subtract(constant_0,v66_4);
    Space v66_8;
    if (!v66_5.empty()) {
      const Path v67_6 = concat_path(p0,v65_11_head);
      Space v67_7_result;
      for (int v67_7_label = 1; v67_7_label <= 2; ++v67_7_label) {
        const Space v67_7_tail = child(v65_11_tail,v67_7_label);
        if (v67_7_tail.empty()) continue;
        const Path v67_7_head{v67_7_label};
        const Space v68_2 = singleton(v67_7_head);
        const Space v68_3 = intersect(constant_9,v68_2);
        const Space v68_4 = (has_head(v68_3) ? constant_10 : Space{});
        const Space v68_5 = subtract(constant_0,v68_4);
        Space v68_8;
        if (!v68_5.empty()) {
          const Path v69_6 = concat_path(v67_6,v67_7_head);
          const Space v69_7 = routine_18(c, v69_6, v67_7_tail);
          v68_8 = compose(v68_5,v69_7);
        }
        const Space v68_9 = intersect(constant_9,v68_2);
        const Space v68_10 = (has_head(v68_9) ? constant_10 : Space{});
        Space v68_12;
        if (!v68_10.empty()) {
          const Path v70_6 = concat_path(v67_6,v67_7_head);
          const Space v70_11 = routine_19(c, v70_6, v67_7_tail);
          v68_12 = compose(v68_10,v70_11);
        }
        const Space v68_13 = unite(v68_8,v68_12);
        v67_7_result = unite(v67_7_result,v68_13);
      }
      const Space v67_7 = std::move(v67_7_result);
      v66_8 = compose(v66_5,v67_7);
    }
    const Space v66_9 = intersect(constant_9,v66_2);
    const Space v66_10 = (has_head(v66_9) ? constant_10 : Space{});
    Space v66_12;
    if (!v66_10.empty()) {
      const Path v71_6 = concat_path(p0,v65_11_head);
      Space v71_11_result;
      for (int v71_11_label = 1; v71_11_label <= 2; ++v71_11_label) {
        const Space v71_11_tail = child(v65_11_tail,v71_11_label);
        if (v71_11_tail.empty()) continue;
        const Path v71_11_head{v71_11_label};
        const Space v72_2 = singleton(v71_11_head);
        const Space v72_3 = intersect(constant_9,v72_2);
        const Space v72_4 = (has_head(v72_3) ? constant_10 : Space{});
        const Space v72_5 = subtract(constant_0,v72_4);
        Space v72_8;
        if (!v72_5.empty()) {
          const Path v73_6 = concat_path(v71_6,v71_11_head);
          const Space v73_7 = routine_18(c, v73_6, v71_11_tail);
          v72_8 = compose(v72_5,v73_7);
        }
        const Space v72_9 = intersect(constant_9,v72_2);
        const Space v72_10 = (has_head(v72_9) ? constant_10 : Space{});
        Space v72_12;
        if (!v72_10.empty()) {
          const Path v74_6 = concat_path(v71_6,v71_11_head);
          const Space v74_11 = routine_6(c, v74_6, v71_11_tail);
          v72_12 = compose(v72_10,v74_11);
        }
        const Space v72_13 = unite(v72_8,v72_12);
        v71_11_result = unite(v71_11_result,v72_13);
      }
      const Space v71_11 = std::move(v71_11_result);
      v66_12 = compose(v66_10,v71_11);
    }
    const Space v66_13 = unite(v66_8,v66_12);
    v65_11_result = unite(v65_11_result,v66_13);
  }
  const Space v65_11 = std::move(v65_11_result);
  return v65_11;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0) {
  Space v75_11_result;
  for (int v75_11_label = 1; v75_11_label <= 2; ++v75_11_label) {
    const Space v75_11_tail = child(s0,v75_11_label);
    if (v75_11_tail.empty()) continue;
    const Path v75_11_head{v75_11_label};
    const Space v76_2 = singleton(v75_11_head);
    const Space v76_3 = intersect(constant_9,v76_2);
    const Space v76_4 = (has_head(v76_3) ? constant_10 : Space{});
    const Space v76_5 = subtract(constant_0,v76_4);
    Space v76_8;
    if (!v76_5.empty()) {
      const Path v77_6 = concat_path(p0,v75_11_head);
      Space v77_7_result;
      for (int v77_7_label = 1; v77_7_label <= 2; ++v77_7_label) {
        const Space v77_7_tail = child(v75_11_tail,v77_7_label);
        if (v77_7_tail.empty()) continue;
        const Path v77_7_head{v77_7_label};
        const Space v78_2 = singleton(v77_7_head);
        const Space v78_3 = intersect(constant_9,v78_2);
        const Space v78_4 = (has_head(v78_3) ? constant_10 : Space{});
        const Space v78_5 = subtract(constant_0,v78_4);
        Space v78_8;
        if (!v78_5.empty()) {
          const Path v79_6 = concat_path(v77_6,v77_7_head);
          const Space v79_7 = routine_18(c, v79_6, v77_7_tail);
          v78_8 = compose(v78_5,v79_7);
        }
        const Space v78_9 = intersect(constant_9,v78_2);
        const Space v78_10 = (has_head(v78_9) ? constant_10 : Space{});
        Space v78_12;
        if (!v78_10.empty()) {
          const Path v80_6 = concat_path(v77_6,v77_7_head);
          const Space v80_11 = routine_19(c, v80_6, v77_7_tail);
          v78_12 = compose(v78_10,v80_11);
        }
        const Space v78_13 = unite(v78_8,v78_12);
        v77_7_result = unite(v77_7_result,v78_13);
      }
      const Space v77_7 = std::move(v77_7_result);
      v76_8 = compose(v76_5,v77_7);
    }
    const Space v76_9 = intersect(constant_9,v76_2);
    const Space v76_10 = (has_head(v76_9) ? constant_10 : Space{});
    Space v76_12;
    if (!v76_10.empty()) {
      const Path v81_6 = concat_path(p0,v75_11_head);
      Space v81_11_result;
      for (int v81_11_label = 1; v81_11_label <= 2; ++v81_11_label) {
        const Space v81_11_tail = child(v75_11_tail,v81_11_label);
        if (v81_11_tail.empty()) continue;
        const Path v81_11_head{v81_11_label};
        const Space v82_2 = singleton(v81_11_head);
        const Space v82_3 = intersect(constant_9,v82_2);
        const Space v82_4 = (has_head(v82_3) ? constant_10 : Space{});
        const Space v82_5 = subtract(constant_0,v82_4);
        Space v82_7;
        if (!v82_5.empty()) {
          const Space v83_6 = routine_20(c, v81_11_head, v81_6, v81_11_tail);
          v82_7 = compose(v82_5,v83_6);
        }
        const Space v82_8 = intersect(constant_9,v82_2);
        const Space v82_9 = (has_head(v82_8) ? constant_10 : Space{});
        Space v82_11;
        if (!v82_9.empty()) {
          const Space v84_10 = routine_21(c, v81_11_head, v81_6, v81_11_tail);
          v82_11 = compose(v82_9,v84_10);
        }
        const Space v82_12 = unite(v82_7,v82_11);
        v81_11_result = unite(v81_11_result,v82_12);
      }
      const Space v81_11 = std::move(v81_11_result);
      v76_12 = compose(v76_10,v81_11);
    }
    const Space v76_13 = unite(v76_8,v76_12);
    v75_11_result = unite(v75_11_result,v76_13);
  }
  const Space v75_11 = std::move(v75_11_result);
  return v75_11;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  Space v85_11_result;
  for (int v85_11_label = 1; v85_11_label <= 2; ++v85_11_label) {
    const Space v85_11_tail = child(s0,v85_11_label);
    if (v85_11_tail.empty()) continue;
    const Path v85_11_head{v85_11_label};
    const Space v86_2 = singleton(v85_11_head);
    const Space v86_3 = intersect(constant_9,v86_2);
    const Space v86_4 = (has_head(v86_3) ? constant_10 : Space{});
    const Space v86_5 = subtract(constant_0,v86_4);
    Space v86_7;
    if (!v86_5.empty()) {
      Space v87_6_result;
      for (int v87_6_label = 1; v87_6_label <= 2; ++v87_6_label) {
        const Space v87_6_tail = child(v85_11_tail,v87_6_label);
        if (v87_6_tail.empty()) continue;
        const Path v87_6_head{v87_6_label};
        const Space v88_2 = singleton(v87_6_head);
        const Space v88_3 = intersect(constant_9,v88_2);
        const Space v88_4 = (has_head(v88_3) ? constant_10 : Space{});
        const Space v88_5 = subtract(constant_0,v88_4);
        Space v88_8;
        if (!v88_5.empty()) {
          const Path v89_6 = concat_path(v85_11_head,v87_6_head);
          const Space v89_7 = routine_22(c, v89_6, p0, v87_6_tail);
          v88_8 = compose(v88_5,v89_7);
        }
        const Space v88_9 = intersect(constant_9,v88_2);
        const Space v88_10 = (has_head(v88_9) ? constant_10 : Space{});
        Space v88_12;
        if (!v88_10.empty()) {
          const Path v90_6 = concat_path(v85_11_head,v87_6_head);
          const Space v90_11 = routine_23(c, v90_6, p0, v87_6_tail);
          v88_12 = compose(v88_10,v90_11);
        }
        const Space v88_13 = unite(v88_8,v88_12);
        v87_6_result = unite(v87_6_result,v88_13);
      }
      const Space v87_6 = std::move(v87_6_result);
      v86_7 = compose(v86_5,v87_6);
    }
    const Space v86_8 = intersect(constant_9,v86_2);
    const Space v86_9 = (has_head(v86_8) ? constant_10 : Space{});
    Space v86_11;
    if (!v86_9.empty()) {
      Space v91_10_result;
      for (int v91_10_label = 1; v91_10_label <= 2; ++v91_10_label) {
        const Space v91_10_tail = child(v85_11_tail,v91_10_label);
        if (v91_10_tail.empty()) continue;
        const Path v91_10_head{v91_10_label};
        const Space v92_2 = singleton(v91_10_head);
        const Space v92_3 = intersect(constant_9,v92_2);
        const Space v92_4 = (has_head(v92_3) ? constant_10 : Space{});
        const Space v92_5 = subtract(constant_0,v92_4);
        Space v92_8;
        if (!v92_5.empty()) {
          const Path v93_6 = concat_path(v85_11_head,v91_10_head);
          const Space v93_7 = routine_22(c, v93_6, p0, v91_10_tail);
          v92_8 = compose(v92_5,v93_7);
        }
        const Space v92_9 = intersect(constant_9,v92_2);
        const Space v92_10 = (has_head(v92_9) ? constant_10 : Space{});
        Space v92_12;
        if (!v92_10.empty()) {
          const Path v94_6 = concat_path(v85_11_head,v91_10_head);
          const Space v94_11 = routine_24(c, v94_6, p0, v91_10_tail);
          v92_12 = compose(v92_10,v94_11);
        }
        const Space v92_13 = unite(v92_8,v92_12);
        v91_10_result = unite(v91_10_result,v92_13);
      }
      const Space v91_10 = std::move(v91_10_result);
      v86_11 = compose(v86_9,v91_10);
    }
    const Space v86_12 = unite(v86_7,v86_11);
    v85_11_result = unite(v85_11_result,v86_12);
  }
  const Space v85_11 = std::move(v85_11_result);
  return v85_11;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v95_11_result;
  for (int v95_11_label = 1; v95_11_label <= 2; ++v95_11_label) {
    const Space v95_11_tail = child(s0,v95_11_label);
    if (v95_11_tail.empty()) continue;
    const Path v95_11_head{v95_11_label};
    const Space v96_2 = singleton(v95_11_head);
    const Space v96_3 = intersect(constant_9,v96_2);
    const Space v96_4 = (has_head(v96_3) ? constant_10 : Space{});
    const Space v96_5 = subtract(constant_0,v96_4);
    Space v96_8;
    if (!v96_5.empty()) {
      const Path v97_6 = concat_path(p0,v95_11_head);
      Space v97_7_result;
      for (int v97_7_label = 1; v97_7_label <= 2; ++v97_7_label) {
        const Space v97_7_tail = child(v95_11_tail,v97_7_label);
        if (v97_7_tail.empty()) continue;
        const Path v97_7_head{v97_7_label};
        const Space v98_2 = singleton(v97_7_head);
        const Space v98_3 = intersect(constant_9,v98_2);
        const Space v98_4 = (has_head(v98_3) ? constant_10 : Space{});
        const Space v98_5 = subtract(constant_0,v98_4);
        Space v98_8;
        if (!v98_5.empty()) {
          const Path v99_6 = concat_path(v97_6,v97_7_head);
          const Space v99_7 = routine_25(c, v99_6, v97_7_tail);
          v98_8 = compose(v98_5,v99_7);
        }
        const Space v98_9 = intersect(constant_9,v98_2);
        const Space v98_10 = (has_head(v98_9) ? constant_10 : Space{});
        Space v98_12;
        if (!v98_10.empty()) {
          const Path v100_6 = concat_path(v97_6,v97_7_head);
          const Space v100_11 = routine_26(c, v100_6, v97_7_tail);
          v98_12 = compose(v98_10,v100_11);
        }
        const Space v98_13 = unite(v98_8,v98_12);
        v97_7_result = unite(v97_7_result,v98_13);
      }
      const Space v97_7 = std::move(v97_7_result);
      v96_8 = compose(v96_5,v97_7);
    }
    const Space v96_9 = intersect(constant_9,v96_2);
    const Space v96_10 = (has_head(v96_9) ? constant_10 : Space{});
    Space v96_12;
    if (!v96_10.empty()) {
      const Path v101_6 = concat_path(p0,v95_11_head);
      Space v101_11_result;
      for (int v101_11_label = 1; v101_11_label <= 2; ++v101_11_label) {
        const Space v101_11_tail = child(v95_11_tail,v101_11_label);
        if (v101_11_tail.empty()) continue;
        const Path v101_11_head{v101_11_label};
        const Space v102_2 = singleton(v101_11_head);
        const Space v102_3 = intersect(constant_9,v102_2);
        const Space v102_4 = (has_head(v102_3) ? constant_10 : Space{});
        const Space v102_5 = subtract(constant_0,v102_4);
        Space v102_8;
        if (!v102_5.empty()) {
          const Path v103_6 = concat_path(v101_6,v101_11_head);
          const Space v103_7 = routine_25(c, v103_6, v101_11_tail);
          v102_8 = compose(v102_5,v103_7);
        }
        const Space v102_9 = intersect(constant_9,v102_2);
        const Space v102_10 = (has_head(v102_9) ? constant_10 : Space{});
        Space v102_12;
        if (!v102_10.empty()) {
          const Path v104_6 = concat_path(v101_6,v101_11_head);
          const Space v104_11 = routine_9(c, v104_6, v101_11_tail);
          v102_12 = compose(v102_10,v104_11);
        }
        const Space v102_13 = unite(v102_8,v102_12);
        v101_11_result = unite(v101_11_result,v102_13);
      }
      const Space v101_11 = std::move(v101_11_result);
      v96_12 = compose(v96_10,v101_11);
    }
    const Space v96_13 = unite(v96_8,v96_12);
    v95_11_result = unite(v95_11_result,v96_13);
  }
  const Space v95_11 = std::move(v95_11_result);
  return v95_11;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v105_8_result;
  for (int v105_8_label = 1; v105_8_label <= 2; ++v105_8_label) {
    const Space v105_8_tail = child(s0,v105_8_label);
    if (v105_8_tail.empty()) continue;
    const Path v105_8_head{v105_8_label};
    const Space v106_2 = singleton(v105_8_head);
    const Space v106_3 = intersect(constant_9,v106_2);
    const Space v106_4 = (has_head(v106_3) ? constant_10 : Space{});
    const Space v106_5 = subtract(constant_0,v106_4);
    Space v106_8;
    if (!v106_5.empty()) {
      const Path v107_6 = concat_path(p0,v105_8_head);
      Space v107_7_result;
      for (int v107_7_label = 1; v107_7_label <= 2; ++v107_7_label) {
        const Space v107_7_tail = child(v105_8_tail,v107_7_label);
        if (v107_7_tail.empty()) continue;
        const Path v107_7_head{v107_7_label};
        const Space v108_2 = singleton(v107_7_head);
        const Space v108_3 = intersect(constant_9,v108_2);
        const Space v108_4 = (has_head(v108_3) ? constant_10 : Space{});
        const Space v108_5 = subtract(constant_0,v108_4);
        Space v108_8;
        if (!v108_5.empty()) {
          const Path v109_6 = concat_path(v107_6,v107_7_head);
          const Space v109_7 = routine_25(c, v109_6, v107_7_tail);
          v108_8 = compose(v108_5,v109_7);
        }
        const Space v108_9 = intersect(constant_9,v108_2);
        const Space v108_10 = (has_head(v108_9) ? constant_10 : Space{});
        Space v108_12;
        if (!v108_10.empty()) {
          const Path v110_6 = concat_path(v107_6,v107_7_head);
          const Space v110_11 = routine_26(c, v110_6, v107_7_tail);
          v108_12 = compose(v108_10,v110_11);
        }
        const Space v108_13 = unite(v108_8,v108_12);
        v107_7_result = unite(v107_7_result,v108_13);
      }
      const Space v107_7 = std::move(v107_7_result);
      v106_8 = compose(v106_5,v107_7);
    }
    const Space v106_9 = intersect(constant_9,v106_2);
    const Space v106_10 = (has_head(v106_9) ? constant_10 : Space{});
    const Path v111_6 = concat_path(p0,v105_8_head);
    const Space v106_11 = singleton(v111_6);
    const Space v106_12 = compose(v106_10,v106_11);
    const Space v106_13 = unite(v106_8,v106_12);
    v105_8_result = unite(v105_8_result,v106_13);
  }
  const Space v105_8 = std::move(v105_8_result);
  return v105_8;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  const Space v112_2 = singleton(p0);
  return v112_2;
}

static Space routine_10(Context& c, const Space& s0) {
  const Space v113_1 = (has_head(s0) ? constant_10 : Space{});
  const Space v113_2 = first_matching(s0,constant_0,false);
  const Space v113_3 = unite(v113_1,v113_2);
  Space v113_6;
  if (!v113_3.empty()) {
    const Space v114_4 = routine_27(c, s0);
    const Space v114_5 = subtract(s0,v114_4);
    v113_6 = compose(v113_3,v114_5);
  }
  const Space v113_7 = subtract(s0,v113_6);
  return v113_7;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0) {
  Space v115_11_result;
  for (int v115_11_label = 1; v115_11_label <= 2; ++v115_11_label) {
    const Space v115_11_tail = child(s0,v115_11_label);
    if (v115_11_tail.empty()) continue;
    const Path v115_11_head{v115_11_label};
    const Space v116_2 = singleton(v115_11_head);
    const Space v116_3 = intersect(constant_9,v116_2);
    const Space v116_4 = (has_head(v116_3) ? constant_10 : Space{});
    const Space v116_5 = subtract(constant_0,v116_4);
    Space v116_8;
    if (!v116_5.empty()) {
      const Path v117_6 = concat_path(p0,v115_11_head);
      Space v117_7_result;
      for (int v117_7_label = 1; v117_7_label <= 2; ++v117_7_label) {
        const Space v117_7_tail = child(v115_11_tail,v117_7_label);
        if (v117_7_tail.empty()) continue;
        const Path v117_7_head{v117_7_label};
        const Space v118_2 = singleton(v117_7_head);
        const Space v118_3 = intersect(constant_9,v118_2);
        const Space v118_4 = (has_head(v118_3) ? constant_10 : Space{});
        const Space v118_5 = subtract(constant_0,v118_4);
        Space v118_8;
        if (!v118_5.empty()) {
          const Path v119_6 = concat_path(v117_6,v117_7_head);
          const Space v119_7 = routine_28(c, v119_6, v117_7_tail);
          v118_8 = compose(v118_5,v119_7);
        }
        const Space v118_9 = intersect(constant_9,v118_2);
        const Space v118_10 = (has_head(v118_9) ? constant_10 : Space{});
        Space v118_12;
        if (!v118_10.empty()) {
          const Path v120_6 = concat_path(v117_6,v117_7_head);
          const Space v120_11 = routine_29(c, v120_6, v117_7_tail);
          v118_12 = compose(v118_10,v120_11);
        }
        const Space v118_13 = unite(v118_8,v118_12);
        v117_7_result = unite(v117_7_result,v118_13);
      }
      const Space v117_7 = std::move(v117_7_result);
      v116_8 = compose(v116_5,v117_7);
    }
    const Space v116_9 = intersect(constant_9,v116_2);
    const Space v116_10 = (has_head(v116_9) ? constant_10 : Space{});
    Space v116_12;
    if (!v116_10.empty()) {
      const Path v121_6 = concat_path(p0,v115_11_head);
      Space v121_11_result;
      for (int v121_11_label = 1; v121_11_label <= 2; ++v121_11_label) {
        const Space v121_11_tail = child(v115_11_tail,v121_11_label);
        if (v121_11_tail.empty()) continue;
        const Path v121_11_head{v121_11_label};
        const Space v122_2 = singleton(v121_11_head);
        const Space v122_3 = intersect(constant_9,v122_2);
        const Space v122_4 = (has_head(v122_3) ? constant_10 : Space{});
        const Space v122_5 = subtract(constant_0,v122_4);
        Space v122_8;
        if (!v122_5.empty()) {
          const Path v123_6 = concat_path(v121_6,v121_11_head);
          const Space v123_7 = routine_28(c, v123_6, v121_11_tail);
          v122_8 = compose(v122_5,v123_7);
        }
        const Space v122_9 = intersect(constant_9,v122_2);
        const Space v122_10 = (has_head(v122_9) ? constant_10 : Space{});
        Space v122_12;
        if (!v122_10.empty()) {
          const Path v124_6 = concat_path(v121_6,v121_11_head);
          const Space v124_11 = routine_13(c, v124_6, v121_11_tail);
          v122_12 = compose(v122_10,v124_11);
        }
        const Space v122_13 = unite(v122_8,v122_12);
        v121_11_result = unite(v121_11_result,v122_13);
      }
      const Space v121_11 = std::move(v121_11_result);
      v116_12 = compose(v116_10,v121_11);
    }
    const Space v116_13 = unite(v116_8,v116_12);
    v115_11_result = unite(v115_11_result,v116_13);
  }
  const Space v115_11 = std::move(v115_11_result);
  return v115_11;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  Space v125_11_result;
  for (int v125_11_label = 1; v125_11_label <= 2; ++v125_11_label) {
    const Space v125_11_tail = child(s0,v125_11_label);
    if (v125_11_tail.empty()) continue;
    const Path v125_11_head{v125_11_label};
    const Space v126_2 = singleton(v125_11_head);
    const Space v126_3 = intersect(constant_9,v126_2);
    const Space v126_4 = (has_head(v126_3) ? constant_10 : Space{});
    const Space v126_5 = subtract(constant_0,v126_4);
    Space v126_8;
    if (!v126_5.empty()) {
      const Path v127_6 = concat_path(p0,v125_11_head);
      Space v127_7_result;
      for (int v127_7_label = 1; v127_7_label <= 2; ++v127_7_label) {
        const Space v127_7_tail = child(v125_11_tail,v127_7_label);
        if (v127_7_tail.empty()) continue;
        const Path v127_7_head{v127_7_label};
        const Space v128_2 = singleton(v127_7_head);
        const Space v128_3 = intersect(constant_9,v128_2);
        const Space v128_4 = (has_head(v128_3) ? constant_10 : Space{});
        const Space v128_5 = subtract(constant_0,v128_4);
        Space v128_8;
        if (!v128_5.empty()) {
          const Path v129_6 = concat_path(v127_6,v127_7_head);
          const Space v129_7 = routine_28(c, v129_6, v127_7_tail);
          v128_8 = compose(v128_5,v129_7);
        }
        const Space v128_9 = intersect(constant_9,v128_2);
        const Space v128_10 = (has_head(v128_9) ? constant_10 : Space{});
        Space v128_12;
        if (!v128_10.empty()) {
          const Path v130_6 = concat_path(v127_6,v127_7_head);
          const Space v130_11 = routine_29(c, v130_6, v127_7_tail);
          v128_12 = compose(v128_10,v130_11);
        }
        const Space v128_13 = unite(v128_8,v128_12);
        v127_7_result = unite(v127_7_result,v128_13);
      }
      const Space v127_7 = std::move(v127_7_result);
      v126_8 = compose(v126_5,v127_7);
    }
    const Space v126_9 = intersect(constant_9,v126_2);
    const Space v126_10 = (has_head(v126_9) ? constant_10 : Space{});
    Space v126_12;
    if (!v126_10.empty()) {
      const Path v131_6 = concat_path(p0,v125_11_head);
      Space v131_11_result;
      for (int v131_11_label = 1; v131_11_label <= 2; ++v131_11_label) {
        const Space v131_11_tail = child(v125_11_tail,v131_11_label);
        if (v131_11_tail.empty()) continue;
        const Path v131_11_head{v131_11_label};
        const Space v132_2 = singleton(v131_11_head);
        const Space v132_3 = intersect(constant_9,v132_2);
        const Space v132_4 = (has_head(v132_3) ? constant_10 : Space{});
        const Space v132_5 = subtract(constant_0,v132_4);
        Space v132_7;
        if (!v132_5.empty()) {
          const Space v133_6 = routine_30(c, v131_11_head, v131_6, v131_11_tail);
          v132_7 = compose(v132_5,v133_6);
        }
        const Space v132_8 = intersect(constant_9,v132_2);
        const Space v132_9 = (has_head(v132_8) ? constant_10 : Space{});
        Space v132_11;
        if (!v132_9.empty()) {
          const Space v134_10 = routine_31(c, v131_11_head, v131_6, v131_11_tail);
          v132_11 = compose(v132_9,v134_10);
        }
        const Space v132_12 = unite(v132_7,v132_11);
        v131_11_result = unite(v131_11_result,v132_12);
      }
      const Space v131_11 = std::move(v131_11_result);
      v126_12 = compose(v126_10,v131_11);
    }
    const Space v126_13 = unite(v126_8,v126_12);
    v125_11_result = unite(v125_11_result,v126_13);
  }
  const Space v125_11 = std::move(v125_11_result);
  return v125_11;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v135_11_result;
  for (int v135_11_label = 1; v135_11_label <= 2; ++v135_11_label) {
    const Space v135_11_tail = child(s0,v135_11_label);
    if (v135_11_tail.empty()) continue;
    const Path v135_11_head{v135_11_label};
    const Space v136_2 = singleton(v135_11_head);
    const Space v136_3 = intersect(constant_9,v136_2);
    const Space v136_4 = (has_head(v136_3) ? constant_10 : Space{});
    const Space v136_5 = subtract(constant_0,v136_4);
    Space v136_7;
    if (!v136_5.empty()) {
      Space v137_6_result;
      for (int v137_6_label = 1; v137_6_label <= 2; ++v137_6_label) {
        const Space v137_6_tail = child(v135_11_tail,v137_6_label);
        if (v137_6_tail.empty()) continue;
        const Path v137_6_head{v137_6_label};
        const Space v138_2 = singleton(v137_6_head);
        const Space v138_3 = intersect(constant_9,v138_2);
        const Space v138_4 = (has_head(v138_3) ? constant_10 : Space{});
        const Space v138_5 = subtract(constant_0,v138_4);
        Space v138_8;
        if (!v138_5.empty()) {
          const Path v139_6 = concat_path(v135_11_head,v137_6_head);
          const Space v139_7 = routine_32(c, v139_6, p0, v137_6_tail);
          v138_8 = compose(v138_5,v139_7);
        }
        const Space v138_9 = intersect(constant_9,v138_2);
        const Space v138_10 = (has_head(v138_9) ? constant_10 : Space{});
        Space v138_12;
        if (!v138_10.empty()) {
          const Path v140_6 = concat_path(v135_11_head,v137_6_head);
          const Space v140_11 = routine_33(c, v140_6, p0, v137_6_tail);
          v138_12 = compose(v138_10,v140_11);
        }
        const Space v138_13 = unite(v138_8,v138_12);
        v137_6_result = unite(v137_6_result,v138_13);
      }
      const Space v137_6 = std::move(v137_6_result);
      v136_7 = compose(v136_5,v137_6);
    }
    const Space v136_8 = intersect(constant_9,v136_2);
    const Space v136_9 = (has_head(v136_8) ? constant_10 : Space{});
    Space v136_11;
    if (!v136_9.empty()) {
      Space v141_10_result;
      for (int v141_10_label = 1; v141_10_label <= 2; ++v141_10_label) {
        const Space v141_10_tail = child(v135_11_tail,v141_10_label);
        if (v141_10_tail.empty()) continue;
        const Path v141_10_head{v141_10_label};
        const Space v142_2 = singleton(v141_10_head);
        const Space v142_3 = intersect(constant_9,v142_2);
        const Space v142_4 = (has_head(v142_3) ? constant_10 : Space{});
        const Space v142_5 = subtract(constant_0,v142_4);
        Space v142_8;
        if (!v142_5.empty()) {
          const Path v143_6 = concat_path(v135_11_head,v141_10_head);
          const Space v143_7 = routine_32(c, v143_6, p0, v141_10_tail);
          v142_8 = compose(v142_5,v143_7);
        }
        const Space v142_9 = intersect(constant_9,v142_2);
        const Space v142_10 = (has_head(v142_9) ? constant_10 : Space{});
        Space v142_12;
        if (!v142_10.empty()) {
          const Path v144_6 = concat_path(v135_11_head,v141_10_head);
          const Space v144_11 = routine_34(c, v144_6, p0, v141_10_tail);
          v142_12 = compose(v142_10,v144_11);
        }
        const Space v142_13 = unite(v142_8,v142_12);
        v141_10_result = unite(v141_10_result,v142_13);
      }
      const Space v141_10 = std::move(v141_10_result);
      v136_11 = compose(v136_9,v141_10);
    }
    const Space v136_12 = unite(v136_7,v136_11);
    v135_11_result = unite(v135_11_result,v136_12);
  }
  const Space v135_11 = std::move(v135_11_result);
  return v135_11;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v145_14_result;
  for (int v145_14_label = 1; v145_14_label <= 2; ++v145_14_label) {
    const Space v145_14_tail = child(s0,v145_14_label);
    if (v145_14_tail.empty()) continue;
    const Path v145_14_head{v145_14_label};
    const Space v146_2 = singleton(v145_14_head);
    const Space v146_3 = intersect(constant_9,v146_2);
    const Space v146_4 = (has_head(v146_3) ? constant_10 : Space{});
    const Space v146_5 = subtract(constant_0,v146_4);
    Space v146_8;
    if (!v146_5.empty()) {
      const Path v147_6 = concat_path(p0,v145_14_head);
      Space v147_7_result;
      for (int v147_7_label = 1; v147_7_label <= 2; ++v147_7_label) {
        const Space v147_7_tail = child(v145_14_tail,v147_7_label);
        if (v147_7_tail.empty()) continue;
        const Path v147_7_head{v147_7_label};
        const Space v148_2 = singleton(v147_7_head);
        const Space v148_3 = intersect(constant_9,v148_2);
        const Space v148_4 = (has_head(v148_3) ? constant_10 : Space{});
        const Space v148_5 = subtract(constant_0,v148_4);
        Space v148_8;
        if (!v148_5.empty()) {
          const Path v149_6 = concat_path(v147_6,v147_7_head);
          const Space v149_7 = routine_35(c, v149_6, v147_7_tail, s1, s2, s3);
          v148_8 = compose(v148_5,v149_7);
        }
        const Space v148_9 = intersect(constant_9,v148_2);
        const Space v148_10 = (has_head(v148_9) ? constant_10 : Space{});
        Space v148_12;
        if (!v148_10.empty()) {
          const Path v150_6 = concat_path(v147_6,v147_7_head);
          const Space v150_11 = routine_36(c, v150_6, v147_7_tail, s1, s2, s3);
          v148_12 = compose(v148_10,v150_11);
        }
        const Space v148_13 = unite(v148_8,v148_12);
        v147_7_result = unite(v147_7_result,v148_13);
      }
      const Space v147_7 = std::move(v147_7_result);
      v146_8 = compose(v146_5,v147_7);
    }
    const Space v146_9 = intersect(constant_9,v146_2);
    const Space v146_10 = (has_head(v146_9) ? constant_10 : Space{});
    Space v146_12;
    if (!v146_10.empty()) {
      const Path v151_6 = concat_path(p0,v145_14_head);
      Space v151_11_result;
      for (int v151_11_label = 1; v151_11_label <= 2; ++v151_11_label) {
        const Space v151_11_tail = child(v145_14_tail,v151_11_label);
        if (v151_11_tail.empty()) continue;
        const Path v151_11_head{v151_11_label};
        const Space v152_2 = singleton(v151_11_head);
        const Space v152_3 = intersect(constant_9,v152_2);
        const Space v152_4 = (has_head(v152_3) ? constant_10 : Space{});
        const Space v152_5 = subtract(constant_0,v152_4);
        Space v152_8;
        if (!v152_5.empty()) {
          const Path v153_6 = concat_path(v151_6,v151_11_head);
          const Space v153_7 = routine_35(c, v153_6, v151_11_tail, s1, s2, s3);
          v152_8 = compose(v152_5,v153_7);
        }
        const Space v152_9 = intersect(constant_9,v152_2);
        const Space v152_10 = (has_head(v152_9) ? constant_10 : Space{});
        Space v152_12;
        if (!v152_10.empty()) {
          const Path v154_6 = concat_path(v151_6,v151_11_head);
          const Space v154_11 = routine_37(c, v154_6, v151_11_tail, s1, s2, s3);
          v152_12 = compose(v152_10,v154_11);
        }
        const Space v152_13 = unite(v152_8,v152_12);
        v151_11_result = unite(v151_11_result,v152_13);
      }
      const Space v151_11 = std::move(v151_11_result);
      v146_12 = compose(v146_10,v151_11);
    }
    const Space v146_13 = unite(v146_8,v146_12);
    v145_14_result = unite(v145_14_result,v146_13);
  }
  const Space v145_14 = std::move(v145_14_result);
  return v145_14;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v155_11_result;
  for (int v155_11_label = 1; v155_11_label <= 2; ++v155_11_label) {
    const Space v155_11_tail = child(s0,v155_11_label);
    if (v155_11_tail.empty()) continue;
    const Path v155_11_head{v155_11_label};
    const Space v156_2 = singleton(v155_11_head);
    const Space v156_3 = intersect(constant_9,v156_2);
    const Space v156_4 = (has_head(v156_3) ? constant_10 : Space{});
    const Space v156_5 = subtract(constant_0,v156_4);
    Space v156_8;
    if (!v156_5.empty()) {
      const Path v157_6 = concat_path(p0,v155_11_head);
      Space v157_7_result;
      for (int v157_7_label = 1; v157_7_label <= 2; ++v157_7_label) {
        const Space v157_7_tail = child(v155_11_tail,v157_7_label);
        if (v157_7_tail.empty()) continue;
        const Path v157_7_head{v157_7_label};
        const Space v158_2 = singleton(v157_7_head);
        const Space v158_3 = intersect(constant_9,v158_2);
        const Space v158_4 = (has_head(v158_3) ? constant_10 : Space{});
        const Space v158_5 = subtract(constant_0,v158_4);
        Space v158_8;
        if (!v158_5.empty()) {
          const Path v159_6 = concat_path(v157_6,v157_7_head);
          const Space v159_7 = routine_35(c, v159_6, v157_7_tail, s1, s2, s3);
          v158_8 = compose(v158_5,v159_7);
        }
        const Space v158_9 = intersect(constant_9,v158_2);
        const Space v158_10 = (has_head(v158_9) ? constant_10 : Space{});
        Space v158_12;
        if (!v158_10.empty()) {
          const Path v160_6 = concat_path(v157_6,v157_7_head);
          const Space v160_11 = routine_36(c, v160_6, v157_7_tail, s1, s2, s3);
          v158_12 = compose(v158_10,v160_11);
        }
        const Space v158_13 = unite(v158_8,v158_12);
        v157_7_result = unite(v157_7_result,v158_13);
      }
      const Space v157_7 = std::move(v157_7_result);
      v156_8 = compose(v156_5,v157_7);
    }
    const Space v156_9 = intersect(constant_9,v156_2);
    const Space v156_10 = (has_head(v156_9) ? constant_10 : Space{});
    Space v156_27;
    if (!v156_10.empty()) {
      const Path v161_6 = concat_path(p0,v155_11_head);
      const Space v161_11 = singleton(v161_6);
      const Space v161_12 = routine_38(c, s1, s3, v161_11);
      const Space v161_13 = routine_38(c, s2, s3, v161_11);
      const Space v161_14 = intersect(v161_12,v161_13);
      const Space v161_15 = subtract(v161_14,v161_11);
      const Space v161_16 = wrap(v161_15,v161_6);
      const Space v161_17 = subtract(s3,v161_13);
      const Space v161_18 = subtract(v161_17,v161_12);
      const Space v161_19 = routine_39(c, s2, s1, v161_18);
      const Space v161_20 = unite(v161_16,v161_19);
      const Space v161_21 = subtract(v161_12,v161_13);
      const Space v161_22 = routine_39(c, s2, s1, v161_21);
      const Space v161_23 = unite(v161_20,v161_22);
      const Space v161_24 = subtract(v161_13,v161_12);
      const Space v161_25 = routine_39(c, s2, s1, v161_24);
      const Space v161_26 = unite(v161_23,v161_25);
      v156_27 = compose(v156_10,v161_26);
    }
    const Space v156_28 = unite(v156_8,v156_27);
    v155_11_result = unite(v155_11_result,v156_28);
  }
  const Space v155_11 = std::move(v155_11_result);
  return v155_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v162_2_result;
  for (int v162_2_label = 1; v162_2_label <= 2; ++v162_2_label) {
    const Space v162_2_tail = child(s0,v162_2_label);
    if (v162_2_tail.empty()) continue;
    const Path v162_2_head{v162_2_label};
    const Space v163_2 = Space{};
    v162_2_result = unite(v162_2_result,v163_2);
  }
  const Space v162_2 = std::move(v162_2_result);
  return v162_2;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  Space v164_3_result;
  for (int v164_3_label = 1; v164_3_label <= 2; ++v164_3_label) {
    const Space v164_3_tail = child(s0,v164_3_label);
    if (v164_3_tail.empty()) continue;
    const Path v164_3_head{v164_3_label};
    const Space v165_2 = singleton(v164_3_head);
    const Space v165_3 = intersect(constant_9,v165_2);
    const Space v165_4 = (has_head(v165_3) ? constant_10 : Space{});
    const Path v165_5 = concat_path(p0,v164_3_head);
    const Space v165_6 = singleton(v165_5);
    const Space v165_7 = compose(v165_4,v165_6);
    v164_3_result = unite(v164_3_result,v165_7);
  }
  const Space v164_3 = std::move(v164_3_result);
  return v164_3;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0) {
  Space v166_2_result;
  for (int v166_2_label = 1; v166_2_label <= 2; ++v166_2_label) {
    const Space v166_2_tail = child(s0,v166_2_label);
    if (v166_2_tail.empty()) continue;
    const Path v166_2_head{v166_2_label};
    const Space v167_2 = Space{};
    v166_2_result = unite(v166_2_result,v167_2);
  }
  const Space v166_2 = std::move(v166_2_result);
  return v166_2;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  Space v168_6_result;
  for (int v168_6_label = 1; v168_6_label <= 2; ++v168_6_label) {
    const Space v168_6_tail = child(s0,v168_6_label);
    if (v168_6_tail.empty()) continue;
    const Path v168_6_head{v168_6_label};
    const Space v169_2 = singleton(v168_6_head);
    const Space v169_3 = intersect(constant_9,v169_2);
    const Space v169_4 = (has_head(v169_3) ? constant_10 : Space{});
    Space v169_7;
    if (!v169_4.empty()) {
      const Path v170_5 = concat_path(p0,v168_6_head);
      Space v170_6_result;
      for (int v170_6_label = 1; v170_6_label <= 2; ++v170_6_label) {
        const Space v170_6_tail = child(v168_6_tail,v170_6_label);
        if (v170_6_tail.empty()) continue;
        const Path v170_6_head{v170_6_label};
        const Space v171_2 = singleton(v170_6_head);
        const Space v171_3 = intersect(constant_9,v171_2);
        const Space v171_4 = (has_head(v171_3) ? constant_10 : Space{});
        const Space v171_5 = subtract(constant_0,v171_4);
        Space v171_7;
        if (!v171_5.empty()) {
          const Space v172_6 = routine_20(c, v170_6_head, v170_5, v170_6_tail);
          v171_7 = compose(v171_5,v172_6);
        }
        const Space v171_8 = intersect(constant_9,v171_2);
        const Space v171_9 = (has_head(v171_8) ? constant_10 : Space{});
        Space v171_11;
        if (!v171_9.empty()) {
          const Space v173_10 = routine_21(c, v170_6_head, v170_5, v170_6_tail);
          v171_11 = compose(v171_9,v173_10);
        }
        const Space v171_12 = unite(v171_7,v171_11);
        v170_6_result = unite(v170_6_result,v171_12);
      }
      const Space v170_6 = std::move(v170_6_result);
      v169_7 = compose(v169_4,v170_6);
    }
    v168_6_result = unite(v168_6_result,v169_7);
  }
  const Space v168_6 = std::move(v168_6_result);
  return v168_6;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v174_12_result;
  for (int v174_12_label = 1; v174_12_label <= 2; ++v174_12_label) {
    const Space v174_12_tail = child(s0,v174_12_label);
    if (v174_12_tail.empty()) continue;
    const Path v174_12_head{v174_12_label};
    const Space v175_2 = singleton(v174_12_head);
    const Space v175_3 = intersect(constant_9,v175_2);
    const Space v175_4 = (has_head(v175_3) ? constant_10 : Space{});
    const Space v175_5 = subtract(constant_0,v175_4);
    Space v175_8;
    if (!v175_5.empty()) {
      const Path v176_6 = concat_path(p0,v174_12_head);
      Space v176_7_result;
      for (int v176_7_label = 1; v176_7_label <= 2; ++v176_7_label) {
        const Space v176_7_tail = child(v174_12_tail,v176_7_label);
        if (v176_7_tail.empty()) continue;
        const Path v176_7_head{v176_7_label};
        const Space v177_2 = singleton(v176_7_head);
        const Space v177_3 = intersect(constant_9,v177_2);
        const Space v177_4 = (has_head(v177_3) ? constant_10 : Space{});
        const Space v177_5 = subtract(constant_0,v177_4);
        Space v177_8;
        if (!v177_5.empty()) {
          const Path v178_6 = concat_path(v176_6,v176_7_head);
          const Space v178_7 = routine_40(c, v178_6, p1, v176_7_tail);
          v177_8 = compose(v177_5,v178_7);
        }
        const Space v177_9 = intersect(constant_9,v177_2);
        const Space v177_10 = (has_head(v177_9) ? constant_10 : Space{});
        Space v177_12;
        if (!v177_10.empty()) {
          const Path v179_6 = concat_path(v176_6,v176_7_head);
          const Space v179_11 = routine_41(c, v179_6, p1, v176_7_tail);
          v177_12 = compose(v177_10,v179_11);
        }
        const Space v177_13 = unite(v177_8,v177_12);
        v176_7_result = unite(v176_7_result,v177_13);
      }
      const Space v176_7 = std::move(v176_7_result);
      v175_8 = compose(v175_5,v176_7);
    }
    const Space v175_9 = intersect(constant_9,v175_2);
    const Space v175_10 = (has_head(v175_9) ? constant_10 : Space{});
    Space v175_12;
    if (!v175_10.empty()) {
      const Path v180_6 = concat_path(p0,v174_12_head);
      Space v180_11_result;
      for (int v180_11_label = 1; v180_11_label <= 2; ++v180_11_label) {
        const Space v180_11_tail = child(v174_12_tail,v180_11_label);
        if (v180_11_tail.empty()) continue;
        const Path v180_11_head{v180_11_label};
        const Space v181_2 = singleton(v180_11_head);
        const Space v181_3 = intersect(constant_9,v181_2);
        const Space v181_4 = (has_head(v181_3) ? constant_10 : Space{});
        const Space v181_5 = subtract(constant_0,v181_4);
        Space v181_8;
        if (!v181_5.empty()) {
          const Path v182_6 = concat_path(v180_6,v180_11_head);
          const Space v182_7 = routine_40(c, v182_6, p1, v180_11_tail);
          v181_8 = compose(v181_5,v182_7);
        }
        const Space v181_9 = intersect(constant_9,v181_2);
        const Space v181_10 = (has_head(v181_9) ? constant_10 : Space{});
        Space v181_12;
        if (!v181_10.empty()) {
          const Path v183_6 = concat_path(v180_6,v180_11_head);
          const Space v183_11 = routine_24(c, v183_6, p1, v180_11_tail);
          v181_12 = compose(v181_10,v183_11);
        }
        const Space v181_13 = unite(v181_8,v181_12);
        v180_11_result = unite(v180_11_result,v181_13);
      }
      const Space v180_11 = std::move(v180_11_result);
      v175_12 = compose(v175_10,v180_11);
    }
    const Space v175_13 = unite(v175_8,v175_12);
    v174_12_result = unite(v174_12_result,v175_13);
  }
  const Space v174_12 = std::move(v174_12_result);
  return v174_12;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v184_9_result;
  for (int v184_9_label = 1; v184_9_label <= 2; ++v184_9_label) {
    const Space v184_9_tail = child(s0,v184_9_label);
    if (v184_9_tail.empty()) continue;
    const Path v184_9_head{v184_9_label};
    const Space v185_2 = singleton(v184_9_head);
    const Space v185_3 = intersect(constant_9,v185_2);
    const Space v185_4 = (has_head(v185_3) ? constant_10 : Space{});
    const Space v185_5 = subtract(constant_0,v185_4);
    Space v185_8;
    if (!v185_5.empty()) {
      const Path v186_6 = concat_path(p0,v184_9_head);
      Space v186_7_result;
      for (int v186_7_label = 1; v186_7_label <= 2; ++v186_7_label) {
        const Space v186_7_tail = child(v184_9_tail,v186_7_label);
        if (v186_7_tail.empty()) continue;
        const Path v186_7_head{v186_7_label};
        const Space v187_2 = singleton(v186_7_head);
        const Space v187_3 = intersect(constant_9,v187_2);
        const Space v187_4 = (has_head(v187_3) ? constant_10 : Space{});
        const Space v187_5 = subtract(constant_0,v187_4);
        Space v187_8;
        if (!v187_5.empty()) {
          const Path v188_6 = concat_path(v186_6,v186_7_head);
          const Space v188_7 = routine_40(c, v188_6, p1, v186_7_tail);
          v187_8 = compose(v187_5,v188_7);
        }
        const Space v187_9 = intersect(constant_9,v187_2);
        const Space v187_10 = (has_head(v187_9) ? constant_10 : Space{});
        Space v187_12;
        if (!v187_10.empty()) {
          const Path v189_6 = concat_path(v186_6,v186_7_head);
          const Space v189_11 = routine_41(c, v189_6, p1, v186_7_tail);
          v187_12 = compose(v187_10,v189_11);
        }
        const Space v187_13 = unite(v187_8,v187_12);
        v186_7_result = unite(v186_7_result,v187_13);
      }
      const Space v186_7 = std::move(v186_7_result);
      v185_8 = compose(v185_5,v186_7);
    }
    const Space v185_9 = intersect(constant_9,v185_2);
    const Space v185_10 = (has_head(v185_9) ? constant_10 : Space{});
    const Path v190_6 = concat_path(p0,v184_9_head);
    const Path v185_11 = concat_path(v190_6,p1);
    const Space v185_12 = singleton(v185_11);
    const Space v185_13 = compose(v185_10,v185_12);
    const Space v185_14 = unite(v185_8,v185_13);
    v184_9_result = unite(v184_9_result,v185_14);
  }
  const Space v184_9 = std::move(v184_9_result);
  return v184_9;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v191_12_result;
  for (int v191_12_label = 1; v191_12_label <= 2; ++v191_12_label) {
    const Space v191_12_tail = child(s0,v191_12_label);
    if (v191_12_tail.empty()) continue;
    const Path v191_12_head{v191_12_label};
    const Space v192_2 = singleton(v191_12_head);
    const Space v192_3 = intersect(constant_9,v192_2);
    const Space v192_4 = (has_head(v192_3) ? constant_10 : Space{});
    const Space v192_5 = subtract(constant_0,v192_4);
    Space v192_8;
    if (!v192_5.empty()) {
      const Path v193_6 = concat_path(p0,v191_12_head);
      Space v193_7_result;
      for (int v193_7_label = 1; v193_7_label <= 2; ++v193_7_label) {
        const Space v193_7_tail = child(v191_12_tail,v193_7_label);
        if (v193_7_tail.empty()) continue;
        const Path v193_7_head{v193_7_label};
        const Space v194_2 = singleton(v193_7_head);
        const Space v194_3 = intersect(constant_9,v194_2);
        const Space v194_4 = (has_head(v194_3) ? constant_10 : Space{});
        const Space v194_5 = subtract(constant_0,v194_4);
        Space v194_8;
        if (!v194_5.empty()) {
          const Path v195_6 = concat_path(v193_6,v193_7_head);
          const Space v195_7 = routine_42(c, v195_6, p1, v193_7_tail);
          v194_8 = compose(v194_5,v195_7);
        }
        const Space v194_9 = intersect(constant_9,v194_2);
        const Space v194_10 = (has_head(v194_9) ? constant_10 : Space{});
        Space v194_12;
        if (!v194_10.empty()) {
          const Path v196_6 = concat_path(v193_6,v193_7_head);
          const Space v196_11 = routine_43(c, v196_6, p1, v193_7_tail);
          v194_12 = compose(v194_10,v196_11);
        }
        const Space v194_13 = unite(v194_8,v194_12);
        v193_7_result = unite(v193_7_result,v194_13);
      }
      const Space v193_7 = std::move(v193_7_result);
      v192_8 = compose(v192_5,v193_7);
    }
    const Space v192_9 = intersect(constant_9,v192_2);
    const Space v192_10 = (has_head(v192_9) ? constant_10 : Space{});
    Space v192_12;
    if (!v192_10.empty()) {
      const Path v197_6 = concat_path(p0,v191_12_head);
      Space v197_11_result;
      for (int v197_11_label = 1; v197_11_label <= 2; ++v197_11_label) {
        const Space v197_11_tail = child(v191_12_tail,v197_11_label);
        if (v197_11_tail.empty()) continue;
        const Path v197_11_head{v197_11_label};
        const Space v198_2 = singleton(v197_11_head);
        const Space v198_3 = intersect(constant_9,v198_2);
        const Space v198_4 = (has_head(v198_3) ? constant_10 : Space{});
        const Space v198_5 = subtract(constant_0,v198_4);
        Space v198_8;
        if (!v198_5.empty()) {
          const Path v199_6 = concat_path(v197_6,v197_11_head);
          const Space v199_7 = routine_42(c, v199_6, p1, v197_11_tail);
          v198_8 = compose(v198_5,v199_7);
        }
        const Space v198_9 = intersect(constant_9,v198_2);
        const Space v198_10 = (has_head(v198_9) ? constant_10 : Space{});
        Space v198_12;
        if (!v198_10.empty()) {
          const Path v200_6 = concat_path(v197_6,v197_11_head);
          const Space v200_11 = routine_24(c, v200_6, p1, v197_11_tail);
          v198_12 = compose(v198_10,v200_11);
        }
        const Space v198_13 = unite(v198_8,v198_12);
        v197_11_result = unite(v197_11_result,v198_13);
      }
      const Space v197_11 = std::move(v197_11_result);
      v192_12 = compose(v192_10,v197_11);
    }
    const Space v192_13 = unite(v192_8,v192_12);
    v191_12_result = unite(v191_12_result,v192_13);
  }
  const Space v191_12 = std::move(v191_12_result);
  return v191_12;
}

static Space routine_23(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v201_9_result;
  for (int v201_9_label = 1; v201_9_label <= 2; ++v201_9_label) {
    const Space v201_9_tail = child(s0,v201_9_label);
    if (v201_9_tail.empty()) continue;
    const Path v201_9_head{v201_9_label};
    const Space v202_2 = singleton(v201_9_head);
    const Space v202_3 = intersect(constant_9,v202_2);
    const Space v202_4 = (has_head(v202_3) ? constant_10 : Space{});
    const Space v202_5 = subtract(constant_0,v202_4);
    Space v202_8;
    if (!v202_5.empty()) {
      const Path v203_6 = concat_path(p0,v201_9_head);
      Space v203_7_result;
      for (int v203_7_label = 1; v203_7_label <= 2; ++v203_7_label) {
        const Space v203_7_tail = child(v201_9_tail,v203_7_label);
        if (v203_7_tail.empty()) continue;
        const Path v203_7_head{v203_7_label};
        const Space v204_2 = singleton(v203_7_head);
        const Space v204_3 = intersect(constant_9,v204_2);
        const Space v204_4 = (has_head(v204_3) ? constant_10 : Space{});
        const Space v204_5 = subtract(constant_0,v204_4);
        Space v204_8;
        if (!v204_5.empty()) {
          const Path v205_6 = concat_path(v203_6,v203_7_head);
          const Space v205_7 = routine_42(c, v205_6, p1, v203_7_tail);
          v204_8 = compose(v204_5,v205_7);
        }
        const Space v204_9 = intersect(constant_9,v204_2);
        const Space v204_10 = (has_head(v204_9) ? constant_10 : Space{});
        Space v204_12;
        if (!v204_10.empty()) {
          const Path v206_6 = concat_path(v203_6,v203_7_head);
          const Space v206_11 = routine_43(c, v206_6, p1, v203_7_tail);
          v204_12 = compose(v204_10,v206_11);
        }
        const Space v204_13 = unite(v204_8,v204_12);
        v203_7_result = unite(v203_7_result,v204_13);
      }
      const Space v203_7 = std::move(v203_7_result);
      v202_8 = compose(v202_5,v203_7);
    }
    const Space v202_9 = intersect(constant_9,v202_2);
    const Space v202_10 = (has_head(v202_9) ? constant_10 : Space{});
    const Path v207_6 = concat_path(p0,v201_9_head);
    const Path v202_11 = concat_path(v207_6,p1);
    const Space v202_12 = singleton(v202_11);
    const Space v202_13 = compose(v202_10,v202_12);
    const Space v202_14 = unite(v202_8,v202_13);
    v201_9_result = unite(v201_9_result,v202_14);
  }
  const Space v201_9 = std::move(v201_9_result);
  return v201_9;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Path v208_3 = concat_path(p0,p1);
  const Space v208_4 = singleton(v208_3);
  return v208_4;
}

static Space routine_25(Context& c, const Path& p0, const Space& s0) {
  Space v209_2_result;
  for (int v209_2_label = 1; v209_2_label <= 2; ++v209_2_label) {
    const Space v209_2_tail = child(s0,v209_2_label);
    if (v209_2_tail.empty()) continue;
    const Path v209_2_head{v209_2_label};
    const Space v210_2 = Space{};
    v209_2_result = unite(v209_2_result,v210_2);
  }
  const Space v209_2 = std::move(v209_2_result);
  return v209_2;
}

static Space routine_26(Context& c, const Path& p0, const Space& s0) {
  Space v211_3_result;
  for (int v211_3_label = 1; v211_3_label <= 2; ++v211_3_label) {
    const Space v211_3_tail = child(s0,v211_3_label);
    if (v211_3_tail.empty()) continue;
    const Path v211_3_head{v211_3_label};
    const Space v212_2 = singleton(v211_3_head);
    const Space v212_3 = intersect(constant_9,v212_2);
    const Space v212_4 = (has_head(v212_3) ? constant_10 : Space{});
    const Path v212_5 = concat_path(p0,v211_3_head);
    const Space v212_6 = singleton(v212_5);
    const Space v212_7 = compose(v212_4,v212_6);
    v211_3_result = unite(v211_3_result,v212_7);
  }
  const Space v211_3 = std::move(v211_3_result);
  return v211_3;
}

static Space routine_27(Context& c, const Space& s0) {
  const Space v213_2 = first_matching(s0,constant_0,false);
  const Space v213_3 = intersect(constant_0,v213_2);
  const Space v213_4 = (has_head(v213_2) ? constant_10 : Space{});
  const Space v213_5 = unite(v213_3,v213_4);
  const Space v213_7 = compose(v213_5,constant_0);
  const Space v213_9 = subtract(constant_0,v213_2);
  const Space v213_10 = subtract(v213_9,v213_4);
  Space v213_18;
  if (!v213_10.empty()) {
    const Space v214_11 = first_fibonacci(s0,6,5,true);
    const Space v214_12 = first_matching(v214_11,constant_0,false);
    Space v214_15;
    if (!v214_12.empty()) {
      const Space v215_14 = routine_44(c, constant_12, s0);
      v214_15 = compose(v214_12,v215_14);
    }
    Space v214_16_result;
    for (int v214_16_label = 1; v214_16_label <= 2; ++v214_16_label) {
      const Space v214_16_tail = child(v214_11,v214_16_label);
      if (v214_16_tail.empty()) continue;
      const Path v214_16_head{v214_16_label};
      const Space v216_2 = routine_45(c, v214_16_head, v214_16_tail, s0);
      v214_16_result = unite(v214_16_result,v216_2);
    }
    const Space v214_16 = std::move(v214_16_result);
    const Space v214_17 = unite(v214_15,v214_16);
    v213_18 = compose(v213_10,v214_17);
  }
  const Space v213_19 = unite(v213_7,v213_18);
  return v213_19;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  Space v217_2_result;
  for (int v217_2_label = 1; v217_2_label <= 2; ++v217_2_label) {
    const Space v217_2_tail = child(s0,v217_2_label);
    if (v217_2_tail.empty()) continue;
    const Path v217_2_head{v217_2_label};
    const Space v218_2 = Space{};
    v217_2_result = unite(v217_2_result,v218_2);
  }
  const Space v217_2 = std::move(v217_2_result);
  return v217_2;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0) {
  Space v219_6_result;
  for (int v219_6_label = 1; v219_6_label <= 2; ++v219_6_label) {
    const Space v219_6_tail = child(s0,v219_6_label);
    if (v219_6_tail.empty()) continue;
    const Path v219_6_head{v219_6_label};
    const Space v220_2 = singleton(v219_6_head);
    const Space v220_3 = intersect(constant_9,v220_2);
    const Space v220_4 = (has_head(v220_3) ? constant_10 : Space{});
    Space v220_7;
    if (!v220_4.empty()) {
      const Path v221_5 = concat_path(p0,v219_6_head);
      Space v221_6_result;
      for (int v221_6_label = 1; v221_6_label <= 2; ++v221_6_label) {
        const Space v221_6_tail = child(v219_6_tail,v221_6_label);
        if (v221_6_tail.empty()) continue;
        const Path v221_6_head{v221_6_label};
        const Space v222_2 = singleton(v221_6_head);
        const Space v222_3 = intersect(constant_9,v222_2);
        const Space v222_4 = (has_head(v222_3) ? constant_10 : Space{});
        const Space v222_5 = subtract(constant_0,v222_4);
        Space v222_7;
        if (!v222_5.empty()) {
          const Space v223_6 = routine_30(c, v221_6_head, v221_5, v221_6_tail);
          v222_7 = compose(v222_5,v223_6);
        }
        const Space v222_8 = intersect(constant_9,v222_2);
        const Space v222_9 = (has_head(v222_8) ? constant_10 : Space{});
        Space v222_11;
        if (!v222_9.empty()) {
          const Space v224_10 = routine_31(c, v221_6_head, v221_5, v221_6_tail);
          v222_11 = compose(v222_9,v224_10);
        }
        const Space v222_12 = unite(v222_7,v222_11);
        v221_6_result = unite(v221_6_result,v222_12);
      }
      const Space v221_6 = std::move(v221_6_result);
      v220_7 = compose(v220_4,v221_6);
    }
    v219_6_result = unite(v219_6_result,v220_7);
  }
  const Space v219_6 = std::move(v219_6_result);
  return v219_6;
}

static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v225_12_result;
  for (int v225_12_label = 1; v225_12_label <= 2; ++v225_12_label) {
    const Space v225_12_tail = child(s0,v225_12_label);
    if (v225_12_tail.empty()) continue;
    const Path v225_12_head{v225_12_label};
    const Space v226_2 = singleton(v225_12_head);
    const Space v226_3 = intersect(constant_9,v226_2);
    const Space v226_4 = (has_head(v226_3) ? constant_10 : Space{});
    const Space v226_5 = subtract(constant_0,v226_4);
    Space v226_8;
    if (!v226_5.empty()) {
      const Path v227_6 = concat_path(p0,v225_12_head);
      Space v227_7_result;
      for (int v227_7_label = 1; v227_7_label <= 2; ++v227_7_label) {
        const Space v227_7_tail = child(v225_12_tail,v227_7_label);
        if (v227_7_tail.empty()) continue;
        const Path v227_7_head{v227_7_label};
        const Space v228_2 = singleton(v227_7_head);
        const Space v228_3 = intersect(constant_9,v228_2);
        const Space v228_4 = (has_head(v228_3) ? constant_10 : Space{});
        const Space v228_5 = subtract(constant_0,v228_4);
        Space v228_8;
        if (!v228_5.empty()) {
          const Path v229_6 = concat_path(v227_6,v227_7_head);
          const Space v229_7 = routine_46(c, v229_6, p1, v227_7_tail);
          v228_8 = compose(v228_5,v229_7);
        }
        const Space v228_9 = intersect(constant_9,v228_2);
        const Space v228_10 = (has_head(v228_9) ? constant_10 : Space{});
        Space v228_12;
        if (!v228_10.empty()) {
          const Path v230_6 = concat_path(v227_6,v227_7_head);
          const Space v230_11 = routine_47(c, v230_6, p1, v227_7_tail);
          v228_12 = compose(v228_10,v230_11);
        }
        const Space v228_13 = unite(v228_8,v228_12);
        v227_7_result = unite(v227_7_result,v228_13);
      }
      const Space v227_7 = std::move(v227_7_result);
      v226_8 = compose(v226_5,v227_7);
    }
    const Space v226_9 = intersect(constant_9,v226_2);
    const Space v226_10 = (has_head(v226_9) ? constant_10 : Space{});
    Space v226_12;
    if (!v226_10.empty()) {
      const Path v231_6 = concat_path(p0,v225_12_head);
      Space v231_11_result;
      for (int v231_11_label = 1; v231_11_label <= 2; ++v231_11_label) {
        const Space v231_11_tail = child(v225_12_tail,v231_11_label);
        if (v231_11_tail.empty()) continue;
        const Path v231_11_head{v231_11_label};
        const Space v232_2 = singleton(v231_11_head);
        const Space v232_3 = intersect(constant_9,v232_2);
        const Space v232_4 = (has_head(v232_3) ? constant_10 : Space{});
        const Space v232_5 = subtract(constant_0,v232_4);
        Space v232_8;
        if (!v232_5.empty()) {
          const Path v233_6 = concat_path(v231_6,v231_11_head);
          const Space v233_7 = routine_46(c, v233_6, p1, v231_11_tail);
          v232_8 = compose(v232_5,v233_7);
        }
        const Space v232_9 = intersect(constant_9,v232_2);
        const Space v232_10 = (has_head(v232_9) ? constant_10 : Space{});
        Space v232_12;
        if (!v232_10.empty()) {
          const Path v234_6 = concat_path(v231_6,v231_11_head);
          const Space v234_11 = routine_34(c, v234_6, p1, v231_11_tail);
          v232_12 = compose(v232_10,v234_11);
        }
        const Space v232_13 = unite(v232_8,v232_12);
        v231_11_result = unite(v231_11_result,v232_13);
      }
      const Space v231_11 = std::move(v231_11_result);
      v226_12 = compose(v226_10,v231_11);
    }
    const Space v226_13 = unite(v226_8,v226_12);
    v225_12_result = unite(v225_12_result,v226_13);
  }
  const Space v225_12 = std::move(v225_12_result);
  return v225_12;
}

static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v235_9_result;
  for (int v235_9_label = 1; v235_9_label <= 2; ++v235_9_label) {
    const Space v235_9_tail = child(s0,v235_9_label);
    if (v235_9_tail.empty()) continue;
    const Path v235_9_head{v235_9_label};
    const Space v236_2 = singleton(v235_9_head);
    const Space v236_3 = intersect(constant_9,v236_2);
    const Space v236_4 = (has_head(v236_3) ? constant_10 : Space{});
    const Space v236_5 = subtract(constant_0,v236_4);
    Space v236_8;
    if (!v236_5.empty()) {
      const Path v237_6 = concat_path(p0,v235_9_head);
      Space v237_7_result;
      for (int v237_7_label = 1; v237_7_label <= 2; ++v237_7_label) {
        const Space v237_7_tail = child(v235_9_tail,v237_7_label);
        if (v237_7_tail.empty()) continue;
        const Path v237_7_head{v237_7_label};
        const Space v238_2 = singleton(v237_7_head);
        const Space v238_3 = intersect(constant_9,v238_2);
        const Space v238_4 = (has_head(v238_3) ? constant_10 : Space{});
        const Space v238_5 = subtract(constant_0,v238_4);
        Space v238_8;
        if (!v238_5.empty()) {
          const Path v239_6 = concat_path(v237_6,v237_7_head);
          const Space v239_7 = routine_46(c, v239_6, p1, v237_7_tail);
          v238_8 = compose(v238_5,v239_7);
        }
        const Space v238_9 = intersect(constant_9,v238_2);
        const Space v238_10 = (has_head(v238_9) ? constant_10 : Space{});
        Space v238_12;
        if (!v238_10.empty()) {
          const Path v240_6 = concat_path(v237_6,v237_7_head);
          const Space v240_11 = routine_47(c, v240_6, p1, v237_7_tail);
          v238_12 = compose(v238_10,v240_11);
        }
        const Space v238_13 = unite(v238_8,v238_12);
        v237_7_result = unite(v237_7_result,v238_13);
      }
      const Space v237_7 = std::move(v237_7_result);
      v236_8 = compose(v236_5,v237_7);
    }
    const Space v236_9 = intersect(constant_9,v236_2);
    const Space v236_10 = (has_head(v236_9) ? constant_10 : Space{});
    const Path v241_6 = concat_path(p0,v235_9_head);
    const Path v236_11 = concat_path(v241_6,p1);
    const Space v236_12 = singleton(v236_11);
    const Space v236_13 = compose(v236_10,v236_12);
    const Space v236_14 = unite(v236_8,v236_13);
    v235_9_result = unite(v235_9_result,v236_14);
  }
  const Space v235_9 = std::move(v235_9_result);
  return v235_9;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v242_12_result;
  for (int v242_12_label = 1; v242_12_label <= 2; ++v242_12_label) {
    const Space v242_12_tail = child(s0,v242_12_label);
    if (v242_12_tail.empty()) continue;
    const Path v242_12_head{v242_12_label};
    const Space v243_2 = singleton(v242_12_head);
    const Space v243_3 = intersect(constant_9,v243_2);
    const Space v243_4 = (has_head(v243_3) ? constant_10 : Space{});
    const Space v243_5 = subtract(constant_0,v243_4);
    Space v243_8;
    if (!v243_5.empty()) {
      const Path v244_6 = concat_path(p0,v242_12_head);
      Space v244_7_result;
      for (int v244_7_label = 1; v244_7_label <= 2; ++v244_7_label) {
        const Space v244_7_tail = child(v242_12_tail,v244_7_label);
        if (v244_7_tail.empty()) continue;
        const Path v244_7_head{v244_7_label};
        const Space v245_2 = singleton(v244_7_head);
        const Space v245_3 = intersect(constant_9,v245_2);
        const Space v245_4 = (has_head(v245_3) ? constant_10 : Space{});
        const Space v245_5 = subtract(constant_0,v245_4);
        Space v245_8;
        if (!v245_5.empty()) {
          const Path v246_6 = concat_path(v244_6,v244_7_head);
          const Space v246_7 = routine_48(c, v246_6, p1, v244_7_tail);
          v245_8 = compose(v245_5,v246_7);
        }
        const Space v245_9 = intersect(constant_9,v245_2);
        const Space v245_10 = (has_head(v245_9) ? constant_10 : Space{});
        Space v245_12;
        if (!v245_10.empty()) {
          const Path v247_6 = concat_path(v244_6,v244_7_head);
          const Space v247_11 = routine_49(c, v247_6, p1, v244_7_tail);
          v245_12 = compose(v245_10,v247_11);
        }
        const Space v245_13 = unite(v245_8,v245_12);
        v244_7_result = unite(v244_7_result,v245_13);
      }
      const Space v244_7 = std::move(v244_7_result);
      v243_8 = compose(v243_5,v244_7);
    }
    const Space v243_9 = intersect(constant_9,v243_2);
    const Space v243_10 = (has_head(v243_9) ? constant_10 : Space{});
    Space v243_12;
    if (!v243_10.empty()) {
      const Path v248_6 = concat_path(p0,v242_12_head);
      Space v248_11_result;
      for (int v248_11_label = 1; v248_11_label <= 2; ++v248_11_label) {
        const Space v248_11_tail = child(v242_12_tail,v248_11_label);
        if (v248_11_tail.empty()) continue;
        const Path v248_11_head{v248_11_label};
        const Space v249_2 = singleton(v248_11_head);
        const Space v249_3 = intersect(constant_9,v249_2);
        const Space v249_4 = (has_head(v249_3) ? constant_10 : Space{});
        const Space v249_5 = subtract(constant_0,v249_4);
        Space v249_8;
        if (!v249_5.empty()) {
          const Path v250_6 = concat_path(v248_6,v248_11_head);
          const Space v250_7 = routine_48(c, v250_6, p1, v248_11_tail);
          v249_8 = compose(v249_5,v250_7);
        }
        const Space v249_9 = intersect(constant_9,v249_2);
        const Space v249_10 = (has_head(v249_9) ? constant_10 : Space{});
        Space v249_12;
        if (!v249_10.empty()) {
          const Path v251_6 = concat_path(v248_6,v248_11_head);
          const Space v251_11 = routine_34(c, v251_6, p1, v248_11_tail);
          v249_12 = compose(v249_10,v251_11);
        }
        const Space v249_13 = unite(v249_8,v249_12);
        v248_11_result = unite(v248_11_result,v249_13);
      }
      const Space v248_11 = std::move(v248_11_result);
      v243_12 = compose(v243_10,v248_11);
    }
    const Space v243_13 = unite(v243_8,v243_12);
    v242_12_result = unite(v242_12_result,v243_13);
  }
  const Space v242_12 = std::move(v242_12_result);
  return v242_12;
}

static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v252_9_result;
  for (int v252_9_label = 1; v252_9_label <= 2; ++v252_9_label) {
    const Space v252_9_tail = child(s0,v252_9_label);
    if (v252_9_tail.empty()) continue;
    const Path v252_9_head{v252_9_label};
    const Space v253_2 = singleton(v252_9_head);
    const Space v253_3 = intersect(constant_9,v253_2);
    const Space v253_4 = (has_head(v253_3) ? constant_10 : Space{});
    const Space v253_5 = subtract(constant_0,v253_4);
    Space v253_8;
    if (!v253_5.empty()) {
      const Path v254_6 = concat_path(p0,v252_9_head);
      Space v254_7_result;
      for (int v254_7_label = 1; v254_7_label <= 2; ++v254_7_label) {
        const Space v254_7_tail = child(v252_9_tail,v254_7_label);
        if (v254_7_tail.empty()) continue;
        const Path v254_7_head{v254_7_label};
        const Space v255_2 = singleton(v254_7_head);
        const Space v255_3 = intersect(constant_9,v255_2);
        const Space v255_4 = (has_head(v255_3) ? constant_10 : Space{});
        const Space v255_5 = subtract(constant_0,v255_4);
        Space v255_8;
        if (!v255_5.empty()) {
          const Path v256_6 = concat_path(v254_6,v254_7_head);
          const Space v256_7 = routine_48(c, v256_6, p1, v254_7_tail);
          v255_8 = compose(v255_5,v256_7);
        }
        const Space v255_9 = intersect(constant_9,v255_2);
        const Space v255_10 = (has_head(v255_9) ? constant_10 : Space{});
        Space v255_12;
        if (!v255_10.empty()) {
          const Path v257_6 = concat_path(v254_6,v254_7_head);
          const Space v257_11 = routine_49(c, v257_6, p1, v254_7_tail);
          v255_12 = compose(v255_10,v257_11);
        }
        const Space v255_13 = unite(v255_8,v255_12);
        v254_7_result = unite(v254_7_result,v255_13);
      }
      const Space v254_7 = std::move(v254_7_result);
      v253_8 = compose(v253_5,v254_7);
    }
    const Space v253_9 = intersect(constant_9,v253_2);
    const Space v253_10 = (has_head(v253_9) ? constant_10 : Space{});
    const Path v258_6 = concat_path(p0,v252_9_head);
    const Path v253_11 = concat_path(v258_6,p1);
    const Space v253_12 = singleton(v253_11);
    const Space v253_13 = compose(v253_10,v253_12);
    const Space v253_14 = unite(v253_8,v253_13);
    v252_9_result = unite(v252_9_result,v253_14);
  }
  const Space v252_9 = std::move(v252_9_result);
  return v252_9;
}

static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Path v259_3 = concat_path(p0,p1);
  const Space v259_4 = singleton(v259_3);
  return v259_4;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v260_9_result;
  for (int v260_9_label = 1; v260_9_label <= 2; ++v260_9_label) {
    const Space v260_9_tail = child(s0,v260_9_label);
    if (v260_9_tail.empty()) continue;
    const Path v260_9_head{v260_9_label};
    const Space v261_2 = singleton(v260_9_head);
    const Space v261_3 = intersect(constant_9,v261_2);
    const Space v261_4 = (has_head(v261_3) ? constant_10 : Space{});
    const Space v261_5 = subtract(constant_0,v261_4);
    Space v261_6_result;
    for (int v261_6_label = 1; v261_6_label <= 2; ++v261_6_label) {
      const Space v261_6_tail = child(v260_9_tail,v261_6_label);
      if (v261_6_tail.empty()) continue;
      const Path v261_6_head{v261_6_label};
      const Space v262_2 = Space{};
      v261_6_result = unite(v261_6_result,v262_2);
    }
    const Space v261_6 = std::move(v261_6_result);
    const Space v261_7 = compose(v261_5,v261_6);
    const Space v261_8 = intersect(constant_9,v261_2);
    const Space v261_9 = (has_head(v261_8) ? constant_10 : Space{});
    Space v261_12;
    if (!v261_9.empty()) {
      const Path v263_10 = concat_path(p0,v260_9_head);
      Space v263_11_result;
      for (int v263_11_label = 1; v263_11_label <= 2; ++v263_11_label) {
        const Space v263_11_tail = child(v260_9_tail,v263_11_label);
        if (v263_11_tail.empty()) continue;
        const Path v263_11_head{v263_11_label};
        const Space v264_2 = singleton(v263_11_head);
        const Space v264_3 = intersect(constant_9,v264_2);
        const Space v264_4 = (has_head(v264_3) ? constant_10 : Space{});
        Space v264_7;
        if (!v264_4.empty()) {
          const Path v265_5 = concat_path(v263_10,v263_11_head);
          const Space v265_6 = routine_37(c, v265_5, v263_11_tail, s1, s2, s3);
          v264_7 = compose(v264_4,v265_6);
        }
        v263_11_result = unite(v263_11_result,v264_7);
      }
      const Space v263_11 = std::move(v263_11_result);
      v261_12 = compose(v261_9,v263_11);
    }
    const Space v261_13 = unite(v261_7,v261_12);
    v260_9_result = unite(v260_9_result,v261_13);
  }
  const Space v260_9 = std::move(v260_9_result);
  return v260_9;
}

static Space routine_36(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v266_8_result;
  for (int v266_8_label = 1; v266_8_label <= 2; ++v266_8_label) {
    const Space v266_8_tail = child(s0,v266_8_label);
    if (v266_8_tail.empty()) continue;
    const Path v266_8_head{v266_8_label};
    const Space v267_2 = singleton(v266_8_head);
    const Space v267_3 = intersect(constant_9,v267_2);
    const Space v267_4 = (has_head(v267_3) ? constant_10 : Space{});
    const Space v267_5 = subtract(constant_0,v267_4);
    Space v267_6_result;
    for (int v267_6_label = 1; v267_6_label <= 2; ++v267_6_label) {
      const Space v267_6_tail = child(v266_8_tail,v267_6_label);
      if (v267_6_tail.empty()) continue;
      const Path v267_6_head{v267_6_label};
      const Space v268_2 = Space{};
      v267_6_result = unite(v267_6_result,v268_2);
    }
    const Space v267_6 = std::move(v267_6_result);
    const Space v267_7 = compose(v267_5,v267_6);
    const Space v267_8 = intersect(constant_9,v267_2);
    const Space v267_9 = (has_head(v267_8) ? constant_10 : Space{});
    Space v267_27;
    if (!v267_9.empty()) {
      const Path v269_10 = concat_path(p0,v266_8_head);
      const Space v269_11 = singleton(v269_10);
      const Space v269_12 = routine_38(c, s1, s3, v269_11);
      const Space v269_13 = routine_38(c, s2, s3, v269_11);
      const Space v269_14 = intersect(v269_12,v269_13);
      const Space v269_15 = subtract(v269_14,v269_11);
      const Space v269_16 = wrap(v269_15,v269_10);
      const Space v269_17 = subtract(s3,v269_13);
      const Space v269_18 = subtract(v269_17,v269_12);
      const Space v269_19 = routine_39(c, s2, s1, v269_18);
      const Space v269_20 = unite(v269_16,v269_19);
      const Space v269_21 = subtract(v269_12,v269_13);
      const Space v269_22 = routine_39(c, s2, s1, v269_21);
      const Space v269_23 = unite(v269_20,v269_22);
      const Space v269_24 = subtract(v269_13,v269_12);
      const Space v269_25 = routine_39(c, s2, s1, v269_24);
      const Space v269_26 = unite(v269_23,v269_25);
      v267_27 = compose(v267_9,v269_26);
    }
    const Space v267_28 = unite(v267_7,v267_27);
    v266_8_result = unite(v266_8_result,v267_28);
  }
  const Space v266_8 = std::move(v266_8_result);
  return v266_8;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  const Space v270_5 = singleton(p0);
  Space v270_15 = v270_5;
  for (;;) {
    const Space v271_1 = intersect(v270_15,s3);
    const Space v271_2 = restrict_to(s1,v271_1);
    Space v271_3_result;
    for (int v271_3_label = 1; v271_3_label <= 2; ++v271_3_label) {
      const Space v271_3_tail = child(v271_2,v271_3_label);
      if (v271_3_tail.empty()) continue;
      const Path v271_3_head{v271_3_label};
      const Space v272_2 = singleton(v271_3_head);
      const Space v272_3 = intersect(constant_9,v272_2);
      const Space v272_4 = (has_head(v272_3) ? constant_10 : Space{});
      const Space v272_5 = subtract(constant_0,v272_4);
      Space v272_7;
      if (!v272_5.empty()) {
        Space v273_6_result;
        for (int v273_6_label = 1; v273_6_label <= 2; ++v273_6_label) {
          const Space v273_6_tail = child(v271_3_tail,v273_6_label);
          if (v273_6_tail.empty()) continue;
          const Path v273_6_head{v273_6_label};
          const Space v274_2 = singleton(v273_6_head);
          const Space v274_3 = intersect(constant_9,v274_2);
          const Space v274_4 = (has_head(v274_3) ? constant_10 : Space{});
          const Space v274_5 = subtract(constant_0,v274_4);
          Space v274_8;
          if (!v274_5.empty()) {
            const Path v275_6 = concat_path(v271_3_head,v273_6_head);
            const Space v275_7 = routine_50(c, v275_6, v273_6_tail);
            v274_8 = compose(v274_5,v275_7);
          }
          const Space v274_9 = intersect(constant_9,v274_2);
          const Space v274_10 = (has_head(v274_9) ? constant_10 : Space{});
          Space v274_12;
          if (!v274_10.empty()) {
            const Path v276_6 = concat_path(v271_3_head,v273_6_head);
            const Space v276_11 = routine_51(c, v276_6, v273_6_tail);
            v274_12 = compose(v274_10,v276_11);
          }
          const Space v274_13 = unite(v274_8,v274_12);
          v273_6_result = unite(v273_6_result,v274_13);
        }
        const Space v273_6 = std::move(v273_6_result);
        v272_7 = compose(v272_5,v273_6);
      }
      const Space v272_8 = intersect(constant_9,v272_2);
      const Space v272_9 = (has_head(v272_8) ? constant_10 : Space{});
      Space v272_11;
      if (!v272_9.empty()) {
        Space v277_10_result;
        for (int v277_10_label = 1; v277_10_label <= 2; ++v277_10_label) {
          const Space v277_10_tail = child(v271_3_tail,v277_10_label);
          if (v277_10_tail.empty()) continue;
          const Path v277_10_head{v277_10_label};
          const Space v278_2 = singleton(v277_10_head);
          const Space v278_3 = intersect(constant_9,v278_2);
          const Space v278_4 = (has_head(v278_3) ? constant_10 : Space{});
          const Space v278_5 = subtract(constant_0,v278_4);
          Space v278_8;
          if (!v278_5.empty()) {
            const Path v279_6 = concat_path(v271_3_head,v277_10_head);
            const Space v279_7 = routine_50(c, v279_6, v277_10_tail);
            v278_8 = compose(v278_5,v279_7);
          }
          const Space v278_9 = intersect(constant_9,v278_2);
          const Space v278_10 = (has_head(v278_9) ? constant_10 : Space{});
          Space v278_12;
          if (!v278_10.empty()) {
            const Path v280_6 = concat_path(v271_3_head,v277_10_head);
            const Space v280_11 = routine_52(c, v280_6, v277_10_tail);
            v278_12 = compose(v278_10,v280_11);
          }
          const Space v278_13 = unite(v278_8,v278_12);
          v277_10_result = unite(v277_10_result,v278_13);
        }
        const Space v277_10 = std::move(v277_10_result);
        v272_11 = compose(v272_9,v277_10);
      }
      const Space v272_12 = unite(v272_7,v272_11);
      v271_3_result = unite(v271_3_result,v272_12);
    }
    const Space v271_3 = std::move(v271_3_result);
    const Space v271_4 = unite(v271_3,v270_15);
    const Space v271_5 = intersect(v271_4,s3);
    Space v270_15_next = unite(v270_15,v271_5);
    if (equal(v270_15_next,v270_15)) break;
    v270_15 = std::move(v270_15_next);
  }
  Space v270_25 = v270_5;
  for (;;) {
    const Space v281_1 = intersect(v270_25,s3);
    const Space v281_2 = restrict_to(s2,v281_1);
    Space v281_3_result;
    for (int v281_3_label = 1; v281_3_label <= 2; ++v281_3_label) {
      const Space v281_3_tail = child(v281_2,v281_3_label);
      if (v281_3_tail.empty()) continue;
      const Path v281_3_head{v281_3_label};
      const Space v282_2 = singleton(v281_3_head);
      const Space v282_3 = intersect(constant_9,v282_2);
      const Space v282_4 = (has_head(v282_3) ? constant_10 : Space{});
      const Space v282_5 = subtract(constant_0,v282_4);
      Space v282_7;
      if (!v282_5.empty()) {
        Space v283_6_result;
        for (int v283_6_label = 1; v283_6_label <= 2; ++v283_6_label) {
          const Space v283_6_tail = child(v281_3_tail,v283_6_label);
          if (v283_6_tail.empty()) continue;
          const Path v283_6_head{v283_6_label};
          const Space v284_2 = singleton(v283_6_head);
          const Space v284_3 = intersect(constant_9,v284_2);
          const Space v284_4 = (has_head(v284_3) ? constant_10 : Space{});
          const Space v284_5 = subtract(constant_0,v284_4);
          Space v284_8;
          if (!v284_5.empty()) {
            const Path v285_6 = concat_path(v281_3_head,v283_6_head);
            const Space v285_7 = routine_50(c, v285_6, v283_6_tail);
            v284_8 = compose(v284_5,v285_7);
          }
          const Space v284_9 = intersect(constant_9,v284_2);
          const Space v284_10 = (has_head(v284_9) ? constant_10 : Space{});
          Space v284_12;
          if (!v284_10.empty()) {
            const Path v286_6 = concat_path(v281_3_head,v283_6_head);
            const Space v286_11 = routine_51(c, v286_6, v283_6_tail);
            v284_12 = compose(v284_10,v286_11);
          }
          const Space v284_13 = unite(v284_8,v284_12);
          v283_6_result = unite(v283_6_result,v284_13);
        }
        const Space v283_6 = std::move(v283_6_result);
        v282_7 = compose(v282_5,v283_6);
      }
      const Space v282_8 = intersect(constant_9,v282_2);
      const Space v282_9 = (has_head(v282_8) ? constant_10 : Space{});
      Space v282_11;
      if (!v282_9.empty()) {
        Space v287_10_result;
        for (int v287_10_label = 1; v287_10_label <= 2; ++v287_10_label) {
          const Space v287_10_tail = child(v281_3_tail,v287_10_label);
          if (v287_10_tail.empty()) continue;
          const Path v287_10_head{v287_10_label};
          const Space v288_2 = singleton(v287_10_head);
          const Space v288_3 = intersect(constant_9,v288_2);
          const Space v288_4 = (has_head(v288_3) ? constant_10 : Space{});
          const Space v288_5 = subtract(constant_0,v288_4);
          Space v288_8;
          if (!v288_5.empty()) {
            const Path v289_6 = concat_path(v281_3_head,v287_10_head);
            const Space v289_7 = routine_50(c, v289_6, v287_10_tail);
            v288_8 = compose(v288_5,v289_7);
          }
          const Space v288_9 = intersect(constant_9,v288_2);
          const Space v288_10 = (has_head(v288_9) ? constant_10 : Space{});
          Space v288_12;
          if (!v288_10.empty()) {
            const Path v290_6 = concat_path(v281_3_head,v287_10_head);
            const Space v290_11 = routine_52(c, v290_6, v287_10_tail);
            v288_12 = compose(v288_10,v290_11);
          }
          const Space v288_13 = unite(v288_8,v288_12);
          v287_10_result = unite(v287_10_result,v288_13);
        }
        const Space v287_10 = std::move(v287_10_result);
        v282_11 = compose(v282_9,v287_10);
      }
      const Space v282_12 = unite(v282_7,v282_11);
      v281_3_result = unite(v281_3_result,v282_12);
    }
    const Space v281_3 = std::move(v281_3_result);
    const Space v281_4 = unite(v281_3,v270_25);
    const Space v281_5 = intersect(v281_4,s3);
    Space v270_25_next = unite(v270_25,v281_5);
    if (equal(v270_25_next,v270_25)) break;
    v270_25 = std::move(v270_25_next);
  }
  const Space v270_26 = intersect(v270_15,v270_25);
  const Space v270_27 = subtract(v270_26,v270_5);
  const Space v270_28 = wrap(v270_27,p0);
  Space v270_38 = v270_5;
  for (;;) {
    const Space v291_1 = intersect(v270_38,s3);
    const Space v291_2 = restrict_to(s2,v291_1);
    Space v291_3_result;
    for (int v291_3_label = 1; v291_3_label <= 2; ++v291_3_label) {
      const Space v291_3_tail = child(v291_2,v291_3_label);
      if (v291_3_tail.empty()) continue;
      const Path v291_3_head{v291_3_label};
      const Space v292_2 = singleton(v291_3_head);
      const Space v292_3 = intersect(constant_9,v292_2);
      const Space v292_4 = (has_head(v292_3) ? constant_10 : Space{});
      const Space v292_5 = subtract(constant_0,v292_4);
      Space v292_7;
      if (!v292_5.empty()) {
        Space v293_6_result;
        for (int v293_6_label = 1; v293_6_label <= 2; ++v293_6_label) {
          const Space v293_6_tail = child(v291_3_tail,v293_6_label);
          if (v293_6_tail.empty()) continue;
          const Path v293_6_head{v293_6_label};
          const Space v294_2 = singleton(v293_6_head);
          const Space v294_3 = intersect(constant_9,v294_2);
          const Space v294_4 = (has_head(v294_3) ? constant_10 : Space{});
          const Space v294_5 = subtract(constant_0,v294_4);
          Space v294_8;
          if (!v294_5.empty()) {
            const Path v295_6 = concat_path(v291_3_head,v293_6_head);
            const Space v295_7 = routine_50(c, v295_6, v293_6_tail);
            v294_8 = compose(v294_5,v295_7);
          }
          const Space v294_9 = intersect(constant_9,v294_2);
          const Space v294_10 = (has_head(v294_9) ? constant_10 : Space{});
          Space v294_12;
          if (!v294_10.empty()) {
            const Path v296_6 = concat_path(v291_3_head,v293_6_head);
            const Space v296_11 = routine_51(c, v296_6, v293_6_tail);
            v294_12 = compose(v294_10,v296_11);
          }
          const Space v294_13 = unite(v294_8,v294_12);
          v293_6_result = unite(v293_6_result,v294_13);
        }
        const Space v293_6 = std::move(v293_6_result);
        v292_7 = compose(v292_5,v293_6);
      }
      const Space v292_8 = intersect(constant_9,v292_2);
      const Space v292_9 = (has_head(v292_8) ? constant_10 : Space{});
      Space v292_11;
      if (!v292_9.empty()) {
        Space v297_10_result;
        for (int v297_10_label = 1; v297_10_label <= 2; ++v297_10_label) {
          const Space v297_10_tail = child(v291_3_tail,v297_10_label);
          if (v297_10_tail.empty()) continue;
          const Path v297_10_head{v297_10_label};
          const Space v298_2 = singleton(v297_10_head);
          const Space v298_3 = intersect(constant_9,v298_2);
          const Space v298_4 = (has_head(v298_3) ? constant_10 : Space{});
          const Space v298_5 = subtract(constant_0,v298_4);
          Space v298_8;
          if (!v298_5.empty()) {
            const Path v299_6 = concat_path(v291_3_head,v297_10_head);
            const Space v299_7 = routine_50(c, v299_6, v297_10_tail);
            v298_8 = compose(v298_5,v299_7);
          }
          const Space v298_9 = intersect(constant_9,v298_2);
          const Space v298_10 = (has_head(v298_9) ? constant_10 : Space{});
          Space v298_12;
          if (!v298_10.empty()) {
            const Path v300_6 = concat_path(v291_3_head,v297_10_head);
            const Space v300_11 = routine_52(c, v300_6, v297_10_tail);
            v298_12 = compose(v298_10,v300_11);
          }
          const Space v298_13 = unite(v298_8,v298_12);
          v297_10_result = unite(v297_10_result,v298_13);
        }
        const Space v297_10 = std::move(v297_10_result);
        v292_11 = compose(v292_9,v297_10);
      }
      const Space v292_12 = unite(v292_7,v292_11);
      v291_3_result = unite(v291_3_result,v292_12);
    }
    const Space v291_3 = std::move(v291_3_result);
    const Space v291_4 = unite(v291_3,v270_38);
    const Space v291_5 = intersect(v291_4,s3);
    Space v270_38_next = unite(v270_38,v291_5);
    if (equal(v270_38_next,v270_38)) break;
    v270_38 = std::move(v270_38_next);
  }
  const Space v270_39 = subtract(s3,v270_38);
  Space v270_49 = v270_5;
  for (;;) {
    const Space v301_1 = intersect(v270_49,s3);
    const Space v301_2 = restrict_to(s1,v301_1);
    Space v301_3_result;
    for (int v301_3_label = 1; v301_3_label <= 2; ++v301_3_label) {
      const Space v301_3_tail = child(v301_2,v301_3_label);
      if (v301_3_tail.empty()) continue;
      const Path v301_3_head{v301_3_label};
      const Space v302_2 = singleton(v301_3_head);
      const Space v302_3 = intersect(constant_9,v302_2);
      const Space v302_4 = (has_head(v302_3) ? constant_10 : Space{});
      const Space v302_5 = subtract(constant_0,v302_4);
      Space v302_7;
      if (!v302_5.empty()) {
        Space v303_6_result;
        for (int v303_6_label = 1; v303_6_label <= 2; ++v303_6_label) {
          const Space v303_6_tail = child(v301_3_tail,v303_6_label);
          if (v303_6_tail.empty()) continue;
          const Path v303_6_head{v303_6_label};
          const Space v304_2 = singleton(v303_6_head);
          const Space v304_3 = intersect(constant_9,v304_2);
          const Space v304_4 = (has_head(v304_3) ? constant_10 : Space{});
          const Space v304_5 = subtract(constant_0,v304_4);
          Space v304_8;
          if (!v304_5.empty()) {
            const Path v305_6 = concat_path(v301_3_head,v303_6_head);
            const Space v305_7 = routine_50(c, v305_6, v303_6_tail);
            v304_8 = compose(v304_5,v305_7);
          }
          const Space v304_9 = intersect(constant_9,v304_2);
          const Space v304_10 = (has_head(v304_9) ? constant_10 : Space{});
          Space v304_12;
          if (!v304_10.empty()) {
            const Path v306_6 = concat_path(v301_3_head,v303_6_head);
            const Space v306_11 = routine_51(c, v306_6, v303_6_tail);
            v304_12 = compose(v304_10,v306_11);
          }
          const Space v304_13 = unite(v304_8,v304_12);
          v303_6_result = unite(v303_6_result,v304_13);
        }
        const Space v303_6 = std::move(v303_6_result);
        v302_7 = compose(v302_5,v303_6);
      }
      const Space v302_8 = intersect(constant_9,v302_2);
      const Space v302_9 = (has_head(v302_8) ? constant_10 : Space{});
      Space v302_11;
      if (!v302_9.empty()) {
        Space v307_10_result;
        for (int v307_10_label = 1; v307_10_label <= 2; ++v307_10_label) {
          const Space v307_10_tail = child(v301_3_tail,v307_10_label);
          if (v307_10_tail.empty()) continue;
          const Path v307_10_head{v307_10_label};
          const Space v308_2 = singleton(v307_10_head);
          const Space v308_3 = intersect(constant_9,v308_2);
          const Space v308_4 = (has_head(v308_3) ? constant_10 : Space{});
          const Space v308_5 = subtract(constant_0,v308_4);
          Space v308_8;
          if (!v308_5.empty()) {
            const Path v309_6 = concat_path(v301_3_head,v307_10_head);
            const Space v309_7 = routine_50(c, v309_6, v307_10_tail);
            v308_8 = compose(v308_5,v309_7);
          }
          const Space v308_9 = intersect(constant_9,v308_2);
          const Space v308_10 = (has_head(v308_9) ? constant_10 : Space{});
          Space v308_12;
          if (!v308_10.empty()) {
            const Path v310_6 = concat_path(v301_3_head,v307_10_head);
            const Space v310_11 = routine_52(c, v310_6, v307_10_tail);
            v308_12 = compose(v308_10,v310_11);
          }
          const Space v308_13 = unite(v308_8,v308_12);
          v307_10_result = unite(v307_10_result,v308_13);
        }
        const Space v307_10 = std::move(v307_10_result);
        v302_11 = compose(v302_9,v307_10);
      }
      const Space v302_12 = unite(v302_7,v302_11);
      v301_3_result = unite(v301_3_result,v302_12);
    }
    const Space v301_3 = std::move(v301_3_result);
    const Space v301_4 = unite(v301_3,v270_49);
    const Space v301_5 = intersect(v301_4,s3);
    Space v270_49_next = unite(v270_49,v301_5);
    if (equal(v270_49_next,v270_49)) break;
    v270_49 = std::move(v270_49_next);
  }
  const Space v270_50 = subtract(v270_39,v270_49);
  const Space v270_51 = routine_10(c, v270_50);
  Space v270_91_result;
  for (int v270_91_label = 1; v270_91_label <= 2; ++v270_91_label) {
    const Space v270_91_tail = child(v270_51,v270_91_label);
    if (v270_91_tail.empty()) continue;
    const Path v270_91_head{v270_91_label};
    const Space v311_2 = singleton(v270_91_head);
    const Space v311_3 = intersect(constant_9,v311_2);
    const Space v311_4 = (has_head(v311_3) ? constant_10 : Space{});
    const Space v311_5 = subtract(constant_0,v311_4);
    Space v311_11;
    if (!v311_5.empty()) {
      Space v312_6 = v270_5;
      for (;;) {
        const Space v313_1 = intersect(v312_6,s3);
        const Space v313_2 = restrict_to(s2,v313_1);
        Space v313_3_result;
        for (int v313_3_label = 1; v313_3_label <= 2; ++v313_3_label) {
          const Space v313_3_tail = child(v313_2,v313_3_label);
          if (v313_3_tail.empty()) continue;
          const Path v313_3_head{v313_3_label};
          const Space v314_2 = singleton(v313_3_head);
          const Space v314_3 = intersect(constant_9,v314_2);
          const Space v314_4 = (has_head(v314_3) ? constant_10 : Space{});
          const Space v314_5 = subtract(constant_0,v314_4);
          Space v314_7;
          if (!v314_5.empty()) {
            Space v315_6_result;
            for (int v315_6_label = 1; v315_6_label <= 2; ++v315_6_label) {
              const Space v315_6_tail = child(v313_3_tail,v315_6_label);
              if (v315_6_tail.empty()) continue;
              const Path v315_6_head{v315_6_label};
              const Space v316_2 = singleton(v315_6_head);
              const Space v316_3 = intersect(constant_9,v316_2);
              const Space v316_4 = (has_head(v316_3) ? constant_10 : Space{});
              const Space v316_5 = subtract(constant_0,v316_4);
              Space v316_8;
              if (!v316_5.empty()) {
                const Path v317_6 = concat_path(v313_3_head,v315_6_head);
                const Space v317_7 = routine_50(c, v317_6, v315_6_tail);
                v316_8 = compose(v316_5,v317_7);
              }
              const Space v316_9 = intersect(constant_9,v316_2);
              const Space v316_10 = (has_head(v316_9) ? constant_10 : Space{});
              Space v316_12;
              if (!v316_10.empty()) {
                const Path v318_6 = concat_path(v313_3_head,v315_6_head);
                const Space v318_11 = routine_51(c, v318_6, v315_6_tail);
                v316_12 = compose(v316_10,v318_11);
              }
              const Space v316_13 = unite(v316_8,v316_12);
              v315_6_result = unite(v315_6_result,v316_13);
            }
            const Space v315_6 = std::move(v315_6_result);
            v314_7 = compose(v314_5,v315_6);
          }
          const Space v314_8 = intersect(constant_9,v314_2);
          const Space v314_9 = (has_head(v314_8) ? constant_10 : Space{});
          Space v314_11;
          if (!v314_9.empty()) {
            Space v319_10_result;
            for (int v319_10_label = 1; v319_10_label <= 2; ++v319_10_label) {
              const Space v319_10_tail = child(v313_3_tail,v319_10_label);
              if (v319_10_tail.empty()) continue;
              const Path v319_10_head{v319_10_label};
              const Space v320_2 = singleton(v319_10_head);
              const Space v320_3 = intersect(constant_9,v320_2);
              const Space v320_4 = (has_head(v320_3) ? constant_10 : Space{});
              const Space v320_5 = subtract(constant_0,v320_4);
              Space v320_8;
              if (!v320_5.empty()) {
                const Path v321_6 = concat_path(v313_3_head,v319_10_head);
                const Space v321_7 = routine_50(c, v321_6, v319_10_tail);
                v320_8 = compose(v320_5,v321_7);
              }
              const Space v320_9 = intersect(constant_9,v320_2);
              const Space v320_10 = (has_head(v320_9) ? constant_10 : Space{});
              Space v320_12;
              if (!v320_10.empty()) {
                const Path v322_6 = concat_path(v313_3_head,v319_10_head);
                const Space v322_11 = routine_52(c, v322_6, v319_10_tail);
                v320_12 = compose(v320_10,v322_11);
              }
              const Space v320_13 = unite(v320_8,v320_12);
              v319_10_result = unite(v319_10_result,v320_13);
            }
            const Space v319_10 = std::move(v319_10_result);
            v314_11 = compose(v314_9,v319_10);
          }
          const Space v314_12 = unite(v314_7,v314_11);
          v313_3_result = unite(v313_3_result,v314_12);
        }
        const Space v313_3 = std::move(v313_3_result);
        const Space v313_4 = unite(v313_3,v312_6);
        const Space v313_5 = intersect(v313_4,s3);
        Space v312_6_next = unite(v312_6,v313_5);
        if (equal(v312_6_next,v312_6)) break;
        v312_6 = std::move(v312_6_next);
      }
      const Space v312_7 = subtract(s3,v312_6);
      Space v312_8 = v270_5;
      for (;;) {
        const Space v323_1 = intersect(v312_8,s3);
        const Space v323_2 = restrict_to(s1,v323_1);
        Space v323_3_result;
        for (int v323_3_label = 1; v323_3_label <= 2; ++v323_3_label) {
          const Space v323_3_tail = child(v323_2,v323_3_label);
          if (v323_3_tail.empty()) continue;
          const Path v323_3_head{v323_3_label};
          const Space v324_2 = singleton(v323_3_head);
          const Space v324_3 = intersect(constant_9,v324_2);
          const Space v324_4 = (has_head(v324_3) ? constant_10 : Space{});
          const Space v324_5 = subtract(constant_0,v324_4);
          Space v324_7;
          if (!v324_5.empty()) {
            Space v325_6_result;
            for (int v325_6_label = 1; v325_6_label <= 2; ++v325_6_label) {
              const Space v325_6_tail = child(v323_3_tail,v325_6_label);
              if (v325_6_tail.empty()) continue;
              const Path v325_6_head{v325_6_label};
              const Space v326_2 = singleton(v325_6_head);
              const Space v326_3 = intersect(constant_9,v326_2);
              const Space v326_4 = (has_head(v326_3) ? constant_10 : Space{});
              const Space v326_5 = subtract(constant_0,v326_4);
              Space v326_8;
              if (!v326_5.empty()) {
                const Path v327_6 = concat_path(v323_3_head,v325_6_head);
                const Space v327_7 = routine_50(c, v327_6, v325_6_tail);
                v326_8 = compose(v326_5,v327_7);
              }
              const Space v326_9 = intersect(constant_9,v326_2);
              const Space v326_10 = (has_head(v326_9) ? constant_10 : Space{});
              Space v326_12;
              if (!v326_10.empty()) {
                const Path v328_6 = concat_path(v323_3_head,v325_6_head);
                const Space v328_11 = routine_51(c, v328_6, v325_6_tail);
                v326_12 = compose(v326_10,v328_11);
              }
              const Space v326_13 = unite(v326_8,v326_12);
              v325_6_result = unite(v325_6_result,v326_13);
            }
            const Space v325_6 = std::move(v325_6_result);
            v324_7 = compose(v324_5,v325_6);
          }
          const Space v324_8 = intersect(constant_9,v324_2);
          const Space v324_9 = (has_head(v324_8) ? constant_10 : Space{});
          Space v324_11;
          if (!v324_9.empty()) {
            Space v329_10_result;
            for (int v329_10_label = 1; v329_10_label <= 2; ++v329_10_label) {
              const Space v329_10_tail = child(v323_3_tail,v329_10_label);
              if (v329_10_tail.empty()) continue;
              const Path v329_10_head{v329_10_label};
              const Space v330_2 = singleton(v329_10_head);
              const Space v330_3 = intersect(constant_9,v330_2);
              const Space v330_4 = (has_head(v330_3) ? constant_10 : Space{});
              const Space v330_5 = subtract(constant_0,v330_4);
              Space v330_8;
              if (!v330_5.empty()) {
                const Path v331_6 = concat_path(v323_3_head,v329_10_head);
                const Space v331_7 = routine_50(c, v331_6, v329_10_tail);
                v330_8 = compose(v330_5,v331_7);
              }
              const Space v330_9 = intersect(constant_9,v330_2);
              const Space v330_10 = (has_head(v330_9) ? constant_10 : Space{});
              Space v330_12;
              if (!v330_10.empty()) {
                const Path v332_6 = concat_path(v323_3_head,v329_10_head);
                const Space v332_11 = routine_52(c, v332_6, v329_10_tail);
                v330_12 = compose(v330_10,v332_11);
              }
              const Space v330_13 = unite(v330_8,v330_12);
              v329_10_result = unite(v329_10_result,v330_13);
            }
            const Space v329_10 = std::move(v329_10_result);
            v324_11 = compose(v324_9,v329_10);
          }
          const Space v324_12 = unite(v324_7,v324_11);
          v323_3_result = unite(v323_3_result,v324_12);
        }
        const Space v323_3 = std::move(v323_3_result);
        const Space v323_4 = unite(v323_3,v312_8);
        const Space v323_5 = intersect(v323_4,s3);
        Space v312_8_next = unite(v312_8,v323_5);
        if (equal(v312_8_next,v312_8)) break;
        v312_8 = std::move(v312_8_next);
      }
      const Space v312_9 = subtract(v312_7,v312_8);
      const Space v312_10 = routine_14(c, v270_91_head, v270_91_tail, s1, s2, v312_9);
      v311_11 = compose(v311_5,v312_10);
    }
    const Space v311_12 = intersect(constant_9,v311_2);
    const Space v311_13 = (has_head(v311_12) ? constant_10 : Space{});
    Space v311_19;
    if (!v311_13.empty()) {
      Space v333_14 = v270_5;
      for (;;) {
        const Space v334_1 = intersect(v333_14,s3);
        const Space v334_2 = restrict_to(s2,v334_1);
        Space v334_3_result;
        for (int v334_3_label = 1; v334_3_label <= 2; ++v334_3_label) {
          const Space v334_3_tail = child(v334_2,v334_3_label);
          if (v334_3_tail.empty()) continue;
          const Path v334_3_head{v334_3_label};
          const Space v335_2 = singleton(v334_3_head);
          const Space v335_3 = intersect(constant_9,v335_2);
          const Space v335_4 = (has_head(v335_3) ? constant_10 : Space{});
          const Space v335_5 = subtract(constant_0,v335_4);
          Space v335_7;
          if (!v335_5.empty()) {
            Space v336_6_result;
            for (int v336_6_label = 1; v336_6_label <= 2; ++v336_6_label) {
              const Space v336_6_tail = child(v334_3_tail,v336_6_label);
              if (v336_6_tail.empty()) continue;
              const Path v336_6_head{v336_6_label};
              const Space v337_2 = singleton(v336_6_head);
              const Space v337_3 = intersect(constant_9,v337_2);
              const Space v337_4 = (has_head(v337_3) ? constant_10 : Space{});
              const Space v337_5 = subtract(constant_0,v337_4);
              Space v337_8;
              if (!v337_5.empty()) {
                const Path v338_6 = concat_path(v334_3_head,v336_6_head);
                const Space v338_7 = routine_50(c, v338_6, v336_6_tail);
                v337_8 = compose(v337_5,v338_7);
              }
              const Space v337_9 = intersect(constant_9,v337_2);
              const Space v337_10 = (has_head(v337_9) ? constant_10 : Space{});
              Space v337_12;
              if (!v337_10.empty()) {
                const Path v339_6 = concat_path(v334_3_head,v336_6_head);
                const Space v339_11 = routine_51(c, v339_6, v336_6_tail);
                v337_12 = compose(v337_10,v339_11);
              }
              const Space v337_13 = unite(v337_8,v337_12);
              v336_6_result = unite(v336_6_result,v337_13);
            }
            const Space v336_6 = std::move(v336_6_result);
            v335_7 = compose(v335_5,v336_6);
          }
          const Space v335_8 = intersect(constant_9,v335_2);
          const Space v335_9 = (has_head(v335_8) ? constant_10 : Space{});
          Space v335_11;
          if (!v335_9.empty()) {
            Space v340_10_result;
            for (int v340_10_label = 1; v340_10_label <= 2; ++v340_10_label) {
              const Space v340_10_tail = child(v334_3_tail,v340_10_label);
              if (v340_10_tail.empty()) continue;
              const Path v340_10_head{v340_10_label};
              const Space v341_2 = singleton(v340_10_head);
              const Space v341_3 = intersect(constant_9,v341_2);
              const Space v341_4 = (has_head(v341_3) ? constant_10 : Space{});
              const Space v341_5 = subtract(constant_0,v341_4);
              Space v341_8;
              if (!v341_5.empty()) {
                const Path v342_6 = concat_path(v334_3_head,v340_10_head);
                const Space v342_7 = routine_50(c, v342_6, v340_10_tail);
                v341_8 = compose(v341_5,v342_7);
              }
              const Space v341_9 = intersect(constant_9,v341_2);
              const Space v341_10 = (has_head(v341_9) ? constant_10 : Space{});
              Space v341_12;
              if (!v341_10.empty()) {
                const Path v343_6 = concat_path(v334_3_head,v340_10_head);
                const Space v343_11 = routine_52(c, v343_6, v340_10_tail);
                v341_12 = compose(v341_10,v343_11);
              }
              const Space v341_13 = unite(v341_8,v341_12);
              v340_10_result = unite(v340_10_result,v341_13);
            }
            const Space v340_10 = std::move(v340_10_result);
            v335_11 = compose(v335_9,v340_10);
          }
          const Space v335_12 = unite(v335_7,v335_11);
          v334_3_result = unite(v334_3_result,v335_12);
        }
        const Space v334_3 = std::move(v334_3_result);
        const Space v334_4 = unite(v334_3,v333_14);
        const Space v334_5 = intersect(v334_4,s3);
        Space v333_14_next = unite(v333_14,v334_5);
        if (equal(v333_14_next,v333_14)) break;
        v333_14 = std::move(v333_14_next);
      }
      const Space v333_15 = subtract(s3,v333_14);
      Space v333_16 = v270_5;
      for (;;) {
        const Space v344_1 = intersect(v333_16,s3);
        const Space v344_2 = restrict_to(s1,v344_1);
        Space v344_3_result;
        for (int v344_3_label = 1; v344_3_label <= 2; ++v344_3_label) {
          const Space v344_3_tail = child(v344_2,v344_3_label);
          if (v344_3_tail.empty()) continue;
          const Path v344_3_head{v344_3_label};
          const Space v345_2 = singleton(v344_3_head);
          const Space v345_3 = intersect(constant_9,v345_2);
          const Space v345_4 = (has_head(v345_3) ? constant_10 : Space{});
          const Space v345_5 = subtract(constant_0,v345_4);
          Space v345_7;
          if (!v345_5.empty()) {
            Space v346_6_result;
            for (int v346_6_label = 1; v346_6_label <= 2; ++v346_6_label) {
              const Space v346_6_tail = child(v344_3_tail,v346_6_label);
              if (v346_6_tail.empty()) continue;
              const Path v346_6_head{v346_6_label};
              const Space v347_2 = singleton(v346_6_head);
              const Space v347_3 = intersect(constant_9,v347_2);
              const Space v347_4 = (has_head(v347_3) ? constant_10 : Space{});
              const Space v347_5 = subtract(constant_0,v347_4);
              Space v347_8;
              if (!v347_5.empty()) {
                const Path v348_6 = concat_path(v344_3_head,v346_6_head);
                const Space v348_7 = routine_50(c, v348_6, v346_6_tail);
                v347_8 = compose(v347_5,v348_7);
              }
              const Space v347_9 = intersect(constant_9,v347_2);
              const Space v347_10 = (has_head(v347_9) ? constant_10 : Space{});
              Space v347_12;
              if (!v347_10.empty()) {
                const Path v349_6 = concat_path(v344_3_head,v346_6_head);
                const Space v349_11 = routine_51(c, v349_6, v346_6_tail);
                v347_12 = compose(v347_10,v349_11);
              }
              const Space v347_13 = unite(v347_8,v347_12);
              v346_6_result = unite(v346_6_result,v347_13);
            }
            const Space v346_6 = std::move(v346_6_result);
            v345_7 = compose(v345_5,v346_6);
          }
          const Space v345_8 = intersect(constant_9,v345_2);
          const Space v345_9 = (has_head(v345_8) ? constant_10 : Space{});
          Space v345_11;
          if (!v345_9.empty()) {
            Space v350_10_result;
            for (int v350_10_label = 1; v350_10_label <= 2; ++v350_10_label) {
              const Space v350_10_tail = child(v344_3_tail,v350_10_label);
              if (v350_10_tail.empty()) continue;
              const Path v350_10_head{v350_10_label};
              const Space v351_2 = singleton(v350_10_head);
              const Space v351_3 = intersect(constant_9,v351_2);
              const Space v351_4 = (has_head(v351_3) ? constant_10 : Space{});
              const Space v351_5 = subtract(constant_0,v351_4);
              Space v351_8;
              if (!v351_5.empty()) {
                const Path v352_6 = concat_path(v344_3_head,v350_10_head);
                const Space v352_7 = routine_50(c, v352_6, v350_10_tail);
                v351_8 = compose(v351_5,v352_7);
              }
              const Space v351_9 = intersect(constant_9,v351_2);
              const Space v351_10 = (has_head(v351_9) ? constant_10 : Space{});
              Space v351_12;
              if (!v351_10.empty()) {
                const Path v353_6 = concat_path(v344_3_head,v350_10_head);
                const Space v353_11 = routine_52(c, v353_6, v350_10_tail);
                v351_12 = compose(v351_10,v353_11);
              }
              const Space v351_13 = unite(v351_8,v351_12);
              v350_10_result = unite(v350_10_result,v351_13);
            }
            const Space v350_10 = std::move(v350_10_result);
            v345_11 = compose(v345_9,v350_10);
          }
          const Space v345_12 = unite(v345_7,v345_11);
          v344_3_result = unite(v344_3_result,v345_12);
        }
        const Space v344_3 = std::move(v344_3_result);
        const Space v344_4 = unite(v344_3,v333_16);
        const Space v344_5 = intersect(v344_4,s3);
        Space v333_16_next = unite(v333_16,v344_5);
        if (equal(v333_16_next,v333_16)) break;
        v333_16 = std::move(v333_16_next);
      }
      const Space v333_17 = subtract(v333_15,v333_16);
      const Space v333_18 = routine_15(c, v270_91_head, v270_91_tail, s1, s2, v333_17);
      v311_19 = compose(v311_13,v333_18);
    }
    const Space v311_20 = unite(v311_11,v311_19);
    v270_91_result = unite(v270_91_result,v311_20);
  }
  const Space v270_91 = std::move(v270_91_result);
  const Space v270_92 = unite(v270_28,v270_91);
  Space v270_102 = v270_5;
  for (;;) {
    const Space v354_1 = intersect(v270_102,s3);
    const Space v354_2 = restrict_to(s2,v354_1);
    Space v354_3_result;
    for (int v354_3_label = 1; v354_3_label <= 2; ++v354_3_label) {
      const Space v354_3_tail = child(v354_2,v354_3_label);
      if (v354_3_tail.empty()) continue;
      const Path v354_3_head{v354_3_label};
      const Space v355_2 = singleton(v354_3_head);
      const Space v355_3 = intersect(constant_9,v355_2);
      const Space v355_4 = (has_head(v355_3) ? constant_10 : Space{});
      const Space v355_5 = subtract(constant_0,v355_4);
      Space v355_7;
      if (!v355_5.empty()) {
        Space v356_6_result;
        for (int v356_6_label = 1; v356_6_label <= 2; ++v356_6_label) {
          const Space v356_6_tail = child(v354_3_tail,v356_6_label);
          if (v356_6_tail.empty()) continue;
          const Path v356_6_head{v356_6_label};
          const Space v357_2 = singleton(v356_6_head);
          const Space v357_3 = intersect(constant_9,v357_2);
          const Space v357_4 = (has_head(v357_3) ? constant_10 : Space{});
          const Space v357_5 = subtract(constant_0,v357_4);
          Space v357_8;
          if (!v357_5.empty()) {
            const Path v358_6 = concat_path(v354_3_head,v356_6_head);
            const Space v358_7 = routine_50(c, v358_6, v356_6_tail);
            v357_8 = compose(v357_5,v358_7);
          }
          const Space v357_9 = intersect(constant_9,v357_2);
          const Space v357_10 = (has_head(v357_9) ? constant_10 : Space{});
          Space v357_12;
          if (!v357_10.empty()) {
            const Path v359_6 = concat_path(v354_3_head,v356_6_head);
            const Space v359_11 = routine_51(c, v359_6, v356_6_tail);
            v357_12 = compose(v357_10,v359_11);
          }
          const Space v357_13 = unite(v357_8,v357_12);
          v356_6_result = unite(v356_6_result,v357_13);
        }
        const Space v356_6 = std::move(v356_6_result);
        v355_7 = compose(v355_5,v356_6);
      }
      const Space v355_8 = intersect(constant_9,v355_2);
      const Space v355_9 = (has_head(v355_8) ? constant_10 : Space{});
      Space v355_11;
      if (!v355_9.empty()) {
        Space v360_10_result;
        for (int v360_10_label = 1; v360_10_label <= 2; ++v360_10_label) {
          const Space v360_10_tail = child(v354_3_tail,v360_10_label);
          if (v360_10_tail.empty()) continue;
          const Path v360_10_head{v360_10_label};
          const Space v361_2 = singleton(v360_10_head);
          const Space v361_3 = intersect(constant_9,v361_2);
          const Space v361_4 = (has_head(v361_3) ? constant_10 : Space{});
          const Space v361_5 = subtract(constant_0,v361_4);
          Space v361_8;
          if (!v361_5.empty()) {
            const Path v362_6 = concat_path(v354_3_head,v360_10_head);
            const Space v362_7 = routine_50(c, v362_6, v360_10_tail);
            v361_8 = compose(v361_5,v362_7);
          }
          const Space v361_9 = intersect(constant_9,v361_2);
          const Space v361_10 = (has_head(v361_9) ? constant_10 : Space{});
          Space v361_12;
          if (!v361_10.empty()) {
            const Path v363_6 = concat_path(v354_3_head,v360_10_head);
            const Space v363_11 = routine_52(c, v363_6, v360_10_tail);
            v361_12 = compose(v361_10,v363_11);
          }
          const Space v361_13 = unite(v361_8,v361_12);
          v360_10_result = unite(v360_10_result,v361_13);
        }
        const Space v360_10 = std::move(v360_10_result);
        v355_11 = compose(v355_9,v360_10);
      }
      const Space v355_12 = unite(v355_7,v355_11);
      v354_3_result = unite(v354_3_result,v355_12);
    }
    const Space v354_3 = std::move(v354_3_result);
    const Space v354_4 = unite(v354_3,v270_102);
    const Space v354_5 = intersect(v354_4,s3);
    Space v270_102_next = unite(v270_102,v354_5);
    if (equal(v270_102_next,v270_102)) break;
    v270_102 = std::move(v270_102_next);
  }
  Space v270_112 = v270_5;
  for (;;) {
    const Space v364_1 = intersect(v270_112,s3);
    const Space v364_2 = restrict_to(s1,v364_1);
    Space v364_3_result;
    for (int v364_3_label = 1; v364_3_label <= 2; ++v364_3_label) {
      const Space v364_3_tail = child(v364_2,v364_3_label);
      if (v364_3_tail.empty()) continue;
      const Path v364_3_head{v364_3_label};
      const Space v365_2 = singleton(v364_3_head);
      const Space v365_3 = intersect(constant_9,v365_2);
      const Space v365_4 = (has_head(v365_3) ? constant_10 : Space{});
      const Space v365_5 = subtract(constant_0,v365_4);
      Space v365_7;
      if (!v365_5.empty()) {
        Space v366_6_result;
        for (int v366_6_label = 1; v366_6_label <= 2; ++v366_6_label) {
          const Space v366_6_tail = child(v364_3_tail,v366_6_label);
          if (v366_6_tail.empty()) continue;
          const Path v366_6_head{v366_6_label};
          const Space v367_2 = singleton(v366_6_head);
          const Space v367_3 = intersect(constant_9,v367_2);
          const Space v367_4 = (has_head(v367_3) ? constant_10 : Space{});
          const Space v367_5 = subtract(constant_0,v367_4);
          Space v367_8;
          if (!v367_5.empty()) {
            const Path v368_6 = concat_path(v364_3_head,v366_6_head);
            const Space v368_7 = routine_50(c, v368_6, v366_6_tail);
            v367_8 = compose(v367_5,v368_7);
          }
          const Space v367_9 = intersect(constant_9,v367_2);
          const Space v367_10 = (has_head(v367_9) ? constant_10 : Space{});
          Space v367_12;
          if (!v367_10.empty()) {
            const Path v369_6 = concat_path(v364_3_head,v366_6_head);
            const Space v369_11 = routine_51(c, v369_6, v366_6_tail);
            v367_12 = compose(v367_10,v369_11);
          }
          const Space v367_13 = unite(v367_8,v367_12);
          v366_6_result = unite(v366_6_result,v367_13);
        }
        const Space v366_6 = std::move(v366_6_result);
        v365_7 = compose(v365_5,v366_6);
      }
      const Space v365_8 = intersect(constant_9,v365_2);
      const Space v365_9 = (has_head(v365_8) ? constant_10 : Space{});
      Space v365_11;
      if (!v365_9.empty()) {
        Space v370_10_result;
        for (int v370_10_label = 1; v370_10_label <= 2; ++v370_10_label) {
          const Space v370_10_tail = child(v364_3_tail,v370_10_label);
          if (v370_10_tail.empty()) continue;
          const Path v370_10_head{v370_10_label};
          const Space v371_2 = singleton(v370_10_head);
          const Space v371_3 = intersect(constant_9,v371_2);
          const Space v371_4 = (has_head(v371_3) ? constant_10 : Space{});
          const Space v371_5 = subtract(constant_0,v371_4);
          Space v371_8;
          if (!v371_5.empty()) {
            const Path v372_6 = concat_path(v364_3_head,v370_10_head);
            const Space v372_7 = routine_50(c, v372_6, v370_10_tail);
            v371_8 = compose(v371_5,v372_7);
          }
          const Space v371_9 = intersect(constant_9,v371_2);
          const Space v371_10 = (has_head(v371_9) ? constant_10 : Space{});
          Space v371_12;
          if (!v371_10.empty()) {
            const Path v373_6 = concat_path(v364_3_head,v370_10_head);
            const Space v373_11 = routine_52(c, v373_6, v370_10_tail);
            v371_12 = compose(v371_10,v373_11);
          }
          const Space v371_13 = unite(v371_8,v371_12);
          v370_10_result = unite(v370_10_result,v371_13);
        }
        const Space v370_10 = std::move(v370_10_result);
        v365_11 = compose(v365_9,v370_10);
      }
      const Space v365_12 = unite(v365_7,v365_11);
      v364_3_result = unite(v364_3_result,v365_12);
    }
    const Space v364_3 = std::move(v364_3_result);
    const Space v364_4 = unite(v364_3,v270_112);
    const Space v364_5 = intersect(v364_4,s3);
    Space v270_112_next = unite(v270_112,v364_5);
    if (equal(v270_112_next,v270_112)) break;
    v270_112 = std::move(v270_112_next);
  }
  const Space v270_113 = subtract(v270_102,v270_112);
  const Space v270_114 = routine_10(c, v270_113);
  Space v270_154_result;
  for (int v270_154_label = 1; v270_154_label <= 2; ++v270_154_label) {
    const Space v270_154_tail = child(v270_114,v270_154_label);
    if (v270_154_tail.empty()) continue;
    const Path v270_154_head{v270_154_label};
    const Space v374_2 = singleton(v270_154_head);
    const Space v374_3 = intersect(constant_9,v374_2);
    const Space v374_4 = (has_head(v374_3) ? constant_10 : Space{});
    const Space v374_5 = subtract(constant_0,v374_4);
    Space v374_10;
    if (!v374_5.empty()) {
      Space v375_6 = v270_5;
      for (;;) {
        const Space v376_1 = intersect(v375_6,s3);
        const Space v376_2 = restrict_to(s2,v376_1);
        Space v376_3_result;
        for (int v376_3_label = 1; v376_3_label <= 2; ++v376_3_label) {
          const Space v376_3_tail = child(v376_2,v376_3_label);
          if (v376_3_tail.empty()) continue;
          const Path v376_3_head{v376_3_label};
          const Space v377_2 = singleton(v376_3_head);
          const Space v377_3 = intersect(constant_9,v377_2);
          const Space v377_4 = (has_head(v377_3) ? constant_10 : Space{});
          const Space v377_5 = subtract(constant_0,v377_4);
          Space v377_7;
          if (!v377_5.empty()) {
            Space v378_6_result;
            for (int v378_6_label = 1; v378_6_label <= 2; ++v378_6_label) {
              const Space v378_6_tail = child(v376_3_tail,v378_6_label);
              if (v378_6_tail.empty()) continue;
              const Path v378_6_head{v378_6_label};
              const Space v379_2 = singleton(v378_6_head);
              const Space v379_3 = intersect(constant_9,v379_2);
              const Space v379_4 = (has_head(v379_3) ? constant_10 : Space{});
              const Space v379_5 = subtract(constant_0,v379_4);
              Space v379_8;
              if (!v379_5.empty()) {
                const Path v380_6 = concat_path(v376_3_head,v378_6_head);
                const Space v380_7 = routine_50(c, v380_6, v378_6_tail);
                v379_8 = compose(v379_5,v380_7);
              }
              const Space v379_9 = intersect(constant_9,v379_2);
              const Space v379_10 = (has_head(v379_9) ? constant_10 : Space{});
              Space v379_12;
              if (!v379_10.empty()) {
                const Path v381_6 = concat_path(v376_3_head,v378_6_head);
                const Space v381_11 = routine_51(c, v381_6, v378_6_tail);
                v379_12 = compose(v379_10,v381_11);
              }
              const Space v379_13 = unite(v379_8,v379_12);
              v378_6_result = unite(v378_6_result,v379_13);
            }
            const Space v378_6 = std::move(v378_6_result);
            v377_7 = compose(v377_5,v378_6);
          }
          const Space v377_8 = intersect(constant_9,v377_2);
          const Space v377_9 = (has_head(v377_8) ? constant_10 : Space{});
          Space v377_11;
          if (!v377_9.empty()) {
            Space v382_10_result;
            for (int v382_10_label = 1; v382_10_label <= 2; ++v382_10_label) {
              const Space v382_10_tail = child(v376_3_tail,v382_10_label);
              if (v382_10_tail.empty()) continue;
              const Path v382_10_head{v382_10_label};
              const Space v383_2 = singleton(v382_10_head);
              const Space v383_3 = intersect(constant_9,v383_2);
              const Space v383_4 = (has_head(v383_3) ? constant_10 : Space{});
              const Space v383_5 = subtract(constant_0,v383_4);
              Space v383_8;
              if (!v383_5.empty()) {
                const Path v384_6 = concat_path(v376_3_head,v382_10_head);
                const Space v384_7 = routine_50(c, v384_6, v382_10_tail);
                v383_8 = compose(v383_5,v384_7);
              }
              const Space v383_9 = intersect(constant_9,v383_2);
              const Space v383_10 = (has_head(v383_9) ? constant_10 : Space{});
              Space v383_12;
              if (!v383_10.empty()) {
                const Path v385_6 = concat_path(v376_3_head,v382_10_head);
                const Space v385_11 = routine_52(c, v385_6, v382_10_tail);
                v383_12 = compose(v383_10,v385_11);
              }
              const Space v383_13 = unite(v383_8,v383_12);
              v382_10_result = unite(v382_10_result,v383_13);
            }
            const Space v382_10 = std::move(v382_10_result);
            v377_11 = compose(v377_9,v382_10);
          }
          const Space v377_12 = unite(v377_7,v377_11);
          v376_3_result = unite(v376_3_result,v377_12);
        }
        const Space v376_3 = std::move(v376_3_result);
        const Space v376_4 = unite(v376_3,v375_6);
        const Space v376_5 = intersect(v376_4,s3);
        Space v375_6_next = unite(v375_6,v376_5);
        if (equal(v375_6_next,v375_6)) break;
        v375_6 = std::move(v375_6_next);
      }
      Space v375_7 = v270_5;
      for (;;) {
        const Space v386_1 = intersect(v375_7,s3);
        const Space v386_2 = restrict_to(s1,v386_1);
        Space v386_3_result;
        for (int v386_3_label = 1; v386_3_label <= 2; ++v386_3_label) {
          const Space v386_3_tail = child(v386_2,v386_3_label);
          if (v386_3_tail.empty()) continue;
          const Path v386_3_head{v386_3_label};
          const Space v387_2 = singleton(v386_3_head);
          const Space v387_3 = intersect(constant_9,v387_2);
          const Space v387_4 = (has_head(v387_3) ? constant_10 : Space{});
          const Space v387_5 = subtract(constant_0,v387_4);
          Space v387_7;
          if (!v387_5.empty()) {
            Space v388_6_result;
            for (int v388_6_label = 1; v388_6_label <= 2; ++v388_6_label) {
              const Space v388_6_tail = child(v386_3_tail,v388_6_label);
              if (v388_6_tail.empty()) continue;
              const Path v388_6_head{v388_6_label};
              const Space v389_2 = singleton(v388_6_head);
              const Space v389_3 = intersect(constant_9,v389_2);
              const Space v389_4 = (has_head(v389_3) ? constant_10 : Space{});
              const Space v389_5 = subtract(constant_0,v389_4);
              Space v389_8;
              if (!v389_5.empty()) {
                const Path v390_6 = concat_path(v386_3_head,v388_6_head);
                const Space v390_7 = routine_50(c, v390_6, v388_6_tail);
                v389_8 = compose(v389_5,v390_7);
              }
              const Space v389_9 = intersect(constant_9,v389_2);
              const Space v389_10 = (has_head(v389_9) ? constant_10 : Space{});
              Space v389_12;
              if (!v389_10.empty()) {
                const Path v391_6 = concat_path(v386_3_head,v388_6_head);
                const Space v391_11 = routine_51(c, v391_6, v388_6_tail);
                v389_12 = compose(v389_10,v391_11);
              }
              const Space v389_13 = unite(v389_8,v389_12);
              v388_6_result = unite(v388_6_result,v389_13);
            }
            const Space v388_6 = std::move(v388_6_result);
            v387_7 = compose(v387_5,v388_6);
          }
          const Space v387_8 = intersect(constant_9,v387_2);
          const Space v387_9 = (has_head(v387_8) ? constant_10 : Space{});
          Space v387_11;
          if (!v387_9.empty()) {
            Space v392_10_result;
            for (int v392_10_label = 1; v392_10_label <= 2; ++v392_10_label) {
              const Space v392_10_tail = child(v386_3_tail,v392_10_label);
              if (v392_10_tail.empty()) continue;
              const Path v392_10_head{v392_10_label};
              const Space v393_2 = singleton(v392_10_head);
              const Space v393_3 = intersect(constant_9,v393_2);
              const Space v393_4 = (has_head(v393_3) ? constant_10 : Space{});
              const Space v393_5 = subtract(constant_0,v393_4);
              Space v393_8;
              if (!v393_5.empty()) {
                const Path v394_6 = concat_path(v386_3_head,v392_10_head);
                const Space v394_7 = routine_50(c, v394_6, v392_10_tail);
                v393_8 = compose(v393_5,v394_7);
              }
              const Space v393_9 = intersect(constant_9,v393_2);
              const Space v393_10 = (has_head(v393_9) ? constant_10 : Space{});
              Space v393_12;
              if (!v393_10.empty()) {
                const Path v395_6 = concat_path(v386_3_head,v392_10_head);
                const Space v395_11 = routine_52(c, v395_6, v392_10_tail);
                v393_12 = compose(v393_10,v395_11);
              }
              const Space v393_13 = unite(v393_8,v393_12);
              v392_10_result = unite(v392_10_result,v393_13);
            }
            const Space v392_10 = std::move(v392_10_result);
            v387_11 = compose(v387_9,v392_10);
          }
          const Space v387_12 = unite(v387_7,v387_11);
          v386_3_result = unite(v386_3_result,v387_12);
        }
        const Space v386_3 = std::move(v386_3_result);
        const Space v386_4 = unite(v386_3,v375_7);
        const Space v386_5 = intersect(v386_4,s3);
        Space v375_7_next = unite(v375_7,v386_5);
        if (equal(v375_7_next,v375_7)) break;
        v375_7 = std::move(v375_7_next);
      }
      const Space v375_8 = subtract(v375_6,v375_7);
      const Space v375_9 = routine_14(c, v270_154_head, v270_154_tail, s1, s2, v375_8);
      v374_10 = compose(v374_5,v375_9);
    }
    const Space v374_11 = intersect(constant_9,v374_2);
    const Space v374_12 = (has_head(v374_11) ? constant_10 : Space{});
    Space v374_17;
    if (!v374_12.empty()) {
      Space v396_13 = v270_5;
      for (;;) {
        const Space v397_1 = intersect(v396_13,s3);
        const Space v397_2 = restrict_to(s2,v397_1);
        Space v397_3_result;
        for (int v397_3_label = 1; v397_3_label <= 2; ++v397_3_label) {
          const Space v397_3_tail = child(v397_2,v397_3_label);
          if (v397_3_tail.empty()) continue;
          const Path v397_3_head{v397_3_label};
          const Space v398_2 = singleton(v397_3_head);
          const Space v398_3 = intersect(constant_9,v398_2);
          const Space v398_4 = (has_head(v398_3) ? constant_10 : Space{});
          const Space v398_5 = subtract(constant_0,v398_4);
          Space v398_7;
          if (!v398_5.empty()) {
            Space v399_6_result;
            for (int v399_6_label = 1; v399_6_label <= 2; ++v399_6_label) {
              const Space v399_6_tail = child(v397_3_tail,v399_6_label);
              if (v399_6_tail.empty()) continue;
              const Path v399_6_head{v399_6_label};
              const Space v400_2 = singleton(v399_6_head);
              const Space v400_3 = intersect(constant_9,v400_2);
              const Space v400_4 = (has_head(v400_3) ? constant_10 : Space{});
              const Space v400_5 = subtract(constant_0,v400_4);
              Space v400_8;
              if (!v400_5.empty()) {
                const Path v401_6 = concat_path(v397_3_head,v399_6_head);
                const Space v401_7 = routine_50(c, v401_6, v399_6_tail);
                v400_8 = compose(v400_5,v401_7);
              }
              const Space v400_9 = intersect(constant_9,v400_2);
              const Space v400_10 = (has_head(v400_9) ? constant_10 : Space{});
              Space v400_12;
              if (!v400_10.empty()) {
                const Path v402_6 = concat_path(v397_3_head,v399_6_head);
                const Space v402_11 = routine_51(c, v402_6, v399_6_tail);
                v400_12 = compose(v400_10,v402_11);
              }
              const Space v400_13 = unite(v400_8,v400_12);
              v399_6_result = unite(v399_6_result,v400_13);
            }
            const Space v399_6 = std::move(v399_6_result);
            v398_7 = compose(v398_5,v399_6);
          }
          const Space v398_8 = intersect(constant_9,v398_2);
          const Space v398_9 = (has_head(v398_8) ? constant_10 : Space{});
          Space v398_11;
          if (!v398_9.empty()) {
            Space v403_10_result;
            for (int v403_10_label = 1; v403_10_label <= 2; ++v403_10_label) {
              const Space v403_10_tail = child(v397_3_tail,v403_10_label);
              if (v403_10_tail.empty()) continue;
              const Path v403_10_head{v403_10_label};
              const Space v404_2 = singleton(v403_10_head);
              const Space v404_3 = intersect(constant_9,v404_2);
              const Space v404_4 = (has_head(v404_3) ? constant_10 : Space{});
              const Space v404_5 = subtract(constant_0,v404_4);
              Space v404_8;
              if (!v404_5.empty()) {
                const Path v405_6 = concat_path(v397_3_head,v403_10_head);
                const Space v405_7 = routine_50(c, v405_6, v403_10_tail);
                v404_8 = compose(v404_5,v405_7);
              }
              const Space v404_9 = intersect(constant_9,v404_2);
              const Space v404_10 = (has_head(v404_9) ? constant_10 : Space{});
              Space v404_12;
              if (!v404_10.empty()) {
                const Path v406_6 = concat_path(v397_3_head,v403_10_head);
                const Space v406_11 = routine_52(c, v406_6, v403_10_tail);
                v404_12 = compose(v404_10,v406_11);
              }
              const Space v404_13 = unite(v404_8,v404_12);
              v403_10_result = unite(v403_10_result,v404_13);
            }
            const Space v403_10 = std::move(v403_10_result);
            v398_11 = compose(v398_9,v403_10);
          }
          const Space v398_12 = unite(v398_7,v398_11);
          v397_3_result = unite(v397_3_result,v398_12);
        }
        const Space v397_3 = std::move(v397_3_result);
        const Space v397_4 = unite(v397_3,v396_13);
        const Space v397_5 = intersect(v397_4,s3);
        Space v396_13_next = unite(v396_13,v397_5);
        if (equal(v396_13_next,v396_13)) break;
        v396_13 = std::move(v396_13_next);
      }
      Space v396_14 = v270_5;
      for (;;) {
        const Space v407_1 = intersect(v396_14,s3);
        const Space v407_2 = restrict_to(s1,v407_1);
        Space v407_3_result;
        for (int v407_3_label = 1; v407_3_label <= 2; ++v407_3_label) {
          const Space v407_3_tail = child(v407_2,v407_3_label);
          if (v407_3_tail.empty()) continue;
          const Path v407_3_head{v407_3_label};
          const Space v408_2 = singleton(v407_3_head);
          const Space v408_3 = intersect(constant_9,v408_2);
          const Space v408_4 = (has_head(v408_3) ? constant_10 : Space{});
          const Space v408_5 = subtract(constant_0,v408_4);
          Space v408_7;
          if (!v408_5.empty()) {
            Space v409_6_result;
            for (int v409_6_label = 1; v409_6_label <= 2; ++v409_6_label) {
              const Space v409_6_tail = child(v407_3_tail,v409_6_label);
              if (v409_6_tail.empty()) continue;
              const Path v409_6_head{v409_6_label};
              const Space v410_2 = singleton(v409_6_head);
              const Space v410_3 = intersect(constant_9,v410_2);
              const Space v410_4 = (has_head(v410_3) ? constant_10 : Space{});
              const Space v410_5 = subtract(constant_0,v410_4);
              Space v410_8;
              if (!v410_5.empty()) {
                const Path v411_6 = concat_path(v407_3_head,v409_6_head);
                const Space v411_7 = routine_50(c, v411_6, v409_6_tail);
                v410_8 = compose(v410_5,v411_7);
              }
              const Space v410_9 = intersect(constant_9,v410_2);
              const Space v410_10 = (has_head(v410_9) ? constant_10 : Space{});
              Space v410_12;
              if (!v410_10.empty()) {
                const Path v412_6 = concat_path(v407_3_head,v409_6_head);
                const Space v412_11 = routine_51(c, v412_6, v409_6_tail);
                v410_12 = compose(v410_10,v412_11);
              }
              const Space v410_13 = unite(v410_8,v410_12);
              v409_6_result = unite(v409_6_result,v410_13);
            }
            const Space v409_6 = std::move(v409_6_result);
            v408_7 = compose(v408_5,v409_6);
          }
          const Space v408_8 = intersect(constant_9,v408_2);
          const Space v408_9 = (has_head(v408_8) ? constant_10 : Space{});
          Space v408_11;
          if (!v408_9.empty()) {
            Space v413_10_result;
            for (int v413_10_label = 1; v413_10_label <= 2; ++v413_10_label) {
              const Space v413_10_tail = child(v407_3_tail,v413_10_label);
              if (v413_10_tail.empty()) continue;
              const Path v413_10_head{v413_10_label};
              const Space v414_2 = singleton(v413_10_head);
              const Space v414_3 = intersect(constant_9,v414_2);
              const Space v414_4 = (has_head(v414_3) ? constant_10 : Space{});
              const Space v414_5 = subtract(constant_0,v414_4);
              Space v414_8;
              if (!v414_5.empty()) {
                const Path v415_6 = concat_path(v407_3_head,v413_10_head);
                const Space v415_7 = routine_50(c, v415_6, v413_10_tail);
                v414_8 = compose(v414_5,v415_7);
              }
              const Space v414_9 = intersect(constant_9,v414_2);
              const Space v414_10 = (has_head(v414_9) ? constant_10 : Space{});
              Space v414_12;
              if (!v414_10.empty()) {
                const Path v416_6 = concat_path(v407_3_head,v413_10_head);
                const Space v416_11 = routine_52(c, v416_6, v413_10_tail);
                v414_12 = compose(v414_10,v416_11);
              }
              const Space v414_13 = unite(v414_8,v414_12);
              v413_10_result = unite(v413_10_result,v414_13);
            }
            const Space v413_10 = std::move(v413_10_result);
            v408_11 = compose(v408_9,v413_10);
          }
          const Space v408_12 = unite(v408_7,v408_11);
          v407_3_result = unite(v407_3_result,v408_12);
        }
        const Space v407_3 = std::move(v407_3_result);
        const Space v407_4 = unite(v407_3,v396_14);
        const Space v407_5 = intersect(v407_4,s3);
        Space v396_14_next = unite(v396_14,v407_5);
        if (equal(v396_14_next,v396_14)) break;
        v396_14 = std::move(v396_14_next);
      }
      const Space v396_15 = subtract(v396_13,v396_14);
      const Space v396_16 = routine_15(c, v270_154_head, v270_154_tail, s1, s2, v396_15);
      v374_17 = compose(v374_12,v396_16);
    }
    const Space v374_18 = unite(v374_10,v374_17);
    v270_154_result = unite(v270_154_result,v374_18);
  }
  const Space v270_154 = std::move(v270_154_result);
  const Space v270_155 = unite(v270_92,v270_154);
  Space v270_165 = v270_5;
  for (;;) {
    const Space v417_1 = intersect(v270_165,s3);
    const Space v417_2 = restrict_to(s1,v417_1);
    Space v417_3_result;
    for (int v417_3_label = 1; v417_3_label <= 2; ++v417_3_label) {
      const Space v417_3_tail = child(v417_2,v417_3_label);
      if (v417_3_tail.empty()) continue;
      const Path v417_3_head{v417_3_label};
      const Space v418_2 = singleton(v417_3_head);
      const Space v418_3 = intersect(constant_9,v418_2);
      const Space v418_4 = (has_head(v418_3) ? constant_10 : Space{});
      const Space v418_5 = subtract(constant_0,v418_4);
      Space v418_7;
      if (!v418_5.empty()) {
        Space v419_6_result;
        for (int v419_6_label = 1; v419_6_label <= 2; ++v419_6_label) {
          const Space v419_6_tail = child(v417_3_tail,v419_6_label);
          if (v419_6_tail.empty()) continue;
          const Path v419_6_head{v419_6_label};
          const Space v420_2 = singleton(v419_6_head);
          const Space v420_3 = intersect(constant_9,v420_2);
          const Space v420_4 = (has_head(v420_3) ? constant_10 : Space{});
          const Space v420_5 = subtract(constant_0,v420_4);
          Space v420_8;
          if (!v420_5.empty()) {
            const Path v421_6 = concat_path(v417_3_head,v419_6_head);
            const Space v421_7 = routine_50(c, v421_6, v419_6_tail);
            v420_8 = compose(v420_5,v421_7);
          }
          const Space v420_9 = intersect(constant_9,v420_2);
          const Space v420_10 = (has_head(v420_9) ? constant_10 : Space{});
          Space v420_12;
          if (!v420_10.empty()) {
            const Path v422_6 = concat_path(v417_3_head,v419_6_head);
            const Space v422_11 = routine_51(c, v422_6, v419_6_tail);
            v420_12 = compose(v420_10,v422_11);
          }
          const Space v420_13 = unite(v420_8,v420_12);
          v419_6_result = unite(v419_6_result,v420_13);
        }
        const Space v419_6 = std::move(v419_6_result);
        v418_7 = compose(v418_5,v419_6);
      }
      const Space v418_8 = intersect(constant_9,v418_2);
      const Space v418_9 = (has_head(v418_8) ? constant_10 : Space{});
      Space v418_11;
      if (!v418_9.empty()) {
        Space v423_10_result;
        for (int v423_10_label = 1; v423_10_label <= 2; ++v423_10_label) {
          const Space v423_10_tail = child(v417_3_tail,v423_10_label);
          if (v423_10_tail.empty()) continue;
          const Path v423_10_head{v423_10_label};
          const Space v424_2 = singleton(v423_10_head);
          const Space v424_3 = intersect(constant_9,v424_2);
          const Space v424_4 = (has_head(v424_3) ? constant_10 : Space{});
          const Space v424_5 = subtract(constant_0,v424_4);
          Space v424_8;
          if (!v424_5.empty()) {
            const Path v425_6 = concat_path(v417_3_head,v423_10_head);
            const Space v425_7 = routine_50(c, v425_6, v423_10_tail);
            v424_8 = compose(v424_5,v425_7);
          }
          const Space v424_9 = intersect(constant_9,v424_2);
          const Space v424_10 = (has_head(v424_9) ? constant_10 : Space{});
          Space v424_12;
          if (!v424_10.empty()) {
            const Path v426_6 = concat_path(v417_3_head,v423_10_head);
            const Space v426_11 = routine_52(c, v426_6, v423_10_tail);
            v424_12 = compose(v424_10,v426_11);
          }
          const Space v424_13 = unite(v424_8,v424_12);
          v423_10_result = unite(v423_10_result,v424_13);
        }
        const Space v423_10 = std::move(v423_10_result);
        v418_11 = compose(v418_9,v423_10);
      }
      const Space v418_12 = unite(v418_7,v418_11);
      v417_3_result = unite(v417_3_result,v418_12);
    }
    const Space v417_3 = std::move(v417_3_result);
    const Space v417_4 = unite(v417_3,v270_165);
    const Space v417_5 = intersect(v417_4,s3);
    Space v270_165_next = unite(v270_165,v417_5);
    if (equal(v270_165_next,v270_165)) break;
    v270_165 = std::move(v270_165_next);
  }
  Space v270_175 = v270_5;
  for (;;) {
    const Space v427_1 = intersect(v270_175,s3);
    const Space v427_2 = restrict_to(s2,v427_1);
    Space v427_3_result;
    for (int v427_3_label = 1; v427_3_label <= 2; ++v427_3_label) {
      const Space v427_3_tail = child(v427_2,v427_3_label);
      if (v427_3_tail.empty()) continue;
      const Path v427_3_head{v427_3_label};
      const Space v428_2 = singleton(v427_3_head);
      const Space v428_3 = intersect(constant_9,v428_2);
      const Space v428_4 = (has_head(v428_3) ? constant_10 : Space{});
      const Space v428_5 = subtract(constant_0,v428_4);
      Space v428_7;
      if (!v428_5.empty()) {
        Space v429_6_result;
        for (int v429_6_label = 1; v429_6_label <= 2; ++v429_6_label) {
          const Space v429_6_tail = child(v427_3_tail,v429_6_label);
          if (v429_6_tail.empty()) continue;
          const Path v429_6_head{v429_6_label};
          const Space v430_2 = singleton(v429_6_head);
          const Space v430_3 = intersect(constant_9,v430_2);
          const Space v430_4 = (has_head(v430_3) ? constant_10 : Space{});
          const Space v430_5 = subtract(constant_0,v430_4);
          Space v430_8;
          if (!v430_5.empty()) {
            const Path v431_6 = concat_path(v427_3_head,v429_6_head);
            const Space v431_7 = routine_50(c, v431_6, v429_6_tail);
            v430_8 = compose(v430_5,v431_7);
          }
          const Space v430_9 = intersect(constant_9,v430_2);
          const Space v430_10 = (has_head(v430_9) ? constant_10 : Space{});
          Space v430_12;
          if (!v430_10.empty()) {
            const Path v432_6 = concat_path(v427_3_head,v429_6_head);
            const Space v432_11 = routine_51(c, v432_6, v429_6_tail);
            v430_12 = compose(v430_10,v432_11);
          }
          const Space v430_13 = unite(v430_8,v430_12);
          v429_6_result = unite(v429_6_result,v430_13);
        }
        const Space v429_6 = std::move(v429_6_result);
        v428_7 = compose(v428_5,v429_6);
      }
      const Space v428_8 = intersect(constant_9,v428_2);
      const Space v428_9 = (has_head(v428_8) ? constant_10 : Space{});
      Space v428_11;
      if (!v428_9.empty()) {
        Space v433_10_result;
        for (int v433_10_label = 1; v433_10_label <= 2; ++v433_10_label) {
          const Space v433_10_tail = child(v427_3_tail,v433_10_label);
          if (v433_10_tail.empty()) continue;
          const Path v433_10_head{v433_10_label};
          const Space v434_2 = singleton(v433_10_head);
          const Space v434_3 = intersect(constant_9,v434_2);
          const Space v434_4 = (has_head(v434_3) ? constant_10 : Space{});
          const Space v434_5 = subtract(constant_0,v434_4);
          Space v434_8;
          if (!v434_5.empty()) {
            const Path v435_6 = concat_path(v427_3_head,v433_10_head);
            const Space v435_7 = routine_50(c, v435_6, v433_10_tail);
            v434_8 = compose(v434_5,v435_7);
          }
          const Space v434_9 = intersect(constant_9,v434_2);
          const Space v434_10 = (has_head(v434_9) ? constant_10 : Space{});
          Space v434_12;
          if (!v434_10.empty()) {
            const Path v436_6 = concat_path(v427_3_head,v433_10_head);
            const Space v436_11 = routine_52(c, v436_6, v433_10_tail);
            v434_12 = compose(v434_10,v436_11);
          }
          const Space v434_13 = unite(v434_8,v434_12);
          v433_10_result = unite(v433_10_result,v434_13);
        }
        const Space v433_10 = std::move(v433_10_result);
        v428_11 = compose(v428_9,v433_10);
      }
      const Space v428_12 = unite(v428_7,v428_11);
      v427_3_result = unite(v427_3_result,v428_12);
    }
    const Space v427_3 = std::move(v427_3_result);
    const Space v427_4 = unite(v427_3,v270_175);
    const Space v427_5 = intersect(v427_4,s3);
    Space v270_175_next = unite(v270_175,v427_5);
    if (equal(v270_175_next,v270_175)) break;
    v270_175 = std::move(v270_175_next);
  }
  const Space v270_176 = subtract(v270_165,v270_175);
  const Space v270_177 = routine_10(c, v270_176);
  Space v270_217_result;
  for (int v270_217_label = 1; v270_217_label <= 2; ++v270_217_label) {
    const Space v270_217_tail = child(v270_177,v270_217_label);
    if (v270_217_tail.empty()) continue;
    const Path v270_217_head{v270_217_label};
    const Space v437_2 = singleton(v270_217_head);
    const Space v437_3 = intersect(constant_9,v437_2);
    const Space v437_4 = (has_head(v437_3) ? constant_10 : Space{});
    const Space v437_5 = subtract(constant_0,v437_4);
    Space v437_10;
    if (!v437_5.empty()) {
      Space v438_6 = v270_5;
      for (;;) {
        const Space v439_1 = intersect(v438_6,s3);
        const Space v439_2 = restrict_to(s1,v439_1);
        Space v439_3_result;
        for (int v439_3_label = 1; v439_3_label <= 2; ++v439_3_label) {
          const Space v439_3_tail = child(v439_2,v439_3_label);
          if (v439_3_tail.empty()) continue;
          const Path v439_3_head{v439_3_label};
          const Space v440_2 = singleton(v439_3_head);
          const Space v440_3 = intersect(constant_9,v440_2);
          const Space v440_4 = (has_head(v440_3) ? constant_10 : Space{});
          const Space v440_5 = subtract(constant_0,v440_4);
          Space v440_7;
          if (!v440_5.empty()) {
            Space v441_6_result;
            for (int v441_6_label = 1; v441_6_label <= 2; ++v441_6_label) {
              const Space v441_6_tail = child(v439_3_tail,v441_6_label);
              if (v441_6_tail.empty()) continue;
              const Path v441_6_head{v441_6_label};
              const Space v442_2 = singleton(v441_6_head);
              const Space v442_3 = intersect(constant_9,v442_2);
              const Space v442_4 = (has_head(v442_3) ? constant_10 : Space{});
              const Space v442_5 = subtract(constant_0,v442_4);
              Space v442_8;
              if (!v442_5.empty()) {
                const Path v443_6 = concat_path(v439_3_head,v441_6_head);
                const Space v443_7 = routine_50(c, v443_6, v441_6_tail);
                v442_8 = compose(v442_5,v443_7);
              }
              const Space v442_9 = intersect(constant_9,v442_2);
              const Space v442_10 = (has_head(v442_9) ? constant_10 : Space{});
              Space v442_12;
              if (!v442_10.empty()) {
                const Path v444_6 = concat_path(v439_3_head,v441_6_head);
                const Space v444_11 = routine_51(c, v444_6, v441_6_tail);
                v442_12 = compose(v442_10,v444_11);
              }
              const Space v442_13 = unite(v442_8,v442_12);
              v441_6_result = unite(v441_6_result,v442_13);
            }
            const Space v441_6 = std::move(v441_6_result);
            v440_7 = compose(v440_5,v441_6);
          }
          const Space v440_8 = intersect(constant_9,v440_2);
          const Space v440_9 = (has_head(v440_8) ? constant_10 : Space{});
          Space v440_11;
          if (!v440_9.empty()) {
            Space v445_10_result;
            for (int v445_10_label = 1; v445_10_label <= 2; ++v445_10_label) {
              const Space v445_10_tail = child(v439_3_tail,v445_10_label);
              if (v445_10_tail.empty()) continue;
              const Path v445_10_head{v445_10_label};
              const Space v446_2 = singleton(v445_10_head);
              const Space v446_3 = intersect(constant_9,v446_2);
              const Space v446_4 = (has_head(v446_3) ? constant_10 : Space{});
              const Space v446_5 = subtract(constant_0,v446_4);
              Space v446_8;
              if (!v446_5.empty()) {
                const Path v447_6 = concat_path(v439_3_head,v445_10_head);
                const Space v447_7 = routine_50(c, v447_6, v445_10_tail);
                v446_8 = compose(v446_5,v447_7);
              }
              const Space v446_9 = intersect(constant_9,v446_2);
              const Space v446_10 = (has_head(v446_9) ? constant_10 : Space{});
              Space v446_12;
              if (!v446_10.empty()) {
                const Path v448_6 = concat_path(v439_3_head,v445_10_head);
                const Space v448_11 = routine_52(c, v448_6, v445_10_tail);
                v446_12 = compose(v446_10,v448_11);
              }
              const Space v446_13 = unite(v446_8,v446_12);
              v445_10_result = unite(v445_10_result,v446_13);
            }
            const Space v445_10 = std::move(v445_10_result);
            v440_11 = compose(v440_9,v445_10);
          }
          const Space v440_12 = unite(v440_7,v440_11);
          v439_3_result = unite(v439_3_result,v440_12);
        }
        const Space v439_3 = std::move(v439_3_result);
        const Space v439_4 = unite(v439_3,v438_6);
        const Space v439_5 = intersect(v439_4,s3);
        Space v438_6_next = unite(v438_6,v439_5);
        if (equal(v438_6_next,v438_6)) break;
        v438_6 = std::move(v438_6_next);
      }
      Space v438_7 = v270_5;
      for (;;) {
        const Space v449_1 = intersect(v438_7,s3);
        const Space v449_2 = restrict_to(s2,v449_1);
        Space v449_3_result;
        for (int v449_3_label = 1; v449_3_label <= 2; ++v449_3_label) {
          const Space v449_3_tail = child(v449_2,v449_3_label);
          if (v449_3_tail.empty()) continue;
          const Path v449_3_head{v449_3_label};
          const Space v450_2 = singleton(v449_3_head);
          const Space v450_3 = intersect(constant_9,v450_2);
          const Space v450_4 = (has_head(v450_3) ? constant_10 : Space{});
          const Space v450_5 = subtract(constant_0,v450_4);
          Space v450_7;
          if (!v450_5.empty()) {
            Space v451_6_result;
            for (int v451_6_label = 1; v451_6_label <= 2; ++v451_6_label) {
              const Space v451_6_tail = child(v449_3_tail,v451_6_label);
              if (v451_6_tail.empty()) continue;
              const Path v451_6_head{v451_6_label};
              const Space v452_2 = singleton(v451_6_head);
              const Space v452_3 = intersect(constant_9,v452_2);
              const Space v452_4 = (has_head(v452_3) ? constant_10 : Space{});
              const Space v452_5 = subtract(constant_0,v452_4);
              Space v452_8;
              if (!v452_5.empty()) {
                const Path v453_6 = concat_path(v449_3_head,v451_6_head);
                const Space v453_7 = routine_50(c, v453_6, v451_6_tail);
                v452_8 = compose(v452_5,v453_7);
              }
              const Space v452_9 = intersect(constant_9,v452_2);
              const Space v452_10 = (has_head(v452_9) ? constant_10 : Space{});
              Space v452_12;
              if (!v452_10.empty()) {
                const Path v454_6 = concat_path(v449_3_head,v451_6_head);
                const Space v454_11 = routine_51(c, v454_6, v451_6_tail);
                v452_12 = compose(v452_10,v454_11);
              }
              const Space v452_13 = unite(v452_8,v452_12);
              v451_6_result = unite(v451_6_result,v452_13);
            }
            const Space v451_6 = std::move(v451_6_result);
            v450_7 = compose(v450_5,v451_6);
          }
          const Space v450_8 = intersect(constant_9,v450_2);
          const Space v450_9 = (has_head(v450_8) ? constant_10 : Space{});
          Space v450_11;
          if (!v450_9.empty()) {
            Space v455_10_result;
            for (int v455_10_label = 1; v455_10_label <= 2; ++v455_10_label) {
              const Space v455_10_tail = child(v449_3_tail,v455_10_label);
              if (v455_10_tail.empty()) continue;
              const Path v455_10_head{v455_10_label};
              const Space v456_2 = singleton(v455_10_head);
              const Space v456_3 = intersect(constant_9,v456_2);
              const Space v456_4 = (has_head(v456_3) ? constant_10 : Space{});
              const Space v456_5 = subtract(constant_0,v456_4);
              Space v456_8;
              if (!v456_5.empty()) {
                const Path v457_6 = concat_path(v449_3_head,v455_10_head);
                const Space v457_7 = routine_50(c, v457_6, v455_10_tail);
                v456_8 = compose(v456_5,v457_7);
              }
              const Space v456_9 = intersect(constant_9,v456_2);
              const Space v456_10 = (has_head(v456_9) ? constant_10 : Space{});
              Space v456_12;
              if (!v456_10.empty()) {
                const Path v458_6 = concat_path(v449_3_head,v455_10_head);
                const Space v458_11 = routine_52(c, v458_6, v455_10_tail);
                v456_12 = compose(v456_10,v458_11);
              }
              const Space v456_13 = unite(v456_8,v456_12);
              v455_10_result = unite(v455_10_result,v456_13);
            }
            const Space v455_10 = std::move(v455_10_result);
            v450_11 = compose(v450_9,v455_10);
          }
          const Space v450_12 = unite(v450_7,v450_11);
          v449_3_result = unite(v449_3_result,v450_12);
        }
        const Space v449_3 = std::move(v449_3_result);
        const Space v449_4 = unite(v449_3,v438_7);
        const Space v449_5 = intersect(v449_4,s3);
        Space v438_7_next = unite(v438_7,v449_5);
        if (equal(v438_7_next,v438_7)) break;
        v438_7 = std::move(v438_7_next);
      }
      const Space v438_8 = subtract(v438_6,v438_7);
      const Space v438_9 = routine_14(c, v270_217_head, v270_217_tail, s1, s2, v438_8);
      v437_10 = compose(v437_5,v438_9);
    }
    const Space v437_11 = intersect(constant_9,v437_2);
    const Space v437_12 = (has_head(v437_11) ? constant_10 : Space{});
    Space v437_17;
    if (!v437_12.empty()) {
      Space v459_13 = v270_5;
      for (;;) {
        const Space v460_1 = intersect(v459_13,s3);
        const Space v460_2 = restrict_to(s1,v460_1);
        Space v460_3_result;
        for (int v460_3_label = 1; v460_3_label <= 2; ++v460_3_label) {
          const Space v460_3_tail = child(v460_2,v460_3_label);
          if (v460_3_tail.empty()) continue;
          const Path v460_3_head{v460_3_label};
          const Space v461_2 = singleton(v460_3_head);
          const Space v461_3 = intersect(constant_9,v461_2);
          const Space v461_4 = (has_head(v461_3) ? constant_10 : Space{});
          const Space v461_5 = subtract(constant_0,v461_4);
          Space v461_7;
          if (!v461_5.empty()) {
            Space v462_6_result;
            for (int v462_6_label = 1; v462_6_label <= 2; ++v462_6_label) {
              const Space v462_6_tail = child(v460_3_tail,v462_6_label);
              if (v462_6_tail.empty()) continue;
              const Path v462_6_head{v462_6_label};
              const Space v463_2 = singleton(v462_6_head);
              const Space v463_3 = intersect(constant_9,v463_2);
              const Space v463_4 = (has_head(v463_3) ? constant_10 : Space{});
              const Space v463_5 = subtract(constant_0,v463_4);
              Space v463_8;
              if (!v463_5.empty()) {
                const Path v464_6 = concat_path(v460_3_head,v462_6_head);
                const Space v464_7 = routine_50(c, v464_6, v462_6_tail);
                v463_8 = compose(v463_5,v464_7);
              }
              const Space v463_9 = intersect(constant_9,v463_2);
              const Space v463_10 = (has_head(v463_9) ? constant_10 : Space{});
              Space v463_12;
              if (!v463_10.empty()) {
                const Path v465_6 = concat_path(v460_3_head,v462_6_head);
                const Space v465_11 = routine_51(c, v465_6, v462_6_tail);
                v463_12 = compose(v463_10,v465_11);
              }
              const Space v463_13 = unite(v463_8,v463_12);
              v462_6_result = unite(v462_6_result,v463_13);
            }
            const Space v462_6 = std::move(v462_6_result);
            v461_7 = compose(v461_5,v462_6);
          }
          const Space v461_8 = intersect(constant_9,v461_2);
          const Space v461_9 = (has_head(v461_8) ? constant_10 : Space{});
          Space v461_11;
          if (!v461_9.empty()) {
            Space v466_10_result;
            for (int v466_10_label = 1; v466_10_label <= 2; ++v466_10_label) {
              const Space v466_10_tail = child(v460_3_tail,v466_10_label);
              if (v466_10_tail.empty()) continue;
              const Path v466_10_head{v466_10_label};
              const Space v467_2 = singleton(v466_10_head);
              const Space v467_3 = intersect(constant_9,v467_2);
              const Space v467_4 = (has_head(v467_3) ? constant_10 : Space{});
              const Space v467_5 = subtract(constant_0,v467_4);
              Space v467_8;
              if (!v467_5.empty()) {
                const Path v468_6 = concat_path(v460_3_head,v466_10_head);
                const Space v468_7 = routine_50(c, v468_6, v466_10_tail);
                v467_8 = compose(v467_5,v468_7);
              }
              const Space v467_9 = intersect(constant_9,v467_2);
              const Space v467_10 = (has_head(v467_9) ? constant_10 : Space{});
              Space v467_12;
              if (!v467_10.empty()) {
                const Path v469_6 = concat_path(v460_3_head,v466_10_head);
                const Space v469_11 = routine_52(c, v469_6, v466_10_tail);
                v467_12 = compose(v467_10,v469_11);
              }
              const Space v467_13 = unite(v467_8,v467_12);
              v466_10_result = unite(v466_10_result,v467_13);
            }
            const Space v466_10 = std::move(v466_10_result);
            v461_11 = compose(v461_9,v466_10);
          }
          const Space v461_12 = unite(v461_7,v461_11);
          v460_3_result = unite(v460_3_result,v461_12);
        }
        const Space v460_3 = std::move(v460_3_result);
        const Space v460_4 = unite(v460_3,v459_13);
        const Space v460_5 = intersect(v460_4,s3);
        Space v459_13_next = unite(v459_13,v460_5);
        if (equal(v459_13_next,v459_13)) break;
        v459_13 = std::move(v459_13_next);
      }
      Space v459_14 = v270_5;
      for (;;) {
        const Space v470_1 = intersect(v459_14,s3);
        const Space v470_2 = restrict_to(s2,v470_1);
        Space v470_3_result;
        for (int v470_3_label = 1; v470_3_label <= 2; ++v470_3_label) {
          const Space v470_3_tail = child(v470_2,v470_3_label);
          if (v470_3_tail.empty()) continue;
          const Path v470_3_head{v470_3_label};
          const Space v471_2 = singleton(v470_3_head);
          const Space v471_3 = intersect(constant_9,v471_2);
          const Space v471_4 = (has_head(v471_3) ? constant_10 : Space{});
          const Space v471_5 = subtract(constant_0,v471_4);
          Space v471_7;
          if (!v471_5.empty()) {
            Space v472_6_result;
            for (int v472_6_label = 1; v472_6_label <= 2; ++v472_6_label) {
              const Space v472_6_tail = child(v470_3_tail,v472_6_label);
              if (v472_6_tail.empty()) continue;
              const Path v472_6_head{v472_6_label};
              const Space v473_2 = singleton(v472_6_head);
              const Space v473_3 = intersect(constant_9,v473_2);
              const Space v473_4 = (has_head(v473_3) ? constant_10 : Space{});
              const Space v473_5 = subtract(constant_0,v473_4);
              Space v473_8;
              if (!v473_5.empty()) {
                const Path v474_6 = concat_path(v470_3_head,v472_6_head);
                const Space v474_7 = routine_50(c, v474_6, v472_6_tail);
                v473_8 = compose(v473_5,v474_7);
              }
              const Space v473_9 = intersect(constant_9,v473_2);
              const Space v473_10 = (has_head(v473_9) ? constant_10 : Space{});
              Space v473_12;
              if (!v473_10.empty()) {
                const Path v475_6 = concat_path(v470_3_head,v472_6_head);
                const Space v475_11 = routine_51(c, v475_6, v472_6_tail);
                v473_12 = compose(v473_10,v475_11);
              }
              const Space v473_13 = unite(v473_8,v473_12);
              v472_6_result = unite(v472_6_result,v473_13);
            }
            const Space v472_6 = std::move(v472_6_result);
            v471_7 = compose(v471_5,v472_6);
          }
          const Space v471_8 = intersect(constant_9,v471_2);
          const Space v471_9 = (has_head(v471_8) ? constant_10 : Space{});
          Space v471_11;
          if (!v471_9.empty()) {
            Space v476_10_result;
            for (int v476_10_label = 1; v476_10_label <= 2; ++v476_10_label) {
              const Space v476_10_tail = child(v470_3_tail,v476_10_label);
              if (v476_10_tail.empty()) continue;
              const Path v476_10_head{v476_10_label};
              const Space v477_2 = singleton(v476_10_head);
              const Space v477_3 = intersect(constant_9,v477_2);
              const Space v477_4 = (has_head(v477_3) ? constant_10 : Space{});
              const Space v477_5 = subtract(constant_0,v477_4);
              Space v477_8;
              if (!v477_5.empty()) {
                const Path v478_6 = concat_path(v470_3_head,v476_10_head);
                const Space v478_7 = routine_50(c, v478_6, v476_10_tail);
                v477_8 = compose(v477_5,v478_7);
              }
              const Space v477_9 = intersect(constant_9,v477_2);
              const Space v477_10 = (has_head(v477_9) ? constant_10 : Space{});
              Space v477_12;
              if (!v477_10.empty()) {
                const Path v479_6 = concat_path(v470_3_head,v476_10_head);
                const Space v479_11 = routine_52(c, v479_6, v476_10_tail);
                v477_12 = compose(v477_10,v479_11);
              }
              const Space v477_13 = unite(v477_8,v477_12);
              v476_10_result = unite(v476_10_result,v477_13);
            }
            const Space v476_10 = std::move(v476_10_result);
            v471_11 = compose(v471_9,v476_10);
          }
          const Space v471_12 = unite(v471_7,v471_11);
          v470_3_result = unite(v470_3_result,v471_12);
        }
        const Space v470_3 = std::move(v470_3_result);
        const Space v470_4 = unite(v470_3,v459_14);
        const Space v470_5 = intersect(v470_4,s3);
        Space v459_14_next = unite(v459_14,v470_5);
        if (equal(v459_14_next,v459_14)) break;
        v459_14 = std::move(v459_14_next);
      }
      const Space v459_15 = subtract(v459_13,v459_14);
      const Space v459_16 = routine_15(c, v270_217_head, v270_217_tail, s1, s2, v459_15);
      v437_17 = compose(v437_12,v459_16);
    }
    const Space v437_18 = unite(v437_10,v437_17);
    v270_217_result = unite(v270_217_result,v437_18);
  }
  const Space v270_217 = std::move(v270_217_result);
  const Space v270_218 = unite(v270_155,v270_217);
  return v270_218;
}

static Space routine_38(Context& c, const Space& s0, const Space& s1, const Space& s2) {
  const Space v480_3 = intersect(s1,s2);
  const Space v480_4 = restrict_to(s0,v480_3);
  Space v480_14_result;
  for (int v480_14_label = 1; v480_14_label <= 2; ++v480_14_label) {
    const Space v480_14_tail = child(v480_4,v480_14_label);
    if (v480_14_tail.empty()) continue;
    const Path v480_14_head{v480_14_label};
    const Space v481_2 = singleton(v480_14_head);
    const Space v481_3 = intersect(constant_9,v481_2);
    const Space v481_4 = (has_head(v481_3) ? constant_10 : Space{});
    const Space v481_5 = subtract(constant_0,v481_4);
    Space v481_7;
    if (!v481_5.empty()) {
      Space v482_6_result;
      for (int v482_6_label = 1; v482_6_label <= 2; ++v482_6_label) {
        const Space v482_6_tail = child(v480_14_tail,v482_6_label);
        if (v482_6_tail.empty()) continue;
        const Path v482_6_head{v482_6_label};
        const Space v483_2 = singleton(v482_6_head);
        const Space v483_3 = intersect(constant_9,v483_2);
        const Space v483_4 = (has_head(v483_3) ? constant_10 : Space{});
        const Space v483_5 = subtract(constant_0,v483_4);
        Space v483_8;
        if (!v483_5.empty()) {
          const Path v484_6 = concat_path(v480_14_head,v482_6_head);
          const Space v484_7 = routine_50(c, v484_6, v482_6_tail);
          v483_8 = compose(v483_5,v484_7);
        }
        const Space v483_9 = intersect(constant_9,v483_2);
        const Space v483_10 = (has_head(v483_9) ? constant_10 : Space{});
        Space v483_12;
        if (!v483_10.empty()) {
          const Path v485_6 = concat_path(v480_14_head,v482_6_head);
          const Space v485_11 = routine_51(c, v485_6, v482_6_tail);
          v483_12 = compose(v483_10,v485_11);
        }
        const Space v483_13 = unite(v483_8,v483_12);
        v482_6_result = unite(v482_6_result,v483_13);
      }
      const Space v482_6 = std::move(v482_6_result);
      v481_7 = compose(v481_5,v482_6);
    }
    const Space v481_8 = intersect(constant_9,v481_2);
    const Space v481_9 = (has_head(v481_8) ? constant_10 : Space{});
    Space v481_11;
    if (!v481_9.empty()) {
      Space v486_10_result;
      for (int v486_10_label = 1; v486_10_label <= 2; ++v486_10_label) {
        const Space v486_10_tail = child(v480_14_tail,v486_10_label);
        if (v486_10_tail.empty()) continue;
        const Path v486_10_head{v486_10_label};
        const Space v487_2 = singleton(v486_10_head);
        const Space v487_3 = intersect(constant_9,v487_2);
        const Space v487_4 = (has_head(v487_3) ? constant_10 : Space{});
        const Space v487_5 = subtract(constant_0,v487_4);
        Space v487_8;
        if (!v487_5.empty()) {
          const Path v488_6 = concat_path(v480_14_head,v486_10_head);
          const Space v488_7 = routine_50(c, v488_6, v486_10_tail);
          v487_8 = compose(v487_5,v488_7);
        }
        const Space v487_9 = intersect(constant_9,v487_2);
        const Space v487_10 = (has_head(v487_9) ? constant_10 : Space{});
        Space v487_12;
        if (!v487_10.empty()) {
          const Path v489_6 = concat_path(v480_14_head,v486_10_head);
          const Space v489_11 = routine_52(c, v489_6, v486_10_tail);
          v487_12 = compose(v487_10,v489_11);
        }
        const Space v487_13 = unite(v487_8,v487_12);
        v486_10_result = unite(v486_10_result,v487_13);
      }
      const Space v486_10 = std::move(v486_10_result);
      v481_11 = compose(v481_9,v486_10);
    }
    const Space v481_12 = unite(v481_7,v481_11);
    v480_14_result = unite(v480_14_result,v481_12);
  }
  const Space v480_14 = std::move(v480_14_result);
  const Space v480_15 = unite(v480_14,s2);
  const Space v480_16 = intersect(v480_15,s1);
  Space v480_26 = v480_16;
  for (;;) {
    const Space v490_1 = intersect(v480_26,s1);
    const Space v490_2 = restrict_to(s0,v490_1);
    Space v490_3_result;
    for (int v490_3_label = 1; v490_3_label <= 2; ++v490_3_label) {
      const Space v490_3_tail = child(v490_2,v490_3_label);
      if (v490_3_tail.empty()) continue;
      const Path v490_3_head{v490_3_label};
      const Space v491_2 = singleton(v490_3_head);
      const Space v491_3 = intersect(constant_9,v491_2);
      const Space v491_4 = (has_head(v491_3) ? constant_10 : Space{});
      const Space v491_5 = subtract(constant_0,v491_4);
      Space v491_7;
      if (!v491_5.empty()) {
        Space v492_6_result;
        for (int v492_6_label = 1; v492_6_label <= 2; ++v492_6_label) {
          const Space v492_6_tail = child(v490_3_tail,v492_6_label);
          if (v492_6_tail.empty()) continue;
          const Path v492_6_head{v492_6_label};
          const Space v493_2 = singleton(v492_6_head);
          const Space v493_3 = intersect(constant_9,v493_2);
          const Space v493_4 = (has_head(v493_3) ? constant_10 : Space{});
          const Space v493_5 = subtract(constant_0,v493_4);
          Space v493_8;
          if (!v493_5.empty()) {
            const Path v494_6 = concat_path(v490_3_head,v492_6_head);
            const Space v494_7 = routine_50(c, v494_6, v492_6_tail);
            v493_8 = compose(v493_5,v494_7);
          }
          const Space v493_9 = intersect(constant_9,v493_2);
          const Space v493_10 = (has_head(v493_9) ? constant_10 : Space{});
          Space v493_12;
          if (!v493_10.empty()) {
            const Path v495_6 = concat_path(v490_3_head,v492_6_head);
            const Space v495_11 = routine_51(c, v495_6, v492_6_tail);
            v493_12 = compose(v493_10,v495_11);
          }
          const Space v493_13 = unite(v493_8,v493_12);
          v492_6_result = unite(v492_6_result,v493_13);
        }
        const Space v492_6 = std::move(v492_6_result);
        v491_7 = compose(v491_5,v492_6);
      }
      const Space v491_8 = intersect(constant_9,v491_2);
      const Space v491_9 = (has_head(v491_8) ? constant_10 : Space{});
      Space v491_11;
      if (!v491_9.empty()) {
        Space v496_10_result;
        for (int v496_10_label = 1; v496_10_label <= 2; ++v496_10_label) {
          const Space v496_10_tail = child(v490_3_tail,v496_10_label);
          if (v496_10_tail.empty()) continue;
          const Path v496_10_head{v496_10_label};
          const Space v497_2 = singleton(v496_10_head);
          const Space v497_3 = intersect(constant_9,v497_2);
          const Space v497_4 = (has_head(v497_3) ? constant_10 : Space{});
          const Space v497_5 = subtract(constant_0,v497_4);
          Space v497_8;
          if (!v497_5.empty()) {
            const Path v498_6 = concat_path(v490_3_head,v496_10_head);
            const Space v498_7 = routine_50(c, v498_6, v496_10_tail);
            v497_8 = compose(v497_5,v498_7);
          }
          const Space v497_9 = intersect(constant_9,v497_2);
          const Space v497_10 = (has_head(v497_9) ? constant_10 : Space{});
          Space v497_12;
          if (!v497_10.empty()) {
            const Path v499_6 = concat_path(v490_3_head,v496_10_head);
            const Space v499_11 = routine_52(c, v499_6, v496_10_tail);
            v497_12 = compose(v497_10,v499_11);
          }
          const Space v497_13 = unite(v497_8,v497_12);
          v496_10_result = unite(v496_10_result,v497_13);
        }
        const Space v496_10 = std::move(v496_10_result);
        v491_11 = compose(v491_9,v496_10);
      }
      const Space v491_12 = unite(v491_7,v491_11);
      v490_3_result = unite(v490_3_result,v491_12);
    }
    const Space v490_3 = std::move(v490_3_result);
    const Space v490_4 = unite(v490_3,v480_26);
    const Space v490_5 = intersect(v490_4,s1);
    Space v480_26_next = unite(v480_26,v490_5);
    if (equal(v480_26_next,v480_26)) break;
    v480_26 = std::move(v480_26_next);
  }
  const Space v480_27 = unite(s2,v480_26);
  return v480_27;
}

static Space routine_39(Context& c, const Space& s0, const Space& s1, const Space& s2) {
  const Space v500_3 = routine_53(c, s2);
  const Space v500_4 = subtract(s2,v500_3);
  Space v500_14_result;
  for (int v500_14_label = 1; v500_14_label <= 2; ++v500_14_label) {
    const Space v500_14_tail = child(v500_4,v500_14_label);
    if (v500_14_tail.empty()) continue;
    const Path v500_14_head{v500_14_label};
    const Space v501_2 = singleton(v500_14_head);
    const Space v501_3 = intersect(constant_9,v501_2);
    const Space v501_4 = (has_head(v501_3) ? constant_10 : Space{});
    const Space v501_5 = subtract(constant_0,v501_4);
    Space v501_7;
    if (!v501_5.empty()) {
      Space v502_6_result;
      for (int v502_6_label = 1; v502_6_label <= 2; ++v502_6_label) {
        const Space v502_6_tail = child(v500_14_tail,v502_6_label);
        if (v502_6_tail.empty()) continue;
        const Path v502_6_head{v502_6_label};
        const Space v503_2 = singleton(v502_6_head);
        const Space v503_3 = intersect(constant_9,v503_2);
        const Space v503_4 = (has_head(v503_3) ? constant_10 : Space{});
        const Space v503_5 = subtract(constant_0,v503_4);
        Space v503_8;
        if (!v503_5.empty()) {
          const Path v504_6 = concat_path(v500_14_head,v502_6_head);
          const Space v504_7 = routine_54(c, v504_6, v502_6_tail, s1, s0, s2);
          v503_8 = compose(v503_5,v504_7);
        }
        const Space v503_9 = intersect(constant_9,v503_2);
        const Space v503_10 = (has_head(v503_9) ? constant_10 : Space{});
        Space v503_12;
        if (!v503_10.empty()) {
          const Path v505_6 = concat_path(v500_14_head,v502_6_head);
          const Space v505_11 = routine_55(c, v505_6, v502_6_tail, s1, s0, s2);
          v503_12 = compose(v503_10,v505_11);
        }
        const Space v503_13 = unite(v503_8,v503_12);
        v502_6_result = unite(v502_6_result,v503_13);
      }
      const Space v502_6 = std::move(v502_6_result);
      v501_7 = compose(v501_5,v502_6);
    }
    const Space v501_8 = intersect(constant_9,v501_2);
    const Space v501_9 = (has_head(v501_8) ? constant_10 : Space{});
    Space v501_11;
    if (!v501_9.empty()) {
      Space v506_10_result;
      for (int v506_10_label = 1; v506_10_label <= 2; ++v506_10_label) {
        const Space v506_10_tail = child(v500_14_tail,v506_10_label);
        if (v506_10_tail.empty()) continue;
        const Path v506_10_head{v506_10_label};
        const Space v507_2 = singleton(v506_10_head);
        const Space v507_3 = intersect(constant_9,v507_2);
        const Space v507_4 = (has_head(v507_3) ? constant_10 : Space{});
        const Space v507_5 = subtract(constant_0,v507_4);
        Space v507_8;
        if (!v507_5.empty()) {
          const Path v508_6 = concat_path(v500_14_head,v506_10_head);
          const Space v508_7 = routine_54(c, v508_6, v506_10_tail, s1, s0, s2);
          v507_8 = compose(v507_5,v508_7);
        }
        const Space v507_9 = intersect(constant_9,v507_2);
        const Space v507_10 = (has_head(v507_9) ? constant_10 : Space{});
        Space v507_12;
        if (!v507_10.empty()) {
          const Path v509_6 = concat_path(v500_14_head,v506_10_head);
          const Space v509_11 = routine_37(c, v509_6, v506_10_tail, s1, s0, s2);
          v507_12 = compose(v507_10,v509_11);
        }
        const Space v507_13 = unite(v507_8,v507_12);
        v506_10_result = unite(v506_10_result,v507_13);
      }
      const Space v506_10 = std::move(v506_10_result);
      v501_11 = compose(v501_9,v506_10);
    }
    const Space v501_12 = unite(v501_7,v501_11);
    v500_14_result = unite(v500_14_result,v501_12);
  }
  const Space v500_14 = std::move(v500_14_result);
  return v500_14;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v510_7_result;
  for (int v510_7_label = 1; v510_7_label <= 2; ++v510_7_label) {
    const Space v510_7_tail = child(s0,v510_7_label);
    if (v510_7_tail.empty()) continue;
    const Path v510_7_head{v510_7_label};
    const Space v511_2 = singleton(v510_7_head);
    const Space v511_3 = intersect(constant_9,v511_2);
    const Space v511_4 = (has_head(v511_3) ? constant_10 : Space{});
    const Space v511_5 = subtract(constant_0,v511_4);
    Space v511_6_result;
    for (int v511_6_label = 1; v511_6_label <= 2; ++v511_6_label) {
      const Space v511_6_tail = child(v510_7_tail,v511_6_label);
      if (v511_6_tail.empty()) continue;
      const Path v511_6_head{v511_6_label};
      const Space v512_2 = Space{};
      v511_6_result = unite(v511_6_result,v512_2);
    }
    const Space v511_6 = std::move(v511_6_result);
    const Space v511_7 = compose(v511_5,v511_6);
    const Space v511_8 = intersect(constant_9,v511_2);
    const Space v511_9 = (has_head(v511_8) ? constant_10 : Space{});
    Space v511_12;
    if (!v511_9.empty()) {
      const Path v513_10 = concat_path(p0,v510_7_head);
      Space v513_11_result;
      for (int v513_11_label = 1; v513_11_label <= 2; ++v513_11_label) {
        const Space v513_11_tail = child(v510_7_tail,v513_11_label);
        if (v513_11_tail.empty()) continue;
        const Path v513_11_head{v513_11_label};
        const Space v514_2 = singleton(v513_11_head);
        const Space v514_3 = intersect(constant_9,v514_2);
        const Space v514_4 = (has_head(v514_3) ? constant_10 : Space{});
        Space v514_7;
        if (!v514_4.empty()) {
          const Path v515_5 = concat_path(v513_10,v513_11_head);
          const Space v515_6 = routine_24(c, v515_5, p1, v513_11_tail);
          v514_7 = compose(v514_4,v515_6);
        }
        v513_11_result = unite(v513_11_result,v514_7);
      }
      const Space v513_11 = std::move(v513_11_result);
      v511_12 = compose(v511_9,v513_11);
    }
    const Space v511_13 = unite(v511_7,v511_12);
    v510_7_result = unite(v510_7_result,v511_13);
  }
  const Space v510_7 = std::move(v510_7_result);
  return v510_7;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v516_6_result;
  for (int v516_6_label = 1; v516_6_label <= 2; ++v516_6_label) {
    const Space v516_6_tail = child(s0,v516_6_label);
    if (v516_6_tail.empty()) continue;
    const Path v516_6_head{v516_6_label};
    const Space v517_2 = singleton(v516_6_head);
    const Space v517_3 = intersect(constant_9,v517_2);
    const Space v517_4 = (has_head(v517_3) ? constant_10 : Space{});
    const Space v517_5 = subtract(constant_0,v517_4);
    Space v517_6_result;
    for (int v517_6_label = 1; v517_6_label <= 2; ++v517_6_label) {
      const Space v517_6_tail = child(v516_6_tail,v517_6_label);
      if (v517_6_tail.empty()) continue;
      const Path v517_6_head{v517_6_label};
      const Space v518_2 = Space{};
      v517_6_result = unite(v517_6_result,v518_2);
    }
    const Space v517_6 = std::move(v517_6_result);
    const Space v517_7 = compose(v517_5,v517_6);
    const Space v517_8 = intersect(constant_9,v517_2);
    const Space v517_9 = (has_head(v517_8) ? constant_10 : Space{});
    const Path v517_10 = concat_path(p0,v516_6_head);
    const Path v517_11 = concat_path(v517_10,p1);
    const Space v517_12 = singleton(v517_11);
    const Space v517_13 = compose(v517_9,v517_12);
    const Space v517_14 = unite(v517_7,v517_13);
    v516_6_result = unite(v516_6_result,v517_14);
  }
  const Space v516_6 = std::move(v516_6_result);
  return v516_6;
}

static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v519_3_result;
  for (int v519_3_label = 1; v519_3_label <= 2; ++v519_3_label) {
    const Space v519_3_tail = child(s0,v519_3_label);
    if (v519_3_tail.empty()) continue;
    const Path v519_3_head{v519_3_label};
    const Space v520_2 = Space{};
    v519_3_result = unite(v519_3_result,v520_2);
  }
  const Space v519_3 = std::move(v519_3_result);
  return v519_3;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v521_4_result;
  for (int v521_4_label = 1; v521_4_label <= 2; ++v521_4_label) {
    const Space v521_4_tail = child(s0,v521_4_label);
    if (v521_4_tail.empty()) continue;
    const Path v521_4_head{v521_4_label};
    const Space v522_2 = singleton(v521_4_head);
    const Space v522_3 = intersect(constant_9,v522_2);
    const Space v522_4 = (has_head(v522_3) ? constant_10 : Space{});
    const Path v522_5 = concat_path(p0,v521_4_head);
    const Path v522_6 = concat_path(v522_5,p1);
    const Space v522_7 = singleton(v522_6);
    const Space v522_8 = compose(v522_4,v522_7);
    v521_4_result = unite(v521_4_result,v522_8);
  }
  const Space v521_4 = std::move(v521_4_result);
  return v521_4;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0) {
  const Space v523_3 = unwrap(s0,p0);
  const Space v523_4 = first_matching(v523_3,constant_0,false);
  const Space v523_5 = intersect(constant_0,v523_4);
  const Space v523_6 = (has_head(v523_4) ? constant_10 : Space{});
  const Space v523_7 = unite(v523_5,v523_6);
  const Space v523_9 = compose(v523_7,constant_0);
  const Space v523_11 = subtract(constant_0,v523_4);
  const Space v523_12 = subtract(v523_11,v523_6);
  Space v523_16;
  if (!v523_12.empty()) {
    const Space v524_14 = first_fibonacci(v523_3,6,5,true);
    const Space v524_15 = routine_45(c, constant_12, v524_14, v523_3);
    v523_16 = compose(v523_12,v524_15);
  }
  const Space v523_17 = unite(v523_9,v523_16);
  const Space v523_18 = wrap(v523_17,p0);
  return v523_18;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v525_3 = first_matching(s0,constant_0,false);
  Space v525_7;
  if (!v525_3.empty()) {
    const Space v526_4 = unwrap(s1,p0);
    const Space v526_5 = routine_27(c, v526_4);
    const Space v526_6 = wrap(v526_5,p0);
    v525_7 = compose(v525_3,v526_6);
  }
  Space v525_8_result;
  for (int v525_8_label = 1; v525_8_label <= 2; ++v525_8_label) {
    const Space v525_8_tail = child(s0,v525_8_label);
    if (v525_8_tail.empty()) continue;
    const Path v525_8_head{v525_8_label};
    const Path v527_2 = concat_path(p0,v525_8_head);
    const Space v527_3 = routine_45(c, v527_2, v525_8_tail, s1);
    v525_8_result = unite(v525_8_result,v527_3);
  }
  const Space v525_8 = std::move(v525_8_result);
  const Space v525_9 = unite(v525_7,v525_8);
  return v525_9;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v528_7_result;
  for (int v528_7_label = 1; v528_7_label <= 2; ++v528_7_label) {
    const Space v528_7_tail = child(s0,v528_7_label);
    if (v528_7_tail.empty()) continue;
    const Path v528_7_head{v528_7_label};
    const Space v529_2 = singleton(v528_7_head);
    const Space v529_3 = intersect(constant_9,v529_2);
    const Space v529_4 = (has_head(v529_3) ? constant_10 : Space{});
    const Space v529_5 = subtract(constant_0,v529_4);
    Space v529_6_result;
    for (int v529_6_label = 1; v529_6_label <= 2; ++v529_6_label) {
      const Space v529_6_tail = child(v528_7_tail,v529_6_label);
      if (v529_6_tail.empty()) continue;
      const Path v529_6_head{v529_6_label};
      const Space v530_2 = Space{};
      v529_6_result = unite(v529_6_result,v530_2);
    }
    const Space v529_6 = std::move(v529_6_result);
    const Space v529_7 = compose(v529_5,v529_6);
    const Space v529_8 = intersect(constant_9,v529_2);
    const Space v529_9 = (has_head(v529_8) ? constant_10 : Space{});
    Space v529_12;
    if (!v529_9.empty()) {
      const Path v531_10 = concat_path(p0,v528_7_head);
      Space v531_11_result;
      for (int v531_11_label = 1; v531_11_label <= 2; ++v531_11_label) {
        const Space v531_11_tail = child(v528_7_tail,v531_11_label);
        if (v531_11_tail.empty()) continue;
        const Path v531_11_head{v531_11_label};
        const Space v532_2 = singleton(v531_11_head);
        const Space v532_3 = intersect(constant_9,v532_2);
        const Space v532_4 = (has_head(v532_3) ? constant_10 : Space{});
        Space v532_7;
        if (!v532_4.empty()) {
          const Path v533_5 = concat_path(v531_10,v531_11_head);
          const Space v533_6 = routine_34(c, v533_5, p1, v531_11_tail);
          v532_7 = compose(v532_4,v533_6);
        }
        v531_11_result = unite(v531_11_result,v532_7);
      }
      const Space v531_11 = std::move(v531_11_result);
      v529_12 = compose(v529_9,v531_11);
    }
    const Space v529_13 = unite(v529_7,v529_12);
    v528_7_result = unite(v528_7_result,v529_13);
  }
  const Space v528_7 = std::move(v528_7_result);
  return v528_7;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v534_6_result;
  for (int v534_6_label = 1; v534_6_label <= 2; ++v534_6_label) {
    const Space v534_6_tail = child(s0,v534_6_label);
    if (v534_6_tail.empty()) continue;
    const Path v534_6_head{v534_6_label};
    const Space v535_2 = singleton(v534_6_head);
    const Space v535_3 = intersect(constant_9,v535_2);
    const Space v535_4 = (has_head(v535_3) ? constant_10 : Space{});
    const Space v535_5 = subtract(constant_0,v535_4);
    Space v535_6_result;
    for (int v535_6_label = 1; v535_6_label <= 2; ++v535_6_label) {
      const Space v535_6_tail = child(v534_6_tail,v535_6_label);
      if (v535_6_tail.empty()) continue;
      const Path v535_6_head{v535_6_label};
      const Space v536_2 = Space{};
      v535_6_result = unite(v535_6_result,v536_2);
    }
    const Space v535_6 = std::move(v535_6_result);
    const Space v535_7 = compose(v535_5,v535_6);
    const Space v535_8 = intersect(constant_9,v535_2);
    const Space v535_9 = (has_head(v535_8) ? constant_10 : Space{});
    const Path v535_10 = concat_path(p0,v534_6_head);
    const Path v535_11 = concat_path(v535_10,p1);
    const Space v535_12 = singleton(v535_11);
    const Space v535_13 = compose(v535_9,v535_12);
    const Space v535_14 = unite(v535_7,v535_13);
    v534_6_result = unite(v534_6_result,v535_14);
  }
  const Space v534_6 = std::move(v534_6_result);
  return v534_6;
}

static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v537_3_result;
  for (int v537_3_label = 1; v537_3_label <= 2; ++v537_3_label) {
    const Space v537_3_tail = child(s0,v537_3_label);
    if (v537_3_tail.empty()) continue;
    const Path v537_3_head{v537_3_label};
    const Space v538_2 = Space{};
    v537_3_result = unite(v537_3_result,v538_2);
  }
  const Space v537_3 = std::move(v537_3_result);
  return v537_3;
}

static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v539_4_result;
  for (int v539_4_label = 1; v539_4_label <= 2; ++v539_4_label) {
    const Space v539_4_tail = child(s0,v539_4_label);
    if (v539_4_tail.empty()) continue;
    const Path v539_4_head{v539_4_label};
    const Space v540_2 = singleton(v539_4_head);
    const Space v540_3 = intersect(constant_9,v540_2);
    const Space v540_4 = (has_head(v540_3) ? constant_10 : Space{});
    const Path v540_5 = concat_path(p0,v539_4_head);
    const Path v540_6 = concat_path(v540_5,p1);
    const Space v540_7 = singleton(v540_6);
    const Space v540_8 = compose(v540_4,v540_7);
    v539_4_result = unite(v539_4_result,v540_8);
  }
  const Space v539_4 = std::move(v539_4_result);
  return v539_4;
}

static Space routine_50(Context& c, const Path& p0, const Space& s0) {
  Space v541_11_result;
  for (int v541_11_label = 1; v541_11_label <= 2; ++v541_11_label) {
    const Space v541_11_tail = child(s0,v541_11_label);
    if (v541_11_tail.empty()) continue;
    const Path v541_11_head{v541_11_label};
    const Space v542_2 = singleton(v541_11_head);
    const Space v542_3 = intersect(constant_9,v542_2);
    const Space v542_4 = (has_head(v542_3) ? constant_10 : Space{});
    const Space v542_5 = subtract(constant_0,v542_4);
    Space v542_8;
    if (!v542_5.empty()) {
      const Path v543_6 = concat_path(p0,v541_11_head);
      Space v543_7_result;
      for (int v543_7_label = 1; v543_7_label <= 2; ++v543_7_label) {
        const Space v543_7_tail = child(v541_11_tail,v543_7_label);
        if (v543_7_tail.empty()) continue;
        const Path v543_7_head{v543_7_label};
        const Space v544_2 = singleton(v543_7_head);
        const Space v544_3 = intersect(constant_9,v544_2);
        const Space v544_4 = (has_head(v544_3) ? constant_10 : Space{});
        const Space v544_5 = subtract(constant_0,v544_4);
        Space v544_8;
        if (!v544_5.empty()) {
          const Path v545_6 = concat_path(v543_6,v543_7_head);
          const Space v545_7 = routine_56(c, v545_6, v543_7_tail);
          v544_8 = compose(v544_5,v545_7);
        }
        const Space v544_9 = intersect(constant_9,v544_2);
        const Space v544_10 = (has_head(v544_9) ? constant_10 : Space{});
        Space v544_12;
        if (!v544_10.empty()) {
          const Path v546_6 = concat_path(v543_6,v543_7_head);
          const Space v546_11 = routine_57(c, v546_6, v543_7_tail);
          v544_12 = compose(v544_10,v546_11);
        }
        const Space v544_13 = unite(v544_8,v544_12);
        v543_7_result = unite(v543_7_result,v544_13);
      }
      const Space v543_7 = std::move(v543_7_result);
      v542_8 = compose(v542_5,v543_7);
    }
    const Space v542_9 = intersect(constant_9,v542_2);
    const Space v542_10 = (has_head(v542_9) ? constant_10 : Space{});
    Space v542_12;
    if (!v542_10.empty()) {
      const Path v547_6 = concat_path(p0,v541_11_head);
      Space v547_11_result;
      for (int v547_11_label = 1; v547_11_label <= 2; ++v547_11_label) {
        const Space v547_11_tail = child(v541_11_tail,v547_11_label);
        if (v547_11_tail.empty()) continue;
        const Path v547_11_head{v547_11_label};
        const Space v548_2 = singleton(v547_11_head);
        const Space v548_3 = intersect(constant_9,v548_2);
        const Space v548_4 = (has_head(v548_3) ? constant_10 : Space{});
        const Space v548_5 = subtract(constant_0,v548_4);
        Space v548_8;
        if (!v548_5.empty()) {
          const Path v549_6 = concat_path(v547_6,v547_11_head);
          const Space v549_7 = routine_56(c, v549_6, v547_11_tail);
          v548_8 = compose(v548_5,v549_7);
        }
        const Space v548_9 = intersect(constant_9,v548_2);
        const Space v548_10 = (has_head(v548_9) ? constant_10 : Space{});
        Space v548_12;
        if (!v548_10.empty()) {
          const Path v550_6 = concat_path(v547_6,v547_11_head);
          const Space v550_11 = routine_52(c, v550_6, v547_11_tail);
          v548_12 = compose(v548_10,v550_11);
        }
        const Space v548_13 = unite(v548_8,v548_12);
        v547_11_result = unite(v547_11_result,v548_13);
      }
      const Space v547_11 = std::move(v547_11_result);
      v542_12 = compose(v542_10,v547_11);
    }
    const Space v542_13 = unite(v542_8,v542_12);
    v541_11_result = unite(v541_11_result,v542_13);
  }
  const Space v541_11 = std::move(v541_11_result);
  return v541_11;
}

static Space routine_51(Context& c, const Path& p0, const Space& s0) {
  Space v551_8_result;
  for (int v551_8_label = 1; v551_8_label <= 2; ++v551_8_label) {
    const Space v551_8_tail = child(s0,v551_8_label);
    if (v551_8_tail.empty()) continue;
    const Path v551_8_head{v551_8_label};
    const Space v552_2 = singleton(v551_8_head);
    const Space v552_3 = intersect(constant_9,v552_2);
    const Space v552_4 = (has_head(v552_3) ? constant_10 : Space{});
    const Space v552_5 = subtract(constant_0,v552_4);
    Space v552_8;
    if (!v552_5.empty()) {
      const Path v553_6 = concat_path(p0,v551_8_head);
      Space v553_7_result;
      for (int v553_7_label = 1; v553_7_label <= 2; ++v553_7_label) {
        const Space v553_7_tail = child(v551_8_tail,v553_7_label);
        if (v553_7_tail.empty()) continue;
        const Path v553_7_head{v553_7_label};
        const Space v554_2 = singleton(v553_7_head);
        const Space v554_3 = intersect(constant_9,v554_2);
        const Space v554_4 = (has_head(v554_3) ? constant_10 : Space{});
        const Space v554_5 = subtract(constant_0,v554_4);
        Space v554_8;
        if (!v554_5.empty()) {
          const Path v555_6 = concat_path(v553_6,v553_7_head);
          const Space v555_7 = routine_56(c, v555_6, v553_7_tail);
          v554_8 = compose(v554_5,v555_7);
        }
        const Space v554_9 = intersect(constant_9,v554_2);
        const Space v554_10 = (has_head(v554_9) ? constant_10 : Space{});
        Space v554_12;
        if (!v554_10.empty()) {
          const Path v556_6 = concat_path(v553_6,v553_7_head);
          const Space v556_11 = routine_57(c, v556_6, v553_7_tail);
          v554_12 = compose(v554_10,v556_11);
        }
        const Space v554_13 = unite(v554_8,v554_12);
        v553_7_result = unite(v553_7_result,v554_13);
      }
      const Space v553_7 = std::move(v553_7_result);
      v552_8 = compose(v552_5,v553_7);
    }
    const Space v552_9 = intersect(constant_9,v552_2);
    const Space v552_10 = (has_head(v552_9) ? constant_10 : Space{});
    const Space v552_11 = compose(v552_10,v551_8_tail);
    const Space v552_12 = unite(v552_8,v552_11);
    v551_8_result = unite(v551_8_result,v552_12);
  }
  const Space v551_8 = std::move(v551_8_result);
  return v551_8;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_53(Context& c, const Space& s0) {
  const Space v558_1 = (has_head(s0) ? constant_10 : Space{});
  const Space v558_2 = first_matching(s0,constant_0,false);
  const Space v558_3 = unite(v558_1,v558_2);
  Space v558_19;
  if (!v558_3.empty()) {
    const Space v559_5 = intersect(constant_0,v558_2);
    const Space v559_6 = (has_head(v558_2) ? constant_10 : Space{});
    const Space v559_7 = unite(v559_5,v559_6);
    const Space v559_9 = compose(v559_7,constant_0);
    const Space v559_10 = subtract(s0,v559_9);
    const Space v559_12 = subtract(constant_0,v558_2);
    const Space v559_13 = subtract(v559_12,v559_6);
    Space v559_17;
    if (!v559_13.empty()) {
      const Space v560_15 = first_fibonacci(s0,6,5,true);
      const Space v560_16 = routine_45(c, constant_12, v560_15, s0);
      v559_17 = compose(v559_13,v560_16);
    }
    const Space v559_18 = subtract(v559_10,v559_17);
    v558_19 = compose(v558_3,v559_18);
  }
  return v558_19;
}

static Space routine_54(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v561_14_result;
  for (int v561_14_label = 1; v561_14_label <= 2; ++v561_14_label) {
    const Space v561_14_tail = child(s0,v561_14_label);
    if (v561_14_tail.empty()) continue;
    const Path v561_14_head{v561_14_label};
    const Space v562_2 = singleton(v561_14_head);
    const Space v562_3 = intersect(constant_9,v562_2);
    const Space v562_4 = (has_head(v562_3) ? constant_10 : Space{});
    const Space v562_5 = subtract(constant_0,v562_4);
    Space v562_8;
    if (!v562_5.empty()) {
      const Path v563_6 = concat_path(p0,v561_14_head);
      Space v563_7_result;
      for (int v563_7_label = 1; v563_7_label <= 2; ++v563_7_label) {
        const Space v563_7_tail = child(v561_14_tail,v563_7_label);
        if (v563_7_tail.empty()) continue;
        const Path v563_7_head{v563_7_label};
        const Space v564_2 = singleton(v563_7_head);
        const Space v564_3 = intersect(constant_9,v564_2);
        const Space v564_4 = (has_head(v564_3) ? constant_10 : Space{});
        const Space v564_5 = subtract(constant_0,v564_4);
        Space v564_8;
        if (!v564_5.empty()) {
          const Path v565_6 = concat_path(v563_6,v563_7_head);
          const Space v565_7 = routine_58(c, v565_6, v563_7_tail, s1, s2, s3);
          v564_8 = compose(v564_5,v565_7);
        }
        const Space v564_9 = intersect(constant_9,v564_2);
        const Space v564_10 = (has_head(v564_9) ? constant_10 : Space{});
        Space v564_12;
        if (!v564_10.empty()) {
          const Path v566_6 = concat_path(v563_6,v563_7_head);
          const Space v566_11 = routine_59(c, v566_6, v563_7_tail, s1, s2, s3);
          v564_12 = compose(v564_10,v566_11);
        }
        const Space v564_13 = unite(v564_8,v564_12);
        v563_7_result = unite(v563_7_result,v564_13);
      }
      const Space v563_7 = std::move(v563_7_result);
      v562_8 = compose(v562_5,v563_7);
    }
    const Space v562_9 = intersect(constant_9,v562_2);
    const Space v562_10 = (has_head(v562_9) ? constant_10 : Space{});
    Space v562_12;
    if (!v562_10.empty()) {
      const Path v567_6 = concat_path(p0,v561_14_head);
      Space v567_11_result;
      for (int v567_11_label = 1; v567_11_label <= 2; ++v567_11_label) {
        const Space v567_11_tail = child(v561_14_tail,v567_11_label);
        if (v567_11_tail.empty()) continue;
        const Path v567_11_head{v567_11_label};
        const Space v568_2 = singleton(v567_11_head);
        const Space v568_3 = intersect(constant_9,v568_2);
        const Space v568_4 = (has_head(v568_3) ? constant_10 : Space{});
        const Space v568_5 = subtract(constant_0,v568_4);
        Space v568_8;
        if (!v568_5.empty()) {
          const Path v569_6 = concat_path(v567_6,v567_11_head);
          const Space v569_7 = routine_58(c, v569_6, v567_11_tail, s1, s2, s3);
          v568_8 = compose(v568_5,v569_7);
        }
        const Space v568_9 = intersect(constant_9,v568_2);
        const Space v568_10 = (has_head(v568_9) ? constant_10 : Space{});
        Space v568_12;
        if (!v568_10.empty()) {
          const Path v570_6 = concat_path(v567_6,v567_11_head);
          const Space v570_11 = routine_37(c, v570_6, v567_11_tail, s1, s2, s3);
          v568_12 = compose(v568_10,v570_11);
        }
        const Space v568_13 = unite(v568_8,v568_12);
        v567_11_result = unite(v567_11_result,v568_13);
      }
      const Space v567_11 = std::move(v567_11_result);
      v562_12 = compose(v562_10,v567_11);
    }
    const Space v562_13 = unite(v562_8,v562_12);
    v561_14_result = unite(v561_14_result,v562_13);
  }
  const Space v561_14 = std::move(v561_14_result);
  return v561_14;
}

static Space routine_55(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v571_11_result;
  for (int v571_11_label = 1; v571_11_label <= 2; ++v571_11_label) {
    const Space v571_11_tail = child(s0,v571_11_label);
    if (v571_11_tail.empty()) continue;
    const Path v571_11_head{v571_11_label};
    const Space v572_2 = singleton(v571_11_head);
    const Space v572_3 = intersect(constant_9,v572_2);
    const Space v572_4 = (has_head(v572_3) ? constant_10 : Space{});
    const Space v572_5 = subtract(constant_0,v572_4);
    Space v572_8;
    if (!v572_5.empty()) {
      const Path v573_6 = concat_path(p0,v571_11_head);
      Space v573_7_result;
      for (int v573_7_label = 1; v573_7_label <= 2; ++v573_7_label) {
        const Space v573_7_tail = child(v571_11_tail,v573_7_label);
        if (v573_7_tail.empty()) continue;
        const Path v573_7_head{v573_7_label};
        const Space v574_2 = singleton(v573_7_head);
        const Space v574_3 = intersect(constant_9,v574_2);
        const Space v574_4 = (has_head(v574_3) ? constant_10 : Space{});
        const Space v574_5 = subtract(constant_0,v574_4);
        Space v574_8;
        if (!v574_5.empty()) {
          const Path v575_6 = concat_path(v573_6,v573_7_head);
          const Space v575_7 = routine_58(c, v575_6, v573_7_tail, s1, s2, s3);
          v574_8 = compose(v574_5,v575_7);
        }
        const Space v574_9 = intersect(constant_9,v574_2);
        const Space v574_10 = (has_head(v574_9) ? constant_10 : Space{});
        Space v574_12;
        if (!v574_10.empty()) {
          const Path v576_6 = concat_path(v573_6,v573_7_head);
          const Space v576_11 = routine_59(c, v576_6, v573_7_tail, s1, s2, s3);
          v574_12 = compose(v574_10,v576_11);
        }
        const Space v574_13 = unite(v574_8,v574_12);
        v573_7_result = unite(v573_7_result,v574_13);
      }
      const Space v573_7 = std::move(v573_7_result);
      v572_8 = compose(v572_5,v573_7);
    }
    const Space v572_9 = intersect(constant_9,v572_2);
    const Space v572_10 = (has_head(v572_9) ? constant_10 : Space{});
    Space v572_27;
    if (!v572_10.empty()) {
      const Path v577_6 = concat_path(p0,v571_11_head);
      const Space v577_11 = singleton(v577_6);
      const Space v577_12 = routine_38(c, s1, s3, v577_11);
      const Space v577_13 = routine_38(c, s2, s3, v577_11);
      const Space v577_14 = intersect(v577_12,v577_13);
      const Space v577_15 = subtract(v577_14,v577_11);
      const Space v577_16 = wrap(v577_15,v577_6);
      const Space v577_17 = subtract(s3,v577_13);
      const Space v577_18 = subtract(v577_17,v577_12);
      const Space v577_19 = routine_39(c, s2, s1, v577_18);
      const Space v577_20 = unite(v577_16,v577_19);
      const Space v577_21 = subtract(v577_12,v577_13);
      const Space v577_22 = routine_39(c, s2, s1, v577_21);
      const Space v577_23 = unite(v577_20,v577_22);
      const Space v577_24 = subtract(v577_13,v577_12);
      const Space v577_25 = routine_39(c, s2, s1, v577_24);
      const Space v577_26 = unite(v577_23,v577_25);
      v572_27 = compose(v572_10,v577_26);
    }
    const Space v572_28 = unite(v572_8,v572_27);
    v571_11_result = unite(v571_11_result,v572_28);
  }
  const Space v571_11 = std::move(v571_11_result);
  return v571_11;
}

static Space routine_56(Context& c, const Path& p0, const Space& s0) {
  Space v578_2_result;
  for (int v578_2_label = 1; v578_2_label <= 2; ++v578_2_label) {
    const Space v578_2_tail = child(s0,v578_2_label);
    if (v578_2_tail.empty()) continue;
    const Path v578_2_head{v578_2_label};
    const Space v579_2 = Space{};
    v578_2_result = unite(v578_2_result,v579_2);
  }
  const Space v578_2 = std::move(v578_2_result);
  return v578_2;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0) {
  Space v580_3_result;
  for (int v580_3_label = 1; v580_3_label <= 2; ++v580_3_label) {
    const Space v580_3_tail = child(s0,v580_3_label);
    if (v580_3_tail.empty()) continue;
    const Path v580_3_head{v580_3_label};
    const Space v581_2 = singleton(v580_3_head);
    const Space v581_3 = intersect(constant_9,v581_2);
    const Space v581_4 = (has_head(v581_3) ? constant_10 : Space{});
    const Space v581_5 = compose(v581_4,v580_3_tail);
    v580_3_result = unite(v580_3_result,v581_5);
  }
  const Space v580_3 = std::move(v580_3_result);
  return v580_3;
}

static Space routine_58(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v582_5_result;
  for (int v582_5_label = 1; v582_5_label <= 2; ++v582_5_label) {
    const Space v582_5_tail = child(s0,v582_5_label);
    if (v582_5_tail.empty()) continue;
    const Path v582_5_head{v582_5_label};
    const Space v583_2 = Space{};
    v582_5_result = unite(v582_5_result,v583_2);
  }
  const Space v582_5 = std::move(v582_5_result);
  return v582_5;
}

static Space routine_59(Context& c, const Path& p0, const Space& s0, const Space& s1, const Space& s2, const Space& s3) {
  Space v584_6_result;
  for (int v584_6_label = 1; v584_6_label <= 2; ++v584_6_label) {
    const Space v584_6_tail = child(s0,v584_6_label);
    if (v584_6_tail.empty()) continue;
    const Path v584_6_head{v584_6_label};
    const Space v585_2 = singleton(v584_6_head);
    const Space v585_3 = intersect(constant_9,v585_2);
    const Space v585_4 = (has_head(v585_3) ? constant_10 : Space{});
    Space v585_22;
    if (!v585_4.empty()) {
      const Path v586_5 = concat_path(p0,v584_6_head);
      const Space v586_6 = singleton(v586_5);
      const Space v586_7 = routine_38(c, s1, s3, v586_6);
      const Space v586_8 = routine_38(c, s2, s3, v586_6);
      const Space v586_9 = intersect(v586_7,v586_8);
      const Space v586_10 = subtract(v586_9,v586_6);
      const Space v586_11 = wrap(v586_10,v586_5);
      const Space v586_12 = subtract(s3,v586_8);
      const Space v586_13 = subtract(v586_12,v586_7);
      const Space v586_14 = routine_39(c, s2, s1, v586_13);
      const Space v586_15 = unite(v586_11,v586_14);
      const Space v586_16 = subtract(v586_7,v586_8);
      const Space v586_17 = routine_39(c, s2, s1, v586_16);
      const Space v586_18 = unite(v586_15,v586_17);
      const Space v586_19 = subtract(v586_8,v586_7);
      const Space v586_20 = routine_39(c, s2, s1, v586_19);
      const Space v586_21 = unite(v586_18,v586_20);
      v585_22 = compose(v585_4,v586_21);
    }
    v584_6_result = unite(v584_6_result,v585_22);
  }
  const Space v584_6 = std::move(v584_6_result);
  return v584_6;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
