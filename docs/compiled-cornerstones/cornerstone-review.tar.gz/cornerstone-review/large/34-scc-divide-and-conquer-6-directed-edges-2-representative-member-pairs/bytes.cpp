#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Space n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Path n11(Context&, const Env&);
static ZIPPY_NOINLINE Path n12(Context&, const Env&);
static ZIPPY_NOINLINE Path n13(Context&, const Env&);
static ZIPPY_NOINLINE Path n14(Context&, const Env&);
static ZIPPY_NOINLINE Path n15(Context&, const Env&);
static ZIPPY_NOINLINE Path n16(Context&, const Env&);
static ZIPPY_NOINLINE Path n17(Context&, const Env&);
static ZIPPY_NOINLINE Path n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n19(Context&, const Env&);
static ZIPPY_NOINLINE Space n20(Context&, const Env&);
static ZIPPY_NOINLINE Space n21(Context&, const Env&);
static ZIPPY_NOINLINE Space n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n23(Context&, const Env&);
static ZIPPY_NOINLINE Space n24(Context&, const Env&);
static ZIPPY_NOINLINE Space n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Space n29(Context&, const Env&);
static ZIPPY_NOINLINE Space n30(Context&, const Env&);
static ZIPPY_NOINLINE Path n31(Context&, const Env&);
static ZIPPY_NOINLINE Path n32(Context&, const Env&);
static ZIPPY_NOINLINE Path n33(Context&, const Env&);
static ZIPPY_NOINLINE Path n34(Context&, const Env&);
static ZIPPY_NOINLINE Path n35(Context&, const Env&);
static ZIPPY_NOINLINE Path n36(Context&, const Env&);
static ZIPPY_NOINLINE Path n37(Context&, const Env&);
static ZIPPY_NOINLINE Path n38(Context&, const Env&);
static ZIPPY_NOINLINE Space n39(Context&, const Env&);
static ZIPPY_NOINLINE Space n40(Context&, const Env&);
static ZIPPY_NOINLINE Space n41(Context&, const Env&);
static ZIPPY_NOINLINE Space n42(Context&, const Env&);
static ZIPPY_NOINLINE Space n43(Context&, const Env&);
static ZIPPY_NOINLINE Space n44(Context&, const Env&);
static ZIPPY_NOINLINE Space n45(Context&, const Env&);
static ZIPPY_NOINLINE Space n46(Context&, const Env&);
static ZIPPY_NOINLINE Space n47(Context&, const Env&);
static ZIPPY_NOINLINE Space n48(Context&, const Env&);
static ZIPPY_NOINLINE Space n49(Context&, const Env&);
static ZIPPY_NOINLINE Path n50(Context&, const Env&);
static ZIPPY_NOINLINE Path n51(Context&, const Env&);
static ZIPPY_NOINLINE Path n52(Context&, const Env&);
static ZIPPY_NOINLINE Path n53(Context&, const Env&);
static ZIPPY_NOINLINE Path n54(Context&, const Env&);
static ZIPPY_NOINLINE Path n55(Context&, const Env&);
static ZIPPY_NOINLINE Path n56(Context&, const Env&);
static ZIPPY_NOINLINE Path n57(Context&, const Env&);
static ZIPPY_NOINLINE Space n58(Context&, const Env&);
static ZIPPY_NOINLINE Space n59(Context&, const Env&);
static ZIPPY_NOINLINE Space n60(Context&, const Env&);
static ZIPPY_NOINLINE Space n61(Context&, const Env&);
static ZIPPY_NOINLINE Space n62(Context&, const Env&);
static ZIPPY_NOINLINE Space n63(Context&, const Env&);
static ZIPPY_NOINLINE Space n64(Context&, const Env&);
static ZIPPY_NOINLINE Space n65(Context&, const Env&);
static ZIPPY_NOINLINE Path n66(Context&, const Env&);
static ZIPPY_NOINLINE Path n67(Context&, const Env&);
static ZIPPY_NOINLINE Path n68(Context&, const Env&);
static ZIPPY_NOINLINE Path n69(Context&, const Env&);
static ZIPPY_NOINLINE Path n70(Context&, const Env&);
static ZIPPY_NOINLINE Path n71(Context&, const Env&);
static ZIPPY_NOINLINE Path n72(Context&, const Env&);
static ZIPPY_NOINLINE Path n73(Context&, const Env&);
static ZIPPY_NOINLINE Space n74(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_16(Context&, const Env&);
static ZIPPY_NOINLINE Space n75(Context&, const Env&);
static ZIPPY_NOINLINE Space n76(Context&, const Env&);
static ZIPPY_NOINLINE Space n77(Context&, const Env&);
static ZIPPY_NOINLINE Space n78(Context&, const Env&);
static ZIPPY_NOINLINE Space n79(Context&, const Env&);
static ZIPPY_NOINLINE Space n80(Context&, const Env&);
static ZIPPY_NOINLINE Space n81(Context&, const Env&);
static ZIPPY_NOINLINE Space n82(Context&, const Env&);
static ZIPPY_NOINLINE Space n83(Context&, const Env&);
static ZIPPY_NOINLINE Space n84(Context&, const Env&);
static ZIPPY_NOINLINE Path n85(Context&, const Env&);
static ZIPPY_NOINLINE Path n86(Context&, const Env&);
static ZIPPY_NOINLINE Path n87(Context&, const Env&);
static ZIPPY_NOINLINE Path n88(Context&, const Env&);
static ZIPPY_NOINLINE Path n89(Context&, const Env&);
static ZIPPY_NOINLINE Path n90(Context&, const Env&);
static ZIPPY_NOINLINE Path n91(Context&, const Env&);
static ZIPPY_NOINLINE Path n92(Context&, const Env&);
static ZIPPY_NOINLINE Space n93(Context&, const Env&);
static ZIPPY_NOINLINE Space n94(Context&, const Env&);
static ZIPPY_NOINLINE Space n95(Context&, const Env&);
static ZIPPY_NOINLINE Space n96(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_13(Context&, const Env&);
static ZIPPY_NOINLINE Space n97(Context&, const Env&);
static ZIPPY_NOINLINE Space n98(Context&, const Env&);
static ZIPPY_NOINLINE Space n99(Context&, const Env&);
static ZIPPY_NOINLINE Space n100(Context&, const Env&);
static ZIPPY_NOINLINE Space n101(Context&, const Env&);
static ZIPPY_NOINLINE Space n102(Context&, const Env&);
static ZIPPY_NOINLINE Space n103(Context&, const Env&);
static ZIPPY_NOINLINE Space n104(Context&, const Env&);
static ZIPPY_NOINLINE Space n105(Context&, const Env&);
static ZIPPY_NOINLINE Path n106(Context&, const Env&);
static ZIPPY_NOINLINE Path n107(Context&, const Env&);
static ZIPPY_NOINLINE Path n108(Context&, const Env&);
static ZIPPY_NOINLINE Path n109(Context&, const Env&);
static ZIPPY_NOINLINE Path n110(Context&, const Env&);
static ZIPPY_NOINLINE Path n111(Context&, const Env&);
static ZIPPY_NOINLINE Path n112(Context&, const Env&);
static ZIPPY_NOINLINE Path n113(Context&, const Env&);
static ZIPPY_NOINLINE Path n114(Context&, const Env&);
static ZIPPY_NOINLINE Space n115(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_14(Context&, const Env&);
static ZIPPY_NOINLINE Space n116(Context&, const Env&);
static ZIPPY_NOINLINE Path n117(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_7(Context&, const Env&);
static ZIPPY_NOINLINE Space n118(Context&, const Env&);
static ZIPPY_NOINLINE Space n119(Context&, const Env&);
static ZIPPY_NOINLINE Space n120(Context&, const Env&);
static ZIPPY_NOINLINE Space n121(Context&, const Env&);
static ZIPPY_NOINLINE Space n122(Context&, const Env&);
static ZIPPY_NOINLINE Space n123(Context&, const Env&);
static ZIPPY_NOINLINE Space n124(Context&, const Env&);
static ZIPPY_NOINLINE Space n125(Context&, const Env&);
static ZIPPY_NOINLINE Space n126(Context&, const Env&);
static ZIPPY_NOINLINE Path n127(Context&, const Env&);
static ZIPPY_NOINLINE Path n128(Context&, const Env&);
static ZIPPY_NOINLINE Path n129(Context&, const Env&);
static ZIPPY_NOINLINE Path n130(Context&, const Env&);
static ZIPPY_NOINLINE Path n131(Context&, const Env&);
static ZIPPY_NOINLINE Path n132(Context&, const Env&);
static ZIPPY_NOINLINE Path n133(Context&, const Env&);
static ZIPPY_NOINLINE Path n134(Context&, const Env&);
static ZIPPY_NOINLINE Path n135(Context&, const Env&);
static ZIPPY_NOINLINE Space n136(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_8(Context&, const Env&);
static ZIPPY_NOINLINE Space n137(Context&, const Env&);
static ZIPPY_NOINLINE Path n138(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_4(Context&, const Env&);
static ZIPPY_NOINLINE Space n139(Context&, const Env&);
static ZIPPY_NOINLINE Space n140(Context&, const Env&);
static ZIPPY_NOINLINE Space n141(Context&, const Env&);
static ZIPPY_NOINLINE Space n142(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_11(Context&, const Env&);
static ZIPPY_NOINLINE Space n143(Context&, const Env&);
static ZIPPY_NOINLINE Space n144(Context&, const Env&);
static ZIPPY_NOINLINE Space n145(Context&, const Env&);
static ZIPPY_NOINLINE Space n146(Context&, const Env&);
static ZIPPY_NOINLINE Path n147(Context&, const Env&);
static ZIPPY_NOINLINE Space n148(Context&, const Env&);
static ZIPPY_NOINLINE Space n149(Context&, const Env&);
static ZIPPY_NOINLINE Space n150(Context&, const Env&);
static ZIPPY_NOINLINE Space n151(Context&, const Env&);
static ZIPPY_NOINLINE Space n152(Context&, const Env&);
static ZIPPY_NOINLINE Space n153(Context&, const Env&);
static ZIPPY_NOINLINE Path n154(Context&, const Env&);
static ZIPPY_NOINLINE Space n155(Context&, const Env&);
static ZIPPY_NOINLINE Space n156(Context&, const Env&);
static ZIPPY_NOINLINE Space n157(Context&, const Env&);
static ZIPPY_NOINLINE Space n158(Context&, const Env&);
static ZIPPY_NOINLINE Path n159(Context&, const Env&);
static ZIPPY_NOINLINE Space n160(Context&, const Env&);
static ZIPPY_NOINLINE Path n161(Context&, const Env&);
static ZIPPY_NOINLINE Space n162(Context&, const Env&);
static ZIPPY_NOINLINE Space n163(Context&, const Env&);
static ZIPPY_NOINLINE Space n164(Context&, const Env&);
static ZIPPY_NOINLINE Space n165(Context&, const Env&);
static ZIPPY_NOINLINE Space n166(Context&, const Env&);
static ZIPPY_NOINLINE Space n167(Context&, const Env&);
static ZIPPY_NOINLINE Space n168(Context&, const Env&);
static ZIPPY_NOINLINE Space n169(Context&, const Env&);
static ZIPPY_NOINLINE Path n170(Context&, const Env&);
static ZIPPY_NOINLINE Space n171(Context&, const Env&);
static ZIPPY_NOINLINE Space n172(Context&, const Env&);
static ZIPPY_NOINLINE Space n173(Context&, const Env&);
static ZIPPY_NOINLINE Space n174(Context&, const Env&);
static ZIPPY_NOINLINE Path n175(Context&, const Env&);
static ZIPPY_NOINLINE Space n176(Context&, const Env&);
static ZIPPY_NOINLINE Space n177(Context&, const Env&);
static ZIPPY_NOINLINE Space n178(Context&, const Env&);
static ZIPPY_NOINLINE Space n179(Context&, const Env&);
static ZIPPY_NOINLINE Space n180(Context&, const Env&);
static ZIPPY_NOINLINE Space n181(Context&, const Env&);
static ZIPPY_NOINLINE Space n182(Context&, const Env&);
static ZIPPY_NOINLINE Space n183(Context&, const Env&);
static ZIPPY_NOINLINE Path n184(Context&, const Env&);
static ZIPPY_NOINLINE Space n185(Context&, const Env&);
static ZIPPY_NOINLINE Space n186(Context&, const Env&);
static ZIPPY_NOINLINE Space n187(Context&, const Env&);
static ZIPPY_NOINLINE Space n188(Context&, const Env&);
static ZIPPY_NOINLINE Path n189(Context&, const Env&);
static ZIPPY_NOINLINE Space n190(Context&, const Env&);
static ZIPPY_NOINLINE Space n191(Context&, const Env&);
static ZIPPY_NOINLINE Space n192(Context&, const Env&);
static ZIPPY_NOINLINE Space n193(Context&, const Env&);
static ZIPPY_NOINLINE Space n194(Context&, const Env&);
static ZIPPY_NOINLINE Space n195(Context&, const Env&);
static ZIPPY_NOINLINE Space n196(Context&, const Env&);
static ZIPPY_NOINLINE Space n197(Context&, const Env&);
static ZIPPY_NOINLINE Space n198(Context&, const Env&);
static ZIPPY_NOINLINE Space n199(Context&, const Env&);
static ZIPPY_NOINLINE Path n200(Context&, const Env&);
static ZIPPY_NOINLINE Space n201(Context&, const Env&);
static ZIPPY_NOINLINE Space n202(Context&, const Env&);
static ZIPPY_NOINLINE Space n203(Context&, const Env&);
static ZIPPY_NOINLINE Space n204(Context&, const Env&);
static ZIPPY_NOINLINE Path n205(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_12(Context&, const Env&);
static ZIPPY_NOINLINE Space n206(Context&, const Env&);
static ZIPPY_NOINLINE Path n207(Context&, const Env&);
static ZIPPY_NOINLINE Path n208(Context&, const Env&);
static ZIPPY_NOINLINE Path n209(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_6(Context&, const Env&);
static ZIPPY_NOINLINE Space n210(Context&, const Env&);
static ZIPPY_NOINLINE Path n211(Context&, const Env&);
static ZIPPY_NOINLINE Path n212(Context&, const Env&);
static ZIPPY_NOINLINE Path n213(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_1(Context&, const Env&);
static ZIPPY_NOINLINE Space n214(Context&, const Env&);
static ZIPPY_NOINLINE Space n215(Context&, const Env&);
static ZIPPY_NOINLINE Space n216(Context&, const Env&);
static ZIPPY_NOINLINE Space n217(Context&, const Env&);
static ZIPPY_NOINLINE Space n218(Context&, const Env&);
static ZIPPY_NOINLINE Space n219(Context&, const Env&);
static ZIPPY_NOINLINE Space n220(Context&, const Env&);
static ZIPPY_NOINLINE Space n221(Context&, const Env&);
static ZIPPY_NOINLINE Space n222(Context&, const Env&);
static ZIPPY_NOINLINE Space n223(Context&, const Env&);
static ZIPPY_NOINLINE Space n224(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_15(Context&, const Env&);
static ZIPPY_NOINLINE Space n225(Context&, const Env&);
static ZIPPY_NOINLINE Space n226(Context&, const Env&);
static ZIPPY_NOINLINE Space n227(Context&, const Env&);
static ZIPPY_NOINLINE Space n228(Context&, const Env&);
static ZIPPY_NOINLINE Space n229(Context&, const Env&);
static ZIPPY_NOINLINE Space n230(Context&, const Env&);
static ZIPPY_NOINLINE Space n231(Context&, const Env&);
static ZIPPY_NOINLINE Space n232(Context&, const Env&);
static ZIPPY_NOINLINE Space n233(Context&, const Env&);
static ZIPPY_NOINLINE Space n234(Context&, const Env&);
static ZIPPY_NOINLINE Space n235(Context&, const Env&);
static ZIPPY_NOINLINE Space n236(Context&, const Env&);
static ZIPPY_NOINLINE Space n237(Context&, const Env&);
static ZIPPY_NOINLINE Space n238(Context&, const Env&);
static ZIPPY_NOINLINE Space n239(Context&, const Env&);
static ZIPPY_NOINLINE Space n240(Context&, const Env&);
static ZIPPY_NOINLINE Space n241(Context&, const Env&);
static ZIPPY_NOINLINE Space n242(Context&, const Env&);
static ZIPPY_NOINLINE Space n243(Context&, const Env&);
static ZIPPY_NOINLINE Space n244(Context&, const Env&);
static ZIPPY_NOINLINE Space n245(Context&, const Env&);
static ZIPPY_NOINLINE Path n246(Context&, const Env&);
static ZIPPY_NOINLINE Path n247(Context&, const Env&);
static ZIPPY_NOINLINE Path n248(Context&, const Env&);
static ZIPPY_NOINLINE Path n249(Context&, const Env&);
static ZIPPY_NOINLINE Path n250(Context&, const Env&);
static ZIPPY_NOINLINE Path n251(Context&, const Env&);
static ZIPPY_NOINLINE Path n252(Context&, const Env&);
static ZIPPY_NOINLINE Path n253(Context&, const Env&);
static ZIPPY_NOINLINE Space n254(Context&, const Env&);
static ZIPPY_NOINLINE Space n255(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_2(Context&, const Env&);
static ZIPPY_NOINLINE Space n256(Context&, const Env&);
static ZIPPY_NOINLINE Space n257(Context&, const Env&);
static ZIPPY_NOINLINE Space n258(Context&, const Env&);
static ZIPPY_NOINLINE Space n259(Context&, const Env&);
static ZIPPY_NOINLINE Space n260(Context&, const Env&);
static ZIPPY_NOINLINE Space n261(Context&, const Env&);
static ZIPPY_NOINLINE Space n262(Context&, const Env&);
static ZIPPY_NOINLINE Space n263(Context&, const Env&);
static ZIPPY_NOINLINE Space n264(Context&, const Env&);
static ZIPPY_NOINLINE Space n265(Context&, const Env&);
static ZIPPY_NOINLINE Space n266(Context&, const Env&);
static ZIPPY_NOINLINE Space n267(Context&, const Env&);
static ZIPPY_NOINLINE Space n268(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_9(Context&, const Env&);
static ZIPPY_NOINLINE Space n269(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n270(Context&, const Env&);
static ZIPPY_NOINLINE Space n271(Context&, const Env&);
static ZIPPY_NOINLINE Space n272(Context&, const Env&);
static ZIPPY_NOINLINE Space n273(Context&, const Env&);
static ZIPPY_NOINLINE Space n274(Context&, const Env&);
static ZIPPY_NOINLINE Path n275(Context&, const Env&);
static ZIPPY_NOINLINE Space n276(Context&, const Env&);
static ZIPPY_NOINLINE Space n277(Context&, const Env&);
static ZIPPY_NOINLINE Space n278(Context&, const Env&);
static ZIPPY_NOINLINE Space n279(Context&, const Env&);
static ZIPPY_NOINLINE Path n280(Context&, const Env&);
static ZIPPY_NOINLINE Path n281(Context&, const Env&);
static ZIPPY_NOINLINE Path n282(Context&, const Env&);
static ZIPPY_NOINLINE Space n283(Context&, const Env&);
static ZIPPY_NOINLINE Space n284(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_5(Context&, const Env&);
static ZIPPY_NOINLINE Space n285(Context&, const Env&);
static ZIPPY_NOINLINE Path n286(Context&, const Env&);
static ZIPPY_NOINLINE Space n287(Context&, const Env&);
static ZIPPY_NOINLINE Space n288(Context&, const Env&);
static ZIPPY_NOINLINE Path n289(Context&, const Env&);
static ZIPPY_NOINLINE Space n290(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { static const Space value=literal_text("6 8 1 1 1 1 1 1 1 2 8 1 1 1 2 1 1 1 1 8 1 1 1 2 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 4 1 1 1 3 8 1 1 1 5 1 1 1 6"); return value; }
static ZIPPY_NOINLINE Space n3(Context& c, const Env& e) { static const Space value=literal_text("6 8 1 1 1 1 1 1 1 2 8 1 1 1 2 1 1 1 1 8 1 1 1 2 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 4 1 1 1 3 8 1 1 1 5 1 1 1 6"); return value; }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Path n15(Context& c, const Env& e) { return Path{}; }
static ZIPPY_NOINLINE Path n16(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n14(Context& c, const Env& e) { auto a=n15(c,e); auto b=n16(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n17(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n13(Context& c, const Env& e) { auto a=n14(c,e); auto b=n17(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n18(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n12(Context& c, const Env& e) { auto a=n13(c,e); auto b=n18(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n19(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Path n11(Context& c, const Env& e) { auto a=n12(c,e); auto b=n19(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n20(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { std::vector<Path> pv{n11(c,e)}; std::vector<Space> sv{n20(c,e)}; Env n; n.paths[4]=pv[0];n.spaces[4]=sv[0];  return routine_13(c,n); }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { return iterate(c,e,n9(c,e),3,3,n10); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { return iterate(c,e,n7(c,e),2,2,n8); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { return iterate(c,e,n5(c,e),1,1,n6); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { return iterate(c,e,n3(c,e),0,0,n4); }
static ZIPPY_NOINLINE Space n23(Context& c, const Env& e) { static const Space value=literal_text("6 8 1 1 1 1 1 1 1 2 8 1 1 1 2 1 1 1 1 8 1 1 1 2 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 4 1 1 1 3 8 1 1 1 5 1 1 1 6"); return value; }
static ZIPPY_NOINLINE Space n25(Context& c, const Env& e) { return e.spaces.at(5); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n29(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Path n35(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Path n34(Context& c, const Env& e) { auto a=n15(c,e); auto b=n35(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n36(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Path n33(Context& c, const Env& e) { auto a=n34(c,e); auto b=n36(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n37(Context& c, const Env& e) { return e.paths.at(7); }
static ZIPPY_NOINLINE Path n32(Context& c, const Env& e) { auto a=n33(c,e); auto b=n37(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n38(Context& c, const Env& e) { return e.paths.at(8); }
static ZIPPY_NOINLINE Path n31(Context& c, const Env& e) { auto a=n32(c,e); auto b=n38(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n39(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n30(Context& c, const Env& e) { std::vector<Path> pv{n31(c,e)}; std::vector<Space> sv{n39(c,e)}; Env n; n.paths[9]=pv[0];n.spaces[9]=sv[0];  return routine_14(c,n); }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { return iterate(c,e,n29(c,e),8,8,n30); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { return iterate(c,e,n27(c,e),7,7,n28); }
static ZIPPY_NOINLINE Space n24(Context& c, const Env& e) { return iterate(c,e,n25(c,e),6,6,n26); }
static ZIPPY_NOINLINE Space n22(Context& c, const Env& e) { return iterate(c,e,n23(c,e),5,5,n24); }
static ZIPPY_NOINLINE Space n42(Context& c, const Env& e) { static const Space value=literal_text("6 8 1 1 1 1 1 1 1 2 8 1 1 1 2 1 1 1 1 8 1 1 1 2 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 4 1 1 1 3 8 1 1 1 5 1 1 1 6"); return value; }
static ZIPPY_NOINLINE Space n44(Context& c, const Env& e) { return e.spaces.at(10); }
static ZIPPY_NOINLINE Space n46(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Space n48(Context& c, const Env& e) { return e.spaces.at(12); }
static ZIPPY_NOINLINE Path n54(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n53(Context& c, const Env& e) { auto a=n15(c,e); auto b=n54(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n55(Context& c, const Env& e) { return e.paths.at(11); }
static ZIPPY_NOINLINE Path n52(Context& c, const Env& e) { auto a=n53(c,e); auto b=n55(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n56(Context& c, const Env& e) { return e.paths.at(12); }
static ZIPPY_NOINLINE Path n51(Context& c, const Env& e) { auto a=n52(c,e); auto b=n56(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n57(Context& c, const Env& e) { return e.paths.at(13); }
static ZIPPY_NOINLINE Path n50(Context& c, const Env& e) { auto a=n51(c,e); auto b=n57(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n58(Context& c, const Env& e) { return e.spaces.at(13); }
static ZIPPY_NOINLINE Space n49(Context& c, const Env& e) { std::vector<Path> pv{n50(c,e)}; std::vector<Space> sv{n58(c,e)}; Env n; n.paths[14]=pv[0];n.spaces[14]=sv[0];  return routine_7(c,n); }
static ZIPPY_NOINLINE Space n47(Context& c, const Env& e) { return iterate(c,e,n48(c,e),13,13,n49); }
static ZIPPY_NOINLINE Space n45(Context& c, const Env& e) { return iterate(c,e,n46(c,e),12,12,n47); }
static ZIPPY_NOINLINE Space n43(Context& c, const Env& e) { return iterate(c,e,n44(c,e),11,11,n45); }
static ZIPPY_NOINLINE Space n41(Context& c, const Env& e) { return iterate(c,e,n42(c,e),10,10,n43); }
static ZIPPY_NOINLINE Space n60(Context& c, const Env& e) { return e.spaces.at(15); }
static ZIPPY_NOINLINE Space n62(Context& c, const Env& e) { return e.spaces.at(16); }
static ZIPPY_NOINLINE Space n64(Context& c, const Env& e) { return e.spaces.at(17); }
static ZIPPY_NOINLINE Path n70(Context& c, const Env& e) { return e.paths.at(15); }
static ZIPPY_NOINLINE Path n69(Context& c, const Env& e) { auto a=n15(c,e); auto b=n70(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n71(Context& c, const Env& e) { return e.paths.at(16); }
static ZIPPY_NOINLINE Path n68(Context& c, const Env& e) { auto a=n69(c,e); auto b=n71(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n72(Context& c, const Env& e) { return e.paths.at(17); }
static ZIPPY_NOINLINE Path n67(Context& c, const Env& e) { auto a=n68(c,e); auto b=n72(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n73(Context& c, const Env& e) { return e.paths.at(18); }
static ZIPPY_NOINLINE Path n66(Context& c, const Env& e) { auto a=n67(c,e); auto b=n73(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n74(Context& c, const Env& e) { return e.spaces.at(18); }
static ZIPPY_NOINLINE Space n65(Context& c, const Env& e) { std::vector<Path> pv{n66(c,e)}; std::vector<Space> sv{n74(c,e)}; Env n; n.paths[19]=pv[0];n.spaces[19]=sv[0];  return routine_8(c,n); }
static ZIPPY_NOINLINE Space n63(Context& c, const Env& e) { return iterate(c,e,n64(c,e),18,18,n65); }
static ZIPPY_NOINLINE Space n61(Context& c, const Env& e) { return iterate(c,e,n62(c,e),17,17,n63); }
static ZIPPY_NOINLINE Space n59(Context& c, const Env& e) { return iterate(c,e,n60(c,e),16,16,n61); }
static ZIPPY_NOINLINE Space n40(Context& c, const Env& e) { return iterate(c,e,n41(c,e),15,15,n59); }
static ZIPPY_NOINLINE Space n21(Context& c, const Env& e) { auto a=n22(c,e); auto b=n40(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n1(c,e),n2(c,e),n21(c,e)}; Env n; n.spaces[20]=sv[0];n.spaces[21]=sv[1];n.spaces[22]=sv[2];  return routine_16(c,n); }
static ZIPPY_NOINLINE Space n77(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Space n76(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n77(c,e)}; Env n; n.spaces[23]=sv[0];  return routine_4(c,n); }
static ZIPPY_NOINLINE Space n79(Context& c, const Env& e) { return e.spaces.at(24); }
static ZIPPY_NOINLINE Space n81(Context& c, const Env& e) { return e.spaces.at(25); }
static ZIPPY_NOINLINE Space n83(Context& c, const Env& e) { return e.spaces.at(26); }
static ZIPPY_NOINLINE Path n89(Context& c, const Env& e) { return e.paths.at(20); }
static ZIPPY_NOINLINE Path n88(Context& c, const Env& e) { auto a=n15(c,e); auto b=n89(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n90(Context& c, const Env& e) { return e.paths.at(21); }
static ZIPPY_NOINLINE Path n87(Context& c, const Env& e) { auto a=n88(c,e); auto b=n90(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n91(Context& c, const Env& e) { return e.paths.at(22); }
static ZIPPY_NOINLINE Path n86(Context& c, const Env& e) { auto a=n87(c,e); auto b=n91(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n92(Context& c, const Env& e) { return e.paths.at(23); }
static ZIPPY_NOINLINE Path n85(Context& c, const Env& e) { auto a=n86(c,e); auto b=n92(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n93(Context& c, const Env& e) { return e.spaces.at(27); }
static ZIPPY_NOINLINE Space n94(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n95(Context& c, const Env& e) { return e.spaces.at(20); }
static ZIPPY_NOINLINE Space n96(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Space n84(Context& c, const Env& e) { std::vector<Path> pv{n85(c,e)}; std::vector<Space> sv{n93(c,e),n94(c,e),n95(c,e),n96(c,e)}; Env n; n.paths[24]=pv[0];n.spaces[28]=sv[0];n.spaces[21]=sv[1];n.spaces[20]=sv[2];n.spaces[22]=sv[3];  return routine_11(c,n); }
static ZIPPY_NOINLINE Space n82(Context& c, const Env& e) { return iterate(c,e,n83(c,e),23,27,n84); }
static ZIPPY_NOINLINE Space n80(Context& c, const Env& e) { return iterate(c,e,n81(c,e),22,26,n82); }
static ZIPPY_NOINLINE Space n78(Context& c, const Env& e) { return iterate(c,e,n79(c,e),21,25,n80); }
static ZIPPY_NOINLINE Space n75(Context& c, const Env& e) { return iterate(c,e,n76(c,e),20,24,n78); }
static ZIPPY_NOINLINE Space routine_16(Context& c,const Env& e) { return n75(c,e); }
static ZIPPY_NOINLINE Space n98(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Space n100(Context& c, const Env& e) { return e.spaces.at(29); }
static ZIPPY_NOINLINE Space n102(Context& c, const Env& e) { return e.spaces.at(30); }
static ZIPPY_NOINLINE Space n104(Context& c, const Env& e) { return e.spaces.at(31); }
static ZIPPY_NOINLINE Path n110(Context& c, const Env& e) { return e.paths.at(25); }
static ZIPPY_NOINLINE Path n109(Context& c, const Env& e) { auto a=n15(c,e); auto b=n110(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n111(Context& c, const Env& e) { return e.paths.at(26); }
static ZIPPY_NOINLINE Path n108(Context& c, const Env& e) { auto a=n109(c,e); auto b=n111(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n112(Context& c, const Env& e) { return e.paths.at(27); }
static ZIPPY_NOINLINE Path n107(Context& c, const Env& e) { auto a=n108(c,e); auto b=n112(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n113(Context& c, const Env& e) { return e.paths.at(28); }
static ZIPPY_NOINLINE Path n106(Context& c, const Env& e) { auto a=n107(c,e); auto b=n113(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n114(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n115(Context& c, const Env& e) { return e.spaces.at(32); }
static ZIPPY_NOINLINE Space n105(Context& c, const Env& e) { std::vector<Path> pv{n106(c,e),n114(c,e)}; std::vector<Space> sv{n115(c,e)}; Env n; n.paths[29]=pv[0];n.paths[4]=pv[1];n.spaces[33]=sv[0];  return routine_12(c,n); }
static ZIPPY_NOINLINE Space n103(Context& c, const Env& e) { return iterate(c,e,n104(c,e),28,32,n105); }
static ZIPPY_NOINLINE Space n101(Context& c, const Env& e) { return iterate(c,e,n102(c,e),27,31,n103); }
static ZIPPY_NOINLINE Space n99(Context& c, const Env& e) { return iterate(c,e,n100(c,e),26,30,n101); }
static ZIPPY_NOINLINE Space n97(Context& c, const Env& e) { return iterate(c,e,n98(c,e),25,29,n99); }
static ZIPPY_NOINLINE Space routine_13(Context& c,const Env& e) { return n97(c,e); }
static ZIPPY_NOINLINE Path n117(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Space n116(Context& c, const Env& e) { return singleton(n117(c,e)); }
static ZIPPY_NOINLINE Space routine_14(Context& c,const Env& e) { return n116(c,e); }
static ZIPPY_NOINLINE Space n119(Context& c, const Env& e) { return e.spaces.at(14); }
static ZIPPY_NOINLINE Space n121(Context& c, const Env& e) { return e.spaces.at(34); }
static ZIPPY_NOINLINE Space n123(Context& c, const Env& e) { return e.spaces.at(35); }
static ZIPPY_NOINLINE Space n125(Context& c, const Env& e) { return e.spaces.at(36); }
static ZIPPY_NOINLINE Path n131(Context& c, const Env& e) { return e.paths.at(30); }
static ZIPPY_NOINLINE Path n130(Context& c, const Env& e) { auto a=n15(c,e); auto b=n131(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n132(Context& c, const Env& e) { return e.paths.at(31); }
static ZIPPY_NOINLINE Path n129(Context& c, const Env& e) { auto a=n130(c,e); auto b=n132(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n133(Context& c, const Env& e) { return e.paths.at(32); }
static ZIPPY_NOINLINE Path n128(Context& c, const Env& e) { auto a=n129(c,e); auto b=n133(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n134(Context& c, const Env& e) { return e.paths.at(33); }
static ZIPPY_NOINLINE Path n127(Context& c, const Env& e) { auto a=n128(c,e); auto b=n134(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n135(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Space n136(Context& c, const Env& e) { return e.spaces.at(37); }
static ZIPPY_NOINLINE Space n126(Context& c, const Env& e) { std::vector<Path> pv{n127(c,e),n135(c,e)}; std::vector<Space> sv{n136(c,e)}; Env n; n.paths[34]=pv[0];n.paths[14]=pv[1];n.spaces[38]=sv[0];  return routine_6(c,n); }
static ZIPPY_NOINLINE Space n124(Context& c, const Env& e) { return iterate(c,e,n125(c,e),33,37,n126); }
static ZIPPY_NOINLINE Space n122(Context& c, const Env& e) { return iterate(c,e,n123(c,e),32,36,n124); }
static ZIPPY_NOINLINE Space n120(Context& c, const Env& e) { return iterate(c,e,n121(c,e),31,35,n122); }
static ZIPPY_NOINLINE Space n118(Context& c, const Env& e) { return iterate(c,e,n119(c,e),30,34,n120); }
static ZIPPY_NOINLINE Space routine_7(Context& c,const Env& e) { return n118(c,e); }
static ZIPPY_NOINLINE Path n138(Context& c, const Env& e) { return e.paths.at(19); }
static ZIPPY_NOINLINE Space n137(Context& c, const Env& e) { return singleton(n138(c,e)); }
static ZIPPY_NOINLINE Space routine_8(Context& c,const Env& e) { return n137(c,e); }
static ZIPPY_NOINLINE Space n140(Context& c, const Env& e) { return e.spaces.at(23); }
static ZIPPY_NOINLINE Space n142(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n140(c,e)}; Env n; n.spaces[39]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n141(Context& c, const Env& e) { auto a=n140(c,e); auto b=n142(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n139(Context& c, const Env& e) { auto a=n140(c,e); auto b=n141(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space routine_4(Context& c,const Env& e) { return n139(c,e); }
static ZIPPY_NOINLINE Path n147(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n151(Context& c, const Env& e) { return e.spaces.at(20); }
static ZIPPY_NOINLINE Space n152(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Path n154(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n153(Context& c, const Env& e) { return singleton(n154(c,e)); }
static ZIPPY_NOINLINE Space n150(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n151(c,e),n152(c,e),n153(c,e)}; Env n; n.spaces[40]=sv[0];n.spaces[41]=sv[1];n.spaces[42]=sv[2];  return routine_15(c,n); }
static ZIPPY_NOINLINE Space n156(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n157(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Path n159(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n158(Context& c, const Env& e) { return singleton(n159(c,e)); }
static ZIPPY_NOINLINE Space n155(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n156(c,e),n157(c,e),n158(c,e)}; Env n; n.spaces[40]=sv[0];n.spaces[41]=sv[1];n.spaces[42]=sv[2];  return routine_15(c,n); }
static ZIPPY_NOINLINE Space n149(Context& c, const Env& e) { auto a=n150(c,e); auto b=n155(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Path n161(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n160(Context& c, const Env& e) { return singleton(n161(c,e)); }
static ZIPPY_NOINLINE Space n148(Context& c, const Env& e) { auto a=n149(c,e); auto b=n160(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n146(Context& c, const Env& e) { auto p=n147(c,e); return wrap(n148(c,e),p); }
static ZIPPY_NOINLINE Space n163(Context& c, const Env& e) { return e.spaces.at(20); }
static ZIPPY_NOINLINE Space n164(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n167(Context& c, const Env& e) { return e.spaces.at(20); }
static ZIPPY_NOINLINE Space n168(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Path n170(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n169(Context& c, const Env& e) { return singleton(n170(c,e)); }
static ZIPPY_NOINLINE Space n166(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n167(c,e),n168(c,e),n169(c,e)}; Env n; n.spaces[40]=sv[0];n.spaces[41]=sv[1];n.spaces[42]=sv[2];  return routine_15(c,n); }
static ZIPPY_NOINLINE Space n172(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n173(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Path n175(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n174(Context& c, const Env& e) { return singleton(n175(c,e)); }
static ZIPPY_NOINLINE Space n171(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n172(c,e),n173(c,e),n174(c,e)}; Env n; n.spaces[40]=sv[0];n.spaces[41]=sv[1];n.spaces[42]=sv[2];  return routine_15(c,n); }
static ZIPPY_NOINLINE Space n165(Context& c, const Env& e) { auto a=n166(c,e); auto b=n171(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n162(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n163(c,e),n164(c,e),n165(c,e)}; Env n; n.spaces[20]=sv[0];n.spaces[21]=sv[1];n.spaces[22]=sv[2];  return routine_16(c,n); }
static ZIPPY_NOINLINE Space n145(Context& c, const Env& e) { auto a=n146(c,e); auto b=n162(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n177(Context& c, const Env& e) { return e.spaces.at(20); }
static ZIPPY_NOINLINE Space n178(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n181(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n182(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Path n184(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n183(Context& c, const Env& e) { return singleton(n184(c,e)); }
static ZIPPY_NOINLINE Space n180(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n181(c,e),n182(c,e),n183(c,e)}; Env n; n.spaces[40]=sv[0];n.spaces[41]=sv[1];n.spaces[42]=sv[2];  return routine_15(c,n); }
static ZIPPY_NOINLINE Space n186(Context& c, const Env& e) { return e.spaces.at(20); }
static ZIPPY_NOINLINE Space n187(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Path n189(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n188(Context& c, const Env& e) { return singleton(n189(c,e)); }
static ZIPPY_NOINLINE Space n185(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n186(c,e),n187(c,e),n188(c,e)}; Env n; n.spaces[40]=sv[0];n.spaces[41]=sv[1];n.spaces[42]=sv[2];  return routine_15(c,n); }
static ZIPPY_NOINLINE Space n179(Context& c, const Env& e) { auto a=n180(c,e); auto b=n185(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n176(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n177(c,e),n178(c,e),n179(c,e)}; Env n; n.spaces[20]=sv[0];n.spaces[21]=sv[1];n.spaces[22]=sv[2];  return routine_16(c,n); }
static ZIPPY_NOINLINE Space n144(Context& c, const Env& e) { auto a=n145(c,e); auto b=n176(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n191(Context& c, const Env& e) { return e.spaces.at(20); }
static ZIPPY_NOINLINE Space n192(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n195(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Space n197(Context& c, const Env& e) { return e.spaces.at(20); }
static ZIPPY_NOINLINE Space n198(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Path n200(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n199(Context& c, const Env& e) { return singleton(n200(c,e)); }
static ZIPPY_NOINLINE Space n196(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n197(c,e),n198(c,e),n199(c,e)}; Env n; n.spaces[40]=sv[0];n.spaces[41]=sv[1];n.spaces[42]=sv[2];  return routine_15(c,n); }
static ZIPPY_NOINLINE Space n194(Context& c, const Env& e) { auto a=n195(c,e); auto b=n196(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n202(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n203(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Path n205(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Space n204(Context& c, const Env& e) { return singleton(n205(c,e)); }
static ZIPPY_NOINLINE Space n201(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n202(c,e),n203(c,e),n204(c,e)}; Env n; n.spaces[40]=sv[0];n.spaces[41]=sv[1];n.spaces[42]=sv[2];  return routine_15(c,n); }
static ZIPPY_NOINLINE Space n193(Context& c, const Env& e) { auto a=n194(c,e); auto b=n201(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n190(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n191(c,e),n192(c,e),n193(c,e)}; Env n; n.spaces[20]=sv[0];n.spaces[21]=sv[1];n.spaces[22]=sv[2];  return routine_16(c,n); }
static ZIPPY_NOINLINE Space n143(Context& c, const Env& e) { auto a=n144(c,e); auto b=n190(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_11(Context& c,const Env& e) { return n143(c,e); }
static ZIPPY_NOINLINE Path n208(Context& c, const Env& e) { return e.paths.at(29); }
static ZIPPY_NOINLINE Path n209(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n207(Context& c, const Env& e) { auto a=n208(c,e); auto b=n209(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n206(Context& c, const Env& e) { return singleton(n207(c,e)); }
static ZIPPY_NOINLINE Space routine_12(Context& c,const Env& e) { return n206(c,e); }
static ZIPPY_NOINLINE Path n212(Context& c, const Env& e) { return e.paths.at(34); }
static ZIPPY_NOINLINE Path n213(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Path n211(Context& c, const Env& e) { auto a=n212(c,e); auto b=n213(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n210(Context& c, const Env& e) { return singleton(n211(c,e)); }
static ZIPPY_NOINLINE Space routine_6(Context& c,const Env& e) { return n210(c,e); }
static ZIPPY_NOINLINE Space n216(Context& c, const Env& e) { return e.spaces.at(39).empty()?Space():singleton(Path{}); }
static ZIPPY_NOINLINE Space n218(Context& c, const Env& e) { return e.spaces.at(39); }
static ZIPPY_NOINLINE Space n220(Context& c, const Env& e) { return e.spaces.at(39); }
static ZIPPY_NOINLINE Space n219(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n220(c,e)}; Env n; n.spaces[43]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n217(Context& c, const Env& e) { auto a=n218(c,e); auto b=n219(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n215(Context& c, const Env& e) { auto a=n216(c,e); if(a.empty()) return a; return compose(a,n217(c,e)); }
static ZIPPY_NOINLINE Space n223(Context& c, const Env& e) { return singleton(n15(c,e)); }
static ZIPPY_NOINLINE Space n222(Context& c, const Env& e) { auto a=n223(c,e); auto b=n216(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n224(Context& c, const Env& e) { return Space(); }
static ZIPPY_NOINLINE Space n221(Context& c, const Env& e) { auto a=n222(c,e); if(a.empty()) return a; return compose(a,n224(c,e)); }
static ZIPPY_NOINLINE Space n214(Context& c, const Env& e) { auto a=n215(c,e); auto b=n221(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_1(Context& c,const Env& e) { return n214(c,e); }
static ZIPPY_NOINLINE Space n226(Context& c, const Env& e) { return e.spaces.at(42); }
static ZIPPY_NOINLINE Space n228(Context& c, const Env& e) { return e.spaces.at(40); }
static ZIPPY_NOINLINE Space n229(Context& c, const Env& e) { return e.spaces.at(41); }
static ZIPPY_NOINLINE Space n232(Context& c, const Env& e) { return e.spaces.at(42); }
static ZIPPY_NOINLINE Space n236(Context& c, const Env& e) { return e.spaces.at(42); }
static ZIPPY_NOINLINE Space n237(Context& c, const Env& e) { return e.spaces.at(41); }
static ZIPPY_NOINLINE Space n235(Context& c, const Env& e) { auto a=n236(c,e); auto b=n237(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n238(Context& c, const Env& e) { return e.spaces.at(40); }
static ZIPPY_NOINLINE Space n234(Context& c, const Env& e) { auto b=n235(c,e); auto a=n238(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n240(Context& c, const Env& e) { return e.spaces.at(44); }
static ZIPPY_NOINLINE Space n242(Context& c, const Env& e) { return e.spaces.at(45); }
static ZIPPY_NOINLINE Space n244(Context& c, const Env& e) { return e.spaces.at(46); }
static ZIPPY_NOINLINE Path n250(Context& c, const Env& e) { return e.paths.at(35); }
static ZIPPY_NOINLINE Path n249(Context& c, const Env& e) { auto a=n15(c,e); auto b=n250(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n251(Context& c, const Env& e) { return e.paths.at(36); }
static ZIPPY_NOINLINE Path n248(Context& c, const Env& e) { auto a=n249(c,e); auto b=n251(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n252(Context& c, const Env& e) { return e.paths.at(37); }
static ZIPPY_NOINLINE Path n247(Context& c, const Env& e) { auto a=n248(c,e); auto b=n252(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n253(Context& c, const Env& e) { return e.paths.at(38); }
static ZIPPY_NOINLINE Path n246(Context& c, const Env& e) { auto a=n247(c,e); auto b=n253(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n254(Context& c, const Env& e) { return e.spaces.at(47); }
static ZIPPY_NOINLINE Space n245(Context& c, const Env& e) { std::vector<Path> pv{n246(c,e)}; std::vector<Space> sv{n254(c,e)}; Env n; n.paths[39]=pv[0];n.spaces[48]=sv[0];  return routine_9(c,n); }
static ZIPPY_NOINLINE Space n243(Context& c, const Env& e) { return iterate(c,e,n244(c,e),38,47,n245); }
static ZIPPY_NOINLINE Space n241(Context& c, const Env& e) { return iterate(c,e,n242(c,e),37,46,n243); }
static ZIPPY_NOINLINE Space n239(Context& c, const Env& e) { return iterate(c,e,n240(c,e),36,45,n241); }
static ZIPPY_NOINLINE Space n233(Context& c, const Env& e) { return iterate(c,e,n234(c,e),35,44,n239); }
static ZIPPY_NOINLINE Space n231(Context& c, const Env& e) { auto a=n232(c,e); auto b=n233(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n255(Context& c, const Env& e) { return e.spaces.at(41); }
static ZIPPY_NOINLINE Space n230(Context& c, const Env& e) { auto a=n231(c,e); auto b=n255(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n227(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n228(c,e),n229(c,e),n230(c,e)}; Env n; n.spaces[40]=sv[0];n.spaces[41]=sv[1];n.spaces[42]=sv[2]; if(equal(n228(c,n),sv[0]) && equal(n229(c,n),sv[1]) && equal(n230(c,n),sv[2])) return n226(c,n); return routine_15(c,n); }
static ZIPPY_NOINLINE Space n225(Context& c, const Env& e) { auto a=n226(c,e); auto b=n227(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_15(Context& c,const Env& e) { return n225(c,e); }
static ZIPPY_NOINLINE Space n261(Context& c, const Env& e) { return e.spaces.at(43); }
static ZIPPY_NOINLINE Space n260(Context& c, const Env& e) { static const Space allowed=literal_text("1 0 ");return first_matching(n261(c,e),allowed,false); }
static ZIPPY_NOINLINE Space n259(Context& c, const Env& e) { auto a=n260(c,e); auto b=n223(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n262(Context& c, const Env& e) { return iterate(c,e,n260(c,e),40,49,n223); }
static ZIPPY_NOINLINE Space n258(Context& c, const Env& e) { auto a=n259(c,e); auto b=n262(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n257(Context& c, const Env& e) { auto a=n258(c,e); if(a.empty()) return a; return compose(a,n223(c,e)); }
static ZIPPY_NOINLINE Space n264(Context& c, const Env& e) { auto a=n223(c,e); auto b=n258(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n267(Context& c, const Env& e) { return e.spaces.at(43); }
static ZIPPY_NOINLINE Space n266(Context& c, const Env& e) { static const Space allowed=literal_text("6 4 1 1 1 1 4 1 1 1 2 4 1 1 1 3 4 1 1 1 4 4 1 1 1 5 4 1 1 1 6");return first_matching(n267(c,e),allowed,true); }
static ZIPPY_NOINLINE Space n268(Context& c, const Env& e) { return e.spaces.at(43); }
static ZIPPY_NOINLINE Space n265(Context& c, const Env& e) { std::vector<Path> pv{n15(c,e)}; std::vector<Space> sv{n266(c,e),n268(c,e)}; Env n; n.paths[41]=pv[0];n.spaces[50]=sv[0];n.spaces[43]=sv[1];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n263(Context& c, const Env& e) { auto a=n264(c,e); if(a.empty()) return a; return compose(a,n265(c,e)); }
static ZIPPY_NOINLINE Space n256(Context& c, const Env& e) { auto a=n257(c,e); auto b=n263(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_2(Context& c,const Env& e) { return n256(c,e); }
static ZIPPY_NOINLINE Space n269(Context& c, const Env& e) { return e.spaces.at(48); }
static ZIPPY_NOINLINE Space routine_9(Context& c,const Env& e) { return n269(c,e); }
static ZIPPY_NOINLINE Space n273(Context& c, const Env& e) { return e.spaces.at(50); }
static ZIPPY_NOINLINE Space n272(Context& c, const Env& e) { static const Space allowed=literal_text("1 0 ");return first_matching(n273(c,e),allowed,false); }
static ZIPPY_NOINLINE Path n275(Context& c, const Env& e) { return e.paths.at(41); }
static ZIPPY_NOINLINE Space n276(Context& c, const Env& e) { return e.spaces.at(43); }
static ZIPPY_NOINLINE Space n274(Context& c, const Env& e) { std::vector<Path> pv{n275(c,e)}; std::vector<Space> sv{n276(c,e)}; Env n; n.paths[42]=pv[0];n.spaces[43]=sv[0];  return routine_5(c,n); }
static ZIPPY_NOINLINE Space n271(Context& c, const Env& e) { auto a=n272(c,e); if(a.empty()) return a; return compose(a,n274(c,e)); }
static ZIPPY_NOINLINE Space n278(Context& c, const Env& e) { return e.spaces.at(50); }
static ZIPPY_NOINLINE Path n281(Context& c, const Env& e) { return e.paths.at(41); }
static ZIPPY_NOINLINE Path n282(Context& c, const Env& e) { return e.paths.at(43); }
static ZIPPY_NOINLINE Path n280(Context& c, const Env& e) { auto a=n281(c,e); auto b=n282(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n283(Context& c, const Env& e) { return e.spaces.at(51); }
static ZIPPY_NOINLINE Space n284(Context& c, const Env& e) { return e.spaces.at(43); }
static ZIPPY_NOINLINE Space n279(Context& c, const Env& e) { std::vector<Path> pv{n280(c,e)}; std::vector<Space> sv{n283(c,e),n284(c,e)}; Env n; n.paths[41]=pv[0];n.spaces[50]=sv[0];n.spaces[43]=sv[1];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n277(Context& c, const Env& e) { return iterate(c,e,n278(c,e),43,51,n279); }
static ZIPPY_NOINLINE Space n270(Context& c, const Env& e) { auto a=n271(c,e); auto b=n277(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n270(c,e); }
static ZIPPY_NOINLINE Path n286(Context& c, const Env& e) { return e.paths.at(42); }
static ZIPPY_NOINLINE Path n289(Context& c, const Env& e) { return e.paths.at(42); }
static ZIPPY_NOINLINE Space n290(Context& c, const Env& e) { return e.spaces.at(43); }
static ZIPPY_NOINLINE Space n288(Context& c, const Env& e) { auto p=n289(c,e); return unwrap(n290(c,e),p); }
static ZIPPY_NOINLINE Space n287(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n288(c,e)}; Env n; n.spaces[43]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n285(Context& c, const Env& e) { auto p=n286(c,e); return wrap(n287(c,e),p); }
static ZIPPY_NOINLINE Space routine_5(Context& c,const Env& e) { return n285(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
