#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Space n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Path n7(Context&, const Env&);
static ZIPPY_NOINLINE Path n8(Context&, const Env&);
static ZIPPY_NOINLINE Path n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Space n13(Context&, const Env&);
static ZIPPY_NOINLINE Space n14(Context&, const Env&);
static ZIPPY_NOINLINE Space n15(Context&, const Env&);
static ZIPPY_NOINLINE Space n16(Context&, const Env&);
static ZIPPY_NOINLINE Space n17(Context&, const Env&);
static ZIPPY_NOINLINE Space n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n19(Context&, const Env&);
static ZIPPY_NOINLINE Path n20(Context&, const Env&);
static ZIPPY_NOINLINE Path n21(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_1(Context&, const Env&);
static ZIPPY_NOINLINE Space n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n23(Context&, const Env&);
static ZIPPY_NOINLINE Space n24(Context&, const Env&);
static ZIPPY_NOINLINE Space n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Path n29(Context&, const Env&);
static ZIPPY_NOINLINE Space n30(Context&, const Env&);
static ZIPPY_NOINLINE Space n31(Context&, const Env&);
static ZIPPY_NOINLINE Space n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Space n34(Context&, const Env&);
static ZIPPY_NOINLINE Space n35(Context&, const Env&);
static ZIPPY_NOINLINE Path n36(Context&, const Env&);
static ZIPPY_NOINLINE Space n37(Context&, const Env&);
static ZIPPY_NOINLINE Space n38(Context&, const Env&);
static ZIPPY_NOINLINE Space n39(Context&, const Env&);
static ZIPPY_NOINLINE Space n40(Context&, const Env&);
static ZIPPY_NOINLINE Path n41(Context&, const Env&);
static ZIPPY_NOINLINE Space n42(Context&, const Env&);
static ZIPPY_NOINLINE Path n43(Context&, const Env&);
static ZIPPY_NOINLINE Space n44(Context&, const Env&);
static ZIPPY_NOINLINE Space n45(Context&, const Env&);
static ZIPPY_NOINLINE Space n46(Context&, const Env&);
static ZIPPY_NOINLINE Space n47(Context&, const Env&);
static ZIPPY_NOINLINE Space n48(Context&, const Env&);
static ZIPPY_NOINLINE Space n49(Context&, const Env&);
static ZIPPY_NOINLINE Space n50(Context&, const Env&);
static ZIPPY_NOINLINE Space n51(Context&, const Env&);
static ZIPPY_NOINLINE Path n52(Context&, const Env&);
static ZIPPY_NOINLINE Space n53(Context&, const Env&);
static ZIPPY_NOINLINE Space n54(Context&, const Env&);
static ZIPPY_NOINLINE Space n55(Context&, const Env&);
static ZIPPY_NOINLINE Space n56(Context&, const Env&);
static ZIPPY_NOINLINE Path n57(Context&, const Env&);
static ZIPPY_NOINLINE Space n58(Context&, const Env&);
static ZIPPY_NOINLINE Space n59(Context&, const Env&);
static ZIPPY_NOINLINE Space n60(Context&, const Env&);
static ZIPPY_NOINLINE Space n61(Context&, const Env&);
static ZIPPY_NOINLINE Space n62(Context&, const Env&);
static ZIPPY_NOINLINE Space n63(Context&, const Env&);
static ZIPPY_NOINLINE Space n64(Context&, const Env&);
static ZIPPY_NOINLINE Space n65(Context&, const Env&);
static ZIPPY_NOINLINE Path n66(Context&, const Env&);
static ZIPPY_NOINLINE Space n67(Context&, const Env&);
static ZIPPY_NOINLINE Space n68(Context&, const Env&);
static ZIPPY_NOINLINE Space n69(Context&, const Env&);
static ZIPPY_NOINLINE Space n70(Context&, const Env&);
static ZIPPY_NOINLINE Path n71(Context&, const Env&);
static ZIPPY_NOINLINE Space n72(Context&, const Env&);
static ZIPPY_NOINLINE Space n73(Context&, const Env&);
static ZIPPY_NOINLINE Space n74(Context&, const Env&);
static ZIPPY_NOINLINE Space n75(Context&, const Env&);
static ZIPPY_NOINLINE Space n76(Context&, const Env&);
static ZIPPY_NOINLINE Space n77(Context&, const Env&);
static ZIPPY_NOINLINE Space n78(Context&, const Env&);
static ZIPPY_NOINLINE Space n79(Context&, const Env&);
static ZIPPY_NOINLINE Space n80(Context&, const Env&);
static ZIPPY_NOINLINE Space n81(Context&, const Env&);
static ZIPPY_NOINLINE Path n82(Context&, const Env&);
static ZIPPY_NOINLINE Space n83(Context&, const Env&);
static ZIPPY_NOINLINE Space n84(Context&, const Env&);
static ZIPPY_NOINLINE Space n85(Context&, const Env&);
static ZIPPY_NOINLINE Space n86(Context&, const Env&);
static ZIPPY_NOINLINE Path n87(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n88(Context&, const Env&);
static ZIPPY_NOINLINE Space n89(Context&, const Env&);
static ZIPPY_NOINLINE Space n90(Context&, const Env&);
static ZIPPY_NOINLINE Space n91(Context&, const Env&);
static ZIPPY_NOINLINE Space n92(Context&, const Env&);
static ZIPPY_NOINLINE Space n93(Context&, const Env&);
static ZIPPY_NOINLINE Space n94(Context&, const Env&);
static ZIPPY_NOINLINE Space n95(Context&, const Env&);
static ZIPPY_NOINLINE Space n96(Context&, const Env&);
static ZIPPY_NOINLINE Space n97(Context&, const Env&);
static ZIPPY_NOINLINE Space n98(Context&, const Env&);
static ZIPPY_NOINLINE Space n99(Context&, const Env&);
static ZIPPY_NOINLINE Space n100(Context&, const Env&);
static ZIPPY_NOINLINE Space n101(Context&, const Env&);
static ZIPPY_NOINLINE Space n102(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { static const Space value=literal_text("6 2 1 2 2 2 1 2 3 2 2 3 4 2 4 3 2 5 6"); return value; }
static ZIPPY_NOINLINE Space n3(Context& c, const Env& e) { static const Space value=literal_text("6 2 1 2 2 2 1 2 3 2 2 3 4 2 4 3 2 5 6"); return value; }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Path n8(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n9(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n7(Context& c, const Env& e) { auto a=n8(c,e); auto b=n9(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { return singleton(n7(c,e)); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { return iterate(c,e,n5(c,e),1,1,n6); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { return iterate(c,e,n3(c,e),0,0,n4); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { static const Space value=literal_text("6 2 1 2 2 2 1 2 3 2 2 3 4 2 4 3 2 5 6"); return value; }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { return head_space(n12(c,e)); }
static ZIPPY_NOINLINE Space n15(Context& c, const Env& e) { static const Space value=literal_text("6 2 1 2 2 2 1 2 3 2 2 3 4 2 4 3 2 5 6"); return value; }
static ZIPPY_NOINLINE Space n17(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Path n20(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n21(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n19(Context& c, const Env& e) { auto a=n20(c,e); auto b=n21(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n18(Context& c, const Env& e) { return singleton(n19(c,e)); }
static ZIPPY_NOINLINE Space n16(Context& c, const Env& e) { return iterate(c,e,n17(c,e),1,1,n18); }
static ZIPPY_NOINLINE Space n14(Context& c, const Env& e) { return iterate(c,e,n15(c,e),0,0,n16); }
static ZIPPY_NOINLINE Space n13(Context& c, const Env& e) { return head_space(n14(c,e)); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { auto a=n11(c,e); auto b=n13(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n1(c,e),n2(c,e),n10(c,e)}; Env n; n.spaces[2]=sv[0];n.spaces[3]=sv[1];n.spaces[4]=sv[2];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n24(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Space n23(Context& c, const Env& e) { return range(c,n24(c,e),0,1); }
static ZIPPY_NOINLINE Path n29(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n34(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Path n36(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n35(Context& c, const Env& e) { return singleton(n36(c,e)); }
static ZIPPY_NOINLINE Space n32(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n33(c,e),n34(c,e),n35(c,e)}; Env n; n.spaces[5]=sv[0];n.spaces[6]=sv[1];n.spaces[7]=sv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n38(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n39(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Path n41(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n40(Context& c, const Env& e) { return singleton(n41(c,e)); }
static ZIPPY_NOINLINE Space n37(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n38(c,e),n39(c,e),n40(c,e)}; Env n; n.spaces[5]=sv[0];n.spaces[6]=sv[1];n.spaces[7]=sv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n31(Context& c, const Env& e) { auto a=n32(c,e); auto b=n37(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Path n43(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n42(Context& c, const Env& e) { return singleton(n43(c,e)); }
static ZIPPY_NOINLINE Space n30(Context& c, const Env& e) { auto a=n31(c,e); auto b=n42(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { auto p=n29(c,e); return wrap(n30(c,e),p); }
static ZIPPY_NOINLINE Space n45(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n46(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n49(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n50(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Path n52(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n51(Context& c, const Env& e) { return singleton(n52(c,e)); }
static ZIPPY_NOINLINE Space n48(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n49(c,e),n50(c,e),n51(c,e)}; Env n; n.spaces[5]=sv[0];n.spaces[6]=sv[1];n.spaces[7]=sv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n54(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n55(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Path n57(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n56(Context& c, const Env& e) { return singleton(n57(c,e)); }
static ZIPPY_NOINLINE Space n53(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n54(c,e),n55(c,e),n56(c,e)}; Env n; n.spaces[5]=sv[0];n.spaces[6]=sv[1];n.spaces[7]=sv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n47(Context& c, const Env& e) { auto a=n48(c,e); auto b=n53(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n44(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n45(c,e),n46(c,e),n47(c,e)}; Env n; n.spaces[2]=sv[0];n.spaces[3]=sv[1];n.spaces[4]=sv[2];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { auto a=n28(c,e); auto b=n44(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n59(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n60(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n63(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n64(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Path n66(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n65(Context& c, const Env& e) { return singleton(n66(c,e)); }
static ZIPPY_NOINLINE Space n62(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n63(c,e),n64(c,e),n65(c,e)}; Env n; n.spaces[5]=sv[0];n.spaces[6]=sv[1];n.spaces[7]=sv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n68(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n69(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Path n71(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n70(Context& c, const Env& e) { return singleton(n71(c,e)); }
static ZIPPY_NOINLINE Space n67(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n68(c,e),n69(c,e),n70(c,e)}; Env n; n.spaces[5]=sv[0];n.spaces[6]=sv[1];n.spaces[7]=sv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n61(Context& c, const Env& e) { auto a=n62(c,e); auto b=n67(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n58(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n59(c,e),n60(c,e),n61(c,e)}; Env n; n.spaces[2]=sv[0];n.spaces[3]=sv[1];n.spaces[4]=sv[2];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { auto a=n27(c,e); auto b=n58(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n73(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n74(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n77(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Space n79(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n80(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Path n82(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n81(Context& c, const Env& e) { return singleton(n82(c,e)); }
static ZIPPY_NOINLINE Space n78(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n79(c,e),n80(c,e),n81(c,e)}; Env n; n.spaces[5]=sv[0];n.spaces[6]=sv[1];n.spaces[7]=sv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n76(Context& c, const Env& e) { auto a=n77(c,e); auto b=n78(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n84(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n85(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Path n87(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n86(Context& c, const Env& e) { return singleton(n87(c,e)); }
static ZIPPY_NOINLINE Space n83(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n84(c,e),n85(c,e),n86(c,e)}; Env n; n.spaces[5]=sv[0];n.spaces[6]=sv[1];n.spaces[7]=sv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n75(Context& c, const Env& e) { auto a=n76(c,e); auto b=n83(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n72(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n73(c,e),n74(c,e),n75(c,e)}; Env n; n.spaces[2]=sv[0];n.spaces[3]=sv[1];n.spaces[4]=sv[2];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n25(Context& c, const Env& e) { auto a=n26(c,e); auto b=n72(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n22(Context& c, const Env& e) { return iterate(c,e,n23(c,e),2,-1,n25); }
static ZIPPY_NOINLINE Space routine_1(Context& c,const Env& e) { return n22(c,e); }
static ZIPPY_NOINLINE Space n89(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n91(Context& c, const Env& e) { return e.spaces.at(5); }
static ZIPPY_NOINLINE Space n92(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n95(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n99(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n100(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n98(Context& c, const Env& e) { auto a=n99(c,e); auto b=n100(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n101(Context& c, const Env& e) { return e.spaces.at(5); }
static ZIPPY_NOINLINE Space n97(Context& c, const Env& e) { auto b=n98(c,e); auto a=n101(c,e); return restrict_to(a,b); }
static ZIPPY_NOINLINE Space n96(Context& c, const Env& e) { return tails_union(n97(c,e)); }
static ZIPPY_NOINLINE Space n94(Context& c, const Env& e) { auto a=n95(c,e); auto b=n96(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n102(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n93(Context& c, const Env& e) { auto a=n94(c,e); auto b=n102(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n90(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n91(c,e),n92(c,e),n93(c,e)}; Env n; n.spaces[5]=sv[0];n.spaces[6]=sv[1];n.spaces[7]=sv[2]; if(equal(n91(c,n),sv[0]) && equal(n92(c,n),sv[1]) && equal(n93(c,n),sv[2])) return n89(c,n); return routine_0(c,n); }
static ZIPPY_NOINLINE Space n88(Context& c, const Env& e) { auto a=n89(c,e); auto b=n90(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n88(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"6 1 1 100 2 1 99 3 1 98 4 1 97 5 1 101 6 1 102"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
