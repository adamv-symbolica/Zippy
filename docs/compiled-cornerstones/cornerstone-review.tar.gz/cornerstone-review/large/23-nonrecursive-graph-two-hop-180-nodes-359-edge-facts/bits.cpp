#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{2,2};
static const Space constant_1 = literal_text("1 0 ");
static const Space constant_2 = literal_text("1 1 2");
static const Space constant_3 = singleton(Path{});
static const Path constant_4 = Path{1,1,1,2,1,1,1,2,1,1,2,2};
static Space routine_0(Context& c, const Space* s0);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_55(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_56(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_57(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_17(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_45(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_52(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_0(Context& c, const Space* s0) {
  const Space v0_2 = unwrap(bound_space(s0),constant_0);
  Space v0_12_result;
  for (int v0_12_label = 1; v0_12_label <= 2; ++v0_12_label) {
    const Space v0_12_tail = child(v0_2,v0_12_label);
    if (v0_12_tail.empty()) continue;
    const Path v0_12_head{v0_12_label};
    const Space v1_2 = singleton(v0_12_head);
    const Space v1_3 = intersect(constant_2,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_3 : Space{});
    const Space v1_5 = subtract(constant_1,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      Space v2_6_result;
      for (int v2_6_label = 1; v2_6_label <= 2; ++v2_6_label) {
        const Space v2_6_tail = child(v0_12_tail,v2_6_label);
        if (v2_6_tail.empty()) continue;
        const Path v2_6_head{v2_6_label};
        const Space v3_2 = singleton(v2_6_head);
        const Space v3_3 = intersect(constant_2,v3_2);
        const Space v3_4 = (has_head(v3_3) ? constant_3 : Space{});
        const Space v3_5 = subtract(constant_1,v3_4);
        Space v3_8;
        if (!v3_5.empty()) {
          const Path v4_6 = concat_path(v0_12_head,v2_6_head);
          const Space v4_7 = routine_1(c, v4_6, v2_6_tail, bound_space(s0));
          v3_8 = compose(v3_5,v4_7);
        }
        const Space v3_9 = intersect(constant_2,v3_2);
        const Space v3_10 = (has_head(v3_9) ? constant_3 : Space{});
        Space v3_12;
        if (!v3_10.empty()) {
          const Path v5_6 = concat_path(v0_12_head,v2_6_head);
          const Space v5_11 = routine_2(c, v5_6, v2_6_tail, bound_space(s0));
          v3_12 = compose(v3_10,v5_11);
        }
        const Space v3_13 = unite(v3_8,v3_12);
        v2_6_result = unite(v2_6_result,v3_13);
      }
      const Space v2_6 = std::move(v2_6_result);
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_2,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_3 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      Space v6_10_result;
      for (int v6_10_label = 1; v6_10_label <= 2; ++v6_10_label) {
        const Space v6_10_tail = child(v0_12_tail,v6_10_label);
        if (v6_10_tail.empty()) continue;
        const Path v6_10_head{v6_10_label};
        const Space v7_2 = singleton(v6_10_head);
        const Space v7_3 = intersect(constant_2,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_3 : Space{});
        const Space v7_5 = subtract(constant_1,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v0_12_head,v6_10_head);
          const Space v8_7 = routine_1(c, v8_6, v6_10_tail, bound_space(s0));
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_2,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_3 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v0_12_head,v6_10_head);
          const Space v9_11 = routine_3(c, v9_6, v6_10_tail, bound_space(s0));
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_10_result = unite(v6_10_result,v7_13);
      }
      const Space v6_10 = std::move(v6_10_result);
      v1_11 = compose(v1_9,v6_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_12_result = unite(v0_12_result,v1_12);
  }
  const Space v0_12 = std::move(v0_12_result);
  const Space v0_14 = wrap(v0_12,constant_4);
  return v0_14;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v10_12_result;
  for (int v10_12_label = 1; v10_12_label <= 2; ++v10_12_label) {
    const Space v10_12_tail = child(s0,v10_12_label);
    if (v10_12_tail.empty()) continue;
    const Path v10_12_head{v10_12_label};
    const Space v11_2 = singleton(v10_12_head);
    const Space v11_3 = intersect(constant_2,v11_2);
    const Space v11_4 = (has_head(v11_3) ? constant_3 : Space{});
    const Space v11_5 = subtract(constant_1,v11_4);
    Space v11_8;
    if (!v11_5.empty()) {
      const Path v12_6 = concat_path(p0,v10_12_head);
      Space v12_7_result;
      for (int v12_7_label = 1; v12_7_label <= 2; ++v12_7_label) {
        const Space v12_7_tail = child(v10_12_tail,v12_7_label);
        if (v12_7_tail.empty()) continue;
        const Path v12_7_head{v12_7_label};
        const Space v13_2 = singleton(v12_7_head);
        const Space v13_3 = intersect(constant_2,v13_2);
        const Space v13_4 = (has_head(v13_3) ? constant_3 : Space{});
        const Space v13_5 = subtract(constant_1,v13_4);
        Space v13_8;
        if (!v13_5.empty()) {
          const Path v14_6 = concat_path(v12_6,v12_7_head);
          const Space v14_7 = routine_4(c, v14_6, v12_7_tail, s1);
          v13_8 = compose(v13_5,v14_7);
        }
        const Space v13_9 = intersect(constant_2,v13_2);
        const Space v13_10 = (has_head(v13_9) ? constant_3 : Space{});
        Space v13_12;
        if (!v13_10.empty()) {
          const Path v15_6 = concat_path(v12_6,v12_7_head);
          const Space v15_11 = routine_5(c, v15_6, v12_7_tail, s1);
          v13_12 = compose(v13_10,v15_11);
        }
        const Space v13_13 = unite(v13_8,v13_12);
        v12_7_result = unite(v12_7_result,v13_13);
      }
      const Space v12_7 = std::move(v12_7_result);
      v11_8 = compose(v11_5,v12_7);
    }
    const Space v11_9 = intersect(constant_2,v11_2);
    const Space v11_10 = (has_head(v11_9) ? constant_3 : Space{});
    Space v11_12;
    if (!v11_10.empty()) {
      const Path v16_6 = concat_path(p0,v10_12_head);
      Space v16_11_result;
      for (int v16_11_label = 1; v16_11_label <= 2; ++v16_11_label) {
        const Space v16_11_tail = child(v10_12_tail,v16_11_label);
        if (v16_11_tail.empty()) continue;
        const Path v16_11_head{v16_11_label};
        const Space v17_2 = singleton(v16_11_head);
        const Space v17_3 = intersect(constant_2,v17_2);
        const Space v17_4 = (has_head(v17_3) ? constant_3 : Space{});
        const Space v17_5 = subtract(constant_1,v17_4);
        Space v17_8;
        if (!v17_5.empty()) {
          const Path v18_6 = concat_path(v16_6,v16_11_head);
          const Space v18_7 = routine_4(c, v18_6, v16_11_tail, s1);
          v17_8 = compose(v17_5,v18_7);
        }
        const Space v17_9 = intersect(constant_2,v17_2);
        const Space v17_10 = (has_head(v17_9) ? constant_3 : Space{});
        Space v17_12;
        if (!v17_10.empty()) {
          const Path v19_6 = concat_path(v16_6,v16_11_head);
          const Space v19_11 = routine_3(c, v19_6, v16_11_tail, s1);
          v17_12 = compose(v17_10,v19_11);
        }
        const Space v17_13 = unite(v17_8,v17_12);
        v16_11_result = unite(v16_11_result,v17_13);
      }
      const Space v16_11 = std::move(v16_11_result);
      v11_12 = compose(v11_10,v16_11);
    }
    const Space v11_13 = unite(v11_8,v11_12);
    v10_12_result = unite(v10_12_result,v11_13);
  }
  const Space v10_12 = std::move(v10_12_result);
  return v10_12;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v20_12_result;
  for (int v20_12_label = 1; v20_12_label <= 2; ++v20_12_label) {
    const Space v20_12_tail = child(s0,v20_12_label);
    if (v20_12_tail.empty()) continue;
    const Path v20_12_head{v20_12_label};
    const Space v21_2 = singleton(v20_12_head);
    const Space v21_3 = intersect(constant_2,v21_2);
    const Space v21_4 = (has_head(v21_3) ? constant_3 : Space{});
    const Space v21_5 = subtract(constant_1,v21_4);
    Space v21_8;
    if (!v21_5.empty()) {
      const Path v22_6 = concat_path(p0,v20_12_head);
      Space v22_7_result;
      for (int v22_7_label = 1; v22_7_label <= 2; ++v22_7_label) {
        const Space v22_7_tail = child(v20_12_tail,v22_7_label);
        if (v22_7_tail.empty()) continue;
        const Path v22_7_head{v22_7_label};
        const Space v23_2 = singleton(v22_7_head);
        const Space v23_3 = intersect(constant_2,v23_2);
        const Space v23_4 = (has_head(v23_3) ? constant_3 : Space{});
        const Space v23_5 = subtract(constant_1,v23_4);
        Space v23_8;
        if (!v23_5.empty()) {
          const Path v24_6 = concat_path(v22_6,v22_7_head);
          const Space v24_7 = routine_4(c, v24_6, v22_7_tail, s1);
          v23_8 = compose(v23_5,v24_7);
        }
        const Space v23_9 = intersect(constant_2,v23_2);
        const Space v23_10 = (has_head(v23_9) ? constant_3 : Space{});
        Space v23_12;
        if (!v23_10.empty()) {
          const Path v25_6 = concat_path(v22_6,v22_7_head);
          const Space v25_11 = routine_5(c, v25_6, v22_7_tail, s1);
          v23_12 = compose(v23_10,v25_11);
        }
        const Space v23_13 = unite(v23_8,v23_12);
        v22_7_result = unite(v22_7_result,v23_13);
      }
      const Space v22_7 = std::move(v22_7_result);
      v21_8 = compose(v21_5,v22_7);
    }
    const Space v21_9 = intersect(constant_2,v21_2);
    const Space v21_10 = (has_head(v21_9) ? constant_3 : Space{});
    Space v21_12;
    if (!v21_10.empty()) {
      const Path v26_6 = concat_path(p0,v20_12_head);
      Space v26_11_result;
      for (int v26_11_label = 1; v26_11_label <= 2; ++v26_11_label) {
        const Space v26_11_tail = child(v20_12_tail,v26_11_label);
        if (v26_11_tail.empty()) continue;
        const Path v26_11_head{v26_11_label};
        const Space v27_2 = singleton(v26_11_head);
        const Space v27_3 = intersect(constant_2,v27_2);
        const Space v27_4 = (has_head(v27_3) ? constant_3 : Space{});
        const Space v27_5 = subtract(constant_1,v27_4);
        Space v27_7;
        if (!v27_5.empty()) {
          const Space v28_6 = routine_6(c, v26_11_head, v26_6, v26_11_tail, s1);
          v27_7 = compose(v27_5,v28_6);
        }
        const Space v27_8 = intersect(constant_2,v27_2);
        const Space v27_9 = (has_head(v27_8) ? constant_3 : Space{});
        Space v27_11;
        if (!v27_9.empty()) {
          const Space v29_10 = routine_7(c, v26_11_head, v26_6, v26_11_tail, s1);
          v27_11 = compose(v27_9,v29_10);
        }
        const Space v27_12 = unite(v27_7,v27_11);
        v26_11_result = unite(v26_11_result,v27_12);
      }
      const Space v26_11 = std::move(v26_11_result);
      v21_12 = compose(v21_10,v26_11);
    }
    const Space v21_13 = unite(v21_8,v21_12);
    v20_12_result = unite(v20_12_result,v21_13);
  }
  const Space v20_12 = std::move(v20_12_result);
  return v20_12;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v30_12_result;
  for (int v30_12_label = 1; v30_12_label <= 2; ++v30_12_label) {
    const Space v30_12_tail = child(s0,v30_12_label);
    if (v30_12_tail.empty()) continue;
    const Path v30_12_head{v30_12_label};
    const Space v31_2 = singleton(v30_12_head);
    const Space v31_3 = intersect(constant_2,v31_2);
    const Space v31_4 = (has_head(v31_3) ? constant_3 : Space{});
    const Space v31_5 = subtract(constant_1,v31_4);
    Space v31_7;
    if (!v31_5.empty()) {
      Space v32_6_result;
      for (int v32_6_label = 1; v32_6_label <= 2; ++v32_6_label) {
        const Space v32_6_tail = child(v30_12_tail,v32_6_label);
        if (v32_6_tail.empty()) continue;
        const Path v32_6_head{v32_6_label};
        const Space v33_2 = singleton(v32_6_head);
        const Space v33_3 = intersect(constant_2,v33_2);
        const Space v33_4 = (has_head(v33_3) ? constant_3 : Space{});
        const Space v33_5 = subtract(constant_1,v33_4);
        Space v33_8;
        if (!v33_5.empty()) {
          const Path v34_6 = concat_path(v30_12_head,v32_6_head);
          const Space v34_7 = routine_8(c, v34_6, p0, v32_6_tail, s1);
          v33_8 = compose(v33_5,v34_7);
        }
        const Space v33_9 = intersect(constant_2,v33_2);
        const Space v33_10 = (has_head(v33_9) ? constant_3 : Space{});
        Space v33_12;
        if (!v33_10.empty()) {
          const Path v35_6 = concat_path(v30_12_head,v32_6_head);
          const Space v35_11 = routine_9(c, v35_6, p0, v32_6_tail, s1);
          v33_12 = compose(v33_10,v35_11);
        }
        const Space v33_13 = unite(v33_8,v33_12);
        v32_6_result = unite(v32_6_result,v33_13);
      }
      const Space v32_6 = std::move(v32_6_result);
      v31_7 = compose(v31_5,v32_6);
    }
    const Space v31_8 = intersect(constant_2,v31_2);
    const Space v31_9 = (has_head(v31_8) ? constant_3 : Space{});
    Space v31_11;
    if (!v31_9.empty()) {
      Space v36_10_result;
      for (int v36_10_label = 1; v36_10_label <= 2; ++v36_10_label) {
        const Space v36_10_tail = child(v30_12_tail,v36_10_label);
        if (v36_10_tail.empty()) continue;
        const Path v36_10_head{v36_10_label};
        const Space v37_2 = singleton(v36_10_head);
        const Space v37_3 = intersect(constant_2,v37_2);
        const Space v37_4 = (has_head(v37_3) ? constant_3 : Space{});
        const Space v37_5 = subtract(constant_1,v37_4);
        Space v37_8;
        if (!v37_5.empty()) {
          const Path v38_6 = concat_path(v30_12_head,v36_10_head);
          const Space v38_7 = routine_8(c, v38_6, p0, v36_10_tail, s1);
          v37_8 = compose(v37_5,v38_7);
        }
        const Space v37_9 = intersect(constant_2,v37_2);
        const Space v37_10 = (has_head(v37_9) ? constant_3 : Space{});
        Space v37_12;
        if (!v37_10.empty()) {
          const Path v39_6 = concat_path(v30_12_head,v36_10_head);
          const Space v39_11 = routine_10(c, v39_6, p0, v36_10_tail, s1);
          v37_12 = compose(v37_10,v39_11);
        }
        const Space v37_13 = unite(v37_8,v37_12);
        v36_10_result = unite(v36_10_result,v37_13);
      }
      const Space v36_10 = std::move(v36_10_result);
      v31_11 = compose(v31_9,v36_10);
    }
    const Space v31_12 = unite(v31_7,v31_11);
    v30_12_result = unite(v30_12_result,v31_12);
  }
  const Space v30_12 = std::move(v30_12_result);
  return v30_12;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v40_12_result;
  for (int v40_12_label = 1; v40_12_label <= 2; ++v40_12_label) {
    const Space v40_12_tail = child(s0,v40_12_label);
    if (v40_12_tail.empty()) continue;
    const Path v40_12_head{v40_12_label};
    const Space v41_2 = singleton(v40_12_head);
    const Space v41_3 = intersect(constant_2,v41_2);
    const Space v41_4 = (has_head(v41_3) ? constant_3 : Space{});
    const Space v41_5 = subtract(constant_1,v41_4);
    Space v41_8;
    if (!v41_5.empty()) {
      const Path v42_6 = concat_path(p0,v40_12_head);
      Space v42_7_result;
      for (int v42_7_label = 1; v42_7_label <= 2; ++v42_7_label) {
        const Space v42_7_tail = child(v40_12_tail,v42_7_label);
        if (v42_7_tail.empty()) continue;
        const Path v42_7_head{v42_7_label};
        const Space v43_2 = singleton(v42_7_head);
        const Space v43_3 = intersect(constant_2,v43_2);
        const Space v43_4 = (has_head(v43_3) ? constant_3 : Space{});
        const Space v43_5 = subtract(constant_1,v43_4);
        Space v43_8;
        if (!v43_5.empty()) {
          const Path v44_6 = concat_path(v42_6,v42_7_head);
          const Space v44_7 = routine_11(c, v44_6, v42_7_tail, s1);
          v43_8 = compose(v43_5,v44_7);
        }
        const Space v43_9 = intersect(constant_2,v43_2);
        const Space v43_10 = (has_head(v43_9) ? constant_3 : Space{});
        Space v43_12;
        if (!v43_10.empty()) {
          const Path v45_6 = concat_path(v42_6,v42_7_head);
          const Space v45_11 = routine_12(c, v45_6, v42_7_tail, s1);
          v43_12 = compose(v43_10,v45_11);
        }
        const Space v43_13 = unite(v43_8,v43_12);
        v42_7_result = unite(v42_7_result,v43_13);
      }
      const Space v42_7 = std::move(v42_7_result);
      v41_8 = compose(v41_5,v42_7);
    }
    const Space v41_9 = intersect(constant_2,v41_2);
    const Space v41_10 = (has_head(v41_9) ? constant_3 : Space{});
    Space v41_12;
    if (!v41_10.empty()) {
      const Path v46_6 = concat_path(p0,v40_12_head);
      Space v46_11_result;
      for (int v46_11_label = 1; v46_11_label <= 2; ++v46_11_label) {
        const Space v46_11_tail = child(v40_12_tail,v46_11_label);
        if (v46_11_tail.empty()) continue;
        const Path v46_11_head{v46_11_label};
        const Space v47_2 = singleton(v46_11_head);
        const Space v47_3 = intersect(constant_2,v47_2);
        const Space v47_4 = (has_head(v47_3) ? constant_3 : Space{});
        const Space v47_5 = subtract(constant_1,v47_4);
        Space v47_8;
        if (!v47_5.empty()) {
          const Path v48_6 = concat_path(v46_6,v46_11_head);
          const Space v48_7 = routine_11(c, v48_6, v46_11_tail, s1);
          v47_8 = compose(v47_5,v48_7);
        }
        const Space v47_9 = intersect(constant_2,v47_2);
        const Space v47_10 = (has_head(v47_9) ? constant_3 : Space{});
        Space v47_12;
        if (!v47_10.empty()) {
          const Path v49_6 = concat_path(v46_6,v46_11_head);
          const Space v49_11 = routine_3(c, v49_6, v46_11_tail, s1);
          v47_12 = compose(v47_10,v49_11);
        }
        const Space v47_13 = unite(v47_8,v47_12);
        v46_11_result = unite(v46_11_result,v47_13);
      }
      const Space v46_11 = std::move(v46_11_result);
      v41_12 = compose(v41_10,v46_11);
    }
    const Space v41_13 = unite(v41_8,v41_12);
    v40_12_result = unite(v40_12_result,v41_13);
  }
  const Space v40_12 = std::move(v40_12_result);
  return v40_12;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v50_12_result;
  for (int v50_12_label = 1; v50_12_label <= 2; ++v50_12_label) {
    const Space v50_12_tail = child(s0,v50_12_label);
    if (v50_12_tail.empty()) continue;
    const Path v50_12_head{v50_12_label};
    const Space v51_2 = singleton(v50_12_head);
    const Space v51_3 = intersect(constant_2,v51_2);
    const Space v51_4 = (has_head(v51_3) ? constant_3 : Space{});
    const Space v51_5 = subtract(constant_1,v51_4);
    Space v51_8;
    if (!v51_5.empty()) {
      const Path v52_6 = concat_path(p0,v50_12_head);
      Space v52_7_result;
      for (int v52_7_label = 1; v52_7_label <= 2; ++v52_7_label) {
        const Space v52_7_tail = child(v50_12_tail,v52_7_label);
        if (v52_7_tail.empty()) continue;
        const Path v52_7_head{v52_7_label};
        const Space v53_2 = singleton(v52_7_head);
        const Space v53_3 = intersect(constant_2,v53_2);
        const Space v53_4 = (has_head(v53_3) ? constant_3 : Space{});
        const Space v53_5 = subtract(constant_1,v53_4);
        Space v53_8;
        if (!v53_5.empty()) {
          const Path v54_6 = concat_path(v52_6,v52_7_head);
          const Space v54_7 = routine_11(c, v54_6, v52_7_tail, s1);
          v53_8 = compose(v53_5,v54_7);
        }
        const Space v53_9 = intersect(constant_2,v53_2);
        const Space v53_10 = (has_head(v53_9) ? constant_3 : Space{});
        Space v53_12;
        if (!v53_10.empty()) {
          const Path v55_6 = concat_path(v52_6,v52_7_head);
          const Space v55_11 = routine_12(c, v55_6, v52_7_tail, s1);
          v53_12 = compose(v53_10,v55_11);
        }
        const Space v53_13 = unite(v53_8,v53_12);
        v52_7_result = unite(v52_7_result,v53_13);
      }
      const Space v52_7 = std::move(v52_7_result);
      v51_8 = compose(v51_5,v52_7);
    }
    const Space v51_9 = intersect(constant_2,v51_2);
    const Space v51_10 = (has_head(v51_9) ? constant_3 : Space{});
    Space v51_12;
    if (!v51_10.empty()) {
      const Path v56_6 = concat_path(p0,v50_12_head);
      Space v56_11_result;
      for (int v56_11_label = 1; v56_11_label <= 2; ++v56_11_label) {
        const Space v56_11_tail = child(v50_12_tail,v56_11_label);
        if (v56_11_tail.empty()) continue;
        const Path v56_11_head{v56_11_label};
        const Space v57_2 = singleton(v56_11_head);
        const Space v57_3 = intersect(constant_2,v57_2);
        const Space v57_4 = (has_head(v57_3) ? constant_3 : Space{});
        const Space v57_5 = subtract(constant_1,v57_4);
        Space v57_7;
        if (!v57_5.empty()) {
          const Space v58_6 = routine_6(c, v56_11_head, v56_6, v56_11_tail, s1);
          v57_7 = compose(v57_5,v58_6);
        }
        const Space v57_8 = intersect(constant_2,v57_2);
        const Space v57_9 = (has_head(v57_8) ? constant_3 : Space{});
        Space v57_11;
        if (!v57_9.empty()) {
          const Space v59_10 = routine_7(c, v56_11_head, v56_6, v56_11_tail, s1);
          v57_11 = compose(v57_9,v59_10);
        }
        const Space v57_12 = unite(v57_7,v57_11);
        v56_11_result = unite(v56_11_result,v57_12);
      }
      const Space v56_11 = std::move(v56_11_result);
      v51_12 = compose(v51_10,v56_11);
    }
    const Space v51_13 = unite(v51_8,v51_12);
    v50_12_result = unite(v50_12_result,v51_13);
  }
  const Space v50_12 = std::move(v50_12_result);
  return v50_12;
}

static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v60_13_result;
  for (int v60_13_label = 1; v60_13_label <= 2; ++v60_13_label) {
    const Space v60_13_tail = child(s0,v60_13_label);
    if (v60_13_tail.empty()) continue;
    const Path v60_13_head{v60_13_label};
    const Space v61_2 = singleton(v60_13_head);
    const Space v61_3 = intersect(constant_2,v61_2);
    const Space v61_4 = (has_head(v61_3) ? constant_3 : Space{});
    const Space v61_5 = subtract(constant_1,v61_4);
    Space v61_8;
    if (!v61_5.empty()) {
      const Path v62_6 = concat_path(p0,v60_13_head);
      Space v62_7_result;
      for (int v62_7_label = 1; v62_7_label <= 2; ++v62_7_label) {
        const Space v62_7_tail = child(v60_13_tail,v62_7_label);
        if (v62_7_tail.empty()) continue;
        const Path v62_7_head{v62_7_label};
        const Space v63_2 = singleton(v62_7_head);
        const Space v63_3 = intersect(constant_2,v63_2);
        const Space v63_4 = (has_head(v63_3) ? constant_3 : Space{});
        const Space v63_5 = subtract(constant_1,v63_4);
        Space v63_8;
        if (!v63_5.empty()) {
          const Path v64_6 = concat_path(v62_6,v62_7_head);
          const Space v64_7 = routine_13(c, v64_6, p1, v62_7_tail, s1);
          v63_8 = compose(v63_5,v64_7);
        }
        const Space v63_9 = intersect(constant_2,v63_2);
        const Space v63_10 = (has_head(v63_9) ? constant_3 : Space{});
        Space v63_12;
        if (!v63_10.empty()) {
          const Path v65_6 = concat_path(v62_6,v62_7_head);
          const Space v65_11 = routine_14(c, v65_6, p1, v62_7_tail, s1);
          v63_12 = compose(v63_10,v65_11);
        }
        const Space v63_13 = unite(v63_8,v63_12);
        v62_7_result = unite(v62_7_result,v63_13);
      }
      const Space v62_7 = std::move(v62_7_result);
      v61_8 = compose(v61_5,v62_7);
    }
    const Space v61_9 = intersect(constant_2,v61_2);
    const Space v61_10 = (has_head(v61_9) ? constant_3 : Space{});
    Space v61_12;
    if (!v61_10.empty()) {
      const Path v66_6 = concat_path(p0,v60_13_head);
      Space v66_11_result;
      for (int v66_11_label = 1; v66_11_label <= 2; ++v66_11_label) {
        const Space v66_11_tail = child(v60_13_tail,v66_11_label);
        if (v66_11_tail.empty()) continue;
        const Path v66_11_head{v66_11_label};
        const Space v67_2 = singleton(v66_11_head);
        const Space v67_3 = intersect(constant_2,v67_2);
        const Space v67_4 = (has_head(v67_3) ? constant_3 : Space{});
        const Space v67_5 = subtract(constant_1,v67_4);
        Space v67_8;
        if (!v67_5.empty()) {
          const Path v68_6 = concat_path(v66_6,v66_11_head);
          const Space v68_7 = routine_13(c, v68_6, p1, v66_11_tail, s1);
          v67_8 = compose(v67_5,v68_7);
        }
        const Space v67_9 = intersect(constant_2,v67_2);
        const Space v67_10 = (has_head(v67_9) ? constant_3 : Space{});
        Space v67_12;
        if (!v67_10.empty()) {
          const Path v69_6 = concat_path(v66_6,v66_11_head);
          const Space v69_11 = routine_10(c, v69_6, p1, v66_11_tail, s1);
          v67_12 = compose(v67_10,v69_11);
        }
        const Space v67_13 = unite(v67_8,v67_12);
        v66_11_result = unite(v66_11_result,v67_13);
      }
      const Space v66_11 = std::move(v66_11_result);
      v61_12 = compose(v61_10,v66_11);
    }
    const Space v61_13 = unite(v61_8,v61_12);
    v60_13_result = unite(v60_13_result,v61_13);
  }
  const Space v60_13 = std::move(v60_13_result);
  return v60_13;
}

static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v70_8 = unwrap(s1,constant_0);
  const Space v70_9 = unwrap(v70_8,p0);
  Space v70_16_result;
  for (int v70_16_label = 1; v70_16_label <= 2; ++v70_16_label) {
    const Space v70_16_tail = child(s0,v70_16_label);
    if (v70_16_tail.empty()) continue;
    const Path v70_16_head{v70_16_label};
    const Space v71_2 = singleton(v70_16_head);
    const Space v71_3 = intersect(constant_2,v71_2);
    const Space v71_4 = (has_head(v71_3) ? constant_3 : Space{});
    const Space v71_5 = subtract(constant_1,v71_4);
    Space v71_8;
    if (!v71_5.empty()) {
      const Path v72_6 = concat_path(p0,v70_16_head);
      Space v72_7_result;
      for (int v72_7_label = 1; v72_7_label <= 2; ++v72_7_label) {
        const Space v72_7_tail = child(v70_16_tail,v72_7_label);
        if (v72_7_tail.empty()) continue;
        const Path v72_7_head{v72_7_label};
        const Space v73_2 = singleton(v72_7_head);
        const Space v73_3 = intersect(constant_2,v73_2);
        const Space v73_4 = (has_head(v73_3) ? constant_3 : Space{});
        const Space v73_5 = subtract(constant_1,v73_4);
        Space v73_8;
        if (!v73_5.empty()) {
          const Path v74_6 = concat_path(v72_6,v72_7_head);
          const Space v74_7 = routine_13(c, v74_6, p1, v72_7_tail, s1);
          v73_8 = compose(v73_5,v74_7);
        }
        const Space v73_9 = intersect(constant_2,v73_2);
        const Space v73_10 = (has_head(v73_9) ? constant_3 : Space{});
        Space v73_12;
        if (!v73_10.empty()) {
          const Path v75_6 = concat_path(v72_6,v72_7_head);
          const Space v75_11 = routine_14(c, v75_6, p1, v72_7_tail, s1);
          v73_12 = compose(v73_10,v75_11);
        }
        const Space v73_13 = unite(v73_8,v73_12);
        v72_7_result = unite(v72_7_result,v73_13);
      }
      const Space v72_7 = std::move(v72_7_result);
      v71_8 = compose(v71_5,v72_7);
    }
    const Space v71_9 = intersect(constant_2,v71_2);
    const Space v71_10 = (has_head(v71_9) ? constant_3 : Space{});
    Space v71_13;
    if (!v71_10.empty()) {
      const Space v76_11 = unwrap(v70_9,v70_16_head);
      Space v76_12_result;
      for (int v76_12_label = 1; v76_12_label <= 2; ++v76_12_label) {
        const Space v76_12_tail = child(v76_11,v76_12_label);
        if (v76_12_tail.empty()) continue;
        const Path v76_12_head{v76_12_label};
        const Space v77_2 = singleton(v76_12_head);
        const Space v77_3 = intersect(constant_2,v77_2);
        const Space v77_4 = (has_head(v77_3) ? constant_3 : Space{});
        const Space v77_5 = subtract(constant_1,v77_4);
        Space v77_7;
        if (!v77_5.empty()) {
          const Space v78_6 = routine_15(c, v76_12_head, p1, v76_12_tail);
          v77_7 = compose(v77_5,v78_6);
        }
        const Space v77_8 = intersect(constant_2,v77_2);
        const Space v77_9 = (has_head(v77_8) ? constant_3 : Space{});
        Space v77_11;
        if (!v77_9.empty()) {
          const Space v79_10 = routine_16(c, v76_12_head, p1, v76_12_tail);
          v77_11 = compose(v77_9,v79_10);
        }
        const Space v77_12 = unite(v77_7,v77_11);
        v76_12_result = unite(v76_12_result,v77_12);
      }
      const Space v76_12 = std::move(v76_12_result);
      v71_13 = compose(v71_10,v76_12);
    }
    const Space v71_14 = unite(v71_8,v71_13);
    v70_16_result = unite(v70_16_result,v71_14);
  }
  const Space v70_16 = std::move(v70_16_result);
  return v70_16;
}

static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v80_13_result;
  for (int v80_13_label = 1; v80_13_label <= 2; ++v80_13_label) {
    const Space v80_13_tail = child(s0,v80_13_label);
    if (v80_13_tail.empty()) continue;
    const Path v80_13_head{v80_13_label};
    const Space v81_2 = singleton(v80_13_head);
    const Space v81_3 = intersect(constant_2,v81_2);
    const Space v81_4 = (has_head(v81_3) ? constant_3 : Space{});
    const Space v81_5 = subtract(constant_1,v81_4);
    Space v81_8;
    if (!v81_5.empty()) {
      const Path v82_6 = concat_path(p0,v80_13_head);
      Space v82_7_result;
      for (int v82_7_label = 1; v82_7_label <= 2; ++v82_7_label) {
        const Space v82_7_tail = child(v80_13_tail,v82_7_label);
        if (v82_7_tail.empty()) continue;
        const Path v82_7_head{v82_7_label};
        const Space v83_2 = singleton(v82_7_head);
        const Space v83_3 = intersect(constant_2,v83_2);
        const Space v83_4 = (has_head(v83_3) ? constant_3 : Space{});
        const Space v83_5 = subtract(constant_1,v83_4);
        Space v83_8;
        if (!v83_5.empty()) {
          const Path v84_6 = concat_path(v82_6,v82_7_head);
          const Space v84_7 = routine_17(c, v84_6, p1, v82_7_tail, s1);
          v83_8 = compose(v83_5,v84_7);
        }
        const Space v83_9 = intersect(constant_2,v83_2);
        const Space v83_10 = (has_head(v83_9) ? constant_3 : Space{});
        Space v83_12;
        if (!v83_10.empty()) {
          const Path v85_6 = concat_path(v82_6,v82_7_head);
          const Space v85_11 = routine_18(c, v85_6, p1, v82_7_tail, s1);
          v83_12 = compose(v83_10,v85_11);
        }
        const Space v83_13 = unite(v83_8,v83_12);
        v82_7_result = unite(v82_7_result,v83_13);
      }
      const Space v82_7 = std::move(v82_7_result);
      v81_8 = compose(v81_5,v82_7);
    }
    const Space v81_9 = intersect(constant_2,v81_2);
    const Space v81_10 = (has_head(v81_9) ? constant_3 : Space{});
    Space v81_12;
    if (!v81_10.empty()) {
      const Path v86_6 = concat_path(p0,v80_13_head);
      Space v86_11_result;
      for (int v86_11_label = 1; v86_11_label <= 2; ++v86_11_label) {
        const Space v86_11_tail = child(v80_13_tail,v86_11_label);
        if (v86_11_tail.empty()) continue;
        const Path v86_11_head{v86_11_label};
        const Space v87_2 = singleton(v86_11_head);
        const Space v87_3 = intersect(constant_2,v87_2);
        const Space v87_4 = (has_head(v87_3) ? constant_3 : Space{});
        const Space v87_5 = subtract(constant_1,v87_4);
        Space v87_8;
        if (!v87_5.empty()) {
          const Path v88_6 = concat_path(v86_6,v86_11_head);
          const Space v88_7 = routine_17(c, v88_6, p1, v86_11_tail, s1);
          v87_8 = compose(v87_5,v88_7);
        }
        const Space v87_9 = intersect(constant_2,v87_2);
        const Space v87_10 = (has_head(v87_9) ? constant_3 : Space{});
        Space v87_12;
        if (!v87_10.empty()) {
          const Path v89_6 = concat_path(v86_6,v86_11_head);
          const Space v89_11 = routine_10(c, v89_6, p1, v86_11_tail, s1);
          v87_12 = compose(v87_10,v89_11);
        }
        const Space v87_13 = unite(v87_8,v87_12);
        v86_11_result = unite(v86_11_result,v87_13);
      }
      const Space v86_11 = std::move(v86_11_result);
      v81_12 = compose(v81_10,v86_11);
    }
    const Space v81_13 = unite(v81_8,v81_12);
    v80_13_result = unite(v80_13_result,v81_13);
  }
  const Space v80_13 = std::move(v80_13_result);
  return v80_13;
}

static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v90_8 = unwrap(s1,constant_0);
  const Space v90_9 = unwrap(v90_8,p0);
  Space v90_16_result;
  for (int v90_16_label = 1; v90_16_label <= 2; ++v90_16_label) {
    const Space v90_16_tail = child(s0,v90_16_label);
    if (v90_16_tail.empty()) continue;
    const Path v90_16_head{v90_16_label};
    const Space v91_2 = singleton(v90_16_head);
    const Space v91_3 = intersect(constant_2,v91_2);
    const Space v91_4 = (has_head(v91_3) ? constant_3 : Space{});
    const Space v91_5 = subtract(constant_1,v91_4);
    Space v91_8;
    if (!v91_5.empty()) {
      const Path v92_6 = concat_path(p0,v90_16_head);
      Space v92_7_result;
      for (int v92_7_label = 1; v92_7_label <= 2; ++v92_7_label) {
        const Space v92_7_tail = child(v90_16_tail,v92_7_label);
        if (v92_7_tail.empty()) continue;
        const Path v92_7_head{v92_7_label};
        const Space v93_2 = singleton(v92_7_head);
        const Space v93_3 = intersect(constant_2,v93_2);
        const Space v93_4 = (has_head(v93_3) ? constant_3 : Space{});
        const Space v93_5 = subtract(constant_1,v93_4);
        Space v93_8;
        if (!v93_5.empty()) {
          const Path v94_6 = concat_path(v92_6,v92_7_head);
          const Space v94_7 = routine_17(c, v94_6, p1, v92_7_tail, s1);
          v93_8 = compose(v93_5,v94_7);
        }
        const Space v93_9 = intersect(constant_2,v93_2);
        const Space v93_10 = (has_head(v93_9) ? constant_3 : Space{});
        Space v93_12;
        if (!v93_10.empty()) {
          const Path v95_6 = concat_path(v92_6,v92_7_head);
          const Space v95_11 = routine_18(c, v95_6, p1, v92_7_tail, s1);
          v93_12 = compose(v93_10,v95_11);
        }
        const Space v93_13 = unite(v93_8,v93_12);
        v92_7_result = unite(v92_7_result,v93_13);
      }
      const Space v92_7 = std::move(v92_7_result);
      v91_8 = compose(v91_5,v92_7);
    }
    const Space v91_9 = intersect(constant_2,v91_2);
    const Space v91_10 = (has_head(v91_9) ? constant_3 : Space{});
    Space v91_13;
    if (!v91_10.empty()) {
      const Space v96_11 = unwrap(v90_9,v90_16_head);
      Space v96_12_result;
      for (int v96_12_label = 1; v96_12_label <= 2; ++v96_12_label) {
        const Space v96_12_tail = child(v96_11,v96_12_label);
        if (v96_12_tail.empty()) continue;
        const Path v96_12_head{v96_12_label};
        const Space v97_2 = singleton(v96_12_head);
        const Space v97_3 = intersect(constant_2,v97_2);
        const Space v97_4 = (has_head(v97_3) ? constant_3 : Space{});
        const Space v97_5 = subtract(constant_1,v97_4);
        Space v97_7;
        if (!v97_5.empty()) {
          const Space v98_6 = routine_15(c, v96_12_head, p1, v96_12_tail);
          v97_7 = compose(v97_5,v98_6);
        }
        const Space v97_8 = intersect(constant_2,v97_2);
        const Space v97_9 = (has_head(v97_8) ? constant_3 : Space{});
        Space v97_11;
        if (!v97_9.empty()) {
          const Space v99_10 = routine_16(c, v96_12_head, p1, v96_12_tail);
          v97_11 = compose(v97_9,v99_10);
        }
        const Space v97_12 = unite(v97_7,v97_11);
        v96_12_result = unite(v96_12_result,v97_12);
      }
      const Space v96_12 = std::move(v96_12_result);
      v91_13 = compose(v91_10,v96_12);
    }
    const Space v91_14 = unite(v91_8,v91_13);
    v90_16_result = unite(v90_16_result,v91_14);
  }
  const Space v90_16 = std::move(v90_16_result);
  return v90_16;
}

static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v100_5 = unwrap(s1,constant_0);
  const Space v100_6 = unwrap(v100_5,p0);
  Space v100_16_result;
  for (int v100_16_label = 1; v100_16_label <= 2; ++v100_16_label) {
    const Space v100_16_tail = child(v100_6,v100_16_label);
    if (v100_16_tail.empty()) continue;
    const Path v100_16_head{v100_16_label};
    const Space v101_2 = singleton(v100_16_head);
    const Space v101_3 = intersect(constant_2,v101_2);
    const Space v101_4 = (has_head(v101_3) ? constant_3 : Space{});
    const Space v101_5 = subtract(constant_1,v101_4);
    Space v101_7;
    if (!v101_5.empty()) {
      Space v102_6_result;
      for (int v102_6_label = 1; v102_6_label <= 2; ++v102_6_label) {
        const Space v102_6_tail = child(v100_16_tail,v102_6_label);
        if (v102_6_tail.empty()) continue;
        const Path v102_6_head{v102_6_label};
        const Space v103_2 = singleton(v102_6_head);
        const Space v103_3 = intersect(constant_2,v103_2);
        const Space v103_4 = (has_head(v103_3) ? constant_3 : Space{});
        const Space v103_5 = subtract(constant_1,v103_4);
        Space v103_8;
        if (!v103_5.empty()) {
          const Path v104_6 = concat_path(v100_16_head,v102_6_head);
          const Space v104_7 = routine_19(c, v104_6, p1, v102_6_tail);
          v103_8 = compose(v103_5,v104_7);
        }
        const Space v103_9 = intersect(constant_2,v103_2);
        const Space v103_10 = (has_head(v103_9) ? constant_3 : Space{});
        Space v103_12;
        if (!v103_10.empty()) {
          const Path v105_6 = concat_path(v100_16_head,v102_6_head);
          const Space v105_11 = routine_20(c, v105_6, p1, v102_6_tail);
          v103_12 = compose(v103_10,v105_11);
        }
        const Space v103_13 = unite(v103_8,v103_12);
        v102_6_result = unite(v102_6_result,v103_13);
      }
      const Space v102_6 = std::move(v102_6_result);
      v101_7 = compose(v101_5,v102_6);
    }
    const Space v101_8 = intersect(constant_2,v101_2);
    const Space v101_9 = (has_head(v101_8) ? constant_3 : Space{});
    Space v101_11;
    if (!v101_9.empty()) {
      Space v106_10_result;
      for (int v106_10_label = 1; v106_10_label <= 2; ++v106_10_label) {
        const Space v106_10_tail = child(v100_16_tail,v106_10_label);
        if (v106_10_tail.empty()) continue;
        const Path v106_10_head{v106_10_label};
        const Space v107_2 = singleton(v106_10_head);
        const Space v107_3 = intersect(constant_2,v107_2);
        const Space v107_4 = (has_head(v107_3) ? constant_3 : Space{});
        const Space v107_5 = subtract(constant_1,v107_4);
        Space v107_8;
        if (!v107_5.empty()) {
          const Path v108_6 = concat_path(v100_16_head,v106_10_head);
          const Space v108_7 = routine_19(c, v108_6, p1, v106_10_tail);
          v107_8 = compose(v107_5,v108_7);
        }
        const Space v107_9 = intersect(constant_2,v107_2);
        const Space v107_10 = (has_head(v107_9) ? constant_3 : Space{});
        Space v107_12;
        if (!v107_10.empty()) {
          const Path v109_6 = concat_path(v100_16_head,v106_10_head);
          const Space v109_11 = routine_21(c, v109_6, p1, v106_10_tail);
          v107_12 = compose(v107_10,v109_11);
        }
        const Space v107_13 = unite(v107_8,v107_12);
        v106_10_result = unite(v106_10_result,v107_13);
      }
      const Space v106_10 = std::move(v106_10_result);
      v101_11 = compose(v101_9,v106_10);
    }
    const Space v101_12 = unite(v101_7,v101_11);
    v100_16_result = unite(v100_16_result,v101_12);
  }
  const Space v100_16 = std::move(v100_16_result);
  return v100_16;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v110_12_result;
  for (int v110_12_label = 1; v110_12_label <= 2; ++v110_12_label) {
    const Space v110_12_tail = child(s0,v110_12_label);
    if (v110_12_tail.empty()) continue;
    const Path v110_12_head{v110_12_label};
    const Space v111_2 = singleton(v110_12_head);
    const Space v111_3 = intersect(constant_2,v111_2);
    const Space v111_4 = (has_head(v111_3) ? constant_3 : Space{});
    const Space v111_5 = subtract(constant_1,v111_4);
    Space v111_8;
    if (!v111_5.empty()) {
      const Path v112_6 = concat_path(p0,v110_12_head);
      Space v112_7_result;
      for (int v112_7_label = 1; v112_7_label <= 2; ++v112_7_label) {
        const Space v112_7_tail = child(v110_12_tail,v112_7_label);
        if (v112_7_tail.empty()) continue;
        const Path v112_7_head{v112_7_label};
        const Space v113_2 = singleton(v112_7_head);
        const Space v113_3 = intersect(constant_2,v113_2);
        const Space v113_4 = (has_head(v113_3) ? constant_3 : Space{});
        const Space v113_5 = subtract(constant_1,v113_4);
        Space v113_8;
        if (!v113_5.empty()) {
          const Path v114_6 = concat_path(v112_6,v112_7_head);
          const Space v114_7 = routine_22(c, v114_6, v112_7_tail, s1);
          v113_8 = compose(v113_5,v114_7);
        }
        const Space v113_9 = intersect(constant_2,v113_2);
        const Space v113_10 = (has_head(v113_9) ? constant_3 : Space{});
        Space v113_12;
        if (!v113_10.empty()) {
          const Path v115_6 = concat_path(v112_6,v112_7_head);
          const Space v115_11 = routine_23(c, v115_6, v112_7_tail, s1);
          v113_12 = compose(v113_10,v115_11);
        }
        const Space v113_13 = unite(v113_8,v113_12);
        v112_7_result = unite(v112_7_result,v113_13);
      }
      const Space v112_7 = std::move(v112_7_result);
      v111_8 = compose(v111_5,v112_7);
    }
    const Space v111_9 = intersect(constant_2,v111_2);
    const Space v111_10 = (has_head(v111_9) ? constant_3 : Space{});
    Space v111_12;
    if (!v111_10.empty()) {
      const Path v116_6 = concat_path(p0,v110_12_head);
      Space v116_11_result;
      for (int v116_11_label = 1; v116_11_label <= 2; ++v116_11_label) {
        const Space v116_11_tail = child(v110_12_tail,v116_11_label);
        if (v116_11_tail.empty()) continue;
        const Path v116_11_head{v116_11_label};
        const Space v117_2 = singleton(v116_11_head);
        const Space v117_3 = intersect(constant_2,v117_2);
        const Space v117_4 = (has_head(v117_3) ? constant_3 : Space{});
        const Space v117_5 = subtract(constant_1,v117_4);
        Space v117_8;
        if (!v117_5.empty()) {
          const Path v118_6 = concat_path(v116_6,v116_11_head);
          const Space v118_7 = routine_22(c, v118_6, v116_11_tail, s1);
          v117_8 = compose(v117_5,v118_7);
        }
        const Space v117_9 = intersect(constant_2,v117_2);
        const Space v117_10 = (has_head(v117_9) ? constant_3 : Space{});
        Space v117_12;
        if (!v117_10.empty()) {
          const Path v119_6 = concat_path(v116_6,v116_11_head);
          const Space v119_11 = routine_3(c, v119_6, v116_11_tail, s1);
          v117_12 = compose(v117_10,v119_11);
        }
        const Space v117_13 = unite(v117_8,v117_12);
        v116_11_result = unite(v116_11_result,v117_13);
      }
      const Space v116_11 = std::move(v116_11_result);
      v111_12 = compose(v111_10,v116_11);
    }
    const Space v111_13 = unite(v111_8,v111_12);
    v110_12_result = unite(v110_12_result,v111_13);
  }
  const Space v110_12 = std::move(v110_12_result);
  return v110_12;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v120_12_result;
  for (int v120_12_label = 1; v120_12_label <= 2; ++v120_12_label) {
    const Space v120_12_tail = child(s0,v120_12_label);
    if (v120_12_tail.empty()) continue;
    const Path v120_12_head{v120_12_label};
    const Space v121_2 = singleton(v120_12_head);
    const Space v121_3 = intersect(constant_2,v121_2);
    const Space v121_4 = (has_head(v121_3) ? constant_3 : Space{});
    const Space v121_5 = subtract(constant_1,v121_4);
    Space v121_8;
    if (!v121_5.empty()) {
      const Path v122_6 = concat_path(p0,v120_12_head);
      Space v122_7_result;
      for (int v122_7_label = 1; v122_7_label <= 2; ++v122_7_label) {
        const Space v122_7_tail = child(v120_12_tail,v122_7_label);
        if (v122_7_tail.empty()) continue;
        const Path v122_7_head{v122_7_label};
        const Space v123_2 = singleton(v122_7_head);
        const Space v123_3 = intersect(constant_2,v123_2);
        const Space v123_4 = (has_head(v123_3) ? constant_3 : Space{});
        const Space v123_5 = subtract(constant_1,v123_4);
        Space v123_8;
        if (!v123_5.empty()) {
          const Path v124_6 = concat_path(v122_6,v122_7_head);
          const Space v124_7 = routine_22(c, v124_6, v122_7_tail, s1);
          v123_8 = compose(v123_5,v124_7);
        }
        const Space v123_9 = intersect(constant_2,v123_2);
        const Space v123_10 = (has_head(v123_9) ? constant_3 : Space{});
        Space v123_12;
        if (!v123_10.empty()) {
          const Path v125_6 = concat_path(v122_6,v122_7_head);
          const Space v125_11 = routine_23(c, v125_6, v122_7_tail, s1);
          v123_12 = compose(v123_10,v125_11);
        }
        const Space v123_13 = unite(v123_8,v123_12);
        v122_7_result = unite(v122_7_result,v123_13);
      }
      const Space v122_7 = std::move(v122_7_result);
      v121_8 = compose(v121_5,v122_7);
    }
    const Space v121_9 = intersect(constant_2,v121_2);
    const Space v121_10 = (has_head(v121_9) ? constant_3 : Space{});
    Space v121_12;
    if (!v121_10.empty()) {
      const Path v126_6 = concat_path(p0,v120_12_head);
      Space v126_11_result;
      for (int v126_11_label = 1; v126_11_label <= 2; ++v126_11_label) {
        const Space v126_11_tail = child(v120_12_tail,v126_11_label);
        if (v126_11_tail.empty()) continue;
        const Path v126_11_head{v126_11_label};
        const Space v127_2 = singleton(v126_11_head);
        const Space v127_3 = intersect(constant_2,v127_2);
        const Space v127_4 = (has_head(v127_3) ? constant_3 : Space{});
        const Space v127_5 = subtract(constant_1,v127_4);
        Space v127_7;
        if (!v127_5.empty()) {
          const Space v128_6 = routine_6(c, v126_11_head, v126_6, v126_11_tail, s1);
          v127_7 = compose(v127_5,v128_6);
        }
        const Space v127_8 = intersect(constant_2,v127_2);
        const Space v127_9 = (has_head(v127_8) ? constant_3 : Space{});
        Space v127_11;
        if (!v127_9.empty()) {
          const Space v129_10 = routine_7(c, v126_11_head, v126_6, v126_11_tail, s1);
          v127_11 = compose(v127_9,v129_10);
        }
        const Space v127_12 = unite(v127_7,v127_11);
        v126_11_result = unite(v126_11_result,v127_12);
      }
      const Space v126_11 = std::move(v126_11_result);
      v121_12 = compose(v121_10,v126_11);
    }
    const Space v121_13 = unite(v121_8,v121_12);
    v120_12_result = unite(v120_12_result,v121_13);
  }
  const Space v120_12 = std::move(v120_12_result);
  return v120_12;
}

static Space routine_13(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v130_13_result;
  for (int v130_13_label = 1; v130_13_label <= 2; ++v130_13_label) {
    const Space v130_13_tail = child(s0,v130_13_label);
    if (v130_13_tail.empty()) continue;
    const Path v130_13_head{v130_13_label};
    const Space v131_2 = singleton(v130_13_head);
    const Space v131_3 = intersect(constant_2,v131_2);
    const Space v131_4 = (has_head(v131_3) ? constant_3 : Space{});
    const Space v131_5 = subtract(constant_1,v131_4);
    Space v131_8;
    if (!v131_5.empty()) {
      const Path v132_6 = concat_path(p0,v130_13_head);
      Space v132_7_result;
      for (int v132_7_label = 1; v132_7_label <= 2; ++v132_7_label) {
        const Space v132_7_tail = child(v130_13_tail,v132_7_label);
        if (v132_7_tail.empty()) continue;
        const Path v132_7_head{v132_7_label};
        const Space v133_2 = singleton(v132_7_head);
        const Space v133_3 = intersect(constant_2,v133_2);
        const Space v133_4 = (has_head(v133_3) ? constant_3 : Space{});
        const Space v133_5 = subtract(constant_1,v133_4);
        Space v133_8;
        if (!v133_5.empty()) {
          const Path v134_6 = concat_path(v132_6,v132_7_head);
          const Space v134_7 = routine_24(c, v134_6, p1, v132_7_tail, s1);
          v133_8 = compose(v133_5,v134_7);
        }
        const Space v133_9 = intersect(constant_2,v133_2);
        const Space v133_10 = (has_head(v133_9) ? constant_3 : Space{});
        Space v133_12;
        if (!v133_10.empty()) {
          const Path v135_6 = concat_path(v132_6,v132_7_head);
          const Space v135_11 = routine_25(c, v135_6, p1, v132_7_tail, s1);
          v133_12 = compose(v133_10,v135_11);
        }
        const Space v133_13 = unite(v133_8,v133_12);
        v132_7_result = unite(v132_7_result,v133_13);
      }
      const Space v132_7 = std::move(v132_7_result);
      v131_8 = compose(v131_5,v132_7);
    }
    const Space v131_9 = intersect(constant_2,v131_2);
    const Space v131_10 = (has_head(v131_9) ? constant_3 : Space{});
    Space v131_12;
    if (!v131_10.empty()) {
      const Path v136_6 = concat_path(p0,v130_13_head);
      Space v136_11_result;
      for (int v136_11_label = 1; v136_11_label <= 2; ++v136_11_label) {
        const Space v136_11_tail = child(v130_13_tail,v136_11_label);
        if (v136_11_tail.empty()) continue;
        const Path v136_11_head{v136_11_label};
        const Space v137_2 = singleton(v136_11_head);
        const Space v137_3 = intersect(constant_2,v137_2);
        const Space v137_4 = (has_head(v137_3) ? constant_3 : Space{});
        const Space v137_5 = subtract(constant_1,v137_4);
        Space v137_8;
        if (!v137_5.empty()) {
          const Path v138_6 = concat_path(v136_6,v136_11_head);
          const Space v138_7 = routine_24(c, v138_6, p1, v136_11_tail, s1);
          v137_8 = compose(v137_5,v138_7);
        }
        const Space v137_9 = intersect(constant_2,v137_2);
        const Space v137_10 = (has_head(v137_9) ? constant_3 : Space{});
        Space v137_12;
        if (!v137_10.empty()) {
          const Path v139_6 = concat_path(v136_6,v136_11_head);
          const Space v139_11 = routine_10(c, v139_6, p1, v136_11_tail, s1);
          v137_12 = compose(v137_10,v139_11);
        }
        const Space v137_13 = unite(v137_8,v137_12);
        v136_11_result = unite(v136_11_result,v137_13);
      }
      const Space v136_11 = std::move(v136_11_result);
      v131_12 = compose(v131_10,v136_11);
    }
    const Space v131_13 = unite(v131_8,v131_12);
    v130_13_result = unite(v130_13_result,v131_13);
  }
  const Space v130_13 = std::move(v130_13_result);
  return v130_13;
}

static Space routine_14(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v140_8 = unwrap(s1,constant_0);
  const Space v140_9 = unwrap(v140_8,p0);
  Space v140_16_result;
  for (int v140_16_label = 1; v140_16_label <= 2; ++v140_16_label) {
    const Space v140_16_tail = child(s0,v140_16_label);
    if (v140_16_tail.empty()) continue;
    const Path v140_16_head{v140_16_label};
    const Space v141_2 = singleton(v140_16_head);
    const Space v141_3 = intersect(constant_2,v141_2);
    const Space v141_4 = (has_head(v141_3) ? constant_3 : Space{});
    const Space v141_5 = subtract(constant_1,v141_4);
    Space v141_8;
    if (!v141_5.empty()) {
      const Path v142_6 = concat_path(p0,v140_16_head);
      Space v142_7_result;
      for (int v142_7_label = 1; v142_7_label <= 2; ++v142_7_label) {
        const Space v142_7_tail = child(v140_16_tail,v142_7_label);
        if (v142_7_tail.empty()) continue;
        const Path v142_7_head{v142_7_label};
        const Space v143_2 = singleton(v142_7_head);
        const Space v143_3 = intersect(constant_2,v143_2);
        const Space v143_4 = (has_head(v143_3) ? constant_3 : Space{});
        const Space v143_5 = subtract(constant_1,v143_4);
        Space v143_8;
        if (!v143_5.empty()) {
          const Path v144_6 = concat_path(v142_6,v142_7_head);
          const Space v144_7 = routine_24(c, v144_6, p1, v142_7_tail, s1);
          v143_8 = compose(v143_5,v144_7);
        }
        const Space v143_9 = intersect(constant_2,v143_2);
        const Space v143_10 = (has_head(v143_9) ? constant_3 : Space{});
        Space v143_12;
        if (!v143_10.empty()) {
          const Path v145_6 = concat_path(v142_6,v142_7_head);
          const Space v145_11 = routine_25(c, v145_6, p1, v142_7_tail, s1);
          v143_12 = compose(v143_10,v145_11);
        }
        const Space v143_13 = unite(v143_8,v143_12);
        v142_7_result = unite(v142_7_result,v143_13);
      }
      const Space v142_7 = std::move(v142_7_result);
      v141_8 = compose(v141_5,v142_7);
    }
    const Space v141_9 = intersect(constant_2,v141_2);
    const Space v141_10 = (has_head(v141_9) ? constant_3 : Space{});
    Space v141_13;
    if (!v141_10.empty()) {
      const Space v146_11 = unwrap(v140_9,v140_16_head);
      Space v146_12_result;
      for (int v146_12_label = 1; v146_12_label <= 2; ++v146_12_label) {
        const Space v146_12_tail = child(v146_11,v146_12_label);
        if (v146_12_tail.empty()) continue;
        const Path v146_12_head{v146_12_label};
        const Space v147_2 = singleton(v146_12_head);
        const Space v147_3 = intersect(constant_2,v147_2);
        const Space v147_4 = (has_head(v147_3) ? constant_3 : Space{});
        const Space v147_5 = subtract(constant_1,v147_4);
        Space v147_7;
        if (!v147_5.empty()) {
          const Space v148_6 = routine_15(c, v146_12_head, p1, v146_12_tail);
          v147_7 = compose(v147_5,v148_6);
        }
        const Space v147_8 = intersect(constant_2,v147_2);
        const Space v147_9 = (has_head(v147_8) ? constant_3 : Space{});
        Space v147_11;
        if (!v147_9.empty()) {
          const Space v149_10 = routine_16(c, v146_12_head, p1, v146_12_tail);
          v147_11 = compose(v147_9,v149_10);
        }
        const Space v147_12 = unite(v147_7,v147_11);
        v146_12_result = unite(v146_12_result,v147_12);
      }
      const Space v146_12 = std::move(v146_12_result);
      v141_13 = compose(v141_10,v146_12);
    }
    const Space v141_14 = unite(v141_8,v141_13);
    v140_16_result = unite(v140_16_result,v141_14);
  }
  const Space v140_16 = std::move(v140_16_result);
  return v140_16;
}

static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v150_12_result;
  for (int v150_12_label = 1; v150_12_label <= 2; ++v150_12_label) {
    const Space v150_12_tail = child(s0,v150_12_label);
    if (v150_12_tail.empty()) continue;
    const Path v150_12_head{v150_12_label};
    const Space v151_2 = singleton(v150_12_head);
    const Space v151_3 = intersect(constant_2,v151_2);
    const Space v151_4 = (has_head(v151_3) ? constant_3 : Space{});
    const Space v151_5 = subtract(constant_1,v151_4);
    Space v151_8;
    if (!v151_5.empty()) {
      const Path v152_6 = concat_path(p0,v150_12_head);
      Space v152_7_result;
      for (int v152_7_label = 1; v152_7_label <= 2; ++v152_7_label) {
        const Space v152_7_tail = child(v150_12_tail,v152_7_label);
        if (v152_7_tail.empty()) continue;
        const Path v152_7_head{v152_7_label};
        const Space v153_2 = singleton(v152_7_head);
        const Space v153_3 = intersect(constant_2,v153_2);
        const Space v153_4 = (has_head(v153_3) ? constant_3 : Space{});
        const Space v153_5 = subtract(constant_1,v153_4);
        Space v153_8;
        if (!v153_5.empty()) {
          const Path v154_6 = concat_path(v152_6,v152_7_head);
          const Space v154_7 = routine_26(c, v154_6, p1, v152_7_tail);
          v153_8 = compose(v153_5,v154_7);
        }
        const Space v153_9 = intersect(constant_2,v153_2);
        const Space v153_10 = (has_head(v153_9) ? constant_3 : Space{});
        Space v153_12;
        if (!v153_10.empty()) {
          const Path v155_6 = concat_path(v152_6,v152_7_head);
          const Space v155_11 = routine_27(c, v155_6, p1, v152_7_tail);
          v153_12 = compose(v153_10,v155_11);
        }
        const Space v153_13 = unite(v153_8,v153_12);
        v152_7_result = unite(v152_7_result,v153_13);
      }
      const Space v152_7 = std::move(v152_7_result);
      v151_8 = compose(v151_5,v152_7);
    }
    const Space v151_9 = intersect(constant_2,v151_2);
    const Space v151_10 = (has_head(v151_9) ? constant_3 : Space{});
    Space v151_12;
    if (!v151_10.empty()) {
      const Path v156_6 = concat_path(p0,v150_12_head);
      Space v156_11_result;
      for (int v156_11_label = 1; v156_11_label <= 2; ++v156_11_label) {
        const Space v156_11_tail = child(v150_12_tail,v156_11_label);
        if (v156_11_tail.empty()) continue;
        const Path v156_11_head{v156_11_label};
        const Space v157_2 = singleton(v156_11_head);
        const Space v157_3 = intersect(constant_2,v157_2);
        const Space v157_4 = (has_head(v157_3) ? constant_3 : Space{});
        const Space v157_5 = subtract(constant_1,v157_4);
        Space v157_8;
        if (!v157_5.empty()) {
          const Path v158_6 = concat_path(v156_6,v156_11_head);
          const Space v158_7 = routine_26(c, v158_6, p1, v156_11_tail);
          v157_8 = compose(v157_5,v158_7);
        }
        const Space v157_9 = intersect(constant_2,v157_2);
        const Space v157_10 = (has_head(v157_9) ? constant_3 : Space{});
        Space v157_12;
        if (!v157_10.empty()) {
          const Path v159_6 = concat_path(v156_6,v156_11_head);
          const Space v159_11 = routine_21(c, v159_6, p1, v156_11_tail);
          v157_12 = compose(v157_10,v159_11);
        }
        const Space v157_13 = unite(v157_8,v157_12);
        v156_11_result = unite(v156_11_result,v157_13);
      }
      const Space v156_11 = std::move(v156_11_result);
      v151_12 = compose(v151_10,v156_11);
    }
    const Space v151_13 = unite(v151_8,v151_12);
    v150_12_result = unite(v150_12_result,v151_13);
  }
  const Space v150_12 = std::move(v150_12_result);
  return v150_12;
}

static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v160_9_result;
  for (int v160_9_label = 1; v160_9_label <= 2; ++v160_9_label) {
    const Space v160_9_tail = child(s0,v160_9_label);
    if (v160_9_tail.empty()) continue;
    const Path v160_9_head{v160_9_label};
    const Space v161_2 = singleton(v160_9_head);
    const Space v161_3 = intersect(constant_2,v161_2);
    const Space v161_4 = (has_head(v161_3) ? constant_3 : Space{});
    const Space v161_5 = subtract(constant_1,v161_4);
    Space v161_8;
    if (!v161_5.empty()) {
      const Path v162_6 = concat_path(p0,v160_9_head);
      Space v162_7_result;
      for (int v162_7_label = 1; v162_7_label <= 2; ++v162_7_label) {
        const Space v162_7_tail = child(v160_9_tail,v162_7_label);
        if (v162_7_tail.empty()) continue;
        const Path v162_7_head{v162_7_label};
        const Space v163_2 = singleton(v162_7_head);
        const Space v163_3 = intersect(constant_2,v163_2);
        const Space v163_4 = (has_head(v163_3) ? constant_3 : Space{});
        const Space v163_5 = subtract(constant_1,v163_4);
        Space v163_8;
        if (!v163_5.empty()) {
          const Path v164_6 = concat_path(v162_6,v162_7_head);
          const Space v164_7 = routine_26(c, v164_6, p1, v162_7_tail);
          v163_8 = compose(v163_5,v164_7);
        }
        const Space v163_9 = intersect(constant_2,v163_2);
        const Space v163_10 = (has_head(v163_9) ? constant_3 : Space{});
        Space v163_12;
        if (!v163_10.empty()) {
          const Path v165_6 = concat_path(v162_6,v162_7_head);
          const Space v165_11 = routine_27(c, v165_6, p1, v162_7_tail);
          v163_12 = compose(v163_10,v165_11);
        }
        const Space v163_13 = unite(v163_8,v163_12);
        v162_7_result = unite(v162_7_result,v163_13);
      }
      const Space v162_7 = std::move(v162_7_result);
      v161_8 = compose(v161_5,v162_7);
    }
    const Space v161_9 = intersect(constant_2,v161_2);
    const Space v161_10 = (has_head(v161_9) ? constant_3 : Space{});
    const Space v161_11 = compose(v161_10,v160_9_tail);
    const Path v166_6 = concat_path(p0,v160_9_head);
    const Space v161_12 = wrap(v161_11,v166_6);
    const Space v161_13 = wrap(v161_12,p1);
    const Space v161_14 = unite(v161_8,v161_13);
    v160_9_result = unite(v160_9_result,v161_14);
  }
  const Space v160_9 = std::move(v160_9_result);
  return v160_9;
}

static Space routine_17(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v167_13_result;
  for (int v167_13_label = 1; v167_13_label <= 2; ++v167_13_label) {
    const Space v167_13_tail = child(s0,v167_13_label);
    if (v167_13_tail.empty()) continue;
    const Path v167_13_head{v167_13_label};
    const Space v168_2 = singleton(v167_13_head);
    const Space v168_3 = intersect(constant_2,v168_2);
    const Space v168_4 = (has_head(v168_3) ? constant_3 : Space{});
    const Space v168_5 = subtract(constant_1,v168_4);
    Space v168_8;
    if (!v168_5.empty()) {
      const Path v169_6 = concat_path(p0,v167_13_head);
      Space v169_7_result;
      for (int v169_7_label = 1; v169_7_label <= 2; ++v169_7_label) {
        const Space v169_7_tail = child(v167_13_tail,v169_7_label);
        if (v169_7_tail.empty()) continue;
        const Path v169_7_head{v169_7_label};
        const Space v170_2 = singleton(v169_7_head);
        const Space v170_3 = intersect(constant_2,v170_2);
        const Space v170_4 = (has_head(v170_3) ? constant_3 : Space{});
        const Space v170_5 = subtract(constant_1,v170_4);
        Space v170_8;
        if (!v170_5.empty()) {
          const Path v171_6 = concat_path(v169_6,v169_7_head);
          const Space v171_7 = routine_28(c, v171_6, p1, v169_7_tail, s1);
          v170_8 = compose(v170_5,v171_7);
        }
        const Space v170_9 = intersect(constant_2,v170_2);
        const Space v170_10 = (has_head(v170_9) ? constant_3 : Space{});
        Space v170_12;
        if (!v170_10.empty()) {
          const Path v172_6 = concat_path(v169_6,v169_7_head);
          const Space v172_11 = routine_29(c, v172_6, p1, v169_7_tail, s1);
          v170_12 = compose(v170_10,v172_11);
        }
        const Space v170_13 = unite(v170_8,v170_12);
        v169_7_result = unite(v169_7_result,v170_13);
      }
      const Space v169_7 = std::move(v169_7_result);
      v168_8 = compose(v168_5,v169_7);
    }
    const Space v168_9 = intersect(constant_2,v168_2);
    const Space v168_10 = (has_head(v168_9) ? constant_3 : Space{});
    Space v168_12;
    if (!v168_10.empty()) {
      const Path v173_6 = concat_path(p0,v167_13_head);
      Space v173_11_result;
      for (int v173_11_label = 1; v173_11_label <= 2; ++v173_11_label) {
        const Space v173_11_tail = child(v167_13_tail,v173_11_label);
        if (v173_11_tail.empty()) continue;
        const Path v173_11_head{v173_11_label};
        const Space v174_2 = singleton(v173_11_head);
        const Space v174_3 = intersect(constant_2,v174_2);
        const Space v174_4 = (has_head(v174_3) ? constant_3 : Space{});
        const Space v174_5 = subtract(constant_1,v174_4);
        Space v174_8;
        if (!v174_5.empty()) {
          const Path v175_6 = concat_path(v173_6,v173_11_head);
          const Space v175_7 = routine_28(c, v175_6, p1, v173_11_tail, s1);
          v174_8 = compose(v174_5,v175_7);
        }
        const Space v174_9 = intersect(constant_2,v174_2);
        const Space v174_10 = (has_head(v174_9) ? constant_3 : Space{});
        Space v174_12;
        if (!v174_10.empty()) {
          const Path v176_6 = concat_path(v173_6,v173_11_head);
          const Space v176_11 = routine_10(c, v176_6, p1, v173_11_tail, s1);
          v174_12 = compose(v174_10,v176_11);
        }
        const Space v174_13 = unite(v174_8,v174_12);
        v173_11_result = unite(v173_11_result,v174_13);
      }
      const Space v173_11 = std::move(v173_11_result);
      v168_12 = compose(v168_10,v173_11);
    }
    const Space v168_13 = unite(v168_8,v168_12);
    v167_13_result = unite(v167_13_result,v168_13);
  }
  const Space v167_13 = std::move(v167_13_result);
  return v167_13;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v177_8 = unwrap(s1,constant_0);
  const Space v177_9 = unwrap(v177_8,p0);
  Space v177_16_result;
  for (int v177_16_label = 1; v177_16_label <= 2; ++v177_16_label) {
    const Space v177_16_tail = child(s0,v177_16_label);
    if (v177_16_tail.empty()) continue;
    const Path v177_16_head{v177_16_label};
    const Space v178_2 = singleton(v177_16_head);
    const Space v178_3 = intersect(constant_2,v178_2);
    const Space v178_4 = (has_head(v178_3) ? constant_3 : Space{});
    const Space v178_5 = subtract(constant_1,v178_4);
    Space v178_8;
    if (!v178_5.empty()) {
      const Path v179_6 = concat_path(p0,v177_16_head);
      Space v179_7_result;
      for (int v179_7_label = 1; v179_7_label <= 2; ++v179_7_label) {
        const Space v179_7_tail = child(v177_16_tail,v179_7_label);
        if (v179_7_tail.empty()) continue;
        const Path v179_7_head{v179_7_label};
        const Space v180_2 = singleton(v179_7_head);
        const Space v180_3 = intersect(constant_2,v180_2);
        const Space v180_4 = (has_head(v180_3) ? constant_3 : Space{});
        const Space v180_5 = subtract(constant_1,v180_4);
        Space v180_8;
        if (!v180_5.empty()) {
          const Path v181_6 = concat_path(v179_6,v179_7_head);
          const Space v181_7 = routine_28(c, v181_6, p1, v179_7_tail, s1);
          v180_8 = compose(v180_5,v181_7);
        }
        const Space v180_9 = intersect(constant_2,v180_2);
        const Space v180_10 = (has_head(v180_9) ? constant_3 : Space{});
        Space v180_12;
        if (!v180_10.empty()) {
          const Path v182_6 = concat_path(v179_6,v179_7_head);
          const Space v182_11 = routine_29(c, v182_6, p1, v179_7_tail, s1);
          v180_12 = compose(v180_10,v182_11);
        }
        const Space v180_13 = unite(v180_8,v180_12);
        v179_7_result = unite(v179_7_result,v180_13);
      }
      const Space v179_7 = std::move(v179_7_result);
      v178_8 = compose(v178_5,v179_7);
    }
    const Space v178_9 = intersect(constant_2,v178_2);
    const Space v178_10 = (has_head(v178_9) ? constant_3 : Space{});
    Space v178_13;
    if (!v178_10.empty()) {
      const Space v183_11 = unwrap(v177_9,v177_16_head);
      Space v183_12_result;
      for (int v183_12_label = 1; v183_12_label <= 2; ++v183_12_label) {
        const Space v183_12_tail = child(v183_11,v183_12_label);
        if (v183_12_tail.empty()) continue;
        const Path v183_12_head{v183_12_label};
        const Space v184_2 = singleton(v183_12_head);
        const Space v184_3 = intersect(constant_2,v184_2);
        const Space v184_4 = (has_head(v184_3) ? constant_3 : Space{});
        const Space v184_5 = subtract(constant_1,v184_4);
        Space v184_7;
        if (!v184_5.empty()) {
          const Space v185_6 = routine_15(c, v183_12_head, p1, v183_12_tail);
          v184_7 = compose(v184_5,v185_6);
        }
        const Space v184_8 = intersect(constant_2,v184_2);
        const Space v184_9 = (has_head(v184_8) ? constant_3 : Space{});
        Space v184_11;
        if (!v184_9.empty()) {
          const Space v186_10 = routine_16(c, v183_12_head, p1, v183_12_tail);
          v184_11 = compose(v184_9,v186_10);
        }
        const Space v184_12 = unite(v184_7,v184_11);
        v183_12_result = unite(v183_12_result,v184_12);
      }
      const Space v183_12 = std::move(v183_12_result);
      v178_13 = compose(v178_10,v183_12);
    }
    const Space v178_14 = unite(v178_8,v178_13);
    v177_16_result = unite(v177_16_result,v178_14);
  }
  const Space v177_16 = std::move(v177_16_result);
  return v177_16;
}

static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v187_12_result;
  for (int v187_12_label = 1; v187_12_label <= 2; ++v187_12_label) {
    const Space v187_12_tail = child(s0,v187_12_label);
    if (v187_12_tail.empty()) continue;
    const Path v187_12_head{v187_12_label};
    const Space v188_2 = singleton(v187_12_head);
    const Space v188_3 = intersect(constant_2,v188_2);
    const Space v188_4 = (has_head(v188_3) ? constant_3 : Space{});
    const Space v188_5 = subtract(constant_1,v188_4);
    Space v188_8;
    if (!v188_5.empty()) {
      const Path v189_6 = concat_path(p0,v187_12_head);
      Space v189_7_result;
      for (int v189_7_label = 1; v189_7_label <= 2; ++v189_7_label) {
        const Space v189_7_tail = child(v187_12_tail,v189_7_label);
        if (v189_7_tail.empty()) continue;
        const Path v189_7_head{v189_7_label};
        const Space v190_2 = singleton(v189_7_head);
        const Space v190_3 = intersect(constant_2,v190_2);
        const Space v190_4 = (has_head(v190_3) ? constant_3 : Space{});
        const Space v190_5 = subtract(constant_1,v190_4);
        Space v190_8;
        if (!v190_5.empty()) {
          const Path v191_6 = concat_path(v189_6,v189_7_head);
          const Space v191_7 = routine_30(c, v191_6, p1, v189_7_tail);
          v190_8 = compose(v190_5,v191_7);
        }
        const Space v190_9 = intersect(constant_2,v190_2);
        const Space v190_10 = (has_head(v190_9) ? constant_3 : Space{});
        Space v190_12;
        if (!v190_10.empty()) {
          const Path v192_6 = concat_path(v189_6,v189_7_head);
          const Space v192_11 = routine_31(c, v192_6, p1, v189_7_tail);
          v190_12 = compose(v190_10,v192_11);
        }
        const Space v190_13 = unite(v190_8,v190_12);
        v189_7_result = unite(v189_7_result,v190_13);
      }
      const Space v189_7 = std::move(v189_7_result);
      v188_8 = compose(v188_5,v189_7);
    }
    const Space v188_9 = intersect(constant_2,v188_2);
    const Space v188_10 = (has_head(v188_9) ? constant_3 : Space{});
    Space v188_12;
    if (!v188_10.empty()) {
      const Path v193_6 = concat_path(p0,v187_12_head);
      Space v193_11_result;
      for (int v193_11_label = 1; v193_11_label <= 2; ++v193_11_label) {
        const Space v193_11_tail = child(v187_12_tail,v193_11_label);
        if (v193_11_tail.empty()) continue;
        const Path v193_11_head{v193_11_label};
        const Space v194_2 = singleton(v193_11_head);
        const Space v194_3 = intersect(constant_2,v194_2);
        const Space v194_4 = (has_head(v194_3) ? constant_3 : Space{});
        const Space v194_5 = subtract(constant_1,v194_4);
        Space v194_8;
        if (!v194_5.empty()) {
          const Path v195_6 = concat_path(v193_6,v193_11_head);
          const Space v195_7 = routine_30(c, v195_6, p1, v193_11_tail);
          v194_8 = compose(v194_5,v195_7);
        }
        const Space v194_9 = intersect(constant_2,v194_2);
        const Space v194_10 = (has_head(v194_9) ? constant_3 : Space{});
        Space v194_12;
        if (!v194_10.empty()) {
          const Path v196_6 = concat_path(v193_6,v193_11_head);
          const Space v196_11 = routine_21(c, v196_6, p1, v193_11_tail);
          v194_12 = compose(v194_10,v196_11);
        }
        const Space v194_13 = unite(v194_8,v194_12);
        v193_11_result = unite(v193_11_result,v194_13);
      }
      const Space v193_11 = std::move(v193_11_result);
      v188_12 = compose(v188_10,v193_11);
    }
    const Space v188_13 = unite(v188_8,v188_12);
    v187_12_result = unite(v187_12_result,v188_13);
  }
  const Space v187_12 = std::move(v187_12_result);
  return v187_12;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v197_9_result;
  for (int v197_9_label = 1; v197_9_label <= 2; ++v197_9_label) {
    const Space v197_9_tail = child(s0,v197_9_label);
    if (v197_9_tail.empty()) continue;
    const Path v197_9_head{v197_9_label};
    const Space v198_2 = singleton(v197_9_head);
    const Space v198_3 = intersect(constant_2,v198_2);
    const Space v198_4 = (has_head(v198_3) ? constant_3 : Space{});
    const Space v198_5 = subtract(constant_1,v198_4);
    Space v198_8;
    if (!v198_5.empty()) {
      const Path v199_6 = concat_path(p0,v197_9_head);
      Space v199_7_result;
      for (int v199_7_label = 1; v199_7_label <= 2; ++v199_7_label) {
        const Space v199_7_tail = child(v197_9_tail,v199_7_label);
        if (v199_7_tail.empty()) continue;
        const Path v199_7_head{v199_7_label};
        const Space v200_2 = singleton(v199_7_head);
        const Space v200_3 = intersect(constant_2,v200_2);
        const Space v200_4 = (has_head(v200_3) ? constant_3 : Space{});
        const Space v200_5 = subtract(constant_1,v200_4);
        Space v200_8;
        if (!v200_5.empty()) {
          const Path v201_6 = concat_path(v199_6,v199_7_head);
          const Space v201_7 = routine_30(c, v201_6, p1, v199_7_tail);
          v200_8 = compose(v200_5,v201_7);
        }
        const Space v200_9 = intersect(constant_2,v200_2);
        const Space v200_10 = (has_head(v200_9) ? constant_3 : Space{});
        Space v200_12;
        if (!v200_10.empty()) {
          const Path v202_6 = concat_path(v199_6,v199_7_head);
          const Space v202_11 = routine_31(c, v202_6, p1, v199_7_tail);
          v200_12 = compose(v200_10,v202_11);
        }
        const Space v200_13 = unite(v200_8,v200_12);
        v199_7_result = unite(v199_7_result,v200_13);
      }
      const Space v199_7 = std::move(v199_7_result);
      v198_8 = compose(v198_5,v199_7);
    }
    const Space v198_9 = intersect(constant_2,v198_2);
    const Space v198_10 = (has_head(v198_9) ? constant_3 : Space{});
    const Space v198_11 = compose(v198_10,v197_9_tail);
    const Path v203_6 = concat_path(p0,v197_9_head);
    const Space v198_12 = wrap(v198_11,v203_6);
    const Space v198_13 = wrap(v198_12,p1);
    const Space v198_14 = unite(v198_8,v198_13);
    v197_9_result = unite(v197_9_result,v198_14);
  }
  const Space v197_9 = std::move(v197_9_result);
  return v197_9;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v204_3 = wrap(s0,p0);
  const Space v204_4 = wrap(v204_3,p1);
  return v204_4;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v205_12_result;
  for (int v205_12_label = 1; v205_12_label <= 2; ++v205_12_label) {
    const Space v205_12_tail = child(s0,v205_12_label);
    if (v205_12_tail.empty()) continue;
    const Path v205_12_head{v205_12_label};
    const Space v206_2 = singleton(v205_12_head);
    const Space v206_3 = intersect(constant_2,v206_2);
    const Space v206_4 = (has_head(v206_3) ? constant_3 : Space{});
    const Space v206_5 = subtract(constant_1,v206_4);
    Space v206_8;
    if (!v206_5.empty()) {
      const Path v207_6 = concat_path(p0,v205_12_head);
      Space v207_7_result;
      for (int v207_7_label = 1; v207_7_label <= 2; ++v207_7_label) {
        const Space v207_7_tail = child(v205_12_tail,v207_7_label);
        if (v207_7_tail.empty()) continue;
        const Path v207_7_head{v207_7_label};
        const Space v208_2 = singleton(v207_7_head);
        const Space v208_3 = intersect(constant_2,v208_2);
        const Space v208_4 = (has_head(v208_3) ? constant_3 : Space{});
        const Space v208_5 = subtract(constant_1,v208_4);
        Space v208_8;
        if (!v208_5.empty()) {
          const Path v209_6 = concat_path(v207_6,v207_7_head);
          const Space v209_7 = routine_32(c, v209_6, v207_7_tail, s1);
          v208_8 = compose(v208_5,v209_7);
        }
        const Space v208_9 = intersect(constant_2,v208_2);
        const Space v208_10 = (has_head(v208_9) ? constant_3 : Space{});
        Space v208_12;
        if (!v208_10.empty()) {
          const Path v210_6 = concat_path(v207_6,v207_7_head);
          const Space v210_11 = routine_33(c, v210_6, v207_7_tail, s1);
          v208_12 = compose(v208_10,v210_11);
        }
        const Space v208_13 = unite(v208_8,v208_12);
        v207_7_result = unite(v207_7_result,v208_13);
      }
      const Space v207_7 = std::move(v207_7_result);
      v206_8 = compose(v206_5,v207_7);
    }
    const Space v206_9 = intersect(constant_2,v206_2);
    const Space v206_10 = (has_head(v206_9) ? constant_3 : Space{});
    Space v206_12;
    if (!v206_10.empty()) {
      const Path v211_6 = concat_path(p0,v205_12_head);
      Space v211_11_result;
      for (int v211_11_label = 1; v211_11_label <= 2; ++v211_11_label) {
        const Space v211_11_tail = child(v205_12_tail,v211_11_label);
        if (v211_11_tail.empty()) continue;
        const Path v211_11_head{v211_11_label};
        const Space v212_2 = singleton(v211_11_head);
        const Space v212_3 = intersect(constant_2,v212_2);
        const Space v212_4 = (has_head(v212_3) ? constant_3 : Space{});
        const Space v212_5 = subtract(constant_1,v212_4);
        Space v212_8;
        if (!v212_5.empty()) {
          const Path v213_6 = concat_path(v211_6,v211_11_head);
          const Space v213_7 = routine_32(c, v213_6, v211_11_tail, s1);
          v212_8 = compose(v212_5,v213_7);
        }
        const Space v212_9 = intersect(constant_2,v212_2);
        const Space v212_10 = (has_head(v212_9) ? constant_3 : Space{});
        Space v212_12;
        if (!v212_10.empty()) {
          const Path v214_6 = concat_path(v211_6,v211_11_head);
          const Space v214_11 = routine_3(c, v214_6, v211_11_tail, s1);
          v212_12 = compose(v212_10,v214_11);
        }
        const Space v212_13 = unite(v212_8,v212_12);
        v211_11_result = unite(v211_11_result,v212_13);
      }
      const Space v211_11 = std::move(v211_11_result);
      v206_12 = compose(v206_10,v211_11);
    }
    const Space v206_13 = unite(v206_8,v206_12);
    v205_12_result = unite(v205_12_result,v206_13);
  }
  const Space v205_12 = std::move(v205_12_result);
  return v205_12;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v215_12_result;
  for (int v215_12_label = 1; v215_12_label <= 2; ++v215_12_label) {
    const Space v215_12_tail = child(s0,v215_12_label);
    if (v215_12_tail.empty()) continue;
    const Path v215_12_head{v215_12_label};
    const Space v216_2 = singleton(v215_12_head);
    const Space v216_3 = intersect(constant_2,v216_2);
    const Space v216_4 = (has_head(v216_3) ? constant_3 : Space{});
    const Space v216_5 = subtract(constant_1,v216_4);
    Space v216_8;
    if (!v216_5.empty()) {
      const Path v217_6 = concat_path(p0,v215_12_head);
      Space v217_7_result;
      for (int v217_7_label = 1; v217_7_label <= 2; ++v217_7_label) {
        const Space v217_7_tail = child(v215_12_tail,v217_7_label);
        if (v217_7_tail.empty()) continue;
        const Path v217_7_head{v217_7_label};
        const Space v218_2 = singleton(v217_7_head);
        const Space v218_3 = intersect(constant_2,v218_2);
        const Space v218_4 = (has_head(v218_3) ? constant_3 : Space{});
        const Space v218_5 = subtract(constant_1,v218_4);
        Space v218_8;
        if (!v218_5.empty()) {
          const Path v219_6 = concat_path(v217_6,v217_7_head);
          const Space v219_7 = routine_32(c, v219_6, v217_7_tail, s1);
          v218_8 = compose(v218_5,v219_7);
        }
        const Space v218_9 = intersect(constant_2,v218_2);
        const Space v218_10 = (has_head(v218_9) ? constant_3 : Space{});
        Space v218_12;
        if (!v218_10.empty()) {
          const Path v220_6 = concat_path(v217_6,v217_7_head);
          const Space v220_11 = routine_33(c, v220_6, v217_7_tail, s1);
          v218_12 = compose(v218_10,v220_11);
        }
        const Space v218_13 = unite(v218_8,v218_12);
        v217_7_result = unite(v217_7_result,v218_13);
      }
      const Space v217_7 = std::move(v217_7_result);
      v216_8 = compose(v216_5,v217_7);
    }
    const Space v216_9 = intersect(constant_2,v216_2);
    const Space v216_10 = (has_head(v216_9) ? constant_3 : Space{});
    Space v216_12;
    if (!v216_10.empty()) {
      const Path v221_6 = concat_path(p0,v215_12_head);
      Space v221_11_result;
      for (int v221_11_label = 1; v221_11_label <= 2; ++v221_11_label) {
        const Space v221_11_tail = child(v215_12_tail,v221_11_label);
        if (v221_11_tail.empty()) continue;
        const Path v221_11_head{v221_11_label};
        const Space v222_2 = singleton(v221_11_head);
        const Space v222_3 = intersect(constant_2,v222_2);
        const Space v222_4 = (has_head(v222_3) ? constant_3 : Space{});
        const Space v222_5 = subtract(constant_1,v222_4);
        Space v222_7;
        if (!v222_5.empty()) {
          const Space v223_6 = routine_6(c, v221_11_head, v221_6, v221_11_tail, s1);
          v222_7 = compose(v222_5,v223_6);
        }
        const Space v222_8 = intersect(constant_2,v222_2);
        const Space v222_9 = (has_head(v222_8) ? constant_3 : Space{});
        Space v222_11;
        if (!v222_9.empty()) {
          const Space v224_10 = routine_7(c, v221_11_head, v221_6, v221_11_tail, s1);
          v222_11 = compose(v222_9,v224_10);
        }
        const Space v222_12 = unite(v222_7,v222_11);
        v221_11_result = unite(v221_11_result,v222_12);
      }
      const Space v221_11 = std::move(v221_11_result);
      v216_12 = compose(v216_10,v221_11);
    }
    const Space v216_13 = unite(v216_8,v216_12);
    v215_12_result = unite(v215_12_result,v216_13);
  }
  const Space v215_12 = std::move(v215_12_result);
  return v215_12;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v225_13_result;
  for (int v225_13_label = 1; v225_13_label <= 2; ++v225_13_label) {
    const Space v225_13_tail = child(s0,v225_13_label);
    if (v225_13_tail.empty()) continue;
    const Path v225_13_head{v225_13_label};
    const Space v226_2 = singleton(v225_13_head);
    const Space v226_3 = intersect(constant_2,v226_2);
    const Space v226_4 = (has_head(v226_3) ? constant_3 : Space{});
    const Space v226_5 = subtract(constant_1,v226_4);
    Space v226_8;
    if (!v226_5.empty()) {
      const Path v227_6 = concat_path(p0,v225_13_head);
      Space v227_7_result;
      for (int v227_7_label = 1; v227_7_label <= 2; ++v227_7_label) {
        const Space v227_7_tail = child(v225_13_tail,v227_7_label);
        if (v227_7_tail.empty()) continue;
        const Path v227_7_head{v227_7_label};
        const Space v228_2 = singleton(v227_7_head);
        const Space v228_3 = intersect(constant_2,v228_2);
        const Space v228_4 = (has_head(v228_3) ? constant_3 : Space{});
        const Space v228_5 = subtract(constant_1,v228_4);
        Space v228_8;
        if (!v228_5.empty()) {
          const Path v229_6 = concat_path(v227_6,v227_7_head);
          const Space v229_7 = routine_34(c, v229_6, p1, v227_7_tail, s1);
          v228_8 = compose(v228_5,v229_7);
        }
        const Space v228_9 = intersect(constant_2,v228_2);
        const Space v228_10 = (has_head(v228_9) ? constant_3 : Space{});
        Space v228_12;
        if (!v228_10.empty()) {
          const Path v230_6 = concat_path(v227_6,v227_7_head);
          const Space v230_11 = routine_35(c, v230_6, p1, v227_7_tail, s1);
          v228_12 = compose(v228_10,v230_11);
        }
        const Space v228_13 = unite(v228_8,v228_12);
        v227_7_result = unite(v227_7_result,v228_13);
      }
      const Space v227_7 = std::move(v227_7_result);
      v226_8 = compose(v226_5,v227_7);
    }
    const Space v226_9 = intersect(constant_2,v226_2);
    const Space v226_10 = (has_head(v226_9) ? constant_3 : Space{});
    Space v226_12;
    if (!v226_10.empty()) {
      const Path v231_6 = concat_path(p0,v225_13_head);
      Space v231_11_result;
      for (int v231_11_label = 1; v231_11_label <= 2; ++v231_11_label) {
        const Space v231_11_tail = child(v225_13_tail,v231_11_label);
        if (v231_11_tail.empty()) continue;
        const Path v231_11_head{v231_11_label};
        const Space v232_2 = singleton(v231_11_head);
        const Space v232_3 = intersect(constant_2,v232_2);
        const Space v232_4 = (has_head(v232_3) ? constant_3 : Space{});
        const Space v232_5 = subtract(constant_1,v232_4);
        Space v232_8;
        if (!v232_5.empty()) {
          const Path v233_6 = concat_path(v231_6,v231_11_head);
          const Space v233_7 = routine_34(c, v233_6, p1, v231_11_tail, s1);
          v232_8 = compose(v232_5,v233_7);
        }
        const Space v232_9 = intersect(constant_2,v232_2);
        const Space v232_10 = (has_head(v232_9) ? constant_3 : Space{});
        Space v232_12;
        if (!v232_10.empty()) {
          const Path v234_6 = concat_path(v231_6,v231_11_head);
          const Space v234_11 = routine_10(c, v234_6, p1, v231_11_tail, s1);
          v232_12 = compose(v232_10,v234_11);
        }
        const Space v232_13 = unite(v232_8,v232_12);
        v231_11_result = unite(v231_11_result,v232_13);
      }
      const Space v231_11 = std::move(v231_11_result);
      v226_12 = compose(v226_10,v231_11);
    }
    const Space v226_13 = unite(v226_8,v226_12);
    v225_13_result = unite(v225_13_result,v226_13);
  }
  const Space v225_13 = std::move(v225_13_result);
  return v225_13;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v235_8 = unwrap(s1,constant_0);
  const Space v235_9 = unwrap(v235_8,p0);
  Space v235_16_result;
  for (int v235_16_label = 1; v235_16_label <= 2; ++v235_16_label) {
    const Space v235_16_tail = child(s0,v235_16_label);
    if (v235_16_tail.empty()) continue;
    const Path v235_16_head{v235_16_label};
    const Space v236_2 = singleton(v235_16_head);
    const Space v236_3 = intersect(constant_2,v236_2);
    const Space v236_4 = (has_head(v236_3) ? constant_3 : Space{});
    const Space v236_5 = subtract(constant_1,v236_4);
    Space v236_8;
    if (!v236_5.empty()) {
      const Path v237_6 = concat_path(p0,v235_16_head);
      Space v237_7_result;
      for (int v237_7_label = 1; v237_7_label <= 2; ++v237_7_label) {
        const Space v237_7_tail = child(v235_16_tail,v237_7_label);
        if (v237_7_tail.empty()) continue;
        const Path v237_7_head{v237_7_label};
        const Space v238_2 = singleton(v237_7_head);
        const Space v238_3 = intersect(constant_2,v238_2);
        const Space v238_4 = (has_head(v238_3) ? constant_3 : Space{});
        const Space v238_5 = subtract(constant_1,v238_4);
        Space v238_8;
        if (!v238_5.empty()) {
          const Path v239_6 = concat_path(v237_6,v237_7_head);
          const Space v239_7 = routine_34(c, v239_6, p1, v237_7_tail, s1);
          v238_8 = compose(v238_5,v239_7);
        }
        const Space v238_9 = intersect(constant_2,v238_2);
        const Space v238_10 = (has_head(v238_9) ? constant_3 : Space{});
        Space v238_12;
        if (!v238_10.empty()) {
          const Path v240_6 = concat_path(v237_6,v237_7_head);
          const Space v240_11 = routine_35(c, v240_6, p1, v237_7_tail, s1);
          v238_12 = compose(v238_10,v240_11);
        }
        const Space v238_13 = unite(v238_8,v238_12);
        v237_7_result = unite(v237_7_result,v238_13);
      }
      const Space v237_7 = std::move(v237_7_result);
      v236_8 = compose(v236_5,v237_7);
    }
    const Space v236_9 = intersect(constant_2,v236_2);
    const Space v236_10 = (has_head(v236_9) ? constant_3 : Space{});
    Space v236_13;
    if (!v236_10.empty()) {
      const Space v241_11 = unwrap(v235_9,v235_16_head);
      Space v241_12_result;
      for (int v241_12_label = 1; v241_12_label <= 2; ++v241_12_label) {
        const Space v241_12_tail = child(v241_11,v241_12_label);
        if (v241_12_tail.empty()) continue;
        const Path v241_12_head{v241_12_label};
        const Space v242_2 = singleton(v241_12_head);
        const Space v242_3 = intersect(constant_2,v242_2);
        const Space v242_4 = (has_head(v242_3) ? constant_3 : Space{});
        const Space v242_5 = subtract(constant_1,v242_4);
        Space v242_7;
        if (!v242_5.empty()) {
          const Space v243_6 = routine_15(c, v241_12_head, p1, v241_12_tail);
          v242_7 = compose(v242_5,v243_6);
        }
        const Space v242_8 = intersect(constant_2,v242_2);
        const Space v242_9 = (has_head(v242_8) ? constant_3 : Space{});
        Space v242_11;
        if (!v242_9.empty()) {
          const Space v244_10 = routine_16(c, v241_12_head, p1, v241_12_tail);
          v242_11 = compose(v242_9,v244_10);
        }
        const Space v242_12 = unite(v242_7,v242_11);
        v241_12_result = unite(v241_12_result,v242_12);
      }
      const Space v241_12 = std::move(v241_12_result);
      v236_13 = compose(v236_10,v241_12);
    }
    const Space v236_14 = unite(v236_8,v236_13);
    v235_16_result = unite(v235_16_result,v236_14);
  }
  const Space v235_16 = std::move(v235_16_result);
  return v235_16;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v245_12_result;
  for (int v245_12_label = 1; v245_12_label <= 2; ++v245_12_label) {
    const Space v245_12_tail = child(s0,v245_12_label);
    if (v245_12_tail.empty()) continue;
    const Path v245_12_head{v245_12_label};
    const Space v246_2 = singleton(v245_12_head);
    const Space v246_3 = intersect(constant_2,v246_2);
    const Space v246_4 = (has_head(v246_3) ? constant_3 : Space{});
    const Space v246_5 = subtract(constant_1,v246_4);
    Space v246_8;
    if (!v246_5.empty()) {
      const Path v247_6 = concat_path(p0,v245_12_head);
      Space v247_7_result;
      for (int v247_7_label = 1; v247_7_label <= 2; ++v247_7_label) {
        const Space v247_7_tail = child(v245_12_tail,v247_7_label);
        if (v247_7_tail.empty()) continue;
        const Path v247_7_head{v247_7_label};
        const Space v248_2 = singleton(v247_7_head);
        const Space v248_3 = intersect(constant_2,v248_2);
        const Space v248_4 = (has_head(v248_3) ? constant_3 : Space{});
        const Space v248_5 = subtract(constant_1,v248_4);
        Space v248_8;
        if (!v248_5.empty()) {
          const Path v249_6 = concat_path(v247_6,v247_7_head);
          const Space v249_7 = routine_36(c, v249_6, p1, v247_7_tail);
          v248_8 = compose(v248_5,v249_7);
        }
        const Space v248_9 = intersect(constant_2,v248_2);
        const Space v248_10 = (has_head(v248_9) ? constant_3 : Space{});
        Space v248_12;
        if (!v248_10.empty()) {
          const Path v250_6 = concat_path(v247_6,v247_7_head);
          const Space v250_11 = routine_37(c, v250_6, p1, v247_7_tail);
          v248_12 = compose(v248_10,v250_11);
        }
        const Space v248_13 = unite(v248_8,v248_12);
        v247_7_result = unite(v247_7_result,v248_13);
      }
      const Space v247_7 = std::move(v247_7_result);
      v246_8 = compose(v246_5,v247_7);
    }
    const Space v246_9 = intersect(constant_2,v246_2);
    const Space v246_10 = (has_head(v246_9) ? constant_3 : Space{});
    Space v246_12;
    if (!v246_10.empty()) {
      const Path v251_6 = concat_path(p0,v245_12_head);
      Space v251_11_result;
      for (int v251_11_label = 1; v251_11_label <= 2; ++v251_11_label) {
        const Space v251_11_tail = child(v245_12_tail,v251_11_label);
        if (v251_11_tail.empty()) continue;
        const Path v251_11_head{v251_11_label};
        const Space v252_2 = singleton(v251_11_head);
        const Space v252_3 = intersect(constant_2,v252_2);
        const Space v252_4 = (has_head(v252_3) ? constant_3 : Space{});
        const Space v252_5 = subtract(constant_1,v252_4);
        Space v252_8;
        if (!v252_5.empty()) {
          const Path v253_6 = concat_path(v251_6,v251_11_head);
          const Space v253_7 = routine_36(c, v253_6, p1, v251_11_tail);
          v252_8 = compose(v252_5,v253_7);
        }
        const Space v252_9 = intersect(constant_2,v252_2);
        const Space v252_10 = (has_head(v252_9) ? constant_3 : Space{});
        Space v252_12;
        if (!v252_10.empty()) {
          const Path v254_6 = concat_path(v251_6,v251_11_head);
          const Space v254_11 = routine_21(c, v254_6, p1, v251_11_tail);
          v252_12 = compose(v252_10,v254_11);
        }
        const Space v252_13 = unite(v252_8,v252_12);
        v251_11_result = unite(v251_11_result,v252_13);
      }
      const Space v251_11 = std::move(v251_11_result);
      v246_12 = compose(v246_10,v251_11);
    }
    const Space v246_13 = unite(v246_8,v246_12);
    v245_12_result = unite(v245_12_result,v246_13);
  }
  const Space v245_12 = std::move(v245_12_result);
  return v245_12;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v255_9_result;
  for (int v255_9_label = 1; v255_9_label <= 2; ++v255_9_label) {
    const Space v255_9_tail = child(s0,v255_9_label);
    if (v255_9_tail.empty()) continue;
    const Path v255_9_head{v255_9_label};
    const Space v256_2 = singleton(v255_9_head);
    const Space v256_3 = intersect(constant_2,v256_2);
    const Space v256_4 = (has_head(v256_3) ? constant_3 : Space{});
    const Space v256_5 = subtract(constant_1,v256_4);
    Space v256_8;
    if (!v256_5.empty()) {
      const Path v257_6 = concat_path(p0,v255_9_head);
      Space v257_7_result;
      for (int v257_7_label = 1; v257_7_label <= 2; ++v257_7_label) {
        const Space v257_7_tail = child(v255_9_tail,v257_7_label);
        if (v257_7_tail.empty()) continue;
        const Path v257_7_head{v257_7_label};
        const Space v258_2 = singleton(v257_7_head);
        const Space v258_3 = intersect(constant_2,v258_2);
        const Space v258_4 = (has_head(v258_3) ? constant_3 : Space{});
        const Space v258_5 = subtract(constant_1,v258_4);
        Space v258_8;
        if (!v258_5.empty()) {
          const Path v259_6 = concat_path(v257_6,v257_7_head);
          const Space v259_7 = routine_36(c, v259_6, p1, v257_7_tail);
          v258_8 = compose(v258_5,v259_7);
        }
        const Space v258_9 = intersect(constant_2,v258_2);
        const Space v258_10 = (has_head(v258_9) ? constant_3 : Space{});
        Space v258_12;
        if (!v258_10.empty()) {
          const Path v260_6 = concat_path(v257_6,v257_7_head);
          const Space v260_11 = routine_37(c, v260_6, p1, v257_7_tail);
          v258_12 = compose(v258_10,v260_11);
        }
        const Space v258_13 = unite(v258_8,v258_12);
        v257_7_result = unite(v257_7_result,v258_13);
      }
      const Space v257_7 = std::move(v257_7_result);
      v256_8 = compose(v256_5,v257_7);
    }
    const Space v256_9 = intersect(constant_2,v256_2);
    const Space v256_10 = (has_head(v256_9) ? constant_3 : Space{});
    const Space v256_11 = compose(v256_10,v255_9_tail);
    const Path v261_6 = concat_path(p0,v255_9_head);
    const Space v256_12 = wrap(v256_11,v261_6);
    const Space v256_13 = wrap(v256_12,p1);
    const Space v256_14 = unite(v256_8,v256_13);
    v255_9_result = unite(v255_9_result,v256_14);
  }
  const Space v255_9 = std::move(v255_9_result);
  return v255_9;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v262_13_result;
  for (int v262_13_label = 1; v262_13_label <= 2; ++v262_13_label) {
    const Space v262_13_tail = child(s0,v262_13_label);
    if (v262_13_tail.empty()) continue;
    const Path v262_13_head{v262_13_label};
    const Space v263_2 = singleton(v262_13_head);
    const Space v263_3 = intersect(constant_2,v263_2);
    const Space v263_4 = (has_head(v263_3) ? constant_3 : Space{});
    const Space v263_5 = subtract(constant_1,v263_4);
    Space v263_8;
    if (!v263_5.empty()) {
      const Path v264_6 = concat_path(p0,v262_13_head);
      Space v264_7_result;
      for (int v264_7_label = 1; v264_7_label <= 2; ++v264_7_label) {
        const Space v264_7_tail = child(v262_13_tail,v264_7_label);
        if (v264_7_tail.empty()) continue;
        const Path v264_7_head{v264_7_label};
        const Space v265_2 = singleton(v264_7_head);
        const Space v265_3 = intersect(constant_2,v265_2);
        const Space v265_4 = (has_head(v265_3) ? constant_3 : Space{});
        const Space v265_5 = subtract(constant_1,v265_4);
        Space v265_8;
        if (!v265_5.empty()) {
          const Path v266_6 = concat_path(v264_6,v264_7_head);
          const Space v266_7 = routine_38(c, v266_6, p1, v264_7_tail, s1);
          v265_8 = compose(v265_5,v266_7);
        }
        const Space v265_9 = intersect(constant_2,v265_2);
        const Space v265_10 = (has_head(v265_9) ? constant_3 : Space{});
        Space v265_12;
        if (!v265_10.empty()) {
          const Path v267_6 = concat_path(v264_6,v264_7_head);
          const Space v267_11 = routine_39(c, v267_6, p1, v264_7_tail, s1);
          v265_12 = compose(v265_10,v267_11);
        }
        const Space v265_13 = unite(v265_8,v265_12);
        v264_7_result = unite(v264_7_result,v265_13);
      }
      const Space v264_7 = std::move(v264_7_result);
      v263_8 = compose(v263_5,v264_7);
    }
    const Space v263_9 = intersect(constant_2,v263_2);
    const Space v263_10 = (has_head(v263_9) ? constant_3 : Space{});
    Space v263_12;
    if (!v263_10.empty()) {
      const Path v268_6 = concat_path(p0,v262_13_head);
      Space v268_11_result;
      for (int v268_11_label = 1; v268_11_label <= 2; ++v268_11_label) {
        const Space v268_11_tail = child(v262_13_tail,v268_11_label);
        if (v268_11_tail.empty()) continue;
        const Path v268_11_head{v268_11_label};
        const Space v269_2 = singleton(v268_11_head);
        const Space v269_3 = intersect(constant_2,v269_2);
        const Space v269_4 = (has_head(v269_3) ? constant_3 : Space{});
        const Space v269_5 = subtract(constant_1,v269_4);
        Space v269_8;
        if (!v269_5.empty()) {
          const Path v270_6 = concat_path(v268_6,v268_11_head);
          const Space v270_7 = routine_38(c, v270_6, p1, v268_11_tail, s1);
          v269_8 = compose(v269_5,v270_7);
        }
        const Space v269_9 = intersect(constant_2,v269_2);
        const Space v269_10 = (has_head(v269_9) ? constant_3 : Space{});
        Space v269_12;
        if (!v269_10.empty()) {
          const Path v271_6 = concat_path(v268_6,v268_11_head);
          const Space v271_11 = routine_10(c, v271_6, p1, v268_11_tail, s1);
          v269_12 = compose(v269_10,v271_11);
        }
        const Space v269_13 = unite(v269_8,v269_12);
        v268_11_result = unite(v268_11_result,v269_13);
      }
      const Space v268_11 = std::move(v268_11_result);
      v263_12 = compose(v263_10,v268_11);
    }
    const Space v263_13 = unite(v263_8,v263_12);
    v262_13_result = unite(v262_13_result,v263_13);
  }
  const Space v262_13 = std::move(v262_13_result);
  return v262_13;
}

static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v272_8 = unwrap(s1,constant_0);
  const Space v272_9 = unwrap(v272_8,p0);
  Space v272_16_result;
  for (int v272_16_label = 1; v272_16_label <= 2; ++v272_16_label) {
    const Space v272_16_tail = child(s0,v272_16_label);
    if (v272_16_tail.empty()) continue;
    const Path v272_16_head{v272_16_label};
    const Space v273_2 = singleton(v272_16_head);
    const Space v273_3 = intersect(constant_2,v273_2);
    const Space v273_4 = (has_head(v273_3) ? constant_3 : Space{});
    const Space v273_5 = subtract(constant_1,v273_4);
    Space v273_8;
    if (!v273_5.empty()) {
      const Path v274_6 = concat_path(p0,v272_16_head);
      Space v274_7_result;
      for (int v274_7_label = 1; v274_7_label <= 2; ++v274_7_label) {
        const Space v274_7_tail = child(v272_16_tail,v274_7_label);
        if (v274_7_tail.empty()) continue;
        const Path v274_7_head{v274_7_label};
        const Space v275_2 = singleton(v274_7_head);
        const Space v275_3 = intersect(constant_2,v275_2);
        const Space v275_4 = (has_head(v275_3) ? constant_3 : Space{});
        const Space v275_5 = subtract(constant_1,v275_4);
        Space v275_8;
        if (!v275_5.empty()) {
          const Path v276_6 = concat_path(v274_6,v274_7_head);
          const Space v276_7 = routine_38(c, v276_6, p1, v274_7_tail, s1);
          v275_8 = compose(v275_5,v276_7);
        }
        const Space v275_9 = intersect(constant_2,v275_2);
        const Space v275_10 = (has_head(v275_9) ? constant_3 : Space{});
        Space v275_12;
        if (!v275_10.empty()) {
          const Path v277_6 = concat_path(v274_6,v274_7_head);
          const Space v277_11 = routine_39(c, v277_6, p1, v274_7_tail, s1);
          v275_12 = compose(v275_10,v277_11);
        }
        const Space v275_13 = unite(v275_8,v275_12);
        v274_7_result = unite(v274_7_result,v275_13);
      }
      const Space v274_7 = std::move(v274_7_result);
      v273_8 = compose(v273_5,v274_7);
    }
    const Space v273_9 = intersect(constant_2,v273_2);
    const Space v273_10 = (has_head(v273_9) ? constant_3 : Space{});
    Space v273_13;
    if (!v273_10.empty()) {
      const Space v278_11 = unwrap(v272_9,v272_16_head);
      Space v278_12_result;
      for (int v278_12_label = 1; v278_12_label <= 2; ++v278_12_label) {
        const Space v278_12_tail = child(v278_11,v278_12_label);
        if (v278_12_tail.empty()) continue;
        const Path v278_12_head{v278_12_label};
        const Space v279_2 = singleton(v278_12_head);
        const Space v279_3 = intersect(constant_2,v279_2);
        const Space v279_4 = (has_head(v279_3) ? constant_3 : Space{});
        const Space v279_5 = subtract(constant_1,v279_4);
        Space v279_7;
        if (!v279_5.empty()) {
          const Space v280_6 = routine_15(c, v278_12_head, p1, v278_12_tail);
          v279_7 = compose(v279_5,v280_6);
        }
        const Space v279_8 = intersect(constant_2,v279_2);
        const Space v279_9 = (has_head(v279_8) ? constant_3 : Space{});
        Space v279_11;
        if (!v279_9.empty()) {
          const Space v281_10 = routine_16(c, v278_12_head, p1, v278_12_tail);
          v279_11 = compose(v279_9,v281_10);
        }
        const Space v279_12 = unite(v279_7,v279_11);
        v278_12_result = unite(v278_12_result,v279_12);
      }
      const Space v278_12 = std::move(v278_12_result);
      v273_13 = compose(v273_10,v278_12);
    }
    const Space v273_14 = unite(v273_8,v273_13);
    v272_16_result = unite(v272_16_result,v273_14);
  }
  const Space v272_16 = std::move(v272_16_result);
  return v272_16;
}

static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v282_12_result;
  for (int v282_12_label = 1; v282_12_label <= 2; ++v282_12_label) {
    const Space v282_12_tail = child(s0,v282_12_label);
    if (v282_12_tail.empty()) continue;
    const Path v282_12_head{v282_12_label};
    const Space v283_2 = singleton(v282_12_head);
    const Space v283_3 = intersect(constant_2,v283_2);
    const Space v283_4 = (has_head(v283_3) ? constant_3 : Space{});
    const Space v283_5 = subtract(constant_1,v283_4);
    Space v283_8;
    if (!v283_5.empty()) {
      const Path v284_6 = concat_path(p0,v282_12_head);
      Space v284_7_result;
      for (int v284_7_label = 1; v284_7_label <= 2; ++v284_7_label) {
        const Space v284_7_tail = child(v282_12_tail,v284_7_label);
        if (v284_7_tail.empty()) continue;
        const Path v284_7_head{v284_7_label};
        const Space v285_2 = singleton(v284_7_head);
        const Space v285_3 = intersect(constant_2,v285_2);
        const Space v285_4 = (has_head(v285_3) ? constant_3 : Space{});
        const Space v285_5 = subtract(constant_1,v285_4);
        Space v285_8;
        if (!v285_5.empty()) {
          const Path v286_6 = concat_path(v284_6,v284_7_head);
          const Space v286_7 = routine_40(c, v286_6, p1, v284_7_tail);
          v285_8 = compose(v285_5,v286_7);
        }
        const Space v285_9 = intersect(constant_2,v285_2);
        const Space v285_10 = (has_head(v285_9) ? constant_3 : Space{});
        Space v285_12;
        if (!v285_10.empty()) {
          const Path v287_6 = concat_path(v284_6,v284_7_head);
          const Space v287_11 = routine_41(c, v287_6, p1, v284_7_tail);
          v285_12 = compose(v285_10,v287_11);
        }
        const Space v285_13 = unite(v285_8,v285_12);
        v284_7_result = unite(v284_7_result,v285_13);
      }
      const Space v284_7 = std::move(v284_7_result);
      v283_8 = compose(v283_5,v284_7);
    }
    const Space v283_9 = intersect(constant_2,v283_2);
    const Space v283_10 = (has_head(v283_9) ? constant_3 : Space{});
    Space v283_12;
    if (!v283_10.empty()) {
      const Path v288_6 = concat_path(p0,v282_12_head);
      Space v288_11_result;
      for (int v288_11_label = 1; v288_11_label <= 2; ++v288_11_label) {
        const Space v288_11_tail = child(v282_12_tail,v288_11_label);
        if (v288_11_tail.empty()) continue;
        const Path v288_11_head{v288_11_label};
        const Space v289_2 = singleton(v288_11_head);
        const Space v289_3 = intersect(constant_2,v289_2);
        const Space v289_4 = (has_head(v289_3) ? constant_3 : Space{});
        const Space v289_5 = subtract(constant_1,v289_4);
        Space v289_8;
        if (!v289_5.empty()) {
          const Path v290_6 = concat_path(v288_6,v288_11_head);
          const Space v290_7 = routine_40(c, v290_6, p1, v288_11_tail);
          v289_8 = compose(v289_5,v290_7);
        }
        const Space v289_9 = intersect(constant_2,v289_2);
        const Space v289_10 = (has_head(v289_9) ? constant_3 : Space{});
        Space v289_12;
        if (!v289_10.empty()) {
          const Path v291_6 = concat_path(v288_6,v288_11_head);
          const Space v291_11 = routine_21(c, v291_6, p1, v288_11_tail);
          v289_12 = compose(v289_10,v291_11);
        }
        const Space v289_13 = unite(v289_8,v289_12);
        v288_11_result = unite(v288_11_result,v289_13);
      }
      const Space v288_11 = std::move(v288_11_result);
      v283_12 = compose(v283_10,v288_11);
    }
    const Space v283_13 = unite(v283_8,v283_12);
    v282_12_result = unite(v282_12_result,v283_13);
  }
  const Space v282_12 = std::move(v282_12_result);
  return v282_12;
}

static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v292_9_result;
  for (int v292_9_label = 1; v292_9_label <= 2; ++v292_9_label) {
    const Space v292_9_tail = child(s0,v292_9_label);
    if (v292_9_tail.empty()) continue;
    const Path v292_9_head{v292_9_label};
    const Space v293_2 = singleton(v292_9_head);
    const Space v293_3 = intersect(constant_2,v293_2);
    const Space v293_4 = (has_head(v293_3) ? constant_3 : Space{});
    const Space v293_5 = subtract(constant_1,v293_4);
    Space v293_8;
    if (!v293_5.empty()) {
      const Path v294_6 = concat_path(p0,v292_9_head);
      Space v294_7_result;
      for (int v294_7_label = 1; v294_7_label <= 2; ++v294_7_label) {
        const Space v294_7_tail = child(v292_9_tail,v294_7_label);
        if (v294_7_tail.empty()) continue;
        const Path v294_7_head{v294_7_label};
        const Space v295_2 = singleton(v294_7_head);
        const Space v295_3 = intersect(constant_2,v295_2);
        const Space v295_4 = (has_head(v295_3) ? constant_3 : Space{});
        const Space v295_5 = subtract(constant_1,v295_4);
        Space v295_8;
        if (!v295_5.empty()) {
          const Path v296_6 = concat_path(v294_6,v294_7_head);
          const Space v296_7 = routine_40(c, v296_6, p1, v294_7_tail);
          v295_8 = compose(v295_5,v296_7);
        }
        const Space v295_9 = intersect(constant_2,v295_2);
        const Space v295_10 = (has_head(v295_9) ? constant_3 : Space{});
        Space v295_12;
        if (!v295_10.empty()) {
          const Path v297_6 = concat_path(v294_6,v294_7_head);
          const Space v297_11 = routine_41(c, v297_6, p1, v294_7_tail);
          v295_12 = compose(v295_10,v297_11);
        }
        const Space v295_13 = unite(v295_8,v295_12);
        v294_7_result = unite(v294_7_result,v295_13);
      }
      const Space v294_7 = std::move(v294_7_result);
      v293_8 = compose(v293_5,v294_7);
    }
    const Space v293_9 = intersect(constant_2,v293_2);
    const Space v293_10 = (has_head(v293_9) ? constant_3 : Space{});
    const Space v293_11 = compose(v293_10,v292_9_tail);
    const Path v298_6 = concat_path(p0,v292_9_head);
    const Space v293_12 = wrap(v293_11,v298_6);
    const Space v293_13 = wrap(v293_12,p1);
    const Space v293_14 = unite(v293_8,v293_13);
    v292_9_result = unite(v292_9_result,v293_14);
  }
  const Space v292_9 = std::move(v292_9_result);
  return v292_9;
}

static Space routine_32(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v299_7_result;
  for (int v299_7_label = 1; v299_7_label <= 2; ++v299_7_label) {
    const Space v299_7_tail = child(s0,v299_7_label);
    if (v299_7_tail.empty()) continue;
    const Path v299_7_head{v299_7_label};
    const Space v300_2 = singleton(v299_7_head);
    const Space v300_3 = intersect(constant_2,v300_2);
    const Space v300_4 = (has_head(v300_3) ? constant_3 : Space{});
    const Space v300_5 = subtract(constant_1,v300_4);
    Space v300_6_result;
    for (int v300_6_label = 1; v300_6_label <= 2; ++v300_6_label) {
      const Space v300_6_tail = child(v299_7_tail,v300_6_label);
      if (v300_6_tail.empty()) continue;
      const Path v300_6_head{v300_6_label};
      const Space v301_2 = Space{};
      v300_6_result = unite(v300_6_result,v301_2);
    }
    const Space v300_6 = std::move(v300_6_result);
    const Space v300_7 = compose(v300_5,v300_6);
    const Space v300_8 = intersect(constant_2,v300_2);
    const Space v300_9 = (has_head(v300_8) ? constant_3 : Space{});
    Space v300_12;
    if (!v300_9.empty()) {
      const Path v302_10 = concat_path(p0,v299_7_head);
      Space v302_11_result;
      for (int v302_11_label = 1; v302_11_label <= 2; ++v302_11_label) {
        const Space v302_11_tail = child(v299_7_tail,v302_11_label);
        if (v302_11_tail.empty()) continue;
        const Path v302_11_head{v302_11_label};
        const Space v303_2 = singleton(v302_11_head);
        const Space v303_3 = intersect(constant_2,v303_2);
        const Space v303_4 = (has_head(v303_3) ? constant_3 : Space{});
        Space v303_7;
        if (!v303_4.empty()) {
          const Path v304_5 = concat_path(v302_10,v302_11_head);
          const Space v304_6 = routine_3(c, v304_5, v302_11_tail, s1);
          v303_7 = compose(v303_4,v304_6);
        }
        v302_11_result = unite(v302_11_result,v303_7);
      }
      const Space v302_11 = std::move(v302_11_result);
      v300_12 = compose(v300_9,v302_11);
    }
    const Space v300_13 = unite(v300_7,v300_12);
    v299_7_result = unite(v299_7_result,v300_13);
  }
  const Space v299_7 = std::move(v299_7_result);
  return v299_7;
}

static Space routine_33(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v305_9_result;
  for (int v305_9_label = 1; v305_9_label <= 2; ++v305_9_label) {
    const Space v305_9_tail = child(s0,v305_9_label);
    if (v305_9_tail.empty()) continue;
    const Path v305_9_head{v305_9_label};
    const Space v306_2 = singleton(v305_9_head);
    const Space v306_3 = intersect(constant_2,v306_2);
    const Space v306_4 = (has_head(v306_3) ? constant_3 : Space{});
    const Space v306_5 = subtract(constant_1,v306_4);
    Space v306_6_result;
    for (int v306_6_label = 1; v306_6_label <= 2; ++v306_6_label) {
      const Space v306_6_tail = child(v305_9_tail,v306_6_label);
      if (v306_6_tail.empty()) continue;
      const Path v306_6_head{v306_6_label};
      const Space v307_2 = Space{};
      v306_6_result = unite(v306_6_result,v307_2);
    }
    const Space v306_6 = std::move(v306_6_result);
    const Space v306_7 = compose(v306_5,v306_6);
    const Space v306_8 = intersect(constant_2,v306_2);
    const Space v306_9 = (has_head(v306_8) ? constant_3 : Space{});
    Space v306_12;
    if (!v306_9.empty()) {
      const Path v308_10 = concat_path(p0,v305_9_head);
      Space v308_11_result;
      for (int v308_11_label = 1; v308_11_label <= 2; ++v308_11_label) {
        const Space v308_11_tail = child(v305_9_tail,v308_11_label);
        if (v308_11_tail.empty()) continue;
        const Path v308_11_head{v308_11_label};
        const Space v309_2 = singleton(v308_11_head);
        const Space v309_3 = intersect(constant_2,v309_2);
        const Space v309_4 = (has_head(v309_3) ? constant_3 : Space{});
        const Space v309_5 = subtract(constant_1,v309_4);
        Space v309_7;
        if (!v309_5.empty()) {
          const Space v310_6 = routine_6(c, v308_11_head, v308_10, v308_11_tail, s1);
          v309_7 = compose(v309_5,v310_6);
        }
        const Space v309_8 = intersect(constant_2,v309_2);
        const Space v309_9 = (has_head(v309_8) ? constant_3 : Space{});
        Space v309_11;
        if (!v309_9.empty()) {
          const Space v311_10 = routine_7(c, v308_11_head, v308_10, v308_11_tail, s1);
          v309_11 = compose(v309_9,v311_10);
        }
        const Space v309_12 = unite(v309_7,v309_11);
        v308_11_result = unite(v308_11_result,v309_12);
      }
      const Space v308_11 = std::move(v308_11_result);
      v306_12 = compose(v306_9,v308_11);
    }
    const Space v306_13 = unite(v306_7,v306_12);
    v305_9_result = unite(v305_9_result,v306_13);
  }
  const Space v305_9 = std::move(v305_9_result);
  return v305_9;
}

static Space routine_34(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v312_13_result;
  for (int v312_13_label = 1; v312_13_label <= 2; ++v312_13_label) {
    const Space v312_13_tail = child(s0,v312_13_label);
    if (v312_13_tail.empty()) continue;
    const Path v312_13_head{v312_13_label};
    const Space v313_2 = singleton(v312_13_head);
    const Space v313_3 = intersect(constant_2,v313_2);
    const Space v313_4 = (has_head(v313_3) ? constant_3 : Space{});
    const Space v313_5 = subtract(constant_1,v313_4);
    Space v313_8;
    if (!v313_5.empty()) {
      const Path v314_6 = concat_path(p0,v312_13_head);
      Space v314_7_result;
      for (int v314_7_label = 1; v314_7_label <= 2; ++v314_7_label) {
        const Space v314_7_tail = child(v312_13_tail,v314_7_label);
        if (v314_7_tail.empty()) continue;
        const Path v314_7_head{v314_7_label};
        const Space v315_2 = singleton(v314_7_head);
        const Space v315_3 = intersect(constant_2,v315_2);
        const Space v315_4 = (has_head(v315_3) ? constant_3 : Space{});
        const Space v315_5 = subtract(constant_1,v315_4);
        Space v315_8;
        if (!v315_5.empty()) {
          const Path v316_6 = concat_path(v314_6,v314_7_head);
          const Space v316_7 = routine_42(c, v316_6, p1, v314_7_tail, s1);
          v315_8 = compose(v315_5,v316_7);
        }
        const Space v315_9 = intersect(constant_2,v315_2);
        const Space v315_10 = (has_head(v315_9) ? constant_3 : Space{});
        Space v315_12;
        if (!v315_10.empty()) {
          const Path v317_6 = concat_path(v314_6,v314_7_head);
          const Space v317_11 = routine_43(c, v317_6, p1, v314_7_tail, s1);
          v315_12 = compose(v315_10,v317_11);
        }
        const Space v315_13 = unite(v315_8,v315_12);
        v314_7_result = unite(v314_7_result,v315_13);
      }
      const Space v314_7 = std::move(v314_7_result);
      v313_8 = compose(v313_5,v314_7);
    }
    const Space v313_9 = intersect(constant_2,v313_2);
    const Space v313_10 = (has_head(v313_9) ? constant_3 : Space{});
    Space v313_12;
    if (!v313_10.empty()) {
      const Path v318_6 = concat_path(p0,v312_13_head);
      Space v318_11_result;
      for (int v318_11_label = 1; v318_11_label <= 2; ++v318_11_label) {
        const Space v318_11_tail = child(v312_13_tail,v318_11_label);
        if (v318_11_tail.empty()) continue;
        const Path v318_11_head{v318_11_label};
        const Space v319_2 = singleton(v318_11_head);
        const Space v319_3 = intersect(constant_2,v319_2);
        const Space v319_4 = (has_head(v319_3) ? constant_3 : Space{});
        const Space v319_5 = subtract(constant_1,v319_4);
        Space v319_8;
        if (!v319_5.empty()) {
          const Path v320_6 = concat_path(v318_6,v318_11_head);
          const Space v320_7 = routine_42(c, v320_6, p1, v318_11_tail, s1);
          v319_8 = compose(v319_5,v320_7);
        }
        const Space v319_9 = intersect(constant_2,v319_2);
        const Space v319_10 = (has_head(v319_9) ? constant_3 : Space{});
        Space v319_12;
        if (!v319_10.empty()) {
          const Path v321_6 = concat_path(v318_6,v318_11_head);
          const Space v321_11 = routine_10(c, v321_6, p1, v318_11_tail, s1);
          v319_12 = compose(v319_10,v321_11);
        }
        const Space v319_13 = unite(v319_8,v319_12);
        v318_11_result = unite(v318_11_result,v319_13);
      }
      const Space v318_11 = std::move(v318_11_result);
      v313_12 = compose(v313_10,v318_11);
    }
    const Space v313_13 = unite(v313_8,v313_12);
    v312_13_result = unite(v312_13_result,v313_13);
  }
  const Space v312_13 = std::move(v312_13_result);
  return v312_13;
}

static Space routine_35(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v322_8 = unwrap(s1,constant_0);
  const Space v322_9 = unwrap(v322_8,p0);
  Space v322_16_result;
  for (int v322_16_label = 1; v322_16_label <= 2; ++v322_16_label) {
    const Space v322_16_tail = child(s0,v322_16_label);
    if (v322_16_tail.empty()) continue;
    const Path v322_16_head{v322_16_label};
    const Space v323_2 = singleton(v322_16_head);
    const Space v323_3 = intersect(constant_2,v323_2);
    const Space v323_4 = (has_head(v323_3) ? constant_3 : Space{});
    const Space v323_5 = subtract(constant_1,v323_4);
    Space v323_8;
    if (!v323_5.empty()) {
      const Path v324_6 = concat_path(p0,v322_16_head);
      Space v324_7_result;
      for (int v324_7_label = 1; v324_7_label <= 2; ++v324_7_label) {
        const Space v324_7_tail = child(v322_16_tail,v324_7_label);
        if (v324_7_tail.empty()) continue;
        const Path v324_7_head{v324_7_label};
        const Space v325_2 = singleton(v324_7_head);
        const Space v325_3 = intersect(constant_2,v325_2);
        const Space v325_4 = (has_head(v325_3) ? constant_3 : Space{});
        const Space v325_5 = subtract(constant_1,v325_4);
        Space v325_8;
        if (!v325_5.empty()) {
          const Path v326_6 = concat_path(v324_6,v324_7_head);
          const Space v326_7 = routine_42(c, v326_6, p1, v324_7_tail, s1);
          v325_8 = compose(v325_5,v326_7);
        }
        const Space v325_9 = intersect(constant_2,v325_2);
        const Space v325_10 = (has_head(v325_9) ? constant_3 : Space{});
        Space v325_12;
        if (!v325_10.empty()) {
          const Path v327_6 = concat_path(v324_6,v324_7_head);
          const Space v327_11 = routine_43(c, v327_6, p1, v324_7_tail, s1);
          v325_12 = compose(v325_10,v327_11);
        }
        const Space v325_13 = unite(v325_8,v325_12);
        v324_7_result = unite(v324_7_result,v325_13);
      }
      const Space v324_7 = std::move(v324_7_result);
      v323_8 = compose(v323_5,v324_7);
    }
    const Space v323_9 = intersect(constant_2,v323_2);
    const Space v323_10 = (has_head(v323_9) ? constant_3 : Space{});
    Space v323_13;
    if (!v323_10.empty()) {
      const Space v328_11 = unwrap(v322_9,v322_16_head);
      Space v328_12_result;
      for (int v328_12_label = 1; v328_12_label <= 2; ++v328_12_label) {
        const Space v328_12_tail = child(v328_11,v328_12_label);
        if (v328_12_tail.empty()) continue;
        const Path v328_12_head{v328_12_label};
        const Space v329_2 = singleton(v328_12_head);
        const Space v329_3 = intersect(constant_2,v329_2);
        const Space v329_4 = (has_head(v329_3) ? constant_3 : Space{});
        const Space v329_5 = subtract(constant_1,v329_4);
        Space v329_7;
        if (!v329_5.empty()) {
          const Space v330_6 = routine_15(c, v328_12_head, p1, v328_12_tail);
          v329_7 = compose(v329_5,v330_6);
        }
        const Space v329_8 = intersect(constant_2,v329_2);
        const Space v329_9 = (has_head(v329_8) ? constant_3 : Space{});
        Space v329_11;
        if (!v329_9.empty()) {
          const Space v331_10 = routine_16(c, v328_12_head, p1, v328_12_tail);
          v329_11 = compose(v329_9,v331_10);
        }
        const Space v329_12 = unite(v329_7,v329_11);
        v328_12_result = unite(v328_12_result,v329_12);
      }
      const Space v328_12 = std::move(v328_12_result);
      v323_13 = compose(v323_10,v328_12);
    }
    const Space v323_14 = unite(v323_8,v323_13);
    v322_16_result = unite(v322_16_result,v323_14);
  }
  const Space v322_16 = std::move(v322_16_result);
  return v322_16;
}

static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v332_12_result;
  for (int v332_12_label = 1; v332_12_label <= 2; ++v332_12_label) {
    const Space v332_12_tail = child(s0,v332_12_label);
    if (v332_12_tail.empty()) continue;
    const Path v332_12_head{v332_12_label};
    const Space v333_2 = singleton(v332_12_head);
    const Space v333_3 = intersect(constant_2,v333_2);
    const Space v333_4 = (has_head(v333_3) ? constant_3 : Space{});
    const Space v333_5 = subtract(constant_1,v333_4);
    Space v333_8;
    if (!v333_5.empty()) {
      const Path v334_6 = concat_path(p0,v332_12_head);
      Space v334_7_result;
      for (int v334_7_label = 1; v334_7_label <= 2; ++v334_7_label) {
        const Space v334_7_tail = child(v332_12_tail,v334_7_label);
        if (v334_7_tail.empty()) continue;
        const Path v334_7_head{v334_7_label};
        const Space v335_2 = singleton(v334_7_head);
        const Space v335_3 = intersect(constant_2,v335_2);
        const Space v335_4 = (has_head(v335_3) ? constant_3 : Space{});
        const Space v335_5 = subtract(constant_1,v335_4);
        Space v335_8;
        if (!v335_5.empty()) {
          const Path v336_6 = concat_path(v334_6,v334_7_head);
          const Space v336_7 = routine_44(c, v336_6, p1, v334_7_tail);
          v335_8 = compose(v335_5,v336_7);
        }
        const Space v335_9 = intersect(constant_2,v335_2);
        const Space v335_10 = (has_head(v335_9) ? constant_3 : Space{});
        Space v335_12;
        if (!v335_10.empty()) {
          const Path v337_6 = concat_path(v334_6,v334_7_head);
          const Space v337_11 = routine_45(c, v337_6, p1, v334_7_tail);
          v335_12 = compose(v335_10,v337_11);
        }
        const Space v335_13 = unite(v335_8,v335_12);
        v334_7_result = unite(v334_7_result,v335_13);
      }
      const Space v334_7 = std::move(v334_7_result);
      v333_8 = compose(v333_5,v334_7);
    }
    const Space v333_9 = intersect(constant_2,v333_2);
    const Space v333_10 = (has_head(v333_9) ? constant_3 : Space{});
    Space v333_12;
    if (!v333_10.empty()) {
      const Path v338_6 = concat_path(p0,v332_12_head);
      Space v338_11_result;
      for (int v338_11_label = 1; v338_11_label <= 2; ++v338_11_label) {
        const Space v338_11_tail = child(v332_12_tail,v338_11_label);
        if (v338_11_tail.empty()) continue;
        const Path v338_11_head{v338_11_label};
        const Space v339_2 = singleton(v338_11_head);
        const Space v339_3 = intersect(constant_2,v339_2);
        const Space v339_4 = (has_head(v339_3) ? constant_3 : Space{});
        const Space v339_5 = subtract(constant_1,v339_4);
        Space v339_8;
        if (!v339_5.empty()) {
          const Path v340_6 = concat_path(v338_6,v338_11_head);
          const Space v340_7 = routine_44(c, v340_6, p1, v338_11_tail);
          v339_8 = compose(v339_5,v340_7);
        }
        const Space v339_9 = intersect(constant_2,v339_2);
        const Space v339_10 = (has_head(v339_9) ? constant_3 : Space{});
        Space v339_12;
        if (!v339_10.empty()) {
          const Path v341_6 = concat_path(v338_6,v338_11_head);
          const Space v341_11 = routine_21(c, v341_6, p1, v338_11_tail);
          v339_12 = compose(v339_10,v341_11);
        }
        const Space v339_13 = unite(v339_8,v339_12);
        v338_11_result = unite(v338_11_result,v339_13);
      }
      const Space v338_11 = std::move(v338_11_result);
      v333_12 = compose(v333_10,v338_11);
    }
    const Space v333_13 = unite(v333_8,v333_12);
    v332_12_result = unite(v332_12_result,v333_13);
  }
  const Space v332_12 = std::move(v332_12_result);
  return v332_12;
}

static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v342_9_result;
  for (int v342_9_label = 1; v342_9_label <= 2; ++v342_9_label) {
    const Space v342_9_tail = child(s0,v342_9_label);
    if (v342_9_tail.empty()) continue;
    const Path v342_9_head{v342_9_label};
    const Space v343_2 = singleton(v342_9_head);
    const Space v343_3 = intersect(constant_2,v343_2);
    const Space v343_4 = (has_head(v343_3) ? constant_3 : Space{});
    const Space v343_5 = subtract(constant_1,v343_4);
    Space v343_8;
    if (!v343_5.empty()) {
      const Path v344_6 = concat_path(p0,v342_9_head);
      Space v344_7_result;
      for (int v344_7_label = 1; v344_7_label <= 2; ++v344_7_label) {
        const Space v344_7_tail = child(v342_9_tail,v344_7_label);
        if (v344_7_tail.empty()) continue;
        const Path v344_7_head{v344_7_label};
        const Space v345_2 = singleton(v344_7_head);
        const Space v345_3 = intersect(constant_2,v345_2);
        const Space v345_4 = (has_head(v345_3) ? constant_3 : Space{});
        const Space v345_5 = subtract(constant_1,v345_4);
        Space v345_8;
        if (!v345_5.empty()) {
          const Path v346_6 = concat_path(v344_6,v344_7_head);
          const Space v346_7 = routine_44(c, v346_6, p1, v344_7_tail);
          v345_8 = compose(v345_5,v346_7);
        }
        const Space v345_9 = intersect(constant_2,v345_2);
        const Space v345_10 = (has_head(v345_9) ? constant_3 : Space{});
        Space v345_12;
        if (!v345_10.empty()) {
          const Path v347_6 = concat_path(v344_6,v344_7_head);
          const Space v347_11 = routine_45(c, v347_6, p1, v344_7_tail);
          v345_12 = compose(v345_10,v347_11);
        }
        const Space v345_13 = unite(v345_8,v345_12);
        v344_7_result = unite(v344_7_result,v345_13);
      }
      const Space v344_7 = std::move(v344_7_result);
      v343_8 = compose(v343_5,v344_7);
    }
    const Space v343_9 = intersect(constant_2,v343_2);
    const Space v343_10 = (has_head(v343_9) ? constant_3 : Space{});
    const Space v343_11 = compose(v343_10,v342_9_tail);
    const Path v348_6 = concat_path(p0,v342_9_head);
    const Space v343_12 = wrap(v343_11,v348_6);
    const Space v343_13 = wrap(v343_12,p1);
    const Space v343_14 = unite(v343_8,v343_13);
    v342_9_result = unite(v342_9_result,v343_14);
  }
  const Space v342_9 = std::move(v342_9_result);
  return v342_9;
}

static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v349_13_result;
  for (int v349_13_label = 1; v349_13_label <= 2; ++v349_13_label) {
    const Space v349_13_tail = child(s0,v349_13_label);
    if (v349_13_tail.empty()) continue;
    const Path v349_13_head{v349_13_label};
    const Space v350_2 = singleton(v349_13_head);
    const Space v350_3 = intersect(constant_2,v350_2);
    const Space v350_4 = (has_head(v350_3) ? constant_3 : Space{});
    const Space v350_5 = subtract(constant_1,v350_4);
    Space v350_8;
    if (!v350_5.empty()) {
      const Path v351_6 = concat_path(p0,v349_13_head);
      Space v351_7_result;
      for (int v351_7_label = 1; v351_7_label <= 2; ++v351_7_label) {
        const Space v351_7_tail = child(v349_13_tail,v351_7_label);
        if (v351_7_tail.empty()) continue;
        const Path v351_7_head{v351_7_label};
        const Space v352_2 = singleton(v351_7_head);
        const Space v352_3 = intersect(constant_2,v352_2);
        const Space v352_4 = (has_head(v352_3) ? constant_3 : Space{});
        const Space v352_5 = subtract(constant_1,v352_4);
        Space v352_8;
        if (!v352_5.empty()) {
          const Path v353_6 = concat_path(v351_6,v351_7_head);
          const Space v353_7 = routine_46(c, v353_6, p1, v351_7_tail, s1);
          v352_8 = compose(v352_5,v353_7);
        }
        const Space v352_9 = intersect(constant_2,v352_2);
        const Space v352_10 = (has_head(v352_9) ? constant_3 : Space{});
        Space v352_12;
        if (!v352_10.empty()) {
          const Path v354_6 = concat_path(v351_6,v351_7_head);
          const Space v354_11 = routine_47(c, v354_6, p1, v351_7_tail, s1);
          v352_12 = compose(v352_10,v354_11);
        }
        const Space v352_13 = unite(v352_8,v352_12);
        v351_7_result = unite(v351_7_result,v352_13);
      }
      const Space v351_7 = std::move(v351_7_result);
      v350_8 = compose(v350_5,v351_7);
    }
    const Space v350_9 = intersect(constant_2,v350_2);
    const Space v350_10 = (has_head(v350_9) ? constant_3 : Space{});
    Space v350_12;
    if (!v350_10.empty()) {
      const Path v355_6 = concat_path(p0,v349_13_head);
      Space v355_11_result;
      for (int v355_11_label = 1; v355_11_label <= 2; ++v355_11_label) {
        const Space v355_11_tail = child(v349_13_tail,v355_11_label);
        if (v355_11_tail.empty()) continue;
        const Path v355_11_head{v355_11_label};
        const Space v356_2 = singleton(v355_11_head);
        const Space v356_3 = intersect(constant_2,v356_2);
        const Space v356_4 = (has_head(v356_3) ? constant_3 : Space{});
        const Space v356_5 = subtract(constant_1,v356_4);
        Space v356_8;
        if (!v356_5.empty()) {
          const Path v357_6 = concat_path(v355_6,v355_11_head);
          const Space v357_7 = routine_46(c, v357_6, p1, v355_11_tail, s1);
          v356_8 = compose(v356_5,v357_7);
        }
        const Space v356_9 = intersect(constant_2,v356_2);
        const Space v356_10 = (has_head(v356_9) ? constant_3 : Space{});
        Space v356_12;
        if (!v356_10.empty()) {
          const Path v358_6 = concat_path(v355_6,v355_11_head);
          const Space v358_11 = routine_10(c, v358_6, p1, v355_11_tail, s1);
          v356_12 = compose(v356_10,v358_11);
        }
        const Space v356_13 = unite(v356_8,v356_12);
        v355_11_result = unite(v355_11_result,v356_13);
      }
      const Space v355_11 = std::move(v355_11_result);
      v350_12 = compose(v350_10,v355_11);
    }
    const Space v350_13 = unite(v350_8,v350_12);
    v349_13_result = unite(v349_13_result,v350_13);
  }
  const Space v349_13 = std::move(v349_13_result);
  return v349_13;
}

static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v359_8 = unwrap(s1,constant_0);
  const Space v359_9 = unwrap(v359_8,p0);
  Space v359_16_result;
  for (int v359_16_label = 1; v359_16_label <= 2; ++v359_16_label) {
    const Space v359_16_tail = child(s0,v359_16_label);
    if (v359_16_tail.empty()) continue;
    const Path v359_16_head{v359_16_label};
    const Space v360_2 = singleton(v359_16_head);
    const Space v360_3 = intersect(constant_2,v360_2);
    const Space v360_4 = (has_head(v360_3) ? constant_3 : Space{});
    const Space v360_5 = subtract(constant_1,v360_4);
    Space v360_8;
    if (!v360_5.empty()) {
      const Path v361_6 = concat_path(p0,v359_16_head);
      Space v361_7_result;
      for (int v361_7_label = 1; v361_7_label <= 2; ++v361_7_label) {
        const Space v361_7_tail = child(v359_16_tail,v361_7_label);
        if (v361_7_tail.empty()) continue;
        const Path v361_7_head{v361_7_label};
        const Space v362_2 = singleton(v361_7_head);
        const Space v362_3 = intersect(constant_2,v362_2);
        const Space v362_4 = (has_head(v362_3) ? constant_3 : Space{});
        const Space v362_5 = subtract(constant_1,v362_4);
        Space v362_8;
        if (!v362_5.empty()) {
          const Path v363_6 = concat_path(v361_6,v361_7_head);
          const Space v363_7 = routine_46(c, v363_6, p1, v361_7_tail, s1);
          v362_8 = compose(v362_5,v363_7);
        }
        const Space v362_9 = intersect(constant_2,v362_2);
        const Space v362_10 = (has_head(v362_9) ? constant_3 : Space{});
        Space v362_12;
        if (!v362_10.empty()) {
          const Path v364_6 = concat_path(v361_6,v361_7_head);
          const Space v364_11 = routine_47(c, v364_6, p1, v361_7_tail, s1);
          v362_12 = compose(v362_10,v364_11);
        }
        const Space v362_13 = unite(v362_8,v362_12);
        v361_7_result = unite(v361_7_result,v362_13);
      }
      const Space v361_7 = std::move(v361_7_result);
      v360_8 = compose(v360_5,v361_7);
    }
    const Space v360_9 = intersect(constant_2,v360_2);
    const Space v360_10 = (has_head(v360_9) ? constant_3 : Space{});
    Space v360_13;
    if (!v360_10.empty()) {
      const Space v365_11 = unwrap(v359_9,v359_16_head);
      Space v365_12_result;
      for (int v365_12_label = 1; v365_12_label <= 2; ++v365_12_label) {
        const Space v365_12_tail = child(v365_11,v365_12_label);
        if (v365_12_tail.empty()) continue;
        const Path v365_12_head{v365_12_label};
        const Space v366_2 = singleton(v365_12_head);
        const Space v366_3 = intersect(constant_2,v366_2);
        const Space v366_4 = (has_head(v366_3) ? constant_3 : Space{});
        const Space v366_5 = subtract(constant_1,v366_4);
        Space v366_7;
        if (!v366_5.empty()) {
          const Space v367_6 = routine_15(c, v365_12_head, p1, v365_12_tail);
          v366_7 = compose(v366_5,v367_6);
        }
        const Space v366_8 = intersect(constant_2,v366_2);
        const Space v366_9 = (has_head(v366_8) ? constant_3 : Space{});
        Space v366_11;
        if (!v366_9.empty()) {
          const Space v368_10 = routine_16(c, v365_12_head, p1, v365_12_tail);
          v366_11 = compose(v366_9,v368_10);
        }
        const Space v366_12 = unite(v366_7,v366_11);
        v365_12_result = unite(v365_12_result,v366_12);
      }
      const Space v365_12 = std::move(v365_12_result);
      v360_13 = compose(v360_10,v365_12);
    }
    const Space v360_14 = unite(v360_8,v360_13);
    v359_16_result = unite(v359_16_result,v360_14);
  }
  const Space v359_16 = std::move(v359_16_result);
  return v359_16;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v369_12_result;
  for (int v369_12_label = 1; v369_12_label <= 2; ++v369_12_label) {
    const Space v369_12_tail = child(s0,v369_12_label);
    if (v369_12_tail.empty()) continue;
    const Path v369_12_head{v369_12_label};
    const Space v370_2 = singleton(v369_12_head);
    const Space v370_3 = intersect(constant_2,v370_2);
    const Space v370_4 = (has_head(v370_3) ? constant_3 : Space{});
    const Space v370_5 = subtract(constant_1,v370_4);
    Space v370_8;
    if (!v370_5.empty()) {
      const Path v371_6 = concat_path(p0,v369_12_head);
      Space v371_7_result;
      for (int v371_7_label = 1; v371_7_label <= 2; ++v371_7_label) {
        const Space v371_7_tail = child(v369_12_tail,v371_7_label);
        if (v371_7_tail.empty()) continue;
        const Path v371_7_head{v371_7_label};
        const Space v372_2 = singleton(v371_7_head);
        const Space v372_3 = intersect(constant_2,v372_2);
        const Space v372_4 = (has_head(v372_3) ? constant_3 : Space{});
        const Space v372_5 = subtract(constant_1,v372_4);
        Space v372_8;
        if (!v372_5.empty()) {
          const Path v373_6 = concat_path(v371_6,v371_7_head);
          const Space v373_7 = routine_48(c, v373_6, p1, v371_7_tail);
          v372_8 = compose(v372_5,v373_7);
        }
        const Space v372_9 = intersect(constant_2,v372_2);
        const Space v372_10 = (has_head(v372_9) ? constant_3 : Space{});
        Space v372_12;
        if (!v372_10.empty()) {
          const Path v374_6 = concat_path(v371_6,v371_7_head);
          const Space v374_11 = routine_49(c, v374_6, p1, v371_7_tail);
          v372_12 = compose(v372_10,v374_11);
        }
        const Space v372_13 = unite(v372_8,v372_12);
        v371_7_result = unite(v371_7_result,v372_13);
      }
      const Space v371_7 = std::move(v371_7_result);
      v370_8 = compose(v370_5,v371_7);
    }
    const Space v370_9 = intersect(constant_2,v370_2);
    const Space v370_10 = (has_head(v370_9) ? constant_3 : Space{});
    Space v370_12;
    if (!v370_10.empty()) {
      const Path v375_6 = concat_path(p0,v369_12_head);
      Space v375_11_result;
      for (int v375_11_label = 1; v375_11_label <= 2; ++v375_11_label) {
        const Space v375_11_tail = child(v369_12_tail,v375_11_label);
        if (v375_11_tail.empty()) continue;
        const Path v375_11_head{v375_11_label};
        const Space v376_2 = singleton(v375_11_head);
        const Space v376_3 = intersect(constant_2,v376_2);
        const Space v376_4 = (has_head(v376_3) ? constant_3 : Space{});
        const Space v376_5 = subtract(constant_1,v376_4);
        Space v376_8;
        if (!v376_5.empty()) {
          const Path v377_6 = concat_path(v375_6,v375_11_head);
          const Space v377_7 = routine_48(c, v377_6, p1, v375_11_tail);
          v376_8 = compose(v376_5,v377_7);
        }
        const Space v376_9 = intersect(constant_2,v376_2);
        const Space v376_10 = (has_head(v376_9) ? constant_3 : Space{});
        Space v376_12;
        if (!v376_10.empty()) {
          const Path v378_6 = concat_path(v375_6,v375_11_head);
          const Space v378_11 = routine_21(c, v378_6, p1, v375_11_tail);
          v376_12 = compose(v376_10,v378_11);
        }
        const Space v376_13 = unite(v376_8,v376_12);
        v375_11_result = unite(v375_11_result,v376_13);
      }
      const Space v375_11 = std::move(v375_11_result);
      v370_12 = compose(v370_10,v375_11);
    }
    const Space v370_13 = unite(v370_8,v370_12);
    v369_12_result = unite(v369_12_result,v370_13);
  }
  const Space v369_12 = std::move(v369_12_result);
  return v369_12;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v379_9_result;
  for (int v379_9_label = 1; v379_9_label <= 2; ++v379_9_label) {
    const Space v379_9_tail = child(s0,v379_9_label);
    if (v379_9_tail.empty()) continue;
    const Path v379_9_head{v379_9_label};
    const Space v380_2 = singleton(v379_9_head);
    const Space v380_3 = intersect(constant_2,v380_2);
    const Space v380_4 = (has_head(v380_3) ? constant_3 : Space{});
    const Space v380_5 = subtract(constant_1,v380_4);
    Space v380_8;
    if (!v380_5.empty()) {
      const Path v381_6 = concat_path(p0,v379_9_head);
      Space v381_7_result;
      for (int v381_7_label = 1; v381_7_label <= 2; ++v381_7_label) {
        const Space v381_7_tail = child(v379_9_tail,v381_7_label);
        if (v381_7_tail.empty()) continue;
        const Path v381_7_head{v381_7_label};
        const Space v382_2 = singleton(v381_7_head);
        const Space v382_3 = intersect(constant_2,v382_2);
        const Space v382_4 = (has_head(v382_3) ? constant_3 : Space{});
        const Space v382_5 = subtract(constant_1,v382_4);
        Space v382_8;
        if (!v382_5.empty()) {
          const Path v383_6 = concat_path(v381_6,v381_7_head);
          const Space v383_7 = routine_48(c, v383_6, p1, v381_7_tail);
          v382_8 = compose(v382_5,v383_7);
        }
        const Space v382_9 = intersect(constant_2,v382_2);
        const Space v382_10 = (has_head(v382_9) ? constant_3 : Space{});
        Space v382_12;
        if (!v382_10.empty()) {
          const Path v384_6 = concat_path(v381_6,v381_7_head);
          const Space v384_11 = routine_49(c, v384_6, p1, v381_7_tail);
          v382_12 = compose(v382_10,v384_11);
        }
        const Space v382_13 = unite(v382_8,v382_12);
        v381_7_result = unite(v381_7_result,v382_13);
      }
      const Space v381_7 = std::move(v381_7_result);
      v380_8 = compose(v380_5,v381_7);
    }
    const Space v380_9 = intersect(constant_2,v380_2);
    const Space v380_10 = (has_head(v380_9) ? constant_3 : Space{});
    const Space v380_11 = compose(v380_10,v379_9_tail);
    const Path v385_6 = concat_path(p0,v379_9_head);
    const Space v380_12 = wrap(v380_11,v385_6);
    const Space v380_13 = wrap(v380_12,p1);
    const Space v380_14 = unite(v380_8,v380_13);
    v379_9_result = unite(v379_9_result,v380_14);
  }
  const Space v379_9 = std::move(v379_9_result);
  return v379_9;
}

static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v386_13_result;
  for (int v386_13_label = 1; v386_13_label <= 2; ++v386_13_label) {
    const Space v386_13_tail = child(s0,v386_13_label);
    if (v386_13_tail.empty()) continue;
    const Path v386_13_head{v386_13_label};
    const Space v387_2 = singleton(v386_13_head);
    const Space v387_3 = intersect(constant_2,v387_2);
    const Space v387_4 = (has_head(v387_3) ? constant_3 : Space{});
    const Space v387_5 = subtract(constant_1,v387_4);
    Space v387_8;
    if (!v387_5.empty()) {
      const Path v388_6 = concat_path(p0,v386_13_head);
      Space v388_7_result;
      for (int v388_7_label = 1; v388_7_label <= 2; ++v388_7_label) {
        const Space v388_7_tail = child(v386_13_tail,v388_7_label);
        if (v388_7_tail.empty()) continue;
        const Path v388_7_head{v388_7_label};
        const Space v389_2 = singleton(v388_7_head);
        const Space v389_3 = intersect(constant_2,v389_2);
        const Space v389_4 = (has_head(v389_3) ? constant_3 : Space{});
        const Space v389_5 = subtract(constant_1,v389_4);
        Space v389_8;
        if (!v389_5.empty()) {
          const Path v390_6 = concat_path(v388_6,v388_7_head);
          const Space v390_7 = routine_50(c, v390_6, p1, v388_7_tail, s1);
          v389_8 = compose(v389_5,v390_7);
        }
        const Space v389_9 = intersect(constant_2,v389_2);
        const Space v389_10 = (has_head(v389_9) ? constant_3 : Space{});
        Space v389_12;
        if (!v389_10.empty()) {
          const Path v391_6 = concat_path(v388_6,v388_7_head);
          const Space v391_11 = routine_51(c, v391_6, p1, v388_7_tail, s1);
          v389_12 = compose(v389_10,v391_11);
        }
        const Space v389_13 = unite(v389_8,v389_12);
        v388_7_result = unite(v388_7_result,v389_13);
      }
      const Space v388_7 = std::move(v388_7_result);
      v387_8 = compose(v387_5,v388_7);
    }
    const Space v387_9 = intersect(constant_2,v387_2);
    const Space v387_10 = (has_head(v387_9) ? constant_3 : Space{});
    Space v387_12;
    if (!v387_10.empty()) {
      const Path v392_6 = concat_path(p0,v386_13_head);
      Space v392_11_result;
      for (int v392_11_label = 1; v392_11_label <= 2; ++v392_11_label) {
        const Space v392_11_tail = child(v386_13_tail,v392_11_label);
        if (v392_11_tail.empty()) continue;
        const Path v392_11_head{v392_11_label};
        const Space v393_2 = singleton(v392_11_head);
        const Space v393_3 = intersect(constant_2,v393_2);
        const Space v393_4 = (has_head(v393_3) ? constant_3 : Space{});
        const Space v393_5 = subtract(constant_1,v393_4);
        Space v393_8;
        if (!v393_5.empty()) {
          const Path v394_6 = concat_path(v392_6,v392_11_head);
          const Space v394_7 = routine_50(c, v394_6, p1, v392_11_tail, s1);
          v393_8 = compose(v393_5,v394_7);
        }
        const Space v393_9 = intersect(constant_2,v393_2);
        const Space v393_10 = (has_head(v393_9) ? constant_3 : Space{});
        Space v393_12;
        if (!v393_10.empty()) {
          const Path v395_6 = concat_path(v392_6,v392_11_head);
          const Space v395_11 = routine_10(c, v395_6, p1, v392_11_tail, s1);
          v393_12 = compose(v393_10,v395_11);
        }
        const Space v393_13 = unite(v393_8,v393_12);
        v392_11_result = unite(v392_11_result,v393_13);
      }
      const Space v392_11 = std::move(v392_11_result);
      v387_12 = compose(v387_10,v392_11);
    }
    const Space v387_13 = unite(v387_8,v387_12);
    v386_13_result = unite(v386_13_result,v387_13);
  }
  const Space v386_13 = std::move(v386_13_result);
  return v386_13;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v396_8 = unwrap(s1,constant_0);
  const Space v396_9 = unwrap(v396_8,p0);
  Space v396_16_result;
  for (int v396_16_label = 1; v396_16_label <= 2; ++v396_16_label) {
    const Space v396_16_tail = child(s0,v396_16_label);
    if (v396_16_tail.empty()) continue;
    const Path v396_16_head{v396_16_label};
    const Space v397_2 = singleton(v396_16_head);
    const Space v397_3 = intersect(constant_2,v397_2);
    const Space v397_4 = (has_head(v397_3) ? constant_3 : Space{});
    const Space v397_5 = subtract(constant_1,v397_4);
    Space v397_8;
    if (!v397_5.empty()) {
      const Path v398_6 = concat_path(p0,v396_16_head);
      Space v398_7_result;
      for (int v398_7_label = 1; v398_7_label <= 2; ++v398_7_label) {
        const Space v398_7_tail = child(v396_16_tail,v398_7_label);
        if (v398_7_tail.empty()) continue;
        const Path v398_7_head{v398_7_label};
        const Space v399_2 = singleton(v398_7_head);
        const Space v399_3 = intersect(constant_2,v399_2);
        const Space v399_4 = (has_head(v399_3) ? constant_3 : Space{});
        const Space v399_5 = subtract(constant_1,v399_4);
        Space v399_8;
        if (!v399_5.empty()) {
          const Path v400_6 = concat_path(v398_6,v398_7_head);
          const Space v400_7 = routine_50(c, v400_6, p1, v398_7_tail, s1);
          v399_8 = compose(v399_5,v400_7);
        }
        const Space v399_9 = intersect(constant_2,v399_2);
        const Space v399_10 = (has_head(v399_9) ? constant_3 : Space{});
        Space v399_12;
        if (!v399_10.empty()) {
          const Path v401_6 = concat_path(v398_6,v398_7_head);
          const Space v401_11 = routine_51(c, v401_6, p1, v398_7_tail, s1);
          v399_12 = compose(v399_10,v401_11);
        }
        const Space v399_13 = unite(v399_8,v399_12);
        v398_7_result = unite(v398_7_result,v399_13);
      }
      const Space v398_7 = std::move(v398_7_result);
      v397_8 = compose(v397_5,v398_7);
    }
    const Space v397_9 = intersect(constant_2,v397_2);
    const Space v397_10 = (has_head(v397_9) ? constant_3 : Space{});
    Space v397_13;
    if (!v397_10.empty()) {
      const Space v402_11 = unwrap(v396_9,v396_16_head);
      Space v402_12_result;
      for (int v402_12_label = 1; v402_12_label <= 2; ++v402_12_label) {
        const Space v402_12_tail = child(v402_11,v402_12_label);
        if (v402_12_tail.empty()) continue;
        const Path v402_12_head{v402_12_label};
        const Space v403_2 = singleton(v402_12_head);
        const Space v403_3 = intersect(constant_2,v403_2);
        const Space v403_4 = (has_head(v403_3) ? constant_3 : Space{});
        const Space v403_5 = subtract(constant_1,v403_4);
        Space v403_7;
        if (!v403_5.empty()) {
          const Space v404_6 = routine_15(c, v402_12_head, p1, v402_12_tail);
          v403_7 = compose(v403_5,v404_6);
        }
        const Space v403_8 = intersect(constant_2,v403_2);
        const Space v403_9 = (has_head(v403_8) ? constant_3 : Space{});
        Space v403_11;
        if (!v403_9.empty()) {
          const Space v405_10 = routine_16(c, v402_12_head, p1, v402_12_tail);
          v403_11 = compose(v403_9,v405_10);
        }
        const Space v403_12 = unite(v403_7,v403_11);
        v402_12_result = unite(v402_12_result,v403_12);
      }
      const Space v402_12 = std::move(v402_12_result);
      v397_13 = compose(v397_10,v402_12);
    }
    const Space v397_14 = unite(v397_8,v397_13);
    v396_16_result = unite(v396_16_result,v397_14);
  }
  const Space v396_16 = std::move(v396_16_result);
  return v396_16;
}

static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v406_12_result;
  for (int v406_12_label = 1; v406_12_label <= 2; ++v406_12_label) {
    const Space v406_12_tail = child(s0,v406_12_label);
    if (v406_12_tail.empty()) continue;
    const Path v406_12_head{v406_12_label};
    const Space v407_2 = singleton(v406_12_head);
    const Space v407_3 = intersect(constant_2,v407_2);
    const Space v407_4 = (has_head(v407_3) ? constant_3 : Space{});
    const Space v407_5 = subtract(constant_1,v407_4);
    Space v407_8;
    if (!v407_5.empty()) {
      const Path v408_6 = concat_path(p0,v406_12_head);
      Space v408_7_result;
      for (int v408_7_label = 1; v408_7_label <= 2; ++v408_7_label) {
        const Space v408_7_tail = child(v406_12_tail,v408_7_label);
        if (v408_7_tail.empty()) continue;
        const Path v408_7_head{v408_7_label};
        const Space v409_2 = singleton(v408_7_head);
        const Space v409_3 = intersect(constant_2,v409_2);
        const Space v409_4 = (has_head(v409_3) ? constant_3 : Space{});
        const Space v409_5 = subtract(constant_1,v409_4);
        Space v409_8;
        if (!v409_5.empty()) {
          const Path v410_6 = concat_path(v408_6,v408_7_head);
          const Space v410_7 = routine_52(c, v410_6, p1, v408_7_tail);
          v409_8 = compose(v409_5,v410_7);
        }
        const Space v409_9 = intersect(constant_2,v409_2);
        const Space v409_10 = (has_head(v409_9) ? constant_3 : Space{});
        Space v409_12;
        if (!v409_10.empty()) {
          const Path v411_6 = concat_path(v408_6,v408_7_head);
          const Space v411_11 = routine_53(c, v411_6, p1, v408_7_tail);
          v409_12 = compose(v409_10,v411_11);
        }
        const Space v409_13 = unite(v409_8,v409_12);
        v408_7_result = unite(v408_7_result,v409_13);
      }
      const Space v408_7 = std::move(v408_7_result);
      v407_8 = compose(v407_5,v408_7);
    }
    const Space v407_9 = intersect(constant_2,v407_2);
    const Space v407_10 = (has_head(v407_9) ? constant_3 : Space{});
    Space v407_12;
    if (!v407_10.empty()) {
      const Path v412_6 = concat_path(p0,v406_12_head);
      Space v412_11_result;
      for (int v412_11_label = 1; v412_11_label <= 2; ++v412_11_label) {
        const Space v412_11_tail = child(v406_12_tail,v412_11_label);
        if (v412_11_tail.empty()) continue;
        const Path v412_11_head{v412_11_label};
        const Space v413_2 = singleton(v412_11_head);
        const Space v413_3 = intersect(constant_2,v413_2);
        const Space v413_4 = (has_head(v413_3) ? constant_3 : Space{});
        const Space v413_5 = subtract(constant_1,v413_4);
        Space v413_8;
        if (!v413_5.empty()) {
          const Path v414_6 = concat_path(v412_6,v412_11_head);
          const Space v414_7 = routine_52(c, v414_6, p1, v412_11_tail);
          v413_8 = compose(v413_5,v414_7);
        }
        const Space v413_9 = intersect(constant_2,v413_2);
        const Space v413_10 = (has_head(v413_9) ? constant_3 : Space{});
        Space v413_12;
        if (!v413_10.empty()) {
          const Path v415_6 = concat_path(v412_6,v412_11_head);
          const Space v415_11 = routine_21(c, v415_6, p1, v412_11_tail);
          v413_12 = compose(v413_10,v415_11);
        }
        const Space v413_13 = unite(v413_8,v413_12);
        v412_11_result = unite(v412_11_result,v413_13);
      }
      const Space v412_11 = std::move(v412_11_result);
      v407_12 = compose(v407_10,v412_11);
    }
    const Space v407_13 = unite(v407_8,v407_12);
    v406_12_result = unite(v406_12_result,v407_13);
  }
  const Space v406_12 = std::move(v406_12_result);
  return v406_12;
}

static Space routine_45(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v416_9_result;
  for (int v416_9_label = 1; v416_9_label <= 2; ++v416_9_label) {
    const Space v416_9_tail = child(s0,v416_9_label);
    if (v416_9_tail.empty()) continue;
    const Path v416_9_head{v416_9_label};
    const Space v417_2 = singleton(v416_9_head);
    const Space v417_3 = intersect(constant_2,v417_2);
    const Space v417_4 = (has_head(v417_3) ? constant_3 : Space{});
    const Space v417_5 = subtract(constant_1,v417_4);
    Space v417_8;
    if (!v417_5.empty()) {
      const Path v418_6 = concat_path(p0,v416_9_head);
      Space v418_7_result;
      for (int v418_7_label = 1; v418_7_label <= 2; ++v418_7_label) {
        const Space v418_7_tail = child(v416_9_tail,v418_7_label);
        if (v418_7_tail.empty()) continue;
        const Path v418_7_head{v418_7_label};
        const Space v419_2 = singleton(v418_7_head);
        const Space v419_3 = intersect(constant_2,v419_2);
        const Space v419_4 = (has_head(v419_3) ? constant_3 : Space{});
        const Space v419_5 = subtract(constant_1,v419_4);
        Space v419_8;
        if (!v419_5.empty()) {
          const Path v420_6 = concat_path(v418_6,v418_7_head);
          const Space v420_7 = routine_52(c, v420_6, p1, v418_7_tail);
          v419_8 = compose(v419_5,v420_7);
        }
        const Space v419_9 = intersect(constant_2,v419_2);
        const Space v419_10 = (has_head(v419_9) ? constant_3 : Space{});
        Space v419_12;
        if (!v419_10.empty()) {
          const Path v421_6 = concat_path(v418_6,v418_7_head);
          const Space v421_11 = routine_53(c, v421_6, p1, v418_7_tail);
          v419_12 = compose(v419_10,v421_11);
        }
        const Space v419_13 = unite(v419_8,v419_12);
        v418_7_result = unite(v418_7_result,v419_13);
      }
      const Space v418_7 = std::move(v418_7_result);
      v417_8 = compose(v417_5,v418_7);
    }
    const Space v417_9 = intersect(constant_2,v417_2);
    const Space v417_10 = (has_head(v417_9) ? constant_3 : Space{});
    const Space v417_11 = compose(v417_10,v416_9_tail);
    const Path v422_6 = concat_path(p0,v416_9_head);
    const Space v417_12 = wrap(v417_11,v422_6);
    const Space v417_13 = wrap(v417_12,p1);
    const Space v417_14 = unite(v417_8,v417_13);
    v416_9_result = unite(v416_9_result,v417_14);
  }
  const Space v416_9 = std::move(v416_9_result);
  return v416_9;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v423_8_result;
  for (int v423_8_label = 1; v423_8_label <= 2; ++v423_8_label) {
    const Space v423_8_tail = child(s0,v423_8_label);
    if (v423_8_tail.empty()) continue;
    const Path v423_8_head{v423_8_label};
    const Space v424_2 = singleton(v423_8_head);
    const Space v424_3 = intersect(constant_2,v424_2);
    const Space v424_4 = (has_head(v424_3) ? constant_3 : Space{});
    const Space v424_5 = subtract(constant_1,v424_4);
    Space v424_6_result;
    for (int v424_6_label = 1; v424_6_label <= 2; ++v424_6_label) {
      const Space v424_6_tail = child(v423_8_tail,v424_6_label);
      if (v424_6_tail.empty()) continue;
      const Path v424_6_head{v424_6_label};
      const Space v425_2 = Space{};
      v424_6_result = unite(v424_6_result,v425_2);
    }
    const Space v424_6 = std::move(v424_6_result);
    const Space v424_7 = compose(v424_5,v424_6);
    const Space v424_8 = intersect(constant_2,v424_2);
    const Space v424_9 = (has_head(v424_8) ? constant_3 : Space{});
    Space v424_12;
    if (!v424_9.empty()) {
      const Path v426_10 = concat_path(p0,v423_8_head);
      Space v426_11_result;
      for (int v426_11_label = 1; v426_11_label <= 2; ++v426_11_label) {
        const Space v426_11_tail = child(v423_8_tail,v426_11_label);
        if (v426_11_tail.empty()) continue;
        const Path v426_11_head{v426_11_label};
        const Space v427_2 = singleton(v426_11_head);
        const Space v427_3 = intersect(constant_2,v427_2);
        const Space v427_4 = (has_head(v427_3) ? constant_3 : Space{});
        Space v427_7;
        if (!v427_4.empty()) {
          const Path v428_5 = concat_path(v426_10,v426_11_head);
          const Space v428_6 = routine_10(c, v428_5, p1, v426_11_tail, s1);
          v427_7 = compose(v427_4,v428_6);
        }
        v426_11_result = unite(v426_11_result,v427_7);
      }
      const Space v426_11 = std::move(v426_11_result);
      v424_12 = compose(v424_9,v426_11);
    }
    const Space v424_13 = unite(v424_7,v424_12);
    v423_8_result = unite(v423_8_result,v424_13);
  }
  const Space v423_8 = std::move(v423_8_result);
  return v423_8;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v429_8 = unwrap(s1,constant_0);
  const Space v429_9 = unwrap(v429_8,p0);
  Space v429_13_result;
  for (int v429_13_label = 1; v429_13_label <= 2; ++v429_13_label) {
    const Space v429_13_tail = child(s0,v429_13_label);
    if (v429_13_tail.empty()) continue;
    const Path v429_13_head{v429_13_label};
    const Space v430_2 = singleton(v429_13_head);
    const Space v430_3 = intersect(constant_2,v430_2);
    const Space v430_4 = (has_head(v430_3) ? constant_3 : Space{});
    const Space v430_5 = subtract(constant_1,v430_4);
    Space v430_6_result;
    for (int v430_6_label = 1; v430_6_label <= 2; ++v430_6_label) {
      const Space v430_6_tail = child(v429_13_tail,v430_6_label);
      if (v430_6_tail.empty()) continue;
      const Path v430_6_head{v430_6_label};
      const Space v431_2 = Space{};
      v430_6_result = unite(v430_6_result,v431_2);
    }
    const Space v430_6 = std::move(v430_6_result);
    const Space v430_7 = compose(v430_5,v430_6);
    const Space v430_8 = intersect(constant_2,v430_2);
    const Space v430_9 = (has_head(v430_8) ? constant_3 : Space{});
    Space v430_12;
    if (!v430_9.empty()) {
      const Space v432_10 = unwrap(v429_9,v429_13_head);
      Space v432_11_result;
      for (int v432_11_label = 1; v432_11_label <= 2; ++v432_11_label) {
        const Space v432_11_tail = child(v432_10,v432_11_label);
        if (v432_11_tail.empty()) continue;
        const Path v432_11_head{v432_11_label};
        const Space v433_2 = singleton(v432_11_head);
        const Space v433_3 = intersect(constant_2,v433_2);
        const Space v433_4 = (has_head(v433_3) ? constant_3 : Space{});
        const Space v433_5 = subtract(constant_1,v433_4);
        Space v433_7;
        if (!v433_5.empty()) {
          const Space v434_6 = routine_15(c, v432_11_head, p1, v432_11_tail);
          v433_7 = compose(v433_5,v434_6);
        }
        const Space v433_8 = intersect(constant_2,v433_2);
        const Space v433_9 = (has_head(v433_8) ? constant_3 : Space{});
        Space v433_11;
        if (!v433_9.empty()) {
          const Space v435_10 = routine_16(c, v432_11_head, p1, v432_11_tail);
          v433_11 = compose(v433_9,v435_10);
        }
        const Space v433_12 = unite(v433_7,v433_11);
        v432_11_result = unite(v432_11_result,v433_12);
      }
      const Space v432_11 = std::move(v432_11_result);
      v430_12 = compose(v430_9,v432_11);
    }
    const Space v430_13 = unite(v430_7,v430_12);
    v429_13_result = unite(v429_13_result,v430_13);
  }
  const Space v429_13 = std::move(v429_13_result);
  return v429_13;
}

static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v436_12_result;
  for (int v436_12_label = 1; v436_12_label <= 2; ++v436_12_label) {
    const Space v436_12_tail = child(s0,v436_12_label);
    if (v436_12_tail.empty()) continue;
    const Path v436_12_head{v436_12_label};
    const Space v437_2 = singleton(v436_12_head);
    const Space v437_3 = intersect(constant_2,v437_2);
    const Space v437_4 = (has_head(v437_3) ? constant_3 : Space{});
    const Space v437_5 = subtract(constant_1,v437_4);
    Space v437_8;
    if (!v437_5.empty()) {
      const Path v438_6 = concat_path(p0,v436_12_head);
      Space v438_7_result;
      for (int v438_7_label = 1; v438_7_label <= 2; ++v438_7_label) {
        const Space v438_7_tail = child(v436_12_tail,v438_7_label);
        if (v438_7_tail.empty()) continue;
        const Path v438_7_head{v438_7_label};
        const Space v439_2 = singleton(v438_7_head);
        const Space v439_3 = intersect(constant_2,v439_2);
        const Space v439_4 = (has_head(v439_3) ? constant_3 : Space{});
        const Space v439_5 = subtract(constant_1,v439_4);
        Space v439_8;
        if (!v439_5.empty()) {
          const Path v440_6 = concat_path(v438_6,v438_7_head);
          const Space v440_7 = routine_54(c, v440_6, p1, v438_7_tail);
          v439_8 = compose(v439_5,v440_7);
        }
        const Space v439_9 = intersect(constant_2,v439_2);
        const Space v439_10 = (has_head(v439_9) ? constant_3 : Space{});
        Space v439_12;
        if (!v439_10.empty()) {
          const Path v441_6 = concat_path(v438_6,v438_7_head);
          const Space v441_11 = routine_55(c, v441_6, p1, v438_7_tail);
          v439_12 = compose(v439_10,v441_11);
        }
        const Space v439_13 = unite(v439_8,v439_12);
        v438_7_result = unite(v438_7_result,v439_13);
      }
      const Space v438_7 = std::move(v438_7_result);
      v437_8 = compose(v437_5,v438_7);
    }
    const Space v437_9 = intersect(constant_2,v437_2);
    const Space v437_10 = (has_head(v437_9) ? constant_3 : Space{});
    Space v437_12;
    if (!v437_10.empty()) {
      const Path v442_6 = concat_path(p0,v436_12_head);
      Space v442_11_result;
      for (int v442_11_label = 1; v442_11_label <= 2; ++v442_11_label) {
        const Space v442_11_tail = child(v436_12_tail,v442_11_label);
        if (v442_11_tail.empty()) continue;
        const Path v442_11_head{v442_11_label};
        const Space v443_2 = singleton(v442_11_head);
        const Space v443_3 = intersect(constant_2,v443_2);
        const Space v443_4 = (has_head(v443_3) ? constant_3 : Space{});
        const Space v443_5 = subtract(constant_1,v443_4);
        Space v443_8;
        if (!v443_5.empty()) {
          const Path v444_6 = concat_path(v442_6,v442_11_head);
          const Space v444_7 = routine_54(c, v444_6, p1, v442_11_tail);
          v443_8 = compose(v443_5,v444_7);
        }
        const Space v443_9 = intersect(constant_2,v443_2);
        const Space v443_10 = (has_head(v443_9) ? constant_3 : Space{});
        Space v443_12;
        if (!v443_10.empty()) {
          const Path v445_6 = concat_path(v442_6,v442_11_head);
          const Space v445_11 = routine_21(c, v445_6, p1, v442_11_tail);
          v443_12 = compose(v443_10,v445_11);
        }
        const Space v443_13 = unite(v443_8,v443_12);
        v442_11_result = unite(v442_11_result,v443_13);
      }
      const Space v442_11 = std::move(v442_11_result);
      v437_12 = compose(v437_10,v442_11);
    }
    const Space v437_13 = unite(v437_8,v437_12);
    v436_12_result = unite(v436_12_result,v437_13);
  }
  const Space v436_12 = std::move(v436_12_result);
  return v436_12;
}

static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v446_9_result;
  for (int v446_9_label = 1; v446_9_label <= 2; ++v446_9_label) {
    const Space v446_9_tail = child(s0,v446_9_label);
    if (v446_9_tail.empty()) continue;
    const Path v446_9_head{v446_9_label};
    const Space v447_2 = singleton(v446_9_head);
    const Space v447_3 = intersect(constant_2,v447_2);
    const Space v447_4 = (has_head(v447_3) ? constant_3 : Space{});
    const Space v447_5 = subtract(constant_1,v447_4);
    Space v447_8;
    if (!v447_5.empty()) {
      const Path v448_6 = concat_path(p0,v446_9_head);
      Space v448_7_result;
      for (int v448_7_label = 1; v448_7_label <= 2; ++v448_7_label) {
        const Space v448_7_tail = child(v446_9_tail,v448_7_label);
        if (v448_7_tail.empty()) continue;
        const Path v448_7_head{v448_7_label};
        const Space v449_2 = singleton(v448_7_head);
        const Space v449_3 = intersect(constant_2,v449_2);
        const Space v449_4 = (has_head(v449_3) ? constant_3 : Space{});
        const Space v449_5 = subtract(constant_1,v449_4);
        Space v449_8;
        if (!v449_5.empty()) {
          const Path v450_6 = concat_path(v448_6,v448_7_head);
          const Space v450_7 = routine_54(c, v450_6, p1, v448_7_tail);
          v449_8 = compose(v449_5,v450_7);
        }
        const Space v449_9 = intersect(constant_2,v449_2);
        const Space v449_10 = (has_head(v449_9) ? constant_3 : Space{});
        Space v449_12;
        if (!v449_10.empty()) {
          const Path v451_6 = concat_path(v448_6,v448_7_head);
          const Space v451_11 = routine_55(c, v451_6, p1, v448_7_tail);
          v449_12 = compose(v449_10,v451_11);
        }
        const Space v449_13 = unite(v449_8,v449_12);
        v448_7_result = unite(v448_7_result,v449_13);
      }
      const Space v448_7 = std::move(v448_7_result);
      v447_8 = compose(v447_5,v448_7);
    }
    const Space v447_9 = intersect(constant_2,v447_2);
    const Space v447_10 = (has_head(v447_9) ? constant_3 : Space{});
    const Space v447_11 = compose(v447_10,v446_9_tail);
    const Path v452_6 = concat_path(p0,v446_9_head);
    const Space v447_12 = wrap(v447_11,v452_6);
    const Space v447_13 = wrap(v447_12,p1);
    const Space v447_14 = unite(v447_8,v447_13);
    v446_9_result = unite(v446_9_result,v447_14);
  }
  const Space v446_9 = std::move(v446_9_result);
  return v446_9;
}

static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v453_4_result;
  for (int v453_4_label = 1; v453_4_label <= 2; ++v453_4_label) {
    const Space v453_4_tail = child(s0,v453_4_label);
    if (v453_4_tail.empty()) continue;
    const Path v453_4_head{v453_4_label};
    const Space v454_2 = Space{};
    v453_4_result = unite(v453_4_result,v454_2);
  }
  const Space v453_4 = std::move(v453_4_result);
  return v453_4;
}

static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v455_6 = unwrap(s1,constant_0);
  const Space v455_7 = unwrap(v455_6,p0);
  Space v455_11_result;
  for (int v455_11_label = 1; v455_11_label <= 2; ++v455_11_label) {
    const Space v455_11_tail = child(s0,v455_11_label);
    if (v455_11_tail.empty()) continue;
    const Path v455_11_head{v455_11_label};
    const Space v456_2 = singleton(v455_11_head);
    const Space v456_3 = intersect(constant_2,v456_2);
    const Space v456_4 = (has_head(v456_3) ? constant_3 : Space{});
    Space v456_7;
    if (!v456_4.empty()) {
      const Space v457_5 = unwrap(v455_7,v455_11_head);
      Space v457_6_result;
      for (int v457_6_label = 1; v457_6_label <= 2; ++v457_6_label) {
        const Space v457_6_tail = child(v457_5,v457_6_label);
        if (v457_6_tail.empty()) continue;
        const Path v457_6_head{v457_6_label};
        const Space v458_2 = singleton(v457_6_head);
        const Space v458_3 = intersect(constant_2,v458_2);
        const Space v458_4 = (has_head(v458_3) ? constant_3 : Space{});
        const Space v458_5 = subtract(constant_1,v458_4);
        Space v458_7;
        if (!v458_5.empty()) {
          const Space v459_6 = routine_15(c, v457_6_head, p1, v457_6_tail);
          v458_7 = compose(v458_5,v459_6);
        }
        const Space v458_8 = intersect(constant_2,v458_2);
        const Space v458_9 = (has_head(v458_8) ? constant_3 : Space{});
        Space v458_11;
        if (!v458_9.empty()) {
          const Space v460_10 = routine_16(c, v457_6_head, p1, v457_6_tail);
          v458_11 = compose(v458_9,v460_10);
        }
        const Space v458_12 = unite(v458_7,v458_11);
        v457_6_result = unite(v457_6_result,v458_12);
      }
      const Space v457_6 = std::move(v457_6_result);
      v456_7 = compose(v456_4,v457_6);
    }
    v455_11_result = unite(v455_11_result,v456_7);
  }
  const Space v455_11 = std::move(v455_11_result);
  return v455_11;
}

static Space routine_52(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v461_12_result;
  for (int v461_12_label = 1; v461_12_label <= 2; ++v461_12_label) {
    const Space v461_12_tail = child(s0,v461_12_label);
    if (v461_12_tail.empty()) continue;
    const Path v461_12_head{v461_12_label};
    const Space v462_2 = singleton(v461_12_head);
    const Space v462_3 = intersect(constant_2,v462_2);
    const Space v462_4 = (has_head(v462_3) ? constant_3 : Space{});
    const Space v462_5 = subtract(constant_1,v462_4);
    Space v462_8;
    if (!v462_5.empty()) {
      const Path v463_6 = concat_path(p0,v461_12_head);
      Space v463_7_result;
      for (int v463_7_label = 1; v463_7_label <= 2; ++v463_7_label) {
        const Space v463_7_tail = child(v461_12_tail,v463_7_label);
        if (v463_7_tail.empty()) continue;
        const Path v463_7_head{v463_7_label};
        const Space v464_2 = singleton(v463_7_head);
        const Space v464_3 = intersect(constant_2,v464_2);
        const Space v464_4 = (has_head(v464_3) ? constant_3 : Space{});
        const Space v464_5 = subtract(constant_1,v464_4);
        Space v464_8;
        if (!v464_5.empty()) {
          const Path v465_6 = concat_path(v463_6,v463_7_head);
          const Space v465_7 = routine_56(c, v465_6, p1, v463_7_tail);
          v464_8 = compose(v464_5,v465_7);
        }
        const Space v464_9 = intersect(constant_2,v464_2);
        const Space v464_10 = (has_head(v464_9) ? constant_3 : Space{});
        Space v464_12;
        if (!v464_10.empty()) {
          const Path v466_6 = concat_path(v463_6,v463_7_head);
          const Space v466_11 = routine_57(c, v466_6, p1, v463_7_tail);
          v464_12 = compose(v464_10,v466_11);
        }
        const Space v464_13 = unite(v464_8,v464_12);
        v463_7_result = unite(v463_7_result,v464_13);
      }
      const Space v463_7 = std::move(v463_7_result);
      v462_8 = compose(v462_5,v463_7);
    }
    const Space v462_9 = intersect(constant_2,v462_2);
    const Space v462_10 = (has_head(v462_9) ? constant_3 : Space{});
    Space v462_12;
    if (!v462_10.empty()) {
      const Path v467_6 = concat_path(p0,v461_12_head);
      Space v467_11_result;
      for (int v467_11_label = 1; v467_11_label <= 2; ++v467_11_label) {
        const Space v467_11_tail = child(v461_12_tail,v467_11_label);
        if (v467_11_tail.empty()) continue;
        const Path v467_11_head{v467_11_label};
        const Space v468_2 = singleton(v467_11_head);
        const Space v468_3 = intersect(constant_2,v468_2);
        const Space v468_4 = (has_head(v468_3) ? constant_3 : Space{});
        const Space v468_5 = subtract(constant_1,v468_4);
        Space v468_8;
        if (!v468_5.empty()) {
          const Path v469_6 = concat_path(v467_6,v467_11_head);
          const Space v469_7 = routine_56(c, v469_6, p1, v467_11_tail);
          v468_8 = compose(v468_5,v469_7);
        }
        const Space v468_9 = intersect(constant_2,v468_2);
        const Space v468_10 = (has_head(v468_9) ? constant_3 : Space{});
        Space v468_12;
        if (!v468_10.empty()) {
          const Path v470_6 = concat_path(v467_6,v467_11_head);
          const Space v470_11 = routine_21(c, v470_6, p1, v467_11_tail);
          v468_12 = compose(v468_10,v470_11);
        }
        const Space v468_13 = unite(v468_8,v468_12);
        v467_11_result = unite(v467_11_result,v468_13);
      }
      const Space v467_11 = std::move(v467_11_result);
      v462_12 = compose(v462_10,v467_11);
    }
    const Space v462_13 = unite(v462_8,v462_12);
    v461_12_result = unite(v461_12_result,v462_13);
  }
  const Space v461_12 = std::move(v461_12_result);
  return v461_12;
}

static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v471_9_result;
  for (int v471_9_label = 1; v471_9_label <= 2; ++v471_9_label) {
    const Space v471_9_tail = child(s0,v471_9_label);
    if (v471_9_tail.empty()) continue;
    const Path v471_9_head{v471_9_label};
    const Space v472_2 = singleton(v471_9_head);
    const Space v472_3 = intersect(constant_2,v472_2);
    const Space v472_4 = (has_head(v472_3) ? constant_3 : Space{});
    const Space v472_5 = subtract(constant_1,v472_4);
    Space v472_8;
    if (!v472_5.empty()) {
      const Path v473_6 = concat_path(p0,v471_9_head);
      Space v473_7_result;
      for (int v473_7_label = 1; v473_7_label <= 2; ++v473_7_label) {
        const Space v473_7_tail = child(v471_9_tail,v473_7_label);
        if (v473_7_tail.empty()) continue;
        const Path v473_7_head{v473_7_label};
        const Space v474_2 = singleton(v473_7_head);
        const Space v474_3 = intersect(constant_2,v474_2);
        const Space v474_4 = (has_head(v474_3) ? constant_3 : Space{});
        const Space v474_5 = subtract(constant_1,v474_4);
        Space v474_8;
        if (!v474_5.empty()) {
          const Path v475_6 = concat_path(v473_6,v473_7_head);
          const Space v475_7 = routine_56(c, v475_6, p1, v473_7_tail);
          v474_8 = compose(v474_5,v475_7);
        }
        const Space v474_9 = intersect(constant_2,v474_2);
        const Space v474_10 = (has_head(v474_9) ? constant_3 : Space{});
        Space v474_12;
        if (!v474_10.empty()) {
          const Path v476_6 = concat_path(v473_6,v473_7_head);
          const Space v476_11 = routine_57(c, v476_6, p1, v473_7_tail);
          v474_12 = compose(v474_10,v476_11);
        }
        const Space v474_13 = unite(v474_8,v474_12);
        v473_7_result = unite(v473_7_result,v474_13);
      }
      const Space v473_7 = std::move(v473_7_result);
      v472_8 = compose(v472_5,v473_7);
    }
    const Space v472_9 = intersect(constant_2,v472_2);
    const Space v472_10 = (has_head(v472_9) ? constant_3 : Space{});
    const Space v472_11 = compose(v472_10,v471_9_tail);
    const Path v477_6 = concat_path(p0,v471_9_head);
    const Space v472_12 = wrap(v472_11,v477_6);
    const Space v472_13 = wrap(v472_12,p1);
    const Space v472_14 = unite(v472_8,v472_13);
    v471_9_result = unite(v471_9_result,v472_14);
  }
  const Space v471_9 = std::move(v471_9_result);
  return v471_9;
}

static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v478_7_result;
  for (int v478_7_label = 1; v478_7_label <= 2; ++v478_7_label) {
    const Space v478_7_tail = child(s0,v478_7_label);
    if (v478_7_tail.empty()) continue;
    const Path v478_7_head{v478_7_label};
    const Space v479_2 = singleton(v478_7_head);
    const Space v479_3 = intersect(constant_2,v479_2);
    const Space v479_4 = (has_head(v479_3) ? constant_3 : Space{});
    const Space v479_5 = subtract(constant_1,v479_4);
    Space v479_6_result;
    for (int v479_6_label = 1; v479_6_label <= 2; ++v479_6_label) {
      const Space v479_6_tail = child(v478_7_tail,v479_6_label);
      if (v479_6_tail.empty()) continue;
      const Path v479_6_head{v479_6_label};
      const Space v480_2 = Space{};
      v479_6_result = unite(v479_6_result,v480_2);
    }
    const Space v479_6 = std::move(v479_6_result);
    const Space v479_7 = compose(v479_5,v479_6);
    const Space v479_8 = intersect(constant_2,v479_2);
    const Space v479_9 = (has_head(v479_8) ? constant_3 : Space{});
    Space v479_12;
    if (!v479_9.empty()) {
      const Path v481_10 = concat_path(p0,v478_7_head);
      Space v481_11_result;
      for (int v481_11_label = 1; v481_11_label <= 2; ++v481_11_label) {
        const Space v481_11_tail = child(v478_7_tail,v481_11_label);
        if (v481_11_tail.empty()) continue;
        const Path v481_11_head{v481_11_label};
        const Space v482_2 = singleton(v481_11_head);
        const Space v482_3 = intersect(constant_2,v482_2);
        const Space v482_4 = (has_head(v482_3) ? constant_3 : Space{});
        Space v482_7;
        if (!v482_4.empty()) {
          const Path v483_5 = concat_path(v481_10,v481_11_head);
          const Space v483_6 = routine_21(c, v483_5, p1, v481_11_tail);
          v482_7 = compose(v482_4,v483_6);
        }
        v481_11_result = unite(v481_11_result,v482_7);
      }
      const Space v481_11 = std::move(v481_11_result);
      v479_12 = compose(v479_9,v481_11);
    }
    const Space v479_13 = unite(v479_7,v479_12);
    v478_7_result = unite(v478_7_result,v479_13);
  }
  const Space v478_7 = std::move(v478_7_result);
  return v478_7;
}

static Space routine_55(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v484_6_result;
  for (int v484_6_label = 1; v484_6_label <= 2; ++v484_6_label) {
    const Space v484_6_tail = child(s0,v484_6_label);
    if (v484_6_tail.empty()) continue;
    const Path v484_6_head{v484_6_label};
    const Space v485_2 = singleton(v484_6_head);
    const Space v485_3 = intersect(constant_2,v485_2);
    const Space v485_4 = (has_head(v485_3) ? constant_3 : Space{});
    const Space v485_5 = subtract(constant_1,v485_4);
    Space v485_6_result;
    for (int v485_6_label = 1; v485_6_label <= 2; ++v485_6_label) {
      const Space v485_6_tail = child(v484_6_tail,v485_6_label);
      if (v485_6_tail.empty()) continue;
      const Path v485_6_head{v485_6_label};
      const Space v486_2 = Space{};
      v485_6_result = unite(v485_6_result,v486_2);
    }
    const Space v485_6 = std::move(v485_6_result);
    const Space v485_7 = compose(v485_5,v485_6);
    const Space v485_8 = intersect(constant_2,v485_2);
    const Space v485_9 = (has_head(v485_8) ? constant_3 : Space{});
    const Space v485_10 = compose(v485_9,v484_6_tail);
    const Path v485_11 = concat_path(p0,v484_6_head);
    const Space v485_12 = wrap(v485_10,v485_11);
    const Space v485_13 = wrap(v485_12,p1);
    const Space v485_14 = unite(v485_7,v485_13);
    v484_6_result = unite(v484_6_result,v485_14);
  }
  const Space v484_6 = std::move(v484_6_result);
  return v484_6;
}

static Space routine_56(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v487_3_result;
  for (int v487_3_label = 1; v487_3_label <= 2; ++v487_3_label) {
    const Space v487_3_tail = child(s0,v487_3_label);
    if (v487_3_tail.empty()) continue;
    const Path v487_3_head{v487_3_label};
    const Space v488_2 = Space{};
    v487_3_result = unite(v487_3_result,v488_2);
  }
  const Space v487_3 = std::move(v487_3_result);
  return v487_3;
}

static Space routine_57(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v489_4_result;
  for (int v489_4_label = 1; v489_4_label <= 2; ++v489_4_label) {
    const Space v489_4_tail = child(s0,v489_4_label);
    if (v489_4_tail.empty()) continue;
    const Path v489_4_head{v489_4_label};
    const Space v490_2 = singleton(v489_4_head);
    const Space v490_3 = intersect(constant_2,v490_2);
    const Space v490_4 = (has_head(v490_3) ? constant_3 : Space{});
    const Space v490_5 = compose(v490_4,v489_4_tail);
    const Path v490_6 = concat_path(p0,v489_4_head);
    const Space v490_7 = wrap(v490_5,v490_6);
    v489_4_result = unite(v489_4_result,v490_7);
  }
  const Space v489_4 = std::move(v489_4_result);
  const Space v489_5 = wrap(v489_4,p1);
  return v489_5;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
