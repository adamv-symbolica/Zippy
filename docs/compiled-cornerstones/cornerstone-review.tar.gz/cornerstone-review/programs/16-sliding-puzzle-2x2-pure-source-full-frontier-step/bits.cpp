#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Path constant_1 = Path{1,1};
static const Space constant_2 = literal_text("3 14 1 2 2 1 1 2 2 2 1 2 2 1 2 2 14 1 2 2 1 2 2 1 1 2 2 2 1 2 2 14 1 2 2 2 1 2 2 1 2 2 1 1 2 2");
static const Path constant_3 = Path{2,1};
static const Space constant_4 = literal_text("3 14 1 2 2 1 1 2 2 1 2 2 2 1 2 2 14 1 2 2 1 2 2 2 1 2 2 1 1 2 2 14 1 2 2 2 1 2 2 1 1 2 2 1 2 2");
static const Path constant_5 = Path{1,2};
static const Path constant_6 = Path{2,2};
static const Space constant_7 = literal_text("3 11 1 1 2 2 2 1 2 2 1 2 2 11 1 2 2 1 1 2 2 2 1 2 2 11 2 1 2 2 1 2 2 1 1 2 2");
static const Space constant_8 = literal_text("1 1 2");
static const Space constant_9 = singleton(Path{});
static const Space constant_10 = literal_text("1 5 1 1 1 2 2");
static const Space constant_11 = literal_text("1 5 1 2 1 2 2");
static const Space constant_12 = literal_text("1 5 2 1 1 2 2");
static const Space constant_13 = literal_text("1 2 2 2");
static const Path constant_14 = Path{1};
static const Space constant_15 = literal_text("8 20 1 1 2 2 1 1 2 1 2 2 1 1 1 2 2 1 2 1 2 2 20 1 1 2 2 1 1 2 1 2 2 1 2 1 2 2 1 1 1 2 2 17 1 1 2 2 1 2 1 1 2 2 1 1 1 2 2 2 2 17 1 1 2 2 1 2 1 1 2 2 2 2 1 1 1 2 2 20 2 1 2 2 1 1 1 1 2 2 1 1 1 2 2 1 2 1 2 2 20 2 1 2 2 1 1 1 1 2 2 1 2 1 2 2 1 1 1 2 2 20 2 1 2 2 1 2 1 1 2 2 1 2 1 2 2 2 1 1 2 2 20 2 1 2 2 1 2 1 1 2 2 2 1 1 2 2 1 2 1 2 2");
static const Path constant_16 = Path{2};
static const Space constant_17 = literal_text("8 17 1 1 2 2 1 1 1 1 2 2 2 1 1 2 2 2 2 17 1 1 2 2 1 1 1 1 2 2 2 2 2 1 1 2 2 20 1 1 2 2 2 1 1 1 2 2 1 2 1 2 2 2 1 1 2 2 20 1 1 2 2 2 1 1 1 2 2 2 1 1 2 2 1 2 1 2 2 14 2 1 1 2 1 2 2 2 1 1 2 2 2 2 14 2 1 1 2 1 2 2 2 2 2 1 1 2 2 14 2 2 1 1 1 2 2 1 1 1 2 2 2 2 14 2 2 1 1 1 2 2 2 2 1 1 1 2 2");
static const Space constant_18 = literal_text("4 19 1 2 2 1 1 2 1 2 2 1 1 1 2 2 1 2 1 2 2 19 1 2 2 1 1 2 1 2 2 1 2 1 2 2 1 1 1 2 2 16 1 2 2 1 2 1 1 2 2 1 1 1 2 2 2 2 16 1 2 2 1 2 1 1 2 2 2 2 1 1 1 2 2");
static const Space constant_19 = literal_text("4 16 1 2 2 1 1 1 1 2 2 2 1 1 2 2 2 2 16 1 2 2 1 1 1 1 2 2 2 2 2 1 1 2 2 19 1 2 2 2 1 1 1 2 2 1 2 1 2 2 2 1 1 2 2 19 1 2 2 2 1 1 1 2 2 2 1 1 2 2 1 2 1 2 2");
static const Space constant_20 = literal_text("4 19 1 2 2 1 1 1 1 2 2 1 1 1 2 2 1 2 1 2 2 19 1 2 2 1 1 1 1 2 2 1 2 1 2 2 1 1 1 2 2 19 1 2 2 1 2 1 1 2 2 1 2 1 2 2 2 1 1 2 2 19 1 2 2 1 2 1 1 2 2 2 1 1 2 2 1 2 1 2 2");
static const Space constant_21 = literal_text("4 13 1 1 2 1 2 2 2 1 1 2 2 2 2 13 1 1 2 1 2 2 2 2 2 1 1 2 2 13 2 1 1 1 2 2 1 1 1 2 2 2 2 13 2 1 1 1 2 2 2 2 1 1 1 2 2");
static const Path constant_22 = Path{2,1,1,2,2};
static const Path constant_23 = Path{1,2,1,2,2};
static const Path constant_24 = Path{1,1,1,2,2};
static const Space constant_25 = literal_text("4 10 1 1 1 2 2 1 1 1 2 2 10 1 2 1 2 2 1 2 1 2 2 10 2 1 1 2 2 2 1 1 2 2 4 2 2 2 2");
static const Space constant_26 = literal_text("1 11 1 1 1 2 2 2 1 2 1 2 2");
static const Space constant_27 = literal_text("1 11 1 2 1 2 2 2 1 2 1 2 2");
static const Space constant_28 = literal_text("1 11 2 1 1 2 2 2 1 2 1 2 2");
static const Space constant_29 = literal_text("1 8 2 2 2 1 2 1 2 2");
static Space routine_0(Context& c);
static Space routine_44(Context& c, const Path& p0, const Space& s0);
static Space routine_257(Context& c, const Path& p0, const Space& s0);
static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_92(Context& c, const Path& p0, const Space& s0);
static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_265(Context& c, const Path& p0, const Space& s0);
static Space routine_182(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_98(Context& c, const Path& p0, const Space& s0);
static Space routine_100(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Space& s0);
static Space routine_46(Context& c, const Path& p0, const Space& s0);
static Space routine_201(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_112(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Space& s0);
static Space routine_54(Context& c, const Path& p0, const Space& s0);
static Space routine_217(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_56(Context& c, const Path& p0, const Space& s0);
static Space routine_209(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Space& s0);
static Space routine_193(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_45(Context& c, const Path& p0, const Space& s0);
static Space routine_258(Context& c, const Path& p0, const Space& s0);
static Space routine_175(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_93(Context& c, const Path& p0, const Space& s0);
static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_266(Context& c, const Path& p0, const Space& s0);
static Space routine_183(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_99(Context& c, const Path& p0, const Space& s0);
static Space routine_101(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_53(Context& c, const Path& p0, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Space& s0);
static Space routine_202(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_113(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_49(Context& c, const Path& p0, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Space& s0);
static Space routine_218(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_57(Context& c, const Path& p0, const Space& s0);
static Space routine_210(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Space& s0);
static Space routine_194(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_69(Context& c, const Path& p0, const Space& s0);
static Space routine_287(Context& c, const Path& p0, const Space& s0);
static Space routine_221(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_128(Context& c, const Path& p0, const Space& s0);
static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_58(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_160(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_292(Context& c, const Path& p0, const Space& s0);
static Space routine_228(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_136(Context& c, const Path& p0, const Space& s0);
static Space routine_139(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_81(Context& c, const Path& p0, const Space& s0);
static Space routine_72(Context& c, const Path& p0, const Space& s0);
static Space routine_240(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_75(Context& c, const Path& p0, const Space& s0);
static Space routine_84(Context& c, const Path& p0, const Space& s0);
static Space routine_250(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_78(Context& c, const Path& p0, const Space& s0);
static Space routine_87(Context& c, const Path& p0, const Space& s0);
static Space routine_245(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_66(Context& c, const Path& p0, const Space& s0);
static Space routine_235(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_70(Context& c, const Path& p0, const Space& s0);
static Space routine_288(Context& c, const Path& p0, const Space& s0);
static Space routine_222(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_129(Context& c, const Path& p0, const Space& s0);
static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_293(Context& c, const Path& p0, const Space& s0);
static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_229(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_137(Context& c, const Path& p0, const Space& s0);
static Space routine_140(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_82(Context& c, const Path& p0, const Space& s0);
static Space routine_73(Context& c, const Path& p0, const Space& s0);
static Space routine_241(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_76(Context& c, const Path& p0, const Space& s0);
static Space routine_85(Context& c, const Path& p0, const Space& s0);
static Space routine_251(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_168(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_88(Context& c, const Path& p0, const Space& s0);
static Space routine_79(Context& c, const Path& p0, const Space& s0);
static Space routine_246(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_67(Context& c, const Path& p0, const Space& s0);
static Space routine_236(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_104(Context& c, const Path& p0, const Space& s0);
static Space routine_305(Context& c, const Path& p0, const Space& s0);
static Space routine_255(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_172(Context& c, const Path& p0, const Space& s0);
static Space routine_176(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_309(Context& c, const Path& p0, const Space& s0);
static Space routine_207(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_263(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_180(Context& c, const Path& p0, const Space& s0);
static Space routine_184(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_116(Context& c, const Path& p0, const Space& s0);
static Space routine_108(Context& c, const Path& p0, const Space& s0);
static Space routine_275(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_199(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_110(Context& c, const Path& p0, const Space& s0);
static Space routine_120(Context& c, const Path& p0, const Space& s0);
static Space routine_283(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_215(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_122(Context& c, const Path& p0, const Space& s0);
static Space routine_279(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_102(Context& c, const Path& p0, const Space& s0);
static Space routine_114(Context& c, const Path& p0, const Space& s0);
static Space routine_271(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_191(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_115(Context& c, const Path& p0, const Space& s0);
static Space routine_105(Context& c, const Path& p0, const Space& s0);
static Space routine_306(Context& c, const Path& p0, const Space& s0);
static Space routine_256(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_173(Context& c, const Path& p0, const Space& s0);
static Space routine_177(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_310(Context& c, const Path& p0, const Space& s0);
static Space routine_208(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_264(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_181(Context& c, const Path& p0, const Space& s0);
static Space routine_185(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_117(Context& c, const Path& p0, const Space& s0);
static Space routine_109(Context& c, const Path& p0, const Space& s0);
static Space routine_276(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_200(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_111(Context& c, const Path& p0, const Space& s0);
static Space routine_121(Context& c, const Path& p0, const Space& s0);
static Space routine_284(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_216(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_123(Context& c, const Path& p0, const Space& s0);
static Space routine_280(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_103(Context& c, const Path& p0, const Space& s0);
static Space routine_272(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_192(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_144(Context& c, const Path& p0, const Space& s0);
static Space routine_156(Context& c, const Path& p0, const Space& s0);
static Space routine_319(Context& c, const Path& p0, const Space& s0);
static Space routine_285(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_219(Context& c, const Path& p0, const Space& s0);
static Space routine_224(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_321(Context& c, const Path& p0, const Space& s0);
static Space routine_243(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_290(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_226(Context& c, const Path& p0, const Space& s0);
static Space routine_231(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0);
static Space routine_158(Context& c, const Path& p0, const Space& s0);
static Space routine_149(Context& c, const Path& p0, const Space& s0);
static Space routine_297(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_238(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_151(Context& c, const Path& p0, const Space& s0);
static Space routine_163(Context& c, const Path& p0, const Space& s0);
static Space routine_301(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_248(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_165(Context& c, const Path& p0, const Space& s0);
static Space routine_142(Context& c, const Path& p0, const Space& s0);
static Space routine_299(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_295(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_233(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_145(Context& c, const Path& p0, const Space& s0);
static Space routine_320(Context& c, const Path& p0, const Space& s0);
static Space routine_157(Context& c, const Path& p0, const Space& s0);
static Space routine_286(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_220(Context& c, const Path& p0, const Space& s0);
static Space routine_225(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_322(Context& c, const Path& p0, const Space& s0);
static Space routine_244(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_291(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_227(Context& c, const Path& p0, const Space& s0);
static Space routine_232(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0);
static Space routine_159(Context& c, const Path& p0, const Space& s0);
static Space routine_150(Context& c, const Path& p0, const Space& s0);
static Space routine_298(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_239(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_152(Context& c, const Path& p0, const Space& s0);
static Space routine_164(Context& c, const Path& p0, const Space& s0);
static Space routine_302(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_249(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_166(Context& c, const Path& p0, const Space& s0);
static Space routine_143(Context& c, const Path& p0, const Space& s0);
static Space routine_300(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_296(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_234(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_189(Context& c, const Path& p0, const Space& s0);
static Space routine_323(Context& c, const Path& p0, const Space& s0);
static Space routine_303(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_253(Context& c, const Path& p0, const Space& s0);
static Space routine_203(Context& c, const Path& p0, const Space& s0);
static Space routine_259(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_325(Context& c, const Path& p0, const Space& s0);
static Space routine_277(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_307(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_261(Context& c, const Path& p0, const Space& s0);
static Space routine_267(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_178(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_64(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_205(Context& c, const Path& p0, const Space& s0);
static Space routine_195(Context& c, const Path& p0, const Space& s0);
static Space routine_313(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_273(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_197(Context& c, const Path& p0, const Space& s0);
static Space routine_211(Context& c, const Path& p0, const Space& s0);
static Space routine_317(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_281(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_213(Context& c, const Path& p0, const Space& s0);
static Space routine_187(Context& c, const Path& p0, const Space& s0);
static Space routine_315(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_311(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_269(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_190(Context& c, const Path& p0, const Space& s0);
static Space routine_324(Context& c, const Path& p0, const Space& s0);
static Space routine_304(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_254(Context& c, const Path& p0, const Space& s0);
static Space routine_260(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_204(Context& c, const Path& p0, const Space& s0);
static Space routine_171(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_326(Context& c, const Path& p0, const Space& s0);
static Space routine_278(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_308(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_262(Context& c, const Path& p0, const Space& s0);
static Space routine_268(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_179(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_65(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_206(Context& c, const Path& p0, const Space& s0);
static Space routine_196(Context& c, const Path& p0, const Space& s0);
static Space routine_314(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_274(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_198(Context& c, const Path& p0, const Space& s0);
static Space routine_212(Context& c, const Path& p0, const Space& s0);
static Space routine_318(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_282(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_214(Context& c, const Path& p0, const Space& s0);
static Space routine_188(Context& c, const Path& p0, const Space& s0);
static Space routine_316(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_312(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_270(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_71(Context& c, const Path& p0, const Space& s0);
static Space routine_289(Context& c, const Path& p0, const Space& s0);
static Space routine_223(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_130(Context& c, const Path& p0, const Space& s0);
static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_294(Context& c, const Path& p0, const Space& s0);
static Space routine_230(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_138(Context& c, const Path& p0, const Space& s0);
static Space routine_141(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_80(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_83(Context& c, const Path& p0, const Space& s0);
static Space routine_74(Context& c, const Path& p0, const Space& s0);
static Space routine_242(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_77(Context& c, const Path& p0, const Space& s0);
static Space routine_86(Context& c, const Path& p0, const Space& s0);
static Space routine_252(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_247(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_89(Context& c, const Path& p0, const Space& s0);
static Space routine_68(Context& c, const Path& p0, const Space& s0);
static Space routine_237(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_186(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c) {
  Space v0_18;
  if (!constant_0.empty()) {
    Space v1_17;
    if (!constant_0.empty()) {
      const Space v2_4 = routine_1(c, constant_1, constant_2);
      const Space v2_7 = routine_1(c, constant_3, constant_4);
      const Space v2_8 = unite(v2_4,v2_7);
      const Space v2_11 = routine_2(c, constant_5, constant_4);
      const Space v2_12 = unite(v2_8,v2_11);
      const Space v2_15 = routine_3(c, constant_6, constant_7);
      const Space v2_16 = unite(v2_12,v2_15);
      v1_17 = compose(constant_0,v2_16);
    }
    v0_18 = compose(constant_0,v1_17);
  }
  return v0_18;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v3_11_result;
  for (int v3_11_label = 1; v3_11_label <= 2; ++v3_11_label) {
    const Space v3_11_tail = child(s0,v3_11_label);
    if (v3_11_tail.empty()) continue;
    const Path v3_11_head{v3_11_label};
    const Space v4_2 = singleton(v3_11_head);
    const Space v4_3 = intersect(constant_8,v4_2);
    const Space v4_4 = (has_head(v4_3) ? constant_9 : Space{});
    const Space v4_5 = subtract(constant_0,v4_4);
    Space v4_8;
    if (!v4_5.empty()) {
      const Path v5_6 = concat_path(p0,v3_11_head);
      Space v5_7_result;
      for (int v5_7_label = 1; v5_7_label <= 2; ++v5_7_label) {
        const Space v5_7_tail = child(v3_11_tail,v5_7_label);
        if (v5_7_tail.empty()) continue;
        const Path v5_7_head{v5_7_label};
        const Space v6_2 = singleton(v5_7_head);
        const Space v6_3 = intersect(constant_8,v6_2);
        const Space v6_4 = (has_head(v6_3) ? constant_9 : Space{});
        const Space v6_5 = subtract(constant_0,v6_4);
        Space v6_8;
        if (!v6_5.empty()) {
          const Path v7_6 = concat_path(v5_6,v5_7_head);
          const Space v7_7 = routine_4(c, v7_6, v5_7_tail);
          v6_8 = compose(v6_5,v7_7);
        }
        const Space v6_9 = intersect(constant_8,v6_2);
        const Space v6_10 = (has_head(v6_9) ? constant_9 : Space{});
        Space v6_12;
        if (!v6_10.empty()) {
          const Path v8_6 = concat_path(v5_6,v5_7_head);
          const Space v8_11 = routine_5(c, v8_6, v5_7_tail);
          v6_12 = compose(v6_10,v8_11);
        }
        const Space v6_13 = unite(v6_8,v6_12);
        v5_7_result = unite(v5_7_result,v6_13);
      }
      const Space v5_7 = std::move(v5_7_result);
      v4_8 = compose(v4_5,v5_7);
    }
    const Space v4_9 = intersect(constant_8,v4_2);
    const Space v4_10 = (has_head(v4_9) ? constant_9 : Space{});
    Space v4_12;
    if (!v4_10.empty()) {
      const Path v9_6 = concat_path(p0,v3_11_head);
      Space v9_11_result;
      for (int v9_11_label = 1; v9_11_label <= 2; ++v9_11_label) {
        const Space v9_11_tail = child(v3_11_tail,v9_11_label);
        if (v9_11_tail.empty()) continue;
        const Path v9_11_head{v9_11_label};
        const Space v10_2 = singleton(v9_11_head);
        const Space v10_3 = intersect(constant_8,v10_2);
        const Space v10_4 = (has_head(v10_3) ? constant_9 : Space{});
        const Space v10_5 = subtract(constant_0,v10_4);
        Space v10_8;
        if (!v10_5.empty()) {
          const Path v11_6 = concat_path(v9_6,v9_11_head);
          const Space v11_7 = routine_4(c, v11_6, v9_11_tail);
          v10_8 = compose(v10_5,v11_7);
        }
        const Space v10_9 = intersect(constant_8,v10_2);
        const Space v10_10 = (has_head(v10_9) ? constant_9 : Space{});
        Space v10_12;
        if (!v10_10.empty()) {
          const Path v12_6 = concat_path(v9_6,v9_11_head);
          const Space v12_11 = routine_3(c, v12_6, v9_11_tail);
          v10_12 = compose(v10_10,v12_11);
        }
        const Space v10_13 = unite(v10_8,v10_12);
        v9_11_result = unite(v9_11_result,v10_13);
      }
      const Space v9_11 = std::move(v9_11_result);
      v4_12 = compose(v4_10,v9_11);
    }
    const Space v4_13 = unite(v4_8,v4_12);
    v3_11_result = unite(v3_11_result,v4_13);
  }
  const Space v3_11 = std::move(v3_11_result);
  return v3_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  Space v13_11_result;
  for (int v13_11_label = 1; v13_11_label <= 2; ++v13_11_label) {
    const Space v13_11_tail = child(s0,v13_11_label);
    if (v13_11_tail.empty()) continue;
    const Path v13_11_head{v13_11_label};
    const Space v14_2 = singleton(v13_11_head);
    const Space v14_3 = intersect(constant_8,v14_2);
    const Space v14_4 = (has_head(v14_3) ? constant_9 : Space{});
    const Space v14_5 = subtract(constant_0,v14_4);
    Space v14_8;
    if (!v14_5.empty()) {
      const Path v15_6 = concat_path(p0,v13_11_head);
      Space v15_7_result;
      for (int v15_7_label = 1; v15_7_label <= 2; ++v15_7_label) {
        const Space v15_7_tail = child(v13_11_tail,v15_7_label);
        if (v15_7_tail.empty()) continue;
        const Path v15_7_head{v15_7_label};
        const Space v16_2 = singleton(v15_7_head);
        const Space v16_3 = intersect(constant_8,v16_2);
        const Space v16_4 = (has_head(v16_3) ? constant_9 : Space{});
        const Space v16_5 = subtract(constant_0,v16_4);
        Space v16_8;
        if (!v16_5.empty()) {
          const Path v17_6 = concat_path(v15_6,v15_7_head);
          const Space v17_7 = routine_4(c, v17_6, v15_7_tail);
          v16_8 = compose(v16_5,v17_7);
        }
        const Space v16_9 = intersect(constant_8,v16_2);
        const Space v16_10 = (has_head(v16_9) ? constant_9 : Space{});
        Space v16_12;
        if (!v16_10.empty()) {
          const Path v18_6 = concat_path(v15_6,v15_7_head);
          const Space v18_11 = routine_5(c, v18_6, v15_7_tail);
          v16_12 = compose(v16_10,v18_11);
        }
        const Space v16_13 = unite(v16_8,v16_12);
        v15_7_result = unite(v15_7_result,v16_13);
      }
      const Space v15_7 = std::move(v15_7_result);
      v14_8 = compose(v14_5,v15_7);
    }
    const Space v14_9 = intersect(constant_8,v14_2);
    const Space v14_10 = (has_head(v14_9) ? constant_9 : Space{});
    Space v14_12;
    if (!v14_10.empty()) {
      const Path v19_6 = concat_path(p0,v13_11_head);
      Space v19_11_result;
      for (int v19_11_label = 1; v19_11_label <= 2; ++v19_11_label) {
        const Space v19_11_tail = child(v13_11_tail,v19_11_label);
        if (v19_11_tail.empty()) continue;
        const Path v19_11_head{v19_11_label};
        const Space v20_2 = singleton(v19_11_head);
        const Space v20_3 = intersect(constant_8,v20_2);
        const Space v20_4 = (has_head(v20_3) ? constant_9 : Space{});
        const Space v20_5 = subtract(constant_0,v20_4);
        Space v20_7;
        if (!v20_5.empty()) {
          const Space v21_6 = routine_6(c, v19_11_head, v19_6, v19_11_tail);
          v20_7 = compose(v20_5,v21_6);
        }
        const Space v20_8 = intersect(constant_8,v20_2);
        const Space v20_9 = (has_head(v20_8) ? constant_9 : Space{});
        Space v20_11;
        if (!v20_9.empty()) {
          const Space v22_10 = routine_7(c, v19_11_head, v19_6, v19_11_tail);
          v20_11 = compose(v20_9,v22_10);
        }
        const Space v20_12 = unite(v20_7,v20_11);
        v19_11_result = unite(v19_11_result,v20_12);
      }
      const Space v19_11 = std::move(v19_11_result);
      v14_12 = compose(v14_10,v19_11);
    }
    const Space v14_13 = unite(v14_8,v14_12);
    v13_11_result = unite(v13_11_result,v14_13);
  }
  const Space v13_11 = std::move(v13_11_result);
  return v13_11;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  Space v23_11_result;
  for (int v23_11_label = 1; v23_11_label <= 2; ++v23_11_label) {
    const Space v23_11_tail = child(s0,v23_11_label);
    if (v23_11_tail.empty()) continue;
    const Path v23_11_head{v23_11_label};
    const Space v24_2 = singleton(v23_11_head);
    const Space v24_3 = intersect(constant_8,v24_2);
    const Space v24_4 = (has_head(v24_3) ? constant_9 : Space{});
    const Space v24_5 = subtract(constant_0,v24_4);
    Space v24_7;
    if (!v24_5.empty()) {
      Space v25_6_result;
      for (int v25_6_label = 1; v25_6_label <= 2; ++v25_6_label) {
        const Space v25_6_tail = child(v23_11_tail,v25_6_label);
        if (v25_6_tail.empty()) continue;
        const Path v25_6_head{v25_6_label};
        const Space v26_2 = singleton(v25_6_head);
        const Space v26_3 = intersect(constant_8,v26_2);
        const Space v26_4 = (has_head(v26_3) ? constant_9 : Space{});
        const Space v26_5 = subtract(constant_0,v26_4);
        Space v26_8;
        if (!v26_5.empty()) {
          const Path v27_6 = concat_path(v23_11_head,v25_6_head);
          const Space v27_7 = routine_8(c, v27_6, p0, v25_6_tail);
          v26_8 = compose(v26_5,v27_7);
        }
        const Space v26_9 = intersect(constant_8,v26_2);
        const Space v26_10 = (has_head(v26_9) ? constant_9 : Space{});
        Space v26_12;
        if (!v26_10.empty()) {
          const Path v28_6 = concat_path(v23_11_head,v25_6_head);
          const Space v28_11 = routine_9(c, v28_6, p0, v25_6_tail);
          v26_12 = compose(v26_10,v28_11);
        }
        const Space v26_13 = unite(v26_8,v26_12);
        v25_6_result = unite(v25_6_result,v26_13);
      }
      const Space v25_6 = std::move(v25_6_result);
      v24_7 = compose(v24_5,v25_6);
    }
    const Space v24_8 = intersect(constant_8,v24_2);
    const Space v24_9 = (has_head(v24_8) ? constant_9 : Space{});
    Space v24_11;
    if (!v24_9.empty()) {
      Space v29_10_result;
      for (int v29_10_label = 1; v29_10_label <= 2; ++v29_10_label) {
        const Space v29_10_tail = child(v23_11_tail,v29_10_label);
        if (v29_10_tail.empty()) continue;
        const Path v29_10_head{v29_10_label};
        const Space v30_2 = singleton(v29_10_head);
        const Space v30_3 = intersect(constant_8,v30_2);
        const Space v30_4 = (has_head(v30_3) ? constant_9 : Space{});
        const Space v30_5 = subtract(constant_0,v30_4);
        Space v30_8;
        if (!v30_5.empty()) {
          const Path v31_6 = concat_path(v23_11_head,v29_10_head);
          const Space v31_7 = routine_8(c, v31_6, p0, v29_10_tail);
          v30_8 = compose(v30_5,v31_7);
        }
        const Space v30_9 = intersect(constant_8,v30_2);
        const Space v30_10 = (has_head(v30_9) ? constant_9 : Space{});
        Space v30_12;
        if (!v30_10.empty()) {
          const Path v32_6 = concat_path(v23_11_head,v29_10_head);
          const Space v32_11 = routine_10(c, v32_6, p0, v29_10_tail);
          v30_12 = compose(v30_10,v32_11);
        }
        const Space v30_13 = unite(v30_8,v30_12);
        v29_10_result = unite(v29_10_result,v30_13);
      }
      const Space v29_10 = std::move(v29_10_result);
      v24_11 = compose(v24_9,v29_10);
    }
    const Space v24_12 = unite(v24_7,v24_11);
    v23_11_result = unite(v23_11_result,v24_12);
  }
  const Space v23_11 = std::move(v23_11_result);
  return v23_11;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0) {
  Space v33_6_result;
  for (int v33_6_label = 1; v33_6_label <= 2; ++v33_6_label) {
    const Space v33_6_tail = child(s0,v33_6_label);
    if (v33_6_tail.empty()) continue;
    const Path v33_6_head{v33_6_label};
    const Space v34_2 = singleton(v33_6_head);
    const Space v34_3 = intersect(constant_8,v34_2);
    const Space v34_4 = (has_head(v34_3) ? constant_9 : Space{});
    const Space v34_5 = subtract(constant_0,v34_4);
    Space v34_6_result;
    for (int v34_6_label = 1; v34_6_label <= 2; ++v34_6_label) {
      const Space v34_6_tail = child(v33_6_tail,v34_6_label);
      if (v34_6_tail.empty()) continue;
      const Path v34_6_head{v34_6_label};
      const Space v35_2 = Space{};
      v34_6_result = unite(v34_6_result,v35_2);
    }
    const Space v34_6 = std::move(v34_6_result);
    const Space v34_7 = compose(v34_5,v34_6);
    const Space v34_8 = intersect(constant_8,v34_2);
    const Space v34_9 = (has_head(v34_8) ? constant_9 : Space{});
    Space v34_12;
    if (!v34_9.empty()) {
      const Path v36_10 = concat_path(p0,v33_6_head);
      Space v36_11_result;
      for (int v36_11_label = 1; v36_11_label <= 2; ++v36_11_label) {
        const Space v36_11_tail = child(v33_6_tail,v36_11_label);
        if (v36_11_tail.empty()) continue;
        const Path v36_11_head{v36_11_label};
        const Space v37_2 = singleton(v36_11_head);
        const Space v37_3 = intersect(constant_8,v37_2);
        const Space v37_4 = (has_head(v37_3) ? constant_9 : Space{});
        Space v37_7;
        if (!v37_4.empty()) {
          const Path v38_5 = concat_path(v36_10,v36_11_head);
          const Space v38_6 = routine_3(c, v38_5, v36_11_tail);
          v37_7 = compose(v37_4,v38_6);
        }
        v36_11_result = unite(v36_11_result,v37_7);
      }
      const Space v36_11 = std::move(v36_11_result);
      v34_12 = compose(v34_9,v36_11);
    }
    const Space v34_13 = unite(v34_7,v34_12);
    v33_6_result = unite(v33_6_result,v34_13);
  }
  const Space v33_6 = std::move(v33_6_result);
  return v33_6;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0) {
  Space v39_8_result;
  for (int v39_8_label = 1; v39_8_label <= 2; ++v39_8_label) {
    const Space v39_8_tail = child(s0,v39_8_label);
    if (v39_8_tail.empty()) continue;
    const Path v39_8_head{v39_8_label};
    const Space v40_2 = singleton(v39_8_head);
    const Space v40_3 = intersect(constant_8,v40_2);
    const Space v40_4 = (has_head(v40_3) ? constant_9 : Space{});
    const Space v40_5 = subtract(constant_0,v40_4);
    Space v40_6_result;
    for (int v40_6_label = 1; v40_6_label <= 2; ++v40_6_label) {
      const Space v40_6_tail = child(v39_8_tail,v40_6_label);
      if (v40_6_tail.empty()) continue;
      const Path v40_6_head{v40_6_label};
      const Space v41_2 = Space{};
      v40_6_result = unite(v40_6_result,v41_2);
    }
    const Space v40_6 = std::move(v40_6_result);
    const Space v40_7 = compose(v40_5,v40_6);
    const Space v40_8 = intersect(constant_8,v40_2);
    const Space v40_9 = (has_head(v40_8) ? constant_9 : Space{});
    Space v40_12;
    if (!v40_9.empty()) {
      const Path v42_10 = concat_path(p0,v39_8_head);
      Space v42_11_result;
      for (int v42_11_label = 1; v42_11_label <= 2; ++v42_11_label) {
        const Space v42_11_tail = child(v39_8_tail,v42_11_label);
        if (v42_11_tail.empty()) continue;
        const Path v42_11_head{v42_11_label};
        const Space v43_2 = singleton(v42_11_head);
        const Space v43_3 = intersect(constant_8,v43_2);
        const Space v43_4 = (has_head(v43_3) ? constant_9 : Space{});
        const Space v43_5 = subtract(constant_0,v43_4);
        Space v43_7;
        if (!v43_5.empty()) {
          const Space v44_6 = routine_6(c, v42_11_head, v42_10, v42_11_tail);
          v43_7 = compose(v43_5,v44_6);
        }
        const Space v43_8 = intersect(constant_8,v43_2);
        const Space v43_9 = (has_head(v43_8) ? constant_9 : Space{});
        Space v43_11;
        if (!v43_9.empty()) {
          const Space v45_10 = routine_7(c, v42_11_head, v42_10, v42_11_tail);
          v43_11 = compose(v43_9,v45_10);
        }
        const Space v43_12 = unite(v43_7,v43_11);
        v42_11_result = unite(v42_11_result,v43_12);
      }
      const Space v42_11 = std::move(v42_11_result);
      v40_12 = compose(v40_9,v42_11);
    }
    const Space v40_13 = unite(v40_7,v40_12);
    v39_8_result = unite(v39_8_result,v40_13);
  }
  const Space v39_8 = std::move(v39_8_result);
  return v39_8;
}

static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v46_12_result;
  for (int v46_12_label = 1; v46_12_label <= 2; ++v46_12_label) {
    const Space v46_12_tail = child(s0,v46_12_label);
    if (v46_12_tail.empty()) continue;
    const Path v46_12_head{v46_12_label};
    const Space v47_2 = singleton(v46_12_head);
    const Space v47_3 = intersect(constant_8,v47_2);
    const Space v47_4 = (has_head(v47_3) ? constant_9 : Space{});
    const Space v47_5 = subtract(constant_0,v47_4);
    Space v47_8;
    if (!v47_5.empty()) {
      const Path v48_6 = concat_path(p0,v46_12_head);
      Space v48_7_result;
      for (int v48_7_label = 1; v48_7_label <= 2; ++v48_7_label) {
        const Space v48_7_tail = child(v46_12_tail,v48_7_label);
        if (v48_7_tail.empty()) continue;
        const Path v48_7_head{v48_7_label};
        const Space v49_2 = singleton(v48_7_head);
        const Space v49_3 = intersect(constant_8,v49_2);
        const Space v49_4 = (has_head(v49_3) ? constant_9 : Space{});
        const Space v49_5 = subtract(constant_0,v49_4);
        Space v49_8;
        if (!v49_5.empty()) {
          const Path v50_6 = concat_path(v48_6,v48_7_head);
          const Space v50_7 = routine_11(c, v50_6, p1, v48_7_tail);
          v49_8 = compose(v49_5,v50_7);
        }
        const Space v49_9 = intersect(constant_8,v49_2);
        const Space v49_10 = (has_head(v49_9) ? constant_9 : Space{});
        Space v49_12;
        if (!v49_10.empty()) {
          const Path v51_6 = concat_path(v48_6,v48_7_head);
          const Space v51_11 = routine_12(c, v51_6, p1, v48_7_tail);
          v49_12 = compose(v49_10,v51_11);
        }
        const Space v49_13 = unite(v49_8,v49_12);
        v48_7_result = unite(v48_7_result,v49_13);
      }
      const Space v48_7 = std::move(v48_7_result);
      v47_8 = compose(v47_5,v48_7);
    }
    const Space v47_9 = intersect(constant_8,v47_2);
    const Space v47_10 = (has_head(v47_9) ? constant_9 : Space{});
    Space v47_12;
    if (!v47_10.empty()) {
      const Path v52_6 = concat_path(p0,v46_12_head);
      Space v52_11_result;
      for (int v52_11_label = 1; v52_11_label <= 2; ++v52_11_label) {
        const Space v52_11_tail = child(v46_12_tail,v52_11_label);
        if (v52_11_tail.empty()) continue;
        const Path v52_11_head{v52_11_label};
        const Space v53_2 = singleton(v52_11_head);
        const Space v53_3 = intersect(constant_8,v53_2);
        const Space v53_4 = (has_head(v53_3) ? constant_9 : Space{});
        const Space v53_5 = subtract(constant_0,v53_4);
        Space v53_8;
        if (!v53_5.empty()) {
          const Path v54_6 = concat_path(v52_6,v52_11_head);
          const Space v54_7 = routine_11(c, v54_6, p1, v52_11_tail);
          v53_8 = compose(v53_5,v54_7);
        }
        const Space v53_9 = intersect(constant_8,v53_2);
        const Space v53_10 = (has_head(v53_9) ? constant_9 : Space{});
        Space v53_12;
        if (!v53_10.empty()) {
          const Path v55_6 = concat_path(v52_6,v52_11_head);
          const Space v55_11 = routine_10(c, v55_6, p1, v52_11_tail);
          v53_12 = compose(v53_10,v55_11);
        }
        const Space v53_13 = unite(v53_8,v53_12);
        v52_11_result = unite(v52_11_result,v53_13);
      }
      const Space v52_11 = std::move(v52_11_result);
      v47_12 = compose(v47_10,v52_11);
    }
    const Space v47_13 = unite(v47_8,v47_12);
    v46_12_result = unite(v46_12_result,v47_13);
  }
  const Space v46_12 = std::move(v46_12_result);
  return v46_12;
}

static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v56_12_result;
  for (int v56_12_label = 1; v56_12_label <= 2; ++v56_12_label) {
    const Space v56_12_tail = child(s0,v56_12_label);
    if (v56_12_tail.empty()) continue;
    const Path v56_12_head{v56_12_label};
    const Space v57_2 = singleton(v56_12_head);
    const Space v57_3 = intersect(constant_8,v57_2);
    const Space v57_4 = (has_head(v57_3) ? constant_9 : Space{});
    const Space v57_5 = subtract(constant_0,v57_4);
    Space v57_8;
    if (!v57_5.empty()) {
      const Path v58_6 = concat_path(p0,v56_12_head);
      Space v58_7_result;
      for (int v58_7_label = 1; v58_7_label <= 2; ++v58_7_label) {
        const Space v58_7_tail = child(v56_12_tail,v58_7_label);
        if (v58_7_tail.empty()) continue;
        const Path v58_7_head{v58_7_label};
        const Space v59_2 = singleton(v58_7_head);
        const Space v59_3 = intersect(constant_8,v59_2);
        const Space v59_4 = (has_head(v59_3) ? constant_9 : Space{});
        const Space v59_5 = subtract(constant_0,v59_4);
        Space v59_8;
        if (!v59_5.empty()) {
          const Path v60_6 = concat_path(v58_6,v58_7_head);
          const Space v60_7 = routine_11(c, v60_6, p1, v58_7_tail);
          v59_8 = compose(v59_5,v60_7);
        }
        const Space v59_9 = intersect(constant_8,v59_2);
        const Space v59_10 = (has_head(v59_9) ? constant_9 : Space{});
        Space v59_12;
        if (!v59_10.empty()) {
          const Path v61_6 = concat_path(v58_6,v58_7_head);
          const Space v61_11 = routine_12(c, v61_6, p1, v58_7_tail);
          v59_12 = compose(v59_10,v61_11);
        }
        const Space v59_13 = unite(v59_8,v59_12);
        v58_7_result = unite(v58_7_result,v59_13);
      }
      const Space v58_7 = std::move(v58_7_result);
      v57_8 = compose(v57_5,v58_7);
    }
    const Space v57_9 = intersect(constant_8,v57_2);
    const Space v57_10 = (has_head(v57_9) ? constant_9 : Space{});
    Space v57_12;
    if (!v57_10.empty()) {
      const Path v62_6 = concat_path(p0,v56_12_head);
      Space v62_11_result;
      for (int v62_11_label = 1; v62_11_label <= 2; ++v62_11_label) {
        const Space v62_11_tail = child(v56_12_tail,v62_11_label);
        if (v62_11_tail.empty()) continue;
        const Path v62_11_head{v62_11_label};
        const Space v63_2 = singleton(v62_11_head);
        const Space v63_3 = intersect(constant_8,v63_2);
        const Space v63_4 = (has_head(v63_3) ? constant_9 : Space{});
        const Space v63_5 = subtract(constant_0,v63_4);
        Space v63_7;
        if (!v63_5.empty()) {
          const Space v64_6 = routine_13(c, v62_11_head, p1, v62_6, v62_11_tail);
          v63_7 = compose(v63_5,v64_6);
        }
        const Space v63_8 = intersect(constant_8,v63_2);
        const Space v63_9 = (has_head(v63_8) ? constant_9 : Space{});
        Space v63_11;
        if (!v63_9.empty()) {
          const Space v65_10 = routine_14(c, v62_11_head, p1, v62_6, v62_11_tail);
          v63_11 = compose(v63_9,v65_10);
        }
        const Space v63_12 = unite(v63_7,v63_11);
        v62_11_result = unite(v62_11_result,v63_12);
      }
      const Space v62_11 = std::move(v62_11_result);
      v57_12 = compose(v57_10,v62_11);
    }
    const Space v57_13 = unite(v57_8,v57_12);
    v56_12_result = unite(v56_12_result,v57_13);
  }
  const Space v56_12 = std::move(v56_12_result);
  return v56_12;
}

static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v66_12_result;
  for (int v66_12_label = 1; v66_12_label <= 2; ++v66_12_label) {
    const Space v66_12_tail = child(s0,v66_12_label);
    if (v66_12_tail.empty()) continue;
    const Path v66_12_head{v66_12_label};
    const Space v67_2 = singleton(v66_12_head);
    const Space v67_3 = intersect(constant_8,v67_2);
    const Space v67_4 = (has_head(v67_3) ? constant_9 : Space{});
    const Space v67_5 = subtract(constant_0,v67_4);
    Space v67_8;
    if (!v67_5.empty()) {
      const Path v68_6 = concat_path(p0,v66_12_head);
      Space v68_7_result;
      for (int v68_7_label = 1; v68_7_label <= 2; ++v68_7_label) {
        const Space v68_7_tail = child(v66_12_tail,v68_7_label);
        if (v68_7_tail.empty()) continue;
        const Path v68_7_head{v68_7_label};
        const Space v69_2 = singleton(v68_7_head);
        const Space v69_3 = intersect(constant_8,v69_2);
        const Space v69_4 = (has_head(v69_3) ? constant_9 : Space{});
        const Space v69_5 = subtract(constant_0,v69_4);
        Space v69_8;
        if (!v69_5.empty()) {
          const Path v70_6 = concat_path(v68_6,v68_7_head);
          const Space v70_7 = routine_15(c, v70_6, p1, v68_7_tail);
          v69_8 = compose(v69_5,v70_7);
        }
        const Space v69_9 = intersect(constant_8,v69_2);
        const Space v69_10 = (has_head(v69_9) ? constant_9 : Space{});
        Space v69_12;
        if (!v69_10.empty()) {
          const Path v71_6 = concat_path(v68_6,v68_7_head);
          const Space v71_11 = routine_16(c, v71_6, p1, v68_7_tail);
          v69_12 = compose(v69_10,v71_11);
        }
        const Space v69_13 = unite(v69_8,v69_12);
        v68_7_result = unite(v68_7_result,v69_13);
      }
      const Space v68_7 = std::move(v68_7_result);
      v67_8 = compose(v67_5,v68_7);
    }
    const Space v67_9 = intersect(constant_8,v67_2);
    const Space v67_10 = (has_head(v67_9) ? constant_9 : Space{});
    Space v67_12;
    if (!v67_10.empty()) {
      const Path v72_6 = concat_path(p0,v66_12_head);
      Space v72_11_result;
      for (int v72_11_label = 1; v72_11_label <= 2; ++v72_11_label) {
        const Space v72_11_tail = child(v66_12_tail,v72_11_label);
        if (v72_11_tail.empty()) continue;
        const Path v72_11_head{v72_11_label};
        const Space v73_2 = singleton(v72_11_head);
        const Space v73_3 = intersect(constant_8,v73_2);
        const Space v73_4 = (has_head(v73_3) ? constant_9 : Space{});
        const Space v73_5 = subtract(constant_0,v73_4);
        Space v73_8;
        if (!v73_5.empty()) {
          const Path v74_6 = concat_path(v72_6,v72_11_head);
          const Space v74_7 = routine_15(c, v74_6, p1, v72_11_tail);
          v73_8 = compose(v73_5,v74_7);
        }
        const Space v73_9 = intersect(constant_8,v73_2);
        const Space v73_10 = (has_head(v73_9) ? constant_9 : Space{});
        Space v73_12;
        if (!v73_10.empty()) {
          const Path v75_6 = concat_path(v72_6,v72_11_head);
          const Space v75_11 = routine_10(c, v75_6, p1, v72_11_tail);
          v73_12 = compose(v73_10,v75_11);
        }
        const Space v73_13 = unite(v73_8,v73_12);
        v72_11_result = unite(v72_11_result,v73_13);
      }
      const Space v72_11 = std::move(v72_11_result);
      v67_12 = compose(v67_10,v72_11);
    }
    const Space v67_13 = unite(v67_8,v67_12);
    v66_12_result = unite(v66_12_result,v67_13);
  }
  const Space v66_12 = std::move(v66_12_result);
  return v66_12;
}

static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v76_12_result;
  for (int v76_12_label = 1; v76_12_label <= 2; ++v76_12_label) {
    const Space v76_12_tail = child(s0,v76_12_label);
    if (v76_12_tail.empty()) continue;
    const Path v76_12_head{v76_12_label};
    const Space v77_2 = singleton(v76_12_head);
    const Space v77_3 = intersect(constant_8,v77_2);
    const Space v77_4 = (has_head(v77_3) ? constant_9 : Space{});
    const Space v77_5 = subtract(constant_0,v77_4);
    Space v77_8;
    if (!v77_5.empty()) {
      const Path v78_6 = concat_path(p0,v76_12_head);
      Space v78_7_result;
      for (int v78_7_label = 1; v78_7_label <= 2; ++v78_7_label) {
        const Space v78_7_tail = child(v76_12_tail,v78_7_label);
        if (v78_7_tail.empty()) continue;
        const Path v78_7_head{v78_7_label};
        const Space v79_2 = singleton(v78_7_head);
        const Space v79_3 = intersect(constant_8,v79_2);
        const Space v79_4 = (has_head(v79_3) ? constant_9 : Space{});
        const Space v79_5 = subtract(constant_0,v79_4);
        Space v79_8;
        if (!v79_5.empty()) {
          const Path v80_6 = concat_path(v78_6,v78_7_head);
          const Space v80_7 = routine_15(c, v80_6, p1, v78_7_tail);
          v79_8 = compose(v79_5,v80_7);
        }
        const Space v79_9 = intersect(constant_8,v79_2);
        const Space v79_10 = (has_head(v79_9) ? constant_9 : Space{});
        Space v79_12;
        if (!v79_10.empty()) {
          const Path v81_6 = concat_path(v78_6,v78_7_head);
          const Space v81_11 = routine_16(c, v81_6, p1, v78_7_tail);
          v79_12 = compose(v79_10,v81_11);
        }
        const Space v79_13 = unite(v79_8,v79_12);
        v78_7_result = unite(v78_7_result,v79_13);
      }
      const Space v78_7 = std::move(v78_7_result);
      v77_8 = compose(v77_5,v78_7);
    }
    const Space v77_9 = intersect(constant_8,v77_2);
    const Space v77_10 = (has_head(v77_9) ? constant_9 : Space{});
    Space v77_12;
    if (!v77_10.empty()) {
      const Path v82_6 = concat_path(p0,v76_12_head);
      Space v82_11_result;
      for (int v82_11_label = 1; v82_11_label <= 2; ++v82_11_label) {
        const Space v82_11_tail = child(v76_12_tail,v82_11_label);
        if (v82_11_tail.empty()) continue;
        const Path v82_11_head{v82_11_label};
        const Space v83_2 = singleton(v82_11_head);
        const Space v83_3 = intersect(constant_8,v83_2);
        const Space v83_4 = (has_head(v83_3) ? constant_9 : Space{});
        const Space v83_5 = subtract(constant_0,v83_4);
        Space v83_7;
        if (!v83_5.empty()) {
          const Space v84_6 = routine_13(c, v82_11_head, p1, v82_6, v82_11_tail);
          v83_7 = compose(v83_5,v84_6);
        }
        const Space v83_8 = intersect(constant_8,v83_2);
        const Space v83_9 = (has_head(v83_8) ? constant_9 : Space{});
        Space v83_11;
        if (!v83_9.empty()) {
          const Space v85_10 = routine_14(c, v82_11_head, p1, v82_6, v82_11_tail);
          v83_11 = compose(v83_9,v85_10);
        }
        const Space v83_12 = unite(v83_7,v83_11);
        v82_11_result = unite(v82_11_result,v83_12);
      }
      const Space v82_11 = std::move(v82_11_result);
      v77_12 = compose(v77_10,v82_11);
    }
    const Space v77_13 = unite(v77_8,v77_12);
    v76_12_result = unite(v76_12_result,v77_13);
  }
  const Space v76_12 = std::move(v76_12_result);
  return v76_12;
}

static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v86_12_result;
  for (int v86_12_label = 1; v86_12_label <= 2; ++v86_12_label) {
    const Space v86_12_tail = child(s0,v86_12_label);
    if (v86_12_tail.empty()) continue;
    const Path v86_12_head{v86_12_label};
    const Space v87_2 = singleton(v86_12_head);
    const Space v87_3 = intersect(constant_8,v87_2);
    const Space v87_4 = (has_head(v87_3) ? constant_9 : Space{});
    const Space v87_5 = subtract(constant_0,v87_4);
    Space v87_7;
    if (!v87_5.empty()) {
      Space v88_6_result;
      for (int v88_6_label = 1; v88_6_label <= 2; ++v88_6_label) {
        const Space v88_6_tail = child(v86_12_tail,v88_6_label);
        if (v88_6_tail.empty()) continue;
        const Path v88_6_head{v88_6_label};
        const Space v89_2 = singleton(v88_6_head);
        const Space v89_3 = intersect(constant_8,v89_2);
        const Space v89_4 = (has_head(v89_3) ? constant_9 : Space{});
        const Space v89_5 = subtract(constant_0,v89_4);
        Space v89_8;
        if (!v89_5.empty()) {
          const Path v90_6 = concat_path(v86_12_head,v88_6_head);
          const Space v90_7 = routine_17(c, v90_6, p1, p0, v88_6_tail);
          v89_8 = compose(v89_5,v90_7);
        }
        const Space v89_9 = intersect(constant_8,v89_2);
        const Space v89_10 = (has_head(v89_9) ? constant_9 : Space{});
        Space v89_12;
        if (!v89_10.empty()) {
          const Path v91_6 = concat_path(v86_12_head,v88_6_head);
          const Space v91_11 = routine_18(c, v91_6, p1, p0, v88_6_tail);
          v89_12 = compose(v89_10,v91_11);
        }
        const Space v89_13 = unite(v89_8,v89_12);
        v88_6_result = unite(v88_6_result,v89_13);
      }
      const Space v88_6 = std::move(v88_6_result);
      v87_7 = compose(v87_5,v88_6);
    }
    const Space v87_8 = intersect(constant_8,v87_2);
    const Space v87_9 = (has_head(v87_8) ? constant_9 : Space{});
    Space v87_11;
    if (!v87_9.empty()) {
      Space v92_10_result;
      for (int v92_10_label = 1; v92_10_label <= 2; ++v92_10_label) {
        const Space v92_10_tail = child(v86_12_tail,v92_10_label);
        if (v92_10_tail.empty()) continue;
        const Path v92_10_head{v92_10_label};
        const Space v93_2 = singleton(v92_10_head);
        const Space v93_3 = intersect(constant_8,v93_2);
        const Space v93_4 = (has_head(v93_3) ? constant_9 : Space{});
        const Space v93_5 = subtract(constant_0,v93_4);
        Space v93_8;
        if (!v93_5.empty()) {
          const Path v94_6 = concat_path(v86_12_head,v92_10_head);
          const Space v94_7 = routine_17(c, v94_6, p1, p0, v92_10_tail);
          v93_8 = compose(v93_5,v94_7);
        }
        const Space v93_9 = intersect(constant_8,v93_2);
        const Space v93_10 = (has_head(v93_9) ? constant_9 : Space{});
        Space v93_12;
        if (!v93_10.empty()) {
          const Path v95_6 = concat_path(v86_12_head,v92_10_head);
          const Space v95_11 = routine_19(c, v95_6, p1, p0, v92_10_tail);
          v93_12 = compose(v93_10,v95_11);
        }
        const Space v93_13 = unite(v93_8,v93_12);
        v92_10_result = unite(v92_10_result,v93_13);
      }
      const Space v92_10 = std::move(v92_10_result);
      v87_11 = compose(v87_9,v92_10);
    }
    const Space v87_12 = unite(v87_7,v87_11);
    v86_12_result = unite(v86_12_result,v87_12);
  }
  const Space v86_12 = std::move(v86_12_result);
  return v86_12;
}

static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v96_12_result;
  for (int v96_12_label = 1; v96_12_label <= 2; ++v96_12_label) {
    const Space v96_12_tail = child(s0,v96_12_label);
    if (v96_12_tail.empty()) continue;
    const Path v96_12_head{v96_12_label};
    const Space v97_2 = singleton(v96_12_head);
    const Space v97_3 = intersect(constant_8,v97_2);
    const Space v97_4 = (has_head(v97_3) ? constant_9 : Space{});
    const Space v97_5 = subtract(constant_0,v97_4);
    Space v97_8;
    if (!v97_5.empty()) {
      const Path v98_6 = concat_path(p0,v96_12_head);
      Space v98_7_result;
      for (int v98_7_label = 1; v98_7_label <= 2; ++v98_7_label) {
        const Space v98_7_tail = child(v96_12_tail,v98_7_label);
        if (v98_7_tail.empty()) continue;
        const Path v98_7_head{v98_7_label};
        const Space v99_2 = singleton(v98_7_head);
        const Space v99_3 = intersect(constant_8,v99_2);
        const Space v99_4 = (has_head(v99_3) ? constant_9 : Space{});
        const Space v99_5 = subtract(constant_0,v99_4);
        Space v99_8;
        if (!v99_5.empty()) {
          const Path v100_6 = concat_path(v98_6,v98_7_head);
          const Space v100_7 = routine_20(c, v100_6, p1, v98_7_tail);
          v99_8 = compose(v99_5,v100_7);
        }
        const Space v99_9 = intersect(constant_8,v99_2);
        const Space v99_10 = (has_head(v99_9) ? constant_9 : Space{});
        Space v99_12;
        if (!v99_10.empty()) {
          const Path v101_6 = concat_path(v98_6,v98_7_head);
          const Space v101_11 = routine_21(c, v101_6, p1, v98_7_tail);
          v99_12 = compose(v99_10,v101_11);
        }
        const Space v99_13 = unite(v99_8,v99_12);
        v98_7_result = unite(v98_7_result,v99_13);
      }
      const Space v98_7 = std::move(v98_7_result);
      v97_8 = compose(v97_5,v98_7);
    }
    const Space v97_9 = intersect(constant_8,v97_2);
    const Space v97_10 = (has_head(v97_9) ? constant_9 : Space{});
    Space v97_12;
    if (!v97_10.empty()) {
      const Path v102_6 = concat_path(p0,v96_12_head);
      Space v102_11_result;
      for (int v102_11_label = 1; v102_11_label <= 2; ++v102_11_label) {
        const Space v102_11_tail = child(v96_12_tail,v102_11_label);
        if (v102_11_tail.empty()) continue;
        const Path v102_11_head{v102_11_label};
        const Space v103_2 = singleton(v102_11_head);
        const Space v103_3 = intersect(constant_8,v103_2);
        const Space v103_4 = (has_head(v103_3) ? constant_9 : Space{});
        const Space v103_5 = subtract(constant_0,v103_4);
        Space v103_8;
        if (!v103_5.empty()) {
          const Path v104_6 = concat_path(v102_6,v102_11_head);
          const Space v104_7 = routine_20(c, v104_6, p1, v102_11_tail);
          v103_8 = compose(v103_5,v104_7);
        }
        const Space v103_9 = intersect(constant_8,v103_2);
        const Space v103_10 = (has_head(v103_9) ? constant_9 : Space{});
        Space v103_12;
        if (!v103_10.empty()) {
          const Path v105_6 = concat_path(v102_6,v102_11_head);
          const Space v105_11 = routine_10(c, v105_6, p1, v102_11_tail);
          v103_12 = compose(v103_10,v105_11);
        }
        const Space v103_13 = unite(v103_8,v103_12);
        v102_11_result = unite(v102_11_result,v103_13);
      }
      const Space v102_11 = std::move(v102_11_result);
      v97_12 = compose(v97_10,v102_11);
    }
    const Space v97_13 = unite(v97_8,v97_12);
    v96_12_result = unite(v96_12_result,v97_13);
  }
  const Space v96_12 = std::move(v96_12_result);
  return v96_12;
}

static Space routine_12(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v106_12_result;
  for (int v106_12_label = 1; v106_12_label <= 2; ++v106_12_label) {
    const Space v106_12_tail = child(s0,v106_12_label);
    if (v106_12_tail.empty()) continue;
    const Path v106_12_head{v106_12_label};
    const Space v107_2 = singleton(v106_12_head);
    const Space v107_3 = intersect(constant_8,v107_2);
    const Space v107_4 = (has_head(v107_3) ? constant_9 : Space{});
    const Space v107_5 = subtract(constant_0,v107_4);
    Space v107_8;
    if (!v107_5.empty()) {
      const Path v108_6 = concat_path(p0,v106_12_head);
      Space v108_7_result;
      for (int v108_7_label = 1; v108_7_label <= 2; ++v108_7_label) {
        const Space v108_7_tail = child(v106_12_tail,v108_7_label);
        if (v108_7_tail.empty()) continue;
        const Path v108_7_head{v108_7_label};
        const Space v109_2 = singleton(v108_7_head);
        const Space v109_3 = intersect(constant_8,v109_2);
        const Space v109_4 = (has_head(v109_3) ? constant_9 : Space{});
        const Space v109_5 = subtract(constant_0,v109_4);
        Space v109_8;
        if (!v109_5.empty()) {
          const Path v110_6 = concat_path(v108_6,v108_7_head);
          const Space v110_7 = routine_20(c, v110_6, p1, v108_7_tail);
          v109_8 = compose(v109_5,v110_7);
        }
        const Space v109_9 = intersect(constant_8,v109_2);
        const Space v109_10 = (has_head(v109_9) ? constant_9 : Space{});
        Space v109_12;
        if (!v109_10.empty()) {
          const Path v111_6 = concat_path(v108_6,v108_7_head);
          const Space v111_11 = routine_21(c, v111_6, p1, v108_7_tail);
          v109_12 = compose(v109_10,v111_11);
        }
        const Space v109_13 = unite(v109_8,v109_12);
        v108_7_result = unite(v108_7_result,v109_13);
      }
      const Space v108_7 = std::move(v108_7_result);
      v107_8 = compose(v107_5,v108_7);
    }
    const Space v107_9 = intersect(constant_8,v107_2);
    const Space v107_10 = (has_head(v107_9) ? constant_9 : Space{});
    Space v107_12;
    if (!v107_10.empty()) {
      const Path v112_6 = concat_path(p0,v106_12_head);
      Space v112_11_result;
      for (int v112_11_label = 1; v112_11_label <= 2; ++v112_11_label) {
        const Space v112_11_tail = child(v106_12_tail,v112_11_label);
        if (v112_11_tail.empty()) continue;
        const Path v112_11_head{v112_11_label};
        const Space v113_2 = singleton(v112_11_head);
        const Space v113_3 = intersect(constant_8,v113_2);
        const Space v113_4 = (has_head(v113_3) ? constant_9 : Space{});
        const Space v113_5 = subtract(constant_0,v113_4);
        Space v113_7;
        if (!v113_5.empty()) {
          const Space v114_6 = routine_13(c, v112_11_head, p1, v112_6, v112_11_tail);
          v113_7 = compose(v113_5,v114_6);
        }
        const Space v113_8 = intersect(constant_8,v113_2);
        const Space v113_9 = (has_head(v113_8) ? constant_9 : Space{});
        Space v113_11;
        if (!v113_9.empty()) {
          const Space v115_10 = routine_14(c, v112_11_head, p1, v112_6, v112_11_tail);
          v113_11 = compose(v113_9,v115_10);
        }
        const Space v113_12 = unite(v113_7,v113_11);
        v112_11_result = unite(v112_11_result,v113_12);
      }
      const Space v112_11 = std::move(v112_11_result);
      v107_12 = compose(v107_10,v112_11);
    }
    const Space v107_13 = unite(v107_8,v107_12);
    v106_12_result = unite(v106_12_result,v107_13);
  }
  const Space v106_12 = std::move(v106_12_result);
  return v106_12;
}

static Space routine_13(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v116_13_result;
  for (int v116_13_label = 1; v116_13_label <= 2; ++v116_13_label) {
    const Space v116_13_tail = child(s0,v116_13_label);
    if (v116_13_tail.empty()) continue;
    const Path v116_13_head{v116_13_label};
    const Space v117_2 = singleton(v116_13_head);
    const Space v117_3 = intersect(constant_8,v117_2);
    const Space v117_4 = (has_head(v117_3) ? constant_9 : Space{});
    const Space v117_5 = subtract(constant_0,v117_4);
    Space v117_8;
    if (!v117_5.empty()) {
      const Path v118_6 = concat_path(p0,v116_13_head);
      Space v118_7_result;
      for (int v118_7_label = 1; v118_7_label <= 2; ++v118_7_label) {
        const Space v118_7_tail = child(v116_13_tail,v118_7_label);
        if (v118_7_tail.empty()) continue;
        const Path v118_7_head{v118_7_label};
        const Space v119_2 = singleton(v118_7_head);
        const Space v119_3 = intersect(constant_8,v119_2);
        const Space v119_4 = (has_head(v119_3) ? constant_9 : Space{});
        const Space v119_5 = subtract(constant_0,v119_4);
        Space v119_8;
        if (!v119_5.empty()) {
          const Path v120_6 = concat_path(v118_6,v118_7_head);
          const Space v120_7 = routine_22(c, v120_6, p1, p2, v118_7_tail);
          v119_8 = compose(v119_5,v120_7);
        }
        const Space v119_9 = intersect(constant_8,v119_2);
        const Space v119_10 = (has_head(v119_9) ? constant_9 : Space{});
        Space v119_12;
        if (!v119_10.empty()) {
          const Path v121_6 = concat_path(v118_6,v118_7_head);
          const Space v121_11 = routine_23(c, v121_6, p1, p2, v118_7_tail);
          v119_12 = compose(v119_10,v121_11);
        }
        const Space v119_13 = unite(v119_8,v119_12);
        v118_7_result = unite(v118_7_result,v119_13);
      }
      const Space v118_7 = std::move(v118_7_result);
      v117_8 = compose(v117_5,v118_7);
    }
    const Space v117_9 = intersect(constant_8,v117_2);
    const Space v117_10 = (has_head(v117_9) ? constant_9 : Space{});
    Space v117_12;
    if (!v117_10.empty()) {
      const Path v122_6 = concat_path(p0,v116_13_head);
      Space v122_11_result;
      for (int v122_11_label = 1; v122_11_label <= 2; ++v122_11_label) {
        const Space v122_11_tail = child(v116_13_tail,v122_11_label);
        if (v122_11_tail.empty()) continue;
        const Path v122_11_head{v122_11_label};
        const Space v123_2 = singleton(v122_11_head);
        const Space v123_3 = intersect(constant_8,v123_2);
        const Space v123_4 = (has_head(v123_3) ? constant_9 : Space{});
        const Space v123_5 = subtract(constant_0,v123_4);
        Space v123_8;
        if (!v123_5.empty()) {
          const Path v124_6 = concat_path(v122_6,v122_11_head);
          const Space v124_7 = routine_22(c, v124_6, p1, p2, v122_11_tail);
          v123_8 = compose(v123_5,v124_7);
        }
        const Space v123_9 = intersect(constant_8,v123_2);
        const Space v123_10 = (has_head(v123_9) ? constant_9 : Space{});
        Space v123_12;
        if (!v123_10.empty()) {
          const Path v125_6 = concat_path(v122_6,v122_11_head);
          const Space v125_11 = routine_19(c, v125_6, p1, p2, v122_11_tail);
          v123_12 = compose(v123_10,v125_11);
        }
        const Space v123_13 = unite(v123_8,v123_12);
        v122_11_result = unite(v122_11_result,v123_13);
      }
      const Space v122_11 = std::move(v122_11_result);
      v117_12 = compose(v117_10,v122_11);
    }
    const Space v117_13 = unite(v117_8,v117_12);
    v116_13_result = unite(v116_13_result,v117_13);
  }
  const Space v116_13 = std::move(v116_13_result);
  return v116_13;
}

static Space routine_14(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v126_13_result;
  for (int v126_13_label = 1; v126_13_label <= 2; ++v126_13_label) {
    const Space v126_13_tail = child(s0,v126_13_label);
    if (v126_13_tail.empty()) continue;
    const Path v126_13_head{v126_13_label};
    const Space v127_2 = singleton(v126_13_head);
    const Space v127_3 = intersect(constant_8,v127_2);
    const Space v127_4 = (has_head(v127_3) ? constant_9 : Space{});
    const Space v127_5 = subtract(constant_0,v127_4);
    Space v127_8;
    if (!v127_5.empty()) {
      const Path v128_6 = concat_path(p0,v126_13_head);
      Space v128_7_result;
      for (int v128_7_label = 1; v128_7_label <= 2; ++v128_7_label) {
        const Space v128_7_tail = child(v126_13_tail,v128_7_label);
        if (v128_7_tail.empty()) continue;
        const Path v128_7_head{v128_7_label};
        const Space v129_2 = singleton(v128_7_head);
        const Space v129_3 = intersect(constant_8,v129_2);
        const Space v129_4 = (has_head(v129_3) ? constant_9 : Space{});
        const Space v129_5 = subtract(constant_0,v129_4);
        Space v129_8;
        if (!v129_5.empty()) {
          const Path v130_6 = concat_path(v128_6,v128_7_head);
          const Space v130_7 = routine_22(c, v130_6, p1, p2, v128_7_tail);
          v129_8 = compose(v129_5,v130_7);
        }
        const Space v129_9 = intersect(constant_8,v129_2);
        const Space v129_10 = (has_head(v129_9) ? constant_9 : Space{});
        Space v129_12;
        if (!v129_10.empty()) {
          const Path v131_6 = concat_path(v128_6,v128_7_head);
          const Space v131_11 = routine_23(c, v131_6, p1, p2, v128_7_tail);
          v129_12 = compose(v129_10,v131_11);
        }
        const Space v129_13 = unite(v129_8,v129_12);
        v128_7_result = unite(v128_7_result,v129_13);
      }
      const Space v128_7 = std::move(v128_7_result);
      v127_8 = compose(v127_5,v128_7);
    }
    const Space v127_9 = intersect(constant_8,v127_2);
    const Space v127_10 = (has_head(v127_9) ? constant_9 : Space{});
    Space v127_12;
    if (!v127_10.empty()) {
      const Path v132_6 = concat_path(p0,v126_13_head);
      Space v132_11_result;
      for (int v132_11_label = 1; v132_11_label <= 2; ++v132_11_label) {
        const Space v132_11_tail = child(v126_13_tail,v132_11_label);
        if (v132_11_tail.empty()) continue;
        const Path v132_11_head{v132_11_label};
        const Space v133_2 = singleton(v132_11_head);
        const Space v133_3 = intersect(constant_8,v133_2);
        const Space v133_4 = (has_head(v133_3) ? constant_9 : Space{});
        const Space v133_5 = subtract(constant_0,v133_4);
        Space v133_7;
        if (!v133_5.empty()) {
          const Space v134_6 = routine_24(c, v132_11_head, p1, p2, v132_6, v132_11_tail);
          v133_7 = compose(v133_5,v134_6);
        }
        const Space v133_8 = intersect(constant_8,v133_2);
        const Space v133_9 = (has_head(v133_8) ? constant_9 : Space{});
        Space v133_11;
        if (!v133_9.empty()) {
          const Space v135_10 = routine_25(c, v132_11_head, p1, p2, v132_6, v132_11_tail);
          v133_11 = compose(v133_9,v135_10);
        }
        const Space v133_12 = unite(v133_7,v133_11);
        v132_11_result = unite(v132_11_result,v133_12);
      }
      const Space v132_11 = std::move(v132_11_result);
      v127_12 = compose(v127_10,v132_11);
    }
    const Space v127_13 = unite(v127_8,v127_12);
    v126_13_result = unite(v126_13_result,v127_13);
  }
  const Space v126_13 = std::move(v126_13_result);
  return v126_13;
}

static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v136_7_result;
  for (int v136_7_label = 1; v136_7_label <= 2; ++v136_7_label) {
    const Space v136_7_tail = child(s0,v136_7_label);
    if (v136_7_tail.empty()) continue;
    const Path v136_7_head{v136_7_label};
    const Space v137_2 = singleton(v136_7_head);
    const Space v137_3 = intersect(constant_8,v137_2);
    const Space v137_4 = (has_head(v137_3) ? constant_9 : Space{});
    const Space v137_5 = subtract(constant_0,v137_4);
    Space v137_6_result;
    for (int v137_6_label = 1; v137_6_label <= 2; ++v137_6_label) {
      const Space v137_6_tail = child(v136_7_tail,v137_6_label);
      if (v137_6_tail.empty()) continue;
      const Path v137_6_head{v137_6_label};
      const Space v138_2 = Space{};
      v137_6_result = unite(v137_6_result,v138_2);
    }
    const Space v137_6 = std::move(v137_6_result);
    const Space v137_7 = compose(v137_5,v137_6);
    const Space v137_8 = intersect(constant_8,v137_2);
    const Space v137_9 = (has_head(v137_8) ? constant_9 : Space{});
    Space v137_12;
    if (!v137_9.empty()) {
      const Path v139_10 = concat_path(p0,v136_7_head);
      Space v139_11_result;
      for (int v139_11_label = 1; v139_11_label <= 2; ++v139_11_label) {
        const Space v139_11_tail = child(v136_7_tail,v139_11_label);
        if (v139_11_tail.empty()) continue;
        const Path v139_11_head{v139_11_label};
        const Space v140_2 = singleton(v139_11_head);
        const Space v140_3 = intersect(constant_8,v140_2);
        const Space v140_4 = (has_head(v140_3) ? constant_9 : Space{});
        Space v140_7;
        if (!v140_4.empty()) {
          const Path v141_5 = concat_path(v139_10,v139_11_head);
          const Space v141_6 = routine_10(c, v141_5, p1, v139_11_tail);
          v140_7 = compose(v140_4,v141_6);
        }
        v139_11_result = unite(v139_11_result,v140_7);
      }
      const Space v139_11 = std::move(v139_11_result);
      v137_12 = compose(v137_9,v139_11);
    }
    const Space v137_13 = unite(v137_7,v137_12);
    v136_7_result = unite(v136_7_result,v137_13);
  }
  const Space v136_7 = std::move(v136_7_result);
  return v136_7;
}

static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v142_9_result;
  for (int v142_9_label = 1; v142_9_label <= 2; ++v142_9_label) {
    const Space v142_9_tail = child(s0,v142_9_label);
    if (v142_9_tail.empty()) continue;
    const Path v142_9_head{v142_9_label};
    const Space v143_2 = singleton(v142_9_head);
    const Space v143_3 = intersect(constant_8,v143_2);
    const Space v143_4 = (has_head(v143_3) ? constant_9 : Space{});
    const Space v143_5 = subtract(constant_0,v143_4);
    Space v143_6_result;
    for (int v143_6_label = 1; v143_6_label <= 2; ++v143_6_label) {
      const Space v143_6_tail = child(v142_9_tail,v143_6_label);
      if (v143_6_tail.empty()) continue;
      const Path v143_6_head{v143_6_label};
      const Space v144_2 = Space{};
      v143_6_result = unite(v143_6_result,v144_2);
    }
    const Space v143_6 = std::move(v143_6_result);
    const Space v143_7 = compose(v143_5,v143_6);
    const Space v143_8 = intersect(constant_8,v143_2);
    const Space v143_9 = (has_head(v143_8) ? constant_9 : Space{});
    Space v143_12;
    if (!v143_9.empty()) {
      const Path v145_10 = concat_path(p0,v142_9_head);
      Space v145_11_result;
      for (int v145_11_label = 1; v145_11_label <= 2; ++v145_11_label) {
        const Space v145_11_tail = child(v142_9_tail,v145_11_label);
        if (v145_11_tail.empty()) continue;
        const Path v145_11_head{v145_11_label};
        const Space v146_2 = singleton(v145_11_head);
        const Space v146_3 = intersect(constant_8,v146_2);
        const Space v146_4 = (has_head(v146_3) ? constant_9 : Space{});
        const Space v146_5 = subtract(constant_0,v146_4);
        Space v146_7;
        if (!v146_5.empty()) {
          const Space v147_6 = routine_13(c, v145_11_head, p1, v145_10, v145_11_tail);
          v146_7 = compose(v146_5,v147_6);
        }
        const Space v146_8 = intersect(constant_8,v146_2);
        const Space v146_9 = (has_head(v146_8) ? constant_9 : Space{});
        Space v146_11;
        if (!v146_9.empty()) {
          const Space v148_10 = routine_14(c, v145_11_head, p1, v145_10, v145_11_tail);
          v146_11 = compose(v146_9,v148_10);
        }
        const Space v146_12 = unite(v146_7,v146_11);
        v145_11_result = unite(v145_11_result,v146_12);
      }
      const Space v145_11 = std::move(v145_11_result);
      v143_12 = compose(v143_9,v145_11);
    }
    const Space v143_13 = unite(v143_7,v143_12);
    v142_9_result = unite(v142_9_result,v143_13);
  }
  const Space v142_9 = std::move(v142_9_result);
  return v142_9;
}

static Space routine_17(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v149_13_result;
  for (int v149_13_label = 1; v149_13_label <= 2; ++v149_13_label) {
    const Space v149_13_tail = child(s0,v149_13_label);
    if (v149_13_tail.empty()) continue;
    const Path v149_13_head{v149_13_label};
    const Space v150_2 = singleton(v149_13_head);
    const Space v150_3 = intersect(constant_8,v150_2);
    const Space v150_4 = (has_head(v150_3) ? constant_9 : Space{});
    const Space v150_5 = subtract(constant_0,v150_4);
    Space v150_8;
    if (!v150_5.empty()) {
      const Path v151_6 = concat_path(p0,v149_13_head);
      Space v151_7_result;
      for (int v151_7_label = 1; v151_7_label <= 2; ++v151_7_label) {
        const Space v151_7_tail = child(v149_13_tail,v151_7_label);
        if (v151_7_tail.empty()) continue;
        const Path v151_7_head{v151_7_label};
        const Space v152_2 = singleton(v151_7_head);
        const Space v152_3 = intersect(constant_8,v152_2);
        const Space v152_4 = (has_head(v152_3) ? constant_9 : Space{});
        const Space v152_5 = subtract(constant_0,v152_4);
        Space v152_8;
        if (!v152_5.empty()) {
          const Path v153_6 = concat_path(v151_6,v151_7_head);
          const Space v153_7 = routine_26(c, v153_6, p1, p2, v151_7_tail);
          v152_8 = compose(v152_5,v153_7);
        }
        const Space v152_9 = intersect(constant_8,v152_2);
        const Space v152_10 = (has_head(v152_9) ? constant_9 : Space{});
        Space v152_12;
        if (!v152_10.empty()) {
          const Path v154_6 = concat_path(v151_6,v151_7_head);
          const Space v154_11 = routine_27(c, v154_6, p1, p2, v151_7_tail);
          v152_12 = compose(v152_10,v154_11);
        }
        const Space v152_13 = unite(v152_8,v152_12);
        v151_7_result = unite(v151_7_result,v152_13);
      }
      const Space v151_7 = std::move(v151_7_result);
      v150_8 = compose(v150_5,v151_7);
    }
    const Space v150_9 = intersect(constant_8,v150_2);
    const Space v150_10 = (has_head(v150_9) ? constant_9 : Space{});
    Space v150_12;
    if (!v150_10.empty()) {
      const Path v155_6 = concat_path(p0,v149_13_head);
      Space v155_11_result;
      for (int v155_11_label = 1; v155_11_label <= 2; ++v155_11_label) {
        const Space v155_11_tail = child(v149_13_tail,v155_11_label);
        if (v155_11_tail.empty()) continue;
        const Path v155_11_head{v155_11_label};
        const Space v156_2 = singleton(v155_11_head);
        const Space v156_3 = intersect(constant_8,v156_2);
        const Space v156_4 = (has_head(v156_3) ? constant_9 : Space{});
        const Space v156_5 = subtract(constant_0,v156_4);
        Space v156_8;
        if (!v156_5.empty()) {
          const Path v157_6 = concat_path(v155_6,v155_11_head);
          const Space v157_7 = routine_26(c, v157_6, p1, p2, v155_11_tail);
          v156_8 = compose(v156_5,v157_7);
        }
        const Space v156_9 = intersect(constant_8,v156_2);
        const Space v156_10 = (has_head(v156_9) ? constant_9 : Space{});
        Space v156_12;
        if (!v156_10.empty()) {
          const Path v158_6 = concat_path(v155_6,v155_11_head);
          const Space v158_11 = routine_19(c, v158_6, p1, p2, v155_11_tail);
          v156_12 = compose(v156_10,v158_11);
        }
        const Space v156_13 = unite(v156_8,v156_12);
        v155_11_result = unite(v155_11_result,v156_13);
      }
      const Space v155_11 = std::move(v155_11_result);
      v150_12 = compose(v150_10,v155_11);
    }
    const Space v150_13 = unite(v150_8,v150_12);
    v149_13_result = unite(v149_13_result,v150_13);
  }
  const Space v149_13 = std::move(v149_13_result);
  return v149_13;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v159_13_result;
  for (int v159_13_label = 1; v159_13_label <= 2; ++v159_13_label) {
    const Space v159_13_tail = child(s0,v159_13_label);
    if (v159_13_tail.empty()) continue;
    const Path v159_13_head{v159_13_label};
    const Space v160_2 = singleton(v159_13_head);
    const Space v160_3 = intersect(constant_8,v160_2);
    const Space v160_4 = (has_head(v160_3) ? constant_9 : Space{});
    const Space v160_5 = subtract(constant_0,v160_4);
    Space v160_8;
    if (!v160_5.empty()) {
      const Path v161_6 = concat_path(p0,v159_13_head);
      Space v161_7_result;
      for (int v161_7_label = 1; v161_7_label <= 2; ++v161_7_label) {
        const Space v161_7_tail = child(v159_13_tail,v161_7_label);
        if (v161_7_tail.empty()) continue;
        const Path v161_7_head{v161_7_label};
        const Space v162_2 = singleton(v161_7_head);
        const Space v162_3 = intersect(constant_8,v162_2);
        const Space v162_4 = (has_head(v162_3) ? constant_9 : Space{});
        const Space v162_5 = subtract(constant_0,v162_4);
        Space v162_8;
        if (!v162_5.empty()) {
          const Path v163_6 = concat_path(v161_6,v161_7_head);
          const Space v163_7 = routine_26(c, v163_6, p1, p2, v161_7_tail);
          v162_8 = compose(v162_5,v163_7);
        }
        const Space v162_9 = intersect(constant_8,v162_2);
        const Space v162_10 = (has_head(v162_9) ? constant_9 : Space{});
        Space v162_12;
        if (!v162_10.empty()) {
          const Path v164_6 = concat_path(v161_6,v161_7_head);
          const Space v164_11 = routine_27(c, v164_6, p1, p2, v161_7_tail);
          v162_12 = compose(v162_10,v164_11);
        }
        const Space v162_13 = unite(v162_8,v162_12);
        v161_7_result = unite(v161_7_result,v162_13);
      }
      const Space v161_7 = std::move(v161_7_result);
      v160_8 = compose(v160_5,v161_7);
    }
    const Space v160_9 = intersect(constant_8,v160_2);
    const Space v160_10 = (has_head(v160_9) ? constant_9 : Space{});
    Space v160_12;
    if (!v160_10.empty()) {
      const Path v165_6 = concat_path(p0,v159_13_head);
      Space v165_11_result;
      for (int v165_11_label = 1; v165_11_label <= 2; ++v165_11_label) {
        const Space v165_11_tail = child(v159_13_tail,v165_11_label);
        if (v165_11_tail.empty()) continue;
        const Path v165_11_head{v165_11_label};
        const Space v166_2 = singleton(v165_11_head);
        const Space v166_3 = intersect(constant_8,v166_2);
        const Space v166_4 = (has_head(v166_3) ? constant_9 : Space{});
        const Space v166_5 = subtract(constant_0,v166_4);
        Space v166_7;
        if (!v166_5.empty()) {
          const Space v167_6 = routine_24(c, v165_11_head, p1, p2, v165_6, v165_11_tail);
          v166_7 = compose(v166_5,v167_6);
        }
        const Space v166_8 = intersect(constant_8,v166_2);
        const Space v166_9 = (has_head(v166_8) ? constant_9 : Space{});
        Space v166_11;
        if (!v166_9.empty()) {
          const Space v168_10 = routine_25(c, v165_11_head, p1, p2, v165_6, v165_11_tail);
          v166_11 = compose(v166_9,v168_10);
        }
        const Space v166_12 = unite(v166_7,v166_11);
        v165_11_result = unite(v165_11_result,v166_12);
      }
      const Space v165_11 = std::move(v165_11_result);
      v160_12 = compose(v160_10,v165_11);
    }
    const Space v160_13 = unite(v160_8,v160_12);
    v159_13_result = unite(v159_13_result,v160_13);
  }
  const Space v159_13 = std::move(v159_13_result);
  return v159_13;
}

static Space routine_19(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v169_13_result;
  for (int v169_13_label = 1; v169_13_label <= 2; ++v169_13_label) {
    const Space v169_13_tail = child(s0,v169_13_label);
    if (v169_13_tail.empty()) continue;
    const Path v169_13_head{v169_13_label};
    const Space v170_2 = singleton(v169_13_head);
    const Space v170_3 = intersect(constant_8,v170_2);
    const Space v170_4 = (has_head(v170_3) ? constant_9 : Space{});
    const Space v170_5 = subtract(constant_0,v170_4);
    Space v170_7;
    if (!v170_5.empty()) {
      Space v171_6_result;
      for (int v171_6_label = 1; v171_6_label <= 2; ++v171_6_label) {
        const Space v171_6_tail = child(v169_13_tail,v171_6_label);
        if (v171_6_tail.empty()) continue;
        const Path v171_6_head{v171_6_label};
        const Space v172_2 = singleton(v171_6_head);
        const Space v172_3 = intersect(constant_8,v172_2);
        const Space v172_4 = (has_head(v172_3) ? constant_9 : Space{});
        const Space v172_5 = subtract(constant_0,v172_4);
        Space v172_8;
        if (!v172_5.empty()) {
          const Path v173_6 = concat_path(v169_13_head,v171_6_head);
          const Space v173_7 = routine_28(c, v173_6, p1, p2, p0, v171_6_tail);
          v172_8 = compose(v172_5,v173_7);
        }
        const Space v172_9 = intersect(constant_8,v172_2);
        const Space v172_10 = (has_head(v172_9) ? constant_9 : Space{});
        Space v172_12;
        if (!v172_10.empty()) {
          const Path v174_6 = concat_path(v169_13_head,v171_6_head);
          const Space v174_11 = routine_29(c, v174_6, p1, p2, p0, v171_6_tail);
          v172_12 = compose(v172_10,v174_11);
        }
        const Space v172_13 = unite(v172_8,v172_12);
        v171_6_result = unite(v171_6_result,v172_13);
      }
      const Space v171_6 = std::move(v171_6_result);
      v170_7 = compose(v170_5,v171_6);
    }
    const Space v170_8 = intersect(constant_8,v170_2);
    const Space v170_9 = (has_head(v170_8) ? constant_9 : Space{});
    Space v170_11;
    if (!v170_9.empty()) {
      Space v175_10_result;
      for (int v175_10_label = 1; v175_10_label <= 2; ++v175_10_label) {
        const Space v175_10_tail = child(v169_13_tail,v175_10_label);
        if (v175_10_tail.empty()) continue;
        const Path v175_10_head{v175_10_label};
        const Space v176_2 = singleton(v175_10_head);
        const Space v176_3 = intersect(constant_8,v176_2);
        const Space v176_4 = (has_head(v176_3) ? constant_9 : Space{});
        const Space v176_5 = subtract(constant_0,v176_4);
        Space v176_8;
        if (!v176_5.empty()) {
          const Path v177_6 = concat_path(v169_13_head,v175_10_head);
          const Space v177_7 = routine_28(c, v177_6, p1, p2, p0, v175_10_tail);
          v176_8 = compose(v176_5,v177_7);
        }
        const Space v176_9 = intersect(constant_8,v176_2);
        const Space v176_10 = (has_head(v176_9) ? constant_9 : Space{});
        Space v176_12;
        if (!v176_10.empty()) {
          const Path v178_6 = concat_path(v169_13_head,v175_10_head);
          const Space v178_11 = routine_30(c, v178_6, p1, p2, p0, v175_10_tail);
          v176_12 = compose(v176_10,v178_11);
        }
        const Space v176_13 = unite(v176_8,v176_12);
        v175_10_result = unite(v175_10_result,v176_13);
      }
      const Space v175_10 = std::move(v175_10_result);
      v170_11 = compose(v170_9,v175_10);
    }
    const Space v170_12 = unite(v170_7,v170_11);
    v169_13_result = unite(v169_13_result,v170_12);
  }
  const Space v169_13 = std::move(v169_13_result);
  return v169_13;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v179_3_result;
  for (int v179_3_label = 1; v179_3_label <= 2; ++v179_3_label) {
    const Space v179_3_tail = child(s0,v179_3_label);
    if (v179_3_tail.empty()) continue;
    const Path v179_3_head{v179_3_label};
    const Space v180_2 = Space{};
    v179_3_result = unite(v179_3_result,v180_2);
  }
  const Space v179_3 = std::move(v179_3_result);
  return v179_3;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v181_7_result;
  for (int v181_7_label = 1; v181_7_label <= 2; ++v181_7_label) {
    const Space v181_7_tail = child(s0,v181_7_label);
    if (v181_7_tail.empty()) continue;
    const Path v181_7_head{v181_7_label};
    const Space v182_2 = singleton(v181_7_head);
    const Space v182_3 = intersect(constant_8,v182_2);
    const Space v182_4 = (has_head(v182_3) ? constant_9 : Space{});
    Space v182_7;
    if (!v182_4.empty()) {
      const Path v183_5 = concat_path(p0,v181_7_head);
      Space v183_6_result;
      for (int v183_6_label = 1; v183_6_label <= 2; ++v183_6_label) {
        const Space v183_6_tail = child(v181_7_tail,v183_6_label);
        if (v183_6_tail.empty()) continue;
        const Path v183_6_head{v183_6_label};
        const Space v184_2 = singleton(v183_6_head);
        const Space v184_3 = intersect(constant_8,v184_2);
        const Space v184_4 = (has_head(v184_3) ? constant_9 : Space{});
        const Space v184_5 = subtract(constant_0,v184_4);
        Space v184_7;
        if (!v184_5.empty()) {
          const Space v185_6 = routine_13(c, v183_6_head, p1, v183_5, v183_6_tail);
          v184_7 = compose(v184_5,v185_6);
        }
        const Space v184_8 = intersect(constant_8,v184_2);
        const Space v184_9 = (has_head(v184_8) ? constant_9 : Space{});
        Space v184_11;
        if (!v184_9.empty()) {
          const Space v186_10 = routine_14(c, v183_6_head, p1, v183_5, v183_6_tail);
          v184_11 = compose(v184_9,v186_10);
        }
        const Space v184_12 = unite(v184_7,v184_11);
        v183_6_result = unite(v183_6_result,v184_12);
      }
      const Space v183_6 = std::move(v183_6_result);
      v182_7 = compose(v182_4,v183_6);
    }
    v181_7_result = unite(v181_7_result,v182_7);
  }
  const Space v181_7 = std::move(v181_7_result);
  return v181_7;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v187_13_result;
  for (int v187_13_label = 1; v187_13_label <= 2; ++v187_13_label) {
    const Space v187_13_tail = child(s0,v187_13_label);
    if (v187_13_tail.empty()) continue;
    const Path v187_13_head{v187_13_label};
    const Space v188_2 = singleton(v187_13_head);
    const Space v188_3 = intersect(constant_8,v188_2);
    const Space v188_4 = (has_head(v188_3) ? constant_9 : Space{});
    const Space v188_5 = subtract(constant_0,v188_4);
    Space v188_8;
    if (!v188_5.empty()) {
      const Path v189_6 = concat_path(p0,v187_13_head);
      Space v189_7_result;
      for (int v189_7_label = 1; v189_7_label <= 2; ++v189_7_label) {
        const Space v189_7_tail = child(v187_13_tail,v189_7_label);
        if (v189_7_tail.empty()) continue;
        const Path v189_7_head{v189_7_label};
        const Space v190_2 = singleton(v189_7_head);
        const Space v190_3 = intersect(constant_8,v190_2);
        const Space v190_4 = (has_head(v190_3) ? constant_9 : Space{});
        const Space v190_5 = subtract(constant_0,v190_4);
        Space v190_8;
        if (!v190_5.empty()) {
          const Path v191_6 = concat_path(v189_6,v189_7_head);
          const Space v191_7 = routine_31(c, v191_6, p1, p2, v189_7_tail);
          v190_8 = compose(v190_5,v191_7);
        }
        const Space v190_9 = intersect(constant_8,v190_2);
        const Space v190_10 = (has_head(v190_9) ? constant_9 : Space{});
        Space v190_12;
        if (!v190_10.empty()) {
          const Path v192_6 = concat_path(v189_6,v189_7_head);
          const Space v192_11 = routine_32(c, v192_6, p1, p2, v189_7_tail);
          v190_12 = compose(v190_10,v192_11);
        }
        const Space v190_13 = unite(v190_8,v190_12);
        v189_7_result = unite(v189_7_result,v190_13);
      }
      const Space v189_7 = std::move(v189_7_result);
      v188_8 = compose(v188_5,v189_7);
    }
    const Space v188_9 = intersect(constant_8,v188_2);
    const Space v188_10 = (has_head(v188_9) ? constant_9 : Space{});
    Space v188_12;
    if (!v188_10.empty()) {
      const Path v193_6 = concat_path(p0,v187_13_head);
      Space v193_11_result;
      for (int v193_11_label = 1; v193_11_label <= 2; ++v193_11_label) {
        const Space v193_11_tail = child(v187_13_tail,v193_11_label);
        if (v193_11_tail.empty()) continue;
        const Path v193_11_head{v193_11_label};
        const Space v194_2 = singleton(v193_11_head);
        const Space v194_3 = intersect(constant_8,v194_2);
        const Space v194_4 = (has_head(v194_3) ? constant_9 : Space{});
        const Space v194_5 = subtract(constant_0,v194_4);
        Space v194_8;
        if (!v194_5.empty()) {
          const Path v195_6 = concat_path(v193_6,v193_11_head);
          const Space v195_7 = routine_31(c, v195_6, p1, p2, v193_11_tail);
          v194_8 = compose(v194_5,v195_7);
        }
        const Space v194_9 = intersect(constant_8,v194_2);
        const Space v194_10 = (has_head(v194_9) ? constant_9 : Space{});
        Space v194_12;
        if (!v194_10.empty()) {
          const Path v196_6 = concat_path(v193_6,v193_11_head);
          const Space v196_11 = routine_19(c, v196_6, p1, p2, v193_11_tail);
          v194_12 = compose(v194_10,v196_11);
        }
        const Space v194_13 = unite(v194_8,v194_12);
        v193_11_result = unite(v193_11_result,v194_13);
      }
      const Space v193_11 = std::move(v193_11_result);
      v188_12 = compose(v188_10,v193_11);
    }
    const Space v188_13 = unite(v188_8,v188_12);
    v187_13_result = unite(v187_13_result,v188_13);
  }
  const Space v187_13 = std::move(v187_13_result);
  return v187_13;
}

static Space routine_23(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v197_13_result;
  for (int v197_13_label = 1; v197_13_label <= 2; ++v197_13_label) {
    const Space v197_13_tail = child(s0,v197_13_label);
    if (v197_13_tail.empty()) continue;
    const Path v197_13_head{v197_13_label};
    const Space v198_2 = singleton(v197_13_head);
    const Space v198_3 = intersect(constant_8,v198_2);
    const Space v198_4 = (has_head(v198_3) ? constant_9 : Space{});
    const Space v198_5 = subtract(constant_0,v198_4);
    Space v198_8;
    if (!v198_5.empty()) {
      const Path v199_6 = concat_path(p0,v197_13_head);
      Space v199_7_result;
      for (int v199_7_label = 1; v199_7_label <= 2; ++v199_7_label) {
        const Space v199_7_tail = child(v197_13_tail,v199_7_label);
        if (v199_7_tail.empty()) continue;
        const Path v199_7_head{v199_7_label};
        const Space v200_2 = singleton(v199_7_head);
        const Space v200_3 = intersect(constant_8,v200_2);
        const Space v200_4 = (has_head(v200_3) ? constant_9 : Space{});
        const Space v200_5 = subtract(constant_0,v200_4);
        Space v200_8;
        if (!v200_5.empty()) {
          const Path v201_6 = concat_path(v199_6,v199_7_head);
          const Space v201_7 = routine_31(c, v201_6, p1, p2, v199_7_tail);
          v200_8 = compose(v200_5,v201_7);
        }
        const Space v200_9 = intersect(constant_8,v200_2);
        const Space v200_10 = (has_head(v200_9) ? constant_9 : Space{});
        Space v200_12;
        if (!v200_10.empty()) {
          const Path v202_6 = concat_path(v199_6,v199_7_head);
          const Space v202_11 = routine_32(c, v202_6, p1, p2, v199_7_tail);
          v200_12 = compose(v200_10,v202_11);
        }
        const Space v200_13 = unite(v200_8,v200_12);
        v199_7_result = unite(v199_7_result,v200_13);
      }
      const Space v199_7 = std::move(v199_7_result);
      v198_8 = compose(v198_5,v199_7);
    }
    const Space v198_9 = intersect(constant_8,v198_2);
    const Space v198_10 = (has_head(v198_9) ? constant_9 : Space{});
    Space v198_12;
    if (!v198_10.empty()) {
      const Path v203_6 = concat_path(p0,v197_13_head);
      Space v203_11_result;
      for (int v203_11_label = 1; v203_11_label <= 2; ++v203_11_label) {
        const Space v203_11_tail = child(v197_13_tail,v203_11_label);
        if (v203_11_tail.empty()) continue;
        const Path v203_11_head{v203_11_label};
        const Space v204_2 = singleton(v203_11_head);
        const Space v204_3 = intersect(constant_8,v204_2);
        const Space v204_4 = (has_head(v204_3) ? constant_9 : Space{});
        const Space v204_5 = subtract(constant_0,v204_4);
        Space v204_7;
        if (!v204_5.empty()) {
          const Space v205_6 = routine_24(c, v203_11_head, p1, p2, v203_6, v203_11_tail);
          v204_7 = compose(v204_5,v205_6);
        }
        const Space v204_8 = intersect(constant_8,v204_2);
        const Space v204_9 = (has_head(v204_8) ? constant_9 : Space{});
        Space v204_11;
        if (!v204_9.empty()) {
          const Space v206_10 = routine_25(c, v203_11_head, p1, p2, v203_6, v203_11_tail);
          v204_11 = compose(v204_9,v206_10);
        }
        const Space v204_12 = unite(v204_7,v204_11);
        v203_11_result = unite(v203_11_result,v204_12);
      }
      const Space v203_11 = std::move(v203_11_result);
      v198_12 = compose(v198_10,v203_11);
    }
    const Space v198_13 = unite(v198_8,v198_12);
    v197_13_result = unite(v197_13_result,v198_13);
  }
  const Space v197_13 = std::move(v197_13_result);
  return v197_13;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v207_14_result;
  for (int v207_14_label = 1; v207_14_label <= 2; ++v207_14_label) {
    const Space v207_14_tail = child(s0,v207_14_label);
    if (v207_14_tail.empty()) continue;
    const Path v207_14_head{v207_14_label};
    const Space v208_2 = singleton(v207_14_head);
    const Space v208_3 = intersect(constant_8,v208_2);
    const Space v208_4 = (has_head(v208_3) ? constant_9 : Space{});
    const Space v208_5 = subtract(constant_0,v208_4);
    Space v208_8;
    if (!v208_5.empty()) {
      const Path v209_6 = concat_path(p0,v207_14_head);
      Space v209_7_result;
      for (int v209_7_label = 1; v209_7_label <= 2; ++v209_7_label) {
        const Space v209_7_tail = child(v207_14_tail,v209_7_label);
        if (v209_7_tail.empty()) continue;
        const Path v209_7_head{v209_7_label};
        const Space v210_2 = singleton(v209_7_head);
        const Space v210_3 = intersect(constant_8,v210_2);
        const Space v210_4 = (has_head(v210_3) ? constant_9 : Space{});
        const Space v210_5 = subtract(constant_0,v210_4);
        Space v210_8;
        if (!v210_5.empty()) {
          const Path v211_6 = concat_path(v209_6,v209_7_head);
          const Space v211_7 = routine_33(c, v211_6, p1, p2, p3, v209_7_tail);
          v210_8 = compose(v210_5,v211_7);
        }
        const Space v210_9 = intersect(constant_8,v210_2);
        const Space v210_10 = (has_head(v210_9) ? constant_9 : Space{});
        Space v210_12;
        if (!v210_10.empty()) {
          const Path v212_6 = concat_path(v209_6,v209_7_head);
          const Space v212_11 = routine_34(c, v212_6, p1, p2, p3, v209_7_tail);
          v210_12 = compose(v210_10,v212_11);
        }
        const Space v210_13 = unite(v210_8,v210_12);
        v209_7_result = unite(v209_7_result,v210_13);
      }
      const Space v209_7 = std::move(v209_7_result);
      v208_8 = compose(v208_5,v209_7);
    }
    const Space v208_9 = intersect(constant_8,v208_2);
    const Space v208_10 = (has_head(v208_9) ? constant_9 : Space{});
    Space v208_12;
    if (!v208_10.empty()) {
      const Path v213_6 = concat_path(p0,v207_14_head);
      Space v213_11_result;
      for (int v213_11_label = 1; v213_11_label <= 2; ++v213_11_label) {
        const Space v213_11_tail = child(v207_14_tail,v213_11_label);
        if (v213_11_tail.empty()) continue;
        const Path v213_11_head{v213_11_label};
        const Space v214_2 = singleton(v213_11_head);
        const Space v214_3 = intersect(constant_8,v214_2);
        const Space v214_4 = (has_head(v214_3) ? constant_9 : Space{});
        const Space v214_5 = subtract(constant_0,v214_4);
        Space v214_8;
        if (!v214_5.empty()) {
          const Path v215_6 = concat_path(v213_6,v213_11_head);
          const Space v215_7 = routine_33(c, v215_6, p1, p2, p3, v213_11_tail);
          v214_8 = compose(v214_5,v215_7);
        }
        const Space v214_9 = intersect(constant_8,v214_2);
        const Space v214_10 = (has_head(v214_9) ? constant_9 : Space{});
        Space v214_12;
        if (!v214_10.empty()) {
          const Path v216_6 = concat_path(v213_6,v213_11_head);
          const Space v216_11 = routine_30(c, v216_6, p1, p2, p3, v213_11_tail);
          v214_12 = compose(v214_10,v216_11);
        }
        const Space v214_13 = unite(v214_8,v214_12);
        v213_11_result = unite(v213_11_result,v214_13);
      }
      const Space v213_11 = std::move(v213_11_result);
      v208_12 = compose(v208_10,v213_11);
    }
    const Space v208_13 = unite(v208_8,v208_12);
    v207_14_result = unite(v207_14_result,v208_13);
  }
  const Space v207_14 = std::move(v207_14_result);
  return v207_14;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Path v217_8 = concat_path(p2,p3);
  Space v217_18_result;
  for (int v217_18_label = 1; v217_18_label <= 2; ++v217_18_label) {
    const Space v217_18_tail = child(s0,v217_18_label);
    if (v217_18_tail.empty()) continue;
    const Path v217_18_head{v217_18_label};
    const Space v218_2 = singleton(v217_18_head);
    const Space v218_3 = intersect(constant_8,v218_2);
    const Space v218_4 = (has_head(v218_3) ? constant_9 : Space{});
    const Space v218_5 = subtract(constant_0,v218_4);
    Space v218_8;
    if (!v218_5.empty()) {
      const Path v219_6 = concat_path(p0,v217_18_head);
      Space v219_7_result;
      for (int v219_7_label = 1; v219_7_label <= 2; ++v219_7_label) {
        const Space v219_7_tail = child(v217_18_tail,v219_7_label);
        if (v219_7_tail.empty()) continue;
        const Path v219_7_head{v219_7_label};
        const Space v220_2 = singleton(v219_7_head);
        const Space v220_3 = intersect(constant_8,v220_2);
        const Space v220_4 = (has_head(v220_3) ? constant_9 : Space{});
        const Space v220_5 = subtract(constant_0,v220_4);
        Space v220_8;
        if (!v220_5.empty()) {
          const Path v221_6 = concat_path(v219_6,v219_7_head);
          const Space v221_7 = routine_33(c, v221_6, p1, p2, p3, v219_7_tail);
          v220_8 = compose(v220_5,v221_7);
        }
        const Space v220_9 = intersect(constant_8,v220_2);
        const Space v220_10 = (has_head(v220_9) ? constant_9 : Space{});
        Space v220_12;
        if (!v220_10.empty()) {
          const Path v222_6 = concat_path(v219_6,v219_7_head);
          const Space v222_11 = routine_34(c, v222_6, p1, p2, p3, v219_7_tail);
          v220_12 = compose(v220_10,v222_11);
        }
        const Space v220_13 = unite(v220_8,v220_12);
        v219_7_result = unite(v219_7_result,v220_13);
      }
      const Space v219_7 = std::move(v219_7_result);
      v218_8 = compose(v218_5,v219_7);
    }
    const Space v218_9 = intersect(constant_8,v218_2);
    const Space v218_10 = (has_head(v218_9) ? constant_9 : Space{});
    Space v218_16;
    if (!v218_10.empty()) {
      const Path v223_6 = concat_path(p0,v217_18_head);
      const Path v223_11 = concat_path(v217_8,v223_6);
      const Space v223_12 = singleton(v223_11);
      const Space v223_13 = routine_35(c, p1, v223_12);
      Space v223_14_result;
      for (int v223_14_label = 1; v223_14_label <= 2; ++v223_14_label) {
        const Space v223_14_tail = child(v223_13,v223_14_label);
        if (v223_14_tail.empty()) continue;
        const Path v223_14_head{v223_14_label};
        const Space v224_2 = singleton(v223_14_head);
        const Space v224_3 = intersect(constant_8,v224_2);
        const Space v224_4 = (has_head(v224_3) ? constant_9 : Space{});
        const Space v224_5 = subtract(constant_0,v224_4);
        Space v224_7;
        if (!v224_5.empty()) {
          const Space v225_6 = routine_36(c, v223_14_head, p1, v223_14_tail);
          v224_7 = compose(v224_5,v225_6);
        }
        const Space v224_8 = intersect(constant_8,v224_2);
        const Space v224_9 = (has_head(v224_8) ? constant_9 : Space{});
        Space v224_11;
        if (!v224_9.empty()) {
          const Space v226_10 = routine_37(c, v223_14_head, p1, v223_14_tail);
          v224_11 = compose(v224_9,v226_10);
        }
        const Space v224_12 = unite(v224_7,v224_11);
        v223_14_result = unite(v223_14_result,v224_12);
      }
      const Space v223_14 = std::move(v223_14_result);
      Space v223_15_result;
      for (int v223_15_label = 1; v223_15_label <= 2; ++v223_15_label) {
        const Space v223_15_tail = child(v223_14,v223_15_label);
        if (v223_15_tail.empty()) continue;
        const Path v223_15_head{v223_15_label};
        const Space v227_2 = singleton(v223_15_head);
        const Space v227_3 = intersect(constant_8,v227_2);
        const Space v227_4 = (has_head(v227_3) ? constant_9 : Space{});
        const Space v227_5 = subtract(constant_0,v227_4);
        Space v227_7;
        if (!v227_5.empty()) {
          const Space v228_6 = routine_38(c, v223_15_head, p1, v223_15_tail);
          v227_7 = compose(v227_5,v228_6);
        }
        const Space v227_8 = intersect(constant_8,v227_2);
        const Space v227_9 = (has_head(v227_8) ? constant_9 : Space{});
        Space v227_11;
        if (!v227_9.empty()) {
          const Space v229_10 = routine_39(c, v223_15_head, p1, v223_15_tail);
          v227_11 = compose(v227_9,v229_10);
        }
        const Space v227_12 = unite(v227_7,v227_11);
        v223_15_result = unite(v223_15_result,v227_12);
      }
      const Space v223_15 = std::move(v223_15_result);
      v218_16 = compose(v218_10,v223_15);
    }
    const Space v218_17 = unite(v218_8,v218_16);
    v217_18_result = unite(v217_18_result,v218_17);
  }
  const Space v217_18 = std::move(v217_18_result);
  return v217_18;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v230_8_result;
  for (int v230_8_label = 1; v230_8_label <= 2; ++v230_8_label) {
    const Space v230_8_tail = child(s0,v230_8_label);
    if (v230_8_tail.empty()) continue;
    const Path v230_8_head{v230_8_label};
    const Space v231_2 = singleton(v230_8_head);
    const Space v231_3 = intersect(constant_8,v231_2);
    const Space v231_4 = (has_head(v231_3) ? constant_9 : Space{});
    const Space v231_5 = subtract(constant_0,v231_4);
    Space v231_6_result;
    for (int v231_6_label = 1; v231_6_label <= 2; ++v231_6_label) {
      const Space v231_6_tail = child(v230_8_tail,v231_6_label);
      if (v231_6_tail.empty()) continue;
      const Path v231_6_head{v231_6_label};
      const Space v232_2 = Space{};
      v231_6_result = unite(v231_6_result,v232_2);
    }
    const Space v231_6 = std::move(v231_6_result);
    const Space v231_7 = compose(v231_5,v231_6);
    const Space v231_8 = intersect(constant_8,v231_2);
    const Space v231_9 = (has_head(v231_8) ? constant_9 : Space{});
    Space v231_12;
    if (!v231_9.empty()) {
      const Path v233_10 = concat_path(p0,v230_8_head);
      Space v233_11_result;
      for (int v233_11_label = 1; v233_11_label <= 2; ++v233_11_label) {
        const Space v233_11_tail = child(v230_8_tail,v233_11_label);
        if (v233_11_tail.empty()) continue;
        const Path v233_11_head{v233_11_label};
        const Space v234_2 = singleton(v233_11_head);
        const Space v234_3 = intersect(constant_8,v234_2);
        const Space v234_4 = (has_head(v234_3) ? constant_9 : Space{});
        Space v234_7;
        if (!v234_4.empty()) {
          const Path v235_5 = concat_path(v233_10,v233_11_head);
          const Space v235_6 = routine_19(c, v235_5, p1, p2, v233_11_tail);
          v234_7 = compose(v234_4,v235_6);
        }
        v233_11_result = unite(v233_11_result,v234_7);
      }
      const Space v233_11 = std::move(v233_11_result);
      v231_12 = compose(v231_9,v233_11);
    }
    const Space v231_13 = unite(v231_7,v231_12);
    v230_8_result = unite(v230_8_result,v231_13);
  }
  const Space v230_8 = std::move(v230_8_result);
  return v230_8;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v236_10_result;
  for (int v236_10_label = 1; v236_10_label <= 2; ++v236_10_label) {
    const Space v236_10_tail = child(s0,v236_10_label);
    if (v236_10_tail.empty()) continue;
    const Path v236_10_head{v236_10_label};
    const Space v237_2 = singleton(v236_10_head);
    const Space v237_3 = intersect(constant_8,v237_2);
    const Space v237_4 = (has_head(v237_3) ? constant_9 : Space{});
    const Space v237_5 = subtract(constant_0,v237_4);
    Space v237_6_result;
    for (int v237_6_label = 1; v237_6_label <= 2; ++v237_6_label) {
      const Space v237_6_tail = child(v236_10_tail,v237_6_label);
      if (v237_6_tail.empty()) continue;
      const Path v237_6_head{v237_6_label};
      const Space v238_2 = Space{};
      v237_6_result = unite(v237_6_result,v238_2);
    }
    const Space v237_6 = std::move(v237_6_result);
    const Space v237_7 = compose(v237_5,v237_6);
    const Space v237_8 = intersect(constant_8,v237_2);
    const Space v237_9 = (has_head(v237_8) ? constant_9 : Space{});
    Space v237_12;
    if (!v237_9.empty()) {
      const Path v239_10 = concat_path(p0,v236_10_head);
      Space v239_11_result;
      for (int v239_11_label = 1; v239_11_label <= 2; ++v239_11_label) {
        const Space v239_11_tail = child(v236_10_tail,v239_11_label);
        if (v239_11_tail.empty()) continue;
        const Path v239_11_head{v239_11_label};
        const Space v240_2 = singleton(v239_11_head);
        const Space v240_3 = intersect(constant_8,v240_2);
        const Space v240_4 = (has_head(v240_3) ? constant_9 : Space{});
        const Space v240_5 = subtract(constant_0,v240_4);
        Space v240_7;
        if (!v240_5.empty()) {
          const Space v241_6 = routine_24(c, v239_11_head, p1, p2, v239_10, v239_11_tail);
          v240_7 = compose(v240_5,v241_6);
        }
        const Space v240_8 = intersect(constant_8,v240_2);
        const Space v240_9 = (has_head(v240_8) ? constant_9 : Space{});
        Space v240_11;
        if (!v240_9.empty()) {
          const Space v242_10 = routine_25(c, v239_11_head, p1, p2, v239_10, v239_11_tail);
          v240_11 = compose(v240_9,v242_10);
        }
        const Space v240_12 = unite(v240_7,v240_11);
        v239_11_result = unite(v239_11_result,v240_12);
      }
      const Space v239_11 = std::move(v239_11_result);
      v237_12 = compose(v237_9,v239_11);
    }
    const Space v237_13 = unite(v237_7,v237_12);
    v236_10_result = unite(v236_10_result,v237_13);
  }
  const Space v236_10 = std::move(v236_10_result);
  return v236_10;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v243_14_result;
  for (int v243_14_label = 1; v243_14_label <= 2; ++v243_14_label) {
    const Space v243_14_tail = child(s0,v243_14_label);
    if (v243_14_tail.empty()) continue;
    const Path v243_14_head{v243_14_label};
    const Space v244_2 = singleton(v243_14_head);
    const Space v244_3 = intersect(constant_8,v244_2);
    const Space v244_4 = (has_head(v244_3) ? constant_9 : Space{});
    const Space v244_5 = subtract(constant_0,v244_4);
    Space v244_8;
    if (!v244_5.empty()) {
      const Path v245_6 = concat_path(p0,v243_14_head);
      Space v245_7_result;
      for (int v245_7_label = 1; v245_7_label <= 2; ++v245_7_label) {
        const Space v245_7_tail = child(v243_14_tail,v245_7_label);
        if (v245_7_tail.empty()) continue;
        const Path v245_7_head{v245_7_label};
        const Space v246_2 = singleton(v245_7_head);
        const Space v246_3 = intersect(constant_8,v246_2);
        const Space v246_4 = (has_head(v246_3) ? constant_9 : Space{});
        const Space v246_5 = subtract(constant_0,v246_4);
        Space v246_8;
        if (!v246_5.empty()) {
          const Path v247_6 = concat_path(v245_6,v245_7_head);
          const Space v247_7 = routine_40(c, v247_6, p1, p2, p3, v245_7_tail);
          v246_8 = compose(v246_5,v247_7);
        }
        const Space v246_9 = intersect(constant_8,v246_2);
        const Space v246_10 = (has_head(v246_9) ? constant_9 : Space{});
        Space v246_12;
        if (!v246_10.empty()) {
          const Path v248_6 = concat_path(v245_6,v245_7_head);
          const Space v248_11 = routine_41(c, v248_6, p1, p2, p3, v245_7_tail);
          v246_12 = compose(v246_10,v248_11);
        }
        const Space v246_13 = unite(v246_8,v246_12);
        v245_7_result = unite(v245_7_result,v246_13);
      }
      const Space v245_7 = std::move(v245_7_result);
      v244_8 = compose(v244_5,v245_7);
    }
    const Space v244_9 = intersect(constant_8,v244_2);
    const Space v244_10 = (has_head(v244_9) ? constant_9 : Space{});
    Space v244_12;
    if (!v244_10.empty()) {
      const Path v249_6 = concat_path(p0,v243_14_head);
      Space v249_11_result;
      for (int v249_11_label = 1; v249_11_label <= 2; ++v249_11_label) {
        const Space v249_11_tail = child(v243_14_tail,v249_11_label);
        if (v249_11_tail.empty()) continue;
        const Path v249_11_head{v249_11_label};
        const Space v250_2 = singleton(v249_11_head);
        const Space v250_3 = intersect(constant_8,v250_2);
        const Space v250_4 = (has_head(v250_3) ? constant_9 : Space{});
        const Space v250_5 = subtract(constant_0,v250_4);
        Space v250_8;
        if (!v250_5.empty()) {
          const Path v251_6 = concat_path(v249_6,v249_11_head);
          const Space v251_7 = routine_40(c, v251_6, p1, p2, p3, v249_11_tail);
          v250_8 = compose(v250_5,v251_7);
        }
        const Space v250_9 = intersect(constant_8,v250_2);
        const Space v250_10 = (has_head(v250_9) ? constant_9 : Space{});
        Space v250_12;
        if (!v250_10.empty()) {
          const Path v252_6 = concat_path(v249_6,v249_11_head);
          const Space v252_11 = routine_30(c, v252_6, p1, p2, p3, v249_11_tail);
          v250_12 = compose(v250_10,v252_11);
        }
        const Space v250_13 = unite(v250_8,v250_12);
        v249_11_result = unite(v249_11_result,v250_13);
      }
      const Space v249_11 = std::move(v249_11_result);
      v244_12 = compose(v244_10,v249_11);
    }
    const Space v244_13 = unite(v244_8,v244_12);
    v243_14_result = unite(v243_14_result,v244_13);
  }
  const Space v243_14 = std::move(v243_14_result);
  return v243_14;
}

static Space routine_29(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Path v253_8 = concat_path(p2,p3);
  Space v253_18_result;
  for (int v253_18_label = 1; v253_18_label <= 2; ++v253_18_label) {
    const Space v253_18_tail = child(s0,v253_18_label);
    if (v253_18_tail.empty()) continue;
    const Path v253_18_head{v253_18_label};
    const Space v254_2 = singleton(v253_18_head);
    const Space v254_3 = intersect(constant_8,v254_2);
    const Space v254_4 = (has_head(v254_3) ? constant_9 : Space{});
    const Space v254_5 = subtract(constant_0,v254_4);
    Space v254_8;
    if (!v254_5.empty()) {
      const Path v255_6 = concat_path(p0,v253_18_head);
      Space v255_7_result;
      for (int v255_7_label = 1; v255_7_label <= 2; ++v255_7_label) {
        const Space v255_7_tail = child(v253_18_tail,v255_7_label);
        if (v255_7_tail.empty()) continue;
        const Path v255_7_head{v255_7_label};
        const Space v256_2 = singleton(v255_7_head);
        const Space v256_3 = intersect(constant_8,v256_2);
        const Space v256_4 = (has_head(v256_3) ? constant_9 : Space{});
        const Space v256_5 = subtract(constant_0,v256_4);
        Space v256_8;
        if (!v256_5.empty()) {
          const Path v257_6 = concat_path(v255_6,v255_7_head);
          const Space v257_7 = routine_40(c, v257_6, p1, p2, p3, v255_7_tail);
          v256_8 = compose(v256_5,v257_7);
        }
        const Space v256_9 = intersect(constant_8,v256_2);
        const Space v256_10 = (has_head(v256_9) ? constant_9 : Space{});
        Space v256_12;
        if (!v256_10.empty()) {
          const Path v258_6 = concat_path(v255_6,v255_7_head);
          const Space v258_11 = routine_41(c, v258_6, p1, p2, p3, v255_7_tail);
          v256_12 = compose(v256_10,v258_11);
        }
        const Space v256_13 = unite(v256_8,v256_12);
        v255_7_result = unite(v255_7_result,v256_13);
      }
      const Space v255_7 = std::move(v255_7_result);
      v254_8 = compose(v254_5,v255_7);
    }
    const Space v254_9 = intersect(constant_8,v254_2);
    const Space v254_10 = (has_head(v254_9) ? constant_9 : Space{});
    Space v254_16;
    if (!v254_10.empty()) {
      const Path v259_6 = concat_path(p0,v253_18_head);
      const Path v259_11 = concat_path(v253_8,v259_6);
      const Space v259_12 = singleton(v259_11);
      const Space v259_13 = routine_35(c, p1, v259_12);
      Space v259_14_result;
      for (int v259_14_label = 1; v259_14_label <= 2; ++v259_14_label) {
        const Space v259_14_tail = child(v259_13,v259_14_label);
        if (v259_14_tail.empty()) continue;
        const Path v259_14_head{v259_14_label};
        const Space v260_2 = singleton(v259_14_head);
        const Space v260_3 = intersect(constant_8,v260_2);
        const Space v260_4 = (has_head(v260_3) ? constant_9 : Space{});
        const Space v260_5 = subtract(constant_0,v260_4);
        Space v260_7;
        if (!v260_5.empty()) {
          const Space v261_6 = routine_36(c, v259_14_head, p1, v259_14_tail);
          v260_7 = compose(v260_5,v261_6);
        }
        const Space v260_8 = intersect(constant_8,v260_2);
        const Space v260_9 = (has_head(v260_8) ? constant_9 : Space{});
        Space v260_11;
        if (!v260_9.empty()) {
          const Space v262_10 = routine_37(c, v259_14_head, p1, v259_14_tail);
          v260_11 = compose(v260_9,v262_10);
        }
        const Space v260_12 = unite(v260_7,v260_11);
        v259_14_result = unite(v259_14_result,v260_12);
      }
      const Space v259_14 = std::move(v259_14_result);
      Space v259_15_result;
      for (int v259_15_label = 1; v259_15_label <= 2; ++v259_15_label) {
        const Space v259_15_tail = child(v259_14,v259_15_label);
        if (v259_15_tail.empty()) continue;
        const Path v259_15_head{v259_15_label};
        const Space v263_2 = singleton(v259_15_head);
        const Space v263_3 = intersect(constant_8,v263_2);
        const Space v263_4 = (has_head(v263_3) ? constant_9 : Space{});
        const Space v263_5 = subtract(constant_0,v263_4);
        Space v263_7;
        if (!v263_5.empty()) {
          const Space v264_6 = routine_38(c, v259_15_head, p1, v259_15_tail);
          v263_7 = compose(v263_5,v264_6);
        }
        const Space v263_8 = intersect(constant_8,v263_2);
        const Space v263_9 = (has_head(v263_8) ? constant_9 : Space{});
        Space v263_11;
        if (!v263_9.empty()) {
          const Space v265_10 = routine_39(c, v259_15_head, p1, v259_15_tail);
          v263_11 = compose(v263_9,v265_10);
        }
        const Space v263_12 = unite(v263_7,v263_11);
        v259_15_result = unite(v259_15_result,v263_12);
      }
      const Space v259_15 = std::move(v259_15_result);
      v254_16 = compose(v254_10,v259_15);
    }
    const Space v254_17 = unite(v254_8,v254_16);
    v253_18_result = unite(v253_18_result,v254_17);
  }
  const Space v253_18 = std::move(v253_18_result);
  return v253_18;
}

static Space routine_30(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Space v266_6 = singleton(p1);
  const Space v266_7 = intersect(constant_10,v266_6);
  Space v266_11_result;
  for (int v266_11_label = 1; v266_11_label <= 2; ++v266_11_label) {
    const Space v266_11_tail = child(v266_7,v266_11_label);
    if (v266_11_tail.empty()) continue;
    const Path v266_11_head{v266_11_label};
    const Space v267_2 = singleton(v266_11_head);
    const Space v267_3 = intersect(constant_8,v267_2);
    const Space v267_4 = (has_head(v267_3) ? constant_9 : Space{});
    const Space v267_5 = subtract(constant_0,v267_4);
    Space v267_7;
    if (!v267_5.empty()) {
      const Space v268_6 = routine_42(c, v266_11_head, v266_11_tail);
      v267_7 = compose(v267_5,v268_6);
    }
    const Space v267_8 = intersect(constant_8,v267_2);
    const Space v267_9 = (has_head(v267_8) ? constant_9 : Space{});
    Space v267_11;
    if (!v267_9.empty()) {
      const Space v269_10 = routine_43(c, v266_11_head, v266_11_tail);
      v267_11 = compose(v267_9,v269_10);
    }
    const Space v267_12 = unite(v267_7,v267_11);
    v266_11_result = unite(v266_11_result,v267_12);
  }
  const Space v266_11 = std::move(v266_11_result);
  Space v266_19;
  if (!v266_11.empty()) {
    const Path v270_12 = concat_path(p2,p3);
    const Path v270_13 = concat_path(v270_12,p0);
    const Space v270_14 = singleton(v270_13);
    Space v270_18_result;
    for (int v270_18_label = 1; v270_18_label <= 2; ++v270_18_label) {
      const Space v270_18_tail = child(v270_14,v270_18_label);
      if (v270_18_tail.empty()) continue;
      const Path v270_18_head{v270_18_label};
      const Space v271_2 = singleton(v270_18_head);
      const Space v271_3 = intersect(constant_8,v271_2);
      const Space v271_4 = (has_head(v271_3) ? constant_9 : Space{});
      const Space v271_5 = subtract(constant_0,v271_4);
      Space v271_7;
      if (!v271_5.empty()) {
        const Space v272_6 = routine_44(c, v270_18_head, v270_18_tail);
        v271_7 = compose(v271_5,v272_6);
      }
      const Space v271_8 = intersect(constant_8,v271_2);
      const Space v271_9 = (has_head(v271_8) ? constant_9 : Space{});
      Space v271_11;
      if (!v271_9.empty()) {
        const Space v273_10 = routine_45(c, v270_18_head, v270_18_tail);
        v271_11 = compose(v271_9,v273_10);
      }
      const Space v271_12 = unite(v271_7,v271_11);
      v270_18_result = unite(v270_18_result,v271_12);
    }
    const Space v270_18 = std::move(v270_18_result);
    v266_19 = compose(v266_11,v270_18);
  }
  const Space v266_21 = intersect(constant_11,v266_6);
  Space v266_25_result;
  for (int v266_25_label = 1; v266_25_label <= 2; ++v266_25_label) {
    const Space v266_25_tail = child(v266_21,v266_25_label);
    if (v266_25_tail.empty()) continue;
    const Path v266_25_head{v266_25_label};
    const Space v274_2 = singleton(v266_25_head);
    const Space v274_3 = intersect(constant_8,v274_2);
    const Space v274_4 = (has_head(v274_3) ? constant_9 : Space{});
    const Space v274_5 = subtract(constant_0,v274_4);
    Space v274_7;
    if (!v274_5.empty()) {
      const Space v275_6 = routine_46(c, v266_25_head, v266_25_tail);
      v274_7 = compose(v274_5,v275_6);
    }
    const Space v274_8 = intersect(constant_8,v274_2);
    const Space v274_9 = (has_head(v274_8) ? constant_9 : Space{});
    Space v274_11;
    if (!v274_9.empty()) {
      const Space v276_10 = routine_47(c, v266_25_head, v266_25_tail);
      v274_11 = compose(v274_9,v276_10);
    }
    const Space v274_12 = unite(v274_7,v274_11);
    v266_25_result = unite(v266_25_result,v274_12);
  }
  const Space v266_25 = std::move(v266_25_result);
  Space v266_30;
  if (!v266_25.empty()) {
    const Path v277_12 = concat_path(p2,p3);
    const Path v277_13 = concat_path(v277_12,p0);
    const Space v277_14 = singleton(v277_13);
    Space v277_29_result;
    for (int v277_29_label = 1; v277_29_label <= 2; ++v277_29_label) {
      const Space v277_29_tail = child(v277_14,v277_29_label);
      if (v277_29_tail.empty()) continue;
      const Path v277_29_head{v277_29_label};
      const Space v278_2 = singleton(v277_29_head);
      const Space v278_3 = intersect(constant_8,v278_2);
      const Space v278_4 = (has_head(v278_3) ? constant_9 : Space{});
      const Space v278_5 = subtract(constant_0,v278_4);
      Space v278_7;
      if (!v278_5.empty()) {
        const Space v279_6 = routine_48(c, v277_29_head, v277_29_tail);
        v278_7 = compose(v278_5,v279_6);
      }
      const Space v278_8 = intersect(constant_8,v278_2);
      const Space v278_9 = (has_head(v278_8) ? constant_9 : Space{});
      Space v278_11;
      if (!v278_9.empty()) {
        const Space v280_10 = routine_49(c, v277_29_head, v277_29_tail);
        v278_11 = compose(v278_9,v280_10);
      }
      const Space v278_12 = unite(v278_7,v278_11);
      v277_29_result = unite(v277_29_result,v278_12);
    }
    const Space v277_29 = std::move(v277_29_result);
    v266_30 = compose(v266_25,v277_29);
  }
  const Space v266_31 = unite(v266_19,v266_30);
  const Space v266_33 = intersect(constant_12,v266_6);
  Space v266_37_result;
  for (int v266_37_label = 1; v266_37_label <= 2; ++v266_37_label) {
    const Space v266_37_tail = child(v266_33,v266_37_label);
    if (v266_37_tail.empty()) continue;
    const Path v266_37_head{v266_37_label};
    const Space v281_2 = singleton(v266_37_head);
    const Space v281_3 = intersect(constant_8,v281_2);
    const Space v281_4 = (has_head(v281_3) ? constant_9 : Space{});
    const Space v281_5 = subtract(constant_0,v281_4);
    Space v281_7;
    if (!v281_5.empty()) {
      const Space v282_6 = routine_50(c, v266_37_head, v266_37_tail);
      v281_7 = compose(v281_5,v282_6);
    }
    const Space v281_8 = intersect(constant_8,v281_2);
    const Space v281_9 = (has_head(v281_8) ? constant_9 : Space{});
    Space v281_11;
    if (!v281_9.empty()) {
      const Space v283_10 = routine_51(c, v266_37_head, v266_37_tail);
      v281_11 = compose(v281_9,v283_10);
    }
    const Space v281_12 = unite(v281_7,v281_11);
    v266_37_result = unite(v266_37_result,v281_12);
  }
  const Space v266_37 = std::move(v266_37_result);
  Space v266_42;
  if (!v266_37.empty()) {
    const Path v284_12 = concat_path(p2,p3);
    const Path v284_13 = concat_path(v284_12,p0);
    const Space v284_14 = singleton(v284_13);
    Space v284_41_result;
    for (int v284_41_label = 1; v284_41_label <= 2; ++v284_41_label) {
      const Space v284_41_tail = child(v284_14,v284_41_label);
      if (v284_41_tail.empty()) continue;
      const Path v284_41_head{v284_41_label};
      const Space v285_2 = singleton(v284_41_head);
      const Space v285_3 = intersect(constant_8,v285_2);
      const Space v285_4 = (has_head(v285_3) ? constant_9 : Space{});
      const Space v285_5 = subtract(constant_0,v285_4);
      Space v285_7;
      if (!v285_5.empty()) {
        const Space v286_6 = routine_52(c, v284_41_head, v284_41_tail);
        v285_7 = compose(v285_5,v286_6);
      }
      const Space v285_8 = intersect(constant_8,v285_2);
      const Space v285_9 = (has_head(v285_8) ? constant_9 : Space{});
      Space v285_11;
      if (!v285_9.empty()) {
        const Space v287_10 = routine_53(c, v284_41_head, v284_41_tail);
        v285_11 = compose(v285_9,v287_10);
      }
      const Space v285_12 = unite(v285_7,v285_11);
      v284_41_result = unite(v284_41_result,v285_12);
    }
    const Space v284_41 = std::move(v284_41_result);
    v266_42 = compose(v266_37,v284_41);
  }
  const Space v266_43 = unite(v266_31,v266_42);
  const Space v266_45 = intersect(constant_13,v266_6);
  Space v266_49_result;
  for (int v266_49_label = 1; v266_49_label <= 2; ++v266_49_label) {
    const Space v266_49_tail = child(v266_45,v266_49_label);
    if (v266_49_tail.empty()) continue;
    const Path v266_49_head{v266_49_label};
    const Space v288_2 = singleton(v266_49_head);
    const Space v288_3 = intersect(constant_8,v288_2);
    const Space v288_4 = (has_head(v288_3) ? constant_9 : Space{});
    const Space v288_5 = subtract(constant_0,v288_4);
    Space v288_7;
    if (!v288_5.empty()) {
      const Space v289_6 = routine_54(c, v266_49_head, v266_49_tail);
      v288_7 = compose(v288_5,v289_6);
    }
    const Space v288_8 = intersect(constant_8,v288_2);
    const Space v288_9 = (has_head(v288_8) ? constant_9 : Space{});
    Space v288_11;
    if (!v288_9.empty()) {
      const Space v290_10 = routine_55(c, v266_49_head, v266_49_tail);
      v288_11 = compose(v288_9,v290_10);
    }
    const Space v288_12 = unite(v288_7,v288_11);
    v266_49_result = unite(v266_49_result,v288_12);
  }
  const Space v266_49 = std::move(v266_49_result);
  Space v266_54;
  if (!v266_49.empty()) {
    const Path v291_12 = concat_path(p2,p3);
    const Path v291_13 = concat_path(v291_12,p0);
    const Space v291_14 = singleton(v291_13);
    Space v291_53_result;
    for (int v291_53_label = 1; v291_53_label <= 2; ++v291_53_label) {
      const Space v291_53_tail = child(v291_14,v291_53_label);
      if (v291_53_tail.empty()) continue;
      const Path v291_53_head{v291_53_label};
      const Space v292_2 = singleton(v291_53_head);
      const Space v292_3 = intersect(constant_8,v292_2);
      const Space v292_4 = (has_head(v292_3) ? constant_9 : Space{});
      const Space v292_5 = subtract(constant_0,v292_4);
      Space v292_7;
      if (!v292_5.empty()) {
        const Space v293_6 = routine_56(c, v291_53_head, v291_53_tail);
        v292_7 = compose(v292_5,v293_6);
      }
      const Space v292_8 = intersect(constant_8,v292_2);
      const Space v292_9 = (has_head(v292_8) ? constant_9 : Space{});
      Space v292_11;
      if (!v292_9.empty()) {
        const Space v294_10 = routine_57(c, v291_53_head, v291_53_tail);
        v292_11 = compose(v292_9,v294_10);
      }
      const Space v292_12 = unite(v292_7,v292_11);
      v291_53_result = unite(v291_53_result,v292_12);
    }
    const Space v291_53 = std::move(v291_53_result);
    v266_54 = compose(v266_49,v291_53);
  }
  const Space v266_55 = unite(v266_43,v266_54);
  Space v266_65_result;
  for (int v266_65_label = 1; v266_65_label <= 2; ++v266_65_label) {
    const Space v266_65_tail = child(v266_55,v266_65_label);
    if (v266_65_tail.empty()) continue;
    const Path v266_65_head{v266_65_label};
    const Space v295_2 = singleton(v266_65_head);
    const Space v295_3 = intersect(constant_8,v295_2);
    const Space v295_4 = (has_head(v295_3) ? constant_9 : Space{});
    const Space v295_5 = subtract(constant_0,v295_4);
    Space v295_7;
    if (!v295_5.empty()) {
      Space v296_6_result;
      for (int v296_6_label = 1; v296_6_label <= 2; ++v296_6_label) {
        const Space v296_6_tail = child(v266_65_tail,v296_6_label);
        if (v296_6_tail.empty()) continue;
        const Path v296_6_head{v296_6_label};
        const Space v297_2 = singleton(v296_6_head);
        const Space v297_3 = intersect(constant_8,v297_2);
        const Space v297_4 = (has_head(v297_3) ? constant_9 : Space{});
        const Space v297_5 = subtract(constant_0,v297_4);
        Space v297_8;
        if (!v297_5.empty()) {
          const Path v298_6 = concat_path(v266_65_head,v296_6_head);
          const Space v298_7 = routine_58(c, v298_6, p1, v296_6_tail);
          v297_8 = compose(v297_5,v298_7);
        }
        const Space v297_9 = intersect(constant_8,v297_2);
        const Space v297_10 = (has_head(v297_9) ? constant_9 : Space{});
        Space v297_12;
        if (!v297_10.empty()) {
          const Path v299_6 = concat_path(v266_65_head,v296_6_head);
          const Space v299_11 = routine_59(c, v299_6, p1, v296_6_tail);
          v297_12 = compose(v297_10,v299_11);
        }
        const Space v297_13 = unite(v297_8,v297_12);
        v296_6_result = unite(v296_6_result,v297_13);
      }
      const Space v296_6 = std::move(v296_6_result);
      v295_7 = compose(v295_5,v296_6);
    }
    const Space v295_8 = intersect(constant_8,v295_2);
    const Space v295_9 = (has_head(v295_8) ? constant_9 : Space{});
    Space v295_11;
    if (!v295_9.empty()) {
      Space v300_10_result;
      for (int v300_10_label = 1; v300_10_label <= 2; ++v300_10_label) {
        const Space v300_10_tail = child(v266_65_tail,v300_10_label);
        if (v300_10_tail.empty()) continue;
        const Path v300_10_head{v300_10_label};
        const Space v301_2 = singleton(v300_10_head);
        const Space v301_3 = intersect(constant_8,v301_2);
        const Space v301_4 = (has_head(v301_3) ? constant_9 : Space{});
        const Space v301_5 = subtract(constant_0,v301_4);
        Space v301_8;
        if (!v301_5.empty()) {
          const Path v302_6 = concat_path(v266_65_head,v300_10_head);
          const Space v302_7 = routine_58(c, v302_6, p1, v300_10_tail);
          v301_8 = compose(v301_5,v302_7);
        }
        const Space v301_9 = intersect(constant_8,v301_2);
        const Space v301_10 = (has_head(v301_9) ? constant_9 : Space{});
        Space v301_12;
        if (!v301_10.empty()) {
          const Path v303_6 = concat_path(v266_65_head,v300_10_head);
          const Space v303_11 = routine_60(c, v303_6, p1, v300_10_tail);
          v301_12 = compose(v301_10,v303_11);
        }
        const Space v301_13 = unite(v301_8,v301_12);
        v300_10_result = unite(v300_10_result,v301_13);
      }
      const Space v300_10 = std::move(v300_10_result);
      v295_11 = compose(v295_9,v300_10);
    }
    const Space v295_12 = unite(v295_7,v295_11);
    v266_65_result = unite(v266_65_result,v295_12);
  }
  const Space v266_65 = std::move(v266_65_result);
  Space v266_75_result;
  for (int v266_75_label = 1; v266_75_label <= 2; ++v266_75_label) {
    const Space v266_75_tail = child(v266_65,v266_75_label);
    if (v266_75_tail.empty()) continue;
    const Path v266_75_head{v266_75_label};
    const Space v304_2 = singleton(v266_75_head);
    const Space v304_3 = intersect(constant_8,v304_2);
    const Space v304_4 = (has_head(v304_3) ? constant_9 : Space{});
    const Space v304_5 = subtract(constant_0,v304_4);
    Space v304_7;
    if (!v304_5.empty()) {
      Space v305_6_result;
      for (int v305_6_label = 1; v305_6_label <= 2; ++v305_6_label) {
        const Space v305_6_tail = child(v266_75_tail,v305_6_label);
        if (v305_6_tail.empty()) continue;
        const Path v305_6_head{v305_6_label};
        const Space v306_2 = singleton(v305_6_head);
        const Space v306_3 = intersect(constant_8,v306_2);
        const Space v306_4 = (has_head(v306_3) ? constant_9 : Space{});
        const Space v306_5 = subtract(constant_0,v306_4);
        Space v306_8;
        if (!v306_5.empty()) {
          const Path v307_6 = concat_path(v266_75_head,v305_6_head);
          const Space v307_7 = routine_61(c, v307_6, p1, v305_6_tail);
          v306_8 = compose(v306_5,v307_7);
        }
        const Space v306_9 = intersect(constant_8,v306_2);
        const Space v306_10 = (has_head(v306_9) ? constant_9 : Space{});
        Space v306_12;
        if (!v306_10.empty()) {
          const Path v308_6 = concat_path(v266_75_head,v305_6_head);
          const Space v308_11 = routine_62(c, v308_6, p1, v305_6_tail);
          v306_12 = compose(v306_10,v308_11);
        }
        const Space v306_13 = unite(v306_8,v306_12);
        v305_6_result = unite(v305_6_result,v306_13);
      }
      const Space v305_6 = std::move(v305_6_result);
      v304_7 = compose(v304_5,v305_6);
    }
    const Space v304_8 = intersect(constant_8,v304_2);
    const Space v304_9 = (has_head(v304_8) ? constant_9 : Space{});
    Space v304_11;
    if (!v304_9.empty()) {
      Space v309_10_result;
      for (int v309_10_label = 1; v309_10_label <= 2; ++v309_10_label) {
        const Space v309_10_tail = child(v266_75_tail,v309_10_label);
        if (v309_10_tail.empty()) continue;
        const Path v309_10_head{v309_10_label};
        const Space v310_2 = singleton(v309_10_head);
        const Space v310_3 = intersect(constant_8,v310_2);
        const Space v310_4 = (has_head(v310_3) ? constant_9 : Space{});
        const Space v310_5 = subtract(constant_0,v310_4);
        Space v310_8;
        if (!v310_5.empty()) {
          const Path v311_6 = concat_path(v266_75_head,v309_10_head);
          const Space v311_7 = routine_61(c, v311_6, p1, v309_10_tail);
          v310_8 = compose(v310_5,v311_7);
        }
        const Space v310_9 = intersect(constant_8,v310_2);
        const Space v310_10 = (has_head(v310_9) ? constant_9 : Space{});
        Space v310_12;
        if (!v310_10.empty()) {
          const Path v312_6 = concat_path(v266_75_head,v309_10_head);
          const Space v312_11 = routine_63(c, v312_6, p1, v309_10_tail);
          v310_12 = compose(v310_10,v312_11);
        }
        const Space v310_13 = unite(v310_8,v310_12);
        v309_10_result = unite(v309_10_result,v310_13);
      }
      const Space v309_10 = std::move(v309_10_result);
      v304_11 = compose(v304_9,v309_10);
    }
    const Space v304_12 = unite(v304_7,v304_11);
    v266_75_result = unite(v266_75_result,v304_12);
  }
  const Space v266_75 = std::move(v266_75_result);
  return v266_75;
}

static Space routine_31(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v313_4_result;
  for (int v313_4_label = 1; v313_4_label <= 2; ++v313_4_label) {
    const Space v313_4_tail = child(s0,v313_4_label);
    if (v313_4_tail.empty()) continue;
    const Path v313_4_head{v313_4_label};
    const Space v314_2 = Space{};
    v313_4_result = unite(v313_4_result,v314_2);
  }
  const Space v313_4 = std::move(v313_4_result);
  return v313_4;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v315_8_result;
  for (int v315_8_label = 1; v315_8_label <= 2; ++v315_8_label) {
    const Space v315_8_tail = child(s0,v315_8_label);
    if (v315_8_tail.empty()) continue;
    const Path v315_8_head{v315_8_label};
    const Space v316_2 = singleton(v315_8_head);
    const Space v316_3 = intersect(constant_8,v316_2);
    const Space v316_4 = (has_head(v316_3) ? constant_9 : Space{});
    Space v316_7;
    if (!v316_4.empty()) {
      const Path v317_5 = concat_path(p0,v315_8_head);
      Space v317_6_result;
      for (int v317_6_label = 1; v317_6_label <= 2; ++v317_6_label) {
        const Space v317_6_tail = child(v315_8_tail,v317_6_label);
        if (v317_6_tail.empty()) continue;
        const Path v317_6_head{v317_6_label};
        const Space v318_2 = singleton(v317_6_head);
        const Space v318_3 = intersect(constant_8,v318_2);
        const Space v318_4 = (has_head(v318_3) ? constant_9 : Space{});
        const Space v318_5 = subtract(constant_0,v318_4);
        Space v318_7;
        if (!v318_5.empty()) {
          const Space v319_6 = routine_24(c, v317_6_head, p1, p2, v317_5, v317_6_tail);
          v318_7 = compose(v318_5,v319_6);
        }
        const Space v318_8 = intersect(constant_8,v318_2);
        const Space v318_9 = (has_head(v318_8) ? constant_9 : Space{});
        Space v318_11;
        if (!v318_9.empty()) {
          const Space v320_10 = routine_25(c, v317_6_head, p1, p2, v317_5, v317_6_tail);
          v318_11 = compose(v318_9,v320_10);
        }
        const Space v318_12 = unite(v318_7,v318_11);
        v317_6_result = unite(v317_6_result,v318_12);
      }
      const Space v317_6 = std::move(v317_6_result);
      v316_7 = compose(v316_4,v317_6);
    }
    v315_8_result = unite(v315_8_result,v316_7);
  }
  const Space v315_8 = std::move(v315_8_result);
  return v315_8;
}

static Space routine_33(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v321_14_result;
  for (int v321_14_label = 1; v321_14_label <= 2; ++v321_14_label) {
    const Space v321_14_tail = child(s0,v321_14_label);
    if (v321_14_tail.empty()) continue;
    const Path v321_14_head{v321_14_label};
    const Space v322_2 = singleton(v321_14_head);
    const Space v322_3 = intersect(constant_8,v322_2);
    const Space v322_4 = (has_head(v322_3) ? constant_9 : Space{});
    const Space v322_5 = subtract(constant_0,v322_4);
    Space v322_8;
    if (!v322_5.empty()) {
      const Path v323_6 = concat_path(p0,v321_14_head);
      Space v323_7_result;
      for (int v323_7_label = 1; v323_7_label <= 2; ++v323_7_label) {
        const Space v323_7_tail = child(v321_14_tail,v323_7_label);
        if (v323_7_tail.empty()) continue;
        const Path v323_7_head{v323_7_label};
        const Space v324_2 = singleton(v323_7_head);
        const Space v324_3 = intersect(constant_8,v324_2);
        const Space v324_4 = (has_head(v324_3) ? constant_9 : Space{});
        const Space v324_5 = subtract(constant_0,v324_4);
        Space v324_8;
        if (!v324_5.empty()) {
          const Path v325_6 = concat_path(v323_6,v323_7_head);
          const Space v325_7 = routine_64(c, v325_6, p1, p2, p3, v323_7_tail);
          v324_8 = compose(v324_5,v325_7);
        }
        const Space v324_9 = intersect(constant_8,v324_2);
        const Space v324_10 = (has_head(v324_9) ? constant_9 : Space{});
        Space v324_12;
        if (!v324_10.empty()) {
          const Path v326_6 = concat_path(v323_6,v323_7_head);
          const Space v326_11 = routine_65(c, v326_6, p1, p2, p3, v323_7_tail);
          v324_12 = compose(v324_10,v326_11);
        }
        const Space v324_13 = unite(v324_8,v324_12);
        v323_7_result = unite(v323_7_result,v324_13);
      }
      const Space v323_7 = std::move(v323_7_result);
      v322_8 = compose(v322_5,v323_7);
    }
    const Space v322_9 = intersect(constant_8,v322_2);
    const Space v322_10 = (has_head(v322_9) ? constant_9 : Space{});
    Space v322_12;
    if (!v322_10.empty()) {
      const Path v327_6 = concat_path(p0,v321_14_head);
      Space v327_11_result;
      for (int v327_11_label = 1; v327_11_label <= 2; ++v327_11_label) {
        const Space v327_11_tail = child(v321_14_tail,v327_11_label);
        if (v327_11_tail.empty()) continue;
        const Path v327_11_head{v327_11_label};
        const Space v328_2 = singleton(v327_11_head);
        const Space v328_3 = intersect(constant_8,v328_2);
        const Space v328_4 = (has_head(v328_3) ? constant_9 : Space{});
        const Space v328_5 = subtract(constant_0,v328_4);
        Space v328_8;
        if (!v328_5.empty()) {
          const Path v329_6 = concat_path(v327_6,v327_11_head);
          const Space v329_7 = routine_64(c, v329_6, p1, p2, p3, v327_11_tail);
          v328_8 = compose(v328_5,v329_7);
        }
        const Space v328_9 = intersect(constant_8,v328_2);
        const Space v328_10 = (has_head(v328_9) ? constant_9 : Space{});
        Space v328_12;
        if (!v328_10.empty()) {
          const Path v330_6 = concat_path(v327_6,v327_11_head);
          const Space v330_11 = routine_30(c, v330_6, p1, p2, p3, v327_11_tail);
          v328_12 = compose(v328_10,v330_11);
        }
        const Space v328_13 = unite(v328_8,v328_12);
        v327_11_result = unite(v327_11_result,v328_13);
      }
      const Space v327_11 = std::move(v327_11_result);
      v322_12 = compose(v322_10,v327_11);
    }
    const Space v322_13 = unite(v322_8,v322_12);
    v321_14_result = unite(v321_14_result,v322_13);
  }
  const Space v321_14 = std::move(v321_14_result);
  return v321_14;
}

static Space routine_34(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Path v331_8 = concat_path(p2,p3);
  Space v331_18_result;
  for (int v331_18_label = 1; v331_18_label <= 2; ++v331_18_label) {
    const Space v331_18_tail = child(s0,v331_18_label);
    if (v331_18_tail.empty()) continue;
    const Path v331_18_head{v331_18_label};
    const Space v332_2 = singleton(v331_18_head);
    const Space v332_3 = intersect(constant_8,v332_2);
    const Space v332_4 = (has_head(v332_3) ? constant_9 : Space{});
    const Space v332_5 = subtract(constant_0,v332_4);
    Space v332_8;
    if (!v332_5.empty()) {
      const Path v333_6 = concat_path(p0,v331_18_head);
      Space v333_7_result;
      for (int v333_7_label = 1; v333_7_label <= 2; ++v333_7_label) {
        const Space v333_7_tail = child(v331_18_tail,v333_7_label);
        if (v333_7_tail.empty()) continue;
        const Path v333_7_head{v333_7_label};
        const Space v334_2 = singleton(v333_7_head);
        const Space v334_3 = intersect(constant_8,v334_2);
        const Space v334_4 = (has_head(v334_3) ? constant_9 : Space{});
        const Space v334_5 = subtract(constant_0,v334_4);
        Space v334_8;
        if (!v334_5.empty()) {
          const Path v335_6 = concat_path(v333_6,v333_7_head);
          const Space v335_7 = routine_64(c, v335_6, p1, p2, p3, v333_7_tail);
          v334_8 = compose(v334_5,v335_7);
        }
        const Space v334_9 = intersect(constant_8,v334_2);
        const Space v334_10 = (has_head(v334_9) ? constant_9 : Space{});
        Space v334_12;
        if (!v334_10.empty()) {
          const Path v336_6 = concat_path(v333_6,v333_7_head);
          const Space v336_11 = routine_65(c, v336_6, p1, p2, p3, v333_7_tail);
          v334_12 = compose(v334_10,v336_11);
        }
        const Space v334_13 = unite(v334_8,v334_12);
        v333_7_result = unite(v333_7_result,v334_13);
      }
      const Space v333_7 = std::move(v333_7_result);
      v332_8 = compose(v332_5,v333_7);
    }
    const Space v332_9 = intersect(constant_8,v332_2);
    const Space v332_10 = (has_head(v332_9) ? constant_9 : Space{});
    Space v332_16;
    if (!v332_10.empty()) {
      const Path v337_6 = concat_path(p0,v331_18_head);
      const Path v337_11 = concat_path(v331_8,v337_6);
      const Space v337_12 = singleton(v337_11);
      const Space v337_13 = routine_35(c, p1, v337_12);
      Space v337_14_result;
      for (int v337_14_label = 1; v337_14_label <= 2; ++v337_14_label) {
        const Space v337_14_tail = child(v337_13,v337_14_label);
        if (v337_14_tail.empty()) continue;
        const Path v337_14_head{v337_14_label};
        const Space v338_2 = singleton(v337_14_head);
        const Space v338_3 = intersect(constant_8,v338_2);
        const Space v338_4 = (has_head(v338_3) ? constant_9 : Space{});
        const Space v338_5 = subtract(constant_0,v338_4);
        Space v338_7;
        if (!v338_5.empty()) {
          const Space v339_6 = routine_36(c, v337_14_head, p1, v337_14_tail);
          v338_7 = compose(v338_5,v339_6);
        }
        const Space v338_8 = intersect(constant_8,v338_2);
        const Space v338_9 = (has_head(v338_8) ? constant_9 : Space{});
        Space v338_11;
        if (!v338_9.empty()) {
          const Space v340_10 = routine_37(c, v337_14_head, p1, v337_14_tail);
          v338_11 = compose(v338_9,v340_10);
        }
        const Space v338_12 = unite(v338_7,v338_11);
        v337_14_result = unite(v337_14_result,v338_12);
      }
      const Space v337_14 = std::move(v337_14_result);
      Space v337_15_result;
      for (int v337_15_label = 1; v337_15_label <= 2; ++v337_15_label) {
        const Space v337_15_tail = child(v337_14,v337_15_label);
        if (v337_15_tail.empty()) continue;
        const Path v337_15_head{v337_15_label};
        const Space v341_2 = singleton(v337_15_head);
        const Space v341_3 = intersect(constant_8,v341_2);
        const Space v341_4 = (has_head(v341_3) ? constant_9 : Space{});
        const Space v341_5 = subtract(constant_0,v341_4);
        Space v341_7;
        if (!v341_5.empty()) {
          const Space v342_6 = routine_38(c, v337_15_head, p1, v337_15_tail);
          v341_7 = compose(v341_5,v342_6);
        }
        const Space v341_8 = intersect(constant_8,v341_2);
        const Space v341_9 = (has_head(v341_8) ? constant_9 : Space{});
        Space v341_11;
        if (!v341_9.empty()) {
          const Space v343_10 = routine_39(c, v337_15_head, p1, v337_15_tail);
          v341_11 = compose(v341_9,v343_10);
        }
        const Space v341_12 = unite(v341_7,v341_11);
        v337_15_result = unite(v337_15_result,v341_12);
      }
      const Space v337_15 = std::move(v337_15_result);
      v332_16 = compose(v332_10,v337_15);
    }
    const Space v332_17 = unite(v332_8,v332_16);
    v331_18_result = unite(v331_18_result,v332_17);
  }
  const Space v331_18 = std::move(v331_18_result);
  return v331_18;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0) {
  const Space v344_3 = singleton(p0);
  const Space v344_4 = intersect(constant_10,v344_3);
  Space v344_14_result;
  for (int v344_14_label = 1; v344_14_label <= 2; ++v344_14_label) {
    const Space v344_14_tail = child(v344_4,v344_14_label);
    if (v344_14_tail.empty()) continue;
    const Path v344_14_head{v344_14_label};
    const Space v345_2 = singleton(v344_14_head);
    const Space v345_3 = intersect(constant_8,v345_2);
    const Space v345_4 = (has_head(v345_3) ? constant_9 : Space{});
    const Space v345_5 = subtract(constant_0,v345_4);
    Space v345_7;
    if (!v345_5.empty()) {
      Space v346_6_result;
      for (int v346_6_label = 1; v346_6_label <= 2; ++v346_6_label) {
        const Space v346_6_tail = child(v344_14_tail,v346_6_label);
        if (v346_6_tail.empty()) continue;
        const Path v346_6_head{v346_6_label};
        const Space v347_2 = singleton(v346_6_head);
        const Space v347_3 = intersect(constant_8,v347_2);
        const Space v347_4 = (has_head(v347_3) ? constant_9 : Space{});
        const Space v347_5 = subtract(constant_0,v347_4);
        Space v347_8;
        if (!v347_5.empty()) {
          const Path v348_6 = concat_path(v344_14_head,v346_6_head);
          const Space v348_7 = routine_66(c, v348_6, v346_6_tail);
          v347_8 = compose(v347_5,v348_7);
        }
        const Space v347_9 = intersect(constant_8,v347_2);
        const Space v347_10 = (has_head(v347_9) ? constant_9 : Space{});
        Space v347_12;
        if (!v347_10.empty()) {
          const Path v349_6 = concat_path(v344_14_head,v346_6_head);
          const Space v349_11 = routine_67(c, v349_6, v346_6_tail);
          v347_12 = compose(v347_10,v349_11);
        }
        const Space v347_13 = unite(v347_8,v347_12);
        v346_6_result = unite(v346_6_result,v347_13);
      }
      const Space v346_6 = std::move(v346_6_result);
      v345_7 = compose(v345_5,v346_6);
    }
    const Space v345_8 = intersect(constant_8,v345_2);
    const Space v345_9 = (has_head(v345_8) ? constant_9 : Space{});
    Space v345_11;
    if (!v345_9.empty()) {
      Space v350_10_result;
      for (int v350_10_label = 1; v350_10_label <= 2; ++v350_10_label) {
        const Space v350_10_tail = child(v344_14_tail,v350_10_label);
        if (v350_10_tail.empty()) continue;
        const Path v350_10_head{v350_10_label};
        const Space v351_2 = singleton(v350_10_head);
        const Space v351_3 = intersect(constant_8,v351_2);
        const Space v351_4 = (has_head(v351_3) ? constant_9 : Space{});
        const Space v351_5 = subtract(constant_0,v351_4);
        Space v351_8;
        if (!v351_5.empty()) {
          const Path v352_6 = concat_path(v344_14_head,v350_10_head);
          const Space v352_7 = routine_66(c, v352_6, v350_10_tail);
          v351_8 = compose(v351_5,v352_7);
        }
        const Space v351_9 = intersect(constant_8,v351_2);
        const Space v351_10 = (has_head(v351_9) ? constant_9 : Space{});
        Space v351_12;
        if (!v351_10.empty()) {
          const Path v353_6 = concat_path(v344_14_head,v350_10_head);
          const Space v353_11 = routine_68(c, v353_6, v350_10_tail);
          v351_12 = compose(v351_10,v353_11);
        }
        const Space v351_13 = unite(v351_8,v351_12);
        v350_10_result = unite(v350_10_result,v351_13);
      }
      const Space v350_10 = std::move(v350_10_result);
      v345_11 = compose(v345_9,v350_10);
    }
    const Space v345_12 = unite(v345_7,v345_11);
    v344_14_result = unite(v344_14_result,v345_12);
  }
  const Space v344_14 = std::move(v344_14_result);
  Space v344_25;
  if (!v344_14.empty()) {
    Space v354_24_result;
    for (int v354_24_label = 1; v354_24_label <= 2; ++v354_24_label) {
      const Space v354_24_tail = child(s0,v354_24_label);
      if (v354_24_tail.empty()) continue;
      const Path v354_24_head{v354_24_label};
      const Space v355_2 = singleton(v354_24_head);
      const Space v355_3 = intersect(constant_8,v355_2);
      const Space v355_4 = (has_head(v355_3) ? constant_9 : Space{});
      const Space v355_5 = subtract(constant_0,v355_4);
      Space v355_7;
      if (!v355_5.empty()) {
        Space v356_6_result;
        for (int v356_6_label = 1; v356_6_label <= 2; ++v356_6_label) {
          const Space v356_6_tail = child(v354_24_tail,v356_6_label);
          if (v356_6_tail.empty()) continue;
          const Path v356_6_head{v356_6_label};
          const Space v357_2 = singleton(v356_6_head);
          const Space v357_3 = intersect(constant_8,v357_2);
          const Space v357_4 = (has_head(v357_3) ? constant_9 : Space{});
          const Space v357_5 = subtract(constant_0,v357_4);
          Space v357_8;
          if (!v357_5.empty()) {
            const Path v358_6 = concat_path(v354_24_head,v356_6_head);
            const Space v358_7 = routine_69(c, v358_6, v356_6_tail);
            v357_8 = compose(v357_5,v358_7);
          }
          const Space v357_9 = intersect(constant_8,v357_2);
          const Space v357_10 = (has_head(v357_9) ? constant_9 : Space{});
          Space v357_12;
          if (!v357_10.empty()) {
            const Path v359_6 = concat_path(v354_24_head,v356_6_head);
            const Space v359_11 = routine_70(c, v359_6, v356_6_tail);
            v357_12 = compose(v357_10,v359_11);
          }
          const Space v357_13 = unite(v357_8,v357_12);
          v356_6_result = unite(v356_6_result,v357_13);
        }
        const Space v356_6 = std::move(v356_6_result);
        v355_7 = compose(v355_5,v356_6);
      }
      const Space v355_8 = intersect(constant_8,v355_2);
      const Space v355_9 = (has_head(v355_8) ? constant_9 : Space{});
      Space v355_11;
      if (!v355_9.empty()) {
        Space v360_10_result;
        for (int v360_10_label = 1; v360_10_label <= 2; ++v360_10_label) {
          const Space v360_10_tail = child(v354_24_tail,v360_10_label);
          if (v360_10_tail.empty()) continue;
          const Path v360_10_head{v360_10_label};
          const Space v361_2 = singleton(v360_10_head);
          const Space v361_3 = intersect(constant_8,v361_2);
          const Space v361_4 = (has_head(v361_3) ? constant_9 : Space{});
          const Space v361_5 = subtract(constant_0,v361_4);
          Space v361_8;
          if (!v361_5.empty()) {
            const Path v362_6 = concat_path(v354_24_head,v360_10_head);
            const Space v362_7 = routine_69(c, v362_6, v360_10_tail);
            v361_8 = compose(v361_5,v362_7);
          }
          const Space v361_9 = intersect(constant_8,v361_2);
          const Space v361_10 = (has_head(v361_9) ? constant_9 : Space{});
          Space v361_12;
          if (!v361_10.empty()) {
            const Path v363_6 = concat_path(v354_24_head,v360_10_head);
            const Space v363_11 = routine_71(c, v363_6, v360_10_tail);
            v361_12 = compose(v361_10,v363_11);
          }
          const Space v361_13 = unite(v361_8,v361_12);
          v360_10_result = unite(v360_10_result,v361_13);
        }
        const Space v360_10 = std::move(v360_10_result);
        v355_11 = compose(v355_9,v360_10);
      }
      const Space v355_12 = unite(v355_7,v355_11);
      v354_24_result = unite(v354_24_result,v355_12);
    }
    const Space v354_24 = std::move(v354_24_result);
    v344_25 = compose(v344_14,v354_24);
  }
  const Space v344_27 = intersect(constant_11,v344_3);
  Space v344_37_result;
  for (int v344_37_label = 1; v344_37_label <= 2; ++v344_37_label) {
    const Space v344_37_tail = child(v344_27,v344_37_label);
    if (v344_37_tail.empty()) continue;
    const Path v344_37_head{v344_37_label};
    const Space v364_2 = singleton(v344_37_head);
    const Space v364_3 = intersect(constant_8,v364_2);
    const Space v364_4 = (has_head(v364_3) ? constant_9 : Space{});
    const Space v364_5 = subtract(constant_0,v364_4);
    Space v364_7;
    if (!v364_5.empty()) {
      Space v365_6_result;
      for (int v365_6_label = 1; v365_6_label <= 2; ++v365_6_label) {
        const Space v365_6_tail = child(v344_37_tail,v365_6_label);
        if (v365_6_tail.empty()) continue;
        const Path v365_6_head{v365_6_label};
        const Space v366_2 = singleton(v365_6_head);
        const Space v366_3 = intersect(constant_8,v366_2);
        const Space v366_4 = (has_head(v366_3) ? constant_9 : Space{});
        const Space v366_5 = subtract(constant_0,v366_4);
        Space v366_8;
        if (!v366_5.empty()) {
          const Path v367_6 = concat_path(v344_37_head,v365_6_head);
          const Space v367_7 = routine_72(c, v367_6, v365_6_tail);
          v366_8 = compose(v366_5,v367_7);
        }
        const Space v366_9 = intersect(constant_8,v366_2);
        const Space v366_10 = (has_head(v366_9) ? constant_9 : Space{});
        Space v366_12;
        if (!v366_10.empty()) {
          const Path v368_6 = concat_path(v344_37_head,v365_6_head);
          const Space v368_11 = routine_73(c, v368_6, v365_6_tail);
          v366_12 = compose(v366_10,v368_11);
        }
        const Space v366_13 = unite(v366_8,v366_12);
        v365_6_result = unite(v365_6_result,v366_13);
      }
      const Space v365_6 = std::move(v365_6_result);
      v364_7 = compose(v364_5,v365_6);
    }
    const Space v364_8 = intersect(constant_8,v364_2);
    const Space v364_9 = (has_head(v364_8) ? constant_9 : Space{});
    Space v364_11;
    if (!v364_9.empty()) {
      Space v369_10_result;
      for (int v369_10_label = 1; v369_10_label <= 2; ++v369_10_label) {
        const Space v369_10_tail = child(v344_37_tail,v369_10_label);
        if (v369_10_tail.empty()) continue;
        const Path v369_10_head{v369_10_label};
        const Space v370_2 = singleton(v369_10_head);
        const Space v370_3 = intersect(constant_8,v370_2);
        const Space v370_4 = (has_head(v370_3) ? constant_9 : Space{});
        const Space v370_5 = subtract(constant_0,v370_4);
        Space v370_8;
        if (!v370_5.empty()) {
          const Path v371_6 = concat_path(v344_37_head,v369_10_head);
          const Space v371_7 = routine_72(c, v371_6, v369_10_tail);
          v370_8 = compose(v370_5,v371_7);
        }
        const Space v370_9 = intersect(constant_8,v370_2);
        const Space v370_10 = (has_head(v370_9) ? constant_9 : Space{});
        Space v370_12;
        if (!v370_10.empty()) {
          const Path v372_6 = concat_path(v344_37_head,v369_10_head);
          const Space v372_11 = routine_74(c, v372_6, v369_10_tail);
          v370_12 = compose(v370_10,v372_11);
        }
        const Space v370_13 = unite(v370_8,v370_12);
        v369_10_result = unite(v369_10_result,v370_13);
      }
      const Space v369_10 = std::move(v369_10_result);
      v364_11 = compose(v364_9,v369_10);
    }
    const Space v364_12 = unite(v364_7,v364_11);
    v344_37_result = unite(v344_37_result,v364_12);
  }
  const Space v344_37 = std::move(v344_37_result);
  Space v344_48;
  if (!v344_37.empty()) {
    Space v373_47_result;
    for (int v373_47_label = 1; v373_47_label <= 2; ++v373_47_label) {
      const Space v373_47_tail = child(s0,v373_47_label);
      if (v373_47_tail.empty()) continue;
      const Path v373_47_head{v373_47_label};
      const Space v374_2 = singleton(v373_47_head);
      const Space v374_3 = intersect(constant_8,v374_2);
      const Space v374_4 = (has_head(v374_3) ? constant_9 : Space{});
      const Space v374_5 = subtract(constant_0,v374_4);
      Space v374_7;
      if (!v374_5.empty()) {
        Space v375_6_result;
        for (int v375_6_label = 1; v375_6_label <= 2; ++v375_6_label) {
          const Space v375_6_tail = child(v373_47_tail,v375_6_label);
          if (v375_6_tail.empty()) continue;
          const Path v375_6_head{v375_6_label};
          const Space v376_2 = singleton(v375_6_head);
          const Space v376_3 = intersect(constant_8,v376_2);
          const Space v376_4 = (has_head(v376_3) ? constant_9 : Space{});
          const Space v376_5 = subtract(constant_0,v376_4);
          Space v376_8;
          if (!v376_5.empty()) {
            const Path v377_6 = concat_path(v373_47_head,v375_6_head);
            const Space v377_7 = routine_75(c, v377_6, v375_6_tail);
            v376_8 = compose(v376_5,v377_7);
          }
          const Space v376_9 = intersect(constant_8,v376_2);
          const Space v376_10 = (has_head(v376_9) ? constant_9 : Space{});
          Space v376_12;
          if (!v376_10.empty()) {
            const Path v378_6 = concat_path(v373_47_head,v375_6_head);
            const Space v378_11 = routine_76(c, v378_6, v375_6_tail);
            v376_12 = compose(v376_10,v378_11);
          }
          const Space v376_13 = unite(v376_8,v376_12);
          v375_6_result = unite(v375_6_result,v376_13);
        }
        const Space v375_6 = std::move(v375_6_result);
        v374_7 = compose(v374_5,v375_6);
      }
      const Space v374_8 = intersect(constant_8,v374_2);
      const Space v374_9 = (has_head(v374_8) ? constant_9 : Space{});
      Space v374_11;
      if (!v374_9.empty()) {
        Space v379_10_result;
        for (int v379_10_label = 1; v379_10_label <= 2; ++v379_10_label) {
          const Space v379_10_tail = child(v373_47_tail,v379_10_label);
          if (v379_10_tail.empty()) continue;
          const Path v379_10_head{v379_10_label};
          const Space v380_2 = singleton(v379_10_head);
          const Space v380_3 = intersect(constant_8,v380_2);
          const Space v380_4 = (has_head(v380_3) ? constant_9 : Space{});
          const Space v380_5 = subtract(constant_0,v380_4);
          Space v380_8;
          if (!v380_5.empty()) {
            const Path v381_6 = concat_path(v373_47_head,v379_10_head);
            const Space v381_7 = routine_75(c, v381_6, v379_10_tail);
            v380_8 = compose(v380_5,v381_7);
          }
          const Space v380_9 = intersect(constant_8,v380_2);
          const Space v380_10 = (has_head(v380_9) ? constant_9 : Space{});
          Space v380_12;
          if (!v380_10.empty()) {
            const Path v382_6 = concat_path(v373_47_head,v379_10_head);
            const Space v382_11 = routine_77(c, v382_6, v379_10_tail);
            v380_12 = compose(v380_10,v382_11);
          }
          const Space v380_13 = unite(v380_8,v380_12);
          v379_10_result = unite(v379_10_result,v380_13);
        }
        const Space v379_10 = std::move(v379_10_result);
        v374_11 = compose(v374_9,v379_10);
      }
      const Space v374_12 = unite(v374_7,v374_11);
      v373_47_result = unite(v373_47_result,v374_12);
    }
    const Space v373_47 = std::move(v373_47_result);
    v344_48 = compose(v344_37,v373_47);
  }
  const Space v344_49 = unite(v344_25,v344_48);
  const Space v344_51 = intersect(constant_12,v344_3);
  Space v344_61_result;
  for (int v344_61_label = 1; v344_61_label <= 2; ++v344_61_label) {
    const Space v344_61_tail = child(v344_51,v344_61_label);
    if (v344_61_tail.empty()) continue;
    const Path v344_61_head{v344_61_label};
    const Space v383_2 = singleton(v344_61_head);
    const Space v383_3 = intersect(constant_8,v383_2);
    const Space v383_4 = (has_head(v383_3) ? constant_9 : Space{});
    const Space v383_5 = subtract(constant_0,v383_4);
    Space v383_7;
    if (!v383_5.empty()) {
      Space v384_6_result;
      for (int v384_6_label = 1; v384_6_label <= 2; ++v384_6_label) {
        const Space v384_6_tail = child(v344_61_tail,v384_6_label);
        if (v384_6_tail.empty()) continue;
        const Path v384_6_head{v384_6_label};
        const Space v385_2 = singleton(v384_6_head);
        const Space v385_3 = intersect(constant_8,v385_2);
        const Space v385_4 = (has_head(v385_3) ? constant_9 : Space{});
        const Space v385_5 = subtract(constant_0,v385_4);
        Space v385_8;
        if (!v385_5.empty()) {
          const Path v386_6 = concat_path(v344_61_head,v384_6_head);
          const Space v386_7 = routine_78(c, v386_6, v384_6_tail);
          v385_8 = compose(v385_5,v386_7);
        }
        const Space v385_9 = intersect(constant_8,v385_2);
        const Space v385_10 = (has_head(v385_9) ? constant_9 : Space{});
        Space v385_12;
        if (!v385_10.empty()) {
          const Path v387_6 = concat_path(v344_61_head,v384_6_head);
          const Space v387_11 = routine_79(c, v387_6, v384_6_tail);
          v385_12 = compose(v385_10,v387_11);
        }
        const Space v385_13 = unite(v385_8,v385_12);
        v384_6_result = unite(v384_6_result,v385_13);
      }
      const Space v384_6 = std::move(v384_6_result);
      v383_7 = compose(v383_5,v384_6);
    }
    const Space v383_8 = intersect(constant_8,v383_2);
    const Space v383_9 = (has_head(v383_8) ? constant_9 : Space{});
    Space v383_11;
    if (!v383_9.empty()) {
      Space v388_10_result;
      for (int v388_10_label = 1; v388_10_label <= 2; ++v388_10_label) {
        const Space v388_10_tail = child(v344_61_tail,v388_10_label);
        if (v388_10_tail.empty()) continue;
        const Path v388_10_head{v388_10_label};
        const Space v389_2 = singleton(v388_10_head);
        const Space v389_3 = intersect(constant_8,v389_2);
        const Space v389_4 = (has_head(v389_3) ? constant_9 : Space{});
        const Space v389_5 = subtract(constant_0,v389_4);
        Space v389_8;
        if (!v389_5.empty()) {
          const Path v390_6 = concat_path(v344_61_head,v388_10_head);
          const Space v390_7 = routine_78(c, v390_6, v388_10_tail);
          v389_8 = compose(v389_5,v390_7);
        }
        const Space v389_9 = intersect(constant_8,v389_2);
        const Space v389_10 = (has_head(v389_9) ? constant_9 : Space{});
        Space v389_12;
        if (!v389_10.empty()) {
          const Path v391_6 = concat_path(v344_61_head,v388_10_head);
          const Space v391_11 = routine_80(c, v391_6, v388_10_tail);
          v389_12 = compose(v389_10,v391_11);
        }
        const Space v389_13 = unite(v389_8,v389_12);
        v388_10_result = unite(v388_10_result,v389_13);
      }
      const Space v388_10 = std::move(v388_10_result);
      v383_11 = compose(v383_9,v388_10);
    }
    const Space v383_12 = unite(v383_7,v383_11);
    v344_61_result = unite(v344_61_result,v383_12);
  }
  const Space v344_61 = std::move(v344_61_result);
  Space v344_72;
  if (!v344_61.empty()) {
    Space v392_71_result;
    for (int v392_71_label = 1; v392_71_label <= 2; ++v392_71_label) {
      const Space v392_71_tail = child(s0,v392_71_label);
      if (v392_71_tail.empty()) continue;
      const Path v392_71_head{v392_71_label};
      const Space v393_2 = singleton(v392_71_head);
      const Space v393_3 = intersect(constant_8,v393_2);
      const Space v393_4 = (has_head(v393_3) ? constant_9 : Space{});
      const Space v393_5 = subtract(constant_0,v393_4);
      Space v393_7;
      if (!v393_5.empty()) {
        Space v394_6_result;
        for (int v394_6_label = 1; v394_6_label <= 2; ++v394_6_label) {
          const Space v394_6_tail = child(v392_71_tail,v394_6_label);
          if (v394_6_tail.empty()) continue;
          const Path v394_6_head{v394_6_label};
          const Space v395_2 = singleton(v394_6_head);
          const Space v395_3 = intersect(constant_8,v395_2);
          const Space v395_4 = (has_head(v395_3) ? constant_9 : Space{});
          const Space v395_5 = subtract(constant_0,v395_4);
          Space v395_8;
          if (!v395_5.empty()) {
            const Path v396_6 = concat_path(v392_71_head,v394_6_head);
            const Space v396_7 = routine_81(c, v396_6, v394_6_tail);
            v395_8 = compose(v395_5,v396_7);
          }
          const Space v395_9 = intersect(constant_8,v395_2);
          const Space v395_10 = (has_head(v395_9) ? constant_9 : Space{});
          Space v395_12;
          if (!v395_10.empty()) {
            const Path v397_6 = concat_path(v392_71_head,v394_6_head);
            const Space v397_11 = routine_82(c, v397_6, v394_6_tail);
            v395_12 = compose(v395_10,v397_11);
          }
          const Space v395_13 = unite(v395_8,v395_12);
          v394_6_result = unite(v394_6_result,v395_13);
        }
        const Space v394_6 = std::move(v394_6_result);
        v393_7 = compose(v393_5,v394_6);
      }
      const Space v393_8 = intersect(constant_8,v393_2);
      const Space v393_9 = (has_head(v393_8) ? constant_9 : Space{});
      Space v393_11;
      if (!v393_9.empty()) {
        Space v398_10_result;
        for (int v398_10_label = 1; v398_10_label <= 2; ++v398_10_label) {
          const Space v398_10_tail = child(v392_71_tail,v398_10_label);
          if (v398_10_tail.empty()) continue;
          const Path v398_10_head{v398_10_label};
          const Space v399_2 = singleton(v398_10_head);
          const Space v399_3 = intersect(constant_8,v399_2);
          const Space v399_4 = (has_head(v399_3) ? constant_9 : Space{});
          const Space v399_5 = subtract(constant_0,v399_4);
          Space v399_8;
          if (!v399_5.empty()) {
            const Path v400_6 = concat_path(v392_71_head,v398_10_head);
            const Space v400_7 = routine_81(c, v400_6, v398_10_tail);
            v399_8 = compose(v399_5,v400_7);
          }
          const Space v399_9 = intersect(constant_8,v399_2);
          const Space v399_10 = (has_head(v399_9) ? constant_9 : Space{});
          Space v399_12;
          if (!v399_10.empty()) {
            const Path v401_6 = concat_path(v392_71_head,v398_10_head);
            const Space v401_11 = routine_83(c, v401_6, v398_10_tail);
            v399_12 = compose(v399_10,v401_11);
          }
          const Space v399_13 = unite(v399_8,v399_12);
          v398_10_result = unite(v398_10_result,v399_13);
        }
        const Space v398_10 = std::move(v398_10_result);
        v393_11 = compose(v393_9,v398_10);
      }
      const Space v393_12 = unite(v393_7,v393_11);
      v392_71_result = unite(v392_71_result,v393_12);
    }
    const Space v392_71 = std::move(v392_71_result);
    v344_72 = compose(v344_61,v392_71);
  }
  const Space v344_73 = unite(v344_49,v344_72);
  const Space v344_75 = intersect(constant_13,v344_3);
  Space v344_85_result;
  for (int v344_85_label = 1; v344_85_label <= 2; ++v344_85_label) {
    const Space v344_85_tail = child(v344_75,v344_85_label);
    if (v344_85_tail.empty()) continue;
    const Path v344_85_head{v344_85_label};
    const Space v402_2 = singleton(v344_85_head);
    const Space v402_3 = intersect(constant_8,v402_2);
    const Space v402_4 = (has_head(v402_3) ? constant_9 : Space{});
    const Space v402_5 = subtract(constant_0,v402_4);
    Space v402_7;
    if (!v402_5.empty()) {
      Space v403_6_result;
      for (int v403_6_label = 1; v403_6_label <= 2; ++v403_6_label) {
        const Space v403_6_tail = child(v344_85_tail,v403_6_label);
        if (v403_6_tail.empty()) continue;
        const Path v403_6_head{v403_6_label};
        const Space v404_2 = singleton(v403_6_head);
        const Space v404_3 = intersect(constant_8,v404_2);
        const Space v404_4 = (has_head(v404_3) ? constant_9 : Space{});
        const Space v404_5 = subtract(constant_0,v404_4);
        Space v404_8;
        if (!v404_5.empty()) {
          const Path v405_6 = concat_path(v344_85_head,v403_6_head);
          const Space v405_7 = routine_84(c, v405_6, v403_6_tail);
          v404_8 = compose(v404_5,v405_7);
        }
        const Space v404_9 = intersect(constant_8,v404_2);
        const Space v404_10 = (has_head(v404_9) ? constant_9 : Space{});
        Space v404_12;
        if (!v404_10.empty()) {
          const Path v406_6 = concat_path(v344_85_head,v403_6_head);
          const Space v406_11 = routine_85(c, v406_6, v403_6_tail);
          v404_12 = compose(v404_10,v406_11);
        }
        const Space v404_13 = unite(v404_8,v404_12);
        v403_6_result = unite(v403_6_result,v404_13);
      }
      const Space v403_6 = std::move(v403_6_result);
      v402_7 = compose(v402_5,v403_6);
    }
    const Space v402_8 = intersect(constant_8,v402_2);
    const Space v402_9 = (has_head(v402_8) ? constant_9 : Space{});
    Space v402_11;
    if (!v402_9.empty()) {
      Space v407_10_result;
      for (int v407_10_label = 1; v407_10_label <= 2; ++v407_10_label) {
        const Space v407_10_tail = child(v344_85_tail,v407_10_label);
        if (v407_10_tail.empty()) continue;
        const Path v407_10_head{v407_10_label};
        const Space v408_2 = singleton(v407_10_head);
        const Space v408_3 = intersect(constant_8,v408_2);
        const Space v408_4 = (has_head(v408_3) ? constant_9 : Space{});
        const Space v408_5 = subtract(constant_0,v408_4);
        Space v408_8;
        if (!v408_5.empty()) {
          const Path v409_6 = concat_path(v344_85_head,v407_10_head);
          const Space v409_7 = routine_84(c, v409_6, v407_10_tail);
          v408_8 = compose(v408_5,v409_7);
        }
        const Space v408_9 = intersect(constant_8,v408_2);
        const Space v408_10 = (has_head(v408_9) ? constant_9 : Space{});
        Space v408_12;
        if (!v408_10.empty()) {
          const Path v410_6 = concat_path(v344_85_head,v407_10_head);
          const Space v410_11 = routine_86(c, v410_6, v407_10_tail);
          v408_12 = compose(v408_10,v410_11);
        }
        const Space v408_13 = unite(v408_8,v408_12);
        v407_10_result = unite(v407_10_result,v408_13);
      }
      const Space v407_10 = std::move(v407_10_result);
      v402_11 = compose(v402_9,v407_10);
    }
    const Space v402_12 = unite(v402_7,v402_11);
    v344_85_result = unite(v344_85_result,v402_12);
  }
  const Space v344_85 = std::move(v344_85_result);
  Space v344_96;
  if (!v344_85.empty()) {
    Space v411_95_result;
    for (int v411_95_label = 1; v411_95_label <= 2; ++v411_95_label) {
      const Space v411_95_tail = child(s0,v411_95_label);
      if (v411_95_tail.empty()) continue;
      const Path v411_95_head{v411_95_label};
      const Space v412_2 = singleton(v411_95_head);
      const Space v412_3 = intersect(constant_8,v412_2);
      const Space v412_4 = (has_head(v412_3) ? constant_9 : Space{});
      const Space v412_5 = subtract(constant_0,v412_4);
      Space v412_7;
      if (!v412_5.empty()) {
        Space v413_6_result;
        for (int v413_6_label = 1; v413_6_label <= 2; ++v413_6_label) {
          const Space v413_6_tail = child(v411_95_tail,v413_6_label);
          if (v413_6_tail.empty()) continue;
          const Path v413_6_head{v413_6_label};
          const Space v414_2 = singleton(v413_6_head);
          const Space v414_3 = intersect(constant_8,v414_2);
          const Space v414_4 = (has_head(v414_3) ? constant_9 : Space{});
          const Space v414_5 = subtract(constant_0,v414_4);
          Space v414_8;
          if (!v414_5.empty()) {
            const Path v415_6 = concat_path(v411_95_head,v413_6_head);
            const Space v415_7 = routine_87(c, v415_6, v413_6_tail);
            v414_8 = compose(v414_5,v415_7);
          }
          const Space v414_9 = intersect(constant_8,v414_2);
          const Space v414_10 = (has_head(v414_9) ? constant_9 : Space{});
          Space v414_12;
          if (!v414_10.empty()) {
            const Path v416_6 = concat_path(v411_95_head,v413_6_head);
            const Space v416_11 = routine_88(c, v416_6, v413_6_tail);
            v414_12 = compose(v414_10,v416_11);
          }
          const Space v414_13 = unite(v414_8,v414_12);
          v413_6_result = unite(v413_6_result,v414_13);
        }
        const Space v413_6 = std::move(v413_6_result);
        v412_7 = compose(v412_5,v413_6);
      }
      const Space v412_8 = intersect(constant_8,v412_2);
      const Space v412_9 = (has_head(v412_8) ? constant_9 : Space{});
      Space v412_11;
      if (!v412_9.empty()) {
        Space v417_10_result;
        for (int v417_10_label = 1; v417_10_label <= 2; ++v417_10_label) {
          const Space v417_10_tail = child(v411_95_tail,v417_10_label);
          if (v417_10_tail.empty()) continue;
          const Path v417_10_head{v417_10_label};
          const Space v418_2 = singleton(v417_10_head);
          const Space v418_3 = intersect(constant_8,v418_2);
          const Space v418_4 = (has_head(v418_3) ? constant_9 : Space{});
          const Space v418_5 = subtract(constant_0,v418_4);
          Space v418_8;
          if (!v418_5.empty()) {
            const Path v419_6 = concat_path(v411_95_head,v417_10_head);
            const Space v419_7 = routine_87(c, v419_6, v417_10_tail);
            v418_8 = compose(v418_5,v419_7);
          }
          const Space v418_9 = intersect(constant_8,v418_2);
          const Space v418_10 = (has_head(v418_9) ? constant_9 : Space{});
          Space v418_12;
          if (!v418_10.empty()) {
            const Path v420_6 = concat_path(v411_95_head,v417_10_head);
            const Space v420_11 = routine_89(c, v420_6, v417_10_tail);
            v418_12 = compose(v418_10,v420_11);
          }
          const Space v418_13 = unite(v418_8,v418_12);
          v417_10_result = unite(v417_10_result,v418_13);
        }
        const Space v417_10 = std::move(v417_10_result);
        v412_11 = compose(v412_9,v417_10);
      }
      const Space v412_12 = unite(v412_7,v412_11);
      v411_95_result = unite(v411_95_result,v412_12);
    }
    const Space v411_95 = std::move(v411_95_result);
    v344_96 = compose(v344_85,v411_95);
  }
  const Space v344_97 = unite(v344_73,v344_96);
  return v344_97;
}

static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v421_12_result;
  for (int v421_12_label = 1; v421_12_label <= 2; ++v421_12_label) {
    const Space v421_12_tail = child(s0,v421_12_label);
    if (v421_12_tail.empty()) continue;
    const Path v421_12_head{v421_12_label};
    const Space v422_2 = singleton(v421_12_head);
    const Space v422_3 = intersect(constant_8,v422_2);
    const Space v422_4 = (has_head(v422_3) ? constant_9 : Space{});
    const Space v422_5 = subtract(constant_0,v422_4);
    Space v422_8;
    if (!v422_5.empty()) {
      const Path v423_6 = concat_path(p0,v421_12_head);
      Space v423_7_result;
      for (int v423_7_label = 1; v423_7_label <= 2; ++v423_7_label) {
        const Space v423_7_tail = child(v421_12_tail,v423_7_label);
        if (v423_7_tail.empty()) continue;
        const Path v423_7_head{v423_7_label};
        const Space v424_2 = singleton(v423_7_head);
        const Space v424_3 = intersect(constant_8,v424_2);
        const Space v424_4 = (has_head(v424_3) ? constant_9 : Space{});
        const Space v424_5 = subtract(constant_0,v424_4);
        Space v424_8;
        if (!v424_5.empty()) {
          const Path v425_6 = concat_path(v423_6,v423_7_head);
          const Space v425_7 = routine_90(c, v425_6, p1, v423_7_tail);
          v424_8 = compose(v424_5,v425_7);
        }
        const Space v424_9 = intersect(constant_8,v424_2);
        const Space v424_10 = (has_head(v424_9) ? constant_9 : Space{});
        Space v424_12;
        if (!v424_10.empty()) {
          const Path v426_6 = concat_path(v423_6,v423_7_head);
          const Space v426_11 = routine_91(c, v426_6, p1, v423_7_tail);
          v424_12 = compose(v424_10,v426_11);
        }
        const Space v424_13 = unite(v424_8,v424_12);
        v423_7_result = unite(v423_7_result,v424_13);
      }
      const Space v423_7 = std::move(v423_7_result);
      v422_8 = compose(v422_5,v423_7);
    }
    const Space v422_9 = intersect(constant_8,v422_2);
    const Space v422_10 = (has_head(v422_9) ? constant_9 : Space{});
    Space v422_12;
    if (!v422_10.empty()) {
      const Path v427_6 = concat_path(p0,v421_12_head);
      Space v427_11_result;
      for (int v427_11_label = 1; v427_11_label <= 2; ++v427_11_label) {
        const Space v427_11_tail = child(v421_12_tail,v427_11_label);
        if (v427_11_tail.empty()) continue;
        const Path v427_11_head{v427_11_label};
        const Space v428_2 = singleton(v427_11_head);
        const Space v428_3 = intersect(constant_8,v428_2);
        const Space v428_4 = (has_head(v428_3) ? constant_9 : Space{});
        const Space v428_5 = subtract(constant_0,v428_4);
        Space v428_8;
        if (!v428_5.empty()) {
          const Path v429_6 = concat_path(v427_6,v427_11_head);
          const Space v429_7 = routine_90(c, v429_6, p1, v427_11_tail);
          v428_8 = compose(v428_5,v429_7);
        }
        const Space v428_9 = intersect(constant_8,v428_2);
        const Space v428_10 = (has_head(v428_9) ? constant_9 : Space{});
        Space v428_12;
        if (!v428_10.empty()) {
          const Path v430_6 = concat_path(v427_6,v427_11_head);
          const Space v430_11 = routine_60(c, v430_6, p1, v427_11_tail);
          v428_12 = compose(v428_10,v430_11);
        }
        const Space v428_13 = unite(v428_8,v428_12);
        v427_11_result = unite(v427_11_result,v428_13);
      }
      const Space v427_11 = std::move(v427_11_result);
      v422_12 = compose(v422_10,v427_11);
    }
    const Space v422_13 = unite(v422_8,v422_12);
    v421_12_result = unite(v421_12_result,v422_13);
  }
  const Space v421_12 = std::move(v421_12_result);
  return v421_12;
}

static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v431_17_result;
  for (int v431_17_label = 1; v431_17_label <= 2; ++v431_17_label) {
    const Space v431_17_tail = child(s0,v431_17_label);
    if (v431_17_tail.empty()) continue;
    const Path v431_17_head{v431_17_label};
    const Space v432_2 = singleton(v431_17_head);
    const Space v432_3 = intersect(constant_8,v432_2);
    const Space v432_4 = (has_head(v432_3) ? constant_9 : Space{});
    const Space v432_5 = subtract(constant_0,v432_4);
    Space v432_8;
    if (!v432_5.empty()) {
      const Path v433_6 = concat_path(p0,v431_17_head);
      Space v433_7_result;
      for (int v433_7_label = 1; v433_7_label <= 2; ++v433_7_label) {
        const Space v433_7_tail = child(v431_17_tail,v433_7_label);
        if (v433_7_tail.empty()) continue;
        const Path v433_7_head{v433_7_label};
        const Space v434_2 = singleton(v433_7_head);
        const Space v434_3 = intersect(constant_8,v434_2);
        const Space v434_4 = (has_head(v434_3) ? constant_9 : Space{});
        const Space v434_5 = subtract(constant_0,v434_4);
        Space v434_8;
        if (!v434_5.empty()) {
          const Path v435_6 = concat_path(v433_6,v433_7_head);
          const Space v435_7 = routine_90(c, v435_6, p1, v433_7_tail);
          v434_8 = compose(v434_5,v435_7);
        }
        const Space v434_9 = intersect(constant_8,v434_2);
        const Space v434_10 = (has_head(v434_9) ? constant_9 : Space{});
        Space v434_12;
        if (!v434_10.empty()) {
          const Path v436_6 = concat_path(v433_6,v433_7_head);
          const Space v436_11 = routine_91(c, v436_6, p1, v433_7_tail);
          v434_12 = compose(v434_10,v436_11);
        }
        const Space v434_13 = unite(v434_8,v434_12);
        v433_7_result = unite(v433_7_result,v434_13);
      }
      const Space v433_7 = std::move(v433_7_result);
      v432_8 = compose(v432_5,v433_7);
    }
    const Space v432_9 = intersect(constant_8,v432_2);
    const Space v432_10 = (has_head(v432_9) ? constant_9 : Space{});
    Space v432_17;
    if (!v432_10.empty()) {
      const Path v437_6 = concat_path(p0,v431_17_head);
      Space v437_14;
      if (!constant_0.empty()) {
        const Space v438_11 = routine_92(c, constant_14, constant_15);
        const Space v438_12 = routine_93(c, constant_16, constant_17);
        const Space v438_13 = unite(v438_11,v438_12);
        v437_14 = compose(constant_0,v438_13);
      }
      const Space v437_15 = unwrap(v437_14,p1);
      Space v437_16_result;
      for (int v437_16_label = 1; v437_16_label <= 2; ++v437_16_label) {
        const Space v437_16_tail = child(v437_15,v437_16_label);
        if (v437_16_tail.empty()) continue;
        const Path v437_16_head{v437_16_label};
        const Space v439_2 = singleton(v437_16_head);
        const Space v439_3 = intersect(constant_8,v439_2);
        const Space v439_4 = (has_head(v439_3) ? constant_9 : Space{});
        const Space v439_5 = subtract(constant_0,v439_4);
        Space v439_7;
        if (!v439_5.empty()) {
          const Space v440_6 = routine_94(c, v437_16_head, v437_6, v437_16_tail, v431_17_tail);
          v439_7 = compose(v439_5,v440_6);
        }
        const Space v439_8 = intersect(constant_8,v439_2);
        const Space v439_9 = (has_head(v439_8) ? constant_9 : Space{});
        Space v439_11;
        if (!v439_9.empty()) {
          const Space v441_10 = routine_95(c, v437_16_head, v437_6, v437_16_tail, v431_17_tail);
          v439_11 = compose(v439_9,v441_10);
        }
        const Space v439_12 = unite(v439_7,v439_11);
        v437_16_result = unite(v437_16_result,v439_12);
      }
      const Space v437_16 = std::move(v437_16_result);
      v432_17 = compose(v432_10,v437_16);
    }
    const Space v432_18 = unite(v432_8,v432_17);
    v431_17_result = unite(v431_17_result,v432_18);
  }
  const Space v431_17 = std::move(v431_17_result);
  return v431_17;
}

static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v442_12_result;
  for (int v442_12_label = 1; v442_12_label <= 2; ++v442_12_label) {
    const Space v442_12_tail = child(s0,v442_12_label);
    if (v442_12_tail.empty()) continue;
    const Path v442_12_head{v442_12_label};
    const Space v443_2 = singleton(v442_12_head);
    const Space v443_3 = intersect(constant_8,v443_2);
    const Space v443_4 = (has_head(v443_3) ? constant_9 : Space{});
    const Space v443_5 = subtract(constant_0,v443_4);
    Space v443_8;
    if (!v443_5.empty()) {
      const Path v444_6 = concat_path(p0,v442_12_head);
      Space v444_7_result;
      for (int v444_7_label = 1; v444_7_label <= 2; ++v444_7_label) {
        const Space v444_7_tail = child(v442_12_tail,v444_7_label);
        if (v444_7_tail.empty()) continue;
        const Path v444_7_head{v444_7_label};
        const Space v445_2 = singleton(v444_7_head);
        const Space v445_3 = intersect(constant_8,v445_2);
        const Space v445_4 = (has_head(v445_3) ? constant_9 : Space{});
        const Space v445_5 = subtract(constant_0,v445_4);
        Space v445_8;
        if (!v445_5.empty()) {
          const Path v446_6 = concat_path(v444_6,v444_7_head);
          const Space v446_7 = routine_96(c, v446_6, p1, v444_7_tail);
          v445_8 = compose(v445_5,v446_7);
        }
        const Space v445_9 = intersect(constant_8,v445_2);
        const Space v445_10 = (has_head(v445_9) ? constant_9 : Space{});
        Space v445_12;
        if (!v445_10.empty()) {
          const Path v447_6 = concat_path(v444_6,v444_7_head);
          const Space v447_11 = routine_97(c, v447_6, p1, v444_7_tail);
          v445_12 = compose(v445_10,v447_11);
        }
        const Space v445_13 = unite(v445_8,v445_12);
        v444_7_result = unite(v444_7_result,v445_13);
      }
      const Space v444_7 = std::move(v444_7_result);
      v443_8 = compose(v443_5,v444_7);
    }
    const Space v443_9 = intersect(constant_8,v443_2);
    const Space v443_10 = (has_head(v443_9) ? constant_9 : Space{});
    Space v443_12;
    if (!v443_10.empty()) {
      const Path v448_6 = concat_path(p0,v442_12_head);
      Space v448_11_result;
      for (int v448_11_label = 1; v448_11_label <= 2; ++v448_11_label) {
        const Space v448_11_tail = child(v442_12_tail,v448_11_label);
        if (v448_11_tail.empty()) continue;
        const Path v448_11_head{v448_11_label};
        const Space v449_2 = singleton(v448_11_head);
        const Space v449_3 = intersect(constant_8,v449_2);
        const Space v449_4 = (has_head(v449_3) ? constant_9 : Space{});
        const Space v449_5 = subtract(constant_0,v449_4);
        Space v449_8;
        if (!v449_5.empty()) {
          const Path v450_6 = concat_path(v448_6,v448_11_head);
          const Space v450_7 = routine_96(c, v450_6, p1, v448_11_tail);
          v449_8 = compose(v449_5,v450_7);
        }
        const Space v449_9 = intersect(constant_8,v449_2);
        const Space v449_10 = (has_head(v449_9) ? constant_9 : Space{});
        Space v449_12;
        if (!v449_10.empty()) {
          const Path v451_6 = concat_path(v448_6,v448_11_head);
          const Space v451_11 = routine_63(c, v451_6, p1, v448_11_tail);
          v449_12 = compose(v449_10,v451_11);
        }
        const Space v449_13 = unite(v449_8,v449_12);
        v448_11_result = unite(v448_11_result,v449_13);
      }
      const Space v448_11 = std::move(v448_11_result);
      v443_12 = compose(v443_10,v448_11);
    }
    const Space v443_13 = unite(v443_8,v443_12);
    v442_12_result = unite(v442_12_result,v443_13);
  }
  const Space v442_12 = std::move(v442_12_result);
  return v442_12;
}

static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v452_17_result;
  for (int v452_17_label = 1; v452_17_label <= 2; ++v452_17_label) {
    const Space v452_17_tail = child(s0,v452_17_label);
    if (v452_17_tail.empty()) continue;
    const Path v452_17_head{v452_17_label};
    const Space v453_2 = singleton(v452_17_head);
    const Space v453_3 = intersect(constant_8,v453_2);
    const Space v453_4 = (has_head(v453_3) ? constant_9 : Space{});
    const Space v453_5 = subtract(constant_0,v453_4);
    Space v453_8;
    if (!v453_5.empty()) {
      const Path v454_6 = concat_path(p0,v452_17_head);
      Space v454_7_result;
      for (int v454_7_label = 1; v454_7_label <= 2; ++v454_7_label) {
        const Space v454_7_tail = child(v452_17_tail,v454_7_label);
        if (v454_7_tail.empty()) continue;
        const Path v454_7_head{v454_7_label};
        const Space v455_2 = singleton(v454_7_head);
        const Space v455_3 = intersect(constant_8,v455_2);
        const Space v455_4 = (has_head(v455_3) ? constant_9 : Space{});
        const Space v455_5 = subtract(constant_0,v455_4);
        Space v455_8;
        if (!v455_5.empty()) {
          const Path v456_6 = concat_path(v454_6,v454_7_head);
          const Space v456_7 = routine_96(c, v456_6, p1, v454_7_tail);
          v455_8 = compose(v455_5,v456_7);
        }
        const Space v455_9 = intersect(constant_8,v455_2);
        const Space v455_10 = (has_head(v455_9) ? constant_9 : Space{});
        Space v455_12;
        if (!v455_10.empty()) {
          const Path v457_6 = concat_path(v454_6,v454_7_head);
          const Space v457_11 = routine_97(c, v457_6, p1, v454_7_tail);
          v455_12 = compose(v455_10,v457_11);
        }
        const Space v455_13 = unite(v455_8,v455_12);
        v454_7_result = unite(v454_7_result,v455_13);
      }
      const Space v454_7 = std::move(v454_7_result);
      v453_8 = compose(v453_5,v454_7);
    }
    const Space v453_9 = intersect(constant_8,v453_2);
    const Space v453_10 = (has_head(v453_9) ? constant_9 : Space{});
    Space v453_20;
    if (!v453_10.empty()) {
      Space v458_14;
      if (!constant_0.empty()) {
        const Space v459_11 = routine_98(c, constant_14, constant_15);
        const Space v459_12 = routine_99(c, constant_16, constant_17);
        const Space v459_13 = unite(v459_11,v459_12);
        v458_14 = compose(constant_0,v459_13);
      }
      const Space v458_15 = unwrap(v458_14,p1);
      const Space v458_16 = unwrap(v458_15,p0);
      const Space v458_17 = unwrap(v458_16,v452_17_head);
      const Space v458_18 = unwrap(v458_17,p1);
      Space v458_19_result;
      for (int v458_19_label = 1; v458_19_label <= 2; ++v458_19_label) {
        const Space v458_19_tail = child(v458_18,v458_19_label);
        if (v458_19_tail.empty()) continue;
        const Path v458_19_head{v458_19_label};
        const Space v460_2 = singleton(v458_19_head);
        const Space v460_3 = intersect(constant_8,v460_2);
        const Space v460_4 = (has_head(v460_3) ? constant_9 : Space{});
        const Space v460_5 = subtract(constant_0,v460_4);
        Space v460_7;
        if (!v460_5.empty()) {
          const Space v461_6 = routine_100(c, v458_19_head, v458_19_tail, v452_17_tail);
          v460_7 = compose(v460_5,v461_6);
        }
        const Space v460_8 = intersect(constant_8,v460_2);
        const Space v460_9 = (has_head(v460_8) ? constant_9 : Space{});
        Space v460_11;
        if (!v460_9.empty()) {
          const Space v462_10 = routine_101(c, v458_19_head, v458_19_tail, v452_17_tail);
          v460_11 = compose(v460_9,v462_10);
        }
        const Space v460_12 = unite(v460_7,v460_11);
        v458_19_result = unite(v458_19_result,v460_12);
      }
      const Space v458_19 = std::move(v458_19_result);
      v453_20 = compose(v453_10,v458_19);
    }
    const Space v453_21 = unite(v453_8,v453_20);
    v452_17_result = unite(v452_17_result,v453_21);
  }
  const Space v452_17 = std::move(v452_17_result);
  return v452_17;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v463_9_result;
  for (int v463_9_label = 1; v463_9_label <= 2; ++v463_9_label) {
    const Space v463_9_tail = child(s0,v463_9_label);
    if (v463_9_tail.empty()) continue;
    const Path v463_9_head{v463_9_label};
    const Space v464_2 = singleton(v463_9_head);
    const Space v464_3 = intersect(constant_8,v464_2);
    const Space v464_4 = (has_head(v464_3) ? constant_9 : Space{});
    const Space v464_5 = subtract(constant_0,v464_4);
    Space v464_6_result;
    for (int v464_6_label = 1; v464_6_label <= 2; ++v464_6_label) {
      const Space v464_6_tail = child(v463_9_tail,v464_6_label);
      if (v464_6_tail.empty()) continue;
      const Path v464_6_head{v464_6_label};
      const Space v465_2 = Space{};
      v464_6_result = unite(v464_6_result,v465_2);
    }
    const Space v464_6 = std::move(v464_6_result);
    const Space v464_7 = compose(v464_5,v464_6);
    const Space v464_8 = intersect(constant_8,v464_2);
    const Space v464_9 = (has_head(v464_8) ? constant_9 : Space{});
    Space v464_12;
    if (!v464_9.empty()) {
      const Path v466_10 = concat_path(p0,v463_9_head);
      Space v466_11_result;
      for (int v466_11_label = 1; v466_11_label <= 2; ++v466_11_label) {
        const Space v466_11_tail = child(v463_9_tail,v466_11_label);
        if (v466_11_tail.empty()) continue;
        const Path v466_11_head{v466_11_label};
        const Space v467_2 = singleton(v466_11_head);
        const Space v467_3 = intersect(constant_8,v467_2);
        const Space v467_4 = (has_head(v467_3) ? constant_9 : Space{});
        Space v467_7;
        if (!v467_4.empty()) {
          const Path v468_5 = concat_path(v466_10,v466_11_head);
          const Space v468_6 = routine_30(c, v468_5, p1, p2, p3, v466_11_tail);
          v467_7 = compose(v467_4,v468_6);
        }
        v466_11_result = unite(v466_11_result,v467_7);
      }
      const Space v466_11 = std::move(v466_11_result);
      v464_12 = compose(v464_9,v466_11);
    }
    const Space v464_13 = unite(v464_7,v464_12);
    v463_9_result = unite(v463_9_result,v464_13);
  }
  const Space v463_9 = std::move(v463_9_result);
  return v463_9;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Path v469_8 = concat_path(p2,p3);
  Space v469_15_result;
  for (int v469_15_label = 1; v469_15_label <= 2; ++v469_15_label) {
    const Space v469_15_tail = child(s0,v469_15_label);
    if (v469_15_tail.empty()) continue;
    const Path v469_15_head{v469_15_label};
    const Space v470_2 = singleton(v469_15_head);
    const Space v470_3 = intersect(constant_8,v470_2);
    const Space v470_4 = (has_head(v470_3) ? constant_9 : Space{});
    const Space v470_5 = subtract(constant_0,v470_4);
    Space v470_6_result;
    for (int v470_6_label = 1; v470_6_label <= 2; ++v470_6_label) {
      const Space v470_6_tail = child(v469_15_tail,v470_6_label);
      if (v470_6_tail.empty()) continue;
      const Path v470_6_head{v470_6_label};
      const Space v471_2 = Space{};
      v470_6_result = unite(v470_6_result,v471_2);
    }
    const Space v470_6 = std::move(v470_6_result);
    const Space v470_7 = compose(v470_5,v470_6);
    const Space v470_8 = intersect(constant_8,v470_2);
    const Space v470_9 = (has_head(v470_8) ? constant_9 : Space{});
    Space v470_16;
    if (!v470_9.empty()) {
      const Path v472_10 = concat_path(p0,v469_15_head);
      const Path v472_11 = concat_path(v469_8,v472_10);
      const Space v472_12 = singleton(v472_11);
      const Space v472_13 = routine_35(c, p1, v472_12);
      Space v472_14_result;
      for (int v472_14_label = 1; v472_14_label <= 2; ++v472_14_label) {
        const Space v472_14_tail = child(v472_13,v472_14_label);
        if (v472_14_tail.empty()) continue;
        const Path v472_14_head{v472_14_label};
        const Space v473_2 = singleton(v472_14_head);
        const Space v473_3 = intersect(constant_8,v473_2);
        const Space v473_4 = (has_head(v473_3) ? constant_9 : Space{});
        const Space v473_5 = subtract(constant_0,v473_4);
        Space v473_7;
        if (!v473_5.empty()) {
          const Space v474_6 = routine_36(c, v472_14_head, p1, v472_14_tail);
          v473_7 = compose(v473_5,v474_6);
        }
        const Space v473_8 = intersect(constant_8,v473_2);
        const Space v473_9 = (has_head(v473_8) ? constant_9 : Space{});
        Space v473_11;
        if (!v473_9.empty()) {
          const Space v475_10 = routine_37(c, v472_14_head, p1, v472_14_tail);
          v473_11 = compose(v473_9,v475_10);
        }
        const Space v473_12 = unite(v473_7,v473_11);
        v472_14_result = unite(v472_14_result,v473_12);
      }
      const Space v472_14 = std::move(v472_14_result);
      Space v472_15_result;
      for (int v472_15_label = 1; v472_15_label <= 2; ++v472_15_label) {
        const Space v472_15_tail = child(v472_14,v472_15_label);
        if (v472_15_tail.empty()) continue;
        const Path v472_15_head{v472_15_label};
        const Space v476_2 = singleton(v472_15_head);
        const Space v476_3 = intersect(constant_8,v476_2);
        const Space v476_4 = (has_head(v476_3) ? constant_9 : Space{});
        const Space v476_5 = subtract(constant_0,v476_4);
        Space v476_7;
        if (!v476_5.empty()) {
          const Space v477_6 = routine_38(c, v472_15_head, p1, v472_15_tail);
          v476_7 = compose(v476_5,v477_6);
        }
        const Space v476_8 = intersect(constant_8,v476_2);
        const Space v476_9 = (has_head(v476_8) ? constant_9 : Space{});
        Space v476_11;
        if (!v476_9.empty()) {
          const Space v478_10 = routine_39(c, v472_15_head, p1, v472_15_tail);
          v476_11 = compose(v476_9,v478_10);
        }
        const Space v476_12 = unite(v476_7,v476_11);
        v472_15_result = unite(v472_15_result,v476_12);
      }
      const Space v472_15 = std::move(v472_15_result);
      v470_16 = compose(v470_9,v472_15);
    }
    const Space v470_17 = unite(v470_7,v470_16);
    v469_15_result = unite(v469_15_result,v470_17);
  }
  const Space v469_15 = std::move(v469_15_result);
  return v469_15;
}

static Space routine_42(Context& c, const Path& p0, const Space& s0) {
  Space v479_11_result;
  for (int v479_11_label = 1; v479_11_label <= 2; ++v479_11_label) {
    const Space v479_11_tail = child(s0,v479_11_label);
    if (v479_11_tail.empty()) continue;
    const Path v479_11_head{v479_11_label};
    const Space v480_2 = singleton(v479_11_head);
    const Space v480_3 = intersect(constant_8,v480_2);
    const Space v480_4 = (has_head(v480_3) ? constant_9 : Space{});
    const Space v480_5 = subtract(constant_0,v480_4);
    Space v480_8;
    if (!v480_5.empty()) {
      const Path v481_6 = concat_path(p0,v479_11_head);
      Space v481_7_result;
      for (int v481_7_label = 1; v481_7_label <= 2; ++v481_7_label) {
        const Space v481_7_tail = child(v479_11_tail,v481_7_label);
        if (v481_7_tail.empty()) continue;
        const Path v481_7_head{v481_7_label};
        const Space v482_2 = singleton(v481_7_head);
        const Space v482_3 = intersect(constant_8,v482_2);
        const Space v482_4 = (has_head(v482_3) ? constant_9 : Space{});
        const Space v482_5 = subtract(constant_0,v482_4);
        Space v482_8;
        if (!v482_5.empty()) {
          const Path v483_6 = concat_path(v481_6,v481_7_head);
          const Space v483_7 = routine_102(c, v483_6, v481_7_tail);
          v482_8 = compose(v482_5,v483_7);
        }
        const Space v482_9 = intersect(constant_8,v482_2);
        const Space v482_10 = (has_head(v482_9) ? constant_9 : Space{});
        Space v482_12;
        if (!v482_10.empty()) {
          const Path v484_6 = concat_path(v481_6,v481_7_head);
          const Space v484_11 = routine_103(c, v484_6, v481_7_tail);
          v482_12 = compose(v482_10,v484_11);
        }
        const Space v482_13 = unite(v482_8,v482_12);
        v481_7_result = unite(v481_7_result,v482_13);
      }
      const Space v481_7 = std::move(v481_7_result);
      v480_8 = compose(v480_5,v481_7);
    }
    const Space v480_9 = intersect(constant_8,v480_2);
    const Space v480_10 = (has_head(v480_9) ? constant_9 : Space{});
    Space v480_12;
    if (!v480_10.empty()) {
      const Path v485_6 = concat_path(p0,v479_11_head);
      Space v485_11_result;
      for (int v485_11_label = 1; v485_11_label <= 2; ++v485_11_label) {
        const Space v485_11_tail = child(v479_11_tail,v485_11_label);
        if (v485_11_tail.empty()) continue;
        const Path v485_11_head{v485_11_label};
        const Space v486_2 = singleton(v485_11_head);
        const Space v486_3 = intersect(constant_8,v486_2);
        const Space v486_4 = (has_head(v486_3) ? constant_9 : Space{});
        const Space v486_5 = subtract(constant_0,v486_4);
        Space v486_8;
        if (!v486_5.empty()) {
          const Path v487_6 = concat_path(v485_6,v485_11_head);
          const Space v487_7 = routine_102(c, v487_6, v485_11_tail);
          v486_8 = compose(v486_5,v487_7);
        }
        const Space v486_9 = intersect(constant_8,v486_2);
        const Space v486_10 = (has_head(v486_9) ? constant_9 : Space{});
        Space v486_12;
        if (!v486_10.empty()) {
          const Path v488_6 = concat_path(v485_6,v485_11_head);
          const Space v488_11 = routine_68(c, v488_6, v485_11_tail);
          v486_12 = compose(v486_10,v488_11);
        }
        const Space v486_13 = unite(v486_8,v486_12);
        v485_11_result = unite(v485_11_result,v486_13);
      }
      const Space v485_11 = std::move(v485_11_result);
      v480_12 = compose(v480_10,v485_11);
    }
    const Space v480_13 = unite(v480_8,v480_12);
    v479_11_result = unite(v479_11_result,v480_13);
  }
  const Space v479_11 = std::move(v479_11_result);
  return v479_11;
}

static Space routine_43(Context& c, const Path& p0, const Space& s0) {
  Space v489_8_result;
  for (int v489_8_label = 1; v489_8_label <= 2; ++v489_8_label) {
    const Space v489_8_tail = child(s0,v489_8_label);
    if (v489_8_tail.empty()) continue;
    const Path v489_8_head{v489_8_label};
    const Space v490_2 = singleton(v489_8_head);
    const Space v490_3 = intersect(constant_8,v490_2);
    const Space v490_4 = (has_head(v490_3) ? constant_9 : Space{});
    const Space v490_5 = subtract(constant_0,v490_4);
    Space v490_8;
    if (!v490_5.empty()) {
      const Path v491_6 = concat_path(p0,v489_8_head);
      Space v491_7_result;
      for (int v491_7_label = 1; v491_7_label <= 2; ++v491_7_label) {
        const Space v491_7_tail = child(v489_8_tail,v491_7_label);
        if (v491_7_tail.empty()) continue;
        const Path v491_7_head{v491_7_label};
        const Space v492_2 = singleton(v491_7_head);
        const Space v492_3 = intersect(constant_8,v492_2);
        const Space v492_4 = (has_head(v492_3) ? constant_9 : Space{});
        const Space v492_5 = subtract(constant_0,v492_4);
        Space v492_8;
        if (!v492_5.empty()) {
          const Path v493_6 = concat_path(v491_6,v491_7_head);
          const Space v493_7 = routine_102(c, v493_6, v491_7_tail);
          v492_8 = compose(v492_5,v493_7);
        }
        const Space v492_9 = intersect(constant_8,v492_2);
        const Space v492_10 = (has_head(v492_9) ? constant_9 : Space{});
        Space v492_12;
        if (!v492_10.empty()) {
          const Path v494_6 = concat_path(v491_6,v491_7_head);
          const Space v494_11 = routine_103(c, v494_6, v491_7_tail);
          v492_12 = compose(v492_10,v494_11);
        }
        const Space v492_13 = unite(v492_8,v492_12);
        v491_7_result = unite(v491_7_result,v492_13);
      }
      const Space v491_7 = std::move(v491_7_result);
      v490_8 = compose(v490_5,v491_7);
    }
    const Space v490_9 = intersect(constant_8,v490_2);
    const Space v490_10 = (has_head(v490_9) ? constant_9 : Space{});
    const Space v490_11 = compose(v490_10,v489_8_tail);
    const Space v490_12 = unite(v490_8,v490_11);
    v489_8_result = unite(v489_8_result,v490_12);
  }
  const Space v489_8 = std::move(v489_8_result);
  return v489_8;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0) {
  Space v495_11_result;
  for (int v495_11_label = 1; v495_11_label <= 2; ++v495_11_label) {
    const Space v495_11_tail = child(s0,v495_11_label);
    if (v495_11_tail.empty()) continue;
    const Path v495_11_head{v495_11_label};
    const Space v496_2 = singleton(v495_11_head);
    const Space v496_3 = intersect(constant_8,v496_2);
    const Space v496_4 = (has_head(v496_3) ? constant_9 : Space{});
    const Space v496_5 = subtract(constant_0,v496_4);
    Space v496_8;
    if (!v496_5.empty()) {
      const Path v497_6 = concat_path(p0,v495_11_head);
      Space v497_7_result;
      for (int v497_7_label = 1; v497_7_label <= 2; ++v497_7_label) {
        const Space v497_7_tail = child(v495_11_tail,v497_7_label);
        if (v497_7_tail.empty()) continue;
        const Path v497_7_head{v497_7_label};
        const Space v498_2 = singleton(v497_7_head);
        const Space v498_3 = intersect(constant_8,v498_2);
        const Space v498_4 = (has_head(v498_3) ? constant_9 : Space{});
        const Space v498_5 = subtract(constant_0,v498_4);
        Space v498_8;
        if (!v498_5.empty()) {
          const Path v499_6 = concat_path(v497_6,v497_7_head);
          const Space v499_7 = routine_104(c, v499_6, v497_7_tail);
          v498_8 = compose(v498_5,v499_7);
        }
        const Space v498_9 = intersect(constant_8,v498_2);
        const Space v498_10 = (has_head(v498_9) ? constant_9 : Space{});
        Space v498_12;
        if (!v498_10.empty()) {
          const Path v500_6 = concat_path(v497_6,v497_7_head);
          const Space v500_11 = routine_105(c, v500_6, v497_7_tail);
          v498_12 = compose(v498_10,v500_11);
        }
        const Space v498_13 = unite(v498_8,v498_12);
        v497_7_result = unite(v497_7_result,v498_13);
      }
      const Space v497_7 = std::move(v497_7_result);
      v496_8 = compose(v496_5,v497_7);
    }
    const Space v496_9 = intersect(constant_8,v496_2);
    const Space v496_10 = (has_head(v496_9) ? constant_9 : Space{});
    Space v496_12;
    if (!v496_10.empty()) {
      const Path v501_6 = concat_path(p0,v495_11_head);
      Space v501_11_result;
      for (int v501_11_label = 1; v501_11_label <= 2; ++v501_11_label) {
        const Space v501_11_tail = child(v495_11_tail,v501_11_label);
        if (v501_11_tail.empty()) continue;
        const Path v501_11_head{v501_11_label};
        const Space v502_2 = singleton(v501_11_head);
        const Space v502_3 = intersect(constant_8,v502_2);
        const Space v502_4 = (has_head(v502_3) ? constant_9 : Space{});
        const Space v502_5 = subtract(constant_0,v502_4);
        Space v502_8;
        if (!v502_5.empty()) {
          const Path v503_6 = concat_path(v501_6,v501_11_head);
          const Space v503_7 = routine_104(c, v503_6, v501_11_tail);
          v502_8 = compose(v502_5,v503_7);
        }
        const Space v502_9 = intersect(constant_8,v502_2);
        const Space v502_10 = (has_head(v502_9) ? constant_9 : Space{});
        Space v502_12;
        if (!v502_10.empty()) {
          const Path v504_6 = concat_path(v501_6,v501_11_head);
          const Space v504_11 = routine_71(c, v504_6, v501_11_tail);
          v502_12 = compose(v502_10,v504_11);
        }
        const Space v502_13 = unite(v502_8,v502_12);
        v501_11_result = unite(v501_11_result,v502_13);
      }
      const Space v501_11 = std::move(v501_11_result);
      v496_12 = compose(v496_10,v501_11);
    }
    const Space v496_13 = unite(v496_8,v496_12);
    v495_11_result = unite(v495_11_result,v496_13);
  }
  const Space v495_11 = std::move(v495_11_result);
  return v495_11;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0) {
  Space v505_11_result;
  for (int v505_11_label = 1; v505_11_label <= 2; ++v505_11_label) {
    const Space v505_11_tail = child(s0,v505_11_label);
    if (v505_11_tail.empty()) continue;
    const Path v505_11_head{v505_11_label};
    const Space v506_2 = singleton(v505_11_head);
    const Space v506_3 = intersect(constant_8,v506_2);
    const Space v506_4 = (has_head(v506_3) ? constant_9 : Space{});
    const Space v506_5 = subtract(constant_0,v506_4);
    Space v506_8;
    if (!v506_5.empty()) {
      const Path v507_6 = concat_path(p0,v505_11_head);
      Space v507_7_result;
      for (int v507_7_label = 1; v507_7_label <= 2; ++v507_7_label) {
        const Space v507_7_tail = child(v505_11_tail,v507_7_label);
        if (v507_7_tail.empty()) continue;
        const Path v507_7_head{v507_7_label};
        const Space v508_2 = singleton(v507_7_head);
        const Space v508_3 = intersect(constant_8,v508_2);
        const Space v508_4 = (has_head(v508_3) ? constant_9 : Space{});
        const Space v508_5 = subtract(constant_0,v508_4);
        Space v508_8;
        if (!v508_5.empty()) {
          const Path v509_6 = concat_path(v507_6,v507_7_head);
          const Space v509_7 = routine_104(c, v509_6, v507_7_tail);
          v508_8 = compose(v508_5,v509_7);
        }
        const Space v508_9 = intersect(constant_8,v508_2);
        const Space v508_10 = (has_head(v508_9) ? constant_9 : Space{});
        Space v508_12;
        if (!v508_10.empty()) {
          const Path v510_6 = concat_path(v507_6,v507_7_head);
          const Space v510_11 = routine_105(c, v510_6, v507_7_tail);
          v508_12 = compose(v508_10,v510_11);
        }
        const Space v508_13 = unite(v508_8,v508_12);
        v507_7_result = unite(v507_7_result,v508_13);
      }
      const Space v507_7 = std::move(v507_7_result);
      v506_8 = compose(v506_5,v507_7);
    }
    const Space v506_9 = intersect(constant_8,v506_2);
    const Space v506_10 = (has_head(v506_9) ? constant_9 : Space{});
    Space v506_12;
    if (!v506_10.empty()) {
      const Path v511_6 = concat_path(p0,v505_11_head);
      Space v511_11_result;
      for (int v511_11_label = 1; v511_11_label <= 2; ++v511_11_label) {
        const Space v511_11_tail = child(v505_11_tail,v511_11_label);
        if (v511_11_tail.empty()) continue;
        const Path v511_11_head{v511_11_label};
        const Space v512_2 = singleton(v511_11_head);
        const Space v512_3 = intersect(constant_8,v512_2);
        const Space v512_4 = (has_head(v512_3) ? constant_9 : Space{});
        const Space v512_5 = subtract(constant_0,v512_4);
        Space v512_7;
        if (!v512_5.empty()) {
          const Space v513_6 = routine_106(c, v511_11_head, v511_6, v511_11_tail);
          v512_7 = compose(v512_5,v513_6);
        }
        const Space v512_8 = intersect(constant_8,v512_2);
        const Space v512_9 = (has_head(v512_8) ? constant_9 : Space{});
        Space v512_11;
        if (!v512_9.empty()) {
          const Space v514_10 = routine_107(c, v511_11_head, v511_6, v511_11_tail);
          v512_11 = compose(v512_9,v514_10);
        }
        const Space v512_12 = unite(v512_7,v512_11);
        v511_11_result = unite(v511_11_result,v512_12);
      }
      const Space v511_11 = std::move(v511_11_result);
      v506_12 = compose(v506_10,v511_11);
    }
    const Space v506_13 = unite(v506_8,v506_12);
    v505_11_result = unite(v505_11_result,v506_13);
  }
  const Space v505_11 = std::move(v505_11_result);
  return v505_11;
}

static Space routine_46(Context& c, const Path& p0, const Space& s0) {
  Space v515_11_result;
  for (int v515_11_label = 1; v515_11_label <= 2; ++v515_11_label) {
    const Space v515_11_tail = child(s0,v515_11_label);
    if (v515_11_tail.empty()) continue;
    const Path v515_11_head{v515_11_label};
    const Space v516_2 = singleton(v515_11_head);
    const Space v516_3 = intersect(constant_8,v516_2);
    const Space v516_4 = (has_head(v516_3) ? constant_9 : Space{});
    const Space v516_5 = subtract(constant_0,v516_4);
    Space v516_8;
    if (!v516_5.empty()) {
      const Path v517_6 = concat_path(p0,v515_11_head);
      Space v517_7_result;
      for (int v517_7_label = 1; v517_7_label <= 2; ++v517_7_label) {
        const Space v517_7_tail = child(v515_11_tail,v517_7_label);
        if (v517_7_tail.empty()) continue;
        const Path v517_7_head{v517_7_label};
        const Space v518_2 = singleton(v517_7_head);
        const Space v518_3 = intersect(constant_8,v518_2);
        const Space v518_4 = (has_head(v518_3) ? constant_9 : Space{});
        const Space v518_5 = subtract(constant_0,v518_4);
        Space v518_8;
        if (!v518_5.empty()) {
          const Path v519_6 = concat_path(v517_6,v517_7_head);
          const Space v519_7 = routine_108(c, v519_6, v517_7_tail);
          v518_8 = compose(v518_5,v519_7);
        }
        const Space v518_9 = intersect(constant_8,v518_2);
        const Space v518_10 = (has_head(v518_9) ? constant_9 : Space{});
        Space v518_12;
        if (!v518_10.empty()) {
          const Path v520_6 = concat_path(v517_6,v517_7_head);
          const Space v520_11 = routine_109(c, v520_6, v517_7_tail);
          v518_12 = compose(v518_10,v520_11);
        }
        const Space v518_13 = unite(v518_8,v518_12);
        v517_7_result = unite(v517_7_result,v518_13);
      }
      const Space v517_7 = std::move(v517_7_result);
      v516_8 = compose(v516_5,v517_7);
    }
    const Space v516_9 = intersect(constant_8,v516_2);
    const Space v516_10 = (has_head(v516_9) ? constant_9 : Space{});
    Space v516_12;
    if (!v516_10.empty()) {
      const Path v521_6 = concat_path(p0,v515_11_head);
      Space v521_11_result;
      for (int v521_11_label = 1; v521_11_label <= 2; ++v521_11_label) {
        const Space v521_11_tail = child(v515_11_tail,v521_11_label);
        if (v521_11_tail.empty()) continue;
        const Path v521_11_head{v521_11_label};
        const Space v522_2 = singleton(v521_11_head);
        const Space v522_3 = intersect(constant_8,v522_2);
        const Space v522_4 = (has_head(v522_3) ? constant_9 : Space{});
        const Space v522_5 = subtract(constant_0,v522_4);
        Space v522_8;
        if (!v522_5.empty()) {
          const Path v523_6 = concat_path(v521_6,v521_11_head);
          const Space v523_7 = routine_108(c, v523_6, v521_11_tail);
          v522_8 = compose(v522_5,v523_7);
        }
        const Space v522_9 = intersect(constant_8,v522_2);
        const Space v522_10 = (has_head(v522_9) ? constant_9 : Space{});
        Space v522_12;
        if (!v522_10.empty()) {
          const Path v524_6 = concat_path(v521_6,v521_11_head);
          const Space v524_11 = routine_74(c, v524_6, v521_11_tail);
          v522_12 = compose(v522_10,v524_11);
        }
        const Space v522_13 = unite(v522_8,v522_12);
        v521_11_result = unite(v521_11_result,v522_13);
      }
      const Space v521_11 = std::move(v521_11_result);
      v516_12 = compose(v516_10,v521_11);
    }
    const Space v516_13 = unite(v516_8,v516_12);
    v515_11_result = unite(v515_11_result,v516_13);
  }
  const Space v515_11 = std::move(v515_11_result);
  return v515_11;
}

static Space routine_47(Context& c, const Path& p0, const Space& s0) {
  Space v525_8_result;
  for (int v525_8_label = 1; v525_8_label <= 2; ++v525_8_label) {
    const Space v525_8_tail = child(s0,v525_8_label);
    if (v525_8_tail.empty()) continue;
    const Path v525_8_head{v525_8_label};
    const Space v526_2 = singleton(v525_8_head);
    const Space v526_3 = intersect(constant_8,v526_2);
    const Space v526_4 = (has_head(v526_3) ? constant_9 : Space{});
    const Space v526_5 = subtract(constant_0,v526_4);
    Space v526_8;
    if (!v526_5.empty()) {
      const Path v527_6 = concat_path(p0,v525_8_head);
      Space v527_7_result;
      for (int v527_7_label = 1; v527_7_label <= 2; ++v527_7_label) {
        const Space v527_7_tail = child(v525_8_tail,v527_7_label);
        if (v527_7_tail.empty()) continue;
        const Path v527_7_head{v527_7_label};
        const Space v528_2 = singleton(v527_7_head);
        const Space v528_3 = intersect(constant_8,v528_2);
        const Space v528_4 = (has_head(v528_3) ? constant_9 : Space{});
        const Space v528_5 = subtract(constant_0,v528_4);
        Space v528_8;
        if (!v528_5.empty()) {
          const Path v529_6 = concat_path(v527_6,v527_7_head);
          const Space v529_7 = routine_108(c, v529_6, v527_7_tail);
          v528_8 = compose(v528_5,v529_7);
        }
        const Space v528_9 = intersect(constant_8,v528_2);
        const Space v528_10 = (has_head(v528_9) ? constant_9 : Space{});
        Space v528_12;
        if (!v528_10.empty()) {
          const Path v530_6 = concat_path(v527_6,v527_7_head);
          const Space v530_11 = routine_109(c, v530_6, v527_7_tail);
          v528_12 = compose(v528_10,v530_11);
        }
        const Space v528_13 = unite(v528_8,v528_12);
        v527_7_result = unite(v527_7_result,v528_13);
      }
      const Space v527_7 = std::move(v527_7_result);
      v526_8 = compose(v526_5,v527_7);
    }
    const Space v526_9 = intersect(constant_8,v526_2);
    const Space v526_10 = (has_head(v526_9) ? constant_9 : Space{});
    const Space v526_11 = compose(v526_10,v525_8_tail);
    const Space v526_12 = unite(v526_8,v526_11);
    v525_8_result = unite(v525_8_result,v526_12);
  }
  const Space v525_8 = std::move(v525_8_result);
  return v525_8;
}

static Space routine_48(Context& c, const Path& p0, const Space& s0) {
  Space v531_11_result;
  for (int v531_11_label = 1; v531_11_label <= 2; ++v531_11_label) {
    const Space v531_11_tail = child(s0,v531_11_label);
    if (v531_11_tail.empty()) continue;
    const Path v531_11_head{v531_11_label};
    const Space v532_2 = singleton(v531_11_head);
    const Space v532_3 = intersect(constant_8,v532_2);
    const Space v532_4 = (has_head(v532_3) ? constant_9 : Space{});
    const Space v532_5 = subtract(constant_0,v532_4);
    Space v532_8;
    if (!v532_5.empty()) {
      const Path v533_6 = concat_path(p0,v531_11_head);
      Space v533_7_result;
      for (int v533_7_label = 1; v533_7_label <= 2; ++v533_7_label) {
        const Space v533_7_tail = child(v531_11_tail,v533_7_label);
        if (v533_7_tail.empty()) continue;
        const Path v533_7_head{v533_7_label};
        const Space v534_2 = singleton(v533_7_head);
        const Space v534_3 = intersect(constant_8,v534_2);
        const Space v534_4 = (has_head(v534_3) ? constant_9 : Space{});
        const Space v534_5 = subtract(constant_0,v534_4);
        Space v534_8;
        if (!v534_5.empty()) {
          const Path v535_6 = concat_path(v533_6,v533_7_head);
          const Space v535_7 = routine_110(c, v535_6, v533_7_tail);
          v534_8 = compose(v534_5,v535_7);
        }
        const Space v534_9 = intersect(constant_8,v534_2);
        const Space v534_10 = (has_head(v534_9) ? constant_9 : Space{});
        Space v534_12;
        if (!v534_10.empty()) {
          const Path v536_6 = concat_path(v533_6,v533_7_head);
          const Space v536_11 = routine_111(c, v536_6, v533_7_tail);
          v534_12 = compose(v534_10,v536_11);
        }
        const Space v534_13 = unite(v534_8,v534_12);
        v533_7_result = unite(v533_7_result,v534_13);
      }
      const Space v533_7 = std::move(v533_7_result);
      v532_8 = compose(v532_5,v533_7);
    }
    const Space v532_9 = intersect(constant_8,v532_2);
    const Space v532_10 = (has_head(v532_9) ? constant_9 : Space{});
    Space v532_12;
    if (!v532_10.empty()) {
      const Path v537_6 = concat_path(p0,v531_11_head);
      Space v537_11_result;
      for (int v537_11_label = 1; v537_11_label <= 2; ++v537_11_label) {
        const Space v537_11_tail = child(v531_11_tail,v537_11_label);
        if (v537_11_tail.empty()) continue;
        const Path v537_11_head{v537_11_label};
        const Space v538_2 = singleton(v537_11_head);
        const Space v538_3 = intersect(constant_8,v538_2);
        const Space v538_4 = (has_head(v538_3) ? constant_9 : Space{});
        const Space v538_5 = subtract(constant_0,v538_4);
        Space v538_8;
        if (!v538_5.empty()) {
          const Path v539_6 = concat_path(v537_6,v537_11_head);
          const Space v539_7 = routine_110(c, v539_6, v537_11_tail);
          v538_8 = compose(v538_5,v539_7);
        }
        const Space v538_9 = intersect(constant_8,v538_2);
        const Space v538_10 = (has_head(v538_9) ? constant_9 : Space{});
        Space v538_12;
        if (!v538_10.empty()) {
          const Path v540_6 = concat_path(v537_6,v537_11_head);
          const Space v540_11 = routine_77(c, v540_6, v537_11_tail);
          v538_12 = compose(v538_10,v540_11);
        }
        const Space v538_13 = unite(v538_8,v538_12);
        v537_11_result = unite(v537_11_result,v538_13);
      }
      const Space v537_11 = std::move(v537_11_result);
      v532_12 = compose(v532_10,v537_11);
    }
    const Space v532_13 = unite(v532_8,v532_12);
    v531_11_result = unite(v531_11_result,v532_13);
  }
  const Space v531_11 = std::move(v531_11_result);
  return v531_11;
}

static Space routine_49(Context& c, const Path& p0, const Space& s0) {
  Space v541_11_result;
  for (int v541_11_label = 1; v541_11_label <= 2; ++v541_11_label) {
    const Space v541_11_tail = child(s0,v541_11_label);
    if (v541_11_tail.empty()) continue;
    const Path v541_11_head{v541_11_label};
    const Space v542_2 = singleton(v541_11_head);
    const Space v542_3 = intersect(constant_8,v542_2);
    const Space v542_4 = (has_head(v542_3) ? constant_9 : Space{});
    const Space v542_5 = subtract(constant_0,v542_4);
    Space v542_8;
    if (!v542_5.empty()) {
      const Path v543_6 = concat_path(p0,v541_11_head);
      Space v543_7_result;
      for (int v543_7_label = 1; v543_7_label <= 2; ++v543_7_label) {
        const Space v543_7_tail = child(v541_11_tail,v543_7_label);
        if (v543_7_tail.empty()) continue;
        const Path v543_7_head{v543_7_label};
        const Space v544_2 = singleton(v543_7_head);
        const Space v544_3 = intersect(constant_8,v544_2);
        const Space v544_4 = (has_head(v544_3) ? constant_9 : Space{});
        const Space v544_5 = subtract(constant_0,v544_4);
        Space v544_8;
        if (!v544_5.empty()) {
          const Path v545_6 = concat_path(v543_6,v543_7_head);
          const Space v545_7 = routine_110(c, v545_6, v543_7_tail);
          v544_8 = compose(v544_5,v545_7);
        }
        const Space v544_9 = intersect(constant_8,v544_2);
        const Space v544_10 = (has_head(v544_9) ? constant_9 : Space{});
        Space v544_12;
        if (!v544_10.empty()) {
          const Path v546_6 = concat_path(v543_6,v543_7_head);
          const Space v546_11 = routine_111(c, v546_6, v543_7_tail);
          v544_12 = compose(v544_10,v546_11);
        }
        const Space v544_13 = unite(v544_8,v544_12);
        v543_7_result = unite(v543_7_result,v544_13);
      }
      const Space v543_7 = std::move(v543_7_result);
      v542_8 = compose(v542_5,v543_7);
    }
    const Space v542_9 = intersect(constant_8,v542_2);
    const Space v542_10 = (has_head(v542_9) ? constant_9 : Space{});
    Space v542_12;
    if (!v542_10.empty()) {
      const Path v547_6 = concat_path(p0,v541_11_head);
      Space v547_11_result;
      for (int v547_11_label = 1; v547_11_label <= 2; ++v547_11_label) {
        const Space v547_11_tail = child(v541_11_tail,v547_11_label);
        if (v547_11_tail.empty()) continue;
        const Path v547_11_head{v547_11_label};
        const Space v548_2 = singleton(v547_11_head);
        const Space v548_3 = intersect(constant_8,v548_2);
        const Space v548_4 = (has_head(v548_3) ? constant_9 : Space{});
        const Space v548_5 = subtract(constant_0,v548_4);
        Space v548_7;
        if (!v548_5.empty()) {
          const Space v549_6 = routine_112(c, v547_11_head, v547_6, v547_11_tail);
          v548_7 = compose(v548_5,v549_6);
        }
        const Space v548_8 = intersect(constant_8,v548_2);
        const Space v548_9 = (has_head(v548_8) ? constant_9 : Space{});
        Space v548_11;
        if (!v548_9.empty()) {
          const Space v550_10 = routine_113(c, v547_11_head, v547_6, v547_11_tail);
          v548_11 = compose(v548_9,v550_10);
        }
        const Space v548_12 = unite(v548_7,v548_11);
        v547_11_result = unite(v547_11_result,v548_12);
      }
      const Space v547_11 = std::move(v547_11_result);
      v542_12 = compose(v542_10,v547_11);
    }
    const Space v542_13 = unite(v542_8,v542_12);
    v541_11_result = unite(v541_11_result,v542_13);
  }
  const Space v541_11 = std::move(v541_11_result);
  return v541_11;
}

static Space routine_50(Context& c, const Path& p0, const Space& s0) {
  Space v551_11_result;
  for (int v551_11_label = 1; v551_11_label <= 2; ++v551_11_label) {
    const Space v551_11_tail = child(s0,v551_11_label);
    if (v551_11_tail.empty()) continue;
    const Path v551_11_head{v551_11_label};
    const Space v552_2 = singleton(v551_11_head);
    const Space v552_3 = intersect(constant_8,v552_2);
    const Space v552_4 = (has_head(v552_3) ? constant_9 : Space{});
    const Space v552_5 = subtract(constant_0,v552_4);
    Space v552_8;
    if (!v552_5.empty()) {
      const Path v553_6 = concat_path(p0,v551_11_head);
      Space v553_7_result;
      for (int v553_7_label = 1; v553_7_label <= 2; ++v553_7_label) {
        const Space v553_7_tail = child(v551_11_tail,v553_7_label);
        if (v553_7_tail.empty()) continue;
        const Path v553_7_head{v553_7_label};
        const Space v554_2 = singleton(v553_7_head);
        const Space v554_3 = intersect(constant_8,v554_2);
        const Space v554_4 = (has_head(v554_3) ? constant_9 : Space{});
        const Space v554_5 = subtract(constant_0,v554_4);
        Space v554_8;
        if (!v554_5.empty()) {
          const Path v555_6 = concat_path(v553_6,v553_7_head);
          const Space v555_7 = routine_114(c, v555_6, v553_7_tail);
          v554_8 = compose(v554_5,v555_7);
        }
        const Space v554_9 = intersect(constant_8,v554_2);
        const Space v554_10 = (has_head(v554_9) ? constant_9 : Space{});
        Space v554_12;
        if (!v554_10.empty()) {
          const Path v556_6 = concat_path(v553_6,v553_7_head);
          const Space v556_11 = routine_115(c, v556_6, v553_7_tail);
          v554_12 = compose(v554_10,v556_11);
        }
        const Space v554_13 = unite(v554_8,v554_12);
        v553_7_result = unite(v553_7_result,v554_13);
      }
      const Space v553_7 = std::move(v553_7_result);
      v552_8 = compose(v552_5,v553_7);
    }
    const Space v552_9 = intersect(constant_8,v552_2);
    const Space v552_10 = (has_head(v552_9) ? constant_9 : Space{});
    Space v552_12;
    if (!v552_10.empty()) {
      const Path v557_6 = concat_path(p0,v551_11_head);
      Space v557_11_result;
      for (int v557_11_label = 1; v557_11_label <= 2; ++v557_11_label) {
        const Space v557_11_tail = child(v551_11_tail,v557_11_label);
        if (v557_11_tail.empty()) continue;
        const Path v557_11_head{v557_11_label};
        const Space v558_2 = singleton(v557_11_head);
        const Space v558_3 = intersect(constant_8,v558_2);
        const Space v558_4 = (has_head(v558_3) ? constant_9 : Space{});
        const Space v558_5 = subtract(constant_0,v558_4);
        Space v558_8;
        if (!v558_5.empty()) {
          const Path v559_6 = concat_path(v557_6,v557_11_head);
          const Space v559_7 = routine_114(c, v559_6, v557_11_tail);
          v558_8 = compose(v558_5,v559_7);
        }
        const Space v558_9 = intersect(constant_8,v558_2);
        const Space v558_10 = (has_head(v558_9) ? constant_9 : Space{});
        Space v558_12;
        if (!v558_10.empty()) {
          const Path v560_6 = concat_path(v557_6,v557_11_head);
          const Space v560_11 = routine_80(c, v560_6, v557_11_tail);
          v558_12 = compose(v558_10,v560_11);
        }
        const Space v558_13 = unite(v558_8,v558_12);
        v557_11_result = unite(v557_11_result,v558_13);
      }
      const Space v557_11 = std::move(v557_11_result);
      v552_12 = compose(v552_10,v557_11);
    }
    const Space v552_13 = unite(v552_8,v552_12);
    v551_11_result = unite(v551_11_result,v552_13);
  }
  const Space v551_11 = std::move(v551_11_result);
  return v551_11;
}

static Space routine_51(Context& c, const Path& p0, const Space& s0) {
  Space v561_8_result;
  for (int v561_8_label = 1; v561_8_label <= 2; ++v561_8_label) {
    const Space v561_8_tail = child(s0,v561_8_label);
    if (v561_8_tail.empty()) continue;
    const Path v561_8_head{v561_8_label};
    const Space v562_2 = singleton(v561_8_head);
    const Space v562_3 = intersect(constant_8,v562_2);
    const Space v562_4 = (has_head(v562_3) ? constant_9 : Space{});
    const Space v562_5 = subtract(constant_0,v562_4);
    Space v562_8;
    if (!v562_5.empty()) {
      const Path v563_6 = concat_path(p0,v561_8_head);
      Space v563_7_result;
      for (int v563_7_label = 1; v563_7_label <= 2; ++v563_7_label) {
        const Space v563_7_tail = child(v561_8_tail,v563_7_label);
        if (v563_7_tail.empty()) continue;
        const Path v563_7_head{v563_7_label};
        const Space v564_2 = singleton(v563_7_head);
        const Space v564_3 = intersect(constant_8,v564_2);
        const Space v564_4 = (has_head(v564_3) ? constant_9 : Space{});
        const Space v564_5 = subtract(constant_0,v564_4);
        Space v564_8;
        if (!v564_5.empty()) {
          const Path v565_6 = concat_path(v563_6,v563_7_head);
          const Space v565_7 = routine_114(c, v565_6, v563_7_tail);
          v564_8 = compose(v564_5,v565_7);
        }
        const Space v564_9 = intersect(constant_8,v564_2);
        const Space v564_10 = (has_head(v564_9) ? constant_9 : Space{});
        Space v564_12;
        if (!v564_10.empty()) {
          const Path v566_6 = concat_path(v563_6,v563_7_head);
          const Space v566_11 = routine_115(c, v566_6, v563_7_tail);
          v564_12 = compose(v564_10,v566_11);
        }
        const Space v564_13 = unite(v564_8,v564_12);
        v563_7_result = unite(v563_7_result,v564_13);
      }
      const Space v563_7 = std::move(v563_7_result);
      v562_8 = compose(v562_5,v563_7);
    }
    const Space v562_9 = intersect(constant_8,v562_2);
    const Space v562_10 = (has_head(v562_9) ? constant_9 : Space{});
    const Space v562_11 = compose(v562_10,v561_8_tail);
    const Space v562_12 = unite(v562_8,v562_11);
    v561_8_result = unite(v561_8_result,v562_12);
  }
  const Space v561_8 = std::move(v561_8_result);
  return v561_8;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0) {
  Space v567_11_result;
  for (int v567_11_label = 1; v567_11_label <= 2; ++v567_11_label) {
    const Space v567_11_tail = child(s0,v567_11_label);
    if (v567_11_tail.empty()) continue;
    const Path v567_11_head{v567_11_label};
    const Space v568_2 = singleton(v567_11_head);
    const Space v568_3 = intersect(constant_8,v568_2);
    const Space v568_4 = (has_head(v568_3) ? constant_9 : Space{});
    const Space v568_5 = subtract(constant_0,v568_4);
    Space v568_8;
    if (!v568_5.empty()) {
      const Path v569_6 = concat_path(p0,v567_11_head);
      Space v569_7_result;
      for (int v569_7_label = 1; v569_7_label <= 2; ++v569_7_label) {
        const Space v569_7_tail = child(v567_11_tail,v569_7_label);
        if (v569_7_tail.empty()) continue;
        const Path v569_7_head{v569_7_label};
        const Space v570_2 = singleton(v569_7_head);
        const Space v570_3 = intersect(constant_8,v570_2);
        const Space v570_4 = (has_head(v570_3) ? constant_9 : Space{});
        const Space v570_5 = subtract(constant_0,v570_4);
        Space v570_8;
        if (!v570_5.empty()) {
          const Path v571_6 = concat_path(v569_6,v569_7_head);
          const Space v571_7 = routine_116(c, v571_6, v569_7_tail);
          v570_8 = compose(v570_5,v571_7);
        }
        const Space v570_9 = intersect(constant_8,v570_2);
        const Space v570_10 = (has_head(v570_9) ? constant_9 : Space{});
        Space v570_12;
        if (!v570_10.empty()) {
          const Path v572_6 = concat_path(v569_6,v569_7_head);
          const Space v572_11 = routine_117(c, v572_6, v569_7_tail);
          v570_12 = compose(v570_10,v572_11);
        }
        const Space v570_13 = unite(v570_8,v570_12);
        v569_7_result = unite(v569_7_result,v570_13);
      }
      const Space v569_7 = std::move(v569_7_result);
      v568_8 = compose(v568_5,v569_7);
    }
    const Space v568_9 = intersect(constant_8,v568_2);
    const Space v568_10 = (has_head(v568_9) ? constant_9 : Space{});
    Space v568_12;
    if (!v568_10.empty()) {
      const Path v573_6 = concat_path(p0,v567_11_head);
      Space v573_11_result;
      for (int v573_11_label = 1; v573_11_label <= 2; ++v573_11_label) {
        const Space v573_11_tail = child(v567_11_tail,v573_11_label);
        if (v573_11_tail.empty()) continue;
        const Path v573_11_head{v573_11_label};
        const Space v574_2 = singleton(v573_11_head);
        const Space v574_3 = intersect(constant_8,v574_2);
        const Space v574_4 = (has_head(v574_3) ? constant_9 : Space{});
        const Space v574_5 = subtract(constant_0,v574_4);
        Space v574_8;
        if (!v574_5.empty()) {
          const Path v575_6 = concat_path(v573_6,v573_11_head);
          const Space v575_7 = routine_116(c, v575_6, v573_11_tail);
          v574_8 = compose(v574_5,v575_7);
        }
        const Space v574_9 = intersect(constant_8,v574_2);
        const Space v574_10 = (has_head(v574_9) ? constant_9 : Space{});
        Space v574_12;
        if (!v574_10.empty()) {
          const Path v576_6 = concat_path(v573_6,v573_11_head);
          const Space v576_11 = routine_83(c, v576_6, v573_11_tail);
          v574_12 = compose(v574_10,v576_11);
        }
        const Space v574_13 = unite(v574_8,v574_12);
        v573_11_result = unite(v573_11_result,v574_13);
      }
      const Space v573_11 = std::move(v573_11_result);
      v568_12 = compose(v568_10,v573_11);
    }
    const Space v568_13 = unite(v568_8,v568_12);
    v567_11_result = unite(v567_11_result,v568_13);
  }
  const Space v567_11 = std::move(v567_11_result);
  return v567_11;
}

static Space routine_53(Context& c, const Path& p0, const Space& s0) {
  Space v577_11_result;
  for (int v577_11_label = 1; v577_11_label <= 2; ++v577_11_label) {
    const Space v577_11_tail = child(s0,v577_11_label);
    if (v577_11_tail.empty()) continue;
    const Path v577_11_head{v577_11_label};
    const Space v578_2 = singleton(v577_11_head);
    const Space v578_3 = intersect(constant_8,v578_2);
    const Space v578_4 = (has_head(v578_3) ? constant_9 : Space{});
    const Space v578_5 = subtract(constant_0,v578_4);
    Space v578_8;
    if (!v578_5.empty()) {
      const Path v579_6 = concat_path(p0,v577_11_head);
      Space v579_7_result;
      for (int v579_7_label = 1; v579_7_label <= 2; ++v579_7_label) {
        const Space v579_7_tail = child(v577_11_tail,v579_7_label);
        if (v579_7_tail.empty()) continue;
        const Path v579_7_head{v579_7_label};
        const Space v580_2 = singleton(v579_7_head);
        const Space v580_3 = intersect(constant_8,v580_2);
        const Space v580_4 = (has_head(v580_3) ? constant_9 : Space{});
        const Space v580_5 = subtract(constant_0,v580_4);
        Space v580_8;
        if (!v580_5.empty()) {
          const Path v581_6 = concat_path(v579_6,v579_7_head);
          const Space v581_7 = routine_116(c, v581_6, v579_7_tail);
          v580_8 = compose(v580_5,v581_7);
        }
        const Space v580_9 = intersect(constant_8,v580_2);
        const Space v580_10 = (has_head(v580_9) ? constant_9 : Space{});
        Space v580_12;
        if (!v580_10.empty()) {
          const Path v582_6 = concat_path(v579_6,v579_7_head);
          const Space v582_11 = routine_117(c, v582_6, v579_7_tail);
          v580_12 = compose(v580_10,v582_11);
        }
        const Space v580_13 = unite(v580_8,v580_12);
        v579_7_result = unite(v579_7_result,v580_13);
      }
      const Space v579_7 = std::move(v579_7_result);
      v578_8 = compose(v578_5,v579_7);
    }
    const Space v578_9 = intersect(constant_8,v578_2);
    const Space v578_10 = (has_head(v578_9) ? constant_9 : Space{});
    Space v578_12;
    if (!v578_10.empty()) {
      const Path v583_6 = concat_path(p0,v577_11_head);
      Space v583_11_result;
      for (int v583_11_label = 1; v583_11_label <= 2; ++v583_11_label) {
        const Space v583_11_tail = child(v577_11_tail,v583_11_label);
        if (v583_11_tail.empty()) continue;
        const Path v583_11_head{v583_11_label};
        const Space v584_2 = singleton(v583_11_head);
        const Space v584_3 = intersect(constant_8,v584_2);
        const Space v584_4 = (has_head(v584_3) ? constant_9 : Space{});
        const Space v584_5 = subtract(constant_0,v584_4);
        Space v584_7;
        if (!v584_5.empty()) {
          const Space v585_6 = routine_118(c, v583_11_head, v583_6, v583_11_tail);
          v584_7 = compose(v584_5,v585_6);
        }
        const Space v584_8 = intersect(constant_8,v584_2);
        const Space v584_9 = (has_head(v584_8) ? constant_9 : Space{});
        Space v584_11;
        if (!v584_9.empty()) {
          const Space v586_10 = routine_119(c, v583_11_head, v583_6, v583_11_tail);
          v584_11 = compose(v584_9,v586_10);
        }
        const Space v584_12 = unite(v584_7,v584_11);
        v583_11_result = unite(v583_11_result,v584_12);
      }
      const Space v583_11 = std::move(v583_11_result);
      v578_12 = compose(v578_10,v583_11);
    }
    const Space v578_13 = unite(v578_8,v578_12);
    v577_11_result = unite(v577_11_result,v578_13);
  }
  const Space v577_11 = std::move(v577_11_result);
  return v577_11;
}

static Space routine_54(Context& c, const Path& p0, const Space& s0) {
  Space v587_11_result;
  for (int v587_11_label = 1; v587_11_label <= 2; ++v587_11_label) {
    const Space v587_11_tail = child(s0,v587_11_label);
    if (v587_11_tail.empty()) continue;
    const Path v587_11_head{v587_11_label};
    const Space v588_2 = singleton(v587_11_head);
    const Space v588_3 = intersect(constant_8,v588_2);
    const Space v588_4 = (has_head(v588_3) ? constant_9 : Space{});
    const Space v588_5 = subtract(constant_0,v588_4);
    Space v588_8;
    if (!v588_5.empty()) {
      const Path v589_6 = concat_path(p0,v587_11_head);
      Space v589_7_result;
      for (int v589_7_label = 1; v589_7_label <= 2; ++v589_7_label) {
        const Space v589_7_tail = child(v587_11_tail,v589_7_label);
        if (v589_7_tail.empty()) continue;
        const Path v589_7_head{v589_7_label};
        const Space v590_2 = singleton(v589_7_head);
        const Space v590_3 = intersect(constant_8,v590_2);
        const Space v590_4 = (has_head(v590_3) ? constant_9 : Space{});
        const Space v590_5 = subtract(constant_0,v590_4);
        Space v590_8;
        if (!v590_5.empty()) {
          const Path v591_6 = concat_path(v589_6,v589_7_head);
          const Space v591_7 = routine_120(c, v591_6, v589_7_tail);
          v590_8 = compose(v590_5,v591_7);
        }
        const Space v590_9 = intersect(constant_8,v590_2);
        const Space v590_10 = (has_head(v590_9) ? constant_9 : Space{});
        Space v590_12;
        if (!v590_10.empty()) {
          const Path v592_6 = concat_path(v589_6,v589_7_head);
          const Space v592_11 = routine_121(c, v592_6, v589_7_tail);
          v590_12 = compose(v590_10,v592_11);
        }
        const Space v590_13 = unite(v590_8,v590_12);
        v589_7_result = unite(v589_7_result,v590_13);
      }
      const Space v589_7 = std::move(v589_7_result);
      v588_8 = compose(v588_5,v589_7);
    }
    const Space v588_9 = intersect(constant_8,v588_2);
    const Space v588_10 = (has_head(v588_9) ? constant_9 : Space{});
    Space v588_12;
    if (!v588_10.empty()) {
      const Path v593_6 = concat_path(p0,v587_11_head);
      Space v593_11_result;
      for (int v593_11_label = 1; v593_11_label <= 2; ++v593_11_label) {
        const Space v593_11_tail = child(v587_11_tail,v593_11_label);
        if (v593_11_tail.empty()) continue;
        const Path v593_11_head{v593_11_label};
        const Space v594_2 = singleton(v593_11_head);
        const Space v594_3 = intersect(constant_8,v594_2);
        const Space v594_4 = (has_head(v594_3) ? constant_9 : Space{});
        const Space v594_5 = subtract(constant_0,v594_4);
        Space v594_8;
        if (!v594_5.empty()) {
          const Path v595_6 = concat_path(v593_6,v593_11_head);
          const Space v595_7 = routine_120(c, v595_6, v593_11_tail);
          v594_8 = compose(v594_5,v595_7);
        }
        const Space v594_9 = intersect(constant_8,v594_2);
        const Space v594_10 = (has_head(v594_9) ? constant_9 : Space{});
        Space v594_12;
        if (!v594_10.empty()) {
          const Path v596_6 = concat_path(v593_6,v593_11_head);
          const Space v596_11 = routine_86(c, v596_6, v593_11_tail);
          v594_12 = compose(v594_10,v596_11);
        }
        const Space v594_13 = unite(v594_8,v594_12);
        v593_11_result = unite(v593_11_result,v594_13);
      }
      const Space v593_11 = std::move(v593_11_result);
      v588_12 = compose(v588_10,v593_11);
    }
    const Space v588_13 = unite(v588_8,v588_12);
    v587_11_result = unite(v587_11_result,v588_13);
  }
  const Space v587_11 = std::move(v587_11_result);
  return v587_11;
}

static Space routine_55(Context& c, const Path& p0, const Space& s0) {
  Space v597_8_result;
  for (int v597_8_label = 1; v597_8_label <= 2; ++v597_8_label) {
    const Space v597_8_tail = child(s0,v597_8_label);
    if (v597_8_tail.empty()) continue;
    const Path v597_8_head{v597_8_label};
    const Space v598_2 = singleton(v597_8_head);
    const Space v598_3 = intersect(constant_8,v598_2);
    const Space v598_4 = (has_head(v598_3) ? constant_9 : Space{});
    const Space v598_5 = subtract(constant_0,v598_4);
    Space v598_8;
    if (!v598_5.empty()) {
      const Path v599_6 = concat_path(p0,v597_8_head);
      Space v599_7_result;
      for (int v599_7_label = 1; v599_7_label <= 2; ++v599_7_label) {
        const Space v599_7_tail = child(v597_8_tail,v599_7_label);
        if (v599_7_tail.empty()) continue;
        const Path v599_7_head{v599_7_label};
        const Space v600_2 = singleton(v599_7_head);
        const Space v600_3 = intersect(constant_8,v600_2);
        const Space v600_4 = (has_head(v600_3) ? constant_9 : Space{});
        const Space v600_5 = subtract(constant_0,v600_4);
        Space v600_8;
        if (!v600_5.empty()) {
          const Path v601_6 = concat_path(v599_6,v599_7_head);
          const Space v601_7 = routine_120(c, v601_6, v599_7_tail);
          v600_8 = compose(v600_5,v601_7);
        }
        const Space v600_9 = intersect(constant_8,v600_2);
        const Space v600_10 = (has_head(v600_9) ? constant_9 : Space{});
        Space v600_12;
        if (!v600_10.empty()) {
          const Path v602_6 = concat_path(v599_6,v599_7_head);
          const Space v602_11 = routine_121(c, v602_6, v599_7_tail);
          v600_12 = compose(v600_10,v602_11);
        }
        const Space v600_13 = unite(v600_8,v600_12);
        v599_7_result = unite(v599_7_result,v600_13);
      }
      const Space v599_7 = std::move(v599_7_result);
      v598_8 = compose(v598_5,v599_7);
    }
    const Space v598_9 = intersect(constant_8,v598_2);
    const Space v598_10 = (has_head(v598_9) ? constant_9 : Space{});
    const Space v598_11 = compose(v598_10,v597_8_tail);
    const Space v598_12 = unite(v598_8,v598_11);
    v597_8_result = unite(v597_8_result,v598_12);
  }
  const Space v597_8 = std::move(v597_8_result);
  return v597_8;
}

static Space routine_56(Context& c, const Path& p0, const Space& s0) {
  Space v603_11_result;
  for (int v603_11_label = 1; v603_11_label <= 2; ++v603_11_label) {
    const Space v603_11_tail = child(s0,v603_11_label);
    if (v603_11_tail.empty()) continue;
    const Path v603_11_head{v603_11_label};
    const Space v604_2 = singleton(v603_11_head);
    const Space v604_3 = intersect(constant_8,v604_2);
    const Space v604_4 = (has_head(v604_3) ? constant_9 : Space{});
    const Space v604_5 = subtract(constant_0,v604_4);
    Space v604_8;
    if (!v604_5.empty()) {
      const Path v605_6 = concat_path(p0,v603_11_head);
      Space v605_7_result;
      for (int v605_7_label = 1; v605_7_label <= 2; ++v605_7_label) {
        const Space v605_7_tail = child(v603_11_tail,v605_7_label);
        if (v605_7_tail.empty()) continue;
        const Path v605_7_head{v605_7_label};
        const Space v606_2 = singleton(v605_7_head);
        const Space v606_3 = intersect(constant_8,v606_2);
        const Space v606_4 = (has_head(v606_3) ? constant_9 : Space{});
        const Space v606_5 = subtract(constant_0,v606_4);
        Space v606_8;
        if (!v606_5.empty()) {
          const Path v607_6 = concat_path(v605_6,v605_7_head);
          const Space v607_7 = routine_122(c, v607_6, v605_7_tail);
          v606_8 = compose(v606_5,v607_7);
        }
        const Space v606_9 = intersect(constant_8,v606_2);
        const Space v606_10 = (has_head(v606_9) ? constant_9 : Space{});
        Space v606_12;
        if (!v606_10.empty()) {
          const Path v608_6 = concat_path(v605_6,v605_7_head);
          const Space v608_11 = routine_123(c, v608_6, v605_7_tail);
          v606_12 = compose(v606_10,v608_11);
        }
        const Space v606_13 = unite(v606_8,v606_12);
        v605_7_result = unite(v605_7_result,v606_13);
      }
      const Space v605_7 = std::move(v605_7_result);
      v604_8 = compose(v604_5,v605_7);
    }
    const Space v604_9 = intersect(constant_8,v604_2);
    const Space v604_10 = (has_head(v604_9) ? constant_9 : Space{});
    Space v604_12;
    if (!v604_10.empty()) {
      const Path v609_6 = concat_path(p0,v603_11_head);
      Space v609_11_result;
      for (int v609_11_label = 1; v609_11_label <= 2; ++v609_11_label) {
        const Space v609_11_tail = child(v603_11_tail,v609_11_label);
        if (v609_11_tail.empty()) continue;
        const Path v609_11_head{v609_11_label};
        const Space v610_2 = singleton(v609_11_head);
        const Space v610_3 = intersect(constant_8,v610_2);
        const Space v610_4 = (has_head(v610_3) ? constant_9 : Space{});
        const Space v610_5 = subtract(constant_0,v610_4);
        Space v610_8;
        if (!v610_5.empty()) {
          const Path v611_6 = concat_path(v609_6,v609_11_head);
          const Space v611_7 = routine_122(c, v611_6, v609_11_tail);
          v610_8 = compose(v610_5,v611_7);
        }
        const Space v610_9 = intersect(constant_8,v610_2);
        const Space v610_10 = (has_head(v610_9) ? constant_9 : Space{});
        Space v610_12;
        if (!v610_10.empty()) {
          const Path v612_6 = concat_path(v609_6,v609_11_head);
          const Space v612_11 = routine_89(c, v612_6, v609_11_tail);
          v610_12 = compose(v610_10,v612_11);
        }
        const Space v610_13 = unite(v610_8,v610_12);
        v609_11_result = unite(v609_11_result,v610_13);
      }
      const Space v609_11 = std::move(v609_11_result);
      v604_12 = compose(v604_10,v609_11);
    }
    const Space v604_13 = unite(v604_8,v604_12);
    v603_11_result = unite(v603_11_result,v604_13);
  }
  const Space v603_11 = std::move(v603_11_result);
  return v603_11;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0) {
  Space v613_11_result;
  for (int v613_11_label = 1; v613_11_label <= 2; ++v613_11_label) {
    const Space v613_11_tail = child(s0,v613_11_label);
    if (v613_11_tail.empty()) continue;
    const Path v613_11_head{v613_11_label};
    const Space v614_2 = singleton(v613_11_head);
    const Space v614_3 = intersect(constant_8,v614_2);
    const Space v614_4 = (has_head(v614_3) ? constant_9 : Space{});
    const Space v614_5 = subtract(constant_0,v614_4);
    Space v614_8;
    if (!v614_5.empty()) {
      const Path v615_6 = concat_path(p0,v613_11_head);
      Space v615_7_result;
      for (int v615_7_label = 1; v615_7_label <= 2; ++v615_7_label) {
        const Space v615_7_tail = child(v613_11_tail,v615_7_label);
        if (v615_7_tail.empty()) continue;
        const Path v615_7_head{v615_7_label};
        const Space v616_2 = singleton(v615_7_head);
        const Space v616_3 = intersect(constant_8,v616_2);
        const Space v616_4 = (has_head(v616_3) ? constant_9 : Space{});
        const Space v616_5 = subtract(constant_0,v616_4);
        Space v616_8;
        if (!v616_5.empty()) {
          const Path v617_6 = concat_path(v615_6,v615_7_head);
          const Space v617_7 = routine_122(c, v617_6, v615_7_tail);
          v616_8 = compose(v616_5,v617_7);
        }
        const Space v616_9 = intersect(constant_8,v616_2);
        const Space v616_10 = (has_head(v616_9) ? constant_9 : Space{});
        Space v616_12;
        if (!v616_10.empty()) {
          const Path v618_6 = concat_path(v615_6,v615_7_head);
          const Space v618_11 = routine_123(c, v618_6, v615_7_tail);
          v616_12 = compose(v616_10,v618_11);
        }
        const Space v616_13 = unite(v616_8,v616_12);
        v615_7_result = unite(v615_7_result,v616_13);
      }
      const Space v615_7 = std::move(v615_7_result);
      v614_8 = compose(v614_5,v615_7);
    }
    const Space v614_9 = intersect(constant_8,v614_2);
    const Space v614_10 = (has_head(v614_9) ? constant_9 : Space{});
    Space v614_12;
    if (!v614_10.empty()) {
      const Path v619_6 = concat_path(p0,v613_11_head);
      Space v619_11_result;
      for (int v619_11_label = 1; v619_11_label <= 2; ++v619_11_label) {
        const Space v619_11_tail = child(v613_11_tail,v619_11_label);
        if (v619_11_tail.empty()) continue;
        const Path v619_11_head{v619_11_label};
        const Space v620_2 = singleton(v619_11_head);
        const Space v620_3 = intersect(constant_8,v620_2);
        const Space v620_4 = (has_head(v620_3) ? constant_9 : Space{});
        const Space v620_5 = subtract(constant_0,v620_4);
        Space v620_7;
        if (!v620_5.empty()) {
          const Space v621_6 = routine_124(c, v619_11_head, v619_6, v619_11_tail);
          v620_7 = compose(v620_5,v621_6);
        }
        const Space v620_8 = intersect(constant_8,v620_2);
        const Space v620_9 = (has_head(v620_8) ? constant_9 : Space{});
        Space v620_11;
        if (!v620_9.empty()) {
          const Space v622_10 = routine_125(c, v619_11_head, v619_6, v619_11_tail);
          v620_11 = compose(v620_9,v622_10);
        }
        const Space v620_12 = unite(v620_7,v620_11);
        v619_11_result = unite(v619_11_result,v620_12);
      }
      const Space v619_11 = std::move(v619_11_result);
      v614_12 = compose(v614_10,v619_11);
    }
    const Space v614_13 = unite(v614_8,v614_12);
    v613_11_result = unite(v613_11_result,v614_13);
  }
  const Space v613_11 = std::move(v613_11_result);
  return v613_11;
}

static Space routine_58(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v623_12_result;
  for (int v623_12_label = 1; v623_12_label <= 2; ++v623_12_label) {
    const Space v623_12_tail = child(s0,v623_12_label);
    if (v623_12_tail.empty()) continue;
    const Path v623_12_head{v623_12_label};
    const Space v624_2 = singleton(v623_12_head);
    const Space v624_3 = intersect(constant_8,v624_2);
    const Space v624_4 = (has_head(v624_3) ? constant_9 : Space{});
    const Space v624_5 = subtract(constant_0,v624_4);
    Space v624_8;
    if (!v624_5.empty()) {
      const Path v625_6 = concat_path(p0,v623_12_head);
      Space v625_7_result;
      for (int v625_7_label = 1; v625_7_label <= 2; ++v625_7_label) {
        const Space v625_7_tail = child(v623_12_tail,v625_7_label);
        if (v625_7_tail.empty()) continue;
        const Path v625_7_head{v625_7_label};
        const Space v626_2 = singleton(v625_7_head);
        const Space v626_3 = intersect(constant_8,v626_2);
        const Space v626_4 = (has_head(v626_3) ? constant_9 : Space{});
        const Space v626_5 = subtract(constant_0,v626_4);
        Space v626_8;
        if (!v626_5.empty()) {
          const Path v627_6 = concat_path(v625_6,v625_7_head);
          const Space v627_7 = routine_126(c, v627_6, p1, v625_7_tail);
          v626_8 = compose(v626_5,v627_7);
        }
        const Space v626_9 = intersect(constant_8,v626_2);
        const Space v626_10 = (has_head(v626_9) ? constant_9 : Space{});
        Space v626_12;
        if (!v626_10.empty()) {
          const Path v628_6 = concat_path(v625_6,v625_7_head);
          const Space v628_11 = routine_127(c, v628_6, p1, v625_7_tail);
          v626_12 = compose(v626_10,v628_11);
        }
        const Space v626_13 = unite(v626_8,v626_12);
        v625_7_result = unite(v625_7_result,v626_13);
      }
      const Space v625_7 = std::move(v625_7_result);
      v624_8 = compose(v624_5,v625_7);
    }
    const Space v624_9 = intersect(constant_8,v624_2);
    const Space v624_10 = (has_head(v624_9) ? constant_9 : Space{});
    Space v624_12;
    if (!v624_10.empty()) {
      const Path v629_6 = concat_path(p0,v623_12_head);
      Space v629_11_result;
      for (int v629_11_label = 1; v629_11_label <= 2; ++v629_11_label) {
        const Space v629_11_tail = child(v623_12_tail,v629_11_label);
        if (v629_11_tail.empty()) continue;
        const Path v629_11_head{v629_11_label};
        const Space v630_2 = singleton(v629_11_head);
        const Space v630_3 = intersect(constant_8,v630_2);
        const Space v630_4 = (has_head(v630_3) ? constant_9 : Space{});
        const Space v630_5 = subtract(constant_0,v630_4);
        Space v630_8;
        if (!v630_5.empty()) {
          const Path v631_6 = concat_path(v629_6,v629_11_head);
          const Space v631_7 = routine_126(c, v631_6, p1, v629_11_tail);
          v630_8 = compose(v630_5,v631_7);
        }
        const Space v630_9 = intersect(constant_8,v630_2);
        const Space v630_10 = (has_head(v630_9) ? constant_9 : Space{});
        Space v630_12;
        if (!v630_10.empty()) {
          const Path v632_6 = concat_path(v629_6,v629_11_head);
          const Space v632_11 = routine_60(c, v632_6, p1, v629_11_tail);
          v630_12 = compose(v630_10,v632_11);
        }
        const Space v630_13 = unite(v630_8,v630_12);
        v629_11_result = unite(v629_11_result,v630_13);
      }
      const Space v629_11 = std::move(v629_11_result);
      v624_12 = compose(v624_10,v629_11);
    }
    const Space v624_13 = unite(v624_8,v624_12);
    v623_12_result = unite(v623_12_result,v624_13);
  }
  const Space v623_12 = std::move(v623_12_result);
  return v623_12;
}

static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v633_17_result;
  for (int v633_17_label = 1; v633_17_label <= 2; ++v633_17_label) {
    const Space v633_17_tail = child(s0,v633_17_label);
    if (v633_17_tail.empty()) continue;
    const Path v633_17_head{v633_17_label};
    const Space v634_2 = singleton(v633_17_head);
    const Space v634_3 = intersect(constant_8,v634_2);
    const Space v634_4 = (has_head(v634_3) ? constant_9 : Space{});
    const Space v634_5 = subtract(constant_0,v634_4);
    Space v634_8;
    if (!v634_5.empty()) {
      const Path v635_6 = concat_path(p0,v633_17_head);
      Space v635_7_result;
      for (int v635_7_label = 1; v635_7_label <= 2; ++v635_7_label) {
        const Space v635_7_tail = child(v633_17_tail,v635_7_label);
        if (v635_7_tail.empty()) continue;
        const Path v635_7_head{v635_7_label};
        const Space v636_2 = singleton(v635_7_head);
        const Space v636_3 = intersect(constant_8,v636_2);
        const Space v636_4 = (has_head(v636_3) ? constant_9 : Space{});
        const Space v636_5 = subtract(constant_0,v636_4);
        Space v636_8;
        if (!v636_5.empty()) {
          const Path v637_6 = concat_path(v635_6,v635_7_head);
          const Space v637_7 = routine_126(c, v637_6, p1, v635_7_tail);
          v636_8 = compose(v636_5,v637_7);
        }
        const Space v636_9 = intersect(constant_8,v636_2);
        const Space v636_10 = (has_head(v636_9) ? constant_9 : Space{});
        Space v636_12;
        if (!v636_10.empty()) {
          const Path v638_6 = concat_path(v635_6,v635_7_head);
          const Space v638_11 = routine_127(c, v638_6, p1, v635_7_tail);
          v636_12 = compose(v636_10,v638_11);
        }
        const Space v636_13 = unite(v636_8,v636_12);
        v635_7_result = unite(v635_7_result,v636_13);
      }
      const Space v635_7 = std::move(v635_7_result);
      v634_8 = compose(v634_5,v635_7);
    }
    const Space v634_9 = intersect(constant_8,v634_2);
    const Space v634_10 = (has_head(v634_9) ? constant_9 : Space{});
    Space v634_17;
    if (!v634_10.empty()) {
      const Path v639_6 = concat_path(p0,v633_17_head);
      Space v639_14;
      if (!constant_0.empty()) {
        const Space v640_11 = routine_92(c, constant_14, constant_15);
        const Space v640_12 = routine_93(c, constant_16, constant_17);
        const Space v640_13 = unite(v640_11,v640_12);
        v639_14 = compose(constant_0,v640_13);
      }
      const Space v639_15 = unwrap(v639_14,p1);
      Space v639_16_result;
      for (int v639_16_label = 1; v639_16_label <= 2; ++v639_16_label) {
        const Space v639_16_tail = child(v639_15,v639_16_label);
        if (v639_16_tail.empty()) continue;
        const Path v639_16_head{v639_16_label};
        const Space v641_2 = singleton(v639_16_head);
        const Space v641_3 = intersect(constant_8,v641_2);
        const Space v641_4 = (has_head(v641_3) ? constant_9 : Space{});
        const Space v641_5 = subtract(constant_0,v641_4);
        Space v641_7;
        if (!v641_5.empty()) {
          const Space v642_6 = routine_94(c, v639_16_head, v639_6, v639_16_tail, v633_17_tail);
          v641_7 = compose(v641_5,v642_6);
        }
        const Space v641_8 = intersect(constant_8,v641_2);
        const Space v641_9 = (has_head(v641_8) ? constant_9 : Space{});
        Space v641_11;
        if (!v641_9.empty()) {
          const Space v643_10 = routine_95(c, v639_16_head, v639_6, v639_16_tail, v633_17_tail);
          v641_11 = compose(v641_9,v643_10);
        }
        const Space v641_12 = unite(v641_7,v641_11);
        v639_16_result = unite(v639_16_result,v641_12);
      }
      const Space v639_16 = std::move(v639_16_result);
      v634_17 = compose(v634_10,v639_16);
    }
    const Space v634_18 = unite(v634_8,v634_17);
    v633_17_result = unite(v633_17_result,v634_18);
  }
  const Space v633_17 = std::move(v633_17_result);
  return v633_17;
}

static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v644_21;
  if (!constant_0.empty()) {
    Space v645_20;
    if (!constant_0.empty()) {
      const Space v646_7 = routine_128(c, constant_1, constant_18);
      const Space v646_10 = routine_128(c, constant_3, constant_19);
      const Space v646_11 = unite(v646_7,v646_10);
      const Space v646_14 = routine_129(c, constant_5, constant_20);
      const Space v646_15 = unite(v646_11,v646_14);
      const Space v646_18 = routine_130(c, constant_6, constant_21);
      const Space v646_19 = unite(v646_15,v646_18);
      v645_20 = compose(constant_0,v646_19);
    }
    v644_21 = compose(constant_0,v645_20);
  }
  const Space v644_22 = unwrap(v644_21,p1);
  Space v644_32_result;
  for (int v644_32_label = 1; v644_32_label <= 2; ++v644_32_label) {
    const Space v644_32_tail = child(v644_22,v644_32_label);
    if (v644_32_tail.empty()) continue;
    const Path v644_32_head{v644_32_label};
    const Space v647_2 = singleton(v644_32_head);
    const Space v647_3 = intersect(constant_8,v647_2);
    const Space v647_4 = (has_head(v647_3) ? constant_9 : Space{});
    const Space v647_5 = subtract(constant_0,v647_4);
    Space v647_7;
    if (!v647_5.empty()) {
      Space v648_6_result;
      for (int v648_6_label = 1; v648_6_label <= 2; ++v648_6_label) {
        const Space v648_6_tail = child(v644_32_tail,v648_6_label);
        if (v648_6_tail.empty()) continue;
        const Path v648_6_head{v648_6_label};
        const Space v649_2 = singleton(v648_6_head);
        const Space v649_3 = intersect(constant_8,v649_2);
        const Space v649_4 = (has_head(v649_3) ? constant_9 : Space{});
        const Space v649_5 = subtract(constant_0,v649_4);
        Space v649_8;
        if (!v649_5.empty()) {
          const Path v650_6 = concat_path(v644_32_head,v648_6_head);
          const Space v650_7 = routine_131(c, v650_6, p0, v648_6_tail, s0);
          v649_8 = compose(v649_5,v650_7);
        }
        const Space v649_9 = intersect(constant_8,v649_2);
        const Space v649_10 = (has_head(v649_9) ? constant_9 : Space{});
        Space v649_12;
        if (!v649_10.empty()) {
          const Path v651_6 = concat_path(v644_32_head,v648_6_head);
          const Space v651_11 = routine_132(c, v651_6, p0, v648_6_tail, s0);
          v649_12 = compose(v649_10,v651_11);
        }
        const Space v649_13 = unite(v649_8,v649_12);
        v648_6_result = unite(v648_6_result,v649_13);
      }
      const Space v648_6 = std::move(v648_6_result);
      v647_7 = compose(v647_5,v648_6);
    }
    const Space v647_8 = intersect(constant_8,v647_2);
    const Space v647_9 = (has_head(v647_8) ? constant_9 : Space{});
    Space v647_11;
    if (!v647_9.empty()) {
      Space v652_10_result;
      for (int v652_10_label = 1; v652_10_label <= 2; ++v652_10_label) {
        const Space v652_10_tail = child(v644_32_tail,v652_10_label);
        if (v652_10_tail.empty()) continue;
        const Path v652_10_head{v652_10_label};
        const Space v653_2 = singleton(v652_10_head);
        const Space v653_3 = intersect(constant_8,v653_2);
        const Space v653_4 = (has_head(v653_3) ? constant_9 : Space{});
        const Space v653_5 = subtract(constant_0,v653_4);
        Space v653_8;
        if (!v653_5.empty()) {
          const Path v654_6 = concat_path(v644_32_head,v652_10_head);
          const Space v654_7 = routine_131(c, v654_6, p0, v652_10_tail, s0);
          v653_8 = compose(v653_5,v654_7);
        }
        const Space v653_9 = intersect(constant_8,v653_2);
        const Space v653_10 = (has_head(v653_9) ? constant_9 : Space{});
        Space v653_12;
        if (!v653_10.empty()) {
          const Path v655_6 = concat_path(v644_32_head,v652_10_head);
          const Space v655_11 = routine_133(c, v655_6, p0, v652_10_tail, s0);
          v653_12 = compose(v653_10,v655_11);
        }
        const Space v653_13 = unite(v653_8,v653_12);
        v652_10_result = unite(v652_10_result,v653_13);
      }
      const Space v652_10 = std::move(v652_10_result);
      v647_11 = compose(v647_9,v652_10);
    }
    const Space v647_12 = unite(v647_7,v647_11);
    v644_32_result = unite(v644_32_result,v647_12);
  }
  const Space v644_32 = std::move(v644_32_result);
  return v644_32;
}

static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v656_12_result;
  for (int v656_12_label = 1; v656_12_label <= 2; ++v656_12_label) {
    const Space v656_12_tail = child(s0,v656_12_label);
    if (v656_12_tail.empty()) continue;
    const Path v656_12_head{v656_12_label};
    const Space v657_2 = singleton(v656_12_head);
    const Space v657_3 = intersect(constant_8,v657_2);
    const Space v657_4 = (has_head(v657_3) ? constant_9 : Space{});
    const Space v657_5 = subtract(constant_0,v657_4);
    Space v657_8;
    if (!v657_5.empty()) {
      const Path v658_6 = concat_path(p0,v656_12_head);
      Space v658_7_result;
      for (int v658_7_label = 1; v658_7_label <= 2; ++v658_7_label) {
        const Space v658_7_tail = child(v656_12_tail,v658_7_label);
        if (v658_7_tail.empty()) continue;
        const Path v658_7_head{v658_7_label};
        const Space v659_2 = singleton(v658_7_head);
        const Space v659_3 = intersect(constant_8,v659_2);
        const Space v659_4 = (has_head(v659_3) ? constant_9 : Space{});
        const Space v659_5 = subtract(constant_0,v659_4);
        Space v659_8;
        if (!v659_5.empty()) {
          const Path v660_6 = concat_path(v658_6,v658_7_head);
          const Space v660_7 = routine_134(c, v660_6, p1, v658_7_tail);
          v659_8 = compose(v659_5,v660_7);
        }
        const Space v659_9 = intersect(constant_8,v659_2);
        const Space v659_10 = (has_head(v659_9) ? constant_9 : Space{});
        Space v659_12;
        if (!v659_10.empty()) {
          const Path v661_6 = concat_path(v658_6,v658_7_head);
          const Space v661_11 = routine_135(c, v661_6, p1, v658_7_tail);
          v659_12 = compose(v659_10,v661_11);
        }
        const Space v659_13 = unite(v659_8,v659_12);
        v658_7_result = unite(v658_7_result,v659_13);
      }
      const Space v658_7 = std::move(v658_7_result);
      v657_8 = compose(v657_5,v658_7);
    }
    const Space v657_9 = intersect(constant_8,v657_2);
    const Space v657_10 = (has_head(v657_9) ? constant_9 : Space{});
    Space v657_12;
    if (!v657_10.empty()) {
      const Path v662_6 = concat_path(p0,v656_12_head);
      Space v662_11_result;
      for (int v662_11_label = 1; v662_11_label <= 2; ++v662_11_label) {
        const Space v662_11_tail = child(v656_12_tail,v662_11_label);
        if (v662_11_tail.empty()) continue;
        const Path v662_11_head{v662_11_label};
        const Space v663_2 = singleton(v662_11_head);
        const Space v663_3 = intersect(constant_8,v663_2);
        const Space v663_4 = (has_head(v663_3) ? constant_9 : Space{});
        const Space v663_5 = subtract(constant_0,v663_4);
        Space v663_8;
        if (!v663_5.empty()) {
          const Path v664_6 = concat_path(v662_6,v662_11_head);
          const Space v664_7 = routine_134(c, v664_6, p1, v662_11_tail);
          v663_8 = compose(v663_5,v664_7);
        }
        const Space v663_9 = intersect(constant_8,v663_2);
        const Space v663_10 = (has_head(v663_9) ? constant_9 : Space{});
        Space v663_12;
        if (!v663_10.empty()) {
          const Path v665_6 = concat_path(v662_6,v662_11_head);
          const Space v665_11 = routine_63(c, v665_6, p1, v662_11_tail);
          v663_12 = compose(v663_10,v665_11);
        }
        const Space v663_13 = unite(v663_8,v663_12);
        v662_11_result = unite(v662_11_result,v663_13);
      }
      const Space v662_11 = std::move(v662_11_result);
      v657_12 = compose(v657_10,v662_11);
    }
    const Space v657_13 = unite(v657_8,v657_12);
    v656_12_result = unite(v656_12_result,v657_13);
  }
  const Space v656_12 = std::move(v656_12_result);
  return v656_12;
}

static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v666_17_result;
  for (int v666_17_label = 1; v666_17_label <= 2; ++v666_17_label) {
    const Space v666_17_tail = child(s0,v666_17_label);
    if (v666_17_tail.empty()) continue;
    const Path v666_17_head{v666_17_label};
    const Space v667_2 = singleton(v666_17_head);
    const Space v667_3 = intersect(constant_8,v667_2);
    const Space v667_4 = (has_head(v667_3) ? constant_9 : Space{});
    const Space v667_5 = subtract(constant_0,v667_4);
    Space v667_8;
    if (!v667_5.empty()) {
      const Path v668_6 = concat_path(p0,v666_17_head);
      Space v668_7_result;
      for (int v668_7_label = 1; v668_7_label <= 2; ++v668_7_label) {
        const Space v668_7_tail = child(v666_17_tail,v668_7_label);
        if (v668_7_tail.empty()) continue;
        const Path v668_7_head{v668_7_label};
        const Space v669_2 = singleton(v668_7_head);
        const Space v669_3 = intersect(constant_8,v669_2);
        const Space v669_4 = (has_head(v669_3) ? constant_9 : Space{});
        const Space v669_5 = subtract(constant_0,v669_4);
        Space v669_8;
        if (!v669_5.empty()) {
          const Path v670_6 = concat_path(v668_6,v668_7_head);
          const Space v670_7 = routine_134(c, v670_6, p1, v668_7_tail);
          v669_8 = compose(v669_5,v670_7);
        }
        const Space v669_9 = intersect(constant_8,v669_2);
        const Space v669_10 = (has_head(v669_9) ? constant_9 : Space{});
        Space v669_12;
        if (!v669_10.empty()) {
          const Path v671_6 = concat_path(v668_6,v668_7_head);
          const Space v671_11 = routine_135(c, v671_6, p1, v668_7_tail);
          v669_12 = compose(v669_10,v671_11);
        }
        const Space v669_13 = unite(v669_8,v669_12);
        v668_7_result = unite(v668_7_result,v669_13);
      }
      const Space v668_7 = std::move(v668_7_result);
      v667_8 = compose(v667_5,v668_7);
    }
    const Space v667_9 = intersect(constant_8,v667_2);
    const Space v667_10 = (has_head(v667_9) ? constant_9 : Space{});
    Space v667_20;
    if (!v667_10.empty()) {
      Space v672_14;
      if (!constant_0.empty()) {
        const Space v673_11 = routine_98(c, constant_14, constant_15);
        const Space v673_12 = routine_99(c, constant_16, constant_17);
        const Space v673_13 = unite(v673_11,v673_12);
        v672_14 = compose(constant_0,v673_13);
      }
      const Space v672_15 = unwrap(v672_14,p1);
      const Space v672_16 = unwrap(v672_15,p0);
      const Space v672_17 = unwrap(v672_16,v666_17_head);
      const Space v672_18 = unwrap(v672_17,p1);
      Space v672_19_result;
      for (int v672_19_label = 1; v672_19_label <= 2; ++v672_19_label) {
        const Space v672_19_tail = child(v672_18,v672_19_label);
        if (v672_19_tail.empty()) continue;
        const Path v672_19_head{v672_19_label};
        const Space v674_2 = singleton(v672_19_head);
        const Space v674_3 = intersect(constant_8,v674_2);
        const Space v674_4 = (has_head(v674_3) ? constant_9 : Space{});
        const Space v674_5 = subtract(constant_0,v674_4);
        Space v674_7;
        if (!v674_5.empty()) {
          const Space v675_6 = routine_100(c, v672_19_head, v672_19_tail, v666_17_tail);
          v674_7 = compose(v674_5,v675_6);
        }
        const Space v674_8 = intersect(constant_8,v674_2);
        const Space v674_9 = (has_head(v674_8) ? constant_9 : Space{});
        Space v674_11;
        if (!v674_9.empty()) {
          const Space v676_10 = routine_101(c, v672_19_head, v672_19_tail, v666_17_tail);
          v674_11 = compose(v674_9,v676_10);
        }
        const Space v674_12 = unite(v674_7,v674_11);
        v672_19_result = unite(v672_19_result,v674_12);
      }
      const Space v672_19 = std::move(v672_19_result);
      v667_20 = compose(v667_10,v672_19);
    }
    const Space v667_21 = unite(v667_8,v667_20);
    v666_17_result = unite(v666_17_result,v667_21);
  }
  const Space v666_17 = std::move(v666_17_result);
  return v666_17;
}

static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v677_21;
  if (!constant_0.empty()) {
    Space v678_20;
    if (!constant_0.empty()) {
      const Space v679_7 = routine_136(c, constant_1, constant_18);
      const Space v679_10 = routine_136(c, constant_3, constant_19);
      const Space v679_11 = unite(v679_7,v679_10);
      const Space v679_14 = routine_137(c, constant_5, constant_20);
      const Space v679_15 = unite(v679_11,v679_14);
      const Space v679_18 = routine_138(c, constant_6, constant_21);
      const Space v679_19 = unite(v679_15,v679_18);
      v678_20 = compose(constant_0,v679_19);
    }
    v677_21 = compose(constant_0,v678_20);
  }
  const Space v677_22 = unwrap(v677_21,p1);
  const Space v677_23 = unwrap(v677_22,p0);
  const Space v677_24 = unwrap(v677_23,p1);
  Space v677_34_result;
  for (int v677_34_label = 1; v677_34_label <= 2; ++v677_34_label) {
    const Space v677_34_tail = child(v677_24,v677_34_label);
    if (v677_34_tail.empty()) continue;
    const Path v677_34_head{v677_34_label};
    const Space v680_2 = singleton(v677_34_head);
    const Space v680_3 = intersect(constant_8,v680_2);
    const Space v680_4 = (has_head(v680_3) ? constant_9 : Space{});
    const Space v680_5 = subtract(constant_0,v680_4);
    Space v680_7;
    if (!v680_5.empty()) {
      Space v681_6_result;
      for (int v681_6_label = 1; v681_6_label <= 2; ++v681_6_label) {
        const Space v681_6_tail = child(v677_34_tail,v681_6_label);
        if (v681_6_tail.empty()) continue;
        const Path v681_6_head{v681_6_label};
        const Space v682_2 = singleton(v681_6_head);
        const Space v682_3 = intersect(constant_8,v682_2);
        const Space v682_4 = (has_head(v682_3) ? constant_9 : Space{});
        const Space v682_5 = subtract(constant_0,v682_4);
        Space v682_8;
        if (!v682_5.empty()) {
          const Path v683_6 = concat_path(v677_34_head,v681_6_head);
          const Space v683_7 = routine_139(c, v683_6, v681_6_tail, s0);
          v682_8 = compose(v682_5,v683_7);
        }
        const Space v682_9 = intersect(constant_8,v682_2);
        const Space v682_10 = (has_head(v682_9) ? constant_9 : Space{});
        Space v682_12;
        if (!v682_10.empty()) {
          const Path v684_6 = concat_path(v677_34_head,v681_6_head);
          const Space v684_11 = routine_140(c, v684_6, v681_6_tail, s0);
          v682_12 = compose(v682_10,v684_11);
        }
        const Space v682_13 = unite(v682_8,v682_12);
        v681_6_result = unite(v681_6_result,v682_13);
      }
      const Space v681_6 = std::move(v681_6_result);
      v680_7 = compose(v680_5,v681_6);
    }
    const Space v680_8 = intersect(constant_8,v680_2);
    const Space v680_9 = (has_head(v680_8) ? constant_9 : Space{});
    Space v680_11;
    if (!v680_9.empty()) {
      Space v685_10_result;
      for (int v685_10_label = 1; v685_10_label <= 2; ++v685_10_label) {
        const Space v685_10_tail = child(v677_34_tail,v685_10_label);
        if (v685_10_tail.empty()) continue;
        const Path v685_10_head{v685_10_label};
        const Space v686_2 = singleton(v685_10_head);
        const Space v686_3 = intersect(constant_8,v686_2);
        const Space v686_4 = (has_head(v686_3) ? constant_9 : Space{});
        const Space v686_5 = subtract(constant_0,v686_4);
        Space v686_8;
        if (!v686_5.empty()) {
          const Path v687_6 = concat_path(v677_34_head,v685_10_head);
          const Space v687_7 = routine_139(c, v687_6, v685_10_tail, s0);
          v686_8 = compose(v686_5,v687_7);
        }
        const Space v686_9 = intersect(constant_8,v686_2);
        const Space v686_10 = (has_head(v686_9) ? constant_9 : Space{});
        Space v686_12;
        if (!v686_10.empty()) {
          const Path v688_6 = concat_path(v677_34_head,v685_10_head);
          const Space v688_11 = routine_141(c, v688_6, v685_10_tail, s0);
          v686_12 = compose(v686_10,v688_11);
        }
        const Space v686_13 = unite(v686_8,v686_12);
        v685_10_result = unite(v685_10_result,v686_13);
      }
      const Space v685_10 = std::move(v685_10_result);
      v680_11 = compose(v680_9,v685_10);
    }
    const Space v680_12 = unite(v680_7,v680_11);
    v677_34_result = unite(v677_34_result,v680_12);
  }
  const Space v677_34 = std::move(v677_34_result);
  return v677_34;
}

static Space routine_64(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  Space v689_5_result;
  for (int v689_5_label = 1; v689_5_label <= 2; ++v689_5_label) {
    const Space v689_5_tail = child(s0,v689_5_label);
    if (v689_5_tail.empty()) continue;
    const Path v689_5_head{v689_5_label};
    const Space v690_2 = Space{};
    v689_5_result = unite(v689_5_result,v690_2);
  }
  const Space v689_5 = std::move(v689_5_result);
  return v689_5;
}

static Space routine_65(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Path v691_6 = concat_path(p2,p3);
  Space v691_13_result;
  for (int v691_13_label = 1; v691_13_label <= 2; ++v691_13_label) {
    const Space v691_13_tail = child(s0,v691_13_label);
    if (v691_13_tail.empty()) continue;
    const Path v691_13_head{v691_13_label};
    const Space v692_2 = singleton(v691_13_head);
    const Space v692_3 = intersect(constant_8,v692_2);
    const Space v692_4 = (has_head(v692_3) ? constant_9 : Space{});
    Space v692_11;
    if (!v692_4.empty()) {
      const Path v693_5 = concat_path(p0,v691_13_head);
      const Path v693_6 = concat_path(v691_6,v693_5);
      const Space v693_7 = singleton(v693_6);
      const Space v693_8 = routine_35(c, p1, v693_7);
      Space v693_9_result;
      for (int v693_9_label = 1; v693_9_label <= 2; ++v693_9_label) {
        const Space v693_9_tail = child(v693_8,v693_9_label);
        if (v693_9_tail.empty()) continue;
        const Path v693_9_head{v693_9_label};
        const Space v694_2 = singleton(v693_9_head);
        const Space v694_3 = intersect(constant_8,v694_2);
        const Space v694_4 = (has_head(v694_3) ? constant_9 : Space{});
        const Space v694_5 = subtract(constant_0,v694_4);
        Space v694_7;
        if (!v694_5.empty()) {
          const Space v695_6 = routine_36(c, v693_9_head, p1, v693_9_tail);
          v694_7 = compose(v694_5,v695_6);
        }
        const Space v694_8 = intersect(constant_8,v694_2);
        const Space v694_9 = (has_head(v694_8) ? constant_9 : Space{});
        Space v694_11;
        if (!v694_9.empty()) {
          const Space v696_10 = routine_37(c, v693_9_head, p1, v693_9_tail);
          v694_11 = compose(v694_9,v696_10);
        }
        const Space v694_12 = unite(v694_7,v694_11);
        v693_9_result = unite(v693_9_result,v694_12);
      }
      const Space v693_9 = std::move(v693_9_result);
      Space v693_10_result;
      for (int v693_10_label = 1; v693_10_label <= 2; ++v693_10_label) {
        const Space v693_10_tail = child(v693_9,v693_10_label);
        if (v693_10_tail.empty()) continue;
        const Path v693_10_head{v693_10_label};
        const Space v697_2 = singleton(v693_10_head);
        const Space v697_3 = intersect(constant_8,v697_2);
        const Space v697_4 = (has_head(v697_3) ? constant_9 : Space{});
        const Space v697_5 = subtract(constant_0,v697_4);
        Space v697_7;
        if (!v697_5.empty()) {
          const Space v698_6 = routine_38(c, v693_10_head, p1, v693_10_tail);
          v697_7 = compose(v697_5,v698_6);
        }
        const Space v697_8 = intersect(constant_8,v697_2);
        const Space v697_9 = (has_head(v697_8) ? constant_9 : Space{});
        Space v697_11;
        if (!v697_9.empty()) {
          const Space v699_10 = routine_39(c, v693_10_head, p1, v693_10_tail);
          v697_11 = compose(v697_9,v699_10);
        }
        const Space v697_12 = unite(v697_7,v697_11);
        v693_10_result = unite(v693_10_result,v697_12);
      }
      const Space v693_10 = std::move(v693_10_result);
      v692_11 = compose(v692_4,v693_10);
    }
    v691_13_result = unite(v691_13_result,v692_11);
  }
  const Space v691_13 = std::move(v691_13_result);
  return v691_13;
}

static Space routine_66(Context& c, const Path& p0, const Space& s0) {
  Space v700_11_result;
  for (int v700_11_label = 1; v700_11_label <= 2; ++v700_11_label) {
    const Space v700_11_tail = child(s0,v700_11_label);
    if (v700_11_tail.empty()) continue;
    const Path v700_11_head{v700_11_label};
    const Space v701_2 = singleton(v700_11_head);
    const Space v701_3 = intersect(constant_8,v701_2);
    const Space v701_4 = (has_head(v701_3) ? constant_9 : Space{});
    const Space v701_5 = subtract(constant_0,v701_4);
    Space v701_8;
    if (!v701_5.empty()) {
      const Path v702_6 = concat_path(p0,v700_11_head);
      Space v702_7_result;
      for (int v702_7_label = 1; v702_7_label <= 2; ++v702_7_label) {
        const Space v702_7_tail = child(v700_11_tail,v702_7_label);
        if (v702_7_tail.empty()) continue;
        const Path v702_7_head{v702_7_label};
        const Space v703_2 = singleton(v702_7_head);
        const Space v703_3 = intersect(constant_8,v703_2);
        const Space v703_4 = (has_head(v703_3) ? constant_9 : Space{});
        const Space v703_5 = subtract(constant_0,v703_4);
        Space v703_8;
        if (!v703_5.empty()) {
          const Path v704_6 = concat_path(v702_6,v702_7_head);
          const Space v704_7 = routine_142(c, v704_6, v702_7_tail);
          v703_8 = compose(v703_5,v704_7);
        }
        const Space v703_9 = intersect(constant_8,v703_2);
        const Space v703_10 = (has_head(v703_9) ? constant_9 : Space{});
        Space v703_12;
        if (!v703_10.empty()) {
          const Path v705_6 = concat_path(v702_6,v702_7_head);
          const Space v705_11 = routine_143(c, v705_6, v702_7_tail);
          v703_12 = compose(v703_10,v705_11);
        }
        const Space v703_13 = unite(v703_8,v703_12);
        v702_7_result = unite(v702_7_result,v703_13);
      }
      const Space v702_7 = std::move(v702_7_result);
      v701_8 = compose(v701_5,v702_7);
    }
    const Space v701_9 = intersect(constant_8,v701_2);
    const Space v701_10 = (has_head(v701_9) ? constant_9 : Space{});
    Space v701_12;
    if (!v701_10.empty()) {
      const Path v706_6 = concat_path(p0,v700_11_head);
      Space v706_11_result;
      for (int v706_11_label = 1; v706_11_label <= 2; ++v706_11_label) {
        const Space v706_11_tail = child(v700_11_tail,v706_11_label);
        if (v706_11_tail.empty()) continue;
        const Path v706_11_head{v706_11_label};
        const Space v707_2 = singleton(v706_11_head);
        const Space v707_3 = intersect(constant_8,v707_2);
        const Space v707_4 = (has_head(v707_3) ? constant_9 : Space{});
        const Space v707_5 = subtract(constant_0,v707_4);
        Space v707_8;
        if (!v707_5.empty()) {
          const Path v708_6 = concat_path(v706_6,v706_11_head);
          const Space v708_7 = routine_142(c, v708_6, v706_11_tail);
          v707_8 = compose(v707_5,v708_7);
        }
        const Space v707_9 = intersect(constant_8,v707_2);
        const Space v707_10 = (has_head(v707_9) ? constant_9 : Space{});
        Space v707_12;
        if (!v707_10.empty()) {
          const Path v709_6 = concat_path(v706_6,v706_11_head);
          const Space v709_11 = routine_68(c, v709_6, v706_11_tail);
          v707_12 = compose(v707_10,v709_11);
        }
        const Space v707_13 = unite(v707_8,v707_12);
        v706_11_result = unite(v706_11_result,v707_13);
      }
      const Space v706_11 = std::move(v706_11_result);
      v701_12 = compose(v701_10,v706_11);
    }
    const Space v701_13 = unite(v701_8,v701_12);
    v700_11_result = unite(v700_11_result,v701_13);
  }
  const Space v700_11 = std::move(v700_11_result);
  return v700_11;
}

static Space routine_67(Context& c, const Path& p0, const Space& s0) {
  Space v710_8_result;
  for (int v710_8_label = 1; v710_8_label <= 2; ++v710_8_label) {
    const Space v710_8_tail = child(s0,v710_8_label);
    if (v710_8_tail.empty()) continue;
    const Path v710_8_head{v710_8_label};
    const Space v711_2 = singleton(v710_8_head);
    const Space v711_3 = intersect(constant_8,v711_2);
    const Space v711_4 = (has_head(v711_3) ? constant_9 : Space{});
    const Space v711_5 = subtract(constant_0,v711_4);
    Space v711_8;
    if (!v711_5.empty()) {
      const Path v712_6 = concat_path(p0,v710_8_head);
      Space v712_7_result;
      for (int v712_7_label = 1; v712_7_label <= 2; ++v712_7_label) {
        const Space v712_7_tail = child(v710_8_tail,v712_7_label);
        if (v712_7_tail.empty()) continue;
        const Path v712_7_head{v712_7_label};
        const Space v713_2 = singleton(v712_7_head);
        const Space v713_3 = intersect(constant_8,v713_2);
        const Space v713_4 = (has_head(v713_3) ? constant_9 : Space{});
        const Space v713_5 = subtract(constant_0,v713_4);
        Space v713_8;
        if (!v713_5.empty()) {
          const Path v714_6 = concat_path(v712_6,v712_7_head);
          const Space v714_7 = routine_142(c, v714_6, v712_7_tail);
          v713_8 = compose(v713_5,v714_7);
        }
        const Space v713_9 = intersect(constant_8,v713_2);
        const Space v713_10 = (has_head(v713_9) ? constant_9 : Space{});
        Space v713_12;
        if (!v713_10.empty()) {
          const Path v715_6 = concat_path(v712_6,v712_7_head);
          const Space v715_11 = routine_143(c, v715_6, v712_7_tail);
          v713_12 = compose(v713_10,v715_11);
        }
        const Space v713_13 = unite(v713_8,v713_12);
        v712_7_result = unite(v712_7_result,v713_13);
      }
      const Space v712_7 = std::move(v712_7_result);
      v711_8 = compose(v711_5,v712_7);
    }
    const Space v711_9 = intersect(constant_8,v711_2);
    const Space v711_10 = (has_head(v711_9) ? constant_9 : Space{});
    const Space v711_11 = compose(v711_10,v710_8_tail);
    const Space v711_12 = unite(v711_8,v711_11);
    v710_8_result = unite(v710_8_result,v711_12);
  }
  const Space v710_8 = std::move(v710_8_result);
  return v710_8;
}

static Space routine_68(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_69(Context& c, const Path& p0, const Space& s0) {
  Space v717_11_result;
  for (int v717_11_label = 1; v717_11_label <= 2; ++v717_11_label) {
    const Space v717_11_tail = child(s0,v717_11_label);
    if (v717_11_tail.empty()) continue;
    const Path v717_11_head{v717_11_label};
    const Space v718_2 = singleton(v717_11_head);
    const Space v718_3 = intersect(constant_8,v718_2);
    const Space v718_4 = (has_head(v718_3) ? constant_9 : Space{});
    const Space v718_5 = subtract(constant_0,v718_4);
    Space v718_8;
    if (!v718_5.empty()) {
      const Path v719_6 = concat_path(p0,v717_11_head);
      Space v719_7_result;
      for (int v719_7_label = 1; v719_7_label <= 2; ++v719_7_label) {
        const Space v719_7_tail = child(v717_11_tail,v719_7_label);
        if (v719_7_tail.empty()) continue;
        const Path v719_7_head{v719_7_label};
        const Space v720_2 = singleton(v719_7_head);
        const Space v720_3 = intersect(constant_8,v720_2);
        const Space v720_4 = (has_head(v720_3) ? constant_9 : Space{});
        const Space v720_5 = subtract(constant_0,v720_4);
        Space v720_8;
        if (!v720_5.empty()) {
          const Path v721_6 = concat_path(v719_6,v719_7_head);
          const Space v721_7 = routine_144(c, v721_6, v719_7_tail);
          v720_8 = compose(v720_5,v721_7);
        }
        const Space v720_9 = intersect(constant_8,v720_2);
        const Space v720_10 = (has_head(v720_9) ? constant_9 : Space{});
        Space v720_12;
        if (!v720_10.empty()) {
          const Path v722_6 = concat_path(v719_6,v719_7_head);
          const Space v722_11 = routine_145(c, v722_6, v719_7_tail);
          v720_12 = compose(v720_10,v722_11);
        }
        const Space v720_13 = unite(v720_8,v720_12);
        v719_7_result = unite(v719_7_result,v720_13);
      }
      const Space v719_7 = std::move(v719_7_result);
      v718_8 = compose(v718_5,v719_7);
    }
    const Space v718_9 = intersect(constant_8,v718_2);
    const Space v718_10 = (has_head(v718_9) ? constant_9 : Space{});
    Space v718_12;
    if (!v718_10.empty()) {
      const Path v723_6 = concat_path(p0,v717_11_head);
      Space v723_11_result;
      for (int v723_11_label = 1; v723_11_label <= 2; ++v723_11_label) {
        const Space v723_11_tail = child(v717_11_tail,v723_11_label);
        if (v723_11_tail.empty()) continue;
        const Path v723_11_head{v723_11_label};
        const Space v724_2 = singleton(v723_11_head);
        const Space v724_3 = intersect(constant_8,v724_2);
        const Space v724_4 = (has_head(v724_3) ? constant_9 : Space{});
        const Space v724_5 = subtract(constant_0,v724_4);
        Space v724_8;
        if (!v724_5.empty()) {
          const Path v725_6 = concat_path(v723_6,v723_11_head);
          const Space v725_7 = routine_144(c, v725_6, v723_11_tail);
          v724_8 = compose(v724_5,v725_7);
        }
        const Space v724_9 = intersect(constant_8,v724_2);
        const Space v724_10 = (has_head(v724_9) ? constant_9 : Space{});
        Space v724_12;
        if (!v724_10.empty()) {
          const Path v726_6 = concat_path(v723_6,v723_11_head);
          const Space v726_11 = routine_71(c, v726_6, v723_11_tail);
          v724_12 = compose(v724_10,v726_11);
        }
        const Space v724_13 = unite(v724_8,v724_12);
        v723_11_result = unite(v723_11_result,v724_13);
      }
      const Space v723_11 = std::move(v723_11_result);
      v718_12 = compose(v718_10,v723_11);
    }
    const Space v718_13 = unite(v718_8,v718_12);
    v717_11_result = unite(v717_11_result,v718_13);
  }
  const Space v717_11 = std::move(v717_11_result);
  return v717_11;
}

static Space routine_70(Context& c, const Path& p0, const Space& s0) {
  Space v727_11_result;
  for (int v727_11_label = 1; v727_11_label <= 2; ++v727_11_label) {
    const Space v727_11_tail = child(s0,v727_11_label);
    if (v727_11_tail.empty()) continue;
    const Path v727_11_head{v727_11_label};
    const Space v728_2 = singleton(v727_11_head);
    const Space v728_3 = intersect(constant_8,v728_2);
    const Space v728_4 = (has_head(v728_3) ? constant_9 : Space{});
    const Space v728_5 = subtract(constant_0,v728_4);
    Space v728_8;
    if (!v728_5.empty()) {
      const Path v729_6 = concat_path(p0,v727_11_head);
      Space v729_7_result;
      for (int v729_7_label = 1; v729_7_label <= 2; ++v729_7_label) {
        const Space v729_7_tail = child(v727_11_tail,v729_7_label);
        if (v729_7_tail.empty()) continue;
        const Path v729_7_head{v729_7_label};
        const Space v730_2 = singleton(v729_7_head);
        const Space v730_3 = intersect(constant_8,v730_2);
        const Space v730_4 = (has_head(v730_3) ? constant_9 : Space{});
        const Space v730_5 = subtract(constant_0,v730_4);
        Space v730_8;
        if (!v730_5.empty()) {
          const Path v731_6 = concat_path(v729_6,v729_7_head);
          const Space v731_7 = routine_144(c, v731_6, v729_7_tail);
          v730_8 = compose(v730_5,v731_7);
        }
        const Space v730_9 = intersect(constant_8,v730_2);
        const Space v730_10 = (has_head(v730_9) ? constant_9 : Space{});
        Space v730_12;
        if (!v730_10.empty()) {
          const Path v732_6 = concat_path(v729_6,v729_7_head);
          const Space v732_11 = routine_145(c, v732_6, v729_7_tail);
          v730_12 = compose(v730_10,v732_11);
        }
        const Space v730_13 = unite(v730_8,v730_12);
        v729_7_result = unite(v729_7_result,v730_13);
      }
      const Space v729_7 = std::move(v729_7_result);
      v728_8 = compose(v728_5,v729_7);
    }
    const Space v728_9 = intersect(constant_8,v728_2);
    const Space v728_10 = (has_head(v728_9) ? constant_9 : Space{});
    Space v728_12;
    if (!v728_10.empty()) {
      const Path v733_6 = concat_path(p0,v727_11_head);
      Space v733_11_result;
      for (int v733_11_label = 1; v733_11_label <= 2; ++v733_11_label) {
        const Space v733_11_tail = child(v727_11_tail,v733_11_label);
        if (v733_11_tail.empty()) continue;
        const Path v733_11_head{v733_11_label};
        const Space v734_2 = singleton(v733_11_head);
        const Space v734_3 = intersect(constant_8,v734_2);
        const Space v734_4 = (has_head(v734_3) ? constant_9 : Space{});
        const Space v734_5 = subtract(constant_0,v734_4);
        Space v734_7;
        if (!v734_5.empty()) {
          const Space v735_6 = routine_106(c, v733_11_head, v733_6, v733_11_tail);
          v734_7 = compose(v734_5,v735_6);
        }
        const Space v734_8 = intersect(constant_8,v734_2);
        const Space v734_9 = (has_head(v734_8) ? constant_9 : Space{});
        Space v734_11;
        if (!v734_9.empty()) {
          const Space v736_10 = routine_107(c, v733_11_head, v733_6, v733_11_tail);
          v734_11 = compose(v734_9,v736_10);
        }
        const Space v734_12 = unite(v734_7,v734_11);
        v733_11_result = unite(v733_11_result,v734_12);
      }
      const Space v733_11 = std::move(v733_11_result);
      v728_12 = compose(v728_10,v733_11);
    }
    const Space v728_13 = unite(v728_8,v728_12);
    v727_11_result = unite(v727_11_result,v728_13);
  }
  const Space v727_11 = std::move(v727_11_result);
  return v727_11;
}

static Space routine_71(Context& c, const Path& p0, const Space& s0) {
  Space v737_11_result;
  for (int v737_11_label = 1; v737_11_label <= 2; ++v737_11_label) {
    const Space v737_11_tail = child(s0,v737_11_label);
    if (v737_11_tail.empty()) continue;
    const Path v737_11_head{v737_11_label};
    const Space v738_2 = singleton(v737_11_head);
    const Space v738_3 = intersect(constant_8,v738_2);
    const Space v738_4 = (has_head(v738_3) ? constant_9 : Space{});
    const Space v738_5 = subtract(constant_0,v738_4);
    Space v738_7;
    if (!v738_5.empty()) {
      Space v739_6_result;
      for (int v739_6_label = 1; v739_6_label <= 2; ++v739_6_label) {
        const Space v739_6_tail = child(v737_11_tail,v739_6_label);
        if (v739_6_tail.empty()) continue;
        const Path v739_6_head{v739_6_label};
        const Space v740_2 = singleton(v739_6_head);
        const Space v740_3 = intersect(constant_8,v740_2);
        const Space v740_4 = (has_head(v740_3) ? constant_9 : Space{});
        const Space v740_5 = subtract(constant_0,v740_4);
        Space v740_8;
        if (!v740_5.empty()) {
          const Path v741_6 = concat_path(v737_11_head,v739_6_head);
          const Space v741_7 = routine_146(c, v741_6, p0, v739_6_tail);
          v740_8 = compose(v740_5,v741_7);
        }
        const Space v740_9 = intersect(constant_8,v740_2);
        const Space v740_10 = (has_head(v740_9) ? constant_9 : Space{});
        Space v740_12;
        if (!v740_10.empty()) {
          const Path v742_6 = concat_path(v737_11_head,v739_6_head);
          const Space v742_11 = routine_147(c, v742_6, p0, v739_6_tail);
          v740_12 = compose(v740_10,v742_11);
        }
        const Space v740_13 = unite(v740_8,v740_12);
        v739_6_result = unite(v739_6_result,v740_13);
      }
      const Space v739_6 = std::move(v739_6_result);
      v738_7 = compose(v738_5,v739_6);
    }
    const Space v738_8 = intersect(constant_8,v738_2);
    const Space v738_9 = (has_head(v738_8) ? constant_9 : Space{});
    Space v738_11;
    if (!v738_9.empty()) {
      Space v743_10_result;
      for (int v743_10_label = 1; v743_10_label <= 2; ++v743_10_label) {
        const Space v743_10_tail = child(v737_11_tail,v743_10_label);
        if (v743_10_tail.empty()) continue;
        const Path v743_10_head{v743_10_label};
        const Space v744_2 = singleton(v743_10_head);
        const Space v744_3 = intersect(constant_8,v744_2);
        const Space v744_4 = (has_head(v744_3) ? constant_9 : Space{});
        const Space v744_5 = subtract(constant_0,v744_4);
        Space v744_8;
        if (!v744_5.empty()) {
          const Path v745_6 = concat_path(v737_11_head,v743_10_head);
          const Space v745_7 = routine_146(c, v745_6, p0, v743_10_tail);
          v744_8 = compose(v744_5,v745_7);
        }
        const Space v744_9 = intersect(constant_8,v744_2);
        const Space v744_10 = (has_head(v744_9) ? constant_9 : Space{});
        Space v744_12;
        if (!v744_10.empty()) {
          const Path v746_6 = concat_path(v737_11_head,v743_10_head);
          const Space v746_11 = routine_148(c, v746_6, p0, v743_10_tail);
          v744_12 = compose(v744_10,v746_11);
        }
        const Space v744_13 = unite(v744_8,v744_12);
        v743_10_result = unite(v743_10_result,v744_13);
      }
      const Space v743_10 = std::move(v743_10_result);
      v738_11 = compose(v738_9,v743_10);
    }
    const Space v738_12 = unite(v738_7,v738_11);
    v737_11_result = unite(v737_11_result,v738_12);
  }
  const Space v737_11 = std::move(v737_11_result);
  return v737_11;
}

static Space routine_72(Context& c, const Path& p0, const Space& s0) {
  Space v747_11_result;
  for (int v747_11_label = 1; v747_11_label <= 2; ++v747_11_label) {
    const Space v747_11_tail = child(s0,v747_11_label);
    if (v747_11_tail.empty()) continue;
    const Path v747_11_head{v747_11_label};
    const Space v748_2 = singleton(v747_11_head);
    const Space v748_3 = intersect(constant_8,v748_2);
    const Space v748_4 = (has_head(v748_3) ? constant_9 : Space{});
    const Space v748_5 = subtract(constant_0,v748_4);
    Space v748_8;
    if (!v748_5.empty()) {
      const Path v749_6 = concat_path(p0,v747_11_head);
      Space v749_7_result;
      for (int v749_7_label = 1; v749_7_label <= 2; ++v749_7_label) {
        const Space v749_7_tail = child(v747_11_tail,v749_7_label);
        if (v749_7_tail.empty()) continue;
        const Path v749_7_head{v749_7_label};
        const Space v750_2 = singleton(v749_7_head);
        const Space v750_3 = intersect(constant_8,v750_2);
        const Space v750_4 = (has_head(v750_3) ? constant_9 : Space{});
        const Space v750_5 = subtract(constant_0,v750_4);
        Space v750_8;
        if (!v750_5.empty()) {
          const Path v751_6 = concat_path(v749_6,v749_7_head);
          const Space v751_7 = routine_149(c, v751_6, v749_7_tail);
          v750_8 = compose(v750_5,v751_7);
        }
        const Space v750_9 = intersect(constant_8,v750_2);
        const Space v750_10 = (has_head(v750_9) ? constant_9 : Space{});
        Space v750_12;
        if (!v750_10.empty()) {
          const Path v752_6 = concat_path(v749_6,v749_7_head);
          const Space v752_11 = routine_150(c, v752_6, v749_7_tail);
          v750_12 = compose(v750_10,v752_11);
        }
        const Space v750_13 = unite(v750_8,v750_12);
        v749_7_result = unite(v749_7_result,v750_13);
      }
      const Space v749_7 = std::move(v749_7_result);
      v748_8 = compose(v748_5,v749_7);
    }
    const Space v748_9 = intersect(constant_8,v748_2);
    const Space v748_10 = (has_head(v748_9) ? constant_9 : Space{});
    Space v748_12;
    if (!v748_10.empty()) {
      const Path v753_6 = concat_path(p0,v747_11_head);
      Space v753_11_result;
      for (int v753_11_label = 1; v753_11_label <= 2; ++v753_11_label) {
        const Space v753_11_tail = child(v747_11_tail,v753_11_label);
        if (v753_11_tail.empty()) continue;
        const Path v753_11_head{v753_11_label};
        const Space v754_2 = singleton(v753_11_head);
        const Space v754_3 = intersect(constant_8,v754_2);
        const Space v754_4 = (has_head(v754_3) ? constant_9 : Space{});
        const Space v754_5 = subtract(constant_0,v754_4);
        Space v754_8;
        if (!v754_5.empty()) {
          const Path v755_6 = concat_path(v753_6,v753_11_head);
          const Space v755_7 = routine_149(c, v755_6, v753_11_tail);
          v754_8 = compose(v754_5,v755_7);
        }
        const Space v754_9 = intersect(constant_8,v754_2);
        const Space v754_10 = (has_head(v754_9) ? constant_9 : Space{});
        Space v754_12;
        if (!v754_10.empty()) {
          const Path v756_6 = concat_path(v753_6,v753_11_head);
          const Space v756_11 = routine_74(c, v756_6, v753_11_tail);
          v754_12 = compose(v754_10,v756_11);
        }
        const Space v754_13 = unite(v754_8,v754_12);
        v753_11_result = unite(v753_11_result,v754_13);
      }
      const Space v753_11 = std::move(v753_11_result);
      v748_12 = compose(v748_10,v753_11);
    }
    const Space v748_13 = unite(v748_8,v748_12);
    v747_11_result = unite(v747_11_result,v748_13);
  }
  const Space v747_11 = std::move(v747_11_result);
  return v747_11;
}

static Space routine_73(Context& c, const Path& p0, const Space& s0) {
  Space v757_8_result;
  for (int v757_8_label = 1; v757_8_label <= 2; ++v757_8_label) {
    const Space v757_8_tail = child(s0,v757_8_label);
    if (v757_8_tail.empty()) continue;
    const Path v757_8_head{v757_8_label};
    const Space v758_2 = singleton(v757_8_head);
    const Space v758_3 = intersect(constant_8,v758_2);
    const Space v758_4 = (has_head(v758_3) ? constant_9 : Space{});
    const Space v758_5 = subtract(constant_0,v758_4);
    Space v758_8;
    if (!v758_5.empty()) {
      const Path v759_6 = concat_path(p0,v757_8_head);
      Space v759_7_result;
      for (int v759_7_label = 1; v759_7_label <= 2; ++v759_7_label) {
        const Space v759_7_tail = child(v757_8_tail,v759_7_label);
        if (v759_7_tail.empty()) continue;
        const Path v759_7_head{v759_7_label};
        const Space v760_2 = singleton(v759_7_head);
        const Space v760_3 = intersect(constant_8,v760_2);
        const Space v760_4 = (has_head(v760_3) ? constant_9 : Space{});
        const Space v760_5 = subtract(constant_0,v760_4);
        Space v760_8;
        if (!v760_5.empty()) {
          const Path v761_6 = concat_path(v759_6,v759_7_head);
          const Space v761_7 = routine_149(c, v761_6, v759_7_tail);
          v760_8 = compose(v760_5,v761_7);
        }
        const Space v760_9 = intersect(constant_8,v760_2);
        const Space v760_10 = (has_head(v760_9) ? constant_9 : Space{});
        Space v760_12;
        if (!v760_10.empty()) {
          const Path v762_6 = concat_path(v759_6,v759_7_head);
          const Space v762_11 = routine_150(c, v762_6, v759_7_tail);
          v760_12 = compose(v760_10,v762_11);
        }
        const Space v760_13 = unite(v760_8,v760_12);
        v759_7_result = unite(v759_7_result,v760_13);
      }
      const Space v759_7 = std::move(v759_7_result);
      v758_8 = compose(v758_5,v759_7);
    }
    const Space v758_9 = intersect(constant_8,v758_2);
    const Space v758_10 = (has_head(v758_9) ? constant_9 : Space{});
    const Space v758_11 = compose(v758_10,v757_8_tail);
    const Space v758_12 = unite(v758_8,v758_11);
    v757_8_result = unite(v757_8_result,v758_12);
  }
  const Space v757_8 = std::move(v757_8_result);
  return v757_8;
}

static Space routine_74(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_75(Context& c, const Path& p0, const Space& s0) {
  Space v764_11_result;
  for (int v764_11_label = 1; v764_11_label <= 2; ++v764_11_label) {
    const Space v764_11_tail = child(s0,v764_11_label);
    if (v764_11_tail.empty()) continue;
    const Path v764_11_head{v764_11_label};
    const Space v765_2 = singleton(v764_11_head);
    const Space v765_3 = intersect(constant_8,v765_2);
    const Space v765_4 = (has_head(v765_3) ? constant_9 : Space{});
    const Space v765_5 = subtract(constant_0,v765_4);
    Space v765_8;
    if (!v765_5.empty()) {
      const Path v766_6 = concat_path(p0,v764_11_head);
      Space v766_7_result;
      for (int v766_7_label = 1; v766_7_label <= 2; ++v766_7_label) {
        const Space v766_7_tail = child(v764_11_tail,v766_7_label);
        if (v766_7_tail.empty()) continue;
        const Path v766_7_head{v766_7_label};
        const Space v767_2 = singleton(v766_7_head);
        const Space v767_3 = intersect(constant_8,v767_2);
        const Space v767_4 = (has_head(v767_3) ? constant_9 : Space{});
        const Space v767_5 = subtract(constant_0,v767_4);
        Space v767_8;
        if (!v767_5.empty()) {
          const Path v768_6 = concat_path(v766_6,v766_7_head);
          const Space v768_7 = routine_151(c, v768_6, v766_7_tail);
          v767_8 = compose(v767_5,v768_7);
        }
        const Space v767_9 = intersect(constant_8,v767_2);
        const Space v767_10 = (has_head(v767_9) ? constant_9 : Space{});
        Space v767_12;
        if (!v767_10.empty()) {
          const Path v769_6 = concat_path(v766_6,v766_7_head);
          const Space v769_11 = routine_152(c, v769_6, v766_7_tail);
          v767_12 = compose(v767_10,v769_11);
        }
        const Space v767_13 = unite(v767_8,v767_12);
        v766_7_result = unite(v766_7_result,v767_13);
      }
      const Space v766_7 = std::move(v766_7_result);
      v765_8 = compose(v765_5,v766_7);
    }
    const Space v765_9 = intersect(constant_8,v765_2);
    const Space v765_10 = (has_head(v765_9) ? constant_9 : Space{});
    Space v765_12;
    if (!v765_10.empty()) {
      const Path v770_6 = concat_path(p0,v764_11_head);
      Space v770_11_result;
      for (int v770_11_label = 1; v770_11_label <= 2; ++v770_11_label) {
        const Space v770_11_tail = child(v764_11_tail,v770_11_label);
        if (v770_11_tail.empty()) continue;
        const Path v770_11_head{v770_11_label};
        const Space v771_2 = singleton(v770_11_head);
        const Space v771_3 = intersect(constant_8,v771_2);
        const Space v771_4 = (has_head(v771_3) ? constant_9 : Space{});
        const Space v771_5 = subtract(constant_0,v771_4);
        Space v771_8;
        if (!v771_5.empty()) {
          const Path v772_6 = concat_path(v770_6,v770_11_head);
          const Space v772_7 = routine_151(c, v772_6, v770_11_tail);
          v771_8 = compose(v771_5,v772_7);
        }
        const Space v771_9 = intersect(constant_8,v771_2);
        const Space v771_10 = (has_head(v771_9) ? constant_9 : Space{});
        Space v771_12;
        if (!v771_10.empty()) {
          const Path v773_6 = concat_path(v770_6,v770_11_head);
          const Space v773_11 = routine_77(c, v773_6, v770_11_tail);
          v771_12 = compose(v771_10,v773_11);
        }
        const Space v771_13 = unite(v771_8,v771_12);
        v770_11_result = unite(v770_11_result,v771_13);
      }
      const Space v770_11 = std::move(v770_11_result);
      v765_12 = compose(v765_10,v770_11);
    }
    const Space v765_13 = unite(v765_8,v765_12);
    v764_11_result = unite(v764_11_result,v765_13);
  }
  const Space v764_11 = std::move(v764_11_result);
  return v764_11;
}

static Space routine_76(Context& c, const Path& p0, const Space& s0) {
  Space v774_11_result;
  for (int v774_11_label = 1; v774_11_label <= 2; ++v774_11_label) {
    const Space v774_11_tail = child(s0,v774_11_label);
    if (v774_11_tail.empty()) continue;
    const Path v774_11_head{v774_11_label};
    const Space v775_2 = singleton(v774_11_head);
    const Space v775_3 = intersect(constant_8,v775_2);
    const Space v775_4 = (has_head(v775_3) ? constant_9 : Space{});
    const Space v775_5 = subtract(constant_0,v775_4);
    Space v775_8;
    if (!v775_5.empty()) {
      const Path v776_6 = concat_path(p0,v774_11_head);
      Space v776_7_result;
      for (int v776_7_label = 1; v776_7_label <= 2; ++v776_7_label) {
        const Space v776_7_tail = child(v774_11_tail,v776_7_label);
        if (v776_7_tail.empty()) continue;
        const Path v776_7_head{v776_7_label};
        const Space v777_2 = singleton(v776_7_head);
        const Space v777_3 = intersect(constant_8,v777_2);
        const Space v777_4 = (has_head(v777_3) ? constant_9 : Space{});
        const Space v777_5 = subtract(constant_0,v777_4);
        Space v777_8;
        if (!v777_5.empty()) {
          const Path v778_6 = concat_path(v776_6,v776_7_head);
          const Space v778_7 = routine_151(c, v778_6, v776_7_tail);
          v777_8 = compose(v777_5,v778_7);
        }
        const Space v777_9 = intersect(constant_8,v777_2);
        const Space v777_10 = (has_head(v777_9) ? constant_9 : Space{});
        Space v777_12;
        if (!v777_10.empty()) {
          const Path v779_6 = concat_path(v776_6,v776_7_head);
          const Space v779_11 = routine_152(c, v779_6, v776_7_tail);
          v777_12 = compose(v777_10,v779_11);
        }
        const Space v777_13 = unite(v777_8,v777_12);
        v776_7_result = unite(v776_7_result,v777_13);
      }
      const Space v776_7 = std::move(v776_7_result);
      v775_8 = compose(v775_5,v776_7);
    }
    const Space v775_9 = intersect(constant_8,v775_2);
    const Space v775_10 = (has_head(v775_9) ? constant_9 : Space{});
    Space v775_12;
    if (!v775_10.empty()) {
      const Path v780_6 = concat_path(p0,v774_11_head);
      Space v780_11_result;
      for (int v780_11_label = 1; v780_11_label <= 2; ++v780_11_label) {
        const Space v780_11_tail = child(v774_11_tail,v780_11_label);
        if (v780_11_tail.empty()) continue;
        const Path v780_11_head{v780_11_label};
        const Space v781_2 = singleton(v780_11_head);
        const Space v781_3 = intersect(constant_8,v781_2);
        const Space v781_4 = (has_head(v781_3) ? constant_9 : Space{});
        const Space v781_5 = subtract(constant_0,v781_4);
        Space v781_7;
        if (!v781_5.empty()) {
          const Space v782_6 = routine_112(c, v780_11_head, v780_6, v780_11_tail);
          v781_7 = compose(v781_5,v782_6);
        }
        const Space v781_8 = intersect(constant_8,v781_2);
        const Space v781_9 = (has_head(v781_8) ? constant_9 : Space{});
        Space v781_11;
        if (!v781_9.empty()) {
          const Space v783_10 = routine_113(c, v780_11_head, v780_6, v780_11_tail);
          v781_11 = compose(v781_9,v783_10);
        }
        const Space v781_12 = unite(v781_7,v781_11);
        v780_11_result = unite(v780_11_result,v781_12);
      }
      const Space v780_11 = std::move(v780_11_result);
      v775_12 = compose(v775_10,v780_11);
    }
    const Space v775_13 = unite(v775_8,v775_12);
    v774_11_result = unite(v774_11_result,v775_13);
  }
  const Space v774_11 = std::move(v774_11_result);
  return v774_11;
}

static Space routine_77(Context& c, const Path& p0, const Space& s0) {
  Space v784_11_result;
  for (int v784_11_label = 1; v784_11_label <= 2; ++v784_11_label) {
    const Space v784_11_tail = child(s0,v784_11_label);
    if (v784_11_tail.empty()) continue;
    const Path v784_11_head{v784_11_label};
    const Space v785_2 = singleton(v784_11_head);
    const Space v785_3 = intersect(constant_8,v785_2);
    const Space v785_4 = (has_head(v785_3) ? constant_9 : Space{});
    const Space v785_5 = subtract(constant_0,v785_4);
    Space v785_7;
    if (!v785_5.empty()) {
      Space v786_6_result;
      for (int v786_6_label = 1; v786_6_label <= 2; ++v786_6_label) {
        const Space v786_6_tail = child(v784_11_tail,v786_6_label);
        if (v786_6_tail.empty()) continue;
        const Path v786_6_head{v786_6_label};
        const Space v787_2 = singleton(v786_6_head);
        const Space v787_3 = intersect(constant_8,v787_2);
        const Space v787_4 = (has_head(v787_3) ? constant_9 : Space{});
        const Space v787_5 = subtract(constant_0,v787_4);
        Space v787_8;
        if (!v787_5.empty()) {
          const Path v788_6 = concat_path(v784_11_head,v786_6_head);
          const Space v788_7 = routine_153(c, v788_6, p0, v786_6_tail);
          v787_8 = compose(v787_5,v788_7);
        }
        const Space v787_9 = intersect(constant_8,v787_2);
        const Space v787_10 = (has_head(v787_9) ? constant_9 : Space{});
        Space v787_12;
        if (!v787_10.empty()) {
          const Path v789_6 = concat_path(v784_11_head,v786_6_head);
          const Space v789_11 = routine_154(c, v789_6, p0, v786_6_tail);
          v787_12 = compose(v787_10,v789_11);
        }
        const Space v787_13 = unite(v787_8,v787_12);
        v786_6_result = unite(v786_6_result,v787_13);
      }
      const Space v786_6 = std::move(v786_6_result);
      v785_7 = compose(v785_5,v786_6);
    }
    const Space v785_8 = intersect(constant_8,v785_2);
    const Space v785_9 = (has_head(v785_8) ? constant_9 : Space{});
    Space v785_11;
    if (!v785_9.empty()) {
      Space v790_10_result;
      for (int v790_10_label = 1; v790_10_label <= 2; ++v790_10_label) {
        const Space v790_10_tail = child(v784_11_tail,v790_10_label);
        if (v790_10_tail.empty()) continue;
        const Path v790_10_head{v790_10_label};
        const Space v791_2 = singleton(v790_10_head);
        const Space v791_3 = intersect(constant_8,v791_2);
        const Space v791_4 = (has_head(v791_3) ? constant_9 : Space{});
        const Space v791_5 = subtract(constant_0,v791_4);
        Space v791_8;
        if (!v791_5.empty()) {
          const Path v792_6 = concat_path(v784_11_head,v790_10_head);
          const Space v792_7 = routine_153(c, v792_6, p0, v790_10_tail);
          v791_8 = compose(v791_5,v792_7);
        }
        const Space v791_9 = intersect(constant_8,v791_2);
        const Space v791_10 = (has_head(v791_9) ? constant_9 : Space{});
        Space v791_12;
        if (!v791_10.empty()) {
          const Path v793_6 = concat_path(v784_11_head,v790_10_head);
          const Space v793_11 = routine_155(c, v793_6, p0, v790_10_tail);
          v791_12 = compose(v791_10,v793_11);
        }
        const Space v791_13 = unite(v791_8,v791_12);
        v790_10_result = unite(v790_10_result,v791_13);
      }
      const Space v790_10 = std::move(v790_10_result);
      v785_11 = compose(v785_9,v790_10);
    }
    const Space v785_12 = unite(v785_7,v785_11);
    v784_11_result = unite(v784_11_result,v785_12);
  }
  const Space v784_11 = std::move(v784_11_result);
  return v784_11;
}

static Space routine_78(Context& c, const Path& p0, const Space& s0) {
  Space v794_11_result;
  for (int v794_11_label = 1; v794_11_label <= 2; ++v794_11_label) {
    const Space v794_11_tail = child(s0,v794_11_label);
    if (v794_11_tail.empty()) continue;
    const Path v794_11_head{v794_11_label};
    const Space v795_2 = singleton(v794_11_head);
    const Space v795_3 = intersect(constant_8,v795_2);
    const Space v795_4 = (has_head(v795_3) ? constant_9 : Space{});
    const Space v795_5 = subtract(constant_0,v795_4);
    Space v795_8;
    if (!v795_5.empty()) {
      const Path v796_6 = concat_path(p0,v794_11_head);
      Space v796_7_result;
      for (int v796_7_label = 1; v796_7_label <= 2; ++v796_7_label) {
        const Space v796_7_tail = child(v794_11_tail,v796_7_label);
        if (v796_7_tail.empty()) continue;
        const Path v796_7_head{v796_7_label};
        const Space v797_2 = singleton(v796_7_head);
        const Space v797_3 = intersect(constant_8,v797_2);
        const Space v797_4 = (has_head(v797_3) ? constant_9 : Space{});
        const Space v797_5 = subtract(constant_0,v797_4);
        Space v797_8;
        if (!v797_5.empty()) {
          const Path v798_6 = concat_path(v796_6,v796_7_head);
          const Space v798_7 = routine_156(c, v798_6, v796_7_tail);
          v797_8 = compose(v797_5,v798_7);
        }
        const Space v797_9 = intersect(constant_8,v797_2);
        const Space v797_10 = (has_head(v797_9) ? constant_9 : Space{});
        Space v797_12;
        if (!v797_10.empty()) {
          const Path v799_6 = concat_path(v796_6,v796_7_head);
          const Space v799_11 = routine_157(c, v799_6, v796_7_tail);
          v797_12 = compose(v797_10,v799_11);
        }
        const Space v797_13 = unite(v797_8,v797_12);
        v796_7_result = unite(v796_7_result,v797_13);
      }
      const Space v796_7 = std::move(v796_7_result);
      v795_8 = compose(v795_5,v796_7);
    }
    const Space v795_9 = intersect(constant_8,v795_2);
    const Space v795_10 = (has_head(v795_9) ? constant_9 : Space{});
    Space v795_12;
    if (!v795_10.empty()) {
      const Path v800_6 = concat_path(p0,v794_11_head);
      Space v800_11_result;
      for (int v800_11_label = 1; v800_11_label <= 2; ++v800_11_label) {
        const Space v800_11_tail = child(v794_11_tail,v800_11_label);
        if (v800_11_tail.empty()) continue;
        const Path v800_11_head{v800_11_label};
        const Space v801_2 = singleton(v800_11_head);
        const Space v801_3 = intersect(constant_8,v801_2);
        const Space v801_4 = (has_head(v801_3) ? constant_9 : Space{});
        const Space v801_5 = subtract(constant_0,v801_4);
        Space v801_8;
        if (!v801_5.empty()) {
          const Path v802_6 = concat_path(v800_6,v800_11_head);
          const Space v802_7 = routine_156(c, v802_6, v800_11_tail);
          v801_8 = compose(v801_5,v802_7);
        }
        const Space v801_9 = intersect(constant_8,v801_2);
        const Space v801_10 = (has_head(v801_9) ? constant_9 : Space{});
        Space v801_12;
        if (!v801_10.empty()) {
          const Path v803_6 = concat_path(v800_6,v800_11_head);
          const Space v803_11 = routine_80(c, v803_6, v800_11_tail);
          v801_12 = compose(v801_10,v803_11);
        }
        const Space v801_13 = unite(v801_8,v801_12);
        v800_11_result = unite(v800_11_result,v801_13);
      }
      const Space v800_11 = std::move(v800_11_result);
      v795_12 = compose(v795_10,v800_11);
    }
    const Space v795_13 = unite(v795_8,v795_12);
    v794_11_result = unite(v794_11_result,v795_13);
  }
  const Space v794_11 = std::move(v794_11_result);
  return v794_11;
}

static Space routine_79(Context& c, const Path& p0, const Space& s0) {
  Space v804_8_result;
  for (int v804_8_label = 1; v804_8_label <= 2; ++v804_8_label) {
    const Space v804_8_tail = child(s0,v804_8_label);
    if (v804_8_tail.empty()) continue;
    const Path v804_8_head{v804_8_label};
    const Space v805_2 = singleton(v804_8_head);
    const Space v805_3 = intersect(constant_8,v805_2);
    const Space v805_4 = (has_head(v805_3) ? constant_9 : Space{});
    const Space v805_5 = subtract(constant_0,v805_4);
    Space v805_8;
    if (!v805_5.empty()) {
      const Path v806_6 = concat_path(p0,v804_8_head);
      Space v806_7_result;
      for (int v806_7_label = 1; v806_7_label <= 2; ++v806_7_label) {
        const Space v806_7_tail = child(v804_8_tail,v806_7_label);
        if (v806_7_tail.empty()) continue;
        const Path v806_7_head{v806_7_label};
        const Space v807_2 = singleton(v806_7_head);
        const Space v807_3 = intersect(constant_8,v807_2);
        const Space v807_4 = (has_head(v807_3) ? constant_9 : Space{});
        const Space v807_5 = subtract(constant_0,v807_4);
        Space v807_8;
        if (!v807_5.empty()) {
          const Path v808_6 = concat_path(v806_6,v806_7_head);
          const Space v808_7 = routine_156(c, v808_6, v806_7_tail);
          v807_8 = compose(v807_5,v808_7);
        }
        const Space v807_9 = intersect(constant_8,v807_2);
        const Space v807_10 = (has_head(v807_9) ? constant_9 : Space{});
        Space v807_12;
        if (!v807_10.empty()) {
          const Path v809_6 = concat_path(v806_6,v806_7_head);
          const Space v809_11 = routine_157(c, v809_6, v806_7_tail);
          v807_12 = compose(v807_10,v809_11);
        }
        const Space v807_13 = unite(v807_8,v807_12);
        v806_7_result = unite(v806_7_result,v807_13);
      }
      const Space v806_7 = std::move(v806_7_result);
      v805_8 = compose(v805_5,v806_7);
    }
    const Space v805_9 = intersect(constant_8,v805_2);
    const Space v805_10 = (has_head(v805_9) ? constant_9 : Space{});
    const Space v805_11 = compose(v805_10,v804_8_tail);
    const Space v805_12 = unite(v805_8,v805_11);
    v804_8_result = unite(v804_8_result,v805_12);
  }
  const Space v804_8 = std::move(v804_8_result);
  return v804_8;
}

static Space routine_80(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_81(Context& c, const Path& p0, const Space& s0) {
  Space v811_11_result;
  for (int v811_11_label = 1; v811_11_label <= 2; ++v811_11_label) {
    const Space v811_11_tail = child(s0,v811_11_label);
    if (v811_11_tail.empty()) continue;
    const Path v811_11_head{v811_11_label};
    const Space v812_2 = singleton(v811_11_head);
    const Space v812_3 = intersect(constant_8,v812_2);
    const Space v812_4 = (has_head(v812_3) ? constant_9 : Space{});
    const Space v812_5 = subtract(constant_0,v812_4);
    Space v812_8;
    if (!v812_5.empty()) {
      const Path v813_6 = concat_path(p0,v811_11_head);
      Space v813_7_result;
      for (int v813_7_label = 1; v813_7_label <= 2; ++v813_7_label) {
        const Space v813_7_tail = child(v811_11_tail,v813_7_label);
        if (v813_7_tail.empty()) continue;
        const Path v813_7_head{v813_7_label};
        const Space v814_2 = singleton(v813_7_head);
        const Space v814_3 = intersect(constant_8,v814_2);
        const Space v814_4 = (has_head(v814_3) ? constant_9 : Space{});
        const Space v814_5 = subtract(constant_0,v814_4);
        Space v814_8;
        if (!v814_5.empty()) {
          const Path v815_6 = concat_path(v813_6,v813_7_head);
          const Space v815_7 = routine_158(c, v815_6, v813_7_tail);
          v814_8 = compose(v814_5,v815_7);
        }
        const Space v814_9 = intersect(constant_8,v814_2);
        const Space v814_10 = (has_head(v814_9) ? constant_9 : Space{});
        Space v814_12;
        if (!v814_10.empty()) {
          const Path v816_6 = concat_path(v813_6,v813_7_head);
          const Space v816_11 = routine_159(c, v816_6, v813_7_tail);
          v814_12 = compose(v814_10,v816_11);
        }
        const Space v814_13 = unite(v814_8,v814_12);
        v813_7_result = unite(v813_7_result,v814_13);
      }
      const Space v813_7 = std::move(v813_7_result);
      v812_8 = compose(v812_5,v813_7);
    }
    const Space v812_9 = intersect(constant_8,v812_2);
    const Space v812_10 = (has_head(v812_9) ? constant_9 : Space{});
    Space v812_12;
    if (!v812_10.empty()) {
      const Path v817_6 = concat_path(p0,v811_11_head);
      Space v817_11_result;
      for (int v817_11_label = 1; v817_11_label <= 2; ++v817_11_label) {
        const Space v817_11_tail = child(v811_11_tail,v817_11_label);
        if (v817_11_tail.empty()) continue;
        const Path v817_11_head{v817_11_label};
        const Space v818_2 = singleton(v817_11_head);
        const Space v818_3 = intersect(constant_8,v818_2);
        const Space v818_4 = (has_head(v818_3) ? constant_9 : Space{});
        const Space v818_5 = subtract(constant_0,v818_4);
        Space v818_8;
        if (!v818_5.empty()) {
          const Path v819_6 = concat_path(v817_6,v817_11_head);
          const Space v819_7 = routine_158(c, v819_6, v817_11_tail);
          v818_8 = compose(v818_5,v819_7);
        }
        const Space v818_9 = intersect(constant_8,v818_2);
        const Space v818_10 = (has_head(v818_9) ? constant_9 : Space{});
        Space v818_12;
        if (!v818_10.empty()) {
          const Path v820_6 = concat_path(v817_6,v817_11_head);
          const Space v820_11 = routine_83(c, v820_6, v817_11_tail);
          v818_12 = compose(v818_10,v820_11);
        }
        const Space v818_13 = unite(v818_8,v818_12);
        v817_11_result = unite(v817_11_result,v818_13);
      }
      const Space v817_11 = std::move(v817_11_result);
      v812_12 = compose(v812_10,v817_11);
    }
    const Space v812_13 = unite(v812_8,v812_12);
    v811_11_result = unite(v811_11_result,v812_13);
  }
  const Space v811_11 = std::move(v811_11_result);
  return v811_11;
}

static Space routine_82(Context& c, const Path& p0, const Space& s0) {
  Space v821_11_result;
  for (int v821_11_label = 1; v821_11_label <= 2; ++v821_11_label) {
    const Space v821_11_tail = child(s0,v821_11_label);
    if (v821_11_tail.empty()) continue;
    const Path v821_11_head{v821_11_label};
    const Space v822_2 = singleton(v821_11_head);
    const Space v822_3 = intersect(constant_8,v822_2);
    const Space v822_4 = (has_head(v822_3) ? constant_9 : Space{});
    const Space v822_5 = subtract(constant_0,v822_4);
    Space v822_8;
    if (!v822_5.empty()) {
      const Path v823_6 = concat_path(p0,v821_11_head);
      Space v823_7_result;
      for (int v823_7_label = 1; v823_7_label <= 2; ++v823_7_label) {
        const Space v823_7_tail = child(v821_11_tail,v823_7_label);
        if (v823_7_tail.empty()) continue;
        const Path v823_7_head{v823_7_label};
        const Space v824_2 = singleton(v823_7_head);
        const Space v824_3 = intersect(constant_8,v824_2);
        const Space v824_4 = (has_head(v824_3) ? constant_9 : Space{});
        const Space v824_5 = subtract(constant_0,v824_4);
        Space v824_8;
        if (!v824_5.empty()) {
          const Path v825_6 = concat_path(v823_6,v823_7_head);
          const Space v825_7 = routine_158(c, v825_6, v823_7_tail);
          v824_8 = compose(v824_5,v825_7);
        }
        const Space v824_9 = intersect(constant_8,v824_2);
        const Space v824_10 = (has_head(v824_9) ? constant_9 : Space{});
        Space v824_12;
        if (!v824_10.empty()) {
          const Path v826_6 = concat_path(v823_6,v823_7_head);
          const Space v826_11 = routine_159(c, v826_6, v823_7_tail);
          v824_12 = compose(v824_10,v826_11);
        }
        const Space v824_13 = unite(v824_8,v824_12);
        v823_7_result = unite(v823_7_result,v824_13);
      }
      const Space v823_7 = std::move(v823_7_result);
      v822_8 = compose(v822_5,v823_7);
    }
    const Space v822_9 = intersect(constant_8,v822_2);
    const Space v822_10 = (has_head(v822_9) ? constant_9 : Space{});
    Space v822_12;
    if (!v822_10.empty()) {
      const Path v827_6 = concat_path(p0,v821_11_head);
      Space v827_11_result;
      for (int v827_11_label = 1; v827_11_label <= 2; ++v827_11_label) {
        const Space v827_11_tail = child(v821_11_tail,v827_11_label);
        if (v827_11_tail.empty()) continue;
        const Path v827_11_head{v827_11_label};
        const Space v828_2 = singleton(v827_11_head);
        const Space v828_3 = intersect(constant_8,v828_2);
        const Space v828_4 = (has_head(v828_3) ? constant_9 : Space{});
        const Space v828_5 = subtract(constant_0,v828_4);
        Space v828_7;
        if (!v828_5.empty()) {
          const Space v829_6 = routine_118(c, v827_11_head, v827_6, v827_11_tail);
          v828_7 = compose(v828_5,v829_6);
        }
        const Space v828_8 = intersect(constant_8,v828_2);
        const Space v828_9 = (has_head(v828_8) ? constant_9 : Space{});
        Space v828_11;
        if (!v828_9.empty()) {
          const Space v830_10 = routine_119(c, v827_11_head, v827_6, v827_11_tail);
          v828_11 = compose(v828_9,v830_10);
        }
        const Space v828_12 = unite(v828_7,v828_11);
        v827_11_result = unite(v827_11_result,v828_12);
      }
      const Space v827_11 = std::move(v827_11_result);
      v822_12 = compose(v822_10,v827_11);
    }
    const Space v822_13 = unite(v822_8,v822_12);
    v821_11_result = unite(v821_11_result,v822_13);
  }
  const Space v821_11 = std::move(v821_11_result);
  return v821_11;
}

static Space routine_83(Context& c, const Path& p0, const Space& s0) {
  Space v831_11_result;
  for (int v831_11_label = 1; v831_11_label <= 2; ++v831_11_label) {
    const Space v831_11_tail = child(s0,v831_11_label);
    if (v831_11_tail.empty()) continue;
    const Path v831_11_head{v831_11_label};
    const Space v832_2 = singleton(v831_11_head);
    const Space v832_3 = intersect(constant_8,v832_2);
    const Space v832_4 = (has_head(v832_3) ? constant_9 : Space{});
    const Space v832_5 = subtract(constant_0,v832_4);
    Space v832_7;
    if (!v832_5.empty()) {
      Space v833_6_result;
      for (int v833_6_label = 1; v833_6_label <= 2; ++v833_6_label) {
        const Space v833_6_tail = child(v831_11_tail,v833_6_label);
        if (v833_6_tail.empty()) continue;
        const Path v833_6_head{v833_6_label};
        const Space v834_2 = singleton(v833_6_head);
        const Space v834_3 = intersect(constant_8,v834_2);
        const Space v834_4 = (has_head(v834_3) ? constant_9 : Space{});
        const Space v834_5 = subtract(constant_0,v834_4);
        Space v834_8;
        if (!v834_5.empty()) {
          const Path v835_6 = concat_path(v831_11_head,v833_6_head);
          const Space v835_7 = routine_160(c, v835_6, p0, v833_6_tail);
          v834_8 = compose(v834_5,v835_7);
        }
        const Space v834_9 = intersect(constant_8,v834_2);
        const Space v834_10 = (has_head(v834_9) ? constant_9 : Space{});
        Space v834_12;
        if (!v834_10.empty()) {
          const Path v836_6 = concat_path(v831_11_head,v833_6_head);
          const Space v836_11 = routine_161(c, v836_6, p0, v833_6_tail);
          v834_12 = compose(v834_10,v836_11);
        }
        const Space v834_13 = unite(v834_8,v834_12);
        v833_6_result = unite(v833_6_result,v834_13);
      }
      const Space v833_6 = std::move(v833_6_result);
      v832_7 = compose(v832_5,v833_6);
    }
    const Space v832_8 = intersect(constant_8,v832_2);
    const Space v832_9 = (has_head(v832_8) ? constant_9 : Space{});
    Space v832_11;
    if (!v832_9.empty()) {
      Space v837_10_result;
      for (int v837_10_label = 1; v837_10_label <= 2; ++v837_10_label) {
        const Space v837_10_tail = child(v831_11_tail,v837_10_label);
        if (v837_10_tail.empty()) continue;
        const Path v837_10_head{v837_10_label};
        const Space v838_2 = singleton(v837_10_head);
        const Space v838_3 = intersect(constant_8,v838_2);
        const Space v838_4 = (has_head(v838_3) ? constant_9 : Space{});
        const Space v838_5 = subtract(constant_0,v838_4);
        Space v838_8;
        if (!v838_5.empty()) {
          const Path v839_6 = concat_path(v831_11_head,v837_10_head);
          const Space v839_7 = routine_160(c, v839_6, p0, v837_10_tail);
          v838_8 = compose(v838_5,v839_7);
        }
        const Space v838_9 = intersect(constant_8,v838_2);
        const Space v838_10 = (has_head(v838_9) ? constant_9 : Space{});
        Space v838_12;
        if (!v838_10.empty()) {
          const Path v840_6 = concat_path(v831_11_head,v837_10_head);
          const Space v840_11 = routine_162(c, v840_6, p0, v837_10_tail);
          v838_12 = compose(v838_10,v840_11);
        }
        const Space v838_13 = unite(v838_8,v838_12);
        v837_10_result = unite(v837_10_result,v838_13);
      }
      const Space v837_10 = std::move(v837_10_result);
      v832_11 = compose(v832_9,v837_10);
    }
    const Space v832_12 = unite(v832_7,v832_11);
    v831_11_result = unite(v831_11_result,v832_12);
  }
  const Space v831_11 = std::move(v831_11_result);
  return v831_11;
}

static Space routine_84(Context& c, const Path& p0, const Space& s0) {
  Space v841_11_result;
  for (int v841_11_label = 1; v841_11_label <= 2; ++v841_11_label) {
    const Space v841_11_tail = child(s0,v841_11_label);
    if (v841_11_tail.empty()) continue;
    const Path v841_11_head{v841_11_label};
    const Space v842_2 = singleton(v841_11_head);
    const Space v842_3 = intersect(constant_8,v842_2);
    const Space v842_4 = (has_head(v842_3) ? constant_9 : Space{});
    const Space v842_5 = subtract(constant_0,v842_4);
    Space v842_8;
    if (!v842_5.empty()) {
      const Path v843_6 = concat_path(p0,v841_11_head);
      Space v843_7_result;
      for (int v843_7_label = 1; v843_7_label <= 2; ++v843_7_label) {
        const Space v843_7_tail = child(v841_11_tail,v843_7_label);
        if (v843_7_tail.empty()) continue;
        const Path v843_7_head{v843_7_label};
        const Space v844_2 = singleton(v843_7_head);
        const Space v844_3 = intersect(constant_8,v844_2);
        const Space v844_4 = (has_head(v844_3) ? constant_9 : Space{});
        const Space v844_5 = subtract(constant_0,v844_4);
        Space v844_8;
        if (!v844_5.empty()) {
          const Path v845_6 = concat_path(v843_6,v843_7_head);
          const Space v845_7 = routine_163(c, v845_6, v843_7_tail);
          v844_8 = compose(v844_5,v845_7);
        }
        const Space v844_9 = intersect(constant_8,v844_2);
        const Space v844_10 = (has_head(v844_9) ? constant_9 : Space{});
        Space v844_12;
        if (!v844_10.empty()) {
          const Path v846_6 = concat_path(v843_6,v843_7_head);
          const Space v846_11 = routine_164(c, v846_6, v843_7_tail);
          v844_12 = compose(v844_10,v846_11);
        }
        const Space v844_13 = unite(v844_8,v844_12);
        v843_7_result = unite(v843_7_result,v844_13);
      }
      const Space v843_7 = std::move(v843_7_result);
      v842_8 = compose(v842_5,v843_7);
    }
    const Space v842_9 = intersect(constant_8,v842_2);
    const Space v842_10 = (has_head(v842_9) ? constant_9 : Space{});
    Space v842_12;
    if (!v842_10.empty()) {
      const Path v847_6 = concat_path(p0,v841_11_head);
      Space v847_11_result;
      for (int v847_11_label = 1; v847_11_label <= 2; ++v847_11_label) {
        const Space v847_11_tail = child(v841_11_tail,v847_11_label);
        if (v847_11_tail.empty()) continue;
        const Path v847_11_head{v847_11_label};
        const Space v848_2 = singleton(v847_11_head);
        const Space v848_3 = intersect(constant_8,v848_2);
        const Space v848_4 = (has_head(v848_3) ? constant_9 : Space{});
        const Space v848_5 = subtract(constant_0,v848_4);
        Space v848_8;
        if (!v848_5.empty()) {
          const Path v849_6 = concat_path(v847_6,v847_11_head);
          const Space v849_7 = routine_163(c, v849_6, v847_11_tail);
          v848_8 = compose(v848_5,v849_7);
        }
        const Space v848_9 = intersect(constant_8,v848_2);
        const Space v848_10 = (has_head(v848_9) ? constant_9 : Space{});
        Space v848_12;
        if (!v848_10.empty()) {
          const Path v850_6 = concat_path(v847_6,v847_11_head);
          const Space v850_11 = routine_86(c, v850_6, v847_11_tail);
          v848_12 = compose(v848_10,v850_11);
        }
        const Space v848_13 = unite(v848_8,v848_12);
        v847_11_result = unite(v847_11_result,v848_13);
      }
      const Space v847_11 = std::move(v847_11_result);
      v842_12 = compose(v842_10,v847_11);
    }
    const Space v842_13 = unite(v842_8,v842_12);
    v841_11_result = unite(v841_11_result,v842_13);
  }
  const Space v841_11 = std::move(v841_11_result);
  return v841_11;
}

static Space routine_85(Context& c, const Path& p0, const Space& s0) {
  Space v851_8_result;
  for (int v851_8_label = 1; v851_8_label <= 2; ++v851_8_label) {
    const Space v851_8_tail = child(s0,v851_8_label);
    if (v851_8_tail.empty()) continue;
    const Path v851_8_head{v851_8_label};
    const Space v852_2 = singleton(v851_8_head);
    const Space v852_3 = intersect(constant_8,v852_2);
    const Space v852_4 = (has_head(v852_3) ? constant_9 : Space{});
    const Space v852_5 = subtract(constant_0,v852_4);
    Space v852_8;
    if (!v852_5.empty()) {
      const Path v853_6 = concat_path(p0,v851_8_head);
      Space v853_7_result;
      for (int v853_7_label = 1; v853_7_label <= 2; ++v853_7_label) {
        const Space v853_7_tail = child(v851_8_tail,v853_7_label);
        if (v853_7_tail.empty()) continue;
        const Path v853_7_head{v853_7_label};
        const Space v854_2 = singleton(v853_7_head);
        const Space v854_3 = intersect(constant_8,v854_2);
        const Space v854_4 = (has_head(v854_3) ? constant_9 : Space{});
        const Space v854_5 = subtract(constant_0,v854_4);
        Space v854_8;
        if (!v854_5.empty()) {
          const Path v855_6 = concat_path(v853_6,v853_7_head);
          const Space v855_7 = routine_163(c, v855_6, v853_7_tail);
          v854_8 = compose(v854_5,v855_7);
        }
        const Space v854_9 = intersect(constant_8,v854_2);
        const Space v854_10 = (has_head(v854_9) ? constant_9 : Space{});
        Space v854_12;
        if (!v854_10.empty()) {
          const Path v856_6 = concat_path(v853_6,v853_7_head);
          const Space v856_11 = routine_164(c, v856_6, v853_7_tail);
          v854_12 = compose(v854_10,v856_11);
        }
        const Space v854_13 = unite(v854_8,v854_12);
        v853_7_result = unite(v853_7_result,v854_13);
      }
      const Space v853_7 = std::move(v853_7_result);
      v852_8 = compose(v852_5,v853_7);
    }
    const Space v852_9 = intersect(constant_8,v852_2);
    const Space v852_10 = (has_head(v852_9) ? constant_9 : Space{});
    const Space v852_11 = compose(v852_10,v851_8_tail);
    const Space v852_12 = unite(v852_8,v852_11);
    v851_8_result = unite(v851_8_result,v852_12);
  }
  const Space v851_8 = std::move(v851_8_result);
  return v851_8;
}

static Space routine_86(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_87(Context& c, const Path& p0, const Space& s0) {
  Space v858_11_result;
  for (int v858_11_label = 1; v858_11_label <= 2; ++v858_11_label) {
    const Space v858_11_tail = child(s0,v858_11_label);
    if (v858_11_tail.empty()) continue;
    const Path v858_11_head{v858_11_label};
    const Space v859_2 = singleton(v858_11_head);
    const Space v859_3 = intersect(constant_8,v859_2);
    const Space v859_4 = (has_head(v859_3) ? constant_9 : Space{});
    const Space v859_5 = subtract(constant_0,v859_4);
    Space v859_8;
    if (!v859_5.empty()) {
      const Path v860_6 = concat_path(p0,v858_11_head);
      Space v860_7_result;
      for (int v860_7_label = 1; v860_7_label <= 2; ++v860_7_label) {
        const Space v860_7_tail = child(v858_11_tail,v860_7_label);
        if (v860_7_tail.empty()) continue;
        const Path v860_7_head{v860_7_label};
        const Space v861_2 = singleton(v860_7_head);
        const Space v861_3 = intersect(constant_8,v861_2);
        const Space v861_4 = (has_head(v861_3) ? constant_9 : Space{});
        const Space v861_5 = subtract(constant_0,v861_4);
        Space v861_8;
        if (!v861_5.empty()) {
          const Path v862_6 = concat_path(v860_6,v860_7_head);
          const Space v862_7 = routine_165(c, v862_6, v860_7_tail);
          v861_8 = compose(v861_5,v862_7);
        }
        const Space v861_9 = intersect(constant_8,v861_2);
        const Space v861_10 = (has_head(v861_9) ? constant_9 : Space{});
        Space v861_12;
        if (!v861_10.empty()) {
          const Path v863_6 = concat_path(v860_6,v860_7_head);
          const Space v863_11 = routine_166(c, v863_6, v860_7_tail);
          v861_12 = compose(v861_10,v863_11);
        }
        const Space v861_13 = unite(v861_8,v861_12);
        v860_7_result = unite(v860_7_result,v861_13);
      }
      const Space v860_7 = std::move(v860_7_result);
      v859_8 = compose(v859_5,v860_7);
    }
    const Space v859_9 = intersect(constant_8,v859_2);
    const Space v859_10 = (has_head(v859_9) ? constant_9 : Space{});
    Space v859_12;
    if (!v859_10.empty()) {
      const Path v864_6 = concat_path(p0,v858_11_head);
      Space v864_11_result;
      for (int v864_11_label = 1; v864_11_label <= 2; ++v864_11_label) {
        const Space v864_11_tail = child(v858_11_tail,v864_11_label);
        if (v864_11_tail.empty()) continue;
        const Path v864_11_head{v864_11_label};
        const Space v865_2 = singleton(v864_11_head);
        const Space v865_3 = intersect(constant_8,v865_2);
        const Space v865_4 = (has_head(v865_3) ? constant_9 : Space{});
        const Space v865_5 = subtract(constant_0,v865_4);
        Space v865_8;
        if (!v865_5.empty()) {
          const Path v866_6 = concat_path(v864_6,v864_11_head);
          const Space v866_7 = routine_165(c, v866_6, v864_11_tail);
          v865_8 = compose(v865_5,v866_7);
        }
        const Space v865_9 = intersect(constant_8,v865_2);
        const Space v865_10 = (has_head(v865_9) ? constant_9 : Space{});
        Space v865_12;
        if (!v865_10.empty()) {
          const Path v867_6 = concat_path(v864_6,v864_11_head);
          const Space v867_11 = routine_89(c, v867_6, v864_11_tail);
          v865_12 = compose(v865_10,v867_11);
        }
        const Space v865_13 = unite(v865_8,v865_12);
        v864_11_result = unite(v864_11_result,v865_13);
      }
      const Space v864_11 = std::move(v864_11_result);
      v859_12 = compose(v859_10,v864_11);
    }
    const Space v859_13 = unite(v859_8,v859_12);
    v858_11_result = unite(v858_11_result,v859_13);
  }
  const Space v858_11 = std::move(v858_11_result);
  return v858_11;
}

static Space routine_88(Context& c, const Path& p0, const Space& s0) {
  Space v868_11_result;
  for (int v868_11_label = 1; v868_11_label <= 2; ++v868_11_label) {
    const Space v868_11_tail = child(s0,v868_11_label);
    if (v868_11_tail.empty()) continue;
    const Path v868_11_head{v868_11_label};
    const Space v869_2 = singleton(v868_11_head);
    const Space v869_3 = intersect(constant_8,v869_2);
    const Space v869_4 = (has_head(v869_3) ? constant_9 : Space{});
    const Space v869_5 = subtract(constant_0,v869_4);
    Space v869_8;
    if (!v869_5.empty()) {
      const Path v870_6 = concat_path(p0,v868_11_head);
      Space v870_7_result;
      for (int v870_7_label = 1; v870_7_label <= 2; ++v870_7_label) {
        const Space v870_7_tail = child(v868_11_tail,v870_7_label);
        if (v870_7_tail.empty()) continue;
        const Path v870_7_head{v870_7_label};
        const Space v871_2 = singleton(v870_7_head);
        const Space v871_3 = intersect(constant_8,v871_2);
        const Space v871_4 = (has_head(v871_3) ? constant_9 : Space{});
        const Space v871_5 = subtract(constant_0,v871_4);
        Space v871_8;
        if (!v871_5.empty()) {
          const Path v872_6 = concat_path(v870_6,v870_7_head);
          const Space v872_7 = routine_165(c, v872_6, v870_7_tail);
          v871_8 = compose(v871_5,v872_7);
        }
        const Space v871_9 = intersect(constant_8,v871_2);
        const Space v871_10 = (has_head(v871_9) ? constant_9 : Space{});
        Space v871_12;
        if (!v871_10.empty()) {
          const Path v873_6 = concat_path(v870_6,v870_7_head);
          const Space v873_11 = routine_166(c, v873_6, v870_7_tail);
          v871_12 = compose(v871_10,v873_11);
        }
        const Space v871_13 = unite(v871_8,v871_12);
        v870_7_result = unite(v870_7_result,v871_13);
      }
      const Space v870_7 = std::move(v870_7_result);
      v869_8 = compose(v869_5,v870_7);
    }
    const Space v869_9 = intersect(constant_8,v869_2);
    const Space v869_10 = (has_head(v869_9) ? constant_9 : Space{});
    Space v869_12;
    if (!v869_10.empty()) {
      const Path v874_6 = concat_path(p0,v868_11_head);
      Space v874_11_result;
      for (int v874_11_label = 1; v874_11_label <= 2; ++v874_11_label) {
        const Space v874_11_tail = child(v868_11_tail,v874_11_label);
        if (v874_11_tail.empty()) continue;
        const Path v874_11_head{v874_11_label};
        const Space v875_2 = singleton(v874_11_head);
        const Space v875_3 = intersect(constant_8,v875_2);
        const Space v875_4 = (has_head(v875_3) ? constant_9 : Space{});
        const Space v875_5 = subtract(constant_0,v875_4);
        Space v875_7;
        if (!v875_5.empty()) {
          const Space v876_6 = routine_124(c, v874_11_head, v874_6, v874_11_tail);
          v875_7 = compose(v875_5,v876_6);
        }
        const Space v875_8 = intersect(constant_8,v875_2);
        const Space v875_9 = (has_head(v875_8) ? constant_9 : Space{});
        Space v875_11;
        if (!v875_9.empty()) {
          const Space v877_10 = routine_125(c, v874_11_head, v874_6, v874_11_tail);
          v875_11 = compose(v875_9,v877_10);
        }
        const Space v875_12 = unite(v875_7,v875_11);
        v874_11_result = unite(v874_11_result,v875_12);
      }
      const Space v874_11 = std::move(v874_11_result);
      v869_12 = compose(v869_10,v874_11);
    }
    const Space v869_13 = unite(v869_8,v869_12);
    v868_11_result = unite(v868_11_result,v869_13);
  }
  const Space v868_11 = std::move(v868_11_result);
  return v868_11;
}

static Space routine_89(Context& c, const Path& p0, const Space& s0) {
  Space v878_11_result;
  for (int v878_11_label = 1; v878_11_label <= 2; ++v878_11_label) {
    const Space v878_11_tail = child(s0,v878_11_label);
    if (v878_11_tail.empty()) continue;
    const Path v878_11_head{v878_11_label};
    const Space v879_2 = singleton(v878_11_head);
    const Space v879_3 = intersect(constant_8,v879_2);
    const Space v879_4 = (has_head(v879_3) ? constant_9 : Space{});
    const Space v879_5 = subtract(constant_0,v879_4);
    Space v879_7;
    if (!v879_5.empty()) {
      Space v880_6_result;
      for (int v880_6_label = 1; v880_6_label <= 2; ++v880_6_label) {
        const Space v880_6_tail = child(v878_11_tail,v880_6_label);
        if (v880_6_tail.empty()) continue;
        const Path v880_6_head{v880_6_label};
        const Space v881_2 = singleton(v880_6_head);
        const Space v881_3 = intersect(constant_8,v881_2);
        const Space v881_4 = (has_head(v881_3) ? constant_9 : Space{});
        const Space v881_5 = subtract(constant_0,v881_4);
        Space v881_8;
        if (!v881_5.empty()) {
          const Path v882_6 = concat_path(v878_11_head,v880_6_head);
          const Space v882_7 = routine_167(c, v882_6, p0, v880_6_tail);
          v881_8 = compose(v881_5,v882_7);
        }
        const Space v881_9 = intersect(constant_8,v881_2);
        const Space v881_10 = (has_head(v881_9) ? constant_9 : Space{});
        Space v881_12;
        if (!v881_10.empty()) {
          const Path v883_6 = concat_path(v878_11_head,v880_6_head);
          const Space v883_11 = routine_168(c, v883_6, p0, v880_6_tail);
          v881_12 = compose(v881_10,v883_11);
        }
        const Space v881_13 = unite(v881_8,v881_12);
        v880_6_result = unite(v880_6_result,v881_13);
      }
      const Space v880_6 = std::move(v880_6_result);
      v879_7 = compose(v879_5,v880_6);
    }
    const Space v879_8 = intersect(constant_8,v879_2);
    const Space v879_9 = (has_head(v879_8) ? constant_9 : Space{});
    Space v879_11;
    if (!v879_9.empty()) {
      Space v884_10_result;
      for (int v884_10_label = 1; v884_10_label <= 2; ++v884_10_label) {
        const Space v884_10_tail = child(v878_11_tail,v884_10_label);
        if (v884_10_tail.empty()) continue;
        const Path v884_10_head{v884_10_label};
        const Space v885_2 = singleton(v884_10_head);
        const Space v885_3 = intersect(constant_8,v885_2);
        const Space v885_4 = (has_head(v885_3) ? constant_9 : Space{});
        const Space v885_5 = subtract(constant_0,v885_4);
        Space v885_8;
        if (!v885_5.empty()) {
          const Path v886_6 = concat_path(v878_11_head,v884_10_head);
          const Space v886_7 = routine_167(c, v886_6, p0, v884_10_tail);
          v885_8 = compose(v885_5,v886_7);
        }
        const Space v885_9 = intersect(constant_8,v885_2);
        const Space v885_10 = (has_head(v885_9) ? constant_9 : Space{});
        Space v885_12;
        if (!v885_10.empty()) {
          const Path v887_6 = concat_path(v878_11_head,v884_10_head);
          const Space v887_11 = routine_169(c, v887_6, p0, v884_10_tail);
          v885_12 = compose(v885_10,v887_11);
        }
        const Space v885_13 = unite(v885_8,v885_12);
        v884_10_result = unite(v884_10_result,v885_13);
      }
      const Space v884_10 = std::move(v884_10_result);
      v879_11 = compose(v879_9,v884_10);
    }
    const Space v879_12 = unite(v879_7,v879_11);
    v878_11_result = unite(v878_11_result,v879_12);
  }
  const Space v878_11 = std::move(v878_11_result);
  return v878_11;
}

static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v888_12_result;
  for (int v888_12_label = 1; v888_12_label <= 2; ++v888_12_label) {
    const Space v888_12_tail = child(s0,v888_12_label);
    if (v888_12_tail.empty()) continue;
    const Path v888_12_head{v888_12_label};
    const Space v889_2 = singleton(v888_12_head);
    const Space v889_3 = intersect(constant_8,v889_2);
    const Space v889_4 = (has_head(v889_3) ? constant_9 : Space{});
    const Space v889_5 = subtract(constant_0,v889_4);
    Space v889_8;
    if (!v889_5.empty()) {
      const Path v890_6 = concat_path(p0,v888_12_head);
      Space v890_7_result;
      for (int v890_7_label = 1; v890_7_label <= 2; ++v890_7_label) {
        const Space v890_7_tail = child(v888_12_tail,v890_7_label);
        if (v890_7_tail.empty()) continue;
        const Path v890_7_head{v890_7_label};
        const Space v891_2 = singleton(v890_7_head);
        const Space v891_3 = intersect(constant_8,v891_2);
        const Space v891_4 = (has_head(v891_3) ? constant_9 : Space{});
        const Space v891_5 = subtract(constant_0,v891_4);
        Space v891_8;
        if (!v891_5.empty()) {
          const Path v892_6 = concat_path(v890_6,v890_7_head);
          const Space v892_7 = routine_170(c, v892_6, p1, v890_7_tail);
          v891_8 = compose(v891_5,v892_7);
        }
        const Space v891_9 = intersect(constant_8,v891_2);
        const Space v891_10 = (has_head(v891_9) ? constant_9 : Space{});
        Space v891_12;
        if (!v891_10.empty()) {
          const Path v893_6 = concat_path(v890_6,v890_7_head);
          const Space v893_11 = routine_171(c, v893_6, p1, v890_7_tail);
          v891_12 = compose(v891_10,v893_11);
        }
        const Space v891_13 = unite(v891_8,v891_12);
        v890_7_result = unite(v890_7_result,v891_13);
      }
      const Space v890_7 = std::move(v890_7_result);
      v889_8 = compose(v889_5,v890_7);
    }
    const Space v889_9 = intersect(constant_8,v889_2);
    const Space v889_10 = (has_head(v889_9) ? constant_9 : Space{});
    Space v889_12;
    if (!v889_10.empty()) {
      const Path v894_6 = concat_path(p0,v888_12_head);
      Space v894_11_result;
      for (int v894_11_label = 1; v894_11_label <= 2; ++v894_11_label) {
        const Space v894_11_tail = child(v888_12_tail,v894_11_label);
        if (v894_11_tail.empty()) continue;
        const Path v894_11_head{v894_11_label};
        const Space v895_2 = singleton(v894_11_head);
        const Space v895_3 = intersect(constant_8,v895_2);
        const Space v895_4 = (has_head(v895_3) ? constant_9 : Space{});
        const Space v895_5 = subtract(constant_0,v895_4);
        Space v895_8;
        if (!v895_5.empty()) {
          const Path v896_6 = concat_path(v894_6,v894_11_head);
          const Space v896_7 = routine_170(c, v896_6, p1, v894_11_tail);
          v895_8 = compose(v895_5,v896_7);
        }
        const Space v895_9 = intersect(constant_8,v895_2);
        const Space v895_10 = (has_head(v895_9) ? constant_9 : Space{});
        Space v895_12;
        if (!v895_10.empty()) {
          const Path v897_6 = concat_path(v894_6,v894_11_head);
          const Space v897_11 = routine_60(c, v897_6, p1, v894_11_tail);
          v895_12 = compose(v895_10,v897_11);
        }
        const Space v895_13 = unite(v895_8,v895_12);
        v894_11_result = unite(v894_11_result,v895_13);
      }
      const Space v894_11 = std::move(v894_11_result);
      v889_12 = compose(v889_10,v894_11);
    }
    const Space v889_13 = unite(v889_8,v889_12);
    v888_12_result = unite(v888_12_result,v889_13);
  }
  const Space v888_12 = std::move(v888_12_result);
  return v888_12;
}

static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v898_17_result;
  for (int v898_17_label = 1; v898_17_label <= 2; ++v898_17_label) {
    const Space v898_17_tail = child(s0,v898_17_label);
    if (v898_17_tail.empty()) continue;
    const Path v898_17_head{v898_17_label};
    const Space v899_2 = singleton(v898_17_head);
    const Space v899_3 = intersect(constant_8,v899_2);
    const Space v899_4 = (has_head(v899_3) ? constant_9 : Space{});
    const Space v899_5 = subtract(constant_0,v899_4);
    Space v899_8;
    if (!v899_5.empty()) {
      const Path v900_6 = concat_path(p0,v898_17_head);
      Space v900_7_result;
      for (int v900_7_label = 1; v900_7_label <= 2; ++v900_7_label) {
        const Space v900_7_tail = child(v898_17_tail,v900_7_label);
        if (v900_7_tail.empty()) continue;
        const Path v900_7_head{v900_7_label};
        const Space v901_2 = singleton(v900_7_head);
        const Space v901_3 = intersect(constant_8,v901_2);
        const Space v901_4 = (has_head(v901_3) ? constant_9 : Space{});
        const Space v901_5 = subtract(constant_0,v901_4);
        Space v901_8;
        if (!v901_5.empty()) {
          const Path v902_6 = concat_path(v900_6,v900_7_head);
          const Space v902_7 = routine_170(c, v902_6, p1, v900_7_tail);
          v901_8 = compose(v901_5,v902_7);
        }
        const Space v901_9 = intersect(constant_8,v901_2);
        const Space v901_10 = (has_head(v901_9) ? constant_9 : Space{});
        Space v901_12;
        if (!v901_10.empty()) {
          const Path v903_6 = concat_path(v900_6,v900_7_head);
          const Space v903_11 = routine_171(c, v903_6, p1, v900_7_tail);
          v901_12 = compose(v901_10,v903_11);
        }
        const Space v901_13 = unite(v901_8,v901_12);
        v900_7_result = unite(v900_7_result,v901_13);
      }
      const Space v900_7 = std::move(v900_7_result);
      v899_8 = compose(v899_5,v900_7);
    }
    const Space v899_9 = intersect(constant_8,v899_2);
    const Space v899_10 = (has_head(v899_9) ? constant_9 : Space{});
    Space v899_17;
    if (!v899_10.empty()) {
      const Path v904_6 = concat_path(p0,v898_17_head);
      Space v904_14;
      if (!constant_0.empty()) {
        const Space v905_11 = routine_92(c, constant_14, constant_15);
        const Space v905_12 = routine_93(c, constant_16, constant_17);
        const Space v905_13 = unite(v905_11,v905_12);
        v904_14 = compose(constant_0,v905_13);
      }
      const Space v904_15 = unwrap(v904_14,p1);
      Space v904_16_result;
      for (int v904_16_label = 1; v904_16_label <= 2; ++v904_16_label) {
        const Space v904_16_tail = child(v904_15,v904_16_label);
        if (v904_16_tail.empty()) continue;
        const Path v904_16_head{v904_16_label};
        const Space v906_2 = singleton(v904_16_head);
        const Space v906_3 = intersect(constant_8,v906_2);
        const Space v906_4 = (has_head(v906_3) ? constant_9 : Space{});
        const Space v906_5 = subtract(constant_0,v906_4);
        Space v906_7;
        if (!v906_5.empty()) {
          const Space v907_6 = routine_94(c, v904_16_head, v904_6, v904_16_tail, v898_17_tail);
          v906_7 = compose(v906_5,v907_6);
        }
        const Space v906_8 = intersect(constant_8,v906_2);
        const Space v906_9 = (has_head(v906_8) ? constant_9 : Space{});
        Space v906_11;
        if (!v906_9.empty()) {
          const Space v908_10 = routine_95(c, v904_16_head, v904_6, v904_16_tail, v898_17_tail);
          v906_11 = compose(v906_9,v908_10);
        }
        const Space v906_12 = unite(v906_7,v906_11);
        v904_16_result = unite(v904_16_result,v906_12);
      }
      const Space v904_16 = std::move(v904_16_result);
      v899_17 = compose(v899_10,v904_16);
    }
    const Space v899_18 = unite(v899_8,v899_17);
    v898_17_result = unite(v898_17_result,v899_18);
  }
  const Space v898_17 = std::move(v898_17_result);
  return v898_17;
}

static Space routine_92(Context& c, const Path& p0, const Space& s0) {
  Space v909_11_result;
  for (int v909_11_label = 1; v909_11_label <= 2; ++v909_11_label) {
    const Space v909_11_tail = child(s0,v909_11_label);
    if (v909_11_tail.empty()) continue;
    const Path v909_11_head{v909_11_label};
    const Space v910_2 = singleton(v909_11_head);
    const Space v910_3 = intersect(constant_8,v910_2);
    const Space v910_4 = (has_head(v910_3) ? constant_9 : Space{});
    const Space v910_5 = subtract(constant_0,v910_4);
    Space v910_8;
    if (!v910_5.empty()) {
      const Path v911_6 = concat_path(p0,v909_11_head);
      Space v911_7_result;
      for (int v911_7_label = 1; v911_7_label <= 2; ++v911_7_label) {
        const Space v911_7_tail = child(v909_11_tail,v911_7_label);
        if (v911_7_tail.empty()) continue;
        const Path v911_7_head{v911_7_label};
        const Space v912_2 = singleton(v911_7_head);
        const Space v912_3 = intersect(constant_8,v912_2);
        const Space v912_4 = (has_head(v912_3) ? constant_9 : Space{});
        const Space v912_5 = subtract(constant_0,v912_4);
        Space v912_8;
        if (!v912_5.empty()) {
          const Path v913_6 = concat_path(v911_6,v911_7_head);
          const Space v913_7 = routine_172(c, v913_6, v911_7_tail);
          v912_8 = compose(v912_5,v913_7);
        }
        const Space v912_9 = intersect(constant_8,v912_2);
        const Space v912_10 = (has_head(v912_9) ? constant_9 : Space{});
        Space v912_12;
        if (!v912_10.empty()) {
          const Path v914_6 = concat_path(v911_6,v911_7_head);
          const Space v914_11 = routine_173(c, v914_6, v911_7_tail);
          v912_12 = compose(v912_10,v914_11);
        }
        const Space v912_13 = unite(v912_8,v912_12);
        v911_7_result = unite(v911_7_result,v912_13);
      }
      const Space v911_7 = std::move(v911_7_result);
      v910_8 = compose(v910_5,v911_7);
    }
    const Space v910_9 = intersect(constant_8,v910_2);
    const Space v910_10 = (has_head(v910_9) ? constant_9 : Space{});
    Space v910_12;
    if (!v910_10.empty()) {
      const Path v915_6 = concat_path(p0,v909_11_head);
      Space v915_11_result;
      for (int v915_11_label = 1; v915_11_label <= 2; ++v915_11_label) {
        const Space v915_11_tail = child(v909_11_tail,v915_11_label);
        if (v915_11_tail.empty()) continue;
        const Path v915_11_head{v915_11_label};
        const Space v916_2 = singleton(v915_11_head);
        const Space v916_3 = intersect(constant_8,v916_2);
        const Space v916_4 = (has_head(v916_3) ? constant_9 : Space{});
        const Space v916_5 = subtract(constant_0,v916_4);
        Space v916_8;
        if (!v916_5.empty()) {
          const Path v917_6 = concat_path(v915_6,v915_11_head);
          const Space v917_7 = routine_172(c, v917_6, v915_11_tail);
          v916_8 = compose(v916_5,v917_7);
        }
        const Space v916_9 = intersect(constant_8,v916_2);
        const Space v916_10 = (has_head(v916_9) ? constant_9 : Space{});
        Space v916_12;
        if (!v916_10.empty()) {
          const Path v918_6 = concat_path(v915_6,v915_11_head);
          const Space v918_11 = routine_130(c, v918_6, v915_11_tail);
          v916_12 = compose(v916_10,v918_11);
        }
        const Space v916_13 = unite(v916_8,v916_12);
        v915_11_result = unite(v915_11_result,v916_13);
      }
      const Space v915_11 = std::move(v915_11_result);
      v910_12 = compose(v910_10,v915_11);
    }
    const Space v910_13 = unite(v910_8,v910_12);
    v909_11_result = unite(v909_11_result,v910_13);
  }
  const Space v909_11 = std::move(v909_11_result);
  return v909_11;
}

static Space routine_93(Context& c, const Path& p0, const Space& s0) {
  Space v919_11_result;
  for (int v919_11_label = 1; v919_11_label <= 2; ++v919_11_label) {
    const Space v919_11_tail = child(s0,v919_11_label);
    if (v919_11_tail.empty()) continue;
    const Path v919_11_head{v919_11_label};
    const Space v920_2 = singleton(v919_11_head);
    const Space v920_3 = intersect(constant_8,v920_2);
    const Space v920_4 = (has_head(v920_3) ? constant_9 : Space{});
    const Space v920_5 = subtract(constant_0,v920_4);
    Space v920_8;
    if (!v920_5.empty()) {
      const Path v921_6 = concat_path(p0,v919_11_head);
      Space v921_7_result;
      for (int v921_7_label = 1; v921_7_label <= 2; ++v921_7_label) {
        const Space v921_7_tail = child(v919_11_tail,v921_7_label);
        if (v921_7_tail.empty()) continue;
        const Path v921_7_head{v921_7_label};
        const Space v922_2 = singleton(v921_7_head);
        const Space v922_3 = intersect(constant_8,v922_2);
        const Space v922_4 = (has_head(v922_3) ? constant_9 : Space{});
        const Space v922_5 = subtract(constant_0,v922_4);
        Space v922_8;
        if (!v922_5.empty()) {
          const Path v923_6 = concat_path(v921_6,v921_7_head);
          const Space v923_7 = routine_172(c, v923_6, v921_7_tail);
          v922_8 = compose(v922_5,v923_7);
        }
        const Space v922_9 = intersect(constant_8,v922_2);
        const Space v922_10 = (has_head(v922_9) ? constant_9 : Space{});
        Space v922_12;
        if (!v922_10.empty()) {
          const Path v924_6 = concat_path(v921_6,v921_7_head);
          const Space v924_11 = routine_173(c, v924_6, v921_7_tail);
          v922_12 = compose(v922_10,v924_11);
        }
        const Space v922_13 = unite(v922_8,v922_12);
        v921_7_result = unite(v921_7_result,v922_13);
      }
      const Space v921_7 = std::move(v921_7_result);
      v920_8 = compose(v920_5,v921_7);
    }
    const Space v920_9 = intersect(constant_8,v920_2);
    const Space v920_10 = (has_head(v920_9) ? constant_9 : Space{});
    Space v920_12;
    if (!v920_10.empty()) {
      const Path v925_6 = concat_path(p0,v919_11_head);
      Space v925_11_result;
      for (int v925_11_label = 1; v925_11_label <= 2; ++v925_11_label) {
        const Space v925_11_tail = child(v919_11_tail,v925_11_label);
        if (v925_11_tail.empty()) continue;
        const Path v925_11_head{v925_11_label};
        const Space v926_2 = singleton(v925_11_head);
        const Space v926_3 = intersect(constant_8,v926_2);
        const Space v926_4 = (has_head(v926_3) ? constant_9 : Space{});
        const Space v926_5 = subtract(constant_0,v926_4);
        Space v926_7;
        if (!v926_5.empty()) {
          const Space v927_6 = routine_174(c, v925_11_head, v925_6, v925_11_tail);
          v926_7 = compose(v926_5,v927_6);
        }
        const Space v926_8 = intersect(constant_8,v926_2);
        const Space v926_9 = (has_head(v926_8) ? constant_9 : Space{});
        Space v926_11;
        if (!v926_9.empty()) {
          const Space v928_10 = routine_175(c, v925_11_head, v925_6, v925_11_tail);
          v926_11 = compose(v926_9,v928_10);
        }
        const Space v926_12 = unite(v926_7,v926_11);
        v925_11_result = unite(v925_11_result,v926_12);
      }
      const Space v925_11 = std::move(v925_11_result);
      v920_12 = compose(v920_10,v925_11);
    }
    const Space v920_13 = unite(v920_8,v920_12);
    v919_11_result = unite(v919_11_result,v920_13);
  }
  const Space v919_11 = std::move(v919_11_result);
  return v919_11;
}

static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v929_13_result;
  for (int v929_13_label = 1; v929_13_label <= 2; ++v929_13_label) {
    const Space v929_13_tail = child(s0,v929_13_label);
    if (v929_13_tail.empty()) continue;
    const Path v929_13_head{v929_13_label};
    const Space v930_2 = singleton(v929_13_head);
    const Space v930_3 = intersect(constant_8,v930_2);
    const Space v930_4 = (has_head(v930_3) ? constant_9 : Space{});
    const Space v930_5 = subtract(constant_0,v930_4);
    Space v930_8;
    if (!v930_5.empty()) {
      const Path v931_6 = concat_path(p0,v929_13_head);
      Space v931_7_result;
      for (int v931_7_label = 1; v931_7_label <= 2; ++v931_7_label) {
        const Space v931_7_tail = child(v929_13_tail,v931_7_label);
        if (v931_7_tail.empty()) continue;
        const Path v931_7_head{v931_7_label};
        const Space v932_2 = singleton(v931_7_head);
        const Space v932_3 = intersect(constant_8,v932_2);
        const Space v932_4 = (has_head(v932_3) ? constant_9 : Space{});
        const Space v932_5 = subtract(constant_0,v932_4);
        Space v932_8;
        if (!v932_5.empty()) {
          const Path v933_6 = concat_path(v931_6,v931_7_head);
          const Space v933_7 = routine_176(c, v933_6, p1, v931_7_tail, s1);
          v932_8 = compose(v932_5,v933_7);
        }
        const Space v932_9 = intersect(constant_8,v932_2);
        const Space v932_10 = (has_head(v932_9) ? constant_9 : Space{});
        Space v932_12;
        if (!v932_10.empty()) {
          const Path v934_6 = concat_path(v931_6,v931_7_head);
          const Space v934_11 = routine_177(c, v934_6, p1, v931_7_tail, s1);
          v932_12 = compose(v932_10,v934_11);
        }
        const Space v932_13 = unite(v932_8,v932_12);
        v931_7_result = unite(v931_7_result,v932_13);
      }
      const Space v931_7 = std::move(v931_7_result);
      v930_8 = compose(v930_5,v931_7);
    }
    const Space v930_9 = intersect(constant_8,v930_2);
    const Space v930_10 = (has_head(v930_9) ? constant_9 : Space{});
    Space v930_12;
    if (!v930_10.empty()) {
      const Path v935_6 = concat_path(p0,v929_13_head);
      Space v935_11_result;
      for (int v935_11_label = 1; v935_11_label <= 2; ++v935_11_label) {
        const Space v935_11_tail = child(v929_13_tail,v935_11_label);
        if (v935_11_tail.empty()) continue;
        const Path v935_11_head{v935_11_label};
        const Space v936_2 = singleton(v935_11_head);
        const Space v936_3 = intersect(constant_8,v936_2);
        const Space v936_4 = (has_head(v936_3) ? constant_9 : Space{});
        const Space v936_5 = subtract(constant_0,v936_4);
        Space v936_8;
        if (!v936_5.empty()) {
          const Path v937_6 = concat_path(v935_6,v935_11_head);
          const Space v937_7 = routine_176(c, v937_6, p1, v935_11_tail, s1);
          v936_8 = compose(v936_5,v937_7);
        }
        const Space v936_9 = intersect(constant_8,v936_2);
        const Space v936_10 = (has_head(v936_9) ? constant_9 : Space{});
        Space v936_12;
        if (!v936_10.empty()) {
          const Path v938_6 = concat_path(v935_6,v935_11_head);
          const Space v938_11 = routine_133(c, v938_6, p1, v935_11_tail, s1);
          v936_12 = compose(v936_10,v938_11);
        }
        const Space v936_13 = unite(v936_8,v936_12);
        v935_11_result = unite(v935_11_result,v936_13);
      }
      const Space v935_11 = std::move(v935_11_result);
      v930_12 = compose(v930_10,v935_11);
    }
    const Space v930_13 = unite(v930_8,v930_12);
    v929_13_result = unite(v929_13_result,v930_13);
  }
  const Space v929_13 = std::move(v929_13_result);
  return v929_13;
}

static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v939_10_result;
  for (int v939_10_label = 1; v939_10_label <= 2; ++v939_10_label) {
    const Space v939_10_tail = child(s0,v939_10_label);
    if (v939_10_tail.empty()) continue;
    const Path v939_10_head{v939_10_label};
    const Space v940_2 = singleton(v939_10_head);
    const Space v940_3 = intersect(constant_8,v940_2);
    const Space v940_4 = (has_head(v940_3) ? constant_9 : Space{});
    const Space v940_5 = subtract(constant_0,v940_4);
    Space v940_8;
    if (!v940_5.empty()) {
      const Path v941_6 = concat_path(p0,v939_10_head);
      Space v941_7_result;
      for (int v941_7_label = 1; v941_7_label <= 2; ++v941_7_label) {
        const Space v941_7_tail = child(v939_10_tail,v941_7_label);
        if (v941_7_tail.empty()) continue;
        const Path v941_7_head{v941_7_label};
        const Space v942_2 = singleton(v941_7_head);
        const Space v942_3 = intersect(constant_8,v942_2);
        const Space v942_4 = (has_head(v942_3) ? constant_9 : Space{});
        const Space v942_5 = subtract(constant_0,v942_4);
        Space v942_8;
        if (!v942_5.empty()) {
          const Path v943_6 = concat_path(v941_6,v941_7_head);
          const Space v943_7 = routine_176(c, v943_6, p1, v941_7_tail, s1);
          v942_8 = compose(v942_5,v943_7);
        }
        const Space v942_9 = intersect(constant_8,v942_2);
        const Space v942_10 = (has_head(v942_9) ? constant_9 : Space{});
        Space v942_12;
        if (!v942_10.empty()) {
          const Path v944_6 = concat_path(v941_6,v941_7_head);
          const Space v944_11 = routine_177(c, v944_6, p1, v941_7_tail, s1);
          v942_12 = compose(v942_10,v944_11);
        }
        const Space v942_13 = unite(v942_8,v942_12);
        v941_7_result = unite(v941_7_result,v942_13);
      }
      const Space v941_7 = std::move(v941_7_result);
      v940_8 = compose(v940_5,v941_7);
    }
    const Space v940_9 = intersect(constant_8,v940_2);
    const Space v940_10 = (has_head(v940_9) ? constant_9 : Space{});
    const Space v940_11 = unwrap(v939_10_tail,p1);
    const Path v945_6 = concat_path(p0,v939_10_head);
    const Space v940_12 = wrap(v940_11,v945_6);
    const Space v940_13 = compose(v940_12,s1);
    const Space v940_14 = compose(v940_10,v940_13);
    const Space v940_15 = unite(v940_8,v940_14);
    v939_10_result = unite(v939_10_result,v940_15);
  }
  const Space v939_10 = std::move(v939_10_result);
  return v939_10;
}

static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v946_12_result;
  for (int v946_12_label = 1; v946_12_label <= 2; ++v946_12_label) {
    const Space v946_12_tail = child(s0,v946_12_label);
    if (v946_12_tail.empty()) continue;
    const Path v946_12_head{v946_12_label};
    const Space v947_2 = singleton(v946_12_head);
    const Space v947_3 = intersect(constant_8,v947_2);
    const Space v947_4 = (has_head(v947_3) ? constant_9 : Space{});
    const Space v947_5 = subtract(constant_0,v947_4);
    Space v947_8;
    if (!v947_5.empty()) {
      const Path v948_6 = concat_path(p0,v946_12_head);
      Space v948_7_result;
      for (int v948_7_label = 1; v948_7_label <= 2; ++v948_7_label) {
        const Space v948_7_tail = child(v946_12_tail,v948_7_label);
        if (v948_7_tail.empty()) continue;
        const Path v948_7_head{v948_7_label};
        const Space v949_2 = singleton(v948_7_head);
        const Space v949_3 = intersect(constant_8,v949_2);
        const Space v949_4 = (has_head(v949_3) ? constant_9 : Space{});
        const Space v949_5 = subtract(constant_0,v949_4);
        Space v949_8;
        if (!v949_5.empty()) {
          const Path v950_6 = concat_path(v948_6,v948_7_head);
          const Space v950_7 = routine_178(c, v950_6, p1, v948_7_tail);
          v949_8 = compose(v949_5,v950_7);
        }
        const Space v949_9 = intersect(constant_8,v949_2);
        const Space v949_10 = (has_head(v949_9) ? constant_9 : Space{});
        Space v949_12;
        if (!v949_10.empty()) {
          const Path v951_6 = concat_path(v948_6,v948_7_head);
          const Space v951_11 = routine_179(c, v951_6, p1, v948_7_tail);
          v949_12 = compose(v949_10,v951_11);
        }
        const Space v949_13 = unite(v949_8,v949_12);
        v948_7_result = unite(v948_7_result,v949_13);
      }
      const Space v948_7 = std::move(v948_7_result);
      v947_8 = compose(v947_5,v948_7);
    }
    const Space v947_9 = intersect(constant_8,v947_2);
    const Space v947_10 = (has_head(v947_9) ? constant_9 : Space{});
    Space v947_12;
    if (!v947_10.empty()) {
      const Path v952_6 = concat_path(p0,v946_12_head);
      Space v952_11_result;
      for (int v952_11_label = 1; v952_11_label <= 2; ++v952_11_label) {
        const Space v952_11_tail = child(v946_12_tail,v952_11_label);
        if (v952_11_tail.empty()) continue;
        const Path v952_11_head{v952_11_label};
        const Space v953_2 = singleton(v952_11_head);
        const Space v953_3 = intersect(constant_8,v953_2);
        const Space v953_4 = (has_head(v953_3) ? constant_9 : Space{});
        const Space v953_5 = subtract(constant_0,v953_4);
        Space v953_8;
        if (!v953_5.empty()) {
          const Path v954_6 = concat_path(v952_6,v952_11_head);
          const Space v954_7 = routine_178(c, v954_6, p1, v952_11_tail);
          v953_8 = compose(v953_5,v954_7);
        }
        const Space v953_9 = intersect(constant_8,v953_2);
        const Space v953_10 = (has_head(v953_9) ? constant_9 : Space{});
        Space v953_12;
        if (!v953_10.empty()) {
          const Path v955_6 = concat_path(v952_6,v952_11_head);
          const Space v955_11 = routine_63(c, v955_6, p1, v952_11_tail);
          v953_12 = compose(v953_10,v955_11);
        }
        const Space v953_13 = unite(v953_8,v953_12);
        v952_11_result = unite(v952_11_result,v953_13);
      }
      const Space v952_11 = std::move(v952_11_result);
      v947_12 = compose(v947_10,v952_11);
    }
    const Space v947_13 = unite(v947_8,v947_12);
    v946_12_result = unite(v946_12_result,v947_13);
  }
  const Space v946_12 = std::move(v946_12_result);
  return v946_12;
}

static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v956_17_result;
  for (int v956_17_label = 1; v956_17_label <= 2; ++v956_17_label) {
    const Space v956_17_tail = child(s0,v956_17_label);
    if (v956_17_tail.empty()) continue;
    const Path v956_17_head{v956_17_label};
    const Space v957_2 = singleton(v956_17_head);
    const Space v957_3 = intersect(constant_8,v957_2);
    const Space v957_4 = (has_head(v957_3) ? constant_9 : Space{});
    const Space v957_5 = subtract(constant_0,v957_4);
    Space v957_8;
    if (!v957_5.empty()) {
      const Path v958_6 = concat_path(p0,v956_17_head);
      Space v958_7_result;
      for (int v958_7_label = 1; v958_7_label <= 2; ++v958_7_label) {
        const Space v958_7_tail = child(v956_17_tail,v958_7_label);
        if (v958_7_tail.empty()) continue;
        const Path v958_7_head{v958_7_label};
        const Space v959_2 = singleton(v958_7_head);
        const Space v959_3 = intersect(constant_8,v959_2);
        const Space v959_4 = (has_head(v959_3) ? constant_9 : Space{});
        const Space v959_5 = subtract(constant_0,v959_4);
        Space v959_8;
        if (!v959_5.empty()) {
          const Path v960_6 = concat_path(v958_6,v958_7_head);
          const Space v960_7 = routine_178(c, v960_6, p1, v958_7_tail);
          v959_8 = compose(v959_5,v960_7);
        }
        const Space v959_9 = intersect(constant_8,v959_2);
        const Space v959_10 = (has_head(v959_9) ? constant_9 : Space{});
        Space v959_12;
        if (!v959_10.empty()) {
          const Path v961_6 = concat_path(v958_6,v958_7_head);
          const Space v961_11 = routine_179(c, v961_6, p1, v958_7_tail);
          v959_12 = compose(v959_10,v961_11);
        }
        const Space v959_13 = unite(v959_8,v959_12);
        v958_7_result = unite(v958_7_result,v959_13);
      }
      const Space v958_7 = std::move(v958_7_result);
      v957_8 = compose(v957_5,v958_7);
    }
    const Space v957_9 = intersect(constant_8,v957_2);
    const Space v957_10 = (has_head(v957_9) ? constant_9 : Space{});
    Space v957_20;
    if (!v957_10.empty()) {
      Space v962_14;
      if (!constant_0.empty()) {
        const Space v963_11 = routine_98(c, constant_14, constant_15);
        const Space v963_12 = routine_99(c, constant_16, constant_17);
        const Space v963_13 = unite(v963_11,v963_12);
        v962_14 = compose(constant_0,v963_13);
      }
      const Space v962_15 = unwrap(v962_14,p1);
      const Space v962_16 = unwrap(v962_15,p0);
      const Space v962_17 = unwrap(v962_16,v956_17_head);
      const Space v962_18 = unwrap(v962_17,p1);
      Space v962_19_result;
      for (int v962_19_label = 1; v962_19_label <= 2; ++v962_19_label) {
        const Space v962_19_tail = child(v962_18,v962_19_label);
        if (v962_19_tail.empty()) continue;
        const Path v962_19_head{v962_19_label};
        const Space v964_2 = singleton(v962_19_head);
        const Space v964_3 = intersect(constant_8,v964_2);
        const Space v964_4 = (has_head(v964_3) ? constant_9 : Space{});
        const Space v964_5 = subtract(constant_0,v964_4);
        Space v964_7;
        if (!v964_5.empty()) {
          const Space v965_6 = routine_100(c, v962_19_head, v962_19_tail, v956_17_tail);
          v964_7 = compose(v964_5,v965_6);
        }
        const Space v964_8 = intersect(constant_8,v964_2);
        const Space v964_9 = (has_head(v964_8) ? constant_9 : Space{});
        Space v964_11;
        if (!v964_9.empty()) {
          const Space v966_10 = routine_101(c, v962_19_head, v962_19_tail, v956_17_tail);
          v964_11 = compose(v964_9,v966_10);
        }
        const Space v964_12 = unite(v964_7,v964_11);
        v962_19_result = unite(v962_19_result,v964_12);
      }
      const Space v962_19 = std::move(v962_19_result);
      v957_20 = compose(v957_10,v962_19);
    }
    const Space v957_21 = unite(v957_8,v957_20);
    v956_17_result = unite(v956_17_result,v957_21);
  }
  const Space v956_17 = std::move(v956_17_result);
  return v956_17;
}

static Space routine_98(Context& c, const Path& p0, const Space& s0) {
  Space v967_11_result;
  for (int v967_11_label = 1; v967_11_label <= 2; ++v967_11_label) {
    const Space v967_11_tail = child(s0,v967_11_label);
    if (v967_11_tail.empty()) continue;
    const Path v967_11_head{v967_11_label};
    const Space v968_2 = singleton(v967_11_head);
    const Space v968_3 = intersect(constant_8,v968_2);
    const Space v968_4 = (has_head(v968_3) ? constant_9 : Space{});
    const Space v968_5 = subtract(constant_0,v968_4);
    Space v968_8;
    if (!v968_5.empty()) {
      const Path v969_6 = concat_path(p0,v967_11_head);
      Space v969_7_result;
      for (int v969_7_label = 1; v969_7_label <= 2; ++v969_7_label) {
        const Space v969_7_tail = child(v967_11_tail,v969_7_label);
        if (v969_7_tail.empty()) continue;
        const Path v969_7_head{v969_7_label};
        const Space v970_2 = singleton(v969_7_head);
        const Space v970_3 = intersect(constant_8,v970_2);
        const Space v970_4 = (has_head(v970_3) ? constant_9 : Space{});
        const Space v970_5 = subtract(constant_0,v970_4);
        Space v970_8;
        if (!v970_5.empty()) {
          const Path v971_6 = concat_path(v969_6,v969_7_head);
          const Space v971_7 = routine_180(c, v971_6, v969_7_tail);
          v970_8 = compose(v970_5,v971_7);
        }
        const Space v970_9 = intersect(constant_8,v970_2);
        const Space v970_10 = (has_head(v970_9) ? constant_9 : Space{});
        Space v970_12;
        if (!v970_10.empty()) {
          const Path v972_6 = concat_path(v969_6,v969_7_head);
          const Space v972_11 = routine_181(c, v972_6, v969_7_tail);
          v970_12 = compose(v970_10,v972_11);
        }
        const Space v970_13 = unite(v970_8,v970_12);
        v969_7_result = unite(v969_7_result,v970_13);
      }
      const Space v969_7 = std::move(v969_7_result);
      v968_8 = compose(v968_5,v969_7);
    }
    const Space v968_9 = intersect(constant_8,v968_2);
    const Space v968_10 = (has_head(v968_9) ? constant_9 : Space{});
    Space v968_12;
    if (!v968_10.empty()) {
      const Path v973_6 = concat_path(p0,v967_11_head);
      Space v973_11_result;
      for (int v973_11_label = 1; v973_11_label <= 2; ++v973_11_label) {
        const Space v973_11_tail = child(v967_11_tail,v973_11_label);
        if (v973_11_tail.empty()) continue;
        const Path v973_11_head{v973_11_label};
        const Space v974_2 = singleton(v973_11_head);
        const Space v974_3 = intersect(constant_8,v974_2);
        const Space v974_4 = (has_head(v974_3) ? constant_9 : Space{});
        const Space v974_5 = subtract(constant_0,v974_4);
        Space v974_8;
        if (!v974_5.empty()) {
          const Path v975_6 = concat_path(v973_6,v973_11_head);
          const Space v975_7 = routine_180(c, v975_6, v973_11_tail);
          v974_8 = compose(v974_5,v975_7);
        }
        const Space v974_9 = intersect(constant_8,v974_2);
        const Space v974_10 = (has_head(v974_9) ? constant_9 : Space{});
        Space v974_12;
        if (!v974_10.empty()) {
          const Path v976_6 = concat_path(v973_6,v973_11_head);
          const Space v976_11 = routine_138(c, v976_6, v973_11_tail);
          v974_12 = compose(v974_10,v976_11);
        }
        const Space v974_13 = unite(v974_8,v974_12);
        v973_11_result = unite(v973_11_result,v974_13);
      }
      const Space v973_11 = std::move(v973_11_result);
      v968_12 = compose(v968_10,v973_11);
    }
    const Space v968_13 = unite(v968_8,v968_12);
    v967_11_result = unite(v967_11_result,v968_13);
  }
  const Space v967_11 = std::move(v967_11_result);
  return v967_11;
}

static Space routine_99(Context& c, const Path& p0, const Space& s0) {
  Space v977_11_result;
  for (int v977_11_label = 1; v977_11_label <= 2; ++v977_11_label) {
    const Space v977_11_tail = child(s0,v977_11_label);
    if (v977_11_tail.empty()) continue;
    const Path v977_11_head{v977_11_label};
    const Space v978_2 = singleton(v977_11_head);
    const Space v978_3 = intersect(constant_8,v978_2);
    const Space v978_4 = (has_head(v978_3) ? constant_9 : Space{});
    const Space v978_5 = subtract(constant_0,v978_4);
    Space v978_8;
    if (!v978_5.empty()) {
      const Path v979_6 = concat_path(p0,v977_11_head);
      Space v979_7_result;
      for (int v979_7_label = 1; v979_7_label <= 2; ++v979_7_label) {
        const Space v979_7_tail = child(v977_11_tail,v979_7_label);
        if (v979_7_tail.empty()) continue;
        const Path v979_7_head{v979_7_label};
        const Space v980_2 = singleton(v979_7_head);
        const Space v980_3 = intersect(constant_8,v980_2);
        const Space v980_4 = (has_head(v980_3) ? constant_9 : Space{});
        const Space v980_5 = subtract(constant_0,v980_4);
        Space v980_8;
        if (!v980_5.empty()) {
          const Path v981_6 = concat_path(v979_6,v979_7_head);
          const Space v981_7 = routine_180(c, v981_6, v979_7_tail);
          v980_8 = compose(v980_5,v981_7);
        }
        const Space v980_9 = intersect(constant_8,v980_2);
        const Space v980_10 = (has_head(v980_9) ? constant_9 : Space{});
        Space v980_12;
        if (!v980_10.empty()) {
          const Path v982_6 = concat_path(v979_6,v979_7_head);
          const Space v982_11 = routine_181(c, v982_6, v979_7_tail);
          v980_12 = compose(v980_10,v982_11);
        }
        const Space v980_13 = unite(v980_8,v980_12);
        v979_7_result = unite(v979_7_result,v980_13);
      }
      const Space v979_7 = std::move(v979_7_result);
      v978_8 = compose(v978_5,v979_7);
    }
    const Space v978_9 = intersect(constant_8,v978_2);
    const Space v978_10 = (has_head(v978_9) ? constant_9 : Space{});
    Space v978_12;
    if (!v978_10.empty()) {
      const Path v983_6 = concat_path(p0,v977_11_head);
      Space v983_11_result;
      for (int v983_11_label = 1; v983_11_label <= 2; ++v983_11_label) {
        const Space v983_11_tail = child(v977_11_tail,v983_11_label);
        if (v983_11_tail.empty()) continue;
        const Path v983_11_head{v983_11_label};
        const Space v984_2 = singleton(v983_11_head);
        const Space v984_3 = intersect(constant_8,v984_2);
        const Space v984_4 = (has_head(v984_3) ? constant_9 : Space{});
        const Space v984_5 = subtract(constant_0,v984_4);
        Space v984_7;
        if (!v984_5.empty()) {
          const Space v985_6 = routine_182(c, v983_11_head, v983_6, v983_11_tail);
          v984_7 = compose(v984_5,v985_6);
        }
        const Space v984_8 = intersect(constant_8,v984_2);
        const Space v984_9 = (has_head(v984_8) ? constant_9 : Space{});
        Space v984_11;
        if (!v984_9.empty()) {
          const Space v986_10 = routine_183(c, v983_11_head, v983_6, v983_11_tail);
          v984_11 = compose(v984_9,v986_10);
        }
        const Space v984_12 = unite(v984_7,v984_11);
        v983_11_result = unite(v983_11_result,v984_12);
      }
      const Space v983_11 = std::move(v983_11_result);
      v978_12 = compose(v978_10,v983_11);
    }
    const Space v978_13 = unite(v978_8,v978_12);
    v977_11_result = unite(v977_11_result,v978_13);
  }
  const Space v977_11 = std::move(v977_11_result);
  return v977_11;
}

static Space routine_100(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v987_12_result;
  for (int v987_12_label = 1; v987_12_label <= 2; ++v987_12_label) {
    const Space v987_12_tail = child(s0,v987_12_label);
    if (v987_12_tail.empty()) continue;
    const Path v987_12_head{v987_12_label};
    const Space v988_2 = singleton(v987_12_head);
    const Space v988_3 = intersect(constant_8,v988_2);
    const Space v988_4 = (has_head(v988_3) ? constant_9 : Space{});
    const Space v988_5 = subtract(constant_0,v988_4);
    Space v988_8;
    if (!v988_5.empty()) {
      const Path v989_6 = concat_path(p0,v987_12_head);
      Space v989_7_result;
      for (int v989_7_label = 1; v989_7_label <= 2; ++v989_7_label) {
        const Space v989_7_tail = child(v987_12_tail,v989_7_label);
        if (v989_7_tail.empty()) continue;
        const Path v989_7_head{v989_7_label};
        const Space v990_2 = singleton(v989_7_head);
        const Space v990_3 = intersect(constant_8,v990_2);
        const Space v990_4 = (has_head(v990_3) ? constant_9 : Space{});
        const Space v990_5 = subtract(constant_0,v990_4);
        Space v990_8;
        if (!v990_5.empty()) {
          const Path v991_6 = concat_path(v989_6,v989_7_head);
          const Space v991_7 = routine_184(c, v991_6, v989_7_tail, s1);
          v990_8 = compose(v990_5,v991_7);
        }
        const Space v990_9 = intersect(constant_8,v990_2);
        const Space v990_10 = (has_head(v990_9) ? constant_9 : Space{});
        Space v990_12;
        if (!v990_10.empty()) {
          const Path v992_6 = concat_path(v989_6,v989_7_head);
          const Space v992_11 = routine_185(c, v992_6, v989_7_tail, s1);
          v990_12 = compose(v990_10,v992_11);
        }
        const Space v990_13 = unite(v990_8,v990_12);
        v989_7_result = unite(v989_7_result,v990_13);
      }
      const Space v989_7 = std::move(v989_7_result);
      v988_8 = compose(v988_5,v989_7);
    }
    const Space v988_9 = intersect(constant_8,v988_2);
    const Space v988_10 = (has_head(v988_9) ? constant_9 : Space{});
    Space v988_12;
    if (!v988_10.empty()) {
      const Path v993_6 = concat_path(p0,v987_12_head);
      Space v993_11_result;
      for (int v993_11_label = 1; v993_11_label <= 2; ++v993_11_label) {
        const Space v993_11_tail = child(v987_12_tail,v993_11_label);
        if (v993_11_tail.empty()) continue;
        const Path v993_11_head{v993_11_label};
        const Space v994_2 = singleton(v993_11_head);
        const Space v994_3 = intersect(constant_8,v994_2);
        const Space v994_4 = (has_head(v994_3) ? constant_9 : Space{});
        const Space v994_5 = subtract(constant_0,v994_4);
        Space v994_8;
        if (!v994_5.empty()) {
          const Path v995_6 = concat_path(v993_6,v993_11_head);
          const Space v995_7 = routine_184(c, v995_6, v993_11_tail, s1);
          v994_8 = compose(v994_5,v995_7);
        }
        const Space v994_9 = intersect(constant_8,v994_2);
        const Space v994_10 = (has_head(v994_9) ? constant_9 : Space{});
        Space v994_12;
        if (!v994_10.empty()) {
          const Path v996_6 = concat_path(v993_6,v993_11_head);
          const Space v996_11 = routine_141(c, v996_6, v993_11_tail, s1);
          v994_12 = compose(v994_10,v996_11);
        }
        const Space v994_13 = unite(v994_8,v994_12);
        v993_11_result = unite(v993_11_result,v994_13);
      }
      const Space v993_11 = std::move(v993_11_result);
      v988_12 = compose(v988_10,v993_11);
    }
    const Space v988_13 = unite(v988_8,v988_12);
    v987_12_result = unite(v987_12_result,v988_13);
  }
  const Space v987_12 = std::move(v987_12_result);
  return v987_12;
}

static Space routine_101(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v997_9_result;
  for (int v997_9_label = 1; v997_9_label <= 2; ++v997_9_label) {
    const Space v997_9_tail = child(s0,v997_9_label);
    if (v997_9_tail.empty()) continue;
    const Path v997_9_head{v997_9_label};
    const Space v998_2 = singleton(v997_9_head);
    const Space v998_3 = intersect(constant_8,v998_2);
    const Space v998_4 = (has_head(v998_3) ? constant_9 : Space{});
    const Space v998_5 = subtract(constant_0,v998_4);
    Space v998_8;
    if (!v998_5.empty()) {
      const Path v999_6 = concat_path(p0,v997_9_head);
      Space v999_7_result;
      for (int v999_7_label = 1; v999_7_label <= 2; ++v999_7_label) {
        const Space v999_7_tail = child(v997_9_tail,v999_7_label);
        if (v999_7_tail.empty()) continue;
        const Path v999_7_head{v999_7_label};
        const Space v1000_2 = singleton(v999_7_head);
        const Space v1000_3 = intersect(constant_8,v1000_2);
        const Space v1000_4 = (has_head(v1000_3) ? constant_9 : Space{});
        const Space v1000_5 = subtract(constant_0,v1000_4);
        Space v1000_8;
        if (!v1000_5.empty()) {
          const Path v1001_6 = concat_path(v999_6,v999_7_head);
          const Space v1001_7 = routine_184(c, v1001_6, v999_7_tail, s1);
          v1000_8 = compose(v1000_5,v1001_7);
        }
        const Space v1000_9 = intersect(constant_8,v1000_2);
        const Space v1000_10 = (has_head(v1000_9) ? constant_9 : Space{});
        Space v1000_12;
        if (!v1000_10.empty()) {
          const Path v1002_6 = concat_path(v999_6,v999_7_head);
          const Space v1002_11 = routine_185(c, v1002_6, v999_7_tail, s1);
          v1000_12 = compose(v1000_10,v1002_11);
        }
        const Space v1000_13 = unite(v1000_8,v1000_12);
        v999_7_result = unite(v999_7_result,v1000_13);
      }
      const Space v999_7 = std::move(v999_7_result);
      v998_8 = compose(v998_5,v999_7);
    }
    const Space v998_9 = intersect(constant_8,v998_2);
    const Space v998_10 = (has_head(v998_9) ? constant_9 : Space{});
    Space v998_12;
    if (!v998_10.empty()) {
      const Path v1003_6 = concat_path(p0,v997_9_head);
      const Space v1003_11 = routine_186(c, v1003_6, s1);
      v998_12 = compose(v998_10,v1003_11);
    }
    const Space v998_13 = unite(v998_8,v998_12);
    v997_9_result = unite(v997_9_result,v998_13);
  }
  const Space v997_9 = std::move(v997_9_result);
  return v997_9;
}

static Space routine_102(Context& c, const Path& p0, const Space& s0) {
  Space v1004_11_result;
  for (int v1004_11_label = 1; v1004_11_label <= 2; ++v1004_11_label) {
    const Space v1004_11_tail = child(s0,v1004_11_label);
    if (v1004_11_tail.empty()) continue;
    const Path v1004_11_head{v1004_11_label};
    const Space v1005_2 = singleton(v1004_11_head);
    const Space v1005_3 = intersect(constant_8,v1005_2);
    const Space v1005_4 = (has_head(v1005_3) ? constant_9 : Space{});
    const Space v1005_5 = subtract(constant_0,v1005_4);
    Space v1005_8;
    if (!v1005_5.empty()) {
      const Path v1006_6 = concat_path(p0,v1004_11_head);
      Space v1006_7_result;
      for (int v1006_7_label = 1; v1006_7_label <= 2; ++v1006_7_label) {
        const Space v1006_7_tail = child(v1004_11_tail,v1006_7_label);
        if (v1006_7_tail.empty()) continue;
        const Path v1006_7_head{v1006_7_label};
        const Space v1007_2 = singleton(v1006_7_head);
        const Space v1007_3 = intersect(constant_8,v1007_2);
        const Space v1007_4 = (has_head(v1007_3) ? constant_9 : Space{});
        const Space v1007_5 = subtract(constant_0,v1007_4);
        Space v1007_8;
        if (!v1007_5.empty()) {
          const Path v1008_6 = concat_path(v1006_6,v1006_7_head);
          const Space v1008_7 = routine_187(c, v1008_6, v1006_7_tail);
          v1007_8 = compose(v1007_5,v1008_7);
        }
        const Space v1007_9 = intersect(constant_8,v1007_2);
        const Space v1007_10 = (has_head(v1007_9) ? constant_9 : Space{});
        Space v1007_12;
        if (!v1007_10.empty()) {
          const Path v1009_6 = concat_path(v1006_6,v1006_7_head);
          const Space v1009_11 = routine_188(c, v1009_6, v1006_7_tail);
          v1007_12 = compose(v1007_10,v1009_11);
        }
        const Space v1007_13 = unite(v1007_8,v1007_12);
        v1006_7_result = unite(v1006_7_result,v1007_13);
      }
      const Space v1006_7 = std::move(v1006_7_result);
      v1005_8 = compose(v1005_5,v1006_7);
    }
    const Space v1005_9 = intersect(constant_8,v1005_2);
    const Space v1005_10 = (has_head(v1005_9) ? constant_9 : Space{});
    Space v1005_12;
    if (!v1005_10.empty()) {
      const Path v1010_6 = concat_path(p0,v1004_11_head);
      Space v1010_11_result;
      for (int v1010_11_label = 1; v1010_11_label <= 2; ++v1010_11_label) {
        const Space v1010_11_tail = child(v1004_11_tail,v1010_11_label);
        if (v1010_11_tail.empty()) continue;
        const Path v1010_11_head{v1010_11_label};
        const Space v1011_2 = singleton(v1010_11_head);
        const Space v1011_3 = intersect(constant_8,v1011_2);
        const Space v1011_4 = (has_head(v1011_3) ? constant_9 : Space{});
        const Space v1011_5 = subtract(constant_0,v1011_4);
        Space v1011_8;
        if (!v1011_5.empty()) {
          const Path v1012_6 = concat_path(v1010_6,v1010_11_head);
          const Space v1012_7 = routine_187(c, v1012_6, v1010_11_tail);
          v1011_8 = compose(v1011_5,v1012_7);
        }
        const Space v1011_9 = intersect(constant_8,v1011_2);
        const Space v1011_10 = (has_head(v1011_9) ? constant_9 : Space{});
        Space v1011_12;
        if (!v1011_10.empty()) {
          const Path v1013_6 = concat_path(v1010_6,v1010_11_head);
          const Space v1013_11 = routine_68(c, v1013_6, v1010_11_tail);
          v1011_12 = compose(v1011_10,v1013_11);
        }
        const Space v1011_13 = unite(v1011_8,v1011_12);
        v1010_11_result = unite(v1010_11_result,v1011_13);
      }
      const Space v1010_11 = std::move(v1010_11_result);
      v1005_12 = compose(v1005_10,v1010_11);
    }
    const Space v1005_13 = unite(v1005_8,v1005_12);
    v1004_11_result = unite(v1004_11_result,v1005_13);
  }
  const Space v1004_11 = std::move(v1004_11_result);
  return v1004_11;
}

static Space routine_103(Context& c, const Path& p0, const Space& s0) {
  Space v1014_8_result;
  for (int v1014_8_label = 1; v1014_8_label <= 2; ++v1014_8_label) {
    const Space v1014_8_tail = child(s0,v1014_8_label);
    if (v1014_8_tail.empty()) continue;
    const Path v1014_8_head{v1014_8_label};
    const Space v1015_2 = singleton(v1014_8_head);
    const Space v1015_3 = intersect(constant_8,v1015_2);
    const Space v1015_4 = (has_head(v1015_3) ? constant_9 : Space{});
    const Space v1015_5 = subtract(constant_0,v1015_4);
    Space v1015_8;
    if (!v1015_5.empty()) {
      const Path v1016_6 = concat_path(p0,v1014_8_head);
      Space v1016_7_result;
      for (int v1016_7_label = 1; v1016_7_label <= 2; ++v1016_7_label) {
        const Space v1016_7_tail = child(v1014_8_tail,v1016_7_label);
        if (v1016_7_tail.empty()) continue;
        const Path v1016_7_head{v1016_7_label};
        const Space v1017_2 = singleton(v1016_7_head);
        const Space v1017_3 = intersect(constant_8,v1017_2);
        const Space v1017_4 = (has_head(v1017_3) ? constant_9 : Space{});
        const Space v1017_5 = subtract(constant_0,v1017_4);
        Space v1017_8;
        if (!v1017_5.empty()) {
          const Path v1018_6 = concat_path(v1016_6,v1016_7_head);
          const Space v1018_7 = routine_187(c, v1018_6, v1016_7_tail);
          v1017_8 = compose(v1017_5,v1018_7);
        }
        const Space v1017_9 = intersect(constant_8,v1017_2);
        const Space v1017_10 = (has_head(v1017_9) ? constant_9 : Space{});
        Space v1017_12;
        if (!v1017_10.empty()) {
          const Path v1019_6 = concat_path(v1016_6,v1016_7_head);
          const Space v1019_11 = routine_188(c, v1019_6, v1016_7_tail);
          v1017_12 = compose(v1017_10,v1019_11);
        }
        const Space v1017_13 = unite(v1017_8,v1017_12);
        v1016_7_result = unite(v1016_7_result,v1017_13);
      }
      const Space v1016_7 = std::move(v1016_7_result);
      v1015_8 = compose(v1015_5,v1016_7);
    }
    const Space v1015_9 = intersect(constant_8,v1015_2);
    const Space v1015_10 = (has_head(v1015_9) ? constant_9 : Space{});
    const Space v1015_11 = compose(v1015_10,v1014_8_tail);
    const Space v1015_12 = unite(v1015_8,v1015_11);
    v1014_8_result = unite(v1014_8_result,v1015_12);
  }
  const Space v1014_8 = std::move(v1014_8_result);
  return v1014_8;
}

static Space routine_104(Context& c, const Path& p0, const Space& s0) {
  Space v1020_11_result;
  for (int v1020_11_label = 1; v1020_11_label <= 2; ++v1020_11_label) {
    const Space v1020_11_tail = child(s0,v1020_11_label);
    if (v1020_11_tail.empty()) continue;
    const Path v1020_11_head{v1020_11_label};
    const Space v1021_2 = singleton(v1020_11_head);
    const Space v1021_3 = intersect(constant_8,v1021_2);
    const Space v1021_4 = (has_head(v1021_3) ? constant_9 : Space{});
    const Space v1021_5 = subtract(constant_0,v1021_4);
    Space v1021_8;
    if (!v1021_5.empty()) {
      const Path v1022_6 = concat_path(p0,v1020_11_head);
      Space v1022_7_result;
      for (int v1022_7_label = 1; v1022_7_label <= 2; ++v1022_7_label) {
        const Space v1022_7_tail = child(v1020_11_tail,v1022_7_label);
        if (v1022_7_tail.empty()) continue;
        const Path v1022_7_head{v1022_7_label};
        const Space v1023_2 = singleton(v1022_7_head);
        const Space v1023_3 = intersect(constant_8,v1023_2);
        const Space v1023_4 = (has_head(v1023_3) ? constant_9 : Space{});
        const Space v1023_5 = subtract(constant_0,v1023_4);
        Space v1023_8;
        if (!v1023_5.empty()) {
          const Path v1024_6 = concat_path(v1022_6,v1022_7_head);
          const Space v1024_7 = routine_189(c, v1024_6, v1022_7_tail);
          v1023_8 = compose(v1023_5,v1024_7);
        }
        const Space v1023_9 = intersect(constant_8,v1023_2);
        const Space v1023_10 = (has_head(v1023_9) ? constant_9 : Space{});
        Space v1023_12;
        if (!v1023_10.empty()) {
          const Path v1025_6 = concat_path(v1022_6,v1022_7_head);
          const Space v1025_11 = routine_190(c, v1025_6, v1022_7_tail);
          v1023_12 = compose(v1023_10,v1025_11);
        }
        const Space v1023_13 = unite(v1023_8,v1023_12);
        v1022_7_result = unite(v1022_7_result,v1023_13);
      }
      const Space v1022_7 = std::move(v1022_7_result);
      v1021_8 = compose(v1021_5,v1022_7);
    }
    const Space v1021_9 = intersect(constant_8,v1021_2);
    const Space v1021_10 = (has_head(v1021_9) ? constant_9 : Space{});
    Space v1021_12;
    if (!v1021_10.empty()) {
      const Path v1026_6 = concat_path(p0,v1020_11_head);
      Space v1026_11_result;
      for (int v1026_11_label = 1; v1026_11_label <= 2; ++v1026_11_label) {
        const Space v1026_11_tail = child(v1020_11_tail,v1026_11_label);
        if (v1026_11_tail.empty()) continue;
        const Path v1026_11_head{v1026_11_label};
        const Space v1027_2 = singleton(v1026_11_head);
        const Space v1027_3 = intersect(constant_8,v1027_2);
        const Space v1027_4 = (has_head(v1027_3) ? constant_9 : Space{});
        const Space v1027_5 = subtract(constant_0,v1027_4);
        Space v1027_8;
        if (!v1027_5.empty()) {
          const Path v1028_6 = concat_path(v1026_6,v1026_11_head);
          const Space v1028_7 = routine_189(c, v1028_6, v1026_11_tail);
          v1027_8 = compose(v1027_5,v1028_7);
        }
        const Space v1027_9 = intersect(constant_8,v1027_2);
        const Space v1027_10 = (has_head(v1027_9) ? constant_9 : Space{});
        Space v1027_12;
        if (!v1027_10.empty()) {
          const Path v1029_6 = concat_path(v1026_6,v1026_11_head);
          const Space v1029_11 = routine_71(c, v1029_6, v1026_11_tail);
          v1027_12 = compose(v1027_10,v1029_11);
        }
        const Space v1027_13 = unite(v1027_8,v1027_12);
        v1026_11_result = unite(v1026_11_result,v1027_13);
      }
      const Space v1026_11 = std::move(v1026_11_result);
      v1021_12 = compose(v1021_10,v1026_11);
    }
    const Space v1021_13 = unite(v1021_8,v1021_12);
    v1020_11_result = unite(v1020_11_result,v1021_13);
  }
  const Space v1020_11 = std::move(v1020_11_result);
  return v1020_11;
}

static Space routine_105(Context& c, const Path& p0, const Space& s0) {
  Space v1030_11_result;
  for (int v1030_11_label = 1; v1030_11_label <= 2; ++v1030_11_label) {
    const Space v1030_11_tail = child(s0,v1030_11_label);
    if (v1030_11_tail.empty()) continue;
    const Path v1030_11_head{v1030_11_label};
    const Space v1031_2 = singleton(v1030_11_head);
    const Space v1031_3 = intersect(constant_8,v1031_2);
    const Space v1031_4 = (has_head(v1031_3) ? constant_9 : Space{});
    const Space v1031_5 = subtract(constant_0,v1031_4);
    Space v1031_8;
    if (!v1031_5.empty()) {
      const Path v1032_6 = concat_path(p0,v1030_11_head);
      Space v1032_7_result;
      for (int v1032_7_label = 1; v1032_7_label <= 2; ++v1032_7_label) {
        const Space v1032_7_tail = child(v1030_11_tail,v1032_7_label);
        if (v1032_7_tail.empty()) continue;
        const Path v1032_7_head{v1032_7_label};
        const Space v1033_2 = singleton(v1032_7_head);
        const Space v1033_3 = intersect(constant_8,v1033_2);
        const Space v1033_4 = (has_head(v1033_3) ? constant_9 : Space{});
        const Space v1033_5 = subtract(constant_0,v1033_4);
        Space v1033_8;
        if (!v1033_5.empty()) {
          const Path v1034_6 = concat_path(v1032_6,v1032_7_head);
          const Space v1034_7 = routine_189(c, v1034_6, v1032_7_tail);
          v1033_8 = compose(v1033_5,v1034_7);
        }
        const Space v1033_9 = intersect(constant_8,v1033_2);
        const Space v1033_10 = (has_head(v1033_9) ? constant_9 : Space{});
        Space v1033_12;
        if (!v1033_10.empty()) {
          const Path v1035_6 = concat_path(v1032_6,v1032_7_head);
          const Space v1035_11 = routine_190(c, v1035_6, v1032_7_tail);
          v1033_12 = compose(v1033_10,v1035_11);
        }
        const Space v1033_13 = unite(v1033_8,v1033_12);
        v1032_7_result = unite(v1032_7_result,v1033_13);
      }
      const Space v1032_7 = std::move(v1032_7_result);
      v1031_8 = compose(v1031_5,v1032_7);
    }
    const Space v1031_9 = intersect(constant_8,v1031_2);
    const Space v1031_10 = (has_head(v1031_9) ? constant_9 : Space{});
    Space v1031_12;
    if (!v1031_10.empty()) {
      const Path v1036_6 = concat_path(p0,v1030_11_head);
      Space v1036_11_result;
      for (int v1036_11_label = 1; v1036_11_label <= 2; ++v1036_11_label) {
        const Space v1036_11_tail = child(v1030_11_tail,v1036_11_label);
        if (v1036_11_tail.empty()) continue;
        const Path v1036_11_head{v1036_11_label};
        const Space v1037_2 = singleton(v1036_11_head);
        const Space v1037_3 = intersect(constant_8,v1037_2);
        const Space v1037_4 = (has_head(v1037_3) ? constant_9 : Space{});
        const Space v1037_5 = subtract(constant_0,v1037_4);
        Space v1037_7;
        if (!v1037_5.empty()) {
          const Space v1038_6 = routine_106(c, v1036_11_head, v1036_6, v1036_11_tail);
          v1037_7 = compose(v1037_5,v1038_6);
        }
        const Space v1037_8 = intersect(constant_8,v1037_2);
        const Space v1037_9 = (has_head(v1037_8) ? constant_9 : Space{});
        Space v1037_11;
        if (!v1037_9.empty()) {
          const Space v1039_10 = routine_107(c, v1036_11_head, v1036_6, v1036_11_tail);
          v1037_11 = compose(v1037_9,v1039_10);
        }
        const Space v1037_12 = unite(v1037_7,v1037_11);
        v1036_11_result = unite(v1036_11_result,v1037_12);
      }
      const Space v1036_11 = std::move(v1036_11_result);
      v1031_12 = compose(v1031_10,v1036_11);
    }
    const Space v1031_13 = unite(v1031_8,v1031_12);
    v1030_11_result = unite(v1030_11_result,v1031_13);
  }
  const Space v1030_11 = std::move(v1030_11_result);
  return v1030_11;
}

static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1040_12_result;
  for (int v1040_12_label = 1; v1040_12_label <= 2; ++v1040_12_label) {
    const Space v1040_12_tail = child(s0,v1040_12_label);
    if (v1040_12_tail.empty()) continue;
    const Path v1040_12_head{v1040_12_label};
    const Space v1041_2 = singleton(v1040_12_head);
    const Space v1041_3 = intersect(constant_8,v1041_2);
    const Space v1041_4 = (has_head(v1041_3) ? constant_9 : Space{});
    const Space v1041_5 = subtract(constant_0,v1041_4);
    Space v1041_8;
    if (!v1041_5.empty()) {
      const Path v1042_6 = concat_path(p0,v1040_12_head);
      Space v1042_7_result;
      for (int v1042_7_label = 1; v1042_7_label <= 2; ++v1042_7_label) {
        const Space v1042_7_tail = child(v1040_12_tail,v1042_7_label);
        if (v1042_7_tail.empty()) continue;
        const Path v1042_7_head{v1042_7_label};
        const Space v1043_2 = singleton(v1042_7_head);
        const Space v1043_3 = intersect(constant_8,v1043_2);
        const Space v1043_4 = (has_head(v1043_3) ? constant_9 : Space{});
        const Space v1043_5 = subtract(constant_0,v1043_4);
        Space v1043_8;
        if (!v1043_5.empty()) {
          const Path v1044_6 = concat_path(v1042_6,v1042_7_head);
          const Space v1044_7 = routine_191(c, v1044_6, p1, v1042_7_tail);
          v1043_8 = compose(v1043_5,v1044_7);
        }
        const Space v1043_9 = intersect(constant_8,v1043_2);
        const Space v1043_10 = (has_head(v1043_9) ? constant_9 : Space{});
        Space v1043_12;
        if (!v1043_10.empty()) {
          const Path v1045_6 = concat_path(v1042_6,v1042_7_head);
          const Space v1045_11 = routine_192(c, v1045_6, p1, v1042_7_tail);
          v1043_12 = compose(v1043_10,v1045_11);
        }
        const Space v1043_13 = unite(v1043_8,v1043_12);
        v1042_7_result = unite(v1042_7_result,v1043_13);
      }
      const Space v1042_7 = std::move(v1042_7_result);
      v1041_8 = compose(v1041_5,v1042_7);
    }
    const Space v1041_9 = intersect(constant_8,v1041_2);
    const Space v1041_10 = (has_head(v1041_9) ? constant_9 : Space{});
    Space v1041_12;
    if (!v1041_10.empty()) {
      const Path v1046_6 = concat_path(p0,v1040_12_head);
      Space v1046_11_result;
      for (int v1046_11_label = 1; v1046_11_label <= 2; ++v1046_11_label) {
        const Space v1046_11_tail = child(v1040_12_tail,v1046_11_label);
        if (v1046_11_tail.empty()) continue;
        const Path v1046_11_head{v1046_11_label};
        const Space v1047_2 = singleton(v1046_11_head);
        const Space v1047_3 = intersect(constant_8,v1047_2);
        const Space v1047_4 = (has_head(v1047_3) ? constant_9 : Space{});
        const Space v1047_5 = subtract(constant_0,v1047_4);
        Space v1047_8;
        if (!v1047_5.empty()) {
          const Path v1048_6 = concat_path(v1046_6,v1046_11_head);
          const Space v1048_7 = routine_191(c, v1048_6, p1, v1046_11_tail);
          v1047_8 = compose(v1047_5,v1048_7);
        }
        const Space v1047_9 = intersect(constant_8,v1047_2);
        const Space v1047_10 = (has_head(v1047_9) ? constant_9 : Space{});
        Space v1047_12;
        if (!v1047_10.empty()) {
          const Path v1049_6 = concat_path(v1046_6,v1046_11_head);
          const Space v1049_11 = routine_148(c, v1049_6, p1, v1046_11_tail);
          v1047_12 = compose(v1047_10,v1049_11);
        }
        const Space v1047_13 = unite(v1047_8,v1047_12);
        v1046_11_result = unite(v1046_11_result,v1047_13);
      }
      const Space v1046_11 = std::move(v1046_11_result);
      v1041_12 = compose(v1041_10,v1046_11);
    }
    const Space v1041_13 = unite(v1041_8,v1041_12);
    v1040_12_result = unite(v1040_12_result,v1041_13);
  }
  const Space v1040_12 = std::move(v1040_12_result);
  return v1040_12;
}

static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1050_12_result;
  for (int v1050_12_label = 1; v1050_12_label <= 2; ++v1050_12_label) {
    const Space v1050_12_tail = child(s0,v1050_12_label);
    if (v1050_12_tail.empty()) continue;
    const Path v1050_12_head{v1050_12_label};
    const Space v1051_2 = singleton(v1050_12_head);
    const Space v1051_3 = intersect(constant_8,v1051_2);
    const Space v1051_4 = (has_head(v1051_3) ? constant_9 : Space{});
    const Space v1051_5 = subtract(constant_0,v1051_4);
    Space v1051_8;
    if (!v1051_5.empty()) {
      const Path v1052_6 = concat_path(p0,v1050_12_head);
      Space v1052_7_result;
      for (int v1052_7_label = 1; v1052_7_label <= 2; ++v1052_7_label) {
        const Space v1052_7_tail = child(v1050_12_tail,v1052_7_label);
        if (v1052_7_tail.empty()) continue;
        const Path v1052_7_head{v1052_7_label};
        const Space v1053_2 = singleton(v1052_7_head);
        const Space v1053_3 = intersect(constant_8,v1053_2);
        const Space v1053_4 = (has_head(v1053_3) ? constant_9 : Space{});
        const Space v1053_5 = subtract(constant_0,v1053_4);
        Space v1053_8;
        if (!v1053_5.empty()) {
          const Path v1054_6 = concat_path(v1052_6,v1052_7_head);
          const Space v1054_7 = routine_191(c, v1054_6, p1, v1052_7_tail);
          v1053_8 = compose(v1053_5,v1054_7);
        }
        const Space v1053_9 = intersect(constant_8,v1053_2);
        const Space v1053_10 = (has_head(v1053_9) ? constant_9 : Space{});
        Space v1053_12;
        if (!v1053_10.empty()) {
          const Path v1055_6 = concat_path(v1052_6,v1052_7_head);
          const Space v1055_11 = routine_192(c, v1055_6, p1, v1052_7_tail);
          v1053_12 = compose(v1053_10,v1055_11);
        }
        const Space v1053_13 = unite(v1053_8,v1053_12);
        v1052_7_result = unite(v1052_7_result,v1053_13);
      }
      const Space v1052_7 = std::move(v1052_7_result);
      v1051_8 = compose(v1051_5,v1052_7);
    }
    const Space v1051_9 = intersect(constant_8,v1051_2);
    const Space v1051_10 = (has_head(v1051_9) ? constant_9 : Space{});
    Space v1051_12;
    if (!v1051_10.empty()) {
      const Path v1056_6 = concat_path(p0,v1050_12_head);
      Space v1056_11_result;
      for (int v1056_11_label = 1; v1056_11_label <= 2; ++v1056_11_label) {
        const Space v1056_11_tail = child(v1050_12_tail,v1056_11_label);
        if (v1056_11_tail.empty()) continue;
        const Path v1056_11_head{v1056_11_label};
        const Space v1057_2 = singleton(v1056_11_head);
        const Space v1057_3 = intersect(constant_8,v1057_2);
        const Space v1057_4 = (has_head(v1057_3) ? constant_9 : Space{});
        const Space v1057_5 = subtract(constant_0,v1057_4);
        Space v1057_7;
        if (!v1057_5.empty()) {
          const Space v1058_6 = routine_193(c, v1056_11_head, p1, v1056_6, v1056_11_tail);
          v1057_7 = compose(v1057_5,v1058_6);
        }
        const Space v1057_8 = intersect(constant_8,v1057_2);
        const Space v1057_9 = (has_head(v1057_8) ? constant_9 : Space{});
        Space v1057_11;
        if (!v1057_9.empty()) {
          const Space v1059_10 = routine_194(c, v1056_11_head, p1, v1056_6, v1056_11_tail);
          v1057_11 = compose(v1057_9,v1059_10);
        }
        const Space v1057_12 = unite(v1057_7,v1057_11);
        v1056_11_result = unite(v1056_11_result,v1057_12);
      }
      const Space v1056_11 = std::move(v1056_11_result);
      v1051_12 = compose(v1051_10,v1056_11);
    }
    const Space v1051_13 = unite(v1051_8,v1051_12);
    v1050_12_result = unite(v1050_12_result,v1051_13);
  }
  const Space v1050_12 = std::move(v1050_12_result);
  return v1050_12;
}

static Space routine_108(Context& c, const Path& p0, const Space& s0) {
  Space v1060_11_result;
  for (int v1060_11_label = 1; v1060_11_label <= 2; ++v1060_11_label) {
    const Space v1060_11_tail = child(s0,v1060_11_label);
    if (v1060_11_tail.empty()) continue;
    const Path v1060_11_head{v1060_11_label};
    const Space v1061_2 = singleton(v1060_11_head);
    const Space v1061_3 = intersect(constant_8,v1061_2);
    const Space v1061_4 = (has_head(v1061_3) ? constant_9 : Space{});
    const Space v1061_5 = subtract(constant_0,v1061_4);
    Space v1061_8;
    if (!v1061_5.empty()) {
      const Path v1062_6 = concat_path(p0,v1060_11_head);
      Space v1062_7_result;
      for (int v1062_7_label = 1; v1062_7_label <= 2; ++v1062_7_label) {
        const Space v1062_7_tail = child(v1060_11_tail,v1062_7_label);
        if (v1062_7_tail.empty()) continue;
        const Path v1062_7_head{v1062_7_label};
        const Space v1063_2 = singleton(v1062_7_head);
        const Space v1063_3 = intersect(constant_8,v1063_2);
        const Space v1063_4 = (has_head(v1063_3) ? constant_9 : Space{});
        const Space v1063_5 = subtract(constant_0,v1063_4);
        Space v1063_8;
        if (!v1063_5.empty()) {
          const Path v1064_6 = concat_path(v1062_6,v1062_7_head);
          const Space v1064_7 = routine_195(c, v1064_6, v1062_7_tail);
          v1063_8 = compose(v1063_5,v1064_7);
        }
        const Space v1063_9 = intersect(constant_8,v1063_2);
        const Space v1063_10 = (has_head(v1063_9) ? constant_9 : Space{});
        Space v1063_12;
        if (!v1063_10.empty()) {
          const Path v1065_6 = concat_path(v1062_6,v1062_7_head);
          const Space v1065_11 = routine_196(c, v1065_6, v1062_7_tail);
          v1063_12 = compose(v1063_10,v1065_11);
        }
        const Space v1063_13 = unite(v1063_8,v1063_12);
        v1062_7_result = unite(v1062_7_result,v1063_13);
      }
      const Space v1062_7 = std::move(v1062_7_result);
      v1061_8 = compose(v1061_5,v1062_7);
    }
    const Space v1061_9 = intersect(constant_8,v1061_2);
    const Space v1061_10 = (has_head(v1061_9) ? constant_9 : Space{});
    Space v1061_12;
    if (!v1061_10.empty()) {
      const Path v1066_6 = concat_path(p0,v1060_11_head);
      Space v1066_11_result;
      for (int v1066_11_label = 1; v1066_11_label <= 2; ++v1066_11_label) {
        const Space v1066_11_tail = child(v1060_11_tail,v1066_11_label);
        if (v1066_11_tail.empty()) continue;
        const Path v1066_11_head{v1066_11_label};
        const Space v1067_2 = singleton(v1066_11_head);
        const Space v1067_3 = intersect(constant_8,v1067_2);
        const Space v1067_4 = (has_head(v1067_3) ? constant_9 : Space{});
        const Space v1067_5 = subtract(constant_0,v1067_4);
        Space v1067_8;
        if (!v1067_5.empty()) {
          const Path v1068_6 = concat_path(v1066_6,v1066_11_head);
          const Space v1068_7 = routine_195(c, v1068_6, v1066_11_tail);
          v1067_8 = compose(v1067_5,v1068_7);
        }
        const Space v1067_9 = intersect(constant_8,v1067_2);
        const Space v1067_10 = (has_head(v1067_9) ? constant_9 : Space{});
        Space v1067_12;
        if (!v1067_10.empty()) {
          const Path v1069_6 = concat_path(v1066_6,v1066_11_head);
          const Space v1069_11 = routine_74(c, v1069_6, v1066_11_tail);
          v1067_12 = compose(v1067_10,v1069_11);
        }
        const Space v1067_13 = unite(v1067_8,v1067_12);
        v1066_11_result = unite(v1066_11_result,v1067_13);
      }
      const Space v1066_11 = std::move(v1066_11_result);
      v1061_12 = compose(v1061_10,v1066_11);
    }
    const Space v1061_13 = unite(v1061_8,v1061_12);
    v1060_11_result = unite(v1060_11_result,v1061_13);
  }
  const Space v1060_11 = std::move(v1060_11_result);
  return v1060_11;
}

static Space routine_109(Context& c, const Path& p0, const Space& s0) {
  Space v1070_8_result;
  for (int v1070_8_label = 1; v1070_8_label <= 2; ++v1070_8_label) {
    const Space v1070_8_tail = child(s0,v1070_8_label);
    if (v1070_8_tail.empty()) continue;
    const Path v1070_8_head{v1070_8_label};
    const Space v1071_2 = singleton(v1070_8_head);
    const Space v1071_3 = intersect(constant_8,v1071_2);
    const Space v1071_4 = (has_head(v1071_3) ? constant_9 : Space{});
    const Space v1071_5 = subtract(constant_0,v1071_4);
    Space v1071_8;
    if (!v1071_5.empty()) {
      const Path v1072_6 = concat_path(p0,v1070_8_head);
      Space v1072_7_result;
      for (int v1072_7_label = 1; v1072_7_label <= 2; ++v1072_7_label) {
        const Space v1072_7_tail = child(v1070_8_tail,v1072_7_label);
        if (v1072_7_tail.empty()) continue;
        const Path v1072_7_head{v1072_7_label};
        const Space v1073_2 = singleton(v1072_7_head);
        const Space v1073_3 = intersect(constant_8,v1073_2);
        const Space v1073_4 = (has_head(v1073_3) ? constant_9 : Space{});
        const Space v1073_5 = subtract(constant_0,v1073_4);
        Space v1073_8;
        if (!v1073_5.empty()) {
          const Path v1074_6 = concat_path(v1072_6,v1072_7_head);
          const Space v1074_7 = routine_195(c, v1074_6, v1072_7_tail);
          v1073_8 = compose(v1073_5,v1074_7);
        }
        const Space v1073_9 = intersect(constant_8,v1073_2);
        const Space v1073_10 = (has_head(v1073_9) ? constant_9 : Space{});
        Space v1073_12;
        if (!v1073_10.empty()) {
          const Path v1075_6 = concat_path(v1072_6,v1072_7_head);
          const Space v1075_11 = routine_196(c, v1075_6, v1072_7_tail);
          v1073_12 = compose(v1073_10,v1075_11);
        }
        const Space v1073_13 = unite(v1073_8,v1073_12);
        v1072_7_result = unite(v1072_7_result,v1073_13);
      }
      const Space v1072_7 = std::move(v1072_7_result);
      v1071_8 = compose(v1071_5,v1072_7);
    }
    const Space v1071_9 = intersect(constant_8,v1071_2);
    const Space v1071_10 = (has_head(v1071_9) ? constant_9 : Space{});
    const Space v1071_11 = compose(v1071_10,v1070_8_tail);
    const Space v1071_12 = unite(v1071_8,v1071_11);
    v1070_8_result = unite(v1070_8_result,v1071_12);
  }
  const Space v1070_8 = std::move(v1070_8_result);
  return v1070_8;
}

static Space routine_110(Context& c, const Path& p0, const Space& s0) {
  Space v1076_11_result;
  for (int v1076_11_label = 1; v1076_11_label <= 2; ++v1076_11_label) {
    const Space v1076_11_tail = child(s0,v1076_11_label);
    if (v1076_11_tail.empty()) continue;
    const Path v1076_11_head{v1076_11_label};
    const Space v1077_2 = singleton(v1076_11_head);
    const Space v1077_3 = intersect(constant_8,v1077_2);
    const Space v1077_4 = (has_head(v1077_3) ? constant_9 : Space{});
    const Space v1077_5 = subtract(constant_0,v1077_4);
    Space v1077_8;
    if (!v1077_5.empty()) {
      const Path v1078_6 = concat_path(p0,v1076_11_head);
      Space v1078_7_result;
      for (int v1078_7_label = 1; v1078_7_label <= 2; ++v1078_7_label) {
        const Space v1078_7_tail = child(v1076_11_tail,v1078_7_label);
        if (v1078_7_tail.empty()) continue;
        const Path v1078_7_head{v1078_7_label};
        const Space v1079_2 = singleton(v1078_7_head);
        const Space v1079_3 = intersect(constant_8,v1079_2);
        const Space v1079_4 = (has_head(v1079_3) ? constant_9 : Space{});
        const Space v1079_5 = subtract(constant_0,v1079_4);
        Space v1079_8;
        if (!v1079_5.empty()) {
          const Path v1080_6 = concat_path(v1078_6,v1078_7_head);
          const Space v1080_7 = routine_197(c, v1080_6, v1078_7_tail);
          v1079_8 = compose(v1079_5,v1080_7);
        }
        const Space v1079_9 = intersect(constant_8,v1079_2);
        const Space v1079_10 = (has_head(v1079_9) ? constant_9 : Space{});
        Space v1079_12;
        if (!v1079_10.empty()) {
          const Path v1081_6 = concat_path(v1078_6,v1078_7_head);
          const Space v1081_11 = routine_198(c, v1081_6, v1078_7_tail);
          v1079_12 = compose(v1079_10,v1081_11);
        }
        const Space v1079_13 = unite(v1079_8,v1079_12);
        v1078_7_result = unite(v1078_7_result,v1079_13);
      }
      const Space v1078_7 = std::move(v1078_7_result);
      v1077_8 = compose(v1077_5,v1078_7);
    }
    const Space v1077_9 = intersect(constant_8,v1077_2);
    const Space v1077_10 = (has_head(v1077_9) ? constant_9 : Space{});
    Space v1077_12;
    if (!v1077_10.empty()) {
      const Path v1082_6 = concat_path(p0,v1076_11_head);
      Space v1082_11_result;
      for (int v1082_11_label = 1; v1082_11_label <= 2; ++v1082_11_label) {
        const Space v1082_11_tail = child(v1076_11_tail,v1082_11_label);
        if (v1082_11_tail.empty()) continue;
        const Path v1082_11_head{v1082_11_label};
        const Space v1083_2 = singleton(v1082_11_head);
        const Space v1083_3 = intersect(constant_8,v1083_2);
        const Space v1083_4 = (has_head(v1083_3) ? constant_9 : Space{});
        const Space v1083_5 = subtract(constant_0,v1083_4);
        Space v1083_8;
        if (!v1083_5.empty()) {
          const Path v1084_6 = concat_path(v1082_6,v1082_11_head);
          const Space v1084_7 = routine_197(c, v1084_6, v1082_11_tail);
          v1083_8 = compose(v1083_5,v1084_7);
        }
        const Space v1083_9 = intersect(constant_8,v1083_2);
        const Space v1083_10 = (has_head(v1083_9) ? constant_9 : Space{});
        Space v1083_12;
        if (!v1083_10.empty()) {
          const Path v1085_6 = concat_path(v1082_6,v1082_11_head);
          const Space v1085_11 = routine_77(c, v1085_6, v1082_11_tail);
          v1083_12 = compose(v1083_10,v1085_11);
        }
        const Space v1083_13 = unite(v1083_8,v1083_12);
        v1082_11_result = unite(v1082_11_result,v1083_13);
      }
      const Space v1082_11 = std::move(v1082_11_result);
      v1077_12 = compose(v1077_10,v1082_11);
    }
    const Space v1077_13 = unite(v1077_8,v1077_12);
    v1076_11_result = unite(v1076_11_result,v1077_13);
  }
  const Space v1076_11 = std::move(v1076_11_result);
  return v1076_11;
}

static Space routine_111(Context& c, const Path& p0, const Space& s0) {
  Space v1086_11_result;
  for (int v1086_11_label = 1; v1086_11_label <= 2; ++v1086_11_label) {
    const Space v1086_11_tail = child(s0,v1086_11_label);
    if (v1086_11_tail.empty()) continue;
    const Path v1086_11_head{v1086_11_label};
    const Space v1087_2 = singleton(v1086_11_head);
    const Space v1087_3 = intersect(constant_8,v1087_2);
    const Space v1087_4 = (has_head(v1087_3) ? constant_9 : Space{});
    const Space v1087_5 = subtract(constant_0,v1087_4);
    Space v1087_8;
    if (!v1087_5.empty()) {
      const Path v1088_6 = concat_path(p0,v1086_11_head);
      Space v1088_7_result;
      for (int v1088_7_label = 1; v1088_7_label <= 2; ++v1088_7_label) {
        const Space v1088_7_tail = child(v1086_11_tail,v1088_7_label);
        if (v1088_7_tail.empty()) continue;
        const Path v1088_7_head{v1088_7_label};
        const Space v1089_2 = singleton(v1088_7_head);
        const Space v1089_3 = intersect(constant_8,v1089_2);
        const Space v1089_4 = (has_head(v1089_3) ? constant_9 : Space{});
        const Space v1089_5 = subtract(constant_0,v1089_4);
        Space v1089_8;
        if (!v1089_5.empty()) {
          const Path v1090_6 = concat_path(v1088_6,v1088_7_head);
          const Space v1090_7 = routine_197(c, v1090_6, v1088_7_tail);
          v1089_8 = compose(v1089_5,v1090_7);
        }
        const Space v1089_9 = intersect(constant_8,v1089_2);
        const Space v1089_10 = (has_head(v1089_9) ? constant_9 : Space{});
        Space v1089_12;
        if (!v1089_10.empty()) {
          const Path v1091_6 = concat_path(v1088_6,v1088_7_head);
          const Space v1091_11 = routine_198(c, v1091_6, v1088_7_tail);
          v1089_12 = compose(v1089_10,v1091_11);
        }
        const Space v1089_13 = unite(v1089_8,v1089_12);
        v1088_7_result = unite(v1088_7_result,v1089_13);
      }
      const Space v1088_7 = std::move(v1088_7_result);
      v1087_8 = compose(v1087_5,v1088_7);
    }
    const Space v1087_9 = intersect(constant_8,v1087_2);
    const Space v1087_10 = (has_head(v1087_9) ? constant_9 : Space{});
    Space v1087_12;
    if (!v1087_10.empty()) {
      const Path v1092_6 = concat_path(p0,v1086_11_head);
      Space v1092_11_result;
      for (int v1092_11_label = 1; v1092_11_label <= 2; ++v1092_11_label) {
        const Space v1092_11_tail = child(v1086_11_tail,v1092_11_label);
        if (v1092_11_tail.empty()) continue;
        const Path v1092_11_head{v1092_11_label};
        const Space v1093_2 = singleton(v1092_11_head);
        const Space v1093_3 = intersect(constant_8,v1093_2);
        const Space v1093_4 = (has_head(v1093_3) ? constant_9 : Space{});
        const Space v1093_5 = subtract(constant_0,v1093_4);
        Space v1093_7;
        if (!v1093_5.empty()) {
          const Space v1094_6 = routine_112(c, v1092_11_head, v1092_6, v1092_11_tail);
          v1093_7 = compose(v1093_5,v1094_6);
        }
        const Space v1093_8 = intersect(constant_8,v1093_2);
        const Space v1093_9 = (has_head(v1093_8) ? constant_9 : Space{});
        Space v1093_11;
        if (!v1093_9.empty()) {
          const Space v1095_10 = routine_113(c, v1092_11_head, v1092_6, v1092_11_tail);
          v1093_11 = compose(v1093_9,v1095_10);
        }
        const Space v1093_12 = unite(v1093_7,v1093_11);
        v1092_11_result = unite(v1092_11_result,v1093_12);
      }
      const Space v1092_11 = std::move(v1092_11_result);
      v1087_12 = compose(v1087_10,v1092_11);
    }
    const Space v1087_13 = unite(v1087_8,v1087_12);
    v1086_11_result = unite(v1086_11_result,v1087_13);
  }
  const Space v1086_11 = std::move(v1086_11_result);
  return v1086_11;
}

static Space routine_112(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1096_12_result;
  for (int v1096_12_label = 1; v1096_12_label <= 2; ++v1096_12_label) {
    const Space v1096_12_tail = child(s0,v1096_12_label);
    if (v1096_12_tail.empty()) continue;
    const Path v1096_12_head{v1096_12_label};
    const Space v1097_2 = singleton(v1096_12_head);
    const Space v1097_3 = intersect(constant_8,v1097_2);
    const Space v1097_4 = (has_head(v1097_3) ? constant_9 : Space{});
    const Space v1097_5 = subtract(constant_0,v1097_4);
    Space v1097_8;
    if (!v1097_5.empty()) {
      const Path v1098_6 = concat_path(p0,v1096_12_head);
      Space v1098_7_result;
      for (int v1098_7_label = 1; v1098_7_label <= 2; ++v1098_7_label) {
        const Space v1098_7_tail = child(v1096_12_tail,v1098_7_label);
        if (v1098_7_tail.empty()) continue;
        const Path v1098_7_head{v1098_7_label};
        const Space v1099_2 = singleton(v1098_7_head);
        const Space v1099_3 = intersect(constant_8,v1099_2);
        const Space v1099_4 = (has_head(v1099_3) ? constant_9 : Space{});
        const Space v1099_5 = subtract(constant_0,v1099_4);
        Space v1099_8;
        if (!v1099_5.empty()) {
          const Path v1100_6 = concat_path(v1098_6,v1098_7_head);
          const Space v1100_7 = routine_199(c, v1100_6, p1, v1098_7_tail);
          v1099_8 = compose(v1099_5,v1100_7);
        }
        const Space v1099_9 = intersect(constant_8,v1099_2);
        const Space v1099_10 = (has_head(v1099_9) ? constant_9 : Space{});
        Space v1099_12;
        if (!v1099_10.empty()) {
          const Path v1101_6 = concat_path(v1098_6,v1098_7_head);
          const Space v1101_11 = routine_200(c, v1101_6, p1, v1098_7_tail);
          v1099_12 = compose(v1099_10,v1101_11);
        }
        const Space v1099_13 = unite(v1099_8,v1099_12);
        v1098_7_result = unite(v1098_7_result,v1099_13);
      }
      const Space v1098_7 = std::move(v1098_7_result);
      v1097_8 = compose(v1097_5,v1098_7);
    }
    const Space v1097_9 = intersect(constant_8,v1097_2);
    const Space v1097_10 = (has_head(v1097_9) ? constant_9 : Space{});
    Space v1097_12;
    if (!v1097_10.empty()) {
      const Path v1102_6 = concat_path(p0,v1096_12_head);
      Space v1102_11_result;
      for (int v1102_11_label = 1; v1102_11_label <= 2; ++v1102_11_label) {
        const Space v1102_11_tail = child(v1096_12_tail,v1102_11_label);
        if (v1102_11_tail.empty()) continue;
        const Path v1102_11_head{v1102_11_label};
        const Space v1103_2 = singleton(v1102_11_head);
        const Space v1103_3 = intersect(constant_8,v1103_2);
        const Space v1103_4 = (has_head(v1103_3) ? constant_9 : Space{});
        const Space v1103_5 = subtract(constant_0,v1103_4);
        Space v1103_8;
        if (!v1103_5.empty()) {
          const Path v1104_6 = concat_path(v1102_6,v1102_11_head);
          const Space v1104_7 = routine_199(c, v1104_6, p1, v1102_11_tail);
          v1103_8 = compose(v1103_5,v1104_7);
        }
        const Space v1103_9 = intersect(constant_8,v1103_2);
        const Space v1103_10 = (has_head(v1103_9) ? constant_9 : Space{});
        Space v1103_12;
        if (!v1103_10.empty()) {
          const Path v1105_6 = concat_path(v1102_6,v1102_11_head);
          const Space v1105_11 = routine_155(c, v1105_6, p1, v1102_11_tail);
          v1103_12 = compose(v1103_10,v1105_11);
        }
        const Space v1103_13 = unite(v1103_8,v1103_12);
        v1102_11_result = unite(v1102_11_result,v1103_13);
      }
      const Space v1102_11 = std::move(v1102_11_result);
      v1097_12 = compose(v1097_10,v1102_11);
    }
    const Space v1097_13 = unite(v1097_8,v1097_12);
    v1096_12_result = unite(v1096_12_result,v1097_13);
  }
  const Space v1096_12 = std::move(v1096_12_result);
  return v1096_12;
}

static Space routine_113(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1106_12_result;
  for (int v1106_12_label = 1; v1106_12_label <= 2; ++v1106_12_label) {
    const Space v1106_12_tail = child(s0,v1106_12_label);
    if (v1106_12_tail.empty()) continue;
    const Path v1106_12_head{v1106_12_label};
    const Space v1107_2 = singleton(v1106_12_head);
    const Space v1107_3 = intersect(constant_8,v1107_2);
    const Space v1107_4 = (has_head(v1107_3) ? constant_9 : Space{});
    const Space v1107_5 = subtract(constant_0,v1107_4);
    Space v1107_8;
    if (!v1107_5.empty()) {
      const Path v1108_6 = concat_path(p0,v1106_12_head);
      Space v1108_7_result;
      for (int v1108_7_label = 1; v1108_7_label <= 2; ++v1108_7_label) {
        const Space v1108_7_tail = child(v1106_12_tail,v1108_7_label);
        if (v1108_7_tail.empty()) continue;
        const Path v1108_7_head{v1108_7_label};
        const Space v1109_2 = singleton(v1108_7_head);
        const Space v1109_3 = intersect(constant_8,v1109_2);
        const Space v1109_4 = (has_head(v1109_3) ? constant_9 : Space{});
        const Space v1109_5 = subtract(constant_0,v1109_4);
        Space v1109_8;
        if (!v1109_5.empty()) {
          const Path v1110_6 = concat_path(v1108_6,v1108_7_head);
          const Space v1110_7 = routine_199(c, v1110_6, p1, v1108_7_tail);
          v1109_8 = compose(v1109_5,v1110_7);
        }
        const Space v1109_9 = intersect(constant_8,v1109_2);
        const Space v1109_10 = (has_head(v1109_9) ? constant_9 : Space{});
        Space v1109_12;
        if (!v1109_10.empty()) {
          const Path v1111_6 = concat_path(v1108_6,v1108_7_head);
          const Space v1111_11 = routine_200(c, v1111_6, p1, v1108_7_tail);
          v1109_12 = compose(v1109_10,v1111_11);
        }
        const Space v1109_13 = unite(v1109_8,v1109_12);
        v1108_7_result = unite(v1108_7_result,v1109_13);
      }
      const Space v1108_7 = std::move(v1108_7_result);
      v1107_8 = compose(v1107_5,v1108_7);
    }
    const Space v1107_9 = intersect(constant_8,v1107_2);
    const Space v1107_10 = (has_head(v1107_9) ? constant_9 : Space{});
    Space v1107_12;
    if (!v1107_10.empty()) {
      const Path v1112_6 = concat_path(p0,v1106_12_head);
      Space v1112_11_result;
      for (int v1112_11_label = 1; v1112_11_label <= 2; ++v1112_11_label) {
        const Space v1112_11_tail = child(v1106_12_tail,v1112_11_label);
        if (v1112_11_tail.empty()) continue;
        const Path v1112_11_head{v1112_11_label};
        const Space v1113_2 = singleton(v1112_11_head);
        const Space v1113_3 = intersect(constant_8,v1113_2);
        const Space v1113_4 = (has_head(v1113_3) ? constant_9 : Space{});
        const Space v1113_5 = subtract(constant_0,v1113_4);
        Space v1113_7;
        if (!v1113_5.empty()) {
          const Space v1114_6 = routine_201(c, v1112_11_head, p1, v1112_6, v1112_11_tail);
          v1113_7 = compose(v1113_5,v1114_6);
        }
        const Space v1113_8 = intersect(constant_8,v1113_2);
        const Space v1113_9 = (has_head(v1113_8) ? constant_9 : Space{});
        Space v1113_11;
        if (!v1113_9.empty()) {
          const Space v1115_10 = routine_202(c, v1112_11_head, p1, v1112_6, v1112_11_tail);
          v1113_11 = compose(v1113_9,v1115_10);
        }
        const Space v1113_12 = unite(v1113_7,v1113_11);
        v1112_11_result = unite(v1112_11_result,v1113_12);
      }
      const Space v1112_11 = std::move(v1112_11_result);
      v1107_12 = compose(v1107_10,v1112_11);
    }
    const Space v1107_13 = unite(v1107_8,v1107_12);
    v1106_12_result = unite(v1106_12_result,v1107_13);
  }
  const Space v1106_12 = std::move(v1106_12_result);
  return v1106_12;
}

static Space routine_114(Context& c, const Path& p0, const Space& s0) {
  Space v1116_11_result;
  for (int v1116_11_label = 1; v1116_11_label <= 2; ++v1116_11_label) {
    const Space v1116_11_tail = child(s0,v1116_11_label);
    if (v1116_11_tail.empty()) continue;
    const Path v1116_11_head{v1116_11_label};
    const Space v1117_2 = singleton(v1116_11_head);
    const Space v1117_3 = intersect(constant_8,v1117_2);
    const Space v1117_4 = (has_head(v1117_3) ? constant_9 : Space{});
    const Space v1117_5 = subtract(constant_0,v1117_4);
    Space v1117_8;
    if (!v1117_5.empty()) {
      const Path v1118_6 = concat_path(p0,v1116_11_head);
      Space v1118_7_result;
      for (int v1118_7_label = 1; v1118_7_label <= 2; ++v1118_7_label) {
        const Space v1118_7_tail = child(v1116_11_tail,v1118_7_label);
        if (v1118_7_tail.empty()) continue;
        const Path v1118_7_head{v1118_7_label};
        const Space v1119_2 = singleton(v1118_7_head);
        const Space v1119_3 = intersect(constant_8,v1119_2);
        const Space v1119_4 = (has_head(v1119_3) ? constant_9 : Space{});
        const Space v1119_5 = subtract(constant_0,v1119_4);
        Space v1119_8;
        if (!v1119_5.empty()) {
          const Path v1120_6 = concat_path(v1118_6,v1118_7_head);
          const Space v1120_7 = routine_203(c, v1120_6, v1118_7_tail);
          v1119_8 = compose(v1119_5,v1120_7);
        }
        const Space v1119_9 = intersect(constant_8,v1119_2);
        const Space v1119_10 = (has_head(v1119_9) ? constant_9 : Space{});
        Space v1119_12;
        if (!v1119_10.empty()) {
          const Path v1121_6 = concat_path(v1118_6,v1118_7_head);
          const Space v1121_11 = routine_204(c, v1121_6, v1118_7_tail);
          v1119_12 = compose(v1119_10,v1121_11);
        }
        const Space v1119_13 = unite(v1119_8,v1119_12);
        v1118_7_result = unite(v1118_7_result,v1119_13);
      }
      const Space v1118_7 = std::move(v1118_7_result);
      v1117_8 = compose(v1117_5,v1118_7);
    }
    const Space v1117_9 = intersect(constant_8,v1117_2);
    const Space v1117_10 = (has_head(v1117_9) ? constant_9 : Space{});
    Space v1117_12;
    if (!v1117_10.empty()) {
      const Path v1122_6 = concat_path(p0,v1116_11_head);
      Space v1122_11_result;
      for (int v1122_11_label = 1; v1122_11_label <= 2; ++v1122_11_label) {
        const Space v1122_11_tail = child(v1116_11_tail,v1122_11_label);
        if (v1122_11_tail.empty()) continue;
        const Path v1122_11_head{v1122_11_label};
        const Space v1123_2 = singleton(v1122_11_head);
        const Space v1123_3 = intersect(constant_8,v1123_2);
        const Space v1123_4 = (has_head(v1123_3) ? constant_9 : Space{});
        const Space v1123_5 = subtract(constant_0,v1123_4);
        Space v1123_8;
        if (!v1123_5.empty()) {
          const Path v1124_6 = concat_path(v1122_6,v1122_11_head);
          const Space v1124_7 = routine_203(c, v1124_6, v1122_11_tail);
          v1123_8 = compose(v1123_5,v1124_7);
        }
        const Space v1123_9 = intersect(constant_8,v1123_2);
        const Space v1123_10 = (has_head(v1123_9) ? constant_9 : Space{});
        Space v1123_12;
        if (!v1123_10.empty()) {
          const Path v1125_6 = concat_path(v1122_6,v1122_11_head);
          const Space v1125_11 = routine_80(c, v1125_6, v1122_11_tail);
          v1123_12 = compose(v1123_10,v1125_11);
        }
        const Space v1123_13 = unite(v1123_8,v1123_12);
        v1122_11_result = unite(v1122_11_result,v1123_13);
      }
      const Space v1122_11 = std::move(v1122_11_result);
      v1117_12 = compose(v1117_10,v1122_11);
    }
    const Space v1117_13 = unite(v1117_8,v1117_12);
    v1116_11_result = unite(v1116_11_result,v1117_13);
  }
  const Space v1116_11 = std::move(v1116_11_result);
  return v1116_11;
}

static Space routine_115(Context& c, const Path& p0, const Space& s0) {
  Space v1126_8_result;
  for (int v1126_8_label = 1; v1126_8_label <= 2; ++v1126_8_label) {
    const Space v1126_8_tail = child(s0,v1126_8_label);
    if (v1126_8_tail.empty()) continue;
    const Path v1126_8_head{v1126_8_label};
    const Space v1127_2 = singleton(v1126_8_head);
    const Space v1127_3 = intersect(constant_8,v1127_2);
    const Space v1127_4 = (has_head(v1127_3) ? constant_9 : Space{});
    const Space v1127_5 = subtract(constant_0,v1127_4);
    Space v1127_8;
    if (!v1127_5.empty()) {
      const Path v1128_6 = concat_path(p0,v1126_8_head);
      Space v1128_7_result;
      for (int v1128_7_label = 1; v1128_7_label <= 2; ++v1128_7_label) {
        const Space v1128_7_tail = child(v1126_8_tail,v1128_7_label);
        if (v1128_7_tail.empty()) continue;
        const Path v1128_7_head{v1128_7_label};
        const Space v1129_2 = singleton(v1128_7_head);
        const Space v1129_3 = intersect(constant_8,v1129_2);
        const Space v1129_4 = (has_head(v1129_3) ? constant_9 : Space{});
        const Space v1129_5 = subtract(constant_0,v1129_4);
        Space v1129_8;
        if (!v1129_5.empty()) {
          const Path v1130_6 = concat_path(v1128_6,v1128_7_head);
          const Space v1130_7 = routine_203(c, v1130_6, v1128_7_tail);
          v1129_8 = compose(v1129_5,v1130_7);
        }
        const Space v1129_9 = intersect(constant_8,v1129_2);
        const Space v1129_10 = (has_head(v1129_9) ? constant_9 : Space{});
        Space v1129_12;
        if (!v1129_10.empty()) {
          const Path v1131_6 = concat_path(v1128_6,v1128_7_head);
          const Space v1131_11 = routine_204(c, v1131_6, v1128_7_tail);
          v1129_12 = compose(v1129_10,v1131_11);
        }
        const Space v1129_13 = unite(v1129_8,v1129_12);
        v1128_7_result = unite(v1128_7_result,v1129_13);
      }
      const Space v1128_7 = std::move(v1128_7_result);
      v1127_8 = compose(v1127_5,v1128_7);
    }
    const Space v1127_9 = intersect(constant_8,v1127_2);
    const Space v1127_10 = (has_head(v1127_9) ? constant_9 : Space{});
    const Space v1127_11 = compose(v1127_10,v1126_8_tail);
    const Space v1127_12 = unite(v1127_8,v1127_11);
    v1126_8_result = unite(v1126_8_result,v1127_12);
  }
  const Space v1126_8 = std::move(v1126_8_result);
  return v1126_8;
}

static Space routine_116(Context& c, const Path& p0, const Space& s0) {
  Space v1132_11_result;
  for (int v1132_11_label = 1; v1132_11_label <= 2; ++v1132_11_label) {
    const Space v1132_11_tail = child(s0,v1132_11_label);
    if (v1132_11_tail.empty()) continue;
    const Path v1132_11_head{v1132_11_label};
    const Space v1133_2 = singleton(v1132_11_head);
    const Space v1133_3 = intersect(constant_8,v1133_2);
    const Space v1133_4 = (has_head(v1133_3) ? constant_9 : Space{});
    const Space v1133_5 = subtract(constant_0,v1133_4);
    Space v1133_8;
    if (!v1133_5.empty()) {
      const Path v1134_6 = concat_path(p0,v1132_11_head);
      Space v1134_7_result;
      for (int v1134_7_label = 1; v1134_7_label <= 2; ++v1134_7_label) {
        const Space v1134_7_tail = child(v1132_11_tail,v1134_7_label);
        if (v1134_7_tail.empty()) continue;
        const Path v1134_7_head{v1134_7_label};
        const Space v1135_2 = singleton(v1134_7_head);
        const Space v1135_3 = intersect(constant_8,v1135_2);
        const Space v1135_4 = (has_head(v1135_3) ? constant_9 : Space{});
        const Space v1135_5 = subtract(constant_0,v1135_4);
        Space v1135_8;
        if (!v1135_5.empty()) {
          const Path v1136_6 = concat_path(v1134_6,v1134_7_head);
          const Space v1136_7 = routine_205(c, v1136_6, v1134_7_tail);
          v1135_8 = compose(v1135_5,v1136_7);
        }
        const Space v1135_9 = intersect(constant_8,v1135_2);
        const Space v1135_10 = (has_head(v1135_9) ? constant_9 : Space{});
        Space v1135_12;
        if (!v1135_10.empty()) {
          const Path v1137_6 = concat_path(v1134_6,v1134_7_head);
          const Space v1137_11 = routine_206(c, v1137_6, v1134_7_tail);
          v1135_12 = compose(v1135_10,v1137_11);
        }
        const Space v1135_13 = unite(v1135_8,v1135_12);
        v1134_7_result = unite(v1134_7_result,v1135_13);
      }
      const Space v1134_7 = std::move(v1134_7_result);
      v1133_8 = compose(v1133_5,v1134_7);
    }
    const Space v1133_9 = intersect(constant_8,v1133_2);
    const Space v1133_10 = (has_head(v1133_9) ? constant_9 : Space{});
    Space v1133_12;
    if (!v1133_10.empty()) {
      const Path v1138_6 = concat_path(p0,v1132_11_head);
      Space v1138_11_result;
      for (int v1138_11_label = 1; v1138_11_label <= 2; ++v1138_11_label) {
        const Space v1138_11_tail = child(v1132_11_tail,v1138_11_label);
        if (v1138_11_tail.empty()) continue;
        const Path v1138_11_head{v1138_11_label};
        const Space v1139_2 = singleton(v1138_11_head);
        const Space v1139_3 = intersect(constant_8,v1139_2);
        const Space v1139_4 = (has_head(v1139_3) ? constant_9 : Space{});
        const Space v1139_5 = subtract(constant_0,v1139_4);
        Space v1139_8;
        if (!v1139_5.empty()) {
          const Path v1140_6 = concat_path(v1138_6,v1138_11_head);
          const Space v1140_7 = routine_205(c, v1140_6, v1138_11_tail);
          v1139_8 = compose(v1139_5,v1140_7);
        }
        const Space v1139_9 = intersect(constant_8,v1139_2);
        const Space v1139_10 = (has_head(v1139_9) ? constant_9 : Space{});
        Space v1139_12;
        if (!v1139_10.empty()) {
          const Path v1141_6 = concat_path(v1138_6,v1138_11_head);
          const Space v1141_11 = routine_83(c, v1141_6, v1138_11_tail);
          v1139_12 = compose(v1139_10,v1141_11);
        }
        const Space v1139_13 = unite(v1139_8,v1139_12);
        v1138_11_result = unite(v1138_11_result,v1139_13);
      }
      const Space v1138_11 = std::move(v1138_11_result);
      v1133_12 = compose(v1133_10,v1138_11);
    }
    const Space v1133_13 = unite(v1133_8,v1133_12);
    v1132_11_result = unite(v1132_11_result,v1133_13);
  }
  const Space v1132_11 = std::move(v1132_11_result);
  return v1132_11;
}

static Space routine_117(Context& c, const Path& p0, const Space& s0) {
  Space v1142_11_result;
  for (int v1142_11_label = 1; v1142_11_label <= 2; ++v1142_11_label) {
    const Space v1142_11_tail = child(s0,v1142_11_label);
    if (v1142_11_tail.empty()) continue;
    const Path v1142_11_head{v1142_11_label};
    const Space v1143_2 = singleton(v1142_11_head);
    const Space v1143_3 = intersect(constant_8,v1143_2);
    const Space v1143_4 = (has_head(v1143_3) ? constant_9 : Space{});
    const Space v1143_5 = subtract(constant_0,v1143_4);
    Space v1143_8;
    if (!v1143_5.empty()) {
      const Path v1144_6 = concat_path(p0,v1142_11_head);
      Space v1144_7_result;
      for (int v1144_7_label = 1; v1144_7_label <= 2; ++v1144_7_label) {
        const Space v1144_7_tail = child(v1142_11_tail,v1144_7_label);
        if (v1144_7_tail.empty()) continue;
        const Path v1144_7_head{v1144_7_label};
        const Space v1145_2 = singleton(v1144_7_head);
        const Space v1145_3 = intersect(constant_8,v1145_2);
        const Space v1145_4 = (has_head(v1145_3) ? constant_9 : Space{});
        const Space v1145_5 = subtract(constant_0,v1145_4);
        Space v1145_8;
        if (!v1145_5.empty()) {
          const Path v1146_6 = concat_path(v1144_6,v1144_7_head);
          const Space v1146_7 = routine_205(c, v1146_6, v1144_7_tail);
          v1145_8 = compose(v1145_5,v1146_7);
        }
        const Space v1145_9 = intersect(constant_8,v1145_2);
        const Space v1145_10 = (has_head(v1145_9) ? constant_9 : Space{});
        Space v1145_12;
        if (!v1145_10.empty()) {
          const Path v1147_6 = concat_path(v1144_6,v1144_7_head);
          const Space v1147_11 = routine_206(c, v1147_6, v1144_7_tail);
          v1145_12 = compose(v1145_10,v1147_11);
        }
        const Space v1145_13 = unite(v1145_8,v1145_12);
        v1144_7_result = unite(v1144_7_result,v1145_13);
      }
      const Space v1144_7 = std::move(v1144_7_result);
      v1143_8 = compose(v1143_5,v1144_7);
    }
    const Space v1143_9 = intersect(constant_8,v1143_2);
    const Space v1143_10 = (has_head(v1143_9) ? constant_9 : Space{});
    Space v1143_12;
    if (!v1143_10.empty()) {
      const Path v1148_6 = concat_path(p0,v1142_11_head);
      Space v1148_11_result;
      for (int v1148_11_label = 1; v1148_11_label <= 2; ++v1148_11_label) {
        const Space v1148_11_tail = child(v1142_11_tail,v1148_11_label);
        if (v1148_11_tail.empty()) continue;
        const Path v1148_11_head{v1148_11_label};
        const Space v1149_2 = singleton(v1148_11_head);
        const Space v1149_3 = intersect(constant_8,v1149_2);
        const Space v1149_4 = (has_head(v1149_3) ? constant_9 : Space{});
        const Space v1149_5 = subtract(constant_0,v1149_4);
        Space v1149_7;
        if (!v1149_5.empty()) {
          const Space v1150_6 = routine_118(c, v1148_11_head, v1148_6, v1148_11_tail);
          v1149_7 = compose(v1149_5,v1150_6);
        }
        const Space v1149_8 = intersect(constant_8,v1149_2);
        const Space v1149_9 = (has_head(v1149_8) ? constant_9 : Space{});
        Space v1149_11;
        if (!v1149_9.empty()) {
          const Space v1151_10 = routine_119(c, v1148_11_head, v1148_6, v1148_11_tail);
          v1149_11 = compose(v1149_9,v1151_10);
        }
        const Space v1149_12 = unite(v1149_7,v1149_11);
        v1148_11_result = unite(v1148_11_result,v1149_12);
      }
      const Space v1148_11 = std::move(v1148_11_result);
      v1143_12 = compose(v1143_10,v1148_11);
    }
    const Space v1143_13 = unite(v1143_8,v1143_12);
    v1142_11_result = unite(v1142_11_result,v1143_13);
  }
  const Space v1142_11 = std::move(v1142_11_result);
  return v1142_11;
}

static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1152_12_result;
  for (int v1152_12_label = 1; v1152_12_label <= 2; ++v1152_12_label) {
    const Space v1152_12_tail = child(s0,v1152_12_label);
    if (v1152_12_tail.empty()) continue;
    const Path v1152_12_head{v1152_12_label};
    const Space v1153_2 = singleton(v1152_12_head);
    const Space v1153_3 = intersect(constant_8,v1153_2);
    const Space v1153_4 = (has_head(v1153_3) ? constant_9 : Space{});
    const Space v1153_5 = subtract(constant_0,v1153_4);
    Space v1153_8;
    if (!v1153_5.empty()) {
      const Path v1154_6 = concat_path(p0,v1152_12_head);
      Space v1154_7_result;
      for (int v1154_7_label = 1; v1154_7_label <= 2; ++v1154_7_label) {
        const Space v1154_7_tail = child(v1152_12_tail,v1154_7_label);
        if (v1154_7_tail.empty()) continue;
        const Path v1154_7_head{v1154_7_label};
        const Space v1155_2 = singleton(v1154_7_head);
        const Space v1155_3 = intersect(constant_8,v1155_2);
        const Space v1155_4 = (has_head(v1155_3) ? constant_9 : Space{});
        const Space v1155_5 = subtract(constant_0,v1155_4);
        Space v1155_8;
        if (!v1155_5.empty()) {
          const Path v1156_6 = concat_path(v1154_6,v1154_7_head);
          const Space v1156_7 = routine_207(c, v1156_6, p1, v1154_7_tail);
          v1155_8 = compose(v1155_5,v1156_7);
        }
        const Space v1155_9 = intersect(constant_8,v1155_2);
        const Space v1155_10 = (has_head(v1155_9) ? constant_9 : Space{});
        Space v1155_12;
        if (!v1155_10.empty()) {
          const Path v1157_6 = concat_path(v1154_6,v1154_7_head);
          const Space v1157_11 = routine_208(c, v1157_6, p1, v1154_7_tail);
          v1155_12 = compose(v1155_10,v1157_11);
        }
        const Space v1155_13 = unite(v1155_8,v1155_12);
        v1154_7_result = unite(v1154_7_result,v1155_13);
      }
      const Space v1154_7 = std::move(v1154_7_result);
      v1153_8 = compose(v1153_5,v1154_7);
    }
    const Space v1153_9 = intersect(constant_8,v1153_2);
    const Space v1153_10 = (has_head(v1153_9) ? constant_9 : Space{});
    Space v1153_12;
    if (!v1153_10.empty()) {
      const Path v1158_6 = concat_path(p0,v1152_12_head);
      Space v1158_11_result;
      for (int v1158_11_label = 1; v1158_11_label <= 2; ++v1158_11_label) {
        const Space v1158_11_tail = child(v1152_12_tail,v1158_11_label);
        if (v1158_11_tail.empty()) continue;
        const Path v1158_11_head{v1158_11_label};
        const Space v1159_2 = singleton(v1158_11_head);
        const Space v1159_3 = intersect(constant_8,v1159_2);
        const Space v1159_4 = (has_head(v1159_3) ? constant_9 : Space{});
        const Space v1159_5 = subtract(constant_0,v1159_4);
        Space v1159_8;
        if (!v1159_5.empty()) {
          const Path v1160_6 = concat_path(v1158_6,v1158_11_head);
          const Space v1160_7 = routine_207(c, v1160_6, p1, v1158_11_tail);
          v1159_8 = compose(v1159_5,v1160_7);
        }
        const Space v1159_9 = intersect(constant_8,v1159_2);
        const Space v1159_10 = (has_head(v1159_9) ? constant_9 : Space{});
        Space v1159_12;
        if (!v1159_10.empty()) {
          const Path v1161_6 = concat_path(v1158_6,v1158_11_head);
          const Space v1161_11 = routine_162(c, v1161_6, p1, v1158_11_tail);
          v1159_12 = compose(v1159_10,v1161_11);
        }
        const Space v1159_13 = unite(v1159_8,v1159_12);
        v1158_11_result = unite(v1158_11_result,v1159_13);
      }
      const Space v1158_11 = std::move(v1158_11_result);
      v1153_12 = compose(v1153_10,v1158_11);
    }
    const Space v1153_13 = unite(v1153_8,v1153_12);
    v1152_12_result = unite(v1152_12_result,v1153_13);
  }
  const Space v1152_12 = std::move(v1152_12_result);
  return v1152_12;
}

static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1162_12_result;
  for (int v1162_12_label = 1; v1162_12_label <= 2; ++v1162_12_label) {
    const Space v1162_12_tail = child(s0,v1162_12_label);
    if (v1162_12_tail.empty()) continue;
    const Path v1162_12_head{v1162_12_label};
    const Space v1163_2 = singleton(v1162_12_head);
    const Space v1163_3 = intersect(constant_8,v1163_2);
    const Space v1163_4 = (has_head(v1163_3) ? constant_9 : Space{});
    const Space v1163_5 = subtract(constant_0,v1163_4);
    Space v1163_8;
    if (!v1163_5.empty()) {
      const Path v1164_6 = concat_path(p0,v1162_12_head);
      Space v1164_7_result;
      for (int v1164_7_label = 1; v1164_7_label <= 2; ++v1164_7_label) {
        const Space v1164_7_tail = child(v1162_12_tail,v1164_7_label);
        if (v1164_7_tail.empty()) continue;
        const Path v1164_7_head{v1164_7_label};
        const Space v1165_2 = singleton(v1164_7_head);
        const Space v1165_3 = intersect(constant_8,v1165_2);
        const Space v1165_4 = (has_head(v1165_3) ? constant_9 : Space{});
        const Space v1165_5 = subtract(constant_0,v1165_4);
        Space v1165_8;
        if (!v1165_5.empty()) {
          const Path v1166_6 = concat_path(v1164_6,v1164_7_head);
          const Space v1166_7 = routine_207(c, v1166_6, p1, v1164_7_tail);
          v1165_8 = compose(v1165_5,v1166_7);
        }
        const Space v1165_9 = intersect(constant_8,v1165_2);
        const Space v1165_10 = (has_head(v1165_9) ? constant_9 : Space{});
        Space v1165_12;
        if (!v1165_10.empty()) {
          const Path v1167_6 = concat_path(v1164_6,v1164_7_head);
          const Space v1167_11 = routine_208(c, v1167_6, p1, v1164_7_tail);
          v1165_12 = compose(v1165_10,v1167_11);
        }
        const Space v1165_13 = unite(v1165_8,v1165_12);
        v1164_7_result = unite(v1164_7_result,v1165_13);
      }
      const Space v1164_7 = std::move(v1164_7_result);
      v1163_8 = compose(v1163_5,v1164_7);
    }
    const Space v1163_9 = intersect(constant_8,v1163_2);
    const Space v1163_10 = (has_head(v1163_9) ? constant_9 : Space{});
    Space v1163_12;
    if (!v1163_10.empty()) {
      const Path v1168_6 = concat_path(p0,v1162_12_head);
      Space v1168_11_result;
      for (int v1168_11_label = 1; v1168_11_label <= 2; ++v1168_11_label) {
        const Space v1168_11_tail = child(v1162_12_tail,v1168_11_label);
        if (v1168_11_tail.empty()) continue;
        const Path v1168_11_head{v1168_11_label};
        const Space v1169_2 = singleton(v1168_11_head);
        const Space v1169_3 = intersect(constant_8,v1169_2);
        const Space v1169_4 = (has_head(v1169_3) ? constant_9 : Space{});
        const Space v1169_5 = subtract(constant_0,v1169_4);
        Space v1169_7;
        if (!v1169_5.empty()) {
          const Space v1170_6 = routine_209(c, v1168_11_head, p1, v1168_6, v1168_11_tail);
          v1169_7 = compose(v1169_5,v1170_6);
        }
        const Space v1169_8 = intersect(constant_8,v1169_2);
        const Space v1169_9 = (has_head(v1169_8) ? constant_9 : Space{});
        Space v1169_11;
        if (!v1169_9.empty()) {
          const Space v1171_10 = routine_210(c, v1168_11_head, p1, v1168_6, v1168_11_tail);
          v1169_11 = compose(v1169_9,v1171_10);
        }
        const Space v1169_12 = unite(v1169_7,v1169_11);
        v1168_11_result = unite(v1168_11_result,v1169_12);
      }
      const Space v1168_11 = std::move(v1168_11_result);
      v1163_12 = compose(v1163_10,v1168_11);
    }
    const Space v1163_13 = unite(v1163_8,v1163_12);
    v1162_12_result = unite(v1162_12_result,v1163_13);
  }
  const Space v1162_12 = std::move(v1162_12_result);
  return v1162_12;
}

static Space routine_120(Context& c, const Path& p0, const Space& s0) {
  Space v1172_11_result;
  for (int v1172_11_label = 1; v1172_11_label <= 2; ++v1172_11_label) {
    const Space v1172_11_tail = child(s0,v1172_11_label);
    if (v1172_11_tail.empty()) continue;
    const Path v1172_11_head{v1172_11_label};
    const Space v1173_2 = singleton(v1172_11_head);
    const Space v1173_3 = intersect(constant_8,v1173_2);
    const Space v1173_4 = (has_head(v1173_3) ? constant_9 : Space{});
    const Space v1173_5 = subtract(constant_0,v1173_4);
    Space v1173_8;
    if (!v1173_5.empty()) {
      const Path v1174_6 = concat_path(p0,v1172_11_head);
      Space v1174_7_result;
      for (int v1174_7_label = 1; v1174_7_label <= 2; ++v1174_7_label) {
        const Space v1174_7_tail = child(v1172_11_tail,v1174_7_label);
        if (v1174_7_tail.empty()) continue;
        const Path v1174_7_head{v1174_7_label};
        const Space v1175_2 = singleton(v1174_7_head);
        const Space v1175_3 = intersect(constant_8,v1175_2);
        const Space v1175_4 = (has_head(v1175_3) ? constant_9 : Space{});
        const Space v1175_5 = subtract(constant_0,v1175_4);
        Space v1175_8;
        if (!v1175_5.empty()) {
          const Path v1176_6 = concat_path(v1174_6,v1174_7_head);
          const Space v1176_7 = routine_211(c, v1176_6, v1174_7_tail);
          v1175_8 = compose(v1175_5,v1176_7);
        }
        const Space v1175_9 = intersect(constant_8,v1175_2);
        const Space v1175_10 = (has_head(v1175_9) ? constant_9 : Space{});
        Space v1175_12;
        if (!v1175_10.empty()) {
          const Path v1177_6 = concat_path(v1174_6,v1174_7_head);
          const Space v1177_11 = routine_212(c, v1177_6, v1174_7_tail);
          v1175_12 = compose(v1175_10,v1177_11);
        }
        const Space v1175_13 = unite(v1175_8,v1175_12);
        v1174_7_result = unite(v1174_7_result,v1175_13);
      }
      const Space v1174_7 = std::move(v1174_7_result);
      v1173_8 = compose(v1173_5,v1174_7);
    }
    const Space v1173_9 = intersect(constant_8,v1173_2);
    const Space v1173_10 = (has_head(v1173_9) ? constant_9 : Space{});
    Space v1173_12;
    if (!v1173_10.empty()) {
      const Path v1178_6 = concat_path(p0,v1172_11_head);
      Space v1178_11_result;
      for (int v1178_11_label = 1; v1178_11_label <= 2; ++v1178_11_label) {
        const Space v1178_11_tail = child(v1172_11_tail,v1178_11_label);
        if (v1178_11_tail.empty()) continue;
        const Path v1178_11_head{v1178_11_label};
        const Space v1179_2 = singleton(v1178_11_head);
        const Space v1179_3 = intersect(constant_8,v1179_2);
        const Space v1179_4 = (has_head(v1179_3) ? constant_9 : Space{});
        const Space v1179_5 = subtract(constant_0,v1179_4);
        Space v1179_8;
        if (!v1179_5.empty()) {
          const Path v1180_6 = concat_path(v1178_6,v1178_11_head);
          const Space v1180_7 = routine_211(c, v1180_6, v1178_11_tail);
          v1179_8 = compose(v1179_5,v1180_7);
        }
        const Space v1179_9 = intersect(constant_8,v1179_2);
        const Space v1179_10 = (has_head(v1179_9) ? constant_9 : Space{});
        Space v1179_12;
        if (!v1179_10.empty()) {
          const Path v1181_6 = concat_path(v1178_6,v1178_11_head);
          const Space v1181_11 = routine_86(c, v1181_6, v1178_11_tail);
          v1179_12 = compose(v1179_10,v1181_11);
        }
        const Space v1179_13 = unite(v1179_8,v1179_12);
        v1178_11_result = unite(v1178_11_result,v1179_13);
      }
      const Space v1178_11 = std::move(v1178_11_result);
      v1173_12 = compose(v1173_10,v1178_11);
    }
    const Space v1173_13 = unite(v1173_8,v1173_12);
    v1172_11_result = unite(v1172_11_result,v1173_13);
  }
  const Space v1172_11 = std::move(v1172_11_result);
  return v1172_11;
}

static Space routine_121(Context& c, const Path& p0, const Space& s0) {
  Space v1182_8_result;
  for (int v1182_8_label = 1; v1182_8_label <= 2; ++v1182_8_label) {
    const Space v1182_8_tail = child(s0,v1182_8_label);
    if (v1182_8_tail.empty()) continue;
    const Path v1182_8_head{v1182_8_label};
    const Space v1183_2 = singleton(v1182_8_head);
    const Space v1183_3 = intersect(constant_8,v1183_2);
    const Space v1183_4 = (has_head(v1183_3) ? constant_9 : Space{});
    const Space v1183_5 = subtract(constant_0,v1183_4);
    Space v1183_8;
    if (!v1183_5.empty()) {
      const Path v1184_6 = concat_path(p0,v1182_8_head);
      Space v1184_7_result;
      for (int v1184_7_label = 1; v1184_7_label <= 2; ++v1184_7_label) {
        const Space v1184_7_tail = child(v1182_8_tail,v1184_7_label);
        if (v1184_7_tail.empty()) continue;
        const Path v1184_7_head{v1184_7_label};
        const Space v1185_2 = singleton(v1184_7_head);
        const Space v1185_3 = intersect(constant_8,v1185_2);
        const Space v1185_4 = (has_head(v1185_3) ? constant_9 : Space{});
        const Space v1185_5 = subtract(constant_0,v1185_4);
        Space v1185_8;
        if (!v1185_5.empty()) {
          const Path v1186_6 = concat_path(v1184_6,v1184_7_head);
          const Space v1186_7 = routine_211(c, v1186_6, v1184_7_tail);
          v1185_8 = compose(v1185_5,v1186_7);
        }
        const Space v1185_9 = intersect(constant_8,v1185_2);
        const Space v1185_10 = (has_head(v1185_9) ? constant_9 : Space{});
        Space v1185_12;
        if (!v1185_10.empty()) {
          const Path v1187_6 = concat_path(v1184_6,v1184_7_head);
          const Space v1187_11 = routine_212(c, v1187_6, v1184_7_tail);
          v1185_12 = compose(v1185_10,v1187_11);
        }
        const Space v1185_13 = unite(v1185_8,v1185_12);
        v1184_7_result = unite(v1184_7_result,v1185_13);
      }
      const Space v1184_7 = std::move(v1184_7_result);
      v1183_8 = compose(v1183_5,v1184_7);
    }
    const Space v1183_9 = intersect(constant_8,v1183_2);
    const Space v1183_10 = (has_head(v1183_9) ? constant_9 : Space{});
    const Space v1183_11 = compose(v1183_10,v1182_8_tail);
    const Space v1183_12 = unite(v1183_8,v1183_11);
    v1182_8_result = unite(v1182_8_result,v1183_12);
  }
  const Space v1182_8 = std::move(v1182_8_result);
  return v1182_8;
}

static Space routine_122(Context& c, const Path& p0, const Space& s0) {
  Space v1188_11_result;
  for (int v1188_11_label = 1; v1188_11_label <= 2; ++v1188_11_label) {
    const Space v1188_11_tail = child(s0,v1188_11_label);
    if (v1188_11_tail.empty()) continue;
    const Path v1188_11_head{v1188_11_label};
    const Space v1189_2 = singleton(v1188_11_head);
    const Space v1189_3 = intersect(constant_8,v1189_2);
    const Space v1189_4 = (has_head(v1189_3) ? constant_9 : Space{});
    const Space v1189_5 = subtract(constant_0,v1189_4);
    Space v1189_8;
    if (!v1189_5.empty()) {
      const Path v1190_6 = concat_path(p0,v1188_11_head);
      Space v1190_7_result;
      for (int v1190_7_label = 1; v1190_7_label <= 2; ++v1190_7_label) {
        const Space v1190_7_tail = child(v1188_11_tail,v1190_7_label);
        if (v1190_7_tail.empty()) continue;
        const Path v1190_7_head{v1190_7_label};
        const Space v1191_2 = singleton(v1190_7_head);
        const Space v1191_3 = intersect(constant_8,v1191_2);
        const Space v1191_4 = (has_head(v1191_3) ? constant_9 : Space{});
        const Space v1191_5 = subtract(constant_0,v1191_4);
        Space v1191_8;
        if (!v1191_5.empty()) {
          const Path v1192_6 = concat_path(v1190_6,v1190_7_head);
          const Space v1192_7 = routine_213(c, v1192_6, v1190_7_tail);
          v1191_8 = compose(v1191_5,v1192_7);
        }
        const Space v1191_9 = intersect(constant_8,v1191_2);
        const Space v1191_10 = (has_head(v1191_9) ? constant_9 : Space{});
        Space v1191_12;
        if (!v1191_10.empty()) {
          const Path v1193_6 = concat_path(v1190_6,v1190_7_head);
          const Space v1193_11 = routine_214(c, v1193_6, v1190_7_tail);
          v1191_12 = compose(v1191_10,v1193_11);
        }
        const Space v1191_13 = unite(v1191_8,v1191_12);
        v1190_7_result = unite(v1190_7_result,v1191_13);
      }
      const Space v1190_7 = std::move(v1190_7_result);
      v1189_8 = compose(v1189_5,v1190_7);
    }
    const Space v1189_9 = intersect(constant_8,v1189_2);
    const Space v1189_10 = (has_head(v1189_9) ? constant_9 : Space{});
    Space v1189_12;
    if (!v1189_10.empty()) {
      const Path v1194_6 = concat_path(p0,v1188_11_head);
      Space v1194_11_result;
      for (int v1194_11_label = 1; v1194_11_label <= 2; ++v1194_11_label) {
        const Space v1194_11_tail = child(v1188_11_tail,v1194_11_label);
        if (v1194_11_tail.empty()) continue;
        const Path v1194_11_head{v1194_11_label};
        const Space v1195_2 = singleton(v1194_11_head);
        const Space v1195_3 = intersect(constant_8,v1195_2);
        const Space v1195_4 = (has_head(v1195_3) ? constant_9 : Space{});
        const Space v1195_5 = subtract(constant_0,v1195_4);
        Space v1195_8;
        if (!v1195_5.empty()) {
          const Path v1196_6 = concat_path(v1194_6,v1194_11_head);
          const Space v1196_7 = routine_213(c, v1196_6, v1194_11_tail);
          v1195_8 = compose(v1195_5,v1196_7);
        }
        const Space v1195_9 = intersect(constant_8,v1195_2);
        const Space v1195_10 = (has_head(v1195_9) ? constant_9 : Space{});
        Space v1195_12;
        if (!v1195_10.empty()) {
          const Path v1197_6 = concat_path(v1194_6,v1194_11_head);
          const Space v1197_11 = routine_89(c, v1197_6, v1194_11_tail);
          v1195_12 = compose(v1195_10,v1197_11);
        }
        const Space v1195_13 = unite(v1195_8,v1195_12);
        v1194_11_result = unite(v1194_11_result,v1195_13);
      }
      const Space v1194_11 = std::move(v1194_11_result);
      v1189_12 = compose(v1189_10,v1194_11);
    }
    const Space v1189_13 = unite(v1189_8,v1189_12);
    v1188_11_result = unite(v1188_11_result,v1189_13);
  }
  const Space v1188_11 = std::move(v1188_11_result);
  return v1188_11;
}

static Space routine_123(Context& c, const Path& p0, const Space& s0) {
  Space v1198_11_result;
  for (int v1198_11_label = 1; v1198_11_label <= 2; ++v1198_11_label) {
    const Space v1198_11_tail = child(s0,v1198_11_label);
    if (v1198_11_tail.empty()) continue;
    const Path v1198_11_head{v1198_11_label};
    const Space v1199_2 = singleton(v1198_11_head);
    const Space v1199_3 = intersect(constant_8,v1199_2);
    const Space v1199_4 = (has_head(v1199_3) ? constant_9 : Space{});
    const Space v1199_5 = subtract(constant_0,v1199_4);
    Space v1199_8;
    if (!v1199_5.empty()) {
      const Path v1200_6 = concat_path(p0,v1198_11_head);
      Space v1200_7_result;
      for (int v1200_7_label = 1; v1200_7_label <= 2; ++v1200_7_label) {
        const Space v1200_7_tail = child(v1198_11_tail,v1200_7_label);
        if (v1200_7_tail.empty()) continue;
        const Path v1200_7_head{v1200_7_label};
        const Space v1201_2 = singleton(v1200_7_head);
        const Space v1201_3 = intersect(constant_8,v1201_2);
        const Space v1201_4 = (has_head(v1201_3) ? constant_9 : Space{});
        const Space v1201_5 = subtract(constant_0,v1201_4);
        Space v1201_8;
        if (!v1201_5.empty()) {
          const Path v1202_6 = concat_path(v1200_6,v1200_7_head);
          const Space v1202_7 = routine_213(c, v1202_6, v1200_7_tail);
          v1201_8 = compose(v1201_5,v1202_7);
        }
        const Space v1201_9 = intersect(constant_8,v1201_2);
        const Space v1201_10 = (has_head(v1201_9) ? constant_9 : Space{});
        Space v1201_12;
        if (!v1201_10.empty()) {
          const Path v1203_6 = concat_path(v1200_6,v1200_7_head);
          const Space v1203_11 = routine_214(c, v1203_6, v1200_7_tail);
          v1201_12 = compose(v1201_10,v1203_11);
        }
        const Space v1201_13 = unite(v1201_8,v1201_12);
        v1200_7_result = unite(v1200_7_result,v1201_13);
      }
      const Space v1200_7 = std::move(v1200_7_result);
      v1199_8 = compose(v1199_5,v1200_7);
    }
    const Space v1199_9 = intersect(constant_8,v1199_2);
    const Space v1199_10 = (has_head(v1199_9) ? constant_9 : Space{});
    Space v1199_12;
    if (!v1199_10.empty()) {
      const Path v1204_6 = concat_path(p0,v1198_11_head);
      Space v1204_11_result;
      for (int v1204_11_label = 1; v1204_11_label <= 2; ++v1204_11_label) {
        const Space v1204_11_tail = child(v1198_11_tail,v1204_11_label);
        if (v1204_11_tail.empty()) continue;
        const Path v1204_11_head{v1204_11_label};
        const Space v1205_2 = singleton(v1204_11_head);
        const Space v1205_3 = intersect(constant_8,v1205_2);
        const Space v1205_4 = (has_head(v1205_3) ? constant_9 : Space{});
        const Space v1205_5 = subtract(constant_0,v1205_4);
        Space v1205_7;
        if (!v1205_5.empty()) {
          const Space v1206_6 = routine_124(c, v1204_11_head, v1204_6, v1204_11_tail);
          v1205_7 = compose(v1205_5,v1206_6);
        }
        const Space v1205_8 = intersect(constant_8,v1205_2);
        const Space v1205_9 = (has_head(v1205_8) ? constant_9 : Space{});
        Space v1205_11;
        if (!v1205_9.empty()) {
          const Space v1207_10 = routine_125(c, v1204_11_head, v1204_6, v1204_11_tail);
          v1205_11 = compose(v1205_9,v1207_10);
        }
        const Space v1205_12 = unite(v1205_7,v1205_11);
        v1204_11_result = unite(v1204_11_result,v1205_12);
      }
      const Space v1204_11 = std::move(v1204_11_result);
      v1199_12 = compose(v1199_10,v1204_11);
    }
    const Space v1199_13 = unite(v1199_8,v1199_12);
    v1198_11_result = unite(v1198_11_result,v1199_13);
  }
  const Space v1198_11 = std::move(v1198_11_result);
  return v1198_11;
}

static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1208_12_result;
  for (int v1208_12_label = 1; v1208_12_label <= 2; ++v1208_12_label) {
    const Space v1208_12_tail = child(s0,v1208_12_label);
    if (v1208_12_tail.empty()) continue;
    const Path v1208_12_head{v1208_12_label};
    const Space v1209_2 = singleton(v1208_12_head);
    const Space v1209_3 = intersect(constant_8,v1209_2);
    const Space v1209_4 = (has_head(v1209_3) ? constant_9 : Space{});
    const Space v1209_5 = subtract(constant_0,v1209_4);
    Space v1209_8;
    if (!v1209_5.empty()) {
      const Path v1210_6 = concat_path(p0,v1208_12_head);
      Space v1210_7_result;
      for (int v1210_7_label = 1; v1210_7_label <= 2; ++v1210_7_label) {
        const Space v1210_7_tail = child(v1208_12_tail,v1210_7_label);
        if (v1210_7_tail.empty()) continue;
        const Path v1210_7_head{v1210_7_label};
        const Space v1211_2 = singleton(v1210_7_head);
        const Space v1211_3 = intersect(constant_8,v1211_2);
        const Space v1211_4 = (has_head(v1211_3) ? constant_9 : Space{});
        const Space v1211_5 = subtract(constant_0,v1211_4);
        Space v1211_8;
        if (!v1211_5.empty()) {
          const Path v1212_6 = concat_path(v1210_6,v1210_7_head);
          const Space v1212_7 = routine_215(c, v1212_6, p1, v1210_7_tail);
          v1211_8 = compose(v1211_5,v1212_7);
        }
        const Space v1211_9 = intersect(constant_8,v1211_2);
        const Space v1211_10 = (has_head(v1211_9) ? constant_9 : Space{});
        Space v1211_12;
        if (!v1211_10.empty()) {
          const Path v1213_6 = concat_path(v1210_6,v1210_7_head);
          const Space v1213_11 = routine_216(c, v1213_6, p1, v1210_7_tail);
          v1211_12 = compose(v1211_10,v1213_11);
        }
        const Space v1211_13 = unite(v1211_8,v1211_12);
        v1210_7_result = unite(v1210_7_result,v1211_13);
      }
      const Space v1210_7 = std::move(v1210_7_result);
      v1209_8 = compose(v1209_5,v1210_7);
    }
    const Space v1209_9 = intersect(constant_8,v1209_2);
    const Space v1209_10 = (has_head(v1209_9) ? constant_9 : Space{});
    Space v1209_12;
    if (!v1209_10.empty()) {
      const Path v1214_6 = concat_path(p0,v1208_12_head);
      Space v1214_11_result;
      for (int v1214_11_label = 1; v1214_11_label <= 2; ++v1214_11_label) {
        const Space v1214_11_tail = child(v1208_12_tail,v1214_11_label);
        if (v1214_11_tail.empty()) continue;
        const Path v1214_11_head{v1214_11_label};
        const Space v1215_2 = singleton(v1214_11_head);
        const Space v1215_3 = intersect(constant_8,v1215_2);
        const Space v1215_4 = (has_head(v1215_3) ? constant_9 : Space{});
        const Space v1215_5 = subtract(constant_0,v1215_4);
        Space v1215_8;
        if (!v1215_5.empty()) {
          const Path v1216_6 = concat_path(v1214_6,v1214_11_head);
          const Space v1216_7 = routine_215(c, v1216_6, p1, v1214_11_tail);
          v1215_8 = compose(v1215_5,v1216_7);
        }
        const Space v1215_9 = intersect(constant_8,v1215_2);
        const Space v1215_10 = (has_head(v1215_9) ? constant_9 : Space{});
        Space v1215_12;
        if (!v1215_10.empty()) {
          const Path v1217_6 = concat_path(v1214_6,v1214_11_head);
          const Space v1217_11 = routine_169(c, v1217_6, p1, v1214_11_tail);
          v1215_12 = compose(v1215_10,v1217_11);
        }
        const Space v1215_13 = unite(v1215_8,v1215_12);
        v1214_11_result = unite(v1214_11_result,v1215_13);
      }
      const Space v1214_11 = std::move(v1214_11_result);
      v1209_12 = compose(v1209_10,v1214_11);
    }
    const Space v1209_13 = unite(v1209_8,v1209_12);
    v1208_12_result = unite(v1208_12_result,v1209_13);
  }
  const Space v1208_12 = std::move(v1208_12_result);
  return v1208_12;
}

static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1218_12_result;
  for (int v1218_12_label = 1; v1218_12_label <= 2; ++v1218_12_label) {
    const Space v1218_12_tail = child(s0,v1218_12_label);
    if (v1218_12_tail.empty()) continue;
    const Path v1218_12_head{v1218_12_label};
    const Space v1219_2 = singleton(v1218_12_head);
    const Space v1219_3 = intersect(constant_8,v1219_2);
    const Space v1219_4 = (has_head(v1219_3) ? constant_9 : Space{});
    const Space v1219_5 = subtract(constant_0,v1219_4);
    Space v1219_8;
    if (!v1219_5.empty()) {
      const Path v1220_6 = concat_path(p0,v1218_12_head);
      Space v1220_7_result;
      for (int v1220_7_label = 1; v1220_7_label <= 2; ++v1220_7_label) {
        const Space v1220_7_tail = child(v1218_12_tail,v1220_7_label);
        if (v1220_7_tail.empty()) continue;
        const Path v1220_7_head{v1220_7_label};
        const Space v1221_2 = singleton(v1220_7_head);
        const Space v1221_3 = intersect(constant_8,v1221_2);
        const Space v1221_4 = (has_head(v1221_3) ? constant_9 : Space{});
        const Space v1221_5 = subtract(constant_0,v1221_4);
        Space v1221_8;
        if (!v1221_5.empty()) {
          const Path v1222_6 = concat_path(v1220_6,v1220_7_head);
          const Space v1222_7 = routine_215(c, v1222_6, p1, v1220_7_tail);
          v1221_8 = compose(v1221_5,v1222_7);
        }
        const Space v1221_9 = intersect(constant_8,v1221_2);
        const Space v1221_10 = (has_head(v1221_9) ? constant_9 : Space{});
        Space v1221_12;
        if (!v1221_10.empty()) {
          const Path v1223_6 = concat_path(v1220_6,v1220_7_head);
          const Space v1223_11 = routine_216(c, v1223_6, p1, v1220_7_tail);
          v1221_12 = compose(v1221_10,v1223_11);
        }
        const Space v1221_13 = unite(v1221_8,v1221_12);
        v1220_7_result = unite(v1220_7_result,v1221_13);
      }
      const Space v1220_7 = std::move(v1220_7_result);
      v1219_8 = compose(v1219_5,v1220_7);
    }
    const Space v1219_9 = intersect(constant_8,v1219_2);
    const Space v1219_10 = (has_head(v1219_9) ? constant_9 : Space{});
    Space v1219_12;
    if (!v1219_10.empty()) {
      const Path v1224_6 = concat_path(p0,v1218_12_head);
      Space v1224_11_result;
      for (int v1224_11_label = 1; v1224_11_label <= 2; ++v1224_11_label) {
        const Space v1224_11_tail = child(v1218_12_tail,v1224_11_label);
        if (v1224_11_tail.empty()) continue;
        const Path v1224_11_head{v1224_11_label};
        const Space v1225_2 = singleton(v1224_11_head);
        const Space v1225_3 = intersect(constant_8,v1225_2);
        const Space v1225_4 = (has_head(v1225_3) ? constant_9 : Space{});
        const Space v1225_5 = subtract(constant_0,v1225_4);
        Space v1225_7;
        if (!v1225_5.empty()) {
          const Space v1226_6 = routine_217(c, v1224_11_head, p1, v1224_6, v1224_11_tail);
          v1225_7 = compose(v1225_5,v1226_6);
        }
        const Space v1225_8 = intersect(constant_8,v1225_2);
        const Space v1225_9 = (has_head(v1225_8) ? constant_9 : Space{});
        Space v1225_11;
        if (!v1225_9.empty()) {
          const Space v1227_10 = routine_218(c, v1224_11_head, p1, v1224_6, v1224_11_tail);
          v1225_11 = compose(v1225_9,v1227_10);
        }
        const Space v1225_12 = unite(v1225_7,v1225_11);
        v1224_11_result = unite(v1224_11_result,v1225_12);
      }
      const Space v1224_11 = std::move(v1224_11_result);
      v1219_12 = compose(v1219_10,v1224_11);
    }
    const Space v1219_13 = unite(v1219_8,v1219_12);
    v1218_12_result = unite(v1218_12_result,v1219_13);
  }
  const Space v1218_12 = std::move(v1218_12_result);
  return v1218_12;
}

static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1228_7_result;
  for (int v1228_7_label = 1; v1228_7_label <= 2; ++v1228_7_label) {
    const Space v1228_7_tail = child(s0,v1228_7_label);
    if (v1228_7_tail.empty()) continue;
    const Path v1228_7_head{v1228_7_label};
    const Space v1229_2 = singleton(v1228_7_head);
    const Space v1229_3 = intersect(constant_8,v1229_2);
    const Space v1229_4 = (has_head(v1229_3) ? constant_9 : Space{});
    const Space v1229_5 = subtract(constant_0,v1229_4);
    Space v1229_6_result;
    for (int v1229_6_label = 1; v1229_6_label <= 2; ++v1229_6_label) {
      const Space v1229_6_tail = child(v1228_7_tail,v1229_6_label);
      if (v1229_6_tail.empty()) continue;
      const Path v1229_6_head{v1229_6_label};
      const Space v1230_2 = Space{};
      v1229_6_result = unite(v1229_6_result,v1230_2);
    }
    const Space v1229_6 = std::move(v1229_6_result);
    const Space v1229_7 = compose(v1229_5,v1229_6);
    const Space v1229_8 = intersect(constant_8,v1229_2);
    const Space v1229_9 = (has_head(v1229_8) ? constant_9 : Space{});
    Space v1229_12;
    if (!v1229_9.empty()) {
      const Path v1231_10 = concat_path(p0,v1228_7_head);
      Space v1231_11_result;
      for (int v1231_11_label = 1; v1231_11_label <= 2; ++v1231_11_label) {
        const Space v1231_11_tail = child(v1228_7_tail,v1231_11_label);
        if (v1231_11_tail.empty()) continue;
        const Path v1231_11_head{v1231_11_label};
        const Space v1232_2 = singleton(v1231_11_head);
        const Space v1232_3 = intersect(constant_8,v1232_2);
        const Space v1232_4 = (has_head(v1232_3) ? constant_9 : Space{});
        Space v1232_7;
        if (!v1232_4.empty()) {
          const Path v1233_5 = concat_path(v1231_10,v1231_11_head);
          const Space v1233_6 = routine_60(c, v1233_5, p1, v1231_11_tail);
          v1232_7 = compose(v1232_4,v1233_6);
        }
        v1231_11_result = unite(v1231_11_result,v1232_7);
      }
      const Space v1231_11 = std::move(v1231_11_result);
      v1229_12 = compose(v1229_9,v1231_11);
    }
    const Space v1229_13 = unite(v1229_7,v1229_12);
    v1228_7_result = unite(v1228_7_result,v1229_13);
  }
  const Space v1228_7 = std::move(v1228_7_result);
  return v1228_7;
}

static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1234_14_result;
  for (int v1234_14_label = 1; v1234_14_label <= 2; ++v1234_14_label) {
    const Space v1234_14_tail = child(s0,v1234_14_label);
    if (v1234_14_tail.empty()) continue;
    const Path v1234_14_head{v1234_14_label};
    const Space v1235_2 = singleton(v1234_14_head);
    const Space v1235_3 = intersect(constant_8,v1235_2);
    const Space v1235_4 = (has_head(v1235_3) ? constant_9 : Space{});
    const Space v1235_5 = subtract(constant_0,v1235_4);
    Space v1235_6_result;
    for (int v1235_6_label = 1; v1235_6_label <= 2; ++v1235_6_label) {
      const Space v1235_6_tail = child(v1234_14_tail,v1235_6_label);
      if (v1235_6_tail.empty()) continue;
      const Path v1235_6_head{v1235_6_label};
      const Space v1236_2 = Space{};
      v1235_6_result = unite(v1235_6_result,v1236_2);
    }
    const Space v1235_6 = std::move(v1235_6_result);
    const Space v1235_7 = compose(v1235_5,v1235_6);
    const Space v1235_8 = intersect(constant_8,v1235_2);
    const Space v1235_9 = (has_head(v1235_8) ? constant_9 : Space{});
    Space v1235_17;
    if (!v1235_9.empty()) {
      Space v1237_13;
      if (!constant_0.empty()) {
        const Space v1238_10 = routine_92(c, constant_14, constant_15);
        const Space v1238_11 = routine_93(c, constant_16, constant_17);
        const Space v1238_12 = unite(v1238_10,v1238_11);
        v1237_13 = compose(constant_0,v1238_12);
      }
      const Space v1237_14 = unwrap(v1237_13,p1);
      const Path v1237_15 = concat_path(p0,v1234_14_head);
      Space v1237_16_result;
      for (int v1237_16_label = 1; v1237_16_label <= 2; ++v1237_16_label) {
        const Space v1237_16_tail = child(v1237_14,v1237_16_label);
        if (v1237_16_tail.empty()) continue;
        const Path v1237_16_head{v1237_16_label};
        const Space v1239_2 = singleton(v1237_16_head);
        const Space v1239_3 = intersect(constant_8,v1239_2);
        const Space v1239_4 = (has_head(v1239_3) ? constant_9 : Space{});
        const Space v1239_5 = subtract(constant_0,v1239_4);
        Space v1239_7;
        if (!v1239_5.empty()) {
          const Space v1240_6 = routine_94(c, v1237_16_head, v1237_15, v1237_16_tail, v1234_14_tail);
          v1239_7 = compose(v1239_5,v1240_6);
        }
        const Space v1239_8 = intersect(constant_8,v1239_2);
        const Space v1239_9 = (has_head(v1239_8) ? constant_9 : Space{});
        Space v1239_11;
        if (!v1239_9.empty()) {
          const Space v1241_10 = routine_95(c, v1237_16_head, v1237_15, v1237_16_tail, v1234_14_tail);
          v1239_11 = compose(v1239_9,v1241_10);
        }
        const Space v1239_12 = unite(v1239_7,v1239_11);
        v1237_16_result = unite(v1237_16_result,v1239_12);
      }
      const Space v1237_16 = std::move(v1237_16_result);
      v1235_17 = compose(v1235_9,v1237_16);
    }
    const Space v1235_18 = unite(v1235_7,v1235_17);
    v1234_14_result = unite(v1234_14_result,v1235_18);
  }
  const Space v1234_14 = std::move(v1234_14_result);
  return v1234_14;
}

static Space routine_128(Context& c, const Path& p0, const Space& s0) {
  Space v1242_11_result;
  for (int v1242_11_label = 1; v1242_11_label <= 2; ++v1242_11_label) {
    const Space v1242_11_tail = child(s0,v1242_11_label);
    if (v1242_11_tail.empty()) continue;
    const Path v1242_11_head{v1242_11_label};
    const Space v1243_2 = singleton(v1242_11_head);
    const Space v1243_3 = intersect(constant_8,v1243_2);
    const Space v1243_4 = (has_head(v1243_3) ? constant_9 : Space{});
    const Space v1243_5 = subtract(constant_0,v1243_4);
    Space v1243_8;
    if (!v1243_5.empty()) {
      const Path v1244_6 = concat_path(p0,v1242_11_head);
      Space v1244_7_result;
      for (int v1244_7_label = 1; v1244_7_label <= 2; ++v1244_7_label) {
        const Space v1244_7_tail = child(v1242_11_tail,v1244_7_label);
        if (v1244_7_tail.empty()) continue;
        const Path v1244_7_head{v1244_7_label};
        const Space v1245_2 = singleton(v1244_7_head);
        const Space v1245_3 = intersect(constant_8,v1245_2);
        const Space v1245_4 = (has_head(v1245_3) ? constant_9 : Space{});
        const Space v1245_5 = subtract(constant_0,v1245_4);
        Space v1245_8;
        if (!v1245_5.empty()) {
          const Path v1246_6 = concat_path(v1244_6,v1244_7_head);
          const Space v1246_7 = routine_219(c, v1246_6, v1244_7_tail);
          v1245_8 = compose(v1245_5,v1246_7);
        }
        const Space v1245_9 = intersect(constant_8,v1245_2);
        const Space v1245_10 = (has_head(v1245_9) ? constant_9 : Space{});
        Space v1245_12;
        if (!v1245_10.empty()) {
          const Path v1247_6 = concat_path(v1244_6,v1244_7_head);
          const Space v1247_11 = routine_220(c, v1247_6, v1244_7_tail);
          v1245_12 = compose(v1245_10,v1247_11);
        }
        const Space v1245_13 = unite(v1245_8,v1245_12);
        v1244_7_result = unite(v1244_7_result,v1245_13);
      }
      const Space v1244_7 = std::move(v1244_7_result);
      v1243_8 = compose(v1243_5,v1244_7);
    }
    const Space v1243_9 = intersect(constant_8,v1243_2);
    const Space v1243_10 = (has_head(v1243_9) ? constant_9 : Space{});
    Space v1243_12;
    if (!v1243_10.empty()) {
      const Path v1248_6 = concat_path(p0,v1242_11_head);
      Space v1248_11_result;
      for (int v1248_11_label = 1; v1248_11_label <= 2; ++v1248_11_label) {
        const Space v1248_11_tail = child(v1242_11_tail,v1248_11_label);
        if (v1248_11_tail.empty()) continue;
        const Path v1248_11_head{v1248_11_label};
        const Space v1249_2 = singleton(v1248_11_head);
        const Space v1249_3 = intersect(constant_8,v1249_2);
        const Space v1249_4 = (has_head(v1249_3) ? constant_9 : Space{});
        const Space v1249_5 = subtract(constant_0,v1249_4);
        Space v1249_8;
        if (!v1249_5.empty()) {
          const Path v1250_6 = concat_path(v1248_6,v1248_11_head);
          const Space v1250_7 = routine_219(c, v1250_6, v1248_11_tail);
          v1249_8 = compose(v1249_5,v1250_7);
        }
        const Space v1249_9 = intersect(constant_8,v1249_2);
        const Space v1249_10 = (has_head(v1249_9) ? constant_9 : Space{});
        Space v1249_12;
        if (!v1249_10.empty()) {
          const Path v1251_6 = concat_path(v1248_6,v1248_11_head);
          const Space v1251_11 = routine_130(c, v1251_6, v1248_11_tail);
          v1249_12 = compose(v1249_10,v1251_11);
        }
        const Space v1249_13 = unite(v1249_8,v1249_12);
        v1248_11_result = unite(v1248_11_result,v1249_13);
      }
      const Space v1248_11 = std::move(v1248_11_result);
      v1243_12 = compose(v1243_10,v1248_11);
    }
    const Space v1243_13 = unite(v1243_8,v1243_12);
    v1242_11_result = unite(v1242_11_result,v1243_13);
  }
  const Space v1242_11 = std::move(v1242_11_result);
  return v1242_11;
}

static Space routine_129(Context& c, const Path& p0, const Space& s0) {
  Space v1252_11_result;
  for (int v1252_11_label = 1; v1252_11_label <= 2; ++v1252_11_label) {
    const Space v1252_11_tail = child(s0,v1252_11_label);
    if (v1252_11_tail.empty()) continue;
    const Path v1252_11_head{v1252_11_label};
    const Space v1253_2 = singleton(v1252_11_head);
    const Space v1253_3 = intersect(constant_8,v1253_2);
    const Space v1253_4 = (has_head(v1253_3) ? constant_9 : Space{});
    const Space v1253_5 = subtract(constant_0,v1253_4);
    Space v1253_8;
    if (!v1253_5.empty()) {
      const Path v1254_6 = concat_path(p0,v1252_11_head);
      Space v1254_7_result;
      for (int v1254_7_label = 1; v1254_7_label <= 2; ++v1254_7_label) {
        const Space v1254_7_tail = child(v1252_11_tail,v1254_7_label);
        if (v1254_7_tail.empty()) continue;
        const Path v1254_7_head{v1254_7_label};
        const Space v1255_2 = singleton(v1254_7_head);
        const Space v1255_3 = intersect(constant_8,v1255_2);
        const Space v1255_4 = (has_head(v1255_3) ? constant_9 : Space{});
        const Space v1255_5 = subtract(constant_0,v1255_4);
        Space v1255_8;
        if (!v1255_5.empty()) {
          const Path v1256_6 = concat_path(v1254_6,v1254_7_head);
          const Space v1256_7 = routine_219(c, v1256_6, v1254_7_tail);
          v1255_8 = compose(v1255_5,v1256_7);
        }
        const Space v1255_9 = intersect(constant_8,v1255_2);
        const Space v1255_10 = (has_head(v1255_9) ? constant_9 : Space{});
        Space v1255_12;
        if (!v1255_10.empty()) {
          const Path v1257_6 = concat_path(v1254_6,v1254_7_head);
          const Space v1257_11 = routine_220(c, v1257_6, v1254_7_tail);
          v1255_12 = compose(v1255_10,v1257_11);
        }
        const Space v1255_13 = unite(v1255_8,v1255_12);
        v1254_7_result = unite(v1254_7_result,v1255_13);
      }
      const Space v1254_7 = std::move(v1254_7_result);
      v1253_8 = compose(v1253_5,v1254_7);
    }
    const Space v1253_9 = intersect(constant_8,v1253_2);
    const Space v1253_10 = (has_head(v1253_9) ? constant_9 : Space{});
    Space v1253_12;
    if (!v1253_10.empty()) {
      const Path v1258_6 = concat_path(p0,v1252_11_head);
      Space v1258_11_result;
      for (int v1258_11_label = 1; v1258_11_label <= 2; ++v1258_11_label) {
        const Space v1258_11_tail = child(v1252_11_tail,v1258_11_label);
        if (v1258_11_tail.empty()) continue;
        const Path v1258_11_head{v1258_11_label};
        const Space v1259_2 = singleton(v1258_11_head);
        const Space v1259_3 = intersect(constant_8,v1259_2);
        const Space v1259_4 = (has_head(v1259_3) ? constant_9 : Space{});
        const Space v1259_5 = subtract(constant_0,v1259_4);
        Space v1259_7;
        if (!v1259_5.empty()) {
          const Space v1260_6 = routine_174(c, v1258_11_head, v1258_6, v1258_11_tail);
          v1259_7 = compose(v1259_5,v1260_6);
        }
        const Space v1259_8 = intersect(constant_8,v1259_2);
        const Space v1259_9 = (has_head(v1259_8) ? constant_9 : Space{});
        Space v1259_11;
        if (!v1259_9.empty()) {
          const Space v1261_10 = routine_175(c, v1258_11_head, v1258_6, v1258_11_tail);
          v1259_11 = compose(v1259_9,v1261_10);
        }
        const Space v1259_12 = unite(v1259_7,v1259_11);
        v1258_11_result = unite(v1258_11_result,v1259_12);
      }
      const Space v1258_11 = std::move(v1258_11_result);
      v1253_12 = compose(v1253_10,v1258_11);
    }
    const Space v1253_13 = unite(v1253_8,v1253_12);
    v1252_11_result = unite(v1252_11_result,v1253_13);
  }
  const Space v1252_11 = std::move(v1252_11_result);
  return v1252_11;
}

static Space routine_130(Context& c, const Path& p0, const Space& s0) {
  Space v1262_11_result;
  for (int v1262_11_label = 1; v1262_11_label <= 2; ++v1262_11_label) {
    const Space v1262_11_tail = child(s0,v1262_11_label);
    if (v1262_11_tail.empty()) continue;
    const Path v1262_11_head{v1262_11_label};
    const Space v1263_2 = singleton(v1262_11_head);
    const Space v1263_3 = intersect(constant_8,v1263_2);
    const Space v1263_4 = (has_head(v1263_3) ? constant_9 : Space{});
    const Space v1263_5 = subtract(constant_0,v1263_4);
    Space v1263_7;
    if (!v1263_5.empty()) {
      Space v1264_6_result;
      for (int v1264_6_label = 1; v1264_6_label <= 2; ++v1264_6_label) {
        const Space v1264_6_tail = child(v1262_11_tail,v1264_6_label);
        if (v1264_6_tail.empty()) continue;
        const Path v1264_6_head{v1264_6_label};
        const Space v1265_2 = singleton(v1264_6_head);
        const Space v1265_3 = intersect(constant_8,v1265_2);
        const Space v1265_4 = (has_head(v1265_3) ? constant_9 : Space{});
        const Space v1265_5 = subtract(constant_0,v1265_4);
        Space v1265_8;
        if (!v1265_5.empty()) {
          const Path v1266_6 = concat_path(v1262_11_head,v1264_6_head);
          const Space v1266_7 = routine_221(c, v1266_6, p0, v1264_6_tail);
          v1265_8 = compose(v1265_5,v1266_7);
        }
        const Space v1265_9 = intersect(constant_8,v1265_2);
        const Space v1265_10 = (has_head(v1265_9) ? constant_9 : Space{});
        Space v1265_12;
        if (!v1265_10.empty()) {
          const Path v1267_6 = concat_path(v1262_11_head,v1264_6_head);
          const Space v1267_11 = routine_222(c, v1267_6, p0, v1264_6_tail);
          v1265_12 = compose(v1265_10,v1267_11);
        }
        const Space v1265_13 = unite(v1265_8,v1265_12);
        v1264_6_result = unite(v1264_6_result,v1265_13);
      }
      const Space v1264_6 = std::move(v1264_6_result);
      v1263_7 = compose(v1263_5,v1264_6);
    }
    const Space v1263_8 = intersect(constant_8,v1263_2);
    const Space v1263_9 = (has_head(v1263_8) ? constant_9 : Space{});
    Space v1263_11;
    if (!v1263_9.empty()) {
      Space v1268_10_result;
      for (int v1268_10_label = 1; v1268_10_label <= 2; ++v1268_10_label) {
        const Space v1268_10_tail = child(v1262_11_tail,v1268_10_label);
        if (v1268_10_tail.empty()) continue;
        const Path v1268_10_head{v1268_10_label};
        const Space v1269_2 = singleton(v1268_10_head);
        const Space v1269_3 = intersect(constant_8,v1269_2);
        const Space v1269_4 = (has_head(v1269_3) ? constant_9 : Space{});
        const Space v1269_5 = subtract(constant_0,v1269_4);
        Space v1269_8;
        if (!v1269_5.empty()) {
          const Path v1270_6 = concat_path(v1262_11_head,v1268_10_head);
          const Space v1270_7 = routine_221(c, v1270_6, p0, v1268_10_tail);
          v1269_8 = compose(v1269_5,v1270_7);
        }
        const Space v1269_9 = intersect(constant_8,v1269_2);
        const Space v1269_10 = (has_head(v1269_9) ? constant_9 : Space{});
        Space v1269_12;
        if (!v1269_10.empty()) {
          const Path v1271_6 = concat_path(v1262_11_head,v1268_10_head);
          const Space v1271_11 = routine_223(c, v1271_6, p0, v1268_10_tail);
          v1269_12 = compose(v1269_10,v1271_11);
        }
        const Space v1269_13 = unite(v1269_8,v1269_12);
        v1268_10_result = unite(v1268_10_result,v1269_13);
      }
      const Space v1268_10 = std::move(v1268_10_result);
      v1263_11 = compose(v1263_9,v1268_10);
    }
    const Space v1263_12 = unite(v1263_7,v1263_11);
    v1262_11_result = unite(v1262_11_result,v1263_12);
  }
  const Space v1262_11 = std::move(v1262_11_result);
  return v1262_11;
}

static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1272_13_result;
  for (int v1272_13_label = 1; v1272_13_label <= 2; ++v1272_13_label) {
    const Space v1272_13_tail = child(s0,v1272_13_label);
    if (v1272_13_tail.empty()) continue;
    const Path v1272_13_head{v1272_13_label};
    const Space v1273_2 = singleton(v1272_13_head);
    const Space v1273_3 = intersect(constant_8,v1273_2);
    const Space v1273_4 = (has_head(v1273_3) ? constant_9 : Space{});
    const Space v1273_5 = subtract(constant_0,v1273_4);
    Space v1273_8;
    if (!v1273_5.empty()) {
      const Path v1274_6 = concat_path(p0,v1272_13_head);
      Space v1274_7_result;
      for (int v1274_7_label = 1; v1274_7_label <= 2; ++v1274_7_label) {
        const Space v1274_7_tail = child(v1272_13_tail,v1274_7_label);
        if (v1274_7_tail.empty()) continue;
        const Path v1274_7_head{v1274_7_label};
        const Space v1275_2 = singleton(v1274_7_head);
        const Space v1275_3 = intersect(constant_8,v1275_2);
        const Space v1275_4 = (has_head(v1275_3) ? constant_9 : Space{});
        const Space v1275_5 = subtract(constant_0,v1275_4);
        Space v1275_8;
        if (!v1275_5.empty()) {
          const Path v1276_6 = concat_path(v1274_6,v1274_7_head);
          const Space v1276_7 = routine_224(c, v1276_6, p1, v1274_7_tail, s1);
          v1275_8 = compose(v1275_5,v1276_7);
        }
        const Space v1275_9 = intersect(constant_8,v1275_2);
        const Space v1275_10 = (has_head(v1275_9) ? constant_9 : Space{});
        Space v1275_12;
        if (!v1275_10.empty()) {
          const Path v1277_6 = concat_path(v1274_6,v1274_7_head);
          const Space v1277_11 = routine_225(c, v1277_6, p1, v1274_7_tail, s1);
          v1275_12 = compose(v1275_10,v1277_11);
        }
        const Space v1275_13 = unite(v1275_8,v1275_12);
        v1274_7_result = unite(v1274_7_result,v1275_13);
      }
      const Space v1274_7 = std::move(v1274_7_result);
      v1273_8 = compose(v1273_5,v1274_7);
    }
    const Space v1273_9 = intersect(constant_8,v1273_2);
    const Space v1273_10 = (has_head(v1273_9) ? constant_9 : Space{});
    Space v1273_12;
    if (!v1273_10.empty()) {
      const Path v1278_6 = concat_path(p0,v1272_13_head);
      Space v1278_11_result;
      for (int v1278_11_label = 1; v1278_11_label <= 2; ++v1278_11_label) {
        const Space v1278_11_tail = child(v1272_13_tail,v1278_11_label);
        if (v1278_11_tail.empty()) continue;
        const Path v1278_11_head{v1278_11_label};
        const Space v1279_2 = singleton(v1278_11_head);
        const Space v1279_3 = intersect(constant_8,v1279_2);
        const Space v1279_4 = (has_head(v1279_3) ? constant_9 : Space{});
        const Space v1279_5 = subtract(constant_0,v1279_4);
        Space v1279_8;
        if (!v1279_5.empty()) {
          const Path v1280_6 = concat_path(v1278_6,v1278_11_head);
          const Space v1280_7 = routine_224(c, v1280_6, p1, v1278_11_tail, s1);
          v1279_8 = compose(v1279_5,v1280_7);
        }
        const Space v1279_9 = intersect(constant_8,v1279_2);
        const Space v1279_10 = (has_head(v1279_9) ? constant_9 : Space{});
        Space v1279_12;
        if (!v1279_10.empty()) {
          const Path v1281_6 = concat_path(v1278_6,v1278_11_head);
          const Space v1281_11 = routine_133(c, v1281_6, p1, v1278_11_tail, s1);
          v1279_12 = compose(v1279_10,v1281_11);
        }
        const Space v1279_13 = unite(v1279_8,v1279_12);
        v1278_11_result = unite(v1278_11_result,v1279_13);
      }
      const Space v1278_11 = std::move(v1278_11_result);
      v1273_12 = compose(v1273_10,v1278_11);
    }
    const Space v1273_13 = unite(v1273_8,v1273_12);
    v1272_13_result = unite(v1272_13_result,v1273_13);
  }
  const Space v1272_13 = std::move(v1272_13_result);
  return v1272_13;
}

static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1282_10_result;
  for (int v1282_10_label = 1; v1282_10_label <= 2; ++v1282_10_label) {
    const Space v1282_10_tail = child(s0,v1282_10_label);
    if (v1282_10_tail.empty()) continue;
    const Path v1282_10_head{v1282_10_label};
    const Space v1283_2 = singleton(v1282_10_head);
    const Space v1283_3 = intersect(constant_8,v1283_2);
    const Space v1283_4 = (has_head(v1283_3) ? constant_9 : Space{});
    const Space v1283_5 = subtract(constant_0,v1283_4);
    Space v1283_8;
    if (!v1283_5.empty()) {
      const Path v1284_6 = concat_path(p0,v1282_10_head);
      Space v1284_7_result;
      for (int v1284_7_label = 1; v1284_7_label <= 2; ++v1284_7_label) {
        const Space v1284_7_tail = child(v1282_10_tail,v1284_7_label);
        if (v1284_7_tail.empty()) continue;
        const Path v1284_7_head{v1284_7_label};
        const Space v1285_2 = singleton(v1284_7_head);
        const Space v1285_3 = intersect(constant_8,v1285_2);
        const Space v1285_4 = (has_head(v1285_3) ? constant_9 : Space{});
        const Space v1285_5 = subtract(constant_0,v1285_4);
        Space v1285_8;
        if (!v1285_5.empty()) {
          const Path v1286_6 = concat_path(v1284_6,v1284_7_head);
          const Space v1286_7 = routine_224(c, v1286_6, p1, v1284_7_tail, s1);
          v1285_8 = compose(v1285_5,v1286_7);
        }
        const Space v1285_9 = intersect(constant_8,v1285_2);
        const Space v1285_10 = (has_head(v1285_9) ? constant_9 : Space{});
        Space v1285_12;
        if (!v1285_10.empty()) {
          const Path v1287_6 = concat_path(v1284_6,v1284_7_head);
          const Space v1287_11 = routine_225(c, v1287_6, p1, v1284_7_tail, s1);
          v1285_12 = compose(v1285_10,v1287_11);
        }
        const Space v1285_13 = unite(v1285_8,v1285_12);
        v1284_7_result = unite(v1284_7_result,v1285_13);
      }
      const Space v1284_7 = std::move(v1284_7_result);
      v1283_8 = compose(v1283_5,v1284_7);
    }
    const Space v1283_9 = intersect(constant_8,v1283_2);
    const Space v1283_10 = (has_head(v1283_9) ? constant_9 : Space{});
    const Space v1283_11 = unwrap(v1282_10_tail,p1);
    const Path v1288_6 = concat_path(p0,v1282_10_head);
    const Space v1283_12 = wrap(v1283_11,v1288_6);
    const Space v1283_13 = compose(v1283_12,s1);
    const Space v1283_14 = compose(v1283_10,v1283_13);
    const Space v1283_15 = unite(v1283_8,v1283_14);
    v1282_10_result = unite(v1282_10_result,v1283_15);
  }
  const Space v1282_10 = std::move(v1282_10_result);
  return v1282_10;
}

static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1289_4 = unwrap(s0,p1);
  const Space v1289_5 = wrap(v1289_4,p0);
  const Space v1289_6 = compose(v1289_5,s1);
  return v1289_6;
}

static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1290_7_result;
  for (int v1290_7_label = 1; v1290_7_label <= 2; ++v1290_7_label) {
    const Space v1290_7_tail = child(s0,v1290_7_label);
    if (v1290_7_tail.empty()) continue;
    const Path v1290_7_head{v1290_7_label};
    const Space v1291_2 = singleton(v1290_7_head);
    const Space v1291_3 = intersect(constant_8,v1291_2);
    const Space v1291_4 = (has_head(v1291_3) ? constant_9 : Space{});
    const Space v1291_5 = subtract(constant_0,v1291_4);
    Space v1291_6_result;
    for (int v1291_6_label = 1; v1291_6_label <= 2; ++v1291_6_label) {
      const Space v1291_6_tail = child(v1290_7_tail,v1291_6_label);
      if (v1291_6_tail.empty()) continue;
      const Path v1291_6_head{v1291_6_label};
      const Space v1292_2 = Space{};
      v1291_6_result = unite(v1291_6_result,v1292_2);
    }
    const Space v1291_6 = std::move(v1291_6_result);
    const Space v1291_7 = compose(v1291_5,v1291_6);
    const Space v1291_8 = intersect(constant_8,v1291_2);
    const Space v1291_9 = (has_head(v1291_8) ? constant_9 : Space{});
    Space v1291_12;
    if (!v1291_9.empty()) {
      const Path v1293_10 = concat_path(p0,v1290_7_head);
      Space v1293_11_result;
      for (int v1293_11_label = 1; v1293_11_label <= 2; ++v1293_11_label) {
        const Space v1293_11_tail = child(v1290_7_tail,v1293_11_label);
        if (v1293_11_tail.empty()) continue;
        const Path v1293_11_head{v1293_11_label};
        const Space v1294_2 = singleton(v1293_11_head);
        const Space v1294_3 = intersect(constant_8,v1294_2);
        const Space v1294_4 = (has_head(v1294_3) ? constant_9 : Space{});
        Space v1294_7;
        if (!v1294_4.empty()) {
          const Path v1295_5 = concat_path(v1293_10,v1293_11_head);
          const Space v1295_6 = routine_63(c, v1295_5, p1, v1293_11_tail);
          v1294_7 = compose(v1294_4,v1295_6);
        }
        v1293_11_result = unite(v1293_11_result,v1294_7);
      }
      const Space v1293_11 = std::move(v1293_11_result);
      v1291_12 = compose(v1291_9,v1293_11);
    }
    const Space v1291_13 = unite(v1291_7,v1291_12);
    v1290_7_result = unite(v1290_7_result,v1291_13);
  }
  const Space v1290_7 = std::move(v1290_7_result);
  return v1290_7;
}

static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1296_14_result;
  for (int v1296_14_label = 1; v1296_14_label <= 2; ++v1296_14_label) {
    const Space v1296_14_tail = child(s0,v1296_14_label);
    if (v1296_14_tail.empty()) continue;
    const Path v1296_14_head{v1296_14_label};
    const Space v1297_2 = singleton(v1296_14_head);
    const Space v1297_3 = intersect(constant_8,v1297_2);
    const Space v1297_4 = (has_head(v1297_3) ? constant_9 : Space{});
    const Space v1297_5 = subtract(constant_0,v1297_4);
    Space v1297_6_result;
    for (int v1297_6_label = 1; v1297_6_label <= 2; ++v1297_6_label) {
      const Space v1297_6_tail = child(v1296_14_tail,v1297_6_label);
      if (v1297_6_tail.empty()) continue;
      const Path v1297_6_head{v1297_6_label};
      const Space v1298_2 = Space{};
      v1297_6_result = unite(v1297_6_result,v1298_2);
    }
    const Space v1297_6 = std::move(v1297_6_result);
    const Space v1297_7 = compose(v1297_5,v1297_6);
    const Space v1297_8 = intersect(constant_8,v1297_2);
    const Space v1297_9 = (has_head(v1297_8) ? constant_9 : Space{});
    Space v1297_19;
    if (!v1297_9.empty()) {
      Space v1299_13;
      if (!constant_0.empty()) {
        const Space v1300_10 = routine_98(c, constant_14, constant_15);
        const Space v1300_11 = routine_99(c, constant_16, constant_17);
        const Space v1300_12 = unite(v1300_10,v1300_11);
        v1299_13 = compose(constant_0,v1300_12);
      }
      const Space v1299_14 = unwrap(v1299_13,p1);
      const Space v1299_15 = unwrap(v1299_14,p0);
      const Space v1299_16 = unwrap(v1299_15,v1296_14_head);
      const Space v1299_17 = unwrap(v1299_16,p1);
      Space v1299_18_result;
      for (int v1299_18_label = 1; v1299_18_label <= 2; ++v1299_18_label) {
        const Space v1299_18_tail = child(v1299_17,v1299_18_label);
        if (v1299_18_tail.empty()) continue;
        const Path v1299_18_head{v1299_18_label};
        const Space v1301_2 = singleton(v1299_18_head);
        const Space v1301_3 = intersect(constant_8,v1301_2);
        const Space v1301_4 = (has_head(v1301_3) ? constant_9 : Space{});
        const Space v1301_5 = subtract(constant_0,v1301_4);
        Space v1301_7;
        if (!v1301_5.empty()) {
          const Space v1302_6 = routine_100(c, v1299_18_head, v1299_18_tail, v1296_14_tail);
          v1301_7 = compose(v1301_5,v1302_6);
        }
        const Space v1301_8 = intersect(constant_8,v1301_2);
        const Space v1301_9 = (has_head(v1301_8) ? constant_9 : Space{});
        Space v1301_11;
        if (!v1301_9.empty()) {
          const Space v1303_10 = routine_101(c, v1299_18_head, v1299_18_tail, v1296_14_tail);
          v1301_11 = compose(v1301_9,v1303_10);
        }
        const Space v1301_12 = unite(v1301_7,v1301_11);
        v1299_18_result = unite(v1299_18_result,v1301_12);
      }
      const Space v1299_18 = std::move(v1299_18_result);
      v1297_19 = compose(v1297_9,v1299_18);
    }
    const Space v1297_20 = unite(v1297_7,v1297_19);
    v1296_14_result = unite(v1296_14_result,v1297_20);
  }
  const Space v1296_14 = std::move(v1296_14_result);
  return v1296_14;
}

static Space routine_136(Context& c, const Path& p0, const Space& s0) {
  Space v1304_11_result;
  for (int v1304_11_label = 1; v1304_11_label <= 2; ++v1304_11_label) {
    const Space v1304_11_tail = child(s0,v1304_11_label);
    if (v1304_11_tail.empty()) continue;
    const Path v1304_11_head{v1304_11_label};
    const Space v1305_2 = singleton(v1304_11_head);
    const Space v1305_3 = intersect(constant_8,v1305_2);
    const Space v1305_4 = (has_head(v1305_3) ? constant_9 : Space{});
    const Space v1305_5 = subtract(constant_0,v1305_4);
    Space v1305_8;
    if (!v1305_5.empty()) {
      const Path v1306_6 = concat_path(p0,v1304_11_head);
      Space v1306_7_result;
      for (int v1306_7_label = 1; v1306_7_label <= 2; ++v1306_7_label) {
        const Space v1306_7_tail = child(v1304_11_tail,v1306_7_label);
        if (v1306_7_tail.empty()) continue;
        const Path v1306_7_head{v1306_7_label};
        const Space v1307_2 = singleton(v1306_7_head);
        const Space v1307_3 = intersect(constant_8,v1307_2);
        const Space v1307_4 = (has_head(v1307_3) ? constant_9 : Space{});
        const Space v1307_5 = subtract(constant_0,v1307_4);
        Space v1307_8;
        if (!v1307_5.empty()) {
          const Path v1308_6 = concat_path(v1306_6,v1306_7_head);
          const Space v1308_7 = routine_226(c, v1308_6, v1306_7_tail);
          v1307_8 = compose(v1307_5,v1308_7);
        }
        const Space v1307_9 = intersect(constant_8,v1307_2);
        const Space v1307_10 = (has_head(v1307_9) ? constant_9 : Space{});
        Space v1307_12;
        if (!v1307_10.empty()) {
          const Path v1309_6 = concat_path(v1306_6,v1306_7_head);
          const Space v1309_11 = routine_227(c, v1309_6, v1306_7_tail);
          v1307_12 = compose(v1307_10,v1309_11);
        }
        const Space v1307_13 = unite(v1307_8,v1307_12);
        v1306_7_result = unite(v1306_7_result,v1307_13);
      }
      const Space v1306_7 = std::move(v1306_7_result);
      v1305_8 = compose(v1305_5,v1306_7);
    }
    const Space v1305_9 = intersect(constant_8,v1305_2);
    const Space v1305_10 = (has_head(v1305_9) ? constant_9 : Space{});
    Space v1305_12;
    if (!v1305_10.empty()) {
      const Path v1310_6 = concat_path(p0,v1304_11_head);
      Space v1310_11_result;
      for (int v1310_11_label = 1; v1310_11_label <= 2; ++v1310_11_label) {
        const Space v1310_11_tail = child(v1304_11_tail,v1310_11_label);
        if (v1310_11_tail.empty()) continue;
        const Path v1310_11_head{v1310_11_label};
        const Space v1311_2 = singleton(v1310_11_head);
        const Space v1311_3 = intersect(constant_8,v1311_2);
        const Space v1311_4 = (has_head(v1311_3) ? constant_9 : Space{});
        const Space v1311_5 = subtract(constant_0,v1311_4);
        Space v1311_8;
        if (!v1311_5.empty()) {
          const Path v1312_6 = concat_path(v1310_6,v1310_11_head);
          const Space v1312_7 = routine_226(c, v1312_6, v1310_11_tail);
          v1311_8 = compose(v1311_5,v1312_7);
        }
        const Space v1311_9 = intersect(constant_8,v1311_2);
        const Space v1311_10 = (has_head(v1311_9) ? constant_9 : Space{});
        Space v1311_12;
        if (!v1311_10.empty()) {
          const Path v1313_6 = concat_path(v1310_6,v1310_11_head);
          const Space v1313_11 = routine_138(c, v1313_6, v1310_11_tail);
          v1311_12 = compose(v1311_10,v1313_11);
        }
        const Space v1311_13 = unite(v1311_8,v1311_12);
        v1310_11_result = unite(v1310_11_result,v1311_13);
      }
      const Space v1310_11 = std::move(v1310_11_result);
      v1305_12 = compose(v1305_10,v1310_11);
    }
    const Space v1305_13 = unite(v1305_8,v1305_12);
    v1304_11_result = unite(v1304_11_result,v1305_13);
  }
  const Space v1304_11 = std::move(v1304_11_result);
  return v1304_11;
}

static Space routine_137(Context& c, const Path& p0, const Space& s0) {
  Space v1314_11_result;
  for (int v1314_11_label = 1; v1314_11_label <= 2; ++v1314_11_label) {
    const Space v1314_11_tail = child(s0,v1314_11_label);
    if (v1314_11_tail.empty()) continue;
    const Path v1314_11_head{v1314_11_label};
    const Space v1315_2 = singleton(v1314_11_head);
    const Space v1315_3 = intersect(constant_8,v1315_2);
    const Space v1315_4 = (has_head(v1315_3) ? constant_9 : Space{});
    const Space v1315_5 = subtract(constant_0,v1315_4);
    Space v1315_8;
    if (!v1315_5.empty()) {
      const Path v1316_6 = concat_path(p0,v1314_11_head);
      Space v1316_7_result;
      for (int v1316_7_label = 1; v1316_7_label <= 2; ++v1316_7_label) {
        const Space v1316_7_tail = child(v1314_11_tail,v1316_7_label);
        if (v1316_7_tail.empty()) continue;
        const Path v1316_7_head{v1316_7_label};
        const Space v1317_2 = singleton(v1316_7_head);
        const Space v1317_3 = intersect(constant_8,v1317_2);
        const Space v1317_4 = (has_head(v1317_3) ? constant_9 : Space{});
        const Space v1317_5 = subtract(constant_0,v1317_4);
        Space v1317_8;
        if (!v1317_5.empty()) {
          const Path v1318_6 = concat_path(v1316_6,v1316_7_head);
          const Space v1318_7 = routine_226(c, v1318_6, v1316_7_tail);
          v1317_8 = compose(v1317_5,v1318_7);
        }
        const Space v1317_9 = intersect(constant_8,v1317_2);
        const Space v1317_10 = (has_head(v1317_9) ? constant_9 : Space{});
        Space v1317_12;
        if (!v1317_10.empty()) {
          const Path v1319_6 = concat_path(v1316_6,v1316_7_head);
          const Space v1319_11 = routine_227(c, v1319_6, v1316_7_tail);
          v1317_12 = compose(v1317_10,v1319_11);
        }
        const Space v1317_13 = unite(v1317_8,v1317_12);
        v1316_7_result = unite(v1316_7_result,v1317_13);
      }
      const Space v1316_7 = std::move(v1316_7_result);
      v1315_8 = compose(v1315_5,v1316_7);
    }
    const Space v1315_9 = intersect(constant_8,v1315_2);
    const Space v1315_10 = (has_head(v1315_9) ? constant_9 : Space{});
    Space v1315_12;
    if (!v1315_10.empty()) {
      const Path v1320_6 = concat_path(p0,v1314_11_head);
      Space v1320_11_result;
      for (int v1320_11_label = 1; v1320_11_label <= 2; ++v1320_11_label) {
        const Space v1320_11_tail = child(v1314_11_tail,v1320_11_label);
        if (v1320_11_tail.empty()) continue;
        const Path v1320_11_head{v1320_11_label};
        const Space v1321_2 = singleton(v1320_11_head);
        const Space v1321_3 = intersect(constant_8,v1321_2);
        const Space v1321_4 = (has_head(v1321_3) ? constant_9 : Space{});
        const Space v1321_5 = subtract(constant_0,v1321_4);
        Space v1321_7;
        if (!v1321_5.empty()) {
          const Space v1322_6 = routine_182(c, v1320_11_head, v1320_6, v1320_11_tail);
          v1321_7 = compose(v1321_5,v1322_6);
        }
        const Space v1321_8 = intersect(constant_8,v1321_2);
        const Space v1321_9 = (has_head(v1321_8) ? constant_9 : Space{});
        Space v1321_11;
        if (!v1321_9.empty()) {
          const Space v1323_10 = routine_183(c, v1320_11_head, v1320_6, v1320_11_tail);
          v1321_11 = compose(v1321_9,v1323_10);
        }
        const Space v1321_12 = unite(v1321_7,v1321_11);
        v1320_11_result = unite(v1320_11_result,v1321_12);
      }
      const Space v1320_11 = std::move(v1320_11_result);
      v1315_12 = compose(v1315_10,v1320_11);
    }
    const Space v1315_13 = unite(v1315_8,v1315_12);
    v1314_11_result = unite(v1314_11_result,v1315_13);
  }
  const Space v1314_11 = std::move(v1314_11_result);
  return v1314_11;
}

static Space routine_138(Context& c, const Path& p0, const Space& s0) {
  Space v1324_11_result;
  for (int v1324_11_label = 1; v1324_11_label <= 2; ++v1324_11_label) {
    const Space v1324_11_tail = child(s0,v1324_11_label);
    if (v1324_11_tail.empty()) continue;
    const Path v1324_11_head{v1324_11_label};
    const Space v1325_2 = singleton(v1324_11_head);
    const Space v1325_3 = intersect(constant_8,v1325_2);
    const Space v1325_4 = (has_head(v1325_3) ? constant_9 : Space{});
    const Space v1325_5 = subtract(constant_0,v1325_4);
    Space v1325_7;
    if (!v1325_5.empty()) {
      Space v1326_6_result;
      for (int v1326_6_label = 1; v1326_6_label <= 2; ++v1326_6_label) {
        const Space v1326_6_tail = child(v1324_11_tail,v1326_6_label);
        if (v1326_6_tail.empty()) continue;
        const Path v1326_6_head{v1326_6_label};
        const Space v1327_2 = singleton(v1326_6_head);
        const Space v1327_3 = intersect(constant_8,v1327_2);
        const Space v1327_4 = (has_head(v1327_3) ? constant_9 : Space{});
        const Space v1327_5 = subtract(constant_0,v1327_4);
        Space v1327_8;
        if (!v1327_5.empty()) {
          const Path v1328_6 = concat_path(v1324_11_head,v1326_6_head);
          const Space v1328_7 = routine_228(c, v1328_6, p0, v1326_6_tail);
          v1327_8 = compose(v1327_5,v1328_7);
        }
        const Space v1327_9 = intersect(constant_8,v1327_2);
        const Space v1327_10 = (has_head(v1327_9) ? constant_9 : Space{});
        Space v1327_12;
        if (!v1327_10.empty()) {
          const Path v1329_6 = concat_path(v1324_11_head,v1326_6_head);
          const Space v1329_11 = routine_229(c, v1329_6, p0, v1326_6_tail);
          v1327_12 = compose(v1327_10,v1329_11);
        }
        const Space v1327_13 = unite(v1327_8,v1327_12);
        v1326_6_result = unite(v1326_6_result,v1327_13);
      }
      const Space v1326_6 = std::move(v1326_6_result);
      v1325_7 = compose(v1325_5,v1326_6);
    }
    const Space v1325_8 = intersect(constant_8,v1325_2);
    const Space v1325_9 = (has_head(v1325_8) ? constant_9 : Space{});
    Space v1325_11;
    if (!v1325_9.empty()) {
      Space v1330_10_result;
      for (int v1330_10_label = 1; v1330_10_label <= 2; ++v1330_10_label) {
        const Space v1330_10_tail = child(v1324_11_tail,v1330_10_label);
        if (v1330_10_tail.empty()) continue;
        const Path v1330_10_head{v1330_10_label};
        const Space v1331_2 = singleton(v1330_10_head);
        const Space v1331_3 = intersect(constant_8,v1331_2);
        const Space v1331_4 = (has_head(v1331_3) ? constant_9 : Space{});
        const Space v1331_5 = subtract(constant_0,v1331_4);
        Space v1331_8;
        if (!v1331_5.empty()) {
          const Path v1332_6 = concat_path(v1324_11_head,v1330_10_head);
          const Space v1332_7 = routine_228(c, v1332_6, p0, v1330_10_tail);
          v1331_8 = compose(v1331_5,v1332_7);
        }
        const Space v1331_9 = intersect(constant_8,v1331_2);
        const Space v1331_10 = (has_head(v1331_9) ? constant_9 : Space{});
        Space v1331_12;
        if (!v1331_10.empty()) {
          const Path v1333_6 = concat_path(v1324_11_head,v1330_10_head);
          const Space v1333_11 = routine_230(c, v1333_6, p0, v1330_10_tail);
          v1331_12 = compose(v1331_10,v1333_11);
        }
        const Space v1331_13 = unite(v1331_8,v1331_12);
        v1330_10_result = unite(v1330_10_result,v1331_13);
      }
      const Space v1330_10 = std::move(v1330_10_result);
      v1325_11 = compose(v1325_9,v1330_10);
    }
    const Space v1325_12 = unite(v1325_7,v1325_11);
    v1324_11_result = unite(v1324_11_result,v1325_12);
  }
  const Space v1324_11 = std::move(v1324_11_result);
  return v1324_11;
}

static Space routine_139(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1334_12_result;
  for (int v1334_12_label = 1; v1334_12_label <= 2; ++v1334_12_label) {
    const Space v1334_12_tail = child(s0,v1334_12_label);
    if (v1334_12_tail.empty()) continue;
    const Path v1334_12_head{v1334_12_label};
    const Space v1335_2 = singleton(v1334_12_head);
    const Space v1335_3 = intersect(constant_8,v1335_2);
    const Space v1335_4 = (has_head(v1335_3) ? constant_9 : Space{});
    const Space v1335_5 = subtract(constant_0,v1335_4);
    Space v1335_8;
    if (!v1335_5.empty()) {
      const Path v1336_6 = concat_path(p0,v1334_12_head);
      Space v1336_7_result;
      for (int v1336_7_label = 1; v1336_7_label <= 2; ++v1336_7_label) {
        const Space v1336_7_tail = child(v1334_12_tail,v1336_7_label);
        if (v1336_7_tail.empty()) continue;
        const Path v1336_7_head{v1336_7_label};
        const Space v1337_2 = singleton(v1336_7_head);
        const Space v1337_3 = intersect(constant_8,v1337_2);
        const Space v1337_4 = (has_head(v1337_3) ? constant_9 : Space{});
        const Space v1337_5 = subtract(constant_0,v1337_4);
        Space v1337_8;
        if (!v1337_5.empty()) {
          const Path v1338_6 = concat_path(v1336_6,v1336_7_head);
          const Space v1338_7 = routine_231(c, v1338_6, v1336_7_tail, s1);
          v1337_8 = compose(v1337_5,v1338_7);
        }
        const Space v1337_9 = intersect(constant_8,v1337_2);
        const Space v1337_10 = (has_head(v1337_9) ? constant_9 : Space{});
        Space v1337_12;
        if (!v1337_10.empty()) {
          const Path v1339_6 = concat_path(v1336_6,v1336_7_head);
          const Space v1339_11 = routine_232(c, v1339_6, v1336_7_tail, s1);
          v1337_12 = compose(v1337_10,v1339_11);
        }
        const Space v1337_13 = unite(v1337_8,v1337_12);
        v1336_7_result = unite(v1336_7_result,v1337_13);
      }
      const Space v1336_7 = std::move(v1336_7_result);
      v1335_8 = compose(v1335_5,v1336_7);
    }
    const Space v1335_9 = intersect(constant_8,v1335_2);
    const Space v1335_10 = (has_head(v1335_9) ? constant_9 : Space{});
    Space v1335_12;
    if (!v1335_10.empty()) {
      const Path v1340_6 = concat_path(p0,v1334_12_head);
      Space v1340_11_result;
      for (int v1340_11_label = 1; v1340_11_label <= 2; ++v1340_11_label) {
        const Space v1340_11_tail = child(v1334_12_tail,v1340_11_label);
        if (v1340_11_tail.empty()) continue;
        const Path v1340_11_head{v1340_11_label};
        const Space v1341_2 = singleton(v1340_11_head);
        const Space v1341_3 = intersect(constant_8,v1341_2);
        const Space v1341_4 = (has_head(v1341_3) ? constant_9 : Space{});
        const Space v1341_5 = subtract(constant_0,v1341_4);
        Space v1341_8;
        if (!v1341_5.empty()) {
          const Path v1342_6 = concat_path(v1340_6,v1340_11_head);
          const Space v1342_7 = routine_231(c, v1342_6, v1340_11_tail, s1);
          v1341_8 = compose(v1341_5,v1342_7);
        }
        const Space v1341_9 = intersect(constant_8,v1341_2);
        const Space v1341_10 = (has_head(v1341_9) ? constant_9 : Space{});
        Space v1341_12;
        if (!v1341_10.empty()) {
          const Path v1343_6 = concat_path(v1340_6,v1340_11_head);
          const Space v1343_11 = routine_141(c, v1343_6, v1340_11_tail, s1);
          v1341_12 = compose(v1341_10,v1343_11);
        }
        const Space v1341_13 = unite(v1341_8,v1341_12);
        v1340_11_result = unite(v1340_11_result,v1341_13);
      }
      const Space v1340_11 = std::move(v1340_11_result);
      v1335_12 = compose(v1335_10,v1340_11);
    }
    const Space v1335_13 = unite(v1335_8,v1335_12);
    v1334_12_result = unite(v1334_12_result,v1335_13);
  }
  const Space v1334_12 = std::move(v1334_12_result);
  return v1334_12;
}

static Space routine_140(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1344_9_result;
  for (int v1344_9_label = 1; v1344_9_label <= 2; ++v1344_9_label) {
    const Space v1344_9_tail = child(s0,v1344_9_label);
    if (v1344_9_tail.empty()) continue;
    const Path v1344_9_head{v1344_9_label};
    const Space v1345_2 = singleton(v1344_9_head);
    const Space v1345_3 = intersect(constant_8,v1345_2);
    const Space v1345_4 = (has_head(v1345_3) ? constant_9 : Space{});
    const Space v1345_5 = subtract(constant_0,v1345_4);
    Space v1345_8;
    if (!v1345_5.empty()) {
      const Path v1346_6 = concat_path(p0,v1344_9_head);
      Space v1346_7_result;
      for (int v1346_7_label = 1; v1346_7_label <= 2; ++v1346_7_label) {
        const Space v1346_7_tail = child(v1344_9_tail,v1346_7_label);
        if (v1346_7_tail.empty()) continue;
        const Path v1346_7_head{v1346_7_label};
        const Space v1347_2 = singleton(v1346_7_head);
        const Space v1347_3 = intersect(constant_8,v1347_2);
        const Space v1347_4 = (has_head(v1347_3) ? constant_9 : Space{});
        const Space v1347_5 = subtract(constant_0,v1347_4);
        Space v1347_8;
        if (!v1347_5.empty()) {
          const Path v1348_6 = concat_path(v1346_6,v1346_7_head);
          const Space v1348_7 = routine_231(c, v1348_6, v1346_7_tail, s1);
          v1347_8 = compose(v1347_5,v1348_7);
        }
        const Space v1347_9 = intersect(constant_8,v1347_2);
        const Space v1347_10 = (has_head(v1347_9) ? constant_9 : Space{});
        Space v1347_12;
        if (!v1347_10.empty()) {
          const Path v1349_6 = concat_path(v1346_6,v1346_7_head);
          const Space v1349_11 = routine_232(c, v1349_6, v1346_7_tail, s1);
          v1347_12 = compose(v1347_10,v1349_11);
        }
        const Space v1347_13 = unite(v1347_8,v1347_12);
        v1346_7_result = unite(v1346_7_result,v1347_13);
      }
      const Space v1346_7 = std::move(v1346_7_result);
      v1345_8 = compose(v1345_5,v1346_7);
    }
    const Space v1345_9 = intersect(constant_8,v1345_2);
    const Space v1345_10 = (has_head(v1345_9) ? constant_9 : Space{});
    Space v1345_12;
    if (!v1345_10.empty()) {
      const Path v1350_6 = concat_path(p0,v1344_9_head);
      const Space v1350_11 = routine_186(c, v1350_6, s1);
      v1345_12 = compose(v1345_10,v1350_11);
    }
    const Space v1345_13 = unite(v1345_8,v1345_12);
    v1344_9_result = unite(v1344_9_result,v1345_13);
  }
  const Space v1344_9 = std::move(v1344_9_result);
  return v1344_9;
}

static Space routine_141(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v1351_4 = singleton(p0);
  const Space v1351_5 = intersect(constant_10,v1351_4);
  const Space v1351_7 = unwrap(s1,constant_22);
  const Space v1351_9 = unwrap(s1,constant_23);
  const Space v1351_10 = compose(v1351_7,v1351_9);
  const Space v1351_12 = unwrap(s1,constant_6);
  const Space v1351_13 = compose(v1351_10,v1351_12);
  const Space v1351_14 = compose(v1351_5,v1351_13);
  const Space v1351_16 = intersect(constant_11,v1351_4);
  const Space v1351_17 = compose(v1351_7,v1351_12);
  const Space v1351_19 = unwrap(s1,constant_24);
  const Space v1351_20 = compose(v1351_17,v1351_19);
  const Space v1351_21 = compose(v1351_16,v1351_20);
  const Space v1351_22 = unite(v1351_14,v1351_21);
  const Space v1351_24 = intersect(constant_12,v1351_4);
  const Space v1351_25 = compose(v1351_9,v1351_12);
  const Space v1351_26 = compose(v1351_25,v1351_19);
  const Space v1351_27 = compose(v1351_24,v1351_26);
  const Space v1351_28 = unite(v1351_22,v1351_27);
  const Space v1351_30 = intersect(constant_13,v1351_4);
  const Space v1351_31 = compose(v1351_10,v1351_19);
  const Space v1351_32 = compose(v1351_30,v1351_31);
  const Space v1351_33 = unite(v1351_28,v1351_32);
  return v1351_33;
}

static Space routine_142(Context& c, const Path& p0, const Space& s0) {
  Space v1352_6_result;
  for (int v1352_6_label = 1; v1352_6_label <= 2; ++v1352_6_label) {
    const Space v1352_6_tail = child(s0,v1352_6_label);
    if (v1352_6_tail.empty()) continue;
    const Path v1352_6_head{v1352_6_label};
    const Space v1353_2 = singleton(v1352_6_head);
    const Space v1353_3 = intersect(constant_8,v1353_2);
    const Space v1353_4 = (has_head(v1353_3) ? constant_9 : Space{});
    const Space v1353_5 = subtract(constant_0,v1353_4);
    Space v1353_6_result;
    for (int v1353_6_label = 1; v1353_6_label <= 2; ++v1353_6_label) {
      const Space v1353_6_tail = child(v1352_6_tail,v1353_6_label);
      if (v1353_6_tail.empty()) continue;
      const Path v1353_6_head{v1353_6_label};
      const Space v1354_2 = Space{};
      v1353_6_result = unite(v1353_6_result,v1354_2);
    }
    const Space v1353_6 = std::move(v1353_6_result);
    const Space v1353_7 = compose(v1353_5,v1353_6);
    const Space v1353_8 = intersect(constant_8,v1353_2);
    const Space v1353_9 = (has_head(v1353_8) ? constant_9 : Space{});
    Space v1353_12;
    if (!v1353_9.empty()) {
      const Path v1355_10 = concat_path(p0,v1352_6_head);
      Space v1355_11_result;
      for (int v1355_11_label = 1; v1355_11_label <= 2; ++v1355_11_label) {
        const Space v1355_11_tail = child(v1352_6_tail,v1355_11_label);
        if (v1355_11_tail.empty()) continue;
        const Path v1355_11_head{v1355_11_label};
        const Space v1356_2 = singleton(v1355_11_head);
        const Space v1356_3 = intersect(constant_8,v1356_2);
        const Space v1356_4 = (has_head(v1356_3) ? constant_9 : Space{});
        Space v1356_7;
        if (!v1356_4.empty()) {
          const Path v1357_5 = concat_path(v1355_10,v1355_11_head);
          const Space v1357_6 = routine_68(c, v1357_5, v1355_11_tail);
          v1356_7 = compose(v1356_4,v1357_6);
        }
        v1355_11_result = unite(v1355_11_result,v1356_7);
      }
      const Space v1355_11 = std::move(v1355_11_result);
      v1353_12 = compose(v1353_9,v1355_11);
    }
    const Space v1353_13 = unite(v1353_7,v1353_12);
    v1352_6_result = unite(v1352_6_result,v1353_13);
  }
  const Space v1352_6 = std::move(v1352_6_result);
  return v1352_6;
}

static Space routine_143(Context& c, const Path& p0, const Space& s0) {
  Space v1358_5_result;
  for (int v1358_5_label = 1; v1358_5_label <= 2; ++v1358_5_label) {
    const Space v1358_5_tail = child(s0,v1358_5_label);
    if (v1358_5_tail.empty()) continue;
    const Path v1358_5_head{v1358_5_label};
    const Space v1359_2 = singleton(v1358_5_head);
    const Space v1359_3 = intersect(constant_8,v1359_2);
    const Space v1359_4 = (has_head(v1359_3) ? constant_9 : Space{});
    const Space v1359_5 = subtract(constant_0,v1359_4);
    Space v1359_6_result;
    for (int v1359_6_label = 1; v1359_6_label <= 2; ++v1359_6_label) {
      const Space v1359_6_tail = child(v1358_5_tail,v1359_6_label);
      if (v1359_6_tail.empty()) continue;
      const Path v1359_6_head{v1359_6_label};
      const Space v1360_2 = Space{};
      v1359_6_result = unite(v1359_6_result,v1360_2);
    }
    const Space v1359_6 = std::move(v1359_6_result);
    const Space v1359_7 = compose(v1359_5,v1359_6);
    const Space v1359_8 = intersect(constant_8,v1359_2);
    const Space v1359_9 = (has_head(v1359_8) ? constant_9 : Space{});
    const Space v1359_10 = compose(v1359_9,v1358_5_tail);
    const Space v1359_11 = unite(v1359_7,v1359_10);
    v1358_5_result = unite(v1358_5_result,v1359_11);
  }
  const Space v1358_5 = std::move(v1358_5_result);
  return v1358_5;
}

static Space routine_144(Context& c, const Path& p0, const Space& s0) {
  Space v1361_6_result;
  for (int v1361_6_label = 1; v1361_6_label <= 2; ++v1361_6_label) {
    const Space v1361_6_tail = child(s0,v1361_6_label);
    if (v1361_6_tail.empty()) continue;
    const Path v1361_6_head{v1361_6_label};
    const Space v1362_2 = singleton(v1361_6_head);
    const Space v1362_3 = intersect(constant_8,v1362_2);
    const Space v1362_4 = (has_head(v1362_3) ? constant_9 : Space{});
    const Space v1362_5 = subtract(constant_0,v1362_4);
    Space v1362_6_result;
    for (int v1362_6_label = 1; v1362_6_label <= 2; ++v1362_6_label) {
      const Space v1362_6_tail = child(v1361_6_tail,v1362_6_label);
      if (v1362_6_tail.empty()) continue;
      const Path v1362_6_head{v1362_6_label};
      const Space v1363_2 = Space{};
      v1362_6_result = unite(v1362_6_result,v1363_2);
    }
    const Space v1362_6 = std::move(v1362_6_result);
    const Space v1362_7 = compose(v1362_5,v1362_6);
    const Space v1362_8 = intersect(constant_8,v1362_2);
    const Space v1362_9 = (has_head(v1362_8) ? constant_9 : Space{});
    Space v1362_12;
    if (!v1362_9.empty()) {
      const Path v1364_10 = concat_path(p0,v1361_6_head);
      Space v1364_11_result;
      for (int v1364_11_label = 1; v1364_11_label <= 2; ++v1364_11_label) {
        const Space v1364_11_tail = child(v1361_6_tail,v1364_11_label);
        if (v1364_11_tail.empty()) continue;
        const Path v1364_11_head{v1364_11_label};
        const Space v1365_2 = singleton(v1364_11_head);
        const Space v1365_3 = intersect(constant_8,v1365_2);
        const Space v1365_4 = (has_head(v1365_3) ? constant_9 : Space{});
        Space v1365_7;
        if (!v1365_4.empty()) {
          const Path v1366_5 = concat_path(v1364_10,v1364_11_head);
          const Space v1366_6 = routine_71(c, v1366_5, v1364_11_tail);
          v1365_7 = compose(v1365_4,v1366_6);
        }
        v1364_11_result = unite(v1364_11_result,v1365_7);
      }
      const Space v1364_11 = std::move(v1364_11_result);
      v1362_12 = compose(v1362_9,v1364_11);
    }
    const Space v1362_13 = unite(v1362_7,v1362_12);
    v1361_6_result = unite(v1361_6_result,v1362_13);
  }
  const Space v1361_6 = std::move(v1361_6_result);
  return v1361_6;
}

static Space routine_145(Context& c, const Path& p0, const Space& s0) {
  Space v1367_8_result;
  for (int v1367_8_label = 1; v1367_8_label <= 2; ++v1367_8_label) {
    const Space v1367_8_tail = child(s0,v1367_8_label);
    if (v1367_8_tail.empty()) continue;
    const Path v1367_8_head{v1367_8_label};
    const Space v1368_2 = singleton(v1367_8_head);
    const Space v1368_3 = intersect(constant_8,v1368_2);
    const Space v1368_4 = (has_head(v1368_3) ? constant_9 : Space{});
    const Space v1368_5 = subtract(constant_0,v1368_4);
    Space v1368_6_result;
    for (int v1368_6_label = 1; v1368_6_label <= 2; ++v1368_6_label) {
      const Space v1368_6_tail = child(v1367_8_tail,v1368_6_label);
      if (v1368_6_tail.empty()) continue;
      const Path v1368_6_head{v1368_6_label};
      const Space v1369_2 = Space{};
      v1368_6_result = unite(v1368_6_result,v1369_2);
    }
    const Space v1368_6 = std::move(v1368_6_result);
    const Space v1368_7 = compose(v1368_5,v1368_6);
    const Space v1368_8 = intersect(constant_8,v1368_2);
    const Space v1368_9 = (has_head(v1368_8) ? constant_9 : Space{});
    Space v1368_12;
    if (!v1368_9.empty()) {
      const Path v1370_10 = concat_path(p0,v1367_8_head);
      Space v1370_11_result;
      for (int v1370_11_label = 1; v1370_11_label <= 2; ++v1370_11_label) {
        const Space v1370_11_tail = child(v1367_8_tail,v1370_11_label);
        if (v1370_11_tail.empty()) continue;
        const Path v1370_11_head{v1370_11_label};
        const Space v1371_2 = singleton(v1370_11_head);
        const Space v1371_3 = intersect(constant_8,v1371_2);
        const Space v1371_4 = (has_head(v1371_3) ? constant_9 : Space{});
        const Space v1371_5 = subtract(constant_0,v1371_4);
        Space v1371_7;
        if (!v1371_5.empty()) {
          const Space v1372_6 = routine_106(c, v1370_11_head, v1370_10, v1370_11_tail);
          v1371_7 = compose(v1371_5,v1372_6);
        }
        const Space v1371_8 = intersect(constant_8,v1371_2);
        const Space v1371_9 = (has_head(v1371_8) ? constant_9 : Space{});
        Space v1371_11;
        if (!v1371_9.empty()) {
          const Space v1373_10 = routine_107(c, v1370_11_head, v1370_10, v1370_11_tail);
          v1371_11 = compose(v1371_9,v1373_10);
        }
        const Space v1371_12 = unite(v1371_7,v1371_11);
        v1370_11_result = unite(v1370_11_result,v1371_12);
      }
      const Space v1370_11 = std::move(v1370_11_result);
      v1368_12 = compose(v1368_9,v1370_11);
    }
    const Space v1368_13 = unite(v1368_7,v1368_12);
    v1367_8_result = unite(v1367_8_result,v1368_13);
  }
  const Space v1367_8 = std::move(v1367_8_result);
  return v1367_8;
}

static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1374_12_result;
  for (int v1374_12_label = 1; v1374_12_label <= 2; ++v1374_12_label) {
    const Space v1374_12_tail = child(s0,v1374_12_label);
    if (v1374_12_tail.empty()) continue;
    const Path v1374_12_head{v1374_12_label};
    const Space v1375_2 = singleton(v1374_12_head);
    const Space v1375_3 = intersect(constant_8,v1375_2);
    const Space v1375_4 = (has_head(v1375_3) ? constant_9 : Space{});
    const Space v1375_5 = subtract(constant_0,v1375_4);
    Space v1375_8;
    if (!v1375_5.empty()) {
      const Path v1376_6 = concat_path(p0,v1374_12_head);
      Space v1376_7_result;
      for (int v1376_7_label = 1; v1376_7_label <= 2; ++v1376_7_label) {
        const Space v1376_7_tail = child(v1374_12_tail,v1376_7_label);
        if (v1376_7_tail.empty()) continue;
        const Path v1376_7_head{v1376_7_label};
        const Space v1377_2 = singleton(v1376_7_head);
        const Space v1377_3 = intersect(constant_8,v1377_2);
        const Space v1377_4 = (has_head(v1377_3) ? constant_9 : Space{});
        const Space v1377_5 = subtract(constant_0,v1377_4);
        Space v1377_8;
        if (!v1377_5.empty()) {
          const Path v1378_6 = concat_path(v1376_6,v1376_7_head);
          const Space v1378_7 = routine_233(c, v1378_6, p1, v1376_7_tail);
          v1377_8 = compose(v1377_5,v1378_7);
        }
        const Space v1377_9 = intersect(constant_8,v1377_2);
        const Space v1377_10 = (has_head(v1377_9) ? constant_9 : Space{});
        Space v1377_12;
        if (!v1377_10.empty()) {
          const Path v1379_6 = concat_path(v1376_6,v1376_7_head);
          const Space v1379_11 = routine_234(c, v1379_6, p1, v1376_7_tail);
          v1377_12 = compose(v1377_10,v1379_11);
        }
        const Space v1377_13 = unite(v1377_8,v1377_12);
        v1376_7_result = unite(v1376_7_result,v1377_13);
      }
      const Space v1376_7 = std::move(v1376_7_result);
      v1375_8 = compose(v1375_5,v1376_7);
    }
    const Space v1375_9 = intersect(constant_8,v1375_2);
    const Space v1375_10 = (has_head(v1375_9) ? constant_9 : Space{});
    Space v1375_12;
    if (!v1375_10.empty()) {
      const Path v1380_6 = concat_path(p0,v1374_12_head);
      Space v1380_11_result;
      for (int v1380_11_label = 1; v1380_11_label <= 2; ++v1380_11_label) {
        const Space v1380_11_tail = child(v1374_12_tail,v1380_11_label);
        if (v1380_11_tail.empty()) continue;
        const Path v1380_11_head{v1380_11_label};
        const Space v1381_2 = singleton(v1380_11_head);
        const Space v1381_3 = intersect(constant_8,v1381_2);
        const Space v1381_4 = (has_head(v1381_3) ? constant_9 : Space{});
        const Space v1381_5 = subtract(constant_0,v1381_4);
        Space v1381_8;
        if (!v1381_5.empty()) {
          const Path v1382_6 = concat_path(v1380_6,v1380_11_head);
          const Space v1382_7 = routine_233(c, v1382_6, p1, v1380_11_tail);
          v1381_8 = compose(v1381_5,v1382_7);
        }
        const Space v1381_9 = intersect(constant_8,v1381_2);
        const Space v1381_10 = (has_head(v1381_9) ? constant_9 : Space{});
        Space v1381_12;
        if (!v1381_10.empty()) {
          const Path v1383_6 = concat_path(v1380_6,v1380_11_head);
          const Space v1383_11 = routine_148(c, v1383_6, p1, v1380_11_tail);
          v1381_12 = compose(v1381_10,v1383_11);
        }
        const Space v1381_13 = unite(v1381_8,v1381_12);
        v1380_11_result = unite(v1380_11_result,v1381_13);
      }
      const Space v1380_11 = std::move(v1380_11_result);
      v1375_12 = compose(v1375_10,v1380_11);
    }
    const Space v1375_13 = unite(v1375_8,v1375_12);
    v1374_12_result = unite(v1374_12_result,v1375_13);
  }
  const Space v1374_12 = std::move(v1374_12_result);
  return v1374_12;
}

static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1384_12_result;
  for (int v1384_12_label = 1; v1384_12_label <= 2; ++v1384_12_label) {
    const Space v1384_12_tail = child(s0,v1384_12_label);
    if (v1384_12_tail.empty()) continue;
    const Path v1384_12_head{v1384_12_label};
    const Space v1385_2 = singleton(v1384_12_head);
    const Space v1385_3 = intersect(constant_8,v1385_2);
    const Space v1385_4 = (has_head(v1385_3) ? constant_9 : Space{});
    const Space v1385_5 = subtract(constant_0,v1385_4);
    Space v1385_8;
    if (!v1385_5.empty()) {
      const Path v1386_6 = concat_path(p0,v1384_12_head);
      Space v1386_7_result;
      for (int v1386_7_label = 1; v1386_7_label <= 2; ++v1386_7_label) {
        const Space v1386_7_tail = child(v1384_12_tail,v1386_7_label);
        if (v1386_7_tail.empty()) continue;
        const Path v1386_7_head{v1386_7_label};
        const Space v1387_2 = singleton(v1386_7_head);
        const Space v1387_3 = intersect(constant_8,v1387_2);
        const Space v1387_4 = (has_head(v1387_3) ? constant_9 : Space{});
        const Space v1387_5 = subtract(constant_0,v1387_4);
        Space v1387_8;
        if (!v1387_5.empty()) {
          const Path v1388_6 = concat_path(v1386_6,v1386_7_head);
          const Space v1388_7 = routine_233(c, v1388_6, p1, v1386_7_tail);
          v1387_8 = compose(v1387_5,v1388_7);
        }
        const Space v1387_9 = intersect(constant_8,v1387_2);
        const Space v1387_10 = (has_head(v1387_9) ? constant_9 : Space{});
        Space v1387_12;
        if (!v1387_10.empty()) {
          const Path v1389_6 = concat_path(v1386_6,v1386_7_head);
          const Space v1389_11 = routine_234(c, v1389_6, p1, v1386_7_tail);
          v1387_12 = compose(v1387_10,v1389_11);
        }
        const Space v1387_13 = unite(v1387_8,v1387_12);
        v1386_7_result = unite(v1386_7_result,v1387_13);
      }
      const Space v1386_7 = std::move(v1386_7_result);
      v1385_8 = compose(v1385_5,v1386_7);
    }
    const Space v1385_9 = intersect(constant_8,v1385_2);
    const Space v1385_10 = (has_head(v1385_9) ? constant_9 : Space{});
    Space v1385_12;
    if (!v1385_10.empty()) {
      const Path v1390_6 = concat_path(p0,v1384_12_head);
      Space v1390_11_result;
      for (int v1390_11_label = 1; v1390_11_label <= 2; ++v1390_11_label) {
        const Space v1390_11_tail = child(v1384_12_tail,v1390_11_label);
        if (v1390_11_tail.empty()) continue;
        const Path v1390_11_head{v1390_11_label};
        const Space v1391_2 = singleton(v1390_11_head);
        const Space v1391_3 = intersect(constant_8,v1391_2);
        const Space v1391_4 = (has_head(v1391_3) ? constant_9 : Space{});
        const Space v1391_5 = subtract(constant_0,v1391_4);
        Space v1391_7;
        if (!v1391_5.empty()) {
          const Space v1392_6 = routine_193(c, v1390_11_head, p1, v1390_6, v1390_11_tail);
          v1391_7 = compose(v1391_5,v1392_6);
        }
        const Space v1391_8 = intersect(constant_8,v1391_2);
        const Space v1391_9 = (has_head(v1391_8) ? constant_9 : Space{});
        Space v1391_11;
        if (!v1391_9.empty()) {
          const Space v1393_10 = routine_194(c, v1390_11_head, p1, v1390_6, v1390_11_tail);
          v1391_11 = compose(v1391_9,v1393_10);
        }
        const Space v1391_12 = unite(v1391_7,v1391_11);
        v1390_11_result = unite(v1390_11_result,v1391_12);
      }
      const Space v1390_11 = std::move(v1390_11_result);
      v1385_12 = compose(v1385_10,v1390_11);
    }
    const Space v1385_13 = unite(v1385_8,v1385_12);
    v1384_12_result = unite(v1384_12_result,v1385_13);
  }
  const Space v1384_12 = std::move(v1384_12_result);
  return v1384_12;
}

static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1394_12_result;
  for (int v1394_12_label = 1; v1394_12_label <= 2; ++v1394_12_label) {
    const Space v1394_12_tail = child(s0,v1394_12_label);
    if (v1394_12_tail.empty()) continue;
    const Path v1394_12_head{v1394_12_label};
    const Space v1395_2 = singleton(v1394_12_head);
    const Space v1395_3 = intersect(constant_8,v1395_2);
    const Space v1395_4 = (has_head(v1395_3) ? constant_9 : Space{});
    const Space v1395_5 = subtract(constant_0,v1395_4);
    Space v1395_7;
    if (!v1395_5.empty()) {
      Space v1396_6_result;
      for (int v1396_6_label = 1; v1396_6_label <= 2; ++v1396_6_label) {
        const Space v1396_6_tail = child(v1394_12_tail,v1396_6_label);
        if (v1396_6_tail.empty()) continue;
        const Path v1396_6_head{v1396_6_label};
        const Space v1397_2 = singleton(v1396_6_head);
        const Space v1397_3 = intersect(constant_8,v1397_2);
        const Space v1397_4 = (has_head(v1397_3) ? constant_9 : Space{});
        const Space v1397_5 = subtract(constant_0,v1397_4);
        Space v1397_8;
        if (!v1397_5.empty()) {
          const Path v1398_6 = concat_path(v1394_12_head,v1396_6_head);
          const Space v1398_7 = routine_235(c, v1398_6, p1, p0, v1396_6_tail);
          v1397_8 = compose(v1397_5,v1398_7);
        }
        const Space v1397_9 = intersect(constant_8,v1397_2);
        const Space v1397_10 = (has_head(v1397_9) ? constant_9 : Space{});
        Space v1397_12;
        if (!v1397_10.empty()) {
          const Path v1399_6 = concat_path(v1394_12_head,v1396_6_head);
          const Space v1399_11 = routine_236(c, v1399_6, p1, p0, v1396_6_tail);
          v1397_12 = compose(v1397_10,v1399_11);
        }
        const Space v1397_13 = unite(v1397_8,v1397_12);
        v1396_6_result = unite(v1396_6_result,v1397_13);
      }
      const Space v1396_6 = std::move(v1396_6_result);
      v1395_7 = compose(v1395_5,v1396_6);
    }
    const Space v1395_8 = intersect(constant_8,v1395_2);
    const Space v1395_9 = (has_head(v1395_8) ? constant_9 : Space{});
    Space v1395_11;
    if (!v1395_9.empty()) {
      Space v1400_10_result;
      for (int v1400_10_label = 1; v1400_10_label <= 2; ++v1400_10_label) {
        const Space v1400_10_tail = child(v1394_12_tail,v1400_10_label);
        if (v1400_10_tail.empty()) continue;
        const Path v1400_10_head{v1400_10_label};
        const Space v1401_2 = singleton(v1400_10_head);
        const Space v1401_3 = intersect(constant_8,v1401_2);
        const Space v1401_4 = (has_head(v1401_3) ? constant_9 : Space{});
        const Space v1401_5 = subtract(constant_0,v1401_4);
        Space v1401_8;
        if (!v1401_5.empty()) {
          const Path v1402_6 = concat_path(v1394_12_head,v1400_10_head);
          const Space v1402_7 = routine_235(c, v1402_6, p1, p0, v1400_10_tail);
          v1401_8 = compose(v1401_5,v1402_7);
        }
        const Space v1401_9 = intersect(constant_8,v1401_2);
        const Space v1401_10 = (has_head(v1401_9) ? constant_9 : Space{});
        Space v1401_12;
        if (!v1401_10.empty()) {
          const Path v1403_6 = concat_path(v1394_12_head,v1400_10_head);
          const Space v1403_11 = routine_237(c, v1403_6, p1, p0, v1400_10_tail);
          v1401_12 = compose(v1401_10,v1403_11);
        }
        const Space v1401_13 = unite(v1401_8,v1401_12);
        v1400_10_result = unite(v1400_10_result,v1401_13);
      }
      const Space v1400_10 = std::move(v1400_10_result);
      v1395_11 = compose(v1395_9,v1400_10);
    }
    const Space v1395_12 = unite(v1395_7,v1395_11);
    v1394_12_result = unite(v1394_12_result,v1395_12);
  }
  const Space v1394_12 = std::move(v1394_12_result);
  return v1394_12;
}

static Space routine_149(Context& c, const Path& p0, const Space& s0) {
  Space v1404_6_result;
  for (int v1404_6_label = 1; v1404_6_label <= 2; ++v1404_6_label) {
    const Space v1404_6_tail = child(s0,v1404_6_label);
    if (v1404_6_tail.empty()) continue;
    const Path v1404_6_head{v1404_6_label};
    const Space v1405_2 = singleton(v1404_6_head);
    const Space v1405_3 = intersect(constant_8,v1405_2);
    const Space v1405_4 = (has_head(v1405_3) ? constant_9 : Space{});
    const Space v1405_5 = subtract(constant_0,v1405_4);
    Space v1405_6_result;
    for (int v1405_6_label = 1; v1405_6_label <= 2; ++v1405_6_label) {
      const Space v1405_6_tail = child(v1404_6_tail,v1405_6_label);
      if (v1405_6_tail.empty()) continue;
      const Path v1405_6_head{v1405_6_label};
      const Space v1406_2 = Space{};
      v1405_6_result = unite(v1405_6_result,v1406_2);
    }
    const Space v1405_6 = std::move(v1405_6_result);
    const Space v1405_7 = compose(v1405_5,v1405_6);
    const Space v1405_8 = intersect(constant_8,v1405_2);
    const Space v1405_9 = (has_head(v1405_8) ? constant_9 : Space{});
    Space v1405_12;
    if (!v1405_9.empty()) {
      const Path v1407_10 = concat_path(p0,v1404_6_head);
      Space v1407_11_result;
      for (int v1407_11_label = 1; v1407_11_label <= 2; ++v1407_11_label) {
        const Space v1407_11_tail = child(v1404_6_tail,v1407_11_label);
        if (v1407_11_tail.empty()) continue;
        const Path v1407_11_head{v1407_11_label};
        const Space v1408_2 = singleton(v1407_11_head);
        const Space v1408_3 = intersect(constant_8,v1408_2);
        const Space v1408_4 = (has_head(v1408_3) ? constant_9 : Space{});
        Space v1408_7;
        if (!v1408_4.empty()) {
          const Path v1409_5 = concat_path(v1407_10,v1407_11_head);
          const Space v1409_6 = routine_74(c, v1409_5, v1407_11_tail);
          v1408_7 = compose(v1408_4,v1409_6);
        }
        v1407_11_result = unite(v1407_11_result,v1408_7);
      }
      const Space v1407_11 = std::move(v1407_11_result);
      v1405_12 = compose(v1405_9,v1407_11);
    }
    const Space v1405_13 = unite(v1405_7,v1405_12);
    v1404_6_result = unite(v1404_6_result,v1405_13);
  }
  const Space v1404_6 = std::move(v1404_6_result);
  return v1404_6;
}

static Space routine_150(Context& c, const Path& p0, const Space& s0) {
  Space v1410_5_result;
  for (int v1410_5_label = 1; v1410_5_label <= 2; ++v1410_5_label) {
    const Space v1410_5_tail = child(s0,v1410_5_label);
    if (v1410_5_tail.empty()) continue;
    const Path v1410_5_head{v1410_5_label};
    const Space v1411_2 = singleton(v1410_5_head);
    const Space v1411_3 = intersect(constant_8,v1411_2);
    const Space v1411_4 = (has_head(v1411_3) ? constant_9 : Space{});
    const Space v1411_5 = subtract(constant_0,v1411_4);
    Space v1411_6_result;
    for (int v1411_6_label = 1; v1411_6_label <= 2; ++v1411_6_label) {
      const Space v1411_6_tail = child(v1410_5_tail,v1411_6_label);
      if (v1411_6_tail.empty()) continue;
      const Path v1411_6_head{v1411_6_label};
      const Space v1412_2 = Space{};
      v1411_6_result = unite(v1411_6_result,v1412_2);
    }
    const Space v1411_6 = std::move(v1411_6_result);
    const Space v1411_7 = compose(v1411_5,v1411_6);
    const Space v1411_8 = intersect(constant_8,v1411_2);
    const Space v1411_9 = (has_head(v1411_8) ? constant_9 : Space{});
    const Space v1411_10 = compose(v1411_9,v1410_5_tail);
    const Space v1411_11 = unite(v1411_7,v1411_10);
    v1410_5_result = unite(v1410_5_result,v1411_11);
  }
  const Space v1410_5 = std::move(v1410_5_result);
  return v1410_5;
}

static Space routine_151(Context& c, const Path& p0, const Space& s0) {
  Space v1413_6_result;
  for (int v1413_6_label = 1; v1413_6_label <= 2; ++v1413_6_label) {
    const Space v1413_6_tail = child(s0,v1413_6_label);
    if (v1413_6_tail.empty()) continue;
    const Path v1413_6_head{v1413_6_label};
    const Space v1414_2 = singleton(v1413_6_head);
    const Space v1414_3 = intersect(constant_8,v1414_2);
    const Space v1414_4 = (has_head(v1414_3) ? constant_9 : Space{});
    const Space v1414_5 = subtract(constant_0,v1414_4);
    Space v1414_6_result;
    for (int v1414_6_label = 1; v1414_6_label <= 2; ++v1414_6_label) {
      const Space v1414_6_tail = child(v1413_6_tail,v1414_6_label);
      if (v1414_6_tail.empty()) continue;
      const Path v1414_6_head{v1414_6_label};
      const Space v1415_2 = Space{};
      v1414_6_result = unite(v1414_6_result,v1415_2);
    }
    const Space v1414_6 = std::move(v1414_6_result);
    const Space v1414_7 = compose(v1414_5,v1414_6);
    const Space v1414_8 = intersect(constant_8,v1414_2);
    const Space v1414_9 = (has_head(v1414_8) ? constant_9 : Space{});
    Space v1414_12;
    if (!v1414_9.empty()) {
      const Path v1416_10 = concat_path(p0,v1413_6_head);
      Space v1416_11_result;
      for (int v1416_11_label = 1; v1416_11_label <= 2; ++v1416_11_label) {
        const Space v1416_11_tail = child(v1413_6_tail,v1416_11_label);
        if (v1416_11_tail.empty()) continue;
        const Path v1416_11_head{v1416_11_label};
        const Space v1417_2 = singleton(v1416_11_head);
        const Space v1417_3 = intersect(constant_8,v1417_2);
        const Space v1417_4 = (has_head(v1417_3) ? constant_9 : Space{});
        Space v1417_7;
        if (!v1417_4.empty()) {
          const Path v1418_5 = concat_path(v1416_10,v1416_11_head);
          const Space v1418_6 = routine_77(c, v1418_5, v1416_11_tail);
          v1417_7 = compose(v1417_4,v1418_6);
        }
        v1416_11_result = unite(v1416_11_result,v1417_7);
      }
      const Space v1416_11 = std::move(v1416_11_result);
      v1414_12 = compose(v1414_9,v1416_11);
    }
    const Space v1414_13 = unite(v1414_7,v1414_12);
    v1413_6_result = unite(v1413_6_result,v1414_13);
  }
  const Space v1413_6 = std::move(v1413_6_result);
  return v1413_6;
}

static Space routine_152(Context& c, const Path& p0, const Space& s0) {
  Space v1419_8_result;
  for (int v1419_8_label = 1; v1419_8_label <= 2; ++v1419_8_label) {
    const Space v1419_8_tail = child(s0,v1419_8_label);
    if (v1419_8_tail.empty()) continue;
    const Path v1419_8_head{v1419_8_label};
    const Space v1420_2 = singleton(v1419_8_head);
    const Space v1420_3 = intersect(constant_8,v1420_2);
    const Space v1420_4 = (has_head(v1420_3) ? constant_9 : Space{});
    const Space v1420_5 = subtract(constant_0,v1420_4);
    Space v1420_6_result;
    for (int v1420_6_label = 1; v1420_6_label <= 2; ++v1420_6_label) {
      const Space v1420_6_tail = child(v1419_8_tail,v1420_6_label);
      if (v1420_6_tail.empty()) continue;
      const Path v1420_6_head{v1420_6_label};
      const Space v1421_2 = Space{};
      v1420_6_result = unite(v1420_6_result,v1421_2);
    }
    const Space v1420_6 = std::move(v1420_6_result);
    const Space v1420_7 = compose(v1420_5,v1420_6);
    const Space v1420_8 = intersect(constant_8,v1420_2);
    const Space v1420_9 = (has_head(v1420_8) ? constant_9 : Space{});
    Space v1420_12;
    if (!v1420_9.empty()) {
      const Path v1422_10 = concat_path(p0,v1419_8_head);
      Space v1422_11_result;
      for (int v1422_11_label = 1; v1422_11_label <= 2; ++v1422_11_label) {
        const Space v1422_11_tail = child(v1419_8_tail,v1422_11_label);
        if (v1422_11_tail.empty()) continue;
        const Path v1422_11_head{v1422_11_label};
        const Space v1423_2 = singleton(v1422_11_head);
        const Space v1423_3 = intersect(constant_8,v1423_2);
        const Space v1423_4 = (has_head(v1423_3) ? constant_9 : Space{});
        const Space v1423_5 = subtract(constant_0,v1423_4);
        Space v1423_7;
        if (!v1423_5.empty()) {
          const Space v1424_6 = routine_112(c, v1422_11_head, v1422_10, v1422_11_tail);
          v1423_7 = compose(v1423_5,v1424_6);
        }
        const Space v1423_8 = intersect(constant_8,v1423_2);
        const Space v1423_9 = (has_head(v1423_8) ? constant_9 : Space{});
        Space v1423_11;
        if (!v1423_9.empty()) {
          const Space v1425_10 = routine_113(c, v1422_11_head, v1422_10, v1422_11_tail);
          v1423_11 = compose(v1423_9,v1425_10);
        }
        const Space v1423_12 = unite(v1423_7,v1423_11);
        v1422_11_result = unite(v1422_11_result,v1423_12);
      }
      const Space v1422_11 = std::move(v1422_11_result);
      v1420_12 = compose(v1420_9,v1422_11);
    }
    const Space v1420_13 = unite(v1420_7,v1420_12);
    v1419_8_result = unite(v1419_8_result,v1420_13);
  }
  const Space v1419_8 = std::move(v1419_8_result);
  return v1419_8;
}

static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1426_12_result;
  for (int v1426_12_label = 1; v1426_12_label <= 2; ++v1426_12_label) {
    const Space v1426_12_tail = child(s0,v1426_12_label);
    if (v1426_12_tail.empty()) continue;
    const Path v1426_12_head{v1426_12_label};
    const Space v1427_2 = singleton(v1426_12_head);
    const Space v1427_3 = intersect(constant_8,v1427_2);
    const Space v1427_4 = (has_head(v1427_3) ? constant_9 : Space{});
    const Space v1427_5 = subtract(constant_0,v1427_4);
    Space v1427_8;
    if (!v1427_5.empty()) {
      const Path v1428_6 = concat_path(p0,v1426_12_head);
      Space v1428_7_result;
      for (int v1428_7_label = 1; v1428_7_label <= 2; ++v1428_7_label) {
        const Space v1428_7_tail = child(v1426_12_tail,v1428_7_label);
        if (v1428_7_tail.empty()) continue;
        const Path v1428_7_head{v1428_7_label};
        const Space v1429_2 = singleton(v1428_7_head);
        const Space v1429_3 = intersect(constant_8,v1429_2);
        const Space v1429_4 = (has_head(v1429_3) ? constant_9 : Space{});
        const Space v1429_5 = subtract(constant_0,v1429_4);
        Space v1429_8;
        if (!v1429_5.empty()) {
          const Path v1430_6 = concat_path(v1428_6,v1428_7_head);
          const Space v1430_7 = routine_238(c, v1430_6, p1, v1428_7_tail);
          v1429_8 = compose(v1429_5,v1430_7);
        }
        const Space v1429_9 = intersect(constant_8,v1429_2);
        const Space v1429_10 = (has_head(v1429_9) ? constant_9 : Space{});
        Space v1429_12;
        if (!v1429_10.empty()) {
          const Path v1431_6 = concat_path(v1428_6,v1428_7_head);
          const Space v1431_11 = routine_239(c, v1431_6, p1, v1428_7_tail);
          v1429_12 = compose(v1429_10,v1431_11);
        }
        const Space v1429_13 = unite(v1429_8,v1429_12);
        v1428_7_result = unite(v1428_7_result,v1429_13);
      }
      const Space v1428_7 = std::move(v1428_7_result);
      v1427_8 = compose(v1427_5,v1428_7);
    }
    const Space v1427_9 = intersect(constant_8,v1427_2);
    const Space v1427_10 = (has_head(v1427_9) ? constant_9 : Space{});
    Space v1427_12;
    if (!v1427_10.empty()) {
      const Path v1432_6 = concat_path(p0,v1426_12_head);
      Space v1432_11_result;
      for (int v1432_11_label = 1; v1432_11_label <= 2; ++v1432_11_label) {
        const Space v1432_11_tail = child(v1426_12_tail,v1432_11_label);
        if (v1432_11_tail.empty()) continue;
        const Path v1432_11_head{v1432_11_label};
        const Space v1433_2 = singleton(v1432_11_head);
        const Space v1433_3 = intersect(constant_8,v1433_2);
        const Space v1433_4 = (has_head(v1433_3) ? constant_9 : Space{});
        const Space v1433_5 = subtract(constant_0,v1433_4);
        Space v1433_8;
        if (!v1433_5.empty()) {
          const Path v1434_6 = concat_path(v1432_6,v1432_11_head);
          const Space v1434_7 = routine_238(c, v1434_6, p1, v1432_11_tail);
          v1433_8 = compose(v1433_5,v1434_7);
        }
        const Space v1433_9 = intersect(constant_8,v1433_2);
        const Space v1433_10 = (has_head(v1433_9) ? constant_9 : Space{});
        Space v1433_12;
        if (!v1433_10.empty()) {
          const Path v1435_6 = concat_path(v1432_6,v1432_11_head);
          const Space v1435_11 = routine_155(c, v1435_6, p1, v1432_11_tail);
          v1433_12 = compose(v1433_10,v1435_11);
        }
        const Space v1433_13 = unite(v1433_8,v1433_12);
        v1432_11_result = unite(v1432_11_result,v1433_13);
      }
      const Space v1432_11 = std::move(v1432_11_result);
      v1427_12 = compose(v1427_10,v1432_11);
    }
    const Space v1427_13 = unite(v1427_8,v1427_12);
    v1426_12_result = unite(v1426_12_result,v1427_13);
  }
  const Space v1426_12 = std::move(v1426_12_result);
  return v1426_12;
}

static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1436_12_result;
  for (int v1436_12_label = 1; v1436_12_label <= 2; ++v1436_12_label) {
    const Space v1436_12_tail = child(s0,v1436_12_label);
    if (v1436_12_tail.empty()) continue;
    const Path v1436_12_head{v1436_12_label};
    const Space v1437_2 = singleton(v1436_12_head);
    const Space v1437_3 = intersect(constant_8,v1437_2);
    const Space v1437_4 = (has_head(v1437_3) ? constant_9 : Space{});
    const Space v1437_5 = subtract(constant_0,v1437_4);
    Space v1437_8;
    if (!v1437_5.empty()) {
      const Path v1438_6 = concat_path(p0,v1436_12_head);
      Space v1438_7_result;
      for (int v1438_7_label = 1; v1438_7_label <= 2; ++v1438_7_label) {
        const Space v1438_7_tail = child(v1436_12_tail,v1438_7_label);
        if (v1438_7_tail.empty()) continue;
        const Path v1438_7_head{v1438_7_label};
        const Space v1439_2 = singleton(v1438_7_head);
        const Space v1439_3 = intersect(constant_8,v1439_2);
        const Space v1439_4 = (has_head(v1439_3) ? constant_9 : Space{});
        const Space v1439_5 = subtract(constant_0,v1439_4);
        Space v1439_8;
        if (!v1439_5.empty()) {
          const Path v1440_6 = concat_path(v1438_6,v1438_7_head);
          const Space v1440_7 = routine_238(c, v1440_6, p1, v1438_7_tail);
          v1439_8 = compose(v1439_5,v1440_7);
        }
        const Space v1439_9 = intersect(constant_8,v1439_2);
        const Space v1439_10 = (has_head(v1439_9) ? constant_9 : Space{});
        Space v1439_12;
        if (!v1439_10.empty()) {
          const Path v1441_6 = concat_path(v1438_6,v1438_7_head);
          const Space v1441_11 = routine_239(c, v1441_6, p1, v1438_7_tail);
          v1439_12 = compose(v1439_10,v1441_11);
        }
        const Space v1439_13 = unite(v1439_8,v1439_12);
        v1438_7_result = unite(v1438_7_result,v1439_13);
      }
      const Space v1438_7 = std::move(v1438_7_result);
      v1437_8 = compose(v1437_5,v1438_7);
    }
    const Space v1437_9 = intersect(constant_8,v1437_2);
    const Space v1437_10 = (has_head(v1437_9) ? constant_9 : Space{});
    Space v1437_12;
    if (!v1437_10.empty()) {
      const Path v1442_6 = concat_path(p0,v1436_12_head);
      Space v1442_11_result;
      for (int v1442_11_label = 1; v1442_11_label <= 2; ++v1442_11_label) {
        const Space v1442_11_tail = child(v1436_12_tail,v1442_11_label);
        if (v1442_11_tail.empty()) continue;
        const Path v1442_11_head{v1442_11_label};
        const Space v1443_2 = singleton(v1442_11_head);
        const Space v1443_3 = intersect(constant_8,v1443_2);
        const Space v1443_4 = (has_head(v1443_3) ? constant_9 : Space{});
        const Space v1443_5 = subtract(constant_0,v1443_4);
        Space v1443_7;
        if (!v1443_5.empty()) {
          const Space v1444_6 = routine_201(c, v1442_11_head, p1, v1442_6, v1442_11_tail);
          v1443_7 = compose(v1443_5,v1444_6);
        }
        const Space v1443_8 = intersect(constant_8,v1443_2);
        const Space v1443_9 = (has_head(v1443_8) ? constant_9 : Space{});
        Space v1443_11;
        if (!v1443_9.empty()) {
          const Space v1445_10 = routine_202(c, v1442_11_head, p1, v1442_6, v1442_11_tail);
          v1443_11 = compose(v1443_9,v1445_10);
        }
        const Space v1443_12 = unite(v1443_7,v1443_11);
        v1442_11_result = unite(v1442_11_result,v1443_12);
      }
      const Space v1442_11 = std::move(v1442_11_result);
      v1437_12 = compose(v1437_10,v1442_11);
    }
    const Space v1437_13 = unite(v1437_8,v1437_12);
    v1436_12_result = unite(v1436_12_result,v1437_13);
  }
  const Space v1436_12 = std::move(v1436_12_result);
  return v1436_12;
}

static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1446_12_result;
  for (int v1446_12_label = 1; v1446_12_label <= 2; ++v1446_12_label) {
    const Space v1446_12_tail = child(s0,v1446_12_label);
    if (v1446_12_tail.empty()) continue;
    const Path v1446_12_head{v1446_12_label};
    const Space v1447_2 = singleton(v1446_12_head);
    const Space v1447_3 = intersect(constant_8,v1447_2);
    const Space v1447_4 = (has_head(v1447_3) ? constant_9 : Space{});
    const Space v1447_5 = subtract(constant_0,v1447_4);
    Space v1447_7;
    if (!v1447_5.empty()) {
      Space v1448_6_result;
      for (int v1448_6_label = 1; v1448_6_label <= 2; ++v1448_6_label) {
        const Space v1448_6_tail = child(v1446_12_tail,v1448_6_label);
        if (v1448_6_tail.empty()) continue;
        const Path v1448_6_head{v1448_6_label};
        const Space v1449_2 = singleton(v1448_6_head);
        const Space v1449_3 = intersect(constant_8,v1449_2);
        const Space v1449_4 = (has_head(v1449_3) ? constant_9 : Space{});
        const Space v1449_5 = subtract(constant_0,v1449_4);
        Space v1449_8;
        if (!v1449_5.empty()) {
          const Path v1450_6 = concat_path(v1446_12_head,v1448_6_head);
          const Space v1450_7 = routine_240(c, v1450_6, p1, p0, v1448_6_tail);
          v1449_8 = compose(v1449_5,v1450_7);
        }
        const Space v1449_9 = intersect(constant_8,v1449_2);
        const Space v1449_10 = (has_head(v1449_9) ? constant_9 : Space{});
        Space v1449_12;
        if (!v1449_10.empty()) {
          const Path v1451_6 = concat_path(v1446_12_head,v1448_6_head);
          const Space v1451_11 = routine_241(c, v1451_6, p1, p0, v1448_6_tail);
          v1449_12 = compose(v1449_10,v1451_11);
        }
        const Space v1449_13 = unite(v1449_8,v1449_12);
        v1448_6_result = unite(v1448_6_result,v1449_13);
      }
      const Space v1448_6 = std::move(v1448_6_result);
      v1447_7 = compose(v1447_5,v1448_6);
    }
    const Space v1447_8 = intersect(constant_8,v1447_2);
    const Space v1447_9 = (has_head(v1447_8) ? constant_9 : Space{});
    Space v1447_11;
    if (!v1447_9.empty()) {
      Space v1452_10_result;
      for (int v1452_10_label = 1; v1452_10_label <= 2; ++v1452_10_label) {
        const Space v1452_10_tail = child(v1446_12_tail,v1452_10_label);
        if (v1452_10_tail.empty()) continue;
        const Path v1452_10_head{v1452_10_label};
        const Space v1453_2 = singleton(v1452_10_head);
        const Space v1453_3 = intersect(constant_8,v1453_2);
        const Space v1453_4 = (has_head(v1453_3) ? constant_9 : Space{});
        const Space v1453_5 = subtract(constant_0,v1453_4);
        Space v1453_8;
        if (!v1453_5.empty()) {
          const Path v1454_6 = concat_path(v1446_12_head,v1452_10_head);
          const Space v1454_7 = routine_240(c, v1454_6, p1, p0, v1452_10_tail);
          v1453_8 = compose(v1453_5,v1454_7);
        }
        const Space v1453_9 = intersect(constant_8,v1453_2);
        const Space v1453_10 = (has_head(v1453_9) ? constant_9 : Space{});
        Space v1453_12;
        if (!v1453_10.empty()) {
          const Path v1455_6 = concat_path(v1446_12_head,v1452_10_head);
          const Space v1455_11 = routine_242(c, v1455_6, p1, p0, v1452_10_tail);
          v1453_12 = compose(v1453_10,v1455_11);
        }
        const Space v1453_13 = unite(v1453_8,v1453_12);
        v1452_10_result = unite(v1452_10_result,v1453_13);
      }
      const Space v1452_10 = std::move(v1452_10_result);
      v1447_11 = compose(v1447_9,v1452_10);
    }
    const Space v1447_12 = unite(v1447_7,v1447_11);
    v1446_12_result = unite(v1446_12_result,v1447_12);
  }
  const Space v1446_12 = std::move(v1446_12_result);
  return v1446_12;
}

static Space routine_156(Context& c, const Path& p0, const Space& s0) {
  Space v1456_6_result;
  for (int v1456_6_label = 1; v1456_6_label <= 2; ++v1456_6_label) {
    const Space v1456_6_tail = child(s0,v1456_6_label);
    if (v1456_6_tail.empty()) continue;
    const Path v1456_6_head{v1456_6_label};
    const Space v1457_2 = singleton(v1456_6_head);
    const Space v1457_3 = intersect(constant_8,v1457_2);
    const Space v1457_4 = (has_head(v1457_3) ? constant_9 : Space{});
    const Space v1457_5 = subtract(constant_0,v1457_4);
    Space v1457_6_result;
    for (int v1457_6_label = 1; v1457_6_label <= 2; ++v1457_6_label) {
      const Space v1457_6_tail = child(v1456_6_tail,v1457_6_label);
      if (v1457_6_tail.empty()) continue;
      const Path v1457_6_head{v1457_6_label};
      const Space v1458_2 = Space{};
      v1457_6_result = unite(v1457_6_result,v1458_2);
    }
    const Space v1457_6 = std::move(v1457_6_result);
    const Space v1457_7 = compose(v1457_5,v1457_6);
    const Space v1457_8 = intersect(constant_8,v1457_2);
    const Space v1457_9 = (has_head(v1457_8) ? constant_9 : Space{});
    Space v1457_12;
    if (!v1457_9.empty()) {
      const Path v1459_10 = concat_path(p0,v1456_6_head);
      Space v1459_11_result;
      for (int v1459_11_label = 1; v1459_11_label <= 2; ++v1459_11_label) {
        const Space v1459_11_tail = child(v1456_6_tail,v1459_11_label);
        if (v1459_11_tail.empty()) continue;
        const Path v1459_11_head{v1459_11_label};
        const Space v1460_2 = singleton(v1459_11_head);
        const Space v1460_3 = intersect(constant_8,v1460_2);
        const Space v1460_4 = (has_head(v1460_3) ? constant_9 : Space{});
        Space v1460_7;
        if (!v1460_4.empty()) {
          const Path v1461_5 = concat_path(v1459_10,v1459_11_head);
          const Space v1461_6 = routine_80(c, v1461_5, v1459_11_tail);
          v1460_7 = compose(v1460_4,v1461_6);
        }
        v1459_11_result = unite(v1459_11_result,v1460_7);
      }
      const Space v1459_11 = std::move(v1459_11_result);
      v1457_12 = compose(v1457_9,v1459_11);
    }
    const Space v1457_13 = unite(v1457_7,v1457_12);
    v1456_6_result = unite(v1456_6_result,v1457_13);
  }
  const Space v1456_6 = std::move(v1456_6_result);
  return v1456_6;
}

static Space routine_157(Context& c, const Path& p0, const Space& s0) {
  Space v1462_5_result;
  for (int v1462_5_label = 1; v1462_5_label <= 2; ++v1462_5_label) {
    const Space v1462_5_tail = child(s0,v1462_5_label);
    if (v1462_5_tail.empty()) continue;
    const Path v1462_5_head{v1462_5_label};
    const Space v1463_2 = singleton(v1462_5_head);
    const Space v1463_3 = intersect(constant_8,v1463_2);
    const Space v1463_4 = (has_head(v1463_3) ? constant_9 : Space{});
    const Space v1463_5 = subtract(constant_0,v1463_4);
    Space v1463_6_result;
    for (int v1463_6_label = 1; v1463_6_label <= 2; ++v1463_6_label) {
      const Space v1463_6_tail = child(v1462_5_tail,v1463_6_label);
      if (v1463_6_tail.empty()) continue;
      const Path v1463_6_head{v1463_6_label};
      const Space v1464_2 = Space{};
      v1463_6_result = unite(v1463_6_result,v1464_2);
    }
    const Space v1463_6 = std::move(v1463_6_result);
    const Space v1463_7 = compose(v1463_5,v1463_6);
    const Space v1463_8 = intersect(constant_8,v1463_2);
    const Space v1463_9 = (has_head(v1463_8) ? constant_9 : Space{});
    const Space v1463_10 = compose(v1463_9,v1462_5_tail);
    const Space v1463_11 = unite(v1463_7,v1463_10);
    v1462_5_result = unite(v1462_5_result,v1463_11);
  }
  const Space v1462_5 = std::move(v1462_5_result);
  return v1462_5;
}

static Space routine_158(Context& c, const Path& p0, const Space& s0) {
  Space v1465_6_result;
  for (int v1465_6_label = 1; v1465_6_label <= 2; ++v1465_6_label) {
    const Space v1465_6_tail = child(s0,v1465_6_label);
    if (v1465_6_tail.empty()) continue;
    const Path v1465_6_head{v1465_6_label};
    const Space v1466_2 = singleton(v1465_6_head);
    const Space v1466_3 = intersect(constant_8,v1466_2);
    const Space v1466_4 = (has_head(v1466_3) ? constant_9 : Space{});
    const Space v1466_5 = subtract(constant_0,v1466_4);
    Space v1466_6_result;
    for (int v1466_6_label = 1; v1466_6_label <= 2; ++v1466_6_label) {
      const Space v1466_6_tail = child(v1465_6_tail,v1466_6_label);
      if (v1466_6_tail.empty()) continue;
      const Path v1466_6_head{v1466_6_label};
      const Space v1467_2 = Space{};
      v1466_6_result = unite(v1466_6_result,v1467_2);
    }
    const Space v1466_6 = std::move(v1466_6_result);
    const Space v1466_7 = compose(v1466_5,v1466_6);
    const Space v1466_8 = intersect(constant_8,v1466_2);
    const Space v1466_9 = (has_head(v1466_8) ? constant_9 : Space{});
    Space v1466_12;
    if (!v1466_9.empty()) {
      const Path v1468_10 = concat_path(p0,v1465_6_head);
      Space v1468_11_result;
      for (int v1468_11_label = 1; v1468_11_label <= 2; ++v1468_11_label) {
        const Space v1468_11_tail = child(v1465_6_tail,v1468_11_label);
        if (v1468_11_tail.empty()) continue;
        const Path v1468_11_head{v1468_11_label};
        const Space v1469_2 = singleton(v1468_11_head);
        const Space v1469_3 = intersect(constant_8,v1469_2);
        const Space v1469_4 = (has_head(v1469_3) ? constant_9 : Space{});
        Space v1469_7;
        if (!v1469_4.empty()) {
          const Path v1470_5 = concat_path(v1468_10,v1468_11_head);
          const Space v1470_6 = routine_83(c, v1470_5, v1468_11_tail);
          v1469_7 = compose(v1469_4,v1470_6);
        }
        v1468_11_result = unite(v1468_11_result,v1469_7);
      }
      const Space v1468_11 = std::move(v1468_11_result);
      v1466_12 = compose(v1466_9,v1468_11);
    }
    const Space v1466_13 = unite(v1466_7,v1466_12);
    v1465_6_result = unite(v1465_6_result,v1466_13);
  }
  const Space v1465_6 = std::move(v1465_6_result);
  return v1465_6;
}

static Space routine_159(Context& c, const Path& p0, const Space& s0) {
  Space v1471_8_result;
  for (int v1471_8_label = 1; v1471_8_label <= 2; ++v1471_8_label) {
    const Space v1471_8_tail = child(s0,v1471_8_label);
    if (v1471_8_tail.empty()) continue;
    const Path v1471_8_head{v1471_8_label};
    const Space v1472_2 = singleton(v1471_8_head);
    const Space v1472_3 = intersect(constant_8,v1472_2);
    const Space v1472_4 = (has_head(v1472_3) ? constant_9 : Space{});
    const Space v1472_5 = subtract(constant_0,v1472_4);
    Space v1472_6_result;
    for (int v1472_6_label = 1; v1472_6_label <= 2; ++v1472_6_label) {
      const Space v1472_6_tail = child(v1471_8_tail,v1472_6_label);
      if (v1472_6_tail.empty()) continue;
      const Path v1472_6_head{v1472_6_label};
      const Space v1473_2 = Space{};
      v1472_6_result = unite(v1472_6_result,v1473_2);
    }
    const Space v1472_6 = std::move(v1472_6_result);
    const Space v1472_7 = compose(v1472_5,v1472_6);
    const Space v1472_8 = intersect(constant_8,v1472_2);
    const Space v1472_9 = (has_head(v1472_8) ? constant_9 : Space{});
    Space v1472_12;
    if (!v1472_9.empty()) {
      const Path v1474_10 = concat_path(p0,v1471_8_head);
      Space v1474_11_result;
      for (int v1474_11_label = 1; v1474_11_label <= 2; ++v1474_11_label) {
        const Space v1474_11_tail = child(v1471_8_tail,v1474_11_label);
        if (v1474_11_tail.empty()) continue;
        const Path v1474_11_head{v1474_11_label};
        const Space v1475_2 = singleton(v1474_11_head);
        const Space v1475_3 = intersect(constant_8,v1475_2);
        const Space v1475_4 = (has_head(v1475_3) ? constant_9 : Space{});
        const Space v1475_5 = subtract(constant_0,v1475_4);
        Space v1475_7;
        if (!v1475_5.empty()) {
          const Space v1476_6 = routine_118(c, v1474_11_head, v1474_10, v1474_11_tail);
          v1475_7 = compose(v1475_5,v1476_6);
        }
        const Space v1475_8 = intersect(constant_8,v1475_2);
        const Space v1475_9 = (has_head(v1475_8) ? constant_9 : Space{});
        Space v1475_11;
        if (!v1475_9.empty()) {
          const Space v1477_10 = routine_119(c, v1474_11_head, v1474_10, v1474_11_tail);
          v1475_11 = compose(v1475_9,v1477_10);
        }
        const Space v1475_12 = unite(v1475_7,v1475_11);
        v1474_11_result = unite(v1474_11_result,v1475_12);
      }
      const Space v1474_11 = std::move(v1474_11_result);
      v1472_12 = compose(v1472_9,v1474_11);
    }
    const Space v1472_13 = unite(v1472_7,v1472_12);
    v1471_8_result = unite(v1471_8_result,v1472_13);
  }
  const Space v1471_8 = std::move(v1471_8_result);
  return v1471_8;
}

static Space routine_160(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1478_12_result;
  for (int v1478_12_label = 1; v1478_12_label <= 2; ++v1478_12_label) {
    const Space v1478_12_tail = child(s0,v1478_12_label);
    if (v1478_12_tail.empty()) continue;
    const Path v1478_12_head{v1478_12_label};
    const Space v1479_2 = singleton(v1478_12_head);
    const Space v1479_3 = intersect(constant_8,v1479_2);
    const Space v1479_4 = (has_head(v1479_3) ? constant_9 : Space{});
    const Space v1479_5 = subtract(constant_0,v1479_4);
    Space v1479_8;
    if (!v1479_5.empty()) {
      const Path v1480_6 = concat_path(p0,v1478_12_head);
      Space v1480_7_result;
      for (int v1480_7_label = 1; v1480_7_label <= 2; ++v1480_7_label) {
        const Space v1480_7_tail = child(v1478_12_tail,v1480_7_label);
        if (v1480_7_tail.empty()) continue;
        const Path v1480_7_head{v1480_7_label};
        const Space v1481_2 = singleton(v1480_7_head);
        const Space v1481_3 = intersect(constant_8,v1481_2);
        const Space v1481_4 = (has_head(v1481_3) ? constant_9 : Space{});
        const Space v1481_5 = subtract(constant_0,v1481_4);
        Space v1481_8;
        if (!v1481_5.empty()) {
          const Path v1482_6 = concat_path(v1480_6,v1480_7_head);
          const Space v1482_7 = routine_243(c, v1482_6, p1, v1480_7_tail);
          v1481_8 = compose(v1481_5,v1482_7);
        }
        const Space v1481_9 = intersect(constant_8,v1481_2);
        const Space v1481_10 = (has_head(v1481_9) ? constant_9 : Space{});
        Space v1481_12;
        if (!v1481_10.empty()) {
          const Path v1483_6 = concat_path(v1480_6,v1480_7_head);
          const Space v1483_11 = routine_244(c, v1483_6, p1, v1480_7_tail);
          v1481_12 = compose(v1481_10,v1483_11);
        }
        const Space v1481_13 = unite(v1481_8,v1481_12);
        v1480_7_result = unite(v1480_7_result,v1481_13);
      }
      const Space v1480_7 = std::move(v1480_7_result);
      v1479_8 = compose(v1479_5,v1480_7);
    }
    const Space v1479_9 = intersect(constant_8,v1479_2);
    const Space v1479_10 = (has_head(v1479_9) ? constant_9 : Space{});
    Space v1479_12;
    if (!v1479_10.empty()) {
      const Path v1484_6 = concat_path(p0,v1478_12_head);
      Space v1484_11_result;
      for (int v1484_11_label = 1; v1484_11_label <= 2; ++v1484_11_label) {
        const Space v1484_11_tail = child(v1478_12_tail,v1484_11_label);
        if (v1484_11_tail.empty()) continue;
        const Path v1484_11_head{v1484_11_label};
        const Space v1485_2 = singleton(v1484_11_head);
        const Space v1485_3 = intersect(constant_8,v1485_2);
        const Space v1485_4 = (has_head(v1485_3) ? constant_9 : Space{});
        const Space v1485_5 = subtract(constant_0,v1485_4);
        Space v1485_8;
        if (!v1485_5.empty()) {
          const Path v1486_6 = concat_path(v1484_6,v1484_11_head);
          const Space v1486_7 = routine_243(c, v1486_6, p1, v1484_11_tail);
          v1485_8 = compose(v1485_5,v1486_7);
        }
        const Space v1485_9 = intersect(constant_8,v1485_2);
        const Space v1485_10 = (has_head(v1485_9) ? constant_9 : Space{});
        Space v1485_12;
        if (!v1485_10.empty()) {
          const Path v1487_6 = concat_path(v1484_6,v1484_11_head);
          const Space v1487_11 = routine_162(c, v1487_6, p1, v1484_11_tail);
          v1485_12 = compose(v1485_10,v1487_11);
        }
        const Space v1485_13 = unite(v1485_8,v1485_12);
        v1484_11_result = unite(v1484_11_result,v1485_13);
      }
      const Space v1484_11 = std::move(v1484_11_result);
      v1479_12 = compose(v1479_10,v1484_11);
    }
    const Space v1479_13 = unite(v1479_8,v1479_12);
    v1478_12_result = unite(v1478_12_result,v1479_13);
  }
  const Space v1478_12 = std::move(v1478_12_result);
  return v1478_12;
}

static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1488_12_result;
  for (int v1488_12_label = 1; v1488_12_label <= 2; ++v1488_12_label) {
    const Space v1488_12_tail = child(s0,v1488_12_label);
    if (v1488_12_tail.empty()) continue;
    const Path v1488_12_head{v1488_12_label};
    const Space v1489_2 = singleton(v1488_12_head);
    const Space v1489_3 = intersect(constant_8,v1489_2);
    const Space v1489_4 = (has_head(v1489_3) ? constant_9 : Space{});
    const Space v1489_5 = subtract(constant_0,v1489_4);
    Space v1489_8;
    if (!v1489_5.empty()) {
      const Path v1490_6 = concat_path(p0,v1488_12_head);
      Space v1490_7_result;
      for (int v1490_7_label = 1; v1490_7_label <= 2; ++v1490_7_label) {
        const Space v1490_7_tail = child(v1488_12_tail,v1490_7_label);
        if (v1490_7_tail.empty()) continue;
        const Path v1490_7_head{v1490_7_label};
        const Space v1491_2 = singleton(v1490_7_head);
        const Space v1491_3 = intersect(constant_8,v1491_2);
        const Space v1491_4 = (has_head(v1491_3) ? constant_9 : Space{});
        const Space v1491_5 = subtract(constant_0,v1491_4);
        Space v1491_8;
        if (!v1491_5.empty()) {
          const Path v1492_6 = concat_path(v1490_6,v1490_7_head);
          const Space v1492_7 = routine_243(c, v1492_6, p1, v1490_7_tail);
          v1491_8 = compose(v1491_5,v1492_7);
        }
        const Space v1491_9 = intersect(constant_8,v1491_2);
        const Space v1491_10 = (has_head(v1491_9) ? constant_9 : Space{});
        Space v1491_12;
        if (!v1491_10.empty()) {
          const Path v1493_6 = concat_path(v1490_6,v1490_7_head);
          const Space v1493_11 = routine_244(c, v1493_6, p1, v1490_7_tail);
          v1491_12 = compose(v1491_10,v1493_11);
        }
        const Space v1491_13 = unite(v1491_8,v1491_12);
        v1490_7_result = unite(v1490_7_result,v1491_13);
      }
      const Space v1490_7 = std::move(v1490_7_result);
      v1489_8 = compose(v1489_5,v1490_7);
    }
    const Space v1489_9 = intersect(constant_8,v1489_2);
    const Space v1489_10 = (has_head(v1489_9) ? constant_9 : Space{});
    Space v1489_12;
    if (!v1489_10.empty()) {
      const Path v1494_6 = concat_path(p0,v1488_12_head);
      Space v1494_11_result;
      for (int v1494_11_label = 1; v1494_11_label <= 2; ++v1494_11_label) {
        const Space v1494_11_tail = child(v1488_12_tail,v1494_11_label);
        if (v1494_11_tail.empty()) continue;
        const Path v1494_11_head{v1494_11_label};
        const Space v1495_2 = singleton(v1494_11_head);
        const Space v1495_3 = intersect(constant_8,v1495_2);
        const Space v1495_4 = (has_head(v1495_3) ? constant_9 : Space{});
        const Space v1495_5 = subtract(constant_0,v1495_4);
        Space v1495_7;
        if (!v1495_5.empty()) {
          const Space v1496_6 = routine_209(c, v1494_11_head, p1, v1494_6, v1494_11_tail);
          v1495_7 = compose(v1495_5,v1496_6);
        }
        const Space v1495_8 = intersect(constant_8,v1495_2);
        const Space v1495_9 = (has_head(v1495_8) ? constant_9 : Space{});
        Space v1495_11;
        if (!v1495_9.empty()) {
          const Space v1497_10 = routine_210(c, v1494_11_head, p1, v1494_6, v1494_11_tail);
          v1495_11 = compose(v1495_9,v1497_10);
        }
        const Space v1495_12 = unite(v1495_7,v1495_11);
        v1494_11_result = unite(v1494_11_result,v1495_12);
      }
      const Space v1494_11 = std::move(v1494_11_result);
      v1489_12 = compose(v1489_10,v1494_11);
    }
    const Space v1489_13 = unite(v1489_8,v1489_12);
    v1488_12_result = unite(v1488_12_result,v1489_13);
  }
  const Space v1488_12 = std::move(v1488_12_result);
  return v1488_12;
}

static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1498_12_result;
  for (int v1498_12_label = 1; v1498_12_label <= 2; ++v1498_12_label) {
    const Space v1498_12_tail = child(s0,v1498_12_label);
    if (v1498_12_tail.empty()) continue;
    const Path v1498_12_head{v1498_12_label};
    const Space v1499_2 = singleton(v1498_12_head);
    const Space v1499_3 = intersect(constant_8,v1499_2);
    const Space v1499_4 = (has_head(v1499_3) ? constant_9 : Space{});
    const Space v1499_5 = subtract(constant_0,v1499_4);
    Space v1499_7;
    if (!v1499_5.empty()) {
      Space v1500_6_result;
      for (int v1500_6_label = 1; v1500_6_label <= 2; ++v1500_6_label) {
        const Space v1500_6_tail = child(v1498_12_tail,v1500_6_label);
        if (v1500_6_tail.empty()) continue;
        const Path v1500_6_head{v1500_6_label};
        const Space v1501_2 = singleton(v1500_6_head);
        const Space v1501_3 = intersect(constant_8,v1501_2);
        const Space v1501_4 = (has_head(v1501_3) ? constant_9 : Space{});
        const Space v1501_5 = subtract(constant_0,v1501_4);
        Space v1501_8;
        if (!v1501_5.empty()) {
          const Path v1502_6 = concat_path(v1498_12_head,v1500_6_head);
          const Space v1502_7 = routine_245(c, v1502_6, p1, p0, v1500_6_tail);
          v1501_8 = compose(v1501_5,v1502_7);
        }
        const Space v1501_9 = intersect(constant_8,v1501_2);
        const Space v1501_10 = (has_head(v1501_9) ? constant_9 : Space{});
        Space v1501_12;
        if (!v1501_10.empty()) {
          const Path v1503_6 = concat_path(v1498_12_head,v1500_6_head);
          const Space v1503_11 = routine_246(c, v1503_6, p1, p0, v1500_6_tail);
          v1501_12 = compose(v1501_10,v1503_11);
        }
        const Space v1501_13 = unite(v1501_8,v1501_12);
        v1500_6_result = unite(v1500_6_result,v1501_13);
      }
      const Space v1500_6 = std::move(v1500_6_result);
      v1499_7 = compose(v1499_5,v1500_6);
    }
    const Space v1499_8 = intersect(constant_8,v1499_2);
    const Space v1499_9 = (has_head(v1499_8) ? constant_9 : Space{});
    Space v1499_11;
    if (!v1499_9.empty()) {
      Space v1504_10_result;
      for (int v1504_10_label = 1; v1504_10_label <= 2; ++v1504_10_label) {
        const Space v1504_10_tail = child(v1498_12_tail,v1504_10_label);
        if (v1504_10_tail.empty()) continue;
        const Path v1504_10_head{v1504_10_label};
        const Space v1505_2 = singleton(v1504_10_head);
        const Space v1505_3 = intersect(constant_8,v1505_2);
        const Space v1505_4 = (has_head(v1505_3) ? constant_9 : Space{});
        const Space v1505_5 = subtract(constant_0,v1505_4);
        Space v1505_8;
        if (!v1505_5.empty()) {
          const Path v1506_6 = concat_path(v1498_12_head,v1504_10_head);
          const Space v1506_7 = routine_245(c, v1506_6, p1, p0, v1504_10_tail);
          v1505_8 = compose(v1505_5,v1506_7);
        }
        const Space v1505_9 = intersect(constant_8,v1505_2);
        const Space v1505_10 = (has_head(v1505_9) ? constant_9 : Space{});
        Space v1505_12;
        if (!v1505_10.empty()) {
          const Path v1507_6 = concat_path(v1498_12_head,v1504_10_head);
          const Space v1507_11 = routine_247(c, v1507_6, p1, p0, v1504_10_tail);
          v1505_12 = compose(v1505_10,v1507_11);
        }
        const Space v1505_13 = unite(v1505_8,v1505_12);
        v1504_10_result = unite(v1504_10_result,v1505_13);
      }
      const Space v1504_10 = std::move(v1504_10_result);
      v1499_11 = compose(v1499_9,v1504_10);
    }
    const Space v1499_12 = unite(v1499_7,v1499_11);
    v1498_12_result = unite(v1498_12_result,v1499_12);
  }
  const Space v1498_12 = std::move(v1498_12_result);
  return v1498_12;
}

static Space routine_163(Context& c, const Path& p0, const Space& s0) {
  Space v1508_6_result;
  for (int v1508_6_label = 1; v1508_6_label <= 2; ++v1508_6_label) {
    const Space v1508_6_tail = child(s0,v1508_6_label);
    if (v1508_6_tail.empty()) continue;
    const Path v1508_6_head{v1508_6_label};
    const Space v1509_2 = singleton(v1508_6_head);
    const Space v1509_3 = intersect(constant_8,v1509_2);
    const Space v1509_4 = (has_head(v1509_3) ? constant_9 : Space{});
    const Space v1509_5 = subtract(constant_0,v1509_4);
    Space v1509_6_result;
    for (int v1509_6_label = 1; v1509_6_label <= 2; ++v1509_6_label) {
      const Space v1509_6_tail = child(v1508_6_tail,v1509_6_label);
      if (v1509_6_tail.empty()) continue;
      const Path v1509_6_head{v1509_6_label};
      const Space v1510_2 = Space{};
      v1509_6_result = unite(v1509_6_result,v1510_2);
    }
    const Space v1509_6 = std::move(v1509_6_result);
    const Space v1509_7 = compose(v1509_5,v1509_6);
    const Space v1509_8 = intersect(constant_8,v1509_2);
    const Space v1509_9 = (has_head(v1509_8) ? constant_9 : Space{});
    Space v1509_12;
    if (!v1509_9.empty()) {
      const Path v1511_10 = concat_path(p0,v1508_6_head);
      Space v1511_11_result;
      for (int v1511_11_label = 1; v1511_11_label <= 2; ++v1511_11_label) {
        const Space v1511_11_tail = child(v1508_6_tail,v1511_11_label);
        if (v1511_11_tail.empty()) continue;
        const Path v1511_11_head{v1511_11_label};
        const Space v1512_2 = singleton(v1511_11_head);
        const Space v1512_3 = intersect(constant_8,v1512_2);
        const Space v1512_4 = (has_head(v1512_3) ? constant_9 : Space{});
        Space v1512_7;
        if (!v1512_4.empty()) {
          const Path v1513_5 = concat_path(v1511_10,v1511_11_head);
          const Space v1513_6 = routine_86(c, v1513_5, v1511_11_tail);
          v1512_7 = compose(v1512_4,v1513_6);
        }
        v1511_11_result = unite(v1511_11_result,v1512_7);
      }
      const Space v1511_11 = std::move(v1511_11_result);
      v1509_12 = compose(v1509_9,v1511_11);
    }
    const Space v1509_13 = unite(v1509_7,v1509_12);
    v1508_6_result = unite(v1508_6_result,v1509_13);
  }
  const Space v1508_6 = std::move(v1508_6_result);
  return v1508_6;
}

static Space routine_164(Context& c, const Path& p0, const Space& s0) {
  Space v1514_5_result;
  for (int v1514_5_label = 1; v1514_5_label <= 2; ++v1514_5_label) {
    const Space v1514_5_tail = child(s0,v1514_5_label);
    if (v1514_5_tail.empty()) continue;
    const Path v1514_5_head{v1514_5_label};
    const Space v1515_2 = singleton(v1514_5_head);
    const Space v1515_3 = intersect(constant_8,v1515_2);
    const Space v1515_4 = (has_head(v1515_3) ? constant_9 : Space{});
    const Space v1515_5 = subtract(constant_0,v1515_4);
    Space v1515_6_result;
    for (int v1515_6_label = 1; v1515_6_label <= 2; ++v1515_6_label) {
      const Space v1515_6_tail = child(v1514_5_tail,v1515_6_label);
      if (v1515_6_tail.empty()) continue;
      const Path v1515_6_head{v1515_6_label};
      const Space v1516_2 = Space{};
      v1515_6_result = unite(v1515_6_result,v1516_2);
    }
    const Space v1515_6 = std::move(v1515_6_result);
    const Space v1515_7 = compose(v1515_5,v1515_6);
    const Space v1515_8 = intersect(constant_8,v1515_2);
    const Space v1515_9 = (has_head(v1515_8) ? constant_9 : Space{});
    const Space v1515_10 = compose(v1515_9,v1514_5_tail);
    const Space v1515_11 = unite(v1515_7,v1515_10);
    v1514_5_result = unite(v1514_5_result,v1515_11);
  }
  const Space v1514_5 = std::move(v1514_5_result);
  return v1514_5;
}

static Space routine_165(Context& c, const Path& p0, const Space& s0) {
  Space v1517_6_result;
  for (int v1517_6_label = 1; v1517_6_label <= 2; ++v1517_6_label) {
    const Space v1517_6_tail = child(s0,v1517_6_label);
    if (v1517_6_tail.empty()) continue;
    const Path v1517_6_head{v1517_6_label};
    const Space v1518_2 = singleton(v1517_6_head);
    const Space v1518_3 = intersect(constant_8,v1518_2);
    const Space v1518_4 = (has_head(v1518_3) ? constant_9 : Space{});
    const Space v1518_5 = subtract(constant_0,v1518_4);
    Space v1518_6_result;
    for (int v1518_6_label = 1; v1518_6_label <= 2; ++v1518_6_label) {
      const Space v1518_6_tail = child(v1517_6_tail,v1518_6_label);
      if (v1518_6_tail.empty()) continue;
      const Path v1518_6_head{v1518_6_label};
      const Space v1519_2 = Space{};
      v1518_6_result = unite(v1518_6_result,v1519_2);
    }
    const Space v1518_6 = std::move(v1518_6_result);
    const Space v1518_7 = compose(v1518_5,v1518_6);
    const Space v1518_8 = intersect(constant_8,v1518_2);
    const Space v1518_9 = (has_head(v1518_8) ? constant_9 : Space{});
    Space v1518_12;
    if (!v1518_9.empty()) {
      const Path v1520_10 = concat_path(p0,v1517_6_head);
      Space v1520_11_result;
      for (int v1520_11_label = 1; v1520_11_label <= 2; ++v1520_11_label) {
        const Space v1520_11_tail = child(v1517_6_tail,v1520_11_label);
        if (v1520_11_tail.empty()) continue;
        const Path v1520_11_head{v1520_11_label};
        const Space v1521_2 = singleton(v1520_11_head);
        const Space v1521_3 = intersect(constant_8,v1521_2);
        const Space v1521_4 = (has_head(v1521_3) ? constant_9 : Space{});
        Space v1521_7;
        if (!v1521_4.empty()) {
          const Path v1522_5 = concat_path(v1520_10,v1520_11_head);
          const Space v1522_6 = routine_89(c, v1522_5, v1520_11_tail);
          v1521_7 = compose(v1521_4,v1522_6);
        }
        v1520_11_result = unite(v1520_11_result,v1521_7);
      }
      const Space v1520_11 = std::move(v1520_11_result);
      v1518_12 = compose(v1518_9,v1520_11);
    }
    const Space v1518_13 = unite(v1518_7,v1518_12);
    v1517_6_result = unite(v1517_6_result,v1518_13);
  }
  const Space v1517_6 = std::move(v1517_6_result);
  return v1517_6;
}

static Space routine_166(Context& c, const Path& p0, const Space& s0) {
  Space v1523_8_result;
  for (int v1523_8_label = 1; v1523_8_label <= 2; ++v1523_8_label) {
    const Space v1523_8_tail = child(s0,v1523_8_label);
    if (v1523_8_tail.empty()) continue;
    const Path v1523_8_head{v1523_8_label};
    const Space v1524_2 = singleton(v1523_8_head);
    const Space v1524_3 = intersect(constant_8,v1524_2);
    const Space v1524_4 = (has_head(v1524_3) ? constant_9 : Space{});
    const Space v1524_5 = subtract(constant_0,v1524_4);
    Space v1524_6_result;
    for (int v1524_6_label = 1; v1524_6_label <= 2; ++v1524_6_label) {
      const Space v1524_6_tail = child(v1523_8_tail,v1524_6_label);
      if (v1524_6_tail.empty()) continue;
      const Path v1524_6_head{v1524_6_label};
      const Space v1525_2 = Space{};
      v1524_6_result = unite(v1524_6_result,v1525_2);
    }
    const Space v1524_6 = std::move(v1524_6_result);
    const Space v1524_7 = compose(v1524_5,v1524_6);
    const Space v1524_8 = intersect(constant_8,v1524_2);
    const Space v1524_9 = (has_head(v1524_8) ? constant_9 : Space{});
    Space v1524_12;
    if (!v1524_9.empty()) {
      const Path v1526_10 = concat_path(p0,v1523_8_head);
      Space v1526_11_result;
      for (int v1526_11_label = 1; v1526_11_label <= 2; ++v1526_11_label) {
        const Space v1526_11_tail = child(v1523_8_tail,v1526_11_label);
        if (v1526_11_tail.empty()) continue;
        const Path v1526_11_head{v1526_11_label};
        const Space v1527_2 = singleton(v1526_11_head);
        const Space v1527_3 = intersect(constant_8,v1527_2);
        const Space v1527_4 = (has_head(v1527_3) ? constant_9 : Space{});
        const Space v1527_5 = subtract(constant_0,v1527_4);
        Space v1527_7;
        if (!v1527_5.empty()) {
          const Space v1528_6 = routine_124(c, v1526_11_head, v1526_10, v1526_11_tail);
          v1527_7 = compose(v1527_5,v1528_6);
        }
        const Space v1527_8 = intersect(constant_8,v1527_2);
        const Space v1527_9 = (has_head(v1527_8) ? constant_9 : Space{});
        Space v1527_11;
        if (!v1527_9.empty()) {
          const Space v1529_10 = routine_125(c, v1526_11_head, v1526_10, v1526_11_tail);
          v1527_11 = compose(v1527_9,v1529_10);
        }
        const Space v1527_12 = unite(v1527_7,v1527_11);
        v1526_11_result = unite(v1526_11_result,v1527_12);
      }
      const Space v1526_11 = std::move(v1526_11_result);
      v1524_12 = compose(v1524_9,v1526_11);
    }
    const Space v1524_13 = unite(v1524_7,v1524_12);
    v1523_8_result = unite(v1523_8_result,v1524_13);
  }
  const Space v1523_8 = std::move(v1523_8_result);
  return v1523_8;
}

static Space routine_167(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1530_12_result;
  for (int v1530_12_label = 1; v1530_12_label <= 2; ++v1530_12_label) {
    const Space v1530_12_tail = child(s0,v1530_12_label);
    if (v1530_12_tail.empty()) continue;
    const Path v1530_12_head{v1530_12_label};
    const Space v1531_2 = singleton(v1530_12_head);
    const Space v1531_3 = intersect(constant_8,v1531_2);
    const Space v1531_4 = (has_head(v1531_3) ? constant_9 : Space{});
    const Space v1531_5 = subtract(constant_0,v1531_4);
    Space v1531_8;
    if (!v1531_5.empty()) {
      const Path v1532_6 = concat_path(p0,v1530_12_head);
      Space v1532_7_result;
      for (int v1532_7_label = 1; v1532_7_label <= 2; ++v1532_7_label) {
        const Space v1532_7_tail = child(v1530_12_tail,v1532_7_label);
        if (v1532_7_tail.empty()) continue;
        const Path v1532_7_head{v1532_7_label};
        const Space v1533_2 = singleton(v1532_7_head);
        const Space v1533_3 = intersect(constant_8,v1533_2);
        const Space v1533_4 = (has_head(v1533_3) ? constant_9 : Space{});
        const Space v1533_5 = subtract(constant_0,v1533_4);
        Space v1533_8;
        if (!v1533_5.empty()) {
          const Path v1534_6 = concat_path(v1532_6,v1532_7_head);
          const Space v1534_7 = routine_248(c, v1534_6, p1, v1532_7_tail);
          v1533_8 = compose(v1533_5,v1534_7);
        }
        const Space v1533_9 = intersect(constant_8,v1533_2);
        const Space v1533_10 = (has_head(v1533_9) ? constant_9 : Space{});
        Space v1533_12;
        if (!v1533_10.empty()) {
          const Path v1535_6 = concat_path(v1532_6,v1532_7_head);
          const Space v1535_11 = routine_249(c, v1535_6, p1, v1532_7_tail);
          v1533_12 = compose(v1533_10,v1535_11);
        }
        const Space v1533_13 = unite(v1533_8,v1533_12);
        v1532_7_result = unite(v1532_7_result,v1533_13);
      }
      const Space v1532_7 = std::move(v1532_7_result);
      v1531_8 = compose(v1531_5,v1532_7);
    }
    const Space v1531_9 = intersect(constant_8,v1531_2);
    const Space v1531_10 = (has_head(v1531_9) ? constant_9 : Space{});
    Space v1531_12;
    if (!v1531_10.empty()) {
      const Path v1536_6 = concat_path(p0,v1530_12_head);
      Space v1536_11_result;
      for (int v1536_11_label = 1; v1536_11_label <= 2; ++v1536_11_label) {
        const Space v1536_11_tail = child(v1530_12_tail,v1536_11_label);
        if (v1536_11_tail.empty()) continue;
        const Path v1536_11_head{v1536_11_label};
        const Space v1537_2 = singleton(v1536_11_head);
        const Space v1537_3 = intersect(constant_8,v1537_2);
        const Space v1537_4 = (has_head(v1537_3) ? constant_9 : Space{});
        const Space v1537_5 = subtract(constant_0,v1537_4);
        Space v1537_8;
        if (!v1537_5.empty()) {
          const Path v1538_6 = concat_path(v1536_6,v1536_11_head);
          const Space v1538_7 = routine_248(c, v1538_6, p1, v1536_11_tail);
          v1537_8 = compose(v1537_5,v1538_7);
        }
        const Space v1537_9 = intersect(constant_8,v1537_2);
        const Space v1537_10 = (has_head(v1537_9) ? constant_9 : Space{});
        Space v1537_12;
        if (!v1537_10.empty()) {
          const Path v1539_6 = concat_path(v1536_6,v1536_11_head);
          const Space v1539_11 = routine_169(c, v1539_6, p1, v1536_11_tail);
          v1537_12 = compose(v1537_10,v1539_11);
        }
        const Space v1537_13 = unite(v1537_8,v1537_12);
        v1536_11_result = unite(v1536_11_result,v1537_13);
      }
      const Space v1536_11 = std::move(v1536_11_result);
      v1531_12 = compose(v1531_10,v1536_11);
    }
    const Space v1531_13 = unite(v1531_8,v1531_12);
    v1530_12_result = unite(v1530_12_result,v1531_13);
  }
  const Space v1530_12 = std::move(v1530_12_result);
  return v1530_12;
}

static Space routine_168(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1540_12_result;
  for (int v1540_12_label = 1; v1540_12_label <= 2; ++v1540_12_label) {
    const Space v1540_12_tail = child(s0,v1540_12_label);
    if (v1540_12_tail.empty()) continue;
    const Path v1540_12_head{v1540_12_label};
    const Space v1541_2 = singleton(v1540_12_head);
    const Space v1541_3 = intersect(constant_8,v1541_2);
    const Space v1541_4 = (has_head(v1541_3) ? constant_9 : Space{});
    const Space v1541_5 = subtract(constant_0,v1541_4);
    Space v1541_8;
    if (!v1541_5.empty()) {
      const Path v1542_6 = concat_path(p0,v1540_12_head);
      Space v1542_7_result;
      for (int v1542_7_label = 1; v1542_7_label <= 2; ++v1542_7_label) {
        const Space v1542_7_tail = child(v1540_12_tail,v1542_7_label);
        if (v1542_7_tail.empty()) continue;
        const Path v1542_7_head{v1542_7_label};
        const Space v1543_2 = singleton(v1542_7_head);
        const Space v1543_3 = intersect(constant_8,v1543_2);
        const Space v1543_4 = (has_head(v1543_3) ? constant_9 : Space{});
        const Space v1543_5 = subtract(constant_0,v1543_4);
        Space v1543_8;
        if (!v1543_5.empty()) {
          const Path v1544_6 = concat_path(v1542_6,v1542_7_head);
          const Space v1544_7 = routine_248(c, v1544_6, p1, v1542_7_tail);
          v1543_8 = compose(v1543_5,v1544_7);
        }
        const Space v1543_9 = intersect(constant_8,v1543_2);
        const Space v1543_10 = (has_head(v1543_9) ? constant_9 : Space{});
        Space v1543_12;
        if (!v1543_10.empty()) {
          const Path v1545_6 = concat_path(v1542_6,v1542_7_head);
          const Space v1545_11 = routine_249(c, v1545_6, p1, v1542_7_tail);
          v1543_12 = compose(v1543_10,v1545_11);
        }
        const Space v1543_13 = unite(v1543_8,v1543_12);
        v1542_7_result = unite(v1542_7_result,v1543_13);
      }
      const Space v1542_7 = std::move(v1542_7_result);
      v1541_8 = compose(v1541_5,v1542_7);
    }
    const Space v1541_9 = intersect(constant_8,v1541_2);
    const Space v1541_10 = (has_head(v1541_9) ? constant_9 : Space{});
    Space v1541_12;
    if (!v1541_10.empty()) {
      const Path v1546_6 = concat_path(p0,v1540_12_head);
      Space v1546_11_result;
      for (int v1546_11_label = 1; v1546_11_label <= 2; ++v1546_11_label) {
        const Space v1546_11_tail = child(v1540_12_tail,v1546_11_label);
        if (v1546_11_tail.empty()) continue;
        const Path v1546_11_head{v1546_11_label};
        const Space v1547_2 = singleton(v1546_11_head);
        const Space v1547_3 = intersect(constant_8,v1547_2);
        const Space v1547_4 = (has_head(v1547_3) ? constant_9 : Space{});
        const Space v1547_5 = subtract(constant_0,v1547_4);
        Space v1547_7;
        if (!v1547_5.empty()) {
          const Space v1548_6 = routine_217(c, v1546_11_head, p1, v1546_6, v1546_11_tail);
          v1547_7 = compose(v1547_5,v1548_6);
        }
        const Space v1547_8 = intersect(constant_8,v1547_2);
        const Space v1547_9 = (has_head(v1547_8) ? constant_9 : Space{});
        Space v1547_11;
        if (!v1547_9.empty()) {
          const Space v1549_10 = routine_218(c, v1546_11_head, p1, v1546_6, v1546_11_tail);
          v1547_11 = compose(v1547_9,v1549_10);
        }
        const Space v1547_12 = unite(v1547_7,v1547_11);
        v1546_11_result = unite(v1546_11_result,v1547_12);
      }
      const Space v1546_11 = std::move(v1546_11_result);
      v1541_12 = compose(v1541_10,v1546_11);
    }
    const Space v1541_13 = unite(v1541_8,v1541_12);
    v1540_12_result = unite(v1540_12_result,v1541_13);
  }
  const Space v1540_12 = std::move(v1540_12_result);
  return v1540_12;
}

static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1550_12_result;
  for (int v1550_12_label = 1; v1550_12_label <= 2; ++v1550_12_label) {
    const Space v1550_12_tail = child(s0,v1550_12_label);
    if (v1550_12_tail.empty()) continue;
    const Path v1550_12_head{v1550_12_label};
    const Space v1551_2 = singleton(v1550_12_head);
    const Space v1551_3 = intersect(constant_8,v1551_2);
    const Space v1551_4 = (has_head(v1551_3) ? constant_9 : Space{});
    const Space v1551_5 = subtract(constant_0,v1551_4);
    Space v1551_7;
    if (!v1551_5.empty()) {
      Space v1552_6_result;
      for (int v1552_6_label = 1; v1552_6_label <= 2; ++v1552_6_label) {
        const Space v1552_6_tail = child(v1550_12_tail,v1552_6_label);
        if (v1552_6_tail.empty()) continue;
        const Path v1552_6_head{v1552_6_label};
        const Space v1553_2 = singleton(v1552_6_head);
        const Space v1553_3 = intersect(constant_8,v1553_2);
        const Space v1553_4 = (has_head(v1553_3) ? constant_9 : Space{});
        const Space v1553_5 = subtract(constant_0,v1553_4);
        Space v1553_8;
        if (!v1553_5.empty()) {
          const Path v1554_6 = concat_path(v1550_12_head,v1552_6_head);
          const Space v1554_7 = routine_250(c, v1554_6, p1, p0, v1552_6_tail);
          v1553_8 = compose(v1553_5,v1554_7);
        }
        const Space v1553_9 = intersect(constant_8,v1553_2);
        const Space v1553_10 = (has_head(v1553_9) ? constant_9 : Space{});
        Space v1553_12;
        if (!v1553_10.empty()) {
          const Path v1555_6 = concat_path(v1550_12_head,v1552_6_head);
          const Space v1555_11 = routine_251(c, v1555_6, p1, p0, v1552_6_tail);
          v1553_12 = compose(v1553_10,v1555_11);
        }
        const Space v1553_13 = unite(v1553_8,v1553_12);
        v1552_6_result = unite(v1552_6_result,v1553_13);
      }
      const Space v1552_6 = std::move(v1552_6_result);
      v1551_7 = compose(v1551_5,v1552_6);
    }
    const Space v1551_8 = intersect(constant_8,v1551_2);
    const Space v1551_9 = (has_head(v1551_8) ? constant_9 : Space{});
    Space v1551_11;
    if (!v1551_9.empty()) {
      Space v1556_10_result;
      for (int v1556_10_label = 1; v1556_10_label <= 2; ++v1556_10_label) {
        const Space v1556_10_tail = child(v1550_12_tail,v1556_10_label);
        if (v1556_10_tail.empty()) continue;
        const Path v1556_10_head{v1556_10_label};
        const Space v1557_2 = singleton(v1556_10_head);
        const Space v1557_3 = intersect(constant_8,v1557_2);
        const Space v1557_4 = (has_head(v1557_3) ? constant_9 : Space{});
        const Space v1557_5 = subtract(constant_0,v1557_4);
        Space v1557_8;
        if (!v1557_5.empty()) {
          const Path v1558_6 = concat_path(v1550_12_head,v1556_10_head);
          const Space v1558_7 = routine_250(c, v1558_6, p1, p0, v1556_10_tail);
          v1557_8 = compose(v1557_5,v1558_7);
        }
        const Space v1557_9 = intersect(constant_8,v1557_2);
        const Space v1557_10 = (has_head(v1557_9) ? constant_9 : Space{});
        Space v1557_12;
        if (!v1557_10.empty()) {
          const Path v1559_6 = concat_path(v1550_12_head,v1556_10_head);
          const Space v1559_11 = routine_252(c, v1559_6, p1, p0, v1556_10_tail);
          v1557_12 = compose(v1557_10,v1559_11);
        }
        const Space v1557_13 = unite(v1557_8,v1557_12);
        v1556_10_result = unite(v1556_10_result,v1557_13);
      }
      const Space v1556_10 = std::move(v1556_10_result);
      v1551_11 = compose(v1551_9,v1556_10);
    }
    const Space v1551_12 = unite(v1551_7,v1551_11);
    v1550_12_result = unite(v1550_12_result,v1551_12);
  }
  const Space v1550_12 = std::move(v1550_12_result);
  return v1550_12;
}

static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1560_3_result;
  for (int v1560_3_label = 1; v1560_3_label <= 2; ++v1560_3_label) {
    const Space v1560_3_tail = child(s0,v1560_3_label);
    if (v1560_3_tail.empty()) continue;
    const Path v1560_3_head{v1560_3_label};
    const Space v1561_2 = Space{};
    v1560_3_result = unite(v1560_3_result,v1561_2);
  }
  const Space v1560_3 = std::move(v1560_3_result);
  return v1560_3;
}

static Space routine_171(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1562_12_result;
  for (int v1562_12_label = 1; v1562_12_label <= 2; ++v1562_12_label) {
    const Space v1562_12_tail = child(s0,v1562_12_label);
    if (v1562_12_tail.empty()) continue;
    const Path v1562_12_head{v1562_12_label};
    const Space v1563_2 = singleton(v1562_12_head);
    const Space v1563_3 = intersect(constant_8,v1563_2);
    const Space v1563_4 = (has_head(v1563_3) ? constant_9 : Space{});
    Space v1563_12;
    if (!v1563_4.empty()) {
      Space v1564_8;
      if (!constant_0.empty()) {
        const Space v1565_5 = routine_92(c, constant_14, constant_15);
        const Space v1565_6 = routine_93(c, constant_16, constant_17);
        const Space v1565_7 = unite(v1565_5,v1565_6);
        v1564_8 = compose(constant_0,v1565_7);
      }
      const Space v1564_9 = unwrap(v1564_8,p1);
      const Path v1564_10 = concat_path(p0,v1562_12_head);
      Space v1564_11_result;
      for (int v1564_11_label = 1; v1564_11_label <= 2; ++v1564_11_label) {
        const Space v1564_11_tail = child(v1564_9,v1564_11_label);
        if (v1564_11_tail.empty()) continue;
        const Path v1564_11_head{v1564_11_label};
        const Space v1566_2 = singleton(v1564_11_head);
        const Space v1566_3 = intersect(constant_8,v1566_2);
        const Space v1566_4 = (has_head(v1566_3) ? constant_9 : Space{});
        const Space v1566_5 = subtract(constant_0,v1566_4);
        Space v1566_7;
        if (!v1566_5.empty()) {
          const Space v1567_6 = routine_94(c, v1564_11_head, v1564_10, v1564_11_tail, v1562_12_tail);
          v1566_7 = compose(v1566_5,v1567_6);
        }
        const Space v1566_8 = intersect(constant_8,v1566_2);
        const Space v1566_9 = (has_head(v1566_8) ? constant_9 : Space{});
        Space v1566_11;
        if (!v1566_9.empty()) {
          const Space v1568_10 = routine_95(c, v1564_11_head, v1564_10, v1564_11_tail, v1562_12_tail);
          v1566_11 = compose(v1566_9,v1568_10);
        }
        const Space v1566_12 = unite(v1566_7,v1566_11);
        v1564_11_result = unite(v1564_11_result,v1566_12);
      }
      const Space v1564_11 = std::move(v1564_11_result);
      v1563_12 = compose(v1563_4,v1564_11);
    }
    v1562_12_result = unite(v1562_12_result,v1563_12);
  }
  const Space v1562_12 = std::move(v1562_12_result);
  return v1562_12;
}

static Space routine_172(Context& c, const Path& p0, const Space& s0) {
  Space v1569_11_result;
  for (int v1569_11_label = 1; v1569_11_label <= 2; ++v1569_11_label) {
    const Space v1569_11_tail = child(s0,v1569_11_label);
    if (v1569_11_tail.empty()) continue;
    const Path v1569_11_head{v1569_11_label};
    const Space v1570_2 = singleton(v1569_11_head);
    const Space v1570_3 = intersect(constant_8,v1570_2);
    const Space v1570_4 = (has_head(v1570_3) ? constant_9 : Space{});
    const Space v1570_5 = subtract(constant_0,v1570_4);
    Space v1570_8;
    if (!v1570_5.empty()) {
      const Path v1571_6 = concat_path(p0,v1569_11_head);
      Space v1571_7_result;
      for (int v1571_7_label = 1; v1571_7_label <= 2; ++v1571_7_label) {
        const Space v1571_7_tail = child(v1569_11_tail,v1571_7_label);
        if (v1571_7_tail.empty()) continue;
        const Path v1571_7_head{v1571_7_label};
        const Space v1572_2 = singleton(v1571_7_head);
        const Space v1572_3 = intersect(constant_8,v1572_2);
        const Space v1572_4 = (has_head(v1572_3) ? constant_9 : Space{});
        const Space v1572_5 = subtract(constant_0,v1572_4);
        Space v1572_8;
        if (!v1572_5.empty()) {
          const Path v1573_6 = concat_path(v1571_6,v1571_7_head);
          const Space v1573_7 = routine_253(c, v1573_6, v1571_7_tail);
          v1572_8 = compose(v1572_5,v1573_7);
        }
        const Space v1572_9 = intersect(constant_8,v1572_2);
        const Space v1572_10 = (has_head(v1572_9) ? constant_9 : Space{});
        Space v1572_12;
        if (!v1572_10.empty()) {
          const Path v1574_6 = concat_path(v1571_6,v1571_7_head);
          const Space v1574_11 = routine_254(c, v1574_6, v1571_7_tail);
          v1572_12 = compose(v1572_10,v1574_11);
        }
        const Space v1572_13 = unite(v1572_8,v1572_12);
        v1571_7_result = unite(v1571_7_result,v1572_13);
      }
      const Space v1571_7 = std::move(v1571_7_result);
      v1570_8 = compose(v1570_5,v1571_7);
    }
    const Space v1570_9 = intersect(constant_8,v1570_2);
    const Space v1570_10 = (has_head(v1570_9) ? constant_9 : Space{});
    Space v1570_12;
    if (!v1570_10.empty()) {
      const Path v1575_6 = concat_path(p0,v1569_11_head);
      Space v1575_11_result;
      for (int v1575_11_label = 1; v1575_11_label <= 2; ++v1575_11_label) {
        const Space v1575_11_tail = child(v1569_11_tail,v1575_11_label);
        if (v1575_11_tail.empty()) continue;
        const Path v1575_11_head{v1575_11_label};
        const Space v1576_2 = singleton(v1575_11_head);
        const Space v1576_3 = intersect(constant_8,v1576_2);
        const Space v1576_4 = (has_head(v1576_3) ? constant_9 : Space{});
        const Space v1576_5 = subtract(constant_0,v1576_4);
        Space v1576_8;
        if (!v1576_5.empty()) {
          const Path v1577_6 = concat_path(v1575_6,v1575_11_head);
          const Space v1577_7 = routine_253(c, v1577_6, v1575_11_tail);
          v1576_8 = compose(v1576_5,v1577_7);
        }
        const Space v1576_9 = intersect(constant_8,v1576_2);
        const Space v1576_10 = (has_head(v1576_9) ? constant_9 : Space{});
        Space v1576_12;
        if (!v1576_10.empty()) {
          const Path v1578_6 = concat_path(v1575_6,v1575_11_head);
          const Space v1578_11 = routine_130(c, v1578_6, v1575_11_tail);
          v1576_12 = compose(v1576_10,v1578_11);
        }
        const Space v1576_13 = unite(v1576_8,v1576_12);
        v1575_11_result = unite(v1575_11_result,v1576_13);
      }
      const Space v1575_11 = std::move(v1575_11_result);
      v1570_12 = compose(v1570_10,v1575_11);
    }
    const Space v1570_13 = unite(v1570_8,v1570_12);
    v1569_11_result = unite(v1569_11_result,v1570_13);
  }
  const Space v1569_11 = std::move(v1569_11_result);
  return v1569_11;
}

static Space routine_173(Context& c, const Path& p0, const Space& s0) {
  Space v1579_11_result;
  for (int v1579_11_label = 1; v1579_11_label <= 2; ++v1579_11_label) {
    const Space v1579_11_tail = child(s0,v1579_11_label);
    if (v1579_11_tail.empty()) continue;
    const Path v1579_11_head{v1579_11_label};
    const Space v1580_2 = singleton(v1579_11_head);
    const Space v1580_3 = intersect(constant_8,v1580_2);
    const Space v1580_4 = (has_head(v1580_3) ? constant_9 : Space{});
    const Space v1580_5 = subtract(constant_0,v1580_4);
    Space v1580_8;
    if (!v1580_5.empty()) {
      const Path v1581_6 = concat_path(p0,v1579_11_head);
      Space v1581_7_result;
      for (int v1581_7_label = 1; v1581_7_label <= 2; ++v1581_7_label) {
        const Space v1581_7_tail = child(v1579_11_tail,v1581_7_label);
        if (v1581_7_tail.empty()) continue;
        const Path v1581_7_head{v1581_7_label};
        const Space v1582_2 = singleton(v1581_7_head);
        const Space v1582_3 = intersect(constant_8,v1582_2);
        const Space v1582_4 = (has_head(v1582_3) ? constant_9 : Space{});
        const Space v1582_5 = subtract(constant_0,v1582_4);
        Space v1582_8;
        if (!v1582_5.empty()) {
          const Path v1583_6 = concat_path(v1581_6,v1581_7_head);
          const Space v1583_7 = routine_253(c, v1583_6, v1581_7_tail);
          v1582_8 = compose(v1582_5,v1583_7);
        }
        const Space v1582_9 = intersect(constant_8,v1582_2);
        const Space v1582_10 = (has_head(v1582_9) ? constant_9 : Space{});
        Space v1582_12;
        if (!v1582_10.empty()) {
          const Path v1584_6 = concat_path(v1581_6,v1581_7_head);
          const Space v1584_11 = routine_254(c, v1584_6, v1581_7_tail);
          v1582_12 = compose(v1582_10,v1584_11);
        }
        const Space v1582_13 = unite(v1582_8,v1582_12);
        v1581_7_result = unite(v1581_7_result,v1582_13);
      }
      const Space v1581_7 = std::move(v1581_7_result);
      v1580_8 = compose(v1580_5,v1581_7);
    }
    const Space v1580_9 = intersect(constant_8,v1580_2);
    const Space v1580_10 = (has_head(v1580_9) ? constant_9 : Space{});
    Space v1580_12;
    if (!v1580_10.empty()) {
      const Path v1585_6 = concat_path(p0,v1579_11_head);
      Space v1585_11_result;
      for (int v1585_11_label = 1; v1585_11_label <= 2; ++v1585_11_label) {
        const Space v1585_11_tail = child(v1579_11_tail,v1585_11_label);
        if (v1585_11_tail.empty()) continue;
        const Path v1585_11_head{v1585_11_label};
        const Space v1586_2 = singleton(v1585_11_head);
        const Space v1586_3 = intersect(constant_8,v1586_2);
        const Space v1586_4 = (has_head(v1586_3) ? constant_9 : Space{});
        const Space v1586_5 = subtract(constant_0,v1586_4);
        Space v1586_7;
        if (!v1586_5.empty()) {
          const Space v1587_6 = routine_174(c, v1585_11_head, v1585_6, v1585_11_tail);
          v1586_7 = compose(v1586_5,v1587_6);
        }
        const Space v1586_8 = intersect(constant_8,v1586_2);
        const Space v1586_9 = (has_head(v1586_8) ? constant_9 : Space{});
        Space v1586_11;
        if (!v1586_9.empty()) {
          const Space v1588_10 = routine_175(c, v1585_11_head, v1585_6, v1585_11_tail);
          v1586_11 = compose(v1586_9,v1588_10);
        }
        const Space v1586_12 = unite(v1586_7,v1586_11);
        v1585_11_result = unite(v1585_11_result,v1586_12);
      }
      const Space v1585_11 = std::move(v1585_11_result);
      v1580_12 = compose(v1580_10,v1585_11);
    }
    const Space v1580_13 = unite(v1580_8,v1580_12);
    v1579_11_result = unite(v1579_11_result,v1580_13);
  }
  const Space v1579_11 = std::move(v1579_11_result);
  return v1579_11;
}

static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1589_12_result;
  for (int v1589_12_label = 1; v1589_12_label <= 2; ++v1589_12_label) {
    const Space v1589_12_tail = child(s0,v1589_12_label);
    if (v1589_12_tail.empty()) continue;
    const Path v1589_12_head{v1589_12_label};
    const Space v1590_2 = singleton(v1589_12_head);
    const Space v1590_3 = intersect(constant_8,v1590_2);
    const Space v1590_4 = (has_head(v1590_3) ? constant_9 : Space{});
    const Space v1590_5 = subtract(constant_0,v1590_4);
    Space v1590_8;
    if (!v1590_5.empty()) {
      const Path v1591_6 = concat_path(p0,v1589_12_head);
      Space v1591_7_result;
      for (int v1591_7_label = 1; v1591_7_label <= 2; ++v1591_7_label) {
        const Space v1591_7_tail = child(v1589_12_tail,v1591_7_label);
        if (v1591_7_tail.empty()) continue;
        const Path v1591_7_head{v1591_7_label};
        const Space v1592_2 = singleton(v1591_7_head);
        const Space v1592_3 = intersect(constant_8,v1592_2);
        const Space v1592_4 = (has_head(v1592_3) ? constant_9 : Space{});
        const Space v1592_5 = subtract(constant_0,v1592_4);
        Space v1592_8;
        if (!v1592_5.empty()) {
          const Path v1593_6 = concat_path(v1591_6,v1591_7_head);
          const Space v1593_7 = routine_255(c, v1593_6, p1, v1591_7_tail);
          v1592_8 = compose(v1592_5,v1593_7);
        }
        const Space v1592_9 = intersect(constant_8,v1592_2);
        const Space v1592_10 = (has_head(v1592_9) ? constant_9 : Space{});
        Space v1592_12;
        if (!v1592_10.empty()) {
          const Path v1594_6 = concat_path(v1591_6,v1591_7_head);
          const Space v1594_11 = routine_256(c, v1594_6, p1, v1591_7_tail);
          v1592_12 = compose(v1592_10,v1594_11);
        }
        const Space v1592_13 = unite(v1592_8,v1592_12);
        v1591_7_result = unite(v1591_7_result,v1592_13);
      }
      const Space v1591_7 = std::move(v1591_7_result);
      v1590_8 = compose(v1590_5,v1591_7);
    }
    const Space v1590_9 = intersect(constant_8,v1590_2);
    const Space v1590_10 = (has_head(v1590_9) ? constant_9 : Space{});
    Space v1590_12;
    if (!v1590_10.empty()) {
      const Path v1595_6 = concat_path(p0,v1589_12_head);
      Space v1595_11_result;
      for (int v1595_11_label = 1; v1595_11_label <= 2; ++v1595_11_label) {
        const Space v1595_11_tail = child(v1589_12_tail,v1595_11_label);
        if (v1595_11_tail.empty()) continue;
        const Path v1595_11_head{v1595_11_label};
        const Space v1596_2 = singleton(v1595_11_head);
        const Space v1596_3 = intersect(constant_8,v1596_2);
        const Space v1596_4 = (has_head(v1596_3) ? constant_9 : Space{});
        const Space v1596_5 = subtract(constant_0,v1596_4);
        Space v1596_8;
        if (!v1596_5.empty()) {
          const Path v1597_6 = concat_path(v1595_6,v1595_11_head);
          const Space v1597_7 = routine_255(c, v1597_6, p1, v1595_11_tail);
          v1596_8 = compose(v1596_5,v1597_7);
        }
        const Space v1596_9 = intersect(constant_8,v1596_2);
        const Space v1596_10 = (has_head(v1596_9) ? constant_9 : Space{});
        Space v1596_12;
        if (!v1596_10.empty()) {
          const Path v1598_6 = concat_path(v1595_6,v1595_11_head);
          const Space v1598_11 = routine_223(c, v1598_6, p1, v1595_11_tail);
          v1596_12 = compose(v1596_10,v1598_11);
        }
        const Space v1596_13 = unite(v1596_8,v1596_12);
        v1595_11_result = unite(v1595_11_result,v1596_13);
      }
      const Space v1595_11 = std::move(v1595_11_result);
      v1590_12 = compose(v1590_10,v1595_11);
    }
    const Space v1590_13 = unite(v1590_8,v1590_12);
    v1589_12_result = unite(v1589_12_result,v1590_13);
  }
  const Space v1589_12 = std::move(v1589_12_result);
  return v1589_12;
}

static Space routine_175(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1599_13_result;
  for (int v1599_13_label = 1; v1599_13_label <= 2; ++v1599_13_label) {
    const Space v1599_13_tail = child(s0,v1599_13_label);
    if (v1599_13_tail.empty()) continue;
    const Path v1599_13_head{v1599_13_label};
    const Space v1600_2 = singleton(v1599_13_head);
    const Space v1600_3 = intersect(constant_8,v1600_2);
    const Space v1600_4 = (has_head(v1600_3) ? constant_9 : Space{});
    const Space v1600_5 = subtract(constant_0,v1600_4);
    Space v1600_8;
    if (!v1600_5.empty()) {
      const Path v1601_6 = concat_path(p0,v1599_13_head);
      Space v1601_7_result;
      for (int v1601_7_label = 1; v1601_7_label <= 2; ++v1601_7_label) {
        const Space v1601_7_tail = child(v1599_13_tail,v1601_7_label);
        if (v1601_7_tail.empty()) continue;
        const Path v1601_7_head{v1601_7_label};
        const Space v1602_2 = singleton(v1601_7_head);
        const Space v1602_3 = intersect(constant_8,v1602_2);
        const Space v1602_4 = (has_head(v1602_3) ? constant_9 : Space{});
        const Space v1602_5 = subtract(constant_0,v1602_4);
        Space v1602_8;
        if (!v1602_5.empty()) {
          const Path v1603_6 = concat_path(v1601_6,v1601_7_head);
          const Space v1603_7 = routine_255(c, v1603_6, p1, v1601_7_tail);
          v1602_8 = compose(v1602_5,v1603_7);
        }
        const Space v1602_9 = intersect(constant_8,v1602_2);
        const Space v1602_10 = (has_head(v1602_9) ? constant_9 : Space{});
        Space v1602_12;
        if (!v1602_10.empty()) {
          const Path v1604_6 = concat_path(v1601_6,v1601_7_head);
          const Space v1604_11 = routine_256(c, v1604_6, p1, v1601_7_tail);
          v1602_12 = compose(v1602_10,v1604_11);
        }
        const Space v1602_13 = unite(v1602_8,v1602_12);
        v1601_7_result = unite(v1601_7_result,v1602_13);
      }
      const Space v1601_7 = std::move(v1601_7_result);
      v1600_8 = compose(v1600_5,v1601_7);
    }
    const Space v1600_9 = intersect(constant_8,v1600_2);
    const Space v1600_10 = (has_head(v1600_9) ? constant_9 : Space{});
    Space v1600_14;
    if (!v1600_10.empty()) {
      Space v1605_11_result;
      for (int v1605_11_label = 1; v1605_11_label <= 2; ++v1605_11_label) {
        const Space v1605_11_tail = child(v1599_13_tail,v1605_11_label);
        if (v1605_11_tail.empty()) continue;
        const Path v1605_11_head{v1605_11_label};
        const Space v1606_2 = singleton(v1605_11_head);
        const Space v1606_3 = intersect(constant_8,v1606_2);
        const Space v1606_4 = (has_head(v1606_3) ? constant_9 : Space{});
        const Space v1606_5 = subtract(constant_0,v1606_4);
        Space v1606_7;
        if (!v1606_5.empty()) {
          const Space v1607_6 = routine_257(c, v1605_11_head, v1605_11_tail);
          v1606_7 = compose(v1606_5,v1607_6);
        }
        const Space v1606_8 = intersect(constant_8,v1606_2);
        const Space v1606_9 = (has_head(v1606_8) ? constant_9 : Space{});
        Space v1606_11;
        if (!v1606_9.empty()) {
          const Space v1608_10 = routine_258(c, v1605_11_head, v1605_11_tail);
          v1606_11 = compose(v1606_9,v1608_10);
        }
        const Space v1606_12 = unite(v1606_7,v1606_11);
        v1605_11_result = unite(v1605_11_result,v1606_12);
      }
      const Space v1605_11 = std::move(v1605_11_result);
      const Space v1605_12 = raffine(constant_25,v1605_11);
      const Space v1605_13 = unite(v1605_12,v1599_13_tail);
      v1600_14 = compose(v1600_10,v1605_13);
    }
    const Path v1609_6 = concat_path(p0,v1599_13_head);
    const Path v1600_15 = concat_path(p1,v1609_6);
    const Space v1600_16 = wrap(v1600_14,v1600_15);
    const Space v1600_17 = unite(v1600_8,v1600_16);
    v1599_13_result = unite(v1599_13_result,v1600_17);
  }
  const Space v1599_13 = std::move(v1599_13_result);
  return v1599_13;
}

static Space routine_176(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1610_13_result;
  for (int v1610_13_label = 1; v1610_13_label <= 2; ++v1610_13_label) {
    const Space v1610_13_tail = child(s0,v1610_13_label);
    if (v1610_13_tail.empty()) continue;
    const Path v1610_13_head{v1610_13_label};
    const Space v1611_2 = singleton(v1610_13_head);
    const Space v1611_3 = intersect(constant_8,v1611_2);
    const Space v1611_4 = (has_head(v1611_3) ? constant_9 : Space{});
    const Space v1611_5 = subtract(constant_0,v1611_4);
    Space v1611_8;
    if (!v1611_5.empty()) {
      const Path v1612_6 = concat_path(p0,v1610_13_head);
      Space v1612_7_result;
      for (int v1612_7_label = 1; v1612_7_label <= 2; ++v1612_7_label) {
        const Space v1612_7_tail = child(v1610_13_tail,v1612_7_label);
        if (v1612_7_tail.empty()) continue;
        const Path v1612_7_head{v1612_7_label};
        const Space v1613_2 = singleton(v1612_7_head);
        const Space v1613_3 = intersect(constant_8,v1613_2);
        const Space v1613_4 = (has_head(v1613_3) ? constant_9 : Space{});
        const Space v1613_5 = subtract(constant_0,v1613_4);
        Space v1613_8;
        if (!v1613_5.empty()) {
          const Path v1614_6 = concat_path(v1612_6,v1612_7_head);
          const Space v1614_7 = routine_259(c, v1614_6, p1, v1612_7_tail, s1);
          v1613_8 = compose(v1613_5,v1614_7);
        }
        const Space v1613_9 = intersect(constant_8,v1613_2);
        const Space v1613_10 = (has_head(v1613_9) ? constant_9 : Space{});
        Space v1613_12;
        if (!v1613_10.empty()) {
          const Path v1615_6 = concat_path(v1612_6,v1612_7_head);
          const Space v1615_11 = routine_260(c, v1615_6, p1, v1612_7_tail, s1);
          v1613_12 = compose(v1613_10,v1615_11);
        }
        const Space v1613_13 = unite(v1613_8,v1613_12);
        v1612_7_result = unite(v1612_7_result,v1613_13);
      }
      const Space v1612_7 = std::move(v1612_7_result);
      v1611_8 = compose(v1611_5,v1612_7);
    }
    const Space v1611_9 = intersect(constant_8,v1611_2);
    const Space v1611_10 = (has_head(v1611_9) ? constant_9 : Space{});
    Space v1611_12;
    if (!v1611_10.empty()) {
      const Path v1616_6 = concat_path(p0,v1610_13_head);
      Space v1616_11_result;
      for (int v1616_11_label = 1; v1616_11_label <= 2; ++v1616_11_label) {
        const Space v1616_11_tail = child(v1610_13_tail,v1616_11_label);
        if (v1616_11_tail.empty()) continue;
        const Path v1616_11_head{v1616_11_label};
        const Space v1617_2 = singleton(v1616_11_head);
        const Space v1617_3 = intersect(constant_8,v1617_2);
        const Space v1617_4 = (has_head(v1617_3) ? constant_9 : Space{});
        const Space v1617_5 = subtract(constant_0,v1617_4);
        Space v1617_8;
        if (!v1617_5.empty()) {
          const Path v1618_6 = concat_path(v1616_6,v1616_11_head);
          const Space v1618_7 = routine_259(c, v1618_6, p1, v1616_11_tail, s1);
          v1617_8 = compose(v1617_5,v1618_7);
        }
        const Space v1617_9 = intersect(constant_8,v1617_2);
        const Space v1617_10 = (has_head(v1617_9) ? constant_9 : Space{});
        Space v1617_12;
        if (!v1617_10.empty()) {
          const Path v1619_6 = concat_path(v1616_6,v1616_11_head);
          const Space v1619_11 = routine_133(c, v1619_6, p1, v1616_11_tail, s1);
          v1617_12 = compose(v1617_10,v1619_11);
        }
        const Space v1617_13 = unite(v1617_8,v1617_12);
        v1616_11_result = unite(v1616_11_result,v1617_13);
      }
      const Space v1616_11 = std::move(v1616_11_result);
      v1611_12 = compose(v1611_10,v1616_11);
    }
    const Space v1611_13 = unite(v1611_8,v1611_12);
    v1610_13_result = unite(v1610_13_result,v1611_13);
  }
  const Space v1610_13 = std::move(v1610_13_result);
  return v1610_13;
}

static Space routine_177(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1620_10_result;
  for (int v1620_10_label = 1; v1620_10_label <= 2; ++v1620_10_label) {
    const Space v1620_10_tail = child(s0,v1620_10_label);
    if (v1620_10_tail.empty()) continue;
    const Path v1620_10_head{v1620_10_label};
    const Space v1621_2 = singleton(v1620_10_head);
    const Space v1621_3 = intersect(constant_8,v1621_2);
    const Space v1621_4 = (has_head(v1621_3) ? constant_9 : Space{});
    const Space v1621_5 = subtract(constant_0,v1621_4);
    Space v1621_8;
    if (!v1621_5.empty()) {
      const Path v1622_6 = concat_path(p0,v1620_10_head);
      Space v1622_7_result;
      for (int v1622_7_label = 1; v1622_7_label <= 2; ++v1622_7_label) {
        const Space v1622_7_tail = child(v1620_10_tail,v1622_7_label);
        if (v1622_7_tail.empty()) continue;
        const Path v1622_7_head{v1622_7_label};
        const Space v1623_2 = singleton(v1622_7_head);
        const Space v1623_3 = intersect(constant_8,v1623_2);
        const Space v1623_4 = (has_head(v1623_3) ? constant_9 : Space{});
        const Space v1623_5 = subtract(constant_0,v1623_4);
        Space v1623_8;
        if (!v1623_5.empty()) {
          const Path v1624_6 = concat_path(v1622_6,v1622_7_head);
          const Space v1624_7 = routine_259(c, v1624_6, p1, v1622_7_tail, s1);
          v1623_8 = compose(v1623_5,v1624_7);
        }
        const Space v1623_9 = intersect(constant_8,v1623_2);
        const Space v1623_10 = (has_head(v1623_9) ? constant_9 : Space{});
        Space v1623_12;
        if (!v1623_10.empty()) {
          const Path v1625_6 = concat_path(v1622_6,v1622_7_head);
          const Space v1625_11 = routine_260(c, v1625_6, p1, v1622_7_tail, s1);
          v1623_12 = compose(v1623_10,v1625_11);
        }
        const Space v1623_13 = unite(v1623_8,v1623_12);
        v1622_7_result = unite(v1622_7_result,v1623_13);
      }
      const Space v1622_7 = std::move(v1622_7_result);
      v1621_8 = compose(v1621_5,v1622_7);
    }
    const Space v1621_9 = intersect(constant_8,v1621_2);
    const Space v1621_10 = (has_head(v1621_9) ? constant_9 : Space{});
    const Space v1621_11 = unwrap(v1620_10_tail,p1);
    const Path v1626_6 = concat_path(p0,v1620_10_head);
    const Space v1621_12 = wrap(v1621_11,v1626_6);
    const Space v1621_13 = compose(v1621_12,s1);
    const Space v1621_14 = compose(v1621_10,v1621_13);
    const Space v1621_15 = unite(v1621_8,v1621_14);
    v1620_10_result = unite(v1620_10_result,v1621_15);
  }
  const Space v1620_10 = std::move(v1620_10_result);
  return v1620_10;
}

static Space routine_178(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1627_3_result;
  for (int v1627_3_label = 1; v1627_3_label <= 2; ++v1627_3_label) {
    const Space v1627_3_tail = child(s0,v1627_3_label);
    if (v1627_3_tail.empty()) continue;
    const Path v1627_3_head{v1627_3_label};
    const Space v1628_2 = Space{};
    v1627_3_result = unite(v1627_3_result,v1628_2);
  }
  const Space v1627_3 = std::move(v1627_3_result);
  return v1627_3;
}

static Space routine_179(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1629_12_result;
  for (int v1629_12_label = 1; v1629_12_label <= 2; ++v1629_12_label) {
    const Space v1629_12_tail = child(s0,v1629_12_label);
    if (v1629_12_tail.empty()) continue;
    const Path v1629_12_head{v1629_12_label};
    const Space v1630_2 = singleton(v1629_12_head);
    const Space v1630_3 = intersect(constant_8,v1630_2);
    const Space v1630_4 = (has_head(v1630_3) ? constant_9 : Space{});
    Space v1630_14;
    if (!v1630_4.empty()) {
      Space v1631_8;
      if (!constant_0.empty()) {
        const Space v1632_5 = routine_98(c, constant_14, constant_15);
        const Space v1632_6 = routine_99(c, constant_16, constant_17);
        const Space v1632_7 = unite(v1632_5,v1632_6);
        v1631_8 = compose(constant_0,v1632_7);
      }
      const Space v1631_9 = unwrap(v1631_8,p1);
      const Space v1631_10 = unwrap(v1631_9,p0);
      const Space v1631_11 = unwrap(v1631_10,v1629_12_head);
      const Space v1631_12 = unwrap(v1631_11,p1);
      Space v1631_13_result;
      for (int v1631_13_label = 1; v1631_13_label <= 2; ++v1631_13_label) {
        const Space v1631_13_tail = child(v1631_12,v1631_13_label);
        if (v1631_13_tail.empty()) continue;
        const Path v1631_13_head{v1631_13_label};
        const Space v1633_2 = singleton(v1631_13_head);
        const Space v1633_3 = intersect(constant_8,v1633_2);
        const Space v1633_4 = (has_head(v1633_3) ? constant_9 : Space{});
        const Space v1633_5 = subtract(constant_0,v1633_4);
        Space v1633_7;
        if (!v1633_5.empty()) {
          const Space v1634_6 = routine_100(c, v1631_13_head, v1631_13_tail, v1629_12_tail);
          v1633_7 = compose(v1633_5,v1634_6);
        }
        const Space v1633_8 = intersect(constant_8,v1633_2);
        const Space v1633_9 = (has_head(v1633_8) ? constant_9 : Space{});
        Space v1633_11;
        if (!v1633_9.empty()) {
          const Space v1635_10 = routine_101(c, v1631_13_head, v1631_13_tail, v1629_12_tail);
          v1633_11 = compose(v1633_9,v1635_10);
        }
        const Space v1633_12 = unite(v1633_7,v1633_11);
        v1631_13_result = unite(v1631_13_result,v1633_12);
      }
      const Space v1631_13 = std::move(v1631_13_result);
      v1630_14 = compose(v1630_4,v1631_13);
    }
    v1629_12_result = unite(v1629_12_result,v1630_14);
  }
  const Space v1629_12 = std::move(v1629_12_result);
  return v1629_12;
}

static Space routine_180(Context& c, const Path& p0, const Space& s0) {
  Space v1636_11_result;
  for (int v1636_11_label = 1; v1636_11_label <= 2; ++v1636_11_label) {
    const Space v1636_11_tail = child(s0,v1636_11_label);
    if (v1636_11_tail.empty()) continue;
    const Path v1636_11_head{v1636_11_label};
    const Space v1637_2 = singleton(v1636_11_head);
    const Space v1637_3 = intersect(constant_8,v1637_2);
    const Space v1637_4 = (has_head(v1637_3) ? constant_9 : Space{});
    const Space v1637_5 = subtract(constant_0,v1637_4);
    Space v1637_8;
    if (!v1637_5.empty()) {
      const Path v1638_6 = concat_path(p0,v1636_11_head);
      Space v1638_7_result;
      for (int v1638_7_label = 1; v1638_7_label <= 2; ++v1638_7_label) {
        const Space v1638_7_tail = child(v1636_11_tail,v1638_7_label);
        if (v1638_7_tail.empty()) continue;
        const Path v1638_7_head{v1638_7_label};
        const Space v1639_2 = singleton(v1638_7_head);
        const Space v1639_3 = intersect(constant_8,v1639_2);
        const Space v1639_4 = (has_head(v1639_3) ? constant_9 : Space{});
        const Space v1639_5 = subtract(constant_0,v1639_4);
        Space v1639_8;
        if (!v1639_5.empty()) {
          const Path v1640_6 = concat_path(v1638_6,v1638_7_head);
          const Space v1640_7 = routine_261(c, v1640_6, v1638_7_tail);
          v1639_8 = compose(v1639_5,v1640_7);
        }
        const Space v1639_9 = intersect(constant_8,v1639_2);
        const Space v1639_10 = (has_head(v1639_9) ? constant_9 : Space{});
        Space v1639_12;
        if (!v1639_10.empty()) {
          const Path v1641_6 = concat_path(v1638_6,v1638_7_head);
          const Space v1641_11 = routine_262(c, v1641_6, v1638_7_tail);
          v1639_12 = compose(v1639_10,v1641_11);
        }
        const Space v1639_13 = unite(v1639_8,v1639_12);
        v1638_7_result = unite(v1638_7_result,v1639_13);
      }
      const Space v1638_7 = std::move(v1638_7_result);
      v1637_8 = compose(v1637_5,v1638_7);
    }
    const Space v1637_9 = intersect(constant_8,v1637_2);
    const Space v1637_10 = (has_head(v1637_9) ? constant_9 : Space{});
    Space v1637_12;
    if (!v1637_10.empty()) {
      const Path v1642_6 = concat_path(p0,v1636_11_head);
      Space v1642_11_result;
      for (int v1642_11_label = 1; v1642_11_label <= 2; ++v1642_11_label) {
        const Space v1642_11_tail = child(v1636_11_tail,v1642_11_label);
        if (v1642_11_tail.empty()) continue;
        const Path v1642_11_head{v1642_11_label};
        const Space v1643_2 = singleton(v1642_11_head);
        const Space v1643_3 = intersect(constant_8,v1643_2);
        const Space v1643_4 = (has_head(v1643_3) ? constant_9 : Space{});
        const Space v1643_5 = subtract(constant_0,v1643_4);
        Space v1643_8;
        if (!v1643_5.empty()) {
          const Path v1644_6 = concat_path(v1642_6,v1642_11_head);
          const Space v1644_7 = routine_261(c, v1644_6, v1642_11_tail);
          v1643_8 = compose(v1643_5,v1644_7);
        }
        const Space v1643_9 = intersect(constant_8,v1643_2);
        const Space v1643_10 = (has_head(v1643_9) ? constant_9 : Space{});
        Space v1643_12;
        if (!v1643_10.empty()) {
          const Path v1645_6 = concat_path(v1642_6,v1642_11_head);
          const Space v1645_11 = routine_138(c, v1645_6, v1642_11_tail);
          v1643_12 = compose(v1643_10,v1645_11);
        }
        const Space v1643_13 = unite(v1643_8,v1643_12);
        v1642_11_result = unite(v1642_11_result,v1643_13);
      }
      const Space v1642_11 = std::move(v1642_11_result);
      v1637_12 = compose(v1637_10,v1642_11);
    }
    const Space v1637_13 = unite(v1637_8,v1637_12);
    v1636_11_result = unite(v1636_11_result,v1637_13);
  }
  const Space v1636_11 = std::move(v1636_11_result);
  return v1636_11;
}

static Space routine_181(Context& c, const Path& p0, const Space& s0) {
  Space v1646_11_result;
  for (int v1646_11_label = 1; v1646_11_label <= 2; ++v1646_11_label) {
    const Space v1646_11_tail = child(s0,v1646_11_label);
    if (v1646_11_tail.empty()) continue;
    const Path v1646_11_head{v1646_11_label};
    const Space v1647_2 = singleton(v1646_11_head);
    const Space v1647_3 = intersect(constant_8,v1647_2);
    const Space v1647_4 = (has_head(v1647_3) ? constant_9 : Space{});
    const Space v1647_5 = subtract(constant_0,v1647_4);
    Space v1647_8;
    if (!v1647_5.empty()) {
      const Path v1648_6 = concat_path(p0,v1646_11_head);
      Space v1648_7_result;
      for (int v1648_7_label = 1; v1648_7_label <= 2; ++v1648_7_label) {
        const Space v1648_7_tail = child(v1646_11_tail,v1648_7_label);
        if (v1648_7_tail.empty()) continue;
        const Path v1648_7_head{v1648_7_label};
        const Space v1649_2 = singleton(v1648_7_head);
        const Space v1649_3 = intersect(constant_8,v1649_2);
        const Space v1649_4 = (has_head(v1649_3) ? constant_9 : Space{});
        const Space v1649_5 = subtract(constant_0,v1649_4);
        Space v1649_8;
        if (!v1649_5.empty()) {
          const Path v1650_6 = concat_path(v1648_6,v1648_7_head);
          const Space v1650_7 = routine_261(c, v1650_6, v1648_7_tail);
          v1649_8 = compose(v1649_5,v1650_7);
        }
        const Space v1649_9 = intersect(constant_8,v1649_2);
        const Space v1649_10 = (has_head(v1649_9) ? constant_9 : Space{});
        Space v1649_12;
        if (!v1649_10.empty()) {
          const Path v1651_6 = concat_path(v1648_6,v1648_7_head);
          const Space v1651_11 = routine_262(c, v1651_6, v1648_7_tail);
          v1649_12 = compose(v1649_10,v1651_11);
        }
        const Space v1649_13 = unite(v1649_8,v1649_12);
        v1648_7_result = unite(v1648_7_result,v1649_13);
      }
      const Space v1648_7 = std::move(v1648_7_result);
      v1647_8 = compose(v1647_5,v1648_7);
    }
    const Space v1647_9 = intersect(constant_8,v1647_2);
    const Space v1647_10 = (has_head(v1647_9) ? constant_9 : Space{});
    Space v1647_12;
    if (!v1647_10.empty()) {
      const Path v1652_6 = concat_path(p0,v1646_11_head);
      Space v1652_11_result;
      for (int v1652_11_label = 1; v1652_11_label <= 2; ++v1652_11_label) {
        const Space v1652_11_tail = child(v1646_11_tail,v1652_11_label);
        if (v1652_11_tail.empty()) continue;
        const Path v1652_11_head{v1652_11_label};
        const Space v1653_2 = singleton(v1652_11_head);
        const Space v1653_3 = intersect(constant_8,v1653_2);
        const Space v1653_4 = (has_head(v1653_3) ? constant_9 : Space{});
        const Space v1653_5 = subtract(constant_0,v1653_4);
        Space v1653_7;
        if (!v1653_5.empty()) {
          const Space v1654_6 = routine_182(c, v1652_11_head, v1652_6, v1652_11_tail);
          v1653_7 = compose(v1653_5,v1654_6);
        }
        const Space v1653_8 = intersect(constant_8,v1653_2);
        const Space v1653_9 = (has_head(v1653_8) ? constant_9 : Space{});
        Space v1653_11;
        if (!v1653_9.empty()) {
          const Space v1655_10 = routine_183(c, v1652_11_head, v1652_6, v1652_11_tail);
          v1653_11 = compose(v1653_9,v1655_10);
        }
        const Space v1653_12 = unite(v1653_7,v1653_11);
        v1652_11_result = unite(v1652_11_result,v1653_12);
      }
      const Space v1652_11 = std::move(v1652_11_result);
      v1647_12 = compose(v1647_10,v1652_11);
    }
    const Space v1647_13 = unite(v1647_8,v1647_12);
    v1646_11_result = unite(v1646_11_result,v1647_13);
  }
  const Space v1646_11 = std::move(v1646_11_result);
  return v1646_11;
}

static Space routine_182(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1656_12_result;
  for (int v1656_12_label = 1; v1656_12_label <= 2; ++v1656_12_label) {
    const Space v1656_12_tail = child(s0,v1656_12_label);
    if (v1656_12_tail.empty()) continue;
    const Path v1656_12_head{v1656_12_label};
    const Space v1657_2 = singleton(v1656_12_head);
    const Space v1657_3 = intersect(constant_8,v1657_2);
    const Space v1657_4 = (has_head(v1657_3) ? constant_9 : Space{});
    const Space v1657_5 = subtract(constant_0,v1657_4);
    Space v1657_8;
    if (!v1657_5.empty()) {
      const Path v1658_6 = concat_path(p0,v1656_12_head);
      Space v1658_7_result;
      for (int v1658_7_label = 1; v1658_7_label <= 2; ++v1658_7_label) {
        const Space v1658_7_tail = child(v1656_12_tail,v1658_7_label);
        if (v1658_7_tail.empty()) continue;
        const Path v1658_7_head{v1658_7_label};
        const Space v1659_2 = singleton(v1658_7_head);
        const Space v1659_3 = intersect(constant_8,v1659_2);
        const Space v1659_4 = (has_head(v1659_3) ? constant_9 : Space{});
        const Space v1659_5 = subtract(constant_0,v1659_4);
        Space v1659_8;
        if (!v1659_5.empty()) {
          const Path v1660_6 = concat_path(v1658_6,v1658_7_head);
          const Space v1660_7 = routine_263(c, v1660_6, p1, v1658_7_tail);
          v1659_8 = compose(v1659_5,v1660_7);
        }
        const Space v1659_9 = intersect(constant_8,v1659_2);
        const Space v1659_10 = (has_head(v1659_9) ? constant_9 : Space{});
        Space v1659_12;
        if (!v1659_10.empty()) {
          const Path v1661_6 = concat_path(v1658_6,v1658_7_head);
          const Space v1661_11 = routine_264(c, v1661_6, p1, v1658_7_tail);
          v1659_12 = compose(v1659_10,v1661_11);
        }
        const Space v1659_13 = unite(v1659_8,v1659_12);
        v1658_7_result = unite(v1658_7_result,v1659_13);
      }
      const Space v1658_7 = std::move(v1658_7_result);
      v1657_8 = compose(v1657_5,v1658_7);
    }
    const Space v1657_9 = intersect(constant_8,v1657_2);
    const Space v1657_10 = (has_head(v1657_9) ? constant_9 : Space{});
    Space v1657_12;
    if (!v1657_10.empty()) {
      const Path v1662_6 = concat_path(p0,v1656_12_head);
      Space v1662_11_result;
      for (int v1662_11_label = 1; v1662_11_label <= 2; ++v1662_11_label) {
        const Space v1662_11_tail = child(v1656_12_tail,v1662_11_label);
        if (v1662_11_tail.empty()) continue;
        const Path v1662_11_head{v1662_11_label};
        const Space v1663_2 = singleton(v1662_11_head);
        const Space v1663_3 = intersect(constant_8,v1663_2);
        const Space v1663_4 = (has_head(v1663_3) ? constant_9 : Space{});
        const Space v1663_5 = subtract(constant_0,v1663_4);
        Space v1663_8;
        if (!v1663_5.empty()) {
          const Path v1664_6 = concat_path(v1662_6,v1662_11_head);
          const Space v1664_7 = routine_263(c, v1664_6, p1, v1662_11_tail);
          v1663_8 = compose(v1663_5,v1664_7);
        }
        const Space v1663_9 = intersect(constant_8,v1663_2);
        const Space v1663_10 = (has_head(v1663_9) ? constant_9 : Space{});
        Space v1663_12;
        if (!v1663_10.empty()) {
          const Path v1665_6 = concat_path(v1662_6,v1662_11_head);
          const Space v1665_11 = routine_230(c, v1665_6, p1, v1662_11_tail);
          v1663_12 = compose(v1663_10,v1665_11);
        }
        const Space v1663_13 = unite(v1663_8,v1663_12);
        v1662_11_result = unite(v1662_11_result,v1663_13);
      }
      const Space v1662_11 = std::move(v1662_11_result);
      v1657_12 = compose(v1657_10,v1662_11);
    }
    const Space v1657_13 = unite(v1657_8,v1657_12);
    v1656_12_result = unite(v1656_12_result,v1657_13);
  }
  const Space v1656_12 = std::move(v1656_12_result);
  return v1656_12;
}

static Space routine_183(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1666_13_result;
  for (int v1666_13_label = 1; v1666_13_label <= 2; ++v1666_13_label) {
    const Space v1666_13_tail = child(s0,v1666_13_label);
    if (v1666_13_tail.empty()) continue;
    const Path v1666_13_head{v1666_13_label};
    const Space v1667_2 = singleton(v1666_13_head);
    const Space v1667_3 = intersect(constant_8,v1667_2);
    const Space v1667_4 = (has_head(v1667_3) ? constant_9 : Space{});
    const Space v1667_5 = subtract(constant_0,v1667_4);
    Space v1667_8;
    if (!v1667_5.empty()) {
      const Path v1668_6 = concat_path(p0,v1666_13_head);
      Space v1668_7_result;
      for (int v1668_7_label = 1; v1668_7_label <= 2; ++v1668_7_label) {
        const Space v1668_7_tail = child(v1666_13_tail,v1668_7_label);
        if (v1668_7_tail.empty()) continue;
        const Path v1668_7_head{v1668_7_label};
        const Space v1669_2 = singleton(v1668_7_head);
        const Space v1669_3 = intersect(constant_8,v1669_2);
        const Space v1669_4 = (has_head(v1669_3) ? constant_9 : Space{});
        const Space v1669_5 = subtract(constant_0,v1669_4);
        Space v1669_8;
        if (!v1669_5.empty()) {
          const Path v1670_6 = concat_path(v1668_6,v1668_7_head);
          const Space v1670_7 = routine_263(c, v1670_6, p1, v1668_7_tail);
          v1669_8 = compose(v1669_5,v1670_7);
        }
        const Space v1669_9 = intersect(constant_8,v1669_2);
        const Space v1669_10 = (has_head(v1669_9) ? constant_9 : Space{});
        Space v1669_12;
        if (!v1669_10.empty()) {
          const Path v1671_6 = concat_path(v1668_6,v1668_7_head);
          const Space v1671_11 = routine_264(c, v1671_6, p1, v1668_7_tail);
          v1669_12 = compose(v1669_10,v1671_11);
        }
        const Space v1669_13 = unite(v1669_8,v1669_12);
        v1668_7_result = unite(v1668_7_result,v1669_13);
      }
      const Space v1668_7 = std::move(v1668_7_result);
      v1667_8 = compose(v1667_5,v1668_7);
    }
    const Space v1667_9 = intersect(constant_8,v1667_2);
    const Space v1667_10 = (has_head(v1667_9) ? constant_9 : Space{});
    Space v1667_14;
    if (!v1667_10.empty()) {
      Space v1672_11_result;
      for (int v1672_11_label = 1; v1672_11_label <= 2; ++v1672_11_label) {
        const Space v1672_11_tail = child(v1666_13_tail,v1672_11_label);
        if (v1672_11_tail.empty()) continue;
        const Path v1672_11_head{v1672_11_label};
        const Space v1673_2 = singleton(v1672_11_head);
        const Space v1673_3 = intersect(constant_8,v1673_2);
        const Space v1673_4 = (has_head(v1673_3) ? constant_9 : Space{});
        const Space v1673_5 = subtract(constant_0,v1673_4);
        Space v1673_7;
        if (!v1673_5.empty()) {
          const Space v1674_6 = routine_265(c, v1672_11_head, v1672_11_tail);
          v1673_7 = compose(v1673_5,v1674_6);
        }
        const Space v1673_8 = intersect(constant_8,v1673_2);
        const Space v1673_9 = (has_head(v1673_8) ? constant_9 : Space{});
        Space v1673_11;
        if (!v1673_9.empty()) {
          const Space v1675_10 = routine_266(c, v1672_11_head, v1672_11_tail);
          v1673_11 = compose(v1673_9,v1675_10);
        }
        const Space v1673_12 = unite(v1673_7,v1673_11);
        v1672_11_result = unite(v1672_11_result,v1673_12);
      }
      const Space v1672_11 = std::move(v1672_11_result);
      const Space v1672_12 = raffine(constant_25,v1672_11);
      const Space v1672_13 = unite(v1672_12,v1666_13_tail);
      v1667_14 = compose(v1667_10,v1672_13);
    }
    const Path v1676_6 = concat_path(p0,v1666_13_head);
    const Path v1667_15 = concat_path(p1,v1676_6);
    const Space v1667_16 = wrap(v1667_14,v1667_15);
    const Space v1667_17 = unite(v1667_8,v1667_16);
    v1666_13_result = unite(v1666_13_result,v1667_17);
  }
  const Space v1666_13 = std::move(v1666_13_result);
  return v1666_13;
}

static Space routine_184(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1677_12_result;
  for (int v1677_12_label = 1; v1677_12_label <= 2; ++v1677_12_label) {
    const Space v1677_12_tail = child(s0,v1677_12_label);
    if (v1677_12_tail.empty()) continue;
    const Path v1677_12_head{v1677_12_label};
    const Space v1678_2 = singleton(v1677_12_head);
    const Space v1678_3 = intersect(constant_8,v1678_2);
    const Space v1678_4 = (has_head(v1678_3) ? constant_9 : Space{});
    const Space v1678_5 = subtract(constant_0,v1678_4);
    Space v1678_8;
    if (!v1678_5.empty()) {
      const Path v1679_6 = concat_path(p0,v1677_12_head);
      Space v1679_7_result;
      for (int v1679_7_label = 1; v1679_7_label <= 2; ++v1679_7_label) {
        const Space v1679_7_tail = child(v1677_12_tail,v1679_7_label);
        if (v1679_7_tail.empty()) continue;
        const Path v1679_7_head{v1679_7_label};
        const Space v1680_2 = singleton(v1679_7_head);
        const Space v1680_3 = intersect(constant_8,v1680_2);
        const Space v1680_4 = (has_head(v1680_3) ? constant_9 : Space{});
        const Space v1680_5 = subtract(constant_0,v1680_4);
        Space v1680_8;
        if (!v1680_5.empty()) {
          const Path v1681_6 = concat_path(v1679_6,v1679_7_head);
          const Space v1681_7 = routine_267(c, v1681_6, v1679_7_tail, s1);
          v1680_8 = compose(v1680_5,v1681_7);
        }
        const Space v1680_9 = intersect(constant_8,v1680_2);
        const Space v1680_10 = (has_head(v1680_9) ? constant_9 : Space{});
        Space v1680_12;
        if (!v1680_10.empty()) {
          const Path v1682_6 = concat_path(v1679_6,v1679_7_head);
          const Space v1682_11 = routine_268(c, v1682_6, v1679_7_tail, s1);
          v1680_12 = compose(v1680_10,v1682_11);
        }
        const Space v1680_13 = unite(v1680_8,v1680_12);
        v1679_7_result = unite(v1679_7_result,v1680_13);
      }
      const Space v1679_7 = std::move(v1679_7_result);
      v1678_8 = compose(v1678_5,v1679_7);
    }
    const Space v1678_9 = intersect(constant_8,v1678_2);
    const Space v1678_10 = (has_head(v1678_9) ? constant_9 : Space{});
    Space v1678_12;
    if (!v1678_10.empty()) {
      const Path v1683_6 = concat_path(p0,v1677_12_head);
      Space v1683_11_result;
      for (int v1683_11_label = 1; v1683_11_label <= 2; ++v1683_11_label) {
        const Space v1683_11_tail = child(v1677_12_tail,v1683_11_label);
        if (v1683_11_tail.empty()) continue;
        const Path v1683_11_head{v1683_11_label};
        const Space v1684_2 = singleton(v1683_11_head);
        const Space v1684_3 = intersect(constant_8,v1684_2);
        const Space v1684_4 = (has_head(v1684_3) ? constant_9 : Space{});
        const Space v1684_5 = subtract(constant_0,v1684_4);
        Space v1684_8;
        if (!v1684_5.empty()) {
          const Path v1685_6 = concat_path(v1683_6,v1683_11_head);
          const Space v1685_7 = routine_267(c, v1685_6, v1683_11_tail, s1);
          v1684_8 = compose(v1684_5,v1685_7);
        }
        const Space v1684_9 = intersect(constant_8,v1684_2);
        const Space v1684_10 = (has_head(v1684_9) ? constant_9 : Space{});
        Space v1684_12;
        if (!v1684_10.empty()) {
          const Path v1686_6 = concat_path(v1683_6,v1683_11_head);
          const Space v1686_11 = routine_141(c, v1686_6, v1683_11_tail, s1);
          v1684_12 = compose(v1684_10,v1686_11);
        }
        const Space v1684_13 = unite(v1684_8,v1684_12);
        v1683_11_result = unite(v1683_11_result,v1684_13);
      }
      const Space v1683_11 = std::move(v1683_11_result);
      v1678_12 = compose(v1678_10,v1683_11);
    }
    const Space v1678_13 = unite(v1678_8,v1678_12);
    v1677_12_result = unite(v1677_12_result,v1678_13);
  }
  const Space v1677_12 = std::move(v1677_12_result);
  return v1677_12;
}

static Space routine_185(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1687_9_result;
  for (int v1687_9_label = 1; v1687_9_label <= 2; ++v1687_9_label) {
    const Space v1687_9_tail = child(s0,v1687_9_label);
    if (v1687_9_tail.empty()) continue;
    const Path v1687_9_head{v1687_9_label};
    const Space v1688_2 = singleton(v1687_9_head);
    const Space v1688_3 = intersect(constant_8,v1688_2);
    const Space v1688_4 = (has_head(v1688_3) ? constant_9 : Space{});
    const Space v1688_5 = subtract(constant_0,v1688_4);
    Space v1688_8;
    if (!v1688_5.empty()) {
      const Path v1689_6 = concat_path(p0,v1687_9_head);
      Space v1689_7_result;
      for (int v1689_7_label = 1; v1689_7_label <= 2; ++v1689_7_label) {
        const Space v1689_7_tail = child(v1687_9_tail,v1689_7_label);
        if (v1689_7_tail.empty()) continue;
        const Path v1689_7_head{v1689_7_label};
        const Space v1690_2 = singleton(v1689_7_head);
        const Space v1690_3 = intersect(constant_8,v1690_2);
        const Space v1690_4 = (has_head(v1690_3) ? constant_9 : Space{});
        const Space v1690_5 = subtract(constant_0,v1690_4);
        Space v1690_8;
        if (!v1690_5.empty()) {
          const Path v1691_6 = concat_path(v1689_6,v1689_7_head);
          const Space v1691_7 = routine_267(c, v1691_6, v1689_7_tail, s1);
          v1690_8 = compose(v1690_5,v1691_7);
        }
        const Space v1690_9 = intersect(constant_8,v1690_2);
        const Space v1690_10 = (has_head(v1690_9) ? constant_9 : Space{});
        Space v1690_12;
        if (!v1690_10.empty()) {
          const Path v1692_6 = concat_path(v1689_6,v1689_7_head);
          const Space v1692_11 = routine_268(c, v1692_6, v1689_7_tail, s1);
          v1690_12 = compose(v1690_10,v1692_11);
        }
        const Space v1690_13 = unite(v1690_8,v1690_12);
        v1689_7_result = unite(v1689_7_result,v1690_13);
      }
      const Space v1689_7 = std::move(v1689_7_result);
      v1688_8 = compose(v1688_5,v1689_7);
    }
    const Space v1688_9 = intersect(constant_8,v1688_2);
    const Space v1688_10 = (has_head(v1688_9) ? constant_9 : Space{});
    Space v1688_12;
    if (!v1688_10.empty()) {
      const Path v1693_6 = concat_path(p0,v1687_9_head);
      const Space v1693_11 = routine_186(c, v1693_6, s1);
      v1688_12 = compose(v1688_10,v1693_11);
    }
    const Space v1688_13 = unite(v1688_8,v1688_12);
    v1687_9_result = unite(v1687_9_result,v1688_13);
  }
  const Space v1687_9 = std::move(v1687_9_result);
  return v1687_9;
}

static Space routine_186(Context& c, const Path& p0, const Space& s0) {
  const Space v1694_3 = singleton(p0);
  const Space v1694_4 = intersect(constant_10,v1694_3);
  const Space v1694_6 = unwrap(s0,constant_22);
  const Space v1694_8 = unwrap(s0,constant_23);
  const Space v1694_9 = compose(v1694_6,v1694_8);
  const Space v1694_11 = unwrap(s0,constant_6);
  const Space v1694_12 = compose(v1694_9,v1694_11);
  const Space v1694_13 = compose(v1694_4,v1694_12);
  const Space v1694_15 = intersect(constant_11,v1694_3);
  const Space v1694_16 = compose(v1694_6,v1694_11);
  const Space v1694_18 = unwrap(s0,constant_24);
  const Space v1694_19 = compose(v1694_16,v1694_18);
  const Space v1694_20 = compose(v1694_15,v1694_19);
  const Space v1694_21 = unite(v1694_13,v1694_20);
  const Space v1694_23 = intersect(constant_12,v1694_3);
  const Space v1694_24 = compose(v1694_8,v1694_11);
  const Space v1694_25 = compose(v1694_24,v1694_18);
  const Space v1694_26 = compose(v1694_23,v1694_25);
  const Space v1694_27 = unite(v1694_21,v1694_26);
  const Space v1694_29 = intersect(constant_13,v1694_3);
  const Space v1694_30 = compose(v1694_9,v1694_18);
  const Space v1694_31 = compose(v1694_29,v1694_30);
  const Space v1694_32 = unite(v1694_27,v1694_31);
  return v1694_32;
}

static Space routine_187(Context& c, const Path& p0, const Space& s0) {
  Space v1695_2_result;
  for (int v1695_2_label = 1; v1695_2_label <= 2; ++v1695_2_label) {
    const Space v1695_2_tail = child(s0,v1695_2_label);
    if (v1695_2_tail.empty()) continue;
    const Path v1695_2_head{v1695_2_label};
    const Space v1696_2 = Space{};
    v1695_2_result = unite(v1695_2_result,v1696_2);
  }
  const Space v1695_2 = std::move(v1695_2_result);
  return v1695_2;
}

static Space routine_188(Context& c, const Path& p0, const Space& s0) {
  Space v1697_3_result;
  for (int v1697_3_label = 1; v1697_3_label <= 2; ++v1697_3_label) {
    const Space v1697_3_tail = child(s0,v1697_3_label);
    if (v1697_3_tail.empty()) continue;
    const Path v1697_3_head{v1697_3_label};
    const Space v1698_2 = singleton(v1697_3_head);
    const Space v1698_3 = intersect(constant_8,v1698_2);
    const Space v1698_4 = (has_head(v1698_3) ? constant_9 : Space{});
    const Space v1698_5 = compose(v1698_4,v1697_3_tail);
    v1697_3_result = unite(v1697_3_result,v1698_5);
  }
  const Space v1697_3 = std::move(v1697_3_result);
  return v1697_3;
}

static Space routine_189(Context& c, const Path& p0, const Space& s0) {
  Space v1699_2_result;
  for (int v1699_2_label = 1; v1699_2_label <= 2; ++v1699_2_label) {
    const Space v1699_2_tail = child(s0,v1699_2_label);
    if (v1699_2_tail.empty()) continue;
    const Path v1699_2_head{v1699_2_label};
    const Space v1700_2 = Space{};
    v1699_2_result = unite(v1699_2_result,v1700_2);
  }
  const Space v1699_2 = std::move(v1699_2_result);
  return v1699_2;
}

static Space routine_190(Context& c, const Path& p0, const Space& s0) {
  Space v1701_6_result;
  for (int v1701_6_label = 1; v1701_6_label <= 2; ++v1701_6_label) {
    const Space v1701_6_tail = child(s0,v1701_6_label);
    if (v1701_6_tail.empty()) continue;
    const Path v1701_6_head{v1701_6_label};
    const Space v1702_2 = singleton(v1701_6_head);
    const Space v1702_3 = intersect(constant_8,v1702_2);
    const Space v1702_4 = (has_head(v1702_3) ? constant_9 : Space{});
    Space v1702_7;
    if (!v1702_4.empty()) {
      const Path v1703_5 = concat_path(p0,v1701_6_head);
      Space v1703_6_result;
      for (int v1703_6_label = 1; v1703_6_label <= 2; ++v1703_6_label) {
        const Space v1703_6_tail = child(v1701_6_tail,v1703_6_label);
        if (v1703_6_tail.empty()) continue;
        const Path v1703_6_head{v1703_6_label};
        const Space v1704_2 = singleton(v1703_6_head);
        const Space v1704_3 = intersect(constant_8,v1704_2);
        const Space v1704_4 = (has_head(v1704_3) ? constant_9 : Space{});
        const Space v1704_5 = subtract(constant_0,v1704_4);
        Space v1704_7;
        if (!v1704_5.empty()) {
          const Space v1705_6 = routine_106(c, v1703_6_head, v1703_5, v1703_6_tail);
          v1704_7 = compose(v1704_5,v1705_6);
        }
        const Space v1704_8 = intersect(constant_8,v1704_2);
        const Space v1704_9 = (has_head(v1704_8) ? constant_9 : Space{});
        Space v1704_11;
        if (!v1704_9.empty()) {
          const Space v1706_10 = routine_107(c, v1703_6_head, v1703_5, v1703_6_tail);
          v1704_11 = compose(v1704_9,v1706_10);
        }
        const Space v1704_12 = unite(v1704_7,v1704_11);
        v1703_6_result = unite(v1703_6_result,v1704_12);
      }
      const Space v1703_6 = std::move(v1703_6_result);
      v1702_7 = compose(v1702_4,v1703_6);
    }
    v1701_6_result = unite(v1701_6_result,v1702_7);
  }
  const Space v1701_6 = std::move(v1701_6_result);
  return v1701_6;
}

static Space routine_191(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1707_12_result;
  for (int v1707_12_label = 1; v1707_12_label <= 2; ++v1707_12_label) {
    const Space v1707_12_tail = child(s0,v1707_12_label);
    if (v1707_12_tail.empty()) continue;
    const Path v1707_12_head{v1707_12_label};
    const Space v1708_2 = singleton(v1707_12_head);
    const Space v1708_3 = intersect(constant_8,v1708_2);
    const Space v1708_4 = (has_head(v1708_3) ? constant_9 : Space{});
    const Space v1708_5 = subtract(constant_0,v1708_4);
    Space v1708_8;
    if (!v1708_5.empty()) {
      const Path v1709_6 = concat_path(p0,v1707_12_head);
      Space v1709_7_result;
      for (int v1709_7_label = 1; v1709_7_label <= 2; ++v1709_7_label) {
        const Space v1709_7_tail = child(v1707_12_tail,v1709_7_label);
        if (v1709_7_tail.empty()) continue;
        const Path v1709_7_head{v1709_7_label};
        const Space v1710_2 = singleton(v1709_7_head);
        const Space v1710_3 = intersect(constant_8,v1710_2);
        const Space v1710_4 = (has_head(v1710_3) ? constant_9 : Space{});
        const Space v1710_5 = subtract(constant_0,v1710_4);
        Space v1710_8;
        if (!v1710_5.empty()) {
          const Path v1711_6 = concat_path(v1709_6,v1709_7_head);
          const Space v1711_7 = routine_269(c, v1711_6, p1, v1709_7_tail);
          v1710_8 = compose(v1710_5,v1711_7);
        }
        const Space v1710_9 = intersect(constant_8,v1710_2);
        const Space v1710_10 = (has_head(v1710_9) ? constant_9 : Space{});
        Space v1710_12;
        if (!v1710_10.empty()) {
          const Path v1712_6 = concat_path(v1709_6,v1709_7_head);
          const Space v1712_11 = routine_270(c, v1712_6, p1, v1709_7_tail);
          v1710_12 = compose(v1710_10,v1712_11);
        }
        const Space v1710_13 = unite(v1710_8,v1710_12);
        v1709_7_result = unite(v1709_7_result,v1710_13);
      }
      const Space v1709_7 = std::move(v1709_7_result);
      v1708_8 = compose(v1708_5,v1709_7);
    }
    const Space v1708_9 = intersect(constant_8,v1708_2);
    const Space v1708_10 = (has_head(v1708_9) ? constant_9 : Space{});
    Space v1708_12;
    if (!v1708_10.empty()) {
      const Path v1713_6 = concat_path(p0,v1707_12_head);
      Space v1713_11_result;
      for (int v1713_11_label = 1; v1713_11_label <= 2; ++v1713_11_label) {
        const Space v1713_11_tail = child(v1707_12_tail,v1713_11_label);
        if (v1713_11_tail.empty()) continue;
        const Path v1713_11_head{v1713_11_label};
        const Space v1714_2 = singleton(v1713_11_head);
        const Space v1714_3 = intersect(constant_8,v1714_2);
        const Space v1714_4 = (has_head(v1714_3) ? constant_9 : Space{});
        const Space v1714_5 = subtract(constant_0,v1714_4);
        Space v1714_8;
        if (!v1714_5.empty()) {
          const Path v1715_6 = concat_path(v1713_6,v1713_11_head);
          const Space v1715_7 = routine_269(c, v1715_6, p1, v1713_11_tail);
          v1714_8 = compose(v1714_5,v1715_7);
        }
        const Space v1714_9 = intersect(constant_8,v1714_2);
        const Space v1714_10 = (has_head(v1714_9) ? constant_9 : Space{});
        Space v1714_12;
        if (!v1714_10.empty()) {
          const Path v1716_6 = concat_path(v1713_6,v1713_11_head);
          const Space v1716_11 = routine_148(c, v1716_6, p1, v1713_11_tail);
          v1714_12 = compose(v1714_10,v1716_11);
        }
        const Space v1714_13 = unite(v1714_8,v1714_12);
        v1713_11_result = unite(v1713_11_result,v1714_13);
      }
      const Space v1713_11 = std::move(v1713_11_result);
      v1708_12 = compose(v1708_10,v1713_11);
    }
    const Space v1708_13 = unite(v1708_8,v1708_12);
    v1707_12_result = unite(v1707_12_result,v1708_13);
  }
  const Space v1707_12 = std::move(v1707_12_result);
  return v1707_12;
}

static Space routine_192(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1717_12_result;
  for (int v1717_12_label = 1; v1717_12_label <= 2; ++v1717_12_label) {
    const Space v1717_12_tail = child(s0,v1717_12_label);
    if (v1717_12_tail.empty()) continue;
    const Path v1717_12_head{v1717_12_label};
    const Space v1718_2 = singleton(v1717_12_head);
    const Space v1718_3 = intersect(constant_8,v1718_2);
    const Space v1718_4 = (has_head(v1718_3) ? constant_9 : Space{});
    const Space v1718_5 = subtract(constant_0,v1718_4);
    Space v1718_8;
    if (!v1718_5.empty()) {
      const Path v1719_6 = concat_path(p0,v1717_12_head);
      Space v1719_7_result;
      for (int v1719_7_label = 1; v1719_7_label <= 2; ++v1719_7_label) {
        const Space v1719_7_tail = child(v1717_12_tail,v1719_7_label);
        if (v1719_7_tail.empty()) continue;
        const Path v1719_7_head{v1719_7_label};
        const Space v1720_2 = singleton(v1719_7_head);
        const Space v1720_3 = intersect(constant_8,v1720_2);
        const Space v1720_4 = (has_head(v1720_3) ? constant_9 : Space{});
        const Space v1720_5 = subtract(constant_0,v1720_4);
        Space v1720_8;
        if (!v1720_5.empty()) {
          const Path v1721_6 = concat_path(v1719_6,v1719_7_head);
          const Space v1721_7 = routine_269(c, v1721_6, p1, v1719_7_tail);
          v1720_8 = compose(v1720_5,v1721_7);
        }
        const Space v1720_9 = intersect(constant_8,v1720_2);
        const Space v1720_10 = (has_head(v1720_9) ? constant_9 : Space{});
        Space v1720_12;
        if (!v1720_10.empty()) {
          const Path v1722_6 = concat_path(v1719_6,v1719_7_head);
          const Space v1722_11 = routine_270(c, v1722_6, p1, v1719_7_tail);
          v1720_12 = compose(v1720_10,v1722_11);
        }
        const Space v1720_13 = unite(v1720_8,v1720_12);
        v1719_7_result = unite(v1719_7_result,v1720_13);
      }
      const Space v1719_7 = std::move(v1719_7_result);
      v1718_8 = compose(v1718_5,v1719_7);
    }
    const Space v1718_9 = intersect(constant_8,v1718_2);
    const Space v1718_10 = (has_head(v1718_9) ? constant_9 : Space{});
    Space v1718_12;
    if (!v1718_10.empty()) {
      const Path v1723_6 = concat_path(p0,v1717_12_head);
      Space v1723_11_result;
      for (int v1723_11_label = 1; v1723_11_label <= 2; ++v1723_11_label) {
        const Space v1723_11_tail = child(v1717_12_tail,v1723_11_label);
        if (v1723_11_tail.empty()) continue;
        const Path v1723_11_head{v1723_11_label};
        const Space v1724_2 = singleton(v1723_11_head);
        const Space v1724_3 = intersect(constant_8,v1724_2);
        const Space v1724_4 = (has_head(v1724_3) ? constant_9 : Space{});
        const Space v1724_5 = subtract(constant_0,v1724_4);
        Space v1724_7;
        if (!v1724_5.empty()) {
          const Space v1725_6 = routine_193(c, v1723_11_head, p1, v1723_6, v1723_11_tail);
          v1724_7 = compose(v1724_5,v1725_6);
        }
        const Space v1724_8 = intersect(constant_8,v1724_2);
        const Space v1724_9 = (has_head(v1724_8) ? constant_9 : Space{});
        Space v1724_11;
        if (!v1724_9.empty()) {
          const Space v1726_10 = routine_194(c, v1723_11_head, p1, v1723_6, v1723_11_tail);
          v1724_11 = compose(v1724_9,v1726_10);
        }
        const Space v1724_12 = unite(v1724_7,v1724_11);
        v1723_11_result = unite(v1723_11_result,v1724_12);
      }
      const Space v1723_11 = std::move(v1723_11_result);
      v1718_12 = compose(v1718_10,v1723_11);
    }
    const Space v1718_13 = unite(v1718_8,v1718_12);
    v1717_12_result = unite(v1717_12_result,v1718_13);
  }
  const Space v1717_12 = std::move(v1717_12_result);
  return v1717_12;
}

static Space routine_193(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1727_13_result;
  for (int v1727_13_label = 1; v1727_13_label <= 2; ++v1727_13_label) {
    const Space v1727_13_tail = child(s0,v1727_13_label);
    if (v1727_13_tail.empty()) continue;
    const Path v1727_13_head{v1727_13_label};
    const Space v1728_2 = singleton(v1727_13_head);
    const Space v1728_3 = intersect(constant_8,v1728_2);
    const Space v1728_4 = (has_head(v1728_3) ? constant_9 : Space{});
    const Space v1728_5 = subtract(constant_0,v1728_4);
    Space v1728_8;
    if (!v1728_5.empty()) {
      const Path v1729_6 = concat_path(p0,v1727_13_head);
      Space v1729_7_result;
      for (int v1729_7_label = 1; v1729_7_label <= 2; ++v1729_7_label) {
        const Space v1729_7_tail = child(v1727_13_tail,v1729_7_label);
        if (v1729_7_tail.empty()) continue;
        const Path v1729_7_head{v1729_7_label};
        const Space v1730_2 = singleton(v1729_7_head);
        const Space v1730_3 = intersect(constant_8,v1730_2);
        const Space v1730_4 = (has_head(v1730_3) ? constant_9 : Space{});
        const Space v1730_5 = subtract(constant_0,v1730_4);
        Space v1730_8;
        if (!v1730_5.empty()) {
          const Path v1731_6 = concat_path(v1729_6,v1729_7_head);
          const Space v1731_7 = routine_271(c, v1731_6, p1, p2, v1729_7_tail);
          v1730_8 = compose(v1730_5,v1731_7);
        }
        const Space v1730_9 = intersect(constant_8,v1730_2);
        const Space v1730_10 = (has_head(v1730_9) ? constant_9 : Space{});
        Space v1730_12;
        if (!v1730_10.empty()) {
          const Path v1732_6 = concat_path(v1729_6,v1729_7_head);
          const Space v1732_11 = routine_272(c, v1732_6, p1, p2, v1729_7_tail);
          v1730_12 = compose(v1730_10,v1732_11);
        }
        const Space v1730_13 = unite(v1730_8,v1730_12);
        v1729_7_result = unite(v1729_7_result,v1730_13);
      }
      const Space v1729_7 = std::move(v1729_7_result);
      v1728_8 = compose(v1728_5,v1729_7);
    }
    const Space v1728_9 = intersect(constant_8,v1728_2);
    const Space v1728_10 = (has_head(v1728_9) ? constant_9 : Space{});
    Space v1728_12;
    if (!v1728_10.empty()) {
      const Path v1733_6 = concat_path(p0,v1727_13_head);
      Space v1733_11_result;
      for (int v1733_11_label = 1; v1733_11_label <= 2; ++v1733_11_label) {
        const Space v1733_11_tail = child(v1727_13_tail,v1733_11_label);
        if (v1733_11_tail.empty()) continue;
        const Path v1733_11_head{v1733_11_label};
        const Space v1734_2 = singleton(v1733_11_head);
        const Space v1734_3 = intersect(constant_8,v1734_2);
        const Space v1734_4 = (has_head(v1734_3) ? constant_9 : Space{});
        const Space v1734_5 = subtract(constant_0,v1734_4);
        Space v1734_8;
        if (!v1734_5.empty()) {
          const Path v1735_6 = concat_path(v1733_6,v1733_11_head);
          const Space v1735_7 = routine_271(c, v1735_6, p1, p2, v1733_11_tail);
          v1734_8 = compose(v1734_5,v1735_7);
        }
        const Space v1734_9 = intersect(constant_8,v1734_2);
        const Space v1734_10 = (has_head(v1734_9) ? constant_9 : Space{});
        Space v1734_12;
        if (!v1734_10.empty()) {
          const Path v1736_6 = concat_path(v1733_6,v1733_11_head);
          const Space v1736_11 = routine_237(c, v1736_6, p1, p2, v1733_11_tail);
          v1734_12 = compose(v1734_10,v1736_11);
        }
        const Space v1734_13 = unite(v1734_8,v1734_12);
        v1733_11_result = unite(v1733_11_result,v1734_13);
      }
      const Space v1733_11 = std::move(v1733_11_result);
      v1728_12 = compose(v1728_10,v1733_11);
    }
    const Space v1728_13 = unite(v1728_8,v1728_12);
    v1727_13_result = unite(v1727_13_result,v1728_13);
  }
  const Space v1727_13 = std::move(v1727_13_result);
  return v1727_13;
}

static Space routine_194(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v1737_9 = concat_path(constant_23,p2);
  const Space v1737_10 = singleton(v1737_9);
  const Space v1737_11 = unite(constant_26,v1737_10);
  const Path v1737_13 = concat_path(constant_22,p1);
  const Space v1737_14 = singleton(v1737_13);
  const Space v1737_15 = unite(v1737_11,v1737_14);
  Space v1737_20_result;
  for (int v1737_20_label = 1; v1737_20_label <= 2; ++v1737_20_label) {
    const Space v1737_20_tail = child(s0,v1737_20_label);
    if (v1737_20_tail.empty()) continue;
    const Path v1737_20_head{v1737_20_label};
    const Space v1738_2 = singleton(v1737_20_head);
    const Space v1738_3 = intersect(constant_8,v1738_2);
    const Space v1738_4 = (has_head(v1738_3) ? constant_9 : Space{});
    const Space v1738_5 = subtract(constant_0,v1738_4);
    Space v1738_8;
    if (!v1738_5.empty()) {
      const Path v1739_6 = concat_path(p0,v1737_20_head);
      Space v1739_7_result;
      for (int v1739_7_label = 1; v1739_7_label <= 2; ++v1739_7_label) {
        const Space v1739_7_tail = child(v1737_20_tail,v1739_7_label);
        if (v1739_7_tail.empty()) continue;
        const Path v1739_7_head{v1739_7_label};
        const Space v1740_2 = singleton(v1739_7_head);
        const Space v1740_3 = intersect(constant_8,v1740_2);
        const Space v1740_4 = (has_head(v1740_3) ? constant_9 : Space{});
        const Space v1740_5 = subtract(constant_0,v1740_4);
        Space v1740_8;
        if (!v1740_5.empty()) {
          const Path v1741_6 = concat_path(v1739_6,v1739_7_head);
          const Space v1741_7 = routine_271(c, v1741_6, p1, p2, v1739_7_tail);
          v1740_8 = compose(v1740_5,v1741_7);
        }
        const Space v1740_9 = intersect(constant_8,v1740_2);
        const Space v1740_10 = (has_head(v1740_9) ? constant_9 : Space{});
        Space v1740_12;
        if (!v1740_10.empty()) {
          const Path v1742_6 = concat_path(v1739_6,v1739_7_head);
          const Space v1742_11 = routine_272(c, v1742_6, p1, p2, v1739_7_tail);
          v1740_12 = compose(v1740_10,v1742_11);
        }
        const Space v1740_13 = unite(v1740_8,v1740_12);
        v1739_7_result = unite(v1739_7_result,v1740_13);
      }
      const Space v1739_7 = std::move(v1739_7_result);
      v1738_8 = compose(v1738_5,v1739_7);
    }
    const Space v1738_9 = intersect(constant_8,v1738_2);
    const Space v1738_10 = (has_head(v1738_9) ? constant_9 : Space{});
    const Path v1743_6 = concat_path(p0,v1737_20_head);
    const Path v1738_11 = concat_path(constant_6,v1743_6);
    const Space v1738_12 = singleton(v1738_11);
    const Space v1738_13 = unite(v1737_15,v1738_12);
    const Space v1738_14 = compose(v1738_10,v1738_13);
    const Space v1738_15 = unite(v1738_8,v1738_14);
    v1737_20_result = unite(v1737_20_result,v1738_15);
  }
  const Space v1737_20 = std::move(v1737_20_result);
  return v1737_20;
}

static Space routine_195(Context& c, const Path& p0, const Space& s0) {
  Space v1744_2_result;
  for (int v1744_2_label = 1; v1744_2_label <= 2; ++v1744_2_label) {
    const Space v1744_2_tail = child(s0,v1744_2_label);
    if (v1744_2_tail.empty()) continue;
    const Path v1744_2_head{v1744_2_label};
    const Space v1745_2 = Space{};
    v1744_2_result = unite(v1744_2_result,v1745_2);
  }
  const Space v1744_2 = std::move(v1744_2_result);
  return v1744_2;
}

static Space routine_196(Context& c, const Path& p0, const Space& s0) {
  Space v1746_3_result;
  for (int v1746_3_label = 1; v1746_3_label <= 2; ++v1746_3_label) {
    const Space v1746_3_tail = child(s0,v1746_3_label);
    if (v1746_3_tail.empty()) continue;
    const Path v1746_3_head{v1746_3_label};
    const Space v1747_2 = singleton(v1746_3_head);
    const Space v1747_3 = intersect(constant_8,v1747_2);
    const Space v1747_4 = (has_head(v1747_3) ? constant_9 : Space{});
    const Space v1747_5 = compose(v1747_4,v1746_3_tail);
    v1746_3_result = unite(v1746_3_result,v1747_5);
  }
  const Space v1746_3 = std::move(v1746_3_result);
  return v1746_3;
}

static Space routine_197(Context& c, const Path& p0, const Space& s0) {
  Space v1748_2_result;
  for (int v1748_2_label = 1; v1748_2_label <= 2; ++v1748_2_label) {
    const Space v1748_2_tail = child(s0,v1748_2_label);
    if (v1748_2_tail.empty()) continue;
    const Path v1748_2_head{v1748_2_label};
    const Space v1749_2 = Space{};
    v1748_2_result = unite(v1748_2_result,v1749_2);
  }
  const Space v1748_2 = std::move(v1748_2_result);
  return v1748_2;
}

static Space routine_198(Context& c, const Path& p0, const Space& s0) {
  Space v1750_6_result;
  for (int v1750_6_label = 1; v1750_6_label <= 2; ++v1750_6_label) {
    const Space v1750_6_tail = child(s0,v1750_6_label);
    if (v1750_6_tail.empty()) continue;
    const Path v1750_6_head{v1750_6_label};
    const Space v1751_2 = singleton(v1750_6_head);
    const Space v1751_3 = intersect(constant_8,v1751_2);
    const Space v1751_4 = (has_head(v1751_3) ? constant_9 : Space{});
    Space v1751_7;
    if (!v1751_4.empty()) {
      const Path v1752_5 = concat_path(p0,v1750_6_head);
      Space v1752_6_result;
      for (int v1752_6_label = 1; v1752_6_label <= 2; ++v1752_6_label) {
        const Space v1752_6_tail = child(v1750_6_tail,v1752_6_label);
        if (v1752_6_tail.empty()) continue;
        const Path v1752_6_head{v1752_6_label};
        const Space v1753_2 = singleton(v1752_6_head);
        const Space v1753_3 = intersect(constant_8,v1753_2);
        const Space v1753_4 = (has_head(v1753_3) ? constant_9 : Space{});
        const Space v1753_5 = subtract(constant_0,v1753_4);
        Space v1753_7;
        if (!v1753_5.empty()) {
          const Space v1754_6 = routine_112(c, v1752_6_head, v1752_5, v1752_6_tail);
          v1753_7 = compose(v1753_5,v1754_6);
        }
        const Space v1753_8 = intersect(constant_8,v1753_2);
        const Space v1753_9 = (has_head(v1753_8) ? constant_9 : Space{});
        Space v1753_11;
        if (!v1753_9.empty()) {
          const Space v1755_10 = routine_113(c, v1752_6_head, v1752_5, v1752_6_tail);
          v1753_11 = compose(v1753_9,v1755_10);
        }
        const Space v1753_12 = unite(v1753_7,v1753_11);
        v1752_6_result = unite(v1752_6_result,v1753_12);
      }
      const Space v1752_6 = std::move(v1752_6_result);
      v1751_7 = compose(v1751_4,v1752_6);
    }
    v1750_6_result = unite(v1750_6_result,v1751_7);
  }
  const Space v1750_6 = std::move(v1750_6_result);
  return v1750_6;
}

static Space routine_199(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1756_12_result;
  for (int v1756_12_label = 1; v1756_12_label <= 2; ++v1756_12_label) {
    const Space v1756_12_tail = child(s0,v1756_12_label);
    if (v1756_12_tail.empty()) continue;
    const Path v1756_12_head{v1756_12_label};
    const Space v1757_2 = singleton(v1756_12_head);
    const Space v1757_3 = intersect(constant_8,v1757_2);
    const Space v1757_4 = (has_head(v1757_3) ? constant_9 : Space{});
    const Space v1757_5 = subtract(constant_0,v1757_4);
    Space v1757_8;
    if (!v1757_5.empty()) {
      const Path v1758_6 = concat_path(p0,v1756_12_head);
      Space v1758_7_result;
      for (int v1758_7_label = 1; v1758_7_label <= 2; ++v1758_7_label) {
        const Space v1758_7_tail = child(v1756_12_tail,v1758_7_label);
        if (v1758_7_tail.empty()) continue;
        const Path v1758_7_head{v1758_7_label};
        const Space v1759_2 = singleton(v1758_7_head);
        const Space v1759_3 = intersect(constant_8,v1759_2);
        const Space v1759_4 = (has_head(v1759_3) ? constant_9 : Space{});
        const Space v1759_5 = subtract(constant_0,v1759_4);
        Space v1759_8;
        if (!v1759_5.empty()) {
          const Path v1760_6 = concat_path(v1758_6,v1758_7_head);
          const Space v1760_7 = routine_273(c, v1760_6, p1, v1758_7_tail);
          v1759_8 = compose(v1759_5,v1760_7);
        }
        const Space v1759_9 = intersect(constant_8,v1759_2);
        const Space v1759_10 = (has_head(v1759_9) ? constant_9 : Space{});
        Space v1759_12;
        if (!v1759_10.empty()) {
          const Path v1761_6 = concat_path(v1758_6,v1758_7_head);
          const Space v1761_11 = routine_274(c, v1761_6, p1, v1758_7_tail);
          v1759_12 = compose(v1759_10,v1761_11);
        }
        const Space v1759_13 = unite(v1759_8,v1759_12);
        v1758_7_result = unite(v1758_7_result,v1759_13);
      }
      const Space v1758_7 = std::move(v1758_7_result);
      v1757_8 = compose(v1757_5,v1758_7);
    }
    const Space v1757_9 = intersect(constant_8,v1757_2);
    const Space v1757_10 = (has_head(v1757_9) ? constant_9 : Space{});
    Space v1757_12;
    if (!v1757_10.empty()) {
      const Path v1762_6 = concat_path(p0,v1756_12_head);
      Space v1762_11_result;
      for (int v1762_11_label = 1; v1762_11_label <= 2; ++v1762_11_label) {
        const Space v1762_11_tail = child(v1756_12_tail,v1762_11_label);
        if (v1762_11_tail.empty()) continue;
        const Path v1762_11_head{v1762_11_label};
        const Space v1763_2 = singleton(v1762_11_head);
        const Space v1763_3 = intersect(constant_8,v1763_2);
        const Space v1763_4 = (has_head(v1763_3) ? constant_9 : Space{});
        const Space v1763_5 = subtract(constant_0,v1763_4);
        Space v1763_8;
        if (!v1763_5.empty()) {
          const Path v1764_6 = concat_path(v1762_6,v1762_11_head);
          const Space v1764_7 = routine_273(c, v1764_6, p1, v1762_11_tail);
          v1763_8 = compose(v1763_5,v1764_7);
        }
        const Space v1763_9 = intersect(constant_8,v1763_2);
        const Space v1763_10 = (has_head(v1763_9) ? constant_9 : Space{});
        Space v1763_12;
        if (!v1763_10.empty()) {
          const Path v1765_6 = concat_path(v1762_6,v1762_11_head);
          const Space v1765_11 = routine_155(c, v1765_6, p1, v1762_11_tail);
          v1763_12 = compose(v1763_10,v1765_11);
        }
        const Space v1763_13 = unite(v1763_8,v1763_12);
        v1762_11_result = unite(v1762_11_result,v1763_13);
      }
      const Space v1762_11 = std::move(v1762_11_result);
      v1757_12 = compose(v1757_10,v1762_11);
    }
    const Space v1757_13 = unite(v1757_8,v1757_12);
    v1756_12_result = unite(v1756_12_result,v1757_13);
  }
  const Space v1756_12 = std::move(v1756_12_result);
  return v1756_12;
}

static Space routine_200(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1766_12_result;
  for (int v1766_12_label = 1; v1766_12_label <= 2; ++v1766_12_label) {
    const Space v1766_12_tail = child(s0,v1766_12_label);
    if (v1766_12_tail.empty()) continue;
    const Path v1766_12_head{v1766_12_label};
    const Space v1767_2 = singleton(v1766_12_head);
    const Space v1767_3 = intersect(constant_8,v1767_2);
    const Space v1767_4 = (has_head(v1767_3) ? constant_9 : Space{});
    const Space v1767_5 = subtract(constant_0,v1767_4);
    Space v1767_8;
    if (!v1767_5.empty()) {
      const Path v1768_6 = concat_path(p0,v1766_12_head);
      Space v1768_7_result;
      for (int v1768_7_label = 1; v1768_7_label <= 2; ++v1768_7_label) {
        const Space v1768_7_tail = child(v1766_12_tail,v1768_7_label);
        if (v1768_7_tail.empty()) continue;
        const Path v1768_7_head{v1768_7_label};
        const Space v1769_2 = singleton(v1768_7_head);
        const Space v1769_3 = intersect(constant_8,v1769_2);
        const Space v1769_4 = (has_head(v1769_3) ? constant_9 : Space{});
        const Space v1769_5 = subtract(constant_0,v1769_4);
        Space v1769_8;
        if (!v1769_5.empty()) {
          const Path v1770_6 = concat_path(v1768_6,v1768_7_head);
          const Space v1770_7 = routine_273(c, v1770_6, p1, v1768_7_tail);
          v1769_8 = compose(v1769_5,v1770_7);
        }
        const Space v1769_9 = intersect(constant_8,v1769_2);
        const Space v1769_10 = (has_head(v1769_9) ? constant_9 : Space{});
        Space v1769_12;
        if (!v1769_10.empty()) {
          const Path v1771_6 = concat_path(v1768_6,v1768_7_head);
          const Space v1771_11 = routine_274(c, v1771_6, p1, v1768_7_tail);
          v1769_12 = compose(v1769_10,v1771_11);
        }
        const Space v1769_13 = unite(v1769_8,v1769_12);
        v1768_7_result = unite(v1768_7_result,v1769_13);
      }
      const Space v1768_7 = std::move(v1768_7_result);
      v1767_8 = compose(v1767_5,v1768_7);
    }
    const Space v1767_9 = intersect(constant_8,v1767_2);
    const Space v1767_10 = (has_head(v1767_9) ? constant_9 : Space{});
    Space v1767_12;
    if (!v1767_10.empty()) {
      const Path v1772_6 = concat_path(p0,v1766_12_head);
      Space v1772_11_result;
      for (int v1772_11_label = 1; v1772_11_label <= 2; ++v1772_11_label) {
        const Space v1772_11_tail = child(v1766_12_tail,v1772_11_label);
        if (v1772_11_tail.empty()) continue;
        const Path v1772_11_head{v1772_11_label};
        const Space v1773_2 = singleton(v1772_11_head);
        const Space v1773_3 = intersect(constant_8,v1773_2);
        const Space v1773_4 = (has_head(v1773_3) ? constant_9 : Space{});
        const Space v1773_5 = subtract(constant_0,v1773_4);
        Space v1773_7;
        if (!v1773_5.empty()) {
          const Space v1774_6 = routine_201(c, v1772_11_head, p1, v1772_6, v1772_11_tail);
          v1773_7 = compose(v1773_5,v1774_6);
        }
        const Space v1773_8 = intersect(constant_8,v1773_2);
        const Space v1773_9 = (has_head(v1773_8) ? constant_9 : Space{});
        Space v1773_11;
        if (!v1773_9.empty()) {
          const Space v1775_10 = routine_202(c, v1772_11_head, p1, v1772_6, v1772_11_tail);
          v1773_11 = compose(v1773_9,v1775_10);
        }
        const Space v1773_12 = unite(v1773_7,v1773_11);
        v1772_11_result = unite(v1772_11_result,v1773_12);
      }
      const Space v1772_11 = std::move(v1772_11_result);
      v1767_12 = compose(v1767_10,v1772_11);
    }
    const Space v1767_13 = unite(v1767_8,v1767_12);
    v1766_12_result = unite(v1766_12_result,v1767_13);
  }
  const Space v1766_12 = std::move(v1766_12_result);
  return v1766_12;
}

static Space routine_201(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1776_13_result;
  for (int v1776_13_label = 1; v1776_13_label <= 2; ++v1776_13_label) {
    const Space v1776_13_tail = child(s0,v1776_13_label);
    if (v1776_13_tail.empty()) continue;
    const Path v1776_13_head{v1776_13_label};
    const Space v1777_2 = singleton(v1776_13_head);
    const Space v1777_3 = intersect(constant_8,v1777_2);
    const Space v1777_4 = (has_head(v1777_3) ? constant_9 : Space{});
    const Space v1777_5 = subtract(constant_0,v1777_4);
    Space v1777_8;
    if (!v1777_5.empty()) {
      const Path v1778_6 = concat_path(p0,v1776_13_head);
      Space v1778_7_result;
      for (int v1778_7_label = 1; v1778_7_label <= 2; ++v1778_7_label) {
        const Space v1778_7_tail = child(v1776_13_tail,v1778_7_label);
        if (v1778_7_tail.empty()) continue;
        const Path v1778_7_head{v1778_7_label};
        const Space v1779_2 = singleton(v1778_7_head);
        const Space v1779_3 = intersect(constant_8,v1779_2);
        const Space v1779_4 = (has_head(v1779_3) ? constant_9 : Space{});
        const Space v1779_5 = subtract(constant_0,v1779_4);
        Space v1779_8;
        if (!v1779_5.empty()) {
          const Path v1780_6 = concat_path(v1778_6,v1778_7_head);
          const Space v1780_7 = routine_275(c, v1780_6, p1, p2, v1778_7_tail);
          v1779_8 = compose(v1779_5,v1780_7);
        }
        const Space v1779_9 = intersect(constant_8,v1779_2);
        const Space v1779_10 = (has_head(v1779_9) ? constant_9 : Space{});
        Space v1779_12;
        if (!v1779_10.empty()) {
          const Path v1781_6 = concat_path(v1778_6,v1778_7_head);
          const Space v1781_11 = routine_276(c, v1781_6, p1, p2, v1778_7_tail);
          v1779_12 = compose(v1779_10,v1781_11);
        }
        const Space v1779_13 = unite(v1779_8,v1779_12);
        v1778_7_result = unite(v1778_7_result,v1779_13);
      }
      const Space v1778_7 = std::move(v1778_7_result);
      v1777_8 = compose(v1777_5,v1778_7);
    }
    const Space v1777_9 = intersect(constant_8,v1777_2);
    const Space v1777_10 = (has_head(v1777_9) ? constant_9 : Space{});
    Space v1777_12;
    if (!v1777_10.empty()) {
      const Path v1782_6 = concat_path(p0,v1776_13_head);
      Space v1782_11_result;
      for (int v1782_11_label = 1; v1782_11_label <= 2; ++v1782_11_label) {
        const Space v1782_11_tail = child(v1776_13_tail,v1782_11_label);
        if (v1782_11_tail.empty()) continue;
        const Path v1782_11_head{v1782_11_label};
        const Space v1783_2 = singleton(v1782_11_head);
        const Space v1783_3 = intersect(constant_8,v1783_2);
        const Space v1783_4 = (has_head(v1783_3) ? constant_9 : Space{});
        const Space v1783_5 = subtract(constant_0,v1783_4);
        Space v1783_8;
        if (!v1783_5.empty()) {
          const Path v1784_6 = concat_path(v1782_6,v1782_11_head);
          const Space v1784_7 = routine_275(c, v1784_6, p1, p2, v1782_11_tail);
          v1783_8 = compose(v1783_5,v1784_7);
        }
        const Space v1783_9 = intersect(constant_8,v1783_2);
        const Space v1783_10 = (has_head(v1783_9) ? constant_9 : Space{});
        Space v1783_12;
        if (!v1783_10.empty()) {
          const Path v1785_6 = concat_path(v1782_6,v1782_11_head);
          const Space v1785_11 = routine_242(c, v1785_6, p1, p2, v1782_11_tail);
          v1783_12 = compose(v1783_10,v1785_11);
        }
        const Space v1783_13 = unite(v1783_8,v1783_12);
        v1782_11_result = unite(v1782_11_result,v1783_13);
      }
      const Space v1782_11 = std::move(v1782_11_result);
      v1777_12 = compose(v1777_10,v1782_11);
    }
    const Space v1777_13 = unite(v1777_8,v1777_12);
    v1776_13_result = unite(v1776_13_result,v1777_13);
  }
  const Space v1776_13 = std::move(v1776_13_result);
  return v1776_13;
}

static Space routine_202(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v1786_10 = concat_path(constant_22,p1);
  const Space v1786_11 = singleton(v1786_10);
  const Path v1786_13 = concat_path(constant_6,p2);
  const Space v1786_14 = singleton(v1786_13);
  Space v1786_18_result;
  for (int v1786_18_label = 1; v1786_18_label <= 2; ++v1786_18_label) {
    const Space v1786_18_tail = child(s0,v1786_18_label);
    if (v1786_18_tail.empty()) continue;
    const Path v1786_18_head{v1786_18_label};
    const Space v1787_2 = singleton(v1786_18_head);
    const Space v1787_3 = intersect(constant_8,v1787_2);
    const Space v1787_4 = (has_head(v1787_3) ? constant_9 : Space{});
    const Space v1787_5 = subtract(constant_0,v1787_4);
    Space v1787_8;
    if (!v1787_5.empty()) {
      const Path v1788_6 = concat_path(p0,v1786_18_head);
      Space v1788_7_result;
      for (int v1788_7_label = 1; v1788_7_label <= 2; ++v1788_7_label) {
        const Space v1788_7_tail = child(v1786_18_tail,v1788_7_label);
        if (v1788_7_tail.empty()) continue;
        const Path v1788_7_head{v1788_7_label};
        const Space v1789_2 = singleton(v1788_7_head);
        const Space v1789_3 = intersect(constant_8,v1789_2);
        const Space v1789_4 = (has_head(v1789_3) ? constant_9 : Space{});
        const Space v1789_5 = subtract(constant_0,v1789_4);
        Space v1789_8;
        if (!v1789_5.empty()) {
          const Path v1790_6 = concat_path(v1788_6,v1788_7_head);
          const Space v1790_7 = routine_275(c, v1790_6, p1, p2, v1788_7_tail);
          v1789_8 = compose(v1789_5,v1790_7);
        }
        const Space v1789_9 = intersect(constant_8,v1789_2);
        const Space v1789_10 = (has_head(v1789_9) ? constant_9 : Space{});
        Space v1789_12;
        if (!v1789_10.empty()) {
          const Path v1791_6 = concat_path(v1788_6,v1788_7_head);
          const Space v1791_11 = routine_276(c, v1791_6, p1, p2, v1788_7_tail);
          v1789_12 = compose(v1789_10,v1791_11);
        }
        const Space v1789_13 = unite(v1789_8,v1789_12);
        v1788_7_result = unite(v1788_7_result,v1789_13);
      }
      const Space v1788_7 = std::move(v1788_7_result);
      v1787_8 = compose(v1787_5,v1788_7);
    }
    const Space v1787_9 = intersect(constant_8,v1787_2);
    const Space v1787_10 = (has_head(v1787_9) ? constant_9 : Space{});
    const Path v1792_6 = concat_path(p0,v1786_18_head);
    const Path v1787_11 = concat_path(constant_24,v1792_6);
    const Space v1787_12 = singleton(v1787_11);
    const Space v1787_13 = unite(constant_27,v1787_12);
    const Space v1787_14 = unite(v1787_13,v1786_11);
    const Space v1787_15 = unite(v1787_14,v1786_14);
    const Space v1787_16 = compose(v1787_10,v1787_15);
    const Space v1787_17 = unite(v1787_8,v1787_16);
    v1786_18_result = unite(v1786_18_result,v1787_17);
  }
  const Space v1786_18 = std::move(v1786_18_result);
  return v1786_18;
}

static Space routine_203(Context& c, const Path& p0, const Space& s0) {
  Space v1793_2_result;
  for (int v1793_2_label = 1; v1793_2_label <= 2; ++v1793_2_label) {
    const Space v1793_2_tail = child(s0,v1793_2_label);
    if (v1793_2_tail.empty()) continue;
    const Path v1793_2_head{v1793_2_label};
    const Space v1794_2 = Space{};
    v1793_2_result = unite(v1793_2_result,v1794_2);
  }
  const Space v1793_2 = std::move(v1793_2_result);
  return v1793_2;
}

static Space routine_204(Context& c, const Path& p0, const Space& s0) {
  Space v1795_3_result;
  for (int v1795_3_label = 1; v1795_3_label <= 2; ++v1795_3_label) {
    const Space v1795_3_tail = child(s0,v1795_3_label);
    if (v1795_3_tail.empty()) continue;
    const Path v1795_3_head{v1795_3_label};
    const Space v1796_2 = singleton(v1795_3_head);
    const Space v1796_3 = intersect(constant_8,v1796_2);
    const Space v1796_4 = (has_head(v1796_3) ? constant_9 : Space{});
    const Space v1796_5 = compose(v1796_4,v1795_3_tail);
    v1795_3_result = unite(v1795_3_result,v1796_5);
  }
  const Space v1795_3 = std::move(v1795_3_result);
  return v1795_3;
}

static Space routine_205(Context& c, const Path& p0, const Space& s0) {
  Space v1797_2_result;
  for (int v1797_2_label = 1; v1797_2_label <= 2; ++v1797_2_label) {
    const Space v1797_2_tail = child(s0,v1797_2_label);
    if (v1797_2_tail.empty()) continue;
    const Path v1797_2_head{v1797_2_label};
    const Space v1798_2 = Space{};
    v1797_2_result = unite(v1797_2_result,v1798_2);
  }
  const Space v1797_2 = std::move(v1797_2_result);
  return v1797_2;
}

static Space routine_206(Context& c, const Path& p0, const Space& s0) {
  Space v1799_6_result;
  for (int v1799_6_label = 1; v1799_6_label <= 2; ++v1799_6_label) {
    const Space v1799_6_tail = child(s0,v1799_6_label);
    if (v1799_6_tail.empty()) continue;
    const Path v1799_6_head{v1799_6_label};
    const Space v1800_2 = singleton(v1799_6_head);
    const Space v1800_3 = intersect(constant_8,v1800_2);
    const Space v1800_4 = (has_head(v1800_3) ? constant_9 : Space{});
    Space v1800_7;
    if (!v1800_4.empty()) {
      const Path v1801_5 = concat_path(p0,v1799_6_head);
      Space v1801_6_result;
      for (int v1801_6_label = 1; v1801_6_label <= 2; ++v1801_6_label) {
        const Space v1801_6_tail = child(v1799_6_tail,v1801_6_label);
        if (v1801_6_tail.empty()) continue;
        const Path v1801_6_head{v1801_6_label};
        const Space v1802_2 = singleton(v1801_6_head);
        const Space v1802_3 = intersect(constant_8,v1802_2);
        const Space v1802_4 = (has_head(v1802_3) ? constant_9 : Space{});
        const Space v1802_5 = subtract(constant_0,v1802_4);
        Space v1802_7;
        if (!v1802_5.empty()) {
          const Space v1803_6 = routine_118(c, v1801_6_head, v1801_5, v1801_6_tail);
          v1802_7 = compose(v1802_5,v1803_6);
        }
        const Space v1802_8 = intersect(constant_8,v1802_2);
        const Space v1802_9 = (has_head(v1802_8) ? constant_9 : Space{});
        Space v1802_11;
        if (!v1802_9.empty()) {
          const Space v1804_10 = routine_119(c, v1801_6_head, v1801_5, v1801_6_tail);
          v1802_11 = compose(v1802_9,v1804_10);
        }
        const Space v1802_12 = unite(v1802_7,v1802_11);
        v1801_6_result = unite(v1801_6_result,v1802_12);
      }
      const Space v1801_6 = std::move(v1801_6_result);
      v1800_7 = compose(v1800_4,v1801_6);
    }
    v1799_6_result = unite(v1799_6_result,v1800_7);
  }
  const Space v1799_6 = std::move(v1799_6_result);
  return v1799_6;
}

static Space routine_207(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1805_12_result;
  for (int v1805_12_label = 1; v1805_12_label <= 2; ++v1805_12_label) {
    const Space v1805_12_tail = child(s0,v1805_12_label);
    if (v1805_12_tail.empty()) continue;
    const Path v1805_12_head{v1805_12_label};
    const Space v1806_2 = singleton(v1805_12_head);
    const Space v1806_3 = intersect(constant_8,v1806_2);
    const Space v1806_4 = (has_head(v1806_3) ? constant_9 : Space{});
    const Space v1806_5 = subtract(constant_0,v1806_4);
    Space v1806_8;
    if (!v1806_5.empty()) {
      const Path v1807_6 = concat_path(p0,v1805_12_head);
      Space v1807_7_result;
      for (int v1807_7_label = 1; v1807_7_label <= 2; ++v1807_7_label) {
        const Space v1807_7_tail = child(v1805_12_tail,v1807_7_label);
        if (v1807_7_tail.empty()) continue;
        const Path v1807_7_head{v1807_7_label};
        const Space v1808_2 = singleton(v1807_7_head);
        const Space v1808_3 = intersect(constant_8,v1808_2);
        const Space v1808_4 = (has_head(v1808_3) ? constant_9 : Space{});
        const Space v1808_5 = subtract(constant_0,v1808_4);
        Space v1808_8;
        if (!v1808_5.empty()) {
          const Path v1809_6 = concat_path(v1807_6,v1807_7_head);
          const Space v1809_7 = routine_277(c, v1809_6, p1, v1807_7_tail);
          v1808_8 = compose(v1808_5,v1809_7);
        }
        const Space v1808_9 = intersect(constant_8,v1808_2);
        const Space v1808_10 = (has_head(v1808_9) ? constant_9 : Space{});
        Space v1808_12;
        if (!v1808_10.empty()) {
          const Path v1810_6 = concat_path(v1807_6,v1807_7_head);
          const Space v1810_11 = routine_278(c, v1810_6, p1, v1807_7_tail);
          v1808_12 = compose(v1808_10,v1810_11);
        }
        const Space v1808_13 = unite(v1808_8,v1808_12);
        v1807_7_result = unite(v1807_7_result,v1808_13);
      }
      const Space v1807_7 = std::move(v1807_7_result);
      v1806_8 = compose(v1806_5,v1807_7);
    }
    const Space v1806_9 = intersect(constant_8,v1806_2);
    const Space v1806_10 = (has_head(v1806_9) ? constant_9 : Space{});
    Space v1806_12;
    if (!v1806_10.empty()) {
      const Path v1811_6 = concat_path(p0,v1805_12_head);
      Space v1811_11_result;
      for (int v1811_11_label = 1; v1811_11_label <= 2; ++v1811_11_label) {
        const Space v1811_11_tail = child(v1805_12_tail,v1811_11_label);
        if (v1811_11_tail.empty()) continue;
        const Path v1811_11_head{v1811_11_label};
        const Space v1812_2 = singleton(v1811_11_head);
        const Space v1812_3 = intersect(constant_8,v1812_2);
        const Space v1812_4 = (has_head(v1812_3) ? constant_9 : Space{});
        const Space v1812_5 = subtract(constant_0,v1812_4);
        Space v1812_8;
        if (!v1812_5.empty()) {
          const Path v1813_6 = concat_path(v1811_6,v1811_11_head);
          const Space v1813_7 = routine_277(c, v1813_6, p1, v1811_11_tail);
          v1812_8 = compose(v1812_5,v1813_7);
        }
        const Space v1812_9 = intersect(constant_8,v1812_2);
        const Space v1812_10 = (has_head(v1812_9) ? constant_9 : Space{});
        Space v1812_12;
        if (!v1812_10.empty()) {
          const Path v1814_6 = concat_path(v1811_6,v1811_11_head);
          const Space v1814_11 = routine_162(c, v1814_6, p1, v1811_11_tail);
          v1812_12 = compose(v1812_10,v1814_11);
        }
        const Space v1812_13 = unite(v1812_8,v1812_12);
        v1811_11_result = unite(v1811_11_result,v1812_13);
      }
      const Space v1811_11 = std::move(v1811_11_result);
      v1806_12 = compose(v1806_10,v1811_11);
    }
    const Space v1806_13 = unite(v1806_8,v1806_12);
    v1805_12_result = unite(v1805_12_result,v1806_13);
  }
  const Space v1805_12 = std::move(v1805_12_result);
  return v1805_12;
}

static Space routine_208(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1815_12_result;
  for (int v1815_12_label = 1; v1815_12_label <= 2; ++v1815_12_label) {
    const Space v1815_12_tail = child(s0,v1815_12_label);
    if (v1815_12_tail.empty()) continue;
    const Path v1815_12_head{v1815_12_label};
    const Space v1816_2 = singleton(v1815_12_head);
    const Space v1816_3 = intersect(constant_8,v1816_2);
    const Space v1816_4 = (has_head(v1816_3) ? constant_9 : Space{});
    const Space v1816_5 = subtract(constant_0,v1816_4);
    Space v1816_8;
    if (!v1816_5.empty()) {
      const Path v1817_6 = concat_path(p0,v1815_12_head);
      Space v1817_7_result;
      for (int v1817_7_label = 1; v1817_7_label <= 2; ++v1817_7_label) {
        const Space v1817_7_tail = child(v1815_12_tail,v1817_7_label);
        if (v1817_7_tail.empty()) continue;
        const Path v1817_7_head{v1817_7_label};
        const Space v1818_2 = singleton(v1817_7_head);
        const Space v1818_3 = intersect(constant_8,v1818_2);
        const Space v1818_4 = (has_head(v1818_3) ? constant_9 : Space{});
        const Space v1818_5 = subtract(constant_0,v1818_4);
        Space v1818_8;
        if (!v1818_5.empty()) {
          const Path v1819_6 = concat_path(v1817_6,v1817_7_head);
          const Space v1819_7 = routine_277(c, v1819_6, p1, v1817_7_tail);
          v1818_8 = compose(v1818_5,v1819_7);
        }
        const Space v1818_9 = intersect(constant_8,v1818_2);
        const Space v1818_10 = (has_head(v1818_9) ? constant_9 : Space{});
        Space v1818_12;
        if (!v1818_10.empty()) {
          const Path v1820_6 = concat_path(v1817_6,v1817_7_head);
          const Space v1820_11 = routine_278(c, v1820_6, p1, v1817_7_tail);
          v1818_12 = compose(v1818_10,v1820_11);
        }
        const Space v1818_13 = unite(v1818_8,v1818_12);
        v1817_7_result = unite(v1817_7_result,v1818_13);
      }
      const Space v1817_7 = std::move(v1817_7_result);
      v1816_8 = compose(v1816_5,v1817_7);
    }
    const Space v1816_9 = intersect(constant_8,v1816_2);
    const Space v1816_10 = (has_head(v1816_9) ? constant_9 : Space{});
    Space v1816_12;
    if (!v1816_10.empty()) {
      const Path v1821_6 = concat_path(p0,v1815_12_head);
      Space v1821_11_result;
      for (int v1821_11_label = 1; v1821_11_label <= 2; ++v1821_11_label) {
        const Space v1821_11_tail = child(v1815_12_tail,v1821_11_label);
        if (v1821_11_tail.empty()) continue;
        const Path v1821_11_head{v1821_11_label};
        const Space v1822_2 = singleton(v1821_11_head);
        const Space v1822_3 = intersect(constant_8,v1822_2);
        const Space v1822_4 = (has_head(v1822_3) ? constant_9 : Space{});
        const Space v1822_5 = subtract(constant_0,v1822_4);
        Space v1822_7;
        if (!v1822_5.empty()) {
          const Space v1823_6 = routine_209(c, v1821_11_head, p1, v1821_6, v1821_11_tail);
          v1822_7 = compose(v1822_5,v1823_6);
        }
        const Space v1822_8 = intersect(constant_8,v1822_2);
        const Space v1822_9 = (has_head(v1822_8) ? constant_9 : Space{});
        Space v1822_11;
        if (!v1822_9.empty()) {
          const Space v1824_10 = routine_210(c, v1821_11_head, p1, v1821_6, v1821_11_tail);
          v1822_11 = compose(v1822_9,v1824_10);
        }
        const Space v1822_12 = unite(v1822_7,v1822_11);
        v1821_11_result = unite(v1821_11_result,v1822_12);
      }
      const Space v1821_11 = std::move(v1821_11_result);
      v1816_12 = compose(v1816_10,v1821_11);
    }
    const Space v1816_13 = unite(v1816_8,v1816_12);
    v1815_12_result = unite(v1815_12_result,v1816_13);
  }
  const Space v1815_12 = std::move(v1815_12_result);
  return v1815_12;
}

static Space routine_209(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1825_13_result;
  for (int v1825_13_label = 1; v1825_13_label <= 2; ++v1825_13_label) {
    const Space v1825_13_tail = child(s0,v1825_13_label);
    if (v1825_13_tail.empty()) continue;
    const Path v1825_13_head{v1825_13_label};
    const Space v1826_2 = singleton(v1825_13_head);
    const Space v1826_3 = intersect(constant_8,v1826_2);
    const Space v1826_4 = (has_head(v1826_3) ? constant_9 : Space{});
    const Space v1826_5 = subtract(constant_0,v1826_4);
    Space v1826_8;
    if (!v1826_5.empty()) {
      const Path v1827_6 = concat_path(p0,v1825_13_head);
      Space v1827_7_result;
      for (int v1827_7_label = 1; v1827_7_label <= 2; ++v1827_7_label) {
        const Space v1827_7_tail = child(v1825_13_tail,v1827_7_label);
        if (v1827_7_tail.empty()) continue;
        const Path v1827_7_head{v1827_7_label};
        const Space v1828_2 = singleton(v1827_7_head);
        const Space v1828_3 = intersect(constant_8,v1828_2);
        const Space v1828_4 = (has_head(v1828_3) ? constant_9 : Space{});
        const Space v1828_5 = subtract(constant_0,v1828_4);
        Space v1828_8;
        if (!v1828_5.empty()) {
          const Path v1829_6 = concat_path(v1827_6,v1827_7_head);
          const Space v1829_7 = routine_279(c, v1829_6, p1, p2, v1827_7_tail);
          v1828_8 = compose(v1828_5,v1829_7);
        }
        const Space v1828_9 = intersect(constant_8,v1828_2);
        const Space v1828_10 = (has_head(v1828_9) ? constant_9 : Space{});
        Space v1828_12;
        if (!v1828_10.empty()) {
          const Path v1830_6 = concat_path(v1827_6,v1827_7_head);
          const Space v1830_11 = routine_280(c, v1830_6, p1, p2, v1827_7_tail);
          v1828_12 = compose(v1828_10,v1830_11);
        }
        const Space v1828_13 = unite(v1828_8,v1828_12);
        v1827_7_result = unite(v1827_7_result,v1828_13);
      }
      const Space v1827_7 = std::move(v1827_7_result);
      v1826_8 = compose(v1826_5,v1827_7);
    }
    const Space v1826_9 = intersect(constant_8,v1826_2);
    const Space v1826_10 = (has_head(v1826_9) ? constant_9 : Space{});
    Space v1826_12;
    if (!v1826_10.empty()) {
      const Path v1831_6 = concat_path(p0,v1825_13_head);
      Space v1831_11_result;
      for (int v1831_11_label = 1; v1831_11_label <= 2; ++v1831_11_label) {
        const Space v1831_11_tail = child(v1825_13_tail,v1831_11_label);
        if (v1831_11_tail.empty()) continue;
        const Path v1831_11_head{v1831_11_label};
        const Space v1832_2 = singleton(v1831_11_head);
        const Space v1832_3 = intersect(constant_8,v1832_2);
        const Space v1832_4 = (has_head(v1832_3) ? constant_9 : Space{});
        const Space v1832_5 = subtract(constant_0,v1832_4);
        Space v1832_8;
        if (!v1832_5.empty()) {
          const Path v1833_6 = concat_path(v1831_6,v1831_11_head);
          const Space v1833_7 = routine_279(c, v1833_6, p1, p2, v1831_11_tail);
          v1832_8 = compose(v1832_5,v1833_7);
        }
        const Space v1832_9 = intersect(constant_8,v1832_2);
        const Space v1832_10 = (has_head(v1832_9) ? constant_9 : Space{});
        Space v1832_12;
        if (!v1832_10.empty()) {
          const Path v1834_6 = concat_path(v1831_6,v1831_11_head);
          const Space v1834_11 = routine_247(c, v1834_6, p1, p2, v1831_11_tail);
          v1832_12 = compose(v1832_10,v1834_11);
        }
        const Space v1832_13 = unite(v1832_8,v1832_12);
        v1831_11_result = unite(v1831_11_result,v1832_13);
      }
      const Space v1831_11 = std::move(v1831_11_result);
      v1826_12 = compose(v1826_10,v1831_11);
    }
    const Space v1826_13 = unite(v1826_8,v1826_12);
    v1825_13_result = unite(v1825_13_result,v1826_13);
  }
  const Space v1825_13 = std::move(v1825_13_result);
  return v1825_13;
}

static Space routine_210(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v1835_10 = concat_path(constant_23,p1);
  const Space v1835_11 = singleton(v1835_10);
  const Path v1835_13 = concat_path(constant_6,p2);
  const Space v1835_14 = singleton(v1835_13);
  Space v1835_18_result;
  for (int v1835_18_label = 1; v1835_18_label <= 2; ++v1835_18_label) {
    const Space v1835_18_tail = child(s0,v1835_18_label);
    if (v1835_18_tail.empty()) continue;
    const Path v1835_18_head{v1835_18_label};
    const Space v1836_2 = singleton(v1835_18_head);
    const Space v1836_3 = intersect(constant_8,v1836_2);
    const Space v1836_4 = (has_head(v1836_3) ? constant_9 : Space{});
    const Space v1836_5 = subtract(constant_0,v1836_4);
    Space v1836_8;
    if (!v1836_5.empty()) {
      const Path v1837_6 = concat_path(p0,v1835_18_head);
      Space v1837_7_result;
      for (int v1837_7_label = 1; v1837_7_label <= 2; ++v1837_7_label) {
        const Space v1837_7_tail = child(v1835_18_tail,v1837_7_label);
        if (v1837_7_tail.empty()) continue;
        const Path v1837_7_head{v1837_7_label};
        const Space v1838_2 = singleton(v1837_7_head);
        const Space v1838_3 = intersect(constant_8,v1838_2);
        const Space v1838_4 = (has_head(v1838_3) ? constant_9 : Space{});
        const Space v1838_5 = subtract(constant_0,v1838_4);
        Space v1838_8;
        if (!v1838_5.empty()) {
          const Path v1839_6 = concat_path(v1837_6,v1837_7_head);
          const Space v1839_7 = routine_279(c, v1839_6, p1, p2, v1837_7_tail);
          v1838_8 = compose(v1838_5,v1839_7);
        }
        const Space v1838_9 = intersect(constant_8,v1838_2);
        const Space v1838_10 = (has_head(v1838_9) ? constant_9 : Space{});
        Space v1838_12;
        if (!v1838_10.empty()) {
          const Path v1840_6 = concat_path(v1837_6,v1837_7_head);
          const Space v1840_11 = routine_280(c, v1840_6, p1, p2, v1837_7_tail);
          v1838_12 = compose(v1838_10,v1840_11);
        }
        const Space v1838_13 = unite(v1838_8,v1838_12);
        v1837_7_result = unite(v1837_7_result,v1838_13);
      }
      const Space v1837_7 = std::move(v1837_7_result);
      v1836_8 = compose(v1836_5,v1837_7);
    }
    const Space v1836_9 = intersect(constant_8,v1836_2);
    const Space v1836_10 = (has_head(v1836_9) ? constant_9 : Space{});
    const Path v1841_6 = concat_path(p0,v1835_18_head);
    const Path v1836_11 = concat_path(constant_24,v1841_6);
    const Space v1836_12 = singleton(v1836_11);
    const Space v1836_13 = unite(constant_28,v1836_12);
    const Space v1836_14 = unite(v1836_13,v1835_11);
    const Space v1836_15 = unite(v1836_14,v1835_14);
    const Space v1836_16 = compose(v1836_10,v1836_15);
    const Space v1836_17 = unite(v1836_8,v1836_16);
    v1835_18_result = unite(v1835_18_result,v1836_17);
  }
  const Space v1835_18 = std::move(v1835_18_result);
  return v1835_18;
}

static Space routine_211(Context& c, const Path& p0, const Space& s0) {
  Space v1842_2_result;
  for (int v1842_2_label = 1; v1842_2_label <= 2; ++v1842_2_label) {
    const Space v1842_2_tail = child(s0,v1842_2_label);
    if (v1842_2_tail.empty()) continue;
    const Path v1842_2_head{v1842_2_label};
    const Space v1843_2 = Space{};
    v1842_2_result = unite(v1842_2_result,v1843_2);
  }
  const Space v1842_2 = std::move(v1842_2_result);
  return v1842_2;
}

static Space routine_212(Context& c, const Path& p0, const Space& s0) {
  Space v1844_3_result;
  for (int v1844_3_label = 1; v1844_3_label <= 2; ++v1844_3_label) {
    const Space v1844_3_tail = child(s0,v1844_3_label);
    if (v1844_3_tail.empty()) continue;
    const Path v1844_3_head{v1844_3_label};
    const Space v1845_2 = singleton(v1844_3_head);
    const Space v1845_3 = intersect(constant_8,v1845_2);
    const Space v1845_4 = (has_head(v1845_3) ? constant_9 : Space{});
    const Space v1845_5 = compose(v1845_4,v1844_3_tail);
    v1844_3_result = unite(v1844_3_result,v1845_5);
  }
  const Space v1844_3 = std::move(v1844_3_result);
  return v1844_3;
}

static Space routine_213(Context& c, const Path& p0, const Space& s0) {
  Space v1846_2_result;
  for (int v1846_2_label = 1; v1846_2_label <= 2; ++v1846_2_label) {
    const Space v1846_2_tail = child(s0,v1846_2_label);
    if (v1846_2_tail.empty()) continue;
    const Path v1846_2_head{v1846_2_label};
    const Space v1847_2 = Space{};
    v1846_2_result = unite(v1846_2_result,v1847_2);
  }
  const Space v1846_2 = std::move(v1846_2_result);
  return v1846_2;
}

static Space routine_214(Context& c, const Path& p0, const Space& s0) {
  Space v1848_6_result;
  for (int v1848_6_label = 1; v1848_6_label <= 2; ++v1848_6_label) {
    const Space v1848_6_tail = child(s0,v1848_6_label);
    if (v1848_6_tail.empty()) continue;
    const Path v1848_6_head{v1848_6_label};
    const Space v1849_2 = singleton(v1848_6_head);
    const Space v1849_3 = intersect(constant_8,v1849_2);
    const Space v1849_4 = (has_head(v1849_3) ? constant_9 : Space{});
    Space v1849_7;
    if (!v1849_4.empty()) {
      const Path v1850_5 = concat_path(p0,v1848_6_head);
      Space v1850_6_result;
      for (int v1850_6_label = 1; v1850_6_label <= 2; ++v1850_6_label) {
        const Space v1850_6_tail = child(v1848_6_tail,v1850_6_label);
        if (v1850_6_tail.empty()) continue;
        const Path v1850_6_head{v1850_6_label};
        const Space v1851_2 = singleton(v1850_6_head);
        const Space v1851_3 = intersect(constant_8,v1851_2);
        const Space v1851_4 = (has_head(v1851_3) ? constant_9 : Space{});
        const Space v1851_5 = subtract(constant_0,v1851_4);
        Space v1851_7;
        if (!v1851_5.empty()) {
          const Space v1852_6 = routine_124(c, v1850_6_head, v1850_5, v1850_6_tail);
          v1851_7 = compose(v1851_5,v1852_6);
        }
        const Space v1851_8 = intersect(constant_8,v1851_2);
        const Space v1851_9 = (has_head(v1851_8) ? constant_9 : Space{});
        Space v1851_11;
        if (!v1851_9.empty()) {
          const Space v1853_10 = routine_125(c, v1850_6_head, v1850_5, v1850_6_tail);
          v1851_11 = compose(v1851_9,v1853_10);
        }
        const Space v1851_12 = unite(v1851_7,v1851_11);
        v1850_6_result = unite(v1850_6_result,v1851_12);
      }
      const Space v1850_6 = std::move(v1850_6_result);
      v1849_7 = compose(v1849_4,v1850_6);
    }
    v1848_6_result = unite(v1848_6_result,v1849_7);
  }
  const Space v1848_6 = std::move(v1848_6_result);
  return v1848_6;
}

static Space routine_215(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1854_12_result;
  for (int v1854_12_label = 1; v1854_12_label <= 2; ++v1854_12_label) {
    const Space v1854_12_tail = child(s0,v1854_12_label);
    if (v1854_12_tail.empty()) continue;
    const Path v1854_12_head{v1854_12_label};
    const Space v1855_2 = singleton(v1854_12_head);
    const Space v1855_3 = intersect(constant_8,v1855_2);
    const Space v1855_4 = (has_head(v1855_3) ? constant_9 : Space{});
    const Space v1855_5 = subtract(constant_0,v1855_4);
    Space v1855_8;
    if (!v1855_5.empty()) {
      const Path v1856_6 = concat_path(p0,v1854_12_head);
      Space v1856_7_result;
      for (int v1856_7_label = 1; v1856_7_label <= 2; ++v1856_7_label) {
        const Space v1856_7_tail = child(v1854_12_tail,v1856_7_label);
        if (v1856_7_tail.empty()) continue;
        const Path v1856_7_head{v1856_7_label};
        const Space v1857_2 = singleton(v1856_7_head);
        const Space v1857_3 = intersect(constant_8,v1857_2);
        const Space v1857_4 = (has_head(v1857_3) ? constant_9 : Space{});
        const Space v1857_5 = subtract(constant_0,v1857_4);
        Space v1857_8;
        if (!v1857_5.empty()) {
          const Path v1858_6 = concat_path(v1856_6,v1856_7_head);
          const Space v1858_7 = routine_281(c, v1858_6, p1, v1856_7_tail);
          v1857_8 = compose(v1857_5,v1858_7);
        }
        const Space v1857_9 = intersect(constant_8,v1857_2);
        const Space v1857_10 = (has_head(v1857_9) ? constant_9 : Space{});
        Space v1857_12;
        if (!v1857_10.empty()) {
          const Path v1859_6 = concat_path(v1856_6,v1856_7_head);
          const Space v1859_11 = routine_282(c, v1859_6, p1, v1856_7_tail);
          v1857_12 = compose(v1857_10,v1859_11);
        }
        const Space v1857_13 = unite(v1857_8,v1857_12);
        v1856_7_result = unite(v1856_7_result,v1857_13);
      }
      const Space v1856_7 = std::move(v1856_7_result);
      v1855_8 = compose(v1855_5,v1856_7);
    }
    const Space v1855_9 = intersect(constant_8,v1855_2);
    const Space v1855_10 = (has_head(v1855_9) ? constant_9 : Space{});
    Space v1855_12;
    if (!v1855_10.empty()) {
      const Path v1860_6 = concat_path(p0,v1854_12_head);
      Space v1860_11_result;
      for (int v1860_11_label = 1; v1860_11_label <= 2; ++v1860_11_label) {
        const Space v1860_11_tail = child(v1854_12_tail,v1860_11_label);
        if (v1860_11_tail.empty()) continue;
        const Path v1860_11_head{v1860_11_label};
        const Space v1861_2 = singleton(v1860_11_head);
        const Space v1861_3 = intersect(constant_8,v1861_2);
        const Space v1861_4 = (has_head(v1861_3) ? constant_9 : Space{});
        const Space v1861_5 = subtract(constant_0,v1861_4);
        Space v1861_8;
        if (!v1861_5.empty()) {
          const Path v1862_6 = concat_path(v1860_6,v1860_11_head);
          const Space v1862_7 = routine_281(c, v1862_6, p1, v1860_11_tail);
          v1861_8 = compose(v1861_5,v1862_7);
        }
        const Space v1861_9 = intersect(constant_8,v1861_2);
        const Space v1861_10 = (has_head(v1861_9) ? constant_9 : Space{});
        Space v1861_12;
        if (!v1861_10.empty()) {
          const Path v1863_6 = concat_path(v1860_6,v1860_11_head);
          const Space v1863_11 = routine_169(c, v1863_6, p1, v1860_11_tail);
          v1861_12 = compose(v1861_10,v1863_11);
        }
        const Space v1861_13 = unite(v1861_8,v1861_12);
        v1860_11_result = unite(v1860_11_result,v1861_13);
      }
      const Space v1860_11 = std::move(v1860_11_result);
      v1855_12 = compose(v1855_10,v1860_11);
    }
    const Space v1855_13 = unite(v1855_8,v1855_12);
    v1854_12_result = unite(v1854_12_result,v1855_13);
  }
  const Space v1854_12 = std::move(v1854_12_result);
  return v1854_12;
}

static Space routine_216(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1864_12_result;
  for (int v1864_12_label = 1; v1864_12_label <= 2; ++v1864_12_label) {
    const Space v1864_12_tail = child(s0,v1864_12_label);
    if (v1864_12_tail.empty()) continue;
    const Path v1864_12_head{v1864_12_label};
    const Space v1865_2 = singleton(v1864_12_head);
    const Space v1865_3 = intersect(constant_8,v1865_2);
    const Space v1865_4 = (has_head(v1865_3) ? constant_9 : Space{});
    const Space v1865_5 = subtract(constant_0,v1865_4);
    Space v1865_8;
    if (!v1865_5.empty()) {
      const Path v1866_6 = concat_path(p0,v1864_12_head);
      Space v1866_7_result;
      for (int v1866_7_label = 1; v1866_7_label <= 2; ++v1866_7_label) {
        const Space v1866_7_tail = child(v1864_12_tail,v1866_7_label);
        if (v1866_7_tail.empty()) continue;
        const Path v1866_7_head{v1866_7_label};
        const Space v1867_2 = singleton(v1866_7_head);
        const Space v1867_3 = intersect(constant_8,v1867_2);
        const Space v1867_4 = (has_head(v1867_3) ? constant_9 : Space{});
        const Space v1867_5 = subtract(constant_0,v1867_4);
        Space v1867_8;
        if (!v1867_5.empty()) {
          const Path v1868_6 = concat_path(v1866_6,v1866_7_head);
          const Space v1868_7 = routine_281(c, v1868_6, p1, v1866_7_tail);
          v1867_8 = compose(v1867_5,v1868_7);
        }
        const Space v1867_9 = intersect(constant_8,v1867_2);
        const Space v1867_10 = (has_head(v1867_9) ? constant_9 : Space{});
        Space v1867_12;
        if (!v1867_10.empty()) {
          const Path v1869_6 = concat_path(v1866_6,v1866_7_head);
          const Space v1869_11 = routine_282(c, v1869_6, p1, v1866_7_tail);
          v1867_12 = compose(v1867_10,v1869_11);
        }
        const Space v1867_13 = unite(v1867_8,v1867_12);
        v1866_7_result = unite(v1866_7_result,v1867_13);
      }
      const Space v1866_7 = std::move(v1866_7_result);
      v1865_8 = compose(v1865_5,v1866_7);
    }
    const Space v1865_9 = intersect(constant_8,v1865_2);
    const Space v1865_10 = (has_head(v1865_9) ? constant_9 : Space{});
    Space v1865_12;
    if (!v1865_10.empty()) {
      const Path v1870_6 = concat_path(p0,v1864_12_head);
      Space v1870_11_result;
      for (int v1870_11_label = 1; v1870_11_label <= 2; ++v1870_11_label) {
        const Space v1870_11_tail = child(v1864_12_tail,v1870_11_label);
        if (v1870_11_tail.empty()) continue;
        const Path v1870_11_head{v1870_11_label};
        const Space v1871_2 = singleton(v1870_11_head);
        const Space v1871_3 = intersect(constant_8,v1871_2);
        const Space v1871_4 = (has_head(v1871_3) ? constant_9 : Space{});
        const Space v1871_5 = subtract(constant_0,v1871_4);
        Space v1871_7;
        if (!v1871_5.empty()) {
          const Space v1872_6 = routine_217(c, v1870_11_head, p1, v1870_6, v1870_11_tail);
          v1871_7 = compose(v1871_5,v1872_6);
        }
        const Space v1871_8 = intersect(constant_8,v1871_2);
        const Space v1871_9 = (has_head(v1871_8) ? constant_9 : Space{});
        Space v1871_11;
        if (!v1871_9.empty()) {
          const Space v1873_10 = routine_218(c, v1870_11_head, p1, v1870_6, v1870_11_tail);
          v1871_11 = compose(v1871_9,v1873_10);
        }
        const Space v1871_12 = unite(v1871_7,v1871_11);
        v1870_11_result = unite(v1870_11_result,v1871_12);
      }
      const Space v1870_11 = std::move(v1870_11_result);
      v1865_12 = compose(v1865_10,v1870_11);
    }
    const Space v1865_13 = unite(v1865_8,v1865_12);
    v1864_12_result = unite(v1864_12_result,v1865_13);
  }
  const Space v1864_12 = std::move(v1864_12_result);
  return v1864_12;
}

static Space routine_217(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v1874_13_result;
  for (int v1874_13_label = 1; v1874_13_label <= 2; ++v1874_13_label) {
    const Space v1874_13_tail = child(s0,v1874_13_label);
    if (v1874_13_tail.empty()) continue;
    const Path v1874_13_head{v1874_13_label};
    const Space v1875_2 = singleton(v1874_13_head);
    const Space v1875_3 = intersect(constant_8,v1875_2);
    const Space v1875_4 = (has_head(v1875_3) ? constant_9 : Space{});
    const Space v1875_5 = subtract(constant_0,v1875_4);
    Space v1875_8;
    if (!v1875_5.empty()) {
      const Path v1876_6 = concat_path(p0,v1874_13_head);
      Space v1876_7_result;
      for (int v1876_7_label = 1; v1876_7_label <= 2; ++v1876_7_label) {
        const Space v1876_7_tail = child(v1874_13_tail,v1876_7_label);
        if (v1876_7_tail.empty()) continue;
        const Path v1876_7_head{v1876_7_label};
        const Space v1877_2 = singleton(v1876_7_head);
        const Space v1877_3 = intersect(constant_8,v1877_2);
        const Space v1877_4 = (has_head(v1877_3) ? constant_9 : Space{});
        const Space v1877_5 = subtract(constant_0,v1877_4);
        Space v1877_8;
        if (!v1877_5.empty()) {
          const Path v1878_6 = concat_path(v1876_6,v1876_7_head);
          const Space v1878_7 = routine_283(c, v1878_6, p1, p2, v1876_7_tail);
          v1877_8 = compose(v1877_5,v1878_7);
        }
        const Space v1877_9 = intersect(constant_8,v1877_2);
        const Space v1877_10 = (has_head(v1877_9) ? constant_9 : Space{});
        Space v1877_12;
        if (!v1877_10.empty()) {
          const Path v1879_6 = concat_path(v1876_6,v1876_7_head);
          const Space v1879_11 = routine_284(c, v1879_6, p1, p2, v1876_7_tail);
          v1877_12 = compose(v1877_10,v1879_11);
        }
        const Space v1877_13 = unite(v1877_8,v1877_12);
        v1876_7_result = unite(v1876_7_result,v1877_13);
      }
      const Space v1876_7 = std::move(v1876_7_result);
      v1875_8 = compose(v1875_5,v1876_7);
    }
    const Space v1875_9 = intersect(constant_8,v1875_2);
    const Space v1875_10 = (has_head(v1875_9) ? constant_9 : Space{});
    Space v1875_12;
    if (!v1875_10.empty()) {
      const Path v1880_6 = concat_path(p0,v1874_13_head);
      Space v1880_11_result;
      for (int v1880_11_label = 1; v1880_11_label <= 2; ++v1880_11_label) {
        const Space v1880_11_tail = child(v1874_13_tail,v1880_11_label);
        if (v1880_11_tail.empty()) continue;
        const Path v1880_11_head{v1880_11_label};
        const Space v1881_2 = singleton(v1880_11_head);
        const Space v1881_3 = intersect(constant_8,v1881_2);
        const Space v1881_4 = (has_head(v1881_3) ? constant_9 : Space{});
        const Space v1881_5 = subtract(constant_0,v1881_4);
        Space v1881_8;
        if (!v1881_5.empty()) {
          const Path v1882_6 = concat_path(v1880_6,v1880_11_head);
          const Space v1882_7 = routine_283(c, v1882_6, p1, p2, v1880_11_tail);
          v1881_8 = compose(v1881_5,v1882_7);
        }
        const Space v1881_9 = intersect(constant_8,v1881_2);
        const Space v1881_10 = (has_head(v1881_9) ? constant_9 : Space{});
        Space v1881_12;
        if (!v1881_10.empty()) {
          const Path v1883_6 = concat_path(v1880_6,v1880_11_head);
          const Space v1883_11 = routine_252(c, v1883_6, p1, p2, v1880_11_tail);
          v1881_12 = compose(v1881_10,v1883_11);
        }
        const Space v1881_13 = unite(v1881_8,v1881_12);
        v1880_11_result = unite(v1880_11_result,v1881_13);
      }
      const Space v1880_11 = std::move(v1880_11_result);
      v1875_12 = compose(v1875_10,v1880_11);
    }
    const Space v1875_13 = unite(v1875_8,v1875_12);
    v1874_13_result = unite(v1874_13_result,v1875_13);
  }
  const Space v1874_13 = std::move(v1874_13_result);
  return v1874_13;
}

static Space routine_218(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v1884_10 = concat_path(constant_23,p2);
  const Space v1884_11 = singleton(v1884_10);
  const Path v1884_13 = concat_path(constant_22,p1);
  const Space v1884_14 = singleton(v1884_13);
  Space v1884_18_result;
  for (int v1884_18_label = 1; v1884_18_label <= 2; ++v1884_18_label) {
    const Space v1884_18_tail = child(s0,v1884_18_label);
    if (v1884_18_tail.empty()) continue;
    const Path v1884_18_head{v1884_18_label};
    const Space v1885_2 = singleton(v1884_18_head);
    const Space v1885_3 = intersect(constant_8,v1885_2);
    const Space v1885_4 = (has_head(v1885_3) ? constant_9 : Space{});
    const Space v1885_5 = subtract(constant_0,v1885_4);
    Space v1885_8;
    if (!v1885_5.empty()) {
      const Path v1886_6 = concat_path(p0,v1884_18_head);
      Space v1886_7_result;
      for (int v1886_7_label = 1; v1886_7_label <= 2; ++v1886_7_label) {
        const Space v1886_7_tail = child(v1884_18_tail,v1886_7_label);
        if (v1886_7_tail.empty()) continue;
        const Path v1886_7_head{v1886_7_label};
        const Space v1887_2 = singleton(v1886_7_head);
        const Space v1887_3 = intersect(constant_8,v1887_2);
        const Space v1887_4 = (has_head(v1887_3) ? constant_9 : Space{});
        const Space v1887_5 = subtract(constant_0,v1887_4);
        Space v1887_8;
        if (!v1887_5.empty()) {
          const Path v1888_6 = concat_path(v1886_6,v1886_7_head);
          const Space v1888_7 = routine_283(c, v1888_6, p1, p2, v1886_7_tail);
          v1887_8 = compose(v1887_5,v1888_7);
        }
        const Space v1887_9 = intersect(constant_8,v1887_2);
        const Space v1887_10 = (has_head(v1887_9) ? constant_9 : Space{});
        Space v1887_12;
        if (!v1887_10.empty()) {
          const Path v1889_6 = concat_path(v1886_6,v1886_7_head);
          const Space v1889_11 = routine_284(c, v1889_6, p1, p2, v1886_7_tail);
          v1887_12 = compose(v1887_10,v1889_11);
        }
        const Space v1887_13 = unite(v1887_8,v1887_12);
        v1886_7_result = unite(v1886_7_result,v1887_13);
      }
      const Space v1886_7 = std::move(v1886_7_result);
      v1885_8 = compose(v1885_5,v1886_7);
    }
    const Space v1885_9 = intersect(constant_8,v1885_2);
    const Space v1885_10 = (has_head(v1885_9) ? constant_9 : Space{});
    const Path v1890_6 = concat_path(p0,v1884_18_head);
    const Path v1885_11 = concat_path(constant_24,v1890_6);
    const Space v1885_12 = singleton(v1885_11);
    const Space v1885_13 = unite(constant_29,v1885_12);
    const Space v1885_14 = unite(v1885_13,v1884_11);
    const Space v1885_15 = unite(v1885_14,v1884_14);
    const Space v1885_16 = compose(v1885_10,v1885_15);
    const Space v1885_17 = unite(v1885_8,v1885_16);
    v1884_18_result = unite(v1884_18_result,v1885_17);
  }
  const Space v1884_18 = std::move(v1884_18_result);
  return v1884_18;
}

static Space routine_219(Context& c, const Path& p0, const Space& s0) {
  Space v1891_6_result;
  for (int v1891_6_label = 1; v1891_6_label <= 2; ++v1891_6_label) {
    const Space v1891_6_tail = child(s0,v1891_6_label);
    if (v1891_6_tail.empty()) continue;
    const Path v1891_6_head{v1891_6_label};
    const Space v1892_2 = singleton(v1891_6_head);
    const Space v1892_3 = intersect(constant_8,v1892_2);
    const Space v1892_4 = (has_head(v1892_3) ? constant_9 : Space{});
    const Space v1892_5 = subtract(constant_0,v1892_4);
    Space v1892_6_result;
    for (int v1892_6_label = 1; v1892_6_label <= 2; ++v1892_6_label) {
      const Space v1892_6_tail = child(v1891_6_tail,v1892_6_label);
      if (v1892_6_tail.empty()) continue;
      const Path v1892_6_head{v1892_6_label};
      const Space v1893_2 = Space{};
      v1892_6_result = unite(v1892_6_result,v1893_2);
    }
    const Space v1892_6 = std::move(v1892_6_result);
    const Space v1892_7 = compose(v1892_5,v1892_6);
    const Space v1892_8 = intersect(constant_8,v1892_2);
    const Space v1892_9 = (has_head(v1892_8) ? constant_9 : Space{});
    Space v1892_12;
    if (!v1892_9.empty()) {
      const Path v1894_10 = concat_path(p0,v1891_6_head);
      Space v1894_11_result;
      for (int v1894_11_label = 1; v1894_11_label <= 2; ++v1894_11_label) {
        const Space v1894_11_tail = child(v1891_6_tail,v1894_11_label);
        if (v1894_11_tail.empty()) continue;
        const Path v1894_11_head{v1894_11_label};
        const Space v1895_2 = singleton(v1894_11_head);
        const Space v1895_3 = intersect(constant_8,v1895_2);
        const Space v1895_4 = (has_head(v1895_3) ? constant_9 : Space{});
        Space v1895_7;
        if (!v1895_4.empty()) {
          const Path v1896_5 = concat_path(v1894_10,v1894_11_head);
          const Space v1896_6 = routine_130(c, v1896_5, v1894_11_tail);
          v1895_7 = compose(v1895_4,v1896_6);
        }
        v1894_11_result = unite(v1894_11_result,v1895_7);
      }
      const Space v1894_11 = std::move(v1894_11_result);
      v1892_12 = compose(v1892_9,v1894_11);
    }
    const Space v1892_13 = unite(v1892_7,v1892_12);
    v1891_6_result = unite(v1891_6_result,v1892_13);
  }
  const Space v1891_6 = std::move(v1891_6_result);
  return v1891_6;
}

static Space routine_220(Context& c, const Path& p0, const Space& s0) {
  Space v1897_8_result;
  for (int v1897_8_label = 1; v1897_8_label <= 2; ++v1897_8_label) {
    const Space v1897_8_tail = child(s0,v1897_8_label);
    if (v1897_8_tail.empty()) continue;
    const Path v1897_8_head{v1897_8_label};
    const Space v1898_2 = singleton(v1897_8_head);
    const Space v1898_3 = intersect(constant_8,v1898_2);
    const Space v1898_4 = (has_head(v1898_3) ? constant_9 : Space{});
    const Space v1898_5 = subtract(constant_0,v1898_4);
    Space v1898_6_result;
    for (int v1898_6_label = 1; v1898_6_label <= 2; ++v1898_6_label) {
      const Space v1898_6_tail = child(v1897_8_tail,v1898_6_label);
      if (v1898_6_tail.empty()) continue;
      const Path v1898_6_head{v1898_6_label};
      const Space v1899_2 = Space{};
      v1898_6_result = unite(v1898_6_result,v1899_2);
    }
    const Space v1898_6 = std::move(v1898_6_result);
    const Space v1898_7 = compose(v1898_5,v1898_6);
    const Space v1898_8 = intersect(constant_8,v1898_2);
    const Space v1898_9 = (has_head(v1898_8) ? constant_9 : Space{});
    Space v1898_12;
    if (!v1898_9.empty()) {
      const Path v1900_10 = concat_path(p0,v1897_8_head);
      Space v1900_11_result;
      for (int v1900_11_label = 1; v1900_11_label <= 2; ++v1900_11_label) {
        const Space v1900_11_tail = child(v1897_8_tail,v1900_11_label);
        if (v1900_11_tail.empty()) continue;
        const Path v1900_11_head{v1900_11_label};
        const Space v1901_2 = singleton(v1900_11_head);
        const Space v1901_3 = intersect(constant_8,v1901_2);
        const Space v1901_4 = (has_head(v1901_3) ? constant_9 : Space{});
        const Space v1901_5 = subtract(constant_0,v1901_4);
        Space v1901_7;
        if (!v1901_5.empty()) {
          const Space v1902_6 = routine_174(c, v1900_11_head, v1900_10, v1900_11_tail);
          v1901_7 = compose(v1901_5,v1902_6);
        }
        const Space v1901_8 = intersect(constant_8,v1901_2);
        const Space v1901_9 = (has_head(v1901_8) ? constant_9 : Space{});
        Space v1901_11;
        if (!v1901_9.empty()) {
          const Space v1903_10 = routine_175(c, v1900_11_head, v1900_10, v1900_11_tail);
          v1901_11 = compose(v1901_9,v1903_10);
        }
        const Space v1901_12 = unite(v1901_7,v1901_11);
        v1900_11_result = unite(v1900_11_result,v1901_12);
      }
      const Space v1900_11 = std::move(v1900_11_result);
      v1898_12 = compose(v1898_9,v1900_11);
    }
    const Space v1898_13 = unite(v1898_7,v1898_12);
    v1897_8_result = unite(v1897_8_result,v1898_13);
  }
  const Space v1897_8 = std::move(v1897_8_result);
  return v1897_8;
}

static Space routine_221(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1904_12_result;
  for (int v1904_12_label = 1; v1904_12_label <= 2; ++v1904_12_label) {
    const Space v1904_12_tail = child(s0,v1904_12_label);
    if (v1904_12_tail.empty()) continue;
    const Path v1904_12_head{v1904_12_label};
    const Space v1905_2 = singleton(v1904_12_head);
    const Space v1905_3 = intersect(constant_8,v1905_2);
    const Space v1905_4 = (has_head(v1905_3) ? constant_9 : Space{});
    const Space v1905_5 = subtract(constant_0,v1905_4);
    Space v1905_8;
    if (!v1905_5.empty()) {
      const Path v1906_6 = concat_path(p0,v1904_12_head);
      Space v1906_7_result;
      for (int v1906_7_label = 1; v1906_7_label <= 2; ++v1906_7_label) {
        const Space v1906_7_tail = child(v1904_12_tail,v1906_7_label);
        if (v1906_7_tail.empty()) continue;
        const Path v1906_7_head{v1906_7_label};
        const Space v1907_2 = singleton(v1906_7_head);
        const Space v1907_3 = intersect(constant_8,v1907_2);
        const Space v1907_4 = (has_head(v1907_3) ? constant_9 : Space{});
        const Space v1907_5 = subtract(constant_0,v1907_4);
        Space v1907_8;
        if (!v1907_5.empty()) {
          const Path v1908_6 = concat_path(v1906_6,v1906_7_head);
          const Space v1908_7 = routine_285(c, v1908_6, p1, v1906_7_tail);
          v1907_8 = compose(v1907_5,v1908_7);
        }
        const Space v1907_9 = intersect(constant_8,v1907_2);
        const Space v1907_10 = (has_head(v1907_9) ? constant_9 : Space{});
        Space v1907_12;
        if (!v1907_10.empty()) {
          const Path v1909_6 = concat_path(v1906_6,v1906_7_head);
          const Space v1909_11 = routine_286(c, v1909_6, p1, v1906_7_tail);
          v1907_12 = compose(v1907_10,v1909_11);
        }
        const Space v1907_13 = unite(v1907_8,v1907_12);
        v1906_7_result = unite(v1906_7_result,v1907_13);
      }
      const Space v1906_7 = std::move(v1906_7_result);
      v1905_8 = compose(v1905_5,v1906_7);
    }
    const Space v1905_9 = intersect(constant_8,v1905_2);
    const Space v1905_10 = (has_head(v1905_9) ? constant_9 : Space{});
    Space v1905_12;
    if (!v1905_10.empty()) {
      const Path v1910_6 = concat_path(p0,v1904_12_head);
      Space v1910_11_result;
      for (int v1910_11_label = 1; v1910_11_label <= 2; ++v1910_11_label) {
        const Space v1910_11_tail = child(v1904_12_tail,v1910_11_label);
        if (v1910_11_tail.empty()) continue;
        const Path v1910_11_head{v1910_11_label};
        const Space v1911_2 = singleton(v1910_11_head);
        const Space v1911_3 = intersect(constant_8,v1911_2);
        const Space v1911_4 = (has_head(v1911_3) ? constant_9 : Space{});
        const Space v1911_5 = subtract(constant_0,v1911_4);
        Space v1911_8;
        if (!v1911_5.empty()) {
          const Path v1912_6 = concat_path(v1910_6,v1910_11_head);
          const Space v1912_7 = routine_285(c, v1912_6, p1, v1910_11_tail);
          v1911_8 = compose(v1911_5,v1912_7);
        }
        const Space v1911_9 = intersect(constant_8,v1911_2);
        const Space v1911_10 = (has_head(v1911_9) ? constant_9 : Space{});
        Space v1911_12;
        if (!v1911_10.empty()) {
          const Path v1913_6 = concat_path(v1910_6,v1910_11_head);
          const Space v1913_11 = routine_223(c, v1913_6, p1, v1910_11_tail);
          v1911_12 = compose(v1911_10,v1913_11);
        }
        const Space v1911_13 = unite(v1911_8,v1911_12);
        v1910_11_result = unite(v1910_11_result,v1911_13);
      }
      const Space v1910_11 = std::move(v1910_11_result);
      v1905_12 = compose(v1905_10,v1910_11);
    }
    const Space v1905_13 = unite(v1905_8,v1905_12);
    v1904_12_result = unite(v1904_12_result,v1905_13);
  }
  const Space v1904_12 = std::move(v1904_12_result);
  return v1904_12;
}

static Space routine_222(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1914_13_result;
  for (int v1914_13_label = 1; v1914_13_label <= 2; ++v1914_13_label) {
    const Space v1914_13_tail = child(s0,v1914_13_label);
    if (v1914_13_tail.empty()) continue;
    const Path v1914_13_head{v1914_13_label};
    const Space v1915_2 = singleton(v1914_13_head);
    const Space v1915_3 = intersect(constant_8,v1915_2);
    const Space v1915_4 = (has_head(v1915_3) ? constant_9 : Space{});
    const Space v1915_5 = subtract(constant_0,v1915_4);
    Space v1915_8;
    if (!v1915_5.empty()) {
      const Path v1916_6 = concat_path(p0,v1914_13_head);
      Space v1916_7_result;
      for (int v1916_7_label = 1; v1916_7_label <= 2; ++v1916_7_label) {
        const Space v1916_7_tail = child(v1914_13_tail,v1916_7_label);
        if (v1916_7_tail.empty()) continue;
        const Path v1916_7_head{v1916_7_label};
        const Space v1917_2 = singleton(v1916_7_head);
        const Space v1917_3 = intersect(constant_8,v1917_2);
        const Space v1917_4 = (has_head(v1917_3) ? constant_9 : Space{});
        const Space v1917_5 = subtract(constant_0,v1917_4);
        Space v1917_8;
        if (!v1917_5.empty()) {
          const Path v1918_6 = concat_path(v1916_6,v1916_7_head);
          const Space v1918_7 = routine_285(c, v1918_6, p1, v1916_7_tail);
          v1917_8 = compose(v1917_5,v1918_7);
        }
        const Space v1917_9 = intersect(constant_8,v1917_2);
        const Space v1917_10 = (has_head(v1917_9) ? constant_9 : Space{});
        Space v1917_12;
        if (!v1917_10.empty()) {
          const Path v1919_6 = concat_path(v1916_6,v1916_7_head);
          const Space v1919_11 = routine_286(c, v1919_6, p1, v1916_7_tail);
          v1917_12 = compose(v1917_10,v1919_11);
        }
        const Space v1917_13 = unite(v1917_8,v1917_12);
        v1916_7_result = unite(v1916_7_result,v1917_13);
      }
      const Space v1916_7 = std::move(v1916_7_result);
      v1915_8 = compose(v1915_5,v1916_7);
    }
    const Space v1915_9 = intersect(constant_8,v1915_2);
    const Space v1915_10 = (has_head(v1915_9) ? constant_9 : Space{});
    Space v1915_14;
    if (!v1915_10.empty()) {
      Space v1920_11_result;
      for (int v1920_11_label = 1; v1920_11_label <= 2; ++v1920_11_label) {
        const Space v1920_11_tail = child(v1914_13_tail,v1920_11_label);
        if (v1920_11_tail.empty()) continue;
        const Path v1920_11_head{v1920_11_label};
        const Space v1921_2 = singleton(v1920_11_head);
        const Space v1921_3 = intersect(constant_8,v1921_2);
        const Space v1921_4 = (has_head(v1921_3) ? constant_9 : Space{});
        const Space v1921_5 = subtract(constant_0,v1921_4);
        Space v1921_7;
        if (!v1921_5.empty()) {
          const Space v1922_6 = routine_257(c, v1920_11_head, v1920_11_tail);
          v1921_7 = compose(v1921_5,v1922_6);
        }
        const Space v1921_8 = intersect(constant_8,v1921_2);
        const Space v1921_9 = (has_head(v1921_8) ? constant_9 : Space{});
        Space v1921_11;
        if (!v1921_9.empty()) {
          const Space v1923_10 = routine_258(c, v1920_11_head, v1920_11_tail);
          v1921_11 = compose(v1921_9,v1923_10);
        }
        const Space v1921_12 = unite(v1921_7,v1921_11);
        v1920_11_result = unite(v1920_11_result,v1921_12);
      }
      const Space v1920_11 = std::move(v1920_11_result);
      const Space v1920_12 = raffine(constant_25,v1920_11);
      const Space v1920_13 = unite(v1920_12,v1914_13_tail);
      v1915_14 = compose(v1915_10,v1920_13);
    }
    const Path v1924_6 = concat_path(p0,v1914_13_head);
    const Path v1915_15 = concat_path(p1,v1924_6);
    const Space v1915_16 = wrap(v1915_14,v1915_15);
    const Space v1915_17 = unite(v1915_8,v1915_16);
    v1914_13_result = unite(v1914_13_result,v1915_17);
  }
  const Space v1914_13 = std::move(v1914_13_result);
  return v1914_13;
}

static Space routine_223(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1925_13_result;
  for (int v1925_13_label = 1; v1925_13_label <= 2; ++v1925_13_label) {
    const Space v1925_13_tail = child(s0,v1925_13_label);
    if (v1925_13_tail.empty()) continue;
    const Path v1925_13_head{v1925_13_label};
    const Space v1926_2 = singleton(v1925_13_head);
    const Space v1926_3 = intersect(constant_8,v1926_2);
    const Space v1926_4 = (has_head(v1926_3) ? constant_9 : Space{});
    const Space v1926_5 = subtract(constant_0,v1926_4);
    Space v1926_7;
    if (!v1926_5.empty()) {
      Space v1927_6_result;
      for (int v1927_6_label = 1; v1927_6_label <= 2; ++v1927_6_label) {
        const Space v1927_6_tail = child(v1925_13_tail,v1927_6_label);
        if (v1927_6_tail.empty()) continue;
        const Path v1927_6_head{v1927_6_label};
        const Space v1928_2 = singleton(v1927_6_head);
        const Space v1928_3 = intersect(constant_8,v1928_2);
        const Space v1928_4 = (has_head(v1928_3) ? constant_9 : Space{});
        const Space v1928_5 = subtract(constant_0,v1928_4);
        Space v1928_8;
        if (!v1928_5.empty()) {
          const Path v1929_6 = concat_path(v1925_13_head,v1927_6_head);
          const Space v1929_7 = routine_287(c, v1929_6, v1927_6_tail);
          v1928_8 = compose(v1928_5,v1929_7);
        }
        const Space v1928_9 = intersect(constant_8,v1928_2);
        const Space v1928_10 = (has_head(v1928_9) ? constant_9 : Space{});
        Space v1928_12;
        if (!v1928_10.empty()) {
          const Path v1930_6 = concat_path(v1925_13_head,v1927_6_head);
          const Space v1930_11 = routine_288(c, v1930_6, v1927_6_tail);
          v1928_12 = compose(v1928_10,v1930_11);
        }
        const Space v1928_13 = unite(v1928_8,v1928_12);
        v1927_6_result = unite(v1927_6_result,v1928_13);
      }
      const Space v1927_6 = std::move(v1927_6_result);
      v1926_7 = compose(v1926_5,v1927_6);
    }
    const Space v1926_8 = intersect(constant_8,v1926_2);
    const Space v1926_9 = (has_head(v1926_8) ? constant_9 : Space{});
    Space v1926_11;
    if (!v1926_9.empty()) {
      Space v1931_10_result;
      for (int v1931_10_label = 1; v1931_10_label <= 2; ++v1931_10_label) {
        const Space v1931_10_tail = child(v1925_13_tail,v1931_10_label);
        if (v1931_10_tail.empty()) continue;
        const Path v1931_10_head{v1931_10_label};
        const Space v1932_2 = singleton(v1931_10_head);
        const Space v1932_3 = intersect(constant_8,v1932_2);
        const Space v1932_4 = (has_head(v1932_3) ? constant_9 : Space{});
        const Space v1932_5 = subtract(constant_0,v1932_4);
        Space v1932_8;
        if (!v1932_5.empty()) {
          const Path v1933_6 = concat_path(v1925_13_head,v1931_10_head);
          const Space v1933_7 = routine_287(c, v1933_6, v1931_10_tail);
          v1932_8 = compose(v1932_5,v1933_7);
        }
        const Space v1932_9 = intersect(constant_8,v1932_2);
        const Space v1932_10 = (has_head(v1932_9) ? constant_9 : Space{});
        Space v1932_12;
        if (!v1932_10.empty()) {
          const Path v1934_6 = concat_path(v1925_13_head,v1931_10_head);
          const Space v1934_11 = routine_289(c, v1934_6, v1931_10_tail);
          v1932_12 = compose(v1932_10,v1934_11);
        }
        const Space v1932_13 = unite(v1932_8,v1932_12);
        v1931_10_result = unite(v1931_10_result,v1932_13);
      }
      const Space v1931_10 = std::move(v1931_10_result);
      v1926_11 = compose(v1926_9,v1931_10);
    }
    const Space v1926_12 = unite(v1926_7,v1926_11);
    v1925_13_result = unite(v1925_13_result,v1926_12);
  }
  const Space v1925_13 = std::move(v1925_13_result);
  const Space v1925_14 = raffine(constant_25,v1925_13);
  const Space v1925_15 = unite(v1925_14,s0);
  const Path v1925_16 = concat_path(p1,p0);
  const Space v1925_17 = wrap(v1925_15,v1925_16);
  return v1925_17;
}

static Space routine_224(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1935_8_result;
  for (int v1935_8_label = 1; v1935_8_label <= 2; ++v1935_8_label) {
    const Space v1935_8_tail = child(s0,v1935_8_label);
    if (v1935_8_tail.empty()) continue;
    const Path v1935_8_head{v1935_8_label};
    const Space v1936_2 = singleton(v1935_8_head);
    const Space v1936_3 = intersect(constant_8,v1936_2);
    const Space v1936_4 = (has_head(v1936_3) ? constant_9 : Space{});
    const Space v1936_5 = subtract(constant_0,v1936_4);
    Space v1936_6_result;
    for (int v1936_6_label = 1; v1936_6_label <= 2; ++v1936_6_label) {
      const Space v1936_6_tail = child(v1935_8_tail,v1936_6_label);
      if (v1936_6_tail.empty()) continue;
      const Path v1936_6_head{v1936_6_label};
      const Space v1937_2 = Space{};
      v1936_6_result = unite(v1936_6_result,v1937_2);
    }
    const Space v1936_6 = std::move(v1936_6_result);
    const Space v1936_7 = compose(v1936_5,v1936_6);
    const Space v1936_8 = intersect(constant_8,v1936_2);
    const Space v1936_9 = (has_head(v1936_8) ? constant_9 : Space{});
    Space v1936_12;
    if (!v1936_9.empty()) {
      const Path v1938_10 = concat_path(p0,v1935_8_head);
      Space v1938_11_result;
      for (int v1938_11_label = 1; v1938_11_label <= 2; ++v1938_11_label) {
        const Space v1938_11_tail = child(v1935_8_tail,v1938_11_label);
        if (v1938_11_tail.empty()) continue;
        const Path v1938_11_head{v1938_11_label};
        const Space v1939_2 = singleton(v1938_11_head);
        const Space v1939_3 = intersect(constant_8,v1939_2);
        const Space v1939_4 = (has_head(v1939_3) ? constant_9 : Space{});
        Space v1939_7;
        if (!v1939_4.empty()) {
          const Path v1940_5 = concat_path(v1938_10,v1938_11_head);
          const Space v1940_6 = routine_133(c, v1940_5, p1, v1938_11_tail, s1);
          v1939_7 = compose(v1939_4,v1940_6);
        }
        v1938_11_result = unite(v1938_11_result,v1939_7);
      }
      const Space v1938_11 = std::move(v1938_11_result);
      v1936_12 = compose(v1936_9,v1938_11);
    }
    const Space v1936_13 = unite(v1936_7,v1936_12);
    v1935_8_result = unite(v1935_8_result,v1936_13);
  }
  const Space v1935_8 = std::move(v1935_8_result);
  return v1935_8;
}

static Space routine_225(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1941_7_result;
  for (int v1941_7_label = 1; v1941_7_label <= 2; ++v1941_7_label) {
    const Space v1941_7_tail = child(s0,v1941_7_label);
    if (v1941_7_tail.empty()) continue;
    const Path v1941_7_head{v1941_7_label};
    const Space v1942_2 = singleton(v1941_7_head);
    const Space v1942_3 = intersect(constant_8,v1942_2);
    const Space v1942_4 = (has_head(v1942_3) ? constant_9 : Space{});
    const Space v1942_5 = subtract(constant_0,v1942_4);
    Space v1942_6_result;
    for (int v1942_6_label = 1; v1942_6_label <= 2; ++v1942_6_label) {
      const Space v1942_6_tail = child(v1941_7_tail,v1942_6_label);
      if (v1942_6_tail.empty()) continue;
      const Path v1942_6_head{v1942_6_label};
      const Space v1943_2 = Space{};
      v1942_6_result = unite(v1942_6_result,v1943_2);
    }
    const Space v1942_6 = std::move(v1942_6_result);
    const Space v1942_7 = compose(v1942_5,v1942_6);
    const Space v1942_8 = intersect(constant_8,v1942_2);
    const Space v1942_9 = (has_head(v1942_8) ? constant_9 : Space{});
    const Space v1942_10 = unwrap(v1941_7_tail,p1);
    const Path v1942_11 = concat_path(p0,v1941_7_head);
    const Space v1942_12 = wrap(v1942_10,v1942_11);
    const Space v1942_13 = compose(v1942_12,s1);
    const Space v1942_14 = compose(v1942_9,v1942_13);
    const Space v1942_15 = unite(v1942_7,v1942_14);
    v1941_7_result = unite(v1941_7_result,v1942_15);
  }
  const Space v1941_7 = std::move(v1941_7_result);
  return v1941_7;
}

static Space routine_226(Context& c, const Path& p0, const Space& s0) {
  Space v1944_6_result;
  for (int v1944_6_label = 1; v1944_6_label <= 2; ++v1944_6_label) {
    const Space v1944_6_tail = child(s0,v1944_6_label);
    if (v1944_6_tail.empty()) continue;
    const Path v1944_6_head{v1944_6_label};
    const Space v1945_2 = singleton(v1944_6_head);
    const Space v1945_3 = intersect(constant_8,v1945_2);
    const Space v1945_4 = (has_head(v1945_3) ? constant_9 : Space{});
    const Space v1945_5 = subtract(constant_0,v1945_4);
    Space v1945_6_result;
    for (int v1945_6_label = 1; v1945_6_label <= 2; ++v1945_6_label) {
      const Space v1945_6_tail = child(v1944_6_tail,v1945_6_label);
      if (v1945_6_tail.empty()) continue;
      const Path v1945_6_head{v1945_6_label};
      const Space v1946_2 = Space{};
      v1945_6_result = unite(v1945_6_result,v1946_2);
    }
    const Space v1945_6 = std::move(v1945_6_result);
    const Space v1945_7 = compose(v1945_5,v1945_6);
    const Space v1945_8 = intersect(constant_8,v1945_2);
    const Space v1945_9 = (has_head(v1945_8) ? constant_9 : Space{});
    Space v1945_12;
    if (!v1945_9.empty()) {
      const Path v1947_10 = concat_path(p0,v1944_6_head);
      Space v1947_11_result;
      for (int v1947_11_label = 1; v1947_11_label <= 2; ++v1947_11_label) {
        const Space v1947_11_tail = child(v1944_6_tail,v1947_11_label);
        if (v1947_11_tail.empty()) continue;
        const Path v1947_11_head{v1947_11_label};
        const Space v1948_2 = singleton(v1947_11_head);
        const Space v1948_3 = intersect(constant_8,v1948_2);
        const Space v1948_4 = (has_head(v1948_3) ? constant_9 : Space{});
        Space v1948_7;
        if (!v1948_4.empty()) {
          const Path v1949_5 = concat_path(v1947_10,v1947_11_head);
          const Space v1949_6 = routine_138(c, v1949_5, v1947_11_tail);
          v1948_7 = compose(v1948_4,v1949_6);
        }
        v1947_11_result = unite(v1947_11_result,v1948_7);
      }
      const Space v1947_11 = std::move(v1947_11_result);
      v1945_12 = compose(v1945_9,v1947_11);
    }
    const Space v1945_13 = unite(v1945_7,v1945_12);
    v1944_6_result = unite(v1944_6_result,v1945_13);
  }
  const Space v1944_6 = std::move(v1944_6_result);
  return v1944_6;
}

static Space routine_227(Context& c, const Path& p0, const Space& s0) {
  Space v1950_8_result;
  for (int v1950_8_label = 1; v1950_8_label <= 2; ++v1950_8_label) {
    const Space v1950_8_tail = child(s0,v1950_8_label);
    if (v1950_8_tail.empty()) continue;
    const Path v1950_8_head{v1950_8_label};
    const Space v1951_2 = singleton(v1950_8_head);
    const Space v1951_3 = intersect(constant_8,v1951_2);
    const Space v1951_4 = (has_head(v1951_3) ? constant_9 : Space{});
    const Space v1951_5 = subtract(constant_0,v1951_4);
    Space v1951_6_result;
    for (int v1951_6_label = 1; v1951_6_label <= 2; ++v1951_6_label) {
      const Space v1951_6_tail = child(v1950_8_tail,v1951_6_label);
      if (v1951_6_tail.empty()) continue;
      const Path v1951_6_head{v1951_6_label};
      const Space v1952_2 = Space{};
      v1951_6_result = unite(v1951_6_result,v1952_2);
    }
    const Space v1951_6 = std::move(v1951_6_result);
    const Space v1951_7 = compose(v1951_5,v1951_6);
    const Space v1951_8 = intersect(constant_8,v1951_2);
    const Space v1951_9 = (has_head(v1951_8) ? constant_9 : Space{});
    Space v1951_12;
    if (!v1951_9.empty()) {
      const Path v1953_10 = concat_path(p0,v1950_8_head);
      Space v1953_11_result;
      for (int v1953_11_label = 1; v1953_11_label <= 2; ++v1953_11_label) {
        const Space v1953_11_tail = child(v1950_8_tail,v1953_11_label);
        if (v1953_11_tail.empty()) continue;
        const Path v1953_11_head{v1953_11_label};
        const Space v1954_2 = singleton(v1953_11_head);
        const Space v1954_3 = intersect(constant_8,v1954_2);
        const Space v1954_4 = (has_head(v1954_3) ? constant_9 : Space{});
        const Space v1954_5 = subtract(constant_0,v1954_4);
        Space v1954_7;
        if (!v1954_5.empty()) {
          const Space v1955_6 = routine_182(c, v1953_11_head, v1953_10, v1953_11_tail);
          v1954_7 = compose(v1954_5,v1955_6);
        }
        const Space v1954_8 = intersect(constant_8,v1954_2);
        const Space v1954_9 = (has_head(v1954_8) ? constant_9 : Space{});
        Space v1954_11;
        if (!v1954_9.empty()) {
          const Space v1956_10 = routine_183(c, v1953_11_head, v1953_10, v1953_11_tail);
          v1954_11 = compose(v1954_9,v1956_10);
        }
        const Space v1954_12 = unite(v1954_7,v1954_11);
        v1953_11_result = unite(v1953_11_result,v1954_12);
      }
      const Space v1953_11 = std::move(v1953_11_result);
      v1951_12 = compose(v1951_9,v1953_11);
    }
    const Space v1951_13 = unite(v1951_7,v1951_12);
    v1950_8_result = unite(v1950_8_result,v1951_13);
  }
  const Space v1950_8 = std::move(v1950_8_result);
  return v1950_8;
}

static Space routine_228(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1957_12_result;
  for (int v1957_12_label = 1; v1957_12_label <= 2; ++v1957_12_label) {
    const Space v1957_12_tail = child(s0,v1957_12_label);
    if (v1957_12_tail.empty()) continue;
    const Path v1957_12_head{v1957_12_label};
    const Space v1958_2 = singleton(v1957_12_head);
    const Space v1958_3 = intersect(constant_8,v1958_2);
    const Space v1958_4 = (has_head(v1958_3) ? constant_9 : Space{});
    const Space v1958_5 = subtract(constant_0,v1958_4);
    Space v1958_8;
    if (!v1958_5.empty()) {
      const Path v1959_6 = concat_path(p0,v1957_12_head);
      Space v1959_7_result;
      for (int v1959_7_label = 1; v1959_7_label <= 2; ++v1959_7_label) {
        const Space v1959_7_tail = child(v1957_12_tail,v1959_7_label);
        if (v1959_7_tail.empty()) continue;
        const Path v1959_7_head{v1959_7_label};
        const Space v1960_2 = singleton(v1959_7_head);
        const Space v1960_3 = intersect(constant_8,v1960_2);
        const Space v1960_4 = (has_head(v1960_3) ? constant_9 : Space{});
        const Space v1960_5 = subtract(constant_0,v1960_4);
        Space v1960_8;
        if (!v1960_5.empty()) {
          const Path v1961_6 = concat_path(v1959_6,v1959_7_head);
          const Space v1961_7 = routine_290(c, v1961_6, p1, v1959_7_tail);
          v1960_8 = compose(v1960_5,v1961_7);
        }
        const Space v1960_9 = intersect(constant_8,v1960_2);
        const Space v1960_10 = (has_head(v1960_9) ? constant_9 : Space{});
        Space v1960_12;
        if (!v1960_10.empty()) {
          const Path v1962_6 = concat_path(v1959_6,v1959_7_head);
          const Space v1962_11 = routine_291(c, v1962_6, p1, v1959_7_tail);
          v1960_12 = compose(v1960_10,v1962_11);
        }
        const Space v1960_13 = unite(v1960_8,v1960_12);
        v1959_7_result = unite(v1959_7_result,v1960_13);
      }
      const Space v1959_7 = std::move(v1959_7_result);
      v1958_8 = compose(v1958_5,v1959_7);
    }
    const Space v1958_9 = intersect(constant_8,v1958_2);
    const Space v1958_10 = (has_head(v1958_9) ? constant_9 : Space{});
    Space v1958_12;
    if (!v1958_10.empty()) {
      const Path v1963_6 = concat_path(p0,v1957_12_head);
      Space v1963_11_result;
      for (int v1963_11_label = 1; v1963_11_label <= 2; ++v1963_11_label) {
        const Space v1963_11_tail = child(v1957_12_tail,v1963_11_label);
        if (v1963_11_tail.empty()) continue;
        const Path v1963_11_head{v1963_11_label};
        const Space v1964_2 = singleton(v1963_11_head);
        const Space v1964_3 = intersect(constant_8,v1964_2);
        const Space v1964_4 = (has_head(v1964_3) ? constant_9 : Space{});
        const Space v1964_5 = subtract(constant_0,v1964_4);
        Space v1964_8;
        if (!v1964_5.empty()) {
          const Path v1965_6 = concat_path(v1963_6,v1963_11_head);
          const Space v1965_7 = routine_290(c, v1965_6, p1, v1963_11_tail);
          v1964_8 = compose(v1964_5,v1965_7);
        }
        const Space v1964_9 = intersect(constant_8,v1964_2);
        const Space v1964_10 = (has_head(v1964_9) ? constant_9 : Space{});
        Space v1964_12;
        if (!v1964_10.empty()) {
          const Path v1966_6 = concat_path(v1963_6,v1963_11_head);
          const Space v1966_11 = routine_230(c, v1966_6, p1, v1963_11_tail);
          v1964_12 = compose(v1964_10,v1966_11);
        }
        const Space v1964_13 = unite(v1964_8,v1964_12);
        v1963_11_result = unite(v1963_11_result,v1964_13);
      }
      const Space v1963_11 = std::move(v1963_11_result);
      v1958_12 = compose(v1958_10,v1963_11);
    }
    const Space v1958_13 = unite(v1958_8,v1958_12);
    v1957_12_result = unite(v1957_12_result,v1958_13);
  }
  const Space v1957_12 = std::move(v1957_12_result);
  return v1957_12;
}

static Space routine_229(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1967_13_result;
  for (int v1967_13_label = 1; v1967_13_label <= 2; ++v1967_13_label) {
    const Space v1967_13_tail = child(s0,v1967_13_label);
    if (v1967_13_tail.empty()) continue;
    const Path v1967_13_head{v1967_13_label};
    const Space v1968_2 = singleton(v1967_13_head);
    const Space v1968_3 = intersect(constant_8,v1968_2);
    const Space v1968_4 = (has_head(v1968_3) ? constant_9 : Space{});
    const Space v1968_5 = subtract(constant_0,v1968_4);
    Space v1968_8;
    if (!v1968_5.empty()) {
      const Path v1969_6 = concat_path(p0,v1967_13_head);
      Space v1969_7_result;
      for (int v1969_7_label = 1; v1969_7_label <= 2; ++v1969_7_label) {
        const Space v1969_7_tail = child(v1967_13_tail,v1969_7_label);
        if (v1969_7_tail.empty()) continue;
        const Path v1969_7_head{v1969_7_label};
        const Space v1970_2 = singleton(v1969_7_head);
        const Space v1970_3 = intersect(constant_8,v1970_2);
        const Space v1970_4 = (has_head(v1970_3) ? constant_9 : Space{});
        const Space v1970_5 = subtract(constant_0,v1970_4);
        Space v1970_8;
        if (!v1970_5.empty()) {
          const Path v1971_6 = concat_path(v1969_6,v1969_7_head);
          const Space v1971_7 = routine_290(c, v1971_6, p1, v1969_7_tail);
          v1970_8 = compose(v1970_5,v1971_7);
        }
        const Space v1970_9 = intersect(constant_8,v1970_2);
        const Space v1970_10 = (has_head(v1970_9) ? constant_9 : Space{});
        Space v1970_12;
        if (!v1970_10.empty()) {
          const Path v1972_6 = concat_path(v1969_6,v1969_7_head);
          const Space v1972_11 = routine_291(c, v1972_6, p1, v1969_7_tail);
          v1970_12 = compose(v1970_10,v1972_11);
        }
        const Space v1970_13 = unite(v1970_8,v1970_12);
        v1969_7_result = unite(v1969_7_result,v1970_13);
      }
      const Space v1969_7 = std::move(v1969_7_result);
      v1968_8 = compose(v1968_5,v1969_7);
    }
    const Space v1968_9 = intersect(constant_8,v1968_2);
    const Space v1968_10 = (has_head(v1968_9) ? constant_9 : Space{});
    Space v1968_14;
    if (!v1968_10.empty()) {
      Space v1973_11_result;
      for (int v1973_11_label = 1; v1973_11_label <= 2; ++v1973_11_label) {
        const Space v1973_11_tail = child(v1967_13_tail,v1973_11_label);
        if (v1973_11_tail.empty()) continue;
        const Path v1973_11_head{v1973_11_label};
        const Space v1974_2 = singleton(v1973_11_head);
        const Space v1974_3 = intersect(constant_8,v1974_2);
        const Space v1974_4 = (has_head(v1974_3) ? constant_9 : Space{});
        const Space v1974_5 = subtract(constant_0,v1974_4);
        Space v1974_7;
        if (!v1974_5.empty()) {
          const Space v1975_6 = routine_265(c, v1973_11_head, v1973_11_tail);
          v1974_7 = compose(v1974_5,v1975_6);
        }
        const Space v1974_8 = intersect(constant_8,v1974_2);
        const Space v1974_9 = (has_head(v1974_8) ? constant_9 : Space{});
        Space v1974_11;
        if (!v1974_9.empty()) {
          const Space v1976_10 = routine_266(c, v1973_11_head, v1973_11_tail);
          v1974_11 = compose(v1974_9,v1976_10);
        }
        const Space v1974_12 = unite(v1974_7,v1974_11);
        v1973_11_result = unite(v1973_11_result,v1974_12);
      }
      const Space v1973_11 = std::move(v1973_11_result);
      const Space v1973_12 = raffine(constant_25,v1973_11);
      const Space v1973_13 = unite(v1973_12,v1967_13_tail);
      v1968_14 = compose(v1968_10,v1973_13);
    }
    const Path v1977_6 = concat_path(p0,v1967_13_head);
    const Path v1968_15 = concat_path(p1,v1977_6);
    const Space v1968_16 = wrap(v1968_14,v1968_15);
    const Space v1968_17 = unite(v1968_8,v1968_16);
    v1967_13_result = unite(v1967_13_result,v1968_17);
  }
  const Space v1967_13 = std::move(v1967_13_result);
  return v1967_13;
}

static Space routine_230(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1978_13_result;
  for (int v1978_13_label = 1; v1978_13_label <= 2; ++v1978_13_label) {
    const Space v1978_13_tail = child(s0,v1978_13_label);
    if (v1978_13_tail.empty()) continue;
    const Path v1978_13_head{v1978_13_label};
    const Space v1979_2 = singleton(v1978_13_head);
    const Space v1979_3 = intersect(constant_8,v1979_2);
    const Space v1979_4 = (has_head(v1979_3) ? constant_9 : Space{});
    const Space v1979_5 = subtract(constant_0,v1979_4);
    Space v1979_7;
    if (!v1979_5.empty()) {
      Space v1980_6_result;
      for (int v1980_6_label = 1; v1980_6_label <= 2; ++v1980_6_label) {
        const Space v1980_6_tail = child(v1978_13_tail,v1980_6_label);
        if (v1980_6_tail.empty()) continue;
        const Path v1980_6_head{v1980_6_label};
        const Space v1981_2 = singleton(v1980_6_head);
        const Space v1981_3 = intersect(constant_8,v1981_2);
        const Space v1981_4 = (has_head(v1981_3) ? constant_9 : Space{});
        const Space v1981_5 = subtract(constant_0,v1981_4);
        Space v1981_8;
        if (!v1981_5.empty()) {
          const Path v1982_6 = concat_path(v1978_13_head,v1980_6_head);
          const Space v1982_7 = routine_292(c, v1982_6, v1980_6_tail);
          v1981_8 = compose(v1981_5,v1982_7);
        }
        const Space v1981_9 = intersect(constant_8,v1981_2);
        const Space v1981_10 = (has_head(v1981_9) ? constant_9 : Space{});
        Space v1981_12;
        if (!v1981_10.empty()) {
          const Path v1983_6 = concat_path(v1978_13_head,v1980_6_head);
          const Space v1983_11 = routine_293(c, v1983_6, v1980_6_tail);
          v1981_12 = compose(v1981_10,v1983_11);
        }
        const Space v1981_13 = unite(v1981_8,v1981_12);
        v1980_6_result = unite(v1980_6_result,v1981_13);
      }
      const Space v1980_6 = std::move(v1980_6_result);
      v1979_7 = compose(v1979_5,v1980_6);
    }
    const Space v1979_8 = intersect(constant_8,v1979_2);
    const Space v1979_9 = (has_head(v1979_8) ? constant_9 : Space{});
    Space v1979_11;
    if (!v1979_9.empty()) {
      Space v1984_10_result;
      for (int v1984_10_label = 1; v1984_10_label <= 2; ++v1984_10_label) {
        const Space v1984_10_tail = child(v1978_13_tail,v1984_10_label);
        if (v1984_10_tail.empty()) continue;
        const Path v1984_10_head{v1984_10_label};
        const Space v1985_2 = singleton(v1984_10_head);
        const Space v1985_3 = intersect(constant_8,v1985_2);
        const Space v1985_4 = (has_head(v1985_3) ? constant_9 : Space{});
        const Space v1985_5 = subtract(constant_0,v1985_4);
        Space v1985_8;
        if (!v1985_5.empty()) {
          const Path v1986_6 = concat_path(v1978_13_head,v1984_10_head);
          const Space v1986_7 = routine_292(c, v1986_6, v1984_10_tail);
          v1985_8 = compose(v1985_5,v1986_7);
        }
        const Space v1985_9 = intersect(constant_8,v1985_2);
        const Space v1985_10 = (has_head(v1985_9) ? constant_9 : Space{});
        Space v1985_12;
        if (!v1985_10.empty()) {
          const Path v1987_6 = concat_path(v1978_13_head,v1984_10_head);
          const Space v1987_11 = routine_294(c, v1987_6, v1984_10_tail);
          v1985_12 = compose(v1985_10,v1987_11);
        }
        const Space v1985_13 = unite(v1985_8,v1985_12);
        v1984_10_result = unite(v1984_10_result,v1985_13);
      }
      const Space v1984_10 = std::move(v1984_10_result);
      v1979_11 = compose(v1979_9,v1984_10);
    }
    const Space v1979_12 = unite(v1979_7,v1979_11);
    v1978_13_result = unite(v1978_13_result,v1979_12);
  }
  const Space v1978_13 = std::move(v1978_13_result);
  const Space v1978_14 = raffine(constant_25,v1978_13);
  const Space v1978_15 = unite(v1978_14,s0);
  const Path v1978_16 = concat_path(p1,p0);
  const Space v1978_17 = wrap(v1978_15,v1978_16);
  return v1978_17;
}

static Space routine_231(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1988_7_result;
  for (int v1988_7_label = 1; v1988_7_label <= 2; ++v1988_7_label) {
    const Space v1988_7_tail = child(s0,v1988_7_label);
    if (v1988_7_tail.empty()) continue;
    const Path v1988_7_head{v1988_7_label};
    const Space v1989_2 = singleton(v1988_7_head);
    const Space v1989_3 = intersect(constant_8,v1989_2);
    const Space v1989_4 = (has_head(v1989_3) ? constant_9 : Space{});
    const Space v1989_5 = subtract(constant_0,v1989_4);
    Space v1989_6_result;
    for (int v1989_6_label = 1; v1989_6_label <= 2; ++v1989_6_label) {
      const Space v1989_6_tail = child(v1988_7_tail,v1989_6_label);
      if (v1989_6_tail.empty()) continue;
      const Path v1989_6_head{v1989_6_label};
      const Space v1990_2 = Space{};
      v1989_6_result = unite(v1989_6_result,v1990_2);
    }
    const Space v1989_6 = std::move(v1989_6_result);
    const Space v1989_7 = compose(v1989_5,v1989_6);
    const Space v1989_8 = intersect(constant_8,v1989_2);
    const Space v1989_9 = (has_head(v1989_8) ? constant_9 : Space{});
    Space v1989_12;
    if (!v1989_9.empty()) {
      const Path v1991_10 = concat_path(p0,v1988_7_head);
      Space v1991_11_result;
      for (int v1991_11_label = 1; v1991_11_label <= 2; ++v1991_11_label) {
        const Space v1991_11_tail = child(v1988_7_tail,v1991_11_label);
        if (v1991_11_tail.empty()) continue;
        const Path v1991_11_head{v1991_11_label};
        const Space v1992_2 = singleton(v1991_11_head);
        const Space v1992_3 = intersect(constant_8,v1992_2);
        const Space v1992_4 = (has_head(v1992_3) ? constant_9 : Space{});
        Space v1992_7;
        if (!v1992_4.empty()) {
          const Path v1993_5 = concat_path(v1991_10,v1991_11_head);
          const Space v1993_6 = routine_141(c, v1993_5, v1991_11_tail, s1);
          v1992_7 = compose(v1992_4,v1993_6);
        }
        v1991_11_result = unite(v1991_11_result,v1992_7);
      }
      const Space v1991_11 = std::move(v1991_11_result);
      v1989_12 = compose(v1989_9,v1991_11);
    }
    const Space v1989_13 = unite(v1989_7,v1989_12);
    v1988_7_result = unite(v1988_7_result,v1989_13);
  }
  const Space v1988_7 = std::move(v1988_7_result);
  return v1988_7;
}

static Space routine_232(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1994_6_result;
  for (int v1994_6_label = 1; v1994_6_label <= 2; ++v1994_6_label) {
    const Space v1994_6_tail = child(s0,v1994_6_label);
    if (v1994_6_tail.empty()) continue;
    const Path v1994_6_head{v1994_6_label};
    const Space v1995_2 = singleton(v1994_6_head);
    const Space v1995_3 = intersect(constant_8,v1995_2);
    const Space v1995_4 = (has_head(v1995_3) ? constant_9 : Space{});
    const Space v1995_5 = subtract(constant_0,v1995_4);
    Space v1995_6_result;
    for (int v1995_6_label = 1; v1995_6_label <= 2; ++v1995_6_label) {
      const Space v1995_6_tail = child(v1994_6_tail,v1995_6_label);
      if (v1995_6_tail.empty()) continue;
      const Path v1995_6_head{v1995_6_label};
      const Space v1996_2 = Space{};
      v1995_6_result = unite(v1995_6_result,v1996_2);
    }
    const Space v1995_6 = std::move(v1995_6_result);
    const Space v1995_7 = compose(v1995_5,v1995_6);
    const Space v1995_8 = intersect(constant_8,v1995_2);
    const Space v1995_9 = (has_head(v1995_8) ? constant_9 : Space{});
    Space v1995_12;
    if (!v1995_9.empty()) {
      const Path v1997_10 = concat_path(p0,v1994_6_head);
      const Space v1997_11 = routine_186(c, v1997_10, s1);
      v1995_12 = compose(v1995_9,v1997_11);
    }
    const Space v1995_13 = unite(v1995_7,v1995_12);
    v1994_6_result = unite(v1994_6_result,v1995_13);
  }
  const Space v1994_6 = std::move(v1994_6_result);
  return v1994_6;
}

static Space routine_233(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1998_7_result;
  for (int v1998_7_label = 1; v1998_7_label <= 2; ++v1998_7_label) {
    const Space v1998_7_tail = child(s0,v1998_7_label);
    if (v1998_7_tail.empty()) continue;
    const Path v1998_7_head{v1998_7_label};
    const Space v1999_2 = singleton(v1998_7_head);
    const Space v1999_3 = intersect(constant_8,v1999_2);
    const Space v1999_4 = (has_head(v1999_3) ? constant_9 : Space{});
    const Space v1999_5 = subtract(constant_0,v1999_4);
    Space v1999_6_result;
    for (int v1999_6_label = 1; v1999_6_label <= 2; ++v1999_6_label) {
      const Space v1999_6_tail = child(v1998_7_tail,v1999_6_label);
      if (v1999_6_tail.empty()) continue;
      const Path v1999_6_head{v1999_6_label};
      const Space v2000_2 = Space{};
      v1999_6_result = unite(v1999_6_result,v2000_2);
    }
    const Space v1999_6 = std::move(v1999_6_result);
    const Space v1999_7 = compose(v1999_5,v1999_6);
    const Space v1999_8 = intersect(constant_8,v1999_2);
    const Space v1999_9 = (has_head(v1999_8) ? constant_9 : Space{});
    Space v1999_12;
    if (!v1999_9.empty()) {
      const Path v2001_10 = concat_path(p0,v1998_7_head);
      Space v2001_11_result;
      for (int v2001_11_label = 1; v2001_11_label <= 2; ++v2001_11_label) {
        const Space v2001_11_tail = child(v1998_7_tail,v2001_11_label);
        if (v2001_11_tail.empty()) continue;
        const Path v2001_11_head{v2001_11_label};
        const Space v2002_2 = singleton(v2001_11_head);
        const Space v2002_3 = intersect(constant_8,v2002_2);
        const Space v2002_4 = (has_head(v2002_3) ? constant_9 : Space{});
        Space v2002_7;
        if (!v2002_4.empty()) {
          const Path v2003_5 = concat_path(v2001_10,v2001_11_head);
          const Space v2003_6 = routine_148(c, v2003_5, p1, v2001_11_tail);
          v2002_7 = compose(v2002_4,v2003_6);
        }
        v2001_11_result = unite(v2001_11_result,v2002_7);
      }
      const Space v2001_11 = std::move(v2001_11_result);
      v1999_12 = compose(v1999_9,v2001_11);
    }
    const Space v1999_13 = unite(v1999_7,v1999_12);
    v1998_7_result = unite(v1998_7_result,v1999_13);
  }
  const Space v1998_7 = std::move(v1998_7_result);
  return v1998_7;
}

static Space routine_234(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2004_9_result;
  for (int v2004_9_label = 1; v2004_9_label <= 2; ++v2004_9_label) {
    const Space v2004_9_tail = child(s0,v2004_9_label);
    if (v2004_9_tail.empty()) continue;
    const Path v2004_9_head{v2004_9_label};
    const Space v2005_2 = singleton(v2004_9_head);
    const Space v2005_3 = intersect(constant_8,v2005_2);
    const Space v2005_4 = (has_head(v2005_3) ? constant_9 : Space{});
    const Space v2005_5 = subtract(constant_0,v2005_4);
    Space v2005_6_result;
    for (int v2005_6_label = 1; v2005_6_label <= 2; ++v2005_6_label) {
      const Space v2005_6_tail = child(v2004_9_tail,v2005_6_label);
      if (v2005_6_tail.empty()) continue;
      const Path v2005_6_head{v2005_6_label};
      const Space v2006_2 = Space{};
      v2005_6_result = unite(v2005_6_result,v2006_2);
    }
    const Space v2005_6 = std::move(v2005_6_result);
    const Space v2005_7 = compose(v2005_5,v2005_6);
    const Space v2005_8 = intersect(constant_8,v2005_2);
    const Space v2005_9 = (has_head(v2005_8) ? constant_9 : Space{});
    Space v2005_12;
    if (!v2005_9.empty()) {
      const Path v2007_10 = concat_path(p0,v2004_9_head);
      Space v2007_11_result;
      for (int v2007_11_label = 1; v2007_11_label <= 2; ++v2007_11_label) {
        const Space v2007_11_tail = child(v2004_9_tail,v2007_11_label);
        if (v2007_11_tail.empty()) continue;
        const Path v2007_11_head{v2007_11_label};
        const Space v2008_2 = singleton(v2007_11_head);
        const Space v2008_3 = intersect(constant_8,v2008_2);
        const Space v2008_4 = (has_head(v2008_3) ? constant_9 : Space{});
        const Space v2008_5 = subtract(constant_0,v2008_4);
        Space v2008_7;
        if (!v2008_5.empty()) {
          const Space v2009_6 = routine_193(c, v2007_11_head, p1, v2007_10, v2007_11_tail);
          v2008_7 = compose(v2008_5,v2009_6);
        }
        const Space v2008_8 = intersect(constant_8,v2008_2);
        const Space v2008_9 = (has_head(v2008_8) ? constant_9 : Space{});
        Space v2008_11;
        if (!v2008_9.empty()) {
          const Space v2010_10 = routine_194(c, v2007_11_head, p1, v2007_10, v2007_11_tail);
          v2008_11 = compose(v2008_9,v2010_10);
        }
        const Space v2008_12 = unite(v2008_7,v2008_11);
        v2007_11_result = unite(v2007_11_result,v2008_12);
      }
      const Space v2007_11 = std::move(v2007_11_result);
      v2005_12 = compose(v2005_9,v2007_11);
    }
    const Space v2005_13 = unite(v2005_7,v2005_12);
    v2004_9_result = unite(v2004_9_result,v2005_13);
  }
  const Space v2004_9 = std::move(v2004_9_result);
  return v2004_9;
}

static Space routine_235(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2011_13_result;
  for (int v2011_13_label = 1; v2011_13_label <= 2; ++v2011_13_label) {
    const Space v2011_13_tail = child(s0,v2011_13_label);
    if (v2011_13_tail.empty()) continue;
    const Path v2011_13_head{v2011_13_label};
    const Space v2012_2 = singleton(v2011_13_head);
    const Space v2012_3 = intersect(constant_8,v2012_2);
    const Space v2012_4 = (has_head(v2012_3) ? constant_9 : Space{});
    const Space v2012_5 = subtract(constant_0,v2012_4);
    Space v2012_8;
    if (!v2012_5.empty()) {
      const Path v2013_6 = concat_path(p0,v2011_13_head);
      Space v2013_7_result;
      for (int v2013_7_label = 1; v2013_7_label <= 2; ++v2013_7_label) {
        const Space v2013_7_tail = child(v2011_13_tail,v2013_7_label);
        if (v2013_7_tail.empty()) continue;
        const Path v2013_7_head{v2013_7_label};
        const Space v2014_2 = singleton(v2013_7_head);
        const Space v2014_3 = intersect(constant_8,v2014_2);
        const Space v2014_4 = (has_head(v2014_3) ? constant_9 : Space{});
        const Space v2014_5 = subtract(constant_0,v2014_4);
        Space v2014_8;
        if (!v2014_5.empty()) {
          const Path v2015_6 = concat_path(v2013_6,v2013_7_head);
          const Space v2015_7 = routine_295(c, v2015_6, p1, p2, v2013_7_tail);
          v2014_8 = compose(v2014_5,v2015_7);
        }
        const Space v2014_9 = intersect(constant_8,v2014_2);
        const Space v2014_10 = (has_head(v2014_9) ? constant_9 : Space{});
        Space v2014_12;
        if (!v2014_10.empty()) {
          const Path v2016_6 = concat_path(v2013_6,v2013_7_head);
          const Space v2016_11 = routine_296(c, v2016_6, p1, p2, v2013_7_tail);
          v2014_12 = compose(v2014_10,v2016_11);
        }
        const Space v2014_13 = unite(v2014_8,v2014_12);
        v2013_7_result = unite(v2013_7_result,v2014_13);
      }
      const Space v2013_7 = std::move(v2013_7_result);
      v2012_8 = compose(v2012_5,v2013_7);
    }
    const Space v2012_9 = intersect(constant_8,v2012_2);
    const Space v2012_10 = (has_head(v2012_9) ? constant_9 : Space{});
    Space v2012_12;
    if (!v2012_10.empty()) {
      const Path v2017_6 = concat_path(p0,v2011_13_head);
      Space v2017_11_result;
      for (int v2017_11_label = 1; v2017_11_label <= 2; ++v2017_11_label) {
        const Space v2017_11_tail = child(v2011_13_tail,v2017_11_label);
        if (v2017_11_tail.empty()) continue;
        const Path v2017_11_head{v2017_11_label};
        const Space v2018_2 = singleton(v2017_11_head);
        const Space v2018_3 = intersect(constant_8,v2018_2);
        const Space v2018_4 = (has_head(v2018_3) ? constant_9 : Space{});
        const Space v2018_5 = subtract(constant_0,v2018_4);
        Space v2018_8;
        if (!v2018_5.empty()) {
          const Path v2019_6 = concat_path(v2017_6,v2017_11_head);
          const Space v2019_7 = routine_295(c, v2019_6, p1, p2, v2017_11_tail);
          v2018_8 = compose(v2018_5,v2019_7);
        }
        const Space v2018_9 = intersect(constant_8,v2018_2);
        const Space v2018_10 = (has_head(v2018_9) ? constant_9 : Space{});
        Space v2018_12;
        if (!v2018_10.empty()) {
          const Path v2020_6 = concat_path(v2017_6,v2017_11_head);
          const Space v2020_11 = routine_237(c, v2020_6, p1, p2, v2017_11_tail);
          v2018_12 = compose(v2018_10,v2020_11);
        }
        const Space v2018_13 = unite(v2018_8,v2018_12);
        v2017_11_result = unite(v2017_11_result,v2018_13);
      }
      const Space v2017_11 = std::move(v2017_11_result);
      v2012_12 = compose(v2012_10,v2017_11);
    }
    const Space v2012_13 = unite(v2012_8,v2012_12);
    v2011_13_result = unite(v2011_13_result,v2012_13);
  }
  const Space v2011_13 = std::move(v2011_13_result);
  return v2011_13;
}

static Space routine_236(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2021_9 = concat_path(constant_23,p2);
  const Space v2021_10 = singleton(v2021_9);
  const Space v2021_11 = unite(constant_26,v2021_10);
  const Path v2021_13 = concat_path(constant_22,p1);
  const Space v2021_14 = singleton(v2021_13);
  const Space v2021_15 = unite(v2021_11,v2021_14);
  Space v2021_20_result;
  for (int v2021_20_label = 1; v2021_20_label <= 2; ++v2021_20_label) {
    const Space v2021_20_tail = child(s0,v2021_20_label);
    if (v2021_20_tail.empty()) continue;
    const Path v2021_20_head{v2021_20_label};
    const Space v2022_2 = singleton(v2021_20_head);
    const Space v2022_3 = intersect(constant_8,v2022_2);
    const Space v2022_4 = (has_head(v2022_3) ? constant_9 : Space{});
    const Space v2022_5 = subtract(constant_0,v2022_4);
    Space v2022_8;
    if (!v2022_5.empty()) {
      const Path v2023_6 = concat_path(p0,v2021_20_head);
      Space v2023_7_result;
      for (int v2023_7_label = 1; v2023_7_label <= 2; ++v2023_7_label) {
        const Space v2023_7_tail = child(v2021_20_tail,v2023_7_label);
        if (v2023_7_tail.empty()) continue;
        const Path v2023_7_head{v2023_7_label};
        const Space v2024_2 = singleton(v2023_7_head);
        const Space v2024_3 = intersect(constant_8,v2024_2);
        const Space v2024_4 = (has_head(v2024_3) ? constant_9 : Space{});
        const Space v2024_5 = subtract(constant_0,v2024_4);
        Space v2024_8;
        if (!v2024_5.empty()) {
          const Path v2025_6 = concat_path(v2023_6,v2023_7_head);
          const Space v2025_7 = routine_295(c, v2025_6, p1, p2, v2023_7_tail);
          v2024_8 = compose(v2024_5,v2025_7);
        }
        const Space v2024_9 = intersect(constant_8,v2024_2);
        const Space v2024_10 = (has_head(v2024_9) ? constant_9 : Space{});
        Space v2024_12;
        if (!v2024_10.empty()) {
          const Path v2026_6 = concat_path(v2023_6,v2023_7_head);
          const Space v2026_11 = routine_296(c, v2026_6, p1, p2, v2023_7_tail);
          v2024_12 = compose(v2024_10,v2026_11);
        }
        const Space v2024_13 = unite(v2024_8,v2024_12);
        v2023_7_result = unite(v2023_7_result,v2024_13);
      }
      const Space v2023_7 = std::move(v2023_7_result);
      v2022_8 = compose(v2022_5,v2023_7);
    }
    const Space v2022_9 = intersect(constant_8,v2022_2);
    const Space v2022_10 = (has_head(v2022_9) ? constant_9 : Space{});
    const Path v2027_6 = concat_path(p0,v2021_20_head);
    const Path v2022_11 = concat_path(constant_6,v2027_6);
    const Space v2022_12 = singleton(v2022_11);
    const Space v2022_13 = unite(v2021_15,v2022_12);
    const Space v2022_14 = compose(v2022_10,v2022_13);
    const Space v2022_15 = unite(v2022_8,v2022_14);
    v2021_20_result = unite(v2021_20_result,v2022_15);
  }
  const Space v2021_20 = std::move(v2021_20_result);
  return v2021_20;
}

static Space routine_237(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2028_6 = concat_path(constant_23,p2);
  const Space v2028_7 = singleton(v2028_6);
  const Space v2028_8 = unite(constant_26,v2028_7);
  const Path v2028_10 = concat_path(constant_22,p1);
  const Space v2028_11 = singleton(v2028_10);
  const Space v2028_12 = unite(v2028_8,v2028_11);
  const Path v2028_14 = concat_path(constant_6,p0);
  const Space v2028_15 = singleton(v2028_14);
  const Space v2028_16 = unite(v2028_12,v2028_15);
  return v2028_16;
}

static Space routine_238(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2029_7_result;
  for (int v2029_7_label = 1; v2029_7_label <= 2; ++v2029_7_label) {
    const Space v2029_7_tail = child(s0,v2029_7_label);
    if (v2029_7_tail.empty()) continue;
    const Path v2029_7_head{v2029_7_label};
    const Space v2030_2 = singleton(v2029_7_head);
    const Space v2030_3 = intersect(constant_8,v2030_2);
    const Space v2030_4 = (has_head(v2030_3) ? constant_9 : Space{});
    const Space v2030_5 = subtract(constant_0,v2030_4);
    Space v2030_6_result;
    for (int v2030_6_label = 1; v2030_6_label <= 2; ++v2030_6_label) {
      const Space v2030_6_tail = child(v2029_7_tail,v2030_6_label);
      if (v2030_6_tail.empty()) continue;
      const Path v2030_6_head{v2030_6_label};
      const Space v2031_2 = Space{};
      v2030_6_result = unite(v2030_6_result,v2031_2);
    }
    const Space v2030_6 = std::move(v2030_6_result);
    const Space v2030_7 = compose(v2030_5,v2030_6);
    const Space v2030_8 = intersect(constant_8,v2030_2);
    const Space v2030_9 = (has_head(v2030_8) ? constant_9 : Space{});
    Space v2030_12;
    if (!v2030_9.empty()) {
      const Path v2032_10 = concat_path(p0,v2029_7_head);
      Space v2032_11_result;
      for (int v2032_11_label = 1; v2032_11_label <= 2; ++v2032_11_label) {
        const Space v2032_11_tail = child(v2029_7_tail,v2032_11_label);
        if (v2032_11_tail.empty()) continue;
        const Path v2032_11_head{v2032_11_label};
        const Space v2033_2 = singleton(v2032_11_head);
        const Space v2033_3 = intersect(constant_8,v2033_2);
        const Space v2033_4 = (has_head(v2033_3) ? constant_9 : Space{});
        Space v2033_7;
        if (!v2033_4.empty()) {
          const Path v2034_5 = concat_path(v2032_10,v2032_11_head);
          const Space v2034_6 = routine_155(c, v2034_5, p1, v2032_11_tail);
          v2033_7 = compose(v2033_4,v2034_6);
        }
        v2032_11_result = unite(v2032_11_result,v2033_7);
      }
      const Space v2032_11 = std::move(v2032_11_result);
      v2030_12 = compose(v2030_9,v2032_11);
    }
    const Space v2030_13 = unite(v2030_7,v2030_12);
    v2029_7_result = unite(v2029_7_result,v2030_13);
  }
  const Space v2029_7 = std::move(v2029_7_result);
  return v2029_7;
}

static Space routine_239(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2035_9_result;
  for (int v2035_9_label = 1; v2035_9_label <= 2; ++v2035_9_label) {
    const Space v2035_9_tail = child(s0,v2035_9_label);
    if (v2035_9_tail.empty()) continue;
    const Path v2035_9_head{v2035_9_label};
    const Space v2036_2 = singleton(v2035_9_head);
    const Space v2036_3 = intersect(constant_8,v2036_2);
    const Space v2036_4 = (has_head(v2036_3) ? constant_9 : Space{});
    const Space v2036_5 = subtract(constant_0,v2036_4);
    Space v2036_6_result;
    for (int v2036_6_label = 1; v2036_6_label <= 2; ++v2036_6_label) {
      const Space v2036_6_tail = child(v2035_9_tail,v2036_6_label);
      if (v2036_6_tail.empty()) continue;
      const Path v2036_6_head{v2036_6_label};
      const Space v2037_2 = Space{};
      v2036_6_result = unite(v2036_6_result,v2037_2);
    }
    const Space v2036_6 = std::move(v2036_6_result);
    const Space v2036_7 = compose(v2036_5,v2036_6);
    const Space v2036_8 = intersect(constant_8,v2036_2);
    const Space v2036_9 = (has_head(v2036_8) ? constant_9 : Space{});
    Space v2036_12;
    if (!v2036_9.empty()) {
      const Path v2038_10 = concat_path(p0,v2035_9_head);
      Space v2038_11_result;
      for (int v2038_11_label = 1; v2038_11_label <= 2; ++v2038_11_label) {
        const Space v2038_11_tail = child(v2035_9_tail,v2038_11_label);
        if (v2038_11_tail.empty()) continue;
        const Path v2038_11_head{v2038_11_label};
        const Space v2039_2 = singleton(v2038_11_head);
        const Space v2039_3 = intersect(constant_8,v2039_2);
        const Space v2039_4 = (has_head(v2039_3) ? constant_9 : Space{});
        const Space v2039_5 = subtract(constant_0,v2039_4);
        Space v2039_7;
        if (!v2039_5.empty()) {
          const Space v2040_6 = routine_201(c, v2038_11_head, p1, v2038_10, v2038_11_tail);
          v2039_7 = compose(v2039_5,v2040_6);
        }
        const Space v2039_8 = intersect(constant_8,v2039_2);
        const Space v2039_9 = (has_head(v2039_8) ? constant_9 : Space{});
        Space v2039_11;
        if (!v2039_9.empty()) {
          const Space v2041_10 = routine_202(c, v2038_11_head, p1, v2038_10, v2038_11_tail);
          v2039_11 = compose(v2039_9,v2041_10);
        }
        const Space v2039_12 = unite(v2039_7,v2039_11);
        v2038_11_result = unite(v2038_11_result,v2039_12);
      }
      const Space v2038_11 = std::move(v2038_11_result);
      v2036_12 = compose(v2036_9,v2038_11);
    }
    const Space v2036_13 = unite(v2036_7,v2036_12);
    v2035_9_result = unite(v2035_9_result,v2036_13);
  }
  const Space v2035_9 = std::move(v2035_9_result);
  return v2035_9;
}

static Space routine_240(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2042_13_result;
  for (int v2042_13_label = 1; v2042_13_label <= 2; ++v2042_13_label) {
    const Space v2042_13_tail = child(s0,v2042_13_label);
    if (v2042_13_tail.empty()) continue;
    const Path v2042_13_head{v2042_13_label};
    const Space v2043_2 = singleton(v2042_13_head);
    const Space v2043_3 = intersect(constant_8,v2043_2);
    const Space v2043_4 = (has_head(v2043_3) ? constant_9 : Space{});
    const Space v2043_5 = subtract(constant_0,v2043_4);
    Space v2043_8;
    if (!v2043_5.empty()) {
      const Path v2044_6 = concat_path(p0,v2042_13_head);
      Space v2044_7_result;
      for (int v2044_7_label = 1; v2044_7_label <= 2; ++v2044_7_label) {
        const Space v2044_7_tail = child(v2042_13_tail,v2044_7_label);
        if (v2044_7_tail.empty()) continue;
        const Path v2044_7_head{v2044_7_label};
        const Space v2045_2 = singleton(v2044_7_head);
        const Space v2045_3 = intersect(constant_8,v2045_2);
        const Space v2045_4 = (has_head(v2045_3) ? constant_9 : Space{});
        const Space v2045_5 = subtract(constant_0,v2045_4);
        Space v2045_8;
        if (!v2045_5.empty()) {
          const Path v2046_6 = concat_path(v2044_6,v2044_7_head);
          const Space v2046_7 = routine_297(c, v2046_6, p1, p2, v2044_7_tail);
          v2045_8 = compose(v2045_5,v2046_7);
        }
        const Space v2045_9 = intersect(constant_8,v2045_2);
        const Space v2045_10 = (has_head(v2045_9) ? constant_9 : Space{});
        Space v2045_12;
        if (!v2045_10.empty()) {
          const Path v2047_6 = concat_path(v2044_6,v2044_7_head);
          const Space v2047_11 = routine_298(c, v2047_6, p1, p2, v2044_7_tail);
          v2045_12 = compose(v2045_10,v2047_11);
        }
        const Space v2045_13 = unite(v2045_8,v2045_12);
        v2044_7_result = unite(v2044_7_result,v2045_13);
      }
      const Space v2044_7 = std::move(v2044_7_result);
      v2043_8 = compose(v2043_5,v2044_7);
    }
    const Space v2043_9 = intersect(constant_8,v2043_2);
    const Space v2043_10 = (has_head(v2043_9) ? constant_9 : Space{});
    Space v2043_12;
    if (!v2043_10.empty()) {
      const Path v2048_6 = concat_path(p0,v2042_13_head);
      Space v2048_11_result;
      for (int v2048_11_label = 1; v2048_11_label <= 2; ++v2048_11_label) {
        const Space v2048_11_tail = child(v2042_13_tail,v2048_11_label);
        if (v2048_11_tail.empty()) continue;
        const Path v2048_11_head{v2048_11_label};
        const Space v2049_2 = singleton(v2048_11_head);
        const Space v2049_3 = intersect(constant_8,v2049_2);
        const Space v2049_4 = (has_head(v2049_3) ? constant_9 : Space{});
        const Space v2049_5 = subtract(constant_0,v2049_4);
        Space v2049_8;
        if (!v2049_5.empty()) {
          const Path v2050_6 = concat_path(v2048_6,v2048_11_head);
          const Space v2050_7 = routine_297(c, v2050_6, p1, p2, v2048_11_tail);
          v2049_8 = compose(v2049_5,v2050_7);
        }
        const Space v2049_9 = intersect(constant_8,v2049_2);
        const Space v2049_10 = (has_head(v2049_9) ? constant_9 : Space{});
        Space v2049_12;
        if (!v2049_10.empty()) {
          const Path v2051_6 = concat_path(v2048_6,v2048_11_head);
          const Space v2051_11 = routine_242(c, v2051_6, p1, p2, v2048_11_tail);
          v2049_12 = compose(v2049_10,v2051_11);
        }
        const Space v2049_13 = unite(v2049_8,v2049_12);
        v2048_11_result = unite(v2048_11_result,v2049_13);
      }
      const Space v2048_11 = std::move(v2048_11_result);
      v2043_12 = compose(v2043_10,v2048_11);
    }
    const Space v2043_13 = unite(v2043_8,v2043_12);
    v2042_13_result = unite(v2042_13_result,v2043_13);
  }
  const Space v2042_13 = std::move(v2042_13_result);
  return v2042_13;
}

static Space routine_241(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2052_10 = concat_path(constant_22,p1);
  const Space v2052_11 = singleton(v2052_10);
  const Path v2052_13 = concat_path(constant_6,p2);
  const Space v2052_14 = singleton(v2052_13);
  Space v2052_18_result;
  for (int v2052_18_label = 1; v2052_18_label <= 2; ++v2052_18_label) {
    const Space v2052_18_tail = child(s0,v2052_18_label);
    if (v2052_18_tail.empty()) continue;
    const Path v2052_18_head{v2052_18_label};
    const Space v2053_2 = singleton(v2052_18_head);
    const Space v2053_3 = intersect(constant_8,v2053_2);
    const Space v2053_4 = (has_head(v2053_3) ? constant_9 : Space{});
    const Space v2053_5 = subtract(constant_0,v2053_4);
    Space v2053_8;
    if (!v2053_5.empty()) {
      const Path v2054_6 = concat_path(p0,v2052_18_head);
      Space v2054_7_result;
      for (int v2054_7_label = 1; v2054_7_label <= 2; ++v2054_7_label) {
        const Space v2054_7_tail = child(v2052_18_tail,v2054_7_label);
        if (v2054_7_tail.empty()) continue;
        const Path v2054_7_head{v2054_7_label};
        const Space v2055_2 = singleton(v2054_7_head);
        const Space v2055_3 = intersect(constant_8,v2055_2);
        const Space v2055_4 = (has_head(v2055_3) ? constant_9 : Space{});
        const Space v2055_5 = subtract(constant_0,v2055_4);
        Space v2055_8;
        if (!v2055_5.empty()) {
          const Path v2056_6 = concat_path(v2054_6,v2054_7_head);
          const Space v2056_7 = routine_297(c, v2056_6, p1, p2, v2054_7_tail);
          v2055_8 = compose(v2055_5,v2056_7);
        }
        const Space v2055_9 = intersect(constant_8,v2055_2);
        const Space v2055_10 = (has_head(v2055_9) ? constant_9 : Space{});
        Space v2055_12;
        if (!v2055_10.empty()) {
          const Path v2057_6 = concat_path(v2054_6,v2054_7_head);
          const Space v2057_11 = routine_298(c, v2057_6, p1, p2, v2054_7_tail);
          v2055_12 = compose(v2055_10,v2057_11);
        }
        const Space v2055_13 = unite(v2055_8,v2055_12);
        v2054_7_result = unite(v2054_7_result,v2055_13);
      }
      const Space v2054_7 = std::move(v2054_7_result);
      v2053_8 = compose(v2053_5,v2054_7);
    }
    const Space v2053_9 = intersect(constant_8,v2053_2);
    const Space v2053_10 = (has_head(v2053_9) ? constant_9 : Space{});
    const Path v2058_6 = concat_path(p0,v2052_18_head);
    const Path v2053_11 = concat_path(constant_24,v2058_6);
    const Space v2053_12 = singleton(v2053_11);
    const Space v2053_13 = unite(constant_27,v2053_12);
    const Space v2053_14 = unite(v2053_13,v2052_11);
    const Space v2053_15 = unite(v2053_14,v2052_14);
    const Space v2053_16 = compose(v2053_10,v2053_15);
    const Space v2053_17 = unite(v2053_8,v2053_16);
    v2052_18_result = unite(v2052_18_result,v2053_17);
  }
  const Space v2052_18 = std::move(v2052_18_result);
  return v2052_18;
}

static Space routine_242(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2059_6 = concat_path(constant_24,p0);
  const Space v2059_7 = singleton(v2059_6);
  const Space v2059_8 = unite(constant_27,v2059_7);
  const Path v2059_10 = concat_path(constant_22,p1);
  const Space v2059_11 = singleton(v2059_10);
  const Space v2059_12 = unite(v2059_8,v2059_11);
  const Path v2059_14 = concat_path(constant_6,p2);
  const Space v2059_15 = singleton(v2059_14);
  const Space v2059_16 = unite(v2059_12,v2059_15);
  return v2059_16;
}

static Space routine_243(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2060_7_result;
  for (int v2060_7_label = 1; v2060_7_label <= 2; ++v2060_7_label) {
    const Space v2060_7_tail = child(s0,v2060_7_label);
    if (v2060_7_tail.empty()) continue;
    const Path v2060_7_head{v2060_7_label};
    const Space v2061_2 = singleton(v2060_7_head);
    const Space v2061_3 = intersect(constant_8,v2061_2);
    const Space v2061_4 = (has_head(v2061_3) ? constant_9 : Space{});
    const Space v2061_5 = subtract(constant_0,v2061_4);
    Space v2061_6_result;
    for (int v2061_6_label = 1; v2061_6_label <= 2; ++v2061_6_label) {
      const Space v2061_6_tail = child(v2060_7_tail,v2061_6_label);
      if (v2061_6_tail.empty()) continue;
      const Path v2061_6_head{v2061_6_label};
      const Space v2062_2 = Space{};
      v2061_6_result = unite(v2061_6_result,v2062_2);
    }
    const Space v2061_6 = std::move(v2061_6_result);
    const Space v2061_7 = compose(v2061_5,v2061_6);
    const Space v2061_8 = intersect(constant_8,v2061_2);
    const Space v2061_9 = (has_head(v2061_8) ? constant_9 : Space{});
    Space v2061_12;
    if (!v2061_9.empty()) {
      const Path v2063_10 = concat_path(p0,v2060_7_head);
      Space v2063_11_result;
      for (int v2063_11_label = 1; v2063_11_label <= 2; ++v2063_11_label) {
        const Space v2063_11_tail = child(v2060_7_tail,v2063_11_label);
        if (v2063_11_tail.empty()) continue;
        const Path v2063_11_head{v2063_11_label};
        const Space v2064_2 = singleton(v2063_11_head);
        const Space v2064_3 = intersect(constant_8,v2064_2);
        const Space v2064_4 = (has_head(v2064_3) ? constant_9 : Space{});
        Space v2064_7;
        if (!v2064_4.empty()) {
          const Path v2065_5 = concat_path(v2063_10,v2063_11_head);
          const Space v2065_6 = routine_162(c, v2065_5, p1, v2063_11_tail);
          v2064_7 = compose(v2064_4,v2065_6);
        }
        v2063_11_result = unite(v2063_11_result,v2064_7);
      }
      const Space v2063_11 = std::move(v2063_11_result);
      v2061_12 = compose(v2061_9,v2063_11);
    }
    const Space v2061_13 = unite(v2061_7,v2061_12);
    v2060_7_result = unite(v2060_7_result,v2061_13);
  }
  const Space v2060_7 = std::move(v2060_7_result);
  return v2060_7;
}

static Space routine_244(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2066_9_result;
  for (int v2066_9_label = 1; v2066_9_label <= 2; ++v2066_9_label) {
    const Space v2066_9_tail = child(s0,v2066_9_label);
    if (v2066_9_tail.empty()) continue;
    const Path v2066_9_head{v2066_9_label};
    const Space v2067_2 = singleton(v2066_9_head);
    const Space v2067_3 = intersect(constant_8,v2067_2);
    const Space v2067_4 = (has_head(v2067_3) ? constant_9 : Space{});
    const Space v2067_5 = subtract(constant_0,v2067_4);
    Space v2067_6_result;
    for (int v2067_6_label = 1; v2067_6_label <= 2; ++v2067_6_label) {
      const Space v2067_6_tail = child(v2066_9_tail,v2067_6_label);
      if (v2067_6_tail.empty()) continue;
      const Path v2067_6_head{v2067_6_label};
      const Space v2068_2 = Space{};
      v2067_6_result = unite(v2067_6_result,v2068_2);
    }
    const Space v2067_6 = std::move(v2067_6_result);
    const Space v2067_7 = compose(v2067_5,v2067_6);
    const Space v2067_8 = intersect(constant_8,v2067_2);
    const Space v2067_9 = (has_head(v2067_8) ? constant_9 : Space{});
    Space v2067_12;
    if (!v2067_9.empty()) {
      const Path v2069_10 = concat_path(p0,v2066_9_head);
      Space v2069_11_result;
      for (int v2069_11_label = 1; v2069_11_label <= 2; ++v2069_11_label) {
        const Space v2069_11_tail = child(v2066_9_tail,v2069_11_label);
        if (v2069_11_tail.empty()) continue;
        const Path v2069_11_head{v2069_11_label};
        const Space v2070_2 = singleton(v2069_11_head);
        const Space v2070_3 = intersect(constant_8,v2070_2);
        const Space v2070_4 = (has_head(v2070_3) ? constant_9 : Space{});
        const Space v2070_5 = subtract(constant_0,v2070_4);
        Space v2070_7;
        if (!v2070_5.empty()) {
          const Space v2071_6 = routine_209(c, v2069_11_head, p1, v2069_10, v2069_11_tail);
          v2070_7 = compose(v2070_5,v2071_6);
        }
        const Space v2070_8 = intersect(constant_8,v2070_2);
        const Space v2070_9 = (has_head(v2070_8) ? constant_9 : Space{});
        Space v2070_11;
        if (!v2070_9.empty()) {
          const Space v2072_10 = routine_210(c, v2069_11_head, p1, v2069_10, v2069_11_tail);
          v2070_11 = compose(v2070_9,v2072_10);
        }
        const Space v2070_12 = unite(v2070_7,v2070_11);
        v2069_11_result = unite(v2069_11_result,v2070_12);
      }
      const Space v2069_11 = std::move(v2069_11_result);
      v2067_12 = compose(v2067_9,v2069_11);
    }
    const Space v2067_13 = unite(v2067_7,v2067_12);
    v2066_9_result = unite(v2066_9_result,v2067_13);
  }
  const Space v2066_9 = std::move(v2066_9_result);
  return v2066_9;
}

static Space routine_245(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2073_13_result;
  for (int v2073_13_label = 1; v2073_13_label <= 2; ++v2073_13_label) {
    const Space v2073_13_tail = child(s0,v2073_13_label);
    if (v2073_13_tail.empty()) continue;
    const Path v2073_13_head{v2073_13_label};
    const Space v2074_2 = singleton(v2073_13_head);
    const Space v2074_3 = intersect(constant_8,v2074_2);
    const Space v2074_4 = (has_head(v2074_3) ? constant_9 : Space{});
    const Space v2074_5 = subtract(constant_0,v2074_4);
    Space v2074_8;
    if (!v2074_5.empty()) {
      const Path v2075_6 = concat_path(p0,v2073_13_head);
      Space v2075_7_result;
      for (int v2075_7_label = 1; v2075_7_label <= 2; ++v2075_7_label) {
        const Space v2075_7_tail = child(v2073_13_tail,v2075_7_label);
        if (v2075_7_tail.empty()) continue;
        const Path v2075_7_head{v2075_7_label};
        const Space v2076_2 = singleton(v2075_7_head);
        const Space v2076_3 = intersect(constant_8,v2076_2);
        const Space v2076_4 = (has_head(v2076_3) ? constant_9 : Space{});
        const Space v2076_5 = subtract(constant_0,v2076_4);
        Space v2076_8;
        if (!v2076_5.empty()) {
          const Path v2077_6 = concat_path(v2075_6,v2075_7_head);
          const Space v2077_7 = routine_299(c, v2077_6, p1, p2, v2075_7_tail);
          v2076_8 = compose(v2076_5,v2077_7);
        }
        const Space v2076_9 = intersect(constant_8,v2076_2);
        const Space v2076_10 = (has_head(v2076_9) ? constant_9 : Space{});
        Space v2076_12;
        if (!v2076_10.empty()) {
          const Path v2078_6 = concat_path(v2075_6,v2075_7_head);
          const Space v2078_11 = routine_300(c, v2078_6, p1, p2, v2075_7_tail);
          v2076_12 = compose(v2076_10,v2078_11);
        }
        const Space v2076_13 = unite(v2076_8,v2076_12);
        v2075_7_result = unite(v2075_7_result,v2076_13);
      }
      const Space v2075_7 = std::move(v2075_7_result);
      v2074_8 = compose(v2074_5,v2075_7);
    }
    const Space v2074_9 = intersect(constant_8,v2074_2);
    const Space v2074_10 = (has_head(v2074_9) ? constant_9 : Space{});
    Space v2074_12;
    if (!v2074_10.empty()) {
      const Path v2079_6 = concat_path(p0,v2073_13_head);
      Space v2079_11_result;
      for (int v2079_11_label = 1; v2079_11_label <= 2; ++v2079_11_label) {
        const Space v2079_11_tail = child(v2073_13_tail,v2079_11_label);
        if (v2079_11_tail.empty()) continue;
        const Path v2079_11_head{v2079_11_label};
        const Space v2080_2 = singleton(v2079_11_head);
        const Space v2080_3 = intersect(constant_8,v2080_2);
        const Space v2080_4 = (has_head(v2080_3) ? constant_9 : Space{});
        const Space v2080_5 = subtract(constant_0,v2080_4);
        Space v2080_8;
        if (!v2080_5.empty()) {
          const Path v2081_6 = concat_path(v2079_6,v2079_11_head);
          const Space v2081_7 = routine_299(c, v2081_6, p1, p2, v2079_11_tail);
          v2080_8 = compose(v2080_5,v2081_7);
        }
        const Space v2080_9 = intersect(constant_8,v2080_2);
        const Space v2080_10 = (has_head(v2080_9) ? constant_9 : Space{});
        Space v2080_12;
        if (!v2080_10.empty()) {
          const Path v2082_6 = concat_path(v2079_6,v2079_11_head);
          const Space v2082_11 = routine_247(c, v2082_6, p1, p2, v2079_11_tail);
          v2080_12 = compose(v2080_10,v2082_11);
        }
        const Space v2080_13 = unite(v2080_8,v2080_12);
        v2079_11_result = unite(v2079_11_result,v2080_13);
      }
      const Space v2079_11 = std::move(v2079_11_result);
      v2074_12 = compose(v2074_10,v2079_11);
    }
    const Space v2074_13 = unite(v2074_8,v2074_12);
    v2073_13_result = unite(v2073_13_result,v2074_13);
  }
  const Space v2073_13 = std::move(v2073_13_result);
  return v2073_13;
}

static Space routine_246(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2083_10 = concat_path(constant_23,p1);
  const Space v2083_11 = singleton(v2083_10);
  const Path v2083_13 = concat_path(constant_6,p2);
  const Space v2083_14 = singleton(v2083_13);
  Space v2083_18_result;
  for (int v2083_18_label = 1; v2083_18_label <= 2; ++v2083_18_label) {
    const Space v2083_18_tail = child(s0,v2083_18_label);
    if (v2083_18_tail.empty()) continue;
    const Path v2083_18_head{v2083_18_label};
    const Space v2084_2 = singleton(v2083_18_head);
    const Space v2084_3 = intersect(constant_8,v2084_2);
    const Space v2084_4 = (has_head(v2084_3) ? constant_9 : Space{});
    const Space v2084_5 = subtract(constant_0,v2084_4);
    Space v2084_8;
    if (!v2084_5.empty()) {
      const Path v2085_6 = concat_path(p0,v2083_18_head);
      Space v2085_7_result;
      for (int v2085_7_label = 1; v2085_7_label <= 2; ++v2085_7_label) {
        const Space v2085_7_tail = child(v2083_18_tail,v2085_7_label);
        if (v2085_7_tail.empty()) continue;
        const Path v2085_7_head{v2085_7_label};
        const Space v2086_2 = singleton(v2085_7_head);
        const Space v2086_3 = intersect(constant_8,v2086_2);
        const Space v2086_4 = (has_head(v2086_3) ? constant_9 : Space{});
        const Space v2086_5 = subtract(constant_0,v2086_4);
        Space v2086_8;
        if (!v2086_5.empty()) {
          const Path v2087_6 = concat_path(v2085_6,v2085_7_head);
          const Space v2087_7 = routine_299(c, v2087_6, p1, p2, v2085_7_tail);
          v2086_8 = compose(v2086_5,v2087_7);
        }
        const Space v2086_9 = intersect(constant_8,v2086_2);
        const Space v2086_10 = (has_head(v2086_9) ? constant_9 : Space{});
        Space v2086_12;
        if (!v2086_10.empty()) {
          const Path v2088_6 = concat_path(v2085_6,v2085_7_head);
          const Space v2088_11 = routine_300(c, v2088_6, p1, p2, v2085_7_tail);
          v2086_12 = compose(v2086_10,v2088_11);
        }
        const Space v2086_13 = unite(v2086_8,v2086_12);
        v2085_7_result = unite(v2085_7_result,v2086_13);
      }
      const Space v2085_7 = std::move(v2085_7_result);
      v2084_8 = compose(v2084_5,v2085_7);
    }
    const Space v2084_9 = intersect(constant_8,v2084_2);
    const Space v2084_10 = (has_head(v2084_9) ? constant_9 : Space{});
    const Path v2089_6 = concat_path(p0,v2083_18_head);
    const Path v2084_11 = concat_path(constant_24,v2089_6);
    const Space v2084_12 = singleton(v2084_11);
    const Space v2084_13 = unite(constant_28,v2084_12);
    const Space v2084_14 = unite(v2084_13,v2083_11);
    const Space v2084_15 = unite(v2084_14,v2083_14);
    const Space v2084_16 = compose(v2084_10,v2084_15);
    const Space v2084_17 = unite(v2084_8,v2084_16);
    v2083_18_result = unite(v2083_18_result,v2084_17);
  }
  const Space v2083_18 = std::move(v2083_18_result);
  return v2083_18;
}

static Space routine_247(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2090_6 = concat_path(constant_24,p0);
  const Space v2090_7 = singleton(v2090_6);
  const Space v2090_8 = unite(constant_28,v2090_7);
  const Path v2090_10 = concat_path(constant_23,p1);
  const Space v2090_11 = singleton(v2090_10);
  const Space v2090_12 = unite(v2090_8,v2090_11);
  const Path v2090_14 = concat_path(constant_6,p2);
  const Space v2090_15 = singleton(v2090_14);
  const Space v2090_16 = unite(v2090_12,v2090_15);
  return v2090_16;
}

static Space routine_248(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2091_7_result;
  for (int v2091_7_label = 1; v2091_7_label <= 2; ++v2091_7_label) {
    const Space v2091_7_tail = child(s0,v2091_7_label);
    if (v2091_7_tail.empty()) continue;
    const Path v2091_7_head{v2091_7_label};
    const Space v2092_2 = singleton(v2091_7_head);
    const Space v2092_3 = intersect(constant_8,v2092_2);
    const Space v2092_4 = (has_head(v2092_3) ? constant_9 : Space{});
    const Space v2092_5 = subtract(constant_0,v2092_4);
    Space v2092_6_result;
    for (int v2092_6_label = 1; v2092_6_label <= 2; ++v2092_6_label) {
      const Space v2092_6_tail = child(v2091_7_tail,v2092_6_label);
      if (v2092_6_tail.empty()) continue;
      const Path v2092_6_head{v2092_6_label};
      const Space v2093_2 = Space{};
      v2092_6_result = unite(v2092_6_result,v2093_2);
    }
    const Space v2092_6 = std::move(v2092_6_result);
    const Space v2092_7 = compose(v2092_5,v2092_6);
    const Space v2092_8 = intersect(constant_8,v2092_2);
    const Space v2092_9 = (has_head(v2092_8) ? constant_9 : Space{});
    Space v2092_12;
    if (!v2092_9.empty()) {
      const Path v2094_10 = concat_path(p0,v2091_7_head);
      Space v2094_11_result;
      for (int v2094_11_label = 1; v2094_11_label <= 2; ++v2094_11_label) {
        const Space v2094_11_tail = child(v2091_7_tail,v2094_11_label);
        if (v2094_11_tail.empty()) continue;
        const Path v2094_11_head{v2094_11_label};
        const Space v2095_2 = singleton(v2094_11_head);
        const Space v2095_3 = intersect(constant_8,v2095_2);
        const Space v2095_4 = (has_head(v2095_3) ? constant_9 : Space{});
        Space v2095_7;
        if (!v2095_4.empty()) {
          const Path v2096_5 = concat_path(v2094_10,v2094_11_head);
          const Space v2096_6 = routine_169(c, v2096_5, p1, v2094_11_tail);
          v2095_7 = compose(v2095_4,v2096_6);
        }
        v2094_11_result = unite(v2094_11_result,v2095_7);
      }
      const Space v2094_11 = std::move(v2094_11_result);
      v2092_12 = compose(v2092_9,v2094_11);
    }
    const Space v2092_13 = unite(v2092_7,v2092_12);
    v2091_7_result = unite(v2091_7_result,v2092_13);
  }
  const Space v2091_7 = std::move(v2091_7_result);
  return v2091_7;
}

static Space routine_249(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2097_9_result;
  for (int v2097_9_label = 1; v2097_9_label <= 2; ++v2097_9_label) {
    const Space v2097_9_tail = child(s0,v2097_9_label);
    if (v2097_9_tail.empty()) continue;
    const Path v2097_9_head{v2097_9_label};
    const Space v2098_2 = singleton(v2097_9_head);
    const Space v2098_3 = intersect(constant_8,v2098_2);
    const Space v2098_4 = (has_head(v2098_3) ? constant_9 : Space{});
    const Space v2098_5 = subtract(constant_0,v2098_4);
    Space v2098_6_result;
    for (int v2098_6_label = 1; v2098_6_label <= 2; ++v2098_6_label) {
      const Space v2098_6_tail = child(v2097_9_tail,v2098_6_label);
      if (v2098_6_tail.empty()) continue;
      const Path v2098_6_head{v2098_6_label};
      const Space v2099_2 = Space{};
      v2098_6_result = unite(v2098_6_result,v2099_2);
    }
    const Space v2098_6 = std::move(v2098_6_result);
    const Space v2098_7 = compose(v2098_5,v2098_6);
    const Space v2098_8 = intersect(constant_8,v2098_2);
    const Space v2098_9 = (has_head(v2098_8) ? constant_9 : Space{});
    Space v2098_12;
    if (!v2098_9.empty()) {
      const Path v2100_10 = concat_path(p0,v2097_9_head);
      Space v2100_11_result;
      for (int v2100_11_label = 1; v2100_11_label <= 2; ++v2100_11_label) {
        const Space v2100_11_tail = child(v2097_9_tail,v2100_11_label);
        if (v2100_11_tail.empty()) continue;
        const Path v2100_11_head{v2100_11_label};
        const Space v2101_2 = singleton(v2100_11_head);
        const Space v2101_3 = intersect(constant_8,v2101_2);
        const Space v2101_4 = (has_head(v2101_3) ? constant_9 : Space{});
        const Space v2101_5 = subtract(constant_0,v2101_4);
        Space v2101_7;
        if (!v2101_5.empty()) {
          const Space v2102_6 = routine_217(c, v2100_11_head, p1, v2100_10, v2100_11_tail);
          v2101_7 = compose(v2101_5,v2102_6);
        }
        const Space v2101_8 = intersect(constant_8,v2101_2);
        const Space v2101_9 = (has_head(v2101_8) ? constant_9 : Space{});
        Space v2101_11;
        if (!v2101_9.empty()) {
          const Space v2103_10 = routine_218(c, v2100_11_head, p1, v2100_10, v2100_11_tail);
          v2101_11 = compose(v2101_9,v2103_10);
        }
        const Space v2101_12 = unite(v2101_7,v2101_11);
        v2100_11_result = unite(v2100_11_result,v2101_12);
      }
      const Space v2100_11 = std::move(v2100_11_result);
      v2098_12 = compose(v2098_9,v2100_11);
    }
    const Space v2098_13 = unite(v2098_7,v2098_12);
    v2097_9_result = unite(v2097_9_result,v2098_13);
  }
  const Space v2097_9 = std::move(v2097_9_result);
  return v2097_9;
}

static Space routine_250(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2104_13_result;
  for (int v2104_13_label = 1; v2104_13_label <= 2; ++v2104_13_label) {
    const Space v2104_13_tail = child(s0,v2104_13_label);
    if (v2104_13_tail.empty()) continue;
    const Path v2104_13_head{v2104_13_label};
    const Space v2105_2 = singleton(v2104_13_head);
    const Space v2105_3 = intersect(constant_8,v2105_2);
    const Space v2105_4 = (has_head(v2105_3) ? constant_9 : Space{});
    const Space v2105_5 = subtract(constant_0,v2105_4);
    Space v2105_8;
    if (!v2105_5.empty()) {
      const Path v2106_6 = concat_path(p0,v2104_13_head);
      Space v2106_7_result;
      for (int v2106_7_label = 1; v2106_7_label <= 2; ++v2106_7_label) {
        const Space v2106_7_tail = child(v2104_13_tail,v2106_7_label);
        if (v2106_7_tail.empty()) continue;
        const Path v2106_7_head{v2106_7_label};
        const Space v2107_2 = singleton(v2106_7_head);
        const Space v2107_3 = intersect(constant_8,v2107_2);
        const Space v2107_4 = (has_head(v2107_3) ? constant_9 : Space{});
        const Space v2107_5 = subtract(constant_0,v2107_4);
        Space v2107_8;
        if (!v2107_5.empty()) {
          const Path v2108_6 = concat_path(v2106_6,v2106_7_head);
          const Space v2108_7 = routine_301(c, v2108_6, p1, p2, v2106_7_tail);
          v2107_8 = compose(v2107_5,v2108_7);
        }
        const Space v2107_9 = intersect(constant_8,v2107_2);
        const Space v2107_10 = (has_head(v2107_9) ? constant_9 : Space{});
        Space v2107_12;
        if (!v2107_10.empty()) {
          const Path v2109_6 = concat_path(v2106_6,v2106_7_head);
          const Space v2109_11 = routine_302(c, v2109_6, p1, p2, v2106_7_tail);
          v2107_12 = compose(v2107_10,v2109_11);
        }
        const Space v2107_13 = unite(v2107_8,v2107_12);
        v2106_7_result = unite(v2106_7_result,v2107_13);
      }
      const Space v2106_7 = std::move(v2106_7_result);
      v2105_8 = compose(v2105_5,v2106_7);
    }
    const Space v2105_9 = intersect(constant_8,v2105_2);
    const Space v2105_10 = (has_head(v2105_9) ? constant_9 : Space{});
    Space v2105_12;
    if (!v2105_10.empty()) {
      const Path v2110_6 = concat_path(p0,v2104_13_head);
      Space v2110_11_result;
      for (int v2110_11_label = 1; v2110_11_label <= 2; ++v2110_11_label) {
        const Space v2110_11_tail = child(v2104_13_tail,v2110_11_label);
        if (v2110_11_tail.empty()) continue;
        const Path v2110_11_head{v2110_11_label};
        const Space v2111_2 = singleton(v2110_11_head);
        const Space v2111_3 = intersect(constant_8,v2111_2);
        const Space v2111_4 = (has_head(v2111_3) ? constant_9 : Space{});
        const Space v2111_5 = subtract(constant_0,v2111_4);
        Space v2111_8;
        if (!v2111_5.empty()) {
          const Path v2112_6 = concat_path(v2110_6,v2110_11_head);
          const Space v2112_7 = routine_301(c, v2112_6, p1, p2, v2110_11_tail);
          v2111_8 = compose(v2111_5,v2112_7);
        }
        const Space v2111_9 = intersect(constant_8,v2111_2);
        const Space v2111_10 = (has_head(v2111_9) ? constant_9 : Space{});
        Space v2111_12;
        if (!v2111_10.empty()) {
          const Path v2113_6 = concat_path(v2110_6,v2110_11_head);
          const Space v2113_11 = routine_252(c, v2113_6, p1, p2, v2110_11_tail);
          v2111_12 = compose(v2111_10,v2113_11);
        }
        const Space v2111_13 = unite(v2111_8,v2111_12);
        v2110_11_result = unite(v2110_11_result,v2111_13);
      }
      const Space v2110_11 = std::move(v2110_11_result);
      v2105_12 = compose(v2105_10,v2110_11);
    }
    const Space v2105_13 = unite(v2105_8,v2105_12);
    v2104_13_result = unite(v2104_13_result,v2105_13);
  }
  const Space v2104_13 = std::move(v2104_13_result);
  return v2104_13;
}

static Space routine_251(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2114_10 = concat_path(constant_23,p2);
  const Space v2114_11 = singleton(v2114_10);
  const Path v2114_13 = concat_path(constant_22,p1);
  const Space v2114_14 = singleton(v2114_13);
  Space v2114_18_result;
  for (int v2114_18_label = 1; v2114_18_label <= 2; ++v2114_18_label) {
    const Space v2114_18_tail = child(s0,v2114_18_label);
    if (v2114_18_tail.empty()) continue;
    const Path v2114_18_head{v2114_18_label};
    const Space v2115_2 = singleton(v2114_18_head);
    const Space v2115_3 = intersect(constant_8,v2115_2);
    const Space v2115_4 = (has_head(v2115_3) ? constant_9 : Space{});
    const Space v2115_5 = subtract(constant_0,v2115_4);
    Space v2115_8;
    if (!v2115_5.empty()) {
      const Path v2116_6 = concat_path(p0,v2114_18_head);
      Space v2116_7_result;
      for (int v2116_7_label = 1; v2116_7_label <= 2; ++v2116_7_label) {
        const Space v2116_7_tail = child(v2114_18_tail,v2116_7_label);
        if (v2116_7_tail.empty()) continue;
        const Path v2116_7_head{v2116_7_label};
        const Space v2117_2 = singleton(v2116_7_head);
        const Space v2117_3 = intersect(constant_8,v2117_2);
        const Space v2117_4 = (has_head(v2117_3) ? constant_9 : Space{});
        const Space v2117_5 = subtract(constant_0,v2117_4);
        Space v2117_8;
        if (!v2117_5.empty()) {
          const Path v2118_6 = concat_path(v2116_6,v2116_7_head);
          const Space v2118_7 = routine_301(c, v2118_6, p1, p2, v2116_7_tail);
          v2117_8 = compose(v2117_5,v2118_7);
        }
        const Space v2117_9 = intersect(constant_8,v2117_2);
        const Space v2117_10 = (has_head(v2117_9) ? constant_9 : Space{});
        Space v2117_12;
        if (!v2117_10.empty()) {
          const Path v2119_6 = concat_path(v2116_6,v2116_7_head);
          const Space v2119_11 = routine_302(c, v2119_6, p1, p2, v2116_7_tail);
          v2117_12 = compose(v2117_10,v2119_11);
        }
        const Space v2117_13 = unite(v2117_8,v2117_12);
        v2116_7_result = unite(v2116_7_result,v2117_13);
      }
      const Space v2116_7 = std::move(v2116_7_result);
      v2115_8 = compose(v2115_5,v2116_7);
    }
    const Space v2115_9 = intersect(constant_8,v2115_2);
    const Space v2115_10 = (has_head(v2115_9) ? constant_9 : Space{});
    const Path v2120_6 = concat_path(p0,v2114_18_head);
    const Path v2115_11 = concat_path(constant_24,v2120_6);
    const Space v2115_12 = singleton(v2115_11);
    const Space v2115_13 = unite(constant_29,v2115_12);
    const Space v2115_14 = unite(v2115_13,v2114_11);
    const Space v2115_15 = unite(v2115_14,v2114_14);
    const Space v2115_16 = compose(v2115_10,v2115_15);
    const Space v2115_17 = unite(v2115_8,v2115_16);
    v2114_18_result = unite(v2114_18_result,v2115_17);
  }
  const Space v2114_18 = std::move(v2114_18_result);
  return v2114_18;
}

static Space routine_252(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2121_6 = concat_path(constant_24,p0);
  const Space v2121_7 = singleton(v2121_6);
  const Space v2121_8 = unite(constant_29,v2121_7);
  const Path v2121_10 = concat_path(constant_23,p2);
  const Space v2121_11 = singleton(v2121_10);
  const Space v2121_12 = unite(v2121_8,v2121_11);
  const Path v2121_14 = concat_path(constant_22,p1);
  const Space v2121_15 = singleton(v2121_14);
  const Space v2121_16 = unite(v2121_12,v2121_15);
  return v2121_16;
}

static Space routine_253(Context& c, const Path& p0, const Space& s0) {
  Space v2122_2_result;
  for (int v2122_2_label = 1; v2122_2_label <= 2; ++v2122_2_label) {
    const Space v2122_2_tail = child(s0,v2122_2_label);
    if (v2122_2_tail.empty()) continue;
    const Path v2122_2_head{v2122_2_label};
    const Space v2123_2 = Space{};
    v2122_2_result = unite(v2122_2_result,v2123_2);
  }
  const Space v2122_2 = std::move(v2122_2_result);
  return v2122_2;
}

static Space routine_254(Context& c, const Path& p0, const Space& s0) {
  Space v2124_6_result;
  for (int v2124_6_label = 1; v2124_6_label <= 2; ++v2124_6_label) {
    const Space v2124_6_tail = child(s0,v2124_6_label);
    if (v2124_6_tail.empty()) continue;
    const Path v2124_6_head{v2124_6_label};
    const Space v2125_2 = singleton(v2124_6_head);
    const Space v2125_3 = intersect(constant_8,v2125_2);
    const Space v2125_4 = (has_head(v2125_3) ? constant_9 : Space{});
    Space v2125_7;
    if (!v2125_4.empty()) {
      const Path v2126_5 = concat_path(p0,v2124_6_head);
      Space v2126_6_result;
      for (int v2126_6_label = 1; v2126_6_label <= 2; ++v2126_6_label) {
        const Space v2126_6_tail = child(v2124_6_tail,v2126_6_label);
        if (v2126_6_tail.empty()) continue;
        const Path v2126_6_head{v2126_6_label};
        const Space v2127_2 = singleton(v2126_6_head);
        const Space v2127_3 = intersect(constant_8,v2127_2);
        const Space v2127_4 = (has_head(v2127_3) ? constant_9 : Space{});
        const Space v2127_5 = subtract(constant_0,v2127_4);
        Space v2127_7;
        if (!v2127_5.empty()) {
          const Space v2128_6 = routine_174(c, v2126_6_head, v2126_5, v2126_6_tail);
          v2127_7 = compose(v2127_5,v2128_6);
        }
        const Space v2127_8 = intersect(constant_8,v2127_2);
        const Space v2127_9 = (has_head(v2127_8) ? constant_9 : Space{});
        Space v2127_11;
        if (!v2127_9.empty()) {
          const Space v2129_10 = routine_175(c, v2126_6_head, v2126_5, v2126_6_tail);
          v2127_11 = compose(v2127_9,v2129_10);
        }
        const Space v2127_12 = unite(v2127_7,v2127_11);
        v2126_6_result = unite(v2126_6_result,v2127_12);
      }
      const Space v2126_6 = std::move(v2126_6_result);
      v2125_7 = compose(v2125_4,v2126_6);
    }
    v2124_6_result = unite(v2124_6_result,v2125_7);
  }
  const Space v2124_6 = std::move(v2124_6_result);
  return v2124_6;
}

static Space routine_255(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2130_12_result;
  for (int v2130_12_label = 1; v2130_12_label <= 2; ++v2130_12_label) {
    const Space v2130_12_tail = child(s0,v2130_12_label);
    if (v2130_12_tail.empty()) continue;
    const Path v2130_12_head{v2130_12_label};
    const Space v2131_2 = singleton(v2130_12_head);
    const Space v2131_3 = intersect(constant_8,v2131_2);
    const Space v2131_4 = (has_head(v2131_3) ? constant_9 : Space{});
    const Space v2131_5 = subtract(constant_0,v2131_4);
    Space v2131_8;
    if (!v2131_5.empty()) {
      const Path v2132_6 = concat_path(p0,v2130_12_head);
      Space v2132_7_result;
      for (int v2132_7_label = 1; v2132_7_label <= 2; ++v2132_7_label) {
        const Space v2132_7_tail = child(v2130_12_tail,v2132_7_label);
        if (v2132_7_tail.empty()) continue;
        const Path v2132_7_head{v2132_7_label};
        const Space v2133_2 = singleton(v2132_7_head);
        const Space v2133_3 = intersect(constant_8,v2133_2);
        const Space v2133_4 = (has_head(v2133_3) ? constant_9 : Space{});
        const Space v2133_5 = subtract(constant_0,v2133_4);
        Space v2133_8;
        if (!v2133_5.empty()) {
          const Path v2134_6 = concat_path(v2132_6,v2132_7_head);
          const Space v2134_7 = routine_303(c, v2134_6, p1, v2132_7_tail);
          v2133_8 = compose(v2133_5,v2134_7);
        }
        const Space v2133_9 = intersect(constant_8,v2133_2);
        const Space v2133_10 = (has_head(v2133_9) ? constant_9 : Space{});
        Space v2133_12;
        if (!v2133_10.empty()) {
          const Path v2135_6 = concat_path(v2132_6,v2132_7_head);
          const Space v2135_11 = routine_304(c, v2135_6, p1, v2132_7_tail);
          v2133_12 = compose(v2133_10,v2135_11);
        }
        const Space v2133_13 = unite(v2133_8,v2133_12);
        v2132_7_result = unite(v2132_7_result,v2133_13);
      }
      const Space v2132_7 = std::move(v2132_7_result);
      v2131_8 = compose(v2131_5,v2132_7);
    }
    const Space v2131_9 = intersect(constant_8,v2131_2);
    const Space v2131_10 = (has_head(v2131_9) ? constant_9 : Space{});
    Space v2131_12;
    if (!v2131_10.empty()) {
      const Path v2136_6 = concat_path(p0,v2130_12_head);
      Space v2136_11_result;
      for (int v2136_11_label = 1; v2136_11_label <= 2; ++v2136_11_label) {
        const Space v2136_11_tail = child(v2130_12_tail,v2136_11_label);
        if (v2136_11_tail.empty()) continue;
        const Path v2136_11_head{v2136_11_label};
        const Space v2137_2 = singleton(v2136_11_head);
        const Space v2137_3 = intersect(constant_8,v2137_2);
        const Space v2137_4 = (has_head(v2137_3) ? constant_9 : Space{});
        const Space v2137_5 = subtract(constant_0,v2137_4);
        Space v2137_8;
        if (!v2137_5.empty()) {
          const Path v2138_6 = concat_path(v2136_6,v2136_11_head);
          const Space v2138_7 = routine_303(c, v2138_6, p1, v2136_11_tail);
          v2137_8 = compose(v2137_5,v2138_7);
        }
        const Space v2137_9 = intersect(constant_8,v2137_2);
        const Space v2137_10 = (has_head(v2137_9) ? constant_9 : Space{});
        Space v2137_12;
        if (!v2137_10.empty()) {
          const Path v2139_6 = concat_path(v2136_6,v2136_11_head);
          const Space v2139_11 = routine_223(c, v2139_6, p1, v2136_11_tail);
          v2137_12 = compose(v2137_10,v2139_11);
        }
        const Space v2137_13 = unite(v2137_8,v2137_12);
        v2136_11_result = unite(v2136_11_result,v2137_13);
      }
      const Space v2136_11 = std::move(v2136_11_result);
      v2131_12 = compose(v2131_10,v2136_11);
    }
    const Space v2131_13 = unite(v2131_8,v2131_12);
    v2130_12_result = unite(v2130_12_result,v2131_13);
  }
  const Space v2130_12 = std::move(v2130_12_result);
  return v2130_12;
}

static Space routine_256(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2140_13_result;
  for (int v2140_13_label = 1; v2140_13_label <= 2; ++v2140_13_label) {
    const Space v2140_13_tail = child(s0,v2140_13_label);
    if (v2140_13_tail.empty()) continue;
    const Path v2140_13_head{v2140_13_label};
    const Space v2141_2 = singleton(v2140_13_head);
    const Space v2141_3 = intersect(constant_8,v2141_2);
    const Space v2141_4 = (has_head(v2141_3) ? constant_9 : Space{});
    const Space v2141_5 = subtract(constant_0,v2141_4);
    Space v2141_8;
    if (!v2141_5.empty()) {
      const Path v2142_6 = concat_path(p0,v2140_13_head);
      Space v2142_7_result;
      for (int v2142_7_label = 1; v2142_7_label <= 2; ++v2142_7_label) {
        const Space v2142_7_tail = child(v2140_13_tail,v2142_7_label);
        if (v2142_7_tail.empty()) continue;
        const Path v2142_7_head{v2142_7_label};
        const Space v2143_2 = singleton(v2142_7_head);
        const Space v2143_3 = intersect(constant_8,v2143_2);
        const Space v2143_4 = (has_head(v2143_3) ? constant_9 : Space{});
        const Space v2143_5 = subtract(constant_0,v2143_4);
        Space v2143_8;
        if (!v2143_5.empty()) {
          const Path v2144_6 = concat_path(v2142_6,v2142_7_head);
          const Space v2144_7 = routine_303(c, v2144_6, p1, v2142_7_tail);
          v2143_8 = compose(v2143_5,v2144_7);
        }
        const Space v2143_9 = intersect(constant_8,v2143_2);
        const Space v2143_10 = (has_head(v2143_9) ? constant_9 : Space{});
        Space v2143_12;
        if (!v2143_10.empty()) {
          const Path v2145_6 = concat_path(v2142_6,v2142_7_head);
          const Space v2145_11 = routine_304(c, v2145_6, p1, v2142_7_tail);
          v2143_12 = compose(v2143_10,v2145_11);
        }
        const Space v2143_13 = unite(v2143_8,v2143_12);
        v2142_7_result = unite(v2142_7_result,v2143_13);
      }
      const Space v2142_7 = std::move(v2142_7_result);
      v2141_8 = compose(v2141_5,v2142_7);
    }
    const Space v2141_9 = intersect(constant_8,v2141_2);
    const Space v2141_10 = (has_head(v2141_9) ? constant_9 : Space{});
    Space v2141_14;
    if (!v2141_10.empty()) {
      Space v2146_11_result;
      for (int v2146_11_label = 1; v2146_11_label <= 2; ++v2146_11_label) {
        const Space v2146_11_tail = child(v2140_13_tail,v2146_11_label);
        if (v2146_11_tail.empty()) continue;
        const Path v2146_11_head{v2146_11_label};
        const Space v2147_2 = singleton(v2146_11_head);
        const Space v2147_3 = intersect(constant_8,v2147_2);
        const Space v2147_4 = (has_head(v2147_3) ? constant_9 : Space{});
        const Space v2147_5 = subtract(constant_0,v2147_4);
        Space v2147_7;
        if (!v2147_5.empty()) {
          const Space v2148_6 = routine_257(c, v2146_11_head, v2146_11_tail);
          v2147_7 = compose(v2147_5,v2148_6);
        }
        const Space v2147_8 = intersect(constant_8,v2147_2);
        const Space v2147_9 = (has_head(v2147_8) ? constant_9 : Space{});
        Space v2147_11;
        if (!v2147_9.empty()) {
          const Space v2149_10 = routine_258(c, v2146_11_head, v2146_11_tail);
          v2147_11 = compose(v2147_9,v2149_10);
        }
        const Space v2147_12 = unite(v2147_7,v2147_11);
        v2146_11_result = unite(v2146_11_result,v2147_12);
      }
      const Space v2146_11 = std::move(v2146_11_result);
      const Space v2146_12 = raffine(constant_25,v2146_11);
      const Space v2146_13 = unite(v2146_12,v2140_13_tail);
      v2141_14 = compose(v2141_10,v2146_13);
    }
    const Path v2150_6 = concat_path(p0,v2140_13_head);
    const Path v2141_15 = concat_path(p1,v2150_6);
    const Space v2141_16 = wrap(v2141_14,v2141_15);
    const Space v2141_17 = unite(v2141_8,v2141_16);
    v2140_13_result = unite(v2140_13_result,v2141_17);
  }
  const Space v2140_13 = std::move(v2140_13_result);
  return v2140_13;
}

static Space routine_257(Context& c, const Path& p0, const Space& s0) {
  Space v2151_11_result;
  for (int v2151_11_label = 1; v2151_11_label <= 2; ++v2151_11_label) {
    const Space v2151_11_tail = child(s0,v2151_11_label);
    if (v2151_11_tail.empty()) continue;
    const Path v2151_11_head{v2151_11_label};
    const Space v2152_2 = singleton(v2151_11_head);
    const Space v2152_3 = intersect(constant_8,v2152_2);
    const Space v2152_4 = (has_head(v2152_3) ? constant_9 : Space{});
    const Space v2152_5 = subtract(constant_0,v2152_4);
    Space v2152_8;
    if (!v2152_5.empty()) {
      const Path v2153_6 = concat_path(p0,v2151_11_head);
      Space v2153_7_result;
      for (int v2153_7_label = 1; v2153_7_label <= 2; ++v2153_7_label) {
        const Space v2153_7_tail = child(v2151_11_tail,v2153_7_label);
        if (v2153_7_tail.empty()) continue;
        const Path v2153_7_head{v2153_7_label};
        const Space v2154_2 = singleton(v2153_7_head);
        const Space v2154_3 = intersect(constant_8,v2154_2);
        const Space v2154_4 = (has_head(v2154_3) ? constant_9 : Space{});
        const Space v2154_5 = subtract(constant_0,v2154_4);
        Space v2154_8;
        if (!v2154_5.empty()) {
          const Path v2155_6 = concat_path(v2153_6,v2153_7_head);
          const Space v2155_7 = routine_305(c, v2155_6, v2153_7_tail);
          v2154_8 = compose(v2154_5,v2155_7);
        }
        const Space v2154_9 = intersect(constant_8,v2154_2);
        const Space v2154_10 = (has_head(v2154_9) ? constant_9 : Space{});
        Space v2154_12;
        if (!v2154_10.empty()) {
          const Path v2156_6 = concat_path(v2153_6,v2153_7_head);
          const Space v2156_11 = routine_306(c, v2156_6, v2153_7_tail);
          v2154_12 = compose(v2154_10,v2156_11);
        }
        const Space v2154_13 = unite(v2154_8,v2154_12);
        v2153_7_result = unite(v2153_7_result,v2154_13);
      }
      const Space v2153_7 = std::move(v2153_7_result);
      v2152_8 = compose(v2152_5,v2153_7);
    }
    const Space v2152_9 = intersect(constant_8,v2152_2);
    const Space v2152_10 = (has_head(v2152_9) ? constant_9 : Space{});
    Space v2152_12;
    if (!v2152_10.empty()) {
      const Path v2157_6 = concat_path(p0,v2151_11_head);
      Space v2157_11_result;
      for (int v2157_11_label = 1; v2157_11_label <= 2; ++v2157_11_label) {
        const Space v2157_11_tail = child(v2151_11_tail,v2157_11_label);
        if (v2157_11_tail.empty()) continue;
        const Path v2157_11_head{v2157_11_label};
        const Space v2158_2 = singleton(v2157_11_head);
        const Space v2158_3 = intersect(constant_8,v2158_2);
        const Space v2158_4 = (has_head(v2158_3) ? constant_9 : Space{});
        const Space v2158_5 = subtract(constant_0,v2158_4);
        Space v2158_8;
        if (!v2158_5.empty()) {
          const Path v2159_6 = concat_path(v2157_6,v2157_11_head);
          const Space v2159_7 = routine_305(c, v2159_6, v2157_11_tail);
          v2158_8 = compose(v2158_5,v2159_7);
        }
        const Space v2158_9 = intersect(constant_8,v2158_2);
        const Space v2158_10 = (has_head(v2158_9) ? constant_9 : Space{});
        Space v2158_12;
        if (!v2158_10.empty()) {
          const Path v2160_6 = concat_path(v2157_6,v2157_11_head);
          const Space v2160_11 = routine_289(c, v2160_6, v2157_11_tail);
          v2158_12 = compose(v2158_10,v2160_11);
        }
        const Space v2158_13 = unite(v2158_8,v2158_12);
        v2157_11_result = unite(v2157_11_result,v2158_13);
      }
      const Space v2157_11 = std::move(v2157_11_result);
      v2152_12 = compose(v2152_10,v2157_11);
    }
    const Space v2152_13 = unite(v2152_8,v2152_12);
    v2151_11_result = unite(v2151_11_result,v2152_13);
  }
  const Space v2151_11 = std::move(v2151_11_result);
  return v2151_11;
}

static Space routine_258(Context& c, const Path& p0, const Space& s0) {
  Space v2161_8_result;
  for (int v2161_8_label = 1; v2161_8_label <= 2; ++v2161_8_label) {
    const Space v2161_8_tail = child(s0,v2161_8_label);
    if (v2161_8_tail.empty()) continue;
    const Path v2161_8_head{v2161_8_label};
    const Space v2162_2 = singleton(v2161_8_head);
    const Space v2162_3 = intersect(constant_8,v2162_2);
    const Space v2162_4 = (has_head(v2162_3) ? constant_9 : Space{});
    const Space v2162_5 = subtract(constant_0,v2162_4);
    Space v2162_8;
    if (!v2162_5.empty()) {
      const Path v2163_6 = concat_path(p0,v2161_8_head);
      Space v2163_7_result;
      for (int v2163_7_label = 1; v2163_7_label <= 2; ++v2163_7_label) {
        const Space v2163_7_tail = child(v2161_8_tail,v2163_7_label);
        if (v2163_7_tail.empty()) continue;
        const Path v2163_7_head{v2163_7_label};
        const Space v2164_2 = singleton(v2163_7_head);
        const Space v2164_3 = intersect(constant_8,v2164_2);
        const Space v2164_4 = (has_head(v2164_3) ? constant_9 : Space{});
        const Space v2164_5 = subtract(constant_0,v2164_4);
        Space v2164_8;
        if (!v2164_5.empty()) {
          const Path v2165_6 = concat_path(v2163_6,v2163_7_head);
          const Space v2165_7 = routine_305(c, v2165_6, v2163_7_tail);
          v2164_8 = compose(v2164_5,v2165_7);
        }
        const Space v2164_9 = intersect(constant_8,v2164_2);
        const Space v2164_10 = (has_head(v2164_9) ? constant_9 : Space{});
        Space v2164_12;
        if (!v2164_10.empty()) {
          const Path v2166_6 = concat_path(v2163_6,v2163_7_head);
          const Space v2166_11 = routine_306(c, v2166_6, v2163_7_tail);
          v2164_12 = compose(v2164_10,v2166_11);
        }
        const Space v2164_13 = unite(v2164_8,v2164_12);
        v2163_7_result = unite(v2163_7_result,v2164_13);
      }
      const Space v2163_7 = std::move(v2163_7_result);
      v2162_8 = compose(v2162_5,v2163_7);
    }
    const Space v2162_9 = intersect(constant_8,v2162_2);
    const Space v2162_10 = (has_head(v2162_9) ? constant_9 : Space{});
    const Path v2167_6 = concat_path(p0,v2161_8_head);
    const Space v2162_11 = singleton(v2167_6);
    const Space v2162_12 = compose(v2162_10,v2162_11);
    const Space v2162_13 = unite(v2162_8,v2162_12);
    v2161_8_result = unite(v2161_8_result,v2162_13);
  }
  const Space v2161_8 = std::move(v2161_8_result);
  return v2161_8;
}

static Space routine_259(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v2168_4_result;
  for (int v2168_4_label = 1; v2168_4_label <= 2; ++v2168_4_label) {
    const Space v2168_4_tail = child(s0,v2168_4_label);
    if (v2168_4_tail.empty()) continue;
    const Path v2168_4_head{v2168_4_label};
    const Space v2169_2 = Space{};
    v2168_4_result = unite(v2168_4_result,v2169_2);
  }
  const Space v2168_4 = std::move(v2168_4_result);
  return v2168_4;
}

static Space routine_260(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v2170_5_result;
  for (int v2170_5_label = 1; v2170_5_label <= 2; ++v2170_5_label) {
    const Space v2170_5_tail = child(s0,v2170_5_label);
    if (v2170_5_tail.empty()) continue;
    const Path v2170_5_head{v2170_5_label};
    const Space v2171_2 = singleton(v2170_5_head);
    const Space v2171_3 = intersect(constant_8,v2171_2);
    const Space v2171_4 = (has_head(v2171_3) ? constant_9 : Space{});
    const Space v2171_5 = unwrap(v2170_5_tail,p1);
    const Path v2171_6 = concat_path(p0,v2170_5_head);
    const Space v2171_7 = wrap(v2171_5,v2171_6);
    const Space v2171_8 = compose(v2171_7,s1);
    const Space v2171_9 = compose(v2171_4,v2171_8);
    v2170_5_result = unite(v2170_5_result,v2171_9);
  }
  const Space v2170_5 = std::move(v2170_5_result);
  return v2170_5;
}

static Space routine_261(Context& c, const Path& p0, const Space& s0) {
  Space v2172_2_result;
  for (int v2172_2_label = 1; v2172_2_label <= 2; ++v2172_2_label) {
    const Space v2172_2_tail = child(s0,v2172_2_label);
    if (v2172_2_tail.empty()) continue;
    const Path v2172_2_head{v2172_2_label};
    const Space v2173_2 = Space{};
    v2172_2_result = unite(v2172_2_result,v2173_2);
  }
  const Space v2172_2 = std::move(v2172_2_result);
  return v2172_2;
}

static Space routine_262(Context& c, const Path& p0, const Space& s0) {
  Space v2174_6_result;
  for (int v2174_6_label = 1; v2174_6_label <= 2; ++v2174_6_label) {
    const Space v2174_6_tail = child(s0,v2174_6_label);
    if (v2174_6_tail.empty()) continue;
    const Path v2174_6_head{v2174_6_label};
    const Space v2175_2 = singleton(v2174_6_head);
    const Space v2175_3 = intersect(constant_8,v2175_2);
    const Space v2175_4 = (has_head(v2175_3) ? constant_9 : Space{});
    Space v2175_7;
    if (!v2175_4.empty()) {
      const Path v2176_5 = concat_path(p0,v2174_6_head);
      Space v2176_6_result;
      for (int v2176_6_label = 1; v2176_6_label <= 2; ++v2176_6_label) {
        const Space v2176_6_tail = child(v2174_6_tail,v2176_6_label);
        if (v2176_6_tail.empty()) continue;
        const Path v2176_6_head{v2176_6_label};
        const Space v2177_2 = singleton(v2176_6_head);
        const Space v2177_3 = intersect(constant_8,v2177_2);
        const Space v2177_4 = (has_head(v2177_3) ? constant_9 : Space{});
        const Space v2177_5 = subtract(constant_0,v2177_4);
        Space v2177_7;
        if (!v2177_5.empty()) {
          const Space v2178_6 = routine_182(c, v2176_6_head, v2176_5, v2176_6_tail);
          v2177_7 = compose(v2177_5,v2178_6);
        }
        const Space v2177_8 = intersect(constant_8,v2177_2);
        const Space v2177_9 = (has_head(v2177_8) ? constant_9 : Space{});
        Space v2177_11;
        if (!v2177_9.empty()) {
          const Space v2179_10 = routine_183(c, v2176_6_head, v2176_5, v2176_6_tail);
          v2177_11 = compose(v2177_9,v2179_10);
        }
        const Space v2177_12 = unite(v2177_7,v2177_11);
        v2176_6_result = unite(v2176_6_result,v2177_12);
      }
      const Space v2176_6 = std::move(v2176_6_result);
      v2175_7 = compose(v2175_4,v2176_6);
    }
    v2174_6_result = unite(v2174_6_result,v2175_7);
  }
  const Space v2174_6 = std::move(v2174_6_result);
  return v2174_6;
}

static Space routine_263(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2180_12_result;
  for (int v2180_12_label = 1; v2180_12_label <= 2; ++v2180_12_label) {
    const Space v2180_12_tail = child(s0,v2180_12_label);
    if (v2180_12_tail.empty()) continue;
    const Path v2180_12_head{v2180_12_label};
    const Space v2181_2 = singleton(v2180_12_head);
    const Space v2181_3 = intersect(constant_8,v2181_2);
    const Space v2181_4 = (has_head(v2181_3) ? constant_9 : Space{});
    const Space v2181_5 = subtract(constant_0,v2181_4);
    Space v2181_8;
    if (!v2181_5.empty()) {
      const Path v2182_6 = concat_path(p0,v2180_12_head);
      Space v2182_7_result;
      for (int v2182_7_label = 1; v2182_7_label <= 2; ++v2182_7_label) {
        const Space v2182_7_tail = child(v2180_12_tail,v2182_7_label);
        if (v2182_7_tail.empty()) continue;
        const Path v2182_7_head{v2182_7_label};
        const Space v2183_2 = singleton(v2182_7_head);
        const Space v2183_3 = intersect(constant_8,v2183_2);
        const Space v2183_4 = (has_head(v2183_3) ? constant_9 : Space{});
        const Space v2183_5 = subtract(constant_0,v2183_4);
        Space v2183_8;
        if (!v2183_5.empty()) {
          const Path v2184_6 = concat_path(v2182_6,v2182_7_head);
          const Space v2184_7 = routine_307(c, v2184_6, p1, v2182_7_tail);
          v2183_8 = compose(v2183_5,v2184_7);
        }
        const Space v2183_9 = intersect(constant_8,v2183_2);
        const Space v2183_10 = (has_head(v2183_9) ? constant_9 : Space{});
        Space v2183_12;
        if (!v2183_10.empty()) {
          const Path v2185_6 = concat_path(v2182_6,v2182_7_head);
          const Space v2185_11 = routine_308(c, v2185_6, p1, v2182_7_tail);
          v2183_12 = compose(v2183_10,v2185_11);
        }
        const Space v2183_13 = unite(v2183_8,v2183_12);
        v2182_7_result = unite(v2182_7_result,v2183_13);
      }
      const Space v2182_7 = std::move(v2182_7_result);
      v2181_8 = compose(v2181_5,v2182_7);
    }
    const Space v2181_9 = intersect(constant_8,v2181_2);
    const Space v2181_10 = (has_head(v2181_9) ? constant_9 : Space{});
    Space v2181_12;
    if (!v2181_10.empty()) {
      const Path v2186_6 = concat_path(p0,v2180_12_head);
      Space v2186_11_result;
      for (int v2186_11_label = 1; v2186_11_label <= 2; ++v2186_11_label) {
        const Space v2186_11_tail = child(v2180_12_tail,v2186_11_label);
        if (v2186_11_tail.empty()) continue;
        const Path v2186_11_head{v2186_11_label};
        const Space v2187_2 = singleton(v2186_11_head);
        const Space v2187_3 = intersect(constant_8,v2187_2);
        const Space v2187_4 = (has_head(v2187_3) ? constant_9 : Space{});
        const Space v2187_5 = subtract(constant_0,v2187_4);
        Space v2187_8;
        if (!v2187_5.empty()) {
          const Path v2188_6 = concat_path(v2186_6,v2186_11_head);
          const Space v2188_7 = routine_307(c, v2188_6, p1, v2186_11_tail);
          v2187_8 = compose(v2187_5,v2188_7);
        }
        const Space v2187_9 = intersect(constant_8,v2187_2);
        const Space v2187_10 = (has_head(v2187_9) ? constant_9 : Space{});
        Space v2187_12;
        if (!v2187_10.empty()) {
          const Path v2189_6 = concat_path(v2186_6,v2186_11_head);
          const Space v2189_11 = routine_230(c, v2189_6, p1, v2186_11_tail);
          v2187_12 = compose(v2187_10,v2189_11);
        }
        const Space v2187_13 = unite(v2187_8,v2187_12);
        v2186_11_result = unite(v2186_11_result,v2187_13);
      }
      const Space v2186_11 = std::move(v2186_11_result);
      v2181_12 = compose(v2181_10,v2186_11);
    }
    const Space v2181_13 = unite(v2181_8,v2181_12);
    v2180_12_result = unite(v2180_12_result,v2181_13);
  }
  const Space v2180_12 = std::move(v2180_12_result);
  return v2180_12;
}

static Space routine_264(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2190_13_result;
  for (int v2190_13_label = 1; v2190_13_label <= 2; ++v2190_13_label) {
    const Space v2190_13_tail = child(s0,v2190_13_label);
    if (v2190_13_tail.empty()) continue;
    const Path v2190_13_head{v2190_13_label};
    const Space v2191_2 = singleton(v2190_13_head);
    const Space v2191_3 = intersect(constant_8,v2191_2);
    const Space v2191_4 = (has_head(v2191_3) ? constant_9 : Space{});
    const Space v2191_5 = subtract(constant_0,v2191_4);
    Space v2191_8;
    if (!v2191_5.empty()) {
      const Path v2192_6 = concat_path(p0,v2190_13_head);
      Space v2192_7_result;
      for (int v2192_7_label = 1; v2192_7_label <= 2; ++v2192_7_label) {
        const Space v2192_7_tail = child(v2190_13_tail,v2192_7_label);
        if (v2192_7_tail.empty()) continue;
        const Path v2192_7_head{v2192_7_label};
        const Space v2193_2 = singleton(v2192_7_head);
        const Space v2193_3 = intersect(constant_8,v2193_2);
        const Space v2193_4 = (has_head(v2193_3) ? constant_9 : Space{});
        const Space v2193_5 = subtract(constant_0,v2193_4);
        Space v2193_8;
        if (!v2193_5.empty()) {
          const Path v2194_6 = concat_path(v2192_6,v2192_7_head);
          const Space v2194_7 = routine_307(c, v2194_6, p1, v2192_7_tail);
          v2193_8 = compose(v2193_5,v2194_7);
        }
        const Space v2193_9 = intersect(constant_8,v2193_2);
        const Space v2193_10 = (has_head(v2193_9) ? constant_9 : Space{});
        Space v2193_12;
        if (!v2193_10.empty()) {
          const Path v2195_6 = concat_path(v2192_6,v2192_7_head);
          const Space v2195_11 = routine_308(c, v2195_6, p1, v2192_7_tail);
          v2193_12 = compose(v2193_10,v2195_11);
        }
        const Space v2193_13 = unite(v2193_8,v2193_12);
        v2192_7_result = unite(v2192_7_result,v2193_13);
      }
      const Space v2192_7 = std::move(v2192_7_result);
      v2191_8 = compose(v2191_5,v2192_7);
    }
    const Space v2191_9 = intersect(constant_8,v2191_2);
    const Space v2191_10 = (has_head(v2191_9) ? constant_9 : Space{});
    Space v2191_14;
    if (!v2191_10.empty()) {
      Space v2196_11_result;
      for (int v2196_11_label = 1; v2196_11_label <= 2; ++v2196_11_label) {
        const Space v2196_11_tail = child(v2190_13_tail,v2196_11_label);
        if (v2196_11_tail.empty()) continue;
        const Path v2196_11_head{v2196_11_label};
        const Space v2197_2 = singleton(v2196_11_head);
        const Space v2197_3 = intersect(constant_8,v2197_2);
        const Space v2197_4 = (has_head(v2197_3) ? constant_9 : Space{});
        const Space v2197_5 = subtract(constant_0,v2197_4);
        Space v2197_7;
        if (!v2197_5.empty()) {
          const Space v2198_6 = routine_265(c, v2196_11_head, v2196_11_tail);
          v2197_7 = compose(v2197_5,v2198_6);
        }
        const Space v2197_8 = intersect(constant_8,v2197_2);
        const Space v2197_9 = (has_head(v2197_8) ? constant_9 : Space{});
        Space v2197_11;
        if (!v2197_9.empty()) {
          const Space v2199_10 = routine_266(c, v2196_11_head, v2196_11_tail);
          v2197_11 = compose(v2197_9,v2199_10);
        }
        const Space v2197_12 = unite(v2197_7,v2197_11);
        v2196_11_result = unite(v2196_11_result,v2197_12);
      }
      const Space v2196_11 = std::move(v2196_11_result);
      const Space v2196_12 = raffine(constant_25,v2196_11);
      const Space v2196_13 = unite(v2196_12,v2190_13_tail);
      v2191_14 = compose(v2191_10,v2196_13);
    }
    const Path v2200_6 = concat_path(p0,v2190_13_head);
    const Path v2191_15 = concat_path(p1,v2200_6);
    const Space v2191_16 = wrap(v2191_14,v2191_15);
    const Space v2191_17 = unite(v2191_8,v2191_16);
    v2190_13_result = unite(v2190_13_result,v2191_17);
  }
  const Space v2190_13 = std::move(v2190_13_result);
  return v2190_13;
}

static Space routine_265(Context& c, const Path& p0, const Space& s0) {
  Space v2201_11_result;
  for (int v2201_11_label = 1; v2201_11_label <= 2; ++v2201_11_label) {
    const Space v2201_11_tail = child(s0,v2201_11_label);
    if (v2201_11_tail.empty()) continue;
    const Path v2201_11_head{v2201_11_label};
    const Space v2202_2 = singleton(v2201_11_head);
    const Space v2202_3 = intersect(constant_8,v2202_2);
    const Space v2202_4 = (has_head(v2202_3) ? constant_9 : Space{});
    const Space v2202_5 = subtract(constant_0,v2202_4);
    Space v2202_8;
    if (!v2202_5.empty()) {
      const Path v2203_6 = concat_path(p0,v2201_11_head);
      Space v2203_7_result;
      for (int v2203_7_label = 1; v2203_7_label <= 2; ++v2203_7_label) {
        const Space v2203_7_tail = child(v2201_11_tail,v2203_7_label);
        if (v2203_7_tail.empty()) continue;
        const Path v2203_7_head{v2203_7_label};
        const Space v2204_2 = singleton(v2203_7_head);
        const Space v2204_3 = intersect(constant_8,v2204_2);
        const Space v2204_4 = (has_head(v2204_3) ? constant_9 : Space{});
        const Space v2204_5 = subtract(constant_0,v2204_4);
        Space v2204_8;
        if (!v2204_5.empty()) {
          const Path v2205_6 = concat_path(v2203_6,v2203_7_head);
          const Space v2205_7 = routine_309(c, v2205_6, v2203_7_tail);
          v2204_8 = compose(v2204_5,v2205_7);
        }
        const Space v2204_9 = intersect(constant_8,v2204_2);
        const Space v2204_10 = (has_head(v2204_9) ? constant_9 : Space{});
        Space v2204_12;
        if (!v2204_10.empty()) {
          const Path v2206_6 = concat_path(v2203_6,v2203_7_head);
          const Space v2206_11 = routine_310(c, v2206_6, v2203_7_tail);
          v2204_12 = compose(v2204_10,v2206_11);
        }
        const Space v2204_13 = unite(v2204_8,v2204_12);
        v2203_7_result = unite(v2203_7_result,v2204_13);
      }
      const Space v2203_7 = std::move(v2203_7_result);
      v2202_8 = compose(v2202_5,v2203_7);
    }
    const Space v2202_9 = intersect(constant_8,v2202_2);
    const Space v2202_10 = (has_head(v2202_9) ? constant_9 : Space{});
    Space v2202_12;
    if (!v2202_10.empty()) {
      const Path v2207_6 = concat_path(p0,v2201_11_head);
      Space v2207_11_result;
      for (int v2207_11_label = 1; v2207_11_label <= 2; ++v2207_11_label) {
        const Space v2207_11_tail = child(v2201_11_tail,v2207_11_label);
        if (v2207_11_tail.empty()) continue;
        const Path v2207_11_head{v2207_11_label};
        const Space v2208_2 = singleton(v2207_11_head);
        const Space v2208_3 = intersect(constant_8,v2208_2);
        const Space v2208_4 = (has_head(v2208_3) ? constant_9 : Space{});
        const Space v2208_5 = subtract(constant_0,v2208_4);
        Space v2208_8;
        if (!v2208_5.empty()) {
          const Path v2209_6 = concat_path(v2207_6,v2207_11_head);
          const Space v2209_7 = routine_309(c, v2209_6, v2207_11_tail);
          v2208_8 = compose(v2208_5,v2209_7);
        }
        const Space v2208_9 = intersect(constant_8,v2208_2);
        const Space v2208_10 = (has_head(v2208_9) ? constant_9 : Space{});
        Space v2208_12;
        if (!v2208_10.empty()) {
          const Path v2210_6 = concat_path(v2207_6,v2207_11_head);
          const Space v2210_11 = routine_294(c, v2210_6, v2207_11_tail);
          v2208_12 = compose(v2208_10,v2210_11);
        }
        const Space v2208_13 = unite(v2208_8,v2208_12);
        v2207_11_result = unite(v2207_11_result,v2208_13);
      }
      const Space v2207_11 = std::move(v2207_11_result);
      v2202_12 = compose(v2202_10,v2207_11);
    }
    const Space v2202_13 = unite(v2202_8,v2202_12);
    v2201_11_result = unite(v2201_11_result,v2202_13);
  }
  const Space v2201_11 = std::move(v2201_11_result);
  return v2201_11;
}

static Space routine_266(Context& c, const Path& p0, const Space& s0) {
  Space v2211_8_result;
  for (int v2211_8_label = 1; v2211_8_label <= 2; ++v2211_8_label) {
    const Space v2211_8_tail = child(s0,v2211_8_label);
    if (v2211_8_tail.empty()) continue;
    const Path v2211_8_head{v2211_8_label};
    const Space v2212_2 = singleton(v2211_8_head);
    const Space v2212_3 = intersect(constant_8,v2212_2);
    const Space v2212_4 = (has_head(v2212_3) ? constant_9 : Space{});
    const Space v2212_5 = subtract(constant_0,v2212_4);
    Space v2212_8;
    if (!v2212_5.empty()) {
      const Path v2213_6 = concat_path(p0,v2211_8_head);
      Space v2213_7_result;
      for (int v2213_7_label = 1; v2213_7_label <= 2; ++v2213_7_label) {
        const Space v2213_7_tail = child(v2211_8_tail,v2213_7_label);
        if (v2213_7_tail.empty()) continue;
        const Path v2213_7_head{v2213_7_label};
        const Space v2214_2 = singleton(v2213_7_head);
        const Space v2214_3 = intersect(constant_8,v2214_2);
        const Space v2214_4 = (has_head(v2214_3) ? constant_9 : Space{});
        const Space v2214_5 = subtract(constant_0,v2214_4);
        Space v2214_8;
        if (!v2214_5.empty()) {
          const Path v2215_6 = concat_path(v2213_6,v2213_7_head);
          const Space v2215_7 = routine_309(c, v2215_6, v2213_7_tail);
          v2214_8 = compose(v2214_5,v2215_7);
        }
        const Space v2214_9 = intersect(constant_8,v2214_2);
        const Space v2214_10 = (has_head(v2214_9) ? constant_9 : Space{});
        Space v2214_12;
        if (!v2214_10.empty()) {
          const Path v2216_6 = concat_path(v2213_6,v2213_7_head);
          const Space v2216_11 = routine_310(c, v2216_6, v2213_7_tail);
          v2214_12 = compose(v2214_10,v2216_11);
        }
        const Space v2214_13 = unite(v2214_8,v2214_12);
        v2213_7_result = unite(v2213_7_result,v2214_13);
      }
      const Space v2213_7 = std::move(v2213_7_result);
      v2212_8 = compose(v2212_5,v2213_7);
    }
    const Space v2212_9 = intersect(constant_8,v2212_2);
    const Space v2212_10 = (has_head(v2212_9) ? constant_9 : Space{});
    const Path v2217_6 = concat_path(p0,v2211_8_head);
    const Space v2212_11 = singleton(v2217_6);
    const Space v2212_12 = compose(v2212_10,v2212_11);
    const Space v2212_13 = unite(v2212_8,v2212_12);
    v2211_8_result = unite(v2211_8_result,v2212_13);
  }
  const Space v2211_8 = std::move(v2211_8_result);
  return v2211_8;
}

static Space routine_267(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v2218_3_result;
  for (int v2218_3_label = 1; v2218_3_label <= 2; ++v2218_3_label) {
    const Space v2218_3_tail = child(s0,v2218_3_label);
    if (v2218_3_tail.empty()) continue;
    const Path v2218_3_head{v2218_3_label};
    const Space v2219_2 = Space{};
    v2218_3_result = unite(v2218_3_result,v2219_2);
  }
  const Space v2218_3 = std::move(v2218_3_result);
  return v2218_3;
}

static Space routine_268(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v2220_4_result;
  for (int v2220_4_label = 1; v2220_4_label <= 2; ++v2220_4_label) {
    const Space v2220_4_tail = child(s0,v2220_4_label);
    if (v2220_4_tail.empty()) continue;
    const Path v2220_4_head{v2220_4_label};
    const Space v2221_2 = singleton(v2220_4_head);
    const Space v2221_3 = intersect(constant_8,v2221_2);
    const Space v2221_4 = (has_head(v2221_3) ? constant_9 : Space{});
    Space v2221_7;
    if (!v2221_4.empty()) {
      const Path v2222_5 = concat_path(p0,v2220_4_head);
      const Space v2222_6 = routine_186(c, v2222_5, s1);
      v2221_7 = compose(v2221_4,v2222_6);
    }
    v2220_4_result = unite(v2220_4_result,v2221_7);
  }
  const Space v2220_4 = std::move(v2220_4_result);
  return v2220_4;
}

static Space routine_269(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2223_3_result;
  for (int v2223_3_label = 1; v2223_3_label <= 2; ++v2223_3_label) {
    const Space v2223_3_tail = child(s0,v2223_3_label);
    if (v2223_3_tail.empty()) continue;
    const Path v2223_3_head{v2223_3_label};
    const Space v2224_2 = Space{};
    v2223_3_result = unite(v2223_3_result,v2224_2);
  }
  const Space v2223_3 = std::move(v2223_3_result);
  return v2223_3;
}

static Space routine_270(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2225_7_result;
  for (int v2225_7_label = 1; v2225_7_label <= 2; ++v2225_7_label) {
    const Space v2225_7_tail = child(s0,v2225_7_label);
    if (v2225_7_tail.empty()) continue;
    const Path v2225_7_head{v2225_7_label};
    const Space v2226_2 = singleton(v2225_7_head);
    const Space v2226_3 = intersect(constant_8,v2226_2);
    const Space v2226_4 = (has_head(v2226_3) ? constant_9 : Space{});
    Space v2226_7;
    if (!v2226_4.empty()) {
      const Path v2227_5 = concat_path(p0,v2225_7_head);
      Space v2227_6_result;
      for (int v2227_6_label = 1; v2227_6_label <= 2; ++v2227_6_label) {
        const Space v2227_6_tail = child(v2225_7_tail,v2227_6_label);
        if (v2227_6_tail.empty()) continue;
        const Path v2227_6_head{v2227_6_label};
        const Space v2228_2 = singleton(v2227_6_head);
        const Space v2228_3 = intersect(constant_8,v2228_2);
        const Space v2228_4 = (has_head(v2228_3) ? constant_9 : Space{});
        const Space v2228_5 = subtract(constant_0,v2228_4);
        Space v2228_7;
        if (!v2228_5.empty()) {
          const Space v2229_6 = routine_193(c, v2227_6_head, p1, v2227_5, v2227_6_tail);
          v2228_7 = compose(v2228_5,v2229_6);
        }
        const Space v2228_8 = intersect(constant_8,v2228_2);
        const Space v2228_9 = (has_head(v2228_8) ? constant_9 : Space{});
        Space v2228_11;
        if (!v2228_9.empty()) {
          const Space v2230_10 = routine_194(c, v2227_6_head, p1, v2227_5, v2227_6_tail);
          v2228_11 = compose(v2228_9,v2230_10);
        }
        const Space v2228_12 = unite(v2228_7,v2228_11);
        v2227_6_result = unite(v2227_6_result,v2228_12);
      }
      const Space v2227_6 = std::move(v2227_6_result);
      v2226_7 = compose(v2226_4,v2227_6);
    }
    v2225_7_result = unite(v2225_7_result,v2226_7);
  }
  const Space v2225_7 = std::move(v2225_7_result);
  return v2225_7;
}

static Space routine_271(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2231_13_result;
  for (int v2231_13_label = 1; v2231_13_label <= 2; ++v2231_13_label) {
    const Space v2231_13_tail = child(s0,v2231_13_label);
    if (v2231_13_tail.empty()) continue;
    const Path v2231_13_head{v2231_13_label};
    const Space v2232_2 = singleton(v2231_13_head);
    const Space v2232_3 = intersect(constant_8,v2232_2);
    const Space v2232_4 = (has_head(v2232_3) ? constant_9 : Space{});
    const Space v2232_5 = subtract(constant_0,v2232_4);
    Space v2232_8;
    if (!v2232_5.empty()) {
      const Path v2233_6 = concat_path(p0,v2231_13_head);
      Space v2233_7_result;
      for (int v2233_7_label = 1; v2233_7_label <= 2; ++v2233_7_label) {
        const Space v2233_7_tail = child(v2231_13_tail,v2233_7_label);
        if (v2233_7_tail.empty()) continue;
        const Path v2233_7_head{v2233_7_label};
        const Space v2234_2 = singleton(v2233_7_head);
        const Space v2234_3 = intersect(constant_8,v2234_2);
        const Space v2234_4 = (has_head(v2234_3) ? constant_9 : Space{});
        const Space v2234_5 = subtract(constant_0,v2234_4);
        Space v2234_8;
        if (!v2234_5.empty()) {
          const Path v2235_6 = concat_path(v2233_6,v2233_7_head);
          const Space v2235_7 = routine_311(c, v2235_6, p1, p2, v2233_7_tail);
          v2234_8 = compose(v2234_5,v2235_7);
        }
        const Space v2234_9 = intersect(constant_8,v2234_2);
        const Space v2234_10 = (has_head(v2234_9) ? constant_9 : Space{});
        Space v2234_12;
        if (!v2234_10.empty()) {
          const Path v2236_6 = concat_path(v2233_6,v2233_7_head);
          const Space v2236_11 = routine_312(c, v2236_6, p1, p2, v2233_7_tail);
          v2234_12 = compose(v2234_10,v2236_11);
        }
        const Space v2234_13 = unite(v2234_8,v2234_12);
        v2233_7_result = unite(v2233_7_result,v2234_13);
      }
      const Space v2233_7 = std::move(v2233_7_result);
      v2232_8 = compose(v2232_5,v2233_7);
    }
    const Space v2232_9 = intersect(constant_8,v2232_2);
    const Space v2232_10 = (has_head(v2232_9) ? constant_9 : Space{});
    Space v2232_12;
    if (!v2232_10.empty()) {
      const Path v2237_6 = concat_path(p0,v2231_13_head);
      Space v2237_11_result;
      for (int v2237_11_label = 1; v2237_11_label <= 2; ++v2237_11_label) {
        const Space v2237_11_tail = child(v2231_13_tail,v2237_11_label);
        if (v2237_11_tail.empty()) continue;
        const Path v2237_11_head{v2237_11_label};
        const Space v2238_2 = singleton(v2237_11_head);
        const Space v2238_3 = intersect(constant_8,v2238_2);
        const Space v2238_4 = (has_head(v2238_3) ? constant_9 : Space{});
        const Space v2238_5 = subtract(constant_0,v2238_4);
        Space v2238_8;
        if (!v2238_5.empty()) {
          const Path v2239_6 = concat_path(v2237_6,v2237_11_head);
          const Space v2239_7 = routine_311(c, v2239_6, p1, p2, v2237_11_tail);
          v2238_8 = compose(v2238_5,v2239_7);
        }
        const Space v2238_9 = intersect(constant_8,v2238_2);
        const Space v2238_10 = (has_head(v2238_9) ? constant_9 : Space{});
        Space v2238_12;
        if (!v2238_10.empty()) {
          const Path v2240_6 = concat_path(v2237_6,v2237_11_head);
          const Space v2240_11 = routine_237(c, v2240_6, p1, p2, v2237_11_tail);
          v2238_12 = compose(v2238_10,v2240_11);
        }
        const Space v2238_13 = unite(v2238_8,v2238_12);
        v2237_11_result = unite(v2237_11_result,v2238_13);
      }
      const Space v2237_11 = std::move(v2237_11_result);
      v2232_12 = compose(v2232_10,v2237_11);
    }
    const Space v2232_13 = unite(v2232_8,v2232_12);
    v2231_13_result = unite(v2231_13_result,v2232_13);
  }
  const Space v2231_13 = std::move(v2231_13_result);
  return v2231_13;
}

static Space routine_272(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2241_9 = concat_path(constant_23,p2);
  const Space v2241_10 = singleton(v2241_9);
  const Space v2241_11 = unite(constant_26,v2241_10);
  const Path v2241_13 = concat_path(constant_22,p1);
  const Space v2241_14 = singleton(v2241_13);
  const Space v2241_15 = unite(v2241_11,v2241_14);
  Space v2241_20_result;
  for (int v2241_20_label = 1; v2241_20_label <= 2; ++v2241_20_label) {
    const Space v2241_20_tail = child(s0,v2241_20_label);
    if (v2241_20_tail.empty()) continue;
    const Path v2241_20_head{v2241_20_label};
    const Space v2242_2 = singleton(v2241_20_head);
    const Space v2242_3 = intersect(constant_8,v2242_2);
    const Space v2242_4 = (has_head(v2242_3) ? constant_9 : Space{});
    const Space v2242_5 = subtract(constant_0,v2242_4);
    Space v2242_8;
    if (!v2242_5.empty()) {
      const Path v2243_6 = concat_path(p0,v2241_20_head);
      Space v2243_7_result;
      for (int v2243_7_label = 1; v2243_7_label <= 2; ++v2243_7_label) {
        const Space v2243_7_tail = child(v2241_20_tail,v2243_7_label);
        if (v2243_7_tail.empty()) continue;
        const Path v2243_7_head{v2243_7_label};
        const Space v2244_2 = singleton(v2243_7_head);
        const Space v2244_3 = intersect(constant_8,v2244_2);
        const Space v2244_4 = (has_head(v2244_3) ? constant_9 : Space{});
        const Space v2244_5 = subtract(constant_0,v2244_4);
        Space v2244_8;
        if (!v2244_5.empty()) {
          const Path v2245_6 = concat_path(v2243_6,v2243_7_head);
          const Space v2245_7 = routine_311(c, v2245_6, p1, p2, v2243_7_tail);
          v2244_8 = compose(v2244_5,v2245_7);
        }
        const Space v2244_9 = intersect(constant_8,v2244_2);
        const Space v2244_10 = (has_head(v2244_9) ? constant_9 : Space{});
        Space v2244_12;
        if (!v2244_10.empty()) {
          const Path v2246_6 = concat_path(v2243_6,v2243_7_head);
          const Space v2246_11 = routine_312(c, v2246_6, p1, p2, v2243_7_tail);
          v2244_12 = compose(v2244_10,v2246_11);
        }
        const Space v2244_13 = unite(v2244_8,v2244_12);
        v2243_7_result = unite(v2243_7_result,v2244_13);
      }
      const Space v2243_7 = std::move(v2243_7_result);
      v2242_8 = compose(v2242_5,v2243_7);
    }
    const Space v2242_9 = intersect(constant_8,v2242_2);
    const Space v2242_10 = (has_head(v2242_9) ? constant_9 : Space{});
    const Path v2247_6 = concat_path(p0,v2241_20_head);
    const Path v2242_11 = concat_path(constant_6,v2247_6);
    const Space v2242_12 = singleton(v2242_11);
    const Space v2242_13 = unite(v2241_15,v2242_12);
    const Space v2242_14 = compose(v2242_10,v2242_13);
    const Space v2242_15 = unite(v2242_8,v2242_14);
    v2241_20_result = unite(v2241_20_result,v2242_15);
  }
  const Space v2241_20 = std::move(v2241_20_result);
  return v2241_20;
}

static Space routine_273(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2248_3_result;
  for (int v2248_3_label = 1; v2248_3_label <= 2; ++v2248_3_label) {
    const Space v2248_3_tail = child(s0,v2248_3_label);
    if (v2248_3_tail.empty()) continue;
    const Path v2248_3_head{v2248_3_label};
    const Space v2249_2 = Space{};
    v2248_3_result = unite(v2248_3_result,v2249_2);
  }
  const Space v2248_3 = std::move(v2248_3_result);
  return v2248_3;
}

static Space routine_274(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2250_7_result;
  for (int v2250_7_label = 1; v2250_7_label <= 2; ++v2250_7_label) {
    const Space v2250_7_tail = child(s0,v2250_7_label);
    if (v2250_7_tail.empty()) continue;
    const Path v2250_7_head{v2250_7_label};
    const Space v2251_2 = singleton(v2250_7_head);
    const Space v2251_3 = intersect(constant_8,v2251_2);
    const Space v2251_4 = (has_head(v2251_3) ? constant_9 : Space{});
    Space v2251_7;
    if (!v2251_4.empty()) {
      const Path v2252_5 = concat_path(p0,v2250_7_head);
      Space v2252_6_result;
      for (int v2252_6_label = 1; v2252_6_label <= 2; ++v2252_6_label) {
        const Space v2252_6_tail = child(v2250_7_tail,v2252_6_label);
        if (v2252_6_tail.empty()) continue;
        const Path v2252_6_head{v2252_6_label};
        const Space v2253_2 = singleton(v2252_6_head);
        const Space v2253_3 = intersect(constant_8,v2253_2);
        const Space v2253_4 = (has_head(v2253_3) ? constant_9 : Space{});
        const Space v2253_5 = subtract(constant_0,v2253_4);
        Space v2253_7;
        if (!v2253_5.empty()) {
          const Space v2254_6 = routine_201(c, v2252_6_head, p1, v2252_5, v2252_6_tail);
          v2253_7 = compose(v2253_5,v2254_6);
        }
        const Space v2253_8 = intersect(constant_8,v2253_2);
        const Space v2253_9 = (has_head(v2253_8) ? constant_9 : Space{});
        Space v2253_11;
        if (!v2253_9.empty()) {
          const Space v2255_10 = routine_202(c, v2252_6_head, p1, v2252_5, v2252_6_tail);
          v2253_11 = compose(v2253_9,v2255_10);
        }
        const Space v2253_12 = unite(v2253_7,v2253_11);
        v2252_6_result = unite(v2252_6_result,v2253_12);
      }
      const Space v2252_6 = std::move(v2252_6_result);
      v2251_7 = compose(v2251_4,v2252_6);
    }
    v2250_7_result = unite(v2250_7_result,v2251_7);
  }
  const Space v2250_7 = std::move(v2250_7_result);
  return v2250_7;
}

static Space routine_275(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2256_13_result;
  for (int v2256_13_label = 1; v2256_13_label <= 2; ++v2256_13_label) {
    const Space v2256_13_tail = child(s0,v2256_13_label);
    if (v2256_13_tail.empty()) continue;
    const Path v2256_13_head{v2256_13_label};
    const Space v2257_2 = singleton(v2256_13_head);
    const Space v2257_3 = intersect(constant_8,v2257_2);
    const Space v2257_4 = (has_head(v2257_3) ? constant_9 : Space{});
    const Space v2257_5 = subtract(constant_0,v2257_4);
    Space v2257_8;
    if (!v2257_5.empty()) {
      const Path v2258_6 = concat_path(p0,v2256_13_head);
      Space v2258_7_result;
      for (int v2258_7_label = 1; v2258_7_label <= 2; ++v2258_7_label) {
        const Space v2258_7_tail = child(v2256_13_tail,v2258_7_label);
        if (v2258_7_tail.empty()) continue;
        const Path v2258_7_head{v2258_7_label};
        const Space v2259_2 = singleton(v2258_7_head);
        const Space v2259_3 = intersect(constant_8,v2259_2);
        const Space v2259_4 = (has_head(v2259_3) ? constant_9 : Space{});
        const Space v2259_5 = subtract(constant_0,v2259_4);
        Space v2259_8;
        if (!v2259_5.empty()) {
          const Path v2260_6 = concat_path(v2258_6,v2258_7_head);
          const Space v2260_7 = routine_313(c, v2260_6, p1, p2, v2258_7_tail);
          v2259_8 = compose(v2259_5,v2260_7);
        }
        const Space v2259_9 = intersect(constant_8,v2259_2);
        const Space v2259_10 = (has_head(v2259_9) ? constant_9 : Space{});
        Space v2259_12;
        if (!v2259_10.empty()) {
          const Path v2261_6 = concat_path(v2258_6,v2258_7_head);
          const Space v2261_11 = routine_314(c, v2261_6, p1, p2, v2258_7_tail);
          v2259_12 = compose(v2259_10,v2261_11);
        }
        const Space v2259_13 = unite(v2259_8,v2259_12);
        v2258_7_result = unite(v2258_7_result,v2259_13);
      }
      const Space v2258_7 = std::move(v2258_7_result);
      v2257_8 = compose(v2257_5,v2258_7);
    }
    const Space v2257_9 = intersect(constant_8,v2257_2);
    const Space v2257_10 = (has_head(v2257_9) ? constant_9 : Space{});
    Space v2257_12;
    if (!v2257_10.empty()) {
      const Path v2262_6 = concat_path(p0,v2256_13_head);
      Space v2262_11_result;
      for (int v2262_11_label = 1; v2262_11_label <= 2; ++v2262_11_label) {
        const Space v2262_11_tail = child(v2256_13_tail,v2262_11_label);
        if (v2262_11_tail.empty()) continue;
        const Path v2262_11_head{v2262_11_label};
        const Space v2263_2 = singleton(v2262_11_head);
        const Space v2263_3 = intersect(constant_8,v2263_2);
        const Space v2263_4 = (has_head(v2263_3) ? constant_9 : Space{});
        const Space v2263_5 = subtract(constant_0,v2263_4);
        Space v2263_8;
        if (!v2263_5.empty()) {
          const Path v2264_6 = concat_path(v2262_6,v2262_11_head);
          const Space v2264_7 = routine_313(c, v2264_6, p1, p2, v2262_11_tail);
          v2263_8 = compose(v2263_5,v2264_7);
        }
        const Space v2263_9 = intersect(constant_8,v2263_2);
        const Space v2263_10 = (has_head(v2263_9) ? constant_9 : Space{});
        Space v2263_12;
        if (!v2263_10.empty()) {
          const Path v2265_6 = concat_path(v2262_6,v2262_11_head);
          const Space v2265_11 = routine_242(c, v2265_6, p1, p2, v2262_11_tail);
          v2263_12 = compose(v2263_10,v2265_11);
        }
        const Space v2263_13 = unite(v2263_8,v2263_12);
        v2262_11_result = unite(v2262_11_result,v2263_13);
      }
      const Space v2262_11 = std::move(v2262_11_result);
      v2257_12 = compose(v2257_10,v2262_11);
    }
    const Space v2257_13 = unite(v2257_8,v2257_12);
    v2256_13_result = unite(v2256_13_result,v2257_13);
  }
  const Space v2256_13 = std::move(v2256_13_result);
  return v2256_13;
}

static Space routine_276(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2266_10 = concat_path(constant_22,p1);
  const Space v2266_11 = singleton(v2266_10);
  const Path v2266_13 = concat_path(constant_6,p2);
  const Space v2266_14 = singleton(v2266_13);
  Space v2266_18_result;
  for (int v2266_18_label = 1; v2266_18_label <= 2; ++v2266_18_label) {
    const Space v2266_18_tail = child(s0,v2266_18_label);
    if (v2266_18_tail.empty()) continue;
    const Path v2266_18_head{v2266_18_label};
    const Space v2267_2 = singleton(v2266_18_head);
    const Space v2267_3 = intersect(constant_8,v2267_2);
    const Space v2267_4 = (has_head(v2267_3) ? constant_9 : Space{});
    const Space v2267_5 = subtract(constant_0,v2267_4);
    Space v2267_8;
    if (!v2267_5.empty()) {
      const Path v2268_6 = concat_path(p0,v2266_18_head);
      Space v2268_7_result;
      for (int v2268_7_label = 1; v2268_7_label <= 2; ++v2268_7_label) {
        const Space v2268_7_tail = child(v2266_18_tail,v2268_7_label);
        if (v2268_7_tail.empty()) continue;
        const Path v2268_7_head{v2268_7_label};
        const Space v2269_2 = singleton(v2268_7_head);
        const Space v2269_3 = intersect(constant_8,v2269_2);
        const Space v2269_4 = (has_head(v2269_3) ? constant_9 : Space{});
        const Space v2269_5 = subtract(constant_0,v2269_4);
        Space v2269_8;
        if (!v2269_5.empty()) {
          const Path v2270_6 = concat_path(v2268_6,v2268_7_head);
          const Space v2270_7 = routine_313(c, v2270_6, p1, p2, v2268_7_tail);
          v2269_8 = compose(v2269_5,v2270_7);
        }
        const Space v2269_9 = intersect(constant_8,v2269_2);
        const Space v2269_10 = (has_head(v2269_9) ? constant_9 : Space{});
        Space v2269_12;
        if (!v2269_10.empty()) {
          const Path v2271_6 = concat_path(v2268_6,v2268_7_head);
          const Space v2271_11 = routine_314(c, v2271_6, p1, p2, v2268_7_tail);
          v2269_12 = compose(v2269_10,v2271_11);
        }
        const Space v2269_13 = unite(v2269_8,v2269_12);
        v2268_7_result = unite(v2268_7_result,v2269_13);
      }
      const Space v2268_7 = std::move(v2268_7_result);
      v2267_8 = compose(v2267_5,v2268_7);
    }
    const Space v2267_9 = intersect(constant_8,v2267_2);
    const Space v2267_10 = (has_head(v2267_9) ? constant_9 : Space{});
    const Path v2272_6 = concat_path(p0,v2266_18_head);
    const Path v2267_11 = concat_path(constant_24,v2272_6);
    const Space v2267_12 = singleton(v2267_11);
    const Space v2267_13 = unite(constant_27,v2267_12);
    const Space v2267_14 = unite(v2267_13,v2266_11);
    const Space v2267_15 = unite(v2267_14,v2266_14);
    const Space v2267_16 = compose(v2267_10,v2267_15);
    const Space v2267_17 = unite(v2267_8,v2267_16);
    v2266_18_result = unite(v2266_18_result,v2267_17);
  }
  const Space v2266_18 = std::move(v2266_18_result);
  return v2266_18;
}

static Space routine_277(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2273_3_result;
  for (int v2273_3_label = 1; v2273_3_label <= 2; ++v2273_3_label) {
    const Space v2273_3_tail = child(s0,v2273_3_label);
    if (v2273_3_tail.empty()) continue;
    const Path v2273_3_head{v2273_3_label};
    const Space v2274_2 = Space{};
    v2273_3_result = unite(v2273_3_result,v2274_2);
  }
  const Space v2273_3 = std::move(v2273_3_result);
  return v2273_3;
}

static Space routine_278(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2275_7_result;
  for (int v2275_7_label = 1; v2275_7_label <= 2; ++v2275_7_label) {
    const Space v2275_7_tail = child(s0,v2275_7_label);
    if (v2275_7_tail.empty()) continue;
    const Path v2275_7_head{v2275_7_label};
    const Space v2276_2 = singleton(v2275_7_head);
    const Space v2276_3 = intersect(constant_8,v2276_2);
    const Space v2276_4 = (has_head(v2276_3) ? constant_9 : Space{});
    Space v2276_7;
    if (!v2276_4.empty()) {
      const Path v2277_5 = concat_path(p0,v2275_7_head);
      Space v2277_6_result;
      for (int v2277_6_label = 1; v2277_6_label <= 2; ++v2277_6_label) {
        const Space v2277_6_tail = child(v2275_7_tail,v2277_6_label);
        if (v2277_6_tail.empty()) continue;
        const Path v2277_6_head{v2277_6_label};
        const Space v2278_2 = singleton(v2277_6_head);
        const Space v2278_3 = intersect(constant_8,v2278_2);
        const Space v2278_4 = (has_head(v2278_3) ? constant_9 : Space{});
        const Space v2278_5 = subtract(constant_0,v2278_4);
        Space v2278_7;
        if (!v2278_5.empty()) {
          const Space v2279_6 = routine_209(c, v2277_6_head, p1, v2277_5, v2277_6_tail);
          v2278_7 = compose(v2278_5,v2279_6);
        }
        const Space v2278_8 = intersect(constant_8,v2278_2);
        const Space v2278_9 = (has_head(v2278_8) ? constant_9 : Space{});
        Space v2278_11;
        if (!v2278_9.empty()) {
          const Space v2280_10 = routine_210(c, v2277_6_head, p1, v2277_5, v2277_6_tail);
          v2278_11 = compose(v2278_9,v2280_10);
        }
        const Space v2278_12 = unite(v2278_7,v2278_11);
        v2277_6_result = unite(v2277_6_result,v2278_12);
      }
      const Space v2277_6 = std::move(v2277_6_result);
      v2276_7 = compose(v2276_4,v2277_6);
    }
    v2275_7_result = unite(v2275_7_result,v2276_7);
  }
  const Space v2275_7 = std::move(v2275_7_result);
  return v2275_7;
}

static Space routine_279(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2281_13_result;
  for (int v2281_13_label = 1; v2281_13_label <= 2; ++v2281_13_label) {
    const Space v2281_13_tail = child(s0,v2281_13_label);
    if (v2281_13_tail.empty()) continue;
    const Path v2281_13_head{v2281_13_label};
    const Space v2282_2 = singleton(v2281_13_head);
    const Space v2282_3 = intersect(constant_8,v2282_2);
    const Space v2282_4 = (has_head(v2282_3) ? constant_9 : Space{});
    const Space v2282_5 = subtract(constant_0,v2282_4);
    Space v2282_8;
    if (!v2282_5.empty()) {
      const Path v2283_6 = concat_path(p0,v2281_13_head);
      Space v2283_7_result;
      for (int v2283_7_label = 1; v2283_7_label <= 2; ++v2283_7_label) {
        const Space v2283_7_tail = child(v2281_13_tail,v2283_7_label);
        if (v2283_7_tail.empty()) continue;
        const Path v2283_7_head{v2283_7_label};
        const Space v2284_2 = singleton(v2283_7_head);
        const Space v2284_3 = intersect(constant_8,v2284_2);
        const Space v2284_4 = (has_head(v2284_3) ? constant_9 : Space{});
        const Space v2284_5 = subtract(constant_0,v2284_4);
        Space v2284_8;
        if (!v2284_5.empty()) {
          const Path v2285_6 = concat_path(v2283_6,v2283_7_head);
          const Space v2285_7 = routine_315(c, v2285_6, p1, p2, v2283_7_tail);
          v2284_8 = compose(v2284_5,v2285_7);
        }
        const Space v2284_9 = intersect(constant_8,v2284_2);
        const Space v2284_10 = (has_head(v2284_9) ? constant_9 : Space{});
        Space v2284_12;
        if (!v2284_10.empty()) {
          const Path v2286_6 = concat_path(v2283_6,v2283_7_head);
          const Space v2286_11 = routine_316(c, v2286_6, p1, p2, v2283_7_tail);
          v2284_12 = compose(v2284_10,v2286_11);
        }
        const Space v2284_13 = unite(v2284_8,v2284_12);
        v2283_7_result = unite(v2283_7_result,v2284_13);
      }
      const Space v2283_7 = std::move(v2283_7_result);
      v2282_8 = compose(v2282_5,v2283_7);
    }
    const Space v2282_9 = intersect(constant_8,v2282_2);
    const Space v2282_10 = (has_head(v2282_9) ? constant_9 : Space{});
    Space v2282_12;
    if (!v2282_10.empty()) {
      const Path v2287_6 = concat_path(p0,v2281_13_head);
      Space v2287_11_result;
      for (int v2287_11_label = 1; v2287_11_label <= 2; ++v2287_11_label) {
        const Space v2287_11_tail = child(v2281_13_tail,v2287_11_label);
        if (v2287_11_tail.empty()) continue;
        const Path v2287_11_head{v2287_11_label};
        const Space v2288_2 = singleton(v2287_11_head);
        const Space v2288_3 = intersect(constant_8,v2288_2);
        const Space v2288_4 = (has_head(v2288_3) ? constant_9 : Space{});
        const Space v2288_5 = subtract(constant_0,v2288_4);
        Space v2288_8;
        if (!v2288_5.empty()) {
          const Path v2289_6 = concat_path(v2287_6,v2287_11_head);
          const Space v2289_7 = routine_315(c, v2289_6, p1, p2, v2287_11_tail);
          v2288_8 = compose(v2288_5,v2289_7);
        }
        const Space v2288_9 = intersect(constant_8,v2288_2);
        const Space v2288_10 = (has_head(v2288_9) ? constant_9 : Space{});
        Space v2288_12;
        if (!v2288_10.empty()) {
          const Path v2290_6 = concat_path(v2287_6,v2287_11_head);
          const Space v2290_11 = routine_247(c, v2290_6, p1, p2, v2287_11_tail);
          v2288_12 = compose(v2288_10,v2290_11);
        }
        const Space v2288_13 = unite(v2288_8,v2288_12);
        v2287_11_result = unite(v2287_11_result,v2288_13);
      }
      const Space v2287_11 = std::move(v2287_11_result);
      v2282_12 = compose(v2282_10,v2287_11);
    }
    const Space v2282_13 = unite(v2282_8,v2282_12);
    v2281_13_result = unite(v2281_13_result,v2282_13);
  }
  const Space v2281_13 = std::move(v2281_13_result);
  return v2281_13;
}

static Space routine_280(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2291_10 = concat_path(constant_23,p1);
  const Space v2291_11 = singleton(v2291_10);
  const Path v2291_13 = concat_path(constant_6,p2);
  const Space v2291_14 = singleton(v2291_13);
  Space v2291_18_result;
  for (int v2291_18_label = 1; v2291_18_label <= 2; ++v2291_18_label) {
    const Space v2291_18_tail = child(s0,v2291_18_label);
    if (v2291_18_tail.empty()) continue;
    const Path v2291_18_head{v2291_18_label};
    const Space v2292_2 = singleton(v2291_18_head);
    const Space v2292_3 = intersect(constant_8,v2292_2);
    const Space v2292_4 = (has_head(v2292_3) ? constant_9 : Space{});
    const Space v2292_5 = subtract(constant_0,v2292_4);
    Space v2292_8;
    if (!v2292_5.empty()) {
      const Path v2293_6 = concat_path(p0,v2291_18_head);
      Space v2293_7_result;
      for (int v2293_7_label = 1; v2293_7_label <= 2; ++v2293_7_label) {
        const Space v2293_7_tail = child(v2291_18_tail,v2293_7_label);
        if (v2293_7_tail.empty()) continue;
        const Path v2293_7_head{v2293_7_label};
        const Space v2294_2 = singleton(v2293_7_head);
        const Space v2294_3 = intersect(constant_8,v2294_2);
        const Space v2294_4 = (has_head(v2294_3) ? constant_9 : Space{});
        const Space v2294_5 = subtract(constant_0,v2294_4);
        Space v2294_8;
        if (!v2294_5.empty()) {
          const Path v2295_6 = concat_path(v2293_6,v2293_7_head);
          const Space v2295_7 = routine_315(c, v2295_6, p1, p2, v2293_7_tail);
          v2294_8 = compose(v2294_5,v2295_7);
        }
        const Space v2294_9 = intersect(constant_8,v2294_2);
        const Space v2294_10 = (has_head(v2294_9) ? constant_9 : Space{});
        Space v2294_12;
        if (!v2294_10.empty()) {
          const Path v2296_6 = concat_path(v2293_6,v2293_7_head);
          const Space v2296_11 = routine_316(c, v2296_6, p1, p2, v2293_7_tail);
          v2294_12 = compose(v2294_10,v2296_11);
        }
        const Space v2294_13 = unite(v2294_8,v2294_12);
        v2293_7_result = unite(v2293_7_result,v2294_13);
      }
      const Space v2293_7 = std::move(v2293_7_result);
      v2292_8 = compose(v2292_5,v2293_7);
    }
    const Space v2292_9 = intersect(constant_8,v2292_2);
    const Space v2292_10 = (has_head(v2292_9) ? constant_9 : Space{});
    const Path v2297_6 = concat_path(p0,v2291_18_head);
    const Path v2292_11 = concat_path(constant_24,v2297_6);
    const Space v2292_12 = singleton(v2292_11);
    const Space v2292_13 = unite(constant_28,v2292_12);
    const Space v2292_14 = unite(v2292_13,v2291_11);
    const Space v2292_15 = unite(v2292_14,v2291_14);
    const Space v2292_16 = compose(v2292_10,v2292_15);
    const Space v2292_17 = unite(v2292_8,v2292_16);
    v2291_18_result = unite(v2291_18_result,v2292_17);
  }
  const Space v2291_18 = std::move(v2291_18_result);
  return v2291_18;
}

static Space routine_281(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2298_3_result;
  for (int v2298_3_label = 1; v2298_3_label <= 2; ++v2298_3_label) {
    const Space v2298_3_tail = child(s0,v2298_3_label);
    if (v2298_3_tail.empty()) continue;
    const Path v2298_3_head{v2298_3_label};
    const Space v2299_2 = Space{};
    v2298_3_result = unite(v2298_3_result,v2299_2);
  }
  const Space v2298_3 = std::move(v2298_3_result);
  return v2298_3;
}

static Space routine_282(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2300_7_result;
  for (int v2300_7_label = 1; v2300_7_label <= 2; ++v2300_7_label) {
    const Space v2300_7_tail = child(s0,v2300_7_label);
    if (v2300_7_tail.empty()) continue;
    const Path v2300_7_head{v2300_7_label};
    const Space v2301_2 = singleton(v2300_7_head);
    const Space v2301_3 = intersect(constant_8,v2301_2);
    const Space v2301_4 = (has_head(v2301_3) ? constant_9 : Space{});
    Space v2301_7;
    if (!v2301_4.empty()) {
      const Path v2302_5 = concat_path(p0,v2300_7_head);
      Space v2302_6_result;
      for (int v2302_6_label = 1; v2302_6_label <= 2; ++v2302_6_label) {
        const Space v2302_6_tail = child(v2300_7_tail,v2302_6_label);
        if (v2302_6_tail.empty()) continue;
        const Path v2302_6_head{v2302_6_label};
        const Space v2303_2 = singleton(v2302_6_head);
        const Space v2303_3 = intersect(constant_8,v2303_2);
        const Space v2303_4 = (has_head(v2303_3) ? constant_9 : Space{});
        const Space v2303_5 = subtract(constant_0,v2303_4);
        Space v2303_7;
        if (!v2303_5.empty()) {
          const Space v2304_6 = routine_217(c, v2302_6_head, p1, v2302_5, v2302_6_tail);
          v2303_7 = compose(v2303_5,v2304_6);
        }
        const Space v2303_8 = intersect(constant_8,v2303_2);
        const Space v2303_9 = (has_head(v2303_8) ? constant_9 : Space{});
        Space v2303_11;
        if (!v2303_9.empty()) {
          const Space v2305_10 = routine_218(c, v2302_6_head, p1, v2302_5, v2302_6_tail);
          v2303_11 = compose(v2303_9,v2305_10);
        }
        const Space v2303_12 = unite(v2303_7,v2303_11);
        v2302_6_result = unite(v2302_6_result,v2303_12);
      }
      const Space v2302_6 = std::move(v2302_6_result);
      v2301_7 = compose(v2301_4,v2302_6);
    }
    v2300_7_result = unite(v2300_7_result,v2301_7);
  }
  const Space v2300_7 = std::move(v2300_7_result);
  return v2300_7;
}

static Space routine_283(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2306_13_result;
  for (int v2306_13_label = 1; v2306_13_label <= 2; ++v2306_13_label) {
    const Space v2306_13_tail = child(s0,v2306_13_label);
    if (v2306_13_tail.empty()) continue;
    const Path v2306_13_head{v2306_13_label};
    const Space v2307_2 = singleton(v2306_13_head);
    const Space v2307_3 = intersect(constant_8,v2307_2);
    const Space v2307_4 = (has_head(v2307_3) ? constant_9 : Space{});
    const Space v2307_5 = subtract(constant_0,v2307_4);
    Space v2307_8;
    if (!v2307_5.empty()) {
      const Path v2308_6 = concat_path(p0,v2306_13_head);
      Space v2308_7_result;
      for (int v2308_7_label = 1; v2308_7_label <= 2; ++v2308_7_label) {
        const Space v2308_7_tail = child(v2306_13_tail,v2308_7_label);
        if (v2308_7_tail.empty()) continue;
        const Path v2308_7_head{v2308_7_label};
        const Space v2309_2 = singleton(v2308_7_head);
        const Space v2309_3 = intersect(constant_8,v2309_2);
        const Space v2309_4 = (has_head(v2309_3) ? constant_9 : Space{});
        const Space v2309_5 = subtract(constant_0,v2309_4);
        Space v2309_8;
        if (!v2309_5.empty()) {
          const Path v2310_6 = concat_path(v2308_6,v2308_7_head);
          const Space v2310_7 = routine_317(c, v2310_6, p1, p2, v2308_7_tail);
          v2309_8 = compose(v2309_5,v2310_7);
        }
        const Space v2309_9 = intersect(constant_8,v2309_2);
        const Space v2309_10 = (has_head(v2309_9) ? constant_9 : Space{});
        Space v2309_12;
        if (!v2309_10.empty()) {
          const Path v2311_6 = concat_path(v2308_6,v2308_7_head);
          const Space v2311_11 = routine_318(c, v2311_6, p1, p2, v2308_7_tail);
          v2309_12 = compose(v2309_10,v2311_11);
        }
        const Space v2309_13 = unite(v2309_8,v2309_12);
        v2308_7_result = unite(v2308_7_result,v2309_13);
      }
      const Space v2308_7 = std::move(v2308_7_result);
      v2307_8 = compose(v2307_5,v2308_7);
    }
    const Space v2307_9 = intersect(constant_8,v2307_2);
    const Space v2307_10 = (has_head(v2307_9) ? constant_9 : Space{});
    Space v2307_12;
    if (!v2307_10.empty()) {
      const Path v2312_6 = concat_path(p0,v2306_13_head);
      Space v2312_11_result;
      for (int v2312_11_label = 1; v2312_11_label <= 2; ++v2312_11_label) {
        const Space v2312_11_tail = child(v2306_13_tail,v2312_11_label);
        if (v2312_11_tail.empty()) continue;
        const Path v2312_11_head{v2312_11_label};
        const Space v2313_2 = singleton(v2312_11_head);
        const Space v2313_3 = intersect(constant_8,v2313_2);
        const Space v2313_4 = (has_head(v2313_3) ? constant_9 : Space{});
        const Space v2313_5 = subtract(constant_0,v2313_4);
        Space v2313_8;
        if (!v2313_5.empty()) {
          const Path v2314_6 = concat_path(v2312_6,v2312_11_head);
          const Space v2314_7 = routine_317(c, v2314_6, p1, p2, v2312_11_tail);
          v2313_8 = compose(v2313_5,v2314_7);
        }
        const Space v2313_9 = intersect(constant_8,v2313_2);
        const Space v2313_10 = (has_head(v2313_9) ? constant_9 : Space{});
        Space v2313_12;
        if (!v2313_10.empty()) {
          const Path v2315_6 = concat_path(v2312_6,v2312_11_head);
          const Space v2315_11 = routine_252(c, v2315_6, p1, p2, v2312_11_tail);
          v2313_12 = compose(v2313_10,v2315_11);
        }
        const Space v2313_13 = unite(v2313_8,v2313_12);
        v2312_11_result = unite(v2312_11_result,v2313_13);
      }
      const Space v2312_11 = std::move(v2312_11_result);
      v2307_12 = compose(v2307_10,v2312_11);
    }
    const Space v2307_13 = unite(v2307_8,v2307_12);
    v2306_13_result = unite(v2306_13_result,v2307_13);
  }
  const Space v2306_13 = std::move(v2306_13_result);
  return v2306_13;
}

static Space routine_284(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2316_10 = concat_path(constant_23,p2);
  const Space v2316_11 = singleton(v2316_10);
  const Path v2316_13 = concat_path(constant_22,p1);
  const Space v2316_14 = singleton(v2316_13);
  Space v2316_18_result;
  for (int v2316_18_label = 1; v2316_18_label <= 2; ++v2316_18_label) {
    const Space v2316_18_tail = child(s0,v2316_18_label);
    if (v2316_18_tail.empty()) continue;
    const Path v2316_18_head{v2316_18_label};
    const Space v2317_2 = singleton(v2316_18_head);
    const Space v2317_3 = intersect(constant_8,v2317_2);
    const Space v2317_4 = (has_head(v2317_3) ? constant_9 : Space{});
    const Space v2317_5 = subtract(constant_0,v2317_4);
    Space v2317_8;
    if (!v2317_5.empty()) {
      const Path v2318_6 = concat_path(p0,v2316_18_head);
      Space v2318_7_result;
      for (int v2318_7_label = 1; v2318_7_label <= 2; ++v2318_7_label) {
        const Space v2318_7_tail = child(v2316_18_tail,v2318_7_label);
        if (v2318_7_tail.empty()) continue;
        const Path v2318_7_head{v2318_7_label};
        const Space v2319_2 = singleton(v2318_7_head);
        const Space v2319_3 = intersect(constant_8,v2319_2);
        const Space v2319_4 = (has_head(v2319_3) ? constant_9 : Space{});
        const Space v2319_5 = subtract(constant_0,v2319_4);
        Space v2319_8;
        if (!v2319_5.empty()) {
          const Path v2320_6 = concat_path(v2318_6,v2318_7_head);
          const Space v2320_7 = routine_317(c, v2320_6, p1, p2, v2318_7_tail);
          v2319_8 = compose(v2319_5,v2320_7);
        }
        const Space v2319_9 = intersect(constant_8,v2319_2);
        const Space v2319_10 = (has_head(v2319_9) ? constant_9 : Space{});
        Space v2319_12;
        if (!v2319_10.empty()) {
          const Path v2321_6 = concat_path(v2318_6,v2318_7_head);
          const Space v2321_11 = routine_318(c, v2321_6, p1, p2, v2318_7_tail);
          v2319_12 = compose(v2319_10,v2321_11);
        }
        const Space v2319_13 = unite(v2319_8,v2319_12);
        v2318_7_result = unite(v2318_7_result,v2319_13);
      }
      const Space v2318_7 = std::move(v2318_7_result);
      v2317_8 = compose(v2317_5,v2318_7);
    }
    const Space v2317_9 = intersect(constant_8,v2317_2);
    const Space v2317_10 = (has_head(v2317_9) ? constant_9 : Space{});
    const Path v2322_6 = concat_path(p0,v2316_18_head);
    const Path v2317_11 = concat_path(constant_24,v2322_6);
    const Space v2317_12 = singleton(v2317_11);
    const Space v2317_13 = unite(constant_29,v2317_12);
    const Space v2317_14 = unite(v2317_13,v2316_11);
    const Space v2317_15 = unite(v2317_14,v2316_14);
    const Space v2317_16 = compose(v2317_10,v2317_15);
    const Space v2317_17 = unite(v2317_8,v2317_16);
    v2316_18_result = unite(v2316_18_result,v2317_17);
  }
  const Space v2316_18 = std::move(v2316_18_result);
  return v2316_18;
}

static Space routine_285(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2323_7_result;
  for (int v2323_7_label = 1; v2323_7_label <= 2; ++v2323_7_label) {
    const Space v2323_7_tail = child(s0,v2323_7_label);
    if (v2323_7_tail.empty()) continue;
    const Path v2323_7_head{v2323_7_label};
    const Space v2324_2 = singleton(v2323_7_head);
    const Space v2324_3 = intersect(constant_8,v2324_2);
    const Space v2324_4 = (has_head(v2324_3) ? constant_9 : Space{});
    const Space v2324_5 = subtract(constant_0,v2324_4);
    Space v2324_6_result;
    for (int v2324_6_label = 1; v2324_6_label <= 2; ++v2324_6_label) {
      const Space v2324_6_tail = child(v2323_7_tail,v2324_6_label);
      if (v2324_6_tail.empty()) continue;
      const Path v2324_6_head{v2324_6_label};
      const Space v2325_2 = Space{};
      v2324_6_result = unite(v2324_6_result,v2325_2);
    }
    const Space v2324_6 = std::move(v2324_6_result);
    const Space v2324_7 = compose(v2324_5,v2324_6);
    const Space v2324_8 = intersect(constant_8,v2324_2);
    const Space v2324_9 = (has_head(v2324_8) ? constant_9 : Space{});
    Space v2324_12;
    if (!v2324_9.empty()) {
      const Path v2326_10 = concat_path(p0,v2323_7_head);
      Space v2326_11_result;
      for (int v2326_11_label = 1; v2326_11_label <= 2; ++v2326_11_label) {
        const Space v2326_11_tail = child(v2323_7_tail,v2326_11_label);
        if (v2326_11_tail.empty()) continue;
        const Path v2326_11_head{v2326_11_label};
        const Space v2327_2 = singleton(v2326_11_head);
        const Space v2327_3 = intersect(constant_8,v2327_2);
        const Space v2327_4 = (has_head(v2327_3) ? constant_9 : Space{});
        Space v2327_7;
        if (!v2327_4.empty()) {
          const Path v2328_5 = concat_path(v2326_10,v2326_11_head);
          const Space v2328_6 = routine_223(c, v2328_5, p1, v2326_11_tail);
          v2327_7 = compose(v2327_4,v2328_6);
        }
        v2326_11_result = unite(v2326_11_result,v2327_7);
      }
      const Space v2326_11 = std::move(v2326_11_result);
      v2324_12 = compose(v2324_9,v2326_11);
    }
    const Space v2324_13 = unite(v2324_7,v2324_12);
    v2323_7_result = unite(v2323_7_result,v2324_13);
  }
  const Space v2323_7 = std::move(v2323_7_result);
  return v2323_7;
}

static Space routine_286(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2329_10_result;
  for (int v2329_10_label = 1; v2329_10_label <= 2; ++v2329_10_label) {
    const Space v2329_10_tail = child(s0,v2329_10_label);
    if (v2329_10_tail.empty()) continue;
    const Path v2329_10_head{v2329_10_label};
    const Space v2330_2 = singleton(v2329_10_head);
    const Space v2330_3 = intersect(constant_8,v2330_2);
    const Space v2330_4 = (has_head(v2330_3) ? constant_9 : Space{});
    const Space v2330_5 = subtract(constant_0,v2330_4);
    Space v2330_6_result;
    for (int v2330_6_label = 1; v2330_6_label <= 2; ++v2330_6_label) {
      const Space v2330_6_tail = child(v2329_10_tail,v2330_6_label);
      if (v2330_6_tail.empty()) continue;
      const Path v2330_6_head{v2330_6_label};
      const Space v2331_2 = Space{};
      v2330_6_result = unite(v2330_6_result,v2331_2);
    }
    const Space v2330_6 = std::move(v2330_6_result);
    const Space v2330_7 = compose(v2330_5,v2330_6);
    const Space v2330_8 = intersect(constant_8,v2330_2);
    const Space v2330_9 = (has_head(v2330_8) ? constant_9 : Space{});
    Space v2330_13;
    if (!v2330_9.empty()) {
      Space v2332_10_result;
      for (int v2332_10_label = 1; v2332_10_label <= 2; ++v2332_10_label) {
        const Space v2332_10_tail = child(v2329_10_tail,v2332_10_label);
        if (v2332_10_tail.empty()) continue;
        const Path v2332_10_head{v2332_10_label};
        const Space v2333_2 = singleton(v2332_10_head);
        const Space v2333_3 = intersect(constant_8,v2333_2);
        const Space v2333_4 = (has_head(v2333_3) ? constant_9 : Space{});
        const Space v2333_5 = subtract(constant_0,v2333_4);
        Space v2333_7;
        if (!v2333_5.empty()) {
          const Space v2334_6 = routine_257(c, v2332_10_head, v2332_10_tail);
          v2333_7 = compose(v2333_5,v2334_6);
        }
        const Space v2333_8 = intersect(constant_8,v2333_2);
        const Space v2333_9 = (has_head(v2333_8) ? constant_9 : Space{});
        Space v2333_11;
        if (!v2333_9.empty()) {
          const Space v2335_10 = routine_258(c, v2332_10_head, v2332_10_tail);
          v2333_11 = compose(v2333_9,v2335_10);
        }
        const Space v2333_12 = unite(v2333_7,v2333_11);
        v2332_10_result = unite(v2332_10_result,v2333_12);
      }
      const Space v2332_10 = std::move(v2332_10_result);
      const Space v2332_11 = raffine(constant_25,v2332_10);
      const Space v2332_12 = unite(v2332_11,v2329_10_tail);
      v2330_13 = compose(v2330_9,v2332_12);
    }
    const Path v2330_14 = concat_path(p0,v2329_10_head);
    const Path v2330_15 = concat_path(p1,v2330_14);
    const Space v2330_16 = wrap(v2330_13,v2330_15);
    const Space v2330_17 = unite(v2330_7,v2330_16);
    v2329_10_result = unite(v2329_10_result,v2330_17);
  }
  const Space v2329_10 = std::move(v2329_10_result);
  return v2329_10;
}

static Space routine_287(Context& c, const Path& p0, const Space& s0) {
  Space v2336_11_result;
  for (int v2336_11_label = 1; v2336_11_label <= 2; ++v2336_11_label) {
    const Space v2336_11_tail = child(s0,v2336_11_label);
    if (v2336_11_tail.empty()) continue;
    const Path v2336_11_head{v2336_11_label};
    const Space v2337_2 = singleton(v2336_11_head);
    const Space v2337_3 = intersect(constant_8,v2337_2);
    const Space v2337_4 = (has_head(v2337_3) ? constant_9 : Space{});
    const Space v2337_5 = subtract(constant_0,v2337_4);
    Space v2337_8;
    if (!v2337_5.empty()) {
      const Path v2338_6 = concat_path(p0,v2336_11_head);
      Space v2338_7_result;
      for (int v2338_7_label = 1; v2338_7_label <= 2; ++v2338_7_label) {
        const Space v2338_7_tail = child(v2336_11_tail,v2338_7_label);
        if (v2338_7_tail.empty()) continue;
        const Path v2338_7_head{v2338_7_label};
        const Space v2339_2 = singleton(v2338_7_head);
        const Space v2339_3 = intersect(constant_8,v2339_2);
        const Space v2339_4 = (has_head(v2339_3) ? constant_9 : Space{});
        const Space v2339_5 = subtract(constant_0,v2339_4);
        Space v2339_8;
        if (!v2339_5.empty()) {
          const Path v2340_6 = concat_path(v2338_6,v2338_7_head);
          const Space v2340_7 = routine_319(c, v2340_6, v2338_7_tail);
          v2339_8 = compose(v2339_5,v2340_7);
        }
        const Space v2339_9 = intersect(constant_8,v2339_2);
        const Space v2339_10 = (has_head(v2339_9) ? constant_9 : Space{});
        Space v2339_12;
        if (!v2339_10.empty()) {
          const Path v2341_6 = concat_path(v2338_6,v2338_7_head);
          const Space v2341_11 = routine_320(c, v2341_6, v2338_7_tail);
          v2339_12 = compose(v2339_10,v2341_11);
        }
        const Space v2339_13 = unite(v2339_8,v2339_12);
        v2338_7_result = unite(v2338_7_result,v2339_13);
      }
      const Space v2338_7 = std::move(v2338_7_result);
      v2337_8 = compose(v2337_5,v2338_7);
    }
    const Space v2337_9 = intersect(constant_8,v2337_2);
    const Space v2337_10 = (has_head(v2337_9) ? constant_9 : Space{});
    Space v2337_12;
    if (!v2337_10.empty()) {
      const Path v2342_6 = concat_path(p0,v2336_11_head);
      Space v2342_11_result;
      for (int v2342_11_label = 1; v2342_11_label <= 2; ++v2342_11_label) {
        const Space v2342_11_tail = child(v2336_11_tail,v2342_11_label);
        if (v2342_11_tail.empty()) continue;
        const Path v2342_11_head{v2342_11_label};
        const Space v2343_2 = singleton(v2342_11_head);
        const Space v2343_3 = intersect(constant_8,v2343_2);
        const Space v2343_4 = (has_head(v2343_3) ? constant_9 : Space{});
        const Space v2343_5 = subtract(constant_0,v2343_4);
        Space v2343_8;
        if (!v2343_5.empty()) {
          const Path v2344_6 = concat_path(v2342_6,v2342_11_head);
          const Space v2344_7 = routine_319(c, v2344_6, v2342_11_tail);
          v2343_8 = compose(v2343_5,v2344_7);
        }
        const Space v2343_9 = intersect(constant_8,v2343_2);
        const Space v2343_10 = (has_head(v2343_9) ? constant_9 : Space{});
        Space v2343_12;
        if (!v2343_10.empty()) {
          const Path v2345_6 = concat_path(v2342_6,v2342_11_head);
          const Space v2345_11 = routine_289(c, v2345_6, v2342_11_tail);
          v2343_12 = compose(v2343_10,v2345_11);
        }
        const Space v2343_13 = unite(v2343_8,v2343_12);
        v2342_11_result = unite(v2342_11_result,v2343_13);
      }
      const Space v2342_11 = std::move(v2342_11_result);
      v2337_12 = compose(v2337_10,v2342_11);
    }
    const Space v2337_13 = unite(v2337_8,v2337_12);
    v2336_11_result = unite(v2336_11_result,v2337_13);
  }
  const Space v2336_11 = std::move(v2336_11_result);
  return v2336_11;
}

static Space routine_288(Context& c, const Path& p0, const Space& s0) {
  Space v2346_8_result;
  for (int v2346_8_label = 1; v2346_8_label <= 2; ++v2346_8_label) {
    const Space v2346_8_tail = child(s0,v2346_8_label);
    if (v2346_8_tail.empty()) continue;
    const Path v2346_8_head{v2346_8_label};
    const Space v2347_2 = singleton(v2346_8_head);
    const Space v2347_3 = intersect(constant_8,v2347_2);
    const Space v2347_4 = (has_head(v2347_3) ? constant_9 : Space{});
    const Space v2347_5 = subtract(constant_0,v2347_4);
    Space v2347_8;
    if (!v2347_5.empty()) {
      const Path v2348_6 = concat_path(p0,v2346_8_head);
      Space v2348_7_result;
      for (int v2348_7_label = 1; v2348_7_label <= 2; ++v2348_7_label) {
        const Space v2348_7_tail = child(v2346_8_tail,v2348_7_label);
        if (v2348_7_tail.empty()) continue;
        const Path v2348_7_head{v2348_7_label};
        const Space v2349_2 = singleton(v2348_7_head);
        const Space v2349_3 = intersect(constant_8,v2349_2);
        const Space v2349_4 = (has_head(v2349_3) ? constant_9 : Space{});
        const Space v2349_5 = subtract(constant_0,v2349_4);
        Space v2349_8;
        if (!v2349_5.empty()) {
          const Path v2350_6 = concat_path(v2348_6,v2348_7_head);
          const Space v2350_7 = routine_319(c, v2350_6, v2348_7_tail);
          v2349_8 = compose(v2349_5,v2350_7);
        }
        const Space v2349_9 = intersect(constant_8,v2349_2);
        const Space v2349_10 = (has_head(v2349_9) ? constant_9 : Space{});
        Space v2349_12;
        if (!v2349_10.empty()) {
          const Path v2351_6 = concat_path(v2348_6,v2348_7_head);
          const Space v2351_11 = routine_320(c, v2351_6, v2348_7_tail);
          v2349_12 = compose(v2349_10,v2351_11);
        }
        const Space v2349_13 = unite(v2349_8,v2349_12);
        v2348_7_result = unite(v2348_7_result,v2349_13);
      }
      const Space v2348_7 = std::move(v2348_7_result);
      v2347_8 = compose(v2347_5,v2348_7);
    }
    const Space v2347_9 = intersect(constant_8,v2347_2);
    const Space v2347_10 = (has_head(v2347_9) ? constant_9 : Space{});
    const Path v2352_6 = concat_path(p0,v2346_8_head);
    const Space v2347_11 = singleton(v2352_6);
    const Space v2347_12 = compose(v2347_10,v2347_11);
    const Space v2347_13 = unite(v2347_8,v2347_12);
    v2346_8_result = unite(v2346_8_result,v2347_13);
  }
  const Space v2346_8 = std::move(v2346_8_result);
  return v2346_8;
}

static Space routine_289(Context& c, const Path& p0, const Space& s0) {
  const Space v2353_2 = singleton(p0);
  return v2353_2;
}

static Space routine_290(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2354_7_result;
  for (int v2354_7_label = 1; v2354_7_label <= 2; ++v2354_7_label) {
    const Space v2354_7_tail = child(s0,v2354_7_label);
    if (v2354_7_tail.empty()) continue;
    const Path v2354_7_head{v2354_7_label};
    const Space v2355_2 = singleton(v2354_7_head);
    const Space v2355_3 = intersect(constant_8,v2355_2);
    const Space v2355_4 = (has_head(v2355_3) ? constant_9 : Space{});
    const Space v2355_5 = subtract(constant_0,v2355_4);
    Space v2355_6_result;
    for (int v2355_6_label = 1; v2355_6_label <= 2; ++v2355_6_label) {
      const Space v2355_6_tail = child(v2354_7_tail,v2355_6_label);
      if (v2355_6_tail.empty()) continue;
      const Path v2355_6_head{v2355_6_label};
      const Space v2356_2 = Space{};
      v2355_6_result = unite(v2355_6_result,v2356_2);
    }
    const Space v2355_6 = std::move(v2355_6_result);
    const Space v2355_7 = compose(v2355_5,v2355_6);
    const Space v2355_8 = intersect(constant_8,v2355_2);
    const Space v2355_9 = (has_head(v2355_8) ? constant_9 : Space{});
    Space v2355_12;
    if (!v2355_9.empty()) {
      const Path v2357_10 = concat_path(p0,v2354_7_head);
      Space v2357_11_result;
      for (int v2357_11_label = 1; v2357_11_label <= 2; ++v2357_11_label) {
        const Space v2357_11_tail = child(v2354_7_tail,v2357_11_label);
        if (v2357_11_tail.empty()) continue;
        const Path v2357_11_head{v2357_11_label};
        const Space v2358_2 = singleton(v2357_11_head);
        const Space v2358_3 = intersect(constant_8,v2358_2);
        const Space v2358_4 = (has_head(v2358_3) ? constant_9 : Space{});
        Space v2358_7;
        if (!v2358_4.empty()) {
          const Path v2359_5 = concat_path(v2357_10,v2357_11_head);
          const Space v2359_6 = routine_230(c, v2359_5, p1, v2357_11_tail);
          v2358_7 = compose(v2358_4,v2359_6);
        }
        v2357_11_result = unite(v2357_11_result,v2358_7);
      }
      const Space v2357_11 = std::move(v2357_11_result);
      v2355_12 = compose(v2355_9,v2357_11);
    }
    const Space v2355_13 = unite(v2355_7,v2355_12);
    v2354_7_result = unite(v2354_7_result,v2355_13);
  }
  const Space v2354_7 = std::move(v2354_7_result);
  return v2354_7;
}

static Space routine_291(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2360_10_result;
  for (int v2360_10_label = 1; v2360_10_label <= 2; ++v2360_10_label) {
    const Space v2360_10_tail = child(s0,v2360_10_label);
    if (v2360_10_tail.empty()) continue;
    const Path v2360_10_head{v2360_10_label};
    const Space v2361_2 = singleton(v2360_10_head);
    const Space v2361_3 = intersect(constant_8,v2361_2);
    const Space v2361_4 = (has_head(v2361_3) ? constant_9 : Space{});
    const Space v2361_5 = subtract(constant_0,v2361_4);
    Space v2361_6_result;
    for (int v2361_6_label = 1; v2361_6_label <= 2; ++v2361_6_label) {
      const Space v2361_6_tail = child(v2360_10_tail,v2361_6_label);
      if (v2361_6_tail.empty()) continue;
      const Path v2361_6_head{v2361_6_label};
      const Space v2362_2 = Space{};
      v2361_6_result = unite(v2361_6_result,v2362_2);
    }
    const Space v2361_6 = std::move(v2361_6_result);
    const Space v2361_7 = compose(v2361_5,v2361_6);
    const Space v2361_8 = intersect(constant_8,v2361_2);
    const Space v2361_9 = (has_head(v2361_8) ? constant_9 : Space{});
    Space v2361_13;
    if (!v2361_9.empty()) {
      Space v2363_10_result;
      for (int v2363_10_label = 1; v2363_10_label <= 2; ++v2363_10_label) {
        const Space v2363_10_tail = child(v2360_10_tail,v2363_10_label);
        if (v2363_10_tail.empty()) continue;
        const Path v2363_10_head{v2363_10_label};
        const Space v2364_2 = singleton(v2363_10_head);
        const Space v2364_3 = intersect(constant_8,v2364_2);
        const Space v2364_4 = (has_head(v2364_3) ? constant_9 : Space{});
        const Space v2364_5 = subtract(constant_0,v2364_4);
        Space v2364_7;
        if (!v2364_5.empty()) {
          const Space v2365_6 = routine_265(c, v2363_10_head, v2363_10_tail);
          v2364_7 = compose(v2364_5,v2365_6);
        }
        const Space v2364_8 = intersect(constant_8,v2364_2);
        const Space v2364_9 = (has_head(v2364_8) ? constant_9 : Space{});
        Space v2364_11;
        if (!v2364_9.empty()) {
          const Space v2366_10 = routine_266(c, v2363_10_head, v2363_10_tail);
          v2364_11 = compose(v2364_9,v2366_10);
        }
        const Space v2364_12 = unite(v2364_7,v2364_11);
        v2363_10_result = unite(v2363_10_result,v2364_12);
      }
      const Space v2363_10 = std::move(v2363_10_result);
      const Space v2363_11 = raffine(constant_25,v2363_10);
      const Space v2363_12 = unite(v2363_11,v2360_10_tail);
      v2361_13 = compose(v2361_9,v2363_12);
    }
    const Path v2361_14 = concat_path(p0,v2360_10_head);
    const Path v2361_15 = concat_path(p1,v2361_14);
    const Space v2361_16 = wrap(v2361_13,v2361_15);
    const Space v2361_17 = unite(v2361_7,v2361_16);
    v2360_10_result = unite(v2360_10_result,v2361_17);
  }
  const Space v2360_10 = std::move(v2360_10_result);
  return v2360_10;
}

static Space routine_292(Context& c, const Path& p0, const Space& s0) {
  Space v2367_11_result;
  for (int v2367_11_label = 1; v2367_11_label <= 2; ++v2367_11_label) {
    const Space v2367_11_tail = child(s0,v2367_11_label);
    if (v2367_11_tail.empty()) continue;
    const Path v2367_11_head{v2367_11_label};
    const Space v2368_2 = singleton(v2367_11_head);
    const Space v2368_3 = intersect(constant_8,v2368_2);
    const Space v2368_4 = (has_head(v2368_3) ? constant_9 : Space{});
    const Space v2368_5 = subtract(constant_0,v2368_4);
    Space v2368_8;
    if (!v2368_5.empty()) {
      const Path v2369_6 = concat_path(p0,v2367_11_head);
      Space v2369_7_result;
      for (int v2369_7_label = 1; v2369_7_label <= 2; ++v2369_7_label) {
        const Space v2369_7_tail = child(v2367_11_tail,v2369_7_label);
        if (v2369_7_tail.empty()) continue;
        const Path v2369_7_head{v2369_7_label};
        const Space v2370_2 = singleton(v2369_7_head);
        const Space v2370_3 = intersect(constant_8,v2370_2);
        const Space v2370_4 = (has_head(v2370_3) ? constant_9 : Space{});
        const Space v2370_5 = subtract(constant_0,v2370_4);
        Space v2370_8;
        if (!v2370_5.empty()) {
          const Path v2371_6 = concat_path(v2369_6,v2369_7_head);
          const Space v2371_7 = routine_321(c, v2371_6, v2369_7_tail);
          v2370_8 = compose(v2370_5,v2371_7);
        }
        const Space v2370_9 = intersect(constant_8,v2370_2);
        const Space v2370_10 = (has_head(v2370_9) ? constant_9 : Space{});
        Space v2370_12;
        if (!v2370_10.empty()) {
          const Path v2372_6 = concat_path(v2369_6,v2369_7_head);
          const Space v2372_11 = routine_322(c, v2372_6, v2369_7_tail);
          v2370_12 = compose(v2370_10,v2372_11);
        }
        const Space v2370_13 = unite(v2370_8,v2370_12);
        v2369_7_result = unite(v2369_7_result,v2370_13);
      }
      const Space v2369_7 = std::move(v2369_7_result);
      v2368_8 = compose(v2368_5,v2369_7);
    }
    const Space v2368_9 = intersect(constant_8,v2368_2);
    const Space v2368_10 = (has_head(v2368_9) ? constant_9 : Space{});
    Space v2368_12;
    if (!v2368_10.empty()) {
      const Path v2373_6 = concat_path(p0,v2367_11_head);
      Space v2373_11_result;
      for (int v2373_11_label = 1; v2373_11_label <= 2; ++v2373_11_label) {
        const Space v2373_11_tail = child(v2367_11_tail,v2373_11_label);
        if (v2373_11_tail.empty()) continue;
        const Path v2373_11_head{v2373_11_label};
        const Space v2374_2 = singleton(v2373_11_head);
        const Space v2374_3 = intersect(constant_8,v2374_2);
        const Space v2374_4 = (has_head(v2374_3) ? constant_9 : Space{});
        const Space v2374_5 = subtract(constant_0,v2374_4);
        Space v2374_8;
        if (!v2374_5.empty()) {
          const Path v2375_6 = concat_path(v2373_6,v2373_11_head);
          const Space v2375_7 = routine_321(c, v2375_6, v2373_11_tail);
          v2374_8 = compose(v2374_5,v2375_7);
        }
        const Space v2374_9 = intersect(constant_8,v2374_2);
        const Space v2374_10 = (has_head(v2374_9) ? constant_9 : Space{});
        Space v2374_12;
        if (!v2374_10.empty()) {
          const Path v2376_6 = concat_path(v2373_6,v2373_11_head);
          const Space v2376_11 = routine_294(c, v2376_6, v2373_11_tail);
          v2374_12 = compose(v2374_10,v2376_11);
        }
        const Space v2374_13 = unite(v2374_8,v2374_12);
        v2373_11_result = unite(v2373_11_result,v2374_13);
      }
      const Space v2373_11 = std::move(v2373_11_result);
      v2368_12 = compose(v2368_10,v2373_11);
    }
    const Space v2368_13 = unite(v2368_8,v2368_12);
    v2367_11_result = unite(v2367_11_result,v2368_13);
  }
  const Space v2367_11 = std::move(v2367_11_result);
  return v2367_11;
}

static Space routine_293(Context& c, const Path& p0, const Space& s0) {
  Space v2377_8_result;
  for (int v2377_8_label = 1; v2377_8_label <= 2; ++v2377_8_label) {
    const Space v2377_8_tail = child(s0,v2377_8_label);
    if (v2377_8_tail.empty()) continue;
    const Path v2377_8_head{v2377_8_label};
    const Space v2378_2 = singleton(v2377_8_head);
    const Space v2378_3 = intersect(constant_8,v2378_2);
    const Space v2378_4 = (has_head(v2378_3) ? constant_9 : Space{});
    const Space v2378_5 = subtract(constant_0,v2378_4);
    Space v2378_8;
    if (!v2378_5.empty()) {
      const Path v2379_6 = concat_path(p0,v2377_8_head);
      Space v2379_7_result;
      for (int v2379_7_label = 1; v2379_7_label <= 2; ++v2379_7_label) {
        const Space v2379_7_tail = child(v2377_8_tail,v2379_7_label);
        if (v2379_7_tail.empty()) continue;
        const Path v2379_7_head{v2379_7_label};
        const Space v2380_2 = singleton(v2379_7_head);
        const Space v2380_3 = intersect(constant_8,v2380_2);
        const Space v2380_4 = (has_head(v2380_3) ? constant_9 : Space{});
        const Space v2380_5 = subtract(constant_0,v2380_4);
        Space v2380_8;
        if (!v2380_5.empty()) {
          const Path v2381_6 = concat_path(v2379_6,v2379_7_head);
          const Space v2381_7 = routine_321(c, v2381_6, v2379_7_tail);
          v2380_8 = compose(v2380_5,v2381_7);
        }
        const Space v2380_9 = intersect(constant_8,v2380_2);
        const Space v2380_10 = (has_head(v2380_9) ? constant_9 : Space{});
        Space v2380_12;
        if (!v2380_10.empty()) {
          const Path v2382_6 = concat_path(v2379_6,v2379_7_head);
          const Space v2382_11 = routine_322(c, v2382_6, v2379_7_tail);
          v2380_12 = compose(v2380_10,v2382_11);
        }
        const Space v2380_13 = unite(v2380_8,v2380_12);
        v2379_7_result = unite(v2379_7_result,v2380_13);
      }
      const Space v2379_7 = std::move(v2379_7_result);
      v2378_8 = compose(v2378_5,v2379_7);
    }
    const Space v2378_9 = intersect(constant_8,v2378_2);
    const Space v2378_10 = (has_head(v2378_9) ? constant_9 : Space{});
    const Path v2383_6 = concat_path(p0,v2377_8_head);
    const Space v2378_11 = singleton(v2383_6);
    const Space v2378_12 = compose(v2378_10,v2378_11);
    const Space v2378_13 = unite(v2378_8,v2378_12);
    v2377_8_result = unite(v2377_8_result,v2378_13);
  }
  const Space v2377_8 = std::move(v2377_8_result);
  return v2377_8;
}

static Space routine_294(Context& c, const Path& p0, const Space& s0) {
  const Space v2384_2 = singleton(p0);
  return v2384_2;
}

static Space routine_295(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2385_8_result;
  for (int v2385_8_label = 1; v2385_8_label <= 2; ++v2385_8_label) {
    const Space v2385_8_tail = child(s0,v2385_8_label);
    if (v2385_8_tail.empty()) continue;
    const Path v2385_8_head{v2385_8_label};
    const Space v2386_2 = singleton(v2385_8_head);
    const Space v2386_3 = intersect(constant_8,v2386_2);
    const Space v2386_4 = (has_head(v2386_3) ? constant_9 : Space{});
    const Space v2386_5 = subtract(constant_0,v2386_4);
    Space v2386_6_result;
    for (int v2386_6_label = 1; v2386_6_label <= 2; ++v2386_6_label) {
      const Space v2386_6_tail = child(v2385_8_tail,v2386_6_label);
      if (v2386_6_tail.empty()) continue;
      const Path v2386_6_head{v2386_6_label};
      const Space v2387_2 = Space{};
      v2386_6_result = unite(v2386_6_result,v2387_2);
    }
    const Space v2386_6 = std::move(v2386_6_result);
    const Space v2386_7 = compose(v2386_5,v2386_6);
    const Space v2386_8 = intersect(constant_8,v2386_2);
    const Space v2386_9 = (has_head(v2386_8) ? constant_9 : Space{});
    Space v2386_12;
    if (!v2386_9.empty()) {
      const Path v2388_10 = concat_path(p0,v2385_8_head);
      Space v2388_11_result;
      for (int v2388_11_label = 1; v2388_11_label <= 2; ++v2388_11_label) {
        const Space v2388_11_tail = child(v2385_8_tail,v2388_11_label);
        if (v2388_11_tail.empty()) continue;
        const Path v2388_11_head{v2388_11_label};
        const Space v2389_2 = singleton(v2388_11_head);
        const Space v2389_3 = intersect(constant_8,v2389_2);
        const Space v2389_4 = (has_head(v2389_3) ? constant_9 : Space{});
        Space v2389_7;
        if (!v2389_4.empty()) {
          const Path v2390_5 = concat_path(v2388_10,v2388_11_head);
          const Space v2390_6 = routine_237(c, v2390_5, p1, p2, v2388_11_tail);
          v2389_7 = compose(v2389_4,v2390_6);
        }
        v2388_11_result = unite(v2388_11_result,v2389_7);
      }
      const Space v2388_11 = std::move(v2388_11_result);
      v2386_12 = compose(v2386_9,v2388_11);
    }
    const Space v2386_13 = unite(v2386_7,v2386_12);
    v2385_8_result = unite(v2385_8_result,v2386_13);
  }
  const Space v2385_8 = std::move(v2385_8_result);
  return v2385_8;
}

static Space routine_296(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2391_9 = concat_path(constant_23,p2);
  const Space v2391_10 = singleton(v2391_9);
  const Space v2391_11 = unite(constant_26,v2391_10);
  const Path v2391_13 = concat_path(constant_22,p1);
  const Space v2391_14 = singleton(v2391_13);
  const Space v2391_15 = unite(v2391_11,v2391_14);
  Space v2391_17_result;
  for (int v2391_17_label = 1; v2391_17_label <= 2; ++v2391_17_label) {
    const Space v2391_17_tail = child(s0,v2391_17_label);
    if (v2391_17_tail.empty()) continue;
    const Path v2391_17_head{v2391_17_label};
    const Space v2392_2 = singleton(v2391_17_head);
    const Space v2392_3 = intersect(constant_8,v2392_2);
    const Space v2392_4 = (has_head(v2392_3) ? constant_9 : Space{});
    const Space v2392_5 = subtract(constant_0,v2392_4);
    Space v2392_6_result;
    for (int v2392_6_label = 1; v2392_6_label <= 2; ++v2392_6_label) {
      const Space v2392_6_tail = child(v2391_17_tail,v2392_6_label);
      if (v2392_6_tail.empty()) continue;
      const Path v2392_6_head{v2392_6_label};
      const Space v2393_2 = Space{};
      v2392_6_result = unite(v2392_6_result,v2393_2);
    }
    const Space v2392_6 = std::move(v2392_6_result);
    const Space v2392_7 = compose(v2392_5,v2392_6);
    const Space v2392_8 = intersect(constant_8,v2392_2);
    const Space v2392_9 = (has_head(v2392_8) ? constant_9 : Space{});
    const Path v2392_10 = concat_path(p0,v2391_17_head);
    const Path v2392_11 = concat_path(constant_6,v2392_10);
    const Space v2392_12 = singleton(v2392_11);
    const Space v2392_13 = unite(v2391_15,v2392_12);
    const Space v2392_14 = compose(v2392_9,v2392_13);
    const Space v2392_15 = unite(v2392_7,v2392_14);
    v2391_17_result = unite(v2391_17_result,v2392_15);
  }
  const Space v2391_17 = std::move(v2391_17_result);
  return v2391_17;
}

static Space routine_297(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2394_8_result;
  for (int v2394_8_label = 1; v2394_8_label <= 2; ++v2394_8_label) {
    const Space v2394_8_tail = child(s0,v2394_8_label);
    if (v2394_8_tail.empty()) continue;
    const Path v2394_8_head{v2394_8_label};
    const Space v2395_2 = singleton(v2394_8_head);
    const Space v2395_3 = intersect(constant_8,v2395_2);
    const Space v2395_4 = (has_head(v2395_3) ? constant_9 : Space{});
    const Space v2395_5 = subtract(constant_0,v2395_4);
    Space v2395_6_result;
    for (int v2395_6_label = 1; v2395_6_label <= 2; ++v2395_6_label) {
      const Space v2395_6_tail = child(v2394_8_tail,v2395_6_label);
      if (v2395_6_tail.empty()) continue;
      const Path v2395_6_head{v2395_6_label};
      const Space v2396_2 = Space{};
      v2395_6_result = unite(v2395_6_result,v2396_2);
    }
    const Space v2395_6 = std::move(v2395_6_result);
    const Space v2395_7 = compose(v2395_5,v2395_6);
    const Space v2395_8 = intersect(constant_8,v2395_2);
    const Space v2395_9 = (has_head(v2395_8) ? constant_9 : Space{});
    Space v2395_12;
    if (!v2395_9.empty()) {
      const Path v2397_10 = concat_path(p0,v2394_8_head);
      Space v2397_11_result;
      for (int v2397_11_label = 1; v2397_11_label <= 2; ++v2397_11_label) {
        const Space v2397_11_tail = child(v2394_8_tail,v2397_11_label);
        if (v2397_11_tail.empty()) continue;
        const Path v2397_11_head{v2397_11_label};
        const Space v2398_2 = singleton(v2397_11_head);
        const Space v2398_3 = intersect(constant_8,v2398_2);
        const Space v2398_4 = (has_head(v2398_3) ? constant_9 : Space{});
        Space v2398_7;
        if (!v2398_4.empty()) {
          const Path v2399_5 = concat_path(v2397_10,v2397_11_head);
          const Space v2399_6 = routine_242(c, v2399_5, p1, p2, v2397_11_tail);
          v2398_7 = compose(v2398_4,v2399_6);
        }
        v2397_11_result = unite(v2397_11_result,v2398_7);
      }
      const Space v2397_11 = std::move(v2397_11_result);
      v2395_12 = compose(v2395_9,v2397_11);
    }
    const Space v2395_13 = unite(v2395_7,v2395_12);
    v2394_8_result = unite(v2394_8_result,v2395_13);
  }
  const Space v2394_8 = std::move(v2394_8_result);
  return v2394_8;
}

static Space routine_298(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2400_10 = concat_path(constant_22,p1);
  const Space v2400_11 = singleton(v2400_10);
  const Path v2400_13 = concat_path(constant_6,p2);
  const Space v2400_14 = singleton(v2400_13);
  Space v2400_15_result;
  for (int v2400_15_label = 1; v2400_15_label <= 2; ++v2400_15_label) {
    const Space v2400_15_tail = child(s0,v2400_15_label);
    if (v2400_15_tail.empty()) continue;
    const Path v2400_15_head{v2400_15_label};
    const Space v2401_2 = singleton(v2400_15_head);
    const Space v2401_3 = intersect(constant_8,v2401_2);
    const Space v2401_4 = (has_head(v2401_3) ? constant_9 : Space{});
    const Space v2401_5 = subtract(constant_0,v2401_4);
    Space v2401_6_result;
    for (int v2401_6_label = 1; v2401_6_label <= 2; ++v2401_6_label) {
      const Space v2401_6_tail = child(v2400_15_tail,v2401_6_label);
      if (v2401_6_tail.empty()) continue;
      const Path v2401_6_head{v2401_6_label};
      const Space v2402_2 = Space{};
      v2401_6_result = unite(v2401_6_result,v2402_2);
    }
    const Space v2401_6 = std::move(v2401_6_result);
    const Space v2401_7 = compose(v2401_5,v2401_6);
    const Space v2401_8 = intersect(constant_8,v2401_2);
    const Space v2401_9 = (has_head(v2401_8) ? constant_9 : Space{});
    const Path v2401_10 = concat_path(p0,v2400_15_head);
    const Path v2401_11 = concat_path(constant_24,v2401_10);
    const Space v2401_12 = singleton(v2401_11);
    const Space v2401_13 = unite(constant_27,v2401_12);
    const Space v2401_14 = unite(v2401_13,v2400_11);
    const Space v2401_15 = unite(v2401_14,v2400_14);
    const Space v2401_16 = compose(v2401_9,v2401_15);
    const Space v2401_17 = unite(v2401_7,v2401_16);
    v2400_15_result = unite(v2400_15_result,v2401_17);
  }
  const Space v2400_15 = std::move(v2400_15_result);
  return v2400_15;
}

static Space routine_299(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2403_8_result;
  for (int v2403_8_label = 1; v2403_8_label <= 2; ++v2403_8_label) {
    const Space v2403_8_tail = child(s0,v2403_8_label);
    if (v2403_8_tail.empty()) continue;
    const Path v2403_8_head{v2403_8_label};
    const Space v2404_2 = singleton(v2403_8_head);
    const Space v2404_3 = intersect(constant_8,v2404_2);
    const Space v2404_4 = (has_head(v2404_3) ? constant_9 : Space{});
    const Space v2404_5 = subtract(constant_0,v2404_4);
    Space v2404_6_result;
    for (int v2404_6_label = 1; v2404_6_label <= 2; ++v2404_6_label) {
      const Space v2404_6_tail = child(v2403_8_tail,v2404_6_label);
      if (v2404_6_tail.empty()) continue;
      const Path v2404_6_head{v2404_6_label};
      const Space v2405_2 = Space{};
      v2404_6_result = unite(v2404_6_result,v2405_2);
    }
    const Space v2404_6 = std::move(v2404_6_result);
    const Space v2404_7 = compose(v2404_5,v2404_6);
    const Space v2404_8 = intersect(constant_8,v2404_2);
    const Space v2404_9 = (has_head(v2404_8) ? constant_9 : Space{});
    Space v2404_12;
    if (!v2404_9.empty()) {
      const Path v2406_10 = concat_path(p0,v2403_8_head);
      Space v2406_11_result;
      for (int v2406_11_label = 1; v2406_11_label <= 2; ++v2406_11_label) {
        const Space v2406_11_tail = child(v2403_8_tail,v2406_11_label);
        if (v2406_11_tail.empty()) continue;
        const Path v2406_11_head{v2406_11_label};
        const Space v2407_2 = singleton(v2406_11_head);
        const Space v2407_3 = intersect(constant_8,v2407_2);
        const Space v2407_4 = (has_head(v2407_3) ? constant_9 : Space{});
        Space v2407_7;
        if (!v2407_4.empty()) {
          const Path v2408_5 = concat_path(v2406_10,v2406_11_head);
          const Space v2408_6 = routine_247(c, v2408_5, p1, p2, v2406_11_tail);
          v2407_7 = compose(v2407_4,v2408_6);
        }
        v2406_11_result = unite(v2406_11_result,v2407_7);
      }
      const Space v2406_11 = std::move(v2406_11_result);
      v2404_12 = compose(v2404_9,v2406_11);
    }
    const Space v2404_13 = unite(v2404_7,v2404_12);
    v2403_8_result = unite(v2403_8_result,v2404_13);
  }
  const Space v2403_8 = std::move(v2403_8_result);
  return v2403_8;
}

static Space routine_300(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2409_10 = concat_path(constant_23,p1);
  const Space v2409_11 = singleton(v2409_10);
  const Path v2409_13 = concat_path(constant_6,p2);
  const Space v2409_14 = singleton(v2409_13);
  Space v2409_15_result;
  for (int v2409_15_label = 1; v2409_15_label <= 2; ++v2409_15_label) {
    const Space v2409_15_tail = child(s0,v2409_15_label);
    if (v2409_15_tail.empty()) continue;
    const Path v2409_15_head{v2409_15_label};
    const Space v2410_2 = singleton(v2409_15_head);
    const Space v2410_3 = intersect(constant_8,v2410_2);
    const Space v2410_4 = (has_head(v2410_3) ? constant_9 : Space{});
    const Space v2410_5 = subtract(constant_0,v2410_4);
    Space v2410_6_result;
    for (int v2410_6_label = 1; v2410_6_label <= 2; ++v2410_6_label) {
      const Space v2410_6_tail = child(v2409_15_tail,v2410_6_label);
      if (v2410_6_tail.empty()) continue;
      const Path v2410_6_head{v2410_6_label};
      const Space v2411_2 = Space{};
      v2410_6_result = unite(v2410_6_result,v2411_2);
    }
    const Space v2410_6 = std::move(v2410_6_result);
    const Space v2410_7 = compose(v2410_5,v2410_6);
    const Space v2410_8 = intersect(constant_8,v2410_2);
    const Space v2410_9 = (has_head(v2410_8) ? constant_9 : Space{});
    const Path v2410_10 = concat_path(p0,v2409_15_head);
    const Path v2410_11 = concat_path(constant_24,v2410_10);
    const Space v2410_12 = singleton(v2410_11);
    const Space v2410_13 = unite(constant_28,v2410_12);
    const Space v2410_14 = unite(v2410_13,v2409_11);
    const Space v2410_15 = unite(v2410_14,v2409_14);
    const Space v2410_16 = compose(v2410_9,v2410_15);
    const Space v2410_17 = unite(v2410_7,v2410_16);
    v2409_15_result = unite(v2409_15_result,v2410_17);
  }
  const Space v2409_15 = std::move(v2409_15_result);
  return v2409_15;
}

static Space routine_301(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2412_8_result;
  for (int v2412_8_label = 1; v2412_8_label <= 2; ++v2412_8_label) {
    const Space v2412_8_tail = child(s0,v2412_8_label);
    if (v2412_8_tail.empty()) continue;
    const Path v2412_8_head{v2412_8_label};
    const Space v2413_2 = singleton(v2412_8_head);
    const Space v2413_3 = intersect(constant_8,v2413_2);
    const Space v2413_4 = (has_head(v2413_3) ? constant_9 : Space{});
    const Space v2413_5 = subtract(constant_0,v2413_4);
    Space v2413_6_result;
    for (int v2413_6_label = 1; v2413_6_label <= 2; ++v2413_6_label) {
      const Space v2413_6_tail = child(v2412_8_tail,v2413_6_label);
      if (v2413_6_tail.empty()) continue;
      const Path v2413_6_head{v2413_6_label};
      const Space v2414_2 = Space{};
      v2413_6_result = unite(v2413_6_result,v2414_2);
    }
    const Space v2413_6 = std::move(v2413_6_result);
    const Space v2413_7 = compose(v2413_5,v2413_6);
    const Space v2413_8 = intersect(constant_8,v2413_2);
    const Space v2413_9 = (has_head(v2413_8) ? constant_9 : Space{});
    Space v2413_12;
    if (!v2413_9.empty()) {
      const Path v2415_10 = concat_path(p0,v2412_8_head);
      Space v2415_11_result;
      for (int v2415_11_label = 1; v2415_11_label <= 2; ++v2415_11_label) {
        const Space v2415_11_tail = child(v2412_8_tail,v2415_11_label);
        if (v2415_11_tail.empty()) continue;
        const Path v2415_11_head{v2415_11_label};
        const Space v2416_2 = singleton(v2415_11_head);
        const Space v2416_3 = intersect(constant_8,v2416_2);
        const Space v2416_4 = (has_head(v2416_3) ? constant_9 : Space{});
        Space v2416_7;
        if (!v2416_4.empty()) {
          const Path v2417_5 = concat_path(v2415_10,v2415_11_head);
          const Space v2417_6 = routine_252(c, v2417_5, p1, p2, v2415_11_tail);
          v2416_7 = compose(v2416_4,v2417_6);
        }
        v2415_11_result = unite(v2415_11_result,v2416_7);
      }
      const Space v2415_11 = std::move(v2415_11_result);
      v2413_12 = compose(v2413_9,v2415_11);
    }
    const Space v2413_13 = unite(v2413_7,v2413_12);
    v2412_8_result = unite(v2412_8_result,v2413_13);
  }
  const Space v2412_8 = std::move(v2412_8_result);
  return v2412_8;
}

static Space routine_302(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2418_10 = concat_path(constant_23,p2);
  const Space v2418_11 = singleton(v2418_10);
  const Path v2418_13 = concat_path(constant_22,p1);
  const Space v2418_14 = singleton(v2418_13);
  Space v2418_15_result;
  for (int v2418_15_label = 1; v2418_15_label <= 2; ++v2418_15_label) {
    const Space v2418_15_tail = child(s0,v2418_15_label);
    if (v2418_15_tail.empty()) continue;
    const Path v2418_15_head{v2418_15_label};
    const Space v2419_2 = singleton(v2418_15_head);
    const Space v2419_3 = intersect(constant_8,v2419_2);
    const Space v2419_4 = (has_head(v2419_3) ? constant_9 : Space{});
    const Space v2419_5 = subtract(constant_0,v2419_4);
    Space v2419_6_result;
    for (int v2419_6_label = 1; v2419_6_label <= 2; ++v2419_6_label) {
      const Space v2419_6_tail = child(v2418_15_tail,v2419_6_label);
      if (v2419_6_tail.empty()) continue;
      const Path v2419_6_head{v2419_6_label};
      const Space v2420_2 = Space{};
      v2419_6_result = unite(v2419_6_result,v2420_2);
    }
    const Space v2419_6 = std::move(v2419_6_result);
    const Space v2419_7 = compose(v2419_5,v2419_6);
    const Space v2419_8 = intersect(constant_8,v2419_2);
    const Space v2419_9 = (has_head(v2419_8) ? constant_9 : Space{});
    const Path v2419_10 = concat_path(p0,v2418_15_head);
    const Path v2419_11 = concat_path(constant_24,v2419_10);
    const Space v2419_12 = singleton(v2419_11);
    const Space v2419_13 = unite(constant_29,v2419_12);
    const Space v2419_14 = unite(v2419_13,v2418_11);
    const Space v2419_15 = unite(v2419_14,v2418_14);
    const Space v2419_16 = compose(v2419_9,v2419_15);
    const Space v2419_17 = unite(v2419_7,v2419_16);
    v2418_15_result = unite(v2418_15_result,v2419_17);
  }
  const Space v2418_15 = std::move(v2418_15_result);
  return v2418_15;
}

static Space routine_303(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2421_3_result;
  for (int v2421_3_label = 1; v2421_3_label <= 2; ++v2421_3_label) {
    const Space v2421_3_tail = child(s0,v2421_3_label);
    if (v2421_3_tail.empty()) continue;
    const Path v2421_3_head{v2421_3_label};
    const Space v2422_2 = Space{};
    v2421_3_result = unite(v2421_3_result,v2422_2);
  }
  const Space v2421_3 = std::move(v2421_3_result);
  return v2421_3;
}

static Space routine_304(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2423_8_result;
  for (int v2423_8_label = 1; v2423_8_label <= 2; ++v2423_8_label) {
    const Space v2423_8_tail = child(s0,v2423_8_label);
    if (v2423_8_tail.empty()) continue;
    const Path v2423_8_head{v2423_8_label};
    const Space v2424_2 = singleton(v2423_8_head);
    const Space v2424_3 = intersect(constant_8,v2424_2);
    const Space v2424_4 = (has_head(v2424_3) ? constant_9 : Space{});
    Space v2424_8;
    if (!v2424_4.empty()) {
      Space v2425_5_result;
      for (int v2425_5_label = 1; v2425_5_label <= 2; ++v2425_5_label) {
        const Space v2425_5_tail = child(v2423_8_tail,v2425_5_label);
        if (v2425_5_tail.empty()) continue;
        const Path v2425_5_head{v2425_5_label};
        const Space v2426_2 = singleton(v2425_5_head);
        const Space v2426_3 = intersect(constant_8,v2426_2);
        const Space v2426_4 = (has_head(v2426_3) ? constant_9 : Space{});
        const Space v2426_5 = subtract(constant_0,v2426_4);
        Space v2426_7;
        if (!v2426_5.empty()) {
          const Space v2427_6 = routine_257(c, v2425_5_head, v2425_5_tail);
          v2426_7 = compose(v2426_5,v2427_6);
        }
        const Space v2426_8 = intersect(constant_8,v2426_2);
        const Space v2426_9 = (has_head(v2426_8) ? constant_9 : Space{});
        Space v2426_11;
        if (!v2426_9.empty()) {
          const Space v2428_10 = routine_258(c, v2425_5_head, v2425_5_tail);
          v2426_11 = compose(v2426_9,v2428_10);
        }
        const Space v2426_12 = unite(v2426_7,v2426_11);
        v2425_5_result = unite(v2425_5_result,v2426_12);
      }
      const Space v2425_5 = std::move(v2425_5_result);
      const Space v2425_6 = raffine(constant_25,v2425_5);
      const Space v2425_7 = unite(v2425_6,v2423_8_tail);
      v2424_8 = compose(v2424_4,v2425_7);
    }
    const Path v2424_9 = concat_path(p0,v2423_8_head);
    const Path v2424_10 = concat_path(p1,v2424_9);
    const Space v2424_11 = wrap(v2424_8,v2424_10);
    v2423_8_result = unite(v2423_8_result,v2424_11);
  }
  const Space v2423_8 = std::move(v2423_8_result);
  return v2423_8;
}

static Space routine_305(Context& c, const Path& p0, const Space& s0) {
  Space v2429_11_result;
  for (int v2429_11_label = 1; v2429_11_label <= 2; ++v2429_11_label) {
    const Space v2429_11_tail = child(s0,v2429_11_label);
    if (v2429_11_tail.empty()) continue;
    const Path v2429_11_head{v2429_11_label};
    const Space v2430_2 = singleton(v2429_11_head);
    const Space v2430_3 = intersect(constant_8,v2430_2);
    const Space v2430_4 = (has_head(v2430_3) ? constant_9 : Space{});
    const Space v2430_5 = subtract(constant_0,v2430_4);
    Space v2430_8;
    if (!v2430_5.empty()) {
      const Path v2431_6 = concat_path(p0,v2429_11_head);
      Space v2431_7_result;
      for (int v2431_7_label = 1; v2431_7_label <= 2; ++v2431_7_label) {
        const Space v2431_7_tail = child(v2429_11_tail,v2431_7_label);
        if (v2431_7_tail.empty()) continue;
        const Path v2431_7_head{v2431_7_label};
        const Space v2432_2 = singleton(v2431_7_head);
        const Space v2432_3 = intersect(constant_8,v2432_2);
        const Space v2432_4 = (has_head(v2432_3) ? constant_9 : Space{});
        const Space v2432_5 = subtract(constant_0,v2432_4);
        Space v2432_8;
        if (!v2432_5.empty()) {
          const Path v2433_6 = concat_path(v2431_6,v2431_7_head);
          const Space v2433_7 = routine_323(c, v2433_6, v2431_7_tail);
          v2432_8 = compose(v2432_5,v2433_7);
        }
        const Space v2432_9 = intersect(constant_8,v2432_2);
        const Space v2432_10 = (has_head(v2432_9) ? constant_9 : Space{});
        Space v2432_12;
        if (!v2432_10.empty()) {
          const Path v2434_6 = concat_path(v2431_6,v2431_7_head);
          const Space v2434_11 = routine_324(c, v2434_6, v2431_7_tail);
          v2432_12 = compose(v2432_10,v2434_11);
        }
        const Space v2432_13 = unite(v2432_8,v2432_12);
        v2431_7_result = unite(v2431_7_result,v2432_13);
      }
      const Space v2431_7 = std::move(v2431_7_result);
      v2430_8 = compose(v2430_5,v2431_7);
    }
    const Space v2430_9 = intersect(constant_8,v2430_2);
    const Space v2430_10 = (has_head(v2430_9) ? constant_9 : Space{});
    Space v2430_12;
    if (!v2430_10.empty()) {
      const Path v2435_6 = concat_path(p0,v2429_11_head);
      Space v2435_11_result;
      for (int v2435_11_label = 1; v2435_11_label <= 2; ++v2435_11_label) {
        const Space v2435_11_tail = child(v2429_11_tail,v2435_11_label);
        if (v2435_11_tail.empty()) continue;
        const Path v2435_11_head{v2435_11_label};
        const Space v2436_2 = singleton(v2435_11_head);
        const Space v2436_3 = intersect(constant_8,v2436_2);
        const Space v2436_4 = (has_head(v2436_3) ? constant_9 : Space{});
        const Space v2436_5 = subtract(constant_0,v2436_4);
        Space v2436_8;
        if (!v2436_5.empty()) {
          const Path v2437_6 = concat_path(v2435_6,v2435_11_head);
          const Space v2437_7 = routine_323(c, v2437_6, v2435_11_tail);
          v2436_8 = compose(v2436_5,v2437_7);
        }
        const Space v2436_9 = intersect(constant_8,v2436_2);
        const Space v2436_10 = (has_head(v2436_9) ? constant_9 : Space{});
        Space v2436_12;
        if (!v2436_10.empty()) {
          const Path v2438_6 = concat_path(v2435_6,v2435_11_head);
          const Space v2438_11 = routine_289(c, v2438_6, v2435_11_tail);
          v2436_12 = compose(v2436_10,v2438_11);
        }
        const Space v2436_13 = unite(v2436_8,v2436_12);
        v2435_11_result = unite(v2435_11_result,v2436_13);
      }
      const Space v2435_11 = std::move(v2435_11_result);
      v2430_12 = compose(v2430_10,v2435_11);
    }
    const Space v2430_13 = unite(v2430_8,v2430_12);
    v2429_11_result = unite(v2429_11_result,v2430_13);
  }
  const Space v2429_11 = std::move(v2429_11_result);
  return v2429_11;
}

static Space routine_306(Context& c, const Path& p0, const Space& s0) {
  Space v2439_8_result;
  for (int v2439_8_label = 1; v2439_8_label <= 2; ++v2439_8_label) {
    const Space v2439_8_tail = child(s0,v2439_8_label);
    if (v2439_8_tail.empty()) continue;
    const Path v2439_8_head{v2439_8_label};
    const Space v2440_2 = singleton(v2439_8_head);
    const Space v2440_3 = intersect(constant_8,v2440_2);
    const Space v2440_4 = (has_head(v2440_3) ? constant_9 : Space{});
    const Space v2440_5 = subtract(constant_0,v2440_4);
    Space v2440_8;
    if (!v2440_5.empty()) {
      const Path v2441_6 = concat_path(p0,v2439_8_head);
      Space v2441_7_result;
      for (int v2441_7_label = 1; v2441_7_label <= 2; ++v2441_7_label) {
        const Space v2441_7_tail = child(v2439_8_tail,v2441_7_label);
        if (v2441_7_tail.empty()) continue;
        const Path v2441_7_head{v2441_7_label};
        const Space v2442_2 = singleton(v2441_7_head);
        const Space v2442_3 = intersect(constant_8,v2442_2);
        const Space v2442_4 = (has_head(v2442_3) ? constant_9 : Space{});
        const Space v2442_5 = subtract(constant_0,v2442_4);
        Space v2442_8;
        if (!v2442_5.empty()) {
          const Path v2443_6 = concat_path(v2441_6,v2441_7_head);
          const Space v2443_7 = routine_323(c, v2443_6, v2441_7_tail);
          v2442_8 = compose(v2442_5,v2443_7);
        }
        const Space v2442_9 = intersect(constant_8,v2442_2);
        const Space v2442_10 = (has_head(v2442_9) ? constant_9 : Space{});
        Space v2442_12;
        if (!v2442_10.empty()) {
          const Path v2444_6 = concat_path(v2441_6,v2441_7_head);
          const Space v2444_11 = routine_324(c, v2444_6, v2441_7_tail);
          v2442_12 = compose(v2442_10,v2444_11);
        }
        const Space v2442_13 = unite(v2442_8,v2442_12);
        v2441_7_result = unite(v2441_7_result,v2442_13);
      }
      const Space v2441_7 = std::move(v2441_7_result);
      v2440_8 = compose(v2440_5,v2441_7);
    }
    const Space v2440_9 = intersect(constant_8,v2440_2);
    const Space v2440_10 = (has_head(v2440_9) ? constant_9 : Space{});
    const Path v2445_6 = concat_path(p0,v2439_8_head);
    const Space v2440_11 = singleton(v2445_6);
    const Space v2440_12 = compose(v2440_10,v2440_11);
    const Space v2440_13 = unite(v2440_8,v2440_12);
    v2439_8_result = unite(v2439_8_result,v2440_13);
  }
  const Space v2439_8 = std::move(v2439_8_result);
  return v2439_8;
}

static Space routine_307(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2446_3_result;
  for (int v2446_3_label = 1; v2446_3_label <= 2; ++v2446_3_label) {
    const Space v2446_3_tail = child(s0,v2446_3_label);
    if (v2446_3_tail.empty()) continue;
    const Path v2446_3_head{v2446_3_label};
    const Space v2447_2 = Space{};
    v2446_3_result = unite(v2446_3_result,v2447_2);
  }
  const Space v2446_3 = std::move(v2446_3_result);
  return v2446_3;
}

static Space routine_308(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2448_8_result;
  for (int v2448_8_label = 1; v2448_8_label <= 2; ++v2448_8_label) {
    const Space v2448_8_tail = child(s0,v2448_8_label);
    if (v2448_8_tail.empty()) continue;
    const Path v2448_8_head{v2448_8_label};
    const Space v2449_2 = singleton(v2448_8_head);
    const Space v2449_3 = intersect(constant_8,v2449_2);
    const Space v2449_4 = (has_head(v2449_3) ? constant_9 : Space{});
    Space v2449_8;
    if (!v2449_4.empty()) {
      Space v2450_5_result;
      for (int v2450_5_label = 1; v2450_5_label <= 2; ++v2450_5_label) {
        const Space v2450_5_tail = child(v2448_8_tail,v2450_5_label);
        if (v2450_5_tail.empty()) continue;
        const Path v2450_5_head{v2450_5_label};
        const Space v2451_2 = singleton(v2450_5_head);
        const Space v2451_3 = intersect(constant_8,v2451_2);
        const Space v2451_4 = (has_head(v2451_3) ? constant_9 : Space{});
        const Space v2451_5 = subtract(constant_0,v2451_4);
        Space v2451_7;
        if (!v2451_5.empty()) {
          const Space v2452_6 = routine_265(c, v2450_5_head, v2450_5_tail);
          v2451_7 = compose(v2451_5,v2452_6);
        }
        const Space v2451_8 = intersect(constant_8,v2451_2);
        const Space v2451_9 = (has_head(v2451_8) ? constant_9 : Space{});
        Space v2451_11;
        if (!v2451_9.empty()) {
          const Space v2453_10 = routine_266(c, v2450_5_head, v2450_5_tail);
          v2451_11 = compose(v2451_9,v2453_10);
        }
        const Space v2451_12 = unite(v2451_7,v2451_11);
        v2450_5_result = unite(v2450_5_result,v2451_12);
      }
      const Space v2450_5 = std::move(v2450_5_result);
      const Space v2450_6 = raffine(constant_25,v2450_5);
      const Space v2450_7 = unite(v2450_6,v2448_8_tail);
      v2449_8 = compose(v2449_4,v2450_7);
    }
    const Path v2449_9 = concat_path(p0,v2448_8_head);
    const Path v2449_10 = concat_path(p1,v2449_9);
    const Space v2449_11 = wrap(v2449_8,v2449_10);
    v2448_8_result = unite(v2448_8_result,v2449_11);
  }
  const Space v2448_8 = std::move(v2448_8_result);
  return v2448_8;
}

static Space routine_309(Context& c, const Path& p0, const Space& s0) {
  Space v2454_11_result;
  for (int v2454_11_label = 1; v2454_11_label <= 2; ++v2454_11_label) {
    const Space v2454_11_tail = child(s0,v2454_11_label);
    if (v2454_11_tail.empty()) continue;
    const Path v2454_11_head{v2454_11_label};
    const Space v2455_2 = singleton(v2454_11_head);
    const Space v2455_3 = intersect(constant_8,v2455_2);
    const Space v2455_4 = (has_head(v2455_3) ? constant_9 : Space{});
    const Space v2455_5 = subtract(constant_0,v2455_4);
    Space v2455_8;
    if (!v2455_5.empty()) {
      const Path v2456_6 = concat_path(p0,v2454_11_head);
      Space v2456_7_result;
      for (int v2456_7_label = 1; v2456_7_label <= 2; ++v2456_7_label) {
        const Space v2456_7_tail = child(v2454_11_tail,v2456_7_label);
        if (v2456_7_tail.empty()) continue;
        const Path v2456_7_head{v2456_7_label};
        const Space v2457_2 = singleton(v2456_7_head);
        const Space v2457_3 = intersect(constant_8,v2457_2);
        const Space v2457_4 = (has_head(v2457_3) ? constant_9 : Space{});
        const Space v2457_5 = subtract(constant_0,v2457_4);
        Space v2457_8;
        if (!v2457_5.empty()) {
          const Path v2458_6 = concat_path(v2456_6,v2456_7_head);
          const Space v2458_7 = routine_325(c, v2458_6, v2456_7_tail);
          v2457_8 = compose(v2457_5,v2458_7);
        }
        const Space v2457_9 = intersect(constant_8,v2457_2);
        const Space v2457_10 = (has_head(v2457_9) ? constant_9 : Space{});
        Space v2457_12;
        if (!v2457_10.empty()) {
          const Path v2459_6 = concat_path(v2456_6,v2456_7_head);
          const Space v2459_11 = routine_326(c, v2459_6, v2456_7_tail);
          v2457_12 = compose(v2457_10,v2459_11);
        }
        const Space v2457_13 = unite(v2457_8,v2457_12);
        v2456_7_result = unite(v2456_7_result,v2457_13);
      }
      const Space v2456_7 = std::move(v2456_7_result);
      v2455_8 = compose(v2455_5,v2456_7);
    }
    const Space v2455_9 = intersect(constant_8,v2455_2);
    const Space v2455_10 = (has_head(v2455_9) ? constant_9 : Space{});
    Space v2455_12;
    if (!v2455_10.empty()) {
      const Path v2460_6 = concat_path(p0,v2454_11_head);
      Space v2460_11_result;
      for (int v2460_11_label = 1; v2460_11_label <= 2; ++v2460_11_label) {
        const Space v2460_11_tail = child(v2454_11_tail,v2460_11_label);
        if (v2460_11_tail.empty()) continue;
        const Path v2460_11_head{v2460_11_label};
        const Space v2461_2 = singleton(v2460_11_head);
        const Space v2461_3 = intersect(constant_8,v2461_2);
        const Space v2461_4 = (has_head(v2461_3) ? constant_9 : Space{});
        const Space v2461_5 = subtract(constant_0,v2461_4);
        Space v2461_8;
        if (!v2461_5.empty()) {
          const Path v2462_6 = concat_path(v2460_6,v2460_11_head);
          const Space v2462_7 = routine_325(c, v2462_6, v2460_11_tail);
          v2461_8 = compose(v2461_5,v2462_7);
        }
        const Space v2461_9 = intersect(constant_8,v2461_2);
        const Space v2461_10 = (has_head(v2461_9) ? constant_9 : Space{});
        Space v2461_12;
        if (!v2461_10.empty()) {
          const Path v2463_6 = concat_path(v2460_6,v2460_11_head);
          const Space v2463_11 = routine_294(c, v2463_6, v2460_11_tail);
          v2461_12 = compose(v2461_10,v2463_11);
        }
        const Space v2461_13 = unite(v2461_8,v2461_12);
        v2460_11_result = unite(v2460_11_result,v2461_13);
      }
      const Space v2460_11 = std::move(v2460_11_result);
      v2455_12 = compose(v2455_10,v2460_11);
    }
    const Space v2455_13 = unite(v2455_8,v2455_12);
    v2454_11_result = unite(v2454_11_result,v2455_13);
  }
  const Space v2454_11 = std::move(v2454_11_result);
  return v2454_11;
}

static Space routine_310(Context& c, const Path& p0, const Space& s0) {
  Space v2464_8_result;
  for (int v2464_8_label = 1; v2464_8_label <= 2; ++v2464_8_label) {
    const Space v2464_8_tail = child(s0,v2464_8_label);
    if (v2464_8_tail.empty()) continue;
    const Path v2464_8_head{v2464_8_label};
    const Space v2465_2 = singleton(v2464_8_head);
    const Space v2465_3 = intersect(constant_8,v2465_2);
    const Space v2465_4 = (has_head(v2465_3) ? constant_9 : Space{});
    const Space v2465_5 = subtract(constant_0,v2465_4);
    Space v2465_8;
    if (!v2465_5.empty()) {
      const Path v2466_6 = concat_path(p0,v2464_8_head);
      Space v2466_7_result;
      for (int v2466_7_label = 1; v2466_7_label <= 2; ++v2466_7_label) {
        const Space v2466_7_tail = child(v2464_8_tail,v2466_7_label);
        if (v2466_7_tail.empty()) continue;
        const Path v2466_7_head{v2466_7_label};
        const Space v2467_2 = singleton(v2466_7_head);
        const Space v2467_3 = intersect(constant_8,v2467_2);
        const Space v2467_4 = (has_head(v2467_3) ? constant_9 : Space{});
        const Space v2467_5 = subtract(constant_0,v2467_4);
        Space v2467_8;
        if (!v2467_5.empty()) {
          const Path v2468_6 = concat_path(v2466_6,v2466_7_head);
          const Space v2468_7 = routine_325(c, v2468_6, v2466_7_tail);
          v2467_8 = compose(v2467_5,v2468_7);
        }
        const Space v2467_9 = intersect(constant_8,v2467_2);
        const Space v2467_10 = (has_head(v2467_9) ? constant_9 : Space{});
        Space v2467_12;
        if (!v2467_10.empty()) {
          const Path v2469_6 = concat_path(v2466_6,v2466_7_head);
          const Space v2469_11 = routine_326(c, v2469_6, v2466_7_tail);
          v2467_12 = compose(v2467_10,v2469_11);
        }
        const Space v2467_13 = unite(v2467_8,v2467_12);
        v2466_7_result = unite(v2466_7_result,v2467_13);
      }
      const Space v2466_7 = std::move(v2466_7_result);
      v2465_8 = compose(v2465_5,v2466_7);
    }
    const Space v2465_9 = intersect(constant_8,v2465_2);
    const Space v2465_10 = (has_head(v2465_9) ? constant_9 : Space{});
    const Path v2470_6 = concat_path(p0,v2464_8_head);
    const Space v2465_11 = singleton(v2470_6);
    const Space v2465_12 = compose(v2465_10,v2465_11);
    const Space v2465_13 = unite(v2465_8,v2465_12);
    v2464_8_result = unite(v2464_8_result,v2465_13);
  }
  const Space v2464_8 = std::move(v2464_8_result);
  return v2464_8;
}

static Space routine_311(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2471_4_result;
  for (int v2471_4_label = 1; v2471_4_label <= 2; ++v2471_4_label) {
    const Space v2471_4_tail = child(s0,v2471_4_label);
    if (v2471_4_tail.empty()) continue;
    const Path v2471_4_head{v2471_4_label};
    const Space v2472_2 = Space{};
    v2471_4_result = unite(v2471_4_result,v2472_2);
  }
  const Space v2471_4 = std::move(v2471_4_result);
  return v2471_4;
}

static Space routine_312(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2473_7 = concat_path(constant_23,p2);
  const Space v2473_8 = singleton(v2473_7);
  const Space v2473_9 = unite(constant_26,v2473_8);
  const Path v2473_11 = concat_path(constant_22,p1);
  const Space v2473_12 = singleton(v2473_11);
  const Space v2473_13 = unite(v2473_9,v2473_12);
  Space v2473_15_result;
  for (int v2473_15_label = 1; v2473_15_label <= 2; ++v2473_15_label) {
    const Space v2473_15_tail = child(s0,v2473_15_label);
    if (v2473_15_tail.empty()) continue;
    const Path v2473_15_head{v2473_15_label};
    const Space v2474_2 = singleton(v2473_15_head);
    const Space v2474_3 = intersect(constant_8,v2474_2);
    const Space v2474_4 = (has_head(v2474_3) ? constant_9 : Space{});
    const Path v2474_5 = concat_path(p0,v2473_15_head);
    const Path v2474_6 = concat_path(constant_6,v2474_5);
    const Space v2474_7 = singleton(v2474_6);
    const Space v2474_8 = unite(v2473_13,v2474_7);
    const Space v2474_9 = compose(v2474_4,v2474_8);
    v2473_15_result = unite(v2473_15_result,v2474_9);
  }
  const Space v2473_15 = std::move(v2473_15_result);
  return v2473_15;
}

static Space routine_313(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2475_4_result;
  for (int v2475_4_label = 1; v2475_4_label <= 2; ++v2475_4_label) {
    const Space v2475_4_tail = child(s0,v2475_4_label);
    if (v2475_4_tail.empty()) continue;
    const Path v2475_4_head{v2475_4_label};
    const Space v2476_2 = Space{};
    v2475_4_result = unite(v2475_4_result,v2476_2);
  }
  const Space v2475_4 = std::move(v2475_4_result);
  return v2475_4;
}

static Space routine_314(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2477_8 = concat_path(constant_22,p1);
  const Space v2477_9 = singleton(v2477_8);
  const Path v2477_11 = concat_path(constant_6,p2);
  const Space v2477_12 = singleton(v2477_11);
  Space v2477_13_result;
  for (int v2477_13_label = 1; v2477_13_label <= 2; ++v2477_13_label) {
    const Space v2477_13_tail = child(s0,v2477_13_label);
    if (v2477_13_tail.empty()) continue;
    const Path v2477_13_head{v2477_13_label};
    const Space v2478_2 = singleton(v2477_13_head);
    const Space v2478_3 = intersect(constant_8,v2478_2);
    const Space v2478_4 = (has_head(v2478_3) ? constant_9 : Space{});
    const Path v2478_5 = concat_path(p0,v2477_13_head);
    const Path v2478_6 = concat_path(constant_24,v2478_5);
    const Space v2478_7 = singleton(v2478_6);
    const Space v2478_8 = unite(constant_27,v2478_7);
    const Space v2478_9 = unite(v2478_8,v2477_9);
    const Space v2478_10 = unite(v2478_9,v2477_12);
    const Space v2478_11 = compose(v2478_4,v2478_10);
    v2477_13_result = unite(v2477_13_result,v2478_11);
  }
  const Space v2477_13 = std::move(v2477_13_result);
  return v2477_13;
}

static Space routine_315(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2479_4_result;
  for (int v2479_4_label = 1; v2479_4_label <= 2; ++v2479_4_label) {
    const Space v2479_4_tail = child(s0,v2479_4_label);
    if (v2479_4_tail.empty()) continue;
    const Path v2479_4_head{v2479_4_label};
    const Space v2480_2 = Space{};
    v2479_4_result = unite(v2479_4_result,v2480_2);
  }
  const Space v2479_4 = std::move(v2479_4_result);
  return v2479_4;
}

static Space routine_316(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2481_8 = concat_path(constant_23,p1);
  const Space v2481_9 = singleton(v2481_8);
  const Path v2481_11 = concat_path(constant_6,p2);
  const Space v2481_12 = singleton(v2481_11);
  Space v2481_13_result;
  for (int v2481_13_label = 1; v2481_13_label <= 2; ++v2481_13_label) {
    const Space v2481_13_tail = child(s0,v2481_13_label);
    if (v2481_13_tail.empty()) continue;
    const Path v2481_13_head{v2481_13_label};
    const Space v2482_2 = singleton(v2481_13_head);
    const Space v2482_3 = intersect(constant_8,v2482_2);
    const Space v2482_4 = (has_head(v2482_3) ? constant_9 : Space{});
    const Path v2482_5 = concat_path(p0,v2481_13_head);
    const Path v2482_6 = concat_path(constant_24,v2482_5);
    const Space v2482_7 = singleton(v2482_6);
    const Space v2482_8 = unite(constant_28,v2482_7);
    const Space v2482_9 = unite(v2482_8,v2481_9);
    const Space v2482_10 = unite(v2482_9,v2481_12);
    const Space v2482_11 = compose(v2482_4,v2482_10);
    v2481_13_result = unite(v2481_13_result,v2482_11);
  }
  const Space v2481_13 = std::move(v2481_13_result);
  return v2481_13;
}

static Space routine_317(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  Space v2483_4_result;
  for (int v2483_4_label = 1; v2483_4_label <= 2; ++v2483_4_label) {
    const Space v2483_4_tail = child(s0,v2483_4_label);
    if (v2483_4_tail.empty()) continue;
    const Path v2483_4_head{v2483_4_label};
    const Space v2484_2 = Space{};
    v2483_4_result = unite(v2483_4_result,v2484_2);
  }
  const Space v2483_4 = std::move(v2483_4_result);
  return v2483_4;
}

static Space routine_318(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Path v2485_8 = concat_path(constant_23,p2);
  const Space v2485_9 = singleton(v2485_8);
  const Path v2485_11 = concat_path(constant_22,p1);
  const Space v2485_12 = singleton(v2485_11);
  Space v2485_13_result;
  for (int v2485_13_label = 1; v2485_13_label <= 2; ++v2485_13_label) {
    const Space v2485_13_tail = child(s0,v2485_13_label);
    if (v2485_13_tail.empty()) continue;
    const Path v2485_13_head{v2485_13_label};
    const Space v2486_2 = singleton(v2485_13_head);
    const Space v2486_3 = intersect(constant_8,v2486_2);
    const Space v2486_4 = (has_head(v2486_3) ? constant_9 : Space{});
    const Path v2486_5 = concat_path(p0,v2485_13_head);
    const Path v2486_6 = concat_path(constant_24,v2486_5);
    const Space v2486_7 = singleton(v2486_6);
    const Space v2486_8 = unite(constant_29,v2486_7);
    const Space v2486_9 = unite(v2486_8,v2485_9);
    const Space v2486_10 = unite(v2486_9,v2485_12);
    const Space v2486_11 = compose(v2486_4,v2486_10);
    v2485_13_result = unite(v2485_13_result,v2486_11);
  }
  const Space v2485_13 = std::move(v2485_13_result);
  return v2485_13;
}

static Space routine_319(Context& c, const Path& p0, const Space& s0) {
  Space v2487_6_result;
  for (int v2487_6_label = 1; v2487_6_label <= 2; ++v2487_6_label) {
    const Space v2487_6_tail = child(s0,v2487_6_label);
    if (v2487_6_tail.empty()) continue;
    const Path v2487_6_head{v2487_6_label};
    const Space v2488_2 = singleton(v2487_6_head);
    const Space v2488_3 = intersect(constant_8,v2488_2);
    const Space v2488_4 = (has_head(v2488_3) ? constant_9 : Space{});
    const Space v2488_5 = subtract(constant_0,v2488_4);
    Space v2488_6_result;
    for (int v2488_6_label = 1; v2488_6_label <= 2; ++v2488_6_label) {
      const Space v2488_6_tail = child(v2487_6_tail,v2488_6_label);
      if (v2488_6_tail.empty()) continue;
      const Path v2488_6_head{v2488_6_label};
      const Space v2489_2 = Space{};
      v2488_6_result = unite(v2488_6_result,v2489_2);
    }
    const Space v2488_6 = std::move(v2488_6_result);
    const Space v2488_7 = compose(v2488_5,v2488_6);
    const Space v2488_8 = intersect(constant_8,v2488_2);
    const Space v2488_9 = (has_head(v2488_8) ? constant_9 : Space{});
    Space v2488_12;
    if (!v2488_9.empty()) {
      const Path v2490_10 = concat_path(p0,v2487_6_head);
      Space v2490_11_result;
      for (int v2490_11_label = 1; v2490_11_label <= 2; ++v2490_11_label) {
        const Space v2490_11_tail = child(v2487_6_tail,v2490_11_label);
        if (v2490_11_tail.empty()) continue;
        const Path v2490_11_head{v2490_11_label};
        const Space v2491_2 = singleton(v2490_11_head);
        const Space v2491_3 = intersect(constant_8,v2491_2);
        const Space v2491_4 = (has_head(v2491_3) ? constant_9 : Space{});
        Space v2491_7;
        if (!v2491_4.empty()) {
          const Path v2492_5 = concat_path(v2490_10,v2490_11_head);
          const Space v2492_6 = routine_289(c, v2492_5, v2490_11_tail);
          v2491_7 = compose(v2491_4,v2492_6);
        }
        v2490_11_result = unite(v2490_11_result,v2491_7);
      }
      const Space v2490_11 = std::move(v2490_11_result);
      v2488_12 = compose(v2488_9,v2490_11);
    }
    const Space v2488_13 = unite(v2488_7,v2488_12);
    v2487_6_result = unite(v2487_6_result,v2488_13);
  }
  const Space v2487_6 = std::move(v2487_6_result);
  return v2487_6;
}

static Space routine_320(Context& c, const Path& p0, const Space& s0) {
  Space v2493_5_result;
  for (int v2493_5_label = 1; v2493_5_label <= 2; ++v2493_5_label) {
    const Space v2493_5_tail = child(s0,v2493_5_label);
    if (v2493_5_tail.empty()) continue;
    const Path v2493_5_head{v2493_5_label};
    const Space v2494_2 = singleton(v2493_5_head);
    const Space v2494_3 = intersect(constant_8,v2494_2);
    const Space v2494_4 = (has_head(v2494_3) ? constant_9 : Space{});
    const Space v2494_5 = subtract(constant_0,v2494_4);
    Space v2494_6_result;
    for (int v2494_6_label = 1; v2494_6_label <= 2; ++v2494_6_label) {
      const Space v2494_6_tail = child(v2493_5_tail,v2494_6_label);
      if (v2494_6_tail.empty()) continue;
      const Path v2494_6_head{v2494_6_label};
      const Space v2495_2 = Space{};
      v2494_6_result = unite(v2494_6_result,v2495_2);
    }
    const Space v2494_6 = std::move(v2494_6_result);
    const Space v2494_7 = compose(v2494_5,v2494_6);
    const Space v2494_8 = intersect(constant_8,v2494_2);
    const Space v2494_9 = (has_head(v2494_8) ? constant_9 : Space{});
    const Path v2494_10 = concat_path(p0,v2493_5_head);
    const Space v2494_11 = singleton(v2494_10);
    const Space v2494_12 = compose(v2494_9,v2494_11);
    const Space v2494_13 = unite(v2494_7,v2494_12);
    v2493_5_result = unite(v2493_5_result,v2494_13);
  }
  const Space v2493_5 = std::move(v2493_5_result);
  return v2493_5;
}

static Space routine_321(Context& c, const Path& p0, const Space& s0) {
  Space v2496_6_result;
  for (int v2496_6_label = 1; v2496_6_label <= 2; ++v2496_6_label) {
    const Space v2496_6_tail = child(s0,v2496_6_label);
    if (v2496_6_tail.empty()) continue;
    const Path v2496_6_head{v2496_6_label};
    const Space v2497_2 = singleton(v2496_6_head);
    const Space v2497_3 = intersect(constant_8,v2497_2);
    const Space v2497_4 = (has_head(v2497_3) ? constant_9 : Space{});
    const Space v2497_5 = subtract(constant_0,v2497_4);
    Space v2497_6_result;
    for (int v2497_6_label = 1; v2497_6_label <= 2; ++v2497_6_label) {
      const Space v2497_6_tail = child(v2496_6_tail,v2497_6_label);
      if (v2497_6_tail.empty()) continue;
      const Path v2497_6_head{v2497_6_label};
      const Space v2498_2 = Space{};
      v2497_6_result = unite(v2497_6_result,v2498_2);
    }
    const Space v2497_6 = std::move(v2497_6_result);
    const Space v2497_7 = compose(v2497_5,v2497_6);
    const Space v2497_8 = intersect(constant_8,v2497_2);
    const Space v2497_9 = (has_head(v2497_8) ? constant_9 : Space{});
    Space v2497_12;
    if (!v2497_9.empty()) {
      const Path v2499_10 = concat_path(p0,v2496_6_head);
      Space v2499_11_result;
      for (int v2499_11_label = 1; v2499_11_label <= 2; ++v2499_11_label) {
        const Space v2499_11_tail = child(v2496_6_tail,v2499_11_label);
        if (v2499_11_tail.empty()) continue;
        const Path v2499_11_head{v2499_11_label};
        const Space v2500_2 = singleton(v2499_11_head);
        const Space v2500_3 = intersect(constant_8,v2500_2);
        const Space v2500_4 = (has_head(v2500_3) ? constant_9 : Space{});
        Space v2500_7;
        if (!v2500_4.empty()) {
          const Path v2501_5 = concat_path(v2499_10,v2499_11_head);
          const Space v2501_6 = routine_294(c, v2501_5, v2499_11_tail);
          v2500_7 = compose(v2500_4,v2501_6);
        }
        v2499_11_result = unite(v2499_11_result,v2500_7);
      }
      const Space v2499_11 = std::move(v2499_11_result);
      v2497_12 = compose(v2497_9,v2499_11);
    }
    const Space v2497_13 = unite(v2497_7,v2497_12);
    v2496_6_result = unite(v2496_6_result,v2497_13);
  }
  const Space v2496_6 = std::move(v2496_6_result);
  return v2496_6;
}

static Space routine_322(Context& c, const Path& p0, const Space& s0) {
  Space v2502_5_result;
  for (int v2502_5_label = 1; v2502_5_label <= 2; ++v2502_5_label) {
    const Space v2502_5_tail = child(s0,v2502_5_label);
    if (v2502_5_tail.empty()) continue;
    const Path v2502_5_head{v2502_5_label};
    const Space v2503_2 = singleton(v2502_5_head);
    const Space v2503_3 = intersect(constant_8,v2503_2);
    const Space v2503_4 = (has_head(v2503_3) ? constant_9 : Space{});
    const Space v2503_5 = subtract(constant_0,v2503_4);
    Space v2503_6_result;
    for (int v2503_6_label = 1; v2503_6_label <= 2; ++v2503_6_label) {
      const Space v2503_6_tail = child(v2502_5_tail,v2503_6_label);
      if (v2503_6_tail.empty()) continue;
      const Path v2503_6_head{v2503_6_label};
      const Space v2504_2 = Space{};
      v2503_6_result = unite(v2503_6_result,v2504_2);
    }
    const Space v2503_6 = std::move(v2503_6_result);
    const Space v2503_7 = compose(v2503_5,v2503_6);
    const Space v2503_8 = intersect(constant_8,v2503_2);
    const Space v2503_9 = (has_head(v2503_8) ? constant_9 : Space{});
    const Path v2503_10 = concat_path(p0,v2502_5_head);
    const Space v2503_11 = singleton(v2503_10);
    const Space v2503_12 = compose(v2503_9,v2503_11);
    const Space v2503_13 = unite(v2503_7,v2503_12);
    v2502_5_result = unite(v2502_5_result,v2503_13);
  }
  const Space v2502_5 = std::move(v2502_5_result);
  return v2502_5;
}

static Space routine_323(Context& c, const Path& p0, const Space& s0) {
  Space v2505_2_result;
  for (int v2505_2_label = 1; v2505_2_label <= 2; ++v2505_2_label) {
    const Space v2505_2_tail = child(s0,v2505_2_label);
    if (v2505_2_tail.empty()) continue;
    const Path v2505_2_head{v2505_2_label};
    const Space v2506_2 = Space{};
    v2505_2_result = unite(v2505_2_result,v2506_2);
  }
  const Space v2505_2 = std::move(v2505_2_result);
  return v2505_2;
}

static Space routine_324(Context& c, const Path& p0, const Space& s0) {
  Space v2507_3_result;
  for (int v2507_3_label = 1; v2507_3_label <= 2; ++v2507_3_label) {
    const Space v2507_3_tail = child(s0,v2507_3_label);
    if (v2507_3_tail.empty()) continue;
    const Path v2507_3_head{v2507_3_label};
    const Space v2508_2 = singleton(v2507_3_head);
    const Space v2508_3 = intersect(constant_8,v2508_2);
    const Space v2508_4 = (has_head(v2508_3) ? constant_9 : Space{});
    const Path v2508_5 = concat_path(p0,v2507_3_head);
    const Space v2508_6 = singleton(v2508_5);
    const Space v2508_7 = compose(v2508_4,v2508_6);
    v2507_3_result = unite(v2507_3_result,v2508_7);
  }
  const Space v2507_3 = std::move(v2507_3_result);
  return v2507_3;
}

static Space routine_325(Context& c, const Path& p0, const Space& s0) {
  Space v2509_2_result;
  for (int v2509_2_label = 1; v2509_2_label <= 2; ++v2509_2_label) {
    const Space v2509_2_tail = child(s0,v2509_2_label);
    if (v2509_2_tail.empty()) continue;
    const Path v2509_2_head{v2509_2_label};
    const Space v2510_2 = Space{};
    v2509_2_result = unite(v2509_2_result,v2510_2);
  }
  const Space v2509_2 = std::move(v2509_2_result);
  return v2509_2;
}

static Space routine_326(Context& c, const Path& p0, const Space& s0) {
  Space v2511_3_result;
  for (int v2511_3_label = 1; v2511_3_label <= 2; ++v2511_3_label) {
    const Space v2511_3_tail = child(s0,v2511_3_label);
    if (v2511_3_tail.empty()) continue;
    const Path v2511_3_head{v2511_3_label};
    const Space v2512_2 = singleton(v2511_3_head);
    const Space v2512_3 = intersect(constant_8,v2512_2);
    const Space v2512_4 = (has_head(v2512_3) ? constant_9 : Space{});
    const Path v2512_5 = concat_path(p0,v2511_3_head);
    const Space v2512_6 = singleton(v2512_5);
    const Space v2512_7 = compose(v2512_4,v2512_6);
    v2511_3_result = unite(v2511_3_result,v2512_7);
  }
  const Space v2511_3 = std::move(v2511_3_result);
  return v2511_3;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
