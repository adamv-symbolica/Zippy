#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Space n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Path n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Path n13(Context&, const Env&);
static ZIPPY_NOINLINE Path n14(Context&, const Env&);
static ZIPPY_NOINLINE Path n15(Context&, const Env&);
static ZIPPY_NOINLINE Path n16(Context&, const Env&);
static ZIPPY_NOINLINE Path n17(Context&, const Env&);
static ZIPPY_NOINLINE Space n18(Context&, const Env&);
static ZIPPY_NOINLINE Space n19(Context&, const Env&);
static ZIPPY_NOINLINE Path n20(Context&, const Env&);
static ZIPPY_NOINLINE Space n21(Context&, const Env&);
static ZIPPY_NOINLINE Space n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n23(Context&, const Env&);
static ZIPPY_NOINLINE Space n24(Context&, const Env&);
static ZIPPY_NOINLINE Space n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Space n29(Context&, const Env&);
static ZIPPY_NOINLINE Space n30(Context&, const Env&);
static ZIPPY_NOINLINE Path n31(Context&, const Env&);
static ZIPPY_NOINLINE Space n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Space n34(Context&, const Env&);
static ZIPPY_NOINLINE Path n35(Context&, const Env&);
static ZIPPY_NOINLINE Space n36(Context&, const Env&);
static ZIPPY_NOINLINE Space n37(Context&, const Env&);
static ZIPPY_NOINLINE Space n38(Context&, const Env&);
static ZIPPY_NOINLINE Path n39(Context&, const Env&);
static ZIPPY_NOINLINE Space n40(Context&, const Env&);
static ZIPPY_NOINLINE Space n41(Context&, const Env&);
static ZIPPY_NOINLINE Space n42(Context&, const Env&);
static ZIPPY_NOINLINE Path n43(Context&, const Env&);
static ZIPPY_NOINLINE Space n44(Context&, const Env&);
static ZIPPY_NOINLINE Space n45(Context&, const Env&);
static ZIPPY_NOINLINE Space n46(Context&, const Env&);
static ZIPPY_NOINLINE Path n47(Context&, const Env&);
static ZIPPY_NOINLINE Space n48(Context&, const Env&);
static ZIPPY_NOINLINE Space n49(Context&, const Env&);
static ZIPPY_NOINLINE Space n50(Context&, const Env&);
static ZIPPY_NOINLINE Path n51(Context&, const Env&);
static ZIPPY_NOINLINE Space n52(Context&, const Env&);
static ZIPPY_NOINLINE Space n53(Context&, const Env&);
static ZIPPY_NOINLINE Space n54(Context&, const Env&);
static ZIPPY_NOINLINE Path n55(Context&, const Env&);
static ZIPPY_NOINLINE Space n56(Context&, const Env&);
static ZIPPY_NOINLINE Space n57(Context&, const Env&);
static ZIPPY_NOINLINE Space n58(Context&, const Env&);
static ZIPPY_NOINLINE Path n59(Context&, const Env&);
static ZIPPY_NOINLINE Space n60(Context&, const Env&);
static ZIPPY_NOINLINE Space n61(Context&, const Env&);
static ZIPPY_NOINLINE Space n62(Context&, const Env&);
static ZIPPY_NOINLINE Space n63(Context&, const Env&);
static ZIPPY_NOINLINE Path n64(Context&, const Env&);
static ZIPPY_NOINLINE Path n65(Context&, const Env&);
static ZIPPY_NOINLINE Path n66(Context&, const Env&);
static ZIPPY_NOINLINE Space n67(Context&, const Env&);
static ZIPPY_NOINLINE Space n68(Context&, const Env&);
static ZIPPY_NOINLINE Space n69(Context&, const Env&);
static ZIPPY_NOINLINE Space n70(Context&, const Env&);
static ZIPPY_NOINLINE Space n71(Context&, const Env&);
static ZIPPY_NOINLINE Space n72(Context&, const Env&);
static ZIPPY_NOINLINE Space n73(Context&, const Env&);
static ZIPPY_NOINLINE Space n74(Context&, const Env&);
static ZIPPY_NOINLINE Path n75(Context&, const Env&);
static ZIPPY_NOINLINE Space n76(Context&, const Env&);
static ZIPPY_NOINLINE Path n77(Context&, const Env&);
static ZIPPY_NOINLINE Space n78(Context&, const Env&);
static ZIPPY_NOINLINE Space n79(Context&, const Env&);
static ZIPPY_NOINLINE Space n80(Context&, const Env&);
static ZIPPY_NOINLINE Space n81(Context&, const Env&);
static ZIPPY_NOINLINE Path n82(Context&, const Env&);
static ZIPPY_NOINLINE Path n83(Context&, const Env&);
static ZIPPY_NOINLINE Path n84(Context&, const Env&);
static ZIPPY_NOINLINE Path n85(Context&, const Env&);
static ZIPPY_NOINLINE Path n86(Context&, const Env&);
static ZIPPY_NOINLINE Space n87(Context&, const Env&);
static ZIPPY_NOINLINE Space n88(Context&, const Env&);
static ZIPPY_NOINLINE Space n89(Context&, const Env&);
static ZIPPY_NOINLINE Space n90(Context&, const Env&);
static ZIPPY_NOINLINE Space n91(Context&, const Env&);
static ZIPPY_NOINLINE Space n92(Context&, const Env&);
static ZIPPY_NOINLINE Space n93(Context&, const Env&);
static ZIPPY_NOINLINE Space n94(Context&, const Env&);
static ZIPPY_NOINLINE Space n95(Context&, const Env&);
static ZIPPY_NOINLINE Space n96(Context&, const Env&);
static ZIPPY_NOINLINE Path n97(Context&, const Env&);
static ZIPPY_NOINLINE Space n98(Context&, const Env&);
static ZIPPY_NOINLINE Space n99(Context&, const Env&);
static ZIPPY_NOINLINE Space n100(Context&, const Env&);
static ZIPPY_NOINLINE Path n101(Context&, const Env&);
static ZIPPY_NOINLINE Space n102(Context&, const Env&);
static ZIPPY_NOINLINE Space n103(Context&, const Env&);
static ZIPPY_NOINLINE Space n104(Context&, const Env&);
static ZIPPY_NOINLINE Path n105(Context&, const Env&);
static ZIPPY_NOINLINE Space n106(Context&, const Env&);
static ZIPPY_NOINLINE Space n107(Context&, const Env&);
static ZIPPY_NOINLINE Space n108(Context&, const Env&);
static ZIPPY_NOINLINE Path n109(Context&, const Env&);
static ZIPPY_NOINLINE Space n110(Context&, const Env&);
static ZIPPY_NOINLINE Space n111(Context&, const Env&);
static ZIPPY_NOINLINE Space n112(Context&, const Env&);
static ZIPPY_NOINLINE Path n113(Context&, const Env&);
static ZIPPY_NOINLINE Space n114(Context&, const Env&);
static ZIPPY_NOINLINE Space n115(Context&, const Env&);
static ZIPPY_NOINLINE Space n116(Context&, const Env&);
static ZIPPY_NOINLINE Path n117(Context&, const Env&);
static ZIPPY_NOINLINE Space n118(Context&, const Env&);
static ZIPPY_NOINLINE Space n119(Context&, const Env&);
static ZIPPY_NOINLINE Space n120(Context&, const Env&);
static ZIPPY_NOINLINE Path n121(Context&, const Env&);
static ZIPPY_NOINLINE Space n122(Context&, const Env&);
static ZIPPY_NOINLINE Space n123(Context&, const Env&);
static ZIPPY_NOINLINE Space n124(Context&, const Env&);
static ZIPPY_NOINLINE Path n125(Context&, const Env&);
static ZIPPY_NOINLINE Space n126(Context&, const Env&);
static ZIPPY_NOINLINE Space n127(Context&, const Env&);
static ZIPPY_NOINLINE Space n128(Context&, const Env&);
static ZIPPY_NOINLINE Space n129(Context&, const Env&);
static ZIPPY_NOINLINE Path n130(Context&, const Env&);
static ZIPPY_NOINLINE Path n131(Context&, const Env&);
static ZIPPY_NOINLINE Path n132(Context&, const Env&);
static ZIPPY_NOINLINE Space n133(Context&, const Env&);
static ZIPPY_NOINLINE Space n134(Context&, const Env&);
static ZIPPY_NOINLINE Space n135(Context&, const Env&);
static ZIPPY_NOINLINE Space n136(Context&, const Env&);
static ZIPPY_NOINLINE Space n137(Context&, const Env&);
static ZIPPY_NOINLINE Space n138(Context&, const Env&);
static ZIPPY_NOINLINE Space n139(Context&, const Env&);
static ZIPPY_NOINLINE Path n140(Context&, const Env&);
static ZIPPY_NOINLINE Space n141(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_1(Context&, const Env&);
static ZIPPY_NOINLINE Space n142(Context&, const Env&);
static ZIPPY_NOINLINE Space n143(Context&, const Env&);
static ZIPPY_NOINLINE Space n144(Context&, const Env&);
static ZIPPY_NOINLINE Space n145(Context&, const Env&);
static ZIPPY_NOINLINE Space n146(Context&, const Env&);
static ZIPPY_NOINLINE Space n147(Context&, const Env&);
static ZIPPY_NOINLINE Space n148(Context&, const Env&);
static ZIPPY_NOINLINE Path n149(Context&, const Env&);
static ZIPPY_NOINLINE Space n150(Context&, const Env&);
static ZIPPY_NOINLINE Path n151(Context&, const Env&);
static ZIPPY_NOINLINE Space n152(Context&, const Env&);
static ZIPPY_NOINLINE Space n153(Context&, const Env&);
static ZIPPY_NOINLINE Space n154(Context&, const Env&);
static ZIPPY_NOINLINE Space n155(Context&, const Env&);
static ZIPPY_NOINLINE Space n156(Context&, const Env&);
static ZIPPY_NOINLINE Space n157(Context&, const Env&);
static ZIPPY_NOINLINE Space n158(Context&, const Env&);
static ZIPPY_NOINLINE Space n159(Context&, const Env&);
static ZIPPY_NOINLINE Space n160(Context&, const Env&);
static ZIPPY_NOINLINE Space n161(Context&, const Env&);
static ZIPPY_NOINLINE Path n162(Context&, const Env&);
static ZIPPY_NOINLINE Space n163(Context&, const Env&);
static ZIPPY_NOINLINE Path n164(Context&, const Env&);
static ZIPPY_NOINLINE Space n165(Context&, const Env&);
static ZIPPY_NOINLINE Path n166(Context&, const Env&);
static ZIPPY_NOINLINE Space n167(Context&, const Env&);
static ZIPPY_NOINLINE Path n168(Context&, const Env&);
static ZIPPY_NOINLINE Space n169(Context&, const Env&);
static ZIPPY_NOINLINE Path n170(Context&, const Env&);
static ZIPPY_NOINLINE Space n171(Context&, const Env&);
static ZIPPY_NOINLINE Path n172(Context&, const Env&);
static ZIPPY_NOINLINE Space n173(Context&, const Env&);
static ZIPPY_NOINLINE Path n174(Context&, const Env&);
static ZIPPY_NOINLINE Space n175(Context&, const Env&);
static ZIPPY_NOINLINE Space n176(Context&, const Env&);
static ZIPPY_NOINLINE Space n177(Context&, const Env&);
static ZIPPY_NOINLINE Space n178(Context&, const Env&);
static ZIPPY_NOINLINE Path n179(Context&, const Env&);
static ZIPPY_NOINLINE Space n180(Context&, const Env&);
static ZIPPY_NOINLINE Path n181(Context&, const Env&);
static ZIPPY_NOINLINE Space n182(Context&, const Env&);
static ZIPPY_NOINLINE Space n183(Context&, const Env&);
static ZIPPY_NOINLINE Space n184(Context&, const Env&);
static ZIPPY_NOINLINE Space n185(Context&, const Env&);
static ZIPPY_NOINLINE Space n186(Context&, const Env&);
static ZIPPY_NOINLINE Space n187(Context&, const Env&);
static ZIPPY_NOINLINE Space n188(Context&, const Env&);
static ZIPPY_NOINLINE Space n189(Context&, const Env&);
static ZIPPY_NOINLINE Space n190(Context&, const Env&);
static ZIPPY_NOINLINE Space n191(Context&, const Env&);
static ZIPPY_NOINLINE Path n192(Context&, const Env&);
static ZIPPY_NOINLINE Space n193(Context&, const Env&);
static ZIPPY_NOINLINE Path n194(Context&, const Env&);
static ZIPPY_NOINLINE Space n195(Context&, const Env&);
static ZIPPY_NOINLINE Path n196(Context&, const Env&);
static ZIPPY_NOINLINE Space n197(Context&, const Env&);
static ZIPPY_NOINLINE Path n198(Context&, const Env&);
static ZIPPY_NOINLINE Space n199(Context&, const Env&);
static ZIPPY_NOINLINE Path n200(Context&, const Env&);
static ZIPPY_NOINLINE Space n201(Context&, const Env&);
static ZIPPY_NOINLINE Path n202(Context&, const Env&);
static ZIPPY_NOINLINE Space n203(Context&, const Env&);
static ZIPPY_NOINLINE Path n204(Context&, const Env&);
static ZIPPY_NOINLINE Space n205(Context&, const Env&);
static ZIPPY_NOINLINE Space n206(Context&, const Env&);
static ZIPPY_NOINLINE Space n207(Context&, const Env&);
static ZIPPY_NOINLINE Space n208(Context&, const Env&);
static ZIPPY_NOINLINE Path n209(Context&, const Env&);
static ZIPPY_NOINLINE Space n210(Context&, const Env&);
static ZIPPY_NOINLINE Path n211(Context&, const Env&);
static ZIPPY_NOINLINE Space n212(Context&, const Env&);
static ZIPPY_NOINLINE Space n213(Context&, const Env&);
static ZIPPY_NOINLINE Space n214(Context&, const Env&);
static ZIPPY_NOINLINE Space n215(Context&, const Env&);
static ZIPPY_NOINLINE Space n216(Context&, const Env&);
static ZIPPY_NOINLINE Space n217(Context&, const Env&);
static ZIPPY_NOINLINE Space n218(Context&, const Env&);
static ZIPPY_NOINLINE Space n219(Context&, const Env&);
static ZIPPY_NOINLINE Space n220(Context&, const Env&);
static ZIPPY_NOINLINE Space n221(Context&, const Env&);
static ZIPPY_NOINLINE Path n222(Context&, const Env&);
static ZIPPY_NOINLINE Space n223(Context&, const Env&);
static ZIPPY_NOINLINE Path n224(Context&, const Env&);
static ZIPPY_NOINLINE Space n225(Context&, const Env&);
static ZIPPY_NOINLINE Path n226(Context&, const Env&);
static ZIPPY_NOINLINE Space n227(Context&, const Env&);
static ZIPPY_NOINLINE Path n228(Context&, const Env&);
static ZIPPY_NOINLINE Space n229(Context&, const Env&);
static ZIPPY_NOINLINE Path n230(Context&, const Env&);
static ZIPPY_NOINLINE Space n231(Context&, const Env&);
static ZIPPY_NOINLINE Path n232(Context&, const Env&);
static ZIPPY_NOINLINE Space n233(Context&, const Env&);
static ZIPPY_NOINLINE Path n234(Context&, const Env&);
static ZIPPY_NOINLINE Space n235(Context&, const Env&);
static ZIPPY_NOINLINE Space n236(Context&, const Env&);
static ZIPPY_NOINLINE Space n237(Context&, const Env&);
static ZIPPY_NOINLINE Space n238(Context&, const Env&);
static ZIPPY_NOINLINE Path n239(Context&, const Env&);
static ZIPPY_NOINLINE Space n240(Context&, const Env&);
static ZIPPY_NOINLINE Path n241(Context&, const Env&);
static ZIPPY_NOINLINE Space n242(Context&, const Env&);
static ZIPPY_NOINLINE Space n243(Context&, const Env&);
static ZIPPY_NOINLINE Space n244(Context&, const Env&);
static ZIPPY_NOINLINE Space n245(Context&, const Env&);
static ZIPPY_NOINLINE Space n246(Context&, const Env&);
static ZIPPY_NOINLINE Space n247(Context&, const Env&);
static ZIPPY_NOINLINE Space n248(Context&, const Env&);
static ZIPPY_NOINLINE Space n249(Context&, const Env&);
static ZIPPY_NOINLINE Space n250(Context&, const Env&);
static ZIPPY_NOINLINE Space n251(Context&, const Env&);
static ZIPPY_NOINLINE Path n252(Context&, const Env&);
static ZIPPY_NOINLINE Space n253(Context&, const Env&);
static ZIPPY_NOINLINE Path n254(Context&, const Env&);
static ZIPPY_NOINLINE Space n255(Context&, const Env&);
static ZIPPY_NOINLINE Path n256(Context&, const Env&);
static ZIPPY_NOINLINE Space n257(Context&, const Env&);
static ZIPPY_NOINLINE Path n258(Context&, const Env&);
static ZIPPY_NOINLINE Space n259(Context&, const Env&);
static ZIPPY_NOINLINE Path n260(Context&, const Env&);
static ZIPPY_NOINLINE Space n261(Context&, const Env&);
static ZIPPY_NOINLINE Path n262(Context&, const Env&);
static ZIPPY_NOINLINE Space n263(Context&, const Env&);
static ZIPPY_NOINLINE Path n264(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n265(Context&, const Env&);
static ZIPPY_NOINLINE Space n266(Context&, const Env&);
static ZIPPY_NOINLINE Space n267(Context&, const Env&);
static ZIPPY_NOINLINE Space n268(Context&, const Env&);
static ZIPPY_NOINLINE Space n269(Context&, const Env&);
static ZIPPY_NOINLINE Space n270(Context&, const Env&);
static ZIPPY_NOINLINE Path n271(Context&, const Env&);
static ZIPPY_NOINLINE Space n272(Context&, const Env&);
static ZIPPY_NOINLINE Path n273(Context&, const Env&);
static ZIPPY_NOINLINE Space n274(Context&, const Env&);
static ZIPPY_NOINLINE Space n275(Context&, const Env&);
static ZIPPY_NOINLINE Space n276(Context&, const Env&);
static ZIPPY_NOINLINE Path n277(Context&, const Env&);
static ZIPPY_NOINLINE Space n278(Context&, const Env&);
static ZIPPY_NOINLINE Space n279(Context&, const Env&);
static ZIPPY_NOINLINE Path n280(Context&, const Env&);
static ZIPPY_NOINLINE Space n281(Context&, const Env&);
static ZIPPY_NOINLINE Space n282(Context&, const Env&);
static ZIPPY_NOINLINE Path n283(Context&, const Env&);
static ZIPPY_NOINLINE Space n284(Context&, const Env&);
static ZIPPY_NOINLINE Space n285(Context&, const Env&);
static ZIPPY_NOINLINE Space n286(Context&, const Env&);
static ZIPPY_NOINLINE Space n287(Context&, const Env&);
static ZIPPY_NOINLINE Path n288(Context&, const Env&);
static ZIPPY_NOINLINE Space n289(Context&, const Env&);
static ZIPPY_NOINLINE Path n290(Context&, const Env&);
static ZIPPY_NOINLINE Space n291(Context&, const Env&);
static ZIPPY_NOINLINE Space n292(Context&, const Env&);
static ZIPPY_NOINLINE Space n293(Context&, const Env&);
static ZIPPY_NOINLINE Path n294(Context&, const Env&);
static ZIPPY_NOINLINE Space n295(Context&, const Env&);
static ZIPPY_NOINLINE Space n296(Context&, const Env&);
static ZIPPY_NOINLINE Path n297(Context&, const Env&);
static ZIPPY_NOINLINE Space n298(Context&, const Env&);
static ZIPPY_NOINLINE Space n299(Context&, const Env&);
static ZIPPY_NOINLINE Path n300(Context&, const Env&);
static ZIPPY_NOINLINE Space n301(Context&, const Env&);
static ZIPPY_NOINLINE Space n302(Context&, const Env&);
static ZIPPY_NOINLINE Space n303(Context&, const Env&);
static ZIPPY_NOINLINE Space n304(Context&, const Env&);
static ZIPPY_NOINLINE Path n305(Context&, const Env&);
static ZIPPY_NOINLINE Space n306(Context&, const Env&);
static ZIPPY_NOINLINE Path n307(Context&, const Env&);
static ZIPPY_NOINLINE Space n308(Context&, const Env&);
static ZIPPY_NOINLINE Space n309(Context&, const Env&);
static ZIPPY_NOINLINE Space n310(Context&, const Env&);
static ZIPPY_NOINLINE Path n311(Context&, const Env&);
static ZIPPY_NOINLINE Space n312(Context&, const Env&);
static ZIPPY_NOINLINE Space n313(Context&, const Env&);
static ZIPPY_NOINLINE Path n314(Context&, const Env&);
static ZIPPY_NOINLINE Space n315(Context&, const Env&);
static ZIPPY_NOINLINE Space n316(Context&, const Env&);
static ZIPPY_NOINLINE Path n317(Context&, const Env&);
static ZIPPY_NOINLINE Space n318(Context&, const Env&);
static ZIPPY_NOINLINE Space n319(Context&, const Env&);
static ZIPPY_NOINLINE Space n320(Context&, const Env&);
static ZIPPY_NOINLINE Space n321(Context&, const Env&);
static ZIPPY_NOINLINE Path n322(Context&, const Env&);
static ZIPPY_NOINLINE Space n323(Context&, const Env&);
static ZIPPY_NOINLINE Path n324(Context&, const Env&);
static ZIPPY_NOINLINE Space n325(Context&, const Env&);
static ZIPPY_NOINLINE Space n326(Context&, const Env&);
static ZIPPY_NOINLINE Space n327(Context&, const Env&);
static ZIPPY_NOINLINE Path n328(Context&, const Env&);
static ZIPPY_NOINLINE Space n329(Context&, const Env&);
static ZIPPY_NOINLINE Space n330(Context&, const Env&);
static ZIPPY_NOINLINE Path n331(Context&, const Env&);
static ZIPPY_NOINLINE Space n332(Context&, const Env&);
static ZIPPY_NOINLINE Space n333(Context&, const Env&);
static ZIPPY_NOINLINE Path n334(Context&, const Env&);
static ZIPPY_NOINLINE Space n335(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { static const Space value=literal_text("12 4 1 2 3 4 4 1 3 4 2 4 1 4 2 3 4 5 2 4 3 4 5 3 2 4 4 5 4 3 2 4 6 2 3 4 4 6 3 4 2 4 6 4 2 3 4 7 2 4 3 4 7 3 2 4 4 7 4 3 2"); return value; }
static ZIPPY_NOINLINE Space n3(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Path n11(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n15(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n16(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n14(Context& c, const Env& e) { auto a=n15(c,e); auto b=n16(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n17(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Path n13(Context& c, const Env& e) { auto a=n14(c,e); auto b=n17(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { return singleton(n13(c,e)); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { std::vector<Path> pv{n11(c,e)}; std::vector<Space> sv{n12(c,e)}; Env n; n.paths[4]=pv[0];n.spaces[3]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Path n20(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n31(Context& c, const Env& e) { return Path{5,8}; }
static ZIPPY_NOINLINE Space n30(Context& c, const Env& e) { return singleton(n31(c,e)); }
static ZIPPY_NOINLINE Space n32(Context& c, const Env& e) { static const Space value=literal_text("2 2 1 5 2 5 1"); return value; }
static ZIPPY_NOINLINE Space n29(Context& c, const Env& e) { auto a=n30(c,e); if(a.empty()) return a; return compose(a,n32(c,e)); }
static ZIPPY_NOINLINE Path n35(Context& c, const Env& e) { return Path{5,9}; }
static ZIPPY_NOINLINE Space n34(Context& c, const Env& e) { return singleton(n35(c,e)); }
static ZIPPY_NOINLINE Space n36(Context& c, const Env& e) { static const Space value=literal_text("2 2 5 7 2 7 5"); return value; }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { auto a=n34(c,e); if(a.empty()) return a; return compose(a,n36(c,e)); }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { auto a=n29(c,e); auto b=n33(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n39(Context& c, const Env& e) { return Path{7,8}; }
static ZIPPY_NOINLINE Space n38(Context& c, const Env& e) { return singleton(n39(c,e)); }
static ZIPPY_NOINLINE Space n40(Context& c, const Env& e) { static const Space value=literal_text("2 2 6 7 2 7 6"); return value; }
static ZIPPY_NOINLINE Space n37(Context& c, const Env& e) { auto a=n38(c,e); if(a.empty()) return a; return compose(a,n40(c,e)); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { auto a=n28(c,e); auto b=n37(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n43(Context& c, const Env& e) { return Path{7,10}; }
static ZIPPY_NOINLINE Space n42(Context& c, const Env& e) { return singleton(n43(c,e)); }
static ZIPPY_NOINLINE Space n44(Context& c, const Env& e) { static const Space value=literal_text("2 2 5 7 2 7 5"); return value; }
static ZIPPY_NOINLINE Space n41(Context& c, const Env& e) { auto a=n42(c,e); if(a.empty()) return a; return compose(a,n44(c,e)); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { auto a=n27(c,e); auto b=n41(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n47(Context& c, const Env& e) { return Path{1,11}; }
static ZIPPY_NOINLINE Space n46(Context& c, const Env& e) { return singleton(n47(c,e)); }
static ZIPPY_NOINLINE Space n48(Context& c, const Env& e) { static const Space value=literal_text("2 2 1 5 2 5 1"); return value; }
static ZIPPY_NOINLINE Space n45(Context& c, const Env& e) { auto a=n46(c,e); if(a.empty()) return a; return compose(a,n48(c,e)); }
static ZIPPY_NOINLINE Space n25(Context& c, const Env& e) { auto a=n26(c,e); auto b=n45(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n51(Context& c, const Env& e) { return Path{1,9}; }
static ZIPPY_NOINLINE Space n50(Context& c, const Env& e) { return singleton(n51(c,e)); }
static ZIPPY_NOINLINE Space n52(Context& c, const Env& e) { static const Space value=literal_text("2 2 1 6 2 6 1"); return value; }
static ZIPPY_NOINLINE Space n49(Context& c, const Env& e) { auto a=n50(c,e); if(a.empty()) return a; return compose(a,n52(c,e)); }
static ZIPPY_NOINLINE Space n24(Context& c, const Env& e) { auto a=n25(c,e); auto b=n49(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n55(Context& c, const Env& e) { return Path{6,11}; }
static ZIPPY_NOINLINE Space n54(Context& c, const Env& e) { return singleton(n55(c,e)); }
static ZIPPY_NOINLINE Space n56(Context& c, const Env& e) { static const Space value=literal_text("2 2 6 7 2 7 6"); return value; }
static ZIPPY_NOINLINE Space n53(Context& c, const Env& e) { auto a=n54(c,e); if(a.empty()) return a; return compose(a,n56(c,e)); }
static ZIPPY_NOINLINE Space n23(Context& c, const Env& e) { auto a=n24(c,e); auto b=n53(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n59(Context& c, const Env& e) { return Path{6,10}; }
static ZIPPY_NOINLINE Space n58(Context& c, const Env& e) { return singleton(n59(c,e)); }
static ZIPPY_NOINLINE Space n60(Context& c, const Env& e) { static const Space value=literal_text("2 2 1 6 2 6 1"); return value; }
static ZIPPY_NOINLINE Space n57(Context& c, const Env& e) { auto a=n58(c,e); if(a.empty()) return a; return compose(a,n60(c,e)); }
static ZIPPY_NOINLINE Space n22(Context& c, const Env& e) { auto a=n23(c,e); auto b=n57(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n62(Context& c, const Env& e) { return e.spaces.at(5); }
static ZIPPY_NOINLINE Path n65(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n66(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Path n64(Context& c, const Env& e) { auto a=n65(c,e); auto b=n66(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n69(Context& c, const Env& e) { static const Space value=literal_text("4 2 1 1 2 5 5 2 6 6 2 7 7"); return value; }
static ZIPPY_NOINLINE Space n71(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n70(Context& c, const Env& e) { return head_space(n71(c,e)); }
static ZIPPY_NOINLINE Space n68(Context& c, const Env& e) { auto a=n69(c,e); auto b=n70(c,e); auto again=n69(c,e); return subtract(a,restrict_to(again,b)); }
static ZIPPY_NOINLINE Space n72(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n67(Context& c, const Env& e) { auto a=n68(c,e); auto b=n72(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n63(Context& c, const Env& e) { auto p=n64(c,e); return wrap(n67(c,e),p); }
static ZIPPY_NOINLINE Space n61(Context& c, const Env& e) { return iterate(c,e,n62(c,e),6,6,n63); }
static ZIPPY_NOINLINE Space n21(Context& c, const Env& e) { return iterate(c,e,n22(c,e),4,5,n61); }
static ZIPPY_NOINLINE Space n19(Context& c, const Env& e) { auto p=n20(c,e); return unwrap(n21(c,e),p); }
static ZIPPY_NOINLINE Path n75(Context& c, const Env& e) { return e.paths.at(7); }
static ZIPPY_NOINLINE Path n77(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n78(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n76(Context& c, const Env& e) { auto p=n77(c,e); return unwrap(n78(c,e),p); }
static ZIPPY_NOINLINE Space n74(Context& c, const Env& e) { auto p=n75(c,e); return wrap(n76(c,e),p); }
static ZIPPY_NOINLINE Space n79(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Space n73(Context& c, const Env& e) { auto a=n74(c,e); if(a.empty()) return a; return compose(a,n79(c,e)); }
static ZIPPY_NOINLINE Space n18(Context& c, const Env& e) { return iterate(c,e,n19(c,e),7,6,n73); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { return iterate(c,e,n10(c,e),5,4,n18); }
static ZIPPY_NOINLINE Path n84(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n85(Context& c, const Env& e) { return e.paths.at(7); }
static ZIPPY_NOINLINE Path n83(Context& c, const Env& e) { auto a=n84(c,e); auto b=n85(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n86(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n82(Context& c, const Env& e) { auto a=n83(c,e); auto b=n86(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n97(Context& c, const Env& e) { return Path{5,8}; }
static ZIPPY_NOINLINE Space n96(Context& c, const Env& e) { return singleton(n97(c,e)); }
static ZIPPY_NOINLINE Space n98(Context& c, const Env& e) { static const Space value=literal_text("2 2 1 5 2 5 1"); return value; }
static ZIPPY_NOINLINE Space n95(Context& c, const Env& e) { auto a=n96(c,e); if(a.empty()) return a; return compose(a,n98(c,e)); }
static ZIPPY_NOINLINE Path n101(Context& c, const Env& e) { return Path{5,9}; }
static ZIPPY_NOINLINE Space n100(Context& c, const Env& e) { return singleton(n101(c,e)); }
static ZIPPY_NOINLINE Space n102(Context& c, const Env& e) { static const Space value=literal_text("2 2 5 7 2 7 5"); return value; }
static ZIPPY_NOINLINE Space n99(Context& c, const Env& e) { auto a=n100(c,e); if(a.empty()) return a; return compose(a,n102(c,e)); }
static ZIPPY_NOINLINE Space n94(Context& c, const Env& e) { auto a=n95(c,e); auto b=n99(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n105(Context& c, const Env& e) { return Path{7,8}; }
static ZIPPY_NOINLINE Space n104(Context& c, const Env& e) { return singleton(n105(c,e)); }
static ZIPPY_NOINLINE Space n106(Context& c, const Env& e) { static const Space value=literal_text("2 2 6 7 2 7 6"); return value; }
static ZIPPY_NOINLINE Space n103(Context& c, const Env& e) { auto a=n104(c,e); if(a.empty()) return a; return compose(a,n106(c,e)); }
static ZIPPY_NOINLINE Space n93(Context& c, const Env& e) { auto a=n94(c,e); auto b=n103(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n109(Context& c, const Env& e) { return Path{7,10}; }
static ZIPPY_NOINLINE Space n108(Context& c, const Env& e) { return singleton(n109(c,e)); }
static ZIPPY_NOINLINE Space n110(Context& c, const Env& e) { static const Space value=literal_text("2 2 5 7 2 7 5"); return value; }
static ZIPPY_NOINLINE Space n107(Context& c, const Env& e) { auto a=n108(c,e); if(a.empty()) return a; return compose(a,n110(c,e)); }
static ZIPPY_NOINLINE Space n92(Context& c, const Env& e) { auto a=n93(c,e); auto b=n107(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n113(Context& c, const Env& e) { return Path{1,11}; }
static ZIPPY_NOINLINE Space n112(Context& c, const Env& e) { return singleton(n113(c,e)); }
static ZIPPY_NOINLINE Space n114(Context& c, const Env& e) { static const Space value=literal_text("2 2 1 5 2 5 1"); return value; }
static ZIPPY_NOINLINE Space n111(Context& c, const Env& e) { auto a=n112(c,e); if(a.empty()) return a; return compose(a,n114(c,e)); }
static ZIPPY_NOINLINE Space n91(Context& c, const Env& e) { auto a=n92(c,e); auto b=n111(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n117(Context& c, const Env& e) { return Path{1,9}; }
static ZIPPY_NOINLINE Space n116(Context& c, const Env& e) { return singleton(n117(c,e)); }
static ZIPPY_NOINLINE Space n118(Context& c, const Env& e) { static const Space value=literal_text("2 2 1 6 2 6 1"); return value; }
static ZIPPY_NOINLINE Space n115(Context& c, const Env& e) { auto a=n116(c,e); if(a.empty()) return a; return compose(a,n118(c,e)); }
static ZIPPY_NOINLINE Space n90(Context& c, const Env& e) { auto a=n91(c,e); auto b=n115(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n121(Context& c, const Env& e) { return Path{6,11}; }
static ZIPPY_NOINLINE Space n120(Context& c, const Env& e) { return singleton(n121(c,e)); }
static ZIPPY_NOINLINE Space n122(Context& c, const Env& e) { static const Space value=literal_text("2 2 6 7 2 7 6"); return value; }
static ZIPPY_NOINLINE Space n119(Context& c, const Env& e) { auto a=n120(c,e); if(a.empty()) return a; return compose(a,n122(c,e)); }
static ZIPPY_NOINLINE Space n89(Context& c, const Env& e) { auto a=n90(c,e); auto b=n119(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n125(Context& c, const Env& e) { return Path{6,10}; }
static ZIPPY_NOINLINE Space n124(Context& c, const Env& e) { return singleton(n125(c,e)); }
static ZIPPY_NOINLINE Space n126(Context& c, const Env& e) { static const Space value=literal_text("2 2 1 6 2 6 1"); return value; }
static ZIPPY_NOINLINE Space n123(Context& c, const Env& e) { auto a=n124(c,e); if(a.empty()) return a; return compose(a,n126(c,e)); }
static ZIPPY_NOINLINE Space n88(Context& c, const Env& e) { auto a=n89(c,e); auto b=n123(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n128(Context& c, const Env& e) { return e.spaces.at(5); }
static ZIPPY_NOINLINE Path n131(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n132(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Path n130(Context& c, const Env& e) { auto a=n131(c,e); auto b=n132(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n135(Context& c, const Env& e) { static const Space value=literal_text("4 2 1 1 2 5 5 2 6 6 2 7 7"); return value; }
static ZIPPY_NOINLINE Space n137(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n136(Context& c, const Env& e) { return head_space(n137(c,e)); }
static ZIPPY_NOINLINE Space n134(Context& c, const Env& e) { auto a=n135(c,e); auto b=n136(c,e); auto again=n135(c,e); return subtract(a,restrict_to(again,b)); }
static ZIPPY_NOINLINE Space n138(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n133(Context& c, const Env& e) { auto a=n134(c,e); auto b=n138(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n129(Context& c, const Env& e) { auto p=n130(c,e); return wrap(n133(c,e),p); }
static ZIPPY_NOINLINE Space n127(Context& c, const Env& e) { return iterate(c,e,n128(c,e),6,6,n129); }
static ZIPPY_NOINLINE Space n87(Context& c, const Env& e) { return iterate(c,e,n88(c,e),4,5,n127); }
static ZIPPY_NOINLINE Space n81(Context& c, const Env& e) { auto p=n82(c,e); return unwrap(n87(c,e),p); }
static ZIPPY_NOINLINE Path n140(Context& c, const Env& e) { return e.paths.at(8); }
static ZIPPY_NOINLINE Space n141(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n139(Context& c, const Env& e) { std::vector<Path> pv{n140(c,e)}; std::vector<Space> sv{n141(c,e)}; Env n; n.paths[4]=pv[0];n.spaces[8]=sv[0];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n80(Context& c, const Env& e) { return iterate(c,e,n81(c,e),8,-1,n139); }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { return iterate(c,e,n9(c,e),7,7,n80); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { return iterate(c,e,n7(c,e),3,-1,n8); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { return iterate(c,e,n5(c,e),2,2,n6); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { return iterate(c,e,n3(c,e),1,1,n4); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { return iterate(c,e,n1(c,e),0,0,n2); }
static ZIPPY_NOINLINE Path n149(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n148(Context& c, const Env& e) { return singleton(n149(c,e)); }
static ZIPPY_NOINLINE Path n151(Context& c, const Env& e) { return Path{5}; }
static ZIPPY_NOINLINE Space n150(Context& c, const Env& e) { return singleton(n151(c,e)); }
static ZIPPY_NOINLINE Space n147(Context& c, const Env& e) { auto a=n148(c,e); auto b=n150(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n146(Context& c, const Env& e) { return tails_union(n147(c,e)); }
static ZIPPY_NOINLINE Space n153(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n155(Context& c, const Env& e) { return e.spaces.at(9); }
static ZIPPY_NOINLINE Space n157(Context& c, const Env& e) { return e.spaces.at(10); }
static ZIPPY_NOINLINE Path n162(Context& c, const Env& e) { return Path{5,12}; }
static ZIPPY_NOINLINE Space n161(Context& c, const Env& e) { return singleton(n162(c,e)); }
static ZIPPY_NOINLINE Path n164(Context& c, const Env& e) { return Path{7}; }
static ZIPPY_NOINLINE Path n166(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Space n165(Context& c, const Env& e) { return singleton(n166(c,e)); }
static ZIPPY_NOINLINE Space n163(Context& c, const Env& e) { auto p=n164(c,e); return wrap(n165(c,e),p); }
static ZIPPY_NOINLINE Space n160(Context& c, const Env& e) { auto a=n161(c,e); auto b=n163(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n168(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Path n170(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Space n169(Context& c, const Env& e) { return singleton(n170(c,e)); }
static ZIPPY_NOINLINE Space n167(Context& c, const Env& e) { auto p=n168(c,e); return wrap(n169(c,e),p); }
static ZIPPY_NOINLINE Space n159(Context& c, const Env& e) { auto a=n160(c,e); auto b=n167(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n172(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Path n174(Context& c, const Env& e) { return e.paths.at(11); }
static ZIPPY_NOINLINE Space n173(Context& c, const Env& e) { return singleton(n174(c,e)); }
static ZIPPY_NOINLINE Space n171(Context& c, const Env& e) { auto p=n172(c,e); return wrap(n173(c,e),p); }
static ZIPPY_NOINLINE Space n158(Context& c, const Env& e) { auto a=n159(c,e); auto b=n171(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n156(Context& c, const Env& e) { return iterate(c,e,n157(c,e),11,-1,n158); }
static ZIPPY_NOINLINE Space n154(Context& c, const Env& e) { return iterate(c,e,n155(c,e),10,10,n156); }
static ZIPPY_NOINLINE Space n152(Context& c, const Env& e) { return iterate(c,e,n153(c,e),9,9,n154); }
static ZIPPY_NOINLINE Space n145(Context& c, const Env& e) { auto a=n146(c,e); if(a.empty()) return a; return compose(a,n152(c,e)); }
static ZIPPY_NOINLINE Path n179(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n178(Context& c, const Env& e) { return singleton(n179(c,e)); }
static ZIPPY_NOINLINE Path n181(Context& c, const Env& e) { return Path{7}; }
static ZIPPY_NOINLINE Space n180(Context& c, const Env& e) { return singleton(n181(c,e)); }
static ZIPPY_NOINLINE Space n177(Context& c, const Env& e) { auto a=n178(c,e); auto b=n180(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n176(Context& c, const Env& e) { return tails_union(n177(c,e)); }
static ZIPPY_NOINLINE Space n183(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n185(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Space n187(Context& c, const Env& e) { return e.spaces.at(12); }
static ZIPPY_NOINLINE Path n192(Context& c, const Env& e) { return Path{7,12}; }
static ZIPPY_NOINLINE Space n191(Context& c, const Env& e) { return singleton(n192(c,e)); }
static ZIPPY_NOINLINE Path n194(Context& c, const Env& e) { return Path{5}; }
static ZIPPY_NOINLINE Path n196(Context& c, const Env& e) { return e.paths.at(12); }
static ZIPPY_NOINLINE Space n195(Context& c, const Env& e) { return singleton(n196(c,e)); }
static ZIPPY_NOINLINE Space n193(Context& c, const Env& e) { auto p=n194(c,e); return wrap(n195(c,e),p); }
static ZIPPY_NOINLINE Space n190(Context& c, const Env& e) { auto a=n191(c,e); auto b=n193(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n198(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Path n200(Context& c, const Env& e) { return e.paths.at(13); }
static ZIPPY_NOINLINE Space n199(Context& c, const Env& e) { return singleton(n200(c,e)); }
static ZIPPY_NOINLINE Space n197(Context& c, const Env& e) { auto p=n198(c,e); return wrap(n199(c,e),p); }
static ZIPPY_NOINLINE Space n189(Context& c, const Env& e) { auto a=n190(c,e); auto b=n197(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n202(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Path n204(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Space n203(Context& c, const Env& e) { return singleton(n204(c,e)); }
static ZIPPY_NOINLINE Space n201(Context& c, const Env& e) { auto p=n202(c,e); return wrap(n203(c,e),p); }
static ZIPPY_NOINLINE Space n188(Context& c, const Env& e) { auto a=n189(c,e); auto b=n201(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n186(Context& c, const Env& e) { return iterate(c,e,n187(c,e),14,-1,n188); }
static ZIPPY_NOINLINE Space n184(Context& c, const Env& e) { return iterate(c,e,n185(c,e),13,12,n186); }
static ZIPPY_NOINLINE Space n182(Context& c, const Env& e) { return iterate(c,e,n183(c,e),12,11,n184); }
static ZIPPY_NOINLINE Space n175(Context& c, const Env& e) { auto a=n176(c,e); if(a.empty()) return a; return compose(a,n182(c,e)); }
static ZIPPY_NOINLINE Space n144(Context& c, const Env& e) { auto a=n145(c,e); auto b=n175(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n209(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n208(Context& c, const Env& e) { return singleton(n209(c,e)); }
static ZIPPY_NOINLINE Path n211(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n210(Context& c, const Env& e) { return singleton(n211(c,e)); }
static ZIPPY_NOINLINE Space n207(Context& c, const Env& e) { auto a=n208(c,e); auto b=n210(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n206(Context& c, const Env& e) { return tails_union(n207(c,e)); }
static ZIPPY_NOINLINE Space n213(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n215(Context& c, const Env& e) { return e.spaces.at(13); }
static ZIPPY_NOINLINE Space n217(Context& c, const Env& e) { return e.spaces.at(14); }
static ZIPPY_NOINLINE Path n222(Context& c, const Env& e) { return Path{1,12}; }
static ZIPPY_NOINLINE Space n221(Context& c, const Env& e) { return singleton(n222(c,e)); }
static ZIPPY_NOINLINE Path n224(Context& c, const Env& e) { return Path{5}; }
static ZIPPY_NOINLINE Path n226(Context& c, const Env& e) { return e.paths.at(15); }
static ZIPPY_NOINLINE Space n225(Context& c, const Env& e) { return singleton(n226(c,e)); }
static ZIPPY_NOINLINE Space n223(Context& c, const Env& e) { auto p=n224(c,e); return wrap(n225(c,e),p); }
static ZIPPY_NOINLINE Space n220(Context& c, const Env& e) { auto a=n221(c,e); auto b=n223(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n228(Context& c, const Env& e) { return Path{7}; }
static ZIPPY_NOINLINE Path n230(Context& c, const Env& e) { return e.paths.at(16); }
static ZIPPY_NOINLINE Space n229(Context& c, const Env& e) { return singleton(n230(c,e)); }
static ZIPPY_NOINLINE Space n227(Context& c, const Env& e) { auto p=n228(c,e); return wrap(n229(c,e),p); }
static ZIPPY_NOINLINE Space n219(Context& c, const Env& e) { auto a=n220(c,e); auto b=n227(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n232(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Path n234(Context& c, const Env& e) { return e.paths.at(17); }
static ZIPPY_NOINLINE Space n233(Context& c, const Env& e) { return singleton(n234(c,e)); }
static ZIPPY_NOINLINE Space n231(Context& c, const Env& e) { auto p=n232(c,e); return wrap(n233(c,e),p); }
static ZIPPY_NOINLINE Space n218(Context& c, const Env& e) { auto a=n219(c,e); auto b=n231(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n216(Context& c, const Env& e) { return iterate(c,e,n217(c,e),17,-1,n218); }
static ZIPPY_NOINLINE Space n214(Context& c, const Env& e) { return iterate(c,e,n215(c,e),16,14,n216); }
static ZIPPY_NOINLINE Space n212(Context& c, const Env& e) { return iterate(c,e,n213(c,e),15,13,n214); }
static ZIPPY_NOINLINE Space n205(Context& c, const Env& e) { auto a=n206(c,e); if(a.empty()) return a; return compose(a,n212(c,e)); }
static ZIPPY_NOINLINE Space n143(Context& c, const Env& e) { auto a=n144(c,e); auto b=n205(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n239(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n238(Context& c, const Env& e) { return singleton(n239(c,e)); }
static ZIPPY_NOINLINE Path n241(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Space n240(Context& c, const Env& e) { return singleton(n241(c,e)); }
static ZIPPY_NOINLINE Space n237(Context& c, const Env& e) { auto a=n238(c,e); auto b=n240(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n236(Context& c, const Env& e) { return tails_union(n237(c,e)); }
static ZIPPY_NOINLINE Space n243(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n245(Context& c, const Env& e) { return e.spaces.at(15); }
static ZIPPY_NOINLINE Space n247(Context& c, const Env& e) { return e.spaces.at(16); }
static ZIPPY_NOINLINE Path n252(Context& c, const Env& e) { return Path{6,12}; }
static ZIPPY_NOINLINE Space n251(Context& c, const Env& e) { return singleton(n252(c,e)); }
static ZIPPY_NOINLINE Path n254(Context& c, const Env& e) { return Path{5}; }
static ZIPPY_NOINLINE Path n256(Context& c, const Env& e) { return e.paths.at(18); }
static ZIPPY_NOINLINE Space n255(Context& c, const Env& e) { return singleton(n256(c,e)); }
static ZIPPY_NOINLINE Space n253(Context& c, const Env& e) { auto p=n254(c,e); return wrap(n255(c,e),p); }
static ZIPPY_NOINLINE Space n250(Context& c, const Env& e) { auto a=n251(c,e); auto b=n253(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n258(Context& c, const Env& e) { return Path{7}; }
static ZIPPY_NOINLINE Path n260(Context& c, const Env& e) { return e.paths.at(19); }
static ZIPPY_NOINLINE Space n259(Context& c, const Env& e) { return singleton(n260(c,e)); }
static ZIPPY_NOINLINE Space n257(Context& c, const Env& e) { auto p=n258(c,e); return wrap(n259(c,e),p); }
static ZIPPY_NOINLINE Space n249(Context& c, const Env& e) { auto a=n250(c,e); auto b=n257(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n262(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Path n264(Context& c, const Env& e) { return e.paths.at(20); }
static ZIPPY_NOINLINE Space n263(Context& c, const Env& e) { return singleton(n264(c,e)); }
static ZIPPY_NOINLINE Space n261(Context& c, const Env& e) { auto p=n262(c,e); return wrap(n263(c,e),p); }
static ZIPPY_NOINLINE Space n248(Context& c, const Env& e) { auto a=n249(c,e); auto b=n261(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n246(Context& c, const Env& e) { return iterate(c,e,n247(c,e),20,-1,n248); }
static ZIPPY_NOINLINE Space n244(Context& c, const Env& e) { return iterate(c,e,n245(c,e),19,16,n246); }
static ZIPPY_NOINLINE Space n242(Context& c, const Env& e) { return iterate(c,e,n243(c,e),18,15,n244); }
static ZIPPY_NOINLINE Space n235(Context& c, const Env& e) { auto a=n236(c,e); if(a.empty()) return a; return compose(a,n242(c,e)); }
static ZIPPY_NOINLINE Space n142(Context& c, const Env& e) { auto a=n143(c,e); auto b=n235(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_1(Context& c,const Env& e) { return n142(c,e); }
static ZIPPY_NOINLINE Path n271(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n270(Context& c, const Env& e) { return singleton(n271(c,e)); }
static ZIPPY_NOINLINE Path n273(Context& c, const Env& e) { return Path{5}; }
static ZIPPY_NOINLINE Space n272(Context& c, const Env& e) { return singleton(n273(c,e)); }
static ZIPPY_NOINLINE Space n269(Context& c, const Env& e) { auto a=n270(c,e); auto b=n272(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Path n277(Context& c, const Env& e) { return Path{7}; }
static ZIPPY_NOINLINE Space n278(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n276(Context& c, const Env& e) { auto p=n277(c,e); return unwrap(n278(c,e),p); }
static ZIPPY_NOINLINE Path n280(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n281(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n279(Context& c, const Env& e) { auto p=n280(c,e); return unwrap(n281(c,e),p); }
static ZIPPY_NOINLINE Space n275(Context& c, const Env& e) { auto a=n276(c,e); if(a.empty()) return a; return compose(a,n279(c,e)); }
static ZIPPY_NOINLINE Path n283(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Space n284(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n282(Context& c, const Env& e) { auto p=n283(c,e); return unwrap(n284(c,e),p); }
static ZIPPY_NOINLINE Space n274(Context& c, const Env& e) { auto a=n275(c,e); if(a.empty()) return a; return compose(a,n282(c,e)); }
static ZIPPY_NOINLINE Space n268(Context& c, const Env& e) { auto a=n269(c,e); if(a.empty()) return a; return compose(a,n274(c,e)); }
static ZIPPY_NOINLINE Path n288(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n287(Context& c, const Env& e) { return singleton(n288(c,e)); }
static ZIPPY_NOINLINE Path n290(Context& c, const Env& e) { return Path{7}; }
static ZIPPY_NOINLINE Space n289(Context& c, const Env& e) { return singleton(n290(c,e)); }
static ZIPPY_NOINLINE Space n286(Context& c, const Env& e) { auto a=n287(c,e); auto b=n289(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Path n294(Context& c, const Env& e) { return Path{5}; }
static ZIPPY_NOINLINE Space n295(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n293(Context& c, const Env& e) { auto p=n294(c,e); return unwrap(n295(c,e),p); }
static ZIPPY_NOINLINE Path n297(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n298(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n296(Context& c, const Env& e) { auto p=n297(c,e); return unwrap(n298(c,e),p); }
static ZIPPY_NOINLINE Space n292(Context& c, const Env& e) { auto a=n293(c,e); if(a.empty()) return a; return compose(a,n296(c,e)); }
static ZIPPY_NOINLINE Path n300(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Space n301(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n299(Context& c, const Env& e) { auto p=n300(c,e); return unwrap(n301(c,e),p); }
static ZIPPY_NOINLINE Space n291(Context& c, const Env& e) { auto a=n292(c,e); if(a.empty()) return a; return compose(a,n299(c,e)); }
static ZIPPY_NOINLINE Space n285(Context& c, const Env& e) { auto a=n286(c,e); if(a.empty()) return a; return compose(a,n291(c,e)); }
static ZIPPY_NOINLINE Space n267(Context& c, const Env& e) { auto a=n268(c,e); auto b=n285(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n305(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n304(Context& c, const Env& e) { return singleton(n305(c,e)); }
static ZIPPY_NOINLINE Path n307(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n306(Context& c, const Env& e) { return singleton(n307(c,e)); }
static ZIPPY_NOINLINE Space n303(Context& c, const Env& e) { auto a=n304(c,e); auto b=n306(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Path n311(Context& c, const Env& e) { return Path{5}; }
static ZIPPY_NOINLINE Space n312(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n310(Context& c, const Env& e) { auto p=n311(c,e); return unwrap(n312(c,e),p); }
static ZIPPY_NOINLINE Path n314(Context& c, const Env& e) { return Path{7}; }
static ZIPPY_NOINLINE Space n315(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n313(Context& c, const Env& e) { auto p=n314(c,e); return unwrap(n315(c,e),p); }
static ZIPPY_NOINLINE Space n309(Context& c, const Env& e) { auto a=n310(c,e); if(a.empty()) return a; return compose(a,n313(c,e)); }
static ZIPPY_NOINLINE Path n317(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Space n318(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n316(Context& c, const Env& e) { auto p=n317(c,e); return unwrap(n318(c,e),p); }
static ZIPPY_NOINLINE Space n308(Context& c, const Env& e) { auto a=n309(c,e); if(a.empty()) return a; return compose(a,n316(c,e)); }
static ZIPPY_NOINLINE Space n302(Context& c, const Env& e) { auto a=n303(c,e); if(a.empty()) return a; return compose(a,n308(c,e)); }
static ZIPPY_NOINLINE Space n266(Context& c, const Env& e) { auto a=n267(c,e); auto b=n302(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n322(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n321(Context& c, const Env& e) { return singleton(n322(c,e)); }
static ZIPPY_NOINLINE Path n324(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Space n323(Context& c, const Env& e) { return singleton(n324(c,e)); }
static ZIPPY_NOINLINE Space n320(Context& c, const Env& e) { auto a=n321(c,e); auto b=n323(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Path n328(Context& c, const Env& e) { return Path{5}; }
static ZIPPY_NOINLINE Space n329(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n327(Context& c, const Env& e) { auto p=n328(c,e); return unwrap(n329(c,e),p); }
static ZIPPY_NOINLINE Path n331(Context& c, const Env& e) { return Path{7}; }
static ZIPPY_NOINLINE Space n332(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n330(Context& c, const Env& e) { auto p=n331(c,e); return unwrap(n332(c,e),p); }
static ZIPPY_NOINLINE Space n326(Context& c, const Env& e) { auto a=n327(c,e); if(a.empty()) return a; return compose(a,n330(c,e)); }
static ZIPPY_NOINLINE Path n334(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n335(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n333(Context& c, const Env& e) { auto p=n334(c,e); return unwrap(n335(c,e),p); }
static ZIPPY_NOINLINE Space n325(Context& c, const Env& e) { auto a=n326(c,e); if(a.empty()) return a; return compose(a,n333(c,e)); }
static ZIPPY_NOINLINE Space n319(Context& c, const Env& e) { auto a=n320(c,e); if(a.empty()) return a; return compose(a,n325(c,e)); }
static ZIPPY_NOINLINE Space n265(Context& c, const Env& e) { auto a=n266(c,e); auto b=n319(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n265(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"12 1 2 66 76 2 1 49 3 1 51 4 1 50 5 2 84 76 6 2 66 82 7 2 84 82 8 1 68 9 1 82 10 1 76 11 1 85 12 1 95"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
