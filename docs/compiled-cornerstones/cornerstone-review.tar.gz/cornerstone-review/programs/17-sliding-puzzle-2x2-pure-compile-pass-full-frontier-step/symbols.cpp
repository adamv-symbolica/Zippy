#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { static const Space value=literal_text("12 4 1 2 3 4 4 1 3 4 2 4 1 4 2 3 4 5 2 4 3 4 5 3 2 4 4 5 4 3 2 4 6 2 3 4 4 6 3 4 2 4 6 4 2 3 4 7 2 4 3 4 7 3 2 4 4 7 4 3 2"); return value; }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"7 1 2 66 76 2 1 49 3 1 51 4 1 50 5 2 84 76 6 2 66 82 7 2 84 82"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
