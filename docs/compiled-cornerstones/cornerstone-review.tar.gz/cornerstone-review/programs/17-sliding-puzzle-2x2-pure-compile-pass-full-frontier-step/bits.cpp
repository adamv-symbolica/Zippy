#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { static const Space value=literal_text("12 16 1 1 1 2 2 1 1 2 2 2 1 2 2 1 2 2 16 1 1 1 2 2 1 2 2 1 1 2 2 2 1 2 2 16 1 1 1 2 2 2 1 2 2 1 2 2 1 1 2 2 16 1 2 1 2 2 1 1 2 2 1 2 2 2 1 2 2 16 1 2 1 2 2 1 2 2 2 1 2 2 1 1 2 2 16 1 2 1 2 2 2 1 2 2 1 1 2 2 1 2 2 16 2 1 1 2 2 1 1 2 2 1 2 2 2 1 2 2 16 2 1 1 2 2 1 2 2 2 1 2 2 1 1 2 2 16 2 1 1 2 2 2 1 2 2 1 1 2 2 1 2 2 13 2 2 1 1 2 2 2 1 2 2 1 2 2 13 2 2 1 2 2 1 1 2 2 2 1 2 2 13 2 2 2 1 2 2 1 2 2 1 1 2 2"); return value; }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
