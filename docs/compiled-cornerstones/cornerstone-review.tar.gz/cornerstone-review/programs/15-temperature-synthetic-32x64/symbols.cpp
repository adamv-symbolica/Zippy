#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Path n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Path n3(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { static const Space value=literal_text("4 3 2 2 3 2 2 3 3 3 2 2 6 3 2 3 2 2 2"); return value; }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { auto p=n3(c,e); return wrap(n4(c,e),p); }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { static const Space value=literal_text("6 4 2 2 2 3 3 2 2 3 4 2 3 2 2 5 2 3 2 3 2 7 2 3 2 3 3 2 2 9 2 3 2 3 3 2 3 2 2"); return value; }
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { auto a=n2(c,e); if(a.empty()) return a; return compose(a,n5(c,e)); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { auto b=n1(c,e); auto a=n6(c,e); return restrict_to(a,b); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"3 1 4 99 101 108 108 2 1 48 3 1 49"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
