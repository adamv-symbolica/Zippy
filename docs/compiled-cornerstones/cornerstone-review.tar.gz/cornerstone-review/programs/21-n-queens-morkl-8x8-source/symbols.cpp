#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Space n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Path n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Space n13(Context&, const Env&);
static ZIPPY_NOINLINE Path n14(Context&, const Env&);
static ZIPPY_NOINLINE Space n15(Context&, const Env&);
static ZIPPY_NOINLINE Space n16(Context&, const Env&);
static ZIPPY_NOINLINE Path n17(Context&, const Env&);
static ZIPPY_NOINLINE Space n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n19(Context&, const Env&);
static ZIPPY_NOINLINE Space n20(Context&, const Env&);
static ZIPPY_NOINLINE Space n21(Context&, const Env&);
static ZIPPY_NOINLINE Path n22(Context&, const Env&);
static ZIPPY_NOINLINE Path n23(Context&, const Env&);
static ZIPPY_NOINLINE Path n24(Context&, const Env&);
static ZIPPY_NOINLINE Space n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Path n28(Context&, const Env&);
static ZIPPY_NOINLINE Space n29(Context&, const Env&);
static ZIPPY_NOINLINE Space n30(Context&, const Env&);
static ZIPPY_NOINLINE Path n31(Context&, const Env&);
static ZIPPY_NOINLINE Space n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Path n34(Context&, const Env&);
static ZIPPY_NOINLINE Space n35(Context&, const Env&);
static ZIPPY_NOINLINE Path n36(Context&, const Env&);
static ZIPPY_NOINLINE Space n37(Context&, const Env&);
static ZIPPY_NOINLINE Space n38(Context&, const Env&);
static ZIPPY_NOINLINE Path n39(Context&, const Env&);
static ZIPPY_NOINLINE Path n40(Context&, const Env&);
static ZIPPY_NOINLINE Path n41(Context&, const Env&);
static ZIPPY_NOINLINE Space n42(Context&, const Env&);
static ZIPPY_NOINLINE Space n43(Context&, const Env&);
static ZIPPY_NOINLINE Space n44(Context&, const Env&);
static ZIPPY_NOINLINE Space n45(Context&, const Env&);
static ZIPPY_NOINLINE Space n46(Context&, const Env&);
static ZIPPY_NOINLINE Space n47(Context&, const Env&);
static ZIPPY_NOINLINE Path n48(Context&, const Env&);
static ZIPPY_NOINLINE Space n49(Context&, const Env&);
static ZIPPY_NOINLINE Space n50(Context&, const Env&);
static ZIPPY_NOINLINE Path n51(Context&, const Env&);
static ZIPPY_NOINLINE Space n52(Context&, const Env&);
static ZIPPY_NOINLINE Space n53(Context&, const Env&);
static ZIPPY_NOINLINE Path n54(Context&, const Env&);
static ZIPPY_NOINLINE Space n55(Context&, const Env&);
static ZIPPY_NOINLINE Path n56(Context&, const Env&);
static ZIPPY_NOINLINE Path n57(Context&, const Env&);
static ZIPPY_NOINLINE Path n58(Context&, const Env&);
static ZIPPY_NOINLINE Space n59(Context&, const Env&);
static ZIPPY_NOINLINE Space n60(Context&, const Env&);
static ZIPPY_NOINLINE Path n61(Context&, const Env&);
static ZIPPY_NOINLINE Path n62(Context&, const Env&);
static ZIPPY_NOINLINE Path n63(Context&, const Env&);
static ZIPPY_NOINLINE Space n64(Context&, const Env&);
static ZIPPY_NOINLINE Space n65(Context&, const Env&);
static ZIPPY_NOINLINE Space n66(Context&, const Env&);
static ZIPPY_NOINLINE Space n67(Context&, const Env&);
static ZIPPY_NOINLINE Space n68(Context&, const Env&);
static ZIPPY_NOINLINE Space n69(Context&, const Env&);
static ZIPPY_NOINLINE Space n70(Context&, const Env&);
static ZIPPY_NOINLINE Space n71(Context&, const Env&);
static ZIPPY_NOINLINE Path n72(Context&, const Env&);
static ZIPPY_NOINLINE Space n73(Context&, const Env&);
static ZIPPY_NOINLINE Space n74(Context&, const Env&);
static ZIPPY_NOINLINE Path n75(Context&, const Env&);
static ZIPPY_NOINLINE Space n76(Context&, const Env&);
static ZIPPY_NOINLINE Space n77(Context&, const Env&);
static ZIPPY_NOINLINE Path n78(Context&, const Env&);
static ZIPPY_NOINLINE Space n79(Context&, const Env&);
static ZIPPY_NOINLINE Path n80(Context&, const Env&);
static ZIPPY_NOINLINE Path n81(Context&, const Env&);
static ZIPPY_NOINLINE Path n82(Context&, const Env&);
static ZIPPY_NOINLINE Path n83(Context&, const Env&);
static ZIPPY_NOINLINE Path n84(Context&, const Env&);
static ZIPPY_NOINLINE Space n85(Context&, const Env&);
static ZIPPY_NOINLINE Space n86(Context&, const Env&);
static ZIPPY_NOINLINE Path n87(Context&, const Env&);
static ZIPPY_NOINLINE Path n88(Context&, const Env&);
static ZIPPY_NOINLINE Path n89(Context&, const Env&);
static ZIPPY_NOINLINE Space n90(Context&, const Env&);
static ZIPPY_NOINLINE Space n91(Context&, const Env&);
static ZIPPY_NOINLINE Space n92(Context&, const Env&);
static ZIPPY_NOINLINE Space n93(Context&, const Env&);
static ZIPPY_NOINLINE Space n94(Context&, const Env&);
static ZIPPY_NOINLINE Space n95(Context&, const Env&);
static ZIPPY_NOINLINE Space n96(Context&, const Env&);
static ZIPPY_NOINLINE Space n97(Context&, const Env&);
static ZIPPY_NOINLINE Space n98(Context&, const Env&);
static ZIPPY_NOINLINE Space n99(Context&, const Env&);
static ZIPPY_NOINLINE Path n100(Context&, const Env&);
static ZIPPY_NOINLINE Space n101(Context&, const Env&);
static ZIPPY_NOINLINE Space n102(Context&, const Env&);
static ZIPPY_NOINLINE Path n103(Context&, const Env&);
static ZIPPY_NOINLINE Space n104(Context&, const Env&);
static ZIPPY_NOINLINE Space n105(Context&, const Env&);
static ZIPPY_NOINLINE Path n106(Context&, const Env&);
static ZIPPY_NOINLINE Space n107(Context&, const Env&);
static ZIPPY_NOINLINE Path n108(Context&, const Env&);
static ZIPPY_NOINLINE Path n109(Context&, const Env&);
static ZIPPY_NOINLINE Path n110(Context&, const Env&);
static ZIPPY_NOINLINE Path n111(Context&, const Env&);
static ZIPPY_NOINLINE Path n112(Context&, const Env&);
static ZIPPY_NOINLINE Path n113(Context&, const Env&);
static ZIPPY_NOINLINE Path n114(Context&, const Env&);
static ZIPPY_NOINLINE Space n115(Context&, const Env&);
static ZIPPY_NOINLINE Space n116(Context&, const Env&);
static ZIPPY_NOINLINE Path n117(Context&, const Env&);
static ZIPPY_NOINLINE Path n118(Context&, const Env&);
static ZIPPY_NOINLINE Path n119(Context&, const Env&);
static ZIPPY_NOINLINE Space n120(Context&, const Env&);
static ZIPPY_NOINLINE Space n121(Context&, const Env&);
static ZIPPY_NOINLINE Space n122(Context&, const Env&);
static ZIPPY_NOINLINE Space n123(Context&, const Env&);
static ZIPPY_NOINLINE Space n124(Context&, const Env&);
static ZIPPY_NOINLINE Space n125(Context&, const Env&);
static ZIPPY_NOINLINE Space n126(Context&, const Env&);
static ZIPPY_NOINLINE Space n127(Context&, const Env&);
static ZIPPY_NOINLINE Space n128(Context&, const Env&);
static ZIPPY_NOINLINE Space n129(Context&, const Env&);
static ZIPPY_NOINLINE Space n130(Context&, const Env&);
static ZIPPY_NOINLINE Space n131(Context&, const Env&);
static ZIPPY_NOINLINE Path n132(Context&, const Env&);
static ZIPPY_NOINLINE Space n133(Context&, const Env&);
static ZIPPY_NOINLINE Space n134(Context&, const Env&);
static ZIPPY_NOINLINE Path n135(Context&, const Env&);
static ZIPPY_NOINLINE Space n136(Context&, const Env&);
static ZIPPY_NOINLINE Space n137(Context&, const Env&);
static ZIPPY_NOINLINE Path n138(Context&, const Env&);
static ZIPPY_NOINLINE Space n139(Context&, const Env&);
static ZIPPY_NOINLINE Path n140(Context&, const Env&);
static ZIPPY_NOINLINE Path n141(Context&, const Env&);
static ZIPPY_NOINLINE Path n142(Context&, const Env&);
static ZIPPY_NOINLINE Path n143(Context&, const Env&);
static ZIPPY_NOINLINE Path n144(Context&, const Env&);
static ZIPPY_NOINLINE Path n145(Context&, const Env&);
static ZIPPY_NOINLINE Path n146(Context&, const Env&);
static ZIPPY_NOINLINE Path n147(Context&, const Env&);
static ZIPPY_NOINLINE Path n148(Context&, const Env&);
static ZIPPY_NOINLINE Space n149(Context&, const Env&);
static ZIPPY_NOINLINE Space n150(Context&, const Env&);
static ZIPPY_NOINLINE Path n151(Context&, const Env&);
static ZIPPY_NOINLINE Path n152(Context&, const Env&);
static ZIPPY_NOINLINE Path n153(Context&, const Env&);
static ZIPPY_NOINLINE Space n154(Context&, const Env&);
static ZIPPY_NOINLINE Space n155(Context&, const Env&);
static ZIPPY_NOINLINE Space n156(Context&, const Env&);
static ZIPPY_NOINLINE Space n157(Context&, const Env&);
static ZIPPY_NOINLINE Space n158(Context&, const Env&);
static ZIPPY_NOINLINE Space n159(Context&, const Env&);
static ZIPPY_NOINLINE Space n160(Context&, const Env&);
static ZIPPY_NOINLINE Space n161(Context&, const Env&);
static ZIPPY_NOINLINE Space n162(Context&, const Env&);
static ZIPPY_NOINLINE Space n163(Context&, const Env&);
static ZIPPY_NOINLINE Space n164(Context&, const Env&);
static ZIPPY_NOINLINE Space n165(Context&, const Env&);
static ZIPPY_NOINLINE Space n166(Context&, const Env&);
static ZIPPY_NOINLINE Space n167(Context&, const Env&);
static ZIPPY_NOINLINE Path n168(Context&, const Env&);
static ZIPPY_NOINLINE Space n169(Context&, const Env&);
static ZIPPY_NOINLINE Space n170(Context&, const Env&);
static ZIPPY_NOINLINE Path n171(Context&, const Env&);
static ZIPPY_NOINLINE Space n172(Context&, const Env&);
static ZIPPY_NOINLINE Space n173(Context&, const Env&);
static ZIPPY_NOINLINE Path n174(Context&, const Env&);
static ZIPPY_NOINLINE Space n175(Context&, const Env&);
static ZIPPY_NOINLINE Path n176(Context&, const Env&);
static ZIPPY_NOINLINE Path n177(Context&, const Env&);
static ZIPPY_NOINLINE Path n178(Context&, const Env&);
static ZIPPY_NOINLINE Path n179(Context&, const Env&);
static ZIPPY_NOINLINE Path n180(Context&, const Env&);
static ZIPPY_NOINLINE Path n181(Context&, const Env&);
static ZIPPY_NOINLINE Path n182(Context&, const Env&);
static ZIPPY_NOINLINE Path n183(Context&, const Env&);
static ZIPPY_NOINLINE Path n184(Context&, const Env&);
static ZIPPY_NOINLINE Path n185(Context&, const Env&);
static ZIPPY_NOINLINE Path n186(Context&, const Env&);
static ZIPPY_NOINLINE Space n187(Context&, const Env&);
static ZIPPY_NOINLINE Space n188(Context&, const Env&);
static ZIPPY_NOINLINE Path n189(Context&, const Env&);
static ZIPPY_NOINLINE Path n190(Context&, const Env&);
static ZIPPY_NOINLINE Path n191(Context&, const Env&);
static ZIPPY_NOINLINE Space n192(Context&, const Env&);
static ZIPPY_NOINLINE Space n193(Context&, const Env&);
static ZIPPY_NOINLINE Space n194(Context&, const Env&);
static ZIPPY_NOINLINE Space n195(Context&, const Env&);
static ZIPPY_NOINLINE Space n196(Context&, const Env&);
static ZIPPY_NOINLINE Space n197(Context&, const Env&);
static ZIPPY_NOINLINE Space n198(Context&, const Env&);
static ZIPPY_NOINLINE Space n199(Context&, const Env&);
static ZIPPY_NOINLINE Space n200(Context&, const Env&);
static ZIPPY_NOINLINE Space n201(Context&, const Env&);
static ZIPPY_NOINLINE Space n202(Context&, const Env&);
static ZIPPY_NOINLINE Space n203(Context&, const Env&);
static ZIPPY_NOINLINE Space n204(Context&, const Env&);
static ZIPPY_NOINLINE Space n205(Context&, const Env&);
static ZIPPY_NOINLINE Space n206(Context&, const Env&);
static ZIPPY_NOINLINE Space n207(Context&, const Env&);
static ZIPPY_NOINLINE Path n208(Context&, const Env&);
static ZIPPY_NOINLINE Space n209(Context&, const Env&);
static ZIPPY_NOINLINE Space n210(Context&, const Env&);
static ZIPPY_NOINLINE Path n211(Context&, const Env&);
static ZIPPY_NOINLINE Space n212(Context&, const Env&);
static ZIPPY_NOINLINE Space n213(Context&, const Env&);
static ZIPPY_NOINLINE Path n214(Context&, const Env&);
static ZIPPY_NOINLINE Space n215(Context&, const Env&);
static ZIPPY_NOINLINE Path n216(Context&, const Env&);
static ZIPPY_NOINLINE Path n217(Context&, const Env&);
static ZIPPY_NOINLINE Path n218(Context&, const Env&);
static ZIPPY_NOINLINE Path n219(Context&, const Env&);
static ZIPPY_NOINLINE Path n220(Context&, const Env&);
static ZIPPY_NOINLINE Path n221(Context&, const Env&);
static ZIPPY_NOINLINE Path n222(Context&, const Env&);
static ZIPPY_NOINLINE Path n223(Context&, const Env&);
static ZIPPY_NOINLINE Path n224(Context&, const Env&);
static ZIPPY_NOINLINE Path n225(Context&, const Env&);
static ZIPPY_NOINLINE Path n226(Context&, const Env&);
static ZIPPY_NOINLINE Path n227(Context&, const Env&);
static ZIPPY_NOINLINE Path n228(Context&, const Env&);
static ZIPPY_NOINLINE Space n229(Context&, const Env&);
static ZIPPY_NOINLINE Space n230(Context&, const Env&);
static ZIPPY_NOINLINE Path n231(Context&, const Env&);
static ZIPPY_NOINLINE Path n232(Context&, const Env&);
static ZIPPY_NOINLINE Path n233(Context&, const Env&);
static ZIPPY_NOINLINE Space n234(Context&, const Env&);
static ZIPPY_NOINLINE Space n235(Context&, const Env&);
static ZIPPY_NOINLINE Space n236(Context&, const Env&);
static ZIPPY_NOINLINE Space n237(Context&, const Env&);
static ZIPPY_NOINLINE Space n238(Context&, const Env&);
static ZIPPY_NOINLINE Space n239(Context&, const Env&);
static ZIPPY_NOINLINE Space n240(Context&, const Env&);
static ZIPPY_NOINLINE Space n241(Context&, const Env&);
static ZIPPY_NOINLINE Space n242(Context&, const Env&);
static ZIPPY_NOINLINE Space n243(Context&, const Env&);
static ZIPPY_NOINLINE Space n244(Context&, const Env&);
static ZIPPY_NOINLINE Space n245(Context&, const Env&);
static ZIPPY_NOINLINE Space n246(Context&, const Env&);
static ZIPPY_NOINLINE Space n247(Context&, const Env&);
static ZIPPY_NOINLINE Space n248(Context&, const Env&);
static ZIPPY_NOINLINE Space n249(Context&, const Env&);
static ZIPPY_NOINLINE Path n250(Context&, const Env&);
static ZIPPY_NOINLINE Path n251(Context&, const Env&);
static ZIPPY_NOINLINE Path n252(Context&, const Env&);
static ZIPPY_NOINLINE Path n253(Context&, const Env&);
static ZIPPY_NOINLINE Path n254(Context&, const Env&);
static ZIPPY_NOINLINE Path n255(Context&, const Env&);
static ZIPPY_NOINLINE Path n256(Context&, const Env&);
static ZIPPY_NOINLINE Path n257(Context&, const Env&);
static ZIPPY_NOINLINE Path n258(Context&, const Env&);
static ZIPPY_NOINLINE Path n259(Context&, const Env&);
static ZIPPY_NOINLINE Path n260(Context&, const Env&);
static ZIPPY_NOINLINE Path n261(Context&, const Env&);
static ZIPPY_NOINLINE Path n262(Context&, const Env&);
static ZIPPY_NOINLINE Path n263(Context&, const Env&);
static ZIPPY_NOINLINE Path n264(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n265(Context&, const Env&);
static ZIPPY_NOINLINE Space n266(Context&, const Env&);
static ZIPPY_NOINLINE Space n267(Context&, const Env&);
static ZIPPY_NOINLINE Path n268(Context&, const Env&);
static ZIPPY_NOINLINE Space n269(Context&, const Env&);
static ZIPPY_NOINLINE Space n270(Context&, const Env&);
static ZIPPY_NOINLINE Space n271(Context&, const Env&);
static ZIPPY_NOINLINE Space n272(Context&, const Env&);
static ZIPPY_NOINLINE Space n273(Context&, const Env&);
static ZIPPY_NOINLINE Space n274(Context&, const Env&);
static ZIPPY_NOINLINE Space n275(Context&, const Env&);
static ZIPPY_NOINLINE Path n276(Context&, const Env&);
static ZIPPY_NOINLINE Space n277(Context&, const Env&);
static ZIPPY_NOINLINE Path n278(Context&, const Env&);
static ZIPPY_NOINLINE Space n279(Context&, const Env&);
static ZIPPY_NOINLINE Path n280(Context&, const Env&);
static ZIPPY_NOINLINE Space n281(Context&, const Env&);
static ZIPPY_NOINLINE Path n282(Context&, const Env&);
static ZIPPY_NOINLINE Space n283(Context&, const Env&);
static ZIPPY_NOINLINE Space n284(Context&, const Env&);
static ZIPPY_NOINLINE Path n285(Context&, const Env&);
static ZIPPY_NOINLINE Space n286(Context&, const Env&);
static ZIPPY_NOINLINE Path n287(Context&, const Env&);
static ZIPPY_NOINLINE Space n288(Context&, const Env&);
static ZIPPY_NOINLINE Space n289(Context&, const Env&);
static ZIPPY_NOINLINE Path n290(Context&, const Env&);
static ZIPPY_NOINLINE Space n291(Context&, const Env&);
static ZIPPY_NOINLINE Path n292(Context&, const Env&);
static ZIPPY_NOINLINE Space n293(Context&, const Env&);
static ZIPPY_NOINLINE Space n294(Context&, const Env&);
static ZIPPY_NOINLINE Space n295(Context&, const Env&);
static ZIPPY_NOINLINE Path n296(Context&, const Env&);
static ZIPPY_NOINLINE Space n297(Context&, const Env&);
static ZIPPY_NOINLINE Path n298(Context&, const Env&);
static ZIPPY_NOINLINE Space n299(Context&, const Env&);
static ZIPPY_NOINLINE Space n300(Context&, const Env&);
static ZIPPY_NOINLINE Path n301(Context&, const Env&);
static ZIPPY_NOINLINE Space n302(Context&, const Env&);
static ZIPPY_NOINLINE Path n303(Context&, const Env&);
static ZIPPY_NOINLINE Space n304(Context&, const Env&);
static ZIPPY_NOINLINE Space n305(Context&, const Env&);
static ZIPPY_NOINLINE Space n306(Context&, const Env&);
static ZIPPY_NOINLINE Path n307(Context&, const Env&);
static ZIPPY_NOINLINE Space n308(Context&, const Env&);
static ZIPPY_NOINLINE Path n309(Context&, const Env&);
static ZIPPY_NOINLINE Space n310(Context&, const Env&);
static ZIPPY_NOINLINE Space n311(Context&, const Env&);
static ZIPPY_NOINLINE Path n312(Context&, const Env&);
static ZIPPY_NOINLINE Space n313(Context&, const Env&);
static ZIPPY_NOINLINE Path n314(Context&, const Env&);
static ZIPPY_NOINLINE Space n315(Context&, const Env&);
static ZIPPY_NOINLINE Space n316(Context&, const Env&);
static ZIPPY_NOINLINE Space n317(Context&, const Env&);
static ZIPPY_NOINLINE Path n318(Context&, const Env&);
static ZIPPY_NOINLINE Space n319(Context&, const Env&);
static ZIPPY_NOINLINE Path n320(Context&, const Env&);
static ZIPPY_NOINLINE Space n321(Context&, const Env&);
static ZIPPY_NOINLINE Space n322(Context&, const Env&);
static ZIPPY_NOINLINE Path n323(Context&, const Env&);
static ZIPPY_NOINLINE Space n324(Context&, const Env&);
static ZIPPY_NOINLINE Path n325(Context&, const Env&);
static ZIPPY_NOINLINE Space n326(Context&, const Env&);
static ZIPPY_NOINLINE Space n327(Context&, const Env&);
static ZIPPY_NOINLINE Space n328(Context&, const Env&);
static ZIPPY_NOINLINE Path n329(Context&, const Env&);
static ZIPPY_NOINLINE Space n330(Context&, const Env&);
static ZIPPY_NOINLINE Space n331(Context&, const Env&);
static ZIPPY_NOINLINE Path n332(Context&, const Env&);
static ZIPPY_NOINLINE Space n333(Context&, const Env&);
static ZIPPY_NOINLINE Path n11(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { static const Space value=literal_text("36 2 1 1 2 1 2 2 1 3 2 1 4 2 1 5 2 1 6 2 1 7 2 1 8 2 2 2 2 2 7 2 3 2 2 3 3 2 3 5 2 3 6 2 3 7 2 4 2 2 4 3 2 4 4 2 4 5 2 4 6 2 4 7 2 4 8 2 5 2 2 5 5 2 5 7 2 6 2 2 6 5 2 6 6 2 6 7 2 7 7 2 8 2 2 8 3 2 8 5 2 8 6 2 8 7 2 8 8"); return value; }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { auto p=n11(c,e); return unwrap(n12(c,e),p); }
static ZIPPY_NOINLINE Path n14(Context& c, const Env& e) { return Path{7}; }
static ZIPPY_NOINLINE Space n15(Context& c, const Env& e) { return Space(); }
static ZIPPY_NOINLINE Space n13(Context& c, const Env& e) { auto p=n14(c,e); return unwrap(n15(c,e),p); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { auto a=n10(c,e); auto b=n13(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n17(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n19(Context& c, const Env& e) { return Path{}; }
static ZIPPY_NOINLINE Path n22(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n23(Context& c, const Env& e) { return Path{7}; }
static ZIPPY_NOINLINE Path n24(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n21(Context& c, const Env& e) { std::vector<Path> pv{n22(c,e),n23(c,e),n24(c,e)}; std::vector<Space> sv{}; Env n; n.paths[1]=pv[0];n.paths[2]=pv[1];n.paths[3]=pv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n20(Context& c, const Env& e) { auto a=n21(c,e); auto b=n15(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n18(Context& c, const Env& e) { auto p=n19(c,e); return wrap(n20(c,e),p); }
static ZIPPY_NOINLINE Space n16(Context& c, const Env& e) { auto p=n17(c,e); return wrap(n18(c,e),p); }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { return iterate(c,e,n9(c,e),0,-1,n16); }
static ZIPPY_NOINLINE Path n28(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n29(Context& c, const Env& e) { static const Space value=literal_text("36 2 1 1 2 1 2 2 1 3 2 1 4 2 1 5 2 1 6 2 1 7 2 1 8 2 2 2 2 2 7 2 3 2 2 3 3 2 3 5 2 3 6 2 3 7 2 4 2 2 4 3 2 4 4 2 4 5 2 4 6 2 4 7 2 4 8 2 5 2 2 5 5 2 5 7 2 6 2 2 6 5 2 6 6 2 6 7 2 7 7 2 8 2 2 8 3 2 8 5 2 8 6 2 8 7 2 8 8"); return value; }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { auto p=n28(c,e); return unwrap(n29(c,e),p); }
static ZIPPY_NOINLINE Path n31(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Space n32(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n30(Context& c, const Env& e) { auto p=n31(c,e); return unwrap(n32(c,e),p); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { auto a=n27(c,e); auto b=n30(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n34(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n36(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n39(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n40(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n41(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n38(Context& c, const Env& e) { std::vector<Path> pv{n39(c,e),n40(c,e),n41(c,e)}; std::vector<Space> sv{}; Env n; n.paths[1]=pv[0];n.paths[2]=pv[1];n.paths[3]=pv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n42(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n37(Context& c, const Env& e) { auto a=n38(c,e); auto b=n42(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n35(Context& c, const Env& e) { auto p=n36(c,e); return wrap(n37(c,e),p); }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { auto p=n34(c,e); return wrap(n35(c,e),p); }
static ZIPPY_NOINLINE Space n25(Context& c, const Env& e) { return iterate(c,e,n26(c,e),0,-1,n33); }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { return iterate(c,e,n8(c,e),4,0,n25); }
static ZIPPY_NOINLINE Space n44(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Path n48(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n49(Context& c, const Env& e) { static const Space value=literal_text("36 2 1 1 2 1 2 2 1 3 2 1 4 2 1 5 2 1 6 2 1 7 2 1 8 2 2 2 2 2 7 2 3 2 2 3 3 2 3 5 2 3 6 2 3 7 2 4 2 2 4 3 2 4 4 2 4 5 2 4 6 2 4 7 2 4 8 2 5 2 2 5 5 2 5 7 2 6 2 2 6 5 2 6 6 2 6 7 2 7 7 2 8 2 2 8 3 2 8 5 2 8 6 2 8 7 2 8 8"); return value; }
static ZIPPY_NOINLINE Space n47(Context& c, const Env& e) { auto p=n48(c,e); return unwrap(n49(c,e),p); }
static ZIPPY_NOINLINE Path n51(Context& c, const Env& e) { return Path{5}; }
static ZIPPY_NOINLINE Space n52(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n50(Context& c, const Env& e) { auto p=n51(c,e); return unwrap(n52(c,e),p); }
static ZIPPY_NOINLINE Space n46(Context& c, const Env& e) { auto a=n47(c,e); auto b=n50(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n54(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n57(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Path n58(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Path n56(Context& c, const Env& e) { auto a=n57(c,e); auto b=n58(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n61(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n62(Context& c, const Env& e) { return Path{5}; }
static ZIPPY_NOINLINE Path n63(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n60(Context& c, const Env& e) { std::vector<Path> pv{n61(c,e),n62(c,e),n63(c,e)}; std::vector<Space> sv{}; Env n; n.paths[1]=pv[0];n.paths[2]=pv[1];n.paths[3]=pv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n64(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n59(Context& c, const Env& e) { auto a=n60(c,e); auto b=n64(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n55(Context& c, const Env& e) { auto p=n56(c,e); return wrap(n59(c,e),p); }
static ZIPPY_NOINLINE Space n53(Context& c, const Env& e) { auto p=n54(c,e); return wrap(n55(c,e),p); }
static ZIPPY_NOINLINE Space n45(Context& c, const Env& e) { return iterate(c,e,n46(c,e),0,-1,n53); }
static ZIPPY_NOINLINE Space n43(Context& c, const Env& e) { return iterate(c,e,n44(c,e),6,0,n45); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { return iterate(c,e,n7(c,e),5,1,n43); }
static ZIPPY_NOINLINE Space n66(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n68(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n72(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n73(Context& c, const Env& e) { static const Space value=literal_text("36 2 1 1 2 1 2 2 1 3 2 1 4 2 1 5 2 1 6 2 1 7 2 1 8 2 2 2 2 2 7 2 3 2 2 3 3 2 3 5 2 3 6 2 3 7 2 4 2 2 4 3 2 4 4 2 4 5 2 4 6 2 4 7 2 4 8 2 5 2 2 5 5 2 5 7 2 6 2 2 6 5 2 6 6 2 6 7 2 7 7 2 8 2 2 8 3 2 8 5 2 8 6 2 8 7 2 8 8"); return value; }
static ZIPPY_NOINLINE Space n71(Context& c, const Env& e) { auto p=n72(c,e); return unwrap(n73(c,e),p); }
static ZIPPY_NOINLINE Path n75(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Space n76(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n74(Context& c, const Env& e) { auto p=n75(c,e); return unwrap(n76(c,e),p); }
static ZIPPY_NOINLINE Space n70(Context& c, const Env& e) { auto a=n71(c,e); auto b=n74(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n78(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n82(Context& c, const Env& e) { return e.paths.at(7); }
static ZIPPY_NOINLINE Path n83(Context& c, const Env& e) { return e.paths.at(8); }
static ZIPPY_NOINLINE Path n81(Context& c, const Env& e) { auto a=n82(c,e); auto b=n83(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n84(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Path n80(Context& c, const Env& e) { auto a=n81(c,e); auto b=n84(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n87(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n88(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Path n89(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n86(Context& c, const Env& e) { std::vector<Path> pv{n87(c,e),n88(c,e),n89(c,e)}; std::vector<Space> sv{}; Env n; n.paths[1]=pv[0];n.paths[2]=pv[1];n.paths[3]=pv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n90(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n85(Context& c, const Env& e) { auto a=n86(c,e); auto b=n90(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n79(Context& c, const Env& e) { auto p=n80(c,e); return wrap(n85(c,e),p); }
static ZIPPY_NOINLINE Space n77(Context& c, const Env& e) { auto p=n78(c,e); return wrap(n79(c,e),p); }
static ZIPPY_NOINLINE Space n69(Context& c, const Env& e) { return iterate(c,e,n70(c,e),0,-1,n77); }
static ZIPPY_NOINLINE Space n67(Context& c, const Env& e) { return iterate(c,e,n68(c,e),9,0,n69); }
static ZIPPY_NOINLINE Space n65(Context& c, const Env& e) { return iterate(c,e,n66(c,e),8,3,n67); }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return iterate(c,e,n6(c,e),7,2,n65); }
static ZIPPY_NOINLINE Space n92(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Space n94(Context& c, const Env& e) { return e.spaces.at(5); }
static ZIPPY_NOINLINE Space n96(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Path n100(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n101(Context& c, const Env& e) { static const Space value=literal_text("36 2 1 1 2 1 2 2 1 3 2 1 4 2 1 5 2 1 6 2 1 7 2 1 8 2 2 2 2 2 7 2 3 2 2 3 3 2 3 5 2 3 6 2 3 7 2 4 2 2 4 3 2 4 4 2 4 5 2 4 6 2 4 7 2 4 8 2 5 2 2 5 5 2 5 7 2 6 2 2 6 5 2 6 6 2 6 7 2 7 7 2 8 2 2 8 3 2 8 5 2 8 6 2 8 7 2 8 8"); return value; }
static ZIPPY_NOINLINE Space n99(Context& c, const Env& e) { auto p=n100(c,e); return unwrap(n101(c,e),p); }
static ZIPPY_NOINLINE Path n103(Context& c, const Env& e) { return Path{3}; }
static ZIPPY_NOINLINE Space n104(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n102(Context& c, const Env& e) { auto p=n103(c,e); return unwrap(n104(c,e),p); }
static ZIPPY_NOINLINE Space n98(Context& c, const Env& e) { auto a=n99(c,e); auto b=n102(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n106(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n111(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n112(Context& c, const Env& e) { return e.paths.at(11); }
static ZIPPY_NOINLINE Path n110(Context& c, const Env& e) { auto a=n111(c,e); auto b=n112(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n113(Context& c, const Env& e) { return e.paths.at(12); }
static ZIPPY_NOINLINE Path n109(Context& c, const Env& e) { auto a=n110(c,e); auto b=n113(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n114(Context& c, const Env& e) { return e.paths.at(13); }
static ZIPPY_NOINLINE Path n108(Context& c, const Env& e) { auto a=n109(c,e); auto b=n114(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n117(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n118(Context& c, const Env& e) { return Path{3}; }
static ZIPPY_NOINLINE Path n119(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n116(Context& c, const Env& e) { std::vector<Path> pv{n117(c,e),n118(c,e),n119(c,e)}; std::vector<Space> sv{}; Env n; n.paths[1]=pv[0];n.paths[2]=pv[1];n.paths[3]=pv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n120(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n115(Context& c, const Env& e) { auto a=n116(c,e); auto b=n120(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n107(Context& c, const Env& e) { auto p=n108(c,e); return wrap(n115(c,e),p); }
static ZIPPY_NOINLINE Space n105(Context& c, const Env& e) { auto p=n106(c,e); return wrap(n107(c,e),p); }
static ZIPPY_NOINLINE Space n97(Context& c, const Env& e) { return iterate(c,e,n98(c,e),0,-1,n105); }
static ZIPPY_NOINLINE Space n95(Context& c, const Env& e) { return iterate(c,e,n96(c,e),13,0,n97); }
static ZIPPY_NOINLINE Space n93(Context& c, const Env& e) { return iterate(c,e,n94(c,e),12,6,n95); }
static ZIPPY_NOINLINE Space n91(Context& c, const Env& e) { return iterate(c,e,n92(c,e),11,5,n93); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { return iterate(c,e,n5(c,e),10,4,n91); }
static ZIPPY_NOINLINE Space n122(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n124(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Space n126(Context& c, const Env& e) { return e.spaces.at(9); }
static ZIPPY_NOINLINE Space n128(Context& c, const Env& e) { return e.spaces.at(10); }
static ZIPPY_NOINLINE Path n132(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n133(Context& c, const Env& e) { static const Space value=literal_text("36 2 1 1 2 1 2 2 1 3 2 1 4 2 1 5 2 1 6 2 1 7 2 1 8 2 2 2 2 2 7 2 3 2 2 3 3 2 3 5 2 3 6 2 3 7 2 4 2 2 4 3 2 4 4 2 4 5 2 4 6 2 4 7 2 4 8 2 5 2 2 5 5 2 5 7 2 6 2 2 6 5 2 6 6 2 6 7 2 7 7 2 8 2 2 8 3 2 8 5 2 8 6 2 8 7 2 8 8"); return value; }
static ZIPPY_NOINLINE Space n131(Context& c, const Env& e) { auto p=n132(c,e); return unwrap(n133(c,e),p); }
static ZIPPY_NOINLINE Path n135(Context& c, const Env& e) { return Path{8}; }
static ZIPPY_NOINLINE Space n136(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n134(Context& c, const Env& e) { auto p=n135(c,e); return unwrap(n136(c,e),p); }
static ZIPPY_NOINLINE Space n130(Context& c, const Env& e) { auto a=n131(c,e); auto b=n134(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n138(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n144(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Path n145(Context& c, const Env& e) { return e.paths.at(15); }
static ZIPPY_NOINLINE Path n143(Context& c, const Env& e) { auto a=n144(c,e); auto b=n145(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n146(Context& c, const Env& e) { return e.paths.at(16); }
static ZIPPY_NOINLINE Path n142(Context& c, const Env& e) { auto a=n143(c,e); auto b=n146(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n147(Context& c, const Env& e) { return e.paths.at(17); }
static ZIPPY_NOINLINE Path n141(Context& c, const Env& e) { auto a=n142(c,e); auto b=n147(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n148(Context& c, const Env& e) { return e.paths.at(18); }
static ZIPPY_NOINLINE Path n140(Context& c, const Env& e) { auto a=n141(c,e); auto b=n148(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n151(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n152(Context& c, const Env& e) { return Path{8}; }
static ZIPPY_NOINLINE Path n153(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n150(Context& c, const Env& e) { std::vector<Path> pv{n151(c,e),n152(c,e),n153(c,e)}; std::vector<Space> sv{}; Env n; n.paths[1]=pv[0];n.paths[2]=pv[1];n.paths[3]=pv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n154(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n149(Context& c, const Env& e) { auto a=n150(c,e); auto b=n154(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n139(Context& c, const Env& e) { auto p=n140(c,e); return wrap(n149(c,e),p); }
static ZIPPY_NOINLINE Space n137(Context& c, const Env& e) { auto p=n138(c,e); return wrap(n139(c,e),p); }
static ZIPPY_NOINLINE Space n129(Context& c, const Env& e) { return iterate(c,e,n130(c,e),0,-1,n137); }
static ZIPPY_NOINLINE Space n127(Context& c, const Env& e) { return iterate(c,e,n128(c,e),18,0,n129); }
static ZIPPY_NOINLINE Space n125(Context& c, const Env& e) { return iterate(c,e,n126(c,e),17,10,n127); }
static ZIPPY_NOINLINE Space n123(Context& c, const Env& e) { return iterate(c,e,n124(c,e),16,9,n125); }
static ZIPPY_NOINLINE Space n121(Context& c, const Env& e) { return iterate(c,e,n122(c,e),15,8,n123); }
static ZIPPY_NOINLINE Space n3(Context& c, const Env& e) { return iterate(c,e,n4(c,e),14,7,n121); }
static ZIPPY_NOINLINE Space n156(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Space n158(Context& c, const Env& e) { return e.spaces.at(12); }
static ZIPPY_NOINLINE Space n160(Context& c, const Env& e) { return e.spaces.at(13); }
static ZIPPY_NOINLINE Space n162(Context& c, const Env& e) { return e.spaces.at(14); }
static ZIPPY_NOINLINE Space n164(Context& c, const Env& e) { return e.spaces.at(15); }
static ZIPPY_NOINLINE Path n168(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n169(Context& c, const Env& e) { static const Space value=literal_text("36 2 1 1 2 1 2 2 1 3 2 1 4 2 1 5 2 1 6 2 1 7 2 1 8 2 2 2 2 2 7 2 3 2 2 3 3 2 3 5 2 3 6 2 3 7 2 4 2 2 4 3 2 4 4 2 4 5 2 4 6 2 4 7 2 4 8 2 5 2 2 5 5 2 5 7 2 6 2 2 6 5 2 6 6 2 6 7 2 7 7 2 8 2 2 8 3 2 8 5 2 8 6 2 8 7 2 8 8"); return value; }
static ZIPPY_NOINLINE Space n167(Context& c, const Env& e) { auto p=n168(c,e); return unwrap(n169(c,e),p); }
static ZIPPY_NOINLINE Path n171(Context& c, const Env& e) { return Path{4}; }
static ZIPPY_NOINLINE Space n172(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n170(Context& c, const Env& e) { auto p=n171(c,e); return unwrap(n172(c,e),p); }
static ZIPPY_NOINLINE Space n166(Context& c, const Env& e) { auto a=n167(c,e); auto b=n170(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n174(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n181(Context& c, const Env& e) { return e.paths.at(19); }
static ZIPPY_NOINLINE Path n182(Context& c, const Env& e) { return e.paths.at(20); }
static ZIPPY_NOINLINE Path n180(Context& c, const Env& e) { auto a=n181(c,e); auto b=n182(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n183(Context& c, const Env& e) { return e.paths.at(21); }
static ZIPPY_NOINLINE Path n179(Context& c, const Env& e) { auto a=n180(c,e); auto b=n183(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n184(Context& c, const Env& e) { return e.paths.at(22); }
static ZIPPY_NOINLINE Path n178(Context& c, const Env& e) { auto a=n179(c,e); auto b=n184(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n185(Context& c, const Env& e) { return e.paths.at(23); }
static ZIPPY_NOINLINE Path n177(Context& c, const Env& e) { auto a=n178(c,e); auto b=n185(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n186(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Path n176(Context& c, const Env& e) { auto a=n177(c,e); auto b=n186(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n189(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n190(Context& c, const Env& e) { return Path{4}; }
static ZIPPY_NOINLINE Path n191(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n188(Context& c, const Env& e) { std::vector<Path> pv{n189(c,e),n190(c,e),n191(c,e)}; std::vector<Space> sv{}; Env n; n.paths[1]=pv[0];n.paths[2]=pv[1];n.paths[3]=pv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n192(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n187(Context& c, const Env& e) { auto a=n188(c,e); auto b=n192(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n175(Context& c, const Env& e) { auto p=n176(c,e); return wrap(n187(c,e),p); }
static ZIPPY_NOINLINE Space n173(Context& c, const Env& e) { auto p=n174(c,e); return wrap(n175(c,e),p); }
static ZIPPY_NOINLINE Space n165(Context& c, const Env& e) { return iterate(c,e,n166(c,e),0,-1,n173); }
static ZIPPY_NOINLINE Space n163(Context& c, const Env& e) { return iterate(c,e,n164(c,e),24,0,n165); }
static ZIPPY_NOINLINE Space n161(Context& c, const Env& e) { return iterate(c,e,n162(c,e),23,15,n163); }
static ZIPPY_NOINLINE Space n159(Context& c, const Env& e) { return iterate(c,e,n160(c,e),22,14,n161); }
static ZIPPY_NOINLINE Space n157(Context& c, const Env& e) { return iterate(c,e,n158(c,e),21,13,n159); }
static ZIPPY_NOINLINE Space n155(Context& c, const Env& e) { return iterate(c,e,n156(c,e),20,12,n157); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { return iterate(c,e,n3(c,e),19,11,n155); }
static ZIPPY_NOINLINE Space n194(Context& c, const Env& e) { return e.spaces.at(16); }
static ZIPPY_NOINLINE Space n196(Context& c, const Env& e) { return e.spaces.at(17); }
static ZIPPY_NOINLINE Space n198(Context& c, const Env& e) { return e.spaces.at(18); }
static ZIPPY_NOINLINE Space n200(Context& c, const Env& e) { return e.spaces.at(19); }
static ZIPPY_NOINLINE Space n202(Context& c, const Env& e) { return e.spaces.at(20); }
static ZIPPY_NOINLINE Space n204(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Path n208(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n209(Context& c, const Env& e) { static const Space value=literal_text("36 2 1 1 2 1 2 2 1 3 2 1 4 2 1 5 2 1 6 2 1 7 2 1 8 2 2 2 2 2 7 2 3 2 2 3 3 2 3 5 2 3 6 2 3 7 2 4 2 2 4 3 2 4 4 2 4 5 2 4 6 2 4 7 2 4 8 2 5 2 2 5 5 2 5 7 2 6 2 2 6 5 2 6 6 2 6 7 2 7 7 2 8 2 2 8 3 2 8 5 2 8 6 2 8 7 2 8 8"); return value; }
static ZIPPY_NOINLINE Space n207(Context& c, const Env& e) { auto p=n208(c,e); return unwrap(n209(c,e),p); }
static ZIPPY_NOINLINE Path n211(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n212(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n210(Context& c, const Env& e) { auto p=n211(c,e); return unwrap(n212(c,e),p); }
static ZIPPY_NOINLINE Space n206(Context& c, const Env& e) { auto a=n207(c,e); auto b=n210(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n214(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n222(Context& c, const Env& e) { return e.paths.at(25); }
static ZIPPY_NOINLINE Path n223(Context& c, const Env& e) { return e.paths.at(26); }
static ZIPPY_NOINLINE Path n221(Context& c, const Env& e) { auto a=n222(c,e); auto b=n223(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n224(Context& c, const Env& e) { return e.paths.at(27); }
static ZIPPY_NOINLINE Path n220(Context& c, const Env& e) { auto a=n221(c,e); auto b=n224(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n225(Context& c, const Env& e) { return e.paths.at(28); }
static ZIPPY_NOINLINE Path n219(Context& c, const Env& e) { auto a=n220(c,e); auto b=n225(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n226(Context& c, const Env& e) { return e.paths.at(29); }
static ZIPPY_NOINLINE Path n218(Context& c, const Env& e) { auto a=n219(c,e); auto b=n226(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n227(Context& c, const Env& e) { return e.paths.at(30); }
static ZIPPY_NOINLINE Path n217(Context& c, const Env& e) { auto a=n218(c,e); auto b=n227(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n228(Context& c, const Env& e) { return e.paths.at(31); }
static ZIPPY_NOINLINE Path n216(Context& c, const Env& e) { auto a=n217(c,e); auto b=n228(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n231(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n232(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Path n233(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n230(Context& c, const Env& e) { std::vector<Path> pv{n231(c,e),n232(c,e),n233(c,e)}; std::vector<Space> sv{}; Env n; n.paths[1]=pv[0];n.paths[2]=pv[1];n.paths[3]=pv[2];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n234(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n229(Context& c, const Env& e) { auto a=n230(c,e); auto b=n234(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n215(Context& c, const Env& e) { auto p=n216(c,e); return wrap(n229(c,e),p); }
static ZIPPY_NOINLINE Space n213(Context& c, const Env& e) { auto p=n214(c,e); return wrap(n215(c,e),p); }
static ZIPPY_NOINLINE Space n205(Context& c, const Env& e) { return iterate(c,e,n206(c,e),0,-1,n213); }
static ZIPPY_NOINLINE Space n203(Context& c, const Env& e) { return iterate(c,e,n204(c,e),31,0,n205); }
static ZIPPY_NOINLINE Space n201(Context& c, const Env& e) { return iterate(c,e,n202(c,e),30,21,n203); }
static ZIPPY_NOINLINE Space n199(Context& c, const Env& e) { return iterate(c,e,n200(c,e),29,20,n201); }
static ZIPPY_NOINLINE Space n197(Context& c, const Env& e) { return iterate(c,e,n198(c,e),28,19,n199); }
static ZIPPY_NOINLINE Space n195(Context& c, const Env& e) { return iterate(c,e,n196(c,e),27,18,n197); }
static ZIPPY_NOINLINE Space n193(Context& c, const Env& e) { return iterate(c,e,n194(c,e),26,17,n195); }
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { return iterate(c,e,n2(c,e),25,16,n193); }
static ZIPPY_NOINLINE Space n236(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Space n238(Context& c, const Env& e) { return e.spaces.at(23); }
static ZIPPY_NOINLINE Space n240(Context& c, const Env& e) { return e.spaces.at(24); }
static ZIPPY_NOINLINE Space n242(Context& c, const Env& e) { return e.spaces.at(25); }
static ZIPPY_NOINLINE Space n244(Context& c, const Env& e) { return e.spaces.at(26); }
static ZIPPY_NOINLINE Space n246(Context& c, const Env& e) { return e.spaces.at(27); }
static ZIPPY_NOINLINE Space n248(Context& c, const Env& e) { return e.spaces.at(28); }
static ZIPPY_NOINLINE Path n257(Context& c, const Env& e) { return e.paths.at(32); }
static ZIPPY_NOINLINE Path n258(Context& c, const Env& e) { return e.paths.at(33); }
static ZIPPY_NOINLINE Path n256(Context& c, const Env& e) { auto a=n257(c,e); auto b=n258(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n259(Context& c, const Env& e) { return e.paths.at(34); }
static ZIPPY_NOINLINE Path n255(Context& c, const Env& e) { auto a=n256(c,e); auto b=n259(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n260(Context& c, const Env& e) { return e.paths.at(35); }
static ZIPPY_NOINLINE Path n254(Context& c, const Env& e) { auto a=n255(c,e); auto b=n260(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n261(Context& c, const Env& e) { return e.paths.at(36); }
static ZIPPY_NOINLINE Path n253(Context& c, const Env& e) { auto a=n254(c,e); auto b=n261(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n262(Context& c, const Env& e) { return e.paths.at(37); }
static ZIPPY_NOINLINE Path n252(Context& c, const Env& e) { auto a=n253(c,e); auto b=n262(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n263(Context& c, const Env& e) { return e.paths.at(38); }
static ZIPPY_NOINLINE Path n251(Context& c, const Env& e) { auto a=n252(c,e); auto b=n263(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n264(Context& c, const Env& e) { return e.paths.at(39); }
static ZIPPY_NOINLINE Path n250(Context& c, const Env& e) { auto a=n251(c,e); auto b=n264(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n249(Context& c, const Env& e) { return singleton(n250(c,e)); }
static ZIPPY_NOINLINE Space n247(Context& c, const Env& e) { return iterate(c,e,n248(c,e),39,-1,n249); }
static ZIPPY_NOINLINE Space n245(Context& c, const Env& e) { return iterate(c,e,n246(c,e),38,28,n247); }
static ZIPPY_NOINLINE Space n243(Context& c, const Env& e) { return iterate(c,e,n244(c,e),37,27,n245); }
static ZIPPY_NOINLINE Space n241(Context& c, const Env& e) { return iterate(c,e,n242(c,e),36,26,n243); }
static ZIPPY_NOINLINE Space n239(Context& c, const Env& e) { return iterate(c,e,n240(c,e),35,25,n241); }
static ZIPPY_NOINLINE Space n237(Context& c, const Env& e) { return iterate(c,e,n238(c,e),34,24,n239); }
static ZIPPY_NOINLINE Space n235(Context& c, const Env& e) { return iterate(c,e,n236(c,e),33,23,n237); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { return iterate(c,e,n1(c,e),32,22,n235); }
static ZIPPY_NOINLINE Path n268(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Space n269(Context& c, const Env& e) { static const Space value=literal_text("36 2 1 1 2 1 2 2 1 3 2 1 4 2 1 5 2 1 6 2 1 7 2 1 8 2 2 2 2 2 7 2 3 2 2 3 3 2 3 5 2 3 6 2 3 7 2 4 2 2 4 3 2 4 4 2 4 5 2 4 6 2 4 7 2 4 8 2 5 2 2 5 5 2 5 7 2 6 2 2 6 5 2 6 6 2 6 7 2 7 7 2 8 2 2 8 3 2 8 5 2 8 6 2 8 7 2 8 8"); return value; }
static ZIPPY_NOINLINE Space n267(Context& c, const Env& e) { auto p=n268(c,e); return unwrap(n269(c,e),p); }
static ZIPPY_NOINLINE Path n276(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n278(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Space n277(Context& c, const Env& e) { return singleton(n278(c,e)); }
static ZIPPY_NOINLINE Space n275(Context& c, const Env& e) { auto p=n276(c,e); return wrap(n277(c,e),p); }
static ZIPPY_NOINLINE Path n280(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Path n282(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Space n281(Context& c, const Env& e) { return singleton(n282(c,e)); }
static ZIPPY_NOINLINE Space n279(Context& c, const Env& e) { auto p=n280(c,e); return wrap(n281(c,e),p); }
static ZIPPY_NOINLINE Space n274(Context& c, const Env& e) { auto a=n275(c,e); auto b=n279(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n285(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Path n287(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n288(Context& c, const Env& e) { static const Space value=literal_text("64 3 1 1 16 3 1 2 9 3 1 3 11 3 1 4 15 3 1 5 14 3 1 6 13 3 1 7 10 3 1 8 12 3 2 1 9 3 2 2 6 3 2 3 4 3 2 4 10 3 2 5 3 3 2 6 8 3 2 7 5 3 2 8 1 3 3 1 11 3 3 2 4 3 3 3 9 3 3 4 13 3 3 5 1 3 3 6 10 3 3 7 8 3 3 8 14 3 4 1 15 3 4 2 10 3 4 3 13 3 4 4 12 3 4 5 9 3 4 6 14 3 4 7 1 3 4 8 11 3 5 1 14 3 5 2 3 3 5 3 1 3 5 4 9 3 5 5 8 3 5 6 4 3 5 7 6 3 5 8 10 3 6 1 13 3 6 2 8 3 6 3 10 3 6 4 14 3 6 5 4 3 6 6 1 3 6 7 3 3 6 8 9 3 7 1 10 3 7 2 5 3 7 3 8 3 7 4 1 3 7 5 6 3 7 6 3 3 7 7 2 3 7 8 4 3 8 1 12 3 8 2 1 3 8 3 14 3 8 4 11 3 8 5 10 3 8 6 9 3 8 7 4 3 8 8 13"); return value; }
static ZIPPY_NOINLINE Space n286(Context& c, const Env& e) { auto p=n287(c,e); return unwrap(n288(c,e),p); }
static ZIPPY_NOINLINE Space n284(Context& c, const Env& e) { auto p=n285(c,e); return unwrap(n286(c,e),p); }
static ZIPPY_NOINLINE Path n290(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Path n292(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Space n293(Context& c, const Env& e) { static const Space value=literal_text("64 3 1 1 16 3 1 2 9 3 1 3 11 3 1 4 15 3 1 5 14 3 1 6 13 3 1 7 10 3 1 8 12 3 2 1 9 3 2 2 6 3 2 3 4 3 2 4 10 3 2 5 3 3 2 6 8 3 2 7 5 3 2 8 1 3 3 1 11 3 3 2 4 3 3 3 9 3 3 4 13 3 3 5 1 3 3 6 10 3 3 7 8 3 3 8 14 3 4 1 15 3 4 2 10 3 4 3 13 3 4 4 12 3 4 5 9 3 4 6 14 3 4 7 1 3 4 8 11 3 5 1 14 3 5 2 3 3 5 3 1 3 5 4 9 3 5 5 8 3 5 6 4 3 5 7 6 3 5 8 10 3 6 1 13 3 6 2 8 3 6 3 10 3 6 4 14 3 6 5 4 3 6 6 1 3 6 7 3 3 6 8 9 3 7 1 10 3 7 2 5 3 7 3 8 3 7 4 1 3 7 5 6 3 7 6 3 3 7 7 2 3 7 8 4 3 8 1 12 3 8 2 1 3 8 3 14 3 8 4 11 3 8 5 10 3 8 6 9 3 8 7 4 3 8 8 13"); return value; }
static ZIPPY_NOINLINE Space n291(Context& c, const Env& e) { auto p=n292(c,e); return unwrap(n293(c,e),p); }
static ZIPPY_NOINLINE Space n289(Context& c, const Env& e) { auto p=n290(c,e); return unwrap(n291(c,e),p); }
static ZIPPY_NOINLINE Space n283(Context& c, const Env& e) { auto a=n284(c,e); if(a.empty()) return a; return compose(a,n289(c,e)); }
static ZIPPY_NOINLINE Space n273(Context& c, const Env& e) { auto a=n274(c,e); auto b=n283(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n296(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Path n298(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n299(Context& c, const Env& e) { static const Space value=literal_text("64 3 1 1 16 3 1 2 9 3 1 3 11 3 1 4 15 3 1 5 14 3 1 6 13 3 1 7 10 3 1 8 12 3 2 1 9 3 2 2 6 3 2 3 4 3 2 4 10 3 2 5 3 3 2 6 8 3 2 7 5 3 2 8 1 3 3 1 11 3 3 2 4 3 3 3 9 3 3 4 13 3 3 5 1 3 3 6 10 3 3 7 8 3 3 8 14 3 4 1 15 3 4 2 10 3 4 3 13 3 4 4 12 3 4 5 9 3 4 6 14 3 4 7 1 3 4 8 11 3 5 1 14 3 5 2 3 3 5 3 1 3 5 4 9 3 5 5 8 3 5 6 4 3 5 7 6 3 5 8 10 3 6 1 13 3 6 2 8 3 6 3 10 3 6 4 14 3 6 5 4 3 6 6 1 3 6 7 3 3 6 8 9 3 7 1 10 3 7 2 5 3 7 3 8 3 7 4 1 3 7 5 6 3 7 6 3 3 7 7 2 3 7 8 4 3 8 1 12 3 8 2 1 3 8 3 14 3 8 4 11 3 8 5 10 3 8 6 9 3 8 7 4 3 8 8 13"); return value; }
static ZIPPY_NOINLINE Space n297(Context& c, const Env& e) { auto p=n298(c,e); return unwrap(n299(c,e),p); }
static ZIPPY_NOINLINE Space n295(Context& c, const Env& e) { auto p=n296(c,e); return unwrap(n297(c,e),p); }
static ZIPPY_NOINLINE Path n301(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Path n303(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Space n304(Context& c, const Env& e) { static const Space value=literal_text("36 3 1 1 17 3 1 2 8 3 1 3 5 3 1 4 7 3 1 5 3 3 1 6 6 3 1 7 4 3 1 8 2 3 2 2 17 3 2 7 7 3 3 2 5 3 3 3 17 3 3 5 2 3 3 6 7 3 3 7 6 3 4 2 3 3 4 3 2 3 4 4 17 3 4 5 6 3 4 6 5 3 4 7 8 3 4 8 7 3 5 2 7 3 5 5 17 3 5 7 2 3 6 2 2 3 6 5 7 3 6 6 17 3 6 7 5 3 7 7 17 3 8 2 6 3 8 3 7 3 8 5 5 3 8 6 2 3 8 7 3 3 8 8 17"); return value; }
static ZIPPY_NOINLINE Space n302(Context& c, const Env& e) { auto p=n303(c,e); return unwrap(n304(c,e),p); }
static ZIPPY_NOINLINE Space n300(Context& c, const Env& e) { auto p=n301(c,e); return unwrap(n302(c,e),p); }
static ZIPPY_NOINLINE Space n294(Context& c, const Env& e) { auto a=n295(c,e); if(a.empty()) return a; return compose(a,n300(c,e)); }
static ZIPPY_NOINLINE Space n272(Context& c, const Env& e) { auto a=n273(c,e); auto b=n294(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n307(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Path n309(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n310(Context& c, const Env& e) { static const Space value=literal_text("36 3 1 1 17 3 1 2 8 3 1 3 5 3 1 4 7 3 1 5 3 3 1 6 6 3 1 7 4 3 1 8 2 3 2 2 17 3 2 7 7 3 3 2 5 3 3 3 17 3 3 5 2 3 3 6 7 3 3 7 6 3 4 2 3 3 4 3 2 3 4 4 17 3 4 5 6 3 4 6 5 3 4 7 8 3 4 8 7 3 5 2 7 3 5 5 17 3 5 7 2 3 6 2 2 3 6 5 7 3 6 6 17 3 6 7 5 3 7 7 17 3 8 2 6 3 8 3 7 3 8 5 5 3 8 6 2 3 8 7 3 3 8 8 17"); return value; }
static ZIPPY_NOINLINE Space n308(Context& c, const Env& e) { auto p=n309(c,e); return unwrap(n310(c,e),p); }
static ZIPPY_NOINLINE Space n306(Context& c, const Env& e) { auto p=n307(c,e); return unwrap(n308(c,e),p); }
static ZIPPY_NOINLINE Path n312(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Path n314(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Space n315(Context& c, const Env& e) { static const Space value=literal_text("64 3 1 1 16 3 1 2 9 3 1 3 11 3 1 4 15 3 1 5 14 3 1 6 13 3 1 7 10 3 1 8 12 3 2 1 9 3 2 2 6 3 2 3 4 3 2 4 10 3 2 5 3 3 2 6 8 3 2 7 5 3 2 8 1 3 3 1 11 3 3 2 4 3 3 3 9 3 3 4 13 3 3 5 1 3 3 6 10 3 3 7 8 3 3 8 14 3 4 1 15 3 4 2 10 3 4 3 13 3 4 4 12 3 4 5 9 3 4 6 14 3 4 7 1 3 4 8 11 3 5 1 14 3 5 2 3 3 5 3 1 3 5 4 9 3 5 5 8 3 5 6 4 3 5 7 6 3 5 8 10 3 6 1 13 3 6 2 8 3 6 3 10 3 6 4 14 3 6 5 4 3 6 6 1 3 6 7 3 3 6 8 9 3 7 1 10 3 7 2 5 3 7 3 8 3 7 4 1 3 7 5 6 3 7 6 3 3 7 7 2 3 7 8 4 3 8 1 12 3 8 2 1 3 8 3 14 3 8 4 11 3 8 5 10 3 8 6 9 3 8 7 4 3 8 8 13"); return value; }
static ZIPPY_NOINLINE Space n313(Context& c, const Env& e) { auto p=n314(c,e); return unwrap(n315(c,e),p); }
static ZIPPY_NOINLINE Space n311(Context& c, const Env& e) { auto p=n312(c,e); return unwrap(n313(c,e),p); }
static ZIPPY_NOINLINE Space n305(Context& c, const Env& e) { auto a=n306(c,e); if(a.empty()) return a; return compose(a,n311(c,e)); }
static ZIPPY_NOINLINE Space n271(Context& c, const Env& e) { auto a=n272(c,e); auto b=n305(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n318(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Path n320(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n321(Context& c, const Env& e) { static const Space value=literal_text("36 3 1 1 17 3 1 2 8 3 1 3 5 3 1 4 7 3 1 5 3 3 1 6 6 3 1 7 4 3 1 8 2 3 2 2 17 3 2 7 7 3 3 2 5 3 3 3 17 3 3 5 2 3 3 6 7 3 3 7 6 3 4 2 3 3 4 3 2 3 4 4 17 3 4 5 6 3 4 6 5 3 4 7 8 3 4 8 7 3 5 2 7 3 5 5 17 3 5 7 2 3 6 2 2 3 6 5 7 3 6 6 17 3 6 7 5 3 7 7 17 3 8 2 6 3 8 3 7 3 8 5 5 3 8 6 2 3 8 7 3 3 8 8 17"); return value; }
static ZIPPY_NOINLINE Space n319(Context& c, const Env& e) { auto p=n320(c,e); return unwrap(n321(c,e),p); }
static ZIPPY_NOINLINE Space n317(Context& c, const Env& e) { auto p=n318(c,e); return unwrap(n319(c,e),p); }
static ZIPPY_NOINLINE Path n323(Context& c, const Env& e) { return e.paths.at(40); }
static ZIPPY_NOINLINE Path n325(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Space n326(Context& c, const Env& e) { static const Space value=literal_text("36 3 1 1 17 3 1 2 8 3 1 3 5 3 1 4 7 3 1 5 3 3 1 6 6 3 1 7 4 3 1 8 2 3 2 2 17 3 2 7 7 3 3 2 5 3 3 3 17 3 3 5 2 3 3 6 7 3 3 7 6 3 4 2 3 3 4 3 2 3 4 4 17 3 4 5 6 3 4 6 5 3 4 7 8 3 4 8 7 3 5 2 7 3 5 5 17 3 5 7 2 3 6 2 2 3 6 5 7 3 6 6 17 3 6 7 5 3 7 7 17 3 8 2 6 3 8 3 7 3 8 5 5 3 8 6 2 3 8 7 3 3 8 8 17"); return value; }
static ZIPPY_NOINLINE Space n324(Context& c, const Env& e) { auto p=n325(c,e); return unwrap(n326(c,e),p); }
static ZIPPY_NOINLINE Space n322(Context& c, const Env& e) { auto p=n323(c,e); return unwrap(n324(c,e),p); }
static ZIPPY_NOINLINE Space n316(Context& c, const Env& e) { auto a=n317(c,e); if(a.empty()) return a; return compose(a,n322(c,e)); }
static ZIPPY_NOINLINE Space n270(Context& c, const Env& e) { auto a=n271(c,e); auto b=n316(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n266(Context& c, const Env& e) { return iterate(c,e,n267(c,e),40,-1,n270); }
static ZIPPY_NOINLINE Path n329(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Space n330(Context& c, const Env& e) { static const Space value=literal_text("36 2 1 1 2 1 2 2 1 3 2 1 4 2 1 5 2 1 6 2 1 7 2 1 8 2 2 2 2 2 7 2 3 2 2 3 3 2 3 5 2 3 6 2 3 7 2 4 2 2 4 3 2 4 4 2 4 5 2 4 6 2 4 7 2 4 8 2 5 2 2 5 5 2 5 7 2 6 2 2 6 5 2 6 6 2 6 7 2 7 7 2 8 2 2 8 3 2 8 5 2 8 6 2 8 7 2 8 8"); return value; }
static ZIPPY_NOINLINE Space n328(Context& c, const Env& e) { auto p=n329(c,e); return unwrap(n330(c,e),p); }
static ZIPPY_NOINLINE Path n332(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Space n333(Context& c, const Env& e) { static const Space value=literal_text("36 2 1 1 2 1 2 2 1 3 2 1 4 2 1 5 2 1 6 2 1 7 2 1 8 2 2 2 2 2 7 2 3 2 2 3 3 2 3 5 2 3 6 2 3 7 2 4 2 2 4 3 2 4 4 2 4 5 2 4 6 2 4 7 2 4 8 2 5 2 2 5 5 2 5 7 2 6 2 2 6 5 2 6 6 2 6 7 2 7 7 2 8 2 2 8 3 2 8 5 2 8 6 2 8 7 2 8 8"); return value; }
static ZIPPY_NOINLINE Space n331(Context& c, const Env& e) { auto p=n332(c,e); return unwrap(n333(c,e),p); }
static ZIPPY_NOINLINE Space n327(Context& c, const Env& e) { auto a=n328(c,e); if(a.empty()) return a; return compose(a,n331(c,e)); }
static ZIPPY_NOINLINE Space n265(Context& c, const Env& e) { auto a=n266(c,e); auto b=n327(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n265(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"17 1 1 56 2 1 50 3 1 53 4 1 55 5 1 51 6 1 52 7 1 49 8 1 54 9 2 49 48 10 1 57 11 2 49 51 12 2 49 52 13 2 49 50 14 2 49 49 15 2 49 53 16 2 49 54 17 1 48"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
