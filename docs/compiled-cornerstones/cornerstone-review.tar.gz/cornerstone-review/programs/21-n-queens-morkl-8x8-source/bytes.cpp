#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,1,1};
static const Path constant_1 = Path{1,1,1,8};
static const Path constant_2 = Path{};
static const Path constant_3 = Path{1,1,1,2};
static const Path constant_4 = Path{1,1,1,3};
static const Path constant_5 = Path{1,1,1,4};
static const Path constant_6 = Path{1,1,1,5};
static const Path constant_7 = Path{1,1,1,6};
static const Path constant_8 = Path{1,1,1,7};
static const Space constant_9 = literal_text("8 4 1 1 1 1 4 1 1 1 2 4 1 1 1 3 4 1 1 1 4 4 1 1 1 5 4 1 1 1 6 4 1 1 1 7 4 1 1 1 8");
static const Space constant_10 = literal_text("36 8 1 1 1 1 1 1 1 1 8 1 1 1 2 1 1 1 1 8 1 1 1 2 1 1 1 2 8 1 1 1 3 1 1 1 1 8 1 1 1 3 1 1 1 2 8 1 1 1 3 1 1 1 3 8 1 1 1 4 1 1 1 1 8 1 1 1 4 1 1 1 2 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 5 1 1 1 1 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 3 8 1 1 1 5 1 1 1 4 8 1 1 1 5 1 1 1 5 8 1 1 1 6 1 1 1 1 8 1 1 1 6 1 1 1 2 8 1 1 1 6 1 1 1 3 8 1 1 1 6 1 1 1 4 8 1 1 1 6 1 1 1 5 8 1 1 1 6 1 1 1 6 8 1 1 1 7 1 1 1 1 8 1 1 1 7 1 1 1 2 8 1 1 1 7 1 1 1 3 8 1 1 1 7 1 1 1 4 8 1 1 1 7 1 1 1 5 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 8 1 1 1 1 8 1 1 1 8 1 1 1 2 8 1 1 1 8 1 1 1 3 8 1 1 1 8 1 1 1 4 8 1 1 1 8 1 1 1 5 8 1 1 1 8 1 1 1 6 8 1 1 1 8 1 1 1 7 8 1 1 1 8 1 1 1 8");
static const Space constant_11 = literal_text("100 12 1 1 1 1 1 1 1 1 1 1 1 2 12 1 1 1 1 1 1 1 1 1 1 1 17 12 1 1 1 1 1 1 1 2 1 1 1 3 12 1 1 1 1 1 1 1 3 1 1 1 4 12 1 1 1 1 1 1 1 4 1 1 1 5 12 1 1 1 1 1 1 1 5 1 1 1 6 12 1 1 1 1 1 1 1 6 1 1 1 7 12 1 1 1 1 1 1 1 7 1 1 1 8 12 1 1 1 1 1 1 1 8 1 1 1 9 12 1 1 1 2 1 1 1 1 1 1 1 1 12 1 1 1 2 1 1 1 1 1 1 1 3 12 1 1 1 2 1 1 1 2 1 1 1 4 12 1 1 1 2 1 1 1 2 1 1 1 17 12 1 1 1 2 1 1 1 3 1 1 1 5 12 1 1 1 2 1 1 1 4 1 1 1 6 12 1 1 1 2 1 1 1 5 1 1 1 7 12 1 1 1 2 1 1 1 6 1 1 1 8 12 1 1 1 2 1 1 1 7 1 1 1 9 12 1 1 1 2 1 1 1 8 1 1 1 10 12 1 1 1 3 1 1 1 1 1 1 1 2 12 1 1 1 3 1 1 1 1 1 1 1 4 12 1 1 1 3 1 1 1 2 1 1 1 1 12 1 1 1 3 1 1 1 2 1 1 1 5 12 1 1 1 3 1 1 1 3 1 1 1 6 12 1 1 1 3 1 1 1 3 1 1 1 17 12 1 1 1 3 1 1 1 4 1 1 1 7 12 1 1 1 3 1 1 1 5 1 1 1 8 12 1 1 1 3 1 1 1 6 1 1 1 9 12 1 1 1 3 1 1 1 7 1 1 1 10 12 1 1 1 3 1 1 1 8 1 1 1 11 12 1 1 1 4 1 1 1 1 1 1 1 3 12 1 1 1 4 1 1 1 1 1 1 1 5 12 1 1 1 4 1 1 1 2 1 1 1 2 12 1 1 1 4 1 1 1 2 1 1 1 6 12 1 1 1 4 1 1 1 3 1 1 1 1 12 1 1 1 4 1 1 1 3 1 1 1 7 12 1 1 1 4 1 1 1 4 1 1 1 8 12 1 1 1 4 1 1 1 4 1 1 1 17 12 1 1 1 4 1 1 1 5 1 1 1 9 12 1 1 1 4 1 1 1 6 1 1 1 10 12 1 1 1 4 1 1 1 7 1 1 1 11 12 1 1 1 4 1 1 1 8 1 1 1 12 12 1 1 1 5 1 1 1 1 1 1 1 4 12 1 1 1 5 1 1 1 1 1 1 1 6 12 1 1 1 5 1 1 1 2 1 1 1 3 12 1 1 1 5 1 1 1 2 1 1 1 7 12 1 1 1 5 1 1 1 3 1 1 1 2 12 1 1 1 5 1 1 1 3 1 1 1 8 12 1 1 1 5 1 1 1 4 1 1 1 1 12 1 1 1 5 1 1 1 4 1 1 1 9 12 1 1 1 5 1 1 1 5 1 1 1 10 12 1 1 1 5 1 1 1 5 1 1 1 17 12 1 1 1 5 1 1 1 6 1 1 1 11 12 1 1 1 5 1 1 1 7 1 1 1 12 12 1 1 1 5 1 1 1 8 1 1 1 13 12 1 1 1 6 1 1 1 1 1 1 1 5 12 1 1 1 6 1 1 1 1 1 1 1 7 12 1 1 1 6 1 1 1 2 1 1 1 4 12 1 1 1 6 1 1 1 2 1 1 1 8 12 1 1 1 6 1 1 1 3 1 1 1 3 12 1 1 1 6 1 1 1 3 1 1 1 9 12 1 1 1 6 1 1 1 4 1 1 1 2 12 1 1 1 6 1 1 1 4 1 1 1 10 12 1 1 1 6 1 1 1 5 1 1 1 1 12 1 1 1 6 1 1 1 5 1 1 1 11 12 1 1 1 6 1 1 1 6 1 1 1 12 12 1 1 1 6 1 1 1 6 1 1 1 17 12 1 1 1 6 1 1 1 7 1 1 1 13 12 1 1 1 6 1 1 1 8 1 1 1 14 12 1 1 1 7 1 1 1 1 1 1 1 6 12 1 1 1 7 1 1 1 1 1 1 1 8 12 1 1 1 7 1 1 1 2 1 1 1 5 12 1 1 1 7 1 1 1 2 1 1 1 9 12 1 1 1 7 1 1 1 3 1 1 1 4 12 1 1 1 7 1 1 1 3 1 1 1 10 12 1 1 1 7 1 1 1 4 1 1 1 3 12 1 1 1 7 1 1 1 4 1 1 1 11 12 1 1 1 7 1 1 1 5 1 1 1 2 12 1 1 1 7 1 1 1 5 1 1 1 12 12 1 1 1 7 1 1 1 6 1 1 1 1 12 1 1 1 7 1 1 1 6 1 1 1 13 12 1 1 1 7 1 1 1 7 1 1 1 14 12 1 1 1 7 1 1 1 7 1 1 1 17 12 1 1 1 7 1 1 1 8 1 1 1 15 12 1 1 1 8 1 1 1 1 1 1 1 7 12 1 1 1 8 1 1 1 1 1 1 1 9 12 1 1 1 8 1 1 1 2 1 1 1 6 12 1 1 1 8 1 1 1 2 1 1 1 10 12 1 1 1 8 1 1 1 3 1 1 1 5 12 1 1 1 8 1 1 1 3 1 1 1 11 12 1 1 1 8 1 1 1 4 1 1 1 4 12 1 1 1 8 1 1 1 4 1 1 1 12 12 1 1 1 8 1 1 1 5 1 1 1 3 12 1 1 1 8 1 1 1 5 1 1 1 13 12 1 1 1 8 1 1 1 6 1 1 1 2 12 1 1 1 8 1 1 1 6 1 1 1 14 12 1 1 1 8 1 1 1 7 1 1 1 1 12 1 1 1 8 1 1 1 7 1 1 1 15 12 1 1 1 8 1 1 1 8 1 1 1 16 12 1 1 1 8 1 1 1 8 1 1 1 17");
static const Space constant_12 = literal_text("1 0 ");
static const Space constant_13 = literal_text("64 8 1 1 1 1 1 1 1 1 8 1 1 1 1 1 1 1 2 8 1 1 1 1 1 1 1 3 8 1 1 1 1 1 1 1 4 8 1 1 1 1 1 1 1 5 8 1 1 1 1 1 1 1 6 8 1 1 1 1 1 1 1 7 8 1 1 1 1 1 1 1 8 8 1 1 1 2 1 1 1 1 8 1 1 1 2 1 1 1 2 8 1 1 1 2 1 1 1 3 8 1 1 1 2 1 1 1 4 8 1 1 1 2 1 1 1 5 8 1 1 1 2 1 1 1 6 8 1 1 1 2 1 1 1 7 8 1 1 1 2 1 1 1 8 8 1 1 1 3 1 1 1 1 8 1 1 1 3 1 1 1 2 8 1 1 1 3 1 1 1 3 8 1 1 1 3 1 1 1 4 8 1 1 1 3 1 1 1 5 8 1 1 1 3 1 1 1 6 8 1 1 1 3 1 1 1 7 8 1 1 1 3 1 1 1 8 8 1 1 1 4 1 1 1 1 8 1 1 1 4 1 1 1 2 8 1 1 1 4 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 4 1 1 1 5 8 1 1 1 4 1 1 1 6 8 1 1 1 4 1 1 1 7 8 1 1 1 4 1 1 1 8 8 1 1 1 5 1 1 1 1 8 1 1 1 5 1 1 1 2 8 1 1 1 5 1 1 1 3 8 1 1 1 5 1 1 1 4 8 1 1 1 5 1 1 1 5 8 1 1 1 5 1 1 1 6 8 1 1 1 5 1 1 1 7 8 1 1 1 5 1 1 1 8 8 1 1 1 6 1 1 1 1 8 1 1 1 6 1 1 1 2 8 1 1 1 6 1 1 1 3 8 1 1 1 6 1 1 1 4 8 1 1 1 6 1 1 1 5 8 1 1 1 6 1 1 1 6 8 1 1 1 6 1 1 1 7 8 1 1 1 6 1 1 1 8 8 1 1 1 7 1 1 1 1 8 1 1 1 7 1 1 1 2 8 1 1 1 7 1 1 1 3 8 1 1 1 7 1 1 1 4 8 1 1 1 7 1 1 1 5 8 1 1 1 7 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 7 1 1 1 8 8 1 1 1 8 1 1 1 1 8 1 1 1 8 1 1 1 2 8 1 1 1 8 1 1 1 3 8 1 1 1 8 1 1 1 4 8 1 1 1 8 1 1 1 5 8 1 1 1 8 1 1 1 6 8 1 1 1 8 1 1 1 7 8 1 1 1 8 1 1 1 8");
static Space routine_0(Context& c);
static Space routine_4(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0, const Space& s1);
static Space routine_10(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0, const Space& s1);
static Space routine_1(Context& c, const Path& p0, const Path& p1, const Path& p2);
static Space routine_0(Context& c) {
  const Space v0_2 = routine_1(c, constant_0, constant_0, constant_1);
  const Space v0_4 = wrap(v0_2,constant_2);
  const Space v0_5 = wrap(v0_4,constant_0);
  const Space v0_7 = routine_1(c, constant_3, constant_0, constant_1);
  const Space v0_8 = wrap(v0_7,constant_2);
  const Space v0_9 = wrap(v0_8,constant_3);
  const Space v0_10 = unite(v0_5,v0_9);
  const Space v0_12 = routine_1(c, constant_4, constant_0, constant_1);
  const Space v0_13 = wrap(v0_12,constant_2);
  const Space v0_14 = wrap(v0_13,constant_4);
  const Space v0_15 = unite(v0_10,v0_14);
  const Space v0_17 = routine_1(c, constant_5, constant_0, constant_1);
  const Space v0_18 = wrap(v0_17,constant_2);
  const Space v0_19 = wrap(v0_18,constant_5);
  const Space v0_20 = unite(v0_15,v0_19);
  const Space v0_22 = routine_1(c, constant_6, constant_0, constant_1);
  const Space v0_23 = wrap(v0_22,constant_2);
  const Space v0_24 = wrap(v0_23,constant_6);
  const Space v0_25 = unite(v0_20,v0_24);
  const Space v0_27 = routine_1(c, constant_7, constant_0, constant_1);
  const Space v0_28 = wrap(v0_27,constant_2);
  const Space v0_29 = wrap(v0_28,constant_7);
  const Space v0_30 = unite(v0_25,v0_29);
  const Space v0_32 = routine_1(c, constant_8, constant_0, constant_1);
  const Space v0_33 = wrap(v0_32,constant_2);
  const Space v0_34 = wrap(v0_33,constant_8);
  const Space v0_35 = unite(v0_30,v0_34);
  const Space v0_36 = routine_1(c, constant_1, constant_0, constant_1);
  const Space v0_37 = wrap(v0_36,constant_2);
  const Space v0_38 = wrap(v0_37,constant_1);
  const Space v0_39 = unite(v0_35,v0_38);
  const auto v0_41_branches = branches(c,v0_39);
  std::vector<Space> v0_41_outputs;
  v0_41_outputs.reserve(v0_41_branches.size());
  for (const auto& v0_41_branch : v0_41_branches) {
    const Path v0_41_head{v0_41_branch.first};
    const Space& v0_41_tail = v0_41_branch.second;
    const auto v1_2_branches = branches(c,v0_41_tail);
    std::vector<Space> v1_2_outputs;
    v1_2_outputs.reserve(v1_2_branches.size());
    for (const auto& v1_2_branch : v1_2_branches) {
      const Path v1_2_head{v1_2_branch.first};
      const Space& v1_2_tail = v1_2_branch.second;
      const Path v2_2 = concat_path(v0_41_head,v1_2_head);
      const auto v2_3_branches = branches(c,v1_2_tail);
      std::vector<Space> v2_3_outputs;
      v2_3_outputs.reserve(v2_3_branches.size());
      for (const auto& v2_3_branch : v2_3_branches) {
        const Path v2_3_head{v2_3_branch.first};
        const Space& v2_3_tail = v2_3_branch.second;
        const Path v3_2 = concat_path(v2_2,v2_3_head);
        const auto v3_3_branches = branches(c,v2_3_tail);
        std::vector<Space> v3_3_outputs;
        v3_3_outputs.reserve(v3_3_branches.size());
        for (const auto& v3_3_branch : v3_3_branches) {
          const Path v3_3_head{v3_3_branch.first};
          const Space& v3_3_tail = v3_3_branch.second;
          const Space v4_2 = unwrap(v3_3_tail,constant_3);
          const Space v4_3 = subtract(constant_9,v4_2);
          const Path v4_4 = concat_path(v3_2,v3_3_head);
          const auto v4_5_branches = branches(c,v4_3);
          std::vector<Space> v4_5_outputs;
          v4_5_outputs.reserve(v4_5_branches.size());
          for (const auto& v4_5_branch : v4_5_branches) {
            const Path v4_5_head{v4_5_branch.first};
            const Space& v4_5_tail = v4_5_branch.second;
            const auto v5_2_branches = branches(c,v4_5_tail);
            std::vector<Space> v5_2_outputs;
            v5_2_outputs.reserve(v5_2_branches.size());
            for (const auto& v5_2_branch : v5_2_branches) {
              const Path v5_2_head{v5_2_branch.first};
              const Space& v5_2_tail = v5_2_branch.second;
              const Path v6_2 = concat_path(v4_5_head,v5_2_head);
              const auto v6_3_branches = branches(c,v5_2_tail);
              std::vector<Space> v6_3_outputs;
              v6_3_outputs.reserve(v6_3_branches.size());
              for (const auto& v6_3_branch : v6_3_branches) {
                const Path v6_3_head{v6_3_branch.first};
                const Space& v6_3_tail = v6_3_branch.second;
                const Path v7_2 = concat_path(v6_2,v6_3_head);
                const auto v7_3_branches = branches(c,v6_3_tail);
                std::vector<Space> v7_3_outputs;
                v7_3_outputs.reserve(v7_3_branches.size());
                for (const auto& v7_3_branch : v7_3_branches) {
                  const Path v7_3_head{v7_3_branch.first};
                  const Space& v7_3_tail = v7_3_branch.second;
                  const Path v8_2 = concat_path(v7_2,v7_3_head);
                  const Space v8_3 = routine_2(c, v8_2, v4_4, v7_3_tail, v3_3_tail);
                  v7_3_outputs.push_back(v8_3);
                }
                const Space v7_3 = join_outputs(std::move(v7_3_outputs));
                v6_3_outputs.push_back(v7_3);
              }
              const Space v6_3 = join_outputs(std::move(v6_3_outputs));
              v5_2_outputs.push_back(v6_3);
            }
            const Space v5_2 = join_outputs(std::move(v5_2_outputs));
            v4_5_outputs.push_back(v5_2);
          }
          const Space v4_5 = join_outputs(std::move(v4_5_outputs));
          v3_3_outputs.push_back(v4_5);
        }
        const Space v3_3 = join_outputs(std::move(v3_3_outputs));
        v2_3_outputs.push_back(v3_3);
      }
      const Space v2_3 = join_outputs(std::move(v2_3_outputs));
      v1_2_outputs.push_back(v2_3);
    }
    const Space v1_2 = join_outputs(std::move(v1_2_outputs));
    v0_41_outputs.push_back(v1_2);
  }
  const Space v0_41 = join_outputs(std::move(v0_41_outputs));
  const auto v0_42_branches = branches(c,v0_41);
  std::vector<Space> v0_42_outputs;
  v0_42_outputs.reserve(v0_42_branches.size());
  for (const auto& v0_42_branch : v0_42_branches) {
    const Path v0_42_head{v0_42_branch.first};
    const Space& v0_42_tail = v0_42_branch.second;
    const auto v9_2_branches = branches(c,v0_42_tail);
    std::vector<Space> v9_2_outputs;
    v9_2_outputs.reserve(v9_2_branches.size());
    for (const auto& v9_2_branch : v9_2_branches) {
      const Path v9_2_head{v9_2_branch.first};
      const Space& v9_2_tail = v9_2_branch.second;
      const Path v10_2 = concat_path(v0_42_head,v9_2_head);
      const auto v10_3_branches = branches(c,v9_2_tail);
      std::vector<Space> v10_3_outputs;
      v10_3_outputs.reserve(v10_3_branches.size());
      for (const auto& v10_3_branch : v10_3_branches) {
        const Path v10_3_head{v10_3_branch.first};
        const Space& v10_3_tail = v10_3_branch.second;
        const Path v11_2 = concat_path(v10_2,v10_3_head);
        const auto v11_3_branches = branches(c,v10_3_tail);
        std::vector<Space> v11_3_outputs;
        v11_3_outputs.reserve(v11_3_branches.size());
        for (const auto& v11_3_branch : v11_3_branches) {
          const Path v11_3_head{v11_3_branch.first};
          const Space& v11_3_tail = v11_3_branch.second;
          const Path v12_2 = concat_path(v11_2,v11_3_head);
          const auto v12_3_branches = branches(c,v11_3_tail);
          std::vector<Space> v12_3_outputs;
          v12_3_outputs.reserve(v12_3_branches.size());
          for (const auto& v12_3_branch : v12_3_branches) {
            const Path v12_3_head{v12_3_branch.first};
            const Space& v12_3_tail = v12_3_branch.second;
            const auto v13_2_branches = branches(c,v12_3_tail);
            std::vector<Space> v13_2_outputs;
            v13_2_outputs.reserve(v13_2_branches.size());
            for (const auto& v13_2_branch : v13_2_branches) {
              const Path v13_2_head{v13_2_branch.first};
              const Space& v13_2_tail = v13_2_branch.second;
              const Path v14_2 = concat_path(v12_3_head,v13_2_head);
              const auto v14_3_branches = branches(c,v13_2_tail);
              std::vector<Space> v14_3_outputs;
              v14_3_outputs.reserve(v14_3_branches.size());
              for (const auto& v14_3_branch : v14_3_branches) {
                const Path v14_3_head{v14_3_branch.first};
                const Space& v14_3_tail = v14_3_branch.second;
                const Path v15_2 = concat_path(v14_2,v14_3_head);
                const auto v15_3_branches = branches(c,v14_3_tail);
                std::vector<Space> v15_3_outputs;
                v15_3_outputs.reserve(v15_3_branches.size());
                for (const auto& v15_3_branch : v15_3_branches) {
                  const Path v15_3_head{v15_3_branch.first};
                  const Space& v15_3_tail = v15_3_branch.second;
                  const Path v16_2 = concat_path(v15_2,v15_3_head);
                  const Space v16_3 = routine_3(c, v16_2, v12_2, v15_3_tail);
                  v15_3_outputs.push_back(v16_3);
                }
                const Space v15_3 = join_outputs(std::move(v15_3_outputs));
                v14_3_outputs.push_back(v15_3);
              }
              const Space v14_3 = join_outputs(std::move(v14_3_outputs));
              v13_2_outputs.push_back(v14_3);
            }
            const Space v13_2 = join_outputs(std::move(v13_2_outputs));
            v12_3_outputs.push_back(v13_2);
          }
          const Space v12_3 = join_outputs(std::move(v12_3_outputs));
          v11_3_outputs.push_back(v12_3);
        }
        const Space v11_3 = join_outputs(std::move(v11_3_outputs));
        v10_3_outputs.push_back(v11_3);
      }
      const Space v10_3 = join_outputs(std::move(v10_3_outputs));
      v9_2_outputs.push_back(v10_3);
    }
    const Space v9_2 = join_outputs(std::move(v9_2_outputs));
    v0_42_outputs.push_back(v9_2);
  }
  const Space v0_42 = join_outputs(std::move(v0_42_outputs));
  const auto v0_43_branches = branches(c,v0_42);
  std::vector<Space> v0_43_outputs;
  v0_43_outputs.reserve(v0_43_branches.size());
  for (const auto& v0_43_branch : v0_43_branches) {
    const Path v0_43_head{v0_43_branch.first};
    const Space& v0_43_tail = v0_43_branch.second;
    const auto v17_2_branches = branches(c,v0_43_tail);
    std::vector<Space> v17_2_outputs;
    v17_2_outputs.reserve(v17_2_branches.size());
    for (const auto& v17_2_branch : v17_2_branches) {
      const Path v17_2_head{v17_2_branch.first};
      const Space& v17_2_tail = v17_2_branch.second;
      const Path v18_2 = concat_path(v0_43_head,v17_2_head);
      const auto v18_3_branches = branches(c,v17_2_tail);
      std::vector<Space> v18_3_outputs;
      v18_3_outputs.reserve(v18_3_branches.size());
      for (const auto& v18_3_branch : v18_3_branches) {
        const Path v18_3_head{v18_3_branch.first};
        const Space& v18_3_tail = v18_3_branch.second;
        const Path v19_2 = concat_path(v18_2,v18_3_head);
        const auto v19_3_branches = branches(c,v18_3_tail);
        std::vector<Space> v19_3_outputs;
        v19_3_outputs.reserve(v19_3_branches.size());
        for (const auto& v19_3_branch : v19_3_branches) {
          const Path v19_3_head{v19_3_branch.first};
          const Space& v19_3_tail = v19_3_branch.second;
          const Path v20_2 = concat_path(v19_2,v19_3_head);
          const auto v20_3_branches = branches(c,v19_3_tail);
          std::vector<Space> v20_3_outputs;
          v20_3_outputs.reserve(v20_3_branches.size());
          for (const auto& v20_3_branch : v20_3_branches) {
            const Path v20_3_head{v20_3_branch.first};
            const Space& v20_3_tail = v20_3_branch.second;
            const auto v21_2_branches = branches(c,v20_3_tail);
            std::vector<Space> v21_2_outputs;
            v21_2_outputs.reserve(v21_2_branches.size());
            for (const auto& v21_2_branch : v21_2_branches) {
              const Path v21_2_head{v21_2_branch.first};
              const Space& v21_2_tail = v21_2_branch.second;
              const Path v22_2 = concat_path(v20_3_head,v21_2_head);
              const auto v22_3_branches = branches(c,v21_2_tail);
              std::vector<Space> v22_3_outputs;
              v22_3_outputs.reserve(v22_3_branches.size());
              for (const auto& v22_3_branch : v22_3_branches) {
                const Path v22_3_head{v22_3_branch.first};
                const Space& v22_3_tail = v22_3_branch.second;
                const Path v23_2 = concat_path(v22_2,v22_3_head);
                const auto v23_3_branches = branches(c,v22_3_tail);
                std::vector<Space> v23_3_outputs;
                v23_3_outputs.reserve(v23_3_branches.size());
                for (const auto& v23_3_branch : v23_3_branches) {
                  const Path v23_3_head{v23_3_branch.first};
                  const Space& v23_3_tail = v23_3_branch.second;
                  const Path v24_2 = concat_path(v23_2,v23_3_head);
                  const Space v24_3 = routine_4(c, v24_2, v20_2, v23_3_tail);
                  v23_3_outputs.push_back(v24_3);
                }
                const Space v23_3 = join_outputs(std::move(v23_3_outputs));
                v22_3_outputs.push_back(v23_3);
              }
              const Space v22_3 = join_outputs(std::move(v22_3_outputs));
              v21_2_outputs.push_back(v22_3);
            }
            const Space v21_2 = join_outputs(std::move(v21_2_outputs));
            v20_3_outputs.push_back(v21_2);
          }
          const Space v20_3 = join_outputs(std::move(v20_3_outputs));
          v19_3_outputs.push_back(v20_3);
        }
        const Space v19_3 = join_outputs(std::move(v19_3_outputs));
        v18_3_outputs.push_back(v19_3);
      }
      const Space v18_3 = join_outputs(std::move(v18_3_outputs));
      v17_2_outputs.push_back(v18_3);
    }
    const Space v17_2 = join_outputs(std::move(v17_2_outputs));
    v0_43_outputs.push_back(v17_2);
  }
  const Space v0_43 = join_outputs(std::move(v0_43_outputs));
  const auto v0_44_branches = branches(c,v0_43);
  std::vector<Space> v0_44_outputs;
  v0_44_outputs.reserve(v0_44_branches.size());
  for (const auto& v0_44_branch : v0_44_branches) {
    const Path v0_44_head{v0_44_branch.first};
    const Space& v0_44_tail = v0_44_branch.second;
    const auto v25_2_branches = branches(c,v0_44_tail);
    std::vector<Space> v25_2_outputs;
    v25_2_outputs.reserve(v25_2_branches.size());
    for (const auto& v25_2_branch : v25_2_branches) {
      const Path v25_2_head{v25_2_branch.first};
      const Space& v25_2_tail = v25_2_branch.second;
      const Path v26_2 = concat_path(v0_44_head,v25_2_head);
      const auto v26_3_branches = branches(c,v25_2_tail);
      std::vector<Space> v26_3_outputs;
      v26_3_outputs.reserve(v26_3_branches.size());
      for (const auto& v26_3_branch : v26_3_branches) {
        const Path v26_3_head{v26_3_branch.first};
        const Space& v26_3_tail = v26_3_branch.second;
        const Path v27_2 = concat_path(v26_2,v26_3_head);
        const auto v27_3_branches = branches(c,v26_3_tail);
        std::vector<Space> v27_3_outputs;
        v27_3_outputs.reserve(v27_3_branches.size());
        for (const auto& v27_3_branch : v27_3_branches) {
          const Path v27_3_head{v27_3_branch.first};
          const Space& v27_3_tail = v27_3_branch.second;
          const Path v28_2 = concat_path(v27_2,v27_3_head);
          const auto v28_3_branches = branches(c,v27_3_tail);
          std::vector<Space> v28_3_outputs;
          v28_3_outputs.reserve(v28_3_branches.size());
          for (const auto& v28_3_branch : v28_3_branches) {
            const Path v28_3_head{v28_3_branch.first};
            const Space& v28_3_tail = v28_3_branch.second;
            const auto v29_2_branches = branches(c,v28_3_tail);
            std::vector<Space> v29_2_outputs;
            v29_2_outputs.reserve(v29_2_branches.size());
            for (const auto& v29_2_branch : v29_2_branches) {
              const Path v29_2_head{v29_2_branch.first};
              const Space& v29_2_tail = v29_2_branch.second;
              const Path v30_2 = concat_path(v28_3_head,v29_2_head);
              const auto v30_3_branches = branches(c,v29_2_tail);
              std::vector<Space> v30_3_outputs;
              v30_3_outputs.reserve(v30_3_branches.size());
              for (const auto& v30_3_branch : v30_3_branches) {
                const Path v30_3_head{v30_3_branch.first};
                const Space& v30_3_tail = v30_3_branch.second;
                const Path v31_2 = concat_path(v30_2,v30_3_head);
                const auto v31_3_branches = branches(c,v30_3_tail);
                std::vector<Space> v31_3_outputs;
                v31_3_outputs.reserve(v31_3_branches.size());
                for (const auto& v31_3_branch : v31_3_branches) {
                  const Path v31_3_head{v31_3_branch.first};
                  const Space& v31_3_tail = v31_3_branch.second;
                  const Path v32_2 = concat_path(v31_2,v31_3_head);
                  const Space v32_3 = routine_5(c, v32_2, v28_2, v31_3_tail);
                  v31_3_outputs.push_back(v32_3);
                }
                const Space v31_3 = join_outputs(std::move(v31_3_outputs));
                v30_3_outputs.push_back(v31_3);
              }
              const Space v30_3 = join_outputs(std::move(v30_3_outputs));
              v29_2_outputs.push_back(v30_3);
            }
            const Space v29_2 = join_outputs(std::move(v29_2_outputs));
            v28_3_outputs.push_back(v29_2);
          }
          const Space v28_3 = join_outputs(std::move(v28_3_outputs));
          v27_3_outputs.push_back(v28_3);
        }
        const Space v27_3 = join_outputs(std::move(v27_3_outputs));
        v26_3_outputs.push_back(v27_3);
      }
      const Space v26_3 = join_outputs(std::move(v26_3_outputs));
      v25_2_outputs.push_back(v26_3);
    }
    const Space v25_2 = join_outputs(std::move(v25_2_outputs));
    v0_44_outputs.push_back(v25_2);
  }
  const Space v0_44 = join_outputs(std::move(v0_44_outputs));
  const auto v0_45_branches = branches(c,v0_44);
  std::vector<Space> v0_45_outputs;
  v0_45_outputs.reserve(v0_45_branches.size());
  for (const auto& v0_45_branch : v0_45_branches) {
    const Path v0_45_head{v0_45_branch.first};
    const Space& v0_45_tail = v0_45_branch.second;
    const auto v33_2_branches = branches(c,v0_45_tail);
    std::vector<Space> v33_2_outputs;
    v33_2_outputs.reserve(v33_2_branches.size());
    for (const auto& v33_2_branch : v33_2_branches) {
      const Path v33_2_head{v33_2_branch.first};
      const Space& v33_2_tail = v33_2_branch.second;
      const Path v34_2 = concat_path(v0_45_head,v33_2_head);
      const auto v34_3_branches = branches(c,v33_2_tail);
      std::vector<Space> v34_3_outputs;
      v34_3_outputs.reserve(v34_3_branches.size());
      for (const auto& v34_3_branch : v34_3_branches) {
        const Path v34_3_head{v34_3_branch.first};
        const Space& v34_3_tail = v34_3_branch.second;
        const Path v35_2 = concat_path(v34_2,v34_3_head);
        const auto v35_3_branches = branches(c,v34_3_tail);
        std::vector<Space> v35_3_outputs;
        v35_3_outputs.reserve(v35_3_branches.size());
        for (const auto& v35_3_branch : v35_3_branches) {
          const Path v35_3_head{v35_3_branch.first};
          const Space& v35_3_tail = v35_3_branch.second;
          const Path v36_2 = concat_path(v35_2,v35_3_head);
          const auto v36_3_branches = branches(c,v35_3_tail);
          std::vector<Space> v36_3_outputs;
          v36_3_outputs.reserve(v36_3_branches.size());
          for (const auto& v36_3_branch : v36_3_branches) {
            const Path v36_3_head{v36_3_branch.first};
            const Space& v36_3_tail = v36_3_branch.second;
            const auto v37_2_branches = branches(c,v36_3_tail);
            std::vector<Space> v37_2_outputs;
            v37_2_outputs.reserve(v37_2_branches.size());
            for (const auto& v37_2_branch : v37_2_branches) {
              const Path v37_2_head{v37_2_branch.first};
              const Space& v37_2_tail = v37_2_branch.second;
              const Path v38_2 = concat_path(v36_3_head,v37_2_head);
              const auto v38_3_branches = branches(c,v37_2_tail);
              std::vector<Space> v38_3_outputs;
              v38_3_outputs.reserve(v38_3_branches.size());
              for (const auto& v38_3_branch : v38_3_branches) {
                const Path v38_3_head{v38_3_branch.first};
                const Space& v38_3_tail = v38_3_branch.second;
                const Path v39_2 = concat_path(v38_2,v38_3_head);
                const auto v39_3_branches = branches(c,v38_3_tail);
                std::vector<Space> v39_3_outputs;
                v39_3_outputs.reserve(v39_3_branches.size());
                for (const auto& v39_3_branch : v39_3_branches) {
                  const Path v39_3_head{v39_3_branch.first};
                  const Space& v39_3_tail = v39_3_branch.second;
                  const Path v40_2 = concat_path(v39_2,v39_3_head);
                  const Space v40_3 = routine_6(c, v40_2, v36_2, v39_3_tail);
                  v39_3_outputs.push_back(v40_3);
                }
                const Space v39_3 = join_outputs(std::move(v39_3_outputs));
                v38_3_outputs.push_back(v39_3);
              }
              const Space v38_3 = join_outputs(std::move(v38_3_outputs));
              v37_2_outputs.push_back(v38_3);
            }
            const Space v37_2 = join_outputs(std::move(v37_2_outputs));
            v36_3_outputs.push_back(v37_2);
          }
          const Space v36_3 = join_outputs(std::move(v36_3_outputs));
          v35_3_outputs.push_back(v36_3);
        }
        const Space v35_3 = join_outputs(std::move(v35_3_outputs));
        v34_3_outputs.push_back(v35_3);
      }
      const Space v34_3 = join_outputs(std::move(v34_3_outputs));
      v33_2_outputs.push_back(v34_3);
    }
    const Space v33_2 = join_outputs(std::move(v33_2_outputs));
    v0_45_outputs.push_back(v33_2);
  }
  const Space v0_45 = join_outputs(std::move(v0_45_outputs));
  const auto v0_46_branches = branches(c,v0_45);
  std::vector<Space> v0_46_outputs;
  v0_46_outputs.reserve(v0_46_branches.size());
  for (const auto& v0_46_branch : v0_46_branches) {
    const Path v0_46_head{v0_46_branch.first};
    const Space& v0_46_tail = v0_46_branch.second;
    const auto v41_2_branches = branches(c,v0_46_tail);
    std::vector<Space> v41_2_outputs;
    v41_2_outputs.reserve(v41_2_branches.size());
    for (const auto& v41_2_branch : v41_2_branches) {
      const Path v41_2_head{v41_2_branch.first};
      const Space& v41_2_tail = v41_2_branch.second;
      const Path v42_2 = concat_path(v0_46_head,v41_2_head);
      const auto v42_3_branches = branches(c,v41_2_tail);
      std::vector<Space> v42_3_outputs;
      v42_3_outputs.reserve(v42_3_branches.size());
      for (const auto& v42_3_branch : v42_3_branches) {
        const Path v42_3_head{v42_3_branch.first};
        const Space& v42_3_tail = v42_3_branch.second;
        const Path v43_2 = concat_path(v42_2,v42_3_head);
        const auto v43_3_branches = branches(c,v42_3_tail);
        std::vector<Space> v43_3_outputs;
        v43_3_outputs.reserve(v43_3_branches.size());
        for (const auto& v43_3_branch : v43_3_branches) {
          const Path v43_3_head{v43_3_branch.first};
          const Space& v43_3_tail = v43_3_branch.second;
          const Path v44_2 = concat_path(v43_2,v43_3_head);
          const auto v44_3_branches = branches(c,v43_3_tail);
          std::vector<Space> v44_3_outputs;
          v44_3_outputs.reserve(v44_3_branches.size());
          for (const auto& v44_3_branch : v44_3_branches) {
            const Path v44_3_head{v44_3_branch.first};
            const Space& v44_3_tail = v44_3_branch.second;
            const auto v45_2_branches = branches(c,v44_3_tail);
            std::vector<Space> v45_2_outputs;
            v45_2_outputs.reserve(v45_2_branches.size());
            for (const auto& v45_2_branch : v45_2_branches) {
              const Path v45_2_head{v45_2_branch.first};
              const Space& v45_2_tail = v45_2_branch.second;
              const Path v46_2 = concat_path(v44_3_head,v45_2_head);
              const auto v46_3_branches = branches(c,v45_2_tail);
              std::vector<Space> v46_3_outputs;
              v46_3_outputs.reserve(v46_3_branches.size());
              for (const auto& v46_3_branch : v46_3_branches) {
                const Path v46_3_head{v46_3_branch.first};
                const Space& v46_3_tail = v46_3_branch.second;
                const Path v47_2 = concat_path(v46_2,v46_3_head);
                const auto v47_3_branches = branches(c,v46_3_tail);
                std::vector<Space> v47_3_outputs;
                v47_3_outputs.reserve(v47_3_branches.size());
                for (const auto& v47_3_branch : v47_3_branches) {
                  const Path v47_3_head{v47_3_branch.first};
                  const Space& v47_3_tail = v47_3_branch.second;
                  const Path v48_2 = concat_path(v47_2,v47_3_head);
                  const Space v48_3 = routine_7(c, v48_2, v44_2, v47_3_tail);
                  v47_3_outputs.push_back(v48_3);
                }
                const Space v47_3 = join_outputs(std::move(v47_3_outputs));
                v46_3_outputs.push_back(v47_3);
              }
              const Space v46_3 = join_outputs(std::move(v46_3_outputs));
              v45_2_outputs.push_back(v46_3);
            }
            const Space v45_2 = join_outputs(std::move(v45_2_outputs));
            v44_3_outputs.push_back(v45_2);
          }
          const Space v44_3 = join_outputs(std::move(v44_3_outputs));
          v43_3_outputs.push_back(v44_3);
        }
        const Space v43_3 = join_outputs(std::move(v43_3_outputs));
        v42_3_outputs.push_back(v43_3);
      }
      const Space v42_3 = join_outputs(std::move(v42_3_outputs));
      v41_2_outputs.push_back(v42_3);
    }
    const Space v41_2 = join_outputs(std::move(v41_2_outputs));
    v0_46_outputs.push_back(v41_2);
  }
  const Space v0_46 = join_outputs(std::move(v0_46_outputs));
  const auto v0_47_branches = branches(c,v0_46);
  std::vector<Space> v0_47_outputs;
  v0_47_outputs.reserve(v0_47_branches.size());
  for (const auto& v0_47_branch : v0_47_branches) {
    const Path v0_47_head{v0_47_branch.first};
    const Space& v0_47_tail = v0_47_branch.second;
    const auto v49_2_branches = branches(c,v0_47_tail);
    std::vector<Space> v49_2_outputs;
    v49_2_outputs.reserve(v49_2_branches.size());
    for (const auto& v49_2_branch : v49_2_branches) {
      const Path v49_2_head{v49_2_branch.first};
      const Space& v49_2_tail = v49_2_branch.second;
      const Path v50_2 = concat_path(v0_47_head,v49_2_head);
      const auto v50_3_branches = branches(c,v49_2_tail);
      std::vector<Space> v50_3_outputs;
      v50_3_outputs.reserve(v50_3_branches.size());
      for (const auto& v50_3_branch : v50_3_branches) {
        const Path v50_3_head{v50_3_branch.first};
        const Space& v50_3_tail = v50_3_branch.second;
        const Path v51_2 = concat_path(v50_2,v50_3_head);
        const auto v51_3_branches = branches(c,v50_3_tail);
        std::vector<Space> v51_3_outputs;
        v51_3_outputs.reserve(v51_3_branches.size());
        for (const auto& v51_3_branch : v51_3_branches) {
          const Path v51_3_head{v51_3_branch.first};
          const Space& v51_3_tail = v51_3_branch.second;
          const Path v52_2 = concat_path(v51_2,v51_3_head);
          const auto v52_3_branches = branches(c,v51_3_tail);
          std::vector<Space> v52_3_outputs;
          v52_3_outputs.reserve(v52_3_branches.size());
          for (const auto& v52_3_branch : v52_3_branches) {
            const Path v52_3_head{v52_3_branch.first};
            const Space& v52_3_tail = v52_3_branch.second;
            const auto v53_2_branches = branches(c,v52_3_tail);
            std::vector<Space> v53_2_outputs;
            v53_2_outputs.reserve(v53_2_branches.size());
            for (const auto& v53_2_branch : v53_2_branches) {
              const Path v53_2_head{v53_2_branch.first};
              const Space& v53_2_tail = v53_2_branch.second;
              const Path v54_2 = concat_path(v52_3_head,v53_2_head);
              const auto v54_3_branches = branches(c,v53_2_tail);
              std::vector<Space> v54_3_outputs;
              v54_3_outputs.reserve(v54_3_branches.size());
              for (const auto& v54_3_branch : v54_3_branches) {
                const Path v54_3_head{v54_3_branch.first};
                const Space& v54_3_tail = v54_3_branch.second;
                const Path v55_2 = concat_path(v54_2,v54_3_head);
                const auto v55_3_branches = branches(c,v54_3_tail);
                std::vector<Space> v55_3_outputs;
                v55_3_outputs.reserve(v55_3_branches.size());
                for (const auto& v55_3_branch : v55_3_branches) {
                  const Path v55_3_head{v55_3_branch.first};
                  const Space& v55_3_tail = v55_3_branch.second;
                  const Path v56_2 = concat_path(v55_2,v55_3_head);
                  const Space v56_3 = routine_8(c, v56_2, v52_2, v55_3_tail);
                  v55_3_outputs.push_back(v56_3);
                }
                const Space v55_3 = join_outputs(std::move(v55_3_outputs));
                v54_3_outputs.push_back(v55_3);
              }
              const Space v54_3 = join_outputs(std::move(v54_3_outputs));
              v53_2_outputs.push_back(v54_3);
            }
            const Space v53_2 = join_outputs(std::move(v53_2_outputs));
            v52_3_outputs.push_back(v53_2);
          }
          const Space v52_3 = join_outputs(std::move(v52_3_outputs));
          v51_3_outputs.push_back(v52_3);
        }
        const Space v51_3 = join_outputs(std::move(v51_3_outputs));
        v50_3_outputs.push_back(v51_3);
      }
      const Space v50_3 = join_outputs(std::move(v50_3_outputs));
      v49_2_outputs.push_back(v50_3);
    }
    const Space v49_2 = join_outputs(std::move(v49_2_outputs));
    v0_47_outputs.push_back(v49_2);
  }
  const Space v0_47 = join_outputs(std::move(v0_47_outputs));
  const auto v0_48_branches = branches(c,v0_47);
  std::vector<Space> v0_48_outputs;
  v0_48_outputs.reserve(v0_48_branches.size());
  for (const auto& v0_48_branch : v0_48_branches) {
    const Path v0_48_head{v0_48_branch.first};
    const Space& v0_48_tail = v0_48_branch.second;
    const auto v57_2_branches = branches(c,v0_48_tail);
    std::vector<Space> v57_2_outputs;
    v57_2_outputs.reserve(v57_2_branches.size());
    for (const auto& v57_2_branch : v57_2_branches) {
      const Path v57_2_head{v57_2_branch.first};
      const Space& v57_2_tail = v57_2_branch.second;
      const Path v58_2 = concat_path(v0_48_head,v57_2_head);
      const auto v58_3_branches = branches(c,v57_2_tail);
      std::vector<Space> v58_3_outputs;
      v58_3_outputs.reserve(v58_3_branches.size());
      for (const auto& v58_3_branch : v58_3_branches) {
        const Path v58_3_head{v58_3_branch.first};
        const Space& v58_3_tail = v58_3_branch.second;
        const Path v59_2 = concat_path(v58_2,v58_3_head);
        const auto v59_3_branches = branches(c,v58_3_tail);
        std::vector<Space> v59_3_outputs;
        v59_3_outputs.reserve(v59_3_branches.size());
        for (const auto& v59_3_branch : v59_3_branches) {
          const Path v59_3_head{v59_3_branch.first};
          const Space& v59_3_tail = v59_3_branch.second;
          const Path v60_2 = concat_path(v59_2,v59_3_head);
          const auto v60_3_branches = branches(c,v59_3_tail);
          std::vector<Space> v60_3_outputs;
          v60_3_outputs.reserve(v60_3_branches.size());
          for (const auto& v60_3_branch : v60_3_branches) {
            const Path v60_3_head{v60_3_branch.first};
            const Space& v60_3_tail = v60_3_branch.second;
            const auto v61_2_branches = branches(c,v60_3_tail);
            std::vector<Space> v61_2_outputs;
            v61_2_outputs.reserve(v61_2_branches.size());
            for (const auto& v61_2_branch : v61_2_branches) {
              const Path v61_2_head{v61_2_branch.first};
              const Space& v61_2_tail = v61_2_branch.second;
              const Path v62_2 = concat_path(v60_3_head,v61_2_head);
              const auto v62_3_branches = branches(c,v61_2_tail);
              std::vector<Space> v62_3_outputs;
              v62_3_outputs.reserve(v62_3_branches.size());
              for (const auto& v62_3_branch : v62_3_branches) {
                const Path v62_3_head{v62_3_branch.first};
                const Space& v62_3_tail = v62_3_branch.second;
                const Path v63_2 = concat_path(v62_2,v62_3_head);
                const auto v63_3_branches = branches(c,v62_3_tail);
                std::vector<Space> v63_3_outputs;
                v63_3_outputs.reserve(v63_3_branches.size());
                for (const auto& v63_3_branch : v63_3_branches) {
                  const Path v63_3_head{v63_3_branch.first};
                  const Space& v63_3_tail = v63_3_branch.second;
                  const Path v64_2 = concat_path(v63_2,v63_3_head);
                  const Space v64_3 = routine_9(c, v64_2, v60_2, v63_3_tail);
                  v63_3_outputs.push_back(v64_3);
                }
                const Space v63_3 = join_outputs(std::move(v63_3_outputs));
                v62_3_outputs.push_back(v63_3);
              }
              const Space v62_3 = join_outputs(std::move(v62_3_outputs));
              v61_2_outputs.push_back(v62_3);
            }
            const Space v61_2 = join_outputs(std::move(v61_2_outputs));
            v60_3_outputs.push_back(v61_2);
          }
          const Space v60_3 = join_outputs(std::move(v60_3_outputs));
          v59_3_outputs.push_back(v60_3);
        }
        const Space v59_3 = join_outputs(std::move(v59_3_outputs));
        v58_3_outputs.push_back(v59_3);
      }
      const Space v58_3 = join_outputs(std::move(v58_3_outputs));
      v57_2_outputs.push_back(v58_3);
    }
    const Space v57_2 = join_outputs(std::move(v57_2_outputs));
    v0_48_outputs.push_back(v57_2);
  }
  const Space v0_48 = join_outputs(std::move(v0_48_outputs));
  return v0_48;
}

static Space routine_1(Context& c, const Path& p0, const Path& p1, const Path& p2) {
  const Space v65_4 = unwrap(constant_10,p2);
  const Space v65_6 = unwrap(constant_10,p2);
  const Space v65_7 = compose(v65_4,v65_6);
  const Space v65_9 = unwrap(constant_10,p2);
  const Space v65_12 = unwrap(constant_11,p1);
  const Space v65_13 = unwrap(constant_11,p0);
  const auto v65_14_branches = branches(c,v65_9);
  std::vector<Space> v65_14_outputs;
  v65_14_outputs.reserve(v65_14_branches.size());
  for (const auto& v65_14_branch : v65_14_branches) {
    const Path v65_14_head{v65_14_branch.first};
    const Space& v65_14_tail = v65_14_branch.second;
    const Space v66_2 = unwrap(v65_12,v65_14_head);
    const Space v66_3 = unwrap(v65_13,v65_14_head);
    const auto v66_4_branches = branches(c,v65_14_tail);
    std::vector<Space> v66_4_outputs;
    v66_4_outputs.reserve(v66_4_branches.size());
    for (const auto& v66_4_branch : v66_4_branches) {
      const Path v66_4_head{v66_4_branch.first};
      const Space& v66_4_tail = v66_4_branch.second;
      const Path v67_2 = concat_path(v65_14_head,v66_4_head);
      const Space v67_3 = unwrap(v66_2,v66_4_head);
      const Space v67_4 = unwrap(v66_3,v66_4_head);
      const auto v67_5_branches = branches(c,v66_4_tail);
      std::vector<Space> v67_5_outputs;
      v67_5_outputs.reserve(v67_5_branches.size());
      for (const auto& v67_5_branch : v67_5_branches) {
        const Path v67_5_head{v67_5_branch.first};
        const Space& v67_5_tail = v67_5_branch.second;
        const Space v68_2 = unwrap(v67_3,v67_5_head);
        const Space v68_3 = unwrap(v67_4,v67_5_head);
        const Path v68_4 = concat_path(v67_2,v67_5_head);
        const auto v68_5_branches = branches(c,v67_5_tail);
        std::vector<Space> v68_5_outputs;
        v68_5_outputs.reserve(v68_5_branches.size());
        for (const auto& v68_5_branch : v68_5_branches) {
          const Path v68_5_head{v68_5_branch.first};
          const Space& v68_5_tail = v68_5_branch.second;
          const Space v69_2 = unwrap(v68_2,v68_5_head);
          const Space v69_3 = unwrap(v68_3,v68_5_head);
          const Space v69_4 = compose(v69_2,v69_3);
          const Path v69_5 = concat_path(v68_4,v68_5_head);
          const Path v69_6 = concat_path(v69_5,p0);
          const Space v69_7 = singleton(v69_6);
          const Space v69_8 = unite(v69_4,v69_7);
          const Path v69_9 = concat_path(p1,v69_5);
          const Space v69_10 = singleton(v69_9);
          const Space v69_11 = unite(v69_8,v69_10);
          v68_5_outputs.push_back(v69_11);
        }
        const Space v68_5 = join_outputs(std::move(v68_5_outputs));
        v67_5_outputs.push_back(v68_5);
      }
      const Space v67_5 = join_outputs(std::move(v67_5_outputs));
      v66_4_outputs.push_back(v67_5);
    }
    const Space v66_4 = join_outputs(std::move(v66_4_outputs));
    v65_14_outputs.push_back(v66_4);
  }
  const Space v65_14 = join_outputs(std::move(v65_14_outputs));
  const Space v65_15 = intersect(v65_7,v65_14);
  return v65_15;
}

static Space routine_2(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v70_7 = routine_10(c, constant_0, constant_3, p0, constant_12);
  const Space v70_9 = routine_10(c, constant_3, constant_3, p0, constant_12);
  const Space v70_10 = unite(v70_7,v70_9);
  const Space v70_13 = routine_10(c, constant_4, constant_3, p0, constant_12);
  const Space v70_14 = unite(v70_10,v70_13);
  const Space v70_17 = routine_10(c, constant_5, constant_3, p0, constant_12);
  const Space v70_18 = unite(v70_14,v70_17);
  const Space v70_21 = routine_10(c, constant_6, constant_3, p0, constant_12);
  const Space v70_22 = unite(v70_18,v70_21);
  const Space v70_25 = routine_10(c, constant_7, constant_3, p0, constant_12);
  const Space v70_26 = unite(v70_22,v70_25);
  const Space v70_29 = routine_10(c, constant_8, constant_3, p0, constant_12);
  const Space v70_30 = unite(v70_26,v70_29);
  const Space v70_33 = routine_10(c, constant_1, constant_3, p0, constant_12);
  const Space v70_34 = unite(v70_30,v70_33);
  const Space v70_36 = intersect(v70_34,constant_13);
  const Space v70_37 = unite(v70_36,s1);
  const Space v70_38 = wrap(v70_37,p1);
  const Space v70_39 = wrap(v70_38,p0);
  return v70_39;
}

static Space routine_3(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v71_5 = unwrap(s0,constant_4);
  const Space v71_6 = subtract(constant_9,v71_5);
  const Path v71_8 = concat_path(p1,p0);
  const auto v71_9_branches = branches(c,v71_6);
  std::vector<Space> v71_9_outputs;
  v71_9_outputs.reserve(v71_9_branches.size());
  for (const auto& v71_9_branch : v71_9_branches) {
    const Path v71_9_head{v71_9_branch.first};
    const Space& v71_9_tail = v71_9_branch.second;
    const auto v72_2_branches = branches(c,v71_9_tail);
    std::vector<Space> v72_2_outputs;
    v72_2_outputs.reserve(v72_2_branches.size());
    for (const auto& v72_2_branch : v72_2_branches) {
      const Path v72_2_head{v72_2_branch.first};
      const Space& v72_2_tail = v72_2_branch.second;
      const Path v73_2 = concat_path(v71_9_head,v72_2_head);
      const auto v73_3_branches = branches(c,v72_2_tail);
      std::vector<Space> v73_3_outputs;
      v73_3_outputs.reserve(v73_3_branches.size());
      for (const auto& v73_3_branch : v73_3_branches) {
        const Path v73_3_head{v73_3_branch.first};
        const Space& v73_3_tail = v73_3_branch.second;
        const Path v74_2 = concat_path(v73_2,v73_3_head);
        const auto v74_3_branches = branches(c,v73_3_tail);
        std::vector<Space> v74_3_outputs;
        v74_3_outputs.reserve(v74_3_branches.size());
        for (const auto& v74_3_branch : v74_3_branches) {
          const Path v74_3_head{v74_3_branch.first};
          const Space& v74_3_tail = v74_3_branch.second;
          const Path v75_2 = concat_path(v74_2,v74_3_head);
          const Space v75_3 = routine_1(c, v75_2, constant_4, constant_1);
          const Space v75_4 = unite(s0,v75_3);
          const Space v75_5 = wrap(v75_4,v71_8);
          const Space v75_6 = wrap(v75_5,v75_2);
          v74_3_outputs.push_back(v75_6);
        }
        const Space v74_3 = join_outputs(std::move(v74_3_outputs));
        v73_3_outputs.push_back(v74_3);
      }
      const Space v73_3 = join_outputs(std::move(v73_3_outputs));
      v72_2_outputs.push_back(v73_3);
    }
    const Space v72_2 = join_outputs(std::move(v72_2_outputs));
    v71_9_outputs.push_back(v72_2);
  }
  const Space v71_9 = join_outputs(std::move(v71_9_outputs));
  return v71_9;
}

static Space routine_4(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v76_5_branches = branches(c,s0);
  std::vector<Space> v76_5_outputs;
  v76_5_outputs.reserve(v76_5_branches.size());
  for (const auto& v76_5_branch : v76_5_branches) {
    const Path v76_5_head{v76_5_branch.first};
    const Space& v76_5_tail = v76_5_branch.second;
    const auto v77_2_branches = branches(c,v76_5_tail);
    std::vector<Space> v77_2_outputs;
    v77_2_outputs.reserve(v77_2_branches.size());
    for (const auto& v77_2_branch : v77_2_branches) {
      const Path v77_2_head{v77_2_branch.first};
      const Space& v77_2_tail = v77_2_branch.second;
      const Path v78_2 = concat_path(v76_5_head,v77_2_head);
      const auto v78_3_branches = branches(c,v77_2_tail);
      std::vector<Space> v78_3_outputs;
      v78_3_outputs.reserve(v78_3_branches.size());
      for (const auto& v78_3_branch : v78_3_branches) {
        const Path v78_3_head{v78_3_branch.first};
        const Space& v78_3_tail = v78_3_branch.second;
        const Path v79_2 = concat_path(v78_2,v78_3_head);
        const auto v79_3_branches = branches(c,v78_3_tail);
        std::vector<Space> v79_3_outputs;
        v79_3_outputs.reserve(v79_3_branches.size());
        for (const auto& v79_3_branch : v79_3_branches) {
          const Path v79_3_head{v79_3_branch.first};
          const Space& v79_3_tail = v79_3_branch.second;
          const Space v80_2 = unwrap(v79_3_tail,constant_5);
          const Space v80_3 = subtract(constant_9,v80_2);
          const Path v80_4 = concat_path(v79_2,v79_3_head);
          const auto v80_5_branches = branches(c,v80_3);
          std::vector<Space> v80_5_outputs;
          v80_5_outputs.reserve(v80_5_branches.size());
          for (const auto& v80_5_branch : v80_5_branches) {
            const Path v80_5_head{v80_5_branch.first};
            const Space& v80_5_tail = v80_5_branch.second;
            const auto v81_2_branches = branches(c,v80_5_tail);
            std::vector<Space> v81_2_outputs;
            v81_2_outputs.reserve(v81_2_branches.size());
            for (const auto& v81_2_branch : v81_2_branches) {
              const Path v81_2_head{v81_2_branch.first};
              const Space& v81_2_tail = v81_2_branch.second;
              const Path v82_2 = concat_path(v80_5_head,v81_2_head);
              const auto v82_3_branches = branches(c,v81_2_tail);
              std::vector<Space> v82_3_outputs;
              v82_3_outputs.reserve(v82_3_branches.size());
              for (const auto& v82_3_branch : v82_3_branches) {
                const Path v82_3_head{v82_3_branch.first};
                const Space& v82_3_tail = v82_3_branch.second;
                const Path v83_2 = concat_path(v82_2,v82_3_head);
                const auto v83_3_branches = branches(c,v82_3_tail);
                std::vector<Space> v83_3_outputs;
                v83_3_outputs.reserve(v83_3_branches.size());
                for (const auto& v83_3_branch : v83_3_branches) {
                  const Path v83_3_head{v83_3_branch.first};
                  const Space& v83_3_tail = v83_3_branch.second;
                  const Path v84_2 = concat_path(v83_2,v83_3_head);
                  const Space v84_3 = routine_11(c, v84_2, p1, p0, v80_4, v83_3_tail, v79_3_tail);
                  v83_3_outputs.push_back(v84_3);
                }
                const Space v83_3 = join_outputs(std::move(v83_3_outputs));
                v82_3_outputs.push_back(v83_3);
              }
              const Space v82_3 = join_outputs(std::move(v82_3_outputs));
              v81_2_outputs.push_back(v82_3);
            }
            const Space v81_2 = join_outputs(std::move(v81_2_outputs));
            v80_5_outputs.push_back(v81_2);
          }
          const Space v80_5 = join_outputs(std::move(v80_5_outputs));
          v79_3_outputs.push_back(v80_5);
        }
        const Space v79_3 = join_outputs(std::move(v79_3_outputs));
        v78_3_outputs.push_back(v79_3);
      }
      const Space v78_3 = join_outputs(std::move(v78_3_outputs));
      v77_2_outputs.push_back(v78_3);
    }
    const Space v77_2 = join_outputs(std::move(v77_2_outputs));
    v76_5_outputs.push_back(v77_2);
  }
  const Space v76_5 = join_outputs(std::move(v76_5_outputs));
  return v76_5;
}

static Space routine_5(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v85_3_branches = branches(c,s0);
  std::vector<Space> v85_3_outputs;
  v85_3_outputs.reserve(v85_3_branches.size());
  for (const auto& v85_3_branch : v85_3_branches) {
    const Path v85_3_head{v85_3_branch.first};
    const Space& v85_3_tail = v85_3_branch.second;
    const auto v86_2_branches = branches(c,v85_3_tail);
    std::vector<Space> v86_2_outputs;
    v86_2_outputs.reserve(v86_2_branches.size());
    for (const auto& v86_2_branch : v86_2_branches) {
      const Path v86_2_head{v86_2_branch.first};
      const Space& v86_2_tail = v86_2_branch.second;
      const Path v87_2 = concat_path(v85_3_head,v86_2_head);
      const auto v87_3_branches = branches(c,v86_2_tail);
      std::vector<Space> v87_3_outputs;
      v87_3_outputs.reserve(v87_3_branches.size());
      for (const auto& v87_3_branch : v87_3_branches) {
        const Path v87_3_head{v87_3_branch.first};
        const Space& v87_3_tail = v87_3_branch.second;
        const Path v88_2 = concat_path(v87_2,v87_3_head);
        const auto v88_3_branches = branches(c,v87_3_tail);
        std::vector<Space> v88_3_outputs;
        v88_3_outputs.reserve(v88_3_branches.size());
        for (const auto& v88_3_branch : v88_3_branches) {
          const Path v88_3_head{v88_3_branch.first};
          const Space& v88_3_tail = v88_3_branch.second;
          const Path v89_2 = concat_path(v88_2,v88_3_head);
          const auto v89_3_branches = branches(c,v88_3_tail);
          std::vector<Space> v89_3_outputs;
          v89_3_outputs.reserve(v89_3_branches.size());
          for (const auto& v89_3_branch : v89_3_branches) {
            const Path v89_3_head{v89_3_branch.first};
            const Space& v89_3_tail = v89_3_branch.second;
            const auto v90_2_branches = branches(c,v89_3_tail);
            std::vector<Space> v90_2_outputs;
            v90_2_outputs.reserve(v90_2_branches.size());
            for (const auto& v90_2_branch : v90_2_branches) {
              const Path v90_2_head{v90_2_branch.first};
              const Space& v90_2_tail = v90_2_branch.second;
              const Path v91_2 = concat_path(v89_3_head,v90_2_head);
              const auto v91_3_branches = branches(c,v90_2_tail);
              std::vector<Space> v91_3_outputs;
              v91_3_outputs.reserve(v91_3_branches.size());
              for (const auto& v91_3_branch : v91_3_branches) {
                const Path v91_3_head{v91_3_branch.first};
                const Space& v91_3_tail = v91_3_branch.second;
                const Path v92_2 = concat_path(v91_2,v91_3_head);
                const auto v92_3_branches = branches(c,v91_3_tail);
                std::vector<Space> v92_3_outputs;
                v92_3_outputs.reserve(v92_3_branches.size());
                for (const auto& v92_3_branch : v92_3_branches) {
                  const Path v92_3_head{v92_3_branch.first};
                  const Space& v92_3_tail = v92_3_branch.second;
                  const Path v93_2 = concat_path(v92_2,v92_3_head);
                  const Space v93_3 = routine_12(c, v93_2, p0, v89_2, p1, v92_3_tail);
                  v92_3_outputs.push_back(v93_3);
                }
                const Space v92_3 = join_outputs(std::move(v92_3_outputs));
                v91_3_outputs.push_back(v92_3);
              }
              const Space v91_3 = join_outputs(std::move(v91_3_outputs));
              v90_2_outputs.push_back(v91_3);
            }
            const Space v90_2 = join_outputs(std::move(v90_2_outputs));
            v89_3_outputs.push_back(v90_2);
          }
          const Space v89_3 = join_outputs(std::move(v89_3_outputs));
          v88_3_outputs.push_back(v89_3);
        }
        const Space v88_3 = join_outputs(std::move(v88_3_outputs));
        v87_3_outputs.push_back(v88_3);
      }
      const Space v87_3 = join_outputs(std::move(v87_3_outputs));
      v86_2_outputs.push_back(v87_3);
    }
    const Space v86_2 = join_outputs(std::move(v86_2_outputs));
    v85_3_outputs.push_back(v86_2);
  }
  const Space v85_3 = join_outputs(std::move(v85_3_outputs));
  return v85_3;
}

static Space routine_6(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v94_3_branches = branches(c,s0);
  std::vector<Space> v94_3_outputs;
  v94_3_outputs.reserve(v94_3_branches.size());
  for (const auto& v94_3_branch : v94_3_branches) {
    const Path v94_3_head{v94_3_branch.first};
    const Space& v94_3_tail = v94_3_branch.second;
    const auto v95_2_branches = branches(c,v94_3_tail);
    std::vector<Space> v95_2_outputs;
    v95_2_outputs.reserve(v95_2_branches.size());
    for (const auto& v95_2_branch : v95_2_branches) {
      const Path v95_2_head{v95_2_branch.first};
      const Space& v95_2_tail = v95_2_branch.second;
      const Path v96_2 = concat_path(v94_3_head,v95_2_head);
      const auto v96_3_branches = branches(c,v95_2_tail);
      std::vector<Space> v96_3_outputs;
      v96_3_outputs.reserve(v96_3_branches.size());
      for (const auto& v96_3_branch : v96_3_branches) {
        const Path v96_3_head{v96_3_branch.first};
        const Space& v96_3_tail = v96_3_branch.second;
        const Path v97_2 = concat_path(v96_2,v96_3_head);
        const auto v97_3_branches = branches(c,v96_3_tail);
        std::vector<Space> v97_3_outputs;
        v97_3_outputs.reserve(v97_3_branches.size());
        for (const auto& v97_3_branch : v97_3_branches) {
          const Path v97_3_head{v97_3_branch.first};
          const Space& v97_3_tail = v97_3_branch.second;
          const Path v98_2 = concat_path(v97_2,v97_3_head);
          const auto v98_3_branches = branches(c,v97_3_tail);
          std::vector<Space> v98_3_outputs;
          v98_3_outputs.reserve(v98_3_branches.size());
          for (const auto& v98_3_branch : v98_3_branches) {
            const Path v98_3_head{v98_3_branch.first};
            const Space& v98_3_tail = v98_3_branch.second;
            const auto v99_2_branches = branches(c,v98_3_tail);
            std::vector<Space> v99_2_outputs;
            v99_2_outputs.reserve(v99_2_branches.size());
            for (const auto& v99_2_branch : v99_2_branches) {
              const Path v99_2_head{v99_2_branch.first};
              const Space& v99_2_tail = v99_2_branch.second;
              const Path v100_2 = concat_path(v98_3_head,v99_2_head);
              const auto v100_3_branches = branches(c,v99_2_tail);
              std::vector<Space> v100_3_outputs;
              v100_3_outputs.reserve(v100_3_branches.size());
              for (const auto& v100_3_branch : v100_3_branches) {
                const Path v100_3_head{v100_3_branch.first};
                const Space& v100_3_tail = v100_3_branch.second;
                const Path v101_2 = concat_path(v100_2,v100_3_head);
                const auto v101_3_branches = branches(c,v100_3_tail);
                std::vector<Space> v101_3_outputs;
                v101_3_outputs.reserve(v101_3_branches.size());
                for (const auto& v101_3_branch : v101_3_branches) {
                  const Path v101_3_head{v101_3_branch.first};
                  const Space& v101_3_tail = v101_3_branch.second;
                  const Path v102_2 = concat_path(v101_2,v101_3_head);
                  const Space v102_3 = routine_13(c, v102_2, p1, p0, v98_2, v101_3_tail);
                  v101_3_outputs.push_back(v102_3);
                }
                const Space v101_3 = join_outputs(std::move(v101_3_outputs));
                v100_3_outputs.push_back(v101_3);
              }
              const Space v100_3 = join_outputs(std::move(v100_3_outputs));
              v99_2_outputs.push_back(v100_3);
            }
            const Space v99_2 = join_outputs(std::move(v99_2_outputs));
            v98_3_outputs.push_back(v99_2);
          }
          const Space v98_3 = join_outputs(std::move(v98_3_outputs));
          v97_3_outputs.push_back(v98_3);
        }
        const Space v97_3 = join_outputs(std::move(v97_3_outputs));
        v96_3_outputs.push_back(v97_3);
      }
      const Space v96_3 = join_outputs(std::move(v96_3_outputs));
      v95_2_outputs.push_back(v96_3);
    }
    const Space v95_2 = join_outputs(std::move(v95_2_outputs));
    v94_3_outputs.push_back(v95_2);
  }
  const Space v94_3 = join_outputs(std::move(v94_3_outputs));
  return v94_3;
}

static Space routine_7(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v103_3_branches = branches(c,s0);
  std::vector<Space> v103_3_outputs;
  v103_3_outputs.reserve(v103_3_branches.size());
  for (const auto& v103_3_branch : v103_3_branches) {
    const Path v103_3_head{v103_3_branch.first};
    const Space& v103_3_tail = v103_3_branch.second;
    const auto v104_2_branches = branches(c,v103_3_tail);
    std::vector<Space> v104_2_outputs;
    v104_2_outputs.reserve(v104_2_branches.size());
    for (const auto& v104_2_branch : v104_2_branches) {
      const Path v104_2_head{v104_2_branch.first};
      const Space& v104_2_tail = v104_2_branch.second;
      const Path v105_2 = concat_path(v103_3_head,v104_2_head);
      const auto v105_3_branches = branches(c,v104_2_tail);
      std::vector<Space> v105_3_outputs;
      v105_3_outputs.reserve(v105_3_branches.size());
      for (const auto& v105_3_branch : v105_3_branches) {
        const Path v105_3_head{v105_3_branch.first};
        const Space& v105_3_tail = v105_3_branch.second;
        const Path v106_2 = concat_path(v105_2,v105_3_head);
        const auto v106_3_branches = branches(c,v105_3_tail);
        std::vector<Space> v106_3_outputs;
        v106_3_outputs.reserve(v106_3_branches.size());
        for (const auto& v106_3_branch : v106_3_branches) {
          const Path v106_3_head{v106_3_branch.first};
          const Space& v106_3_tail = v106_3_branch.second;
          const Path v107_2 = concat_path(v106_2,v106_3_head);
          const auto v107_3_branches = branches(c,v106_3_tail);
          std::vector<Space> v107_3_outputs;
          v107_3_outputs.reserve(v107_3_branches.size());
          for (const auto& v107_3_branch : v107_3_branches) {
            const Path v107_3_head{v107_3_branch.first};
            const Space& v107_3_tail = v107_3_branch.second;
            const auto v108_2_branches = branches(c,v107_3_tail);
            std::vector<Space> v108_2_outputs;
            v108_2_outputs.reserve(v108_2_branches.size());
            for (const auto& v108_2_branch : v108_2_branches) {
              const Path v108_2_head{v108_2_branch.first};
              const Space& v108_2_tail = v108_2_branch.second;
              const Path v109_2 = concat_path(v107_3_head,v108_2_head);
              const auto v109_3_branches = branches(c,v108_2_tail);
              std::vector<Space> v109_3_outputs;
              v109_3_outputs.reserve(v109_3_branches.size());
              for (const auto& v109_3_branch : v109_3_branches) {
                const Path v109_3_head{v109_3_branch.first};
                const Space& v109_3_tail = v109_3_branch.second;
                const Path v110_2 = concat_path(v109_2,v109_3_head);
                const auto v110_3_branches = branches(c,v109_3_tail);
                std::vector<Space> v110_3_outputs;
                v110_3_outputs.reserve(v110_3_branches.size());
                for (const auto& v110_3_branch : v110_3_branches) {
                  const Path v110_3_head{v110_3_branch.first};
                  const Space& v110_3_tail = v110_3_branch.second;
                  const Path v111_2 = concat_path(v110_2,v110_3_head);
                  const Space v111_3 = routine_14(c, v111_2, p1, p0, v107_2, v110_3_tail);
                  v110_3_outputs.push_back(v111_3);
                }
                const Space v110_3 = join_outputs(std::move(v110_3_outputs));
                v109_3_outputs.push_back(v110_3);
              }
              const Space v109_3 = join_outputs(std::move(v109_3_outputs));
              v108_2_outputs.push_back(v109_3);
            }
            const Space v108_2 = join_outputs(std::move(v108_2_outputs));
            v107_3_outputs.push_back(v108_2);
          }
          const Space v107_3 = join_outputs(std::move(v107_3_outputs));
          v106_3_outputs.push_back(v107_3);
        }
        const Space v106_3 = join_outputs(std::move(v106_3_outputs));
        v105_3_outputs.push_back(v106_3);
      }
      const Space v105_3 = join_outputs(std::move(v105_3_outputs));
      v104_2_outputs.push_back(v105_3);
    }
    const Space v104_2 = join_outputs(std::move(v104_2_outputs));
    v103_3_outputs.push_back(v104_2);
  }
  const Space v103_3 = join_outputs(std::move(v103_3_outputs));
  return v103_3;
}

static Space routine_8(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v112_3_branches = branches(c,s0);
  std::vector<Space> v112_3_outputs;
  v112_3_outputs.reserve(v112_3_branches.size());
  for (const auto& v112_3_branch : v112_3_branches) {
    const Path v112_3_head{v112_3_branch.first};
    const Space& v112_3_tail = v112_3_branch.second;
    const auto v113_2_branches = branches(c,v112_3_tail);
    std::vector<Space> v113_2_outputs;
    v113_2_outputs.reserve(v113_2_branches.size());
    for (const auto& v113_2_branch : v113_2_branches) {
      const Path v113_2_head{v113_2_branch.first};
      const Space& v113_2_tail = v113_2_branch.second;
      const Path v114_2 = concat_path(v112_3_head,v113_2_head);
      const auto v114_3_branches = branches(c,v113_2_tail);
      std::vector<Space> v114_3_outputs;
      v114_3_outputs.reserve(v114_3_branches.size());
      for (const auto& v114_3_branch : v114_3_branches) {
        const Path v114_3_head{v114_3_branch.first};
        const Space& v114_3_tail = v114_3_branch.second;
        const Path v115_2 = concat_path(v114_2,v114_3_head);
        const auto v115_3_branches = branches(c,v114_3_tail);
        std::vector<Space> v115_3_outputs;
        v115_3_outputs.reserve(v115_3_branches.size());
        for (const auto& v115_3_branch : v115_3_branches) {
          const Path v115_3_head{v115_3_branch.first};
          const Space& v115_3_tail = v115_3_branch.second;
          const Path v116_2 = concat_path(v115_2,v115_3_head);
          const auto v116_3_branches = branches(c,v115_3_tail);
          std::vector<Space> v116_3_outputs;
          v116_3_outputs.reserve(v116_3_branches.size());
          for (const auto& v116_3_branch : v116_3_branches) {
            const Path v116_3_head{v116_3_branch.first};
            const Space& v116_3_tail = v116_3_branch.second;
            const auto v117_2_branches = branches(c,v116_3_tail);
            std::vector<Space> v117_2_outputs;
            v117_2_outputs.reserve(v117_2_branches.size());
            for (const auto& v117_2_branch : v117_2_branches) {
              const Path v117_2_head{v117_2_branch.first};
              const Space& v117_2_tail = v117_2_branch.second;
              const Path v118_2 = concat_path(v116_3_head,v117_2_head);
              const auto v118_3_branches = branches(c,v117_2_tail);
              std::vector<Space> v118_3_outputs;
              v118_3_outputs.reserve(v118_3_branches.size());
              for (const auto& v118_3_branch : v118_3_branches) {
                const Path v118_3_head{v118_3_branch.first};
                const Space& v118_3_tail = v118_3_branch.second;
                const Path v119_2 = concat_path(v118_2,v118_3_head);
                const auto v119_3_branches = branches(c,v118_3_tail);
                std::vector<Space> v119_3_outputs;
                v119_3_outputs.reserve(v119_3_branches.size());
                for (const auto& v119_3_branch : v119_3_branches) {
                  const Path v119_3_head{v119_3_branch.first};
                  const Space& v119_3_tail = v119_3_branch.second;
                  const Path v120_2 = concat_path(v119_2,v119_3_head);
                  const Space v120_3 = routine_15(c, v120_2, p1, p0, v116_2, v119_3_tail);
                  v119_3_outputs.push_back(v120_3);
                }
                const Space v119_3 = join_outputs(std::move(v119_3_outputs));
                v118_3_outputs.push_back(v119_3);
              }
              const Space v118_3 = join_outputs(std::move(v118_3_outputs));
              v117_2_outputs.push_back(v118_3);
            }
            const Space v117_2 = join_outputs(std::move(v117_2_outputs));
            v116_3_outputs.push_back(v117_2);
          }
          const Space v116_3 = join_outputs(std::move(v116_3_outputs));
          v115_3_outputs.push_back(v116_3);
        }
        const Space v115_3 = join_outputs(std::move(v115_3_outputs));
        v114_3_outputs.push_back(v115_3);
      }
      const Space v114_3 = join_outputs(std::move(v114_3_outputs));
      v113_2_outputs.push_back(v114_3);
    }
    const Space v113_2 = join_outputs(std::move(v113_2_outputs));
    v112_3_outputs.push_back(v113_2);
  }
  const Space v112_3 = join_outputs(std::move(v112_3_outputs));
  return v112_3;
}

static Space routine_9(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v121_3_branches = branches(c,s0);
  std::vector<Space> v121_3_outputs;
  v121_3_outputs.reserve(v121_3_branches.size());
  for (const auto& v121_3_branch : v121_3_branches) {
    const Path v121_3_head{v121_3_branch.first};
    const Space& v121_3_tail = v121_3_branch.second;
    const auto v122_2_branches = branches(c,v121_3_tail);
    std::vector<Space> v122_2_outputs;
    v122_2_outputs.reserve(v122_2_branches.size());
    for (const auto& v122_2_branch : v122_2_branches) {
      const Path v122_2_head{v122_2_branch.first};
      const Space& v122_2_tail = v122_2_branch.second;
      const Path v123_2 = concat_path(v121_3_head,v122_2_head);
      const auto v123_3_branches = branches(c,v122_2_tail);
      std::vector<Space> v123_3_outputs;
      v123_3_outputs.reserve(v123_3_branches.size());
      for (const auto& v123_3_branch : v123_3_branches) {
        const Path v123_3_head{v123_3_branch.first};
        const Space& v123_3_tail = v123_3_branch.second;
        const Path v124_2 = concat_path(v123_2,v123_3_head);
        const auto v124_3_branches = branches(c,v123_3_tail);
        std::vector<Space> v124_3_outputs;
        v124_3_outputs.reserve(v124_3_branches.size());
        for (const auto& v124_3_branch : v124_3_branches) {
          const Path v124_3_head{v124_3_branch.first};
          const Space& v124_3_tail = v124_3_branch.second;
          const Path v125_2 = concat_path(v124_2,v124_3_head);
          const auto v125_3_branches = branches(c,v124_3_tail);
          std::vector<Space> v125_3_outputs;
          v125_3_outputs.reserve(v125_3_branches.size());
          for (const auto& v125_3_branch : v125_3_branches) {
            const Path v125_3_head{v125_3_branch.first};
            const Space& v125_3_tail = v125_3_branch.second;
            const auto v126_2_branches = branches(c,v125_3_tail);
            std::vector<Space> v126_2_outputs;
            v126_2_outputs.reserve(v126_2_branches.size());
            for (const auto& v126_2_branch : v126_2_branches) {
              const Path v126_2_head{v126_2_branch.first};
              const Space& v126_2_tail = v126_2_branch.second;
              const Path v127_2 = concat_path(v125_3_head,v126_2_head);
              const auto v127_3_branches = branches(c,v126_2_tail);
              std::vector<Space> v127_3_outputs;
              v127_3_outputs.reserve(v127_3_branches.size());
              for (const auto& v127_3_branch : v127_3_branches) {
                const Path v127_3_head{v127_3_branch.first};
                const Space& v127_3_tail = v127_3_branch.second;
                const Path v128_2 = concat_path(v127_2,v127_3_head);
                const auto v128_3_branches = branches(c,v127_3_tail);
                std::vector<Space> v128_3_outputs;
                v128_3_outputs.reserve(v128_3_branches.size());
                for (const auto& v128_3_branch : v128_3_branches) {
                  const Path v128_3_head{v128_3_branch.first};
                  const Space& v128_3_tail = v128_3_branch.second;
                  const Path v129_2 = concat_path(v128_2,v128_3_head);
                  const Space v129_3 = routine_16(c, v129_2, p1, p0, v125_2, v128_3_tail);
                  v128_3_outputs.push_back(v129_3);
                }
                const Space v128_3 = join_outputs(std::move(v128_3_outputs));
                v127_3_outputs.push_back(v128_3);
              }
              const Space v127_3 = join_outputs(std::move(v127_3_outputs));
              v126_2_outputs.push_back(v127_3);
            }
            const Space v126_2 = join_outputs(std::move(v126_2_outputs));
            v125_3_outputs.push_back(v126_2);
          }
          const Space v125_3 = join_outputs(std::move(v125_3_outputs));
          v124_3_outputs.push_back(v125_3);
        }
        const Space v124_3 = join_outputs(std::move(v124_3_outputs));
        v123_3_outputs.push_back(v124_3);
      }
      const Space v123_3 = join_outputs(std::move(v123_3_outputs));
      v122_2_outputs.push_back(v123_3);
    }
    const Space v122_2 = join_outputs(std::move(v122_2_outputs));
    v121_3_outputs.push_back(v122_2);
  }
  const Space v121_3 = join_outputs(std::move(v121_3_outputs));
  return v121_3;
}

static Space routine_10(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const Space v130_5 = unwrap(constant_11,p1);
  const Space v130_6 = unwrap(v130_5,p0);
  const Space v130_8 = unwrap(constant_11,p2);
  const Space v130_9 = unwrap(v130_8,p0);
  const Space v130_10 = compose(v130_6,v130_9);
  const Path v130_11 = concat_path(p0,p2);
  const Space v130_12 = singleton(v130_11);
  const Space v130_13 = unite(v130_10,v130_12);
  const Path v130_14 = concat_path(p1,p0);
  const Space v130_15 = singleton(v130_14);
  const Space v130_16 = unite(v130_13,v130_15);
  return v130_16;
}

static Space routine_11(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0, const Space& s1) {
  const Space v131_9 = routine_10(c, constant_0, constant_5, p0, constant_12);
  const Space v131_12 = routine_10(c, constant_3, constant_5, p0, constant_12);
  const Space v131_13 = unite(v131_9,v131_12);
  const Space v131_16 = routine_10(c, constant_4, constant_5, p0, constant_12);
  const Space v131_17 = unite(v131_13,v131_16);
  const Space v131_19 = routine_10(c, constant_5, constant_5, p0, constant_12);
  const Space v131_20 = unite(v131_17,v131_19);
  const Space v131_23 = routine_10(c, constant_6, constant_5, p0, constant_12);
  const Space v131_24 = unite(v131_20,v131_23);
  const Space v131_27 = routine_10(c, constant_7, constant_5, p0, constant_12);
  const Space v131_28 = unite(v131_24,v131_27);
  const Space v131_31 = routine_10(c, constant_8, constant_5, p0, constant_12);
  const Space v131_32 = unite(v131_28,v131_31);
  const Space v131_35 = routine_10(c, constant_1, constant_5, p0, constant_12);
  const Space v131_36 = unite(v131_32,v131_35);
  const Space v131_38 = intersect(v131_36,constant_13);
  const Space v131_39 = unite(v131_38,s1);
  const Path v131_40 = concat_path(p1,p2);
  const Path v131_41 = concat_path(v131_40,p3);
  const Space v131_42 = wrap(v131_39,v131_41);
  const Space v131_43 = wrap(v131_42,p0);
  return v131_43;
}

static Space routine_12(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const Space v132_7 = unwrap(s0,constant_6);
  const Space v132_8 = subtract(constant_9,v132_7);
  const Path v132_10 = concat_path(p3,p1);
  const Path v132_11 = concat_path(v132_10,p2);
  const Path v132_12 = concat_path(v132_11,p0);
  const auto v132_13_branches = branches(c,v132_8);
  std::vector<Space> v132_13_outputs;
  v132_13_outputs.reserve(v132_13_branches.size());
  for (const auto& v132_13_branch : v132_13_branches) {
    const Path v132_13_head{v132_13_branch.first};
    const Space& v132_13_tail = v132_13_branch.second;
    const auto v133_2_branches = branches(c,v132_13_tail);
    std::vector<Space> v133_2_outputs;
    v133_2_outputs.reserve(v133_2_branches.size());
    for (const auto& v133_2_branch : v133_2_branches) {
      const Path v133_2_head{v133_2_branch.first};
      const Space& v133_2_tail = v133_2_branch.second;
      const Path v134_2 = concat_path(v132_13_head,v133_2_head);
      const auto v134_3_branches = branches(c,v133_2_tail);
      std::vector<Space> v134_3_outputs;
      v134_3_outputs.reserve(v134_3_branches.size());
      for (const auto& v134_3_branch : v134_3_branches) {
        const Path v134_3_head{v134_3_branch.first};
        const Space& v134_3_tail = v134_3_branch.second;
        const Path v135_2 = concat_path(v134_2,v134_3_head);
        const auto v135_3_branches = branches(c,v134_3_tail);
        std::vector<Space> v135_3_outputs;
        v135_3_outputs.reserve(v135_3_branches.size());
        for (const auto& v135_3_branch : v135_3_branches) {
          const Path v135_3_head{v135_3_branch.first};
          const Space& v135_3_tail = v135_3_branch.second;
          const Path v136_2 = concat_path(v135_2,v135_3_head);
          const Space v136_3 = routine_1(c, v136_2, constant_6, constant_1);
          const Space v136_4 = unite(s0,v136_3);
          const Space v136_5 = wrap(v136_4,v132_12);
          const Space v136_6 = wrap(v136_5,v136_2);
          v135_3_outputs.push_back(v136_6);
        }
        const Space v135_3 = join_outputs(std::move(v135_3_outputs));
        v134_3_outputs.push_back(v135_3);
      }
      const Space v134_3 = join_outputs(std::move(v134_3_outputs));
      v133_2_outputs.push_back(v134_3);
    }
    const Space v133_2 = join_outputs(std::move(v133_2_outputs));
    v132_13_outputs.push_back(v133_2);
  }
  const Space v132_13 = join_outputs(std::move(v132_13_outputs));
  return v132_13;
}

static Space routine_13(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v137_7_branches = branches(c,s0);
  std::vector<Space> v137_7_outputs;
  v137_7_outputs.reserve(v137_7_branches.size());
  for (const auto& v137_7_branch : v137_7_branches) {
    const Path v137_7_head{v137_7_branch.first};
    const Space& v137_7_tail = v137_7_branch.second;
    const auto v138_2_branches = branches(c,v137_7_tail);
    std::vector<Space> v138_2_outputs;
    v138_2_outputs.reserve(v138_2_branches.size());
    for (const auto& v138_2_branch : v138_2_branches) {
      const Path v138_2_head{v138_2_branch.first};
      const Space& v138_2_tail = v138_2_branch.second;
      const Path v139_2 = concat_path(v137_7_head,v138_2_head);
      const auto v139_3_branches = branches(c,v138_2_tail);
      std::vector<Space> v139_3_outputs;
      v139_3_outputs.reserve(v139_3_branches.size());
      for (const auto& v139_3_branch : v139_3_branches) {
        const Path v139_3_head{v139_3_branch.first};
        const Space& v139_3_tail = v139_3_branch.second;
        const Path v140_2 = concat_path(v139_2,v139_3_head);
        const auto v140_3_branches = branches(c,v139_3_tail);
        std::vector<Space> v140_3_outputs;
        v140_3_outputs.reserve(v140_3_branches.size());
        for (const auto& v140_3_branch : v140_3_branches) {
          const Path v140_3_head{v140_3_branch.first};
          const Space& v140_3_tail = v140_3_branch.second;
          const Space v141_2 = unwrap(v140_3_tail,constant_7);
          const Space v141_3 = subtract(constant_9,v141_2);
          const Path v141_4 = concat_path(v140_2,v140_3_head);
          const auto v141_5_branches = branches(c,v141_3);
          std::vector<Space> v141_5_outputs;
          v141_5_outputs.reserve(v141_5_branches.size());
          for (const auto& v141_5_branch : v141_5_branches) {
            const Path v141_5_head{v141_5_branch.first};
            const Space& v141_5_tail = v141_5_branch.second;
            const auto v142_2_branches = branches(c,v141_5_tail);
            std::vector<Space> v142_2_outputs;
            v142_2_outputs.reserve(v142_2_branches.size());
            for (const auto& v142_2_branch : v142_2_branches) {
              const Path v142_2_head{v142_2_branch.first};
              const Space& v142_2_tail = v142_2_branch.second;
              const Path v143_2 = concat_path(v141_5_head,v142_2_head);
              const auto v143_3_branches = branches(c,v142_2_tail);
              std::vector<Space> v143_3_outputs;
              v143_3_outputs.reserve(v143_3_branches.size());
              for (const auto& v143_3_branch : v143_3_branches) {
                const Path v143_3_head{v143_3_branch.first};
                const Space& v143_3_tail = v143_3_branch.second;
                const Path v144_2 = concat_path(v143_2,v143_3_head);
                const auto v144_3_branches = branches(c,v143_3_tail);
                std::vector<Space> v144_3_outputs;
                v144_3_outputs.reserve(v144_3_branches.size());
                for (const auto& v144_3_branch : v144_3_branches) {
                  const Path v144_3_head{v144_3_branch.first};
                  const Space& v144_3_tail = v144_3_branch.second;
                  const Path v145_2 = concat_path(v144_2,v144_3_head);
                  const Space v145_3 = routine_17(c, v145_2, p1, p2, p3, p0, v141_4, v144_3_tail, v140_3_tail);
                  v144_3_outputs.push_back(v145_3);
                }
                const Space v144_3 = join_outputs(std::move(v144_3_outputs));
                v143_3_outputs.push_back(v144_3);
              }
              const Space v143_3 = join_outputs(std::move(v143_3_outputs));
              v142_2_outputs.push_back(v143_3);
            }
            const Space v142_2 = join_outputs(std::move(v142_2_outputs));
            v141_5_outputs.push_back(v142_2);
          }
          const Space v141_5 = join_outputs(std::move(v141_5_outputs));
          v140_3_outputs.push_back(v141_5);
        }
        const Space v140_3 = join_outputs(std::move(v140_3_outputs));
        v139_3_outputs.push_back(v140_3);
      }
      const Space v139_3 = join_outputs(std::move(v139_3_outputs));
      v138_2_outputs.push_back(v139_3);
    }
    const Space v138_2 = join_outputs(std::move(v138_2_outputs));
    v137_7_outputs.push_back(v138_2);
  }
  const Space v137_7 = join_outputs(std::move(v137_7_outputs));
  return v137_7;
}

static Space routine_14(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v146_5_branches = branches(c,s0);
  std::vector<Space> v146_5_outputs;
  v146_5_outputs.reserve(v146_5_branches.size());
  for (const auto& v146_5_branch : v146_5_branches) {
    const Path v146_5_head{v146_5_branch.first};
    const Space& v146_5_tail = v146_5_branch.second;
    const auto v147_2_branches = branches(c,v146_5_tail);
    std::vector<Space> v147_2_outputs;
    v147_2_outputs.reserve(v147_2_branches.size());
    for (const auto& v147_2_branch : v147_2_branches) {
      const Path v147_2_head{v147_2_branch.first};
      const Space& v147_2_tail = v147_2_branch.second;
      const Path v148_2 = concat_path(v146_5_head,v147_2_head);
      const auto v148_3_branches = branches(c,v147_2_tail);
      std::vector<Space> v148_3_outputs;
      v148_3_outputs.reserve(v148_3_branches.size());
      for (const auto& v148_3_branch : v148_3_branches) {
        const Path v148_3_head{v148_3_branch.first};
        const Space& v148_3_tail = v148_3_branch.second;
        const Path v149_2 = concat_path(v148_2,v148_3_head);
        const auto v149_3_branches = branches(c,v148_3_tail);
        std::vector<Space> v149_3_outputs;
        v149_3_outputs.reserve(v149_3_branches.size());
        for (const auto& v149_3_branch : v149_3_branches) {
          const Path v149_3_head{v149_3_branch.first};
          const Space& v149_3_tail = v149_3_branch.second;
          const Path v150_2 = concat_path(v149_2,v149_3_head);
          const auto v150_3_branches = branches(c,v149_3_tail);
          std::vector<Space> v150_3_outputs;
          v150_3_outputs.reserve(v150_3_branches.size());
          for (const auto& v150_3_branch : v150_3_branches) {
            const Path v150_3_head{v150_3_branch.first};
            const Space& v150_3_tail = v150_3_branch.second;
            const auto v151_2_branches = branches(c,v150_3_tail);
            std::vector<Space> v151_2_outputs;
            v151_2_outputs.reserve(v151_2_branches.size());
            for (const auto& v151_2_branch : v151_2_branches) {
              const Path v151_2_head{v151_2_branch.first};
              const Space& v151_2_tail = v151_2_branch.second;
              const Path v152_2 = concat_path(v150_3_head,v151_2_head);
              const auto v152_3_branches = branches(c,v151_2_tail);
              std::vector<Space> v152_3_outputs;
              v152_3_outputs.reserve(v152_3_branches.size());
              for (const auto& v152_3_branch : v152_3_branches) {
                const Path v152_3_head{v152_3_branch.first};
                const Space& v152_3_tail = v152_3_branch.second;
                const Path v153_2 = concat_path(v152_2,v152_3_head);
                const auto v153_3_branches = branches(c,v152_3_tail);
                std::vector<Space> v153_3_outputs;
                v153_3_outputs.reserve(v153_3_branches.size());
                for (const auto& v153_3_branch : v153_3_branches) {
                  const Path v153_3_head{v153_3_branch.first};
                  const Space& v153_3_tail = v153_3_branch.second;
                  const Path v154_2 = concat_path(v153_2,v153_3_head);
                  const Space v154_3 = routine_18(c, v154_2, p1, p2, p3, p0, v150_2, v153_3_tail);
                  v153_3_outputs.push_back(v154_3);
                }
                const Space v153_3 = join_outputs(std::move(v153_3_outputs));
                v152_3_outputs.push_back(v153_3);
              }
              const Space v152_3 = join_outputs(std::move(v152_3_outputs));
              v151_2_outputs.push_back(v152_3);
            }
            const Space v151_2 = join_outputs(std::move(v151_2_outputs));
            v150_3_outputs.push_back(v151_2);
          }
          const Space v150_3 = join_outputs(std::move(v150_3_outputs));
          v149_3_outputs.push_back(v150_3);
        }
        const Space v149_3 = join_outputs(std::move(v149_3_outputs));
        v148_3_outputs.push_back(v149_3);
      }
      const Space v148_3 = join_outputs(std::move(v148_3_outputs));
      v147_2_outputs.push_back(v148_3);
    }
    const Space v147_2 = join_outputs(std::move(v147_2_outputs));
    v146_5_outputs.push_back(v147_2);
  }
  const Space v146_5 = join_outputs(std::move(v146_5_outputs));
  return v146_5;
}

static Space routine_15(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v155_5_branches = branches(c,s0);
  std::vector<Space> v155_5_outputs;
  v155_5_outputs.reserve(v155_5_branches.size());
  for (const auto& v155_5_branch : v155_5_branches) {
    const Path v155_5_head{v155_5_branch.first};
    const Space& v155_5_tail = v155_5_branch.second;
    const auto v156_2_branches = branches(c,v155_5_tail);
    std::vector<Space> v156_2_outputs;
    v156_2_outputs.reserve(v156_2_branches.size());
    for (const auto& v156_2_branch : v156_2_branches) {
      const Path v156_2_head{v156_2_branch.first};
      const Space& v156_2_tail = v156_2_branch.second;
      const Path v157_2 = concat_path(v155_5_head,v156_2_head);
      const auto v157_3_branches = branches(c,v156_2_tail);
      std::vector<Space> v157_3_outputs;
      v157_3_outputs.reserve(v157_3_branches.size());
      for (const auto& v157_3_branch : v157_3_branches) {
        const Path v157_3_head{v157_3_branch.first};
        const Space& v157_3_tail = v157_3_branch.second;
        const Path v158_2 = concat_path(v157_2,v157_3_head);
        const auto v158_3_branches = branches(c,v157_3_tail);
        std::vector<Space> v158_3_outputs;
        v158_3_outputs.reserve(v158_3_branches.size());
        for (const auto& v158_3_branch : v158_3_branches) {
          const Path v158_3_head{v158_3_branch.first};
          const Space& v158_3_tail = v158_3_branch.second;
          const Path v159_2 = concat_path(v158_2,v158_3_head);
          const auto v159_3_branches = branches(c,v158_3_tail);
          std::vector<Space> v159_3_outputs;
          v159_3_outputs.reserve(v159_3_branches.size());
          for (const auto& v159_3_branch : v159_3_branches) {
            const Path v159_3_head{v159_3_branch.first};
            const Space& v159_3_tail = v159_3_branch.second;
            const auto v160_2_branches = branches(c,v159_3_tail);
            std::vector<Space> v160_2_outputs;
            v160_2_outputs.reserve(v160_2_branches.size());
            for (const auto& v160_2_branch : v160_2_branches) {
              const Path v160_2_head{v160_2_branch.first};
              const Space& v160_2_tail = v160_2_branch.second;
              const Path v161_2 = concat_path(v159_3_head,v160_2_head);
              const auto v161_3_branches = branches(c,v160_2_tail);
              std::vector<Space> v161_3_outputs;
              v161_3_outputs.reserve(v161_3_branches.size());
              for (const auto& v161_3_branch : v161_3_branches) {
                const Path v161_3_head{v161_3_branch.first};
                const Space& v161_3_tail = v161_3_branch.second;
                const Path v162_2 = concat_path(v161_2,v161_3_head);
                const auto v162_3_branches = branches(c,v161_3_tail);
                std::vector<Space> v162_3_outputs;
                v162_3_outputs.reserve(v162_3_branches.size());
                for (const auto& v162_3_branch : v162_3_branches) {
                  const Path v162_3_head{v162_3_branch.first};
                  const Space& v162_3_tail = v162_3_branch.second;
                  const Path v163_2 = concat_path(v162_2,v162_3_head);
                  const Space v163_3 = routine_19(c, v163_2, p1, p2, p3, p0, v159_2, v162_3_tail);
                  v162_3_outputs.push_back(v163_3);
                }
                const Space v162_3 = join_outputs(std::move(v162_3_outputs));
                v161_3_outputs.push_back(v162_3);
              }
              const Space v161_3 = join_outputs(std::move(v161_3_outputs));
              v160_2_outputs.push_back(v161_3);
            }
            const Space v160_2 = join_outputs(std::move(v160_2_outputs));
            v159_3_outputs.push_back(v160_2);
          }
          const Space v159_3 = join_outputs(std::move(v159_3_outputs));
          v158_3_outputs.push_back(v159_3);
        }
        const Space v158_3 = join_outputs(std::move(v158_3_outputs));
        v157_3_outputs.push_back(v158_3);
      }
      const Space v157_3 = join_outputs(std::move(v157_3_outputs));
      v156_2_outputs.push_back(v157_3);
    }
    const Space v156_2 = join_outputs(std::move(v156_2_outputs));
    v155_5_outputs.push_back(v156_2);
  }
  const Space v155_5 = join_outputs(std::move(v155_5_outputs));
  return v155_5;
}

static Space routine_16(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v164_5_branches = branches(c,s0);
  std::vector<Space> v164_5_outputs;
  v164_5_outputs.reserve(v164_5_branches.size());
  for (const auto& v164_5_branch : v164_5_branches) {
    const Path v164_5_head{v164_5_branch.first};
    const Space& v164_5_tail = v164_5_branch.second;
    const auto v165_2_branches = branches(c,v164_5_tail);
    std::vector<Space> v165_2_outputs;
    v165_2_outputs.reserve(v165_2_branches.size());
    for (const auto& v165_2_branch : v165_2_branches) {
      const Path v165_2_head{v165_2_branch.first};
      const Space& v165_2_tail = v165_2_branch.second;
      const Path v166_2 = concat_path(v164_5_head,v165_2_head);
      const auto v166_3_branches = branches(c,v165_2_tail);
      std::vector<Space> v166_3_outputs;
      v166_3_outputs.reserve(v166_3_branches.size());
      for (const auto& v166_3_branch : v166_3_branches) {
        const Path v166_3_head{v166_3_branch.first};
        const Space& v166_3_tail = v166_3_branch.second;
        const Path v167_2 = concat_path(v166_2,v166_3_head);
        const auto v167_3_branches = branches(c,v166_3_tail);
        std::vector<Space> v167_3_outputs;
        v167_3_outputs.reserve(v167_3_branches.size());
        for (const auto& v167_3_branch : v167_3_branches) {
          const Path v167_3_head{v167_3_branch.first};
          const Space& v167_3_tail = v167_3_branch.second;
          const Path v168_2 = concat_path(v167_2,v167_3_head);
          const auto v168_3_branches = branches(c,v167_3_tail);
          std::vector<Space> v168_3_outputs;
          v168_3_outputs.reserve(v168_3_branches.size());
          for (const auto& v168_3_branch : v168_3_branches) {
            const Path v168_3_head{v168_3_branch.first};
            const Space& v168_3_tail = v168_3_branch.second;
            const auto v169_2_branches = branches(c,v168_3_tail);
            std::vector<Space> v169_2_outputs;
            v169_2_outputs.reserve(v169_2_branches.size());
            for (const auto& v169_2_branch : v169_2_branches) {
              const Path v169_2_head{v169_2_branch.first};
              const Space& v169_2_tail = v169_2_branch.second;
              const Path v170_2 = concat_path(v168_3_head,v169_2_head);
              const auto v170_3_branches = branches(c,v169_2_tail);
              std::vector<Space> v170_3_outputs;
              v170_3_outputs.reserve(v170_3_branches.size());
              for (const auto& v170_3_branch : v170_3_branches) {
                const Path v170_3_head{v170_3_branch.first};
                const Space& v170_3_tail = v170_3_branch.second;
                const Path v171_2 = concat_path(v170_2,v170_3_head);
                const auto v171_3_branches = branches(c,v170_3_tail);
                std::vector<Space> v171_3_outputs;
                v171_3_outputs.reserve(v171_3_branches.size());
                for (const auto& v171_3_branch : v171_3_branches) {
                  const Path v171_3_head{v171_3_branch.first};
                  const Space& v171_3_tail = v171_3_branch.second;
                  const Path v172_2 = concat_path(v171_2,v171_3_head);
                  const Space v172_3 = routine_20(c, v172_2, p1, p2, p3, p0, v168_2, v171_3_tail);
                  v171_3_outputs.push_back(v172_3);
                }
                const Space v171_3 = join_outputs(std::move(v171_3_outputs));
                v170_3_outputs.push_back(v171_3);
              }
              const Space v170_3 = join_outputs(std::move(v170_3_outputs));
              v169_2_outputs.push_back(v170_3);
            }
            const Space v169_2 = join_outputs(std::move(v169_2_outputs));
            v168_3_outputs.push_back(v169_2);
          }
          const Space v168_3 = join_outputs(std::move(v168_3_outputs));
          v167_3_outputs.push_back(v168_3);
        }
        const Space v167_3 = join_outputs(std::move(v167_3_outputs));
        v166_3_outputs.push_back(v167_3);
      }
      const Space v166_3 = join_outputs(std::move(v166_3_outputs));
      v165_2_outputs.push_back(v166_3);
    }
    const Space v165_2 = join_outputs(std::move(v165_2_outputs));
    v164_5_outputs.push_back(v165_2);
  }
  const Space v164_5 = join_outputs(std::move(v164_5_outputs));
  return v164_5;
}

static Space routine_17(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0, const Space& s1) {
  const Space v173_11 = routine_10(c, constant_0, constant_7, p0, constant_12);
  const Space v173_14 = routine_10(c, constant_3, constant_7, p0, constant_12);
  const Space v173_15 = unite(v173_11,v173_14);
  const Space v173_18 = routine_10(c, constant_4, constant_7, p0, constant_12);
  const Space v173_19 = unite(v173_15,v173_18);
  const Space v173_22 = routine_10(c, constant_5, constant_7, p0, constant_12);
  const Space v173_23 = unite(v173_19,v173_22);
  const Space v173_26 = routine_10(c, constant_6, constant_7, p0, constant_12);
  const Space v173_27 = unite(v173_23,v173_26);
  const Space v173_29 = routine_10(c, constant_7, constant_7, p0, constant_12);
  const Space v173_30 = unite(v173_27,v173_29);
  const Space v173_33 = routine_10(c, constant_8, constant_7, p0, constant_12);
  const Space v173_34 = unite(v173_30,v173_33);
  const Space v173_37 = routine_10(c, constant_1, constant_7, p0, constant_12);
  const Space v173_38 = unite(v173_34,v173_37);
  const Space v173_40 = intersect(v173_38,constant_13);
  const Space v173_41 = unite(v173_40,s1);
  const Path v173_42 = concat_path(p1,p2);
  const Path v173_43 = concat_path(v173_42,p3);
  const Path v173_44 = concat_path(v173_43,p4);
  const Path v173_45 = concat_path(v173_44,p5);
  const Space v173_46 = wrap(v173_41,v173_45);
  const Space v173_47 = wrap(v173_46,p0);
  return v173_47;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const Space v174_9 = unwrap(s0,constant_8);
  const Space v174_10 = subtract(constant_9,v174_9);
  const Path v174_12 = concat_path(p1,p2);
  const Path v174_13 = concat_path(v174_12,p3);
  const Path v174_14 = concat_path(v174_13,p4);
  const Path v174_15 = concat_path(v174_14,p5);
  const Path v174_16 = concat_path(v174_15,p0);
  const auto v174_17_branches = branches(c,v174_10);
  std::vector<Space> v174_17_outputs;
  v174_17_outputs.reserve(v174_17_branches.size());
  for (const auto& v174_17_branch : v174_17_branches) {
    const Path v174_17_head{v174_17_branch.first};
    const Space& v174_17_tail = v174_17_branch.second;
    const auto v175_2_branches = branches(c,v174_17_tail);
    std::vector<Space> v175_2_outputs;
    v175_2_outputs.reserve(v175_2_branches.size());
    for (const auto& v175_2_branch : v175_2_branches) {
      const Path v175_2_head{v175_2_branch.first};
      const Space& v175_2_tail = v175_2_branch.second;
      const Path v176_2 = concat_path(v174_17_head,v175_2_head);
      const auto v176_3_branches = branches(c,v175_2_tail);
      std::vector<Space> v176_3_outputs;
      v176_3_outputs.reserve(v176_3_branches.size());
      for (const auto& v176_3_branch : v176_3_branches) {
        const Path v176_3_head{v176_3_branch.first};
        const Space& v176_3_tail = v176_3_branch.second;
        const Path v177_2 = concat_path(v176_2,v176_3_head);
        const auto v177_3_branches = branches(c,v176_3_tail);
        std::vector<Space> v177_3_outputs;
        v177_3_outputs.reserve(v177_3_branches.size());
        for (const auto& v177_3_branch : v177_3_branches) {
          const Path v177_3_head{v177_3_branch.first};
          const Space& v177_3_tail = v177_3_branch.second;
          const Path v178_2 = concat_path(v177_2,v177_3_head);
          const Space v178_3 = routine_1(c, v178_2, constant_8, constant_1);
          const Space v178_4 = unite(s0,v178_3);
          const Space v178_5 = wrap(v178_4,v174_16);
          const Space v178_6 = wrap(v178_5,v178_2);
          v177_3_outputs.push_back(v178_6);
        }
        const Space v177_3 = join_outputs(std::move(v177_3_outputs));
        v176_3_outputs.push_back(v177_3);
      }
      const Space v176_3 = join_outputs(std::move(v176_3_outputs));
      v175_2_outputs.push_back(v176_3);
    }
    const Space v175_2 = join_outputs(std::move(v175_2_outputs));
    v174_17_outputs.push_back(v175_2);
  }
  const Space v174_17 = join_outputs(std::move(v174_17_outputs));
  return v174_17;
}

static Space routine_19(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v179_9_branches = branches(c,s0);
  std::vector<Space> v179_9_outputs;
  v179_9_outputs.reserve(v179_9_branches.size());
  for (const auto& v179_9_branch : v179_9_branches) {
    const Path v179_9_head{v179_9_branch.first};
    const Space& v179_9_tail = v179_9_branch.second;
    const auto v180_2_branches = branches(c,v179_9_tail);
    std::vector<Space> v180_2_outputs;
    v180_2_outputs.reserve(v180_2_branches.size());
    for (const auto& v180_2_branch : v180_2_branches) {
      const Path v180_2_head{v180_2_branch.first};
      const Space& v180_2_tail = v180_2_branch.second;
      const Path v181_2 = concat_path(v179_9_head,v180_2_head);
      const auto v181_3_branches = branches(c,v180_2_tail);
      std::vector<Space> v181_3_outputs;
      v181_3_outputs.reserve(v181_3_branches.size());
      for (const auto& v181_3_branch : v181_3_branches) {
        const Path v181_3_head{v181_3_branch.first};
        const Space& v181_3_tail = v181_3_branch.second;
        const Path v182_2 = concat_path(v181_2,v181_3_head);
        const auto v182_3_branches = branches(c,v181_3_tail);
        std::vector<Space> v182_3_outputs;
        v182_3_outputs.reserve(v182_3_branches.size());
        for (const auto& v182_3_branch : v182_3_branches) {
          const Path v182_3_head{v182_3_branch.first};
          const Space& v182_3_tail = v182_3_branch.second;
          const Space v183_2 = unwrap(v182_3_tail,constant_1);
          const Space v183_3 = subtract(constant_9,v183_2);
          const Path v183_4 = concat_path(v182_2,v182_3_head);
          const auto v183_5_branches = branches(c,v183_3);
          std::vector<Space> v183_5_outputs;
          v183_5_outputs.reserve(v183_5_branches.size());
          for (const auto& v183_5_branch : v183_5_branches) {
            const Path v183_5_head{v183_5_branch.first};
            const Space& v183_5_tail = v183_5_branch.second;
            const auto v184_2_branches = branches(c,v183_5_tail);
            std::vector<Space> v184_2_outputs;
            v184_2_outputs.reserve(v184_2_branches.size());
            for (const auto& v184_2_branch : v184_2_branches) {
              const Path v184_2_head{v184_2_branch.first};
              const Space& v184_2_tail = v184_2_branch.second;
              const Path v185_2 = concat_path(v183_5_head,v184_2_head);
              const auto v185_3_branches = branches(c,v184_2_tail);
              std::vector<Space> v185_3_outputs;
              v185_3_outputs.reserve(v185_3_branches.size());
              for (const auto& v185_3_branch : v185_3_branches) {
                const Path v185_3_head{v185_3_branch.first};
                const Space& v185_3_tail = v185_3_branch.second;
                const Path v186_2 = concat_path(v185_2,v185_3_head);
                const auto v186_3_branches = branches(c,v185_3_tail);
                std::vector<Space> v186_3_outputs;
                v186_3_outputs.reserve(v186_3_branches.size());
                for (const auto& v186_3_branch : v186_3_branches) {
                  const Path v186_3_head{v186_3_branch.first};
                  const Space& v186_3_tail = v186_3_branch.second;
                  const Path v187_2 = concat_path(v186_2,v186_3_head);
                  const Space v187_3 = routine_21(c, v187_2, p1, p2, p3, p4, p5, p0, v183_4, v186_3_tail, v182_3_tail);
                  v186_3_outputs.push_back(v187_3);
                }
                const Space v186_3 = join_outputs(std::move(v186_3_outputs));
                v185_3_outputs.push_back(v186_3);
              }
              const Space v185_3 = join_outputs(std::move(v185_3_outputs));
              v184_2_outputs.push_back(v185_3);
            }
            const Space v184_2 = join_outputs(std::move(v184_2_outputs));
            v183_5_outputs.push_back(v184_2);
          }
          const Space v183_5 = join_outputs(std::move(v183_5_outputs));
          v182_3_outputs.push_back(v183_5);
        }
        const Space v182_3 = join_outputs(std::move(v182_3_outputs));
        v181_3_outputs.push_back(v182_3);
      }
      const Space v181_3 = join_outputs(std::move(v181_3_outputs));
      v180_2_outputs.push_back(v181_3);
    }
    const Space v180_2 = join_outputs(std::move(v180_2_outputs));
    v179_9_outputs.push_back(v180_2);
  }
  const Space v179_9 = join_outputs(std::move(v179_9_outputs));
  return v179_9;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v188_7_branches = branches(c,s0);
  std::vector<Space> v188_7_outputs;
  v188_7_outputs.reserve(v188_7_branches.size());
  for (const auto& v188_7_branch : v188_7_branches) {
    const Path v188_7_head{v188_7_branch.first};
    const Space& v188_7_tail = v188_7_branch.second;
    const auto v189_2_branches = branches(c,v188_7_tail);
    std::vector<Space> v189_2_outputs;
    v189_2_outputs.reserve(v189_2_branches.size());
    for (const auto& v189_2_branch : v189_2_branches) {
      const Path v189_2_head{v189_2_branch.first};
      const Space& v189_2_tail = v189_2_branch.second;
      const Path v190_2 = concat_path(v188_7_head,v189_2_head);
      const auto v190_3_branches = branches(c,v189_2_tail);
      std::vector<Space> v190_3_outputs;
      v190_3_outputs.reserve(v190_3_branches.size());
      for (const auto& v190_3_branch : v190_3_branches) {
        const Path v190_3_head{v190_3_branch.first};
        const Space& v190_3_tail = v190_3_branch.second;
        const Path v191_2 = concat_path(v190_2,v190_3_head);
        const auto v191_3_branches = branches(c,v190_3_tail);
        std::vector<Space> v191_3_outputs;
        v191_3_outputs.reserve(v191_3_branches.size());
        for (const auto& v191_3_branch : v191_3_branches) {
          const Path v191_3_head{v191_3_branch.first};
          const Space& v191_3_tail = v191_3_branch.second;
          const Path v192_2 = concat_path(v191_2,v191_3_head);
          const auto v192_3_branches = branches(c,v191_3_tail);
          std::vector<Space> v192_3_outputs;
          v192_3_outputs.reserve(v192_3_branches.size());
          for (const auto& v192_3_branch : v192_3_branches) {
            const Path v192_3_head{v192_3_branch.first};
            const Space& v192_3_tail = v192_3_branch.second;
            const auto v193_2_branches = branches(c,v192_3_tail);
            std::vector<Space> v193_2_outputs;
            v193_2_outputs.reserve(v193_2_branches.size());
            for (const auto& v193_2_branch : v193_2_branches) {
              const Path v193_2_head{v193_2_branch.first};
              const Space& v193_2_tail = v193_2_branch.second;
              const Path v194_2 = concat_path(v192_3_head,v193_2_head);
              const auto v194_3_branches = branches(c,v193_2_tail);
              std::vector<Space> v194_3_outputs;
              v194_3_outputs.reserve(v194_3_branches.size());
              for (const auto& v194_3_branch : v194_3_branches) {
                const Path v194_3_head{v194_3_branch.first};
                const Space& v194_3_tail = v194_3_branch.second;
                const Path v195_2 = concat_path(v194_2,v194_3_head);
                const auto v195_3_branches = branches(c,v194_3_tail);
                std::vector<Space> v195_3_outputs;
                v195_3_outputs.reserve(v195_3_branches.size());
                for (const auto& v195_3_branch : v195_3_branches) {
                  const Path v195_3_head{v195_3_branch.first};
                  const Space& v195_3_tail = v195_3_branch.second;
                  const Path v196_2 = concat_path(v195_2,v195_3_head);
                  const Space v196_3 = routine_22(c, v196_2, p1, p2, p3, p4, p5, p0, v192_2, v195_3_tail);
                  v195_3_outputs.push_back(v196_3);
                }
                const Space v195_3 = join_outputs(std::move(v195_3_outputs));
                v194_3_outputs.push_back(v195_3);
              }
              const Space v194_3 = join_outputs(std::move(v194_3_outputs));
              v193_2_outputs.push_back(v194_3);
            }
            const Space v193_2 = join_outputs(std::move(v193_2_outputs));
            v192_3_outputs.push_back(v193_2);
          }
          const Space v192_3 = join_outputs(std::move(v192_3_outputs));
          v191_3_outputs.push_back(v192_3);
        }
        const Space v191_3 = join_outputs(std::move(v191_3_outputs));
        v190_3_outputs.push_back(v191_3);
      }
      const Space v190_3 = join_outputs(std::move(v190_3_outputs));
      v189_2_outputs.push_back(v190_3);
    }
    const Space v189_2 = join_outputs(std::move(v189_2_outputs));
    v188_7_outputs.push_back(v189_2);
  }
  const Space v188_7 = join_outputs(std::move(v188_7_outputs));
  return v188_7;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0, const Space& s1) {
  const Space v197_13 = routine_10(c, constant_0, constant_1, p0, constant_12);
  const Space v197_16 = routine_10(c, constant_3, constant_1, p0, constant_12);
  const Space v197_17 = unite(v197_13,v197_16);
  const Space v197_20 = routine_10(c, constant_4, constant_1, p0, constant_12);
  const Space v197_21 = unite(v197_17,v197_20);
  const Space v197_24 = routine_10(c, constant_5, constant_1, p0, constant_12);
  const Space v197_25 = unite(v197_21,v197_24);
  const Space v197_28 = routine_10(c, constant_6, constant_1, p0, constant_12);
  const Space v197_29 = unite(v197_25,v197_28);
  const Space v197_32 = routine_10(c, constant_7, constant_1, p0, constant_12);
  const Space v197_33 = unite(v197_29,v197_32);
  const Space v197_36 = routine_10(c, constant_8, constant_1, p0, constant_12);
  const Space v197_37 = unite(v197_33,v197_36);
  const Space v197_39 = routine_10(c, constant_1, constant_1, p0, constant_12);
  const Space v197_40 = unite(v197_37,v197_39);
  const Space v197_42 = intersect(v197_40,constant_13);
  const Space v197_43 = unite(v197_42,s1);
  const Path v197_44 = concat_path(p1,p2);
  const Path v197_45 = concat_path(v197_44,p3);
  const Path v197_46 = concat_path(v197_45,p4);
  const Path v197_47 = concat_path(v197_46,p5);
  const Path v197_48 = concat_path(v197_47,p6);
  const Path v197_49 = concat_path(v197_48,p7);
  const Space v197_50 = wrap(v197_43,v197_49);
  const Space v197_51 = wrap(v197_50,p0);
  return v197_51;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const Path v198_9 = concat_path(p1,p2);
  const Path v198_10 = concat_path(v198_9,p3);
  const Path v198_11 = concat_path(v198_10,p4);
  const Path v198_12 = concat_path(v198_11,p5);
  const Path v198_13 = concat_path(v198_12,p6);
  const Path v198_14 = concat_path(v198_13,p7);
  const Path v198_15 = concat_path(v198_14,p0);
  const Space v198_16 = singleton(v198_15);
  return v198_16;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
