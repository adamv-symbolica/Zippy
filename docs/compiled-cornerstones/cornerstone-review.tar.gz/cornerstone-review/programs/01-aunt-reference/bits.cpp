#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Space constant_1 = literal_text("1 1 2");
static const Space constant_2 = singleton(Path{});
static const Path constant_3 = Path{1,1,1,1,1,2,2};
static const Path constant_4 = Path{1,1,2,1,2,2};
static const Path constant_5 = Path{1,1,1,1,2,2};
static const Path constant_6 = Path{2,1,1,1,2,2};
static Space routine_0(Context& c, const Space* s0, const Space* s1);
static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_20(Context& c, const Path& p0, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_21(Context& c, const Path& p0, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_29(Context& c, const Path& p0, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_0(Context& c, const Space* s0, const Space* s1) {
  Space v0_5_result;
  for (int v0_5_label = 1; v0_5_label <= 2; ++v0_5_label) {
    const Space v0_5_tail = child(bound_space(s1),v0_5_label);
    if (v0_5_tail.empty()) continue;
    const Path v0_5_head{v0_5_label};
    const Space v1_2 = singleton(v0_5_head);
    const Space v1_3 = intersect(constant_1,v1_2);
    const Space v1_4 = (has_head(v1_3) ? constant_2 : Space{});
    const Space v1_5 = subtract(constant_0,v1_4);
    Space v1_7;
    if (!v1_5.empty()) {
      const Space v2_6 = routine_1(c, v0_5_head, v0_5_tail, bound_space(s0));
      v1_7 = compose(v1_5,v2_6);
    }
    const Space v1_8 = intersect(constant_1,v1_2);
    const Space v1_9 = (has_head(v1_8) ? constant_2 : Space{});
    Space v1_11;
    if (!v1_9.empty()) {
      const Space v3_10 = routine_2(c, v0_5_head, v0_5_tail, bound_space(s0));
      v1_11 = compose(v1_9,v3_10);
    }
    const Space v1_12 = unite(v1_7,v1_11);
    v0_5_result = unite(v0_5_result,v1_12);
  }
  const Space v0_5 = std::move(v0_5_result);
  const Space v0_7 = wrap(v0_5,constant_3);
  return v0_7;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v4_12_result;
  for (int v4_12_label = 1; v4_12_label <= 2; ++v4_12_label) {
    const Space v4_12_tail = child(s0,v4_12_label);
    if (v4_12_tail.empty()) continue;
    const Path v4_12_head{v4_12_label};
    const Space v5_2 = singleton(v4_12_head);
    const Space v5_3 = intersect(constant_1,v5_2);
    const Space v5_4 = (has_head(v5_3) ? constant_2 : Space{});
    const Space v5_5 = subtract(constant_0,v5_4);
    Space v5_8;
    if (!v5_5.empty()) {
      const Path v6_6 = concat_path(p0,v4_12_head);
      Space v6_7_result;
      for (int v6_7_label = 1; v6_7_label <= 2; ++v6_7_label) {
        const Space v6_7_tail = child(v4_12_tail,v6_7_label);
        if (v6_7_tail.empty()) continue;
        const Path v6_7_head{v6_7_label};
        const Space v7_2 = singleton(v6_7_head);
        const Space v7_3 = intersect(constant_1,v7_2);
        const Space v7_4 = (has_head(v7_3) ? constant_2 : Space{});
        const Space v7_5 = subtract(constant_0,v7_4);
        Space v7_8;
        if (!v7_5.empty()) {
          const Path v8_6 = concat_path(v6_6,v6_7_head);
          const Space v8_7 = routine_3(c, v8_6, v6_7_tail, s1);
          v7_8 = compose(v7_5,v8_7);
        }
        const Space v7_9 = intersect(constant_1,v7_2);
        const Space v7_10 = (has_head(v7_9) ? constant_2 : Space{});
        Space v7_12;
        if (!v7_10.empty()) {
          const Path v9_6 = concat_path(v6_6,v6_7_head);
          const Space v9_11 = routine_4(c, v9_6, v6_7_tail, s1);
          v7_12 = compose(v7_10,v9_11);
        }
        const Space v7_13 = unite(v7_8,v7_12);
        v6_7_result = unite(v6_7_result,v7_13);
      }
      const Space v6_7 = std::move(v6_7_result);
      v5_8 = compose(v5_5,v6_7);
    }
    const Space v5_9 = intersect(constant_1,v5_2);
    const Space v5_10 = (has_head(v5_9) ? constant_2 : Space{});
    Space v5_12;
    if (!v5_10.empty()) {
      const Path v10_6 = concat_path(p0,v4_12_head);
      Space v10_11_result;
      for (int v10_11_label = 1; v10_11_label <= 2; ++v10_11_label) {
        const Space v10_11_tail = child(v4_12_tail,v10_11_label);
        if (v10_11_tail.empty()) continue;
        const Path v10_11_head{v10_11_label};
        const Space v11_2 = singleton(v10_11_head);
        const Space v11_3 = intersect(constant_1,v11_2);
        const Space v11_4 = (has_head(v11_3) ? constant_2 : Space{});
        const Space v11_5 = subtract(constant_0,v11_4);
        Space v11_8;
        if (!v11_5.empty()) {
          const Path v12_6 = concat_path(v10_6,v10_11_head);
          const Space v12_7 = routine_3(c, v12_6, v10_11_tail, s1);
          v11_8 = compose(v11_5,v12_7);
        }
        const Space v11_9 = intersect(constant_1,v11_2);
        const Space v11_10 = (has_head(v11_9) ? constant_2 : Space{});
        Space v11_12;
        if (!v11_10.empty()) {
          const Path v13_6 = concat_path(v10_6,v10_11_head);
          const Space v13_11 = routine_5(c, v13_6, v10_11_tail, s1);
          v11_12 = compose(v11_10,v13_11);
        }
        const Space v11_13 = unite(v11_8,v11_12);
        v10_11_result = unite(v10_11_result,v11_13);
      }
      const Space v10_11 = std::move(v10_11_result);
      v5_12 = compose(v5_10,v10_11);
    }
    const Space v5_13 = unite(v5_8,v5_12);
    v4_12_result = unite(v4_12_result,v5_13);
  }
  const Space v4_12 = std::move(v4_12_result);
  return v4_12;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v14_7 = unwrap(s1,constant_4);
  const Space v14_9 = unwrap(s1,constant_5);
  const Space v14_10 = unwrap(v14_9,p0);
  const Space v14_12 = unwrap(s1,constant_6);
  Space v14_22_result;
  for (int v14_22_label = 1; v14_22_label <= 2; ++v14_22_label) {
    const Space v14_22_tail = child(s0,v14_22_label);
    if (v14_22_tail.empty()) continue;
    const Path v14_22_head{v14_22_label};
    const Space v15_2 = singleton(v14_22_head);
    const Space v15_3 = intersect(constant_1,v15_2);
    const Space v15_4 = (has_head(v15_3) ? constant_2 : Space{});
    const Space v15_5 = subtract(constant_0,v15_4);
    Space v15_8;
    if (!v15_5.empty()) {
      const Path v16_6 = concat_path(p0,v14_22_head);
      Space v16_7_result;
      for (int v16_7_label = 1; v16_7_label <= 2; ++v16_7_label) {
        const Space v16_7_tail = child(v14_22_tail,v16_7_label);
        if (v16_7_tail.empty()) continue;
        const Path v16_7_head{v16_7_label};
        const Space v17_2 = singleton(v16_7_head);
        const Space v17_3 = intersect(constant_1,v17_2);
        const Space v17_4 = (has_head(v17_3) ? constant_2 : Space{});
        const Space v17_5 = subtract(constant_0,v17_4);
        Space v17_8;
        if (!v17_5.empty()) {
          const Path v18_6 = concat_path(v16_6,v16_7_head);
          const Space v18_7 = routine_3(c, v18_6, v16_7_tail, s1);
          v17_8 = compose(v17_5,v18_7);
        }
        const Space v17_9 = intersect(constant_1,v17_2);
        const Space v17_10 = (has_head(v17_9) ? constant_2 : Space{});
        Space v17_12;
        if (!v17_10.empty()) {
          const Path v19_6 = concat_path(v16_6,v16_7_head);
          const Space v19_11 = routine_4(c, v19_6, v16_7_tail, s1);
          v17_12 = compose(v17_10,v19_11);
        }
        const Space v17_13 = unite(v17_8,v17_12);
        v16_7_result = unite(v16_7_result,v17_13);
      }
      const Space v16_7 = std::move(v16_7_result);
      v15_8 = compose(v15_5,v16_7);
    }
    const Space v15_9 = intersect(constant_1,v15_2);
    const Space v15_10 = (has_head(v15_9) ? constant_2 : Space{});
    Space v15_18;
    if (!v15_10.empty()) {
      const Space v20_11 = unwrap(v14_10,v14_22_head);
      const Space v20_12 = restrict_to(v14_9,v20_11);
      Space v20_13_result;
      for (int v20_13_label = 1; v20_13_label <= 2; ++v20_13_label) {
        const Space v20_13_tail = child(v20_12,v20_13_label);
        if (v20_13_tail.empty()) continue;
        const Path v20_13_head{v20_13_label};
        const Space v21_2 = singleton(v20_13_head);
        const Space v21_3 = intersect(constant_1,v21_2);
        const Space v21_4 = (has_head(v21_3) ? constant_2 : Space{});
        const Space v21_5 = subtract(constant_0,v21_4);
        Space v21_7;
        if (!v21_5.empty()) {
          const Space v22_6 = routine_6(c, v20_13_head, v20_13_tail);
          v21_7 = compose(v21_5,v22_6);
        }
        const Space v21_8 = intersect(constant_1,v21_2);
        const Space v21_9 = (has_head(v21_8) ? constant_2 : Space{});
        Space v21_11;
        if (!v21_9.empty()) {
          const Space v23_10 = routine_7(c, v20_13_head, v20_13_tail);
          v21_11 = compose(v21_9,v23_10);
        }
        const Space v21_12 = unite(v21_7,v21_11);
        v20_13_result = unite(v20_13_result,v21_12);
      }
      const Space v20_13 = std::move(v20_13_result);
      const Space v20_14 = restrict_to(v14_7,v20_13);
      Space v20_15_result;
      for (int v20_15_label = 1; v20_15_label <= 2; ++v20_15_label) {
        const Space v20_15_tail = child(v20_14,v20_15_label);
        if (v20_15_tail.empty()) continue;
        const Path v20_15_head{v20_15_label};
        const Space v24_2 = singleton(v20_15_head);
        const Space v24_3 = intersect(constant_1,v24_2);
        const Space v24_4 = (has_head(v24_3) ? constant_2 : Space{});
        const Space v24_5 = subtract(constant_0,v24_4);
        Space v24_7;
        if (!v24_5.empty()) {
          const Space v25_6 = routine_8(c, v20_15_head, v20_15_tail);
          v24_7 = compose(v24_5,v25_6);
        }
        const Space v24_8 = intersect(constant_1,v24_2);
        const Space v24_9 = (has_head(v24_8) ? constant_2 : Space{});
        Space v24_11;
        if (!v24_9.empty()) {
          const Space v26_10 = routine_9(c, v20_15_head, v20_15_tail);
          v24_11 = compose(v24_9,v26_10);
        }
        const Space v24_12 = unite(v24_7,v24_11);
        v20_15_result = unite(v20_15_result,v24_12);
      }
      const Space v20_15 = std::move(v20_15_result);
      const Space v20_16 = subtract(v20_15,v20_11);
      const Space v20_17 = intersect(v20_16,v14_12);
      v15_18 = compose(v15_10,v20_17);
    }
    const Path v27_6 = concat_path(p0,v14_22_head);
    const Space v15_19 = wrap(v15_18,v27_6);
    const Space v15_20 = unite(v15_8,v15_19);
    v14_22_result = unite(v14_22_result,v15_20);
  }
  const Space v14_22 = std::move(v14_22_result);
  return v14_22;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v28_12_result;
  for (int v28_12_label = 1; v28_12_label <= 2; ++v28_12_label) {
    const Space v28_12_tail = child(s0,v28_12_label);
    if (v28_12_tail.empty()) continue;
    const Path v28_12_head{v28_12_label};
    const Space v29_2 = singleton(v28_12_head);
    const Space v29_3 = intersect(constant_1,v29_2);
    const Space v29_4 = (has_head(v29_3) ? constant_2 : Space{});
    const Space v29_5 = subtract(constant_0,v29_4);
    Space v29_8;
    if (!v29_5.empty()) {
      const Path v30_6 = concat_path(p0,v28_12_head);
      Space v30_7_result;
      for (int v30_7_label = 1; v30_7_label <= 2; ++v30_7_label) {
        const Space v30_7_tail = child(v28_12_tail,v30_7_label);
        if (v30_7_tail.empty()) continue;
        const Path v30_7_head{v30_7_label};
        const Space v31_2 = singleton(v30_7_head);
        const Space v31_3 = intersect(constant_1,v31_2);
        const Space v31_4 = (has_head(v31_3) ? constant_2 : Space{});
        const Space v31_5 = subtract(constant_0,v31_4);
        Space v31_8;
        if (!v31_5.empty()) {
          const Path v32_6 = concat_path(v30_6,v30_7_head);
          const Space v32_7 = routine_10(c, v32_6, v30_7_tail, s1);
          v31_8 = compose(v31_5,v32_7);
        }
        const Space v31_9 = intersect(constant_1,v31_2);
        const Space v31_10 = (has_head(v31_9) ? constant_2 : Space{});
        Space v31_12;
        if (!v31_10.empty()) {
          const Path v33_6 = concat_path(v30_6,v30_7_head);
          const Space v33_11 = routine_11(c, v33_6, v30_7_tail, s1);
          v31_12 = compose(v31_10,v33_11);
        }
        const Space v31_13 = unite(v31_8,v31_12);
        v30_7_result = unite(v30_7_result,v31_13);
      }
      const Space v30_7 = std::move(v30_7_result);
      v29_8 = compose(v29_5,v30_7);
    }
    const Space v29_9 = intersect(constant_1,v29_2);
    const Space v29_10 = (has_head(v29_9) ? constant_2 : Space{});
    Space v29_12;
    if (!v29_10.empty()) {
      const Path v34_6 = concat_path(p0,v28_12_head);
      Space v34_11_result;
      for (int v34_11_label = 1; v34_11_label <= 2; ++v34_11_label) {
        const Space v34_11_tail = child(v28_12_tail,v34_11_label);
        if (v34_11_tail.empty()) continue;
        const Path v34_11_head{v34_11_label};
        const Space v35_2 = singleton(v34_11_head);
        const Space v35_3 = intersect(constant_1,v35_2);
        const Space v35_4 = (has_head(v35_3) ? constant_2 : Space{});
        const Space v35_5 = subtract(constant_0,v35_4);
        Space v35_8;
        if (!v35_5.empty()) {
          const Path v36_6 = concat_path(v34_6,v34_11_head);
          const Space v36_7 = routine_10(c, v36_6, v34_11_tail, s1);
          v35_8 = compose(v35_5,v36_7);
        }
        const Space v35_9 = intersect(constant_1,v35_2);
        const Space v35_10 = (has_head(v35_9) ? constant_2 : Space{});
        Space v35_12;
        if (!v35_10.empty()) {
          const Path v37_6 = concat_path(v34_6,v34_11_head);
          const Space v37_11 = routine_5(c, v37_6, v34_11_tail, s1);
          v35_12 = compose(v35_10,v37_11);
        }
        const Space v35_13 = unite(v35_8,v35_12);
        v34_11_result = unite(v34_11_result,v35_13);
      }
      const Space v34_11 = std::move(v34_11_result);
      v29_12 = compose(v29_10,v34_11);
    }
    const Space v29_13 = unite(v29_8,v29_12);
    v28_12_result = unite(v28_12_result,v29_13);
  }
  const Space v28_12 = std::move(v28_12_result);
  return v28_12;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v38_7 = unwrap(s1,constant_4);
  const Space v38_9 = unwrap(s1,constant_5);
  const Space v38_10 = unwrap(v38_9,p0);
  const Space v38_12 = unwrap(s1,constant_6);
  Space v38_22_result;
  for (int v38_22_label = 1; v38_22_label <= 2; ++v38_22_label) {
    const Space v38_22_tail = child(s0,v38_22_label);
    if (v38_22_tail.empty()) continue;
    const Path v38_22_head{v38_22_label};
    const Space v39_2 = singleton(v38_22_head);
    const Space v39_3 = intersect(constant_1,v39_2);
    const Space v39_4 = (has_head(v39_3) ? constant_2 : Space{});
    const Space v39_5 = subtract(constant_0,v39_4);
    Space v39_8;
    if (!v39_5.empty()) {
      const Path v40_6 = concat_path(p0,v38_22_head);
      Space v40_7_result;
      for (int v40_7_label = 1; v40_7_label <= 2; ++v40_7_label) {
        const Space v40_7_tail = child(v38_22_tail,v40_7_label);
        if (v40_7_tail.empty()) continue;
        const Path v40_7_head{v40_7_label};
        const Space v41_2 = singleton(v40_7_head);
        const Space v41_3 = intersect(constant_1,v41_2);
        const Space v41_4 = (has_head(v41_3) ? constant_2 : Space{});
        const Space v41_5 = subtract(constant_0,v41_4);
        Space v41_8;
        if (!v41_5.empty()) {
          const Path v42_6 = concat_path(v40_6,v40_7_head);
          const Space v42_7 = routine_10(c, v42_6, v40_7_tail, s1);
          v41_8 = compose(v41_5,v42_7);
        }
        const Space v41_9 = intersect(constant_1,v41_2);
        const Space v41_10 = (has_head(v41_9) ? constant_2 : Space{});
        Space v41_12;
        if (!v41_10.empty()) {
          const Path v43_6 = concat_path(v40_6,v40_7_head);
          const Space v43_11 = routine_11(c, v43_6, v40_7_tail, s1);
          v41_12 = compose(v41_10,v43_11);
        }
        const Space v41_13 = unite(v41_8,v41_12);
        v40_7_result = unite(v40_7_result,v41_13);
      }
      const Space v40_7 = std::move(v40_7_result);
      v39_8 = compose(v39_5,v40_7);
    }
    const Space v39_9 = intersect(constant_1,v39_2);
    const Space v39_10 = (has_head(v39_9) ? constant_2 : Space{});
    Space v39_18;
    if (!v39_10.empty()) {
      const Space v44_11 = unwrap(v38_10,v38_22_head);
      const Space v44_12 = restrict_to(v38_9,v44_11);
      Space v44_13_result;
      for (int v44_13_label = 1; v44_13_label <= 2; ++v44_13_label) {
        const Space v44_13_tail = child(v44_12,v44_13_label);
        if (v44_13_tail.empty()) continue;
        const Path v44_13_head{v44_13_label};
        const Space v45_2 = singleton(v44_13_head);
        const Space v45_3 = intersect(constant_1,v45_2);
        const Space v45_4 = (has_head(v45_3) ? constant_2 : Space{});
        const Space v45_5 = subtract(constant_0,v45_4);
        Space v45_7;
        if (!v45_5.empty()) {
          const Space v46_6 = routine_6(c, v44_13_head, v44_13_tail);
          v45_7 = compose(v45_5,v46_6);
        }
        const Space v45_8 = intersect(constant_1,v45_2);
        const Space v45_9 = (has_head(v45_8) ? constant_2 : Space{});
        Space v45_11;
        if (!v45_9.empty()) {
          const Space v47_10 = routine_7(c, v44_13_head, v44_13_tail);
          v45_11 = compose(v45_9,v47_10);
        }
        const Space v45_12 = unite(v45_7,v45_11);
        v44_13_result = unite(v44_13_result,v45_12);
      }
      const Space v44_13 = std::move(v44_13_result);
      const Space v44_14 = restrict_to(v38_7,v44_13);
      Space v44_15_result;
      for (int v44_15_label = 1; v44_15_label <= 2; ++v44_15_label) {
        const Space v44_15_tail = child(v44_14,v44_15_label);
        if (v44_15_tail.empty()) continue;
        const Path v44_15_head{v44_15_label};
        const Space v48_2 = singleton(v44_15_head);
        const Space v48_3 = intersect(constant_1,v48_2);
        const Space v48_4 = (has_head(v48_3) ? constant_2 : Space{});
        const Space v48_5 = subtract(constant_0,v48_4);
        Space v48_7;
        if (!v48_5.empty()) {
          const Space v49_6 = routine_8(c, v44_15_head, v44_15_tail);
          v48_7 = compose(v48_5,v49_6);
        }
        const Space v48_8 = intersect(constant_1,v48_2);
        const Space v48_9 = (has_head(v48_8) ? constant_2 : Space{});
        Space v48_11;
        if (!v48_9.empty()) {
          const Space v50_10 = routine_9(c, v44_15_head, v44_15_tail);
          v48_11 = compose(v48_9,v50_10);
        }
        const Space v48_12 = unite(v48_7,v48_11);
        v44_15_result = unite(v44_15_result,v48_12);
      }
      const Space v44_15 = std::move(v44_15_result);
      const Space v44_16 = subtract(v44_15,v44_11);
      const Space v44_17 = intersect(v44_16,v38_12);
      v39_18 = compose(v39_10,v44_17);
    }
    const Path v51_6 = concat_path(p0,v38_22_head);
    const Space v39_19 = wrap(v39_18,v51_6);
    const Space v39_20 = unite(v39_8,v39_19);
    v38_22_result = unite(v38_22_result,v39_20);
  }
  const Space v38_22 = std::move(v38_22_result);
  return v38_22;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v52_4 = unwrap(s1,constant_4);
  const Space v52_6 = unwrap(s1,constant_5);
  const Space v52_7 = unwrap(v52_6,p0);
  const Space v52_8 = restrict_to(v52_6,v52_7);
  Space v52_18_result;
  for (int v52_18_label = 1; v52_18_label <= 2; ++v52_18_label) {
    const Space v52_18_tail = child(v52_8,v52_18_label);
    if (v52_18_tail.empty()) continue;
    const Path v52_18_head{v52_18_label};
    const Space v53_2 = singleton(v52_18_head);
    const Space v53_3 = intersect(constant_1,v53_2);
    const Space v53_4 = (has_head(v53_3) ? constant_2 : Space{});
    const Space v53_5 = subtract(constant_0,v53_4);
    Space v53_7;
    if (!v53_5.empty()) {
      Space v54_6_result;
      for (int v54_6_label = 1; v54_6_label <= 2; ++v54_6_label) {
        const Space v54_6_tail = child(v52_18_tail,v54_6_label);
        if (v54_6_tail.empty()) continue;
        const Path v54_6_head{v54_6_label};
        const Space v55_2 = singleton(v54_6_head);
        const Space v55_3 = intersect(constant_1,v55_2);
        const Space v55_4 = (has_head(v55_3) ? constant_2 : Space{});
        const Space v55_5 = subtract(constant_0,v55_4);
        Space v55_8;
        if (!v55_5.empty()) {
          const Path v56_6 = concat_path(v52_18_head,v54_6_head);
          const Space v56_7 = routine_12(c, v56_6, v54_6_tail);
          v55_8 = compose(v55_5,v56_7);
        }
        const Space v55_9 = intersect(constant_1,v55_2);
        const Space v55_10 = (has_head(v55_9) ? constant_2 : Space{});
        Space v55_12;
        if (!v55_10.empty()) {
          const Path v57_6 = concat_path(v52_18_head,v54_6_head);
          const Space v57_11 = routine_13(c, v57_6, v54_6_tail);
          v55_12 = compose(v55_10,v57_11);
        }
        const Space v55_13 = unite(v55_8,v55_12);
        v54_6_result = unite(v54_6_result,v55_13);
      }
      const Space v54_6 = std::move(v54_6_result);
      v53_7 = compose(v53_5,v54_6);
    }
    const Space v53_8 = intersect(constant_1,v53_2);
    const Space v53_9 = (has_head(v53_8) ? constant_2 : Space{});
    Space v53_11;
    if (!v53_9.empty()) {
      Space v58_10_result;
      for (int v58_10_label = 1; v58_10_label <= 2; ++v58_10_label) {
        const Space v58_10_tail = child(v52_18_tail,v58_10_label);
        if (v58_10_tail.empty()) continue;
        const Path v58_10_head{v58_10_label};
        const Space v59_2 = singleton(v58_10_head);
        const Space v59_3 = intersect(constant_1,v59_2);
        const Space v59_4 = (has_head(v59_3) ? constant_2 : Space{});
        const Space v59_5 = subtract(constant_0,v59_4);
        Space v59_8;
        if (!v59_5.empty()) {
          const Path v60_6 = concat_path(v52_18_head,v58_10_head);
          const Space v60_7 = routine_12(c, v60_6, v58_10_tail);
          v59_8 = compose(v59_5,v60_7);
        }
        const Space v59_9 = intersect(constant_1,v59_2);
        const Space v59_10 = (has_head(v59_9) ? constant_2 : Space{});
        Space v59_12;
        if (!v59_10.empty()) {
          const Path v61_6 = concat_path(v52_18_head,v58_10_head);
          const Space v61_11 = routine_14(c, v61_6, v58_10_tail);
          v59_12 = compose(v59_10,v61_11);
        }
        const Space v59_13 = unite(v59_8,v59_12);
        v58_10_result = unite(v58_10_result,v59_13);
      }
      const Space v58_10 = std::move(v58_10_result);
      v53_11 = compose(v53_9,v58_10);
    }
    const Space v53_12 = unite(v53_7,v53_11);
    v52_18_result = unite(v52_18_result,v53_12);
  }
  const Space v52_18 = std::move(v52_18_result);
  const Space v52_19 = restrict_to(v52_4,v52_18);
  Space v52_29_result;
  for (int v52_29_label = 1; v52_29_label <= 2; ++v52_29_label) {
    const Space v52_29_tail = child(v52_19,v52_29_label);
    if (v52_29_tail.empty()) continue;
    const Path v52_29_head{v52_29_label};
    const Space v62_2 = singleton(v52_29_head);
    const Space v62_3 = intersect(constant_1,v62_2);
    const Space v62_4 = (has_head(v62_3) ? constant_2 : Space{});
    const Space v62_5 = subtract(constant_0,v62_4);
    Space v62_7;
    if (!v62_5.empty()) {
      Space v63_6_result;
      for (int v63_6_label = 1; v63_6_label <= 2; ++v63_6_label) {
        const Space v63_6_tail = child(v52_29_tail,v63_6_label);
        if (v63_6_tail.empty()) continue;
        const Path v63_6_head{v63_6_label};
        const Space v64_2 = singleton(v63_6_head);
        const Space v64_3 = intersect(constant_1,v64_2);
        const Space v64_4 = (has_head(v64_3) ? constant_2 : Space{});
        const Space v64_5 = subtract(constant_0,v64_4);
        Space v64_8;
        if (!v64_5.empty()) {
          const Path v65_6 = concat_path(v52_29_head,v63_6_head);
          const Space v65_7 = routine_15(c, v65_6, v63_6_tail);
          v64_8 = compose(v64_5,v65_7);
        }
        const Space v64_9 = intersect(constant_1,v64_2);
        const Space v64_10 = (has_head(v64_9) ? constant_2 : Space{});
        Space v64_12;
        if (!v64_10.empty()) {
          const Path v66_6 = concat_path(v52_29_head,v63_6_head);
          const Space v66_11 = routine_16(c, v66_6, v63_6_tail);
          v64_12 = compose(v64_10,v66_11);
        }
        const Space v64_13 = unite(v64_8,v64_12);
        v63_6_result = unite(v63_6_result,v64_13);
      }
      const Space v63_6 = std::move(v63_6_result);
      v62_7 = compose(v62_5,v63_6);
    }
    const Space v62_8 = intersect(constant_1,v62_2);
    const Space v62_9 = (has_head(v62_8) ? constant_2 : Space{});
    Space v62_11;
    if (!v62_9.empty()) {
      Space v67_10_result;
      for (int v67_10_label = 1; v67_10_label <= 2; ++v67_10_label) {
        const Space v67_10_tail = child(v52_29_tail,v67_10_label);
        if (v67_10_tail.empty()) continue;
        const Path v67_10_head{v67_10_label};
        const Space v68_2 = singleton(v67_10_head);
        const Space v68_3 = intersect(constant_1,v68_2);
        const Space v68_4 = (has_head(v68_3) ? constant_2 : Space{});
        const Space v68_5 = subtract(constant_0,v68_4);
        Space v68_8;
        if (!v68_5.empty()) {
          const Path v69_6 = concat_path(v52_29_head,v67_10_head);
          const Space v69_7 = routine_15(c, v69_6, v67_10_tail);
          v68_8 = compose(v68_5,v69_7);
        }
        const Space v68_9 = intersect(constant_1,v68_2);
        const Space v68_10 = (has_head(v68_9) ? constant_2 : Space{});
        Space v68_12;
        if (!v68_10.empty()) {
          const Path v70_6 = concat_path(v52_29_head,v67_10_head);
          const Space v70_11 = routine_17(c, v70_6, v67_10_tail);
          v68_12 = compose(v68_10,v70_11);
        }
        const Space v68_13 = unite(v68_8,v68_12);
        v67_10_result = unite(v67_10_result,v68_13);
      }
      const Space v67_10 = std::move(v67_10_result);
      v62_11 = compose(v62_9,v67_10);
    }
    const Space v62_12 = unite(v62_7,v62_11);
    v52_29_result = unite(v52_29_result,v62_12);
  }
  const Space v52_29 = std::move(v52_29_result);
  const Space v52_30 = subtract(v52_29,v52_7);
  const Space v52_32 = unwrap(s1,constant_6);
  const Space v52_33 = intersect(v52_30,v52_32);
  const Space v52_34 = wrap(v52_33,p0);
  return v52_34;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  Space v71_11_result;
  for (int v71_11_label = 1; v71_11_label <= 2; ++v71_11_label) {
    const Space v71_11_tail = child(s0,v71_11_label);
    if (v71_11_tail.empty()) continue;
    const Path v71_11_head{v71_11_label};
    const Space v72_2 = singleton(v71_11_head);
    const Space v72_3 = intersect(constant_1,v72_2);
    const Space v72_4 = (has_head(v72_3) ? constant_2 : Space{});
    const Space v72_5 = subtract(constant_0,v72_4);
    Space v72_8;
    if (!v72_5.empty()) {
      const Path v73_6 = concat_path(p0,v71_11_head);
      Space v73_7_result;
      for (int v73_7_label = 1; v73_7_label <= 2; ++v73_7_label) {
        const Space v73_7_tail = child(v71_11_tail,v73_7_label);
        if (v73_7_tail.empty()) continue;
        const Path v73_7_head{v73_7_label};
        const Space v74_2 = singleton(v73_7_head);
        const Space v74_3 = intersect(constant_1,v74_2);
        const Space v74_4 = (has_head(v74_3) ? constant_2 : Space{});
        const Space v74_5 = subtract(constant_0,v74_4);
        Space v74_8;
        if (!v74_5.empty()) {
          const Path v75_6 = concat_path(v73_6,v73_7_head);
          const Space v75_7 = routine_18(c, v75_6, v73_7_tail);
          v74_8 = compose(v74_5,v75_7);
        }
        const Space v74_9 = intersect(constant_1,v74_2);
        const Space v74_10 = (has_head(v74_9) ? constant_2 : Space{});
        Space v74_12;
        if (!v74_10.empty()) {
          const Path v76_6 = concat_path(v73_6,v73_7_head);
          const Space v76_11 = routine_19(c, v76_6, v73_7_tail);
          v74_12 = compose(v74_10,v76_11);
        }
        const Space v74_13 = unite(v74_8,v74_12);
        v73_7_result = unite(v73_7_result,v74_13);
      }
      const Space v73_7 = std::move(v73_7_result);
      v72_8 = compose(v72_5,v73_7);
    }
    const Space v72_9 = intersect(constant_1,v72_2);
    const Space v72_10 = (has_head(v72_9) ? constant_2 : Space{});
    Space v72_12;
    if (!v72_10.empty()) {
      const Path v77_6 = concat_path(p0,v71_11_head);
      Space v77_11_result;
      for (int v77_11_label = 1; v77_11_label <= 2; ++v77_11_label) {
        const Space v77_11_tail = child(v71_11_tail,v77_11_label);
        if (v77_11_tail.empty()) continue;
        const Path v77_11_head{v77_11_label};
        const Space v78_2 = singleton(v77_11_head);
        const Space v78_3 = intersect(constant_1,v78_2);
        const Space v78_4 = (has_head(v78_3) ? constant_2 : Space{});
        const Space v78_5 = subtract(constant_0,v78_4);
        Space v78_8;
        if (!v78_5.empty()) {
          const Path v79_6 = concat_path(v77_6,v77_11_head);
          const Space v79_7 = routine_18(c, v79_6, v77_11_tail);
          v78_8 = compose(v78_5,v79_7);
        }
        const Space v78_9 = intersect(constant_1,v78_2);
        const Space v78_10 = (has_head(v78_9) ? constant_2 : Space{});
        Space v78_12;
        if (!v78_10.empty()) {
          const Path v80_6 = concat_path(v77_6,v77_11_head);
          const Space v80_11 = routine_14(c, v80_6, v77_11_tail);
          v78_12 = compose(v78_10,v80_11);
        }
        const Space v78_13 = unite(v78_8,v78_12);
        v77_11_result = unite(v77_11_result,v78_13);
      }
      const Space v77_11 = std::move(v77_11_result);
      v72_12 = compose(v72_10,v77_11);
    }
    const Space v72_13 = unite(v72_8,v72_12);
    v71_11_result = unite(v71_11_result,v72_13);
  }
  const Space v71_11 = std::move(v71_11_result);
  return v71_11;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v81_8_result;
  for (int v81_8_label = 1; v81_8_label <= 2; ++v81_8_label) {
    const Space v81_8_tail = child(s0,v81_8_label);
    if (v81_8_tail.empty()) continue;
    const Path v81_8_head{v81_8_label};
    const Space v82_2 = singleton(v81_8_head);
    const Space v82_3 = intersect(constant_1,v82_2);
    const Space v82_4 = (has_head(v82_3) ? constant_2 : Space{});
    const Space v82_5 = subtract(constant_0,v82_4);
    Space v82_8;
    if (!v82_5.empty()) {
      const Path v83_6 = concat_path(p0,v81_8_head);
      Space v83_7_result;
      for (int v83_7_label = 1; v83_7_label <= 2; ++v83_7_label) {
        const Space v83_7_tail = child(v81_8_tail,v83_7_label);
        if (v83_7_tail.empty()) continue;
        const Path v83_7_head{v83_7_label};
        const Space v84_2 = singleton(v83_7_head);
        const Space v84_3 = intersect(constant_1,v84_2);
        const Space v84_4 = (has_head(v84_3) ? constant_2 : Space{});
        const Space v84_5 = subtract(constant_0,v84_4);
        Space v84_8;
        if (!v84_5.empty()) {
          const Path v85_6 = concat_path(v83_6,v83_7_head);
          const Space v85_7 = routine_18(c, v85_6, v83_7_tail);
          v84_8 = compose(v84_5,v85_7);
        }
        const Space v84_9 = intersect(constant_1,v84_2);
        const Space v84_10 = (has_head(v84_9) ? constant_2 : Space{});
        Space v84_12;
        if (!v84_10.empty()) {
          const Path v86_6 = concat_path(v83_6,v83_7_head);
          const Space v86_11 = routine_19(c, v86_6, v83_7_tail);
          v84_12 = compose(v84_10,v86_11);
        }
        const Space v84_13 = unite(v84_8,v84_12);
        v83_7_result = unite(v83_7_result,v84_13);
      }
      const Space v83_7 = std::move(v83_7_result);
      v82_8 = compose(v82_5,v83_7);
    }
    const Space v82_9 = intersect(constant_1,v82_2);
    const Space v82_10 = (has_head(v82_9) ? constant_2 : Space{});
    const Space v82_11 = compose(v82_10,v81_8_tail);
    const Space v82_12 = unite(v82_8,v82_11);
    v81_8_result = unite(v81_8_result,v82_12);
  }
  const Space v81_8 = std::move(v81_8_result);
  return v81_8;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v87_11_result;
  for (int v87_11_label = 1; v87_11_label <= 2; ++v87_11_label) {
    const Space v87_11_tail = child(s0,v87_11_label);
    if (v87_11_tail.empty()) continue;
    const Path v87_11_head{v87_11_label};
    const Space v88_2 = singleton(v87_11_head);
    const Space v88_3 = intersect(constant_1,v88_2);
    const Space v88_4 = (has_head(v88_3) ? constant_2 : Space{});
    const Space v88_5 = subtract(constant_0,v88_4);
    Space v88_8;
    if (!v88_5.empty()) {
      const Path v89_6 = concat_path(p0,v87_11_head);
      Space v89_7_result;
      for (int v89_7_label = 1; v89_7_label <= 2; ++v89_7_label) {
        const Space v89_7_tail = child(v87_11_tail,v89_7_label);
        if (v89_7_tail.empty()) continue;
        const Path v89_7_head{v89_7_label};
        const Space v90_2 = singleton(v89_7_head);
        const Space v90_3 = intersect(constant_1,v90_2);
        const Space v90_4 = (has_head(v90_3) ? constant_2 : Space{});
        const Space v90_5 = subtract(constant_0,v90_4);
        Space v90_8;
        if (!v90_5.empty()) {
          const Path v91_6 = concat_path(v89_6,v89_7_head);
          const Space v91_7 = routine_20(c, v91_6, v89_7_tail);
          v90_8 = compose(v90_5,v91_7);
        }
        const Space v90_9 = intersect(constant_1,v90_2);
        const Space v90_10 = (has_head(v90_9) ? constant_2 : Space{});
        Space v90_12;
        if (!v90_10.empty()) {
          const Path v92_6 = concat_path(v89_6,v89_7_head);
          const Space v92_11 = routine_21(c, v92_6, v89_7_tail);
          v90_12 = compose(v90_10,v92_11);
        }
        const Space v90_13 = unite(v90_8,v90_12);
        v89_7_result = unite(v89_7_result,v90_13);
      }
      const Space v89_7 = std::move(v89_7_result);
      v88_8 = compose(v88_5,v89_7);
    }
    const Space v88_9 = intersect(constant_1,v88_2);
    const Space v88_10 = (has_head(v88_9) ? constant_2 : Space{});
    Space v88_12;
    if (!v88_10.empty()) {
      const Path v93_6 = concat_path(p0,v87_11_head);
      Space v93_11_result;
      for (int v93_11_label = 1; v93_11_label <= 2; ++v93_11_label) {
        const Space v93_11_tail = child(v87_11_tail,v93_11_label);
        if (v93_11_tail.empty()) continue;
        const Path v93_11_head{v93_11_label};
        const Space v94_2 = singleton(v93_11_head);
        const Space v94_3 = intersect(constant_1,v94_2);
        const Space v94_4 = (has_head(v94_3) ? constant_2 : Space{});
        const Space v94_5 = subtract(constant_0,v94_4);
        Space v94_8;
        if (!v94_5.empty()) {
          const Path v95_6 = concat_path(v93_6,v93_11_head);
          const Space v95_7 = routine_20(c, v95_6, v93_11_tail);
          v94_8 = compose(v94_5,v95_7);
        }
        const Space v94_9 = intersect(constant_1,v94_2);
        const Space v94_10 = (has_head(v94_9) ? constant_2 : Space{});
        Space v94_12;
        if (!v94_10.empty()) {
          const Path v96_6 = concat_path(v93_6,v93_11_head);
          const Space v96_11 = routine_17(c, v96_6, v93_11_tail);
          v94_12 = compose(v94_10,v96_11);
        }
        const Space v94_13 = unite(v94_8,v94_12);
        v93_11_result = unite(v93_11_result,v94_13);
      }
      const Space v93_11 = std::move(v93_11_result);
      v88_12 = compose(v88_10,v93_11);
    }
    const Space v88_13 = unite(v88_8,v88_12);
    v87_11_result = unite(v87_11_result,v88_13);
  }
  const Space v87_11 = std::move(v87_11_result);
  return v87_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  Space v97_8_result;
  for (int v97_8_label = 1; v97_8_label <= 2; ++v97_8_label) {
    const Space v97_8_tail = child(s0,v97_8_label);
    if (v97_8_tail.empty()) continue;
    const Path v97_8_head{v97_8_label};
    const Space v98_2 = singleton(v97_8_head);
    const Space v98_3 = intersect(constant_1,v98_2);
    const Space v98_4 = (has_head(v98_3) ? constant_2 : Space{});
    const Space v98_5 = subtract(constant_0,v98_4);
    Space v98_8;
    if (!v98_5.empty()) {
      const Path v99_6 = concat_path(p0,v97_8_head);
      Space v99_7_result;
      for (int v99_7_label = 1; v99_7_label <= 2; ++v99_7_label) {
        const Space v99_7_tail = child(v97_8_tail,v99_7_label);
        if (v99_7_tail.empty()) continue;
        const Path v99_7_head{v99_7_label};
        const Space v100_2 = singleton(v99_7_head);
        const Space v100_3 = intersect(constant_1,v100_2);
        const Space v100_4 = (has_head(v100_3) ? constant_2 : Space{});
        const Space v100_5 = subtract(constant_0,v100_4);
        Space v100_8;
        if (!v100_5.empty()) {
          const Path v101_6 = concat_path(v99_6,v99_7_head);
          const Space v101_7 = routine_20(c, v101_6, v99_7_tail);
          v100_8 = compose(v100_5,v101_7);
        }
        const Space v100_9 = intersect(constant_1,v100_2);
        const Space v100_10 = (has_head(v100_9) ? constant_2 : Space{});
        Space v100_12;
        if (!v100_10.empty()) {
          const Path v102_6 = concat_path(v99_6,v99_7_head);
          const Space v102_11 = routine_21(c, v102_6, v99_7_tail);
          v100_12 = compose(v100_10,v102_11);
        }
        const Space v100_13 = unite(v100_8,v100_12);
        v99_7_result = unite(v99_7_result,v100_13);
      }
      const Space v99_7 = std::move(v99_7_result);
      v98_8 = compose(v98_5,v99_7);
    }
    const Space v98_9 = intersect(constant_1,v98_2);
    const Space v98_10 = (has_head(v98_9) ? constant_2 : Space{});
    const Space v98_11 = compose(v98_10,v97_8_tail);
    const Space v98_12 = unite(v98_8,v98_11);
    v97_8_result = unite(v97_8_result,v98_12);
  }
  const Space v97_8 = std::move(v97_8_result);
  return v97_8;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v103_7_result;
  for (int v103_7_label = 1; v103_7_label <= 2; ++v103_7_label) {
    const Space v103_7_tail = child(s0,v103_7_label);
    if (v103_7_tail.empty()) continue;
    const Path v103_7_head{v103_7_label};
    const Space v104_2 = singleton(v103_7_head);
    const Space v104_3 = intersect(constant_1,v104_2);
    const Space v104_4 = (has_head(v104_3) ? constant_2 : Space{});
    const Space v104_5 = subtract(constant_0,v104_4);
    Space v104_6_result;
    for (int v104_6_label = 1; v104_6_label <= 2; ++v104_6_label) {
      const Space v104_6_tail = child(v103_7_tail,v104_6_label);
      if (v104_6_tail.empty()) continue;
      const Path v104_6_head{v104_6_label};
      const Space v105_2 = Space{};
      v104_6_result = unite(v104_6_result,v105_2);
    }
    const Space v104_6 = std::move(v104_6_result);
    const Space v104_7 = compose(v104_5,v104_6);
    const Space v104_8 = intersect(constant_1,v104_2);
    const Space v104_9 = (has_head(v104_8) ? constant_2 : Space{});
    Space v104_12;
    if (!v104_9.empty()) {
      const Path v106_10 = concat_path(p0,v103_7_head);
      Space v106_11_result;
      for (int v106_11_label = 1; v106_11_label <= 2; ++v106_11_label) {
        const Space v106_11_tail = child(v103_7_tail,v106_11_label);
        if (v106_11_tail.empty()) continue;
        const Path v106_11_head{v106_11_label};
        const Space v107_2 = singleton(v106_11_head);
        const Space v107_3 = intersect(constant_1,v107_2);
        const Space v107_4 = (has_head(v107_3) ? constant_2 : Space{});
        Space v107_7;
        if (!v107_4.empty()) {
          const Path v108_5 = concat_path(v106_10,v106_11_head);
          const Space v108_6 = routine_5(c, v108_5, v106_11_tail, s1);
          v107_7 = compose(v107_4,v108_6);
        }
        v106_11_result = unite(v106_11_result,v107_7);
      }
      const Space v106_11 = std::move(v106_11_result);
      v104_12 = compose(v104_9,v106_11);
    }
    const Space v104_13 = unite(v104_7,v104_12);
    v103_7_result = unite(v103_7_result,v104_13);
  }
  const Space v103_7 = std::move(v103_7_result);
  return v103_7;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v109_7 = unwrap(s1,constant_4);
  const Space v109_9 = unwrap(s1,constant_5);
  const Space v109_10 = unwrap(v109_9,p0);
  const Space v109_12 = unwrap(s1,constant_6);
  Space v109_19_result;
  for (int v109_19_label = 1; v109_19_label <= 2; ++v109_19_label) {
    const Space v109_19_tail = child(s0,v109_19_label);
    if (v109_19_tail.empty()) continue;
    const Path v109_19_head{v109_19_label};
    const Space v110_2 = singleton(v109_19_head);
    const Space v110_3 = intersect(constant_1,v110_2);
    const Space v110_4 = (has_head(v110_3) ? constant_2 : Space{});
    const Space v110_5 = subtract(constant_0,v110_4);
    Space v110_6_result;
    for (int v110_6_label = 1; v110_6_label <= 2; ++v110_6_label) {
      const Space v110_6_tail = child(v109_19_tail,v110_6_label);
      if (v110_6_tail.empty()) continue;
      const Path v110_6_head{v110_6_label};
      const Space v111_2 = Space{};
      v110_6_result = unite(v110_6_result,v111_2);
    }
    const Space v110_6 = std::move(v110_6_result);
    const Space v110_7 = compose(v110_5,v110_6);
    const Space v110_8 = intersect(constant_1,v110_2);
    const Space v110_9 = (has_head(v110_8) ? constant_2 : Space{});
    Space v110_17;
    if (!v110_9.empty()) {
      const Space v112_10 = unwrap(v109_10,v109_19_head);
      const Space v112_11 = restrict_to(v109_9,v112_10);
      Space v112_12_result;
      for (int v112_12_label = 1; v112_12_label <= 2; ++v112_12_label) {
        const Space v112_12_tail = child(v112_11,v112_12_label);
        if (v112_12_tail.empty()) continue;
        const Path v112_12_head{v112_12_label};
        const Space v113_2 = singleton(v112_12_head);
        const Space v113_3 = intersect(constant_1,v113_2);
        const Space v113_4 = (has_head(v113_3) ? constant_2 : Space{});
        const Space v113_5 = subtract(constant_0,v113_4);
        Space v113_7;
        if (!v113_5.empty()) {
          const Space v114_6 = routine_6(c, v112_12_head, v112_12_tail);
          v113_7 = compose(v113_5,v114_6);
        }
        const Space v113_8 = intersect(constant_1,v113_2);
        const Space v113_9 = (has_head(v113_8) ? constant_2 : Space{});
        Space v113_11;
        if (!v113_9.empty()) {
          const Space v115_10 = routine_7(c, v112_12_head, v112_12_tail);
          v113_11 = compose(v113_9,v115_10);
        }
        const Space v113_12 = unite(v113_7,v113_11);
        v112_12_result = unite(v112_12_result,v113_12);
      }
      const Space v112_12 = std::move(v112_12_result);
      const Space v112_13 = restrict_to(v109_7,v112_12);
      Space v112_14_result;
      for (int v112_14_label = 1; v112_14_label <= 2; ++v112_14_label) {
        const Space v112_14_tail = child(v112_13,v112_14_label);
        if (v112_14_tail.empty()) continue;
        const Path v112_14_head{v112_14_label};
        const Space v116_2 = singleton(v112_14_head);
        const Space v116_3 = intersect(constant_1,v116_2);
        const Space v116_4 = (has_head(v116_3) ? constant_2 : Space{});
        const Space v116_5 = subtract(constant_0,v116_4);
        Space v116_7;
        if (!v116_5.empty()) {
          const Space v117_6 = routine_8(c, v112_14_head, v112_14_tail);
          v116_7 = compose(v116_5,v117_6);
        }
        const Space v116_8 = intersect(constant_1,v116_2);
        const Space v116_9 = (has_head(v116_8) ? constant_2 : Space{});
        Space v116_11;
        if (!v116_9.empty()) {
          const Space v118_10 = routine_9(c, v112_14_head, v112_14_tail);
          v116_11 = compose(v116_9,v118_10);
        }
        const Space v116_12 = unite(v116_7,v116_11);
        v112_14_result = unite(v112_14_result,v116_12);
      }
      const Space v112_14 = std::move(v112_14_result);
      const Space v112_15 = subtract(v112_14,v112_10);
      const Space v112_16 = intersect(v112_15,v109_12);
      v110_17 = compose(v110_9,v112_16);
    }
    const Path v110_18 = concat_path(p0,v109_19_head);
    const Space v110_19 = wrap(v110_17,v110_18);
    const Space v110_20 = unite(v110_7,v110_19);
    v109_19_result = unite(v109_19_result,v110_20);
  }
  const Space v109_19 = std::move(v109_19_result);
  return v109_19;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  Space v119_11_result;
  for (int v119_11_label = 1; v119_11_label <= 2; ++v119_11_label) {
    const Space v119_11_tail = child(s0,v119_11_label);
    if (v119_11_tail.empty()) continue;
    const Path v119_11_head{v119_11_label};
    const Space v120_2 = singleton(v119_11_head);
    const Space v120_3 = intersect(constant_1,v120_2);
    const Space v120_4 = (has_head(v120_3) ? constant_2 : Space{});
    const Space v120_5 = subtract(constant_0,v120_4);
    Space v120_8;
    if (!v120_5.empty()) {
      const Path v121_6 = concat_path(p0,v119_11_head);
      Space v121_7_result;
      for (int v121_7_label = 1; v121_7_label <= 2; ++v121_7_label) {
        const Space v121_7_tail = child(v119_11_tail,v121_7_label);
        if (v121_7_tail.empty()) continue;
        const Path v121_7_head{v121_7_label};
        const Space v122_2 = singleton(v121_7_head);
        const Space v122_3 = intersect(constant_1,v122_2);
        const Space v122_4 = (has_head(v122_3) ? constant_2 : Space{});
        const Space v122_5 = subtract(constant_0,v122_4);
        Space v122_8;
        if (!v122_5.empty()) {
          const Path v123_6 = concat_path(v121_6,v121_7_head);
          const Space v123_7 = routine_22(c, v123_6, v121_7_tail);
          v122_8 = compose(v122_5,v123_7);
        }
        const Space v122_9 = intersect(constant_1,v122_2);
        const Space v122_10 = (has_head(v122_9) ? constant_2 : Space{});
        Space v122_12;
        if (!v122_10.empty()) {
          const Path v124_6 = concat_path(v121_6,v121_7_head);
          const Space v124_11 = routine_23(c, v124_6, v121_7_tail);
          v122_12 = compose(v122_10,v124_11);
        }
        const Space v122_13 = unite(v122_8,v122_12);
        v121_7_result = unite(v121_7_result,v122_13);
      }
      const Space v121_7 = std::move(v121_7_result);
      v120_8 = compose(v120_5,v121_7);
    }
    const Space v120_9 = intersect(constant_1,v120_2);
    const Space v120_10 = (has_head(v120_9) ? constant_2 : Space{});
    Space v120_12;
    if (!v120_10.empty()) {
      const Path v125_6 = concat_path(p0,v119_11_head);
      Space v125_11_result;
      for (int v125_11_label = 1; v125_11_label <= 2; ++v125_11_label) {
        const Space v125_11_tail = child(v119_11_tail,v125_11_label);
        if (v125_11_tail.empty()) continue;
        const Path v125_11_head{v125_11_label};
        const Space v126_2 = singleton(v125_11_head);
        const Space v126_3 = intersect(constant_1,v126_2);
        const Space v126_4 = (has_head(v126_3) ? constant_2 : Space{});
        const Space v126_5 = subtract(constant_0,v126_4);
        Space v126_8;
        if (!v126_5.empty()) {
          const Path v127_6 = concat_path(v125_6,v125_11_head);
          const Space v127_7 = routine_22(c, v127_6, v125_11_tail);
          v126_8 = compose(v126_5,v127_7);
        }
        const Space v126_9 = intersect(constant_1,v126_2);
        const Space v126_10 = (has_head(v126_9) ? constant_2 : Space{});
        Space v126_12;
        if (!v126_10.empty()) {
          const Path v128_6 = concat_path(v125_6,v125_11_head);
          const Space v128_11 = routine_14(c, v128_6, v125_11_tail);
          v126_12 = compose(v126_10,v128_11);
        }
        const Space v126_13 = unite(v126_8,v126_12);
        v125_11_result = unite(v125_11_result,v126_13);
      }
      const Space v125_11 = std::move(v125_11_result);
      v120_12 = compose(v120_10,v125_11);
    }
    const Space v120_13 = unite(v120_8,v120_12);
    v119_11_result = unite(v119_11_result,v120_13);
  }
  const Space v119_11 = std::move(v119_11_result);
  return v119_11;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v129_8_result;
  for (int v129_8_label = 1; v129_8_label <= 2; ++v129_8_label) {
    const Space v129_8_tail = child(s0,v129_8_label);
    if (v129_8_tail.empty()) continue;
    const Path v129_8_head{v129_8_label};
    const Space v130_2 = singleton(v129_8_head);
    const Space v130_3 = intersect(constant_1,v130_2);
    const Space v130_4 = (has_head(v130_3) ? constant_2 : Space{});
    const Space v130_5 = subtract(constant_0,v130_4);
    Space v130_8;
    if (!v130_5.empty()) {
      const Path v131_6 = concat_path(p0,v129_8_head);
      Space v131_7_result;
      for (int v131_7_label = 1; v131_7_label <= 2; ++v131_7_label) {
        const Space v131_7_tail = child(v129_8_tail,v131_7_label);
        if (v131_7_tail.empty()) continue;
        const Path v131_7_head{v131_7_label};
        const Space v132_2 = singleton(v131_7_head);
        const Space v132_3 = intersect(constant_1,v132_2);
        const Space v132_4 = (has_head(v132_3) ? constant_2 : Space{});
        const Space v132_5 = subtract(constant_0,v132_4);
        Space v132_8;
        if (!v132_5.empty()) {
          const Path v133_6 = concat_path(v131_6,v131_7_head);
          const Space v133_7 = routine_22(c, v133_6, v131_7_tail);
          v132_8 = compose(v132_5,v133_7);
        }
        const Space v132_9 = intersect(constant_1,v132_2);
        const Space v132_10 = (has_head(v132_9) ? constant_2 : Space{});
        Space v132_12;
        if (!v132_10.empty()) {
          const Path v134_6 = concat_path(v131_6,v131_7_head);
          const Space v134_11 = routine_23(c, v134_6, v131_7_tail);
          v132_12 = compose(v132_10,v134_11);
        }
        const Space v132_13 = unite(v132_8,v132_12);
        v131_7_result = unite(v131_7_result,v132_13);
      }
      const Space v131_7 = std::move(v131_7_result);
      v130_8 = compose(v130_5,v131_7);
    }
    const Space v130_9 = intersect(constant_1,v130_2);
    const Space v130_10 = (has_head(v130_9) ? constant_2 : Space{});
    const Space v130_11 = compose(v130_10,v129_8_tail);
    const Space v130_12 = unite(v130_8,v130_11);
    v129_8_result = unite(v129_8_result,v130_12);
  }
  const Space v129_8 = std::move(v129_8_result);
  return v129_8;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0) {
  Space v136_11_result;
  for (int v136_11_label = 1; v136_11_label <= 2; ++v136_11_label) {
    const Space v136_11_tail = child(s0,v136_11_label);
    if (v136_11_tail.empty()) continue;
    const Path v136_11_head{v136_11_label};
    const Space v137_2 = singleton(v136_11_head);
    const Space v137_3 = intersect(constant_1,v137_2);
    const Space v137_4 = (has_head(v137_3) ? constant_2 : Space{});
    const Space v137_5 = subtract(constant_0,v137_4);
    Space v137_8;
    if (!v137_5.empty()) {
      const Path v138_6 = concat_path(p0,v136_11_head);
      Space v138_7_result;
      for (int v138_7_label = 1; v138_7_label <= 2; ++v138_7_label) {
        const Space v138_7_tail = child(v136_11_tail,v138_7_label);
        if (v138_7_tail.empty()) continue;
        const Path v138_7_head{v138_7_label};
        const Space v139_2 = singleton(v138_7_head);
        const Space v139_3 = intersect(constant_1,v139_2);
        const Space v139_4 = (has_head(v139_3) ? constant_2 : Space{});
        const Space v139_5 = subtract(constant_0,v139_4);
        Space v139_8;
        if (!v139_5.empty()) {
          const Path v140_6 = concat_path(v138_6,v138_7_head);
          const Space v140_7 = routine_24(c, v140_6, v138_7_tail);
          v139_8 = compose(v139_5,v140_7);
        }
        const Space v139_9 = intersect(constant_1,v139_2);
        const Space v139_10 = (has_head(v139_9) ? constant_2 : Space{});
        Space v139_12;
        if (!v139_10.empty()) {
          const Path v141_6 = concat_path(v138_6,v138_7_head);
          const Space v141_11 = routine_25(c, v141_6, v138_7_tail);
          v139_12 = compose(v139_10,v141_11);
        }
        const Space v139_13 = unite(v139_8,v139_12);
        v138_7_result = unite(v138_7_result,v139_13);
      }
      const Space v138_7 = std::move(v138_7_result);
      v137_8 = compose(v137_5,v138_7);
    }
    const Space v137_9 = intersect(constant_1,v137_2);
    const Space v137_10 = (has_head(v137_9) ? constant_2 : Space{});
    Space v137_12;
    if (!v137_10.empty()) {
      const Path v142_6 = concat_path(p0,v136_11_head);
      Space v142_11_result;
      for (int v142_11_label = 1; v142_11_label <= 2; ++v142_11_label) {
        const Space v142_11_tail = child(v136_11_tail,v142_11_label);
        if (v142_11_tail.empty()) continue;
        const Path v142_11_head{v142_11_label};
        const Space v143_2 = singleton(v142_11_head);
        const Space v143_3 = intersect(constant_1,v143_2);
        const Space v143_4 = (has_head(v143_3) ? constant_2 : Space{});
        const Space v143_5 = subtract(constant_0,v143_4);
        Space v143_8;
        if (!v143_5.empty()) {
          const Path v144_6 = concat_path(v142_6,v142_11_head);
          const Space v144_7 = routine_24(c, v144_6, v142_11_tail);
          v143_8 = compose(v143_5,v144_7);
        }
        const Space v143_9 = intersect(constant_1,v143_2);
        const Space v143_10 = (has_head(v143_9) ? constant_2 : Space{});
        Space v143_12;
        if (!v143_10.empty()) {
          const Path v145_6 = concat_path(v142_6,v142_11_head);
          const Space v145_11 = routine_17(c, v145_6, v142_11_tail);
          v143_12 = compose(v143_10,v145_11);
        }
        const Space v143_13 = unite(v143_8,v143_12);
        v142_11_result = unite(v142_11_result,v143_13);
      }
      const Space v142_11 = std::move(v142_11_result);
      v137_12 = compose(v137_10,v142_11);
    }
    const Space v137_13 = unite(v137_8,v137_12);
    v136_11_result = unite(v136_11_result,v137_13);
  }
  const Space v136_11 = std::move(v136_11_result);
  return v136_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v146_8_result;
  for (int v146_8_label = 1; v146_8_label <= 2; ++v146_8_label) {
    const Space v146_8_tail = child(s0,v146_8_label);
    if (v146_8_tail.empty()) continue;
    const Path v146_8_head{v146_8_label};
    const Space v147_2 = singleton(v146_8_head);
    const Space v147_3 = intersect(constant_1,v147_2);
    const Space v147_4 = (has_head(v147_3) ? constant_2 : Space{});
    const Space v147_5 = subtract(constant_0,v147_4);
    Space v147_8;
    if (!v147_5.empty()) {
      const Path v148_6 = concat_path(p0,v146_8_head);
      Space v148_7_result;
      for (int v148_7_label = 1; v148_7_label <= 2; ++v148_7_label) {
        const Space v148_7_tail = child(v146_8_tail,v148_7_label);
        if (v148_7_tail.empty()) continue;
        const Path v148_7_head{v148_7_label};
        const Space v149_2 = singleton(v148_7_head);
        const Space v149_3 = intersect(constant_1,v149_2);
        const Space v149_4 = (has_head(v149_3) ? constant_2 : Space{});
        const Space v149_5 = subtract(constant_0,v149_4);
        Space v149_8;
        if (!v149_5.empty()) {
          const Path v150_6 = concat_path(v148_6,v148_7_head);
          const Space v150_7 = routine_24(c, v150_6, v148_7_tail);
          v149_8 = compose(v149_5,v150_7);
        }
        const Space v149_9 = intersect(constant_1,v149_2);
        const Space v149_10 = (has_head(v149_9) ? constant_2 : Space{});
        Space v149_12;
        if (!v149_10.empty()) {
          const Path v151_6 = concat_path(v148_6,v148_7_head);
          const Space v151_11 = routine_25(c, v151_6, v148_7_tail);
          v149_12 = compose(v149_10,v151_11);
        }
        const Space v149_13 = unite(v149_8,v149_12);
        v148_7_result = unite(v148_7_result,v149_13);
      }
      const Space v148_7 = std::move(v148_7_result);
      v147_8 = compose(v147_5,v148_7);
    }
    const Space v147_9 = intersect(constant_1,v147_2);
    const Space v147_10 = (has_head(v147_9) ? constant_2 : Space{});
    const Space v147_11 = compose(v147_10,v146_8_tail);
    const Space v147_12 = unite(v147_8,v147_11);
    v146_8_result = unite(v146_8_result,v147_12);
  }
  const Space v146_8 = std::move(v146_8_result);
  return v146_8;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0) {
  Space v153_11_result;
  for (int v153_11_label = 1; v153_11_label <= 2; ++v153_11_label) {
    const Space v153_11_tail = child(s0,v153_11_label);
    if (v153_11_tail.empty()) continue;
    const Path v153_11_head{v153_11_label};
    const Space v154_2 = singleton(v153_11_head);
    const Space v154_3 = intersect(constant_1,v154_2);
    const Space v154_4 = (has_head(v154_3) ? constant_2 : Space{});
    const Space v154_5 = subtract(constant_0,v154_4);
    Space v154_8;
    if (!v154_5.empty()) {
      const Path v155_6 = concat_path(p0,v153_11_head);
      Space v155_7_result;
      for (int v155_7_label = 1; v155_7_label <= 2; ++v155_7_label) {
        const Space v155_7_tail = child(v153_11_tail,v155_7_label);
        if (v155_7_tail.empty()) continue;
        const Path v155_7_head{v155_7_label};
        const Space v156_2 = singleton(v155_7_head);
        const Space v156_3 = intersect(constant_1,v156_2);
        const Space v156_4 = (has_head(v156_3) ? constant_2 : Space{});
        const Space v156_5 = subtract(constant_0,v156_4);
        Space v156_8;
        if (!v156_5.empty()) {
          const Path v157_6 = concat_path(v155_6,v155_7_head);
          const Space v157_7 = routine_26(c, v157_6, v155_7_tail);
          v156_8 = compose(v156_5,v157_7);
        }
        const Space v156_9 = intersect(constant_1,v156_2);
        const Space v156_10 = (has_head(v156_9) ? constant_2 : Space{});
        Space v156_12;
        if (!v156_10.empty()) {
          const Path v158_6 = concat_path(v155_6,v155_7_head);
          const Space v158_11 = routine_27(c, v158_6, v155_7_tail);
          v156_12 = compose(v156_10,v158_11);
        }
        const Space v156_13 = unite(v156_8,v156_12);
        v155_7_result = unite(v155_7_result,v156_13);
      }
      const Space v155_7 = std::move(v155_7_result);
      v154_8 = compose(v154_5,v155_7);
    }
    const Space v154_9 = intersect(constant_1,v154_2);
    const Space v154_10 = (has_head(v154_9) ? constant_2 : Space{});
    Space v154_12;
    if (!v154_10.empty()) {
      const Path v159_6 = concat_path(p0,v153_11_head);
      Space v159_11_result;
      for (int v159_11_label = 1; v159_11_label <= 2; ++v159_11_label) {
        const Space v159_11_tail = child(v153_11_tail,v159_11_label);
        if (v159_11_tail.empty()) continue;
        const Path v159_11_head{v159_11_label};
        const Space v160_2 = singleton(v159_11_head);
        const Space v160_3 = intersect(constant_1,v160_2);
        const Space v160_4 = (has_head(v160_3) ? constant_2 : Space{});
        const Space v160_5 = subtract(constant_0,v160_4);
        Space v160_8;
        if (!v160_5.empty()) {
          const Path v161_6 = concat_path(v159_6,v159_11_head);
          const Space v161_7 = routine_26(c, v161_6, v159_11_tail);
          v160_8 = compose(v160_5,v161_7);
        }
        const Space v160_9 = intersect(constant_1,v160_2);
        const Space v160_10 = (has_head(v160_9) ? constant_2 : Space{});
        Space v160_12;
        if (!v160_10.empty()) {
          const Path v162_6 = concat_path(v159_6,v159_11_head);
          const Space v162_11 = routine_14(c, v162_6, v159_11_tail);
          v160_12 = compose(v160_10,v162_11);
        }
        const Space v160_13 = unite(v160_8,v160_12);
        v159_11_result = unite(v159_11_result,v160_13);
      }
      const Space v159_11 = std::move(v159_11_result);
      v154_12 = compose(v154_10,v159_11);
    }
    const Space v154_13 = unite(v154_8,v154_12);
    v153_11_result = unite(v153_11_result,v154_13);
  }
  const Space v153_11 = std::move(v153_11_result);
  return v153_11;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  Space v163_8_result;
  for (int v163_8_label = 1; v163_8_label <= 2; ++v163_8_label) {
    const Space v163_8_tail = child(s0,v163_8_label);
    if (v163_8_tail.empty()) continue;
    const Path v163_8_head{v163_8_label};
    const Space v164_2 = singleton(v163_8_head);
    const Space v164_3 = intersect(constant_1,v164_2);
    const Space v164_4 = (has_head(v164_3) ? constant_2 : Space{});
    const Space v164_5 = subtract(constant_0,v164_4);
    Space v164_8;
    if (!v164_5.empty()) {
      const Path v165_6 = concat_path(p0,v163_8_head);
      Space v165_7_result;
      for (int v165_7_label = 1; v165_7_label <= 2; ++v165_7_label) {
        const Space v165_7_tail = child(v163_8_tail,v165_7_label);
        if (v165_7_tail.empty()) continue;
        const Path v165_7_head{v165_7_label};
        const Space v166_2 = singleton(v165_7_head);
        const Space v166_3 = intersect(constant_1,v166_2);
        const Space v166_4 = (has_head(v166_3) ? constant_2 : Space{});
        const Space v166_5 = subtract(constant_0,v166_4);
        Space v166_8;
        if (!v166_5.empty()) {
          const Path v167_6 = concat_path(v165_6,v165_7_head);
          const Space v167_7 = routine_26(c, v167_6, v165_7_tail);
          v166_8 = compose(v166_5,v167_7);
        }
        const Space v166_9 = intersect(constant_1,v166_2);
        const Space v166_10 = (has_head(v166_9) ? constant_2 : Space{});
        Space v166_12;
        if (!v166_10.empty()) {
          const Path v168_6 = concat_path(v165_6,v165_7_head);
          const Space v168_11 = routine_27(c, v168_6, v165_7_tail);
          v166_12 = compose(v166_10,v168_11);
        }
        const Space v166_13 = unite(v166_8,v166_12);
        v165_7_result = unite(v165_7_result,v166_13);
      }
      const Space v165_7 = std::move(v165_7_result);
      v164_8 = compose(v164_5,v165_7);
    }
    const Space v164_9 = intersect(constant_1,v164_2);
    const Space v164_10 = (has_head(v164_9) ? constant_2 : Space{});
    const Space v164_11 = compose(v164_10,v163_8_tail);
    const Space v164_12 = unite(v164_8,v164_11);
    v163_8_result = unite(v163_8_result,v164_12);
  }
  const Space v163_8 = std::move(v163_8_result);
  return v163_8;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0) {
  Space v169_11_result;
  for (int v169_11_label = 1; v169_11_label <= 2; ++v169_11_label) {
    const Space v169_11_tail = child(s0,v169_11_label);
    if (v169_11_tail.empty()) continue;
    const Path v169_11_head{v169_11_label};
    const Space v170_2 = singleton(v169_11_head);
    const Space v170_3 = intersect(constant_1,v170_2);
    const Space v170_4 = (has_head(v170_3) ? constant_2 : Space{});
    const Space v170_5 = subtract(constant_0,v170_4);
    Space v170_8;
    if (!v170_5.empty()) {
      const Path v171_6 = concat_path(p0,v169_11_head);
      Space v171_7_result;
      for (int v171_7_label = 1; v171_7_label <= 2; ++v171_7_label) {
        const Space v171_7_tail = child(v169_11_tail,v171_7_label);
        if (v171_7_tail.empty()) continue;
        const Path v171_7_head{v171_7_label};
        const Space v172_2 = singleton(v171_7_head);
        const Space v172_3 = intersect(constant_1,v172_2);
        const Space v172_4 = (has_head(v172_3) ? constant_2 : Space{});
        const Space v172_5 = subtract(constant_0,v172_4);
        Space v172_8;
        if (!v172_5.empty()) {
          const Path v173_6 = concat_path(v171_6,v171_7_head);
          const Space v173_7 = routine_28(c, v173_6, v171_7_tail);
          v172_8 = compose(v172_5,v173_7);
        }
        const Space v172_9 = intersect(constant_1,v172_2);
        const Space v172_10 = (has_head(v172_9) ? constant_2 : Space{});
        Space v172_12;
        if (!v172_10.empty()) {
          const Path v174_6 = concat_path(v171_6,v171_7_head);
          const Space v174_11 = routine_29(c, v174_6, v171_7_tail);
          v172_12 = compose(v172_10,v174_11);
        }
        const Space v172_13 = unite(v172_8,v172_12);
        v171_7_result = unite(v171_7_result,v172_13);
      }
      const Space v171_7 = std::move(v171_7_result);
      v170_8 = compose(v170_5,v171_7);
    }
    const Space v170_9 = intersect(constant_1,v170_2);
    const Space v170_10 = (has_head(v170_9) ? constant_2 : Space{});
    Space v170_12;
    if (!v170_10.empty()) {
      const Path v175_6 = concat_path(p0,v169_11_head);
      Space v175_11_result;
      for (int v175_11_label = 1; v175_11_label <= 2; ++v175_11_label) {
        const Space v175_11_tail = child(v169_11_tail,v175_11_label);
        if (v175_11_tail.empty()) continue;
        const Path v175_11_head{v175_11_label};
        const Space v176_2 = singleton(v175_11_head);
        const Space v176_3 = intersect(constant_1,v176_2);
        const Space v176_4 = (has_head(v176_3) ? constant_2 : Space{});
        const Space v176_5 = subtract(constant_0,v176_4);
        Space v176_8;
        if (!v176_5.empty()) {
          const Path v177_6 = concat_path(v175_6,v175_11_head);
          const Space v177_7 = routine_28(c, v177_6, v175_11_tail);
          v176_8 = compose(v176_5,v177_7);
        }
        const Space v176_9 = intersect(constant_1,v176_2);
        const Space v176_10 = (has_head(v176_9) ? constant_2 : Space{});
        Space v176_12;
        if (!v176_10.empty()) {
          const Path v178_6 = concat_path(v175_6,v175_11_head);
          const Space v178_11 = routine_17(c, v178_6, v175_11_tail);
          v176_12 = compose(v176_10,v178_11);
        }
        const Space v176_13 = unite(v176_8,v176_12);
        v175_11_result = unite(v175_11_result,v176_13);
      }
      const Space v175_11 = std::move(v175_11_result);
      v170_12 = compose(v170_10,v175_11);
    }
    const Space v170_13 = unite(v170_8,v170_12);
    v169_11_result = unite(v169_11_result,v170_13);
  }
  const Space v169_11 = std::move(v169_11_result);
  return v169_11;
}

static Space routine_21(Context& c, const Path& p0, const Space& s0) {
  Space v179_8_result;
  for (int v179_8_label = 1; v179_8_label <= 2; ++v179_8_label) {
    const Space v179_8_tail = child(s0,v179_8_label);
    if (v179_8_tail.empty()) continue;
    const Path v179_8_head{v179_8_label};
    const Space v180_2 = singleton(v179_8_head);
    const Space v180_3 = intersect(constant_1,v180_2);
    const Space v180_4 = (has_head(v180_3) ? constant_2 : Space{});
    const Space v180_5 = subtract(constant_0,v180_4);
    Space v180_8;
    if (!v180_5.empty()) {
      const Path v181_6 = concat_path(p0,v179_8_head);
      Space v181_7_result;
      for (int v181_7_label = 1; v181_7_label <= 2; ++v181_7_label) {
        const Space v181_7_tail = child(v179_8_tail,v181_7_label);
        if (v181_7_tail.empty()) continue;
        const Path v181_7_head{v181_7_label};
        const Space v182_2 = singleton(v181_7_head);
        const Space v182_3 = intersect(constant_1,v182_2);
        const Space v182_4 = (has_head(v182_3) ? constant_2 : Space{});
        const Space v182_5 = subtract(constant_0,v182_4);
        Space v182_8;
        if (!v182_5.empty()) {
          const Path v183_6 = concat_path(v181_6,v181_7_head);
          const Space v183_7 = routine_28(c, v183_6, v181_7_tail);
          v182_8 = compose(v182_5,v183_7);
        }
        const Space v182_9 = intersect(constant_1,v182_2);
        const Space v182_10 = (has_head(v182_9) ? constant_2 : Space{});
        Space v182_12;
        if (!v182_10.empty()) {
          const Path v184_6 = concat_path(v181_6,v181_7_head);
          const Space v184_11 = routine_29(c, v184_6, v181_7_tail);
          v182_12 = compose(v182_10,v184_11);
        }
        const Space v182_13 = unite(v182_8,v182_12);
        v181_7_result = unite(v181_7_result,v182_13);
      }
      const Space v181_7 = std::move(v181_7_result);
      v180_8 = compose(v180_5,v181_7);
    }
    const Space v180_9 = intersect(constant_1,v180_2);
    const Space v180_10 = (has_head(v180_9) ? constant_2 : Space{});
    const Space v180_11 = compose(v180_10,v179_8_tail);
    const Space v180_12 = unite(v180_8,v180_11);
    v179_8_result = unite(v179_8_result,v180_12);
  }
  const Space v179_8 = std::move(v179_8_result);
  return v179_8;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0) {
  Space v185_11_result;
  for (int v185_11_label = 1; v185_11_label <= 2; ++v185_11_label) {
    const Space v185_11_tail = child(s0,v185_11_label);
    if (v185_11_tail.empty()) continue;
    const Path v185_11_head{v185_11_label};
    const Space v186_2 = singleton(v185_11_head);
    const Space v186_3 = intersect(constant_1,v186_2);
    const Space v186_4 = (has_head(v186_3) ? constant_2 : Space{});
    const Space v186_5 = subtract(constant_0,v186_4);
    Space v186_8;
    if (!v186_5.empty()) {
      const Path v187_6 = concat_path(p0,v185_11_head);
      Space v187_7_result;
      for (int v187_7_label = 1; v187_7_label <= 2; ++v187_7_label) {
        const Space v187_7_tail = child(v185_11_tail,v187_7_label);
        if (v187_7_tail.empty()) continue;
        const Path v187_7_head{v187_7_label};
        const Space v188_2 = singleton(v187_7_head);
        const Space v188_3 = intersect(constant_1,v188_2);
        const Space v188_4 = (has_head(v188_3) ? constant_2 : Space{});
        const Space v188_5 = subtract(constant_0,v188_4);
        Space v188_8;
        if (!v188_5.empty()) {
          const Path v189_6 = concat_path(v187_6,v187_7_head);
          const Space v189_7 = routine_30(c, v189_6, v187_7_tail);
          v188_8 = compose(v188_5,v189_7);
        }
        const Space v188_9 = intersect(constant_1,v188_2);
        const Space v188_10 = (has_head(v188_9) ? constant_2 : Space{});
        Space v188_12;
        if (!v188_10.empty()) {
          const Path v190_6 = concat_path(v187_6,v187_7_head);
          const Space v190_11 = routine_31(c, v190_6, v187_7_tail);
          v188_12 = compose(v188_10,v190_11);
        }
        const Space v188_13 = unite(v188_8,v188_12);
        v187_7_result = unite(v187_7_result,v188_13);
      }
      const Space v187_7 = std::move(v187_7_result);
      v186_8 = compose(v186_5,v187_7);
    }
    const Space v186_9 = intersect(constant_1,v186_2);
    const Space v186_10 = (has_head(v186_9) ? constant_2 : Space{});
    Space v186_12;
    if (!v186_10.empty()) {
      const Path v191_6 = concat_path(p0,v185_11_head);
      Space v191_11_result;
      for (int v191_11_label = 1; v191_11_label <= 2; ++v191_11_label) {
        const Space v191_11_tail = child(v185_11_tail,v191_11_label);
        if (v191_11_tail.empty()) continue;
        const Path v191_11_head{v191_11_label};
        const Space v192_2 = singleton(v191_11_head);
        const Space v192_3 = intersect(constant_1,v192_2);
        const Space v192_4 = (has_head(v192_3) ? constant_2 : Space{});
        const Space v192_5 = subtract(constant_0,v192_4);
        Space v192_8;
        if (!v192_5.empty()) {
          const Path v193_6 = concat_path(v191_6,v191_11_head);
          const Space v193_7 = routine_30(c, v193_6, v191_11_tail);
          v192_8 = compose(v192_5,v193_7);
        }
        const Space v192_9 = intersect(constant_1,v192_2);
        const Space v192_10 = (has_head(v192_9) ? constant_2 : Space{});
        Space v192_12;
        if (!v192_10.empty()) {
          const Path v194_6 = concat_path(v191_6,v191_11_head);
          const Space v194_11 = routine_14(c, v194_6, v191_11_tail);
          v192_12 = compose(v192_10,v194_11);
        }
        const Space v192_13 = unite(v192_8,v192_12);
        v191_11_result = unite(v191_11_result,v192_13);
      }
      const Space v191_11 = std::move(v191_11_result);
      v186_12 = compose(v186_10,v191_11);
    }
    const Space v186_13 = unite(v186_8,v186_12);
    v185_11_result = unite(v185_11_result,v186_13);
  }
  const Space v185_11 = std::move(v185_11_result);
  return v185_11;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0) {
  Space v195_8_result;
  for (int v195_8_label = 1; v195_8_label <= 2; ++v195_8_label) {
    const Space v195_8_tail = child(s0,v195_8_label);
    if (v195_8_tail.empty()) continue;
    const Path v195_8_head{v195_8_label};
    const Space v196_2 = singleton(v195_8_head);
    const Space v196_3 = intersect(constant_1,v196_2);
    const Space v196_4 = (has_head(v196_3) ? constant_2 : Space{});
    const Space v196_5 = subtract(constant_0,v196_4);
    Space v196_8;
    if (!v196_5.empty()) {
      const Path v197_6 = concat_path(p0,v195_8_head);
      Space v197_7_result;
      for (int v197_7_label = 1; v197_7_label <= 2; ++v197_7_label) {
        const Space v197_7_tail = child(v195_8_tail,v197_7_label);
        if (v197_7_tail.empty()) continue;
        const Path v197_7_head{v197_7_label};
        const Space v198_2 = singleton(v197_7_head);
        const Space v198_3 = intersect(constant_1,v198_2);
        const Space v198_4 = (has_head(v198_3) ? constant_2 : Space{});
        const Space v198_5 = subtract(constant_0,v198_4);
        Space v198_8;
        if (!v198_5.empty()) {
          const Path v199_6 = concat_path(v197_6,v197_7_head);
          const Space v199_7 = routine_30(c, v199_6, v197_7_tail);
          v198_8 = compose(v198_5,v199_7);
        }
        const Space v198_9 = intersect(constant_1,v198_2);
        const Space v198_10 = (has_head(v198_9) ? constant_2 : Space{});
        Space v198_12;
        if (!v198_10.empty()) {
          const Path v200_6 = concat_path(v197_6,v197_7_head);
          const Space v200_11 = routine_31(c, v200_6, v197_7_tail);
          v198_12 = compose(v198_10,v200_11);
        }
        const Space v198_13 = unite(v198_8,v198_12);
        v197_7_result = unite(v197_7_result,v198_13);
      }
      const Space v197_7 = std::move(v197_7_result);
      v196_8 = compose(v196_5,v197_7);
    }
    const Space v196_9 = intersect(constant_1,v196_2);
    const Space v196_10 = (has_head(v196_9) ? constant_2 : Space{});
    const Space v196_11 = compose(v196_10,v195_8_tail);
    const Space v196_12 = unite(v196_8,v196_11);
    v195_8_result = unite(v195_8_result,v196_12);
  }
  const Space v195_8 = std::move(v195_8_result);
  return v195_8;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0) {
  Space v201_11_result;
  for (int v201_11_label = 1; v201_11_label <= 2; ++v201_11_label) {
    const Space v201_11_tail = child(s0,v201_11_label);
    if (v201_11_tail.empty()) continue;
    const Path v201_11_head{v201_11_label};
    const Space v202_2 = singleton(v201_11_head);
    const Space v202_3 = intersect(constant_1,v202_2);
    const Space v202_4 = (has_head(v202_3) ? constant_2 : Space{});
    const Space v202_5 = subtract(constant_0,v202_4);
    Space v202_8;
    if (!v202_5.empty()) {
      const Path v203_6 = concat_path(p0,v201_11_head);
      Space v203_7_result;
      for (int v203_7_label = 1; v203_7_label <= 2; ++v203_7_label) {
        const Space v203_7_tail = child(v201_11_tail,v203_7_label);
        if (v203_7_tail.empty()) continue;
        const Path v203_7_head{v203_7_label};
        const Space v204_2 = singleton(v203_7_head);
        const Space v204_3 = intersect(constant_1,v204_2);
        const Space v204_4 = (has_head(v204_3) ? constant_2 : Space{});
        const Space v204_5 = subtract(constant_0,v204_4);
        Space v204_8;
        if (!v204_5.empty()) {
          const Path v205_6 = concat_path(v203_6,v203_7_head);
          const Space v205_7 = routine_32(c, v205_6, v203_7_tail);
          v204_8 = compose(v204_5,v205_7);
        }
        const Space v204_9 = intersect(constant_1,v204_2);
        const Space v204_10 = (has_head(v204_9) ? constant_2 : Space{});
        Space v204_12;
        if (!v204_10.empty()) {
          const Path v206_6 = concat_path(v203_6,v203_7_head);
          const Space v206_11 = routine_33(c, v206_6, v203_7_tail);
          v204_12 = compose(v204_10,v206_11);
        }
        const Space v204_13 = unite(v204_8,v204_12);
        v203_7_result = unite(v203_7_result,v204_13);
      }
      const Space v203_7 = std::move(v203_7_result);
      v202_8 = compose(v202_5,v203_7);
    }
    const Space v202_9 = intersect(constant_1,v202_2);
    const Space v202_10 = (has_head(v202_9) ? constant_2 : Space{});
    Space v202_12;
    if (!v202_10.empty()) {
      const Path v207_6 = concat_path(p0,v201_11_head);
      Space v207_11_result;
      for (int v207_11_label = 1; v207_11_label <= 2; ++v207_11_label) {
        const Space v207_11_tail = child(v201_11_tail,v207_11_label);
        if (v207_11_tail.empty()) continue;
        const Path v207_11_head{v207_11_label};
        const Space v208_2 = singleton(v207_11_head);
        const Space v208_3 = intersect(constant_1,v208_2);
        const Space v208_4 = (has_head(v208_3) ? constant_2 : Space{});
        const Space v208_5 = subtract(constant_0,v208_4);
        Space v208_8;
        if (!v208_5.empty()) {
          const Path v209_6 = concat_path(v207_6,v207_11_head);
          const Space v209_7 = routine_32(c, v209_6, v207_11_tail);
          v208_8 = compose(v208_5,v209_7);
        }
        const Space v208_9 = intersect(constant_1,v208_2);
        const Space v208_10 = (has_head(v208_9) ? constant_2 : Space{});
        Space v208_12;
        if (!v208_10.empty()) {
          const Path v210_6 = concat_path(v207_6,v207_11_head);
          const Space v210_11 = routine_17(c, v210_6, v207_11_tail);
          v208_12 = compose(v208_10,v210_11);
        }
        const Space v208_13 = unite(v208_8,v208_12);
        v207_11_result = unite(v207_11_result,v208_13);
      }
      const Space v207_11 = std::move(v207_11_result);
      v202_12 = compose(v202_10,v207_11);
    }
    const Space v202_13 = unite(v202_8,v202_12);
    v201_11_result = unite(v201_11_result,v202_13);
  }
  const Space v201_11 = std::move(v201_11_result);
  return v201_11;
}

static Space routine_25(Context& c, const Path& p0, const Space& s0) {
  Space v211_8_result;
  for (int v211_8_label = 1; v211_8_label <= 2; ++v211_8_label) {
    const Space v211_8_tail = child(s0,v211_8_label);
    if (v211_8_tail.empty()) continue;
    const Path v211_8_head{v211_8_label};
    const Space v212_2 = singleton(v211_8_head);
    const Space v212_3 = intersect(constant_1,v212_2);
    const Space v212_4 = (has_head(v212_3) ? constant_2 : Space{});
    const Space v212_5 = subtract(constant_0,v212_4);
    Space v212_8;
    if (!v212_5.empty()) {
      const Path v213_6 = concat_path(p0,v211_8_head);
      Space v213_7_result;
      for (int v213_7_label = 1; v213_7_label <= 2; ++v213_7_label) {
        const Space v213_7_tail = child(v211_8_tail,v213_7_label);
        if (v213_7_tail.empty()) continue;
        const Path v213_7_head{v213_7_label};
        const Space v214_2 = singleton(v213_7_head);
        const Space v214_3 = intersect(constant_1,v214_2);
        const Space v214_4 = (has_head(v214_3) ? constant_2 : Space{});
        const Space v214_5 = subtract(constant_0,v214_4);
        Space v214_8;
        if (!v214_5.empty()) {
          const Path v215_6 = concat_path(v213_6,v213_7_head);
          const Space v215_7 = routine_32(c, v215_6, v213_7_tail);
          v214_8 = compose(v214_5,v215_7);
        }
        const Space v214_9 = intersect(constant_1,v214_2);
        const Space v214_10 = (has_head(v214_9) ? constant_2 : Space{});
        Space v214_12;
        if (!v214_10.empty()) {
          const Path v216_6 = concat_path(v213_6,v213_7_head);
          const Space v216_11 = routine_33(c, v216_6, v213_7_tail);
          v214_12 = compose(v214_10,v216_11);
        }
        const Space v214_13 = unite(v214_8,v214_12);
        v213_7_result = unite(v213_7_result,v214_13);
      }
      const Space v213_7 = std::move(v213_7_result);
      v212_8 = compose(v212_5,v213_7);
    }
    const Space v212_9 = intersect(constant_1,v212_2);
    const Space v212_10 = (has_head(v212_9) ? constant_2 : Space{});
    const Space v212_11 = compose(v212_10,v211_8_tail);
    const Space v212_12 = unite(v212_8,v212_11);
    v211_8_result = unite(v211_8_result,v212_12);
  }
  const Space v211_8 = std::move(v211_8_result);
  return v211_8;
}

static Space routine_26(Context& c, const Path& p0, const Space& s0) {
  Space v217_6_result;
  for (int v217_6_label = 1; v217_6_label <= 2; ++v217_6_label) {
    const Space v217_6_tail = child(s0,v217_6_label);
    if (v217_6_tail.empty()) continue;
    const Path v217_6_head{v217_6_label};
    const Space v218_2 = singleton(v217_6_head);
    const Space v218_3 = intersect(constant_1,v218_2);
    const Space v218_4 = (has_head(v218_3) ? constant_2 : Space{});
    const Space v218_5 = subtract(constant_0,v218_4);
    Space v218_6_result;
    for (int v218_6_label = 1; v218_6_label <= 2; ++v218_6_label) {
      const Space v218_6_tail = child(v217_6_tail,v218_6_label);
      if (v218_6_tail.empty()) continue;
      const Path v218_6_head{v218_6_label};
      const Space v219_2 = Space{};
      v218_6_result = unite(v218_6_result,v219_2);
    }
    const Space v218_6 = std::move(v218_6_result);
    const Space v218_7 = compose(v218_5,v218_6);
    const Space v218_8 = intersect(constant_1,v218_2);
    const Space v218_9 = (has_head(v218_8) ? constant_2 : Space{});
    Space v218_12;
    if (!v218_9.empty()) {
      const Path v220_10 = concat_path(p0,v217_6_head);
      Space v220_11_result;
      for (int v220_11_label = 1; v220_11_label <= 2; ++v220_11_label) {
        const Space v220_11_tail = child(v217_6_tail,v220_11_label);
        if (v220_11_tail.empty()) continue;
        const Path v220_11_head{v220_11_label};
        const Space v221_2 = singleton(v220_11_head);
        const Space v221_3 = intersect(constant_1,v221_2);
        const Space v221_4 = (has_head(v221_3) ? constant_2 : Space{});
        Space v221_7;
        if (!v221_4.empty()) {
          const Path v222_5 = concat_path(v220_10,v220_11_head);
          const Space v222_6 = routine_14(c, v222_5, v220_11_tail);
          v221_7 = compose(v221_4,v222_6);
        }
        v220_11_result = unite(v220_11_result,v221_7);
      }
      const Space v220_11 = std::move(v220_11_result);
      v218_12 = compose(v218_9,v220_11);
    }
    const Space v218_13 = unite(v218_7,v218_12);
    v217_6_result = unite(v217_6_result,v218_13);
  }
  const Space v217_6 = std::move(v217_6_result);
  return v217_6;
}

static Space routine_27(Context& c, const Path& p0, const Space& s0) {
  Space v223_5_result;
  for (int v223_5_label = 1; v223_5_label <= 2; ++v223_5_label) {
    const Space v223_5_tail = child(s0,v223_5_label);
    if (v223_5_tail.empty()) continue;
    const Path v223_5_head{v223_5_label};
    const Space v224_2 = singleton(v223_5_head);
    const Space v224_3 = intersect(constant_1,v224_2);
    const Space v224_4 = (has_head(v224_3) ? constant_2 : Space{});
    const Space v224_5 = subtract(constant_0,v224_4);
    Space v224_6_result;
    for (int v224_6_label = 1; v224_6_label <= 2; ++v224_6_label) {
      const Space v224_6_tail = child(v223_5_tail,v224_6_label);
      if (v224_6_tail.empty()) continue;
      const Path v224_6_head{v224_6_label};
      const Space v225_2 = Space{};
      v224_6_result = unite(v224_6_result,v225_2);
    }
    const Space v224_6 = std::move(v224_6_result);
    const Space v224_7 = compose(v224_5,v224_6);
    const Space v224_8 = intersect(constant_1,v224_2);
    const Space v224_9 = (has_head(v224_8) ? constant_2 : Space{});
    const Space v224_10 = compose(v224_9,v223_5_tail);
    const Space v224_11 = unite(v224_7,v224_10);
    v223_5_result = unite(v223_5_result,v224_11);
  }
  const Space v223_5 = std::move(v223_5_result);
  return v223_5;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  Space v226_6_result;
  for (int v226_6_label = 1; v226_6_label <= 2; ++v226_6_label) {
    const Space v226_6_tail = child(s0,v226_6_label);
    if (v226_6_tail.empty()) continue;
    const Path v226_6_head{v226_6_label};
    const Space v227_2 = singleton(v226_6_head);
    const Space v227_3 = intersect(constant_1,v227_2);
    const Space v227_4 = (has_head(v227_3) ? constant_2 : Space{});
    const Space v227_5 = subtract(constant_0,v227_4);
    Space v227_6_result;
    for (int v227_6_label = 1; v227_6_label <= 2; ++v227_6_label) {
      const Space v227_6_tail = child(v226_6_tail,v227_6_label);
      if (v227_6_tail.empty()) continue;
      const Path v227_6_head{v227_6_label};
      const Space v228_2 = Space{};
      v227_6_result = unite(v227_6_result,v228_2);
    }
    const Space v227_6 = std::move(v227_6_result);
    const Space v227_7 = compose(v227_5,v227_6);
    const Space v227_8 = intersect(constant_1,v227_2);
    const Space v227_9 = (has_head(v227_8) ? constant_2 : Space{});
    Space v227_12;
    if (!v227_9.empty()) {
      const Path v229_10 = concat_path(p0,v226_6_head);
      Space v229_11_result;
      for (int v229_11_label = 1; v229_11_label <= 2; ++v229_11_label) {
        const Space v229_11_tail = child(v226_6_tail,v229_11_label);
        if (v229_11_tail.empty()) continue;
        const Path v229_11_head{v229_11_label};
        const Space v230_2 = singleton(v229_11_head);
        const Space v230_3 = intersect(constant_1,v230_2);
        const Space v230_4 = (has_head(v230_3) ? constant_2 : Space{});
        Space v230_7;
        if (!v230_4.empty()) {
          const Path v231_5 = concat_path(v229_10,v229_11_head);
          const Space v231_6 = routine_17(c, v231_5, v229_11_tail);
          v230_7 = compose(v230_4,v231_6);
        }
        v229_11_result = unite(v229_11_result,v230_7);
      }
      const Space v229_11 = std::move(v229_11_result);
      v227_12 = compose(v227_9,v229_11);
    }
    const Space v227_13 = unite(v227_7,v227_12);
    v226_6_result = unite(v226_6_result,v227_13);
  }
  const Space v226_6 = std::move(v226_6_result);
  return v226_6;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0) {
  Space v232_5_result;
  for (int v232_5_label = 1; v232_5_label <= 2; ++v232_5_label) {
    const Space v232_5_tail = child(s0,v232_5_label);
    if (v232_5_tail.empty()) continue;
    const Path v232_5_head{v232_5_label};
    const Space v233_2 = singleton(v232_5_head);
    const Space v233_3 = intersect(constant_1,v233_2);
    const Space v233_4 = (has_head(v233_3) ? constant_2 : Space{});
    const Space v233_5 = subtract(constant_0,v233_4);
    Space v233_6_result;
    for (int v233_6_label = 1; v233_6_label <= 2; ++v233_6_label) {
      const Space v233_6_tail = child(v232_5_tail,v233_6_label);
      if (v233_6_tail.empty()) continue;
      const Path v233_6_head{v233_6_label};
      const Space v234_2 = Space{};
      v233_6_result = unite(v233_6_result,v234_2);
    }
    const Space v233_6 = std::move(v233_6_result);
    const Space v233_7 = compose(v233_5,v233_6);
    const Space v233_8 = intersect(constant_1,v233_2);
    const Space v233_9 = (has_head(v233_8) ? constant_2 : Space{});
    const Space v233_10 = compose(v233_9,v232_5_tail);
    const Space v233_11 = unite(v233_7,v233_10);
    v232_5_result = unite(v232_5_result,v233_11);
  }
  const Space v232_5 = std::move(v232_5_result);
  return v232_5;
}

static Space routine_30(Context& c, const Path& p0, const Space& s0) {
  Space v235_2_result;
  for (int v235_2_label = 1; v235_2_label <= 2; ++v235_2_label) {
    const Space v235_2_tail = child(s0,v235_2_label);
    if (v235_2_tail.empty()) continue;
    const Path v235_2_head{v235_2_label};
    const Space v236_2 = Space{};
    v235_2_result = unite(v235_2_result,v236_2);
  }
  const Space v235_2 = std::move(v235_2_result);
  return v235_2;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0) {
  Space v237_3_result;
  for (int v237_3_label = 1; v237_3_label <= 2; ++v237_3_label) {
    const Space v237_3_tail = child(s0,v237_3_label);
    if (v237_3_tail.empty()) continue;
    const Path v237_3_head{v237_3_label};
    const Space v238_2 = singleton(v237_3_head);
    const Space v238_3 = intersect(constant_1,v238_2);
    const Space v238_4 = (has_head(v238_3) ? constant_2 : Space{});
    const Space v238_5 = compose(v238_4,v237_3_tail);
    v237_3_result = unite(v237_3_result,v238_5);
  }
  const Space v237_3 = std::move(v237_3_result);
  return v237_3;
}

static Space routine_32(Context& c, const Path& p0, const Space& s0) {
  Space v239_2_result;
  for (int v239_2_label = 1; v239_2_label <= 2; ++v239_2_label) {
    const Space v239_2_tail = child(s0,v239_2_label);
    if (v239_2_tail.empty()) continue;
    const Path v239_2_head{v239_2_label};
    const Space v240_2 = Space{};
    v239_2_result = unite(v239_2_result,v240_2);
  }
  const Space v239_2 = std::move(v239_2_result);
  return v239_2;
}

static Space routine_33(Context& c, const Path& p0, const Space& s0) {
  Space v241_3_result;
  for (int v241_3_label = 1; v241_3_label <= 2; ++v241_3_label) {
    const Space v241_3_tail = child(s0,v241_3_label);
    if (v241_3_tail.empty()) continue;
    const Path v241_3_head{v241_3_label};
    const Space v242_2 = singleton(v241_3_head);
    const Space v242_3 = intersect(constant_1,v242_2);
    const Space v242_4 = (has_head(v242_3) ? constant_2 : Space{});
    const Space v242_5 = compose(v242_4,v241_3_tail);
    v241_3_result = unite(v241_3_result,v242_5);
  }
  const Space v241_3 = std::move(v241_3_result);
  return v241_3;
}

static Space entry(Context& c,const Env& e) { return routine_0(c,space_arg(e,0),space_arg(e,1)); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
