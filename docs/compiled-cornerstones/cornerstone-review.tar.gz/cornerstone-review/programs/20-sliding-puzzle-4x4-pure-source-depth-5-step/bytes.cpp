#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Path constant_0 = Path{1,1,1,2};
static const Path constant_1 = Path{1,1,1,1};
static const Space constant_2 = literal_text("1 56 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_3 = Path{1,1,1,17};
static const Space constant_4 = literal_text("3 56 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 3 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 3 1 1 1 6 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_5 = Path{1,1,1,18};
static const Space constant_6 = literal_text("2 56 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 3 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_7 = Path{1,1,1,19};
static const Space constant_8 = literal_text("4 56 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 3 1 1 1 7 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 4 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 4 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 3 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_9 = Path{1,1,1,20};
static const Space constant_10 = literal_text("3 56 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 5 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_11 = Path{1,1,1,21};
static const Space constant_12 = literal_text("2 56 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_13 = Path{1,1,1,22};
static const Space constant_14 = literal_text("4 56 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 10 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 7 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_15 = Path{1,1,1,23};
static const Space constant_16 = literal_text("3 56 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_17 = Path{1,1,1,24};
static const Space constant_18 = literal_text("2 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_19 = Path{1,1,1,25};
static const Space constant_20 = literal_text("5 56 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 10 1 1 1 6 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_21 = Path{1,1,1,26};
static const Space constant_22 = literal_text("3 56 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_23 = Path{1,1,1,27};
static const Space constant_24 = literal_text("6 56 1 1 1 3 1 1 1 4 1 1 1 8 1 1 1 5 1 1 1 6 1 1 1 7 1 1 1 12 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 8 1 1 1 12 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 12 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_25 = Path{1,1,1,28};
static const Space constant_26 = literal_text("3 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 14 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 13 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 13 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_27 = Path{1,1,1,29};
static const Space constant_28 = literal_text("1 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 14 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 15 1 1 1 16");
static const Path constant_29 = Path{1,1,1,30};
static const Space constant_30 = literal_text("4 56 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 5 1 1 1 6 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 15 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 7 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 15 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 15 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 16 56 1 1 1 6 1 1 1 3 1 1 1 4 1 1 1 5 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 14 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 15 1 1 1 16");
static const Path constant_31 = Path{1,1,1,5};
static const Space constant_32 = literal_text("1 56 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_33 = literal_text("3 56 1 1 1 2 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 3 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 6 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_34 = literal_text("2 56 1 1 1 2 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 3 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_35 = literal_text("3 56 1 1 1 2 1 1 1 3 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 4 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 3 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_36 = literal_text("3 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 6 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 6 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_37 = literal_text("2 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 6 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_38 = literal_text("5 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 10 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 7 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 8 1 1 1 10 1 1 1 11 1 1 1 7 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 6 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 3 1 1 1 7 1 1 1 4 1 1 1 6 1 1 1 2 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_39 = literal_text("1 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_40 = literal_text("2 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_41 = literal_text("4 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 13 1 1 1 11 1 1 1 12 1 1 1 14 1 1 1 10 1 1 1 15 1 1 1 16");
static const Space constant_42 = literal_text("3 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_43 = literal_text("4 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 12 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_44 = literal_text("4 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 14 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 13 1 1 1 9 1 1 1 11 1 1 1 12 1 1 1 14 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 14 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 13 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_45 = literal_text("3 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 14 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 14 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 13 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_46 = literal_text("6 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 7 1 1 1 11 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 15 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 11 1 1 1 15 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 6 1 1 1 10 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 14 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 11 1 1 1 15 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 10 1 1 1 14 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 15 1 1 1 16 56 1 1 1 2 1 1 1 3 1 1 1 4 1 1 1 9 1 1 1 6 1 1 1 7 1 1 1 8 1 1 1 13 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 14 1 1 1 15 1 1 1 16");
static const Path constant_47 = Path{1,1,1,6};
static const Space constant_48 = literal_text("1 56 1 1 1 3 1 1 1 4 1 1 1 2 1 1 1 5 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_49 = literal_text("1 56 1 1 1 5 1 1 1 3 1 1 1 4 1 1 1 2 1 1 1 7 1 1 1 8 1 1 1 9 1 1 1 10 1 1 1 11 1 1 1 12 1 1 1 13 1 1 1 14 1 1 1 15 1 1 1 16");
static const Space constant_50 = literal_text("1 4 1 1 1 1");
static const Space constant_51 = literal_text("1 4 1 1 1 17");
static const Space constant_52 = literal_text("1 4 1 1 1 18");
static const Space constant_53 = literal_text("1 4 1 1 1 19");
static const Space constant_54 = literal_text("1 4 1 1 1 20");
static const Space constant_55 = literal_text("1 4 1 1 1 21");
static const Space constant_56 = literal_text("1 4 1 1 1 22");
static const Space constant_57 = literal_text("1 4 1 1 1 23");
static const Space constant_58 = literal_text("1 4 1 1 1 24");
static const Space constant_59 = literal_text("1 4 1 1 1 25");
static const Space constant_60 = literal_text("1 4 1 1 1 26");
static const Space constant_61 = literal_text("1 4 1 1 1 27");
static const Space constant_62 = literal_text("1 4 1 1 1 28");
static const Space constant_63 = literal_text("1 4 1 1 1 29");
static const Space constant_64 = literal_text("1 4 1 1 1 30");
static const Space constant_65 = literal_text("1 4 1 1 1 35");
static const Space constant_66 = literal_text("4 12 1 1 1 31 1 1 1 1 1 1 1 20 12 1 1 1 31 1 1 1 20 1 1 1 1 12 1 1 1 32 1 1 1 1 1 1 1 17 12 1 1 1 32 1 1 1 17 1 1 1 1");
static const Space constant_67 = literal_text("6 12 1 1 1 31 1 1 1 17 1 1 1 21 12 1 1 1 31 1 1 1 21 1 1 1 17 12 1 1 1 32 1 1 1 17 1 1 1 18 12 1 1 1 32 1 1 1 18 1 1 1 17 12 1 1 1 33 1 1 1 1 1 1 1 17 12 1 1 1 33 1 1 1 17 1 1 1 1");
static const Space constant_68 = literal_text("6 12 1 1 1 31 1 1 1 18 1 1 1 22 12 1 1 1 31 1 1 1 22 1 1 1 18 12 1 1 1 32 1 1 1 18 1 1 1 19 12 1 1 1 32 1 1 1 19 1 1 1 18 12 1 1 1 33 1 1 1 17 1 1 1 18 12 1 1 1 33 1 1 1 18 1 1 1 17");
static const Space constant_69 = literal_text("4 12 1 1 1 31 1 1 1 19 1 1 1 23 12 1 1 1 31 1 1 1 23 1 1 1 19 12 1 1 1 33 1 1 1 18 1 1 1 19 12 1 1 1 33 1 1 1 19 1 1 1 18");
static const Space constant_70 = literal_text("6 12 1 1 1 31 1 1 1 20 1 1 1 24 12 1 1 1 31 1 1 1 24 1 1 1 20 12 1 1 1 32 1 1 1 20 1 1 1 21 12 1 1 1 32 1 1 1 21 1 1 1 20 12 1 1 1 34 1 1 1 1 1 1 1 20 12 1 1 1 34 1 1 1 20 1 1 1 1");
static const Space constant_71 = literal_text("8 12 1 1 1 31 1 1 1 21 1 1 1 25 12 1 1 1 31 1 1 1 25 1 1 1 21 12 1 1 1 32 1 1 1 21 1 1 1 22 12 1 1 1 32 1 1 1 22 1 1 1 21 12 1 1 1 33 1 1 1 20 1 1 1 21 12 1 1 1 33 1 1 1 21 1 1 1 20 12 1 1 1 34 1 1 1 17 1 1 1 21 12 1 1 1 34 1 1 1 21 1 1 1 17");
static const Space constant_72 = literal_text("8 12 1 1 1 31 1 1 1 22 1 1 1 26 12 1 1 1 31 1 1 1 26 1 1 1 22 12 1 1 1 32 1 1 1 22 1 1 1 23 12 1 1 1 32 1 1 1 23 1 1 1 22 12 1 1 1 33 1 1 1 21 1 1 1 22 12 1 1 1 33 1 1 1 22 1 1 1 21 12 1 1 1 34 1 1 1 18 1 1 1 22 12 1 1 1 34 1 1 1 22 1 1 1 18");
static const Space constant_73 = literal_text("6 12 1 1 1 31 1 1 1 23 1 1 1 27 12 1 1 1 31 1 1 1 27 1 1 1 23 12 1 1 1 33 1 1 1 22 1 1 1 23 12 1 1 1 33 1 1 1 23 1 1 1 22 12 1 1 1 34 1 1 1 19 1 1 1 23 12 1 1 1 34 1 1 1 23 1 1 1 19");
static const Space constant_74 = literal_text("6 12 1 1 1 31 1 1 1 24 1 1 1 28 12 1 1 1 31 1 1 1 28 1 1 1 24 12 1 1 1 32 1 1 1 24 1 1 1 25 12 1 1 1 32 1 1 1 25 1 1 1 24 12 1 1 1 34 1 1 1 20 1 1 1 24 12 1 1 1 34 1 1 1 24 1 1 1 20");
static const Space constant_75 = literal_text("8 12 1 1 1 31 1 1 1 25 1 1 1 29 12 1 1 1 31 1 1 1 29 1 1 1 25 12 1 1 1 32 1 1 1 25 1 1 1 26 12 1 1 1 32 1 1 1 26 1 1 1 25 12 1 1 1 33 1 1 1 24 1 1 1 25 12 1 1 1 33 1 1 1 25 1 1 1 24 12 1 1 1 34 1 1 1 21 1 1 1 25 12 1 1 1 34 1 1 1 25 1 1 1 21");
static const Space constant_76 = literal_text("8 12 1 1 1 31 1 1 1 26 1 1 1 30 12 1 1 1 31 1 1 1 30 1 1 1 26 12 1 1 1 32 1 1 1 26 1 1 1 27 12 1 1 1 32 1 1 1 27 1 1 1 26 12 1 1 1 33 1 1 1 25 1 1 1 26 12 1 1 1 33 1 1 1 26 1 1 1 25 12 1 1 1 34 1 1 1 22 1 1 1 26 12 1 1 1 34 1 1 1 26 1 1 1 22");
static const Space constant_77 = literal_text("6 12 1 1 1 31 1 1 1 27 1 1 1 35 12 1 1 1 31 1 1 1 35 1 1 1 27 12 1 1 1 33 1 1 1 26 1 1 1 27 12 1 1 1 33 1 1 1 27 1 1 1 26 12 1 1 1 34 1 1 1 23 1 1 1 27 12 1 1 1 34 1 1 1 27 1 1 1 23");
static const Space constant_78 = literal_text("4 12 1 1 1 32 1 1 1 28 1 1 1 29 12 1 1 1 32 1 1 1 29 1 1 1 28 12 1 1 1 34 1 1 1 24 1 1 1 28 12 1 1 1 34 1 1 1 28 1 1 1 24");
static const Space constant_79 = literal_text("6 12 1 1 1 32 1 1 1 29 1 1 1 30 12 1 1 1 32 1 1 1 30 1 1 1 29 12 1 1 1 33 1 1 1 28 1 1 1 29 12 1 1 1 33 1 1 1 29 1 1 1 28 12 1 1 1 34 1 1 1 25 1 1 1 29 12 1 1 1 34 1 1 1 29 1 1 1 25");
static const Space constant_80 = literal_text("6 12 1 1 1 32 1 1 1 30 1 1 1 35 12 1 1 1 32 1 1 1 35 1 1 1 30 12 1 1 1 33 1 1 1 29 1 1 1 30 12 1 1 1 33 1 1 1 30 1 1 1 29 12 1 1 1 34 1 1 1 26 1 1 1 30 12 1 1 1 34 1 1 1 30 1 1 1 26");
static const Path constant_81 = Path{1,1,1,35};
static const Space constant_82 = literal_text("4 12 1 1 1 33 1 1 1 30 1 1 1 35 12 1 1 1 33 1 1 1 35 1 1 1 30 12 1 1 1 34 1 1 1 27 1 1 1 35 12 1 1 1 34 1 1 1 35 1 1 1 27");
static const Space constant_83 = literal_text("16 8 1 1 1 1 1 1 1 1 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 19 8 1 1 1 20 1 1 1 20 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 28 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 30 1 1 1 30 8 1 1 1 35 1 1 1 35");
static const Space constant_84 = literal_text("1 8 1 1 1 1 1 1 1 36");
static const Space constant_85 = literal_text("1 8 1 1 1 17 1 1 1 36");
static const Space constant_86 = literal_text("1 8 1 1 1 18 1 1 1 36");
static const Space constant_87 = literal_text("1 8 1 1 1 19 1 1 1 36");
static const Space constant_88 = literal_text("1 8 1 1 1 20 1 1 1 36");
static const Space constant_89 = literal_text("1 8 1 1 1 21 1 1 1 36");
static const Space constant_90 = literal_text("1 8 1 1 1 22 1 1 1 36");
static const Space constant_91 = literal_text("1 8 1 1 1 23 1 1 1 36");
static const Space constant_92 = literal_text("1 8 1 1 1 24 1 1 1 36");
static const Space constant_93 = literal_text("1 8 1 1 1 25 1 1 1 36");
static const Space constant_94 = literal_text("1 8 1 1 1 26 1 1 1 36");
static const Space constant_95 = literal_text("1 8 1 1 1 27 1 1 1 36");
static const Space constant_96 = literal_text("1 8 1 1 1 28 1 1 1 36");
static const Space constant_97 = literal_text("1 8 1 1 1 29 1 1 1 36");
static const Space constant_98 = literal_text("1 8 1 1 1 30 1 1 1 36");
static const Space constant_99 = literal_text("1 8 1 1 1 35 1 1 1 36");
static Space routine_0(Context& c);
static Space routine_68(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Space& s0);
static Space routine_149(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_133(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_79(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_117(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_101(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_85(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_69(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Space& s0);
static Space routine_150(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_134(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_118(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_63(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_102(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_86(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_70(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Space& s0);
static Space routine_151(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_135(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_119(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_45(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_103(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_87(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_71(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_53(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Space& s0);
static Space routine_152(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_136(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_120(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Space& s0);
static Space routine_104(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_88(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_72(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_54(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_29(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Space& s0);
static Space routine_153(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_137(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_121(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_105(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_89(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_73(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Space& s0);
static Space routine_31(Context& c, const Path& p0, const Space& s0);
static Space routine_154(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_138(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_9(Context& c, const Path& p0, const Space& s0);
static Space routine_122(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_106(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_90(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_74(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_56(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Space& s0);
static Space routine_33(Context& c, const Path& p0, const Space& s0);
static Space routine_155(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_144(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_139(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_123(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_107(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_91(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_75(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_57(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Space& s0);
static Space routine_156(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_140(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_128(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_124(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_108(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_92(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_76(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_58(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_36(Context& c, const Path& p0, const Space& s0);
static Space routine_37(Context& c, const Path& p0, const Space& s0);
static Space routine_157(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_141(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_112(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_125(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_109(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_93(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_77(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_59(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_38(Context& c, const Path& p0, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Space& s0);
static Space routine_158(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_142(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_96(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_126(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_110(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_94(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_78(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_60(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Space& s0);
static Space routine_61(Context& c, const Path& p0, const Space& s0);
static Space routine_41(Context& c, const Path& p0, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_80(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_62(Context& c, const Path& p0, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Space& s0);
static Space routine_44(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_8(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Path& p15, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Space& s0);
static Space routine_5(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0);
static Space routine_64(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_145(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_143(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_129(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_113(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_97(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_81(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_65(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0);
static Space routine_146(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_130(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_127(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_114(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_98(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_82(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_66(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_147(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_131(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_111(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_115(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_99(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_83(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_67(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0);
static Space routine_49(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0);
static Space routine_18(Context& c, const Path& p0, const Space& s0);
static Space routine_19(Context& c, const Path& p0, const Space& s0);
static Space routine_148(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0);
static Space routine_132(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0);
static Space routine_95(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_116(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0);
static Space routine_100(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0);
static Space routine_84(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0);
static Space routine_0(Context& c) {
  const Space v0_3 = routine_1(c, constant_0, constant_1, constant_2);
  const Space v0_6 = routine_1(c, constant_0, constant_3, constant_4);
  const Space v0_7 = unite(v0_3,v0_6);
  const Space v0_10 = routine_1(c, constant_0, constant_5, constant_6);
  const Space v0_11 = unite(v0_7,v0_10);
  const Space v0_14 = routine_1(c, constant_0, constant_7, constant_8);
  const Space v0_15 = unite(v0_11,v0_14);
  const Space v0_18 = routine_1(c, constant_0, constant_9, constant_10);
  const Space v0_19 = unite(v0_15,v0_18);
  const Space v0_22 = routine_1(c, constant_0, constant_11, constant_12);
  const Space v0_23 = unite(v0_19,v0_22);
  const Space v0_26 = routine_1(c, constant_0, constant_13, constant_14);
  const Space v0_27 = unite(v0_23,v0_26);
  const Space v0_30 = routine_1(c, constant_0, constant_15, constant_16);
  const Space v0_31 = unite(v0_27,v0_30);
  const Space v0_34 = routine_1(c, constant_0, constant_17, constant_18);
  const Space v0_35 = unite(v0_31,v0_34);
  const Space v0_38 = routine_1(c, constant_0, constant_19, constant_20);
  const Space v0_39 = unite(v0_35,v0_38);
  const Space v0_42 = routine_1(c, constant_0, constant_21, constant_22);
  const Space v0_43 = unite(v0_39,v0_42);
  const Space v0_46 = routine_1(c, constant_0, constant_23, constant_24);
  const Space v0_47 = unite(v0_43,v0_46);
  const Space v0_50 = routine_1(c, constant_0, constant_25, constant_26);
  const Space v0_51 = unite(v0_47,v0_50);
  const Space v0_54 = routine_1(c, constant_0, constant_27, constant_28);
  const Space v0_55 = unite(v0_51,v0_54);
  const Space v0_58 = routine_1(c, constant_0, constant_29, constant_30);
  const Space v0_59 = unite(v0_55,v0_58);
  const Space v0_62 = routine_1(c, constant_31, constant_1, constant_32);
  const Space v0_63 = unite(v0_59,v0_62);
  const Space v0_65 = routine_1(c, constant_31, constant_3, constant_33);
  const Space v0_66 = unite(v0_63,v0_65);
  const Space v0_68 = routine_1(c, constant_31, constant_5, constant_34);
  const Space v0_69 = unite(v0_66,v0_68);
  const Space v0_71 = routine_1(c, constant_31, constant_7, constant_35);
  const Space v0_72 = unite(v0_69,v0_71);
  const Space v0_74 = routine_1(c, constant_31, constant_9, constant_36);
  const Space v0_75 = unite(v0_72,v0_74);
  const Space v0_77 = routine_1(c, constant_31, constant_11, constant_37);
  const Space v0_78 = unite(v0_75,v0_77);
  const Space v0_80 = routine_1(c, constant_31, constant_13, constant_38);
  const Space v0_81 = unite(v0_78,v0_80);
  const Space v0_83 = routine_1(c, constant_31, constant_15, constant_39);
  const Space v0_84 = unite(v0_81,v0_83);
  const Space v0_86 = routine_1(c, constant_31, constant_17, constant_40);
  const Space v0_87 = unite(v0_84,v0_86);
  const Space v0_89 = routine_1(c, constant_31, constant_19, constant_41);
  const Space v0_90 = unite(v0_87,v0_89);
  const Space v0_92 = routine_1(c, constant_31, constant_21, constant_42);
  const Space v0_93 = unite(v0_90,v0_92);
  const Space v0_95 = routine_1(c, constant_31, constant_23, constant_43);
  const Space v0_96 = unite(v0_93,v0_95);
  const Space v0_98 = routine_1(c, constant_31, constant_25, constant_44);
  const Space v0_99 = unite(v0_96,v0_98);
  const Space v0_101 = routine_1(c, constant_31, constant_27, constant_45);
  const Space v0_102 = unite(v0_99,v0_101);
  const Space v0_104 = routine_1(c, constant_31, constant_29, constant_46);
  const Space v0_105 = unite(v0_102,v0_104);
  const Space v0_108 = routine_1(c, constant_47, constant_1, constant_48);
  const Space v0_109 = unite(v0_105,v0_108);
  const Space v0_111 = routine_1(c, constant_47, constant_3, constant_48);
  const Space v0_112 = unite(v0_109,v0_111);
  const Space v0_114 = routine_1(c, constant_47, constant_9, constant_49);
  const Space v0_115 = unite(v0_112,v0_114);
  return v0_115;
}

static Space routine_1(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const auto v1_3_branches = branches(c,s0);
  std::vector<Space> v1_3_outputs;
  v1_3_outputs.reserve(v1_3_branches.size());
  for (const auto& v1_3_branch : v1_3_branches) {
    const Path v1_3_head{v1_3_branch.first};
    const Space& v1_3_tail = v1_3_branch.second;
    const auto v2_2_branches = branches(c,v1_3_tail);
    std::vector<Space> v2_2_outputs;
    v2_2_outputs.reserve(v2_2_branches.size());
    for (const auto& v2_2_branch : v2_2_branches) {
      const Path v2_2_head{v2_2_branch.first};
      const Space& v2_2_tail = v2_2_branch.second;
      const Path v3_2 = concat_path(v1_3_head,v2_2_head);
      const auto v3_3_branches = branches(c,v2_2_tail);
      std::vector<Space> v3_3_outputs;
      v3_3_outputs.reserve(v3_3_branches.size());
      for (const auto& v3_3_branch : v3_3_branches) {
        const Path v3_3_head{v3_3_branch.first};
        const Space& v3_3_tail = v3_3_branch.second;
        const Path v4_2 = concat_path(v3_2,v3_3_head);
        const auto v4_3_branches = branches(c,v3_3_tail);
        std::vector<Space> v4_3_outputs;
        v4_3_outputs.reserve(v4_3_branches.size());
        for (const auto& v4_3_branch : v4_3_branches) {
          const Path v4_3_head{v4_3_branch.first};
          const Space& v4_3_tail = v4_3_branch.second;
          const Path v5_2 = concat_path(v4_2,v4_3_head);
          const auto v5_3_branches = branches(c,v4_3_tail);
          std::vector<Space> v5_3_outputs;
          v5_3_outputs.reserve(v5_3_branches.size());
          for (const auto& v5_3_branch : v5_3_branches) {
            const Path v5_3_head{v5_3_branch.first};
            const Space& v5_3_tail = v5_3_branch.second;
            const auto v6_2_branches = branches(c,v5_3_tail);
            std::vector<Space> v6_2_outputs;
            v6_2_outputs.reserve(v6_2_branches.size());
            for (const auto& v6_2_branch : v6_2_branches) {
              const Path v6_2_head{v6_2_branch.first};
              const Space& v6_2_tail = v6_2_branch.second;
              const Path v7_2 = concat_path(v5_3_head,v6_2_head);
              const auto v7_3_branches = branches(c,v6_2_tail);
              std::vector<Space> v7_3_outputs;
              v7_3_outputs.reserve(v7_3_branches.size());
              for (const auto& v7_3_branch : v7_3_branches) {
                const Path v7_3_head{v7_3_branch.first};
                const Space& v7_3_tail = v7_3_branch.second;
                const Path v8_2 = concat_path(v7_2,v7_3_head);
                const auto v8_3_branches = branches(c,v7_3_tail);
                std::vector<Space> v8_3_outputs;
                v8_3_outputs.reserve(v8_3_branches.size());
                for (const auto& v8_3_branch : v8_3_branches) {
                  const Path v8_3_head{v8_3_branch.first};
                  const Space& v8_3_tail = v8_3_branch.second;
                  const Path v9_2 = concat_path(v8_2,v8_3_head);
                  const Space v9_3 = routine_2(c, v9_2, p1, p0, v5_2, v8_3_tail);
                  v8_3_outputs.push_back(v9_3);
                }
                const Space v8_3 = join_outputs(std::move(v8_3_outputs));
                v7_3_outputs.push_back(v8_3);
              }
              const Space v7_3 = join_outputs(std::move(v7_3_outputs));
              v6_2_outputs.push_back(v7_3);
            }
            const Space v6_2 = join_outputs(std::move(v6_2_outputs));
            v5_3_outputs.push_back(v6_2);
          }
          const Space v5_3 = join_outputs(std::move(v5_3_outputs));
          v4_3_outputs.push_back(v5_3);
        }
        const Space v4_3 = join_outputs(std::move(v4_3_outputs));
        v3_3_outputs.push_back(v4_3);
      }
      const Space v3_3 = join_outputs(std::move(v3_3_outputs));
      v2_2_outputs.push_back(v3_3);
    }
    const Space v2_2 = join_outputs(std::move(v2_2_outputs));
    v1_3_outputs.push_back(v2_2);
  }
  const Space v1_3 = join_outputs(std::move(v1_3_outputs));
  return v1_3;
}

static Space routine_2(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Space& s0) {
  const auto v10_5_branches = branches(c,s0);
  std::vector<Space> v10_5_outputs;
  v10_5_outputs.reserve(v10_5_branches.size());
  for (const auto& v10_5_branch : v10_5_branches) {
    const Path v10_5_head{v10_5_branch.first};
    const Space& v10_5_tail = v10_5_branch.second;
    const auto v11_2_branches = branches(c,v10_5_tail);
    std::vector<Space> v11_2_outputs;
    v11_2_outputs.reserve(v11_2_branches.size());
    for (const auto& v11_2_branch : v11_2_branches) {
      const Path v11_2_head{v11_2_branch.first};
      const Space& v11_2_tail = v11_2_branch.second;
      const Path v12_2 = concat_path(v10_5_head,v11_2_head);
      const auto v12_3_branches = branches(c,v11_2_tail);
      std::vector<Space> v12_3_outputs;
      v12_3_outputs.reserve(v12_3_branches.size());
      for (const auto& v12_3_branch : v12_3_branches) {
        const Path v12_3_head{v12_3_branch.first};
        const Space& v12_3_tail = v12_3_branch.second;
        const Path v13_2 = concat_path(v12_2,v12_3_head);
        const auto v13_3_branches = branches(c,v12_3_tail);
        std::vector<Space> v13_3_outputs;
        v13_3_outputs.reserve(v13_3_branches.size());
        for (const auto& v13_3_branch : v13_3_branches) {
          const Path v13_3_head{v13_3_branch.first};
          const Space& v13_3_tail = v13_3_branch.second;
          const Path v14_2 = concat_path(v13_2,v13_3_head);
          const auto v14_3_branches = branches(c,v13_3_tail);
          std::vector<Space> v14_3_outputs;
          v14_3_outputs.reserve(v14_3_branches.size());
          for (const auto& v14_3_branch : v14_3_branches) {
            const Path v14_3_head{v14_3_branch.first};
            const Space& v14_3_tail = v14_3_branch.second;
            const auto v15_2_branches = branches(c,v14_3_tail);
            std::vector<Space> v15_2_outputs;
            v15_2_outputs.reserve(v15_2_branches.size());
            for (const auto& v15_2_branch : v15_2_branches) {
              const Path v15_2_head{v15_2_branch.first};
              const Space& v15_2_tail = v15_2_branch.second;
              const Path v16_2 = concat_path(v14_3_head,v15_2_head);
              const auto v16_3_branches = branches(c,v15_2_tail);
              std::vector<Space> v16_3_outputs;
              v16_3_outputs.reserve(v16_3_branches.size());
              for (const auto& v16_3_branch : v16_3_branches) {
                const Path v16_3_head{v16_3_branch.first};
                const Space& v16_3_tail = v16_3_branch.second;
                const Path v17_2 = concat_path(v16_2,v16_3_head);
                const auto v17_3_branches = branches(c,v16_3_tail);
                std::vector<Space> v17_3_outputs;
                v17_3_outputs.reserve(v17_3_branches.size());
                for (const auto& v17_3_branch : v17_3_branches) {
                  const Path v17_3_head{v17_3_branch.first};
                  const Space& v17_3_tail = v17_3_branch.second;
                  const Path v18_2 = concat_path(v17_2,v17_3_head);
                  const Space v18_3 = routine_3(c, v18_2, p1, p2, p3, p0, v14_2, v17_3_tail);
                  v17_3_outputs.push_back(v18_3);
                }
                const Space v17_3 = join_outputs(std::move(v17_3_outputs));
                v16_3_outputs.push_back(v17_3);
              }
              const Space v16_3 = join_outputs(std::move(v16_3_outputs));
              v15_2_outputs.push_back(v16_3);
            }
            const Space v15_2 = join_outputs(std::move(v15_2_outputs));
            v14_3_outputs.push_back(v15_2);
          }
          const Space v14_3 = join_outputs(std::move(v14_3_outputs));
          v13_3_outputs.push_back(v14_3);
        }
        const Space v13_3 = join_outputs(std::move(v13_3_outputs));
        v12_3_outputs.push_back(v13_3);
      }
      const Space v12_3 = join_outputs(std::move(v12_3_outputs));
      v11_2_outputs.push_back(v12_3);
    }
    const Space v11_2 = join_outputs(std::move(v11_2_outputs));
    v10_5_outputs.push_back(v11_2);
  }
  const Space v10_5 = join_outputs(std::move(v10_5_outputs));
  return v10_5;
}

static Space routine_3(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Space& s0) {
  const auto v19_7_branches = branches(c,s0);
  std::vector<Space> v19_7_outputs;
  v19_7_outputs.reserve(v19_7_branches.size());
  for (const auto& v19_7_branch : v19_7_branches) {
    const Path v19_7_head{v19_7_branch.first};
    const Space& v19_7_tail = v19_7_branch.second;
    const auto v20_2_branches = branches(c,v19_7_tail);
    std::vector<Space> v20_2_outputs;
    v20_2_outputs.reserve(v20_2_branches.size());
    for (const auto& v20_2_branch : v20_2_branches) {
      const Path v20_2_head{v20_2_branch.first};
      const Space& v20_2_tail = v20_2_branch.second;
      const Path v21_2 = concat_path(v19_7_head,v20_2_head);
      const auto v21_3_branches = branches(c,v20_2_tail);
      std::vector<Space> v21_3_outputs;
      v21_3_outputs.reserve(v21_3_branches.size());
      for (const auto& v21_3_branch : v21_3_branches) {
        const Path v21_3_head{v21_3_branch.first};
        const Space& v21_3_tail = v21_3_branch.second;
        const Path v22_2 = concat_path(v21_2,v21_3_head);
        const auto v22_3_branches = branches(c,v21_3_tail);
        std::vector<Space> v22_3_outputs;
        v22_3_outputs.reserve(v22_3_branches.size());
        for (const auto& v22_3_branch : v22_3_branches) {
          const Path v22_3_head{v22_3_branch.first};
          const Space& v22_3_tail = v22_3_branch.second;
          const Path v23_2 = concat_path(v22_2,v22_3_head);
          const auto v23_3_branches = branches(c,v22_3_tail);
          std::vector<Space> v23_3_outputs;
          v23_3_outputs.reserve(v23_3_branches.size());
          for (const auto& v23_3_branch : v23_3_branches) {
            const Path v23_3_head{v23_3_branch.first};
            const Space& v23_3_tail = v23_3_branch.second;
            const auto v24_2_branches = branches(c,v23_3_tail);
            std::vector<Space> v24_2_outputs;
            v24_2_outputs.reserve(v24_2_branches.size());
            for (const auto& v24_2_branch : v24_2_branches) {
              const Path v24_2_head{v24_2_branch.first};
              const Space& v24_2_tail = v24_2_branch.second;
              const Path v25_2 = concat_path(v23_3_head,v24_2_head);
              const auto v25_3_branches = branches(c,v24_2_tail);
              std::vector<Space> v25_3_outputs;
              v25_3_outputs.reserve(v25_3_branches.size());
              for (const auto& v25_3_branch : v25_3_branches) {
                const Path v25_3_head{v25_3_branch.first};
                const Space& v25_3_tail = v25_3_branch.second;
                const Path v26_2 = concat_path(v25_2,v25_3_head);
                const auto v26_3_branches = branches(c,v25_3_tail);
                std::vector<Space> v26_3_outputs;
                v26_3_outputs.reserve(v26_3_branches.size());
                for (const auto& v26_3_branch : v26_3_branches) {
                  const Path v26_3_head{v26_3_branch.first};
                  const Space& v26_3_tail = v26_3_branch.second;
                  const Path v27_2 = concat_path(v26_2,v26_3_head);
                  const Space v27_3 = routine_4(c, v27_2, p1, p2, p3, p4, p5, p0, v23_2, v26_3_tail);
                  v26_3_outputs.push_back(v27_3);
                }
                const Space v26_3 = join_outputs(std::move(v26_3_outputs));
                v25_3_outputs.push_back(v26_3);
              }
              const Space v25_3 = join_outputs(std::move(v25_3_outputs));
              v24_2_outputs.push_back(v25_3);
            }
            const Space v24_2 = join_outputs(std::move(v24_2_outputs));
            v23_3_outputs.push_back(v24_2);
          }
          const Space v23_3 = join_outputs(std::move(v23_3_outputs));
          v22_3_outputs.push_back(v23_3);
        }
        const Space v22_3 = join_outputs(std::move(v22_3_outputs));
        v21_3_outputs.push_back(v22_3);
      }
      const Space v21_3 = join_outputs(std::move(v21_3_outputs));
      v20_2_outputs.push_back(v21_3);
    }
    const Space v20_2 = join_outputs(std::move(v20_2_outputs));
    v19_7_outputs.push_back(v20_2);
  }
  const Space v19_7 = join_outputs(std::move(v19_7_outputs));
  return v19_7;
}

static Space routine_4(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Space& s0) {
  const auto v28_9_branches = branches(c,s0);
  std::vector<Space> v28_9_outputs;
  v28_9_outputs.reserve(v28_9_branches.size());
  for (const auto& v28_9_branch : v28_9_branches) {
    const Path v28_9_head{v28_9_branch.first};
    const Space& v28_9_tail = v28_9_branch.second;
    const auto v29_2_branches = branches(c,v28_9_tail);
    std::vector<Space> v29_2_outputs;
    v29_2_outputs.reserve(v29_2_branches.size());
    for (const auto& v29_2_branch : v29_2_branches) {
      const Path v29_2_head{v29_2_branch.first};
      const Space& v29_2_tail = v29_2_branch.second;
      const Path v30_2 = concat_path(v28_9_head,v29_2_head);
      const auto v30_3_branches = branches(c,v29_2_tail);
      std::vector<Space> v30_3_outputs;
      v30_3_outputs.reserve(v30_3_branches.size());
      for (const auto& v30_3_branch : v30_3_branches) {
        const Path v30_3_head{v30_3_branch.first};
        const Space& v30_3_tail = v30_3_branch.second;
        const Path v31_2 = concat_path(v30_2,v30_3_head);
        const auto v31_3_branches = branches(c,v30_3_tail);
        std::vector<Space> v31_3_outputs;
        v31_3_outputs.reserve(v31_3_branches.size());
        for (const auto& v31_3_branch : v31_3_branches) {
          const Path v31_3_head{v31_3_branch.first};
          const Space& v31_3_tail = v31_3_branch.second;
          const Path v32_2 = concat_path(v31_2,v31_3_head);
          const auto v32_3_branches = branches(c,v31_3_tail);
          std::vector<Space> v32_3_outputs;
          v32_3_outputs.reserve(v32_3_branches.size());
          for (const auto& v32_3_branch : v32_3_branches) {
            const Path v32_3_head{v32_3_branch.first};
            const Space& v32_3_tail = v32_3_branch.second;
            const auto v33_2_branches = branches(c,v32_3_tail);
            std::vector<Space> v33_2_outputs;
            v33_2_outputs.reserve(v33_2_branches.size());
            for (const auto& v33_2_branch : v33_2_branches) {
              const Path v33_2_head{v33_2_branch.first};
              const Space& v33_2_tail = v33_2_branch.second;
              const Path v34_2 = concat_path(v32_3_head,v33_2_head);
              const auto v34_3_branches = branches(c,v33_2_tail);
              std::vector<Space> v34_3_outputs;
              v34_3_outputs.reserve(v34_3_branches.size());
              for (const auto& v34_3_branch : v34_3_branches) {
                const Path v34_3_head{v34_3_branch.first};
                const Space& v34_3_tail = v34_3_branch.second;
                const Path v35_2 = concat_path(v34_2,v34_3_head);
                const auto v35_3_branches = branches(c,v34_3_tail);
                std::vector<Space> v35_3_outputs;
                v35_3_outputs.reserve(v35_3_branches.size());
                for (const auto& v35_3_branch : v35_3_branches) {
                  const Path v35_3_head{v35_3_branch.first};
                  const Space& v35_3_tail = v35_3_branch.second;
                  const Path v36_2 = concat_path(v35_2,v35_3_head);
                  const Space v36_3 = routine_5(c, v36_2, p1, p2, p3, p4, p5, p6, p7, p0, v32_2, v35_3_tail);
                  v35_3_outputs.push_back(v36_3);
                }
                const Space v35_3 = join_outputs(std::move(v35_3_outputs));
                v34_3_outputs.push_back(v35_3);
              }
              const Space v34_3 = join_outputs(std::move(v34_3_outputs));
              v33_2_outputs.push_back(v34_3);
            }
            const Space v33_2 = join_outputs(std::move(v33_2_outputs));
            v32_3_outputs.push_back(v33_2);
          }
          const Space v32_3 = join_outputs(std::move(v32_3_outputs));
          v31_3_outputs.push_back(v32_3);
        }
        const Space v31_3 = join_outputs(std::move(v31_3_outputs));
        v30_3_outputs.push_back(v31_3);
      }
      const Space v30_3 = join_outputs(std::move(v30_3_outputs));
      v29_2_outputs.push_back(v30_3);
    }
    const Space v29_2 = join_outputs(std::move(v29_2_outputs));
    v28_9_outputs.push_back(v29_2);
  }
  const Space v28_9 = join_outputs(std::move(v28_9_outputs));
  return v28_9;
}

static Space routine_5(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Space& s0) {
  const auto v37_11_branches = branches(c,s0);
  std::vector<Space> v37_11_outputs;
  v37_11_outputs.reserve(v37_11_branches.size());
  for (const auto& v37_11_branch : v37_11_branches) {
    const Path v37_11_head{v37_11_branch.first};
    const Space& v37_11_tail = v37_11_branch.second;
    const auto v38_2_branches = branches(c,v37_11_tail);
    std::vector<Space> v38_2_outputs;
    v38_2_outputs.reserve(v38_2_branches.size());
    for (const auto& v38_2_branch : v38_2_branches) {
      const Path v38_2_head{v38_2_branch.first};
      const Space& v38_2_tail = v38_2_branch.second;
      const Path v39_2 = concat_path(v37_11_head,v38_2_head);
      const auto v39_3_branches = branches(c,v38_2_tail);
      std::vector<Space> v39_3_outputs;
      v39_3_outputs.reserve(v39_3_branches.size());
      for (const auto& v39_3_branch : v39_3_branches) {
        const Path v39_3_head{v39_3_branch.first};
        const Space& v39_3_tail = v39_3_branch.second;
        const Path v40_2 = concat_path(v39_2,v39_3_head);
        const auto v40_3_branches = branches(c,v39_3_tail);
        std::vector<Space> v40_3_outputs;
        v40_3_outputs.reserve(v40_3_branches.size());
        for (const auto& v40_3_branch : v40_3_branches) {
          const Path v40_3_head{v40_3_branch.first};
          const Space& v40_3_tail = v40_3_branch.second;
          const Path v41_2 = concat_path(v40_2,v40_3_head);
          const auto v41_3_branches = branches(c,v40_3_tail);
          std::vector<Space> v41_3_outputs;
          v41_3_outputs.reserve(v41_3_branches.size());
          for (const auto& v41_3_branch : v41_3_branches) {
            const Path v41_3_head{v41_3_branch.first};
            const Space& v41_3_tail = v41_3_branch.second;
            const auto v42_2_branches = branches(c,v41_3_tail);
            std::vector<Space> v42_2_outputs;
            v42_2_outputs.reserve(v42_2_branches.size());
            for (const auto& v42_2_branch : v42_2_branches) {
              const Path v42_2_head{v42_2_branch.first};
              const Space& v42_2_tail = v42_2_branch.second;
              const Path v43_2 = concat_path(v41_3_head,v42_2_head);
              const auto v43_3_branches = branches(c,v42_2_tail);
              std::vector<Space> v43_3_outputs;
              v43_3_outputs.reserve(v43_3_branches.size());
              for (const auto& v43_3_branch : v43_3_branches) {
                const Path v43_3_head{v43_3_branch.first};
                const Space& v43_3_tail = v43_3_branch.second;
                const Path v44_2 = concat_path(v43_2,v43_3_head);
                const auto v44_3_branches = branches(c,v43_3_tail);
                std::vector<Space> v44_3_outputs;
                v44_3_outputs.reserve(v44_3_branches.size());
                for (const auto& v44_3_branch : v44_3_branches) {
                  const Path v44_3_head{v44_3_branch.first};
                  const Space& v44_3_tail = v44_3_branch.second;
                  const Path v45_2 = concat_path(v44_2,v44_3_head);
                  const Space v45_3 = routine_6(c, v45_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p0, v41_2, v44_3_tail);
                  v44_3_outputs.push_back(v45_3);
                }
                const Space v44_3 = join_outputs(std::move(v44_3_outputs));
                v43_3_outputs.push_back(v44_3);
              }
              const Space v43_3 = join_outputs(std::move(v43_3_outputs));
              v42_2_outputs.push_back(v43_3);
            }
            const Space v42_2 = join_outputs(std::move(v42_2_outputs));
            v41_3_outputs.push_back(v42_2);
          }
          const Space v41_3 = join_outputs(std::move(v41_3_outputs));
          v40_3_outputs.push_back(v41_3);
        }
        const Space v40_3 = join_outputs(std::move(v40_3_outputs));
        v39_3_outputs.push_back(v40_3);
      }
      const Space v39_3 = join_outputs(std::move(v39_3_outputs));
      v38_2_outputs.push_back(v39_3);
    }
    const Space v38_2 = join_outputs(std::move(v38_2_outputs));
    v37_11_outputs.push_back(v38_2);
  }
  const Space v37_11 = join_outputs(std::move(v37_11_outputs));
  return v37_11;
}

static Space routine_6(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Space& s0) {
  const auto v46_13_branches = branches(c,s0);
  std::vector<Space> v46_13_outputs;
  v46_13_outputs.reserve(v46_13_branches.size());
  for (const auto& v46_13_branch : v46_13_branches) {
    const Path v46_13_head{v46_13_branch.first};
    const Space& v46_13_tail = v46_13_branch.second;
    const auto v47_2_branches = branches(c,v46_13_tail);
    std::vector<Space> v47_2_outputs;
    v47_2_outputs.reserve(v47_2_branches.size());
    for (const auto& v47_2_branch : v47_2_branches) {
      const Path v47_2_head{v47_2_branch.first};
      const Space& v47_2_tail = v47_2_branch.second;
      const Path v48_2 = concat_path(v46_13_head,v47_2_head);
      const auto v48_3_branches = branches(c,v47_2_tail);
      std::vector<Space> v48_3_outputs;
      v48_3_outputs.reserve(v48_3_branches.size());
      for (const auto& v48_3_branch : v48_3_branches) {
        const Path v48_3_head{v48_3_branch.first};
        const Space& v48_3_tail = v48_3_branch.second;
        const Path v49_2 = concat_path(v48_2,v48_3_head);
        const auto v49_3_branches = branches(c,v48_3_tail);
        std::vector<Space> v49_3_outputs;
        v49_3_outputs.reserve(v49_3_branches.size());
        for (const auto& v49_3_branch : v49_3_branches) {
          const Path v49_3_head{v49_3_branch.first};
          const Space& v49_3_tail = v49_3_branch.second;
          const Path v50_2 = concat_path(v49_2,v49_3_head);
          const auto v50_3_branches = branches(c,v49_3_tail);
          std::vector<Space> v50_3_outputs;
          v50_3_outputs.reserve(v50_3_branches.size());
          for (const auto& v50_3_branch : v50_3_branches) {
            const Path v50_3_head{v50_3_branch.first};
            const Space& v50_3_tail = v50_3_branch.second;
            const auto v51_2_branches = branches(c,v50_3_tail);
            std::vector<Space> v51_2_outputs;
            v51_2_outputs.reserve(v51_2_branches.size());
            for (const auto& v51_2_branch : v51_2_branches) {
              const Path v51_2_head{v51_2_branch.first};
              const Space& v51_2_tail = v51_2_branch.second;
              const Path v52_2 = concat_path(v50_3_head,v51_2_head);
              const auto v52_3_branches = branches(c,v51_2_tail);
              std::vector<Space> v52_3_outputs;
              v52_3_outputs.reserve(v52_3_branches.size());
              for (const auto& v52_3_branch : v52_3_branches) {
                const Path v52_3_head{v52_3_branch.first};
                const Space& v52_3_tail = v52_3_branch.second;
                const Path v53_2 = concat_path(v52_2,v52_3_head);
                const auto v53_3_branches = branches(c,v52_3_tail);
                std::vector<Space> v53_3_outputs;
                v53_3_outputs.reserve(v53_3_branches.size());
                for (const auto& v53_3_branch : v53_3_branches) {
                  const Path v53_3_head{v53_3_branch.first};
                  const Space& v53_3_tail = v53_3_branch.second;
                  const Path v54_2 = concat_path(v53_2,v53_3_head);
                  const Space v54_3 = routine_7(c, v54_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p0, v50_2, v53_3_tail);
                  v53_3_outputs.push_back(v54_3);
                }
                const Space v53_3 = join_outputs(std::move(v53_3_outputs));
                v52_3_outputs.push_back(v53_3);
              }
              const Space v52_3 = join_outputs(std::move(v52_3_outputs));
              v51_2_outputs.push_back(v52_3);
            }
            const Space v51_2 = join_outputs(std::move(v51_2_outputs));
            v50_3_outputs.push_back(v51_2);
          }
          const Space v50_3 = join_outputs(std::move(v50_3_outputs));
          v49_3_outputs.push_back(v50_3);
        }
        const Space v49_3 = join_outputs(std::move(v49_3_outputs));
        v48_3_outputs.push_back(v49_3);
      }
      const Space v48_3 = join_outputs(std::move(v48_3_outputs));
      v47_2_outputs.push_back(v48_3);
    }
    const Space v47_2 = join_outputs(std::move(v47_2_outputs));
    v46_13_outputs.push_back(v47_2);
  }
  const Space v46_13 = join_outputs(std::move(v46_13_outputs));
  return v46_13;
}

static Space routine_7(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Space& s0) {
  const auto v55_15_branches = branches(c,s0);
  std::vector<Space> v55_15_outputs;
  v55_15_outputs.reserve(v55_15_branches.size());
  for (const auto& v55_15_branch : v55_15_branches) {
    const Path v55_15_head{v55_15_branch.first};
    const Space& v55_15_tail = v55_15_branch.second;
    const auto v56_2_branches = branches(c,v55_15_tail);
    std::vector<Space> v56_2_outputs;
    v56_2_outputs.reserve(v56_2_branches.size());
    for (const auto& v56_2_branch : v56_2_branches) {
      const Path v56_2_head{v56_2_branch.first};
      const Space& v56_2_tail = v56_2_branch.second;
      const Path v57_2 = concat_path(v55_15_head,v56_2_head);
      const auto v57_3_branches = branches(c,v56_2_tail);
      std::vector<Space> v57_3_outputs;
      v57_3_outputs.reserve(v57_3_branches.size());
      for (const auto& v57_3_branch : v57_3_branches) {
        const Path v57_3_head{v57_3_branch.first};
        const Space& v57_3_tail = v57_3_branch.second;
        const Path v58_2 = concat_path(v57_2,v57_3_head);
        const auto v58_3_branches = branches(c,v57_3_tail);
        std::vector<Space> v58_3_outputs;
        v58_3_outputs.reserve(v58_3_branches.size());
        for (const auto& v58_3_branch : v58_3_branches) {
          const Path v58_3_head{v58_3_branch.first};
          const Space& v58_3_tail = v58_3_branch.second;
          const Path v59_2 = concat_path(v58_2,v58_3_head);
          const auto v59_3_branches = branches(c,v58_3_tail);
          std::vector<Space> v59_3_outputs;
          v59_3_outputs.reserve(v59_3_branches.size());
          for (const auto& v59_3_branch : v59_3_branches) {
            const Path v59_3_head{v59_3_branch.first};
            const Space& v59_3_tail = v59_3_branch.second;
            const auto v60_2_branches = branches(c,v59_3_tail);
            std::vector<Space> v60_2_outputs;
            v60_2_outputs.reserve(v60_2_branches.size());
            for (const auto& v60_2_branch : v60_2_branches) {
              const Path v60_2_head{v60_2_branch.first};
              const Space& v60_2_tail = v60_2_branch.second;
              const Path v61_2 = concat_path(v59_3_head,v60_2_head);
              const auto v61_3_branches = branches(c,v60_2_tail);
              std::vector<Space> v61_3_outputs;
              v61_3_outputs.reserve(v61_3_branches.size());
              for (const auto& v61_3_branch : v61_3_branches) {
                const Path v61_3_head{v61_3_branch.first};
                const Space& v61_3_tail = v61_3_branch.second;
                const Path v62_2 = concat_path(v61_2,v61_3_head);
                const auto v62_3_branches = branches(c,v61_3_tail);
                std::vector<Space> v62_3_outputs;
                v62_3_outputs.reserve(v62_3_branches.size());
                for (const auto& v62_3_branch : v62_3_branches) {
                  const Path v62_3_head{v62_3_branch.first};
                  const Space& v62_3_tail = v62_3_branch.second;
                  const Path v63_2 = concat_path(v62_2,v62_3_head);
                  const Space v63_3 = routine_8(c, v63_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p13, p0, v59_2, v62_3_tail);
                  v62_3_outputs.push_back(v63_3);
                }
                const Space v62_3 = join_outputs(std::move(v62_3_outputs));
                v61_3_outputs.push_back(v62_3);
              }
              const Space v61_3 = join_outputs(std::move(v61_3_outputs));
              v60_2_outputs.push_back(v61_3);
            }
            const Space v60_2 = join_outputs(std::move(v60_2_outputs));
            v59_3_outputs.push_back(v60_2);
          }
          const Space v59_3 = join_outputs(std::move(v59_3_outputs));
          v58_3_outputs.push_back(v59_3);
        }
        const Space v58_3 = join_outputs(std::move(v58_3_outputs));
        v57_3_outputs.push_back(v58_3);
      }
      const Space v57_3 = join_outputs(std::move(v57_3_outputs));
      v56_2_outputs.push_back(v57_3);
    }
    const Space v56_2 = join_outputs(std::move(v56_2_outputs));
    v55_15_outputs.push_back(v56_2);
  }
  const Space v55_15 = join_outputs(std::move(v55_15_outputs));
  return v55_15;
}

static Space routine_8(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Path& p15, const Space& s0) {
  const Space v64_18 = singleton(p1);
  const Space v64_19 = intersect(constant_50,v64_18);
  const auto v64_20_branches = branches(c,v64_19);
  std::vector<Space> v64_20_outputs;
  v64_20_outputs.reserve(v64_20_branches.size());
  for (const auto& v64_20_branch : v64_20_branches) {
    const Path v64_20_head{v64_20_branch.first};
    const Space& v64_20_tail = v64_20_branch.second;
    const auto v65_2_branches = branches(c,v64_20_tail);
    std::vector<Space> v65_2_outputs;
    v65_2_outputs.reserve(v65_2_branches.size());
    for (const auto& v65_2_branch : v65_2_branches) {
      const Path v65_2_head{v65_2_branch.first};
      const Space& v65_2_tail = v65_2_branch.second;
      const Path v66_2 = concat_path(v64_20_head,v65_2_head);
      const auto v66_3_branches = branches(c,v65_2_tail);
      std::vector<Space> v66_3_outputs;
      v66_3_outputs.reserve(v66_3_branches.size());
      for (const auto& v66_3_branch : v66_3_branches) {
        const Path v66_3_head{v66_3_branch.first};
        const Space& v66_3_tail = v66_3_branch.second;
        const Path v67_2 = concat_path(v66_2,v66_3_head);
        const auto v67_3_branches = branches(c,v66_3_tail);
        std::vector<Space> v67_3_outputs;
        v67_3_outputs.reserve(v67_3_branches.size());
        for (const auto& v67_3_branch : v67_3_branches) {
          const Path v67_3_head{v67_3_branch.first};
          const Space& v67_3_tail = v67_3_branch.second;
          const Path v68_2 = concat_path(v67_2,v67_3_head);
          const Space v68_3 = routine_9(c, v68_2, v67_3_tail);
          v67_3_outputs.push_back(v68_3);
        }
        const Space v67_3 = join_outputs(std::move(v67_3_outputs));
        v66_3_outputs.push_back(v67_3);
      }
      const Space v66_3 = join_outputs(std::move(v66_3_outputs));
      v65_2_outputs.push_back(v66_3);
    }
    const Space v65_2 = join_outputs(std::move(v65_2_outputs));
    v64_20_outputs.push_back(v65_2);
  }
  const Space v64_20 = join_outputs(std::move(v64_20_outputs));
  Space v64_37;
  if (!v64_20.empty()) {
    const Path v69_21 = concat_path(p2,p3);
    const Path v69_22 = concat_path(v69_21,p4);
    const Path v69_23 = concat_path(v69_22,p5);
    const Path v69_24 = concat_path(v69_23,p6);
    const Path v69_25 = concat_path(v69_24,p7);
    const Path v69_26 = concat_path(v69_25,p8);
    const Path v69_27 = concat_path(v69_26,p9);
    const Path v69_28 = concat_path(v69_27,p10);
    const Path v69_29 = concat_path(v69_28,p11);
    const Path v69_30 = concat_path(v69_29,p12);
    const Path v69_31 = concat_path(v69_30,p13);
    const Path v69_32 = concat_path(v69_31,p14);
    const Path v69_33 = concat_path(v69_32,p15);
    const Path v69_34 = concat_path(v69_33,p0);
    const Space v69_35 = singleton(v69_34);
    const auto v69_36_branches = branches(c,v69_35);
    std::vector<Space> v69_36_outputs;
    v69_36_outputs.reserve(v69_36_branches.size());
    for (const auto& v69_36_branch : v69_36_branches) {
      const Path v69_36_head{v69_36_branch.first};
      const Space& v69_36_tail = v69_36_branch.second;
      const auto v70_2_branches = branches(c,v69_36_tail);
      std::vector<Space> v70_2_outputs;
      v70_2_outputs.reserve(v70_2_branches.size());
      for (const auto& v70_2_branch : v70_2_branches) {
        const Path v70_2_head{v70_2_branch.first};
        const Space& v70_2_tail = v70_2_branch.second;
        const Path v71_2 = concat_path(v69_36_head,v70_2_head);
        const auto v71_3_branches = branches(c,v70_2_tail);
        std::vector<Space> v71_3_outputs;
        v71_3_outputs.reserve(v71_3_branches.size());
        for (const auto& v71_3_branch : v71_3_branches) {
          const Path v71_3_head{v71_3_branch.first};
          const Space& v71_3_tail = v71_3_branch.second;
          const Path v72_2 = concat_path(v71_2,v71_3_head);
          const auto v72_3_branches = branches(c,v71_3_tail);
          std::vector<Space> v72_3_outputs;
          v72_3_outputs.reserve(v72_3_branches.size());
          for (const auto& v72_3_branch : v72_3_branches) {
            const Path v72_3_head{v72_3_branch.first};
            const Space& v72_3_tail = v72_3_branch.second;
            const Path v73_2 = concat_path(v72_2,v72_3_head);
            const Space v73_3 = routine_10(c, v73_2, v72_3_tail);
            v72_3_outputs.push_back(v73_3);
          }
          const Space v72_3 = join_outputs(std::move(v72_3_outputs));
          v71_3_outputs.push_back(v72_3);
        }
        const Space v71_3 = join_outputs(std::move(v71_3_outputs));
        v70_2_outputs.push_back(v71_3);
      }
      const Space v70_2 = join_outputs(std::move(v70_2_outputs));
      v69_36_outputs.push_back(v70_2);
    }
    const Space v69_36 = join_outputs(std::move(v69_36_outputs));
    v64_37 = compose(v64_20,v69_36);
  }
  const Space v64_39 = intersect(constant_51,v64_18);
  const auto v64_40_branches = branches(c,v64_39);
  std::vector<Space> v64_40_outputs;
  v64_40_outputs.reserve(v64_40_branches.size());
  for (const auto& v64_40_branch : v64_40_branches) {
    const Path v64_40_head{v64_40_branch.first};
    const Space& v64_40_tail = v64_40_branch.second;
    const auto v74_2_branches = branches(c,v64_40_tail);
    std::vector<Space> v74_2_outputs;
    v74_2_outputs.reserve(v74_2_branches.size());
    for (const auto& v74_2_branch : v74_2_branches) {
      const Path v74_2_head{v74_2_branch.first};
      const Space& v74_2_tail = v74_2_branch.second;
      const Path v75_2 = concat_path(v64_40_head,v74_2_head);
      const auto v75_3_branches = branches(c,v74_2_tail);
      std::vector<Space> v75_3_outputs;
      v75_3_outputs.reserve(v75_3_branches.size());
      for (const auto& v75_3_branch : v75_3_branches) {
        const Path v75_3_head{v75_3_branch.first};
        const Space& v75_3_tail = v75_3_branch.second;
        const Path v76_2 = concat_path(v75_2,v75_3_head);
        const auto v76_3_branches = branches(c,v75_3_tail);
        std::vector<Space> v76_3_outputs;
        v76_3_outputs.reserve(v76_3_branches.size());
        for (const auto& v76_3_branch : v76_3_branches) {
          const Path v76_3_head{v76_3_branch.first};
          const Space& v76_3_tail = v76_3_branch.second;
          const Path v77_2 = concat_path(v76_2,v76_3_head);
          const Space v77_3 = routine_11(c, v77_2, v76_3_tail);
          v76_3_outputs.push_back(v77_3);
        }
        const Space v76_3 = join_outputs(std::move(v76_3_outputs));
        v75_3_outputs.push_back(v76_3);
      }
      const Space v75_3 = join_outputs(std::move(v75_3_outputs));
      v74_2_outputs.push_back(v75_3);
    }
    const Space v74_2 = join_outputs(std::move(v74_2_outputs));
    v64_40_outputs.push_back(v74_2);
  }
  const Space v64_40 = join_outputs(std::move(v64_40_outputs));
  Space v64_42;
  if (!v64_40.empty()) {
    const Path v78_21 = concat_path(p2,p3);
    const Path v78_22 = concat_path(v78_21,p4);
    const Path v78_23 = concat_path(v78_22,p5);
    const Path v78_24 = concat_path(v78_23,p6);
    const Path v78_25 = concat_path(v78_24,p7);
    const Path v78_26 = concat_path(v78_25,p8);
    const Path v78_27 = concat_path(v78_26,p9);
    const Path v78_28 = concat_path(v78_27,p10);
    const Path v78_29 = concat_path(v78_28,p11);
    const Path v78_30 = concat_path(v78_29,p12);
    const Path v78_31 = concat_path(v78_30,p13);
    const Path v78_32 = concat_path(v78_31,p14);
    const Path v78_33 = concat_path(v78_32,p15);
    const Path v78_34 = concat_path(v78_33,p0);
    const Space v78_35 = singleton(v78_34);
    const auto v78_41_branches = branches(c,v78_35);
    std::vector<Space> v78_41_outputs;
    v78_41_outputs.reserve(v78_41_branches.size());
    for (const auto& v78_41_branch : v78_41_branches) {
      const Path v78_41_head{v78_41_branch.first};
      const Space& v78_41_tail = v78_41_branch.second;
      const auto v79_2_branches = branches(c,v78_41_tail);
      std::vector<Space> v79_2_outputs;
      v79_2_outputs.reserve(v79_2_branches.size());
      for (const auto& v79_2_branch : v79_2_branches) {
        const Path v79_2_head{v79_2_branch.first};
        const Space& v79_2_tail = v79_2_branch.second;
        const Path v80_2 = concat_path(v78_41_head,v79_2_head);
        const auto v80_3_branches = branches(c,v79_2_tail);
        std::vector<Space> v80_3_outputs;
        v80_3_outputs.reserve(v80_3_branches.size());
        for (const auto& v80_3_branch : v80_3_branches) {
          const Path v80_3_head{v80_3_branch.first};
          const Space& v80_3_tail = v80_3_branch.second;
          const Path v81_2 = concat_path(v80_2,v80_3_head);
          const auto v81_3_branches = branches(c,v80_3_tail);
          std::vector<Space> v81_3_outputs;
          v81_3_outputs.reserve(v81_3_branches.size());
          for (const auto& v81_3_branch : v81_3_branches) {
            const Path v81_3_head{v81_3_branch.first};
            const Space& v81_3_tail = v81_3_branch.second;
            const Path v82_2 = concat_path(v81_2,v81_3_head);
            const Space v82_3 = routine_12(c, v82_2, v81_3_tail);
            v81_3_outputs.push_back(v82_3);
          }
          const Space v81_3 = join_outputs(std::move(v81_3_outputs));
          v80_3_outputs.push_back(v81_3);
        }
        const Space v80_3 = join_outputs(std::move(v80_3_outputs));
        v79_2_outputs.push_back(v80_3);
      }
      const Space v79_2 = join_outputs(std::move(v79_2_outputs));
      v78_41_outputs.push_back(v79_2);
    }
    const Space v78_41 = join_outputs(std::move(v78_41_outputs));
    v64_42 = compose(v64_40,v78_41);
  }
  const Space v64_43 = unite(v64_37,v64_42);
  const Space v64_45 = intersect(constant_52,v64_18);
  const auto v64_46_branches = branches(c,v64_45);
  std::vector<Space> v64_46_outputs;
  v64_46_outputs.reserve(v64_46_branches.size());
  for (const auto& v64_46_branch : v64_46_branches) {
    const Path v64_46_head{v64_46_branch.first};
    const Space& v64_46_tail = v64_46_branch.second;
    const auto v83_2_branches = branches(c,v64_46_tail);
    std::vector<Space> v83_2_outputs;
    v83_2_outputs.reserve(v83_2_branches.size());
    for (const auto& v83_2_branch : v83_2_branches) {
      const Path v83_2_head{v83_2_branch.first};
      const Space& v83_2_tail = v83_2_branch.second;
      const Path v84_2 = concat_path(v64_46_head,v83_2_head);
      const auto v84_3_branches = branches(c,v83_2_tail);
      std::vector<Space> v84_3_outputs;
      v84_3_outputs.reserve(v84_3_branches.size());
      for (const auto& v84_3_branch : v84_3_branches) {
        const Path v84_3_head{v84_3_branch.first};
        const Space& v84_3_tail = v84_3_branch.second;
        const Path v85_2 = concat_path(v84_2,v84_3_head);
        const auto v85_3_branches = branches(c,v84_3_tail);
        std::vector<Space> v85_3_outputs;
        v85_3_outputs.reserve(v85_3_branches.size());
        for (const auto& v85_3_branch : v85_3_branches) {
          const Path v85_3_head{v85_3_branch.first};
          const Space& v85_3_tail = v85_3_branch.second;
          const Path v86_2 = concat_path(v85_2,v85_3_head);
          const Space v86_3 = routine_13(c, v86_2, v85_3_tail);
          v85_3_outputs.push_back(v86_3);
        }
        const Space v85_3 = join_outputs(std::move(v85_3_outputs));
        v84_3_outputs.push_back(v85_3);
      }
      const Space v84_3 = join_outputs(std::move(v84_3_outputs));
      v83_2_outputs.push_back(v84_3);
    }
    const Space v83_2 = join_outputs(std::move(v83_2_outputs));
    v64_46_outputs.push_back(v83_2);
  }
  const Space v64_46 = join_outputs(std::move(v64_46_outputs));
  Space v64_48;
  if (!v64_46.empty()) {
    const Path v87_21 = concat_path(p2,p3);
    const Path v87_22 = concat_path(v87_21,p4);
    const Path v87_23 = concat_path(v87_22,p5);
    const Path v87_24 = concat_path(v87_23,p6);
    const Path v87_25 = concat_path(v87_24,p7);
    const Path v87_26 = concat_path(v87_25,p8);
    const Path v87_27 = concat_path(v87_26,p9);
    const Path v87_28 = concat_path(v87_27,p10);
    const Path v87_29 = concat_path(v87_28,p11);
    const Path v87_30 = concat_path(v87_29,p12);
    const Path v87_31 = concat_path(v87_30,p13);
    const Path v87_32 = concat_path(v87_31,p14);
    const Path v87_33 = concat_path(v87_32,p15);
    const Path v87_34 = concat_path(v87_33,p0);
    const Space v87_35 = singleton(v87_34);
    const auto v87_47_branches = branches(c,v87_35);
    std::vector<Space> v87_47_outputs;
    v87_47_outputs.reserve(v87_47_branches.size());
    for (const auto& v87_47_branch : v87_47_branches) {
      const Path v87_47_head{v87_47_branch.first};
      const Space& v87_47_tail = v87_47_branch.second;
      const auto v88_2_branches = branches(c,v87_47_tail);
      std::vector<Space> v88_2_outputs;
      v88_2_outputs.reserve(v88_2_branches.size());
      for (const auto& v88_2_branch : v88_2_branches) {
        const Path v88_2_head{v88_2_branch.first};
        const Space& v88_2_tail = v88_2_branch.second;
        const Path v89_2 = concat_path(v87_47_head,v88_2_head);
        const auto v89_3_branches = branches(c,v88_2_tail);
        std::vector<Space> v89_3_outputs;
        v89_3_outputs.reserve(v89_3_branches.size());
        for (const auto& v89_3_branch : v89_3_branches) {
          const Path v89_3_head{v89_3_branch.first};
          const Space& v89_3_tail = v89_3_branch.second;
          const Path v90_2 = concat_path(v89_2,v89_3_head);
          const auto v90_3_branches = branches(c,v89_3_tail);
          std::vector<Space> v90_3_outputs;
          v90_3_outputs.reserve(v90_3_branches.size());
          for (const auto& v90_3_branch : v90_3_branches) {
            const Path v90_3_head{v90_3_branch.first};
            const Space& v90_3_tail = v90_3_branch.second;
            const Path v91_2 = concat_path(v90_2,v90_3_head);
            const Space v91_3 = routine_14(c, v91_2, v90_3_tail);
            v90_3_outputs.push_back(v91_3);
          }
          const Space v90_3 = join_outputs(std::move(v90_3_outputs));
          v89_3_outputs.push_back(v90_3);
        }
        const Space v89_3 = join_outputs(std::move(v89_3_outputs));
        v88_2_outputs.push_back(v89_3);
      }
      const Space v88_2 = join_outputs(std::move(v88_2_outputs));
      v87_47_outputs.push_back(v88_2);
    }
    const Space v87_47 = join_outputs(std::move(v87_47_outputs));
    v64_48 = compose(v64_46,v87_47);
  }
  const Space v64_49 = unite(v64_43,v64_48);
  const Space v64_51 = intersect(constant_53,v64_18);
  const auto v64_52_branches = branches(c,v64_51);
  std::vector<Space> v64_52_outputs;
  v64_52_outputs.reserve(v64_52_branches.size());
  for (const auto& v64_52_branch : v64_52_branches) {
    const Path v64_52_head{v64_52_branch.first};
    const Space& v64_52_tail = v64_52_branch.second;
    const auto v92_2_branches = branches(c,v64_52_tail);
    std::vector<Space> v92_2_outputs;
    v92_2_outputs.reserve(v92_2_branches.size());
    for (const auto& v92_2_branch : v92_2_branches) {
      const Path v92_2_head{v92_2_branch.first};
      const Space& v92_2_tail = v92_2_branch.second;
      const Path v93_2 = concat_path(v64_52_head,v92_2_head);
      const auto v93_3_branches = branches(c,v92_2_tail);
      std::vector<Space> v93_3_outputs;
      v93_3_outputs.reserve(v93_3_branches.size());
      for (const auto& v93_3_branch : v93_3_branches) {
        const Path v93_3_head{v93_3_branch.first};
        const Space& v93_3_tail = v93_3_branch.second;
        const Path v94_2 = concat_path(v93_2,v93_3_head);
        const auto v94_3_branches = branches(c,v93_3_tail);
        std::vector<Space> v94_3_outputs;
        v94_3_outputs.reserve(v94_3_branches.size());
        for (const auto& v94_3_branch : v94_3_branches) {
          const Path v94_3_head{v94_3_branch.first};
          const Space& v94_3_tail = v94_3_branch.second;
          const Path v95_2 = concat_path(v94_2,v94_3_head);
          const Space v95_3 = routine_15(c, v95_2, v94_3_tail);
          v94_3_outputs.push_back(v95_3);
        }
        const Space v94_3 = join_outputs(std::move(v94_3_outputs));
        v93_3_outputs.push_back(v94_3);
      }
      const Space v93_3 = join_outputs(std::move(v93_3_outputs));
      v92_2_outputs.push_back(v93_3);
    }
    const Space v92_2 = join_outputs(std::move(v92_2_outputs));
    v64_52_outputs.push_back(v92_2);
  }
  const Space v64_52 = join_outputs(std::move(v64_52_outputs));
  Space v64_54;
  if (!v64_52.empty()) {
    const Path v96_21 = concat_path(p2,p3);
    const Path v96_22 = concat_path(v96_21,p4);
    const Path v96_23 = concat_path(v96_22,p5);
    const Path v96_24 = concat_path(v96_23,p6);
    const Path v96_25 = concat_path(v96_24,p7);
    const Path v96_26 = concat_path(v96_25,p8);
    const Path v96_27 = concat_path(v96_26,p9);
    const Path v96_28 = concat_path(v96_27,p10);
    const Path v96_29 = concat_path(v96_28,p11);
    const Path v96_30 = concat_path(v96_29,p12);
    const Path v96_31 = concat_path(v96_30,p13);
    const Path v96_32 = concat_path(v96_31,p14);
    const Path v96_33 = concat_path(v96_32,p15);
    const Path v96_34 = concat_path(v96_33,p0);
    const Space v96_35 = singleton(v96_34);
    const auto v96_53_branches = branches(c,v96_35);
    std::vector<Space> v96_53_outputs;
    v96_53_outputs.reserve(v96_53_branches.size());
    for (const auto& v96_53_branch : v96_53_branches) {
      const Path v96_53_head{v96_53_branch.first};
      const Space& v96_53_tail = v96_53_branch.second;
      const auto v97_2_branches = branches(c,v96_53_tail);
      std::vector<Space> v97_2_outputs;
      v97_2_outputs.reserve(v97_2_branches.size());
      for (const auto& v97_2_branch : v97_2_branches) {
        const Path v97_2_head{v97_2_branch.first};
        const Space& v97_2_tail = v97_2_branch.second;
        const Path v98_2 = concat_path(v96_53_head,v97_2_head);
        const auto v98_3_branches = branches(c,v97_2_tail);
        std::vector<Space> v98_3_outputs;
        v98_3_outputs.reserve(v98_3_branches.size());
        for (const auto& v98_3_branch : v98_3_branches) {
          const Path v98_3_head{v98_3_branch.first};
          const Space& v98_3_tail = v98_3_branch.second;
          const Path v99_2 = concat_path(v98_2,v98_3_head);
          const auto v99_3_branches = branches(c,v98_3_tail);
          std::vector<Space> v99_3_outputs;
          v99_3_outputs.reserve(v99_3_branches.size());
          for (const auto& v99_3_branch : v99_3_branches) {
            const Path v99_3_head{v99_3_branch.first};
            const Space& v99_3_tail = v99_3_branch.second;
            const Path v100_2 = concat_path(v99_2,v99_3_head);
            const Space v100_3 = routine_16(c, v100_2, v99_3_tail);
            v99_3_outputs.push_back(v100_3);
          }
          const Space v99_3 = join_outputs(std::move(v99_3_outputs));
          v98_3_outputs.push_back(v99_3);
        }
        const Space v98_3 = join_outputs(std::move(v98_3_outputs));
        v97_2_outputs.push_back(v98_3);
      }
      const Space v97_2 = join_outputs(std::move(v97_2_outputs));
      v96_53_outputs.push_back(v97_2);
    }
    const Space v96_53 = join_outputs(std::move(v96_53_outputs));
    v64_54 = compose(v64_52,v96_53);
  }
  const Space v64_55 = unite(v64_49,v64_54);
  const Space v64_57 = intersect(constant_54,v64_18);
  const auto v64_58_branches = branches(c,v64_57);
  std::vector<Space> v64_58_outputs;
  v64_58_outputs.reserve(v64_58_branches.size());
  for (const auto& v64_58_branch : v64_58_branches) {
    const Path v64_58_head{v64_58_branch.first};
    const Space& v64_58_tail = v64_58_branch.second;
    const auto v101_2_branches = branches(c,v64_58_tail);
    std::vector<Space> v101_2_outputs;
    v101_2_outputs.reserve(v101_2_branches.size());
    for (const auto& v101_2_branch : v101_2_branches) {
      const Path v101_2_head{v101_2_branch.first};
      const Space& v101_2_tail = v101_2_branch.second;
      const Path v102_2 = concat_path(v64_58_head,v101_2_head);
      const auto v102_3_branches = branches(c,v101_2_tail);
      std::vector<Space> v102_3_outputs;
      v102_3_outputs.reserve(v102_3_branches.size());
      for (const auto& v102_3_branch : v102_3_branches) {
        const Path v102_3_head{v102_3_branch.first};
        const Space& v102_3_tail = v102_3_branch.second;
        const Path v103_2 = concat_path(v102_2,v102_3_head);
        const auto v103_3_branches = branches(c,v102_3_tail);
        std::vector<Space> v103_3_outputs;
        v103_3_outputs.reserve(v103_3_branches.size());
        for (const auto& v103_3_branch : v103_3_branches) {
          const Path v103_3_head{v103_3_branch.first};
          const Space& v103_3_tail = v103_3_branch.second;
          const Path v104_2 = concat_path(v103_2,v103_3_head);
          const Space v104_3 = routine_17(c, v104_2, v103_3_tail);
          v103_3_outputs.push_back(v104_3);
        }
        const Space v103_3 = join_outputs(std::move(v103_3_outputs));
        v102_3_outputs.push_back(v103_3);
      }
      const Space v102_3 = join_outputs(std::move(v102_3_outputs));
      v101_2_outputs.push_back(v102_3);
    }
    const Space v101_2 = join_outputs(std::move(v101_2_outputs));
    v64_58_outputs.push_back(v101_2);
  }
  const Space v64_58 = join_outputs(std::move(v64_58_outputs));
  Space v64_60;
  if (!v64_58.empty()) {
    const Path v105_21 = concat_path(p2,p3);
    const Path v105_22 = concat_path(v105_21,p4);
    const Path v105_23 = concat_path(v105_22,p5);
    const Path v105_24 = concat_path(v105_23,p6);
    const Path v105_25 = concat_path(v105_24,p7);
    const Path v105_26 = concat_path(v105_25,p8);
    const Path v105_27 = concat_path(v105_26,p9);
    const Path v105_28 = concat_path(v105_27,p10);
    const Path v105_29 = concat_path(v105_28,p11);
    const Path v105_30 = concat_path(v105_29,p12);
    const Path v105_31 = concat_path(v105_30,p13);
    const Path v105_32 = concat_path(v105_31,p14);
    const Path v105_33 = concat_path(v105_32,p15);
    const Path v105_34 = concat_path(v105_33,p0);
    const Space v105_35 = singleton(v105_34);
    const auto v105_59_branches = branches(c,v105_35);
    std::vector<Space> v105_59_outputs;
    v105_59_outputs.reserve(v105_59_branches.size());
    for (const auto& v105_59_branch : v105_59_branches) {
      const Path v105_59_head{v105_59_branch.first};
      const Space& v105_59_tail = v105_59_branch.second;
      const auto v106_2_branches = branches(c,v105_59_tail);
      std::vector<Space> v106_2_outputs;
      v106_2_outputs.reserve(v106_2_branches.size());
      for (const auto& v106_2_branch : v106_2_branches) {
        const Path v106_2_head{v106_2_branch.first};
        const Space& v106_2_tail = v106_2_branch.second;
        const Path v107_2 = concat_path(v105_59_head,v106_2_head);
        const auto v107_3_branches = branches(c,v106_2_tail);
        std::vector<Space> v107_3_outputs;
        v107_3_outputs.reserve(v107_3_branches.size());
        for (const auto& v107_3_branch : v107_3_branches) {
          const Path v107_3_head{v107_3_branch.first};
          const Space& v107_3_tail = v107_3_branch.second;
          const Path v108_2 = concat_path(v107_2,v107_3_head);
          const auto v108_3_branches = branches(c,v107_3_tail);
          std::vector<Space> v108_3_outputs;
          v108_3_outputs.reserve(v108_3_branches.size());
          for (const auto& v108_3_branch : v108_3_branches) {
            const Path v108_3_head{v108_3_branch.first};
            const Space& v108_3_tail = v108_3_branch.second;
            const Path v109_2 = concat_path(v108_2,v108_3_head);
            const Space v109_3 = routine_18(c, v109_2, v108_3_tail);
            v108_3_outputs.push_back(v109_3);
          }
          const Space v108_3 = join_outputs(std::move(v108_3_outputs));
          v107_3_outputs.push_back(v108_3);
        }
        const Space v107_3 = join_outputs(std::move(v107_3_outputs));
        v106_2_outputs.push_back(v107_3);
      }
      const Space v106_2 = join_outputs(std::move(v106_2_outputs));
      v105_59_outputs.push_back(v106_2);
    }
    const Space v105_59 = join_outputs(std::move(v105_59_outputs));
    v64_60 = compose(v64_58,v105_59);
  }
  const Space v64_61 = unite(v64_55,v64_60);
  const Space v64_63 = intersect(constant_55,v64_18);
  const auto v64_64_branches = branches(c,v64_63);
  std::vector<Space> v64_64_outputs;
  v64_64_outputs.reserve(v64_64_branches.size());
  for (const auto& v64_64_branch : v64_64_branches) {
    const Path v64_64_head{v64_64_branch.first};
    const Space& v64_64_tail = v64_64_branch.second;
    const auto v110_2_branches = branches(c,v64_64_tail);
    std::vector<Space> v110_2_outputs;
    v110_2_outputs.reserve(v110_2_branches.size());
    for (const auto& v110_2_branch : v110_2_branches) {
      const Path v110_2_head{v110_2_branch.first};
      const Space& v110_2_tail = v110_2_branch.second;
      const Path v111_2 = concat_path(v64_64_head,v110_2_head);
      const auto v111_3_branches = branches(c,v110_2_tail);
      std::vector<Space> v111_3_outputs;
      v111_3_outputs.reserve(v111_3_branches.size());
      for (const auto& v111_3_branch : v111_3_branches) {
        const Path v111_3_head{v111_3_branch.first};
        const Space& v111_3_tail = v111_3_branch.second;
        const Path v112_2 = concat_path(v111_2,v111_3_head);
        const auto v112_3_branches = branches(c,v111_3_tail);
        std::vector<Space> v112_3_outputs;
        v112_3_outputs.reserve(v112_3_branches.size());
        for (const auto& v112_3_branch : v112_3_branches) {
          const Path v112_3_head{v112_3_branch.first};
          const Space& v112_3_tail = v112_3_branch.second;
          const Path v113_2 = concat_path(v112_2,v112_3_head);
          const Space v113_3 = routine_19(c, v113_2, v112_3_tail);
          v112_3_outputs.push_back(v113_3);
        }
        const Space v112_3 = join_outputs(std::move(v112_3_outputs));
        v111_3_outputs.push_back(v112_3);
      }
      const Space v111_3 = join_outputs(std::move(v111_3_outputs));
      v110_2_outputs.push_back(v111_3);
    }
    const Space v110_2 = join_outputs(std::move(v110_2_outputs));
    v64_64_outputs.push_back(v110_2);
  }
  const Space v64_64 = join_outputs(std::move(v64_64_outputs));
  Space v64_66;
  if (!v64_64.empty()) {
    const Path v114_21 = concat_path(p2,p3);
    const Path v114_22 = concat_path(v114_21,p4);
    const Path v114_23 = concat_path(v114_22,p5);
    const Path v114_24 = concat_path(v114_23,p6);
    const Path v114_25 = concat_path(v114_24,p7);
    const Path v114_26 = concat_path(v114_25,p8);
    const Path v114_27 = concat_path(v114_26,p9);
    const Path v114_28 = concat_path(v114_27,p10);
    const Path v114_29 = concat_path(v114_28,p11);
    const Path v114_30 = concat_path(v114_29,p12);
    const Path v114_31 = concat_path(v114_30,p13);
    const Path v114_32 = concat_path(v114_31,p14);
    const Path v114_33 = concat_path(v114_32,p15);
    const Path v114_34 = concat_path(v114_33,p0);
    const Space v114_35 = singleton(v114_34);
    const auto v114_65_branches = branches(c,v114_35);
    std::vector<Space> v114_65_outputs;
    v114_65_outputs.reserve(v114_65_branches.size());
    for (const auto& v114_65_branch : v114_65_branches) {
      const Path v114_65_head{v114_65_branch.first};
      const Space& v114_65_tail = v114_65_branch.second;
      const auto v115_2_branches = branches(c,v114_65_tail);
      std::vector<Space> v115_2_outputs;
      v115_2_outputs.reserve(v115_2_branches.size());
      for (const auto& v115_2_branch : v115_2_branches) {
        const Path v115_2_head{v115_2_branch.first};
        const Space& v115_2_tail = v115_2_branch.second;
        const Path v116_2 = concat_path(v114_65_head,v115_2_head);
        const auto v116_3_branches = branches(c,v115_2_tail);
        std::vector<Space> v116_3_outputs;
        v116_3_outputs.reserve(v116_3_branches.size());
        for (const auto& v116_3_branch : v116_3_branches) {
          const Path v116_3_head{v116_3_branch.first};
          const Space& v116_3_tail = v116_3_branch.second;
          const Path v117_2 = concat_path(v116_2,v116_3_head);
          const auto v117_3_branches = branches(c,v116_3_tail);
          std::vector<Space> v117_3_outputs;
          v117_3_outputs.reserve(v117_3_branches.size());
          for (const auto& v117_3_branch : v117_3_branches) {
            const Path v117_3_head{v117_3_branch.first};
            const Space& v117_3_tail = v117_3_branch.second;
            const Path v118_2 = concat_path(v117_2,v117_3_head);
            const Space v118_3 = routine_20(c, v118_2, v117_3_tail);
            v117_3_outputs.push_back(v118_3);
          }
          const Space v117_3 = join_outputs(std::move(v117_3_outputs));
          v116_3_outputs.push_back(v117_3);
        }
        const Space v116_3 = join_outputs(std::move(v116_3_outputs));
        v115_2_outputs.push_back(v116_3);
      }
      const Space v115_2 = join_outputs(std::move(v115_2_outputs));
      v114_65_outputs.push_back(v115_2);
    }
    const Space v114_65 = join_outputs(std::move(v114_65_outputs));
    v64_66 = compose(v64_64,v114_65);
  }
  const Space v64_67 = unite(v64_61,v64_66);
  const Space v64_69 = intersect(constant_56,v64_18);
  const auto v64_70_branches = branches(c,v64_69);
  std::vector<Space> v64_70_outputs;
  v64_70_outputs.reserve(v64_70_branches.size());
  for (const auto& v64_70_branch : v64_70_branches) {
    const Path v64_70_head{v64_70_branch.first};
    const Space& v64_70_tail = v64_70_branch.second;
    const auto v119_2_branches = branches(c,v64_70_tail);
    std::vector<Space> v119_2_outputs;
    v119_2_outputs.reserve(v119_2_branches.size());
    for (const auto& v119_2_branch : v119_2_branches) {
      const Path v119_2_head{v119_2_branch.first};
      const Space& v119_2_tail = v119_2_branch.second;
      const Path v120_2 = concat_path(v64_70_head,v119_2_head);
      const auto v120_3_branches = branches(c,v119_2_tail);
      std::vector<Space> v120_3_outputs;
      v120_3_outputs.reserve(v120_3_branches.size());
      for (const auto& v120_3_branch : v120_3_branches) {
        const Path v120_3_head{v120_3_branch.first};
        const Space& v120_3_tail = v120_3_branch.second;
        const Path v121_2 = concat_path(v120_2,v120_3_head);
        const auto v121_3_branches = branches(c,v120_3_tail);
        std::vector<Space> v121_3_outputs;
        v121_3_outputs.reserve(v121_3_branches.size());
        for (const auto& v121_3_branch : v121_3_branches) {
          const Path v121_3_head{v121_3_branch.first};
          const Space& v121_3_tail = v121_3_branch.second;
          const Path v122_2 = concat_path(v121_2,v121_3_head);
          const Space v122_3 = routine_21(c, v122_2, v121_3_tail);
          v121_3_outputs.push_back(v122_3);
        }
        const Space v121_3 = join_outputs(std::move(v121_3_outputs));
        v120_3_outputs.push_back(v121_3);
      }
      const Space v120_3 = join_outputs(std::move(v120_3_outputs));
      v119_2_outputs.push_back(v120_3);
    }
    const Space v119_2 = join_outputs(std::move(v119_2_outputs));
    v64_70_outputs.push_back(v119_2);
  }
  const Space v64_70 = join_outputs(std::move(v64_70_outputs));
  Space v64_72;
  if (!v64_70.empty()) {
    const Path v123_21 = concat_path(p2,p3);
    const Path v123_22 = concat_path(v123_21,p4);
    const Path v123_23 = concat_path(v123_22,p5);
    const Path v123_24 = concat_path(v123_23,p6);
    const Path v123_25 = concat_path(v123_24,p7);
    const Path v123_26 = concat_path(v123_25,p8);
    const Path v123_27 = concat_path(v123_26,p9);
    const Path v123_28 = concat_path(v123_27,p10);
    const Path v123_29 = concat_path(v123_28,p11);
    const Path v123_30 = concat_path(v123_29,p12);
    const Path v123_31 = concat_path(v123_30,p13);
    const Path v123_32 = concat_path(v123_31,p14);
    const Path v123_33 = concat_path(v123_32,p15);
    const Path v123_34 = concat_path(v123_33,p0);
    const Space v123_35 = singleton(v123_34);
    const auto v123_71_branches = branches(c,v123_35);
    std::vector<Space> v123_71_outputs;
    v123_71_outputs.reserve(v123_71_branches.size());
    for (const auto& v123_71_branch : v123_71_branches) {
      const Path v123_71_head{v123_71_branch.first};
      const Space& v123_71_tail = v123_71_branch.second;
      const auto v124_2_branches = branches(c,v123_71_tail);
      std::vector<Space> v124_2_outputs;
      v124_2_outputs.reserve(v124_2_branches.size());
      for (const auto& v124_2_branch : v124_2_branches) {
        const Path v124_2_head{v124_2_branch.first};
        const Space& v124_2_tail = v124_2_branch.second;
        const Path v125_2 = concat_path(v123_71_head,v124_2_head);
        const auto v125_3_branches = branches(c,v124_2_tail);
        std::vector<Space> v125_3_outputs;
        v125_3_outputs.reserve(v125_3_branches.size());
        for (const auto& v125_3_branch : v125_3_branches) {
          const Path v125_3_head{v125_3_branch.first};
          const Space& v125_3_tail = v125_3_branch.second;
          const Path v126_2 = concat_path(v125_2,v125_3_head);
          const auto v126_3_branches = branches(c,v125_3_tail);
          std::vector<Space> v126_3_outputs;
          v126_3_outputs.reserve(v126_3_branches.size());
          for (const auto& v126_3_branch : v126_3_branches) {
            const Path v126_3_head{v126_3_branch.first};
            const Space& v126_3_tail = v126_3_branch.second;
            const Path v127_2 = concat_path(v126_2,v126_3_head);
            const Space v127_3 = routine_22(c, v127_2, v126_3_tail);
            v126_3_outputs.push_back(v127_3);
          }
          const Space v126_3 = join_outputs(std::move(v126_3_outputs));
          v125_3_outputs.push_back(v126_3);
        }
        const Space v125_3 = join_outputs(std::move(v125_3_outputs));
        v124_2_outputs.push_back(v125_3);
      }
      const Space v124_2 = join_outputs(std::move(v124_2_outputs));
      v123_71_outputs.push_back(v124_2);
    }
    const Space v123_71 = join_outputs(std::move(v123_71_outputs));
    v64_72 = compose(v64_70,v123_71);
  }
  const Space v64_73 = unite(v64_67,v64_72);
  const Space v64_75 = intersect(constant_57,v64_18);
  const auto v64_76_branches = branches(c,v64_75);
  std::vector<Space> v64_76_outputs;
  v64_76_outputs.reserve(v64_76_branches.size());
  for (const auto& v64_76_branch : v64_76_branches) {
    const Path v64_76_head{v64_76_branch.first};
    const Space& v64_76_tail = v64_76_branch.second;
    const auto v128_2_branches = branches(c,v64_76_tail);
    std::vector<Space> v128_2_outputs;
    v128_2_outputs.reserve(v128_2_branches.size());
    for (const auto& v128_2_branch : v128_2_branches) {
      const Path v128_2_head{v128_2_branch.first};
      const Space& v128_2_tail = v128_2_branch.second;
      const Path v129_2 = concat_path(v64_76_head,v128_2_head);
      const auto v129_3_branches = branches(c,v128_2_tail);
      std::vector<Space> v129_3_outputs;
      v129_3_outputs.reserve(v129_3_branches.size());
      for (const auto& v129_3_branch : v129_3_branches) {
        const Path v129_3_head{v129_3_branch.first};
        const Space& v129_3_tail = v129_3_branch.second;
        const Path v130_2 = concat_path(v129_2,v129_3_head);
        const auto v130_3_branches = branches(c,v129_3_tail);
        std::vector<Space> v130_3_outputs;
        v130_3_outputs.reserve(v130_3_branches.size());
        for (const auto& v130_3_branch : v130_3_branches) {
          const Path v130_3_head{v130_3_branch.first};
          const Space& v130_3_tail = v130_3_branch.second;
          const Path v131_2 = concat_path(v130_2,v130_3_head);
          const Space v131_3 = routine_23(c, v131_2, v130_3_tail);
          v130_3_outputs.push_back(v131_3);
        }
        const Space v130_3 = join_outputs(std::move(v130_3_outputs));
        v129_3_outputs.push_back(v130_3);
      }
      const Space v129_3 = join_outputs(std::move(v129_3_outputs));
      v128_2_outputs.push_back(v129_3);
    }
    const Space v128_2 = join_outputs(std::move(v128_2_outputs));
    v64_76_outputs.push_back(v128_2);
  }
  const Space v64_76 = join_outputs(std::move(v64_76_outputs));
  Space v64_78;
  if (!v64_76.empty()) {
    const Path v132_21 = concat_path(p2,p3);
    const Path v132_22 = concat_path(v132_21,p4);
    const Path v132_23 = concat_path(v132_22,p5);
    const Path v132_24 = concat_path(v132_23,p6);
    const Path v132_25 = concat_path(v132_24,p7);
    const Path v132_26 = concat_path(v132_25,p8);
    const Path v132_27 = concat_path(v132_26,p9);
    const Path v132_28 = concat_path(v132_27,p10);
    const Path v132_29 = concat_path(v132_28,p11);
    const Path v132_30 = concat_path(v132_29,p12);
    const Path v132_31 = concat_path(v132_30,p13);
    const Path v132_32 = concat_path(v132_31,p14);
    const Path v132_33 = concat_path(v132_32,p15);
    const Path v132_34 = concat_path(v132_33,p0);
    const Space v132_35 = singleton(v132_34);
    const auto v132_77_branches = branches(c,v132_35);
    std::vector<Space> v132_77_outputs;
    v132_77_outputs.reserve(v132_77_branches.size());
    for (const auto& v132_77_branch : v132_77_branches) {
      const Path v132_77_head{v132_77_branch.first};
      const Space& v132_77_tail = v132_77_branch.second;
      const auto v133_2_branches = branches(c,v132_77_tail);
      std::vector<Space> v133_2_outputs;
      v133_2_outputs.reserve(v133_2_branches.size());
      for (const auto& v133_2_branch : v133_2_branches) {
        const Path v133_2_head{v133_2_branch.first};
        const Space& v133_2_tail = v133_2_branch.second;
        const Path v134_2 = concat_path(v132_77_head,v133_2_head);
        const auto v134_3_branches = branches(c,v133_2_tail);
        std::vector<Space> v134_3_outputs;
        v134_3_outputs.reserve(v134_3_branches.size());
        for (const auto& v134_3_branch : v134_3_branches) {
          const Path v134_3_head{v134_3_branch.first};
          const Space& v134_3_tail = v134_3_branch.second;
          const Path v135_2 = concat_path(v134_2,v134_3_head);
          const auto v135_3_branches = branches(c,v134_3_tail);
          std::vector<Space> v135_3_outputs;
          v135_3_outputs.reserve(v135_3_branches.size());
          for (const auto& v135_3_branch : v135_3_branches) {
            const Path v135_3_head{v135_3_branch.first};
            const Space& v135_3_tail = v135_3_branch.second;
            const Path v136_2 = concat_path(v135_2,v135_3_head);
            const Space v136_3 = routine_24(c, v136_2, v135_3_tail);
            v135_3_outputs.push_back(v136_3);
          }
          const Space v135_3 = join_outputs(std::move(v135_3_outputs));
          v134_3_outputs.push_back(v135_3);
        }
        const Space v134_3 = join_outputs(std::move(v134_3_outputs));
        v133_2_outputs.push_back(v134_3);
      }
      const Space v133_2 = join_outputs(std::move(v133_2_outputs));
      v132_77_outputs.push_back(v133_2);
    }
    const Space v132_77 = join_outputs(std::move(v132_77_outputs));
    v64_78 = compose(v64_76,v132_77);
  }
  const Space v64_79 = unite(v64_73,v64_78);
  const Space v64_81 = intersect(constant_58,v64_18);
  const auto v64_82_branches = branches(c,v64_81);
  std::vector<Space> v64_82_outputs;
  v64_82_outputs.reserve(v64_82_branches.size());
  for (const auto& v64_82_branch : v64_82_branches) {
    const Path v64_82_head{v64_82_branch.first};
    const Space& v64_82_tail = v64_82_branch.second;
    const auto v137_2_branches = branches(c,v64_82_tail);
    std::vector<Space> v137_2_outputs;
    v137_2_outputs.reserve(v137_2_branches.size());
    for (const auto& v137_2_branch : v137_2_branches) {
      const Path v137_2_head{v137_2_branch.first};
      const Space& v137_2_tail = v137_2_branch.second;
      const Path v138_2 = concat_path(v64_82_head,v137_2_head);
      const auto v138_3_branches = branches(c,v137_2_tail);
      std::vector<Space> v138_3_outputs;
      v138_3_outputs.reserve(v138_3_branches.size());
      for (const auto& v138_3_branch : v138_3_branches) {
        const Path v138_3_head{v138_3_branch.first};
        const Space& v138_3_tail = v138_3_branch.second;
        const Path v139_2 = concat_path(v138_2,v138_3_head);
        const auto v139_3_branches = branches(c,v138_3_tail);
        std::vector<Space> v139_3_outputs;
        v139_3_outputs.reserve(v139_3_branches.size());
        for (const auto& v139_3_branch : v139_3_branches) {
          const Path v139_3_head{v139_3_branch.first};
          const Space& v139_3_tail = v139_3_branch.second;
          const Path v140_2 = concat_path(v139_2,v139_3_head);
          const Space v140_3 = routine_25(c, v140_2, v139_3_tail);
          v139_3_outputs.push_back(v140_3);
        }
        const Space v139_3 = join_outputs(std::move(v139_3_outputs));
        v138_3_outputs.push_back(v139_3);
      }
      const Space v138_3 = join_outputs(std::move(v138_3_outputs));
      v137_2_outputs.push_back(v138_3);
    }
    const Space v137_2 = join_outputs(std::move(v137_2_outputs));
    v64_82_outputs.push_back(v137_2);
  }
  const Space v64_82 = join_outputs(std::move(v64_82_outputs));
  Space v64_84;
  if (!v64_82.empty()) {
    const Path v141_21 = concat_path(p2,p3);
    const Path v141_22 = concat_path(v141_21,p4);
    const Path v141_23 = concat_path(v141_22,p5);
    const Path v141_24 = concat_path(v141_23,p6);
    const Path v141_25 = concat_path(v141_24,p7);
    const Path v141_26 = concat_path(v141_25,p8);
    const Path v141_27 = concat_path(v141_26,p9);
    const Path v141_28 = concat_path(v141_27,p10);
    const Path v141_29 = concat_path(v141_28,p11);
    const Path v141_30 = concat_path(v141_29,p12);
    const Path v141_31 = concat_path(v141_30,p13);
    const Path v141_32 = concat_path(v141_31,p14);
    const Path v141_33 = concat_path(v141_32,p15);
    const Path v141_34 = concat_path(v141_33,p0);
    const Space v141_35 = singleton(v141_34);
    const auto v141_83_branches = branches(c,v141_35);
    std::vector<Space> v141_83_outputs;
    v141_83_outputs.reserve(v141_83_branches.size());
    for (const auto& v141_83_branch : v141_83_branches) {
      const Path v141_83_head{v141_83_branch.first};
      const Space& v141_83_tail = v141_83_branch.second;
      const auto v142_2_branches = branches(c,v141_83_tail);
      std::vector<Space> v142_2_outputs;
      v142_2_outputs.reserve(v142_2_branches.size());
      for (const auto& v142_2_branch : v142_2_branches) {
        const Path v142_2_head{v142_2_branch.first};
        const Space& v142_2_tail = v142_2_branch.second;
        const Path v143_2 = concat_path(v141_83_head,v142_2_head);
        const auto v143_3_branches = branches(c,v142_2_tail);
        std::vector<Space> v143_3_outputs;
        v143_3_outputs.reserve(v143_3_branches.size());
        for (const auto& v143_3_branch : v143_3_branches) {
          const Path v143_3_head{v143_3_branch.first};
          const Space& v143_3_tail = v143_3_branch.second;
          const Path v144_2 = concat_path(v143_2,v143_3_head);
          const auto v144_3_branches = branches(c,v143_3_tail);
          std::vector<Space> v144_3_outputs;
          v144_3_outputs.reserve(v144_3_branches.size());
          for (const auto& v144_3_branch : v144_3_branches) {
            const Path v144_3_head{v144_3_branch.first};
            const Space& v144_3_tail = v144_3_branch.second;
            const Path v145_2 = concat_path(v144_2,v144_3_head);
            const Space v145_3 = routine_26(c, v145_2, v144_3_tail);
            v144_3_outputs.push_back(v145_3);
          }
          const Space v144_3 = join_outputs(std::move(v144_3_outputs));
          v143_3_outputs.push_back(v144_3);
        }
        const Space v143_3 = join_outputs(std::move(v143_3_outputs));
        v142_2_outputs.push_back(v143_3);
      }
      const Space v142_2 = join_outputs(std::move(v142_2_outputs));
      v141_83_outputs.push_back(v142_2);
    }
    const Space v141_83 = join_outputs(std::move(v141_83_outputs));
    v64_84 = compose(v64_82,v141_83);
  }
  const Space v64_85 = unite(v64_79,v64_84);
  const Space v64_87 = intersect(constant_59,v64_18);
  const auto v64_88_branches = branches(c,v64_87);
  std::vector<Space> v64_88_outputs;
  v64_88_outputs.reserve(v64_88_branches.size());
  for (const auto& v64_88_branch : v64_88_branches) {
    const Path v64_88_head{v64_88_branch.first};
    const Space& v64_88_tail = v64_88_branch.second;
    const auto v146_2_branches = branches(c,v64_88_tail);
    std::vector<Space> v146_2_outputs;
    v146_2_outputs.reserve(v146_2_branches.size());
    for (const auto& v146_2_branch : v146_2_branches) {
      const Path v146_2_head{v146_2_branch.first};
      const Space& v146_2_tail = v146_2_branch.second;
      const Path v147_2 = concat_path(v64_88_head,v146_2_head);
      const auto v147_3_branches = branches(c,v146_2_tail);
      std::vector<Space> v147_3_outputs;
      v147_3_outputs.reserve(v147_3_branches.size());
      for (const auto& v147_3_branch : v147_3_branches) {
        const Path v147_3_head{v147_3_branch.first};
        const Space& v147_3_tail = v147_3_branch.second;
        const Path v148_2 = concat_path(v147_2,v147_3_head);
        const auto v148_3_branches = branches(c,v147_3_tail);
        std::vector<Space> v148_3_outputs;
        v148_3_outputs.reserve(v148_3_branches.size());
        for (const auto& v148_3_branch : v148_3_branches) {
          const Path v148_3_head{v148_3_branch.first};
          const Space& v148_3_tail = v148_3_branch.second;
          const Path v149_2 = concat_path(v148_2,v148_3_head);
          const Space v149_3 = routine_27(c, v149_2, v148_3_tail);
          v148_3_outputs.push_back(v149_3);
        }
        const Space v148_3 = join_outputs(std::move(v148_3_outputs));
        v147_3_outputs.push_back(v148_3);
      }
      const Space v147_3 = join_outputs(std::move(v147_3_outputs));
      v146_2_outputs.push_back(v147_3);
    }
    const Space v146_2 = join_outputs(std::move(v146_2_outputs));
    v64_88_outputs.push_back(v146_2);
  }
  const Space v64_88 = join_outputs(std::move(v64_88_outputs));
  Space v64_90;
  if (!v64_88.empty()) {
    const Path v150_21 = concat_path(p2,p3);
    const Path v150_22 = concat_path(v150_21,p4);
    const Path v150_23 = concat_path(v150_22,p5);
    const Path v150_24 = concat_path(v150_23,p6);
    const Path v150_25 = concat_path(v150_24,p7);
    const Path v150_26 = concat_path(v150_25,p8);
    const Path v150_27 = concat_path(v150_26,p9);
    const Path v150_28 = concat_path(v150_27,p10);
    const Path v150_29 = concat_path(v150_28,p11);
    const Path v150_30 = concat_path(v150_29,p12);
    const Path v150_31 = concat_path(v150_30,p13);
    const Path v150_32 = concat_path(v150_31,p14);
    const Path v150_33 = concat_path(v150_32,p15);
    const Path v150_34 = concat_path(v150_33,p0);
    const Space v150_35 = singleton(v150_34);
    const auto v150_89_branches = branches(c,v150_35);
    std::vector<Space> v150_89_outputs;
    v150_89_outputs.reserve(v150_89_branches.size());
    for (const auto& v150_89_branch : v150_89_branches) {
      const Path v150_89_head{v150_89_branch.first};
      const Space& v150_89_tail = v150_89_branch.second;
      const auto v151_2_branches = branches(c,v150_89_tail);
      std::vector<Space> v151_2_outputs;
      v151_2_outputs.reserve(v151_2_branches.size());
      for (const auto& v151_2_branch : v151_2_branches) {
        const Path v151_2_head{v151_2_branch.first};
        const Space& v151_2_tail = v151_2_branch.second;
        const Path v152_2 = concat_path(v150_89_head,v151_2_head);
        const auto v152_3_branches = branches(c,v151_2_tail);
        std::vector<Space> v152_3_outputs;
        v152_3_outputs.reserve(v152_3_branches.size());
        for (const auto& v152_3_branch : v152_3_branches) {
          const Path v152_3_head{v152_3_branch.first};
          const Space& v152_3_tail = v152_3_branch.second;
          const Path v153_2 = concat_path(v152_2,v152_3_head);
          const auto v153_3_branches = branches(c,v152_3_tail);
          std::vector<Space> v153_3_outputs;
          v153_3_outputs.reserve(v153_3_branches.size());
          for (const auto& v153_3_branch : v153_3_branches) {
            const Path v153_3_head{v153_3_branch.first};
            const Space& v153_3_tail = v153_3_branch.second;
            const Path v154_2 = concat_path(v153_2,v153_3_head);
            const Space v154_3 = routine_28(c, v154_2, v153_3_tail);
            v153_3_outputs.push_back(v154_3);
          }
          const Space v153_3 = join_outputs(std::move(v153_3_outputs));
          v152_3_outputs.push_back(v153_3);
        }
        const Space v152_3 = join_outputs(std::move(v152_3_outputs));
        v151_2_outputs.push_back(v152_3);
      }
      const Space v151_2 = join_outputs(std::move(v151_2_outputs));
      v150_89_outputs.push_back(v151_2);
    }
    const Space v150_89 = join_outputs(std::move(v150_89_outputs));
    v64_90 = compose(v64_88,v150_89);
  }
  const Space v64_91 = unite(v64_85,v64_90);
  const Space v64_93 = intersect(constant_60,v64_18);
  const auto v64_94_branches = branches(c,v64_93);
  std::vector<Space> v64_94_outputs;
  v64_94_outputs.reserve(v64_94_branches.size());
  for (const auto& v64_94_branch : v64_94_branches) {
    const Path v64_94_head{v64_94_branch.first};
    const Space& v64_94_tail = v64_94_branch.second;
    const auto v155_2_branches = branches(c,v64_94_tail);
    std::vector<Space> v155_2_outputs;
    v155_2_outputs.reserve(v155_2_branches.size());
    for (const auto& v155_2_branch : v155_2_branches) {
      const Path v155_2_head{v155_2_branch.first};
      const Space& v155_2_tail = v155_2_branch.second;
      const Path v156_2 = concat_path(v64_94_head,v155_2_head);
      const auto v156_3_branches = branches(c,v155_2_tail);
      std::vector<Space> v156_3_outputs;
      v156_3_outputs.reserve(v156_3_branches.size());
      for (const auto& v156_3_branch : v156_3_branches) {
        const Path v156_3_head{v156_3_branch.first};
        const Space& v156_3_tail = v156_3_branch.second;
        const Path v157_2 = concat_path(v156_2,v156_3_head);
        const auto v157_3_branches = branches(c,v156_3_tail);
        std::vector<Space> v157_3_outputs;
        v157_3_outputs.reserve(v157_3_branches.size());
        for (const auto& v157_3_branch : v157_3_branches) {
          const Path v157_3_head{v157_3_branch.first};
          const Space& v157_3_tail = v157_3_branch.second;
          const Path v158_2 = concat_path(v157_2,v157_3_head);
          const Space v158_3 = routine_29(c, v158_2, v157_3_tail);
          v157_3_outputs.push_back(v158_3);
        }
        const Space v157_3 = join_outputs(std::move(v157_3_outputs));
        v156_3_outputs.push_back(v157_3);
      }
      const Space v156_3 = join_outputs(std::move(v156_3_outputs));
      v155_2_outputs.push_back(v156_3);
    }
    const Space v155_2 = join_outputs(std::move(v155_2_outputs));
    v64_94_outputs.push_back(v155_2);
  }
  const Space v64_94 = join_outputs(std::move(v64_94_outputs));
  Space v64_96;
  if (!v64_94.empty()) {
    const Path v159_21 = concat_path(p2,p3);
    const Path v159_22 = concat_path(v159_21,p4);
    const Path v159_23 = concat_path(v159_22,p5);
    const Path v159_24 = concat_path(v159_23,p6);
    const Path v159_25 = concat_path(v159_24,p7);
    const Path v159_26 = concat_path(v159_25,p8);
    const Path v159_27 = concat_path(v159_26,p9);
    const Path v159_28 = concat_path(v159_27,p10);
    const Path v159_29 = concat_path(v159_28,p11);
    const Path v159_30 = concat_path(v159_29,p12);
    const Path v159_31 = concat_path(v159_30,p13);
    const Path v159_32 = concat_path(v159_31,p14);
    const Path v159_33 = concat_path(v159_32,p15);
    const Path v159_34 = concat_path(v159_33,p0);
    const Space v159_35 = singleton(v159_34);
    const auto v159_95_branches = branches(c,v159_35);
    std::vector<Space> v159_95_outputs;
    v159_95_outputs.reserve(v159_95_branches.size());
    for (const auto& v159_95_branch : v159_95_branches) {
      const Path v159_95_head{v159_95_branch.first};
      const Space& v159_95_tail = v159_95_branch.second;
      const auto v160_2_branches = branches(c,v159_95_tail);
      std::vector<Space> v160_2_outputs;
      v160_2_outputs.reserve(v160_2_branches.size());
      for (const auto& v160_2_branch : v160_2_branches) {
        const Path v160_2_head{v160_2_branch.first};
        const Space& v160_2_tail = v160_2_branch.second;
        const Path v161_2 = concat_path(v159_95_head,v160_2_head);
        const auto v161_3_branches = branches(c,v160_2_tail);
        std::vector<Space> v161_3_outputs;
        v161_3_outputs.reserve(v161_3_branches.size());
        for (const auto& v161_3_branch : v161_3_branches) {
          const Path v161_3_head{v161_3_branch.first};
          const Space& v161_3_tail = v161_3_branch.second;
          const Path v162_2 = concat_path(v161_2,v161_3_head);
          const auto v162_3_branches = branches(c,v161_3_tail);
          std::vector<Space> v162_3_outputs;
          v162_3_outputs.reserve(v162_3_branches.size());
          for (const auto& v162_3_branch : v162_3_branches) {
            const Path v162_3_head{v162_3_branch.first};
            const Space& v162_3_tail = v162_3_branch.second;
            const Path v163_2 = concat_path(v162_2,v162_3_head);
            const Space v163_3 = routine_30(c, v163_2, v162_3_tail);
            v162_3_outputs.push_back(v163_3);
          }
          const Space v162_3 = join_outputs(std::move(v162_3_outputs));
          v161_3_outputs.push_back(v162_3);
        }
        const Space v161_3 = join_outputs(std::move(v161_3_outputs));
        v160_2_outputs.push_back(v161_3);
      }
      const Space v160_2 = join_outputs(std::move(v160_2_outputs));
      v159_95_outputs.push_back(v160_2);
    }
    const Space v159_95 = join_outputs(std::move(v159_95_outputs));
    v64_96 = compose(v64_94,v159_95);
  }
  const Space v64_97 = unite(v64_91,v64_96);
  const Space v64_99 = intersect(constant_61,v64_18);
  const auto v64_100_branches = branches(c,v64_99);
  std::vector<Space> v64_100_outputs;
  v64_100_outputs.reserve(v64_100_branches.size());
  for (const auto& v64_100_branch : v64_100_branches) {
    const Path v64_100_head{v64_100_branch.first};
    const Space& v64_100_tail = v64_100_branch.second;
    const auto v164_2_branches = branches(c,v64_100_tail);
    std::vector<Space> v164_2_outputs;
    v164_2_outputs.reserve(v164_2_branches.size());
    for (const auto& v164_2_branch : v164_2_branches) {
      const Path v164_2_head{v164_2_branch.first};
      const Space& v164_2_tail = v164_2_branch.second;
      const Path v165_2 = concat_path(v64_100_head,v164_2_head);
      const auto v165_3_branches = branches(c,v164_2_tail);
      std::vector<Space> v165_3_outputs;
      v165_3_outputs.reserve(v165_3_branches.size());
      for (const auto& v165_3_branch : v165_3_branches) {
        const Path v165_3_head{v165_3_branch.first};
        const Space& v165_3_tail = v165_3_branch.second;
        const Path v166_2 = concat_path(v165_2,v165_3_head);
        const auto v166_3_branches = branches(c,v165_3_tail);
        std::vector<Space> v166_3_outputs;
        v166_3_outputs.reserve(v166_3_branches.size());
        for (const auto& v166_3_branch : v166_3_branches) {
          const Path v166_3_head{v166_3_branch.first};
          const Space& v166_3_tail = v166_3_branch.second;
          const Path v167_2 = concat_path(v166_2,v166_3_head);
          const Space v167_3 = routine_31(c, v167_2, v166_3_tail);
          v166_3_outputs.push_back(v167_3);
        }
        const Space v166_3 = join_outputs(std::move(v166_3_outputs));
        v165_3_outputs.push_back(v166_3);
      }
      const Space v165_3 = join_outputs(std::move(v165_3_outputs));
      v164_2_outputs.push_back(v165_3);
    }
    const Space v164_2 = join_outputs(std::move(v164_2_outputs));
    v64_100_outputs.push_back(v164_2);
  }
  const Space v64_100 = join_outputs(std::move(v64_100_outputs));
  Space v64_102;
  if (!v64_100.empty()) {
    const Path v168_21 = concat_path(p2,p3);
    const Path v168_22 = concat_path(v168_21,p4);
    const Path v168_23 = concat_path(v168_22,p5);
    const Path v168_24 = concat_path(v168_23,p6);
    const Path v168_25 = concat_path(v168_24,p7);
    const Path v168_26 = concat_path(v168_25,p8);
    const Path v168_27 = concat_path(v168_26,p9);
    const Path v168_28 = concat_path(v168_27,p10);
    const Path v168_29 = concat_path(v168_28,p11);
    const Path v168_30 = concat_path(v168_29,p12);
    const Path v168_31 = concat_path(v168_30,p13);
    const Path v168_32 = concat_path(v168_31,p14);
    const Path v168_33 = concat_path(v168_32,p15);
    const Path v168_34 = concat_path(v168_33,p0);
    const Space v168_35 = singleton(v168_34);
    const auto v168_101_branches = branches(c,v168_35);
    std::vector<Space> v168_101_outputs;
    v168_101_outputs.reserve(v168_101_branches.size());
    for (const auto& v168_101_branch : v168_101_branches) {
      const Path v168_101_head{v168_101_branch.first};
      const Space& v168_101_tail = v168_101_branch.second;
      const auto v169_2_branches = branches(c,v168_101_tail);
      std::vector<Space> v169_2_outputs;
      v169_2_outputs.reserve(v169_2_branches.size());
      for (const auto& v169_2_branch : v169_2_branches) {
        const Path v169_2_head{v169_2_branch.first};
        const Space& v169_2_tail = v169_2_branch.second;
        const Path v170_2 = concat_path(v168_101_head,v169_2_head);
        const auto v170_3_branches = branches(c,v169_2_tail);
        std::vector<Space> v170_3_outputs;
        v170_3_outputs.reserve(v170_3_branches.size());
        for (const auto& v170_3_branch : v170_3_branches) {
          const Path v170_3_head{v170_3_branch.first};
          const Space& v170_3_tail = v170_3_branch.second;
          const Path v171_2 = concat_path(v170_2,v170_3_head);
          const auto v171_3_branches = branches(c,v170_3_tail);
          std::vector<Space> v171_3_outputs;
          v171_3_outputs.reserve(v171_3_branches.size());
          for (const auto& v171_3_branch : v171_3_branches) {
            const Path v171_3_head{v171_3_branch.first};
            const Space& v171_3_tail = v171_3_branch.second;
            const Path v172_2 = concat_path(v171_2,v171_3_head);
            const Space v172_3 = routine_32(c, v172_2, v171_3_tail);
            v171_3_outputs.push_back(v172_3);
          }
          const Space v171_3 = join_outputs(std::move(v171_3_outputs));
          v170_3_outputs.push_back(v171_3);
        }
        const Space v170_3 = join_outputs(std::move(v170_3_outputs));
        v169_2_outputs.push_back(v170_3);
      }
      const Space v169_2 = join_outputs(std::move(v169_2_outputs));
      v168_101_outputs.push_back(v169_2);
    }
    const Space v168_101 = join_outputs(std::move(v168_101_outputs));
    v64_102 = compose(v64_100,v168_101);
  }
  const Space v64_103 = unite(v64_97,v64_102);
  const Space v64_105 = intersect(constant_62,v64_18);
  const auto v64_106_branches = branches(c,v64_105);
  std::vector<Space> v64_106_outputs;
  v64_106_outputs.reserve(v64_106_branches.size());
  for (const auto& v64_106_branch : v64_106_branches) {
    const Path v64_106_head{v64_106_branch.first};
    const Space& v64_106_tail = v64_106_branch.second;
    const auto v173_2_branches = branches(c,v64_106_tail);
    std::vector<Space> v173_2_outputs;
    v173_2_outputs.reserve(v173_2_branches.size());
    for (const auto& v173_2_branch : v173_2_branches) {
      const Path v173_2_head{v173_2_branch.first};
      const Space& v173_2_tail = v173_2_branch.second;
      const Path v174_2 = concat_path(v64_106_head,v173_2_head);
      const auto v174_3_branches = branches(c,v173_2_tail);
      std::vector<Space> v174_3_outputs;
      v174_3_outputs.reserve(v174_3_branches.size());
      for (const auto& v174_3_branch : v174_3_branches) {
        const Path v174_3_head{v174_3_branch.first};
        const Space& v174_3_tail = v174_3_branch.second;
        const Path v175_2 = concat_path(v174_2,v174_3_head);
        const auto v175_3_branches = branches(c,v174_3_tail);
        std::vector<Space> v175_3_outputs;
        v175_3_outputs.reserve(v175_3_branches.size());
        for (const auto& v175_3_branch : v175_3_branches) {
          const Path v175_3_head{v175_3_branch.first};
          const Space& v175_3_tail = v175_3_branch.second;
          const Path v176_2 = concat_path(v175_2,v175_3_head);
          const Space v176_3 = routine_33(c, v176_2, v175_3_tail);
          v175_3_outputs.push_back(v176_3);
        }
        const Space v175_3 = join_outputs(std::move(v175_3_outputs));
        v174_3_outputs.push_back(v175_3);
      }
      const Space v174_3 = join_outputs(std::move(v174_3_outputs));
      v173_2_outputs.push_back(v174_3);
    }
    const Space v173_2 = join_outputs(std::move(v173_2_outputs));
    v64_106_outputs.push_back(v173_2);
  }
  const Space v64_106 = join_outputs(std::move(v64_106_outputs));
  Space v64_108;
  if (!v64_106.empty()) {
    const Path v177_21 = concat_path(p2,p3);
    const Path v177_22 = concat_path(v177_21,p4);
    const Path v177_23 = concat_path(v177_22,p5);
    const Path v177_24 = concat_path(v177_23,p6);
    const Path v177_25 = concat_path(v177_24,p7);
    const Path v177_26 = concat_path(v177_25,p8);
    const Path v177_27 = concat_path(v177_26,p9);
    const Path v177_28 = concat_path(v177_27,p10);
    const Path v177_29 = concat_path(v177_28,p11);
    const Path v177_30 = concat_path(v177_29,p12);
    const Path v177_31 = concat_path(v177_30,p13);
    const Path v177_32 = concat_path(v177_31,p14);
    const Path v177_33 = concat_path(v177_32,p15);
    const Path v177_34 = concat_path(v177_33,p0);
    const Space v177_35 = singleton(v177_34);
    const auto v177_107_branches = branches(c,v177_35);
    std::vector<Space> v177_107_outputs;
    v177_107_outputs.reserve(v177_107_branches.size());
    for (const auto& v177_107_branch : v177_107_branches) {
      const Path v177_107_head{v177_107_branch.first};
      const Space& v177_107_tail = v177_107_branch.second;
      const auto v178_2_branches = branches(c,v177_107_tail);
      std::vector<Space> v178_2_outputs;
      v178_2_outputs.reserve(v178_2_branches.size());
      for (const auto& v178_2_branch : v178_2_branches) {
        const Path v178_2_head{v178_2_branch.first};
        const Space& v178_2_tail = v178_2_branch.second;
        const Path v179_2 = concat_path(v177_107_head,v178_2_head);
        const auto v179_3_branches = branches(c,v178_2_tail);
        std::vector<Space> v179_3_outputs;
        v179_3_outputs.reserve(v179_3_branches.size());
        for (const auto& v179_3_branch : v179_3_branches) {
          const Path v179_3_head{v179_3_branch.first};
          const Space& v179_3_tail = v179_3_branch.second;
          const Path v180_2 = concat_path(v179_2,v179_3_head);
          const auto v180_3_branches = branches(c,v179_3_tail);
          std::vector<Space> v180_3_outputs;
          v180_3_outputs.reserve(v180_3_branches.size());
          for (const auto& v180_3_branch : v180_3_branches) {
            const Path v180_3_head{v180_3_branch.first};
            const Space& v180_3_tail = v180_3_branch.second;
            const Path v181_2 = concat_path(v180_2,v180_3_head);
            const Space v181_3 = routine_34(c, v181_2, v180_3_tail);
            v180_3_outputs.push_back(v181_3);
          }
          const Space v180_3 = join_outputs(std::move(v180_3_outputs));
          v179_3_outputs.push_back(v180_3);
        }
        const Space v179_3 = join_outputs(std::move(v179_3_outputs));
        v178_2_outputs.push_back(v179_3);
      }
      const Space v178_2 = join_outputs(std::move(v178_2_outputs));
      v177_107_outputs.push_back(v178_2);
    }
    const Space v177_107 = join_outputs(std::move(v177_107_outputs));
    v64_108 = compose(v64_106,v177_107);
  }
  const Space v64_109 = unite(v64_103,v64_108);
  const Space v64_111 = intersect(constant_63,v64_18);
  const auto v64_112_branches = branches(c,v64_111);
  std::vector<Space> v64_112_outputs;
  v64_112_outputs.reserve(v64_112_branches.size());
  for (const auto& v64_112_branch : v64_112_branches) {
    const Path v64_112_head{v64_112_branch.first};
    const Space& v64_112_tail = v64_112_branch.second;
    const auto v182_2_branches = branches(c,v64_112_tail);
    std::vector<Space> v182_2_outputs;
    v182_2_outputs.reserve(v182_2_branches.size());
    for (const auto& v182_2_branch : v182_2_branches) {
      const Path v182_2_head{v182_2_branch.first};
      const Space& v182_2_tail = v182_2_branch.second;
      const Path v183_2 = concat_path(v64_112_head,v182_2_head);
      const auto v183_3_branches = branches(c,v182_2_tail);
      std::vector<Space> v183_3_outputs;
      v183_3_outputs.reserve(v183_3_branches.size());
      for (const auto& v183_3_branch : v183_3_branches) {
        const Path v183_3_head{v183_3_branch.first};
        const Space& v183_3_tail = v183_3_branch.second;
        const Path v184_2 = concat_path(v183_2,v183_3_head);
        const auto v184_3_branches = branches(c,v183_3_tail);
        std::vector<Space> v184_3_outputs;
        v184_3_outputs.reserve(v184_3_branches.size());
        for (const auto& v184_3_branch : v184_3_branches) {
          const Path v184_3_head{v184_3_branch.first};
          const Space& v184_3_tail = v184_3_branch.second;
          const Path v185_2 = concat_path(v184_2,v184_3_head);
          const Space v185_3 = routine_35(c, v185_2, v184_3_tail);
          v184_3_outputs.push_back(v185_3);
        }
        const Space v184_3 = join_outputs(std::move(v184_3_outputs));
        v183_3_outputs.push_back(v184_3);
      }
      const Space v183_3 = join_outputs(std::move(v183_3_outputs));
      v182_2_outputs.push_back(v183_3);
    }
    const Space v182_2 = join_outputs(std::move(v182_2_outputs));
    v64_112_outputs.push_back(v182_2);
  }
  const Space v64_112 = join_outputs(std::move(v64_112_outputs));
  Space v64_114;
  if (!v64_112.empty()) {
    const Path v186_21 = concat_path(p2,p3);
    const Path v186_22 = concat_path(v186_21,p4);
    const Path v186_23 = concat_path(v186_22,p5);
    const Path v186_24 = concat_path(v186_23,p6);
    const Path v186_25 = concat_path(v186_24,p7);
    const Path v186_26 = concat_path(v186_25,p8);
    const Path v186_27 = concat_path(v186_26,p9);
    const Path v186_28 = concat_path(v186_27,p10);
    const Path v186_29 = concat_path(v186_28,p11);
    const Path v186_30 = concat_path(v186_29,p12);
    const Path v186_31 = concat_path(v186_30,p13);
    const Path v186_32 = concat_path(v186_31,p14);
    const Path v186_33 = concat_path(v186_32,p15);
    const Path v186_34 = concat_path(v186_33,p0);
    const Space v186_35 = singleton(v186_34);
    const auto v186_113_branches = branches(c,v186_35);
    std::vector<Space> v186_113_outputs;
    v186_113_outputs.reserve(v186_113_branches.size());
    for (const auto& v186_113_branch : v186_113_branches) {
      const Path v186_113_head{v186_113_branch.first};
      const Space& v186_113_tail = v186_113_branch.second;
      const auto v187_2_branches = branches(c,v186_113_tail);
      std::vector<Space> v187_2_outputs;
      v187_2_outputs.reserve(v187_2_branches.size());
      for (const auto& v187_2_branch : v187_2_branches) {
        const Path v187_2_head{v187_2_branch.first};
        const Space& v187_2_tail = v187_2_branch.second;
        const Path v188_2 = concat_path(v186_113_head,v187_2_head);
        const auto v188_3_branches = branches(c,v187_2_tail);
        std::vector<Space> v188_3_outputs;
        v188_3_outputs.reserve(v188_3_branches.size());
        for (const auto& v188_3_branch : v188_3_branches) {
          const Path v188_3_head{v188_3_branch.first};
          const Space& v188_3_tail = v188_3_branch.second;
          const Path v189_2 = concat_path(v188_2,v188_3_head);
          const auto v189_3_branches = branches(c,v188_3_tail);
          std::vector<Space> v189_3_outputs;
          v189_3_outputs.reserve(v189_3_branches.size());
          for (const auto& v189_3_branch : v189_3_branches) {
            const Path v189_3_head{v189_3_branch.first};
            const Space& v189_3_tail = v189_3_branch.second;
            const Path v190_2 = concat_path(v189_2,v189_3_head);
            const Space v190_3 = routine_36(c, v190_2, v189_3_tail);
            v189_3_outputs.push_back(v190_3);
          }
          const Space v189_3 = join_outputs(std::move(v189_3_outputs));
          v188_3_outputs.push_back(v189_3);
        }
        const Space v188_3 = join_outputs(std::move(v188_3_outputs));
        v187_2_outputs.push_back(v188_3);
      }
      const Space v187_2 = join_outputs(std::move(v187_2_outputs));
      v186_113_outputs.push_back(v187_2);
    }
    const Space v186_113 = join_outputs(std::move(v186_113_outputs));
    v64_114 = compose(v64_112,v186_113);
  }
  const Space v64_115 = unite(v64_109,v64_114);
  const Space v64_117 = intersect(constant_64,v64_18);
  const auto v64_118_branches = branches(c,v64_117);
  std::vector<Space> v64_118_outputs;
  v64_118_outputs.reserve(v64_118_branches.size());
  for (const auto& v64_118_branch : v64_118_branches) {
    const Path v64_118_head{v64_118_branch.first};
    const Space& v64_118_tail = v64_118_branch.second;
    const auto v191_2_branches = branches(c,v64_118_tail);
    std::vector<Space> v191_2_outputs;
    v191_2_outputs.reserve(v191_2_branches.size());
    for (const auto& v191_2_branch : v191_2_branches) {
      const Path v191_2_head{v191_2_branch.first};
      const Space& v191_2_tail = v191_2_branch.second;
      const Path v192_2 = concat_path(v64_118_head,v191_2_head);
      const auto v192_3_branches = branches(c,v191_2_tail);
      std::vector<Space> v192_3_outputs;
      v192_3_outputs.reserve(v192_3_branches.size());
      for (const auto& v192_3_branch : v192_3_branches) {
        const Path v192_3_head{v192_3_branch.first};
        const Space& v192_3_tail = v192_3_branch.second;
        const Path v193_2 = concat_path(v192_2,v192_3_head);
        const auto v193_3_branches = branches(c,v192_3_tail);
        std::vector<Space> v193_3_outputs;
        v193_3_outputs.reserve(v193_3_branches.size());
        for (const auto& v193_3_branch : v193_3_branches) {
          const Path v193_3_head{v193_3_branch.first};
          const Space& v193_3_tail = v193_3_branch.second;
          const Path v194_2 = concat_path(v193_2,v193_3_head);
          const Space v194_3 = routine_37(c, v194_2, v193_3_tail);
          v193_3_outputs.push_back(v194_3);
        }
        const Space v193_3 = join_outputs(std::move(v193_3_outputs));
        v192_3_outputs.push_back(v193_3);
      }
      const Space v192_3 = join_outputs(std::move(v192_3_outputs));
      v191_2_outputs.push_back(v192_3);
    }
    const Space v191_2 = join_outputs(std::move(v191_2_outputs));
    v64_118_outputs.push_back(v191_2);
  }
  const Space v64_118 = join_outputs(std::move(v64_118_outputs));
  Space v64_120;
  if (!v64_118.empty()) {
    const Path v195_21 = concat_path(p2,p3);
    const Path v195_22 = concat_path(v195_21,p4);
    const Path v195_23 = concat_path(v195_22,p5);
    const Path v195_24 = concat_path(v195_23,p6);
    const Path v195_25 = concat_path(v195_24,p7);
    const Path v195_26 = concat_path(v195_25,p8);
    const Path v195_27 = concat_path(v195_26,p9);
    const Path v195_28 = concat_path(v195_27,p10);
    const Path v195_29 = concat_path(v195_28,p11);
    const Path v195_30 = concat_path(v195_29,p12);
    const Path v195_31 = concat_path(v195_30,p13);
    const Path v195_32 = concat_path(v195_31,p14);
    const Path v195_33 = concat_path(v195_32,p15);
    const Path v195_34 = concat_path(v195_33,p0);
    const Space v195_35 = singleton(v195_34);
    const auto v195_119_branches = branches(c,v195_35);
    std::vector<Space> v195_119_outputs;
    v195_119_outputs.reserve(v195_119_branches.size());
    for (const auto& v195_119_branch : v195_119_branches) {
      const Path v195_119_head{v195_119_branch.first};
      const Space& v195_119_tail = v195_119_branch.second;
      const auto v196_2_branches = branches(c,v195_119_tail);
      std::vector<Space> v196_2_outputs;
      v196_2_outputs.reserve(v196_2_branches.size());
      for (const auto& v196_2_branch : v196_2_branches) {
        const Path v196_2_head{v196_2_branch.first};
        const Space& v196_2_tail = v196_2_branch.second;
        const Path v197_2 = concat_path(v195_119_head,v196_2_head);
        const auto v197_3_branches = branches(c,v196_2_tail);
        std::vector<Space> v197_3_outputs;
        v197_3_outputs.reserve(v197_3_branches.size());
        for (const auto& v197_3_branch : v197_3_branches) {
          const Path v197_3_head{v197_3_branch.first};
          const Space& v197_3_tail = v197_3_branch.second;
          const Path v198_2 = concat_path(v197_2,v197_3_head);
          const auto v198_3_branches = branches(c,v197_3_tail);
          std::vector<Space> v198_3_outputs;
          v198_3_outputs.reserve(v198_3_branches.size());
          for (const auto& v198_3_branch : v198_3_branches) {
            const Path v198_3_head{v198_3_branch.first};
            const Space& v198_3_tail = v198_3_branch.second;
            const Path v199_2 = concat_path(v198_2,v198_3_head);
            const Space v199_3 = routine_38(c, v199_2, v198_3_tail);
            v198_3_outputs.push_back(v199_3);
          }
          const Space v198_3 = join_outputs(std::move(v198_3_outputs));
          v197_3_outputs.push_back(v198_3);
        }
        const Space v197_3 = join_outputs(std::move(v197_3_outputs));
        v196_2_outputs.push_back(v197_3);
      }
      const Space v196_2 = join_outputs(std::move(v196_2_outputs));
      v195_119_outputs.push_back(v196_2);
    }
    const Space v195_119 = join_outputs(std::move(v195_119_outputs));
    v64_120 = compose(v64_118,v195_119);
  }
  const Space v64_121 = unite(v64_115,v64_120);
  const Space v64_123 = intersect(constant_65,v64_18);
  const auto v64_124_branches = branches(c,v64_123);
  std::vector<Space> v64_124_outputs;
  v64_124_outputs.reserve(v64_124_branches.size());
  for (const auto& v64_124_branch : v64_124_branches) {
    const Path v64_124_head{v64_124_branch.first};
    const Space& v64_124_tail = v64_124_branch.second;
    const auto v200_2_branches = branches(c,v64_124_tail);
    std::vector<Space> v200_2_outputs;
    v200_2_outputs.reserve(v200_2_branches.size());
    for (const auto& v200_2_branch : v200_2_branches) {
      const Path v200_2_head{v200_2_branch.first};
      const Space& v200_2_tail = v200_2_branch.second;
      const Path v201_2 = concat_path(v64_124_head,v200_2_head);
      const auto v201_3_branches = branches(c,v200_2_tail);
      std::vector<Space> v201_3_outputs;
      v201_3_outputs.reserve(v201_3_branches.size());
      for (const auto& v201_3_branch : v201_3_branches) {
        const Path v201_3_head{v201_3_branch.first};
        const Space& v201_3_tail = v201_3_branch.second;
        const Path v202_2 = concat_path(v201_2,v201_3_head);
        const auto v202_3_branches = branches(c,v201_3_tail);
        std::vector<Space> v202_3_outputs;
        v202_3_outputs.reserve(v202_3_branches.size());
        for (const auto& v202_3_branch : v202_3_branches) {
          const Path v202_3_head{v202_3_branch.first};
          const Space& v202_3_tail = v202_3_branch.second;
          const Path v203_2 = concat_path(v202_2,v202_3_head);
          const Space v203_3 = routine_39(c, v203_2, v202_3_tail);
          v202_3_outputs.push_back(v203_3);
        }
        const Space v202_3 = join_outputs(std::move(v202_3_outputs));
        v201_3_outputs.push_back(v202_3);
      }
      const Space v201_3 = join_outputs(std::move(v201_3_outputs));
      v200_2_outputs.push_back(v201_3);
    }
    const Space v200_2 = join_outputs(std::move(v200_2_outputs));
    v64_124_outputs.push_back(v200_2);
  }
  const Space v64_124 = join_outputs(std::move(v64_124_outputs));
  Space v64_126;
  if (!v64_124.empty()) {
    const Path v204_21 = concat_path(p2,p3);
    const Path v204_22 = concat_path(v204_21,p4);
    const Path v204_23 = concat_path(v204_22,p5);
    const Path v204_24 = concat_path(v204_23,p6);
    const Path v204_25 = concat_path(v204_24,p7);
    const Path v204_26 = concat_path(v204_25,p8);
    const Path v204_27 = concat_path(v204_26,p9);
    const Path v204_28 = concat_path(v204_27,p10);
    const Path v204_29 = concat_path(v204_28,p11);
    const Path v204_30 = concat_path(v204_29,p12);
    const Path v204_31 = concat_path(v204_30,p13);
    const Path v204_32 = concat_path(v204_31,p14);
    const Path v204_33 = concat_path(v204_32,p15);
    const Path v204_34 = concat_path(v204_33,p0);
    const Space v204_35 = singleton(v204_34);
    const auto v204_125_branches = branches(c,v204_35);
    std::vector<Space> v204_125_outputs;
    v204_125_outputs.reserve(v204_125_branches.size());
    for (const auto& v204_125_branch : v204_125_branches) {
      const Path v204_125_head{v204_125_branch.first};
      const Space& v204_125_tail = v204_125_branch.second;
      const auto v205_2_branches = branches(c,v204_125_tail);
      std::vector<Space> v205_2_outputs;
      v205_2_outputs.reserve(v205_2_branches.size());
      for (const auto& v205_2_branch : v205_2_branches) {
        const Path v205_2_head{v205_2_branch.first};
        const Space& v205_2_tail = v205_2_branch.second;
        const Path v206_2 = concat_path(v204_125_head,v205_2_head);
        const auto v206_3_branches = branches(c,v205_2_tail);
        std::vector<Space> v206_3_outputs;
        v206_3_outputs.reserve(v206_3_branches.size());
        for (const auto& v206_3_branch : v206_3_branches) {
          const Path v206_3_head{v206_3_branch.first};
          const Space& v206_3_tail = v206_3_branch.second;
          const Path v207_2 = concat_path(v206_2,v206_3_head);
          const auto v207_3_branches = branches(c,v206_3_tail);
          std::vector<Space> v207_3_outputs;
          v207_3_outputs.reserve(v207_3_branches.size());
          for (const auto& v207_3_branch : v207_3_branches) {
            const Path v207_3_head{v207_3_branch.first};
            const Space& v207_3_tail = v207_3_branch.second;
            const Path v208_2 = concat_path(v207_2,v207_3_head);
            const Space v208_3 = routine_40(c, v208_2, v207_3_tail);
            v207_3_outputs.push_back(v208_3);
          }
          const Space v207_3 = join_outputs(std::move(v207_3_outputs));
          v206_3_outputs.push_back(v207_3);
        }
        const Space v206_3 = join_outputs(std::move(v206_3_outputs));
        v205_2_outputs.push_back(v206_3);
      }
      const Space v205_2 = join_outputs(std::move(v205_2_outputs));
      v204_125_outputs.push_back(v205_2);
    }
    const Space v204_125 = join_outputs(std::move(v204_125_outputs));
    v64_126 = compose(v64_124,v204_125);
  }
  const Space v64_127 = unite(v64_121,v64_126);
  const auto v64_160_branches = branches(c,v64_127);
  std::vector<Space> v64_160_outputs;
  v64_160_outputs.reserve(v64_160_branches.size());
  for (const auto& v64_160_branch : v64_160_branches) {
    const Path v64_160_head{v64_160_branch.first};
    const Space& v64_160_tail = v64_160_branch.second;
    const auto v209_2_branches = branches(c,v64_160_tail);
    std::vector<Space> v209_2_outputs;
    v209_2_outputs.reserve(v209_2_branches.size());
    for (const auto& v209_2_branch : v209_2_branches) {
      const Path v209_2_head{v209_2_branch.first};
      const Space& v209_2_tail = v209_2_branch.second;
      const Path v210_2 = concat_path(v64_160_head,v209_2_head);
      const auto v210_3_branches = branches(c,v209_2_tail);
      std::vector<Space> v210_3_outputs;
      v210_3_outputs.reserve(v210_3_branches.size());
      for (const auto& v210_3_branch : v210_3_branches) {
        const Path v210_3_head{v210_3_branch.first};
        const Space& v210_3_tail = v210_3_branch.second;
        const Path v211_2 = concat_path(v210_2,v210_3_head);
        const auto v211_3_branches = branches(c,v210_3_tail);
        std::vector<Space> v211_3_outputs;
        v211_3_outputs.reserve(v211_3_branches.size());
        for (const auto& v211_3_branch : v211_3_branches) {
          const Path v211_3_head{v211_3_branch.first};
          const Space& v211_3_tail = v211_3_branch.second;
          const Space v212_2 = routine_41(c, constant_1, constant_66);
          const Space v212_3 = routine_41(c, constant_3, constant_67);
          const Space v212_4 = unite(v212_2,v212_3);
          const Space v212_5 = routine_41(c, constant_5, constant_68);
          const Space v212_6 = unite(v212_4,v212_5);
          const Space v212_7 = routine_41(c, constant_7, constant_69);
          const Space v212_8 = unite(v212_6,v212_7);
          const Space v212_9 = routine_41(c, constant_9, constant_70);
          const Space v212_10 = unite(v212_8,v212_9);
          const Space v212_11 = routine_41(c, constant_11, constant_71);
          const Space v212_12 = unite(v212_10,v212_11);
          const Space v212_13 = routine_41(c, constant_13, constant_72);
          const Space v212_14 = unite(v212_12,v212_13);
          const Space v212_15 = routine_41(c, constant_15, constant_73);
          const Space v212_16 = unite(v212_14,v212_15);
          const Space v212_17 = routine_41(c, constant_17, constant_74);
          const Space v212_18 = unite(v212_16,v212_17);
          const Space v212_19 = routine_41(c, constant_19, constant_75);
          const Space v212_20 = unite(v212_18,v212_19);
          const Space v212_21 = routine_41(c, constant_21, constant_76);
          const Space v212_22 = unite(v212_20,v212_21);
          const Space v212_23 = routine_41(c, constant_23, constant_77);
          const Space v212_24 = unite(v212_22,v212_23);
          const Space v212_25 = routine_41(c, constant_25, constant_78);
          const Space v212_26 = unite(v212_24,v212_25);
          const Space v212_27 = routine_41(c, constant_27, constant_79);
          const Space v212_28 = unite(v212_26,v212_27);
          const Space v212_29 = routine_41(c, constant_29, constant_80);
          const Space v212_30 = unite(v212_28,v212_29);
          const Space v212_31 = routine_41(c, constant_81, constant_82);
          const Space v212_32 = unite(v212_30,v212_31);
          const Space v212_33 = unwrap(v212_32,p1);
          const Path v212_34 = concat_path(v211_2,v211_3_head);
          const auto v212_35_branches = branches(c,v212_33);
          std::vector<Space> v212_35_outputs;
          v212_35_outputs.reserve(v212_35_branches.size());
          for (const auto& v212_35_branch : v212_35_branches) {
            const Path v212_35_head{v212_35_branch.first};
            const Space& v212_35_tail = v212_35_branch.second;
            const auto v213_2_branches = branches(c,v212_35_tail);
            std::vector<Space> v213_2_outputs;
            v213_2_outputs.reserve(v213_2_branches.size());
            for (const auto& v213_2_branch : v213_2_branches) {
              const Path v213_2_head{v213_2_branch.first};
              const Space& v213_2_tail = v213_2_branch.second;
              const Path v214_2 = concat_path(v212_35_head,v213_2_head);
              const auto v214_3_branches = branches(c,v213_2_tail);
              std::vector<Space> v214_3_outputs;
              v214_3_outputs.reserve(v214_3_branches.size());
              for (const auto& v214_3_branch : v214_3_branches) {
                const Path v214_3_head{v214_3_branch.first};
                const Space& v214_3_tail = v214_3_branch.second;
                const Path v215_2 = concat_path(v214_2,v214_3_head);
                const auto v215_3_branches = branches(c,v214_3_tail);
                std::vector<Space> v215_3_outputs;
                v215_3_outputs.reserve(v215_3_branches.size());
                for (const auto& v215_3_branch : v215_3_branches) {
                  const Path v215_3_head{v215_3_branch.first};
                  const Space& v215_3_tail = v215_3_branch.second;
                  const Path v216_2 = concat_path(v215_2,v215_3_head);
                  const Space v216_3 = routine_42(c, v216_2, v212_34, v215_3_tail, v211_3_tail);
                  v215_3_outputs.push_back(v216_3);
                }
                const Space v215_3 = join_outputs(std::move(v215_3_outputs));
                v214_3_outputs.push_back(v215_3);
              }
              const Space v214_3 = join_outputs(std::move(v214_3_outputs));
              v213_2_outputs.push_back(v214_3);
            }
            const Space v213_2 = join_outputs(std::move(v213_2_outputs));
            v212_35_outputs.push_back(v213_2);
          }
          const Space v212_35 = join_outputs(std::move(v212_35_outputs));
          v211_3_outputs.push_back(v212_35);
        }
        const Space v211_3 = join_outputs(std::move(v211_3_outputs));
        v210_3_outputs.push_back(v211_3);
      }
      const Space v210_3 = join_outputs(std::move(v210_3_outputs));
      v209_2_outputs.push_back(v210_3);
    }
    const Space v209_2 = join_outputs(std::move(v209_2_outputs));
    v64_160_outputs.push_back(v209_2);
  }
  const Space v64_160 = join_outputs(std::move(v64_160_outputs));
  const auto v64_177_branches = branches(c,v64_160);
  std::vector<Space> v64_177_outputs;
  v64_177_outputs.reserve(v64_177_branches.size());
  for (const auto& v64_177_branch : v64_177_branches) {
    const Path v64_177_head{v64_177_branch.first};
    const Space& v64_177_tail = v64_177_branch.second;
    const auto v217_2_branches = branches(c,v64_177_tail);
    std::vector<Space> v217_2_outputs;
    v217_2_outputs.reserve(v217_2_branches.size());
    for (const auto& v217_2_branch : v217_2_branches) {
      const Path v217_2_head{v217_2_branch.first};
      const Space& v217_2_tail = v217_2_branch.second;
      const auto v218_2_branches = branches(c,v217_2_tail);
      std::vector<Space> v218_2_outputs;
      v218_2_outputs.reserve(v218_2_branches.size());
      for (const auto& v218_2_branch : v218_2_branches) {
        const Path v218_2_head{v218_2_branch.first};
        const Space& v218_2_tail = v218_2_branch.second;
        const auto v219_2_branches = branches(c,v218_2_tail);
        std::vector<Space> v219_2_outputs;
        v219_2_outputs.reserve(v219_2_branches.size());
        for (const auto& v219_2_branch : v219_2_branches) {
          const Path v219_2_head{v219_2_branch.first};
          const Space& v219_2_tail = v219_2_branch.second;
          const Space v220_2 = routine_43(c, constant_1, constant_66);
          const Space v220_3 = routine_43(c, constant_3, constant_67);
          const Space v220_4 = unite(v220_2,v220_3);
          const Space v220_5 = routine_43(c, constant_5, constant_68);
          const Space v220_6 = unite(v220_4,v220_5);
          const Space v220_7 = routine_43(c, constant_7, constant_69);
          const Space v220_8 = unite(v220_6,v220_7);
          const Space v220_9 = routine_43(c, constant_9, constant_70);
          const Space v220_10 = unite(v220_8,v220_9);
          const Space v220_11 = routine_43(c, constant_11, constant_71);
          const Space v220_12 = unite(v220_10,v220_11);
          const Space v220_13 = routine_43(c, constant_13, constant_72);
          const Space v220_14 = unite(v220_12,v220_13);
          const Space v220_15 = routine_43(c, constant_15, constant_73);
          const Space v220_16 = unite(v220_14,v220_15);
          const Space v220_17 = routine_43(c, constant_17, constant_74);
          const Space v220_18 = unite(v220_16,v220_17);
          const Space v220_19 = routine_43(c, constant_19, constant_75);
          const Space v220_20 = unite(v220_18,v220_19);
          const Space v220_21 = routine_43(c, constant_21, constant_76);
          const Space v220_22 = unite(v220_20,v220_21);
          const Space v220_23 = routine_43(c, constant_23, constant_77);
          const Space v220_24 = unite(v220_22,v220_23);
          const Space v220_25 = routine_43(c, constant_25, constant_78);
          const Space v220_26 = unite(v220_24,v220_25);
          const Space v220_27 = routine_43(c, constant_27, constant_79);
          const Space v220_28 = unite(v220_26,v220_27);
          const Space v220_29 = routine_43(c, constant_29, constant_80);
          const Space v220_30 = unite(v220_28,v220_29);
          const Space v220_31 = routine_43(c, constant_81, constant_82);
          const Space v220_32 = unite(v220_30,v220_31);
          const Space v220_33 = unwrap(v220_32,p1);
          const Space v220_34 = unwrap(v220_33,v64_177_head);
          const Space v220_35 = unwrap(v220_34,v217_2_head);
          const Space v220_36 = unwrap(v220_35,v218_2_head);
          const Space v220_37 = unwrap(v220_36,v219_2_head);
          const Space v220_38 = unwrap(v220_37,p1);
          const auto v220_39_branches = branches(c,v220_38);
          std::vector<Space> v220_39_outputs;
          v220_39_outputs.reserve(v220_39_branches.size());
          for (const auto& v220_39_branch : v220_39_branches) {
            const Path v220_39_head{v220_39_branch.first};
            const Space& v220_39_tail = v220_39_branch.second;
            const auto v221_2_branches = branches(c,v220_39_tail);
            std::vector<Space> v221_2_outputs;
            v221_2_outputs.reserve(v221_2_branches.size());
            for (const auto& v221_2_branch : v221_2_branches) {
              const Path v221_2_head{v221_2_branch.first};
              const Space& v221_2_tail = v221_2_branch.second;
              const Path v222_2 = concat_path(v220_39_head,v221_2_head);
              const auto v222_3_branches = branches(c,v221_2_tail);
              std::vector<Space> v222_3_outputs;
              v222_3_outputs.reserve(v222_3_branches.size());
              for (const auto& v222_3_branch : v222_3_branches) {
                const Path v222_3_head{v222_3_branch.first};
                const Space& v222_3_tail = v222_3_branch.second;
                const Path v223_2 = concat_path(v222_2,v222_3_head);
                const auto v223_3_branches = branches(c,v222_3_tail);
                std::vector<Space> v223_3_outputs;
                v223_3_outputs.reserve(v223_3_branches.size());
                for (const auto& v223_3_branch : v223_3_branches) {
                  const Path v223_3_head{v223_3_branch.first};
                  const Space& v223_3_tail = v223_3_branch.second;
                  const Path v224_2 = concat_path(v223_2,v223_3_head);
                  const Space v224_3 = routine_44(c, v224_2, v223_3_tail, v219_2_tail);
                  v223_3_outputs.push_back(v224_3);
                }
                const Space v223_3 = join_outputs(std::move(v223_3_outputs));
                v222_3_outputs.push_back(v223_3);
              }
              const Space v222_3 = join_outputs(std::move(v222_3_outputs));
              v221_2_outputs.push_back(v222_3);
            }
            const Space v221_2 = join_outputs(std::move(v221_2_outputs));
            v220_39_outputs.push_back(v221_2);
          }
          const Space v220_39 = join_outputs(std::move(v220_39_outputs));
          v219_2_outputs.push_back(v220_39);
        }
        const Space v219_2 = join_outputs(std::move(v219_2_outputs));
        v218_2_outputs.push_back(v219_2);
      }
      const Space v218_2 = join_outputs(std::move(v218_2_outputs));
      v217_2_outputs.push_back(v218_2);
    }
    const Space v217_2 = join_outputs(std::move(v217_2_outputs));
    v64_177_outputs.push_back(v217_2);
  }
  const Space v64_177 = join_outputs(std::move(v64_177_outputs));
  return v64_177;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0) {
  const auto v226_2_branches = branches(c,s0);
  std::vector<Space> v226_2_outputs;
  v226_2_outputs.reserve(v226_2_branches.size());
  for (const auto& v226_2_branch : v226_2_branches) {
    const Path v226_2_head{v226_2_branch.first};
    const Space& v226_2_tail = v226_2_branch.second;
    const auto v227_2_branches = branches(c,v226_2_tail);
    std::vector<Space> v227_2_outputs;
    v227_2_outputs.reserve(v227_2_branches.size());
    for (const auto& v227_2_branch : v227_2_branches) {
      const Path v227_2_head{v227_2_branch.first};
      const Space& v227_2_tail = v227_2_branch.second;
      const Path v228_2 = concat_path(v226_2_head,v227_2_head);
      const auto v228_3_branches = branches(c,v227_2_tail);
      std::vector<Space> v228_3_outputs;
      v228_3_outputs.reserve(v228_3_branches.size());
      for (const auto& v228_3_branch : v228_3_branches) {
        const Path v228_3_head{v228_3_branch.first};
        const Space& v228_3_tail = v228_3_branch.second;
        const Path v229_2 = concat_path(v228_2,v228_3_head);
        const auto v229_3_branches = branches(c,v228_3_tail);
        std::vector<Space> v229_3_outputs;
        v229_3_outputs.reserve(v229_3_branches.size());
        for (const auto& v229_3_branch : v229_3_branches) {
          const Path v229_3_head{v229_3_branch.first};
          const Space& v229_3_tail = v229_3_branch.second;
          const Path v230_2 = concat_path(v229_2,v229_3_head);
          const auto v230_3_branches = branches(c,v229_3_tail);
          std::vector<Space> v230_3_outputs;
          v230_3_outputs.reserve(v230_3_branches.size());
          for (const auto& v230_3_branch : v230_3_branches) {
            const Path v230_3_head{v230_3_branch.first};
            const Space& v230_3_tail = v230_3_branch.second;
            const auto v231_2_branches = branches(c,v230_3_tail);
            std::vector<Space> v231_2_outputs;
            v231_2_outputs.reserve(v231_2_branches.size());
            for (const auto& v231_2_branch : v231_2_branches) {
              const Path v231_2_head{v231_2_branch.first};
              const Space& v231_2_tail = v231_2_branch.second;
              const Path v232_2 = concat_path(v230_3_head,v231_2_head);
              const auto v232_3_branches = branches(c,v231_2_tail);
              std::vector<Space> v232_3_outputs;
              v232_3_outputs.reserve(v232_3_branches.size());
              for (const auto& v232_3_branch : v232_3_branches) {
                const Path v232_3_head{v232_3_branch.first};
                const Space& v232_3_tail = v232_3_branch.second;
                const Path v233_2 = concat_path(v232_2,v232_3_head);
                const auto v233_3_branches = branches(c,v232_3_tail);
                std::vector<Space> v233_3_outputs;
                v233_3_outputs.reserve(v233_3_branches.size());
                for (const auto& v233_3_branch : v233_3_branches) {
                  const Path v233_3_head{v233_3_branch.first};
                  const Space& v233_3_tail = v233_3_branch.second;
                  const Path v234_2 = concat_path(v233_2,v233_3_head);
                  const Space v234_3 = routine_45(c, v234_2, p0, v230_2, v233_3_tail);
                  v233_3_outputs.push_back(v234_3);
                }
                const Space v233_3 = join_outputs(std::move(v233_3_outputs));
                v232_3_outputs.push_back(v233_3);
              }
              const Space v232_3 = join_outputs(std::move(v232_3_outputs));
              v231_2_outputs.push_back(v232_3);
            }
            const Space v231_2 = join_outputs(std::move(v231_2_outputs));
            v230_3_outputs.push_back(v231_2);
          }
          const Space v230_3 = join_outputs(std::move(v230_3_outputs));
          v229_3_outputs.push_back(v230_3);
        }
        const Space v229_3 = join_outputs(std::move(v229_3_outputs));
        v228_3_outputs.push_back(v229_3);
      }
      const Space v228_3 = join_outputs(std::move(v228_3_outputs));
      v227_2_outputs.push_back(v228_3);
    }
    const Space v227_2 = join_outputs(std::move(v227_2_outputs));
    v226_2_outputs.push_back(v227_2);
  }
  const Space v226_2 = join_outputs(std::move(v226_2_outputs));
  return v226_2;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  const auto v236_2_branches = branches(c,s0);
  std::vector<Space> v236_2_outputs;
  v236_2_outputs.reserve(v236_2_branches.size());
  for (const auto& v236_2_branch : v236_2_branches) {
    const Path v236_2_head{v236_2_branch.first};
    const Space& v236_2_tail = v236_2_branch.second;
    const auto v237_2_branches = branches(c,v236_2_tail);
    std::vector<Space> v237_2_outputs;
    v237_2_outputs.reserve(v237_2_branches.size());
    for (const auto& v237_2_branch : v237_2_branches) {
      const Path v237_2_head{v237_2_branch.first};
      const Space& v237_2_tail = v237_2_branch.second;
      const Path v238_2 = concat_path(v236_2_head,v237_2_head);
      const auto v238_3_branches = branches(c,v237_2_tail);
      std::vector<Space> v238_3_outputs;
      v238_3_outputs.reserve(v238_3_branches.size());
      for (const auto& v238_3_branch : v238_3_branches) {
        const Path v238_3_head{v238_3_branch.first};
        const Space& v238_3_tail = v238_3_branch.second;
        const Path v239_2 = concat_path(v238_2,v238_3_head);
        const auto v239_3_branches = branches(c,v238_3_tail);
        std::vector<Space> v239_3_outputs;
        v239_3_outputs.reserve(v239_3_branches.size());
        for (const auto& v239_3_branch : v239_3_branches) {
          const Path v239_3_head{v239_3_branch.first};
          const Space& v239_3_tail = v239_3_branch.second;
          const Path v240_2 = concat_path(v239_2,v239_3_head);
          const auto v240_3_branches = branches(c,v239_3_tail);
          std::vector<Space> v240_3_outputs;
          v240_3_outputs.reserve(v240_3_branches.size());
          for (const auto& v240_3_branch : v240_3_branches) {
            const Path v240_3_head{v240_3_branch.first};
            const Space& v240_3_tail = v240_3_branch.second;
            const auto v241_2_branches = branches(c,v240_3_tail);
            std::vector<Space> v241_2_outputs;
            v241_2_outputs.reserve(v241_2_branches.size());
            for (const auto& v241_2_branch : v241_2_branches) {
              const Path v241_2_head{v241_2_branch.first};
              const Space& v241_2_tail = v241_2_branch.second;
              const Path v242_2 = concat_path(v240_3_head,v241_2_head);
              const auto v242_3_branches = branches(c,v241_2_tail);
              std::vector<Space> v242_3_outputs;
              v242_3_outputs.reserve(v242_3_branches.size());
              for (const auto& v242_3_branch : v242_3_branches) {
                const Path v242_3_head{v242_3_branch.first};
                const Space& v242_3_tail = v242_3_branch.second;
                const Path v243_2 = concat_path(v242_2,v242_3_head);
                const auto v243_3_branches = branches(c,v242_3_tail);
                std::vector<Space> v243_3_outputs;
                v243_3_outputs.reserve(v243_3_branches.size());
                for (const auto& v243_3_branch : v243_3_branches) {
                  const Path v243_3_head{v243_3_branch.first};
                  const Space& v243_3_tail = v243_3_branch.second;
                  const Path v244_2 = concat_path(v243_2,v243_3_head);
                  const Space v244_3 = routine_46(c, v244_2, p0, v240_2, v243_3_tail);
                  v243_3_outputs.push_back(v244_3);
                }
                const Space v243_3 = join_outputs(std::move(v243_3_outputs));
                v242_3_outputs.push_back(v243_3);
              }
              const Space v242_3 = join_outputs(std::move(v242_3_outputs));
              v241_2_outputs.push_back(v242_3);
            }
            const Space v241_2 = join_outputs(std::move(v241_2_outputs));
            v240_3_outputs.push_back(v241_2);
          }
          const Space v240_3 = join_outputs(std::move(v240_3_outputs));
          v239_3_outputs.push_back(v240_3);
        }
        const Space v239_3 = join_outputs(std::move(v239_3_outputs));
        v238_3_outputs.push_back(v239_3);
      }
      const Space v238_3 = join_outputs(std::move(v238_3_outputs));
      v237_2_outputs.push_back(v238_3);
    }
    const Space v237_2 = join_outputs(std::move(v237_2_outputs));
    v236_2_outputs.push_back(v237_2);
  }
  const Space v236_2 = join_outputs(std::move(v236_2_outputs));
  return v236_2;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0) {
  const auto v246_2_branches = branches(c,s0);
  std::vector<Space> v246_2_outputs;
  v246_2_outputs.reserve(v246_2_branches.size());
  for (const auto& v246_2_branch : v246_2_branches) {
    const Path v246_2_head{v246_2_branch.first};
    const Space& v246_2_tail = v246_2_branch.second;
    const auto v247_2_branches = branches(c,v246_2_tail);
    std::vector<Space> v247_2_outputs;
    v247_2_outputs.reserve(v247_2_branches.size());
    for (const auto& v247_2_branch : v247_2_branches) {
      const Path v247_2_head{v247_2_branch.first};
      const Space& v247_2_tail = v247_2_branch.second;
      const Path v248_2 = concat_path(v246_2_head,v247_2_head);
      const auto v248_3_branches = branches(c,v247_2_tail);
      std::vector<Space> v248_3_outputs;
      v248_3_outputs.reserve(v248_3_branches.size());
      for (const auto& v248_3_branch : v248_3_branches) {
        const Path v248_3_head{v248_3_branch.first};
        const Space& v248_3_tail = v248_3_branch.second;
        const Path v249_2 = concat_path(v248_2,v248_3_head);
        const auto v249_3_branches = branches(c,v248_3_tail);
        std::vector<Space> v249_3_outputs;
        v249_3_outputs.reserve(v249_3_branches.size());
        for (const auto& v249_3_branch : v249_3_branches) {
          const Path v249_3_head{v249_3_branch.first};
          const Space& v249_3_tail = v249_3_branch.second;
          const Path v250_2 = concat_path(v249_2,v249_3_head);
          const auto v250_3_branches = branches(c,v249_3_tail);
          std::vector<Space> v250_3_outputs;
          v250_3_outputs.reserve(v250_3_branches.size());
          for (const auto& v250_3_branch : v250_3_branches) {
            const Path v250_3_head{v250_3_branch.first};
            const Space& v250_3_tail = v250_3_branch.second;
            const auto v251_2_branches = branches(c,v250_3_tail);
            std::vector<Space> v251_2_outputs;
            v251_2_outputs.reserve(v251_2_branches.size());
            for (const auto& v251_2_branch : v251_2_branches) {
              const Path v251_2_head{v251_2_branch.first};
              const Space& v251_2_tail = v251_2_branch.second;
              const Path v252_2 = concat_path(v250_3_head,v251_2_head);
              const auto v252_3_branches = branches(c,v251_2_tail);
              std::vector<Space> v252_3_outputs;
              v252_3_outputs.reserve(v252_3_branches.size());
              for (const auto& v252_3_branch : v252_3_branches) {
                const Path v252_3_head{v252_3_branch.first};
                const Space& v252_3_tail = v252_3_branch.second;
                const Path v253_2 = concat_path(v252_2,v252_3_head);
                const auto v253_3_branches = branches(c,v252_3_tail);
                std::vector<Space> v253_3_outputs;
                v253_3_outputs.reserve(v253_3_branches.size());
                for (const auto& v253_3_branch : v253_3_branches) {
                  const Path v253_3_head{v253_3_branch.first};
                  const Space& v253_3_tail = v253_3_branch.second;
                  const Path v254_2 = concat_path(v253_2,v253_3_head);
                  const Space v254_3 = routine_47(c, v254_2, p0, v250_2, v253_3_tail);
                  v253_3_outputs.push_back(v254_3);
                }
                const Space v253_3 = join_outputs(std::move(v253_3_outputs));
                v252_3_outputs.push_back(v253_3);
              }
              const Space v252_3 = join_outputs(std::move(v252_3_outputs));
              v251_2_outputs.push_back(v252_3);
            }
            const Space v251_2 = join_outputs(std::move(v251_2_outputs));
            v250_3_outputs.push_back(v251_2);
          }
          const Space v250_3 = join_outputs(std::move(v250_3_outputs));
          v249_3_outputs.push_back(v250_3);
        }
        const Space v249_3 = join_outputs(std::move(v249_3_outputs));
        v248_3_outputs.push_back(v249_3);
      }
      const Space v248_3 = join_outputs(std::move(v248_3_outputs));
      v247_2_outputs.push_back(v248_3);
    }
    const Space v247_2 = join_outputs(std::move(v247_2_outputs));
    v246_2_outputs.push_back(v247_2);
  }
  const Space v246_2 = join_outputs(std::move(v246_2_outputs));
  return v246_2;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  const auto v256_2_branches = branches(c,s0);
  std::vector<Space> v256_2_outputs;
  v256_2_outputs.reserve(v256_2_branches.size());
  for (const auto& v256_2_branch : v256_2_branches) {
    const Path v256_2_head{v256_2_branch.first};
    const Space& v256_2_tail = v256_2_branch.second;
    const auto v257_2_branches = branches(c,v256_2_tail);
    std::vector<Space> v257_2_outputs;
    v257_2_outputs.reserve(v257_2_branches.size());
    for (const auto& v257_2_branch : v257_2_branches) {
      const Path v257_2_head{v257_2_branch.first};
      const Space& v257_2_tail = v257_2_branch.second;
      const Path v258_2 = concat_path(v256_2_head,v257_2_head);
      const auto v258_3_branches = branches(c,v257_2_tail);
      std::vector<Space> v258_3_outputs;
      v258_3_outputs.reserve(v258_3_branches.size());
      for (const auto& v258_3_branch : v258_3_branches) {
        const Path v258_3_head{v258_3_branch.first};
        const Space& v258_3_tail = v258_3_branch.second;
        const Path v259_2 = concat_path(v258_2,v258_3_head);
        const auto v259_3_branches = branches(c,v258_3_tail);
        std::vector<Space> v259_3_outputs;
        v259_3_outputs.reserve(v259_3_branches.size());
        for (const auto& v259_3_branch : v259_3_branches) {
          const Path v259_3_head{v259_3_branch.first};
          const Space& v259_3_tail = v259_3_branch.second;
          const Path v260_2 = concat_path(v259_2,v259_3_head);
          const auto v260_3_branches = branches(c,v259_3_tail);
          std::vector<Space> v260_3_outputs;
          v260_3_outputs.reserve(v260_3_branches.size());
          for (const auto& v260_3_branch : v260_3_branches) {
            const Path v260_3_head{v260_3_branch.first};
            const Space& v260_3_tail = v260_3_branch.second;
            const auto v261_2_branches = branches(c,v260_3_tail);
            std::vector<Space> v261_2_outputs;
            v261_2_outputs.reserve(v261_2_branches.size());
            for (const auto& v261_2_branch : v261_2_branches) {
              const Path v261_2_head{v261_2_branch.first};
              const Space& v261_2_tail = v261_2_branch.second;
              const Path v262_2 = concat_path(v260_3_head,v261_2_head);
              const auto v262_3_branches = branches(c,v261_2_tail);
              std::vector<Space> v262_3_outputs;
              v262_3_outputs.reserve(v262_3_branches.size());
              for (const auto& v262_3_branch : v262_3_branches) {
                const Path v262_3_head{v262_3_branch.first};
                const Space& v262_3_tail = v262_3_branch.second;
                const Path v263_2 = concat_path(v262_2,v262_3_head);
                const auto v263_3_branches = branches(c,v262_3_tail);
                std::vector<Space> v263_3_outputs;
                v263_3_outputs.reserve(v263_3_branches.size());
                for (const auto& v263_3_branch : v263_3_branches) {
                  const Path v263_3_head{v263_3_branch.first};
                  const Space& v263_3_tail = v263_3_branch.second;
                  const Path v264_2 = concat_path(v263_2,v263_3_head);
                  const Space v264_3 = routine_48(c, v264_2, p0, v260_2, v263_3_tail);
                  v263_3_outputs.push_back(v264_3);
                }
                const Space v263_3 = join_outputs(std::move(v263_3_outputs));
                v262_3_outputs.push_back(v263_3);
              }
              const Space v262_3 = join_outputs(std::move(v262_3_outputs));
              v261_2_outputs.push_back(v262_3);
            }
            const Space v261_2 = join_outputs(std::move(v261_2_outputs));
            v260_3_outputs.push_back(v261_2);
          }
          const Space v260_3 = join_outputs(std::move(v260_3_outputs));
          v259_3_outputs.push_back(v260_3);
        }
        const Space v259_3 = join_outputs(std::move(v259_3_outputs));
        v258_3_outputs.push_back(v259_3);
      }
      const Space v258_3 = join_outputs(std::move(v258_3_outputs));
      v257_2_outputs.push_back(v258_3);
    }
    const Space v257_2 = join_outputs(std::move(v257_2_outputs));
    v256_2_outputs.push_back(v257_2);
  }
  const Space v256_2 = join_outputs(std::move(v256_2_outputs));
  return v256_2;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0) {
  const auto v266_2_branches = branches(c,s0);
  std::vector<Space> v266_2_outputs;
  v266_2_outputs.reserve(v266_2_branches.size());
  for (const auto& v266_2_branch : v266_2_branches) {
    const Path v266_2_head{v266_2_branch.first};
    const Space& v266_2_tail = v266_2_branch.second;
    const auto v267_2_branches = branches(c,v266_2_tail);
    std::vector<Space> v267_2_outputs;
    v267_2_outputs.reserve(v267_2_branches.size());
    for (const auto& v267_2_branch : v267_2_branches) {
      const Path v267_2_head{v267_2_branch.first};
      const Space& v267_2_tail = v267_2_branch.second;
      const Path v268_2 = concat_path(v266_2_head,v267_2_head);
      const auto v268_3_branches = branches(c,v267_2_tail);
      std::vector<Space> v268_3_outputs;
      v268_3_outputs.reserve(v268_3_branches.size());
      for (const auto& v268_3_branch : v268_3_branches) {
        const Path v268_3_head{v268_3_branch.first};
        const Space& v268_3_tail = v268_3_branch.second;
        const Path v269_2 = concat_path(v268_2,v268_3_head);
        const auto v269_3_branches = branches(c,v268_3_tail);
        std::vector<Space> v269_3_outputs;
        v269_3_outputs.reserve(v269_3_branches.size());
        for (const auto& v269_3_branch : v269_3_branches) {
          const Path v269_3_head{v269_3_branch.first};
          const Space& v269_3_tail = v269_3_branch.second;
          const Path v270_2 = concat_path(v269_2,v269_3_head);
          const auto v270_3_branches = branches(c,v269_3_tail);
          std::vector<Space> v270_3_outputs;
          v270_3_outputs.reserve(v270_3_branches.size());
          for (const auto& v270_3_branch : v270_3_branches) {
            const Path v270_3_head{v270_3_branch.first};
            const Space& v270_3_tail = v270_3_branch.second;
            const auto v271_2_branches = branches(c,v270_3_tail);
            std::vector<Space> v271_2_outputs;
            v271_2_outputs.reserve(v271_2_branches.size());
            for (const auto& v271_2_branch : v271_2_branches) {
              const Path v271_2_head{v271_2_branch.first};
              const Space& v271_2_tail = v271_2_branch.second;
              const Path v272_2 = concat_path(v270_3_head,v271_2_head);
              const auto v272_3_branches = branches(c,v271_2_tail);
              std::vector<Space> v272_3_outputs;
              v272_3_outputs.reserve(v272_3_branches.size());
              for (const auto& v272_3_branch : v272_3_branches) {
                const Path v272_3_head{v272_3_branch.first};
                const Space& v272_3_tail = v272_3_branch.second;
                const Path v273_2 = concat_path(v272_2,v272_3_head);
                const auto v273_3_branches = branches(c,v272_3_tail);
                std::vector<Space> v273_3_outputs;
                v273_3_outputs.reserve(v273_3_branches.size());
                for (const auto& v273_3_branch : v273_3_branches) {
                  const Path v273_3_head{v273_3_branch.first};
                  const Space& v273_3_tail = v273_3_branch.second;
                  const Path v274_2 = concat_path(v273_2,v273_3_head);
                  const Space v274_3 = routine_49(c, v274_2, p0, v270_2, v273_3_tail);
                  v273_3_outputs.push_back(v274_3);
                }
                const Space v273_3 = join_outputs(std::move(v273_3_outputs));
                v272_3_outputs.push_back(v273_3);
              }
              const Space v272_3 = join_outputs(std::move(v272_3_outputs));
              v271_2_outputs.push_back(v272_3);
            }
            const Space v271_2 = join_outputs(std::move(v271_2_outputs));
            v270_3_outputs.push_back(v271_2);
          }
          const Space v270_3 = join_outputs(std::move(v270_3_outputs));
          v269_3_outputs.push_back(v270_3);
        }
        const Space v269_3 = join_outputs(std::move(v269_3_outputs));
        v268_3_outputs.push_back(v269_3);
      }
      const Space v268_3 = join_outputs(std::move(v268_3_outputs));
      v267_2_outputs.push_back(v268_3);
    }
    const Space v267_2 = join_outputs(std::move(v267_2_outputs));
    v266_2_outputs.push_back(v267_2);
  }
  const Space v266_2 = join_outputs(std::move(v266_2_outputs));
  return v266_2;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0) {
  const auto v276_2_branches = branches(c,s0);
  std::vector<Space> v276_2_outputs;
  v276_2_outputs.reserve(v276_2_branches.size());
  for (const auto& v276_2_branch : v276_2_branches) {
    const Path v276_2_head{v276_2_branch.first};
    const Space& v276_2_tail = v276_2_branch.second;
    const auto v277_2_branches = branches(c,v276_2_tail);
    std::vector<Space> v277_2_outputs;
    v277_2_outputs.reserve(v277_2_branches.size());
    for (const auto& v277_2_branch : v277_2_branches) {
      const Path v277_2_head{v277_2_branch.first};
      const Space& v277_2_tail = v277_2_branch.second;
      const Path v278_2 = concat_path(v276_2_head,v277_2_head);
      const auto v278_3_branches = branches(c,v277_2_tail);
      std::vector<Space> v278_3_outputs;
      v278_3_outputs.reserve(v278_3_branches.size());
      for (const auto& v278_3_branch : v278_3_branches) {
        const Path v278_3_head{v278_3_branch.first};
        const Space& v278_3_tail = v278_3_branch.second;
        const Path v279_2 = concat_path(v278_2,v278_3_head);
        const auto v279_3_branches = branches(c,v278_3_tail);
        std::vector<Space> v279_3_outputs;
        v279_3_outputs.reserve(v279_3_branches.size());
        for (const auto& v279_3_branch : v279_3_branches) {
          const Path v279_3_head{v279_3_branch.first};
          const Space& v279_3_tail = v279_3_branch.second;
          const Path v280_2 = concat_path(v279_2,v279_3_head);
          const auto v280_3_branches = branches(c,v279_3_tail);
          std::vector<Space> v280_3_outputs;
          v280_3_outputs.reserve(v280_3_branches.size());
          for (const auto& v280_3_branch : v280_3_branches) {
            const Path v280_3_head{v280_3_branch.first};
            const Space& v280_3_tail = v280_3_branch.second;
            const auto v281_2_branches = branches(c,v280_3_tail);
            std::vector<Space> v281_2_outputs;
            v281_2_outputs.reserve(v281_2_branches.size());
            for (const auto& v281_2_branch : v281_2_branches) {
              const Path v281_2_head{v281_2_branch.first};
              const Space& v281_2_tail = v281_2_branch.second;
              const Path v282_2 = concat_path(v280_3_head,v281_2_head);
              const auto v282_3_branches = branches(c,v281_2_tail);
              std::vector<Space> v282_3_outputs;
              v282_3_outputs.reserve(v282_3_branches.size());
              for (const auto& v282_3_branch : v282_3_branches) {
                const Path v282_3_head{v282_3_branch.first};
                const Space& v282_3_tail = v282_3_branch.second;
                const Path v283_2 = concat_path(v282_2,v282_3_head);
                const auto v283_3_branches = branches(c,v282_3_tail);
                std::vector<Space> v283_3_outputs;
                v283_3_outputs.reserve(v283_3_branches.size());
                for (const auto& v283_3_branch : v283_3_branches) {
                  const Path v283_3_head{v283_3_branch.first};
                  const Space& v283_3_tail = v283_3_branch.second;
                  const Path v284_2 = concat_path(v283_2,v283_3_head);
                  const Space v284_3 = routine_50(c, v284_2, p0, v280_2, v283_3_tail);
                  v283_3_outputs.push_back(v284_3);
                }
                const Space v283_3 = join_outputs(std::move(v283_3_outputs));
                v282_3_outputs.push_back(v283_3);
              }
              const Space v282_3 = join_outputs(std::move(v282_3_outputs));
              v281_2_outputs.push_back(v282_3);
            }
            const Space v281_2 = join_outputs(std::move(v281_2_outputs));
            v280_3_outputs.push_back(v281_2);
          }
          const Space v280_3 = join_outputs(std::move(v280_3_outputs));
          v279_3_outputs.push_back(v280_3);
        }
        const Space v279_3 = join_outputs(std::move(v279_3_outputs));
        v278_3_outputs.push_back(v279_3);
      }
      const Space v278_3 = join_outputs(std::move(v278_3_outputs));
      v277_2_outputs.push_back(v278_3);
    }
    const Space v277_2 = join_outputs(std::move(v277_2_outputs));
    v276_2_outputs.push_back(v277_2);
  }
  const Space v276_2 = join_outputs(std::move(v276_2_outputs));
  return v276_2;
}

static Space routine_21(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0) {
  const auto v286_2_branches = branches(c,s0);
  std::vector<Space> v286_2_outputs;
  v286_2_outputs.reserve(v286_2_branches.size());
  for (const auto& v286_2_branch : v286_2_branches) {
    const Path v286_2_head{v286_2_branch.first};
    const Space& v286_2_tail = v286_2_branch.second;
    const auto v287_2_branches = branches(c,v286_2_tail);
    std::vector<Space> v287_2_outputs;
    v287_2_outputs.reserve(v287_2_branches.size());
    for (const auto& v287_2_branch : v287_2_branches) {
      const Path v287_2_head{v287_2_branch.first};
      const Space& v287_2_tail = v287_2_branch.second;
      const Path v288_2 = concat_path(v286_2_head,v287_2_head);
      const auto v288_3_branches = branches(c,v287_2_tail);
      std::vector<Space> v288_3_outputs;
      v288_3_outputs.reserve(v288_3_branches.size());
      for (const auto& v288_3_branch : v288_3_branches) {
        const Path v288_3_head{v288_3_branch.first};
        const Space& v288_3_tail = v288_3_branch.second;
        const Path v289_2 = concat_path(v288_2,v288_3_head);
        const auto v289_3_branches = branches(c,v288_3_tail);
        std::vector<Space> v289_3_outputs;
        v289_3_outputs.reserve(v289_3_branches.size());
        for (const auto& v289_3_branch : v289_3_branches) {
          const Path v289_3_head{v289_3_branch.first};
          const Space& v289_3_tail = v289_3_branch.second;
          const Path v290_2 = concat_path(v289_2,v289_3_head);
          const auto v290_3_branches = branches(c,v289_3_tail);
          std::vector<Space> v290_3_outputs;
          v290_3_outputs.reserve(v290_3_branches.size());
          for (const auto& v290_3_branch : v290_3_branches) {
            const Path v290_3_head{v290_3_branch.first};
            const Space& v290_3_tail = v290_3_branch.second;
            const auto v291_2_branches = branches(c,v290_3_tail);
            std::vector<Space> v291_2_outputs;
            v291_2_outputs.reserve(v291_2_branches.size());
            for (const auto& v291_2_branch : v291_2_branches) {
              const Path v291_2_head{v291_2_branch.first};
              const Space& v291_2_tail = v291_2_branch.second;
              const Path v292_2 = concat_path(v290_3_head,v291_2_head);
              const auto v292_3_branches = branches(c,v291_2_tail);
              std::vector<Space> v292_3_outputs;
              v292_3_outputs.reserve(v292_3_branches.size());
              for (const auto& v292_3_branch : v292_3_branches) {
                const Path v292_3_head{v292_3_branch.first};
                const Space& v292_3_tail = v292_3_branch.second;
                const Path v293_2 = concat_path(v292_2,v292_3_head);
                const auto v293_3_branches = branches(c,v292_3_tail);
                std::vector<Space> v293_3_outputs;
                v293_3_outputs.reserve(v293_3_branches.size());
                for (const auto& v293_3_branch : v293_3_branches) {
                  const Path v293_3_head{v293_3_branch.first};
                  const Space& v293_3_tail = v293_3_branch.second;
                  const Path v294_2 = concat_path(v293_2,v293_3_head);
                  const Space v294_3 = routine_51(c, v294_2, p0, v290_2, v293_3_tail);
                  v293_3_outputs.push_back(v294_3);
                }
                const Space v293_3 = join_outputs(std::move(v293_3_outputs));
                v292_3_outputs.push_back(v293_3);
              }
              const Space v292_3 = join_outputs(std::move(v292_3_outputs));
              v291_2_outputs.push_back(v292_3);
            }
            const Space v291_2 = join_outputs(std::move(v291_2_outputs));
            v290_3_outputs.push_back(v291_2);
          }
          const Space v290_3 = join_outputs(std::move(v290_3_outputs));
          v289_3_outputs.push_back(v290_3);
        }
        const Space v289_3 = join_outputs(std::move(v289_3_outputs));
        v288_3_outputs.push_back(v289_3);
      }
      const Space v288_3 = join_outputs(std::move(v288_3_outputs));
      v287_2_outputs.push_back(v288_3);
    }
    const Space v287_2 = join_outputs(std::move(v287_2_outputs));
    v286_2_outputs.push_back(v287_2);
  }
  const Space v286_2 = join_outputs(std::move(v286_2_outputs));
  return v286_2;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_24(Context& c, const Path& p0, const Space& s0) {
  const auto v296_2_branches = branches(c,s0);
  std::vector<Space> v296_2_outputs;
  v296_2_outputs.reserve(v296_2_branches.size());
  for (const auto& v296_2_branch : v296_2_branches) {
    const Path v296_2_head{v296_2_branch.first};
    const Space& v296_2_tail = v296_2_branch.second;
    const auto v297_2_branches = branches(c,v296_2_tail);
    std::vector<Space> v297_2_outputs;
    v297_2_outputs.reserve(v297_2_branches.size());
    for (const auto& v297_2_branch : v297_2_branches) {
      const Path v297_2_head{v297_2_branch.first};
      const Space& v297_2_tail = v297_2_branch.second;
      const Path v298_2 = concat_path(v296_2_head,v297_2_head);
      const auto v298_3_branches = branches(c,v297_2_tail);
      std::vector<Space> v298_3_outputs;
      v298_3_outputs.reserve(v298_3_branches.size());
      for (const auto& v298_3_branch : v298_3_branches) {
        const Path v298_3_head{v298_3_branch.first};
        const Space& v298_3_tail = v298_3_branch.second;
        const Path v299_2 = concat_path(v298_2,v298_3_head);
        const auto v299_3_branches = branches(c,v298_3_tail);
        std::vector<Space> v299_3_outputs;
        v299_3_outputs.reserve(v299_3_branches.size());
        for (const auto& v299_3_branch : v299_3_branches) {
          const Path v299_3_head{v299_3_branch.first};
          const Space& v299_3_tail = v299_3_branch.second;
          const Path v300_2 = concat_path(v299_2,v299_3_head);
          const auto v300_3_branches = branches(c,v299_3_tail);
          std::vector<Space> v300_3_outputs;
          v300_3_outputs.reserve(v300_3_branches.size());
          for (const auto& v300_3_branch : v300_3_branches) {
            const Path v300_3_head{v300_3_branch.first};
            const Space& v300_3_tail = v300_3_branch.second;
            const auto v301_2_branches = branches(c,v300_3_tail);
            std::vector<Space> v301_2_outputs;
            v301_2_outputs.reserve(v301_2_branches.size());
            for (const auto& v301_2_branch : v301_2_branches) {
              const Path v301_2_head{v301_2_branch.first};
              const Space& v301_2_tail = v301_2_branch.second;
              const Path v302_2 = concat_path(v300_3_head,v301_2_head);
              const auto v302_3_branches = branches(c,v301_2_tail);
              std::vector<Space> v302_3_outputs;
              v302_3_outputs.reserve(v302_3_branches.size());
              for (const auto& v302_3_branch : v302_3_branches) {
                const Path v302_3_head{v302_3_branch.first};
                const Space& v302_3_tail = v302_3_branch.second;
                const Path v303_2 = concat_path(v302_2,v302_3_head);
                const auto v303_3_branches = branches(c,v302_3_tail);
                std::vector<Space> v303_3_outputs;
                v303_3_outputs.reserve(v303_3_branches.size());
                for (const auto& v303_3_branch : v303_3_branches) {
                  const Path v303_3_head{v303_3_branch.first};
                  const Space& v303_3_tail = v303_3_branch.second;
                  const Path v304_2 = concat_path(v303_2,v303_3_head);
                  const Space v304_3 = routine_52(c, v304_2, p0, v300_2, v303_3_tail);
                  v303_3_outputs.push_back(v304_3);
                }
                const Space v303_3 = join_outputs(std::move(v303_3_outputs));
                v302_3_outputs.push_back(v303_3);
              }
              const Space v302_3 = join_outputs(std::move(v302_3_outputs));
              v301_2_outputs.push_back(v302_3);
            }
            const Space v301_2 = join_outputs(std::move(v301_2_outputs));
            v300_3_outputs.push_back(v301_2);
          }
          const Space v300_3 = join_outputs(std::move(v300_3_outputs));
          v299_3_outputs.push_back(v300_3);
        }
        const Space v299_3 = join_outputs(std::move(v299_3_outputs));
        v298_3_outputs.push_back(v299_3);
      }
      const Space v298_3 = join_outputs(std::move(v298_3_outputs));
      v297_2_outputs.push_back(v298_3);
    }
    const Space v297_2 = join_outputs(std::move(v297_2_outputs));
    v296_2_outputs.push_back(v297_2);
  }
  const Space v296_2 = join_outputs(std::move(v296_2_outputs));
  return v296_2;
}

static Space routine_25(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_26(Context& c, const Path& p0, const Space& s0) {
  const auto v306_2_branches = branches(c,s0);
  std::vector<Space> v306_2_outputs;
  v306_2_outputs.reserve(v306_2_branches.size());
  for (const auto& v306_2_branch : v306_2_branches) {
    const Path v306_2_head{v306_2_branch.first};
    const Space& v306_2_tail = v306_2_branch.second;
    const auto v307_2_branches = branches(c,v306_2_tail);
    std::vector<Space> v307_2_outputs;
    v307_2_outputs.reserve(v307_2_branches.size());
    for (const auto& v307_2_branch : v307_2_branches) {
      const Path v307_2_head{v307_2_branch.first};
      const Space& v307_2_tail = v307_2_branch.second;
      const Path v308_2 = concat_path(v306_2_head,v307_2_head);
      const auto v308_3_branches = branches(c,v307_2_tail);
      std::vector<Space> v308_3_outputs;
      v308_3_outputs.reserve(v308_3_branches.size());
      for (const auto& v308_3_branch : v308_3_branches) {
        const Path v308_3_head{v308_3_branch.first};
        const Space& v308_3_tail = v308_3_branch.second;
        const Path v309_2 = concat_path(v308_2,v308_3_head);
        const auto v309_3_branches = branches(c,v308_3_tail);
        std::vector<Space> v309_3_outputs;
        v309_3_outputs.reserve(v309_3_branches.size());
        for (const auto& v309_3_branch : v309_3_branches) {
          const Path v309_3_head{v309_3_branch.first};
          const Space& v309_3_tail = v309_3_branch.second;
          const Path v310_2 = concat_path(v309_2,v309_3_head);
          const auto v310_3_branches = branches(c,v309_3_tail);
          std::vector<Space> v310_3_outputs;
          v310_3_outputs.reserve(v310_3_branches.size());
          for (const auto& v310_3_branch : v310_3_branches) {
            const Path v310_3_head{v310_3_branch.first};
            const Space& v310_3_tail = v310_3_branch.second;
            const auto v311_2_branches = branches(c,v310_3_tail);
            std::vector<Space> v311_2_outputs;
            v311_2_outputs.reserve(v311_2_branches.size());
            for (const auto& v311_2_branch : v311_2_branches) {
              const Path v311_2_head{v311_2_branch.first};
              const Space& v311_2_tail = v311_2_branch.second;
              const Path v312_2 = concat_path(v310_3_head,v311_2_head);
              const auto v312_3_branches = branches(c,v311_2_tail);
              std::vector<Space> v312_3_outputs;
              v312_3_outputs.reserve(v312_3_branches.size());
              for (const auto& v312_3_branch : v312_3_branches) {
                const Path v312_3_head{v312_3_branch.first};
                const Space& v312_3_tail = v312_3_branch.second;
                const Path v313_2 = concat_path(v312_2,v312_3_head);
                const auto v313_3_branches = branches(c,v312_3_tail);
                std::vector<Space> v313_3_outputs;
                v313_3_outputs.reserve(v313_3_branches.size());
                for (const auto& v313_3_branch : v313_3_branches) {
                  const Path v313_3_head{v313_3_branch.first};
                  const Space& v313_3_tail = v313_3_branch.second;
                  const Path v314_2 = concat_path(v313_2,v313_3_head);
                  const Space v314_3 = routine_53(c, v314_2, p0, v310_2, v313_3_tail);
                  v313_3_outputs.push_back(v314_3);
                }
                const Space v313_3 = join_outputs(std::move(v313_3_outputs));
                v312_3_outputs.push_back(v313_3);
              }
              const Space v312_3 = join_outputs(std::move(v312_3_outputs));
              v311_2_outputs.push_back(v312_3);
            }
            const Space v311_2 = join_outputs(std::move(v311_2_outputs));
            v310_3_outputs.push_back(v311_2);
          }
          const Space v310_3 = join_outputs(std::move(v310_3_outputs));
          v309_3_outputs.push_back(v310_3);
        }
        const Space v309_3 = join_outputs(std::move(v309_3_outputs));
        v308_3_outputs.push_back(v309_3);
      }
      const Space v308_3 = join_outputs(std::move(v308_3_outputs));
      v307_2_outputs.push_back(v308_3);
    }
    const Space v307_2 = join_outputs(std::move(v307_2_outputs));
    v306_2_outputs.push_back(v307_2);
  }
  const Space v306_2 = join_outputs(std::move(v306_2_outputs));
  return v306_2;
}

static Space routine_27(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  const auto v316_2_branches = branches(c,s0);
  std::vector<Space> v316_2_outputs;
  v316_2_outputs.reserve(v316_2_branches.size());
  for (const auto& v316_2_branch : v316_2_branches) {
    const Path v316_2_head{v316_2_branch.first};
    const Space& v316_2_tail = v316_2_branch.second;
    const auto v317_2_branches = branches(c,v316_2_tail);
    std::vector<Space> v317_2_outputs;
    v317_2_outputs.reserve(v317_2_branches.size());
    for (const auto& v317_2_branch : v317_2_branches) {
      const Path v317_2_head{v317_2_branch.first};
      const Space& v317_2_tail = v317_2_branch.second;
      const Path v318_2 = concat_path(v316_2_head,v317_2_head);
      const auto v318_3_branches = branches(c,v317_2_tail);
      std::vector<Space> v318_3_outputs;
      v318_3_outputs.reserve(v318_3_branches.size());
      for (const auto& v318_3_branch : v318_3_branches) {
        const Path v318_3_head{v318_3_branch.first};
        const Space& v318_3_tail = v318_3_branch.second;
        const Path v319_2 = concat_path(v318_2,v318_3_head);
        const auto v319_3_branches = branches(c,v318_3_tail);
        std::vector<Space> v319_3_outputs;
        v319_3_outputs.reserve(v319_3_branches.size());
        for (const auto& v319_3_branch : v319_3_branches) {
          const Path v319_3_head{v319_3_branch.first};
          const Space& v319_3_tail = v319_3_branch.second;
          const Path v320_2 = concat_path(v319_2,v319_3_head);
          const auto v320_3_branches = branches(c,v319_3_tail);
          std::vector<Space> v320_3_outputs;
          v320_3_outputs.reserve(v320_3_branches.size());
          for (const auto& v320_3_branch : v320_3_branches) {
            const Path v320_3_head{v320_3_branch.first};
            const Space& v320_3_tail = v320_3_branch.second;
            const auto v321_2_branches = branches(c,v320_3_tail);
            std::vector<Space> v321_2_outputs;
            v321_2_outputs.reserve(v321_2_branches.size());
            for (const auto& v321_2_branch : v321_2_branches) {
              const Path v321_2_head{v321_2_branch.first};
              const Space& v321_2_tail = v321_2_branch.second;
              const Path v322_2 = concat_path(v320_3_head,v321_2_head);
              const auto v322_3_branches = branches(c,v321_2_tail);
              std::vector<Space> v322_3_outputs;
              v322_3_outputs.reserve(v322_3_branches.size());
              for (const auto& v322_3_branch : v322_3_branches) {
                const Path v322_3_head{v322_3_branch.first};
                const Space& v322_3_tail = v322_3_branch.second;
                const Path v323_2 = concat_path(v322_2,v322_3_head);
                const auto v323_3_branches = branches(c,v322_3_tail);
                std::vector<Space> v323_3_outputs;
                v323_3_outputs.reserve(v323_3_branches.size());
                for (const auto& v323_3_branch : v323_3_branches) {
                  const Path v323_3_head{v323_3_branch.first};
                  const Space& v323_3_tail = v323_3_branch.second;
                  const Path v324_2 = concat_path(v323_2,v323_3_head);
                  const Space v324_3 = routine_54(c, v324_2, p0, v320_2, v323_3_tail);
                  v323_3_outputs.push_back(v324_3);
                }
                const Space v323_3 = join_outputs(std::move(v323_3_outputs));
                v322_3_outputs.push_back(v323_3);
              }
              const Space v322_3 = join_outputs(std::move(v322_3_outputs));
              v321_2_outputs.push_back(v322_3);
            }
            const Space v321_2 = join_outputs(std::move(v321_2_outputs));
            v320_3_outputs.push_back(v321_2);
          }
          const Space v320_3 = join_outputs(std::move(v320_3_outputs));
          v319_3_outputs.push_back(v320_3);
        }
        const Space v319_3 = join_outputs(std::move(v319_3_outputs));
        v318_3_outputs.push_back(v319_3);
      }
      const Space v318_3 = join_outputs(std::move(v318_3_outputs));
      v317_2_outputs.push_back(v318_3);
    }
    const Space v317_2 = join_outputs(std::move(v317_2_outputs));
    v316_2_outputs.push_back(v317_2);
  }
  const Space v316_2 = join_outputs(std::move(v316_2_outputs));
  return v316_2;
}

static Space routine_29(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_30(Context& c, const Path& p0, const Space& s0) {
  const auto v326_2_branches = branches(c,s0);
  std::vector<Space> v326_2_outputs;
  v326_2_outputs.reserve(v326_2_branches.size());
  for (const auto& v326_2_branch : v326_2_branches) {
    const Path v326_2_head{v326_2_branch.first};
    const Space& v326_2_tail = v326_2_branch.second;
    const auto v327_2_branches = branches(c,v326_2_tail);
    std::vector<Space> v327_2_outputs;
    v327_2_outputs.reserve(v327_2_branches.size());
    for (const auto& v327_2_branch : v327_2_branches) {
      const Path v327_2_head{v327_2_branch.first};
      const Space& v327_2_tail = v327_2_branch.second;
      const Path v328_2 = concat_path(v326_2_head,v327_2_head);
      const auto v328_3_branches = branches(c,v327_2_tail);
      std::vector<Space> v328_3_outputs;
      v328_3_outputs.reserve(v328_3_branches.size());
      for (const auto& v328_3_branch : v328_3_branches) {
        const Path v328_3_head{v328_3_branch.first};
        const Space& v328_3_tail = v328_3_branch.second;
        const Path v329_2 = concat_path(v328_2,v328_3_head);
        const auto v329_3_branches = branches(c,v328_3_tail);
        std::vector<Space> v329_3_outputs;
        v329_3_outputs.reserve(v329_3_branches.size());
        for (const auto& v329_3_branch : v329_3_branches) {
          const Path v329_3_head{v329_3_branch.first};
          const Space& v329_3_tail = v329_3_branch.second;
          const Path v330_2 = concat_path(v329_2,v329_3_head);
          const auto v330_3_branches = branches(c,v329_3_tail);
          std::vector<Space> v330_3_outputs;
          v330_3_outputs.reserve(v330_3_branches.size());
          for (const auto& v330_3_branch : v330_3_branches) {
            const Path v330_3_head{v330_3_branch.first};
            const Space& v330_3_tail = v330_3_branch.second;
            const auto v331_2_branches = branches(c,v330_3_tail);
            std::vector<Space> v331_2_outputs;
            v331_2_outputs.reserve(v331_2_branches.size());
            for (const auto& v331_2_branch : v331_2_branches) {
              const Path v331_2_head{v331_2_branch.first};
              const Space& v331_2_tail = v331_2_branch.second;
              const Path v332_2 = concat_path(v330_3_head,v331_2_head);
              const auto v332_3_branches = branches(c,v331_2_tail);
              std::vector<Space> v332_3_outputs;
              v332_3_outputs.reserve(v332_3_branches.size());
              for (const auto& v332_3_branch : v332_3_branches) {
                const Path v332_3_head{v332_3_branch.first};
                const Space& v332_3_tail = v332_3_branch.second;
                const Path v333_2 = concat_path(v332_2,v332_3_head);
                const auto v333_3_branches = branches(c,v332_3_tail);
                std::vector<Space> v333_3_outputs;
                v333_3_outputs.reserve(v333_3_branches.size());
                for (const auto& v333_3_branch : v333_3_branches) {
                  const Path v333_3_head{v333_3_branch.first};
                  const Space& v333_3_tail = v333_3_branch.second;
                  const Path v334_2 = concat_path(v333_2,v333_3_head);
                  const Space v334_3 = routine_55(c, v334_2, p0, v330_2, v333_3_tail);
                  v333_3_outputs.push_back(v334_3);
                }
                const Space v333_3 = join_outputs(std::move(v333_3_outputs));
                v332_3_outputs.push_back(v333_3);
              }
              const Space v332_3 = join_outputs(std::move(v332_3_outputs));
              v331_2_outputs.push_back(v332_3);
            }
            const Space v331_2 = join_outputs(std::move(v331_2_outputs));
            v330_3_outputs.push_back(v331_2);
          }
          const Space v330_3 = join_outputs(std::move(v330_3_outputs));
          v329_3_outputs.push_back(v330_3);
        }
        const Space v329_3 = join_outputs(std::move(v329_3_outputs));
        v328_3_outputs.push_back(v329_3);
      }
      const Space v328_3 = join_outputs(std::move(v328_3_outputs));
      v327_2_outputs.push_back(v328_3);
    }
    const Space v327_2 = join_outputs(std::move(v327_2_outputs));
    v326_2_outputs.push_back(v327_2);
  }
  const Space v326_2 = join_outputs(std::move(v326_2_outputs));
  return v326_2;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_32(Context& c, const Path& p0, const Space& s0) {
  const auto v336_2_branches = branches(c,s0);
  std::vector<Space> v336_2_outputs;
  v336_2_outputs.reserve(v336_2_branches.size());
  for (const auto& v336_2_branch : v336_2_branches) {
    const Path v336_2_head{v336_2_branch.first};
    const Space& v336_2_tail = v336_2_branch.second;
    const auto v337_2_branches = branches(c,v336_2_tail);
    std::vector<Space> v337_2_outputs;
    v337_2_outputs.reserve(v337_2_branches.size());
    for (const auto& v337_2_branch : v337_2_branches) {
      const Path v337_2_head{v337_2_branch.first};
      const Space& v337_2_tail = v337_2_branch.second;
      const Path v338_2 = concat_path(v336_2_head,v337_2_head);
      const auto v338_3_branches = branches(c,v337_2_tail);
      std::vector<Space> v338_3_outputs;
      v338_3_outputs.reserve(v338_3_branches.size());
      for (const auto& v338_3_branch : v338_3_branches) {
        const Path v338_3_head{v338_3_branch.first};
        const Space& v338_3_tail = v338_3_branch.second;
        const Path v339_2 = concat_path(v338_2,v338_3_head);
        const auto v339_3_branches = branches(c,v338_3_tail);
        std::vector<Space> v339_3_outputs;
        v339_3_outputs.reserve(v339_3_branches.size());
        for (const auto& v339_3_branch : v339_3_branches) {
          const Path v339_3_head{v339_3_branch.first};
          const Space& v339_3_tail = v339_3_branch.second;
          const Path v340_2 = concat_path(v339_2,v339_3_head);
          const auto v340_3_branches = branches(c,v339_3_tail);
          std::vector<Space> v340_3_outputs;
          v340_3_outputs.reserve(v340_3_branches.size());
          for (const auto& v340_3_branch : v340_3_branches) {
            const Path v340_3_head{v340_3_branch.first};
            const Space& v340_3_tail = v340_3_branch.second;
            const auto v341_2_branches = branches(c,v340_3_tail);
            std::vector<Space> v341_2_outputs;
            v341_2_outputs.reserve(v341_2_branches.size());
            for (const auto& v341_2_branch : v341_2_branches) {
              const Path v341_2_head{v341_2_branch.first};
              const Space& v341_2_tail = v341_2_branch.second;
              const Path v342_2 = concat_path(v340_3_head,v341_2_head);
              const auto v342_3_branches = branches(c,v341_2_tail);
              std::vector<Space> v342_3_outputs;
              v342_3_outputs.reserve(v342_3_branches.size());
              for (const auto& v342_3_branch : v342_3_branches) {
                const Path v342_3_head{v342_3_branch.first};
                const Space& v342_3_tail = v342_3_branch.second;
                const Path v343_2 = concat_path(v342_2,v342_3_head);
                const auto v343_3_branches = branches(c,v342_3_tail);
                std::vector<Space> v343_3_outputs;
                v343_3_outputs.reserve(v343_3_branches.size());
                for (const auto& v343_3_branch : v343_3_branches) {
                  const Path v343_3_head{v343_3_branch.first};
                  const Space& v343_3_tail = v343_3_branch.second;
                  const Path v344_2 = concat_path(v343_2,v343_3_head);
                  const Space v344_3 = routine_56(c, v344_2, p0, v340_2, v343_3_tail);
                  v343_3_outputs.push_back(v344_3);
                }
                const Space v343_3 = join_outputs(std::move(v343_3_outputs));
                v342_3_outputs.push_back(v343_3);
              }
              const Space v342_3 = join_outputs(std::move(v342_3_outputs));
              v341_2_outputs.push_back(v342_3);
            }
            const Space v341_2 = join_outputs(std::move(v341_2_outputs));
            v340_3_outputs.push_back(v341_2);
          }
          const Space v340_3 = join_outputs(std::move(v340_3_outputs));
          v339_3_outputs.push_back(v340_3);
        }
        const Space v339_3 = join_outputs(std::move(v339_3_outputs));
        v338_3_outputs.push_back(v339_3);
      }
      const Space v338_3 = join_outputs(std::move(v338_3_outputs));
      v337_2_outputs.push_back(v338_3);
    }
    const Space v337_2 = join_outputs(std::move(v337_2_outputs));
    v336_2_outputs.push_back(v337_2);
  }
  const Space v336_2 = join_outputs(std::move(v336_2_outputs));
  return v336_2;
}

static Space routine_33(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_34(Context& c, const Path& p0, const Space& s0) {
  const auto v346_2_branches = branches(c,s0);
  std::vector<Space> v346_2_outputs;
  v346_2_outputs.reserve(v346_2_branches.size());
  for (const auto& v346_2_branch : v346_2_branches) {
    const Path v346_2_head{v346_2_branch.first};
    const Space& v346_2_tail = v346_2_branch.second;
    const auto v347_2_branches = branches(c,v346_2_tail);
    std::vector<Space> v347_2_outputs;
    v347_2_outputs.reserve(v347_2_branches.size());
    for (const auto& v347_2_branch : v347_2_branches) {
      const Path v347_2_head{v347_2_branch.first};
      const Space& v347_2_tail = v347_2_branch.second;
      const Path v348_2 = concat_path(v346_2_head,v347_2_head);
      const auto v348_3_branches = branches(c,v347_2_tail);
      std::vector<Space> v348_3_outputs;
      v348_3_outputs.reserve(v348_3_branches.size());
      for (const auto& v348_3_branch : v348_3_branches) {
        const Path v348_3_head{v348_3_branch.first};
        const Space& v348_3_tail = v348_3_branch.second;
        const Path v349_2 = concat_path(v348_2,v348_3_head);
        const auto v349_3_branches = branches(c,v348_3_tail);
        std::vector<Space> v349_3_outputs;
        v349_3_outputs.reserve(v349_3_branches.size());
        for (const auto& v349_3_branch : v349_3_branches) {
          const Path v349_3_head{v349_3_branch.first};
          const Space& v349_3_tail = v349_3_branch.second;
          const Path v350_2 = concat_path(v349_2,v349_3_head);
          const auto v350_3_branches = branches(c,v349_3_tail);
          std::vector<Space> v350_3_outputs;
          v350_3_outputs.reserve(v350_3_branches.size());
          for (const auto& v350_3_branch : v350_3_branches) {
            const Path v350_3_head{v350_3_branch.first};
            const Space& v350_3_tail = v350_3_branch.second;
            const auto v351_2_branches = branches(c,v350_3_tail);
            std::vector<Space> v351_2_outputs;
            v351_2_outputs.reserve(v351_2_branches.size());
            for (const auto& v351_2_branch : v351_2_branches) {
              const Path v351_2_head{v351_2_branch.first};
              const Space& v351_2_tail = v351_2_branch.second;
              const Path v352_2 = concat_path(v350_3_head,v351_2_head);
              const auto v352_3_branches = branches(c,v351_2_tail);
              std::vector<Space> v352_3_outputs;
              v352_3_outputs.reserve(v352_3_branches.size());
              for (const auto& v352_3_branch : v352_3_branches) {
                const Path v352_3_head{v352_3_branch.first};
                const Space& v352_3_tail = v352_3_branch.second;
                const Path v353_2 = concat_path(v352_2,v352_3_head);
                const auto v353_3_branches = branches(c,v352_3_tail);
                std::vector<Space> v353_3_outputs;
                v353_3_outputs.reserve(v353_3_branches.size());
                for (const auto& v353_3_branch : v353_3_branches) {
                  const Path v353_3_head{v353_3_branch.first};
                  const Space& v353_3_tail = v353_3_branch.second;
                  const Path v354_2 = concat_path(v353_2,v353_3_head);
                  const Space v354_3 = routine_57(c, v354_2, p0, v350_2, v353_3_tail);
                  v353_3_outputs.push_back(v354_3);
                }
                const Space v353_3 = join_outputs(std::move(v353_3_outputs));
                v352_3_outputs.push_back(v353_3);
              }
              const Space v352_3 = join_outputs(std::move(v352_3_outputs));
              v351_2_outputs.push_back(v352_3);
            }
            const Space v351_2 = join_outputs(std::move(v351_2_outputs));
            v350_3_outputs.push_back(v351_2);
          }
          const Space v350_3 = join_outputs(std::move(v350_3_outputs));
          v349_3_outputs.push_back(v350_3);
        }
        const Space v349_3 = join_outputs(std::move(v349_3_outputs));
        v348_3_outputs.push_back(v349_3);
      }
      const Space v348_3 = join_outputs(std::move(v348_3_outputs));
      v347_2_outputs.push_back(v348_3);
    }
    const Space v347_2 = join_outputs(std::move(v347_2_outputs));
    v346_2_outputs.push_back(v347_2);
  }
  const Space v346_2 = join_outputs(std::move(v346_2_outputs));
  return v346_2;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_36(Context& c, const Path& p0, const Space& s0) {
  const auto v356_2_branches = branches(c,s0);
  std::vector<Space> v356_2_outputs;
  v356_2_outputs.reserve(v356_2_branches.size());
  for (const auto& v356_2_branch : v356_2_branches) {
    const Path v356_2_head{v356_2_branch.first};
    const Space& v356_2_tail = v356_2_branch.second;
    const auto v357_2_branches = branches(c,v356_2_tail);
    std::vector<Space> v357_2_outputs;
    v357_2_outputs.reserve(v357_2_branches.size());
    for (const auto& v357_2_branch : v357_2_branches) {
      const Path v357_2_head{v357_2_branch.first};
      const Space& v357_2_tail = v357_2_branch.second;
      const Path v358_2 = concat_path(v356_2_head,v357_2_head);
      const auto v358_3_branches = branches(c,v357_2_tail);
      std::vector<Space> v358_3_outputs;
      v358_3_outputs.reserve(v358_3_branches.size());
      for (const auto& v358_3_branch : v358_3_branches) {
        const Path v358_3_head{v358_3_branch.first};
        const Space& v358_3_tail = v358_3_branch.second;
        const Path v359_2 = concat_path(v358_2,v358_3_head);
        const auto v359_3_branches = branches(c,v358_3_tail);
        std::vector<Space> v359_3_outputs;
        v359_3_outputs.reserve(v359_3_branches.size());
        for (const auto& v359_3_branch : v359_3_branches) {
          const Path v359_3_head{v359_3_branch.first};
          const Space& v359_3_tail = v359_3_branch.second;
          const Path v360_2 = concat_path(v359_2,v359_3_head);
          const auto v360_3_branches = branches(c,v359_3_tail);
          std::vector<Space> v360_3_outputs;
          v360_3_outputs.reserve(v360_3_branches.size());
          for (const auto& v360_3_branch : v360_3_branches) {
            const Path v360_3_head{v360_3_branch.first};
            const Space& v360_3_tail = v360_3_branch.second;
            const auto v361_2_branches = branches(c,v360_3_tail);
            std::vector<Space> v361_2_outputs;
            v361_2_outputs.reserve(v361_2_branches.size());
            for (const auto& v361_2_branch : v361_2_branches) {
              const Path v361_2_head{v361_2_branch.first};
              const Space& v361_2_tail = v361_2_branch.second;
              const Path v362_2 = concat_path(v360_3_head,v361_2_head);
              const auto v362_3_branches = branches(c,v361_2_tail);
              std::vector<Space> v362_3_outputs;
              v362_3_outputs.reserve(v362_3_branches.size());
              for (const auto& v362_3_branch : v362_3_branches) {
                const Path v362_3_head{v362_3_branch.first};
                const Space& v362_3_tail = v362_3_branch.second;
                const Path v363_2 = concat_path(v362_2,v362_3_head);
                const auto v363_3_branches = branches(c,v362_3_tail);
                std::vector<Space> v363_3_outputs;
                v363_3_outputs.reserve(v363_3_branches.size());
                for (const auto& v363_3_branch : v363_3_branches) {
                  const Path v363_3_head{v363_3_branch.first};
                  const Space& v363_3_tail = v363_3_branch.second;
                  const Path v364_2 = concat_path(v363_2,v363_3_head);
                  const Space v364_3 = routine_58(c, v364_2, p0, v360_2, v363_3_tail);
                  v363_3_outputs.push_back(v364_3);
                }
                const Space v363_3 = join_outputs(std::move(v363_3_outputs));
                v362_3_outputs.push_back(v363_3);
              }
              const Space v362_3 = join_outputs(std::move(v362_3_outputs));
              v361_2_outputs.push_back(v362_3);
            }
            const Space v361_2 = join_outputs(std::move(v361_2_outputs));
            v360_3_outputs.push_back(v361_2);
          }
          const Space v360_3 = join_outputs(std::move(v360_3_outputs));
          v359_3_outputs.push_back(v360_3);
        }
        const Space v359_3 = join_outputs(std::move(v359_3_outputs));
        v358_3_outputs.push_back(v359_3);
      }
      const Space v358_3 = join_outputs(std::move(v358_3_outputs));
      v357_2_outputs.push_back(v358_3);
    }
    const Space v357_2 = join_outputs(std::move(v357_2_outputs));
    v356_2_outputs.push_back(v357_2);
  }
  const Space v356_2 = join_outputs(std::move(v356_2_outputs));
  return v356_2;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_38(Context& c, const Path& p0, const Space& s0) {
  const auto v366_2_branches = branches(c,s0);
  std::vector<Space> v366_2_outputs;
  v366_2_outputs.reserve(v366_2_branches.size());
  for (const auto& v366_2_branch : v366_2_branches) {
    const Path v366_2_head{v366_2_branch.first};
    const Space& v366_2_tail = v366_2_branch.second;
    const auto v367_2_branches = branches(c,v366_2_tail);
    std::vector<Space> v367_2_outputs;
    v367_2_outputs.reserve(v367_2_branches.size());
    for (const auto& v367_2_branch : v367_2_branches) {
      const Path v367_2_head{v367_2_branch.first};
      const Space& v367_2_tail = v367_2_branch.second;
      const Path v368_2 = concat_path(v366_2_head,v367_2_head);
      const auto v368_3_branches = branches(c,v367_2_tail);
      std::vector<Space> v368_3_outputs;
      v368_3_outputs.reserve(v368_3_branches.size());
      for (const auto& v368_3_branch : v368_3_branches) {
        const Path v368_3_head{v368_3_branch.first};
        const Space& v368_3_tail = v368_3_branch.second;
        const Path v369_2 = concat_path(v368_2,v368_3_head);
        const auto v369_3_branches = branches(c,v368_3_tail);
        std::vector<Space> v369_3_outputs;
        v369_3_outputs.reserve(v369_3_branches.size());
        for (const auto& v369_3_branch : v369_3_branches) {
          const Path v369_3_head{v369_3_branch.first};
          const Space& v369_3_tail = v369_3_branch.second;
          const Path v370_2 = concat_path(v369_2,v369_3_head);
          const auto v370_3_branches = branches(c,v369_3_tail);
          std::vector<Space> v370_3_outputs;
          v370_3_outputs.reserve(v370_3_branches.size());
          for (const auto& v370_3_branch : v370_3_branches) {
            const Path v370_3_head{v370_3_branch.first};
            const Space& v370_3_tail = v370_3_branch.second;
            const auto v371_2_branches = branches(c,v370_3_tail);
            std::vector<Space> v371_2_outputs;
            v371_2_outputs.reserve(v371_2_branches.size());
            for (const auto& v371_2_branch : v371_2_branches) {
              const Path v371_2_head{v371_2_branch.first};
              const Space& v371_2_tail = v371_2_branch.second;
              const Path v372_2 = concat_path(v370_3_head,v371_2_head);
              const auto v372_3_branches = branches(c,v371_2_tail);
              std::vector<Space> v372_3_outputs;
              v372_3_outputs.reserve(v372_3_branches.size());
              for (const auto& v372_3_branch : v372_3_branches) {
                const Path v372_3_head{v372_3_branch.first};
                const Space& v372_3_tail = v372_3_branch.second;
                const Path v373_2 = concat_path(v372_2,v372_3_head);
                const auto v373_3_branches = branches(c,v372_3_tail);
                std::vector<Space> v373_3_outputs;
                v373_3_outputs.reserve(v373_3_branches.size());
                for (const auto& v373_3_branch : v373_3_branches) {
                  const Path v373_3_head{v373_3_branch.first};
                  const Space& v373_3_tail = v373_3_branch.second;
                  const Path v374_2 = concat_path(v373_2,v373_3_head);
                  const Space v374_3 = routine_59(c, v374_2, p0, v370_2, v373_3_tail);
                  v373_3_outputs.push_back(v374_3);
                }
                const Space v373_3 = join_outputs(std::move(v373_3_outputs));
                v372_3_outputs.push_back(v373_3);
              }
              const Space v372_3 = join_outputs(std::move(v372_3_outputs));
              v371_2_outputs.push_back(v372_3);
            }
            const Space v371_2 = join_outputs(std::move(v371_2_outputs));
            v370_3_outputs.push_back(v371_2);
          }
          const Space v370_3 = join_outputs(std::move(v370_3_outputs));
          v369_3_outputs.push_back(v370_3);
        }
        const Space v369_3 = join_outputs(std::move(v369_3_outputs));
        v368_3_outputs.push_back(v369_3);
      }
      const Space v368_3 = join_outputs(std::move(v368_3_outputs));
      v367_2_outputs.push_back(v368_3);
    }
    const Space v367_2 = join_outputs(std::move(v367_2_outputs));
    v366_2_outputs.push_back(v367_2);
  }
  const Space v366_2 = join_outputs(std::move(v366_2_outputs));
  return v366_2;
}

static Space routine_39(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_40(Context& c, const Path& p0, const Space& s0) {
  const auto v376_2_branches = branches(c,s0);
  std::vector<Space> v376_2_outputs;
  v376_2_outputs.reserve(v376_2_branches.size());
  for (const auto& v376_2_branch : v376_2_branches) {
    const Path v376_2_head{v376_2_branch.first};
    const Space& v376_2_tail = v376_2_branch.second;
    const auto v377_2_branches = branches(c,v376_2_tail);
    std::vector<Space> v377_2_outputs;
    v377_2_outputs.reserve(v377_2_branches.size());
    for (const auto& v377_2_branch : v377_2_branches) {
      const Path v377_2_head{v377_2_branch.first};
      const Space& v377_2_tail = v377_2_branch.second;
      const Path v378_2 = concat_path(v376_2_head,v377_2_head);
      const auto v378_3_branches = branches(c,v377_2_tail);
      std::vector<Space> v378_3_outputs;
      v378_3_outputs.reserve(v378_3_branches.size());
      for (const auto& v378_3_branch : v378_3_branches) {
        const Path v378_3_head{v378_3_branch.first};
        const Space& v378_3_tail = v378_3_branch.second;
        const Path v379_2 = concat_path(v378_2,v378_3_head);
        const auto v379_3_branches = branches(c,v378_3_tail);
        std::vector<Space> v379_3_outputs;
        v379_3_outputs.reserve(v379_3_branches.size());
        for (const auto& v379_3_branch : v379_3_branches) {
          const Path v379_3_head{v379_3_branch.first};
          const Space& v379_3_tail = v379_3_branch.second;
          const Path v380_2 = concat_path(v379_2,v379_3_head);
          const auto v380_3_branches = branches(c,v379_3_tail);
          std::vector<Space> v380_3_outputs;
          v380_3_outputs.reserve(v380_3_branches.size());
          for (const auto& v380_3_branch : v380_3_branches) {
            const Path v380_3_head{v380_3_branch.first};
            const Space& v380_3_tail = v380_3_branch.second;
            const auto v381_2_branches = branches(c,v380_3_tail);
            std::vector<Space> v381_2_outputs;
            v381_2_outputs.reserve(v381_2_branches.size());
            for (const auto& v381_2_branch : v381_2_branches) {
              const Path v381_2_head{v381_2_branch.first};
              const Space& v381_2_tail = v381_2_branch.second;
              const Path v382_2 = concat_path(v380_3_head,v381_2_head);
              const auto v382_3_branches = branches(c,v381_2_tail);
              std::vector<Space> v382_3_outputs;
              v382_3_outputs.reserve(v382_3_branches.size());
              for (const auto& v382_3_branch : v382_3_branches) {
                const Path v382_3_head{v382_3_branch.first};
                const Space& v382_3_tail = v382_3_branch.second;
                const Path v383_2 = concat_path(v382_2,v382_3_head);
                const auto v383_3_branches = branches(c,v382_3_tail);
                std::vector<Space> v383_3_outputs;
                v383_3_outputs.reserve(v383_3_branches.size());
                for (const auto& v383_3_branch : v383_3_branches) {
                  const Path v383_3_head{v383_3_branch.first};
                  const Space& v383_3_tail = v383_3_branch.second;
                  const Path v384_2 = concat_path(v383_2,v383_3_head);
                  const Space v384_3 = routine_60(c, v384_2, p0, v380_2, v383_3_tail);
                  v383_3_outputs.push_back(v384_3);
                }
                const Space v383_3 = join_outputs(std::move(v383_3_outputs));
                v382_3_outputs.push_back(v383_3);
              }
              const Space v382_3 = join_outputs(std::move(v382_3_outputs));
              v381_2_outputs.push_back(v382_3);
            }
            const Space v381_2 = join_outputs(std::move(v381_2_outputs));
            v380_3_outputs.push_back(v381_2);
          }
          const Space v380_3 = join_outputs(std::move(v380_3_outputs));
          v379_3_outputs.push_back(v380_3);
        }
        const Space v379_3 = join_outputs(std::move(v379_3_outputs));
        v378_3_outputs.push_back(v379_3);
      }
      const Space v378_3 = join_outputs(std::move(v378_3_outputs));
      v377_2_outputs.push_back(v378_3);
    }
    const Space v377_2 = join_outputs(std::move(v377_2_outputs));
    v376_2_outputs.push_back(v377_2);
  }
  const Space v376_2 = join_outputs(std::move(v376_2_outputs));
  return v376_2;
}

static Space routine_41(Context& c, const Path& p0, const Space& s0) {
  const auto v385_3_branches = branches(c,s0);
  std::vector<Space> v385_3_outputs;
  v385_3_outputs.reserve(v385_3_branches.size());
  for (const auto& v385_3_branch : v385_3_branches) {
    const Path v385_3_head{v385_3_branch.first};
    const Space& v385_3_tail = v385_3_branch.second;
    const auto v386_2_branches = branches(c,v385_3_tail);
    std::vector<Space> v386_2_outputs;
    v386_2_outputs.reserve(v386_2_branches.size());
    for (const auto& v386_2_branch : v386_2_branches) {
      const Path v386_2_head{v386_2_branch.first};
      const Space& v386_2_tail = v386_2_branch.second;
      const Path v387_2 = concat_path(v385_3_head,v386_2_head);
      const auto v387_3_branches = branches(c,v386_2_tail);
      std::vector<Space> v387_3_outputs;
      v387_3_outputs.reserve(v387_3_branches.size());
      for (const auto& v387_3_branch : v387_3_branches) {
        const Path v387_3_head{v387_3_branch.first};
        const Space& v387_3_tail = v387_3_branch.second;
        const Path v388_2 = concat_path(v387_2,v387_3_head);
        const auto v388_3_branches = branches(c,v387_3_tail);
        std::vector<Space> v388_3_outputs;
        v388_3_outputs.reserve(v388_3_branches.size());
        for (const auto& v388_3_branch : v388_3_branches) {
          const Path v388_3_head{v388_3_branch.first};
          const Space& v388_3_tail = v388_3_branch.second;
          const auto v389_2_branches = branches(c,v388_3_tail);
          std::vector<Space> v389_2_outputs;
          v389_2_outputs.reserve(v389_2_branches.size());
          for (const auto& v389_2_branch : v389_2_branches) {
            const Path v389_2_head{v389_2_branch.first};
            const Space& v389_2_tail = v389_2_branch.second;
            const auto v390_2_branches = branches(c,v389_2_tail);
            std::vector<Space> v390_2_outputs;
            v390_2_outputs.reserve(v390_2_branches.size());
            for (const auto& v390_2_branch : v390_2_branches) {
              const Path v390_2_head{v390_2_branch.first};
              const Space& v390_2_tail = v390_2_branch.second;
              const Path v391_2 = concat_path(v389_2_head,v390_2_head);
              const auto v391_3_branches = branches(c,v390_2_tail);
              std::vector<Space> v391_3_outputs;
              v391_3_outputs.reserve(v391_3_branches.size());
              for (const auto& v391_3_branch : v391_3_branches) {
                const Path v391_3_head{v391_3_branch.first};
                const Space& v391_3_tail = v391_3_branch.second;
                const Path v392_2 = concat_path(v391_2,v391_3_head);
                const auto v392_3_branches = branches(c,v391_3_tail);
                std::vector<Space> v392_3_outputs;
                v392_3_outputs.reserve(v392_3_branches.size());
                for (const auto& v392_3_branch : v392_3_branches) {
                  const Path v392_3_head{v392_3_branch.first};
                  const Space& v392_3_tail = v392_3_branch.second;
                  const Path v393_2 = concat_path(v392_2,v392_3_head);
                  const Space v393_3 = routine_61(c, v393_2, v392_3_tail);
                  v392_3_outputs.push_back(v393_3);
                }
                const Space v392_3 = join_outputs(std::move(v392_3_outputs));
                v391_3_outputs.push_back(v392_3);
              }
              const Space v391_3 = join_outputs(std::move(v391_3_outputs));
              v390_2_outputs.push_back(v391_3);
            }
            const Space v390_2 = join_outputs(std::move(v390_2_outputs));
            v389_2_outputs.push_back(v390_2);
          }
          const Space v389_2 = join_outputs(std::move(v389_2_outputs));
          const Space v389_3 = raffine(constant_83,v389_2);
          const Space v389_4 = unite(v389_3,v388_3_tail);
          const Path v389_5 = concat_path(v388_2,v388_3_head);
          const Path v389_6 = concat_path(p0,v389_5);
          const Space v389_7 = wrap(v389_4,v389_6);
          v388_3_outputs.push_back(v389_7);
        }
        const Space v388_3 = join_outputs(std::move(v388_3_outputs));
        v387_3_outputs.push_back(v388_3);
      }
      const Space v387_3 = join_outputs(std::move(v387_3_outputs));
      v386_2_outputs.push_back(v387_3);
    }
    const Space v386_2 = join_outputs(std::move(v386_2_outputs));
    v385_3_outputs.push_back(v386_2);
  }
  const Space v385_3 = join_outputs(std::move(v385_3_outputs));
  return v385_3;
}

static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v394_4 = unwrap(s0,p1);
  const Space v394_5 = wrap(v394_4,p0);
  const Space v394_6 = compose(v394_5,s1);
  return v394_6;
}

static Space routine_43(Context& c, const Path& p0, const Space& s0) {
  const auto v395_3_branches = branches(c,s0);
  std::vector<Space> v395_3_outputs;
  v395_3_outputs.reserve(v395_3_branches.size());
  for (const auto& v395_3_branch : v395_3_branches) {
    const Path v395_3_head{v395_3_branch.first};
    const Space& v395_3_tail = v395_3_branch.second;
    const auto v396_2_branches = branches(c,v395_3_tail);
    std::vector<Space> v396_2_outputs;
    v396_2_outputs.reserve(v396_2_branches.size());
    for (const auto& v396_2_branch : v396_2_branches) {
      const Path v396_2_head{v396_2_branch.first};
      const Space& v396_2_tail = v396_2_branch.second;
      const Path v397_2 = concat_path(v395_3_head,v396_2_head);
      const auto v397_3_branches = branches(c,v396_2_tail);
      std::vector<Space> v397_3_outputs;
      v397_3_outputs.reserve(v397_3_branches.size());
      for (const auto& v397_3_branch : v397_3_branches) {
        const Path v397_3_head{v397_3_branch.first};
        const Space& v397_3_tail = v397_3_branch.second;
        const Path v398_2 = concat_path(v397_2,v397_3_head);
        const auto v398_3_branches = branches(c,v397_3_tail);
        std::vector<Space> v398_3_outputs;
        v398_3_outputs.reserve(v398_3_branches.size());
        for (const auto& v398_3_branch : v398_3_branches) {
          const Path v398_3_head{v398_3_branch.first};
          const Space& v398_3_tail = v398_3_branch.second;
          const auto v399_2_branches = branches(c,v398_3_tail);
          std::vector<Space> v399_2_outputs;
          v399_2_outputs.reserve(v399_2_branches.size());
          for (const auto& v399_2_branch : v399_2_branches) {
            const Path v399_2_head{v399_2_branch.first};
            const Space& v399_2_tail = v399_2_branch.second;
            const auto v400_2_branches = branches(c,v399_2_tail);
            std::vector<Space> v400_2_outputs;
            v400_2_outputs.reserve(v400_2_branches.size());
            for (const auto& v400_2_branch : v400_2_branches) {
              const Path v400_2_head{v400_2_branch.first};
              const Space& v400_2_tail = v400_2_branch.second;
              const Path v401_2 = concat_path(v399_2_head,v400_2_head);
              const auto v401_3_branches = branches(c,v400_2_tail);
              std::vector<Space> v401_3_outputs;
              v401_3_outputs.reserve(v401_3_branches.size());
              for (const auto& v401_3_branch : v401_3_branches) {
                const Path v401_3_head{v401_3_branch.first};
                const Space& v401_3_tail = v401_3_branch.second;
                const Path v402_2 = concat_path(v401_2,v401_3_head);
                const auto v402_3_branches = branches(c,v401_3_tail);
                std::vector<Space> v402_3_outputs;
                v402_3_outputs.reserve(v402_3_branches.size());
                for (const auto& v402_3_branch : v402_3_branches) {
                  const Path v402_3_head{v402_3_branch.first};
                  const Space& v402_3_tail = v402_3_branch.second;
                  const Path v403_2 = concat_path(v402_2,v402_3_head);
                  const Space v403_3 = routine_62(c, v403_2, v402_3_tail);
                  v402_3_outputs.push_back(v403_3);
                }
                const Space v402_3 = join_outputs(std::move(v402_3_outputs));
                v401_3_outputs.push_back(v402_3);
              }
              const Space v401_3 = join_outputs(std::move(v401_3_outputs));
              v400_2_outputs.push_back(v401_3);
            }
            const Space v400_2 = join_outputs(std::move(v400_2_outputs));
            v399_2_outputs.push_back(v400_2);
          }
          const Space v399_2 = join_outputs(std::move(v399_2_outputs));
          const Space v399_3 = raffine(constant_83,v399_2);
          const Space v399_4 = unite(v399_3,v398_3_tail);
          const Path v399_5 = concat_path(v398_2,v398_3_head);
          const Path v399_6 = concat_path(p0,v399_5);
          const Space v399_7 = wrap(v399_4,v399_6);
          v398_3_outputs.push_back(v399_7);
        }
        const Space v398_3 = join_outputs(std::move(v398_3_outputs));
        v397_3_outputs.push_back(v398_3);
      }
      const Space v397_3 = join_outputs(std::move(v397_3_outputs));
      v396_2_outputs.push_back(v397_3);
    }
    const Space v396_2 = join_outputs(std::move(v396_2_outputs));
    v395_3_outputs.push_back(v396_2);
  }
  const Space v395_3 = join_outputs(std::move(v395_3_outputs));
  return v395_3;
}

static Space routine_44(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v404_4 = singleton(p0);
  const Space v404_5 = intersect(constant_50,v404_4);
  const Space v404_7 = unwrap(s1,constant_3);
  const Space v404_9 = unwrap(s1,constant_5);
  const Space v404_10 = compose(v404_7,v404_9);
  const Space v404_12 = unwrap(s1,constant_7);
  const Space v404_13 = compose(v404_10,v404_12);
  const Space v404_15 = unwrap(s1,constant_9);
  const Space v404_16 = compose(v404_13,v404_15);
  const Space v404_18 = unwrap(s1,constant_11);
  const Space v404_19 = compose(v404_16,v404_18);
  const Space v404_21 = unwrap(s1,constant_13);
  const Space v404_22 = compose(v404_19,v404_21);
  const Space v404_24 = unwrap(s1,constant_15);
  const Space v404_25 = compose(v404_22,v404_24);
  const Space v404_27 = unwrap(s1,constant_17);
  const Space v404_28 = compose(v404_25,v404_27);
  const Space v404_30 = unwrap(s1,constant_19);
  const Space v404_31 = compose(v404_28,v404_30);
  const Space v404_33 = unwrap(s1,constant_21);
  const Space v404_34 = compose(v404_31,v404_33);
  const Space v404_36 = unwrap(s1,constant_23);
  const Space v404_37 = compose(v404_34,v404_36);
  const Space v404_39 = unwrap(s1,constant_25);
  const Space v404_40 = compose(v404_37,v404_39);
  const Space v404_42 = unwrap(s1,constant_27);
  const Space v404_43 = compose(v404_40,v404_42);
  const Space v404_45 = unwrap(s1,constant_29);
  const Space v404_46 = compose(v404_43,v404_45);
  const Space v404_48 = unwrap(s1,constant_81);
  const Space v404_49 = compose(v404_46,v404_48);
  const Space v404_50 = compose(v404_5,v404_49);
  const Space v404_52 = intersect(constant_51,v404_4);
  const Space v404_54 = unwrap(s1,constant_1);
  const Space v404_55 = compose(v404_54,v404_9);
  const Space v404_56 = compose(v404_55,v404_12);
  const Space v404_57 = compose(v404_56,v404_15);
  const Space v404_58 = compose(v404_57,v404_18);
  const Space v404_59 = compose(v404_58,v404_21);
  const Space v404_60 = compose(v404_59,v404_24);
  const Space v404_61 = compose(v404_60,v404_27);
  const Space v404_62 = compose(v404_61,v404_30);
  const Space v404_63 = compose(v404_62,v404_33);
  const Space v404_64 = compose(v404_63,v404_36);
  const Space v404_65 = compose(v404_64,v404_39);
  const Space v404_66 = compose(v404_65,v404_42);
  const Space v404_67 = compose(v404_66,v404_45);
  const Space v404_68 = compose(v404_67,v404_48);
  const Space v404_69 = compose(v404_52,v404_68);
  const Space v404_70 = unite(v404_50,v404_69);
  const Space v404_72 = intersect(constant_52,v404_4);
  const Space v404_73 = compose(v404_54,v404_7);
  const Space v404_74 = compose(v404_73,v404_12);
  const Space v404_75 = compose(v404_74,v404_15);
  const Space v404_76 = compose(v404_75,v404_18);
  const Space v404_77 = compose(v404_76,v404_21);
  const Space v404_78 = compose(v404_77,v404_24);
  const Space v404_79 = compose(v404_78,v404_27);
  const Space v404_80 = compose(v404_79,v404_30);
  const Space v404_81 = compose(v404_80,v404_33);
  const Space v404_82 = compose(v404_81,v404_36);
  const Space v404_83 = compose(v404_82,v404_39);
  const Space v404_84 = compose(v404_83,v404_42);
  const Space v404_85 = compose(v404_84,v404_45);
  const Space v404_86 = compose(v404_85,v404_48);
  const Space v404_87 = compose(v404_72,v404_86);
  const Space v404_88 = unite(v404_70,v404_87);
  const Space v404_90 = intersect(constant_53,v404_4);
  const Space v404_91 = compose(v404_73,v404_9);
  const Space v404_92 = compose(v404_91,v404_15);
  const Space v404_93 = compose(v404_92,v404_18);
  const Space v404_94 = compose(v404_93,v404_21);
  const Space v404_95 = compose(v404_94,v404_24);
  const Space v404_96 = compose(v404_95,v404_27);
  const Space v404_97 = compose(v404_96,v404_30);
  const Space v404_98 = compose(v404_97,v404_33);
  const Space v404_99 = compose(v404_98,v404_36);
  const Space v404_100 = compose(v404_99,v404_39);
  const Space v404_101 = compose(v404_100,v404_42);
  const Space v404_102 = compose(v404_101,v404_45);
  const Space v404_103 = compose(v404_102,v404_48);
  const Space v404_104 = compose(v404_90,v404_103);
  const Space v404_105 = unite(v404_88,v404_104);
  const Space v404_107 = intersect(constant_54,v404_4);
  const Space v404_108 = compose(v404_91,v404_12);
  const Space v404_109 = compose(v404_108,v404_18);
  const Space v404_110 = compose(v404_109,v404_21);
  const Space v404_111 = compose(v404_110,v404_24);
  const Space v404_112 = compose(v404_111,v404_27);
  const Space v404_113 = compose(v404_112,v404_30);
  const Space v404_114 = compose(v404_113,v404_33);
  const Space v404_115 = compose(v404_114,v404_36);
  const Space v404_116 = compose(v404_115,v404_39);
  const Space v404_117 = compose(v404_116,v404_42);
  const Space v404_118 = compose(v404_117,v404_45);
  const Space v404_119 = compose(v404_118,v404_48);
  const Space v404_120 = compose(v404_107,v404_119);
  const Space v404_121 = unite(v404_105,v404_120);
  const Space v404_123 = intersect(constant_55,v404_4);
  const Space v404_124 = compose(v404_108,v404_15);
  const Space v404_125 = compose(v404_124,v404_21);
  const Space v404_126 = compose(v404_125,v404_24);
  const Space v404_127 = compose(v404_126,v404_27);
  const Space v404_128 = compose(v404_127,v404_30);
  const Space v404_129 = compose(v404_128,v404_33);
  const Space v404_130 = compose(v404_129,v404_36);
  const Space v404_131 = compose(v404_130,v404_39);
  const Space v404_132 = compose(v404_131,v404_42);
  const Space v404_133 = compose(v404_132,v404_45);
  const Space v404_134 = compose(v404_133,v404_48);
  const Space v404_135 = compose(v404_123,v404_134);
  const Space v404_136 = unite(v404_121,v404_135);
  const Space v404_138 = intersect(constant_56,v404_4);
  const Space v404_139 = compose(v404_124,v404_18);
  const Space v404_140 = compose(v404_139,v404_24);
  const Space v404_141 = compose(v404_140,v404_27);
  const Space v404_142 = compose(v404_141,v404_30);
  const Space v404_143 = compose(v404_142,v404_33);
  const Space v404_144 = compose(v404_143,v404_36);
  const Space v404_145 = compose(v404_144,v404_39);
  const Space v404_146 = compose(v404_145,v404_42);
  const Space v404_147 = compose(v404_146,v404_45);
  const Space v404_148 = compose(v404_147,v404_48);
  const Space v404_149 = compose(v404_138,v404_148);
  const Space v404_150 = unite(v404_136,v404_149);
  const Space v404_152 = intersect(constant_57,v404_4);
  const Space v404_153 = compose(v404_139,v404_21);
  const Space v404_154 = compose(v404_153,v404_27);
  const Space v404_155 = compose(v404_154,v404_30);
  const Space v404_156 = compose(v404_155,v404_33);
  const Space v404_157 = compose(v404_156,v404_36);
  const Space v404_158 = compose(v404_157,v404_39);
  const Space v404_159 = compose(v404_158,v404_42);
  const Space v404_160 = compose(v404_159,v404_45);
  const Space v404_161 = compose(v404_160,v404_48);
  const Space v404_162 = compose(v404_152,v404_161);
  const Space v404_163 = unite(v404_150,v404_162);
  const Space v404_165 = intersect(constant_58,v404_4);
  const Space v404_166 = compose(v404_153,v404_24);
  const Space v404_167 = compose(v404_166,v404_30);
  const Space v404_168 = compose(v404_167,v404_33);
  const Space v404_169 = compose(v404_168,v404_36);
  const Space v404_170 = compose(v404_169,v404_39);
  const Space v404_171 = compose(v404_170,v404_42);
  const Space v404_172 = compose(v404_171,v404_45);
  const Space v404_173 = compose(v404_172,v404_48);
  const Space v404_174 = compose(v404_165,v404_173);
  const Space v404_175 = unite(v404_163,v404_174);
  const Space v404_177 = intersect(constant_59,v404_4);
  const Space v404_178 = compose(v404_166,v404_27);
  const Space v404_179 = compose(v404_178,v404_33);
  const Space v404_180 = compose(v404_179,v404_36);
  const Space v404_181 = compose(v404_180,v404_39);
  const Space v404_182 = compose(v404_181,v404_42);
  const Space v404_183 = compose(v404_182,v404_45);
  const Space v404_184 = compose(v404_183,v404_48);
  const Space v404_185 = compose(v404_177,v404_184);
  const Space v404_186 = unite(v404_175,v404_185);
  const Space v404_188 = intersect(constant_60,v404_4);
  const Space v404_189 = compose(v404_178,v404_30);
  const Space v404_190 = compose(v404_189,v404_36);
  const Space v404_191 = compose(v404_190,v404_39);
  const Space v404_192 = compose(v404_191,v404_42);
  const Space v404_193 = compose(v404_192,v404_45);
  const Space v404_194 = compose(v404_193,v404_48);
  const Space v404_195 = compose(v404_188,v404_194);
  const Space v404_196 = unite(v404_186,v404_195);
  const Space v404_198 = intersect(constant_61,v404_4);
  const Space v404_199 = compose(v404_189,v404_33);
  const Space v404_200 = compose(v404_199,v404_39);
  const Space v404_201 = compose(v404_200,v404_42);
  const Space v404_202 = compose(v404_201,v404_45);
  const Space v404_203 = compose(v404_202,v404_48);
  const Space v404_204 = compose(v404_198,v404_203);
  const Space v404_205 = unite(v404_196,v404_204);
  const Space v404_207 = intersect(constant_62,v404_4);
  const Space v404_208 = compose(v404_199,v404_36);
  const Space v404_209 = compose(v404_208,v404_42);
  const Space v404_210 = compose(v404_209,v404_45);
  const Space v404_211 = compose(v404_210,v404_48);
  const Space v404_212 = compose(v404_207,v404_211);
  const Space v404_213 = unite(v404_205,v404_212);
  const Space v404_215 = intersect(constant_63,v404_4);
  const Space v404_216 = compose(v404_208,v404_39);
  const Space v404_217 = compose(v404_216,v404_45);
  const Space v404_218 = compose(v404_217,v404_48);
  const Space v404_219 = compose(v404_215,v404_218);
  const Space v404_220 = unite(v404_213,v404_219);
  const Space v404_222 = intersect(constant_64,v404_4);
  const Space v404_223 = compose(v404_216,v404_42);
  const Space v404_224 = compose(v404_223,v404_48);
  const Space v404_225 = compose(v404_222,v404_224);
  const Space v404_226 = unite(v404_220,v404_225);
  const Space v404_228 = intersect(constant_65,v404_4);
  const Space v404_229 = compose(v404_223,v404_45);
  const Space v404_230 = compose(v404_228,v404_229);
  const Space v404_231 = unite(v404_226,v404_230);
  return v404_231;
}

static Space routine_45(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v405_4_branches = branches(c,s0);
  std::vector<Space> v405_4_outputs;
  v405_4_outputs.reserve(v405_4_branches.size());
  for (const auto& v405_4_branch : v405_4_branches) {
    const Path v405_4_head{v405_4_branch.first};
    const Space& v405_4_tail = v405_4_branch.second;
    const auto v406_2_branches = branches(c,v405_4_tail);
    std::vector<Space> v406_2_outputs;
    v406_2_outputs.reserve(v406_2_branches.size());
    for (const auto& v406_2_branch : v406_2_branches) {
      const Path v406_2_head{v406_2_branch.first};
      const Space& v406_2_tail = v406_2_branch.second;
      const Path v407_2 = concat_path(v405_4_head,v406_2_head);
      const auto v407_3_branches = branches(c,v406_2_tail);
      std::vector<Space> v407_3_outputs;
      v407_3_outputs.reserve(v407_3_branches.size());
      for (const auto& v407_3_branch : v407_3_branches) {
        const Path v407_3_head{v407_3_branch.first};
        const Space& v407_3_tail = v407_3_branch.second;
        const Path v408_2 = concat_path(v407_2,v407_3_head);
        const auto v408_3_branches = branches(c,v407_3_tail);
        std::vector<Space> v408_3_outputs;
        v408_3_outputs.reserve(v408_3_branches.size());
        for (const auto& v408_3_branch : v408_3_branches) {
          const Path v408_3_head{v408_3_branch.first};
          const Space& v408_3_tail = v408_3_branch.second;
          const Path v409_2 = concat_path(v408_2,v408_3_head);
          const auto v409_3_branches = branches(c,v408_3_tail);
          std::vector<Space> v409_3_outputs;
          v409_3_outputs.reserve(v409_3_branches.size());
          for (const auto& v409_3_branch : v409_3_branches) {
            const Path v409_3_head{v409_3_branch.first};
            const Space& v409_3_tail = v409_3_branch.second;
            const auto v410_2_branches = branches(c,v409_3_tail);
            std::vector<Space> v410_2_outputs;
            v410_2_outputs.reserve(v410_2_branches.size());
            for (const auto& v410_2_branch : v410_2_branches) {
              const Path v410_2_head{v410_2_branch.first};
              const Space& v410_2_tail = v410_2_branch.second;
              const Path v411_2 = concat_path(v409_3_head,v410_2_head);
              const auto v411_3_branches = branches(c,v410_2_tail);
              std::vector<Space> v411_3_outputs;
              v411_3_outputs.reserve(v411_3_branches.size());
              for (const auto& v411_3_branch : v411_3_branches) {
                const Path v411_3_head{v411_3_branch.first};
                const Space& v411_3_tail = v411_3_branch.second;
                const Path v412_2 = concat_path(v411_2,v411_3_head);
                const auto v412_3_branches = branches(c,v411_3_tail);
                std::vector<Space> v412_3_outputs;
                v412_3_outputs.reserve(v412_3_branches.size());
                for (const auto& v412_3_branch : v412_3_branches) {
                  const Path v412_3_head{v412_3_branch.first};
                  const Space& v412_3_tail = v412_3_branch.second;
                  const Path v413_2 = concat_path(v412_2,v412_3_head);
                  const Space v413_3 = routine_63(c, v413_2, p1, p2, p0, v409_2, v412_3_tail);
                  v412_3_outputs.push_back(v413_3);
                }
                const Space v412_3 = join_outputs(std::move(v412_3_outputs));
                v411_3_outputs.push_back(v412_3);
              }
              const Space v411_3 = join_outputs(std::move(v411_3_outputs));
              v410_2_outputs.push_back(v411_3);
            }
            const Space v410_2 = join_outputs(std::move(v410_2_outputs));
            v409_3_outputs.push_back(v410_2);
          }
          const Space v409_3 = join_outputs(std::move(v409_3_outputs));
          v408_3_outputs.push_back(v409_3);
        }
        const Space v408_3 = join_outputs(std::move(v408_3_outputs));
        v407_3_outputs.push_back(v408_3);
      }
      const Space v407_3 = join_outputs(std::move(v407_3_outputs));
      v406_2_outputs.push_back(v407_3);
    }
    const Space v406_2 = join_outputs(std::move(v406_2_outputs));
    v405_4_outputs.push_back(v406_2);
  }
  const Space v405_4 = join_outputs(std::move(v405_4_outputs));
  return v405_4;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v414_4_branches = branches(c,s0);
  std::vector<Space> v414_4_outputs;
  v414_4_outputs.reserve(v414_4_branches.size());
  for (const auto& v414_4_branch : v414_4_branches) {
    const Path v414_4_head{v414_4_branch.first};
    const Space& v414_4_tail = v414_4_branch.second;
    const auto v415_2_branches = branches(c,v414_4_tail);
    std::vector<Space> v415_2_outputs;
    v415_2_outputs.reserve(v415_2_branches.size());
    for (const auto& v415_2_branch : v415_2_branches) {
      const Path v415_2_head{v415_2_branch.first};
      const Space& v415_2_tail = v415_2_branch.second;
      const Path v416_2 = concat_path(v414_4_head,v415_2_head);
      const auto v416_3_branches = branches(c,v415_2_tail);
      std::vector<Space> v416_3_outputs;
      v416_3_outputs.reserve(v416_3_branches.size());
      for (const auto& v416_3_branch : v416_3_branches) {
        const Path v416_3_head{v416_3_branch.first};
        const Space& v416_3_tail = v416_3_branch.second;
        const Path v417_2 = concat_path(v416_2,v416_3_head);
        const auto v417_3_branches = branches(c,v416_3_tail);
        std::vector<Space> v417_3_outputs;
        v417_3_outputs.reserve(v417_3_branches.size());
        for (const auto& v417_3_branch : v417_3_branches) {
          const Path v417_3_head{v417_3_branch.first};
          const Space& v417_3_tail = v417_3_branch.second;
          const Path v418_2 = concat_path(v417_2,v417_3_head);
          const auto v418_3_branches = branches(c,v417_3_tail);
          std::vector<Space> v418_3_outputs;
          v418_3_outputs.reserve(v418_3_branches.size());
          for (const auto& v418_3_branch : v418_3_branches) {
            const Path v418_3_head{v418_3_branch.first};
            const Space& v418_3_tail = v418_3_branch.second;
            const auto v419_2_branches = branches(c,v418_3_tail);
            std::vector<Space> v419_2_outputs;
            v419_2_outputs.reserve(v419_2_branches.size());
            for (const auto& v419_2_branch : v419_2_branches) {
              const Path v419_2_head{v419_2_branch.first};
              const Space& v419_2_tail = v419_2_branch.second;
              const Path v420_2 = concat_path(v418_3_head,v419_2_head);
              const auto v420_3_branches = branches(c,v419_2_tail);
              std::vector<Space> v420_3_outputs;
              v420_3_outputs.reserve(v420_3_branches.size());
              for (const auto& v420_3_branch : v420_3_branches) {
                const Path v420_3_head{v420_3_branch.first};
                const Space& v420_3_tail = v420_3_branch.second;
                const Path v421_2 = concat_path(v420_2,v420_3_head);
                const auto v421_3_branches = branches(c,v420_3_tail);
                std::vector<Space> v421_3_outputs;
                v421_3_outputs.reserve(v421_3_branches.size());
                for (const auto& v421_3_branch : v421_3_branches) {
                  const Path v421_3_head{v421_3_branch.first};
                  const Space& v421_3_tail = v421_3_branch.second;
                  const Path v422_2 = concat_path(v421_2,v421_3_head);
                  const Space v422_3 = routine_64(c, v422_2, p1, p2, p0, v418_2, v421_3_tail);
                  v421_3_outputs.push_back(v422_3);
                }
                const Space v421_3 = join_outputs(std::move(v421_3_outputs));
                v420_3_outputs.push_back(v421_3);
              }
              const Space v420_3 = join_outputs(std::move(v420_3_outputs));
              v419_2_outputs.push_back(v420_3);
            }
            const Space v419_2 = join_outputs(std::move(v419_2_outputs));
            v418_3_outputs.push_back(v419_2);
          }
          const Space v418_3 = join_outputs(std::move(v418_3_outputs));
          v417_3_outputs.push_back(v418_3);
        }
        const Space v417_3 = join_outputs(std::move(v417_3_outputs));
        v416_3_outputs.push_back(v417_3);
      }
      const Space v416_3 = join_outputs(std::move(v416_3_outputs));
      v415_2_outputs.push_back(v416_3);
    }
    const Space v415_2 = join_outputs(std::move(v415_2_outputs));
    v414_4_outputs.push_back(v415_2);
  }
  const Space v414_4 = join_outputs(std::move(v414_4_outputs));
  return v414_4;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v423_4_branches = branches(c,s0);
  std::vector<Space> v423_4_outputs;
  v423_4_outputs.reserve(v423_4_branches.size());
  for (const auto& v423_4_branch : v423_4_branches) {
    const Path v423_4_head{v423_4_branch.first};
    const Space& v423_4_tail = v423_4_branch.second;
    const auto v424_2_branches = branches(c,v423_4_tail);
    std::vector<Space> v424_2_outputs;
    v424_2_outputs.reserve(v424_2_branches.size());
    for (const auto& v424_2_branch : v424_2_branches) {
      const Path v424_2_head{v424_2_branch.first};
      const Space& v424_2_tail = v424_2_branch.second;
      const Path v425_2 = concat_path(v423_4_head,v424_2_head);
      const auto v425_3_branches = branches(c,v424_2_tail);
      std::vector<Space> v425_3_outputs;
      v425_3_outputs.reserve(v425_3_branches.size());
      for (const auto& v425_3_branch : v425_3_branches) {
        const Path v425_3_head{v425_3_branch.first};
        const Space& v425_3_tail = v425_3_branch.second;
        const Path v426_2 = concat_path(v425_2,v425_3_head);
        const auto v426_3_branches = branches(c,v425_3_tail);
        std::vector<Space> v426_3_outputs;
        v426_3_outputs.reserve(v426_3_branches.size());
        for (const auto& v426_3_branch : v426_3_branches) {
          const Path v426_3_head{v426_3_branch.first};
          const Space& v426_3_tail = v426_3_branch.second;
          const Path v427_2 = concat_path(v426_2,v426_3_head);
          const auto v427_3_branches = branches(c,v426_3_tail);
          std::vector<Space> v427_3_outputs;
          v427_3_outputs.reserve(v427_3_branches.size());
          for (const auto& v427_3_branch : v427_3_branches) {
            const Path v427_3_head{v427_3_branch.first};
            const Space& v427_3_tail = v427_3_branch.second;
            const auto v428_2_branches = branches(c,v427_3_tail);
            std::vector<Space> v428_2_outputs;
            v428_2_outputs.reserve(v428_2_branches.size());
            for (const auto& v428_2_branch : v428_2_branches) {
              const Path v428_2_head{v428_2_branch.first};
              const Space& v428_2_tail = v428_2_branch.second;
              const Path v429_2 = concat_path(v427_3_head,v428_2_head);
              const auto v429_3_branches = branches(c,v428_2_tail);
              std::vector<Space> v429_3_outputs;
              v429_3_outputs.reserve(v429_3_branches.size());
              for (const auto& v429_3_branch : v429_3_branches) {
                const Path v429_3_head{v429_3_branch.first};
                const Space& v429_3_tail = v429_3_branch.second;
                const Path v430_2 = concat_path(v429_2,v429_3_head);
                const auto v430_3_branches = branches(c,v429_3_tail);
                std::vector<Space> v430_3_outputs;
                v430_3_outputs.reserve(v430_3_branches.size());
                for (const auto& v430_3_branch : v430_3_branches) {
                  const Path v430_3_head{v430_3_branch.first};
                  const Space& v430_3_tail = v430_3_branch.second;
                  const Path v431_2 = concat_path(v430_2,v430_3_head);
                  const Space v431_3 = routine_65(c, v431_2, p1, p2, p0, v427_2, v430_3_tail);
                  v430_3_outputs.push_back(v431_3);
                }
                const Space v430_3 = join_outputs(std::move(v430_3_outputs));
                v429_3_outputs.push_back(v430_3);
              }
              const Space v429_3 = join_outputs(std::move(v429_3_outputs));
              v428_2_outputs.push_back(v429_3);
            }
            const Space v428_2 = join_outputs(std::move(v428_2_outputs));
            v427_3_outputs.push_back(v428_2);
          }
          const Space v427_3 = join_outputs(std::move(v427_3_outputs));
          v426_3_outputs.push_back(v427_3);
        }
        const Space v426_3 = join_outputs(std::move(v426_3_outputs));
        v425_3_outputs.push_back(v426_3);
      }
      const Space v425_3 = join_outputs(std::move(v425_3_outputs));
      v424_2_outputs.push_back(v425_3);
    }
    const Space v424_2 = join_outputs(std::move(v424_2_outputs));
    v423_4_outputs.push_back(v424_2);
  }
  const Space v423_4 = join_outputs(std::move(v423_4_outputs));
  return v423_4;
}

static Space routine_48(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v432_4_branches = branches(c,s0);
  std::vector<Space> v432_4_outputs;
  v432_4_outputs.reserve(v432_4_branches.size());
  for (const auto& v432_4_branch : v432_4_branches) {
    const Path v432_4_head{v432_4_branch.first};
    const Space& v432_4_tail = v432_4_branch.second;
    const auto v433_2_branches = branches(c,v432_4_tail);
    std::vector<Space> v433_2_outputs;
    v433_2_outputs.reserve(v433_2_branches.size());
    for (const auto& v433_2_branch : v433_2_branches) {
      const Path v433_2_head{v433_2_branch.first};
      const Space& v433_2_tail = v433_2_branch.second;
      const Path v434_2 = concat_path(v432_4_head,v433_2_head);
      const auto v434_3_branches = branches(c,v433_2_tail);
      std::vector<Space> v434_3_outputs;
      v434_3_outputs.reserve(v434_3_branches.size());
      for (const auto& v434_3_branch : v434_3_branches) {
        const Path v434_3_head{v434_3_branch.first};
        const Space& v434_3_tail = v434_3_branch.second;
        const Path v435_2 = concat_path(v434_2,v434_3_head);
        const auto v435_3_branches = branches(c,v434_3_tail);
        std::vector<Space> v435_3_outputs;
        v435_3_outputs.reserve(v435_3_branches.size());
        for (const auto& v435_3_branch : v435_3_branches) {
          const Path v435_3_head{v435_3_branch.first};
          const Space& v435_3_tail = v435_3_branch.second;
          const Path v436_2 = concat_path(v435_2,v435_3_head);
          const auto v436_3_branches = branches(c,v435_3_tail);
          std::vector<Space> v436_3_outputs;
          v436_3_outputs.reserve(v436_3_branches.size());
          for (const auto& v436_3_branch : v436_3_branches) {
            const Path v436_3_head{v436_3_branch.first};
            const Space& v436_3_tail = v436_3_branch.second;
            const auto v437_2_branches = branches(c,v436_3_tail);
            std::vector<Space> v437_2_outputs;
            v437_2_outputs.reserve(v437_2_branches.size());
            for (const auto& v437_2_branch : v437_2_branches) {
              const Path v437_2_head{v437_2_branch.first};
              const Space& v437_2_tail = v437_2_branch.second;
              const Path v438_2 = concat_path(v436_3_head,v437_2_head);
              const auto v438_3_branches = branches(c,v437_2_tail);
              std::vector<Space> v438_3_outputs;
              v438_3_outputs.reserve(v438_3_branches.size());
              for (const auto& v438_3_branch : v438_3_branches) {
                const Path v438_3_head{v438_3_branch.first};
                const Space& v438_3_tail = v438_3_branch.second;
                const Path v439_2 = concat_path(v438_2,v438_3_head);
                const auto v439_3_branches = branches(c,v438_3_tail);
                std::vector<Space> v439_3_outputs;
                v439_3_outputs.reserve(v439_3_branches.size());
                for (const auto& v439_3_branch : v439_3_branches) {
                  const Path v439_3_head{v439_3_branch.first};
                  const Space& v439_3_tail = v439_3_branch.second;
                  const Path v440_2 = concat_path(v439_2,v439_3_head);
                  const Space v440_3 = routine_66(c, v440_2, p1, p2, p0, v436_2, v439_3_tail);
                  v439_3_outputs.push_back(v440_3);
                }
                const Space v439_3 = join_outputs(std::move(v439_3_outputs));
                v438_3_outputs.push_back(v439_3);
              }
              const Space v438_3 = join_outputs(std::move(v438_3_outputs));
              v437_2_outputs.push_back(v438_3);
            }
            const Space v437_2 = join_outputs(std::move(v437_2_outputs));
            v436_3_outputs.push_back(v437_2);
          }
          const Space v436_3 = join_outputs(std::move(v436_3_outputs));
          v435_3_outputs.push_back(v436_3);
        }
        const Space v435_3 = join_outputs(std::move(v435_3_outputs));
        v434_3_outputs.push_back(v435_3);
      }
      const Space v434_3 = join_outputs(std::move(v434_3_outputs));
      v433_2_outputs.push_back(v434_3);
    }
    const Space v433_2 = join_outputs(std::move(v433_2_outputs));
    v432_4_outputs.push_back(v433_2);
  }
  const Space v432_4 = join_outputs(std::move(v432_4_outputs));
  return v432_4;
}

static Space routine_49(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v441_4_branches = branches(c,s0);
  std::vector<Space> v441_4_outputs;
  v441_4_outputs.reserve(v441_4_branches.size());
  for (const auto& v441_4_branch : v441_4_branches) {
    const Path v441_4_head{v441_4_branch.first};
    const Space& v441_4_tail = v441_4_branch.second;
    const auto v442_2_branches = branches(c,v441_4_tail);
    std::vector<Space> v442_2_outputs;
    v442_2_outputs.reserve(v442_2_branches.size());
    for (const auto& v442_2_branch : v442_2_branches) {
      const Path v442_2_head{v442_2_branch.first};
      const Space& v442_2_tail = v442_2_branch.second;
      const Path v443_2 = concat_path(v441_4_head,v442_2_head);
      const auto v443_3_branches = branches(c,v442_2_tail);
      std::vector<Space> v443_3_outputs;
      v443_3_outputs.reserve(v443_3_branches.size());
      for (const auto& v443_3_branch : v443_3_branches) {
        const Path v443_3_head{v443_3_branch.first};
        const Space& v443_3_tail = v443_3_branch.second;
        const Path v444_2 = concat_path(v443_2,v443_3_head);
        const auto v444_3_branches = branches(c,v443_3_tail);
        std::vector<Space> v444_3_outputs;
        v444_3_outputs.reserve(v444_3_branches.size());
        for (const auto& v444_3_branch : v444_3_branches) {
          const Path v444_3_head{v444_3_branch.first};
          const Space& v444_3_tail = v444_3_branch.second;
          const Path v445_2 = concat_path(v444_2,v444_3_head);
          const auto v445_3_branches = branches(c,v444_3_tail);
          std::vector<Space> v445_3_outputs;
          v445_3_outputs.reserve(v445_3_branches.size());
          for (const auto& v445_3_branch : v445_3_branches) {
            const Path v445_3_head{v445_3_branch.first};
            const Space& v445_3_tail = v445_3_branch.second;
            const auto v446_2_branches = branches(c,v445_3_tail);
            std::vector<Space> v446_2_outputs;
            v446_2_outputs.reserve(v446_2_branches.size());
            for (const auto& v446_2_branch : v446_2_branches) {
              const Path v446_2_head{v446_2_branch.first};
              const Space& v446_2_tail = v446_2_branch.second;
              const Path v447_2 = concat_path(v445_3_head,v446_2_head);
              const auto v447_3_branches = branches(c,v446_2_tail);
              std::vector<Space> v447_3_outputs;
              v447_3_outputs.reserve(v447_3_branches.size());
              for (const auto& v447_3_branch : v447_3_branches) {
                const Path v447_3_head{v447_3_branch.first};
                const Space& v447_3_tail = v447_3_branch.second;
                const Path v448_2 = concat_path(v447_2,v447_3_head);
                const auto v448_3_branches = branches(c,v447_3_tail);
                std::vector<Space> v448_3_outputs;
                v448_3_outputs.reserve(v448_3_branches.size());
                for (const auto& v448_3_branch : v448_3_branches) {
                  const Path v448_3_head{v448_3_branch.first};
                  const Space& v448_3_tail = v448_3_branch.second;
                  const Path v449_2 = concat_path(v448_2,v448_3_head);
                  const Space v449_3 = routine_67(c, v449_2, p1, p2, p0, v445_2, v448_3_tail);
                  v448_3_outputs.push_back(v449_3);
                }
                const Space v448_3 = join_outputs(std::move(v448_3_outputs));
                v447_3_outputs.push_back(v448_3);
              }
              const Space v447_3 = join_outputs(std::move(v447_3_outputs));
              v446_2_outputs.push_back(v447_3);
            }
            const Space v446_2 = join_outputs(std::move(v446_2_outputs));
            v445_3_outputs.push_back(v446_2);
          }
          const Space v445_3 = join_outputs(std::move(v445_3_outputs));
          v444_3_outputs.push_back(v445_3);
        }
        const Space v444_3 = join_outputs(std::move(v444_3_outputs));
        v443_3_outputs.push_back(v444_3);
      }
      const Space v443_3 = join_outputs(std::move(v443_3_outputs));
      v442_2_outputs.push_back(v443_3);
    }
    const Space v442_2 = join_outputs(std::move(v442_2_outputs));
    v441_4_outputs.push_back(v442_2);
  }
  const Space v441_4 = join_outputs(std::move(v441_4_outputs));
  return v441_4;
}

static Space routine_50(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v450_4_branches = branches(c,s0);
  std::vector<Space> v450_4_outputs;
  v450_4_outputs.reserve(v450_4_branches.size());
  for (const auto& v450_4_branch : v450_4_branches) {
    const Path v450_4_head{v450_4_branch.first};
    const Space& v450_4_tail = v450_4_branch.second;
    const auto v451_2_branches = branches(c,v450_4_tail);
    std::vector<Space> v451_2_outputs;
    v451_2_outputs.reserve(v451_2_branches.size());
    for (const auto& v451_2_branch : v451_2_branches) {
      const Path v451_2_head{v451_2_branch.first};
      const Space& v451_2_tail = v451_2_branch.second;
      const Path v452_2 = concat_path(v450_4_head,v451_2_head);
      const auto v452_3_branches = branches(c,v451_2_tail);
      std::vector<Space> v452_3_outputs;
      v452_3_outputs.reserve(v452_3_branches.size());
      for (const auto& v452_3_branch : v452_3_branches) {
        const Path v452_3_head{v452_3_branch.first};
        const Space& v452_3_tail = v452_3_branch.second;
        const Path v453_2 = concat_path(v452_2,v452_3_head);
        const auto v453_3_branches = branches(c,v452_3_tail);
        std::vector<Space> v453_3_outputs;
        v453_3_outputs.reserve(v453_3_branches.size());
        for (const auto& v453_3_branch : v453_3_branches) {
          const Path v453_3_head{v453_3_branch.first};
          const Space& v453_3_tail = v453_3_branch.second;
          const Path v454_2 = concat_path(v453_2,v453_3_head);
          const auto v454_3_branches = branches(c,v453_3_tail);
          std::vector<Space> v454_3_outputs;
          v454_3_outputs.reserve(v454_3_branches.size());
          for (const auto& v454_3_branch : v454_3_branches) {
            const Path v454_3_head{v454_3_branch.first};
            const Space& v454_3_tail = v454_3_branch.second;
            const auto v455_2_branches = branches(c,v454_3_tail);
            std::vector<Space> v455_2_outputs;
            v455_2_outputs.reserve(v455_2_branches.size());
            for (const auto& v455_2_branch : v455_2_branches) {
              const Path v455_2_head{v455_2_branch.first};
              const Space& v455_2_tail = v455_2_branch.second;
              const Path v456_2 = concat_path(v454_3_head,v455_2_head);
              const auto v456_3_branches = branches(c,v455_2_tail);
              std::vector<Space> v456_3_outputs;
              v456_3_outputs.reserve(v456_3_branches.size());
              for (const auto& v456_3_branch : v456_3_branches) {
                const Path v456_3_head{v456_3_branch.first};
                const Space& v456_3_tail = v456_3_branch.second;
                const Path v457_2 = concat_path(v456_2,v456_3_head);
                const auto v457_3_branches = branches(c,v456_3_tail);
                std::vector<Space> v457_3_outputs;
                v457_3_outputs.reserve(v457_3_branches.size());
                for (const auto& v457_3_branch : v457_3_branches) {
                  const Path v457_3_head{v457_3_branch.first};
                  const Space& v457_3_tail = v457_3_branch.second;
                  const Path v458_2 = concat_path(v457_2,v457_3_head);
                  const Space v458_3 = routine_68(c, v458_2, p1, p2, p0, v454_2, v457_3_tail);
                  v457_3_outputs.push_back(v458_3);
                }
                const Space v457_3 = join_outputs(std::move(v457_3_outputs));
                v456_3_outputs.push_back(v457_3);
              }
              const Space v456_3 = join_outputs(std::move(v456_3_outputs));
              v455_2_outputs.push_back(v456_3);
            }
            const Space v455_2 = join_outputs(std::move(v455_2_outputs));
            v454_3_outputs.push_back(v455_2);
          }
          const Space v454_3 = join_outputs(std::move(v454_3_outputs));
          v453_3_outputs.push_back(v454_3);
        }
        const Space v453_3 = join_outputs(std::move(v453_3_outputs));
        v452_3_outputs.push_back(v453_3);
      }
      const Space v452_3 = join_outputs(std::move(v452_3_outputs));
      v451_2_outputs.push_back(v452_3);
    }
    const Space v451_2 = join_outputs(std::move(v451_2_outputs));
    v450_4_outputs.push_back(v451_2);
  }
  const Space v450_4 = join_outputs(std::move(v450_4_outputs));
  return v450_4;
}

static Space routine_51(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v459_4_branches = branches(c,s0);
  std::vector<Space> v459_4_outputs;
  v459_4_outputs.reserve(v459_4_branches.size());
  for (const auto& v459_4_branch : v459_4_branches) {
    const Path v459_4_head{v459_4_branch.first};
    const Space& v459_4_tail = v459_4_branch.second;
    const auto v460_2_branches = branches(c,v459_4_tail);
    std::vector<Space> v460_2_outputs;
    v460_2_outputs.reserve(v460_2_branches.size());
    for (const auto& v460_2_branch : v460_2_branches) {
      const Path v460_2_head{v460_2_branch.first};
      const Space& v460_2_tail = v460_2_branch.second;
      const Path v461_2 = concat_path(v459_4_head,v460_2_head);
      const auto v461_3_branches = branches(c,v460_2_tail);
      std::vector<Space> v461_3_outputs;
      v461_3_outputs.reserve(v461_3_branches.size());
      for (const auto& v461_3_branch : v461_3_branches) {
        const Path v461_3_head{v461_3_branch.first};
        const Space& v461_3_tail = v461_3_branch.second;
        const Path v462_2 = concat_path(v461_2,v461_3_head);
        const auto v462_3_branches = branches(c,v461_3_tail);
        std::vector<Space> v462_3_outputs;
        v462_3_outputs.reserve(v462_3_branches.size());
        for (const auto& v462_3_branch : v462_3_branches) {
          const Path v462_3_head{v462_3_branch.first};
          const Space& v462_3_tail = v462_3_branch.second;
          const Path v463_2 = concat_path(v462_2,v462_3_head);
          const auto v463_3_branches = branches(c,v462_3_tail);
          std::vector<Space> v463_3_outputs;
          v463_3_outputs.reserve(v463_3_branches.size());
          for (const auto& v463_3_branch : v463_3_branches) {
            const Path v463_3_head{v463_3_branch.first};
            const Space& v463_3_tail = v463_3_branch.second;
            const auto v464_2_branches = branches(c,v463_3_tail);
            std::vector<Space> v464_2_outputs;
            v464_2_outputs.reserve(v464_2_branches.size());
            for (const auto& v464_2_branch : v464_2_branches) {
              const Path v464_2_head{v464_2_branch.first};
              const Space& v464_2_tail = v464_2_branch.second;
              const Path v465_2 = concat_path(v463_3_head,v464_2_head);
              const auto v465_3_branches = branches(c,v464_2_tail);
              std::vector<Space> v465_3_outputs;
              v465_3_outputs.reserve(v465_3_branches.size());
              for (const auto& v465_3_branch : v465_3_branches) {
                const Path v465_3_head{v465_3_branch.first};
                const Space& v465_3_tail = v465_3_branch.second;
                const Path v466_2 = concat_path(v465_2,v465_3_head);
                const auto v466_3_branches = branches(c,v465_3_tail);
                std::vector<Space> v466_3_outputs;
                v466_3_outputs.reserve(v466_3_branches.size());
                for (const auto& v466_3_branch : v466_3_branches) {
                  const Path v466_3_head{v466_3_branch.first};
                  const Space& v466_3_tail = v466_3_branch.second;
                  const Path v467_2 = concat_path(v466_2,v466_3_head);
                  const Space v467_3 = routine_69(c, v467_2, p1, p2, p0, v463_2, v466_3_tail);
                  v466_3_outputs.push_back(v467_3);
                }
                const Space v466_3 = join_outputs(std::move(v466_3_outputs));
                v465_3_outputs.push_back(v466_3);
              }
              const Space v465_3 = join_outputs(std::move(v465_3_outputs));
              v464_2_outputs.push_back(v465_3);
            }
            const Space v464_2 = join_outputs(std::move(v464_2_outputs));
            v463_3_outputs.push_back(v464_2);
          }
          const Space v463_3 = join_outputs(std::move(v463_3_outputs));
          v462_3_outputs.push_back(v463_3);
        }
        const Space v462_3 = join_outputs(std::move(v462_3_outputs));
        v461_3_outputs.push_back(v462_3);
      }
      const Space v461_3 = join_outputs(std::move(v461_3_outputs));
      v460_2_outputs.push_back(v461_3);
    }
    const Space v460_2 = join_outputs(std::move(v460_2_outputs));
    v459_4_outputs.push_back(v460_2);
  }
  const Space v459_4 = join_outputs(std::move(v459_4_outputs));
  return v459_4;
}

static Space routine_52(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v468_4_branches = branches(c,s0);
  std::vector<Space> v468_4_outputs;
  v468_4_outputs.reserve(v468_4_branches.size());
  for (const auto& v468_4_branch : v468_4_branches) {
    const Path v468_4_head{v468_4_branch.first};
    const Space& v468_4_tail = v468_4_branch.second;
    const auto v469_2_branches = branches(c,v468_4_tail);
    std::vector<Space> v469_2_outputs;
    v469_2_outputs.reserve(v469_2_branches.size());
    for (const auto& v469_2_branch : v469_2_branches) {
      const Path v469_2_head{v469_2_branch.first};
      const Space& v469_2_tail = v469_2_branch.second;
      const Path v470_2 = concat_path(v468_4_head,v469_2_head);
      const auto v470_3_branches = branches(c,v469_2_tail);
      std::vector<Space> v470_3_outputs;
      v470_3_outputs.reserve(v470_3_branches.size());
      for (const auto& v470_3_branch : v470_3_branches) {
        const Path v470_3_head{v470_3_branch.first};
        const Space& v470_3_tail = v470_3_branch.second;
        const Path v471_2 = concat_path(v470_2,v470_3_head);
        const auto v471_3_branches = branches(c,v470_3_tail);
        std::vector<Space> v471_3_outputs;
        v471_3_outputs.reserve(v471_3_branches.size());
        for (const auto& v471_3_branch : v471_3_branches) {
          const Path v471_3_head{v471_3_branch.first};
          const Space& v471_3_tail = v471_3_branch.second;
          const Path v472_2 = concat_path(v471_2,v471_3_head);
          const auto v472_3_branches = branches(c,v471_3_tail);
          std::vector<Space> v472_3_outputs;
          v472_3_outputs.reserve(v472_3_branches.size());
          for (const auto& v472_3_branch : v472_3_branches) {
            const Path v472_3_head{v472_3_branch.first};
            const Space& v472_3_tail = v472_3_branch.second;
            const auto v473_2_branches = branches(c,v472_3_tail);
            std::vector<Space> v473_2_outputs;
            v473_2_outputs.reserve(v473_2_branches.size());
            for (const auto& v473_2_branch : v473_2_branches) {
              const Path v473_2_head{v473_2_branch.first};
              const Space& v473_2_tail = v473_2_branch.second;
              const Path v474_2 = concat_path(v472_3_head,v473_2_head);
              const auto v474_3_branches = branches(c,v473_2_tail);
              std::vector<Space> v474_3_outputs;
              v474_3_outputs.reserve(v474_3_branches.size());
              for (const auto& v474_3_branch : v474_3_branches) {
                const Path v474_3_head{v474_3_branch.first};
                const Space& v474_3_tail = v474_3_branch.second;
                const Path v475_2 = concat_path(v474_2,v474_3_head);
                const auto v475_3_branches = branches(c,v474_3_tail);
                std::vector<Space> v475_3_outputs;
                v475_3_outputs.reserve(v475_3_branches.size());
                for (const auto& v475_3_branch : v475_3_branches) {
                  const Path v475_3_head{v475_3_branch.first};
                  const Space& v475_3_tail = v475_3_branch.second;
                  const Path v476_2 = concat_path(v475_2,v475_3_head);
                  const Space v476_3 = routine_70(c, v476_2, p1, p2, p0, v472_2, v475_3_tail);
                  v475_3_outputs.push_back(v476_3);
                }
                const Space v475_3 = join_outputs(std::move(v475_3_outputs));
                v474_3_outputs.push_back(v475_3);
              }
              const Space v474_3 = join_outputs(std::move(v474_3_outputs));
              v473_2_outputs.push_back(v474_3);
            }
            const Space v473_2 = join_outputs(std::move(v473_2_outputs));
            v472_3_outputs.push_back(v473_2);
          }
          const Space v472_3 = join_outputs(std::move(v472_3_outputs));
          v471_3_outputs.push_back(v472_3);
        }
        const Space v471_3 = join_outputs(std::move(v471_3_outputs));
        v470_3_outputs.push_back(v471_3);
      }
      const Space v470_3 = join_outputs(std::move(v470_3_outputs));
      v469_2_outputs.push_back(v470_3);
    }
    const Space v469_2 = join_outputs(std::move(v469_2_outputs));
    v468_4_outputs.push_back(v469_2);
  }
  const Space v468_4 = join_outputs(std::move(v468_4_outputs));
  return v468_4;
}

static Space routine_53(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v477_4_branches = branches(c,s0);
  std::vector<Space> v477_4_outputs;
  v477_4_outputs.reserve(v477_4_branches.size());
  for (const auto& v477_4_branch : v477_4_branches) {
    const Path v477_4_head{v477_4_branch.first};
    const Space& v477_4_tail = v477_4_branch.second;
    const auto v478_2_branches = branches(c,v477_4_tail);
    std::vector<Space> v478_2_outputs;
    v478_2_outputs.reserve(v478_2_branches.size());
    for (const auto& v478_2_branch : v478_2_branches) {
      const Path v478_2_head{v478_2_branch.first};
      const Space& v478_2_tail = v478_2_branch.second;
      const Path v479_2 = concat_path(v477_4_head,v478_2_head);
      const auto v479_3_branches = branches(c,v478_2_tail);
      std::vector<Space> v479_3_outputs;
      v479_3_outputs.reserve(v479_3_branches.size());
      for (const auto& v479_3_branch : v479_3_branches) {
        const Path v479_3_head{v479_3_branch.first};
        const Space& v479_3_tail = v479_3_branch.second;
        const Path v480_2 = concat_path(v479_2,v479_3_head);
        const auto v480_3_branches = branches(c,v479_3_tail);
        std::vector<Space> v480_3_outputs;
        v480_3_outputs.reserve(v480_3_branches.size());
        for (const auto& v480_3_branch : v480_3_branches) {
          const Path v480_3_head{v480_3_branch.first};
          const Space& v480_3_tail = v480_3_branch.second;
          const Path v481_2 = concat_path(v480_2,v480_3_head);
          const auto v481_3_branches = branches(c,v480_3_tail);
          std::vector<Space> v481_3_outputs;
          v481_3_outputs.reserve(v481_3_branches.size());
          for (const auto& v481_3_branch : v481_3_branches) {
            const Path v481_3_head{v481_3_branch.first};
            const Space& v481_3_tail = v481_3_branch.second;
            const auto v482_2_branches = branches(c,v481_3_tail);
            std::vector<Space> v482_2_outputs;
            v482_2_outputs.reserve(v482_2_branches.size());
            for (const auto& v482_2_branch : v482_2_branches) {
              const Path v482_2_head{v482_2_branch.first};
              const Space& v482_2_tail = v482_2_branch.second;
              const Path v483_2 = concat_path(v481_3_head,v482_2_head);
              const auto v483_3_branches = branches(c,v482_2_tail);
              std::vector<Space> v483_3_outputs;
              v483_3_outputs.reserve(v483_3_branches.size());
              for (const auto& v483_3_branch : v483_3_branches) {
                const Path v483_3_head{v483_3_branch.first};
                const Space& v483_3_tail = v483_3_branch.second;
                const Path v484_2 = concat_path(v483_2,v483_3_head);
                const auto v484_3_branches = branches(c,v483_3_tail);
                std::vector<Space> v484_3_outputs;
                v484_3_outputs.reserve(v484_3_branches.size());
                for (const auto& v484_3_branch : v484_3_branches) {
                  const Path v484_3_head{v484_3_branch.first};
                  const Space& v484_3_tail = v484_3_branch.second;
                  const Path v485_2 = concat_path(v484_2,v484_3_head);
                  const Space v485_3 = routine_71(c, v485_2, p1, p2, p0, v481_2, v484_3_tail);
                  v484_3_outputs.push_back(v485_3);
                }
                const Space v484_3 = join_outputs(std::move(v484_3_outputs));
                v483_3_outputs.push_back(v484_3);
              }
              const Space v483_3 = join_outputs(std::move(v483_3_outputs));
              v482_2_outputs.push_back(v483_3);
            }
            const Space v482_2 = join_outputs(std::move(v482_2_outputs));
            v481_3_outputs.push_back(v482_2);
          }
          const Space v481_3 = join_outputs(std::move(v481_3_outputs));
          v480_3_outputs.push_back(v481_3);
        }
        const Space v480_3 = join_outputs(std::move(v480_3_outputs));
        v479_3_outputs.push_back(v480_3);
      }
      const Space v479_3 = join_outputs(std::move(v479_3_outputs));
      v478_2_outputs.push_back(v479_3);
    }
    const Space v478_2 = join_outputs(std::move(v478_2_outputs));
    v477_4_outputs.push_back(v478_2);
  }
  const Space v477_4 = join_outputs(std::move(v477_4_outputs));
  return v477_4;
}

static Space routine_54(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v486_4_branches = branches(c,s0);
  std::vector<Space> v486_4_outputs;
  v486_4_outputs.reserve(v486_4_branches.size());
  for (const auto& v486_4_branch : v486_4_branches) {
    const Path v486_4_head{v486_4_branch.first};
    const Space& v486_4_tail = v486_4_branch.second;
    const auto v487_2_branches = branches(c,v486_4_tail);
    std::vector<Space> v487_2_outputs;
    v487_2_outputs.reserve(v487_2_branches.size());
    for (const auto& v487_2_branch : v487_2_branches) {
      const Path v487_2_head{v487_2_branch.first};
      const Space& v487_2_tail = v487_2_branch.second;
      const Path v488_2 = concat_path(v486_4_head,v487_2_head);
      const auto v488_3_branches = branches(c,v487_2_tail);
      std::vector<Space> v488_3_outputs;
      v488_3_outputs.reserve(v488_3_branches.size());
      for (const auto& v488_3_branch : v488_3_branches) {
        const Path v488_3_head{v488_3_branch.first};
        const Space& v488_3_tail = v488_3_branch.second;
        const Path v489_2 = concat_path(v488_2,v488_3_head);
        const auto v489_3_branches = branches(c,v488_3_tail);
        std::vector<Space> v489_3_outputs;
        v489_3_outputs.reserve(v489_3_branches.size());
        for (const auto& v489_3_branch : v489_3_branches) {
          const Path v489_3_head{v489_3_branch.first};
          const Space& v489_3_tail = v489_3_branch.second;
          const Path v490_2 = concat_path(v489_2,v489_3_head);
          const auto v490_3_branches = branches(c,v489_3_tail);
          std::vector<Space> v490_3_outputs;
          v490_3_outputs.reserve(v490_3_branches.size());
          for (const auto& v490_3_branch : v490_3_branches) {
            const Path v490_3_head{v490_3_branch.first};
            const Space& v490_3_tail = v490_3_branch.second;
            const auto v491_2_branches = branches(c,v490_3_tail);
            std::vector<Space> v491_2_outputs;
            v491_2_outputs.reserve(v491_2_branches.size());
            for (const auto& v491_2_branch : v491_2_branches) {
              const Path v491_2_head{v491_2_branch.first};
              const Space& v491_2_tail = v491_2_branch.second;
              const Path v492_2 = concat_path(v490_3_head,v491_2_head);
              const auto v492_3_branches = branches(c,v491_2_tail);
              std::vector<Space> v492_3_outputs;
              v492_3_outputs.reserve(v492_3_branches.size());
              for (const auto& v492_3_branch : v492_3_branches) {
                const Path v492_3_head{v492_3_branch.first};
                const Space& v492_3_tail = v492_3_branch.second;
                const Path v493_2 = concat_path(v492_2,v492_3_head);
                const auto v493_3_branches = branches(c,v492_3_tail);
                std::vector<Space> v493_3_outputs;
                v493_3_outputs.reserve(v493_3_branches.size());
                for (const auto& v493_3_branch : v493_3_branches) {
                  const Path v493_3_head{v493_3_branch.first};
                  const Space& v493_3_tail = v493_3_branch.second;
                  const Path v494_2 = concat_path(v493_2,v493_3_head);
                  const Space v494_3 = routine_72(c, v494_2, p1, p2, p0, v490_2, v493_3_tail);
                  v493_3_outputs.push_back(v494_3);
                }
                const Space v493_3 = join_outputs(std::move(v493_3_outputs));
                v492_3_outputs.push_back(v493_3);
              }
              const Space v492_3 = join_outputs(std::move(v492_3_outputs));
              v491_2_outputs.push_back(v492_3);
            }
            const Space v491_2 = join_outputs(std::move(v491_2_outputs));
            v490_3_outputs.push_back(v491_2);
          }
          const Space v490_3 = join_outputs(std::move(v490_3_outputs));
          v489_3_outputs.push_back(v490_3);
        }
        const Space v489_3 = join_outputs(std::move(v489_3_outputs));
        v488_3_outputs.push_back(v489_3);
      }
      const Space v488_3 = join_outputs(std::move(v488_3_outputs));
      v487_2_outputs.push_back(v488_3);
    }
    const Space v487_2 = join_outputs(std::move(v487_2_outputs));
    v486_4_outputs.push_back(v487_2);
  }
  const Space v486_4 = join_outputs(std::move(v486_4_outputs));
  return v486_4;
}

static Space routine_55(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v495_4_branches = branches(c,s0);
  std::vector<Space> v495_4_outputs;
  v495_4_outputs.reserve(v495_4_branches.size());
  for (const auto& v495_4_branch : v495_4_branches) {
    const Path v495_4_head{v495_4_branch.first};
    const Space& v495_4_tail = v495_4_branch.second;
    const auto v496_2_branches = branches(c,v495_4_tail);
    std::vector<Space> v496_2_outputs;
    v496_2_outputs.reserve(v496_2_branches.size());
    for (const auto& v496_2_branch : v496_2_branches) {
      const Path v496_2_head{v496_2_branch.first};
      const Space& v496_2_tail = v496_2_branch.second;
      const Path v497_2 = concat_path(v495_4_head,v496_2_head);
      const auto v497_3_branches = branches(c,v496_2_tail);
      std::vector<Space> v497_3_outputs;
      v497_3_outputs.reserve(v497_3_branches.size());
      for (const auto& v497_3_branch : v497_3_branches) {
        const Path v497_3_head{v497_3_branch.first};
        const Space& v497_3_tail = v497_3_branch.second;
        const Path v498_2 = concat_path(v497_2,v497_3_head);
        const auto v498_3_branches = branches(c,v497_3_tail);
        std::vector<Space> v498_3_outputs;
        v498_3_outputs.reserve(v498_3_branches.size());
        for (const auto& v498_3_branch : v498_3_branches) {
          const Path v498_3_head{v498_3_branch.first};
          const Space& v498_3_tail = v498_3_branch.second;
          const Path v499_2 = concat_path(v498_2,v498_3_head);
          const auto v499_3_branches = branches(c,v498_3_tail);
          std::vector<Space> v499_3_outputs;
          v499_3_outputs.reserve(v499_3_branches.size());
          for (const auto& v499_3_branch : v499_3_branches) {
            const Path v499_3_head{v499_3_branch.first};
            const Space& v499_3_tail = v499_3_branch.second;
            const auto v500_2_branches = branches(c,v499_3_tail);
            std::vector<Space> v500_2_outputs;
            v500_2_outputs.reserve(v500_2_branches.size());
            for (const auto& v500_2_branch : v500_2_branches) {
              const Path v500_2_head{v500_2_branch.first};
              const Space& v500_2_tail = v500_2_branch.second;
              const Path v501_2 = concat_path(v499_3_head,v500_2_head);
              const auto v501_3_branches = branches(c,v500_2_tail);
              std::vector<Space> v501_3_outputs;
              v501_3_outputs.reserve(v501_3_branches.size());
              for (const auto& v501_3_branch : v501_3_branches) {
                const Path v501_3_head{v501_3_branch.first};
                const Space& v501_3_tail = v501_3_branch.second;
                const Path v502_2 = concat_path(v501_2,v501_3_head);
                const auto v502_3_branches = branches(c,v501_3_tail);
                std::vector<Space> v502_3_outputs;
                v502_3_outputs.reserve(v502_3_branches.size());
                for (const auto& v502_3_branch : v502_3_branches) {
                  const Path v502_3_head{v502_3_branch.first};
                  const Space& v502_3_tail = v502_3_branch.second;
                  const Path v503_2 = concat_path(v502_2,v502_3_head);
                  const Space v503_3 = routine_73(c, v503_2, p1, p2, p0, v499_2, v502_3_tail);
                  v502_3_outputs.push_back(v503_3);
                }
                const Space v502_3 = join_outputs(std::move(v502_3_outputs));
                v501_3_outputs.push_back(v502_3);
              }
              const Space v501_3 = join_outputs(std::move(v501_3_outputs));
              v500_2_outputs.push_back(v501_3);
            }
            const Space v500_2 = join_outputs(std::move(v500_2_outputs));
            v499_3_outputs.push_back(v500_2);
          }
          const Space v499_3 = join_outputs(std::move(v499_3_outputs));
          v498_3_outputs.push_back(v499_3);
        }
        const Space v498_3 = join_outputs(std::move(v498_3_outputs));
        v497_3_outputs.push_back(v498_3);
      }
      const Space v497_3 = join_outputs(std::move(v497_3_outputs));
      v496_2_outputs.push_back(v497_3);
    }
    const Space v496_2 = join_outputs(std::move(v496_2_outputs));
    v495_4_outputs.push_back(v496_2);
  }
  const Space v495_4 = join_outputs(std::move(v495_4_outputs));
  return v495_4;
}

static Space routine_56(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v504_4_branches = branches(c,s0);
  std::vector<Space> v504_4_outputs;
  v504_4_outputs.reserve(v504_4_branches.size());
  for (const auto& v504_4_branch : v504_4_branches) {
    const Path v504_4_head{v504_4_branch.first};
    const Space& v504_4_tail = v504_4_branch.second;
    const auto v505_2_branches = branches(c,v504_4_tail);
    std::vector<Space> v505_2_outputs;
    v505_2_outputs.reserve(v505_2_branches.size());
    for (const auto& v505_2_branch : v505_2_branches) {
      const Path v505_2_head{v505_2_branch.first};
      const Space& v505_2_tail = v505_2_branch.second;
      const Path v506_2 = concat_path(v504_4_head,v505_2_head);
      const auto v506_3_branches = branches(c,v505_2_tail);
      std::vector<Space> v506_3_outputs;
      v506_3_outputs.reserve(v506_3_branches.size());
      for (const auto& v506_3_branch : v506_3_branches) {
        const Path v506_3_head{v506_3_branch.first};
        const Space& v506_3_tail = v506_3_branch.second;
        const Path v507_2 = concat_path(v506_2,v506_3_head);
        const auto v507_3_branches = branches(c,v506_3_tail);
        std::vector<Space> v507_3_outputs;
        v507_3_outputs.reserve(v507_3_branches.size());
        for (const auto& v507_3_branch : v507_3_branches) {
          const Path v507_3_head{v507_3_branch.first};
          const Space& v507_3_tail = v507_3_branch.second;
          const Path v508_2 = concat_path(v507_2,v507_3_head);
          const auto v508_3_branches = branches(c,v507_3_tail);
          std::vector<Space> v508_3_outputs;
          v508_3_outputs.reserve(v508_3_branches.size());
          for (const auto& v508_3_branch : v508_3_branches) {
            const Path v508_3_head{v508_3_branch.first};
            const Space& v508_3_tail = v508_3_branch.second;
            const auto v509_2_branches = branches(c,v508_3_tail);
            std::vector<Space> v509_2_outputs;
            v509_2_outputs.reserve(v509_2_branches.size());
            for (const auto& v509_2_branch : v509_2_branches) {
              const Path v509_2_head{v509_2_branch.first};
              const Space& v509_2_tail = v509_2_branch.second;
              const Path v510_2 = concat_path(v508_3_head,v509_2_head);
              const auto v510_3_branches = branches(c,v509_2_tail);
              std::vector<Space> v510_3_outputs;
              v510_3_outputs.reserve(v510_3_branches.size());
              for (const auto& v510_3_branch : v510_3_branches) {
                const Path v510_3_head{v510_3_branch.first};
                const Space& v510_3_tail = v510_3_branch.second;
                const Path v511_2 = concat_path(v510_2,v510_3_head);
                const auto v511_3_branches = branches(c,v510_3_tail);
                std::vector<Space> v511_3_outputs;
                v511_3_outputs.reserve(v511_3_branches.size());
                for (const auto& v511_3_branch : v511_3_branches) {
                  const Path v511_3_head{v511_3_branch.first};
                  const Space& v511_3_tail = v511_3_branch.second;
                  const Path v512_2 = concat_path(v511_2,v511_3_head);
                  const Space v512_3 = routine_74(c, v512_2, p1, p2, p0, v508_2, v511_3_tail);
                  v511_3_outputs.push_back(v512_3);
                }
                const Space v511_3 = join_outputs(std::move(v511_3_outputs));
                v510_3_outputs.push_back(v511_3);
              }
              const Space v510_3 = join_outputs(std::move(v510_3_outputs));
              v509_2_outputs.push_back(v510_3);
            }
            const Space v509_2 = join_outputs(std::move(v509_2_outputs));
            v508_3_outputs.push_back(v509_2);
          }
          const Space v508_3 = join_outputs(std::move(v508_3_outputs));
          v507_3_outputs.push_back(v508_3);
        }
        const Space v507_3 = join_outputs(std::move(v507_3_outputs));
        v506_3_outputs.push_back(v507_3);
      }
      const Space v506_3 = join_outputs(std::move(v506_3_outputs));
      v505_2_outputs.push_back(v506_3);
    }
    const Space v505_2 = join_outputs(std::move(v505_2_outputs));
    v504_4_outputs.push_back(v505_2);
  }
  const Space v504_4 = join_outputs(std::move(v504_4_outputs));
  return v504_4;
}

static Space routine_57(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v513_4_branches = branches(c,s0);
  std::vector<Space> v513_4_outputs;
  v513_4_outputs.reserve(v513_4_branches.size());
  for (const auto& v513_4_branch : v513_4_branches) {
    const Path v513_4_head{v513_4_branch.first};
    const Space& v513_4_tail = v513_4_branch.second;
    const auto v514_2_branches = branches(c,v513_4_tail);
    std::vector<Space> v514_2_outputs;
    v514_2_outputs.reserve(v514_2_branches.size());
    for (const auto& v514_2_branch : v514_2_branches) {
      const Path v514_2_head{v514_2_branch.first};
      const Space& v514_2_tail = v514_2_branch.second;
      const Path v515_2 = concat_path(v513_4_head,v514_2_head);
      const auto v515_3_branches = branches(c,v514_2_tail);
      std::vector<Space> v515_3_outputs;
      v515_3_outputs.reserve(v515_3_branches.size());
      for (const auto& v515_3_branch : v515_3_branches) {
        const Path v515_3_head{v515_3_branch.first};
        const Space& v515_3_tail = v515_3_branch.second;
        const Path v516_2 = concat_path(v515_2,v515_3_head);
        const auto v516_3_branches = branches(c,v515_3_tail);
        std::vector<Space> v516_3_outputs;
        v516_3_outputs.reserve(v516_3_branches.size());
        for (const auto& v516_3_branch : v516_3_branches) {
          const Path v516_3_head{v516_3_branch.first};
          const Space& v516_3_tail = v516_3_branch.second;
          const Path v517_2 = concat_path(v516_2,v516_3_head);
          const auto v517_3_branches = branches(c,v516_3_tail);
          std::vector<Space> v517_3_outputs;
          v517_3_outputs.reserve(v517_3_branches.size());
          for (const auto& v517_3_branch : v517_3_branches) {
            const Path v517_3_head{v517_3_branch.first};
            const Space& v517_3_tail = v517_3_branch.second;
            const auto v518_2_branches = branches(c,v517_3_tail);
            std::vector<Space> v518_2_outputs;
            v518_2_outputs.reserve(v518_2_branches.size());
            for (const auto& v518_2_branch : v518_2_branches) {
              const Path v518_2_head{v518_2_branch.first};
              const Space& v518_2_tail = v518_2_branch.second;
              const Path v519_2 = concat_path(v517_3_head,v518_2_head);
              const auto v519_3_branches = branches(c,v518_2_tail);
              std::vector<Space> v519_3_outputs;
              v519_3_outputs.reserve(v519_3_branches.size());
              for (const auto& v519_3_branch : v519_3_branches) {
                const Path v519_3_head{v519_3_branch.first};
                const Space& v519_3_tail = v519_3_branch.second;
                const Path v520_2 = concat_path(v519_2,v519_3_head);
                const auto v520_3_branches = branches(c,v519_3_tail);
                std::vector<Space> v520_3_outputs;
                v520_3_outputs.reserve(v520_3_branches.size());
                for (const auto& v520_3_branch : v520_3_branches) {
                  const Path v520_3_head{v520_3_branch.first};
                  const Space& v520_3_tail = v520_3_branch.second;
                  const Path v521_2 = concat_path(v520_2,v520_3_head);
                  const Space v521_3 = routine_75(c, v521_2, p1, p2, p0, v517_2, v520_3_tail);
                  v520_3_outputs.push_back(v521_3);
                }
                const Space v520_3 = join_outputs(std::move(v520_3_outputs));
                v519_3_outputs.push_back(v520_3);
              }
              const Space v519_3 = join_outputs(std::move(v519_3_outputs));
              v518_2_outputs.push_back(v519_3);
            }
            const Space v518_2 = join_outputs(std::move(v518_2_outputs));
            v517_3_outputs.push_back(v518_2);
          }
          const Space v517_3 = join_outputs(std::move(v517_3_outputs));
          v516_3_outputs.push_back(v517_3);
        }
        const Space v516_3 = join_outputs(std::move(v516_3_outputs));
        v515_3_outputs.push_back(v516_3);
      }
      const Space v515_3 = join_outputs(std::move(v515_3_outputs));
      v514_2_outputs.push_back(v515_3);
    }
    const Space v514_2 = join_outputs(std::move(v514_2_outputs));
    v513_4_outputs.push_back(v514_2);
  }
  const Space v513_4 = join_outputs(std::move(v513_4_outputs));
  return v513_4;
}

static Space routine_58(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v522_4_branches = branches(c,s0);
  std::vector<Space> v522_4_outputs;
  v522_4_outputs.reserve(v522_4_branches.size());
  for (const auto& v522_4_branch : v522_4_branches) {
    const Path v522_4_head{v522_4_branch.first};
    const Space& v522_4_tail = v522_4_branch.second;
    const auto v523_2_branches = branches(c,v522_4_tail);
    std::vector<Space> v523_2_outputs;
    v523_2_outputs.reserve(v523_2_branches.size());
    for (const auto& v523_2_branch : v523_2_branches) {
      const Path v523_2_head{v523_2_branch.first};
      const Space& v523_2_tail = v523_2_branch.second;
      const Path v524_2 = concat_path(v522_4_head,v523_2_head);
      const auto v524_3_branches = branches(c,v523_2_tail);
      std::vector<Space> v524_3_outputs;
      v524_3_outputs.reserve(v524_3_branches.size());
      for (const auto& v524_3_branch : v524_3_branches) {
        const Path v524_3_head{v524_3_branch.first};
        const Space& v524_3_tail = v524_3_branch.second;
        const Path v525_2 = concat_path(v524_2,v524_3_head);
        const auto v525_3_branches = branches(c,v524_3_tail);
        std::vector<Space> v525_3_outputs;
        v525_3_outputs.reserve(v525_3_branches.size());
        for (const auto& v525_3_branch : v525_3_branches) {
          const Path v525_3_head{v525_3_branch.first};
          const Space& v525_3_tail = v525_3_branch.second;
          const Path v526_2 = concat_path(v525_2,v525_3_head);
          const auto v526_3_branches = branches(c,v525_3_tail);
          std::vector<Space> v526_3_outputs;
          v526_3_outputs.reserve(v526_3_branches.size());
          for (const auto& v526_3_branch : v526_3_branches) {
            const Path v526_3_head{v526_3_branch.first};
            const Space& v526_3_tail = v526_3_branch.second;
            const auto v527_2_branches = branches(c,v526_3_tail);
            std::vector<Space> v527_2_outputs;
            v527_2_outputs.reserve(v527_2_branches.size());
            for (const auto& v527_2_branch : v527_2_branches) {
              const Path v527_2_head{v527_2_branch.first};
              const Space& v527_2_tail = v527_2_branch.second;
              const Path v528_2 = concat_path(v526_3_head,v527_2_head);
              const auto v528_3_branches = branches(c,v527_2_tail);
              std::vector<Space> v528_3_outputs;
              v528_3_outputs.reserve(v528_3_branches.size());
              for (const auto& v528_3_branch : v528_3_branches) {
                const Path v528_3_head{v528_3_branch.first};
                const Space& v528_3_tail = v528_3_branch.second;
                const Path v529_2 = concat_path(v528_2,v528_3_head);
                const auto v529_3_branches = branches(c,v528_3_tail);
                std::vector<Space> v529_3_outputs;
                v529_3_outputs.reserve(v529_3_branches.size());
                for (const auto& v529_3_branch : v529_3_branches) {
                  const Path v529_3_head{v529_3_branch.first};
                  const Space& v529_3_tail = v529_3_branch.second;
                  const Path v530_2 = concat_path(v529_2,v529_3_head);
                  const Space v530_3 = routine_76(c, v530_2, p1, p2, p0, v526_2, v529_3_tail);
                  v529_3_outputs.push_back(v530_3);
                }
                const Space v529_3 = join_outputs(std::move(v529_3_outputs));
                v528_3_outputs.push_back(v529_3);
              }
              const Space v528_3 = join_outputs(std::move(v528_3_outputs));
              v527_2_outputs.push_back(v528_3);
            }
            const Space v527_2 = join_outputs(std::move(v527_2_outputs));
            v526_3_outputs.push_back(v527_2);
          }
          const Space v526_3 = join_outputs(std::move(v526_3_outputs));
          v525_3_outputs.push_back(v526_3);
        }
        const Space v525_3 = join_outputs(std::move(v525_3_outputs));
        v524_3_outputs.push_back(v525_3);
      }
      const Space v524_3 = join_outputs(std::move(v524_3_outputs));
      v523_2_outputs.push_back(v524_3);
    }
    const Space v523_2 = join_outputs(std::move(v523_2_outputs));
    v522_4_outputs.push_back(v523_2);
  }
  const Space v522_4 = join_outputs(std::move(v522_4_outputs));
  return v522_4;
}

static Space routine_59(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v531_4_branches = branches(c,s0);
  std::vector<Space> v531_4_outputs;
  v531_4_outputs.reserve(v531_4_branches.size());
  for (const auto& v531_4_branch : v531_4_branches) {
    const Path v531_4_head{v531_4_branch.first};
    const Space& v531_4_tail = v531_4_branch.second;
    const auto v532_2_branches = branches(c,v531_4_tail);
    std::vector<Space> v532_2_outputs;
    v532_2_outputs.reserve(v532_2_branches.size());
    for (const auto& v532_2_branch : v532_2_branches) {
      const Path v532_2_head{v532_2_branch.first};
      const Space& v532_2_tail = v532_2_branch.second;
      const Path v533_2 = concat_path(v531_4_head,v532_2_head);
      const auto v533_3_branches = branches(c,v532_2_tail);
      std::vector<Space> v533_3_outputs;
      v533_3_outputs.reserve(v533_3_branches.size());
      for (const auto& v533_3_branch : v533_3_branches) {
        const Path v533_3_head{v533_3_branch.first};
        const Space& v533_3_tail = v533_3_branch.second;
        const Path v534_2 = concat_path(v533_2,v533_3_head);
        const auto v534_3_branches = branches(c,v533_3_tail);
        std::vector<Space> v534_3_outputs;
        v534_3_outputs.reserve(v534_3_branches.size());
        for (const auto& v534_3_branch : v534_3_branches) {
          const Path v534_3_head{v534_3_branch.first};
          const Space& v534_3_tail = v534_3_branch.second;
          const Path v535_2 = concat_path(v534_2,v534_3_head);
          const auto v535_3_branches = branches(c,v534_3_tail);
          std::vector<Space> v535_3_outputs;
          v535_3_outputs.reserve(v535_3_branches.size());
          for (const auto& v535_3_branch : v535_3_branches) {
            const Path v535_3_head{v535_3_branch.first};
            const Space& v535_3_tail = v535_3_branch.second;
            const auto v536_2_branches = branches(c,v535_3_tail);
            std::vector<Space> v536_2_outputs;
            v536_2_outputs.reserve(v536_2_branches.size());
            for (const auto& v536_2_branch : v536_2_branches) {
              const Path v536_2_head{v536_2_branch.first};
              const Space& v536_2_tail = v536_2_branch.second;
              const Path v537_2 = concat_path(v535_3_head,v536_2_head);
              const auto v537_3_branches = branches(c,v536_2_tail);
              std::vector<Space> v537_3_outputs;
              v537_3_outputs.reserve(v537_3_branches.size());
              for (const auto& v537_3_branch : v537_3_branches) {
                const Path v537_3_head{v537_3_branch.first};
                const Space& v537_3_tail = v537_3_branch.second;
                const Path v538_2 = concat_path(v537_2,v537_3_head);
                const auto v538_3_branches = branches(c,v537_3_tail);
                std::vector<Space> v538_3_outputs;
                v538_3_outputs.reserve(v538_3_branches.size());
                for (const auto& v538_3_branch : v538_3_branches) {
                  const Path v538_3_head{v538_3_branch.first};
                  const Space& v538_3_tail = v538_3_branch.second;
                  const Path v539_2 = concat_path(v538_2,v538_3_head);
                  const Space v539_3 = routine_77(c, v539_2, p1, p2, p0, v535_2, v538_3_tail);
                  v538_3_outputs.push_back(v539_3);
                }
                const Space v538_3 = join_outputs(std::move(v538_3_outputs));
                v537_3_outputs.push_back(v538_3);
              }
              const Space v537_3 = join_outputs(std::move(v537_3_outputs));
              v536_2_outputs.push_back(v537_3);
            }
            const Space v536_2 = join_outputs(std::move(v536_2_outputs));
            v535_3_outputs.push_back(v536_2);
          }
          const Space v535_3 = join_outputs(std::move(v535_3_outputs));
          v534_3_outputs.push_back(v535_3);
        }
        const Space v534_3 = join_outputs(std::move(v534_3_outputs));
        v533_3_outputs.push_back(v534_3);
      }
      const Space v533_3 = join_outputs(std::move(v533_3_outputs));
      v532_2_outputs.push_back(v533_3);
    }
    const Space v532_2 = join_outputs(std::move(v532_2_outputs));
    v531_4_outputs.push_back(v532_2);
  }
  const Space v531_4 = join_outputs(std::move(v531_4_outputs));
  return v531_4;
}

static Space routine_60(Context& c, const Path& p0, const Path& p1, const Path& p2, const Space& s0) {
  const auto v540_4_branches = branches(c,s0);
  std::vector<Space> v540_4_outputs;
  v540_4_outputs.reserve(v540_4_branches.size());
  for (const auto& v540_4_branch : v540_4_branches) {
    const Path v540_4_head{v540_4_branch.first};
    const Space& v540_4_tail = v540_4_branch.second;
    const auto v541_2_branches = branches(c,v540_4_tail);
    std::vector<Space> v541_2_outputs;
    v541_2_outputs.reserve(v541_2_branches.size());
    for (const auto& v541_2_branch : v541_2_branches) {
      const Path v541_2_head{v541_2_branch.first};
      const Space& v541_2_tail = v541_2_branch.second;
      const Path v542_2 = concat_path(v540_4_head,v541_2_head);
      const auto v542_3_branches = branches(c,v541_2_tail);
      std::vector<Space> v542_3_outputs;
      v542_3_outputs.reserve(v542_3_branches.size());
      for (const auto& v542_3_branch : v542_3_branches) {
        const Path v542_3_head{v542_3_branch.first};
        const Space& v542_3_tail = v542_3_branch.second;
        const Path v543_2 = concat_path(v542_2,v542_3_head);
        const auto v543_3_branches = branches(c,v542_3_tail);
        std::vector<Space> v543_3_outputs;
        v543_3_outputs.reserve(v543_3_branches.size());
        for (const auto& v543_3_branch : v543_3_branches) {
          const Path v543_3_head{v543_3_branch.first};
          const Space& v543_3_tail = v543_3_branch.second;
          const Path v544_2 = concat_path(v543_2,v543_3_head);
          const auto v544_3_branches = branches(c,v543_3_tail);
          std::vector<Space> v544_3_outputs;
          v544_3_outputs.reserve(v544_3_branches.size());
          for (const auto& v544_3_branch : v544_3_branches) {
            const Path v544_3_head{v544_3_branch.first};
            const Space& v544_3_tail = v544_3_branch.second;
            const auto v545_2_branches = branches(c,v544_3_tail);
            std::vector<Space> v545_2_outputs;
            v545_2_outputs.reserve(v545_2_branches.size());
            for (const auto& v545_2_branch : v545_2_branches) {
              const Path v545_2_head{v545_2_branch.first};
              const Space& v545_2_tail = v545_2_branch.second;
              const Path v546_2 = concat_path(v544_3_head,v545_2_head);
              const auto v546_3_branches = branches(c,v545_2_tail);
              std::vector<Space> v546_3_outputs;
              v546_3_outputs.reserve(v546_3_branches.size());
              for (const auto& v546_3_branch : v546_3_branches) {
                const Path v546_3_head{v546_3_branch.first};
                const Space& v546_3_tail = v546_3_branch.second;
                const Path v547_2 = concat_path(v546_2,v546_3_head);
                const auto v547_3_branches = branches(c,v546_3_tail);
                std::vector<Space> v547_3_outputs;
                v547_3_outputs.reserve(v547_3_branches.size());
                for (const auto& v547_3_branch : v547_3_branches) {
                  const Path v547_3_head{v547_3_branch.first};
                  const Space& v547_3_tail = v547_3_branch.second;
                  const Path v548_2 = concat_path(v547_2,v547_3_head);
                  const Space v548_3 = routine_78(c, v548_2, p1, p2, p0, v544_2, v547_3_tail);
                  v547_3_outputs.push_back(v548_3);
                }
                const Space v547_3 = join_outputs(std::move(v547_3_outputs));
                v546_3_outputs.push_back(v547_3);
              }
              const Space v546_3 = join_outputs(std::move(v546_3_outputs));
              v545_2_outputs.push_back(v546_3);
            }
            const Space v545_2 = join_outputs(std::move(v545_2_outputs));
            v544_3_outputs.push_back(v545_2);
          }
          const Space v544_3 = join_outputs(std::move(v544_3_outputs));
          v543_3_outputs.push_back(v544_3);
        }
        const Space v543_3 = join_outputs(std::move(v543_3_outputs));
        v542_3_outputs.push_back(v543_3);
      }
      const Space v542_3 = join_outputs(std::move(v542_3_outputs));
      v541_2_outputs.push_back(v542_3);
    }
    const Space v541_2 = join_outputs(std::move(v541_2_outputs));
    v540_4_outputs.push_back(v541_2);
  }
  const Space v540_4 = join_outputs(std::move(v540_4_outputs));
  return v540_4;
}

static Space routine_61(Context& c, const Path& p0, const Space& s0) {
  const Space v549_2 = singleton(p0);
  return v549_2;
}

static Space routine_62(Context& c, const Path& p0, const Space& s0) {
  const Space v550_2 = singleton(p0);
  return v550_2;
}

static Space routine_63(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v551_6_branches = branches(c,s0);
  std::vector<Space> v551_6_outputs;
  v551_6_outputs.reserve(v551_6_branches.size());
  for (const auto& v551_6_branch : v551_6_branches) {
    const Path v551_6_head{v551_6_branch.first};
    const Space& v551_6_tail = v551_6_branch.second;
    const auto v552_2_branches = branches(c,v551_6_tail);
    std::vector<Space> v552_2_outputs;
    v552_2_outputs.reserve(v552_2_branches.size());
    for (const auto& v552_2_branch : v552_2_branches) {
      const Path v552_2_head{v552_2_branch.first};
      const Space& v552_2_tail = v552_2_branch.second;
      const Path v553_2 = concat_path(v551_6_head,v552_2_head);
      const auto v553_3_branches = branches(c,v552_2_tail);
      std::vector<Space> v553_3_outputs;
      v553_3_outputs.reserve(v553_3_branches.size());
      for (const auto& v553_3_branch : v553_3_branches) {
        const Path v553_3_head{v553_3_branch.first};
        const Space& v553_3_tail = v553_3_branch.second;
        const Path v554_2 = concat_path(v553_2,v553_3_head);
        const auto v554_3_branches = branches(c,v553_3_tail);
        std::vector<Space> v554_3_outputs;
        v554_3_outputs.reserve(v554_3_branches.size());
        for (const auto& v554_3_branch : v554_3_branches) {
          const Path v554_3_head{v554_3_branch.first};
          const Space& v554_3_tail = v554_3_branch.second;
          const Path v555_2 = concat_path(v554_2,v554_3_head);
          const auto v555_3_branches = branches(c,v554_3_tail);
          std::vector<Space> v555_3_outputs;
          v555_3_outputs.reserve(v555_3_branches.size());
          for (const auto& v555_3_branch : v555_3_branches) {
            const Path v555_3_head{v555_3_branch.first};
            const Space& v555_3_tail = v555_3_branch.second;
            const auto v556_2_branches = branches(c,v555_3_tail);
            std::vector<Space> v556_2_outputs;
            v556_2_outputs.reserve(v556_2_branches.size());
            for (const auto& v556_2_branch : v556_2_branches) {
              const Path v556_2_head{v556_2_branch.first};
              const Space& v556_2_tail = v556_2_branch.second;
              const Path v557_2 = concat_path(v555_3_head,v556_2_head);
              const auto v557_3_branches = branches(c,v556_2_tail);
              std::vector<Space> v557_3_outputs;
              v557_3_outputs.reserve(v557_3_branches.size());
              for (const auto& v557_3_branch : v557_3_branches) {
                const Path v557_3_head{v557_3_branch.first};
                const Space& v557_3_tail = v557_3_branch.second;
                const Path v558_2 = concat_path(v557_2,v557_3_head);
                const auto v558_3_branches = branches(c,v557_3_tail);
                std::vector<Space> v558_3_outputs;
                v558_3_outputs.reserve(v558_3_branches.size());
                for (const auto& v558_3_branch : v558_3_branches) {
                  const Path v558_3_head{v558_3_branch.first};
                  const Space& v558_3_tail = v558_3_branch.second;
                  const Path v559_2 = concat_path(v558_2,v558_3_head);
                  const Space v559_3 = routine_79(c, v559_2, p1, p2, p3, p4, p0, v555_2, v558_3_tail);
                  v558_3_outputs.push_back(v559_3);
                }
                const Space v558_3 = join_outputs(std::move(v558_3_outputs));
                v557_3_outputs.push_back(v558_3);
              }
              const Space v557_3 = join_outputs(std::move(v557_3_outputs));
              v556_2_outputs.push_back(v557_3);
            }
            const Space v556_2 = join_outputs(std::move(v556_2_outputs));
            v555_3_outputs.push_back(v556_2);
          }
          const Space v555_3 = join_outputs(std::move(v555_3_outputs));
          v554_3_outputs.push_back(v555_3);
        }
        const Space v554_3 = join_outputs(std::move(v554_3_outputs));
        v553_3_outputs.push_back(v554_3);
      }
      const Space v553_3 = join_outputs(std::move(v553_3_outputs));
      v552_2_outputs.push_back(v553_3);
    }
    const Space v552_2 = join_outputs(std::move(v552_2_outputs));
    v551_6_outputs.push_back(v552_2);
  }
  const Space v551_6 = join_outputs(std::move(v551_6_outputs));
  return v551_6;
}

static Space routine_64(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v560_6_branches = branches(c,s0);
  std::vector<Space> v560_6_outputs;
  v560_6_outputs.reserve(v560_6_branches.size());
  for (const auto& v560_6_branch : v560_6_branches) {
    const Path v560_6_head{v560_6_branch.first};
    const Space& v560_6_tail = v560_6_branch.second;
    const auto v561_2_branches = branches(c,v560_6_tail);
    std::vector<Space> v561_2_outputs;
    v561_2_outputs.reserve(v561_2_branches.size());
    for (const auto& v561_2_branch : v561_2_branches) {
      const Path v561_2_head{v561_2_branch.first};
      const Space& v561_2_tail = v561_2_branch.second;
      const Path v562_2 = concat_path(v560_6_head,v561_2_head);
      const auto v562_3_branches = branches(c,v561_2_tail);
      std::vector<Space> v562_3_outputs;
      v562_3_outputs.reserve(v562_3_branches.size());
      for (const auto& v562_3_branch : v562_3_branches) {
        const Path v562_3_head{v562_3_branch.first};
        const Space& v562_3_tail = v562_3_branch.second;
        const Path v563_2 = concat_path(v562_2,v562_3_head);
        const auto v563_3_branches = branches(c,v562_3_tail);
        std::vector<Space> v563_3_outputs;
        v563_3_outputs.reserve(v563_3_branches.size());
        for (const auto& v563_3_branch : v563_3_branches) {
          const Path v563_3_head{v563_3_branch.first};
          const Space& v563_3_tail = v563_3_branch.second;
          const Path v564_2 = concat_path(v563_2,v563_3_head);
          const auto v564_3_branches = branches(c,v563_3_tail);
          std::vector<Space> v564_3_outputs;
          v564_3_outputs.reserve(v564_3_branches.size());
          for (const auto& v564_3_branch : v564_3_branches) {
            const Path v564_3_head{v564_3_branch.first};
            const Space& v564_3_tail = v564_3_branch.second;
            const auto v565_2_branches = branches(c,v564_3_tail);
            std::vector<Space> v565_2_outputs;
            v565_2_outputs.reserve(v565_2_branches.size());
            for (const auto& v565_2_branch : v565_2_branches) {
              const Path v565_2_head{v565_2_branch.first};
              const Space& v565_2_tail = v565_2_branch.second;
              const Path v566_2 = concat_path(v564_3_head,v565_2_head);
              const auto v566_3_branches = branches(c,v565_2_tail);
              std::vector<Space> v566_3_outputs;
              v566_3_outputs.reserve(v566_3_branches.size());
              for (const auto& v566_3_branch : v566_3_branches) {
                const Path v566_3_head{v566_3_branch.first};
                const Space& v566_3_tail = v566_3_branch.second;
                const Path v567_2 = concat_path(v566_2,v566_3_head);
                const auto v567_3_branches = branches(c,v566_3_tail);
                std::vector<Space> v567_3_outputs;
                v567_3_outputs.reserve(v567_3_branches.size());
                for (const auto& v567_3_branch : v567_3_branches) {
                  const Path v567_3_head{v567_3_branch.first};
                  const Space& v567_3_tail = v567_3_branch.second;
                  const Path v568_2 = concat_path(v567_2,v567_3_head);
                  const Space v568_3 = routine_80(c, v568_2, p1, p2, p3, p4, p0, v564_2, v567_3_tail);
                  v567_3_outputs.push_back(v568_3);
                }
                const Space v567_3 = join_outputs(std::move(v567_3_outputs));
                v566_3_outputs.push_back(v567_3);
              }
              const Space v566_3 = join_outputs(std::move(v566_3_outputs));
              v565_2_outputs.push_back(v566_3);
            }
            const Space v565_2 = join_outputs(std::move(v565_2_outputs));
            v564_3_outputs.push_back(v565_2);
          }
          const Space v564_3 = join_outputs(std::move(v564_3_outputs));
          v563_3_outputs.push_back(v564_3);
        }
        const Space v563_3 = join_outputs(std::move(v563_3_outputs));
        v562_3_outputs.push_back(v563_3);
      }
      const Space v562_3 = join_outputs(std::move(v562_3_outputs));
      v561_2_outputs.push_back(v562_3);
    }
    const Space v561_2 = join_outputs(std::move(v561_2_outputs));
    v560_6_outputs.push_back(v561_2);
  }
  const Space v560_6 = join_outputs(std::move(v560_6_outputs));
  return v560_6;
}

static Space routine_65(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v569_6_branches = branches(c,s0);
  std::vector<Space> v569_6_outputs;
  v569_6_outputs.reserve(v569_6_branches.size());
  for (const auto& v569_6_branch : v569_6_branches) {
    const Path v569_6_head{v569_6_branch.first};
    const Space& v569_6_tail = v569_6_branch.second;
    const auto v570_2_branches = branches(c,v569_6_tail);
    std::vector<Space> v570_2_outputs;
    v570_2_outputs.reserve(v570_2_branches.size());
    for (const auto& v570_2_branch : v570_2_branches) {
      const Path v570_2_head{v570_2_branch.first};
      const Space& v570_2_tail = v570_2_branch.second;
      const Path v571_2 = concat_path(v569_6_head,v570_2_head);
      const auto v571_3_branches = branches(c,v570_2_tail);
      std::vector<Space> v571_3_outputs;
      v571_3_outputs.reserve(v571_3_branches.size());
      for (const auto& v571_3_branch : v571_3_branches) {
        const Path v571_3_head{v571_3_branch.first};
        const Space& v571_3_tail = v571_3_branch.second;
        const Path v572_2 = concat_path(v571_2,v571_3_head);
        const auto v572_3_branches = branches(c,v571_3_tail);
        std::vector<Space> v572_3_outputs;
        v572_3_outputs.reserve(v572_3_branches.size());
        for (const auto& v572_3_branch : v572_3_branches) {
          const Path v572_3_head{v572_3_branch.first};
          const Space& v572_3_tail = v572_3_branch.second;
          const Path v573_2 = concat_path(v572_2,v572_3_head);
          const auto v573_3_branches = branches(c,v572_3_tail);
          std::vector<Space> v573_3_outputs;
          v573_3_outputs.reserve(v573_3_branches.size());
          for (const auto& v573_3_branch : v573_3_branches) {
            const Path v573_3_head{v573_3_branch.first};
            const Space& v573_3_tail = v573_3_branch.second;
            const auto v574_2_branches = branches(c,v573_3_tail);
            std::vector<Space> v574_2_outputs;
            v574_2_outputs.reserve(v574_2_branches.size());
            for (const auto& v574_2_branch : v574_2_branches) {
              const Path v574_2_head{v574_2_branch.first};
              const Space& v574_2_tail = v574_2_branch.second;
              const Path v575_2 = concat_path(v573_3_head,v574_2_head);
              const auto v575_3_branches = branches(c,v574_2_tail);
              std::vector<Space> v575_3_outputs;
              v575_3_outputs.reserve(v575_3_branches.size());
              for (const auto& v575_3_branch : v575_3_branches) {
                const Path v575_3_head{v575_3_branch.first};
                const Space& v575_3_tail = v575_3_branch.second;
                const Path v576_2 = concat_path(v575_2,v575_3_head);
                const auto v576_3_branches = branches(c,v575_3_tail);
                std::vector<Space> v576_3_outputs;
                v576_3_outputs.reserve(v576_3_branches.size());
                for (const auto& v576_3_branch : v576_3_branches) {
                  const Path v576_3_head{v576_3_branch.first};
                  const Space& v576_3_tail = v576_3_branch.second;
                  const Path v577_2 = concat_path(v576_2,v576_3_head);
                  const Space v577_3 = routine_81(c, v577_2, p1, p2, p3, p4, p0, v573_2, v576_3_tail);
                  v576_3_outputs.push_back(v577_3);
                }
                const Space v576_3 = join_outputs(std::move(v576_3_outputs));
                v575_3_outputs.push_back(v576_3);
              }
              const Space v575_3 = join_outputs(std::move(v575_3_outputs));
              v574_2_outputs.push_back(v575_3);
            }
            const Space v574_2 = join_outputs(std::move(v574_2_outputs));
            v573_3_outputs.push_back(v574_2);
          }
          const Space v573_3 = join_outputs(std::move(v573_3_outputs));
          v572_3_outputs.push_back(v573_3);
        }
        const Space v572_3 = join_outputs(std::move(v572_3_outputs));
        v571_3_outputs.push_back(v572_3);
      }
      const Space v571_3 = join_outputs(std::move(v571_3_outputs));
      v570_2_outputs.push_back(v571_3);
    }
    const Space v570_2 = join_outputs(std::move(v570_2_outputs));
    v569_6_outputs.push_back(v570_2);
  }
  const Space v569_6 = join_outputs(std::move(v569_6_outputs));
  return v569_6;
}

static Space routine_66(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v578_6_branches = branches(c,s0);
  std::vector<Space> v578_6_outputs;
  v578_6_outputs.reserve(v578_6_branches.size());
  for (const auto& v578_6_branch : v578_6_branches) {
    const Path v578_6_head{v578_6_branch.first};
    const Space& v578_6_tail = v578_6_branch.second;
    const auto v579_2_branches = branches(c,v578_6_tail);
    std::vector<Space> v579_2_outputs;
    v579_2_outputs.reserve(v579_2_branches.size());
    for (const auto& v579_2_branch : v579_2_branches) {
      const Path v579_2_head{v579_2_branch.first};
      const Space& v579_2_tail = v579_2_branch.second;
      const Path v580_2 = concat_path(v578_6_head,v579_2_head);
      const auto v580_3_branches = branches(c,v579_2_tail);
      std::vector<Space> v580_3_outputs;
      v580_3_outputs.reserve(v580_3_branches.size());
      for (const auto& v580_3_branch : v580_3_branches) {
        const Path v580_3_head{v580_3_branch.first};
        const Space& v580_3_tail = v580_3_branch.second;
        const Path v581_2 = concat_path(v580_2,v580_3_head);
        const auto v581_3_branches = branches(c,v580_3_tail);
        std::vector<Space> v581_3_outputs;
        v581_3_outputs.reserve(v581_3_branches.size());
        for (const auto& v581_3_branch : v581_3_branches) {
          const Path v581_3_head{v581_3_branch.first};
          const Space& v581_3_tail = v581_3_branch.second;
          const Path v582_2 = concat_path(v581_2,v581_3_head);
          const auto v582_3_branches = branches(c,v581_3_tail);
          std::vector<Space> v582_3_outputs;
          v582_3_outputs.reserve(v582_3_branches.size());
          for (const auto& v582_3_branch : v582_3_branches) {
            const Path v582_3_head{v582_3_branch.first};
            const Space& v582_3_tail = v582_3_branch.second;
            const auto v583_2_branches = branches(c,v582_3_tail);
            std::vector<Space> v583_2_outputs;
            v583_2_outputs.reserve(v583_2_branches.size());
            for (const auto& v583_2_branch : v583_2_branches) {
              const Path v583_2_head{v583_2_branch.first};
              const Space& v583_2_tail = v583_2_branch.second;
              const Path v584_2 = concat_path(v582_3_head,v583_2_head);
              const auto v584_3_branches = branches(c,v583_2_tail);
              std::vector<Space> v584_3_outputs;
              v584_3_outputs.reserve(v584_3_branches.size());
              for (const auto& v584_3_branch : v584_3_branches) {
                const Path v584_3_head{v584_3_branch.first};
                const Space& v584_3_tail = v584_3_branch.second;
                const Path v585_2 = concat_path(v584_2,v584_3_head);
                const auto v585_3_branches = branches(c,v584_3_tail);
                std::vector<Space> v585_3_outputs;
                v585_3_outputs.reserve(v585_3_branches.size());
                for (const auto& v585_3_branch : v585_3_branches) {
                  const Path v585_3_head{v585_3_branch.first};
                  const Space& v585_3_tail = v585_3_branch.second;
                  const Path v586_2 = concat_path(v585_2,v585_3_head);
                  const Space v586_3 = routine_82(c, v586_2, p1, p2, p3, p4, p0, v582_2, v585_3_tail);
                  v585_3_outputs.push_back(v586_3);
                }
                const Space v585_3 = join_outputs(std::move(v585_3_outputs));
                v584_3_outputs.push_back(v585_3);
              }
              const Space v584_3 = join_outputs(std::move(v584_3_outputs));
              v583_2_outputs.push_back(v584_3);
            }
            const Space v583_2 = join_outputs(std::move(v583_2_outputs));
            v582_3_outputs.push_back(v583_2);
          }
          const Space v582_3 = join_outputs(std::move(v582_3_outputs));
          v581_3_outputs.push_back(v582_3);
        }
        const Space v581_3 = join_outputs(std::move(v581_3_outputs));
        v580_3_outputs.push_back(v581_3);
      }
      const Space v580_3 = join_outputs(std::move(v580_3_outputs));
      v579_2_outputs.push_back(v580_3);
    }
    const Space v579_2 = join_outputs(std::move(v579_2_outputs));
    v578_6_outputs.push_back(v579_2);
  }
  const Space v578_6 = join_outputs(std::move(v578_6_outputs));
  return v578_6;
}

static Space routine_67(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v587_6_branches = branches(c,s0);
  std::vector<Space> v587_6_outputs;
  v587_6_outputs.reserve(v587_6_branches.size());
  for (const auto& v587_6_branch : v587_6_branches) {
    const Path v587_6_head{v587_6_branch.first};
    const Space& v587_6_tail = v587_6_branch.second;
    const auto v588_2_branches = branches(c,v587_6_tail);
    std::vector<Space> v588_2_outputs;
    v588_2_outputs.reserve(v588_2_branches.size());
    for (const auto& v588_2_branch : v588_2_branches) {
      const Path v588_2_head{v588_2_branch.first};
      const Space& v588_2_tail = v588_2_branch.second;
      const Path v589_2 = concat_path(v587_6_head,v588_2_head);
      const auto v589_3_branches = branches(c,v588_2_tail);
      std::vector<Space> v589_3_outputs;
      v589_3_outputs.reserve(v589_3_branches.size());
      for (const auto& v589_3_branch : v589_3_branches) {
        const Path v589_3_head{v589_3_branch.first};
        const Space& v589_3_tail = v589_3_branch.second;
        const Path v590_2 = concat_path(v589_2,v589_3_head);
        const auto v590_3_branches = branches(c,v589_3_tail);
        std::vector<Space> v590_3_outputs;
        v590_3_outputs.reserve(v590_3_branches.size());
        for (const auto& v590_3_branch : v590_3_branches) {
          const Path v590_3_head{v590_3_branch.first};
          const Space& v590_3_tail = v590_3_branch.second;
          const Path v591_2 = concat_path(v590_2,v590_3_head);
          const auto v591_3_branches = branches(c,v590_3_tail);
          std::vector<Space> v591_3_outputs;
          v591_3_outputs.reserve(v591_3_branches.size());
          for (const auto& v591_3_branch : v591_3_branches) {
            const Path v591_3_head{v591_3_branch.first};
            const Space& v591_3_tail = v591_3_branch.second;
            const auto v592_2_branches = branches(c,v591_3_tail);
            std::vector<Space> v592_2_outputs;
            v592_2_outputs.reserve(v592_2_branches.size());
            for (const auto& v592_2_branch : v592_2_branches) {
              const Path v592_2_head{v592_2_branch.first};
              const Space& v592_2_tail = v592_2_branch.second;
              const Path v593_2 = concat_path(v591_3_head,v592_2_head);
              const auto v593_3_branches = branches(c,v592_2_tail);
              std::vector<Space> v593_3_outputs;
              v593_3_outputs.reserve(v593_3_branches.size());
              for (const auto& v593_3_branch : v593_3_branches) {
                const Path v593_3_head{v593_3_branch.first};
                const Space& v593_3_tail = v593_3_branch.second;
                const Path v594_2 = concat_path(v593_2,v593_3_head);
                const auto v594_3_branches = branches(c,v593_3_tail);
                std::vector<Space> v594_3_outputs;
                v594_3_outputs.reserve(v594_3_branches.size());
                for (const auto& v594_3_branch : v594_3_branches) {
                  const Path v594_3_head{v594_3_branch.first};
                  const Space& v594_3_tail = v594_3_branch.second;
                  const Path v595_2 = concat_path(v594_2,v594_3_head);
                  const Space v595_3 = routine_83(c, v595_2, p1, p2, p3, p4, p0, v591_2, v594_3_tail);
                  v594_3_outputs.push_back(v595_3);
                }
                const Space v594_3 = join_outputs(std::move(v594_3_outputs));
                v593_3_outputs.push_back(v594_3);
              }
              const Space v593_3 = join_outputs(std::move(v593_3_outputs));
              v592_2_outputs.push_back(v593_3);
            }
            const Space v592_2 = join_outputs(std::move(v592_2_outputs));
            v591_3_outputs.push_back(v592_2);
          }
          const Space v591_3 = join_outputs(std::move(v591_3_outputs));
          v590_3_outputs.push_back(v591_3);
        }
        const Space v590_3 = join_outputs(std::move(v590_3_outputs));
        v589_3_outputs.push_back(v590_3);
      }
      const Space v589_3 = join_outputs(std::move(v589_3_outputs));
      v588_2_outputs.push_back(v589_3);
    }
    const Space v588_2 = join_outputs(std::move(v588_2_outputs));
    v587_6_outputs.push_back(v588_2);
  }
  const Space v587_6 = join_outputs(std::move(v587_6_outputs));
  return v587_6;
}

static Space routine_68(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v596_6_branches = branches(c,s0);
  std::vector<Space> v596_6_outputs;
  v596_6_outputs.reserve(v596_6_branches.size());
  for (const auto& v596_6_branch : v596_6_branches) {
    const Path v596_6_head{v596_6_branch.first};
    const Space& v596_6_tail = v596_6_branch.second;
    const auto v597_2_branches = branches(c,v596_6_tail);
    std::vector<Space> v597_2_outputs;
    v597_2_outputs.reserve(v597_2_branches.size());
    for (const auto& v597_2_branch : v597_2_branches) {
      const Path v597_2_head{v597_2_branch.first};
      const Space& v597_2_tail = v597_2_branch.second;
      const Path v598_2 = concat_path(v596_6_head,v597_2_head);
      const auto v598_3_branches = branches(c,v597_2_tail);
      std::vector<Space> v598_3_outputs;
      v598_3_outputs.reserve(v598_3_branches.size());
      for (const auto& v598_3_branch : v598_3_branches) {
        const Path v598_3_head{v598_3_branch.first};
        const Space& v598_3_tail = v598_3_branch.second;
        const Path v599_2 = concat_path(v598_2,v598_3_head);
        const auto v599_3_branches = branches(c,v598_3_tail);
        std::vector<Space> v599_3_outputs;
        v599_3_outputs.reserve(v599_3_branches.size());
        for (const auto& v599_3_branch : v599_3_branches) {
          const Path v599_3_head{v599_3_branch.first};
          const Space& v599_3_tail = v599_3_branch.second;
          const Path v600_2 = concat_path(v599_2,v599_3_head);
          const auto v600_3_branches = branches(c,v599_3_tail);
          std::vector<Space> v600_3_outputs;
          v600_3_outputs.reserve(v600_3_branches.size());
          for (const auto& v600_3_branch : v600_3_branches) {
            const Path v600_3_head{v600_3_branch.first};
            const Space& v600_3_tail = v600_3_branch.second;
            const auto v601_2_branches = branches(c,v600_3_tail);
            std::vector<Space> v601_2_outputs;
            v601_2_outputs.reserve(v601_2_branches.size());
            for (const auto& v601_2_branch : v601_2_branches) {
              const Path v601_2_head{v601_2_branch.first};
              const Space& v601_2_tail = v601_2_branch.second;
              const Path v602_2 = concat_path(v600_3_head,v601_2_head);
              const auto v602_3_branches = branches(c,v601_2_tail);
              std::vector<Space> v602_3_outputs;
              v602_3_outputs.reserve(v602_3_branches.size());
              for (const auto& v602_3_branch : v602_3_branches) {
                const Path v602_3_head{v602_3_branch.first};
                const Space& v602_3_tail = v602_3_branch.second;
                const Path v603_2 = concat_path(v602_2,v602_3_head);
                const auto v603_3_branches = branches(c,v602_3_tail);
                std::vector<Space> v603_3_outputs;
                v603_3_outputs.reserve(v603_3_branches.size());
                for (const auto& v603_3_branch : v603_3_branches) {
                  const Path v603_3_head{v603_3_branch.first};
                  const Space& v603_3_tail = v603_3_branch.second;
                  const Path v604_2 = concat_path(v603_2,v603_3_head);
                  const Space v604_3 = routine_84(c, v604_2, p1, p2, p3, p4, p0, v600_2, v603_3_tail);
                  v603_3_outputs.push_back(v604_3);
                }
                const Space v603_3 = join_outputs(std::move(v603_3_outputs));
                v602_3_outputs.push_back(v603_3);
              }
              const Space v602_3 = join_outputs(std::move(v602_3_outputs));
              v601_2_outputs.push_back(v602_3);
            }
            const Space v601_2 = join_outputs(std::move(v601_2_outputs));
            v600_3_outputs.push_back(v601_2);
          }
          const Space v600_3 = join_outputs(std::move(v600_3_outputs));
          v599_3_outputs.push_back(v600_3);
        }
        const Space v599_3 = join_outputs(std::move(v599_3_outputs));
        v598_3_outputs.push_back(v599_3);
      }
      const Space v598_3 = join_outputs(std::move(v598_3_outputs));
      v597_2_outputs.push_back(v598_3);
    }
    const Space v597_2 = join_outputs(std::move(v597_2_outputs));
    v596_6_outputs.push_back(v597_2);
  }
  const Space v596_6 = join_outputs(std::move(v596_6_outputs));
  return v596_6;
}

static Space routine_69(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v605_6_branches = branches(c,s0);
  std::vector<Space> v605_6_outputs;
  v605_6_outputs.reserve(v605_6_branches.size());
  for (const auto& v605_6_branch : v605_6_branches) {
    const Path v605_6_head{v605_6_branch.first};
    const Space& v605_6_tail = v605_6_branch.second;
    const auto v606_2_branches = branches(c,v605_6_tail);
    std::vector<Space> v606_2_outputs;
    v606_2_outputs.reserve(v606_2_branches.size());
    for (const auto& v606_2_branch : v606_2_branches) {
      const Path v606_2_head{v606_2_branch.first};
      const Space& v606_2_tail = v606_2_branch.second;
      const Path v607_2 = concat_path(v605_6_head,v606_2_head);
      const auto v607_3_branches = branches(c,v606_2_tail);
      std::vector<Space> v607_3_outputs;
      v607_3_outputs.reserve(v607_3_branches.size());
      for (const auto& v607_3_branch : v607_3_branches) {
        const Path v607_3_head{v607_3_branch.first};
        const Space& v607_3_tail = v607_3_branch.second;
        const Path v608_2 = concat_path(v607_2,v607_3_head);
        const auto v608_3_branches = branches(c,v607_3_tail);
        std::vector<Space> v608_3_outputs;
        v608_3_outputs.reserve(v608_3_branches.size());
        for (const auto& v608_3_branch : v608_3_branches) {
          const Path v608_3_head{v608_3_branch.first};
          const Space& v608_3_tail = v608_3_branch.second;
          const Path v609_2 = concat_path(v608_2,v608_3_head);
          const auto v609_3_branches = branches(c,v608_3_tail);
          std::vector<Space> v609_3_outputs;
          v609_3_outputs.reserve(v609_3_branches.size());
          for (const auto& v609_3_branch : v609_3_branches) {
            const Path v609_3_head{v609_3_branch.first};
            const Space& v609_3_tail = v609_3_branch.second;
            const auto v610_2_branches = branches(c,v609_3_tail);
            std::vector<Space> v610_2_outputs;
            v610_2_outputs.reserve(v610_2_branches.size());
            for (const auto& v610_2_branch : v610_2_branches) {
              const Path v610_2_head{v610_2_branch.first};
              const Space& v610_2_tail = v610_2_branch.second;
              const Path v611_2 = concat_path(v609_3_head,v610_2_head);
              const auto v611_3_branches = branches(c,v610_2_tail);
              std::vector<Space> v611_3_outputs;
              v611_3_outputs.reserve(v611_3_branches.size());
              for (const auto& v611_3_branch : v611_3_branches) {
                const Path v611_3_head{v611_3_branch.first};
                const Space& v611_3_tail = v611_3_branch.second;
                const Path v612_2 = concat_path(v611_2,v611_3_head);
                const auto v612_3_branches = branches(c,v611_3_tail);
                std::vector<Space> v612_3_outputs;
                v612_3_outputs.reserve(v612_3_branches.size());
                for (const auto& v612_3_branch : v612_3_branches) {
                  const Path v612_3_head{v612_3_branch.first};
                  const Space& v612_3_tail = v612_3_branch.second;
                  const Path v613_2 = concat_path(v612_2,v612_3_head);
                  const Space v613_3 = routine_85(c, v613_2, p1, p2, p3, p4, p0, v609_2, v612_3_tail);
                  v612_3_outputs.push_back(v613_3);
                }
                const Space v612_3 = join_outputs(std::move(v612_3_outputs));
                v611_3_outputs.push_back(v612_3);
              }
              const Space v611_3 = join_outputs(std::move(v611_3_outputs));
              v610_2_outputs.push_back(v611_3);
            }
            const Space v610_2 = join_outputs(std::move(v610_2_outputs));
            v609_3_outputs.push_back(v610_2);
          }
          const Space v609_3 = join_outputs(std::move(v609_3_outputs));
          v608_3_outputs.push_back(v609_3);
        }
        const Space v608_3 = join_outputs(std::move(v608_3_outputs));
        v607_3_outputs.push_back(v608_3);
      }
      const Space v607_3 = join_outputs(std::move(v607_3_outputs));
      v606_2_outputs.push_back(v607_3);
    }
    const Space v606_2 = join_outputs(std::move(v606_2_outputs));
    v605_6_outputs.push_back(v606_2);
  }
  const Space v605_6 = join_outputs(std::move(v605_6_outputs));
  return v605_6;
}

static Space routine_70(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v614_6_branches = branches(c,s0);
  std::vector<Space> v614_6_outputs;
  v614_6_outputs.reserve(v614_6_branches.size());
  for (const auto& v614_6_branch : v614_6_branches) {
    const Path v614_6_head{v614_6_branch.first};
    const Space& v614_6_tail = v614_6_branch.second;
    const auto v615_2_branches = branches(c,v614_6_tail);
    std::vector<Space> v615_2_outputs;
    v615_2_outputs.reserve(v615_2_branches.size());
    for (const auto& v615_2_branch : v615_2_branches) {
      const Path v615_2_head{v615_2_branch.first};
      const Space& v615_2_tail = v615_2_branch.second;
      const Path v616_2 = concat_path(v614_6_head,v615_2_head);
      const auto v616_3_branches = branches(c,v615_2_tail);
      std::vector<Space> v616_3_outputs;
      v616_3_outputs.reserve(v616_3_branches.size());
      for (const auto& v616_3_branch : v616_3_branches) {
        const Path v616_3_head{v616_3_branch.first};
        const Space& v616_3_tail = v616_3_branch.second;
        const Path v617_2 = concat_path(v616_2,v616_3_head);
        const auto v617_3_branches = branches(c,v616_3_tail);
        std::vector<Space> v617_3_outputs;
        v617_3_outputs.reserve(v617_3_branches.size());
        for (const auto& v617_3_branch : v617_3_branches) {
          const Path v617_3_head{v617_3_branch.first};
          const Space& v617_3_tail = v617_3_branch.second;
          const Path v618_2 = concat_path(v617_2,v617_3_head);
          const auto v618_3_branches = branches(c,v617_3_tail);
          std::vector<Space> v618_3_outputs;
          v618_3_outputs.reserve(v618_3_branches.size());
          for (const auto& v618_3_branch : v618_3_branches) {
            const Path v618_3_head{v618_3_branch.first};
            const Space& v618_3_tail = v618_3_branch.second;
            const auto v619_2_branches = branches(c,v618_3_tail);
            std::vector<Space> v619_2_outputs;
            v619_2_outputs.reserve(v619_2_branches.size());
            for (const auto& v619_2_branch : v619_2_branches) {
              const Path v619_2_head{v619_2_branch.first};
              const Space& v619_2_tail = v619_2_branch.second;
              const Path v620_2 = concat_path(v618_3_head,v619_2_head);
              const auto v620_3_branches = branches(c,v619_2_tail);
              std::vector<Space> v620_3_outputs;
              v620_3_outputs.reserve(v620_3_branches.size());
              for (const auto& v620_3_branch : v620_3_branches) {
                const Path v620_3_head{v620_3_branch.first};
                const Space& v620_3_tail = v620_3_branch.second;
                const Path v621_2 = concat_path(v620_2,v620_3_head);
                const auto v621_3_branches = branches(c,v620_3_tail);
                std::vector<Space> v621_3_outputs;
                v621_3_outputs.reserve(v621_3_branches.size());
                for (const auto& v621_3_branch : v621_3_branches) {
                  const Path v621_3_head{v621_3_branch.first};
                  const Space& v621_3_tail = v621_3_branch.second;
                  const Path v622_2 = concat_path(v621_2,v621_3_head);
                  const Space v622_3 = routine_86(c, v622_2, p1, p2, p3, p4, p0, v618_2, v621_3_tail);
                  v621_3_outputs.push_back(v622_3);
                }
                const Space v621_3 = join_outputs(std::move(v621_3_outputs));
                v620_3_outputs.push_back(v621_3);
              }
              const Space v620_3 = join_outputs(std::move(v620_3_outputs));
              v619_2_outputs.push_back(v620_3);
            }
            const Space v619_2 = join_outputs(std::move(v619_2_outputs));
            v618_3_outputs.push_back(v619_2);
          }
          const Space v618_3 = join_outputs(std::move(v618_3_outputs));
          v617_3_outputs.push_back(v618_3);
        }
        const Space v617_3 = join_outputs(std::move(v617_3_outputs));
        v616_3_outputs.push_back(v617_3);
      }
      const Space v616_3 = join_outputs(std::move(v616_3_outputs));
      v615_2_outputs.push_back(v616_3);
    }
    const Space v615_2 = join_outputs(std::move(v615_2_outputs));
    v614_6_outputs.push_back(v615_2);
  }
  const Space v614_6 = join_outputs(std::move(v614_6_outputs));
  return v614_6;
}

static Space routine_71(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v623_6_branches = branches(c,s0);
  std::vector<Space> v623_6_outputs;
  v623_6_outputs.reserve(v623_6_branches.size());
  for (const auto& v623_6_branch : v623_6_branches) {
    const Path v623_6_head{v623_6_branch.first};
    const Space& v623_6_tail = v623_6_branch.second;
    const auto v624_2_branches = branches(c,v623_6_tail);
    std::vector<Space> v624_2_outputs;
    v624_2_outputs.reserve(v624_2_branches.size());
    for (const auto& v624_2_branch : v624_2_branches) {
      const Path v624_2_head{v624_2_branch.first};
      const Space& v624_2_tail = v624_2_branch.second;
      const Path v625_2 = concat_path(v623_6_head,v624_2_head);
      const auto v625_3_branches = branches(c,v624_2_tail);
      std::vector<Space> v625_3_outputs;
      v625_3_outputs.reserve(v625_3_branches.size());
      for (const auto& v625_3_branch : v625_3_branches) {
        const Path v625_3_head{v625_3_branch.first};
        const Space& v625_3_tail = v625_3_branch.second;
        const Path v626_2 = concat_path(v625_2,v625_3_head);
        const auto v626_3_branches = branches(c,v625_3_tail);
        std::vector<Space> v626_3_outputs;
        v626_3_outputs.reserve(v626_3_branches.size());
        for (const auto& v626_3_branch : v626_3_branches) {
          const Path v626_3_head{v626_3_branch.first};
          const Space& v626_3_tail = v626_3_branch.second;
          const Path v627_2 = concat_path(v626_2,v626_3_head);
          const auto v627_3_branches = branches(c,v626_3_tail);
          std::vector<Space> v627_3_outputs;
          v627_3_outputs.reserve(v627_3_branches.size());
          for (const auto& v627_3_branch : v627_3_branches) {
            const Path v627_3_head{v627_3_branch.first};
            const Space& v627_3_tail = v627_3_branch.second;
            const auto v628_2_branches = branches(c,v627_3_tail);
            std::vector<Space> v628_2_outputs;
            v628_2_outputs.reserve(v628_2_branches.size());
            for (const auto& v628_2_branch : v628_2_branches) {
              const Path v628_2_head{v628_2_branch.first};
              const Space& v628_2_tail = v628_2_branch.second;
              const Path v629_2 = concat_path(v627_3_head,v628_2_head);
              const auto v629_3_branches = branches(c,v628_2_tail);
              std::vector<Space> v629_3_outputs;
              v629_3_outputs.reserve(v629_3_branches.size());
              for (const auto& v629_3_branch : v629_3_branches) {
                const Path v629_3_head{v629_3_branch.first};
                const Space& v629_3_tail = v629_3_branch.second;
                const Path v630_2 = concat_path(v629_2,v629_3_head);
                const auto v630_3_branches = branches(c,v629_3_tail);
                std::vector<Space> v630_3_outputs;
                v630_3_outputs.reserve(v630_3_branches.size());
                for (const auto& v630_3_branch : v630_3_branches) {
                  const Path v630_3_head{v630_3_branch.first};
                  const Space& v630_3_tail = v630_3_branch.second;
                  const Path v631_2 = concat_path(v630_2,v630_3_head);
                  const Space v631_3 = routine_87(c, v631_2, p1, p2, p3, p4, p0, v627_2, v630_3_tail);
                  v630_3_outputs.push_back(v631_3);
                }
                const Space v630_3 = join_outputs(std::move(v630_3_outputs));
                v629_3_outputs.push_back(v630_3);
              }
              const Space v629_3 = join_outputs(std::move(v629_3_outputs));
              v628_2_outputs.push_back(v629_3);
            }
            const Space v628_2 = join_outputs(std::move(v628_2_outputs));
            v627_3_outputs.push_back(v628_2);
          }
          const Space v627_3 = join_outputs(std::move(v627_3_outputs));
          v626_3_outputs.push_back(v627_3);
        }
        const Space v626_3 = join_outputs(std::move(v626_3_outputs));
        v625_3_outputs.push_back(v626_3);
      }
      const Space v625_3 = join_outputs(std::move(v625_3_outputs));
      v624_2_outputs.push_back(v625_3);
    }
    const Space v624_2 = join_outputs(std::move(v624_2_outputs));
    v623_6_outputs.push_back(v624_2);
  }
  const Space v623_6 = join_outputs(std::move(v623_6_outputs));
  return v623_6;
}

static Space routine_72(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v632_6_branches = branches(c,s0);
  std::vector<Space> v632_6_outputs;
  v632_6_outputs.reserve(v632_6_branches.size());
  for (const auto& v632_6_branch : v632_6_branches) {
    const Path v632_6_head{v632_6_branch.first};
    const Space& v632_6_tail = v632_6_branch.second;
    const auto v633_2_branches = branches(c,v632_6_tail);
    std::vector<Space> v633_2_outputs;
    v633_2_outputs.reserve(v633_2_branches.size());
    for (const auto& v633_2_branch : v633_2_branches) {
      const Path v633_2_head{v633_2_branch.first};
      const Space& v633_2_tail = v633_2_branch.second;
      const Path v634_2 = concat_path(v632_6_head,v633_2_head);
      const auto v634_3_branches = branches(c,v633_2_tail);
      std::vector<Space> v634_3_outputs;
      v634_3_outputs.reserve(v634_3_branches.size());
      for (const auto& v634_3_branch : v634_3_branches) {
        const Path v634_3_head{v634_3_branch.first};
        const Space& v634_3_tail = v634_3_branch.second;
        const Path v635_2 = concat_path(v634_2,v634_3_head);
        const auto v635_3_branches = branches(c,v634_3_tail);
        std::vector<Space> v635_3_outputs;
        v635_3_outputs.reserve(v635_3_branches.size());
        for (const auto& v635_3_branch : v635_3_branches) {
          const Path v635_3_head{v635_3_branch.first};
          const Space& v635_3_tail = v635_3_branch.second;
          const Path v636_2 = concat_path(v635_2,v635_3_head);
          const auto v636_3_branches = branches(c,v635_3_tail);
          std::vector<Space> v636_3_outputs;
          v636_3_outputs.reserve(v636_3_branches.size());
          for (const auto& v636_3_branch : v636_3_branches) {
            const Path v636_3_head{v636_3_branch.first};
            const Space& v636_3_tail = v636_3_branch.second;
            const auto v637_2_branches = branches(c,v636_3_tail);
            std::vector<Space> v637_2_outputs;
            v637_2_outputs.reserve(v637_2_branches.size());
            for (const auto& v637_2_branch : v637_2_branches) {
              const Path v637_2_head{v637_2_branch.first};
              const Space& v637_2_tail = v637_2_branch.second;
              const Path v638_2 = concat_path(v636_3_head,v637_2_head);
              const auto v638_3_branches = branches(c,v637_2_tail);
              std::vector<Space> v638_3_outputs;
              v638_3_outputs.reserve(v638_3_branches.size());
              for (const auto& v638_3_branch : v638_3_branches) {
                const Path v638_3_head{v638_3_branch.first};
                const Space& v638_3_tail = v638_3_branch.second;
                const Path v639_2 = concat_path(v638_2,v638_3_head);
                const auto v639_3_branches = branches(c,v638_3_tail);
                std::vector<Space> v639_3_outputs;
                v639_3_outputs.reserve(v639_3_branches.size());
                for (const auto& v639_3_branch : v639_3_branches) {
                  const Path v639_3_head{v639_3_branch.first};
                  const Space& v639_3_tail = v639_3_branch.second;
                  const Path v640_2 = concat_path(v639_2,v639_3_head);
                  const Space v640_3 = routine_88(c, v640_2, p1, p2, p3, p4, p0, v636_2, v639_3_tail);
                  v639_3_outputs.push_back(v640_3);
                }
                const Space v639_3 = join_outputs(std::move(v639_3_outputs));
                v638_3_outputs.push_back(v639_3);
              }
              const Space v638_3 = join_outputs(std::move(v638_3_outputs));
              v637_2_outputs.push_back(v638_3);
            }
            const Space v637_2 = join_outputs(std::move(v637_2_outputs));
            v636_3_outputs.push_back(v637_2);
          }
          const Space v636_3 = join_outputs(std::move(v636_3_outputs));
          v635_3_outputs.push_back(v636_3);
        }
        const Space v635_3 = join_outputs(std::move(v635_3_outputs));
        v634_3_outputs.push_back(v635_3);
      }
      const Space v634_3 = join_outputs(std::move(v634_3_outputs));
      v633_2_outputs.push_back(v634_3);
    }
    const Space v633_2 = join_outputs(std::move(v633_2_outputs));
    v632_6_outputs.push_back(v633_2);
  }
  const Space v632_6 = join_outputs(std::move(v632_6_outputs));
  return v632_6;
}

static Space routine_73(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v641_6_branches = branches(c,s0);
  std::vector<Space> v641_6_outputs;
  v641_6_outputs.reserve(v641_6_branches.size());
  for (const auto& v641_6_branch : v641_6_branches) {
    const Path v641_6_head{v641_6_branch.first};
    const Space& v641_6_tail = v641_6_branch.second;
    const auto v642_2_branches = branches(c,v641_6_tail);
    std::vector<Space> v642_2_outputs;
    v642_2_outputs.reserve(v642_2_branches.size());
    for (const auto& v642_2_branch : v642_2_branches) {
      const Path v642_2_head{v642_2_branch.first};
      const Space& v642_2_tail = v642_2_branch.second;
      const Path v643_2 = concat_path(v641_6_head,v642_2_head);
      const auto v643_3_branches = branches(c,v642_2_tail);
      std::vector<Space> v643_3_outputs;
      v643_3_outputs.reserve(v643_3_branches.size());
      for (const auto& v643_3_branch : v643_3_branches) {
        const Path v643_3_head{v643_3_branch.first};
        const Space& v643_3_tail = v643_3_branch.second;
        const Path v644_2 = concat_path(v643_2,v643_3_head);
        const auto v644_3_branches = branches(c,v643_3_tail);
        std::vector<Space> v644_3_outputs;
        v644_3_outputs.reserve(v644_3_branches.size());
        for (const auto& v644_3_branch : v644_3_branches) {
          const Path v644_3_head{v644_3_branch.first};
          const Space& v644_3_tail = v644_3_branch.second;
          const Path v645_2 = concat_path(v644_2,v644_3_head);
          const auto v645_3_branches = branches(c,v644_3_tail);
          std::vector<Space> v645_3_outputs;
          v645_3_outputs.reserve(v645_3_branches.size());
          for (const auto& v645_3_branch : v645_3_branches) {
            const Path v645_3_head{v645_3_branch.first};
            const Space& v645_3_tail = v645_3_branch.second;
            const auto v646_2_branches = branches(c,v645_3_tail);
            std::vector<Space> v646_2_outputs;
            v646_2_outputs.reserve(v646_2_branches.size());
            for (const auto& v646_2_branch : v646_2_branches) {
              const Path v646_2_head{v646_2_branch.first};
              const Space& v646_2_tail = v646_2_branch.second;
              const Path v647_2 = concat_path(v645_3_head,v646_2_head);
              const auto v647_3_branches = branches(c,v646_2_tail);
              std::vector<Space> v647_3_outputs;
              v647_3_outputs.reserve(v647_3_branches.size());
              for (const auto& v647_3_branch : v647_3_branches) {
                const Path v647_3_head{v647_3_branch.first};
                const Space& v647_3_tail = v647_3_branch.second;
                const Path v648_2 = concat_path(v647_2,v647_3_head);
                const auto v648_3_branches = branches(c,v647_3_tail);
                std::vector<Space> v648_3_outputs;
                v648_3_outputs.reserve(v648_3_branches.size());
                for (const auto& v648_3_branch : v648_3_branches) {
                  const Path v648_3_head{v648_3_branch.first};
                  const Space& v648_3_tail = v648_3_branch.second;
                  const Path v649_2 = concat_path(v648_2,v648_3_head);
                  const Space v649_3 = routine_89(c, v649_2, p1, p2, p3, p4, p0, v645_2, v648_3_tail);
                  v648_3_outputs.push_back(v649_3);
                }
                const Space v648_3 = join_outputs(std::move(v648_3_outputs));
                v647_3_outputs.push_back(v648_3);
              }
              const Space v647_3 = join_outputs(std::move(v647_3_outputs));
              v646_2_outputs.push_back(v647_3);
            }
            const Space v646_2 = join_outputs(std::move(v646_2_outputs));
            v645_3_outputs.push_back(v646_2);
          }
          const Space v645_3 = join_outputs(std::move(v645_3_outputs));
          v644_3_outputs.push_back(v645_3);
        }
        const Space v644_3 = join_outputs(std::move(v644_3_outputs));
        v643_3_outputs.push_back(v644_3);
      }
      const Space v643_3 = join_outputs(std::move(v643_3_outputs));
      v642_2_outputs.push_back(v643_3);
    }
    const Space v642_2 = join_outputs(std::move(v642_2_outputs));
    v641_6_outputs.push_back(v642_2);
  }
  const Space v641_6 = join_outputs(std::move(v641_6_outputs));
  return v641_6;
}

static Space routine_74(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v650_6_branches = branches(c,s0);
  std::vector<Space> v650_6_outputs;
  v650_6_outputs.reserve(v650_6_branches.size());
  for (const auto& v650_6_branch : v650_6_branches) {
    const Path v650_6_head{v650_6_branch.first};
    const Space& v650_6_tail = v650_6_branch.second;
    const auto v651_2_branches = branches(c,v650_6_tail);
    std::vector<Space> v651_2_outputs;
    v651_2_outputs.reserve(v651_2_branches.size());
    for (const auto& v651_2_branch : v651_2_branches) {
      const Path v651_2_head{v651_2_branch.first};
      const Space& v651_2_tail = v651_2_branch.second;
      const Path v652_2 = concat_path(v650_6_head,v651_2_head);
      const auto v652_3_branches = branches(c,v651_2_tail);
      std::vector<Space> v652_3_outputs;
      v652_3_outputs.reserve(v652_3_branches.size());
      for (const auto& v652_3_branch : v652_3_branches) {
        const Path v652_3_head{v652_3_branch.first};
        const Space& v652_3_tail = v652_3_branch.second;
        const Path v653_2 = concat_path(v652_2,v652_3_head);
        const auto v653_3_branches = branches(c,v652_3_tail);
        std::vector<Space> v653_3_outputs;
        v653_3_outputs.reserve(v653_3_branches.size());
        for (const auto& v653_3_branch : v653_3_branches) {
          const Path v653_3_head{v653_3_branch.first};
          const Space& v653_3_tail = v653_3_branch.second;
          const Path v654_2 = concat_path(v653_2,v653_3_head);
          const auto v654_3_branches = branches(c,v653_3_tail);
          std::vector<Space> v654_3_outputs;
          v654_3_outputs.reserve(v654_3_branches.size());
          for (const auto& v654_3_branch : v654_3_branches) {
            const Path v654_3_head{v654_3_branch.first};
            const Space& v654_3_tail = v654_3_branch.second;
            const auto v655_2_branches = branches(c,v654_3_tail);
            std::vector<Space> v655_2_outputs;
            v655_2_outputs.reserve(v655_2_branches.size());
            for (const auto& v655_2_branch : v655_2_branches) {
              const Path v655_2_head{v655_2_branch.first};
              const Space& v655_2_tail = v655_2_branch.second;
              const Path v656_2 = concat_path(v654_3_head,v655_2_head);
              const auto v656_3_branches = branches(c,v655_2_tail);
              std::vector<Space> v656_3_outputs;
              v656_3_outputs.reserve(v656_3_branches.size());
              for (const auto& v656_3_branch : v656_3_branches) {
                const Path v656_3_head{v656_3_branch.first};
                const Space& v656_3_tail = v656_3_branch.second;
                const Path v657_2 = concat_path(v656_2,v656_3_head);
                const auto v657_3_branches = branches(c,v656_3_tail);
                std::vector<Space> v657_3_outputs;
                v657_3_outputs.reserve(v657_3_branches.size());
                for (const auto& v657_3_branch : v657_3_branches) {
                  const Path v657_3_head{v657_3_branch.first};
                  const Space& v657_3_tail = v657_3_branch.second;
                  const Path v658_2 = concat_path(v657_2,v657_3_head);
                  const Space v658_3 = routine_90(c, v658_2, p1, p2, p3, p4, p0, v654_2, v657_3_tail);
                  v657_3_outputs.push_back(v658_3);
                }
                const Space v657_3 = join_outputs(std::move(v657_3_outputs));
                v656_3_outputs.push_back(v657_3);
              }
              const Space v656_3 = join_outputs(std::move(v656_3_outputs));
              v655_2_outputs.push_back(v656_3);
            }
            const Space v655_2 = join_outputs(std::move(v655_2_outputs));
            v654_3_outputs.push_back(v655_2);
          }
          const Space v654_3 = join_outputs(std::move(v654_3_outputs));
          v653_3_outputs.push_back(v654_3);
        }
        const Space v653_3 = join_outputs(std::move(v653_3_outputs));
        v652_3_outputs.push_back(v653_3);
      }
      const Space v652_3 = join_outputs(std::move(v652_3_outputs));
      v651_2_outputs.push_back(v652_3);
    }
    const Space v651_2 = join_outputs(std::move(v651_2_outputs));
    v650_6_outputs.push_back(v651_2);
  }
  const Space v650_6 = join_outputs(std::move(v650_6_outputs));
  return v650_6;
}

static Space routine_75(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v659_6_branches = branches(c,s0);
  std::vector<Space> v659_6_outputs;
  v659_6_outputs.reserve(v659_6_branches.size());
  for (const auto& v659_6_branch : v659_6_branches) {
    const Path v659_6_head{v659_6_branch.first};
    const Space& v659_6_tail = v659_6_branch.second;
    const auto v660_2_branches = branches(c,v659_6_tail);
    std::vector<Space> v660_2_outputs;
    v660_2_outputs.reserve(v660_2_branches.size());
    for (const auto& v660_2_branch : v660_2_branches) {
      const Path v660_2_head{v660_2_branch.first};
      const Space& v660_2_tail = v660_2_branch.second;
      const Path v661_2 = concat_path(v659_6_head,v660_2_head);
      const auto v661_3_branches = branches(c,v660_2_tail);
      std::vector<Space> v661_3_outputs;
      v661_3_outputs.reserve(v661_3_branches.size());
      for (const auto& v661_3_branch : v661_3_branches) {
        const Path v661_3_head{v661_3_branch.first};
        const Space& v661_3_tail = v661_3_branch.second;
        const Path v662_2 = concat_path(v661_2,v661_3_head);
        const auto v662_3_branches = branches(c,v661_3_tail);
        std::vector<Space> v662_3_outputs;
        v662_3_outputs.reserve(v662_3_branches.size());
        for (const auto& v662_3_branch : v662_3_branches) {
          const Path v662_3_head{v662_3_branch.first};
          const Space& v662_3_tail = v662_3_branch.second;
          const Path v663_2 = concat_path(v662_2,v662_3_head);
          const auto v663_3_branches = branches(c,v662_3_tail);
          std::vector<Space> v663_3_outputs;
          v663_3_outputs.reserve(v663_3_branches.size());
          for (const auto& v663_3_branch : v663_3_branches) {
            const Path v663_3_head{v663_3_branch.first};
            const Space& v663_3_tail = v663_3_branch.second;
            const auto v664_2_branches = branches(c,v663_3_tail);
            std::vector<Space> v664_2_outputs;
            v664_2_outputs.reserve(v664_2_branches.size());
            for (const auto& v664_2_branch : v664_2_branches) {
              const Path v664_2_head{v664_2_branch.first};
              const Space& v664_2_tail = v664_2_branch.second;
              const Path v665_2 = concat_path(v663_3_head,v664_2_head);
              const auto v665_3_branches = branches(c,v664_2_tail);
              std::vector<Space> v665_3_outputs;
              v665_3_outputs.reserve(v665_3_branches.size());
              for (const auto& v665_3_branch : v665_3_branches) {
                const Path v665_3_head{v665_3_branch.first};
                const Space& v665_3_tail = v665_3_branch.second;
                const Path v666_2 = concat_path(v665_2,v665_3_head);
                const auto v666_3_branches = branches(c,v665_3_tail);
                std::vector<Space> v666_3_outputs;
                v666_3_outputs.reserve(v666_3_branches.size());
                for (const auto& v666_3_branch : v666_3_branches) {
                  const Path v666_3_head{v666_3_branch.first};
                  const Space& v666_3_tail = v666_3_branch.second;
                  const Path v667_2 = concat_path(v666_2,v666_3_head);
                  const Space v667_3 = routine_91(c, v667_2, p1, p2, p3, p4, p0, v663_2, v666_3_tail);
                  v666_3_outputs.push_back(v667_3);
                }
                const Space v666_3 = join_outputs(std::move(v666_3_outputs));
                v665_3_outputs.push_back(v666_3);
              }
              const Space v665_3 = join_outputs(std::move(v665_3_outputs));
              v664_2_outputs.push_back(v665_3);
            }
            const Space v664_2 = join_outputs(std::move(v664_2_outputs));
            v663_3_outputs.push_back(v664_2);
          }
          const Space v663_3 = join_outputs(std::move(v663_3_outputs));
          v662_3_outputs.push_back(v663_3);
        }
        const Space v662_3 = join_outputs(std::move(v662_3_outputs));
        v661_3_outputs.push_back(v662_3);
      }
      const Space v661_3 = join_outputs(std::move(v661_3_outputs));
      v660_2_outputs.push_back(v661_3);
    }
    const Space v660_2 = join_outputs(std::move(v660_2_outputs));
    v659_6_outputs.push_back(v660_2);
  }
  const Space v659_6 = join_outputs(std::move(v659_6_outputs));
  return v659_6;
}

static Space routine_76(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v668_6_branches = branches(c,s0);
  std::vector<Space> v668_6_outputs;
  v668_6_outputs.reserve(v668_6_branches.size());
  for (const auto& v668_6_branch : v668_6_branches) {
    const Path v668_6_head{v668_6_branch.first};
    const Space& v668_6_tail = v668_6_branch.second;
    const auto v669_2_branches = branches(c,v668_6_tail);
    std::vector<Space> v669_2_outputs;
    v669_2_outputs.reserve(v669_2_branches.size());
    for (const auto& v669_2_branch : v669_2_branches) {
      const Path v669_2_head{v669_2_branch.first};
      const Space& v669_2_tail = v669_2_branch.second;
      const Path v670_2 = concat_path(v668_6_head,v669_2_head);
      const auto v670_3_branches = branches(c,v669_2_tail);
      std::vector<Space> v670_3_outputs;
      v670_3_outputs.reserve(v670_3_branches.size());
      for (const auto& v670_3_branch : v670_3_branches) {
        const Path v670_3_head{v670_3_branch.first};
        const Space& v670_3_tail = v670_3_branch.second;
        const Path v671_2 = concat_path(v670_2,v670_3_head);
        const auto v671_3_branches = branches(c,v670_3_tail);
        std::vector<Space> v671_3_outputs;
        v671_3_outputs.reserve(v671_3_branches.size());
        for (const auto& v671_3_branch : v671_3_branches) {
          const Path v671_3_head{v671_3_branch.first};
          const Space& v671_3_tail = v671_3_branch.second;
          const Path v672_2 = concat_path(v671_2,v671_3_head);
          const auto v672_3_branches = branches(c,v671_3_tail);
          std::vector<Space> v672_3_outputs;
          v672_3_outputs.reserve(v672_3_branches.size());
          for (const auto& v672_3_branch : v672_3_branches) {
            const Path v672_3_head{v672_3_branch.first};
            const Space& v672_3_tail = v672_3_branch.second;
            const auto v673_2_branches = branches(c,v672_3_tail);
            std::vector<Space> v673_2_outputs;
            v673_2_outputs.reserve(v673_2_branches.size());
            for (const auto& v673_2_branch : v673_2_branches) {
              const Path v673_2_head{v673_2_branch.first};
              const Space& v673_2_tail = v673_2_branch.second;
              const Path v674_2 = concat_path(v672_3_head,v673_2_head);
              const auto v674_3_branches = branches(c,v673_2_tail);
              std::vector<Space> v674_3_outputs;
              v674_3_outputs.reserve(v674_3_branches.size());
              for (const auto& v674_3_branch : v674_3_branches) {
                const Path v674_3_head{v674_3_branch.first};
                const Space& v674_3_tail = v674_3_branch.second;
                const Path v675_2 = concat_path(v674_2,v674_3_head);
                const auto v675_3_branches = branches(c,v674_3_tail);
                std::vector<Space> v675_3_outputs;
                v675_3_outputs.reserve(v675_3_branches.size());
                for (const auto& v675_3_branch : v675_3_branches) {
                  const Path v675_3_head{v675_3_branch.first};
                  const Space& v675_3_tail = v675_3_branch.second;
                  const Path v676_2 = concat_path(v675_2,v675_3_head);
                  const Space v676_3 = routine_92(c, v676_2, p1, p2, p3, p4, p0, v672_2, v675_3_tail);
                  v675_3_outputs.push_back(v676_3);
                }
                const Space v675_3 = join_outputs(std::move(v675_3_outputs));
                v674_3_outputs.push_back(v675_3);
              }
              const Space v674_3 = join_outputs(std::move(v674_3_outputs));
              v673_2_outputs.push_back(v674_3);
            }
            const Space v673_2 = join_outputs(std::move(v673_2_outputs));
            v672_3_outputs.push_back(v673_2);
          }
          const Space v672_3 = join_outputs(std::move(v672_3_outputs));
          v671_3_outputs.push_back(v672_3);
        }
        const Space v671_3 = join_outputs(std::move(v671_3_outputs));
        v670_3_outputs.push_back(v671_3);
      }
      const Space v670_3 = join_outputs(std::move(v670_3_outputs));
      v669_2_outputs.push_back(v670_3);
    }
    const Space v669_2 = join_outputs(std::move(v669_2_outputs));
    v668_6_outputs.push_back(v669_2);
  }
  const Space v668_6 = join_outputs(std::move(v668_6_outputs));
  return v668_6;
}

static Space routine_77(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v677_6_branches = branches(c,s0);
  std::vector<Space> v677_6_outputs;
  v677_6_outputs.reserve(v677_6_branches.size());
  for (const auto& v677_6_branch : v677_6_branches) {
    const Path v677_6_head{v677_6_branch.first};
    const Space& v677_6_tail = v677_6_branch.second;
    const auto v678_2_branches = branches(c,v677_6_tail);
    std::vector<Space> v678_2_outputs;
    v678_2_outputs.reserve(v678_2_branches.size());
    for (const auto& v678_2_branch : v678_2_branches) {
      const Path v678_2_head{v678_2_branch.first};
      const Space& v678_2_tail = v678_2_branch.second;
      const Path v679_2 = concat_path(v677_6_head,v678_2_head);
      const auto v679_3_branches = branches(c,v678_2_tail);
      std::vector<Space> v679_3_outputs;
      v679_3_outputs.reserve(v679_3_branches.size());
      for (const auto& v679_3_branch : v679_3_branches) {
        const Path v679_3_head{v679_3_branch.first};
        const Space& v679_3_tail = v679_3_branch.second;
        const Path v680_2 = concat_path(v679_2,v679_3_head);
        const auto v680_3_branches = branches(c,v679_3_tail);
        std::vector<Space> v680_3_outputs;
        v680_3_outputs.reserve(v680_3_branches.size());
        for (const auto& v680_3_branch : v680_3_branches) {
          const Path v680_3_head{v680_3_branch.first};
          const Space& v680_3_tail = v680_3_branch.second;
          const Path v681_2 = concat_path(v680_2,v680_3_head);
          const auto v681_3_branches = branches(c,v680_3_tail);
          std::vector<Space> v681_3_outputs;
          v681_3_outputs.reserve(v681_3_branches.size());
          for (const auto& v681_3_branch : v681_3_branches) {
            const Path v681_3_head{v681_3_branch.first};
            const Space& v681_3_tail = v681_3_branch.second;
            const auto v682_2_branches = branches(c,v681_3_tail);
            std::vector<Space> v682_2_outputs;
            v682_2_outputs.reserve(v682_2_branches.size());
            for (const auto& v682_2_branch : v682_2_branches) {
              const Path v682_2_head{v682_2_branch.first};
              const Space& v682_2_tail = v682_2_branch.second;
              const Path v683_2 = concat_path(v681_3_head,v682_2_head);
              const auto v683_3_branches = branches(c,v682_2_tail);
              std::vector<Space> v683_3_outputs;
              v683_3_outputs.reserve(v683_3_branches.size());
              for (const auto& v683_3_branch : v683_3_branches) {
                const Path v683_3_head{v683_3_branch.first};
                const Space& v683_3_tail = v683_3_branch.second;
                const Path v684_2 = concat_path(v683_2,v683_3_head);
                const auto v684_3_branches = branches(c,v683_3_tail);
                std::vector<Space> v684_3_outputs;
                v684_3_outputs.reserve(v684_3_branches.size());
                for (const auto& v684_3_branch : v684_3_branches) {
                  const Path v684_3_head{v684_3_branch.first};
                  const Space& v684_3_tail = v684_3_branch.second;
                  const Path v685_2 = concat_path(v684_2,v684_3_head);
                  const Space v685_3 = routine_93(c, v685_2, p1, p2, p3, p4, p0, v681_2, v684_3_tail);
                  v684_3_outputs.push_back(v685_3);
                }
                const Space v684_3 = join_outputs(std::move(v684_3_outputs));
                v683_3_outputs.push_back(v684_3);
              }
              const Space v683_3 = join_outputs(std::move(v683_3_outputs));
              v682_2_outputs.push_back(v683_3);
            }
            const Space v682_2 = join_outputs(std::move(v682_2_outputs));
            v681_3_outputs.push_back(v682_2);
          }
          const Space v681_3 = join_outputs(std::move(v681_3_outputs));
          v680_3_outputs.push_back(v681_3);
        }
        const Space v680_3 = join_outputs(std::move(v680_3_outputs));
        v679_3_outputs.push_back(v680_3);
      }
      const Space v679_3 = join_outputs(std::move(v679_3_outputs));
      v678_2_outputs.push_back(v679_3);
    }
    const Space v678_2 = join_outputs(std::move(v678_2_outputs));
    v677_6_outputs.push_back(v678_2);
  }
  const Space v677_6 = join_outputs(std::move(v677_6_outputs));
  return v677_6;
}

static Space routine_78(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Space& s0) {
  const auto v686_6_branches = branches(c,s0);
  std::vector<Space> v686_6_outputs;
  v686_6_outputs.reserve(v686_6_branches.size());
  for (const auto& v686_6_branch : v686_6_branches) {
    const Path v686_6_head{v686_6_branch.first};
    const Space& v686_6_tail = v686_6_branch.second;
    const auto v687_2_branches = branches(c,v686_6_tail);
    std::vector<Space> v687_2_outputs;
    v687_2_outputs.reserve(v687_2_branches.size());
    for (const auto& v687_2_branch : v687_2_branches) {
      const Path v687_2_head{v687_2_branch.first};
      const Space& v687_2_tail = v687_2_branch.second;
      const Path v688_2 = concat_path(v686_6_head,v687_2_head);
      const auto v688_3_branches = branches(c,v687_2_tail);
      std::vector<Space> v688_3_outputs;
      v688_3_outputs.reserve(v688_3_branches.size());
      for (const auto& v688_3_branch : v688_3_branches) {
        const Path v688_3_head{v688_3_branch.first};
        const Space& v688_3_tail = v688_3_branch.second;
        const Path v689_2 = concat_path(v688_2,v688_3_head);
        const auto v689_3_branches = branches(c,v688_3_tail);
        std::vector<Space> v689_3_outputs;
        v689_3_outputs.reserve(v689_3_branches.size());
        for (const auto& v689_3_branch : v689_3_branches) {
          const Path v689_3_head{v689_3_branch.first};
          const Space& v689_3_tail = v689_3_branch.second;
          const Path v690_2 = concat_path(v689_2,v689_3_head);
          const auto v690_3_branches = branches(c,v689_3_tail);
          std::vector<Space> v690_3_outputs;
          v690_3_outputs.reserve(v690_3_branches.size());
          for (const auto& v690_3_branch : v690_3_branches) {
            const Path v690_3_head{v690_3_branch.first};
            const Space& v690_3_tail = v690_3_branch.second;
            const auto v691_2_branches = branches(c,v690_3_tail);
            std::vector<Space> v691_2_outputs;
            v691_2_outputs.reserve(v691_2_branches.size());
            for (const auto& v691_2_branch : v691_2_branches) {
              const Path v691_2_head{v691_2_branch.first};
              const Space& v691_2_tail = v691_2_branch.second;
              const Path v692_2 = concat_path(v690_3_head,v691_2_head);
              const auto v692_3_branches = branches(c,v691_2_tail);
              std::vector<Space> v692_3_outputs;
              v692_3_outputs.reserve(v692_3_branches.size());
              for (const auto& v692_3_branch : v692_3_branches) {
                const Path v692_3_head{v692_3_branch.first};
                const Space& v692_3_tail = v692_3_branch.second;
                const Path v693_2 = concat_path(v692_2,v692_3_head);
                const auto v693_3_branches = branches(c,v692_3_tail);
                std::vector<Space> v693_3_outputs;
                v693_3_outputs.reserve(v693_3_branches.size());
                for (const auto& v693_3_branch : v693_3_branches) {
                  const Path v693_3_head{v693_3_branch.first};
                  const Space& v693_3_tail = v693_3_branch.second;
                  const Path v694_2 = concat_path(v693_2,v693_3_head);
                  const Space v694_3 = routine_94(c, v694_2, p1, p2, p3, p4, p0, v690_2, v693_3_tail);
                  v693_3_outputs.push_back(v694_3);
                }
                const Space v693_3 = join_outputs(std::move(v693_3_outputs));
                v692_3_outputs.push_back(v693_3);
              }
              const Space v692_3 = join_outputs(std::move(v692_3_outputs));
              v691_2_outputs.push_back(v692_3);
            }
            const Space v691_2 = join_outputs(std::move(v691_2_outputs));
            v690_3_outputs.push_back(v691_2);
          }
          const Space v690_3 = join_outputs(std::move(v690_3_outputs));
          v689_3_outputs.push_back(v690_3);
        }
        const Space v689_3 = join_outputs(std::move(v689_3_outputs));
        v688_3_outputs.push_back(v689_3);
      }
      const Space v688_3 = join_outputs(std::move(v688_3_outputs));
      v687_2_outputs.push_back(v688_3);
    }
    const Space v687_2 = join_outputs(std::move(v687_2_outputs));
    v686_6_outputs.push_back(v687_2);
  }
  const Space v686_6 = join_outputs(std::move(v686_6_outputs));
  return v686_6;
}

static Space routine_79(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v695_8_branches = branches(c,s0);
  std::vector<Space> v695_8_outputs;
  v695_8_outputs.reserve(v695_8_branches.size());
  for (const auto& v695_8_branch : v695_8_branches) {
    const Path v695_8_head{v695_8_branch.first};
    const Space& v695_8_tail = v695_8_branch.second;
    const auto v696_2_branches = branches(c,v695_8_tail);
    std::vector<Space> v696_2_outputs;
    v696_2_outputs.reserve(v696_2_branches.size());
    for (const auto& v696_2_branch : v696_2_branches) {
      const Path v696_2_head{v696_2_branch.first};
      const Space& v696_2_tail = v696_2_branch.second;
      const Path v697_2 = concat_path(v695_8_head,v696_2_head);
      const auto v697_3_branches = branches(c,v696_2_tail);
      std::vector<Space> v697_3_outputs;
      v697_3_outputs.reserve(v697_3_branches.size());
      for (const auto& v697_3_branch : v697_3_branches) {
        const Path v697_3_head{v697_3_branch.first};
        const Space& v697_3_tail = v697_3_branch.second;
        const Path v698_2 = concat_path(v697_2,v697_3_head);
        const auto v698_3_branches = branches(c,v697_3_tail);
        std::vector<Space> v698_3_outputs;
        v698_3_outputs.reserve(v698_3_branches.size());
        for (const auto& v698_3_branch : v698_3_branches) {
          const Path v698_3_head{v698_3_branch.first};
          const Space& v698_3_tail = v698_3_branch.second;
          const Path v699_2 = concat_path(v698_2,v698_3_head);
          const auto v699_3_branches = branches(c,v698_3_tail);
          std::vector<Space> v699_3_outputs;
          v699_3_outputs.reserve(v699_3_branches.size());
          for (const auto& v699_3_branch : v699_3_branches) {
            const Path v699_3_head{v699_3_branch.first};
            const Space& v699_3_tail = v699_3_branch.second;
            const auto v700_2_branches = branches(c,v699_3_tail);
            std::vector<Space> v700_2_outputs;
            v700_2_outputs.reserve(v700_2_branches.size());
            for (const auto& v700_2_branch : v700_2_branches) {
              const Path v700_2_head{v700_2_branch.first};
              const Space& v700_2_tail = v700_2_branch.second;
              const Path v701_2 = concat_path(v699_3_head,v700_2_head);
              const auto v701_3_branches = branches(c,v700_2_tail);
              std::vector<Space> v701_3_outputs;
              v701_3_outputs.reserve(v701_3_branches.size());
              for (const auto& v701_3_branch : v701_3_branches) {
                const Path v701_3_head{v701_3_branch.first};
                const Space& v701_3_tail = v701_3_branch.second;
                const Path v702_2 = concat_path(v701_2,v701_3_head);
                const auto v702_3_branches = branches(c,v701_3_tail);
                std::vector<Space> v702_3_outputs;
                v702_3_outputs.reserve(v702_3_branches.size());
                for (const auto& v702_3_branch : v702_3_branches) {
                  const Path v702_3_head{v702_3_branch.first};
                  const Space& v702_3_tail = v702_3_branch.second;
                  const Path v703_2 = concat_path(v702_2,v702_3_head);
                  const Space v703_3 = routine_95(c, v703_2, p1, p2, p3, p4, p5, p6, p0, v699_2, v702_3_tail);
                  v702_3_outputs.push_back(v703_3);
                }
                const Space v702_3 = join_outputs(std::move(v702_3_outputs));
                v701_3_outputs.push_back(v702_3);
              }
              const Space v701_3 = join_outputs(std::move(v701_3_outputs));
              v700_2_outputs.push_back(v701_3);
            }
            const Space v700_2 = join_outputs(std::move(v700_2_outputs));
            v699_3_outputs.push_back(v700_2);
          }
          const Space v699_3 = join_outputs(std::move(v699_3_outputs));
          v698_3_outputs.push_back(v699_3);
        }
        const Space v698_3 = join_outputs(std::move(v698_3_outputs));
        v697_3_outputs.push_back(v698_3);
      }
      const Space v697_3 = join_outputs(std::move(v697_3_outputs));
      v696_2_outputs.push_back(v697_3);
    }
    const Space v696_2 = join_outputs(std::move(v696_2_outputs));
    v695_8_outputs.push_back(v696_2);
  }
  const Space v695_8 = join_outputs(std::move(v695_8_outputs));
  return v695_8;
}

static Space routine_80(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v704_8_branches = branches(c,s0);
  std::vector<Space> v704_8_outputs;
  v704_8_outputs.reserve(v704_8_branches.size());
  for (const auto& v704_8_branch : v704_8_branches) {
    const Path v704_8_head{v704_8_branch.first};
    const Space& v704_8_tail = v704_8_branch.second;
    const auto v705_2_branches = branches(c,v704_8_tail);
    std::vector<Space> v705_2_outputs;
    v705_2_outputs.reserve(v705_2_branches.size());
    for (const auto& v705_2_branch : v705_2_branches) {
      const Path v705_2_head{v705_2_branch.first};
      const Space& v705_2_tail = v705_2_branch.second;
      const Path v706_2 = concat_path(v704_8_head,v705_2_head);
      const auto v706_3_branches = branches(c,v705_2_tail);
      std::vector<Space> v706_3_outputs;
      v706_3_outputs.reserve(v706_3_branches.size());
      for (const auto& v706_3_branch : v706_3_branches) {
        const Path v706_3_head{v706_3_branch.first};
        const Space& v706_3_tail = v706_3_branch.second;
        const Path v707_2 = concat_path(v706_2,v706_3_head);
        const auto v707_3_branches = branches(c,v706_3_tail);
        std::vector<Space> v707_3_outputs;
        v707_3_outputs.reserve(v707_3_branches.size());
        for (const auto& v707_3_branch : v707_3_branches) {
          const Path v707_3_head{v707_3_branch.first};
          const Space& v707_3_tail = v707_3_branch.second;
          const Path v708_2 = concat_path(v707_2,v707_3_head);
          const auto v708_3_branches = branches(c,v707_3_tail);
          std::vector<Space> v708_3_outputs;
          v708_3_outputs.reserve(v708_3_branches.size());
          for (const auto& v708_3_branch : v708_3_branches) {
            const Path v708_3_head{v708_3_branch.first};
            const Space& v708_3_tail = v708_3_branch.second;
            const auto v709_2_branches = branches(c,v708_3_tail);
            std::vector<Space> v709_2_outputs;
            v709_2_outputs.reserve(v709_2_branches.size());
            for (const auto& v709_2_branch : v709_2_branches) {
              const Path v709_2_head{v709_2_branch.first};
              const Space& v709_2_tail = v709_2_branch.second;
              const Path v710_2 = concat_path(v708_3_head,v709_2_head);
              const auto v710_3_branches = branches(c,v709_2_tail);
              std::vector<Space> v710_3_outputs;
              v710_3_outputs.reserve(v710_3_branches.size());
              for (const auto& v710_3_branch : v710_3_branches) {
                const Path v710_3_head{v710_3_branch.first};
                const Space& v710_3_tail = v710_3_branch.second;
                const Path v711_2 = concat_path(v710_2,v710_3_head);
                const auto v711_3_branches = branches(c,v710_3_tail);
                std::vector<Space> v711_3_outputs;
                v711_3_outputs.reserve(v711_3_branches.size());
                for (const auto& v711_3_branch : v711_3_branches) {
                  const Path v711_3_head{v711_3_branch.first};
                  const Space& v711_3_tail = v711_3_branch.second;
                  const Path v712_2 = concat_path(v711_2,v711_3_head);
                  const Space v712_3 = routine_96(c, v712_2, p1, p2, p3, p4, p5, p6, p0, v708_2, v711_3_tail);
                  v711_3_outputs.push_back(v712_3);
                }
                const Space v711_3 = join_outputs(std::move(v711_3_outputs));
                v710_3_outputs.push_back(v711_3);
              }
              const Space v710_3 = join_outputs(std::move(v710_3_outputs));
              v709_2_outputs.push_back(v710_3);
            }
            const Space v709_2 = join_outputs(std::move(v709_2_outputs));
            v708_3_outputs.push_back(v709_2);
          }
          const Space v708_3 = join_outputs(std::move(v708_3_outputs));
          v707_3_outputs.push_back(v708_3);
        }
        const Space v707_3 = join_outputs(std::move(v707_3_outputs));
        v706_3_outputs.push_back(v707_3);
      }
      const Space v706_3 = join_outputs(std::move(v706_3_outputs));
      v705_2_outputs.push_back(v706_3);
    }
    const Space v705_2 = join_outputs(std::move(v705_2_outputs));
    v704_8_outputs.push_back(v705_2);
  }
  const Space v704_8 = join_outputs(std::move(v704_8_outputs));
  return v704_8;
}

static Space routine_81(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v713_8_branches = branches(c,s0);
  std::vector<Space> v713_8_outputs;
  v713_8_outputs.reserve(v713_8_branches.size());
  for (const auto& v713_8_branch : v713_8_branches) {
    const Path v713_8_head{v713_8_branch.first};
    const Space& v713_8_tail = v713_8_branch.second;
    const auto v714_2_branches = branches(c,v713_8_tail);
    std::vector<Space> v714_2_outputs;
    v714_2_outputs.reserve(v714_2_branches.size());
    for (const auto& v714_2_branch : v714_2_branches) {
      const Path v714_2_head{v714_2_branch.first};
      const Space& v714_2_tail = v714_2_branch.second;
      const Path v715_2 = concat_path(v713_8_head,v714_2_head);
      const auto v715_3_branches = branches(c,v714_2_tail);
      std::vector<Space> v715_3_outputs;
      v715_3_outputs.reserve(v715_3_branches.size());
      for (const auto& v715_3_branch : v715_3_branches) {
        const Path v715_3_head{v715_3_branch.first};
        const Space& v715_3_tail = v715_3_branch.second;
        const Path v716_2 = concat_path(v715_2,v715_3_head);
        const auto v716_3_branches = branches(c,v715_3_tail);
        std::vector<Space> v716_3_outputs;
        v716_3_outputs.reserve(v716_3_branches.size());
        for (const auto& v716_3_branch : v716_3_branches) {
          const Path v716_3_head{v716_3_branch.first};
          const Space& v716_3_tail = v716_3_branch.second;
          const Path v717_2 = concat_path(v716_2,v716_3_head);
          const auto v717_3_branches = branches(c,v716_3_tail);
          std::vector<Space> v717_3_outputs;
          v717_3_outputs.reserve(v717_3_branches.size());
          for (const auto& v717_3_branch : v717_3_branches) {
            const Path v717_3_head{v717_3_branch.first};
            const Space& v717_3_tail = v717_3_branch.second;
            const auto v718_2_branches = branches(c,v717_3_tail);
            std::vector<Space> v718_2_outputs;
            v718_2_outputs.reserve(v718_2_branches.size());
            for (const auto& v718_2_branch : v718_2_branches) {
              const Path v718_2_head{v718_2_branch.first};
              const Space& v718_2_tail = v718_2_branch.second;
              const Path v719_2 = concat_path(v717_3_head,v718_2_head);
              const auto v719_3_branches = branches(c,v718_2_tail);
              std::vector<Space> v719_3_outputs;
              v719_3_outputs.reserve(v719_3_branches.size());
              for (const auto& v719_3_branch : v719_3_branches) {
                const Path v719_3_head{v719_3_branch.first};
                const Space& v719_3_tail = v719_3_branch.second;
                const Path v720_2 = concat_path(v719_2,v719_3_head);
                const auto v720_3_branches = branches(c,v719_3_tail);
                std::vector<Space> v720_3_outputs;
                v720_3_outputs.reserve(v720_3_branches.size());
                for (const auto& v720_3_branch : v720_3_branches) {
                  const Path v720_3_head{v720_3_branch.first};
                  const Space& v720_3_tail = v720_3_branch.second;
                  const Path v721_2 = concat_path(v720_2,v720_3_head);
                  const Space v721_3 = routine_97(c, v721_2, p1, p2, p3, p4, p5, p6, p0, v717_2, v720_3_tail);
                  v720_3_outputs.push_back(v721_3);
                }
                const Space v720_3 = join_outputs(std::move(v720_3_outputs));
                v719_3_outputs.push_back(v720_3);
              }
              const Space v719_3 = join_outputs(std::move(v719_3_outputs));
              v718_2_outputs.push_back(v719_3);
            }
            const Space v718_2 = join_outputs(std::move(v718_2_outputs));
            v717_3_outputs.push_back(v718_2);
          }
          const Space v717_3 = join_outputs(std::move(v717_3_outputs));
          v716_3_outputs.push_back(v717_3);
        }
        const Space v716_3 = join_outputs(std::move(v716_3_outputs));
        v715_3_outputs.push_back(v716_3);
      }
      const Space v715_3 = join_outputs(std::move(v715_3_outputs));
      v714_2_outputs.push_back(v715_3);
    }
    const Space v714_2 = join_outputs(std::move(v714_2_outputs));
    v713_8_outputs.push_back(v714_2);
  }
  const Space v713_8 = join_outputs(std::move(v713_8_outputs));
  return v713_8;
}

static Space routine_82(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v722_8_branches = branches(c,s0);
  std::vector<Space> v722_8_outputs;
  v722_8_outputs.reserve(v722_8_branches.size());
  for (const auto& v722_8_branch : v722_8_branches) {
    const Path v722_8_head{v722_8_branch.first};
    const Space& v722_8_tail = v722_8_branch.second;
    const auto v723_2_branches = branches(c,v722_8_tail);
    std::vector<Space> v723_2_outputs;
    v723_2_outputs.reserve(v723_2_branches.size());
    for (const auto& v723_2_branch : v723_2_branches) {
      const Path v723_2_head{v723_2_branch.first};
      const Space& v723_2_tail = v723_2_branch.second;
      const Path v724_2 = concat_path(v722_8_head,v723_2_head);
      const auto v724_3_branches = branches(c,v723_2_tail);
      std::vector<Space> v724_3_outputs;
      v724_3_outputs.reserve(v724_3_branches.size());
      for (const auto& v724_3_branch : v724_3_branches) {
        const Path v724_3_head{v724_3_branch.first};
        const Space& v724_3_tail = v724_3_branch.second;
        const Path v725_2 = concat_path(v724_2,v724_3_head);
        const auto v725_3_branches = branches(c,v724_3_tail);
        std::vector<Space> v725_3_outputs;
        v725_3_outputs.reserve(v725_3_branches.size());
        for (const auto& v725_3_branch : v725_3_branches) {
          const Path v725_3_head{v725_3_branch.first};
          const Space& v725_3_tail = v725_3_branch.second;
          const Path v726_2 = concat_path(v725_2,v725_3_head);
          const auto v726_3_branches = branches(c,v725_3_tail);
          std::vector<Space> v726_3_outputs;
          v726_3_outputs.reserve(v726_3_branches.size());
          for (const auto& v726_3_branch : v726_3_branches) {
            const Path v726_3_head{v726_3_branch.first};
            const Space& v726_3_tail = v726_3_branch.second;
            const auto v727_2_branches = branches(c,v726_3_tail);
            std::vector<Space> v727_2_outputs;
            v727_2_outputs.reserve(v727_2_branches.size());
            for (const auto& v727_2_branch : v727_2_branches) {
              const Path v727_2_head{v727_2_branch.first};
              const Space& v727_2_tail = v727_2_branch.second;
              const Path v728_2 = concat_path(v726_3_head,v727_2_head);
              const auto v728_3_branches = branches(c,v727_2_tail);
              std::vector<Space> v728_3_outputs;
              v728_3_outputs.reserve(v728_3_branches.size());
              for (const auto& v728_3_branch : v728_3_branches) {
                const Path v728_3_head{v728_3_branch.first};
                const Space& v728_3_tail = v728_3_branch.second;
                const Path v729_2 = concat_path(v728_2,v728_3_head);
                const auto v729_3_branches = branches(c,v728_3_tail);
                std::vector<Space> v729_3_outputs;
                v729_3_outputs.reserve(v729_3_branches.size());
                for (const auto& v729_3_branch : v729_3_branches) {
                  const Path v729_3_head{v729_3_branch.first};
                  const Space& v729_3_tail = v729_3_branch.second;
                  const Path v730_2 = concat_path(v729_2,v729_3_head);
                  const Space v730_3 = routine_98(c, v730_2, p1, p2, p3, p4, p5, p6, p0, v726_2, v729_3_tail);
                  v729_3_outputs.push_back(v730_3);
                }
                const Space v729_3 = join_outputs(std::move(v729_3_outputs));
                v728_3_outputs.push_back(v729_3);
              }
              const Space v728_3 = join_outputs(std::move(v728_3_outputs));
              v727_2_outputs.push_back(v728_3);
            }
            const Space v727_2 = join_outputs(std::move(v727_2_outputs));
            v726_3_outputs.push_back(v727_2);
          }
          const Space v726_3 = join_outputs(std::move(v726_3_outputs));
          v725_3_outputs.push_back(v726_3);
        }
        const Space v725_3 = join_outputs(std::move(v725_3_outputs));
        v724_3_outputs.push_back(v725_3);
      }
      const Space v724_3 = join_outputs(std::move(v724_3_outputs));
      v723_2_outputs.push_back(v724_3);
    }
    const Space v723_2 = join_outputs(std::move(v723_2_outputs));
    v722_8_outputs.push_back(v723_2);
  }
  const Space v722_8 = join_outputs(std::move(v722_8_outputs));
  return v722_8;
}

static Space routine_83(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v731_8_branches = branches(c,s0);
  std::vector<Space> v731_8_outputs;
  v731_8_outputs.reserve(v731_8_branches.size());
  for (const auto& v731_8_branch : v731_8_branches) {
    const Path v731_8_head{v731_8_branch.first};
    const Space& v731_8_tail = v731_8_branch.second;
    const auto v732_2_branches = branches(c,v731_8_tail);
    std::vector<Space> v732_2_outputs;
    v732_2_outputs.reserve(v732_2_branches.size());
    for (const auto& v732_2_branch : v732_2_branches) {
      const Path v732_2_head{v732_2_branch.first};
      const Space& v732_2_tail = v732_2_branch.second;
      const Path v733_2 = concat_path(v731_8_head,v732_2_head);
      const auto v733_3_branches = branches(c,v732_2_tail);
      std::vector<Space> v733_3_outputs;
      v733_3_outputs.reserve(v733_3_branches.size());
      for (const auto& v733_3_branch : v733_3_branches) {
        const Path v733_3_head{v733_3_branch.first};
        const Space& v733_3_tail = v733_3_branch.second;
        const Path v734_2 = concat_path(v733_2,v733_3_head);
        const auto v734_3_branches = branches(c,v733_3_tail);
        std::vector<Space> v734_3_outputs;
        v734_3_outputs.reserve(v734_3_branches.size());
        for (const auto& v734_3_branch : v734_3_branches) {
          const Path v734_3_head{v734_3_branch.first};
          const Space& v734_3_tail = v734_3_branch.second;
          const Path v735_2 = concat_path(v734_2,v734_3_head);
          const auto v735_3_branches = branches(c,v734_3_tail);
          std::vector<Space> v735_3_outputs;
          v735_3_outputs.reserve(v735_3_branches.size());
          for (const auto& v735_3_branch : v735_3_branches) {
            const Path v735_3_head{v735_3_branch.first};
            const Space& v735_3_tail = v735_3_branch.second;
            const auto v736_2_branches = branches(c,v735_3_tail);
            std::vector<Space> v736_2_outputs;
            v736_2_outputs.reserve(v736_2_branches.size());
            for (const auto& v736_2_branch : v736_2_branches) {
              const Path v736_2_head{v736_2_branch.first};
              const Space& v736_2_tail = v736_2_branch.second;
              const Path v737_2 = concat_path(v735_3_head,v736_2_head);
              const auto v737_3_branches = branches(c,v736_2_tail);
              std::vector<Space> v737_3_outputs;
              v737_3_outputs.reserve(v737_3_branches.size());
              for (const auto& v737_3_branch : v737_3_branches) {
                const Path v737_3_head{v737_3_branch.first};
                const Space& v737_3_tail = v737_3_branch.second;
                const Path v738_2 = concat_path(v737_2,v737_3_head);
                const auto v738_3_branches = branches(c,v737_3_tail);
                std::vector<Space> v738_3_outputs;
                v738_3_outputs.reserve(v738_3_branches.size());
                for (const auto& v738_3_branch : v738_3_branches) {
                  const Path v738_3_head{v738_3_branch.first};
                  const Space& v738_3_tail = v738_3_branch.second;
                  const Path v739_2 = concat_path(v738_2,v738_3_head);
                  const Space v739_3 = routine_99(c, v739_2, p1, p2, p3, p4, p5, p6, p0, v735_2, v738_3_tail);
                  v738_3_outputs.push_back(v739_3);
                }
                const Space v738_3 = join_outputs(std::move(v738_3_outputs));
                v737_3_outputs.push_back(v738_3);
              }
              const Space v737_3 = join_outputs(std::move(v737_3_outputs));
              v736_2_outputs.push_back(v737_3);
            }
            const Space v736_2 = join_outputs(std::move(v736_2_outputs));
            v735_3_outputs.push_back(v736_2);
          }
          const Space v735_3 = join_outputs(std::move(v735_3_outputs));
          v734_3_outputs.push_back(v735_3);
        }
        const Space v734_3 = join_outputs(std::move(v734_3_outputs));
        v733_3_outputs.push_back(v734_3);
      }
      const Space v733_3 = join_outputs(std::move(v733_3_outputs));
      v732_2_outputs.push_back(v733_3);
    }
    const Space v732_2 = join_outputs(std::move(v732_2_outputs));
    v731_8_outputs.push_back(v732_2);
  }
  const Space v731_8 = join_outputs(std::move(v731_8_outputs));
  return v731_8;
}

static Space routine_84(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v740_8_branches = branches(c,s0);
  std::vector<Space> v740_8_outputs;
  v740_8_outputs.reserve(v740_8_branches.size());
  for (const auto& v740_8_branch : v740_8_branches) {
    const Path v740_8_head{v740_8_branch.first};
    const Space& v740_8_tail = v740_8_branch.second;
    const auto v741_2_branches = branches(c,v740_8_tail);
    std::vector<Space> v741_2_outputs;
    v741_2_outputs.reserve(v741_2_branches.size());
    for (const auto& v741_2_branch : v741_2_branches) {
      const Path v741_2_head{v741_2_branch.first};
      const Space& v741_2_tail = v741_2_branch.second;
      const Path v742_2 = concat_path(v740_8_head,v741_2_head);
      const auto v742_3_branches = branches(c,v741_2_tail);
      std::vector<Space> v742_3_outputs;
      v742_3_outputs.reserve(v742_3_branches.size());
      for (const auto& v742_3_branch : v742_3_branches) {
        const Path v742_3_head{v742_3_branch.first};
        const Space& v742_3_tail = v742_3_branch.second;
        const Path v743_2 = concat_path(v742_2,v742_3_head);
        const auto v743_3_branches = branches(c,v742_3_tail);
        std::vector<Space> v743_3_outputs;
        v743_3_outputs.reserve(v743_3_branches.size());
        for (const auto& v743_3_branch : v743_3_branches) {
          const Path v743_3_head{v743_3_branch.first};
          const Space& v743_3_tail = v743_3_branch.second;
          const Path v744_2 = concat_path(v743_2,v743_3_head);
          const auto v744_3_branches = branches(c,v743_3_tail);
          std::vector<Space> v744_3_outputs;
          v744_3_outputs.reserve(v744_3_branches.size());
          for (const auto& v744_3_branch : v744_3_branches) {
            const Path v744_3_head{v744_3_branch.first};
            const Space& v744_3_tail = v744_3_branch.second;
            const auto v745_2_branches = branches(c,v744_3_tail);
            std::vector<Space> v745_2_outputs;
            v745_2_outputs.reserve(v745_2_branches.size());
            for (const auto& v745_2_branch : v745_2_branches) {
              const Path v745_2_head{v745_2_branch.first};
              const Space& v745_2_tail = v745_2_branch.second;
              const Path v746_2 = concat_path(v744_3_head,v745_2_head);
              const auto v746_3_branches = branches(c,v745_2_tail);
              std::vector<Space> v746_3_outputs;
              v746_3_outputs.reserve(v746_3_branches.size());
              for (const auto& v746_3_branch : v746_3_branches) {
                const Path v746_3_head{v746_3_branch.first};
                const Space& v746_3_tail = v746_3_branch.second;
                const Path v747_2 = concat_path(v746_2,v746_3_head);
                const auto v747_3_branches = branches(c,v746_3_tail);
                std::vector<Space> v747_3_outputs;
                v747_3_outputs.reserve(v747_3_branches.size());
                for (const auto& v747_3_branch : v747_3_branches) {
                  const Path v747_3_head{v747_3_branch.first};
                  const Space& v747_3_tail = v747_3_branch.second;
                  const Path v748_2 = concat_path(v747_2,v747_3_head);
                  const Space v748_3 = routine_100(c, v748_2, p1, p2, p3, p4, p5, p6, p0, v744_2, v747_3_tail);
                  v747_3_outputs.push_back(v748_3);
                }
                const Space v747_3 = join_outputs(std::move(v747_3_outputs));
                v746_3_outputs.push_back(v747_3);
              }
              const Space v746_3 = join_outputs(std::move(v746_3_outputs));
              v745_2_outputs.push_back(v746_3);
            }
            const Space v745_2 = join_outputs(std::move(v745_2_outputs));
            v744_3_outputs.push_back(v745_2);
          }
          const Space v744_3 = join_outputs(std::move(v744_3_outputs));
          v743_3_outputs.push_back(v744_3);
        }
        const Space v743_3 = join_outputs(std::move(v743_3_outputs));
        v742_3_outputs.push_back(v743_3);
      }
      const Space v742_3 = join_outputs(std::move(v742_3_outputs));
      v741_2_outputs.push_back(v742_3);
    }
    const Space v741_2 = join_outputs(std::move(v741_2_outputs));
    v740_8_outputs.push_back(v741_2);
  }
  const Space v740_8 = join_outputs(std::move(v740_8_outputs));
  return v740_8;
}

static Space routine_85(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v749_8_branches = branches(c,s0);
  std::vector<Space> v749_8_outputs;
  v749_8_outputs.reserve(v749_8_branches.size());
  for (const auto& v749_8_branch : v749_8_branches) {
    const Path v749_8_head{v749_8_branch.first};
    const Space& v749_8_tail = v749_8_branch.second;
    const auto v750_2_branches = branches(c,v749_8_tail);
    std::vector<Space> v750_2_outputs;
    v750_2_outputs.reserve(v750_2_branches.size());
    for (const auto& v750_2_branch : v750_2_branches) {
      const Path v750_2_head{v750_2_branch.first};
      const Space& v750_2_tail = v750_2_branch.second;
      const Path v751_2 = concat_path(v749_8_head,v750_2_head);
      const auto v751_3_branches = branches(c,v750_2_tail);
      std::vector<Space> v751_3_outputs;
      v751_3_outputs.reserve(v751_3_branches.size());
      for (const auto& v751_3_branch : v751_3_branches) {
        const Path v751_3_head{v751_3_branch.first};
        const Space& v751_3_tail = v751_3_branch.second;
        const Path v752_2 = concat_path(v751_2,v751_3_head);
        const auto v752_3_branches = branches(c,v751_3_tail);
        std::vector<Space> v752_3_outputs;
        v752_3_outputs.reserve(v752_3_branches.size());
        for (const auto& v752_3_branch : v752_3_branches) {
          const Path v752_3_head{v752_3_branch.first};
          const Space& v752_3_tail = v752_3_branch.second;
          const Path v753_2 = concat_path(v752_2,v752_3_head);
          const auto v753_3_branches = branches(c,v752_3_tail);
          std::vector<Space> v753_3_outputs;
          v753_3_outputs.reserve(v753_3_branches.size());
          for (const auto& v753_3_branch : v753_3_branches) {
            const Path v753_3_head{v753_3_branch.first};
            const Space& v753_3_tail = v753_3_branch.second;
            const auto v754_2_branches = branches(c,v753_3_tail);
            std::vector<Space> v754_2_outputs;
            v754_2_outputs.reserve(v754_2_branches.size());
            for (const auto& v754_2_branch : v754_2_branches) {
              const Path v754_2_head{v754_2_branch.first};
              const Space& v754_2_tail = v754_2_branch.second;
              const Path v755_2 = concat_path(v753_3_head,v754_2_head);
              const auto v755_3_branches = branches(c,v754_2_tail);
              std::vector<Space> v755_3_outputs;
              v755_3_outputs.reserve(v755_3_branches.size());
              for (const auto& v755_3_branch : v755_3_branches) {
                const Path v755_3_head{v755_3_branch.first};
                const Space& v755_3_tail = v755_3_branch.second;
                const Path v756_2 = concat_path(v755_2,v755_3_head);
                const auto v756_3_branches = branches(c,v755_3_tail);
                std::vector<Space> v756_3_outputs;
                v756_3_outputs.reserve(v756_3_branches.size());
                for (const auto& v756_3_branch : v756_3_branches) {
                  const Path v756_3_head{v756_3_branch.first};
                  const Space& v756_3_tail = v756_3_branch.second;
                  const Path v757_2 = concat_path(v756_2,v756_3_head);
                  const Space v757_3 = routine_101(c, v757_2, p1, p2, p3, p4, p5, p6, p0, v753_2, v756_3_tail);
                  v756_3_outputs.push_back(v757_3);
                }
                const Space v756_3 = join_outputs(std::move(v756_3_outputs));
                v755_3_outputs.push_back(v756_3);
              }
              const Space v755_3 = join_outputs(std::move(v755_3_outputs));
              v754_2_outputs.push_back(v755_3);
            }
            const Space v754_2 = join_outputs(std::move(v754_2_outputs));
            v753_3_outputs.push_back(v754_2);
          }
          const Space v753_3 = join_outputs(std::move(v753_3_outputs));
          v752_3_outputs.push_back(v753_3);
        }
        const Space v752_3 = join_outputs(std::move(v752_3_outputs));
        v751_3_outputs.push_back(v752_3);
      }
      const Space v751_3 = join_outputs(std::move(v751_3_outputs));
      v750_2_outputs.push_back(v751_3);
    }
    const Space v750_2 = join_outputs(std::move(v750_2_outputs));
    v749_8_outputs.push_back(v750_2);
  }
  const Space v749_8 = join_outputs(std::move(v749_8_outputs));
  return v749_8;
}

static Space routine_86(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v758_8_branches = branches(c,s0);
  std::vector<Space> v758_8_outputs;
  v758_8_outputs.reserve(v758_8_branches.size());
  for (const auto& v758_8_branch : v758_8_branches) {
    const Path v758_8_head{v758_8_branch.first};
    const Space& v758_8_tail = v758_8_branch.second;
    const auto v759_2_branches = branches(c,v758_8_tail);
    std::vector<Space> v759_2_outputs;
    v759_2_outputs.reserve(v759_2_branches.size());
    for (const auto& v759_2_branch : v759_2_branches) {
      const Path v759_2_head{v759_2_branch.first};
      const Space& v759_2_tail = v759_2_branch.second;
      const Path v760_2 = concat_path(v758_8_head,v759_2_head);
      const auto v760_3_branches = branches(c,v759_2_tail);
      std::vector<Space> v760_3_outputs;
      v760_3_outputs.reserve(v760_3_branches.size());
      for (const auto& v760_3_branch : v760_3_branches) {
        const Path v760_3_head{v760_3_branch.first};
        const Space& v760_3_tail = v760_3_branch.second;
        const Path v761_2 = concat_path(v760_2,v760_3_head);
        const auto v761_3_branches = branches(c,v760_3_tail);
        std::vector<Space> v761_3_outputs;
        v761_3_outputs.reserve(v761_3_branches.size());
        for (const auto& v761_3_branch : v761_3_branches) {
          const Path v761_3_head{v761_3_branch.first};
          const Space& v761_3_tail = v761_3_branch.second;
          const Path v762_2 = concat_path(v761_2,v761_3_head);
          const auto v762_3_branches = branches(c,v761_3_tail);
          std::vector<Space> v762_3_outputs;
          v762_3_outputs.reserve(v762_3_branches.size());
          for (const auto& v762_3_branch : v762_3_branches) {
            const Path v762_3_head{v762_3_branch.first};
            const Space& v762_3_tail = v762_3_branch.second;
            const auto v763_2_branches = branches(c,v762_3_tail);
            std::vector<Space> v763_2_outputs;
            v763_2_outputs.reserve(v763_2_branches.size());
            for (const auto& v763_2_branch : v763_2_branches) {
              const Path v763_2_head{v763_2_branch.first};
              const Space& v763_2_tail = v763_2_branch.second;
              const Path v764_2 = concat_path(v762_3_head,v763_2_head);
              const auto v764_3_branches = branches(c,v763_2_tail);
              std::vector<Space> v764_3_outputs;
              v764_3_outputs.reserve(v764_3_branches.size());
              for (const auto& v764_3_branch : v764_3_branches) {
                const Path v764_3_head{v764_3_branch.first};
                const Space& v764_3_tail = v764_3_branch.second;
                const Path v765_2 = concat_path(v764_2,v764_3_head);
                const auto v765_3_branches = branches(c,v764_3_tail);
                std::vector<Space> v765_3_outputs;
                v765_3_outputs.reserve(v765_3_branches.size());
                for (const auto& v765_3_branch : v765_3_branches) {
                  const Path v765_3_head{v765_3_branch.first};
                  const Space& v765_3_tail = v765_3_branch.second;
                  const Path v766_2 = concat_path(v765_2,v765_3_head);
                  const Space v766_3 = routine_102(c, v766_2, p1, p2, p3, p4, p5, p6, p0, v762_2, v765_3_tail);
                  v765_3_outputs.push_back(v766_3);
                }
                const Space v765_3 = join_outputs(std::move(v765_3_outputs));
                v764_3_outputs.push_back(v765_3);
              }
              const Space v764_3 = join_outputs(std::move(v764_3_outputs));
              v763_2_outputs.push_back(v764_3);
            }
            const Space v763_2 = join_outputs(std::move(v763_2_outputs));
            v762_3_outputs.push_back(v763_2);
          }
          const Space v762_3 = join_outputs(std::move(v762_3_outputs));
          v761_3_outputs.push_back(v762_3);
        }
        const Space v761_3 = join_outputs(std::move(v761_3_outputs));
        v760_3_outputs.push_back(v761_3);
      }
      const Space v760_3 = join_outputs(std::move(v760_3_outputs));
      v759_2_outputs.push_back(v760_3);
    }
    const Space v759_2 = join_outputs(std::move(v759_2_outputs));
    v758_8_outputs.push_back(v759_2);
  }
  const Space v758_8 = join_outputs(std::move(v758_8_outputs));
  return v758_8;
}

static Space routine_87(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v767_8_branches = branches(c,s0);
  std::vector<Space> v767_8_outputs;
  v767_8_outputs.reserve(v767_8_branches.size());
  for (const auto& v767_8_branch : v767_8_branches) {
    const Path v767_8_head{v767_8_branch.first};
    const Space& v767_8_tail = v767_8_branch.second;
    const auto v768_2_branches = branches(c,v767_8_tail);
    std::vector<Space> v768_2_outputs;
    v768_2_outputs.reserve(v768_2_branches.size());
    for (const auto& v768_2_branch : v768_2_branches) {
      const Path v768_2_head{v768_2_branch.first};
      const Space& v768_2_tail = v768_2_branch.second;
      const Path v769_2 = concat_path(v767_8_head,v768_2_head);
      const auto v769_3_branches = branches(c,v768_2_tail);
      std::vector<Space> v769_3_outputs;
      v769_3_outputs.reserve(v769_3_branches.size());
      for (const auto& v769_3_branch : v769_3_branches) {
        const Path v769_3_head{v769_3_branch.first};
        const Space& v769_3_tail = v769_3_branch.second;
        const Path v770_2 = concat_path(v769_2,v769_3_head);
        const auto v770_3_branches = branches(c,v769_3_tail);
        std::vector<Space> v770_3_outputs;
        v770_3_outputs.reserve(v770_3_branches.size());
        for (const auto& v770_3_branch : v770_3_branches) {
          const Path v770_3_head{v770_3_branch.first};
          const Space& v770_3_tail = v770_3_branch.second;
          const Path v771_2 = concat_path(v770_2,v770_3_head);
          const auto v771_3_branches = branches(c,v770_3_tail);
          std::vector<Space> v771_3_outputs;
          v771_3_outputs.reserve(v771_3_branches.size());
          for (const auto& v771_3_branch : v771_3_branches) {
            const Path v771_3_head{v771_3_branch.first};
            const Space& v771_3_tail = v771_3_branch.second;
            const auto v772_2_branches = branches(c,v771_3_tail);
            std::vector<Space> v772_2_outputs;
            v772_2_outputs.reserve(v772_2_branches.size());
            for (const auto& v772_2_branch : v772_2_branches) {
              const Path v772_2_head{v772_2_branch.first};
              const Space& v772_2_tail = v772_2_branch.second;
              const Path v773_2 = concat_path(v771_3_head,v772_2_head);
              const auto v773_3_branches = branches(c,v772_2_tail);
              std::vector<Space> v773_3_outputs;
              v773_3_outputs.reserve(v773_3_branches.size());
              for (const auto& v773_3_branch : v773_3_branches) {
                const Path v773_3_head{v773_3_branch.first};
                const Space& v773_3_tail = v773_3_branch.second;
                const Path v774_2 = concat_path(v773_2,v773_3_head);
                const auto v774_3_branches = branches(c,v773_3_tail);
                std::vector<Space> v774_3_outputs;
                v774_3_outputs.reserve(v774_3_branches.size());
                for (const auto& v774_3_branch : v774_3_branches) {
                  const Path v774_3_head{v774_3_branch.first};
                  const Space& v774_3_tail = v774_3_branch.second;
                  const Path v775_2 = concat_path(v774_2,v774_3_head);
                  const Space v775_3 = routine_103(c, v775_2, p1, p2, p3, p4, p5, p6, p0, v771_2, v774_3_tail);
                  v774_3_outputs.push_back(v775_3);
                }
                const Space v774_3 = join_outputs(std::move(v774_3_outputs));
                v773_3_outputs.push_back(v774_3);
              }
              const Space v773_3 = join_outputs(std::move(v773_3_outputs));
              v772_2_outputs.push_back(v773_3);
            }
            const Space v772_2 = join_outputs(std::move(v772_2_outputs));
            v771_3_outputs.push_back(v772_2);
          }
          const Space v771_3 = join_outputs(std::move(v771_3_outputs));
          v770_3_outputs.push_back(v771_3);
        }
        const Space v770_3 = join_outputs(std::move(v770_3_outputs));
        v769_3_outputs.push_back(v770_3);
      }
      const Space v769_3 = join_outputs(std::move(v769_3_outputs));
      v768_2_outputs.push_back(v769_3);
    }
    const Space v768_2 = join_outputs(std::move(v768_2_outputs));
    v767_8_outputs.push_back(v768_2);
  }
  const Space v767_8 = join_outputs(std::move(v767_8_outputs));
  return v767_8;
}

static Space routine_88(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v776_8_branches = branches(c,s0);
  std::vector<Space> v776_8_outputs;
  v776_8_outputs.reserve(v776_8_branches.size());
  for (const auto& v776_8_branch : v776_8_branches) {
    const Path v776_8_head{v776_8_branch.first};
    const Space& v776_8_tail = v776_8_branch.second;
    const auto v777_2_branches = branches(c,v776_8_tail);
    std::vector<Space> v777_2_outputs;
    v777_2_outputs.reserve(v777_2_branches.size());
    for (const auto& v777_2_branch : v777_2_branches) {
      const Path v777_2_head{v777_2_branch.first};
      const Space& v777_2_tail = v777_2_branch.second;
      const Path v778_2 = concat_path(v776_8_head,v777_2_head);
      const auto v778_3_branches = branches(c,v777_2_tail);
      std::vector<Space> v778_3_outputs;
      v778_3_outputs.reserve(v778_3_branches.size());
      for (const auto& v778_3_branch : v778_3_branches) {
        const Path v778_3_head{v778_3_branch.first};
        const Space& v778_3_tail = v778_3_branch.second;
        const Path v779_2 = concat_path(v778_2,v778_3_head);
        const auto v779_3_branches = branches(c,v778_3_tail);
        std::vector<Space> v779_3_outputs;
        v779_3_outputs.reserve(v779_3_branches.size());
        for (const auto& v779_3_branch : v779_3_branches) {
          const Path v779_3_head{v779_3_branch.first};
          const Space& v779_3_tail = v779_3_branch.second;
          const Path v780_2 = concat_path(v779_2,v779_3_head);
          const auto v780_3_branches = branches(c,v779_3_tail);
          std::vector<Space> v780_3_outputs;
          v780_3_outputs.reserve(v780_3_branches.size());
          for (const auto& v780_3_branch : v780_3_branches) {
            const Path v780_3_head{v780_3_branch.first};
            const Space& v780_3_tail = v780_3_branch.second;
            const auto v781_2_branches = branches(c,v780_3_tail);
            std::vector<Space> v781_2_outputs;
            v781_2_outputs.reserve(v781_2_branches.size());
            for (const auto& v781_2_branch : v781_2_branches) {
              const Path v781_2_head{v781_2_branch.first};
              const Space& v781_2_tail = v781_2_branch.second;
              const Path v782_2 = concat_path(v780_3_head,v781_2_head);
              const auto v782_3_branches = branches(c,v781_2_tail);
              std::vector<Space> v782_3_outputs;
              v782_3_outputs.reserve(v782_3_branches.size());
              for (const auto& v782_3_branch : v782_3_branches) {
                const Path v782_3_head{v782_3_branch.first};
                const Space& v782_3_tail = v782_3_branch.second;
                const Path v783_2 = concat_path(v782_2,v782_3_head);
                const auto v783_3_branches = branches(c,v782_3_tail);
                std::vector<Space> v783_3_outputs;
                v783_3_outputs.reserve(v783_3_branches.size());
                for (const auto& v783_3_branch : v783_3_branches) {
                  const Path v783_3_head{v783_3_branch.first};
                  const Space& v783_3_tail = v783_3_branch.second;
                  const Path v784_2 = concat_path(v783_2,v783_3_head);
                  const Space v784_3 = routine_104(c, v784_2, p1, p2, p3, p4, p5, p6, p0, v780_2, v783_3_tail);
                  v783_3_outputs.push_back(v784_3);
                }
                const Space v783_3 = join_outputs(std::move(v783_3_outputs));
                v782_3_outputs.push_back(v783_3);
              }
              const Space v782_3 = join_outputs(std::move(v782_3_outputs));
              v781_2_outputs.push_back(v782_3);
            }
            const Space v781_2 = join_outputs(std::move(v781_2_outputs));
            v780_3_outputs.push_back(v781_2);
          }
          const Space v780_3 = join_outputs(std::move(v780_3_outputs));
          v779_3_outputs.push_back(v780_3);
        }
        const Space v779_3 = join_outputs(std::move(v779_3_outputs));
        v778_3_outputs.push_back(v779_3);
      }
      const Space v778_3 = join_outputs(std::move(v778_3_outputs));
      v777_2_outputs.push_back(v778_3);
    }
    const Space v777_2 = join_outputs(std::move(v777_2_outputs));
    v776_8_outputs.push_back(v777_2);
  }
  const Space v776_8 = join_outputs(std::move(v776_8_outputs));
  return v776_8;
}

static Space routine_89(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v785_8_branches = branches(c,s0);
  std::vector<Space> v785_8_outputs;
  v785_8_outputs.reserve(v785_8_branches.size());
  for (const auto& v785_8_branch : v785_8_branches) {
    const Path v785_8_head{v785_8_branch.first};
    const Space& v785_8_tail = v785_8_branch.second;
    const auto v786_2_branches = branches(c,v785_8_tail);
    std::vector<Space> v786_2_outputs;
    v786_2_outputs.reserve(v786_2_branches.size());
    for (const auto& v786_2_branch : v786_2_branches) {
      const Path v786_2_head{v786_2_branch.first};
      const Space& v786_2_tail = v786_2_branch.second;
      const Path v787_2 = concat_path(v785_8_head,v786_2_head);
      const auto v787_3_branches = branches(c,v786_2_tail);
      std::vector<Space> v787_3_outputs;
      v787_3_outputs.reserve(v787_3_branches.size());
      for (const auto& v787_3_branch : v787_3_branches) {
        const Path v787_3_head{v787_3_branch.first};
        const Space& v787_3_tail = v787_3_branch.second;
        const Path v788_2 = concat_path(v787_2,v787_3_head);
        const auto v788_3_branches = branches(c,v787_3_tail);
        std::vector<Space> v788_3_outputs;
        v788_3_outputs.reserve(v788_3_branches.size());
        for (const auto& v788_3_branch : v788_3_branches) {
          const Path v788_3_head{v788_3_branch.first};
          const Space& v788_3_tail = v788_3_branch.second;
          const Path v789_2 = concat_path(v788_2,v788_3_head);
          const auto v789_3_branches = branches(c,v788_3_tail);
          std::vector<Space> v789_3_outputs;
          v789_3_outputs.reserve(v789_3_branches.size());
          for (const auto& v789_3_branch : v789_3_branches) {
            const Path v789_3_head{v789_3_branch.first};
            const Space& v789_3_tail = v789_3_branch.second;
            const auto v790_2_branches = branches(c,v789_3_tail);
            std::vector<Space> v790_2_outputs;
            v790_2_outputs.reserve(v790_2_branches.size());
            for (const auto& v790_2_branch : v790_2_branches) {
              const Path v790_2_head{v790_2_branch.first};
              const Space& v790_2_tail = v790_2_branch.second;
              const Path v791_2 = concat_path(v789_3_head,v790_2_head);
              const auto v791_3_branches = branches(c,v790_2_tail);
              std::vector<Space> v791_3_outputs;
              v791_3_outputs.reserve(v791_3_branches.size());
              for (const auto& v791_3_branch : v791_3_branches) {
                const Path v791_3_head{v791_3_branch.first};
                const Space& v791_3_tail = v791_3_branch.second;
                const Path v792_2 = concat_path(v791_2,v791_3_head);
                const auto v792_3_branches = branches(c,v791_3_tail);
                std::vector<Space> v792_3_outputs;
                v792_3_outputs.reserve(v792_3_branches.size());
                for (const auto& v792_3_branch : v792_3_branches) {
                  const Path v792_3_head{v792_3_branch.first};
                  const Space& v792_3_tail = v792_3_branch.second;
                  const Path v793_2 = concat_path(v792_2,v792_3_head);
                  const Space v793_3 = routine_105(c, v793_2, p1, p2, p3, p4, p5, p6, p0, v789_2, v792_3_tail);
                  v792_3_outputs.push_back(v793_3);
                }
                const Space v792_3 = join_outputs(std::move(v792_3_outputs));
                v791_3_outputs.push_back(v792_3);
              }
              const Space v791_3 = join_outputs(std::move(v791_3_outputs));
              v790_2_outputs.push_back(v791_3);
            }
            const Space v790_2 = join_outputs(std::move(v790_2_outputs));
            v789_3_outputs.push_back(v790_2);
          }
          const Space v789_3 = join_outputs(std::move(v789_3_outputs));
          v788_3_outputs.push_back(v789_3);
        }
        const Space v788_3 = join_outputs(std::move(v788_3_outputs));
        v787_3_outputs.push_back(v788_3);
      }
      const Space v787_3 = join_outputs(std::move(v787_3_outputs));
      v786_2_outputs.push_back(v787_3);
    }
    const Space v786_2 = join_outputs(std::move(v786_2_outputs));
    v785_8_outputs.push_back(v786_2);
  }
  const Space v785_8 = join_outputs(std::move(v785_8_outputs));
  return v785_8;
}

static Space routine_90(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v794_8_branches = branches(c,s0);
  std::vector<Space> v794_8_outputs;
  v794_8_outputs.reserve(v794_8_branches.size());
  for (const auto& v794_8_branch : v794_8_branches) {
    const Path v794_8_head{v794_8_branch.first};
    const Space& v794_8_tail = v794_8_branch.second;
    const auto v795_2_branches = branches(c,v794_8_tail);
    std::vector<Space> v795_2_outputs;
    v795_2_outputs.reserve(v795_2_branches.size());
    for (const auto& v795_2_branch : v795_2_branches) {
      const Path v795_2_head{v795_2_branch.first};
      const Space& v795_2_tail = v795_2_branch.second;
      const Path v796_2 = concat_path(v794_8_head,v795_2_head);
      const auto v796_3_branches = branches(c,v795_2_tail);
      std::vector<Space> v796_3_outputs;
      v796_3_outputs.reserve(v796_3_branches.size());
      for (const auto& v796_3_branch : v796_3_branches) {
        const Path v796_3_head{v796_3_branch.first};
        const Space& v796_3_tail = v796_3_branch.second;
        const Path v797_2 = concat_path(v796_2,v796_3_head);
        const auto v797_3_branches = branches(c,v796_3_tail);
        std::vector<Space> v797_3_outputs;
        v797_3_outputs.reserve(v797_3_branches.size());
        for (const auto& v797_3_branch : v797_3_branches) {
          const Path v797_3_head{v797_3_branch.first};
          const Space& v797_3_tail = v797_3_branch.second;
          const Path v798_2 = concat_path(v797_2,v797_3_head);
          const auto v798_3_branches = branches(c,v797_3_tail);
          std::vector<Space> v798_3_outputs;
          v798_3_outputs.reserve(v798_3_branches.size());
          for (const auto& v798_3_branch : v798_3_branches) {
            const Path v798_3_head{v798_3_branch.first};
            const Space& v798_3_tail = v798_3_branch.second;
            const auto v799_2_branches = branches(c,v798_3_tail);
            std::vector<Space> v799_2_outputs;
            v799_2_outputs.reserve(v799_2_branches.size());
            for (const auto& v799_2_branch : v799_2_branches) {
              const Path v799_2_head{v799_2_branch.first};
              const Space& v799_2_tail = v799_2_branch.second;
              const Path v800_2 = concat_path(v798_3_head,v799_2_head);
              const auto v800_3_branches = branches(c,v799_2_tail);
              std::vector<Space> v800_3_outputs;
              v800_3_outputs.reserve(v800_3_branches.size());
              for (const auto& v800_3_branch : v800_3_branches) {
                const Path v800_3_head{v800_3_branch.first};
                const Space& v800_3_tail = v800_3_branch.second;
                const Path v801_2 = concat_path(v800_2,v800_3_head);
                const auto v801_3_branches = branches(c,v800_3_tail);
                std::vector<Space> v801_3_outputs;
                v801_3_outputs.reserve(v801_3_branches.size());
                for (const auto& v801_3_branch : v801_3_branches) {
                  const Path v801_3_head{v801_3_branch.first};
                  const Space& v801_3_tail = v801_3_branch.second;
                  const Path v802_2 = concat_path(v801_2,v801_3_head);
                  const Space v802_3 = routine_106(c, v802_2, p1, p2, p3, p4, p5, p6, p0, v798_2, v801_3_tail);
                  v801_3_outputs.push_back(v802_3);
                }
                const Space v801_3 = join_outputs(std::move(v801_3_outputs));
                v800_3_outputs.push_back(v801_3);
              }
              const Space v800_3 = join_outputs(std::move(v800_3_outputs));
              v799_2_outputs.push_back(v800_3);
            }
            const Space v799_2 = join_outputs(std::move(v799_2_outputs));
            v798_3_outputs.push_back(v799_2);
          }
          const Space v798_3 = join_outputs(std::move(v798_3_outputs));
          v797_3_outputs.push_back(v798_3);
        }
        const Space v797_3 = join_outputs(std::move(v797_3_outputs));
        v796_3_outputs.push_back(v797_3);
      }
      const Space v796_3 = join_outputs(std::move(v796_3_outputs));
      v795_2_outputs.push_back(v796_3);
    }
    const Space v795_2 = join_outputs(std::move(v795_2_outputs));
    v794_8_outputs.push_back(v795_2);
  }
  const Space v794_8 = join_outputs(std::move(v794_8_outputs));
  return v794_8;
}

static Space routine_91(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v803_8_branches = branches(c,s0);
  std::vector<Space> v803_8_outputs;
  v803_8_outputs.reserve(v803_8_branches.size());
  for (const auto& v803_8_branch : v803_8_branches) {
    const Path v803_8_head{v803_8_branch.first};
    const Space& v803_8_tail = v803_8_branch.second;
    const auto v804_2_branches = branches(c,v803_8_tail);
    std::vector<Space> v804_2_outputs;
    v804_2_outputs.reserve(v804_2_branches.size());
    for (const auto& v804_2_branch : v804_2_branches) {
      const Path v804_2_head{v804_2_branch.first};
      const Space& v804_2_tail = v804_2_branch.second;
      const Path v805_2 = concat_path(v803_8_head,v804_2_head);
      const auto v805_3_branches = branches(c,v804_2_tail);
      std::vector<Space> v805_3_outputs;
      v805_3_outputs.reserve(v805_3_branches.size());
      for (const auto& v805_3_branch : v805_3_branches) {
        const Path v805_3_head{v805_3_branch.first};
        const Space& v805_3_tail = v805_3_branch.second;
        const Path v806_2 = concat_path(v805_2,v805_3_head);
        const auto v806_3_branches = branches(c,v805_3_tail);
        std::vector<Space> v806_3_outputs;
        v806_3_outputs.reserve(v806_3_branches.size());
        for (const auto& v806_3_branch : v806_3_branches) {
          const Path v806_3_head{v806_3_branch.first};
          const Space& v806_3_tail = v806_3_branch.second;
          const Path v807_2 = concat_path(v806_2,v806_3_head);
          const auto v807_3_branches = branches(c,v806_3_tail);
          std::vector<Space> v807_3_outputs;
          v807_3_outputs.reserve(v807_3_branches.size());
          for (const auto& v807_3_branch : v807_3_branches) {
            const Path v807_3_head{v807_3_branch.first};
            const Space& v807_3_tail = v807_3_branch.second;
            const auto v808_2_branches = branches(c,v807_3_tail);
            std::vector<Space> v808_2_outputs;
            v808_2_outputs.reserve(v808_2_branches.size());
            for (const auto& v808_2_branch : v808_2_branches) {
              const Path v808_2_head{v808_2_branch.first};
              const Space& v808_2_tail = v808_2_branch.second;
              const Path v809_2 = concat_path(v807_3_head,v808_2_head);
              const auto v809_3_branches = branches(c,v808_2_tail);
              std::vector<Space> v809_3_outputs;
              v809_3_outputs.reserve(v809_3_branches.size());
              for (const auto& v809_3_branch : v809_3_branches) {
                const Path v809_3_head{v809_3_branch.first};
                const Space& v809_3_tail = v809_3_branch.second;
                const Path v810_2 = concat_path(v809_2,v809_3_head);
                const auto v810_3_branches = branches(c,v809_3_tail);
                std::vector<Space> v810_3_outputs;
                v810_3_outputs.reserve(v810_3_branches.size());
                for (const auto& v810_3_branch : v810_3_branches) {
                  const Path v810_3_head{v810_3_branch.first};
                  const Space& v810_3_tail = v810_3_branch.second;
                  const Path v811_2 = concat_path(v810_2,v810_3_head);
                  const Space v811_3 = routine_107(c, v811_2, p1, p2, p3, p4, p5, p6, p0, v807_2, v810_3_tail);
                  v810_3_outputs.push_back(v811_3);
                }
                const Space v810_3 = join_outputs(std::move(v810_3_outputs));
                v809_3_outputs.push_back(v810_3);
              }
              const Space v809_3 = join_outputs(std::move(v809_3_outputs));
              v808_2_outputs.push_back(v809_3);
            }
            const Space v808_2 = join_outputs(std::move(v808_2_outputs));
            v807_3_outputs.push_back(v808_2);
          }
          const Space v807_3 = join_outputs(std::move(v807_3_outputs));
          v806_3_outputs.push_back(v807_3);
        }
        const Space v806_3 = join_outputs(std::move(v806_3_outputs));
        v805_3_outputs.push_back(v806_3);
      }
      const Space v805_3 = join_outputs(std::move(v805_3_outputs));
      v804_2_outputs.push_back(v805_3);
    }
    const Space v804_2 = join_outputs(std::move(v804_2_outputs));
    v803_8_outputs.push_back(v804_2);
  }
  const Space v803_8 = join_outputs(std::move(v803_8_outputs));
  return v803_8;
}

static Space routine_92(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v812_8_branches = branches(c,s0);
  std::vector<Space> v812_8_outputs;
  v812_8_outputs.reserve(v812_8_branches.size());
  for (const auto& v812_8_branch : v812_8_branches) {
    const Path v812_8_head{v812_8_branch.first};
    const Space& v812_8_tail = v812_8_branch.second;
    const auto v813_2_branches = branches(c,v812_8_tail);
    std::vector<Space> v813_2_outputs;
    v813_2_outputs.reserve(v813_2_branches.size());
    for (const auto& v813_2_branch : v813_2_branches) {
      const Path v813_2_head{v813_2_branch.first};
      const Space& v813_2_tail = v813_2_branch.second;
      const Path v814_2 = concat_path(v812_8_head,v813_2_head);
      const auto v814_3_branches = branches(c,v813_2_tail);
      std::vector<Space> v814_3_outputs;
      v814_3_outputs.reserve(v814_3_branches.size());
      for (const auto& v814_3_branch : v814_3_branches) {
        const Path v814_3_head{v814_3_branch.first};
        const Space& v814_3_tail = v814_3_branch.second;
        const Path v815_2 = concat_path(v814_2,v814_3_head);
        const auto v815_3_branches = branches(c,v814_3_tail);
        std::vector<Space> v815_3_outputs;
        v815_3_outputs.reserve(v815_3_branches.size());
        for (const auto& v815_3_branch : v815_3_branches) {
          const Path v815_3_head{v815_3_branch.first};
          const Space& v815_3_tail = v815_3_branch.second;
          const Path v816_2 = concat_path(v815_2,v815_3_head);
          const auto v816_3_branches = branches(c,v815_3_tail);
          std::vector<Space> v816_3_outputs;
          v816_3_outputs.reserve(v816_3_branches.size());
          for (const auto& v816_3_branch : v816_3_branches) {
            const Path v816_3_head{v816_3_branch.first};
            const Space& v816_3_tail = v816_3_branch.second;
            const auto v817_2_branches = branches(c,v816_3_tail);
            std::vector<Space> v817_2_outputs;
            v817_2_outputs.reserve(v817_2_branches.size());
            for (const auto& v817_2_branch : v817_2_branches) {
              const Path v817_2_head{v817_2_branch.first};
              const Space& v817_2_tail = v817_2_branch.second;
              const Path v818_2 = concat_path(v816_3_head,v817_2_head);
              const auto v818_3_branches = branches(c,v817_2_tail);
              std::vector<Space> v818_3_outputs;
              v818_3_outputs.reserve(v818_3_branches.size());
              for (const auto& v818_3_branch : v818_3_branches) {
                const Path v818_3_head{v818_3_branch.first};
                const Space& v818_3_tail = v818_3_branch.second;
                const Path v819_2 = concat_path(v818_2,v818_3_head);
                const auto v819_3_branches = branches(c,v818_3_tail);
                std::vector<Space> v819_3_outputs;
                v819_3_outputs.reserve(v819_3_branches.size());
                for (const auto& v819_3_branch : v819_3_branches) {
                  const Path v819_3_head{v819_3_branch.first};
                  const Space& v819_3_tail = v819_3_branch.second;
                  const Path v820_2 = concat_path(v819_2,v819_3_head);
                  const Space v820_3 = routine_108(c, v820_2, p1, p2, p3, p4, p5, p6, p0, v816_2, v819_3_tail);
                  v819_3_outputs.push_back(v820_3);
                }
                const Space v819_3 = join_outputs(std::move(v819_3_outputs));
                v818_3_outputs.push_back(v819_3);
              }
              const Space v818_3 = join_outputs(std::move(v818_3_outputs));
              v817_2_outputs.push_back(v818_3);
            }
            const Space v817_2 = join_outputs(std::move(v817_2_outputs));
            v816_3_outputs.push_back(v817_2);
          }
          const Space v816_3 = join_outputs(std::move(v816_3_outputs));
          v815_3_outputs.push_back(v816_3);
        }
        const Space v815_3 = join_outputs(std::move(v815_3_outputs));
        v814_3_outputs.push_back(v815_3);
      }
      const Space v814_3 = join_outputs(std::move(v814_3_outputs));
      v813_2_outputs.push_back(v814_3);
    }
    const Space v813_2 = join_outputs(std::move(v813_2_outputs));
    v812_8_outputs.push_back(v813_2);
  }
  const Space v812_8 = join_outputs(std::move(v812_8_outputs));
  return v812_8;
}

static Space routine_93(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v821_8_branches = branches(c,s0);
  std::vector<Space> v821_8_outputs;
  v821_8_outputs.reserve(v821_8_branches.size());
  for (const auto& v821_8_branch : v821_8_branches) {
    const Path v821_8_head{v821_8_branch.first};
    const Space& v821_8_tail = v821_8_branch.second;
    const auto v822_2_branches = branches(c,v821_8_tail);
    std::vector<Space> v822_2_outputs;
    v822_2_outputs.reserve(v822_2_branches.size());
    for (const auto& v822_2_branch : v822_2_branches) {
      const Path v822_2_head{v822_2_branch.first};
      const Space& v822_2_tail = v822_2_branch.second;
      const Path v823_2 = concat_path(v821_8_head,v822_2_head);
      const auto v823_3_branches = branches(c,v822_2_tail);
      std::vector<Space> v823_3_outputs;
      v823_3_outputs.reserve(v823_3_branches.size());
      for (const auto& v823_3_branch : v823_3_branches) {
        const Path v823_3_head{v823_3_branch.first};
        const Space& v823_3_tail = v823_3_branch.second;
        const Path v824_2 = concat_path(v823_2,v823_3_head);
        const auto v824_3_branches = branches(c,v823_3_tail);
        std::vector<Space> v824_3_outputs;
        v824_3_outputs.reserve(v824_3_branches.size());
        for (const auto& v824_3_branch : v824_3_branches) {
          const Path v824_3_head{v824_3_branch.first};
          const Space& v824_3_tail = v824_3_branch.second;
          const Path v825_2 = concat_path(v824_2,v824_3_head);
          const auto v825_3_branches = branches(c,v824_3_tail);
          std::vector<Space> v825_3_outputs;
          v825_3_outputs.reserve(v825_3_branches.size());
          for (const auto& v825_3_branch : v825_3_branches) {
            const Path v825_3_head{v825_3_branch.first};
            const Space& v825_3_tail = v825_3_branch.second;
            const auto v826_2_branches = branches(c,v825_3_tail);
            std::vector<Space> v826_2_outputs;
            v826_2_outputs.reserve(v826_2_branches.size());
            for (const auto& v826_2_branch : v826_2_branches) {
              const Path v826_2_head{v826_2_branch.first};
              const Space& v826_2_tail = v826_2_branch.second;
              const Path v827_2 = concat_path(v825_3_head,v826_2_head);
              const auto v827_3_branches = branches(c,v826_2_tail);
              std::vector<Space> v827_3_outputs;
              v827_3_outputs.reserve(v827_3_branches.size());
              for (const auto& v827_3_branch : v827_3_branches) {
                const Path v827_3_head{v827_3_branch.first};
                const Space& v827_3_tail = v827_3_branch.second;
                const Path v828_2 = concat_path(v827_2,v827_3_head);
                const auto v828_3_branches = branches(c,v827_3_tail);
                std::vector<Space> v828_3_outputs;
                v828_3_outputs.reserve(v828_3_branches.size());
                for (const auto& v828_3_branch : v828_3_branches) {
                  const Path v828_3_head{v828_3_branch.first};
                  const Space& v828_3_tail = v828_3_branch.second;
                  const Path v829_2 = concat_path(v828_2,v828_3_head);
                  const Space v829_3 = routine_109(c, v829_2, p1, p2, p3, p4, p5, p6, p0, v825_2, v828_3_tail);
                  v828_3_outputs.push_back(v829_3);
                }
                const Space v828_3 = join_outputs(std::move(v828_3_outputs));
                v827_3_outputs.push_back(v828_3);
              }
              const Space v827_3 = join_outputs(std::move(v827_3_outputs));
              v826_2_outputs.push_back(v827_3);
            }
            const Space v826_2 = join_outputs(std::move(v826_2_outputs));
            v825_3_outputs.push_back(v826_2);
          }
          const Space v825_3 = join_outputs(std::move(v825_3_outputs));
          v824_3_outputs.push_back(v825_3);
        }
        const Space v824_3 = join_outputs(std::move(v824_3_outputs));
        v823_3_outputs.push_back(v824_3);
      }
      const Space v823_3 = join_outputs(std::move(v823_3_outputs));
      v822_2_outputs.push_back(v823_3);
    }
    const Space v822_2 = join_outputs(std::move(v822_2_outputs));
    v821_8_outputs.push_back(v822_2);
  }
  const Space v821_8 = join_outputs(std::move(v821_8_outputs));
  return v821_8;
}

static Space routine_94(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Space& s0) {
  const auto v830_8_branches = branches(c,s0);
  std::vector<Space> v830_8_outputs;
  v830_8_outputs.reserve(v830_8_branches.size());
  for (const auto& v830_8_branch : v830_8_branches) {
    const Path v830_8_head{v830_8_branch.first};
    const Space& v830_8_tail = v830_8_branch.second;
    const auto v831_2_branches = branches(c,v830_8_tail);
    std::vector<Space> v831_2_outputs;
    v831_2_outputs.reserve(v831_2_branches.size());
    for (const auto& v831_2_branch : v831_2_branches) {
      const Path v831_2_head{v831_2_branch.first};
      const Space& v831_2_tail = v831_2_branch.second;
      const Path v832_2 = concat_path(v830_8_head,v831_2_head);
      const auto v832_3_branches = branches(c,v831_2_tail);
      std::vector<Space> v832_3_outputs;
      v832_3_outputs.reserve(v832_3_branches.size());
      for (const auto& v832_3_branch : v832_3_branches) {
        const Path v832_3_head{v832_3_branch.first};
        const Space& v832_3_tail = v832_3_branch.second;
        const Path v833_2 = concat_path(v832_2,v832_3_head);
        const auto v833_3_branches = branches(c,v832_3_tail);
        std::vector<Space> v833_3_outputs;
        v833_3_outputs.reserve(v833_3_branches.size());
        for (const auto& v833_3_branch : v833_3_branches) {
          const Path v833_3_head{v833_3_branch.first};
          const Space& v833_3_tail = v833_3_branch.second;
          const Path v834_2 = concat_path(v833_2,v833_3_head);
          const auto v834_3_branches = branches(c,v833_3_tail);
          std::vector<Space> v834_3_outputs;
          v834_3_outputs.reserve(v834_3_branches.size());
          for (const auto& v834_3_branch : v834_3_branches) {
            const Path v834_3_head{v834_3_branch.first};
            const Space& v834_3_tail = v834_3_branch.second;
            const auto v835_2_branches = branches(c,v834_3_tail);
            std::vector<Space> v835_2_outputs;
            v835_2_outputs.reserve(v835_2_branches.size());
            for (const auto& v835_2_branch : v835_2_branches) {
              const Path v835_2_head{v835_2_branch.first};
              const Space& v835_2_tail = v835_2_branch.second;
              const Path v836_2 = concat_path(v834_3_head,v835_2_head);
              const auto v836_3_branches = branches(c,v835_2_tail);
              std::vector<Space> v836_3_outputs;
              v836_3_outputs.reserve(v836_3_branches.size());
              for (const auto& v836_3_branch : v836_3_branches) {
                const Path v836_3_head{v836_3_branch.first};
                const Space& v836_3_tail = v836_3_branch.second;
                const Path v837_2 = concat_path(v836_2,v836_3_head);
                const auto v837_3_branches = branches(c,v836_3_tail);
                std::vector<Space> v837_3_outputs;
                v837_3_outputs.reserve(v837_3_branches.size());
                for (const auto& v837_3_branch : v837_3_branches) {
                  const Path v837_3_head{v837_3_branch.first};
                  const Space& v837_3_tail = v837_3_branch.second;
                  const Path v838_2 = concat_path(v837_2,v837_3_head);
                  const Space v838_3 = routine_110(c, v838_2, p1, p2, p3, p4, p5, p6, p0, v834_2, v837_3_tail);
                  v837_3_outputs.push_back(v838_3);
                }
                const Space v837_3 = join_outputs(std::move(v837_3_outputs));
                v836_3_outputs.push_back(v837_3);
              }
              const Space v836_3 = join_outputs(std::move(v836_3_outputs));
              v835_2_outputs.push_back(v836_3);
            }
            const Space v835_2 = join_outputs(std::move(v835_2_outputs));
            v834_3_outputs.push_back(v835_2);
          }
          const Space v834_3 = join_outputs(std::move(v834_3_outputs));
          v833_3_outputs.push_back(v834_3);
        }
        const Space v833_3 = join_outputs(std::move(v833_3_outputs));
        v832_3_outputs.push_back(v833_3);
      }
      const Space v832_3 = join_outputs(std::move(v832_3_outputs));
      v831_2_outputs.push_back(v832_3);
    }
    const Space v831_2 = join_outputs(std::move(v831_2_outputs));
    v830_8_outputs.push_back(v831_2);
  }
  const Space v830_8 = join_outputs(std::move(v830_8_outputs));
  return v830_8;
}

static Space routine_95(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v839_10_branches = branches(c,s0);
  std::vector<Space> v839_10_outputs;
  v839_10_outputs.reserve(v839_10_branches.size());
  for (const auto& v839_10_branch : v839_10_branches) {
    const Path v839_10_head{v839_10_branch.first};
    const Space& v839_10_tail = v839_10_branch.second;
    const auto v840_2_branches = branches(c,v839_10_tail);
    std::vector<Space> v840_2_outputs;
    v840_2_outputs.reserve(v840_2_branches.size());
    for (const auto& v840_2_branch : v840_2_branches) {
      const Path v840_2_head{v840_2_branch.first};
      const Space& v840_2_tail = v840_2_branch.second;
      const Path v841_2 = concat_path(v839_10_head,v840_2_head);
      const auto v841_3_branches = branches(c,v840_2_tail);
      std::vector<Space> v841_3_outputs;
      v841_3_outputs.reserve(v841_3_branches.size());
      for (const auto& v841_3_branch : v841_3_branches) {
        const Path v841_3_head{v841_3_branch.first};
        const Space& v841_3_tail = v841_3_branch.second;
        const Path v842_2 = concat_path(v841_2,v841_3_head);
        const auto v842_3_branches = branches(c,v841_3_tail);
        std::vector<Space> v842_3_outputs;
        v842_3_outputs.reserve(v842_3_branches.size());
        for (const auto& v842_3_branch : v842_3_branches) {
          const Path v842_3_head{v842_3_branch.first};
          const Space& v842_3_tail = v842_3_branch.second;
          const Path v843_2 = concat_path(v842_2,v842_3_head);
          const auto v843_3_branches = branches(c,v842_3_tail);
          std::vector<Space> v843_3_outputs;
          v843_3_outputs.reserve(v843_3_branches.size());
          for (const auto& v843_3_branch : v843_3_branches) {
            const Path v843_3_head{v843_3_branch.first};
            const Space& v843_3_tail = v843_3_branch.second;
            const auto v844_2_branches = branches(c,v843_3_tail);
            std::vector<Space> v844_2_outputs;
            v844_2_outputs.reserve(v844_2_branches.size());
            for (const auto& v844_2_branch : v844_2_branches) {
              const Path v844_2_head{v844_2_branch.first};
              const Space& v844_2_tail = v844_2_branch.second;
              const Path v845_2 = concat_path(v843_3_head,v844_2_head);
              const auto v845_3_branches = branches(c,v844_2_tail);
              std::vector<Space> v845_3_outputs;
              v845_3_outputs.reserve(v845_3_branches.size());
              for (const auto& v845_3_branch : v845_3_branches) {
                const Path v845_3_head{v845_3_branch.first};
                const Space& v845_3_tail = v845_3_branch.second;
                const Path v846_2 = concat_path(v845_2,v845_3_head);
                const auto v846_3_branches = branches(c,v845_3_tail);
                std::vector<Space> v846_3_outputs;
                v846_3_outputs.reserve(v846_3_branches.size());
                for (const auto& v846_3_branch : v846_3_branches) {
                  const Path v846_3_head{v846_3_branch.first};
                  const Space& v846_3_tail = v846_3_branch.second;
                  const Path v847_2 = concat_path(v846_2,v846_3_head);
                  const Space v847_3 = routine_111(c, v847_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v843_2, v846_3_tail);
                  v846_3_outputs.push_back(v847_3);
                }
                const Space v846_3 = join_outputs(std::move(v846_3_outputs));
                v845_3_outputs.push_back(v846_3);
              }
              const Space v845_3 = join_outputs(std::move(v845_3_outputs));
              v844_2_outputs.push_back(v845_3);
            }
            const Space v844_2 = join_outputs(std::move(v844_2_outputs));
            v843_3_outputs.push_back(v844_2);
          }
          const Space v843_3 = join_outputs(std::move(v843_3_outputs));
          v842_3_outputs.push_back(v843_3);
        }
        const Space v842_3 = join_outputs(std::move(v842_3_outputs));
        v841_3_outputs.push_back(v842_3);
      }
      const Space v841_3 = join_outputs(std::move(v841_3_outputs));
      v840_2_outputs.push_back(v841_3);
    }
    const Space v840_2 = join_outputs(std::move(v840_2_outputs));
    v839_10_outputs.push_back(v840_2);
  }
  const Space v839_10 = join_outputs(std::move(v839_10_outputs));
  return v839_10;
}

static Space routine_96(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v848_10_branches = branches(c,s0);
  std::vector<Space> v848_10_outputs;
  v848_10_outputs.reserve(v848_10_branches.size());
  for (const auto& v848_10_branch : v848_10_branches) {
    const Path v848_10_head{v848_10_branch.first};
    const Space& v848_10_tail = v848_10_branch.second;
    const auto v849_2_branches = branches(c,v848_10_tail);
    std::vector<Space> v849_2_outputs;
    v849_2_outputs.reserve(v849_2_branches.size());
    for (const auto& v849_2_branch : v849_2_branches) {
      const Path v849_2_head{v849_2_branch.first};
      const Space& v849_2_tail = v849_2_branch.second;
      const Path v850_2 = concat_path(v848_10_head,v849_2_head);
      const auto v850_3_branches = branches(c,v849_2_tail);
      std::vector<Space> v850_3_outputs;
      v850_3_outputs.reserve(v850_3_branches.size());
      for (const auto& v850_3_branch : v850_3_branches) {
        const Path v850_3_head{v850_3_branch.first};
        const Space& v850_3_tail = v850_3_branch.second;
        const Path v851_2 = concat_path(v850_2,v850_3_head);
        const auto v851_3_branches = branches(c,v850_3_tail);
        std::vector<Space> v851_3_outputs;
        v851_3_outputs.reserve(v851_3_branches.size());
        for (const auto& v851_3_branch : v851_3_branches) {
          const Path v851_3_head{v851_3_branch.first};
          const Space& v851_3_tail = v851_3_branch.second;
          const Path v852_2 = concat_path(v851_2,v851_3_head);
          const auto v852_3_branches = branches(c,v851_3_tail);
          std::vector<Space> v852_3_outputs;
          v852_3_outputs.reserve(v852_3_branches.size());
          for (const auto& v852_3_branch : v852_3_branches) {
            const Path v852_3_head{v852_3_branch.first};
            const Space& v852_3_tail = v852_3_branch.second;
            const auto v853_2_branches = branches(c,v852_3_tail);
            std::vector<Space> v853_2_outputs;
            v853_2_outputs.reserve(v853_2_branches.size());
            for (const auto& v853_2_branch : v853_2_branches) {
              const Path v853_2_head{v853_2_branch.first};
              const Space& v853_2_tail = v853_2_branch.second;
              const Path v854_2 = concat_path(v852_3_head,v853_2_head);
              const auto v854_3_branches = branches(c,v853_2_tail);
              std::vector<Space> v854_3_outputs;
              v854_3_outputs.reserve(v854_3_branches.size());
              for (const auto& v854_3_branch : v854_3_branches) {
                const Path v854_3_head{v854_3_branch.first};
                const Space& v854_3_tail = v854_3_branch.second;
                const Path v855_2 = concat_path(v854_2,v854_3_head);
                const auto v855_3_branches = branches(c,v854_3_tail);
                std::vector<Space> v855_3_outputs;
                v855_3_outputs.reserve(v855_3_branches.size());
                for (const auto& v855_3_branch : v855_3_branches) {
                  const Path v855_3_head{v855_3_branch.first};
                  const Space& v855_3_tail = v855_3_branch.second;
                  const Path v856_2 = concat_path(v855_2,v855_3_head);
                  const Space v856_3 = routine_112(c, v856_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v852_2, v855_3_tail);
                  v855_3_outputs.push_back(v856_3);
                }
                const Space v855_3 = join_outputs(std::move(v855_3_outputs));
                v854_3_outputs.push_back(v855_3);
              }
              const Space v854_3 = join_outputs(std::move(v854_3_outputs));
              v853_2_outputs.push_back(v854_3);
            }
            const Space v853_2 = join_outputs(std::move(v853_2_outputs));
            v852_3_outputs.push_back(v853_2);
          }
          const Space v852_3 = join_outputs(std::move(v852_3_outputs));
          v851_3_outputs.push_back(v852_3);
        }
        const Space v851_3 = join_outputs(std::move(v851_3_outputs));
        v850_3_outputs.push_back(v851_3);
      }
      const Space v850_3 = join_outputs(std::move(v850_3_outputs));
      v849_2_outputs.push_back(v850_3);
    }
    const Space v849_2 = join_outputs(std::move(v849_2_outputs));
    v848_10_outputs.push_back(v849_2);
  }
  const Space v848_10 = join_outputs(std::move(v848_10_outputs));
  return v848_10;
}

static Space routine_97(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v857_10_branches = branches(c,s0);
  std::vector<Space> v857_10_outputs;
  v857_10_outputs.reserve(v857_10_branches.size());
  for (const auto& v857_10_branch : v857_10_branches) {
    const Path v857_10_head{v857_10_branch.first};
    const Space& v857_10_tail = v857_10_branch.second;
    const auto v858_2_branches = branches(c,v857_10_tail);
    std::vector<Space> v858_2_outputs;
    v858_2_outputs.reserve(v858_2_branches.size());
    for (const auto& v858_2_branch : v858_2_branches) {
      const Path v858_2_head{v858_2_branch.first};
      const Space& v858_2_tail = v858_2_branch.second;
      const Path v859_2 = concat_path(v857_10_head,v858_2_head);
      const auto v859_3_branches = branches(c,v858_2_tail);
      std::vector<Space> v859_3_outputs;
      v859_3_outputs.reserve(v859_3_branches.size());
      for (const auto& v859_3_branch : v859_3_branches) {
        const Path v859_3_head{v859_3_branch.first};
        const Space& v859_3_tail = v859_3_branch.second;
        const Path v860_2 = concat_path(v859_2,v859_3_head);
        const auto v860_3_branches = branches(c,v859_3_tail);
        std::vector<Space> v860_3_outputs;
        v860_3_outputs.reserve(v860_3_branches.size());
        for (const auto& v860_3_branch : v860_3_branches) {
          const Path v860_3_head{v860_3_branch.first};
          const Space& v860_3_tail = v860_3_branch.second;
          const Path v861_2 = concat_path(v860_2,v860_3_head);
          const auto v861_3_branches = branches(c,v860_3_tail);
          std::vector<Space> v861_3_outputs;
          v861_3_outputs.reserve(v861_3_branches.size());
          for (const auto& v861_3_branch : v861_3_branches) {
            const Path v861_3_head{v861_3_branch.first};
            const Space& v861_3_tail = v861_3_branch.second;
            const auto v862_2_branches = branches(c,v861_3_tail);
            std::vector<Space> v862_2_outputs;
            v862_2_outputs.reserve(v862_2_branches.size());
            for (const auto& v862_2_branch : v862_2_branches) {
              const Path v862_2_head{v862_2_branch.first};
              const Space& v862_2_tail = v862_2_branch.second;
              const Path v863_2 = concat_path(v861_3_head,v862_2_head);
              const auto v863_3_branches = branches(c,v862_2_tail);
              std::vector<Space> v863_3_outputs;
              v863_3_outputs.reserve(v863_3_branches.size());
              for (const auto& v863_3_branch : v863_3_branches) {
                const Path v863_3_head{v863_3_branch.first};
                const Space& v863_3_tail = v863_3_branch.second;
                const Path v864_2 = concat_path(v863_2,v863_3_head);
                const auto v864_3_branches = branches(c,v863_3_tail);
                std::vector<Space> v864_3_outputs;
                v864_3_outputs.reserve(v864_3_branches.size());
                for (const auto& v864_3_branch : v864_3_branches) {
                  const Path v864_3_head{v864_3_branch.first};
                  const Space& v864_3_tail = v864_3_branch.second;
                  const Path v865_2 = concat_path(v864_2,v864_3_head);
                  const Space v865_3 = routine_113(c, v865_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v861_2, v864_3_tail);
                  v864_3_outputs.push_back(v865_3);
                }
                const Space v864_3 = join_outputs(std::move(v864_3_outputs));
                v863_3_outputs.push_back(v864_3);
              }
              const Space v863_3 = join_outputs(std::move(v863_3_outputs));
              v862_2_outputs.push_back(v863_3);
            }
            const Space v862_2 = join_outputs(std::move(v862_2_outputs));
            v861_3_outputs.push_back(v862_2);
          }
          const Space v861_3 = join_outputs(std::move(v861_3_outputs));
          v860_3_outputs.push_back(v861_3);
        }
        const Space v860_3 = join_outputs(std::move(v860_3_outputs));
        v859_3_outputs.push_back(v860_3);
      }
      const Space v859_3 = join_outputs(std::move(v859_3_outputs));
      v858_2_outputs.push_back(v859_3);
    }
    const Space v858_2 = join_outputs(std::move(v858_2_outputs));
    v857_10_outputs.push_back(v858_2);
  }
  const Space v857_10 = join_outputs(std::move(v857_10_outputs));
  return v857_10;
}

static Space routine_98(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v866_10_branches = branches(c,s0);
  std::vector<Space> v866_10_outputs;
  v866_10_outputs.reserve(v866_10_branches.size());
  for (const auto& v866_10_branch : v866_10_branches) {
    const Path v866_10_head{v866_10_branch.first};
    const Space& v866_10_tail = v866_10_branch.second;
    const auto v867_2_branches = branches(c,v866_10_tail);
    std::vector<Space> v867_2_outputs;
    v867_2_outputs.reserve(v867_2_branches.size());
    for (const auto& v867_2_branch : v867_2_branches) {
      const Path v867_2_head{v867_2_branch.first};
      const Space& v867_2_tail = v867_2_branch.second;
      const Path v868_2 = concat_path(v866_10_head,v867_2_head);
      const auto v868_3_branches = branches(c,v867_2_tail);
      std::vector<Space> v868_3_outputs;
      v868_3_outputs.reserve(v868_3_branches.size());
      for (const auto& v868_3_branch : v868_3_branches) {
        const Path v868_3_head{v868_3_branch.first};
        const Space& v868_3_tail = v868_3_branch.second;
        const Path v869_2 = concat_path(v868_2,v868_3_head);
        const auto v869_3_branches = branches(c,v868_3_tail);
        std::vector<Space> v869_3_outputs;
        v869_3_outputs.reserve(v869_3_branches.size());
        for (const auto& v869_3_branch : v869_3_branches) {
          const Path v869_3_head{v869_3_branch.first};
          const Space& v869_3_tail = v869_3_branch.second;
          const Path v870_2 = concat_path(v869_2,v869_3_head);
          const auto v870_3_branches = branches(c,v869_3_tail);
          std::vector<Space> v870_3_outputs;
          v870_3_outputs.reserve(v870_3_branches.size());
          for (const auto& v870_3_branch : v870_3_branches) {
            const Path v870_3_head{v870_3_branch.first};
            const Space& v870_3_tail = v870_3_branch.second;
            const auto v871_2_branches = branches(c,v870_3_tail);
            std::vector<Space> v871_2_outputs;
            v871_2_outputs.reserve(v871_2_branches.size());
            for (const auto& v871_2_branch : v871_2_branches) {
              const Path v871_2_head{v871_2_branch.first};
              const Space& v871_2_tail = v871_2_branch.second;
              const Path v872_2 = concat_path(v870_3_head,v871_2_head);
              const auto v872_3_branches = branches(c,v871_2_tail);
              std::vector<Space> v872_3_outputs;
              v872_3_outputs.reserve(v872_3_branches.size());
              for (const auto& v872_3_branch : v872_3_branches) {
                const Path v872_3_head{v872_3_branch.first};
                const Space& v872_3_tail = v872_3_branch.second;
                const Path v873_2 = concat_path(v872_2,v872_3_head);
                const auto v873_3_branches = branches(c,v872_3_tail);
                std::vector<Space> v873_3_outputs;
                v873_3_outputs.reserve(v873_3_branches.size());
                for (const auto& v873_3_branch : v873_3_branches) {
                  const Path v873_3_head{v873_3_branch.first};
                  const Space& v873_3_tail = v873_3_branch.second;
                  const Path v874_2 = concat_path(v873_2,v873_3_head);
                  const Space v874_3 = routine_114(c, v874_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v870_2, v873_3_tail);
                  v873_3_outputs.push_back(v874_3);
                }
                const Space v873_3 = join_outputs(std::move(v873_3_outputs));
                v872_3_outputs.push_back(v873_3);
              }
              const Space v872_3 = join_outputs(std::move(v872_3_outputs));
              v871_2_outputs.push_back(v872_3);
            }
            const Space v871_2 = join_outputs(std::move(v871_2_outputs));
            v870_3_outputs.push_back(v871_2);
          }
          const Space v870_3 = join_outputs(std::move(v870_3_outputs));
          v869_3_outputs.push_back(v870_3);
        }
        const Space v869_3 = join_outputs(std::move(v869_3_outputs));
        v868_3_outputs.push_back(v869_3);
      }
      const Space v868_3 = join_outputs(std::move(v868_3_outputs));
      v867_2_outputs.push_back(v868_3);
    }
    const Space v867_2 = join_outputs(std::move(v867_2_outputs));
    v866_10_outputs.push_back(v867_2);
  }
  const Space v866_10 = join_outputs(std::move(v866_10_outputs));
  return v866_10;
}

static Space routine_99(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v875_10_branches = branches(c,s0);
  std::vector<Space> v875_10_outputs;
  v875_10_outputs.reserve(v875_10_branches.size());
  for (const auto& v875_10_branch : v875_10_branches) {
    const Path v875_10_head{v875_10_branch.first};
    const Space& v875_10_tail = v875_10_branch.second;
    const auto v876_2_branches = branches(c,v875_10_tail);
    std::vector<Space> v876_2_outputs;
    v876_2_outputs.reserve(v876_2_branches.size());
    for (const auto& v876_2_branch : v876_2_branches) {
      const Path v876_2_head{v876_2_branch.first};
      const Space& v876_2_tail = v876_2_branch.second;
      const Path v877_2 = concat_path(v875_10_head,v876_2_head);
      const auto v877_3_branches = branches(c,v876_2_tail);
      std::vector<Space> v877_3_outputs;
      v877_3_outputs.reserve(v877_3_branches.size());
      for (const auto& v877_3_branch : v877_3_branches) {
        const Path v877_3_head{v877_3_branch.first};
        const Space& v877_3_tail = v877_3_branch.second;
        const Path v878_2 = concat_path(v877_2,v877_3_head);
        const auto v878_3_branches = branches(c,v877_3_tail);
        std::vector<Space> v878_3_outputs;
        v878_3_outputs.reserve(v878_3_branches.size());
        for (const auto& v878_3_branch : v878_3_branches) {
          const Path v878_3_head{v878_3_branch.first};
          const Space& v878_3_tail = v878_3_branch.second;
          const Path v879_2 = concat_path(v878_2,v878_3_head);
          const auto v879_3_branches = branches(c,v878_3_tail);
          std::vector<Space> v879_3_outputs;
          v879_3_outputs.reserve(v879_3_branches.size());
          for (const auto& v879_3_branch : v879_3_branches) {
            const Path v879_3_head{v879_3_branch.first};
            const Space& v879_3_tail = v879_3_branch.second;
            const auto v880_2_branches = branches(c,v879_3_tail);
            std::vector<Space> v880_2_outputs;
            v880_2_outputs.reserve(v880_2_branches.size());
            for (const auto& v880_2_branch : v880_2_branches) {
              const Path v880_2_head{v880_2_branch.first};
              const Space& v880_2_tail = v880_2_branch.second;
              const Path v881_2 = concat_path(v879_3_head,v880_2_head);
              const auto v881_3_branches = branches(c,v880_2_tail);
              std::vector<Space> v881_3_outputs;
              v881_3_outputs.reserve(v881_3_branches.size());
              for (const auto& v881_3_branch : v881_3_branches) {
                const Path v881_3_head{v881_3_branch.first};
                const Space& v881_3_tail = v881_3_branch.second;
                const Path v882_2 = concat_path(v881_2,v881_3_head);
                const auto v882_3_branches = branches(c,v881_3_tail);
                std::vector<Space> v882_3_outputs;
                v882_3_outputs.reserve(v882_3_branches.size());
                for (const auto& v882_3_branch : v882_3_branches) {
                  const Path v882_3_head{v882_3_branch.first};
                  const Space& v882_3_tail = v882_3_branch.second;
                  const Path v883_2 = concat_path(v882_2,v882_3_head);
                  const Space v883_3 = routine_115(c, v883_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v879_2, v882_3_tail);
                  v882_3_outputs.push_back(v883_3);
                }
                const Space v882_3 = join_outputs(std::move(v882_3_outputs));
                v881_3_outputs.push_back(v882_3);
              }
              const Space v881_3 = join_outputs(std::move(v881_3_outputs));
              v880_2_outputs.push_back(v881_3);
            }
            const Space v880_2 = join_outputs(std::move(v880_2_outputs));
            v879_3_outputs.push_back(v880_2);
          }
          const Space v879_3 = join_outputs(std::move(v879_3_outputs));
          v878_3_outputs.push_back(v879_3);
        }
        const Space v878_3 = join_outputs(std::move(v878_3_outputs));
        v877_3_outputs.push_back(v878_3);
      }
      const Space v877_3 = join_outputs(std::move(v877_3_outputs));
      v876_2_outputs.push_back(v877_3);
    }
    const Space v876_2 = join_outputs(std::move(v876_2_outputs));
    v875_10_outputs.push_back(v876_2);
  }
  const Space v875_10 = join_outputs(std::move(v875_10_outputs));
  return v875_10;
}

static Space routine_100(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v884_10_branches = branches(c,s0);
  std::vector<Space> v884_10_outputs;
  v884_10_outputs.reserve(v884_10_branches.size());
  for (const auto& v884_10_branch : v884_10_branches) {
    const Path v884_10_head{v884_10_branch.first};
    const Space& v884_10_tail = v884_10_branch.second;
    const auto v885_2_branches = branches(c,v884_10_tail);
    std::vector<Space> v885_2_outputs;
    v885_2_outputs.reserve(v885_2_branches.size());
    for (const auto& v885_2_branch : v885_2_branches) {
      const Path v885_2_head{v885_2_branch.first};
      const Space& v885_2_tail = v885_2_branch.second;
      const Path v886_2 = concat_path(v884_10_head,v885_2_head);
      const auto v886_3_branches = branches(c,v885_2_tail);
      std::vector<Space> v886_3_outputs;
      v886_3_outputs.reserve(v886_3_branches.size());
      for (const auto& v886_3_branch : v886_3_branches) {
        const Path v886_3_head{v886_3_branch.first};
        const Space& v886_3_tail = v886_3_branch.second;
        const Path v887_2 = concat_path(v886_2,v886_3_head);
        const auto v887_3_branches = branches(c,v886_3_tail);
        std::vector<Space> v887_3_outputs;
        v887_3_outputs.reserve(v887_3_branches.size());
        for (const auto& v887_3_branch : v887_3_branches) {
          const Path v887_3_head{v887_3_branch.first};
          const Space& v887_3_tail = v887_3_branch.second;
          const Path v888_2 = concat_path(v887_2,v887_3_head);
          const auto v888_3_branches = branches(c,v887_3_tail);
          std::vector<Space> v888_3_outputs;
          v888_3_outputs.reserve(v888_3_branches.size());
          for (const auto& v888_3_branch : v888_3_branches) {
            const Path v888_3_head{v888_3_branch.first};
            const Space& v888_3_tail = v888_3_branch.second;
            const auto v889_2_branches = branches(c,v888_3_tail);
            std::vector<Space> v889_2_outputs;
            v889_2_outputs.reserve(v889_2_branches.size());
            for (const auto& v889_2_branch : v889_2_branches) {
              const Path v889_2_head{v889_2_branch.first};
              const Space& v889_2_tail = v889_2_branch.second;
              const Path v890_2 = concat_path(v888_3_head,v889_2_head);
              const auto v890_3_branches = branches(c,v889_2_tail);
              std::vector<Space> v890_3_outputs;
              v890_3_outputs.reserve(v890_3_branches.size());
              for (const auto& v890_3_branch : v890_3_branches) {
                const Path v890_3_head{v890_3_branch.first};
                const Space& v890_3_tail = v890_3_branch.second;
                const Path v891_2 = concat_path(v890_2,v890_3_head);
                const auto v891_3_branches = branches(c,v890_3_tail);
                std::vector<Space> v891_3_outputs;
                v891_3_outputs.reserve(v891_3_branches.size());
                for (const auto& v891_3_branch : v891_3_branches) {
                  const Path v891_3_head{v891_3_branch.first};
                  const Space& v891_3_tail = v891_3_branch.second;
                  const Path v892_2 = concat_path(v891_2,v891_3_head);
                  const Space v892_3 = routine_116(c, v892_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v888_2, v891_3_tail);
                  v891_3_outputs.push_back(v892_3);
                }
                const Space v891_3 = join_outputs(std::move(v891_3_outputs));
                v890_3_outputs.push_back(v891_3);
              }
              const Space v890_3 = join_outputs(std::move(v890_3_outputs));
              v889_2_outputs.push_back(v890_3);
            }
            const Space v889_2 = join_outputs(std::move(v889_2_outputs));
            v888_3_outputs.push_back(v889_2);
          }
          const Space v888_3 = join_outputs(std::move(v888_3_outputs));
          v887_3_outputs.push_back(v888_3);
        }
        const Space v887_3 = join_outputs(std::move(v887_3_outputs));
        v886_3_outputs.push_back(v887_3);
      }
      const Space v886_3 = join_outputs(std::move(v886_3_outputs));
      v885_2_outputs.push_back(v886_3);
    }
    const Space v885_2 = join_outputs(std::move(v885_2_outputs));
    v884_10_outputs.push_back(v885_2);
  }
  const Space v884_10 = join_outputs(std::move(v884_10_outputs));
  return v884_10;
}

static Space routine_101(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v893_10_branches = branches(c,s0);
  std::vector<Space> v893_10_outputs;
  v893_10_outputs.reserve(v893_10_branches.size());
  for (const auto& v893_10_branch : v893_10_branches) {
    const Path v893_10_head{v893_10_branch.first};
    const Space& v893_10_tail = v893_10_branch.second;
    const auto v894_2_branches = branches(c,v893_10_tail);
    std::vector<Space> v894_2_outputs;
    v894_2_outputs.reserve(v894_2_branches.size());
    for (const auto& v894_2_branch : v894_2_branches) {
      const Path v894_2_head{v894_2_branch.first};
      const Space& v894_2_tail = v894_2_branch.second;
      const Path v895_2 = concat_path(v893_10_head,v894_2_head);
      const auto v895_3_branches = branches(c,v894_2_tail);
      std::vector<Space> v895_3_outputs;
      v895_3_outputs.reserve(v895_3_branches.size());
      for (const auto& v895_3_branch : v895_3_branches) {
        const Path v895_3_head{v895_3_branch.first};
        const Space& v895_3_tail = v895_3_branch.second;
        const Path v896_2 = concat_path(v895_2,v895_3_head);
        const auto v896_3_branches = branches(c,v895_3_tail);
        std::vector<Space> v896_3_outputs;
        v896_3_outputs.reserve(v896_3_branches.size());
        for (const auto& v896_3_branch : v896_3_branches) {
          const Path v896_3_head{v896_3_branch.first};
          const Space& v896_3_tail = v896_3_branch.second;
          const Path v897_2 = concat_path(v896_2,v896_3_head);
          const auto v897_3_branches = branches(c,v896_3_tail);
          std::vector<Space> v897_3_outputs;
          v897_3_outputs.reserve(v897_3_branches.size());
          for (const auto& v897_3_branch : v897_3_branches) {
            const Path v897_3_head{v897_3_branch.first};
            const Space& v897_3_tail = v897_3_branch.second;
            const auto v898_2_branches = branches(c,v897_3_tail);
            std::vector<Space> v898_2_outputs;
            v898_2_outputs.reserve(v898_2_branches.size());
            for (const auto& v898_2_branch : v898_2_branches) {
              const Path v898_2_head{v898_2_branch.first};
              const Space& v898_2_tail = v898_2_branch.second;
              const Path v899_2 = concat_path(v897_3_head,v898_2_head);
              const auto v899_3_branches = branches(c,v898_2_tail);
              std::vector<Space> v899_3_outputs;
              v899_3_outputs.reserve(v899_3_branches.size());
              for (const auto& v899_3_branch : v899_3_branches) {
                const Path v899_3_head{v899_3_branch.first};
                const Space& v899_3_tail = v899_3_branch.second;
                const Path v900_2 = concat_path(v899_2,v899_3_head);
                const auto v900_3_branches = branches(c,v899_3_tail);
                std::vector<Space> v900_3_outputs;
                v900_3_outputs.reserve(v900_3_branches.size());
                for (const auto& v900_3_branch : v900_3_branches) {
                  const Path v900_3_head{v900_3_branch.first};
                  const Space& v900_3_tail = v900_3_branch.second;
                  const Path v901_2 = concat_path(v900_2,v900_3_head);
                  const Space v901_3 = routine_117(c, v901_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v897_2, v900_3_tail);
                  v900_3_outputs.push_back(v901_3);
                }
                const Space v900_3 = join_outputs(std::move(v900_3_outputs));
                v899_3_outputs.push_back(v900_3);
              }
              const Space v899_3 = join_outputs(std::move(v899_3_outputs));
              v898_2_outputs.push_back(v899_3);
            }
            const Space v898_2 = join_outputs(std::move(v898_2_outputs));
            v897_3_outputs.push_back(v898_2);
          }
          const Space v897_3 = join_outputs(std::move(v897_3_outputs));
          v896_3_outputs.push_back(v897_3);
        }
        const Space v896_3 = join_outputs(std::move(v896_3_outputs));
        v895_3_outputs.push_back(v896_3);
      }
      const Space v895_3 = join_outputs(std::move(v895_3_outputs));
      v894_2_outputs.push_back(v895_3);
    }
    const Space v894_2 = join_outputs(std::move(v894_2_outputs));
    v893_10_outputs.push_back(v894_2);
  }
  const Space v893_10 = join_outputs(std::move(v893_10_outputs));
  return v893_10;
}

static Space routine_102(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v902_10_branches = branches(c,s0);
  std::vector<Space> v902_10_outputs;
  v902_10_outputs.reserve(v902_10_branches.size());
  for (const auto& v902_10_branch : v902_10_branches) {
    const Path v902_10_head{v902_10_branch.first};
    const Space& v902_10_tail = v902_10_branch.second;
    const auto v903_2_branches = branches(c,v902_10_tail);
    std::vector<Space> v903_2_outputs;
    v903_2_outputs.reserve(v903_2_branches.size());
    for (const auto& v903_2_branch : v903_2_branches) {
      const Path v903_2_head{v903_2_branch.first};
      const Space& v903_2_tail = v903_2_branch.second;
      const Path v904_2 = concat_path(v902_10_head,v903_2_head);
      const auto v904_3_branches = branches(c,v903_2_tail);
      std::vector<Space> v904_3_outputs;
      v904_3_outputs.reserve(v904_3_branches.size());
      for (const auto& v904_3_branch : v904_3_branches) {
        const Path v904_3_head{v904_3_branch.first};
        const Space& v904_3_tail = v904_3_branch.second;
        const Path v905_2 = concat_path(v904_2,v904_3_head);
        const auto v905_3_branches = branches(c,v904_3_tail);
        std::vector<Space> v905_3_outputs;
        v905_3_outputs.reserve(v905_3_branches.size());
        for (const auto& v905_3_branch : v905_3_branches) {
          const Path v905_3_head{v905_3_branch.first};
          const Space& v905_3_tail = v905_3_branch.second;
          const Path v906_2 = concat_path(v905_2,v905_3_head);
          const auto v906_3_branches = branches(c,v905_3_tail);
          std::vector<Space> v906_3_outputs;
          v906_3_outputs.reserve(v906_3_branches.size());
          for (const auto& v906_3_branch : v906_3_branches) {
            const Path v906_3_head{v906_3_branch.first};
            const Space& v906_3_tail = v906_3_branch.second;
            const auto v907_2_branches = branches(c,v906_3_tail);
            std::vector<Space> v907_2_outputs;
            v907_2_outputs.reserve(v907_2_branches.size());
            for (const auto& v907_2_branch : v907_2_branches) {
              const Path v907_2_head{v907_2_branch.first};
              const Space& v907_2_tail = v907_2_branch.second;
              const Path v908_2 = concat_path(v906_3_head,v907_2_head);
              const auto v908_3_branches = branches(c,v907_2_tail);
              std::vector<Space> v908_3_outputs;
              v908_3_outputs.reserve(v908_3_branches.size());
              for (const auto& v908_3_branch : v908_3_branches) {
                const Path v908_3_head{v908_3_branch.first};
                const Space& v908_3_tail = v908_3_branch.second;
                const Path v909_2 = concat_path(v908_2,v908_3_head);
                const auto v909_3_branches = branches(c,v908_3_tail);
                std::vector<Space> v909_3_outputs;
                v909_3_outputs.reserve(v909_3_branches.size());
                for (const auto& v909_3_branch : v909_3_branches) {
                  const Path v909_3_head{v909_3_branch.first};
                  const Space& v909_3_tail = v909_3_branch.second;
                  const Path v910_2 = concat_path(v909_2,v909_3_head);
                  const Space v910_3 = routine_118(c, v910_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v906_2, v909_3_tail);
                  v909_3_outputs.push_back(v910_3);
                }
                const Space v909_3 = join_outputs(std::move(v909_3_outputs));
                v908_3_outputs.push_back(v909_3);
              }
              const Space v908_3 = join_outputs(std::move(v908_3_outputs));
              v907_2_outputs.push_back(v908_3);
            }
            const Space v907_2 = join_outputs(std::move(v907_2_outputs));
            v906_3_outputs.push_back(v907_2);
          }
          const Space v906_3 = join_outputs(std::move(v906_3_outputs));
          v905_3_outputs.push_back(v906_3);
        }
        const Space v905_3 = join_outputs(std::move(v905_3_outputs));
        v904_3_outputs.push_back(v905_3);
      }
      const Space v904_3 = join_outputs(std::move(v904_3_outputs));
      v903_2_outputs.push_back(v904_3);
    }
    const Space v903_2 = join_outputs(std::move(v903_2_outputs));
    v902_10_outputs.push_back(v903_2);
  }
  const Space v902_10 = join_outputs(std::move(v902_10_outputs));
  return v902_10;
}

static Space routine_103(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v911_10_branches = branches(c,s0);
  std::vector<Space> v911_10_outputs;
  v911_10_outputs.reserve(v911_10_branches.size());
  for (const auto& v911_10_branch : v911_10_branches) {
    const Path v911_10_head{v911_10_branch.first};
    const Space& v911_10_tail = v911_10_branch.second;
    const auto v912_2_branches = branches(c,v911_10_tail);
    std::vector<Space> v912_2_outputs;
    v912_2_outputs.reserve(v912_2_branches.size());
    for (const auto& v912_2_branch : v912_2_branches) {
      const Path v912_2_head{v912_2_branch.first};
      const Space& v912_2_tail = v912_2_branch.second;
      const Path v913_2 = concat_path(v911_10_head,v912_2_head);
      const auto v913_3_branches = branches(c,v912_2_tail);
      std::vector<Space> v913_3_outputs;
      v913_3_outputs.reserve(v913_3_branches.size());
      for (const auto& v913_3_branch : v913_3_branches) {
        const Path v913_3_head{v913_3_branch.first};
        const Space& v913_3_tail = v913_3_branch.second;
        const Path v914_2 = concat_path(v913_2,v913_3_head);
        const auto v914_3_branches = branches(c,v913_3_tail);
        std::vector<Space> v914_3_outputs;
        v914_3_outputs.reserve(v914_3_branches.size());
        for (const auto& v914_3_branch : v914_3_branches) {
          const Path v914_3_head{v914_3_branch.first};
          const Space& v914_3_tail = v914_3_branch.second;
          const Path v915_2 = concat_path(v914_2,v914_3_head);
          const auto v915_3_branches = branches(c,v914_3_tail);
          std::vector<Space> v915_3_outputs;
          v915_3_outputs.reserve(v915_3_branches.size());
          for (const auto& v915_3_branch : v915_3_branches) {
            const Path v915_3_head{v915_3_branch.first};
            const Space& v915_3_tail = v915_3_branch.second;
            const auto v916_2_branches = branches(c,v915_3_tail);
            std::vector<Space> v916_2_outputs;
            v916_2_outputs.reserve(v916_2_branches.size());
            for (const auto& v916_2_branch : v916_2_branches) {
              const Path v916_2_head{v916_2_branch.first};
              const Space& v916_2_tail = v916_2_branch.second;
              const Path v917_2 = concat_path(v915_3_head,v916_2_head);
              const auto v917_3_branches = branches(c,v916_2_tail);
              std::vector<Space> v917_3_outputs;
              v917_3_outputs.reserve(v917_3_branches.size());
              for (const auto& v917_3_branch : v917_3_branches) {
                const Path v917_3_head{v917_3_branch.first};
                const Space& v917_3_tail = v917_3_branch.second;
                const Path v918_2 = concat_path(v917_2,v917_3_head);
                const auto v918_3_branches = branches(c,v917_3_tail);
                std::vector<Space> v918_3_outputs;
                v918_3_outputs.reserve(v918_3_branches.size());
                for (const auto& v918_3_branch : v918_3_branches) {
                  const Path v918_3_head{v918_3_branch.first};
                  const Space& v918_3_tail = v918_3_branch.second;
                  const Path v919_2 = concat_path(v918_2,v918_3_head);
                  const Space v919_3 = routine_119(c, v919_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v915_2, v918_3_tail);
                  v918_3_outputs.push_back(v919_3);
                }
                const Space v918_3 = join_outputs(std::move(v918_3_outputs));
                v917_3_outputs.push_back(v918_3);
              }
              const Space v917_3 = join_outputs(std::move(v917_3_outputs));
              v916_2_outputs.push_back(v917_3);
            }
            const Space v916_2 = join_outputs(std::move(v916_2_outputs));
            v915_3_outputs.push_back(v916_2);
          }
          const Space v915_3 = join_outputs(std::move(v915_3_outputs));
          v914_3_outputs.push_back(v915_3);
        }
        const Space v914_3 = join_outputs(std::move(v914_3_outputs));
        v913_3_outputs.push_back(v914_3);
      }
      const Space v913_3 = join_outputs(std::move(v913_3_outputs));
      v912_2_outputs.push_back(v913_3);
    }
    const Space v912_2 = join_outputs(std::move(v912_2_outputs));
    v911_10_outputs.push_back(v912_2);
  }
  const Space v911_10 = join_outputs(std::move(v911_10_outputs));
  return v911_10;
}

static Space routine_104(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v920_10_branches = branches(c,s0);
  std::vector<Space> v920_10_outputs;
  v920_10_outputs.reserve(v920_10_branches.size());
  for (const auto& v920_10_branch : v920_10_branches) {
    const Path v920_10_head{v920_10_branch.first};
    const Space& v920_10_tail = v920_10_branch.second;
    const auto v921_2_branches = branches(c,v920_10_tail);
    std::vector<Space> v921_2_outputs;
    v921_2_outputs.reserve(v921_2_branches.size());
    for (const auto& v921_2_branch : v921_2_branches) {
      const Path v921_2_head{v921_2_branch.first};
      const Space& v921_2_tail = v921_2_branch.second;
      const Path v922_2 = concat_path(v920_10_head,v921_2_head);
      const auto v922_3_branches = branches(c,v921_2_tail);
      std::vector<Space> v922_3_outputs;
      v922_3_outputs.reserve(v922_3_branches.size());
      for (const auto& v922_3_branch : v922_3_branches) {
        const Path v922_3_head{v922_3_branch.first};
        const Space& v922_3_tail = v922_3_branch.second;
        const Path v923_2 = concat_path(v922_2,v922_3_head);
        const auto v923_3_branches = branches(c,v922_3_tail);
        std::vector<Space> v923_3_outputs;
        v923_3_outputs.reserve(v923_3_branches.size());
        for (const auto& v923_3_branch : v923_3_branches) {
          const Path v923_3_head{v923_3_branch.first};
          const Space& v923_3_tail = v923_3_branch.second;
          const Path v924_2 = concat_path(v923_2,v923_3_head);
          const auto v924_3_branches = branches(c,v923_3_tail);
          std::vector<Space> v924_3_outputs;
          v924_3_outputs.reserve(v924_3_branches.size());
          for (const auto& v924_3_branch : v924_3_branches) {
            const Path v924_3_head{v924_3_branch.first};
            const Space& v924_3_tail = v924_3_branch.second;
            const auto v925_2_branches = branches(c,v924_3_tail);
            std::vector<Space> v925_2_outputs;
            v925_2_outputs.reserve(v925_2_branches.size());
            for (const auto& v925_2_branch : v925_2_branches) {
              const Path v925_2_head{v925_2_branch.first};
              const Space& v925_2_tail = v925_2_branch.second;
              const Path v926_2 = concat_path(v924_3_head,v925_2_head);
              const auto v926_3_branches = branches(c,v925_2_tail);
              std::vector<Space> v926_3_outputs;
              v926_3_outputs.reserve(v926_3_branches.size());
              for (const auto& v926_3_branch : v926_3_branches) {
                const Path v926_3_head{v926_3_branch.first};
                const Space& v926_3_tail = v926_3_branch.second;
                const Path v927_2 = concat_path(v926_2,v926_3_head);
                const auto v927_3_branches = branches(c,v926_3_tail);
                std::vector<Space> v927_3_outputs;
                v927_3_outputs.reserve(v927_3_branches.size());
                for (const auto& v927_3_branch : v927_3_branches) {
                  const Path v927_3_head{v927_3_branch.first};
                  const Space& v927_3_tail = v927_3_branch.second;
                  const Path v928_2 = concat_path(v927_2,v927_3_head);
                  const Space v928_3 = routine_120(c, v928_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v924_2, v927_3_tail);
                  v927_3_outputs.push_back(v928_3);
                }
                const Space v927_3 = join_outputs(std::move(v927_3_outputs));
                v926_3_outputs.push_back(v927_3);
              }
              const Space v926_3 = join_outputs(std::move(v926_3_outputs));
              v925_2_outputs.push_back(v926_3);
            }
            const Space v925_2 = join_outputs(std::move(v925_2_outputs));
            v924_3_outputs.push_back(v925_2);
          }
          const Space v924_3 = join_outputs(std::move(v924_3_outputs));
          v923_3_outputs.push_back(v924_3);
        }
        const Space v923_3 = join_outputs(std::move(v923_3_outputs));
        v922_3_outputs.push_back(v923_3);
      }
      const Space v922_3 = join_outputs(std::move(v922_3_outputs));
      v921_2_outputs.push_back(v922_3);
    }
    const Space v921_2 = join_outputs(std::move(v921_2_outputs));
    v920_10_outputs.push_back(v921_2);
  }
  const Space v920_10 = join_outputs(std::move(v920_10_outputs));
  return v920_10;
}

static Space routine_105(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v929_10_branches = branches(c,s0);
  std::vector<Space> v929_10_outputs;
  v929_10_outputs.reserve(v929_10_branches.size());
  for (const auto& v929_10_branch : v929_10_branches) {
    const Path v929_10_head{v929_10_branch.first};
    const Space& v929_10_tail = v929_10_branch.second;
    const auto v930_2_branches = branches(c,v929_10_tail);
    std::vector<Space> v930_2_outputs;
    v930_2_outputs.reserve(v930_2_branches.size());
    for (const auto& v930_2_branch : v930_2_branches) {
      const Path v930_2_head{v930_2_branch.first};
      const Space& v930_2_tail = v930_2_branch.second;
      const Path v931_2 = concat_path(v929_10_head,v930_2_head);
      const auto v931_3_branches = branches(c,v930_2_tail);
      std::vector<Space> v931_3_outputs;
      v931_3_outputs.reserve(v931_3_branches.size());
      for (const auto& v931_3_branch : v931_3_branches) {
        const Path v931_3_head{v931_3_branch.first};
        const Space& v931_3_tail = v931_3_branch.second;
        const Path v932_2 = concat_path(v931_2,v931_3_head);
        const auto v932_3_branches = branches(c,v931_3_tail);
        std::vector<Space> v932_3_outputs;
        v932_3_outputs.reserve(v932_3_branches.size());
        for (const auto& v932_3_branch : v932_3_branches) {
          const Path v932_3_head{v932_3_branch.first};
          const Space& v932_3_tail = v932_3_branch.second;
          const Path v933_2 = concat_path(v932_2,v932_3_head);
          const auto v933_3_branches = branches(c,v932_3_tail);
          std::vector<Space> v933_3_outputs;
          v933_3_outputs.reserve(v933_3_branches.size());
          for (const auto& v933_3_branch : v933_3_branches) {
            const Path v933_3_head{v933_3_branch.first};
            const Space& v933_3_tail = v933_3_branch.second;
            const auto v934_2_branches = branches(c,v933_3_tail);
            std::vector<Space> v934_2_outputs;
            v934_2_outputs.reserve(v934_2_branches.size());
            for (const auto& v934_2_branch : v934_2_branches) {
              const Path v934_2_head{v934_2_branch.first};
              const Space& v934_2_tail = v934_2_branch.second;
              const Path v935_2 = concat_path(v933_3_head,v934_2_head);
              const auto v935_3_branches = branches(c,v934_2_tail);
              std::vector<Space> v935_3_outputs;
              v935_3_outputs.reserve(v935_3_branches.size());
              for (const auto& v935_3_branch : v935_3_branches) {
                const Path v935_3_head{v935_3_branch.first};
                const Space& v935_3_tail = v935_3_branch.second;
                const Path v936_2 = concat_path(v935_2,v935_3_head);
                const auto v936_3_branches = branches(c,v935_3_tail);
                std::vector<Space> v936_3_outputs;
                v936_3_outputs.reserve(v936_3_branches.size());
                for (const auto& v936_3_branch : v936_3_branches) {
                  const Path v936_3_head{v936_3_branch.first};
                  const Space& v936_3_tail = v936_3_branch.second;
                  const Path v937_2 = concat_path(v936_2,v936_3_head);
                  const Space v937_3 = routine_121(c, v937_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v933_2, v936_3_tail);
                  v936_3_outputs.push_back(v937_3);
                }
                const Space v936_3 = join_outputs(std::move(v936_3_outputs));
                v935_3_outputs.push_back(v936_3);
              }
              const Space v935_3 = join_outputs(std::move(v935_3_outputs));
              v934_2_outputs.push_back(v935_3);
            }
            const Space v934_2 = join_outputs(std::move(v934_2_outputs));
            v933_3_outputs.push_back(v934_2);
          }
          const Space v933_3 = join_outputs(std::move(v933_3_outputs));
          v932_3_outputs.push_back(v933_3);
        }
        const Space v932_3 = join_outputs(std::move(v932_3_outputs));
        v931_3_outputs.push_back(v932_3);
      }
      const Space v931_3 = join_outputs(std::move(v931_3_outputs));
      v930_2_outputs.push_back(v931_3);
    }
    const Space v930_2 = join_outputs(std::move(v930_2_outputs));
    v929_10_outputs.push_back(v930_2);
  }
  const Space v929_10 = join_outputs(std::move(v929_10_outputs));
  return v929_10;
}

static Space routine_106(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v938_10_branches = branches(c,s0);
  std::vector<Space> v938_10_outputs;
  v938_10_outputs.reserve(v938_10_branches.size());
  for (const auto& v938_10_branch : v938_10_branches) {
    const Path v938_10_head{v938_10_branch.first};
    const Space& v938_10_tail = v938_10_branch.second;
    const auto v939_2_branches = branches(c,v938_10_tail);
    std::vector<Space> v939_2_outputs;
    v939_2_outputs.reserve(v939_2_branches.size());
    for (const auto& v939_2_branch : v939_2_branches) {
      const Path v939_2_head{v939_2_branch.first};
      const Space& v939_2_tail = v939_2_branch.second;
      const Path v940_2 = concat_path(v938_10_head,v939_2_head);
      const auto v940_3_branches = branches(c,v939_2_tail);
      std::vector<Space> v940_3_outputs;
      v940_3_outputs.reserve(v940_3_branches.size());
      for (const auto& v940_3_branch : v940_3_branches) {
        const Path v940_3_head{v940_3_branch.first};
        const Space& v940_3_tail = v940_3_branch.second;
        const Path v941_2 = concat_path(v940_2,v940_3_head);
        const auto v941_3_branches = branches(c,v940_3_tail);
        std::vector<Space> v941_3_outputs;
        v941_3_outputs.reserve(v941_3_branches.size());
        for (const auto& v941_3_branch : v941_3_branches) {
          const Path v941_3_head{v941_3_branch.first};
          const Space& v941_3_tail = v941_3_branch.second;
          const Path v942_2 = concat_path(v941_2,v941_3_head);
          const auto v942_3_branches = branches(c,v941_3_tail);
          std::vector<Space> v942_3_outputs;
          v942_3_outputs.reserve(v942_3_branches.size());
          for (const auto& v942_3_branch : v942_3_branches) {
            const Path v942_3_head{v942_3_branch.first};
            const Space& v942_3_tail = v942_3_branch.second;
            const auto v943_2_branches = branches(c,v942_3_tail);
            std::vector<Space> v943_2_outputs;
            v943_2_outputs.reserve(v943_2_branches.size());
            for (const auto& v943_2_branch : v943_2_branches) {
              const Path v943_2_head{v943_2_branch.first};
              const Space& v943_2_tail = v943_2_branch.second;
              const Path v944_2 = concat_path(v942_3_head,v943_2_head);
              const auto v944_3_branches = branches(c,v943_2_tail);
              std::vector<Space> v944_3_outputs;
              v944_3_outputs.reserve(v944_3_branches.size());
              for (const auto& v944_3_branch : v944_3_branches) {
                const Path v944_3_head{v944_3_branch.first};
                const Space& v944_3_tail = v944_3_branch.second;
                const Path v945_2 = concat_path(v944_2,v944_3_head);
                const auto v945_3_branches = branches(c,v944_3_tail);
                std::vector<Space> v945_3_outputs;
                v945_3_outputs.reserve(v945_3_branches.size());
                for (const auto& v945_3_branch : v945_3_branches) {
                  const Path v945_3_head{v945_3_branch.first};
                  const Space& v945_3_tail = v945_3_branch.second;
                  const Path v946_2 = concat_path(v945_2,v945_3_head);
                  const Space v946_3 = routine_122(c, v946_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v942_2, v945_3_tail);
                  v945_3_outputs.push_back(v946_3);
                }
                const Space v945_3 = join_outputs(std::move(v945_3_outputs));
                v944_3_outputs.push_back(v945_3);
              }
              const Space v944_3 = join_outputs(std::move(v944_3_outputs));
              v943_2_outputs.push_back(v944_3);
            }
            const Space v943_2 = join_outputs(std::move(v943_2_outputs));
            v942_3_outputs.push_back(v943_2);
          }
          const Space v942_3 = join_outputs(std::move(v942_3_outputs));
          v941_3_outputs.push_back(v942_3);
        }
        const Space v941_3 = join_outputs(std::move(v941_3_outputs));
        v940_3_outputs.push_back(v941_3);
      }
      const Space v940_3 = join_outputs(std::move(v940_3_outputs));
      v939_2_outputs.push_back(v940_3);
    }
    const Space v939_2 = join_outputs(std::move(v939_2_outputs));
    v938_10_outputs.push_back(v939_2);
  }
  const Space v938_10 = join_outputs(std::move(v938_10_outputs));
  return v938_10;
}

static Space routine_107(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v947_10_branches = branches(c,s0);
  std::vector<Space> v947_10_outputs;
  v947_10_outputs.reserve(v947_10_branches.size());
  for (const auto& v947_10_branch : v947_10_branches) {
    const Path v947_10_head{v947_10_branch.first};
    const Space& v947_10_tail = v947_10_branch.second;
    const auto v948_2_branches = branches(c,v947_10_tail);
    std::vector<Space> v948_2_outputs;
    v948_2_outputs.reserve(v948_2_branches.size());
    for (const auto& v948_2_branch : v948_2_branches) {
      const Path v948_2_head{v948_2_branch.first};
      const Space& v948_2_tail = v948_2_branch.second;
      const Path v949_2 = concat_path(v947_10_head,v948_2_head);
      const auto v949_3_branches = branches(c,v948_2_tail);
      std::vector<Space> v949_3_outputs;
      v949_3_outputs.reserve(v949_3_branches.size());
      for (const auto& v949_3_branch : v949_3_branches) {
        const Path v949_3_head{v949_3_branch.first};
        const Space& v949_3_tail = v949_3_branch.second;
        const Path v950_2 = concat_path(v949_2,v949_3_head);
        const auto v950_3_branches = branches(c,v949_3_tail);
        std::vector<Space> v950_3_outputs;
        v950_3_outputs.reserve(v950_3_branches.size());
        for (const auto& v950_3_branch : v950_3_branches) {
          const Path v950_3_head{v950_3_branch.first};
          const Space& v950_3_tail = v950_3_branch.second;
          const Path v951_2 = concat_path(v950_2,v950_3_head);
          const auto v951_3_branches = branches(c,v950_3_tail);
          std::vector<Space> v951_3_outputs;
          v951_3_outputs.reserve(v951_3_branches.size());
          for (const auto& v951_3_branch : v951_3_branches) {
            const Path v951_3_head{v951_3_branch.first};
            const Space& v951_3_tail = v951_3_branch.second;
            const auto v952_2_branches = branches(c,v951_3_tail);
            std::vector<Space> v952_2_outputs;
            v952_2_outputs.reserve(v952_2_branches.size());
            for (const auto& v952_2_branch : v952_2_branches) {
              const Path v952_2_head{v952_2_branch.first};
              const Space& v952_2_tail = v952_2_branch.second;
              const Path v953_2 = concat_path(v951_3_head,v952_2_head);
              const auto v953_3_branches = branches(c,v952_2_tail);
              std::vector<Space> v953_3_outputs;
              v953_3_outputs.reserve(v953_3_branches.size());
              for (const auto& v953_3_branch : v953_3_branches) {
                const Path v953_3_head{v953_3_branch.first};
                const Space& v953_3_tail = v953_3_branch.second;
                const Path v954_2 = concat_path(v953_2,v953_3_head);
                const auto v954_3_branches = branches(c,v953_3_tail);
                std::vector<Space> v954_3_outputs;
                v954_3_outputs.reserve(v954_3_branches.size());
                for (const auto& v954_3_branch : v954_3_branches) {
                  const Path v954_3_head{v954_3_branch.first};
                  const Space& v954_3_tail = v954_3_branch.second;
                  const Path v955_2 = concat_path(v954_2,v954_3_head);
                  const Space v955_3 = routine_123(c, v955_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v951_2, v954_3_tail);
                  v954_3_outputs.push_back(v955_3);
                }
                const Space v954_3 = join_outputs(std::move(v954_3_outputs));
                v953_3_outputs.push_back(v954_3);
              }
              const Space v953_3 = join_outputs(std::move(v953_3_outputs));
              v952_2_outputs.push_back(v953_3);
            }
            const Space v952_2 = join_outputs(std::move(v952_2_outputs));
            v951_3_outputs.push_back(v952_2);
          }
          const Space v951_3 = join_outputs(std::move(v951_3_outputs));
          v950_3_outputs.push_back(v951_3);
        }
        const Space v950_3 = join_outputs(std::move(v950_3_outputs));
        v949_3_outputs.push_back(v950_3);
      }
      const Space v949_3 = join_outputs(std::move(v949_3_outputs));
      v948_2_outputs.push_back(v949_3);
    }
    const Space v948_2 = join_outputs(std::move(v948_2_outputs));
    v947_10_outputs.push_back(v948_2);
  }
  const Space v947_10 = join_outputs(std::move(v947_10_outputs));
  return v947_10;
}

static Space routine_108(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v956_10_branches = branches(c,s0);
  std::vector<Space> v956_10_outputs;
  v956_10_outputs.reserve(v956_10_branches.size());
  for (const auto& v956_10_branch : v956_10_branches) {
    const Path v956_10_head{v956_10_branch.first};
    const Space& v956_10_tail = v956_10_branch.second;
    const auto v957_2_branches = branches(c,v956_10_tail);
    std::vector<Space> v957_2_outputs;
    v957_2_outputs.reserve(v957_2_branches.size());
    for (const auto& v957_2_branch : v957_2_branches) {
      const Path v957_2_head{v957_2_branch.first};
      const Space& v957_2_tail = v957_2_branch.second;
      const Path v958_2 = concat_path(v956_10_head,v957_2_head);
      const auto v958_3_branches = branches(c,v957_2_tail);
      std::vector<Space> v958_3_outputs;
      v958_3_outputs.reserve(v958_3_branches.size());
      for (const auto& v958_3_branch : v958_3_branches) {
        const Path v958_3_head{v958_3_branch.first};
        const Space& v958_3_tail = v958_3_branch.second;
        const Path v959_2 = concat_path(v958_2,v958_3_head);
        const auto v959_3_branches = branches(c,v958_3_tail);
        std::vector<Space> v959_3_outputs;
        v959_3_outputs.reserve(v959_3_branches.size());
        for (const auto& v959_3_branch : v959_3_branches) {
          const Path v959_3_head{v959_3_branch.first};
          const Space& v959_3_tail = v959_3_branch.second;
          const Path v960_2 = concat_path(v959_2,v959_3_head);
          const auto v960_3_branches = branches(c,v959_3_tail);
          std::vector<Space> v960_3_outputs;
          v960_3_outputs.reserve(v960_3_branches.size());
          for (const auto& v960_3_branch : v960_3_branches) {
            const Path v960_3_head{v960_3_branch.first};
            const Space& v960_3_tail = v960_3_branch.second;
            const auto v961_2_branches = branches(c,v960_3_tail);
            std::vector<Space> v961_2_outputs;
            v961_2_outputs.reserve(v961_2_branches.size());
            for (const auto& v961_2_branch : v961_2_branches) {
              const Path v961_2_head{v961_2_branch.first};
              const Space& v961_2_tail = v961_2_branch.second;
              const Path v962_2 = concat_path(v960_3_head,v961_2_head);
              const auto v962_3_branches = branches(c,v961_2_tail);
              std::vector<Space> v962_3_outputs;
              v962_3_outputs.reserve(v962_3_branches.size());
              for (const auto& v962_3_branch : v962_3_branches) {
                const Path v962_3_head{v962_3_branch.first};
                const Space& v962_3_tail = v962_3_branch.second;
                const Path v963_2 = concat_path(v962_2,v962_3_head);
                const auto v963_3_branches = branches(c,v962_3_tail);
                std::vector<Space> v963_3_outputs;
                v963_3_outputs.reserve(v963_3_branches.size());
                for (const auto& v963_3_branch : v963_3_branches) {
                  const Path v963_3_head{v963_3_branch.first};
                  const Space& v963_3_tail = v963_3_branch.second;
                  const Path v964_2 = concat_path(v963_2,v963_3_head);
                  const Space v964_3 = routine_124(c, v964_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v960_2, v963_3_tail);
                  v963_3_outputs.push_back(v964_3);
                }
                const Space v963_3 = join_outputs(std::move(v963_3_outputs));
                v962_3_outputs.push_back(v963_3);
              }
              const Space v962_3 = join_outputs(std::move(v962_3_outputs));
              v961_2_outputs.push_back(v962_3);
            }
            const Space v961_2 = join_outputs(std::move(v961_2_outputs));
            v960_3_outputs.push_back(v961_2);
          }
          const Space v960_3 = join_outputs(std::move(v960_3_outputs));
          v959_3_outputs.push_back(v960_3);
        }
        const Space v959_3 = join_outputs(std::move(v959_3_outputs));
        v958_3_outputs.push_back(v959_3);
      }
      const Space v958_3 = join_outputs(std::move(v958_3_outputs));
      v957_2_outputs.push_back(v958_3);
    }
    const Space v957_2 = join_outputs(std::move(v957_2_outputs));
    v956_10_outputs.push_back(v957_2);
  }
  const Space v956_10 = join_outputs(std::move(v956_10_outputs));
  return v956_10;
}

static Space routine_109(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v965_10_branches = branches(c,s0);
  std::vector<Space> v965_10_outputs;
  v965_10_outputs.reserve(v965_10_branches.size());
  for (const auto& v965_10_branch : v965_10_branches) {
    const Path v965_10_head{v965_10_branch.first};
    const Space& v965_10_tail = v965_10_branch.second;
    const auto v966_2_branches = branches(c,v965_10_tail);
    std::vector<Space> v966_2_outputs;
    v966_2_outputs.reserve(v966_2_branches.size());
    for (const auto& v966_2_branch : v966_2_branches) {
      const Path v966_2_head{v966_2_branch.first};
      const Space& v966_2_tail = v966_2_branch.second;
      const Path v967_2 = concat_path(v965_10_head,v966_2_head);
      const auto v967_3_branches = branches(c,v966_2_tail);
      std::vector<Space> v967_3_outputs;
      v967_3_outputs.reserve(v967_3_branches.size());
      for (const auto& v967_3_branch : v967_3_branches) {
        const Path v967_3_head{v967_3_branch.first};
        const Space& v967_3_tail = v967_3_branch.second;
        const Path v968_2 = concat_path(v967_2,v967_3_head);
        const auto v968_3_branches = branches(c,v967_3_tail);
        std::vector<Space> v968_3_outputs;
        v968_3_outputs.reserve(v968_3_branches.size());
        for (const auto& v968_3_branch : v968_3_branches) {
          const Path v968_3_head{v968_3_branch.first};
          const Space& v968_3_tail = v968_3_branch.second;
          const Path v969_2 = concat_path(v968_2,v968_3_head);
          const auto v969_3_branches = branches(c,v968_3_tail);
          std::vector<Space> v969_3_outputs;
          v969_3_outputs.reserve(v969_3_branches.size());
          for (const auto& v969_3_branch : v969_3_branches) {
            const Path v969_3_head{v969_3_branch.first};
            const Space& v969_3_tail = v969_3_branch.second;
            const auto v970_2_branches = branches(c,v969_3_tail);
            std::vector<Space> v970_2_outputs;
            v970_2_outputs.reserve(v970_2_branches.size());
            for (const auto& v970_2_branch : v970_2_branches) {
              const Path v970_2_head{v970_2_branch.first};
              const Space& v970_2_tail = v970_2_branch.second;
              const Path v971_2 = concat_path(v969_3_head,v970_2_head);
              const auto v971_3_branches = branches(c,v970_2_tail);
              std::vector<Space> v971_3_outputs;
              v971_3_outputs.reserve(v971_3_branches.size());
              for (const auto& v971_3_branch : v971_3_branches) {
                const Path v971_3_head{v971_3_branch.first};
                const Space& v971_3_tail = v971_3_branch.second;
                const Path v972_2 = concat_path(v971_2,v971_3_head);
                const auto v972_3_branches = branches(c,v971_3_tail);
                std::vector<Space> v972_3_outputs;
                v972_3_outputs.reserve(v972_3_branches.size());
                for (const auto& v972_3_branch : v972_3_branches) {
                  const Path v972_3_head{v972_3_branch.first};
                  const Space& v972_3_tail = v972_3_branch.second;
                  const Path v973_2 = concat_path(v972_2,v972_3_head);
                  const Space v973_3 = routine_125(c, v973_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v969_2, v972_3_tail);
                  v972_3_outputs.push_back(v973_3);
                }
                const Space v972_3 = join_outputs(std::move(v972_3_outputs));
                v971_3_outputs.push_back(v972_3);
              }
              const Space v971_3 = join_outputs(std::move(v971_3_outputs));
              v970_2_outputs.push_back(v971_3);
            }
            const Space v970_2 = join_outputs(std::move(v970_2_outputs));
            v969_3_outputs.push_back(v970_2);
          }
          const Space v969_3 = join_outputs(std::move(v969_3_outputs));
          v968_3_outputs.push_back(v969_3);
        }
        const Space v968_3 = join_outputs(std::move(v968_3_outputs));
        v967_3_outputs.push_back(v968_3);
      }
      const Space v967_3 = join_outputs(std::move(v967_3_outputs));
      v966_2_outputs.push_back(v967_3);
    }
    const Space v966_2 = join_outputs(std::move(v966_2_outputs));
    v965_10_outputs.push_back(v966_2);
  }
  const Space v965_10 = join_outputs(std::move(v965_10_outputs));
  return v965_10;
}

static Space routine_110(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Space& s0) {
  const auto v974_10_branches = branches(c,s0);
  std::vector<Space> v974_10_outputs;
  v974_10_outputs.reserve(v974_10_branches.size());
  for (const auto& v974_10_branch : v974_10_branches) {
    const Path v974_10_head{v974_10_branch.first};
    const Space& v974_10_tail = v974_10_branch.second;
    const auto v975_2_branches = branches(c,v974_10_tail);
    std::vector<Space> v975_2_outputs;
    v975_2_outputs.reserve(v975_2_branches.size());
    for (const auto& v975_2_branch : v975_2_branches) {
      const Path v975_2_head{v975_2_branch.first};
      const Space& v975_2_tail = v975_2_branch.second;
      const Path v976_2 = concat_path(v974_10_head,v975_2_head);
      const auto v976_3_branches = branches(c,v975_2_tail);
      std::vector<Space> v976_3_outputs;
      v976_3_outputs.reserve(v976_3_branches.size());
      for (const auto& v976_3_branch : v976_3_branches) {
        const Path v976_3_head{v976_3_branch.first};
        const Space& v976_3_tail = v976_3_branch.second;
        const Path v977_2 = concat_path(v976_2,v976_3_head);
        const auto v977_3_branches = branches(c,v976_3_tail);
        std::vector<Space> v977_3_outputs;
        v977_3_outputs.reserve(v977_3_branches.size());
        for (const auto& v977_3_branch : v977_3_branches) {
          const Path v977_3_head{v977_3_branch.first};
          const Space& v977_3_tail = v977_3_branch.second;
          const Path v978_2 = concat_path(v977_2,v977_3_head);
          const auto v978_3_branches = branches(c,v977_3_tail);
          std::vector<Space> v978_3_outputs;
          v978_3_outputs.reserve(v978_3_branches.size());
          for (const auto& v978_3_branch : v978_3_branches) {
            const Path v978_3_head{v978_3_branch.first};
            const Space& v978_3_tail = v978_3_branch.second;
            const auto v979_2_branches = branches(c,v978_3_tail);
            std::vector<Space> v979_2_outputs;
            v979_2_outputs.reserve(v979_2_branches.size());
            for (const auto& v979_2_branch : v979_2_branches) {
              const Path v979_2_head{v979_2_branch.first};
              const Space& v979_2_tail = v979_2_branch.second;
              const Path v980_2 = concat_path(v978_3_head,v979_2_head);
              const auto v980_3_branches = branches(c,v979_2_tail);
              std::vector<Space> v980_3_outputs;
              v980_3_outputs.reserve(v980_3_branches.size());
              for (const auto& v980_3_branch : v980_3_branches) {
                const Path v980_3_head{v980_3_branch.first};
                const Space& v980_3_tail = v980_3_branch.second;
                const Path v981_2 = concat_path(v980_2,v980_3_head);
                const auto v981_3_branches = branches(c,v980_3_tail);
                std::vector<Space> v981_3_outputs;
                v981_3_outputs.reserve(v981_3_branches.size());
                for (const auto& v981_3_branch : v981_3_branches) {
                  const Path v981_3_head{v981_3_branch.first};
                  const Space& v981_3_tail = v981_3_branch.second;
                  const Path v982_2 = concat_path(v981_2,v981_3_head);
                  const Space v982_3 = routine_126(c, v982_2, p1, p2, p3, p4, p5, p6, p7, p8, p0, v978_2, v981_3_tail);
                  v981_3_outputs.push_back(v982_3);
                }
                const Space v981_3 = join_outputs(std::move(v981_3_outputs));
                v980_3_outputs.push_back(v981_3);
              }
              const Space v980_3 = join_outputs(std::move(v980_3_outputs));
              v979_2_outputs.push_back(v980_3);
            }
            const Space v979_2 = join_outputs(std::move(v979_2_outputs));
            v978_3_outputs.push_back(v979_2);
          }
          const Space v978_3 = join_outputs(std::move(v978_3_outputs));
          v977_3_outputs.push_back(v978_3);
        }
        const Space v977_3 = join_outputs(std::move(v977_3_outputs));
        v976_3_outputs.push_back(v977_3);
      }
      const Space v976_3 = join_outputs(std::move(v976_3_outputs));
      v975_2_outputs.push_back(v976_3);
    }
    const Space v975_2 = join_outputs(std::move(v975_2_outputs));
    v974_10_outputs.push_back(v975_2);
  }
  const Space v974_10 = join_outputs(std::move(v974_10_outputs));
  return v974_10;
}

static Space routine_111(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v983_12_branches = branches(c,s0);
  std::vector<Space> v983_12_outputs;
  v983_12_outputs.reserve(v983_12_branches.size());
  for (const auto& v983_12_branch : v983_12_branches) {
    const Path v983_12_head{v983_12_branch.first};
    const Space& v983_12_tail = v983_12_branch.second;
    const auto v984_2_branches = branches(c,v983_12_tail);
    std::vector<Space> v984_2_outputs;
    v984_2_outputs.reserve(v984_2_branches.size());
    for (const auto& v984_2_branch : v984_2_branches) {
      const Path v984_2_head{v984_2_branch.first};
      const Space& v984_2_tail = v984_2_branch.second;
      const Path v985_2 = concat_path(v983_12_head,v984_2_head);
      const auto v985_3_branches = branches(c,v984_2_tail);
      std::vector<Space> v985_3_outputs;
      v985_3_outputs.reserve(v985_3_branches.size());
      for (const auto& v985_3_branch : v985_3_branches) {
        const Path v985_3_head{v985_3_branch.first};
        const Space& v985_3_tail = v985_3_branch.second;
        const Path v986_2 = concat_path(v985_2,v985_3_head);
        const auto v986_3_branches = branches(c,v985_3_tail);
        std::vector<Space> v986_3_outputs;
        v986_3_outputs.reserve(v986_3_branches.size());
        for (const auto& v986_3_branch : v986_3_branches) {
          const Path v986_3_head{v986_3_branch.first};
          const Space& v986_3_tail = v986_3_branch.second;
          const Path v987_2 = concat_path(v986_2,v986_3_head);
          const auto v987_3_branches = branches(c,v986_3_tail);
          std::vector<Space> v987_3_outputs;
          v987_3_outputs.reserve(v987_3_branches.size());
          for (const auto& v987_3_branch : v987_3_branches) {
            const Path v987_3_head{v987_3_branch.first};
            const Space& v987_3_tail = v987_3_branch.second;
            const auto v988_2_branches = branches(c,v987_3_tail);
            std::vector<Space> v988_2_outputs;
            v988_2_outputs.reserve(v988_2_branches.size());
            for (const auto& v988_2_branch : v988_2_branches) {
              const Path v988_2_head{v988_2_branch.first};
              const Space& v988_2_tail = v988_2_branch.second;
              const Path v989_2 = concat_path(v987_3_head,v988_2_head);
              const auto v989_3_branches = branches(c,v988_2_tail);
              std::vector<Space> v989_3_outputs;
              v989_3_outputs.reserve(v989_3_branches.size());
              for (const auto& v989_3_branch : v989_3_branches) {
                const Path v989_3_head{v989_3_branch.first};
                const Space& v989_3_tail = v989_3_branch.second;
                const Path v990_2 = concat_path(v989_2,v989_3_head);
                const auto v990_3_branches = branches(c,v989_3_tail);
                std::vector<Space> v990_3_outputs;
                v990_3_outputs.reserve(v990_3_branches.size());
                for (const auto& v990_3_branch : v990_3_branches) {
                  const Path v990_3_head{v990_3_branch.first};
                  const Space& v990_3_tail = v990_3_branch.second;
                  const Path v991_2 = concat_path(v990_2,v990_3_head);
                  const Space v991_3 = routine_127(c, v991_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v987_2, v990_3_tail);
                  v990_3_outputs.push_back(v991_3);
                }
                const Space v990_3 = join_outputs(std::move(v990_3_outputs));
                v989_3_outputs.push_back(v990_3);
              }
              const Space v989_3 = join_outputs(std::move(v989_3_outputs));
              v988_2_outputs.push_back(v989_3);
            }
            const Space v988_2 = join_outputs(std::move(v988_2_outputs));
            v987_3_outputs.push_back(v988_2);
          }
          const Space v987_3 = join_outputs(std::move(v987_3_outputs));
          v986_3_outputs.push_back(v987_3);
        }
        const Space v986_3 = join_outputs(std::move(v986_3_outputs));
        v985_3_outputs.push_back(v986_3);
      }
      const Space v985_3 = join_outputs(std::move(v985_3_outputs));
      v984_2_outputs.push_back(v985_3);
    }
    const Space v984_2 = join_outputs(std::move(v984_2_outputs));
    v983_12_outputs.push_back(v984_2);
  }
  const Space v983_12 = join_outputs(std::move(v983_12_outputs));
  return v983_12;
}

static Space routine_112(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v992_12_branches = branches(c,s0);
  std::vector<Space> v992_12_outputs;
  v992_12_outputs.reserve(v992_12_branches.size());
  for (const auto& v992_12_branch : v992_12_branches) {
    const Path v992_12_head{v992_12_branch.first};
    const Space& v992_12_tail = v992_12_branch.second;
    const auto v993_2_branches = branches(c,v992_12_tail);
    std::vector<Space> v993_2_outputs;
    v993_2_outputs.reserve(v993_2_branches.size());
    for (const auto& v993_2_branch : v993_2_branches) {
      const Path v993_2_head{v993_2_branch.first};
      const Space& v993_2_tail = v993_2_branch.second;
      const Path v994_2 = concat_path(v992_12_head,v993_2_head);
      const auto v994_3_branches = branches(c,v993_2_tail);
      std::vector<Space> v994_3_outputs;
      v994_3_outputs.reserve(v994_3_branches.size());
      for (const auto& v994_3_branch : v994_3_branches) {
        const Path v994_3_head{v994_3_branch.first};
        const Space& v994_3_tail = v994_3_branch.second;
        const Path v995_2 = concat_path(v994_2,v994_3_head);
        const auto v995_3_branches = branches(c,v994_3_tail);
        std::vector<Space> v995_3_outputs;
        v995_3_outputs.reserve(v995_3_branches.size());
        for (const auto& v995_3_branch : v995_3_branches) {
          const Path v995_3_head{v995_3_branch.first};
          const Space& v995_3_tail = v995_3_branch.second;
          const Path v996_2 = concat_path(v995_2,v995_3_head);
          const auto v996_3_branches = branches(c,v995_3_tail);
          std::vector<Space> v996_3_outputs;
          v996_3_outputs.reserve(v996_3_branches.size());
          for (const auto& v996_3_branch : v996_3_branches) {
            const Path v996_3_head{v996_3_branch.first};
            const Space& v996_3_tail = v996_3_branch.second;
            const auto v997_2_branches = branches(c,v996_3_tail);
            std::vector<Space> v997_2_outputs;
            v997_2_outputs.reserve(v997_2_branches.size());
            for (const auto& v997_2_branch : v997_2_branches) {
              const Path v997_2_head{v997_2_branch.first};
              const Space& v997_2_tail = v997_2_branch.second;
              const Path v998_2 = concat_path(v996_3_head,v997_2_head);
              const auto v998_3_branches = branches(c,v997_2_tail);
              std::vector<Space> v998_3_outputs;
              v998_3_outputs.reserve(v998_3_branches.size());
              for (const auto& v998_3_branch : v998_3_branches) {
                const Path v998_3_head{v998_3_branch.first};
                const Space& v998_3_tail = v998_3_branch.second;
                const Path v999_2 = concat_path(v998_2,v998_3_head);
                const auto v999_3_branches = branches(c,v998_3_tail);
                std::vector<Space> v999_3_outputs;
                v999_3_outputs.reserve(v999_3_branches.size());
                for (const auto& v999_3_branch : v999_3_branches) {
                  const Path v999_3_head{v999_3_branch.first};
                  const Space& v999_3_tail = v999_3_branch.second;
                  const Path v1000_2 = concat_path(v999_2,v999_3_head);
                  const Space v1000_3 = routine_128(c, v1000_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v996_2, v999_3_tail);
                  v999_3_outputs.push_back(v1000_3);
                }
                const Space v999_3 = join_outputs(std::move(v999_3_outputs));
                v998_3_outputs.push_back(v999_3);
              }
              const Space v998_3 = join_outputs(std::move(v998_3_outputs));
              v997_2_outputs.push_back(v998_3);
            }
            const Space v997_2 = join_outputs(std::move(v997_2_outputs));
            v996_3_outputs.push_back(v997_2);
          }
          const Space v996_3 = join_outputs(std::move(v996_3_outputs));
          v995_3_outputs.push_back(v996_3);
        }
        const Space v995_3 = join_outputs(std::move(v995_3_outputs));
        v994_3_outputs.push_back(v995_3);
      }
      const Space v994_3 = join_outputs(std::move(v994_3_outputs));
      v993_2_outputs.push_back(v994_3);
    }
    const Space v993_2 = join_outputs(std::move(v993_2_outputs));
    v992_12_outputs.push_back(v993_2);
  }
  const Space v992_12 = join_outputs(std::move(v992_12_outputs));
  return v992_12;
}

static Space routine_113(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1001_12_branches = branches(c,s0);
  std::vector<Space> v1001_12_outputs;
  v1001_12_outputs.reserve(v1001_12_branches.size());
  for (const auto& v1001_12_branch : v1001_12_branches) {
    const Path v1001_12_head{v1001_12_branch.first};
    const Space& v1001_12_tail = v1001_12_branch.second;
    const auto v1002_2_branches = branches(c,v1001_12_tail);
    std::vector<Space> v1002_2_outputs;
    v1002_2_outputs.reserve(v1002_2_branches.size());
    for (const auto& v1002_2_branch : v1002_2_branches) {
      const Path v1002_2_head{v1002_2_branch.first};
      const Space& v1002_2_tail = v1002_2_branch.second;
      const Path v1003_2 = concat_path(v1001_12_head,v1002_2_head);
      const auto v1003_3_branches = branches(c,v1002_2_tail);
      std::vector<Space> v1003_3_outputs;
      v1003_3_outputs.reserve(v1003_3_branches.size());
      for (const auto& v1003_3_branch : v1003_3_branches) {
        const Path v1003_3_head{v1003_3_branch.first};
        const Space& v1003_3_tail = v1003_3_branch.second;
        const Path v1004_2 = concat_path(v1003_2,v1003_3_head);
        const auto v1004_3_branches = branches(c,v1003_3_tail);
        std::vector<Space> v1004_3_outputs;
        v1004_3_outputs.reserve(v1004_3_branches.size());
        for (const auto& v1004_3_branch : v1004_3_branches) {
          const Path v1004_3_head{v1004_3_branch.first};
          const Space& v1004_3_tail = v1004_3_branch.second;
          const Path v1005_2 = concat_path(v1004_2,v1004_3_head);
          const auto v1005_3_branches = branches(c,v1004_3_tail);
          std::vector<Space> v1005_3_outputs;
          v1005_3_outputs.reserve(v1005_3_branches.size());
          for (const auto& v1005_3_branch : v1005_3_branches) {
            const Path v1005_3_head{v1005_3_branch.first};
            const Space& v1005_3_tail = v1005_3_branch.second;
            const auto v1006_2_branches = branches(c,v1005_3_tail);
            std::vector<Space> v1006_2_outputs;
            v1006_2_outputs.reserve(v1006_2_branches.size());
            for (const auto& v1006_2_branch : v1006_2_branches) {
              const Path v1006_2_head{v1006_2_branch.first};
              const Space& v1006_2_tail = v1006_2_branch.second;
              const Path v1007_2 = concat_path(v1005_3_head,v1006_2_head);
              const auto v1007_3_branches = branches(c,v1006_2_tail);
              std::vector<Space> v1007_3_outputs;
              v1007_3_outputs.reserve(v1007_3_branches.size());
              for (const auto& v1007_3_branch : v1007_3_branches) {
                const Path v1007_3_head{v1007_3_branch.first};
                const Space& v1007_3_tail = v1007_3_branch.second;
                const Path v1008_2 = concat_path(v1007_2,v1007_3_head);
                const auto v1008_3_branches = branches(c,v1007_3_tail);
                std::vector<Space> v1008_3_outputs;
                v1008_3_outputs.reserve(v1008_3_branches.size());
                for (const auto& v1008_3_branch : v1008_3_branches) {
                  const Path v1008_3_head{v1008_3_branch.first};
                  const Space& v1008_3_tail = v1008_3_branch.second;
                  const Path v1009_2 = concat_path(v1008_2,v1008_3_head);
                  const Space v1009_3 = routine_129(c, v1009_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1005_2, v1008_3_tail);
                  v1008_3_outputs.push_back(v1009_3);
                }
                const Space v1008_3 = join_outputs(std::move(v1008_3_outputs));
                v1007_3_outputs.push_back(v1008_3);
              }
              const Space v1007_3 = join_outputs(std::move(v1007_3_outputs));
              v1006_2_outputs.push_back(v1007_3);
            }
            const Space v1006_2 = join_outputs(std::move(v1006_2_outputs));
            v1005_3_outputs.push_back(v1006_2);
          }
          const Space v1005_3 = join_outputs(std::move(v1005_3_outputs));
          v1004_3_outputs.push_back(v1005_3);
        }
        const Space v1004_3 = join_outputs(std::move(v1004_3_outputs));
        v1003_3_outputs.push_back(v1004_3);
      }
      const Space v1003_3 = join_outputs(std::move(v1003_3_outputs));
      v1002_2_outputs.push_back(v1003_3);
    }
    const Space v1002_2 = join_outputs(std::move(v1002_2_outputs));
    v1001_12_outputs.push_back(v1002_2);
  }
  const Space v1001_12 = join_outputs(std::move(v1001_12_outputs));
  return v1001_12;
}

static Space routine_114(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1010_12_branches = branches(c,s0);
  std::vector<Space> v1010_12_outputs;
  v1010_12_outputs.reserve(v1010_12_branches.size());
  for (const auto& v1010_12_branch : v1010_12_branches) {
    const Path v1010_12_head{v1010_12_branch.first};
    const Space& v1010_12_tail = v1010_12_branch.second;
    const auto v1011_2_branches = branches(c,v1010_12_tail);
    std::vector<Space> v1011_2_outputs;
    v1011_2_outputs.reserve(v1011_2_branches.size());
    for (const auto& v1011_2_branch : v1011_2_branches) {
      const Path v1011_2_head{v1011_2_branch.first};
      const Space& v1011_2_tail = v1011_2_branch.second;
      const Path v1012_2 = concat_path(v1010_12_head,v1011_2_head);
      const auto v1012_3_branches = branches(c,v1011_2_tail);
      std::vector<Space> v1012_3_outputs;
      v1012_3_outputs.reserve(v1012_3_branches.size());
      for (const auto& v1012_3_branch : v1012_3_branches) {
        const Path v1012_3_head{v1012_3_branch.first};
        const Space& v1012_3_tail = v1012_3_branch.second;
        const Path v1013_2 = concat_path(v1012_2,v1012_3_head);
        const auto v1013_3_branches = branches(c,v1012_3_tail);
        std::vector<Space> v1013_3_outputs;
        v1013_3_outputs.reserve(v1013_3_branches.size());
        for (const auto& v1013_3_branch : v1013_3_branches) {
          const Path v1013_3_head{v1013_3_branch.first};
          const Space& v1013_3_tail = v1013_3_branch.second;
          const Path v1014_2 = concat_path(v1013_2,v1013_3_head);
          const auto v1014_3_branches = branches(c,v1013_3_tail);
          std::vector<Space> v1014_3_outputs;
          v1014_3_outputs.reserve(v1014_3_branches.size());
          for (const auto& v1014_3_branch : v1014_3_branches) {
            const Path v1014_3_head{v1014_3_branch.first};
            const Space& v1014_3_tail = v1014_3_branch.second;
            const auto v1015_2_branches = branches(c,v1014_3_tail);
            std::vector<Space> v1015_2_outputs;
            v1015_2_outputs.reserve(v1015_2_branches.size());
            for (const auto& v1015_2_branch : v1015_2_branches) {
              const Path v1015_2_head{v1015_2_branch.first};
              const Space& v1015_2_tail = v1015_2_branch.second;
              const Path v1016_2 = concat_path(v1014_3_head,v1015_2_head);
              const auto v1016_3_branches = branches(c,v1015_2_tail);
              std::vector<Space> v1016_3_outputs;
              v1016_3_outputs.reserve(v1016_3_branches.size());
              for (const auto& v1016_3_branch : v1016_3_branches) {
                const Path v1016_3_head{v1016_3_branch.first};
                const Space& v1016_3_tail = v1016_3_branch.second;
                const Path v1017_2 = concat_path(v1016_2,v1016_3_head);
                const auto v1017_3_branches = branches(c,v1016_3_tail);
                std::vector<Space> v1017_3_outputs;
                v1017_3_outputs.reserve(v1017_3_branches.size());
                for (const auto& v1017_3_branch : v1017_3_branches) {
                  const Path v1017_3_head{v1017_3_branch.first};
                  const Space& v1017_3_tail = v1017_3_branch.second;
                  const Path v1018_2 = concat_path(v1017_2,v1017_3_head);
                  const Space v1018_3 = routine_130(c, v1018_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1014_2, v1017_3_tail);
                  v1017_3_outputs.push_back(v1018_3);
                }
                const Space v1017_3 = join_outputs(std::move(v1017_3_outputs));
                v1016_3_outputs.push_back(v1017_3);
              }
              const Space v1016_3 = join_outputs(std::move(v1016_3_outputs));
              v1015_2_outputs.push_back(v1016_3);
            }
            const Space v1015_2 = join_outputs(std::move(v1015_2_outputs));
            v1014_3_outputs.push_back(v1015_2);
          }
          const Space v1014_3 = join_outputs(std::move(v1014_3_outputs));
          v1013_3_outputs.push_back(v1014_3);
        }
        const Space v1013_3 = join_outputs(std::move(v1013_3_outputs));
        v1012_3_outputs.push_back(v1013_3);
      }
      const Space v1012_3 = join_outputs(std::move(v1012_3_outputs));
      v1011_2_outputs.push_back(v1012_3);
    }
    const Space v1011_2 = join_outputs(std::move(v1011_2_outputs));
    v1010_12_outputs.push_back(v1011_2);
  }
  const Space v1010_12 = join_outputs(std::move(v1010_12_outputs));
  return v1010_12;
}

static Space routine_115(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1019_12_branches = branches(c,s0);
  std::vector<Space> v1019_12_outputs;
  v1019_12_outputs.reserve(v1019_12_branches.size());
  for (const auto& v1019_12_branch : v1019_12_branches) {
    const Path v1019_12_head{v1019_12_branch.first};
    const Space& v1019_12_tail = v1019_12_branch.second;
    const auto v1020_2_branches = branches(c,v1019_12_tail);
    std::vector<Space> v1020_2_outputs;
    v1020_2_outputs.reserve(v1020_2_branches.size());
    for (const auto& v1020_2_branch : v1020_2_branches) {
      const Path v1020_2_head{v1020_2_branch.first};
      const Space& v1020_2_tail = v1020_2_branch.second;
      const Path v1021_2 = concat_path(v1019_12_head,v1020_2_head);
      const auto v1021_3_branches = branches(c,v1020_2_tail);
      std::vector<Space> v1021_3_outputs;
      v1021_3_outputs.reserve(v1021_3_branches.size());
      for (const auto& v1021_3_branch : v1021_3_branches) {
        const Path v1021_3_head{v1021_3_branch.first};
        const Space& v1021_3_tail = v1021_3_branch.second;
        const Path v1022_2 = concat_path(v1021_2,v1021_3_head);
        const auto v1022_3_branches = branches(c,v1021_3_tail);
        std::vector<Space> v1022_3_outputs;
        v1022_3_outputs.reserve(v1022_3_branches.size());
        for (const auto& v1022_3_branch : v1022_3_branches) {
          const Path v1022_3_head{v1022_3_branch.first};
          const Space& v1022_3_tail = v1022_3_branch.second;
          const Path v1023_2 = concat_path(v1022_2,v1022_3_head);
          const auto v1023_3_branches = branches(c,v1022_3_tail);
          std::vector<Space> v1023_3_outputs;
          v1023_3_outputs.reserve(v1023_3_branches.size());
          for (const auto& v1023_3_branch : v1023_3_branches) {
            const Path v1023_3_head{v1023_3_branch.first};
            const Space& v1023_3_tail = v1023_3_branch.second;
            const auto v1024_2_branches = branches(c,v1023_3_tail);
            std::vector<Space> v1024_2_outputs;
            v1024_2_outputs.reserve(v1024_2_branches.size());
            for (const auto& v1024_2_branch : v1024_2_branches) {
              const Path v1024_2_head{v1024_2_branch.first};
              const Space& v1024_2_tail = v1024_2_branch.second;
              const Path v1025_2 = concat_path(v1023_3_head,v1024_2_head);
              const auto v1025_3_branches = branches(c,v1024_2_tail);
              std::vector<Space> v1025_3_outputs;
              v1025_3_outputs.reserve(v1025_3_branches.size());
              for (const auto& v1025_3_branch : v1025_3_branches) {
                const Path v1025_3_head{v1025_3_branch.first};
                const Space& v1025_3_tail = v1025_3_branch.second;
                const Path v1026_2 = concat_path(v1025_2,v1025_3_head);
                const auto v1026_3_branches = branches(c,v1025_3_tail);
                std::vector<Space> v1026_3_outputs;
                v1026_3_outputs.reserve(v1026_3_branches.size());
                for (const auto& v1026_3_branch : v1026_3_branches) {
                  const Path v1026_3_head{v1026_3_branch.first};
                  const Space& v1026_3_tail = v1026_3_branch.second;
                  const Path v1027_2 = concat_path(v1026_2,v1026_3_head);
                  const Space v1027_3 = routine_131(c, v1027_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1023_2, v1026_3_tail);
                  v1026_3_outputs.push_back(v1027_3);
                }
                const Space v1026_3 = join_outputs(std::move(v1026_3_outputs));
                v1025_3_outputs.push_back(v1026_3);
              }
              const Space v1025_3 = join_outputs(std::move(v1025_3_outputs));
              v1024_2_outputs.push_back(v1025_3);
            }
            const Space v1024_2 = join_outputs(std::move(v1024_2_outputs));
            v1023_3_outputs.push_back(v1024_2);
          }
          const Space v1023_3 = join_outputs(std::move(v1023_3_outputs));
          v1022_3_outputs.push_back(v1023_3);
        }
        const Space v1022_3 = join_outputs(std::move(v1022_3_outputs));
        v1021_3_outputs.push_back(v1022_3);
      }
      const Space v1021_3 = join_outputs(std::move(v1021_3_outputs));
      v1020_2_outputs.push_back(v1021_3);
    }
    const Space v1020_2 = join_outputs(std::move(v1020_2_outputs));
    v1019_12_outputs.push_back(v1020_2);
  }
  const Space v1019_12 = join_outputs(std::move(v1019_12_outputs));
  return v1019_12;
}

static Space routine_116(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1028_12_branches = branches(c,s0);
  std::vector<Space> v1028_12_outputs;
  v1028_12_outputs.reserve(v1028_12_branches.size());
  for (const auto& v1028_12_branch : v1028_12_branches) {
    const Path v1028_12_head{v1028_12_branch.first};
    const Space& v1028_12_tail = v1028_12_branch.second;
    const auto v1029_2_branches = branches(c,v1028_12_tail);
    std::vector<Space> v1029_2_outputs;
    v1029_2_outputs.reserve(v1029_2_branches.size());
    for (const auto& v1029_2_branch : v1029_2_branches) {
      const Path v1029_2_head{v1029_2_branch.first};
      const Space& v1029_2_tail = v1029_2_branch.second;
      const Path v1030_2 = concat_path(v1028_12_head,v1029_2_head);
      const auto v1030_3_branches = branches(c,v1029_2_tail);
      std::vector<Space> v1030_3_outputs;
      v1030_3_outputs.reserve(v1030_3_branches.size());
      for (const auto& v1030_3_branch : v1030_3_branches) {
        const Path v1030_3_head{v1030_3_branch.first};
        const Space& v1030_3_tail = v1030_3_branch.second;
        const Path v1031_2 = concat_path(v1030_2,v1030_3_head);
        const auto v1031_3_branches = branches(c,v1030_3_tail);
        std::vector<Space> v1031_3_outputs;
        v1031_3_outputs.reserve(v1031_3_branches.size());
        for (const auto& v1031_3_branch : v1031_3_branches) {
          const Path v1031_3_head{v1031_3_branch.first};
          const Space& v1031_3_tail = v1031_3_branch.second;
          const Path v1032_2 = concat_path(v1031_2,v1031_3_head);
          const auto v1032_3_branches = branches(c,v1031_3_tail);
          std::vector<Space> v1032_3_outputs;
          v1032_3_outputs.reserve(v1032_3_branches.size());
          for (const auto& v1032_3_branch : v1032_3_branches) {
            const Path v1032_3_head{v1032_3_branch.first};
            const Space& v1032_3_tail = v1032_3_branch.second;
            const auto v1033_2_branches = branches(c,v1032_3_tail);
            std::vector<Space> v1033_2_outputs;
            v1033_2_outputs.reserve(v1033_2_branches.size());
            for (const auto& v1033_2_branch : v1033_2_branches) {
              const Path v1033_2_head{v1033_2_branch.first};
              const Space& v1033_2_tail = v1033_2_branch.second;
              const Path v1034_2 = concat_path(v1032_3_head,v1033_2_head);
              const auto v1034_3_branches = branches(c,v1033_2_tail);
              std::vector<Space> v1034_3_outputs;
              v1034_3_outputs.reserve(v1034_3_branches.size());
              for (const auto& v1034_3_branch : v1034_3_branches) {
                const Path v1034_3_head{v1034_3_branch.first};
                const Space& v1034_3_tail = v1034_3_branch.second;
                const Path v1035_2 = concat_path(v1034_2,v1034_3_head);
                const auto v1035_3_branches = branches(c,v1034_3_tail);
                std::vector<Space> v1035_3_outputs;
                v1035_3_outputs.reserve(v1035_3_branches.size());
                for (const auto& v1035_3_branch : v1035_3_branches) {
                  const Path v1035_3_head{v1035_3_branch.first};
                  const Space& v1035_3_tail = v1035_3_branch.second;
                  const Path v1036_2 = concat_path(v1035_2,v1035_3_head);
                  const Space v1036_3 = routine_132(c, v1036_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1032_2, v1035_3_tail);
                  v1035_3_outputs.push_back(v1036_3);
                }
                const Space v1035_3 = join_outputs(std::move(v1035_3_outputs));
                v1034_3_outputs.push_back(v1035_3);
              }
              const Space v1034_3 = join_outputs(std::move(v1034_3_outputs));
              v1033_2_outputs.push_back(v1034_3);
            }
            const Space v1033_2 = join_outputs(std::move(v1033_2_outputs));
            v1032_3_outputs.push_back(v1033_2);
          }
          const Space v1032_3 = join_outputs(std::move(v1032_3_outputs));
          v1031_3_outputs.push_back(v1032_3);
        }
        const Space v1031_3 = join_outputs(std::move(v1031_3_outputs));
        v1030_3_outputs.push_back(v1031_3);
      }
      const Space v1030_3 = join_outputs(std::move(v1030_3_outputs));
      v1029_2_outputs.push_back(v1030_3);
    }
    const Space v1029_2 = join_outputs(std::move(v1029_2_outputs));
    v1028_12_outputs.push_back(v1029_2);
  }
  const Space v1028_12 = join_outputs(std::move(v1028_12_outputs));
  return v1028_12;
}

static Space routine_117(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1037_12_branches = branches(c,s0);
  std::vector<Space> v1037_12_outputs;
  v1037_12_outputs.reserve(v1037_12_branches.size());
  for (const auto& v1037_12_branch : v1037_12_branches) {
    const Path v1037_12_head{v1037_12_branch.first};
    const Space& v1037_12_tail = v1037_12_branch.second;
    const auto v1038_2_branches = branches(c,v1037_12_tail);
    std::vector<Space> v1038_2_outputs;
    v1038_2_outputs.reserve(v1038_2_branches.size());
    for (const auto& v1038_2_branch : v1038_2_branches) {
      const Path v1038_2_head{v1038_2_branch.first};
      const Space& v1038_2_tail = v1038_2_branch.second;
      const Path v1039_2 = concat_path(v1037_12_head,v1038_2_head);
      const auto v1039_3_branches = branches(c,v1038_2_tail);
      std::vector<Space> v1039_3_outputs;
      v1039_3_outputs.reserve(v1039_3_branches.size());
      for (const auto& v1039_3_branch : v1039_3_branches) {
        const Path v1039_3_head{v1039_3_branch.first};
        const Space& v1039_3_tail = v1039_3_branch.second;
        const Path v1040_2 = concat_path(v1039_2,v1039_3_head);
        const auto v1040_3_branches = branches(c,v1039_3_tail);
        std::vector<Space> v1040_3_outputs;
        v1040_3_outputs.reserve(v1040_3_branches.size());
        for (const auto& v1040_3_branch : v1040_3_branches) {
          const Path v1040_3_head{v1040_3_branch.first};
          const Space& v1040_3_tail = v1040_3_branch.second;
          const Path v1041_2 = concat_path(v1040_2,v1040_3_head);
          const auto v1041_3_branches = branches(c,v1040_3_tail);
          std::vector<Space> v1041_3_outputs;
          v1041_3_outputs.reserve(v1041_3_branches.size());
          for (const auto& v1041_3_branch : v1041_3_branches) {
            const Path v1041_3_head{v1041_3_branch.first};
            const Space& v1041_3_tail = v1041_3_branch.second;
            const auto v1042_2_branches = branches(c,v1041_3_tail);
            std::vector<Space> v1042_2_outputs;
            v1042_2_outputs.reserve(v1042_2_branches.size());
            for (const auto& v1042_2_branch : v1042_2_branches) {
              const Path v1042_2_head{v1042_2_branch.first};
              const Space& v1042_2_tail = v1042_2_branch.second;
              const Path v1043_2 = concat_path(v1041_3_head,v1042_2_head);
              const auto v1043_3_branches = branches(c,v1042_2_tail);
              std::vector<Space> v1043_3_outputs;
              v1043_3_outputs.reserve(v1043_3_branches.size());
              for (const auto& v1043_3_branch : v1043_3_branches) {
                const Path v1043_3_head{v1043_3_branch.first};
                const Space& v1043_3_tail = v1043_3_branch.second;
                const Path v1044_2 = concat_path(v1043_2,v1043_3_head);
                const auto v1044_3_branches = branches(c,v1043_3_tail);
                std::vector<Space> v1044_3_outputs;
                v1044_3_outputs.reserve(v1044_3_branches.size());
                for (const auto& v1044_3_branch : v1044_3_branches) {
                  const Path v1044_3_head{v1044_3_branch.first};
                  const Space& v1044_3_tail = v1044_3_branch.second;
                  const Path v1045_2 = concat_path(v1044_2,v1044_3_head);
                  const Space v1045_3 = routine_133(c, v1045_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1041_2, v1044_3_tail);
                  v1044_3_outputs.push_back(v1045_3);
                }
                const Space v1044_3 = join_outputs(std::move(v1044_3_outputs));
                v1043_3_outputs.push_back(v1044_3);
              }
              const Space v1043_3 = join_outputs(std::move(v1043_3_outputs));
              v1042_2_outputs.push_back(v1043_3);
            }
            const Space v1042_2 = join_outputs(std::move(v1042_2_outputs));
            v1041_3_outputs.push_back(v1042_2);
          }
          const Space v1041_3 = join_outputs(std::move(v1041_3_outputs));
          v1040_3_outputs.push_back(v1041_3);
        }
        const Space v1040_3 = join_outputs(std::move(v1040_3_outputs));
        v1039_3_outputs.push_back(v1040_3);
      }
      const Space v1039_3 = join_outputs(std::move(v1039_3_outputs));
      v1038_2_outputs.push_back(v1039_3);
    }
    const Space v1038_2 = join_outputs(std::move(v1038_2_outputs));
    v1037_12_outputs.push_back(v1038_2);
  }
  const Space v1037_12 = join_outputs(std::move(v1037_12_outputs));
  return v1037_12;
}

static Space routine_118(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1046_12_branches = branches(c,s0);
  std::vector<Space> v1046_12_outputs;
  v1046_12_outputs.reserve(v1046_12_branches.size());
  for (const auto& v1046_12_branch : v1046_12_branches) {
    const Path v1046_12_head{v1046_12_branch.first};
    const Space& v1046_12_tail = v1046_12_branch.second;
    const auto v1047_2_branches = branches(c,v1046_12_tail);
    std::vector<Space> v1047_2_outputs;
    v1047_2_outputs.reserve(v1047_2_branches.size());
    for (const auto& v1047_2_branch : v1047_2_branches) {
      const Path v1047_2_head{v1047_2_branch.first};
      const Space& v1047_2_tail = v1047_2_branch.second;
      const Path v1048_2 = concat_path(v1046_12_head,v1047_2_head);
      const auto v1048_3_branches = branches(c,v1047_2_tail);
      std::vector<Space> v1048_3_outputs;
      v1048_3_outputs.reserve(v1048_3_branches.size());
      for (const auto& v1048_3_branch : v1048_3_branches) {
        const Path v1048_3_head{v1048_3_branch.first};
        const Space& v1048_3_tail = v1048_3_branch.second;
        const Path v1049_2 = concat_path(v1048_2,v1048_3_head);
        const auto v1049_3_branches = branches(c,v1048_3_tail);
        std::vector<Space> v1049_3_outputs;
        v1049_3_outputs.reserve(v1049_3_branches.size());
        for (const auto& v1049_3_branch : v1049_3_branches) {
          const Path v1049_3_head{v1049_3_branch.first};
          const Space& v1049_3_tail = v1049_3_branch.second;
          const Path v1050_2 = concat_path(v1049_2,v1049_3_head);
          const auto v1050_3_branches = branches(c,v1049_3_tail);
          std::vector<Space> v1050_3_outputs;
          v1050_3_outputs.reserve(v1050_3_branches.size());
          for (const auto& v1050_3_branch : v1050_3_branches) {
            const Path v1050_3_head{v1050_3_branch.first};
            const Space& v1050_3_tail = v1050_3_branch.second;
            const auto v1051_2_branches = branches(c,v1050_3_tail);
            std::vector<Space> v1051_2_outputs;
            v1051_2_outputs.reserve(v1051_2_branches.size());
            for (const auto& v1051_2_branch : v1051_2_branches) {
              const Path v1051_2_head{v1051_2_branch.first};
              const Space& v1051_2_tail = v1051_2_branch.second;
              const Path v1052_2 = concat_path(v1050_3_head,v1051_2_head);
              const auto v1052_3_branches = branches(c,v1051_2_tail);
              std::vector<Space> v1052_3_outputs;
              v1052_3_outputs.reserve(v1052_3_branches.size());
              for (const auto& v1052_3_branch : v1052_3_branches) {
                const Path v1052_3_head{v1052_3_branch.first};
                const Space& v1052_3_tail = v1052_3_branch.second;
                const Path v1053_2 = concat_path(v1052_2,v1052_3_head);
                const auto v1053_3_branches = branches(c,v1052_3_tail);
                std::vector<Space> v1053_3_outputs;
                v1053_3_outputs.reserve(v1053_3_branches.size());
                for (const auto& v1053_3_branch : v1053_3_branches) {
                  const Path v1053_3_head{v1053_3_branch.first};
                  const Space& v1053_3_tail = v1053_3_branch.second;
                  const Path v1054_2 = concat_path(v1053_2,v1053_3_head);
                  const Space v1054_3 = routine_134(c, v1054_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1050_2, v1053_3_tail);
                  v1053_3_outputs.push_back(v1054_3);
                }
                const Space v1053_3 = join_outputs(std::move(v1053_3_outputs));
                v1052_3_outputs.push_back(v1053_3);
              }
              const Space v1052_3 = join_outputs(std::move(v1052_3_outputs));
              v1051_2_outputs.push_back(v1052_3);
            }
            const Space v1051_2 = join_outputs(std::move(v1051_2_outputs));
            v1050_3_outputs.push_back(v1051_2);
          }
          const Space v1050_3 = join_outputs(std::move(v1050_3_outputs));
          v1049_3_outputs.push_back(v1050_3);
        }
        const Space v1049_3 = join_outputs(std::move(v1049_3_outputs));
        v1048_3_outputs.push_back(v1049_3);
      }
      const Space v1048_3 = join_outputs(std::move(v1048_3_outputs));
      v1047_2_outputs.push_back(v1048_3);
    }
    const Space v1047_2 = join_outputs(std::move(v1047_2_outputs));
    v1046_12_outputs.push_back(v1047_2);
  }
  const Space v1046_12 = join_outputs(std::move(v1046_12_outputs));
  return v1046_12;
}

static Space routine_119(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1055_12_branches = branches(c,s0);
  std::vector<Space> v1055_12_outputs;
  v1055_12_outputs.reserve(v1055_12_branches.size());
  for (const auto& v1055_12_branch : v1055_12_branches) {
    const Path v1055_12_head{v1055_12_branch.first};
    const Space& v1055_12_tail = v1055_12_branch.second;
    const auto v1056_2_branches = branches(c,v1055_12_tail);
    std::vector<Space> v1056_2_outputs;
    v1056_2_outputs.reserve(v1056_2_branches.size());
    for (const auto& v1056_2_branch : v1056_2_branches) {
      const Path v1056_2_head{v1056_2_branch.first};
      const Space& v1056_2_tail = v1056_2_branch.second;
      const Path v1057_2 = concat_path(v1055_12_head,v1056_2_head);
      const auto v1057_3_branches = branches(c,v1056_2_tail);
      std::vector<Space> v1057_3_outputs;
      v1057_3_outputs.reserve(v1057_3_branches.size());
      for (const auto& v1057_3_branch : v1057_3_branches) {
        const Path v1057_3_head{v1057_3_branch.first};
        const Space& v1057_3_tail = v1057_3_branch.second;
        const Path v1058_2 = concat_path(v1057_2,v1057_3_head);
        const auto v1058_3_branches = branches(c,v1057_3_tail);
        std::vector<Space> v1058_3_outputs;
        v1058_3_outputs.reserve(v1058_3_branches.size());
        for (const auto& v1058_3_branch : v1058_3_branches) {
          const Path v1058_3_head{v1058_3_branch.first};
          const Space& v1058_3_tail = v1058_3_branch.second;
          const Path v1059_2 = concat_path(v1058_2,v1058_3_head);
          const auto v1059_3_branches = branches(c,v1058_3_tail);
          std::vector<Space> v1059_3_outputs;
          v1059_3_outputs.reserve(v1059_3_branches.size());
          for (const auto& v1059_3_branch : v1059_3_branches) {
            const Path v1059_3_head{v1059_3_branch.first};
            const Space& v1059_3_tail = v1059_3_branch.second;
            const auto v1060_2_branches = branches(c,v1059_3_tail);
            std::vector<Space> v1060_2_outputs;
            v1060_2_outputs.reserve(v1060_2_branches.size());
            for (const auto& v1060_2_branch : v1060_2_branches) {
              const Path v1060_2_head{v1060_2_branch.first};
              const Space& v1060_2_tail = v1060_2_branch.second;
              const Path v1061_2 = concat_path(v1059_3_head,v1060_2_head);
              const auto v1061_3_branches = branches(c,v1060_2_tail);
              std::vector<Space> v1061_3_outputs;
              v1061_3_outputs.reserve(v1061_3_branches.size());
              for (const auto& v1061_3_branch : v1061_3_branches) {
                const Path v1061_3_head{v1061_3_branch.first};
                const Space& v1061_3_tail = v1061_3_branch.second;
                const Path v1062_2 = concat_path(v1061_2,v1061_3_head);
                const auto v1062_3_branches = branches(c,v1061_3_tail);
                std::vector<Space> v1062_3_outputs;
                v1062_3_outputs.reserve(v1062_3_branches.size());
                for (const auto& v1062_3_branch : v1062_3_branches) {
                  const Path v1062_3_head{v1062_3_branch.first};
                  const Space& v1062_3_tail = v1062_3_branch.second;
                  const Path v1063_2 = concat_path(v1062_2,v1062_3_head);
                  const Space v1063_3 = routine_135(c, v1063_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1059_2, v1062_3_tail);
                  v1062_3_outputs.push_back(v1063_3);
                }
                const Space v1062_3 = join_outputs(std::move(v1062_3_outputs));
                v1061_3_outputs.push_back(v1062_3);
              }
              const Space v1061_3 = join_outputs(std::move(v1061_3_outputs));
              v1060_2_outputs.push_back(v1061_3);
            }
            const Space v1060_2 = join_outputs(std::move(v1060_2_outputs));
            v1059_3_outputs.push_back(v1060_2);
          }
          const Space v1059_3 = join_outputs(std::move(v1059_3_outputs));
          v1058_3_outputs.push_back(v1059_3);
        }
        const Space v1058_3 = join_outputs(std::move(v1058_3_outputs));
        v1057_3_outputs.push_back(v1058_3);
      }
      const Space v1057_3 = join_outputs(std::move(v1057_3_outputs));
      v1056_2_outputs.push_back(v1057_3);
    }
    const Space v1056_2 = join_outputs(std::move(v1056_2_outputs));
    v1055_12_outputs.push_back(v1056_2);
  }
  const Space v1055_12 = join_outputs(std::move(v1055_12_outputs));
  return v1055_12;
}

static Space routine_120(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1064_12_branches = branches(c,s0);
  std::vector<Space> v1064_12_outputs;
  v1064_12_outputs.reserve(v1064_12_branches.size());
  for (const auto& v1064_12_branch : v1064_12_branches) {
    const Path v1064_12_head{v1064_12_branch.first};
    const Space& v1064_12_tail = v1064_12_branch.second;
    const auto v1065_2_branches = branches(c,v1064_12_tail);
    std::vector<Space> v1065_2_outputs;
    v1065_2_outputs.reserve(v1065_2_branches.size());
    for (const auto& v1065_2_branch : v1065_2_branches) {
      const Path v1065_2_head{v1065_2_branch.first};
      const Space& v1065_2_tail = v1065_2_branch.second;
      const Path v1066_2 = concat_path(v1064_12_head,v1065_2_head);
      const auto v1066_3_branches = branches(c,v1065_2_tail);
      std::vector<Space> v1066_3_outputs;
      v1066_3_outputs.reserve(v1066_3_branches.size());
      for (const auto& v1066_3_branch : v1066_3_branches) {
        const Path v1066_3_head{v1066_3_branch.first};
        const Space& v1066_3_tail = v1066_3_branch.second;
        const Path v1067_2 = concat_path(v1066_2,v1066_3_head);
        const auto v1067_3_branches = branches(c,v1066_3_tail);
        std::vector<Space> v1067_3_outputs;
        v1067_3_outputs.reserve(v1067_3_branches.size());
        for (const auto& v1067_3_branch : v1067_3_branches) {
          const Path v1067_3_head{v1067_3_branch.first};
          const Space& v1067_3_tail = v1067_3_branch.second;
          const Path v1068_2 = concat_path(v1067_2,v1067_3_head);
          const auto v1068_3_branches = branches(c,v1067_3_tail);
          std::vector<Space> v1068_3_outputs;
          v1068_3_outputs.reserve(v1068_3_branches.size());
          for (const auto& v1068_3_branch : v1068_3_branches) {
            const Path v1068_3_head{v1068_3_branch.first};
            const Space& v1068_3_tail = v1068_3_branch.second;
            const auto v1069_2_branches = branches(c,v1068_3_tail);
            std::vector<Space> v1069_2_outputs;
            v1069_2_outputs.reserve(v1069_2_branches.size());
            for (const auto& v1069_2_branch : v1069_2_branches) {
              const Path v1069_2_head{v1069_2_branch.first};
              const Space& v1069_2_tail = v1069_2_branch.second;
              const Path v1070_2 = concat_path(v1068_3_head,v1069_2_head);
              const auto v1070_3_branches = branches(c,v1069_2_tail);
              std::vector<Space> v1070_3_outputs;
              v1070_3_outputs.reserve(v1070_3_branches.size());
              for (const auto& v1070_3_branch : v1070_3_branches) {
                const Path v1070_3_head{v1070_3_branch.first};
                const Space& v1070_3_tail = v1070_3_branch.second;
                const Path v1071_2 = concat_path(v1070_2,v1070_3_head);
                const auto v1071_3_branches = branches(c,v1070_3_tail);
                std::vector<Space> v1071_3_outputs;
                v1071_3_outputs.reserve(v1071_3_branches.size());
                for (const auto& v1071_3_branch : v1071_3_branches) {
                  const Path v1071_3_head{v1071_3_branch.first};
                  const Space& v1071_3_tail = v1071_3_branch.second;
                  const Path v1072_2 = concat_path(v1071_2,v1071_3_head);
                  const Space v1072_3 = routine_136(c, v1072_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1068_2, v1071_3_tail);
                  v1071_3_outputs.push_back(v1072_3);
                }
                const Space v1071_3 = join_outputs(std::move(v1071_3_outputs));
                v1070_3_outputs.push_back(v1071_3);
              }
              const Space v1070_3 = join_outputs(std::move(v1070_3_outputs));
              v1069_2_outputs.push_back(v1070_3);
            }
            const Space v1069_2 = join_outputs(std::move(v1069_2_outputs));
            v1068_3_outputs.push_back(v1069_2);
          }
          const Space v1068_3 = join_outputs(std::move(v1068_3_outputs));
          v1067_3_outputs.push_back(v1068_3);
        }
        const Space v1067_3 = join_outputs(std::move(v1067_3_outputs));
        v1066_3_outputs.push_back(v1067_3);
      }
      const Space v1066_3 = join_outputs(std::move(v1066_3_outputs));
      v1065_2_outputs.push_back(v1066_3);
    }
    const Space v1065_2 = join_outputs(std::move(v1065_2_outputs));
    v1064_12_outputs.push_back(v1065_2);
  }
  const Space v1064_12 = join_outputs(std::move(v1064_12_outputs));
  return v1064_12;
}

static Space routine_121(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1073_12_branches = branches(c,s0);
  std::vector<Space> v1073_12_outputs;
  v1073_12_outputs.reserve(v1073_12_branches.size());
  for (const auto& v1073_12_branch : v1073_12_branches) {
    const Path v1073_12_head{v1073_12_branch.first};
    const Space& v1073_12_tail = v1073_12_branch.second;
    const auto v1074_2_branches = branches(c,v1073_12_tail);
    std::vector<Space> v1074_2_outputs;
    v1074_2_outputs.reserve(v1074_2_branches.size());
    for (const auto& v1074_2_branch : v1074_2_branches) {
      const Path v1074_2_head{v1074_2_branch.first};
      const Space& v1074_2_tail = v1074_2_branch.second;
      const Path v1075_2 = concat_path(v1073_12_head,v1074_2_head);
      const auto v1075_3_branches = branches(c,v1074_2_tail);
      std::vector<Space> v1075_3_outputs;
      v1075_3_outputs.reserve(v1075_3_branches.size());
      for (const auto& v1075_3_branch : v1075_3_branches) {
        const Path v1075_3_head{v1075_3_branch.first};
        const Space& v1075_3_tail = v1075_3_branch.second;
        const Path v1076_2 = concat_path(v1075_2,v1075_3_head);
        const auto v1076_3_branches = branches(c,v1075_3_tail);
        std::vector<Space> v1076_3_outputs;
        v1076_3_outputs.reserve(v1076_3_branches.size());
        for (const auto& v1076_3_branch : v1076_3_branches) {
          const Path v1076_3_head{v1076_3_branch.first};
          const Space& v1076_3_tail = v1076_3_branch.second;
          const Path v1077_2 = concat_path(v1076_2,v1076_3_head);
          const auto v1077_3_branches = branches(c,v1076_3_tail);
          std::vector<Space> v1077_3_outputs;
          v1077_3_outputs.reserve(v1077_3_branches.size());
          for (const auto& v1077_3_branch : v1077_3_branches) {
            const Path v1077_3_head{v1077_3_branch.first};
            const Space& v1077_3_tail = v1077_3_branch.second;
            const auto v1078_2_branches = branches(c,v1077_3_tail);
            std::vector<Space> v1078_2_outputs;
            v1078_2_outputs.reserve(v1078_2_branches.size());
            for (const auto& v1078_2_branch : v1078_2_branches) {
              const Path v1078_2_head{v1078_2_branch.first};
              const Space& v1078_2_tail = v1078_2_branch.second;
              const Path v1079_2 = concat_path(v1077_3_head,v1078_2_head);
              const auto v1079_3_branches = branches(c,v1078_2_tail);
              std::vector<Space> v1079_3_outputs;
              v1079_3_outputs.reserve(v1079_3_branches.size());
              for (const auto& v1079_3_branch : v1079_3_branches) {
                const Path v1079_3_head{v1079_3_branch.first};
                const Space& v1079_3_tail = v1079_3_branch.second;
                const Path v1080_2 = concat_path(v1079_2,v1079_3_head);
                const auto v1080_3_branches = branches(c,v1079_3_tail);
                std::vector<Space> v1080_3_outputs;
                v1080_3_outputs.reserve(v1080_3_branches.size());
                for (const auto& v1080_3_branch : v1080_3_branches) {
                  const Path v1080_3_head{v1080_3_branch.first};
                  const Space& v1080_3_tail = v1080_3_branch.second;
                  const Path v1081_2 = concat_path(v1080_2,v1080_3_head);
                  const Space v1081_3 = routine_137(c, v1081_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1077_2, v1080_3_tail);
                  v1080_3_outputs.push_back(v1081_3);
                }
                const Space v1080_3 = join_outputs(std::move(v1080_3_outputs));
                v1079_3_outputs.push_back(v1080_3);
              }
              const Space v1079_3 = join_outputs(std::move(v1079_3_outputs));
              v1078_2_outputs.push_back(v1079_3);
            }
            const Space v1078_2 = join_outputs(std::move(v1078_2_outputs));
            v1077_3_outputs.push_back(v1078_2);
          }
          const Space v1077_3 = join_outputs(std::move(v1077_3_outputs));
          v1076_3_outputs.push_back(v1077_3);
        }
        const Space v1076_3 = join_outputs(std::move(v1076_3_outputs));
        v1075_3_outputs.push_back(v1076_3);
      }
      const Space v1075_3 = join_outputs(std::move(v1075_3_outputs));
      v1074_2_outputs.push_back(v1075_3);
    }
    const Space v1074_2 = join_outputs(std::move(v1074_2_outputs));
    v1073_12_outputs.push_back(v1074_2);
  }
  const Space v1073_12 = join_outputs(std::move(v1073_12_outputs));
  return v1073_12;
}

static Space routine_122(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1082_12_branches = branches(c,s0);
  std::vector<Space> v1082_12_outputs;
  v1082_12_outputs.reserve(v1082_12_branches.size());
  for (const auto& v1082_12_branch : v1082_12_branches) {
    const Path v1082_12_head{v1082_12_branch.first};
    const Space& v1082_12_tail = v1082_12_branch.second;
    const auto v1083_2_branches = branches(c,v1082_12_tail);
    std::vector<Space> v1083_2_outputs;
    v1083_2_outputs.reserve(v1083_2_branches.size());
    for (const auto& v1083_2_branch : v1083_2_branches) {
      const Path v1083_2_head{v1083_2_branch.first};
      const Space& v1083_2_tail = v1083_2_branch.second;
      const Path v1084_2 = concat_path(v1082_12_head,v1083_2_head);
      const auto v1084_3_branches = branches(c,v1083_2_tail);
      std::vector<Space> v1084_3_outputs;
      v1084_3_outputs.reserve(v1084_3_branches.size());
      for (const auto& v1084_3_branch : v1084_3_branches) {
        const Path v1084_3_head{v1084_3_branch.first};
        const Space& v1084_3_tail = v1084_3_branch.second;
        const Path v1085_2 = concat_path(v1084_2,v1084_3_head);
        const auto v1085_3_branches = branches(c,v1084_3_tail);
        std::vector<Space> v1085_3_outputs;
        v1085_3_outputs.reserve(v1085_3_branches.size());
        for (const auto& v1085_3_branch : v1085_3_branches) {
          const Path v1085_3_head{v1085_3_branch.first};
          const Space& v1085_3_tail = v1085_3_branch.second;
          const Path v1086_2 = concat_path(v1085_2,v1085_3_head);
          const auto v1086_3_branches = branches(c,v1085_3_tail);
          std::vector<Space> v1086_3_outputs;
          v1086_3_outputs.reserve(v1086_3_branches.size());
          for (const auto& v1086_3_branch : v1086_3_branches) {
            const Path v1086_3_head{v1086_3_branch.first};
            const Space& v1086_3_tail = v1086_3_branch.second;
            const auto v1087_2_branches = branches(c,v1086_3_tail);
            std::vector<Space> v1087_2_outputs;
            v1087_2_outputs.reserve(v1087_2_branches.size());
            for (const auto& v1087_2_branch : v1087_2_branches) {
              const Path v1087_2_head{v1087_2_branch.first};
              const Space& v1087_2_tail = v1087_2_branch.second;
              const Path v1088_2 = concat_path(v1086_3_head,v1087_2_head);
              const auto v1088_3_branches = branches(c,v1087_2_tail);
              std::vector<Space> v1088_3_outputs;
              v1088_3_outputs.reserve(v1088_3_branches.size());
              for (const auto& v1088_3_branch : v1088_3_branches) {
                const Path v1088_3_head{v1088_3_branch.first};
                const Space& v1088_3_tail = v1088_3_branch.second;
                const Path v1089_2 = concat_path(v1088_2,v1088_3_head);
                const auto v1089_3_branches = branches(c,v1088_3_tail);
                std::vector<Space> v1089_3_outputs;
                v1089_3_outputs.reserve(v1089_3_branches.size());
                for (const auto& v1089_3_branch : v1089_3_branches) {
                  const Path v1089_3_head{v1089_3_branch.first};
                  const Space& v1089_3_tail = v1089_3_branch.second;
                  const Path v1090_2 = concat_path(v1089_2,v1089_3_head);
                  const Space v1090_3 = routine_138(c, v1090_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1086_2, v1089_3_tail);
                  v1089_3_outputs.push_back(v1090_3);
                }
                const Space v1089_3 = join_outputs(std::move(v1089_3_outputs));
                v1088_3_outputs.push_back(v1089_3);
              }
              const Space v1088_3 = join_outputs(std::move(v1088_3_outputs));
              v1087_2_outputs.push_back(v1088_3);
            }
            const Space v1087_2 = join_outputs(std::move(v1087_2_outputs));
            v1086_3_outputs.push_back(v1087_2);
          }
          const Space v1086_3 = join_outputs(std::move(v1086_3_outputs));
          v1085_3_outputs.push_back(v1086_3);
        }
        const Space v1085_3 = join_outputs(std::move(v1085_3_outputs));
        v1084_3_outputs.push_back(v1085_3);
      }
      const Space v1084_3 = join_outputs(std::move(v1084_3_outputs));
      v1083_2_outputs.push_back(v1084_3);
    }
    const Space v1083_2 = join_outputs(std::move(v1083_2_outputs));
    v1082_12_outputs.push_back(v1083_2);
  }
  const Space v1082_12 = join_outputs(std::move(v1082_12_outputs));
  return v1082_12;
}

static Space routine_123(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1091_12_branches = branches(c,s0);
  std::vector<Space> v1091_12_outputs;
  v1091_12_outputs.reserve(v1091_12_branches.size());
  for (const auto& v1091_12_branch : v1091_12_branches) {
    const Path v1091_12_head{v1091_12_branch.first};
    const Space& v1091_12_tail = v1091_12_branch.second;
    const auto v1092_2_branches = branches(c,v1091_12_tail);
    std::vector<Space> v1092_2_outputs;
    v1092_2_outputs.reserve(v1092_2_branches.size());
    for (const auto& v1092_2_branch : v1092_2_branches) {
      const Path v1092_2_head{v1092_2_branch.first};
      const Space& v1092_2_tail = v1092_2_branch.second;
      const Path v1093_2 = concat_path(v1091_12_head,v1092_2_head);
      const auto v1093_3_branches = branches(c,v1092_2_tail);
      std::vector<Space> v1093_3_outputs;
      v1093_3_outputs.reserve(v1093_3_branches.size());
      for (const auto& v1093_3_branch : v1093_3_branches) {
        const Path v1093_3_head{v1093_3_branch.first};
        const Space& v1093_3_tail = v1093_3_branch.second;
        const Path v1094_2 = concat_path(v1093_2,v1093_3_head);
        const auto v1094_3_branches = branches(c,v1093_3_tail);
        std::vector<Space> v1094_3_outputs;
        v1094_3_outputs.reserve(v1094_3_branches.size());
        for (const auto& v1094_3_branch : v1094_3_branches) {
          const Path v1094_3_head{v1094_3_branch.first};
          const Space& v1094_3_tail = v1094_3_branch.second;
          const Path v1095_2 = concat_path(v1094_2,v1094_3_head);
          const auto v1095_3_branches = branches(c,v1094_3_tail);
          std::vector<Space> v1095_3_outputs;
          v1095_3_outputs.reserve(v1095_3_branches.size());
          for (const auto& v1095_3_branch : v1095_3_branches) {
            const Path v1095_3_head{v1095_3_branch.first};
            const Space& v1095_3_tail = v1095_3_branch.second;
            const auto v1096_2_branches = branches(c,v1095_3_tail);
            std::vector<Space> v1096_2_outputs;
            v1096_2_outputs.reserve(v1096_2_branches.size());
            for (const auto& v1096_2_branch : v1096_2_branches) {
              const Path v1096_2_head{v1096_2_branch.first};
              const Space& v1096_2_tail = v1096_2_branch.second;
              const Path v1097_2 = concat_path(v1095_3_head,v1096_2_head);
              const auto v1097_3_branches = branches(c,v1096_2_tail);
              std::vector<Space> v1097_3_outputs;
              v1097_3_outputs.reserve(v1097_3_branches.size());
              for (const auto& v1097_3_branch : v1097_3_branches) {
                const Path v1097_3_head{v1097_3_branch.first};
                const Space& v1097_3_tail = v1097_3_branch.second;
                const Path v1098_2 = concat_path(v1097_2,v1097_3_head);
                const auto v1098_3_branches = branches(c,v1097_3_tail);
                std::vector<Space> v1098_3_outputs;
                v1098_3_outputs.reserve(v1098_3_branches.size());
                for (const auto& v1098_3_branch : v1098_3_branches) {
                  const Path v1098_3_head{v1098_3_branch.first};
                  const Space& v1098_3_tail = v1098_3_branch.second;
                  const Path v1099_2 = concat_path(v1098_2,v1098_3_head);
                  const Space v1099_3 = routine_139(c, v1099_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1095_2, v1098_3_tail);
                  v1098_3_outputs.push_back(v1099_3);
                }
                const Space v1098_3 = join_outputs(std::move(v1098_3_outputs));
                v1097_3_outputs.push_back(v1098_3);
              }
              const Space v1097_3 = join_outputs(std::move(v1097_3_outputs));
              v1096_2_outputs.push_back(v1097_3);
            }
            const Space v1096_2 = join_outputs(std::move(v1096_2_outputs));
            v1095_3_outputs.push_back(v1096_2);
          }
          const Space v1095_3 = join_outputs(std::move(v1095_3_outputs));
          v1094_3_outputs.push_back(v1095_3);
        }
        const Space v1094_3 = join_outputs(std::move(v1094_3_outputs));
        v1093_3_outputs.push_back(v1094_3);
      }
      const Space v1093_3 = join_outputs(std::move(v1093_3_outputs));
      v1092_2_outputs.push_back(v1093_3);
    }
    const Space v1092_2 = join_outputs(std::move(v1092_2_outputs));
    v1091_12_outputs.push_back(v1092_2);
  }
  const Space v1091_12 = join_outputs(std::move(v1091_12_outputs));
  return v1091_12;
}

static Space routine_124(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1100_12_branches = branches(c,s0);
  std::vector<Space> v1100_12_outputs;
  v1100_12_outputs.reserve(v1100_12_branches.size());
  for (const auto& v1100_12_branch : v1100_12_branches) {
    const Path v1100_12_head{v1100_12_branch.first};
    const Space& v1100_12_tail = v1100_12_branch.second;
    const auto v1101_2_branches = branches(c,v1100_12_tail);
    std::vector<Space> v1101_2_outputs;
    v1101_2_outputs.reserve(v1101_2_branches.size());
    for (const auto& v1101_2_branch : v1101_2_branches) {
      const Path v1101_2_head{v1101_2_branch.first};
      const Space& v1101_2_tail = v1101_2_branch.second;
      const Path v1102_2 = concat_path(v1100_12_head,v1101_2_head);
      const auto v1102_3_branches = branches(c,v1101_2_tail);
      std::vector<Space> v1102_3_outputs;
      v1102_3_outputs.reserve(v1102_3_branches.size());
      for (const auto& v1102_3_branch : v1102_3_branches) {
        const Path v1102_3_head{v1102_3_branch.first};
        const Space& v1102_3_tail = v1102_3_branch.second;
        const Path v1103_2 = concat_path(v1102_2,v1102_3_head);
        const auto v1103_3_branches = branches(c,v1102_3_tail);
        std::vector<Space> v1103_3_outputs;
        v1103_3_outputs.reserve(v1103_3_branches.size());
        for (const auto& v1103_3_branch : v1103_3_branches) {
          const Path v1103_3_head{v1103_3_branch.first};
          const Space& v1103_3_tail = v1103_3_branch.second;
          const Path v1104_2 = concat_path(v1103_2,v1103_3_head);
          const auto v1104_3_branches = branches(c,v1103_3_tail);
          std::vector<Space> v1104_3_outputs;
          v1104_3_outputs.reserve(v1104_3_branches.size());
          for (const auto& v1104_3_branch : v1104_3_branches) {
            const Path v1104_3_head{v1104_3_branch.first};
            const Space& v1104_3_tail = v1104_3_branch.second;
            const auto v1105_2_branches = branches(c,v1104_3_tail);
            std::vector<Space> v1105_2_outputs;
            v1105_2_outputs.reserve(v1105_2_branches.size());
            for (const auto& v1105_2_branch : v1105_2_branches) {
              const Path v1105_2_head{v1105_2_branch.first};
              const Space& v1105_2_tail = v1105_2_branch.second;
              const Path v1106_2 = concat_path(v1104_3_head,v1105_2_head);
              const auto v1106_3_branches = branches(c,v1105_2_tail);
              std::vector<Space> v1106_3_outputs;
              v1106_3_outputs.reserve(v1106_3_branches.size());
              for (const auto& v1106_3_branch : v1106_3_branches) {
                const Path v1106_3_head{v1106_3_branch.first};
                const Space& v1106_3_tail = v1106_3_branch.second;
                const Path v1107_2 = concat_path(v1106_2,v1106_3_head);
                const auto v1107_3_branches = branches(c,v1106_3_tail);
                std::vector<Space> v1107_3_outputs;
                v1107_3_outputs.reserve(v1107_3_branches.size());
                for (const auto& v1107_3_branch : v1107_3_branches) {
                  const Path v1107_3_head{v1107_3_branch.first};
                  const Space& v1107_3_tail = v1107_3_branch.second;
                  const Path v1108_2 = concat_path(v1107_2,v1107_3_head);
                  const Space v1108_3 = routine_140(c, v1108_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1104_2, v1107_3_tail);
                  v1107_3_outputs.push_back(v1108_3);
                }
                const Space v1107_3 = join_outputs(std::move(v1107_3_outputs));
                v1106_3_outputs.push_back(v1107_3);
              }
              const Space v1106_3 = join_outputs(std::move(v1106_3_outputs));
              v1105_2_outputs.push_back(v1106_3);
            }
            const Space v1105_2 = join_outputs(std::move(v1105_2_outputs));
            v1104_3_outputs.push_back(v1105_2);
          }
          const Space v1104_3 = join_outputs(std::move(v1104_3_outputs));
          v1103_3_outputs.push_back(v1104_3);
        }
        const Space v1103_3 = join_outputs(std::move(v1103_3_outputs));
        v1102_3_outputs.push_back(v1103_3);
      }
      const Space v1102_3 = join_outputs(std::move(v1102_3_outputs));
      v1101_2_outputs.push_back(v1102_3);
    }
    const Space v1101_2 = join_outputs(std::move(v1101_2_outputs));
    v1100_12_outputs.push_back(v1101_2);
  }
  const Space v1100_12 = join_outputs(std::move(v1100_12_outputs));
  return v1100_12;
}

static Space routine_125(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1109_12_branches = branches(c,s0);
  std::vector<Space> v1109_12_outputs;
  v1109_12_outputs.reserve(v1109_12_branches.size());
  for (const auto& v1109_12_branch : v1109_12_branches) {
    const Path v1109_12_head{v1109_12_branch.first};
    const Space& v1109_12_tail = v1109_12_branch.second;
    const auto v1110_2_branches = branches(c,v1109_12_tail);
    std::vector<Space> v1110_2_outputs;
    v1110_2_outputs.reserve(v1110_2_branches.size());
    for (const auto& v1110_2_branch : v1110_2_branches) {
      const Path v1110_2_head{v1110_2_branch.first};
      const Space& v1110_2_tail = v1110_2_branch.second;
      const Path v1111_2 = concat_path(v1109_12_head,v1110_2_head);
      const auto v1111_3_branches = branches(c,v1110_2_tail);
      std::vector<Space> v1111_3_outputs;
      v1111_3_outputs.reserve(v1111_3_branches.size());
      for (const auto& v1111_3_branch : v1111_3_branches) {
        const Path v1111_3_head{v1111_3_branch.first};
        const Space& v1111_3_tail = v1111_3_branch.second;
        const Path v1112_2 = concat_path(v1111_2,v1111_3_head);
        const auto v1112_3_branches = branches(c,v1111_3_tail);
        std::vector<Space> v1112_3_outputs;
        v1112_3_outputs.reserve(v1112_3_branches.size());
        for (const auto& v1112_3_branch : v1112_3_branches) {
          const Path v1112_3_head{v1112_3_branch.first};
          const Space& v1112_3_tail = v1112_3_branch.second;
          const Path v1113_2 = concat_path(v1112_2,v1112_3_head);
          const auto v1113_3_branches = branches(c,v1112_3_tail);
          std::vector<Space> v1113_3_outputs;
          v1113_3_outputs.reserve(v1113_3_branches.size());
          for (const auto& v1113_3_branch : v1113_3_branches) {
            const Path v1113_3_head{v1113_3_branch.first};
            const Space& v1113_3_tail = v1113_3_branch.second;
            const auto v1114_2_branches = branches(c,v1113_3_tail);
            std::vector<Space> v1114_2_outputs;
            v1114_2_outputs.reserve(v1114_2_branches.size());
            for (const auto& v1114_2_branch : v1114_2_branches) {
              const Path v1114_2_head{v1114_2_branch.first};
              const Space& v1114_2_tail = v1114_2_branch.second;
              const Path v1115_2 = concat_path(v1113_3_head,v1114_2_head);
              const auto v1115_3_branches = branches(c,v1114_2_tail);
              std::vector<Space> v1115_3_outputs;
              v1115_3_outputs.reserve(v1115_3_branches.size());
              for (const auto& v1115_3_branch : v1115_3_branches) {
                const Path v1115_3_head{v1115_3_branch.first};
                const Space& v1115_3_tail = v1115_3_branch.second;
                const Path v1116_2 = concat_path(v1115_2,v1115_3_head);
                const auto v1116_3_branches = branches(c,v1115_3_tail);
                std::vector<Space> v1116_3_outputs;
                v1116_3_outputs.reserve(v1116_3_branches.size());
                for (const auto& v1116_3_branch : v1116_3_branches) {
                  const Path v1116_3_head{v1116_3_branch.first};
                  const Space& v1116_3_tail = v1116_3_branch.second;
                  const Path v1117_2 = concat_path(v1116_2,v1116_3_head);
                  const Space v1117_3 = routine_141(c, v1117_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1113_2, v1116_3_tail);
                  v1116_3_outputs.push_back(v1117_3);
                }
                const Space v1116_3 = join_outputs(std::move(v1116_3_outputs));
                v1115_3_outputs.push_back(v1116_3);
              }
              const Space v1115_3 = join_outputs(std::move(v1115_3_outputs));
              v1114_2_outputs.push_back(v1115_3);
            }
            const Space v1114_2 = join_outputs(std::move(v1114_2_outputs));
            v1113_3_outputs.push_back(v1114_2);
          }
          const Space v1113_3 = join_outputs(std::move(v1113_3_outputs));
          v1112_3_outputs.push_back(v1113_3);
        }
        const Space v1112_3 = join_outputs(std::move(v1112_3_outputs));
        v1111_3_outputs.push_back(v1112_3);
      }
      const Space v1111_3 = join_outputs(std::move(v1111_3_outputs));
      v1110_2_outputs.push_back(v1111_3);
    }
    const Space v1110_2 = join_outputs(std::move(v1110_2_outputs));
    v1109_12_outputs.push_back(v1110_2);
  }
  const Space v1109_12 = join_outputs(std::move(v1109_12_outputs));
  return v1109_12;
}

static Space routine_126(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Space& s0) {
  const auto v1118_12_branches = branches(c,s0);
  std::vector<Space> v1118_12_outputs;
  v1118_12_outputs.reserve(v1118_12_branches.size());
  for (const auto& v1118_12_branch : v1118_12_branches) {
    const Path v1118_12_head{v1118_12_branch.first};
    const Space& v1118_12_tail = v1118_12_branch.second;
    const auto v1119_2_branches = branches(c,v1118_12_tail);
    std::vector<Space> v1119_2_outputs;
    v1119_2_outputs.reserve(v1119_2_branches.size());
    for (const auto& v1119_2_branch : v1119_2_branches) {
      const Path v1119_2_head{v1119_2_branch.first};
      const Space& v1119_2_tail = v1119_2_branch.second;
      const Path v1120_2 = concat_path(v1118_12_head,v1119_2_head);
      const auto v1120_3_branches = branches(c,v1119_2_tail);
      std::vector<Space> v1120_3_outputs;
      v1120_3_outputs.reserve(v1120_3_branches.size());
      for (const auto& v1120_3_branch : v1120_3_branches) {
        const Path v1120_3_head{v1120_3_branch.first};
        const Space& v1120_3_tail = v1120_3_branch.second;
        const Path v1121_2 = concat_path(v1120_2,v1120_3_head);
        const auto v1121_3_branches = branches(c,v1120_3_tail);
        std::vector<Space> v1121_3_outputs;
        v1121_3_outputs.reserve(v1121_3_branches.size());
        for (const auto& v1121_3_branch : v1121_3_branches) {
          const Path v1121_3_head{v1121_3_branch.first};
          const Space& v1121_3_tail = v1121_3_branch.second;
          const Path v1122_2 = concat_path(v1121_2,v1121_3_head);
          const auto v1122_3_branches = branches(c,v1121_3_tail);
          std::vector<Space> v1122_3_outputs;
          v1122_3_outputs.reserve(v1122_3_branches.size());
          for (const auto& v1122_3_branch : v1122_3_branches) {
            const Path v1122_3_head{v1122_3_branch.first};
            const Space& v1122_3_tail = v1122_3_branch.second;
            const auto v1123_2_branches = branches(c,v1122_3_tail);
            std::vector<Space> v1123_2_outputs;
            v1123_2_outputs.reserve(v1123_2_branches.size());
            for (const auto& v1123_2_branch : v1123_2_branches) {
              const Path v1123_2_head{v1123_2_branch.first};
              const Space& v1123_2_tail = v1123_2_branch.second;
              const Path v1124_2 = concat_path(v1122_3_head,v1123_2_head);
              const auto v1124_3_branches = branches(c,v1123_2_tail);
              std::vector<Space> v1124_3_outputs;
              v1124_3_outputs.reserve(v1124_3_branches.size());
              for (const auto& v1124_3_branch : v1124_3_branches) {
                const Path v1124_3_head{v1124_3_branch.first};
                const Space& v1124_3_tail = v1124_3_branch.second;
                const Path v1125_2 = concat_path(v1124_2,v1124_3_head);
                const auto v1125_3_branches = branches(c,v1124_3_tail);
                std::vector<Space> v1125_3_outputs;
                v1125_3_outputs.reserve(v1125_3_branches.size());
                for (const auto& v1125_3_branch : v1125_3_branches) {
                  const Path v1125_3_head{v1125_3_branch.first};
                  const Space& v1125_3_tail = v1125_3_branch.second;
                  const Path v1126_2 = concat_path(v1125_2,v1125_3_head);
                  const Space v1126_3 = routine_142(c, v1126_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p0, v1122_2, v1125_3_tail);
                  v1125_3_outputs.push_back(v1126_3);
                }
                const Space v1125_3 = join_outputs(std::move(v1125_3_outputs));
                v1124_3_outputs.push_back(v1125_3);
              }
              const Space v1124_3 = join_outputs(std::move(v1124_3_outputs));
              v1123_2_outputs.push_back(v1124_3);
            }
            const Space v1123_2 = join_outputs(std::move(v1123_2_outputs));
            v1122_3_outputs.push_back(v1123_2);
          }
          const Space v1122_3 = join_outputs(std::move(v1122_3_outputs));
          v1121_3_outputs.push_back(v1122_3);
        }
        const Space v1121_3 = join_outputs(std::move(v1121_3_outputs));
        v1120_3_outputs.push_back(v1121_3);
      }
      const Space v1120_3 = join_outputs(std::move(v1120_3_outputs));
      v1119_2_outputs.push_back(v1120_3);
    }
    const Space v1119_2 = join_outputs(std::move(v1119_2_outputs));
    v1118_12_outputs.push_back(v1119_2);
  }
  const Space v1118_12 = join_outputs(std::move(v1118_12_outputs));
  return v1118_12;
}

static Space routine_127(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1127_14_branches = branches(c,s0);
  std::vector<Space> v1127_14_outputs;
  v1127_14_outputs.reserve(v1127_14_branches.size());
  for (const auto& v1127_14_branch : v1127_14_branches) {
    const Path v1127_14_head{v1127_14_branch.first};
    const Space& v1127_14_tail = v1127_14_branch.second;
    const auto v1128_2_branches = branches(c,v1127_14_tail);
    std::vector<Space> v1128_2_outputs;
    v1128_2_outputs.reserve(v1128_2_branches.size());
    for (const auto& v1128_2_branch : v1128_2_branches) {
      const Path v1128_2_head{v1128_2_branch.first};
      const Space& v1128_2_tail = v1128_2_branch.second;
      const Path v1129_2 = concat_path(v1127_14_head,v1128_2_head);
      const auto v1129_3_branches = branches(c,v1128_2_tail);
      std::vector<Space> v1129_3_outputs;
      v1129_3_outputs.reserve(v1129_3_branches.size());
      for (const auto& v1129_3_branch : v1129_3_branches) {
        const Path v1129_3_head{v1129_3_branch.first};
        const Space& v1129_3_tail = v1129_3_branch.second;
        const Path v1130_2 = concat_path(v1129_2,v1129_3_head);
        const auto v1130_3_branches = branches(c,v1129_3_tail);
        std::vector<Space> v1130_3_outputs;
        v1130_3_outputs.reserve(v1130_3_branches.size());
        for (const auto& v1130_3_branch : v1130_3_branches) {
          const Path v1130_3_head{v1130_3_branch.first};
          const Space& v1130_3_tail = v1130_3_branch.second;
          const Path v1131_2 = concat_path(v1130_2,v1130_3_head);
          const auto v1131_3_branches = branches(c,v1130_3_tail);
          std::vector<Space> v1131_3_outputs;
          v1131_3_outputs.reserve(v1131_3_branches.size());
          for (const auto& v1131_3_branch : v1131_3_branches) {
            const Path v1131_3_head{v1131_3_branch.first};
            const Space& v1131_3_tail = v1131_3_branch.second;
            const auto v1132_2_branches = branches(c,v1131_3_tail);
            std::vector<Space> v1132_2_outputs;
            v1132_2_outputs.reserve(v1132_2_branches.size());
            for (const auto& v1132_2_branch : v1132_2_branches) {
              const Path v1132_2_head{v1132_2_branch.first};
              const Space& v1132_2_tail = v1132_2_branch.second;
              const Path v1133_2 = concat_path(v1131_3_head,v1132_2_head);
              const auto v1133_3_branches = branches(c,v1132_2_tail);
              std::vector<Space> v1133_3_outputs;
              v1133_3_outputs.reserve(v1133_3_branches.size());
              for (const auto& v1133_3_branch : v1133_3_branches) {
                const Path v1133_3_head{v1133_3_branch.first};
                const Space& v1133_3_tail = v1133_3_branch.second;
                const Path v1134_2 = concat_path(v1133_2,v1133_3_head);
                const auto v1134_3_branches = branches(c,v1133_3_tail);
                std::vector<Space> v1134_3_outputs;
                v1134_3_outputs.reserve(v1134_3_branches.size());
                for (const auto& v1134_3_branch : v1134_3_branches) {
                  const Path v1134_3_head{v1134_3_branch.first};
                  const Space& v1134_3_tail = v1134_3_branch.second;
                  const Path v1135_2 = concat_path(v1134_2,v1134_3_head);
                  const Space v1135_3 = routine_143(c, v1135_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1131_2, v1134_3_tail);
                  v1134_3_outputs.push_back(v1135_3);
                }
                const Space v1134_3 = join_outputs(std::move(v1134_3_outputs));
                v1133_3_outputs.push_back(v1134_3);
              }
              const Space v1133_3 = join_outputs(std::move(v1133_3_outputs));
              v1132_2_outputs.push_back(v1133_3);
            }
            const Space v1132_2 = join_outputs(std::move(v1132_2_outputs));
            v1131_3_outputs.push_back(v1132_2);
          }
          const Space v1131_3 = join_outputs(std::move(v1131_3_outputs));
          v1130_3_outputs.push_back(v1131_3);
        }
        const Space v1130_3 = join_outputs(std::move(v1130_3_outputs));
        v1129_3_outputs.push_back(v1130_3);
      }
      const Space v1129_3 = join_outputs(std::move(v1129_3_outputs));
      v1128_2_outputs.push_back(v1129_3);
    }
    const Space v1128_2 = join_outputs(std::move(v1128_2_outputs));
    v1127_14_outputs.push_back(v1128_2);
  }
  const Space v1127_14 = join_outputs(std::move(v1127_14_outputs));
  return v1127_14;
}

static Space routine_128(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1136_14_branches = branches(c,s0);
  std::vector<Space> v1136_14_outputs;
  v1136_14_outputs.reserve(v1136_14_branches.size());
  for (const auto& v1136_14_branch : v1136_14_branches) {
    const Path v1136_14_head{v1136_14_branch.first};
    const Space& v1136_14_tail = v1136_14_branch.second;
    const auto v1137_2_branches = branches(c,v1136_14_tail);
    std::vector<Space> v1137_2_outputs;
    v1137_2_outputs.reserve(v1137_2_branches.size());
    for (const auto& v1137_2_branch : v1137_2_branches) {
      const Path v1137_2_head{v1137_2_branch.first};
      const Space& v1137_2_tail = v1137_2_branch.second;
      const Path v1138_2 = concat_path(v1136_14_head,v1137_2_head);
      const auto v1138_3_branches = branches(c,v1137_2_tail);
      std::vector<Space> v1138_3_outputs;
      v1138_3_outputs.reserve(v1138_3_branches.size());
      for (const auto& v1138_3_branch : v1138_3_branches) {
        const Path v1138_3_head{v1138_3_branch.first};
        const Space& v1138_3_tail = v1138_3_branch.second;
        const Path v1139_2 = concat_path(v1138_2,v1138_3_head);
        const auto v1139_3_branches = branches(c,v1138_3_tail);
        std::vector<Space> v1139_3_outputs;
        v1139_3_outputs.reserve(v1139_3_branches.size());
        for (const auto& v1139_3_branch : v1139_3_branches) {
          const Path v1139_3_head{v1139_3_branch.first};
          const Space& v1139_3_tail = v1139_3_branch.second;
          const Path v1140_2 = concat_path(v1139_2,v1139_3_head);
          const auto v1140_3_branches = branches(c,v1139_3_tail);
          std::vector<Space> v1140_3_outputs;
          v1140_3_outputs.reserve(v1140_3_branches.size());
          for (const auto& v1140_3_branch : v1140_3_branches) {
            const Path v1140_3_head{v1140_3_branch.first};
            const Space& v1140_3_tail = v1140_3_branch.second;
            const auto v1141_2_branches = branches(c,v1140_3_tail);
            std::vector<Space> v1141_2_outputs;
            v1141_2_outputs.reserve(v1141_2_branches.size());
            for (const auto& v1141_2_branch : v1141_2_branches) {
              const Path v1141_2_head{v1141_2_branch.first};
              const Space& v1141_2_tail = v1141_2_branch.second;
              const Path v1142_2 = concat_path(v1140_3_head,v1141_2_head);
              const auto v1142_3_branches = branches(c,v1141_2_tail);
              std::vector<Space> v1142_3_outputs;
              v1142_3_outputs.reserve(v1142_3_branches.size());
              for (const auto& v1142_3_branch : v1142_3_branches) {
                const Path v1142_3_head{v1142_3_branch.first};
                const Space& v1142_3_tail = v1142_3_branch.second;
                const Path v1143_2 = concat_path(v1142_2,v1142_3_head);
                const auto v1143_3_branches = branches(c,v1142_3_tail);
                std::vector<Space> v1143_3_outputs;
                v1143_3_outputs.reserve(v1143_3_branches.size());
                for (const auto& v1143_3_branch : v1143_3_branches) {
                  const Path v1143_3_head{v1143_3_branch.first};
                  const Space& v1143_3_tail = v1143_3_branch.second;
                  const Path v1144_2 = concat_path(v1143_2,v1143_3_head);
                  const Space v1144_3 = routine_144(c, v1144_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1140_2, v1143_3_tail);
                  v1143_3_outputs.push_back(v1144_3);
                }
                const Space v1143_3 = join_outputs(std::move(v1143_3_outputs));
                v1142_3_outputs.push_back(v1143_3);
              }
              const Space v1142_3 = join_outputs(std::move(v1142_3_outputs));
              v1141_2_outputs.push_back(v1142_3);
            }
            const Space v1141_2 = join_outputs(std::move(v1141_2_outputs));
            v1140_3_outputs.push_back(v1141_2);
          }
          const Space v1140_3 = join_outputs(std::move(v1140_3_outputs));
          v1139_3_outputs.push_back(v1140_3);
        }
        const Space v1139_3 = join_outputs(std::move(v1139_3_outputs));
        v1138_3_outputs.push_back(v1139_3);
      }
      const Space v1138_3 = join_outputs(std::move(v1138_3_outputs));
      v1137_2_outputs.push_back(v1138_3);
    }
    const Space v1137_2 = join_outputs(std::move(v1137_2_outputs));
    v1136_14_outputs.push_back(v1137_2);
  }
  const Space v1136_14 = join_outputs(std::move(v1136_14_outputs));
  return v1136_14;
}

static Space routine_129(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1145_14_branches = branches(c,s0);
  std::vector<Space> v1145_14_outputs;
  v1145_14_outputs.reserve(v1145_14_branches.size());
  for (const auto& v1145_14_branch : v1145_14_branches) {
    const Path v1145_14_head{v1145_14_branch.first};
    const Space& v1145_14_tail = v1145_14_branch.second;
    const auto v1146_2_branches = branches(c,v1145_14_tail);
    std::vector<Space> v1146_2_outputs;
    v1146_2_outputs.reserve(v1146_2_branches.size());
    for (const auto& v1146_2_branch : v1146_2_branches) {
      const Path v1146_2_head{v1146_2_branch.first};
      const Space& v1146_2_tail = v1146_2_branch.second;
      const Path v1147_2 = concat_path(v1145_14_head,v1146_2_head);
      const auto v1147_3_branches = branches(c,v1146_2_tail);
      std::vector<Space> v1147_3_outputs;
      v1147_3_outputs.reserve(v1147_3_branches.size());
      for (const auto& v1147_3_branch : v1147_3_branches) {
        const Path v1147_3_head{v1147_3_branch.first};
        const Space& v1147_3_tail = v1147_3_branch.second;
        const Path v1148_2 = concat_path(v1147_2,v1147_3_head);
        const auto v1148_3_branches = branches(c,v1147_3_tail);
        std::vector<Space> v1148_3_outputs;
        v1148_3_outputs.reserve(v1148_3_branches.size());
        for (const auto& v1148_3_branch : v1148_3_branches) {
          const Path v1148_3_head{v1148_3_branch.first};
          const Space& v1148_3_tail = v1148_3_branch.second;
          const Path v1149_2 = concat_path(v1148_2,v1148_3_head);
          const auto v1149_3_branches = branches(c,v1148_3_tail);
          std::vector<Space> v1149_3_outputs;
          v1149_3_outputs.reserve(v1149_3_branches.size());
          for (const auto& v1149_3_branch : v1149_3_branches) {
            const Path v1149_3_head{v1149_3_branch.first};
            const Space& v1149_3_tail = v1149_3_branch.second;
            const auto v1150_2_branches = branches(c,v1149_3_tail);
            std::vector<Space> v1150_2_outputs;
            v1150_2_outputs.reserve(v1150_2_branches.size());
            for (const auto& v1150_2_branch : v1150_2_branches) {
              const Path v1150_2_head{v1150_2_branch.first};
              const Space& v1150_2_tail = v1150_2_branch.second;
              const Path v1151_2 = concat_path(v1149_3_head,v1150_2_head);
              const auto v1151_3_branches = branches(c,v1150_2_tail);
              std::vector<Space> v1151_3_outputs;
              v1151_3_outputs.reserve(v1151_3_branches.size());
              for (const auto& v1151_3_branch : v1151_3_branches) {
                const Path v1151_3_head{v1151_3_branch.first};
                const Space& v1151_3_tail = v1151_3_branch.second;
                const Path v1152_2 = concat_path(v1151_2,v1151_3_head);
                const auto v1152_3_branches = branches(c,v1151_3_tail);
                std::vector<Space> v1152_3_outputs;
                v1152_3_outputs.reserve(v1152_3_branches.size());
                for (const auto& v1152_3_branch : v1152_3_branches) {
                  const Path v1152_3_head{v1152_3_branch.first};
                  const Space& v1152_3_tail = v1152_3_branch.second;
                  const Path v1153_2 = concat_path(v1152_2,v1152_3_head);
                  const Space v1153_3 = routine_145(c, v1153_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1149_2, v1152_3_tail);
                  v1152_3_outputs.push_back(v1153_3);
                }
                const Space v1152_3 = join_outputs(std::move(v1152_3_outputs));
                v1151_3_outputs.push_back(v1152_3);
              }
              const Space v1151_3 = join_outputs(std::move(v1151_3_outputs));
              v1150_2_outputs.push_back(v1151_3);
            }
            const Space v1150_2 = join_outputs(std::move(v1150_2_outputs));
            v1149_3_outputs.push_back(v1150_2);
          }
          const Space v1149_3 = join_outputs(std::move(v1149_3_outputs));
          v1148_3_outputs.push_back(v1149_3);
        }
        const Space v1148_3 = join_outputs(std::move(v1148_3_outputs));
        v1147_3_outputs.push_back(v1148_3);
      }
      const Space v1147_3 = join_outputs(std::move(v1147_3_outputs));
      v1146_2_outputs.push_back(v1147_3);
    }
    const Space v1146_2 = join_outputs(std::move(v1146_2_outputs));
    v1145_14_outputs.push_back(v1146_2);
  }
  const Space v1145_14 = join_outputs(std::move(v1145_14_outputs));
  return v1145_14;
}

static Space routine_130(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1154_14_branches = branches(c,s0);
  std::vector<Space> v1154_14_outputs;
  v1154_14_outputs.reserve(v1154_14_branches.size());
  for (const auto& v1154_14_branch : v1154_14_branches) {
    const Path v1154_14_head{v1154_14_branch.first};
    const Space& v1154_14_tail = v1154_14_branch.second;
    const auto v1155_2_branches = branches(c,v1154_14_tail);
    std::vector<Space> v1155_2_outputs;
    v1155_2_outputs.reserve(v1155_2_branches.size());
    for (const auto& v1155_2_branch : v1155_2_branches) {
      const Path v1155_2_head{v1155_2_branch.first};
      const Space& v1155_2_tail = v1155_2_branch.second;
      const Path v1156_2 = concat_path(v1154_14_head,v1155_2_head);
      const auto v1156_3_branches = branches(c,v1155_2_tail);
      std::vector<Space> v1156_3_outputs;
      v1156_3_outputs.reserve(v1156_3_branches.size());
      for (const auto& v1156_3_branch : v1156_3_branches) {
        const Path v1156_3_head{v1156_3_branch.first};
        const Space& v1156_3_tail = v1156_3_branch.second;
        const Path v1157_2 = concat_path(v1156_2,v1156_3_head);
        const auto v1157_3_branches = branches(c,v1156_3_tail);
        std::vector<Space> v1157_3_outputs;
        v1157_3_outputs.reserve(v1157_3_branches.size());
        for (const auto& v1157_3_branch : v1157_3_branches) {
          const Path v1157_3_head{v1157_3_branch.first};
          const Space& v1157_3_tail = v1157_3_branch.second;
          const Path v1158_2 = concat_path(v1157_2,v1157_3_head);
          const auto v1158_3_branches = branches(c,v1157_3_tail);
          std::vector<Space> v1158_3_outputs;
          v1158_3_outputs.reserve(v1158_3_branches.size());
          for (const auto& v1158_3_branch : v1158_3_branches) {
            const Path v1158_3_head{v1158_3_branch.first};
            const Space& v1158_3_tail = v1158_3_branch.second;
            const auto v1159_2_branches = branches(c,v1158_3_tail);
            std::vector<Space> v1159_2_outputs;
            v1159_2_outputs.reserve(v1159_2_branches.size());
            for (const auto& v1159_2_branch : v1159_2_branches) {
              const Path v1159_2_head{v1159_2_branch.first};
              const Space& v1159_2_tail = v1159_2_branch.second;
              const Path v1160_2 = concat_path(v1158_3_head,v1159_2_head);
              const auto v1160_3_branches = branches(c,v1159_2_tail);
              std::vector<Space> v1160_3_outputs;
              v1160_3_outputs.reserve(v1160_3_branches.size());
              for (const auto& v1160_3_branch : v1160_3_branches) {
                const Path v1160_3_head{v1160_3_branch.first};
                const Space& v1160_3_tail = v1160_3_branch.second;
                const Path v1161_2 = concat_path(v1160_2,v1160_3_head);
                const auto v1161_3_branches = branches(c,v1160_3_tail);
                std::vector<Space> v1161_3_outputs;
                v1161_3_outputs.reserve(v1161_3_branches.size());
                for (const auto& v1161_3_branch : v1161_3_branches) {
                  const Path v1161_3_head{v1161_3_branch.first};
                  const Space& v1161_3_tail = v1161_3_branch.second;
                  const Path v1162_2 = concat_path(v1161_2,v1161_3_head);
                  const Space v1162_3 = routine_146(c, v1162_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1158_2, v1161_3_tail);
                  v1161_3_outputs.push_back(v1162_3);
                }
                const Space v1161_3 = join_outputs(std::move(v1161_3_outputs));
                v1160_3_outputs.push_back(v1161_3);
              }
              const Space v1160_3 = join_outputs(std::move(v1160_3_outputs));
              v1159_2_outputs.push_back(v1160_3);
            }
            const Space v1159_2 = join_outputs(std::move(v1159_2_outputs));
            v1158_3_outputs.push_back(v1159_2);
          }
          const Space v1158_3 = join_outputs(std::move(v1158_3_outputs));
          v1157_3_outputs.push_back(v1158_3);
        }
        const Space v1157_3 = join_outputs(std::move(v1157_3_outputs));
        v1156_3_outputs.push_back(v1157_3);
      }
      const Space v1156_3 = join_outputs(std::move(v1156_3_outputs));
      v1155_2_outputs.push_back(v1156_3);
    }
    const Space v1155_2 = join_outputs(std::move(v1155_2_outputs));
    v1154_14_outputs.push_back(v1155_2);
  }
  const Space v1154_14 = join_outputs(std::move(v1154_14_outputs));
  return v1154_14;
}

static Space routine_131(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1163_14_branches = branches(c,s0);
  std::vector<Space> v1163_14_outputs;
  v1163_14_outputs.reserve(v1163_14_branches.size());
  for (const auto& v1163_14_branch : v1163_14_branches) {
    const Path v1163_14_head{v1163_14_branch.first};
    const Space& v1163_14_tail = v1163_14_branch.second;
    const auto v1164_2_branches = branches(c,v1163_14_tail);
    std::vector<Space> v1164_2_outputs;
    v1164_2_outputs.reserve(v1164_2_branches.size());
    for (const auto& v1164_2_branch : v1164_2_branches) {
      const Path v1164_2_head{v1164_2_branch.first};
      const Space& v1164_2_tail = v1164_2_branch.second;
      const Path v1165_2 = concat_path(v1163_14_head,v1164_2_head);
      const auto v1165_3_branches = branches(c,v1164_2_tail);
      std::vector<Space> v1165_3_outputs;
      v1165_3_outputs.reserve(v1165_3_branches.size());
      for (const auto& v1165_3_branch : v1165_3_branches) {
        const Path v1165_3_head{v1165_3_branch.first};
        const Space& v1165_3_tail = v1165_3_branch.second;
        const Path v1166_2 = concat_path(v1165_2,v1165_3_head);
        const auto v1166_3_branches = branches(c,v1165_3_tail);
        std::vector<Space> v1166_3_outputs;
        v1166_3_outputs.reserve(v1166_3_branches.size());
        for (const auto& v1166_3_branch : v1166_3_branches) {
          const Path v1166_3_head{v1166_3_branch.first};
          const Space& v1166_3_tail = v1166_3_branch.second;
          const Path v1167_2 = concat_path(v1166_2,v1166_3_head);
          const auto v1167_3_branches = branches(c,v1166_3_tail);
          std::vector<Space> v1167_3_outputs;
          v1167_3_outputs.reserve(v1167_3_branches.size());
          for (const auto& v1167_3_branch : v1167_3_branches) {
            const Path v1167_3_head{v1167_3_branch.first};
            const Space& v1167_3_tail = v1167_3_branch.second;
            const auto v1168_2_branches = branches(c,v1167_3_tail);
            std::vector<Space> v1168_2_outputs;
            v1168_2_outputs.reserve(v1168_2_branches.size());
            for (const auto& v1168_2_branch : v1168_2_branches) {
              const Path v1168_2_head{v1168_2_branch.first};
              const Space& v1168_2_tail = v1168_2_branch.second;
              const Path v1169_2 = concat_path(v1167_3_head,v1168_2_head);
              const auto v1169_3_branches = branches(c,v1168_2_tail);
              std::vector<Space> v1169_3_outputs;
              v1169_3_outputs.reserve(v1169_3_branches.size());
              for (const auto& v1169_3_branch : v1169_3_branches) {
                const Path v1169_3_head{v1169_3_branch.first};
                const Space& v1169_3_tail = v1169_3_branch.second;
                const Path v1170_2 = concat_path(v1169_2,v1169_3_head);
                const auto v1170_3_branches = branches(c,v1169_3_tail);
                std::vector<Space> v1170_3_outputs;
                v1170_3_outputs.reserve(v1170_3_branches.size());
                for (const auto& v1170_3_branch : v1170_3_branches) {
                  const Path v1170_3_head{v1170_3_branch.first};
                  const Space& v1170_3_tail = v1170_3_branch.second;
                  const Path v1171_2 = concat_path(v1170_2,v1170_3_head);
                  const Space v1171_3 = routine_147(c, v1171_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1167_2, v1170_3_tail);
                  v1170_3_outputs.push_back(v1171_3);
                }
                const Space v1170_3 = join_outputs(std::move(v1170_3_outputs));
                v1169_3_outputs.push_back(v1170_3);
              }
              const Space v1169_3 = join_outputs(std::move(v1169_3_outputs));
              v1168_2_outputs.push_back(v1169_3);
            }
            const Space v1168_2 = join_outputs(std::move(v1168_2_outputs));
            v1167_3_outputs.push_back(v1168_2);
          }
          const Space v1167_3 = join_outputs(std::move(v1167_3_outputs));
          v1166_3_outputs.push_back(v1167_3);
        }
        const Space v1166_3 = join_outputs(std::move(v1166_3_outputs));
        v1165_3_outputs.push_back(v1166_3);
      }
      const Space v1165_3 = join_outputs(std::move(v1165_3_outputs));
      v1164_2_outputs.push_back(v1165_3);
    }
    const Space v1164_2 = join_outputs(std::move(v1164_2_outputs));
    v1163_14_outputs.push_back(v1164_2);
  }
  const Space v1163_14 = join_outputs(std::move(v1163_14_outputs));
  return v1163_14;
}

static Space routine_132(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1172_14_branches = branches(c,s0);
  std::vector<Space> v1172_14_outputs;
  v1172_14_outputs.reserve(v1172_14_branches.size());
  for (const auto& v1172_14_branch : v1172_14_branches) {
    const Path v1172_14_head{v1172_14_branch.first};
    const Space& v1172_14_tail = v1172_14_branch.second;
    const auto v1173_2_branches = branches(c,v1172_14_tail);
    std::vector<Space> v1173_2_outputs;
    v1173_2_outputs.reserve(v1173_2_branches.size());
    for (const auto& v1173_2_branch : v1173_2_branches) {
      const Path v1173_2_head{v1173_2_branch.first};
      const Space& v1173_2_tail = v1173_2_branch.second;
      const Path v1174_2 = concat_path(v1172_14_head,v1173_2_head);
      const auto v1174_3_branches = branches(c,v1173_2_tail);
      std::vector<Space> v1174_3_outputs;
      v1174_3_outputs.reserve(v1174_3_branches.size());
      for (const auto& v1174_3_branch : v1174_3_branches) {
        const Path v1174_3_head{v1174_3_branch.first};
        const Space& v1174_3_tail = v1174_3_branch.second;
        const Path v1175_2 = concat_path(v1174_2,v1174_3_head);
        const auto v1175_3_branches = branches(c,v1174_3_tail);
        std::vector<Space> v1175_3_outputs;
        v1175_3_outputs.reserve(v1175_3_branches.size());
        for (const auto& v1175_3_branch : v1175_3_branches) {
          const Path v1175_3_head{v1175_3_branch.first};
          const Space& v1175_3_tail = v1175_3_branch.second;
          const Path v1176_2 = concat_path(v1175_2,v1175_3_head);
          const auto v1176_3_branches = branches(c,v1175_3_tail);
          std::vector<Space> v1176_3_outputs;
          v1176_3_outputs.reserve(v1176_3_branches.size());
          for (const auto& v1176_3_branch : v1176_3_branches) {
            const Path v1176_3_head{v1176_3_branch.first};
            const Space& v1176_3_tail = v1176_3_branch.second;
            const auto v1177_2_branches = branches(c,v1176_3_tail);
            std::vector<Space> v1177_2_outputs;
            v1177_2_outputs.reserve(v1177_2_branches.size());
            for (const auto& v1177_2_branch : v1177_2_branches) {
              const Path v1177_2_head{v1177_2_branch.first};
              const Space& v1177_2_tail = v1177_2_branch.second;
              const Path v1178_2 = concat_path(v1176_3_head,v1177_2_head);
              const auto v1178_3_branches = branches(c,v1177_2_tail);
              std::vector<Space> v1178_3_outputs;
              v1178_3_outputs.reserve(v1178_3_branches.size());
              for (const auto& v1178_3_branch : v1178_3_branches) {
                const Path v1178_3_head{v1178_3_branch.first};
                const Space& v1178_3_tail = v1178_3_branch.second;
                const Path v1179_2 = concat_path(v1178_2,v1178_3_head);
                const auto v1179_3_branches = branches(c,v1178_3_tail);
                std::vector<Space> v1179_3_outputs;
                v1179_3_outputs.reserve(v1179_3_branches.size());
                for (const auto& v1179_3_branch : v1179_3_branches) {
                  const Path v1179_3_head{v1179_3_branch.first};
                  const Space& v1179_3_tail = v1179_3_branch.second;
                  const Path v1180_2 = concat_path(v1179_2,v1179_3_head);
                  const Space v1180_3 = routine_148(c, v1180_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1176_2, v1179_3_tail);
                  v1179_3_outputs.push_back(v1180_3);
                }
                const Space v1179_3 = join_outputs(std::move(v1179_3_outputs));
                v1178_3_outputs.push_back(v1179_3);
              }
              const Space v1178_3 = join_outputs(std::move(v1178_3_outputs));
              v1177_2_outputs.push_back(v1178_3);
            }
            const Space v1177_2 = join_outputs(std::move(v1177_2_outputs));
            v1176_3_outputs.push_back(v1177_2);
          }
          const Space v1176_3 = join_outputs(std::move(v1176_3_outputs));
          v1175_3_outputs.push_back(v1176_3);
        }
        const Space v1175_3 = join_outputs(std::move(v1175_3_outputs));
        v1174_3_outputs.push_back(v1175_3);
      }
      const Space v1174_3 = join_outputs(std::move(v1174_3_outputs));
      v1173_2_outputs.push_back(v1174_3);
    }
    const Space v1173_2 = join_outputs(std::move(v1173_2_outputs));
    v1172_14_outputs.push_back(v1173_2);
  }
  const Space v1172_14 = join_outputs(std::move(v1172_14_outputs));
  return v1172_14;
}

static Space routine_133(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1181_14_branches = branches(c,s0);
  std::vector<Space> v1181_14_outputs;
  v1181_14_outputs.reserve(v1181_14_branches.size());
  for (const auto& v1181_14_branch : v1181_14_branches) {
    const Path v1181_14_head{v1181_14_branch.first};
    const Space& v1181_14_tail = v1181_14_branch.second;
    const auto v1182_2_branches = branches(c,v1181_14_tail);
    std::vector<Space> v1182_2_outputs;
    v1182_2_outputs.reserve(v1182_2_branches.size());
    for (const auto& v1182_2_branch : v1182_2_branches) {
      const Path v1182_2_head{v1182_2_branch.first};
      const Space& v1182_2_tail = v1182_2_branch.second;
      const Path v1183_2 = concat_path(v1181_14_head,v1182_2_head);
      const auto v1183_3_branches = branches(c,v1182_2_tail);
      std::vector<Space> v1183_3_outputs;
      v1183_3_outputs.reserve(v1183_3_branches.size());
      for (const auto& v1183_3_branch : v1183_3_branches) {
        const Path v1183_3_head{v1183_3_branch.first};
        const Space& v1183_3_tail = v1183_3_branch.second;
        const Path v1184_2 = concat_path(v1183_2,v1183_3_head);
        const auto v1184_3_branches = branches(c,v1183_3_tail);
        std::vector<Space> v1184_3_outputs;
        v1184_3_outputs.reserve(v1184_3_branches.size());
        for (const auto& v1184_3_branch : v1184_3_branches) {
          const Path v1184_3_head{v1184_3_branch.first};
          const Space& v1184_3_tail = v1184_3_branch.second;
          const Path v1185_2 = concat_path(v1184_2,v1184_3_head);
          const auto v1185_3_branches = branches(c,v1184_3_tail);
          std::vector<Space> v1185_3_outputs;
          v1185_3_outputs.reserve(v1185_3_branches.size());
          for (const auto& v1185_3_branch : v1185_3_branches) {
            const Path v1185_3_head{v1185_3_branch.first};
            const Space& v1185_3_tail = v1185_3_branch.second;
            const auto v1186_2_branches = branches(c,v1185_3_tail);
            std::vector<Space> v1186_2_outputs;
            v1186_2_outputs.reserve(v1186_2_branches.size());
            for (const auto& v1186_2_branch : v1186_2_branches) {
              const Path v1186_2_head{v1186_2_branch.first};
              const Space& v1186_2_tail = v1186_2_branch.second;
              const Path v1187_2 = concat_path(v1185_3_head,v1186_2_head);
              const auto v1187_3_branches = branches(c,v1186_2_tail);
              std::vector<Space> v1187_3_outputs;
              v1187_3_outputs.reserve(v1187_3_branches.size());
              for (const auto& v1187_3_branch : v1187_3_branches) {
                const Path v1187_3_head{v1187_3_branch.first};
                const Space& v1187_3_tail = v1187_3_branch.second;
                const Path v1188_2 = concat_path(v1187_2,v1187_3_head);
                const auto v1188_3_branches = branches(c,v1187_3_tail);
                std::vector<Space> v1188_3_outputs;
                v1188_3_outputs.reserve(v1188_3_branches.size());
                for (const auto& v1188_3_branch : v1188_3_branches) {
                  const Path v1188_3_head{v1188_3_branch.first};
                  const Space& v1188_3_tail = v1188_3_branch.second;
                  const Path v1189_2 = concat_path(v1188_2,v1188_3_head);
                  const Space v1189_3 = routine_149(c, v1189_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1185_2, v1188_3_tail);
                  v1188_3_outputs.push_back(v1189_3);
                }
                const Space v1188_3 = join_outputs(std::move(v1188_3_outputs));
                v1187_3_outputs.push_back(v1188_3);
              }
              const Space v1187_3 = join_outputs(std::move(v1187_3_outputs));
              v1186_2_outputs.push_back(v1187_3);
            }
            const Space v1186_2 = join_outputs(std::move(v1186_2_outputs));
            v1185_3_outputs.push_back(v1186_2);
          }
          const Space v1185_3 = join_outputs(std::move(v1185_3_outputs));
          v1184_3_outputs.push_back(v1185_3);
        }
        const Space v1184_3 = join_outputs(std::move(v1184_3_outputs));
        v1183_3_outputs.push_back(v1184_3);
      }
      const Space v1183_3 = join_outputs(std::move(v1183_3_outputs));
      v1182_2_outputs.push_back(v1183_3);
    }
    const Space v1182_2 = join_outputs(std::move(v1182_2_outputs));
    v1181_14_outputs.push_back(v1182_2);
  }
  const Space v1181_14 = join_outputs(std::move(v1181_14_outputs));
  return v1181_14;
}

static Space routine_134(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1190_14_branches = branches(c,s0);
  std::vector<Space> v1190_14_outputs;
  v1190_14_outputs.reserve(v1190_14_branches.size());
  for (const auto& v1190_14_branch : v1190_14_branches) {
    const Path v1190_14_head{v1190_14_branch.first};
    const Space& v1190_14_tail = v1190_14_branch.second;
    const auto v1191_2_branches = branches(c,v1190_14_tail);
    std::vector<Space> v1191_2_outputs;
    v1191_2_outputs.reserve(v1191_2_branches.size());
    for (const auto& v1191_2_branch : v1191_2_branches) {
      const Path v1191_2_head{v1191_2_branch.first};
      const Space& v1191_2_tail = v1191_2_branch.second;
      const Path v1192_2 = concat_path(v1190_14_head,v1191_2_head);
      const auto v1192_3_branches = branches(c,v1191_2_tail);
      std::vector<Space> v1192_3_outputs;
      v1192_3_outputs.reserve(v1192_3_branches.size());
      for (const auto& v1192_3_branch : v1192_3_branches) {
        const Path v1192_3_head{v1192_3_branch.first};
        const Space& v1192_3_tail = v1192_3_branch.second;
        const Path v1193_2 = concat_path(v1192_2,v1192_3_head);
        const auto v1193_3_branches = branches(c,v1192_3_tail);
        std::vector<Space> v1193_3_outputs;
        v1193_3_outputs.reserve(v1193_3_branches.size());
        for (const auto& v1193_3_branch : v1193_3_branches) {
          const Path v1193_3_head{v1193_3_branch.first};
          const Space& v1193_3_tail = v1193_3_branch.second;
          const Path v1194_2 = concat_path(v1193_2,v1193_3_head);
          const auto v1194_3_branches = branches(c,v1193_3_tail);
          std::vector<Space> v1194_3_outputs;
          v1194_3_outputs.reserve(v1194_3_branches.size());
          for (const auto& v1194_3_branch : v1194_3_branches) {
            const Path v1194_3_head{v1194_3_branch.first};
            const Space& v1194_3_tail = v1194_3_branch.second;
            const auto v1195_2_branches = branches(c,v1194_3_tail);
            std::vector<Space> v1195_2_outputs;
            v1195_2_outputs.reserve(v1195_2_branches.size());
            for (const auto& v1195_2_branch : v1195_2_branches) {
              const Path v1195_2_head{v1195_2_branch.first};
              const Space& v1195_2_tail = v1195_2_branch.second;
              const Path v1196_2 = concat_path(v1194_3_head,v1195_2_head);
              const auto v1196_3_branches = branches(c,v1195_2_tail);
              std::vector<Space> v1196_3_outputs;
              v1196_3_outputs.reserve(v1196_3_branches.size());
              for (const auto& v1196_3_branch : v1196_3_branches) {
                const Path v1196_3_head{v1196_3_branch.first};
                const Space& v1196_3_tail = v1196_3_branch.second;
                const Path v1197_2 = concat_path(v1196_2,v1196_3_head);
                const auto v1197_3_branches = branches(c,v1196_3_tail);
                std::vector<Space> v1197_3_outputs;
                v1197_3_outputs.reserve(v1197_3_branches.size());
                for (const auto& v1197_3_branch : v1197_3_branches) {
                  const Path v1197_3_head{v1197_3_branch.first};
                  const Space& v1197_3_tail = v1197_3_branch.second;
                  const Path v1198_2 = concat_path(v1197_2,v1197_3_head);
                  const Space v1198_3 = routine_150(c, v1198_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1194_2, v1197_3_tail);
                  v1197_3_outputs.push_back(v1198_3);
                }
                const Space v1197_3 = join_outputs(std::move(v1197_3_outputs));
                v1196_3_outputs.push_back(v1197_3);
              }
              const Space v1196_3 = join_outputs(std::move(v1196_3_outputs));
              v1195_2_outputs.push_back(v1196_3);
            }
            const Space v1195_2 = join_outputs(std::move(v1195_2_outputs));
            v1194_3_outputs.push_back(v1195_2);
          }
          const Space v1194_3 = join_outputs(std::move(v1194_3_outputs));
          v1193_3_outputs.push_back(v1194_3);
        }
        const Space v1193_3 = join_outputs(std::move(v1193_3_outputs));
        v1192_3_outputs.push_back(v1193_3);
      }
      const Space v1192_3 = join_outputs(std::move(v1192_3_outputs));
      v1191_2_outputs.push_back(v1192_3);
    }
    const Space v1191_2 = join_outputs(std::move(v1191_2_outputs));
    v1190_14_outputs.push_back(v1191_2);
  }
  const Space v1190_14 = join_outputs(std::move(v1190_14_outputs));
  return v1190_14;
}

static Space routine_135(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1199_14_branches = branches(c,s0);
  std::vector<Space> v1199_14_outputs;
  v1199_14_outputs.reserve(v1199_14_branches.size());
  for (const auto& v1199_14_branch : v1199_14_branches) {
    const Path v1199_14_head{v1199_14_branch.first};
    const Space& v1199_14_tail = v1199_14_branch.second;
    const auto v1200_2_branches = branches(c,v1199_14_tail);
    std::vector<Space> v1200_2_outputs;
    v1200_2_outputs.reserve(v1200_2_branches.size());
    for (const auto& v1200_2_branch : v1200_2_branches) {
      const Path v1200_2_head{v1200_2_branch.first};
      const Space& v1200_2_tail = v1200_2_branch.second;
      const Path v1201_2 = concat_path(v1199_14_head,v1200_2_head);
      const auto v1201_3_branches = branches(c,v1200_2_tail);
      std::vector<Space> v1201_3_outputs;
      v1201_3_outputs.reserve(v1201_3_branches.size());
      for (const auto& v1201_3_branch : v1201_3_branches) {
        const Path v1201_3_head{v1201_3_branch.first};
        const Space& v1201_3_tail = v1201_3_branch.second;
        const Path v1202_2 = concat_path(v1201_2,v1201_3_head);
        const auto v1202_3_branches = branches(c,v1201_3_tail);
        std::vector<Space> v1202_3_outputs;
        v1202_3_outputs.reserve(v1202_3_branches.size());
        for (const auto& v1202_3_branch : v1202_3_branches) {
          const Path v1202_3_head{v1202_3_branch.first};
          const Space& v1202_3_tail = v1202_3_branch.second;
          const Path v1203_2 = concat_path(v1202_2,v1202_3_head);
          const auto v1203_3_branches = branches(c,v1202_3_tail);
          std::vector<Space> v1203_3_outputs;
          v1203_3_outputs.reserve(v1203_3_branches.size());
          for (const auto& v1203_3_branch : v1203_3_branches) {
            const Path v1203_3_head{v1203_3_branch.first};
            const Space& v1203_3_tail = v1203_3_branch.second;
            const auto v1204_2_branches = branches(c,v1203_3_tail);
            std::vector<Space> v1204_2_outputs;
            v1204_2_outputs.reserve(v1204_2_branches.size());
            for (const auto& v1204_2_branch : v1204_2_branches) {
              const Path v1204_2_head{v1204_2_branch.first};
              const Space& v1204_2_tail = v1204_2_branch.second;
              const Path v1205_2 = concat_path(v1203_3_head,v1204_2_head);
              const auto v1205_3_branches = branches(c,v1204_2_tail);
              std::vector<Space> v1205_3_outputs;
              v1205_3_outputs.reserve(v1205_3_branches.size());
              for (const auto& v1205_3_branch : v1205_3_branches) {
                const Path v1205_3_head{v1205_3_branch.first};
                const Space& v1205_3_tail = v1205_3_branch.second;
                const Path v1206_2 = concat_path(v1205_2,v1205_3_head);
                const auto v1206_3_branches = branches(c,v1205_3_tail);
                std::vector<Space> v1206_3_outputs;
                v1206_3_outputs.reserve(v1206_3_branches.size());
                for (const auto& v1206_3_branch : v1206_3_branches) {
                  const Path v1206_3_head{v1206_3_branch.first};
                  const Space& v1206_3_tail = v1206_3_branch.second;
                  const Path v1207_2 = concat_path(v1206_2,v1206_3_head);
                  const Space v1207_3 = routine_151(c, v1207_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1203_2, v1206_3_tail);
                  v1206_3_outputs.push_back(v1207_3);
                }
                const Space v1206_3 = join_outputs(std::move(v1206_3_outputs));
                v1205_3_outputs.push_back(v1206_3);
              }
              const Space v1205_3 = join_outputs(std::move(v1205_3_outputs));
              v1204_2_outputs.push_back(v1205_3);
            }
            const Space v1204_2 = join_outputs(std::move(v1204_2_outputs));
            v1203_3_outputs.push_back(v1204_2);
          }
          const Space v1203_3 = join_outputs(std::move(v1203_3_outputs));
          v1202_3_outputs.push_back(v1203_3);
        }
        const Space v1202_3 = join_outputs(std::move(v1202_3_outputs));
        v1201_3_outputs.push_back(v1202_3);
      }
      const Space v1201_3 = join_outputs(std::move(v1201_3_outputs));
      v1200_2_outputs.push_back(v1201_3);
    }
    const Space v1200_2 = join_outputs(std::move(v1200_2_outputs));
    v1199_14_outputs.push_back(v1200_2);
  }
  const Space v1199_14 = join_outputs(std::move(v1199_14_outputs));
  return v1199_14;
}

static Space routine_136(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1208_14_branches = branches(c,s0);
  std::vector<Space> v1208_14_outputs;
  v1208_14_outputs.reserve(v1208_14_branches.size());
  for (const auto& v1208_14_branch : v1208_14_branches) {
    const Path v1208_14_head{v1208_14_branch.first};
    const Space& v1208_14_tail = v1208_14_branch.second;
    const auto v1209_2_branches = branches(c,v1208_14_tail);
    std::vector<Space> v1209_2_outputs;
    v1209_2_outputs.reserve(v1209_2_branches.size());
    for (const auto& v1209_2_branch : v1209_2_branches) {
      const Path v1209_2_head{v1209_2_branch.first};
      const Space& v1209_2_tail = v1209_2_branch.second;
      const Path v1210_2 = concat_path(v1208_14_head,v1209_2_head);
      const auto v1210_3_branches = branches(c,v1209_2_tail);
      std::vector<Space> v1210_3_outputs;
      v1210_3_outputs.reserve(v1210_3_branches.size());
      for (const auto& v1210_3_branch : v1210_3_branches) {
        const Path v1210_3_head{v1210_3_branch.first};
        const Space& v1210_3_tail = v1210_3_branch.second;
        const Path v1211_2 = concat_path(v1210_2,v1210_3_head);
        const auto v1211_3_branches = branches(c,v1210_3_tail);
        std::vector<Space> v1211_3_outputs;
        v1211_3_outputs.reserve(v1211_3_branches.size());
        for (const auto& v1211_3_branch : v1211_3_branches) {
          const Path v1211_3_head{v1211_3_branch.first};
          const Space& v1211_3_tail = v1211_3_branch.second;
          const Path v1212_2 = concat_path(v1211_2,v1211_3_head);
          const auto v1212_3_branches = branches(c,v1211_3_tail);
          std::vector<Space> v1212_3_outputs;
          v1212_3_outputs.reserve(v1212_3_branches.size());
          for (const auto& v1212_3_branch : v1212_3_branches) {
            const Path v1212_3_head{v1212_3_branch.first};
            const Space& v1212_3_tail = v1212_3_branch.second;
            const auto v1213_2_branches = branches(c,v1212_3_tail);
            std::vector<Space> v1213_2_outputs;
            v1213_2_outputs.reserve(v1213_2_branches.size());
            for (const auto& v1213_2_branch : v1213_2_branches) {
              const Path v1213_2_head{v1213_2_branch.first};
              const Space& v1213_2_tail = v1213_2_branch.second;
              const Path v1214_2 = concat_path(v1212_3_head,v1213_2_head);
              const auto v1214_3_branches = branches(c,v1213_2_tail);
              std::vector<Space> v1214_3_outputs;
              v1214_3_outputs.reserve(v1214_3_branches.size());
              for (const auto& v1214_3_branch : v1214_3_branches) {
                const Path v1214_3_head{v1214_3_branch.first};
                const Space& v1214_3_tail = v1214_3_branch.second;
                const Path v1215_2 = concat_path(v1214_2,v1214_3_head);
                const auto v1215_3_branches = branches(c,v1214_3_tail);
                std::vector<Space> v1215_3_outputs;
                v1215_3_outputs.reserve(v1215_3_branches.size());
                for (const auto& v1215_3_branch : v1215_3_branches) {
                  const Path v1215_3_head{v1215_3_branch.first};
                  const Space& v1215_3_tail = v1215_3_branch.second;
                  const Path v1216_2 = concat_path(v1215_2,v1215_3_head);
                  const Space v1216_3 = routine_152(c, v1216_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1212_2, v1215_3_tail);
                  v1215_3_outputs.push_back(v1216_3);
                }
                const Space v1215_3 = join_outputs(std::move(v1215_3_outputs));
                v1214_3_outputs.push_back(v1215_3);
              }
              const Space v1214_3 = join_outputs(std::move(v1214_3_outputs));
              v1213_2_outputs.push_back(v1214_3);
            }
            const Space v1213_2 = join_outputs(std::move(v1213_2_outputs));
            v1212_3_outputs.push_back(v1213_2);
          }
          const Space v1212_3 = join_outputs(std::move(v1212_3_outputs));
          v1211_3_outputs.push_back(v1212_3);
        }
        const Space v1211_3 = join_outputs(std::move(v1211_3_outputs));
        v1210_3_outputs.push_back(v1211_3);
      }
      const Space v1210_3 = join_outputs(std::move(v1210_3_outputs));
      v1209_2_outputs.push_back(v1210_3);
    }
    const Space v1209_2 = join_outputs(std::move(v1209_2_outputs));
    v1208_14_outputs.push_back(v1209_2);
  }
  const Space v1208_14 = join_outputs(std::move(v1208_14_outputs));
  return v1208_14;
}

static Space routine_137(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1217_14_branches = branches(c,s0);
  std::vector<Space> v1217_14_outputs;
  v1217_14_outputs.reserve(v1217_14_branches.size());
  for (const auto& v1217_14_branch : v1217_14_branches) {
    const Path v1217_14_head{v1217_14_branch.first};
    const Space& v1217_14_tail = v1217_14_branch.second;
    const auto v1218_2_branches = branches(c,v1217_14_tail);
    std::vector<Space> v1218_2_outputs;
    v1218_2_outputs.reserve(v1218_2_branches.size());
    for (const auto& v1218_2_branch : v1218_2_branches) {
      const Path v1218_2_head{v1218_2_branch.first};
      const Space& v1218_2_tail = v1218_2_branch.second;
      const Path v1219_2 = concat_path(v1217_14_head,v1218_2_head);
      const auto v1219_3_branches = branches(c,v1218_2_tail);
      std::vector<Space> v1219_3_outputs;
      v1219_3_outputs.reserve(v1219_3_branches.size());
      for (const auto& v1219_3_branch : v1219_3_branches) {
        const Path v1219_3_head{v1219_3_branch.first};
        const Space& v1219_3_tail = v1219_3_branch.second;
        const Path v1220_2 = concat_path(v1219_2,v1219_3_head);
        const auto v1220_3_branches = branches(c,v1219_3_tail);
        std::vector<Space> v1220_3_outputs;
        v1220_3_outputs.reserve(v1220_3_branches.size());
        for (const auto& v1220_3_branch : v1220_3_branches) {
          const Path v1220_3_head{v1220_3_branch.first};
          const Space& v1220_3_tail = v1220_3_branch.second;
          const Path v1221_2 = concat_path(v1220_2,v1220_3_head);
          const auto v1221_3_branches = branches(c,v1220_3_tail);
          std::vector<Space> v1221_3_outputs;
          v1221_3_outputs.reserve(v1221_3_branches.size());
          for (const auto& v1221_3_branch : v1221_3_branches) {
            const Path v1221_3_head{v1221_3_branch.first};
            const Space& v1221_3_tail = v1221_3_branch.second;
            const auto v1222_2_branches = branches(c,v1221_3_tail);
            std::vector<Space> v1222_2_outputs;
            v1222_2_outputs.reserve(v1222_2_branches.size());
            for (const auto& v1222_2_branch : v1222_2_branches) {
              const Path v1222_2_head{v1222_2_branch.first};
              const Space& v1222_2_tail = v1222_2_branch.second;
              const Path v1223_2 = concat_path(v1221_3_head,v1222_2_head);
              const auto v1223_3_branches = branches(c,v1222_2_tail);
              std::vector<Space> v1223_3_outputs;
              v1223_3_outputs.reserve(v1223_3_branches.size());
              for (const auto& v1223_3_branch : v1223_3_branches) {
                const Path v1223_3_head{v1223_3_branch.first};
                const Space& v1223_3_tail = v1223_3_branch.second;
                const Path v1224_2 = concat_path(v1223_2,v1223_3_head);
                const auto v1224_3_branches = branches(c,v1223_3_tail);
                std::vector<Space> v1224_3_outputs;
                v1224_3_outputs.reserve(v1224_3_branches.size());
                for (const auto& v1224_3_branch : v1224_3_branches) {
                  const Path v1224_3_head{v1224_3_branch.first};
                  const Space& v1224_3_tail = v1224_3_branch.second;
                  const Path v1225_2 = concat_path(v1224_2,v1224_3_head);
                  const Space v1225_3 = routine_153(c, v1225_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1221_2, v1224_3_tail);
                  v1224_3_outputs.push_back(v1225_3);
                }
                const Space v1224_3 = join_outputs(std::move(v1224_3_outputs));
                v1223_3_outputs.push_back(v1224_3);
              }
              const Space v1223_3 = join_outputs(std::move(v1223_3_outputs));
              v1222_2_outputs.push_back(v1223_3);
            }
            const Space v1222_2 = join_outputs(std::move(v1222_2_outputs));
            v1221_3_outputs.push_back(v1222_2);
          }
          const Space v1221_3 = join_outputs(std::move(v1221_3_outputs));
          v1220_3_outputs.push_back(v1221_3);
        }
        const Space v1220_3 = join_outputs(std::move(v1220_3_outputs));
        v1219_3_outputs.push_back(v1220_3);
      }
      const Space v1219_3 = join_outputs(std::move(v1219_3_outputs));
      v1218_2_outputs.push_back(v1219_3);
    }
    const Space v1218_2 = join_outputs(std::move(v1218_2_outputs));
    v1217_14_outputs.push_back(v1218_2);
  }
  const Space v1217_14 = join_outputs(std::move(v1217_14_outputs));
  return v1217_14;
}

static Space routine_138(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1226_14_branches = branches(c,s0);
  std::vector<Space> v1226_14_outputs;
  v1226_14_outputs.reserve(v1226_14_branches.size());
  for (const auto& v1226_14_branch : v1226_14_branches) {
    const Path v1226_14_head{v1226_14_branch.first};
    const Space& v1226_14_tail = v1226_14_branch.second;
    const auto v1227_2_branches = branches(c,v1226_14_tail);
    std::vector<Space> v1227_2_outputs;
    v1227_2_outputs.reserve(v1227_2_branches.size());
    for (const auto& v1227_2_branch : v1227_2_branches) {
      const Path v1227_2_head{v1227_2_branch.first};
      const Space& v1227_2_tail = v1227_2_branch.second;
      const Path v1228_2 = concat_path(v1226_14_head,v1227_2_head);
      const auto v1228_3_branches = branches(c,v1227_2_tail);
      std::vector<Space> v1228_3_outputs;
      v1228_3_outputs.reserve(v1228_3_branches.size());
      for (const auto& v1228_3_branch : v1228_3_branches) {
        const Path v1228_3_head{v1228_3_branch.first};
        const Space& v1228_3_tail = v1228_3_branch.second;
        const Path v1229_2 = concat_path(v1228_2,v1228_3_head);
        const auto v1229_3_branches = branches(c,v1228_3_tail);
        std::vector<Space> v1229_3_outputs;
        v1229_3_outputs.reserve(v1229_3_branches.size());
        for (const auto& v1229_3_branch : v1229_3_branches) {
          const Path v1229_3_head{v1229_3_branch.first};
          const Space& v1229_3_tail = v1229_3_branch.second;
          const Path v1230_2 = concat_path(v1229_2,v1229_3_head);
          const auto v1230_3_branches = branches(c,v1229_3_tail);
          std::vector<Space> v1230_3_outputs;
          v1230_3_outputs.reserve(v1230_3_branches.size());
          for (const auto& v1230_3_branch : v1230_3_branches) {
            const Path v1230_3_head{v1230_3_branch.first};
            const Space& v1230_3_tail = v1230_3_branch.second;
            const auto v1231_2_branches = branches(c,v1230_3_tail);
            std::vector<Space> v1231_2_outputs;
            v1231_2_outputs.reserve(v1231_2_branches.size());
            for (const auto& v1231_2_branch : v1231_2_branches) {
              const Path v1231_2_head{v1231_2_branch.first};
              const Space& v1231_2_tail = v1231_2_branch.second;
              const Path v1232_2 = concat_path(v1230_3_head,v1231_2_head);
              const auto v1232_3_branches = branches(c,v1231_2_tail);
              std::vector<Space> v1232_3_outputs;
              v1232_3_outputs.reserve(v1232_3_branches.size());
              for (const auto& v1232_3_branch : v1232_3_branches) {
                const Path v1232_3_head{v1232_3_branch.first};
                const Space& v1232_3_tail = v1232_3_branch.second;
                const Path v1233_2 = concat_path(v1232_2,v1232_3_head);
                const auto v1233_3_branches = branches(c,v1232_3_tail);
                std::vector<Space> v1233_3_outputs;
                v1233_3_outputs.reserve(v1233_3_branches.size());
                for (const auto& v1233_3_branch : v1233_3_branches) {
                  const Path v1233_3_head{v1233_3_branch.first};
                  const Space& v1233_3_tail = v1233_3_branch.second;
                  const Path v1234_2 = concat_path(v1233_2,v1233_3_head);
                  const Space v1234_3 = routine_154(c, v1234_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1230_2, v1233_3_tail);
                  v1233_3_outputs.push_back(v1234_3);
                }
                const Space v1233_3 = join_outputs(std::move(v1233_3_outputs));
                v1232_3_outputs.push_back(v1233_3);
              }
              const Space v1232_3 = join_outputs(std::move(v1232_3_outputs));
              v1231_2_outputs.push_back(v1232_3);
            }
            const Space v1231_2 = join_outputs(std::move(v1231_2_outputs));
            v1230_3_outputs.push_back(v1231_2);
          }
          const Space v1230_3 = join_outputs(std::move(v1230_3_outputs));
          v1229_3_outputs.push_back(v1230_3);
        }
        const Space v1229_3 = join_outputs(std::move(v1229_3_outputs));
        v1228_3_outputs.push_back(v1229_3);
      }
      const Space v1228_3 = join_outputs(std::move(v1228_3_outputs));
      v1227_2_outputs.push_back(v1228_3);
    }
    const Space v1227_2 = join_outputs(std::move(v1227_2_outputs));
    v1226_14_outputs.push_back(v1227_2);
  }
  const Space v1226_14 = join_outputs(std::move(v1226_14_outputs));
  return v1226_14;
}

static Space routine_139(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1235_14_branches = branches(c,s0);
  std::vector<Space> v1235_14_outputs;
  v1235_14_outputs.reserve(v1235_14_branches.size());
  for (const auto& v1235_14_branch : v1235_14_branches) {
    const Path v1235_14_head{v1235_14_branch.first};
    const Space& v1235_14_tail = v1235_14_branch.second;
    const auto v1236_2_branches = branches(c,v1235_14_tail);
    std::vector<Space> v1236_2_outputs;
    v1236_2_outputs.reserve(v1236_2_branches.size());
    for (const auto& v1236_2_branch : v1236_2_branches) {
      const Path v1236_2_head{v1236_2_branch.first};
      const Space& v1236_2_tail = v1236_2_branch.second;
      const Path v1237_2 = concat_path(v1235_14_head,v1236_2_head);
      const auto v1237_3_branches = branches(c,v1236_2_tail);
      std::vector<Space> v1237_3_outputs;
      v1237_3_outputs.reserve(v1237_3_branches.size());
      for (const auto& v1237_3_branch : v1237_3_branches) {
        const Path v1237_3_head{v1237_3_branch.first};
        const Space& v1237_3_tail = v1237_3_branch.second;
        const Path v1238_2 = concat_path(v1237_2,v1237_3_head);
        const auto v1238_3_branches = branches(c,v1237_3_tail);
        std::vector<Space> v1238_3_outputs;
        v1238_3_outputs.reserve(v1238_3_branches.size());
        for (const auto& v1238_3_branch : v1238_3_branches) {
          const Path v1238_3_head{v1238_3_branch.first};
          const Space& v1238_3_tail = v1238_3_branch.second;
          const Path v1239_2 = concat_path(v1238_2,v1238_3_head);
          const auto v1239_3_branches = branches(c,v1238_3_tail);
          std::vector<Space> v1239_3_outputs;
          v1239_3_outputs.reserve(v1239_3_branches.size());
          for (const auto& v1239_3_branch : v1239_3_branches) {
            const Path v1239_3_head{v1239_3_branch.first};
            const Space& v1239_3_tail = v1239_3_branch.second;
            const auto v1240_2_branches = branches(c,v1239_3_tail);
            std::vector<Space> v1240_2_outputs;
            v1240_2_outputs.reserve(v1240_2_branches.size());
            for (const auto& v1240_2_branch : v1240_2_branches) {
              const Path v1240_2_head{v1240_2_branch.first};
              const Space& v1240_2_tail = v1240_2_branch.second;
              const Path v1241_2 = concat_path(v1239_3_head,v1240_2_head);
              const auto v1241_3_branches = branches(c,v1240_2_tail);
              std::vector<Space> v1241_3_outputs;
              v1241_3_outputs.reserve(v1241_3_branches.size());
              for (const auto& v1241_3_branch : v1241_3_branches) {
                const Path v1241_3_head{v1241_3_branch.first};
                const Space& v1241_3_tail = v1241_3_branch.second;
                const Path v1242_2 = concat_path(v1241_2,v1241_3_head);
                const auto v1242_3_branches = branches(c,v1241_3_tail);
                std::vector<Space> v1242_3_outputs;
                v1242_3_outputs.reserve(v1242_3_branches.size());
                for (const auto& v1242_3_branch : v1242_3_branches) {
                  const Path v1242_3_head{v1242_3_branch.first};
                  const Space& v1242_3_tail = v1242_3_branch.second;
                  const Path v1243_2 = concat_path(v1242_2,v1242_3_head);
                  const Space v1243_3 = routine_155(c, v1243_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1239_2, v1242_3_tail);
                  v1242_3_outputs.push_back(v1243_3);
                }
                const Space v1242_3 = join_outputs(std::move(v1242_3_outputs));
                v1241_3_outputs.push_back(v1242_3);
              }
              const Space v1241_3 = join_outputs(std::move(v1241_3_outputs));
              v1240_2_outputs.push_back(v1241_3);
            }
            const Space v1240_2 = join_outputs(std::move(v1240_2_outputs));
            v1239_3_outputs.push_back(v1240_2);
          }
          const Space v1239_3 = join_outputs(std::move(v1239_3_outputs));
          v1238_3_outputs.push_back(v1239_3);
        }
        const Space v1238_3 = join_outputs(std::move(v1238_3_outputs));
        v1237_3_outputs.push_back(v1238_3);
      }
      const Space v1237_3 = join_outputs(std::move(v1237_3_outputs));
      v1236_2_outputs.push_back(v1237_3);
    }
    const Space v1236_2 = join_outputs(std::move(v1236_2_outputs));
    v1235_14_outputs.push_back(v1236_2);
  }
  const Space v1235_14 = join_outputs(std::move(v1235_14_outputs));
  return v1235_14;
}

static Space routine_140(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1244_14_branches = branches(c,s0);
  std::vector<Space> v1244_14_outputs;
  v1244_14_outputs.reserve(v1244_14_branches.size());
  for (const auto& v1244_14_branch : v1244_14_branches) {
    const Path v1244_14_head{v1244_14_branch.first};
    const Space& v1244_14_tail = v1244_14_branch.second;
    const auto v1245_2_branches = branches(c,v1244_14_tail);
    std::vector<Space> v1245_2_outputs;
    v1245_2_outputs.reserve(v1245_2_branches.size());
    for (const auto& v1245_2_branch : v1245_2_branches) {
      const Path v1245_2_head{v1245_2_branch.first};
      const Space& v1245_2_tail = v1245_2_branch.second;
      const Path v1246_2 = concat_path(v1244_14_head,v1245_2_head);
      const auto v1246_3_branches = branches(c,v1245_2_tail);
      std::vector<Space> v1246_3_outputs;
      v1246_3_outputs.reserve(v1246_3_branches.size());
      for (const auto& v1246_3_branch : v1246_3_branches) {
        const Path v1246_3_head{v1246_3_branch.first};
        const Space& v1246_3_tail = v1246_3_branch.second;
        const Path v1247_2 = concat_path(v1246_2,v1246_3_head);
        const auto v1247_3_branches = branches(c,v1246_3_tail);
        std::vector<Space> v1247_3_outputs;
        v1247_3_outputs.reserve(v1247_3_branches.size());
        for (const auto& v1247_3_branch : v1247_3_branches) {
          const Path v1247_3_head{v1247_3_branch.first};
          const Space& v1247_3_tail = v1247_3_branch.second;
          const Path v1248_2 = concat_path(v1247_2,v1247_3_head);
          const auto v1248_3_branches = branches(c,v1247_3_tail);
          std::vector<Space> v1248_3_outputs;
          v1248_3_outputs.reserve(v1248_3_branches.size());
          for (const auto& v1248_3_branch : v1248_3_branches) {
            const Path v1248_3_head{v1248_3_branch.first};
            const Space& v1248_3_tail = v1248_3_branch.second;
            const auto v1249_2_branches = branches(c,v1248_3_tail);
            std::vector<Space> v1249_2_outputs;
            v1249_2_outputs.reserve(v1249_2_branches.size());
            for (const auto& v1249_2_branch : v1249_2_branches) {
              const Path v1249_2_head{v1249_2_branch.first};
              const Space& v1249_2_tail = v1249_2_branch.second;
              const Path v1250_2 = concat_path(v1248_3_head,v1249_2_head);
              const auto v1250_3_branches = branches(c,v1249_2_tail);
              std::vector<Space> v1250_3_outputs;
              v1250_3_outputs.reserve(v1250_3_branches.size());
              for (const auto& v1250_3_branch : v1250_3_branches) {
                const Path v1250_3_head{v1250_3_branch.first};
                const Space& v1250_3_tail = v1250_3_branch.second;
                const Path v1251_2 = concat_path(v1250_2,v1250_3_head);
                const auto v1251_3_branches = branches(c,v1250_3_tail);
                std::vector<Space> v1251_3_outputs;
                v1251_3_outputs.reserve(v1251_3_branches.size());
                for (const auto& v1251_3_branch : v1251_3_branches) {
                  const Path v1251_3_head{v1251_3_branch.first};
                  const Space& v1251_3_tail = v1251_3_branch.second;
                  const Path v1252_2 = concat_path(v1251_2,v1251_3_head);
                  const Space v1252_3 = routine_156(c, v1252_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1248_2, v1251_3_tail);
                  v1251_3_outputs.push_back(v1252_3);
                }
                const Space v1251_3 = join_outputs(std::move(v1251_3_outputs));
                v1250_3_outputs.push_back(v1251_3);
              }
              const Space v1250_3 = join_outputs(std::move(v1250_3_outputs));
              v1249_2_outputs.push_back(v1250_3);
            }
            const Space v1249_2 = join_outputs(std::move(v1249_2_outputs));
            v1248_3_outputs.push_back(v1249_2);
          }
          const Space v1248_3 = join_outputs(std::move(v1248_3_outputs));
          v1247_3_outputs.push_back(v1248_3);
        }
        const Space v1247_3 = join_outputs(std::move(v1247_3_outputs));
        v1246_3_outputs.push_back(v1247_3);
      }
      const Space v1246_3 = join_outputs(std::move(v1246_3_outputs));
      v1245_2_outputs.push_back(v1246_3);
    }
    const Space v1245_2 = join_outputs(std::move(v1245_2_outputs));
    v1244_14_outputs.push_back(v1245_2);
  }
  const Space v1244_14 = join_outputs(std::move(v1244_14_outputs));
  return v1244_14;
}

static Space routine_141(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1253_14_branches = branches(c,s0);
  std::vector<Space> v1253_14_outputs;
  v1253_14_outputs.reserve(v1253_14_branches.size());
  for (const auto& v1253_14_branch : v1253_14_branches) {
    const Path v1253_14_head{v1253_14_branch.first};
    const Space& v1253_14_tail = v1253_14_branch.second;
    const auto v1254_2_branches = branches(c,v1253_14_tail);
    std::vector<Space> v1254_2_outputs;
    v1254_2_outputs.reserve(v1254_2_branches.size());
    for (const auto& v1254_2_branch : v1254_2_branches) {
      const Path v1254_2_head{v1254_2_branch.first};
      const Space& v1254_2_tail = v1254_2_branch.second;
      const Path v1255_2 = concat_path(v1253_14_head,v1254_2_head);
      const auto v1255_3_branches = branches(c,v1254_2_tail);
      std::vector<Space> v1255_3_outputs;
      v1255_3_outputs.reserve(v1255_3_branches.size());
      for (const auto& v1255_3_branch : v1255_3_branches) {
        const Path v1255_3_head{v1255_3_branch.first};
        const Space& v1255_3_tail = v1255_3_branch.second;
        const Path v1256_2 = concat_path(v1255_2,v1255_3_head);
        const auto v1256_3_branches = branches(c,v1255_3_tail);
        std::vector<Space> v1256_3_outputs;
        v1256_3_outputs.reserve(v1256_3_branches.size());
        for (const auto& v1256_3_branch : v1256_3_branches) {
          const Path v1256_3_head{v1256_3_branch.first};
          const Space& v1256_3_tail = v1256_3_branch.second;
          const Path v1257_2 = concat_path(v1256_2,v1256_3_head);
          const auto v1257_3_branches = branches(c,v1256_3_tail);
          std::vector<Space> v1257_3_outputs;
          v1257_3_outputs.reserve(v1257_3_branches.size());
          for (const auto& v1257_3_branch : v1257_3_branches) {
            const Path v1257_3_head{v1257_3_branch.first};
            const Space& v1257_3_tail = v1257_3_branch.second;
            const auto v1258_2_branches = branches(c,v1257_3_tail);
            std::vector<Space> v1258_2_outputs;
            v1258_2_outputs.reserve(v1258_2_branches.size());
            for (const auto& v1258_2_branch : v1258_2_branches) {
              const Path v1258_2_head{v1258_2_branch.first};
              const Space& v1258_2_tail = v1258_2_branch.second;
              const Path v1259_2 = concat_path(v1257_3_head,v1258_2_head);
              const auto v1259_3_branches = branches(c,v1258_2_tail);
              std::vector<Space> v1259_3_outputs;
              v1259_3_outputs.reserve(v1259_3_branches.size());
              for (const auto& v1259_3_branch : v1259_3_branches) {
                const Path v1259_3_head{v1259_3_branch.first};
                const Space& v1259_3_tail = v1259_3_branch.second;
                const Path v1260_2 = concat_path(v1259_2,v1259_3_head);
                const auto v1260_3_branches = branches(c,v1259_3_tail);
                std::vector<Space> v1260_3_outputs;
                v1260_3_outputs.reserve(v1260_3_branches.size());
                for (const auto& v1260_3_branch : v1260_3_branches) {
                  const Path v1260_3_head{v1260_3_branch.first};
                  const Space& v1260_3_tail = v1260_3_branch.second;
                  const Path v1261_2 = concat_path(v1260_2,v1260_3_head);
                  const Space v1261_3 = routine_157(c, v1261_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1257_2, v1260_3_tail);
                  v1260_3_outputs.push_back(v1261_3);
                }
                const Space v1260_3 = join_outputs(std::move(v1260_3_outputs));
                v1259_3_outputs.push_back(v1260_3);
              }
              const Space v1259_3 = join_outputs(std::move(v1259_3_outputs));
              v1258_2_outputs.push_back(v1259_3);
            }
            const Space v1258_2 = join_outputs(std::move(v1258_2_outputs));
            v1257_3_outputs.push_back(v1258_2);
          }
          const Space v1257_3 = join_outputs(std::move(v1257_3_outputs));
          v1256_3_outputs.push_back(v1257_3);
        }
        const Space v1256_3 = join_outputs(std::move(v1256_3_outputs));
        v1255_3_outputs.push_back(v1256_3);
      }
      const Space v1255_3 = join_outputs(std::move(v1255_3_outputs));
      v1254_2_outputs.push_back(v1255_3);
    }
    const Space v1254_2 = join_outputs(std::move(v1254_2_outputs));
    v1253_14_outputs.push_back(v1254_2);
  }
  const Space v1253_14 = join_outputs(std::move(v1253_14_outputs));
  return v1253_14;
}

static Space routine_142(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Space& s0) {
  const auto v1262_14_branches = branches(c,s0);
  std::vector<Space> v1262_14_outputs;
  v1262_14_outputs.reserve(v1262_14_branches.size());
  for (const auto& v1262_14_branch : v1262_14_branches) {
    const Path v1262_14_head{v1262_14_branch.first};
    const Space& v1262_14_tail = v1262_14_branch.second;
    const auto v1263_2_branches = branches(c,v1262_14_tail);
    std::vector<Space> v1263_2_outputs;
    v1263_2_outputs.reserve(v1263_2_branches.size());
    for (const auto& v1263_2_branch : v1263_2_branches) {
      const Path v1263_2_head{v1263_2_branch.first};
      const Space& v1263_2_tail = v1263_2_branch.second;
      const Path v1264_2 = concat_path(v1262_14_head,v1263_2_head);
      const auto v1264_3_branches = branches(c,v1263_2_tail);
      std::vector<Space> v1264_3_outputs;
      v1264_3_outputs.reserve(v1264_3_branches.size());
      for (const auto& v1264_3_branch : v1264_3_branches) {
        const Path v1264_3_head{v1264_3_branch.first};
        const Space& v1264_3_tail = v1264_3_branch.second;
        const Path v1265_2 = concat_path(v1264_2,v1264_3_head);
        const auto v1265_3_branches = branches(c,v1264_3_tail);
        std::vector<Space> v1265_3_outputs;
        v1265_3_outputs.reserve(v1265_3_branches.size());
        for (const auto& v1265_3_branch : v1265_3_branches) {
          const Path v1265_3_head{v1265_3_branch.first};
          const Space& v1265_3_tail = v1265_3_branch.second;
          const Path v1266_2 = concat_path(v1265_2,v1265_3_head);
          const auto v1266_3_branches = branches(c,v1265_3_tail);
          std::vector<Space> v1266_3_outputs;
          v1266_3_outputs.reserve(v1266_3_branches.size());
          for (const auto& v1266_3_branch : v1266_3_branches) {
            const Path v1266_3_head{v1266_3_branch.first};
            const Space& v1266_3_tail = v1266_3_branch.second;
            const auto v1267_2_branches = branches(c,v1266_3_tail);
            std::vector<Space> v1267_2_outputs;
            v1267_2_outputs.reserve(v1267_2_branches.size());
            for (const auto& v1267_2_branch : v1267_2_branches) {
              const Path v1267_2_head{v1267_2_branch.first};
              const Space& v1267_2_tail = v1267_2_branch.second;
              const Path v1268_2 = concat_path(v1266_3_head,v1267_2_head);
              const auto v1268_3_branches = branches(c,v1267_2_tail);
              std::vector<Space> v1268_3_outputs;
              v1268_3_outputs.reserve(v1268_3_branches.size());
              for (const auto& v1268_3_branch : v1268_3_branches) {
                const Path v1268_3_head{v1268_3_branch.first};
                const Space& v1268_3_tail = v1268_3_branch.second;
                const Path v1269_2 = concat_path(v1268_2,v1268_3_head);
                const auto v1269_3_branches = branches(c,v1268_3_tail);
                std::vector<Space> v1269_3_outputs;
                v1269_3_outputs.reserve(v1269_3_branches.size());
                for (const auto& v1269_3_branch : v1269_3_branches) {
                  const Path v1269_3_head{v1269_3_branch.first};
                  const Space& v1269_3_tail = v1269_3_branch.second;
                  const Path v1270_2 = concat_path(v1269_2,v1269_3_head);
                  const Space v1270_3 = routine_158(c, v1270_2, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12, p0, v1266_2, v1269_3_tail);
                  v1269_3_outputs.push_back(v1270_3);
                }
                const Space v1269_3 = join_outputs(std::move(v1269_3_outputs));
                v1268_3_outputs.push_back(v1269_3);
              }
              const Space v1268_3 = join_outputs(std::move(v1268_3_outputs));
              v1267_2_outputs.push_back(v1268_3);
            }
            const Space v1267_2 = join_outputs(std::move(v1267_2_outputs));
            v1266_3_outputs.push_back(v1267_2);
          }
          const Space v1266_3 = join_outputs(std::move(v1266_3_outputs));
          v1265_3_outputs.push_back(v1266_3);
        }
        const Space v1265_3 = join_outputs(std::move(v1265_3_outputs));
        v1264_3_outputs.push_back(v1265_3);
      }
      const Space v1264_3 = join_outputs(std::move(v1264_3_outputs));
      v1263_2_outputs.push_back(v1264_3);
    }
    const Space v1263_2 = join_outputs(std::move(v1263_2_outputs));
    v1262_14_outputs.push_back(v1263_2);
  }
  const Space v1262_14 = join_outputs(std::move(v1262_14_outputs));
  return v1262_14;
}

static Space routine_143(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1271_18 = concat_path(constant_3,p1);
  const Space v1271_19 = singleton(v1271_18);
  const Space v1271_20 = unite(constant_84,v1271_19);
  const Path v1271_22 = concat_path(constant_5,p2);
  const Space v1271_23 = singleton(v1271_22);
  const Space v1271_24 = unite(v1271_20,v1271_23);
  const Path v1271_26 = concat_path(constant_7,p3);
  const Space v1271_27 = singleton(v1271_26);
  const Space v1271_28 = unite(v1271_24,v1271_27);
  const Path v1271_30 = concat_path(constant_9,p4);
  const Space v1271_31 = singleton(v1271_30);
  const Space v1271_32 = unite(v1271_28,v1271_31);
  const Path v1271_34 = concat_path(constant_11,p5);
  const Space v1271_35 = singleton(v1271_34);
  const Space v1271_36 = unite(v1271_32,v1271_35);
  const Path v1271_38 = concat_path(constant_13,p6);
  const Space v1271_39 = singleton(v1271_38);
  const Space v1271_40 = unite(v1271_36,v1271_39);
  const Path v1271_42 = concat_path(constant_15,p7);
  const Space v1271_43 = singleton(v1271_42);
  const Space v1271_44 = unite(v1271_40,v1271_43);
  const Path v1271_46 = concat_path(constant_17,p8);
  const Space v1271_47 = singleton(v1271_46);
  const Space v1271_48 = unite(v1271_44,v1271_47);
  const Path v1271_50 = concat_path(constant_19,p9);
  const Space v1271_51 = singleton(v1271_50);
  const Space v1271_52 = unite(v1271_48,v1271_51);
  const Path v1271_54 = concat_path(constant_21,p10);
  const Space v1271_55 = singleton(v1271_54);
  const Space v1271_56 = unite(v1271_52,v1271_55);
  const Path v1271_58 = concat_path(constant_23,p11);
  const Space v1271_59 = singleton(v1271_58);
  const Space v1271_60 = unite(v1271_56,v1271_59);
  const Path v1271_62 = concat_path(constant_25,p12);
  const Space v1271_63 = singleton(v1271_62);
  const Space v1271_64 = unite(v1271_60,v1271_63);
  const Path v1271_66 = concat_path(constant_27,p13);
  const Space v1271_67 = singleton(v1271_66);
  const Space v1271_68 = unite(v1271_64,v1271_67);
  const Path v1271_70 = concat_path(constant_29,p14);
  const Space v1271_71 = singleton(v1271_70);
  const Space v1271_72 = unite(v1271_68,v1271_71);
  const Path v1271_74 = concat_path(constant_81,p0);
  const Space v1271_75 = singleton(v1271_74);
  const Space v1271_76 = unite(v1271_72,v1271_75);
  return v1271_76;
}

static Space routine_144(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1272_18 = concat_path(constant_1,p1);
  const Space v1272_19 = singleton(v1272_18);
  const Space v1272_20 = unite(constant_85,v1272_19);
  const Path v1272_22 = concat_path(constant_5,p2);
  const Space v1272_23 = singleton(v1272_22);
  const Space v1272_24 = unite(v1272_20,v1272_23);
  const Path v1272_26 = concat_path(constant_7,p3);
  const Space v1272_27 = singleton(v1272_26);
  const Space v1272_28 = unite(v1272_24,v1272_27);
  const Path v1272_30 = concat_path(constant_9,p4);
  const Space v1272_31 = singleton(v1272_30);
  const Space v1272_32 = unite(v1272_28,v1272_31);
  const Path v1272_34 = concat_path(constant_11,p5);
  const Space v1272_35 = singleton(v1272_34);
  const Space v1272_36 = unite(v1272_32,v1272_35);
  const Path v1272_38 = concat_path(constant_13,p6);
  const Space v1272_39 = singleton(v1272_38);
  const Space v1272_40 = unite(v1272_36,v1272_39);
  const Path v1272_42 = concat_path(constant_15,p7);
  const Space v1272_43 = singleton(v1272_42);
  const Space v1272_44 = unite(v1272_40,v1272_43);
  const Path v1272_46 = concat_path(constant_17,p8);
  const Space v1272_47 = singleton(v1272_46);
  const Space v1272_48 = unite(v1272_44,v1272_47);
  const Path v1272_50 = concat_path(constant_19,p9);
  const Space v1272_51 = singleton(v1272_50);
  const Space v1272_52 = unite(v1272_48,v1272_51);
  const Path v1272_54 = concat_path(constant_21,p10);
  const Space v1272_55 = singleton(v1272_54);
  const Space v1272_56 = unite(v1272_52,v1272_55);
  const Path v1272_58 = concat_path(constant_23,p11);
  const Space v1272_59 = singleton(v1272_58);
  const Space v1272_60 = unite(v1272_56,v1272_59);
  const Path v1272_62 = concat_path(constant_25,p12);
  const Space v1272_63 = singleton(v1272_62);
  const Space v1272_64 = unite(v1272_60,v1272_63);
  const Path v1272_66 = concat_path(constant_27,p13);
  const Space v1272_67 = singleton(v1272_66);
  const Space v1272_68 = unite(v1272_64,v1272_67);
  const Path v1272_70 = concat_path(constant_29,p14);
  const Space v1272_71 = singleton(v1272_70);
  const Space v1272_72 = unite(v1272_68,v1272_71);
  const Path v1272_74 = concat_path(constant_81,p0);
  const Space v1272_75 = singleton(v1272_74);
  const Space v1272_76 = unite(v1272_72,v1272_75);
  return v1272_76;
}

static Space routine_145(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1273_18 = concat_path(constant_1,p1);
  const Space v1273_19 = singleton(v1273_18);
  const Space v1273_20 = unite(constant_86,v1273_19);
  const Path v1273_22 = concat_path(constant_3,p2);
  const Space v1273_23 = singleton(v1273_22);
  const Space v1273_24 = unite(v1273_20,v1273_23);
  const Path v1273_26 = concat_path(constant_7,p3);
  const Space v1273_27 = singleton(v1273_26);
  const Space v1273_28 = unite(v1273_24,v1273_27);
  const Path v1273_30 = concat_path(constant_9,p4);
  const Space v1273_31 = singleton(v1273_30);
  const Space v1273_32 = unite(v1273_28,v1273_31);
  const Path v1273_34 = concat_path(constant_11,p5);
  const Space v1273_35 = singleton(v1273_34);
  const Space v1273_36 = unite(v1273_32,v1273_35);
  const Path v1273_38 = concat_path(constant_13,p6);
  const Space v1273_39 = singleton(v1273_38);
  const Space v1273_40 = unite(v1273_36,v1273_39);
  const Path v1273_42 = concat_path(constant_15,p7);
  const Space v1273_43 = singleton(v1273_42);
  const Space v1273_44 = unite(v1273_40,v1273_43);
  const Path v1273_46 = concat_path(constant_17,p8);
  const Space v1273_47 = singleton(v1273_46);
  const Space v1273_48 = unite(v1273_44,v1273_47);
  const Path v1273_50 = concat_path(constant_19,p9);
  const Space v1273_51 = singleton(v1273_50);
  const Space v1273_52 = unite(v1273_48,v1273_51);
  const Path v1273_54 = concat_path(constant_21,p10);
  const Space v1273_55 = singleton(v1273_54);
  const Space v1273_56 = unite(v1273_52,v1273_55);
  const Path v1273_58 = concat_path(constant_23,p11);
  const Space v1273_59 = singleton(v1273_58);
  const Space v1273_60 = unite(v1273_56,v1273_59);
  const Path v1273_62 = concat_path(constant_25,p12);
  const Space v1273_63 = singleton(v1273_62);
  const Space v1273_64 = unite(v1273_60,v1273_63);
  const Path v1273_66 = concat_path(constant_27,p13);
  const Space v1273_67 = singleton(v1273_66);
  const Space v1273_68 = unite(v1273_64,v1273_67);
  const Path v1273_70 = concat_path(constant_29,p14);
  const Space v1273_71 = singleton(v1273_70);
  const Space v1273_72 = unite(v1273_68,v1273_71);
  const Path v1273_74 = concat_path(constant_81,p0);
  const Space v1273_75 = singleton(v1273_74);
  const Space v1273_76 = unite(v1273_72,v1273_75);
  return v1273_76;
}

static Space routine_146(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1274_18 = concat_path(constant_1,p1);
  const Space v1274_19 = singleton(v1274_18);
  const Space v1274_20 = unite(constant_87,v1274_19);
  const Path v1274_22 = concat_path(constant_3,p2);
  const Space v1274_23 = singleton(v1274_22);
  const Space v1274_24 = unite(v1274_20,v1274_23);
  const Path v1274_26 = concat_path(constant_5,p3);
  const Space v1274_27 = singleton(v1274_26);
  const Space v1274_28 = unite(v1274_24,v1274_27);
  const Path v1274_30 = concat_path(constant_9,p4);
  const Space v1274_31 = singleton(v1274_30);
  const Space v1274_32 = unite(v1274_28,v1274_31);
  const Path v1274_34 = concat_path(constant_11,p5);
  const Space v1274_35 = singleton(v1274_34);
  const Space v1274_36 = unite(v1274_32,v1274_35);
  const Path v1274_38 = concat_path(constant_13,p6);
  const Space v1274_39 = singleton(v1274_38);
  const Space v1274_40 = unite(v1274_36,v1274_39);
  const Path v1274_42 = concat_path(constant_15,p7);
  const Space v1274_43 = singleton(v1274_42);
  const Space v1274_44 = unite(v1274_40,v1274_43);
  const Path v1274_46 = concat_path(constant_17,p8);
  const Space v1274_47 = singleton(v1274_46);
  const Space v1274_48 = unite(v1274_44,v1274_47);
  const Path v1274_50 = concat_path(constant_19,p9);
  const Space v1274_51 = singleton(v1274_50);
  const Space v1274_52 = unite(v1274_48,v1274_51);
  const Path v1274_54 = concat_path(constant_21,p10);
  const Space v1274_55 = singleton(v1274_54);
  const Space v1274_56 = unite(v1274_52,v1274_55);
  const Path v1274_58 = concat_path(constant_23,p11);
  const Space v1274_59 = singleton(v1274_58);
  const Space v1274_60 = unite(v1274_56,v1274_59);
  const Path v1274_62 = concat_path(constant_25,p12);
  const Space v1274_63 = singleton(v1274_62);
  const Space v1274_64 = unite(v1274_60,v1274_63);
  const Path v1274_66 = concat_path(constant_27,p13);
  const Space v1274_67 = singleton(v1274_66);
  const Space v1274_68 = unite(v1274_64,v1274_67);
  const Path v1274_70 = concat_path(constant_29,p14);
  const Space v1274_71 = singleton(v1274_70);
  const Space v1274_72 = unite(v1274_68,v1274_71);
  const Path v1274_74 = concat_path(constant_81,p0);
  const Space v1274_75 = singleton(v1274_74);
  const Space v1274_76 = unite(v1274_72,v1274_75);
  return v1274_76;
}

static Space routine_147(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1275_18 = concat_path(constant_1,p1);
  const Space v1275_19 = singleton(v1275_18);
  const Space v1275_20 = unite(constant_88,v1275_19);
  const Path v1275_22 = concat_path(constant_3,p2);
  const Space v1275_23 = singleton(v1275_22);
  const Space v1275_24 = unite(v1275_20,v1275_23);
  const Path v1275_26 = concat_path(constant_5,p3);
  const Space v1275_27 = singleton(v1275_26);
  const Space v1275_28 = unite(v1275_24,v1275_27);
  const Path v1275_30 = concat_path(constant_7,p4);
  const Space v1275_31 = singleton(v1275_30);
  const Space v1275_32 = unite(v1275_28,v1275_31);
  const Path v1275_34 = concat_path(constant_11,p5);
  const Space v1275_35 = singleton(v1275_34);
  const Space v1275_36 = unite(v1275_32,v1275_35);
  const Path v1275_38 = concat_path(constant_13,p6);
  const Space v1275_39 = singleton(v1275_38);
  const Space v1275_40 = unite(v1275_36,v1275_39);
  const Path v1275_42 = concat_path(constant_15,p7);
  const Space v1275_43 = singleton(v1275_42);
  const Space v1275_44 = unite(v1275_40,v1275_43);
  const Path v1275_46 = concat_path(constant_17,p8);
  const Space v1275_47 = singleton(v1275_46);
  const Space v1275_48 = unite(v1275_44,v1275_47);
  const Path v1275_50 = concat_path(constant_19,p9);
  const Space v1275_51 = singleton(v1275_50);
  const Space v1275_52 = unite(v1275_48,v1275_51);
  const Path v1275_54 = concat_path(constant_21,p10);
  const Space v1275_55 = singleton(v1275_54);
  const Space v1275_56 = unite(v1275_52,v1275_55);
  const Path v1275_58 = concat_path(constant_23,p11);
  const Space v1275_59 = singleton(v1275_58);
  const Space v1275_60 = unite(v1275_56,v1275_59);
  const Path v1275_62 = concat_path(constant_25,p12);
  const Space v1275_63 = singleton(v1275_62);
  const Space v1275_64 = unite(v1275_60,v1275_63);
  const Path v1275_66 = concat_path(constant_27,p13);
  const Space v1275_67 = singleton(v1275_66);
  const Space v1275_68 = unite(v1275_64,v1275_67);
  const Path v1275_70 = concat_path(constant_29,p14);
  const Space v1275_71 = singleton(v1275_70);
  const Space v1275_72 = unite(v1275_68,v1275_71);
  const Path v1275_74 = concat_path(constant_81,p0);
  const Space v1275_75 = singleton(v1275_74);
  const Space v1275_76 = unite(v1275_72,v1275_75);
  return v1275_76;
}

static Space routine_148(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1276_18 = concat_path(constant_1,p1);
  const Space v1276_19 = singleton(v1276_18);
  const Space v1276_20 = unite(constant_89,v1276_19);
  const Path v1276_22 = concat_path(constant_3,p2);
  const Space v1276_23 = singleton(v1276_22);
  const Space v1276_24 = unite(v1276_20,v1276_23);
  const Path v1276_26 = concat_path(constant_5,p3);
  const Space v1276_27 = singleton(v1276_26);
  const Space v1276_28 = unite(v1276_24,v1276_27);
  const Path v1276_30 = concat_path(constant_7,p4);
  const Space v1276_31 = singleton(v1276_30);
  const Space v1276_32 = unite(v1276_28,v1276_31);
  const Path v1276_34 = concat_path(constant_9,p5);
  const Space v1276_35 = singleton(v1276_34);
  const Space v1276_36 = unite(v1276_32,v1276_35);
  const Path v1276_38 = concat_path(constant_13,p6);
  const Space v1276_39 = singleton(v1276_38);
  const Space v1276_40 = unite(v1276_36,v1276_39);
  const Path v1276_42 = concat_path(constant_15,p7);
  const Space v1276_43 = singleton(v1276_42);
  const Space v1276_44 = unite(v1276_40,v1276_43);
  const Path v1276_46 = concat_path(constant_17,p8);
  const Space v1276_47 = singleton(v1276_46);
  const Space v1276_48 = unite(v1276_44,v1276_47);
  const Path v1276_50 = concat_path(constant_19,p9);
  const Space v1276_51 = singleton(v1276_50);
  const Space v1276_52 = unite(v1276_48,v1276_51);
  const Path v1276_54 = concat_path(constant_21,p10);
  const Space v1276_55 = singleton(v1276_54);
  const Space v1276_56 = unite(v1276_52,v1276_55);
  const Path v1276_58 = concat_path(constant_23,p11);
  const Space v1276_59 = singleton(v1276_58);
  const Space v1276_60 = unite(v1276_56,v1276_59);
  const Path v1276_62 = concat_path(constant_25,p12);
  const Space v1276_63 = singleton(v1276_62);
  const Space v1276_64 = unite(v1276_60,v1276_63);
  const Path v1276_66 = concat_path(constant_27,p13);
  const Space v1276_67 = singleton(v1276_66);
  const Space v1276_68 = unite(v1276_64,v1276_67);
  const Path v1276_70 = concat_path(constant_29,p14);
  const Space v1276_71 = singleton(v1276_70);
  const Space v1276_72 = unite(v1276_68,v1276_71);
  const Path v1276_74 = concat_path(constant_81,p0);
  const Space v1276_75 = singleton(v1276_74);
  const Space v1276_76 = unite(v1276_72,v1276_75);
  return v1276_76;
}

static Space routine_149(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1277_18 = concat_path(constant_1,p1);
  const Space v1277_19 = singleton(v1277_18);
  const Space v1277_20 = unite(constant_90,v1277_19);
  const Path v1277_22 = concat_path(constant_3,p2);
  const Space v1277_23 = singleton(v1277_22);
  const Space v1277_24 = unite(v1277_20,v1277_23);
  const Path v1277_26 = concat_path(constant_5,p3);
  const Space v1277_27 = singleton(v1277_26);
  const Space v1277_28 = unite(v1277_24,v1277_27);
  const Path v1277_30 = concat_path(constant_7,p4);
  const Space v1277_31 = singleton(v1277_30);
  const Space v1277_32 = unite(v1277_28,v1277_31);
  const Path v1277_34 = concat_path(constant_9,p5);
  const Space v1277_35 = singleton(v1277_34);
  const Space v1277_36 = unite(v1277_32,v1277_35);
  const Path v1277_38 = concat_path(constant_11,p6);
  const Space v1277_39 = singleton(v1277_38);
  const Space v1277_40 = unite(v1277_36,v1277_39);
  const Path v1277_42 = concat_path(constant_15,p7);
  const Space v1277_43 = singleton(v1277_42);
  const Space v1277_44 = unite(v1277_40,v1277_43);
  const Path v1277_46 = concat_path(constant_17,p8);
  const Space v1277_47 = singleton(v1277_46);
  const Space v1277_48 = unite(v1277_44,v1277_47);
  const Path v1277_50 = concat_path(constant_19,p9);
  const Space v1277_51 = singleton(v1277_50);
  const Space v1277_52 = unite(v1277_48,v1277_51);
  const Path v1277_54 = concat_path(constant_21,p10);
  const Space v1277_55 = singleton(v1277_54);
  const Space v1277_56 = unite(v1277_52,v1277_55);
  const Path v1277_58 = concat_path(constant_23,p11);
  const Space v1277_59 = singleton(v1277_58);
  const Space v1277_60 = unite(v1277_56,v1277_59);
  const Path v1277_62 = concat_path(constant_25,p12);
  const Space v1277_63 = singleton(v1277_62);
  const Space v1277_64 = unite(v1277_60,v1277_63);
  const Path v1277_66 = concat_path(constant_27,p13);
  const Space v1277_67 = singleton(v1277_66);
  const Space v1277_68 = unite(v1277_64,v1277_67);
  const Path v1277_70 = concat_path(constant_29,p14);
  const Space v1277_71 = singleton(v1277_70);
  const Space v1277_72 = unite(v1277_68,v1277_71);
  const Path v1277_74 = concat_path(constant_81,p0);
  const Space v1277_75 = singleton(v1277_74);
  const Space v1277_76 = unite(v1277_72,v1277_75);
  return v1277_76;
}

static Space routine_150(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1278_18 = concat_path(constant_1,p1);
  const Space v1278_19 = singleton(v1278_18);
  const Space v1278_20 = unite(constant_91,v1278_19);
  const Path v1278_22 = concat_path(constant_3,p2);
  const Space v1278_23 = singleton(v1278_22);
  const Space v1278_24 = unite(v1278_20,v1278_23);
  const Path v1278_26 = concat_path(constant_5,p3);
  const Space v1278_27 = singleton(v1278_26);
  const Space v1278_28 = unite(v1278_24,v1278_27);
  const Path v1278_30 = concat_path(constant_7,p4);
  const Space v1278_31 = singleton(v1278_30);
  const Space v1278_32 = unite(v1278_28,v1278_31);
  const Path v1278_34 = concat_path(constant_9,p5);
  const Space v1278_35 = singleton(v1278_34);
  const Space v1278_36 = unite(v1278_32,v1278_35);
  const Path v1278_38 = concat_path(constant_11,p6);
  const Space v1278_39 = singleton(v1278_38);
  const Space v1278_40 = unite(v1278_36,v1278_39);
  const Path v1278_42 = concat_path(constant_13,p7);
  const Space v1278_43 = singleton(v1278_42);
  const Space v1278_44 = unite(v1278_40,v1278_43);
  const Path v1278_46 = concat_path(constant_17,p8);
  const Space v1278_47 = singleton(v1278_46);
  const Space v1278_48 = unite(v1278_44,v1278_47);
  const Path v1278_50 = concat_path(constant_19,p9);
  const Space v1278_51 = singleton(v1278_50);
  const Space v1278_52 = unite(v1278_48,v1278_51);
  const Path v1278_54 = concat_path(constant_21,p10);
  const Space v1278_55 = singleton(v1278_54);
  const Space v1278_56 = unite(v1278_52,v1278_55);
  const Path v1278_58 = concat_path(constant_23,p11);
  const Space v1278_59 = singleton(v1278_58);
  const Space v1278_60 = unite(v1278_56,v1278_59);
  const Path v1278_62 = concat_path(constant_25,p12);
  const Space v1278_63 = singleton(v1278_62);
  const Space v1278_64 = unite(v1278_60,v1278_63);
  const Path v1278_66 = concat_path(constant_27,p13);
  const Space v1278_67 = singleton(v1278_66);
  const Space v1278_68 = unite(v1278_64,v1278_67);
  const Path v1278_70 = concat_path(constant_29,p14);
  const Space v1278_71 = singleton(v1278_70);
  const Space v1278_72 = unite(v1278_68,v1278_71);
  const Path v1278_74 = concat_path(constant_81,p0);
  const Space v1278_75 = singleton(v1278_74);
  const Space v1278_76 = unite(v1278_72,v1278_75);
  return v1278_76;
}

static Space routine_151(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1279_18 = concat_path(constant_1,p1);
  const Space v1279_19 = singleton(v1279_18);
  const Space v1279_20 = unite(constant_92,v1279_19);
  const Path v1279_22 = concat_path(constant_3,p2);
  const Space v1279_23 = singleton(v1279_22);
  const Space v1279_24 = unite(v1279_20,v1279_23);
  const Path v1279_26 = concat_path(constant_5,p3);
  const Space v1279_27 = singleton(v1279_26);
  const Space v1279_28 = unite(v1279_24,v1279_27);
  const Path v1279_30 = concat_path(constant_7,p4);
  const Space v1279_31 = singleton(v1279_30);
  const Space v1279_32 = unite(v1279_28,v1279_31);
  const Path v1279_34 = concat_path(constant_9,p5);
  const Space v1279_35 = singleton(v1279_34);
  const Space v1279_36 = unite(v1279_32,v1279_35);
  const Path v1279_38 = concat_path(constant_11,p6);
  const Space v1279_39 = singleton(v1279_38);
  const Space v1279_40 = unite(v1279_36,v1279_39);
  const Path v1279_42 = concat_path(constant_13,p7);
  const Space v1279_43 = singleton(v1279_42);
  const Space v1279_44 = unite(v1279_40,v1279_43);
  const Path v1279_46 = concat_path(constant_15,p8);
  const Space v1279_47 = singleton(v1279_46);
  const Space v1279_48 = unite(v1279_44,v1279_47);
  const Path v1279_50 = concat_path(constant_19,p9);
  const Space v1279_51 = singleton(v1279_50);
  const Space v1279_52 = unite(v1279_48,v1279_51);
  const Path v1279_54 = concat_path(constant_21,p10);
  const Space v1279_55 = singleton(v1279_54);
  const Space v1279_56 = unite(v1279_52,v1279_55);
  const Path v1279_58 = concat_path(constant_23,p11);
  const Space v1279_59 = singleton(v1279_58);
  const Space v1279_60 = unite(v1279_56,v1279_59);
  const Path v1279_62 = concat_path(constant_25,p12);
  const Space v1279_63 = singleton(v1279_62);
  const Space v1279_64 = unite(v1279_60,v1279_63);
  const Path v1279_66 = concat_path(constant_27,p13);
  const Space v1279_67 = singleton(v1279_66);
  const Space v1279_68 = unite(v1279_64,v1279_67);
  const Path v1279_70 = concat_path(constant_29,p14);
  const Space v1279_71 = singleton(v1279_70);
  const Space v1279_72 = unite(v1279_68,v1279_71);
  const Path v1279_74 = concat_path(constant_81,p0);
  const Space v1279_75 = singleton(v1279_74);
  const Space v1279_76 = unite(v1279_72,v1279_75);
  return v1279_76;
}

static Space routine_152(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1280_18 = concat_path(constant_1,p1);
  const Space v1280_19 = singleton(v1280_18);
  const Space v1280_20 = unite(constant_93,v1280_19);
  const Path v1280_22 = concat_path(constant_3,p2);
  const Space v1280_23 = singleton(v1280_22);
  const Space v1280_24 = unite(v1280_20,v1280_23);
  const Path v1280_26 = concat_path(constant_5,p3);
  const Space v1280_27 = singleton(v1280_26);
  const Space v1280_28 = unite(v1280_24,v1280_27);
  const Path v1280_30 = concat_path(constant_7,p4);
  const Space v1280_31 = singleton(v1280_30);
  const Space v1280_32 = unite(v1280_28,v1280_31);
  const Path v1280_34 = concat_path(constant_9,p5);
  const Space v1280_35 = singleton(v1280_34);
  const Space v1280_36 = unite(v1280_32,v1280_35);
  const Path v1280_38 = concat_path(constant_11,p6);
  const Space v1280_39 = singleton(v1280_38);
  const Space v1280_40 = unite(v1280_36,v1280_39);
  const Path v1280_42 = concat_path(constant_13,p7);
  const Space v1280_43 = singleton(v1280_42);
  const Space v1280_44 = unite(v1280_40,v1280_43);
  const Path v1280_46 = concat_path(constant_15,p8);
  const Space v1280_47 = singleton(v1280_46);
  const Space v1280_48 = unite(v1280_44,v1280_47);
  const Path v1280_50 = concat_path(constant_17,p9);
  const Space v1280_51 = singleton(v1280_50);
  const Space v1280_52 = unite(v1280_48,v1280_51);
  const Path v1280_54 = concat_path(constant_21,p10);
  const Space v1280_55 = singleton(v1280_54);
  const Space v1280_56 = unite(v1280_52,v1280_55);
  const Path v1280_58 = concat_path(constant_23,p11);
  const Space v1280_59 = singleton(v1280_58);
  const Space v1280_60 = unite(v1280_56,v1280_59);
  const Path v1280_62 = concat_path(constant_25,p12);
  const Space v1280_63 = singleton(v1280_62);
  const Space v1280_64 = unite(v1280_60,v1280_63);
  const Path v1280_66 = concat_path(constant_27,p13);
  const Space v1280_67 = singleton(v1280_66);
  const Space v1280_68 = unite(v1280_64,v1280_67);
  const Path v1280_70 = concat_path(constant_29,p14);
  const Space v1280_71 = singleton(v1280_70);
  const Space v1280_72 = unite(v1280_68,v1280_71);
  const Path v1280_74 = concat_path(constant_81,p0);
  const Space v1280_75 = singleton(v1280_74);
  const Space v1280_76 = unite(v1280_72,v1280_75);
  return v1280_76;
}

static Space routine_153(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1281_18 = concat_path(constant_1,p1);
  const Space v1281_19 = singleton(v1281_18);
  const Space v1281_20 = unite(constant_94,v1281_19);
  const Path v1281_22 = concat_path(constant_3,p2);
  const Space v1281_23 = singleton(v1281_22);
  const Space v1281_24 = unite(v1281_20,v1281_23);
  const Path v1281_26 = concat_path(constant_5,p3);
  const Space v1281_27 = singleton(v1281_26);
  const Space v1281_28 = unite(v1281_24,v1281_27);
  const Path v1281_30 = concat_path(constant_7,p4);
  const Space v1281_31 = singleton(v1281_30);
  const Space v1281_32 = unite(v1281_28,v1281_31);
  const Path v1281_34 = concat_path(constant_9,p5);
  const Space v1281_35 = singleton(v1281_34);
  const Space v1281_36 = unite(v1281_32,v1281_35);
  const Path v1281_38 = concat_path(constant_11,p6);
  const Space v1281_39 = singleton(v1281_38);
  const Space v1281_40 = unite(v1281_36,v1281_39);
  const Path v1281_42 = concat_path(constant_13,p7);
  const Space v1281_43 = singleton(v1281_42);
  const Space v1281_44 = unite(v1281_40,v1281_43);
  const Path v1281_46 = concat_path(constant_15,p8);
  const Space v1281_47 = singleton(v1281_46);
  const Space v1281_48 = unite(v1281_44,v1281_47);
  const Path v1281_50 = concat_path(constant_17,p9);
  const Space v1281_51 = singleton(v1281_50);
  const Space v1281_52 = unite(v1281_48,v1281_51);
  const Path v1281_54 = concat_path(constant_19,p10);
  const Space v1281_55 = singleton(v1281_54);
  const Space v1281_56 = unite(v1281_52,v1281_55);
  const Path v1281_58 = concat_path(constant_23,p11);
  const Space v1281_59 = singleton(v1281_58);
  const Space v1281_60 = unite(v1281_56,v1281_59);
  const Path v1281_62 = concat_path(constant_25,p12);
  const Space v1281_63 = singleton(v1281_62);
  const Space v1281_64 = unite(v1281_60,v1281_63);
  const Path v1281_66 = concat_path(constant_27,p13);
  const Space v1281_67 = singleton(v1281_66);
  const Space v1281_68 = unite(v1281_64,v1281_67);
  const Path v1281_70 = concat_path(constant_29,p14);
  const Space v1281_71 = singleton(v1281_70);
  const Space v1281_72 = unite(v1281_68,v1281_71);
  const Path v1281_74 = concat_path(constant_81,p0);
  const Space v1281_75 = singleton(v1281_74);
  const Space v1281_76 = unite(v1281_72,v1281_75);
  return v1281_76;
}

static Space routine_154(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1282_18 = concat_path(constant_1,p1);
  const Space v1282_19 = singleton(v1282_18);
  const Space v1282_20 = unite(constant_95,v1282_19);
  const Path v1282_22 = concat_path(constant_3,p2);
  const Space v1282_23 = singleton(v1282_22);
  const Space v1282_24 = unite(v1282_20,v1282_23);
  const Path v1282_26 = concat_path(constant_5,p3);
  const Space v1282_27 = singleton(v1282_26);
  const Space v1282_28 = unite(v1282_24,v1282_27);
  const Path v1282_30 = concat_path(constant_7,p4);
  const Space v1282_31 = singleton(v1282_30);
  const Space v1282_32 = unite(v1282_28,v1282_31);
  const Path v1282_34 = concat_path(constant_9,p5);
  const Space v1282_35 = singleton(v1282_34);
  const Space v1282_36 = unite(v1282_32,v1282_35);
  const Path v1282_38 = concat_path(constant_11,p6);
  const Space v1282_39 = singleton(v1282_38);
  const Space v1282_40 = unite(v1282_36,v1282_39);
  const Path v1282_42 = concat_path(constant_13,p7);
  const Space v1282_43 = singleton(v1282_42);
  const Space v1282_44 = unite(v1282_40,v1282_43);
  const Path v1282_46 = concat_path(constant_15,p8);
  const Space v1282_47 = singleton(v1282_46);
  const Space v1282_48 = unite(v1282_44,v1282_47);
  const Path v1282_50 = concat_path(constant_17,p9);
  const Space v1282_51 = singleton(v1282_50);
  const Space v1282_52 = unite(v1282_48,v1282_51);
  const Path v1282_54 = concat_path(constant_19,p10);
  const Space v1282_55 = singleton(v1282_54);
  const Space v1282_56 = unite(v1282_52,v1282_55);
  const Path v1282_58 = concat_path(constant_21,p11);
  const Space v1282_59 = singleton(v1282_58);
  const Space v1282_60 = unite(v1282_56,v1282_59);
  const Path v1282_62 = concat_path(constant_25,p12);
  const Space v1282_63 = singleton(v1282_62);
  const Space v1282_64 = unite(v1282_60,v1282_63);
  const Path v1282_66 = concat_path(constant_27,p13);
  const Space v1282_67 = singleton(v1282_66);
  const Space v1282_68 = unite(v1282_64,v1282_67);
  const Path v1282_70 = concat_path(constant_29,p14);
  const Space v1282_71 = singleton(v1282_70);
  const Space v1282_72 = unite(v1282_68,v1282_71);
  const Path v1282_74 = concat_path(constant_81,p0);
  const Space v1282_75 = singleton(v1282_74);
  const Space v1282_76 = unite(v1282_72,v1282_75);
  return v1282_76;
}

static Space routine_155(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1283_18 = concat_path(constant_1,p1);
  const Space v1283_19 = singleton(v1283_18);
  const Space v1283_20 = unite(constant_96,v1283_19);
  const Path v1283_22 = concat_path(constant_3,p2);
  const Space v1283_23 = singleton(v1283_22);
  const Space v1283_24 = unite(v1283_20,v1283_23);
  const Path v1283_26 = concat_path(constant_5,p3);
  const Space v1283_27 = singleton(v1283_26);
  const Space v1283_28 = unite(v1283_24,v1283_27);
  const Path v1283_30 = concat_path(constant_7,p4);
  const Space v1283_31 = singleton(v1283_30);
  const Space v1283_32 = unite(v1283_28,v1283_31);
  const Path v1283_34 = concat_path(constant_9,p5);
  const Space v1283_35 = singleton(v1283_34);
  const Space v1283_36 = unite(v1283_32,v1283_35);
  const Path v1283_38 = concat_path(constant_11,p6);
  const Space v1283_39 = singleton(v1283_38);
  const Space v1283_40 = unite(v1283_36,v1283_39);
  const Path v1283_42 = concat_path(constant_13,p7);
  const Space v1283_43 = singleton(v1283_42);
  const Space v1283_44 = unite(v1283_40,v1283_43);
  const Path v1283_46 = concat_path(constant_15,p8);
  const Space v1283_47 = singleton(v1283_46);
  const Space v1283_48 = unite(v1283_44,v1283_47);
  const Path v1283_50 = concat_path(constant_17,p9);
  const Space v1283_51 = singleton(v1283_50);
  const Space v1283_52 = unite(v1283_48,v1283_51);
  const Path v1283_54 = concat_path(constant_19,p10);
  const Space v1283_55 = singleton(v1283_54);
  const Space v1283_56 = unite(v1283_52,v1283_55);
  const Path v1283_58 = concat_path(constant_21,p11);
  const Space v1283_59 = singleton(v1283_58);
  const Space v1283_60 = unite(v1283_56,v1283_59);
  const Path v1283_62 = concat_path(constant_23,p12);
  const Space v1283_63 = singleton(v1283_62);
  const Space v1283_64 = unite(v1283_60,v1283_63);
  const Path v1283_66 = concat_path(constant_27,p13);
  const Space v1283_67 = singleton(v1283_66);
  const Space v1283_68 = unite(v1283_64,v1283_67);
  const Path v1283_70 = concat_path(constant_29,p14);
  const Space v1283_71 = singleton(v1283_70);
  const Space v1283_72 = unite(v1283_68,v1283_71);
  const Path v1283_74 = concat_path(constant_81,p0);
  const Space v1283_75 = singleton(v1283_74);
  const Space v1283_76 = unite(v1283_72,v1283_75);
  return v1283_76;
}

static Space routine_156(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1284_18 = concat_path(constant_1,p1);
  const Space v1284_19 = singleton(v1284_18);
  const Space v1284_20 = unite(constant_97,v1284_19);
  const Path v1284_22 = concat_path(constant_3,p2);
  const Space v1284_23 = singleton(v1284_22);
  const Space v1284_24 = unite(v1284_20,v1284_23);
  const Path v1284_26 = concat_path(constant_5,p3);
  const Space v1284_27 = singleton(v1284_26);
  const Space v1284_28 = unite(v1284_24,v1284_27);
  const Path v1284_30 = concat_path(constant_7,p4);
  const Space v1284_31 = singleton(v1284_30);
  const Space v1284_32 = unite(v1284_28,v1284_31);
  const Path v1284_34 = concat_path(constant_9,p5);
  const Space v1284_35 = singleton(v1284_34);
  const Space v1284_36 = unite(v1284_32,v1284_35);
  const Path v1284_38 = concat_path(constant_11,p6);
  const Space v1284_39 = singleton(v1284_38);
  const Space v1284_40 = unite(v1284_36,v1284_39);
  const Path v1284_42 = concat_path(constant_13,p7);
  const Space v1284_43 = singleton(v1284_42);
  const Space v1284_44 = unite(v1284_40,v1284_43);
  const Path v1284_46 = concat_path(constant_15,p8);
  const Space v1284_47 = singleton(v1284_46);
  const Space v1284_48 = unite(v1284_44,v1284_47);
  const Path v1284_50 = concat_path(constant_17,p9);
  const Space v1284_51 = singleton(v1284_50);
  const Space v1284_52 = unite(v1284_48,v1284_51);
  const Path v1284_54 = concat_path(constant_19,p10);
  const Space v1284_55 = singleton(v1284_54);
  const Space v1284_56 = unite(v1284_52,v1284_55);
  const Path v1284_58 = concat_path(constant_21,p11);
  const Space v1284_59 = singleton(v1284_58);
  const Space v1284_60 = unite(v1284_56,v1284_59);
  const Path v1284_62 = concat_path(constant_23,p12);
  const Space v1284_63 = singleton(v1284_62);
  const Space v1284_64 = unite(v1284_60,v1284_63);
  const Path v1284_66 = concat_path(constant_25,p13);
  const Space v1284_67 = singleton(v1284_66);
  const Space v1284_68 = unite(v1284_64,v1284_67);
  const Path v1284_70 = concat_path(constant_29,p14);
  const Space v1284_71 = singleton(v1284_70);
  const Space v1284_72 = unite(v1284_68,v1284_71);
  const Path v1284_74 = concat_path(constant_81,p0);
  const Space v1284_75 = singleton(v1284_74);
  const Space v1284_76 = unite(v1284_72,v1284_75);
  return v1284_76;
}

static Space routine_157(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1285_18 = concat_path(constant_1,p1);
  const Space v1285_19 = singleton(v1285_18);
  const Space v1285_20 = unite(constant_98,v1285_19);
  const Path v1285_22 = concat_path(constant_3,p2);
  const Space v1285_23 = singleton(v1285_22);
  const Space v1285_24 = unite(v1285_20,v1285_23);
  const Path v1285_26 = concat_path(constant_5,p3);
  const Space v1285_27 = singleton(v1285_26);
  const Space v1285_28 = unite(v1285_24,v1285_27);
  const Path v1285_30 = concat_path(constant_7,p4);
  const Space v1285_31 = singleton(v1285_30);
  const Space v1285_32 = unite(v1285_28,v1285_31);
  const Path v1285_34 = concat_path(constant_9,p5);
  const Space v1285_35 = singleton(v1285_34);
  const Space v1285_36 = unite(v1285_32,v1285_35);
  const Path v1285_38 = concat_path(constant_11,p6);
  const Space v1285_39 = singleton(v1285_38);
  const Space v1285_40 = unite(v1285_36,v1285_39);
  const Path v1285_42 = concat_path(constant_13,p7);
  const Space v1285_43 = singleton(v1285_42);
  const Space v1285_44 = unite(v1285_40,v1285_43);
  const Path v1285_46 = concat_path(constant_15,p8);
  const Space v1285_47 = singleton(v1285_46);
  const Space v1285_48 = unite(v1285_44,v1285_47);
  const Path v1285_50 = concat_path(constant_17,p9);
  const Space v1285_51 = singleton(v1285_50);
  const Space v1285_52 = unite(v1285_48,v1285_51);
  const Path v1285_54 = concat_path(constant_19,p10);
  const Space v1285_55 = singleton(v1285_54);
  const Space v1285_56 = unite(v1285_52,v1285_55);
  const Path v1285_58 = concat_path(constant_21,p11);
  const Space v1285_59 = singleton(v1285_58);
  const Space v1285_60 = unite(v1285_56,v1285_59);
  const Path v1285_62 = concat_path(constant_23,p12);
  const Space v1285_63 = singleton(v1285_62);
  const Space v1285_64 = unite(v1285_60,v1285_63);
  const Path v1285_66 = concat_path(constant_25,p13);
  const Space v1285_67 = singleton(v1285_66);
  const Space v1285_68 = unite(v1285_64,v1285_67);
  const Path v1285_70 = concat_path(constant_27,p14);
  const Space v1285_71 = singleton(v1285_70);
  const Space v1285_72 = unite(v1285_68,v1285_71);
  const Path v1285_74 = concat_path(constant_81,p0);
  const Space v1285_75 = singleton(v1285_74);
  const Space v1285_76 = unite(v1285_72,v1285_75);
  return v1285_76;
}

static Space routine_158(Context& c, const Path& p0, const Path& p1, const Path& p2, const Path& p3, const Path& p4, const Path& p5, const Path& p6, const Path& p7, const Path& p8, const Path& p9, const Path& p10, const Path& p11, const Path& p12, const Path& p13, const Path& p14, const Space& s0) {
  const Path v1286_18 = concat_path(constant_1,p1);
  const Space v1286_19 = singleton(v1286_18);
  const Space v1286_20 = unite(constant_99,v1286_19);
  const Path v1286_22 = concat_path(constant_3,p2);
  const Space v1286_23 = singleton(v1286_22);
  const Space v1286_24 = unite(v1286_20,v1286_23);
  const Path v1286_26 = concat_path(constant_5,p3);
  const Space v1286_27 = singleton(v1286_26);
  const Space v1286_28 = unite(v1286_24,v1286_27);
  const Path v1286_30 = concat_path(constant_7,p4);
  const Space v1286_31 = singleton(v1286_30);
  const Space v1286_32 = unite(v1286_28,v1286_31);
  const Path v1286_34 = concat_path(constant_9,p5);
  const Space v1286_35 = singleton(v1286_34);
  const Space v1286_36 = unite(v1286_32,v1286_35);
  const Path v1286_38 = concat_path(constant_11,p6);
  const Space v1286_39 = singleton(v1286_38);
  const Space v1286_40 = unite(v1286_36,v1286_39);
  const Path v1286_42 = concat_path(constant_13,p7);
  const Space v1286_43 = singleton(v1286_42);
  const Space v1286_44 = unite(v1286_40,v1286_43);
  const Path v1286_46 = concat_path(constant_15,p8);
  const Space v1286_47 = singleton(v1286_46);
  const Space v1286_48 = unite(v1286_44,v1286_47);
  const Path v1286_50 = concat_path(constant_17,p9);
  const Space v1286_51 = singleton(v1286_50);
  const Space v1286_52 = unite(v1286_48,v1286_51);
  const Path v1286_54 = concat_path(constant_19,p10);
  const Space v1286_55 = singleton(v1286_54);
  const Space v1286_56 = unite(v1286_52,v1286_55);
  const Path v1286_58 = concat_path(constant_21,p11);
  const Space v1286_59 = singleton(v1286_58);
  const Space v1286_60 = unite(v1286_56,v1286_59);
  const Path v1286_62 = concat_path(constant_23,p12);
  const Space v1286_63 = singleton(v1286_62);
  const Space v1286_64 = unite(v1286_60,v1286_63);
  const Path v1286_66 = concat_path(constant_25,p13);
  const Space v1286_67 = singleton(v1286_66);
  const Space v1286_68 = unite(v1286_64,v1286_67);
  const Path v1286_70 = concat_path(constant_27,p14);
  const Space v1286_71 = singleton(v1286_70);
  const Space v1286_72 = unite(v1286_68,v1286_71);
  const Path v1286_74 = concat_path(constant_29,p0);
  const Space v1286_75 = singleton(v1286_74);
  const Space v1286_76 = unite(v1286_72,v1286_75);
  return v1286_76;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
