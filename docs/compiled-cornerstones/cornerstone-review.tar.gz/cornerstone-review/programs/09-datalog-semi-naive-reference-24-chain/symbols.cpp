#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Path n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Space n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Path n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Path n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Path n13(Context&, const Env&);
static ZIPPY_NOINLINE Space n14(Context&, const Env&);
static ZIPPY_NOINLINE Path n15(Context&, const Env&);
static ZIPPY_NOINLINE Space n16(Context&, const Env&);
static ZIPPY_NOINLINE Path n17(Context&, const Env&);
static ZIPPY_NOINLINE Space n18(Context&, const Env&);
static ZIPPY_NOINLINE Space n19(Context&, const Env&);
static ZIPPY_NOINLINE Path n20(Context&, const Env&);
static ZIPPY_NOINLINE Space n21(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n23(Context&, const Env&);
static ZIPPY_NOINLINE Space n24(Context&, const Env&);
static ZIPPY_NOINLINE Space n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Path n29(Context&, const Env&);
static ZIPPY_NOINLINE Space n30(Context&, const Env&);
static ZIPPY_NOINLINE Space n31(Context&, const Env&);
static ZIPPY_NOINLINE Path n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Space n34(Context&, const Env&);
static ZIPPY_NOINLINE Path n35(Context&, const Env&);
static ZIPPY_NOINLINE Space n36(Context&, const Env&);
static ZIPPY_NOINLINE Space n37(Context&, const Env&);
static ZIPPY_NOINLINE Path n38(Context&, const Env&);
static ZIPPY_NOINLINE Space n39(Context&, const Env&);
static ZIPPY_NOINLINE Space n40(Context&, const Env&);
static ZIPPY_NOINLINE Space n41(Context&, const Env&);
static ZIPPY_NOINLINE Space n42(Context&, const Env&);
static ZIPPY_NOINLINE Space n43(Context&, const Env&);
static ZIPPY_NOINLINE Space n44(Context&, const Env&);
static ZIPPY_NOINLINE Path n45(Context&, const Env&);
static ZIPPY_NOINLINE Space n46(Context&, const Env&);
static ZIPPY_NOINLINE Path n47(Context&, const Env&);
static ZIPPY_NOINLINE Space n48(Context&, const Env&);
static ZIPPY_NOINLINE Space n49(Context&, const Env&);
static ZIPPY_NOINLINE Space n50(Context&, const Env&);
static ZIPPY_NOINLINE Space n51(Context&, const Env&);
static ZIPPY_NOINLINE Path n52(Context&, const Env&);
static ZIPPY_NOINLINE Space n53(Context&, const Env&);
static ZIPPY_NOINLINE Path n54(Context&, const Env&);
static ZIPPY_NOINLINE Space n55(Context&, const Env&);
static ZIPPY_NOINLINE Space n56(Context&, const Env&);
static ZIPPY_NOINLINE Space n57(Context&, const Env&);
static ZIPPY_NOINLINE Path n58(Context&, const Env&);
static ZIPPY_NOINLINE Space n59(Context&, const Env&);
static ZIPPY_NOINLINE Path n60(Context&, const Env&);
static ZIPPY_NOINLINE Space n61(Context&, const Env&);
static ZIPPY_NOINLINE Space n62(Context&, const Env&);
static ZIPPY_NOINLINE Space n63(Context&, const Env&);
static ZIPPY_NOINLINE Space n64(Context&, const Env&);
static ZIPPY_NOINLINE Space n65(Context&, const Env&);
static ZIPPY_NOINLINE Path n66(Context&, const Env&);
static ZIPPY_NOINLINE Space n67(Context&, const Env&);
static ZIPPY_NOINLINE Path n68(Context&, const Env&);
static ZIPPY_NOINLINE Space n69(Context&, const Env&);
static ZIPPY_NOINLINE Path n70(Context&, const Env&);
static ZIPPY_NOINLINE Space n71(Context&, const Env&);
static ZIPPY_NOINLINE Space n72(Context&, const Env&);
static ZIPPY_NOINLINE Path n73(Context&, const Env&);
static ZIPPY_NOINLINE Space n74(Context&, const Env&);
static ZIPPY_NOINLINE Path n75(Context&, const Env&);
static ZIPPY_NOINLINE Space n76(Context&, const Env&);
static ZIPPY_NOINLINE Space n77(Context&, const Env&);
static ZIPPY_NOINLINE Space n78(Context&, const Env&);
static ZIPPY_NOINLINE Path n79(Context&, const Env&);
static ZIPPY_NOINLINE Space n80(Context&, const Env&);
static ZIPPY_NOINLINE Path n81(Context&, const Env&);
static ZIPPY_NOINLINE Space n82(Context&, const Env&);
static ZIPPY_NOINLINE Space n83(Context&, const Env&);
static ZIPPY_NOINLINE Space n84(Context&, const Env&);
static ZIPPY_NOINLINE Space n85(Context&, const Env&);
static ZIPPY_NOINLINE Space n86(Context&, const Env&);
static ZIPPY_NOINLINE Path n87(Context&, const Env&);
static ZIPPY_NOINLINE Space n88(Context&, const Env&);
static ZIPPY_NOINLINE Path n89(Context&, const Env&);
static ZIPPY_NOINLINE Space n90(Context&, const Env&);
static ZIPPY_NOINLINE Path n91(Context&, const Env&);
static ZIPPY_NOINLINE Space n92(Context&, const Env&);
static ZIPPY_NOINLINE Space n93(Context&, const Env&);
static ZIPPY_NOINLINE Path n94(Context&, const Env&);
static ZIPPY_NOINLINE Space n95(Context&, const Env&);
static ZIPPY_NOINLINE Path n96(Context&, const Env&);
static ZIPPY_NOINLINE Space n97(Context&, const Env&);
static ZIPPY_NOINLINE Space n98(Context&, const Env&);
static ZIPPY_NOINLINE Space n99(Context&, const Env&);
static ZIPPY_NOINLINE Path n100(Context&, const Env&);
static ZIPPY_NOINLINE Space n101(Context&, const Env&);
static ZIPPY_NOINLINE Path n102(Context&, const Env&);
static ZIPPY_NOINLINE Space n103(Context&, const Env&);
static ZIPPY_NOINLINE Space n104(Context&, const Env&);
static ZIPPY_NOINLINE Space n105(Context&, const Env&);
static ZIPPY_NOINLINE Space n106(Context&, const Env&);
static ZIPPY_NOINLINE Space n107(Context&, const Env&);
static ZIPPY_NOINLINE Path n108(Context&, const Env&);
static ZIPPY_NOINLINE Space n109(Context&, const Env&);
static ZIPPY_NOINLINE Path n110(Context&, const Env&);
static ZIPPY_NOINLINE Space n111(Context&, const Env&);
static ZIPPY_NOINLINE Path n112(Context&, const Env&);
static ZIPPY_NOINLINE Space n113(Context&, const Env&);
static ZIPPY_NOINLINE Space n114(Context&, const Env&);
static ZIPPY_NOINLINE Path n115(Context&, const Env&);
static ZIPPY_NOINLINE Space n116(Context&, const Env&);
static ZIPPY_NOINLINE Path n117(Context&, const Env&);
static ZIPPY_NOINLINE Space n118(Context&, const Env&);
static ZIPPY_NOINLINE Space n119(Context&, const Env&);
static ZIPPY_NOINLINE Space n120(Context&, const Env&);
static ZIPPY_NOINLINE Path n121(Context&, const Env&);
static ZIPPY_NOINLINE Space n122(Context&, const Env&);
static ZIPPY_NOINLINE Space n123(Context&, const Env&);
static ZIPPY_NOINLINE Path n124(Context&, const Env&);
static ZIPPY_NOINLINE Space n125(Context&, const Env&);
static ZIPPY_NOINLINE Path n1(Context& c, const Env& e) { return Path{1,2}; }
static ZIPPY_NOINLINE Path n5(Context& c, const Env& e) { return Path{3}; }
static ZIPPY_NOINLINE Path n8(Context& c, const Env& e) { return Path{4}; }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { static const Space value=literal_text("47 3 4 5 6 3 4 5 25 3 4 6 24 3 4 6 26 3 4 7 8 3 4 7 29 3 4 8 20 3 4 8 29 3 4 9 7 3 4 9 10 3 4 10 7 3 4 10 8 3 4 11 12 3 4 11 23 3 4 12 22 3 4 12 23 3 4 13 14 3 4 13 16 3 4 14 18 3 4 14 21 3 4 15 9 3 4 15 10 3 4 16 14 3 4 16 18 3 4 17 5 3 4 17 25 3 4 18 11 3 4 18 21 3 4 19 5 3 4 19 17 3 4 20 13 3 4 20 16 3 4 21 11 3 4 21 12 3 4 22 27 3 4 22 28 3 4 23 22 3 4 23 28 3 4 24 15 3 4 24 26 3 4 25 6 3 4 25 24 3 4 26 9 3 4 26 15 3 4 28 27 3 4 29 13 3 4 29 20"); return value; }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { auto p=n8(c,e); return unwrap(n9(c,e),p); }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Path n13(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n15(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n17(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Space n18(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n16(Context& c, const Env& e) { auto p=n17(c,e); return wrap(n18(c,e),p); }
static ZIPPY_NOINLINE Space n14(Context& c, const Env& e) { auto p=n15(c,e); return wrap(n16(c,e),p); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { auto p=n13(c,e); return wrap(n14(c,e),p); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { return iterate(c,e,n11(c,e),1,1,n12); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { return iterate(c,e,n7(c,e),0,0,n10); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { auto p=n5(c,e); return wrap(n6(c,e),p); }
static ZIPPY_NOINLINE Path n20(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n21(Context& c, const Env& e) { static const Space value=literal_text("47 3 4 5 6 3 4 5 25 3 4 6 24 3 4 6 26 3 4 7 8 3 4 7 29 3 4 8 20 3 4 8 29 3 4 9 7 3 4 9 10 3 4 10 7 3 4 10 8 3 4 11 12 3 4 11 23 3 4 12 22 3 4 12 23 3 4 13 14 3 4 13 16 3 4 14 18 3 4 14 21 3 4 15 9 3 4 15 10 3 4 16 14 3 4 16 18 3 4 17 5 3 4 17 25 3 4 18 11 3 4 18 21 3 4 19 5 3 4 19 17 3 4 20 13 3 4 20 16 3 4 21 11 3 4 21 12 3 4 22 27 3 4 22 28 3 4 23 22 3 4 23 28 3 4 24 15 3 4 24 26 3 4 25 6 3 4 25 24 3 4 26 9 3 4 26 15 3 4 28 27 3 4 29 13 3 4 29 20"); return value; }
static ZIPPY_NOINLINE Space n19(Context& c, const Env& e) { auto p=n20(c,e); return wrap(n21(c,e),p); }
static ZIPPY_NOINLINE Space n3(Context& c, const Env& e) { auto a=n4(c,e); auto b=n19(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n3(c,e)}; Env n; n.spaces[2]=sv[0];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { auto p=n1(c,e); return unwrap(n2(c,e),p); }
static ZIPPY_NOINLINE Space n23(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Path n29(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Path n32(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n31(Context& c, const Env& e) { auto p=n32(c,e); return unwrap(n33(c,e),p); }
static ZIPPY_NOINLINE Path n35(Context& c, const Env& e) { return Path{3}; }
static ZIPPY_NOINLINE Space n36(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n34(Context& c, const Env& e) { auto p=n35(c,e); return unwrap(n36(c,e),p); }
static ZIPPY_NOINLINE Space n30(Context& c, const Env& e) { auto a=n31(c,e); auto b=n34(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { auto p=n29(c,e); return wrap(n30(c,e),p); }
static ZIPPY_NOINLINE Path n38(Context& c, const Env& e) { return Path{3,2}; }
static ZIPPY_NOINLINE Path n45(Context& c, const Env& e) { return Path{4}; }
static ZIPPY_NOINLINE Path n47(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n48(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n46(Context& c, const Env& e) { auto p=n47(c,e); return unwrap(n48(c,e),p); }
static ZIPPY_NOINLINE Space n44(Context& c, const Env& e) { auto p=n45(c,e); return unwrap(n46(c,e),p); }
static ZIPPY_NOINLINE Space n50(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Path n52(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n54(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Space n55(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n53(Context& c, const Env& e) { auto p=n54(c,e); return wrap(n55(c,e),p); }
static ZIPPY_NOINLINE Space n51(Context& c, const Env& e) { auto p=n52(c,e); return wrap(n53(c,e),p); }
static ZIPPY_NOINLINE Space n49(Context& c, const Env& e) { return iterate(c,e,n50(c,e),1,1,n51); }
static ZIPPY_NOINLINE Space n43(Context& c, const Env& e) { return iterate(c,e,n44(c,e),0,0,n49); }
static ZIPPY_NOINLINE Path n58(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n60(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n61(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n59(Context& c, const Env& e) { auto p=n60(c,e); return unwrap(n61(c,e),p); }
static ZIPPY_NOINLINE Space n57(Context& c, const Env& e) { auto p=n58(c,e); return unwrap(n59(c,e),p); }
static ZIPPY_NOINLINE Space n63(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Path n66(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n68(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n70(Context& c, const Env& e) { return Path{3}; }
static ZIPPY_NOINLINE Space n71(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n69(Context& c, const Env& e) { auto p=n70(c,e); return unwrap(n71(c,e),p); }
static ZIPPY_NOINLINE Space n67(Context& c, const Env& e) { auto p=n68(c,e); return unwrap(n69(c,e),p); }
static ZIPPY_NOINLINE Space n65(Context& c, const Env& e) { auto p=n66(c,e); return unwrap(n67(c,e),p); }
static ZIPPY_NOINLINE Path n73(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n75(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n76(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n74(Context& c, const Env& e) { auto p=n75(c,e); return wrap(n76(c,e),p); }
static ZIPPY_NOINLINE Space n72(Context& c, const Env& e) { auto p=n73(c,e); return wrap(n74(c,e),p); }
static ZIPPY_NOINLINE Space n64(Context& c, const Env& e) { return iterate(c,e,n65(c,e),2,3,n72); }
static ZIPPY_NOINLINE Space n62(Context& c, const Env& e) { return iterate(c,e,n63(c,e),1,1,n64); }
static ZIPPY_NOINLINE Space n56(Context& c, const Env& e) { return iterate(c,e,n57(c,e),0,0,n62); }
static ZIPPY_NOINLINE Space n42(Context& c, const Env& e) { auto a=n43(c,e); auto b=n56(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n79(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n81(Context& c, const Env& e) { return Path{3}; }
static ZIPPY_NOINLINE Space n82(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n80(Context& c, const Env& e) { auto p=n81(c,e); return unwrap(n82(c,e),p); }
static ZIPPY_NOINLINE Space n78(Context& c, const Env& e) { auto p=n79(c,e); return unwrap(n80(c,e),p); }
static ZIPPY_NOINLINE Space n84(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Path n87(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n89(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n91(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n92(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n90(Context& c, const Env& e) { auto p=n91(c,e); return unwrap(n92(c,e),p); }
static ZIPPY_NOINLINE Space n88(Context& c, const Env& e) { auto p=n89(c,e); return unwrap(n90(c,e),p); }
static ZIPPY_NOINLINE Space n86(Context& c, const Env& e) { auto p=n87(c,e); return unwrap(n88(c,e),p); }
static ZIPPY_NOINLINE Path n94(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n96(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n97(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n95(Context& c, const Env& e) { auto p=n96(c,e); return wrap(n97(c,e),p); }
static ZIPPY_NOINLINE Space n93(Context& c, const Env& e) { auto p=n94(c,e); return wrap(n95(c,e),p); }
static ZIPPY_NOINLINE Space n85(Context& c, const Env& e) { return iterate(c,e,n86(c,e),2,3,n93); }
static ZIPPY_NOINLINE Space n83(Context& c, const Env& e) { return iterate(c,e,n84(c,e),1,1,n85); }
static ZIPPY_NOINLINE Space n77(Context& c, const Env& e) { return iterate(c,e,n78(c,e),0,0,n83); }
static ZIPPY_NOINLINE Space n41(Context& c, const Env& e) { auto a=n42(c,e); auto b=n77(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n100(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n102(Context& c, const Env& e) { return Path{3}; }
static ZIPPY_NOINLINE Space n103(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n101(Context& c, const Env& e) { auto p=n102(c,e); return unwrap(n103(c,e),p); }
static ZIPPY_NOINLINE Space n99(Context& c, const Env& e) { auto p=n100(c,e); return unwrap(n101(c,e),p); }
static ZIPPY_NOINLINE Space n105(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Path n108(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n110(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n112(Context& c, const Env& e) { return Path{3}; }
static ZIPPY_NOINLINE Space n113(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n111(Context& c, const Env& e) { auto p=n112(c,e); return unwrap(n113(c,e),p); }
static ZIPPY_NOINLINE Space n109(Context& c, const Env& e) { auto p=n110(c,e); return unwrap(n111(c,e),p); }
static ZIPPY_NOINLINE Space n107(Context& c, const Env& e) { auto p=n108(c,e); return unwrap(n109(c,e),p); }
static ZIPPY_NOINLINE Path n115(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n117(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n118(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Space n116(Context& c, const Env& e) { auto p=n117(c,e); return wrap(n118(c,e),p); }
static ZIPPY_NOINLINE Space n114(Context& c, const Env& e) { auto p=n115(c,e); return wrap(n116(c,e),p); }
static ZIPPY_NOINLINE Space n106(Context& c, const Env& e) { return iterate(c,e,n107(c,e),2,3,n114); }
static ZIPPY_NOINLINE Space n104(Context& c, const Env& e) { return iterate(c,e,n105(c,e),1,1,n106); }
static ZIPPY_NOINLINE Space n98(Context& c, const Env& e) { return iterate(c,e,n99(c,e),0,0,n104); }
static ZIPPY_NOINLINE Space n40(Context& c, const Env& e) { auto a=n41(c,e); auto b=n98(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n121(Context& c, const Env& e) { return Path{1,2}; }
static ZIPPY_NOINLINE Space n122(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n120(Context& c, const Env& e) { auto p=n121(c,e); return unwrap(n122(c,e),p); }
static ZIPPY_NOINLINE Path n124(Context& c, const Env& e) { return Path{3,2}; }
static ZIPPY_NOINLINE Space n125(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n123(Context& c, const Env& e) { auto p=n124(c,e); return unwrap(n125(c,e),p); }
static ZIPPY_NOINLINE Space n119(Context& c, const Env& e) { auto a=n120(c,e); auto b=n123(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n39(Context& c, const Env& e) { auto a=n40(c,e); auto b=n119(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n37(Context& c, const Env& e) { auto p=n38(c,e); return wrap(n39(c,e),p); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { auto a=n28(c,e); auto b=n37(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n25(Context& c, const Env& e) { auto a=n26(c,e); auto b=n27(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n24(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n25(c,e)}; Env n; n.spaces[2]=sv[0]; if(equal(n25(c,n),sv[0])) return n23(c,n); return routine_0(c,n); }
static ZIPPY_NOINLINE Space n22(Context& c, const Env& e) { auto a=n23(c,e); auto b=n24(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n22(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"29 1 8 99 111 109 112 108 101 116 101 2 4 112 97 116 104 3 5 100 101 108 116 97 4 4 101 100 103 101 5 2 110 50 6 2 110 52 7 3 110 49 48 8 3 110 49 49 9 2 110 56 10 2 110 57 11 3 110 49 57 12 3 110 50 48 13 3 110 49 52 14 3 110 49 54 15 2 110 55 16 3 110 49 53 17 2 110 49 18 3 110 49 55 19 2 110 48 20 3 110 49 51 21 3 110 49 56 22 3 110 50 50 23 3 110 50 49 24 2 110 53 25 2 110 51 26 2 110 54 27 3 110 50 52 28 3 110 50 51 29 3 110 49 50"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
