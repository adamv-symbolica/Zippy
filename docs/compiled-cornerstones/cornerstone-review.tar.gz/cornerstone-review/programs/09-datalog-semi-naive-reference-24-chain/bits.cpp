#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Path constant_1 = Path{1,1};
static const Space constant_2 = literal_text("18 12 1 1 1 2 2 1 2 1 1 1 2 2 12 1 1 1 2 2 2 1 1 1 1 2 2 10 1 1 2 2 1 2 1 1 2 2 10 1 1 2 2 2 1 1 1 2 2 11 1 2 1 1 2 2 1 2 1 2 2 11 1 2 1 1 2 2 2 1 1 2 2 13 1 2 1 2 2 1 2 1 1 1 1 2 2 13 1 2 1 2 2 2 1 1 1 1 1 2 2 10 1 2 2 1 1 1 2 1 2 2 11 1 2 2 2 1 1 1 1 1 2 2 14 2 1 1 1 2 2 1 1 1 2 1 1 2 2 14 2 1 1 1 2 2 2 1 2 1 1 1 2 2 12 2 1 1 2 2 2 1 1 2 1 2 2 12 2 1 1 2 2 2 1 2 1 1 2 2 11 2 1 2 2 1 1 1 1 1 2 2 10 2 1 2 2 2 1 2 1 2 2 7 2 2 1 1 1 2 2 6 2 2 2 1 2 2");
static const Path constant_3 = Path{2,1};
static const Space constant_4 = literal_text("18 14 1 1 1 1 2 2 1 1 2 1 1 1 2 2 14 1 1 1 1 2 2 1 2 1 1 1 1 2 2 12 1 1 1 2 2 1 1 2 1 1 2 2 12 1 1 1 2 2 1 2 1 1 1 2 2 10 1 1 2 2 1 1 2 1 2 2 10 1 1 2 2 1 2 1 1 2 2 13 1 2 1 2 2 1 1 1 1 1 1 2 2 12 1 2 1 2 2 1 2 1 2 1 2 2 9 1 2 2 1 1 1 1 2 2 8 1 2 2 1 2 1 2 2 14 2 1 1 1 2 2 1 1 1 2 1 1 2 2 11 2 1 1 1 2 2 2 1 1 2 2 12 2 1 1 2 2 1 2 1 2 1 2 2 12 2 1 1 2 2 2 1 1 2 1 2 2 11 2 1 2 2 1 1 1 1 1 2 2 11 2 1 2 2 2 1 1 1 1 2 2 9 2 2 1 1 1 2 1 2 2 7 2 2 1 1 1 2 2");
static const Path constant_5 = Path{1,2};
static const Space constant_6 = literal_text("11 14 1 1 1 1 2 2 1 1 2 1 1 1 2 2 14 1 1 1 1 2 2 2 1 2 1 1 1 2 2 12 1 1 1 2 2 1 1 2 1 1 2 2 12 1 1 1 2 2 2 1 2 1 1 2 2 10 1 1 2 2 1 1 2 1 2 2 10 1 1 2 2 2 1 2 1 2 2 13 1 2 1 2 2 1 1 1 1 1 1 2 2 9 1 2 2 1 1 1 1 2 2 9 1 2 2 2 1 1 1 2 2 5 2 1 1 2 2 5 2 2 1 2 2");
static const Path constant_7 = Path{1,2,1,2,1,1,2,2};
static const Space constant_8 = literal_text("47 24 1 1 1 1 2 1 2 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 1 1 1 2 2 1 2 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 1 1 1 2 2 2 1 1 1 2 2 23 1 1 1 1 2 1 2 2 2 2 1 1 1 2 1 1 2 2 1 2 1 2 2 23 1 1 1 1 2 1 2 2 2 2 1 1 1 2 1 1 2 2 2 1 1 2 2 25 1 1 1 1 2 1 2 2 2 2 1 1 1 2 1 2 2 1 2 1 1 1 1 2 2 25 1 1 1 1 2 1 2 2 2 2 1 1 1 2 1 2 2 2 1 1 1 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 1 1 2 2 1 1 1 2 1 2 2 23 1 1 1 1 2 1 2 2 2 2 1 1 1 2 2 2 1 1 1 1 1 2 2 26 1 1 1 1 2 1 2 2 2 2 1 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 26 1 1 1 1 2 1 2 2 2 2 1 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 1 1 2 1 1 2 2 2 1 1 2 1 2 2 24 1 1 1 1 2 1 2 2 2 2 1 1 2 1 1 2 2 2 1 2 1 1 2 2 23 1 1 1 1 2 1 2 2 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 1 2 1 2 2 2 1 2 1 2 2 19 1 1 1 1 2 1 2 2 2 2 1 1 2 2 1 1 1 2 2 18 1 1 1 1 2 1 2 2 2 2 1 1 2 2 2 1 2 2 26 1 1 1 1 2 1 2 2 2 2 1 2 1 1 1 1 2 2 1 1 2 1 1 1 2 2 26 1 1 1 1 2 1 2 2 2 2 1 2 1 1 1 1 2 2 2 1 2 1 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 1 2 1 1 1 2 2 1 1 2 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 1 2 1 1 1 2 2 2 1 2 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 2 1 1 2 2 1 1 2 1 2 2 22 1 1 1 1 2 1 2 2 2 2 1 2 1 1 2 2 2 1 2 1 2 2 25 1 1 1 1 2 1 2 2 2 2 1 2 1 2 1 2 2 1 1 1 1 1 1 2 2 21 1 1 1 1 2 1 2 2 2 2 1 2 1 2 2 1 1 1 1 2 2 21 1 1 1 1 2 1 2 2 2 2 1 2 1 2 2 2 1 1 1 2 2 17 1 1 1 1 2 1 2 2 2 2 1 2 2 1 1 2 2 17 1 1 1 1 2 1 2 2 2 2 1 2 2 2 1 2 2 26 1 1 1 1 2 1 2 2 2 2 2 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 26 1 1 1 1 2 1 2 2 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 2 1 1 1 1 2 2 1 1 2 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 22 1 1 1 1 2 1 2 2 2 2 2 1 1 1 2 2 1 1 2 1 2 2 22 1 1 1 1 2 1 2 2 2 2 2 1 1 1 2 2 1 2 1 1 2 2 25 1 1 1 1 2 1 2 2 2 2 2 1 1 2 1 2 2 1 1 1 1 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 2 1 1 2 1 2 2 1 2 1 2 1 2 2 21 1 1 1 1 2 1 2 2 2 2 2 1 1 2 2 1 1 1 1 2 2 20 1 1 1 1 2 1 2 2 2 2 2 1 1 2 2 1 2 1 2 2 26 1 1 1 1 2 1 2 2 2 2 2 1 2 1 1 1 2 2 1 1 1 2 1 1 2 2 23 1 1 1 1 2 1 2 2 2 2 2 1 2 1 1 1 2 2 2 1 1 2 2 24 1 1 1 1 2 1 2 2 2 2 2 1 2 1 1 2 2 1 2 1 2 1 2 2 24 1 1 1 1 2 1 2 2 2 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 23 1 1 1 1 2 1 2 2 2 2 2 1 2 1 2 2 1 1 1 1 1 2 2 23 1 1 1 1 2 1 2 2 2 2 2 1 2 1 2 2 2 1 1 1 1 2 2 21 1 1 1 1 2 1 2 2 2 2 2 1 2 2 1 1 1 2 1 2 2 19 1 1 1 1 2 1 2 2 2 2 2 1 2 2 1 1 1 2 2");
static const Path constant_9 = Path{1,1,1,1,2,1,2,2};
static const Path constant_10 = Path{2,1,1,2,1,1,2,2};
static const Path constant_11 = Path{2,2};
static const Path constant_12 = Path{1,1,1,1,2,1,2,2,2,1,1,2,1,1,2,2};
static const Path constant_13 = Path{1,2,1,2,1,1,2,2,2,1,1,2,1,1,2,2};
static const Space constant_14 = literal_text("1 1 2");
static const Space constant_15 = singleton(Path{});
static Space routine_0(Context& c);
static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_87(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_23(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_88(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_1(Context& c, const Path& p0, const Space& s0);
static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_80(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_9(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_45(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_6(Context& c, const Path& p0, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_2(Context& c, const Path& p0, const Space& s0);
static Space routine_64(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_7(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_68(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_100(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_57(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_112(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_74(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_120(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_85(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_69(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_101(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_58(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_113(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_75(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_121(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_86(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Space& s0);
static Space routine_70(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_104(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_20(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_116(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_78(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_34(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_89(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_41(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Space& s0);
static Space routine_71(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_105(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_21(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_117(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_79(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_35(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_42(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_98(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_140(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_110(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_99(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_141(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_111(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_66(Context& c, const Path& p0, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Space& s0);
static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_102(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_55(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_142(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_72(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_83(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_67(Context& c, const Path& p0, const Space& s0);
static Space routine_49(Context& c, const Path& p0, const Space& s0);
static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_103(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_56(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_143(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_73(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_84(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_152(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_144(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_128(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_151(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_145(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_129(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_17(Context& c, const Path& p0, const Space& s0);
static Space routine_65(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_82(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_8(Context& c, const Path& p0, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_0(Context& c) {
  Space v0_14;
  if (!constant_0.empty()) {
    Space v1_13;
    if (!constant_0.empty()) {
      const Space v2_4 = routine_1(c, constant_1, constant_2);
      const Space v2_7 = routine_1(c, constant_3, constant_4);
      const Space v2_8 = unite(v2_4,v2_7);
      const Space v2_11 = routine_2(c, constant_5, constant_6);
      const Space v2_12 = unite(v2_8,v2_11);
      v1_13 = compose(constant_0,v2_12);
    }
    v0_14 = compose(constant_0,v1_13);
  }
  const Space v0_16 = wrap(v0_14,constant_7);
  const Space v0_18 = unite(v0_16,constant_8);
  Space v0_60 = v0_18;
  for (;;) {
    const Space v3_1 = unwrap(v0_60,constant_9);
    const Space v3_2 = unwrap(v0_60,constant_7);
    const Space v3_3 = unite(v3_1,v3_2);
    const Space v3_4 = wrap(v3_3,constant_9);
    const Space v3_5 = unwrap(v3_1,constant_10);
    Space v3_6_result;
    for (int v3_6_label = 1; v3_6_label <= 2; ++v3_6_label) {
      const Space v3_6_tail = child(v3_5,v3_6_label);
      if (v3_6_tail.empty()) continue;
      const Path v3_6_head{v3_6_label};
      const Space v4_2 = singleton(v3_6_head);
      const Space v4_3 = intersect(constant_14,v4_2);
      const Space v4_4 = (has_head(v4_3) ? constant_15 : Space{});
      const Space v4_5 = subtract(constant_0,v4_4);
      Space v4_7;
      if (!v4_5.empty()) {
        Space v5_6_result;
        for (int v5_6_label = 1; v5_6_label <= 2; ++v5_6_label) {
          const Space v5_6_tail = child(v3_6_tail,v5_6_label);
          if (v5_6_tail.empty()) continue;
          const Path v5_6_head{v5_6_label};
          const Space v6_2 = singleton(v5_6_head);
          const Space v6_3 = intersect(constant_14,v6_2);
          const Space v6_4 = (has_head(v6_3) ? constant_15 : Space{});
          const Space v6_5 = subtract(constant_0,v6_4);
          Space v6_8;
          if (!v6_5.empty()) {
            const Path v7_6 = concat_path(v3_6_head,v5_6_head);
            const Space v7_7 = routine_3(c, v7_6, v5_6_tail, v0_60);
            v6_8 = compose(v6_5,v7_7);
          }
          const Space v6_9 = intersect(constant_14,v6_2);
          const Space v6_10 = (has_head(v6_9) ? constant_15 : Space{});
          Space v6_12;
          if (!v6_10.empty()) {
            const Path v8_6 = concat_path(v3_6_head,v5_6_head);
            const Space v8_11 = routine_4(c, v8_6, v5_6_tail, v0_60);
            v6_12 = compose(v6_10,v8_11);
          }
          const Space v6_13 = unite(v6_8,v6_12);
          v5_6_result = unite(v5_6_result,v6_13);
        }
        const Space v5_6 = std::move(v5_6_result);
        v4_7 = compose(v4_5,v5_6);
      }
      const Space v4_8 = intersect(constant_14,v4_2);
      const Space v4_9 = (has_head(v4_8) ? constant_15 : Space{});
      Space v4_11;
      if (!v4_9.empty()) {
        Space v9_10_result;
        for (int v9_10_label = 1; v9_10_label <= 2; ++v9_10_label) {
          const Space v9_10_tail = child(v3_6_tail,v9_10_label);
          if (v9_10_tail.empty()) continue;
          const Path v9_10_head{v9_10_label};
          const Space v10_2 = singleton(v9_10_head);
          const Space v10_3 = intersect(constant_14,v10_2);
          const Space v10_4 = (has_head(v10_3) ? constant_15 : Space{});
          const Space v10_5 = subtract(constant_0,v10_4);
          Space v10_8;
          if (!v10_5.empty()) {
            const Path v11_6 = concat_path(v3_6_head,v9_10_head);
            const Space v11_7 = routine_3(c, v11_6, v9_10_tail, v0_60);
            v10_8 = compose(v10_5,v11_7);
          }
          const Space v10_9 = intersect(constant_14,v10_2);
          const Space v10_10 = (has_head(v10_9) ? constant_15 : Space{});
          Space v10_12;
          if (!v10_10.empty()) {
            const Path v12_6 = concat_path(v3_6_head,v9_10_head);
            const Space v12_11 = routine_5(c, v12_6, v9_10_tail, v0_60);
            v10_12 = compose(v10_10,v12_11);
          }
          const Space v10_13 = unite(v10_8,v10_12);
          v9_10_result = unite(v9_10_result,v10_13);
        }
        const Space v9_10 = std::move(v9_10_result);
        v4_11 = compose(v4_9,v9_10);
      }
      const Space v4_12 = unite(v4_7,v4_11);
      v3_6_result = unite(v3_6_result,v4_12);
    }
    const Space v3_6 = std::move(v3_6_result);
    const Space v3_7 = unwrap(v3_1,constant_11);
    Space v3_8_result;
    for (int v3_8_label = 1; v3_8_label <= 2; ++v3_8_label) {
      const Space v3_8_tail = child(v3_7,v3_8_label);
      if (v3_8_tail.empty()) continue;
      const Path v3_8_head{v3_8_label};
      const Space v13_2 = singleton(v3_8_head);
      const Space v13_3 = intersect(constant_14,v13_2);
      const Space v13_4 = (has_head(v13_3) ? constant_15 : Space{});
      const Space v13_5 = subtract(constant_0,v13_4);
      Space v13_7;
      if (!v13_5.empty()) {
        Space v14_6_result;
        for (int v14_6_label = 1; v14_6_label <= 2; ++v14_6_label) {
          const Space v14_6_tail = child(v3_8_tail,v14_6_label);
          if (v14_6_tail.empty()) continue;
          const Path v14_6_head{v14_6_label};
          const Space v15_2 = singleton(v14_6_head);
          const Space v15_3 = intersect(constant_14,v15_2);
          const Space v15_4 = (has_head(v15_3) ? constant_15 : Space{});
          const Space v15_5 = subtract(constant_0,v15_4);
          Space v15_8;
          if (!v15_5.empty()) {
            const Path v16_6 = concat_path(v3_8_head,v14_6_head);
            const Space v16_7 = routine_6(c, v16_6, v14_6_tail);
            v15_8 = compose(v15_5,v16_7);
          }
          const Space v15_9 = intersect(constant_14,v15_2);
          const Space v15_10 = (has_head(v15_9) ? constant_15 : Space{});
          Space v15_12;
          if (!v15_10.empty()) {
            const Path v17_6 = concat_path(v3_8_head,v14_6_head);
            const Space v17_11 = routine_7(c, v17_6, v14_6_tail);
            v15_12 = compose(v15_10,v17_11);
          }
          const Space v15_13 = unite(v15_8,v15_12);
          v14_6_result = unite(v14_6_result,v15_13);
        }
        const Space v14_6 = std::move(v14_6_result);
        v13_7 = compose(v13_5,v14_6);
      }
      const Space v13_8 = intersect(constant_14,v13_2);
      const Space v13_9 = (has_head(v13_8) ? constant_15 : Space{});
      Space v13_11;
      if (!v13_9.empty()) {
        Space v18_10_result;
        for (int v18_10_label = 1; v18_10_label <= 2; ++v18_10_label) {
          const Space v18_10_tail = child(v3_8_tail,v18_10_label);
          if (v18_10_tail.empty()) continue;
          const Path v18_10_head{v18_10_label};
          const Space v19_2 = singleton(v18_10_head);
          const Space v19_3 = intersect(constant_14,v19_2);
          const Space v19_4 = (has_head(v19_3) ? constant_15 : Space{});
          const Space v19_5 = subtract(constant_0,v19_4);
          Space v19_8;
          if (!v19_5.empty()) {
            const Path v20_6 = concat_path(v3_8_head,v18_10_head);
            const Space v20_7 = routine_6(c, v20_6, v18_10_tail);
            v19_8 = compose(v19_5,v20_7);
          }
          const Space v19_9 = intersect(constant_14,v19_2);
          const Space v19_10 = (has_head(v19_9) ? constant_15 : Space{});
          Space v19_12;
          if (!v19_10.empty()) {
            const Path v21_6 = concat_path(v3_8_head,v18_10_head);
            const Space v21_11 = routine_8(c, v21_6, v18_10_tail);
            v19_12 = compose(v19_10,v21_11);
          }
          const Space v19_13 = unite(v19_8,v19_12);
          v18_10_result = unite(v18_10_result,v19_13);
        }
        const Space v18_10 = std::move(v18_10_result);
        v13_11 = compose(v13_9,v18_10);
      }
      const Space v13_12 = unite(v13_7,v13_11);
      v3_8_result = unite(v3_8_result,v13_12);
    }
    const Space v3_8 = std::move(v3_8_result);
    const Space v3_9 = unite(v3_6,v3_8);
    const Space v3_10 = unwrap(v3_2,constant_10);
    Space v3_11_result;
    for (int v3_11_label = 1; v3_11_label <= 2; ++v3_11_label) {
      const Space v3_11_tail = child(v3_10,v3_11_label);
      if (v3_11_tail.empty()) continue;
      const Path v3_11_head{v3_11_label};
      const Space v22_2 = singleton(v3_11_head);
      const Space v22_3 = intersect(constant_14,v22_2);
      const Space v22_4 = (has_head(v22_3) ? constant_15 : Space{});
      const Space v22_5 = subtract(constant_0,v22_4);
      Space v22_7;
      if (!v22_5.empty()) {
        Space v23_6_result;
        for (int v23_6_label = 1; v23_6_label <= 2; ++v23_6_label) {
          const Space v23_6_tail = child(v3_11_tail,v23_6_label);
          if (v23_6_tail.empty()) continue;
          const Path v23_6_head{v23_6_label};
          const Space v24_2 = singleton(v23_6_head);
          const Space v24_3 = intersect(constant_14,v24_2);
          const Space v24_4 = (has_head(v24_3) ? constant_15 : Space{});
          const Space v24_5 = subtract(constant_0,v24_4);
          Space v24_8;
          if (!v24_5.empty()) {
            const Path v25_6 = concat_path(v3_11_head,v23_6_head);
            const Space v25_7 = routine_9(c, v25_6, v23_6_tail, v0_60);
            v24_8 = compose(v24_5,v25_7);
          }
          const Space v24_9 = intersect(constant_14,v24_2);
          const Space v24_10 = (has_head(v24_9) ? constant_15 : Space{});
          Space v24_12;
          if (!v24_10.empty()) {
            const Path v26_6 = concat_path(v3_11_head,v23_6_head);
            const Space v26_11 = routine_10(c, v26_6, v23_6_tail, v0_60);
            v24_12 = compose(v24_10,v26_11);
          }
          const Space v24_13 = unite(v24_8,v24_12);
          v23_6_result = unite(v23_6_result,v24_13);
        }
        const Space v23_6 = std::move(v23_6_result);
        v22_7 = compose(v22_5,v23_6);
      }
      const Space v22_8 = intersect(constant_14,v22_2);
      const Space v22_9 = (has_head(v22_8) ? constant_15 : Space{});
      Space v22_11;
      if (!v22_9.empty()) {
        Space v27_10_result;
        for (int v27_10_label = 1; v27_10_label <= 2; ++v27_10_label) {
          const Space v27_10_tail = child(v3_11_tail,v27_10_label);
          if (v27_10_tail.empty()) continue;
          const Path v27_10_head{v27_10_label};
          const Space v28_2 = singleton(v27_10_head);
          const Space v28_3 = intersect(constant_14,v28_2);
          const Space v28_4 = (has_head(v28_3) ? constant_15 : Space{});
          const Space v28_5 = subtract(constant_0,v28_4);
          Space v28_8;
          if (!v28_5.empty()) {
            const Path v29_6 = concat_path(v3_11_head,v27_10_head);
            const Space v29_7 = routine_9(c, v29_6, v27_10_tail, v0_60);
            v28_8 = compose(v28_5,v29_7);
          }
          const Space v28_9 = intersect(constant_14,v28_2);
          const Space v28_10 = (has_head(v28_9) ? constant_15 : Space{});
          Space v28_12;
          if (!v28_10.empty()) {
            const Path v30_6 = concat_path(v3_11_head,v27_10_head);
            const Space v30_11 = routine_11(c, v30_6, v27_10_tail, v0_60);
            v28_12 = compose(v28_10,v30_11);
          }
          const Space v28_13 = unite(v28_8,v28_12);
          v27_10_result = unite(v27_10_result,v28_13);
        }
        const Space v27_10 = std::move(v27_10_result);
        v22_11 = compose(v22_9,v27_10);
      }
      const Space v22_12 = unite(v22_7,v22_11);
      v3_11_result = unite(v3_11_result,v22_12);
    }
    const Space v3_11 = std::move(v3_11_result);
    const Space v3_12 = unite(v3_9,v3_11);
    Space v3_13_result;
    for (int v3_13_label = 1; v3_13_label <= 2; ++v3_13_label) {
      const Space v3_13_tail = child(v3_10,v3_13_label);
      if (v3_13_tail.empty()) continue;
      const Path v3_13_head{v3_13_label};
      const Space v31_2 = singleton(v3_13_head);
      const Space v31_3 = intersect(constant_14,v31_2);
      const Space v31_4 = (has_head(v31_3) ? constant_15 : Space{});
      const Space v31_5 = subtract(constant_0,v31_4);
      Space v31_7;
      if (!v31_5.empty()) {
        Space v32_6_result;
        for (int v32_6_label = 1; v32_6_label <= 2; ++v32_6_label) {
          const Space v32_6_tail = child(v3_13_tail,v32_6_label);
          if (v32_6_tail.empty()) continue;
          const Path v32_6_head{v32_6_label};
          const Space v33_2 = singleton(v32_6_head);
          const Space v33_3 = intersect(constant_14,v33_2);
          const Space v33_4 = (has_head(v33_3) ? constant_15 : Space{});
          const Space v33_5 = subtract(constant_0,v33_4);
          Space v33_8;
          if (!v33_5.empty()) {
            const Path v34_6 = concat_path(v3_13_head,v32_6_head);
            const Space v34_7 = routine_12(c, v34_6, v32_6_tail, v0_60);
            v33_8 = compose(v33_5,v34_7);
          }
          const Space v33_9 = intersect(constant_14,v33_2);
          const Space v33_10 = (has_head(v33_9) ? constant_15 : Space{});
          Space v33_12;
          if (!v33_10.empty()) {
            const Path v35_6 = concat_path(v3_13_head,v32_6_head);
            const Space v35_11 = routine_13(c, v35_6, v32_6_tail, v0_60);
            v33_12 = compose(v33_10,v35_11);
          }
          const Space v33_13 = unite(v33_8,v33_12);
          v32_6_result = unite(v32_6_result,v33_13);
        }
        const Space v32_6 = std::move(v32_6_result);
        v31_7 = compose(v31_5,v32_6);
      }
      const Space v31_8 = intersect(constant_14,v31_2);
      const Space v31_9 = (has_head(v31_8) ? constant_15 : Space{});
      Space v31_11;
      if (!v31_9.empty()) {
        Space v36_10_result;
        for (int v36_10_label = 1; v36_10_label <= 2; ++v36_10_label) {
          const Space v36_10_tail = child(v3_13_tail,v36_10_label);
          if (v36_10_tail.empty()) continue;
          const Path v36_10_head{v36_10_label};
          const Space v37_2 = singleton(v36_10_head);
          const Space v37_3 = intersect(constant_14,v37_2);
          const Space v37_4 = (has_head(v37_3) ? constant_15 : Space{});
          const Space v37_5 = subtract(constant_0,v37_4);
          Space v37_8;
          if (!v37_5.empty()) {
            const Path v38_6 = concat_path(v3_13_head,v36_10_head);
            const Space v38_7 = routine_12(c, v38_6, v36_10_tail, v0_60);
            v37_8 = compose(v37_5,v38_7);
          }
          const Space v37_9 = intersect(constant_14,v37_2);
          const Space v37_10 = (has_head(v37_9) ? constant_15 : Space{});
          Space v37_12;
          if (!v37_10.empty()) {
            const Path v39_6 = concat_path(v3_13_head,v36_10_head);
            const Space v39_11 = routine_14(c, v39_6, v36_10_tail, v0_60);
            v37_12 = compose(v37_10,v39_11);
          }
          const Space v37_13 = unite(v37_8,v37_12);
          v36_10_result = unite(v36_10_result,v37_13);
        }
        const Space v36_10 = std::move(v36_10_result);
        v31_11 = compose(v31_9,v36_10);
      }
      const Space v31_12 = unite(v31_7,v31_11);
      v3_13_result = unite(v3_13_result,v31_12);
    }
    const Space v3_13 = std::move(v3_13_result);
    const Space v3_14 = unite(v3_12,v3_13);
    const Space v3_15 = unwrap(v0_60,constant_12);
    const Space v3_16 = subtract(v3_14,v3_15);
    const Space v3_17 = unwrap(v0_60,constant_13);
    const Space v3_18 = subtract(v3_16,v3_17);
    const Space v3_19 = wrap(v3_18,constant_13);
    const Space v3_20 = unite(v3_4,v3_19);
    const Space v3_21 = unite(v3_20,v0_60);
    Space v0_60_next = unite(v0_60,v3_21);
    if (equal(v0_60_next,v0_60)) break;
    v0_60 = std::move(v0_60_next);
  }
  const Space v0_61 = unwrap(v0_60,constant_12);
  return v0_61;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0) {
  Space v40_11_result;
  for (int v40_11_label = 1; v40_11_label <= 2; ++v40_11_label) {
    const Space v40_11_tail = child(s0,v40_11_label);
    if (v40_11_tail.empty()) continue;
    const Path v40_11_head{v40_11_label};
    const Space v41_2 = singleton(v40_11_head);
    const Space v41_3 = intersect(constant_14,v41_2);
    const Space v41_4 = (has_head(v41_3) ? constant_15 : Space{});
    const Space v41_5 = subtract(constant_0,v41_4);
    Space v41_8;
    if (!v41_5.empty()) {
      const Path v42_6 = concat_path(p0,v40_11_head);
      Space v42_7_result;
      for (int v42_7_label = 1; v42_7_label <= 2; ++v42_7_label) {
        const Space v42_7_tail = child(v40_11_tail,v42_7_label);
        if (v42_7_tail.empty()) continue;
        const Path v42_7_head{v42_7_label};
        const Space v43_2 = singleton(v42_7_head);
        const Space v43_3 = intersect(constant_14,v43_2);
        const Space v43_4 = (has_head(v43_3) ? constant_15 : Space{});
        const Space v43_5 = subtract(constant_0,v43_4);
        Space v43_8;
        if (!v43_5.empty()) {
          const Path v44_6 = concat_path(v42_6,v42_7_head);
          const Space v44_7 = routine_15(c, v44_6, v42_7_tail);
          v43_8 = compose(v43_5,v44_7);
        }
        const Space v43_9 = intersect(constant_14,v43_2);
        const Space v43_10 = (has_head(v43_9) ? constant_15 : Space{});
        Space v43_12;
        if (!v43_10.empty()) {
          const Path v45_6 = concat_path(v42_6,v42_7_head);
          const Space v45_11 = routine_16(c, v45_6, v42_7_tail);
          v43_12 = compose(v43_10,v45_11);
        }
        const Space v43_13 = unite(v43_8,v43_12);
        v42_7_result = unite(v42_7_result,v43_13);
      }
      const Space v42_7 = std::move(v42_7_result);
      v41_8 = compose(v41_5,v42_7);
    }
    const Space v41_9 = intersect(constant_14,v41_2);
    const Space v41_10 = (has_head(v41_9) ? constant_15 : Space{});
    Space v41_12;
    if (!v41_10.empty()) {
      const Path v46_6 = concat_path(p0,v40_11_head);
      Space v46_11_result;
      for (int v46_11_label = 1; v46_11_label <= 2; ++v46_11_label) {
        const Space v46_11_tail = child(v40_11_tail,v46_11_label);
        if (v46_11_tail.empty()) continue;
        const Path v46_11_head{v46_11_label};
        const Space v47_2 = singleton(v46_11_head);
        const Space v47_3 = intersect(constant_14,v47_2);
        const Space v47_4 = (has_head(v47_3) ? constant_15 : Space{});
        const Space v47_5 = subtract(constant_0,v47_4);
        Space v47_8;
        if (!v47_5.empty()) {
          const Path v48_6 = concat_path(v46_6,v46_11_head);
          const Space v48_7 = routine_15(c, v48_6, v46_11_tail);
          v47_8 = compose(v47_5,v48_7);
        }
        const Space v47_9 = intersect(constant_14,v47_2);
        const Space v47_10 = (has_head(v47_9) ? constant_15 : Space{});
        Space v47_12;
        if (!v47_10.empty()) {
          const Path v49_6 = concat_path(v46_6,v46_11_head);
          const Space v49_11 = routine_17(c, v49_6, v46_11_tail);
          v47_12 = compose(v47_10,v49_11);
        }
        const Space v47_13 = unite(v47_8,v47_12);
        v46_11_result = unite(v46_11_result,v47_13);
      }
      const Space v46_11 = std::move(v46_11_result);
      v41_12 = compose(v41_10,v46_11);
    }
    const Space v41_13 = unite(v41_8,v41_12);
    v40_11_result = unite(v40_11_result,v41_13);
  }
  const Space v40_11 = std::move(v40_11_result);
  return v40_11;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0) {
  Space v50_11_result;
  for (int v50_11_label = 1; v50_11_label <= 2; ++v50_11_label) {
    const Space v50_11_tail = child(s0,v50_11_label);
    if (v50_11_tail.empty()) continue;
    const Path v50_11_head{v50_11_label};
    const Space v51_2 = singleton(v50_11_head);
    const Space v51_3 = intersect(constant_14,v51_2);
    const Space v51_4 = (has_head(v51_3) ? constant_15 : Space{});
    const Space v51_5 = subtract(constant_0,v51_4);
    Space v51_8;
    if (!v51_5.empty()) {
      const Path v52_6 = concat_path(p0,v50_11_head);
      Space v52_7_result;
      for (int v52_7_label = 1; v52_7_label <= 2; ++v52_7_label) {
        const Space v52_7_tail = child(v50_11_tail,v52_7_label);
        if (v52_7_tail.empty()) continue;
        const Path v52_7_head{v52_7_label};
        const Space v53_2 = singleton(v52_7_head);
        const Space v53_3 = intersect(constant_14,v53_2);
        const Space v53_4 = (has_head(v53_3) ? constant_15 : Space{});
        const Space v53_5 = subtract(constant_0,v53_4);
        Space v53_8;
        if (!v53_5.empty()) {
          const Path v54_6 = concat_path(v52_6,v52_7_head);
          const Space v54_7 = routine_15(c, v54_6, v52_7_tail);
          v53_8 = compose(v53_5,v54_7);
        }
        const Space v53_9 = intersect(constant_14,v53_2);
        const Space v53_10 = (has_head(v53_9) ? constant_15 : Space{});
        Space v53_12;
        if (!v53_10.empty()) {
          const Path v55_6 = concat_path(v52_6,v52_7_head);
          const Space v55_11 = routine_16(c, v55_6, v52_7_tail);
          v53_12 = compose(v53_10,v55_11);
        }
        const Space v53_13 = unite(v53_8,v53_12);
        v52_7_result = unite(v52_7_result,v53_13);
      }
      const Space v52_7 = std::move(v52_7_result);
      v51_8 = compose(v51_5,v52_7);
    }
    const Space v51_9 = intersect(constant_14,v51_2);
    const Space v51_10 = (has_head(v51_9) ? constant_15 : Space{});
    Space v51_12;
    if (!v51_10.empty()) {
      const Path v56_6 = concat_path(p0,v50_11_head);
      Space v56_11_result;
      for (int v56_11_label = 1; v56_11_label <= 2; ++v56_11_label) {
        const Space v56_11_tail = child(v50_11_tail,v56_11_label);
        if (v56_11_tail.empty()) continue;
        const Path v56_11_head{v56_11_label};
        const Space v57_2 = singleton(v56_11_head);
        const Space v57_3 = intersect(constant_14,v57_2);
        const Space v57_4 = (has_head(v57_3) ? constant_15 : Space{});
        const Space v57_5 = subtract(constant_0,v57_4);
        Space v57_7;
        if (!v57_5.empty()) {
          const Space v58_6 = routine_18(c, v56_11_head, v56_6, v56_11_tail);
          v57_7 = compose(v57_5,v58_6);
        }
        const Space v57_8 = intersect(constant_14,v57_2);
        const Space v57_9 = (has_head(v57_8) ? constant_15 : Space{});
        Space v57_11;
        if (!v57_9.empty()) {
          const Space v59_10 = routine_19(c, v56_11_head, v56_6, v56_11_tail);
          v57_11 = compose(v57_9,v59_10);
        }
        const Space v57_12 = unite(v57_7,v57_11);
        v56_11_result = unite(v56_11_result,v57_12);
      }
      const Space v56_11 = std::move(v56_11_result);
      v51_12 = compose(v51_10,v56_11);
    }
    const Space v51_13 = unite(v51_8,v51_12);
    v50_11_result = unite(v50_11_result,v51_13);
  }
  const Space v50_11 = std::move(v50_11_result);
  return v50_11;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v60_12_result;
  for (int v60_12_label = 1; v60_12_label <= 2; ++v60_12_label) {
    const Space v60_12_tail = child(s0,v60_12_label);
    if (v60_12_tail.empty()) continue;
    const Path v60_12_head{v60_12_label};
    const Space v61_2 = singleton(v60_12_head);
    const Space v61_3 = intersect(constant_14,v61_2);
    const Space v61_4 = (has_head(v61_3) ? constant_15 : Space{});
    const Space v61_5 = subtract(constant_0,v61_4);
    Space v61_8;
    if (!v61_5.empty()) {
      const Path v62_6 = concat_path(p0,v60_12_head);
      Space v62_7_result;
      for (int v62_7_label = 1; v62_7_label <= 2; ++v62_7_label) {
        const Space v62_7_tail = child(v60_12_tail,v62_7_label);
        if (v62_7_tail.empty()) continue;
        const Path v62_7_head{v62_7_label};
        const Space v63_2 = singleton(v62_7_head);
        const Space v63_3 = intersect(constant_14,v63_2);
        const Space v63_4 = (has_head(v63_3) ? constant_15 : Space{});
        const Space v63_5 = subtract(constant_0,v63_4);
        Space v63_8;
        if (!v63_5.empty()) {
          const Path v64_6 = concat_path(v62_6,v62_7_head);
          const Space v64_7 = routine_20(c, v64_6, v62_7_tail, s1);
          v63_8 = compose(v63_5,v64_7);
        }
        const Space v63_9 = intersect(constant_14,v63_2);
        const Space v63_10 = (has_head(v63_9) ? constant_15 : Space{});
        Space v63_12;
        if (!v63_10.empty()) {
          const Path v65_6 = concat_path(v62_6,v62_7_head);
          const Space v65_11 = routine_21(c, v65_6, v62_7_tail, s1);
          v63_12 = compose(v63_10,v65_11);
        }
        const Space v63_13 = unite(v63_8,v63_12);
        v62_7_result = unite(v62_7_result,v63_13);
      }
      const Space v62_7 = std::move(v62_7_result);
      v61_8 = compose(v61_5,v62_7);
    }
    const Space v61_9 = intersect(constant_14,v61_2);
    const Space v61_10 = (has_head(v61_9) ? constant_15 : Space{});
    Space v61_12;
    if (!v61_10.empty()) {
      const Path v66_6 = concat_path(p0,v60_12_head);
      Space v66_11_result;
      for (int v66_11_label = 1; v66_11_label <= 2; ++v66_11_label) {
        const Space v66_11_tail = child(v60_12_tail,v66_11_label);
        if (v66_11_tail.empty()) continue;
        const Path v66_11_head{v66_11_label};
        const Space v67_2 = singleton(v66_11_head);
        const Space v67_3 = intersect(constant_14,v67_2);
        const Space v67_4 = (has_head(v67_3) ? constant_15 : Space{});
        const Space v67_5 = subtract(constant_0,v67_4);
        Space v67_8;
        if (!v67_5.empty()) {
          const Path v68_6 = concat_path(v66_6,v66_11_head);
          const Space v68_7 = routine_20(c, v68_6, v66_11_tail, s1);
          v67_8 = compose(v67_5,v68_7);
        }
        const Space v67_9 = intersect(constant_14,v67_2);
        const Space v67_10 = (has_head(v67_9) ? constant_15 : Space{});
        Space v67_12;
        if (!v67_10.empty()) {
          const Path v69_6 = concat_path(v66_6,v66_11_head);
          const Space v69_11 = routine_5(c, v69_6, v66_11_tail, s1);
          v67_12 = compose(v67_10,v69_11);
        }
        const Space v67_13 = unite(v67_8,v67_12);
        v66_11_result = unite(v66_11_result,v67_13);
      }
      const Space v66_11 = std::move(v66_11_result);
      v61_12 = compose(v61_10,v66_11);
    }
    const Space v61_13 = unite(v61_8,v61_12);
    v60_12_result = unite(v60_12_result,v61_13);
  }
  const Space v60_12 = std::move(v60_12_result);
  return v60_12;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v70_12_result;
  for (int v70_12_label = 1; v70_12_label <= 2; ++v70_12_label) {
    const Space v70_12_tail = child(s0,v70_12_label);
    if (v70_12_tail.empty()) continue;
    const Path v70_12_head{v70_12_label};
    const Space v71_2 = singleton(v70_12_head);
    const Space v71_3 = intersect(constant_14,v71_2);
    const Space v71_4 = (has_head(v71_3) ? constant_15 : Space{});
    const Space v71_5 = subtract(constant_0,v71_4);
    Space v71_8;
    if (!v71_5.empty()) {
      const Path v72_6 = concat_path(p0,v70_12_head);
      Space v72_7_result;
      for (int v72_7_label = 1; v72_7_label <= 2; ++v72_7_label) {
        const Space v72_7_tail = child(v70_12_tail,v72_7_label);
        if (v72_7_tail.empty()) continue;
        const Path v72_7_head{v72_7_label};
        const Space v73_2 = singleton(v72_7_head);
        const Space v73_3 = intersect(constant_14,v73_2);
        const Space v73_4 = (has_head(v73_3) ? constant_15 : Space{});
        const Space v73_5 = subtract(constant_0,v73_4);
        Space v73_8;
        if (!v73_5.empty()) {
          const Path v74_6 = concat_path(v72_6,v72_7_head);
          const Space v74_7 = routine_20(c, v74_6, v72_7_tail, s1);
          v73_8 = compose(v73_5,v74_7);
        }
        const Space v73_9 = intersect(constant_14,v73_2);
        const Space v73_10 = (has_head(v73_9) ? constant_15 : Space{});
        Space v73_12;
        if (!v73_10.empty()) {
          const Path v75_6 = concat_path(v72_6,v72_7_head);
          const Space v75_11 = routine_21(c, v75_6, v72_7_tail, s1);
          v73_12 = compose(v73_10,v75_11);
        }
        const Space v73_13 = unite(v73_8,v73_12);
        v72_7_result = unite(v72_7_result,v73_13);
      }
      const Space v72_7 = std::move(v72_7_result);
      v71_8 = compose(v71_5,v72_7);
    }
    const Space v71_9 = intersect(constant_14,v71_2);
    const Space v71_10 = (has_head(v71_9) ? constant_15 : Space{});
    Space v71_12;
    if (!v71_10.empty()) {
      const Path v76_6 = concat_path(p0,v70_12_head);
      Space v76_11_result;
      for (int v76_11_label = 1; v76_11_label <= 2; ++v76_11_label) {
        const Space v76_11_tail = child(v70_12_tail,v76_11_label);
        if (v76_11_tail.empty()) continue;
        const Path v76_11_head{v76_11_label};
        const Space v77_2 = singleton(v76_11_head);
        const Space v77_3 = intersect(constant_14,v77_2);
        const Space v77_4 = (has_head(v77_3) ? constant_15 : Space{});
        const Space v77_5 = subtract(constant_0,v77_4);
        Space v77_7;
        if (!v77_5.empty()) {
          const Space v78_6 = routine_22(c, v76_11_head, v76_6, v76_11_tail, s1);
          v77_7 = compose(v77_5,v78_6);
        }
        const Space v77_8 = intersect(constant_14,v77_2);
        const Space v77_9 = (has_head(v77_8) ? constant_15 : Space{});
        Space v77_11;
        if (!v77_9.empty()) {
          const Space v79_10 = routine_23(c, v76_11_head, v76_6, v76_11_tail, s1);
          v77_11 = compose(v77_9,v79_10);
        }
        const Space v77_12 = unite(v77_7,v77_11);
        v76_11_result = unite(v76_11_result,v77_12);
      }
      const Space v76_11 = std::move(v76_11_result);
      v71_12 = compose(v71_10,v76_11);
    }
    const Space v71_13 = unite(v71_8,v71_12);
    v70_12_result = unite(v70_12_result,v71_13);
  }
  const Space v70_12 = std::move(v70_12_result);
  return v70_12;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v80_12_result;
  for (int v80_12_label = 1; v80_12_label <= 2; ++v80_12_label) {
    const Space v80_12_tail = child(s0,v80_12_label);
    if (v80_12_tail.empty()) continue;
    const Path v80_12_head{v80_12_label};
    const Space v81_2 = singleton(v80_12_head);
    const Space v81_3 = intersect(constant_14,v81_2);
    const Space v81_4 = (has_head(v81_3) ? constant_15 : Space{});
    const Space v81_5 = subtract(constant_0,v81_4);
    Space v81_7;
    if (!v81_5.empty()) {
      Space v82_6_result;
      for (int v82_6_label = 1; v82_6_label <= 2; ++v82_6_label) {
        const Space v82_6_tail = child(v80_12_tail,v82_6_label);
        if (v82_6_tail.empty()) continue;
        const Path v82_6_head{v82_6_label};
        const Space v83_2 = singleton(v82_6_head);
        const Space v83_3 = intersect(constant_14,v83_2);
        const Space v83_4 = (has_head(v83_3) ? constant_15 : Space{});
        const Space v83_5 = subtract(constant_0,v83_4);
        Space v83_8;
        if (!v83_5.empty()) {
          const Path v84_6 = concat_path(v80_12_head,v82_6_head);
          const Space v84_7 = routine_24(c, v84_6, p0, v82_6_tail, s1);
          v83_8 = compose(v83_5,v84_7);
        }
        const Space v83_9 = intersect(constant_14,v83_2);
        const Space v83_10 = (has_head(v83_9) ? constant_15 : Space{});
        Space v83_12;
        if (!v83_10.empty()) {
          const Path v85_6 = concat_path(v80_12_head,v82_6_head);
          const Space v85_11 = routine_25(c, v85_6, p0, v82_6_tail, s1);
          v83_12 = compose(v83_10,v85_11);
        }
        const Space v83_13 = unite(v83_8,v83_12);
        v82_6_result = unite(v82_6_result,v83_13);
      }
      const Space v82_6 = std::move(v82_6_result);
      v81_7 = compose(v81_5,v82_6);
    }
    const Space v81_8 = intersect(constant_14,v81_2);
    const Space v81_9 = (has_head(v81_8) ? constant_15 : Space{});
    Space v81_11;
    if (!v81_9.empty()) {
      Space v86_10_result;
      for (int v86_10_label = 1; v86_10_label <= 2; ++v86_10_label) {
        const Space v86_10_tail = child(v80_12_tail,v86_10_label);
        if (v86_10_tail.empty()) continue;
        const Path v86_10_head{v86_10_label};
        const Space v87_2 = singleton(v86_10_head);
        const Space v87_3 = intersect(constant_14,v87_2);
        const Space v87_4 = (has_head(v87_3) ? constant_15 : Space{});
        const Space v87_5 = subtract(constant_0,v87_4);
        Space v87_8;
        if (!v87_5.empty()) {
          const Path v88_6 = concat_path(v80_12_head,v86_10_head);
          const Space v88_7 = routine_24(c, v88_6, p0, v86_10_tail, s1);
          v87_8 = compose(v87_5,v88_7);
        }
        const Space v87_9 = intersect(constant_14,v87_2);
        const Space v87_10 = (has_head(v87_9) ? constant_15 : Space{});
        Space v87_12;
        if (!v87_10.empty()) {
          const Path v89_6 = concat_path(v80_12_head,v86_10_head);
          const Space v89_11 = routine_26(c, v89_6, p0, v86_10_tail, s1);
          v87_12 = compose(v87_10,v89_11);
        }
        const Space v87_13 = unite(v87_8,v87_12);
        v86_10_result = unite(v86_10_result,v87_13);
      }
      const Space v86_10 = std::move(v86_10_result);
      v81_11 = compose(v81_9,v86_10);
    }
    const Space v81_12 = unite(v81_7,v81_11);
    v80_12_result = unite(v80_12_result,v81_12);
  }
  const Space v80_12 = std::move(v80_12_result);
  return v80_12;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0) {
  Space v90_11_result;
  for (int v90_11_label = 1; v90_11_label <= 2; ++v90_11_label) {
    const Space v90_11_tail = child(s0,v90_11_label);
    if (v90_11_tail.empty()) continue;
    const Path v90_11_head{v90_11_label};
    const Space v91_2 = singleton(v90_11_head);
    const Space v91_3 = intersect(constant_14,v91_2);
    const Space v91_4 = (has_head(v91_3) ? constant_15 : Space{});
    const Space v91_5 = subtract(constant_0,v91_4);
    Space v91_8;
    if (!v91_5.empty()) {
      const Path v92_6 = concat_path(p0,v90_11_head);
      Space v92_7_result;
      for (int v92_7_label = 1; v92_7_label <= 2; ++v92_7_label) {
        const Space v92_7_tail = child(v90_11_tail,v92_7_label);
        if (v92_7_tail.empty()) continue;
        const Path v92_7_head{v92_7_label};
        const Space v93_2 = singleton(v92_7_head);
        const Space v93_3 = intersect(constant_14,v93_2);
        const Space v93_4 = (has_head(v93_3) ? constant_15 : Space{});
        const Space v93_5 = subtract(constant_0,v93_4);
        Space v93_8;
        if (!v93_5.empty()) {
          const Path v94_6 = concat_path(v92_6,v92_7_head);
          const Space v94_7 = routine_27(c, v94_6, v92_7_tail);
          v93_8 = compose(v93_5,v94_7);
        }
        const Space v93_9 = intersect(constant_14,v93_2);
        const Space v93_10 = (has_head(v93_9) ? constant_15 : Space{});
        Space v93_12;
        if (!v93_10.empty()) {
          const Path v95_6 = concat_path(v92_6,v92_7_head);
          const Space v95_11 = routine_28(c, v95_6, v92_7_tail);
          v93_12 = compose(v93_10,v95_11);
        }
        const Space v93_13 = unite(v93_8,v93_12);
        v92_7_result = unite(v92_7_result,v93_13);
      }
      const Space v92_7 = std::move(v92_7_result);
      v91_8 = compose(v91_5,v92_7);
    }
    const Space v91_9 = intersect(constant_14,v91_2);
    const Space v91_10 = (has_head(v91_9) ? constant_15 : Space{});
    Space v91_12;
    if (!v91_10.empty()) {
      const Path v96_6 = concat_path(p0,v90_11_head);
      Space v96_11_result;
      for (int v96_11_label = 1; v96_11_label <= 2; ++v96_11_label) {
        const Space v96_11_tail = child(v90_11_tail,v96_11_label);
        if (v96_11_tail.empty()) continue;
        const Path v96_11_head{v96_11_label};
        const Space v97_2 = singleton(v96_11_head);
        const Space v97_3 = intersect(constant_14,v97_2);
        const Space v97_4 = (has_head(v97_3) ? constant_15 : Space{});
        const Space v97_5 = subtract(constant_0,v97_4);
        Space v97_8;
        if (!v97_5.empty()) {
          const Path v98_6 = concat_path(v96_6,v96_11_head);
          const Space v98_7 = routine_27(c, v98_6, v96_11_tail);
          v97_8 = compose(v97_5,v98_7);
        }
        const Space v97_9 = intersect(constant_14,v97_2);
        const Space v97_10 = (has_head(v97_9) ? constant_15 : Space{});
        Space v97_12;
        if (!v97_10.empty()) {
          const Path v99_6 = concat_path(v96_6,v96_11_head);
          const Space v99_11 = routine_8(c, v99_6, v96_11_tail);
          v97_12 = compose(v97_10,v99_11);
        }
        const Space v97_13 = unite(v97_8,v97_12);
        v96_11_result = unite(v96_11_result,v97_13);
      }
      const Space v96_11 = std::move(v96_11_result);
      v91_12 = compose(v91_10,v96_11);
    }
    const Space v91_13 = unite(v91_8,v91_12);
    v90_11_result = unite(v90_11_result,v91_13);
  }
  const Space v90_11 = std::move(v90_11_result);
  return v90_11;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0) {
  Space v100_11_result;
  for (int v100_11_label = 1; v100_11_label <= 2; ++v100_11_label) {
    const Space v100_11_tail = child(s0,v100_11_label);
    if (v100_11_tail.empty()) continue;
    const Path v100_11_head{v100_11_label};
    const Space v101_2 = singleton(v100_11_head);
    const Space v101_3 = intersect(constant_14,v101_2);
    const Space v101_4 = (has_head(v101_3) ? constant_15 : Space{});
    const Space v101_5 = subtract(constant_0,v101_4);
    Space v101_8;
    if (!v101_5.empty()) {
      const Path v102_6 = concat_path(p0,v100_11_head);
      Space v102_7_result;
      for (int v102_7_label = 1; v102_7_label <= 2; ++v102_7_label) {
        const Space v102_7_tail = child(v100_11_tail,v102_7_label);
        if (v102_7_tail.empty()) continue;
        const Path v102_7_head{v102_7_label};
        const Space v103_2 = singleton(v102_7_head);
        const Space v103_3 = intersect(constant_14,v103_2);
        const Space v103_4 = (has_head(v103_3) ? constant_15 : Space{});
        const Space v103_5 = subtract(constant_0,v103_4);
        Space v103_8;
        if (!v103_5.empty()) {
          const Path v104_6 = concat_path(v102_6,v102_7_head);
          const Space v104_7 = routine_27(c, v104_6, v102_7_tail);
          v103_8 = compose(v103_5,v104_7);
        }
        const Space v103_9 = intersect(constant_14,v103_2);
        const Space v103_10 = (has_head(v103_9) ? constant_15 : Space{});
        Space v103_12;
        if (!v103_10.empty()) {
          const Path v105_6 = concat_path(v102_6,v102_7_head);
          const Space v105_11 = routine_28(c, v105_6, v102_7_tail);
          v103_12 = compose(v103_10,v105_11);
        }
        const Space v103_13 = unite(v103_8,v103_12);
        v102_7_result = unite(v102_7_result,v103_13);
      }
      const Space v102_7 = std::move(v102_7_result);
      v101_8 = compose(v101_5,v102_7);
    }
    const Space v101_9 = intersect(constant_14,v101_2);
    const Space v101_10 = (has_head(v101_9) ? constant_15 : Space{});
    Space v101_12;
    if (!v101_10.empty()) {
      const Path v106_6 = concat_path(p0,v100_11_head);
      Space v106_11_result;
      for (int v106_11_label = 1; v106_11_label <= 2; ++v106_11_label) {
        const Space v106_11_tail = child(v100_11_tail,v106_11_label);
        if (v106_11_tail.empty()) continue;
        const Path v106_11_head{v106_11_label};
        const Space v107_2 = singleton(v106_11_head);
        const Space v107_3 = intersect(constant_14,v107_2);
        const Space v107_4 = (has_head(v107_3) ? constant_15 : Space{});
        const Space v107_5 = subtract(constant_0,v107_4);
        Space v107_7;
        if (!v107_5.empty()) {
          const Space v108_6 = routine_29(c, v106_11_head, v106_6, v106_11_tail);
          v107_7 = compose(v107_5,v108_6);
        }
        const Space v107_8 = intersect(constant_14,v107_2);
        const Space v107_9 = (has_head(v107_8) ? constant_15 : Space{});
        Space v107_11;
        if (!v107_9.empty()) {
          const Space v109_10 = routine_30(c, v106_11_head, v106_6, v106_11_tail);
          v107_11 = compose(v107_9,v109_10);
        }
        const Space v107_12 = unite(v107_7,v107_11);
        v106_11_result = unite(v106_11_result,v107_12);
      }
      const Space v106_11 = std::move(v106_11_result);
      v101_12 = compose(v101_10,v106_11);
    }
    const Space v101_13 = unite(v101_8,v101_12);
    v100_11_result = unite(v100_11_result,v101_13);
  }
  const Space v100_11 = std::move(v100_11_result);
  return v100_11;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0) {
  Space v110_11_result;
  for (int v110_11_label = 1; v110_11_label <= 2; ++v110_11_label) {
    const Space v110_11_tail = child(s0,v110_11_label);
    if (v110_11_tail.empty()) continue;
    const Path v110_11_head{v110_11_label};
    const Space v111_2 = singleton(v110_11_head);
    const Space v111_3 = intersect(constant_14,v111_2);
    const Space v111_4 = (has_head(v111_3) ? constant_15 : Space{});
    const Space v111_5 = subtract(constant_0,v111_4);
    Space v111_7;
    if (!v111_5.empty()) {
      Space v112_6_result;
      for (int v112_6_label = 1; v112_6_label <= 2; ++v112_6_label) {
        const Space v112_6_tail = child(v110_11_tail,v112_6_label);
        if (v112_6_tail.empty()) continue;
        const Path v112_6_head{v112_6_label};
        const Space v113_2 = singleton(v112_6_head);
        const Space v113_3 = intersect(constant_14,v113_2);
        const Space v113_4 = (has_head(v113_3) ? constant_15 : Space{});
        const Space v113_5 = subtract(constant_0,v113_4);
        Space v113_8;
        if (!v113_5.empty()) {
          const Path v114_6 = concat_path(v110_11_head,v112_6_head);
          const Space v114_7 = routine_31(c, v114_6, p0, v112_6_tail);
          v113_8 = compose(v113_5,v114_7);
        }
        const Space v113_9 = intersect(constant_14,v113_2);
        const Space v113_10 = (has_head(v113_9) ? constant_15 : Space{});
        Space v113_12;
        if (!v113_10.empty()) {
          const Path v115_6 = concat_path(v110_11_head,v112_6_head);
          const Space v115_11 = routine_32(c, v115_6, p0, v112_6_tail);
          v113_12 = compose(v113_10,v115_11);
        }
        const Space v113_13 = unite(v113_8,v113_12);
        v112_6_result = unite(v112_6_result,v113_13);
      }
      const Space v112_6 = std::move(v112_6_result);
      v111_7 = compose(v111_5,v112_6);
    }
    const Space v111_8 = intersect(constant_14,v111_2);
    const Space v111_9 = (has_head(v111_8) ? constant_15 : Space{});
    Space v111_11;
    if (!v111_9.empty()) {
      Space v116_10_result;
      for (int v116_10_label = 1; v116_10_label <= 2; ++v116_10_label) {
        const Space v116_10_tail = child(v110_11_tail,v116_10_label);
        if (v116_10_tail.empty()) continue;
        const Path v116_10_head{v116_10_label};
        const Space v117_2 = singleton(v116_10_head);
        const Space v117_3 = intersect(constant_14,v117_2);
        const Space v117_4 = (has_head(v117_3) ? constant_15 : Space{});
        const Space v117_5 = subtract(constant_0,v117_4);
        Space v117_8;
        if (!v117_5.empty()) {
          const Path v118_6 = concat_path(v110_11_head,v116_10_head);
          const Space v118_7 = routine_31(c, v118_6, p0, v116_10_tail);
          v117_8 = compose(v117_5,v118_7);
        }
        const Space v117_9 = intersect(constant_14,v117_2);
        const Space v117_10 = (has_head(v117_9) ? constant_15 : Space{});
        Space v117_12;
        if (!v117_10.empty()) {
          const Path v119_6 = concat_path(v110_11_head,v116_10_head);
          const Space v119_11 = routine_33(c, v119_6, p0, v116_10_tail);
          v117_12 = compose(v117_10,v119_11);
        }
        const Space v117_13 = unite(v117_8,v117_12);
        v116_10_result = unite(v116_10_result,v117_13);
      }
      const Space v116_10 = std::move(v116_10_result);
      v111_11 = compose(v111_9,v116_10);
    }
    const Space v111_12 = unite(v111_7,v111_11);
    v110_11_result = unite(v110_11_result,v111_12);
  }
  const Space v110_11 = std::move(v110_11_result);
  return v110_11;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v120_12_result;
  for (int v120_12_label = 1; v120_12_label <= 2; ++v120_12_label) {
    const Space v120_12_tail = child(s0,v120_12_label);
    if (v120_12_tail.empty()) continue;
    const Path v120_12_head{v120_12_label};
    const Space v121_2 = singleton(v120_12_head);
    const Space v121_3 = intersect(constant_14,v121_2);
    const Space v121_4 = (has_head(v121_3) ? constant_15 : Space{});
    const Space v121_5 = subtract(constant_0,v121_4);
    Space v121_8;
    if (!v121_5.empty()) {
      const Path v122_6 = concat_path(p0,v120_12_head);
      Space v122_7_result;
      for (int v122_7_label = 1; v122_7_label <= 2; ++v122_7_label) {
        const Space v122_7_tail = child(v120_12_tail,v122_7_label);
        if (v122_7_tail.empty()) continue;
        const Path v122_7_head{v122_7_label};
        const Space v123_2 = singleton(v122_7_head);
        const Space v123_3 = intersect(constant_14,v123_2);
        const Space v123_4 = (has_head(v123_3) ? constant_15 : Space{});
        const Space v123_5 = subtract(constant_0,v123_4);
        Space v123_8;
        if (!v123_5.empty()) {
          const Path v124_6 = concat_path(v122_6,v122_7_head);
          const Space v124_7 = routine_34(c, v124_6, v122_7_tail, s1);
          v123_8 = compose(v123_5,v124_7);
        }
        const Space v123_9 = intersect(constant_14,v123_2);
        const Space v123_10 = (has_head(v123_9) ? constant_15 : Space{});
        Space v123_12;
        if (!v123_10.empty()) {
          const Path v125_6 = concat_path(v122_6,v122_7_head);
          const Space v125_11 = routine_35(c, v125_6, v122_7_tail, s1);
          v123_12 = compose(v123_10,v125_11);
        }
        const Space v123_13 = unite(v123_8,v123_12);
        v122_7_result = unite(v122_7_result,v123_13);
      }
      const Space v122_7 = std::move(v122_7_result);
      v121_8 = compose(v121_5,v122_7);
    }
    const Space v121_9 = intersect(constant_14,v121_2);
    const Space v121_10 = (has_head(v121_9) ? constant_15 : Space{});
    Space v121_12;
    if (!v121_10.empty()) {
      const Path v126_6 = concat_path(p0,v120_12_head);
      Space v126_11_result;
      for (int v126_11_label = 1; v126_11_label <= 2; ++v126_11_label) {
        const Space v126_11_tail = child(v120_12_tail,v126_11_label);
        if (v126_11_tail.empty()) continue;
        const Path v126_11_head{v126_11_label};
        const Space v127_2 = singleton(v126_11_head);
        const Space v127_3 = intersect(constant_14,v127_2);
        const Space v127_4 = (has_head(v127_3) ? constant_15 : Space{});
        const Space v127_5 = subtract(constant_0,v127_4);
        Space v127_8;
        if (!v127_5.empty()) {
          const Path v128_6 = concat_path(v126_6,v126_11_head);
          const Space v128_7 = routine_34(c, v128_6, v126_11_tail, s1);
          v127_8 = compose(v127_5,v128_7);
        }
        const Space v127_9 = intersect(constant_14,v127_2);
        const Space v127_10 = (has_head(v127_9) ? constant_15 : Space{});
        Space v127_12;
        if (!v127_10.empty()) {
          const Path v129_6 = concat_path(v126_6,v126_11_head);
          const Space v129_11 = routine_11(c, v129_6, v126_11_tail, s1);
          v127_12 = compose(v127_10,v129_11);
        }
        const Space v127_13 = unite(v127_8,v127_12);
        v126_11_result = unite(v126_11_result,v127_13);
      }
      const Space v126_11 = std::move(v126_11_result);
      v121_12 = compose(v121_10,v126_11);
    }
    const Space v121_13 = unite(v121_8,v121_12);
    v120_12_result = unite(v120_12_result,v121_13);
  }
  const Space v120_12 = std::move(v120_12_result);
  return v120_12;
}

static Space routine_10(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v130_12_result;
  for (int v130_12_label = 1; v130_12_label <= 2; ++v130_12_label) {
    const Space v130_12_tail = child(s0,v130_12_label);
    if (v130_12_tail.empty()) continue;
    const Path v130_12_head{v130_12_label};
    const Space v131_2 = singleton(v130_12_head);
    const Space v131_3 = intersect(constant_14,v131_2);
    const Space v131_4 = (has_head(v131_3) ? constant_15 : Space{});
    const Space v131_5 = subtract(constant_0,v131_4);
    Space v131_8;
    if (!v131_5.empty()) {
      const Path v132_6 = concat_path(p0,v130_12_head);
      Space v132_7_result;
      for (int v132_7_label = 1; v132_7_label <= 2; ++v132_7_label) {
        const Space v132_7_tail = child(v130_12_tail,v132_7_label);
        if (v132_7_tail.empty()) continue;
        const Path v132_7_head{v132_7_label};
        const Space v133_2 = singleton(v132_7_head);
        const Space v133_3 = intersect(constant_14,v133_2);
        const Space v133_4 = (has_head(v133_3) ? constant_15 : Space{});
        const Space v133_5 = subtract(constant_0,v133_4);
        Space v133_8;
        if (!v133_5.empty()) {
          const Path v134_6 = concat_path(v132_6,v132_7_head);
          const Space v134_7 = routine_34(c, v134_6, v132_7_tail, s1);
          v133_8 = compose(v133_5,v134_7);
        }
        const Space v133_9 = intersect(constant_14,v133_2);
        const Space v133_10 = (has_head(v133_9) ? constant_15 : Space{});
        Space v133_12;
        if (!v133_10.empty()) {
          const Path v135_6 = concat_path(v132_6,v132_7_head);
          const Space v135_11 = routine_35(c, v135_6, v132_7_tail, s1);
          v133_12 = compose(v133_10,v135_11);
        }
        const Space v133_13 = unite(v133_8,v133_12);
        v132_7_result = unite(v132_7_result,v133_13);
      }
      const Space v132_7 = std::move(v132_7_result);
      v131_8 = compose(v131_5,v132_7);
    }
    const Space v131_9 = intersect(constant_14,v131_2);
    const Space v131_10 = (has_head(v131_9) ? constant_15 : Space{});
    Space v131_12;
    if (!v131_10.empty()) {
      const Path v136_6 = concat_path(p0,v130_12_head);
      Space v136_11_result;
      for (int v136_11_label = 1; v136_11_label <= 2; ++v136_11_label) {
        const Space v136_11_tail = child(v130_12_tail,v136_11_label);
        if (v136_11_tail.empty()) continue;
        const Path v136_11_head{v136_11_label};
        const Space v137_2 = singleton(v136_11_head);
        const Space v137_3 = intersect(constant_14,v137_2);
        const Space v137_4 = (has_head(v137_3) ? constant_15 : Space{});
        const Space v137_5 = subtract(constant_0,v137_4);
        Space v137_7;
        if (!v137_5.empty()) {
          const Space v138_6 = routine_36(c, v136_11_head, v136_6, v136_11_tail, s1);
          v137_7 = compose(v137_5,v138_6);
        }
        const Space v137_8 = intersect(constant_14,v137_2);
        const Space v137_9 = (has_head(v137_8) ? constant_15 : Space{});
        Space v137_11;
        if (!v137_9.empty()) {
          const Space v139_10 = routine_37(c, v136_11_head, v136_6, v136_11_tail, s1);
          v137_11 = compose(v137_9,v139_10);
        }
        const Space v137_12 = unite(v137_7,v137_11);
        v136_11_result = unite(v136_11_result,v137_12);
      }
      const Space v136_11 = std::move(v136_11_result);
      v131_12 = compose(v131_10,v136_11);
    }
    const Space v131_13 = unite(v131_8,v131_12);
    v130_12_result = unite(v130_12_result,v131_13);
  }
  const Space v130_12 = std::move(v130_12_result);
  return v130_12;
}

static Space routine_11(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v140_12_result;
  for (int v140_12_label = 1; v140_12_label <= 2; ++v140_12_label) {
    const Space v140_12_tail = child(s0,v140_12_label);
    if (v140_12_tail.empty()) continue;
    const Path v140_12_head{v140_12_label};
    const Space v141_2 = singleton(v140_12_head);
    const Space v141_3 = intersect(constant_14,v141_2);
    const Space v141_4 = (has_head(v141_3) ? constant_15 : Space{});
    const Space v141_5 = subtract(constant_0,v141_4);
    Space v141_7;
    if (!v141_5.empty()) {
      Space v142_6_result;
      for (int v142_6_label = 1; v142_6_label <= 2; ++v142_6_label) {
        const Space v142_6_tail = child(v140_12_tail,v142_6_label);
        if (v142_6_tail.empty()) continue;
        const Path v142_6_head{v142_6_label};
        const Space v143_2 = singleton(v142_6_head);
        const Space v143_3 = intersect(constant_14,v143_2);
        const Space v143_4 = (has_head(v143_3) ? constant_15 : Space{});
        const Space v143_5 = subtract(constant_0,v143_4);
        Space v143_8;
        if (!v143_5.empty()) {
          const Path v144_6 = concat_path(v140_12_head,v142_6_head);
          const Space v144_7 = routine_38(c, v144_6, p0, v142_6_tail, s1);
          v143_8 = compose(v143_5,v144_7);
        }
        const Space v143_9 = intersect(constant_14,v143_2);
        const Space v143_10 = (has_head(v143_9) ? constant_15 : Space{});
        Space v143_12;
        if (!v143_10.empty()) {
          const Path v145_6 = concat_path(v140_12_head,v142_6_head);
          const Space v145_11 = routine_39(c, v145_6, p0, v142_6_tail, s1);
          v143_12 = compose(v143_10,v145_11);
        }
        const Space v143_13 = unite(v143_8,v143_12);
        v142_6_result = unite(v142_6_result,v143_13);
      }
      const Space v142_6 = std::move(v142_6_result);
      v141_7 = compose(v141_5,v142_6);
    }
    const Space v141_8 = intersect(constant_14,v141_2);
    const Space v141_9 = (has_head(v141_8) ? constant_15 : Space{});
    Space v141_11;
    if (!v141_9.empty()) {
      Space v146_10_result;
      for (int v146_10_label = 1; v146_10_label <= 2; ++v146_10_label) {
        const Space v146_10_tail = child(v140_12_tail,v146_10_label);
        if (v146_10_tail.empty()) continue;
        const Path v146_10_head{v146_10_label};
        const Space v147_2 = singleton(v146_10_head);
        const Space v147_3 = intersect(constant_14,v147_2);
        const Space v147_4 = (has_head(v147_3) ? constant_15 : Space{});
        const Space v147_5 = subtract(constant_0,v147_4);
        Space v147_8;
        if (!v147_5.empty()) {
          const Path v148_6 = concat_path(v140_12_head,v146_10_head);
          const Space v148_7 = routine_38(c, v148_6, p0, v146_10_tail, s1);
          v147_8 = compose(v147_5,v148_7);
        }
        const Space v147_9 = intersect(constant_14,v147_2);
        const Space v147_10 = (has_head(v147_9) ? constant_15 : Space{});
        Space v147_12;
        if (!v147_10.empty()) {
          const Path v149_6 = concat_path(v140_12_head,v146_10_head);
          const Space v149_11 = routine_40(c, v149_6, p0, v146_10_tail, s1);
          v147_12 = compose(v147_10,v149_11);
        }
        const Space v147_13 = unite(v147_8,v147_12);
        v146_10_result = unite(v146_10_result,v147_13);
      }
      const Space v146_10 = std::move(v146_10_result);
      v141_11 = compose(v141_9,v146_10);
    }
    const Space v141_12 = unite(v141_7,v141_11);
    v140_12_result = unite(v140_12_result,v141_12);
  }
  const Space v140_12 = std::move(v140_12_result);
  return v140_12;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v150_12_result;
  for (int v150_12_label = 1; v150_12_label <= 2; ++v150_12_label) {
    const Space v150_12_tail = child(s0,v150_12_label);
    if (v150_12_tail.empty()) continue;
    const Path v150_12_head{v150_12_label};
    const Space v151_2 = singleton(v150_12_head);
    const Space v151_3 = intersect(constant_14,v151_2);
    const Space v151_4 = (has_head(v151_3) ? constant_15 : Space{});
    const Space v151_5 = subtract(constant_0,v151_4);
    Space v151_8;
    if (!v151_5.empty()) {
      const Path v152_6 = concat_path(p0,v150_12_head);
      Space v152_7_result;
      for (int v152_7_label = 1; v152_7_label <= 2; ++v152_7_label) {
        const Space v152_7_tail = child(v150_12_tail,v152_7_label);
        if (v152_7_tail.empty()) continue;
        const Path v152_7_head{v152_7_label};
        const Space v153_2 = singleton(v152_7_head);
        const Space v153_3 = intersect(constant_14,v153_2);
        const Space v153_4 = (has_head(v153_3) ? constant_15 : Space{});
        const Space v153_5 = subtract(constant_0,v153_4);
        Space v153_8;
        if (!v153_5.empty()) {
          const Path v154_6 = concat_path(v152_6,v152_7_head);
          const Space v154_7 = routine_41(c, v154_6, v152_7_tail, s1);
          v153_8 = compose(v153_5,v154_7);
        }
        const Space v153_9 = intersect(constant_14,v153_2);
        const Space v153_10 = (has_head(v153_9) ? constant_15 : Space{});
        Space v153_12;
        if (!v153_10.empty()) {
          const Path v155_6 = concat_path(v152_6,v152_7_head);
          const Space v155_11 = routine_42(c, v155_6, v152_7_tail, s1);
          v153_12 = compose(v153_10,v155_11);
        }
        const Space v153_13 = unite(v153_8,v153_12);
        v152_7_result = unite(v152_7_result,v153_13);
      }
      const Space v152_7 = std::move(v152_7_result);
      v151_8 = compose(v151_5,v152_7);
    }
    const Space v151_9 = intersect(constant_14,v151_2);
    const Space v151_10 = (has_head(v151_9) ? constant_15 : Space{});
    Space v151_12;
    if (!v151_10.empty()) {
      const Path v156_6 = concat_path(p0,v150_12_head);
      Space v156_11_result;
      for (int v156_11_label = 1; v156_11_label <= 2; ++v156_11_label) {
        const Space v156_11_tail = child(v150_12_tail,v156_11_label);
        if (v156_11_tail.empty()) continue;
        const Path v156_11_head{v156_11_label};
        const Space v157_2 = singleton(v156_11_head);
        const Space v157_3 = intersect(constant_14,v157_2);
        const Space v157_4 = (has_head(v157_3) ? constant_15 : Space{});
        const Space v157_5 = subtract(constant_0,v157_4);
        Space v157_8;
        if (!v157_5.empty()) {
          const Path v158_6 = concat_path(v156_6,v156_11_head);
          const Space v158_7 = routine_41(c, v158_6, v156_11_tail, s1);
          v157_8 = compose(v157_5,v158_7);
        }
        const Space v157_9 = intersect(constant_14,v157_2);
        const Space v157_10 = (has_head(v157_9) ? constant_15 : Space{});
        Space v157_12;
        if (!v157_10.empty()) {
          const Path v159_6 = concat_path(v156_6,v156_11_head);
          const Space v159_11 = routine_14(c, v159_6, v156_11_tail, s1);
          v157_12 = compose(v157_10,v159_11);
        }
        const Space v157_13 = unite(v157_8,v157_12);
        v156_11_result = unite(v156_11_result,v157_13);
      }
      const Space v156_11 = std::move(v156_11_result);
      v151_12 = compose(v151_10,v156_11);
    }
    const Space v151_13 = unite(v151_8,v151_12);
    v150_12_result = unite(v150_12_result,v151_13);
  }
  const Space v150_12 = std::move(v150_12_result);
  return v150_12;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v160_12_result;
  for (int v160_12_label = 1; v160_12_label <= 2; ++v160_12_label) {
    const Space v160_12_tail = child(s0,v160_12_label);
    if (v160_12_tail.empty()) continue;
    const Path v160_12_head{v160_12_label};
    const Space v161_2 = singleton(v160_12_head);
    const Space v161_3 = intersect(constant_14,v161_2);
    const Space v161_4 = (has_head(v161_3) ? constant_15 : Space{});
    const Space v161_5 = subtract(constant_0,v161_4);
    Space v161_8;
    if (!v161_5.empty()) {
      const Path v162_6 = concat_path(p0,v160_12_head);
      Space v162_7_result;
      for (int v162_7_label = 1; v162_7_label <= 2; ++v162_7_label) {
        const Space v162_7_tail = child(v160_12_tail,v162_7_label);
        if (v162_7_tail.empty()) continue;
        const Path v162_7_head{v162_7_label};
        const Space v163_2 = singleton(v162_7_head);
        const Space v163_3 = intersect(constant_14,v163_2);
        const Space v163_4 = (has_head(v163_3) ? constant_15 : Space{});
        const Space v163_5 = subtract(constant_0,v163_4);
        Space v163_8;
        if (!v163_5.empty()) {
          const Path v164_6 = concat_path(v162_6,v162_7_head);
          const Space v164_7 = routine_41(c, v164_6, v162_7_tail, s1);
          v163_8 = compose(v163_5,v164_7);
        }
        const Space v163_9 = intersect(constant_14,v163_2);
        const Space v163_10 = (has_head(v163_9) ? constant_15 : Space{});
        Space v163_12;
        if (!v163_10.empty()) {
          const Path v165_6 = concat_path(v162_6,v162_7_head);
          const Space v165_11 = routine_42(c, v165_6, v162_7_tail, s1);
          v163_12 = compose(v163_10,v165_11);
        }
        const Space v163_13 = unite(v163_8,v163_12);
        v162_7_result = unite(v162_7_result,v163_13);
      }
      const Space v162_7 = std::move(v162_7_result);
      v161_8 = compose(v161_5,v162_7);
    }
    const Space v161_9 = intersect(constant_14,v161_2);
    const Space v161_10 = (has_head(v161_9) ? constant_15 : Space{});
    Space v161_12;
    if (!v161_10.empty()) {
      const Path v166_6 = concat_path(p0,v160_12_head);
      Space v166_11_result;
      for (int v166_11_label = 1; v166_11_label <= 2; ++v166_11_label) {
        const Space v166_11_tail = child(v160_12_tail,v166_11_label);
        if (v166_11_tail.empty()) continue;
        const Path v166_11_head{v166_11_label};
        const Space v167_2 = singleton(v166_11_head);
        const Space v167_3 = intersect(constant_14,v167_2);
        const Space v167_4 = (has_head(v167_3) ? constant_15 : Space{});
        const Space v167_5 = subtract(constant_0,v167_4);
        Space v167_7;
        if (!v167_5.empty()) {
          const Space v168_6 = routine_43(c, v166_11_head, v166_6, v166_11_tail, s1);
          v167_7 = compose(v167_5,v168_6);
        }
        const Space v167_8 = intersect(constant_14,v167_2);
        const Space v167_9 = (has_head(v167_8) ? constant_15 : Space{});
        Space v167_11;
        if (!v167_9.empty()) {
          const Space v169_10 = routine_44(c, v166_11_head, v166_6, v166_11_tail, s1);
          v167_11 = compose(v167_9,v169_10);
        }
        const Space v167_12 = unite(v167_7,v167_11);
        v166_11_result = unite(v166_11_result,v167_12);
      }
      const Space v166_11 = std::move(v166_11_result);
      v161_12 = compose(v161_10,v166_11);
    }
    const Space v161_13 = unite(v161_8,v161_12);
    v160_12_result = unite(v160_12_result,v161_13);
  }
  const Space v160_12 = std::move(v160_12_result);
  return v160_12;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v170_12_result;
  for (int v170_12_label = 1; v170_12_label <= 2; ++v170_12_label) {
    const Space v170_12_tail = child(s0,v170_12_label);
    if (v170_12_tail.empty()) continue;
    const Path v170_12_head{v170_12_label};
    const Space v171_2 = singleton(v170_12_head);
    const Space v171_3 = intersect(constant_14,v171_2);
    const Space v171_4 = (has_head(v171_3) ? constant_15 : Space{});
    const Space v171_5 = subtract(constant_0,v171_4);
    Space v171_7;
    if (!v171_5.empty()) {
      Space v172_6_result;
      for (int v172_6_label = 1; v172_6_label <= 2; ++v172_6_label) {
        const Space v172_6_tail = child(v170_12_tail,v172_6_label);
        if (v172_6_tail.empty()) continue;
        const Path v172_6_head{v172_6_label};
        const Space v173_2 = singleton(v172_6_head);
        const Space v173_3 = intersect(constant_14,v173_2);
        const Space v173_4 = (has_head(v173_3) ? constant_15 : Space{});
        const Space v173_5 = subtract(constant_0,v173_4);
        Space v173_8;
        if (!v173_5.empty()) {
          const Path v174_6 = concat_path(v170_12_head,v172_6_head);
          const Space v174_7 = routine_45(c, v174_6, p0, v172_6_tail, s1);
          v173_8 = compose(v173_5,v174_7);
        }
        const Space v173_9 = intersect(constant_14,v173_2);
        const Space v173_10 = (has_head(v173_9) ? constant_15 : Space{});
        Space v173_12;
        if (!v173_10.empty()) {
          const Path v175_6 = concat_path(v170_12_head,v172_6_head);
          const Space v175_11 = routine_46(c, v175_6, p0, v172_6_tail, s1);
          v173_12 = compose(v173_10,v175_11);
        }
        const Space v173_13 = unite(v173_8,v173_12);
        v172_6_result = unite(v172_6_result,v173_13);
      }
      const Space v172_6 = std::move(v172_6_result);
      v171_7 = compose(v171_5,v172_6);
    }
    const Space v171_8 = intersect(constant_14,v171_2);
    const Space v171_9 = (has_head(v171_8) ? constant_15 : Space{});
    Space v171_11;
    if (!v171_9.empty()) {
      Space v176_10_result;
      for (int v176_10_label = 1; v176_10_label <= 2; ++v176_10_label) {
        const Space v176_10_tail = child(v170_12_tail,v176_10_label);
        if (v176_10_tail.empty()) continue;
        const Path v176_10_head{v176_10_label};
        const Space v177_2 = singleton(v176_10_head);
        const Space v177_3 = intersect(constant_14,v177_2);
        const Space v177_4 = (has_head(v177_3) ? constant_15 : Space{});
        const Space v177_5 = subtract(constant_0,v177_4);
        Space v177_8;
        if (!v177_5.empty()) {
          const Path v178_6 = concat_path(v170_12_head,v176_10_head);
          const Space v178_7 = routine_45(c, v178_6, p0, v176_10_tail, s1);
          v177_8 = compose(v177_5,v178_7);
        }
        const Space v177_9 = intersect(constant_14,v177_2);
        const Space v177_10 = (has_head(v177_9) ? constant_15 : Space{});
        Space v177_12;
        if (!v177_10.empty()) {
          const Path v179_6 = concat_path(v170_12_head,v176_10_head);
          const Space v179_11 = routine_47(c, v179_6, p0, v176_10_tail, s1);
          v177_12 = compose(v177_10,v179_11);
        }
        const Space v177_13 = unite(v177_8,v177_12);
        v176_10_result = unite(v176_10_result,v177_13);
      }
      const Space v176_10 = std::move(v176_10_result);
      v171_11 = compose(v171_9,v176_10);
    }
    const Space v171_12 = unite(v171_7,v171_11);
    v170_12_result = unite(v170_12_result,v171_12);
  }
  const Space v170_12 = std::move(v170_12_result);
  return v170_12;
}

static Space routine_15(Context& c, const Path& p0, const Space& s0) {
  Space v180_11_result;
  for (int v180_11_label = 1; v180_11_label <= 2; ++v180_11_label) {
    const Space v180_11_tail = child(s0,v180_11_label);
    if (v180_11_tail.empty()) continue;
    const Path v180_11_head{v180_11_label};
    const Space v181_2 = singleton(v180_11_head);
    const Space v181_3 = intersect(constant_14,v181_2);
    const Space v181_4 = (has_head(v181_3) ? constant_15 : Space{});
    const Space v181_5 = subtract(constant_0,v181_4);
    Space v181_8;
    if (!v181_5.empty()) {
      const Path v182_6 = concat_path(p0,v180_11_head);
      Space v182_7_result;
      for (int v182_7_label = 1; v182_7_label <= 2; ++v182_7_label) {
        const Space v182_7_tail = child(v180_11_tail,v182_7_label);
        if (v182_7_tail.empty()) continue;
        const Path v182_7_head{v182_7_label};
        const Space v183_2 = singleton(v182_7_head);
        const Space v183_3 = intersect(constant_14,v183_2);
        const Space v183_4 = (has_head(v183_3) ? constant_15 : Space{});
        const Space v183_5 = subtract(constant_0,v183_4);
        Space v183_8;
        if (!v183_5.empty()) {
          const Path v184_6 = concat_path(v182_6,v182_7_head);
          const Space v184_7 = routine_48(c, v184_6, v182_7_tail);
          v183_8 = compose(v183_5,v184_7);
        }
        const Space v183_9 = intersect(constant_14,v183_2);
        const Space v183_10 = (has_head(v183_9) ? constant_15 : Space{});
        Space v183_12;
        if (!v183_10.empty()) {
          const Path v185_6 = concat_path(v182_6,v182_7_head);
          const Space v185_11 = routine_49(c, v185_6, v182_7_tail);
          v183_12 = compose(v183_10,v185_11);
        }
        const Space v183_13 = unite(v183_8,v183_12);
        v182_7_result = unite(v182_7_result,v183_13);
      }
      const Space v182_7 = std::move(v182_7_result);
      v181_8 = compose(v181_5,v182_7);
    }
    const Space v181_9 = intersect(constant_14,v181_2);
    const Space v181_10 = (has_head(v181_9) ? constant_15 : Space{});
    Space v181_12;
    if (!v181_10.empty()) {
      const Path v186_6 = concat_path(p0,v180_11_head);
      Space v186_11_result;
      for (int v186_11_label = 1; v186_11_label <= 2; ++v186_11_label) {
        const Space v186_11_tail = child(v180_11_tail,v186_11_label);
        if (v186_11_tail.empty()) continue;
        const Path v186_11_head{v186_11_label};
        const Space v187_2 = singleton(v186_11_head);
        const Space v187_3 = intersect(constant_14,v187_2);
        const Space v187_4 = (has_head(v187_3) ? constant_15 : Space{});
        const Space v187_5 = subtract(constant_0,v187_4);
        Space v187_8;
        if (!v187_5.empty()) {
          const Path v188_6 = concat_path(v186_6,v186_11_head);
          const Space v188_7 = routine_48(c, v188_6, v186_11_tail);
          v187_8 = compose(v187_5,v188_7);
        }
        const Space v187_9 = intersect(constant_14,v187_2);
        const Space v187_10 = (has_head(v187_9) ? constant_15 : Space{});
        Space v187_12;
        if (!v187_10.empty()) {
          const Path v189_6 = concat_path(v186_6,v186_11_head);
          const Space v189_11 = routine_17(c, v189_6, v186_11_tail);
          v187_12 = compose(v187_10,v189_11);
        }
        const Space v187_13 = unite(v187_8,v187_12);
        v186_11_result = unite(v186_11_result,v187_13);
      }
      const Space v186_11 = std::move(v186_11_result);
      v181_12 = compose(v181_10,v186_11);
    }
    const Space v181_13 = unite(v181_8,v181_12);
    v180_11_result = unite(v180_11_result,v181_13);
  }
  const Space v180_11 = std::move(v180_11_result);
  return v180_11;
}

static Space routine_16(Context& c, const Path& p0, const Space& s0) {
  Space v190_11_result;
  for (int v190_11_label = 1; v190_11_label <= 2; ++v190_11_label) {
    const Space v190_11_tail = child(s0,v190_11_label);
    if (v190_11_tail.empty()) continue;
    const Path v190_11_head{v190_11_label};
    const Space v191_2 = singleton(v190_11_head);
    const Space v191_3 = intersect(constant_14,v191_2);
    const Space v191_4 = (has_head(v191_3) ? constant_15 : Space{});
    const Space v191_5 = subtract(constant_0,v191_4);
    Space v191_8;
    if (!v191_5.empty()) {
      const Path v192_6 = concat_path(p0,v190_11_head);
      Space v192_7_result;
      for (int v192_7_label = 1; v192_7_label <= 2; ++v192_7_label) {
        const Space v192_7_tail = child(v190_11_tail,v192_7_label);
        if (v192_7_tail.empty()) continue;
        const Path v192_7_head{v192_7_label};
        const Space v193_2 = singleton(v192_7_head);
        const Space v193_3 = intersect(constant_14,v193_2);
        const Space v193_4 = (has_head(v193_3) ? constant_15 : Space{});
        const Space v193_5 = subtract(constant_0,v193_4);
        Space v193_8;
        if (!v193_5.empty()) {
          const Path v194_6 = concat_path(v192_6,v192_7_head);
          const Space v194_7 = routine_48(c, v194_6, v192_7_tail);
          v193_8 = compose(v193_5,v194_7);
        }
        const Space v193_9 = intersect(constant_14,v193_2);
        const Space v193_10 = (has_head(v193_9) ? constant_15 : Space{});
        Space v193_12;
        if (!v193_10.empty()) {
          const Path v195_6 = concat_path(v192_6,v192_7_head);
          const Space v195_11 = routine_49(c, v195_6, v192_7_tail);
          v193_12 = compose(v193_10,v195_11);
        }
        const Space v193_13 = unite(v193_8,v193_12);
        v192_7_result = unite(v192_7_result,v193_13);
      }
      const Space v192_7 = std::move(v192_7_result);
      v191_8 = compose(v191_5,v192_7);
    }
    const Space v191_9 = intersect(constant_14,v191_2);
    const Space v191_10 = (has_head(v191_9) ? constant_15 : Space{});
    Space v191_12;
    if (!v191_10.empty()) {
      const Path v196_6 = concat_path(p0,v190_11_head);
      Space v196_11_result;
      for (int v196_11_label = 1; v196_11_label <= 2; ++v196_11_label) {
        const Space v196_11_tail = child(v190_11_tail,v196_11_label);
        if (v196_11_tail.empty()) continue;
        const Path v196_11_head{v196_11_label};
        const Space v197_2 = singleton(v196_11_head);
        const Space v197_3 = intersect(constant_14,v197_2);
        const Space v197_4 = (has_head(v197_3) ? constant_15 : Space{});
        const Space v197_5 = subtract(constant_0,v197_4);
        Space v197_7;
        if (!v197_5.empty()) {
          const Space v198_6 = routine_18(c, v196_11_head, v196_6, v196_11_tail);
          v197_7 = compose(v197_5,v198_6);
        }
        const Space v197_8 = intersect(constant_14,v197_2);
        const Space v197_9 = (has_head(v197_8) ? constant_15 : Space{});
        Space v197_11;
        if (!v197_9.empty()) {
          const Space v199_10 = routine_19(c, v196_11_head, v196_6, v196_11_tail);
          v197_11 = compose(v197_9,v199_10);
        }
        const Space v197_12 = unite(v197_7,v197_11);
        v196_11_result = unite(v196_11_result,v197_12);
      }
      const Space v196_11 = std::move(v196_11_result);
      v191_12 = compose(v191_10,v196_11);
    }
    const Space v191_13 = unite(v191_8,v191_12);
    v190_11_result = unite(v190_11_result,v191_13);
  }
  const Space v190_11 = std::move(v190_11_result);
  return v190_11;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0) {
  Space v200_11_result;
  for (int v200_11_label = 1; v200_11_label <= 2; ++v200_11_label) {
    const Space v200_11_tail = child(s0,v200_11_label);
    if (v200_11_tail.empty()) continue;
    const Path v200_11_head{v200_11_label};
    const Space v201_2 = singleton(v200_11_head);
    const Space v201_3 = intersect(constant_14,v201_2);
    const Space v201_4 = (has_head(v201_3) ? constant_15 : Space{});
    const Space v201_5 = subtract(constant_0,v201_4);
    Space v201_7;
    if (!v201_5.empty()) {
      Space v202_6_result;
      for (int v202_6_label = 1; v202_6_label <= 2; ++v202_6_label) {
        const Space v202_6_tail = child(v200_11_tail,v202_6_label);
        if (v202_6_tail.empty()) continue;
        const Path v202_6_head{v202_6_label};
        const Space v203_2 = singleton(v202_6_head);
        const Space v203_3 = intersect(constant_14,v203_2);
        const Space v203_4 = (has_head(v203_3) ? constant_15 : Space{});
        const Space v203_5 = subtract(constant_0,v203_4);
        Space v203_8;
        if (!v203_5.empty()) {
          const Path v204_6 = concat_path(v200_11_head,v202_6_head);
          const Space v204_7 = routine_50(c, v204_6, p0, v202_6_tail);
          v203_8 = compose(v203_5,v204_7);
        }
        const Space v203_9 = intersect(constant_14,v203_2);
        const Space v203_10 = (has_head(v203_9) ? constant_15 : Space{});
        Space v203_12;
        if (!v203_10.empty()) {
          const Path v205_6 = concat_path(v200_11_head,v202_6_head);
          const Space v205_11 = routine_51(c, v205_6, p0, v202_6_tail);
          v203_12 = compose(v203_10,v205_11);
        }
        const Space v203_13 = unite(v203_8,v203_12);
        v202_6_result = unite(v202_6_result,v203_13);
      }
      const Space v202_6 = std::move(v202_6_result);
      v201_7 = compose(v201_5,v202_6);
    }
    const Space v201_8 = intersect(constant_14,v201_2);
    const Space v201_9 = (has_head(v201_8) ? constant_15 : Space{});
    Space v201_11;
    if (!v201_9.empty()) {
      Space v206_10_result;
      for (int v206_10_label = 1; v206_10_label <= 2; ++v206_10_label) {
        const Space v206_10_tail = child(v200_11_tail,v206_10_label);
        if (v206_10_tail.empty()) continue;
        const Path v206_10_head{v206_10_label};
        const Space v207_2 = singleton(v206_10_head);
        const Space v207_3 = intersect(constant_14,v207_2);
        const Space v207_4 = (has_head(v207_3) ? constant_15 : Space{});
        const Space v207_5 = subtract(constant_0,v207_4);
        Space v207_8;
        if (!v207_5.empty()) {
          const Path v208_6 = concat_path(v200_11_head,v206_10_head);
          const Space v208_7 = routine_50(c, v208_6, p0, v206_10_tail);
          v207_8 = compose(v207_5,v208_7);
        }
        const Space v207_9 = intersect(constant_14,v207_2);
        const Space v207_10 = (has_head(v207_9) ? constant_15 : Space{});
        Space v207_12;
        if (!v207_10.empty()) {
          const Path v209_6 = concat_path(v200_11_head,v206_10_head);
          const Space v209_11 = routine_52(c, v209_6, p0, v206_10_tail);
          v207_12 = compose(v207_10,v209_11);
        }
        const Space v207_13 = unite(v207_8,v207_12);
        v206_10_result = unite(v206_10_result,v207_13);
      }
      const Space v206_10 = std::move(v206_10_result);
      v201_11 = compose(v201_9,v206_10);
    }
    const Space v201_12 = unite(v201_7,v201_11);
    v200_11_result = unite(v200_11_result,v201_12);
  }
  const Space v200_11 = std::move(v200_11_result);
  return v200_11;
}

static Space routine_18(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v210_12_result;
  for (int v210_12_label = 1; v210_12_label <= 2; ++v210_12_label) {
    const Space v210_12_tail = child(s0,v210_12_label);
    if (v210_12_tail.empty()) continue;
    const Path v210_12_head{v210_12_label};
    const Space v211_2 = singleton(v210_12_head);
    const Space v211_3 = intersect(constant_14,v211_2);
    const Space v211_4 = (has_head(v211_3) ? constant_15 : Space{});
    const Space v211_5 = subtract(constant_0,v211_4);
    Space v211_8;
    if (!v211_5.empty()) {
      const Path v212_6 = concat_path(p0,v210_12_head);
      Space v212_7_result;
      for (int v212_7_label = 1; v212_7_label <= 2; ++v212_7_label) {
        const Space v212_7_tail = child(v210_12_tail,v212_7_label);
        if (v212_7_tail.empty()) continue;
        const Path v212_7_head{v212_7_label};
        const Space v213_2 = singleton(v212_7_head);
        const Space v213_3 = intersect(constant_14,v213_2);
        const Space v213_4 = (has_head(v213_3) ? constant_15 : Space{});
        const Space v213_5 = subtract(constant_0,v213_4);
        Space v213_8;
        if (!v213_5.empty()) {
          const Path v214_6 = concat_path(v212_6,v212_7_head);
          const Space v214_7 = routine_53(c, v214_6, p1, v212_7_tail);
          v213_8 = compose(v213_5,v214_7);
        }
        const Space v213_9 = intersect(constant_14,v213_2);
        const Space v213_10 = (has_head(v213_9) ? constant_15 : Space{});
        Space v213_12;
        if (!v213_10.empty()) {
          const Path v215_6 = concat_path(v212_6,v212_7_head);
          const Space v215_11 = routine_54(c, v215_6, p1, v212_7_tail);
          v213_12 = compose(v213_10,v215_11);
        }
        const Space v213_13 = unite(v213_8,v213_12);
        v212_7_result = unite(v212_7_result,v213_13);
      }
      const Space v212_7 = std::move(v212_7_result);
      v211_8 = compose(v211_5,v212_7);
    }
    const Space v211_9 = intersect(constant_14,v211_2);
    const Space v211_10 = (has_head(v211_9) ? constant_15 : Space{});
    Space v211_12;
    if (!v211_10.empty()) {
      const Path v216_6 = concat_path(p0,v210_12_head);
      Space v216_11_result;
      for (int v216_11_label = 1; v216_11_label <= 2; ++v216_11_label) {
        const Space v216_11_tail = child(v210_12_tail,v216_11_label);
        if (v216_11_tail.empty()) continue;
        const Path v216_11_head{v216_11_label};
        const Space v217_2 = singleton(v216_11_head);
        const Space v217_3 = intersect(constant_14,v217_2);
        const Space v217_4 = (has_head(v217_3) ? constant_15 : Space{});
        const Space v217_5 = subtract(constant_0,v217_4);
        Space v217_8;
        if (!v217_5.empty()) {
          const Path v218_6 = concat_path(v216_6,v216_11_head);
          const Space v218_7 = routine_53(c, v218_6, p1, v216_11_tail);
          v217_8 = compose(v217_5,v218_7);
        }
        const Space v217_9 = intersect(constant_14,v217_2);
        const Space v217_10 = (has_head(v217_9) ? constant_15 : Space{});
        Space v217_12;
        if (!v217_10.empty()) {
          const Path v219_6 = concat_path(v216_6,v216_11_head);
          const Space v219_11 = routine_52(c, v219_6, p1, v216_11_tail);
          v217_12 = compose(v217_10,v219_11);
        }
        const Space v217_13 = unite(v217_8,v217_12);
        v216_11_result = unite(v216_11_result,v217_13);
      }
      const Space v216_11 = std::move(v216_11_result);
      v211_12 = compose(v211_10,v216_11);
    }
    const Space v211_13 = unite(v211_8,v211_12);
    v210_12_result = unite(v210_12_result,v211_13);
  }
  const Space v210_12 = std::move(v210_12_result);
  return v210_12;
}

static Space routine_19(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v220_10_result;
  for (int v220_10_label = 1; v220_10_label <= 2; ++v220_10_label) {
    const Space v220_10_tail = child(s0,v220_10_label);
    if (v220_10_tail.empty()) continue;
    const Path v220_10_head{v220_10_label};
    const Space v221_2 = singleton(v220_10_head);
    const Space v221_3 = intersect(constant_14,v221_2);
    const Space v221_4 = (has_head(v221_3) ? constant_15 : Space{});
    const Space v221_5 = compose(v221_4,v220_10_tail);
    const Path v222_6 = concat_path(p0,v220_10_head);
    const Space v221_7 = wrap(v221_5,v222_6);
    const Space v221_8 = wrap(v221_7,p1);
    const Space v221_9 = wrap(v221_8,constant_10);
    const Space v221_10 = intersect(constant_14,v221_2);
    const Space v221_11 = (has_head(v221_10) ? constant_15 : Space{});
    const Space v221_12 = subtract(constant_0,v221_11);
    Space v221_14;
    if (!v221_12.empty()) {
      Space v223_13_result;
      for (int v223_13_label = 1; v223_13_label <= 2; ++v223_13_label) {
        const Space v223_13_tail = child(v220_10_tail,v223_13_label);
        if (v223_13_tail.empty()) continue;
        const Path v223_13_head{v223_13_label};
        const Space v224_2 = singleton(v223_13_head);
        const Space v224_3 = intersect(constant_14,v224_2);
        const Space v224_4 = (has_head(v224_3) ? constant_15 : Space{});
        const Space v224_5 = subtract(constant_0,v224_4);
        Space v224_8;
        if (!v224_5.empty()) {
          const Path v225_6 = concat_path(v222_6,v223_13_head);
          const Space v225_7 = routine_53(c, v225_6, p1, v223_13_tail);
          v224_8 = compose(v224_5,v225_7);
        }
        const Space v224_9 = intersect(constant_14,v224_2);
        const Space v224_10 = (has_head(v224_9) ? constant_15 : Space{});
        Space v224_12;
        if (!v224_10.empty()) {
          const Path v226_6 = concat_path(v222_6,v223_13_head);
          const Space v226_11 = routine_54(c, v226_6, p1, v223_13_tail);
          v224_12 = compose(v224_10,v226_11);
        }
        const Space v224_13 = unite(v224_8,v224_12);
        v223_13_result = unite(v223_13_result,v224_13);
      }
      const Space v223_13 = std::move(v223_13_result);
      v221_14 = compose(v221_12,v223_13);
    }
    const Space v221_15 = unite(v221_9,v221_14);
    v220_10_result = unite(v220_10_result,v221_15);
  }
  const Space v220_10 = std::move(v220_10_result);
  return v220_10;
}

static Space routine_20(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v227_12_result;
  for (int v227_12_label = 1; v227_12_label <= 2; ++v227_12_label) {
    const Space v227_12_tail = child(s0,v227_12_label);
    if (v227_12_tail.empty()) continue;
    const Path v227_12_head{v227_12_label};
    const Space v228_2 = singleton(v227_12_head);
    const Space v228_3 = intersect(constant_14,v228_2);
    const Space v228_4 = (has_head(v228_3) ? constant_15 : Space{});
    const Space v228_5 = subtract(constant_0,v228_4);
    Space v228_8;
    if (!v228_5.empty()) {
      const Path v229_6 = concat_path(p0,v227_12_head);
      Space v229_7_result;
      for (int v229_7_label = 1; v229_7_label <= 2; ++v229_7_label) {
        const Space v229_7_tail = child(v227_12_tail,v229_7_label);
        if (v229_7_tail.empty()) continue;
        const Path v229_7_head{v229_7_label};
        const Space v230_2 = singleton(v229_7_head);
        const Space v230_3 = intersect(constant_14,v230_2);
        const Space v230_4 = (has_head(v230_3) ? constant_15 : Space{});
        const Space v230_5 = subtract(constant_0,v230_4);
        Space v230_8;
        if (!v230_5.empty()) {
          const Path v231_6 = concat_path(v229_6,v229_7_head);
          const Space v231_7 = routine_55(c, v231_6, v229_7_tail, s1);
          v230_8 = compose(v230_5,v231_7);
        }
        const Space v230_9 = intersect(constant_14,v230_2);
        const Space v230_10 = (has_head(v230_9) ? constant_15 : Space{});
        Space v230_12;
        if (!v230_10.empty()) {
          const Path v232_6 = concat_path(v229_6,v229_7_head);
          const Space v232_11 = routine_56(c, v232_6, v229_7_tail, s1);
          v230_12 = compose(v230_10,v232_11);
        }
        const Space v230_13 = unite(v230_8,v230_12);
        v229_7_result = unite(v229_7_result,v230_13);
      }
      const Space v229_7 = std::move(v229_7_result);
      v228_8 = compose(v228_5,v229_7);
    }
    const Space v228_9 = intersect(constant_14,v228_2);
    const Space v228_10 = (has_head(v228_9) ? constant_15 : Space{});
    Space v228_12;
    if (!v228_10.empty()) {
      const Path v233_6 = concat_path(p0,v227_12_head);
      Space v233_11_result;
      for (int v233_11_label = 1; v233_11_label <= 2; ++v233_11_label) {
        const Space v233_11_tail = child(v227_12_tail,v233_11_label);
        if (v233_11_tail.empty()) continue;
        const Path v233_11_head{v233_11_label};
        const Space v234_2 = singleton(v233_11_head);
        const Space v234_3 = intersect(constant_14,v234_2);
        const Space v234_4 = (has_head(v234_3) ? constant_15 : Space{});
        const Space v234_5 = subtract(constant_0,v234_4);
        Space v234_8;
        if (!v234_5.empty()) {
          const Path v235_6 = concat_path(v233_6,v233_11_head);
          const Space v235_7 = routine_55(c, v235_6, v233_11_tail, s1);
          v234_8 = compose(v234_5,v235_7);
        }
        const Space v234_9 = intersect(constant_14,v234_2);
        const Space v234_10 = (has_head(v234_9) ? constant_15 : Space{});
        Space v234_12;
        if (!v234_10.empty()) {
          const Path v236_6 = concat_path(v233_6,v233_11_head);
          const Space v236_11 = routine_5(c, v236_6, v233_11_tail, s1);
          v234_12 = compose(v234_10,v236_11);
        }
        const Space v234_13 = unite(v234_8,v234_12);
        v233_11_result = unite(v233_11_result,v234_13);
      }
      const Space v233_11 = std::move(v233_11_result);
      v228_12 = compose(v228_10,v233_11);
    }
    const Space v228_13 = unite(v228_8,v228_12);
    v227_12_result = unite(v227_12_result,v228_13);
  }
  const Space v227_12 = std::move(v227_12_result);
  return v227_12;
}

static Space routine_21(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v237_12_result;
  for (int v237_12_label = 1; v237_12_label <= 2; ++v237_12_label) {
    const Space v237_12_tail = child(s0,v237_12_label);
    if (v237_12_tail.empty()) continue;
    const Path v237_12_head{v237_12_label};
    const Space v238_2 = singleton(v237_12_head);
    const Space v238_3 = intersect(constant_14,v238_2);
    const Space v238_4 = (has_head(v238_3) ? constant_15 : Space{});
    const Space v238_5 = subtract(constant_0,v238_4);
    Space v238_8;
    if (!v238_5.empty()) {
      const Path v239_6 = concat_path(p0,v237_12_head);
      Space v239_7_result;
      for (int v239_7_label = 1; v239_7_label <= 2; ++v239_7_label) {
        const Space v239_7_tail = child(v237_12_tail,v239_7_label);
        if (v239_7_tail.empty()) continue;
        const Path v239_7_head{v239_7_label};
        const Space v240_2 = singleton(v239_7_head);
        const Space v240_3 = intersect(constant_14,v240_2);
        const Space v240_4 = (has_head(v240_3) ? constant_15 : Space{});
        const Space v240_5 = subtract(constant_0,v240_4);
        Space v240_8;
        if (!v240_5.empty()) {
          const Path v241_6 = concat_path(v239_6,v239_7_head);
          const Space v241_7 = routine_55(c, v241_6, v239_7_tail, s1);
          v240_8 = compose(v240_5,v241_7);
        }
        const Space v240_9 = intersect(constant_14,v240_2);
        const Space v240_10 = (has_head(v240_9) ? constant_15 : Space{});
        Space v240_12;
        if (!v240_10.empty()) {
          const Path v242_6 = concat_path(v239_6,v239_7_head);
          const Space v242_11 = routine_56(c, v242_6, v239_7_tail, s1);
          v240_12 = compose(v240_10,v242_11);
        }
        const Space v240_13 = unite(v240_8,v240_12);
        v239_7_result = unite(v239_7_result,v240_13);
      }
      const Space v239_7 = std::move(v239_7_result);
      v238_8 = compose(v238_5,v239_7);
    }
    const Space v238_9 = intersect(constant_14,v238_2);
    const Space v238_10 = (has_head(v238_9) ? constant_15 : Space{});
    Space v238_12;
    if (!v238_10.empty()) {
      const Path v243_6 = concat_path(p0,v237_12_head);
      Space v243_11_result;
      for (int v243_11_label = 1; v243_11_label <= 2; ++v243_11_label) {
        const Space v243_11_tail = child(v237_12_tail,v243_11_label);
        if (v243_11_tail.empty()) continue;
        const Path v243_11_head{v243_11_label};
        const Space v244_2 = singleton(v243_11_head);
        const Space v244_3 = intersect(constant_14,v244_2);
        const Space v244_4 = (has_head(v244_3) ? constant_15 : Space{});
        const Space v244_5 = subtract(constant_0,v244_4);
        Space v244_7;
        if (!v244_5.empty()) {
          const Space v245_6 = routine_22(c, v243_11_head, v243_6, v243_11_tail, s1);
          v244_7 = compose(v244_5,v245_6);
        }
        const Space v244_8 = intersect(constant_14,v244_2);
        const Space v244_9 = (has_head(v244_8) ? constant_15 : Space{});
        Space v244_11;
        if (!v244_9.empty()) {
          const Space v246_10 = routine_23(c, v243_11_head, v243_6, v243_11_tail, s1);
          v244_11 = compose(v244_9,v246_10);
        }
        const Space v244_12 = unite(v244_7,v244_11);
        v243_11_result = unite(v243_11_result,v244_12);
      }
      const Space v243_11 = std::move(v243_11_result);
      v238_12 = compose(v238_10,v243_11);
    }
    const Space v238_13 = unite(v238_8,v238_12);
    v237_12_result = unite(v237_12_result,v238_13);
  }
  const Space v237_12 = std::move(v237_12_result);
  return v237_12;
}

static Space routine_22(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v247_13_result;
  for (int v247_13_label = 1; v247_13_label <= 2; ++v247_13_label) {
    const Space v247_13_tail = child(s0,v247_13_label);
    if (v247_13_tail.empty()) continue;
    const Path v247_13_head{v247_13_label};
    const Space v248_2 = singleton(v247_13_head);
    const Space v248_3 = intersect(constant_14,v248_2);
    const Space v248_4 = (has_head(v248_3) ? constant_15 : Space{});
    const Space v248_5 = subtract(constant_0,v248_4);
    Space v248_8;
    if (!v248_5.empty()) {
      const Path v249_6 = concat_path(p0,v247_13_head);
      Space v249_7_result;
      for (int v249_7_label = 1; v249_7_label <= 2; ++v249_7_label) {
        const Space v249_7_tail = child(v247_13_tail,v249_7_label);
        if (v249_7_tail.empty()) continue;
        const Path v249_7_head{v249_7_label};
        const Space v250_2 = singleton(v249_7_head);
        const Space v250_3 = intersect(constant_14,v250_2);
        const Space v250_4 = (has_head(v250_3) ? constant_15 : Space{});
        const Space v250_5 = subtract(constant_0,v250_4);
        Space v250_8;
        if (!v250_5.empty()) {
          const Path v251_6 = concat_path(v249_6,v249_7_head);
          const Space v251_7 = routine_57(c, v251_6, p1, v249_7_tail, s1);
          v250_8 = compose(v250_5,v251_7);
        }
        const Space v250_9 = intersect(constant_14,v250_2);
        const Space v250_10 = (has_head(v250_9) ? constant_15 : Space{});
        Space v250_12;
        if (!v250_10.empty()) {
          const Path v252_6 = concat_path(v249_6,v249_7_head);
          const Space v252_11 = routine_58(c, v252_6, p1, v249_7_tail, s1);
          v250_12 = compose(v250_10,v252_11);
        }
        const Space v250_13 = unite(v250_8,v250_12);
        v249_7_result = unite(v249_7_result,v250_13);
      }
      const Space v249_7 = std::move(v249_7_result);
      v248_8 = compose(v248_5,v249_7);
    }
    const Space v248_9 = intersect(constant_14,v248_2);
    const Space v248_10 = (has_head(v248_9) ? constant_15 : Space{});
    Space v248_12;
    if (!v248_10.empty()) {
      const Path v253_6 = concat_path(p0,v247_13_head);
      Space v253_11_result;
      for (int v253_11_label = 1; v253_11_label <= 2; ++v253_11_label) {
        const Space v253_11_tail = child(v247_13_tail,v253_11_label);
        if (v253_11_tail.empty()) continue;
        const Path v253_11_head{v253_11_label};
        const Space v254_2 = singleton(v253_11_head);
        const Space v254_3 = intersect(constant_14,v254_2);
        const Space v254_4 = (has_head(v254_3) ? constant_15 : Space{});
        const Space v254_5 = subtract(constant_0,v254_4);
        Space v254_8;
        if (!v254_5.empty()) {
          const Path v255_6 = concat_path(v253_6,v253_11_head);
          const Space v255_7 = routine_57(c, v255_6, p1, v253_11_tail, s1);
          v254_8 = compose(v254_5,v255_7);
        }
        const Space v254_9 = intersect(constant_14,v254_2);
        const Space v254_10 = (has_head(v254_9) ? constant_15 : Space{});
        Space v254_12;
        if (!v254_10.empty()) {
          const Path v256_6 = concat_path(v253_6,v253_11_head);
          const Space v256_11 = routine_26(c, v256_6, p1, v253_11_tail, s1);
          v254_12 = compose(v254_10,v256_11);
        }
        const Space v254_13 = unite(v254_8,v254_12);
        v253_11_result = unite(v253_11_result,v254_13);
      }
      const Space v253_11 = std::move(v253_11_result);
      v248_12 = compose(v248_10,v253_11);
    }
    const Space v248_13 = unite(v248_8,v248_12);
    v247_13_result = unite(v247_13_result,v248_13);
  }
  const Space v247_13 = std::move(v247_13_result);
  return v247_13;
}

static Space routine_23(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v257_8 = unwrap(s1,constant_7);
  const Space v257_10 = unwrap(v257_8,constant_10);
  const Space v257_11 = unwrap(v257_10,p0);
  Space v257_18_result;
  for (int v257_18_label = 1; v257_18_label <= 2; ++v257_18_label) {
    const Space v257_18_tail = child(s0,v257_18_label);
    if (v257_18_tail.empty()) continue;
    const Path v257_18_head{v257_18_label};
    const Space v258_2 = singleton(v257_18_head);
    const Space v258_3 = intersect(constant_14,v258_2);
    const Space v258_4 = (has_head(v258_3) ? constant_15 : Space{});
    const Space v258_5 = subtract(constant_0,v258_4);
    Space v258_8;
    if (!v258_5.empty()) {
      const Path v259_6 = concat_path(p0,v257_18_head);
      Space v259_7_result;
      for (int v259_7_label = 1; v259_7_label <= 2; ++v259_7_label) {
        const Space v259_7_tail = child(v257_18_tail,v259_7_label);
        if (v259_7_tail.empty()) continue;
        const Path v259_7_head{v259_7_label};
        const Space v260_2 = singleton(v259_7_head);
        const Space v260_3 = intersect(constant_14,v260_2);
        const Space v260_4 = (has_head(v260_3) ? constant_15 : Space{});
        const Space v260_5 = subtract(constant_0,v260_4);
        Space v260_8;
        if (!v260_5.empty()) {
          const Path v261_6 = concat_path(v259_6,v259_7_head);
          const Space v261_7 = routine_57(c, v261_6, p1, v259_7_tail, s1);
          v260_8 = compose(v260_5,v261_7);
        }
        const Space v260_9 = intersect(constant_14,v260_2);
        const Space v260_10 = (has_head(v260_9) ? constant_15 : Space{});
        Space v260_12;
        if (!v260_10.empty()) {
          const Path v262_6 = concat_path(v259_6,v259_7_head);
          const Space v262_11 = routine_58(c, v262_6, p1, v259_7_tail, s1);
          v260_12 = compose(v260_10,v262_11);
        }
        const Space v260_13 = unite(v260_8,v260_12);
        v259_7_result = unite(v259_7_result,v260_13);
      }
      const Space v259_7 = std::move(v259_7_result);
      v258_8 = compose(v258_5,v259_7);
    }
    const Space v258_9 = intersect(constant_14,v258_2);
    const Space v258_10 = (has_head(v258_9) ? constant_15 : Space{});
    Space v258_13;
    if (!v258_10.empty()) {
      const Space v263_11 = unwrap(v257_11,v257_18_head);
      Space v263_12_result;
      for (int v263_12_label = 1; v263_12_label <= 2; ++v263_12_label) {
        const Space v263_12_tail = child(v263_11,v263_12_label);
        if (v263_12_tail.empty()) continue;
        const Path v263_12_head{v263_12_label};
        const Space v264_2 = singleton(v263_12_head);
        const Space v264_3 = intersect(constant_14,v264_2);
        const Space v264_4 = (has_head(v264_3) ? constant_15 : Space{});
        const Space v264_5 = subtract(constant_0,v264_4);
        Space v264_7;
        if (!v264_5.empty()) {
          const Space v265_6 = routine_59(c, v263_12_head, p1, v263_12_tail);
          v264_7 = compose(v264_5,v265_6);
        }
        const Space v264_8 = intersect(constant_14,v264_2);
        const Space v264_9 = (has_head(v264_8) ? constant_15 : Space{});
        Space v264_11;
        if (!v264_9.empty()) {
          const Space v266_10 = routine_60(c, v263_12_head, p1, v263_12_tail);
          v264_11 = compose(v264_9,v266_10);
        }
        const Space v264_12 = unite(v264_7,v264_11);
        v263_12_result = unite(v263_12_result,v264_12);
      }
      const Space v263_12 = std::move(v263_12_result);
      v258_13 = compose(v258_10,v263_12);
    }
    const Space v258_14 = unite(v258_8,v258_13);
    v257_18_result = unite(v257_18_result,v258_14);
  }
  const Space v257_18 = std::move(v257_18_result);
  return v257_18;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v267_13_result;
  for (int v267_13_label = 1; v267_13_label <= 2; ++v267_13_label) {
    const Space v267_13_tail = child(s0,v267_13_label);
    if (v267_13_tail.empty()) continue;
    const Path v267_13_head{v267_13_label};
    const Space v268_2 = singleton(v267_13_head);
    const Space v268_3 = intersect(constant_14,v268_2);
    const Space v268_4 = (has_head(v268_3) ? constant_15 : Space{});
    const Space v268_5 = subtract(constant_0,v268_4);
    Space v268_8;
    if (!v268_5.empty()) {
      const Path v269_6 = concat_path(p0,v267_13_head);
      Space v269_7_result;
      for (int v269_7_label = 1; v269_7_label <= 2; ++v269_7_label) {
        const Space v269_7_tail = child(v267_13_tail,v269_7_label);
        if (v269_7_tail.empty()) continue;
        const Path v269_7_head{v269_7_label};
        const Space v270_2 = singleton(v269_7_head);
        const Space v270_3 = intersect(constant_14,v270_2);
        const Space v270_4 = (has_head(v270_3) ? constant_15 : Space{});
        const Space v270_5 = subtract(constant_0,v270_4);
        Space v270_8;
        if (!v270_5.empty()) {
          const Path v271_6 = concat_path(v269_6,v269_7_head);
          const Space v271_7 = routine_61(c, v271_6, p1, v269_7_tail, s1);
          v270_8 = compose(v270_5,v271_7);
        }
        const Space v270_9 = intersect(constant_14,v270_2);
        const Space v270_10 = (has_head(v270_9) ? constant_15 : Space{});
        Space v270_12;
        if (!v270_10.empty()) {
          const Path v272_6 = concat_path(v269_6,v269_7_head);
          const Space v272_11 = routine_62(c, v272_6, p1, v269_7_tail, s1);
          v270_12 = compose(v270_10,v272_11);
        }
        const Space v270_13 = unite(v270_8,v270_12);
        v269_7_result = unite(v269_7_result,v270_13);
      }
      const Space v269_7 = std::move(v269_7_result);
      v268_8 = compose(v268_5,v269_7);
    }
    const Space v268_9 = intersect(constant_14,v268_2);
    const Space v268_10 = (has_head(v268_9) ? constant_15 : Space{});
    Space v268_12;
    if (!v268_10.empty()) {
      const Path v273_6 = concat_path(p0,v267_13_head);
      Space v273_11_result;
      for (int v273_11_label = 1; v273_11_label <= 2; ++v273_11_label) {
        const Space v273_11_tail = child(v267_13_tail,v273_11_label);
        if (v273_11_tail.empty()) continue;
        const Path v273_11_head{v273_11_label};
        const Space v274_2 = singleton(v273_11_head);
        const Space v274_3 = intersect(constant_14,v274_2);
        const Space v274_4 = (has_head(v274_3) ? constant_15 : Space{});
        const Space v274_5 = subtract(constant_0,v274_4);
        Space v274_8;
        if (!v274_5.empty()) {
          const Path v275_6 = concat_path(v273_6,v273_11_head);
          const Space v275_7 = routine_61(c, v275_6, p1, v273_11_tail, s1);
          v274_8 = compose(v274_5,v275_7);
        }
        const Space v274_9 = intersect(constant_14,v274_2);
        const Space v274_10 = (has_head(v274_9) ? constant_15 : Space{});
        Space v274_12;
        if (!v274_10.empty()) {
          const Path v276_6 = concat_path(v273_6,v273_11_head);
          const Space v276_11 = routine_26(c, v276_6, p1, v273_11_tail, s1);
          v274_12 = compose(v274_10,v276_11);
        }
        const Space v274_13 = unite(v274_8,v274_12);
        v273_11_result = unite(v273_11_result,v274_13);
      }
      const Space v273_11 = std::move(v273_11_result);
      v268_12 = compose(v268_10,v273_11);
    }
    const Space v268_13 = unite(v268_8,v268_12);
    v267_13_result = unite(v267_13_result,v268_13);
  }
  const Space v267_13 = std::move(v267_13_result);
  return v267_13;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v277_8 = unwrap(s1,constant_7);
  const Space v277_10 = unwrap(v277_8,constant_10);
  const Space v277_11 = unwrap(v277_10,p0);
  Space v277_18_result;
  for (int v277_18_label = 1; v277_18_label <= 2; ++v277_18_label) {
    const Space v277_18_tail = child(s0,v277_18_label);
    if (v277_18_tail.empty()) continue;
    const Path v277_18_head{v277_18_label};
    const Space v278_2 = singleton(v277_18_head);
    const Space v278_3 = intersect(constant_14,v278_2);
    const Space v278_4 = (has_head(v278_3) ? constant_15 : Space{});
    const Space v278_5 = subtract(constant_0,v278_4);
    Space v278_8;
    if (!v278_5.empty()) {
      const Path v279_6 = concat_path(p0,v277_18_head);
      Space v279_7_result;
      for (int v279_7_label = 1; v279_7_label <= 2; ++v279_7_label) {
        const Space v279_7_tail = child(v277_18_tail,v279_7_label);
        if (v279_7_tail.empty()) continue;
        const Path v279_7_head{v279_7_label};
        const Space v280_2 = singleton(v279_7_head);
        const Space v280_3 = intersect(constant_14,v280_2);
        const Space v280_4 = (has_head(v280_3) ? constant_15 : Space{});
        const Space v280_5 = subtract(constant_0,v280_4);
        Space v280_8;
        if (!v280_5.empty()) {
          const Path v281_6 = concat_path(v279_6,v279_7_head);
          const Space v281_7 = routine_61(c, v281_6, p1, v279_7_tail, s1);
          v280_8 = compose(v280_5,v281_7);
        }
        const Space v280_9 = intersect(constant_14,v280_2);
        const Space v280_10 = (has_head(v280_9) ? constant_15 : Space{});
        Space v280_12;
        if (!v280_10.empty()) {
          const Path v282_6 = concat_path(v279_6,v279_7_head);
          const Space v282_11 = routine_62(c, v282_6, p1, v279_7_tail, s1);
          v280_12 = compose(v280_10,v282_11);
        }
        const Space v280_13 = unite(v280_8,v280_12);
        v279_7_result = unite(v279_7_result,v280_13);
      }
      const Space v279_7 = std::move(v279_7_result);
      v278_8 = compose(v278_5,v279_7);
    }
    const Space v278_9 = intersect(constant_14,v278_2);
    const Space v278_10 = (has_head(v278_9) ? constant_15 : Space{});
    Space v278_13;
    if (!v278_10.empty()) {
      const Space v283_11 = unwrap(v277_11,v277_18_head);
      Space v283_12_result;
      for (int v283_12_label = 1; v283_12_label <= 2; ++v283_12_label) {
        const Space v283_12_tail = child(v283_11,v283_12_label);
        if (v283_12_tail.empty()) continue;
        const Path v283_12_head{v283_12_label};
        const Space v284_2 = singleton(v283_12_head);
        const Space v284_3 = intersect(constant_14,v284_2);
        const Space v284_4 = (has_head(v284_3) ? constant_15 : Space{});
        const Space v284_5 = subtract(constant_0,v284_4);
        Space v284_7;
        if (!v284_5.empty()) {
          const Space v285_6 = routine_59(c, v283_12_head, p1, v283_12_tail);
          v284_7 = compose(v284_5,v285_6);
        }
        const Space v284_8 = intersect(constant_14,v284_2);
        const Space v284_9 = (has_head(v284_8) ? constant_15 : Space{});
        Space v284_11;
        if (!v284_9.empty()) {
          const Space v286_10 = routine_60(c, v283_12_head, p1, v283_12_tail);
          v284_11 = compose(v284_9,v286_10);
        }
        const Space v284_12 = unite(v284_7,v284_11);
        v283_12_result = unite(v283_12_result,v284_12);
      }
      const Space v283_12 = std::move(v283_12_result);
      v278_13 = compose(v278_10,v283_12);
    }
    const Space v278_14 = unite(v278_8,v278_13);
    v277_18_result = unite(v277_18_result,v278_14);
  }
  const Space v277_18 = std::move(v277_18_result);
  return v277_18;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v287_5 = unwrap(s1,constant_7);
  const Space v287_7 = unwrap(v287_5,constant_10);
  const Space v287_8 = unwrap(v287_7,p0);
  Space v287_18_result;
  for (int v287_18_label = 1; v287_18_label <= 2; ++v287_18_label) {
    const Space v287_18_tail = child(v287_8,v287_18_label);
    if (v287_18_tail.empty()) continue;
    const Path v287_18_head{v287_18_label};
    const Space v288_2 = singleton(v287_18_head);
    const Space v288_3 = intersect(constant_14,v288_2);
    const Space v288_4 = (has_head(v288_3) ? constant_15 : Space{});
    const Space v288_5 = subtract(constant_0,v288_4);
    Space v288_7;
    if (!v288_5.empty()) {
      Space v289_6_result;
      for (int v289_6_label = 1; v289_6_label <= 2; ++v289_6_label) {
        const Space v289_6_tail = child(v287_18_tail,v289_6_label);
        if (v289_6_tail.empty()) continue;
        const Path v289_6_head{v289_6_label};
        const Space v290_2 = singleton(v289_6_head);
        const Space v290_3 = intersect(constant_14,v290_2);
        const Space v290_4 = (has_head(v290_3) ? constant_15 : Space{});
        const Space v290_5 = subtract(constant_0,v290_4);
        Space v290_8;
        if (!v290_5.empty()) {
          const Path v291_6 = concat_path(v287_18_head,v289_6_head);
          const Space v291_7 = routine_63(c, v291_6, p1, v289_6_tail);
          v290_8 = compose(v290_5,v291_7);
        }
        const Space v290_9 = intersect(constant_14,v290_2);
        const Space v290_10 = (has_head(v290_9) ? constant_15 : Space{});
        Space v290_12;
        if (!v290_10.empty()) {
          const Path v292_6 = concat_path(v287_18_head,v289_6_head);
          const Space v292_11 = routine_64(c, v292_6, p1, v289_6_tail);
          v290_12 = compose(v290_10,v292_11);
        }
        const Space v290_13 = unite(v290_8,v290_12);
        v289_6_result = unite(v289_6_result,v290_13);
      }
      const Space v289_6 = std::move(v289_6_result);
      v288_7 = compose(v288_5,v289_6);
    }
    const Space v288_8 = intersect(constant_14,v288_2);
    const Space v288_9 = (has_head(v288_8) ? constant_15 : Space{});
    Space v288_11;
    if (!v288_9.empty()) {
      Space v293_10_result;
      for (int v293_10_label = 1; v293_10_label <= 2; ++v293_10_label) {
        const Space v293_10_tail = child(v287_18_tail,v293_10_label);
        if (v293_10_tail.empty()) continue;
        const Path v293_10_head{v293_10_label};
        const Space v294_2 = singleton(v293_10_head);
        const Space v294_3 = intersect(constant_14,v294_2);
        const Space v294_4 = (has_head(v294_3) ? constant_15 : Space{});
        const Space v294_5 = subtract(constant_0,v294_4);
        Space v294_8;
        if (!v294_5.empty()) {
          const Path v295_6 = concat_path(v287_18_head,v293_10_head);
          const Space v295_7 = routine_63(c, v295_6, p1, v293_10_tail);
          v294_8 = compose(v294_5,v295_7);
        }
        const Space v294_9 = intersect(constant_14,v294_2);
        const Space v294_10 = (has_head(v294_9) ? constant_15 : Space{});
        Space v294_12;
        if (!v294_10.empty()) {
          const Path v296_6 = concat_path(v287_18_head,v293_10_head);
          const Space v296_11 = routine_65(c, v296_6, p1, v293_10_tail);
          v294_12 = compose(v294_10,v296_11);
        }
        const Space v294_13 = unite(v294_8,v294_12);
        v293_10_result = unite(v293_10_result,v294_13);
      }
      const Space v293_10 = std::move(v293_10_result);
      v288_11 = compose(v288_9,v293_10);
    }
    const Space v288_12 = unite(v288_7,v288_11);
    v287_18_result = unite(v287_18_result,v288_12);
  }
  const Space v287_18 = std::move(v287_18_result);
  return v287_18;
}

static Space routine_27(Context& c, const Path& p0, const Space& s0) {
  Space v297_11_result;
  for (int v297_11_label = 1; v297_11_label <= 2; ++v297_11_label) {
    const Space v297_11_tail = child(s0,v297_11_label);
    if (v297_11_tail.empty()) continue;
    const Path v297_11_head{v297_11_label};
    const Space v298_2 = singleton(v297_11_head);
    const Space v298_3 = intersect(constant_14,v298_2);
    const Space v298_4 = (has_head(v298_3) ? constant_15 : Space{});
    const Space v298_5 = subtract(constant_0,v298_4);
    Space v298_8;
    if (!v298_5.empty()) {
      const Path v299_6 = concat_path(p0,v297_11_head);
      Space v299_7_result;
      for (int v299_7_label = 1; v299_7_label <= 2; ++v299_7_label) {
        const Space v299_7_tail = child(v297_11_tail,v299_7_label);
        if (v299_7_tail.empty()) continue;
        const Path v299_7_head{v299_7_label};
        const Space v300_2 = singleton(v299_7_head);
        const Space v300_3 = intersect(constant_14,v300_2);
        const Space v300_4 = (has_head(v300_3) ? constant_15 : Space{});
        const Space v300_5 = subtract(constant_0,v300_4);
        Space v300_8;
        if (!v300_5.empty()) {
          const Path v301_6 = concat_path(v299_6,v299_7_head);
          const Space v301_7 = routine_66(c, v301_6, v299_7_tail);
          v300_8 = compose(v300_5,v301_7);
        }
        const Space v300_9 = intersect(constant_14,v300_2);
        const Space v300_10 = (has_head(v300_9) ? constant_15 : Space{});
        Space v300_12;
        if (!v300_10.empty()) {
          const Path v302_6 = concat_path(v299_6,v299_7_head);
          const Space v302_11 = routine_67(c, v302_6, v299_7_tail);
          v300_12 = compose(v300_10,v302_11);
        }
        const Space v300_13 = unite(v300_8,v300_12);
        v299_7_result = unite(v299_7_result,v300_13);
      }
      const Space v299_7 = std::move(v299_7_result);
      v298_8 = compose(v298_5,v299_7);
    }
    const Space v298_9 = intersect(constant_14,v298_2);
    const Space v298_10 = (has_head(v298_9) ? constant_15 : Space{});
    Space v298_12;
    if (!v298_10.empty()) {
      const Path v303_6 = concat_path(p0,v297_11_head);
      Space v303_11_result;
      for (int v303_11_label = 1; v303_11_label <= 2; ++v303_11_label) {
        const Space v303_11_tail = child(v297_11_tail,v303_11_label);
        if (v303_11_tail.empty()) continue;
        const Path v303_11_head{v303_11_label};
        const Space v304_2 = singleton(v303_11_head);
        const Space v304_3 = intersect(constant_14,v304_2);
        const Space v304_4 = (has_head(v304_3) ? constant_15 : Space{});
        const Space v304_5 = subtract(constant_0,v304_4);
        Space v304_8;
        if (!v304_5.empty()) {
          const Path v305_6 = concat_path(v303_6,v303_11_head);
          const Space v305_7 = routine_66(c, v305_6, v303_11_tail);
          v304_8 = compose(v304_5,v305_7);
        }
        const Space v304_9 = intersect(constant_14,v304_2);
        const Space v304_10 = (has_head(v304_9) ? constant_15 : Space{});
        Space v304_12;
        if (!v304_10.empty()) {
          const Path v306_6 = concat_path(v303_6,v303_11_head);
          const Space v306_11 = routine_8(c, v306_6, v303_11_tail);
          v304_12 = compose(v304_10,v306_11);
        }
        const Space v304_13 = unite(v304_8,v304_12);
        v303_11_result = unite(v303_11_result,v304_13);
      }
      const Space v303_11 = std::move(v303_11_result);
      v298_12 = compose(v298_10,v303_11);
    }
    const Space v298_13 = unite(v298_8,v298_12);
    v297_11_result = unite(v297_11_result,v298_13);
  }
  const Space v297_11 = std::move(v297_11_result);
  return v297_11;
}

static Space routine_28(Context& c, const Path& p0, const Space& s0) {
  Space v307_11_result;
  for (int v307_11_label = 1; v307_11_label <= 2; ++v307_11_label) {
    const Space v307_11_tail = child(s0,v307_11_label);
    if (v307_11_tail.empty()) continue;
    const Path v307_11_head{v307_11_label};
    const Space v308_2 = singleton(v307_11_head);
    const Space v308_3 = intersect(constant_14,v308_2);
    const Space v308_4 = (has_head(v308_3) ? constant_15 : Space{});
    const Space v308_5 = subtract(constant_0,v308_4);
    Space v308_8;
    if (!v308_5.empty()) {
      const Path v309_6 = concat_path(p0,v307_11_head);
      Space v309_7_result;
      for (int v309_7_label = 1; v309_7_label <= 2; ++v309_7_label) {
        const Space v309_7_tail = child(v307_11_tail,v309_7_label);
        if (v309_7_tail.empty()) continue;
        const Path v309_7_head{v309_7_label};
        const Space v310_2 = singleton(v309_7_head);
        const Space v310_3 = intersect(constant_14,v310_2);
        const Space v310_4 = (has_head(v310_3) ? constant_15 : Space{});
        const Space v310_5 = subtract(constant_0,v310_4);
        Space v310_8;
        if (!v310_5.empty()) {
          const Path v311_6 = concat_path(v309_6,v309_7_head);
          const Space v311_7 = routine_66(c, v311_6, v309_7_tail);
          v310_8 = compose(v310_5,v311_7);
        }
        const Space v310_9 = intersect(constant_14,v310_2);
        const Space v310_10 = (has_head(v310_9) ? constant_15 : Space{});
        Space v310_12;
        if (!v310_10.empty()) {
          const Path v312_6 = concat_path(v309_6,v309_7_head);
          const Space v312_11 = routine_67(c, v312_6, v309_7_tail);
          v310_12 = compose(v310_10,v312_11);
        }
        const Space v310_13 = unite(v310_8,v310_12);
        v309_7_result = unite(v309_7_result,v310_13);
      }
      const Space v309_7 = std::move(v309_7_result);
      v308_8 = compose(v308_5,v309_7);
    }
    const Space v308_9 = intersect(constant_14,v308_2);
    const Space v308_10 = (has_head(v308_9) ? constant_15 : Space{});
    Space v308_12;
    if (!v308_10.empty()) {
      const Path v313_6 = concat_path(p0,v307_11_head);
      Space v313_11_result;
      for (int v313_11_label = 1; v313_11_label <= 2; ++v313_11_label) {
        const Space v313_11_tail = child(v307_11_tail,v313_11_label);
        if (v313_11_tail.empty()) continue;
        const Path v313_11_head{v313_11_label};
        const Space v314_2 = singleton(v313_11_head);
        const Space v314_3 = intersect(constant_14,v314_2);
        const Space v314_4 = (has_head(v314_3) ? constant_15 : Space{});
        const Space v314_5 = subtract(constant_0,v314_4);
        Space v314_7;
        if (!v314_5.empty()) {
          const Space v315_6 = routine_29(c, v313_11_head, v313_6, v313_11_tail);
          v314_7 = compose(v314_5,v315_6);
        }
        const Space v314_8 = intersect(constant_14,v314_2);
        const Space v314_9 = (has_head(v314_8) ? constant_15 : Space{});
        Space v314_11;
        if (!v314_9.empty()) {
          const Space v316_10 = routine_30(c, v313_11_head, v313_6, v313_11_tail);
          v314_11 = compose(v314_9,v316_10);
        }
        const Space v314_12 = unite(v314_7,v314_11);
        v313_11_result = unite(v313_11_result,v314_12);
      }
      const Space v313_11 = std::move(v313_11_result);
      v308_12 = compose(v308_10,v313_11);
    }
    const Space v308_13 = unite(v308_8,v308_12);
    v307_11_result = unite(v307_11_result,v308_13);
  }
  const Space v307_11 = std::move(v307_11_result);
  return v307_11;
}

static Space routine_29(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v317_12_result;
  for (int v317_12_label = 1; v317_12_label <= 2; ++v317_12_label) {
    const Space v317_12_tail = child(s0,v317_12_label);
    if (v317_12_tail.empty()) continue;
    const Path v317_12_head{v317_12_label};
    const Space v318_2 = singleton(v317_12_head);
    const Space v318_3 = intersect(constant_14,v318_2);
    const Space v318_4 = (has_head(v318_3) ? constant_15 : Space{});
    const Space v318_5 = subtract(constant_0,v318_4);
    Space v318_8;
    if (!v318_5.empty()) {
      const Path v319_6 = concat_path(p0,v317_12_head);
      Space v319_7_result;
      for (int v319_7_label = 1; v319_7_label <= 2; ++v319_7_label) {
        const Space v319_7_tail = child(v317_12_tail,v319_7_label);
        if (v319_7_tail.empty()) continue;
        const Path v319_7_head{v319_7_label};
        const Space v320_2 = singleton(v319_7_head);
        const Space v320_3 = intersect(constant_14,v320_2);
        const Space v320_4 = (has_head(v320_3) ? constant_15 : Space{});
        const Space v320_5 = subtract(constant_0,v320_4);
        Space v320_8;
        if (!v320_5.empty()) {
          const Path v321_6 = concat_path(v319_6,v319_7_head);
          const Space v321_7 = routine_68(c, v321_6, p1, v319_7_tail);
          v320_8 = compose(v320_5,v321_7);
        }
        const Space v320_9 = intersect(constant_14,v320_2);
        const Space v320_10 = (has_head(v320_9) ? constant_15 : Space{});
        Space v320_12;
        if (!v320_10.empty()) {
          const Path v322_6 = concat_path(v319_6,v319_7_head);
          const Space v322_11 = routine_69(c, v322_6, p1, v319_7_tail);
          v320_12 = compose(v320_10,v322_11);
        }
        const Space v320_13 = unite(v320_8,v320_12);
        v319_7_result = unite(v319_7_result,v320_13);
      }
      const Space v319_7 = std::move(v319_7_result);
      v318_8 = compose(v318_5,v319_7);
    }
    const Space v318_9 = intersect(constant_14,v318_2);
    const Space v318_10 = (has_head(v318_9) ? constant_15 : Space{});
    Space v318_12;
    if (!v318_10.empty()) {
      const Path v323_6 = concat_path(p0,v317_12_head);
      Space v323_11_result;
      for (int v323_11_label = 1; v323_11_label <= 2; ++v323_11_label) {
        const Space v323_11_tail = child(v317_12_tail,v323_11_label);
        if (v323_11_tail.empty()) continue;
        const Path v323_11_head{v323_11_label};
        const Space v324_2 = singleton(v323_11_head);
        const Space v324_3 = intersect(constant_14,v324_2);
        const Space v324_4 = (has_head(v324_3) ? constant_15 : Space{});
        const Space v324_5 = subtract(constant_0,v324_4);
        Space v324_8;
        if (!v324_5.empty()) {
          const Path v325_6 = concat_path(v323_6,v323_11_head);
          const Space v325_7 = routine_68(c, v325_6, p1, v323_11_tail);
          v324_8 = compose(v324_5,v325_7);
        }
        const Space v324_9 = intersect(constant_14,v324_2);
        const Space v324_10 = (has_head(v324_9) ? constant_15 : Space{});
        Space v324_12;
        if (!v324_10.empty()) {
          const Path v326_6 = concat_path(v323_6,v323_11_head);
          const Space v326_11 = routine_33(c, v326_6, p1, v323_11_tail);
          v324_12 = compose(v324_10,v326_11);
        }
        const Space v324_13 = unite(v324_8,v324_12);
        v323_11_result = unite(v323_11_result,v324_13);
      }
      const Space v323_11 = std::move(v323_11_result);
      v318_12 = compose(v318_10,v323_11);
    }
    const Space v318_13 = unite(v318_8,v318_12);
    v317_12_result = unite(v317_12_result,v318_13);
  }
  const Space v317_12 = std::move(v317_12_result);
  return v317_12;
}

static Space routine_30(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v327_9_result;
  for (int v327_9_label = 1; v327_9_label <= 2; ++v327_9_label) {
    const Space v327_9_tail = child(s0,v327_9_label);
    if (v327_9_tail.empty()) continue;
    const Path v327_9_head{v327_9_label};
    const Space v328_2 = singleton(v327_9_head);
    const Space v328_3 = intersect(constant_14,v328_2);
    const Space v328_4 = (has_head(v328_3) ? constant_15 : Space{});
    const Space v328_5 = subtract(constant_0,v328_4);
    Space v328_8;
    if (!v328_5.empty()) {
      const Path v329_6 = concat_path(p0,v327_9_head);
      Space v329_7_result;
      for (int v329_7_label = 1; v329_7_label <= 2; ++v329_7_label) {
        const Space v329_7_tail = child(v327_9_tail,v329_7_label);
        if (v329_7_tail.empty()) continue;
        const Path v329_7_head{v329_7_label};
        const Space v330_2 = singleton(v329_7_head);
        const Space v330_3 = intersect(constant_14,v330_2);
        const Space v330_4 = (has_head(v330_3) ? constant_15 : Space{});
        const Space v330_5 = subtract(constant_0,v330_4);
        Space v330_8;
        if (!v330_5.empty()) {
          const Path v331_6 = concat_path(v329_6,v329_7_head);
          const Space v331_7 = routine_68(c, v331_6, p1, v329_7_tail);
          v330_8 = compose(v330_5,v331_7);
        }
        const Space v330_9 = intersect(constant_14,v330_2);
        const Space v330_10 = (has_head(v330_9) ? constant_15 : Space{});
        Space v330_12;
        if (!v330_10.empty()) {
          const Path v332_6 = concat_path(v329_6,v329_7_head);
          const Space v332_11 = routine_69(c, v332_6, p1, v329_7_tail);
          v330_12 = compose(v330_10,v332_11);
        }
        const Space v330_13 = unite(v330_8,v330_12);
        v329_7_result = unite(v329_7_result,v330_13);
      }
      const Space v329_7 = std::move(v329_7_result);
      v328_8 = compose(v328_5,v329_7);
    }
    const Space v328_9 = intersect(constant_14,v328_2);
    const Space v328_10 = (has_head(v328_9) ? constant_15 : Space{});
    const Space v328_11 = compose(v328_10,v327_9_tail);
    const Path v333_6 = concat_path(p0,v327_9_head);
    const Space v328_12 = wrap(v328_11,v333_6);
    const Space v328_13 = wrap(v328_12,p1);
    const Space v328_14 = unite(v328_8,v328_13);
    v327_9_result = unite(v327_9_result,v328_14);
  }
  const Space v327_9 = std::move(v327_9_result);
  return v327_9;
}

static Space routine_31(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v334_12_result;
  for (int v334_12_label = 1; v334_12_label <= 2; ++v334_12_label) {
    const Space v334_12_tail = child(s0,v334_12_label);
    if (v334_12_tail.empty()) continue;
    const Path v334_12_head{v334_12_label};
    const Space v335_2 = singleton(v334_12_head);
    const Space v335_3 = intersect(constant_14,v335_2);
    const Space v335_4 = (has_head(v335_3) ? constant_15 : Space{});
    const Space v335_5 = subtract(constant_0,v335_4);
    Space v335_8;
    if (!v335_5.empty()) {
      const Path v336_6 = concat_path(p0,v334_12_head);
      Space v336_7_result;
      for (int v336_7_label = 1; v336_7_label <= 2; ++v336_7_label) {
        const Space v336_7_tail = child(v334_12_tail,v336_7_label);
        if (v336_7_tail.empty()) continue;
        const Path v336_7_head{v336_7_label};
        const Space v337_2 = singleton(v336_7_head);
        const Space v337_3 = intersect(constant_14,v337_2);
        const Space v337_4 = (has_head(v337_3) ? constant_15 : Space{});
        const Space v337_5 = subtract(constant_0,v337_4);
        Space v337_8;
        if (!v337_5.empty()) {
          const Path v338_6 = concat_path(v336_6,v336_7_head);
          const Space v338_7 = routine_70(c, v338_6, p1, v336_7_tail);
          v337_8 = compose(v337_5,v338_7);
        }
        const Space v337_9 = intersect(constant_14,v337_2);
        const Space v337_10 = (has_head(v337_9) ? constant_15 : Space{});
        Space v337_12;
        if (!v337_10.empty()) {
          const Path v339_6 = concat_path(v336_6,v336_7_head);
          const Space v339_11 = routine_71(c, v339_6, p1, v336_7_tail);
          v337_12 = compose(v337_10,v339_11);
        }
        const Space v337_13 = unite(v337_8,v337_12);
        v336_7_result = unite(v336_7_result,v337_13);
      }
      const Space v336_7 = std::move(v336_7_result);
      v335_8 = compose(v335_5,v336_7);
    }
    const Space v335_9 = intersect(constant_14,v335_2);
    const Space v335_10 = (has_head(v335_9) ? constant_15 : Space{});
    Space v335_12;
    if (!v335_10.empty()) {
      const Path v340_6 = concat_path(p0,v334_12_head);
      Space v340_11_result;
      for (int v340_11_label = 1; v340_11_label <= 2; ++v340_11_label) {
        const Space v340_11_tail = child(v334_12_tail,v340_11_label);
        if (v340_11_tail.empty()) continue;
        const Path v340_11_head{v340_11_label};
        const Space v341_2 = singleton(v340_11_head);
        const Space v341_3 = intersect(constant_14,v341_2);
        const Space v341_4 = (has_head(v341_3) ? constant_15 : Space{});
        const Space v341_5 = subtract(constant_0,v341_4);
        Space v341_8;
        if (!v341_5.empty()) {
          const Path v342_6 = concat_path(v340_6,v340_11_head);
          const Space v342_7 = routine_70(c, v342_6, p1, v340_11_tail);
          v341_8 = compose(v341_5,v342_7);
        }
        const Space v341_9 = intersect(constant_14,v341_2);
        const Space v341_10 = (has_head(v341_9) ? constant_15 : Space{});
        Space v341_12;
        if (!v341_10.empty()) {
          const Path v343_6 = concat_path(v340_6,v340_11_head);
          const Space v343_11 = routine_33(c, v343_6, p1, v340_11_tail);
          v341_12 = compose(v341_10,v343_11);
        }
        const Space v341_13 = unite(v341_8,v341_12);
        v340_11_result = unite(v340_11_result,v341_13);
      }
      const Space v340_11 = std::move(v340_11_result);
      v335_12 = compose(v335_10,v340_11);
    }
    const Space v335_13 = unite(v335_8,v335_12);
    v334_12_result = unite(v334_12_result,v335_13);
  }
  const Space v334_12 = std::move(v334_12_result);
  return v334_12;
}

static Space routine_32(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v344_9_result;
  for (int v344_9_label = 1; v344_9_label <= 2; ++v344_9_label) {
    const Space v344_9_tail = child(s0,v344_9_label);
    if (v344_9_tail.empty()) continue;
    const Path v344_9_head{v344_9_label};
    const Space v345_2 = singleton(v344_9_head);
    const Space v345_3 = intersect(constant_14,v345_2);
    const Space v345_4 = (has_head(v345_3) ? constant_15 : Space{});
    const Space v345_5 = subtract(constant_0,v345_4);
    Space v345_8;
    if (!v345_5.empty()) {
      const Path v346_6 = concat_path(p0,v344_9_head);
      Space v346_7_result;
      for (int v346_7_label = 1; v346_7_label <= 2; ++v346_7_label) {
        const Space v346_7_tail = child(v344_9_tail,v346_7_label);
        if (v346_7_tail.empty()) continue;
        const Path v346_7_head{v346_7_label};
        const Space v347_2 = singleton(v346_7_head);
        const Space v347_3 = intersect(constant_14,v347_2);
        const Space v347_4 = (has_head(v347_3) ? constant_15 : Space{});
        const Space v347_5 = subtract(constant_0,v347_4);
        Space v347_8;
        if (!v347_5.empty()) {
          const Path v348_6 = concat_path(v346_6,v346_7_head);
          const Space v348_7 = routine_70(c, v348_6, p1, v346_7_tail);
          v347_8 = compose(v347_5,v348_7);
        }
        const Space v347_9 = intersect(constant_14,v347_2);
        const Space v347_10 = (has_head(v347_9) ? constant_15 : Space{});
        Space v347_12;
        if (!v347_10.empty()) {
          const Path v349_6 = concat_path(v346_6,v346_7_head);
          const Space v349_11 = routine_71(c, v349_6, p1, v346_7_tail);
          v347_12 = compose(v347_10,v349_11);
        }
        const Space v347_13 = unite(v347_8,v347_12);
        v346_7_result = unite(v346_7_result,v347_13);
      }
      const Space v346_7 = std::move(v346_7_result);
      v345_8 = compose(v345_5,v346_7);
    }
    const Space v345_9 = intersect(constant_14,v345_2);
    const Space v345_10 = (has_head(v345_9) ? constant_15 : Space{});
    const Space v345_11 = compose(v345_10,v344_9_tail);
    const Path v350_6 = concat_path(p0,v344_9_head);
    const Space v345_12 = wrap(v345_11,v350_6);
    const Space v345_13 = wrap(v345_12,p1);
    const Space v345_14 = unite(v345_8,v345_13);
    v344_9_result = unite(v344_9_result,v345_14);
  }
  const Space v344_9 = std::move(v344_9_result);
  return v344_9;
}

static Space routine_33(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v351_3 = wrap(s0,p0);
  const Space v351_4 = wrap(v351_3,p1);
  return v351_4;
}

static Space routine_34(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v352_12_result;
  for (int v352_12_label = 1; v352_12_label <= 2; ++v352_12_label) {
    const Space v352_12_tail = child(s0,v352_12_label);
    if (v352_12_tail.empty()) continue;
    const Path v352_12_head{v352_12_label};
    const Space v353_2 = singleton(v352_12_head);
    const Space v353_3 = intersect(constant_14,v353_2);
    const Space v353_4 = (has_head(v353_3) ? constant_15 : Space{});
    const Space v353_5 = subtract(constant_0,v353_4);
    Space v353_8;
    if (!v353_5.empty()) {
      const Path v354_6 = concat_path(p0,v352_12_head);
      Space v354_7_result;
      for (int v354_7_label = 1; v354_7_label <= 2; ++v354_7_label) {
        const Space v354_7_tail = child(v352_12_tail,v354_7_label);
        if (v354_7_tail.empty()) continue;
        const Path v354_7_head{v354_7_label};
        const Space v355_2 = singleton(v354_7_head);
        const Space v355_3 = intersect(constant_14,v355_2);
        const Space v355_4 = (has_head(v355_3) ? constant_15 : Space{});
        const Space v355_5 = subtract(constant_0,v355_4);
        Space v355_8;
        if (!v355_5.empty()) {
          const Path v356_6 = concat_path(v354_6,v354_7_head);
          const Space v356_7 = routine_72(c, v356_6, v354_7_tail, s1);
          v355_8 = compose(v355_5,v356_7);
        }
        const Space v355_9 = intersect(constant_14,v355_2);
        const Space v355_10 = (has_head(v355_9) ? constant_15 : Space{});
        Space v355_12;
        if (!v355_10.empty()) {
          const Path v357_6 = concat_path(v354_6,v354_7_head);
          const Space v357_11 = routine_73(c, v357_6, v354_7_tail, s1);
          v355_12 = compose(v355_10,v357_11);
        }
        const Space v355_13 = unite(v355_8,v355_12);
        v354_7_result = unite(v354_7_result,v355_13);
      }
      const Space v354_7 = std::move(v354_7_result);
      v353_8 = compose(v353_5,v354_7);
    }
    const Space v353_9 = intersect(constant_14,v353_2);
    const Space v353_10 = (has_head(v353_9) ? constant_15 : Space{});
    Space v353_12;
    if (!v353_10.empty()) {
      const Path v358_6 = concat_path(p0,v352_12_head);
      Space v358_11_result;
      for (int v358_11_label = 1; v358_11_label <= 2; ++v358_11_label) {
        const Space v358_11_tail = child(v352_12_tail,v358_11_label);
        if (v358_11_tail.empty()) continue;
        const Path v358_11_head{v358_11_label};
        const Space v359_2 = singleton(v358_11_head);
        const Space v359_3 = intersect(constant_14,v359_2);
        const Space v359_4 = (has_head(v359_3) ? constant_15 : Space{});
        const Space v359_5 = subtract(constant_0,v359_4);
        Space v359_8;
        if (!v359_5.empty()) {
          const Path v360_6 = concat_path(v358_6,v358_11_head);
          const Space v360_7 = routine_72(c, v360_6, v358_11_tail, s1);
          v359_8 = compose(v359_5,v360_7);
        }
        const Space v359_9 = intersect(constant_14,v359_2);
        const Space v359_10 = (has_head(v359_9) ? constant_15 : Space{});
        Space v359_12;
        if (!v359_10.empty()) {
          const Path v361_6 = concat_path(v358_6,v358_11_head);
          const Space v361_11 = routine_11(c, v361_6, v358_11_tail, s1);
          v359_12 = compose(v359_10,v361_11);
        }
        const Space v359_13 = unite(v359_8,v359_12);
        v358_11_result = unite(v358_11_result,v359_13);
      }
      const Space v358_11 = std::move(v358_11_result);
      v353_12 = compose(v353_10,v358_11);
    }
    const Space v353_13 = unite(v353_8,v353_12);
    v352_12_result = unite(v352_12_result,v353_13);
  }
  const Space v352_12 = std::move(v352_12_result);
  return v352_12;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v362_12_result;
  for (int v362_12_label = 1; v362_12_label <= 2; ++v362_12_label) {
    const Space v362_12_tail = child(s0,v362_12_label);
    if (v362_12_tail.empty()) continue;
    const Path v362_12_head{v362_12_label};
    const Space v363_2 = singleton(v362_12_head);
    const Space v363_3 = intersect(constant_14,v363_2);
    const Space v363_4 = (has_head(v363_3) ? constant_15 : Space{});
    const Space v363_5 = subtract(constant_0,v363_4);
    Space v363_8;
    if (!v363_5.empty()) {
      const Path v364_6 = concat_path(p0,v362_12_head);
      Space v364_7_result;
      for (int v364_7_label = 1; v364_7_label <= 2; ++v364_7_label) {
        const Space v364_7_tail = child(v362_12_tail,v364_7_label);
        if (v364_7_tail.empty()) continue;
        const Path v364_7_head{v364_7_label};
        const Space v365_2 = singleton(v364_7_head);
        const Space v365_3 = intersect(constant_14,v365_2);
        const Space v365_4 = (has_head(v365_3) ? constant_15 : Space{});
        const Space v365_5 = subtract(constant_0,v365_4);
        Space v365_8;
        if (!v365_5.empty()) {
          const Path v366_6 = concat_path(v364_6,v364_7_head);
          const Space v366_7 = routine_72(c, v366_6, v364_7_tail, s1);
          v365_8 = compose(v365_5,v366_7);
        }
        const Space v365_9 = intersect(constant_14,v365_2);
        const Space v365_10 = (has_head(v365_9) ? constant_15 : Space{});
        Space v365_12;
        if (!v365_10.empty()) {
          const Path v367_6 = concat_path(v364_6,v364_7_head);
          const Space v367_11 = routine_73(c, v367_6, v364_7_tail, s1);
          v365_12 = compose(v365_10,v367_11);
        }
        const Space v365_13 = unite(v365_8,v365_12);
        v364_7_result = unite(v364_7_result,v365_13);
      }
      const Space v364_7 = std::move(v364_7_result);
      v363_8 = compose(v363_5,v364_7);
    }
    const Space v363_9 = intersect(constant_14,v363_2);
    const Space v363_10 = (has_head(v363_9) ? constant_15 : Space{});
    Space v363_12;
    if (!v363_10.empty()) {
      const Path v368_6 = concat_path(p0,v362_12_head);
      Space v368_11_result;
      for (int v368_11_label = 1; v368_11_label <= 2; ++v368_11_label) {
        const Space v368_11_tail = child(v362_12_tail,v368_11_label);
        if (v368_11_tail.empty()) continue;
        const Path v368_11_head{v368_11_label};
        const Space v369_2 = singleton(v368_11_head);
        const Space v369_3 = intersect(constant_14,v369_2);
        const Space v369_4 = (has_head(v369_3) ? constant_15 : Space{});
        const Space v369_5 = subtract(constant_0,v369_4);
        Space v369_7;
        if (!v369_5.empty()) {
          const Space v370_6 = routine_36(c, v368_11_head, v368_6, v368_11_tail, s1);
          v369_7 = compose(v369_5,v370_6);
        }
        const Space v369_8 = intersect(constant_14,v369_2);
        const Space v369_9 = (has_head(v369_8) ? constant_15 : Space{});
        Space v369_11;
        if (!v369_9.empty()) {
          const Space v371_10 = routine_37(c, v368_11_head, v368_6, v368_11_tail, s1);
          v369_11 = compose(v369_9,v371_10);
        }
        const Space v369_12 = unite(v369_7,v369_11);
        v368_11_result = unite(v368_11_result,v369_12);
      }
      const Space v368_11 = std::move(v368_11_result);
      v363_12 = compose(v363_10,v368_11);
    }
    const Space v363_13 = unite(v363_8,v363_12);
    v362_12_result = unite(v362_12_result,v363_13);
  }
  const Space v362_12 = std::move(v362_12_result);
  return v362_12;
}

static Space routine_36(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v372_13_result;
  for (int v372_13_label = 1; v372_13_label <= 2; ++v372_13_label) {
    const Space v372_13_tail = child(s0,v372_13_label);
    if (v372_13_tail.empty()) continue;
    const Path v372_13_head{v372_13_label};
    const Space v373_2 = singleton(v372_13_head);
    const Space v373_3 = intersect(constant_14,v373_2);
    const Space v373_4 = (has_head(v373_3) ? constant_15 : Space{});
    const Space v373_5 = subtract(constant_0,v373_4);
    Space v373_8;
    if (!v373_5.empty()) {
      const Path v374_6 = concat_path(p0,v372_13_head);
      Space v374_7_result;
      for (int v374_7_label = 1; v374_7_label <= 2; ++v374_7_label) {
        const Space v374_7_tail = child(v372_13_tail,v374_7_label);
        if (v374_7_tail.empty()) continue;
        const Path v374_7_head{v374_7_label};
        const Space v375_2 = singleton(v374_7_head);
        const Space v375_3 = intersect(constant_14,v375_2);
        const Space v375_4 = (has_head(v375_3) ? constant_15 : Space{});
        const Space v375_5 = subtract(constant_0,v375_4);
        Space v375_8;
        if (!v375_5.empty()) {
          const Path v376_6 = concat_path(v374_6,v374_7_head);
          const Space v376_7 = routine_74(c, v376_6, p1, v374_7_tail, s1);
          v375_8 = compose(v375_5,v376_7);
        }
        const Space v375_9 = intersect(constant_14,v375_2);
        const Space v375_10 = (has_head(v375_9) ? constant_15 : Space{});
        Space v375_12;
        if (!v375_10.empty()) {
          const Path v377_6 = concat_path(v374_6,v374_7_head);
          const Space v377_11 = routine_75(c, v377_6, p1, v374_7_tail, s1);
          v375_12 = compose(v375_10,v377_11);
        }
        const Space v375_13 = unite(v375_8,v375_12);
        v374_7_result = unite(v374_7_result,v375_13);
      }
      const Space v374_7 = std::move(v374_7_result);
      v373_8 = compose(v373_5,v374_7);
    }
    const Space v373_9 = intersect(constant_14,v373_2);
    const Space v373_10 = (has_head(v373_9) ? constant_15 : Space{});
    Space v373_12;
    if (!v373_10.empty()) {
      const Path v378_6 = concat_path(p0,v372_13_head);
      Space v378_11_result;
      for (int v378_11_label = 1; v378_11_label <= 2; ++v378_11_label) {
        const Space v378_11_tail = child(v372_13_tail,v378_11_label);
        if (v378_11_tail.empty()) continue;
        const Path v378_11_head{v378_11_label};
        const Space v379_2 = singleton(v378_11_head);
        const Space v379_3 = intersect(constant_14,v379_2);
        const Space v379_4 = (has_head(v379_3) ? constant_15 : Space{});
        const Space v379_5 = subtract(constant_0,v379_4);
        Space v379_8;
        if (!v379_5.empty()) {
          const Path v380_6 = concat_path(v378_6,v378_11_head);
          const Space v380_7 = routine_74(c, v380_6, p1, v378_11_tail, s1);
          v379_8 = compose(v379_5,v380_7);
        }
        const Space v379_9 = intersect(constant_14,v379_2);
        const Space v379_10 = (has_head(v379_9) ? constant_15 : Space{});
        Space v379_12;
        if (!v379_10.empty()) {
          const Path v381_6 = concat_path(v378_6,v378_11_head);
          const Space v381_11 = routine_40(c, v381_6, p1, v378_11_tail, s1);
          v379_12 = compose(v379_10,v381_11);
        }
        const Space v379_13 = unite(v379_8,v379_12);
        v378_11_result = unite(v378_11_result,v379_13);
      }
      const Space v378_11 = std::move(v378_11_result);
      v373_12 = compose(v373_10,v378_11);
    }
    const Space v373_13 = unite(v373_8,v373_12);
    v372_13_result = unite(v372_13_result,v373_13);
  }
  const Space v372_13 = std::move(v372_13_result);
  return v372_13;
}

static Space routine_37(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v382_8 = unwrap(s1,constant_9);
  const Space v382_10 = unwrap(v382_8,constant_10);
  const Space v382_11 = unwrap(v382_10,p0);
  Space v382_18_result;
  for (int v382_18_label = 1; v382_18_label <= 2; ++v382_18_label) {
    const Space v382_18_tail = child(s0,v382_18_label);
    if (v382_18_tail.empty()) continue;
    const Path v382_18_head{v382_18_label};
    const Space v383_2 = singleton(v382_18_head);
    const Space v383_3 = intersect(constant_14,v383_2);
    const Space v383_4 = (has_head(v383_3) ? constant_15 : Space{});
    const Space v383_5 = subtract(constant_0,v383_4);
    Space v383_8;
    if (!v383_5.empty()) {
      const Path v384_6 = concat_path(p0,v382_18_head);
      Space v384_7_result;
      for (int v384_7_label = 1; v384_7_label <= 2; ++v384_7_label) {
        const Space v384_7_tail = child(v382_18_tail,v384_7_label);
        if (v384_7_tail.empty()) continue;
        const Path v384_7_head{v384_7_label};
        const Space v385_2 = singleton(v384_7_head);
        const Space v385_3 = intersect(constant_14,v385_2);
        const Space v385_4 = (has_head(v385_3) ? constant_15 : Space{});
        const Space v385_5 = subtract(constant_0,v385_4);
        Space v385_8;
        if (!v385_5.empty()) {
          const Path v386_6 = concat_path(v384_6,v384_7_head);
          const Space v386_7 = routine_74(c, v386_6, p1, v384_7_tail, s1);
          v385_8 = compose(v385_5,v386_7);
        }
        const Space v385_9 = intersect(constant_14,v385_2);
        const Space v385_10 = (has_head(v385_9) ? constant_15 : Space{});
        Space v385_12;
        if (!v385_10.empty()) {
          const Path v387_6 = concat_path(v384_6,v384_7_head);
          const Space v387_11 = routine_75(c, v387_6, p1, v384_7_tail, s1);
          v385_12 = compose(v385_10,v387_11);
        }
        const Space v385_13 = unite(v385_8,v385_12);
        v384_7_result = unite(v384_7_result,v385_13);
      }
      const Space v384_7 = std::move(v384_7_result);
      v383_8 = compose(v383_5,v384_7);
    }
    const Space v383_9 = intersect(constant_14,v383_2);
    const Space v383_10 = (has_head(v383_9) ? constant_15 : Space{});
    Space v383_13;
    if (!v383_10.empty()) {
      const Space v388_11 = unwrap(v382_11,v382_18_head);
      Space v388_12_result;
      for (int v388_12_label = 1; v388_12_label <= 2; ++v388_12_label) {
        const Space v388_12_tail = child(v388_11,v388_12_label);
        if (v388_12_tail.empty()) continue;
        const Path v388_12_head{v388_12_label};
        const Space v389_2 = singleton(v388_12_head);
        const Space v389_3 = intersect(constant_14,v389_2);
        const Space v389_4 = (has_head(v389_3) ? constant_15 : Space{});
        const Space v389_5 = subtract(constant_0,v389_4);
        Space v389_7;
        if (!v389_5.empty()) {
          const Space v390_6 = routine_76(c, v388_12_head, p1, v388_12_tail);
          v389_7 = compose(v389_5,v390_6);
        }
        const Space v389_8 = intersect(constant_14,v389_2);
        const Space v389_9 = (has_head(v389_8) ? constant_15 : Space{});
        Space v389_11;
        if (!v389_9.empty()) {
          const Space v391_10 = routine_77(c, v388_12_head, p1, v388_12_tail);
          v389_11 = compose(v389_9,v391_10);
        }
        const Space v389_12 = unite(v389_7,v389_11);
        v388_12_result = unite(v388_12_result,v389_12);
      }
      const Space v388_12 = std::move(v388_12_result);
      v383_13 = compose(v383_10,v388_12);
    }
    const Space v383_14 = unite(v383_8,v383_13);
    v382_18_result = unite(v382_18_result,v383_14);
  }
  const Space v382_18 = std::move(v382_18_result);
  return v382_18;
}

static Space routine_38(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v392_13_result;
  for (int v392_13_label = 1; v392_13_label <= 2; ++v392_13_label) {
    const Space v392_13_tail = child(s0,v392_13_label);
    if (v392_13_tail.empty()) continue;
    const Path v392_13_head{v392_13_label};
    const Space v393_2 = singleton(v392_13_head);
    const Space v393_3 = intersect(constant_14,v393_2);
    const Space v393_4 = (has_head(v393_3) ? constant_15 : Space{});
    const Space v393_5 = subtract(constant_0,v393_4);
    Space v393_8;
    if (!v393_5.empty()) {
      const Path v394_6 = concat_path(p0,v392_13_head);
      Space v394_7_result;
      for (int v394_7_label = 1; v394_7_label <= 2; ++v394_7_label) {
        const Space v394_7_tail = child(v392_13_tail,v394_7_label);
        if (v394_7_tail.empty()) continue;
        const Path v394_7_head{v394_7_label};
        const Space v395_2 = singleton(v394_7_head);
        const Space v395_3 = intersect(constant_14,v395_2);
        const Space v395_4 = (has_head(v395_3) ? constant_15 : Space{});
        const Space v395_5 = subtract(constant_0,v395_4);
        Space v395_8;
        if (!v395_5.empty()) {
          const Path v396_6 = concat_path(v394_6,v394_7_head);
          const Space v396_7 = routine_78(c, v396_6, p1, v394_7_tail, s1);
          v395_8 = compose(v395_5,v396_7);
        }
        const Space v395_9 = intersect(constant_14,v395_2);
        const Space v395_10 = (has_head(v395_9) ? constant_15 : Space{});
        Space v395_12;
        if (!v395_10.empty()) {
          const Path v397_6 = concat_path(v394_6,v394_7_head);
          const Space v397_11 = routine_79(c, v397_6, p1, v394_7_tail, s1);
          v395_12 = compose(v395_10,v397_11);
        }
        const Space v395_13 = unite(v395_8,v395_12);
        v394_7_result = unite(v394_7_result,v395_13);
      }
      const Space v394_7 = std::move(v394_7_result);
      v393_8 = compose(v393_5,v394_7);
    }
    const Space v393_9 = intersect(constant_14,v393_2);
    const Space v393_10 = (has_head(v393_9) ? constant_15 : Space{});
    Space v393_12;
    if (!v393_10.empty()) {
      const Path v398_6 = concat_path(p0,v392_13_head);
      Space v398_11_result;
      for (int v398_11_label = 1; v398_11_label <= 2; ++v398_11_label) {
        const Space v398_11_tail = child(v392_13_tail,v398_11_label);
        if (v398_11_tail.empty()) continue;
        const Path v398_11_head{v398_11_label};
        const Space v399_2 = singleton(v398_11_head);
        const Space v399_3 = intersect(constant_14,v399_2);
        const Space v399_4 = (has_head(v399_3) ? constant_15 : Space{});
        const Space v399_5 = subtract(constant_0,v399_4);
        Space v399_8;
        if (!v399_5.empty()) {
          const Path v400_6 = concat_path(v398_6,v398_11_head);
          const Space v400_7 = routine_78(c, v400_6, p1, v398_11_tail, s1);
          v399_8 = compose(v399_5,v400_7);
        }
        const Space v399_9 = intersect(constant_14,v399_2);
        const Space v399_10 = (has_head(v399_9) ? constant_15 : Space{});
        Space v399_12;
        if (!v399_10.empty()) {
          const Path v401_6 = concat_path(v398_6,v398_11_head);
          const Space v401_11 = routine_40(c, v401_6, p1, v398_11_tail, s1);
          v399_12 = compose(v399_10,v401_11);
        }
        const Space v399_13 = unite(v399_8,v399_12);
        v398_11_result = unite(v398_11_result,v399_13);
      }
      const Space v398_11 = std::move(v398_11_result);
      v393_12 = compose(v393_10,v398_11);
    }
    const Space v393_13 = unite(v393_8,v393_12);
    v392_13_result = unite(v392_13_result,v393_13);
  }
  const Space v392_13 = std::move(v392_13_result);
  return v392_13;
}

static Space routine_39(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v402_8 = unwrap(s1,constant_9);
  const Space v402_10 = unwrap(v402_8,constant_10);
  const Space v402_11 = unwrap(v402_10,p0);
  Space v402_18_result;
  for (int v402_18_label = 1; v402_18_label <= 2; ++v402_18_label) {
    const Space v402_18_tail = child(s0,v402_18_label);
    if (v402_18_tail.empty()) continue;
    const Path v402_18_head{v402_18_label};
    const Space v403_2 = singleton(v402_18_head);
    const Space v403_3 = intersect(constant_14,v403_2);
    const Space v403_4 = (has_head(v403_3) ? constant_15 : Space{});
    const Space v403_5 = subtract(constant_0,v403_4);
    Space v403_8;
    if (!v403_5.empty()) {
      const Path v404_6 = concat_path(p0,v402_18_head);
      Space v404_7_result;
      for (int v404_7_label = 1; v404_7_label <= 2; ++v404_7_label) {
        const Space v404_7_tail = child(v402_18_tail,v404_7_label);
        if (v404_7_tail.empty()) continue;
        const Path v404_7_head{v404_7_label};
        const Space v405_2 = singleton(v404_7_head);
        const Space v405_3 = intersect(constant_14,v405_2);
        const Space v405_4 = (has_head(v405_3) ? constant_15 : Space{});
        const Space v405_5 = subtract(constant_0,v405_4);
        Space v405_8;
        if (!v405_5.empty()) {
          const Path v406_6 = concat_path(v404_6,v404_7_head);
          const Space v406_7 = routine_78(c, v406_6, p1, v404_7_tail, s1);
          v405_8 = compose(v405_5,v406_7);
        }
        const Space v405_9 = intersect(constant_14,v405_2);
        const Space v405_10 = (has_head(v405_9) ? constant_15 : Space{});
        Space v405_12;
        if (!v405_10.empty()) {
          const Path v407_6 = concat_path(v404_6,v404_7_head);
          const Space v407_11 = routine_79(c, v407_6, p1, v404_7_tail, s1);
          v405_12 = compose(v405_10,v407_11);
        }
        const Space v405_13 = unite(v405_8,v405_12);
        v404_7_result = unite(v404_7_result,v405_13);
      }
      const Space v404_7 = std::move(v404_7_result);
      v403_8 = compose(v403_5,v404_7);
    }
    const Space v403_9 = intersect(constant_14,v403_2);
    const Space v403_10 = (has_head(v403_9) ? constant_15 : Space{});
    Space v403_13;
    if (!v403_10.empty()) {
      const Space v408_11 = unwrap(v402_11,v402_18_head);
      Space v408_12_result;
      for (int v408_12_label = 1; v408_12_label <= 2; ++v408_12_label) {
        const Space v408_12_tail = child(v408_11,v408_12_label);
        if (v408_12_tail.empty()) continue;
        const Path v408_12_head{v408_12_label};
        const Space v409_2 = singleton(v408_12_head);
        const Space v409_3 = intersect(constant_14,v409_2);
        const Space v409_4 = (has_head(v409_3) ? constant_15 : Space{});
        const Space v409_5 = subtract(constant_0,v409_4);
        Space v409_7;
        if (!v409_5.empty()) {
          const Space v410_6 = routine_76(c, v408_12_head, p1, v408_12_tail);
          v409_7 = compose(v409_5,v410_6);
        }
        const Space v409_8 = intersect(constant_14,v409_2);
        const Space v409_9 = (has_head(v409_8) ? constant_15 : Space{});
        Space v409_11;
        if (!v409_9.empty()) {
          const Space v411_10 = routine_77(c, v408_12_head, p1, v408_12_tail);
          v409_11 = compose(v409_9,v411_10);
        }
        const Space v409_12 = unite(v409_7,v409_11);
        v408_12_result = unite(v408_12_result,v409_12);
      }
      const Space v408_12 = std::move(v408_12_result);
      v403_13 = compose(v403_10,v408_12);
    }
    const Space v403_14 = unite(v403_8,v403_13);
    v402_18_result = unite(v402_18_result,v403_14);
  }
  const Space v402_18 = std::move(v402_18_result);
  return v402_18;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v412_5 = unwrap(s1,constant_9);
  const Space v412_7 = unwrap(v412_5,constant_10);
  const Space v412_8 = unwrap(v412_7,p0);
  Space v412_18_result;
  for (int v412_18_label = 1; v412_18_label <= 2; ++v412_18_label) {
    const Space v412_18_tail = child(v412_8,v412_18_label);
    if (v412_18_tail.empty()) continue;
    const Path v412_18_head{v412_18_label};
    const Space v413_2 = singleton(v412_18_head);
    const Space v413_3 = intersect(constant_14,v413_2);
    const Space v413_4 = (has_head(v413_3) ? constant_15 : Space{});
    const Space v413_5 = subtract(constant_0,v413_4);
    Space v413_7;
    if (!v413_5.empty()) {
      Space v414_6_result;
      for (int v414_6_label = 1; v414_6_label <= 2; ++v414_6_label) {
        const Space v414_6_tail = child(v412_18_tail,v414_6_label);
        if (v414_6_tail.empty()) continue;
        const Path v414_6_head{v414_6_label};
        const Space v415_2 = singleton(v414_6_head);
        const Space v415_3 = intersect(constant_14,v415_2);
        const Space v415_4 = (has_head(v415_3) ? constant_15 : Space{});
        const Space v415_5 = subtract(constant_0,v415_4);
        Space v415_8;
        if (!v415_5.empty()) {
          const Path v416_6 = concat_path(v412_18_head,v414_6_head);
          const Space v416_7 = routine_80(c, v416_6, p1, v414_6_tail);
          v415_8 = compose(v415_5,v416_7);
        }
        const Space v415_9 = intersect(constant_14,v415_2);
        const Space v415_10 = (has_head(v415_9) ? constant_15 : Space{});
        Space v415_12;
        if (!v415_10.empty()) {
          const Path v417_6 = concat_path(v412_18_head,v414_6_head);
          const Space v417_11 = routine_81(c, v417_6, p1, v414_6_tail);
          v415_12 = compose(v415_10,v417_11);
        }
        const Space v415_13 = unite(v415_8,v415_12);
        v414_6_result = unite(v414_6_result,v415_13);
      }
      const Space v414_6 = std::move(v414_6_result);
      v413_7 = compose(v413_5,v414_6);
    }
    const Space v413_8 = intersect(constant_14,v413_2);
    const Space v413_9 = (has_head(v413_8) ? constant_15 : Space{});
    Space v413_11;
    if (!v413_9.empty()) {
      Space v418_10_result;
      for (int v418_10_label = 1; v418_10_label <= 2; ++v418_10_label) {
        const Space v418_10_tail = child(v412_18_tail,v418_10_label);
        if (v418_10_tail.empty()) continue;
        const Path v418_10_head{v418_10_label};
        const Space v419_2 = singleton(v418_10_head);
        const Space v419_3 = intersect(constant_14,v419_2);
        const Space v419_4 = (has_head(v419_3) ? constant_15 : Space{});
        const Space v419_5 = subtract(constant_0,v419_4);
        Space v419_8;
        if (!v419_5.empty()) {
          const Path v420_6 = concat_path(v412_18_head,v418_10_head);
          const Space v420_7 = routine_80(c, v420_6, p1, v418_10_tail);
          v419_8 = compose(v419_5,v420_7);
        }
        const Space v419_9 = intersect(constant_14,v419_2);
        const Space v419_10 = (has_head(v419_9) ? constant_15 : Space{});
        Space v419_12;
        if (!v419_10.empty()) {
          const Path v421_6 = concat_path(v412_18_head,v418_10_head);
          const Space v421_11 = routine_82(c, v421_6, p1, v418_10_tail);
          v419_12 = compose(v419_10,v421_11);
        }
        const Space v419_13 = unite(v419_8,v419_12);
        v418_10_result = unite(v418_10_result,v419_13);
      }
      const Space v418_10 = std::move(v418_10_result);
      v413_11 = compose(v413_9,v418_10);
    }
    const Space v413_12 = unite(v413_7,v413_11);
    v412_18_result = unite(v412_18_result,v413_12);
  }
  const Space v412_18 = std::move(v412_18_result);
  return v412_18;
}

static Space routine_41(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v422_12_result;
  for (int v422_12_label = 1; v422_12_label <= 2; ++v422_12_label) {
    const Space v422_12_tail = child(s0,v422_12_label);
    if (v422_12_tail.empty()) continue;
    const Path v422_12_head{v422_12_label};
    const Space v423_2 = singleton(v422_12_head);
    const Space v423_3 = intersect(constant_14,v423_2);
    const Space v423_4 = (has_head(v423_3) ? constant_15 : Space{});
    const Space v423_5 = subtract(constant_0,v423_4);
    Space v423_8;
    if (!v423_5.empty()) {
      const Path v424_6 = concat_path(p0,v422_12_head);
      Space v424_7_result;
      for (int v424_7_label = 1; v424_7_label <= 2; ++v424_7_label) {
        const Space v424_7_tail = child(v422_12_tail,v424_7_label);
        if (v424_7_tail.empty()) continue;
        const Path v424_7_head{v424_7_label};
        const Space v425_2 = singleton(v424_7_head);
        const Space v425_3 = intersect(constant_14,v425_2);
        const Space v425_4 = (has_head(v425_3) ? constant_15 : Space{});
        const Space v425_5 = subtract(constant_0,v425_4);
        Space v425_8;
        if (!v425_5.empty()) {
          const Path v426_6 = concat_path(v424_6,v424_7_head);
          const Space v426_7 = routine_83(c, v426_6, v424_7_tail, s1);
          v425_8 = compose(v425_5,v426_7);
        }
        const Space v425_9 = intersect(constant_14,v425_2);
        const Space v425_10 = (has_head(v425_9) ? constant_15 : Space{});
        Space v425_12;
        if (!v425_10.empty()) {
          const Path v427_6 = concat_path(v424_6,v424_7_head);
          const Space v427_11 = routine_84(c, v427_6, v424_7_tail, s1);
          v425_12 = compose(v425_10,v427_11);
        }
        const Space v425_13 = unite(v425_8,v425_12);
        v424_7_result = unite(v424_7_result,v425_13);
      }
      const Space v424_7 = std::move(v424_7_result);
      v423_8 = compose(v423_5,v424_7);
    }
    const Space v423_9 = intersect(constant_14,v423_2);
    const Space v423_10 = (has_head(v423_9) ? constant_15 : Space{});
    Space v423_12;
    if (!v423_10.empty()) {
      const Path v428_6 = concat_path(p0,v422_12_head);
      Space v428_11_result;
      for (int v428_11_label = 1; v428_11_label <= 2; ++v428_11_label) {
        const Space v428_11_tail = child(v422_12_tail,v428_11_label);
        if (v428_11_tail.empty()) continue;
        const Path v428_11_head{v428_11_label};
        const Space v429_2 = singleton(v428_11_head);
        const Space v429_3 = intersect(constant_14,v429_2);
        const Space v429_4 = (has_head(v429_3) ? constant_15 : Space{});
        const Space v429_5 = subtract(constant_0,v429_4);
        Space v429_8;
        if (!v429_5.empty()) {
          const Path v430_6 = concat_path(v428_6,v428_11_head);
          const Space v430_7 = routine_83(c, v430_6, v428_11_tail, s1);
          v429_8 = compose(v429_5,v430_7);
        }
        const Space v429_9 = intersect(constant_14,v429_2);
        const Space v429_10 = (has_head(v429_9) ? constant_15 : Space{});
        Space v429_12;
        if (!v429_10.empty()) {
          const Path v431_6 = concat_path(v428_6,v428_11_head);
          const Space v431_11 = routine_14(c, v431_6, v428_11_tail, s1);
          v429_12 = compose(v429_10,v431_11);
        }
        const Space v429_13 = unite(v429_8,v429_12);
        v428_11_result = unite(v428_11_result,v429_13);
      }
      const Space v428_11 = std::move(v428_11_result);
      v423_12 = compose(v423_10,v428_11);
    }
    const Space v423_13 = unite(v423_8,v423_12);
    v422_12_result = unite(v422_12_result,v423_13);
  }
  const Space v422_12 = std::move(v422_12_result);
  return v422_12;
}

static Space routine_42(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v432_12_result;
  for (int v432_12_label = 1; v432_12_label <= 2; ++v432_12_label) {
    const Space v432_12_tail = child(s0,v432_12_label);
    if (v432_12_tail.empty()) continue;
    const Path v432_12_head{v432_12_label};
    const Space v433_2 = singleton(v432_12_head);
    const Space v433_3 = intersect(constant_14,v433_2);
    const Space v433_4 = (has_head(v433_3) ? constant_15 : Space{});
    const Space v433_5 = subtract(constant_0,v433_4);
    Space v433_8;
    if (!v433_5.empty()) {
      const Path v434_6 = concat_path(p0,v432_12_head);
      Space v434_7_result;
      for (int v434_7_label = 1; v434_7_label <= 2; ++v434_7_label) {
        const Space v434_7_tail = child(v432_12_tail,v434_7_label);
        if (v434_7_tail.empty()) continue;
        const Path v434_7_head{v434_7_label};
        const Space v435_2 = singleton(v434_7_head);
        const Space v435_3 = intersect(constant_14,v435_2);
        const Space v435_4 = (has_head(v435_3) ? constant_15 : Space{});
        const Space v435_5 = subtract(constant_0,v435_4);
        Space v435_8;
        if (!v435_5.empty()) {
          const Path v436_6 = concat_path(v434_6,v434_7_head);
          const Space v436_7 = routine_83(c, v436_6, v434_7_tail, s1);
          v435_8 = compose(v435_5,v436_7);
        }
        const Space v435_9 = intersect(constant_14,v435_2);
        const Space v435_10 = (has_head(v435_9) ? constant_15 : Space{});
        Space v435_12;
        if (!v435_10.empty()) {
          const Path v437_6 = concat_path(v434_6,v434_7_head);
          const Space v437_11 = routine_84(c, v437_6, v434_7_tail, s1);
          v435_12 = compose(v435_10,v437_11);
        }
        const Space v435_13 = unite(v435_8,v435_12);
        v434_7_result = unite(v434_7_result,v435_13);
      }
      const Space v434_7 = std::move(v434_7_result);
      v433_8 = compose(v433_5,v434_7);
    }
    const Space v433_9 = intersect(constant_14,v433_2);
    const Space v433_10 = (has_head(v433_9) ? constant_15 : Space{});
    Space v433_12;
    if (!v433_10.empty()) {
      const Path v438_6 = concat_path(p0,v432_12_head);
      Space v438_11_result;
      for (int v438_11_label = 1; v438_11_label <= 2; ++v438_11_label) {
        const Space v438_11_tail = child(v432_12_tail,v438_11_label);
        if (v438_11_tail.empty()) continue;
        const Path v438_11_head{v438_11_label};
        const Space v439_2 = singleton(v438_11_head);
        const Space v439_3 = intersect(constant_14,v439_2);
        const Space v439_4 = (has_head(v439_3) ? constant_15 : Space{});
        const Space v439_5 = subtract(constant_0,v439_4);
        Space v439_7;
        if (!v439_5.empty()) {
          const Space v440_6 = routine_43(c, v438_11_head, v438_6, v438_11_tail, s1);
          v439_7 = compose(v439_5,v440_6);
        }
        const Space v439_8 = intersect(constant_14,v439_2);
        const Space v439_9 = (has_head(v439_8) ? constant_15 : Space{});
        Space v439_11;
        if (!v439_9.empty()) {
          const Space v441_10 = routine_44(c, v438_11_head, v438_6, v438_11_tail, s1);
          v439_11 = compose(v439_9,v441_10);
        }
        const Space v439_12 = unite(v439_7,v439_11);
        v438_11_result = unite(v438_11_result,v439_12);
      }
      const Space v438_11 = std::move(v438_11_result);
      v433_12 = compose(v433_10,v438_11);
    }
    const Space v433_13 = unite(v433_8,v433_12);
    v432_12_result = unite(v432_12_result,v433_13);
  }
  const Space v432_12 = std::move(v432_12_result);
  return v432_12;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v442_13_result;
  for (int v442_13_label = 1; v442_13_label <= 2; ++v442_13_label) {
    const Space v442_13_tail = child(s0,v442_13_label);
    if (v442_13_tail.empty()) continue;
    const Path v442_13_head{v442_13_label};
    const Space v443_2 = singleton(v442_13_head);
    const Space v443_3 = intersect(constant_14,v443_2);
    const Space v443_4 = (has_head(v443_3) ? constant_15 : Space{});
    const Space v443_5 = subtract(constant_0,v443_4);
    Space v443_8;
    if (!v443_5.empty()) {
      const Path v444_6 = concat_path(p0,v442_13_head);
      Space v444_7_result;
      for (int v444_7_label = 1; v444_7_label <= 2; ++v444_7_label) {
        const Space v444_7_tail = child(v442_13_tail,v444_7_label);
        if (v444_7_tail.empty()) continue;
        const Path v444_7_head{v444_7_label};
        const Space v445_2 = singleton(v444_7_head);
        const Space v445_3 = intersect(constant_14,v445_2);
        const Space v445_4 = (has_head(v445_3) ? constant_15 : Space{});
        const Space v445_5 = subtract(constant_0,v445_4);
        Space v445_8;
        if (!v445_5.empty()) {
          const Path v446_6 = concat_path(v444_6,v444_7_head);
          const Space v446_7 = routine_85(c, v446_6, p1, v444_7_tail, s1);
          v445_8 = compose(v445_5,v446_7);
        }
        const Space v445_9 = intersect(constant_14,v445_2);
        const Space v445_10 = (has_head(v445_9) ? constant_15 : Space{});
        Space v445_12;
        if (!v445_10.empty()) {
          const Path v447_6 = concat_path(v444_6,v444_7_head);
          const Space v447_11 = routine_86(c, v447_6, p1, v444_7_tail, s1);
          v445_12 = compose(v445_10,v447_11);
        }
        const Space v445_13 = unite(v445_8,v445_12);
        v444_7_result = unite(v444_7_result,v445_13);
      }
      const Space v444_7 = std::move(v444_7_result);
      v443_8 = compose(v443_5,v444_7);
    }
    const Space v443_9 = intersect(constant_14,v443_2);
    const Space v443_10 = (has_head(v443_9) ? constant_15 : Space{});
    Space v443_12;
    if (!v443_10.empty()) {
      const Path v448_6 = concat_path(p0,v442_13_head);
      Space v448_11_result;
      for (int v448_11_label = 1; v448_11_label <= 2; ++v448_11_label) {
        const Space v448_11_tail = child(v442_13_tail,v448_11_label);
        if (v448_11_tail.empty()) continue;
        const Path v448_11_head{v448_11_label};
        const Space v449_2 = singleton(v448_11_head);
        const Space v449_3 = intersect(constant_14,v449_2);
        const Space v449_4 = (has_head(v449_3) ? constant_15 : Space{});
        const Space v449_5 = subtract(constant_0,v449_4);
        Space v449_8;
        if (!v449_5.empty()) {
          const Path v450_6 = concat_path(v448_6,v448_11_head);
          const Space v450_7 = routine_85(c, v450_6, p1, v448_11_tail, s1);
          v449_8 = compose(v449_5,v450_7);
        }
        const Space v449_9 = intersect(constant_14,v449_2);
        const Space v449_10 = (has_head(v449_9) ? constant_15 : Space{});
        Space v449_12;
        if (!v449_10.empty()) {
          const Path v451_6 = concat_path(v448_6,v448_11_head);
          const Space v451_11 = routine_47(c, v451_6, p1, v448_11_tail, s1);
          v449_12 = compose(v449_10,v451_11);
        }
        const Space v449_13 = unite(v449_8,v449_12);
        v448_11_result = unite(v448_11_result,v449_13);
      }
      const Space v448_11 = std::move(v448_11_result);
      v443_12 = compose(v443_10,v448_11);
    }
    const Space v443_13 = unite(v443_8,v443_12);
    v442_13_result = unite(v442_13_result,v443_13);
  }
  const Space v442_13 = std::move(v442_13_result);
  return v442_13;
}

static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v452_8 = unwrap(s1,constant_7);
  const Space v452_10 = unwrap(v452_8,constant_10);
  const Space v452_11 = unwrap(v452_10,p0);
  Space v452_18_result;
  for (int v452_18_label = 1; v452_18_label <= 2; ++v452_18_label) {
    const Space v452_18_tail = child(s0,v452_18_label);
    if (v452_18_tail.empty()) continue;
    const Path v452_18_head{v452_18_label};
    const Space v453_2 = singleton(v452_18_head);
    const Space v453_3 = intersect(constant_14,v453_2);
    const Space v453_4 = (has_head(v453_3) ? constant_15 : Space{});
    const Space v453_5 = subtract(constant_0,v453_4);
    Space v453_8;
    if (!v453_5.empty()) {
      const Path v454_6 = concat_path(p0,v452_18_head);
      Space v454_7_result;
      for (int v454_7_label = 1; v454_7_label <= 2; ++v454_7_label) {
        const Space v454_7_tail = child(v452_18_tail,v454_7_label);
        if (v454_7_tail.empty()) continue;
        const Path v454_7_head{v454_7_label};
        const Space v455_2 = singleton(v454_7_head);
        const Space v455_3 = intersect(constant_14,v455_2);
        const Space v455_4 = (has_head(v455_3) ? constant_15 : Space{});
        const Space v455_5 = subtract(constant_0,v455_4);
        Space v455_8;
        if (!v455_5.empty()) {
          const Path v456_6 = concat_path(v454_6,v454_7_head);
          const Space v456_7 = routine_85(c, v456_6, p1, v454_7_tail, s1);
          v455_8 = compose(v455_5,v456_7);
        }
        const Space v455_9 = intersect(constant_14,v455_2);
        const Space v455_10 = (has_head(v455_9) ? constant_15 : Space{});
        Space v455_12;
        if (!v455_10.empty()) {
          const Path v457_6 = concat_path(v454_6,v454_7_head);
          const Space v457_11 = routine_86(c, v457_6, p1, v454_7_tail, s1);
          v455_12 = compose(v455_10,v457_11);
        }
        const Space v455_13 = unite(v455_8,v455_12);
        v454_7_result = unite(v454_7_result,v455_13);
      }
      const Space v454_7 = std::move(v454_7_result);
      v453_8 = compose(v453_5,v454_7);
    }
    const Space v453_9 = intersect(constant_14,v453_2);
    const Space v453_10 = (has_head(v453_9) ? constant_15 : Space{});
    Space v453_13;
    if (!v453_10.empty()) {
      const Space v458_11 = unwrap(v452_11,v452_18_head);
      Space v458_12_result;
      for (int v458_12_label = 1; v458_12_label <= 2; ++v458_12_label) {
        const Space v458_12_tail = child(v458_11,v458_12_label);
        if (v458_12_tail.empty()) continue;
        const Path v458_12_head{v458_12_label};
        const Space v459_2 = singleton(v458_12_head);
        const Space v459_3 = intersect(constant_14,v459_2);
        const Space v459_4 = (has_head(v459_3) ? constant_15 : Space{});
        const Space v459_5 = subtract(constant_0,v459_4);
        Space v459_7;
        if (!v459_5.empty()) {
          const Space v460_6 = routine_87(c, v458_12_head, p1, v458_12_tail);
          v459_7 = compose(v459_5,v460_6);
        }
        const Space v459_8 = intersect(constant_14,v459_2);
        const Space v459_9 = (has_head(v459_8) ? constant_15 : Space{});
        Space v459_11;
        if (!v459_9.empty()) {
          const Space v461_10 = routine_88(c, v458_12_head, p1, v458_12_tail);
          v459_11 = compose(v459_9,v461_10);
        }
        const Space v459_12 = unite(v459_7,v459_11);
        v458_12_result = unite(v458_12_result,v459_12);
      }
      const Space v458_12 = std::move(v458_12_result);
      v453_13 = compose(v453_10,v458_12);
    }
    const Space v453_14 = unite(v453_8,v453_13);
    v452_18_result = unite(v452_18_result,v453_14);
  }
  const Space v452_18 = std::move(v452_18_result);
  return v452_18;
}

static Space routine_45(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v462_13_result;
  for (int v462_13_label = 1; v462_13_label <= 2; ++v462_13_label) {
    const Space v462_13_tail = child(s0,v462_13_label);
    if (v462_13_tail.empty()) continue;
    const Path v462_13_head{v462_13_label};
    const Space v463_2 = singleton(v462_13_head);
    const Space v463_3 = intersect(constant_14,v463_2);
    const Space v463_4 = (has_head(v463_3) ? constant_15 : Space{});
    const Space v463_5 = subtract(constant_0,v463_4);
    Space v463_8;
    if (!v463_5.empty()) {
      const Path v464_6 = concat_path(p0,v462_13_head);
      Space v464_7_result;
      for (int v464_7_label = 1; v464_7_label <= 2; ++v464_7_label) {
        const Space v464_7_tail = child(v462_13_tail,v464_7_label);
        if (v464_7_tail.empty()) continue;
        const Path v464_7_head{v464_7_label};
        const Space v465_2 = singleton(v464_7_head);
        const Space v465_3 = intersect(constant_14,v465_2);
        const Space v465_4 = (has_head(v465_3) ? constant_15 : Space{});
        const Space v465_5 = subtract(constant_0,v465_4);
        Space v465_8;
        if (!v465_5.empty()) {
          const Path v466_6 = concat_path(v464_6,v464_7_head);
          const Space v466_7 = routine_89(c, v466_6, p1, v464_7_tail, s1);
          v465_8 = compose(v465_5,v466_7);
        }
        const Space v465_9 = intersect(constant_14,v465_2);
        const Space v465_10 = (has_head(v465_9) ? constant_15 : Space{});
        Space v465_12;
        if (!v465_10.empty()) {
          const Path v467_6 = concat_path(v464_6,v464_7_head);
          const Space v467_11 = routine_90(c, v467_6, p1, v464_7_tail, s1);
          v465_12 = compose(v465_10,v467_11);
        }
        const Space v465_13 = unite(v465_8,v465_12);
        v464_7_result = unite(v464_7_result,v465_13);
      }
      const Space v464_7 = std::move(v464_7_result);
      v463_8 = compose(v463_5,v464_7);
    }
    const Space v463_9 = intersect(constant_14,v463_2);
    const Space v463_10 = (has_head(v463_9) ? constant_15 : Space{});
    Space v463_12;
    if (!v463_10.empty()) {
      const Path v468_6 = concat_path(p0,v462_13_head);
      Space v468_11_result;
      for (int v468_11_label = 1; v468_11_label <= 2; ++v468_11_label) {
        const Space v468_11_tail = child(v462_13_tail,v468_11_label);
        if (v468_11_tail.empty()) continue;
        const Path v468_11_head{v468_11_label};
        const Space v469_2 = singleton(v468_11_head);
        const Space v469_3 = intersect(constant_14,v469_2);
        const Space v469_4 = (has_head(v469_3) ? constant_15 : Space{});
        const Space v469_5 = subtract(constant_0,v469_4);
        Space v469_8;
        if (!v469_5.empty()) {
          const Path v470_6 = concat_path(v468_6,v468_11_head);
          const Space v470_7 = routine_89(c, v470_6, p1, v468_11_tail, s1);
          v469_8 = compose(v469_5,v470_7);
        }
        const Space v469_9 = intersect(constant_14,v469_2);
        const Space v469_10 = (has_head(v469_9) ? constant_15 : Space{});
        Space v469_12;
        if (!v469_10.empty()) {
          const Path v471_6 = concat_path(v468_6,v468_11_head);
          const Space v471_11 = routine_47(c, v471_6, p1, v468_11_tail, s1);
          v469_12 = compose(v469_10,v471_11);
        }
        const Space v469_13 = unite(v469_8,v469_12);
        v468_11_result = unite(v468_11_result,v469_13);
      }
      const Space v468_11 = std::move(v468_11_result);
      v463_12 = compose(v463_10,v468_11);
    }
    const Space v463_13 = unite(v463_8,v463_12);
    v462_13_result = unite(v462_13_result,v463_13);
  }
  const Space v462_13 = std::move(v462_13_result);
  return v462_13;
}

static Space routine_46(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v472_8 = unwrap(s1,constant_7);
  const Space v472_10 = unwrap(v472_8,constant_10);
  const Space v472_11 = unwrap(v472_10,p0);
  Space v472_18_result;
  for (int v472_18_label = 1; v472_18_label <= 2; ++v472_18_label) {
    const Space v472_18_tail = child(s0,v472_18_label);
    if (v472_18_tail.empty()) continue;
    const Path v472_18_head{v472_18_label};
    const Space v473_2 = singleton(v472_18_head);
    const Space v473_3 = intersect(constant_14,v473_2);
    const Space v473_4 = (has_head(v473_3) ? constant_15 : Space{});
    const Space v473_5 = subtract(constant_0,v473_4);
    Space v473_8;
    if (!v473_5.empty()) {
      const Path v474_6 = concat_path(p0,v472_18_head);
      Space v474_7_result;
      for (int v474_7_label = 1; v474_7_label <= 2; ++v474_7_label) {
        const Space v474_7_tail = child(v472_18_tail,v474_7_label);
        if (v474_7_tail.empty()) continue;
        const Path v474_7_head{v474_7_label};
        const Space v475_2 = singleton(v474_7_head);
        const Space v475_3 = intersect(constant_14,v475_2);
        const Space v475_4 = (has_head(v475_3) ? constant_15 : Space{});
        const Space v475_5 = subtract(constant_0,v475_4);
        Space v475_8;
        if (!v475_5.empty()) {
          const Path v476_6 = concat_path(v474_6,v474_7_head);
          const Space v476_7 = routine_89(c, v476_6, p1, v474_7_tail, s1);
          v475_8 = compose(v475_5,v476_7);
        }
        const Space v475_9 = intersect(constant_14,v475_2);
        const Space v475_10 = (has_head(v475_9) ? constant_15 : Space{});
        Space v475_12;
        if (!v475_10.empty()) {
          const Path v477_6 = concat_path(v474_6,v474_7_head);
          const Space v477_11 = routine_90(c, v477_6, p1, v474_7_tail, s1);
          v475_12 = compose(v475_10,v477_11);
        }
        const Space v475_13 = unite(v475_8,v475_12);
        v474_7_result = unite(v474_7_result,v475_13);
      }
      const Space v474_7 = std::move(v474_7_result);
      v473_8 = compose(v473_5,v474_7);
    }
    const Space v473_9 = intersect(constant_14,v473_2);
    const Space v473_10 = (has_head(v473_9) ? constant_15 : Space{});
    Space v473_13;
    if (!v473_10.empty()) {
      const Space v478_11 = unwrap(v472_11,v472_18_head);
      Space v478_12_result;
      for (int v478_12_label = 1; v478_12_label <= 2; ++v478_12_label) {
        const Space v478_12_tail = child(v478_11,v478_12_label);
        if (v478_12_tail.empty()) continue;
        const Path v478_12_head{v478_12_label};
        const Space v479_2 = singleton(v478_12_head);
        const Space v479_3 = intersect(constant_14,v479_2);
        const Space v479_4 = (has_head(v479_3) ? constant_15 : Space{});
        const Space v479_5 = subtract(constant_0,v479_4);
        Space v479_7;
        if (!v479_5.empty()) {
          const Space v480_6 = routine_87(c, v478_12_head, p1, v478_12_tail);
          v479_7 = compose(v479_5,v480_6);
        }
        const Space v479_8 = intersect(constant_14,v479_2);
        const Space v479_9 = (has_head(v479_8) ? constant_15 : Space{});
        Space v479_11;
        if (!v479_9.empty()) {
          const Space v481_10 = routine_88(c, v478_12_head, p1, v478_12_tail);
          v479_11 = compose(v479_9,v481_10);
        }
        const Space v479_12 = unite(v479_7,v479_11);
        v478_12_result = unite(v478_12_result,v479_12);
      }
      const Space v478_12 = std::move(v478_12_result);
      v473_13 = compose(v473_10,v478_12);
    }
    const Space v473_14 = unite(v473_8,v473_13);
    v472_18_result = unite(v472_18_result,v473_14);
  }
  const Space v472_18 = std::move(v472_18_result);
  return v472_18;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v482_5 = unwrap(s1,constant_7);
  const Space v482_7 = unwrap(v482_5,constant_10);
  const Space v482_8 = unwrap(v482_7,p0);
  Space v482_18_result;
  for (int v482_18_label = 1; v482_18_label <= 2; ++v482_18_label) {
    const Space v482_18_tail = child(v482_8,v482_18_label);
    if (v482_18_tail.empty()) continue;
    const Path v482_18_head{v482_18_label};
    const Space v483_2 = singleton(v482_18_head);
    const Space v483_3 = intersect(constant_14,v483_2);
    const Space v483_4 = (has_head(v483_3) ? constant_15 : Space{});
    const Space v483_5 = subtract(constant_0,v483_4);
    Space v483_7;
    if (!v483_5.empty()) {
      Space v484_6_result;
      for (int v484_6_label = 1; v484_6_label <= 2; ++v484_6_label) {
        const Space v484_6_tail = child(v482_18_tail,v484_6_label);
        if (v484_6_tail.empty()) continue;
        const Path v484_6_head{v484_6_label};
        const Space v485_2 = singleton(v484_6_head);
        const Space v485_3 = intersect(constant_14,v485_2);
        const Space v485_4 = (has_head(v485_3) ? constant_15 : Space{});
        const Space v485_5 = subtract(constant_0,v485_4);
        Space v485_8;
        if (!v485_5.empty()) {
          const Path v486_6 = concat_path(v482_18_head,v484_6_head);
          const Space v486_7 = routine_91(c, v486_6, p1, v484_6_tail);
          v485_8 = compose(v485_5,v486_7);
        }
        const Space v485_9 = intersect(constant_14,v485_2);
        const Space v485_10 = (has_head(v485_9) ? constant_15 : Space{});
        Space v485_12;
        if (!v485_10.empty()) {
          const Path v487_6 = concat_path(v482_18_head,v484_6_head);
          const Space v487_11 = routine_92(c, v487_6, p1, v484_6_tail);
          v485_12 = compose(v485_10,v487_11);
        }
        const Space v485_13 = unite(v485_8,v485_12);
        v484_6_result = unite(v484_6_result,v485_13);
      }
      const Space v484_6 = std::move(v484_6_result);
      v483_7 = compose(v483_5,v484_6);
    }
    const Space v483_8 = intersect(constant_14,v483_2);
    const Space v483_9 = (has_head(v483_8) ? constant_15 : Space{});
    Space v483_11;
    if (!v483_9.empty()) {
      Space v488_10_result;
      for (int v488_10_label = 1; v488_10_label <= 2; ++v488_10_label) {
        const Space v488_10_tail = child(v482_18_tail,v488_10_label);
        if (v488_10_tail.empty()) continue;
        const Path v488_10_head{v488_10_label};
        const Space v489_2 = singleton(v488_10_head);
        const Space v489_3 = intersect(constant_14,v489_2);
        const Space v489_4 = (has_head(v489_3) ? constant_15 : Space{});
        const Space v489_5 = subtract(constant_0,v489_4);
        Space v489_8;
        if (!v489_5.empty()) {
          const Path v490_6 = concat_path(v482_18_head,v488_10_head);
          const Space v490_7 = routine_91(c, v490_6, p1, v488_10_tail);
          v489_8 = compose(v489_5,v490_7);
        }
        const Space v489_9 = intersect(constant_14,v489_2);
        const Space v489_10 = (has_head(v489_9) ? constant_15 : Space{});
        Space v489_12;
        if (!v489_10.empty()) {
          const Path v491_6 = concat_path(v482_18_head,v488_10_head);
          const Space v491_11 = routine_93(c, v491_6, p1, v488_10_tail);
          v489_12 = compose(v489_10,v491_11);
        }
        const Space v489_13 = unite(v489_8,v489_12);
        v488_10_result = unite(v488_10_result,v489_13);
      }
      const Space v488_10 = std::move(v488_10_result);
      v483_11 = compose(v483_9,v488_10);
    }
    const Space v483_12 = unite(v483_7,v483_11);
    v482_18_result = unite(v482_18_result,v483_12);
  }
  const Space v482_18 = std::move(v482_18_result);
  return v482_18;
}

static Space routine_48(Context& c, const Path& p0, const Space& s0) {
  Space v492_6_result;
  for (int v492_6_label = 1; v492_6_label <= 2; ++v492_6_label) {
    const Space v492_6_tail = child(s0,v492_6_label);
    if (v492_6_tail.empty()) continue;
    const Path v492_6_head{v492_6_label};
    const Space v493_2 = singleton(v492_6_head);
    const Space v493_3 = intersect(constant_14,v493_2);
    const Space v493_4 = (has_head(v493_3) ? constant_15 : Space{});
    const Space v493_5 = subtract(constant_0,v493_4);
    Space v493_6_result;
    for (int v493_6_label = 1; v493_6_label <= 2; ++v493_6_label) {
      const Space v493_6_tail = child(v492_6_tail,v493_6_label);
      if (v493_6_tail.empty()) continue;
      const Path v493_6_head{v493_6_label};
      const Space v494_2 = Space{};
      v493_6_result = unite(v493_6_result,v494_2);
    }
    const Space v493_6 = std::move(v493_6_result);
    const Space v493_7 = compose(v493_5,v493_6);
    const Space v493_8 = intersect(constant_14,v493_2);
    const Space v493_9 = (has_head(v493_8) ? constant_15 : Space{});
    Space v493_12;
    if (!v493_9.empty()) {
      const Path v495_10 = concat_path(p0,v492_6_head);
      Space v495_11_result;
      for (int v495_11_label = 1; v495_11_label <= 2; ++v495_11_label) {
        const Space v495_11_tail = child(v492_6_tail,v495_11_label);
        if (v495_11_tail.empty()) continue;
        const Path v495_11_head{v495_11_label};
        const Space v496_2 = singleton(v495_11_head);
        const Space v496_3 = intersect(constant_14,v496_2);
        const Space v496_4 = (has_head(v496_3) ? constant_15 : Space{});
        Space v496_7;
        if (!v496_4.empty()) {
          const Path v497_5 = concat_path(v495_10,v495_11_head);
          const Space v497_6 = routine_17(c, v497_5, v495_11_tail);
          v496_7 = compose(v496_4,v497_6);
        }
        v495_11_result = unite(v495_11_result,v496_7);
      }
      const Space v495_11 = std::move(v495_11_result);
      v493_12 = compose(v493_9,v495_11);
    }
    const Space v493_13 = unite(v493_7,v493_12);
    v492_6_result = unite(v492_6_result,v493_13);
  }
  const Space v492_6 = std::move(v492_6_result);
  return v492_6;
}

static Space routine_49(Context& c, const Path& p0, const Space& s0) {
  Space v498_8_result;
  for (int v498_8_label = 1; v498_8_label <= 2; ++v498_8_label) {
    const Space v498_8_tail = child(s0,v498_8_label);
    if (v498_8_tail.empty()) continue;
    const Path v498_8_head{v498_8_label};
    const Space v499_2 = singleton(v498_8_head);
    const Space v499_3 = intersect(constant_14,v499_2);
    const Space v499_4 = (has_head(v499_3) ? constant_15 : Space{});
    const Space v499_5 = subtract(constant_0,v499_4);
    Space v499_6_result;
    for (int v499_6_label = 1; v499_6_label <= 2; ++v499_6_label) {
      const Space v499_6_tail = child(v498_8_tail,v499_6_label);
      if (v499_6_tail.empty()) continue;
      const Path v499_6_head{v499_6_label};
      const Space v500_2 = Space{};
      v499_6_result = unite(v499_6_result,v500_2);
    }
    const Space v499_6 = std::move(v499_6_result);
    const Space v499_7 = compose(v499_5,v499_6);
    const Space v499_8 = intersect(constant_14,v499_2);
    const Space v499_9 = (has_head(v499_8) ? constant_15 : Space{});
    Space v499_12;
    if (!v499_9.empty()) {
      const Path v501_10 = concat_path(p0,v498_8_head);
      Space v501_11_result;
      for (int v501_11_label = 1; v501_11_label <= 2; ++v501_11_label) {
        const Space v501_11_tail = child(v498_8_tail,v501_11_label);
        if (v501_11_tail.empty()) continue;
        const Path v501_11_head{v501_11_label};
        const Space v502_2 = singleton(v501_11_head);
        const Space v502_3 = intersect(constant_14,v502_2);
        const Space v502_4 = (has_head(v502_3) ? constant_15 : Space{});
        const Space v502_5 = subtract(constant_0,v502_4);
        Space v502_7;
        if (!v502_5.empty()) {
          const Space v503_6 = routine_18(c, v501_11_head, v501_10, v501_11_tail);
          v502_7 = compose(v502_5,v503_6);
        }
        const Space v502_8 = intersect(constant_14,v502_2);
        const Space v502_9 = (has_head(v502_8) ? constant_15 : Space{});
        Space v502_11;
        if (!v502_9.empty()) {
          const Space v504_10 = routine_19(c, v501_11_head, v501_10, v501_11_tail);
          v502_11 = compose(v502_9,v504_10);
        }
        const Space v502_12 = unite(v502_7,v502_11);
        v501_11_result = unite(v501_11_result,v502_12);
      }
      const Space v501_11 = std::move(v501_11_result);
      v499_12 = compose(v499_9,v501_11);
    }
    const Space v499_13 = unite(v499_7,v499_12);
    v498_8_result = unite(v498_8_result,v499_13);
  }
  const Space v498_8 = std::move(v498_8_result);
  return v498_8;
}

static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v505_12_result;
  for (int v505_12_label = 1; v505_12_label <= 2; ++v505_12_label) {
    const Space v505_12_tail = child(s0,v505_12_label);
    if (v505_12_tail.empty()) continue;
    const Path v505_12_head{v505_12_label};
    const Space v506_2 = singleton(v505_12_head);
    const Space v506_3 = intersect(constant_14,v506_2);
    const Space v506_4 = (has_head(v506_3) ? constant_15 : Space{});
    const Space v506_5 = subtract(constant_0,v506_4);
    Space v506_8;
    if (!v506_5.empty()) {
      const Path v507_6 = concat_path(p0,v505_12_head);
      Space v507_7_result;
      for (int v507_7_label = 1; v507_7_label <= 2; ++v507_7_label) {
        const Space v507_7_tail = child(v505_12_tail,v507_7_label);
        if (v507_7_tail.empty()) continue;
        const Path v507_7_head{v507_7_label};
        const Space v508_2 = singleton(v507_7_head);
        const Space v508_3 = intersect(constant_14,v508_2);
        const Space v508_4 = (has_head(v508_3) ? constant_15 : Space{});
        const Space v508_5 = subtract(constant_0,v508_4);
        Space v508_8;
        if (!v508_5.empty()) {
          const Path v509_6 = concat_path(v507_6,v507_7_head);
          const Space v509_7 = routine_94(c, v509_6, p1, v507_7_tail);
          v508_8 = compose(v508_5,v509_7);
        }
        const Space v508_9 = intersect(constant_14,v508_2);
        const Space v508_10 = (has_head(v508_9) ? constant_15 : Space{});
        Space v508_12;
        if (!v508_10.empty()) {
          const Path v510_6 = concat_path(v507_6,v507_7_head);
          const Space v510_11 = routine_95(c, v510_6, p1, v507_7_tail);
          v508_12 = compose(v508_10,v510_11);
        }
        const Space v508_13 = unite(v508_8,v508_12);
        v507_7_result = unite(v507_7_result,v508_13);
      }
      const Space v507_7 = std::move(v507_7_result);
      v506_8 = compose(v506_5,v507_7);
    }
    const Space v506_9 = intersect(constant_14,v506_2);
    const Space v506_10 = (has_head(v506_9) ? constant_15 : Space{});
    Space v506_12;
    if (!v506_10.empty()) {
      const Path v511_6 = concat_path(p0,v505_12_head);
      Space v511_11_result;
      for (int v511_11_label = 1; v511_11_label <= 2; ++v511_11_label) {
        const Space v511_11_tail = child(v505_12_tail,v511_11_label);
        if (v511_11_tail.empty()) continue;
        const Path v511_11_head{v511_11_label};
        const Space v512_2 = singleton(v511_11_head);
        const Space v512_3 = intersect(constant_14,v512_2);
        const Space v512_4 = (has_head(v512_3) ? constant_15 : Space{});
        const Space v512_5 = subtract(constant_0,v512_4);
        Space v512_8;
        if (!v512_5.empty()) {
          const Path v513_6 = concat_path(v511_6,v511_11_head);
          const Space v513_7 = routine_94(c, v513_6, p1, v511_11_tail);
          v512_8 = compose(v512_5,v513_7);
        }
        const Space v512_9 = intersect(constant_14,v512_2);
        const Space v512_10 = (has_head(v512_9) ? constant_15 : Space{});
        Space v512_12;
        if (!v512_10.empty()) {
          const Path v514_6 = concat_path(v511_6,v511_11_head);
          const Space v514_11 = routine_52(c, v514_6, p1, v511_11_tail);
          v512_12 = compose(v512_10,v514_11);
        }
        const Space v512_13 = unite(v512_8,v512_12);
        v511_11_result = unite(v511_11_result,v512_13);
      }
      const Space v511_11 = std::move(v511_11_result);
      v506_12 = compose(v506_10,v511_11);
    }
    const Space v506_13 = unite(v506_8,v506_12);
    v505_12_result = unite(v505_12_result,v506_13);
  }
  const Space v505_12 = std::move(v505_12_result);
  return v505_12;
}

static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v515_10_result;
  for (int v515_10_label = 1; v515_10_label <= 2; ++v515_10_label) {
    const Space v515_10_tail = child(s0,v515_10_label);
    if (v515_10_tail.empty()) continue;
    const Path v515_10_head{v515_10_label};
    const Space v516_2 = singleton(v515_10_head);
    const Space v516_3 = intersect(constant_14,v516_2);
    const Space v516_4 = (has_head(v516_3) ? constant_15 : Space{});
    const Space v516_5 = compose(v516_4,v515_10_tail);
    const Path v517_6 = concat_path(p0,v515_10_head);
    const Space v516_7 = wrap(v516_5,v517_6);
    const Space v516_8 = wrap(v516_7,p1);
    const Space v516_9 = wrap(v516_8,constant_10);
    const Space v516_10 = intersect(constant_14,v516_2);
    const Space v516_11 = (has_head(v516_10) ? constant_15 : Space{});
    const Space v516_12 = subtract(constant_0,v516_11);
    Space v516_14;
    if (!v516_12.empty()) {
      Space v518_13_result;
      for (int v518_13_label = 1; v518_13_label <= 2; ++v518_13_label) {
        const Space v518_13_tail = child(v515_10_tail,v518_13_label);
        if (v518_13_tail.empty()) continue;
        const Path v518_13_head{v518_13_label};
        const Space v519_2 = singleton(v518_13_head);
        const Space v519_3 = intersect(constant_14,v519_2);
        const Space v519_4 = (has_head(v519_3) ? constant_15 : Space{});
        const Space v519_5 = subtract(constant_0,v519_4);
        Space v519_8;
        if (!v519_5.empty()) {
          const Path v520_6 = concat_path(v517_6,v518_13_head);
          const Space v520_7 = routine_94(c, v520_6, p1, v518_13_tail);
          v519_8 = compose(v519_5,v520_7);
        }
        const Space v519_9 = intersect(constant_14,v519_2);
        const Space v519_10 = (has_head(v519_9) ? constant_15 : Space{});
        Space v519_12;
        if (!v519_10.empty()) {
          const Path v521_6 = concat_path(v517_6,v518_13_head);
          const Space v521_11 = routine_95(c, v521_6, p1, v518_13_tail);
          v519_12 = compose(v519_10,v521_11);
        }
        const Space v519_13 = unite(v519_8,v519_12);
        v518_13_result = unite(v518_13_result,v519_13);
      }
      const Space v518_13 = std::move(v518_13_result);
      v516_14 = compose(v516_12,v518_13);
    }
    const Space v516_15 = unite(v516_9,v516_14);
    v515_10_result = unite(v515_10_result,v516_15);
  }
  const Space v515_10 = std::move(v515_10_result);
  return v515_10;
}

static Space routine_52(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v522_3 = wrap(s0,p0);
  const Space v522_4 = wrap(v522_3,p1);
  const Space v522_6 = wrap(v522_4,constant_10);
  return v522_6;
}

static Space routine_53(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v523_12_result;
  for (int v523_12_label = 1; v523_12_label <= 2; ++v523_12_label) {
    const Space v523_12_tail = child(s0,v523_12_label);
    if (v523_12_tail.empty()) continue;
    const Path v523_12_head{v523_12_label};
    const Space v524_2 = singleton(v523_12_head);
    const Space v524_3 = intersect(constant_14,v524_2);
    const Space v524_4 = (has_head(v524_3) ? constant_15 : Space{});
    const Space v524_5 = subtract(constant_0,v524_4);
    Space v524_8;
    if (!v524_5.empty()) {
      const Path v525_6 = concat_path(p0,v523_12_head);
      Space v525_7_result;
      for (int v525_7_label = 1; v525_7_label <= 2; ++v525_7_label) {
        const Space v525_7_tail = child(v523_12_tail,v525_7_label);
        if (v525_7_tail.empty()) continue;
        const Path v525_7_head{v525_7_label};
        const Space v526_2 = singleton(v525_7_head);
        const Space v526_3 = intersect(constant_14,v526_2);
        const Space v526_4 = (has_head(v526_3) ? constant_15 : Space{});
        const Space v526_5 = subtract(constant_0,v526_4);
        Space v526_8;
        if (!v526_5.empty()) {
          const Path v527_6 = concat_path(v525_6,v525_7_head);
          const Space v527_7 = routine_96(c, v527_6, p1, v525_7_tail);
          v526_8 = compose(v526_5,v527_7);
        }
        const Space v526_9 = intersect(constant_14,v526_2);
        const Space v526_10 = (has_head(v526_9) ? constant_15 : Space{});
        Space v526_12;
        if (!v526_10.empty()) {
          const Path v528_6 = concat_path(v525_6,v525_7_head);
          const Space v528_11 = routine_97(c, v528_6, p1, v525_7_tail);
          v526_12 = compose(v526_10,v528_11);
        }
        const Space v526_13 = unite(v526_8,v526_12);
        v525_7_result = unite(v525_7_result,v526_13);
      }
      const Space v525_7 = std::move(v525_7_result);
      v524_8 = compose(v524_5,v525_7);
    }
    const Space v524_9 = intersect(constant_14,v524_2);
    const Space v524_10 = (has_head(v524_9) ? constant_15 : Space{});
    Space v524_12;
    if (!v524_10.empty()) {
      const Path v529_6 = concat_path(p0,v523_12_head);
      Space v529_11_result;
      for (int v529_11_label = 1; v529_11_label <= 2; ++v529_11_label) {
        const Space v529_11_tail = child(v523_12_tail,v529_11_label);
        if (v529_11_tail.empty()) continue;
        const Path v529_11_head{v529_11_label};
        const Space v530_2 = singleton(v529_11_head);
        const Space v530_3 = intersect(constant_14,v530_2);
        const Space v530_4 = (has_head(v530_3) ? constant_15 : Space{});
        const Space v530_5 = subtract(constant_0,v530_4);
        Space v530_8;
        if (!v530_5.empty()) {
          const Path v531_6 = concat_path(v529_6,v529_11_head);
          const Space v531_7 = routine_96(c, v531_6, p1, v529_11_tail);
          v530_8 = compose(v530_5,v531_7);
        }
        const Space v530_9 = intersect(constant_14,v530_2);
        const Space v530_10 = (has_head(v530_9) ? constant_15 : Space{});
        Space v530_12;
        if (!v530_10.empty()) {
          const Path v532_6 = concat_path(v529_6,v529_11_head);
          const Space v532_11 = routine_52(c, v532_6, p1, v529_11_tail);
          v530_12 = compose(v530_10,v532_11);
        }
        const Space v530_13 = unite(v530_8,v530_12);
        v529_11_result = unite(v529_11_result,v530_13);
      }
      const Space v529_11 = std::move(v529_11_result);
      v524_12 = compose(v524_10,v529_11);
    }
    const Space v524_13 = unite(v524_8,v524_12);
    v523_12_result = unite(v523_12_result,v524_13);
  }
  const Space v523_12 = std::move(v523_12_result);
  return v523_12;
}

static Space routine_54(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v533_10_result;
  for (int v533_10_label = 1; v533_10_label <= 2; ++v533_10_label) {
    const Space v533_10_tail = child(s0,v533_10_label);
    if (v533_10_tail.empty()) continue;
    const Path v533_10_head{v533_10_label};
    const Space v534_2 = singleton(v533_10_head);
    const Space v534_3 = intersect(constant_14,v534_2);
    const Space v534_4 = (has_head(v534_3) ? constant_15 : Space{});
    const Space v534_5 = compose(v534_4,v533_10_tail);
    const Path v535_6 = concat_path(p0,v533_10_head);
    const Space v534_7 = wrap(v534_5,v535_6);
    const Space v534_8 = wrap(v534_7,p1);
    const Space v534_9 = wrap(v534_8,constant_10);
    const Space v534_10 = intersect(constant_14,v534_2);
    const Space v534_11 = (has_head(v534_10) ? constant_15 : Space{});
    const Space v534_12 = subtract(constant_0,v534_11);
    Space v534_14;
    if (!v534_12.empty()) {
      Space v536_13_result;
      for (int v536_13_label = 1; v536_13_label <= 2; ++v536_13_label) {
        const Space v536_13_tail = child(v533_10_tail,v536_13_label);
        if (v536_13_tail.empty()) continue;
        const Path v536_13_head{v536_13_label};
        const Space v537_2 = singleton(v536_13_head);
        const Space v537_3 = intersect(constant_14,v537_2);
        const Space v537_4 = (has_head(v537_3) ? constant_15 : Space{});
        const Space v537_5 = subtract(constant_0,v537_4);
        Space v537_8;
        if (!v537_5.empty()) {
          const Path v538_6 = concat_path(v535_6,v536_13_head);
          const Space v538_7 = routine_96(c, v538_6, p1, v536_13_tail);
          v537_8 = compose(v537_5,v538_7);
        }
        const Space v537_9 = intersect(constant_14,v537_2);
        const Space v537_10 = (has_head(v537_9) ? constant_15 : Space{});
        Space v537_12;
        if (!v537_10.empty()) {
          const Path v539_6 = concat_path(v535_6,v536_13_head);
          const Space v539_11 = routine_97(c, v539_6, p1, v536_13_tail);
          v537_12 = compose(v537_10,v539_11);
        }
        const Space v537_13 = unite(v537_8,v537_12);
        v536_13_result = unite(v536_13_result,v537_13);
      }
      const Space v536_13 = std::move(v536_13_result);
      v534_14 = compose(v534_12,v536_13);
    }
    const Space v534_15 = unite(v534_9,v534_14);
    v533_10_result = unite(v533_10_result,v534_15);
  }
  const Space v533_10 = std::move(v533_10_result);
  return v533_10;
}

static Space routine_55(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v540_7_result;
  for (int v540_7_label = 1; v540_7_label <= 2; ++v540_7_label) {
    const Space v540_7_tail = child(s0,v540_7_label);
    if (v540_7_tail.empty()) continue;
    const Path v540_7_head{v540_7_label};
    const Space v541_2 = singleton(v540_7_head);
    const Space v541_3 = intersect(constant_14,v541_2);
    const Space v541_4 = (has_head(v541_3) ? constant_15 : Space{});
    const Space v541_5 = subtract(constant_0,v541_4);
    Space v541_6_result;
    for (int v541_6_label = 1; v541_6_label <= 2; ++v541_6_label) {
      const Space v541_6_tail = child(v540_7_tail,v541_6_label);
      if (v541_6_tail.empty()) continue;
      const Path v541_6_head{v541_6_label};
      const Space v542_2 = Space{};
      v541_6_result = unite(v541_6_result,v542_2);
    }
    const Space v541_6 = std::move(v541_6_result);
    const Space v541_7 = compose(v541_5,v541_6);
    const Space v541_8 = intersect(constant_14,v541_2);
    const Space v541_9 = (has_head(v541_8) ? constant_15 : Space{});
    Space v541_12;
    if (!v541_9.empty()) {
      const Path v543_10 = concat_path(p0,v540_7_head);
      Space v543_11_result;
      for (int v543_11_label = 1; v543_11_label <= 2; ++v543_11_label) {
        const Space v543_11_tail = child(v540_7_tail,v543_11_label);
        if (v543_11_tail.empty()) continue;
        const Path v543_11_head{v543_11_label};
        const Space v544_2 = singleton(v543_11_head);
        const Space v544_3 = intersect(constant_14,v544_2);
        const Space v544_4 = (has_head(v544_3) ? constant_15 : Space{});
        Space v544_7;
        if (!v544_4.empty()) {
          const Path v545_5 = concat_path(v543_10,v543_11_head);
          const Space v545_6 = routine_5(c, v545_5, v543_11_tail, s1);
          v544_7 = compose(v544_4,v545_6);
        }
        v543_11_result = unite(v543_11_result,v544_7);
      }
      const Space v543_11 = std::move(v543_11_result);
      v541_12 = compose(v541_9,v543_11);
    }
    const Space v541_13 = unite(v541_7,v541_12);
    v540_7_result = unite(v540_7_result,v541_13);
  }
  const Space v540_7 = std::move(v540_7_result);
  return v540_7;
}

static Space routine_56(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v546_9_result;
  for (int v546_9_label = 1; v546_9_label <= 2; ++v546_9_label) {
    const Space v546_9_tail = child(s0,v546_9_label);
    if (v546_9_tail.empty()) continue;
    const Path v546_9_head{v546_9_label};
    const Space v547_2 = singleton(v546_9_head);
    const Space v547_3 = intersect(constant_14,v547_2);
    const Space v547_4 = (has_head(v547_3) ? constant_15 : Space{});
    const Space v547_5 = subtract(constant_0,v547_4);
    Space v547_6_result;
    for (int v547_6_label = 1; v547_6_label <= 2; ++v547_6_label) {
      const Space v547_6_tail = child(v546_9_tail,v547_6_label);
      if (v547_6_tail.empty()) continue;
      const Path v547_6_head{v547_6_label};
      const Space v548_2 = Space{};
      v547_6_result = unite(v547_6_result,v548_2);
    }
    const Space v547_6 = std::move(v547_6_result);
    const Space v547_7 = compose(v547_5,v547_6);
    const Space v547_8 = intersect(constant_14,v547_2);
    const Space v547_9 = (has_head(v547_8) ? constant_15 : Space{});
    Space v547_12;
    if (!v547_9.empty()) {
      const Path v549_10 = concat_path(p0,v546_9_head);
      Space v549_11_result;
      for (int v549_11_label = 1; v549_11_label <= 2; ++v549_11_label) {
        const Space v549_11_tail = child(v546_9_tail,v549_11_label);
        if (v549_11_tail.empty()) continue;
        const Path v549_11_head{v549_11_label};
        const Space v550_2 = singleton(v549_11_head);
        const Space v550_3 = intersect(constant_14,v550_2);
        const Space v550_4 = (has_head(v550_3) ? constant_15 : Space{});
        const Space v550_5 = subtract(constant_0,v550_4);
        Space v550_7;
        if (!v550_5.empty()) {
          const Space v551_6 = routine_22(c, v549_11_head, v549_10, v549_11_tail, s1);
          v550_7 = compose(v550_5,v551_6);
        }
        const Space v550_8 = intersect(constant_14,v550_2);
        const Space v550_9 = (has_head(v550_8) ? constant_15 : Space{});
        Space v550_11;
        if (!v550_9.empty()) {
          const Space v552_10 = routine_23(c, v549_11_head, v549_10, v549_11_tail, s1);
          v550_11 = compose(v550_9,v552_10);
        }
        const Space v550_12 = unite(v550_7,v550_11);
        v549_11_result = unite(v549_11_result,v550_12);
      }
      const Space v549_11 = std::move(v549_11_result);
      v547_12 = compose(v547_9,v549_11);
    }
    const Space v547_13 = unite(v547_7,v547_12);
    v546_9_result = unite(v546_9_result,v547_13);
  }
  const Space v546_9 = std::move(v546_9_result);
  return v546_9;
}

static Space routine_57(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v553_13_result;
  for (int v553_13_label = 1; v553_13_label <= 2; ++v553_13_label) {
    const Space v553_13_tail = child(s0,v553_13_label);
    if (v553_13_tail.empty()) continue;
    const Path v553_13_head{v553_13_label};
    const Space v554_2 = singleton(v553_13_head);
    const Space v554_3 = intersect(constant_14,v554_2);
    const Space v554_4 = (has_head(v554_3) ? constant_15 : Space{});
    const Space v554_5 = subtract(constant_0,v554_4);
    Space v554_8;
    if (!v554_5.empty()) {
      const Path v555_6 = concat_path(p0,v553_13_head);
      Space v555_7_result;
      for (int v555_7_label = 1; v555_7_label <= 2; ++v555_7_label) {
        const Space v555_7_tail = child(v553_13_tail,v555_7_label);
        if (v555_7_tail.empty()) continue;
        const Path v555_7_head{v555_7_label};
        const Space v556_2 = singleton(v555_7_head);
        const Space v556_3 = intersect(constant_14,v556_2);
        const Space v556_4 = (has_head(v556_3) ? constant_15 : Space{});
        const Space v556_5 = subtract(constant_0,v556_4);
        Space v556_8;
        if (!v556_5.empty()) {
          const Path v557_6 = concat_path(v555_6,v555_7_head);
          const Space v557_7 = routine_98(c, v557_6, p1, v555_7_tail, s1);
          v556_8 = compose(v556_5,v557_7);
        }
        const Space v556_9 = intersect(constant_14,v556_2);
        const Space v556_10 = (has_head(v556_9) ? constant_15 : Space{});
        Space v556_12;
        if (!v556_10.empty()) {
          const Path v558_6 = concat_path(v555_6,v555_7_head);
          const Space v558_11 = routine_99(c, v558_6, p1, v555_7_tail, s1);
          v556_12 = compose(v556_10,v558_11);
        }
        const Space v556_13 = unite(v556_8,v556_12);
        v555_7_result = unite(v555_7_result,v556_13);
      }
      const Space v555_7 = std::move(v555_7_result);
      v554_8 = compose(v554_5,v555_7);
    }
    const Space v554_9 = intersect(constant_14,v554_2);
    const Space v554_10 = (has_head(v554_9) ? constant_15 : Space{});
    Space v554_12;
    if (!v554_10.empty()) {
      const Path v559_6 = concat_path(p0,v553_13_head);
      Space v559_11_result;
      for (int v559_11_label = 1; v559_11_label <= 2; ++v559_11_label) {
        const Space v559_11_tail = child(v553_13_tail,v559_11_label);
        if (v559_11_tail.empty()) continue;
        const Path v559_11_head{v559_11_label};
        const Space v560_2 = singleton(v559_11_head);
        const Space v560_3 = intersect(constant_14,v560_2);
        const Space v560_4 = (has_head(v560_3) ? constant_15 : Space{});
        const Space v560_5 = subtract(constant_0,v560_4);
        Space v560_8;
        if (!v560_5.empty()) {
          const Path v561_6 = concat_path(v559_6,v559_11_head);
          const Space v561_7 = routine_98(c, v561_6, p1, v559_11_tail, s1);
          v560_8 = compose(v560_5,v561_7);
        }
        const Space v560_9 = intersect(constant_14,v560_2);
        const Space v560_10 = (has_head(v560_9) ? constant_15 : Space{});
        Space v560_12;
        if (!v560_10.empty()) {
          const Path v562_6 = concat_path(v559_6,v559_11_head);
          const Space v562_11 = routine_26(c, v562_6, p1, v559_11_tail, s1);
          v560_12 = compose(v560_10,v562_11);
        }
        const Space v560_13 = unite(v560_8,v560_12);
        v559_11_result = unite(v559_11_result,v560_13);
      }
      const Space v559_11 = std::move(v559_11_result);
      v554_12 = compose(v554_10,v559_11);
    }
    const Space v554_13 = unite(v554_8,v554_12);
    v553_13_result = unite(v553_13_result,v554_13);
  }
  const Space v553_13 = std::move(v553_13_result);
  return v553_13;
}

static Space routine_58(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v563_8 = unwrap(s1,constant_7);
  const Space v563_10 = unwrap(v563_8,constant_10);
  const Space v563_11 = unwrap(v563_10,p0);
  Space v563_18_result;
  for (int v563_18_label = 1; v563_18_label <= 2; ++v563_18_label) {
    const Space v563_18_tail = child(s0,v563_18_label);
    if (v563_18_tail.empty()) continue;
    const Path v563_18_head{v563_18_label};
    const Space v564_2 = singleton(v563_18_head);
    const Space v564_3 = intersect(constant_14,v564_2);
    const Space v564_4 = (has_head(v564_3) ? constant_15 : Space{});
    const Space v564_5 = subtract(constant_0,v564_4);
    Space v564_8;
    if (!v564_5.empty()) {
      const Path v565_6 = concat_path(p0,v563_18_head);
      Space v565_7_result;
      for (int v565_7_label = 1; v565_7_label <= 2; ++v565_7_label) {
        const Space v565_7_tail = child(v563_18_tail,v565_7_label);
        if (v565_7_tail.empty()) continue;
        const Path v565_7_head{v565_7_label};
        const Space v566_2 = singleton(v565_7_head);
        const Space v566_3 = intersect(constant_14,v566_2);
        const Space v566_4 = (has_head(v566_3) ? constant_15 : Space{});
        const Space v566_5 = subtract(constant_0,v566_4);
        Space v566_8;
        if (!v566_5.empty()) {
          const Path v567_6 = concat_path(v565_6,v565_7_head);
          const Space v567_7 = routine_98(c, v567_6, p1, v565_7_tail, s1);
          v566_8 = compose(v566_5,v567_7);
        }
        const Space v566_9 = intersect(constant_14,v566_2);
        const Space v566_10 = (has_head(v566_9) ? constant_15 : Space{});
        Space v566_12;
        if (!v566_10.empty()) {
          const Path v568_6 = concat_path(v565_6,v565_7_head);
          const Space v568_11 = routine_99(c, v568_6, p1, v565_7_tail, s1);
          v566_12 = compose(v566_10,v568_11);
        }
        const Space v566_13 = unite(v566_8,v566_12);
        v565_7_result = unite(v565_7_result,v566_13);
      }
      const Space v565_7 = std::move(v565_7_result);
      v564_8 = compose(v564_5,v565_7);
    }
    const Space v564_9 = intersect(constant_14,v564_2);
    const Space v564_10 = (has_head(v564_9) ? constant_15 : Space{});
    Space v564_13;
    if (!v564_10.empty()) {
      const Space v569_11 = unwrap(v563_11,v563_18_head);
      Space v569_12_result;
      for (int v569_12_label = 1; v569_12_label <= 2; ++v569_12_label) {
        const Space v569_12_tail = child(v569_11,v569_12_label);
        if (v569_12_tail.empty()) continue;
        const Path v569_12_head{v569_12_label};
        const Space v570_2 = singleton(v569_12_head);
        const Space v570_3 = intersect(constant_14,v570_2);
        const Space v570_4 = (has_head(v570_3) ? constant_15 : Space{});
        const Space v570_5 = subtract(constant_0,v570_4);
        Space v570_7;
        if (!v570_5.empty()) {
          const Space v571_6 = routine_59(c, v569_12_head, p1, v569_12_tail);
          v570_7 = compose(v570_5,v571_6);
        }
        const Space v570_8 = intersect(constant_14,v570_2);
        const Space v570_9 = (has_head(v570_8) ? constant_15 : Space{});
        Space v570_11;
        if (!v570_9.empty()) {
          const Space v572_10 = routine_60(c, v569_12_head, p1, v569_12_tail);
          v570_11 = compose(v570_9,v572_10);
        }
        const Space v570_12 = unite(v570_7,v570_11);
        v569_12_result = unite(v569_12_result,v570_12);
      }
      const Space v569_12 = std::move(v569_12_result);
      v564_13 = compose(v564_10,v569_12);
    }
    const Space v564_14 = unite(v564_8,v564_13);
    v563_18_result = unite(v563_18_result,v564_14);
  }
  const Space v563_18 = std::move(v563_18_result);
  return v563_18;
}

static Space routine_59(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v573_12_result;
  for (int v573_12_label = 1; v573_12_label <= 2; ++v573_12_label) {
    const Space v573_12_tail = child(s0,v573_12_label);
    if (v573_12_tail.empty()) continue;
    const Path v573_12_head{v573_12_label};
    const Space v574_2 = singleton(v573_12_head);
    const Space v574_3 = intersect(constant_14,v574_2);
    const Space v574_4 = (has_head(v574_3) ? constant_15 : Space{});
    const Space v574_5 = subtract(constant_0,v574_4);
    Space v574_8;
    if (!v574_5.empty()) {
      const Path v575_6 = concat_path(p0,v573_12_head);
      Space v575_7_result;
      for (int v575_7_label = 1; v575_7_label <= 2; ++v575_7_label) {
        const Space v575_7_tail = child(v573_12_tail,v575_7_label);
        if (v575_7_tail.empty()) continue;
        const Path v575_7_head{v575_7_label};
        const Space v576_2 = singleton(v575_7_head);
        const Space v576_3 = intersect(constant_14,v576_2);
        const Space v576_4 = (has_head(v576_3) ? constant_15 : Space{});
        const Space v576_5 = subtract(constant_0,v576_4);
        Space v576_8;
        if (!v576_5.empty()) {
          const Path v577_6 = concat_path(v575_6,v575_7_head);
          const Space v577_7 = routine_100(c, v577_6, p1, v575_7_tail);
          v576_8 = compose(v576_5,v577_7);
        }
        const Space v576_9 = intersect(constant_14,v576_2);
        const Space v576_10 = (has_head(v576_9) ? constant_15 : Space{});
        Space v576_12;
        if (!v576_10.empty()) {
          const Path v578_6 = concat_path(v575_6,v575_7_head);
          const Space v578_11 = routine_101(c, v578_6, p1, v575_7_tail);
          v576_12 = compose(v576_10,v578_11);
        }
        const Space v576_13 = unite(v576_8,v576_12);
        v575_7_result = unite(v575_7_result,v576_13);
      }
      const Space v575_7 = std::move(v575_7_result);
      v574_8 = compose(v574_5,v575_7);
    }
    const Space v574_9 = intersect(constant_14,v574_2);
    const Space v574_10 = (has_head(v574_9) ? constant_15 : Space{});
    Space v574_12;
    if (!v574_10.empty()) {
      const Path v579_6 = concat_path(p0,v573_12_head);
      Space v579_11_result;
      for (int v579_11_label = 1; v579_11_label <= 2; ++v579_11_label) {
        const Space v579_11_tail = child(v573_12_tail,v579_11_label);
        if (v579_11_tail.empty()) continue;
        const Path v579_11_head{v579_11_label};
        const Space v580_2 = singleton(v579_11_head);
        const Space v580_3 = intersect(constant_14,v580_2);
        const Space v580_4 = (has_head(v580_3) ? constant_15 : Space{});
        const Space v580_5 = subtract(constant_0,v580_4);
        Space v580_8;
        if (!v580_5.empty()) {
          const Path v581_6 = concat_path(v579_6,v579_11_head);
          const Space v581_7 = routine_100(c, v581_6, p1, v579_11_tail);
          v580_8 = compose(v580_5,v581_7);
        }
        const Space v580_9 = intersect(constant_14,v580_2);
        const Space v580_10 = (has_head(v580_9) ? constant_15 : Space{});
        Space v580_12;
        if (!v580_10.empty()) {
          const Path v582_6 = concat_path(v579_6,v579_11_head);
          const Space v582_11 = routine_65(c, v582_6, p1, v579_11_tail);
          v580_12 = compose(v580_10,v582_11);
        }
        const Space v580_13 = unite(v580_8,v580_12);
        v579_11_result = unite(v579_11_result,v580_13);
      }
      const Space v579_11 = std::move(v579_11_result);
      v574_12 = compose(v574_10,v579_11);
    }
    const Space v574_13 = unite(v574_8,v574_12);
    v573_12_result = unite(v573_12_result,v574_13);
  }
  const Space v573_12 = std::move(v573_12_result);
  return v573_12;
}

static Space routine_60(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v583_9_result;
  for (int v583_9_label = 1; v583_9_label <= 2; ++v583_9_label) {
    const Space v583_9_tail = child(s0,v583_9_label);
    if (v583_9_tail.empty()) continue;
    const Path v583_9_head{v583_9_label};
    const Space v584_2 = singleton(v583_9_head);
    const Space v584_3 = intersect(constant_14,v584_2);
    const Space v584_4 = (has_head(v584_3) ? constant_15 : Space{});
    const Space v584_5 = subtract(constant_0,v584_4);
    Space v584_8;
    if (!v584_5.empty()) {
      const Path v585_6 = concat_path(p0,v583_9_head);
      Space v585_7_result;
      for (int v585_7_label = 1; v585_7_label <= 2; ++v585_7_label) {
        const Space v585_7_tail = child(v583_9_tail,v585_7_label);
        if (v585_7_tail.empty()) continue;
        const Path v585_7_head{v585_7_label};
        const Space v586_2 = singleton(v585_7_head);
        const Space v586_3 = intersect(constant_14,v586_2);
        const Space v586_4 = (has_head(v586_3) ? constant_15 : Space{});
        const Space v586_5 = subtract(constant_0,v586_4);
        Space v586_8;
        if (!v586_5.empty()) {
          const Path v587_6 = concat_path(v585_6,v585_7_head);
          const Space v587_7 = routine_100(c, v587_6, p1, v585_7_tail);
          v586_8 = compose(v586_5,v587_7);
        }
        const Space v586_9 = intersect(constant_14,v586_2);
        const Space v586_10 = (has_head(v586_9) ? constant_15 : Space{});
        Space v586_12;
        if (!v586_10.empty()) {
          const Path v588_6 = concat_path(v585_6,v585_7_head);
          const Space v588_11 = routine_101(c, v588_6, p1, v585_7_tail);
          v586_12 = compose(v586_10,v588_11);
        }
        const Space v586_13 = unite(v586_8,v586_12);
        v585_7_result = unite(v585_7_result,v586_13);
      }
      const Space v585_7 = std::move(v585_7_result);
      v584_8 = compose(v584_5,v585_7);
    }
    const Space v584_9 = intersect(constant_14,v584_2);
    const Space v584_10 = (has_head(v584_9) ? constant_15 : Space{});
    const Space v584_11 = compose(v584_10,v583_9_tail);
    const Path v589_6 = concat_path(p0,v583_9_head);
    const Space v584_12 = wrap(v584_11,v589_6);
    const Space v584_13 = wrap(v584_12,p1);
    const Space v584_14 = unite(v584_8,v584_13);
    v583_9_result = unite(v583_9_result,v584_14);
  }
  const Space v583_9 = std::move(v583_9_result);
  return v583_9;
}

static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v590_13_result;
  for (int v590_13_label = 1; v590_13_label <= 2; ++v590_13_label) {
    const Space v590_13_tail = child(s0,v590_13_label);
    if (v590_13_tail.empty()) continue;
    const Path v590_13_head{v590_13_label};
    const Space v591_2 = singleton(v590_13_head);
    const Space v591_3 = intersect(constant_14,v591_2);
    const Space v591_4 = (has_head(v591_3) ? constant_15 : Space{});
    const Space v591_5 = subtract(constant_0,v591_4);
    Space v591_8;
    if (!v591_5.empty()) {
      const Path v592_6 = concat_path(p0,v590_13_head);
      Space v592_7_result;
      for (int v592_7_label = 1; v592_7_label <= 2; ++v592_7_label) {
        const Space v592_7_tail = child(v590_13_tail,v592_7_label);
        if (v592_7_tail.empty()) continue;
        const Path v592_7_head{v592_7_label};
        const Space v593_2 = singleton(v592_7_head);
        const Space v593_3 = intersect(constant_14,v593_2);
        const Space v593_4 = (has_head(v593_3) ? constant_15 : Space{});
        const Space v593_5 = subtract(constant_0,v593_4);
        Space v593_8;
        if (!v593_5.empty()) {
          const Path v594_6 = concat_path(v592_6,v592_7_head);
          const Space v594_7 = routine_102(c, v594_6, p1, v592_7_tail, s1);
          v593_8 = compose(v593_5,v594_7);
        }
        const Space v593_9 = intersect(constant_14,v593_2);
        const Space v593_10 = (has_head(v593_9) ? constant_15 : Space{});
        Space v593_12;
        if (!v593_10.empty()) {
          const Path v595_6 = concat_path(v592_6,v592_7_head);
          const Space v595_11 = routine_103(c, v595_6, p1, v592_7_tail, s1);
          v593_12 = compose(v593_10,v595_11);
        }
        const Space v593_13 = unite(v593_8,v593_12);
        v592_7_result = unite(v592_7_result,v593_13);
      }
      const Space v592_7 = std::move(v592_7_result);
      v591_8 = compose(v591_5,v592_7);
    }
    const Space v591_9 = intersect(constant_14,v591_2);
    const Space v591_10 = (has_head(v591_9) ? constant_15 : Space{});
    Space v591_12;
    if (!v591_10.empty()) {
      const Path v596_6 = concat_path(p0,v590_13_head);
      Space v596_11_result;
      for (int v596_11_label = 1; v596_11_label <= 2; ++v596_11_label) {
        const Space v596_11_tail = child(v590_13_tail,v596_11_label);
        if (v596_11_tail.empty()) continue;
        const Path v596_11_head{v596_11_label};
        const Space v597_2 = singleton(v596_11_head);
        const Space v597_3 = intersect(constant_14,v597_2);
        const Space v597_4 = (has_head(v597_3) ? constant_15 : Space{});
        const Space v597_5 = subtract(constant_0,v597_4);
        Space v597_8;
        if (!v597_5.empty()) {
          const Path v598_6 = concat_path(v596_6,v596_11_head);
          const Space v598_7 = routine_102(c, v598_6, p1, v596_11_tail, s1);
          v597_8 = compose(v597_5,v598_7);
        }
        const Space v597_9 = intersect(constant_14,v597_2);
        const Space v597_10 = (has_head(v597_9) ? constant_15 : Space{});
        Space v597_12;
        if (!v597_10.empty()) {
          const Path v599_6 = concat_path(v596_6,v596_11_head);
          const Space v599_11 = routine_26(c, v599_6, p1, v596_11_tail, s1);
          v597_12 = compose(v597_10,v599_11);
        }
        const Space v597_13 = unite(v597_8,v597_12);
        v596_11_result = unite(v596_11_result,v597_13);
      }
      const Space v596_11 = std::move(v596_11_result);
      v591_12 = compose(v591_10,v596_11);
    }
    const Space v591_13 = unite(v591_8,v591_12);
    v590_13_result = unite(v590_13_result,v591_13);
  }
  const Space v590_13 = std::move(v590_13_result);
  return v590_13;
}

static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v600_8 = unwrap(s1,constant_7);
  const Space v600_10 = unwrap(v600_8,constant_10);
  const Space v600_11 = unwrap(v600_10,p0);
  Space v600_18_result;
  for (int v600_18_label = 1; v600_18_label <= 2; ++v600_18_label) {
    const Space v600_18_tail = child(s0,v600_18_label);
    if (v600_18_tail.empty()) continue;
    const Path v600_18_head{v600_18_label};
    const Space v601_2 = singleton(v600_18_head);
    const Space v601_3 = intersect(constant_14,v601_2);
    const Space v601_4 = (has_head(v601_3) ? constant_15 : Space{});
    const Space v601_5 = subtract(constant_0,v601_4);
    Space v601_8;
    if (!v601_5.empty()) {
      const Path v602_6 = concat_path(p0,v600_18_head);
      Space v602_7_result;
      for (int v602_7_label = 1; v602_7_label <= 2; ++v602_7_label) {
        const Space v602_7_tail = child(v600_18_tail,v602_7_label);
        if (v602_7_tail.empty()) continue;
        const Path v602_7_head{v602_7_label};
        const Space v603_2 = singleton(v602_7_head);
        const Space v603_3 = intersect(constant_14,v603_2);
        const Space v603_4 = (has_head(v603_3) ? constant_15 : Space{});
        const Space v603_5 = subtract(constant_0,v603_4);
        Space v603_8;
        if (!v603_5.empty()) {
          const Path v604_6 = concat_path(v602_6,v602_7_head);
          const Space v604_7 = routine_102(c, v604_6, p1, v602_7_tail, s1);
          v603_8 = compose(v603_5,v604_7);
        }
        const Space v603_9 = intersect(constant_14,v603_2);
        const Space v603_10 = (has_head(v603_9) ? constant_15 : Space{});
        Space v603_12;
        if (!v603_10.empty()) {
          const Path v605_6 = concat_path(v602_6,v602_7_head);
          const Space v605_11 = routine_103(c, v605_6, p1, v602_7_tail, s1);
          v603_12 = compose(v603_10,v605_11);
        }
        const Space v603_13 = unite(v603_8,v603_12);
        v602_7_result = unite(v602_7_result,v603_13);
      }
      const Space v602_7 = std::move(v602_7_result);
      v601_8 = compose(v601_5,v602_7);
    }
    const Space v601_9 = intersect(constant_14,v601_2);
    const Space v601_10 = (has_head(v601_9) ? constant_15 : Space{});
    Space v601_13;
    if (!v601_10.empty()) {
      const Space v606_11 = unwrap(v600_11,v600_18_head);
      Space v606_12_result;
      for (int v606_12_label = 1; v606_12_label <= 2; ++v606_12_label) {
        const Space v606_12_tail = child(v606_11,v606_12_label);
        if (v606_12_tail.empty()) continue;
        const Path v606_12_head{v606_12_label};
        const Space v607_2 = singleton(v606_12_head);
        const Space v607_3 = intersect(constant_14,v607_2);
        const Space v607_4 = (has_head(v607_3) ? constant_15 : Space{});
        const Space v607_5 = subtract(constant_0,v607_4);
        Space v607_7;
        if (!v607_5.empty()) {
          const Space v608_6 = routine_59(c, v606_12_head, p1, v606_12_tail);
          v607_7 = compose(v607_5,v608_6);
        }
        const Space v607_8 = intersect(constant_14,v607_2);
        const Space v607_9 = (has_head(v607_8) ? constant_15 : Space{});
        Space v607_11;
        if (!v607_9.empty()) {
          const Space v609_10 = routine_60(c, v606_12_head, p1, v606_12_tail);
          v607_11 = compose(v607_9,v609_10);
        }
        const Space v607_12 = unite(v607_7,v607_11);
        v606_12_result = unite(v606_12_result,v607_12);
      }
      const Space v606_12 = std::move(v606_12_result);
      v601_13 = compose(v601_10,v606_12);
    }
    const Space v601_14 = unite(v601_8,v601_13);
    v600_18_result = unite(v600_18_result,v601_14);
  }
  const Space v600_18 = std::move(v600_18_result);
  return v600_18;
}

static Space routine_63(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v610_12_result;
  for (int v610_12_label = 1; v610_12_label <= 2; ++v610_12_label) {
    const Space v610_12_tail = child(s0,v610_12_label);
    if (v610_12_tail.empty()) continue;
    const Path v610_12_head{v610_12_label};
    const Space v611_2 = singleton(v610_12_head);
    const Space v611_3 = intersect(constant_14,v611_2);
    const Space v611_4 = (has_head(v611_3) ? constant_15 : Space{});
    const Space v611_5 = subtract(constant_0,v611_4);
    Space v611_8;
    if (!v611_5.empty()) {
      const Path v612_6 = concat_path(p0,v610_12_head);
      Space v612_7_result;
      for (int v612_7_label = 1; v612_7_label <= 2; ++v612_7_label) {
        const Space v612_7_tail = child(v610_12_tail,v612_7_label);
        if (v612_7_tail.empty()) continue;
        const Path v612_7_head{v612_7_label};
        const Space v613_2 = singleton(v612_7_head);
        const Space v613_3 = intersect(constant_14,v613_2);
        const Space v613_4 = (has_head(v613_3) ? constant_15 : Space{});
        const Space v613_5 = subtract(constant_0,v613_4);
        Space v613_8;
        if (!v613_5.empty()) {
          const Path v614_6 = concat_path(v612_6,v612_7_head);
          const Space v614_7 = routine_104(c, v614_6, p1, v612_7_tail);
          v613_8 = compose(v613_5,v614_7);
        }
        const Space v613_9 = intersect(constant_14,v613_2);
        const Space v613_10 = (has_head(v613_9) ? constant_15 : Space{});
        Space v613_12;
        if (!v613_10.empty()) {
          const Path v615_6 = concat_path(v612_6,v612_7_head);
          const Space v615_11 = routine_105(c, v615_6, p1, v612_7_tail);
          v613_12 = compose(v613_10,v615_11);
        }
        const Space v613_13 = unite(v613_8,v613_12);
        v612_7_result = unite(v612_7_result,v613_13);
      }
      const Space v612_7 = std::move(v612_7_result);
      v611_8 = compose(v611_5,v612_7);
    }
    const Space v611_9 = intersect(constant_14,v611_2);
    const Space v611_10 = (has_head(v611_9) ? constant_15 : Space{});
    Space v611_12;
    if (!v611_10.empty()) {
      const Path v616_6 = concat_path(p0,v610_12_head);
      Space v616_11_result;
      for (int v616_11_label = 1; v616_11_label <= 2; ++v616_11_label) {
        const Space v616_11_tail = child(v610_12_tail,v616_11_label);
        if (v616_11_tail.empty()) continue;
        const Path v616_11_head{v616_11_label};
        const Space v617_2 = singleton(v616_11_head);
        const Space v617_3 = intersect(constant_14,v617_2);
        const Space v617_4 = (has_head(v617_3) ? constant_15 : Space{});
        const Space v617_5 = subtract(constant_0,v617_4);
        Space v617_8;
        if (!v617_5.empty()) {
          const Path v618_6 = concat_path(v616_6,v616_11_head);
          const Space v618_7 = routine_104(c, v618_6, p1, v616_11_tail);
          v617_8 = compose(v617_5,v618_7);
        }
        const Space v617_9 = intersect(constant_14,v617_2);
        const Space v617_10 = (has_head(v617_9) ? constant_15 : Space{});
        Space v617_12;
        if (!v617_10.empty()) {
          const Path v619_6 = concat_path(v616_6,v616_11_head);
          const Space v619_11 = routine_65(c, v619_6, p1, v616_11_tail);
          v617_12 = compose(v617_10,v619_11);
        }
        const Space v617_13 = unite(v617_8,v617_12);
        v616_11_result = unite(v616_11_result,v617_13);
      }
      const Space v616_11 = std::move(v616_11_result);
      v611_12 = compose(v611_10,v616_11);
    }
    const Space v611_13 = unite(v611_8,v611_12);
    v610_12_result = unite(v610_12_result,v611_13);
  }
  const Space v610_12 = std::move(v610_12_result);
  return v610_12;
}

static Space routine_64(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v620_9_result;
  for (int v620_9_label = 1; v620_9_label <= 2; ++v620_9_label) {
    const Space v620_9_tail = child(s0,v620_9_label);
    if (v620_9_tail.empty()) continue;
    const Path v620_9_head{v620_9_label};
    const Space v621_2 = singleton(v620_9_head);
    const Space v621_3 = intersect(constant_14,v621_2);
    const Space v621_4 = (has_head(v621_3) ? constant_15 : Space{});
    const Space v621_5 = subtract(constant_0,v621_4);
    Space v621_8;
    if (!v621_5.empty()) {
      const Path v622_6 = concat_path(p0,v620_9_head);
      Space v622_7_result;
      for (int v622_7_label = 1; v622_7_label <= 2; ++v622_7_label) {
        const Space v622_7_tail = child(v620_9_tail,v622_7_label);
        if (v622_7_tail.empty()) continue;
        const Path v622_7_head{v622_7_label};
        const Space v623_2 = singleton(v622_7_head);
        const Space v623_3 = intersect(constant_14,v623_2);
        const Space v623_4 = (has_head(v623_3) ? constant_15 : Space{});
        const Space v623_5 = subtract(constant_0,v623_4);
        Space v623_8;
        if (!v623_5.empty()) {
          const Path v624_6 = concat_path(v622_6,v622_7_head);
          const Space v624_7 = routine_104(c, v624_6, p1, v622_7_tail);
          v623_8 = compose(v623_5,v624_7);
        }
        const Space v623_9 = intersect(constant_14,v623_2);
        const Space v623_10 = (has_head(v623_9) ? constant_15 : Space{});
        Space v623_12;
        if (!v623_10.empty()) {
          const Path v625_6 = concat_path(v622_6,v622_7_head);
          const Space v625_11 = routine_105(c, v625_6, p1, v622_7_tail);
          v623_12 = compose(v623_10,v625_11);
        }
        const Space v623_13 = unite(v623_8,v623_12);
        v622_7_result = unite(v622_7_result,v623_13);
      }
      const Space v622_7 = std::move(v622_7_result);
      v621_8 = compose(v621_5,v622_7);
    }
    const Space v621_9 = intersect(constant_14,v621_2);
    const Space v621_10 = (has_head(v621_9) ? constant_15 : Space{});
    const Space v621_11 = compose(v621_10,v620_9_tail);
    const Path v626_6 = concat_path(p0,v620_9_head);
    const Space v621_12 = wrap(v621_11,v626_6);
    const Space v621_13 = wrap(v621_12,p1);
    const Space v621_14 = unite(v621_8,v621_13);
    v620_9_result = unite(v620_9_result,v621_14);
  }
  const Space v620_9 = std::move(v620_9_result);
  return v620_9;
}

static Space routine_65(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v627_3 = wrap(s0,p0);
  const Space v627_4 = wrap(v627_3,p1);
  return v627_4;
}

static Space routine_66(Context& c, const Path& p0, const Space& s0) {
  Space v628_6_result;
  for (int v628_6_label = 1; v628_6_label <= 2; ++v628_6_label) {
    const Space v628_6_tail = child(s0,v628_6_label);
    if (v628_6_tail.empty()) continue;
    const Path v628_6_head{v628_6_label};
    const Space v629_2 = singleton(v628_6_head);
    const Space v629_3 = intersect(constant_14,v629_2);
    const Space v629_4 = (has_head(v629_3) ? constant_15 : Space{});
    const Space v629_5 = subtract(constant_0,v629_4);
    Space v629_6_result;
    for (int v629_6_label = 1; v629_6_label <= 2; ++v629_6_label) {
      const Space v629_6_tail = child(v628_6_tail,v629_6_label);
      if (v629_6_tail.empty()) continue;
      const Path v629_6_head{v629_6_label};
      const Space v630_2 = Space{};
      v629_6_result = unite(v629_6_result,v630_2);
    }
    const Space v629_6 = std::move(v629_6_result);
    const Space v629_7 = compose(v629_5,v629_6);
    const Space v629_8 = intersect(constant_14,v629_2);
    const Space v629_9 = (has_head(v629_8) ? constant_15 : Space{});
    Space v629_12;
    if (!v629_9.empty()) {
      const Path v631_10 = concat_path(p0,v628_6_head);
      Space v631_11_result;
      for (int v631_11_label = 1; v631_11_label <= 2; ++v631_11_label) {
        const Space v631_11_tail = child(v628_6_tail,v631_11_label);
        if (v631_11_tail.empty()) continue;
        const Path v631_11_head{v631_11_label};
        const Space v632_2 = singleton(v631_11_head);
        const Space v632_3 = intersect(constant_14,v632_2);
        const Space v632_4 = (has_head(v632_3) ? constant_15 : Space{});
        Space v632_7;
        if (!v632_4.empty()) {
          const Path v633_5 = concat_path(v631_10,v631_11_head);
          const Space v633_6 = routine_8(c, v633_5, v631_11_tail);
          v632_7 = compose(v632_4,v633_6);
        }
        v631_11_result = unite(v631_11_result,v632_7);
      }
      const Space v631_11 = std::move(v631_11_result);
      v629_12 = compose(v629_9,v631_11);
    }
    const Space v629_13 = unite(v629_7,v629_12);
    v628_6_result = unite(v628_6_result,v629_13);
  }
  const Space v628_6 = std::move(v628_6_result);
  return v628_6;
}

static Space routine_67(Context& c, const Path& p0, const Space& s0) {
  Space v634_8_result;
  for (int v634_8_label = 1; v634_8_label <= 2; ++v634_8_label) {
    const Space v634_8_tail = child(s0,v634_8_label);
    if (v634_8_tail.empty()) continue;
    const Path v634_8_head{v634_8_label};
    const Space v635_2 = singleton(v634_8_head);
    const Space v635_3 = intersect(constant_14,v635_2);
    const Space v635_4 = (has_head(v635_3) ? constant_15 : Space{});
    const Space v635_5 = subtract(constant_0,v635_4);
    Space v635_6_result;
    for (int v635_6_label = 1; v635_6_label <= 2; ++v635_6_label) {
      const Space v635_6_tail = child(v634_8_tail,v635_6_label);
      if (v635_6_tail.empty()) continue;
      const Path v635_6_head{v635_6_label};
      const Space v636_2 = Space{};
      v635_6_result = unite(v635_6_result,v636_2);
    }
    const Space v635_6 = std::move(v635_6_result);
    const Space v635_7 = compose(v635_5,v635_6);
    const Space v635_8 = intersect(constant_14,v635_2);
    const Space v635_9 = (has_head(v635_8) ? constant_15 : Space{});
    Space v635_12;
    if (!v635_9.empty()) {
      const Path v637_10 = concat_path(p0,v634_8_head);
      Space v637_11_result;
      for (int v637_11_label = 1; v637_11_label <= 2; ++v637_11_label) {
        const Space v637_11_tail = child(v634_8_tail,v637_11_label);
        if (v637_11_tail.empty()) continue;
        const Path v637_11_head{v637_11_label};
        const Space v638_2 = singleton(v637_11_head);
        const Space v638_3 = intersect(constant_14,v638_2);
        const Space v638_4 = (has_head(v638_3) ? constant_15 : Space{});
        const Space v638_5 = subtract(constant_0,v638_4);
        Space v638_7;
        if (!v638_5.empty()) {
          const Space v639_6 = routine_29(c, v637_11_head, v637_10, v637_11_tail);
          v638_7 = compose(v638_5,v639_6);
        }
        const Space v638_8 = intersect(constant_14,v638_2);
        const Space v638_9 = (has_head(v638_8) ? constant_15 : Space{});
        Space v638_11;
        if (!v638_9.empty()) {
          const Space v640_10 = routine_30(c, v637_11_head, v637_10, v637_11_tail);
          v638_11 = compose(v638_9,v640_10);
        }
        const Space v638_12 = unite(v638_7,v638_11);
        v637_11_result = unite(v637_11_result,v638_12);
      }
      const Space v637_11 = std::move(v637_11_result);
      v635_12 = compose(v635_9,v637_11);
    }
    const Space v635_13 = unite(v635_7,v635_12);
    v634_8_result = unite(v634_8_result,v635_13);
  }
  const Space v634_8 = std::move(v634_8_result);
  return v634_8;
}

static Space routine_68(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v641_12_result;
  for (int v641_12_label = 1; v641_12_label <= 2; ++v641_12_label) {
    const Space v641_12_tail = child(s0,v641_12_label);
    if (v641_12_tail.empty()) continue;
    const Path v641_12_head{v641_12_label};
    const Space v642_2 = singleton(v641_12_head);
    const Space v642_3 = intersect(constant_14,v642_2);
    const Space v642_4 = (has_head(v642_3) ? constant_15 : Space{});
    const Space v642_5 = subtract(constant_0,v642_4);
    Space v642_8;
    if (!v642_5.empty()) {
      const Path v643_6 = concat_path(p0,v641_12_head);
      Space v643_7_result;
      for (int v643_7_label = 1; v643_7_label <= 2; ++v643_7_label) {
        const Space v643_7_tail = child(v641_12_tail,v643_7_label);
        if (v643_7_tail.empty()) continue;
        const Path v643_7_head{v643_7_label};
        const Space v644_2 = singleton(v643_7_head);
        const Space v644_3 = intersect(constant_14,v644_2);
        const Space v644_4 = (has_head(v644_3) ? constant_15 : Space{});
        const Space v644_5 = subtract(constant_0,v644_4);
        Space v644_8;
        if (!v644_5.empty()) {
          const Path v645_6 = concat_path(v643_6,v643_7_head);
          const Space v645_7 = routine_106(c, v645_6, p1, v643_7_tail);
          v644_8 = compose(v644_5,v645_7);
        }
        const Space v644_9 = intersect(constant_14,v644_2);
        const Space v644_10 = (has_head(v644_9) ? constant_15 : Space{});
        Space v644_12;
        if (!v644_10.empty()) {
          const Path v646_6 = concat_path(v643_6,v643_7_head);
          const Space v646_11 = routine_107(c, v646_6, p1, v643_7_tail);
          v644_12 = compose(v644_10,v646_11);
        }
        const Space v644_13 = unite(v644_8,v644_12);
        v643_7_result = unite(v643_7_result,v644_13);
      }
      const Space v643_7 = std::move(v643_7_result);
      v642_8 = compose(v642_5,v643_7);
    }
    const Space v642_9 = intersect(constant_14,v642_2);
    const Space v642_10 = (has_head(v642_9) ? constant_15 : Space{});
    Space v642_12;
    if (!v642_10.empty()) {
      const Path v647_6 = concat_path(p0,v641_12_head);
      Space v647_11_result;
      for (int v647_11_label = 1; v647_11_label <= 2; ++v647_11_label) {
        const Space v647_11_tail = child(v641_12_tail,v647_11_label);
        if (v647_11_tail.empty()) continue;
        const Path v647_11_head{v647_11_label};
        const Space v648_2 = singleton(v647_11_head);
        const Space v648_3 = intersect(constant_14,v648_2);
        const Space v648_4 = (has_head(v648_3) ? constant_15 : Space{});
        const Space v648_5 = subtract(constant_0,v648_4);
        Space v648_8;
        if (!v648_5.empty()) {
          const Path v649_6 = concat_path(v647_6,v647_11_head);
          const Space v649_7 = routine_106(c, v649_6, p1, v647_11_tail);
          v648_8 = compose(v648_5,v649_7);
        }
        const Space v648_9 = intersect(constant_14,v648_2);
        const Space v648_10 = (has_head(v648_9) ? constant_15 : Space{});
        Space v648_12;
        if (!v648_10.empty()) {
          const Path v650_6 = concat_path(v647_6,v647_11_head);
          const Space v650_11 = routine_33(c, v650_6, p1, v647_11_tail);
          v648_12 = compose(v648_10,v650_11);
        }
        const Space v648_13 = unite(v648_8,v648_12);
        v647_11_result = unite(v647_11_result,v648_13);
      }
      const Space v647_11 = std::move(v647_11_result);
      v642_12 = compose(v642_10,v647_11);
    }
    const Space v642_13 = unite(v642_8,v642_12);
    v641_12_result = unite(v641_12_result,v642_13);
  }
  const Space v641_12 = std::move(v641_12_result);
  return v641_12;
}

static Space routine_69(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v651_9_result;
  for (int v651_9_label = 1; v651_9_label <= 2; ++v651_9_label) {
    const Space v651_9_tail = child(s0,v651_9_label);
    if (v651_9_tail.empty()) continue;
    const Path v651_9_head{v651_9_label};
    const Space v652_2 = singleton(v651_9_head);
    const Space v652_3 = intersect(constant_14,v652_2);
    const Space v652_4 = (has_head(v652_3) ? constant_15 : Space{});
    const Space v652_5 = subtract(constant_0,v652_4);
    Space v652_8;
    if (!v652_5.empty()) {
      const Path v653_6 = concat_path(p0,v651_9_head);
      Space v653_7_result;
      for (int v653_7_label = 1; v653_7_label <= 2; ++v653_7_label) {
        const Space v653_7_tail = child(v651_9_tail,v653_7_label);
        if (v653_7_tail.empty()) continue;
        const Path v653_7_head{v653_7_label};
        const Space v654_2 = singleton(v653_7_head);
        const Space v654_3 = intersect(constant_14,v654_2);
        const Space v654_4 = (has_head(v654_3) ? constant_15 : Space{});
        const Space v654_5 = subtract(constant_0,v654_4);
        Space v654_8;
        if (!v654_5.empty()) {
          const Path v655_6 = concat_path(v653_6,v653_7_head);
          const Space v655_7 = routine_106(c, v655_6, p1, v653_7_tail);
          v654_8 = compose(v654_5,v655_7);
        }
        const Space v654_9 = intersect(constant_14,v654_2);
        const Space v654_10 = (has_head(v654_9) ? constant_15 : Space{});
        Space v654_12;
        if (!v654_10.empty()) {
          const Path v656_6 = concat_path(v653_6,v653_7_head);
          const Space v656_11 = routine_107(c, v656_6, p1, v653_7_tail);
          v654_12 = compose(v654_10,v656_11);
        }
        const Space v654_13 = unite(v654_8,v654_12);
        v653_7_result = unite(v653_7_result,v654_13);
      }
      const Space v653_7 = std::move(v653_7_result);
      v652_8 = compose(v652_5,v653_7);
    }
    const Space v652_9 = intersect(constant_14,v652_2);
    const Space v652_10 = (has_head(v652_9) ? constant_15 : Space{});
    const Space v652_11 = compose(v652_10,v651_9_tail);
    const Path v657_6 = concat_path(p0,v651_9_head);
    const Space v652_12 = wrap(v652_11,v657_6);
    const Space v652_13 = wrap(v652_12,p1);
    const Space v652_14 = unite(v652_8,v652_13);
    v651_9_result = unite(v651_9_result,v652_14);
  }
  const Space v651_9 = std::move(v651_9_result);
  return v651_9;
}

static Space routine_70(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v658_12_result;
  for (int v658_12_label = 1; v658_12_label <= 2; ++v658_12_label) {
    const Space v658_12_tail = child(s0,v658_12_label);
    if (v658_12_tail.empty()) continue;
    const Path v658_12_head{v658_12_label};
    const Space v659_2 = singleton(v658_12_head);
    const Space v659_3 = intersect(constant_14,v659_2);
    const Space v659_4 = (has_head(v659_3) ? constant_15 : Space{});
    const Space v659_5 = subtract(constant_0,v659_4);
    Space v659_8;
    if (!v659_5.empty()) {
      const Path v660_6 = concat_path(p0,v658_12_head);
      Space v660_7_result;
      for (int v660_7_label = 1; v660_7_label <= 2; ++v660_7_label) {
        const Space v660_7_tail = child(v658_12_tail,v660_7_label);
        if (v660_7_tail.empty()) continue;
        const Path v660_7_head{v660_7_label};
        const Space v661_2 = singleton(v660_7_head);
        const Space v661_3 = intersect(constant_14,v661_2);
        const Space v661_4 = (has_head(v661_3) ? constant_15 : Space{});
        const Space v661_5 = subtract(constant_0,v661_4);
        Space v661_8;
        if (!v661_5.empty()) {
          const Path v662_6 = concat_path(v660_6,v660_7_head);
          const Space v662_7 = routine_108(c, v662_6, p1, v660_7_tail);
          v661_8 = compose(v661_5,v662_7);
        }
        const Space v661_9 = intersect(constant_14,v661_2);
        const Space v661_10 = (has_head(v661_9) ? constant_15 : Space{});
        Space v661_12;
        if (!v661_10.empty()) {
          const Path v663_6 = concat_path(v660_6,v660_7_head);
          const Space v663_11 = routine_109(c, v663_6, p1, v660_7_tail);
          v661_12 = compose(v661_10,v663_11);
        }
        const Space v661_13 = unite(v661_8,v661_12);
        v660_7_result = unite(v660_7_result,v661_13);
      }
      const Space v660_7 = std::move(v660_7_result);
      v659_8 = compose(v659_5,v660_7);
    }
    const Space v659_9 = intersect(constant_14,v659_2);
    const Space v659_10 = (has_head(v659_9) ? constant_15 : Space{});
    Space v659_12;
    if (!v659_10.empty()) {
      const Path v664_6 = concat_path(p0,v658_12_head);
      Space v664_11_result;
      for (int v664_11_label = 1; v664_11_label <= 2; ++v664_11_label) {
        const Space v664_11_tail = child(v658_12_tail,v664_11_label);
        if (v664_11_tail.empty()) continue;
        const Path v664_11_head{v664_11_label};
        const Space v665_2 = singleton(v664_11_head);
        const Space v665_3 = intersect(constant_14,v665_2);
        const Space v665_4 = (has_head(v665_3) ? constant_15 : Space{});
        const Space v665_5 = subtract(constant_0,v665_4);
        Space v665_8;
        if (!v665_5.empty()) {
          const Path v666_6 = concat_path(v664_6,v664_11_head);
          const Space v666_7 = routine_108(c, v666_6, p1, v664_11_tail);
          v665_8 = compose(v665_5,v666_7);
        }
        const Space v665_9 = intersect(constant_14,v665_2);
        const Space v665_10 = (has_head(v665_9) ? constant_15 : Space{});
        Space v665_12;
        if (!v665_10.empty()) {
          const Path v667_6 = concat_path(v664_6,v664_11_head);
          const Space v667_11 = routine_33(c, v667_6, p1, v664_11_tail);
          v665_12 = compose(v665_10,v667_11);
        }
        const Space v665_13 = unite(v665_8,v665_12);
        v664_11_result = unite(v664_11_result,v665_13);
      }
      const Space v664_11 = std::move(v664_11_result);
      v659_12 = compose(v659_10,v664_11);
    }
    const Space v659_13 = unite(v659_8,v659_12);
    v658_12_result = unite(v658_12_result,v659_13);
  }
  const Space v658_12 = std::move(v658_12_result);
  return v658_12;
}

static Space routine_71(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v668_9_result;
  for (int v668_9_label = 1; v668_9_label <= 2; ++v668_9_label) {
    const Space v668_9_tail = child(s0,v668_9_label);
    if (v668_9_tail.empty()) continue;
    const Path v668_9_head{v668_9_label};
    const Space v669_2 = singleton(v668_9_head);
    const Space v669_3 = intersect(constant_14,v669_2);
    const Space v669_4 = (has_head(v669_3) ? constant_15 : Space{});
    const Space v669_5 = subtract(constant_0,v669_4);
    Space v669_8;
    if (!v669_5.empty()) {
      const Path v670_6 = concat_path(p0,v668_9_head);
      Space v670_7_result;
      for (int v670_7_label = 1; v670_7_label <= 2; ++v670_7_label) {
        const Space v670_7_tail = child(v668_9_tail,v670_7_label);
        if (v670_7_tail.empty()) continue;
        const Path v670_7_head{v670_7_label};
        const Space v671_2 = singleton(v670_7_head);
        const Space v671_3 = intersect(constant_14,v671_2);
        const Space v671_4 = (has_head(v671_3) ? constant_15 : Space{});
        const Space v671_5 = subtract(constant_0,v671_4);
        Space v671_8;
        if (!v671_5.empty()) {
          const Path v672_6 = concat_path(v670_6,v670_7_head);
          const Space v672_7 = routine_108(c, v672_6, p1, v670_7_tail);
          v671_8 = compose(v671_5,v672_7);
        }
        const Space v671_9 = intersect(constant_14,v671_2);
        const Space v671_10 = (has_head(v671_9) ? constant_15 : Space{});
        Space v671_12;
        if (!v671_10.empty()) {
          const Path v673_6 = concat_path(v670_6,v670_7_head);
          const Space v673_11 = routine_109(c, v673_6, p1, v670_7_tail);
          v671_12 = compose(v671_10,v673_11);
        }
        const Space v671_13 = unite(v671_8,v671_12);
        v670_7_result = unite(v670_7_result,v671_13);
      }
      const Space v670_7 = std::move(v670_7_result);
      v669_8 = compose(v669_5,v670_7);
    }
    const Space v669_9 = intersect(constant_14,v669_2);
    const Space v669_10 = (has_head(v669_9) ? constant_15 : Space{});
    const Space v669_11 = compose(v669_10,v668_9_tail);
    const Path v674_6 = concat_path(p0,v668_9_head);
    const Space v669_12 = wrap(v669_11,v674_6);
    const Space v669_13 = wrap(v669_12,p1);
    const Space v669_14 = unite(v669_8,v669_13);
    v668_9_result = unite(v668_9_result,v669_14);
  }
  const Space v668_9 = std::move(v668_9_result);
  return v668_9;
}

static Space routine_72(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v675_7_result;
  for (int v675_7_label = 1; v675_7_label <= 2; ++v675_7_label) {
    const Space v675_7_tail = child(s0,v675_7_label);
    if (v675_7_tail.empty()) continue;
    const Path v675_7_head{v675_7_label};
    const Space v676_2 = singleton(v675_7_head);
    const Space v676_3 = intersect(constant_14,v676_2);
    const Space v676_4 = (has_head(v676_3) ? constant_15 : Space{});
    const Space v676_5 = subtract(constant_0,v676_4);
    Space v676_6_result;
    for (int v676_6_label = 1; v676_6_label <= 2; ++v676_6_label) {
      const Space v676_6_tail = child(v675_7_tail,v676_6_label);
      if (v676_6_tail.empty()) continue;
      const Path v676_6_head{v676_6_label};
      const Space v677_2 = Space{};
      v676_6_result = unite(v676_6_result,v677_2);
    }
    const Space v676_6 = std::move(v676_6_result);
    const Space v676_7 = compose(v676_5,v676_6);
    const Space v676_8 = intersect(constant_14,v676_2);
    const Space v676_9 = (has_head(v676_8) ? constant_15 : Space{});
    Space v676_12;
    if (!v676_9.empty()) {
      const Path v678_10 = concat_path(p0,v675_7_head);
      Space v678_11_result;
      for (int v678_11_label = 1; v678_11_label <= 2; ++v678_11_label) {
        const Space v678_11_tail = child(v675_7_tail,v678_11_label);
        if (v678_11_tail.empty()) continue;
        const Path v678_11_head{v678_11_label};
        const Space v679_2 = singleton(v678_11_head);
        const Space v679_3 = intersect(constant_14,v679_2);
        const Space v679_4 = (has_head(v679_3) ? constant_15 : Space{});
        Space v679_7;
        if (!v679_4.empty()) {
          const Path v680_5 = concat_path(v678_10,v678_11_head);
          const Space v680_6 = routine_11(c, v680_5, v678_11_tail, s1);
          v679_7 = compose(v679_4,v680_6);
        }
        v678_11_result = unite(v678_11_result,v679_7);
      }
      const Space v678_11 = std::move(v678_11_result);
      v676_12 = compose(v676_9,v678_11);
    }
    const Space v676_13 = unite(v676_7,v676_12);
    v675_7_result = unite(v675_7_result,v676_13);
  }
  const Space v675_7 = std::move(v675_7_result);
  return v675_7;
}

static Space routine_73(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v681_9_result;
  for (int v681_9_label = 1; v681_9_label <= 2; ++v681_9_label) {
    const Space v681_9_tail = child(s0,v681_9_label);
    if (v681_9_tail.empty()) continue;
    const Path v681_9_head{v681_9_label};
    const Space v682_2 = singleton(v681_9_head);
    const Space v682_3 = intersect(constant_14,v682_2);
    const Space v682_4 = (has_head(v682_3) ? constant_15 : Space{});
    const Space v682_5 = subtract(constant_0,v682_4);
    Space v682_6_result;
    for (int v682_6_label = 1; v682_6_label <= 2; ++v682_6_label) {
      const Space v682_6_tail = child(v681_9_tail,v682_6_label);
      if (v682_6_tail.empty()) continue;
      const Path v682_6_head{v682_6_label};
      const Space v683_2 = Space{};
      v682_6_result = unite(v682_6_result,v683_2);
    }
    const Space v682_6 = std::move(v682_6_result);
    const Space v682_7 = compose(v682_5,v682_6);
    const Space v682_8 = intersect(constant_14,v682_2);
    const Space v682_9 = (has_head(v682_8) ? constant_15 : Space{});
    Space v682_12;
    if (!v682_9.empty()) {
      const Path v684_10 = concat_path(p0,v681_9_head);
      Space v684_11_result;
      for (int v684_11_label = 1; v684_11_label <= 2; ++v684_11_label) {
        const Space v684_11_tail = child(v681_9_tail,v684_11_label);
        if (v684_11_tail.empty()) continue;
        const Path v684_11_head{v684_11_label};
        const Space v685_2 = singleton(v684_11_head);
        const Space v685_3 = intersect(constant_14,v685_2);
        const Space v685_4 = (has_head(v685_3) ? constant_15 : Space{});
        const Space v685_5 = subtract(constant_0,v685_4);
        Space v685_7;
        if (!v685_5.empty()) {
          const Space v686_6 = routine_36(c, v684_11_head, v684_10, v684_11_tail, s1);
          v685_7 = compose(v685_5,v686_6);
        }
        const Space v685_8 = intersect(constant_14,v685_2);
        const Space v685_9 = (has_head(v685_8) ? constant_15 : Space{});
        Space v685_11;
        if (!v685_9.empty()) {
          const Space v687_10 = routine_37(c, v684_11_head, v684_10, v684_11_tail, s1);
          v685_11 = compose(v685_9,v687_10);
        }
        const Space v685_12 = unite(v685_7,v685_11);
        v684_11_result = unite(v684_11_result,v685_12);
      }
      const Space v684_11 = std::move(v684_11_result);
      v682_12 = compose(v682_9,v684_11);
    }
    const Space v682_13 = unite(v682_7,v682_12);
    v681_9_result = unite(v681_9_result,v682_13);
  }
  const Space v681_9 = std::move(v681_9_result);
  return v681_9;
}

static Space routine_74(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v688_13_result;
  for (int v688_13_label = 1; v688_13_label <= 2; ++v688_13_label) {
    const Space v688_13_tail = child(s0,v688_13_label);
    if (v688_13_tail.empty()) continue;
    const Path v688_13_head{v688_13_label};
    const Space v689_2 = singleton(v688_13_head);
    const Space v689_3 = intersect(constant_14,v689_2);
    const Space v689_4 = (has_head(v689_3) ? constant_15 : Space{});
    const Space v689_5 = subtract(constant_0,v689_4);
    Space v689_8;
    if (!v689_5.empty()) {
      const Path v690_6 = concat_path(p0,v688_13_head);
      Space v690_7_result;
      for (int v690_7_label = 1; v690_7_label <= 2; ++v690_7_label) {
        const Space v690_7_tail = child(v688_13_tail,v690_7_label);
        if (v690_7_tail.empty()) continue;
        const Path v690_7_head{v690_7_label};
        const Space v691_2 = singleton(v690_7_head);
        const Space v691_3 = intersect(constant_14,v691_2);
        const Space v691_4 = (has_head(v691_3) ? constant_15 : Space{});
        const Space v691_5 = subtract(constant_0,v691_4);
        Space v691_8;
        if (!v691_5.empty()) {
          const Path v692_6 = concat_path(v690_6,v690_7_head);
          const Space v692_7 = routine_110(c, v692_6, p1, v690_7_tail, s1);
          v691_8 = compose(v691_5,v692_7);
        }
        const Space v691_9 = intersect(constant_14,v691_2);
        const Space v691_10 = (has_head(v691_9) ? constant_15 : Space{});
        Space v691_12;
        if (!v691_10.empty()) {
          const Path v693_6 = concat_path(v690_6,v690_7_head);
          const Space v693_11 = routine_111(c, v693_6, p1, v690_7_tail, s1);
          v691_12 = compose(v691_10,v693_11);
        }
        const Space v691_13 = unite(v691_8,v691_12);
        v690_7_result = unite(v690_7_result,v691_13);
      }
      const Space v690_7 = std::move(v690_7_result);
      v689_8 = compose(v689_5,v690_7);
    }
    const Space v689_9 = intersect(constant_14,v689_2);
    const Space v689_10 = (has_head(v689_9) ? constant_15 : Space{});
    Space v689_12;
    if (!v689_10.empty()) {
      const Path v694_6 = concat_path(p0,v688_13_head);
      Space v694_11_result;
      for (int v694_11_label = 1; v694_11_label <= 2; ++v694_11_label) {
        const Space v694_11_tail = child(v688_13_tail,v694_11_label);
        if (v694_11_tail.empty()) continue;
        const Path v694_11_head{v694_11_label};
        const Space v695_2 = singleton(v694_11_head);
        const Space v695_3 = intersect(constant_14,v695_2);
        const Space v695_4 = (has_head(v695_3) ? constant_15 : Space{});
        const Space v695_5 = subtract(constant_0,v695_4);
        Space v695_8;
        if (!v695_5.empty()) {
          const Path v696_6 = concat_path(v694_6,v694_11_head);
          const Space v696_7 = routine_110(c, v696_6, p1, v694_11_tail, s1);
          v695_8 = compose(v695_5,v696_7);
        }
        const Space v695_9 = intersect(constant_14,v695_2);
        const Space v695_10 = (has_head(v695_9) ? constant_15 : Space{});
        Space v695_12;
        if (!v695_10.empty()) {
          const Path v697_6 = concat_path(v694_6,v694_11_head);
          const Space v697_11 = routine_40(c, v697_6, p1, v694_11_tail, s1);
          v695_12 = compose(v695_10,v697_11);
        }
        const Space v695_13 = unite(v695_8,v695_12);
        v694_11_result = unite(v694_11_result,v695_13);
      }
      const Space v694_11 = std::move(v694_11_result);
      v689_12 = compose(v689_10,v694_11);
    }
    const Space v689_13 = unite(v689_8,v689_12);
    v688_13_result = unite(v688_13_result,v689_13);
  }
  const Space v688_13 = std::move(v688_13_result);
  return v688_13;
}

static Space routine_75(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v698_8 = unwrap(s1,constant_9);
  const Space v698_10 = unwrap(v698_8,constant_10);
  const Space v698_11 = unwrap(v698_10,p0);
  Space v698_18_result;
  for (int v698_18_label = 1; v698_18_label <= 2; ++v698_18_label) {
    const Space v698_18_tail = child(s0,v698_18_label);
    if (v698_18_tail.empty()) continue;
    const Path v698_18_head{v698_18_label};
    const Space v699_2 = singleton(v698_18_head);
    const Space v699_3 = intersect(constant_14,v699_2);
    const Space v699_4 = (has_head(v699_3) ? constant_15 : Space{});
    const Space v699_5 = subtract(constant_0,v699_4);
    Space v699_8;
    if (!v699_5.empty()) {
      const Path v700_6 = concat_path(p0,v698_18_head);
      Space v700_7_result;
      for (int v700_7_label = 1; v700_7_label <= 2; ++v700_7_label) {
        const Space v700_7_tail = child(v698_18_tail,v700_7_label);
        if (v700_7_tail.empty()) continue;
        const Path v700_7_head{v700_7_label};
        const Space v701_2 = singleton(v700_7_head);
        const Space v701_3 = intersect(constant_14,v701_2);
        const Space v701_4 = (has_head(v701_3) ? constant_15 : Space{});
        const Space v701_5 = subtract(constant_0,v701_4);
        Space v701_8;
        if (!v701_5.empty()) {
          const Path v702_6 = concat_path(v700_6,v700_7_head);
          const Space v702_7 = routine_110(c, v702_6, p1, v700_7_tail, s1);
          v701_8 = compose(v701_5,v702_7);
        }
        const Space v701_9 = intersect(constant_14,v701_2);
        const Space v701_10 = (has_head(v701_9) ? constant_15 : Space{});
        Space v701_12;
        if (!v701_10.empty()) {
          const Path v703_6 = concat_path(v700_6,v700_7_head);
          const Space v703_11 = routine_111(c, v703_6, p1, v700_7_tail, s1);
          v701_12 = compose(v701_10,v703_11);
        }
        const Space v701_13 = unite(v701_8,v701_12);
        v700_7_result = unite(v700_7_result,v701_13);
      }
      const Space v700_7 = std::move(v700_7_result);
      v699_8 = compose(v699_5,v700_7);
    }
    const Space v699_9 = intersect(constant_14,v699_2);
    const Space v699_10 = (has_head(v699_9) ? constant_15 : Space{});
    Space v699_13;
    if (!v699_10.empty()) {
      const Space v704_11 = unwrap(v698_11,v698_18_head);
      Space v704_12_result;
      for (int v704_12_label = 1; v704_12_label <= 2; ++v704_12_label) {
        const Space v704_12_tail = child(v704_11,v704_12_label);
        if (v704_12_tail.empty()) continue;
        const Path v704_12_head{v704_12_label};
        const Space v705_2 = singleton(v704_12_head);
        const Space v705_3 = intersect(constant_14,v705_2);
        const Space v705_4 = (has_head(v705_3) ? constant_15 : Space{});
        const Space v705_5 = subtract(constant_0,v705_4);
        Space v705_7;
        if (!v705_5.empty()) {
          const Space v706_6 = routine_76(c, v704_12_head, p1, v704_12_tail);
          v705_7 = compose(v705_5,v706_6);
        }
        const Space v705_8 = intersect(constant_14,v705_2);
        const Space v705_9 = (has_head(v705_8) ? constant_15 : Space{});
        Space v705_11;
        if (!v705_9.empty()) {
          const Space v707_10 = routine_77(c, v704_12_head, p1, v704_12_tail);
          v705_11 = compose(v705_9,v707_10);
        }
        const Space v705_12 = unite(v705_7,v705_11);
        v704_12_result = unite(v704_12_result,v705_12);
      }
      const Space v704_12 = std::move(v704_12_result);
      v699_13 = compose(v699_10,v704_12);
    }
    const Space v699_14 = unite(v699_8,v699_13);
    v698_18_result = unite(v698_18_result,v699_14);
  }
  const Space v698_18 = std::move(v698_18_result);
  return v698_18;
}

static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v708_12_result;
  for (int v708_12_label = 1; v708_12_label <= 2; ++v708_12_label) {
    const Space v708_12_tail = child(s0,v708_12_label);
    if (v708_12_tail.empty()) continue;
    const Path v708_12_head{v708_12_label};
    const Space v709_2 = singleton(v708_12_head);
    const Space v709_3 = intersect(constant_14,v709_2);
    const Space v709_4 = (has_head(v709_3) ? constant_15 : Space{});
    const Space v709_5 = subtract(constant_0,v709_4);
    Space v709_8;
    if (!v709_5.empty()) {
      const Path v710_6 = concat_path(p0,v708_12_head);
      Space v710_7_result;
      for (int v710_7_label = 1; v710_7_label <= 2; ++v710_7_label) {
        const Space v710_7_tail = child(v708_12_tail,v710_7_label);
        if (v710_7_tail.empty()) continue;
        const Path v710_7_head{v710_7_label};
        const Space v711_2 = singleton(v710_7_head);
        const Space v711_3 = intersect(constant_14,v711_2);
        const Space v711_4 = (has_head(v711_3) ? constant_15 : Space{});
        const Space v711_5 = subtract(constant_0,v711_4);
        Space v711_8;
        if (!v711_5.empty()) {
          const Path v712_6 = concat_path(v710_6,v710_7_head);
          const Space v712_7 = routine_112(c, v712_6, p1, v710_7_tail);
          v711_8 = compose(v711_5,v712_7);
        }
        const Space v711_9 = intersect(constant_14,v711_2);
        const Space v711_10 = (has_head(v711_9) ? constant_15 : Space{});
        Space v711_12;
        if (!v711_10.empty()) {
          const Path v713_6 = concat_path(v710_6,v710_7_head);
          const Space v713_11 = routine_113(c, v713_6, p1, v710_7_tail);
          v711_12 = compose(v711_10,v713_11);
        }
        const Space v711_13 = unite(v711_8,v711_12);
        v710_7_result = unite(v710_7_result,v711_13);
      }
      const Space v710_7 = std::move(v710_7_result);
      v709_8 = compose(v709_5,v710_7);
    }
    const Space v709_9 = intersect(constant_14,v709_2);
    const Space v709_10 = (has_head(v709_9) ? constant_15 : Space{});
    Space v709_12;
    if (!v709_10.empty()) {
      const Path v714_6 = concat_path(p0,v708_12_head);
      Space v714_11_result;
      for (int v714_11_label = 1; v714_11_label <= 2; ++v714_11_label) {
        const Space v714_11_tail = child(v708_12_tail,v714_11_label);
        if (v714_11_tail.empty()) continue;
        const Path v714_11_head{v714_11_label};
        const Space v715_2 = singleton(v714_11_head);
        const Space v715_3 = intersect(constant_14,v715_2);
        const Space v715_4 = (has_head(v715_3) ? constant_15 : Space{});
        const Space v715_5 = subtract(constant_0,v715_4);
        Space v715_8;
        if (!v715_5.empty()) {
          const Path v716_6 = concat_path(v714_6,v714_11_head);
          const Space v716_7 = routine_112(c, v716_6, p1, v714_11_tail);
          v715_8 = compose(v715_5,v716_7);
        }
        const Space v715_9 = intersect(constant_14,v715_2);
        const Space v715_10 = (has_head(v715_9) ? constant_15 : Space{});
        Space v715_12;
        if (!v715_10.empty()) {
          const Path v717_6 = concat_path(v714_6,v714_11_head);
          const Space v717_11 = routine_82(c, v717_6, p1, v714_11_tail);
          v715_12 = compose(v715_10,v717_11);
        }
        const Space v715_13 = unite(v715_8,v715_12);
        v714_11_result = unite(v714_11_result,v715_13);
      }
      const Space v714_11 = std::move(v714_11_result);
      v709_12 = compose(v709_10,v714_11);
    }
    const Space v709_13 = unite(v709_8,v709_12);
    v708_12_result = unite(v708_12_result,v709_13);
  }
  const Space v708_12 = std::move(v708_12_result);
  return v708_12;
}

static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v718_9_result;
  for (int v718_9_label = 1; v718_9_label <= 2; ++v718_9_label) {
    const Space v718_9_tail = child(s0,v718_9_label);
    if (v718_9_tail.empty()) continue;
    const Path v718_9_head{v718_9_label};
    const Space v719_2 = singleton(v718_9_head);
    const Space v719_3 = intersect(constant_14,v719_2);
    const Space v719_4 = (has_head(v719_3) ? constant_15 : Space{});
    const Space v719_5 = subtract(constant_0,v719_4);
    Space v719_8;
    if (!v719_5.empty()) {
      const Path v720_6 = concat_path(p0,v718_9_head);
      Space v720_7_result;
      for (int v720_7_label = 1; v720_7_label <= 2; ++v720_7_label) {
        const Space v720_7_tail = child(v718_9_tail,v720_7_label);
        if (v720_7_tail.empty()) continue;
        const Path v720_7_head{v720_7_label};
        const Space v721_2 = singleton(v720_7_head);
        const Space v721_3 = intersect(constant_14,v721_2);
        const Space v721_4 = (has_head(v721_3) ? constant_15 : Space{});
        const Space v721_5 = subtract(constant_0,v721_4);
        Space v721_8;
        if (!v721_5.empty()) {
          const Path v722_6 = concat_path(v720_6,v720_7_head);
          const Space v722_7 = routine_112(c, v722_6, p1, v720_7_tail);
          v721_8 = compose(v721_5,v722_7);
        }
        const Space v721_9 = intersect(constant_14,v721_2);
        const Space v721_10 = (has_head(v721_9) ? constant_15 : Space{});
        Space v721_12;
        if (!v721_10.empty()) {
          const Path v723_6 = concat_path(v720_6,v720_7_head);
          const Space v723_11 = routine_113(c, v723_6, p1, v720_7_tail);
          v721_12 = compose(v721_10,v723_11);
        }
        const Space v721_13 = unite(v721_8,v721_12);
        v720_7_result = unite(v720_7_result,v721_13);
      }
      const Space v720_7 = std::move(v720_7_result);
      v719_8 = compose(v719_5,v720_7);
    }
    const Space v719_9 = intersect(constant_14,v719_2);
    const Space v719_10 = (has_head(v719_9) ? constant_15 : Space{});
    const Space v719_11 = compose(v719_10,v718_9_tail);
    const Path v724_6 = concat_path(p0,v718_9_head);
    const Space v719_12 = wrap(v719_11,v724_6);
    const Space v719_13 = wrap(v719_12,p1);
    const Space v719_14 = unite(v719_8,v719_13);
    v718_9_result = unite(v718_9_result,v719_14);
  }
  const Space v718_9 = std::move(v718_9_result);
  return v718_9;
}

static Space routine_78(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v725_13_result;
  for (int v725_13_label = 1; v725_13_label <= 2; ++v725_13_label) {
    const Space v725_13_tail = child(s0,v725_13_label);
    if (v725_13_tail.empty()) continue;
    const Path v725_13_head{v725_13_label};
    const Space v726_2 = singleton(v725_13_head);
    const Space v726_3 = intersect(constant_14,v726_2);
    const Space v726_4 = (has_head(v726_3) ? constant_15 : Space{});
    const Space v726_5 = subtract(constant_0,v726_4);
    Space v726_8;
    if (!v726_5.empty()) {
      const Path v727_6 = concat_path(p0,v725_13_head);
      Space v727_7_result;
      for (int v727_7_label = 1; v727_7_label <= 2; ++v727_7_label) {
        const Space v727_7_tail = child(v725_13_tail,v727_7_label);
        if (v727_7_tail.empty()) continue;
        const Path v727_7_head{v727_7_label};
        const Space v728_2 = singleton(v727_7_head);
        const Space v728_3 = intersect(constant_14,v728_2);
        const Space v728_4 = (has_head(v728_3) ? constant_15 : Space{});
        const Space v728_5 = subtract(constant_0,v728_4);
        Space v728_8;
        if (!v728_5.empty()) {
          const Path v729_6 = concat_path(v727_6,v727_7_head);
          const Space v729_7 = routine_114(c, v729_6, p1, v727_7_tail, s1);
          v728_8 = compose(v728_5,v729_7);
        }
        const Space v728_9 = intersect(constant_14,v728_2);
        const Space v728_10 = (has_head(v728_9) ? constant_15 : Space{});
        Space v728_12;
        if (!v728_10.empty()) {
          const Path v730_6 = concat_path(v727_6,v727_7_head);
          const Space v730_11 = routine_115(c, v730_6, p1, v727_7_tail, s1);
          v728_12 = compose(v728_10,v730_11);
        }
        const Space v728_13 = unite(v728_8,v728_12);
        v727_7_result = unite(v727_7_result,v728_13);
      }
      const Space v727_7 = std::move(v727_7_result);
      v726_8 = compose(v726_5,v727_7);
    }
    const Space v726_9 = intersect(constant_14,v726_2);
    const Space v726_10 = (has_head(v726_9) ? constant_15 : Space{});
    Space v726_12;
    if (!v726_10.empty()) {
      const Path v731_6 = concat_path(p0,v725_13_head);
      Space v731_11_result;
      for (int v731_11_label = 1; v731_11_label <= 2; ++v731_11_label) {
        const Space v731_11_tail = child(v725_13_tail,v731_11_label);
        if (v731_11_tail.empty()) continue;
        const Path v731_11_head{v731_11_label};
        const Space v732_2 = singleton(v731_11_head);
        const Space v732_3 = intersect(constant_14,v732_2);
        const Space v732_4 = (has_head(v732_3) ? constant_15 : Space{});
        const Space v732_5 = subtract(constant_0,v732_4);
        Space v732_8;
        if (!v732_5.empty()) {
          const Path v733_6 = concat_path(v731_6,v731_11_head);
          const Space v733_7 = routine_114(c, v733_6, p1, v731_11_tail, s1);
          v732_8 = compose(v732_5,v733_7);
        }
        const Space v732_9 = intersect(constant_14,v732_2);
        const Space v732_10 = (has_head(v732_9) ? constant_15 : Space{});
        Space v732_12;
        if (!v732_10.empty()) {
          const Path v734_6 = concat_path(v731_6,v731_11_head);
          const Space v734_11 = routine_40(c, v734_6, p1, v731_11_tail, s1);
          v732_12 = compose(v732_10,v734_11);
        }
        const Space v732_13 = unite(v732_8,v732_12);
        v731_11_result = unite(v731_11_result,v732_13);
      }
      const Space v731_11 = std::move(v731_11_result);
      v726_12 = compose(v726_10,v731_11);
    }
    const Space v726_13 = unite(v726_8,v726_12);
    v725_13_result = unite(v725_13_result,v726_13);
  }
  const Space v725_13 = std::move(v725_13_result);
  return v725_13;
}

static Space routine_79(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v735_8 = unwrap(s1,constant_9);
  const Space v735_10 = unwrap(v735_8,constant_10);
  const Space v735_11 = unwrap(v735_10,p0);
  Space v735_18_result;
  for (int v735_18_label = 1; v735_18_label <= 2; ++v735_18_label) {
    const Space v735_18_tail = child(s0,v735_18_label);
    if (v735_18_tail.empty()) continue;
    const Path v735_18_head{v735_18_label};
    const Space v736_2 = singleton(v735_18_head);
    const Space v736_3 = intersect(constant_14,v736_2);
    const Space v736_4 = (has_head(v736_3) ? constant_15 : Space{});
    const Space v736_5 = subtract(constant_0,v736_4);
    Space v736_8;
    if (!v736_5.empty()) {
      const Path v737_6 = concat_path(p0,v735_18_head);
      Space v737_7_result;
      for (int v737_7_label = 1; v737_7_label <= 2; ++v737_7_label) {
        const Space v737_7_tail = child(v735_18_tail,v737_7_label);
        if (v737_7_tail.empty()) continue;
        const Path v737_7_head{v737_7_label};
        const Space v738_2 = singleton(v737_7_head);
        const Space v738_3 = intersect(constant_14,v738_2);
        const Space v738_4 = (has_head(v738_3) ? constant_15 : Space{});
        const Space v738_5 = subtract(constant_0,v738_4);
        Space v738_8;
        if (!v738_5.empty()) {
          const Path v739_6 = concat_path(v737_6,v737_7_head);
          const Space v739_7 = routine_114(c, v739_6, p1, v737_7_tail, s1);
          v738_8 = compose(v738_5,v739_7);
        }
        const Space v738_9 = intersect(constant_14,v738_2);
        const Space v738_10 = (has_head(v738_9) ? constant_15 : Space{});
        Space v738_12;
        if (!v738_10.empty()) {
          const Path v740_6 = concat_path(v737_6,v737_7_head);
          const Space v740_11 = routine_115(c, v740_6, p1, v737_7_tail, s1);
          v738_12 = compose(v738_10,v740_11);
        }
        const Space v738_13 = unite(v738_8,v738_12);
        v737_7_result = unite(v737_7_result,v738_13);
      }
      const Space v737_7 = std::move(v737_7_result);
      v736_8 = compose(v736_5,v737_7);
    }
    const Space v736_9 = intersect(constant_14,v736_2);
    const Space v736_10 = (has_head(v736_9) ? constant_15 : Space{});
    Space v736_13;
    if (!v736_10.empty()) {
      const Space v741_11 = unwrap(v735_11,v735_18_head);
      Space v741_12_result;
      for (int v741_12_label = 1; v741_12_label <= 2; ++v741_12_label) {
        const Space v741_12_tail = child(v741_11,v741_12_label);
        if (v741_12_tail.empty()) continue;
        const Path v741_12_head{v741_12_label};
        const Space v742_2 = singleton(v741_12_head);
        const Space v742_3 = intersect(constant_14,v742_2);
        const Space v742_4 = (has_head(v742_3) ? constant_15 : Space{});
        const Space v742_5 = subtract(constant_0,v742_4);
        Space v742_7;
        if (!v742_5.empty()) {
          const Space v743_6 = routine_76(c, v741_12_head, p1, v741_12_tail);
          v742_7 = compose(v742_5,v743_6);
        }
        const Space v742_8 = intersect(constant_14,v742_2);
        const Space v742_9 = (has_head(v742_8) ? constant_15 : Space{});
        Space v742_11;
        if (!v742_9.empty()) {
          const Space v744_10 = routine_77(c, v741_12_head, p1, v741_12_tail);
          v742_11 = compose(v742_9,v744_10);
        }
        const Space v742_12 = unite(v742_7,v742_11);
        v741_12_result = unite(v741_12_result,v742_12);
      }
      const Space v741_12 = std::move(v741_12_result);
      v736_13 = compose(v736_10,v741_12);
    }
    const Space v736_14 = unite(v736_8,v736_13);
    v735_18_result = unite(v735_18_result,v736_14);
  }
  const Space v735_18 = std::move(v735_18_result);
  return v735_18;
}

static Space routine_80(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v745_12_result;
  for (int v745_12_label = 1; v745_12_label <= 2; ++v745_12_label) {
    const Space v745_12_tail = child(s0,v745_12_label);
    if (v745_12_tail.empty()) continue;
    const Path v745_12_head{v745_12_label};
    const Space v746_2 = singleton(v745_12_head);
    const Space v746_3 = intersect(constant_14,v746_2);
    const Space v746_4 = (has_head(v746_3) ? constant_15 : Space{});
    const Space v746_5 = subtract(constant_0,v746_4);
    Space v746_8;
    if (!v746_5.empty()) {
      const Path v747_6 = concat_path(p0,v745_12_head);
      Space v747_7_result;
      for (int v747_7_label = 1; v747_7_label <= 2; ++v747_7_label) {
        const Space v747_7_tail = child(v745_12_tail,v747_7_label);
        if (v747_7_tail.empty()) continue;
        const Path v747_7_head{v747_7_label};
        const Space v748_2 = singleton(v747_7_head);
        const Space v748_3 = intersect(constant_14,v748_2);
        const Space v748_4 = (has_head(v748_3) ? constant_15 : Space{});
        const Space v748_5 = subtract(constant_0,v748_4);
        Space v748_8;
        if (!v748_5.empty()) {
          const Path v749_6 = concat_path(v747_6,v747_7_head);
          const Space v749_7 = routine_116(c, v749_6, p1, v747_7_tail);
          v748_8 = compose(v748_5,v749_7);
        }
        const Space v748_9 = intersect(constant_14,v748_2);
        const Space v748_10 = (has_head(v748_9) ? constant_15 : Space{});
        Space v748_12;
        if (!v748_10.empty()) {
          const Path v750_6 = concat_path(v747_6,v747_7_head);
          const Space v750_11 = routine_117(c, v750_6, p1, v747_7_tail);
          v748_12 = compose(v748_10,v750_11);
        }
        const Space v748_13 = unite(v748_8,v748_12);
        v747_7_result = unite(v747_7_result,v748_13);
      }
      const Space v747_7 = std::move(v747_7_result);
      v746_8 = compose(v746_5,v747_7);
    }
    const Space v746_9 = intersect(constant_14,v746_2);
    const Space v746_10 = (has_head(v746_9) ? constant_15 : Space{});
    Space v746_12;
    if (!v746_10.empty()) {
      const Path v751_6 = concat_path(p0,v745_12_head);
      Space v751_11_result;
      for (int v751_11_label = 1; v751_11_label <= 2; ++v751_11_label) {
        const Space v751_11_tail = child(v745_12_tail,v751_11_label);
        if (v751_11_tail.empty()) continue;
        const Path v751_11_head{v751_11_label};
        const Space v752_2 = singleton(v751_11_head);
        const Space v752_3 = intersect(constant_14,v752_2);
        const Space v752_4 = (has_head(v752_3) ? constant_15 : Space{});
        const Space v752_5 = subtract(constant_0,v752_4);
        Space v752_8;
        if (!v752_5.empty()) {
          const Path v753_6 = concat_path(v751_6,v751_11_head);
          const Space v753_7 = routine_116(c, v753_6, p1, v751_11_tail);
          v752_8 = compose(v752_5,v753_7);
        }
        const Space v752_9 = intersect(constant_14,v752_2);
        const Space v752_10 = (has_head(v752_9) ? constant_15 : Space{});
        Space v752_12;
        if (!v752_10.empty()) {
          const Path v754_6 = concat_path(v751_6,v751_11_head);
          const Space v754_11 = routine_82(c, v754_6, p1, v751_11_tail);
          v752_12 = compose(v752_10,v754_11);
        }
        const Space v752_13 = unite(v752_8,v752_12);
        v751_11_result = unite(v751_11_result,v752_13);
      }
      const Space v751_11 = std::move(v751_11_result);
      v746_12 = compose(v746_10,v751_11);
    }
    const Space v746_13 = unite(v746_8,v746_12);
    v745_12_result = unite(v745_12_result,v746_13);
  }
  const Space v745_12 = std::move(v745_12_result);
  return v745_12;
}

static Space routine_81(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v755_9_result;
  for (int v755_9_label = 1; v755_9_label <= 2; ++v755_9_label) {
    const Space v755_9_tail = child(s0,v755_9_label);
    if (v755_9_tail.empty()) continue;
    const Path v755_9_head{v755_9_label};
    const Space v756_2 = singleton(v755_9_head);
    const Space v756_3 = intersect(constant_14,v756_2);
    const Space v756_4 = (has_head(v756_3) ? constant_15 : Space{});
    const Space v756_5 = subtract(constant_0,v756_4);
    Space v756_8;
    if (!v756_5.empty()) {
      const Path v757_6 = concat_path(p0,v755_9_head);
      Space v757_7_result;
      for (int v757_7_label = 1; v757_7_label <= 2; ++v757_7_label) {
        const Space v757_7_tail = child(v755_9_tail,v757_7_label);
        if (v757_7_tail.empty()) continue;
        const Path v757_7_head{v757_7_label};
        const Space v758_2 = singleton(v757_7_head);
        const Space v758_3 = intersect(constant_14,v758_2);
        const Space v758_4 = (has_head(v758_3) ? constant_15 : Space{});
        const Space v758_5 = subtract(constant_0,v758_4);
        Space v758_8;
        if (!v758_5.empty()) {
          const Path v759_6 = concat_path(v757_6,v757_7_head);
          const Space v759_7 = routine_116(c, v759_6, p1, v757_7_tail);
          v758_8 = compose(v758_5,v759_7);
        }
        const Space v758_9 = intersect(constant_14,v758_2);
        const Space v758_10 = (has_head(v758_9) ? constant_15 : Space{});
        Space v758_12;
        if (!v758_10.empty()) {
          const Path v760_6 = concat_path(v757_6,v757_7_head);
          const Space v760_11 = routine_117(c, v760_6, p1, v757_7_tail);
          v758_12 = compose(v758_10,v760_11);
        }
        const Space v758_13 = unite(v758_8,v758_12);
        v757_7_result = unite(v757_7_result,v758_13);
      }
      const Space v757_7 = std::move(v757_7_result);
      v756_8 = compose(v756_5,v757_7);
    }
    const Space v756_9 = intersect(constant_14,v756_2);
    const Space v756_10 = (has_head(v756_9) ? constant_15 : Space{});
    const Space v756_11 = compose(v756_10,v755_9_tail);
    const Path v761_6 = concat_path(p0,v755_9_head);
    const Space v756_12 = wrap(v756_11,v761_6);
    const Space v756_13 = wrap(v756_12,p1);
    const Space v756_14 = unite(v756_8,v756_13);
    v755_9_result = unite(v755_9_result,v756_14);
  }
  const Space v755_9 = std::move(v755_9_result);
  return v755_9;
}

static Space routine_82(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v762_3 = wrap(s0,p0);
  const Space v762_4 = wrap(v762_3,p1);
  return v762_4;
}

static Space routine_83(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v763_7_result;
  for (int v763_7_label = 1; v763_7_label <= 2; ++v763_7_label) {
    const Space v763_7_tail = child(s0,v763_7_label);
    if (v763_7_tail.empty()) continue;
    const Path v763_7_head{v763_7_label};
    const Space v764_2 = singleton(v763_7_head);
    const Space v764_3 = intersect(constant_14,v764_2);
    const Space v764_4 = (has_head(v764_3) ? constant_15 : Space{});
    const Space v764_5 = subtract(constant_0,v764_4);
    Space v764_6_result;
    for (int v764_6_label = 1; v764_6_label <= 2; ++v764_6_label) {
      const Space v764_6_tail = child(v763_7_tail,v764_6_label);
      if (v764_6_tail.empty()) continue;
      const Path v764_6_head{v764_6_label};
      const Space v765_2 = Space{};
      v764_6_result = unite(v764_6_result,v765_2);
    }
    const Space v764_6 = std::move(v764_6_result);
    const Space v764_7 = compose(v764_5,v764_6);
    const Space v764_8 = intersect(constant_14,v764_2);
    const Space v764_9 = (has_head(v764_8) ? constant_15 : Space{});
    Space v764_12;
    if (!v764_9.empty()) {
      const Path v766_10 = concat_path(p0,v763_7_head);
      Space v766_11_result;
      for (int v766_11_label = 1; v766_11_label <= 2; ++v766_11_label) {
        const Space v766_11_tail = child(v763_7_tail,v766_11_label);
        if (v766_11_tail.empty()) continue;
        const Path v766_11_head{v766_11_label};
        const Space v767_2 = singleton(v766_11_head);
        const Space v767_3 = intersect(constant_14,v767_2);
        const Space v767_4 = (has_head(v767_3) ? constant_15 : Space{});
        Space v767_7;
        if (!v767_4.empty()) {
          const Path v768_5 = concat_path(v766_10,v766_11_head);
          const Space v768_6 = routine_14(c, v768_5, v766_11_tail, s1);
          v767_7 = compose(v767_4,v768_6);
        }
        v766_11_result = unite(v766_11_result,v767_7);
      }
      const Space v766_11 = std::move(v766_11_result);
      v764_12 = compose(v764_9,v766_11);
    }
    const Space v764_13 = unite(v764_7,v764_12);
    v763_7_result = unite(v763_7_result,v764_13);
  }
  const Space v763_7 = std::move(v763_7_result);
  return v763_7;
}

static Space routine_84(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v769_9_result;
  for (int v769_9_label = 1; v769_9_label <= 2; ++v769_9_label) {
    const Space v769_9_tail = child(s0,v769_9_label);
    if (v769_9_tail.empty()) continue;
    const Path v769_9_head{v769_9_label};
    const Space v770_2 = singleton(v769_9_head);
    const Space v770_3 = intersect(constant_14,v770_2);
    const Space v770_4 = (has_head(v770_3) ? constant_15 : Space{});
    const Space v770_5 = subtract(constant_0,v770_4);
    Space v770_6_result;
    for (int v770_6_label = 1; v770_6_label <= 2; ++v770_6_label) {
      const Space v770_6_tail = child(v769_9_tail,v770_6_label);
      if (v770_6_tail.empty()) continue;
      const Path v770_6_head{v770_6_label};
      const Space v771_2 = Space{};
      v770_6_result = unite(v770_6_result,v771_2);
    }
    const Space v770_6 = std::move(v770_6_result);
    const Space v770_7 = compose(v770_5,v770_6);
    const Space v770_8 = intersect(constant_14,v770_2);
    const Space v770_9 = (has_head(v770_8) ? constant_15 : Space{});
    Space v770_12;
    if (!v770_9.empty()) {
      const Path v772_10 = concat_path(p0,v769_9_head);
      Space v772_11_result;
      for (int v772_11_label = 1; v772_11_label <= 2; ++v772_11_label) {
        const Space v772_11_tail = child(v769_9_tail,v772_11_label);
        if (v772_11_tail.empty()) continue;
        const Path v772_11_head{v772_11_label};
        const Space v773_2 = singleton(v772_11_head);
        const Space v773_3 = intersect(constant_14,v773_2);
        const Space v773_4 = (has_head(v773_3) ? constant_15 : Space{});
        const Space v773_5 = subtract(constant_0,v773_4);
        Space v773_7;
        if (!v773_5.empty()) {
          const Space v774_6 = routine_43(c, v772_11_head, v772_10, v772_11_tail, s1);
          v773_7 = compose(v773_5,v774_6);
        }
        const Space v773_8 = intersect(constant_14,v773_2);
        const Space v773_9 = (has_head(v773_8) ? constant_15 : Space{});
        Space v773_11;
        if (!v773_9.empty()) {
          const Space v775_10 = routine_44(c, v772_11_head, v772_10, v772_11_tail, s1);
          v773_11 = compose(v773_9,v775_10);
        }
        const Space v773_12 = unite(v773_7,v773_11);
        v772_11_result = unite(v772_11_result,v773_12);
      }
      const Space v772_11 = std::move(v772_11_result);
      v770_12 = compose(v770_9,v772_11);
    }
    const Space v770_13 = unite(v770_7,v770_12);
    v769_9_result = unite(v769_9_result,v770_13);
  }
  const Space v769_9 = std::move(v769_9_result);
  return v769_9;
}

static Space routine_85(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v776_13_result;
  for (int v776_13_label = 1; v776_13_label <= 2; ++v776_13_label) {
    const Space v776_13_tail = child(s0,v776_13_label);
    if (v776_13_tail.empty()) continue;
    const Path v776_13_head{v776_13_label};
    const Space v777_2 = singleton(v776_13_head);
    const Space v777_3 = intersect(constant_14,v777_2);
    const Space v777_4 = (has_head(v777_3) ? constant_15 : Space{});
    const Space v777_5 = subtract(constant_0,v777_4);
    Space v777_8;
    if (!v777_5.empty()) {
      const Path v778_6 = concat_path(p0,v776_13_head);
      Space v778_7_result;
      for (int v778_7_label = 1; v778_7_label <= 2; ++v778_7_label) {
        const Space v778_7_tail = child(v776_13_tail,v778_7_label);
        if (v778_7_tail.empty()) continue;
        const Path v778_7_head{v778_7_label};
        const Space v779_2 = singleton(v778_7_head);
        const Space v779_3 = intersect(constant_14,v779_2);
        const Space v779_4 = (has_head(v779_3) ? constant_15 : Space{});
        const Space v779_5 = subtract(constant_0,v779_4);
        Space v779_8;
        if (!v779_5.empty()) {
          const Path v780_6 = concat_path(v778_6,v778_7_head);
          const Space v780_7 = routine_118(c, v780_6, p1, v778_7_tail, s1);
          v779_8 = compose(v779_5,v780_7);
        }
        const Space v779_9 = intersect(constant_14,v779_2);
        const Space v779_10 = (has_head(v779_9) ? constant_15 : Space{});
        Space v779_12;
        if (!v779_10.empty()) {
          const Path v781_6 = concat_path(v778_6,v778_7_head);
          const Space v781_11 = routine_119(c, v781_6, p1, v778_7_tail, s1);
          v779_12 = compose(v779_10,v781_11);
        }
        const Space v779_13 = unite(v779_8,v779_12);
        v778_7_result = unite(v778_7_result,v779_13);
      }
      const Space v778_7 = std::move(v778_7_result);
      v777_8 = compose(v777_5,v778_7);
    }
    const Space v777_9 = intersect(constant_14,v777_2);
    const Space v777_10 = (has_head(v777_9) ? constant_15 : Space{});
    Space v777_12;
    if (!v777_10.empty()) {
      const Path v782_6 = concat_path(p0,v776_13_head);
      Space v782_11_result;
      for (int v782_11_label = 1; v782_11_label <= 2; ++v782_11_label) {
        const Space v782_11_tail = child(v776_13_tail,v782_11_label);
        if (v782_11_tail.empty()) continue;
        const Path v782_11_head{v782_11_label};
        const Space v783_2 = singleton(v782_11_head);
        const Space v783_3 = intersect(constant_14,v783_2);
        const Space v783_4 = (has_head(v783_3) ? constant_15 : Space{});
        const Space v783_5 = subtract(constant_0,v783_4);
        Space v783_8;
        if (!v783_5.empty()) {
          const Path v784_6 = concat_path(v782_6,v782_11_head);
          const Space v784_7 = routine_118(c, v784_6, p1, v782_11_tail, s1);
          v783_8 = compose(v783_5,v784_7);
        }
        const Space v783_9 = intersect(constant_14,v783_2);
        const Space v783_10 = (has_head(v783_9) ? constant_15 : Space{});
        Space v783_12;
        if (!v783_10.empty()) {
          const Path v785_6 = concat_path(v782_6,v782_11_head);
          const Space v785_11 = routine_47(c, v785_6, p1, v782_11_tail, s1);
          v783_12 = compose(v783_10,v785_11);
        }
        const Space v783_13 = unite(v783_8,v783_12);
        v782_11_result = unite(v782_11_result,v783_13);
      }
      const Space v782_11 = std::move(v782_11_result);
      v777_12 = compose(v777_10,v782_11);
    }
    const Space v777_13 = unite(v777_8,v777_12);
    v776_13_result = unite(v776_13_result,v777_13);
  }
  const Space v776_13 = std::move(v776_13_result);
  return v776_13;
}

static Space routine_86(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v786_8 = unwrap(s1,constant_7);
  const Space v786_10 = unwrap(v786_8,constant_10);
  const Space v786_11 = unwrap(v786_10,p0);
  Space v786_18_result;
  for (int v786_18_label = 1; v786_18_label <= 2; ++v786_18_label) {
    const Space v786_18_tail = child(s0,v786_18_label);
    if (v786_18_tail.empty()) continue;
    const Path v786_18_head{v786_18_label};
    const Space v787_2 = singleton(v786_18_head);
    const Space v787_3 = intersect(constant_14,v787_2);
    const Space v787_4 = (has_head(v787_3) ? constant_15 : Space{});
    const Space v787_5 = subtract(constant_0,v787_4);
    Space v787_8;
    if (!v787_5.empty()) {
      const Path v788_6 = concat_path(p0,v786_18_head);
      Space v788_7_result;
      for (int v788_7_label = 1; v788_7_label <= 2; ++v788_7_label) {
        const Space v788_7_tail = child(v786_18_tail,v788_7_label);
        if (v788_7_tail.empty()) continue;
        const Path v788_7_head{v788_7_label};
        const Space v789_2 = singleton(v788_7_head);
        const Space v789_3 = intersect(constant_14,v789_2);
        const Space v789_4 = (has_head(v789_3) ? constant_15 : Space{});
        const Space v789_5 = subtract(constant_0,v789_4);
        Space v789_8;
        if (!v789_5.empty()) {
          const Path v790_6 = concat_path(v788_6,v788_7_head);
          const Space v790_7 = routine_118(c, v790_6, p1, v788_7_tail, s1);
          v789_8 = compose(v789_5,v790_7);
        }
        const Space v789_9 = intersect(constant_14,v789_2);
        const Space v789_10 = (has_head(v789_9) ? constant_15 : Space{});
        Space v789_12;
        if (!v789_10.empty()) {
          const Path v791_6 = concat_path(v788_6,v788_7_head);
          const Space v791_11 = routine_119(c, v791_6, p1, v788_7_tail, s1);
          v789_12 = compose(v789_10,v791_11);
        }
        const Space v789_13 = unite(v789_8,v789_12);
        v788_7_result = unite(v788_7_result,v789_13);
      }
      const Space v788_7 = std::move(v788_7_result);
      v787_8 = compose(v787_5,v788_7);
    }
    const Space v787_9 = intersect(constant_14,v787_2);
    const Space v787_10 = (has_head(v787_9) ? constant_15 : Space{});
    Space v787_13;
    if (!v787_10.empty()) {
      const Space v792_11 = unwrap(v786_11,v786_18_head);
      Space v792_12_result;
      for (int v792_12_label = 1; v792_12_label <= 2; ++v792_12_label) {
        const Space v792_12_tail = child(v792_11,v792_12_label);
        if (v792_12_tail.empty()) continue;
        const Path v792_12_head{v792_12_label};
        const Space v793_2 = singleton(v792_12_head);
        const Space v793_3 = intersect(constant_14,v793_2);
        const Space v793_4 = (has_head(v793_3) ? constant_15 : Space{});
        const Space v793_5 = subtract(constant_0,v793_4);
        Space v793_7;
        if (!v793_5.empty()) {
          const Space v794_6 = routine_87(c, v792_12_head, p1, v792_12_tail);
          v793_7 = compose(v793_5,v794_6);
        }
        const Space v793_8 = intersect(constant_14,v793_2);
        const Space v793_9 = (has_head(v793_8) ? constant_15 : Space{});
        Space v793_11;
        if (!v793_9.empty()) {
          const Space v795_10 = routine_88(c, v792_12_head, p1, v792_12_tail);
          v793_11 = compose(v793_9,v795_10);
        }
        const Space v793_12 = unite(v793_7,v793_11);
        v792_12_result = unite(v792_12_result,v793_12);
      }
      const Space v792_12 = std::move(v792_12_result);
      v787_13 = compose(v787_10,v792_12);
    }
    const Space v787_14 = unite(v787_8,v787_13);
    v786_18_result = unite(v786_18_result,v787_14);
  }
  const Space v786_18 = std::move(v786_18_result);
  return v786_18;
}

static Space routine_87(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v796_12_result;
  for (int v796_12_label = 1; v796_12_label <= 2; ++v796_12_label) {
    const Space v796_12_tail = child(s0,v796_12_label);
    if (v796_12_tail.empty()) continue;
    const Path v796_12_head{v796_12_label};
    const Space v797_2 = singleton(v796_12_head);
    const Space v797_3 = intersect(constant_14,v797_2);
    const Space v797_4 = (has_head(v797_3) ? constant_15 : Space{});
    const Space v797_5 = subtract(constant_0,v797_4);
    Space v797_8;
    if (!v797_5.empty()) {
      const Path v798_6 = concat_path(p0,v796_12_head);
      Space v798_7_result;
      for (int v798_7_label = 1; v798_7_label <= 2; ++v798_7_label) {
        const Space v798_7_tail = child(v796_12_tail,v798_7_label);
        if (v798_7_tail.empty()) continue;
        const Path v798_7_head{v798_7_label};
        const Space v799_2 = singleton(v798_7_head);
        const Space v799_3 = intersect(constant_14,v799_2);
        const Space v799_4 = (has_head(v799_3) ? constant_15 : Space{});
        const Space v799_5 = subtract(constant_0,v799_4);
        Space v799_8;
        if (!v799_5.empty()) {
          const Path v800_6 = concat_path(v798_6,v798_7_head);
          const Space v800_7 = routine_120(c, v800_6, p1, v798_7_tail);
          v799_8 = compose(v799_5,v800_7);
        }
        const Space v799_9 = intersect(constant_14,v799_2);
        const Space v799_10 = (has_head(v799_9) ? constant_15 : Space{});
        Space v799_12;
        if (!v799_10.empty()) {
          const Path v801_6 = concat_path(v798_6,v798_7_head);
          const Space v801_11 = routine_121(c, v801_6, p1, v798_7_tail);
          v799_12 = compose(v799_10,v801_11);
        }
        const Space v799_13 = unite(v799_8,v799_12);
        v798_7_result = unite(v798_7_result,v799_13);
      }
      const Space v798_7 = std::move(v798_7_result);
      v797_8 = compose(v797_5,v798_7);
    }
    const Space v797_9 = intersect(constant_14,v797_2);
    const Space v797_10 = (has_head(v797_9) ? constant_15 : Space{});
    Space v797_12;
    if (!v797_10.empty()) {
      const Path v802_6 = concat_path(p0,v796_12_head);
      Space v802_11_result;
      for (int v802_11_label = 1; v802_11_label <= 2; ++v802_11_label) {
        const Space v802_11_tail = child(v796_12_tail,v802_11_label);
        if (v802_11_tail.empty()) continue;
        const Path v802_11_head{v802_11_label};
        const Space v803_2 = singleton(v802_11_head);
        const Space v803_3 = intersect(constant_14,v803_2);
        const Space v803_4 = (has_head(v803_3) ? constant_15 : Space{});
        const Space v803_5 = subtract(constant_0,v803_4);
        Space v803_8;
        if (!v803_5.empty()) {
          const Path v804_6 = concat_path(v802_6,v802_11_head);
          const Space v804_7 = routine_120(c, v804_6, p1, v802_11_tail);
          v803_8 = compose(v803_5,v804_7);
        }
        const Space v803_9 = intersect(constant_14,v803_2);
        const Space v803_10 = (has_head(v803_9) ? constant_15 : Space{});
        Space v803_12;
        if (!v803_10.empty()) {
          const Path v805_6 = concat_path(v802_6,v802_11_head);
          const Space v805_11 = routine_93(c, v805_6, p1, v802_11_tail);
          v803_12 = compose(v803_10,v805_11);
        }
        const Space v803_13 = unite(v803_8,v803_12);
        v802_11_result = unite(v802_11_result,v803_13);
      }
      const Space v802_11 = std::move(v802_11_result);
      v797_12 = compose(v797_10,v802_11);
    }
    const Space v797_13 = unite(v797_8,v797_12);
    v796_12_result = unite(v796_12_result,v797_13);
  }
  const Space v796_12 = std::move(v796_12_result);
  return v796_12;
}

static Space routine_88(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v806_9_result;
  for (int v806_9_label = 1; v806_9_label <= 2; ++v806_9_label) {
    const Space v806_9_tail = child(s0,v806_9_label);
    if (v806_9_tail.empty()) continue;
    const Path v806_9_head{v806_9_label};
    const Space v807_2 = singleton(v806_9_head);
    const Space v807_3 = intersect(constant_14,v807_2);
    const Space v807_4 = (has_head(v807_3) ? constant_15 : Space{});
    const Space v807_5 = subtract(constant_0,v807_4);
    Space v807_8;
    if (!v807_5.empty()) {
      const Path v808_6 = concat_path(p0,v806_9_head);
      Space v808_7_result;
      for (int v808_7_label = 1; v808_7_label <= 2; ++v808_7_label) {
        const Space v808_7_tail = child(v806_9_tail,v808_7_label);
        if (v808_7_tail.empty()) continue;
        const Path v808_7_head{v808_7_label};
        const Space v809_2 = singleton(v808_7_head);
        const Space v809_3 = intersect(constant_14,v809_2);
        const Space v809_4 = (has_head(v809_3) ? constant_15 : Space{});
        const Space v809_5 = subtract(constant_0,v809_4);
        Space v809_8;
        if (!v809_5.empty()) {
          const Path v810_6 = concat_path(v808_6,v808_7_head);
          const Space v810_7 = routine_120(c, v810_6, p1, v808_7_tail);
          v809_8 = compose(v809_5,v810_7);
        }
        const Space v809_9 = intersect(constant_14,v809_2);
        const Space v809_10 = (has_head(v809_9) ? constant_15 : Space{});
        Space v809_12;
        if (!v809_10.empty()) {
          const Path v811_6 = concat_path(v808_6,v808_7_head);
          const Space v811_11 = routine_121(c, v811_6, p1, v808_7_tail);
          v809_12 = compose(v809_10,v811_11);
        }
        const Space v809_13 = unite(v809_8,v809_12);
        v808_7_result = unite(v808_7_result,v809_13);
      }
      const Space v808_7 = std::move(v808_7_result);
      v807_8 = compose(v807_5,v808_7);
    }
    const Space v807_9 = intersect(constant_14,v807_2);
    const Space v807_10 = (has_head(v807_9) ? constant_15 : Space{});
    const Space v807_11 = compose(v807_10,v806_9_tail);
    const Path v812_6 = concat_path(p0,v806_9_head);
    const Space v807_12 = wrap(v807_11,v812_6);
    const Space v807_13 = wrap(v807_12,p1);
    const Space v807_14 = unite(v807_8,v807_13);
    v806_9_result = unite(v806_9_result,v807_14);
  }
  const Space v806_9 = std::move(v806_9_result);
  return v806_9;
}

static Space routine_89(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v813_13_result;
  for (int v813_13_label = 1; v813_13_label <= 2; ++v813_13_label) {
    const Space v813_13_tail = child(s0,v813_13_label);
    if (v813_13_tail.empty()) continue;
    const Path v813_13_head{v813_13_label};
    const Space v814_2 = singleton(v813_13_head);
    const Space v814_3 = intersect(constant_14,v814_2);
    const Space v814_4 = (has_head(v814_3) ? constant_15 : Space{});
    const Space v814_5 = subtract(constant_0,v814_4);
    Space v814_8;
    if (!v814_5.empty()) {
      const Path v815_6 = concat_path(p0,v813_13_head);
      Space v815_7_result;
      for (int v815_7_label = 1; v815_7_label <= 2; ++v815_7_label) {
        const Space v815_7_tail = child(v813_13_tail,v815_7_label);
        if (v815_7_tail.empty()) continue;
        const Path v815_7_head{v815_7_label};
        const Space v816_2 = singleton(v815_7_head);
        const Space v816_3 = intersect(constant_14,v816_2);
        const Space v816_4 = (has_head(v816_3) ? constant_15 : Space{});
        const Space v816_5 = subtract(constant_0,v816_4);
        Space v816_8;
        if (!v816_5.empty()) {
          const Path v817_6 = concat_path(v815_6,v815_7_head);
          const Space v817_7 = routine_122(c, v817_6, p1, v815_7_tail, s1);
          v816_8 = compose(v816_5,v817_7);
        }
        const Space v816_9 = intersect(constant_14,v816_2);
        const Space v816_10 = (has_head(v816_9) ? constant_15 : Space{});
        Space v816_12;
        if (!v816_10.empty()) {
          const Path v818_6 = concat_path(v815_6,v815_7_head);
          const Space v818_11 = routine_123(c, v818_6, p1, v815_7_tail, s1);
          v816_12 = compose(v816_10,v818_11);
        }
        const Space v816_13 = unite(v816_8,v816_12);
        v815_7_result = unite(v815_7_result,v816_13);
      }
      const Space v815_7 = std::move(v815_7_result);
      v814_8 = compose(v814_5,v815_7);
    }
    const Space v814_9 = intersect(constant_14,v814_2);
    const Space v814_10 = (has_head(v814_9) ? constant_15 : Space{});
    Space v814_12;
    if (!v814_10.empty()) {
      const Path v819_6 = concat_path(p0,v813_13_head);
      Space v819_11_result;
      for (int v819_11_label = 1; v819_11_label <= 2; ++v819_11_label) {
        const Space v819_11_tail = child(v813_13_tail,v819_11_label);
        if (v819_11_tail.empty()) continue;
        const Path v819_11_head{v819_11_label};
        const Space v820_2 = singleton(v819_11_head);
        const Space v820_3 = intersect(constant_14,v820_2);
        const Space v820_4 = (has_head(v820_3) ? constant_15 : Space{});
        const Space v820_5 = subtract(constant_0,v820_4);
        Space v820_8;
        if (!v820_5.empty()) {
          const Path v821_6 = concat_path(v819_6,v819_11_head);
          const Space v821_7 = routine_122(c, v821_6, p1, v819_11_tail, s1);
          v820_8 = compose(v820_5,v821_7);
        }
        const Space v820_9 = intersect(constant_14,v820_2);
        const Space v820_10 = (has_head(v820_9) ? constant_15 : Space{});
        Space v820_12;
        if (!v820_10.empty()) {
          const Path v822_6 = concat_path(v819_6,v819_11_head);
          const Space v822_11 = routine_47(c, v822_6, p1, v819_11_tail, s1);
          v820_12 = compose(v820_10,v822_11);
        }
        const Space v820_13 = unite(v820_8,v820_12);
        v819_11_result = unite(v819_11_result,v820_13);
      }
      const Space v819_11 = std::move(v819_11_result);
      v814_12 = compose(v814_10,v819_11);
    }
    const Space v814_13 = unite(v814_8,v814_12);
    v813_13_result = unite(v813_13_result,v814_13);
  }
  const Space v813_13 = std::move(v813_13_result);
  return v813_13;
}

static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v823_8 = unwrap(s1,constant_7);
  const Space v823_10 = unwrap(v823_8,constant_10);
  const Space v823_11 = unwrap(v823_10,p0);
  Space v823_18_result;
  for (int v823_18_label = 1; v823_18_label <= 2; ++v823_18_label) {
    const Space v823_18_tail = child(s0,v823_18_label);
    if (v823_18_tail.empty()) continue;
    const Path v823_18_head{v823_18_label};
    const Space v824_2 = singleton(v823_18_head);
    const Space v824_3 = intersect(constant_14,v824_2);
    const Space v824_4 = (has_head(v824_3) ? constant_15 : Space{});
    const Space v824_5 = subtract(constant_0,v824_4);
    Space v824_8;
    if (!v824_5.empty()) {
      const Path v825_6 = concat_path(p0,v823_18_head);
      Space v825_7_result;
      for (int v825_7_label = 1; v825_7_label <= 2; ++v825_7_label) {
        const Space v825_7_tail = child(v823_18_tail,v825_7_label);
        if (v825_7_tail.empty()) continue;
        const Path v825_7_head{v825_7_label};
        const Space v826_2 = singleton(v825_7_head);
        const Space v826_3 = intersect(constant_14,v826_2);
        const Space v826_4 = (has_head(v826_3) ? constant_15 : Space{});
        const Space v826_5 = subtract(constant_0,v826_4);
        Space v826_8;
        if (!v826_5.empty()) {
          const Path v827_6 = concat_path(v825_6,v825_7_head);
          const Space v827_7 = routine_122(c, v827_6, p1, v825_7_tail, s1);
          v826_8 = compose(v826_5,v827_7);
        }
        const Space v826_9 = intersect(constant_14,v826_2);
        const Space v826_10 = (has_head(v826_9) ? constant_15 : Space{});
        Space v826_12;
        if (!v826_10.empty()) {
          const Path v828_6 = concat_path(v825_6,v825_7_head);
          const Space v828_11 = routine_123(c, v828_6, p1, v825_7_tail, s1);
          v826_12 = compose(v826_10,v828_11);
        }
        const Space v826_13 = unite(v826_8,v826_12);
        v825_7_result = unite(v825_7_result,v826_13);
      }
      const Space v825_7 = std::move(v825_7_result);
      v824_8 = compose(v824_5,v825_7);
    }
    const Space v824_9 = intersect(constant_14,v824_2);
    const Space v824_10 = (has_head(v824_9) ? constant_15 : Space{});
    Space v824_13;
    if (!v824_10.empty()) {
      const Space v829_11 = unwrap(v823_11,v823_18_head);
      Space v829_12_result;
      for (int v829_12_label = 1; v829_12_label <= 2; ++v829_12_label) {
        const Space v829_12_tail = child(v829_11,v829_12_label);
        if (v829_12_tail.empty()) continue;
        const Path v829_12_head{v829_12_label};
        const Space v830_2 = singleton(v829_12_head);
        const Space v830_3 = intersect(constant_14,v830_2);
        const Space v830_4 = (has_head(v830_3) ? constant_15 : Space{});
        const Space v830_5 = subtract(constant_0,v830_4);
        Space v830_7;
        if (!v830_5.empty()) {
          const Space v831_6 = routine_87(c, v829_12_head, p1, v829_12_tail);
          v830_7 = compose(v830_5,v831_6);
        }
        const Space v830_8 = intersect(constant_14,v830_2);
        const Space v830_9 = (has_head(v830_8) ? constant_15 : Space{});
        Space v830_11;
        if (!v830_9.empty()) {
          const Space v832_10 = routine_88(c, v829_12_head, p1, v829_12_tail);
          v830_11 = compose(v830_9,v832_10);
        }
        const Space v830_12 = unite(v830_7,v830_11);
        v829_12_result = unite(v829_12_result,v830_12);
      }
      const Space v829_12 = std::move(v829_12_result);
      v824_13 = compose(v824_10,v829_12);
    }
    const Space v824_14 = unite(v824_8,v824_13);
    v823_18_result = unite(v823_18_result,v824_14);
  }
  const Space v823_18 = std::move(v823_18_result);
  return v823_18;
}

static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v833_12_result;
  for (int v833_12_label = 1; v833_12_label <= 2; ++v833_12_label) {
    const Space v833_12_tail = child(s0,v833_12_label);
    if (v833_12_tail.empty()) continue;
    const Path v833_12_head{v833_12_label};
    const Space v834_2 = singleton(v833_12_head);
    const Space v834_3 = intersect(constant_14,v834_2);
    const Space v834_4 = (has_head(v834_3) ? constant_15 : Space{});
    const Space v834_5 = subtract(constant_0,v834_4);
    Space v834_8;
    if (!v834_5.empty()) {
      const Path v835_6 = concat_path(p0,v833_12_head);
      Space v835_7_result;
      for (int v835_7_label = 1; v835_7_label <= 2; ++v835_7_label) {
        const Space v835_7_tail = child(v833_12_tail,v835_7_label);
        if (v835_7_tail.empty()) continue;
        const Path v835_7_head{v835_7_label};
        const Space v836_2 = singleton(v835_7_head);
        const Space v836_3 = intersect(constant_14,v836_2);
        const Space v836_4 = (has_head(v836_3) ? constant_15 : Space{});
        const Space v836_5 = subtract(constant_0,v836_4);
        Space v836_8;
        if (!v836_5.empty()) {
          const Path v837_6 = concat_path(v835_6,v835_7_head);
          const Space v837_7 = routine_124(c, v837_6, p1, v835_7_tail);
          v836_8 = compose(v836_5,v837_7);
        }
        const Space v836_9 = intersect(constant_14,v836_2);
        const Space v836_10 = (has_head(v836_9) ? constant_15 : Space{});
        Space v836_12;
        if (!v836_10.empty()) {
          const Path v838_6 = concat_path(v835_6,v835_7_head);
          const Space v838_11 = routine_125(c, v838_6, p1, v835_7_tail);
          v836_12 = compose(v836_10,v838_11);
        }
        const Space v836_13 = unite(v836_8,v836_12);
        v835_7_result = unite(v835_7_result,v836_13);
      }
      const Space v835_7 = std::move(v835_7_result);
      v834_8 = compose(v834_5,v835_7);
    }
    const Space v834_9 = intersect(constant_14,v834_2);
    const Space v834_10 = (has_head(v834_9) ? constant_15 : Space{});
    Space v834_12;
    if (!v834_10.empty()) {
      const Path v839_6 = concat_path(p0,v833_12_head);
      Space v839_11_result;
      for (int v839_11_label = 1; v839_11_label <= 2; ++v839_11_label) {
        const Space v839_11_tail = child(v833_12_tail,v839_11_label);
        if (v839_11_tail.empty()) continue;
        const Path v839_11_head{v839_11_label};
        const Space v840_2 = singleton(v839_11_head);
        const Space v840_3 = intersect(constant_14,v840_2);
        const Space v840_4 = (has_head(v840_3) ? constant_15 : Space{});
        const Space v840_5 = subtract(constant_0,v840_4);
        Space v840_8;
        if (!v840_5.empty()) {
          const Path v841_6 = concat_path(v839_6,v839_11_head);
          const Space v841_7 = routine_124(c, v841_6, p1, v839_11_tail);
          v840_8 = compose(v840_5,v841_7);
        }
        const Space v840_9 = intersect(constant_14,v840_2);
        const Space v840_10 = (has_head(v840_9) ? constant_15 : Space{});
        Space v840_12;
        if (!v840_10.empty()) {
          const Path v842_6 = concat_path(v839_6,v839_11_head);
          const Space v842_11 = routine_93(c, v842_6, p1, v839_11_tail);
          v840_12 = compose(v840_10,v842_11);
        }
        const Space v840_13 = unite(v840_8,v840_12);
        v839_11_result = unite(v839_11_result,v840_13);
      }
      const Space v839_11 = std::move(v839_11_result);
      v834_12 = compose(v834_10,v839_11);
    }
    const Space v834_13 = unite(v834_8,v834_12);
    v833_12_result = unite(v833_12_result,v834_13);
  }
  const Space v833_12 = std::move(v833_12_result);
  return v833_12;
}

static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v843_9_result;
  for (int v843_9_label = 1; v843_9_label <= 2; ++v843_9_label) {
    const Space v843_9_tail = child(s0,v843_9_label);
    if (v843_9_tail.empty()) continue;
    const Path v843_9_head{v843_9_label};
    const Space v844_2 = singleton(v843_9_head);
    const Space v844_3 = intersect(constant_14,v844_2);
    const Space v844_4 = (has_head(v844_3) ? constant_15 : Space{});
    const Space v844_5 = subtract(constant_0,v844_4);
    Space v844_8;
    if (!v844_5.empty()) {
      const Path v845_6 = concat_path(p0,v843_9_head);
      Space v845_7_result;
      for (int v845_7_label = 1; v845_7_label <= 2; ++v845_7_label) {
        const Space v845_7_tail = child(v843_9_tail,v845_7_label);
        if (v845_7_tail.empty()) continue;
        const Path v845_7_head{v845_7_label};
        const Space v846_2 = singleton(v845_7_head);
        const Space v846_3 = intersect(constant_14,v846_2);
        const Space v846_4 = (has_head(v846_3) ? constant_15 : Space{});
        const Space v846_5 = subtract(constant_0,v846_4);
        Space v846_8;
        if (!v846_5.empty()) {
          const Path v847_6 = concat_path(v845_6,v845_7_head);
          const Space v847_7 = routine_124(c, v847_6, p1, v845_7_tail);
          v846_8 = compose(v846_5,v847_7);
        }
        const Space v846_9 = intersect(constant_14,v846_2);
        const Space v846_10 = (has_head(v846_9) ? constant_15 : Space{});
        Space v846_12;
        if (!v846_10.empty()) {
          const Path v848_6 = concat_path(v845_6,v845_7_head);
          const Space v848_11 = routine_125(c, v848_6, p1, v845_7_tail);
          v846_12 = compose(v846_10,v848_11);
        }
        const Space v846_13 = unite(v846_8,v846_12);
        v845_7_result = unite(v845_7_result,v846_13);
      }
      const Space v845_7 = std::move(v845_7_result);
      v844_8 = compose(v844_5,v845_7);
    }
    const Space v844_9 = intersect(constant_14,v844_2);
    const Space v844_10 = (has_head(v844_9) ? constant_15 : Space{});
    const Space v844_11 = compose(v844_10,v843_9_tail);
    const Path v849_6 = concat_path(p0,v843_9_head);
    const Space v844_12 = wrap(v844_11,v849_6);
    const Space v844_13 = wrap(v844_12,p1);
    const Space v844_14 = unite(v844_8,v844_13);
    v843_9_result = unite(v843_9_result,v844_14);
  }
  const Space v843_9 = std::move(v843_9_result);
  return v843_9;
}

static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v850_3 = wrap(s0,p0);
  const Space v850_4 = wrap(v850_3,p1);
  return v850_4;
}

static Space routine_94(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v851_12_result;
  for (int v851_12_label = 1; v851_12_label <= 2; ++v851_12_label) {
    const Space v851_12_tail = child(s0,v851_12_label);
    if (v851_12_tail.empty()) continue;
    const Path v851_12_head{v851_12_label};
    const Space v852_2 = singleton(v851_12_head);
    const Space v852_3 = intersect(constant_14,v852_2);
    const Space v852_4 = (has_head(v852_3) ? constant_15 : Space{});
    const Space v852_5 = subtract(constant_0,v852_4);
    Space v852_8;
    if (!v852_5.empty()) {
      const Path v853_6 = concat_path(p0,v851_12_head);
      Space v853_7_result;
      for (int v853_7_label = 1; v853_7_label <= 2; ++v853_7_label) {
        const Space v853_7_tail = child(v851_12_tail,v853_7_label);
        if (v853_7_tail.empty()) continue;
        const Path v853_7_head{v853_7_label};
        const Space v854_2 = singleton(v853_7_head);
        const Space v854_3 = intersect(constant_14,v854_2);
        const Space v854_4 = (has_head(v854_3) ? constant_15 : Space{});
        const Space v854_5 = subtract(constant_0,v854_4);
        Space v854_8;
        if (!v854_5.empty()) {
          const Path v855_6 = concat_path(v853_6,v853_7_head);
          const Space v855_7 = routine_126(c, v855_6, p1, v853_7_tail);
          v854_8 = compose(v854_5,v855_7);
        }
        const Space v854_9 = intersect(constant_14,v854_2);
        const Space v854_10 = (has_head(v854_9) ? constant_15 : Space{});
        Space v854_12;
        if (!v854_10.empty()) {
          const Path v856_6 = concat_path(v853_6,v853_7_head);
          const Space v856_11 = routine_127(c, v856_6, p1, v853_7_tail);
          v854_12 = compose(v854_10,v856_11);
        }
        const Space v854_13 = unite(v854_8,v854_12);
        v853_7_result = unite(v853_7_result,v854_13);
      }
      const Space v853_7 = std::move(v853_7_result);
      v852_8 = compose(v852_5,v853_7);
    }
    const Space v852_9 = intersect(constant_14,v852_2);
    const Space v852_10 = (has_head(v852_9) ? constant_15 : Space{});
    Space v852_12;
    if (!v852_10.empty()) {
      const Path v857_6 = concat_path(p0,v851_12_head);
      Space v857_11_result;
      for (int v857_11_label = 1; v857_11_label <= 2; ++v857_11_label) {
        const Space v857_11_tail = child(v851_12_tail,v857_11_label);
        if (v857_11_tail.empty()) continue;
        const Path v857_11_head{v857_11_label};
        const Space v858_2 = singleton(v857_11_head);
        const Space v858_3 = intersect(constant_14,v858_2);
        const Space v858_4 = (has_head(v858_3) ? constant_15 : Space{});
        const Space v858_5 = subtract(constant_0,v858_4);
        Space v858_8;
        if (!v858_5.empty()) {
          const Path v859_6 = concat_path(v857_6,v857_11_head);
          const Space v859_7 = routine_126(c, v859_6, p1, v857_11_tail);
          v858_8 = compose(v858_5,v859_7);
        }
        const Space v858_9 = intersect(constant_14,v858_2);
        const Space v858_10 = (has_head(v858_9) ? constant_15 : Space{});
        Space v858_12;
        if (!v858_10.empty()) {
          const Path v860_6 = concat_path(v857_6,v857_11_head);
          const Space v860_11 = routine_52(c, v860_6, p1, v857_11_tail);
          v858_12 = compose(v858_10,v860_11);
        }
        const Space v858_13 = unite(v858_8,v858_12);
        v857_11_result = unite(v857_11_result,v858_13);
      }
      const Space v857_11 = std::move(v857_11_result);
      v852_12 = compose(v852_10,v857_11);
    }
    const Space v852_13 = unite(v852_8,v852_12);
    v851_12_result = unite(v851_12_result,v852_13);
  }
  const Space v851_12 = std::move(v851_12_result);
  return v851_12;
}

static Space routine_95(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v861_10_result;
  for (int v861_10_label = 1; v861_10_label <= 2; ++v861_10_label) {
    const Space v861_10_tail = child(s0,v861_10_label);
    if (v861_10_tail.empty()) continue;
    const Path v861_10_head{v861_10_label};
    const Space v862_2 = singleton(v861_10_head);
    const Space v862_3 = intersect(constant_14,v862_2);
    const Space v862_4 = (has_head(v862_3) ? constant_15 : Space{});
    const Space v862_5 = compose(v862_4,v861_10_tail);
    const Path v863_6 = concat_path(p0,v861_10_head);
    const Space v862_7 = wrap(v862_5,v863_6);
    const Space v862_8 = wrap(v862_7,p1);
    const Space v862_9 = wrap(v862_8,constant_10);
    const Space v862_10 = intersect(constant_14,v862_2);
    const Space v862_11 = (has_head(v862_10) ? constant_15 : Space{});
    const Space v862_12 = subtract(constant_0,v862_11);
    Space v862_14;
    if (!v862_12.empty()) {
      Space v864_13_result;
      for (int v864_13_label = 1; v864_13_label <= 2; ++v864_13_label) {
        const Space v864_13_tail = child(v861_10_tail,v864_13_label);
        if (v864_13_tail.empty()) continue;
        const Path v864_13_head{v864_13_label};
        const Space v865_2 = singleton(v864_13_head);
        const Space v865_3 = intersect(constant_14,v865_2);
        const Space v865_4 = (has_head(v865_3) ? constant_15 : Space{});
        const Space v865_5 = subtract(constant_0,v865_4);
        Space v865_8;
        if (!v865_5.empty()) {
          const Path v866_6 = concat_path(v863_6,v864_13_head);
          const Space v866_7 = routine_126(c, v866_6, p1, v864_13_tail);
          v865_8 = compose(v865_5,v866_7);
        }
        const Space v865_9 = intersect(constant_14,v865_2);
        const Space v865_10 = (has_head(v865_9) ? constant_15 : Space{});
        Space v865_12;
        if (!v865_10.empty()) {
          const Path v867_6 = concat_path(v863_6,v864_13_head);
          const Space v867_11 = routine_127(c, v867_6, p1, v864_13_tail);
          v865_12 = compose(v865_10,v867_11);
        }
        const Space v865_13 = unite(v865_8,v865_12);
        v864_13_result = unite(v864_13_result,v865_13);
      }
      const Space v864_13 = std::move(v864_13_result);
      v862_14 = compose(v862_12,v864_13);
    }
    const Space v862_15 = unite(v862_9,v862_14);
    v861_10_result = unite(v861_10_result,v862_15);
  }
  const Space v861_10 = std::move(v861_10_result);
  return v861_10;
}

static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v868_12_result;
  for (int v868_12_label = 1; v868_12_label <= 2; ++v868_12_label) {
    const Space v868_12_tail = child(s0,v868_12_label);
    if (v868_12_tail.empty()) continue;
    const Path v868_12_head{v868_12_label};
    const Space v869_2 = singleton(v868_12_head);
    const Space v869_3 = intersect(constant_14,v869_2);
    const Space v869_4 = (has_head(v869_3) ? constant_15 : Space{});
    const Space v869_5 = subtract(constant_0,v869_4);
    Space v869_8;
    if (!v869_5.empty()) {
      const Path v870_6 = concat_path(p0,v868_12_head);
      Space v870_7_result;
      for (int v870_7_label = 1; v870_7_label <= 2; ++v870_7_label) {
        const Space v870_7_tail = child(v868_12_tail,v870_7_label);
        if (v870_7_tail.empty()) continue;
        const Path v870_7_head{v870_7_label};
        const Space v871_2 = singleton(v870_7_head);
        const Space v871_3 = intersect(constant_14,v871_2);
        const Space v871_4 = (has_head(v871_3) ? constant_15 : Space{});
        const Space v871_5 = subtract(constant_0,v871_4);
        Space v871_8;
        if (!v871_5.empty()) {
          const Path v872_6 = concat_path(v870_6,v870_7_head);
          const Space v872_7 = routine_128(c, v872_6, p1, v870_7_tail);
          v871_8 = compose(v871_5,v872_7);
        }
        const Space v871_9 = intersect(constant_14,v871_2);
        const Space v871_10 = (has_head(v871_9) ? constant_15 : Space{});
        Space v871_12;
        if (!v871_10.empty()) {
          const Path v873_6 = concat_path(v870_6,v870_7_head);
          const Space v873_11 = routine_129(c, v873_6, p1, v870_7_tail);
          v871_12 = compose(v871_10,v873_11);
        }
        const Space v871_13 = unite(v871_8,v871_12);
        v870_7_result = unite(v870_7_result,v871_13);
      }
      const Space v870_7 = std::move(v870_7_result);
      v869_8 = compose(v869_5,v870_7);
    }
    const Space v869_9 = intersect(constant_14,v869_2);
    const Space v869_10 = (has_head(v869_9) ? constant_15 : Space{});
    Space v869_12;
    if (!v869_10.empty()) {
      const Path v874_6 = concat_path(p0,v868_12_head);
      Space v874_11_result;
      for (int v874_11_label = 1; v874_11_label <= 2; ++v874_11_label) {
        const Space v874_11_tail = child(v868_12_tail,v874_11_label);
        if (v874_11_tail.empty()) continue;
        const Path v874_11_head{v874_11_label};
        const Space v875_2 = singleton(v874_11_head);
        const Space v875_3 = intersect(constant_14,v875_2);
        const Space v875_4 = (has_head(v875_3) ? constant_15 : Space{});
        const Space v875_5 = subtract(constant_0,v875_4);
        Space v875_8;
        if (!v875_5.empty()) {
          const Path v876_6 = concat_path(v874_6,v874_11_head);
          const Space v876_7 = routine_128(c, v876_6, p1, v874_11_tail);
          v875_8 = compose(v875_5,v876_7);
        }
        const Space v875_9 = intersect(constant_14,v875_2);
        const Space v875_10 = (has_head(v875_9) ? constant_15 : Space{});
        Space v875_12;
        if (!v875_10.empty()) {
          const Path v877_6 = concat_path(v874_6,v874_11_head);
          const Space v877_11 = routine_52(c, v877_6, p1, v874_11_tail);
          v875_12 = compose(v875_10,v877_11);
        }
        const Space v875_13 = unite(v875_8,v875_12);
        v874_11_result = unite(v874_11_result,v875_13);
      }
      const Space v874_11 = std::move(v874_11_result);
      v869_12 = compose(v869_10,v874_11);
    }
    const Space v869_13 = unite(v869_8,v869_12);
    v868_12_result = unite(v868_12_result,v869_13);
  }
  const Space v868_12 = std::move(v868_12_result);
  return v868_12;
}

static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v878_10_result;
  for (int v878_10_label = 1; v878_10_label <= 2; ++v878_10_label) {
    const Space v878_10_tail = child(s0,v878_10_label);
    if (v878_10_tail.empty()) continue;
    const Path v878_10_head{v878_10_label};
    const Space v879_2 = singleton(v878_10_head);
    const Space v879_3 = intersect(constant_14,v879_2);
    const Space v879_4 = (has_head(v879_3) ? constant_15 : Space{});
    const Space v879_5 = compose(v879_4,v878_10_tail);
    const Path v880_6 = concat_path(p0,v878_10_head);
    const Space v879_7 = wrap(v879_5,v880_6);
    const Space v879_8 = wrap(v879_7,p1);
    const Space v879_9 = wrap(v879_8,constant_10);
    const Space v879_10 = intersect(constant_14,v879_2);
    const Space v879_11 = (has_head(v879_10) ? constant_15 : Space{});
    const Space v879_12 = subtract(constant_0,v879_11);
    Space v879_14;
    if (!v879_12.empty()) {
      Space v881_13_result;
      for (int v881_13_label = 1; v881_13_label <= 2; ++v881_13_label) {
        const Space v881_13_tail = child(v878_10_tail,v881_13_label);
        if (v881_13_tail.empty()) continue;
        const Path v881_13_head{v881_13_label};
        const Space v882_2 = singleton(v881_13_head);
        const Space v882_3 = intersect(constant_14,v882_2);
        const Space v882_4 = (has_head(v882_3) ? constant_15 : Space{});
        const Space v882_5 = subtract(constant_0,v882_4);
        Space v882_8;
        if (!v882_5.empty()) {
          const Path v883_6 = concat_path(v880_6,v881_13_head);
          const Space v883_7 = routine_128(c, v883_6, p1, v881_13_tail);
          v882_8 = compose(v882_5,v883_7);
        }
        const Space v882_9 = intersect(constant_14,v882_2);
        const Space v882_10 = (has_head(v882_9) ? constant_15 : Space{});
        Space v882_12;
        if (!v882_10.empty()) {
          const Path v884_6 = concat_path(v880_6,v881_13_head);
          const Space v884_11 = routine_129(c, v884_6, p1, v881_13_tail);
          v882_12 = compose(v882_10,v884_11);
        }
        const Space v882_13 = unite(v882_8,v882_12);
        v881_13_result = unite(v881_13_result,v882_13);
      }
      const Space v881_13 = std::move(v881_13_result);
      v879_14 = compose(v879_12,v881_13);
    }
    const Space v879_15 = unite(v879_9,v879_14);
    v878_10_result = unite(v878_10_result,v879_15);
  }
  const Space v878_10 = std::move(v878_10_result);
  return v878_10;
}

static Space routine_98(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v885_13_result;
  for (int v885_13_label = 1; v885_13_label <= 2; ++v885_13_label) {
    const Space v885_13_tail = child(s0,v885_13_label);
    if (v885_13_tail.empty()) continue;
    const Path v885_13_head{v885_13_label};
    const Space v886_2 = singleton(v885_13_head);
    const Space v886_3 = intersect(constant_14,v886_2);
    const Space v886_4 = (has_head(v886_3) ? constant_15 : Space{});
    const Space v886_5 = subtract(constant_0,v886_4);
    Space v886_8;
    if (!v886_5.empty()) {
      const Path v887_6 = concat_path(p0,v885_13_head);
      Space v887_7_result;
      for (int v887_7_label = 1; v887_7_label <= 2; ++v887_7_label) {
        const Space v887_7_tail = child(v885_13_tail,v887_7_label);
        if (v887_7_tail.empty()) continue;
        const Path v887_7_head{v887_7_label};
        const Space v888_2 = singleton(v887_7_head);
        const Space v888_3 = intersect(constant_14,v888_2);
        const Space v888_4 = (has_head(v888_3) ? constant_15 : Space{});
        const Space v888_5 = subtract(constant_0,v888_4);
        Space v888_8;
        if (!v888_5.empty()) {
          const Path v889_6 = concat_path(v887_6,v887_7_head);
          const Space v889_7 = routine_130(c, v889_6, p1, v887_7_tail, s1);
          v888_8 = compose(v888_5,v889_7);
        }
        const Space v888_9 = intersect(constant_14,v888_2);
        const Space v888_10 = (has_head(v888_9) ? constant_15 : Space{});
        Space v888_12;
        if (!v888_10.empty()) {
          const Path v890_6 = concat_path(v887_6,v887_7_head);
          const Space v890_11 = routine_131(c, v890_6, p1, v887_7_tail, s1);
          v888_12 = compose(v888_10,v890_11);
        }
        const Space v888_13 = unite(v888_8,v888_12);
        v887_7_result = unite(v887_7_result,v888_13);
      }
      const Space v887_7 = std::move(v887_7_result);
      v886_8 = compose(v886_5,v887_7);
    }
    const Space v886_9 = intersect(constant_14,v886_2);
    const Space v886_10 = (has_head(v886_9) ? constant_15 : Space{});
    Space v886_12;
    if (!v886_10.empty()) {
      const Path v891_6 = concat_path(p0,v885_13_head);
      Space v891_11_result;
      for (int v891_11_label = 1; v891_11_label <= 2; ++v891_11_label) {
        const Space v891_11_tail = child(v885_13_tail,v891_11_label);
        if (v891_11_tail.empty()) continue;
        const Path v891_11_head{v891_11_label};
        const Space v892_2 = singleton(v891_11_head);
        const Space v892_3 = intersect(constant_14,v892_2);
        const Space v892_4 = (has_head(v892_3) ? constant_15 : Space{});
        const Space v892_5 = subtract(constant_0,v892_4);
        Space v892_8;
        if (!v892_5.empty()) {
          const Path v893_6 = concat_path(v891_6,v891_11_head);
          const Space v893_7 = routine_130(c, v893_6, p1, v891_11_tail, s1);
          v892_8 = compose(v892_5,v893_7);
        }
        const Space v892_9 = intersect(constant_14,v892_2);
        const Space v892_10 = (has_head(v892_9) ? constant_15 : Space{});
        Space v892_12;
        if (!v892_10.empty()) {
          const Path v894_6 = concat_path(v891_6,v891_11_head);
          const Space v894_11 = routine_26(c, v894_6, p1, v891_11_tail, s1);
          v892_12 = compose(v892_10,v894_11);
        }
        const Space v892_13 = unite(v892_8,v892_12);
        v891_11_result = unite(v891_11_result,v892_13);
      }
      const Space v891_11 = std::move(v891_11_result);
      v886_12 = compose(v886_10,v891_11);
    }
    const Space v886_13 = unite(v886_8,v886_12);
    v885_13_result = unite(v885_13_result,v886_13);
  }
  const Space v885_13 = std::move(v885_13_result);
  return v885_13;
}

static Space routine_99(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v895_8 = unwrap(s1,constant_7);
  const Space v895_10 = unwrap(v895_8,constant_10);
  const Space v895_11 = unwrap(v895_10,p0);
  Space v895_18_result;
  for (int v895_18_label = 1; v895_18_label <= 2; ++v895_18_label) {
    const Space v895_18_tail = child(s0,v895_18_label);
    if (v895_18_tail.empty()) continue;
    const Path v895_18_head{v895_18_label};
    const Space v896_2 = singleton(v895_18_head);
    const Space v896_3 = intersect(constant_14,v896_2);
    const Space v896_4 = (has_head(v896_3) ? constant_15 : Space{});
    const Space v896_5 = subtract(constant_0,v896_4);
    Space v896_8;
    if (!v896_5.empty()) {
      const Path v897_6 = concat_path(p0,v895_18_head);
      Space v897_7_result;
      for (int v897_7_label = 1; v897_7_label <= 2; ++v897_7_label) {
        const Space v897_7_tail = child(v895_18_tail,v897_7_label);
        if (v897_7_tail.empty()) continue;
        const Path v897_7_head{v897_7_label};
        const Space v898_2 = singleton(v897_7_head);
        const Space v898_3 = intersect(constant_14,v898_2);
        const Space v898_4 = (has_head(v898_3) ? constant_15 : Space{});
        const Space v898_5 = subtract(constant_0,v898_4);
        Space v898_8;
        if (!v898_5.empty()) {
          const Path v899_6 = concat_path(v897_6,v897_7_head);
          const Space v899_7 = routine_130(c, v899_6, p1, v897_7_tail, s1);
          v898_8 = compose(v898_5,v899_7);
        }
        const Space v898_9 = intersect(constant_14,v898_2);
        const Space v898_10 = (has_head(v898_9) ? constant_15 : Space{});
        Space v898_12;
        if (!v898_10.empty()) {
          const Path v900_6 = concat_path(v897_6,v897_7_head);
          const Space v900_11 = routine_131(c, v900_6, p1, v897_7_tail, s1);
          v898_12 = compose(v898_10,v900_11);
        }
        const Space v898_13 = unite(v898_8,v898_12);
        v897_7_result = unite(v897_7_result,v898_13);
      }
      const Space v897_7 = std::move(v897_7_result);
      v896_8 = compose(v896_5,v897_7);
    }
    const Space v896_9 = intersect(constant_14,v896_2);
    const Space v896_10 = (has_head(v896_9) ? constant_15 : Space{});
    Space v896_13;
    if (!v896_10.empty()) {
      const Space v901_11 = unwrap(v895_11,v895_18_head);
      Space v901_12_result;
      for (int v901_12_label = 1; v901_12_label <= 2; ++v901_12_label) {
        const Space v901_12_tail = child(v901_11,v901_12_label);
        if (v901_12_tail.empty()) continue;
        const Path v901_12_head{v901_12_label};
        const Space v902_2 = singleton(v901_12_head);
        const Space v902_3 = intersect(constant_14,v902_2);
        const Space v902_4 = (has_head(v902_3) ? constant_15 : Space{});
        const Space v902_5 = subtract(constant_0,v902_4);
        Space v902_7;
        if (!v902_5.empty()) {
          const Space v903_6 = routine_59(c, v901_12_head, p1, v901_12_tail);
          v902_7 = compose(v902_5,v903_6);
        }
        const Space v902_8 = intersect(constant_14,v902_2);
        const Space v902_9 = (has_head(v902_8) ? constant_15 : Space{});
        Space v902_11;
        if (!v902_9.empty()) {
          const Space v904_10 = routine_60(c, v901_12_head, p1, v901_12_tail);
          v902_11 = compose(v902_9,v904_10);
        }
        const Space v902_12 = unite(v902_7,v902_11);
        v901_12_result = unite(v901_12_result,v902_12);
      }
      const Space v901_12 = std::move(v901_12_result);
      v896_13 = compose(v896_10,v901_12);
    }
    const Space v896_14 = unite(v896_8,v896_13);
    v895_18_result = unite(v895_18_result,v896_14);
  }
  const Space v895_18 = std::move(v895_18_result);
  return v895_18;
}

static Space routine_100(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v905_12_result;
  for (int v905_12_label = 1; v905_12_label <= 2; ++v905_12_label) {
    const Space v905_12_tail = child(s0,v905_12_label);
    if (v905_12_tail.empty()) continue;
    const Path v905_12_head{v905_12_label};
    const Space v906_2 = singleton(v905_12_head);
    const Space v906_3 = intersect(constant_14,v906_2);
    const Space v906_4 = (has_head(v906_3) ? constant_15 : Space{});
    const Space v906_5 = subtract(constant_0,v906_4);
    Space v906_8;
    if (!v906_5.empty()) {
      const Path v907_6 = concat_path(p0,v905_12_head);
      Space v907_7_result;
      for (int v907_7_label = 1; v907_7_label <= 2; ++v907_7_label) {
        const Space v907_7_tail = child(v905_12_tail,v907_7_label);
        if (v907_7_tail.empty()) continue;
        const Path v907_7_head{v907_7_label};
        const Space v908_2 = singleton(v907_7_head);
        const Space v908_3 = intersect(constant_14,v908_2);
        const Space v908_4 = (has_head(v908_3) ? constant_15 : Space{});
        const Space v908_5 = subtract(constant_0,v908_4);
        Space v908_8;
        if (!v908_5.empty()) {
          const Path v909_6 = concat_path(v907_6,v907_7_head);
          const Space v909_7 = routine_132(c, v909_6, p1, v907_7_tail);
          v908_8 = compose(v908_5,v909_7);
        }
        const Space v908_9 = intersect(constant_14,v908_2);
        const Space v908_10 = (has_head(v908_9) ? constant_15 : Space{});
        Space v908_12;
        if (!v908_10.empty()) {
          const Path v910_6 = concat_path(v907_6,v907_7_head);
          const Space v910_11 = routine_133(c, v910_6, p1, v907_7_tail);
          v908_12 = compose(v908_10,v910_11);
        }
        const Space v908_13 = unite(v908_8,v908_12);
        v907_7_result = unite(v907_7_result,v908_13);
      }
      const Space v907_7 = std::move(v907_7_result);
      v906_8 = compose(v906_5,v907_7);
    }
    const Space v906_9 = intersect(constant_14,v906_2);
    const Space v906_10 = (has_head(v906_9) ? constant_15 : Space{});
    Space v906_12;
    if (!v906_10.empty()) {
      const Path v911_6 = concat_path(p0,v905_12_head);
      Space v911_11_result;
      for (int v911_11_label = 1; v911_11_label <= 2; ++v911_11_label) {
        const Space v911_11_tail = child(v905_12_tail,v911_11_label);
        if (v911_11_tail.empty()) continue;
        const Path v911_11_head{v911_11_label};
        const Space v912_2 = singleton(v911_11_head);
        const Space v912_3 = intersect(constant_14,v912_2);
        const Space v912_4 = (has_head(v912_3) ? constant_15 : Space{});
        const Space v912_5 = subtract(constant_0,v912_4);
        Space v912_8;
        if (!v912_5.empty()) {
          const Path v913_6 = concat_path(v911_6,v911_11_head);
          const Space v913_7 = routine_132(c, v913_6, p1, v911_11_tail);
          v912_8 = compose(v912_5,v913_7);
        }
        const Space v912_9 = intersect(constant_14,v912_2);
        const Space v912_10 = (has_head(v912_9) ? constant_15 : Space{});
        Space v912_12;
        if (!v912_10.empty()) {
          const Path v914_6 = concat_path(v911_6,v911_11_head);
          const Space v914_11 = routine_65(c, v914_6, p1, v911_11_tail);
          v912_12 = compose(v912_10,v914_11);
        }
        const Space v912_13 = unite(v912_8,v912_12);
        v911_11_result = unite(v911_11_result,v912_13);
      }
      const Space v911_11 = std::move(v911_11_result);
      v906_12 = compose(v906_10,v911_11);
    }
    const Space v906_13 = unite(v906_8,v906_12);
    v905_12_result = unite(v905_12_result,v906_13);
  }
  const Space v905_12 = std::move(v905_12_result);
  return v905_12;
}

static Space routine_101(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v915_9_result;
  for (int v915_9_label = 1; v915_9_label <= 2; ++v915_9_label) {
    const Space v915_9_tail = child(s0,v915_9_label);
    if (v915_9_tail.empty()) continue;
    const Path v915_9_head{v915_9_label};
    const Space v916_2 = singleton(v915_9_head);
    const Space v916_3 = intersect(constant_14,v916_2);
    const Space v916_4 = (has_head(v916_3) ? constant_15 : Space{});
    const Space v916_5 = subtract(constant_0,v916_4);
    Space v916_8;
    if (!v916_5.empty()) {
      const Path v917_6 = concat_path(p0,v915_9_head);
      Space v917_7_result;
      for (int v917_7_label = 1; v917_7_label <= 2; ++v917_7_label) {
        const Space v917_7_tail = child(v915_9_tail,v917_7_label);
        if (v917_7_tail.empty()) continue;
        const Path v917_7_head{v917_7_label};
        const Space v918_2 = singleton(v917_7_head);
        const Space v918_3 = intersect(constant_14,v918_2);
        const Space v918_4 = (has_head(v918_3) ? constant_15 : Space{});
        const Space v918_5 = subtract(constant_0,v918_4);
        Space v918_8;
        if (!v918_5.empty()) {
          const Path v919_6 = concat_path(v917_6,v917_7_head);
          const Space v919_7 = routine_132(c, v919_6, p1, v917_7_tail);
          v918_8 = compose(v918_5,v919_7);
        }
        const Space v918_9 = intersect(constant_14,v918_2);
        const Space v918_10 = (has_head(v918_9) ? constant_15 : Space{});
        Space v918_12;
        if (!v918_10.empty()) {
          const Path v920_6 = concat_path(v917_6,v917_7_head);
          const Space v920_11 = routine_133(c, v920_6, p1, v917_7_tail);
          v918_12 = compose(v918_10,v920_11);
        }
        const Space v918_13 = unite(v918_8,v918_12);
        v917_7_result = unite(v917_7_result,v918_13);
      }
      const Space v917_7 = std::move(v917_7_result);
      v916_8 = compose(v916_5,v917_7);
    }
    const Space v916_9 = intersect(constant_14,v916_2);
    const Space v916_10 = (has_head(v916_9) ? constant_15 : Space{});
    const Space v916_11 = compose(v916_10,v915_9_tail);
    const Path v921_6 = concat_path(p0,v915_9_head);
    const Space v916_12 = wrap(v916_11,v921_6);
    const Space v916_13 = wrap(v916_12,p1);
    const Space v916_14 = unite(v916_8,v916_13);
    v915_9_result = unite(v915_9_result,v916_14);
  }
  const Space v915_9 = std::move(v915_9_result);
  return v915_9;
}

static Space routine_102(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v922_8_result;
  for (int v922_8_label = 1; v922_8_label <= 2; ++v922_8_label) {
    const Space v922_8_tail = child(s0,v922_8_label);
    if (v922_8_tail.empty()) continue;
    const Path v922_8_head{v922_8_label};
    const Space v923_2 = singleton(v922_8_head);
    const Space v923_3 = intersect(constant_14,v923_2);
    const Space v923_4 = (has_head(v923_3) ? constant_15 : Space{});
    const Space v923_5 = subtract(constant_0,v923_4);
    Space v923_6_result;
    for (int v923_6_label = 1; v923_6_label <= 2; ++v923_6_label) {
      const Space v923_6_tail = child(v922_8_tail,v923_6_label);
      if (v923_6_tail.empty()) continue;
      const Path v923_6_head{v923_6_label};
      const Space v924_2 = Space{};
      v923_6_result = unite(v923_6_result,v924_2);
    }
    const Space v923_6 = std::move(v923_6_result);
    const Space v923_7 = compose(v923_5,v923_6);
    const Space v923_8 = intersect(constant_14,v923_2);
    const Space v923_9 = (has_head(v923_8) ? constant_15 : Space{});
    Space v923_12;
    if (!v923_9.empty()) {
      const Path v925_10 = concat_path(p0,v922_8_head);
      Space v925_11_result;
      for (int v925_11_label = 1; v925_11_label <= 2; ++v925_11_label) {
        const Space v925_11_tail = child(v922_8_tail,v925_11_label);
        if (v925_11_tail.empty()) continue;
        const Path v925_11_head{v925_11_label};
        const Space v926_2 = singleton(v925_11_head);
        const Space v926_3 = intersect(constant_14,v926_2);
        const Space v926_4 = (has_head(v926_3) ? constant_15 : Space{});
        Space v926_7;
        if (!v926_4.empty()) {
          const Path v927_5 = concat_path(v925_10,v925_11_head);
          const Space v927_6 = routine_26(c, v927_5, p1, v925_11_tail, s1);
          v926_7 = compose(v926_4,v927_6);
        }
        v925_11_result = unite(v925_11_result,v926_7);
      }
      const Space v925_11 = std::move(v925_11_result);
      v923_12 = compose(v923_9,v925_11);
    }
    const Space v923_13 = unite(v923_7,v923_12);
    v922_8_result = unite(v922_8_result,v923_13);
  }
  const Space v922_8 = std::move(v922_8_result);
  return v922_8;
}

static Space routine_103(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v928_8 = unwrap(s1,constant_7);
  const Space v928_10 = unwrap(v928_8,constant_10);
  const Space v928_11 = unwrap(v928_10,p0);
  Space v928_15_result;
  for (int v928_15_label = 1; v928_15_label <= 2; ++v928_15_label) {
    const Space v928_15_tail = child(s0,v928_15_label);
    if (v928_15_tail.empty()) continue;
    const Path v928_15_head{v928_15_label};
    const Space v929_2 = singleton(v928_15_head);
    const Space v929_3 = intersect(constant_14,v929_2);
    const Space v929_4 = (has_head(v929_3) ? constant_15 : Space{});
    const Space v929_5 = subtract(constant_0,v929_4);
    Space v929_6_result;
    for (int v929_6_label = 1; v929_6_label <= 2; ++v929_6_label) {
      const Space v929_6_tail = child(v928_15_tail,v929_6_label);
      if (v929_6_tail.empty()) continue;
      const Path v929_6_head{v929_6_label};
      const Space v930_2 = Space{};
      v929_6_result = unite(v929_6_result,v930_2);
    }
    const Space v929_6 = std::move(v929_6_result);
    const Space v929_7 = compose(v929_5,v929_6);
    const Space v929_8 = intersect(constant_14,v929_2);
    const Space v929_9 = (has_head(v929_8) ? constant_15 : Space{});
    Space v929_12;
    if (!v929_9.empty()) {
      const Space v931_10 = unwrap(v928_11,v928_15_head);
      Space v931_11_result;
      for (int v931_11_label = 1; v931_11_label <= 2; ++v931_11_label) {
        const Space v931_11_tail = child(v931_10,v931_11_label);
        if (v931_11_tail.empty()) continue;
        const Path v931_11_head{v931_11_label};
        const Space v932_2 = singleton(v931_11_head);
        const Space v932_3 = intersect(constant_14,v932_2);
        const Space v932_4 = (has_head(v932_3) ? constant_15 : Space{});
        const Space v932_5 = subtract(constant_0,v932_4);
        Space v932_7;
        if (!v932_5.empty()) {
          const Space v933_6 = routine_59(c, v931_11_head, p1, v931_11_tail);
          v932_7 = compose(v932_5,v933_6);
        }
        const Space v932_8 = intersect(constant_14,v932_2);
        const Space v932_9 = (has_head(v932_8) ? constant_15 : Space{});
        Space v932_11;
        if (!v932_9.empty()) {
          const Space v934_10 = routine_60(c, v931_11_head, p1, v931_11_tail);
          v932_11 = compose(v932_9,v934_10);
        }
        const Space v932_12 = unite(v932_7,v932_11);
        v931_11_result = unite(v931_11_result,v932_12);
      }
      const Space v931_11 = std::move(v931_11_result);
      v929_12 = compose(v929_9,v931_11);
    }
    const Space v929_13 = unite(v929_7,v929_12);
    v928_15_result = unite(v928_15_result,v929_13);
  }
  const Space v928_15 = std::move(v928_15_result);
  return v928_15;
}

static Space routine_104(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v935_12_result;
  for (int v935_12_label = 1; v935_12_label <= 2; ++v935_12_label) {
    const Space v935_12_tail = child(s0,v935_12_label);
    if (v935_12_tail.empty()) continue;
    const Path v935_12_head{v935_12_label};
    const Space v936_2 = singleton(v935_12_head);
    const Space v936_3 = intersect(constant_14,v936_2);
    const Space v936_4 = (has_head(v936_3) ? constant_15 : Space{});
    const Space v936_5 = subtract(constant_0,v936_4);
    Space v936_8;
    if (!v936_5.empty()) {
      const Path v937_6 = concat_path(p0,v935_12_head);
      Space v937_7_result;
      for (int v937_7_label = 1; v937_7_label <= 2; ++v937_7_label) {
        const Space v937_7_tail = child(v935_12_tail,v937_7_label);
        if (v937_7_tail.empty()) continue;
        const Path v937_7_head{v937_7_label};
        const Space v938_2 = singleton(v937_7_head);
        const Space v938_3 = intersect(constant_14,v938_2);
        const Space v938_4 = (has_head(v938_3) ? constant_15 : Space{});
        const Space v938_5 = subtract(constant_0,v938_4);
        Space v938_8;
        if (!v938_5.empty()) {
          const Path v939_6 = concat_path(v937_6,v937_7_head);
          const Space v939_7 = routine_134(c, v939_6, p1, v937_7_tail);
          v938_8 = compose(v938_5,v939_7);
        }
        const Space v938_9 = intersect(constant_14,v938_2);
        const Space v938_10 = (has_head(v938_9) ? constant_15 : Space{});
        Space v938_12;
        if (!v938_10.empty()) {
          const Path v940_6 = concat_path(v937_6,v937_7_head);
          const Space v940_11 = routine_135(c, v940_6, p1, v937_7_tail);
          v938_12 = compose(v938_10,v940_11);
        }
        const Space v938_13 = unite(v938_8,v938_12);
        v937_7_result = unite(v937_7_result,v938_13);
      }
      const Space v937_7 = std::move(v937_7_result);
      v936_8 = compose(v936_5,v937_7);
    }
    const Space v936_9 = intersect(constant_14,v936_2);
    const Space v936_10 = (has_head(v936_9) ? constant_15 : Space{});
    Space v936_12;
    if (!v936_10.empty()) {
      const Path v941_6 = concat_path(p0,v935_12_head);
      Space v941_11_result;
      for (int v941_11_label = 1; v941_11_label <= 2; ++v941_11_label) {
        const Space v941_11_tail = child(v935_12_tail,v941_11_label);
        if (v941_11_tail.empty()) continue;
        const Path v941_11_head{v941_11_label};
        const Space v942_2 = singleton(v941_11_head);
        const Space v942_3 = intersect(constant_14,v942_2);
        const Space v942_4 = (has_head(v942_3) ? constant_15 : Space{});
        const Space v942_5 = subtract(constant_0,v942_4);
        Space v942_8;
        if (!v942_5.empty()) {
          const Path v943_6 = concat_path(v941_6,v941_11_head);
          const Space v943_7 = routine_134(c, v943_6, p1, v941_11_tail);
          v942_8 = compose(v942_5,v943_7);
        }
        const Space v942_9 = intersect(constant_14,v942_2);
        const Space v942_10 = (has_head(v942_9) ? constant_15 : Space{});
        Space v942_12;
        if (!v942_10.empty()) {
          const Path v944_6 = concat_path(v941_6,v941_11_head);
          const Space v944_11 = routine_65(c, v944_6, p1, v941_11_tail);
          v942_12 = compose(v942_10,v944_11);
        }
        const Space v942_13 = unite(v942_8,v942_12);
        v941_11_result = unite(v941_11_result,v942_13);
      }
      const Space v941_11 = std::move(v941_11_result);
      v936_12 = compose(v936_10,v941_11);
    }
    const Space v936_13 = unite(v936_8,v936_12);
    v935_12_result = unite(v935_12_result,v936_13);
  }
  const Space v935_12 = std::move(v935_12_result);
  return v935_12;
}

static Space routine_105(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v945_9_result;
  for (int v945_9_label = 1; v945_9_label <= 2; ++v945_9_label) {
    const Space v945_9_tail = child(s0,v945_9_label);
    if (v945_9_tail.empty()) continue;
    const Path v945_9_head{v945_9_label};
    const Space v946_2 = singleton(v945_9_head);
    const Space v946_3 = intersect(constant_14,v946_2);
    const Space v946_4 = (has_head(v946_3) ? constant_15 : Space{});
    const Space v946_5 = subtract(constant_0,v946_4);
    Space v946_8;
    if (!v946_5.empty()) {
      const Path v947_6 = concat_path(p0,v945_9_head);
      Space v947_7_result;
      for (int v947_7_label = 1; v947_7_label <= 2; ++v947_7_label) {
        const Space v947_7_tail = child(v945_9_tail,v947_7_label);
        if (v947_7_tail.empty()) continue;
        const Path v947_7_head{v947_7_label};
        const Space v948_2 = singleton(v947_7_head);
        const Space v948_3 = intersect(constant_14,v948_2);
        const Space v948_4 = (has_head(v948_3) ? constant_15 : Space{});
        const Space v948_5 = subtract(constant_0,v948_4);
        Space v948_8;
        if (!v948_5.empty()) {
          const Path v949_6 = concat_path(v947_6,v947_7_head);
          const Space v949_7 = routine_134(c, v949_6, p1, v947_7_tail);
          v948_8 = compose(v948_5,v949_7);
        }
        const Space v948_9 = intersect(constant_14,v948_2);
        const Space v948_10 = (has_head(v948_9) ? constant_15 : Space{});
        Space v948_12;
        if (!v948_10.empty()) {
          const Path v950_6 = concat_path(v947_6,v947_7_head);
          const Space v950_11 = routine_135(c, v950_6, p1, v947_7_tail);
          v948_12 = compose(v948_10,v950_11);
        }
        const Space v948_13 = unite(v948_8,v948_12);
        v947_7_result = unite(v947_7_result,v948_13);
      }
      const Space v947_7 = std::move(v947_7_result);
      v946_8 = compose(v946_5,v947_7);
    }
    const Space v946_9 = intersect(constant_14,v946_2);
    const Space v946_10 = (has_head(v946_9) ? constant_15 : Space{});
    const Space v946_11 = compose(v946_10,v945_9_tail);
    const Path v951_6 = concat_path(p0,v945_9_head);
    const Space v946_12 = wrap(v946_11,v951_6);
    const Space v946_13 = wrap(v946_12,p1);
    const Space v946_14 = unite(v946_8,v946_13);
    v945_9_result = unite(v945_9_result,v946_14);
  }
  const Space v945_9 = std::move(v945_9_result);
  return v945_9;
}

static Space routine_106(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v952_12_result;
  for (int v952_12_label = 1; v952_12_label <= 2; ++v952_12_label) {
    const Space v952_12_tail = child(s0,v952_12_label);
    if (v952_12_tail.empty()) continue;
    const Path v952_12_head{v952_12_label};
    const Space v953_2 = singleton(v952_12_head);
    const Space v953_3 = intersect(constant_14,v953_2);
    const Space v953_4 = (has_head(v953_3) ? constant_15 : Space{});
    const Space v953_5 = subtract(constant_0,v953_4);
    Space v953_8;
    if (!v953_5.empty()) {
      const Path v954_6 = concat_path(p0,v952_12_head);
      Space v954_7_result;
      for (int v954_7_label = 1; v954_7_label <= 2; ++v954_7_label) {
        const Space v954_7_tail = child(v952_12_tail,v954_7_label);
        if (v954_7_tail.empty()) continue;
        const Path v954_7_head{v954_7_label};
        const Space v955_2 = singleton(v954_7_head);
        const Space v955_3 = intersect(constant_14,v955_2);
        const Space v955_4 = (has_head(v955_3) ? constant_15 : Space{});
        const Space v955_5 = subtract(constant_0,v955_4);
        Space v955_8;
        if (!v955_5.empty()) {
          const Path v956_6 = concat_path(v954_6,v954_7_head);
          const Space v956_7 = routine_136(c, v956_6, p1, v954_7_tail);
          v955_8 = compose(v955_5,v956_7);
        }
        const Space v955_9 = intersect(constant_14,v955_2);
        const Space v955_10 = (has_head(v955_9) ? constant_15 : Space{});
        Space v955_12;
        if (!v955_10.empty()) {
          const Path v957_6 = concat_path(v954_6,v954_7_head);
          const Space v957_11 = routine_137(c, v957_6, p1, v954_7_tail);
          v955_12 = compose(v955_10,v957_11);
        }
        const Space v955_13 = unite(v955_8,v955_12);
        v954_7_result = unite(v954_7_result,v955_13);
      }
      const Space v954_7 = std::move(v954_7_result);
      v953_8 = compose(v953_5,v954_7);
    }
    const Space v953_9 = intersect(constant_14,v953_2);
    const Space v953_10 = (has_head(v953_9) ? constant_15 : Space{});
    Space v953_12;
    if (!v953_10.empty()) {
      const Path v958_6 = concat_path(p0,v952_12_head);
      Space v958_11_result;
      for (int v958_11_label = 1; v958_11_label <= 2; ++v958_11_label) {
        const Space v958_11_tail = child(v952_12_tail,v958_11_label);
        if (v958_11_tail.empty()) continue;
        const Path v958_11_head{v958_11_label};
        const Space v959_2 = singleton(v958_11_head);
        const Space v959_3 = intersect(constant_14,v959_2);
        const Space v959_4 = (has_head(v959_3) ? constant_15 : Space{});
        const Space v959_5 = subtract(constant_0,v959_4);
        Space v959_8;
        if (!v959_5.empty()) {
          const Path v960_6 = concat_path(v958_6,v958_11_head);
          const Space v960_7 = routine_136(c, v960_6, p1, v958_11_tail);
          v959_8 = compose(v959_5,v960_7);
        }
        const Space v959_9 = intersect(constant_14,v959_2);
        const Space v959_10 = (has_head(v959_9) ? constant_15 : Space{});
        Space v959_12;
        if (!v959_10.empty()) {
          const Path v961_6 = concat_path(v958_6,v958_11_head);
          const Space v961_11 = routine_33(c, v961_6, p1, v958_11_tail);
          v959_12 = compose(v959_10,v961_11);
        }
        const Space v959_13 = unite(v959_8,v959_12);
        v958_11_result = unite(v958_11_result,v959_13);
      }
      const Space v958_11 = std::move(v958_11_result);
      v953_12 = compose(v953_10,v958_11);
    }
    const Space v953_13 = unite(v953_8,v953_12);
    v952_12_result = unite(v952_12_result,v953_13);
  }
  const Space v952_12 = std::move(v952_12_result);
  return v952_12;
}

static Space routine_107(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v962_9_result;
  for (int v962_9_label = 1; v962_9_label <= 2; ++v962_9_label) {
    const Space v962_9_tail = child(s0,v962_9_label);
    if (v962_9_tail.empty()) continue;
    const Path v962_9_head{v962_9_label};
    const Space v963_2 = singleton(v962_9_head);
    const Space v963_3 = intersect(constant_14,v963_2);
    const Space v963_4 = (has_head(v963_3) ? constant_15 : Space{});
    const Space v963_5 = subtract(constant_0,v963_4);
    Space v963_8;
    if (!v963_5.empty()) {
      const Path v964_6 = concat_path(p0,v962_9_head);
      Space v964_7_result;
      for (int v964_7_label = 1; v964_7_label <= 2; ++v964_7_label) {
        const Space v964_7_tail = child(v962_9_tail,v964_7_label);
        if (v964_7_tail.empty()) continue;
        const Path v964_7_head{v964_7_label};
        const Space v965_2 = singleton(v964_7_head);
        const Space v965_3 = intersect(constant_14,v965_2);
        const Space v965_4 = (has_head(v965_3) ? constant_15 : Space{});
        const Space v965_5 = subtract(constant_0,v965_4);
        Space v965_8;
        if (!v965_5.empty()) {
          const Path v966_6 = concat_path(v964_6,v964_7_head);
          const Space v966_7 = routine_136(c, v966_6, p1, v964_7_tail);
          v965_8 = compose(v965_5,v966_7);
        }
        const Space v965_9 = intersect(constant_14,v965_2);
        const Space v965_10 = (has_head(v965_9) ? constant_15 : Space{});
        Space v965_12;
        if (!v965_10.empty()) {
          const Path v967_6 = concat_path(v964_6,v964_7_head);
          const Space v967_11 = routine_137(c, v967_6, p1, v964_7_tail);
          v965_12 = compose(v965_10,v967_11);
        }
        const Space v965_13 = unite(v965_8,v965_12);
        v964_7_result = unite(v964_7_result,v965_13);
      }
      const Space v964_7 = std::move(v964_7_result);
      v963_8 = compose(v963_5,v964_7);
    }
    const Space v963_9 = intersect(constant_14,v963_2);
    const Space v963_10 = (has_head(v963_9) ? constant_15 : Space{});
    const Space v963_11 = compose(v963_10,v962_9_tail);
    const Path v968_6 = concat_path(p0,v962_9_head);
    const Space v963_12 = wrap(v963_11,v968_6);
    const Space v963_13 = wrap(v963_12,p1);
    const Space v963_14 = unite(v963_8,v963_13);
    v962_9_result = unite(v962_9_result,v963_14);
  }
  const Space v962_9 = std::move(v962_9_result);
  return v962_9;
}

static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v969_7_result;
  for (int v969_7_label = 1; v969_7_label <= 2; ++v969_7_label) {
    const Space v969_7_tail = child(s0,v969_7_label);
    if (v969_7_tail.empty()) continue;
    const Path v969_7_head{v969_7_label};
    const Space v970_2 = singleton(v969_7_head);
    const Space v970_3 = intersect(constant_14,v970_2);
    const Space v970_4 = (has_head(v970_3) ? constant_15 : Space{});
    const Space v970_5 = subtract(constant_0,v970_4);
    Space v970_6_result;
    for (int v970_6_label = 1; v970_6_label <= 2; ++v970_6_label) {
      const Space v970_6_tail = child(v969_7_tail,v970_6_label);
      if (v970_6_tail.empty()) continue;
      const Path v970_6_head{v970_6_label};
      const Space v971_2 = Space{};
      v970_6_result = unite(v970_6_result,v971_2);
    }
    const Space v970_6 = std::move(v970_6_result);
    const Space v970_7 = compose(v970_5,v970_6);
    const Space v970_8 = intersect(constant_14,v970_2);
    const Space v970_9 = (has_head(v970_8) ? constant_15 : Space{});
    Space v970_12;
    if (!v970_9.empty()) {
      const Path v972_10 = concat_path(p0,v969_7_head);
      Space v972_11_result;
      for (int v972_11_label = 1; v972_11_label <= 2; ++v972_11_label) {
        const Space v972_11_tail = child(v969_7_tail,v972_11_label);
        if (v972_11_tail.empty()) continue;
        const Path v972_11_head{v972_11_label};
        const Space v973_2 = singleton(v972_11_head);
        const Space v973_3 = intersect(constant_14,v973_2);
        const Space v973_4 = (has_head(v973_3) ? constant_15 : Space{});
        Space v973_7;
        if (!v973_4.empty()) {
          const Path v974_5 = concat_path(v972_10,v972_11_head);
          const Space v974_6 = routine_33(c, v974_5, p1, v972_11_tail);
          v973_7 = compose(v973_4,v974_6);
        }
        v972_11_result = unite(v972_11_result,v973_7);
      }
      const Space v972_11 = std::move(v972_11_result);
      v970_12 = compose(v970_9,v972_11);
    }
    const Space v970_13 = unite(v970_7,v970_12);
    v969_7_result = unite(v969_7_result,v970_13);
  }
  const Space v969_7 = std::move(v969_7_result);
  return v969_7;
}

static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v975_6_result;
  for (int v975_6_label = 1; v975_6_label <= 2; ++v975_6_label) {
    const Space v975_6_tail = child(s0,v975_6_label);
    if (v975_6_tail.empty()) continue;
    const Path v975_6_head{v975_6_label};
    const Space v976_2 = singleton(v975_6_head);
    const Space v976_3 = intersect(constant_14,v976_2);
    const Space v976_4 = (has_head(v976_3) ? constant_15 : Space{});
    const Space v976_5 = subtract(constant_0,v976_4);
    Space v976_6_result;
    for (int v976_6_label = 1; v976_6_label <= 2; ++v976_6_label) {
      const Space v976_6_tail = child(v975_6_tail,v976_6_label);
      if (v976_6_tail.empty()) continue;
      const Path v976_6_head{v976_6_label};
      const Space v977_2 = Space{};
      v976_6_result = unite(v976_6_result,v977_2);
    }
    const Space v976_6 = std::move(v976_6_result);
    const Space v976_7 = compose(v976_5,v976_6);
    const Space v976_8 = intersect(constant_14,v976_2);
    const Space v976_9 = (has_head(v976_8) ? constant_15 : Space{});
    const Space v976_10 = compose(v976_9,v975_6_tail);
    const Path v976_11 = concat_path(p0,v975_6_head);
    const Space v976_12 = wrap(v976_10,v976_11);
    const Space v976_13 = wrap(v976_12,p1);
    const Space v976_14 = unite(v976_7,v976_13);
    v975_6_result = unite(v975_6_result,v976_14);
  }
  const Space v975_6 = std::move(v975_6_result);
  return v975_6;
}

static Space routine_110(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v978_13_result;
  for (int v978_13_label = 1; v978_13_label <= 2; ++v978_13_label) {
    const Space v978_13_tail = child(s0,v978_13_label);
    if (v978_13_tail.empty()) continue;
    const Path v978_13_head{v978_13_label};
    const Space v979_2 = singleton(v978_13_head);
    const Space v979_3 = intersect(constant_14,v979_2);
    const Space v979_4 = (has_head(v979_3) ? constant_15 : Space{});
    const Space v979_5 = subtract(constant_0,v979_4);
    Space v979_8;
    if (!v979_5.empty()) {
      const Path v980_6 = concat_path(p0,v978_13_head);
      Space v980_7_result;
      for (int v980_7_label = 1; v980_7_label <= 2; ++v980_7_label) {
        const Space v980_7_tail = child(v978_13_tail,v980_7_label);
        if (v980_7_tail.empty()) continue;
        const Path v980_7_head{v980_7_label};
        const Space v981_2 = singleton(v980_7_head);
        const Space v981_3 = intersect(constant_14,v981_2);
        const Space v981_4 = (has_head(v981_3) ? constant_15 : Space{});
        const Space v981_5 = subtract(constant_0,v981_4);
        Space v981_8;
        if (!v981_5.empty()) {
          const Path v982_6 = concat_path(v980_6,v980_7_head);
          const Space v982_7 = routine_138(c, v982_6, p1, v980_7_tail, s1);
          v981_8 = compose(v981_5,v982_7);
        }
        const Space v981_9 = intersect(constant_14,v981_2);
        const Space v981_10 = (has_head(v981_9) ? constant_15 : Space{});
        Space v981_12;
        if (!v981_10.empty()) {
          const Path v983_6 = concat_path(v980_6,v980_7_head);
          const Space v983_11 = routine_139(c, v983_6, p1, v980_7_tail, s1);
          v981_12 = compose(v981_10,v983_11);
        }
        const Space v981_13 = unite(v981_8,v981_12);
        v980_7_result = unite(v980_7_result,v981_13);
      }
      const Space v980_7 = std::move(v980_7_result);
      v979_8 = compose(v979_5,v980_7);
    }
    const Space v979_9 = intersect(constant_14,v979_2);
    const Space v979_10 = (has_head(v979_9) ? constant_15 : Space{});
    Space v979_12;
    if (!v979_10.empty()) {
      const Path v984_6 = concat_path(p0,v978_13_head);
      Space v984_11_result;
      for (int v984_11_label = 1; v984_11_label <= 2; ++v984_11_label) {
        const Space v984_11_tail = child(v978_13_tail,v984_11_label);
        if (v984_11_tail.empty()) continue;
        const Path v984_11_head{v984_11_label};
        const Space v985_2 = singleton(v984_11_head);
        const Space v985_3 = intersect(constant_14,v985_2);
        const Space v985_4 = (has_head(v985_3) ? constant_15 : Space{});
        const Space v985_5 = subtract(constant_0,v985_4);
        Space v985_8;
        if (!v985_5.empty()) {
          const Path v986_6 = concat_path(v984_6,v984_11_head);
          const Space v986_7 = routine_138(c, v986_6, p1, v984_11_tail, s1);
          v985_8 = compose(v985_5,v986_7);
        }
        const Space v985_9 = intersect(constant_14,v985_2);
        const Space v985_10 = (has_head(v985_9) ? constant_15 : Space{});
        Space v985_12;
        if (!v985_10.empty()) {
          const Path v987_6 = concat_path(v984_6,v984_11_head);
          const Space v987_11 = routine_40(c, v987_6, p1, v984_11_tail, s1);
          v985_12 = compose(v985_10,v987_11);
        }
        const Space v985_13 = unite(v985_8,v985_12);
        v984_11_result = unite(v984_11_result,v985_13);
      }
      const Space v984_11 = std::move(v984_11_result);
      v979_12 = compose(v979_10,v984_11);
    }
    const Space v979_13 = unite(v979_8,v979_12);
    v978_13_result = unite(v978_13_result,v979_13);
  }
  const Space v978_13 = std::move(v978_13_result);
  return v978_13;
}

static Space routine_111(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v988_8 = unwrap(s1,constant_9);
  const Space v988_10 = unwrap(v988_8,constant_10);
  const Space v988_11 = unwrap(v988_10,p0);
  Space v988_18_result;
  for (int v988_18_label = 1; v988_18_label <= 2; ++v988_18_label) {
    const Space v988_18_tail = child(s0,v988_18_label);
    if (v988_18_tail.empty()) continue;
    const Path v988_18_head{v988_18_label};
    const Space v989_2 = singleton(v988_18_head);
    const Space v989_3 = intersect(constant_14,v989_2);
    const Space v989_4 = (has_head(v989_3) ? constant_15 : Space{});
    const Space v989_5 = subtract(constant_0,v989_4);
    Space v989_8;
    if (!v989_5.empty()) {
      const Path v990_6 = concat_path(p0,v988_18_head);
      Space v990_7_result;
      for (int v990_7_label = 1; v990_7_label <= 2; ++v990_7_label) {
        const Space v990_7_tail = child(v988_18_tail,v990_7_label);
        if (v990_7_tail.empty()) continue;
        const Path v990_7_head{v990_7_label};
        const Space v991_2 = singleton(v990_7_head);
        const Space v991_3 = intersect(constant_14,v991_2);
        const Space v991_4 = (has_head(v991_3) ? constant_15 : Space{});
        const Space v991_5 = subtract(constant_0,v991_4);
        Space v991_8;
        if (!v991_5.empty()) {
          const Path v992_6 = concat_path(v990_6,v990_7_head);
          const Space v992_7 = routine_138(c, v992_6, p1, v990_7_tail, s1);
          v991_8 = compose(v991_5,v992_7);
        }
        const Space v991_9 = intersect(constant_14,v991_2);
        const Space v991_10 = (has_head(v991_9) ? constant_15 : Space{});
        Space v991_12;
        if (!v991_10.empty()) {
          const Path v993_6 = concat_path(v990_6,v990_7_head);
          const Space v993_11 = routine_139(c, v993_6, p1, v990_7_tail, s1);
          v991_12 = compose(v991_10,v993_11);
        }
        const Space v991_13 = unite(v991_8,v991_12);
        v990_7_result = unite(v990_7_result,v991_13);
      }
      const Space v990_7 = std::move(v990_7_result);
      v989_8 = compose(v989_5,v990_7);
    }
    const Space v989_9 = intersect(constant_14,v989_2);
    const Space v989_10 = (has_head(v989_9) ? constant_15 : Space{});
    Space v989_13;
    if (!v989_10.empty()) {
      const Space v994_11 = unwrap(v988_11,v988_18_head);
      Space v994_12_result;
      for (int v994_12_label = 1; v994_12_label <= 2; ++v994_12_label) {
        const Space v994_12_tail = child(v994_11,v994_12_label);
        if (v994_12_tail.empty()) continue;
        const Path v994_12_head{v994_12_label};
        const Space v995_2 = singleton(v994_12_head);
        const Space v995_3 = intersect(constant_14,v995_2);
        const Space v995_4 = (has_head(v995_3) ? constant_15 : Space{});
        const Space v995_5 = subtract(constant_0,v995_4);
        Space v995_7;
        if (!v995_5.empty()) {
          const Space v996_6 = routine_76(c, v994_12_head, p1, v994_12_tail);
          v995_7 = compose(v995_5,v996_6);
        }
        const Space v995_8 = intersect(constant_14,v995_2);
        const Space v995_9 = (has_head(v995_8) ? constant_15 : Space{});
        Space v995_11;
        if (!v995_9.empty()) {
          const Space v997_10 = routine_77(c, v994_12_head, p1, v994_12_tail);
          v995_11 = compose(v995_9,v997_10);
        }
        const Space v995_12 = unite(v995_7,v995_11);
        v994_12_result = unite(v994_12_result,v995_12);
      }
      const Space v994_12 = std::move(v994_12_result);
      v989_13 = compose(v989_10,v994_12);
    }
    const Space v989_14 = unite(v989_8,v989_13);
    v988_18_result = unite(v988_18_result,v989_14);
  }
  const Space v988_18 = std::move(v988_18_result);
  return v988_18;
}

static Space routine_112(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v998_12_result;
  for (int v998_12_label = 1; v998_12_label <= 2; ++v998_12_label) {
    const Space v998_12_tail = child(s0,v998_12_label);
    if (v998_12_tail.empty()) continue;
    const Path v998_12_head{v998_12_label};
    const Space v999_2 = singleton(v998_12_head);
    const Space v999_3 = intersect(constant_14,v999_2);
    const Space v999_4 = (has_head(v999_3) ? constant_15 : Space{});
    const Space v999_5 = subtract(constant_0,v999_4);
    Space v999_8;
    if (!v999_5.empty()) {
      const Path v1000_6 = concat_path(p0,v998_12_head);
      Space v1000_7_result;
      for (int v1000_7_label = 1; v1000_7_label <= 2; ++v1000_7_label) {
        const Space v1000_7_tail = child(v998_12_tail,v1000_7_label);
        if (v1000_7_tail.empty()) continue;
        const Path v1000_7_head{v1000_7_label};
        const Space v1001_2 = singleton(v1000_7_head);
        const Space v1001_3 = intersect(constant_14,v1001_2);
        const Space v1001_4 = (has_head(v1001_3) ? constant_15 : Space{});
        const Space v1001_5 = subtract(constant_0,v1001_4);
        Space v1001_8;
        if (!v1001_5.empty()) {
          const Path v1002_6 = concat_path(v1000_6,v1000_7_head);
          const Space v1002_7 = routine_140(c, v1002_6, p1, v1000_7_tail);
          v1001_8 = compose(v1001_5,v1002_7);
        }
        const Space v1001_9 = intersect(constant_14,v1001_2);
        const Space v1001_10 = (has_head(v1001_9) ? constant_15 : Space{});
        Space v1001_12;
        if (!v1001_10.empty()) {
          const Path v1003_6 = concat_path(v1000_6,v1000_7_head);
          const Space v1003_11 = routine_141(c, v1003_6, p1, v1000_7_tail);
          v1001_12 = compose(v1001_10,v1003_11);
        }
        const Space v1001_13 = unite(v1001_8,v1001_12);
        v1000_7_result = unite(v1000_7_result,v1001_13);
      }
      const Space v1000_7 = std::move(v1000_7_result);
      v999_8 = compose(v999_5,v1000_7);
    }
    const Space v999_9 = intersect(constant_14,v999_2);
    const Space v999_10 = (has_head(v999_9) ? constant_15 : Space{});
    Space v999_12;
    if (!v999_10.empty()) {
      const Path v1004_6 = concat_path(p0,v998_12_head);
      Space v1004_11_result;
      for (int v1004_11_label = 1; v1004_11_label <= 2; ++v1004_11_label) {
        const Space v1004_11_tail = child(v998_12_tail,v1004_11_label);
        if (v1004_11_tail.empty()) continue;
        const Path v1004_11_head{v1004_11_label};
        const Space v1005_2 = singleton(v1004_11_head);
        const Space v1005_3 = intersect(constant_14,v1005_2);
        const Space v1005_4 = (has_head(v1005_3) ? constant_15 : Space{});
        const Space v1005_5 = subtract(constant_0,v1005_4);
        Space v1005_8;
        if (!v1005_5.empty()) {
          const Path v1006_6 = concat_path(v1004_6,v1004_11_head);
          const Space v1006_7 = routine_140(c, v1006_6, p1, v1004_11_tail);
          v1005_8 = compose(v1005_5,v1006_7);
        }
        const Space v1005_9 = intersect(constant_14,v1005_2);
        const Space v1005_10 = (has_head(v1005_9) ? constant_15 : Space{});
        Space v1005_12;
        if (!v1005_10.empty()) {
          const Path v1007_6 = concat_path(v1004_6,v1004_11_head);
          const Space v1007_11 = routine_82(c, v1007_6, p1, v1004_11_tail);
          v1005_12 = compose(v1005_10,v1007_11);
        }
        const Space v1005_13 = unite(v1005_8,v1005_12);
        v1004_11_result = unite(v1004_11_result,v1005_13);
      }
      const Space v1004_11 = std::move(v1004_11_result);
      v999_12 = compose(v999_10,v1004_11);
    }
    const Space v999_13 = unite(v999_8,v999_12);
    v998_12_result = unite(v998_12_result,v999_13);
  }
  const Space v998_12 = std::move(v998_12_result);
  return v998_12;
}

static Space routine_113(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1008_9_result;
  for (int v1008_9_label = 1; v1008_9_label <= 2; ++v1008_9_label) {
    const Space v1008_9_tail = child(s0,v1008_9_label);
    if (v1008_9_tail.empty()) continue;
    const Path v1008_9_head{v1008_9_label};
    const Space v1009_2 = singleton(v1008_9_head);
    const Space v1009_3 = intersect(constant_14,v1009_2);
    const Space v1009_4 = (has_head(v1009_3) ? constant_15 : Space{});
    const Space v1009_5 = subtract(constant_0,v1009_4);
    Space v1009_8;
    if (!v1009_5.empty()) {
      const Path v1010_6 = concat_path(p0,v1008_9_head);
      Space v1010_7_result;
      for (int v1010_7_label = 1; v1010_7_label <= 2; ++v1010_7_label) {
        const Space v1010_7_tail = child(v1008_9_tail,v1010_7_label);
        if (v1010_7_tail.empty()) continue;
        const Path v1010_7_head{v1010_7_label};
        const Space v1011_2 = singleton(v1010_7_head);
        const Space v1011_3 = intersect(constant_14,v1011_2);
        const Space v1011_4 = (has_head(v1011_3) ? constant_15 : Space{});
        const Space v1011_5 = subtract(constant_0,v1011_4);
        Space v1011_8;
        if (!v1011_5.empty()) {
          const Path v1012_6 = concat_path(v1010_6,v1010_7_head);
          const Space v1012_7 = routine_140(c, v1012_6, p1, v1010_7_tail);
          v1011_8 = compose(v1011_5,v1012_7);
        }
        const Space v1011_9 = intersect(constant_14,v1011_2);
        const Space v1011_10 = (has_head(v1011_9) ? constant_15 : Space{});
        Space v1011_12;
        if (!v1011_10.empty()) {
          const Path v1013_6 = concat_path(v1010_6,v1010_7_head);
          const Space v1013_11 = routine_141(c, v1013_6, p1, v1010_7_tail);
          v1011_12 = compose(v1011_10,v1013_11);
        }
        const Space v1011_13 = unite(v1011_8,v1011_12);
        v1010_7_result = unite(v1010_7_result,v1011_13);
      }
      const Space v1010_7 = std::move(v1010_7_result);
      v1009_8 = compose(v1009_5,v1010_7);
    }
    const Space v1009_9 = intersect(constant_14,v1009_2);
    const Space v1009_10 = (has_head(v1009_9) ? constant_15 : Space{});
    const Space v1009_11 = compose(v1009_10,v1008_9_tail);
    const Path v1014_6 = concat_path(p0,v1008_9_head);
    const Space v1009_12 = wrap(v1009_11,v1014_6);
    const Space v1009_13 = wrap(v1009_12,p1);
    const Space v1009_14 = unite(v1009_8,v1009_13);
    v1008_9_result = unite(v1008_9_result,v1009_14);
  }
  const Space v1008_9 = std::move(v1008_9_result);
  return v1008_9;
}

static Space routine_114(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1015_8_result;
  for (int v1015_8_label = 1; v1015_8_label <= 2; ++v1015_8_label) {
    const Space v1015_8_tail = child(s0,v1015_8_label);
    if (v1015_8_tail.empty()) continue;
    const Path v1015_8_head{v1015_8_label};
    const Space v1016_2 = singleton(v1015_8_head);
    const Space v1016_3 = intersect(constant_14,v1016_2);
    const Space v1016_4 = (has_head(v1016_3) ? constant_15 : Space{});
    const Space v1016_5 = subtract(constant_0,v1016_4);
    Space v1016_6_result;
    for (int v1016_6_label = 1; v1016_6_label <= 2; ++v1016_6_label) {
      const Space v1016_6_tail = child(v1015_8_tail,v1016_6_label);
      if (v1016_6_tail.empty()) continue;
      const Path v1016_6_head{v1016_6_label};
      const Space v1017_2 = Space{};
      v1016_6_result = unite(v1016_6_result,v1017_2);
    }
    const Space v1016_6 = std::move(v1016_6_result);
    const Space v1016_7 = compose(v1016_5,v1016_6);
    const Space v1016_8 = intersect(constant_14,v1016_2);
    const Space v1016_9 = (has_head(v1016_8) ? constant_15 : Space{});
    Space v1016_12;
    if (!v1016_9.empty()) {
      const Path v1018_10 = concat_path(p0,v1015_8_head);
      Space v1018_11_result;
      for (int v1018_11_label = 1; v1018_11_label <= 2; ++v1018_11_label) {
        const Space v1018_11_tail = child(v1015_8_tail,v1018_11_label);
        if (v1018_11_tail.empty()) continue;
        const Path v1018_11_head{v1018_11_label};
        const Space v1019_2 = singleton(v1018_11_head);
        const Space v1019_3 = intersect(constant_14,v1019_2);
        const Space v1019_4 = (has_head(v1019_3) ? constant_15 : Space{});
        Space v1019_7;
        if (!v1019_4.empty()) {
          const Path v1020_5 = concat_path(v1018_10,v1018_11_head);
          const Space v1020_6 = routine_40(c, v1020_5, p1, v1018_11_tail, s1);
          v1019_7 = compose(v1019_4,v1020_6);
        }
        v1018_11_result = unite(v1018_11_result,v1019_7);
      }
      const Space v1018_11 = std::move(v1018_11_result);
      v1016_12 = compose(v1016_9,v1018_11);
    }
    const Space v1016_13 = unite(v1016_7,v1016_12);
    v1015_8_result = unite(v1015_8_result,v1016_13);
  }
  const Space v1015_8 = std::move(v1015_8_result);
  return v1015_8;
}

static Space routine_115(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1021_8 = unwrap(s1,constant_9);
  const Space v1021_10 = unwrap(v1021_8,constant_10);
  const Space v1021_11 = unwrap(v1021_10,p0);
  Space v1021_15_result;
  for (int v1021_15_label = 1; v1021_15_label <= 2; ++v1021_15_label) {
    const Space v1021_15_tail = child(s0,v1021_15_label);
    if (v1021_15_tail.empty()) continue;
    const Path v1021_15_head{v1021_15_label};
    const Space v1022_2 = singleton(v1021_15_head);
    const Space v1022_3 = intersect(constant_14,v1022_2);
    const Space v1022_4 = (has_head(v1022_3) ? constant_15 : Space{});
    const Space v1022_5 = subtract(constant_0,v1022_4);
    Space v1022_6_result;
    for (int v1022_6_label = 1; v1022_6_label <= 2; ++v1022_6_label) {
      const Space v1022_6_tail = child(v1021_15_tail,v1022_6_label);
      if (v1022_6_tail.empty()) continue;
      const Path v1022_6_head{v1022_6_label};
      const Space v1023_2 = Space{};
      v1022_6_result = unite(v1022_6_result,v1023_2);
    }
    const Space v1022_6 = std::move(v1022_6_result);
    const Space v1022_7 = compose(v1022_5,v1022_6);
    const Space v1022_8 = intersect(constant_14,v1022_2);
    const Space v1022_9 = (has_head(v1022_8) ? constant_15 : Space{});
    Space v1022_12;
    if (!v1022_9.empty()) {
      const Space v1024_10 = unwrap(v1021_11,v1021_15_head);
      Space v1024_11_result;
      for (int v1024_11_label = 1; v1024_11_label <= 2; ++v1024_11_label) {
        const Space v1024_11_tail = child(v1024_10,v1024_11_label);
        if (v1024_11_tail.empty()) continue;
        const Path v1024_11_head{v1024_11_label};
        const Space v1025_2 = singleton(v1024_11_head);
        const Space v1025_3 = intersect(constant_14,v1025_2);
        const Space v1025_4 = (has_head(v1025_3) ? constant_15 : Space{});
        const Space v1025_5 = subtract(constant_0,v1025_4);
        Space v1025_7;
        if (!v1025_5.empty()) {
          const Space v1026_6 = routine_76(c, v1024_11_head, p1, v1024_11_tail);
          v1025_7 = compose(v1025_5,v1026_6);
        }
        const Space v1025_8 = intersect(constant_14,v1025_2);
        const Space v1025_9 = (has_head(v1025_8) ? constant_15 : Space{});
        Space v1025_11;
        if (!v1025_9.empty()) {
          const Space v1027_10 = routine_77(c, v1024_11_head, p1, v1024_11_tail);
          v1025_11 = compose(v1025_9,v1027_10);
        }
        const Space v1025_12 = unite(v1025_7,v1025_11);
        v1024_11_result = unite(v1024_11_result,v1025_12);
      }
      const Space v1024_11 = std::move(v1024_11_result);
      v1022_12 = compose(v1022_9,v1024_11);
    }
    const Space v1022_13 = unite(v1022_7,v1022_12);
    v1021_15_result = unite(v1021_15_result,v1022_13);
  }
  const Space v1021_15 = std::move(v1021_15_result);
  return v1021_15;
}

static Space routine_116(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1028_12_result;
  for (int v1028_12_label = 1; v1028_12_label <= 2; ++v1028_12_label) {
    const Space v1028_12_tail = child(s0,v1028_12_label);
    if (v1028_12_tail.empty()) continue;
    const Path v1028_12_head{v1028_12_label};
    const Space v1029_2 = singleton(v1028_12_head);
    const Space v1029_3 = intersect(constant_14,v1029_2);
    const Space v1029_4 = (has_head(v1029_3) ? constant_15 : Space{});
    const Space v1029_5 = subtract(constant_0,v1029_4);
    Space v1029_8;
    if (!v1029_5.empty()) {
      const Path v1030_6 = concat_path(p0,v1028_12_head);
      Space v1030_7_result;
      for (int v1030_7_label = 1; v1030_7_label <= 2; ++v1030_7_label) {
        const Space v1030_7_tail = child(v1028_12_tail,v1030_7_label);
        if (v1030_7_tail.empty()) continue;
        const Path v1030_7_head{v1030_7_label};
        const Space v1031_2 = singleton(v1030_7_head);
        const Space v1031_3 = intersect(constant_14,v1031_2);
        const Space v1031_4 = (has_head(v1031_3) ? constant_15 : Space{});
        const Space v1031_5 = subtract(constant_0,v1031_4);
        Space v1031_8;
        if (!v1031_5.empty()) {
          const Path v1032_6 = concat_path(v1030_6,v1030_7_head);
          const Space v1032_7 = routine_142(c, v1032_6, p1, v1030_7_tail);
          v1031_8 = compose(v1031_5,v1032_7);
        }
        const Space v1031_9 = intersect(constant_14,v1031_2);
        const Space v1031_10 = (has_head(v1031_9) ? constant_15 : Space{});
        Space v1031_12;
        if (!v1031_10.empty()) {
          const Path v1033_6 = concat_path(v1030_6,v1030_7_head);
          const Space v1033_11 = routine_143(c, v1033_6, p1, v1030_7_tail);
          v1031_12 = compose(v1031_10,v1033_11);
        }
        const Space v1031_13 = unite(v1031_8,v1031_12);
        v1030_7_result = unite(v1030_7_result,v1031_13);
      }
      const Space v1030_7 = std::move(v1030_7_result);
      v1029_8 = compose(v1029_5,v1030_7);
    }
    const Space v1029_9 = intersect(constant_14,v1029_2);
    const Space v1029_10 = (has_head(v1029_9) ? constant_15 : Space{});
    Space v1029_12;
    if (!v1029_10.empty()) {
      const Path v1034_6 = concat_path(p0,v1028_12_head);
      Space v1034_11_result;
      for (int v1034_11_label = 1; v1034_11_label <= 2; ++v1034_11_label) {
        const Space v1034_11_tail = child(v1028_12_tail,v1034_11_label);
        if (v1034_11_tail.empty()) continue;
        const Path v1034_11_head{v1034_11_label};
        const Space v1035_2 = singleton(v1034_11_head);
        const Space v1035_3 = intersect(constant_14,v1035_2);
        const Space v1035_4 = (has_head(v1035_3) ? constant_15 : Space{});
        const Space v1035_5 = subtract(constant_0,v1035_4);
        Space v1035_8;
        if (!v1035_5.empty()) {
          const Path v1036_6 = concat_path(v1034_6,v1034_11_head);
          const Space v1036_7 = routine_142(c, v1036_6, p1, v1034_11_tail);
          v1035_8 = compose(v1035_5,v1036_7);
        }
        const Space v1035_9 = intersect(constant_14,v1035_2);
        const Space v1035_10 = (has_head(v1035_9) ? constant_15 : Space{});
        Space v1035_12;
        if (!v1035_10.empty()) {
          const Path v1037_6 = concat_path(v1034_6,v1034_11_head);
          const Space v1037_11 = routine_82(c, v1037_6, p1, v1034_11_tail);
          v1035_12 = compose(v1035_10,v1037_11);
        }
        const Space v1035_13 = unite(v1035_8,v1035_12);
        v1034_11_result = unite(v1034_11_result,v1035_13);
      }
      const Space v1034_11 = std::move(v1034_11_result);
      v1029_12 = compose(v1029_10,v1034_11);
    }
    const Space v1029_13 = unite(v1029_8,v1029_12);
    v1028_12_result = unite(v1028_12_result,v1029_13);
  }
  const Space v1028_12 = std::move(v1028_12_result);
  return v1028_12;
}

static Space routine_117(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1038_9_result;
  for (int v1038_9_label = 1; v1038_9_label <= 2; ++v1038_9_label) {
    const Space v1038_9_tail = child(s0,v1038_9_label);
    if (v1038_9_tail.empty()) continue;
    const Path v1038_9_head{v1038_9_label};
    const Space v1039_2 = singleton(v1038_9_head);
    const Space v1039_3 = intersect(constant_14,v1039_2);
    const Space v1039_4 = (has_head(v1039_3) ? constant_15 : Space{});
    const Space v1039_5 = subtract(constant_0,v1039_4);
    Space v1039_8;
    if (!v1039_5.empty()) {
      const Path v1040_6 = concat_path(p0,v1038_9_head);
      Space v1040_7_result;
      for (int v1040_7_label = 1; v1040_7_label <= 2; ++v1040_7_label) {
        const Space v1040_7_tail = child(v1038_9_tail,v1040_7_label);
        if (v1040_7_tail.empty()) continue;
        const Path v1040_7_head{v1040_7_label};
        const Space v1041_2 = singleton(v1040_7_head);
        const Space v1041_3 = intersect(constant_14,v1041_2);
        const Space v1041_4 = (has_head(v1041_3) ? constant_15 : Space{});
        const Space v1041_5 = subtract(constant_0,v1041_4);
        Space v1041_8;
        if (!v1041_5.empty()) {
          const Path v1042_6 = concat_path(v1040_6,v1040_7_head);
          const Space v1042_7 = routine_142(c, v1042_6, p1, v1040_7_tail);
          v1041_8 = compose(v1041_5,v1042_7);
        }
        const Space v1041_9 = intersect(constant_14,v1041_2);
        const Space v1041_10 = (has_head(v1041_9) ? constant_15 : Space{});
        Space v1041_12;
        if (!v1041_10.empty()) {
          const Path v1043_6 = concat_path(v1040_6,v1040_7_head);
          const Space v1043_11 = routine_143(c, v1043_6, p1, v1040_7_tail);
          v1041_12 = compose(v1041_10,v1043_11);
        }
        const Space v1041_13 = unite(v1041_8,v1041_12);
        v1040_7_result = unite(v1040_7_result,v1041_13);
      }
      const Space v1040_7 = std::move(v1040_7_result);
      v1039_8 = compose(v1039_5,v1040_7);
    }
    const Space v1039_9 = intersect(constant_14,v1039_2);
    const Space v1039_10 = (has_head(v1039_9) ? constant_15 : Space{});
    const Space v1039_11 = compose(v1039_10,v1038_9_tail);
    const Path v1044_6 = concat_path(p0,v1038_9_head);
    const Space v1039_12 = wrap(v1039_11,v1044_6);
    const Space v1039_13 = wrap(v1039_12,p1);
    const Space v1039_14 = unite(v1039_8,v1039_13);
    v1038_9_result = unite(v1038_9_result,v1039_14);
  }
  const Space v1038_9 = std::move(v1038_9_result);
  return v1038_9;
}

static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1045_13_result;
  for (int v1045_13_label = 1; v1045_13_label <= 2; ++v1045_13_label) {
    const Space v1045_13_tail = child(s0,v1045_13_label);
    if (v1045_13_tail.empty()) continue;
    const Path v1045_13_head{v1045_13_label};
    const Space v1046_2 = singleton(v1045_13_head);
    const Space v1046_3 = intersect(constant_14,v1046_2);
    const Space v1046_4 = (has_head(v1046_3) ? constant_15 : Space{});
    const Space v1046_5 = subtract(constant_0,v1046_4);
    Space v1046_8;
    if (!v1046_5.empty()) {
      const Path v1047_6 = concat_path(p0,v1045_13_head);
      Space v1047_7_result;
      for (int v1047_7_label = 1; v1047_7_label <= 2; ++v1047_7_label) {
        const Space v1047_7_tail = child(v1045_13_tail,v1047_7_label);
        if (v1047_7_tail.empty()) continue;
        const Path v1047_7_head{v1047_7_label};
        const Space v1048_2 = singleton(v1047_7_head);
        const Space v1048_3 = intersect(constant_14,v1048_2);
        const Space v1048_4 = (has_head(v1048_3) ? constant_15 : Space{});
        const Space v1048_5 = subtract(constant_0,v1048_4);
        Space v1048_8;
        if (!v1048_5.empty()) {
          const Path v1049_6 = concat_path(v1047_6,v1047_7_head);
          const Space v1049_7 = routine_144(c, v1049_6, p1, v1047_7_tail, s1);
          v1048_8 = compose(v1048_5,v1049_7);
        }
        const Space v1048_9 = intersect(constant_14,v1048_2);
        const Space v1048_10 = (has_head(v1048_9) ? constant_15 : Space{});
        Space v1048_12;
        if (!v1048_10.empty()) {
          const Path v1050_6 = concat_path(v1047_6,v1047_7_head);
          const Space v1050_11 = routine_145(c, v1050_6, p1, v1047_7_tail, s1);
          v1048_12 = compose(v1048_10,v1050_11);
        }
        const Space v1048_13 = unite(v1048_8,v1048_12);
        v1047_7_result = unite(v1047_7_result,v1048_13);
      }
      const Space v1047_7 = std::move(v1047_7_result);
      v1046_8 = compose(v1046_5,v1047_7);
    }
    const Space v1046_9 = intersect(constant_14,v1046_2);
    const Space v1046_10 = (has_head(v1046_9) ? constant_15 : Space{});
    Space v1046_12;
    if (!v1046_10.empty()) {
      const Path v1051_6 = concat_path(p0,v1045_13_head);
      Space v1051_11_result;
      for (int v1051_11_label = 1; v1051_11_label <= 2; ++v1051_11_label) {
        const Space v1051_11_tail = child(v1045_13_tail,v1051_11_label);
        if (v1051_11_tail.empty()) continue;
        const Path v1051_11_head{v1051_11_label};
        const Space v1052_2 = singleton(v1051_11_head);
        const Space v1052_3 = intersect(constant_14,v1052_2);
        const Space v1052_4 = (has_head(v1052_3) ? constant_15 : Space{});
        const Space v1052_5 = subtract(constant_0,v1052_4);
        Space v1052_8;
        if (!v1052_5.empty()) {
          const Path v1053_6 = concat_path(v1051_6,v1051_11_head);
          const Space v1053_7 = routine_144(c, v1053_6, p1, v1051_11_tail, s1);
          v1052_8 = compose(v1052_5,v1053_7);
        }
        const Space v1052_9 = intersect(constant_14,v1052_2);
        const Space v1052_10 = (has_head(v1052_9) ? constant_15 : Space{});
        Space v1052_12;
        if (!v1052_10.empty()) {
          const Path v1054_6 = concat_path(v1051_6,v1051_11_head);
          const Space v1054_11 = routine_47(c, v1054_6, p1, v1051_11_tail, s1);
          v1052_12 = compose(v1052_10,v1054_11);
        }
        const Space v1052_13 = unite(v1052_8,v1052_12);
        v1051_11_result = unite(v1051_11_result,v1052_13);
      }
      const Space v1051_11 = std::move(v1051_11_result);
      v1046_12 = compose(v1046_10,v1051_11);
    }
    const Space v1046_13 = unite(v1046_8,v1046_12);
    v1045_13_result = unite(v1045_13_result,v1046_13);
  }
  const Space v1045_13 = std::move(v1045_13_result);
  return v1045_13;
}

static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1055_8 = unwrap(s1,constant_7);
  const Space v1055_10 = unwrap(v1055_8,constant_10);
  const Space v1055_11 = unwrap(v1055_10,p0);
  Space v1055_18_result;
  for (int v1055_18_label = 1; v1055_18_label <= 2; ++v1055_18_label) {
    const Space v1055_18_tail = child(s0,v1055_18_label);
    if (v1055_18_tail.empty()) continue;
    const Path v1055_18_head{v1055_18_label};
    const Space v1056_2 = singleton(v1055_18_head);
    const Space v1056_3 = intersect(constant_14,v1056_2);
    const Space v1056_4 = (has_head(v1056_3) ? constant_15 : Space{});
    const Space v1056_5 = subtract(constant_0,v1056_4);
    Space v1056_8;
    if (!v1056_5.empty()) {
      const Path v1057_6 = concat_path(p0,v1055_18_head);
      Space v1057_7_result;
      for (int v1057_7_label = 1; v1057_7_label <= 2; ++v1057_7_label) {
        const Space v1057_7_tail = child(v1055_18_tail,v1057_7_label);
        if (v1057_7_tail.empty()) continue;
        const Path v1057_7_head{v1057_7_label};
        const Space v1058_2 = singleton(v1057_7_head);
        const Space v1058_3 = intersect(constant_14,v1058_2);
        const Space v1058_4 = (has_head(v1058_3) ? constant_15 : Space{});
        const Space v1058_5 = subtract(constant_0,v1058_4);
        Space v1058_8;
        if (!v1058_5.empty()) {
          const Path v1059_6 = concat_path(v1057_6,v1057_7_head);
          const Space v1059_7 = routine_144(c, v1059_6, p1, v1057_7_tail, s1);
          v1058_8 = compose(v1058_5,v1059_7);
        }
        const Space v1058_9 = intersect(constant_14,v1058_2);
        const Space v1058_10 = (has_head(v1058_9) ? constant_15 : Space{});
        Space v1058_12;
        if (!v1058_10.empty()) {
          const Path v1060_6 = concat_path(v1057_6,v1057_7_head);
          const Space v1060_11 = routine_145(c, v1060_6, p1, v1057_7_tail, s1);
          v1058_12 = compose(v1058_10,v1060_11);
        }
        const Space v1058_13 = unite(v1058_8,v1058_12);
        v1057_7_result = unite(v1057_7_result,v1058_13);
      }
      const Space v1057_7 = std::move(v1057_7_result);
      v1056_8 = compose(v1056_5,v1057_7);
    }
    const Space v1056_9 = intersect(constant_14,v1056_2);
    const Space v1056_10 = (has_head(v1056_9) ? constant_15 : Space{});
    Space v1056_13;
    if (!v1056_10.empty()) {
      const Space v1061_11 = unwrap(v1055_11,v1055_18_head);
      Space v1061_12_result;
      for (int v1061_12_label = 1; v1061_12_label <= 2; ++v1061_12_label) {
        const Space v1061_12_tail = child(v1061_11,v1061_12_label);
        if (v1061_12_tail.empty()) continue;
        const Path v1061_12_head{v1061_12_label};
        const Space v1062_2 = singleton(v1061_12_head);
        const Space v1062_3 = intersect(constant_14,v1062_2);
        const Space v1062_4 = (has_head(v1062_3) ? constant_15 : Space{});
        const Space v1062_5 = subtract(constant_0,v1062_4);
        Space v1062_7;
        if (!v1062_5.empty()) {
          const Space v1063_6 = routine_87(c, v1061_12_head, p1, v1061_12_tail);
          v1062_7 = compose(v1062_5,v1063_6);
        }
        const Space v1062_8 = intersect(constant_14,v1062_2);
        const Space v1062_9 = (has_head(v1062_8) ? constant_15 : Space{});
        Space v1062_11;
        if (!v1062_9.empty()) {
          const Space v1064_10 = routine_88(c, v1061_12_head, p1, v1061_12_tail);
          v1062_11 = compose(v1062_9,v1064_10);
        }
        const Space v1062_12 = unite(v1062_7,v1062_11);
        v1061_12_result = unite(v1061_12_result,v1062_12);
      }
      const Space v1061_12 = std::move(v1061_12_result);
      v1056_13 = compose(v1056_10,v1061_12);
    }
    const Space v1056_14 = unite(v1056_8,v1056_13);
    v1055_18_result = unite(v1055_18_result,v1056_14);
  }
  const Space v1055_18 = std::move(v1055_18_result);
  return v1055_18;
}

static Space routine_120(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1065_12_result;
  for (int v1065_12_label = 1; v1065_12_label <= 2; ++v1065_12_label) {
    const Space v1065_12_tail = child(s0,v1065_12_label);
    if (v1065_12_tail.empty()) continue;
    const Path v1065_12_head{v1065_12_label};
    const Space v1066_2 = singleton(v1065_12_head);
    const Space v1066_3 = intersect(constant_14,v1066_2);
    const Space v1066_4 = (has_head(v1066_3) ? constant_15 : Space{});
    const Space v1066_5 = subtract(constant_0,v1066_4);
    Space v1066_8;
    if (!v1066_5.empty()) {
      const Path v1067_6 = concat_path(p0,v1065_12_head);
      Space v1067_7_result;
      for (int v1067_7_label = 1; v1067_7_label <= 2; ++v1067_7_label) {
        const Space v1067_7_tail = child(v1065_12_tail,v1067_7_label);
        if (v1067_7_tail.empty()) continue;
        const Path v1067_7_head{v1067_7_label};
        const Space v1068_2 = singleton(v1067_7_head);
        const Space v1068_3 = intersect(constant_14,v1068_2);
        const Space v1068_4 = (has_head(v1068_3) ? constant_15 : Space{});
        const Space v1068_5 = subtract(constant_0,v1068_4);
        Space v1068_8;
        if (!v1068_5.empty()) {
          const Path v1069_6 = concat_path(v1067_6,v1067_7_head);
          const Space v1069_7 = routine_146(c, v1069_6, p1, v1067_7_tail);
          v1068_8 = compose(v1068_5,v1069_7);
        }
        const Space v1068_9 = intersect(constant_14,v1068_2);
        const Space v1068_10 = (has_head(v1068_9) ? constant_15 : Space{});
        Space v1068_12;
        if (!v1068_10.empty()) {
          const Path v1070_6 = concat_path(v1067_6,v1067_7_head);
          const Space v1070_11 = routine_147(c, v1070_6, p1, v1067_7_tail);
          v1068_12 = compose(v1068_10,v1070_11);
        }
        const Space v1068_13 = unite(v1068_8,v1068_12);
        v1067_7_result = unite(v1067_7_result,v1068_13);
      }
      const Space v1067_7 = std::move(v1067_7_result);
      v1066_8 = compose(v1066_5,v1067_7);
    }
    const Space v1066_9 = intersect(constant_14,v1066_2);
    const Space v1066_10 = (has_head(v1066_9) ? constant_15 : Space{});
    Space v1066_12;
    if (!v1066_10.empty()) {
      const Path v1071_6 = concat_path(p0,v1065_12_head);
      Space v1071_11_result;
      for (int v1071_11_label = 1; v1071_11_label <= 2; ++v1071_11_label) {
        const Space v1071_11_tail = child(v1065_12_tail,v1071_11_label);
        if (v1071_11_tail.empty()) continue;
        const Path v1071_11_head{v1071_11_label};
        const Space v1072_2 = singleton(v1071_11_head);
        const Space v1072_3 = intersect(constant_14,v1072_2);
        const Space v1072_4 = (has_head(v1072_3) ? constant_15 : Space{});
        const Space v1072_5 = subtract(constant_0,v1072_4);
        Space v1072_8;
        if (!v1072_5.empty()) {
          const Path v1073_6 = concat_path(v1071_6,v1071_11_head);
          const Space v1073_7 = routine_146(c, v1073_6, p1, v1071_11_tail);
          v1072_8 = compose(v1072_5,v1073_7);
        }
        const Space v1072_9 = intersect(constant_14,v1072_2);
        const Space v1072_10 = (has_head(v1072_9) ? constant_15 : Space{});
        Space v1072_12;
        if (!v1072_10.empty()) {
          const Path v1074_6 = concat_path(v1071_6,v1071_11_head);
          const Space v1074_11 = routine_93(c, v1074_6, p1, v1071_11_tail);
          v1072_12 = compose(v1072_10,v1074_11);
        }
        const Space v1072_13 = unite(v1072_8,v1072_12);
        v1071_11_result = unite(v1071_11_result,v1072_13);
      }
      const Space v1071_11 = std::move(v1071_11_result);
      v1066_12 = compose(v1066_10,v1071_11);
    }
    const Space v1066_13 = unite(v1066_8,v1066_12);
    v1065_12_result = unite(v1065_12_result,v1066_13);
  }
  const Space v1065_12 = std::move(v1065_12_result);
  return v1065_12;
}

static Space routine_121(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1075_9_result;
  for (int v1075_9_label = 1; v1075_9_label <= 2; ++v1075_9_label) {
    const Space v1075_9_tail = child(s0,v1075_9_label);
    if (v1075_9_tail.empty()) continue;
    const Path v1075_9_head{v1075_9_label};
    const Space v1076_2 = singleton(v1075_9_head);
    const Space v1076_3 = intersect(constant_14,v1076_2);
    const Space v1076_4 = (has_head(v1076_3) ? constant_15 : Space{});
    const Space v1076_5 = subtract(constant_0,v1076_4);
    Space v1076_8;
    if (!v1076_5.empty()) {
      const Path v1077_6 = concat_path(p0,v1075_9_head);
      Space v1077_7_result;
      for (int v1077_7_label = 1; v1077_7_label <= 2; ++v1077_7_label) {
        const Space v1077_7_tail = child(v1075_9_tail,v1077_7_label);
        if (v1077_7_tail.empty()) continue;
        const Path v1077_7_head{v1077_7_label};
        const Space v1078_2 = singleton(v1077_7_head);
        const Space v1078_3 = intersect(constant_14,v1078_2);
        const Space v1078_4 = (has_head(v1078_3) ? constant_15 : Space{});
        const Space v1078_5 = subtract(constant_0,v1078_4);
        Space v1078_8;
        if (!v1078_5.empty()) {
          const Path v1079_6 = concat_path(v1077_6,v1077_7_head);
          const Space v1079_7 = routine_146(c, v1079_6, p1, v1077_7_tail);
          v1078_8 = compose(v1078_5,v1079_7);
        }
        const Space v1078_9 = intersect(constant_14,v1078_2);
        const Space v1078_10 = (has_head(v1078_9) ? constant_15 : Space{});
        Space v1078_12;
        if (!v1078_10.empty()) {
          const Path v1080_6 = concat_path(v1077_6,v1077_7_head);
          const Space v1080_11 = routine_147(c, v1080_6, p1, v1077_7_tail);
          v1078_12 = compose(v1078_10,v1080_11);
        }
        const Space v1078_13 = unite(v1078_8,v1078_12);
        v1077_7_result = unite(v1077_7_result,v1078_13);
      }
      const Space v1077_7 = std::move(v1077_7_result);
      v1076_8 = compose(v1076_5,v1077_7);
    }
    const Space v1076_9 = intersect(constant_14,v1076_2);
    const Space v1076_10 = (has_head(v1076_9) ? constant_15 : Space{});
    const Space v1076_11 = compose(v1076_10,v1075_9_tail);
    const Path v1081_6 = concat_path(p0,v1075_9_head);
    const Space v1076_12 = wrap(v1076_11,v1081_6);
    const Space v1076_13 = wrap(v1076_12,p1);
    const Space v1076_14 = unite(v1076_8,v1076_13);
    v1075_9_result = unite(v1075_9_result,v1076_14);
  }
  const Space v1075_9 = std::move(v1075_9_result);
  return v1075_9;
}

static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1082_8_result;
  for (int v1082_8_label = 1; v1082_8_label <= 2; ++v1082_8_label) {
    const Space v1082_8_tail = child(s0,v1082_8_label);
    if (v1082_8_tail.empty()) continue;
    const Path v1082_8_head{v1082_8_label};
    const Space v1083_2 = singleton(v1082_8_head);
    const Space v1083_3 = intersect(constant_14,v1083_2);
    const Space v1083_4 = (has_head(v1083_3) ? constant_15 : Space{});
    const Space v1083_5 = subtract(constant_0,v1083_4);
    Space v1083_6_result;
    for (int v1083_6_label = 1; v1083_6_label <= 2; ++v1083_6_label) {
      const Space v1083_6_tail = child(v1082_8_tail,v1083_6_label);
      if (v1083_6_tail.empty()) continue;
      const Path v1083_6_head{v1083_6_label};
      const Space v1084_2 = Space{};
      v1083_6_result = unite(v1083_6_result,v1084_2);
    }
    const Space v1083_6 = std::move(v1083_6_result);
    const Space v1083_7 = compose(v1083_5,v1083_6);
    const Space v1083_8 = intersect(constant_14,v1083_2);
    const Space v1083_9 = (has_head(v1083_8) ? constant_15 : Space{});
    Space v1083_12;
    if (!v1083_9.empty()) {
      const Path v1085_10 = concat_path(p0,v1082_8_head);
      Space v1085_11_result;
      for (int v1085_11_label = 1; v1085_11_label <= 2; ++v1085_11_label) {
        const Space v1085_11_tail = child(v1082_8_tail,v1085_11_label);
        if (v1085_11_tail.empty()) continue;
        const Path v1085_11_head{v1085_11_label};
        const Space v1086_2 = singleton(v1085_11_head);
        const Space v1086_3 = intersect(constant_14,v1086_2);
        const Space v1086_4 = (has_head(v1086_3) ? constant_15 : Space{});
        Space v1086_7;
        if (!v1086_4.empty()) {
          const Path v1087_5 = concat_path(v1085_10,v1085_11_head);
          const Space v1087_6 = routine_47(c, v1087_5, p1, v1085_11_tail, s1);
          v1086_7 = compose(v1086_4,v1087_6);
        }
        v1085_11_result = unite(v1085_11_result,v1086_7);
      }
      const Space v1085_11 = std::move(v1085_11_result);
      v1083_12 = compose(v1083_9,v1085_11);
    }
    const Space v1083_13 = unite(v1083_7,v1083_12);
    v1082_8_result = unite(v1082_8_result,v1083_13);
  }
  const Space v1082_8 = std::move(v1082_8_result);
  return v1082_8;
}

static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1088_8 = unwrap(s1,constant_7);
  const Space v1088_10 = unwrap(v1088_8,constant_10);
  const Space v1088_11 = unwrap(v1088_10,p0);
  Space v1088_15_result;
  for (int v1088_15_label = 1; v1088_15_label <= 2; ++v1088_15_label) {
    const Space v1088_15_tail = child(s0,v1088_15_label);
    if (v1088_15_tail.empty()) continue;
    const Path v1088_15_head{v1088_15_label};
    const Space v1089_2 = singleton(v1088_15_head);
    const Space v1089_3 = intersect(constant_14,v1089_2);
    const Space v1089_4 = (has_head(v1089_3) ? constant_15 : Space{});
    const Space v1089_5 = subtract(constant_0,v1089_4);
    Space v1089_6_result;
    for (int v1089_6_label = 1; v1089_6_label <= 2; ++v1089_6_label) {
      const Space v1089_6_tail = child(v1088_15_tail,v1089_6_label);
      if (v1089_6_tail.empty()) continue;
      const Path v1089_6_head{v1089_6_label};
      const Space v1090_2 = Space{};
      v1089_6_result = unite(v1089_6_result,v1090_2);
    }
    const Space v1089_6 = std::move(v1089_6_result);
    const Space v1089_7 = compose(v1089_5,v1089_6);
    const Space v1089_8 = intersect(constant_14,v1089_2);
    const Space v1089_9 = (has_head(v1089_8) ? constant_15 : Space{});
    Space v1089_12;
    if (!v1089_9.empty()) {
      const Space v1091_10 = unwrap(v1088_11,v1088_15_head);
      Space v1091_11_result;
      for (int v1091_11_label = 1; v1091_11_label <= 2; ++v1091_11_label) {
        const Space v1091_11_tail = child(v1091_10,v1091_11_label);
        if (v1091_11_tail.empty()) continue;
        const Path v1091_11_head{v1091_11_label};
        const Space v1092_2 = singleton(v1091_11_head);
        const Space v1092_3 = intersect(constant_14,v1092_2);
        const Space v1092_4 = (has_head(v1092_3) ? constant_15 : Space{});
        const Space v1092_5 = subtract(constant_0,v1092_4);
        Space v1092_7;
        if (!v1092_5.empty()) {
          const Space v1093_6 = routine_87(c, v1091_11_head, p1, v1091_11_tail);
          v1092_7 = compose(v1092_5,v1093_6);
        }
        const Space v1092_8 = intersect(constant_14,v1092_2);
        const Space v1092_9 = (has_head(v1092_8) ? constant_15 : Space{});
        Space v1092_11;
        if (!v1092_9.empty()) {
          const Space v1094_10 = routine_88(c, v1091_11_head, p1, v1091_11_tail);
          v1092_11 = compose(v1092_9,v1094_10);
        }
        const Space v1092_12 = unite(v1092_7,v1092_11);
        v1091_11_result = unite(v1091_11_result,v1092_12);
      }
      const Space v1091_11 = std::move(v1091_11_result);
      v1089_12 = compose(v1089_9,v1091_11);
    }
    const Space v1089_13 = unite(v1089_7,v1089_12);
    v1088_15_result = unite(v1088_15_result,v1089_13);
  }
  const Space v1088_15 = std::move(v1088_15_result);
  return v1088_15;
}

static Space routine_124(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1095_12_result;
  for (int v1095_12_label = 1; v1095_12_label <= 2; ++v1095_12_label) {
    const Space v1095_12_tail = child(s0,v1095_12_label);
    if (v1095_12_tail.empty()) continue;
    const Path v1095_12_head{v1095_12_label};
    const Space v1096_2 = singleton(v1095_12_head);
    const Space v1096_3 = intersect(constant_14,v1096_2);
    const Space v1096_4 = (has_head(v1096_3) ? constant_15 : Space{});
    const Space v1096_5 = subtract(constant_0,v1096_4);
    Space v1096_8;
    if (!v1096_5.empty()) {
      const Path v1097_6 = concat_path(p0,v1095_12_head);
      Space v1097_7_result;
      for (int v1097_7_label = 1; v1097_7_label <= 2; ++v1097_7_label) {
        const Space v1097_7_tail = child(v1095_12_tail,v1097_7_label);
        if (v1097_7_tail.empty()) continue;
        const Path v1097_7_head{v1097_7_label};
        const Space v1098_2 = singleton(v1097_7_head);
        const Space v1098_3 = intersect(constant_14,v1098_2);
        const Space v1098_4 = (has_head(v1098_3) ? constant_15 : Space{});
        const Space v1098_5 = subtract(constant_0,v1098_4);
        Space v1098_8;
        if (!v1098_5.empty()) {
          const Path v1099_6 = concat_path(v1097_6,v1097_7_head);
          const Space v1099_7 = routine_148(c, v1099_6, p1, v1097_7_tail);
          v1098_8 = compose(v1098_5,v1099_7);
        }
        const Space v1098_9 = intersect(constant_14,v1098_2);
        const Space v1098_10 = (has_head(v1098_9) ? constant_15 : Space{});
        Space v1098_12;
        if (!v1098_10.empty()) {
          const Path v1100_6 = concat_path(v1097_6,v1097_7_head);
          const Space v1100_11 = routine_149(c, v1100_6, p1, v1097_7_tail);
          v1098_12 = compose(v1098_10,v1100_11);
        }
        const Space v1098_13 = unite(v1098_8,v1098_12);
        v1097_7_result = unite(v1097_7_result,v1098_13);
      }
      const Space v1097_7 = std::move(v1097_7_result);
      v1096_8 = compose(v1096_5,v1097_7);
    }
    const Space v1096_9 = intersect(constant_14,v1096_2);
    const Space v1096_10 = (has_head(v1096_9) ? constant_15 : Space{});
    Space v1096_12;
    if (!v1096_10.empty()) {
      const Path v1101_6 = concat_path(p0,v1095_12_head);
      Space v1101_11_result;
      for (int v1101_11_label = 1; v1101_11_label <= 2; ++v1101_11_label) {
        const Space v1101_11_tail = child(v1095_12_tail,v1101_11_label);
        if (v1101_11_tail.empty()) continue;
        const Path v1101_11_head{v1101_11_label};
        const Space v1102_2 = singleton(v1101_11_head);
        const Space v1102_3 = intersect(constant_14,v1102_2);
        const Space v1102_4 = (has_head(v1102_3) ? constant_15 : Space{});
        const Space v1102_5 = subtract(constant_0,v1102_4);
        Space v1102_8;
        if (!v1102_5.empty()) {
          const Path v1103_6 = concat_path(v1101_6,v1101_11_head);
          const Space v1103_7 = routine_148(c, v1103_6, p1, v1101_11_tail);
          v1102_8 = compose(v1102_5,v1103_7);
        }
        const Space v1102_9 = intersect(constant_14,v1102_2);
        const Space v1102_10 = (has_head(v1102_9) ? constant_15 : Space{});
        Space v1102_12;
        if (!v1102_10.empty()) {
          const Path v1104_6 = concat_path(v1101_6,v1101_11_head);
          const Space v1104_11 = routine_93(c, v1104_6, p1, v1101_11_tail);
          v1102_12 = compose(v1102_10,v1104_11);
        }
        const Space v1102_13 = unite(v1102_8,v1102_12);
        v1101_11_result = unite(v1101_11_result,v1102_13);
      }
      const Space v1101_11 = std::move(v1101_11_result);
      v1096_12 = compose(v1096_10,v1101_11);
    }
    const Space v1096_13 = unite(v1096_8,v1096_12);
    v1095_12_result = unite(v1095_12_result,v1096_13);
  }
  const Space v1095_12 = std::move(v1095_12_result);
  return v1095_12;
}

static Space routine_125(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1105_9_result;
  for (int v1105_9_label = 1; v1105_9_label <= 2; ++v1105_9_label) {
    const Space v1105_9_tail = child(s0,v1105_9_label);
    if (v1105_9_tail.empty()) continue;
    const Path v1105_9_head{v1105_9_label};
    const Space v1106_2 = singleton(v1105_9_head);
    const Space v1106_3 = intersect(constant_14,v1106_2);
    const Space v1106_4 = (has_head(v1106_3) ? constant_15 : Space{});
    const Space v1106_5 = subtract(constant_0,v1106_4);
    Space v1106_8;
    if (!v1106_5.empty()) {
      const Path v1107_6 = concat_path(p0,v1105_9_head);
      Space v1107_7_result;
      for (int v1107_7_label = 1; v1107_7_label <= 2; ++v1107_7_label) {
        const Space v1107_7_tail = child(v1105_9_tail,v1107_7_label);
        if (v1107_7_tail.empty()) continue;
        const Path v1107_7_head{v1107_7_label};
        const Space v1108_2 = singleton(v1107_7_head);
        const Space v1108_3 = intersect(constant_14,v1108_2);
        const Space v1108_4 = (has_head(v1108_3) ? constant_15 : Space{});
        const Space v1108_5 = subtract(constant_0,v1108_4);
        Space v1108_8;
        if (!v1108_5.empty()) {
          const Path v1109_6 = concat_path(v1107_6,v1107_7_head);
          const Space v1109_7 = routine_148(c, v1109_6, p1, v1107_7_tail);
          v1108_8 = compose(v1108_5,v1109_7);
        }
        const Space v1108_9 = intersect(constant_14,v1108_2);
        const Space v1108_10 = (has_head(v1108_9) ? constant_15 : Space{});
        Space v1108_12;
        if (!v1108_10.empty()) {
          const Path v1110_6 = concat_path(v1107_6,v1107_7_head);
          const Space v1110_11 = routine_149(c, v1110_6, p1, v1107_7_tail);
          v1108_12 = compose(v1108_10,v1110_11);
        }
        const Space v1108_13 = unite(v1108_8,v1108_12);
        v1107_7_result = unite(v1107_7_result,v1108_13);
      }
      const Space v1107_7 = std::move(v1107_7_result);
      v1106_8 = compose(v1106_5,v1107_7);
    }
    const Space v1106_9 = intersect(constant_14,v1106_2);
    const Space v1106_10 = (has_head(v1106_9) ? constant_15 : Space{});
    const Space v1106_11 = compose(v1106_10,v1105_9_tail);
    const Path v1111_6 = concat_path(p0,v1105_9_head);
    const Space v1106_12 = wrap(v1106_11,v1111_6);
    const Space v1106_13 = wrap(v1106_12,p1);
    const Space v1106_14 = unite(v1106_8,v1106_13);
    v1105_9_result = unite(v1105_9_result,v1106_14);
  }
  const Space v1105_9 = std::move(v1105_9_result);
  return v1105_9;
}

static Space routine_126(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1112_7_result;
  for (int v1112_7_label = 1; v1112_7_label <= 2; ++v1112_7_label) {
    const Space v1112_7_tail = child(s0,v1112_7_label);
    if (v1112_7_tail.empty()) continue;
    const Path v1112_7_head{v1112_7_label};
    const Space v1113_2 = singleton(v1112_7_head);
    const Space v1113_3 = intersect(constant_14,v1113_2);
    const Space v1113_4 = (has_head(v1113_3) ? constant_15 : Space{});
    const Space v1113_5 = subtract(constant_0,v1113_4);
    Space v1113_6_result;
    for (int v1113_6_label = 1; v1113_6_label <= 2; ++v1113_6_label) {
      const Space v1113_6_tail = child(v1112_7_tail,v1113_6_label);
      if (v1113_6_tail.empty()) continue;
      const Path v1113_6_head{v1113_6_label};
      const Space v1114_2 = Space{};
      v1113_6_result = unite(v1113_6_result,v1114_2);
    }
    const Space v1113_6 = std::move(v1113_6_result);
    const Space v1113_7 = compose(v1113_5,v1113_6);
    const Space v1113_8 = intersect(constant_14,v1113_2);
    const Space v1113_9 = (has_head(v1113_8) ? constant_15 : Space{});
    Space v1113_12;
    if (!v1113_9.empty()) {
      const Path v1115_10 = concat_path(p0,v1112_7_head);
      Space v1115_11_result;
      for (int v1115_11_label = 1; v1115_11_label <= 2; ++v1115_11_label) {
        const Space v1115_11_tail = child(v1112_7_tail,v1115_11_label);
        if (v1115_11_tail.empty()) continue;
        const Path v1115_11_head{v1115_11_label};
        const Space v1116_2 = singleton(v1115_11_head);
        const Space v1116_3 = intersect(constant_14,v1116_2);
        const Space v1116_4 = (has_head(v1116_3) ? constant_15 : Space{});
        Space v1116_7;
        if (!v1116_4.empty()) {
          const Path v1117_5 = concat_path(v1115_10,v1115_11_head);
          const Space v1117_6 = routine_52(c, v1117_5, p1, v1115_11_tail);
          v1116_7 = compose(v1116_4,v1117_6);
        }
        v1115_11_result = unite(v1115_11_result,v1116_7);
      }
      const Space v1115_11 = std::move(v1115_11_result);
      v1113_12 = compose(v1113_9,v1115_11);
    }
    const Space v1113_13 = unite(v1113_7,v1113_12);
    v1112_7_result = unite(v1112_7_result,v1113_13);
  }
  const Space v1112_7 = std::move(v1112_7_result);
  return v1112_7;
}

static Space routine_127(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1118_7_result;
  for (int v1118_7_label = 1; v1118_7_label <= 2; ++v1118_7_label) {
    const Space v1118_7_tail = child(s0,v1118_7_label);
    if (v1118_7_tail.empty()) continue;
    const Path v1118_7_head{v1118_7_label};
    const Space v1119_2 = singleton(v1118_7_head);
    const Space v1119_3 = intersect(constant_14,v1119_2);
    const Space v1119_4 = (has_head(v1119_3) ? constant_15 : Space{});
    const Space v1119_5 = compose(v1119_4,v1118_7_tail);
    const Path v1119_6 = concat_path(p0,v1118_7_head);
    const Space v1119_7 = wrap(v1119_5,v1119_6);
    const Space v1119_8 = wrap(v1119_7,p1);
    const Space v1119_9 = wrap(v1119_8,constant_10);
    const Space v1119_10 = intersect(constant_14,v1119_2);
    const Space v1119_11 = (has_head(v1119_10) ? constant_15 : Space{});
    const Space v1119_12 = subtract(constant_0,v1119_11);
    Space v1119_13_result;
    for (int v1119_13_label = 1; v1119_13_label <= 2; ++v1119_13_label) {
      const Space v1119_13_tail = child(v1118_7_tail,v1119_13_label);
      if (v1119_13_tail.empty()) continue;
      const Path v1119_13_head{v1119_13_label};
      const Space v1120_2 = Space{};
      v1119_13_result = unite(v1119_13_result,v1120_2);
    }
    const Space v1119_13 = std::move(v1119_13_result);
    const Space v1119_14 = compose(v1119_12,v1119_13);
    const Space v1119_15 = unite(v1119_9,v1119_14);
    v1118_7_result = unite(v1118_7_result,v1119_15);
  }
  const Space v1118_7 = std::move(v1118_7_result);
  return v1118_7;
}

static Space routine_128(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1121_3_result;
  for (int v1121_3_label = 1; v1121_3_label <= 2; ++v1121_3_label) {
    const Space v1121_3_tail = child(s0,v1121_3_label);
    if (v1121_3_tail.empty()) continue;
    const Path v1121_3_head{v1121_3_label};
    const Space v1122_2 = Space{};
    v1121_3_result = unite(v1121_3_result,v1122_2);
  }
  const Space v1121_3 = std::move(v1121_3_result);
  return v1121_3;
}

static Space routine_129(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1123_4_result;
  for (int v1123_4_label = 1; v1123_4_label <= 2; ++v1123_4_label) {
    const Space v1123_4_tail = child(s0,v1123_4_label);
    if (v1123_4_tail.empty()) continue;
    const Path v1123_4_head{v1123_4_label};
    const Space v1124_2 = singleton(v1123_4_head);
    const Space v1124_3 = intersect(constant_14,v1124_2);
    const Space v1124_4 = (has_head(v1124_3) ? constant_15 : Space{});
    const Space v1124_5 = compose(v1124_4,v1123_4_tail);
    const Path v1124_6 = concat_path(p0,v1123_4_head);
    const Space v1124_7 = wrap(v1124_5,v1124_6);
    v1123_4_result = unite(v1123_4_result,v1124_7);
  }
  const Space v1123_4 = std::move(v1123_4_result);
  const Space v1123_5 = wrap(v1123_4,p1);
  const Space v1123_7 = wrap(v1123_5,constant_10);
  return v1123_7;
}

static Space routine_130(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1125_4_result;
  for (int v1125_4_label = 1; v1125_4_label <= 2; ++v1125_4_label) {
    const Space v1125_4_tail = child(s0,v1125_4_label);
    if (v1125_4_tail.empty()) continue;
    const Path v1125_4_head{v1125_4_label};
    const Space v1126_2 = Space{};
    v1125_4_result = unite(v1125_4_result,v1126_2);
  }
  const Space v1125_4 = std::move(v1125_4_result);
  return v1125_4;
}

static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1127_6 = unwrap(s1,constant_7);
  const Space v1127_8 = unwrap(v1127_6,constant_10);
  const Space v1127_9 = unwrap(v1127_8,p0);
  Space v1127_13_result;
  for (int v1127_13_label = 1; v1127_13_label <= 2; ++v1127_13_label) {
    const Space v1127_13_tail = child(s0,v1127_13_label);
    if (v1127_13_tail.empty()) continue;
    const Path v1127_13_head{v1127_13_label};
    const Space v1128_2 = singleton(v1127_13_head);
    const Space v1128_3 = intersect(constant_14,v1128_2);
    const Space v1128_4 = (has_head(v1128_3) ? constant_15 : Space{});
    Space v1128_7;
    if (!v1128_4.empty()) {
      const Space v1129_5 = unwrap(v1127_9,v1127_13_head);
      Space v1129_6_result;
      for (int v1129_6_label = 1; v1129_6_label <= 2; ++v1129_6_label) {
        const Space v1129_6_tail = child(v1129_5,v1129_6_label);
        if (v1129_6_tail.empty()) continue;
        const Path v1129_6_head{v1129_6_label};
        const Space v1130_2 = singleton(v1129_6_head);
        const Space v1130_3 = intersect(constant_14,v1130_2);
        const Space v1130_4 = (has_head(v1130_3) ? constant_15 : Space{});
        const Space v1130_5 = subtract(constant_0,v1130_4);
        Space v1130_7;
        if (!v1130_5.empty()) {
          const Space v1131_6 = routine_59(c, v1129_6_head, p1, v1129_6_tail);
          v1130_7 = compose(v1130_5,v1131_6);
        }
        const Space v1130_8 = intersect(constant_14,v1130_2);
        const Space v1130_9 = (has_head(v1130_8) ? constant_15 : Space{});
        Space v1130_11;
        if (!v1130_9.empty()) {
          const Space v1132_10 = routine_60(c, v1129_6_head, p1, v1129_6_tail);
          v1130_11 = compose(v1130_9,v1132_10);
        }
        const Space v1130_12 = unite(v1130_7,v1130_11);
        v1129_6_result = unite(v1129_6_result,v1130_12);
      }
      const Space v1129_6 = std::move(v1129_6_result);
      v1128_7 = compose(v1128_4,v1129_6);
    }
    v1127_13_result = unite(v1127_13_result,v1128_7);
  }
  const Space v1127_13 = std::move(v1127_13_result);
  return v1127_13;
}

static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1133_12_result;
  for (int v1133_12_label = 1; v1133_12_label <= 2; ++v1133_12_label) {
    const Space v1133_12_tail = child(s0,v1133_12_label);
    if (v1133_12_tail.empty()) continue;
    const Path v1133_12_head{v1133_12_label};
    const Space v1134_2 = singleton(v1133_12_head);
    const Space v1134_3 = intersect(constant_14,v1134_2);
    const Space v1134_4 = (has_head(v1134_3) ? constant_15 : Space{});
    const Space v1134_5 = subtract(constant_0,v1134_4);
    Space v1134_8;
    if (!v1134_5.empty()) {
      const Path v1135_6 = concat_path(p0,v1133_12_head);
      Space v1135_7_result;
      for (int v1135_7_label = 1; v1135_7_label <= 2; ++v1135_7_label) {
        const Space v1135_7_tail = child(v1133_12_tail,v1135_7_label);
        if (v1135_7_tail.empty()) continue;
        const Path v1135_7_head{v1135_7_label};
        const Space v1136_2 = singleton(v1135_7_head);
        const Space v1136_3 = intersect(constant_14,v1136_2);
        const Space v1136_4 = (has_head(v1136_3) ? constant_15 : Space{});
        const Space v1136_5 = subtract(constant_0,v1136_4);
        Space v1136_8;
        if (!v1136_5.empty()) {
          const Path v1137_6 = concat_path(v1135_6,v1135_7_head);
          const Space v1137_7 = routine_150(c, v1137_6, p1, v1135_7_tail);
          v1136_8 = compose(v1136_5,v1137_7);
        }
        const Space v1136_9 = intersect(constant_14,v1136_2);
        const Space v1136_10 = (has_head(v1136_9) ? constant_15 : Space{});
        Space v1136_12;
        if (!v1136_10.empty()) {
          const Path v1138_6 = concat_path(v1135_6,v1135_7_head);
          const Space v1138_11 = routine_151(c, v1138_6, p1, v1135_7_tail);
          v1136_12 = compose(v1136_10,v1138_11);
        }
        const Space v1136_13 = unite(v1136_8,v1136_12);
        v1135_7_result = unite(v1135_7_result,v1136_13);
      }
      const Space v1135_7 = std::move(v1135_7_result);
      v1134_8 = compose(v1134_5,v1135_7);
    }
    const Space v1134_9 = intersect(constant_14,v1134_2);
    const Space v1134_10 = (has_head(v1134_9) ? constant_15 : Space{});
    Space v1134_12;
    if (!v1134_10.empty()) {
      const Path v1139_6 = concat_path(p0,v1133_12_head);
      Space v1139_11_result;
      for (int v1139_11_label = 1; v1139_11_label <= 2; ++v1139_11_label) {
        const Space v1139_11_tail = child(v1133_12_tail,v1139_11_label);
        if (v1139_11_tail.empty()) continue;
        const Path v1139_11_head{v1139_11_label};
        const Space v1140_2 = singleton(v1139_11_head);
        const Space v1140_3 = intersect(constant_14,v1140_2);
        const Space v1140_4 = (has_head(v1140_3) ? constant_15 : Space{});
        const Space v1140_5 = subtract(constant_0,v1140_4);
        Space v1140_8;
        if (!v1140_5.empty()) {
          const Path v1141_6 = concat_path(v1139_6,v1139_11_head);
          const Space v1141_7 = routine_150(c, v1141_6, p1, v1139_11_tail);
          v1140_8 = compose(v1140_5,v1141_7);
        }
        const Space v1140_9 = intersect(constant_14,v1140_2);
        const Space v1140_10 = (has_head(v1140_9) ? constant_15 : Space{});
        Space v1140_12;
        if (!v1140_10.empty()) {
          const Path v1142_6 = concat_path(v1139_6,v1139_11_head);
          const Space v1142_11 = routine_65(c, v1142_6, p1, v1139_11_tail);
          v1140_12 = compose(v1140_10,v1142_11);
        }
        const Space v1140_13 = unite(v1140_8,v1140_12);
        v1139_11_result = unite(v1139_11_result,v1140_13);
      }
      const Space v1139_11 = std::move(v1139_11_result);
      v1134_12 = compose(v1134_10,v1139_11);
    }
    const Space v1134_13 = unite(v1134_8,v1134_12);
    v1133_12_result = unite(v1133_12_result,v1134_13);
  }
  const Space v1133_12 = std::move(v1133_12_result);
  return v1133_12;
}

static Space routine_133(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1143_9_result;
  for (int v1143_9_label = 1; v1143_9_label <= 2; ++v1143_9_label) {
    const Space v1143_9_tail = child(s0,v1143_9_label);
    if (v1143_9_tail.empty()) continue;
    const Path v1143_9_head{v1143_9_label};
    const Space v1144_2 = singleton(v1143_9_head);
    const Space v1144_3 = intersect(constant_14,v1144_2);
    const Space v1144_4 = (has_head(v1144_3) ? constant_15 : Space{});
    const Space v1144_5 = subtract(constant_0,v1144_4);
    Space v1144_8;
    if (!v1144_5.empty()) {
      const Path v1145_6 = concat_path(p0,v1143_9_head);
      Space v1145_7_result;
      for (int v1145_7_label = 1; v1145_7_label <= 2; ++v1145_7_label) {
        const Space v1145_7_tail = child(v1143_9_tail,v1145_7_label);
        if (v1145_7_tail.empty()) continue;
        const Path v1145_7_head{v1145_7_label};
        const Space v1146_2 = singleton(v1145_7_head);
        const Space v1146_3 = intersect(constant_14,v1146_2);
        const Space v1146_4 = (has_head(v1146_3) ? constant_15 : Space{});
        const Space v1146_5 = subtract(constant_0,v1146_4);
        Space v1146_8;
        if (!v1146_5.empty()) {
          const Path v1147_6 = concat_path(v1145_6,v1145_7_head);
          const Space v1147_7 = routine_150(c, v1147_6, p1, v1145_7_tail);
          v1146_8 = compose(v1146_5,v1147_7);
        }
        const Space v1146_9 = intersect(constant_14,v1146_2);
        const Space v1146_10 = (has_head(v1146_9) ? constant_15 : Space{});
        Space v1146_12;
        if (!v1146_10.empty()) {
          const Path v1148_6 = concat_path(v1145_6,v1145_7_head);
          const Space v1148_11 = routine_151(c, v1148_6, p1, v1145_7_tail);
          v1146_12 = compose(v1146_10,v1148_11);
        }
        const Space v1146_13 = unite(v1146_8,v1146_12);
        v1145_7_result = unite(v1145_7_result,v1146_13);
      }
      const Space v1145_7 = std::move(v1145_7_result);
      v1144_8 = compose(v1144_5,v1145_7);
    }
    const Space v1144_9 = intersect(constant_14,v1144_2);
    const Space v1144_10 = (has_head(v1144_9) ? constant_15 : Space{});
    const Space v1144_11 = compose(v1144_10,v1143_9_tail);
    const Path v1149_6 = concat_path(p0,v1143_9_head);
    const Space v1144_12 = wrap(v1144_11,v1149_6);
    const Space v1144_13 = wrap(v1144_12,p1);
    const Space v1144_14 = unite(v1144_8,v1144_13);
    v1143_9_result = unite(v1143_9_result,v1144_14);
  }
  const Space v1143_9 = std::move(v1143_9_result);
  return v1143_9;
}

static Space routine_134(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1150_7_result;
  for (int v1150_7_label = 1; v1150_7_label <= 2; ++v1150_7_label) {
    const Space v1150_7_tail = child(s0,v1150_7_label);
    if (v1150_7_tail.empty()) continue;
    const Path v1150_7_head{v1150_7_label};
    const Space v1151_2 = singleton(v1150_7_head);
    const Space v1151_3 = intersect(constant_14,v1151_2);
    const Space v1151_4 = (has_head(v1151_3) ? constant_15 : Space{});
    const Space v1151_5 = subtract(constant_0,v1151_4);
    Space v1151_6_result;
    for (int v1151_6_label = 1; v1151_6_label <= 2; ++v1151_6_label) {
      const Space v1151_6_tail = child(v1150_7_tail,v1151_6_label);
      if (v1151_6_tail.empty()) continue;
      const Path v1151_6_head{v1151_6_label};
      const Space v1152_2 = Space{};
      v1151_6_result = unite(v1151_6_result,v1152_2);
    }
    const Space v1151_6 = std::move(v1151_6_result);
    const Space v1151_7 = compose(v1151_5,v1151_6);
    const Space v1151_8 = intersect(constant_14,v1151_2);
    const Space v1151_9 = (has_head(v1151_8) ? constant_15 : Space{});
    Space v1151_12;
    if (!v1151_9.empty()) {
      const Path v1153_10 = concat_path(p0,v1150_7_head);
      Space v1153_11_result;
      for (int v1153_11_label = 1; v1153_11_label <= 2; ++v1153_11_label) {
        const Space v1153_11_tail = child(v1150_7_tail,v1153_11_label);
        if (v1153_11_tail.empty()) continue;
        const Path v1153_11_head{v1153_11_label};
        const Space v1154_2 = singleton(v1153_11_head);
        const Space v1154_3 = intersect(constant_14,v1154_2);
        const Space v1154_4 = (has_head(v1154_3) ? constant_15 : Space{});
        Space v1154_7;
        if (!v1154_4.empty()) {
          const Path v1155_5 = concat_path(v1153_10,v1153_11_head);
          const Space v1155_6 = routine_65(c, v1155_5, p1, v1153_11_tail);
          v1154_7 = compose(v1154_4,v1155_6);
        }
        v1153_11_result = unite(v1153_11_result,v1154_7);
      }
      const Space v1153_11 = std::move(v1153_11_result);
      v1151_12 = compose(v1151_9,v1153_11);
    }
    const Space v1151_13 = unite(v1151_7,v1151_12);
    v1150_7_result = unite(v1150_7_result,v1151_13);
  }
  const Space v1150_7 = std::move(v1150_7_result);
  return v1150_7;
}

static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1156_6_result;
  for (int v1156_6_label = 1; v1156_6_label <= 2; ++v1156_6_label) {
    const Space v1156_6_tail = child(s0,v1156_6_label);
    if (v1156_6_tail.empty()) continue;
    const Path v1156_6_head{v1156_6_label};
    const Space v1157_2 = singleton(v1156_6_head);
    const Space v1157_3 = intersect(constant_14,v1157_2);
    const Space v1157_4 = (has_head(v1157_3) ? constant_15 : Space{});
    const Space v1157_5 = subtract(constant_0,v1157_4);
    Space v1157_6_result;
    for (int v1157_6_label = 1; v1157_6_label <= 2; ++v1157_6_label) {
      const Space v1157_6_tail = child(v1156_6_tail,v1157_6_label);
      if (v1157_6_tail.empty()) continue;
      const Path v1157_6_head{v1157_6_label};
      const Space v1158_2 = Space{};
      v1157_6_result = unite(v1157_6_result,v1158_2);
    }
    const Space v1157_6 = std::move(v1157_6_result);
    const Space v1157_7 = compose(v1157_5,v1157_6);
    const Space v1157_8 = intersect(constant_14,v1157_2);
    const Space v1157_9 = (has_head(v1157_8) ? constant_15 : Space{});
    const Space v1157_10 = compose(v1157_9,v1156_6_tail);
    const Path v1157_11 = concat_path(p0,v1156_6_head);
    const Space v1157_12 = wrap(v1157_10,v1157_11);
    const Space v1157_13 = wrap(v1157_12,p1);
    const Space v1157_14 = unite(v1157_7,v1157_13);
    v1156_6_result = unite(v1156_6_result,v1157_14);
  }
  const Space v1156_6 = std::move(v1156_6_result);
  return v1156_6;
}

static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1159_3_result;
  for (int v1159_3_label = 1; v1159_3_label <= 2; ++v1159_3_label) {
    const Space v1159_3_tail = child(s0,v1159_3_label);
    if (v1159_3_tail.empty()) continue;
    const Path v1159_3_head{v1159_3_label};
    const Space v1160_2 = Space{};
    v1159_3_result = unite(v1159_3_result,v1160_2);
  }
  const Space v1159_3 = std::move(v1159_3_result);
  return v1159_3;
}

static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1161_4_result;
  for (int v1161_4_label = 1; v1161_4_label <= 2; ++v1161_4_label) {
    const Space v1161_4_tail = child(s0,v1161_4_label);
    if (v1161_4_tail.empty()) continue;
    const Path v1161_4_head{v1161_4_label};
    const Space v1162_2 = singleton(v1161_4_head);
    const Space v1162_3 = intersect(constant_14,v1162_2);
    const Space v1162_4 = (has_head(v1162_3) ? constant_15 : Space{});
    const Space v1162_5 = compose(v1162_4,v1161_4_tail);
    const Path v1162_6 = concat_path(p0,v1161_4_head);
    const Space v1162_7 = wrap(v1162_5,v1162_6);
    v1161_4_result = unite(v1161_4_result,v1162_7);
  }
  const Space v1161_4 = std::move(v1161_4_result);
  const Space v1161_5 = wrap(v1161_4,p1);
  return v1161_5;
}

static Space routine_138(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1163_4_result;
  for (int v1163_4_label = 1; v1163_4_label <= 2; ++v1163_4_label) {
    const Space v1163_4_tail = child(s0,v1163_4_label);
    if (v1163_4_tail.empty()) continue;
    const Path v1163_4_head{v1163_4_label};
    const Space v1164_2 = Space{};
    v1163_4_result = unite(v1163_4_result,v1164_2);
  }
  const Space v1163_4 = std::move(v1163_4_result);
  return v1163_4;
}

static Space routine_139(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1165_6 = unwrap(s1,constant_9);
  const Space v1165_8 = unwrap(v1165_6,constant_10);
  const Space v1165_9 = unwrap(v1165_8,p0);
  Space v1165_13_result;
  for (int v1165_13_label = 1; v1165_13_label <= 2; ++v1165_13_label) {
    const Space v1165_13_tail = child(s0,v1165_13_label);
    if (v1165_13_tail.empty()) continue;
    const Path v1165_13_head{v1165_13_label};
    const Space v1166_2 = singleton(v1165_13_head);
    const Space v1166_3 = intersect(constant_14,v1166_2);
    const Space v1166_4 = (has_head(v1166_3) ? constant_15 : Space{});
    Space v1166_7;
    if (!v1166_4.empty()) {
      const Space v1167_5 = unwrap(v1165_9,v1165_13_head);
      Space v1167_6_result;
      for (int v1167_6_label = 1; v1167_6_label <= 2; ++v1167_6_label) {
        const Space v1167_6_tail = child(v1167_5,v1167_6_label);
        if (v1167_6_tail.empty()) continue;
        const Path v1167_6_head{v1167_6_label};
        const Space v1168_2 = singleton(v1167_6_head);
        const Space v1168_3 = intersect(constant_14,v1168_2);
        const Space v1168_4 = (has_head(v1168_3) ? constant_15 : Space{});
        const Space v1168_5 = subtract(constant_0,v1168_4);
        Space v1168_7;
        if (!v1168_5.empty()) {
          const Space v1169_6 = routine_76(c, v1167_6_head, p1, v1167_6_tail);
          v1168_7 = compose(v1168_5,v1169_6);
        }
        const Space v1168_8 = intersect(constant_14,v1168_2);
        const Space v1168_9 = (has_head(v1168_8) ? constant_15 : Space{});
        Space v1168_11;
        if (!v1168_9.empty()) {
          const Space v1170_10 = routine_77(c, v1167_6_head, p1, v1167_6_tail);
          v1168_11 = compose(v1168_9,v1170_10);
        }
        const Space v1168_12 = unite(v1168_7,v1168_11);
        v1167_6_result = unite(v1167_6_result,v1168_12);
      }
      const Space v1167_6 = std::move(v1167_6_result);
      v1166_7 = compose(v1166_4,v1167_6);
    }
    v1165_13_result = unite(v1165_13_result,v1166_7);
  }
  const Space v1165_13 = std::move(v1165_13_result);
  return v1165_13;
}

static Space routine_140(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1171_12_result;
  for (int v1171_12_label = 1; v1171_12_label <= 2; ++v1171_12_label) {
    const Space v1171_12_tail = child(s0,v1171_12_label);
    if (v1171_12_tail.empty()) continue;
    const Path v1171_12_head{v1171_12_label};
    const Space v1172_2 = singleton(v1171_12_head);
    const Space v1172_3 = intersect(constant_14,v1172_2);
    const Space v1172_4 = (has_head(v1172_3) ? constant_15 : Space{});
    const Space v1172_5 = subtract(constant_0,v1172_4);
    Space v1172_8;
    if (!v1172_5.empty()) {
      const Path v1173_6 = concat_path(p0,v1171_12_head);
      Space v1173_7_result;
      for (int v1173_7_label = 1; v1173_7_label <= 2; ++v1173_7_label) {
        const Space v1173_7_tail = child(v1171_12_tail,v1173_7_label);
        if (v1173_7_tail.empty()) continue;
        const Path v1173_7_head{v1173_7_label};
        const Space v1174_2 = singleton(v1173_7_head);
        const Space v1174_3 = intersect(constant_14,v1174_2);
        const Space v1174_4 = (has_head(v1174_3) ? constant_15 : Space{});
        const Space v1174_5 = subtract(constant_0,v1174_4);
        Space v1174_8;
        if (!v1174_5.empty()) {
          const Path v1175_6 = concat_path(v1173_6,v1173_7_head);
          const Space v1175_7 = routine_152(c, v1175_6, p1, v1173_7_tail);
          v1174_8 = compose(v1174_5,v1175_7);
        }
        const Space v1174_9 = intersect(constant_14,v1174_2);
        const Space v1174_10 = (has_head(v1174_9) ? constant_15 : Space{});
        Space v1174_12;
        if (!v1174_10.empty()) {
          const Path v1176_6 = concat_path(v1173_6,v1173_7_head);
          const Space v1176_11 = routine_153(c, v1176_6, p1, v1173_7_tail);
          v1174_12 = compose(v1174_10,v1176_11);
        }
        const Space v1174_13 = unite(v1174_8,v1174_12);
        v1173_7_result = unite(v1173_7_result,v1174_13);
      }
      const Space v1173_7 = std::move(v1173_7_result);
      v1172_8 = compose(v1172_5,v1173_7);
    }
    const Space v1172_9 = intersect(constant_14,v1172_2);
    const Space v1172_10 = (has_head(v1172_9) ? constant_15 : Space{});
    Space v1172_12;
    if (!v1172_10.empty()) {
      const Path v1177_6 = concat_path(p0,v1171_12_head);
      Space v1177_11_result;
      for (int v1177_11_label = 1; v1177_11_label <= 2; ++v1177_11_label) {
        const Space v1177_11_tail = child(v1171_12_tail,v1177_11_label);
        if (v1177_11_tail.empty()) continue;
        const Path v1177_11_head{v1177_11_label};
        const Space v1178_2 = singleton(v1177_11_head);
        const Space v1178_3 = intersect(constant_14,v1178_2);
        const Space v1178_4 = (has_head(v1178_3) ? constant_15 : Space{});
        const Space v1178_5 = subtract(constant_0,v1178_4);
        Space v1178_8;
        if (!v1178_5.empty()) {
          const Path v1179_6 = concat_path(v1177_6,v1177_11_head);
          const Space v1179_7 = routine_152(c, v1179_6, p1, v1177_11_tail);
          v1178_8 = compose(v1178_5,v1179_7);
        }
        const Space v1178_9 = intersect(constant_14,v1178_2);
        const Space v1178_10 = (has_head(v1178_9) ? constant_15 : Space{});
        Space v1178_12;
        if (!v1178_10.empty()) {
          const Path v1180_6 = concat_path(v1177_6,v1177_11_head);
          const Space v1180_11 = routine_82(c, v1180_6, p1, v1177_11_tail);
          v1178_12 = compose(v1178_10,v1180_11);
        }
        const Space v1178_13 = unite(v1178_8,v1178_12);
        v1177_11_result = unite(v1177_11_result,v1178_13);
      }
      const Space v1177_11 = std::move(v1177_11_result);
      v1172_12 = compose(v1172_10,v1177_11);
    }
    const Space v1172_13 = unite(v1172_8,v1172_12);
    v1171_12_result = unite(v1171_12_result,v1172_13);
  }
  const Space v1171_12 = std::move(v1171_12_result);
  return v1171_12;
}

static Space routine_141(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1181_9_result;
  for (int v1181_9_label = 1; v1181_9_label <= 2; ++v1181_9_label) {
    const Space v1181_9_tail = child(s0,v1181_9_label);
    if (v1181_9_tail.empty()) continue;
    const Path v1181_9_head{v1181_9_label};
    const Space v1182_2 = singleton(v1181_9_head);
    const Space v1182_3 = intersect(constant_14,v1182_2);
    const Space v1182_4 = (has_head(v1182_3) ? constant_15 : Space{});
    const Space v1182_5 = subtract(constant_0,v1182_4);
    Space v1182_8;
    if (!v1182_5.empty()) {
      const Path v1183_6 = concat_path(p0,v1181_9_head);
      Space v1183_7_result;
      for (int v1183_7_label = 1; v1183_7_label <= 2; ++v1183_7_label) {
        const Space v1183_7_tail = child(v1181_9_tail,v1183_7_label);
        if (v1183_7_tail.empty()) continue;
        const Path v1183_7_head{v1183_7_label};
        const Space v1184_2 = singleton(v1183_7_head);
        const Space v1184_3 = intersect(constant_14,v1184_2);
        const Space v1184_4 = (has_head(v1184_3) ? constant_15 : Space{});
        const Space v1184_5 = subtract(constant_0,v1184_4);
        Space v1184_8;
        if (!v1184_5.empty()) {
          const Path v1185_6 = concat_path(v1183_6,v1183_7_head);
          const Space v1185_7 = routine_152(c, v1185_6, p1, v1183_7_tail);
          v1184_8 = compose(v1184_5,v1185_7);
        }
        const Space v1184_9 = intersect(constant_14,v1184_2);
        const Space v1184_10 = (has_head(v1184_9) ? constant_15 : Space{});
        Space v1184_12;
        if (!v1184_10.empty()) {
          const Path v1186_6 = concat_path(v1183_6,v1183_7_head);
          const Space v1186_11 = routine_153(c, v1186_6, p1, v1183_7_tail);
          v1184_12 = compose(v1184_10,v1186_11);
        }
        const Space v1184_13 = unite(v1184_8,v1184_12);
        v1183_7_result = unite(v1183_7_result,v1184_13);
      }
      const Space v1183_7 = std::move(v1183_7_result);
      v1182_8 = compose(v1182_5,v1183_7);
    }
    const Space v1182_9 = intersect(constant_14,v1182_2);
    const Space v1182_10 = (has_head(v1182_9) ? constant_15 : Space{});
    const Space v1182_11 = compose(v1182_10,v1181_9_tail);
    const Path v1187_6 = concat_path(p0,v1181_9_head);
    const Space v1182_12 = wrap(v1182_11,v1187_6);
    const Space v1182_13 = wrap(v1182_12,p1);
    const Space v1182_14 = unite(v1182_8,v1182_13);
    v1181_9_result = unite(v1181_9_result,v1182_14);
  }
  const Space v1181_9 = std::move(v1181_9_result);
  return v1181_9;
}

static Space routine_142(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1188_7_result;
  for (int v1188_7_label = 1; v1188_7_label <= 2; ++v1188_7_label) {
    const Space v1188_7_tail = child(s0,v1188_7_label);
    if (v1188_7_tail.empty()) continue;
    const Path v1188_7_head{v1188_7_label};
    const Space v1189_2 = singleton(v1188_7_head);
    const Space v1189_3 = intersect(constant_14,v1189_2);
    const Space v1189_4 = (has_head(v1189_3) ? constant_15 : Space{});
    const Space v1189_5 = subtract(constant_0,v1189_4);
    Space v1189_6_result;
    for (int v1189_6_label = 1; v1189_6_label <= 2; ++v1189_6_label) {
      const Space v1189_6_tail = child(v1188_7_tail,v1189_6_label);
      if (v1189_6_tail.empty()) continue;
      const Path v1189_6_head{v1189_6_label};
      const Space v1190_2 = Space{};
      v1189_6_result = unite(v1189_6_result,v1190_2);
    }
    const Space v1189_6 = std::move(v1189_6_result);
    const Space v1189_7 = compose(v1189_5,v1189_6);
    const Space v1189_8 = intersect(constant_14,v1189_2);
    const Space v1189_9 = (has_head(v1189_8) ? constant_15 : Space{});
    Space v1189_12;
    if (!v1189_9.empty()) {
      const Path v1191_10 = concat_path(p0,v1188_7_head);
      Space v1191_11_result;
      for (int v1191_11_label = 1; v1191_11_label <= 2; ++v1191_11_label) {
        const Space v1191_11_tail = child(v1188_7_tail,v1191_11_label);
        if (v1191_11_tail.empty()) continue;
        const Path v1191_11_head{v1191_11_label};
        const Space v1192_2 = singleton(v1191_11_head);
        const Space v1192_3 = intersect(constant_14,v1192_2);
        const Space v1192_4 = (has_head(v1192_3) ? constant_15 : Space{});
        Space v1192_7;
        if (!v1192_4.empty()) {
          const Path v1193_5 = concat_path(v1191_10,v1191_11_head);
          const Space v1193_6 = routine_82(c, v1193_5, p1, v1191_11_tail);
          v1192_7 = compose(v1192_4,v1193_6);
        }
        v1191_11_result = unite(v1191_11_result,v1192_7);
      }
      const Space v1191_11 = std::move(v1191_11_result);
      v1189_12 = compose(v1189_9,v1191_11);
    }
    const Space v1189_13 = unite(v1189_7,v1189_12);
    v1188_7_result = unite(v1188_7_result,v1189_13);
  }
  const Space v1188_7 = std::move(v1188_7_result);
  return v1188_7;
}

static Space routine_143(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1194_6_result;
  for (int v1194_6_label = 1; v1194_6_label <= 2; ++v1194_6_label) {
    const Space v1194_6_tail = child(s0,v1194_6_label);
    if (v1194_6_tail.empty()) continue;
    const Path v1194_6_head{v1194_6_label};
    const Space v1195_2 = singleton(v1194_6_head);
    const Space v1195_3 = intersect(constant_14,v1195_2);
    const Space v1195_4 = (has_head(v1195_3) ? constant_15 : Space{});
    const Space v1195_5 = subtract(constant_0,v1195_4);
    Space v1195_6_result;
    for (int v1195_6_label = 1; v1195_6_label <= 2; ++v1195_6_label) {
      const Space v1195_6_tail = child(v1194_6_tail,v1195_6_label);
      if (v1195_6_tail.empty()) continue;
      const Path v1195_6_head{v1195_6_label};
      const Space v1196_2 = Space{};
      v1195_6_result = unite(v1195_6_result,v1196_2);
    }
    const Space v1195_6 = std::move(v1195_6_result);
    const Space v1195_7 = compose(v1195_5,v1195_6);
    const Space v1195_8 = intersect(constant_14,v1195_2);
    const Space v1195_9 = (has_head(v1195_8) ? constant_15 : Space{});
    const Space v1195_10 = compose(v1195_9,v1194_6_tail);
    const Path v1195_11 = concat_path(p0,v1194_6_head);
    const Space v1195_12 = wrap(v1195_10,v1195_11);
    const Space v1195_13 = wrap(v1195_12,p1);
    const Space v1195_14 = unite(v1195_7,v1195_13);
    v1194_6_result = unite(v1194_6_result,v1195_14);
  }
  const Space v1194_6 = std::move(v1194_6_result);
  return v1194_6;
}

static Space routine_144(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1197_4_result;
  for (int v1197_4_label = 1; v1197_4_label <= 2; ++v1197_4_label) {
    const Space v1197_4_tail = child(s0,v1197_4_label);
    if (v1197_4_tail.empty()) continue;
    const Path v1197_4_head{v1197_4_label};
    const Space v1198_2 = Space{};
    v1197_4_result = unite(v1197_4_result,v1198_2);
  }
  const Space v1197_4 = std::move(v1197_4_result);
  return v1197_4;
}

static Space routine_145(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1199_6 = unwrap(s1,constant_7);
  const Space v1199_8 = unwrap(v1199_6,constant_10);
  const Space v1199_9 = unwrap(v1199_8,p0);
  Space v1199_13_result;
  for (int v1199_13_label = 1; v1199_13_label <= 2; ++v1199_13_label) {
    const Space v1199_13_tail = child(s0,v1199_13_label);
    if (v1199_13_tail.empty()) continue;
    const Path v1199_13_head{v1199_13_label};
    const Space v1200_2 = singleton(v1199_13_head);
    const Space v1200_3 = intersect(constant_14,v1200_2);
    const Space v1200_4 = (has_head(v1200_3) ? constant_15 : Space{});
    Space v1200_7;
    if (!v1200_4.empty()) {
      const Space v1201_5 = unwrap(v1199_9,v1199_13_head);
      Space v1201_6_result;
      for (int v1201_6_label = 1; v1201_6_label <= 2; ++v1201_6_label) {
        const Space v1201_6_tail = child(v1201_5,v1201_6_label);
        if (v1201_6_tail.empty()) continue;
        const Path v1201_6_head{v1201_6_label};
        const Space v1202_2 = singleton(v1201_6_head);
        const Space v1202_3 = intersect(constant_14,v1202_2);
        const Space v1202_4 = (has_head(v1202_3) ? constant_15 : Space{});
        const Space v1202_5 = subtract(constant_0,v1202_4);
        Space v1202_7;
        if (!v1202_5.empty()) {
          const Space v1203_6 = routine_87(c, v1201_6_head, p1, v1201_6_tail);
          v1202_7 = compose(v1202_5,v1203_6);
        }
        const Space v1202_8 = intersect(constant_14,v1202_2);
        const Space v1202_9 = (has_head(v1202_8) ? constant_15 : Space{});
        Space v1202_11;
        if (!v1202_9.empty()) {
          const Space v1204_10 = routine_88(c, v1201_6_head, p1, v1201_6_tail);
          v1202_11 = compose(v1202_9,v1204_10);
        }
        const Space v1202_12 = unite(v1202_7,v1202_11);
        v1201_6_result = unite(v1201_6_result,v1202_12);
      }
      const Space v1201_6 = std::move(v1201_6_result);
      v1200_7 = compose(v1200_4,v1201_6);
    }
    v1199_13_result = unite(v1199_13_result,v1200_7);
  }
  const Space v1199_13 = std::move(v1199_13_result);
  return v1199_13;
}

static Space routine_146(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1205_12_result;
  for (int v1205_12_label = 1; v1205_12_label <= 2; ++v1205_12_label) {
    const Space v1205_12_tail = child(s0,v1205_12_label);
    if (v1205_12_tail.empty()) continue;
    const Path v1205_12_head{v1205_12_label};
    const Space v1206_2 = singleton(v1205_12_head);
    const Space v1206_3 = intersect(constant_14,v1206_2);
    const Space v1206_4 = (has_head(v1206_3) ? constant_15 : Space{});
    const Space v1206_5 = subtract(constant_0,v1206_4);
    Space v1206_8;
    if (!v1206_5.empty()) {
      const Path v1207_6 = concat_path(p0,v1205_12_head);
      Space v1207_7_result;
      for (int v1207_7_label = 1; v1207_7_label <= 2; ++v1207_7_label) {
        const Space v1207_7_tail = child(v1205_12_tail,v1207_7_label);
        if (v1207_7_tail.empty()) continue;
        const Path v1207_7_head{v1207_7_label};
        const Space v1208_2 = singleton(v1207_7_head);
        const Space v1208_3 = intersect(constant_14,v1208_2);
        const Space v1208_4 = (has_head(v1208_3) ? constant_15 : Space{});
        const Space v1208_5 = subtract(constant_0,v1208_4);
        Space v1208_8;
        if (!v1208_5.empty()) {
          const Path v1209_6 = concat_path(v1207_6,v1207_7_head);
          const Space v1209_7 = routine_154(c, v1209_6, p1, v1207_7_tail);
          v1208_8 = compose(v1208_5,v1209_7);
        }
        const Space v1208_9 = intersect(constant_14,v1208_2);
        const Space v1208_10 = (has_head(v1208_9) ? constant_15 : Space{});
        Space v1208_12;
        if (!v1208_10.empty()) {
          const Path v1210_6 = concat_path(v1207_6,v1207_7_head);
          const Space v1210_11 = routine_155(c, v1210_6, p1, v1207_7_tail);
          v1208_12 = compose(v1208_10,v1210_11);
        }
        const Space v1208_13 = unite(v1208_8,v1208_12);
        v1207_7_result = unite(v1207_7_result,v1208_13);
      }
      const Space v1207_7 = std::move(v1207_7_result);
      v1206_8 = compose(v1206_5,v1207_7);
    }
    const Space v1206_9 = intersect(constant_14,v1206_2);
    const Space v1206_10 = (has_head(v1206_9) ? constant_15 : Space{});
    Space v1206_12;
    if (!v1206_10.empty()) {
      const Path v1211_6 = concat_path(p0,v1205_12_head);
      Space v1211_11_result;
      for (int v1211_11_label = 1; v1211_11_label <= 2; ++v1211_11_label) {
        const Space v1211_11_tail = child(v1205_12_tail,v1211_11_label);
        if (v1211_11_tail.empty()) continue;
        const Path v1211_11_head{v1211_11_label};
        const Space v1212_2 = singleton(v1211_11_head);
        const Space v1212_3 = intersect(constant_14,v1212_2);
        const Space v1212_4 = (has_head(v1212_3) ? constant_15 : Space{});
        const Space v1212_5 = subtract(constant_0,v1212_4);
        Space v1212_8;
        if (!v1212_5.empty()) {
          const Path v1213_6 = concat_path(v1211_6,v1211_11_head);
          const Space v1213_7 = routine_154(c, v1213_6, p1, v1211_11_tail);
          v1212_8 = compose(v1212_5,v1213_7);
        }
        const Space v1212_9 = intersect(constant_14,v1212_2);
        const Space v1212_10 = (has_head(v1212_9) ? constant_15 : Space{});
        Space v1212_12;
        if (!v1212_10.empty()) {
          const Path v1214_6 = concat_path(v1211_6,v1211_11_head);
          const Space v1214_11 = routine_93(c, v1214_6, p1, v1211_11_tail);
          v1212_12 = compose(v1212_10,v1214_11);
        }
        const Space v1212_13 = unite(v1212_8,v1212_12);
        v1211_11_result = unite(v1211_11_result,v1212_13);
      }
      const Space v1211_11 = std::move(v1211_11_result);
      v1206_12 = compose(v1206_10,v1211_11);
    }
    const Space v1206_13 = unite(v1206_8,v1206_12);
    v1205_12_result = unite(v1205_12_result,v1206_13);
  }
  const Space v1205_12 = std::move(v1205_12_result);
  return v1205_12;
}

static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1215_9_result;
  for (int v1215_9_label = 1; v1215_9_label <= 2; ++v1215_9_label) {
    const Space v1215_9_tail = child(s0,v1215_9_label);
    if (v1215_9_tail.empty()) continue;
    const Path v1215_9_head{v1215_9_label};
    const Space v1216_2 = singleton(v1215_9_head);
    const Space v1216_3 = intersect(constant_14,v1216_2);
    const Space v1216_4 = (has_head(v1216_3) ? constant_15 : Space{});
    const Space v1216_5 = subtract(constant_0,v1216_4);
    Space v1216_8;
    if (!v1216_5.empty()) {
      const Path v1217_6 = concat_path(p0,v1215_9_head);
      Space v1217_7_result;
      for (int v1217_7_label = 1; v1217_7_label <= 2; ++v1217_7_label) {
        const Space v1217_7_tail = child(v1215_9_tail,v1217_7_label);
        if (v1217_7_tail.empty()) continue;
        const Path v1217_7_head{v1217_7_label};
        const Space v1218_2 = singleton(v1217_7_head);
        const Space v1218_3 = intersect(constant_14,v1218_2);
        const Space v1218_4 = (has_head(v1218_3) ? constant_15 : Space{});
        const Space v1218_5 = subtract(constant_0,v1218_4);
        Space v1218_8;
        if (!v1218_5.empty()) {
          const Path v1219_6 = concat_path(v1217_6,v1217_7_head);
          const Space v1219_7 = routine_154(c, v1219_6, p1, v1217_7_tail);
          v1218_8 = compose(v1218_5,v1219_7);
        }
        const Space v1218_9 = intersect(constant_14,v1218_2);
        const Space v1218_10 = (has_head(v1218_9) ? constant_15 : Space{});
        Space v1218_12;
        if (!v1218_10.empty()) {
          const Path v1220_6 = concat_path(v1217_6,v1217_7_head);
          const Space v1220_11 = routine_155(c, v1220_6, p1, v1217_7_tail);
          v1218_12 = compose(v1218_10,v1220_11);
        }
        const Space v1218_13 = unite(v1218_8,v1218_12);
        v1217_7_result = unite(v1217_7_result,v1218_13);
      }
      const Space v1217_7 = std::move(v1217_7_result);
      v1216_8 = compose(v1216_5,v1217_7);
    }
    const Space v1216_9 = intersect(constant_14,v1216_2);
    const Space v1216_10 = (has_head(v1216_9) ? constant_15 : Space{});
    const Space v1216_11 = compose(v1216_10,v1215_9_tail);
    const Path v1221_6 = concat_path(p0,v1215_9_head);
    const Space v1216_12 = wrap(v1216_11,v1221_6);
    const Space v1216_13 = wrap(v1216_12,p1);
    const Space v1216_14 = unite(v1216_8,v1216_13);
    v1215_9_result = unite(v1215_9_result,v1216_14);
  }
  const Space v1215_9 = std::move(v1215_9_result);
  return v1215_9;
}

static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1222_7_result;
  for (int v1222_7_label = 1; v1222_7_label <= 2; ++v1222_7_label) {
    const Space v1222_7_tail = child(s0,v1222_7_label);
    if (v1222_7_tail.empty()) continue;
    const Path v1222_7_head{v1222_7_label};
    const Space v1223_2 = singleton(v1222_7_head);
    const Space v1223_3 = intersect(constant_14,v1223_2);
    const Space v1223_4 = (has_head(v1223_3) ? constant_15 : Space{});
    const Space v1223_5 = subtract(constant_0,v1223_4);
    Space v1223_6_result;
    for (int v1223_6_label = 1; v1223_6_label <= 2; ++v1223_6_label) {
      const Space v1223_6_tail = child(v1222_7_tail,v1223_6_label);
      if (v1223_6_tail.empty()) continue;
      const Path v1223_6_head{v1223_6_label};
      const Space v1224_2 = Space{};
      v1223_6_result = unite(v1223_6_result,v1224_2);
    }
    const Space v1223_6 = std::move(v1223_6_result);
    const Space v1223_7 = compose(v1223_5,v1223_6);
    const Space v1223_8 = intersect(constant_14,v1223_2);
    const Space v1223_9 = (has_head(v1223_8) ? constant_15 : Space{});
    Space v1223_12;
    if (!v1223_9.empty()) {
      const Path v1225_10 = concat_path(p0,v1222_7_head);
      Space v1225_11_result;
      for (int v1225_11_label = 1; v1225_11_label <= 2; ++v1225_11_label) {
        const Space v1225_11_tail = child(v1222_7_tail,v1225_11_label);
        if (v1225_11_tail.empty()) continue;
        const Path v1225_11_head{v1225_11_label};
        const Space v1226_2 = singleton(v1225_11_head);
        const Space v1226_3 = intersect(constant_14,v1226_2);
        const Space v1226_4 = (has_head(v1226_3) ? constant_15 : Space{});
        Space v1226_7;
        if (!v1226_4.empty()) {
          const Path v1227_5 = concat_path(v1225_10,v1225_11_head);
          const Space v1227_6 = routine_93(c, v1227_5, p1, v1225_11_tail);
          v1226_7 = compose(v1226_4,v1227_6);
        }
        v1225_11_result = unite(v1225_11_result,v1226_7);
      }
      const Space v1225_11 = std::move(v1225_11_result);
      v1223_12 = compose(v1223_9,v1225_11);
    }
    const Space v1223_13 = unite(v1223_7,v1223_12);
    v1222_7_result = unite(v1222_7_result,v1223_13);
  }
  const Space v1222_7 = std::move(v1222_7_result);
  return v1222_7;
}

static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1228_6_result;
  for (int v1228_6_label = 1; v1228_6_label <= 2; ++v1228_6_label) {
    const Space v1228_6_tail = child(s0,v1228_6_label);
    if (v1228_6_tail.empty()) continue;
    const Path v1228_6_head{v1228_6_label};
    const Space v1229_2 = singleton(v1228_6_head);
    const Space v1229_3 = intersect(constant_14,v1229_2);
    const Space v1229_4 = (has_head(v1229_3) ? constant_15 : Space{});
    const Space v1229_5 = subtract(constant_0,v1229_4);
    Space v1229_6_result;
    for (int v1229_6_label = 1; v1229_6_label <= 2; ++v1229_6_label) {
      const Space v1229_6_tail = child(v1228_6_tail,v1229_6_label);
      if (v1229_6_tail.empty()) continue;
      const Path v1229_6_head{v1229_6_label};
      const Space v1230_2 = Space{};
      v1229_6_result = unite(v1229_6_result,v1230_2);
    }
    const Space v1229_6 = std::move(v1229_6_result);
    const Space v1229_7 = compose(v1229_5,v1229_6);
    const Space v1229_8 = intersect(constant_14,v1229_2);
    const Space v1229_9 = (has_head(v1229_8) ? constant_15 : Space{});
    const Space v1229_10 = compose(v1229_9,v1228_6_tail);
    const Path v1229_11 = concat_path(p0,v1228_6_head);
    const Space v1229_12 = wrap(v1229_10,v1229_11);
    const Space v1229_13 = wrap(v1229_12,p1);
    const Space v1229_14 = unite(v1229_7,v1229_13);
    v1228_6_result = unite(v1228_6_result,v1229_14);
  }
  const Space v1228_6 = std::move(v1228_6_result);
  return v1228_6;
}

static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1231_3_result;
  for (int v1231_3_label = 1; v1231_3_label <= 2; ++v1231_3_label) {
    const Space v1231_3_tail = child(s0,v1231_3_label);
    if (v1231_3_tail.empty()) continue;
    const Path v1231_3_head{v1231_3_label};
    const Space v1232_2 = Space{};
    v1231_3_result = unite(v1231_3_result,v1232_2);
  }
  const Space v1231_3 = std::move(v1231_3_result);
  return v1231_3;
}

static Space routine_151(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1233_4_result;
  for (int v1233_4_label = 1; v1233_4_label <= 2; ++v1233_4_label) {
    const Space v1233_4_tail = child(s0,v1233_4_label);
    if (v1233_4_tail.empty()) continue;
    const Path v1233_4_head{v1233_4_label};
    const Space v1234_2 = singleton(v1233_4_head);
    const Space v1234_3 = intersect(constant_14,v1234_2);
    const Space v1234_4 = (has_head(v1234_3) ? constant_15 : Space{});
    const Space v1234_5 = compose(v1234_4,v1233_4_tail);
    const Path v1234_6 = concat_path(p0,v1233_4_head);
    const Space v1234_7 = wrap(v1234_5,v1234_6);
    v1233_4_result = unite(v1233_4_result,v1234_7);
  }
  const Space v1233_4 = std::move(v1233_4_result);
  const Space v1233_5 = wrap(v1233_4,p1);
  return v1233_5;
}

static Space routine_152(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1235_3_result;
  for (int v1235_3_label = 1; v1235_3_label <= 2; ++v1235_3_label) {
    const Space v1235_3_tail = child(s0,v1235_3_label);
    if (v1235_3_tail.empty()) continue;
    const Path v1235_3_head{v1235_3_label};
    const Space v1236_2 = Space{};
    v1235_3_result = unite(v1235_3_result,v1236_2);
  }
  const Space v1235_3 = std::move(v1235_3_result);
  return v1235_3;
}

static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1237_4_result;
  for (int v1237_4_label = 1; v1237_4_label <= 2; ++v1237_4_label) {
    const Space v1237_4_tail = child(s0,v1237_4_label);
    if (v1237_4_tail.empty()) continue;
    const Path v1237_4_head{v1237_4_label};
    const Space v1238_2 = singleton(v1237_4_head);
    const Space v1238_3 = intersect(constant_14,v1238_2);
    const Space v1238_4 = (has_head(v1238_3) ? constant_15 : Space{});
    const Space v1238_5 = compose(v1238_4,v1237_4_tail);
    const Path v1238_6 = concat_path(p0,v1237_4_head);
    const Space v1238_7 = wrap(v1238_5,v1238_6);
    v1237_4_result = unite(v1237_4_result,v1238_7);
  }
  const Space v1237_4 = std::move(v1237_4_result);
  const Space v1237_5 = wrap(v1237_4,p1);
  return v1237_5;
}

static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1239_3_result;
  for (int v1239_3_label = 1; v1239_3_label <= 2; ++v1239_3_label) {
    const Space v1239_3_tail = child(s0,v1239_3_label);
    if (v1239_3_tail.empty()) continue;
    const Path v1239_3_head{v1239_3_label};
    const Space v1240_2 = Space{};
    v1239_3_result = unite(v1239_3_result,v1240_2);
  }
  const Space v1239_3 = std::move(v1239_3_result);
  return v1239_3;
}

static Space routine_155(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1241_4_result;
  for (int v1241_4_label = 1; v1241_4_label <= 2; ++v1241_4_label) {
    const Space v1241_4_tail = child(s0,v1241_4_label);
    if (v1241_4_tail.empty()) continue;
    const Path v1241_4_head{v1241_4_label};
    const Space v1242_2 = singleton(v1241_4_head);
    const Space v1242_3 = intersect(constant_14,v1242_2);
    const Space v1242_4 = (has_head(v1242_3) ? constant_15 : Space{});
    const Space v1242_5 = compose(v1242_4,v1241_4_tail);
    const Path v1242_6 = concat_path(p0,v1241_4_head);
    const Space v1242_7 = wrap(v1242_5,v1242_6);
    v1241_4_result = unite(v1241_4_result,v1242_7);
  }
  const Space v1241_4 = std::move(v1241_4_result);
  const Space v1241_5 = wrap(v1241_4,p1);
  return v1241_5;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
