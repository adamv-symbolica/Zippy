#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
using namespace zippy;
namespace program_0 {
static const Space constant_0 = literal_text("1 0 ");
static const Path constant_1 = Path{1};
static const Space constant_2 = literal_text("77 13 1 1 1 1 1 2 2 1 1 1 1 2 2 12 1 1 1 1 1 2 2 1 1 1 2 2 14 1 1 1 1 1 2 2 1 1 2 1 1 2 2 14 1 1 1 1 1 2 2 1 2 1 1 1 2 2 15 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 14 1 1 1 1 1 2 2 2 1 1 1 1 2 2 14 1 1 1 1 1 2 2 2 1 2 1 1 2 2 13 1 1 1 1 1 2 2 2 1 2 1 2 2 14 1 1 1 1 2 2 1 1 2 1 1 1 2 2 12 1 1 1 1 2 2 1 1 2 1 2 2 14 1 1 1 1 2 2 1 2 1 1 1 1 2 2 13 1 1 1 1 2 2 1 2 1 1 1 2 2 14 1 1 1 1 2 2 2 1 1 1 1 1 2 2 13 1 1 1 1 2 2 2 1 1 1 1 2 2 12 1 1 1 1 2 2 2 1 1 1 2 2 13 1 1 1 1 2 2 2 1 2 1 1 2 2 13 1 1 1 2 2 1 1 1 1 1 1 2 2 12 1 1 1 2 2 1 1 1 1 1 2 2 12 1 1 1 2 2 1 1 1 2 1 2 2 13 1 1 1 2 2 1 1 2 1 1 1 2 2 12 1 1 1 2 2 1 2 1 1 1 2 2 10 1 1 2 1 2 2 1 1 2 2 13 1 1 2 1 2 2 2 1 1 2 1 2 2 11 1 1 2 1 2 2 2 1 1 2 2 10 1 1 2 2 1 1 1 1 2 2 9 1 1 2 2 1 2 1 2 2 9 1 1 2 2 2 1 1 2 2 13 1 2 1 1 1 2 2 1 1 1 1 2 2 12 1 2 1 1 1 2 2 1 1 1 2 2 11 1 2 1 1 1 2 2 1 1 2 2 15 1 2 1 1 1 2 2 1 2 1 1 1 1 2 2 14 1 2 1 1 1 2 2 1 2 1 1 1 2 2 12 1 2 1 1 1 2 2 1 2 1 2 2 14 1 2 1 1 1 2 2 2 1 2 1 1 2 2 9 1 2 1 1 2 2 1 2 2 12 1 2 1 2 2 1 1 1 1 1 2 2 12 1 2 1 2 2 1 1 1 2 1 2 2 10 1 2 1 2 2 1 1 1 2 2 13 1 2 1 2 2 1 1 2 1 1 1 2 2 12 1 2 1 2 2 1 2 1 1 1 2 2 10 1 2 2 1 1 1 1 1 2 2 9 1 2 2 1 1 2 1 2 2 9 1 2 2 1 2 1 1 2 2 9 1 2 2 2 1 1 1 2 2 9 1 2 2 2 1 2 1 2 2 15 2 1 1 1 1 2 2 1 1 1 1 1 1 2 2 13 2 1 1 1 1 2 2 1 1 1 1 2 2 14 2 1 1 1 1 2 2 1 1 2 1 1 2 2 13 2 1 1 1 1 2 2 1 1 2 1 2 2 14 2 1 1 1 1 2 2 1 2 1 2 1 2 2 14 2 1 1 1 1 2 2 2 1 2 1 1 2 2 11 2 1 1 1 1 2 2 2 1 2 2 14 2 1 1 1 2 2 1 1 2 1 1 1 2 2 10 2 1 1 1 2 2 1 1 2 2 12 2 1 1 1 2 2 1 2 1 1 2 2 12 2 1 1 1 2 2 2 1 1 1 2 2 13 2 1 1 1 2 2 2 1 2 1 1 2 2 13 2 1 1 2 2 1 1 1 1 1 1 2 2 9 2 1 1 2 2 1 1 2 2 12 2 1 1 2 2 1 2 1 1 1 2 2 13 2 1 1 2 2 2 1 1 1 1 1 2 2 11 2 1 1 2 2 2 1 1 1 2 2 10 2 1 1 2 2 2 1 1 2 2 13 2 1 1 2 2 2 1 2 1 1 1 2 2 13 2 1 2 1 2 2 1 1 1 1 1 2 2 13 2 1 2 1 2 2 1 2 1 1 1 2 2 13 2 1 2 1 2 2 2 1 1 2 1 2 2 13 2 1 2 1 2 2 2 1 2 1 1 2 2 12 2 1 2 1 2 2 2 1 2 1 2 2 10 2 1 2 1 2 2 2 1 2 2 11 2 1 2 2 1 1 1 1 1 2 2 10 2 1 2 2 1 2 1 1 2 2 11 2 1 2 2 1 2 1 2 1 2 2 7 2 1 2 2 1 2 2 10 2 1 2 2 2 1 2 1 2 2 6 2 2 1 1 2 2 6 2 2 2 1 2 2");
static const Space constant_3 = literal_text("120 16 2 2 1 1 1 1 1 1 2 2 1 1 1 1 2 2 15 2 2 1 1 1 1 1 1 2 2 1 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 1 1 2 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 1 2 1 1 1 2 2 18 2 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 2 1 1 1 1 2 2 17 2 2 1 1 1 1 1 1 2 2 2 1 2 1 1 2 2 16 2 2 1 1 1 1 1 1 2 2 2 1 2 1 2 2 17 2 2 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 15 2 2 1 1 1 1 1 2 2 1 1 2 1 2 2 17 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 16 2 2 1 1 1 1 1 2 2 1 2 1 1 1 2 2 17 2 2 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 16 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 15 2 2 1 1 1 1 1 2 2 2 1 1 1 2 2 16 2 2 1 1 1 1 1 2 2 2 1 2 1 1 2 2 16 2 2 1 1 1 1 2 2 1 1 1 1 1 1 2 2 15 2 2 1 1 1 1 2 2 1 1 1 1 1 2 2 15 2 2 1 1 1 1 2 2 1 1 1 2 1 2 2 16 2 2 1 1 1 1 2 2 1 1 2 1 1 1 2 2 15 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 13 2 2 1 1 1 2 1 2 2 1 1 2 2 16 2 2 1 1 1 2 1 2 2 2 1 1 2 1 2 2 14 2 2 1 1 1 2 1 2 2 2 1 1 2 2 13 2 2 1 1 1 2 2 1 1 1 1 2 2 12 2 2 1 1 1 2 2 1 2 1 2 2 12 2 2 1 1 1 2 2 2 1 1 2 2 16 2 2 1 1 2 1 1 1 2 2 1 1 1 1 2 2 15 2 2 1 1 2 1 1 1 2 2 1 1 1 2 2 14 2 2 1 1 2 1 1 1 2 2 1 1 2 2 18 2 2 1 1 2 1 1 1 2 2 1 2 1 1 1 1 2 2 17 2 2 1 1 2 1 1 1 2 2 1 2 1 1 1 2 2 15 2 2 1 1 2 1 1 1 2 2 1 2 1 2 2 17 2 2 1 1 2 1 1 1 2 2 2 1 2 1 1 2 2 12 2 2 1 1 2 1 1 2 2 1 2 2 15 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 15 2 2 1 1 2 1 2 2 1 1 1 2 1 2 2 13 2 2 1 1 2 1 2 2 1 1 1 2 2 16 2 2 1 1 2 1 2 2 1 1 2 1 1 1 2 2 15 2 2 1 1 2 1 2 2 1 2 1 1 1 2 2 13 2 2 1 1 2 2 1 1 1 1 1 2 2 12 2 2 1 1 2 2 1 1 2 1 2 2 12 2 2 1 1 2 2 1 2 1 1 2 2 12 2 2 1 1 2 2 2 1 1 1 2 2 12 2 2 1 1 2 2 2 1 2 1 2 2 18 2 2 1 2 1 1 1 1 2 2 1 1 1 1 1 1 2 2 16 2 2 1 2 1 1 1 1 2 2 1 1 1 1 2 2 17 2 2 1 2 1 1 1 1 2 2 1 1 2 1 1 2 2 16 2 2 1 2 1 1 1 1 2 2 1 1 2 1 2 2 17 2 2 1 2 1 1 1 1 2 2 1 2 1 2 1 2 2 17 2 2 1 2 1 1 1 1 2 2 2 1 2 1 1 2 2 14 2 2 1 2 1 1 1 1 2 2 2 1 2 2 17 2 2 1 2 1 1 1 2 2 1 1 2 1 1 1 2 2 13 2 2 1 2 1 1 1 2 2 1 1 2 2 15 2 2 1 2 1 1 1 2 2 1 2 1 1 2 2 15 2 2 1 2 1 1 1 2 2 2 1 1 1 2 2 16 2 2 1 2 1 1 1 2 2 2 1 2 1 1 2 2 16 2 2 1 2 1 1 2 2 1 1 1 1 1 1 2 2 12 2 2 1 2 1 1 2 2 1 1 2 2 15 2 2 1 2 1 1 2 2 1 2 1 1 1 2 2 16 2 2 1 2 1 1 2 2 2 1 1 1 1 1 2 2 14 2 2 1 2 1 1 2 2 2 1 1 1 2 2 13 2 2 1 2 1 1 2 2 2 1 1 2 2 16 2 2 1 2 1 1 2 2 2 1 2 1 1 1 2 2 16 2 2 1 2 1 2 1 2 2 1 1 1 1 1 2 2 16 2 2 1 2 1 2 1 2 2 1 2 1 1 1 2 2 16 2 2 1 2 1 2 1 2 2 2 1 1 2 1 2 2 16 2 2 1 2 1 2 1 2 2 2 1 2 1 1 2 2 15 2 2 1 2 1 2 1 2 2 2 1 2 1 2 2 13 2 2 1 2 1 2 1 2 2 2 1 2 2 14 2 2 1 2 1 2 2 1 1 1 1 1 2 2 13 2 2 1 2 1 2 2 1 2 1 1 2 2 14 2 2 1 2 1 2 2 1 2 1 2 1 2 2 10 2 2 1 2 1 2 2 1 2 2 13 2 2 1 2 1 2 2 2 1 2 1 2 2 9 2 2 1 2 2 1 1 2 2 9 2 2 1 2 2 2 1 2 2 17 2 2 2 1 1 1 1 1 2 2 1 1 1 1 1 2 2 17 2 2 2 1 1 1 1 1 2 2 1 1 1 2 1 2 2 18 2 2 2 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 17 2 2 2 1 1 1 1 1 2 2 1 1 2 1 1 2 2 18 2 2 2 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 16 2 2 2 1 1 1 1 1 2 2 1 2 1 1 2 2 17 2 2 2 1 1 1 1 1 2 2 2 1 1 1 1 2 2 16 2 2 2 1 1 1 1 1 2 2 2 1 1 1 2 2 16 2 2 2 1 1 1 1 1 2 2 2 1 2 1 2 2 16 2 2 2 1 1 1 1 2 2 1 1 1 2 1 2 2 14 2 2 2 1 1 1 1 2 2 1 1 1 2 2 17 2 2 2 1 1 1 1 2 2 1 1 2 1 1 1 2 2 16 2 2 2 1 1 1 1 2 2 1 2 1 1 1 2 2 16 2 2 2 1 1 1 1 2 2 2 1 1 2 1 2 2 15 2 2 2 1 1 1 2 2 1 1 1 2 1 2 2 15 2 2 2 1 1 1 2 2 1 1 2 1 1 2 2 15 2 2 2 1 1 1 2 2 2 1 2 1 1 2 2 17 2 2 2 1 1 2 1 2 2 1 1 1 1 1 1 2 2 16 2 2 2 1 1 2 1 2 2 1 1 1 1 1 2 2 17 2 2 2 1 1 2 1 2 2 1 2 1 1 1 1 2 2 16 2 2 2 1 1 2 1 2 2 1 2 1 2 1 2 2 14 2 2 2 1 1 2 1 2 2 2 1 1 2 2 14 2 2 2 1 1 2 2 1 1 1 1 1 2 2 13 2 2 2 1 1 2 2 1 1 1 1 2 2 12 2 2 2 1 1 2 2 1 2 1 2 2 14 2 2 2 1 1 2 2 2 1 1 2 1 2 2 17 2 2 2 1 2 1 1 1 2 2 1 1 1 2 1 2 2 17 2 2 2 1 2 1 1 1 2 2 1 1 2 1 1 2 2 18 2 2 2 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 15 2 2 2 1 2 1 1 2 2 1 2 1 1 2 2 16 2 2 2 1 2 1 1 2 2 2 1 1 1 1 2 2 16 2 2 2 1 2 1 1 2 2 2 1 1 2 1 2 2 14 2 2 2 1 2 1 2 2 1 1 1 1 2 2 15 2 2 2 1 2 1 2 2 1 1 1 2 1 2 2 13 2 2 2 1 2 1 2 2 1 1 1 2 2 16 2 2 2 1 2 1 2 2 1 2 1 1 1 1 2 2 13 2 2 2 1 2 1 2 2 1 2 1 2 2 14 2 2 2 1 2 1 2 2 2 1 2 1 2 2 12 2 2 2 1 2 2 1 1 2 1 2 2 13 2 2 2 1 2 2 1 2 1 1 1 2 2 13 2 2 2 1 2 2 2 1 1 1 1 2 2 12 2 2 2 1 2 2 2 1 1 1 2 2 10 2 2 2 1 2 2 2 1 2 2");
static const Path constant_4 = Path{2};
static const Space constant_5 = literal_text("43 14 1 1 1 1 1 2 2 1 1 1 1 1 2 2 14 1 1 1 1 1 2 2 1 1 1 2 1 2 2 15 1 1 1 1 1 2 2 1 1 2 1 1 1 2 2 14 1 1 1 1 1 2 2 1 1 2 1 1 2 2 15 1 1 1 1 1 2 2 1 2 1 1 1 1 2 2 13 1 1 1 1 1 2 2 1 2 1 1 2 2 14 1 1 1 1 1 2 2 2 1 1 1 1 2 2 13 1 1 1 1 1 2 2 2 1 1 1 2 2 13 1 1 1 1 1 2 2 2 1 2 1 2 2 13 1 1 1 1 2 2 1 1 1 2 1 2 2 11 1 1 1 1 2 2 1 1 1 2 2 14 1 1 1 1 2 2 1 1 2 1 1 1 2 2 13 1 1 1 1 2 2 1 2 1 1 1 2 2 13 1 1 1 1 2 2 2 1 1 2 1 2 2 12 1 1 1 2 2 1 1 1 2 1 2 2 12 1 1 1 2 2 1 1 2 1 1 2 2 12 1 1 1 2 2 2 1 2 1 1 2 2 14 1 1 2 1 2 2 1 1 1 1 1 1 2 2 13 1 1 2 1 2 2 1 1 1 1 1 2 2 14 1 1 2 1 2 2 1 2 1 1 1 1 2 2 13 1 1 2 1 2 2 1 2 1 2 1 2 2 11 1 1 2 1 2 2 2 1 1 2 2 11 1 1 2 2 1 1 1 1 1 2 2 10 1 1 2 2 1 1 1 1 2 2 9 1 1 2 2 1 2 1 2 2 11 1 1 2 2 2 1 1 2 1 2 2 14 1 2 1 1 1 2 2 1 1 1 2 1 2 2 14 1 2 1 1 1 2 2 1 1 2 1 1 2 2 15 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 12 1 2 1 1 2 2 1 2 1 1 2 2 13 1 2 1 1 2 2 2 1 1 1 1 2 2 13 1 2 1 1 2 2 2 1 1 2 1 2 2 11 1 2 1 2 2 1 1 1 1 2 2 12 1 2 1 2 2 1 1 1 2 1 2 2 10 1 2 1 2 2 1 1 1 2 2 13 1 2 1 2 2 1 2 1 1 1 1 2 2 10 1 2 1 2 2 1 2 1 2 2 11 1 2 1 2 2 2 1 2 1 2 2 9 1 2 2 1 1 2 1 2 2 10 1 2 2 1 2 1 1 1 2 2 10 1 2 2 2 1 1 1 1 2 2 9 1 2 2 2 1 1 1 2 2 7 1 2 2 2 1 2 2");
static const Space constant_6 = literal_text("1 1 2");
static const Space constant_7 = singleton(Path{});
static const Path constant_8 = Path{2,2};
static const Space constant_9 = literal_text("1 11 1 2 1 1 2 1 1 2 1 2 2");
static const Path constant_10 = Path{};
static const std::vector<Path> constant_11 = paths_text("133 8 1 1 1 2 1 1 2 2 8 1 2 1 2 1 1 2 2 8 1 1 1 1 2 1 2 2 8 2 1 1 1 2 1 2 2 8 1 2 1 1 2 1 2 2 8 1 1 2 1 2 1 2 2 8 2 1 2 1 2 1 2 2 9 1 1 1 1 1 1 1 2 2 9 2 1 1 1 1 1 1 2 2 9 1 2 1 1 1 1 1 2 2 9 1 1 2 1 1 1 1 2 2 8 2 1 1 2 1 1 2 2 9 2 1 2 1 1 1 1 2 2 9 2 1 1 2 1 1 1 2 2 9 1 2 1 2 1 1 1 2 2 9 1 1 1 1 2 1 1 2 2 9 2 1 1 1 2 1 1 2 2 9 1 2 1 1 2 1 1 2 2 9 1 1 2 1 2 1 1 2 2 9 2 1 2 1 2 1 1 2 2 9 1 1 1 1 1 2 1 2 2 9 2 1 1 1 1 2 1 2 2 9 1 1 1 2 1 1 1 2 2 9 1 2 1 1 1 2 1 2 2 9 2 1 2 1 1 2 1 2 2 9 1 1 1 2 1 2 1 2 2 9 2 1 1 2 1 2 1 2 2 9 1 2 1 2 1 2 1 2 2 10 1 1 1 1 1 1 1 1 2 2 10 2 1 1 1 1 1 1 1 2 2 10 1 2 1 1 1 1 1 1 2 2 10 1 1 2 1 1 1 1 1 2 2 10 2 1 2 1 1 1 1 1 2 2 9 1 1 2 1 1 2 1 2 2 10 1 1 1 2 1 1 1 1 2 2 10 1 2 1 2 1 1 1 1 2 2 10 1 1 1 1 2 1 1 1 2 2 10 2 1 1 1 2 1 1 1 2 2 10 1 2 1 1 2 1 1 1 2 2 10 1 1 2 1 2 1 1 1 2 2 10 2 1 2 1 2 1 1 1 2 2 10 1 1 1 1 1 2 1 1 2 2 10 2 1 1 1 1 2 1 1 2 2 10 1 2 1 1 1 2 1 1 2 2 10 2 1 1 2 1 1 1 1 2 2 10 1 1 2 1 1 2 1 1 2 2 10 1 1 1 2 1 2 1 1 2 2 10 2 1 1 2 1 2 1 1 2 2 10 1 2 1 2 1 2 1 1 2 2 10 1 1 1 1 1 1 2 1 2 2 10 2 1 1 1 1 1 2 1 2 2 10 1 2 1 1 1 1 2 1 2 2 10 1 1 2 1 1 1 2 1 2 2 10 2 1 2 1 1 1 2 1 2 2 10 1 1 1 2 1 1 2 1 2 2 10 2 1 2 1 1 2 1 1 2 2 10 2 1 1 2 1 1 2 1 2 2 10 1 1 1 1 2 1 2 1 2 2 10 2 1 1 1 2 1 2 1 2 2 10 1 2 1 1 2 1 2 1 2 2 10 1 1 2 1 2 1 2 1 2 2 10 2 1 2 1 2 1 2 1 2 2 10 1 2 1 2 1 1 2 1 2 2 11 1 1 1 1 1 1 1 1 1 2 2 11 2 1 1 1 1 1 1 1 1 2 2 3 1 2 2 5 1 1 1 2 2 4 1 1 2 2 4 2 1 2 2 6 2 1 1 1 2 2 5 2 1 1 2 2 5 1 2 1 2 2 8 1 1 1 1 1 1 2 2 7 1 1 2 1 1 2 2 8 2 1 1 1 1 1 2 2 6 1 2 1 1 2 2 7 2 1 2 1 1 2 2 7 1 1 1 2 1 2 2 6 1 1 1 1 2 2 7 2 1 1 2 1 2 2 8 2 1 2 1 1 1 2 2 6 1 1 2 1 2 2 11 1 2 1 1 1 1 1 1 1 2 2 11 1 1 2 1 1 1 1 1 1 2 2 11 2 1 2 1 1 1 1 1 1 2 2 11 1 1 1 2 1 1 1 1 1 2 2 11 2 1 1 2 1 1 1 1 1 2 2 11 1 2 1 2 1 1 1 1 1 2 2 7 2 1 1 1 1 2 2 11 1 1 1 1 2 1 1 1 1 2 2 11 2 1 1 1 2 1 1 1 1 2 2 11 1 2 1 1 2 1 1 1 1 2 2 11 1 1 2 1 2 1 1 1 1 2 2 11 2 1 2 1 2 1 1 1 1 2 2 11 1 1 1 1 1 2 1 1 1 2 2 11 2 1 1 1 1 2 1 1 1 2 2 11 1 2 1 1 1 2 1 1 1 2 2 11 1 1 2 1 1 2 1 1 1 2 2 11 2 1 2 1 1 2 1 1 1 2 2 8 1 2 1 1 1 1 2 2 11 1 1 1 2 1 2 1 1 1 2 2 11 2 1 1 2 1 2 1 1 1 2 2 11 1 2 1 2 1 2 1 1 1 2 2 11 1 1 1 1 1 1 2 1 1 2 2 11 2 1 1 1 1 1 2 1 1 2 2 11 1 2 1 1 1 1 2 1 1 2 2 11 1 1 2 1 1 1 2 1 1 2 2 11 2 1 2 1 1 1 2 1 1 2 2 11 1 1 1 2 1 1 2 1 1 2 2 11 2 1 1 2 1 1 2 1 1 2 2 7 1 2 1 1 1 2 2 11 1 2 1 2 1 1 2 1 1 2 2 11 1 1 1 1 2 1 2 1 1 2 2 11 2 1 1 1 2 1 2 1 1 2 2 11 1 2 1 1 2 1 2 1 1 2 2 11 1 1 2 1 2 1 2 1 1 2 2 11 2 1 2 1 2 1 2 1 1 2 2 11 1 1 1 1 1 1 1 2 1 2 2 11 2 1 1 1 1 1 1 2 1 2 2 11 1 2 1 1 1 1 1 2 1 2 2 11 1 1 2 1 1 1 1 2 1 2 2 6 2 1 2 1 2 2 11 2 1 2 1 1 1 1 2 1 2 2 11 1 1 1 2 1 1 1 2 1 2 2 11 2 1 1 2 1 1 1 2 1 2 2 11 1 2 1 2 1 1 1 2 1 2 2 11 1 1 1 1 2 1 1 2 1 2 2 11 2 1 1 1 2 1 1 2 1 2 2 8 1 1 2 1 1 1 2 2 7 1 2 1 2 1 2 2 7 1 1 1 1 1 2 2 2 2 2 11 1 2 1 1 2 1 1 2 1 2 2");
static const Space constant_12 = literal_text("387 22 1 1 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 1 1 2 2 21 1 1 1 1 1 1 1 1 1 2 2 1 2 1 2 1 1 2 1 2 2 22 1 1 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 1 2 2 20 1 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 1 2 2 19 1 1 1 1 1 1 1 1 2 2 1 2 1 2 1 2 1 2 2 20 1 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 2 2 22 1 1 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 1 2 1 2 2 22 1 1 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 1 2 1 2 2 22 1 1 1 1 1 1 1 2 1 2 2 2 1 2 1 2 1 2 1 1 2 2 18 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 2 2 18 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 2 2 17 1 1 1 1 1 1 1 2 2 2 1 2 1 2 1 2 2 22 1 1 1 1 1 1 2 1 1 2 2 1 1 1 1 1 1 2 1 1 2 2 22 1 1 1 1 1 1 2 1 1 2 2 1 2 1 2 1 2 1 1 1 2 2 22 1 1 1 1 1 1 2 1 1 2 2 2 1 1 1 1 1 2 1 1 2 2 20 1 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 2 1 2 2 20 1 1 1 1 1 1 2 1 2 2 1 2 1 2 1 2 1 1 2 2 20 1 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 2 1 2 2 16 1 1 1 1 1 1 2 2 1 1 1 1 1 1 2 2 15 1 1 1 1 1 1 2 2 1 1 2 1 1 2 2 13 1 1 1 1 1 1 2 2 1 2 1 2 2 22 1 1 1 1 1 2 1 1 1 2 2 1 1 1 1 1 2 1 1 1 2 2 22 1 1 1 1 1 2 1 1 1 2 2 2 1 1 1 1 2 1 1 1 2 2 22 1 1 1 1 1 2 1 1 1 2 2 2 1 2 1 2 1 1 1 1 2 2 20 1 1 1 1 1 2 1 1 2 2 1 1 1 1 1 2 1 1 2 2 20 1 1 1 1 1 2 1 1 2 2 2 1 1 1 1 2 1 1 2 2 20 1 1 1 1 1 2 1 1 2 2 2 1 2 1 2 1 1 1 2 2 18 1 1 1 1 1 2 1 2 2 1 1 1 1 1 2 1 2 2 18 1 1 1 1 1 2 1 2 2 2 1 1 1 1 2 1 2 2 18 1 1 1 1 1 2 1 2 2 2 1 2 1 2 1 1 2 2 14 1 1 1 1 1 2 2 1 1 1 1 1 2 2 11 1 1 1 1 1 2 2 1 1 2 2 14 1 1 1 1 1 2 2 1 2 1 2 1 2 2 22 1 1 1 1 2 1 1 1 1 2 2 1 1 1 1 2 1 1 1 1 2 2 22 1 1 1 1 2 1 1 1 1 2 2 1 2 1 2 1 1 1 1 1 2 2 22 1 1 1 1 2 1 1 1 1 2 2 2 1 1 1 2 1 1 1 1 2 2 20 1 1 1 1 2 1 1 1 2 2 1 1 1 1 2 1 1 1 2 2 20 1 1 1 1 2 1 1 1 2 2 1 2 1 2 1 1 1 1 2 2 20 1 1 1 1 2 1 1 1 2 2 2 1 1 1 2 1 1 1 2 2 22 1 1 1 1 2 1 1 2 1 2 2 1 1 1 1 2 1 1 2 1 2 2 22 1 1 1 1 2 1 1 2 1 2 2 1 2 1 2 1 1 1 2 1 2 2 22 1 1 1 1 2 1 1 2 1 2 2 2 1 1 1 2 1 1 2 1 2 2 18 1 1 1 1 2 1 1 2 2 1 1 1 1 2 1 1 2 2 18 1 1 1 1 2 1 1 2 2 1 2 1 2 1 1 1 2 2 18 1 1 1 1 2 1 1 2 2 2 1 1 1 2 1 1 2 2 22 1 1 1 1 2 1 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 22 1 1 1 1 2 1 2 1 1 2 2 1 2 1 2 1 1 2 1 1 2 2 22 1 1 1 1 2 1 2 1 1 2 2 2 1 1 1 2 1 2 1 1 2 2 20 1 1 1 1 2 1 2 1 2 2 1 1 1 1 2 1 2 1 2 2 20 1 1 1 1 2 1 2 1 2 2 2 1 1 1 2 1 2 1 2 2 20 1 1 1 1 2 1 2 1 2 2 2 1 1 2 1 1 2 1 2 2 16 1 1 1 1 2 1 2 2 1 1 1 1 2 1 2 2 16 1 1 1 1 2 1 2 2 1 2 1 2 1 1 2 2 16 1 1 1 1 2 1 2 2 2 1 1 1 2 1 2 2 12 1 1 1 1 2 2 1 1 1 1 2 2 13 1 1 1 1 2 2 2 1 1 2 1 2 2 13 1 1 1 1 2 2 2 1 2 1 1 2 2 22 1 1 1 2 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 1 2 2 22 1 1 1 2 1 1 1 1 1 2 2 2 1 1 2 1 1 1 1 1 2 2 22 1 1 1 2 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 1 2 2 20 1 1 1 2 1 1 1 1 2 2 1 1 1 2 1 1 1 1 2 2 20 1 1 1 2 1 1 1 1 2 2 1 2 1 2 1 1 1 1 2 2 20 1 1 1 2 1 1 1 1 2 2 2 1 2 1 1 1 1 1 2 2 22 1 1 1 2 1 1 1 2 1 2 2 1 1 1 2 1 1 1 2 1 2 2 22 1 1 1 2 1 1 1 2 1 2 2 2 1 1 2 1 1 1 2 1 2 2 22 1 1 1 2 1 1 1 2 1 2 2 2 1 2 1 1 1 1 2 1 2 2 18 1 1 1 2 1 1 1 2 2 1 1 1 2 1 1 1 2 2 18 1 1 1 2 1 1 1 2 2 1 1 2 1 1 2 1 2 2 17 1 1 1 2 1 1 1 2 2 2 1 1 2 1 1 2 2 22 1 1 1 2 1 1 2 1 1 2 2 1 1 1 2 1 1 2 1 1 2 2 22 1 1 1 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 1 1 2 2 22 1 1 1 2 1 1 2 1 1 2 2 2 1 2 1 1 1 2 1 1 2 2 20 1 1 1 2 1 1 2 1 2 2 1 1 1 2 1 1 2 1 2 2 20 1 1 1 2 1 1 2 1 2 2 2 1 1 2 1 1 2 1 2 2 20 1 1 1 2 1 1 2 1 2 2 2 1 2 1 1 1 2 1 2 2 16 1 1 1 2 1 1 2 2 1 1 1 2 1 1 2 2 11 1 1 1 2 1 1 2 2 1 2 2 16 1 1 1 2 1 1 2 2 2 1 1 2 1 1 2 2 22 1 1 1 2 1 2 1 1 1 2 2 1 1 1 2 1 2 1 1 1 2 2 22 1 1 1 2 1 2 1 1 1 2 2 2 1 1 2 1 2 1 1 1 2 2 22 1 1 1 2 1 2 1 1 1 2 2 2 1 2 1 1 2 1 1 1 2 2 20 1 1 1 2 1 2 1 1 2 2 1 1 1 2 1 2 1 1 2 2 20 1 1 1 2 1 2 1 1 2 2 1 1 2 1 1 2 1 1 2 2 20 1 1 1 2 1 2 1 1 2 2 2 1 1 2 1 2 1 1 2 2 18 1 1 1 2 1 2 1 2 2 1 1 1 2 1 2 1 2 2 18 1 1 1 2 1 2 1 2 2 2 1 1 2 1 2 1 2 2 18 1 1 1 2 1 2 1 2 2 2 1 2 1 1 2 1 2 2 14 1 1 1 2 1 2 2 1 1 1 2 1 2 2 12 1 1 1 2 1 2 2 1 1 1 2 2 14 1 1 1 2 1 2 2 2 1 1 1 1 2 2 12 1 1 1 2 2 1 1 1 2 1 2 2 10 1 1 1 2 2 1 1 1 2 2 8 1 1 1 2 2 1 2 2 22 1 1 2 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 1 2 2 22 1 1 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 1 2 2 22 1 1 2 1 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 1 2 2 20 1 1 2 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 2 2 20 1 1 2 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 2 2 20 1 1 2 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 2 2 22 1 1 2 1 1 1 1 2 1 2 2 1 1 2 1 1 1 1 2 1 2 2 22 1 1 2 1 1 1 1 2 1 2 2 1 2 1 1 1 1 1 2 1 2 2 22 1 1 2 1 1 1 1 2 1 2 2 2 1 2 1 1 1 1 2 1 2 2 18 1 1 2 1 1 1 1 2 2 1 1 2 1 1 1 1 2 2 18 1 1 2 1 1 1 1 2 2 1 2 1 1 1 1 1 2 2 18 1 1 2 1 1 1 1 2 2 2 1 2 1 1 1 1 2 2 22 1 1 2 1 1 1 2 1 1 2 2 1 1 2 1 1 1 2 1 1 2 2 22 1 1 2 1 1 1 2 1 1 2 2 1 2 1 1 1 1 2 1 1 2 2 22 1 1 2 1 1 1 2 1 1 2 2 2 1 2 1 1 1 2 1 1 2 2 20 1 1 2 1 1 1 2 1 2 2 1 1 2 1 1 1 2 1 2 2 20 1 1 2 1 1 1 2 1 2 2 1 2 1 1 1 1 2 1 2 2 20 1 1 2 1 1 1 2 1 2 2 2 1 2 1 1 1 2 1 2 2 16 1 1 2 1 1 1 2 2 1 1 2 1 1 1 2 2 15 1 1 2 1 1 1 2 2 1 2 1 2 1 2 2 14 1 1 2 1 1 1 2 2 2 1 2 1 2 2 22 1 1 2 1 1 2 1 1 1 2 2 1 1 2 1 1 2 1 1 1 2 2 22 1 1 2 1 1 2 1 1 1 2 2 1 2 1 1 1 2 1 1 1 2 2 22 1 1 2 1 1 2 1 1 1 2 2 2 1 2 1 1 2 1 1 1 2 2 20 1 1 2 1 1 2 1 1 2 2 1 1 1 2 1 2 1 1 2 2 20 1 1 2 1 1 2 1 1 2 2 1 1 2 1 1 2 1 1 2 2 20 1 1 2 1 1 2 1 1 2 2 1 2 1 1 1 2 1 1 2 2 18 1 1 2 1 1 2 1 2 2 1 1 1 2 1 1 1 2 2 18 1 1 2 1 1 2 1 2 2 1 1 2 1 1 2 1 2 2 19 1 1 2 1 1 2 1 2 2 2 1 1 2 1 1 1 1 2 2 15 1 1 2 1 1 2 2 1 1 1 1 1 1 2 2 14 1 1 2 1 1 2 2 1 1 2 1 1 2 2 15 1 1 2 1 1 2 2 2 1 1 1 1 1 2 2 22 1 1 2 1 2 1 1 1 1 2 2 1 1 2 1 2 1 1 1 1 2 2 22 1 1 2 1 2 1 1 1 1 2 2 1 2 1 1 2 1 1 1 1 2 2 22 1 1 2 1 2 1 1 1 1 2 2 2 1 2 1 2 1 1 1 1 2 2 20 1 1 2 1 2 1 1 1 2 2 1 1 2 1 2 1 1 1 2 2 20 1 1 2 1 2 1 1 1 2 2 1 2 1 1 2 1 1 1 2 2 20 1 1 2 1 2 1 1 1 2 2 2 1 2 1 2 1 1 1 2 2 18 1 1 2 1 2 1 1 2 2 1 1 2 1 2 1 1 2 2 18 1 1 2 1 2 1 1 2 2 1 2 1 1 2 1 1 2 2 18 1 1 2 1 2 1 1 2 2 2 1 2 1 2 1 1 2 2 22 1 1 2 1 2 1 2 1 1 2 2 1 1 2 1 2 1 2 1 1 2 2 22 1 1 2 1 2 1 2 1 1 2 2 1 2 1 1 2 1 2 1 1 2 2 22 1 1 2 1 2 1 2 1 1 2 2 2 1 2 1 2 1 2 1 1 2 2 20 1 1 2 1 2 1 2 1 2 2 1 1 2 1 2 1 2 1 2 2 20 1 1 2 1 2 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 20 1 1 2 1 2 1 2 1 2 2 2 1 2 1 2 1 2 1 2 2 16 1 1 2 1 2 1 2 2 1 1 2 1 2 1 2 2 16 1 1 2 1 2 1 2 2 1 2 1 1 2 1 2 2 16 1 1 2 1 2 1 2 2 2 1 2 1 2 1 2 2 12 1 1 2 1 2 2 1 1 2 1 2 2 17 1 1 2 1 2 2 1 2 1 1 1 1 1 1 1 2 2 14 1 1 2 1 2 2 2 1 2 1 1 1 2 2 11 1 1 2 2 1 1 1 1 1 2 2 8 1 1 2 2 1 1 2 2 8 1 1 2 2 2 1 2 2 22 1 2 1 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 1 2 2 17 1 2 1 1 1 1 1 1 1 2 2 1 1 2 1 2 2 22 1 2 1 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 1 2 2 20 1 2 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 2 2 20 1 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 2 2 20 1 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 2 2 22 1 2 1 1 1 1 1 2 1 2 2 1 1 2 1 1 1 1 2 1 2 2 22 1 2 1 1 1 1 1 2 1 2 2 1 2 1 1 1 1 1 2 1 2 2 22 1 2 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 1 2 1 2 2 18 1 2 1 1 1 1 1 2 2 1 1 2 1 1 1 1 2 2 18 1 2 1 1 1 1 1 2 2 1 2 1 1 1 1 1 2 2 18 1 2 1 1 1 1 1 2 2 2 1 1 1 1 1 1 2 2 22 1 2 1 1 1 1 2 1 1 2 2 1 1 2 1 1 1 2 1 1 2 2 22 1 2 1 1 1 1 2 1 1 2 2 1 2 1 1 1 1 2 1 1 2 2 22 1 2 1 1 1 1 2 1 1 2 2 2 1 1 1 1 1 2 1 1 2 2 20 1 2 1 1 1 1 2 1 2 2 1 1 2 1 1 1 2 1 2 2 20 1 2 1 1 1 1 2 1 2 2 1 2 1 1 1 1 2 1 2 2 20 1 2 1 1 1 1 2 1 2 2 2 1 1 1 1 1 2 1 2 2 16 1 2 1 1 1 1 2 2 1 2 1 1 1 1 2 2 15 1 2 1 1 1 1 2 2 1 2 1 1 1 2 2 15 1 2 1 1 1 1 2 2 2 1 1 1 1 2 2 22 1 2 1 1 1 2 1 1 1 2 2 1 1 2 1 1 2 1 1 1 2 2 22 1 2 1 1 1 2 1 1 1 2 2 1 2 1 1 1 2 1 1 1 2 2 22 1 2 1 1 1 2 1 1 1 2 2 2 1 1 1 1 2 1 1 1 2 2 20 1 2 1 1 1 2 1 1 2 2 1 1 2 1 1 2 1 1 2 2 20 1 2 1 1 1 2 1 1 2 2 1 2 1 1 1 2 1 1 2 2 20 1 2 1 1 1 2 1 1 2 2 2 1 1 1 1 2 1 1 2 2 18 1 2 1 1 1 2 1 2 2 1 2 1 1 1 2 1 2 2 18 1 2 1 1 1 2 1 2 2 2 1 1 1 1 2 1 2 2 18 1 2 1 1 1 2 1 2 2 2 1 2 1 1 2 1 2 2 15 1 2 1 1 1 2 2 1 2 1 1 1 1 2 2 14 1 2 1 1 1 2 2 1 2 1 1 1 2 2 13 1 2 1 1 1 2 2 2 1 2 1 2 2 22 1 2 1 1 2 1 1 1 1 2 2 1 1 2 1 2 1 1 1 1 2 2 22 1 2 1 1 2 1 1 1 1 2 2 1 2 1 1 2 1 1 1 1 2 2 22 1 2 1 1 2 1 1 1 1 2 2 2 1 1 1 2 1 1 1 1 2 2 20 1 2 1 1 2 1 1 1 2 2 1 1 2 1 2 1 1 1 2 2 20 1 2 1 1 2 1 1 1 2 2 1 2 1 1 2 1 1 1 2 2 20 1 2 1 1 2 1 1 1 2 2 2 1 1 1 2 1 1 1 2 2 18 1 2 1 1 2 1 1 2 2 1 1 2 1 2 1 1 2 2 18 1 2 1 1 2 1 1 2 2 1 2 1 1 2 1 1 2 2 18 1 2 1 1 2 1 1 2 2 2 1 1 1 2 1 1 2 2 22 1 2 1 1 2 1 2 1 1 2 2 1 1 2 1 2 1 2 1 1 2 2 22 1 2 1 1 2 1 2 1 1 2 2 1 2 1 1 2 1 2 1 1 2 2 22 1 2 1 1 2 1 2 1 1 2 2 2 1 1 1 2 1 2 1 1 2 2 20 1 2 1 1 2 1 2 1 2 2 1 1 2 1 2 1 2 1 2 2 20 1 2 1 1 2 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 20 1 2 1 1 2 1 2 1 2 2 2 1 1 1 2 1 2 1 2 2 16 1 2 1 1 2 1 2 2 1 1 2 1 2 1 2 2 16 1 2 1 1 2 1 2 2 1 2 1 1 2 1 2 2 16 1 2 1 1 2 1 2 2 2 1 1 1 2 1 2 2 12 1 2 1 1 2 2 1 2 1 1 2 2 14 1 2 1 1 2 2 2 1 1 1 1 1 2 2 13 1 2 1 1 2 2 2 1 2 1 1 2 2 22 1 2 1 2 1 1 1 1 1 2 2 1 1 1 1 2 1 1 1 1 2 2 22 1 2 1 2 1 1 1 1 1 2 2 1 2 1 2 1 1 1 1 1 2 2 22 1 2 1 2 1 1 1 1 1 2 2 2 1 1 2 1 1 1 1 1 2 2 20 1 2 1 2 1 1 1 1 2 2 1 1 1 1 2 1 1 1 2 2 20 1 2 1 2 1 1 1 1 2 2 1 1 1 2 1 1 1 1 2 2 20 1 2 1 2 1 1 1 1 2 2 1 2 1 2 1 1 1 1 2 2 22 1 2 1 2 1 1 1 2 1 2 2 1 1 1 1 2 1 1 2 1 2 2 22 1 2 1 2 1 1 1 2 1 2 2 1 2 1 2 1 1 1 2 1 2 2 22 1 2 1 2 1 1 1 2 1 2 2 2 1 1 2 1 1 1 2 1 2 2 18 1 2 1 2 1 1 1 2 2 1 1 1 1 2 1 1 2 2 18 1 2 1 2 1 1 1 2 2 1 2 1 2 1 1 1 2 2 18 1 2 1 2 1 1 1 2 2 2 1 1 2 1 1 1 2 2 22 1 2 1 2 1 1 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 22 1 2 1 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 1 1 2 2 22 1 2 1 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 1 1 2 2 21 1 2 1 2 1 1 2 1 2 2 1 1 1 1 1 1 1 1 1 2 2 20 1 2 1 2 1 1 2 1 2 2 1 2 1 2 1 1 2 1 2 2 20 1 2 1 2 1 1 2 1 2 2 2 1 2 1 1 2 1 1 2 2 16 1 2 1 2 1 1 2 2 1 1 1 1 2 1 2 2 16 1 2 1 2 1 1 2 2 1 2 1 2 1 1 2 2 19 1 2 1 2 1 1 2 2 2 1 1 1 1 1 1 1 1 2 2 22 1 2 1 2 1 2 1 1 1 2 2 1 1 1 1 1 1 2 1 1 2 2 22 1 2 1 2 1 2 1 1 1 2 2 1 2 1 2 1 2 1 1 1 2 2 22 1 2 1 2 1 2 1 1 1 2 2 2 1 1 2 1 2 1 1 1 2 2 20 1 2 1 2 1 2 1 1 2 2 1 1 1 1 1 1 2 1 2 2 20 1 2 1 2 1 2 1 1 2 2 1 2 1 2 1 2 1 1 2 2 20 1 2 1 2 1 2 1 1 2 2 2 1 1 2 1 2 1 1 2 2 19 1 2 1 2 1 2 1 2 2 1 1 1 1 1 1 1 1 2 2 18 1 2 1 2 1 2 1 2 2 1 2 1 2 1 2 1 2 2 18 1 2 1 2 1 2 1 2 2 2 1 1 2 1 2 1 2 2 14 1 2 1 2 1 2 2 1 1 1 1 1 2 2 15 1 2 1 2 1 2 2 1 1 2 1 1 1 2 2 14 1 2 1 2 1 2 2 1 2 1 2 1 2 2 13 1 2 1 2 2 1 1 1 1 1 1 2 2 10 1 2 1 2 2 1 2 1 2 2 10 1 2 1 2 2 2 1 1 2 2 11 1 2 2 1 1 1 2 1 1 2 2 8 1 2 2 1 1 1 2 2 6 1 2 2 1 2 2 22 2 1 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 1 1 2 2 19 2 1 1 1 1 1 1 1 1 2 2 1 2 1 2 1 1 2 2 22 2 1 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 1 2 2 20 2 1 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 1 2 2 20 2 1 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 1 2 2 20 2 1 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 1 2 2 22 2 1 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 1 2 1 2 2 22 2 1 1 1 1 1 1 2 1 2 2 1 2 1 1 1 1 1 2 1 2 2 22 2 1 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 1 2 1 2 2 18 2 1 1 1 1 1 1 2 2 1 1 1 1 1 1 1 2 2 18 2 1 1 1 1 1 1 2 2 1 2 1 1 1 1 1 2 2 18 2 1 1 1 1 1 1 2 2 2 1 1 1 1 1 1 2 2 22 2 1 1 1 1 1 2 1 1 2 2 1 1 1 1 1 1 2 1 1 2 2 22 2 1 1 1 1 1 2 1 1 2 2 1 2 1 1 1 1 2 1 1 2 2 22 2 1 1 1 1 1 2 1 1 2 2 2 1 1 1 1 1 2 1 1 2 2 20 2 1 1 1 1 1 2 1 2 2 1 1 1 1 1 1 2 1 2 2 20 2 1 1 1 1 1 2 1 2 2 1 2 1 1 1 1 2 1 2 2 20 2 1 1 1 1 1 2 1 2 2 2 1 1 1 1 1 2 1 2 2 15 2 1 1 1 1 1 2 2 1 1 2 1 1 2 2 14 2 1 1 1 1 1 2 2 1 2 1 1 2 2 16 2 1 1 1 1 1 2 2 2 1 1 1 1 1 2 2 22 2 1 1 1 1 2 1 1 1 2 2 1 1 1 1 1 2 1 1 1 2 2 22 2 1 1 1 1 2 1 1 1 2 2 1 2 1 1 1 2 1 1 1 2 2 22 2 1 1 1 1 2 1 1 1 2 2 2 1 1 1 1 2 1 1 1 2 2 20 2 1 1 1 1 2 1 1 2 2 1 1 1 1 1 2 1 1 2 2 20 2 1 1 1 1 2 1 1 2 2 1 2 1 1 1 2 1 1 2 2 20 2 1 1 1 1 2 1 1 2 2 2 1 1 1 1 2 1 1 2 2 18 2 1 1 1 1 2 1 2 2 1 1 1 1 1 2 1 2 2 18 2 1 1 1 1 2 1 2 2 1 2 1 1 1 2 1 2 2 18 2 1 1 1 1 2 1 2 2 2 1 1 1 1 2 1 2 2 14 2 1 1 1 1 2 2 1 1 1 2 1 2 2 15 2 1 1 1 1 2 2 1 2 1 1 1 1 2 2 14 2 1 1 1 1 2 2 2 1 1 1 1 2 2 22 2 1 1 1 2 1 1 1 1 2 2 1 1 1 1 2 1 1 1 1 2 2 22 2 1 1 1 2 1 1 1 1 2 2 1 2 1 1 2 1 1 1 1 2 2 22 2 1 1 1 2 1 1 1 1 2 2 2 1 1 1 2 1 1 1 1 2 2 20 2 1 1 1 2 1 1 1 2 2 1 1 1 1 2 1 1 1 2 2 20 2 1 1 1 2 1 1 1 2 2 1 2 1 1 2 1 1 1 2 2 20 2 1 1 1 2 1 1 1 2 2 2 1 1 1 2 1 1 1 2 2 18 2 1 1 1 2 1 1 2 2 1 1 1 1 2 1 1 2 2 18 2 1 1 1 2 1 1 2 2 1 2 1 1 2 1 1 2 2 18 2 1 1 1 2 1 1 2 2 2 1 1 1 2 1 1 2 2 22 2 1 1 1 2 1 2 1 1 2 2 1 1 1 1 2 1 2 1 1 2 2 22 2 1 1 1 2 1 2 1 1 2 2 1 2 1 1 2 1 2 1 1 2 2 22 2 1 1 1 2 1 2 1 1 2 2 2 1 1 1 2 1 2 1 1 2 2 20 2 1 1 1 2 1 2 1 2 2 1 1 1 1 2 1 2 1 2 2 20 2 1 1 1 2 1 2 1 2 2 1 2 1 1 2 1 2 1 2 2 20 2 1 1 1 2 1 2 1 2 2 2 1 1 1 2 1 2 1 2 2 16 2 1 1 1 2 1 2 2 1 1 1 1 2 1 2 2 16 2 1 1 1 2 1 2 2 1 2 1 1 2 1 2 2 16 2 1 1 1 2 1 2 2 2 1 1 1 2 1 2 2 12 2 1 1 1 2 2 2 1 1 1 2 2 11 2 1 1 1 2 2 2 1 1 2 2 10 2 1 1 1 2 2 2 1 2 2 22 2 1 1 2 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 1 2 2 22 2 1 1 2 1 1 1 1 1 2 2 1 2 1 2 1 1 1 1 1 2 2 22 2 1 1 2 1 1 1 1 1 2 2 2 1 1 2 1 1 1 1 1 2 2 19 2 1 1 2 1 1 1 1 2 2 1 1 2 1 1 2 1 2 2 20 2 1 1 2 1 1 1 1 2 2 2 1 1 2 1 1 1 1 2 2 20 2 1 1 2 1 1 1 1 2 2 2 1 2 1 1 2 1 1 2 2 22 2 1 1 2 1 1 1 2 1 2 2 1 1 1 2 1 1 1 2 1 2 2 22 2 1 1 2 1 1 1 2 1 2 2 1 2 1 2 1 1 1 2 1 2 2 22 2 1 1 2 1 1 1 2 1 2 2 2 1 1 2 1 1 1 2 1 2 2 18 2 1 1 2 1 1 1 2 2 1 2 1 2 1 1 1 2 2 18 2 1 1 2 1 1 1 2 2 2 1 1 2 1 1 1 2 2 18 2 1 1 2 1 1 1 2 2 2 1 2 1 1 1 1 2 2 22 2 1 1 2 1 1 2 1 1 2 2 1 1 1 2 1 1 2 1 1 2 2 22 2 1 1 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 1 1 2 2 22 2 1 1 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 1 1 2 2 20 2 1 1 2 1 1 2 1 2 2 1 1 1 1 2 1 2 1 2 2 20 2 1 1 2 1 1 2 1 2 2 1 1 1 2 1 1 2 1 2 2 20 2 1 1 2 1 1 2 1 2 2 2 1 1 2 1 1 2 1 2 2 17 2 1 1 2 1 1 2 2 1 1 1 2 1 1 1 2 2 16 2 1 1 2 1 1 2 2 1 1 1 2 1 1 2 2 16 2 1 1 2 1 1 2 2 2 1 1 2 1 1 2 2 22 2 1 1 2 1 2 1 1 1 2 2 1 1 1 2 1 2 1 1 1 2 2 22 2 1 1 2 1 2 1 1 1 2 2 1 2 1 2 1 2 1 1 1 2 2 22 2 1 1 2 1 2 1 1 1 2 2 2 1 1 2 1 2 1 1 1 2 2 20 2 1 1 2 1 2 1 1 2 2 1 1 1 2 1 2 1 1 2 2 20 2 1 1 2 1 2 1 1 2 2 1 2 1 2 1 2 1 1 2 2 20 2 1 1 2 1 2 1 1 2 2 2 1 1 2 1 2 1 1 2 2 18 2 1 1 2 1 2 1 2 2 1 1 1 2 1 2 1 2 2 18 2 1 1 2 1 2 1 2 2 1 2 1 2 1 2 1 2 2 18 2 1 1 2 1 2 1 2 2 2 1 1 2 1 2 1 2 2 13 2 1 1 2 1 2 2 1 1 1 1 2 2 14 2 1 1 2 1 2 2 2 1 1 2 1 2 2 15 2 1 1 2 1 2 2 2 1 2 1 1 1 2 2 10 2 1 1 2 2 1 2 1 2 2 11 2 1 1 2 2 2 1 1 1 2 2 10 2 1 1 2 2 2 1 1 2 2 22 2 1 2 1 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 1 2 2 22 2 1 2 1 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 1 2 2 22 2 1 2 1 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 1 2 2 20 2 1 2 1 1 1 1 1 2 2 1 1 1 2 1 1 1 1 2 2 20 2 1 2 1 1 1 1 1 2 2 1 1 2 1 1 1 1 1 2 2 20 2 1 2 1 1 1 1 1 2 2 2 1 2 1 1 1 1 1 2 2 22 2 1 2 1 1 1 1 2 1 2 2 1 1 1 2 1 1 1 2 1 2 2 22 2 1 2 1 1 1 1 2 1 2 2 1 1 2 1 1 1 1 2 1 2 2 22 2 1 2 1 1 1 1 2 1 2 2 2 1 2 1 1 1 1 2 1 2 2 18 2 1 2 1 1 1 1 2 2 1 1 2 1 1 1 1 2 2 18 2 1 2 1 1 1 1 2 2 2 1 1 2 1 1 1 2 2 18 2 1 2 1 1 1 1 2 2 2 1 2 1 1 1 1 2 2 22 2 1 2 1 1 1 2 1 1 2 2 1 1 1 2 1 1 2 1 1 2 2 22 2 1 2 1 1 1 2 1 1 2 2 1 1 2 1 1 1 2 1 1 2 2 22 2 1 2 1 1 1 2 1 1 2 2 2 1 2 1 1 1 2 1 1 2 2 20 2 1 2 1 1 1 2 1 2 2 1 1 1 2 1 1 2 1 2 2 20 2 1 2 1 1 1 2 1 2 2 1 1 2 1 1 1 2 1 2 2 20 2 1 2 1 1 1 2 1 2 2 2 1 2 1 1 1 2 1 2 2 14 2 1 2 1 1 1 2 2 1 1 2 1 2 2 15 2 1 2 1 1 1 2 2 2 1 1 2 1 2 2 16 2 1 2 1 1 1 2 2 2 1 2 1 1 1 2 2 22 2 1 2 1 1 2 1 1 1 2 2 1 1 1 2 1 2 1 1 1 2 2 22 2 1 2 1 1 2 1 1 1 2 2 1 1 2 1 1 2 1 1 1 2 2 22 2 1 2 1 1 2 1 1 1 2 2 2 1 2 1 1 2 1 1 1 2 2 20 2 1 2 1 1 2 1 1 2 2 1 2 1 2 1 1 2 1 2 2 20 2 1 2 1 1 2 1 1 2 2 2 1 1 2 1 1 1 1 2 2 20 2 1 2 1 1 2 1 1 2 2 2 1 2 1 1 2 1 1 2 2 18 2 1 2 1 1 2 1 2 2 1 1 1 2 1 2 1 2 2 18 2 1 2 1 1 2 1 2 2 1 2 1 1 1 2 1 2 2 18 2 1 2 1 1 2 1 2 2 2 1 2 1 1 2 1 2 2 13 2 1 2 1 1 2 2 1 1 1 1 2 2 13 2 1 2 1 1 2 2 1 2 1 1 2 2 14 2 1 2 1 1 2 2 2 1 2 1 1 2 2 22 2 1 2 1 2 1 1 1 1 2 2 1 1 1 1 1 2 1 1 1 2 2 22 2 1 2 1 2 1 1 1 1 2 2 1 1 2 1 2 1 1 1 1 2 2 22 2 1 2 1 2 1 1 1 1 2 2 2 1 2 1 2 1 1 1 1 2 2 20 2 1 2 1 2 1 1 1 2 2 1 1 1 1 1 2 1 1 2 2 20 2 1 2 1 2 1 1 1 2 2 1 1 2 1 2 1 1 1 2 2 20 2 1 2 1 2 1 1 1 2 2 2 1 2 1 2 1 1 1 2 2 18 2 1 2 1 2 1 1 2 2 1 1 1 1 1 2 1 2 2 18 2 1 2 1 2 1 1 2 2 1 1 2 1 2 1 1 2 2 18 2 1 2 1 2 1 1 2 2 2 1 2 1 2 1 1 2 2 22 2 1 2 1 2 1 2 1 1 2 2 1 1 1 1 1 1 1 2 1 2 2 22 2 1 2 1 2 1 2 1 1 2 2 1 1 2 1 2 1 2 1 1 2 2 22 2 1 2 1 2 1 2 1 1 2 2 2 1 2 1 2 1 2 1 1 2 2 17 2 1 2 1 2 1 2 2 1 1 1 1 1 1 1 2 2 16 2 1 2 1 2 1 2 2 1 1 2 1 2 1 2 2 16 2 1 2 1 2 1 2 2 2 1 2 1 2 1 2 2 14 2 1 2 1 2 2 1 1 2 1 1 1 2 2 13 2 1 2 1 2 2 1 2 1 1 1 2 2 12 2 1 2 1 2 2 2 1 2 1 2 2 8 2 1 2 2 1 1 2 2 10 2 1 2 2 2 1 1 1 2 2 8 2 1 2 2 2 1 2 2");
static Space routine_0(Context& c);
static Space routine_124(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_66(Context& c, const Space& s0);
static Space routine_65(Context& c, const Space& s0);
static Space routine_101(Context& c, const Space& s0);
static Space routine_213(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_235(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_261(Context& c, const Path& p0, const Space& s0);
static Space routine_265(Context& c, const Path& p0, const Space& s0);
static Space routine_267(Context& c, const Path& p0, const Space& s0);
static Space routine_269(Context& c, const Path& p0, const Space& s0);
static Space routine_237(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_273(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_255(Context& c, const Path& p0, const Space& s0);
static Space routine_257(Context& c, const Path& p0, const Space& s0);
static Space routine_259(Context& c, const Path& p0, const Space& s0);
static Space routine_214(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_236(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_262(Context& c, const Path& p0, const Space& s0);
static Space routine_266(Context& c, const Path& p0, const Space& s0);
static Space routine_268(Context& c, const Path& p0, const Space& s0);
static Space routine_270(Context& c, const Path& p0, const Space& s0);
static Space routine_238(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_274(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_256(Context& c, const Path& p0, const Space& s0);
static Space routine_258(Context& c, const Path& p0, const Space& s0);
static Space routine_260(Context& c, const Path& p0, const Space& s0);
static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_63(Context& c, const Path& p0, const Space& s0);
static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_3(Context& c, const Path& p0, const Space& s0);
static Space routine_52(Context& c, const Path& p0, const Space& s0);
static Space routine_55(Context& c, const Path& p0, const Space& s0);
static Space routine_57(Context& c, const Path& p0, const Space& s0);
static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_31(Context& c, const Path& p0, const Space& s0);
static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_34(Context& c, const Path& p0, const Space& s0);
static Space routine_36(Context& c, const Path& p0, const Space& s0);
static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_64(Context& c, const Path& p0, const Space& s0);
static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_4(Context& c, const Path& p0, const Space& s0);
static Space routine_53(Context& c, const Path& p0, const Space& s0);
static Space routine_56(Context& c, const Path& p0, const Space& s0);
static Space routine_58(Context& c, const Path& p0, const Space& s0);
static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_32(Context& c, const Path& p0, const Space& s0);
static Space routine_35(Context& c, const Path& p0, const Space& s0);
static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_37(Context& c, const Path& p0, const Space& s0);
static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_78(Context& c, const Path& p0, const Space& s0);
static Space routine_98(Context& c, const Path& p0, const Space& s0);
static Space routine_102(Context& c, const Path& p0, const Space& s0);
static Space routine_105(Context& c, const Path& p0, const Space& s0);
static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_67(Context& c, const Path& p0, const Space& s0);
static Space routine_70(Context& c, const Path& p0, const Space& s0);
static Space routine_73(Context& c, const Path& p0, const Space& s0);
static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_79(Context& c, const Path& p0, const Space& s0);
static Space routine_99(Context& c, const Path& p0, const Space& s0);
static Space routine_103(Context& c, const Path& p0, const Space& s0);
static Space routine_106(Context& c, const Path& p0, const Space& s0);
static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_68(Context& c, const Path& p0, const Space& s0);
static Space routine_71(Context& c, const Path& p0, const Space& s0);
static Space routine_74(Context& c, const Path& p0, const Space& s0);
static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_7(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_120(Context& c, const Path& p0, const Space& s0);
static Space routine_12(Context& c, const Path& p0, const Space& s0);
static Space routine_110(Context& c, const Path& p0, const Space& s0);
static Space routine_112(Context& c, const Path& p0, const Space& s0);
static Space routine_114(Context& c, const Path& p0, const Space& s0);
static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_17(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_82(Context& c, const Path& p0, const Space& s0);
static Space routine_84(Context& c, const Path& p0, const Space& s0);
static Space routine_86(Context& c, const Path& p0, const Space& s0);
static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_8(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_121(Context& c, const Path& p0, const Space& s0);
static Space routine_13(Context& c, const Path& p0, const Space& s0);
static Space routine_111(Context& c, const Path& p0, const Space& s0);
static Space routine_113(Context& c, const Path& p0, const Space& s0);
static Space routine_115(Context& c, const Path& p0, const Space& s0);
static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_18(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_83(Context& c, const Path& p0, const Space& s0);
static Space routine_85(Context& c, const Path& p0, const Space& s0);
static Space routine_87(Context& c, const Path& p0, const Space& s0);
static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_185(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_133(Context& c, const Path& p0, const Space& s0);
static Space routine_155(Context& c, const Path& p0, const Space& s0);
static Space routine_157(Context& c, const Path& p0, const Space& s0);
static Space routine_159(Context& c, const Path& p0, const Space& s0);
static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_125(Context& c, const Path& p0, const Space& s0);
static Space routine_127(Context& c, const Path& p0, const Space& s0);
static Space routine_129(Context& c, const Path& p0, const Space& s0);
static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_134(Context& c, const Path& p0, const Space& s0);
static Space routine_186(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_156(Context& c, const Path& p0, const Space& s0);
static Space routine_158(Context& c, const Path& p0, const Space& s0);
static Space routine_160(Context& c, const Path& p0, const Space& s0);
static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_126(Context& c, const Path& p0, const Space& s0);
static Space routine_128(Context& c, const Path& p0, const Space& s0);
static Space routine_130(Context& c, const Path& p0, const Space& s0);
static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_171(Context& c, const Path& p0, const Space& s0);
static Space routine_38(Context& c, const Path& p0, const Space& s0);
static Space routine_163(Context& c, const Path& p0, const Space& s0);
static Space routine_217(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_165(Context& c, const Path& p0, const Space& s0);
static Space routine_167(Context& c, const Path& p0, const Space& s0);
static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_139(Context& c, const Path& p0, const Space& s0);
static Space routine_141(Context& c, const Path& p0, const Space& s0);
static Space routine_143(Context& c, const Path& p0, const Space& s0);
static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_172(Context& c, const Path& p0, const Space& s0);
static Space routine_39(Context& c, const Path& p0, const Space& s0);
static Space routine_164(Context& c, const Path& p0, const Space& s0);
static Space routine_218(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_166(Context& c, const Path& p0, const Space& s0);
static Space routine_168(Context& c, const Path& p0, const Space& s0);
static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_46(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_140(Context& c, const Path& p0, const Space& s0);
static Space routine_142(Context& c, const Path& p0, const Space& s0);
static Space routine_144(Context& c, const Path& p0, const Space& s0);
static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_183(Context& c, const Path& p0, const Space& s0);
static Space routine_199(Context& c, const Path& p0, const Space& s0);
static Space routine_201(Context& c, const Path& p0, const Space& s0);
static Space routine_227(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_203(Context& c, const Path& p0, const Space& s0);
static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_175(Context& c, const Path& p0, const Space& s0);
static Space routine_177(Context& c, const Path& p0, const Space& s0);
static Space routine_179(Context& c, const Path& p0, const Space& s0);
static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_184(Context& c, const Path& p0, const Space& s0);
static Space routine_200(Context& c, const Path& p0, const Space& s0);
static Space routine_202(Context& c, const Path& p0, const Space& s0);
static Space routine_204(Context& c, const Path& p0, const Space& s0);
static Space routine_228(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_176(Context& c, const Path& p0, const Space& s0);
static Space routine_178(Context& c, const Path& p0, const Space& s0);
static Space routine_180(Context& c, const Path& p0, const Space& s0);
static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_59(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_215(Context& c, const Path& p0, const Space& s0);
static Space routine_88(Context& c, const Path& p0, const Space& s0);
static Space routine_207(Context& c, const Path& p0, const Space& s0);
static Space routine_209(Context& c, const Path& p0, const Space& s0);
static Space routine_211(Context& c, const Path& p0, const Space& s0);
static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_253(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_94(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_187(Context& c, const Path& p0, const Space& s0);
static Space routine_189(Context& c, const Path& p0, const Space& s0);
static Space routine_191(Context& c, const Path& p0, const Space& s0);
static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_60(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_216(Context& c, const Path& p0, const Space& s0);
static Space routine_89(Context& c, const Path& p0, const Space& s0);
static Space routine_208(Context& c, const Path& p0, const Space& s0);
static Space routine_210(Context& c, const Path& p0, const Space& s0);
static Space routine_212(Context& c, const Path& p0, const Space& s0);
static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_95(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_254(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_188(Context& c, const Path& p0, const Space& s0);
static Space routine_190(Context& c, const Path& p0, const Space& s0);
static Space routine_192(Context& c, const Path& p0, const Space& s0);
static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_193(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_225(Context& c, const Path& p0, const Space& s0);
static Space routine_239(Context& c, const Path& p0, const Space& s0);
static Space routine_241(Context& c, const Path& p0, const Space& s0);
static Space routine_243(Context& c, const Path& p0, const Space& s0);
static Space routine_197(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_263(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_219(Context& c, const Path& p0, const Space& s0);
static Space routine_221(Context& c, const Path& p0, const Space& s0);
static Space routine_223(Context& c, const Path& p0, const Space& s0);
static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_194(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_226(Context& c, const Path& p0, const Space& s0);
static Space routine_240(Context& c, const Path& p0, const Space& s0);
static Space routine_242(Context& c, const Path& p0, const Space& s0);
static Space routine_244(Context& c, const Path& p0, const Space& s0);
static Space routine_198(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_264(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_220(Context& c, const Path& p0, const Space& s0);
static Space routine_222(Context& c, const Path& p0, const Space& s0);
static Space routine_224(Context& c, const Path& p0, const Space& s0);
static Space routine_181(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_116(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_195(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_145(Context& c, const Path& p0, const Space& s0);
static Space routine_251(Context& c, const Path& p0, const Space& s0);
static Space routine_245(Context& c, const Path& p0, const Space& s0);
static Space routine_247(Context& c, const Path& p0, const Space& s0);
static Space routine_249(Context& c, const Path& p0, const Space& s0);
static Space routine_205(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_151(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_271(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_229(Context& c, const Path& p0, const Space& s0);
static Space routine_231(Context& c, const Path& p0, const Space& s0);
static Space routine_233(Context& c, const Path& p0, const Space& s0);
static Space routine_182(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_117(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_196(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_146(Context& c, const Path& p0, const Space& s0);
static Space routine_252(Context& c, const Path& p0, const Space& s0);
static Space routine_246(Context& c, const Path& p0, const Space& s0);
static Space routine_248(Context& c, const Path& p0, const Space& s0);
static Space routine_250(Context& c, const Path& p0, const Space& s0);
static Space routine_206(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_152(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_272(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_230(Context& c, const Path& p0, const Space& s0);
static Space routine_232(Context& c, const Path& p0, const Space& s0);
static Space routine_234(Context& c, const Path& p0, const Space& s0);
static Space routine_81(Context& c, const Space& s0);
static Space routine_54(Context& c, const Space& s0);
static Space routine_30(Context& c, const Space& s0);
static Space routine_33(Context& c, const Space& s0);
static Space routine_138(Context& c, const Path& p0, const Space& s0);
static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_9(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_80(Context& c, const Path& p0, const Space& s0);
static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_14(Context& c, const Path& p0, const Space& s0);
static Space routine_100(Context& c, const Path& p0, const Space& s0);
static Space routine_104(Context& c, const Path& p0, const Space& s0);
static Space routine_107(Context& c, const Path& p0, const Space& s0);
static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1);
static Space routine_19(Context& c, const Path& p0, const Space& s0, const Space& s1);
static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0);
static Space routine_69(Context& c, const Path& p0, const Space& s0);
static Space routine_72(Context& c, const Path& p0, const Space& s0);
static Space routine_75(Context& c, const Path& p0, const Space& s0);
static Space routine_29(Context& c, const Path& p0);
static Space routine_0(Context& c) {
  Space v0_10;
  if (!constant_0.empty()) {
    const Space v1_4 = routine_1(c, constant_1, constant_2, constant_3);
    const Space v1_8 = routine_2(c, constant_4, constant_5, constant_3);
    const Space v1_9 = unite(v1_4,v1_8);
    v0_10 = compose(constant_0,v1_9);
  }
  Space v0_17;
  if (!constant_0.empty()) {
    const Space v2_13 = routine_3(c, constant_1, constant_2);
    const Space v2_15 = routine_4(c, constant_4, constant_5);
    const Space v2_16 = unite(v2_13,v2_15);
    v0_17 = compose(constant_0,v2_16);
  }
  Space v0_23_result;
  for (int v0_23_label = 1; v0_23_label <= 2; ++v0_23_label) {
    const Space v0_23_tail = child(v0_17,v0_23_label);
    if (v0_23_tail.empty()) continue;
    const Path v0_23_head{v0_23_label};
    const Space v3_2 = singleton(v0_23_head);
    const Space v3_3 = intersect(constant_6,v3_2);
    const Space v3_4 = (has_head(v3_3) ? constant_7 : Space{});
    const Space v3_5 = subtract(constant_0,v3_4);
    Space v3_7;
    if (!v3_5.empty()) {
      const Space v4_6 = routine_5(c, v0_23_head, v0_23_tail, constant_3);
      v3_7 = compose(v3_5,v4_6);
    }
    const Space v3_8 = intersect(constant_6,v3_2);
    const Space v3_9 = (has_head(v3_8) ? constant_7 : Space{});
    Space v3_11;
    if (!v3_9.empty()) {
      const Space v5_10 = routine_6(c, v0_23_head, v0_23_tail, constant_3);
      v3_11 = compose(v3_9,v5_10);
    }
    const Space v3_12 = unite(v3_7,v3_11);
    v0_23_result = unite(v0_23_result,v3_12);
  }
  const Space v0_23 = std::move(v0_23_result);
  const Space v0_24 = unite(v0_10,v0_23);
  const Space v0_26 = wrap(v0_24,constant_8);
  return v0_26;
}

static Space routine_1(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v6_12_result;
  for (int v6_12_label = 1; v6_12_label <= 2; ++v6_12_label) {
    const Space v6_12_tail = child(s0,v6_12_label);
    if (v6_12_tail.empty()) continue;
    const Path v6_12_head{v6_12_label};
    const Space v7_2 = singleton(v6_12_head);
    const Space v7_3 = intersect(constant_6,v7_2);
    const Space v7_4 = (has_head(v7_3) ? constant_7 : Space{});
    const Space v7_5 = subtract(constant_0,v7_4);
    Space v7_8;
    if (!v7_5.empty()) {
      const Path v8_6 = concat_path(p0,v6_12_head);
      Space v8_7_result;
      for (int v8_7_label = 1; v8_7_label <= 2; ++v8_7_label) {
        const Space v8_7_tail = child(v6_12_tail,v8_7_label);
        if (v8_7_tail.empty()) continue;
        const Path v8_7_head{v8_7_label};
        const Space v9_2 = singleton(v8_7_head);
        const Space v9_3 = intersect(constant_6,v9_2);
        const Space v9_4 = (has_head(v9_3) ? constant_7 : Space{});
        const Space v9_5 = subtract(constant_0,v9_4);
        Space v9_8;
        if (!v9_5.empty()) {
          const Path v10_6 = concat_path(v8_6,v8_7_head);
          const Space v10_7 = routine_7(c, v10_6, v8_7_tail, s1);
          v9_8 = compose(v9_5,v10_7);
        }
        const Space v9_9 = intersect(constant_6,v9_2);
        const Space v9_10 = (has_head(v9_9) ? constant_7 : Space{});
        Space v9_12;
        if (!v9_10.empty()) {
          const Path v11_6 = concat_path(v8_6,v8_7_head);
          const Space v11_11 = routine_8(c, v11_6, v8_7_tail, s1);
          v9_12 = compose(v9_10,v11_11);
        }
        const Space v9_13 = unite(v9_8,v9_12);
        v8_7_result = unite(v8_7_result,v9_13);
      }
      const Space v8_7 = std::move(v8_7_result);
      v7_8 = compose(v7_5,v8_7);
    }
    const Space v7_9 = intersect(constant_6,v7_2);
    const Space v7_10 = (has_head(v7_9) ? constant_7 : Space{});
    Space v7_12;
    if (!v7_10.empty()) {
      const Path v12_6 = concat_path(p0,v6_12_head);
      Space v12_11_result;
      for (int v12_11_label = 1; v12_11_label <= 2; ++v12_11_label) {
        const Space v12_11_tail = child(v6_12_tail,v12_11_label);
        if (v12_11_tail.empty()) continue;
        const Path v12_11_head{v12_11_label};
        const Space v13_2 = singleton(v12_11_head);
        const Space v13_3 = intersect(constant_6,v13_2);
        const Space v13_4 = (has_head(v13_3) ? constant_7 : Space{});
        const Space v13_5 = subtract(constant_0,v13_4);
        Space v13_8;
        if (!v13_5.empty()) {
          const Path v14_6 = concat_path(v12_6,v12_11_head);
          const Space v14_7 = routine_7(c, v14_6, v12_11_tail, s1);
          v13_8 = compose(v13_5,v14_7);
        }
        const Space v13_9 = intersect(constant_6,v13_2);
        const Space v13_10 = (has_head(v13_9) ? constant_7 : Space{});
        Space v13_12;
        if (!v13_10.empty()) {
          const Path v15_6 = concat_path(v12_6,v12_11_head);
          const Space v15_11 = routine_9(c, v15_6, v12_11_tail, s1);
          v13_12 = compose(v13_10,v15_11);
        }
        const Space v13_13 = unite(v13_8,v13_12);
        v12_11_result = unite(v12_11_result,v13_13);
      }
      const Space v12_11 = std::move(v12_11_result);
      v7_12 = compose(v7_10,v12_11);
    }
    const Space v7_13 = unite(v7_8,v7_12);
    v6_12_result = unite(v6_12_result,v7_13);
  }
  const Space v6_12 = std::move(v6_12_result);
  return v6_12;
}

static Space routine_2(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v16_12_result;
  for (int v16_12_label = 1; v16_12_label <= 2; ++v16_12_label) {
    const Space v16_12_tail = child(s0,v16_12_label);
    if (v16_12_tail.empty()) continue;
    const Path v16_12_head{v16_12_label};
    const Space v17_2 = singleton(v16_12_head);
    const Space v17_3 = intersect(constant_6,v17_2);
    const Space v17_4 = (has_head(v17_3) ? constant_7 : Space{});
    const Space v17_5 = subtract(constant_0,v17_4);
    Space v17_8;
    if (!v17_5.empty()) {
      const Path v18_6 = concat_path(p0,v16_12_head);
      Space v18_7_result;
      for (int v18_7_label = 1; v18_7_label <= 2; ++v18_7_label) {
        const Space v18_7_tail = child(v16_12_tail,v18_7_label);
        if (v18_7_tail.empty()) continue;
        const Path v18_7_head{v18_7_label};
        const Space v19_2 = singleton(v18_7_head);
        const Space v19_3 = intersect(constant_6,v19_2);
        const Space v19_4 = (has_head(v19_3) ? constant_7 : Space{});
        const Space v19_5 = subtract(constant_0,v19_4);
        Space v19_8;
        if (!v19_5.empty()) {
          const Path v20_6 = concat_path(v18_6,v18_7_head);
          const Space v20_7 = routine_7(c, v20_6, v18_7_tail, s1);
          v19_8 = compose(v19_5,v20_7);
        }
        const Space v19_9 = intersect(constant_6,v19_2);
        const Space v19_10 = (has_head(v19_9) ? constant_7 : Space{});
        Space v19_12;
        if (!v19_10.empty()) {
          const Path v21_6 = concat_path(v18_6,v18_7_head);
          const Space v21_11 = routine_8(c, v21_6, v18_7_tail, s1);
          v19_12 = compose(v19_10,v21_11);
        }
        const Space v19_13 = unite(v19_8,v19_12);
        v18_7_result = unite(v18_7_result,v19_13);
      }
      const Space v18_7 = std::move(v18_7_result);
      v17_8 = compose(v17_5,v18_7);
    }
    const Space v17_9 = intersect(constant_6,v17_2);
    const Space v17_10 = (has_head(v17_9) ? constant_7 : Space{});
    Space v17_12;
    if (!v17_10.empty()) {
      const Path v22_6 = concat_path(p0,v16_12_head);
      Space v22_11_result;
      for (int v22_11_label = 1; v22_11_label <= 2; ++v22_11_label) {
        const Space v22_11_tail = child(v16_12_tail,v22_11_label);
        if (v22_11_tail.empty()) continue;
        const Path v22_11_head{v22_11_label};
        const Space v23_2 = singleton(v22_11_head);
        const Space v23_3 = intersect(constant_6,v23_2);
        const Space v23_4 = (has_head(v23_3) ? constant_7 : Space{});
        const Space v23_5 = subtract(constant_0,v23_4);
        Space v23_7;
        if (!v23_5.empty()) {
          const Space v24_6 = routine_10(c, v22_11_head, v22_6, v22_11_tail, s1);
          v23_7 = compose(v23_5,v24_6);
        }
        const Space v23_8 = intersect(constant_6,v23_2);
        const Space v23_9 = (has_head(v23_8) ? constant_7 : Space{});
        Space v23_11;
        if (!v23_9.empty()) {
          const Space v25_10 = routine_11(c, v22_11_head, v22_6, v22_11_tail, s1);
          v23_11 = compose(v23_9,v25_10);
        }
        const Space v23_12 = unite(v23_7,v23_11);
        v22_11_result = unite(v22_11_result,v23_12);
      }
      const Space v22_11 = std::move(v22_11_result);
      v17_12 = compose(v17_10,v22_11);
    }
    const Space v17_13 = unite(v17_8,v17_12);
    v16_12_result = unite(v16_12_result,v17_13);
  }
  const Space v16_12 = std::move(v16_12_result);
  return v16_12;
}

static Space routine_3(Context& c, const Path& p0, const Space& s0) {
  Space v26_11_result;
  for (int v26_11_label = 1; v26_11_label <= 2; ++v26_11_label) {
    const Space v26_11_tail = child(s0,v26_11_label);
    if (v26_11_tail.empty()) continue;
    const Path v26_11_head{v26_11_label};
    const Space v27_2 = singleton(v26_11_head);
    const Space v27_3 = intersect(constant_6,v27_2);
    const Space v27_4 = (has_head(v27_3) ? constant_7 : Space{});
    const Space v27_5 = subtract(constant_0,v27_4);
    Space v27_8;
    if (!v27_5.empty()) {
      const Path v28_6 = concat_path(p0,v26_11_head);
      Space v28_7_result;
      for (int v28_7_label = 1; v28_7_label <= 2; ++v28_7_label) {
        const Space v28_7_tail = child(v26_11_tail,v28_7_label);
        if (v28_7_tail.empty()) continue;
        const Path v28_7_head{v28_7_label};
        const Space v29_2 = singleton(v28_7_head);
        const Space v29_3 = intersect(constant_6,v29_2);
        const Space v29_4 = (has_head(v29_3) ? constant_7 : Space{});
        const Space v29_5 = subtract(constant_0,v29_4);
        Space v29_8;
        if (!v29_5.empty()) {
          const Path v30_6 = concat_path(v28_6,v28_7_head);
          const Space v30_7 = routine_12(c, v30_6, v28_7_tail);
          v29_8 = compose(v29_5,v30_7);
        }
        const Space v29_9 = intersect(constant_6,v29_2);
        const Space v29_10 = (has_head(v29_9) ? constant_7 : Space{});
        Space v29_12;
        if (!v29_10.empty()) {
          const Path v31_6 = concat_path(v28_6,v28_7_head);
          const Space v31_11 = routine_13(c, v31_6, v28_7_tail);
          v29_12 = compose(v29_10,v31_11);
        }
        const Space v29_13 = unite(v29_8,v29_12);
        v28_7_result = unite(v28_7_result,v29_13);
      }
      const Space v28_7 = std::move(v28_7_result);
      v27_8 = compose(v27_5,v28_7);
    }
    const Space v27_9 = intersect(constant_6,v27_2);
    const Space v27_10 = (has_head(v27_9) ? constant_7 : Space{});
    Space v27_12;
    if (!v27_10.empty()) {
      const Path v32_6 = concat_path(p0,v26_11_head);
      Space v32_11_result;
      for (int v32_11_label = 1; v32_11_label <= 2; ++v32_11_label) {
        const Space v32_11_tail = child(v26_11_tail,v32_11_label);
        if (v32_11_tail.empty()) continue;
        const Path v32_11_head{v32_11_label};
        const Space v33_2 = singleton(v32_11_head);
        const Space v33_3 = intersect(constant_6,v33_2);
        const Space v33_4 = (has_head(v33_3) ? constant_7 : Space{});
        const Space v33_5 = subtract(constant_0,v33_4);
        Space v33_8;
        if (!v33_5.empty()) {
          const Path v34_6 = concat_path(v32_6,v32_11_head);
          const Space v34_7 = routine_12(c, v34_6, v32_11_tail);
          v33_8 = compose(v33_5,v34_7);
        }
        const Space v33_9 = intersect(constant_6,v33_2);
        const Space v33_10 = (has_head(v33_9) ? constant_7 : Space{});
        Space v33_12;
        if (!v33_10.empty()) {
          const Path v35_6 = concat_path(v32_6,v32_11_head);
          const Space v35_11 = routine_14(c, v35_6, v32_11_tail);
          v33_12 = compose(v33_10,v35_11);
        }
        const Space v33_13 = unite(v33_8,v33_12);
        v32_11_result = unite(v32_11_result,v33_13);
      }
      const Space v32_11 = std::move(v32_11_result);
      v27_12 = compose(v27_10,v32_11);
    }
    const Space v27_13 = unite(v27_8,v27_12);
    v26_11_result = unite(v26_11_result,v27_13);
  }
  const Space v26_11 = std::move(v26_11_result);
  return v26_11;
}

static Space routine_4(Context& c, const Path& p0, const Space& s0) {
  Space v36_11_result;
  for (int v36_11_label = 1; v36_11_label <= 2; ++v36_11_label) {
    const Space v36_11_tail = child(s0,v36_11_label);
    if (v36_11_tail.empty()) continue;
    const Path v36_11_head{v36_11_label};
    const Space v37_2 = singleton(v36_11_head);
    const Space v37_3 = intersect(constant_6,v37_2);
    const Space v37_4 = (has_head(v37_3) ? constant_7 : Space{});
    const Space v37_5 = subtract(constant_0,v37_4);
    Space v37_8;
    if (!v37_5.empty()) {
      const Path v38_6 = concat_path(p0,v36_11_head);
      Space v38_7_result;
      for (int v38_7_label = 1; v38_7_label <= 2; ++v38_7_label) {
        const Space v38_7_tail = child(v36_11_tail,v38_7_label);
        if (v38_7_tail.empty()) continue;
        const Path v38_7_head{v38_7_label};
        const Space v39_2 = singleton(v38_7_head);
        const Space v39_3 = intersect(constant_6,v39_2);
        const Space v39_4 = (has_head(v39_3) ? constant_7 : Space{});
        const Space v39_5 = subtract(constant_0,v39_4);
        Space v39_8;
        if (!v39_5.empty()) {
          const Path v40_6 = concat_path(v38_6,v38_7_head);
          const Space v40_7 = routine_12(c, v40_6, v38_7_tail);
          v39_8 = compose(v39_5,v40_7);
        }
        const Space v39_9 = intersect(constant_6,v39_2);
        const Space v39_10 = (has_head(v39_9) ? constant_7 : Space{});
        Space v39_12;
        if (!v39_10.empty()) {
          const Path v41_6 = concat_path(v38_6,v38_7_head);
          const Space v41_11 = routine_13(c, v41_6, v38_7_tail);
          v39_12 = compose(v39_10,v41_11);
        }
        const Space v39_13 = unite(v39_8,v39_12);
        v38_7_result = unite(v38_7_result,v39_13);
      }
      const Space v38_7 = std::move(v38_7_result);
      v37_8 = compose(v37_5,v38_7);
    }
    const Space v37_9 = intersect(constant_6,v37_2);
    const Space v37_10 = (has_head(v37_9) ? constant_7 : Space{});
    Space v37_12;
    if (!v37_10.empty()) {
      const Path v42_6 = concat_path(p0,v36_11_head);
      Space v42_11_result;
      for (int v42_11_label = 1; v42_11_label <= 2; ++v42_11_label) {
        const Space v42_11_tail = child(v36_11_tail,v42_11_label);
        if (v42_11_tail.empty()) continue;
        const Path v42_11_head{v42_11_label};
        const Space v43_2 = singleton(v42_11_head);
        const Space v43_3 = intersect(constant_6,v43_2);
        const Space v43_4 = (has_head(v43_3) ? constant_7 : Space{});
        const Space v43_5 = subtract(constant_0,v43_4);
        Space v43_7;
        if (!v43_5.empty()) {
          const Space v44_6 = routine_15(c, v42_11_head, v42_6, v42_11_tail);
          v43_7 = compose(v43_5,v44_6);
        }
        const Space v43_8 = intersect(constant_6,v43_2);
        const Space v43_9 = (has_head(v43_8) ? constant_7 : Space{});
        Space v43_11;
        if (!v43_9.empty()) {
          const Space v45_10 = routine_16(c, v42_11_head, v42_6, v42_11_tail);
          v43_11 = compose(v43_9,v45_10);
        }
        const Space v43_12 = unite(v43_7,v43_11);
        v42_11_result = unite(v42_11_result,v43_12);
      }
      const Space v42_11 = std::move(v42_11_result);
      v37_12 = compose(v37_10,v42_11);
    }
    const Space v37_13 = unite(v37_8,v37_12);
    v36_11_result = unite(v36_11_result,v37_13);
  }
  const Space v36_11 = std::move(v36_11_result);
  return v36_11;
}

static Space routine_5(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v46_12_result;
  for (int v46_12_label = 1; v46_12_label <= 2; ++v46_12_label) {
    const Space v46_12_tail = child(s0,v46_12_label);
    if (v46_12_tail.empty()) continue;
    const Path v46_12_head{v46_12_label};
    const Space v47_2 = singleton(v46_12_head);
    const Space v47_3 = intersect(constant_6,v47_2);
    const Space v47_4 = (has_head(v47_3) ? constant_7 : Space{});
    const Space v47_5 = subtract(constant_0,v47_4);
    Space v47_8;
    if (!v47_5.empty()) {
      const Path v48_6 = concat_path(p0,v46_12_head);
      Space v48_7_result;
      for (int v48_7_label = 1; v48_7_label <= 2; ++v48_7_label) {
        const Space v48_7_tail = child(v46_12_tail,v48_7_label);
        if (v48_7_tail.empty()) continue;
        const Path v48_7_head{v48_7_label};
        const Space v49_2 = singleton(v48_7_head);
        const Space v49_3 = intersect(constant_6,v49_2);
        const Space v49_4 = (has_head(v49_3) ? constant_7 : Space{});
        const Space v49_5 = subtract(constant_0,v49_4);
        Space v49_8;
        if (!v49_5.empty()) {
          const Path v50_6 = concat_path(v48_6,v48_7_head);
          const Space v50_7 = routine_17(c, v50_6, v48_7_tail, s1);
          v49_8 = compose(v49_5,v50_7);
        }
        const Space v49_9 = intersect(constant_6,v49_2);
        const Space v49_10 = (has_head(v49_9) ? constant_7 : Space{});
        Space v49_12;
        if (!v49_10.empty()) {
          const Path v51_6 = concat_path(v48_6,v48_7_head);
          const Space v51_11 = routine_18(c, v51_6, v48_7_tail, s1);
          v49_12 = compose(v49_10,v51_11);
        }
        const Space v49_13 = unite(v49_8,v49_12);
        v48_7_result = unite(v48_7_result,v49_13);
      }
      const Space v48_7 = std::move(v48_7_result);
      v47_8 = compose(v47_5,v48_7);
    }
    const Space v47_9 = intersect(constant_6,v47_2);
    const Space v47_10 = (has_head(v47_9) ? constant_7 : Space{});
    Space v47_12;
    if (!v47_10.empty()) {
      const Path v52_6 = concat_path(p0,v46_12_head);
      Space v52_11_result;
      for (int v52_11_label = 1; v52_11_label <= 2; ++v52_11_label) {
        const Space v52_11_tail = child(v46_12_tail,v52_11_label);
        if (v52_11_tail.empty()) continue;
        const Path v52_11_head{v52_11_label};
        const Space v53_2 = singleton(v52_11_head);
        const Space v53_3 = intersect(constant_6,v53_2);
        const Space v53_4 = (has_head(v53_3) ? constant_7 : Space{});
        const Space v53_5 = subtract(constant_0,v53_4);
        Space v53_8;
        if (!v53_5.empty()) {
          const Path v54_6 = concat_path(v52_6,v52_11_head);
          const Space v54_7 = routine_17(c, v54_6, v52_11_tail, s1);
          v53_8 = compose(v53_5,v54_7);
        }
        const Space v53_9 = intersect(constant_6,v53_2);
        const Space v53_10 = (has_head(v53_9) ? constant_7 : Space{});
        Space v53_12;
        if (!v53_10.empty()) {
          const Path v55_6 = concat_path(v52_6,v52_11_head);
          const Space v55_11 = routine_19(c, v55_6, v52_11_tail, s1);
          v53_12 = compose(v53_10,v55_11);
        }
        const Space v53_13 = unite(v53_8,v53_12);
        v52_11_result = unite(v52_11_result,v53_13);
      }
      const Space v52_11 = std::move(v52_11_result);
      v47_12 = compose(v47_10,v52_11);
    }
    const Space v47_13 = unite(v47_8,v47_12);
    v46_12_result = unite(v46_12_result,v47_13);
  }
  const Space v46_12 = std::move(v46_12_result);
  return v46_12;
}

static Space routine_6(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v56_12_result;
  for (int v56_12_label = 1; v56_12_label <= 2; ++v56_12_label) {
    const Space v56_12_tail = child(s0,v56_12_label);
    if (v56_12_tail.empty()) continue;
    const Path v56_12_head{v56_12_label};
    const Space v57_2 = singleton(v56_12_head);
    const Space v57_3 = intersect(constant_6,v57_2);
    const Space v57_4 = (has_head(v57_3) ? constant_7 : Space{});
    const Space v57_5 = subtract(constant_0,v57_4);
    Space v57_8;
    if (!v57_5.empty()) {
      const Path v58_6 = concat_path(p0,v56_12_head);
      Space v58_7_result;
      for (int v58_7_label = 1; v58_7_label <= 2; ++v58_7_label) {
        const Space v58_7_tail = child(v56_12_tail,v58_7_label);
        if (v58_7_tail.empty()) continue;
        const Path v58_7_head{v58_7_label};
        const Space v59_2 = singleton(v58_7_head);
        const Space v59_3 = intersect(constant_6,v59_2);
        const Space v59_4 = (has_head(v59_3) ? constant_7 : Space{});
        const Space v59_5 = subtract(constant_0,v59_4);
        Space v59_8;
        if (!v59_5.empty()) {
          const Path v60_6 = concat_path(v58_6,v58_7_head);
          const Space v60_7 = routine_17(c, v60_6, v58_7_tail, s1);
          v59_8 = compose(v59_5,v60_7);
        }
        const Space v59_9 = intersect(constant_6,v59_2);
        const Space v59_10 = (has_head(v59_9) ? constant_7 : Space{});
        Space v59_12;
        if (!v59_10.empty()) {
          const Path v61_6 = concat_path(v58_6,v58_7_head);
          const Space v61_11 = routine_18(c, v61_6, v58_7_tail, s1);
          v59_12 = compose(v59_10,v61_11);
        }
        const Space v59_13 = unite(v59_8,v59_12);
        v58_7_result = unite(v58_7_result,v59_13);
      }
      const Space v58_7 = std::move(v58_7_result);
      v57_8 = compose(v57_5,v58_7);
    }
    const Space v57_9 = intersect(constant_6,v57_2);
    const Space v57_10 = (has_head(v57_9) ? constant_7 : Space{});
    Space v57_12;
    if (!v57_10.empty()) {
      const Path v62_6 = concat_path(p0,v56_12_head);
      Space v62_11_result;
      for (int v62_11_label = 1; v62_11_label <= 2; ++v62_11_label) {
        const Space v62_11_tail = child(v56_12_tail,v62_11_label);
        if (v62_11_tail.empty()) continue;
        const Path v62_11_head{v62_11_label};
        const Space v63_2 = singleton(v62_11_head);
        const Space v63_3 = intersect(constant_6,v63_2);
        const Space v63_4 = (has_head(v63_3) ? constant_7 : Space{});
        const Space v63_5 = subtract(constant_0,v63_4);
        Space v63_7;
        if (!v63_5.empty()) {
          const Space v64_6 = routine_20(c, v62_11_head, v62_6, v62_11_tail, s1);
          v63_7 = compose(v63_5,v64_6);
        }
        const Space v63_8 = intersect(constant_6,v63_2);
        const Space v63_9 = (has_head(v63_8) ? constant_7 : Space{});
        Space v63_11;
        if (!v63_9.empty()) {
          const Space v65_10 = routine_21(c, v62_11_head, v62_6, v62_11_tail, s1);
          v63_11 = compose(v63_9,v65_10);
        }
        const Space v63_12 = unite(v63_7,v63_11);
        v62_11_result = unite(v62_11_result,v63_12);
      }
      const Space v62_11 = std::move(v62_11_result);
      v57_12 = compose(v57_10,v62_11);
    }
    const Space v57_13 = unite(v57_8,v57_12);
    v56_12_result = unite(v56_12_result,v57_13);
  }
  const Space v56_12 = std::move(v56_12_result);
  return v56_12;
}

static Space routine_7(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v66_12_result;
  for (int v66_12_label = 1; v66_12_label <= 2; ++v66_12_label) {
    const Space v66_12_tail = child(s0,v66_12_label);
    if (v66_12_tail.empty()) continue;
    const Path v66_12_head{v66_12_label};
    const Space v67_2 = singleton(v66_12_head);
    const Space v67_3 = intersect(constant_6,v67_2);
    const Space v67_4 = (has_head(v67_3) ? constant_7 : Space{});
    const Space v67_5 = subtract(constant_0,v67_4);
    Space v67_8;
    if (!v67_5.empty()) {
      const Path v68_6 = concat_path(p0,v66_12_head);
      Space v68_7_result;
      for (int v68_7_label = 1; v68_7_label <= 2; ++v68_7_label) {
        const Space v68_7_tail = child(v66_12_tail,v68_7_label);
        if (v68_7_tail.empty()) continue;
        const Path v68_7_head{v68_7_label};
        const Space v69_2 = singleton(v68_7_head);
        const Space v69_3 = intersect(constant_6,v69_2);
        const Space v69_4 = (has_head(v69_3) ? constant_7 : Space{});
        const Space v69_5 = subtract(constant_0,v69_4);
        Space v69_8;
        if (!v69_5.empty()) {
          const Path v70_6 = concat_path(v68_6,v68_7_head);
          const Space v70_7 = routine_22(c, v70_6, v68_7_tail, s1);
          v69_8 = compose(v69_5,v70_7);
        }
        const Space v69_9 = intersect(constant_6,v69_2);
        const Space v69_10 = (has_head(v69_9) ? constant_7 : Space{});
        Space v69_12;
        if (!v69_10.empty()) {
          const Path v71_6 = concat_path(v68_6,v68_7_head);
          const Space v71_11 = routine_23(c, v71_6, v68_7_tail, s1);
          v69_12 = compose(v69_10,v71_11);
        }
        const Space v69_13 = unite(v69_8,v69_12);
        v68_7_result = unite(v68_7_result,v69_13);
      }
      const Space v68_7 = std::move(v68_7_result);
      v67_8 = compose(v67_5,v68_7);
    }
    const Space v67_9 = intersect(constant_6,v67_2);
    const Space v67_10 = (has_head(v67_9) ? constant_7 : Space{});
    Space v67_12;
    if (!v67_10.empty()) {
      const Path v72_6 = concat_path(p0,v66_12_head);
      Space v72_11_result;
      for (int v72_11_label = 1; v72_11_label <= 2; ++v72_11_label) {
        const Space v72_11_tail = child(v66_12_tail,v72_11_label);
        if (v72_11_tail.empty()) continue;
        const Path v72_11_head{v72_11_label};
        const Space v73_2 = singleton(v72_11_head);
        const Space v73_3 = intersect(constant_6,v73_2);
        const Space v73_4 = (has_head(v73_3) ? constant_7 : Space{});
        const Space v73_5 = subtract(constant_0,v73_4);
        Space v73_8;
        if (!v73_5.empty()) {
          const Path v74_6 = concat_path(v72_6,v72_11_head);
          const Space v74_7 = routine_22(c, v74_6, v72_11_tail, s1);
          v73_8 = compose(v73_5,v74_7);
        }
        const Space v73_9 = intersect(constant_6,v73_2);
        const Space v73_10 = (has_head(v73_9) ? constant_7 : Space{});
        Space v73_12;
        if (!v73_10.empty()) {
          const Path v75_6 = concat_path(v72_6,v72_11_head);
          const Space v75_11 = routine_9(c, v75_6, v72_11_tail, s1);
          v73_12 = compose(v73_10,v75_11);
        }
        const Space v73_13 = unite(v73_8,v73_12);
        v72_11_result = unite(v72_11_result,v73_13);
      }
      const Space v72_11 = std::move(v72_11_result);
      v67_12 = compose(v67_10,v72_11);
    }
    const Space v67_13 = unite(v67_8,v67_12);
    v66_12_result = unite(v66_12_result,v67_13);
  }
  const Space v66_12 = std::move(v66_12_result);
  return v66_12;
}

static Space routine_8(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v76_12_result;
  for (int v76_12_label = 1; v76_12_label <= 2; ++v76_12_label) {
    const Space v76_12_tail = child(s0,v76_12_label);
    if (v76_12_tail.empty()) continue;
    const Path v76_12_head{v76_12_label};
    const Space v77_2 = singleton(v76_12_head);
    const Space v77_3 = intersect(constant_6,v77_2);
    const Space v77_4 = (has_head(v77_3) ? constant_7 : Space{});
    const Space v77_5 = subtract(constant_0,v77_4);
    Space v77_8;
    if (!v77_5.empty()) {
      const Path v78_6 = concat_path(p0,v76_12_head);
      Space v78_7_result;
      for (int v78_7_label = 1; v78_7_label <= 2; ++v78_7_label) {
        const Space v78_7_tail = child(v76_12_tail,v78_7_label);
        if (v78_7_tail.empty()) continue;
        const Path v78_7_head{v78_7_label};
        const Space v79_2 = singleton(v78_7_head);
        const Space v79_3 = intersect(constant_6,v79_2);
        const Space v79_4 = (has_head(v79_3) ? constant_7 : Space{});
        const Space v79_5 = subtract(constant_0,v79_4);
        Space v79_8;
        if (!v79_5.empty()) {
          const Path v80_6 = concat_path(v78_6,v78_7_head);
          const Space v80_7 = routine_22(c, v80_6, v78_7_tail, s1);
          v79_8 = compose(v79_5,v80_7);
        }
        const Space v79_9 = intersect(constant_6,v79_2);
        const Space v79_10 = (has_head(v79_9) ? constant_7 : Space{});
        Space v79_12;
        if (!v79_10.empty()) {
          const Path v81_6 = concat_path(v78_6,v78_7_head);
          const Space v81_11 = routine_23(c, v81_6, v78_7_tail, s1);
          v79_12 = compose(v79_10,v81_11);
        }
        const Space v79_13 = unite(v79_8,v79_12);
        v78_7_result = unite(v78_7_result,v79_13);
      }
      const Space v78_7 = std::move(v78_7_result);
      v77_8 = compose(v77_5,v78_7);
    }
    const Space v77_9 = intersect(constant_6,v77_2);
    const Space v77_10 = (has_head(v77_9) ? constant_7 : Space{});
    Space v77_12;
    if (!v77_10.empty()) {
      const Path v82_6 = concat_path(p0,v76_12_head);
      Space v82_11_result;
      for (int v82_11_label = 1; v82_11_label <= 2; ++v82_11_label) {
        const Space v82_11_tail = child(v76_12_tail,v82_11_label);
        if (v82_11_tail.empty()) continue;
        const Path v82_11_head{v82_11_label};
        const Space v83_2 = singleton(v82_11_head);
        const Space v83_3 = intersect(constant_6,v83_2);
        const Space v83_4 = (has_head(v83_3) ? constant_7 : Space{});
        const Space v83_5 = subtract(constant_0,v83_4);
        Space v83_7;
        if (!v83_5.empty()) {
          const Space v84_6 = routine_10(c, v82_11_head, v82_6, v82_11_tail, s1);
          v83_7 = compose(v83_5,v84_6);
        }
        const Space v83_8 = intersect(constant_6,v83_2);
        const Space v83_9 = (has_head(v83_8) ? constant_7 : Space{});
        Space v83_11;
        if (!v83_9.empty()) {
          const Space v85_10 = routine_11(c, v82_11_head, v82_6, v82_11_tail, s1);
          v83_11 = compose(v83_9,v85_10);
        }
        const Space v83_12 = unite(v83_7,v83_11);
        v82_11_result = unite(v82_11_result,v83_12);
      }
      const Space v82_11 = std::move(v82_11_result);
      v77_12 = compose(v77_10,v82_11);
    }
    const Space v77_13 = unite(v77_8,v77_12);
    v76_12_result = unite(v76_12_result,v77_13);
  }
  const Space v76_12 = std::move(v76_12_result);
  return v76_12;
}

static Space routine_9(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v86_12_result;
  for (int v86_12_label = 1; v86_12_label <= 2; ++v86_12_label) {
    const Space v86_12_tail = child(s0,v86_12_label);
    if (v86_12_tail.empty()) continue;
    const Path v86_12_head{v86_12_label};
    const Space v87_2 = singleton(v86_12_head);
    const Space v87_3 = intersect(constant_6,v87_2);
    const Space v87_4 = (has_head(v87_3) ? constant_7 : Space{});
    const Space v87_5 = subtract(constant_0,v87_4);
    Space v87_7;
    if (!v87_5.empty()) {
      Space v88_6_result;
      for (int v88_6_label = 1; v88_6_label <= 2; ++v88_6_label) {
        const Space v88_6_tail = child(v86_12_tail,v88_6_label);
        if (v88_6_tail.empty()) continue;
        const Path v88_6_head{v88_6_label};
        const Space v89_2 = singleton(v88_6_head);
        const Space v89_3 = intersect(constant_6,v89_2);
        const Space v89_4 = (has_head(v89_3) ? constant_7 : Space{});
        const Space v89_5 = subtract(constant_0,v89_4);
        Space v89_8;
        if (!v89_5.empty()) {
          const Path v90_6 = concat_path(v86_12_head,v88_6_head);
          const Space v90_7 = routine_24(c, v90_6, p0, v88_6_tail, s1);
          v89_8 = compose(v89_5,v90_7);
        }
        const Space v89_9 = intersect(constant_6,v89_2);
        const Space v89_10 = (has_head(v89_9) ? constant_7 : Space{});
        Space v89_12;
        if (!v89_10.empty()) {
          const Path v91_6 = concat_path(v86_12_head,v88_6_head);
          const Space v91_11 = routine_25(c, v91_6, p0, v88_6_tail, s1);
          v89_12 = compose(v89_10,v91_11);
        }
        const Space v89_13 = unite(v89_8,v89_12);
        v88_6_result = unite(v88_6_result,v89_13);
      }
      const Space v88_6 = std::move(v88_6_result);
      v87_7 = compose(v87_5,v88_6);
    }
    const Space v87_8 = intersect(constant_6,v87_2);
    const Space v87_9 = (has_head(v87_8) ? constant_7 : Space{});
    Space v87_11;
    if (!v87_9.empty()) {
      Space v92_10_result;
      for (int v92_10_label = 1; v92_10_label <= 2; ++v92_10_label) {
        const Space v92_10_tail = child(v86_12_tail,v92_10_label);
        if (v92_10_tail.empty()) continue;
        const Path v92_10_head{v92_10_label};
        const Space v93_2 = singleton(v92_10_head);
        const Space v93_3 = intersect(constant_6,v93_2);
        const Space v93_4 = (has_head(v93_3) ? constant_7 : Space{});
        const Space v93_5 = subtract(constant_0,v93_4);
        Space v93_8;
        if (!v93_5.empty()) {
          const Path v94_6 = concat_path(v86_12_head,v92_10_head);
          const Space v94_7 = routine_24(c, v94_6, p0, v92_10_tail, s1);
          v93_8 = compose(v93_5,v94_7);
        }
        const Space v93_9 = intersect(constant_6,v93_2);
        const Space v93_10 = (has_head(v93_9) ? constant_7 : Space{});
        Space v93_12;
        if (!v93_10.empty()) {
          const Path v95_6 = concat_path(v86_12_head,v92_10_head);
          const Space v95_11 = routine_26(c, v95_6, p0, v92_10_tail, s1);
          v93_12 = compose(v93_10,v95_11);
        }
        const Space v93_13 = unite(v93_8,v93_12);
        v92_10_result = unite(v92_10_result,v93_13);
      }
      const Space v92_10 = std::move(v92_10_result);
      v87_11 = compose(v87_9,v92_10);
    }
    const Space v87_12 = unite(v87_7,v87_11);
    v86_12_result = unite(v86_12_result,v87_12);
  }
  const Space v86_12 = std::move(v86_12_result);
  return v86_12;
}

static Space routine_10(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v96_13_result;
  for (int v96_13_label = 1; v96_13_label <= 2; ++v96_13_label) {
    const Space v96_13_tail = child(s0,v96_13_label);
    if (v96_13_tail.empty()) continue;
    const Path v96_13_head{v96_13_label};
    const Space v97_2 = singleton(v96_13_head);
    const Space v97_3 = intersect(constant_6,v97_2);
    const Space v97_4 = (has_head(v97_3) ? constant_7 : Space{});
    const Space v97_5 = subtract(constant_0,v97_4);
    Space v97_8;
    if (!v97_5.empty()) {
      const Path v98_6 = concat_path(p0,v96_13_head);
      Space v98_7_result;
      for (int v98_7_label = 1; v98_7_label <= 2; ++v98_7_label) {
        const Space v98_7_tail = child(v96_13_tail,v98_7_label);
        if (v98_7_tail.empty()) continue;
        const Path v98_7_head{v98_7_label};
        const Space v99_2 = singleton(v98_7_head);
        const Space v99_3 = intersect(constant_6,v99_2);
        const Space v99_4 = (has_head(v99_3) ? constant_7 : Space{});
        const Space v99_5 = subtract(constant_0,v99_4);
        Space v99_8;
        if (!v99_5.empty()) {
          const Path v100_6 = concat_path(v98_6,v98_7_head);
          const Space v100_7 = routine_27(c, v100_6, p1, v98_7_tail, s1);
          v99_8 = compose(v99_5,v100_7);
        }
        const Space v99_9 = intersect(constant_6,v99_2);
        const Space v99_10 = (has_head(v99_9) ? constant_7 : Space{});
        Space v99_12;
        if (!v99_10.empty()) {
          const Path v101_6 = concat_path(v98_6,v98_7_head);
          const Space v101_11 = routine_28(c, v101_6, p1, v98_7_tail, s1);
          v99_12 = compose(v99_10,v101_11);
        }
        const Space v99_13 = unite(v99_8,v99_12);
        v98_7_result = unite(v98_7_result,v99_13);
      }
      const Space v98_7 = std::move(v98_7_result);
      v97_8 = compose(v97_5,v98_7);
    }
    const Space v97_9 = intersect(constant_6,v97_2);
    const Space v97_10 = (has_head(v97_9) ? constant_7 : Space{});
    Space v97_12;
    if (!v97_10.empty()) {
      const Path v102_6 = concat_path(p0,v96_13_head);
      Space v102_11_result;
      for (int v102_11_label = 1; v102_11_label <= 2; ++v102_11_label) {
        const Space v102_11_tail = child(v96_13_tail,v102_11_label);
        if (v102_11_tail.empty()) continue;
        const Path v102_11_head{v102_11_label};
        const Space v103_2 = singleton(v102_11_head);
        const Space v103_3 = intersect(constant_6,v103_2);
        const Space v103_4 = (has_head(v103_3) ? constant_7 : Space{});
        const Space v103_5 = subtract(constant_0,v103_4);
        Space v103_8;
        if (!v103_5.empty()) {
          const Path v104_6 = concat_path(v102_6,v102_11_head);
          const Space v104_7 = routine_27(c, v104_6, p1, v102_11_tail, s1);
          v103_8 = compose(v103_5,v104_7);
        }
        const Space v103_9 = intersect(constant_6,v103_2);
        const Space v103_10 = (has_head(v103_9) ? constant_7 : Space{});
        Space v103_12;
        if (!v103_10.empty()) {
          const Path v105_6 = concat_path(v102_6,v102_11_head);
          const Space v105_11 = routine_26(c, v105_6, p1, v102_11_tail, s1);
          v103_12 = compose(v103_10,v105_11);
        }
        const Space v103_13 = unite(v103_8,v103_12);
        v102_11_result = unite(v102_11_result,v103_13);
      }
      const Space v102_11 = std::move(v102_11_result);
      v97_12 = compose(v97_10,v102_11);
    }
    const Space v97_13 = unite(v97_8,v97_12);
    v96_13_result = unite(v96_13_result,v97_13);
  }
  const Space v96_13 = std::move(v96_13_result);
  return v96_13;
}

static Space routine_11(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v106_8 = unwrap(s1,constant_8);
  Space v106_21_result;
  for (int v106_21_label = 1; v106_21_label <= 2; ++v106_21_label) {
    const Space v106_21_tail = child(s0,v106_21_label);
    if (v106_21_tail.empty()) continue;
    const Path v106_21_head{v106_21_label};
    const Space v107_2 = singleton(v106_21_head);
    const Space v107_3 = intersect(constant_6,v107_2);
    const Space v107_4 = (has_head(v107_3) ? constant_7 : Space{});
    const Space v107_5 = subtract(constant_0,v107_4);
    Space v107_8;
    if (!v107_5.empty()) {
      const Path v108_6 = concat_path(p0,v106_21_head);
      Space v108_7_result;
      for (int v108_7_label = 1; v108_7_label <= 2; ++v108_7_label) {
        const Space v108_7_tail = child(v106_21_tail,v108_7_label);
        if (v108_7_tail.empty()) continue;
        const Path v108_7_head{v108_7_label};
        const Space v109_2 = singleton(v108_7_head);
        const Space v109_3 = intersect(constant_6,v109_2);
        const Space v109_4 = (has_head(v109_3) ? constant_7 : Space{});
        const Space v109_5 = subtract(constant_0,v109_4);
        Space v109_8;
        if (!v109_5.empty()) {
          const Path v110_6 = concat_path(v108_6,v108_7_head);
          const Space v110_7 = routine_27(c, v110_6, p1, v108_7_tail, s1);
          v109_8 = compose(v109_5,v110_7);
        }
        const Space v109_9 = intersect(constant_6,v109_2);
        const Space v109_10 = (has_head(v109_9) ? constant_7 : Space{});
        Space v109_12;
        if (!v109_10.empty()) {
          const Path v111_6 = concat_path(v108_6,v108_7_head);
          const Space v111_11 = routine_28(c, v111_6, p1, v108_7_tail, s1);
          v109_12 = compose(v109_10,v111_11);
        }
        const Space v109_13 = unite(v109_8,v109_12);
        v108_7_result = unite(v108_7_result,v109_13);
      }
      const Space v108_7 = std::move(v108_7_result);
      v107_8 = compose(v107_5,v108_7);
    }
    const Space v107_9 = intersect(constant_6,v107_2);
    const Space v107_10 = (has_head(v107_9) ? constant_7 : Space{});
    Space v107_22;
    if (!v107_10.empty()) {
      const Path v112_6 = concat_path(p0,v106_21_head);
      const Path v112_11 = concat_path(p1,v112_6);
      const Space v112_12 = routine_29(c, v112_11);
      const Space v112_13 = intersect(v106_8,v112_12);
      const Space v112_14 = routine_30(c, v112_13);
      Space v112_15_result;
      for (int v112_15_label = 1; v112_15_label <= 2; ++v112_15_label) {
        const Space v112_15_tail = child(v112_14,v112_15_label);
        if (v112_15_tail.empty()) continue;
        const Path v112_15_head{v112_15_label};
        const Space v113_2 = singleton(v112_15_head);
        const Space v113_3 = intersect(constant_6,v113_2);
        const Space v113_4 = (has_head(v113_3) ? constant_7 : Space{});
        const Space v113_5 = subtract(constant_0,v113_4);
        Space v113_7;
        if (!v113_5.empty()) {
          const Space v114_6 = routine_31(c, v112_15_head, v112_15_tail);
          v113_7 = compose(v113_5,v114_6);
        }
        const Space v113_8 = intersect(constant_6,v113_2);
        const Space v113_9 = (has_head(v113_8) ? constant_7 : Space{});
        Space v113_11;
        if (!v113_9.empty()) {
          const Space v115_10 = routine_32(c, v112_15_head, v112_15_tail);
          v113_11 = compose(v113_9,v115_10);
        }
        const Space v113_12 = unite(v113_7,v113_11);
        v112_15_result = unite(v112_15_result,v113_12);
      }
      const Space v112_15 = std::move(v112_15_result);
      const Space v112_16 = routine_33(c, v112_13);
      Space v112_17_result;
      for (int v112_17_label = 1; v112_17_label <= 2; ++v112_17_label) {
        const Space v112_17_tail = child(v112_16,v112_17_label);
        if (v112_17_tail.empty()) continue;
        const Path v112_17_head{v112_17_label};
        const Space v116_2 = singleton(v112_17_head);
        const Space v116_3 = intersect(constant_6,v116_2);
        const Space v116_4 = (has_head(v116_3) ? constant_7 : Space{});
        const Space v116_5 = subtract(constant_0,v116_4);
        Space v116_7;
        if (!v116_5.empty()) {
          const Space v117_6 = routine_34(c, v112_17_head, v112_17_tail);
          v116_7 = compose(v116_5,v117_6);
        }
        const Space v116_8 = intersect(constant_6,v116_2);
        const Space v116_9 = (has_head(v116_8) ? constant_7 : Space{});
        Space v116_11;
        if (!v116_9.empty()) {
          const Space v118_10 = routine_35(c, v112_17_head, v112_17_tail);
          v116_11 = compose(v116_9,v118_10);
        }
        const Space v116_12 = unite(v116_7,v116_11);
        v112_17_result = unite(v112_17_result,v116_12);
      }
      const Space v112_17 = std::move(v112_17_result);
      const Space v112_18 = subtract(v112_15,v112_17);
      const Space v112_19 = singleton(v112_11);
      const Space v112_20 = compose(v112_18,v112_19);
      Space v112_21_result;
      for (int v112_21_label = 1; v112_21_label <= 2; ++v112_21_label) {
        const Space v112_21_tail = child(v112_20,v112_21_label);
        if (v112_21_tail.empty()) continue;
        const Path v112_21_head{v112_21_label};
        const Space v119_2 = singleton(v112_21_head);
        const Space v119_3 = intersect(constant_6,v119_2);
        const Space v119_4 = (has_head(v119_3) ? constant_7 : Space{});
        const Space v119_5 = subtract(constant_0,v119_4);
        Space v119_7;
        if (!v119_5.empty()) {
          const Space v120_6 = routine_36(c, v112_21_head, v112_21_tail);
          v119_7 = compose(v119_5,v120_6);
        }
        const Space v119_8 = intersect(constant_6,v119_2);
        const Space v119_9 = (has_head(v119_8) ? constant_7 : Space{});
        Space v119_11;
        if (!v119_9.empty()) {
          const Space v121_10 = routine_37(c, v112_21_head, v112_21_tail);
          v119_11 = compose(v119_9,v121_10);
        }
        const Space v119_12 = unite(v119_7,v119_11);
        v112_21_result = unite(v112_21_result,v119_12);
      }
      const Space v112_21 = std::move(v112_21_result);
      v107_22 = compose(v107_10,v112_21);
    }
    const Space v107_23 = unite(v107_8,v107_22);
    v106_21_result = unite(v106_21_result,v107_23);
  }
  const Space v106_21 = std::move(v106_21_result);
  return v106_21;
}

static Space routine_12(Context& c, const Path& p0, const Space& s0) {
  Space v122_11_result;
  for (int v122_11_label = 1; v122_11_label <= 2; ++v122_11_label) {
    const Space v122_11_tail = child(s0,v122_11_label);
    if (v122_11_tail.empty()) continue;
    const Path v122_11_head{v122_11_label};
    const Space v123_2 = singleton(v122_11_head);
    const Space v123_3 = intersect(constant_6,v123_2);
    const Space v123_4 = (has_head(v123_3) ? constant_7 : Space{});
    const Space v123_5 = subtract(constant_0,v123_4);
    Space v123_8;
    if (!v123_5.empty()) {
      const Path v124_6 = concat_path(p0,v122_11_head);
      Space v124_7_result;
      for (int v124_7_label = 1; v124_7_label <= 2; ++v124_7_label) {
        const Space v124_7_tail = child(v122_11_tail,v124_7_label);
        if (v124_7_tail.empty()) continue;
        const Path v124_7_head{v124_7_label};
        const Space v125_2 = singleton(v124_7_head);
        const Space v125_3 = intersect(constant_6,v125_2);
        const Space v125_4 = (has_head(v125_3) ? constant_7 : Space{});
        const Space v125_5 = subtract(constant_0,v125_4);
        Space v125_8;
        if (!v125_5.empty()) {
          const Path v126_6 = concat_path(v124_6,v124_7_head);
          const Space v126_7 = routine_38(c, v126_6, v124_7_tail);
          v125_8 = compose(v125_5,v126_7);
        }
        const Space v125_9 = intersect(constant_6,v125_2);
        const Space v125_10 = (has_head(v125_9) ? constant_7 : Space{});
        Space v125_12;
        if (!v125_10.empty()) {
          const Path v127_6 = concat_path(v124_6,v124_7_head);
          const Space v127_11 = routine_39(c, v127_6, v124_7_tail);
          v125_12 = compose(v125_10,v127_11);
        }
        const Space v125_13 = unite(v125_8,v125_12);
        v124_7_result = unite(v124_7_result,v125_13);
      }
      const Space v124_7 = std::move(v124_7_result);
      v123_8 = compose(v123_5,v124_7);
    }
    const Space v123_9 = intersect(constant_6,v123_2);
    const Space v123_10 = (has_head(v123_9) ? constant_7 : Space{});
    Space v123_12;
    if (!v123_10.empty()) {
      const Path v128_6 = concat_path(p0,v122_11_head);
      Space v128_11_result;
      for (int v128_11_label = 1; v128_11_label <= 2; ++v128_11_label) {
        const Space v128_11_tail = child(v122_11_tail,v128_11_label);
        if (v128_11_tail.empty()) continue;
        const Path v128_11_head{v128_11_label};
        const Space v129_2 = singleton(v128_11_head);
        const Space v129_3 = intersect(constant_6,v129_2);
        const Space v129_4 = (has_head(v129_3) ? constant_7 : Space{});
        const Space v129_5 = subtract(constant_0,v129_4);
        Space v129_8;
        if (!v129_5.empty()) {
          const Path v130_6 = concat_path(v128_6,v128_11_head);
          const Space v130_7 = routine_38(c, v130_6, v128_11_tail);
          v129_8 = compose(v129_5,v130_7);
        }
        const Space v129_9 = intersect(constant_6,v129_2);
        const Space v129_10 = (has_head(v129_9) ? constant_7 : Space{});
        Space v129_12;
        if (!v129_10.empty()) {
          const Path v131_6 = concat_path(v128_6,v128_11_head);
          const Space v131_11 = routine_14(c, v131_6, v128_11_tail);
          v129_12 = compose(v129_10,v131_11);
        }
        const Space v129_13 = unite(v129_8,v129_12);
        v128_11_result = unite(v128_11_result,v129_13);
      }
      const Space v128_11 = std::move(v128_11_result);
      v123_12 = compose(v123_10,v128_11);
    }
    const Space v123_13 = unite(v123_8,v123_12);
    v122_11_result = unite(v122_11_result,v123_13);
  }
  const Space v122_11 = std::move(v122_11_result);
  return v122_11;
}

static Space routine_13(Context& c, const Path& p0, const Space& s0) {
  Space v132_11_result;
  for (int v132_11_label = 1; v132_11_label <= 2; ++v132_11_label) {
    const Space v132_11_tail = child(s0,v132_11_label);
    if (v132_11_tail.empty()) continue;
    const Path v132_11_head{v132_11_label};
    const Space v133_2 = singleton(v132_11_head);
    const Space v133_3 = intersect(constant_6,v133_2);
    const Space v133_4 = (has_head(v133_3) ? constant_7 : Space{});
    const Space v133_5 = subtract(constant_0,v133_4);
    Space v133_8;
    if (!v133_5.empty()) {
      const Path v134_6 = concat_path(p0,v132_11_head);
      Space v134_7_result;
      for (int v134_7_label = 1; v134_7_label <= 2; ++v134_7_label) {
        const Space v134_7_tail = child(v132_11_tail,v134_7_label);
        if (v134_7_tail.empty()) continue;
        const Path v134_7_head{v134_7_label};
        const Space v135_2 = singleton(v134_7_head);
        const Space v135_3 = intersect(constant_6,v135_2);
        const Space v135_4 = (has_head(v135_3) ? constant_7 : Space{});
        const Space v135_5 = subtract(constant_0,v135_4);
        Space v135_8;
        if (!v135_5.empty()) {
          const Path v136_6 = concat_path(v134_6,v134_7_head);
          const Space v136_7 = routine_38(c, v136_6, v134_7_tail);
          v135_8 = compose(v135_5,v136_7);
        }
        const Space v135_9 = intersect(constant_6,v135_2);
        const Space v135_10 = (has_head(v135_9) ? constant_7 : Space{});
        Space v135_12;
        if (!v135_10.empty()) {
          const Path v137_6 = concat_path(v134_6,v134_7_head);
          const Space v137_11 = routine_39(c, v137_6, v134_7_tail);
          v135_12 = compose(v135_10,v137_11);
        }
        const Space v135_13 = unite(v135_8,v135_12);
        v134_7_result = unite(v134_7_result,v135_13);
      }
      const Space v134_7 = std::move(v134_7_result);
      v133_8 = compose(v133_5,v134_7);
    }
    const Space v133_9 = intersect(constant_6,v133_2);
    const Space v133_10 = (has_head(v133_9) ? constant_7 : Space{});
    Space v133_12;
    if (!v133_10.empty()) {
      const Path v138_6 = concat_path(p0,v132_11_head);
      Space v138_11_result;
      for (int v138_11_label = 1; v138_11_label <= 2; ++v138_11_label) {
        const Space v138_11_tail = child(v132_11_tail,v138_11_label);
        if (v138_11_tail.empty()) continue;
        const Path v138_11_head{v138_11_label};
        const Space v139_2 = singleton(v138_11_head);
        const Space v139_3 = intersect(constant_6,v139_2);
        const Space v139_4 = (has_head(v139_3) ? constant_7 : Space{});
        const Space v139_5 = subtract(constant_0,v139_4);
        Space v139_7;
        if (!v139_5.empty()) {
          const Space v140_6 = routine_15(c, v138_11_head, v138_6, v138_11_tail);
          v139_7 = compose(v139_5,v140_6);
        }
        const Space v139_8 = intersect(constant_6,v139_2);
        const Space v139_9 = (has_head(v139_8) ? constant_7 : Space{});
        Space v139_11;
        if (!v139_9.empty()) {
          const Space v141_10 = routine_16(c, v138_11_head, v138_6, v138_11_tail);
          v139_11 = compose(v139_9,v141_10);
        }
        const Space v139_12 = unite(v139_7,v139_11);
        v138_11_result = unite(v138_11_result,v139_12);
      }
      const Space v138_11 = std::move(v138_11_result);
      v133_12 = compose(v133_10,v138_11);
    }
    const Space v133_13 = unite(v133_8,v133_12);
    v132_11_result = unite(v132_11_result,v133_13);
  }
  const Space v132_11 = std::move(v132_11_result);
  return v132_11;
}

static Space routine_14(Context& c, const Path& p0, const Space& s0) {
  Space v142_11_result;
  for (int v142_11_label = 1; v142_11_label <= 2; ++v142_11_label) {
    const Space v142_11_tail = child(s0,v142_11_label);
    if (v142_11_tail.empty()) continue;
    const Path v142_11_head{v142_11_label};
    const Space v143_2 = singleton(v142_11_head);
    const Space v143_3 = intersect(constant_6,v143_2);
    const Space v143_4 = (has_head(v143_3) ? constant_7 : Space{});
    const Space v143_5 = subtract(constant_0,v143_4);
    Space v143_7;
    if (!v143_5.empty()) {
      Space v144_6_result;
      for (int v144_6_label = 1; v144_6_label <= 2; ++v144_6_label) {
        const Space v144_6_tail = child(v142_11_tail,v144_6_label);
        if (v144_6_tail.empty()) continue;
        const Path v144_6_head{v144_6_label};
        const Space v145_2 = singleton(v144_6_head);
        const Space v145_3 = intersect(constant_6,v145_2);
        const Space v145_4 = (has_head(v145_3) ? constant_7 : Space{});
        const Space v145_5 = subtract(constant_0,v145_4);
        Space v145_8;
        if (!v145_5.empty()) {
          const Path v146_6 = concat_path(v142_11_head,v144_6_head);
          const Space v146_7 = routine_40(c, v146_6, p0, v144_6_tail);
          v145_8 = compose(v145_5,v146_7);
        }
        const Space v145_9 = intersect(constant_6,v145_2);
        const Space v145_10 = (has_head(v145_9) ? constant_7 : Space{});
        Space v145_12;
        if (!v145_10.empty()) {
          const Path v147_6 = concat_path(v142_11_head,v144_6_head);
          const Space v147_11 = routine_41(c, v147_6, p0, v144_6_tail);
          v145_12 = compose(v145_10,v147_11);
        }
        const Space v145_13 = unite(v145_8,v145_12);
        v144_6_result = unite(v144_6_result,v145_13);
      }
      const Space v144_6 = std::move(v144_6_result);
      v143_7 = compose(v143_5,v144_6);
    }
    const Space v143_8 = intersect(constant_6,v143_2);
    const Space v143_9 = (has_head(v143_8) ? constant_7 : Space{});
    Space v143_11;
    if (!v143_9.empty()) {
      Space v148_10_result;
      for (int v148_10_label = 1; v148_10_label <= 2; ++v148_10_label) {
        const Space v148_10_tail = child(v142_11_tail,v148_10_label);
        if (v148_10_tail.empty()) continue;
        const Path v148_10_head{v148_10_label};
        const Space v149_2 = singleton(v148_10_head);
        const Space v149_3 = intersect(constant_6,v149_2);
        const Space v149_4 = (has_head(v149_3) ? constant_7 : Space{});
        const Space v149_5 = subtract(constant_0,v149_4);
        Space v149_8;
        if (!v149_5.empty()) {
          const Path v150_6 = concat_path(v142_11_head,v148_10_head);
          const Space v150_7 = routine_40(c, v150_6, p0, v148_10_tail);
          v149_8 = compose(v149_5,v150_7);
        }
        const Space v149_9 = intersect(constant_6,v149_2);
        const Space v149_10 = (has_head(v149_9) ? constant_7 : Space{});
        Space v149_12;
        if (!v149_10.empty()) {
          const Path v151_6 = concat_path(v142_11_head,v148_10_head);
          const Space v151_11 = routine_42(c, v151_6, p0, v148_10_tail);
          v149_12 = compose(v149_10,v151_11);
        }
        const Space v149_13 = unite(v149_8,v149_12);
        v148_10_result = unite(v148_10_result,v149_13);
      }
      const Space v148_10 = std::move(v148_10_result);
      v143_11 = compose(v143_9,v148_10);
    }
    const Space v143_12 = unite(v143_7,v143_11);
    v142_11_result = unite(v142_11_result,v143_12);
  }
  const Space v142_11 = std::move(v142_11_result);
  return v142_11;
}

static Space routine_15(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v152_12_result;
  for (int v152_12_label = 1; v152_12_label <= 2; ++v152_12_label) {
    const Space v152_12_tail = child(s0,v152_12_label);
    if (v152_12_tail.empty()) continue;
    const Path v152_12_head{v152_12_label};
    const Space v153_2 = singleton(v152_12_head);
    const Space v153_3 = intersect(constant_6,v153_2);
    const Space v153_4 = (has_head(v153_3) ? constant_7 : Space{});
    const Space v153_5 = subtract(constant_0,v153_4);
    Space v153_8;
    if (!v153_5.empty()) {
      const Path v154_6 = concat_path(p0,v152_12_head);
      Space v154_7_result;
      for (int v154_7_label = 1; v154_7_label <= 2; ++v154_7_label) {
        const Space v154_7_tail = child(v152_12_tail,v154_7_label);
        if (v154_7_tail.empty()) continue;
        const Path v154_7_head{v154_7_label};
        const Space v155_2 = singleton(v154_7_head);
        const Space v155_3 = intersect(constant_6,v155_2);
        const Space v155_4 = (has_head(v155_3) ? constant_7 : Space{});
        const Space v155_5 = subtract(constant_0,v155_4);
        Space v155_8;
        if (!v155_5.empty()) {
          const Path v156_6 = concat_path(v154_6,v154_7_head);
          const Space v156_7 = routine_43(c, v156_6, p1, v154_7_tail);
          v155_8 = compose(v155_5,v156_7);
        }
        const Space v155_9 = intersect(constant_6,v155_2);
        const Space v155_10 = (has_head(v155_9) ? constant_7 : Space{});
        Space v155_12;
        if (!v155_10.empty()) {
          const Path v157_6 = concat_path(v154_6,v154_7_head);
          const Space v157_11 = routine_44(c, v157_6, p1, v154_7_tail);
          v155_12 = compose(v155_10,v157_11);
        }
        const Space v155_13 = unite(v155_8,v155_12);
        v154_7_result = unite(v154_7_result,v155_13);
      }
      const Space v154_7 = std::move(v154_7_result);
      v153_8 = compose(v153_5,v154_7);
    }
    const Space v153_9 = intersect(constant_6,v153_2);
    const Space v153_10 = (has_head(v153_9) ? constant_7 : Space{});
    Space v153_12;
    if (!v153_10.empty()) {
      const Path v158_6 = concat_path(p0,v152_12_head);
      Space v158_11_result;
      for (int v158_11_label = 1; v158_11_label <= 2; ++v158_11_label) {
        const Space v158_11_tail = child(v152_12_tail,v158_11_label);
        if (v158_11_tail.empty()) continue;
        const Path v158_11_head{v158_11_label};
        const Space v159_2 = singleton(v158_11_head);
        const Space v159_3 = intersect(constant_6,v159_2);
        const Space v159_4 = (has_head(v159_3) ? constant_7 : Space{});
        const Space v159_5 = subtract(constant_0,v159_4);
        Space v159_8;
        if (!v159_5.empty()) {
          const Path v160_6 = concat_path(v158_6,v158_11_head);
          const Space v160_7 = routine_43(c, v160_6, p1, v158_11_tail);
          v159_8 = compose(v159_5,v160_7);
        }
        const Space v159_9 = intersect(constant_6,v159_2);
        const Space v159_10 = (has_head(v159_9) ? constant_7 : Space{});
        Space v159_12;
        if (!v159_10.empty()) {
          const Path v161_6 = concat_path(v158_6,v158_11_head);
          const Space v161_11 = routine_42(c, v161_6, p1, v158_11_tail);
          v159_12 = compose(v159_10,v161_11);
        }
        const Space v159_13 = unite(v159_8,v159_12);
        v158_11_result = unite(v158_11_result,v159_13);
      }
      const Space v158_11 = std::move(v158_11_result);
      v153_12 = compose(v153_10,v158_11);
    }
    const Space v153_13 = unite(v153_8,v153_12);
    v152_12_result = unite(v152_12_result,v153_13);
  }
  const Space v152_12 = std::move(v152_12_result);
  return v152_12;
}

static Space routine_16(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v162_9_result;
  for (int v162_9_label = 1; v162_9_label <= 2; ++v162_9_label) {
    const Space v162_9_tail = child(s0,v162_9_label);
    if (v162_9_tail.empty()) continue;
    const Path v162_9_head{v162_9_label};
    const Space v163_2 = singleton(v162_9_head);
    const Space v163_3 = intersect(constant_6,v163_2);
    const Space v163_4 = (has_head(v163_3) ? constant_7 : Space{});
    const Space v163_5 = subtract(constant_0,v163_4);
    Space v163_8;
    if (!v163_5.empty()) {
      const Path v164_6 = concat_path(p0,v162_9_head);
      Space v164_7_result;
      for (int v164_7_label = 1; v164_7_label <= 2; ++v164_7_label) {
        const Space v164_7_tail = child(v162_9_tail,v164_7_label);
        if (v164_7_tail.empty()) continue;
        const Path v164_7_head{v164_7_label};
        const Space v165_2 = singleton(v164_7_head);
        const Space v165_3 = intersect(constant_6,v165_2);
        const Space v165_4 = (has_head(v165_3) ? constant_7 : Space{});
        const Space v165_5 = subtract(constant_0,v165_4);
        Space v165_8;
        if (!v165_5.empty()) {
          const Path v166_6 = concat_path(v164_6,v164_7_head);
          const Space v166_7 = routine_43(c, v166_6, p1, v164_7_tail);
          v165_8 = compose(v165_5,v166_7);
        }
        const Space v165_9 = intersect(constant_6,v165_2);
        const Space v165_10 = (has_head(v165_9) ? constant_7 : Space{});
        Space v165_12;
        if (!v165_10.empty()) {
          const Path v167_6 = concat_path(v164_6,v164_7_head);
          const Space v167_11 = routine_44(c, v167_6, p1, v164_7_tail);
          v165_12 = compose(v165_10,v167_11);
        }
        const Space v165_13 = unite(v165_8,v165_12);
        v164_7_result = unite(v164_7_result,v165_13);
      }
      const Space v164_7 = std::move(v164_7_result);
      v163_8 = compose(v163_5,v164_7);
    }
    const Space v163_9 = intersect(constant_6,v163_2);
    const Space v163_10 = (has_head(v163_9) ? constant_7 : Space{});
    Space v163_13;
    if (!v163_10.empty()) {
      const Path v168_6 = concat_path(p0,v162_9_head);
      const Path v168_11 = concat_path(p1,v168_6);
      const Space v168_12 = routine_29(c, v168_11);
      v163_13 = compose(v163_10,v168_12);
    }
    const Space v163_14 = unite(v163_8,v163_13);
    v162_9_result = unite(v162_9_result,v163_14);
  }
  const Space v162_9 = std::move(v162_9_result);
  return v162_9;
}

static Space routine_17(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v169_12_result;
  for (int v169_12_label = 1; v169_12_label <= 2; ++v169_12_label) {
    const Space v169_12_tail = child(s0,v169_12_label);
    if (v169_12_tail.empty()) continue;
    const Path v169_12_head{v169_12_label};
    const Space v170_2 = singleton(v169_12_head);
    const Space v170_3 = intersect(constant_6,v170_2);
    const Space v170_4 = (has_head(v170_3) ? constant_7 : Space{});
    const Space v170_5 = subtract(constant_0,v170_4);
    Space v170_8;
    if (!v170_5.empty()) {
      const Path v171_6 = concat_path(p0,v169_12_head);
      Space v171_7_result;
      for (int v171_7_label = 1; v171_7_label <= 2; ++v171_7_label) {
        const Space v171_7_tail = child(v169_12_tail,v171_7_label);
        if (v171_7_tail.empty()) continue;
        const Path v171_7_head{v171_7_label};
        const Space v172_2 = singleton(v171_7_head);
        const Space v172_3 = intersect(constant_6,v172_2);
        const Space v172_4 = (has_head(v172_3) ? constant_7 : Space{});
        const Space v172_5 = subtract(constant_0,v172_4);
        Space v172_8;
        if (!v172_5.empty()) {
          const Path v173_6 = concat_path(v171_6,v171_7_head);
          const Space v173_7 = routine_45(c, v173_6, v171_7_tail, s1);
          v172_8 = compose(v172_5,v173_7);
        }
        const Space v172_9 = intersect(constant_6,v172_2);
        const Space v172_10 = (has_head(v172_9) ? constant_7 : Space{});
        Space v172_12;
        if (!v172_10.empty()) {
          const Path v174_6 = concat_path(v171_6,v171_7_head);
          const Space v174_11 = routine_46(c, v174_6, v171_7_tail, s1);
          v172_12 = compose(v172_10,v174_11);
        }
        const Space v172_13 = unite(v172_8,v172_12);
        v171_7_result = unite(v171_7_result,v172_13);
      }
      const Space v171_7 = std::move(v171_7_result);
      v170_8 = compose(v170_5,v171_7);
    }
    const Space v170_9 = intersect(constant_6,v170_2);
    const Space v170_10 = (has_head(v170_9) ? constant_7 : Space{});
    Space v170_12;
    if (!v170_10.empty()) {
      const Path v175_6 = concat_path(p0,v169_12_head);
      Space v175_11_result;
      for (int v175_11_label = 1; v175_11_label <= 2; ++v175_11_label) {
        const Space v175_11_tail = child(v169_12_tail,v175_11_label);
        if (v175_11_tail.empty()) continue;
        const Path v175_11_head{v175_11_label};
        const Space v176_2 = singleton(v175_11_head);
        const Space v176_3 = intersect(constant_6,v176_2);
        const Space v176_4 = (has_head(v176_3) ? constant_7 : Space{});
        const Space v176_5 = subtract(constant_0,v176_4);
        Space v176_8;
        if (!v176_5.empty()) {
          const Path v177_6 = concat_path(v175_6,v175_11_head);
          const Space v177_7 = routine_45(c, v177_6, v175_11_tail, s1);
          v176_8 = compose(v176_5,v177_7);
        }
        const Space v176_9 = intersect(constant_6,v176_2);
        const Space v176_10 = (has_head(v176_9) ? constant_7 : Space{});
        Space v176_12;
        if (!v176_10.empty()) {
          const Path v178_6 = concat_path(v175_6,v175_11_head);
          const Space v178_11 = routine_19(c, v178_6, v175_11_tail, s1);
          v176_12 = compose(v176_10,v178_11);
        }
        const Space v176_13 = unite(v176_8,v176_12);
        v175_11_result = unite(v175_11_result,v176_13);
      }
      const Space v175_11 = std::move(v175_11_result);
      v170_12 = compose(v170_10,v175_11);
    }
    const Space v170_13 = unite(v170_8,v170_12);
    v169_12_result = unite(v169_12_result,v170_13);
  }
  const Space v169_12 = std::move(v169_12_result);
  return v169_12;
}

static Space routine_18(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v179_12_result;
  for (int v179_12_label = 1; v179_12_label <= 2; ++v179_12_label) {
    const Space v179_12_tail = child(s0,v179_12_label);
    if (v179_12_tail.empty()) continue;
    const Path v179_12_head{v179_12_label};
    const Space v180_2 = singleton(v179_12_head);
    const Space v180_3 = intersect(constant_6,v180_2);
    const Space v180_4 = (has_head(v180_3) ? constant_7 : Space{});
    const Space v180_5 = subtract(constant_0,v180_4);
    Space v180_8;
    if (!v180_5.empty()) {
      const Path v181_6 = concat_path(p0,v179_12_head);
      Space v181_7_result;
      for (int v181_7_label = 1; v181_7_label <= 2; ++v181_7_label) {
        const Space v181_7_tail = child(v179_12_tail,v181_7_label);
        if (v181_7_tail.empty()) continue;
        const Path v181_7_head{v181_7_label};
        const Space v182_2 = singleton(v181_7_head);
        const Space v182_3 = intersect(constant_6,v182_2);
        const Space v182_4 = (has_head(v182_3) ? constant_7 : Space{});
        const Space v182_5 = subtract(constant_0,v182_4);
        Space v182_8;
        if (!v182_5.empty()) {
          const Path v183_6 = concat_path(v181_6,v181_7_head);
          const Space v183_7 = routine_45(c, v183_6, v181_7_tail, s1);
          v182_8 = compose(v182_5,v183_7);
        }
        const Space v182_9 = intersect(constant_6,v182_2);
        const Space v182_10 = (has_head(v182_9) ? constant_7 : Space{});
        Space v182_12;
        if (!v182_10.empty()) {
          const Path v184_6 = concat_path(v181_6,v181_7_head);
          const Space v184_11 = routine_46(c, v184_6, v181_7_tail, s1);
          v182_12 = compose(v182_10,v184_11);
        }
        const Space v182_13 = unite(v182_8,v182_12);
        v181_7_result = unite(v181_7_result,v182_13);
      }
      const Space v181_7 = std::move(v181_7_result);
      v180_8 = compose(v180_5,v181_7);
    }
    const Space v180_9 = intersect(constant_6,v180_2);
    const Space v180_10 = (has_head(v180_9) ? constant_7 : Space{});
    Space v180_12;
    if (!v180_10.empty()) {
      const Path v185_6 = concat_path(p0,v179_12_head);
      Space v185_11_result;
      for (int v185_11_label = 1; v185_11_label <= 2; ++v185_11_label) {
        const Space v185_11_tail = child(v179_12_tail,v185_11_label);
        if (v185_11_tail.empty()) continue;
        const Path v185_11_head{v185_11_label};
        const Space v186_2 = singleton(v185_11_head);
        const Space v186_3 = intersect(constant_6,v186_2);
        const Space v186_4 = (has_head(v186_3) ? constant_7 : Space{});
        const Space v186_5 = subtract(constant_0,v186_4);
        Space v186_7;
        if (!v186_5.empty()) {
          const Space v187_6 = routine_20(c, v185_11_head, v185_6, v185_11_tail, s1);
          v186_7 = compose(v186_5,v187_6);
        }
        const Space v186_8 = intersect(constant_6,v186_2);
        const Space v186_9 = (has_head(v186_8) ? constant_7 : Space{});
        Space v186_11;
        if (!v186_9.empty()) {
          const Space v188_10 = routine_21(c, v185_11_head, v185_6, v185_11_tail, s1);
          v186_11 = compose(v186_9,v188_10);
        }
        const Space v186_12 = unite(v186_7,v186_11);
        v185_11_result = unite(v185_11_result,v186_12);
      }
      const Space v185_11 = std::move(v185_11_result);
      v180_12 = compose(v180_10,v185_11);
    }
    const Space v180_13 = unite(v180_8,v180_12);
    v179_12_result = unite(v179_12_result,v180_13);
  }
  const Space v179_12 = std::move(v179_12_result);
  return v179_12;
}

static Space routine_19(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v189_12_result;
  for (int v189_12_label = 1; v189_12_label <= 2; ++v189_12_label) {
    const Space v189_12_tail = child(s0,v189_12_label);
    if (v189_12_tail.empty()) continue;
    const Path v189_12_head{v189_12_label};
    const Space v190_2 = singleton(v189_12_head);
    const Space v190_3 = intersect(constant_6,v190_2);
    const Space v190_4 = (has_head(v190_3) ? constant_7 : Space{});
    const Space v190_5 = subtract(constant_0,v190_4);
    Space v190_7;
    if (!v190_5.empty()) {
      Space v191_6_result;
      for (int v191_6_label = 1; v191_6_label <= 2; ++v191_6_label) {
        const Space v191_6_tail = child(v189_12_tail,v191_6_label);
        if (v191_6_tail.empty()) continue;
        const Path v191_6_head{v191_6_label};
        const Space v192_2 = singleton(v191_6_head);
        const Space v192_3 = intersect(constant_6,v192_2);
        const Space v192_4 = (has_head(v192_3) ? constant_7 : Space{});
        const Space v192_5 = subtract(constant_0,v192_4);
        Space v192_8;
        if (!v192_5.empty()) {
          const Path v193_6 = concat_path(v189_12_head,v191_6_head);
          const Space v193_7 = routine_47(c, v193_6, p0, v191_6_tail, s1);
          v192_8 = compose(v192_5,v193_7);
        }
        const Space v192_9 = intersect(constant_6,v192_2);
        const Space v192_10 = (has_head(v192_9) ? constant_7 : Space{});
        Space v192_12;
        if (!v192_10.empty()) {
          const Path v194_6 = concat_path(v189_12_head,v191_6_head);
          const Space v194_11 = routine_48(c, v194_6, p0, v191_6_tail, s1);
          v192_12 = compose(v192_10,v194_11);
        }
        const Space v192_13 = unite(v192_8,v192_12);
        v191_6_result = unite(v191_6_result,v192_13);
      }
      const Space v191_6 = std::move(v191_6_result);
      v190_7 = compose(v190_5,v191_6);
    }
    const Space v190_8 = intersect(constant_6,v190_2);
    const Space v190_9 = (has_head(v190_8) ? constant_7 : Space{});
    Space v190_11;
    if (!v190_9.empty()) {
      Space v195_10_result;
      for (int v195_10_label = 1; v195_10_label <= 2; ++v195_10_label) {
        const Space v195_10_tail = child(v189_12_tail,v195_10_label);
        if (v195_10_tail.empty()) continue;
        const Path v195_10_head{v195_10_label};
        const Space v196_2 = singleton(v195_10_head);
        const Space v196_3 = intersect(constant_6,v196_2);
        const Space v196_4 = (has_head(v196_3) ? constant_7 : Space{});
        const Space v196_5 = subtract(constant_0,v196_4);
        Space v196_8;
        if (!v196_5.empty()) {
          const Path v197_6 = concat_path(v189_12_head,v195_10_head);
          const Space v197_7 = routine_47(c, v197_6, p0, v195_10_tail, s1);
          v196_8 = compose(v196_5,v197_7);
        }
        const Space v196_9 = intersect(constant_6,v196_2);
        const Space v196_10 = (has_head(v196_9) ? constant_7 : Space{});
        Space v196_12;
        if (!v196_10.empty()) {
          const Path v198_6 = concat_path(v189_12_head,v195_10_head);
          const Space v198_11 = routine_49(c, v198_6, p0, v195_10_tail, s1);
          v196_12 = compose(v196_10,v198_11);
        }
        const Space v196_13 = unite(v196_8,v196_12);
        v195_10_result = unite(v195_10_result,v196_13);
      }
      const Space v195_10 = std::move(v195_10_result);
      v190_11 = compose(v190_9,v195_10);
    }
    const Space v190_12 = unite(v190_7,v190_11);
    v189_12_result = unite(v189_12_result,v190_12);
  }
  const Space v189_12 = std::move(v189_12_result);
  return v189_12;
}

static Space routine_20(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v199_13_result;
  for (int v199_13_label = 1; v199_13_label <= 2; ++v199_13_label) {
    const Space v199_13_tail = child(s0,v199_13_label);
    if (v199_13_tail.empty()) continue;
    const Path v199_13_head{v199_13_label};
    const Space v200_2 = singleton(v199_13_head);
    const Space v200_3 = intersect(constant_6,v200_2);
    const Space v200_4 = (has_head(v200_3) ? constant_7 : Space{});
    const Space v200_5 = subtract(constant_0,v200_4);
    Space v200_8;
    if (!v200_5.empty()) {
      const Path v201_6 = concat_path(p0,v199_13_head);
      Space v201_7_result;
      for (int v201_7_label = 1; v201_7_label <= 2; ++v201_7_label) {
        const Space v201_7_tail = child(v199_13_tail,v201_7_label);
        if (v201_7_tail.empty()) continue;
        const Path v201_7_head{v201_7_label};
        const Space v202_2 = singleton(v201_7_head);
        const Space v202_3 = intersect(constant_6,v202_2);
        const Space v202_4 = (has_head(v202_3) ? constant_7 : Space{});
        const Space v202_5 = subtract(constant_0,v202_4);
        Space v202_8;
        if (!v202_5.empty()) {
          const Path v203_6 = concat_path(v201_6,v201_7_head);
          const Space v203_7 = routine_50(c, v203_6, p1, v201_7_tail, s1);
          v202_8 = compose(v202_5,v203_7);
        }
        const Space v202_9 = intersect(constant_6,v202_2);
        const Space v202_10 = (has_head(v202_9) ? constant_7 : Space{});
        Space v202_12;
        if (!v202_10.empty()) {
          const Path v204_6 = concat_path(v201_6,v201_7_head);
          const Space v204_11 = routine_51(c, v204_6, p1, v201_7_tail, s1);
          v202_12 = compose(v202_10,v204_11);
        }
        const Space v202_13 = unite(v202_8,v202_12);
        v201_7_result = unite(v201_7_result,v202_13);
      }
      const Space v201_7 = std::move(v201_7_result);
      v200_8 = compose(v200_5,v201_7);
    }
    const Space v200_9 = intersect(constant_6,v200_2);
    const Space v200_10 = (has_head(v200_9) ? constant_7 : Space{});
    Space v200_12;
    if (!v200_10.empty()) {
      const Path v205_6 = concat_path(p0,v199_13_head);
      Space v205_11_result;
      for (int v205_11_label = 1; v205_11_label <= 2; ++v205_11_label) {
        const Space v205_11_tail = child(v199_13_tail,v205_11_label);
        if (v205_11_tail.empty()) continue;
        const Path v205_11_head{v205_11_label};
        const Space v206_2 = singleton(v205_11_head);
        const Space v206_3 = intersect(constant_6,v206_2);
        const Space v206_4 = (has_head(v206_3) ? constant_7 : Space{});
        const Space v206_5 = subtract(constant_0,v206_4);
        Space v206_8;
        if (!v206_5.empty()) {
          const Path v207_6 = concat_path(v205_6,v205_11_head);
          const Space v207_7 = routine_50(c, v207_6, p1, v205_11_tail, s1);
          v206_8 = compose(v206_5,v207_7);
        }
        const Space v206_9 = intersect(constant_6,v206_2);
        const Space v206_10 = (has_head(v206_9) ? constant_7 : Space{});
        Space v206_12;
        if (!v206_10.empty()) {
          const Path v208_6 = concat_path(v205_6,v205_11_head);
          const Space v208_11 = routine_49(c, v208_6, p1, v205_11_tail, s1);
          v206_12 = compose(v206_10,v208_11);
        }
        const Space v206_13 = unite(v206_8,v206_12);
        v205_11_result = unite(v205_11_result,v206_13);
      }
      const Space v205_11 = std::move(v205_11_result);
      v200_12 = compose(v200_10,v205_11);
    }
    const Space v200_13 = unite(v200_8,v200_12);
    v199_13_result = unite(v199_13_result,v200_13);
  }
  const Space v199_13 = std::move(v199_13_result);
  return v199_13;
}

static Space routine_21(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v209_8 = unwrap(s1,constant_8);
  Space v209_21_result;
  for (int v209_21_label = 1; v209_21_label <= 2; ++v209_21_label) {
    const Space v209_21_tail = child(s0,v209_21_label);
    if (v209_21_tail.empty()) continue;
    const Path v209_21_head{v209_21_label};
    const Space v210_2 = singleton(v209_21_head);
    const Space v210_3 = intersect(constant_6,v210_2);
    const Space v210_4 = (has_head(v210_3) ? constant_7 : Space{});
    const Space v210_5 = subtract(constant_0,v210_4);
    Space v210_8;
    if (!v210_5.empty()) {
      const Path v211_6 = concat_path(p0,v209_21_head);
      Space v211_7_result;
      for (int v211_7_label = 1; v211_7_label <= 2; ++v211_7_label) {
        const Space v211_7_tail = child(v209_21_tail,v211_7_label);
        if (v211_7_tail.empty()) continue;
        const Path v211_7_head{v211_7_label};
        const Space v212_2 = singleton(v211_7_head);
        const Space v212_3 = intersect(constant_6,v212_2);
        const Space v212_4 = (has_head(v212_3) ? constant_7 : Space{});
        const Space v212_5 = subtract(constant_0,v212_4);
        Space v212_8;
        if (!v212_5.empty()) {
          const Path v213_6 = concat_path(v211_6,v211_7_head);
          const Space v213_7 = routine_50(c, v213_6, p1, v211_7_tail, s1);
          v212_8 = compose(v212_5,v213_7);
        }
        const Space v212_9 = intersect(constant_6,v212_2);
        const Space v212_10 = (has_head(v212_9) ? constant_7 : Space{});
        Space v212_12;
        if (!v212_10.empty()) {
          const Path v214_6 = concat_path(v211_6,v211_7_head);
          const Space v214_11 = routine_51(c, v214_6, p1, v211_7_tail, s1);
          v212_12 = compose(v212_10,v214_11);
        }
        const Space v212_13 = unite(v212_8,v212_12);
        v211_7_result = unite(v211_7_result,v212_13);
      }
      const Space v211_7 = std::move(v211_7_result);
      v210_8 = compose(v210_5,v211_7);
    }
    const Space v210_9 = intersect(constant_6,v210_2);
    const Space v210_10 = (has_head(v210_9) ? constant_7 : Space{});
    Space v210_22;
    if (!v210_10.empty()) {
      const Path v215_6 = concat_path(p0,v209_21_head);
      const Path v215_11 = concat_path(p1,v215_6);
      const Space v215_12 = routine_29(c, v215_11);
      const Space v215_13 = intersect(v209_8,v215_12);
      const Space v215_14 = routine_33(c, v215_13);
      Space v215_15_result;
      for (int v215_15_label = 1; v215_15_label <= 2; ++v215_15_label) {
        const Space v215_15_tail = child(v215_14,v215_15_label);
        if (v215_15_tail.empty()) continue;
        const Path v215_15_head{v215_15_label};
        const Space v216_2 = singleton(v215_15_head);
        const Space v216_3 = intersect(constant_6,v216_2);
        const Space v216_4 = (has_head(v216_3) ? constant_7 : Space{});
        const Space v216_5 = subtract(constant_0,v216_4);
        Space v216_7;
        if (!v216_5.empty()) {
          const Space v217_6 = routine_52(c, v215_15_head, v215_15_tail);
          v216_7 = compose(v216_5,v217_6);
        }
        const Space v216_8 = intersect(constant_6,v216_2);
        const Space v216_9 = (has_head(v216_8) ? constant_7 : Space{});
        Space v216_11;
        if (!v216_9.empty()) {
          const Space v218_10 = routine_53(c, v215_15_head, v215_15_tail);
          v216_11 = compose(v216_9,v218_10);
        }
        const Space v216_12 = unite(v216_7,v216_11);
        v215_15_result = unite(v215_15_result,v216_12);
      }
      const Space v215_15 = std::move(v215_15_result);
      const Space v215_16 = routine_54(c, v215_13);
      Space v215_17_result;
      for (int v215_17_label = 1; v215_17_label <= 2; ++v215_17_label) {
        const Space v215_17_tail = child(v215_16,v215_17_label);
        if (v215_17_tail.empty()) continue;
        const Path v215_17_head{v215_17_label};
        const Space v219_2 = singleton(v215_17_head);
        const Space v219_3 = intersect(constant_6,v219_2);
        const Space v219_4 = (has_head(v219_3) ? constant_7 : Space{});
        const Space v219_5 = subtract(constant_0,v219_4);
        Space v219_7;
        if (!v219_5.empty()) {
          const Space v220_6 = routine_55(c, v215_17_head, v215_17_tail);
          v219_7 = compose(v219_5,v220_6);
        }
        const Space v219_8 = intersect(constant_6,v219_2);
        const Space v219_9 = (has_head(v219_8) ? constant_7 : Space{});
        Space v219_11;
        if (!v219_9.empty()) {
          const Space v221_10 = routine_56(c, v215_17_head, v215_17_tail);
          v219_11 = compose(v219_9,v221_10);
        }
        const Space v219_12 = unite(v219_7,v219_11);
        v215_17_result = unite(v215_17_result,v219_12);
      }
      const Space v215_17 = std::move(v215_17_result);
      const Space v215_18 = subtract(v215_15,v215_17);
      const Space v215_19 = singleton(v215_11);
      const Space v215_20 = compose(v215_18,v215_19);
      Space v215_21_result;
      for (int v215_21_label = 1; v215_21_label <= 2; ++v215_21_label) {
        const Space v215_21_tail = child(v215_20,v215_21_label);
        if (v215_21_tail.empty()) continue;
        const Path v215_21_head{v215_21_label};
        const Space v222_2 = singleton(v215_21_head);
        const Space v222_3 = intersect(constant_6,v222_2);
        const Space v222_4 = (has_head(v222_3) ? constant_7 : Space{});
        const Space v222_5 = subtract(constant_0,v222_4);
        Space v222_7;
        if (!v222_5.empty()) {
          const Space v223_6 = routine_57(c, v215_21_head, v215_21_tail);
          v222_7 = compose(v222_5,v223_6);
        }
        const Space v222_8 = intersect(constant_6,v222_2);
        const Space v222_9 = (has_head(v222_8) ? constant_7 : Space{});
        Space v222_11;
        if (!v222_9.empty()) {
          const Space v224_10 = routine_58(c, v215_21_head, v215_21_tail);
          v222_11 = compose(v222_9,v224_10);
        }
        const Space v222_12 = unite(v222_7,v222_11);
        v215_21_result = unite(v215_21_result,v222_12);
      }
      const Space v215_21 = std::move(v215_21_result);
      v210_22 = compose(v210_10,v215_21);
    }
    const Space v210_23 = unite(v210_8,v210_22);
    v209_21_result = unite(v209_21_result,v210_23);
  }
  const Space v209_21 = std::move(v209_21_result);
  return v209_21;
}

static Space routine_22(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v225_12_result;
  for (int v225_12_label = 1; v225_12_label <= 2; ++v225_12_label) {
    const Space v225_12_tail = child(s0,v225_12_label);
    if (v225_12_tail.empty()) continue;
    const Path v225_12_head{v225_12_label};
    const Space v226_2 = singleton(v225_12_head);
    const Space v226_3 = intersect(constant_6,v226_2);
    const Space v226_4 = (has_head(v226_3) ? constant_7 : Space{});
    const Space v226_5 = subtract(constant_0,v226_4);
    Space v226_8;
    if (!v226_5.empty()) {
      const Path v227_6 = concat_path(p0,v225_12_head);
      Space v227_7_result;
      for (int v227_7_label = 1; v227_7_label <= 2; ++v227_7_label) {
        const Space v227_7_tail = child(v225_12_tail,v227_7_label);
        if (v227_7_tail.empty()) continue;
        const Path v227_7_head{v227_7_label};
        const Space v228_2 = singleton(v227_7_head);
        const Space v228_3 = intersect(constant_6,v228_2);
        const Space v228_4 = (has_head(v228_3) ? constant_7 : Space{});
        const Space v228_5 = subtract(constant_0,v228_4);
        Space v228_8;
        if (!v228_5.empty()) {
          const Path v229_6 = concat_path(v227_6,v227_7_head);
          const Space v229_7 = routine_59(c, v229_6, v227_7_tail, s1);
          v228_8 = compose(v228_5,v229_7);
        }
        const Space v228_9 = intersect(constant_6,v228_2);
        const Space v228_10 = (has_head(v228_9) ? constant_7 : Space{});
        Space v228_12;
        if (!v228_10.empty()) {
          const Path v230_6 = concat_path(v227_6,v227_7_head);
          const Space v230_11 = routine_60(c, v230_6, v227_7_tail, s1);
          v228_12 = compose(v228_10,v230_11);
        }
        const Space v228_13 = unite(v228_8,v228_12);
        v227_7_result = unite(v227_7_result,v228_13);
      }
      const Space v227_7 = std::move(v227_7_result);
      v226_8 = compose(v226_5,v227_7);
    }
    const Space v226_9 = intersect(constant_6,v226_2);
    const Space v226_10 = (has_head(v226_9) ? constant_7 : Space{});
    Space v226_12;
    if (!v226_10.empty()) {
      const Path v231_6 = concat_path(p0,v225_12_head);
      Space v231_11_result;
      for (int v231_11_label = 1; v231_11_label <= 2; ++v231_11_label) {
        const Space v231_11_tail = child(v225_12_tail,v231_11_label);
        if (v231_11_tail.empty()) continue;
        const Path v231_11_head{v231_11_label};
        const Space v232_2 = singleton(v231_11_head);
        const Space v232_3 = intersect(constant_6,v232_2);
        const Space v232_4 = (has_head(v232_3) ? constant_7 : Space{});
        const Space v232_5 = subtract(constant_0,v232_4);
        Space v232_8;
        if (!v232_5.empty()) {
          const Path v233_6 = concat_path(v231_6,v231_11_head);
          const Space v233_7 = routine_59(c, v233_6, v231_11_tail, s1);
          v232_8 = compose(v232_5,v233_7);
        }
        const Space v232_9 = intersect(constant_6,v232_2);
        const Space v232_10 = (has_head(v232_9) ? constant_7 : Space{});
        Space v232_12;
        if (!v232_10.empty()) {
          const Path v234_6 = concat_path(v231_6,v231_11_head);
          const Space v234_11 = routine_9(c, v234_6, v231_11_tail, s1);
          v232_12 = compose(v232_10,v234_11);
        }
        const Space v232_13 = unite(v232_8,v232_12);
        v231_11_result = unite(v231_11_result,v232_13);
      }
      const Space v231_11 = std::move(v231_11_result);
      v226_12 = compose(v226_10,v231_11);
    }
    const Space v226_13 = unite(v226_8,v226_12);
    v225_12_result = unite(v225_12_result,v226_13);
  }
  const Space v225_12 = std::move(v225_12_result);
  return v225_12;
}

static Space routine_23(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v235_12_result;
  for (int v235_12_label = 1; v235_12_label <= 2; ++v235_12_label) {
    const Space v235_12_tail = child(s0,v235_12_label);
    if (v235_12_tail.empty()) continue;
    const Path v235_12_head{v235_12_label};
    const Space v236_2 = singleton(v235_12_head);
    const Space v236_3 = intersect(constant_6,v236_2);
    const Space v236_4 = (has_head(v236_3) ? constant_7 : Space{});
    const Space v236_5 = subtract(constant_0,v236_4);
    Space v236_8;
    if (!v236_5.empty()) {
      const Path v237_6 = concat_path(p0,v235_12_head);
      Space v237_7_result;
      for (int v237_7_label = 1; v237_7_label <= 2; ++v237_7_label) {
        const Space v237_7_tail = child(v235_12_tail,v237_7_label);
        if (v237_7_tail.empty()) continue;
        const Path v237_7_head{v237_7_label};
        const Space v238_2 = singleton(v237_7_head);
        const Space v238_3 = intersect(constant_6,v238_2);
        const Space v238_4 = (has_head(v238_3) ? constant_7 : Space{});
        const Space v238_5 = subtract(constant_0,v238_4);
        Space v238_8;
        if (!v238_5.empty()) {
          const Path v239_6 = concat_path(v237_6,v237_7_head);
          const Space v239_7 = routine_59(c, v239_6, v237_7_tail, s1);
          v238_8 = compose(v238_5,v239_7);
        }
        const Space v238_9 = intersect(constant_6,v238_2);
        const Space v238_10 = (has_head(v238_9) ? constant_7 : Space{});
        Space v238_12;
        if (!v238_10.empty()) {
          const Path v240_6 = concat_path(v237_6,v237_7_head);
          const Space v240_11 = routine_60(c, v240_6, v237_7_tail, s1);
          v238_12 = compose(v238_10,v240_11);
        }
        const Space v238_13 = unite(v238_8,v238_12);
        v237_7_result = unite(v237_7_result,v238_13);
      }
      const Space v237_7 = std::move(v237_7_result);
      v236_8 = compose(v236_5,v237_7);
    }
    const Space v236_9 = intersect(constant_6,v236_2);
    const Space v236_10 = (has_head(v236_9) ? constant_7 : Space{});
    Space v236_12;
    if (!v236_10.empty()) {
      const Path v241_6 = concat_path(p0,v235_12_head);
      Space v241_11_result;
      for (int v241_11_label = 1; v241_11_label <= 2; ++v241_11_label) {
        const Space v241_11_tail = child(v235_12_tail,v241_11_label);
        if (v241_11_tail.empty()) continue;
        const Path v241_11_head{v241_11_label};
        const Space v242_2 = singleton(v241_11_head);
        const Space v242_3 = intersect(constant_6,v242_2);
        const Space v242_4 = (has_head(v242_3) ? constant_7 : Space{});
        const Space v242_5 = subtract(constant_0,v242_4);
        Space v242_7;
        if (!v242_5.empty()) {
          const Space v243_6 = routine_10(c, v241_11_head, v241_6, v241_11_tail, s1);
          v242_7 = compose(v242_5,v243_6);
        }
        const Space v242_8 = intersect(constant_6,v242_2);
        const Space v242_9 = (has_head(v242_8) ? constant_7 : Space{});
        Space v242_11;
        if (!v242_9.empty()) {
          const Space v244_10 = routine_11(c, v241_11_head, v241_6, v241_11_tail, s1);
          v242_11 = compose(v242_9,v244_10);
        }
        const Space v242_12 = unite(v242_7,v242_11);
        v241_11_result = unite(v241_11_result,v242_12);
      }
      const Space v241_11 = std::move(v241_11_result);
      v236_12 = compose(v236_10,v241_11);
    }
    const Space v236_13 = unite(v236_8,v236_12);
    v235_12_result = unite(v235_12_result,v236_13);
  }
  const Space v235_12 = std::move(v235_12_result);
  return v235_12;
}

static Space routine_24(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v245_13_result;
  for (int v245_13_label = 1; v245_13_label <= 2; ++v245_13_label) {
    const Space v245_13_tail = child(s0,v245_13_label);
    if (v245_13_tail.empty()) continue;
    const Path v245_13_head{v245_13_label};
    const Space v246_2 = singleton(v245_13_head);
    const Space v246_3 = intersect(constant_6,v246_2);
    const Space v246_4 = (has_head(v246_3) ? constant_7 : Space{});
    const Space v246_5 = subtract(constant_0,v246_4);
    Space v246_8;
    if (!v246_5.empty()) {
      const Path v247_6 = concat_path(p0,v245_13_head);
      Space v247_7_result;
      for (int v247_7_label = 1; v247_7_label <= 2; ++v247_7_label) {
        const Space v247_7_tail = child(v245_13_tail,v247_7_label);
        if (v247_7_tail.empty()) continue;
        const Path v247_7_head{v247_7_label};
        const Space v248_2 = singleton(v247_7_head);
        const Space v248_3 = intersect(constant_6,v248_2);
        const Space v248_4 = (has_head(v248_3) ? constant_7 : Space{});
        const Space v248_5 = subtract(constant_0,v248_4);
        Space v248_8;
        if (!v248_5.empty()) {
          const Path v249_6 = concat_path(v247_6,v247_7_head);
          const Space v249_7 = routine_61(c, v249_6, p1, v247_7_tail, s1);
          v248_8 = compose(v248_5,v249_7);
        }
        const Space v248_9 = intersect(constant_6,v248_2);
        const Space v248_10 = (has_head(v248_9) ? constant_7 : Space{});
        Space v248_12;
        if (!v248_10.empty()) {
          const Path v250_6 = concat_path(v247_6,v247_7_head);
          const Space v250_11 = routine_62(c, v250_6, p1, v247_7_tail, s1);
          v248_12 = compose(v248_10,v250_11);
        }
        const Space v248_13 = unite(v248_8,v248_12);
        v247_7_result = unite(v247_7_result,v248_13);
      }
      const Space v247_7 = std::move(v247_7_result);
      v246_8 = compose(v246_5,v247_7);
    }
    const Space v246_9 = intersect(constant_6,v246_2);
    const Space v246_10 = (has_head(v246_9) ? constant_7 : Space{});
    Space v246_12;
    if (!v246_10.empty()) {
      const Path v251_6 = concat_path(p0,v245_13_head);
      Space v251_11_result;
      for (int v251_11_label = 1; v251_11_label <= 2; ++v251_11_label) {
        const Space v251_11_tail = child(v245_13_tail,v251_11_label);
        if (v251_11_tail.empty()) continue;
        const Path v251_11_head{v251_11_label};
        const Space v252_2 = singleton(v251_11_head);
        const Space v252_3 = intersect(constant_6,v252_2);
        const Space v252_4 = (has_head(v252_3) ? constant_7 : Space{});
        const Space v252_5 = subtract(constant_0,v252_4);
        Space v252_8;
        if (!v252_5.empty()) {
          const Path v253_6 = concat_path(v251_6,v251_11_head);
          const Space v253_7 = routine_61(c, v253_6, p1, v251_11_tail, s1);
          v252_8 = compose(v252_5,v253_7);
        }
        const Space v252_9 = intersect(constant_6,v252_2);
        const Space v252_10 = (has_head(v252_9) ? constant_7 : Space{});
        Space v252_12;
        if (!v252_10.empty()) {
          const Path v254_6 = concat_path(v251_6,v251_11_head);
          const Space v254_11 = routine_26(c, v254_6, p1, v251_11_tail, s1);
          v252_12 = compose(v252_10,v254_11);
        }
        const Space v252_13 = unite(v252_8,v252_12);
        v251_11_result = unite(v251_11_result,v252_13);
      }
      const Space v251_11 = std::move(v251_11_result);
      v246_12 = compose(v246_10,v251_11);
    }
    const Space v246_13 = unite(v246_8,v246_12);
    v245_13_result = unite(v245_13_result,v246_13);
  }
  const Space v245_13 = std::move(v245_13_result);
  return v245_13;
}

static Space routine_25(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v255_8 = unwrap(s1,constant_8);
  Space v255_21_result;
  for (int v255_21_label = 1; v255_21_label <= 2; ++v255_21_label) {
    const Space v255_21_tail = child(s0,v255_21_label);
    if (v255_21_tail.empty()) continue;
    const Path v255_21_head{v255_21_label};
    const Space v256_2 = singleton(v255_21_head);
    const Space v256_3 = intersect(constant_6,v256_2);
    const Space v256_4 = (has_head(v256_3) ? constant_7 : Space{});
    const Space v256_5 = subtract(constant_0,v256_4);
    Space v256_8;
    if (!v256_5.empty()) {
      const Path v257_6 = concat_path(p0,v255_21_head);
      Space v257_7_result;
      for (int v257_7_label = 1; v257_7_label <= 2; ++v257_7_label) {
        const Space v257_7_tail = child(v255_21_tail,v257_7_label);
        if (v257_7_tail.empty()) continue;
        const Path v257_7_head{v257_7_label};
        const Space v258_2 = singleton(v257_7_head);
        const Space v258_3 = intersect(constant_6,v258_2);
        const Space v258_4 = (has_head(v258_3) ? constant_7 : Space{});
        const Space v258_5 = subtract(constant_0,v258_4);
        Space v258_8;
        if (!v258_5.empty()) {
          const Path v259_6 = concat_path(v257_6,v257_7_head);
          const Space v259_7 = routine_61(c, v259_6, p1, v257_7_tail, s1);
          v258_8 = compose(v258_5,v259_7);
        }
        const Space v258_9 = intersect(constant_6,v258_2);
        const Space v258_10 = (has_head(v258_9) ? constant_7 : Space{});
        Space v258_12;
        if (!v258_10.empty()) {
          const Path v260_6 = concat_path(v257_6,v257_7_head);
          const Space v260_11 = routine_62(c, v260_6, p1, v257_7_tail, s1);
          v258_12 = compose(v258_10,v260_11);
        }
        const Space v258_13 = unite(v258_8,v258_12);
        v257_7_result = unite(v257_7_result,v258_13);
      }
      const Space v257_7 = std::move(v257_7_result);
      v256_8 = compose(v256_5,v257_7);
    }
    const Space v256_9 = intersect(constant_6,v256_2);
    const Space v256_10 = (has_head(v256_9) ? constant_7 : Space{});
    Space v256_22;
    if (!v256_10.empty()) {
      const Path v261_6 = concat_path(p0,v255_21_head);
      const Path v261_11 = concat_path(p1,v261_6);
      const Space v261_12 = routine_29(c, v261_11);
      const Space v261_13 = intersect(v255_8,v261_12);
      const Space v261_14 = routine_30(c, v261_13);
      Space v261_15_result;
      for (int v261_15_label = 1; v261_15_label <= 2; ++v261_15_label) {
        const Space v261_15_tail = child(v261_14,v261_15_label);
        if (v261_15_tail.empty()) continue;
        const Path v261_15_head{v261_15_label};
        const Space v262_2 = singleton(v261_15_head);
        const Space v262_3 = intersect(constant_6,v262_2);
        const Space v262_4 = (has_head(v262_3) ? constant_7 : Space{});
        const Space v262_5 = subtract(constant_0,v262_4);
        Space v262_7;
        if (!v262_5.empty()) {
          const Space v263_6 = routine_31(c, v261_15_head, v261_15_tail);
          v262_7 = compose(v262_5,v263_6);
        }
        const Space v262_8 = intersect(constant_6,v262_2);
        const Space v262_9 = (has_head(v262_8) ? constant_7 : Space{});
        Space v262_11;
        if (!v262_9.empty()) {
          const Space v264_10 = routine_32(c, v261_15_head, v261_15_tail);
          v262_11 = compose(v262_9,v264_10);
        }
        const Space v262_12 = unite(v262_7,v262_11);
        v261_15_result = unite(v261_15_result,v262_12);
      }
      const Space v261_15 = std::move(v261_15_result);
      const Space v261_16 = routine_33(c, v261_13);
      Space v261_17_result;
      for (int v261_17_label = 1; v261_17_label <= 2; ++v261_17_label) {
        const Space v261_17_tail = child(v261_16,v261_17_label);
        if (v261_17_tail.empty()) continue;
        const Path v261_17_head{v261_17_label};
        const Space v265_2 = singleton(v261_17_head);
        const Space v265_3 = intersect(constant_6,v265_2);
        const Space v265_4 = (has_head(v265_3) ? constant_7 : Space{});
        const Space v265_5 = subtract(constant_0,v265_4);
        Space v265_7;
        if (!v265_5.empty()) {
          const Space v266_6 = routine_34(c, v261_17_head, v261_17_tail);
          v265_7 = compose(v265_5,v266_6);
        }
        const Space v265_8 = intersect(constant_6,v265_2);
        const Space v265_9 = (has_head(v265_8) ? constant_7 : Space{});
        Space v265_11;
        if (!v265_9.empty()) {
          const Space v267_10 = routine_35(c, v261_17_head, v261_17_tail);
          v265_11 = compose(v265_9,v267_10);
        }
        const Space v265_12 = unite(v265_7,v265_11);
        v261_17_result = unite(v261_17_result,v265_12);
      }
      const Space v261_17 = std::move(v261_17_result);
      const Space v261_18 = subtract(v261_15,v261_17);
      const Space v261_19 = singleton(v261_11);
      const Space v261_20 = compose(v261_18,v261_19);
      Space v261_21_result;
      for (int v261_21_label = 1; v261_21_label <= 2; ++v261_21_label) {
        const Space v261_21_tail = child(v261_20,v261_21_label);
        if (v261_21_tail.empty()) continue;
        const Path v261_21_head{v261_21_label};
        const Space v268_2 = singleton(v261_21_head);
        const Space v268_3 = intersect(constant_6,v268_2);
        const Space v268_4 = (has_head(v268_3) ? constant_7 : Space{});
        const Space v268_5 = subtract(constant_0,v268_4);
        Space v268_7;
        if (!v268_5.empty()) {
          const Space v269_6 = routine_36(c, v261_21_head, v261_21_tail);
          v268_7 = compose(v268_5,v269_6);
        }
        const Space v268_8 = intersect(constant_6,v268_2);
        const Space v268_9 = (has_head(v268_8) ? constant_7 : Space{});
        Space v268_11;
        if (!v268_9.empty()) {
          const Space v270_10 = routine_37(c, v261_21_head, v261_21_tail);
          v268_11 = compose(v268_9,v270_10);
        }
        const Space v268_12 = unite(v268_7,v268_11);
        v261_21_result = unite(v261_21_result,v268_12);
      }
      const Space v261_21 = std::move(v261_21_result);
      v256_22 = compose(v256_10,v261_21);
    }
    const Space v256_23 = unite(v256_8,v256_22);
    v255_21_result = unite(v255_21_result,v256_23);
  }
  const Space v255_21 = std::move(v255_21_result);
  return v255_21;
}

static Space routine_26(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v271_5 = unwrap(s1,constant_8);
  const Path v271_6 = concat_path(p1,p0);
  const Space v271_7 = singleton(v271_6);
  Space v271_11_result;
  for (int v271_11_label = 1; v271_11_label <= 2; ++v271_11_label) {
    const Space v271_11_tail = child(v271_7,v271_11_label);
    if (v271_11_tail.empty()) continue;
    const Path v271_11_head{v271_11_label};
    const Space v272_2 = singleton(v271_11_head);
    const Space v272_3 = intersect(constant_6,v272_2);
    const Space v272_4 = (has_head(v272_3) ? constant_7 : Space{});
    const Space v272_5 = subtract(constant_0,v272_4);
    Space v272_7;
    if (!v272_5.empty()) {
      const Space v273_6 = routine_63(c, v271_11_head, v271_11_tail);
      v272_7 = compose(v272_5,v273_6);
    }
    const Space v272_8 = intersect(constant_6,v272_2);
    const Space v272_9 = (has_head(v272_8) ? constant_7 : Space{});
    Space v272_11;
    if (!v272_9.empty()) {
      const Space v274_10 = routine_64(c, v271_11_head, v271_11_tail);
      v272_11 = compose(v272_9,v274_10);
    }
    const Space v272_12 = unite(v272_7,v272_11);
    v271_11_result = unite(v271_11_result,v272_12);
  }
  const Space v271_11 = std::move(v271_11_result);
  const Space v271_12 = intersect(v271_5,v271_11);
  Space v271_16_result;
  for (int v271_16_label = 1; v271_16_label <= 2; ++v271_16_label) {
    const Space v271_16_tail = child(v271_7,v271_16_label);
    if (v271_16_tail.empty()) continue;
    const Path v271_16_head{v271_16_label};
    const Space v275_2 = singleton(v271_16_head);
    const Space v275_3 = intersect(constant_6,v275_2);
    const Space v275_4 = (has_head(v275_3) ? constant_7 : Space{});
    const Space v275_5 = subtract(constant_0,v275_4);
    Space v275_7;
    if (!v275_5.empty()) {
      const Space v276_6 = routine_63(c, v271_16_head, v271_16_tail);
      v275_7 = compose(v275_5,v276_6);
    }
    const Space v275_8 = intersect(constant_6,v275_2);
    const Space v275_9 = (has_head(v275_8) ? constant_7 : Space{});
    Space v275_11;
    if (!v275_9.empty()) {
      const Space v277_10 = routine_64(c, v271_16_head, v271_16_tail);
      v275_11 = compose(v275_9,v277_10);
    }
    const Space v275_12 = unite(v275_7,v275_11);
    v271_16_result = unite(v271_16_result,v275_12);
  }
  const Space v271_16 = std::move(v271_16_result);
  const Space v271_17 = intersect(v271_5,v271_16);
  const Space v271_18 = routine_65(c, v271_17);
  const Space v271_19 = subtract(v271_12,v271_18);
  Space v271_23_result;
  for (int v271_23_label = 1; v271_23_label <= 2; ++v271_23_label) {
    const Space v271_23_tail = child(v271_7,v271_23_label);
    if (v271_23_tail.empty()) continue;
    const Path v271_23_head{v271_23_label};
    const Space v278_2 = singleton(v271_23_head);
    const Space v278_3 = intersect(constant_6,v278_2);
    const Space v278_4 = (has_head(v278_3) ? constant_7 : Space{});
    const Space v278_5 = subtract(constant_0,v278_4);
    Space v278_7;
    if (!v278_5.empty()) {
      const Space v279_6 = routine_63(c, v271_23_head, v271_23_tail);
      v278_7 = compose(v278_5,v279_6);
    }
    const Space v278_8 = intersect(constant_6,v278_2);
    const Space v278_9 = (has_head(v278_8) ? constant_7 : Space{});
    Space v278_11;
    if (!v278_9.empty()) {
      const Space v280_10 = routine_64(c, v271_23_head, v271_23_tail);
      v278_11 = compose(v278_9,v280_10);
    }
    const Space v278_12 = unite(v278_7,v278_11);
    v271_23_result = unite(v271_23_result,v278_12);
  }
  const Space v271_23 = std::move(v271_23_result);
  const Space v271_24 = intersect(v271_5,v271_23);
  const Space v271_25 = routine_66(c, v271_24);
  const Space v271_26 = intersect(v271_19,v271_25);
  Space v271_36_result;
  for (int v271_36_label = 1; v271_36_label <= 2; ++v271_36_label) {
    const Space v271_36_tail = child(v271_26,v271_36_label);
    if (v271_36_tail.empty()) continue;
    const Path v271_36_head{v271_36_label};
    const Space v281_2 = singleton(v271_36_head);
    const Space v281_3 = intersect(constant_6,v281_2);
    const Space v281_4 = (has_head(v281_3) ? constant_7 : Space{});
    const Space v281_5 = subtract(constant_0,v281_4);
    Space v281_7;
    if (!v281_5.empty()) {
      Space v282_6_result;
      for (int v282_6_label = 1; v282_6_label <= 2; ++v282_6_label) {
        const Space v282_6_tail = child(v271_36_tail,v282_6_label);
        if (v282_6_tail.empty()) continue;
        const Path v282_6_head{v282_6_label};
        const Space v283_2 = singleton(v282_6_head);
        const Space v283_3 = intersect(constant_6,v283_2);
        const Space v283_4 = (has_head(v283_3) ? constant_7 : Space{});
        const Space v283_5 = subtract(constant_0,v283_4);
        Space v283_8;
        if (!v283_5.empty()) {
          const Path v284_6 = concat_path(v271_36_head,v282_6_head);
          const Space v284_7 = routine_67(c, v284_6, v282_6_tail);
          v283_8 = compose(v283_5,v284_7);
        }
        const Space v283_9 = intersect(constant_6,v283_2);
        const Space v283_10 = (has_head(v283_9) ? constant_7 : Space{});
        Space v283_12;
        if (!v283_10.empty()) {
          const Path v285_6 = concat_path(v271_36_head,v282_6_head);
          const Space v285_11 = routine_68(c, v285_6, v282_6_tail);
          v283_12 = compose(v283_10,v285_11);
        }
        const Space v283_13 = unite(v283_8,v283_12);
        v282_6_result = unite(v282_6_result,v283_13);
      }
      const Space v282_6 = std::move(v282_6_result);
      v281_7 = compose(v281_5,v282_6);
    }
    const Space v281_8 = intersect(constant_6,v281_2);
    const Space v281_9 = (has_head(v281_8) ? constant_7 : Space{});
    Space v281_11;
    if (!v281_9.empty()) {
      Space v286_10_result;
      for (int v286_10_label = 1; v286_10_label <= 2; ++v286_10_label) {
        const Space v286_10_tail = child(v271_36_tail,v286_10_label);
        if (v286_10_tail.empty()) continue;
        const Path v286_10_head{v286_10_label};
        const Space v287_2 = singleton(v286_10_head);
        const Space v287_3 = intersect(constant_6,v287_2);
        const Space v287_4 = (has_head(v287_3) ? constant_7 : Space{});
        const Space v287_5 = subtract(constant_0,v287_4);
        Space v287_8;
        if (!v287_5.empty()) {
          const Path v288_6 = concat_path(v271_36_head,v286_10_head);
          const Space v288_7 = routine_67(c, v288_6, v286_10_tail);
          v287_8 = compose(v287_5,v288_7);
        }
        const Space v287_9 = intersect(constant_6,v287_2);
        const Space v287_10 = (has_head(v287_9) ? constant_7 : Space{});
        Space v287_12;
        if (!v287_10.empty()) {
          const Path v289_6 = concat_path(v271_36_head,v286_10_head);
          const Space v289_11 = routine_69(c, v289_6, v286_10_tail);
          v287_12 = compose(v287_10,v289_11);
        }
        const Space v287_13 = unite(v287_8,v287_12);
        v286_10_result = unite(v286_10_result,v287_13);
      }
      const Space v286_10 = std::move(v286_10_result);
      v281_11 = compose(v281_9,v286_10);
    }
    const Space v281_12 = unite(v281_7,v281_11);
    v271_36_result = unite(v271_36_result,v281_12);
  }
  const Space v271_36 = std::move(v271_36_result);
  Space v271_40_result;
  for (int v271_40_label = 1; v271_40_label <= 2; ++v271_40_label) {
    const Space v271_40_tail = child(v271_7,v271_40_label);
    if (v271_40_tail.empty()) continue;
    const Path v271_40_head{v271_40_label};
    const Space v290_2 = singleton(v271_40_head);
    const Space v290_3 = intersect(constant_6,v290_2);
    const Space v290_4 = (has_head(v290_3) ? constant_7 : Space{});
    const Space v290_5 = subtract(constant_0,v290_4);
    Space v290_7;
    if (!v290_5.empty()) {
      const Space v291_6 = routine_63(c, v271_40_head, v271_40_tail);
      v290_7 = compose(v290_5,v291_6);
    }
    const Space v290_8 = intersect(constant_6,v290_2);
    const Space v290_9 = (has_head(v290_8) ? constant_7 : Space{});
    Space v290_11;
    if (!v290_9.empty()) {
      const Space v292_10 = routine_64(c, v271_40_head, v271_40_tail);
      v290_11 = compose(v290_9,v292_10);
    }
    const Space v290_12 = unite(v290_7,v290_11);
    v271_40_result = unite(v271_40_result,v290_12);
  }
  const Space v271_40 = std::move(v271_40_result);
  const Space v271_41 = intersect(v271_5,v271_40);
  Space v271_45_result;
  for (int v271_45_label = 1; v271_45_label <= 2; ++v271_45_label) {
    const Space v271_45_tail = child(v271_7,v271_45_label);
    if (v271_45_tail.empty()) continue;
    const Path v271_45_head{v271_45_label};
    const Space v293_2 = singleton(v271_45_head);
    const Space v293_3 = intersect(constant_6,v293_2);
    const Space v293_4 = (has_head(v293_3) ? constant_7 : Space{});
    const Space v293_5 = subtract(constant_0,v293_4);
    Space v293_7;
    if (!v293_5.empty()) {
      const Space v294_6 = routine_63(c, v271_45_head, v271_45_tail);
      v293_7 = compose(v293_5,v294_6);
    }
    const Space v293_8 = intersect(constant_6,v293_2);
    const Space v293_9 = (has_head(v293_8) ? constant_7 : Space{});
    Space v293_11;
    if (!v293_9.empty()) {
      const Space v295_10 = routine_64(c, v271_45_head, v271_45_tail);
      v293_11 = compose(v293_9,v295_10);
    }
    const Space v293_12 = unite(v293_7,v293_11);
    v271_45_result = unite(v271_45_result,v293_12);
  }
  const Space v271_45 = std::move(v271_45_result);
  const Space v271_46 = intersect(v271_5,v271_45);
  const Space v271_47 = routine_66(c, v271_46);
  const Space v271_48 = routine_65(c, v271_47);
  const Space v271_49 = subtract(v271_41,v271_48);
  Space v271_53_result;
  for (int v271_53_label = 1; v271_53_label <= 2; ++v271_53_label) {
    const Space v271_53_tail = child(v271_7,v271_53_label);
    if (v271_53_tail.empty()) continue;
    const Path v271_53_head{v271_53_label};
    const Space v296_2 = singleton(v271_53_head);
    const Space v296_3 = intersect(constant_6,v296_2);
    const Space v296_4 = (has_head(v296_3) ? constant_7 : Space{});
    const Space v296_5 = subtract(constant_0,v296_4);
    Space v296_7;
    if (!v296_5.empty()) {
      const Space v297_6 = routine_63(c, v271_53_head, v271_53_tail);
      v296_7 = compose(v296_5,v297_6);
    }
    const Space v296_8 = intersect(constant_6,v296_2);
    const Space v296_9 = (has_head(v296_8) ? constant_7 : Space{});
    Space v296_11;
    if (!v296_9.empty()) {
      const Space v298_10 = routine_64(c, v271_53_head, v271_53_tail);
      v296_11 = compose(v296_9,v298_10);
    }
    const Space v296_12 = unite(v296_7,v296_11);
    v271_53_result = unite(v271_53_result,v296_12);
  }
  const Space v271_53 = std::move(v271_53_result);
  const Space v271_54 = intersect(v271_5,v271_53);
  const Space v271_55 = routine_65(c, v271_54);
  const Space v271_56 = intersect(v271_49,v271_55);
  Space v271_66_result;
  for (int v271_66_label = 1; v271_66_label <= 2; ++v271_66_label) {
    const Space v271_66_tail = child(v271_56,v271_66_label);
    if (v271_66_tail.empty()) continue;
    const Path v271_66_head{v271_66_label};
    const Space v299_2 = singleton(v271_66_head);
    const Space v299_3 = intersect(constant_6,v299_2);
    const Space v299_4 = (has_head(v299_3) ? constant_7 : Space{});
    const Space v299_5 = subtract(constant_0,v299_4);
    Space v299_7;
    if (!v299_5.empty()) {
      Space v300_6_result;
      for (int v300_6_label = 1; v300_6_label <= 2; ++v300_6_label) {
        const Space v300_6_tail = child(v271_66_tail,v300_6_label);
        if (v300_6_tail.empty()) continue;
        const Path v300_6_head{v300_6_label};
        const Space v301_2 = singleton(v300_6_head);
        const Space v301_3 = intersect(constant_6,v301_2);
        const Space v301_4 = (has_head(v301_3) ? constant_7 : Space{});
        const Space v301_5 = subtract(constant_0,v301_4);
        Space v301_8;
        if (!v301_5.empty()) {
          const Path v302_6 = concat_path(v271_66_head,v300_6_head);
          const Space v302_7 = routine_70(c, v302_6, v300_6_tail);
          v301_8 = compose(v301_5,v302_7);
        }
        const Space v301_9 = intersect(constant_6,v301_2);
        const Space v301_10 = (has_head(v301_9) ? constant_7 : Space{});
        Space v301_12;
        if (!v301_10.empty()) {
          const Path v303_6 = concat_path(v271_66_head,v300_6_head);
          const Space v303_11 = routine_71(c, v303_6, v300_6_tail);
          v301_12 = compose(v301_10,v303_11);
        }
        const Space v301_13 = unite(v301_8,v301_12);
        v300_6_result = unite(v300_6_result,v301_13);
      }
      const Space v300_6 = std::move(v300_6_result);
      v299_7 = compose(v299_5,v300_6);
    }
    const Space v299_8 = intersect(constant_6,v299_2);
    const Space v299_9 = (has_head(v299_8) ? constant_7 : Space{});
    Space v299_11;
    if (!v299_9.empty()) {
      Space v304_10_result;
      for (int v304_10_label = 1; v304_10_label <= 2; ++v304_10_label) {
        const Space v304_10_tail = child(v271_66_tail,v304_10_label);
        if (v304_10_tail.empty()) continue;
        const Path v304_10_head{v304_10_label};
        const Space v305_2 = singleton(v304_10_head);
        const Space v305_3 = intersect(constant_6,v305_2);
        const Space v305_4 = (has_head(v305_3) ? constant_7 : Space{});
        const Space v305_5 = subtract(constant_0,v305_4);
        Space v305_8;
        if (!v305_5.empty()) {
          const Path v306_6 = concat_path(v271_66_head,v304_10_head);
          const Space v306_7 = routine_70(c, v306_6, v304_10_tail);
          v305_8 = compose(v305_5,v306_7);
        }
        const Space v305_9 = intersect(constant_6,v305_2);
        const Space v305_10 = (has_head(v305_9) ? constant_7 : Space{});
        Space v305_12;
        if (!v305_10.empty()) {
          const Path v307_6 = concat_path(v271_66_head,v304_10_head);
          const Space v307_11 = routine_72(c, v307_6, v304_10_tail);
          v305_12 = compose(v305_10,v307_11);
        }
        const Space v305_13 = unite(v305_8,v305_12);
        v304_10_result = unite(v304_10_result,v305_13);
      }
      const Space v304_10 = std::move(v304_10_result);
      v299_11 = compose(v299_9,v304_10);
    }
    const Space v299_12 = unite(v299_7,v299_11);
    v271_66_result = unite(v271_66_result,v299_12);
  }
  const Space v271_66 = std::move(v271_66_result);
  const Space v271_67 = subtract(v271_36,v271_66);
  const Space v271_68 = compose(v271_67,v271_7);
  Space v271_78_result;
  for (int v271_78_label = 1; v271_78_label <= 2; ++v271_78_label) {
    const Space v271_78_tail = child(v271_68,v271_78_label);
    if (v271_78_tail.empty()) continue;
    const Path v271_78_head{v271_78_label};
    const Space v308_2 = singleton(v271_78_head);
    const Space v308_3 = intersect(constant_6,v308_2);
    const Space v308_4 = (has_head(v308_3) ? constant_7 : Space{});
    const Space v308_5 = subtract(constant_0,v308_4);
    Space v308_7;
    if (!v308_5.empty()) {
      Space v309_6_result;
      for (int v309_6_label = 1; v309_6_label <= 2; ++v309_6_label) {
        const Space v309_6_tail = child(v271_78_tail,v309_6_label);
        if (v309_6_tail.empty()) continue;
        const Path v309_6_head{v309_6_label};
        const Space v310_2 = singleton(v309_6_head);
        const Space v310_3 = intersect(constant_6,v310_2);
        const Space v310_4 = (has_head(v310_3) ? constant_7 : Space{});
        const Space v310_5 = subtract(constant_0,v310_4);
        Space v310_8;
        if (!v310_5.empty()) {
          const Path v311_6 = concat_path(v271_78_head,v309_6_head);
          const Space v311_7 = routine_73(c, v311_6, v309_6_tail);
          v310_8 = compose(v310_5,v311_7);
        }
        const Space v310_9 = intersect(constant_6,v310_2);
        const Space v310_10 = (has_head(v310_9) ? constant_7 : Space{});
        Space v310_12;
        if (!v310_10.empty()) {
          const Path v312_6 = concat_path(v271_78_head,v309_6_head);
          const Space v312_11 = routine_74(c, v312_6, v309_6_tail);
          v310_12 = compose(v310_10,v312_11);
        }
        const Space v310_13 = unite(v310_8,v310_12);
        v309_6_result = unite(v309_6_result,v310_13);
      }
      const Space v309_6 = std::move(v309_6_result);
      v308_7 = compose(v308_5,v309_6);
    }
    const Space v308_8 = intersect(constant_6,v308_2);
    const Space v308_9 = (has_head(v308_8) ? constant_7 : Space{});
    Space v308_11;
    if (!v308_9.empty()) {
      Space v313_10_result;
      for (int v313_10_label = 1; v313_10_label <= 2; ++v313_10_label) {
        const Space v313_10_tail = child(v271_78_tail,v313_10_label);
        if (v313_10_tail.empty()) continue;
        const Path v313_10_head{v313_10_label};
        const Space v314_2 = singleton(v313_10_head);
        const Space v314_3 = intersect(constant_6,v314_2);
        const Space v314_4 = (has_head(v314_3) ? constant_7 : Space{});
        const Space v314_5 = subtract(constant_0,v314_4);
        Space v314_8;
        if (!v314_5.empty()) {
          const Path v315_6 = concat_path(v271_78_head,v313_10_head);
          const Space v315_7 = routine_73(c, v315_6, v313_10_tail);
          v314_8 = compose(v314_5,v315_7);
        }
        const Space v314_9 = intersect(constant_6,v314_2);
        const Space v314_10 = (has_head(v314_9) ? constant_7 : Space{});
        Space v314_12;
        if (!v314_10.empty()) {
          const Path v316_6 = concat_path(v271_78_head,v313_10_head);
          const Space v316_11 = routine_75(c, v316_6, v313_10_tail);
          v314_12 = compose(v314_10,v316_11);
        }
        const Space v314_13 = unite(v314_8,v314_12);
        v313_10_result = unite(v313_10_result,v314_13);
      }
      const Space v313_10 = std::move(v313_10_result);
      v308_11 = compose(v308_9,v313_10);
    }
    const Space v308_12 = unite(v308_7,v308_11);
    v271_78_result = unite(v271_78_result,v308_12);
  }
  const Space v271_78 = std::move(v271_78_result);
  return v271_78;
}

static Space routine_27(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v317_13_result;
  for (int v317_13_label = 1; v317_13_label <= 2; ++v317_13_label) {
    const Space v317_13_tail = child(s0,v317_13_label);
    if (v317_13_tail.empty()) continue;
    const Path v317_13_head{v317_13_label};
    const Space v318_2 = singleton(v317_13_head);
    const Space v318_3 = intersect(constant_6,v318_2);
    const Space v318_4 = (has_head(v318_3) ? constant_7 : Space{});
    const Space v318_5 = subtract(constant_0,v318_4);
    Space v318_8;
    if (!v318_5.empty()) {
      const Path v319_6 = concat_path(p0,v317_13_head);
      Space v319_7_result;
      for (int v319_7_label = 1; v319_7_label <= 2; ++v319_7_label) {
        const Space v319_7_tail = child(v317_13_tail,v319_7_label);
        if (v319_7_tail.empty()) continue;
        const Path v319_7_head{v319_7_label};
        const Space v320_2 = singleton(v319_7_head);
        const Space v320_3 = intersect(constant_6,v320_2);
        const Space v320_4 = (has_head(v320_3) ? constant_7 : Space{});
        const Space v320_5 = subtract(constant_0,v320_4);
        Space v320_8;
        if (!v320_5.empty()) {
          const Path v321_6 = concat_path(v319_6,v319_7_head);
          const Space v321_7 = routine_76(c, v321_6, p1, v319_7_tail, s1);
          v320_8 = compose(v320_5,v321_7);
        }
        const Space v320_9 = intersect(constant_6,v320_2);
        const Space v320_10 = (has_head(v320_9) ? constant_7 : Space{});
        Space v320_12;
        if (!v320_10.empty()) {
          const Path v322_6 = concat_path(v319_6,v319_7_head);
          const Space v322_11 = routine_77(c, v322_6, p1, v319_7_tail, s1);
          v320_12 = compose(v320_10,v322_11);
        }
        const Space v320_13 = unite(v320_8,v320_12);
        v319_7_result = unite(v319_7_result,v320_13);
      }
      const Space v319_7 = std::move(v319_7_result);
      v318_8 = compose(v318_5,v319_7);
    }
    const Space v318_9 = intersect(constant_6,v318_2);
    const Space v318_10 = (has_head(v318_9) ? constant_7 : Space{});
    Space v318_12;
    if (!v318_10.empty()) {
      const Path v323_6 = concat_path(p0,v317_13_head);
      Space v323_11_result;
      for (int v323_11_label = 1; v323_11_label <= 2; ++v323_11_label) {
        const Space v323_11_tail = child(v317_13_tail,v323_11_label);
        if (v323_11_tail.empty()) continue;
        const Path v323_11_head{v323_11_label};
        const Space v324_2 = singleton(v323_11_head);
        const Space v324_3 = intersect(constant_6,v324_2);
        const Space v324_4 = (has_head(v324_3) ? constant_7 : Space{});
        const Space v324_5 = subtract(constant_0,v324_4);
        Space v324_8;
        if (!v324_5.empty()) {
          const Path v325_6 = concat_path(v323_6,v323_11_head);
          const Space v325_7 = routine_76(c, v325_6, p1, v323_11_tail, s1);
          v324_8 = compose(v324_5,v325_7);
        }
        const Space v324_9 = intersect(constant_6,v324_2);
        const Space v324_10 = (has_head(v324_9) ? constant_7 : Space{});
        Space v324_12;
        if (!v324_10.empty()) {
          const Path v326_6 = concat_path(v323_6,v323_11_head);
          const Space v326_11 = routine_26(c, v326_6, p1, v323_11_tail, s1);
          v324_12 = compose(v324_10,v326_11);
        }
        const Space v324_13 = unite(v324_8,v324_12);
        v323_11_result = unite(v323_11_result,v324_13);
      }
      const Space v323_11 = std::move(v323_11_result);
      v318_12 = compose(v318_10,v323_11);
    }
    const Space v318_13 = unite(v318_8,v318_12);
    v317_13_result = unite(v317_13_result,v318_13);
  }
  const Space v317_13 = std::move(v317_13_result);
  return v317_13;
}

static Space routine_28(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v327_8 = unwrap(s1,constant_8);
  Space v327_21_result;
  for (int v327_21_label = 1; v327_21_label <= 2; ++v327_21_label) {
    const Space v327_21_tail = child(s0,v327_21_label);
    if (v327_21_tail.empty()) continue;
    const Path v327_21_head{v327_21_label};
    const Space v328_2 = singleton(v327_21_head);
    const Space v328_3 = intersect(constant_6,v328_2);
    const Space v328_4 = (has_head(v328_3) ? constant_7 : Space{});
    const Space v328_5 = subtract(constant_0,v328_4);
    Space v328_8;
    if (!v328_5.empty()) {
      const Path v329_6 = concat_path(p0,v327_21_head);
      Space v329_7_result;
      for (int v329_7_label = 1; v329_7_label <= 2; ++v329_7_label) {
        const Space v329_7_tail = child(v327_21_tail,v329_7_label);
        if (v329_7_tail.empty()) continue;
        const Path v329_7_head{v329_7_label};
        const Space v330_2 = singleton(v329_7_head);
        const Space v330_3 = intersect(constant_6,v330_2);
        const Space v330_4 = (has_head(v330_3) ? constant_7 : Space{});
        const Space v330_5 = subtract(constant_0,v330_4);
        Space v330_8;
        if (!v330_5.empty()) {
          const Path v331_6 = concat_path(v329_6,v329_7_head);
          const Space v331_7 = routine_76(c, v331_6, p1, v329_7_tail, s1);
          v330_8 = compose(v330_5,v331_7);
        }
        const Space v330_9 = intersect(constant_6,v330_2);
        const Space v330_10 = (has_head(v330_9) ? constant_7 : Space{});
        Space v330_12;
        if (!v330_10.empty()) {
          const Path v332_6 = concat_path(v329_6,v329_7_head);
          const Space v332_11 = routine_77(c, v332_6, p1, v329_7_tail, s1);
          v330_12 = compose(v330_10,v332_11);
        }
        const Space v330_13 = unite(v330_8,v330_12);
        v329_7_result = unite(v329_7_result,v330_13);
      }
      const Space v329_7 = std::move(v329_7_result);
      v328_8 = compose(v328_5,v329_7);
    }
    const Space v328_9 = intersect(constant_6,v328_2);
    const Space v328_10 = (has_head(v328_9) ? constant_7 : Space{});
    Space v328_22;
    if (!v328_10.empty()) {
      const Path v333_6 = concat_path(p0,v327_21_head);
      const Path v333_11 = concat_path(p1,v333_6);
      const Space v333_12 = routine_29(c, v333_11);
      const Space v333_13 = intersect(v327_8,v333_12);
      const Space v333_14 = routine_30(c, v333_13);
      Space v333_15_result;
      for (int v333_15_label = 1; v333_15_label <= 2; ++v333_15_label) {
        const Space v333_15_tail = child(v333_14,v333_15_label);
        if (v333_15_tail.empty()) continue;
        const Path v333_15_head{v333_15_label};
        const Space v334_2 = singleton(v333_15_head);
        const Space v334_3 = intersect(constant_6,v334_2);
        const Space v334_4 = (has_head(v334_3) ? constant_7 : Space{});
        const Space v334_5 = subtract(constant_0,v334_4);
        Space v334_7;
        if (!v334_5.empty()) {
          const Space v335_6 = routine_31(c, v333_15_head, v333_15_tail);
          v334_7 = compose(v334_5,v335_6);
        }
        const Space v334_8 = intersect(constant_6,v334_2);
        const Space v334_9 = (has_head(v334_8) ? constant_7 : Space{});
        Space v334_11;
        if (!v334_9.empty()) {
          const Space v336_10 = routine_32(c, v333_15_head, v333_15_tail);
          v334_11 = compose(v334_9,v336_10);
        }
        const Space v334_12 = unite(v334_7,v334_11);
        v333_15_result = unite(v333_15_result,v334_12);
      }
      const Space v333_15 = std::move(v333_15_result);
      const Space v333_16 = routine_33(c, v333_13);
      Space v333_17_result;
      for (int v333_17_label = 1; v333_17_label <= 2; ++v333_17_label) {
        const Space v333_17_tail = child(v333_16,v333_17_label);
        if (v333_17_tail.empty()) continue;
        const Path v333_17_head{v333_17_label};
        const Space v337_2 = singleton(v333_17_head);
        const Space v337_3 = intersect(constant_6,v337_2);
        const Space v337_4 = (has_head(v337_3) ? constant_7 : Space{});
        const Space v337_5 = subtract(constant_0,v337_4);
        Space v337_7;
        if (!v337_5.empty()) {
          const Space v338_6 = routine_34(c, v333_17_head, v333_17_tail);
          v337_7 = compose(v337_5,v338_6);
        }
        const Space v337_8 = intersect(constant_6,v337_2);
        const Space v337_9 = (has_head(v337_8) ? constant_7 : Space{});
        Space v337_11;
        if (!v337_9.empty()) {
          const Space v339_10 = routine_35(c, v333_17_head, v333_17_tail);
          v337_11 = compose(v337_9,v339_10);
        }
        const Space v337_12 = unite(v337_7,v337_11);
        v333_17_result = unite(v333_17_result,v337_12);
      }
      const Space v333_17 = std::move(v333_17_result);
      const Space v333_18 = subtract(v333_15,v333_17);
      const Space v333_19 = singleton(v333_11);
      const Space v333_20 = compose(v333_18,v333_19);
      Space v333_21_result;
      for (int v333_21_label = 1; v333_21_label <= 2; ++v333_21_label) {
        const Space v333_21_tail = child(v333_20,v333_21_label);
        if (v333_21_tail.empty()) continue;
        const Path v333_21_head{v333_21_label};
        const Space v340_2 = singleton(v333_21_head);
        const Space v340_3 = intersect(constant_6,v340_2);
        const Space v340_4 = (has_head(v340_3) ? constant_7 : Space{});
        const Space v340_5 = subtract(constant_0,v340_4);
        Space v340_7;
        if (!v340_5.empty()) {
          const Space v341_6 = routine_36(c, v333_21_head, v333_21_tail);
          v340_7 = compose(v340_5,v341_6);
        }
        const Space v340_8 = intersect(constant_6,v340_2);
        const Space v340_9 = (has_head(v340_8) ? constant_7 : Space{});
        Space v340_11;
        if (!v340_9.empty()) {
          const Space v342_10 = routine_37(c, v333_21_head, v333_21_tail);
          v340_11 = compose(v340_9,v342_10);
        }
        const Space v340_12 = unite(v340_7,v340_11);
        v333_21_result = unite(v333_21_result,v340_12);
      }
      const Space v333_21 = std::move(v333_21_result);
      v328_22 = compose(v328_10,v333_21);
    }
    const Space v328_23 = unite(v328_8,v328_22);
    v327_21_result = unite(v327_21_result,v328_23);
  }
  const Space v327_21 = std::move(v327_21_result);
  return v327_21;
}

static Space routine_29(Context& c, const Path& p0) {
  const Space v343_1 = singleton(p0);
  Space v343_11_result;
  for (int v343_11_label = 1; v343_11_label <= 2; ++v343_11_label) {
    const Space v343_11_tail = child(v343_1,v343_11_label);
    if (v343_11_tail.empty()) continue;
    const Path v343_11_head{v343_11_label};
    const Space v344_2 = singleton(v343_11_head);
    const Space v344_3 = intersect(constant_6,v344_2);
    const Space v344_4 = (has_head(v344_3) ? constant_7 : Space{});
    const Space v344_5 = subtract(constant_0,v344_4);
    Space v344_7;
    if (!v344_5.empty()) {
      Space v345_6_result;
      for (int v345_6_label = 1; v345_6_label <= 2; ++v345_6_label) {
        const Space v345_6_tail = child(v343_11_tail,v345_6_label);
        if (v345_6_tail.empty()) continue;
        const Path v345_6_head{v345_6_label};
        const Space v346_2 = singleton(v345_6_head);
        const Space v346_3 = intersect(constant_6,v346_2);
        const Space v346_4 = (has_head(v346_3) ? constant_7 : Space{});
        const Space v346_5 = subtract(constant_0,v346_4);
        Space v346_8;
        if (!v346_5.empty()) {
          const Path v347_6 = concat_path(v343_11_head,v345_6_head);
          const Space v347_7 = routine_78(c, v347_6, v345_6_tail);
          v346_8 = compose(v346_5,v347_7);
        }
        const Space v346_9 = intersect(constant_6,v346_2);
        const Space v346_10 = (has_head(v346_9) ? constant_7 : Space{});
        Space v346_12;
        if (!v346_10.empty()) {
          const Path v348_6 = concat_path(v343_11_head,v345_6_head);
          const Space v348_11 = routine_79(c, v348_6, v345_6_tail);
          v346_12 = compose(v346_10,v348_11);
        }
        const Space v346_13 = unite(v346_8,v346_12);
        v345_6_result = unite(v345_6_result,v346_13);
      }
      const Space v345_6 = std::move(v345_6_result);
      v344_7 = compose(v344_5,v345_6);
    }
    const Space v344_8 = intersect(constant_6,v344_2);
    const Space v344_9 = (has_head(v344_8) ? constant_7 : Space{});
    Space v344_11;
    if (!v344_9.empty()) {
      Space v349_10_result;
      for (int v349_10_label = 1; v349_10_label <= 2; ++v349_10_label) {
        const Space v349_10_tail = child(v343_11_tail,v349_10_label);
        if (v349_10_tail.empty()) continue;
        const Path v349_10_head{v349_10_label};
        const Space v350_2 = singleton(v349_10_head);
        const Space v350_3 = intersect(constant_6,v350_2);
        const Space v350_4 = (has_head(v350_3) ? constant_7 : Space{});
        const Space v350_5 = subtract(constant_0,v350_4);
        Space v350_8;
        if (!v350_5.empty()) {
          const Path v351_6 = concat_path(v343_11_head,v349_10_head);
          const Space v351_7 = routine_78(c, v351_6, v349_10_tail);
          v350_8 = compose(v350_5,v351_7);
        }
        const Space v350_9 = intersect(constant_6,v350_2);
        const Space v350_10 = (has_head(v350_9) ? constant_7 : Space{});
        Space v350_12;
        if (!v350_10.empty()) {
          const Path v352_6 = concat_path(v343_11_head,v349_10_head);
          const Space v352_11 = routine_80(c, v352_6, v349_10_tail);
          v350_12 = compose(v350_10,v352_11);
        }
        const Space v350_13 = unite(v350_8,v350_12);
        v349_10_result = unite(v349_10_result,v350_13);
      }
      const Space v349_10 = std::move(v349_10_result);
      v344_11 = compose(v344_9,v349_10);
    }
    const Space v344_12 = unite(v344_7,v344_11);
    v343_11_result = unite(v343_11_result,v344_12);
  }
  const Space v343_11 = std::move(v343_11_result);
  return v343_11;
}

static Space routine_30(Context& c, const Space& s0) {
  const Space v353_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v353_2 = first_matching(s0,constant_0,false);
  const Space v353_3 = unite(v353_1,v353_2);
  Space v353_6;
  if (!v353_3.empty()) {
    const Space v354_4 = routine_81(c, s0);
    const Space v354_5 = subtract(s0,v354_4);
    v353_6 = compose(v353_3,v354_5);
  }
  Space v353_9;
  if (!v353_3.empty()) {
    const Space v355_7 = routine_66(c, s0);
    const Space v355_8 = routine_66(c, v355_7);
    v353_9 = compose(v353_3,v355_8);
  }
  const Space v353_10 = subtract(s0,v353_9);
  const Space v353_11 = intersect(v353_6,v353_10);
  return v353_11;
}

static Space routine_31(Context& c, const Path& p0, const Space& s0) {
  Space v356_11_result;
  for (int v356_11_label = 1; v356_11_label <= 2; ++v356_11_label) {
    const Space v356_11_tail = child(s0,v356_11_label);
    if (v356_11_tail.empty()) continue;
    const Path v356_11_head{v356_11_label};
    const Space v357_2 = singleton(v356_11_head);
    const Space v357_3 = intersect(constant_6,v357_2);
    const Space v357_4 = (has_head(v357_3) ? constant_7 : Space{});
    const Space v357_5 = subtract(constant_0,v357_4);
    Space v357_8;
    if (!v357_5.empty()) {
      const Path v358_6 = concat_path(p0,v356_11_head);
      Space v358_7_result;
      for (int v358_7_label = 1; v358_7_label <= 2; ++v358_7_label) {
        const Space v358_7_tail = child(v356_11_tail,v358_7_label);
        if (v358_7_tail.empty()) continue;
        const Path v358_7_head{v358_7_label};
        const Space v359_2 = singleton(v358_7_head);
        const Space v359_3 = intersect(constant_6,v359_2);
        const Space v359_4 = (has_head(v359_3) ? constant_7 : Space{});
        const Space v359_5 = subtract(constant_0,v359_4);
        Space v359_8;
        if (!v359_5.empty()) {
          const Path v360_6 = concat_path(v358_6,v358_7_head);
          const Space v360_7 = routine_82(c, v360_6, v358_7_tail);
          v359_8 = compose(v359_5,v360_7);
        }
        const Space v359_9 = intersect(constant_6,v359_2);
        const Space v359_10 = (has_head(v359_9) ? constant_7 : Space{});
        Space v359_12;
        if (!v359_10.empty()) {
          const Path v361_6 = concat_path(v358_6,v358_7_head);
          const Space v361_11 = routine_83(c, v361_6, v358_7_tail);
          v359_12 = compose(v359_10,v361_11);
        }
        const Space v359_13 = unite(v359_8,v359_12);
        v358_7_result = unite(v358_7_result,v359_13);
      }
      const Space v358_7 = std::move(v358_7_result);
      v357_8 = compose(v357_5,v358_7);
    }
    const Space v357_9 = intersect(constant_6,v357_2);
    const Space v357_10 = (has_head(v357_9) ? constant_7 : Space{});
    Space v357_12;
    if (!v357_10.empty()) {
      const Path v362_6 = concat_path(p0,v356_11_head);
      Space v362_11_result;
      for (int v362_11_label = 1; v362_11_label <= 2; ++v362_11_label) {
        const Space v362_11_tail = child(v356_11_tail,v362_11_label);
        if (v362_11_tail.empty()) continue;
        const Path v362_11_head{v362_11_label};
        const Space v363_2 = singleton(v362_11_head);
        const Space v363_3 = intersect(constant_6,v363_2);
        const Space v363_4 = (has_head(v363_3) ? constant_7 : Space{});
        const Space v363_5 = subtract(constant_0,v363_4);
        Space v363_8;
        if (!v363_5.empty()) {
          const Path v364_6 = concat_path(v362_6,v362_11_head);
          const Space v364_7 = routine_82(c, v364_6, v362_11_tail);
          v363_8 = compose(v363_5,v364_7);
        }
        const Space v363_9 = intersect(constant_6,v363_2);
        const Space v363_10 = (has_head(v363_9) ? constant_7 : Space{});
        Space v363_12;
        if (!v363_10.empty()) {
          const Path v365_6 = concat_path(v362_6,v362_11_head);
          const Space v365_11 = routine_69(c, v365_6, v362_11_tail);
          v363_12 = compose(v363_10,v365_11);
        }
        const Space v363_13 = unite(v363_8,v363_12);
        v362_11_result = unite(v362_11_result,v363_13);
      }
      const Space v362_11 = std::move(v362_11_result);
      v357_12 = compose(v357_10,v362_11);
    }
    const Space v357_13 = unite(v357_8,v357_12);
    v356_11_result = unite(v356_11_result,v357_13);
  }
  const Space v356_11 = std::move(v356_11_result);
  return v356_11;
}

static Space routine_32(Context& c, const Path& p0, const Space& s0) {
  Space v366_9_result;
  for (int v366_9_label = 1; v366_9_label <= 2; ++v366_9_label) {
    const Space v366_9_tail = child(s0,v366_9_label);
    if (v366_9_tail.empty()) continue;
    const Path v366_9_head{v366_9_label};
    const Space v367_2 = singleton(v366_9_head);
    const Space v367_3 = intersect(constant_6,v367_2);
    const Space v367_4 = (has_head(v367_3) ? constant_7 : Space{});
    const Space v367_5 = subtract(constant_0,v367_4);
    Space v367_8;
    if (!v367_5.empty()) {
      const Path v368_6 = concat_path(p0,v366_9_head);
      Space v368_7_result;
      for (int v368_7_label = 1; v368_7_label <= 2; ++v368_7_label) {
        const Space v368_7_tail = child(v366_9_tail,v368_7_label);
        if (v368_7_tail.empty()) continue;
        const Path v368_7_head{v368_7_label};
        const Space v369_2 = singleton(v368_7_head);
        const Space v369_3 = intersect(constant_6,v369_2);
        const Space v369_4 = (has_head(v369_3) ? constant_7 : Space{});
        const Space v369_5 = subtract(constant_0,v369_4);
        Space v369_8;
        if (!v369_5.empty()) {
          const Path v370_6 = concat_path(v368_6,v368_7_head);
          const Space v370_7 = routine_82(c, v370_6, v368_7_tail);
          v369_8 = compose(v369_5,v370_7);
        }
        const Space v369_9 = intersect(constant_6,v369_2);
        const Space v369_10 = (has_head(v369_9) ? constant_7 : Space{});
        Space v369_12;
        if (!v369_10.empty()) {
          const Path v371_6 = concat_path(v368_6,v368_7_head);
          const Space v371_11 = routine_83(c, v371_6, v368_7_tail);
          v369_12 = compose(v369_10,v371_11);
        }
        const Space v369_13 = unite(v369_8,v369_12);
        v368_7_result = unite(v368_7_result,v369_13);
      }
      const Space v368_7 = std::move(v368_7_result);
      v367_8 = compose(v367_5,v368_7);
    }
    const Space v367_9 = intersect(constant_6,v367_2);
    const Space v367_10 = (has_head(v367_9) ? constant_7 : Space{});
    const Space v367_11 = compose(v367_10,constant_9);
    const Space v367_12 = unite(v367_8,v367_11);
    v366_9_result = unite(v366_9_result,v367_12);
  }
  const Space v366_9 = std::move(v366_9_result);
  return v366_9;
}

static Space routine_33(Context& c, const Space& s0) {
  const Space v372_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v372_2 = first_matching(s0,constant_0,false);
  const Space v372_3 = unite(v372_1,v372_2);
  Space v372_6;
  if (!v372_3.empty()) {
    const Space v373_4 = routine_66(c, s0);
    const Space v373_5 = routine_66(c, v373_4);
    v372_6 = compose(v372_3,v373_5);
  }
  Space v372_9;
  if (!v372_3.empty()) {
    const Space v374_7 = routine_81(c, s0);
    const Space v374_8 = subtract(s0,v374_7);
    v372_9 = compose(v372_3,v374_8);
  }
  const Space v372_10 = (has_head(v372_9) ? constant_7 : Space{});
  const Space v372_11 = first_matching(v372_9,constant_0,false);
  const Space v372_12 = unite(v372_10,v372_11);
  Space v372_15;
  if (!v372_12.empty()) {
    const Space v375_13 = routine_66(c, v372_9);
    const Space v375_14 = routine_66(c, v375_13);
    v372_15 = compose(v372_12,v375_14);
  }
  const Space v372_16 = subtract(s0,v372_15);
  const Space v372_17 = intersect(v372_6,v372_16);
  return v372_17;
}

static Space routine_34(Context& c, const Path& p0, const Space& s0) {
  Space v376_11_result;
  for (int v376_11_label = 1; v376_11_label <= 2; ++v376_11_label) {
    const Space v376_11_tail = child(s0,v376_11_label);
    if (v376_11_tail.empty()) continue;
    const Path v376_11_head{v376_11_label};
    const Space v377_2 = singleton(v376_11_head);
    const Space v377_3 = intersect(constant_6,v377_2);
    const Space v377_4 = (has_head(v377_3) ? constant_7 : Space{});
    const Space v377_5 = subtract(constant_0,v377_4);
    Space v377_8;
    if (!v377_5.empty()) {
      const Path v378_6 = concat_path(p0,v376_11_head);
      Space v378_7_result;
      for (int v378_7_label = 1; v378_7_label <= 2; ++v378_7_label) {
        const Space v378_7_tail = child(v376_11_tail,v378_7_label);
        if (v378_7_tail.empty()) continue;
        const Path v378_7_head{v378_7_label};
        const Space v379_2 = singleton(v378_7_head);
        const Space v379_3 = intersect(constant_6,v379_2);
        const Space v379_4 = (has_head(v379_3) ? constant_7 : Space{});
        const Space v379_5 = subtract(constant_0,v379_4);
        Space v379_8;
        if (!v379_5.empty()) {
          const Path v380_6 = concat_path(v378_6,v378_7_head);
          const Space v380_7 = routine_84(c, v380_6, v378_7_tail);
          v379_8 = compose(v379_5,v380_7);
        }
        const Space v379_9 = intersect(constant_6,v379_2);
        const Space v379_10 = (has_head(v379_9) ? constant_7 : Space{});
        Space v379_12;
        if (!v379_10.empty()) {
          const Path v381_6 = concat_path(v378_6,v378_7_head);
          const Space v381_11 = routine_85(c, v381_6, v378_7_tail);
          v379_12 = compose(v379_10,v381_11);
        }
        const Space v379_13 = unite(v379_8,v379_12);
        v378_7_result = unite(v378_7_result,v379_13);
      }
      const Space v378_7 = std::move(v378_7_result);
      v377_8 = compose(v377_5,v378_7);
    }
    const Space v377_9 = intersect(constant_6,v377_2);
    const Space v377_10 = (has_head(v377_9) ? constant_7 : Space{});
    Space v377_12;
    if (!v377_10.empty()) {
      const Path v382_6 = concat_path(p0,v376_11_head);
      Space v382_11_result;
      for (int v382_11_label = 1; v382_11_label <= 2; ++v382_11_label) {
        const Space v382_11_tail = child(v376_11_tail,v382_11_label);
        if (v382_11_tail.empty()) continue;
        const Path v382_11_head{v382_11_label};
        const Space v383_2 = singleton(v382_11_head);
        const Space v383_3 = intersect(constant_6,v383_2);
        const Space v383_4 = (has_head(v383_3) ? constant_7 : Space{});
        const Space v383_5 = subtract(constant_0,v383_4);
        Space v383_8;
        if (!v383_5.empty()) {
          const Path v384_6 = concat_path(v382_6,v382_11_head);
          const Space v384_7 = routine_84(c, v384_6, v382_11_tail);
          v383_8 = compose(v383_5,v384_7);
        }
        const Space v383_9 = intersect(constant_6,v383_2);
        const Space v383_10 = (has_head(v383_9) ? constant_7 : Space{});
        Space v383_12;
        if (!v383_10.empty()) {
          const Path v385_6 = concat_path(v382_6,v382_11_head);
          const Space v385_11 = routine_72(c, v385_6, v382_11_tail);
          v383_12 = compose(v383_10,v385_11);
        }
        const Space v383_13 = unite(v383_8,v383_12);
        v382_11_result = unite(v382_11_result,v383_13);
      }
      const Space v382_11 = std::move(v382_11_result);
      v377_12 = compose(v377_10,v382_11);
    }
    const Space v377_13 = unite(v377_8,v377_12);
    v376_11_result = unite(v376_11_result,v377_13);
  }
  const Space v376_11 = std::move(v376_11_result);
  return v376_11;
}

static Space routine_35(Context& c, const Path& p0, const Space& s0) {
  Space v386_9_result;
  for (int v386_9_label = 1; v386_9_label <= 2; ++v386_9_label) {
    const Space v386_9_tail = child(s0,v386_9_label);
    if (v386_9_tail.empty()) continue;
    const Path v386_9_head{v386_9_label};
    const Space v387_2 = singleton(v386_9_head);
    const Space v387_3 = intersect(constant_6,v387_2);
    const Space v387_4 = (has_head(v387_3) ? constant_7 : Space{});
    const Space v387_5 = subtract(constant_0,v387_4);
    Space v387_8;
    if (!v387_5.empty()) {
      const Path v388_6 = concat_path(p0,v386_9_head);
      Space v388_7_result;
      for (int v388_7_label = 1; v388_7_label <= 2; ++v388_7_label) {
        const Space v388_7_tail = child(v386_9_tail,v388_7_label);
        if (v388_7_tail.empty()) continue;
        const Path v388_7_head{v388_7_label};
        const Space v389_2 = singleton(v388_7_head);
        const Space v389_3 = intersect(constant_6,v389_2);
        const Space v389_4 = (has_head(v389_3) ? constant_7 : Space{});
        const Space v389_5 = subtract(constant_0,v389_4);
        Space v389_8;
        if (!v389_5.empty()) {
          const Path v390_6 = concat_path(v388_6,v388_7_head);
          const Space v390_7 = routine_84(c, v390_6, v388_7_tail);
          v389_8 = compose(v389_5,v390_7);
        }
        const Space v389_9 = intersect(constant_6,v389_2);
        const Space v389_10 = (has_head(v389_9) ? constant_7 : Space{});
        Space v389_12;
        if (!v389_10.empty()) {
          const Path v391_6 = concat_path(v388_6,v388_7_head);
          const Space v391_11 = routine_85(c, v391_6, v388_7_tail);
          v389_12 = compose(v389_10,v391_11);
        }
        const Space v389_13 = unite(v389_8,v389_12);
        v388_7_result = unite(v388_7_result,v389_13);
      }
      const Space v388_7 = std::move(v388_7_result);
      v387_8 = compose(v387_5,v388_7);
    }
    const Space v387_9 = intersect(constant_6,v387_2);
    const Space v387_10 = (has_head(v387_9) ? constant_7 : Space{});
    const Space v387_11 = compose(v387_10,constant_9);
    const Space v387_12 = unite(v387_8,v387_11);
    v386_9_result = unite(v386_9_result,v387_12);
  }
  const Space v386_9 = std::move(v386_9_result);
  return v386_9;
}

static Space routine_36(Context& c, const Path& p0, const Space& s0) {
  Space v392_11_result;
  for (int v392_11_label = 1; v392_11_label <= 2; ++v392_11_label) {
    const Space v392_11_tail = child(s0,v392_11_label);
    if (v392_11_tail.empty()) continue;
    const Path v392_11_head{v392_11_label};
    const Space v393_2 = singleton(v392_11_head);
    const Space v393_3 = intersect(constant_6,v393_2);
    const Space v393_4 = (has_head(v393_3) ? constant_7 : Space{});
    const Space v393_5 = subtract(constant_0,v393_4);
    Space v393_8;
    if (!v393_5.empty()) {
      const Path v394_6 = concat_path(p0,v392_11_head);
      Space v394_7_result;
      for (int v394_7_label = 1; v394_7_label <= 2; ++v394_7_label) {
        const Space v394_7_tail = child(v392_11_tail,v394_7_label);
        if (v394_7_tail.empty()) continue;
        const Path v394_7_head{v394_7_label};
        const Space v395_2 = singleton(v394_7_head);
        const Space v395_3 = intersect(constant_6,v395_2);
        const Space v395_4 = (has_head(v395_3) ? constant_7 : Space{});
        const Space v395_5 = subtract(constant_0,v395_4);
        Space v395_8;
        if (!v395_5.empty()) {
          const Path v396_6 = concat_path(v394_6,v394_7_head);
          const Space v396_7 = routine_86(c, v396_6, v394_7_tail);
          v395_8 = compose(v395_5,v396_7);
        }
        const Space v395_9 = intersect(constant_6,v395_2);
        const Space v395_10 = (has_head(v395_9) ? constant_7 : Space{});
        Space v395_12;
        if (!v395_10.empty()) {
          const Path v397_6 = concat_path(v394_6,v394_7_head);
          const Space v397_11 = routine_87(c, v397_6, v394_7_tail);
          v395_12 = compose(v395_10,v397_11);
        }
        const Space v395_13 = unite(v395_8,v395_12);
        v394_7_result = unite(v394_7_result,v395_13);
      }
      const Space v394_7 = std::move(v394_7_result);
      v393_8 = compose(v393_5,v394_7);
    }
    const Space v393_9 = intersect(constant_6,v393_2);
    const Space v393_10 = (has_head(v393_9) ? constant_7 : Space{});
    Space v393_12;
    if (!v393_10.empty()) {
      const Path v398_6 = concat_path(p0,v392_11_head);
      Space v398_11_result;
      for (int v398_11_label = 1; v398_11_label <= 2; ++v398_11_label) {
        const Space v398_11_tail = child(v392_11_tail,v398_11_label);
        if (v398_11_tail.empty()) continue;
        const Path v398_11_head{v398_11_label};
        const Space v399_2 = singleton(v398_11_head);
        const Space v399_3 = intersect(constant_6,v399_2);
        const Space v399_4 = (has_head(v399_3) ? constant_7 : Space{});
        const Space v399_5 = subtract(constant_0,v399_4);
        Space v399_8;
        if (!v399_5.empty()) {
          const Path v400_6 = concat_path(v398_6,v398_11_head);
          const Space v400_7 = routine_86(c, v400_6, v398_11_tail);
          v399_8 = compose(v399_5,v400_7);
        }
        const Space v399_9 = intersect(constant_6,v399_2);
        const Space v399_10 = (has_head(v399_9) ? constant_7 : Space{});
        Space v399_12;
        if (!v399_10.empty()) {
          const Path v401_6 = concat_path(v398_6,v398_11_head);
          const Space v401_11 = routine_75(c, v401_6, v398_11_tail);
          v399_12 = compose(v399_10,v401_11);
        }
        const Space v399_13 = unite(v399_8,v399_12);
        v398_11_result = unite(v398_11_result,v399_13);
      }
      const Space v398_11 = std::move(v398_11_result);
      v393_12 = compose(v393_10,v398_11);
    }
    const Space v393_13 = unite(v393_8,v393_12);
    v392_11_result = unite(v392_11_result,v393_13);
  }
  const Space v392_11 = std::move(v392_11_result);
  return v392_11;
}

static Space routine_37(Context& c, const Path& p0, const Space& s0) {
  Space v402_8_result;
  for (int v402_8_label = 1; v402_8_label <= 2; ++v402_8_label) {
    const Space v402_8_tail = child(s0,v402_8_label);
    if (v402_8_tail.empty()) continue;
    const Path v402_8_head{v402_8_label};
    const Space v403_2 = singleton(v402_8_head);
    const Space v403_3 = intersect(constant_6,v403_2);
    const Space v403_4 = (has_head(v403_3) ? constant_7 : Space{});
    const Space v403_5 = subtract(constant_0,v403_4);
    Space v403_8;
    if (!v403_5.empty()) {
      const Path v404_6 = concat_path(p0,v402_8_head);
      Space v404_7_result;
      for (int v404_7_label = 1; v404_7_label <= 2; ++v404_7_label) {
        const Space v404_7_tail = child(v402_8_tail,v404_7_label);
        if (v404_7_tail.empty()) continue;
        const Path v404_7_head{v404_7_label};
        const Space v405_2 = singleton(v404_7_head);
        const Space v405_3 = intersect(constant_6,v405_2);
        const Space v405_4 = (has_head(v405_3) ? constant_7 : Space{});
        const Space v405_5 = subtract(constant_0,v405_4);
        Space v405_8;
        if (!v405_5.empty()) {
          const Path v406_6 = concat_path(v404_6,v404_7_head);
          const Space v406_7 = routine_86(c, v406_6, v404_7_tail);
          v405_8 = compose(v405_5,v406_7);
        }
        const Space v405_9 = intersect(constant_6,v405_2);
        const Space v405_10 = (has_head(v405_9) ? constant_7 : Space{});
        Space v405_12;
        if (!v405_10.empty()) {
          const Path v407_6 = concat_path(v404_6,v404_7_head);
          const Space v407_11 = routine_87(c, v407_6, v404_7_tail);
          v405_12 = compose(v405_10,v407_11);
        }
        const Space v405_13 = unite(v405_8,v405_12);
        v404_7_result = unite(v404_7_result,v405_13);
      }
      const Space v404_7 = std::move(v404_7_result);
      v403_8 = compose(v403_5,v404_7);
    }
    const Space v403_9 = intersect(constant_6,v403_2);
    const Space v403_10 = (has_head(v403_9) ? constant_7 : Space{});
    const Space v403_11 = compose(v403_10,v402_8_tail);
    const Space v403_12 = unite(v403_8,v403_11);
    v402_8_result = unite(v402_8_result,v403_12);
  }
  const Space v402_8 = std::move(v402_8_result);
  return v402_8;
}

static Space routine_38(Context& c, const Path& p0, const Space& s0) {
  Space v408_11_result;
  for (int v408_11_label = 1; v408_11_label <= 2; ++v408_11_label) {
    const Space v408_11_tail = child(s0,v408_11_label);
    if (v408_11_tail.empty()) continue;
    const Path v408_11_head{v408_11_label};
    const Space v409_2 = singleton(v408_11_head);
    const Space v409_3 = intersect(constant_6,v409_2);
    const Space v409_4 = (has_head(v409_3) ? constant_7 : Space{});
    const Space v409_5 = subtract(constant_0,v409_4);
    Space v409_8;
    if (!v409_5.empty()) {
      const Path v410_6 = concat_path(p0,v408_11_head);
      Space v410_7_result;
      for (int v410_7_label = 1; v410_7_label <= 2; ++v410_7_label) {
        const Space v410_7_tail = child(v408_11_tail,v410_7_label);
        if (v410_7_tail.empty()) continue;
        const Path v410_7_head{v410_7_label};
        const Space v411_2 = singleton(v410_7_head);
        const Space v411_3 = intersect(constant_6,v411_2);
        const Space v411_4 = (has_head(v411_3) ? constant_7 : Space{});
        const Space v411_5 = subtract(constant_0,v411_4);
        Space v411_8;
        if (!v411_5.empty()) {
          const Path v412_6 = concat_path(v410_6,v410_7_head);
          const Space v412_7 = routine_88(c, v412_6, v410_7_tail);
          v411_8 = compose(v411_5,v412_7);
        }
        const Space v411_9 = intersect(constant_6,v411_2);
        const Space v411_10 = (has_head(v411_9) ? constant_7 : Space{});
        Space v411_12;
        if (!v411_10.empty()) {
          const Path v413_6 = concat_path(v410_6,v410_7_head);
          const Space v413_11 = routine_89(c, v413_6, v410_7_tail);
          v411_12 = compose(v411_10,v413_11);
        }
        const Space v411_13 = unite(v411_8,v411_12);
        v410_7_result = unite(v410_7_result,v411_13);
      }
      const Space v410_7 = std::move(v410_7_result);
      v409_8 = compose(v409_5,v410_7);
    }
    const Space v409_9 = intersect(constant_6,v409_2);
    const Space v409_10 = (has_head(v409_9) ? constant_7 : Space{});
    Space v409_12;
    if (!v409_10.empty()) {
      const Path v414_6 = concat_path(p0,v408_11_head);
      Space v414_11_result;
      for (int v414_11_label = 1; v414_11_label <= 2; ++v414_11_label) {
        const Space v414_11_tail = child(v408_11_tail,v414_11_label);
        if (v414_11_tail.empty()) continue;
        const Path v414_11_head{v414_11_label};
        const Space v415_2 = singleton(v414_11_head);
        const Space v415_3 = intersect(constant_6,v415_2);
        const Space v415_4 = (has_head(v415_3) ? constant_7 : Space{});
        const Space v415_5 = subtract(constant_0,v415_4);
        Space v415_8;
        if (!v415_5.empty()) {
          const Path v416_6 = concat_path(v414_6,v414_11_head);
          const Space v416_7 = routine_88(c, v416_6, v414_11_tail);
          v415_8 = compose(v415_5,v416_7);
        }
        const Space v415_9 = intersect(constant_6,v415_2);
        const Space v415_10 = (has_head(v415_9) ? constant_7 : Space{});
        Space v415_12;
        if (!v415_10.empty()) {
          const Path v417_6 = concat_path(v414_6,v414_11_head);
          const Space v417_11 = routine_14(c, v417_6, v414_11_tail);
          v415_12 = compose(v415_10,v417_11);
        }
        const Space v415_13 = unite(v415_8,v415_12);
        v414_11_result = unite(v414_11_result,v415_13);
      }
      const Space v414_11 = std::move(v414_11_result);
      v409_12 = compose(v409_10,v414_11);
    }
    const Space v409_13 = unite(v409_8,v409_12);
    v408_11_result = unite(v408_11_result,v409_13);
  }
  const Space v408_11 = std::move(v408_11_result);
  return v408_11;
}

static Space routine_39(Context& c, const Path& p0, const Space& s0) {
  Space v418_11_result;
  for (int v418_11_label = 1; v418_11_label <= 2; ++v418_11_label) {
    const Space v418_11_tail = child(s0,v418_11_label);
    if (v418_11_tail.empty()) continue;
    const Path v418_11_head{v418_11_label};
    const Space v419_2 = singleton(v418_11_head);
    const Space v419_3 = intersect(constant_6,v419_2);
    const Space v419_4 = (has_head(v419_3) ? constant_7 : Space{});
    const Space v419_5 = subtract(constant_0,v419_4);
    Space v419_8;
    if (!v419_5.empty()) {
      const Path v420_6 = concat_path(p0,v418_11_head);
      Space v420_7_result;
      for (int v420_7_label = 1; v420_7_label <= 2; ++v420_7_label) {
        const Space v420_7_tail = child(v418_11_tail,v420_7_label);
        if (v420_7_tail.empty()) continue;
        const Path v420_7_head{v420_7_label};
        const Space v421_2 = singleton(v420_7_head);
        const Space v421_3 = intersect(constant_6,v421_2);
        const Space v421_4 = (has_head(v421_3) ? constant_7 : Space{});
        const Space v421_5 = subtract(constant_0,v421_4);
        Space v421_8;
        if (!v421_5.empty()) {
          const Path v422_6 = concat_path(v420_6,v420_7_head);
          const Space v422_7 = routine_88(c, v422_6, v420_7_tail);
          v421_8 = compose(v421_5,v422_7);
        }
        const Space v421_9 = intersect(constant_6,v421_2);
        const Space v421_10 = (has_head(v421_9) ? constant_7 : Space{});
        Space v421_12;
        if (!v421_10.empty()) {
          const Path v423_6 = concat_path(v420_6,v420_7_head);
          const Space v423_11 = routine_89(c, v423_6, v420_7_tail);
          v421_12 = compose(v421_10,v423_11);
        }
        const Space v421_13 = unite(v421_8,v421_12);
        v420_7_result = unite(v420_7_result,v421_13);
      }
      const Space v420_7 = std::move(v420_7_result);
      v419_8 = compose(v419_5,v420_7);
    }
    const Space v419_9 = intersect(constant_6,v419_2);
    const Space v419_10 = (has_head(v419_9) ? constant_7 : Space{});
    Space v419_12;
    if (!v419_10.empty()) {
      const Path v424_6 = concat_path(p0,v418_11_head);
      Space v424_11_result;
      for (int v424_11_label = 1; v424_11_label <= 2; ++v424_11_label) {
        const Space v424_11_tail = child(v418_11_tail,v424_11_label);
        if (v424_11_tail.empty()) continue;
        const Path v424_11_head{v424_11_label};
        const Space v425_2 = singleton(v424_11_head);
        const Space v425_3 = intersect(constant_6,v425_2);
        const Space v425_4 = (has_head(v425_3) ? constant_7 : Space{});
        const Space v425_5 = subtract(constant_0,v425_4);
        Space v425_7;
        if (!v425_5.empty()) {
          const Space v426_6 = routine_15(c, v424_11_head, v424_6, v424_11_tail);
          v425_7 = compose(v425_5,v426_6);
        }
        const Space v425_8 = intersect(constant_6,v425_2);
        const Space v425_9 = (has_head(v425_8) ? constant_7 : Space{});
        Space v425_11;
        if (!v425_9.empty()) {
          const Space v427_10 = routine_16(c, v424_11_head, v424_6, v424_11_tail);
          v425_11 = compose(v425_9,v427_10);
        }
        const Space v425_12 = unite(v425_7,v425_11);
        v424_11_result = unite(v424_11_result,v425_12);
      }
      const Space v424_11 = std::move(v424_11_result);
      v419_12 = compose(v419_10,v424_11);
    }
    const Space v419_13 = unite(v419_8,v419_12);
    v418_11_result = unite(v418_11_result,v419_13);
  }
  const Space v418_11 = std::move(v418_11_result);
  return v418_11;
}

static Space routine_40(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v428_12_result;
  for (int v428_12_label = 1; v428_12_label <= 2; ++v428_12_label) {
    const Space v428_12_tail = child(s0,v428_12_label);
    if (v428_12_tail.empty()) continue;
    const Path v428_12_head{v428_12_label};
    const Space v429_2 = singleton(v428_12_head);
    const Space v429_3 = intersect(constant_6,v429_2);
    const Space v429_4 = (has_head(v429_3) ? constant_7 : Space{});
    const Space v429_5 = subtract(constant_0,v429_4);
    Space v429_8;
    if (!v429_5.empty()) {
      const Path v430_6 = concat_path(p0,v428_12_head);
      Space v430_7_result;
      for (int v430_7_label = 1; v430_7_label <= 2; ++v430_7_label) {
        const Space v430_7_tail = child(v428_12_tail,v430_7_label);
        if (v430_7_tail.empty()) continue;
        const Path v430_7_head{v430_7_label};
        const Space v431_2 = singleton(v430_7_head);
        const Space v431_3 = intersect(constant_6,v431_2);
        const Space v431_4 = (has_head(v431_3) ? constant_7 : Space{});
        const Space v431_5 = subtract(constant_0,v431_4);
        Space v431_8;
        if (!v431_5.empty()) {
          const Path v432_6 = concat_path(v430_6,v430_7_head);
          const Space v432_7 = routine_90(c, v432_6, p1, v430_7_tail);
          v431_8 = compose(v431_5,v432_7);
        }
        const Space v431_9 = intersect(constant_6,v431_2);
        const Space v431_10 = (has_head(v431_9) ? constant_7 : Space{});
        Space v431_12;
        if (!v431_10.empty()) {
          const Path v433_6 = concat_path(v430_6,v430_7_head);
          const Space v433_11 = routine_91(c, v433_6, p1, v430_7_tail);
          v431_12 = compose(v431_10,v433_11);
        }
        const Space v431_13 = unite(v431_8,v431_12);
        v430_7_result = unite(v430_7_result,v431_13);
      }
      const Space v430_7 = std::move(v430_7_result);
      v429_8 = compose(v429_5,v430_7);
    }
    const Space v429_9 = intersect(constant_6,v429_2);
    const Space v429_10 = (has_head(v429_9) ? constant_7 : Space{});
    Space v429_12;
    if (!v429_10.empty()) {
      const Path v434_6 = concat_path(p0,v428_12_head);
      Space v434_11_result;
      for (int v434_11_label = 1; v434_11_label <= 2; ++v434_11_label) {
        const Space v434_11_tail = child(v428_12_tail,v434_11_label);
        if (v434_11_tail.empty()) continue;
        const Path v434_11_head{v434_11_label};
        const Space v435_2 = singleton(v434_11_head);
        const Space v435_3 = intersect(constant_6,v435_2);
        const Space v435_4 = (has_head(v435_3) ? constant_7 : Space{});
        const Space v435_5 = subtract(constant_0,v435_4);
        Space v435_8;
        if (!v435_5.empty()) {
          const Path v436_6 = concat_path(v434_6,v434_11_head);
          const Space v436_7 = routine_90(c, v436_6, p1, v434_11_tail);
          v435_8 = compose(v435_5,v436_7);
        }
        const Space v435_9 = intersect(constant_6,v435_2);
        const Space v435_10 = (has_head(v435_9) ? constant_7 : Space{});
        Space v435_12;
        if (!v435_10.empty()) {
          const Path v437_6 = concat_path(v434_6,v434_11_head);
          const Space v437_11 = routine_42(c, v437_6, p1, v434_11_tail);
          v435_12 = compose(v435_10,v437_11);
        }
        const Space v435_13 = unite(v435_8,v435_12);
        v434_11_result = unite(v434_11_result,v435_13);
      }
      const Space v434_11 = std::move(v434_11_result);
      v429_12 = compose(v429_10,v434_11);
    }
    const Space v429_13 = unite(v429_8,v429_12);
    v428_12_result = unite(v428_12_result,v429_13);
  }
  const Space v428_12 = std::move(v428_12_result);
  return v428_12;
}

static Space routine_41(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v438_9_result;
  for (int v438_9_label = 1; v438_9_label <= 2; ++v438_9_label) {
    const Space v438_9_tail = child(s0,v438_9_label);
    if (v438_9_tail.empty()) continue;
    const Path v438_9_head{v438_9_label};
    const Space v439_2 = singleton(v438_9_head);
    const Space v439_3 = intersect(constant_6,v439_2);
    const Space v439_4 = (has_head(v439_3) ? constant_7 : Space{});
    const Space v439_5 = subtract(constant_0,v439_4);
    Space v439_8;
    if (!v439_5.empty()) {
      const Path v440_6 = concat_path(p0,v438_9_head);
      Space v440_7_result;
      for (int v440_7_label = 1; v440_7_label <= 2; ++v440_7_label) {
        const Space v440_7_tail = child(v438_9_tail,v440_7_label);
        if (v440_7_tail.empty()) continue;
        const Path v440_7_head{v440_7_label};
        const Space v441_2 = singleton(v440_7_head);
        const Space v441_3 = intersect(constant_6,v441_2);
        const Space v441_4 = (has_head(v441_3) ? constant_7 : Space{});
        const Space v441_5 = subtract(constant_0,v441_4);
        Space v441_8;
        if (!v441_5.empty()) {
          const Path v442_6 = concat_path(v440_6,v440_7_head);
          const Space v442_7 = routine_90(c, v442_6, p1, v440_7_tail);
          v441_8 = compose(v441_5,v442_7);
        }
        const Space v441_9 = intersect(constant_6,v441_2);
        const Space v441_10 = (has_head(v441_9) ? constant_7 : Space{});
        Space v441_12;
        if (!v441_10.empty()) {
          const Path v443_6 = concat_path(v440_6,v440_7_head);
          const Space v443_11 = routine_91(c, v443_6, p1, v440_7_tail);
          v441_12 = compose(v441_10,v443_11);
        }
        const Space v441_13 = unite(v441_8,v441_12);
        v440_7_result = unite(v440_7_result,v441_13);
      }
      const Space v440_7 = std::move(v440_7_result);
      v439_8 = compose(v439_5,v440_7);
    }
    const Space v439_9 = intersect(constant_6,v439_2);
    const Space v439_10 = (has_head(v439_9) ? constant_7 : Space{});
    Space v439_13;
    if (!v439_10.empty()) {
      const Path v444_6 = concat_path(p0,v438_9_head);
      const Path v444_11 = concat_path(p1,v444_6);
      const Space v444_12 = routine_29(c, v444_11);
      v439_13 = compose(v439_10,v444_12);
    }
    const Space v439_14 = unite(v439_8,v439_13);
    v438_9_result = unite(v438_9_result,v439_14);
  }
  const Space v438_9 = std::move(v438_9_result);
  return v438_9;
}

static Space routine_42(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Path v445_3 = concat_path(p1,p0);
  const Space v445_4 = singleton(v445_3);
  Space v445_8_result;
  for (int v445_8_label = 1; v445_8_label <= 2; ++v445_8_label) {
    const Space v445_8_tail = child(v445_4,v445_8_label);
    if (v445_8_tail.empty()) continue;
    const Path v445_8_head{v445_8_label};
    const Space v446_2 = singleton(v445_8_head);
    const Space v446_3 = intersect(constant_6,v446_2);
    const Space v446_4 = (has_head(v446_3) ? constant_7 : Space{});
    const Space v446_5 = subtract(constant_0,v446_4);
    Space v446_7;
    if (!v446_5.empty()) {
      const Space v447_6 = routine_63(c, v445_8_head, v445_8_tail);
      v446_7 = compose(v446_5,v447_6);
    }
    const Space v446_8 = intersect(constant_6,v446_2);
    const Space v446_9 = (has_head(v446_8) ? constant_7 : Space{});
    Space v446_11;
    if (!v446_9.empty()) {
      const Space v448_10 = routine_64(c, v445_8_head, v445_8_tail);
      v446_11 = compose(v446_9,v448_10);
    }
    const Space v446_12 = unite(v446_7,v446_11);
    v445_8_result = unite(v445_8_result,v446_12);
  }
  const Space v445_8 = std::move(v445_8_result);
  return v445_8;
}

static Space routine_43(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v449_12_result;
  for (int v449_12_label = 1; v449_12_label <= 2; ++v449_12_label) {
    const Space v449_12_tail = child(s0,v449_12_label);
    if (v449_12_tail.empty()) continue;
    const Path v449_12_head{v449_12_label};
    const Space v450_2 = singleton(v449_12_head);
    const Space v450_3 = intersect(constant_6,v450_2);
    const Space v450_4 = (has_head(v450_3) ? constant_7 : Space{});
    const Space v450_5 = subtract(constant_0,v450_4);
    Space v450_8;
    if (!v450_5.empty()) {
      const Path v451_6 = concat_path(p0,v449_12_head);
      Space v451_7_result;
      for (int v451_7_label = 1; v451_7_label <= 2; ++v451_7_label) {
        const Space v451_7_tail = child(v449_12_tail,v451_7_label);
        if (v451_7_tail.empty()) continue;
        const Path v451_7_head{v451_7_label};
        const Space v452_2 = singleton(v451_7_head);
        const Space v452_3 = intersect(constant_6,v452_2);
        const Space v452_4 = (has_head(v452_3) ? constant_7 : Space{});
        const Space v452_5 = subtract(constant_0,v452_4);
        Space v452_8;
        if (!v452_5.empty()) {
          const Path v453_6 = concat_path(v451_6,v451_7_head);
          const Space v453_7 = routine_92(c, v453_6, p1, v451_7_tail);
          v452_8 = compose(v452_5,v453_7);
        }
        const Space v452_9 = intersect(constant_6,v452_2);
        const Space v452_10 = (has_head(v452_9) ? constant_7 : Space{});
        Space v452_12;
        if (!v452_10.empty()) {
          const Path v454_6 = concat_path(v451_6,v451_7_head);
          const Space v454_11 = routine_93(c, v454_6, p1, v451_7_tail);
          v452_12 = compose(v452_10,v454_11);
        }
        const Space v452_13 = unite(v452_8,v452_12);
        v451_7_result = unite(v451_7_result,v452_13);
      }
      const Space v451_7 = std::move(v451_7_result);
      v450_8 = compose(v450_5,v451_7);
    }
    const Space v450_9 = intersect(constant_6,v450_2);
    const Space v450_10 = (has_head(v450_9) ? constant_7 : Space{});
    Space v450_12;
    if (!v450_10.empty()) {
      const Path v455_6 = concat_path(p0,v449_12_head);
      Space v455_11_result;
      for (int v455_11_label = 1; v455_11_label <= 2; ++v455_11_label) {
        const Space v455_11_tail = child(v449_12_tail,v455_11_label);
        if (v455_11_tail.empty()) continue;
        const Path v455_11_head{v455_11_label};
        const Space v456_2 = singleton(v455_11_head);
        const Space v456_3 = intersect(constant_6,v456_2);
        const Space v456_4 = (has_head(v456_3) ? constant_7 : Space{});
        const Space v456_5 = subtract(constant_0,v456_4);
        Space v456_8;
        if (!v456_5.empty()) {
          const Path v457_6 = concat_path(v455_6,v455_11_head);
          const Space v457_7 = routine_92(c, v457_6, p1, v455_11_tail);
          v456_8 = compose(v456_5,v457_7);
        }
        const Space v456_9 = intersect(constant_6,v456_2);
        const Space v456_10 = (has_head(v456_9) ? constant_7 : Space{});
        Space v456_12;
        if (!v456_10.empty()) {
          const Path v458_6 = concat_path(v455_6,v455_11_head);
          const Space v458_11 = routine_42(c, v458_6, p1, v455_11_tail);
          v456_12 = compose(v456_10,v458_11);
        }
        const Space v456_13 = unite(v456_8,v456_12);
        v455_11_result = unite(v455_11_result,v456_13);
      }
      const Space v455_11 = std::move(v455_11_result);
      v450_12 = compose(v450_10,v455_11);
    }
    const Space v450_13 = unite(v450_8,v450_12);
    v449_12_result = unite(v449_12_result,v450_13);
  }
  const Space v449_12 = std::move(v449_12_result);
  return v449_12;
}

static Space routine_44(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v459_9_result;
  for (int v459_9_label = 1; v459_9_label <= 2; ++v459_9_label) {
    const Space v459_9_tail = child(s0,v459_9_label);
    if (v459_9_tail.empty()) continue;
    const Path v459_9_head{v459_9_label};
    const Space v460_2 = singleton(v459_9_head);
    const Space v460_3 = intersect(constant_6,v460_2);
    const Space v460_4 = (has_head(v460_3) ? constant_7 : Space{});
    const Space v460_5 = subtract(constant_0,v460_4);
    Space v460_8;
    if (!v460_5.empty()) {
      const Path v461_6 = concat_path(p0,v459_9_head);
      Space v461_7_result;
      for (int v461_7_label = 1; v461_7_label <= 2; ++v461_7_label) {
        const Space v461_7_tail = child(v459_9_tail,v461_7_label);
        if (v461_7_tail.empty()) continue;
        const Path v461_7_head{v461_7_label};
        const Space v462_2 = singleton(v461_7_head);
        const Space v462_3 = intersect(constant_6,v462_2);
        const Space v462_4 = (has_head(v462_3) ? constant_7 : Space{});
        const Space v462_5 = subtract(constant_0,v462_4);
        Space v462_8;
        if (!v462_5.empty()) {
          const Path v463_6 = concat_path(v461_6,v461_7_head);
          const Space v463_7 = routine_92(c, v463_6, p1, v461_7_tail);
          v462_8 = compose(v462_5,v463_7);
        }
        const Space v462_9 = intersect(constant_6,v462_2);
        const Space v462_10 = (has_head(v462_9) ? constant_7 : Space{});
        Space v462_12;
        if (!v462_10.empty()) {
          const Path v464_6 = concat_path(v461_6,v461_7_head);
          const Space v464_11 = routine_93(c, v464_6, p1, v461_7_tail);
          v462_12 = compose(v462_10,v464_11);
        }
        const Space v462_13 = unite(v462_8,v462_12);
        v461_7_result = unite(v461_7_result,v462_13);
      }
      const Space v461_7 = std::move(v461_7_result);
      v460_8 = compose(v460_5,v461_7);
    }
    const Space v460_9 = intersect(constant_6,v460_2);
    const Space v460_10 = (has_head(v460_9) ? constant_7 : Space{});
    Space v460_13;
    if (!v460_10.empty()) {
      const Path v465_6 = concat_path(p0,v459_9_head);
      const Path v465_11 = concat_path(p1,v465_6);
      const Space v465_12 = routine_29(c, v465_11);
      v460_13 = compose(v460_10,v465_12);
    }
    const Space v460_14 = unite(v460_8,v460_13);
    v459_9_result = unite(v459_9_result,v460_14);
  }
  const Space v459_9 = std::move(v459_9_result);
  return v459_9;
}

static Space routine_45(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v466_12_result;
  for (int v466_12_label = 1; v466_12_label <= 2; ++v466_12_label) {
    const Space v466_12_tail = child(s0,v466_12_label);
    if (v466_12_tail.empty()) continue;
    const Path v466_12_head{v466_12_label};
    const Space v467_2 = singleton(v466_12_head);
    const Space v467_3 = intersect(constant_6,v467_2);
    const Space v467_4 = (has_head(v467_3) ? constant_7 : Space{});
    const Space v467_5 = subtract(constant_0,v467_4);
    Space v467_8;
    if (!v467_5.empty()) {
      const Path v468_6 = concat_path(p0,v466_12_head);
      Space v468_7_result;
      for (int v468_7_label = 1; v468_7_label <= 2; ++v468_7_label) {
        const Space v468_7_tail = child(v466_12_tail,v468_7_label);
        if (v468_7_tail.empty()) continue;
        const Path v468_7_head{v468_7_label};
        const Space v469_2 = singleton(v468_7_head);
        const Space v469_3 = intersect(constant_6,v469_2);
        const Space v469_4 = (has_head(v469_3) ? constant_7 : Space{});
        const Space v469_5 = subtract(constant_0,v469_4);
        Space v469_8;
        if (!v469_5.empty()) {
          const Path v470_6 = concat_path(v468_6,v468_7_head);
          const Space v470_7 = routine_94(c, v470_6, v468_7_tail, s1);
          v469_8 = compose(v469_5,v470_7);
        }
        const Space v469_9 = intersect(constant_6,v469_2);
        const Space v469_10 = (has_head(v469_9) ? constant_7 : Space{});
        Space v469_12;
        if (!v469_10.empty()) {
          const Path v471_6 = concat_path(v468_6,v468_7_head);
          const Space v471_11 = routine_95(c, v471_6, v468_7_tail, s1);
          v469_12 = compose(v469_10,v471_11);
        }
        const Space v469_13 = unite(v469_8,v469_12);
        v468_7_result = unite(v468_7_result,v469_13);
      }
      const Space v468_7 = std::move(v468_7_result);
      v467_8 = compose(v467_5,v468_7);
    }
    const Space v467_9 = intersect(constant_6,v467_2);
    const Space v467_10 = (has_head(v467_9) ? constant_7 : Space{});
    Space v467_12;
    if (!v467_10.empty()) {
      const Path v472_6 = concat_path(p0,v466_12_head);
      Space v472_11_result;
      for (int v472_11_label = 1; v472_11_label <= 2; ++v472_11_label) {
        const Space v472_11_tail = child(v466_12_tail,v472_11_label);
        if (v472_11_tail.empty()) continue;
        const Path v472_11_head{v472_11_label};
        const Space v473_2 = singleton(v472_11_head);
        const Space v473_3 = intersect(constant_6,v473_2);
        const Space v473_4 = (has_head(v473_3) ? constant_7 : Space{});
        const Space v473_5 = subtract(constant_0,v473_4);
        Space v473_8;
        if (!v473_5.empty()) {
          const Path v474_6 = concat_path(v472_6,v472_11_head);
          const Space v474_7 = routine_94(c, v474_6, v472_11_tail, s1);
          v473_8 = compose(v473_5,v474_7);
        }
        const Space v473_9 = intersect(constant_6,v473_2);
        const Space v473_10 = (has_head(v473_9) ? constant_7 : Space{});
        Space v473_12;
        if (!v473_10.empty()) {
          const Path v475_6 = concat_path(v472_6,v472_11_head);
          const Space v475_11 = routine_19(c, v475_6, v472_11_tail, s1);
          v473_12 = compose(v473_10,v475_11);
        }
        const Space v473_13 = unite(v473_8,v473_12);
        v472_11_result = unite(v472_11_result,v473_13);
      }
      const Space v472_11 = std::move(v472_11_result);
      v467_12 = compose(v467_10,v472_11);
    }
    const Space v467_13 = unite(v467_8,v467_12);
    v466_12_result = unite(v466_12_result,v467_13);
  }
  const Space v466_12 = std::move(v466_12_result);
  return v466_12;
}

static Space routine_46(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v476_12_result;
  for (int v476_12_label = 1; v476_12_label <= 2; ++v476_12_label) {
    const Space v476_12_tail = child(s0,v476_12_label);
    if (v476_12_tail.empty()) continue;
    const Path v476_12_head{v476_12_label};
    const Space v477_2 = singleton(v476_12_head);
    const Space v477_3 = intersect(constant_6,v477_2);
    const Space v477_4 = (has_head(v477_3) ? constant_7 : Space{});
    const Space v477_5 = subtract(constant_0,v477_4);
    Space v477_8;
    if (!v477_5.empty()) {
      const Path v478_6 = concat_path(p0,v476_12_head);
      Space v478_7_result;
      for (int v478_7_label = 1; v478_7_label <= 2; ++v478_7_label) {
        const Space v478_7_tail = child(v476_12_tail,v478_7_label);
        if (v478_7_tail.empty()) continue;
        const Path v478_7_head{v478_7_label};
        const Space v479_2 = singleton(v478_7_head);
        const Space v479_3 = intersect(constant_6,v479_2);
        const Space v479_4 = (has_head(v479_3) ? constant_7 : Space{});
        const Space v479_5 = subtract(constant_0,v479_4);
        Space v479_8;
        if (!v479_5.empty()) {
          const Path v480_6 = concat_path(v478_6,v478_7_head);
          const Space v480_7 = routine_94(c, v480_6, v478_7_tail, s1);
          v479_8 = compose(v479_5,v480_7);
        }
        const Space v479_9 = intersect(constant_6,v479_2);
        const Space v479_10 = (has_head(v479_9) ? constant_7 : Space{});
        Space v479_12;
        if (!v479_10.empty()) {
          const Path v481_6 = concat_path(v478_6,v478_7_head);
          const Space v481_11 = routine_95(c, v481_6, v478_7_tail, s1);
          v479_12 = compose(v479_10,v481_11);
        }
        const Space v479_13 = unite(v479_8,v479_12);
        v478_7_result = unite(v478_7_result,v479_13);
      }
      const Space v478_7 = std::move(v478_7_result);
      v477_8 = compose(v477_5,v478_7);
    }
    const Space v477_9 = intersect(constant_6,v477_2);
    const Space v477_10 = (has_head(v477_9) ? constant_7 : Space{});
    Space v477_12;
    if (!v477_10.empty()) {
      const Path v482_6 = concat_path(p0,v476_12_head);
      Space v482_11_result;
      for (int v482_11_label = 1; v482_11_label <= 2; ++v482_11_label) {
        const Space v482_11_tail = child(v476_12_tail,v482_11_label);
        if (v482_11_tail.empty()) continue;
        const Path v482_11_head{v482_11_label};
        const Space v483_2 = singleton(v482_11_head);
        const Space v483_3 = intersect(constant_6,v483_2);
        const Space v483_4 = (has_head(v483_3) ? constant_7 : Space{});
        const Space v483_5 = subtract(constant_0,v483_4);
        Space v483_7;
        if (!v483_5.empty()) {
          const Space v484_6 = routine_20(c, v482_11_head, v482_6, v482_11_tail, s1);
          v483_7 = compose(v483_5,v484_6);
        }
        const Space v483_8 = intersect(constant_6,v483_2);
        const Space v483_9 = (has_head(v483_8) ? constant_7 : Space{});
        Space v483_11;
        if (!v483_9.empty()) {
          const Space v485_10 = routine_21(c, v482_11_head, v482_6, v482_11_tail, s1);
          v483_11 = compose(v483_9,v485_10);
        }
        const Space v483_12 = unite(v483_7,v483_11);
        v482_11_result = unite(v482_11_result,v483_12);
      }
      const Space v482_11 = std::move(v482_11_result);
      v477_12 = compose(v477_10,v482_11);
    }
    const Space v477_13 = unite(v477_8,v477_12);
    v476_12_result = unite(v476_12_result,v477_13);
  }
  const Space v476_12 = std::move(v476_12_result);
  return v476_12;
}

static Space routine_47(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v486_13_result;
  for (int v486_13_label = 1; v486_13_label <= 2; ++v486_13_label) {
    const Space v486_13_tail = child(s0,v486_13_label);
    if (v486_13_tail.empty()) continue;
    const Path v486_13_head{v486_13_label};
    const Space v487_2 = singleton(v486_13_head);
    const Space v487_3 = intersect(constant_6,v487_2);
    const Space v487_4 = (has_head(v487_3) ? constant_7 : Space{});
    const Space v487_5 = subtract(constant_0,v487_4);
    Space v487_8;
    if (!v487_5.empty()) {
      const Path v488_6 = concat_path(p0,v486_13_head);
      Space v488_7_result;
      for (int v488_7_label = 1; v488_7_label <= 2; ++v488_7_label) {
        const Space v488_7_tail = child(v486_13_tail,v488_7_label);
        if (v488_7_tail.empty()) continue;
        const Path v488_7_head{v488_7_label};
        const Space v489_2 = singleton(v488_7_head);
        const Space v489_3 = intersect(constant_6,v489_2);
        const Space v489_4 = (has_head(v489_3) ? constant_7 : Space{});
        const Space v489_5 = subtract(constant_0,v489_4);
        Space v489_8;
        if (!v489_5.empty()) {
          const Path v490_6 = concat_path(v488_6,v488_7_head);
          const Space v490_7 = routine_96(c, v490_6, p1, v488_7_tail, s1);
          v489_8 = compose(v489_5,v490_7);
        }
        const Space v489_9 = intersect(constant_6,v489_2);
        const Space v489_10 = (has_head(v489_9) ? constant_7 : Space{});
        Space v489_12;
        if (!v489_10.empty()) {
          const Path v491_6 = concat_path(v488_6,v488_7_head);
          const Space v491_11 = routine_97(c, v491_6, p1, v488_7_tail, s1);
          v489_12 = compose(v489_10,v491_11);
        }
        const Space v489_13 = unite(v489_8,v489_12);
        v488_7_result = unite(v488_7_result,v489_13);
      }
      const Space v488_7 = std::move(v488_7_result);
      v487_8 = compose(v487_5,v488_7);
    }
    const Space v487_9 = intersect(constant_6,v487_2);
    const Space v487_10 = (has_head(v487_9) ? constant_7 : Space{});
    Space v487_12;
    if (!v487_10.empty()) {
      const Path v492_6 = concat_path(p0,v486_13_head);
      Space v492_11_result;
      for (int v492_11_label = 1; v492_11_label <= 2; ++v492_11_label) {
        const Space v492_11_tail = child(v486_13_tail,v492_11_label);
        if (v492_11_tail.empty()) continue;
        const Path v492_11_head{v492_11_label};
        const Space v493_2 = singleton(v492_11_head);
        const Space v493_3 = intersect(constant_6,v493_2);
        const Space v493_4 = (has_head(v493_3) ? constant_7 : Space{});
        const Space v493_5 = subtract(constant_0,v493_4);
        Space v493_8;
        if (!v493_5.empty()) {
          const Path v494_6 = concat_path(v492_6,v492_11_head);
          const Space v494_7 = routine_96(c, v494_6, p1, v492_11_tail, s1);
          v493_8 = compose(v493_5,v494_7);
        }
        const Space v493_9 = intersect(constant_6,v493_2);
        const Space v493_10 = (has_head(v493_9) ? constant_7 : Space{});
        Space v493_12;
        if (!v493_10.empty()) {
          const Path v495_6 = concat_path(v492_6,v492_11_head);
          const Space v495_11 = routine_49(c, v495_6, p1, v492_11_tail, s1);
          v493_12 = compose(v493_10,v495_11);
        }
        const Space v493_13 = unite(v493_8,v493_12);
        v492_11_result = unite(v492_11_result,v493_13);
      }
      const Space v492_11 = std::move(v492_11_result);
      v487_12 = compose(v487_10,v492_11);
    }
    const Space v487_13 = unite(v487_8,v487_12);
    v486_13_result = unite(v486_13_result,v487_13);
  }
  const Space v486_13 = std::move(v486_13_result);
  return v486_13;
}

static Space routine_48(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v496_8 = unwrap(s1,constant_8);
  Space v496_21_result;
  for (int v496_21_label = 1; v496_21_label <= 2; ++v496_21_label) {
    const Space v496_21_tail = child(s0,v496_21_label);
    if (v496_21_tail.empty()) continue;
    const Path v496_21_head{v496_21_label};
    const Space v497_2 = singleton(v496_21_head);
    const Space v497_3 = intersect(constant_6,v497_2);
    const Space v497_4 = (has_head(v497_3) ? constant_7 : Space{});
    const Space v497_5 = subtract(constant_0,v497_4);
    Space v497_8;
    if (!v497_5.empty()) {
      const Path v498_6 = concat_path(p0,v496_21_head);
      Space v498_7_result;
      for (int v498_7_label = 1; v498_7_label <= 2; ++v498_7_label) {
        const Space v498_7_tail = child(v496_21_tail,v498_7_label);
        if (v498_7_tail.empty()) continue;
        const Path v498_7_head{v498_7_label};
        const Space v499_2 = singleton(v498_7_head);
        const Space v499_3 = intersect(constant_6,v499_2);
        const Space v499_4 = (has_head(v499_3) ? constant_7 : Space{});
        const Space v499_5 = subtract(constant_0,v499_4);
        Space v499_8;
        if (!v499_5.empty()) {
          const Path v500_6 = concat_path(v498_6,v498_7_head);
          const Space v500_7 = routine_96(c, v500_6, p1, v498_7_tail, s1);
          v499_8 = compose(v499_5,v500_7);
        }
        const Space v499_9 = intersect(constant_6,v499_2);
        const Space v499_10 = (has_head(v499_9) ? constant_7 : Space{});
        Space v499_12;
        if (!v499_10.empty()) {
          const Path v501_6 = concat_path(v498_6,v498_7_head);
          const Space v501_11 = routine_97(c, v501_6, p1, v498_7_tail, s1);
          v499_12 = compose(v499_10,v501_11);
        }
        const Space v499_13 = unite(v499_8,v499_12);
        v498_7_result = unite(v498_7_result,v499_13);
      }
      const Space v498_7 = std::move(v498_7_result);
      v497_8 = compose(v497_5,v498_7);
    }
    const Space v497_9 = intersect(constant_6,v497_2);
    const Space v497_10 = (has_head(v497_9) ? constant_7 : Space{});
    Space v497_22;
    if (!v497_10.empty()) {
      const Path v502_6 = concat_path(p0,v496_21_head);
      const Path v502_11 = concat_path(p1,v502_6);
      const Space v502_12 = routine_29(c, v502_11);
      const Space v502_13 = intersect(v496_8,v502_12);
      const Space v502_14 = routine_33(c, v502_13);
      Space v502_15_result;
      for (int v502_15_label = 1; v502_15_label <= 2; ++v502_15_label) {
        const Space v502_15_tail = child(v502_14,v502_15_label);
        if (v502_15_tail.empty()) continue;
        const Path v502_15_head{v502_15_label};
        const Space v503_2 = singleton(v502_15_head);
        const Space v503_3 = intersect(constant_6,v503_2);
        const Space v503_4 = (has_head(v503_3) ? constant_7 : Space{});
        const Space v503_5 = subtract(constant_0,v503_4);
        Space v503_7;
        if (!v503_5.empty()) {
          const Space v504_6 = routine_52(c, v502_15_head, v502_15_tail);
          v503_7 = compose(v503_5,v504_6);
        }
        const Space v503_8 = intersect(constant_6,v503_2);
        const Space v503_9 = (has_head(v503_8) ? constant_7 : Space{});
        Space v503_11;
        if (!v503_9.empty()) {
          const Space v505_10 = routine_53(c, v502_15_head, v502_15_tail);
          v503_11 = compose(v503_9,v505_10);
        }
        const Space v503_12 = unite(v503_7,v503_11);
        v502_15_result = unite(v502_15_result,v503_12);
      }
      const Space v502_15 = std::move(v502_15_result);
      const Space v502_16 = routine_54(c, v502_13);
      Space v502_17_result;
      for (int v502_17_label = 1; v502_17_label <= 2; ++v502_17_label) {
        const Space v502_17_tail = child(v502_16,v502_17_label);
        if (v502_17_tail.empty()) continue;
        const Path v502_17_head{v502_17_label};
        const Space v506_2 = singleton(v502_17_head);
        const Space v506_3 = intersect(constant_6,v506_2);
        const Space v506_4 = (has_head(v506_3) ? constant_7 : Space{});
        const Space v506_5 = subtract(constant_0,v506_4);
        Space v506_7;
        if (!v506_5.empty()) {
          const Space v507_6 = routine_55(c, v502_17_head, v502_17_tail);
          v506_7 = compose(v506_5,v507_6);
        }
        const Space v506_8 = intersect(constant_6,v506_2);
        const Space v506_9 = (has_head(v506_8) ? constant_7 : Space{});
        Space v506_11;
        if (!v506_9.empty()) {
          const Space v508_10 = routine_56(c, v502_17_head, v502_17_tail);
          v506_11 = compose(v506_9,v508_10);
        }
        const Space v506_12 = unite(v506_7,v506_11);
        v502_17_result = unite(v502_17_result,v506_12);
      }
      const Space v502_17 = std::move(v502_17_result);
      const Space v502_18 = subtract(v502_15,v502_17);
      const Space v502_19 = singleton(v502_11);
      const Space v502_20 = compose(v502_18,v502_19);
      Space v502_21_result;
      for (int v502_21_label = 1; v502_21_label <= 2; ++v502_21_label) {
        const Space v502_21_tail = child(v502_20,v502_21_label);
        if (v502_21_tail.empty()) continue;
        const Path v502_21_head{v502_21_label};
        const Space v509_2 = singleton(v502_21_head);
        const Space v509_3 = intersect(constant_6,v509_2);
        const Space v509_4 = (has_head(v509_3) ? constant_7 : Space{});
        const Space v509_5 = subtract(constant_0,v509_4);
        Space v509_7;
        if (!v509_5.empty()) {
          const Space v510_6 = routine_57(c, v502_21_head, v502_21_tail);
          v509_7 = compose(v509_5,v510_6);
        }
        const Space v509_8 = intersect(constant_6,v509_2);
        const Space v509_9 = (has_head(v509_8) ? constant_7 : Space{});
        Space v509_11;
        if (!v509_9.empty()) {
          const Space v511_10 = routine_58(c, v502_21_head, v502_21_tail);
          v509_11 = compose(v509_9,v511_10);
        }
        const Space v509_12 = unite(v509_7,v509_11);
        v502_21_result = unite(v502_21_result,v509_12);
      }
      const Space v502_21 = std::move(v502_21_result);
      v497_22 = compose(v497_10,v502_21);
    }
    const Space v497_23 = unite(v497_8,v497_22);
    v496_21_result = unite(v496_21_result,v497_23);
  }
  const Space v496_21 = std::move(v496_21_result);
  return v496_21;
}

static Space routine_49(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v512_5 = unwrap(s1,constant_8);
  const Path v512_6 = concat_path(p1,p0);
  const Space v512_7 = singleton(v512_6);
  Space v512_11_result;
  for (int v512_11_label = 1; v512_11_label <= 2; ++v512_11_label) {
    const Space v512_11_tail = child(v512_7,v512_11_label);
    if (v512_11_tail.empty()) continue;
    const Path v512_11_head{v512_11_label};
    const Space v513_2 = singleton(v512_11_head);
    const Space v513_3 = intersect(constant_6,v513_2);
    const Space v513_4 = (has_head(v513_3) ? constant_7 : Space{});
    const Space v513_5 = subtract(constant_0,v513_4);
    Space v513_7;
    if (!v513_5.empty()) {
      const Space v514_6 = routine_63(c, v512_11_head, v512_11_tail);
      v513_7 = compose(v513_5,v514_6);
    }
    const Space v513_8 = intersect(constant_6,v513_2);
    const Space v513_9 = (has_head(v513_8) ? constant_7 : Space{});
    Space v513_11;
    if (!v513_9.empty()) {
      const Space v515_10 = routine_64(c, v512_11_head, v512_11_tail);
      v513_11 = compose(v513_9,v515_10);
    }
    const Space v513_12 = unite(v513_7,v513_11);
    v512_11_result = unite(v512_11_result,v513_12);
  }
  const Space v512_11 = std::move(v512_11_result);
  const Space v512_12 = intersect(v512_5,v512_11);
  Space v512_16_result;
  for (int v512_16_label = 1; v512_16_label <= 2; ++v512_16_label) {
    const Space v512_16_tail = child(v512_7,v512_16_label);
    if (v512_16_tail.empty()) continue;
    const Path v512_16_head{v512_16_label};
    const Space v516_2 = singleton(v512_16_head);
    const Space v516_3 = intersect(constant_6,v516_2);
    const Space v516_4 = (has_head(v516_3) ? constant_7 : Space{});
    const Space v516_5 = subtract(constant_0,v516_4);
    Space v516_7;
    if (!v516_5.empty()) {
      const Space v517_6 = routine_63(c, v512_16_head, v512_16_tail);
      v516_7 = compose(v516_5,v517_6);
    }
    const Space v516_8 = intersect(constant_6,v516_2);
    const Space v516_9 = (has_head(v516_8) ? constant_7 : Space{});
    Space v516_11;
    if (!v516_9.empty()) {
      const Space v518_10 = routine_64(c, v512_16_head, v512_16_tail);
      v516_11 = compose(v516_9,v518_10);
    }
    const Space v516_12 = unite(v516_7,v516_11);
    v512_16_result = unite(v512_16_result,v516_12);
  }
  const Space v512_16 = std::move(v512_16_result);
  const Space v512_17 = intersect(v512_5,v512_16);
  const Space v512_18 = routine_66(c, v512_17);
  const Space v512_19 = routine_65(c, v512_18);
  const Space v512_20 = subtract(v512_12,v512_19);
  Space v512_24_result;
  for (int v512_24_label = 1; v512_24_label <= 2; ++v512_24_label) {
    const Space v512_24_tail = child(v512_7,v512_24_label);
    if (v512_24_tail.empty()) continue;
    const Path v512_24_head{v512_24_label};
    const Space v519_2 = singleton(v512_24_head);
    const Space v519_3 = intersect(constant_6,v519_2);
    const Space v519_4 = (has_head(v519_3) ? constant_7 : Space{});
    const Space v519_5 = subtract(constant_0,v519_4);
    Space v519_7;
    if (!v519_5.empty()) {
      const Space v520_6 = routine_63(c, v512_24_head, v512_24_tail);
      v519_7 = compose(v519_5,v520_6);
    }
    const Space v519_8 = intersect(constant_6,v519_2);
    const Space v519_9 = (has_head(v519_8) ? constant_7 : Space{});
    Space v519_11;
    if (!v519_9.empty()) {
      const Space v521_10 = routine_64(c, v512_24_head, v512_24_tail);
      v519_11 = compose(v519_9,v521_10);
    }
    const Space v519_12 = unite(v519_7,v519_11);
    v512_24_result = unite(v512_24_result,v519_12);
  }
  const Space v512_24 = std::move(v512_24_result);
  const Space v512_25 = intersect(v512_5,v512_24);
  const Space v512_26 = routine_65(c, v512_25);
  const Space v512_27 = intersect(v512_20,v512_26);
  Space v512_37_result;
  for (int v512_37_label = 1; v512_37_label <= 2; ++v512_37_label) {
    const Space v512_37_tail = child(v512_27,v512_37_label);
    if (v512_37_tail.empty()) continue;
    const Path v512_37_head{v512_37_label};
    const Space v522_2 = singleton(v512_37_head);
    const Space v522_3 = intersect(constant_6,v522_2);
    const Space v522_4 = (has_head(v522_3) ? constant_7 : Space{});
    const Space v522_5 = subtract(constant_0,v522_4);
    Space v522_7;
    if (!v522_5.empty()) {
      Space v523_6_result;
      for (int v523_6_label = 1; v523_6_label <= 2; ++v523_6_label) {
        const Space v523_6_tail = child(v512_37_tail,v523_6_label);
        if (v523_6_tail.empty()) continue;
        const Path v523_6_head{v523_6_label};
        const Space v524_2 = singleton(v523_6_head);
        const Space v524_3 = intersect(constant_6,v524_2);
        const Space v524_4 = (has_head(v524_3) ? constant_7 : Space{});
        const Space v524_5 = subtract(constant_0,v524_4);
        Space v524_8;
        if (!v524_5.empty()) {
          const Path v525_6 = concat_path(v512_37_head,v523_6_head);
          const Space v525_7 = routine_98(c, v525_6, v523_6_tail);
          v524_8 = compose(v524_5,v525_7);
        }
        const Space v524_9 = intersect(constant_6,v524_2);
        const Space v524_10 = (has_head(v524_9) ? constant_7 : Space{});
        Space v524_12;
        if (!v524_10.empty()) {
          const Path v526_6 = concat_path(v512_37_head,v523_6_head);
          const Space v526_11 = routine_99(c, v526_6, v523_6_tail);
          v524_12 = compose(v524_10,v526_11);
        }
        const Space v524_13 = unite(v524_8,v524_12);
        v523_6_result = unite(v523_6_result,v524_13);
      }
      const Space v523_6 = std::move(v523_6_result);
      v522_7 = compose(v522_5,v523_6);
    }
    const Space v522_8 = intersect(constant_6,v522_2);
    const Space v522_9 = (has_head(v522_8) ? constant_7 : Space{});
    Space v522_11;
    if (!v522_9.empty()) {
      Space v527_10_result;
      for (int v527_10_label = 1; v527_10_label <= 2; ++v527_10_label) {
        const Space v527_10_tail = child(v512_37_tail,v527_10_label);
        if (v527_10_tail.empty()) continue;
        const Path v527_10_head{v527_10_label};
        const Space v528_2 = singleton(v527_10_head);
        const Space v528_3 = intersect(constant_6,v528_2);
        const Space v528_4 = (has_head(v528_3) ? constant_7 : Space{});
        const Space v528_5 = subtract(constant_0,v528_4);
        Space v528_8;
        if (!v528_5.empty()) {
          const Path v529_6 = concat_path(v512_37_head,v527_10_head);
          const Space v529_7 = routine_98(c, v529_6, v527_10_tail);
          v528_8 = compose(v528_5,v529_7);
        }
        const Space v528_9 = intersect(constant_6,v528_2);
        const Space v528_10 = (has_head(v528_9) ? constant_7 : Space{});
        Space v528_12;
        if (!v528_10.empty()) {
          const Path v530_6 = concat_path(v512_37_head,v527_10_head);
          const Space v530_11 = routine_100(c, v530_6, v527_10_tail);
          v528_12 = compose(v528_10,v530_11);
        }
        const Space v528_13 = unite(v528_8,v528_12);
        v527_10_result = unite(v527_10_result,v528_13);
      }
      const Space v527_10 = std::move(v527_10_result);
      v522_11 = compose(v522_9,v527_10);
    }
    const Space v522_12 = unite(v522_7,v522_11);
    v512_37_result = unite(v512_37_result,v522_12);
  }
  const Space v512_37 = std::move(v512_37_result);
  Space v512_41_result;
  for (int v512_41_label = 1; v512_41_label <= 2; ++v512_41_label) {
    const Space v512_41_tail = child(v512_7,v512_41_label);
    if (v512_41_tail.empty()) continue;
    const Path v512_41_head{v512_41_label};
    const Space v531_2 = singleton(v512_41_head);
    const Space v531_3 = intersect(constant_6,v531_2);
    const Space v531_4 = (has_head(v531_3) ? constant_7 : Space{});
    const Space v531_5 = subtract(constant_0,v531_4);
    Space v531_7;
    if (!v531_5.empty()) {
      const Space v532_6 = routine_63(c, v512_41_head, v512_41_tail);
      v531_7 = compose(v531_5,v532_6);
    }
    const Space v531_8 = intersect(constant_6,v531_2);
    const Space v531_9 = (has_head(v531_8) ? constant_7 : Space{});
    Space v531_11;
    if (!v531_9.empty()) {
      const Space v533_10 = routine_64(c, v512_41_head, v512_41_tail);
      v531_11 = compose(v531_9,v533_10);
    }
    const Space v531_12 = unite(v531_7,v531_11);
    v512_41_result = unite(v512_41_result,v531_12);
  }
  const Space v512_41 = std::move(v512_41_result);
  const Space v512_42 = intersect(v512_5,v512_41);
  Space v512_46_result;
  for (int v512_46_label = 1; v512_46_label <= 2; ++v512_46_label) {
    const Space v512_46_tail = child(v512_7,v512_46_label);
    if (v512_46_tail.empty()) continue;
    const Path v512_46_head{v512_46_label};
    const Space v534_2 = singleton(v512_46_head);
    const Space v534_3 = intersect(constant_6,v534_2);
    const Space v534_4 = (has_head(v534_3) ? constant_7 : Space{});
    const Space v534_5 = subtract(constant_0,v534_4);
    Space v534_7;
    if (!v534_5.empty()) {
      const Space v535_6 = routine_63(c, v512_46_head, v512_46_tail);
      v534_7 = compose(v534_5,v535_6);
    }
    const Space v534_8 = intersect(constant_6,v534_2);
    const Space v534_9 = (has_head(v534_8) ? constant_7 : Space{});
    Space v534_11;
    if (!v534_9.empty()) {
      const Space v536_10 = routine_64(c, v512_46_head, v512_46_tail);
      v534_11 = compose(v534_9,v536_10);
    }
    const Space v534_12 = unite(v534_7,v534_11);
    v512_46_result = unite(v512_46_result,v534_12);
  }
  const Space v512_46 = std::move(v512_46_result);
  const Space v512_47 = intersect(v512_5,v512_46);
  const Space v512_48 = routine_101(c, v512_47);
  const Space v512_49 = subtract(v512_42,v512_48);
  Space v512_53_result;
  for (int v512_53_label = 1; v512_53_label <= 2; ++v512_53_label) {
    const Space v512_53_tail = child(v512_7,v512_53_label);
    if (v512_53_tail.empty()) continue;
    const Path v512_53_head{v512_53_label};
    const Space v537_2 = singleton(v512_53_head);
    const Space v537_3 = intersect(constant_6,v537_2);
    const Space v537_4 = (has_head(v537_3) ? constant_7 : Space{});
    const Space v537_5 = subtract(constant_0,v537_4);
    Space v537_7;
    if (!v537_5.empty()) {
      const Space v538_6 = routine_63(c, v512_53_head, v512_53_tail);
      v537_7 = compose(v537_5,v538_6);
    }
    const Space v537_8 = intersect(constant_6,v537_2);
    const Space v537_9 = (has_head(v537_8) ? constant_7 : Space{});
    Space v537_11;
    if (!v537_9.empty()) {
      const Space v539_10 = routine_64(c, v512_53_head, v512_53_tail);
      v537_11 = compose(v537_9,v539_10);
    }
    const Space v537_12 = unite(v537_7,v537_11);
    v512_53_result = unite(v512_53_result,v537_12);
  }
  const Space v512_53 = std::move(v512_53_result);
  const Space v512_54 = intersect(v512_5,v512_53);
  const Space v512_55 = routine_66(c, v512_54);
  const Space v512_56 = routine_65(c, v512_55);
  const Space v512_57 = intersect(v512_49,v512_56);
  Space v512_67_result;
  for (int v512_67_label = 1; v512_67_label <= 2; ++v512_67_label) {
    const Space v512_67_tail = child(v512_57,v512_67_label);
    if (v512_67_tail.empty()) continue;
    const Path v512_67_head{v512_67_label};
    const Space v540_2 = singleton(v512_67_head);
    const Space v540_3 = intersect(constant_6,v540_2);
    const Space v540_4 = (has_head(v540_3) ? constant_7 : Space{});
    const Space v540_5 = subtract(constant_0,v540_4);
    Space v540_7;
    if (!v540_5.empty()) {
      Space v541_6_result;
      for (int v541_6_label = 1; v541_6_label <= 2; ++v541_6_label) {
        const Space v541_6_tail = child(v512_67_tail,v541_6_label);
        if (v541_6_tail.empty()) continue;
        const Path v541_6_head{v541_6_label};
        const Space v542_2 = singleton(v541_6_head);
        const Space v542_3 = intersect(constant_6,v542_2);
        const Space v542_4 = (has_head(v542_3) ? constant_7 : Space{});
        const Space v542_5 = subtract(constant_0,v542_4);
        Space v542_8;
        if (!v542_5.empty()) {
          const Path v543_6 = concat_path(v512_67_head,v541_6_head);
          const Space v543_7 = routine_102(c, v543_6, v541_6_tail);
          v542_8 = compose(v542_5,v543_7);
        }
        const Space v542_9 = intersect(constant_6,v542_2);
        const Space v542_10 = (has_head(v542_9) ? constant_7 : Space{});
        Space v542_12;
        if (!v542_10.empty()) {
          const Path v544_6 = concat_path(v512_67_head,v541_6_head);
          const Space v544_11 = routine_103(c, v544_6, v541_6_tail);
          v542_12 = compose(v542_10,v544_11);
        }
        const Space v542_13 = unite(v542_8,v542_12);
        v541_6_result = unite(v541_6_result,v542_13);
      }
      const Space v541_6 = std::move(v541_6_result);
      v540_7 = compose(v540_5,v541_6);
    }
    const Space v540_8 = intersect(constant_6,v540_2);
    const Space v540_9 = (has_head(v540_8) ? constant_7 : Space{});
    Space v540_11;
    if (!v540_9.empty()) {
      Space v545_10_result;
      for (int v545_10_label = 1; v545_10_label <= 2; ++v545_10_label) {
        const Space v545_10_tail = child(v512_67_tail,v545_10_label);
        if (v545_10_tail.empty()) continue;
        const Path v545_10_head{v545_10_label};
        const Space v546_2 = singleton(v545_10_head);
        const Space v546_3 = intersect(constant_6,v546_2);
        const Space v546_4 = (has_head(v546_3) ? constant_7 : Space{});
        const Space v546_5 = subtract(constant_0,v546_4);
        Space v546_8;
        if (!v546_5.empty()) {
          const Path v547_6 = concat_path(v512_67_head,v545_10_head);
          const Space v547_7 = routine_102(c, v547_6, v545_10_tail);
          v546_8 = compose(v546_5,v547_7);
        }
        const Space v546_9 = intersect(constant_6,v546_2);
        const Space v546_10 = (has_head(v546_9) ? constant_7 : Space{});
        Space v546_12;
        if (!v546_10.empty()) {
          const Path v548_6 = concat_path(v512_67_head,v545_10_head);
          const Space v548_11 = routine_104(c, v548_6, v545_10_tail);
          v546_12 = compose(v546_10,v548_11);
        }
        const Space v546_13 = unite(v546_8,v546_12);
        v545_10_result = unite(v545_10_result,v546_13);
      }
      const Space v545_10 = std::move(v545_10_result);
      v540_11 = compose(v540_9,v545_10);
    }
    const Space v540_12 = unite(v540_7,v540_11);
    v512_67_result = unite(v512_67_result,v540_12);
  }
  const Space v512_67 = std::move(v512_67_result);
  const Space v512_68 = subtract(v512_37,v512_67);
  const Space v512_69 = compose(v512_68,v512_7);
  Space v512_79_result;
  for (int v512_79_label = 1; v512_79_label <= 2; ++v512_79_label) {
    const Space v512_79_tail = child(v512_69,v512_79_label);
    if (v512_79_tail.empty()) continue;
    const Path v512_79_head{v512_79_label};
    const Space v549_2 = singleton(v512_79_head);
    const Space v549_3 = intersect(constant_6,v549_2);
    const Space v549_4 = (has_head(v549_3) ? constant_7 : Space{});
    const Space v549_5 = subtract(constant_0,v549_4);
    Space v549_7;
    if (!v549_5.empty()) {
      Space v550_6_result;
      for (int v550_6_label = 1; v550_6_label <= 2; ++v550_6_label) {
        const Space v550_6_tail = child(v512_79_tail,v550_6_label);
        if (v550_6_tail.empty()) continue;
        const Path v550_6_head{v550_6_label};
        const Space v551_2 = singleton(v550_6_head);
        const Space v551_3 = intersect(constant_6,v551_2);
        const Space v551_4 = (has_head(v551_3) ? constant_7 : Space{});
        const Space v551_5 = subtract(constant_0,v551_4);
        Space v551_8;
        if (!v551_5.empty()) {
          const Path v552_6 = concat_path(v512_79_head,v550_6_head);
          const Space v552_7 = routine_105(c, v552_6, v550_6_tail);
          v551_8 = compose(v551_5,v552_7);
        }
        const Space v551_9 = intersect(constant_6,v551_2);
        const Space v551_10 = (has_head(v551_9) ? constant_7 : Space{});
        Space v551_12;
        if (!v551_10.empty()) {
          const Path v553_6 = concat_path(v512_79_head,v550_6_head);
          const Space v553_11 = routine_106(c, v553_6, v550_6_tail);
          v551_12 = compose(v551_10,v553_11);
        }
        const Space v551_13 = unite(v551_8,v551_12);
        v550_6_result = unite(v550_6_result,v551_13);
      }
      const Space v550_6 = std::move(v550_6_result);
      v549_7 = compose(v549_5,v550_6);
    }
    const Space v549_8 = intersect(constant_6,v549_2);
    const Space v549_9 = (has_head(v549_8) ? constant_7 : Space{});
    Space v549_11;
    if (!v549_9.empty()) {
      Space v554_10_result;
      for (int v554_10_label = 1; v554_10_label <= 2; ++v554_10_label) {
        const Space v554_10_tail = child(v512_79_tail,v554_10_label);
        if (v554_10_tail.empty()) continue;
        const Path v554_10_head{v554_10_label};
        const Space v555_2 = singleton(v554_10_head);
        const Space v555_3 = intersect(constant_6,v555_2);
        const Space v555_4 = (has_head(v555_3) ? constant_7 : Space{});
        const Space v555_5 = subtract(constant_0,v555_4);
        Space v555_8;
        if (!v555_5.empty()) {
          const Path v556_6 = concat_path(v512_79_head,v554_10_head);
          const Space v556_7 = routine_105(c, v556_6, v554_10_tail);
          v555_8 = compose(v555_5,v556_7);
        }
        const Space v555_9 = intersect(constant_6,v555_2);
        const Space v555_10 = (has_head(v555_9) ? constant_7 : Space{});
        Space v555_12;
        if (!v555_10.empty()) {
          const Path v557_6 = concat_path(v512_79_head,v554_10_head);
          const Space v557_11 = routine_107(c, v557_6, v554_10_tail);
          v555_12 = compose(v555_10,v557_11);
        }
        const Space v555_13 = unite(v555_8,v555_12);
        v554_10_result = unite(v554_10_result,v555_13);
      }
      const Space v554_10 = std::move(v554_10_result);
      v549_11 = compose(v549_9,v554_10);
    }
    const Space v549_12 = unite(v549_7,v549_11);
    v512_79_result = unite(v512_79_result,v549_12);
  }
  const Space v512_79 = std::move(v512_79_result);
  return v512_79;
}

static Space routine_50(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v558_13_result;
  for (int v558_13_label = 1; v558_13_label <= 2; ++v558_13_label) {
    const Space v558_13_tail = child(s0,v558_13_label);
    if (v558_13_tail.empty()) continue;
    const Path v558_13_head{v558_13_label};
    const Space v559_2 = singleton(v558_13_head);
    const Space v559_3 = intersect(constant_6,v559_2);
    const Space v559_4 = (has_head(v559_3) ? constant_7 : Space{});
    const Space v559_5 = subtract(constant_0,v559_4);
    Space v559_8;
    if (!v559_5.empty()) {
      const Path v560_6 = concat_path(p0,v558_13_head);
      Space v560_7_result;
      for (int v560_7_label = 1; v560_7_label <= 2; ++v560_7_label) {
        const Space v560_7_tail = child(v558_13_tail,v560_7_label);
        if (v560_7_tail.empty()) continue;
        const Path v560_7_head{v560_7_label};
        const Space v561_2 = singleton(v560_7_head);
        const Space v561_3 = intersect(constant_6,v561_2);
        const Space v561_4 = (has_head(v561_3) ? constant_7 : Space{});
        const Space v561_5 = subtract(constant_0,v561_4);
        Space v561_8;
        if (!v561_5.empty()) {
          const Path v562_6 = concat_path(v560_6,v560_7_head);
          const Space v562_7 = routine_108(c, v562_6, p1, v560_7_tail, s1);
          v561_8 = compose(v561_5,v562_7);
        }
        const Space v561_9 = intersect(constant_6,v561_2);
        const Space v561_10 = (has_head(v561_9) ? constant_7 : Space{});
        Space v561_12;
        if (!v561_10.empty()) {
          const Path v563_6 = concat_path(v560_6,v560_7_head);
          const Space v563_11 = routine_109(c, v563_6, p1, v560_7_tail, s1);
          v561_12 = compose(v561_10,v563_11);
        }
        const Space v561_13 = unite(v561_8,v561_12);
        v560_7_result = unite(v560_7_result,v561_13);
      }
      const Space v560_7 = std::move(v560_7_result);
      v559_8 = compose(v559_5,v560_7);
    }
    const Space v559_9 = intersect(constant_6,v559_2);
    const Space v559_10 = (has_head(v559_9) ? constant_7 : Space{});
    Space v559_12;
    if (!v559_10.empty()) {
      const Path v564_6 = concat_path(p0,v558_13_head);
      Space v564_11_result;
      for (int v564_11_label = 1; v564_11_label <= 2; ++v564_11_label) {
        const Space v564_11_tail = child(v558_13_tail,v564_11_label);
        if (v564_11_tail.empty()) continue;
        const Path v564_11_head{v564_11_label};
        const Space v565_2 = singleton(v564_11_head);
        const Space v565_3 = intersect(constant_6,v565_2);
        const Space v565_4 = (has_head(v565_3) ? constant_7 : Space{});
        const Space v565_5 = subtract(constant_0,v565_4);
        Space v565_8;
        if (!v565_5.empty()) {
          const Path v566_6 = concat_path(v564_6,v564_11_head);
          const Space v566_7 = routine_108(c, v566_6, p1, v564_11_tail, s1);
          v565_8 = compose(v565_5,v566_7);
        }
        const Space v565_9 = intersect(constant_6,v565_2);
        const Space v565_10 = (has_head(v565_9) ? constant_7 : Space{});
        Space v565_12;
        if (!v565_10.empty()) {
          const Path v567_6 = concat_path(v564_6,v564_11_head);
          const Space v567_11 = routine_49(c, v567_6, p1, v564_11_tail, s1);
          v565_12 = compose(v565_10,v567_11);
        }
        const Space v565_13 = unite(v565_8,v565_12);
        v564_11_result = unite(v564_11_result,v565_13);
      }
      const Space v564_11 = std::move(v564_11_result);
      v559_12 = compose(v559_10,v564_11);
    }
    const Space v559_13 = unite(v559_8,v559_12);
    v558_13_result = unite(v558_13_result,v559_13);
  }
  const Space v558_13 = std::move(v558_13_result);
  return v558_13;
}

static Space routine_51(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v568_8 = unwrap(s1,constant_8);
  Space v568_21_result;
  for (int v568_21_label = 1; v568_21_label <= 2; ++v568_21_label) {
    const Space v568_21_tail = child(s0,v568_21_label);
    if (v568_21_tail.empty()) continue;
    const Path v568_21_head{v568_21_label};
    const Space v569_2 = singleton(v568_21_head);
    const Space v569_3 = intersect(constant_6,v569_2);
    const Space v569_4 = (has_head(v569_3) ? constant_7 : Space{});
    const Space v569_5 = subtract(constant_0,v569_4);
    Space v569_8;
    if (!v569_5.empty()) {
      const Path v570_6 = concat_path(p0,v568_21_head);
      Space v570_7_result;
      for (int v570_7_label = 1; v570_7_label <= 2; ++v570_7_label) {
        const Space v570_7_tail = child(v568_21_tail,v570_7_label);
        if (v570_7_tail.empty()) continue;
        const Path v570_7_head{v570_7_label};
        const Space v571_2 = singleton(v570_7_head);
        const Space v571_3 = intersect(constant_6,v571_2);
        const Space v571_4 = (has_head(v571_3) ? constant_7 : Space{});
        const Space v571_5 = subtract(constant_0,v571_4);
        Space v571_8;
        if (!v571_5.empty()) {
          const Path v572_6 = concat_path(v570_6,v570_7_head);
          const Space v572_7 = routine_108(c, v572_6, p1, v570_7_tail, s1);
          v571_8 = compose(v571_5,v572_7);
        }
        const Space v571_9 = intersect(constant_6,v571_2);
        const Space v571_10 = (has_head(v571_9) ? constant_7 : Space{});
        Space v571_12;
        if (!v571_10.empty()) {
          const Path v573_6 = concat_path(v570_6,v570_7_head);
          const Space v573_11 = routine_109(c, v573_6, p1, v570_7_tail, s1);
          v571_12 = compose(v571_10,v573_11);
        }
        const Space v571_13 = unite(v571_8,v571_12);
        v570_7_result = unite(v570_7_result,v571_13);
      }
      const Space v570_7 = std::move(v570_7_result);
      v569_8 = compose(v569_5,v570_7);
    }
    const Space v569_9 = intersect(constant_6,v569_2);
    const Space v569_10 = (has_head(v569_9) ? constant_7 : Space{});
    Space v569_22;
    if (!v569_10.empty()) {
      const Path v574_6 = concat_path(p0,v568_21_head);
      const Path v574_11 = concat_path(p1,v574_6);
      const Space v574_12 = routine_29(c, v574_11);
      const Space v574_13 = intersect(v568_8,v574_12);
      const Space v574_14 = routine_33(c, v574_13);
      Space v574_15_result;
      for (int v574_15_label = 1; v574_15_label <= 2; ++v574_15_label) {
        const Space v574_15_tail = child(v574_14,v574_15_label);
        if (v574_15_tail.empty()) continue;
        const Path v574_15_head{v574_15_label};
        const Space v575_2 = singleton(v574_15_head);
        const Space v575_3 = intersect(constant_6,v575_2);
        const Space v575_4 = (has_head(v575_3) ? constant_7 : Space{});
        const Space v575_5 = subtract(constant_0,v575_4);
        Space v575_7;
        if (!v575_5.empty()) {
          const Space v576_6 = routine_52(c, v574_15_head, v574_15_tail);
          v575_7 = compose(v575_5,v576_6);
        }
        const Space v575_8 = intersect(constant_6,v575_2);
        const Space v575_9 = (has_head(v575_8) ? constant_7 : Space{});
        Space v575_11;
        if (!v575_9.empty()) {
          const Space v577_10 = routine_53(c, v574_15_head, v574_15_tail);
          v575_11 = compose(v575_9,v577_10);
        }
        const Space v575_12 = unite(v575_7,v575_11);
        v574_15_result = unite(v574_15_result,v575_12);
      }
      const Space v574_15 = std::move(v574_15_result);
      const Space v574_16 = routine_54(c, v574_13);
      Space v574_17_result;
      for (int v574_17_label = 1; v574_17_label <= 2; ++v574_17_label) {
        const Space v574_17_tail = child(v574_16,v574_17_label);
        if (v574_17_tail.empty()) continue;
        const Path v574_17_head{v574_17_label};
        const Space v578_2 = singleton(v574_17_head);
        const Space v578_3 = intersect(constant_6,v578_2);
        const Space v578_4 = (has_head(v578_3) ? constant_7 : Space{});
        const Space v578_5 = subtract(constant_0,v578_4);
        Space v578_7;
        if (!v578_5.empty()) {
          const Space v579_6 = routine_55(c, v574_17_head, v574_17_tail);
          v578_7 = compose(v578_5,v579_6);
        }
        const Space v578_8 = intersect(constant_6,v578_2);
        const Space v578_9 = (has_head(v578_8) ? constant_7 : Space{});
        Space v578_11;
        if (!v578_9.empty()) {
          const Space v580_10 = routine_56(c, v574_17_head, v574_17_tail);
          v578_11 = compose(v578_9,v580_10);
        }
        const Space v578_12 = unite(v578_7,v578_11);
        v574_17_result = unite(v574_17_result,v578_12);
      }
      const Space v574_17 = std::move(v574_17_result);
      const Space v574_18 = subtract(v574_15,v574_17);
      const Space v574_19 = singleton(v574_11);
      const Space v574_20 = compose(v574_18,v574_19);
      Space v574_21_result;
      for (int v574_21_label = 1; v574_21_label <= 2; ++v574_21_label) {
        const Space v574_21_tail = child(v574_20,v574_21_label);
        if (v574_21_tail.empty()) continue;
        const Path v574_21_head{v574_21_label};
        const Space v581_2 = singleton(v574_21_head);
        const Space v581_3 = intersect(constant_6,v581_2);
        const Space v581_4 = (has_head(v581_3) ? constant_7 : Space{});
        const Space v581_5 = subtract(constant_0,v581_4);
        Space v581_7;
        if (!v581_5.empty()) {
          const Space v582_6 = routine_57(c, v574_21_head, v574_21_tail);
          v581_7 = compose(v581_5,v582_6);
        }
        const Space v581_8 = intersect(constant_6,v581_2);
        const Space v581_9 = (has_head(v581_8) ? constant_7 : Space{});
        Space v581_11;
        if (!v581_9.empty()) {
          const Space v583_10 = routine_58(c, v574_21_head, v574_21_tail);
          v581_11 = compose(v581_9,v583_10);
        }
        const Space v581_12 = unite(v581_7,v581_11);
        v574_21_result = unite(v574_21_result,v581_12);
      }
      const Space v574_21 = std::move(v574_21_result);
      v569_22 = compose(v569_10,v574_21);
    }
    const Space v569_23 = unite(v569_8,v569_22);
    v568_21_result = unite(v568_21_result,v569_23);
  }
  const Space v568_21 = std::move(v568_21_result);
  return v568_21;
}

static Space routine_52(Context& c, const Path& p0, const Space& s0) {
  Space v584_11_result;
  for (int v584_11_label = 1; v584_11_label <= 2; ++v584_11_label) {
    const Space v584_11_tail = child(s0,v584_11_label);
    if (v584_11_tail.empty()) continue;
    const Path v584_11_head{v584_11_label};
    const Space v585_2 = singleton(v584_11_head);
    const Space v585_3 = intersect(constant_6,v585_2);
    const Space v585_4 = (has_head(v585_3) ? constant_7 : Space{});
    const Space v585_5 = subtract(constant_0,v585_4);
    Space v585_8;
    if (!v585_5.empty()) {
      const Path v586_6 = concat_path(p0,v584_11_head);
      Space v586_7_result;
      for (int v586_7_label = 1; v586_7_label <= 2; ++v586_7_label) {
        const Space v586_7_tail = child(v584_11_tail,v586_7_label);
        if (v586_7_tail.empty()) continue;
        const Path v586_7_head{v586_7_label};
        const Space v587_2 = singleton(v586_7_head);
        const Space v587_3 = intersect(constant_6,v587_2);
        const Space v587_4 = (has_head(v587_3) ? constant_7 : Space{});
        const Space v587_5 = subtract(constant_0,v587_4);
        Space v587_8;
        if (!v587_5.empty()) {
          const Path v588_6 = concat_path(v586_6,v586_7_head);
          const Space v588_7 = routine_110(c, v588_6, v586_7_tail);
          v587_8 = compose(v587_5,v588_7);
        }
        const Space v587_9 = intersect(constant_6,v587_2);
        const Space v587_10 = (has_head(v587_9) ? constant_7 : Space{});
        Space v587_12;
        if (!v587_10.empty()) {
          const Path v589_6 = concat_path(v586_6,v586_7_head);
          const Space v589_11 = routine_111(c, v589_6, v586_7_tail);
          v587_12 = compose(v587_10,v589_11);
        }
        const Space v587_13 = unite(v587_8,v587_12);
        v586_7_result = unite(v586_7_result,v587_13);
      }
      const Space v586_7 = std::move(v586_7_result);
      v585_8 = compose(v585_5,v586_7);
    }
    const Space v585_9 = intersect(constant_6,v585_2);
    const Space v585_10 = (has_head(v585_9) ? constant_7 : Space{});
    Space v585_12;
    if (!v585_10.empty()) {
      const Path v590_6 = concat_path(p0,v584_11_head);
      Space v590_11_result;
      for (int v590_11_label = 1; v590_11_label <= 2; ++v590_11_label) {
        const Space v590_11_tail = child(v584_11_tail,v590_11_label);
        if (v590_11_tail.empty()) continue;
        const Path v590_11_head{v590_11_label};
        const Space v591_2 = singleton(v590_11_head);
        const Space v591_3 = intersect(constant_6,v591_2);
        const Space v591_4 = (has_head(v591_3) ? constant_7 : Space{});
        const Space v591_5 = subtract(constant_0,v591_4);
        Space v591_8;
        if (!v591_5.empty()) {
          const Path v592_6 = concat_path(v590_6,v590_11_head);
          const Space v592_7 = routine_110(c, v592_6, v590_11_tail);
          v591_8 = compose(v591_5,v592_7);
        }
        const Space v591_9 = intersect(constant_6,v591_2);
        const Space v591_10 = (has_head(v591_9) ? constant_7 : Space{});
        Space v591_12;
        if (!v591_10.empty()) {
          const Path v593_6 = concat_path(v590_6,v590_11_head);
          const Space v593_11 = routine_100(c, v593_6, v590_11_tail);
          v591_12 = compose(v591_10,v593_11);
        }
        const Space v591_13 = unite(v591_8,v591_12);
        v590_11_result = unite(v590_11_result,v591_13);
      }
      const Space v590_11 = std::move(v590_11_result);
      v585_12 = compose(v585_10,v590_11);
    }
    const Space v585_13 = unite(v585_8,v585_12);
    v584_11_result = unite(v584_11_result,v585_13);
  }
  const Space v584_11 = std::move(v584_11_result);
  return v584_11;
}

static Space routine_53(Context& c, const Path& p0, const Space& s0) {
  Space v594_9_result;
  for (int v594_9_label = 1; v594_9_label <= 2; ++v594_9_label) {
    const Space v594_9_tail = child(s0,v594_9_label);
    if (v594_9_tail.empty()) continue;
    const Path v594_9_head{v594_9_label};
    const Space v595_2 = singleton(v594_9_head);
    const Space v595_3 = intersect(constant_6,v595_2);
    const Space v595_4 = (has_head(v595_3) ? constant_7 : Space{});
    const Space v595_5 = subtract(constant_0,v595_4);
    Space v595_8;
    if (!v595_5.empty()) {
      const Path v596_6 = concat_path(p0,v594_9_head);
      Space v596_7_result;
      for (int v596_7_label = 1; v596_7_label <= 2; ++v596_7_label) {
        const Space v596_7_tail = child(v594_9_tail,v596_7_label);
        if (v596_7_tail.empty()) continue;
        const Path v596_7_head{v596_7_label};
        const Space v597_2 = singleton(v596_7_head);
        const Space v597_3 = intersect(constant_6,v597_2);
        const Space v597_4 = (has_head(v597_3) ? constant_7 : Space{});
        const Space v597_5 = subtract(constant_0,v597_4);
        Space v597_8;
        if (!v597_5.empty()) {
          const Path v598_6 = concat_path(v596_6,v596_7_head);
          const Space v598_7 = routine_110(c, v598_6, v596_7_tail);
          v597_8 = compose(v597_5,v598_7);
        }
        const Space v597_9 = intersect(constant_6,v597_2);
        const Space v597_10 = (has_head(v597_9) ? constant_7 : Space{});
        Space v597_12;
        if (!v597_10.empty()) {
          const Path v599_6 = concat_path(v596_6,v596_7_head);
          const Space v599_11 = routine_111(c, v599_6, v596_7_tail);
          v597_12 = compose(v597_10,v599_11);
        }
        const Space v597_13 = unite(v597_8,v597_12);
        v596_7_result = unite(v596_7_result,v597_13);
      }
      const Space v596_7 = std::move(v596_7_result);
      v595_8 = compose(v595_5,v596_7);
    }
    const Space v595_9 = intersect(constant_6,v595_2);
    const Space v595_10 = (has_head(v595_9) ? constant_7 : Space{});
    const Space v595_11 = compose(v595_10,constant_9);
    const Space v595_12 = unite(v595_8,v595_11);
    v594_9_result = unite(v594_9_result,v595_12);
  }
  const Space v594_9 = std::move(v594_9_result);
  return v594_9;
}

static Space routine_54(Context& c, const Space& s0) {
  const Space v600_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v600_2 = first_matching(s0,constant_0,false);
  const Space v600_3 = unite(v600_1,v600_2);
  Space v600_6;
  if (!v600_3.empty()) {
    const Space v601_4 = routine_81(c, s0);
    const Space v601_5 = subtract(s0,v601_4);
    v600_6 = compose(v600_3,v601_5);
  }
  const Space v600_7 = (has_head(v600_6) ? constant_7 : Space{});
  const Space v600_8 = first_matching(v600_6,constant_0,false);
  const Space v600_9 = unite(v600_7,v600_8);
  Space v600_12;
  if (!v600_9.empty()) {
    const Space v602_10 = routine_66(c, v600_6);
    const Space v602_11 = routine_66(c, v602_10);
    v600_12 = compose(v600_9,v602_11);
  }
  Space v600_15;
  if (!v600_3.empty()) {
    const Space v603_13 = routine_65(c, s0);
    const Space v603_14 = routine_65(c, v603_13);
    v600_15 = compose(v600_3,v603_14);
  }
  const Space v600_16 = subtract(s0,v600_15);
  const Space v600_17 = intersect(v600_12,v600_16);
  return v600_17;
}

static Space routine_55(Context& c, const Path& p0, const Space& s0) {
  Space v604_11_result;
  for (int v604_11_label = 1; v604_11_label <= 2; ++v604_11_label) {
    const Space v604_11_tail = child(s0,v604_11_label);
    if (v604_11_tail.empty()) continue;
    const Path v604_11_head{v604_11_label};
    const Space v605_2 = singleton(v604_11_head);
    const Space v605_3 = intersect(constant_6,v605_2);
    const Space v605_4 = (has_head(v605_3) ? constant_7 : Space{});
    const Space v605_5 = subtract(constant_0,v605_4);
    Space v605_8;
    if (!v605_5.empty()) {
      const Path v606_6 = concat_path(p0,v604_11_head);
      Space v606_7_result;
      for (int v606_7_label = 1; v606_7_label <= 2; ++v606_7_label) {
        const Space v606_7_tail = child(v604_11_tail,v606_7_label);
        if (v606_7_tail.empty()) continue;
        const Path v606_7_head{v606_7_label};
        const Space v607_2 = singleton(v606_7_head);
        const Space v607_3 = intersect(constant_6,v607_2);
        const Space v607_4 = (has_head(v607_3) ? constant_7 : Space{});
        const Space v607_5 = subtract(constant_0,v607_4);
        Space v607_8;
        if (!v607_5.empty()) {
          const Path v608_6 = concat_path(v606_6,v606_7_head);
          const Space v608_7 = routine_112(c, v608_6, v606_7_tail);
          v607_8 = compose(v607_5,v608_7);
        }
        const Space v607_9 = intersect(constant_6,v607_2);
        const Space v607_10 = (has_head(v607_9) ? constant_7 : Space{});
        Space v607_12;
        if (!v607_10.empty()) {
          const Path v609_6 = concat_path(v606_6,v606_7_head);
          const Space v609_11 = routine_113(c, v609_6, v606_7_tail);
          v607_12 = compose(v607_10,v609_11);
        }
        const Space v607_13 = unite(v607_8,v607_12);
        v606_7_result = unite(v606_7_result,v607_13);
      }
      const Space v606_7 = std::move(v606_7_result);
      v605_8 = compose(v605_5,v606_7);
    }
    const Space v605_9 = intersect(constant_6,v605_2);
    const Space v605_10 = (has_head(v605_9) ? constant_7 : Space{});
    Space v605_12;
    if (!v605_10.empty()) {
      const Path v610_6 = concat_path(p0,v604_11_head);
      Space v610_11_result;
      for (int v610_11_label = 1; v610_11_label <= 2; ++v610_11_label) {
        const Space v610_11_tail = child(v604_11_tail,v610_11_label);
        if (v610_11_tail.empty()) continue;
        const Path v610_11_head{v610_11_label};
        const Space v611_2 = singleton(v610_11_head);
        const Space v611_3 = intersect(constant_6,v611_2);
        const Space v611_4 = (has_head(v611_3) ? constant_7 : Space{});
        const Space v611_5 = subtract(constant_0,v611_4);
        Space v611_8;
        if (!v611_5.empty()) {
          const Path v612_6 = concat_path(v610_6,v610_11_head);
          const Space v612_7 = routine_112(c, v612_6, v610_11_tail);
          v611_8 = compose(v611_5,v612_7);
        }
        const Space v611_9 = intersect(constant_6,v611_2);
        const Space v611_10 = (has_head(v611_9) ? constant_7 : Space{});
        Space v611_12;
        if (!v611_10.empty()) {
          const Path v613_6 = concat_path(v610_6,v610_11_head);
          const Space v613_11 = routine_104(c, v613_6, v610_11_tail);
          v611_12 = compose(v611_10,v613_11);
        }
        const Space v611_13 = unite(v611_8,v611_12);
        v610_11_result = unite(v610_11_result,v611_13);
      }
      const Space v610_11 = std::move(v610_11_result);
      v605_12 = compose(v605_10,v610_11);
    }
    const Space v605_13 = unite(v605_8,v605_12);
    v604_11_result = unite(v604_11_result,v605_13);
  }
  const Space v604_11 = std::move(v604_11_result);
  return v604_11;
}

static Space routine_56(Context& c, const Path& p0, const Space& s0) {
  Space v614_9_result;
  for (int v614_9_label = 1; v614_9_label <= 2; ++v614_9_label) {
    const Space v614_9_tail = child(s0,v614_9_label);
    if (v614_9_tail.empty()) continue;
    const Path v614_9_head{v614_9_label};
    const Space v615_2 = singleton(v614_9_head);
    const Space v615_3 = intersect(constant_6,v615_2);
    const Space v615_4 = (has_head(v615_3) ? constant_7 : Space{});
    const Space v615_5 = subtract(constant_0,v615_4);
    Space v615_8;
    if (!v615_5.empty()) {
      const Path v616_6 = concat_path(p0,v614_9_head);
      Space v616_7_result;
      for (int v616_7_label = 1; v616_7_label <= 2; ++v616_7_label) {
        const Space v616_7_tail = child(v614_9_tail,v616_7_label);
        if (v616_7_tail.empty()) continue;
        const Path v616_7_head{v616_7_label};
        const Space v617_2 = singleton(v616_7_head);
        const Space v617_3 = intersect(constant_6,v617_2);
        const Space v617_4 = (has_head(v617_3) ? constant_7 : Space{});
        const Space v617_5 = subtract(constant_0,v617_4);
        Space v617_8;
        if (!v617_5.empty()) {
          const Path v618_6 = concat_path(v616_6,v616_7_head);
          const Space v618_7 = routine_112(c, v618_6, v616_7_tail);
          v617_8 = compose(v617_5,v618_7);
        }
        const Space v617_9 = intersect(constant_6,v617_2);
        const Space v617_10 = (has_head(v617_9) ? constant_7 : Space{});
        Space v617_12;
        if (!v617_10.empty()) {
          const Path v619_6 = concat_path(v616_6,v616_7_head);
          const Space v619_11 = routine_113(c, v619_6, v616_7_tail);
          v617_12 = compose(v617_10,v619_11);
        }
        const Space v617_13 = unite(v617_8,v617_12);
        v616_7_result = unite(v616_7_result,v617_13);
      }
      const Space v616_7 = std::move(v616_7_result);
      v615_8 = compose(v615_5,v616_7);
    }
    const Space v615_9 = intersect(constant_6,v615_2);
    const Space v615_10 = (has_head(v615_9) ? constant_7 : Space{});
    const Space v615_11 = compose(v615_10,constant_9);
    const Space v615_12 = unite(v615_8,v615_11);
    v614_9_result = unite(v614_9_result,v615_12);
  }
  const Space v614_9 = std::move(v614_9_result);
  return v614_9;
}

static Space routine_57(Context& c, const Path& p0, const Space& s0) {
  Space v620_11_result;
  for (int v620_11_label = 1; v620_11_label <= 2; ++v620_11_label) {
    const Space v620_11_tail = child(s0,v620_11_label);
    if (v620_11_tail.empty()) continue;
    const Path v620_11_head{v620_11_label};
    const Space v621_2 = singleton(v620_11_head);
    const Space v621_3 = intersect(constant_6,v621_2);
    const Space v621_4 = (has_head(v621_3) ? constant_7 : Space{});
    const Space v621_5 = subtract(constant_0,v621_4);
    Space v621_8;
    if (!v621_5.empty()) {
      const Path v622_6 = concat_path(p0,v620_11_head);
      Space v622_7_result;
      for (int v622_7_label = 1; v622_7_label <= 2; ++v622_7_label) {
        const Space v622_7_tail = child(v620_11_tail,v622_7_label);
        if (v622_7_tail.empty()) continue;
        const Path v622_7_head{v622_7_label};
        const Space v623_2 = singleton(v622_7_head);
        const Space v623_3 = intersect(constant_6,v623_2);
        const Space v623_4 = (has_head(v623_3) ? constant_7 : Space{});
        const Space v623_5 = subtract(constant_0,v623_4);
        Space v623_8;
        if (!v623_5.empty()) {
          const Path v624_6 = concat_path(v622_6,v622_7_head);
          const Space v624_7 = routine_114(c, v624_6, v622_7_tail);
          v623_8 = compose(v623_5,v624_7);
        }
        const Space v623_9 = intersect(constant_6,v623_2);
        const Space v623_10 = (has_head(v623_9) ? constant_7 : Space{});
        Space v623_12;
        if (!v623_10.empty()) {
          const Path v625_6 = concat_path(v622_6,v622_7_head);
          const Space v625_11 = routine_115(c, v625_6, v622_7_tail);
          v623_12 = compose(v623_10,v625_11);
        }
        const Space v623_13 = unite(v623_8,v623_12);
        v622_7_result = unite(v622_7_result,v623_13);
      }
      const Space v622_7 = std::move(v622_7_result);
      v621_8 = compose(v621_5,v622_7);
    }
    const Space v621_9 = intersect(constant_6,v621_2);
    const Space v621_10 = (has_head(v621_9) ? constant_7 : Space{});
    Space v621_12;
    if (!v621_10.empty()) {
      const Path v626_6 = concat_path(p0,v620_11_head);
      Space v626_11_result;
      for (int v626_11_label = 1; v626_11_label <= 2; ++v626_11_label) {
        const Space v626_11_tail = child(v620_11_tail,v626_11_label);
        if (v626_11_tail.empty()) continue;
        const Path v626_11_head{v626_11_label};
        const Space v627_2 = singleton(v626_11_head);
        const Space v627_3 = intersect(constant_6,v627_2);
        const Space v627_4 = (has_head(v627_3) ? constant_7 : Space{});
        const Space v627_5 = subtract(constant_0,v627_4);
        Space v627_8;
        if (!v627_5.empty()) {
          const Path v628_6 = concat_path(v626_6,v626_11_head);
          const Space v628_7 = routine_114(c, v628_6, v626_11_tail);
          v627_8 = compose(v627_5,v628_7);
        }
        const Space v627_9 = intersect(constant_6,v627_2);
        const Space v627_10 = (has_head(v627_9) ? constant_7 : Space{});
        Space v627_12;
        if (!v627_10.empty()) {
          const Path v629_6 = concat_path(v626_6,v626_11_head);
          const Space v629_11 = routine_107(c, v629_6, v626_11_tail);
          v627_12 = compose(v627_10,v629_11);
        }
        const Space v627_13 = unite(v627_8,v627_12);
        v626_11_result = unite(v626_11_result,v627_13);
      }
      const Space v626_11 = std::move(v626_11_result);
      v621_12 = compose(v621_10,v626_11);
    }
    const Space v621_13 = unite(v621_8,v621_12);
    v620_11_result = unite(v620_11_result,v621_13);
  }
  const Space v620_11 = std::move(v620_11_result);
  return v620_11;
}

static Space routine_58(Context& c, const Path& p0, const Space& s0) {
  Space v630_8_result;
  for (int v630_8_label = 1; v630_8_label <= 2; ++v630_8_label) {
    const Space v630_8_tail = child(s0,v630_8_label);
    if (v630_8_tail.empty()) continue;
    const Path v630_8_head{v630_8_label};
    const Space v631_2 = singleton(v630_8_head);
    const Space v631_3 = intersect(constant_6,v631_2);
    const Space v631_4 = (has_head(v631_3) ? constant_7 : Space{});
    const Space v631_5 = subtract(constant_0,v631_4);
    Space v631_8;
    if (!v631_5.empty()) {
      const Path v632_6 = concat_path(p0,v630_8_head);
      Space v632_7_result;
      for (int v632_7_label = 1; v632_7_label <= 2; ++v632_7_label) {
        const Space v632_7_tail = child(v630_8_tail,v632_7_label);
        if (v632_7_tail.empty()) continue;
        const Path v632_7_head{v632_7_label};
        const Space v633_2 = singleton(v632_7_head);
        const Space v633_3 = intersect(constant_6,v633_2);
        const Space v633_4 = (has_head(v633_3) ? constant_7 : Space{});
        const Space v633_5 = subtract(constant_0,v633_4);
        Space v633_8;
        if (!v633_5.empty()) {
          const Path v634_6 = concat_path(v632_6,v632_7_head);
          const Space v634_7 = routine_114(c, v634_6, v632_7_tail);
          v633_8 = compose(v633_5,v634_7);
        }
        const Space v633_9 = intersect(constant_6,v633_2);
        const Space v633_10 = (has_head(v633_9) ? constant_7 : Space{});
        Space v633_12;
        if (!v633_10.empty()) {
          const Path v635_6 = concat_path(v632_6,v632_7_head);
          const Space v635_11 = routine_115(c, v635_6, v632_7_tail);
          v633_12 = compose(v633_10,v635_11);
        }
        const Space v633_13 = unite(v633_8,v633_12);
        v632_7_result = unite(v632_7_result,v633_13);
      }
      const Space v632_7 = std::move(v632_7_result);
      v631_8 = compose(v631_5,v632_7);
    }
    const Space v631_9 = intersect(constant_6,v631_2);
    const Space v631_10 = (has_head(v631_9) ? constant_7 : Space{});
    const Space v631_11 = compose(v631_10,v630_8_tail);
    const Space v631_12 = unite(v631_8,v631_11);
    v630_8_result = unite(v630_8_result,v631_12);
  }
  const Space v630_8 = std::move(v630_8_result);
  return v630_8;
}

static Space routine_59(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v636_12_result;
  for (int v636_12_label = 1; v636_12_label <= 2; ++v636_12_label) {
    const Space v636_12_tail = child(s0,v636_12_label);
    if (v636_12_tail.empty()) continue;
    const Path v636_12_head{v636_12_label};
    const Space v637_2 = singleton(v636_12_head);
    const Space v637_3 = intersect(constant_6,v637_2);
    const Space v637_4 = (has_head(v637_3) ? constant_7 : Space{});
    const Space v637_5 = subtract(constant_0,v637_4);
    Space v637_8;
    if (!v637_5.empty()) {
      const Path v638_6 = concat_path(p0,v636_12_head);
      Space v638_7_result;
      for (int v638_7_label = 1; v638_7_label <= 2; ++v638_7_label) {
        const Space v638_7_tail = child(v636_12_tail,v638_7_label);
        if (v638_7_tail.empty()) continue;
        const Path v638_7_head{v638_7_label};
        const Space v639_2 = singleton(v638_7_head);
        const Space v639_3 = intersect(constant_6,v639_2);
        const Space v639_4 = (has_head(v639_3) ? constant_7 : Space{});
        const Space v639_5 = subtract(constant_0,v639_4);
        Space v639_8;
        if (!v639_5.empty()) {
          const Path v640_6 = concat_path(v638_6,v638_7_head);
          const Space v640_7 = routine_116(c, v640_6, v638_7_tail, s1);
          v639_8 = compose(v639_5,v640_7);
        }
        const Space v639_9 = intersect(constant_6,v639_2);
        const Space v639_10 = (has_head(v639_9) ? constant_7 : Space{});
        Space v639_12;
        if (!v639_10.empty()) {
          const Path v641_6 = concat_path(v638_6,v638_7_head);
          const Space v641_11 = routine_117(c, v641_6, v638_7_tail, s1);
          v639_12 = compose(v639_10,v641_11);
        }
        const Space v639_13 = unite(v639_8,v639_12);
        v638_7_result = unite(v638_7_result,v639_13);
      }
      const Space v638_7 = std::move(v638_7_result);
      v637_8 = compose(v637_5,v638_7);
    }
    const Space v637_9 = intersect(constant_6,v637_2);
    const Space v637_10 = (has_head(v637_9) ? constant_7 : Space{});
    Space v637_12;
    if (!v637_10.empty()) {
      const Path v642_6 = concat_path(p0,v636_12_head);
      Space v642_11_result;
      for (int v642_11_label = 1; v642_11_label <= 2; ++v642_11_label) {
        const Space v642_11_tail = child(v636_12_tail,v642_11_label);
        if (v642_11_tail.empty()) continue;
        const Path v642_11_head{v642_11_label};
        const Space v643_2 = singleton(v642_11_head);
        const Space v643_3 = intersect(constant_6,v643_2);
        const Space v643_4 = (has_head(v643_3) ? constant_7 : Space{});
        const Space v643_5 = subtract(constant_0,v643_4);
        Space v643_8;
        if (!v643_5.empty()) {
          const Path v644_6 = concat_path(v642_6,v642_11_head);
          const Space v644_7 = routine_116(c, v644_6, v642_11_tail, s1);
          v643_8 = compose(v643_5,v644_7);
        }
        const Space v643_9 = intersect(constant_6,v643_2);
        const Space v643_10 = (has_head(v643_9) ? constant_7 : Space{});
        Space v643_12;
        if (!v643_10.empty()) {
          const Path v645_6 = concat_path(v642_6,v642_11_head);
          const Space v645_11 = routine_9(c, v645_6, v642_11_tail, s1);
          v643_12 = compose(v643_10,v645_11);
        }
        const Space v643_13 = unite(v643_8,v643_12);
        v642_11_result = unite(v642_11_result,v643_13);
      }
      const Space v642_11 = std::move(v642_11_result);
      v637_12 = compose(v637_10,v642_11);
    }
    const Space v637_13 = unite(v637_8,v637_12);
    v636_12_result = unite(v636_12_result,v637_13);
  }
  const Space v636_12 = std::move(v636_12_result);
  return v636_12;
}

static Space routine_60(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v646_12_result;
  for (int v646_12_label = 1; v646_12_label <= 2; ++v646_12_label) {
    const Space v646_12_tail = child(s0,v646_12_label);
    if (v646_12_tail.empty()) continue;
    const Path v646_12_head{v646_12_label};
    const Space v647_2 = singleton(v646_12_head);
    const Space v647_3 = intersect(constant_6,v647_2);
    const Space v647_4 = (has_head(v647_3) ? constant_7 : Space{});
    const Space v647_5 = subtract(constant_0,v647_4);
    Space v647_8;
    if (!v647_5.empty()) {
      const Path v648_6 = concat_path(p0,v646_12_head);
      Space v648_7_result;
      for (int v648_7_label = 1; v648_7_label <= 2; ++v648_7_label) {
        const Space v648_7_tail = child(v646_12_tail,v648_7_label);
        if (v648_7_tail.empty()) continue;
        const Path v648_7_head{v648_7_label};
        const Space v649_2 = singleton(v648_7_head);
        const Space v649_3 = intersect(constant_6,v649_2);
        const Space v649_4 = (has_head(v649_3) ? constant_7 : Space{});
        const Space v649_5 = subtract(constant_0,v649_4);
        Space v649_8;
        if (!v649_5.empty()) {
          const Path v650_6 = concat_path(v648_6,v648_7_head);
          const Space v650_7 = routine_116(c, v650_6, v648_7_tail, s1);
          v649_8 = compose(v649_5,v650_7);
        }
        const Space v649_9 = intersect(constant_6,v649_2);
        const Space v649_10 = (has_head(v649_9) ? constant_7 : Space{});
        Space v649_12;
        if (!v649_10.empty()) {
          const Path v651_6 = concat_path(v648_6,v648_7_head);
          const Space v651_11 = routine_117(c, v651_6, v648_7_tail, s1);
          v649_12 = compose(v649_10,v651_11);
        }
        const Space v649_13 = unite(v649_8,v649_12);
        v648_7_result = unite(v648_7_result,v649_13);
      }
      const Space v648_7 = std::move(v648_7_result);
      v647_8 = compose(v647_5,v648_7);
    }
    const Space v647_9 = intersect(constant_6,v647_2);
    const Space v647_10 = (has_head(v647_9) ? constant_7 : Space{});
    Space v647_12;
    if (!v647_10.empty()) {
      const Path v652_6 = concat_path(p0,v646_12_head);
      Space v652_11_result;
      for (int v652_11_label = 1; v652_11_label <= 2; ++v652_11_label) {
        const Space v652_11_tail = child(v646_12_tail,v652_11_label);
        if (v652_11_tail.empty()) continue;
        const Path v652_11_head{v652_11_label};
        const Space v653_2 = singleton(v652_11_head);
        const Space v653_3 = intersect(constant_6,v653_2);
        const Space v653_4 = (has_head(v653_3) ? constant_7 : Space{});
        const Space v653_5 = subtract(constant_0,v653_4);
        Space v653_7;
        if (!v653_5.empty()) {
          const Space v654_6 = routine_10(c, v652_11_head, v652_6, v652_11_tail, s1);
          v653_7 = compose(v653_5,v654_6);
        }
        const Space v653_8 = intersect(constant_6,v653_2);
        const Space v653_9 = (has_head(v653_8) ? constant_7 : Space{});
        Space v653_11;
        if (!v653_9.empty()) {
          const Space v655_10 = routine_11(c, v652_11_head, v652_6, v652_11_tail, s1);
          v653_11 = compose(v653_9,v655_10);
        }
        const Space v653_12 = unite(v653_7,v653_11);
        v652_11_result = unite(v652_11_result,v653_12);
      }
      const Space v652_11 = std::move(v652_11_result);
      v647_12 = compose(v647_10,v652_11);
    }
    const Space v647_13 = unite(v647_8,v647_12);
    v646_12_result = unite(v646_12_result,v647_13);
  }
  const Space v646_12 = std::move(v646_12_result);
  return v646_12;
}

static Space routine_61(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v656_13_result;
  for (int v656_13_label = 1; v656_13_label <= 2; ++v656_13_label) {
    const Space v656_13_tail = child(s0,v656_13_label);
    if (v656_13_tail.empty()) continue;
    const Path v656_13_head{v656_13_label};
    const Space v657_2 = singleton(v656_13_head);
    const Space v657_3 = intersect(constant_6,v657_2);
    const Space v657_4 = (has_head(v657_3) ? constant_7 : Space{});
    const Space v657_5 = subtract(constant_0,v657_4);
    Space v657_8;
    if (!v657_5.empty()) {
      const Path v658_6 = concat_path(p0,v656_13_head);
      Space v658_7_result;
      for (int v658_7_label = 1; v658_7_label <= 2; ++v658_7_label) {
        const Space v658_7_tail = child(v656_13_tail,v658_7_label);
        if (v658_7_tail.empty()) continue;
        const Path v658_7_head{v658_7_label};
        const Space v659_2 = singleton(v658_7_head);
        const Space v659_3 = intersect(constant_6,v659_2);
        const Space v659_4 = (has_head(v659_3) ? constant_7 : Space{});
        const Space v659_5 = subtract(constant_0,v659_4);
        Space v659_8;
        if (!v659_5.empty()) {
          const Path v660_6 = concat_path(v658_6,v658_7_head);
          const Space v660_7 = routine_118(c, v660_6, p1, v658_7_tail, s1);
          v659_8 = compose(v659_5,v660_7);
        }
        const Space v659_9 = intersect(constant_6,v659_2);
        const Space v659_10 = (has_head(v659_9) ? constant_7 : Space{});
        Space v659_12;
        if (!v659_10.empty()) {
          const Path v661_6 = concat_path(v658_6,v658_7_head);
          const Space v661_11 = routine_119(c, v661_6, p1, v658_7_tail, s1);
          v659_12 = compose(v659_10,v661_11);
        }
        const Space v659_13 = unite(v659_8,v659_12);
        v658_7_result = unite(v658_7_result,v659_13);
      }
      const Space v658_7 = std::move(v658_7_result);
      v657_8 = compose(v657_5,v658_7);
    }
    const Space v657_9 = intersect(constant_6,v657_2);
    const Space v657_10 = (has_head(v657_9) ? constant_7 : Space{});
    Space v657_12;
    if (!v657_10.empty()) {
      const Path v662_6 = concat_path(p0,v656_13_head);
      Space v662_11_result;
      for (int v662_11_label = 1; v662_11_label <= 2; ++v662_11_label) {
        const Space v662_11_tail = child(v656_13_tail,v662_11_label);
        if (v662_11_tail.empty()) continue;
        const Path v662_11_head{v662_11_label};
        const Space v663_2 = singleton(v662_11_head);
        const Space v663_3 = intersect(constant_6,v663_2);
        const Space v663_4 = (has_head(v663_3) ? constant_7 : Space{});
        const Space v663_5 = subtract(constant_0,v663_4);
        Space v663_8;
        if (!v663_5.empty()) {
          const Path v664_6 = concat_path(v662_6,v662_11_head);
          const Space v664_7 = routine_118(c, v664_6, p1, v662_11_tail, s1);
          v663_8 = compose(v663_5,v664_7);
        }
        const Space v663_9 = intersect(constant_6,v663_2);
        const Space v663_10 = (has_head(v663_9) ? constant_7 : Space{});
        Space v663_12;
        if (!v663_10.empty()) {
          const Path v665_6 = concat_path(v662_6,v662_11_head);
          const Space v665_11 = routine_26(c, v665_6, p1, v662_11_tail, s1);
          v663_12 = compose(v663_10,v665_11);
        }
        const Space v663_13 = unite(v663_8,v663_12);
        v662_11_result = unite(v662_11_result,v663_13);
      }
      const Space v662_11 = std::move(v662_11_result);
      v657_12 = compose(v657_10,v662_11);
    }
    const Space v657_13 = unite(v657_8,v657_12);
    v656_13_result = unite(v656_13_result,v657_13);
  }
  const Space v656_13 = std::move(v656_13_result);
  return v656_13;
}

static Space routine_62(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v666_8 = unwrap(s1,constant_8);
  Space v666_21_result;
  for (int v666_21_label = 1; v666_21_label <= 2; ++v666_21_label) {
    const Space v666_21_tail = child(s0,v666_21_label);
    if (v666_21_tail.empty()) continue;
    const Path v666_21_head{v666_21_label};
    const Space v667_2 = singleton(v666_21_head);
    const Space v667_3 = intersect(constant_6,v667_2);
    const Space v667_4 = (has_head(v667_3) ? constant_7 : Space{});
    const Space v667_5 = subtract(constant_0,v667_4);
    Space v667_8;
    if (!v667_5.empty()) {
      const Path v668_6 = concat_path(p0,v666_21_head);
      Space v668_7_result;
      for (int v668_7_label = 1; v668_7_label <= 2; ++v668_7_label) {
        const Space v668_7_tail = child(v666_21_tail,v668_7_label);
        if (v668_7_tail.empty()) continue;
        const Path v668_7_head{v668_7_label};
        const Space v669_2 = singleton(v668_7_head);
        const Space v669_3 = intersect(constant_6,v669_2);
        const Space v669_4 = (has_head(v669_3) ? constant_7 : Space{});
        const Space v669_5 = subtract(constant_0,v669_4);
        Space v669_8;
        if (!v669_5.empty()) {
          const Path v670_6 = concat_path(v668_6,v668_7_head);
          const Space v670_7 = routine_118(c, v670_6, p1, v668_7_tail, s1);
          v669_8 = compose(v669_5,v670_7);
        }
        const Space v669_9 = intersect(constant_6,v669_2);
        const Space v669_10 = (has_head(v669_9) ? constant_7 : Space{});
        Space v669_12;
        if (!v669_10.empty()) {
          const Path v671_6 = concat_path(v668_6,v668_7_head);
          const Space v671_11 = routine_119(c, v671_6, p1, v668_7_tail, s1);
          v669_12 = compose(v669_10,v671_11);
        }
        const Space v669_13 = unite(v669_8,v669_12);
        v668_7_result = unite(v668_7_result,v669_13);
      }
      const Space v668_7 = std::move(v668_7_result);
      v667_8 = compose(v667_5,v668_7);
    }
    const Space v667_9 = intersect(constant_6,v667_2);
    const Space v667_10 = (has_head(v667_9) ? constant_7 : Space{});
    Space v667_22;
    if (!v667_10.empty()) {
      const Path v672_6 = concat_path(p0,v666_21_head);
      const Path v672_11 = concat_path(p1,v672_6);
      const Space v672_12 = routine_29(c, v672_11);
      const Space v672_13 = intersect(v666_8,v672_12);
      const Space v672_14 = routine_30(c, v672_13);
      Space v672_15_result;
      for (int v672_15_label = 1; v672_15_label <= 2; ++v672_15_label) {
        const Space v672_15_tail = child(v672_14,v672_15_label);
        if (v672_15_tail.empty()) continue;
        const Path v672_15_head{v672_15_label};
        const Space v673_2 = singleton(v672_15_head);
        const Space v673_3 = intersect(constant_6,v673_2);
        const Space v673_4 = (has_head(v673_3) ? constant_7 : Space{});
        const Space v673_5 = subtract(constant_0,v673_4);
        Space v673_7;
        if (!v673_5.empty()) {
          const Space v674_6 = routine_31(c, v672_15_head, v672_15_tail);
          v673_7 = compose(v673_5,v674_6);
        }
        const Space v673_8 = intersect(constant_6,v673_2);
        const Space v673_9 = (has_head(v673_8) ? constant_7 : Space{});
        Space v673_11;
        if (!v673_9.empty()) {
          const Space v675_10 = routine_32(c, v672_15_head, v672_15_tail);
          v673_11 = compose(v673_9,v675_10);
        }
        const Space v673_12 = unite(v673_7,v673_11);
        v672_15_result = unite(v672_15_result,v673_12);
      }
      const Space v672_15 = std::move(v672_15_result);
      const Space v672_16 = routine_33(c, v672_13);
      Space v672_17_result;
      for (int v672_17_label = 1; v672_17_label <= 2; ++v672_17_label) {
        const Space v672_17_tail = child(v672_16,v672_17_label);
        if (v672_17_tail.empty()) continue;
        const Path v672_17_head{v672_17_label};
        const Space v676_2 = singleton(v672_17_head);
        const Space v676_3 = intersect(constant_6,v676_2);
        const Space v676_4 = (has_head(v676_3) ? constant_7 : Space{});
        const Space v676_5 = subtract(constant_0,v676_4);
        Space v676_7;
        if (!v676_5.empty()) {
          const Space v677_6 = routine_34(c, v672_17_head, v672_17_tail);
          v676_7 = compose(v676_5,v677_6);
        }
        const Space v676_8 = intersect(constant_6,v676_2);
        const Space v676_9 = (has_head(v676_8) ? constant_7 : Space{});
        Space v676_11;
        if (!v676_9.empty()) {
          const Space v678_10 = routine_35(c, v672_17_head, v672_17_tail);
          v676_11 = compose(v676_9,v678_10);
        }
        const Space v676_12 = unite(v676_7,v676_11);
        v672_17_result = unite(v672_17_result,v676_12);
      }
      const Space v672_17 = std::move(v672_17_result);
      const Space v672_18 = subtract(v672_15,v672_17);
      const Space v672_19 = singleton(v672_11);
      const Space v672_20 = compose(v672_18,v672_19);
      Space v672_21_result;
      for (int v672_21_label = 1; v672_21_label <= 2; ++v672_21_label) {
        const Space v672_21_tail = child(v672_20,v672_21_label);
        if (v672_21_tail.empty()) continue;
        const Path v672_21_head{v672_21_label};
        const Space v679_2 = singleton(v672_21_head);
        const Space v679_3 = intersect(constant_6,v679_2);
        const Space v679_4 = (has_head(v679_3) ? constant_7 : Space{});
        const Space v679_5 = subtract(constant_0,v679_4);
        Space v679_7;
        if (!v679_5.empty()) {
          const Space v680_6 = routine_36(c, v672_21_head, v672_21_tail);
          v679_7 = compose(v679_5,v680_6);
        }
        const Space v679_8 = intersect(constant_6,v679_2);
        const Space v679_9 = (has_head(v679_8) ? constant_7 : Space{});
        Space v679_11;
        if (!v679_9.empty()) {
          const Space v681_10 = routine_37(c, v672_21_head, v672_21_tail);
          v679_11 = compose(v679_9,v681_10);
        }
        const Space v679_12 = unite(v679_7,v679_11);
        v672_21_result = unite(v672_21_result,v679_12);
      }
      const Space v672_21 = std::move(v672_21_result);
      v667_22 = compose(v667_10,v672_21);
    }
    const Space v667_23 = unite(v667_8,v667_22);
    v666_21_result = unite(v666_21_result,v667_23);
  }
  const Space v666_21 = std::move(v666_21_result);
  return v666_21;
}

static Space routine_63(Context& c, const Path& p0, const Space& s0) {
  Space v682_11_result;
  for (int v682_11_label = 1; v682_11_label <= 2; ++v682_11_label) {
    const Space v682_11_tail = child(s0,v682_11_label);
    if (v682_11_tail.empty()) continue;
    const Path v682_11_head{v682_11_label};
    const Space v683_2 = singleton(v682_11_head);
    const Space v683_3 = intersect(constant_6,v683_2);
    const Space v683_4 = (has_head(v683_3) ? constant_7 : Space{});
    const Space v683_5 = subtract(constant_0,v683_4);
    Space v683_8;
    if (!v683_5.empty()) {
      const Path v684_6 = concat_path(p0,v682_11_head);
      Space v684_7_result;
      for (int v684_7_label = 1; v684_7_label <= 2; ++v684_7_label) {
        const Space v684_7_tail = child(v682_11_tail,v684_7_label);
        if (v684_7_tail.empty()) continue;
        const Path v684_7_head{v684_7_label};
        const Space v685_2 = singleton(v684_7_head);
        const Space v685_3 = intersect(constant_6,v685_2);
        const Space v685_4 = (has_head(v685_3) ? constant_7 : Space{});
        const Space v685_5 = subtract(constant_0,v685_4);
        Space v685_8;
        if (!v685_5.empty()) {
          const Path v686_6 = concat_path(v684_6,v684_7_head);
          const Space v686_7 = routine_120(c, v686_6, v684_7_tail);
          v685_8 = compose(v685_5,v686_7);
        }
        const Space v685_9 = intersect(constant_6,v685_2);
        const Space v685_10 = (has_head(v685_9) ? constant_7 : Space{});
        Space v685_12;
        if (!v685_10.empty()) {
          const Path v687_6 = concat_path(v684_6,v684_7_head);
          const Space v687_11 = routine_121(c, v687_6, v684_7_tail);
          v685_12 = compose(v685_10,v687_11);
        }
        const Space v685_13 = unite(v685_8,v685_12);
        v684_7_result = unite(v684_7_result,v685_13);
      }
      const Space v684_7 = std::move(v684_7_result);
      v683_8 = compose(v683_5,v684_7);
    }
    const Space v683_9 = intersect(constant_6,v683_2);
    const Space v683_10 = (has_head(v683_9) ? constant_7 : Space{});
    Space v683_12;
    if (!v683_10.empty()) {
      const Path v688_6 = concat_path(p0,v682_11_head);
      Space v688_11_result;
      for (int v688_11_label = 1; v688_11_label <= 2; ++v688_11_label) {
        const Space v688_11_tail = child(v682_11_tail,v688_11_label);
        if (v688_11_tail.empty()) continue;
        const Path v688_11_head{v688_11_label};
        const Space v689_2 = singleton(v688_11_head);
        const Space v689_3 = intersect(constant_6,v689_2);
        const Space v689_4 = (has_head(v689_3) ? constant_7 : Space{});
        const Space v689_5 = subtract(constant_0,v689_4);
        Space v689_8;
        if (!v689_5.empty()) {
          const Path v690_6 = concat_path(v688_6,v688_11_head);
          const Space v690_7 = routine_120(c, v690_6, v688_11_tail);
          v689_8 = compose(v689_5,v690_7);
        }
        const Space v689_9 = intersect(constant_6,v689_2);
        const Space v689_10 = (has_head(v689_9) ? constant_7 : Space{});
        Space v689_12;
        if (!v689_10.empty()) {
          const Path v691_6 = concat_path(v688_6,v688_11_head);
          const Space v691_11 = routine_80(c, v691_6, v688_11_tail);
          v689_12 = compose(v689_10,v691_11);
        }
        const Space v689_13 = unite(v689_8,v689_12);
        v688_11_result = unite(v688_11_result,v689_13);
      }
      const Space v688_11 = std::move(v688_11_result);
      v683_12 = compose(v683_10,v688_11);
    }
    const Space v683_13 = unite(v683_8,v683_12);
    v682_11_result = unite(v682_11_result,v683_13);
  }
  const Space v682_11 = std::move(v682_11_result);
  return v682_11;
}

static Space routine_64(Context& c, const Path& p0, const Space& s0) {
  Space v692_11_result;
  for (int v692_11_label = 1; v692_11_label <= 2; ++v692_11_label) {
    const Space v692_11_tail = child(s0,v692_11_label);
    if (v692_11_tail.empty()) continue;
    const Path v692_11_head{v692_11_label};
    const Space v693_2 = singleton(v692_11_head);
    const Space v693_3 = intersect(constant_6,v693_2);
    const Space v693_4 = (has_head(v693_3) ? constant_7 : Space{});
    const Space v693_5 = subtract(constant_0,v693_4);
    Space v693_8;
    if (!v693_5.empty()) {
      const Path v694_6 = concat_path(p0,v692_11_head);
      Space v694_7_result;
      for (int v694_7_label = 1; v694_7_label <= 2; ++v694_7_label) {
        const Space v694_7_tail = child(v692_11_tail,v694_7_label);
        if (v694_7_tail.empty()) continue;
        const Path v694_7_head{v694_7_label};
        const Space v695_2 = singleton(v694_7_head);
        const Space v695_3 = intersect(constant_6,v695_2);
        const Space v695_4 = (has_head(v695_3) ? constant_7 : Space{});
        const Space v695_5 = subtract(constant_0,v695_4);
        Space v695_8;
        if (!v695_5.empty()) {
          const Path v696_6 = concat_path(v694_6,v694_7_head);
          const Space v696_7 = routine_120(c, v696_6, v694_7_tail);
          v695_8 = compose(v695_5,v696_7);
        }
        const Space v695_9 = intersect(constant_6,v695_2);
        const Space v695_10 = (has_head(v695_9) ? constant_7 : Space{});
        Space v695_12;
        if (!v695_10.empty()) {
          const Path v697_6 = concat_path(v694_6,v694_7_head);
          const Space v697_11 = routine_121(c, v697_6, v694_7_tail);
          v695_12 = compose(v695_10,v697_11);
        }
        const Space v695_13 = unite(v695_8,v695_12);
        v694_7_result = unite(v694_7_result,v695_13);
      }
      const Space v694_7 = std::move(v694_7_result);
      v693_8 = compose(v693_5,v694_7);
    }
    const Space v693_9 = intersect(constant_6,v693_2);
    const Space v693_10 = (has_head(v693_9) ? constant_7 : Space{});
    Space v693_12;
    if (!v693_10.empty()) {
      const Path v698_6 = concat_path(p0,v692_11_head);
      Space v698_11_result;
      for (int v698_11_label = 1; v698_11_label <= 2; ++v698_11_label) {
        const Space v698_11_tail = child(v692_11_tail,v698_11_label);
        if (v698_11_tail.empty()) continue;
        const Path v698_11_head{v698_11_label};
        const Space v699_2 = singleton(v698_11_head);
        const Space v699_3 = intersect(constant_6,v699_2);
        const Space v699_4 = (has_head(v699_3) ? constant_7 : Space{});
        const Space v699_5 = subtract(constant_0,v699_4);
        Space v699_7;
        if (!v699_5.empty()) {
          const Space v700_6 = routine_122(c, v698_11_head, v698_6, v698_11_tail);
          v699_7 = compose(v699_5,v700_6);
        }
        const Space v699_8 = intersect(constant_6,v699_2);
        const Space v699_9 = (has_head(v699_8) ? constant_7 : Space{});
        Space v699_11;
        if (!v699_9.empty()) {
          const Space v701_10 = routine_123(c, v698_11_head, v698_6, v698_11_tail);
          v699_11 = compose(v699_9,v701_10);
        }
        const Space v699_12 = unite(v699_7,v699_11);
        v698_11_result = unite(v698_11_result,v699_12);
      }
      const Space v698_11 = std::move(v698_11_result);
      v693_12 = compose(v693_10,v698_11);
    }
    const Space v693_13 = unite(v693_8,v693_12);
    v692_11_result = unite(v692_11_result,v693_13);
  }
  const Space v692_11 = std::move(v692_11_result);
  return v692_11;
}

static Space routine_65(Context& c, const Space& s0) {
  const Space v702_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v702_2 = first_matching(s0,constant_0,false);
  const Space v702_3 = unite(v702_1,v702_2);
  Space v702_13;
  if (!v702_3.empty()) {
    Space v703_6;
    if (!v702_3.empty()) {
      const Space v704_4 = routine_81(c, s0);
      const Space v704_5 = subtract(s0,v704_4);
      v703_6 = compose(v702_3,v704_5);
    }
    const Space v703_7 = (has_head(v703_6) ? constant_7 : Space{});
    const Space v703_8 = first_matching(v703_6,constant_0,false);
    const Space v703_9 = unite(v703_7,v703_8);
    Space v703_12;
    if (!v703_9.empty()) {
      const Space v705_10 = routine_81(c, v703_6);
      const Space v705_11 = subtract(v703_6,v705_10);
      v703_12 = compose(v703_9,v705_11);
    }
    v702_13 = compose(v702_3,v703_12);
  }
  return v702_13;
}

static Space routine_66(Context& c, const Space& s0) {
  const Space v706_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v706_2 = first_matching(s0,constant_0,false);
  const Space v706_3 = unite(v706_1,v706_2);
  Space v706_19;
  if (!v706_3.empty()) {
    const Space v707_5 = intersect(constant_0,v706_2);
    const Space v707_6 = (has_head(v706_2) ? constant_7 : Space{});
    const Space v707_7 = unite(v707_5,v707_6);
    const Space v707_9 = compose(v707_7,constant_0);
    const Space v707_10 = subtract(s0,v707_9);
    const Space v707_12 = subtract(constant_0,v706_2);
    const Space v707_13 = subtract(v707_12,v707_6);
    Space v707_17;
    if (!v707_13.empty()) {
      const Space v708_15 = first_listed(s0,constant_11,true);
      const Space v708_16 = routine_124(c, constant_10, v708_15, s0);
      v707_17 = compose(v707_13,v708_16);
    }
    const Space v707_18 = subtract(v707_10,v707_17);
    v706_19 = compose(v706_3,v707_18);
  }
  return v706_19;
}

static Space routine_67(Context& c, const Path& p0, const Space& s0) {
  Space v709_11_result;
  for (int v709_11_label = 1; v709_11_label <= 2; ++v709_11_label) {
    const Space v709_11_tail = child(s0,v709_11_label);
    if (v709_11_tail.empty()) continue;
    const Path v709_11_head{v709_11_label};
    const Space v710_2 = singleton(v709_11_head);
    const Space v710_3 = intersect(constant_6,v710_2);
    const Space v710_4 = (has_head(v710_3) ? constant_7 : Space{});
    const Space v710_5 = subtract(constant_0,v710_4);
    Space v710_8;
    if (!v710_5.empty()) {
      const Path v711_6 = concat_path(p0,v709_11_head);
      Space v711_7_result;
      for (int v711_7_label = 1; v711_7_label <= 2; ++v711_7_label) {
        const Space v711_7_tail = child(v709_11_tail,v711_7_label);
        if (v711_7_tail.empty()) continue;
        const Path v711_7_head{v711_7_label};
        const Space v712_2 = singleton(v711_7_head);
        const Space v712_3 = intersect(constant_6,v712_2);
        const Space v712_4 = (has_head(v712_3) ? constant_7 : Space{});
        const Space v712_5 = subtract(constant_0,v712_4);
        Space v712_8;
        if (!v712_5.empty()) {
          const Path v713_6 = concat_path(v711_6,v711_7_head);
          const Space v713_7 = routine_125(c, v713_6, v711_7_tail);
          v712_8 = compose(v712_5,v713_7);
        }
        const Space v712_9 = intersect(constant_6,v712_2);
        const Space v712_10 = (has_head(v712_9) ? constant_7 : Space{});
        Space v712_12;
        if (!v712_10.empty()) {
          const Path v714_6 = concat_path(v711_6,v711_7_head);
          const Space v714_11 = routine_126(c, v714_6, v711_7_tail);
          v712_12 = compose(v712_10,v714_11);
        }
        const Space v712_13 = unite(v712_8,v712_12);
        v711_7_result = unite(v711_7_result,v712_13);
      }
      const Space v711_7 = std::move(v711_7_result);
      v710_8 = compose(v710_5,v711_7);
    }
    const Space v710_9 = intersect(constant_6,v710_2);
    const Space v710_10 = (has_head(v710_9) ? constant_7 : Space{});
    Space v710_12;
    if (!v710_10.empty()) {
      const Path v715_6 = concat_path(p0,v709_11_head);
      Space v715_11_result;
      for (int v715_11_label = 1; v715_11_label <= 2; ++v715_11_label) {
        const Space v715_11_tail = child(v709_11_tail,v715_11_label);
        if (v715_11_tail.empty()) continue;
        const Path v715_11_head{v715_11_label};
        const Space v716_2 = singleton(v715_11_head);
        const Space v716_3 = intersect(constant_6,v716_2);
        const Space v716_4 = (has_head(v716_3) ? constant_7 : Space{});
        const Space v716_5 = subtract(constant_0,v716_4);
        Space v716_8;
        if (!v716_5.empty()) {
          const Path v717_6 = concat_path(v715_6,v715_11_head);
          const Space v717_7 = routine_125(c, v717_6, v715_11_tail);
          v716_8 = compose(v716_5,v717_7);
        }
        const Space v716_9 = intersect(constant_6,v716_2);
        const Space v716_10 = (has_head(v716_9) ? constant_7 : Space{});
        Space v716_12;
        if (!v716_10.empty()) {
          const Path v718_6 = concat_path(v715_6,v715_11_head);
          const Space v718_11 = routine_69(c, v718_6, v715_11_tail);
          v716_12 = compose(v716_10,v718_11);
        }
        const Space v716_13 = unite(v716_8,v716_12);
        v715_11_result = unite(v715_11_result,v716_13);
      }
      const Space v715_11 = std::move(v715_11_result);
      v710_12 = compose(v710_10,v715_11);
    }
    const Space v710_13 = unite(v710_8,v710_12);
    v709_11_result = unite(v709_11_result,v710_13);
  }
  const Space v709_11 = std::move(v709_11_result);
  return v709_11;
}

static Space routine_68(Context& c, const Path& p0, const Space& s0) {
  Space v719_9_result;
  for (int v719_9_label = 1; v719_9_label <= 2; ++v719_9_label) {
    const Space v719_9_tail = child(s0,v719_9_label);
    if (v719_9_tail.empty()) continue;
    const Path v719_9_head{v719_9_label};
    const Space v720_2 = singleton(v719_9_head);
    const Space v720_3 = intersect(constant_6,v720_2);
    const Space v720_4 = (has_head(v720_3) ? constant_7 : Space{});
    const Space v720_5 = subtract(constant_0,v720_4);
    Space v720_8;
    if (!v720_5.empty()) {
      const Path v721_6 = concat_path(p0,v719_9_head);
      Space v721_7_result;
      for (int v721_7_label = 1; v721_7_label <= 2; ++v721_7_label) {
        const Space v721_7_tail = child(v719_9_tail,v721_7_label);
        if (v721_7_tail.empty()) continue;
        const Path v721_7_head{v721_7_label};
        const Space v722_2 = singleton(v721_7_head);
        const Space v722_3 = intersect(constant_6,v722_2);
        const Space v722_4 = (has_head(v722_3) ? constant_7 : Space{});
        const Space v722_5 = subtract(constant_0,v722_4);
        Space v722_8;
        if (!v722_5.empty()) {
          const Path v723_6 = concat_path(v721_6,v721_7_head);
          const Space v723_7 = routine_125(c, v723_6, v721_7_tail);
          v722_8 = compose(v722_5,v723_7);
        }
        const Space v722_9 = intersect(constant_6,v722_2);
        const Space v722_10 = (has_head(v722_9) ? constant_7 : Space{});
        Space v722_12;
        if (!v722_10.empty()) {
          const Path v724_6 = concat_path(v721_6,v721_7_head);
          const Space v724_11 = routine_126(c, v724_6, v721_7_tail);
          v722_12 = compose(v722_10,v724_11);
        }
        const Space v722_13 = unite(v722_8,v722_12);
        v721_7_result = unite(v721_7_result,v722_13);
      }
      const Space v721_7 = std::move(v721_7_result);
      v720_8 = compose(v720_5,v721_7);
    }
    const Space v720_9 = intersect(constant_6,v720_2);
    const Space v720_10 = (has_head(v720_9) ? constant_7 : Space{});
    const Space v720_11 = compose(v720_10,constant_9);
    const Space v720_12 = unite(v720_8,v720_11);
    v719_9_result = unite(v719_9_result,v720_12);
  }
  const Space v719_9 = std::move(v719_9_result);
  return v719_9;
}

static Space routine_69(Context& c, const Path& p0, const Space& s0) {
  return constant_9;
}

static Space routine_70(Context& c, const Path& p0, const Space& s0) {
  Space v726_11_result;
  for (int v726_11_label = 1; v726_11_label <= 2; ++v726_11_label) {
    const Space v726_11_tail = child(s0,v726_11_label);
    if (v726_11_tail.empty()) continue;
    const Path v726_11_head{v726_11_label};
    const Space v727_2 = singleton(v726_11_head);
    const Space v727_3 = intersect(constant_6,v727_2);
    const Space v727_4 = (has_head(v727_3) ? constant_7 : Space{});
    const Space v727_5 = subtract(constant_0,v727_4);
    Space v727_8;
    if (!v727_5.empty()) {
      const Path v728_6 = concat_path(p0,v726_11_head);
      Space v728_7_result;
      for (int v728_7_label = 1; v728_7_label <= 2; ++v728_7_label) {
        const Space v728_7_tail = child(v726_11_tail,v728_7_label);
        if (v728_7_tail.empty()) continue;
        const Path v728_7_head{v728_7_label};
        const Space v729_2 = singleton(v728_7_head);
        const Space v729_3 = intersect(constant_6,v729_2);
        const Space v729_4 = (has_head(v729_3) ? constant_7 : Space{});
        const Space v729_5 = subtract(constant_0,v729_4);
        Space v729_8;
        if (!v729_5.empty()) {
          const Path v730_6 = concat_path(v728_6,v728_7_head);
          const Space v730_7 = routine_127(c, v730_6, v728_7_tail);
          v729_8 = compose(v729_5,v730_7);
        }
        const Space v729_9 = intersect(constant_6,v729_2);
        const Space v729_10 = (has_head(v729_9) ? constant_7 : Space{});
        Space v729_12;
        if (!v729_10.empty()) {
          const Path v731_6 = concat_path(v728_6,v728_7_head);
          const Space v731_11 = routine_128(c, v731_6, v728_7_tail);
          v729_12 = compose(v729_10,v731_11);
        }
        const Space v729_13 = unite(v729_8,v729_12);
        v728_7_result = unite(v728_7_result,v729_13);
      }
      const Space v728_7 = std::move(v728_7_result);
      v727_8 = compose(v727_5,v728_7);
    }
    const Space v727_9 = intersect(constant_6,v727_2);
    const Space v727_10 = (has_head(v727_9) ? constant_7 : Space{});
    Space v727_12;
    if (!v727_10.empty()) {
      const Path v732_6 = concat_path(p0,v726_11_head);
      Space v732_11_result;
      for (int v732_11_label = 1; v732_11_label <= 2; ++v732_11_label) {
        const Space v732_11_tail = child(v726_11_tail,v732_11_label);
        if (v732_11_tail.empty()) continue;
        const Path v732_11_head{v732_11_label};
        const Space v733_2 = singleton(v732_11_head);
        const Space v733_3 = intersect(constant_6,v733_2);
        const Space v733_4 = (has_head(v733_3) ? constant_7 : Space{});
        const Space v733_5 = subtract(constant_0,v733_4);
        Space v733_8;
        if (!v733_5.empty()) {
          const Path v734_6 = concat_path(v732_6,v732_11_head);
          const Space v734_7 = routine_127(c, v734_6, v732_11_tail);
          v733_8 = compose(v733_5,v734_7);
        }
        const Space v733_9 = intersect(constant_6,v733_2);
        const Space v733_10 = (has_head(v733_9) ? constant_7 : Space{});
        Space v733_12;
        if (!v733_10.empty()) {
          const Path v735_6 = concat_path(v732_6,v732_11_head);
          const Space v735_11 = routine_72(c, v735_6, v732_11_tail);
          v733_12 = compose(v733_10,v735_11);
        }
        const Space v733_13 = unite(v733_8,v733_12);
        v732_11_result = unite(v732_11_result,v733_13);
      }
      const Space v732_11 = std::move(v732_11_result);
      v727_12 = compose(v727_10,v732_11);
    }
    const Space v727_13 = unite(v727_8,v727_12);
    v726_11_result = unite(v726_11_result,v727_13);
  }
  const Space v726_11 = std::move(v726_11_result);
  return v726_11;
}

static Space routine_71(Context& c, const Path& p0, const Space& s0) {
  Space v736_9_result;
  for (int v736_9_label = 1; v736_9_label <= 2; ++v736_9_label) {
    const Space v736_9_tail = child(s0,v736_9_label);
    if (v736_9_tail.empty()) continue;
    const Path v736_9_head{v736_9_label};
    const Space v737_2 = singleton(v736_9_head);
    const Space v737_3 = intersect(constant_6,v737_2);
    const Space v737_4 = (has_head(v737_3) ? constant_7 : Space{});
    const Space v737_5 = subtract(constant_0,v737_4);
    Space v737_8;
    if (!v737_5.empty()) {
      const Path v738_6 = concat_path(p0,v736_9_head);
      Space v738_7_result;
      for (int v738_7_label = 1; v738_7_label <= 2; ++v738_7_label) {
        const Space v738_7_tail = child(v736_9_tail,v738_7_label);
        if (v738_7_tail.empty()) continue;
        const Path v738_7_head{v738_7_label};
        const Space v739_2 = singleton(v738_7_head);
        const Space v739_3 = intersect(constant_6,v739_2);
        const Space v739_4 = (has_head(v739_3) ? constant_7 : Space{});
        const Space v739_5 = subtract(constant_0,v739_4);
        Space v739_8;
        if (!v739_5.empty()) {
          const Path v740_6 = concat_path(v738_6,v738_7_head);
          const Space v740_7 = routine_127(c, v740_6, v738_7_tail);
          v739_8 = compose(v739_5,v740_7);
        }
        const Space v739_9 = intersect(constant_6,v739_2);
        const Space v739_10 = (has_head(v739_9) ? constant_7 : Space{});
        Space v739_12;
        if (!v739_10.empty()) {
          const Path v741_6 = concat_path(v738_6,v738_7_head);
          const Space v741_11 = routine_128(c, v741_6, v738_7_tail);
          v739_12 = compose(v739_10,v741_11);
        }
        const Space v739_13 = unite(v739_8,v739_12);
        v738_7_result = unite(v738_7_result,v739_13);
      }
      const Space v738_7 = std::move(v738_7_result);
      v737_8 = compose(v737_5,v738_7);
    }
    const Space v737_9 = intersect(constant_6,v737_2);
    const Space v737_10 = (has_head(v737_9) ? constant_7 : Space{});
    const Space v737_11 = compose(v737_10,constant_9);
    const Space v737_12 = unite(v737_8,v737_11);
    v736_9_result = unite(v736_9_result,v737_12);
  }
  const Space v736_9 = std::move(v736_9_result);
  return v736_9;
}

static Space routine_72(Context& c, const Path& p0, const Space& s0) {
  return constant_9;
}

static Space routine_73(Context& c, const Path& p0, const Space& s0) {
  Space v743_11_result;
  for (int v743_11_label = 1; v743_11_label <= 2; ++v743_11_label) {
    const Space v743_11_tail = child(s0,v743_11_label);
    if (v743_11_tail.empty()) continue;
    const Path v743_11_head{v743_11_label};
    const Space v744_2 = singleton(v743_11_head);
    const Space v744_3 = intersect(constant_6,v744_2);
    const Space v744_4 = (has_head(v744_3) ? constant_7 : Space{});
    const Space v744_5 = subtract(constant_0,v744_4);
    Space v744_8;
    if (!v744_5.empty()) {
      const Path v745_6 = concat_path(p0,v743_11_head);
      Space v745_7_result;
      for (int v745_7_label = 1; v745_7_label <= 2; ++v745_7_label) {
        const Space v745_7_tail = child(v743_11_tail,v745_7_label);
        if (v745_7_tail.empty()) continue;
        const Path v745_7_head{v745_7_label};
        const Space v746_2 = singleton(v745_7_head);
        const Space v746_3 = intersect(constant_6,v746_2);
        const Space v746_4 = (has_head(v746_3) ? constant_7 : Space{});
        const Space v746_5 = subtract(constant_0,v746_4);
        Space v746_8;
        if (!v746_5.empty()) {
          const Path v747_6 = concat_path(v745_6,v745_7_head);
          const Space v747_7 = routine_129(c, v747_6, v745_7_tail);
          v746_8 = compose(v746_5,v747_7);
        }
        const Space v746_9 = intersect(constant_6,v746_2);
        const Space v746_10 = (has_head(v746_9) ? constant_7 : Space{});
        Space v746_12;
        if (!v746_10.empty()) {
          const Path v748_6 = concat_path(v745_6,v745_7_head);
          const Space v748_11 = routine_130(c, v748_6, v745_7_tail);
          v746_12 = compose(v746_10,v748_11);
        }
        const Space v746_13 = unite(v746_8,v746_12);
        v745_7_result = unite(v745_7_result,v746_13);
      }
      const Space v745_7 = std::move(v745_7_result);
      v744_8 = compose(v744_5,v745_7);
    }
    const Space v744_9 = intersect(constant_6,v744_2);
    const Space v744_10 = (has_head(v744_9) ? constant_7 : Space{});
    Space v744_12;
    if (!v744_10.empty()) {
      const Path v749_6 = concat_path(p0,v743_11_head);
      Space v749_11_result;
      for (int v749_11_label = 1; v749_11_label <= 2; ++v749_11_label) {
        const Space v749_11_tail = child(v743_11_tail,v749_11_label);
        if (v749_11_tail.empty()) continue;
        const Path v749_11_head{v749_11_label};
        const Space v750_2 = singleton(v749_11_head);
        const Space v750_3 = intersect(constant_6,v750_2);
        const Space v750_4 = (has_head(v750_3) ? constant_7 : Space{});
        const Space v750_5 = subtract(constant_0,v750_4);
        Space v750_8;
        if (!v750_5.empty()) {
          const Path v751_6 = concat_path(v749_6,v749_11_head);
          const Space v751_7 = routine_129(c, v751_6, v749_11_tail);
          v750_8 = compose(v750_5,v751_7);
        }
        const Space v750_9 = intersect(constant_6,v750_2);
        const Space v750_10 = (has_head(v750_9) ? constant_7 : Space{});
        Space v750_12;
        if (!v750_10.empty()) {
          const Path v752_6 = concat_path(v749_6,v749_11_head);
          const Space v752_11 = routine_75(c, v752_6, v749_11_tail);
          v750_12 = compose(v750_10,v752_11);
        }
        const Space v750_13 = unite(v750_8,v750_12);
        v749_11_result = unite(v749_11_result,v750_13);
      }
      const Space v749_11 = std::move(v749_11_result);
      v744_12 = compose(v744_10,v749_11);
    }
    const Space v744_13 = unite(v744_8,v744_12);
    v743_11_result = unite(v743_11_result,v744_13);
  }
  const Space v743_11 = std::move(v743_11_result);
  return v743_11;
}

static Space routine_74(Context& c, const Path& p0, const Space& s0) {
  Space v753_8_result;
  for (int v753_8_label = 1; v753_8_label <= 2; ++v753_8_label) {
    const Space v753_8_tail = child(s0,v753_8_label);
    if (v753_8_tail.empty()) continue;
    const Path v753_8_head{v753_8_label};
    const Space v754_2 = singleton(v753_8_head);
    const Space v754_3 = intersect(constant_6,v754_2);
    const Space v754_4 = (has_head(v754_3) ? constant_7 : Space{});
    const Space v754_5 = subtract(constant_0,v754_4);
    Space v754_8;
    if (!v754_5.empty()) {
      const Path v755_6 = concat_path(p0,v753_8_head);
      Space v755_7_result;
      for (int v755_7_label = 1; v755_7_label <= 2; ++v755_7_label) {
        const Space v755_7_tail = child(v753_8_tail,v755_7_label);
        if (v755_7_tail.empty()) continue;
        const Path v755_7_head{v755_7_label};
        const Space v756_2 = singleton(v755_7_head);
        const Space v756_3 = intersect(constant_6,v756_2);
        const Space v756_4 = (has_head(v756_3) ? constant_7 : Space{});
        const Space v756_5 = subtract(constant_0,v756_4);
        Space v756_8;
        if (!v756_5.empty()) {
          const Path v757_6 = concat_path(v755_6,v755_7_head);
          const Space v757_7 = routine_129(c, v757_6, v755_7_tail);
          v756_8 = compose(v756_5,v757_7);
        }
        const Space v756_9 = intersect(constant_6,v756_2);
        const Space v756_10 = (has_head(v756_9) ? constant_7 : Space{});
        Space v756_12;
        if (!v756_10.empty()) {
          const Path v758_6 = concat_path(v755_6,v755_7_head);
          const Space v758_11 = routine_130(c, v758_6, v755_7_tail);
          v756_12 = compose(v756_10,v758_11);
        }
        const Space v756_13 = unite(v756_8,v756_12);
        v755_7_result = unite(v755_7_result,v756_13);
      }
      const Space v755_7 = std::move(v755_7_result);
      v754_8 = compose(v754_5,v755_7);
    }
    const Space v754_9 = intersect(constant_6,v754_2);
    const Space v754_10 = (has_head(v754_9) ? constant_7 : Space{});
    const Space v754_11 = compose(v754_10,v753_8_tail);
    const Space v754_12 = unite(v754_8,v754_11);
    v753_8_result = unite(v753_8_result,v754_12);
  }
  const Space v753_8 = std::move(v753_8_result);
  return v753_8;
}

static Space routine_75(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_76(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v760_13_result;
  for (int v760_13_label = 1; v760_13_label <= 2; ++v760_13_label) {
    const Space v760_13_tail = child(s0,v760_13_label);
    if (v760_13_tail.empty()) continue;
    const Path v760_13_head{v760_13_label};
    const Space v761_2 = singleton(v760_13_head);
    const Space v761_3 = intersect(constant_6,v761_2);
    const Space v761_4 = (has_head(v761_3) ? constant_7 : Space{});
    const Space v761_5 = subtract(constant_0,v761_4);
    Space v761_8;
    if (!v761_5.empty()) {
      const Path v762_6 = concat_path(p0,v760_13_head);
      Space v762_7_result;
      for (int v762_7_label = 1; v762_7_label <= 2; ++v762_7_label) {
        const Space v762_7_tail = child(v760_13_tail,v762_7_label);
        if (v762_7_tail.empty()) continue;
        const Path v762_7_head{v762_7_label};
        const Space v763_2 = singleton(v762_7_head);
        const Space v763_3 = intersect(constant_6,v763_2);
        const Space v763_4 = (has_head(v763_3) ? constant_7 : Space{});
        const Space v763_5 = subtract(constant_0,v763_4);
        Space v763_8;
        if (!v763_5.empty()) {
          const Path v764_6 = concat_path(v762_6,v762_7_head);
          const Space v764_7 = routine_131(c, v764_6, p1, v762_7_tail, s1);
          v763_8 = compose(v763_5,v764_7);
        }
        const Space v763_9 = intersect(constant_6,v763_2);
        const Space v763_10 = (has_head(v763_9) ? constant_7 : Space{});
        Space v763_12;
        if (!v763_10.empty()) {
          const Path v765_6 = concat_path(v762_6,v762_7_head);
          const Space v765_11 = routine_132(c, v765_6, p1, v762_7_tail, s1);
          v763_12 = compose(v763_10,v765_11);
        }
        const Space v763_13 = unite(v763_8,v763_12);
        v762_7_result = unite(v762_7_result,v763_13);
      }
      const Space v762_7 = std::move(v762_7_result);
      v761_8 = compose(v761_5,v762_7);
    }
    const Space v761_9 = intersect(constant_6,v761_2);
    const Space v761_10 = (has_head(v761_9) ? constant_7 : Space{});
    Space v761_12;
    if (!v761_10.empty()) {
      const Path v766_6 = concat_path(p0,v760_13_head);
      Space v766_11_result;
      for (int v766_11_label = 1; v766_11_label <= 2; ++v766_11_label) {
        const Space v766_11_tail = child(v760_13_tail,v766_11_label);
        if (v766_11_tail.empty()) continue;
        const Path v766_11_head{v766_11_label};
        const Space v767_2 = singleton(v766_11_head);
        const Space v767_3 = intersect(constant_6,v767_2);
        const Space v767_4 = (has_head(v767_3) ? constant_7 : Space{});
        const Space v767_5 = subtract(constant_0,v767_4);
        Space v767_8;
        if (!v767_5.empty()) {
          const Path v768_6 = concat_path(v766_6,v766_11_head);
          const Space v768_7 = routine_131(c, v768_6, p1, v766_11_tail, s1);
          v767_8 = compose(v767_5,v768_7);
        }
        const Space v767_9 = intersect(constant_6,v767_2);
        const Space v767_10 = (has_head(v767_9) ? constant_7 : Space{});
        Space v767_12;
        if (!v767_10.empty()) {
          const Path v769_6 = concat_path(v766_6,v766_11_head);
          const Space v769_11 = routine_26(c, v769_6, p1, v766_11_tail, s1);
          v767_12 = compose(v767_10,v769_11);
        }
        const Space v767_13 = unite(v767_8,v767_12);
        v766_11_result = unite(v766_11_result,v767_13);
      }
      const Space v766_11 = std::move(v766_11_result);
      v761_12 = compose(v761_10,v766_11);
    }
    const Space v761_13 = unite(v761_8,v761_12);
    v760_13_result = unite(v760_13_result,v761_13);
  }
  const Space v760_13 = std::move(v760_13_result);
  return v760_13;
}

static Space routine_77(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v770_8 = unwrap(s1,constant_8);
  Space v770_21_result;
  for (int v770_21_label = 1; v770_21_label <= 2; ++v770_21_label) {
    const Space v770_21_tail = child(s0,v770_21_label);
    if (v770_21_tail.empty()) continue;
    const Path v770_21_head{v770_21_label};
    const Space v771_2 = singleton(v770_21_head);
    const Space v771_3 = intersect(constant_6,v771_2);
    const Space v771_4 = (has_head(v771_3) ? constant_7 : Space{});
    const Space v771_5 = subtract(constant_0,v771_4);
    Space v771_8;
    if (!v771_5.empty()) {
      const Path v772_6 = concat_path(p0,v770_21_head);
      Space v772_7_result;
      for (int v772_7_label = 1; v772_7_label <= 2; ++v772_7_label) {
        const Space v772_7_tail = child(v770_21_tail,v772_7_label);
        if (v772_7_tail.empty()) continue;
        const Path v772_7_head{v772_7_label};
        const Space v773_2 = singleton(v772_7_head);
        const Space v773_3 = intersect(constant_6,v773_2);
        const Space v773_4 = (has_head(v773_3) ? constant_7 : Space{});
        const Space v773_5 = subtract(constant_0,v773_4);
        Space v773_8;
        if (!v773_5.empty()) {
          const Path v774_6 = concat_path(v772_6,v772_7_head);
          const Space v774_7 = routine_131(c, v774_6, p1, v772_7_tail, s1);
          v773_8 = compose(v773_5,v774_7);
        }
        const Space v773_9 = intersect(constant_6,v773_2);
        const Space v773_10 = (has_head(v773_9) ? constant_7 : Space{});
        Space v773_12;
        if (!v773_10.empty()) {
          const Path v775_6 = concat_path(v772_6,v772_7_head);
          const Space v775_11 = routine_132(c, v775_6, p1, v772_7_tail, s1);
          v773_12 = compose(v773_10,v775_11);
        }
        const Space v773_13 = unite(v773_8,v773_12);
        v772_7_result = unite(v772_7_result,v773_13);
      }
      const Space v772_7 = std::move(v772_7_result);
      v771_8 = compose(v771_5,v772_7);
    }
    const Space v771_9 = intersect(constant_6,v771_2);
    const Space v771_10 = (has_head(v771_9) ? constant_7 : Space{});
    Space v771_22;
    if (!v771_10.empty()) {
      const Path v776_6 = concat_path(p0,v770_21_head);
      const Path v776_11 = concat_path(p1,v776_6);
      const Space v776_12 = routine_29(c, v776_11);
      const Space v776_13 = intersect(v770_8,v776_12);
      const Space v776_14 = routine_30(c, v776_13);
      Space v776_15_result;
      for (int v776_15_label = 1; v776_15_label <= 2; ++v776_15_label) {
        const Space v776_15_tail = child(v776_14,v776_15_label);
        if (v776_15_tail.empty()) continue;
        const Path v776_15_head{v776_15_label};
        const Space v777_2 = singleton(v776_15_head);
        const Space v777_3 = intersect(constant_6,v777_2);
        const Space v777_4 = (has_head(v777_3) ? constant_7 : Space{});
        const Space v777_5 = subtract(constant_0,v777_4);
        Space v777_7;
        if (!v777_5.empty()) {
          const Space v778_6 = routine_31(c, v776_15_head, v776_15_tail);
          v777_7 = compose(v777_5,v778_6);
        }
        const Space v777_8 = intersect(constant_6,v777_2);
        const Space v777_9 = (has_head(v777_8) ? constant_7 : Space{});
        Space v777_11;
        if (!v777_9.empty()) {
          const Space v779_10 = routine_32(c, v776_15_head, v776_15_tail);
          v777_11 = compose(v777_9,v779_10);
        }
        const Space v777_12 = unite(v777_7,v777_11);
        v776_15_result = unite(v776_15_result,v777_12);
      }
      const Space v776_15 = std::move(v776_15_result);
      const Space v776_16 = routine_33(c, v776_13);
      Space v776_17_result;
      for (int v776_17_label = 1; v776_17_label <= 2; ++v776_17_label) {
        const Space v776_17_tail = child(v776_16,v776_17_label);
        if (v776_17_tail.empty()) continue;
        const Path v776_17_head{v776_17_label};
        const Space v780_2 = singleton(v776_17_head);
        const Space v780_3 = intersect(constant_6,v780_2);
        const Space v780_4 = (has_head(v780_3) ? constant_7 : Space{});
        const Space v780_5 = subtract(constant_0,v780_4);
        Space v780_7;
        if (!v780_5.empty()) {
          const Space v781_6 = routine_34(c, v776_17_head, v776_17_tail);
          v780_7 = compose(v780_5,v781_6);
        }
        const Space v780_8 = intersect(constant_6,v780_2);
        const Space v780_9 = (has_head(v780_8) ? constant_7 : Space{});
        Space v780_11;
        if (!v780_9.empty()) {
          const Space v782_10 = routine_35(c, v776_17_head, v776_17_tail);
          v780_11 = compose(v780_9,v782_10);
        }
        const Space v780_12 = unite(v780_7,v780_11);
        v776_17_result = unite(v776_17_result,v780_12);
      }
      const Space v776_17 = std::move(v776_17_result);
      const Space v776_18 = subtract(v776_15,v776_17);
      const Space v776_19 = singleton(v776_11);
      const Space v776_20 = compose(v776_18,v776_19);
      Space v776_21_result;
      for (int v776_21_label = 1; v776_21_label <= 2; ++v776_21_label) {
        const Space v776_21_tail = child(v776_20,v776_21_label);
        if (v776_21_tail.empty()) continue;
        const Path v776_21_head{v776_21_label};
        const Space v783_2 = singleton(v776_21_head);
        const Space v783_3 = intersect(constant_6,v783_2);
        const Space v783_4 = (has_head(v783_3) ? constant_7 : Space{});
        const Space v783_5 = subtract(constant_0,v783_4);
        Space v783_7;
        if (!v783_5.empty()) {
          const Space v784_6 = routine_36(c, v776_21_head, v776_21_tail);
          v783_7 = compose(v783_5,v784_6);
        }
        const Space v783_8 = intersect(constant_6,v783_2);
        const Space v783_9 = (has_head(v783_8) ? constant_7 : Space{});
        Space v783_11;
        if (!v783_9.empty()) {
          const Space v785_10 = routine_37(c, v776_21_head, v776_21_tail);
          v783_11 = compose(v783_9,v785_10);
        }
        const Space v783_12 = unite(v783_7,v783_11);
        v776_21_result = unite(v776_21_result,v783_12);
      }
      const Space v776_21 = std::move(v776_21_result);
      v771_22 = compose(v771_10,v776_21);
    }
    const Space v771_23 = unite(v771_8,v771_22);
    v770_21_result = unite(v770_21_result,v771_23);
  }
  const Space v770_21 = std::move(v770_21_result);
  return v770_21;
}

static Space routine_78(Context& c, const Path& p0, const Space& s0) {
  Space v786_11_result;
  for (int v786_11_label = 1; v786_11_label <= 2; ++v786_11_label) {
    const Space v786_11_tail = child(s0,v786_11_label);
    if (v786_11_tail.empty()) continue;
    const Path v786_11_head{v786_11_label};
    const Space v787_2 = singleton(v786_11_head);
    const Space v787_3 = intersect(constant_6,v787_2);
    const Space v787_4 = (has_head(v787_3) ? constant_7 : Space{});
    const Space v787_5 = subtract(constant_0,v787_4);
    Space v787_8;
    if (!v787_5.empty()) {
      const Path v788_6 = concat_path(p0,v786_11_head);
      Space v788_7_result;
      for (int v788_7_label = 1; v788_7_label <= 2; ++v788_7_label) {
        const Space v788_7_tail = child(v786_11_tail,v788_7_label);
        if (v788_7_tail.empty()) continue;
        const Path v788_7_head{v788_7_label};
        const Space v789_2 = singleton(v788_7_head);
        const Space v789_3 = intersect(constant_6,v789_2);
        const Space v789_4 = (has_head(v789_3) ? constant_7 : Space{});
        const Space v789_5 = subtract(constant_0,v789_4);
        Space v789_8;
        if (!v789_5.empty()) {
          const Path v790_6 = concat_path(v788_6,v788_7_head);
          const Space v790_7 = routine_133(c, v790_6, v788_7_tail);
          v789_8 = compose(v789_5,v790_7);
        }
        const Space v789_9 = intersect(constant_6,v789_2);
        const Space v789_10 = (has_head(v789_9) ? constant_7 : Space{});
        Space v789_12;
        if (!v789_10.empty()) {
          const Path v791_6 = concat_path(v788_6,v788_7_head);
          const Space v791_11 = routine_134(c, v791_6, v788_7_tail);
          v789_12 = compose(v789_10,v791_11);
        }
        const Space v789_13 = unite(v789_8,v789_12);
        v788_7_result = unite(v788_7_result,v789_13);
      }
      const Space v788_7 = std::move(v788_7_result);
      v787_8 = compose(v787_5,v788_7);
    }
    const Space v787_9 = intersect(constant_6,v787_2);
    const Space v787_10 = (has_head(v787_9) ? constant_7 : Space{});
    Space v787_12;
    if (!v787_10.empty()) {
      const Path v792_6 = concat_path(p0,v786_11_head);
      Space v792_11_result;
      for (int v792_11_label = 1; v792_11_label <= 2; ++v792_11_label) {
        const Space v792_11_tail = child(v786_11_tail,v792_11_label);
        if (v792_11_tail.empty()) continue;
        const Path v792_11_head{v792_11_label};
        const Space v793_2 = singleton(v792_11_head);
        const Space v793_3 = intersect(constant_6,v793_2);
        const Space v793_4 = (has_head(v793_3) ? constant_7 : Space{});
        const Space v793_5 = subtract(constant_0,v793_4);
        Space v793_8;
        if (!v793_5.empty()) {
          const Path v794_6 = concat_path(v792_6,v792_11_head);
          const Space v794_7 = routine_133(c, v794_6, v792_11_tail);
          v793_8 = compose(v793_5,v794_7);
        }
        const Space v793_9 = intersect(constant_6,v793_2);
        const Space v793_10 = (has_head(v793_9) ? constant_7 : Space{});
        Space v793_12;
        if (!v793_10.empty()) {
          const Path v795_6 = concat_path(v792_6,v792_11_head);
          const Space v795_11 = routine_80(c, v795_6, v792_11_tail);
          v793_12 = compose(v793_10,v795_11);
        }
        const Space v793_13 = unite(v793_8,v793_12);
        v792_11_result = unite(v792_11_result,v793_13);
      }
      const Space v792_11 = std::move(v792_11_result);
      v787_12 = compose(v787_10,v792_11);
    }
    const Space v787_13 = unite(v787_8,v787_12);
    v786_11_result = unite(v786_11_result,v787_13);
  }
  const Space v786_11 = std::move(v786_11_result);
  return v786_11;
}

static Space routine_79(Context& c, const Path& p0, const Space& s0) {
  Space v796_11_result;
  for (int v796_11_label = 1; v796_11_label <= 2; ++v796_11_label) {
    const Space v796_11_tail = child(s0,v796_11_label);
    if (v796_11_tail.empty()) continue;
    const Path v796_11_head{v796_11_label};
    const Space v797_2 = singleton(v796_11_head);
    const Space v797_3 = intersect(constant_6,v797_2);
    const Space v797_4 = (has_head(v797_3) ? constant_7 : Space{});
    const Space v797_5 = subtract(constant_0,v797_4);
    Space v797_8;
    if (!v797_5.empty()) {
      const Path v798_6 = concat_path(p0,v796_11_head);
      Space v798_7_result;
      for (int v798_7_label = 1; v798_7_label <= 2; ++v798_7_label) {
        const Space v798_7_tail = child(v796_11_tail,v798_7_label);
        if (v798_7_tail.empty()) continue;
        const Path v798_7_head{v798_7_label};
        const Space v799_2 = singleton(v798_7_head);
        const Space v799_3 = intersect(constant_6,v799_2);
        const Space v799_4 = (has_head(v799_3) ? constant_7 : Space{});
        const Space v799_5 = subtract(constant_0,v799_4);
        Space v799_8;
        if (!v799_5.empty()) {
          const Path v800_6 = concat_path(v798_6,v798_7_head);
          const Space v800_7 = routine_133(c, v800_6, v798_7_tail);
          v799_8 = compose(v799_5,v800_7);
        }
        const Space v799_9 = intersect(constant_6,v799_2);
        const Space v799_10 = (has_head(v799_9) ? constant_7 : Space{});
        Space v799_12;
        if (!v799_10.empty()) {
          const Path v801_6 = concat_path(v798_6,v798_7_head);
          const Space v801_11 = routine_134(c, v801_6, v798_7_tail);
          v799_12 = compose(v799_10,v801_11);
        }
        const Space v799_13 = unite(v799_8,v799_12);
        v798_7_result = unite(v798_7_result,v799_13);
      }
      const Space v798_7 = std::move(v798_7_result);
      v797_8 = compose(v797_5,v798_7);
    }
    const Space v797_9 = intersect(constant_6,v797_2);
    const Space v797_10 = (has_head(v797_9) ? constant_7 : Space{});
    Space v797_12;
    if (!v797_10.empty()) {
      const Path v802_6 = concat_path(p0,v796_11_head);
      Space v802_11_result;
      for (int v802_11_label = 1; v802_11_label <= 2; ++v802_11_label) {
        const Space v802_11_tail = child(v796_11_tail,v802_11_label);
        if (v802_11_tail.empty()) continue;
        const Path v802_11_head{v802_11_label};
        const Space v803_2 = singleton(v802_11_head);
        const Space v803_3 = intersect(constant_6,v803_2);
        const Space v803_4 = (has_head(v803_3) ? constant_7 : Space{});
        const Space v803_5 = subtract(constant_0,v803_4);
        Space v803_7;
        if (!v803_5.empty()) {
          const Space v804_6 = routine_122(c, v802_11_head, v802_6, v802_11_tail);
          v803_7 = compose(v803_5,v804_6);
        }
        const Space v803_8 = intersect(constant_6,v803_2);
        const Space v803_9 = (has_head(v803_8) ? constant_7 : Space{});
        Space v803_11;
        if (!v803_9.empty()) {
          const Space v805_10 = routine_123(c, v802_11_head, v802_6, v802_11_tail);
          v803_11 = compose(v803_9,v805_10);
        }
        const Space v803_12 = unite(v803_7,v803_11);
        v802_11_result = unite(v802_11_result,v803_12);
      }
      const Space v802_11 = std::move(v802_11_result);
      v797_12 = compose(v797_10,v802_11);
    }
    const Space v797_13 = unite(v797_8,v797_12);
    v796_11_result = unite(v796_11_result,v797_13);
  }
  const Space v796_11 = std::move(v796_11_result);
  return v796_11;
}

static Space routine_80(Context& c, const Path& p0, const Space& s0) {
  Space v806_11_result;
  for (int v806_11_label = 1; v806_11_label <= 2; ++v806_11_label) {
    const Space v806_11_tail = child(s0,v806_11_label);
    if (v806_11_tail.empty()) continue;
    const Path v806_11_head{v806_11_label};
    const Space v807_2 = singleton(v806_11_head);
    const Space v807_3 = intersect(constant_6,v807_2);
    const Space v807_4 = (has_head(v807_3) ? constant_7 : Space{});
    const Space v807_5 = subtract(constant_0,v807_4);
    Space v807_7;
    if (!v807_5.empty()) {
      Space v808_6_result;
      for (int v808_6_label = 1; v808_6_label <= 2; ++v808_6_label) {
        const Space v808_6_tail = child(v806_11_tail,v808_6_label);
        if (v808_6_tail.empty()) continue;
        const Path v808_6_head{v808_6_label};
        const Space v809_2 = singleton(v808_6_head);
        const Space v809_3 = intersect(constant_6,v809_2);
        const Space v809_4 = (has_head(v809_3) ? constant_7 : Space{});
        const Space v809_5 = subtract(constant_0,v809_4);
        Space v809_8;
        if (!v809_5.empty()) {
          const Path v810_6 = concat_path(v806_11_head,v808_6_head);
          const Space v810_7 = routine_135(c, v810_6, p0, v808_6_tail);
          v809_8 = compose(v809_5,v810_7);
        }
        const Space v809_9 = intersect(constant_6,v809_2);
        const Space v809_10 = (has_head(v809_9) ? constant_7 : Space{});
        Space v809_12;
        if (!v809_10.empty()) {
          const Path v811_6 = concat_path(v806_11_head,v808_6_head);
          const Space v811_11 = routine_136(c, v811_6, p0, v808_6_tail);
          v809_12 = compose(v809_10,v811_11);
        }
        const Space v809_13 = unite(v809_8,v809_12);
        v808_6_result = unite(v808_6_result,v809_13);
      }
      const Space v808_6 = std::move(v808_6_result);
      v807_7 = compose(v807_5,v808_6);
    }
    const Space v807_8 = intersect(constant_6,v807_2);
    const Space v807_9 = (has_head(v807_8) ? constant_7 : Space{});
    Space v807_11;
    if (!v807_9.empty()) {
      Space v812_10_result;
      for (int v812_10_label = 1; v812_10_label <= 2; ++v812_10_label) {
        const Space v812_10_tail = child(v806_11_tail,v812_10_label);
        if (v812_10_tail.empty()) continue;
        const Path v812_10_head{v812_10_label};
        const Space v813_2 = singleton(v812_10_head);
        const Space v813_3 = intersect(constant_6,v813_2);
        const Space v813_4 = (has_head(v813_3) ? constant_7 : Space{});
        const Space v813_5 = subtract(constant_0,v813_4);
        Space v813_8;
        if (!v813_5.empty()) {
          const Path v814_6 = concat_path(v806_11_head,v812_10_head);
          const Space v814_7 = routine_135(c, v814_6, p0, v812_10_tail);
          v813_8 = compose(v813_5,v814_7);
        }
        const Space v813_9 = intersect(constant_6,v813_2);
        const Space v813_10 = (has_head(v813_9) ? constant_7 : Space{});
        Space v813_12;
        if (!v813_10.empty()) {
          const Path v815_6 = concat_path(v806_11_head,v812_10_head);
          const Space v815_11 = routine_137(c, v815_6, p0, v812_10_tail);
          v813_12 = compose(v813_10,v815_11);
        }
        const Space v813_13 = unite(v813_8,v813_12);
        v812_10_result = unite(v812_10_result,v813_13);
      }
      const Space v812_10 = std::move(v812_10_result);
      v807_11 = compose(v807_9,v812_10);
    }
    const Space v807_12 = unite(v807_7,v807_11);
    v806_11_result = unite(v806_11_result,v807_12);
  }
  const Space v806_11 = std::move(v806_11_result);
  return v806_11;
}

static Space routine_81(Context& c, const Space& s0) {
  const Space v816_2 = first_matching(s0,constant_0,false);
  const Space v816_3 = intersect(constant_0,v816_2);
  const Space v816_4 = (has_head(v816_2) ? constant_7 : Space{});
  const Space v816_5 = unite(v816_3,v816_4);
  const Space v816_7 = compose(v816_5,constant_0);
  const Space v816_9 = subtract(constant_0,v816_2);
  const Space v816_10 = subtract(v816_9,v816_4);
  Space v816_18;
  if (!v816_10.empty()) {
    const Space v817_11 = first_listed(s0,constant_11,true);
    const Space v817_12 = first_matching(v817_11,constant_0,false);
    Space v817_15;
    if (!v817_12.empty()) {
      const Space v818_14 = routine_138(c, constant_10, s0);
      v817_15 = compose(v817_12,v818_14);
    }
    Space v817_16_result;
    for (int v817_16_label = 1; v817_16_label <= 2; ++v817_16_label) {
      const Space v817_16_tail = child(v817_11,v817_16_label);
      if (v817_16_tail.empty()) continue;
      const Path v817_16_head{v817_16_label};
      const Space v819_2 = routine_124(c, v817_16_head, v817_16_tail, s0);
      v817_16_result = unite(v817_16_result,v819_2);
    }
    const Space v817_16 = std::move(v817_16_result);
    const Space v817_17 = unite(v817_15,v817_16);
    v816_18 = compose(v816_10,v817_17);
  }
  const Space v816_19 = unite(v816_7,v816_18);
  return v816_19;
}

static Space routine_82(Context& c, const Path& p0, const Space& s0) {
  Space v820_11_result;
  for (int v820_11_label = 1; v820_11_label <= 2; ++v820_11_label) {
    const Space v820_11_tail = child(s0,v820_11_label);
    if (v820_11_tail.empty()) continue;
    const Path v820_11_head{v820_11_label};
    const Space v821_2 = singleton(v820_11_head);
    const Space v821_3 = intersect(constant_6,v821_2);
    const Space v821_4 = (has_head(v821_3) ? constant_7 : Space{});
    const Space v821_5 = subtract(constant_0,v821_4);
    Space v821_8;
    if (!v821_5.empty()) {
      const Path v822_6 = concat_path(p0,v820_11_head);
      Space v822_7_result;
      for (int v822_7_label = 1; v822_7_label <= 2; ++v822_7_label) {
        const Space v822_7_tail = child(v820_11_tail,v822_7_label);
        if (v822_7_tail.empty()) continue;
        const Path v822_7_head{v822_7_label};
        const Space v823_2 = singleton(v822_7_head);
        const Space v823_3 = intersect(constant_6,v823_2);
        const Space v823_4 = (has_head(v823_3) ? constant_7 : Space{});
        const Space v823_5 = subtract(constant_0,v823_4);
        Space v823_8;
        if (!v823_5.empty()) {
          const Path v824_6 = concat_path(v822_6,v822_7_head);
          const Space v824_7 = routine_139(c, v824_6, v822_7_tail);
          v823_8 = compose(v823_5,v824_7);
        }
        const Space v823_9 = intersect(constant_6,v823_2);
        const Space v823_10 = (has_head(v823_9) ? constant_7 : Space{});
        Space v823_12;
        if (!v823_10.empty()) {
          const Path v825_6 = concat_path(v822_6,v822_7_head);
          const Space v825_11 = routine_140(c, v825_6, v822_7_tail);
          v823_12 = compose(v823_10,v825_11);
        }
        const Space v823_13 = unite(v823_8,v823_12);
        v822_7_result = unite(v822_7_result,v823_13);
      }
      const Space v822_7 = std::move(v822_7_result);
      v821_8 = compose(v821_5,v822_7);
    }
    const Space v821_9 = intersect(constant_6,v821_2);
    const Space v821_10 = (has_head(v821_9) ? constant_7 : Space{});
    Space v821_12;
    if (!v821_10.empty()) {
      const Path v826_6 = concat_path(p0,v820_11_head);
      Space v826_11_result;
      for (int v826_11_label = 1; v826_11_label <= 2; ++v826_11_label) {
        const Space v826_11_tail = child(v820_11_tail,v826_11_label);
        if (v826_11_tail.empty()) continue;
        const Path v826_11_head{v826_11_label};
        const Space v827_2 = singleton(v826_11_head);
        const Space v827_3 = intersect(constant_6,v827_2);
        const Space v827_4 = (has_head(v827_3) ? constant_7 : Space{});
        const Space v827_5 = subtract(constant_0,v827_4);
        Space v827_8;
        if (!v827_5.empty()) {
          const Path v828_6 = concat_path(v826_6,v826_11_head);
          const Space v828_7 = routine_139(c, v828_6, v826_11_tail);
          v827_8 = compose(v827_5,v828_7);
        }
        const Space v827_9 = intersect(constant_6,v827_2);
        const Space v827_10 = (has_head(v827_9) ? constant_7 : Space{});
        Space v827_12;
        if (!v827_10.empty()) {
          const Path v829_6 = concat_path(v826_6,v826_11_head);
          const Space v829_11 = routine_69(c, v829_6, v826_11_tail);
          v827_12 = compose(v827_10,v829_11);
        }
        const Space v827_13 = unite(v827_8,v827_12);
        v826_11_result = unite(v826_11_result,v827_13);
      }
      const Space v826_11 = std::move(v826_11_result);
      v821_12 = compose(v821_10,v826_11);
    }
    const Space v821_13 = unite(v821_8,v821_12);
    v820_11_result = unite(v820_11_result,v821_13);
  }
  const Space v820_11 = std::move(v820_11_result);
  return v820_11;
}

static Space routine_83(Context& c, const Path& p0, const Space& s0) {
  Space v830_9_result;
  for (int v830_9_label = 1; v830_9_label <= 2; ++v830_9_label) {
    const Space v830_9_tail = child(s0,v830_9_label);
    if (v830_9_tail.empty()) continue;
    const Path v830_9_head{v830_9_label};
    const Space v831_2 = singleton(v830_9_head);
    const Space v831_3 = intersect(constant_6,v831_2);
    const Space v831_4 = (has_head(v831_3) ? constant_7 : Space{});
    const Space v831_5 = subtract(constant_0,v831_4);
    Space v831_8;
    if (!v831_5.empty()) {
      const Path v832_6 = concat_path(p0,v830_9_head);
      Space v832_7_result;
      for (int v832_7_label = 1; v832_7_label <= 2; ++v832_7_label) {
        const Space v832_7_tail = child(v830_9_tail,v832_7_label);
        if (v832_7_tail.empty()) continue;
        const Path v832_7_head{v832_7_label};
        const Space v833_2 = singleton(v832_7_head);
        const Space v833_3 = intersect(constant_6,v833_2);
        const Space v833_4 = (has_head(v833_3) ? constant_7 : Space{});
        const Space v833_5 = subtract(constant_0,v833_4);
        Space v833_8;
        if (!v833_5.empty()) {
          const Path v834_6 = concat_path(v832_6,v832_7_head);
          const Space v834_7 = routine_139(c, v834_6, v832_7_tail);
          v833_8 = compose(v833_5,v834_7);
        }
        const Space v833_9 = intersect(constant_6,v833_2);
        const Space v833_10 = (has_head(v833_9) ? constant_7 : Space{});
        Space v833_12;
        if (!v833_10.empty()) {
          const Path v835_6 = concat_path(v832_6,v832_7_head);
          const Space v835_11 = routine_140(c, v835_6, v832_7_tail);
          v833_12 = compose(v833_10,v835_11);
        }
        const Space v833_13 = unite(v833_8,v833_12);
        v832_7_result = unite(v832_7_result,v833_13);
      }
      const Space v832_7 = std::move(v832_7_result);
      v831_8 = compose(v831_5,v832_7);
    }
    const Space v831_9 = intersect(constant_6,v831_2);
    const Space v831_10 = (has_head(v831_9) ? constant_7 : Space{});
    const Space v831_11 = compose(v831_10,constant_9);
    const Space v831_12 = unite(v831_8,v831_11);
    v830_9_result = unite(v830_9_result,v831_12);
  }
  const Space v830_9 = std::move(v830_9_result);
  return v830_9;
}

static Space routine_84(Context& c, const Path& p0, const Space& s0) {
  Space v836_11_result;
  for (int v836_11_label = 1; v836_11_label <= 2; ++v836_11_label) {
    const Space v836_11_tail = child(s0,v836_11_label);
    if (v836_11_tail.empty()) continue;
    const Path v836_11_head{v836_11_label};
    const Space v837_2 = singleton(v836_11_head);
    const Space v837_3 = intersect(constant_6,v837_2);
    const Space v837_4 = (has_head(v837_3) ? constant_7 : Space{});
    const Space v837_5 = subtract(constant_0,v837_4);
    Space v837_8;
    if (!v837_5.empty()) {
      const Path v838_6 = concat_path(p0,v836_11_head);
      Space v838_7_result;
      for (int v838_7_label = 1; v838_7_label <= 2; ++v838_7_label) {
        const Space v838_7_tail = child(v836_11_tail,v838_7_label);
        if (v838_7_tail.empty()) continue;
        const Path v838_7_head{v838_7_label};
        const Space v839_2 = singleton(v838_7_head);
        const Space v839_3 = intersect(constant_6,v839_2);
        const Space v839_4 = (has_head(v839_3) ? constant_7 : Space{});
        const Space v839_5 = subtract(constant_0,v839_4);
        Space v839_8;
        if (!v839_5.empty()) {
          const Path v840_6 = concat_path(v838_6,v838_7_head);
          const Space v840_7 = routine_141(c, v840_6, v838_7_tail);
          v839_8 = compose(v839_5,v840_7);
        }
        const Space v839_9 = intersect(constant_6,v839_2);
        const Space v839_10 = (has_head(v839_9) ? constant_7 : Space{});
        Space v839_12;
        if (!v839_10.empty()) {
          const Path v841_6 = concat_path(v838_6,v838_7_head);
          const Space v841_11 = routine_142(c, v841_6, v838_7_tail);
          v839_12 = compose(v839_10,v841_11);
        }
        const Space v839_13 = unite(v839_8,v839_12);
        v838_7_result = unite(v838_7_result,v839_13);
      }
      const Space v838_7 = std::move(v838_7_result);
      v837_8 = compose(v837_5,v838_7);
    }
    const Space v837_9 = intersect(constant_6,v837_2);
    const Space v837_10 = (has_head(v837_9) ? constant_7 : Space{});
    Space v837_12;
    if (!v837_10.empty()) {
      const Path v842_6 = concat_path(p0,v836_11_head);
      Space v842_11_result;
      for (int v842_11_label = 1; v842_11_label <= 2; ++v842_11_label) {
        const Space v842_11_tail = child(v836_11_tail,v842_11_label);
        if (v842_11_tail.empty()) continue;
        const Path v842_11_head{v842_11_label};
        const Space v843_2 = singleton(v842_11_head);
        const Space v843_3 = intersect(constant_6,v843_2);
        const Space v843_4 = (has_head(v843_3) ? constant_7 : Space{});
        const Space v843_5 = subtract(constant_0,v843_4);
        Space v843_8;
        if (!v843_5.empty()) {
          const Path v844_6 = concat_path(v842_6,v842_11_head);
          const Space v844_7 = routine_141(c, v844_6, v842_11_tail);
          v843_8 = compose(v843_5,v844_7);
        }
        const Space v843_9 = intersect(constant_6,v843_2);
        const Space v843_10 = (has_head(v843_9) ? constant_7 : Space{});
        Space v843_12;
        if (!v843_10.empty()) {
          const Path v845_6 = concat_path(v842_6,v842_11_head);
          const Space v845_11 = routine_72(c, v845_6, v842_11_tail);
          v843_12 = compose(v843_10,v845_11);
        }
        const Space v843_13 = unite(v843_8,v843_12);
        v842_11_result = unite(v842_11_result,v843_13);
      }
      const Space v842_11 = std::move(v842_11_result);
      v837_12 = compose(v837_10,v842_11);
    }
    const Space v837_13 = unite(v837_8,v837_12);
    v836_11_result = unite(v836_11_result,v837_13);
  }
  const Space v836_11 = std::move(v836_11_result);
  return v836_11;
}

static Space routine_85(Context& c, const Path& p0, const Space& s0) {
  Space v846_9_result;
  for (int v846_9_label = 1; v846_9_label <= 2; ++v846_9_label) {
    const Space v846_9_tail = child(s0,v846_9_label);
    if (v846_9_tail.empty()) continue;
    const Path v846_9_head{v846_9_label};
    const Space v847_2 = singleton(v846_9_head);
    const Space v847_3 = intersect(constant_6,v847_2);
    const Space v847_4 = (has_head(v847_3) ? constant_7 : Space{});
    const Space v847_5 = subtract(constant_0,v847_4);
    Space v847_8;
    if (!v847_5.empty()) {
      const Path v848_6 = concat_path(p0,v846_9_head);
      Space v848_7_result;
      for (int v848_7_label = 1; v848_7_label <= 2; ++v848_7_label) {
        const Space v848_7_tail = child(v846_9_tail,v848_7_label);
        if (v848_7_tail.empty()) continue;
        const Path v848_7_head{v848_7_label};
        const Space v849_2 = singleton(v848_7_head);
        const Space v849_3 = intersect(constant_6,v849_2);
        const Space v849_4 = (has_head(v849_3) ? constant_7 : Space{});
        const Space v849_5 = subtract(constant_0,v849_4);
        Space v849_8;
        if (!v849_5.empty()) {
          const Path v850_6 = concat_path(v848_6,v848_7_head);
          const Space v850_7 = routine_141(c, v850_6, v848_7_tail);
          v849_8 = compose(v849_5,v850_7);
        }
        const Space v849_9 = intersect(constant_6,v849_2);
        const Space v849_10 = (has_head(v849_9) ? constant_7 : Space{});
        Space v849_12;
        if (!v849_10.empty()) {
          const Path v851_6 = concat_path(v848_6,v848_7_head);
          const Space v851_11 = routine_142(c, v851_6, v848_7_tail);
          v849_12 = compose(v849_10,v851_11);
        }
        const Space v849_13 = unite(v849_8,v849_12);
        v848_7_result = unite(v848_7_result,v849_13);
      }
      const Space v848_7 = std::move(v848_7_result);
      v847_8 = compose(v847_5,v848_7);
    }
    const Space v847_9 = intersect(constant_6,v847_2);
    const Space v847_10 = (has_head(v847_9) ? constant_7 : Space{});
    const Space v847_11 = compose(v847_10,constant_9);
    const Space v847_12 = unite(v847_8,v847_11);
    v846_9_result = unite(v846_9_result,v847_12);
  }
  const Space v846_9 = std::move(v846_9_result);
  return v846_9;
}

static Space routine_86(Context& c, const Path& p0, const Space& s0) {
  Space v852_11_result;
  for (int v852_11_label = 1; v852_11_label <= 2; ++v852_11_label) {
    const Space v852_11_tail = child(s0,v852_11_label);
    if (v852_11_tail.empty()) continue;
    const Path v852_11_head{v852_11_label};
    const Space v853_2 = singleton(v852_11_head);
    const Space v853_3 = intersect(constant_6,v853_2);
    const Space v853_4 = (has_head(v853_3) ? constant_7 : Space{});
    const Space v853_5 = subtract(constant_0,v853_4);
    Space v853_8;
    if (!v853_5.empty()) {
      const Path v854_6 = concat_path(p0,v852_11_head);
      Space v854_7_result;
      for (int v854_7_label = 1; v854_7_label <= 2; ++v854_7_label) {
        const Space v854_7_tail = child(v852_11_tail,v854_7_label);
        if (v854_7_tail.empty()) continue;
        const Path v854_7_head{v854_7_label};
        const Space v855_2 = singleton(v854_7_head);
        const Space v855_3 = intersect(constant_6,v855_2);
        const Space v855_4 = (has_head(v855_3) ? constant_7 : Space{});
        const Space v855_5 = subtract(constant_0,v855_4);
        Space v855_8;
        if (!v855_5.empty()) {
          const Path v856_6 = concat_path(v854_6,v854_7_head);
          const Space v856_7 = routine_143(c, v856_6, v854_7_tail);
          v855_8 = compose(v855_5,v856_7);
        }
        const Space v855_9 = intersect(constant_6,v855_2);
        const Space v855_10 = (has_head(v855_9) ? constant_7 : Space{});
        Space v855_12;
        if (!v855_10.empty()) {
          const Path v857_6 = concat_path(v854_6,v854_7_head);
          const Space v857_11 = routine_144(c, v857_6, v854_7_tail);
          v855_12 = compose(v855_10,v857_11);
        }
        const Space v855_13 = unite(v855_8,v855_12);
        v854_7_result = unite(v854_7_result,v855_13);
      }
      const Space v854_7 = std::move(v854_7_result);
      v853_8 = compose(v853_5,v854_7);
    }
    const Space v853_9 = intersect(constant_6,v853_2);
    const Space v853_10 = (has_head(v853_9) ? constant_7 : Space{});
    Space v853_12;
    if (!v853_10.empty()) {
      const Path v858_6 = concat_path(p0,v852_11_head);
      Space v858_11_result;
      for (int v858_11_label = 1; v858_11_label <= 2; ++v858_11_label) {
        const Space v858_11_tail = child(v852_11_tail,v858_11_label);
        if (v858_11_tail.empty()) continue;
        const Path v858_11_head{v858_11_label};
        const Space v859_2 = singleton(v858_11_head);
        const Space v859_3 = intersect(constant_6,v859_2);
        const Space v859_4 = (has_head(v859_3) ? constant_7 : Space{});
        const Space v859_5 = subtract(constant_0,v859_4);
        Space v859_8;
        if (!v859_5.empty()) {
          const Path v860_6 = concat_path(v858_6,v858_11_head);
          const Space v860_7 = routine_143(c, v860_6, v858_11_tail);
          v859_8 = compose(v859_5,v860_7);
        }
        const Space v859_9 = intersect(constant_6,v859_2);
        const Space v859_10 = (has_head(v859_9) ? constant_7 : Space{});
        Space v859_12;
        if (!v859_10.empty()) {
          const Path v861_6 = concat_path(v858_6,v858_11_head);
          const Space v861_11 = routine_75(c, v861_6, v858_11_tail);
          v859_12 = compose(v859_10,v861_11);
        }
        const Space v859_13 = unite(v859_8,v859_12);
        v858_11_result = unite(v858_11_result,v859_13);
      }
      const Space v858_11 = std::move(v858_11_result);
      v853_12 = compose(v853_10,v858_11);
    }
    const Space v853_13 = unite(v853_8,v853_12);
    v852_11_result = unite(v852_11_result,v853_13);
  }
  const Space v852_11 = std::move(v852_11_result);
  return v852_11;
}

static Space routine_87(Context& c, const Path& p0, const Space& s0) {
  Space v862_8_result;
  for (int v862_8_label = 1; v862_8_label <= 2; ++v862_8_label) {
    const Space v862_8_tail = child(s0,v862_8_label);
    if (v862_8_tail.empty()) continue;
    const Path v862_8_head{v862_8_label};
    const Space v863_2 = singleton(v862_8_head);
    const Space v863_3 = intersect(constant_6,v863_2);
    const Space v863_4 = (has_head(v863_3) ? constant_7 : Space{});
    const Space v863_5 = subtract(constant_0,v863_4);
    Space v863_8;
    if (!v863_5.empty()) {
      const Path v864_6 = concat_path(p0,v862_8_head);
      Space v864_7_result;
      for (int v864_7_label = 1; v864_7_label <= 2; ++v864_7_label) {
        const Space v864_7_tail = child(v862_8_tail,v864_7_label);
        if (v864_7_tail.empty()) continue;
        const Path v864_7_head{v864_7_label};
        const Space v865_2 = singleton(v864_7_head);
        const Space v865_3 = intersect(constant_6,v865_2);
        const Space v865_4 = (has_head(v865_3) ? constant_7 : Space{});
        const Space v865_5 = subtract(constant_0,v865_4);
        Space v865_8;
        if (!v865_5.empty()) {
          const Path v866_6 = concat_path(v864_6,v864_7_head);
          const Space v866_7 = routine_143(c, v866_6, v864_7_tail);
          v865_8 = compose(v865_5,v866_7);
        }
        const Space v865_9 = intersect(constant_6,v865_2);
        const Space v865_10 = (has_head(v865_9) ? constant_7 : Space{});
        Space v865_12;
        if (!v865_10.empty()) {
          const Path v867_6 = concat_path(v864_6,v864_7_head);
          const Space v867_11 = routine_144(c, v867_6, v864_7_tail);
          v865_12 = compose(v865_10,v867_11);
        }
        const Space v865_13 = unite(v865_8,v865_12);
        v864_7_result = unite(v864_7_result,v865_13);
      }
      const Space v864_7 = std::move(v864_7_result);
      v863_8 = compose(v863_5,v864_7);
    }
    const Space v863_9 = intersect(constant_6,v863_2);
    const Space v863_10 = (has_head(v863_9) ? constant_7 : Space{});
    const Space v863_11 = compose(v863_10,v862_8_tail);
    const Space v863_12 = unite(v863_8,v863_11);
    v862_8_result = unite(v862_8_result,v863_12);
  }
  const Space v862_8 = std::move(v862_8_result);
  return v862_8;
}

static Space routine_88(Context& c, const Path& p0, const Space& s0) {
  Space v868_11_result;
  for (int v868_11_label = 1; v868_11_label <= 2; ++v868_11_label) {
    const Space v868_11_tail = child(s0,v868_11_label);
    if (v868_11_tail.empty()) continue;
    const Path v868_11_head{v868_11_label};
    const Space v869_2 = singleton(v868_11_head);
    const Space v869_3 = intersect(constant_6,v869_2);
    const Space v869_4 = (has_head(v869_3) ? constant_7 : Space{});
    const Space v869_5 = subtract(constant_0,v869_4);
    Space v869_8;
    if (!v869_5.empty()) {
      const Path v870_6 = concat_path(p0,v868_11_head);
      Space v870_7_result;
      for (int v870_7_label = 1; v870_7_label <= 2; ++v870_7_label) {
        const Space v870_7_tail = child(v868_11_tail,v870_7_label);
        if (v870_7_tail.empty()) continue;
        const Path v870_7_head{v870_7_label};
        const Space v871_2 = singleton(v870_7_head);
        const Space v871_3 = intersect(constant_6,v871_2);
        const Space v871_4 = (has_head(v871_3) ? constant_7 : Space{});
        const Space v871_5 = subtract(constant_0,v871_4);
        Space v871_8;
        if (!v871_5.empty()) {
          const Path v872_6 = concat_path(v870_6,v870_7_head);
          const Space v872_7 = routine_145(c, v872_6, v870_7_tail);
          v871_8 = compose(v871_5,v872_7);
        }
        const Space v871_9 = intersect(constant_6,v871_2);
        const Space v871_10 = (has_head(v871_9) ? constant_7 : Space{});
        Space v871_12;
        if (!v871_10.empty()) {
          const Path v873_6 = concat_path(v870_6,v870_7_head);
          const Space v873_11 = routine_146(c, v873_6, v870_7_tail);
          v871_12 = compose(v871_10,v873_11);
        }
        const Space v871_13 = unite(v871_8,v871_12);
        v870_7_result = unite(v870_7_result,v871_13);
      }
      const Space v870_7 = std::move(v870_7_result);
      v869_8 = compose(v869_5,v870_7);
    }
    const Space v869_9 = intersect(constant_6,v869_2);
    const Space v869_10 = (has_head(v869_9) ? constant_7 : Space{});
    Space v869_12;
    if (!v869_10.empty()) {
      const Path v874_6 = concat_path(p0,v868_11_head);
      Space v874_11_result;
      for (int v874_11_label = 1; v874_11_label <= 2; ++v874_11_label) {
        const Space v874_11_tail = child(v868_11_tail,v874_11_label);
        if (v874_11_tail.empty()) continue;
        const Path v874_11_head{v874_11_label};
        const Space v875_2 = singleton(v874_11_head);
        const Space v875_3 = intersect(constant_6,v875_2);
        const Space v875_4 = (has_head(v875_3) ? constant_7 : Space{});
        const Space v875_5 = subtract(constant_0,v875_4);
        Space v875_8;
        if (!v875_5.empty()) {
          const Path v876_6 = concat_path(v874_6,v874_11_head);
          const Space v876_7 = routine_145(c, v876_6, v874_11_tail);
          v875_8 = compose(v875_5,v876_7);
        }
        const Space v875_9 = intersect(constant_6,v875_2);
        const Space v875_10 = (has_head(v875_9) ? constant_7 : Space{});
        Space v875_12;
        if (!v875_10.empty()) {
          const Path v877_6 = concat_path(v874_6,v874_11_head);
          const Space v877_11 = routine_14(c, v877_6, v874_11_tail);
          v875_12 = compose(v875_10,v877_11);
        }
        const Space v875_13 = unite(v875_8,v875_12);
        v874_11_result = unite(v874_11_result,v875_13);
      }
      const Space v874_11 = std::move(v874_11_result);
      v869_12 = compose(v869_10,v874_11);
    }
    const Space v869_13 = unite(v869_8,v869_12);
    v868_11_result = unite(v868_11_result,v869_13);
  }
  const Space v868_11 = std::move(v868_11_result);
  return v868_11;
}

static Space routine_89(Context& c, const Path& p0, const Space& s0) {
  Space v878_11_result;
  for (int v878_11_label = 1; v878_11_label <= 2; ++v878_11_label) {
    const Space v878_11_tail = child(s0,v878_11_label);
    if (v878_11_tail.empty()) continue;
    const Path v878_11_head{v878_11_label};
    const Space v879_2 = singleton(v878_11_head);
    const Space v879_3 = intersect(constant_6,v879_2);
    const Space v879_4 = (has_head(v879_3) ? constant_7 : Space{});
    const Space v879_5 = subtract(constant_0,v879_4);
    Space v879_8;
    if (!v879_5.empty()) {
      const Path v880_6 = concat_path(p0,v878_11_head);
      Space v880_7_result;
      for (int v880_7_label = 1; v880_7_label <= 2; ++v880_7_label) {
        const Space v880_7_tail = child(v878_11_tail,v880_7_label);
        if (v880_7_tail.empty()) continue;
        const Path v880_7_head{v880_7_label};
        const Space v881_2 = singleton(v880_7_head);
        const Space v881_3 = intersect(constant_6,v881_2);
        const Space v881_4 = (has_head(v881_3) ? constant_7 : Space{});
        const Space v881_5 = subtract(constant_0,v881_4);
        Space v881_8;
        if (!v881_5.empty()) {
          const Path v882_6 = concat_path(v880_6,v880_7_head);
          const Space v882_7 = routine_145(c, v882_6, v880_7_tail);
          v881_8 = compose(v881_5,v882_7);
        }
        const Space v881_9 = intersect(constant_6,v881_2);
        const Space v881_10 = (has_head(v881_9) ? constant_7 : Space{});
        Space v881_12;
        if (!v881_10.empty()) {
          const Path v883_6 = concat_path(v880_6,v880_7_head);
          const Space v883_11 = routine_146(c, v883_6, v880_7_tail);
          v881_12 = compose(v881_10,v883_11);
        }
        const Space v881_13 = unite(v881_8,v881_12);
        v880_7_result = unite(v880_7_result,v881_13);
      }
      const Space v880_7 = std::move(v880_7_result);
      v879_8 = compose(v879_5,v880_7);
    }
    const Space v879_9 = intersect(constant_6,v879_2);
    const Space v879_10 = (has_head(v879_9) ? constant_7 : Space{});
    Space v879_12;
    if (!v879_10.empty()) {
      const Path v884_6 = concat_path(p0,v878_11_head);
      Space v884_11_result;
      for (int v884_11_label = 1; v884_11_label <= 2; ++v884_11_label) {
        const Space v884_11_tail = child(v878_11_tail,v884_11_label);
        if (v884_11_tail.empty()) continue;
        const Path v884_11_head{v884_11_label};
        const Space v885_2 = singleton(v884_11_head);
        const Space v885_3 = intersect(constant_6,v885_2);
        const Space v885_4 = (has_head(v885_3) ? constant_7 : Space{});
        const Space v885_5 = subtract(constant_0,v885_4);
        Space v885_7;
        if (!v885_5.empty()) {
          const Space v886_6 = routine_15(c, v884_11_head, v884_6, v884_11_tail);
          v885_7 = compose(v885_5,v886_6);
        }
        const Space v885_8 = intersect(constant_6,v885_2);
        const Space v885_9 = (has_head(v885_8) ? constant_7 : Space{});
        Space v885_11;
        if (!v885_9.empty()) {
          const Space v887_10 = routine_16(c, v884_11_head, v884_6, v884_11_tail);
          v885_11 = compose(v885_9,v887_10);
        }
        const Space v885_12 = unite(v885_7,v885_11);
        v884_11_result = unite(v884_11_result,v885_12);
      }
      const Space v884_11 = std::move(v884_11_result);
      v879_12 = compose(v879_10,v884_11);
    }
    const Space v879_13 = unite(v879_8,v879_12);
    v878_11_result = unite(v878_11_result,v879_13);
  }
  const Space v878_11 = std::move(v878_11_result);
  return v878_11;
}

static Space routine_90(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v888_12_result;
  for (int v888_12_label = 1; v888_12_label <= 2; ++v888_12_label) {
    const Space v888_12_tail = child(s0,v888_12_label);
    if (v888_12_tail.empty()) continue;
    const Path v888_12_head{v888_12_label};
    const Space v889_2 = singleton(v888_12_head);
    const Space v889_3 = intersect(constant_6,v889_2);
    const Space v889_4 = (has_head(v889_3) ? constant_7 : Space{});
    const Space v889_5 = subtract(constant_0,v889_4);
    Space v889_8;
    if (!v889_5.empty()) {
      const Path v890_6 = concat_path(p0,v888_12_head);
      Space v890_7_result;
      for (int v890_7_label = 1; v890_7_label <= 2; ++v890_7_label) {
        const Space v890_7_tail = child(v888_12_tail,v890_7_label);
        if (v890_7_tail.empty()) continue;
        const Path v890_7_head{v890_7_label};
        const Space v891_2 = singleton(v890_7_head);
        const Space v891_3 = intersect(constant_6,v891_2);
        const Space v891_4 = (has_head(v891_3) ? constant_7 : Space{});
        const Space v891_5 = subtract(constant_0,v891_4);
        Space v891_8;
        if (!v891_5.empty()) {
          const Path v892_6 = concat_path(v890_6,v890_7_head);
          const Space v892_7 = routine_147(c, v892_6, p1, v890_7_tail);
          v891_8 = compose(v891_5,v892_7);
        }
        const Space v891_9 = intersect(constant_6,v891_2);
        const Space v891_10 = (has_head(v891_9) ? constant_7 : Space{});
        Space v891_12;
        if (!v891_10.empty()) {
          const Path v893_6 = concat_path(v890_6,v890_7_head);
          const Space v893_11 = routine_148(c, v893_6, p1, v890_7_tail);
          v891_12 = compose(v891_10,v893_11);
        }
        const Space v891_13 = unite(v891_8,v891_12);
        v890_7_result = unite(v890_7_result,v891_13);
      }
      const Space v890_7 = std::move(v890_7_result);
      v889_8 = compose(v889_5,v890_7);
    }
    const Space v889_9 = intersect(constant_6,v889_2);
    const Space v889_10 = (has_head(v889_9) ? constant_7 : Space{});
    Space v889_12;
    if (!v889_10.empty()) {
      const Path v894_6 = concat_path(p0,v888_12_head);
      Space v894_11_result;
      for (int v894_11_label = 1; v894_11_label <= 2; ++v894_11_label) {
        const Space v894_11_tail = child(v888_12_tail,v894_11_label);
        if (v894_11_tail.empty()) continue;
        const Path v894_11_head{v894_11_label};
        const Space v895_2 = singleton(v894_11_head);
        const Space v895_3 = intersect(constant_6,v895_2);
        const Space v895_4 = (has_head(v895_3) ? constant_7 : Space{});
        const Space v895_5 = subtract(constant_0,v895_4);
        Space v895_8;
        if (!v895_5.empty()) {
          const Path v896_6 = concat_path(v894_6,v894_11_head);
          const Space v896_7 = routine_147(c, v896_6, p1, v894_11_tail);
          v895_8 = compose(v895_5,v896_7);
        }
        const Space v895_9 = intersect(constant_6,v895_2);
        const Space v895_10 = (has_head(v895_9) ? constant_7 : Space{});
        Space v895_12;
        if (!v895_10.empty()) {
          const Path v897_6 = concat_path(v894_6,v894_11_head);
          const Space v897_11 = routine_42(c, v897_6, p1, v894_11_tail);
          v895_12 = compose(v895_10,v897_11);
        }
        const Space v895_13 = unite(v895_8,v895_12);
        v894_11_result = unite(v894_11_result,v895_13);
      }
      const Space v894_11 = std::move(v894_11_result);
      v889_12 = compose(v889_10,v894_11);
    }
    const Space v889_13 = unite(v889_8,v889_12);
    v888_12_result = unite(v888_12_result,v889_13);
  }
  const Space v888_12 = std::move(v888_12_result);
  return v888_12;
}

static Space routine_91(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v898_9_result;
  for (int v898_9_label = 1; v898_9_label <= 2; ++v898_9_label) {
    const Space v898_9_tail = child(s0,v898_9_label);
    if (v898_9_tail.empty()) continue;
    const Path v898_9_head{v898_9_label};
    const Space v899_2 = singleton(v898_9_head);
    const Space v899_3 = intersect(constant_6,v899_2);
    const Space v899_4 = (has_head(v899_3) ? constant_7 : Space{});
    const Space v899_5 = subtract(constant_0,v899_4);
    Space v899_8;
    if (!v899_5.empty()) {
      const Path v900_6 = concat_path(p0,v898_9_head);
      Space v900_7_result;
      for (int v900_7_label = 1; v900_7_label <= 2; ++v900_7_label) {
        const Space v900_7_tail = child(v898_9_tail,v900_7_label);
        if (v900_7_tail.empty()) continue;
        const Path v900_7_head{v900_7_label};
        const Space v901_2 = singleton(v900_7_head);
        const Space v901_3 = intersect(constant_6,v901_2);
        const Space v901_4 = (has_head(v901_3) ? constant_7 : Space{});
        const Space v901_5 = subtract(constant_0,v901_4);
        Space v901_8;
        if (!v901_5.empty()) {
          const Path v902_6 = concat_path(v900_6,v900_7_head);
          const Space v902_7 = routine_147(c, v902_6, p1, v900_7_tail);
          v901_8 = compose(v901_5,v902_7);
        }
        const Space v901_9 = intersect(constant_6,v901_2);
        const Space v901_10 = (has_head(v901_9) ? constant_7 : Space{});
        Space v901_12;
        if (!v901_10.empty()) {
          const Path v903_6 = concat_path(v900_6,v900_7_head);
          const Space v903_11 = routine_148(c, v903_6, p1, v900_7_tail);
          v901_12 = compose(v901_10,v903_11);
        }
        const Space v901_13 = unite(v901_8,v901_12);
        v900_7_result = unite(v900_7_result,v901_13);
      }
      const Space v900_7 = std::move(v900_7_result);
      v899_8 = compose(v899_5,v900_7);
    }
    const Space v899_9 = intersect(constant_6,v899_2);
    const Space v899_10 = (has_head(v899_9) ? constant_7 : Space{});
    Space v899_13;
    if (!v899_10.empty()) {
      const Path v904_6 = concat_path(p0,v898_9_head);
      const Path v904_11 = concat_path(p1,v904_6);
      const Space v904_12 = routine_29(c, v904_11);
      v899_13 = compose(v899_10,v904_12);
    }
    const Space v899_14 = unite(v899_8,v899_13);
    v898_9_result = unite(v898_9_result,v899_14);
  }
  const Space v898_9 = std::move(v898_9_result);
  return v898_9;
}

static Space routine_92(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v905_12_result;
  for (int v905_12_label = 1; v905_12_label <= 2; ++v905_12_label) {
    const Space v905_12_tail = child(s0,v905_12_label);
    if (v905_12_tail.empty()) continue;
    const Path v905_12_head{v905_12_label};
    const Space v906_2 = singleton(v905_12_head);
    const Space v906_3 = intersect(constant_6,v906_2);
    const Space v906_4 = (has_head(v906_3) ? constant_7 : Space{});
    const Space v906_5 = subtract(constant_0,v906_4);
    Space v906_8;
    if (!v906_5.empty()) {
      const Path v907_6 = concat_path(p0,v905_12_head);
      Space v907_7_result;
      for (int v907_7_label = 1; v907_7_label <= 2; ++v907_7_label) {
        const Space v907_7_tail = child(v905_12_tail,v907_7_label);
        if (v907_7_tail.empty()) continue;
        const Path v907_7_head{v907_7_label};
        const Space v908_2 = singleton(v907_7_head);
        const Space v908_3 = intersect(constant_6,v908_2);
        const Space v908_4 = (has_head(v908_3) ? constant_7 : Space{});
        const Space v908_5 = subtract(constant_0,v908_4);
        Space v908_8;
        if (!v908_5.empty()) {
          const Path v909_6 = concat_path(v907_6,v907_7_head);
          const Space v909_7 = routine_149(c, v909_6, p1, v907_7_tail);
          v908_8 = compose(v908_5,v909_7);
        }
        const Space v908_9 = intersect(constant_6,v908_2);
        const Space v908_10 = (has_head(v908_9) ? constant_7 : Space{});
        Space v908_12;
        if (!v908_10.empty()) {
          const Path v910_6 = concat_path(v907_6,v907_7_head);
          const Space v910_11 = routine_150(c, v910_6, p1, v907_7_tail);
          v908_12 = compose(v908_10,v910_11);
        }
        const Space v908_13 = unite(v908_8,v908_12);
        v907_7_result = unite(v907_7_result,v908_13);
      }
      const Space v907_7 = std::move(v907_7_result);
      v906_8 = compose(v906_5,v907_7);
    }
    const Space v906_9 = intersect(constant_6,v906_2);
    const Space v906_10 = (has_head(v906_9) ? constant_7 : Space{});
    Space v906_12;
    if (!v906_10.empty()) {
      const Path v911_6 = concat_path(p0,v905_12_head);
      Space v911_11_result;
      for (int v911_11_label = 1; v911_11_label <= 2; ++v911_11_label) {
        const Space v911_11_tail = child(v905_12_tail,v911_11_label);
        if (v911_11_tail.empty()) continue;
        const Path v911_11_head{v911_11_label};
        const Space v912_2 = singleton(v911_11_head);
        const Space v912_3 = intersect(constant_6,v912_2);
        const Space v912_4 = (has_head(v912_3) ? constant_7 : Space{});
        const Space v912_5 = subtract(constant_0,v912_4);
        Space v912_8;
        if (!v912_5.empty()) {
          const Path v913_6 = concat_path(v911_6,v911_11_head);
          const Space v913_7 = routine_149(c, v913_6, p1, v911_11_tail);
          v912_8 = compose(v912_5,v913_7);
        }
        const Space v912_9 = intersect(constant_6,v912_2);
        const Space v912_10 = (has_head(v912_9) ? constant_7 : Space{});
        Space v912_12;
        if (!v912_10.empty()) {
          const Path v914_6 = concat_path(v911_6,v911_11_head);
          const Space v914_11 = routine_42(c, v914_6, p1, v911_11_tail);
          v912_12 = compose(v912_10,v914_11);
        }
        const Space v912_13 = unite(v912_8,v912_12);
        v911_11_result = unite(v911_11_result,v912_13);
      }
      const Space v911_11 = std::move(v911_11_result);
      v906_12 = compose(v906_10,v911_11);
    }
    const Space v906_13 = unite(v906_8,v906_12);
    v905_12_result = unite(v905_12_result,v906_13);
  }
  const Space v905_12 = std::move(v905_12_result);
  return v905_12;
}

static Space routine_93(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v915_9_result;
  for (int v915_9_label = 1; v915_9_label <= 2; ++v915_9_label) {
    const Space v915_9_tail = child(s0,v915_9_label);
    if (v915_9_tail.empty()) continue;
    const Path v915_9_head{v915_9_label};
    const Space v916_2 = singleton(v915_9_head);
    const Space v916_3 = intersect(constant_6,v916_2);
    const Space v916_4 = (has_head(v916_3) ? constant_7 : Space{});
    const Space v916_5 = subtract(constant_0,v916_4);
    Space v916_8;
    if (!v916_5.empty()) {
      const Path v917_6 = concat_path(p0,v915_9_head);
      Space v917_7_result;
      for (int v917_7_label = 1; v917_7_label <= 2; ++v917_7_label) {
        const Space v917_7_tail = child(v915_9_tail,v917_7_label);
        if (v917_7_tail.empty()) continue;
        const Path v917_7_head{v917_7_label};
        const Space v918_2 = singleton(v917_7_head);
        const Space v918_3 = intersect(constant_6,v918_2);
        const Space v918_4 = (has_head(v918_3) ? constant_7 : Space{});
        const Space v918_5 = subtract(constant_0,v918_4);
        Space v918_8;
        if (!v918_5.empty()) {
          const Path v919_6 = concat_path(v917_6,v917_7_head);
          const Space v919_7 = routine_149(c, v919_6, p1, v917_7_tail);
          v918_8 = compose(v918_5,v919_7);
        }
        const Space v918_9 = intersect(constant_6,v918_2);
        const Space v918_10 = (has_head(v918_9) ? constant_7 : Space{});
        Space v918_12;
        if (!v918_10.empty()) {
          const Path v920_6 = concat_path(v917_6,v917_7_head);
          const Space v920_11 = routine_150(c, v920_6, p1, v917_7_tail);
          v918_12 = compose(v918_10,v920_11);
        }
        const Space v918_13 = unite(v918_8,v918_12);
        v917_7_result = unite(v917_7_result,v918_13);
      }
      const Space v917_7 = std::move(v917_7_result);
      v916_8 = compose(v916_5,v917_7);
    }
    const Space v916_9 = intersect(constant_6,v916_2);
    const Space v916_10 = (has_head(v916_9) ? constant_7 : Space{});
    Space v916_13;
    if (!v916_10.empty()) {
      const Path v921_6 = concat_path(p0,v915_9_head);
      const Path v921_11 = concat_path(p1,v921_6);
      const Space v921_12 = routine_29(c, v921_11);
      v916_13 = compose(v916_10,v921_12);
    }
    const Space v916_14 = unite(v916_8,v916_13);
    v915_9_result = unite(v915_9_result,v916_14);
  }
  const Space v915_9 = std::move(v915_9_result);
  return v915_9;
}

static Space routine_94(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v922_12_result;
  for (int v922_12_label = 1; v922_12_label <= 2; ++v922_12_label) {
    const Space v922_12_tail = child(s0,v922_12_label);
    if (v922_12_tail.empty()) continue;
    const Path v922_12_head{v922_12_label};
    const Space v923_2 = singleton(v922_12_head);
    const Space v923_3 = intersect(constant_6,v923_2);
    const Space v923_4 = (has_head(v923_3) ? constant_7 : Space{});
    const Space v923_5 = subtract(constant_0,v923_4);
    Space v923_8;
    if (!v923_5.empty()) {
      const Path v924_6 = concat_path(p0,v922_12_head);
      Space v924_7_result;
      for (int v924_7_label = 1; v924_7_label <= 2; ++v924_7_label) {
        const Space v924_7_tail = child(v922_12_tail,v924_7_label);
        if (v924_7_tail.empty()) continue;
        const Path v924_7_head{v924_7_label};
        const Space v925_2 = singleton(v924_7_head);
        const Space v925_3 = intersect(constant_6,v925_2);
        const Space v925_4 = (has_head(v925_3) ? constant_7 : Space{});
        const Space v925_5 = subtract(constant_0,v925_4);
        Space v925_8;
        if (!v925_5.empty()) {
          const Path v926_6 = concat_path(v924_6,v924_7_head);
          const Space v926_7 = routine_151(c, v926_6, v924_7_tail, s1);
          v925_8 = compose(v925_5,v926_7);
        }
        const Space v925_9 = intersect(constant_6,v925_2);
        const Space v925_10 = (has_head(v925_9) ? constant_7 : Space{});
        Space v925_12;
        if (!v925_10.empty()) {
          const Path v927_6 = concat_path(v924_6,v924_7_head);
          const Space v927_11 = routine_152(c, v927_6, v924_7_tail, s1);
          v925_12 = compose(v925_10,v927_11);
        }
        const Space v925_13 = unite(v925_8,v925_12);
        v924_7_result = unite(v924_7_result,v925_13);
      }
      const Space v924_7 = std::move(v924_7_result);
      v923_8 = compose(v923_5,v924_7);
    }
    const Space v923_9 = intersect(constant_6,v923_2);
    const Space v923_10 = (has_head(v923_9) ? constant_7 : Space{});
    Space v923_12;
    if (!v923_10.empty()) {
      const Path v928_6 = concat_path(p0,v922_12_head);
      Space v928_11_result;
      for (int v928_11_label = 1; v928_11_label <= 2; ++v928_11_label) {
        const Space v928_11_tail = child(v922_12_tail,v928_11_label);
        if (v928_11_tail.empty()) continue;
        const Path v928_11_head{v928_11_label};
        const Space v929_2 = singleton(v928_11_head);
        const Space v929_3 = intersect(constant_6,v929_2);
        const Space v929_4 = (has_head(v929_3) ? constant_7 : Space{});
        const Space v929_5 = subtract(constant_0,v929_4);
        Space v929_8;
        if (!v929_5.empty()) {
          const Path v930_6 = concat_path(v928_6,v928_11_head);
          const Space v930_7 = routine_151(c, v930_6, v928_11_tail, s1);
          v929_8 = compose(v929_5,v930_7);
        }
        const Space v929_9 = intersect(constant_6,v929_2);
        const Space v929_10 = (has_head(v929_9) ? constant_7 : Space{});
        Space v929_12;
        if (!v929_10.empty()) {
          const Path v931_6 = concat_path(v928_6,v928_11_head);
          const Space v931_11 = routine_19(c, v931_6, v928_11_tail, s1);
          v929_12 = compose(v929_10,v931_11);
        }
        const Space v929_13 = unite(v929_8,v929_12);
        v928_11_result = unite(v928_11_result,v929_13);
      }
      const Space v928_11 = std::move(v928_11_result);
      v923_12 = compose(v923_10,v928_11);
    }
    const Space v923_13 = unite(v923_8,v923_12);
    v922_12_result = unite(v922_12_result,v923_13);
  }
  const Space v922_12 = std::move(v922_12_result);
  return v922_12;
}

static Space routine_95(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v932_12_result;
  for (int v932_12_label = 1; v932_12_label <= 2; ++v932_12_label) {
    const Space v932_12_tail = child(s0,v932_12_label);
    if (v932_12_tail.empty()) continue;
    const Path v932_12_head{v932_12_label};
    const Space v933_2 = singleton(v932_12_head);
    const Space v933_3 = intersect(constant_6,v933_2);
    const Space v933_4 = (has_head(v933_3) ? constant_7 : Space{});
    const Space v933_5 = subtract(constant_0,v933_4);
    Space v933_8;
    if (!v933_5.empty()) {
      const Path v934_6 = concat_path(p0,v932_12_head);
      Space v934_7_result;
      for (int v934_7_label = 1; v934_7_label <= 2; ++v934_7_label) {
        const Space v934_7_tail = child(v932_12_tail,v934_7_label);
        if (v934_7_tail.empty()) continue;
        const Path v934_7_head{v934_7_label};
        const Space v935_2 = singleton(v934_7_head);
        const Space v935_3 = intersect(constant_6,v935_2);
        const Space v935_4 = (has_head(v935_3) ? constant_7 : Space{});
        const Space v935_5 = subtract(constant_0,v935_4);
        Space v935_8;
        if (!v935_5.empty()) {
          const Path v936_6 = concat_path(v934_6,v934_7_head);
          const Space v936_7 = routine_151(c, v936_6, v934_7_tail, s1);
          v935_8 = compose(v935_5,v936_7);
        }
        const Space v935_9 = intersect(constant_6,v935_2);
        const Space v935_10 = (has_head(v935_9) ? constant_7 : Space{});
        Space v935_12;
        if (!v935_10.empty()) {
          const Path v937_6 = concat_path(v934_6,v934_7_head);
          const Space v937_11 = routine_152(c, v937_6, v934_7_tail, s1);
          v935_12 = compose(v935_10,v937_11);
        }
        const Space v935_13 = unite(v935_8,v935_12);
        v934_7_result = unite(v934_7_result,v935_13);
      }
      const Space v934_7 = std::move(v934_7_result);
      v933_8 = compose(v933_5,v934_7);
    }
    const Space v933_9 = intersect(constant_6,v933_2);
    const Space v933_10 = (has_head(v933_9) ? constant_7 : Space{});
    Space v933_12;
    if (!v933_10.empty()) {
      const Path v938_6 = concat_path(p0,v932_12_head);
      Space v938_11_result;
      for (int v938_11_label = 1; v938_11_label <= 2; ++v938_11_label) {
        const Space v938_11_tail = child(v932_12_tail,v938_11_label);
        if (v938_11_tail.empty()) continue;
        const Path v938_11_head{v938_11_label};
        const Space v939_2 = singleton(v938_11_head);
        const Space v939_3 = intersect(constant_6,v939_2);
        const Space v939_4 = (has_head(v939_3) ? constant_7 : Space{});
        const Space v939_5 = subtract(constant_0,v939_4);
        Space v939_7;
        if (!v939_5.empty()) {
          const Space v940_6 = routine_20(c, v938_11_head, v938_6, v938_11_tail, s1);
          v939_7 = compose(v939_5,v940_6);
        }
        const Space v939_8 = intersect(constant_6,v939_2);
        const Space v939_9 = (has_head(v939_8) ? constant_7 : Space{});
        Space v939_11;
        if (!v939_9.empty()) {
          const Space v941_10 = routine_21(c, v938_11_head, v938_6, v938_11_tail, s1);
          v939_11 = compose(v939_9,v941_10);
        }
        const Space v939_12 = unite(v939_7,v939_11);
        v938_11_result = unite(v938_11_result,v939_12);
      }
      const Space v938_11 = std::move(v938_11_result);
      v933_12 = compose(v933_10,v938_11);
    }
    const Space v933_13 = unite(v933_8,v933_12);
    v932_12_result = unite(v932_12_result,v933_13);
  }
  const Space v932_12 = std::move(v932_12_result);
  return v932_12;
}

static Space routine_96(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v942_13_result;
  for (int v942_13_label = 1; v942_13_label <= 2; ++v942_13_label) {
    const Space v942_13_tail = child(s0,v942_13_label);
    if (v942_13_tail.empty()) continue;
    const Path v942_13_head{v942_13_label};
    const Space v943_2 = singleton(v942_13_head);
    const Space v943_3 = intersect(constant_6,v943_2);
    const Space v943_4 = (has_head(v943_3) ? constant_7 : Space{});
    const Space v943_5 = subtract(constant_0,v943_4);
    Space v943_8;
    if (!v943_5.empty()) {
      const Path v944_6 = concat_path(p0,v942_13_head);
      Space v944_7_result;
      for (int v944_7_label = 1; v944_7_label <= 2; ++v944_7_label) {
        const Space v944_7_tail = child(v942_13_tail,v944_7_label);
        if (v944_7_tail.empty()) continue;
        const Path v944_7_head{v944_7_label};
        const Space v945_2 = singleton(v944_7_head);
        const Space v945_3 = intersect(constant_6,v945_2);
        const Space v945_4 = (has_head(v945_3) ? constant_7 : Space{});
        const Space v945_5 = subtract(constant_0,v945_4);
        Space v945_8;
        if (!v945_5.empty()) {
          const Path v946_6 = concat_path(v944_6,v944_7_head);
          const Space v946_7 = routine_153(c, v946_6, p1, v944_7_tail, s1);
          v945_8 = compose(v945_5,v946_7);
        }
        const Space v945_9 = intersect(constant_6,v945_2);
        const Space v945_10 = (has_head(v945_9) ? constant_7 : Space{});
        Space v945_12;
        if (!v945_10.empty()) {
          const Path v947_6 = concat_path(v944_6,v944_7_head);
          const Space v947_11 = routine_154(c, v947_6, p1, v944_7_tail, s1);
          v945_12 = compose(v945_10,v947_11);
        }
        const Space v945_13 = unite(v945_8,v945_12);
        v944_7_result = unite(v944_7_result,v945_13);
      }
      const Space v944_7 = std::move(v944_7_result);
      v943_8 = compose(v943_5,v944_7);
    }
    const Space v943_9 = intersect(constant_6,v943_2);
    const Space v943_10 = (has_head(v943_9) ? constant_7 : Space{});
    Space v943_12;
    if (!v943_10.empty()) {
      const Path v948_6 = concat_path(p0,v942_13_head);
      Space v948_11_result;
      for (int v948_11_label = 1; v948_11_label <= 2; ++v948_11_label) {
        const Space v948_11_tail = child(v942_13_tail,v948_11_label);
        if (v948_11_tail.empty()) continue;
        const Path v948_11_head{v948_11_label};
        const Space v949_2 = singleton(v948_11_head);
        const Space v949_3 = intersect(constant_6,v949_2);
        const Space v949_4 = (has_head(v949_3) ? constant_7 : Space{});
        const Space v949_5 = subtract(constant_0,v949_4);
        Space v949_8;
        if (!v949_5.empty()) {
          const Path v950_6 = concat_path(v948_6,v948_11_head);
          const Space v950_7 = routine_153(c, v950_6, p1, v948_11_tail, s1);
          v949_8 = compose(v949_5,v950_7);
        }
        const Space v949_9 = intersect(constant_6,v949_2);
        const Space v949_10 = (has_head(v949_9) ? constant_7 : Space{});
        Space v949_12;
        if (!v949_10.empty()) {
          const Path v951_6 = concat_path(v948_6,v948_11_head);
          const Space v951_11 = routine_49(c, v951_6, p1, v948_11_tail, s1);
          v949_12 = compose(v949_10,v951_11);
        }
        const Space v949_13 = unite(v949_8,v949_12);
        v948_11_result = unite(v948_11_result,v949_13);
      }
      const Space v948_11 = std::move(v948_11_result);
      v943_12 = compose(v943_10,v948_11);
    }
    const Space v943_13 = unite(v943_8,v943_12);
    v942_13_result = unite(v942_13_result,v943_13);
  }
  const Space v942_13 = std::move(v942_13_result);
  return v942_13;
}

static Space routine_97(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v952_8 = unwrap(s1,constant_8);
  Space v952_21_result;
  for (int v952_21_label = 1; v952_21_label <= 2; ++v952_21_label) {
    const Space v952_21_tail = child(s0,v952_21_label);
    if (v952_21_tail.empty()) continue;
    const Path v952_21_head{v952_21_label};
    const Space v953_2 = singleton(v952_21_head);
    const Space v953_3 = intersect(constant_6,v953_2);
    const Space v953_4 = (has_head(v953_3) ? constant_7 : Space{});
    const Space v953_5 = subtract(constant_0,v953_4);
    Space v953_8;
    if (!v953_5.empty()) {
      const Path v954_6 = concat_path(p0,v952_21_head);
      Space v954_7_result;
      for (int v954_7_label = 1; v954_7_label <= 2; ++v954_7_label) {
        const Space v954_7_tail = child(v952_21_tail,v954_7_label);
        if (v954_7_tail.empty()) continue;
        const Path v954_7_head{v954_7_label};
        const Space v955_2 = singleton(v954_7_head);
        const Space v955_3 = intersect(constant_6,v955_2);
        const Space v955_4 = (has_head(v955_3) ? constant_7 : Space{});
        const Space v955_5 = subtract(constant_0,v955_4);
        Space v955_8;
        if (!v955_5.empty()) {
          const Path v956_6 = concat_path(v954_6,v954_7_head);
          const Space v956_7 = routine_153(c, v956_6, p1, v954_7_tail, s1);
          v955_8 = compose(v955_5,v956_7);
        }
        const Space v955_9 = intersect(constant_6,v955_2);
        const Space v955_10 = (has_head(v955_9) ? constant_7 : Space{});
        Space v955_12;
        if (!v955_10.empty()) {
          const Path v957_6 = concat_path(v954_6,v954_7_head);
          const Space v957_11 = routine_154(c, v957_6, p1, v954_7_tail, s1);
          v955_12 = compose(v955_10,v957_11);
        }
        const Space v955_13 = unite(v955_8,v955_12);
        v954_7_result = unite(v954_7_result,v955_13);
      }
      const Space v954_7 = std::move(v954_7_result);
      v953_8 = compose(v953_5,v954_7);
    }
    const Space v953_9 = intersect(constant_6,v953_2);
    const Space v953_10 = (has_head(v953_9) ? constant_7 : Space{});
    Space v953_22;
    if (!v953_10.empty()) {
      const Path v958_6 = concat_path(p0,v952_21_head);
      const Path v958_11 = concat_path(p1,v958_6);
      const Space v958_12 = routine_29(c, v958_11);
      const Space v958_13 = intersect(v952_8,v958_12);
      const Space v958_14 = routine_33(c, v958_13);
      Space v958_15_result;
      for (int v958_15_label = 1; v958_15_label <= 2; ++v958_15_label) {
        const Space v958_15_tail = child(v958_14,v958_15_label);
        if (v958_15_tail.empty()) continue;
        const Path v958_15_head{v958_15_label};
        const Space v959_2 = singleton(v958_15_head);
        const Space v959_3 = intersect(constant_6,v959_2);
        const Space v959_4 = (has_head(v959_3) ? constant_7 : Space{});
        const Space v959_5 = subtract(constant_0,v959_4);
        Space v959_7;
        if (!v959_5.empty()) {
          const Space v960_6 = routine_52(c, v958_15_head, v958_15_tail);
          v959_7 = compose(v959_5,v960_6);
        }
        const Space v959_8 = intersect(constant_6,v959_2);
        const Space v959_9 = (has_head(v959_8) ? constant_7 : Space{});
        Space v959_11;
        if (!v959_9.empty()) {
          const Space v961_10 = routine_53(c, v958_15_head, v958_15_tail);
          v959_11 = compose(v959_9,v961_10);
        }
        const Space v959_12 = unite(v959_7,v959_11);
        v958_15_result = unite(v958_15_result,v959_12);
      }
      const Space v958_15 = std::move(v958_15_result);
      const Space v958_16 = routine_54(c, v958_13);
      Space v958_17_result;
      for (int v958_17_label = 1; v958_17_label <= 2; ++v958_17_label) {
        const Space v958_17_tail = child(v958_16,v958_17_label);
        if (v958_17_tail.empty()) continue;
        const Path v958_17_head{v958_17_label};
        const Space v962_2 = singleton(v958_17_head);
        const Space v962_3 = intersect(constant_6,v962_2);
        const Space v962_4 = (has_head(v962_3) ? constant_7 : Space{});
        const Space v962_5 = subtract(constant_0,v962_4);
        Space v962_7;
        if (!v962_5.empty()) {
          const Space v963_6 = routine_55(c, v958_17_head, v958_17_tail);
          v962_7 = compose(v962_5,v963_6);
        }
        const Space v962_8 = intersect(constant_6,v962_2);
        const Space v962_9 = (has_head(v962_8) ? constant_7 : Space{});
        Space v962_11;
        if (!v962_9.empty()) {
          const Space v964_10 = routine_56(c, v958_17_head, v958_17_tail);
          v962_11 = compose(v962_9,v964_10);
        }
        const Space v962_12 = unite(v962_7,v962_11);
        v958_17_result = unite(v958_17_result,v962_12);
      }
      const Space v958_17 = std::move(v958_17_result);
      const Space v958_18 = subtract(v958_15,v958_17);
      const Space v958_19 = singleton(v958_11);
      const Space v958_20 = compose(v958_18,v958_19);
      Space v958_21_result;
      for (int v958_21_label = 1; v958_21_label <= 2; ++v958_21_label) {
        const Space v958_21_tail = child(v958_20,v958_21_label);
        if (v958_21_tail.empty()) continue;
        const Path v958_21_head{v958_21_label};
        const Space v965_2 = singleton(v958_21_head);
        const Space v965_3 = intersect(constant_6,v965_2);
        const Space v965_4 = (has_head(v965_3) ? constant_7 : Space{});
        const Space v965_5 = subtract(constant_0,v965_4);
        Space v965_7;
        if (!v965_5.empty()) {
          const Space v966_6 = routine_57(c, v958_21_head, v958_21_tail);
          v965_7 = compose(v965_5,v966_6);
        }
        const Space v965_8 = intersect(constant_6,v965_2);
        const Space v965_9 = (has_head(v965_8) ? constant_7 : Space{});
        Space v965_11;
        if (!v965_9.empty()) {
          const Space v967_10 = routine_58(c, v958_21_head, v958_21_tail);
          v965_11 = compose(v965_9,v967_10);
        }
        const Space v965_12 = unite(v965_7,v965_11);
        v958_21_result = unite(v958_21_result,v965_12);
      }
      const Space v958_21 = std::move(v958_21_result);
      v953_22 = compose(v953_10,v958_21);
    }
    const Space v953_23 = unite(v953_8,v953_22);
    v952_21_result = unite(v952_21_result,v953_23);
  }
  const Space v952_21 = std::move(v952_21_result);
  return v952_21;
}

static Space routine_98(Context& c, const Path& p0, const Space& s0) {
  Space v968_11_result;
  for (int v968_11_label = 1; v968_11_label <= 2; ++v968_11_label) {
    const Space v968_11_tail = child(s0,v968_11_label);
    if (v968_11_tail.empty()) continue;
    const Path v968_11_head{v968_11_label};
    const Space v969_2 = singleton(v968_11_head);
    const Space v969_3 = intersect(constant_6,v969_2);
    const Space v969_4 = (has_head(v969_3) ? constant_7 : Space{});
    const Space v969_5 = subtract(constant_0,v969_4);
    Space v969_8;
    if (!v969_5.empty()) {
      const Path v970_6 = concat_path(p0,v968_11_head);
      Space v970_7_result;
      for (int v970_7_label = 1; v970_7_label <= 2; ++v970_7_label) {
        const Space v970_7_tail = child(v968_11_tail,v970_7_label);
        if (v970_7_tail.empty()) continue;
        const Path v970_7_head{v970_7_label};
        const Space v971_2 = singleton(v970_7_head);
        const Space v971_3 = intersect(constant_6,v971_2);
        const Space v971_4 = (has_head(v971_3) ? constant_7 : Space{});
        const Space v971_5 = subtract(constant_0,v971_4);
        Space v971_8;
        if (!v971_5.empty()) {
          const Path v972_6 = concat_path(v970_6,v970_7_head);
          const Space v972_7 = routine_155(c, v972_6, v970_7_tail);
          v971_8 = compose(v971_5,v972_7);
        }
        const Space v971_9 = intersect(constant_6,v971_2);
        const Space v971_10 = (has_head(v971_9) ? constant_7 : Space{});
        Space v971_12;
        if (!v971_10.empty()) {
          const Path v973_6 = concat_path(v970_6,v970_7_head);
          const Space v973_11 = routine_156(c, v973_6, v970_7_tail);
          v971_12 = compose(v971_10,v973_11);
        }
        const Space v971_13 = unite(v971_8,v971_12);
        v970_7_result = unite(v970_7_result,v971_13);
      }
      const Space v970_7 = std::move(v970_7_result);
      v969_8 = compose(v969_5,v970_7);
    }
    const Space v969_9 = intersect(constant_6,v969_2);
    const Space v969_10 = (has_head(v969_9) ? constant_7 : Space{});
    Space v969_12;
    if (!v969_10.empty()) {
      const Path v974_6 = concat_path(p0,v968_11_head);
      Space v974_11_result;
      for (int v974_11_label = 1; v974_11_label <= 2; ++v974_11_label) {
        const Space v974_11_tail = child(v968_11_tail,v974_11_label);
        if (v974_11_tail.empty()) continue;
        const Path v974_11_head{v974_11_label};
        const Space v975_2 = singleton(v974_11_head);
        const Space v975_3 = intersect(constant_6,v975_2);
        const Space v975_4 = (has_head(v975_3) ? constant_7 : Space{});
        const Space v975_5 = subtract(constant_0,v975_4);
        Space v975_8;
        if (!v975_5.empty()) {
          const Path v976_6 = concat_path(v974_6,v974_11_head);
          const Space v976_7 = routine_155(c, v976_6, v974_11_tail);
          v975_8 = compose(v975_5,v976_7);
        }
        const Space v975_9 = intersect(constant_6,v975_2);
        const Space v975_10 = (has_head(v975_9) ? constant_7 : Space{});
        Space v975_12;
        if (!v975_10.empty()) {
          const Path v977_6 = concat_path(v974_6,v974_11_head);
          const Space v977_11 = routine_100(c, v977_6, v974_11_tail);
          v975_12 = compose(v975_10,v977_11);
        }
        const Space v975_13 = unite(v975_8,v975_12);
        v974_11_result = unite(v974_11_result,v975_13);
      }
      const Space v974_11 = std::move(v974_11_result);
      v969_12 = compose(v969_10,v974_11);
    }
    const Space v969_13 = unite(v969_8,v969_12);
    v968_11_result = unite(v968_11_result,v969_13);
  }
  const Space v968_11 = std::move(v968_11_result);
  return v968_11;
}

static Space routine_99(Context& c, const Path& p0, const Space& s0) {
  Space v978_9_result;
  for (int v978_9_label = 1; v978_9_label <= 2; ++v978_9_label) {
    const Space v978_9_tail = child(s0,v978_9_label);
    if (v978_9_tail.empty()) continue;
    const Path v978_9_head{v978_9_label};
    const Space v979_2 = singleton(v978_9_head);
    const Space v979_3 = intersect(constant_6,v979_2);
    const Space v979_4 = (has_head(v979_3) ? constant_7 : Space{});
    const Space v979_5 = subtract(constant_0,v979_4);
    Space v979_8;
    if (!v979_5.empty()) {
      const Path v980_6 = concat_path(p0,v978_9_head);
      Space v980_7_result;
      for (int v980_7_label = 1; v980_7_label <= 2; ++v980_7_label) {
        const Space v980_7_tail = child(v978_9_tail,v980_7_label);
        if (v980_7_tail.empty()) continue;
        const Path v980_7_head{v980_7_label};
        const Space v981_2 = singleton(v980_7_head);
        const Space v981_3 = intersect(constant_6,v981_2);
        const Space v981_4 = (has_head(v981_3) ? constant_7 : Space{});
        const Space v981_5 = subtract(constant_0,v981_4);
        Space v981_8;
        if (!v981_5.empty()) {
          const Path v982_6 = concat_path(v980_6,v980_7_head);
          const Space v982_7 = routine_155(c, v982_6, v980_7_tail);
          v981_8 = compose(v981_5,v982_7);
        }
        const Space v981_9 = intersect(constant_6,v981_2);
        const Space v981_10 = (has_head(v981_9) ? constant_7 : Space{});
        Space v981_12;
        if (!v981_10.empty()) {
          const Path v983_6 = concat_path(v980_6,v980_7_head);
          const Space v983_11 = routine_156(c, v983_6, v980_7_tail);
          v981_12 = compose(v981_10,v983_11);
        }
        const Space v981_13 = unite(v981_8,v981_12);
        v980_7_result = unite(v980_7_result,v981_13);
      }
      const Space v980_7 = std::move(v980_7_result);
      v979_8 = compose(v979_5,v980_7);
    }
    const Space v979_9 = intersect(constant_6,v979_2);
    const Space v979_10 = (has_head(v979_9) ? constant_7 : Space{});
    const Space v979_11 = compose(v979_10,constant_9);
    const Space v979_12 = unite(v979_8,v979_11);
    v978_9_result = unite(v978_9_result,v979_12);
  }
  const Space v978_9 = std::move(v978_9_result);
  return v978_9;
}

static Space routine_100(Context& c, const Path& p0, const Space& s0) {
  return constant_9;
}

static Space routine_101(Context& c, const Space& s0) {
  const Space v985_1 = (has_head(s0) ? constant_7 : Space{});
  const Space v985_2 = first_matching(s0,constant_0,false);
  const Space v985_3 = unite(v985_1,v985_2);
  Space v985_13;
  if (!v985_3.empty()) {
    Space v986_6;
    if (!v985_3.empty()) {
      const Space v987_4 = routine_66(c, s0);
      const Space v987_5 = routine_66(c, v987_4);
      v986_6 = compose(v985_3,v987_5);
    }
    const Space v986_7 = (has_head(v986_6) ? constant_7 : Space{});
    const Space v986_8 = first_matching(v986_6,constant_0,false);
    const Space v986_9 = unite(v986_7,v986_8);
    Space v986_12;
    if (!v986_9.empty()) {
      const Space v988_10 = routine_66(c, v986_6);
      const Space v988_11 = routine_66(c, v988_10);
      v986_12 = compose(v986_9,v988_11);
    }
    v985_13 = compose(v985_3,v986_12);
  }
  return v985_13;
}

static Space routine_102(Context& c, const Path& p0, const Space& s0) {
  Space v989_11_result;
  for (int v989_11_label = 1; v989_11_label <= 2; ++v989_11_label) {
    const Space v989_11_tail = child(s0,v989_11_label);
    if (v989_11_tail.empty()) continue;
    const Path v989_11_head{v989_11_label};
    const Space v990_2 = singleton(v989_11_head);
    const Space v990_3 = intersect(constant_6,v990_2);
    const Space v990_4 = (has_head(v990_3) ? constant_7 : Space{});
    const Space v990_5 = subtract(constant_0,v990_4);
    Space v990_8;
    if (!v990_5.empty()) {
      const Path v991_6 = concat_path(p0,v989_11_head);
      Space v991_7_result;
      for (int v991_7_label = 1; v991_7_label <= 2; ++v991_7_label) {
        const Space v991_7_tail = child(v989_11_tail,v991_7_label);
        if (v991_7_tail.empty()) continue;
        const Path v991_7_head{v991_7_label};
        const Space v992_2 = singleton(v991_7_head);
        const Space v992_3 = intersect(constant_6,v992_2);
        const Space v992_4 = (has_head(v992_3) ? constant_7 : Space{});
        const Space v992_5 = subtract(constant_0,v992_4);
        Space v992_8;
        if (!v992_5.empty()) {
          const Path v993_6 = concat_path(v991_6,v991_7_head);
          const Space v993_7 = routine_157(c, v993_6, v991_7_tail);
          v992_8 = compose(v992_5,v993_7);
        }
        const Space v992_9 = intersect(constant_6,v992_2);
        const Space v992_10 = (has_head(v992_9) ? constant_7 : Space{});
        Space v992_12;
        if (!v992_10.empty()) {
          const Path v994_6 = concat_path(v991_6,v991_7_head);
          const Space v994_11 = routine_158(c, v994_6, v991_7_tail);
          v992_12 = compose(v992_10,v994_11);
        }
        const Space v992_13 = unite(v992_8,v992_12);
        v991_7_result = unite(v991_7_result,v992_13);
      }
      const Space v991_7 = std::move(v991_7_result);
      v990_8 = compose(v990_5,v991_7);
    }
    const Space v990_9 = intersect(constant_6,v990_2);
    const Space v990_10 = (has_head(v990_9) ? constant_7 : Space{});
    Space v990_12;
    if (!v990_10.empty()) {
      const Path v995_6 = concat_path(p0,v989_11_head);
      Space v995_11_result;
      for (int v995_11_label = 1; v995_11_label <= 2; ++v995_11_label) {
        const Space v995_11_tail = child(v989_11_tail,v995_11_label);
        if (v995_11_tail.empty()) continue;
        const Path v995_11_head{v995_11_label};
        const Space v996_2 = singleton(v995_11_head);
        const Space v996_3 = intersect(constant_6,v996_2);
        const Space v996_4 = (has_head(v996_3) ? constant_7 : Space{});
        const Space v996_5 = subtract(constant_0,v996_4);
        Space v996_8;
        if (!v996_5.empty()) {
          const Path v997_6 = concat_path(v995_6,v995_11_head);
          const Space v997_7 = routine_157(c, v997_6, v995_11_tail);
          v996_8 = compose(v996_5,v997_7);
        }
        const Space v996_9 = intersect(constant_6,v996_2);
        const Space v996_10 = (has_head(v996_9) ? constant_7 : Space{});
        Space v996_12;
        if (!v996_10.empty()) {
          const Path v998_6 = concat_path(v995_6,v995_11_head);
          const Space v998_11 = routine_104(c, v998_6, v995_11_tail);
          v996_12 = compose(v996_10,v998_11);
        }
        const Space v996_13 = unite(v996_8,v996_12);
        v995_11_result = unite(v995_11_result,v996_13);
      }
      const Space v995_11 = std::move(v995_11_result);
      v990_12 = compose(v990_10,v995_11);
    }
    const Space v990_13 = unite(v990_8,v990_12);
    v989_11_result = unite(v989_11_result,v990_13);
  }
  const Space v989_11 = std::move(v989_11_result);
  return v989_11;
}

static Space routine_103(Context& c, const Path& p0, const Space& s0) {
  Space v999_9_result;
  for (int v999_9_label = 1; v999_9_label <= 2; ++v999_9_label) {
    const Space v999_9_tail = child(s0,v999_9_label);
    if (v999_9_tail.empty()) continue;
    const Path v999_9_head{v999_9_label};
    const Space v1000_2 = singleton(v999_9_head);
    const Space v1000_3 = intersect(constant_6,v1000_2);
    const Space v1000_4 = (has_head(v1000_3) ? constant_7 : Space{});
    const Space v1000_5 = subtract(constant_0,v1000_4);
    Space v1000_8;
    if (!v1000_5.empty()) {
      const Path v1001_6 = concat_path(p0,v999_9_head);
      Space v1001_7_result;
      for (int v1001_7_label = 1; v1001_7_label <= 2; ++v1001_7_label) {
        const Space v1001_7_tail = child(v999_9_tail,v1001_7_label);
        if (v1001_7_tail.empty()) continue;
        const Path v1001_7_head{v1001_7_label};
        const Space v1002_2 = singleton(v1001_7_head);
        const Space v1002_3 = intersect(constant_6,v1002_2);
        const Space v1002_4 = (has_head(v1002_3) ? constant_7 : Space{});
        const Space v1002_5 = subtract(constant_0,v1002_4);
        Space v1002_8;
        if (!v1002_5.empty()) {
          const Path v1003_6 = concat_path(v1001_6,v1001_7_head);
          const Space v1003_7 = routine_157(c, v1003_6, v1001_7_tail);
          v1002_8 = compose(v1002_5,v1003_7);
        }
        const Space v1002_9 = intersect(constant_6,v1002_2);
        const Space v1002_10 = (has_head(v1002_9) ? constant_7 : Space{});
        Space v1002_12;
        if (!v1002_10.empty()) {
          const Path v1004_6 = concat_path(v1001_6,v1001_7_head);
          const Space v1004_11 = routine_158(c, v1004_6, v1001_7_tail);
          v1002_12 = compose(v1002_10,v1004_11);
        }
        const Space v1002_13 = unite(v1002_8,v1002_12);
        v1001_7_result = unite(v1001_7_result,v1002_13);
      }
      const Space v1001_7 = std::move(v1001_7_result);
      v1000_8 = compose(v1000_5,v1001_7);
    }
    const Space v1000_9 = intersect(constant_6,v1000_2);
    const Space v1000_10 = (has_head(v1000_9) ? constant_7 : Space{});
    const Space v1000_11 = compose(v1000_10,constant_9);
    const Space v1000_12 = unite(v1000_8,v1000_11);
    v999_9_result = unite(v999_9_result,v1000_12);
  }
  const Space v999_9 = std::move(v999_9_result);
  return v999_9;
}

static Space routine_104(Context& c, const Path& p0, const Space& s0) {
  return constant_9;
}

static Space routine_105(Context& c, const Path& p0, const Space& s0) {
  Space v1006_11_result;
  for (int v1006_11_label = 1; v1006_11_label <= 2; ++v1006_11_label) {
    const Space v1006_11_tail = child(s0,v1006_11_label);
    if (v1006_11_tail.empty()) continue;
    const Path v1006_11_head{v1006_11_label};
    const Space v1007_2 = singleton(v1006_11_head);
    const Space v1007_3 = intersect(constant_6,v1007_2);
    const Space v1007_4 = (has_head(v1007_3) ? constant_7 : Space{});
    const Space v1007_5 = subtract(constant_0,v1007_4);
    Space v1007_8;
    if (!v1007_5.empty()) {
      const Path v1008_6 = concat_path(p0,v1006_11_head);
      Space v1008_7_result;
      for (int v1008_7_label = 1; v1008_7_label <= 2; ++v1008_7_label) {
        const Space v1008_7_tail = child(v1006_11_tail,v1008_7_label);
        if (v1008_7_tail.empty()) continue;
        const Path v1008_7_head{v1008_7_label};
        const Space v1009_2 = singleton(v1008_7_head);
        const Space v1009_3 = intersect(constant_6,v1009_2);
        const Space v1009_4 = (has_head(v1009_3) ? constant_7 : Space{});
        const Space v1009_5 = subtract(constant_0,v1009_4);
        Space v1009_8;
        if (!v1009_5.empty()) {
          const Path v1010_6 = concat_path(v1008_6,v1008_7_head);
          const Space v1010_7 = routine_159(c, v1010_6, v1008_7_tail);
          v1009_8 = compose(v1009_5,v1010_7);
        }
        const Space v1009_9 = intersect(constant_6,v1009_2);
        const Space v1009_10 = (has_head(v1009_9) ? constant_7 : Space{});
        Space v1009_12;
        if (!v1009_10.empty()) {
          const Path v1011_6 = concat_path(v1008_6,v1008_7_head);
          const Space v1011_11 = routine_160(c, v1011_6, v1008_7_tail);
          v1009_12 = compose(v1009_10,v1011_11);
        }
        const Space v1009_13 = unite(v1009_8,v1009_12);
        v1008_7_result = unite(v1008_7_result,v1009_13);
      }
      const Space v1008_7 = std::move(v1008_7_result);
      v1007_8 = compose(v1007_5,v1008_7);
    }
    const Space v1007_9 = intersect(constant_6,v1007_2);
    const Space v1007_10 = (has_head(v1007_9) ? constant_7 : Space{});
    Space v1007_12;
    if (!v1007_10.empty()) {
      const Path v1012_6 = concat_path(p0,v1006_11_head);
      Space v1012_11_result;
      for (int v1012_11_label = 1; v1012_11_label <= 2; ++v1012_11_label) {
        const Space v1012_11_tail = child(v1006_11_tail,v1012_11_label);
        if (v1012_11_tail.empty()) continue;
        const Path v1012_11_head{v1012_11_label};
        const Space v1013_2 = singleton(v1012_11_head);
        const Space v1013_3 = intersect(constant_6,v1013_2);
        const Space v1013_4 = (has_head(v1013_3) ? constant_7 : Space{});
        const Space v1013_5 = subtract(constant_0,v1013_4);
        Space v1013_8;
        if (!v1013_5.empty()) {
          const Path v1014_6 = concat_path(v1012_6,v1012_11_head);
          const Space v1014_7 = routine_159(c, v1014_6, v1012_11_tail);
          v1013_8 = compose(v1013_5,v1014_7);
        }
        const Space v1013_9 = intersect(constant_6,v1013_2);
        const Space v1013_10 = (has_head(v1013_9) ? constant_7 : Space{});
        Space v1013_12;
        if (!v1013_10.empty()) {
          const Path v1015_6 = concat_path(v1012_6,v1012_11_head);
          const Space v1015_11 = routine_107(c, v1015_6, v1012_11_tail);
          v1013_12 = compose(v1013_10,v1015_11);
        }
        const Space v1013_13 = unite(v1013_8,v1013_12);
        v1012_11_result = unite(v1012_11_result,v1013_13);
      }
      const Space v1012_11 = std::move(v1012_11_result);
      v1007_12 = compose(v1007_10,v1012_11);
    }
    const Space v1007_13 = unite(v1007_8,v1007_12);
    v1006_11_result = unite(v1006_11_result,v1007_13);
  }
  const Space v1006_11 = std::move(v1006_11_result);
  return v1006_11;
}

static Space routine_106(Context& c, const Path& p0, const Space& s0) {
  Space v1016_8_result;
  for (int v1016_8_label = 1; v1016_8_label <= 2; ++v1016_8_label) {
    const Space v1016_8_tail = child(s0,v1016_8_label);
    if (v1016_8_tail.empty()) continue;
    const Path v1016_8_head{v1016_8_label};
    const Space v1017_2 = singleton(v1016_8_head);
    const Space v1017_3 = intersect(constant_6,v1017_2);
    const Space v1017_4 = (has_head(v1017_3) ? constant_7 : Space{});
    const Space v1017_5 = subtract(constant_0,v1017_4);
    Space v1017_8;
    if (!v1017_5.empty()) {
      const Path v1018_6 = concat_path(p0,v1016_8_head);
      Space v1018_7_result;
      for (int v1018_7_label = 1; v1018_7_label <= 2; ++v1018_7_label) {
        const Space v1018_7_tail = child(v1016_8_tail,v1018_7_label);
        if (v1018_7_tail.empty()) continue;
        const Path v1018_7_head{v1018_7_label};
        const Space v1019_2 = singleton(v1018_7_head);
        const Space v1019_3 = intersect(constant_6,v1019_2);
        const Space v1019_4 = (has_head(v1019_3) ? constant_7 : Space{});
        const Space v1019_5 = subtract(constant_0,v1019_4);
        Space v1019_8;
        if (!v1019_5.empty()) {
          const Path v1020_6 = concat_path(v1018_6,v1018_7_head);
          const Space v1020_7 = routine_159(c, v1020_6, v1018_7_tail);
          v1019_8 = compose(v1019_5,v1020_7);
        }
        const Space v1019_9 = intersect(constant_6,v1019_2);
        const Space v1019_10 = (has_head(v1019_9) ? constant_7 : Space{});
        Space v1019_12;
        if (!v1019_10.empty()) {
          const Path v1021_6 = concat_path(v1018_6,v1018_7_head);
          const Space v1021_11 = routine_160(c, v1021_6, v1018_7_tail);
          v1019_12 = compose(v1019_10,v1021_11);
        }
        const Space v1019_13 = unite(v1019_8,v1019_12);
        v1018_7_result = unite(v1018_7_result,v1019_13);
      }
      const Space v1018_7 = std::move(v1018_7_result);
      v1017_8 = compose(v1017_5,v1018_7);
    }
    const Space v1017_9 = intersect(constant_6,v1017_2);
    const Space v1017_10 = (has_head(v1017_9) ? constant_7 : Space{});
    const Space v1017_11 = compose(v1017_10,v1016_8_tail);
    const Space v1017_12 = unite(v1017_8,v1017_11);
    v1016_8_result = unite(v1016_8_result,v1017_12);
  }
  const Space v1016_8 = std::move(v1016_8_result);
  return v1016_8;
}

static Space routine_107(Context& c, const Path& p0, const Space& s0) {
  return s0;
}

static Space routine_108(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1023_13_result;
  for (int v1023_13_label = 1; v1023_13_label <= 2; ++v1023_13_label) {
    const Space v1023_13_tail = child(s0,v1023_13_label);
    if (v1023_13_tail.empty()) continue;
    const Path v1023_13_head{v1023_13_label};
    const Space v1024_2 = singleton(v1023_13_head);
    const Space v1024_3 = intersect(constant_6,v1024_2);
    const Space v1024_4 = (has_head(v1024_3) ? constant_7 : Space{});
    const Space v1024_5 = subtract(constant_0,v1024_4);
    Space v1024_8;
    if (!v1024_5.empty()) {
      const Path v1025_6 = concat_path(p0,v1023_13_head);
      Space v1025_7_result;
      for (int v1025_7_label = 1; v1025_7_label <= 2; ++v1025_7_label) {
        const Space v1025_7_tail = child(v1023_13_tail,v1025_7_label);
        if (v1025_7_tail.empty()) continue;
        const Path v1025_7_head{v1025_7_label};
        const Space v1026_2 = singleton(v1025_7_head);
        const Space v1026_3 = intersect(constant_6,v1026_2);
        const Space v1026_4 = (has_head(v1026_3) ? constant_7 : Space{});
        const Space v1026_5 = subtract(constant_0,v1026_4);
        Space v1026_8;
        if (!v1026_5.empty()) {
          const Path v1027_6 = concat_path(v1025_6,v1025_7_head);
          const Space v1027_7 = routine_161(c, v1027_6, p1, v1025_7_tail, s1);
          v1026_8 = compose(v1026_5,v1027_7);
        }
        const Space v1026_9 = intersect(constant_6,v1026_2);
        const Space v1026_10 = (has_head(v1026_9) ? constant_7 : Space{});
        Space v1026_12;
        if (!v1026_10.empty()) {
          const Path v1028_6 = concat_path(v1025_6,v1025_7_head);
          const Space v1028_11 = routine_162(c, v1028_6, p1, v1025_7_tail, s1);
          v1026_12 = compose(v1026_10,v1028_11);
        }
        const Space v1026_13 = unite(v1026_8,v1026_12);
        v1025_7_result = unite(v1025_7_result,v1026_13);
      }
      const Space v1025_7 = std::move(v1025_7_result);
      v1024_8 = compose(v1024_5,v1025_7);
    }
    const Space v1024_9 = intersect(constant_6,v1024_2);
    const Space v1024_10 = (has_head(v1024_9) ? constant_7 : Space{});
    Space v1024_12;
    if (!v1024_10.empty()) {
      const Path v1029_6 = concat_path(p0,v1023_13_head);
      Space v1029_11_result;
      for (int v1029_11_label = 1; v1029_11_label <= 2; ++v1029_11_label) {
        const Space v1029_11_tail = child(v1023_13_tail,v1029_11_label);
        if (v1029_11_tail.empty()) continue;
        const Path v1029_11_head{v1029_11_label};
        const Space v1030_2 = singleton(v1029_11_head);
        const Space v1030_3 = intersect(constant_6,v1030_2);
        const Space v1030_4 = (has_head(v1030_3) ? constant_7 : Space{});
        const Space v1030_5 = subtract(constant_0,v1030_4);
        Space v1030_8;
        if (!v1030_5.empty()) {
          const Path v1031_6 = concat_path(v1029_6,v1029_11_head);
          const Space v1031_7 = routine_161(c, v1031_6, p1, v1029_11_tail, s1);
          v1030_8 = compose(v1030_5,v1031_7);
        }
        const Space v1030_9 = intersect(constant_6,v1030_2);
        const Space v1030_10 = (has_head(v1030_9) ? constant_7 : Space{});
        Space v1030_12;
        if (!v1030_10.empty()) {
          const Path v1032_6 = concat_path(v1029_6,v1029_11_head);
          const Space v1032_11 = routine_49(c, v1032_6, p1, v1029_11_tail, s1);
          v1030_12 = compose(v1030_10,v1032_11);
        }
        const Space v1030_13 = unite(v1030_8,v1030_12);
        v1029_11_result = unite(v1029_11_result,v1030_13);
      }
      const Space v1029_11 = std::move(v1029_11_result);
      v1024_12 = compose(v1024_10,v1029_11);
    }
    const Space v1024_13 = unite(v1024_8,v1024_12);
    v1023_13_result = unite(v1023_13_result,v1024_13);
  }
  const Space v1023_13 = std::move(v1023_13_result);
  return v1023_13;
}

static Space routine_109(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1033_8 = unwrap(s1,constant_8);
  Space v1033_21_result;
  for (int v1033_21_label = 1; v1033_21_label <= 2; ++v1033_21_label) {
    const Space v1033_21_tail = child(s0,v1033_21_label);
    if (v1033_21_tail.empty()) continue;
    const Path v1033_21_head{v1033_21_label};
    const Space v1034_2 = singleton(v1033_21_head);
    const Space v1034_3 = intersect(constant_6,v1034_2);
    const Space v1034_4 = (has_head(v1034_3) ? constant_7 : Space{});
    const Space v1034_5 = subtract(constant_0,v1034_4);
    Space v1034_8;
    if (!v1034_5.empty()) {
      const Path v1035_6 = concat_path(p0,v1033_21_head);
      Space v1035_7_result;
      for (int v1035_7_label = 1; v1035_7_label <= 2; ++v1035_7_label) {
        const Space v1035_7_tail = child(v1033_21_tail,v1035_7_label);
        if (v1035_7_tail.empty()) continue;
        const Path v1035_7_head{v1035_7_label};
        const Space v1036_2 = singleton(v1035_7_head);
        const Space v1036_3 = intersect(constant_6,v1036_2);
        const Space v1036_4 = (has_head(v1036_3) ? constant_7 : Space{});
        const Space v1036_5 = subtract(constant_0,v1036_4);
        Space v1036_8;
        if (!v1036_5.empty()) {
          const Path v1037_6 = concat_path(v1035_6,v1035_7_head);
          const Space v1037_7 = routine_161(c, v1037_6, p1, v1035_7_tail, s1);
          v1036_8 = compose(v1036_5,v1037_7);
        }
        const Space v1036_9 = intersect(constant_6,v1036_2);
        const Space v1036_10 = (has_head(v1036_9) ? constant_7 : Space{});
        Space v1036_12;
        if (!v1036_10.empty()) {
          const Path v1038_6 = concat_path(v1035_6,v1035_7_head);
          const Space v1038_11 = routine_162(c, v1038_6, p1, v1035_7_tail, s1);
          v1036_12 = compose(v1036_10,v1038_11);
        }
        const Space v1036_13 = unite(v1036_8,v1036_12);
        v1035_7_result = unite(v1035_7_result,v1036_13);
      }
      const Space v1035_7 = std::move(v1035_7_result);
      v1034_8 = compose(v1034_5,v1035_7);
    }
    const Space v1034_9 = intersect(constant_6,v1034_2);
    const Space v1034_10 = (has_head(v1034_9) ? constant_7 : Space{});
    Space v1034_22;
    if (!v1034_10.empty()) {
      const Path v1039_6 = concat_path(p0,v1033_21_head);
      const Path v1039_11 = concat_path(p1,v1039_6);
      const Space v1039_12 = routine_29(c, v1039_11);
      const Space v1039_13 = intersect(v1033_8,v1039_12);
      const Space v1039_14 = routine_33(c, v1039_13);
      Space v1039_15_result;
      for (int v1039_15_label = 1; v1039_15_label <= 2; ++v1039_15_label) {
        const Space v1039_15_tail = child(v1039_14,v1039_15_label);
        if (v1039_15_tail.empty()) continue;
        const Path v1039_15_head{v1039_15_label};
        const Space v1040_2 = singleton(v1039_15_head);
        const Space v1040_3 = intersect(constant_6,v1040_2);
        const Space v1040_4 = (has_head(v1040_3) ? constant_7 : Space{});
        const Space v1040_5 = subtract(constant_0,v1040_4);
        Space v1040_7;
        if (!v1040_5.empty()) {
          const Space v1041_6 = routine_52(c, v1039_15_head, v1039_15_tail);
          v1040_7 = compose(v1040_5,v1041_6);
        }
        const Space v1040_8 = intersect(constant_6,v1040_2);
        const Space v1040_9 = (has_head(v1040_8) ? constant_7 : Space{});
        Space v1040_11;
        if (!v1040_9.empty()) {
          const Space v1042_10 = routine_53(c, v1039_15_head, v1039_15_tail);
          v1040_11 = compose(v1040_9,v1042_10);
        }
        const Space v1040_12 = unite(v1040_7,v1040_11);
        v1039_15_result = unite(v1039_15_result,v1040_12);
      }
      const Space v1039_15 = std::move(v1039_15_result);
      const Space v1039_16 = routine_54(c, v1039_13);
      Space v1039_17_result;
      for (int v1039_17_label = 1; v1039_17_label <= 2; ++v1039_17_label) {
        const Space v1039_17_tail = child(v1039_16,v1039_17_label);
        if (v1039_17_tail.empty()) continue;
        const Path v1039_17_head{v1039_17_label};
        const Space v1043_2 = singleton(v1039_17_head);
        const Space v1043_3 = intersect(constant_6,v1043_2);
        const Space v1043_4 = (has_head(v1043_3) ? constant_7 : Space{});
        const Space v1043_5 = subtract(constant_0,v1043_4);
        Space v1043_7;
        if (!v1043_5.empty()) {
          const Space v1044_6 = routine_55(c, v1039_17_head, v1039_17_tail);
          v1043_7 = compose(v1043_5,v1044_6);
        }
        const Space v1043_8 = intersect(constant_6,v1043_2);
        const Space v1043_9 = (has_head(v1043_8) ? constant_7 : Space{});
        Space v1043_11;
        if (!v1043_9.empty()) {
          const Space v1045_10 = routine_56(c, v1039_17_head, v1039_17_tail);
          v1043_11 = compose(v1043_9,v1045_10);
        }
        const Space v1043_12 = unite(v1043_7,v1043_11);
        v1039_17_result = unite(v1039_17_result,v1043_12);
      }
      const Space v1039_17 = std::move(v1039_17_result);
      const Space v1039_18 = subtract(v1039_15,v1039_17);
      const Space v1039_19 = singleton(v1039_11);
      const Space v1039_20 = compose(v1039_18,v1039_19);
      Space v1039_21_result;
      for (int v1039_21_label = 1; v1039_21_label <= 2; ++v1039_21_label) {
        const Space v1039_21_tail = child(v1039_20,v1039_21_label);
        if (v1039_21_tail.empty()) continue;
        const Path v1039_21_head{v1039_21_label};
        const Space v1046_2 = singleton(v1039_21_head);
        const Space v1046_3 = intersect(constant_6,v1046_2);
        const Space v1046_4 = (has_head(v1046_3) ? constant_7 : Space{});
        const Space v1046_5 = subtract(constant_0,v1046_4);
        Space v1046_7;
        if (!v1046_5.empty()) {
          const Space v1047_6 = routine_57(c, v1039_21_head, v1039_21_tail);
          v1046_7 = compose(v1046_5,v1047_6);
        }
        const Space v1046_8 = intersect(constant_6,v1046_2);
        const Space v1046_9 = (has_head(v1046_8) ? constant_7 : Space{});
        Space v1046_11;
        if (!v1046_9.empty()) {
          const Space v1048_10 = routine_58(c, v1039_21_head, v1039_21_tail);
          v1046_11 = compose(v1046_9,v1048_10);
        }
        const Space v1046_12 = unite(v1046_7,v1046_11);
        v1039_21_result = unite(v1039_21_result,v1046_12);
      }
      const Space v1039_21 = std::move(v1039_21_result);
      v1034_22 = compose(v1034_10,v1039_21);
    }
    const Space v1034_23 = unite(v1034_8,v1034_22);
    v1033_21_result = unite(v1033_21_result,v1034_23);
  }
  const Space v1033_21 = std::move(v1033_21_result);
  return v1033_21;
}

static Space routine_110(Context& c, const Path& p0, const Space& s0) {
  Space v1049_11_result;
  for (int v1049_11_label = 1; v1049_11_label <= 2; ++v1049_11_label) {
    const Space v1049_11_tail = child(s0,v1049_11_label);
    if (v1049_11_tail.empty()) continue;
    const Path v1049_11_head{v1049_11_label};
    const Space v1050_2 = singleton(v1049_11_head);
    const Space v1050_3 = intersect(constant_6,v1050_2);
    const Space v1050_4 = (has_head(v1050_3) ? constant_7 : Space{});
    const Space v1050_5 = subtract(constant_0,v1050_4);
    Space v1050_8;
    if (!v1050_5.empty()) {
      const Path v1051_6 = concat_path(p0,v1049_11_head);
      Space v1051_7_result;
      for (int v1051_7_label = 1; v1051_7_label <= 2; ++v1051_7_label) {
        const Space v1051_7_tail = child(v1049_11_tail,v1051_7_label);
        if (v1051_7_tail.empty()) continue;
        const Path v1051_7_head{v1051_7_label};
        const Space v1052_2 = singleton(v1051_7_head);
        const Space v1052_3 = intersect(constant_6,v1052_2);
        const Space v1052_4 = (has_head(v1052_3) ? constant_7 : Space{});
        const Space v1052_5 = subtract(constant_0,v1052_4);
        Space v1052_8;
        if (!v1052_5.empty()) {
          const Path v1053_6 = concat_path(v1051_6,v1051_7_head);
          const Space v1053_7 = routine_163(c, v1053_6, v1051_7_tail);
          v1052_8 = compose(v1052_5,v1053_7);
        }
        const Space v1052_9 = intersect(constant_6,v1052_2);
        const Space v1052_10 = (has_head(v1052_9) ? constant_7 : Space{});
        Space v1052_12;
        if (!v1052_10.empty()) {
          const Path v1054_6 = concat_path(v1051_6,v1051_7_head);
          const Space v1054_11 = routine_164(c, v1054_6, v1051_7_tail);
          v1052_12 = compose(v1052_10,v1054_11);
        }
        const Space v1052_13 = unite(v1052_8,v1052_12);
        v1051_7_result = unite(v1051_7_result,v1052_13);
      }
      const Space v1051_7 = std::move(v1051_7_result);
      v1050_8 = compose(v1050_5,v1051_7);
    }
    const Space v1050_9 = intersect(constant_6,v1050_2);
    const Space v1050_10 = (has_head(v1050_9) ? constant_7 : Space{});
    Space v1050_12;
    if (!v1050_10.empty()) {
      const Path v1055_6 = concat_path(p0,v1049_11_head);
      Space v1055_11_result;
      for (int v1055_11_label = 1; v1055_11_label <= 2; ++v1055_11_label) {
        const Space v1055_11_tail = child(v1049_11_tail,v1055_11_label);
        if (v1055_11_tail.empty()) continue;
        const Path v1055_11_head{v1055_11_label};
        const Space v1056_2 = singleton(v1055_11_head);
        const Space v1056_3 = intersect(constant_6,v1056_2);
        const Space v1056_4 = (has_head(v1056_3) ? constant_7 : Space{});
        const Space v1056_5 = subtract(constant_0,v1056_4);
        Space v1056_8;
        if (!v1056_5.empty()) {
          const Path v1057_6 = concat_path(v1055_6,v1055_11_head);
          const Space v1057_7 = routine_163(c, v1057_6, v1055_11_tail);
          v1056_8 = compose(v1056_5,v1057_7);
        }
        const Space v1056_9 = intersect(constant_6,v1056_2);
        const Space v1056_10 = (has_head(v1056_9) ? constant_7 : Space{});
        Space v1056_12;
        if (!v1056_10.empty()) {
          const Path v1058_6 = concat_path(v1055_6,v1055_11_head);
          const Space v1058_11 = routine_100(c, v1058_6, v1055_11_tail);
          v1056_12 = compose(v1056_10,v1058_11);
        }
        const Space v1056_13 = unite(v1056_8,v1056_12);
        v1055_11_result = unite(v1055_11_result,v1056_13);
      }
      const Space v1055_11 = std::move(v1055_11_result);
      v1050_12 = compose(v1050_10,v1055_11);
    }
    const Space v1050_13 = unite(v1050_8,v1050_12);
    v1049_11_result = unite(v1049_11_result,v1050_13);
  }
  const Space v1049_11 = std::move(v1049_11_result);
  return v1049_11;
}

static Space routine_111(Context& c, const Path& p0, const Space& s0) {
  Space v1059_9_result;
  for (int v1059_9_label = 1; v1059_9_label <= 2; ++v1059_9_label) {
    const Space v1059_9_tail = child(s0,v1059_9_label);
    if (v1059_9_tail.empty()) continue;
    const Path v1059_9_head{v1059_9_label};
    const Space v1060_2 = singleton(v1059_9_head);
    const Space v1060_3 = intersect(constant_6,v1060_2);
    const Space v1060_4 = (has_head(v1060_3) ? constant_7 : Space{});
    const Space v1060_5 = subtract(constant_0,v1060_4);
    Space v1060_8;
    if (!v1060_5.empty()) {
      const Path v1061_6 = concat_path(p0,v1059_9_head);
      Space v1061_7_result;
      for (int v1061_7_label = 1; v1061_7_label <= 2; ++v1061_7_label) {
        const Space v1061_7_tail = child(v1059_9_tail,v1061_7_label);
        if (v1061_7_tail.empty()) continue;
        const Path v1061_7_head{v1061_7_label};
        const Space v1062_2 = singleton(v1061_7_head);
        const Space v1062_3 = intersect(constant_6,v1062_2);
        const Space v1062_4 = (has_head(v1062_3) ? constant_7 : Space{});
        const Space v1062_5 = subtract(constant_0,v1062_4);
        Space v1062_8;
        if (!v1062_5.empty()) {
          const Path v1063_6 = concat_path(v1061_6,v1061_7_head);
          const Space v1063_7 = routine_163(c, v1063_6, v1061_7_tail);
          v1062_8 = compose(v1062_5,v1063_7);
        }
        const Space v1062_9 = intersect(constant_6,v1062_2);
        const Space v1062_10 = (has_head(v1062_9) ? constant_7 : Space{});
        Space v1062_12;
        if (!v1062_10.empty()) {
          const Path v1064_6 = concat_path(v1061_6,v1061_7_head);
          const Space v1064_11 = routine_164(c, v1064_6, v1061_7_tail);
          v1062_12 = compose(v1062_10,v1064_11);
        }
        const Space v1062_13 = unite(v1062_8,v1062_12);
        v1061_7_result = unite(v1061_7_result,v1062_13);
      }
      const Space v1061_7 = std::move(v1061_7_result);
      v1060_8 = compose(v1060_5,v1061_7);
    }
    const Space v1060_9 = intersect(constant_6,v1060_2);
    const Space v1060_10 = (has_head(v1060_9) ? constant_7 : Space{});
    const Space v1060_11 = compose(v1060_10,constant_9);
    const Space v1060_12 = unite(v1060_8,v1060_11);
    v1059_9_result = unite(v1059_9_result,v1060_12);
  }
  const Space v1059_9 = std::move(v1059_9_result);
  return v1059_9;
}

static Space routine_112(Context& c, const Path& p0, const Space& s0) {
  Space v1065_11_result;
  for (int v1065_11_label = 1; v1065_11_label <= 2; ++v1065_11_label) {
    const Space v1065_11_tail = child(s0,v1065_11_label);
    if (v1065_11_tail.empty()) continue;
    const Path v1065_11_head{v1065_11_label};
    const Space v1066_2 = singleton(v1065_11_head);
    const Space v1066_3 = intersect(constant_6,v1066_2);
    const Space v1066_4 = (has_head(v1066_3) ? constant_7 : Space{});
    const Space v1066_5 = subtract(constant_0,v1066_4);
    Space v1066_8;
    if (!v1066_5.empty()) {
      const Path v1067_6 = concat_path(p0,v1065_11_head);
      Space v1067_7_result;
      for (int v1067_7_label = 1; v1067_7_label <= 2; ++v1067_7_label) {
        const Space v1067_7_tail = child(v1065_11_tail,v1067_7_label);
        if (v1067_7_tail.empty()) continue;
        const Path v1067_7_head{v1067_7_label};
        const Space v1068_2 = singleton(v1067_7_head);
        const Space v1068_3 = intersect(constant_6,v1068_2);
        const Space v1068_4 = (has_head(v1068_3) ? constant_7 : Space{});
        const Space v1068_5 = subtract(constant_0,v1068_4);
        Space v1068_8;
        if (!v1068_5.empty()) {
          const Path v1069_6 = concat_path(v1067_6,v1067_7_head);
          const Space v1069_7 = routine_165(c, v1069_6, v1067_7_tail);
          v1068_8 = compose(v1068_5,v1069_7);
        }
        const Space v1068_9 = intersect(constant_6,v1068_2);
        const Space v1068_10 = (has_head(v1068_9) ? constant_7 : Space{});
        Space v1068_12;
        if (!v1068_10.empty()) {
          const Path v1070_6 = concat_path(v1067_6,v1067_7_head);
          const Space v1070_11 = routine_166(c, v1070_6, v1067_7_tail);
          v1068_12 = compose(v1068_10,v1070_11);
        }
        const Space v1068_13 = unite(v1068_8,v1068_12);
        v1067_7_result = unite(v1067_7_result,v1068_13);
      }
      const Space v1067_7 = std::move(v1067_7_result);
      v1066_8 = compose(v1066_5,v1067_7);
    }
    const Space v1066_9 = intersect(constant_6,v1066_2);
    const Space v1066_10 = (has_head(v1066_9) ? constant_7 : Space{});
    Space v1066_12;
    if (!v1066_10.empty()) {
      const Path v1071_6 = concat_path(p0,v1065_11_head);
      Space v1071_11_result;
      for (int v1071_11_label = 1; v1071_11_label <= 2; ++v1071_11_label) {
        const Space v1071_11_tail = child(v1065_11_tail,v1071_11_label);
        if (v1071_11_tail.empty()) continue;
        const Path v1071_11_head{v1071_11_label};
        const Space v1072_2 = singleton(v1071_11_head);
        const Space v1072_3 = intersect(constant_6,v1072_2);
        const Space v1072_4 = (has_head(v1072_3) ? constant_7 : Space{});
        const Space v1072_5 = subtract(constant_0,v1072_4);
        Space v1072_8;
        if (!v1072_5.empty()) {
          const Path v1073_6 = concat_path(v1071_6,v1071_11_head);
          const Space v1073_7 = routine_165(c, v1073_6, v1071_11_tail);
          v1072_8 = compose(v1072_5,v1073_7);
        }
        const Space v1072_9 = intersect(constant_6,v1072_2);
        const Space v1072_10 = (has_head(v1072_9) ? constant_7 : Space{});
        Space v1072_12;
        if (!v1072_10.empty()) {
          const Path v1074_6 = concat_path(v1071_6,v1071_11_head);
          const Space v1074_11 = routine_104(c, v1074_6, v1071_11_tail);
          v1072_12 = compose(v1072_10,v1074_11);
        }
        const Space v1072_13 = unite(v1072_8,v1072_12);
        v1071_11_result = unite(v1071_11_result,v1072_13);
      }
      const Space v1071_11 = std::move(v1071_11_result);
      v1066_12 = compose(v1066_10,v1071_11);
    }
    const Space v1066_13 = unite(v1066_8,v1066_12);
    v1065_11_result = unite(v1065_11_result,v1066_13);
  }
  const Space v1065_11 = std::move(v1065_11_result);
  return v1065_11;
}

static Space routine_113(Context& c, const Path& p0, const Space& s0) {
  Space v1075_9_result;
  for (int v1075_9_label = 1; v1075_9_label <= 2; ++v1075_9_label) {
    const Space v1075_9_tail = child(s0,v1075_9_label);
    if (v1075_9_tail.empty()) continue;
    const Path v1075_9_head{v1075_9_label};
    const Space v1076_2 = singleton(v1075_9_head);
    const Space v1076_3 = intersect(constant_6,v1076_2);
    const Space v1076_4 = (has_head(v1076_3) ? constant_7 : Space{});
    const Space v1076_5 = subtract(constant_0,v1076_4);
    Space v1076_8;
    if (!v1076_5.empty()) {
      const Path v1077_6 = concat_path(p0,v1075_9_head);
      Space v1077_7_result;
      for (int v1077_7_label = 1; v1077_7_label <= 2; ++v1077_7_label) {
        const Space v1077_7_tail = child(v1075_9_tail,v1077_7_label);
        if (v1077_7_tail.empty()) continue;
        const Path v1077_7_head{v1077_7_label};
        const Space v1078_2 = singleton(v1077_7_head);
        const Space v1078_3 = intersect(constant_6,v1078_2);
        const Space v1078_4 = (has_head(v1078_3) ? constant_7 : Space{});
        const Space v1078_5 = subtract(constant_0,v1078_4);
        Space v1078_8;
        if (!v1078_5.empty()) {
          const Path v1079_6 = concat_path(v1077_6,v1077_7_head);
          const Space v1079_7 = routine_165(c, v1079_6, v1077_7_tail);
          v1078_8 = compose(v1078_5,v1079_7);
        }
        const Space v1078_9 = intersect(constant_6,v1078_2);
        const Space v1078_10 = (has_head(v1078_9) ? constant_7 : Space{});
        Space v1078_12;
        if (!v1078_10.empty()) {
          const Path v1080_6 = concat_path(v1077_6,v1077_7_head);
          const Space v1080_11 = routine_166(c, v1080_6, v1077_7_tail);
          v1078_12 = compose(v1078_10,v1080_11);
        }
        const Space v1078_13 = unite(v1078_8,v1078_12);
        v1077_7_result = unite(v1077_7_result,v1078_13);
      }
      const Space v1077_7 = std::move(v1077_7_result);
      v1076_8 = compose(v1076_5,v1077_7);
    }
    const Space v1076_9 = intersect(constant_6,v1076_2);
    const Space v1076_10 = (has_head(v1076_9) ? constant_7 : Space{});
    const Space v1076_11 = compose(v1076_10,constant_9);
    const Space v1076_12 = unite(v1076_8,v1076_11);
    v1075_9_result = unite(v1075_9_result,v1076_12);
  }
  const Space v1075_9 = std::move(v1075_9_result);
  return v1075_9;
}

static Space routine_114(Context& c, const Path& p0, const Space& s0) {
  Space v1081_11_result;
  for (int v1081_11_label = 1; v1081_11_label <= 2; ++v1081_11_label) {
    const Space v1081_11_tail = child(s0,v1081_11_label);
    if (v1081_11_tail.empty()) continue;
    const Path v1081_11_head{v1081_11_label};
    const Space v1082_2 = singleton(v1081_11_head);
    const Space v1082_3 = intersect(constant_6,v1082_2);
    const Space v1082_4 = (has_head(v1082_3) ? constant_7 : Space{});
    const Space v1082_5 = subtract(constant_0,v1082_4);
    Space v1082_8;
    if (!v1082_5.empty()) {
      const Path v1083_6 = concat_path(p0,v1081_11_head);
      Space v1083_7_result;
      for (int v1083_7_label = 1; v1083_7_label <= 2; ++v1083_7_label) {
        const Space v1083_7_tail = child(v1081_11_tail,v1083_7_label);
        if (v1083_7_tail.empty()) continue;
        const Path v1083_7_head{v1083_7_label};
        const Space v1084_2 = singleton(v1083_7_head);
        const Space v1084_3 = intersect(constant_6,v1084_2);
        const Space v1084_4 = (has_head(v1084_3) ? constant_7 : Space{});
        const Space v1084_5 = subtract(constant_0,v1084_4);
        Space v1084_8;
        if (!v1084_5.empty()) {
          const Path v1085_6 = concat_path(v1083_6,v1083_7_head);
          const Space v1085_7 = routine_167(c, v1085_6, v1083_7_tail);
          v1084_8 = compose(v1084_5,v1085_7);
        }
        const Space v1084_9 = intersect(constant_6,v1084_2);
        const Space v1084_10 = (has_head(v1084_9) ? constant_7 : Space{});
        Space v1084_12;
        if (!v1084_10.empty()) {
          const Path v1086_6 = concat_path(v1083_6,v1083_7_head);
          const Space v1086_11 = routine_168(c, v1086_6, v1083_7_tail);
          v1084_12 = compose(v1084_10,v1086_11);
        }
        const Space v1084_13 = unite(v1084_8,v1084_12);
        v1083_7_result = unite(v1083_7_result,v1084_13);
      }
      const Space v1083_7 = std::move(v1083_7_result);
      v1082_8 = compose(v1082_5,v1083_7);
    }
    const Space v1082_9 = intersect(constant_6,v1082_2);
    const Space v1082_10 = (has_head(v1082_9) ? constant_7 : Space{});
    Space v1082_12;
    if (!v1082_10.empty()) {
      const Path v1087_6 = concat_path(p0,v1081_11_head);
      Space v1087_11_result;
      for (int v1087_11_label = 1; v1087_11_label <= 2; ++v1087_11_label) {
        const Space v1087_11_tail = child(v1081_11_tail,v1087_11_label);
        if (v1087_11_tail.empty()) continue;
        const Path v1087_11_head{v1087_11_label};
        const Space v1088_2 = singleton(v1087_11_head);
        const Space v1088_3 = intersect(constant_6,v1088_2);
        const Space v1088_4 = (has_head(v1088_3) ? constant_7 : Space{});
        const Space v1088_5 = subtract(constant_0,v1088_4);
        Space v1088_8;
        if (!v1088_5.empty()) {
          const Path v1089_6 = concat_path(v1087_6,v1087_11_head);
          const Space v1089_7 = routine_167(c, v1089_6, v1087_11_tail);
          v1088_8 = compose(v1088_5,v1089_7);
        }
        const Space v1088_9 = intersect(constant_6,v1088_2);
        const Space v1088_10 = (has_head(v1088_9) ? constant_7 : Space{});
        Space v1088_12;
        if (!v1088_10.empty()) {
          const Path v1090_6 = concat_path(v1087_6,v1087_11_head);
          const Space v1090_11 = routine_107(c, v1090_6, v1087_11_tail);
          v1088_12 = compose(v1088_10,v1090_11);
        }
        const Space v1088_13 = unite(v1088_8,v1088_12);
        v1087_11_result = unite(v1087_11_result,v1088_13);
      }
      const Space v1087_11 = std::move(v1087_11_result);
      v1082_12 = compose(v1082_10,v1087_11);
    }
    const Space v1082_13 = unite(v1082_8,v1082_12);
    v1081_11_result = unite(v1081_11_result,v1082_13);
  }
  const Space v1081_11 = std::move(v1081_11_result);
  return v1081_11;
}

static Space routine_115(Context& c, const Path& p0, const Space& s0) {
  Space v1091_8_result;
  for (int v1091_8_label = 1; v1091_8_label <= 2; ++v1091_8_label) {
    const Space v1091_8_tail = child(s0,v1091_8_label);
    if (v1091_8_tail.empty()) continue;
    const Path v1091_8_head{v1091_8_label};
    const Space v1092_2 = singleton(v1091_8_head);
    const Space v1092_3 = intersect(constant_6,v1092_2);
    const Space v1092_4 = (has_head(v1092_3) ? constant_7 : Space{});
    const Space v1092_5 = subtract(constant_0,v1092_4);
    Space v1092_8;
    if (!v1092_5.empty()) {
      const Path v1093_6 = concat_path(p0,v1091_8_head);
      Space v1093_7_result;
      for (int v1093_7_label = 1; v1093_7_label <= 2; ++v1093_7_label) {
        const Space v1093_7_tail = child(v1091_8_tail,v1093_7_label);
        if (v1093_7_tail.empty()) continue;
        const Path v1093_7_head{v1093_7_label};
        const Space v1094_2 = singleton(v1093_7_head);
        const Space v1094_3 = intersect(constant_6,v1094_2);
        const Space v1094_4 = (has_head(v1094_3) ? constant_7 : Space{});
        const Space v1094_5 = subtract(constant_0,v1094_4);
        Space v1094_8;
        if (!v1094_5.empty()) {
          const Path v1095_6 = concat_path(v1093_6,v1093_7_head);
          const Space v1095_7 = routine_167(c, v1095_6, v1093_7_tail);
          v1094_8 = compose(v1094_5,v1095_7);
        }
        const Space v1094_9 = intersect(constant_6,v1094_2);
        const Space v1094_10 = (has_head(v1094_9) ? constant_7 : Space{});
        Space v1094_12;
        if (!v1094_10.empty()) {
          const Path v1096_6 = concat_path(v1093_6,v1093_7_head);
          const Space v1096_11 = routine_168(c, v1096_6, v1093_7_tail);
          v1094_12 = compose(v1094_10,v1096_11);
        }
        const Space v1094_13 = unite(v1094_8,v1094_12);
        v1093_7_result = unite(v1093_7_result,v1094_13);
      }
      const Space v1093_7 = std::move(v1093_7_result);
      v1092_8 = compose(v1092_5,v1093_7);
    }
    const Space v1092_9 = intersect(constant_6,v1092_2);
    const Space v1092_10 = (has_head(v1092_9) ? constant_7 : Space{});
    const Space v1092_11 = compose(v1092_10,v1091_8_tail);
    const Space v1092_12 = unite(v1092_8,v1092_11);
    v1091_8_result = unite(v1091_8_result,v1092_12);
  }
  const Space v1091_8 = std::move(v1091_8_result);
  return v1091_8;
}

static Space routine_116(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1097_7_result;
  for (int v1097_7_label = 1; v1097_7_label <= 2; ++v1097_7_label) {
    const Space v1097_7_tail = child(s0,v1097_7_label);
    if (v1097_7_tail.empty()) continue;
    const Path v1097_7_head{v1097_7_label};
    const Space v1098_2 = singleton(v1097_7_head);
    const Space v1098_3 = intersect(constant_6,v1098_2);
    const Space v1098_4 = (has_head(v1098_3) ? constant_7 : Space{});
    const Space v1098_5 = subtract(constant_0,v1098_4);
    Space v1098_6_result;
    for (int v1098_6_label = 1; v1098_6_label <= 2; ++v1098_6_label) {
      const Space v1098_6_tail = child(v1097_7_tail,v1098_6_label);
      if (v1098_6_tail.empty()) continue;
      const Path v1098_6_head{v1098_6_label};
      const Space v1099_2 = Space{};
      v1098_6_result = unite(v1098_6_result,v1099_2);
    }
    const Space v1098_6 = std::move(v1098_6_result);
    const Space v1098_7 = compose(v1098_5,v1098_6);
    const Space v1098_8 = intersect(constant_6,v1098_2);
    const Space v1098_9 = (has_head(v1098_8) ? constant_7 : Space{});
    Space v1098_12;
    if (!v1098_9.empty()) {
      const Path v1100_10 = concat_path(p0,v1097_7_head);
      Space v1100_11_result;
      for (int v1100_11_label = 1; v1100_11_label <= 2; ++v1100_11_label) {
        const Space v1100_11_tail = child(v1097_7_tail,v1100_11_label);
        if (v1100_11_tail.empty()) continue;
        const Path v1100_11_head{v1100_11_label};
        const Space v1101_2 = singleton(v1100_11_head);
        const Space v1101_3 = intersect(constant_6,v1101_2);
        const Space v1101_4 = (has_head(v1101_3) ? constant_7 : Space{});
        Space v1101_7;
        if (!v1101_4.empty()) {
          const Path v1102_5 = concat_path(v1100_10,v1100_11_head);
          const Space v1102_6 = routine_9(c, v1102_5, v1100_11_tail, s1);
          v1101_7 = compose(v1101_4,v1102_6);
        }
        v1100_11_result = unite(v1100_11_result,v1101_7);
      }
      const Space v1100_11 = std::move(v1100_11_result);
      v1098_12 = compose(v1098_9,v1100_11);
    }
    const Space v1098_13 = unite(v1098_7,v1098_12);
    v1097_7_result = unite(v1097_7_result,v1098_13);
  }
  const Space v1097_7 = std::move(v1097_7_result);
  return v1097_7;
}

static Space routine_117(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1103_9_result;
  for (int v1103_9_label = 1; v1103_9_label <= 2; ++v1103_9_label) {
    const Space v1103_9_tail = child(s0,v1103_9_label);
    if (v1103_9_tail.empty()) continue;
    const Path v1103_9_head{v1103_9_label};
    const Space v1104_2 = singleton(v1103_9_head);
    const Space v1104_3 = intersect(constant_6,v1104_2);
    const Space v1104_4 = (has_head(v1104_3) ? constant_7 : Space{});
    const Space v1104_5 = subtract(constant_0,v1104_4);
    Space v1104_6_result;
    for (int v1104_6_label = 1; v1104_6_label <= 2; ++v1104_6_label) {
      const Space v1104_6_tail = child(v1103_9_tail,v1104_6_label);
      if (v1104_6_tail.empty()) continue;
      const Path v1104_6_head{v1104_6_label};
      const Space v1105_2 = Space{};
      v1104_6_result = unite(v1104_6_result,v1105_2);
    }
    const Space v1104_6 = std::move(v1104_6_result);
    const Space v1104_7 = compose(v1104_5,v1104_6);
    const Space v1104_8 = intersect(constant_6,v1104_2);
    const Space v1104_9 = (has_head(v1104_8) ? constant_7 : Space{});
    Space v1104_12;
    if (!v1104_9.empty()) {
      const Path v1106_10 = concat_path(p0,v1103_9_head);
      Space v1106_11_result;
      for (int v1106_11_label = 1; v1106_11_label <= 2; ++v1106_11_label) {
        const Space v1106_11_tail = child(v1103_9_tail,v1106_11_label);
        if (v1106_11_tail.empty()) continue;
        const Path v1106_11_head{v1106_11_label};
        const Space v1107_2 = singleton(v1106_11_head);
        const Space v1107_3 = intersect(constant_6,v1107_2);
        const Space v1107_4 = (has_head(v1107_3) ? constant_7 : Space{});
        const Space v1107_5 = subtract(constant_0,v1107_4);
        Space v1107_7;
        if (!v1107_5.empty()) {
          const Space v1108_6 = routine_10(c, v1106_11_head, v1106_10, v1106_11_tail, s1);
          v1107_7 = compose(v1107_5,v1108_6);
        }
        const Space v1107_8 = intersect(constant_6,v1107_2);
        const Space v1107_9 = (has_head(v1107_8) ? constant_7 : Space{});
        Space v1107_11;
        if (!v1107_9.empty()) {
          const Space v1109_10 = routine_11(c, v1106_11_head, v1106_10, v1106_11_tail, s1);
          v1107_11 = compose(v1107_9,v1109_10);
        }
        const Space v1107_12 = unite(v1107_7,v1107_11);
        v1106_11_result = unite(v1106_11_result,v1107_12);
      }
      const Space v1106_11 = std::move(v1106_11_result);
      v1104_12 = compose(v1104_9,v1106_11);
    }
    const Space v1104_13 = unite(v1104_7,v1104_12);
    v1103_9_result = unite(v1103_9_result,v1104_13);
  }
  const Space v1103_9 = std::move(v1103_9_result);
  return v1103_9;
}

static Space routine_118(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1110_13_result;
  for (int v1110_13_label = 1; v1110_13_label <= 2; ++v1110_13_label) {
    const Space v1110_13_tail = child(s0,v1110_13_label);
    if (v1110_13_tail.empty()) continue;
    const Path v1110_13_head{v1110_13_label};
    const Space v1111_2 = singleton(v1110_13_head);
    const Space v1111_3 = intersect(constant_6,v1111_2);
    const Space v1111_4 = (has_head(v1111_3) ? constant_7 : Space{});
    const Space v1111_5 = subtract(constant_0,v1111_4);
    Space v1111_8;
    if (!v1111_5.empty()) {
      const Path v1112_6 = concat_path(p0,v1110_13_head);
      Space v1112_7_result;
      for (int v1112_7_label = 1; v1112_7_label <= 2; ++v1112_7_label) {
        const Space v1112_7_tail = child(v1110_13_tail,v1112_7_label);
        if (v1112_7_tail.empty()) continue;
        const Path v1112_7_head{v1112_7_label};
        const Space v1113_2 = singleton(v1112_7_head);
        const Space v1113_3 = intersect(constant_6,v1113_2);
        const Space v1113_4 = (has_head(v1113_3) ? constant_7 : Space{});
        const Space v1113_5 = subtract(constant_0,v1113_4);
        Space v1113_8;
        if (!v1113_5.empty()) {
          const Path v1114_6 = concat_path(v1112_6,v1112_7_head);
          const Space v1114_7 = routine_169(c, v1114_6, p1, v1112_7_tail, s1);
          v1113_8 = compose(v1113_5,v1114_7);
        }
        const Space v1113_9 = intersect(constant_6,v1113_2);
        const Space v1113_10 = (has_head(v1113_9) ? constant_7 : Space{});
        Space v1113_12;
        if (!v1113_10.empty()) {
          const Path v1115_6 = concat_path(v1112_6,v1112_7_head);
          const Space v1115_11 = routine_170(c, v1115_6, p1, v1112_7_tail, s1);
          v1113_12 = compose(v1113_10,v1115_11);
        }
        const Space v1113_13 = unite(v1113_8,v1113_12);
        v1112_7_result = unite(v1112_7_result,v1113_13);
      }
      const Space v1112_7 = std::move(v1112_7_result);
      v1111_8 = compose(v1111_5,v1112_7);
    }
    const Space v1111_9 = intersect(constant_6,v1111_2);
    const Space v1111_10 = (has_head(v1111_9) ? constant_7 : Space{});
    Space v1111_12;
    if (!v1111_10.empty()) {
      const Path v1116_6 = concat_path(p0,v1110_13_head);
      Space v1116_11_result;
      for (int v1116_11_label = 1; v1116_11_label <= 2; ++v1116_11_label) {
        const Space v1116_11_tail = child(v1110_13_tail,v1116_11_label);
        if (v1116_11_tail.empty()) continue;
        const Path v1116_11_head{v1116_11_label};
        const Space v1117_2 = singleton(v1116_11_head);
        const Space v1117_3 = intersect(constant_6,v1117_2);
        const Space v1117_4 = (has_head(v1117_3) ? constant_7 : Space{});
        const Space v1117_5 = subtract(constant_0,v1117_4);
        Space v1117_8;
        if (!v1117_5.empty()) {
          const Path v1118_6 = concat_path(v1116_6,v1116_11_head);
          const Space v1118_7 = routine_169(c, v1118_6, p1, v1116_11_tail, s1);
          v1117_8 = compose(v1117_5,v1118_7);
        }
        const Space v1117_9 = intersect(constant_6,v1117_2);
        const Space v1117_10 = (has_head(v1117_9) ? constant_7 : Space{});
        Space v1117_12;
        if (!v1117_10.empty()) {
          const Path v1119_6 = concat_path(v1116_6,v1116_11_head);
          const Space v1119_11 = routine_26(c, v1119_6, p1, v1116_11_tail, s1);
          v1117_12 = compose(v1117_10,v1119_11);
        }
        const Space v1117_13 = unite(v1117_8,v1117_12);
        v1116_11_result = unite(v1116_11_result,v1117_13);
      }
      const Space v1116_11 = std::move(v1116_11_result);
      v1111_12 = compose(v1111_10,v1116_11);
    }
    const Space v1111_13 = unite(v1111_8,v1111_12);
    v1110_13_result = unite(v1110_13_result,v1111_13);
  }
  const Space v1110_13 = std::move(v1110_13_result);
  return v1110_13;
}

static Space routine_119(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1120_8 = unwrap(s1,constant_8);
  Space v1120_21_result;
  for (int v1120_21_label = 1; v1120_21_label <= 2; ++v1120_21_label) {
    const Space v1120_21_tail = child(s0,v1120_21_label);
    if (v1120_21_tail.empty()) continue;
    const Path v1120_21_head{v1120_21_label};
    const Space v1121_2 = singleton(v1120_21_head);
    const Space v1121_3 = intersect(constant_6,v1121_2);
    const Space v1121_4 = (has_head(v1121_3) ? constant_7 : Space{});
    const Space v1121_5 = subtract(constant_0,v1121_4);
    Space v1121_8;
    if (!v1121_5.empty()) {
      const Path v1122_6 = concat_path(p0,v1120_21_head);
      Space v1122_7_result;
      for (int v1122_7_label = 1; v1122_7_label <= 2; ++v1122_7_label) {
        const Space v1122_7_tail = child(v1120_21_tail,v1122_7_label);
        if (v1122_7_tail.empty()) continue;
        const Path v1122_7_head{v1122_7_label};
        const Space v1123_2 = singleton(v1122_7_head);
        const Space v1123_3 = intersect(constant_6,v1123_2);
        const Space v1123_4 = (has_head(v1123_3) ? constant_7 : Space{});
        const Space v1123_5 = subtract(constant_0,v1123_4);
        Space v1123_8;
        if (!v1123_5.empty()) {
          const Path v1124_6 = concat_path(v1122_6,v1122_7_head);
          const Space v1124_7 = routine_169(c, v1124_6, p1, v1122_7_tail, s1);
          v1123_8 = compose(v1123_5,v1124_7);
        }
        const Space v1123_9 = intersect(constant_6,v1123_2);
        const Space v1123_10 = (has_head(v1123_9) ? constant_7 : Space{});
        Space v1123_12;
        if (!v1123_10.empty()) {
          const Path v1125_6 = concat_path(v1122_6,v1122_7_head);
          const Space v1125_11 = routine_170(c, v1125_6, p1, v1122_7_tail, s1);
          v1123_12 = compose(v1123_10,v1125_11);
        }
        const Space v1123_13 = unite(v1123_8,v1123_12);
        v1122_7_result = unite(v1122_7_result,v1123_13);
      }
      const Space v1122_7 = std::move(v1122_7_result);
      v1121_8 = compose(v1121_5,v1122_7);
    }
    const Space v1121_9 = intersect(constant_6,v1121_2);
    const Space v1121_10 = (has_head(v1121_9) ? constant_7 : Space{});
    Space v1121_22;
    if (!v1121_10.empty()) {
      const Path v1126_6 = concat_path(p0,v1120_21_head);
      const Path v1126_11 = concat_path(p1,v1126_6);
      const Space v1126_12 = routine_29(c, v1126_11);
      const Space v1126_13 = intersect(v1120_8,v1126_12);
      const Space v1126_14 = routine_30(c, v1126_13);
      Space v1126_15_result;
      for (int v1126_15_label = 1; v1126_15_label <= 2; ++v1126_15_label) {
        const Space v1126_15_tail = child(v1126_14,v1126_15_label);
        if (v1126_15_tail.empty()) continue;
        const Path v1126_15_head{v1126_15_label};
        const Space v1127_2 = singleton(v1126_15_head);
        const Space v1127_3 = intersect(constant_6,v1127_2);
        const Space v1127_4 = (has_head(v1127_3) ? constant_7 : Space{});
        const Space v1127_5 = subtract(constant_0,v1127_4);
        Space v1127_7;
        if (!v1127_5.empty()) {
          const Space v1128_6 = routine_31(c, v1126_15_head, v1126_15_tail);
          v1127_7 = compose(v1127_5,v1128_6);
        }
        const Space v1127_8 = intersect(constant_6,v1127_2);
        const Space v1127_9 = (has_head(v1127_8) ? constant_7 : Space{});
        Space v1127_11;
        if (!v1127_9.empty()) {
          const Space v1129_10 = routine_32(c, v1126_15_head, v1126_15_tail);
          v1127_11 = compose(v1127_9,v1129_10);
        }
        const Space v1127_12 = unite(v1127_7,v1127_11);
        v1126_15_result = unite(v1126_15_result,v1127_12);
      }
      const Space v1126_15 = std::move(v1126_15_result);
      const Space v1126_16 = routine_33(c, v1126_13);
      Space v1126_17_result;
      for (int v1126_17_label = 1; v1126_17_label <= 2; ++v1126_17_label) {
        const Space v1126_17_tail = child(v1126_16,v1126_17_label);
        if (v1126_17_tail.empty()) continue;
        const Path v1126_17_head{v1126_17_label};
        const Space v1130_2 = singleton(v1126_17_head);
        const Space v1130_3 = intersect(constant_6,v1130_2);
        const Space v1130_4 = (has_head(v1130_3) ? constant_7 : Space{});
        const Space v1130_5 = subtract(constant_0,v1130_4);
        Space v1130_7;
        if (!v1130_5.empty()) {
          const Space v1131_6 = routine_34(c, v1126_17_head, v1126_17_tail);
          v1130_7 = compose(v1130_5,v1131_6);
        }
        const Space v1130_8 = intersect(constant_6,v1130_2);
        const Space v1130_9 = (has_head(v1130_8) ? constant_7 : Space{});
        Space v1130_11;
        if (!v1130_9.empty()) {
          const Space v1132_10 = routine_35(c, v1126_17_head, v1126_17_tail);
          v1130_11 = compose(v1130_9,v1132_10);
        }
        const Space v1130_12 = unite(v1130_7,v1130_11);
        v1126_17_result = unite(v1126_17_result,v1130_12);
      }
      const Space v1126_17 = std::move(v1126_17_result);
      const Space v1126_18 = subtract(v1126_15,v1126_17);
      const Space v1126_19 = singleton(v1126_11);
      const Space v1126_20 = compose(v1126_18,v1126_19);
      Space v1126_21_result;
      for (int v1126_21_label = 1; v1126_21_label <= 2; ++v1126_21_label) {
        const Space v1126_21_tail = child(v1126_20,v1126_21_label);
        if (v1126_21_tail.empty()) continue;
        const Path v1126_21_head{v1126_21_label};
        const Space v1133_2 = singleton(v1126_21_head);
        const Space v1133_3 = intersect(constant_6,v1133_2);
        const Space v1133_4 = (has_head(v1133_3) ? constant_7 : Space{});
        const Space v1133_5 = subtract(constant_0,v1133_4);
        Space v1133_7;
        if (!v1133_5.empty()) {
          const Space v1134_6 = routine_36(c, v1126_21_head, v1126_21_tail);
          v1133_7 = compose(v1133_5,v1134_6);
        }
        const Space v1133_8 = intersect(constant_6,v1133_2);
        const Space v1133_9 = (has_head(v1133_8) ? constant_7 : Space{});
        Space v1133_11;
        if (!v1133_9.empty()) {
          const Space v1135_10 = routine_37(c, v1126_21_head, v1126_21_tail);
          v1133_11 = compose(v1133_9,v1135_10);
        }
        const Space v1133_12 = unite(v1133_7,v1133_11);
        v1126_21_result = unite(v1126_21_result,v1133_12);
      }
      const Space v1126_21 = std::move(v1126_21_result);
      v1121_22 = compose(v1121_10,v1126_21);
    }
    const Space v1121_23 = unite(v1121_8,v1121_22);
    v1120_21_result = unite(v1120_21_result,v1121_23);
  }
  const Space v1120_21 = std::move(v1120_21_result);
  return v1120_21;
}

static Space routine_120(Context& c, const Path& p0, const Space& s0) {
  Space v1136_11_result;
  for (int v1136_11_label = 1; v1136_11_label <= 2; ++v1136_11_label) {
    const Space v1136_11_tail = child(s0,v1136_11_label);
    if (v1136_11_tail.empty()) continue;
    const Path v1136_11_head{v1136_11_label};
    const Space v1137_2 = singleton(v1136_11_head);
    const Space v1137_3 = intersect(constant_6,v1137_2);
    const Space v1137_4 = (has_head(v1137_3) ? constant_7 : Space{});
    const Space v1137_5 = subtract(constant_0,v1137_4);
    Space v1137_8;
    if (!v1137_5.empty()) {
      const Path v1138_6 = concat_path(p0,v1136_11_head);
      Space v1138_7_result;
      for (int v1138_7_label = 1; v1138_7_label <= 2; ++v1138_7_label) {
        const Space v1138_7_tail = child(v1136_11_tail,v1138_7_label);
        if (v1138_7_tail.empty()) continue;
        const Path v1138_7_head{v1138_7_label};
        const Space v1139_2 = singleton(v1138_7_head);
        const Space v1139_3 = intersect(constant_6,v1139_2);
        const Space v1139_4 = (has_head(v1139_3) ? constant_7 : Space{});
        const Space v1139_5 = subtract(constant_0,v1139_4);
        Space v1139_8;
        if (!v1139_5.empty()) {
          const Path v1140_6 = concat_path(v1138_6,v1138_7_head);
          const Space v1140_7 = routine_171(c, v1140_6, v1138_7_tail);
          v1139_8 = compose(v1139_5,v1140_7);
        }
        const Space v1139_9 = intersect(constant_6,v1139_2);
        const Space v1139_10 = (has_head(v1139_9) ? constant_7 : Space{});
        Space v1139_12;
        if (!v1139_10.empty()) {
          const Path v1141_6 = concat_path(v1138_6,v1138_7_head);
          const Space v1141_11 = routine_172(c, v1141_6, v1138_7_tail);
          v1139_12 = compose(v1139_10,v1141_11);
        }
        const Space v1139_13 = unite(v1139_8,v1139_12);
        v1138_7_result = unite(v1138_7_result,v1139_13);
      }
      const Space v1138_7 = std::move(v1138_7_result);
      v1137_8 = compose(v1137_5,v1138_7);
    }
    const Space v1137_9 = intersect(constant_6,v1137_2);
    const Space v1137_10 = (has_head(v1137_9) ? constant_7 : Space{});
    Space v1137_12;
    if (!v1137_10.empty()) {
      const Path v1142_6 = concat_path(p0,v1136_11_head);
      Space v1142_11_result;
      for (int v1142_11_label = 1; v1142_11_label <= 2; ++v1142_11_label) {
        const Space v1142_11_tail = child(v1136_11_tail,v1142_11_label);
        if (v1142_11_tail.empty()) continue;
        const Path v1142_11_head{v1142_11_label};
        const Space v1143_2 = singleton(v1142_11_head);
        const Space v1143_3 = intersect(constant_6,v1143_2);
        const Space v1143_4 = (has_head(v1143_3) ? constant_7 : Space{});
        const Space v1143_5 = subtract(constant_0,v1143_4);
        Space v1143_8;
        if (!v1143_5.empty()) {
          const Path v1144_6 = concat_path(v1142_6,v1142_11_head);
          const Space v1144_7 = routine_171(c, v1144_6, v1142_11_tail);
          v1143_8 = compose(v1143_5,v1144_7);
        }
        const Space v1143_9 = intersect(constant_6,v1143_2);
        const Space v1143_10 = (has_head(v1143_9) ? constant_7 : Space{});
        Space v1143_12;
        if (!v1143_10.empty()) {
          const Path v1145_6 = concat_path(v1142_6,v1142_11_head);
          const Space v1145_11 = routine_80(c, v1145_6, v1142_11_tail);
          v1143_12 = compose(v1143_10,v1145_11);
        }
        const Space v1143_13 = unite(v1143_8,v1143_12);
        v1142_11_result = unite(v1142_11_result,v1143_13);
      }
      const Space v1142_11 = std::move(v1142_11_result);
      v1137_12 = compose(v1137_10,v1142_11);
    }
    const Space v1137_13 = unite(v1137_8,v1137_12);
    v1136_11_result = unite(v1136_11_result,v1137_13);
  }
  const Space v1136_11 = std::move(v1136_11_result);
  return v1136_11;
}

static Space routine_121(Context& c, const Path& p0, const Space& s0) {
  Space v1146_11_result;
  for (int v1146_11_label = 1; v1146_11_label <= 2; ++v1146_11_label) {
    const Space v1146_11_tail = child(s0,v1146_11_label);
    if (v1146_11_tail.empty()) continue;
    const Path v1146_11_head{v1146_11_label};
    const Space v1147_2 = singleton(v1146_11_head);
    const Space v1147_3 = intersect(constant_6,v1147_2);
    const Space v1147_4 = (has_head(v1147_3) ? constant_7 : Space{});
    const Space v1147_5 = subtract(constant_0,v1147_4);
    Space v1147_8;
    if (!v1147_5.empty()) {
      const Path v1148_6 = concat_path(p0,v1146_11_head);
      Space v1148_7_result;
      for (int v1148_7_label = 1; v1148_7_label <= 2; ++v1148_7_label) {
        const Space v1148_7_tail = child(v1146_11_tail,v1148_7_label);
        if (v1148_7_tail.empty()) continue;
        const Path v1148_7_head{v1148_7_label};
        const Space v1149_2 = singleton(v1148_7_head);
        const Space v1149_3 = intersect(constant_6,v1149_2);
        const Space v1149_4 = (has_head(v1149_3) ? constant_7 : Space{});
        const Space v1149_5 = subtract(constant_0,v1149_4);
        Space v1149_8;
        if (!v1149_5.empty()) {
          const Path v1150_6 = concat_path(v1148_6,v1148_7_head);
          const Space v1150_7 = routine_171(c, v1150_6, v1148_7_tail);
          v1149_8 = compose(v1149_5,v1150_7);
        }
        const Space v1149_9 = intersect(constant_6,v1149_2);
        const Space v1149_10 = (has_head(v1149_9) ? constant_7 : Space{});
        Space v1149_12;
        if (!v1149_10.empty()) {
          const Path v1151_6 = concat_path(v1148_6,v1148_7_head);
          const Space v1151_11 = routine_172(c, v1151_6, v1148_7_tail);
          v1149_12 = compose(v1149_10,v1151_11);
        }
        const Space v1149_13 = unite(v1149_8,v1149_12);
        v1148_7_result = unite(v1148_7_result,v1149_13);
      }
      const Space v1148_7 = std::move(v1148_7_result);
      v1147_8 = compose(v1147_5,v1148_7);
    }
    const Space v1147_9 = intersect(constant_6,v1147_2);
    const Space v1147_10 = (has_head(v1147_9) ? constant_7 : Space{});
    Space v1147_12;
    if (!v1147_10.empty()) {
      const Path v1152_6 = concat_path(p0,v1146_11_head);
      Space v1152_11_result;
      for (int v1152_11_label = 1; v1152_11_label <= 2; ++v1152_11_label) {
        const Space v1152_11_tail = child(v1146_11_tail,v1152_11_label);
        if (v1152_11_tail.empty()) continue;
        const Path v1152_11_head{v1152_11_label};
        const Space v1153_2 = singleton(v1152_11_head);
        const Space v1153_3 = intersect(constant_6,v1153_2);
        const Space v1153_4 = (has_head(v1153_3) ? constant_7 : Space{});
        const Space v1153_5 = subtract(constant_0,v1153_4);
        Space v1153_7;
        if (!v1153_5.empty()) {
          const Space v1154_6 = routine_122(c, v1152_11_head, v1152_6, v1152_11_tail);
          v1153_7 = compose(v1153_5,v1154_6);
        }
        const Space v1153_8 = intersect(constant_6,v1153_2);
        const Space v1153_9 = (has_head(v1153_8) ? constant_7 : Space{});
        Space v1153_11;
        if (!v1153_9.empty()) {
          const Space v1155_10 = routine_123(c, v1152_11_head, v1152_6, v1152_11_tail);
          v1153_11 = compose(v1153_9,v1155_10);
        }
        const Space v1153_12 = unite(v1153_7,v1153_11);
        v1152_11_result = unite(v1152_11_result,v1153_12);
      }
      const Space v1152_11 = std::move(v1152_11_result);
      v1147_12 = compose(v1147_10,v1152_11);
    }
    const Space v1147_13 = unite(v1147_8,v1147_12);
    v1146_11_result = unite(v1146_11_result,v1147_13);
  }
  const Space v1146_11 = std::move(v1146_11_result);
  return v1146_11;
}

static Space routine_122(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1156_12_result;
  for (int v1156_12_label = 1; v1156_12_label <= 2; ++v1156_12_label) {
    const Space v1156_12_tail = child(s0,v1156_12_label);
    if (v1156_12_tail.empty()) continue;
    const Path v1156_12_head{v1156_12_label};
    const Space v1157_2 = singleton(v1156_12_head);
    const Space v1157_3 = intersect(constant_6,v1157_2);
    const Space v1157_4 = (has_head(v1157_3) ? constant_7 : Space{});
    const Space v1157_5 = subtract(constant_0,v1157_4);
    Space v1157_8;
    if (!v1157_5.empty()) {
      const Path v1158_6 = concat_path(p0,v1156_12_head);
      Space v1158_7_result;
      for (int v1158_7_label = 1; v1158_7_label <= 2; ++v1158_7_label) {
        const Space v1158_7_tail = child(v1156_12_tail,v1158_7_label);
        if (v1158_7_tail.empty()) continue;
        const Path v1158_7_head{v1158_7_label};
        const Space v1159_2 = singleton(v1158_7_head);
        const Space v1159_3 = intersect(constant_6,v1159_2);
        const Space v1159_4 = (has_head(v1159_3) ? constant_7 : Space{});
        const Space v1159_5 = subtract(constant_0,v1159_4);
        Space v1159_8;
        if (!v1159_5.empty()) {
          const Path v1160_6 = concat_path(v1158_6,v1158_7_head);
          const Space v1160_7 = routine_173(c, v1160_6, p1, v1158_7_tail);
          v1159_8 = compose(v1159_5,v1160_7);
        }
        const Space v1159_9 = intersect(constant_6,v1159_2);
        const Space v1159_10 = (has_head(v1159_9) ? constant_7 : Space{});
        Space v1159_12;
        if (!v1159_10.empty()) {
          const Path v1161_6 = concat_path(v1158_6,v1158_7_head);
          const Space v1161_11 = routine_174(c, v1161_6, p1, v1158_7_tail);
          v1159_12 = compose(v1159_10,v1161_11);
        }
        const Space v1159_13 = unite(v1159_8,v1159_12);
        v1158_7_result = unite(v1158_7_result,v1159_13);
      }
      const Space v1158_7 = std::move(v1158_7_result);
      v1157_8 = compose(v1157_5,v1158_7);
    }
    const Space v1157_9 = intersect(constant_6,v1157_2);
    const Space v1157_10 = (has_head(v1157_9) ? constant_7 : Space{});
    Space v1157_12;
    if (!v1157_10.empty()) {
      const Path v1162_6 = concat_path(p0,v1156_12_head);
      Space v1162_11_result;
      for (int v1162_11_label = 1; v1162_11_label <= 2; ++v1162_11_label) {
        const Space v1162_11_tail = child(v1156_12_tail,v1162_11_label);
        if (v1162_11_tail.empty()) continue;
        const Path v1162_11_head{v1162_11_label};
        const Space v1163_2 = singleton(v1162_11_head);
        const Space v1163_3 = intersect(constant_6,v1163_2);
        const Space v1163_4 = (has_head(v1163_3) ? constant_7 : Space{});
        const Space v1163_5 = subtract(constant_0,v1163_4);
        Space v1163_8;
        if (!v1163_5.empty()) {
          const Path v1164_6 = concat_path(v1162_6,v1162_11_head);
          const Space v1164_7 = routine_173(c, v1164_6, p1, v1162_11_tail);
          v1163_8 = compose(v1163_5,v1164_7);
        }
        const Space v1163_9 = intersect(constant_6,v1163_2);
        const Space v1163_10 = (has_head(v1163_9) ? constant_7 : Space{});
        Space v1163_12;
        if (!v1163_10.empty()) {
          const Path v1165_6 = concat_path(v1162_6,v1162_11_head);
          const Space v1165_11 = routine_137(c, v1165_6, p1, v1162_11_tail);
          v1163_12 = compose(v1163_10,v1165_11);
        }
        const Space v1163_13 = unite(v1163_8,v1163_12);
        v1162_11_result = unite(v1162_11_result,v1163_13);
      }
      const Space v1162_11 = std::move(v1162_11_result);
      v1157_12 = compose(v1157_10,v1162_11);
    }
    const Space v1157_13 = unite(v1157_8,v1157_12);
    v1156_12_result = unite(v1156_12_result,v1157_13);
  }
  const Space v1156_12 = std::move(v1156_12_result);
  return v1156_12;
}

static Space routine_123(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1166_7 = unwrap(constant_12,p1);
  const Space v1166_9 = unwrap(constant_12,p0);
  Space v1166_13_result;
  for (int v1166_13_label = 1; v1166_13_label <= 2; ++v1166_13_label) {
    const Space v1166_13_tail = child(s0,v1166_13_label);
    if (v1166_13_tail.empty()) continue;
    const Path v1166_13_head{v1166_13_label};
    const Space v1167_2 = singleton(v1166_13_head);
    const Space v1167_3 = intersect(constant_6,v1167_2);
    const Space v1167_4 = (has_head(v1167_3) ? constant_7 : Space{});
    const Space v1167_5 = subtract(constant_0,v1167_4);
    Space v1167_8;
    if (!v1167_5.empty()) {
      const Path v1168_6 = concat_path(p0,v1166_13_head);
      Space v1168_7_result;
      for (int v1168_7_label = 1; v1168_7_label <= 2; ++v1168_7_label) {
        const Space v1168_7_tail = child(v1166_13_tail,v1168_7_label);
        if (v1168_7_tail.empty()) continue;
        const Path v1168_7_head{v1168_7_label};
        const Space v1169_2 = singleton(v1168_7_head);
        const Space v1169_3 = intersect(constant_6,v1169_2);
        const Space v1169_4 = (has_head(v1169_3) ? constant_7 : Space{});
        const Space v1169_5 = subtract(constant_0,v1169_4);
        Space v1169_8;
        if (!v1169_5.empty()) {
          const Path v1170_6 = concat_path(v1168_6,v1168_7_head);
          const Space v1170_7 = routine_173(c, v1170_6, p1, v1168_7_tail);
          v1169_8 = compose(v1169_5,v1170_7);
        }
        const Space v1169_9 = intersect(constant_6,v1169_2);
        const Space v1169_10 = (has_head(v1169_9) ? constant_7 : Space{});
        Space v1169_12;
        if (!v1169_10.empty()) {
          const Path v1171_6 = concat_path(v1168_6,v1168_7_head);
          const Space v1171_11 = routine_174(c, v1171_6, p1, v1168_7_tail);
          v1169_12 = compose(v1169_10,v1171_11);
        }
        const Space v1169_13 = unite(v1169_8,v1169_12);
        v1168_7_result = unite(v1168_7_result,v1169_13);
      }
      const Space v1168_7 = std::move(v1168_7_result);
      v1167_8 = compose(v1167_5,v1168_7);
    }
    const Space v1167_9 = intersect(constant_6,v1167_2);
    const Space v1167_10 = (has_head(v1167_9) ? constant_7 : Space{});
    const Space v1167_11 = unwrap(v1166_9,v1166_13_head);
    const Space v1167_12 = compose(v1166_7,v1167_11);
    const Path v1172_6 = concat_path(p0,v1166_13_head);
    const Path v1167_13 = concat_path(p1,v1172_6);
    const Space v1167_14 = singleton(v1167_13);
    const Space v1167_15 = subtract(v1167_12,v1167_14);
    const Space v1167_16 = compose(v1167_10,v1167_15);
    const Space v1167_17 = unite(v1167_8,v1167_16);
    v1166_13_result = unite(v1166_13_result,v1167_17);
  }
  const Space v1166_13 = std::move(v1166_13_result);
  return v1166_13;
}

static Space routine_124(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  const Space v1173_3 = first_matching(s0,constant_0,false);
  Space v1173_7;
  if (!v1173_3.empty()) {
    const Space v1174_4 = unwrap(s1,p0);
    const Space v1174_5 = routine_81(c, v1174_4);
    const Space v1174_6 = wrap(v1174_5,p0);
    v1173_7 = compose(v1173_3,v1174_6);
  }
  Space v1173_8_result;
  for (int v1173_8_label = 1; v1173_8_label <= 2; ++v1173_8_label) {
    const Space v1173_8_tail = child(s0,v1173_8_label);
    if (v1173_8_tail.empty()) continue;
    const Path v1173_8_head{v1173_8_label};
    const Path v1175_2 = concat_path(p0,v1173_8_head);
    const Space v1175_3 = routine_124(c, v1175_2, v1173_8_tail, s1);
    v1173_8_result = unite(v1173_8_result,v1175_3);
  }
  const Space v1173_8 = std::move(v1173_8_result);
  const Space v1173_9 = unite(v1173_7,v1173_8);
  return v1173_9;
}

static Space routine_125(Context& c, const Path& p0, const Space& s0) {
  Space v1176_11_result;
  for (int v1176_11_label = 1; v1176_11_label <= 2; ++v1176_11_label) {
    const Space v1176_11_tail = child(s0,v1176_11_label);
    if (v1176_11_tail.empty()) continue;
    const Path v1176_11_head{v1176_11_label};
    const Space v1177_2 = singleton(v1176_11_head);
    const Space v1177_3 = intersect(constant_6,v1177_2);
    const Space v1177_4 = (has_head(v1177_3) ? constant_7 : Space{});
    const Space v1177_5 = subtract(constant_0,v1177_4);
    Space v1177_8;
    if (!v1177_5.empty()) {
      const Path v1178_6 = concat_path(p0,v1176_11_head);
      Space v1178_7_result;
      for (int v1178_7_label = 1; v1178_7_label <= 2; ++v1178_7_label) {
        const Space v1178_7_tail = child(v1176_11_tail,v1178_7_label);
        if (v1178_7_tail.empty()) continue;
        const Path v1178_7_head{v1178_7_label};
        const Space v1179_2 = singleton(v1178_7_head);
        const Space v1179_3 = intersect(constant_6,v1179_2);
        const Space v1179_4 = (has_head(v1179_3) ? constant_7 : Space{});
        const Space v1179_5 = subtract(constant_0,v1179_4);
        Space v1179_8;
        if (!v1179_5.empty()) {
          const Path v1180_6 = concat_path(v1178_6,v1178_7_head);
          const Space v1180_7 = routine_175(c, v1180_6, v1178_7_tail);
          v1179_8 = compose(v1179_5,v1180_7);
        }
        const Space v1179_9 = intersect(constant_6,v1179_2);
        const Space v1179_10 = (has_head(v1179_9) ? constant_7 : Space{});
        Space v1179_12;
        if (!v1179_10.empty()) {
          const Path v1181_6 = concat_path(v1178_6,v1178_7_head);
          const Space v1181_11 = routine_176(c, v1181_6, v1178_7_tail);
          v1179_12 = compose(v1179_10,v1181_11);
        }
        const Space v1179_13 = unite(v1179_8,v1179_12);
        v1178_7_result = unite(v1178_7_result,v1179_13);
      }
      const Space v1178_7 = std::move(v1178_7_result);
      v1177_8 = compose(v1177_5,v1178_7);
    }
    const Space v1177_9 = intersect(constant_6,v1177_2);
    const Space v1177_10 = (has_head(v1177_9) ? constant_7 : Space{});
    Space v1177_12;
    if (!v1177_10.empty()) {
      const Path v1182_6 = concat_path(p0,v1176_11_head);
      Space v1182_11_result;
      for (int v1182_11_label = 1; v1182_11_label <= 2; ++v1182_11_label) {
        const Space v1182_11_tail = child(v1176_11_tail,v1182_11_label);
        if (v1182_11_tail.empty()) continue;
        const Path v1182_11_head{v1182_11_label};
        const Space v1183_2 = singleton(v1182_11_head);
        const Space v1183_3 = intersect(constant_6,v1183_2);
        const Space v1183_4 = (has_head(v1183_3) ? constant_7 : Space{});
        const Space v1183_5 = subtract(constant_0,v1183_4);
        Space v1183_8;
        if (!v1183_5.empty()) {
          const Path v1184_6 = concat_path(v1182_6,v1182_11_head);
          const Space v1184_7 = routine_175(c, v1184_6, v1182_11_tail);
          v1183_8 = compose(v1183_5,v1184_7);
        }
        const Space v1183_9 = intersect(constant_6,v1183_2);
        const Space v1183_10 = (has_head(v1183_9) ? constant_7 : Space{});
        Space v1183_12;
        if (!v1183_10.empty()) {
          const Path v1185_6 = concat_path(v1182_6,v1182_11_head);
          const Space v1185_11 = routine_69(c, v1185_6, v1182_11_tail);
          v1183_12 = compose(v1183_10,v1185_11);
        }
        const Space v1183_13 = unite(v1183_8,v1183_12);
        v1182_11_result = unite(v1182_11_result,v1183_13);
      }
      const Space v1182_11 = std::move(v1182_11_result);
      v1177_12 = compose(v1177_10,v1182_11);
    }
    const Space v1177_13 = unite(v1177_8,v1177_12);
    v1176_11_result = unite(v1176_11_result,v1177_13);
  }
  const Space v1176_11 = std::move(v1176_11_result);
  return v1176_11;
}

static Space routine_126(Context& c, const Path& p0, const Space& s0) {
  Space v1186_9_result;
  for (int v1186_9_label = 1; v1186_9_label <= 2; ++v1186_9_label) {
    const Space v1186_9_tail = child(s0,v1186_9_label);
    if (v1186_9_tail.empty()) continue;
    const Path v1186_9_head{v1186_9_label};
    const Space v1187_2 = singleton(v1186_9_head);
    const Space v1187_3 = intersect(constant_6,v1187_2);
    const Space v1187_4 = (has_head(v1187_3) ? constant_7 : Space{});
    const Space v1187_5 = subtract(constant_0,v1187_4);
    Space v1187_8;
    if (!v1187_5.empty()) {
      const Path v1188_6 = concat_path(p0,v1186_9_head);
      Space v1188_7_result;
      for (int v1188_7_label = 1; v1188_7_label <= 2; ++v1188_7_label) {
        const Space v1188_7_tail = child(v1186_9_tail,v1188_7_label);
        if (v1188_7_tail.empty()) continue;
        const Path v1188_7_head{v1188_7_label};
        const Space v1189_2 = singleton(v1188_7_head);
        const Space v1189_3 = intersect(constant_6,v1189_2);
        const Space v1189_4 = (has_head(v1189_3) ? constant_7 : Space{});
        const Space v1189_5 = subtract(constant_0,v1189_4);
        Space v1189_8;
        if (!v1189_5.empty()) {
          const Path v1190_6 = concat_path(v1188_6,v1188_7_head);
          const Space v1190_7 = routine_175(c, v1190_6, v1188_7_tail);
          v1189_8 = compose(v1189_5,v1190_7);
        }
        const Space v1189_9 = intersect(constant_6,v1189_2);
        const Space v1189_10 = (has_head(v1189_9) ? constant_7 : Space{});
        Space v1189_12;
        if (!v1189_10.empty()) {
          const Path v1191_6 = concat_path(v1188_6,v1188_7_head);
          const Space v1191_11 = routine_176(c, v1191_6, v1188_7_tail);
          v1189_12 = compose(v1189_10,v1191_11);
        }
        const Space v1189_13 = unite(v1189_8,v1189_12);
        v1188_7_result = unite(v1188_7_result,v1189_13);
      }
      const Space v1188_7 = std::move(v1188_7_result);
      v1187_8 = compose(v1187_5,v1188_7);
    }
    const Space v1187_9 = intersect(constant_6,v1187_2);
    const Space v1187_10 = (has_head(v1187_9) ? constant_7 : Space{});
    const Space v1187_11 = compose(v1187_10,constant_9);
    const Space v1187_12 = unite(v1187_8,v1187_11);
    v1186_9_result = unite(v1186_9_result,v1187_12);
  }
  const Space v1186_9 = std::move(v1186_9_result);
  return v1186_9;
}

static Space routine_127(Context& c, const Path& p0, const Space& s0) {
  Space v1192_11_result;
  for (int v1192_11_label = 1; v1192_11_label <= 2; ++v1192_11_label) {
    const Space v1192_11_tail = child(s0,v1192_11_label);
    if (v1192_11_tail.empty()) continue;
    const Path v1192_11_head{v1192_11_label};
    const Space v1193_2 = singleton(v1192_11_head);
    const Space v1193_3 = intersect(constant_6,v1193_2);
    const Space v1193_4 = (has_head(v1193_3) ? constant_7 : Space{});
    const Space v1193_5 = subtract(constant_0,v1193_4);
    Space v1193_8;
    if (!v1193_5.empty()) {
      const Path v1194_6 = concat_path(p0,v1192_11_head);
      Space v1194_7_result;
      for (int v1194_7_label = 1; v1194_7_label <= 2; ++v1194_7_label) {
        const Space v1194_7_tail = child(v1192_11_tail,v1194_7_label);
        if (v1194_7_tail.empty()) continue;
        const Path v1194_7_head{v1194_7_label};
        const Space v1195_2 = singleton(v1194_7_head);
        const Space v1195_3 = intersect(constant_6,v1195_2);
        const Space v1195_4 = (has_head(v1195_3) ? constant_7 : Space{});
        const Space v1195_5 = subtract(constant_0,v1195_4);
        Space v1195_8;
        if (!v1195_5.empty()) {
          const Path v1196_6 = concat_path(v1194_6,v1194_7_head);
          const Space v1196_7 = routine_177(c, v1196_6, v1194_7_tail);
          v1195_8 = compose(v1195_5,v1196_7);
        }
        const Space v1195_9 = intersect(constant_6,v1195_2);
        const Space v1195_10 = (has_head(v1195_9) ? constant_7 : Space{});
        Space v1195_12;
        if (!v1195_10.empty()) {
          const Path v1197_6 = concat_path(v1194_6,v1194_7_head);
          const Space v1197_11 = routine_178(c, v1197_6, v1194_7_tail);
          v1195_12 = compose(v1195_10,v1197_11);
        }
        const Space v1195_13 = unite(v1195_8,v1195_12);
        v1194_7_result = unite(v1194_7_result,v1195_13);
      }
      const Space v1194_7 = std::move(v1194_7_result);
      v1193_8 = compose(v1193_5,v1194_7);
    }
    const Space v1193_9 = intersect(constant_6,v1193_2);
    const Space v1193_10 = (has_head(v1193_9) ? constant_7 : Space{});
    Space v1193_12;
    if (!v1193_10.empty()) {
      const Path v1198_6 = concat_path(p0,v1192_11_head);
      Space v1198_11_result;
      for (int v1198_11_label = 1; v1198_11_label <= 2; ++v1198_11_label) {
        const Space v1198_11_tail = child(v1192_11_tail,v1198_11_label);
        if (v1198_11_tail.empty()) continue;
        const Path v1198_11_head{v1198_11_label};
        const Space v1199_2 = singleton(v1198_11_head);
        const Space v1199_3 = intersect(constant_6,v1199_2);
        const Space v1199_4 = (has_head(v1199_3) ? constant_7 : Space{});
        const Space v1199_5 = subtract(constant_0,v1199_4);
        Space v1199_8;
        if (!v1199_5.empty()) {
          const Path v1200_6 = concat_path(v1198_6,v1198_11_head);
          const Space v1200_7 = routine_177(c, v1200_6, v1198_11_tail);
          v1199_8 = compose(v1199_5,v1200_7);
        }
        const Space v1199_9 = intersect(constant_6,v1199_2);
        const Space v1199_10 = (has_head(v1199_9) ? constant_7 : Space{});
        Space v1199_12;
        if (!v1199_10.empty()) {
          const Path v1201_6 = concat_path(v1198_6,v1198_11_head);
          const Space v1201_11 = routine_72(c, v1201_6, v1198_11_tail);
          v1199_12 = compose(v1199_10,v1201_11);
        }
        const Space v1199_13 = unite(v1199_8,v1199_12);
        v1198_11_result = unite(v1198_11_result,v1199_13);
      }
      const Space v1198_11 = std::move(v1198_11_result);
      v1193_12 = compose(v1193_10,v1198_11);
    }
    const Space v1193_13 = unite(v1193_8,v1193_12);
    v1192_11_result = unite(v1192_11_result,v1193_13);
  }
  const Space v1192_11 = std::move(v1192_11_result);
  return v1192_11;
}

static Space routine_128(Context& c, const Path& p0, const Space& s0) {
  Space v1202_9_result;
  for (int v1202_9_label = 1; v1202_9_label <= 2; ++v1202_9_label) {
    const Space v1202_9_tail = child(s0,v1202_9_label);
    if (v1202_9_tail.empty()) continue;
    const Path v1202_9_head{v1202_9_label};
    const Space v1203_2 = singleton(v1202_9_head);
    const Space v1203_3 = intersect(constant_6,v1203_2);
    const Space v1203_4 = (has_head(v1203_3) ? constant_7 : Space{});
    const Space v1203_5 = subtract(constant_0,v1203_4);
    Space v1203_8;
    if (!v1203_5.empty()) {
      const Path v1204_6 = concat_path(p0,v1202_9_head);
      Space v1204_7_result;
      for (int v1204_7_label = 1; v1204_7_label <= 2; ++v1204_7_label) {
        const Space v1204_7_tail = child(v1202_9_tail,v1204_7_label);
        if (v1204_7_tail.empty()) continue;
        const Path v1204_7_head{v1204_7_label};
        const Space v1205_2 = singleton(v1204_7_head);
        const Space v1205_3 = intersect(constant_6,v1205_2);
        const Space v1205_4 = (has_head(v1205_3) ? constant_7 : Space{});
        const Space v1205_5 = subtract(constant_0,v1205_4);
        Space v1205_8;
        if (!v1205_5.empty()) {
          const Path v1206_6 = concat_path(v1204_6,v1204_7_head);
          const Space v1206_7 = routine_177(c, v1206_6, v1204_7_tail);
          v1205_8 = compose(v1205_5,v1206_7);
        }
        const Space v1205_9 = intersect(constant_6,v1205_2);
        const Space v1205_10 = (has_head(v1205_9) ? constant_7 : Space{});
        Space v1205_12;
        if (!v1205_10.empty()) {
          const Path v1207_6 = concat_path(v1204_6,v1204_7_head);
          const Space v1207_11 = routine_178(c, v1207_6, v1204_7_tail);
          v1205_12 = compose(v1205_10,v1207_11);
        }
        const Space v1205_13 = unite(v1205_8,v1205_12);
        v1204_7_result = unite(v1204_7_result,v1205_13);
      }
      const Space v1204_7 = std::move(v1204_7_result);
      v1203_8 = compose(v1203_5,v1204_7);
    }
    const Space v1203_9 = intersect(constant_6,v1203_2);
    const Space v1203_10 = (has_head(v1203_9) ? constant_7 : Space{});
    const Space v1203_11 = compose(v1203_10,constant_9);
    const Space v1203_12 = unite(v1203_8,v1203_11);
    v1202_9_result = unite(v1202_9_result,v1203_12);
  }
  const Space v1202_9 = std::move(v1202_9_result);
  return v1202_9;
}

static Space routine_129(Context& c, const Path& p0, const Space& s0) {
  Space v1208_11_result;
  for (int v1208_11_label = 1; v1208_11_label <= 2; ++v1208_11_label) {
    const Space v1208_11_tail = child(s0,v1208_11_label);
    if (v1208_11_tail.empty()) continue;
    const Path v1208_11_head{v1208_11_label};
    const Space v1209_2 = singleton(v1208_11_head);
    const Space v1209_3 = intersect(constant_6,v1209_2);
    const Space v1209_4 = (has_head(v1209_3) ? constant_7 : Space{});
    const Space v1209_5 = subtract(constant_0,v1209_4);
    Space v1209_8;
    if (!v1209_5.empty()) {
      const Path v1210_6 = concat_path(p0,v1208_11_head);
      Space v1210_7_result;
      for (int v1210_7_label = 1; v1210_7_label <= 2; ++v1210_7_label) {
        const Space v1210_7_tail = child(v1208_11_tail,v1210_7_label);
        if (v1210_7_tail.empty()) continue;
        const Path v1210_7_head{v1210_7_label};
        const Space v1211_2 = singleton(v1210_7_head);
        const Space v1211_3 = intersect(constant_6,v1211_2);
        const Space v1211_4 = (has_head(v1211_3) ? constant_7 : Space{});
        const Space v1211_5 = subtract(constant_0,v1211_4);
        Space v1211_8;
        if (!v1211_5.empty()) {
          const Path v1212_6 = concat_path(v1210_6,v1210_7_head);
          const Space v1212_7 = routine_179(c, v1212_6, v1210_7_tail);
          v1211_8 = compose(v1211_5,v1212_7);
        }
        const Space v1211_9 = intersect(constant_6,v1211_2);
        const Space v1211_10 = (has_head(v1211_9) ? constant_7 : Space{});
        Space v1211_12;
        if (!v1211_10.empty()) {
          const Path v1213_6 = concat_path(v1210_6,v1210_7_head);
          const Space v1213_11 = routine_180(c, v1213_6, v1210_7_tail);
          v1211_12 = compose(v1211_10,v1213_11);
        }
        const Space v1211_13 = unite(v1211_8,v1211_12);
        v1210_7_result = unite(v1210_7_result,v1211_13);
      }
      const Space v1210_7 = std::move(v1210_7_result);
      v1209_8 = compose(v1209_5,v1210_7);
    }
    const Space v1209_9 = intersect(constant_6,v1209_2);
    const Space v1209_10 = (has_head(v1209_9) ? constant_7 : Space{});
    Space v1209_12;
    if (!v1209_10.empty()) {
      const Path v1214_6 = concat_path(p0,v1208_11_head);
      Space v1214_11_result;
      for (int v1214_11_label = 1; v1214_11_label <= 2; ++v1214_11_label) {
        const Space v1214_11_tail = child(v1208_11_tail,v1214_11_label);
        if (v1214_11_tail.empty()) continue;
        const Path v1214_11_head{v1214_11_label};
        const Space v1215_2 = singleton(v1214_11_head);
        const Space v1215_3 = intersect(constant_6,v1215_2);
        const Space v1215_4 = (has_head(v1215_3) ? constant_7 : Space{});
        const Space v1215_5 = subtract(constant_0,v1215_4);
        Space v1215_8;
        if (!v1215_5.empty()) {
          const Path v1216_6 = concat_path(v1214_6,v1214_11_head);
          const Space v1216_7 = routine_179(c, v1216_6, v1214_11_tail);
          v1215_8 = compose(v1215_5,v1216_7);
        }
        const Space v1215_9 = intersect(constant_6,v1215_2);
        const Space v1215_10 = (has_head(v1215_9) ? constant_7 : Space{});
        Space v1215_12;
        if (!v1215_10.empty()) {
          const Path v1217_6 = concat_path(v1214_6,v1214_11_head);
          const Space v1217_11 = routine_75(c, v1217_6, v1214_11_tail);
          v1215_12 = compose(v1215_10,v1217_11);
        }
        const Space v1215_13 = unite(v1215_8,v1215_12);
        v1214_11_result = unite(v1214_11_result,v1215_13);
      }
      const Space v1214_11 = std::move(v1214_11_result);
      v1209_12 = compose(v1209_10,v1214_11);
    }
    const Space v1209_13 = unite(v1209_8,v1209_12);
    v1208_11_result = unite(v1208_11_result,v1209_13);
  }
  const Space v1208_11 = std::move(v1208_11_result);
  return v1208_11;
}

static Space routine_130(Context& c, const Path& p0, const Space& s0) {
  Space v1218_8_result;
  for (int v1218_8_label = 1; v1218_8_label <= 2; ++v1218_8_label) {
    const Space v1218_8_tail = child(s0,v1218_8_label);
    if (v1218_8_tail.empty()) continue;
    const Path v1218_8_head{v1218_8_label};
    const Space v1219_2 = singleton(v1218_8_head);
    const Space v1219_3 = intersect(constant_6,v1219_2);
    const Space v1219_4 = (has_head(v1219_3) ? constant_7 : Space{});
    const Space v1219_5 = subtract(constant_0,v1219_4);
    Space v1219_8;
    if (!v1219_5.empty()) {
      const Path v1220_6 = concat_path(p0,v1218_8_head);
      Space v1220_7_result;
      for (int v1220_7_label = 1; v1220_7_label <= 2; ++v1220_7_label) {
        const Space v1220_7_tail = child(v1218_8_tail,v1220_7_label);
        if (v1220_7_tail.empty()) continue;
        const Path v1220_7_head{v1220_7_label};
        const Space v1221_2 = singleton(v1220_7_head);
        const Space v1221_3 = intersect(constant_6,v1221_2);
        const Space v1221_4 = (has_head(v1221_3) ? constant_7 : Space{});
        const Space v1221_5 = subtract(constant_0,v1221_4);
        Space v1221_8;
        if (!v1221_5.empty()) {
          const Path v1222_6 = concat_path(v1220_6,v1220_7_head);
          const Space v1222_7 = routine_179(c, v1222_6, v1220_7_tail);
          v1221_8 = compose(v1221_5,v1222_7);
        }
        const Space v1221_9 = intersect(constant_6,v1221_2);
        const Space v1221_10 = (has_head(v1221_9) ? constant_7 : Space{});
        Space v1221_12;
        if (!v1221_10.empty()) {
          const Path v1223_6 = concat_path(v1220_6,v1220_7_head);
          const Space v1223_11 = routine_180(c, v1223_6, v1220_7_tail);
          v1221_12 = compose(v1221_10,v1223_11);
        }
        const Space v1221_13 = unite(v1221_8,v1221_12);
        v1220_7_result = unite(v1220_7_result,v1221_13);
      }
      const Space v1220_7 = std::move(v1220_7_result);
      v1219_8 = compose(v1219_5,v1220_7);
    }
    const Space v1219_9 = intersect(constant_6,v1219_2);
    const Space v1219_10 = (has_head(v1219_9) ? constant_7 : Space{});
    const Space v1219_11 = compose(v1219_10,v1218_8_tail);
    const Space v1219_12 = unite(v1219_8,v1219_11);
    v1218_8_result = unite(v1218_8_result,v1219_12);
  }
  const Space v1218_8 = std::move(v1218_8_result);
  return v1218_8;
}

static Space routine_131(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1224_13_result;
  for (int v1224_13_label = 1; v1224_13_label <= 2; ++v1224_13_label) {
    const Space v1224_13_tail = child(s0,v1224_13_label);
    if (v1224_13_tail.empty()) continue;
    const Path v1224_13_head{v1224_13_label};
    const Space v1225_2 = singleton(v1224_13_head);
    const Space v1225_3 = intersect(constant_6,v1225_2);
    const Space v1225_4 = (has_head(v1225_3) ? constant_7 : Space{});
    const Space v1225_5 = subtract(constant_0,v1225_4);
    Space v1225_8;
    if (!v1225_5.empty()) {
      const Path v1226_6 = concat_path(p0,v1224_13_head);
      Space v1226_7_result;
      for (int v1226_7_label = 1; v1226_7_label <= 2; ++v1226_7_label) {
        const Space v1226_7_tail = child(v1224_13_tail,v1226_7_label);
        if (v1226_7_tail.empty()) continue;
        const Path v1226_7_head{v1226_7_label};
        const Space v1227_2 = singleton(v1226_7_head);
        const Space v1227_3 = intersect(constant_6,v1227_2);
        const Space v1227_4 = (has_head(v1227_3) ? constant_7 : Space{});
        const Space v1227_5 = subtract(constant_0,v1227_4);
        Space v1227_8;
        if (!v1227_5.empty()) {
          const Path v1228_6 = concat_path(v1226_6,v1226_7_head);
          const Space v1228_7 = routine_181(c, v1228_6, p1, v1226_7_tail, s1);
          v1227_8 = compose(v1227_5,v1228_7);
        }
        const Space v1227_9 = intersect(constant_6,v1227_2);
        const Space v1227_10 = (has_head(v1227_9) ? constant_7 : Space{});
        Space v1227_12;
        if (!v1227_10.empty()) {
          const Path v1229_6 = concat_path(v1226_6,v1226_7_head);
          const Space v1229_11 = routine_182(c, v1229_6, p1, v1226_7_tail, s1);
          v1227_12 = compose(v1227_10,v1229_11);
        }
        const Space v1227_13 = unite(v1227_8,v1227_12);
        v1226_7_result = unite(v1226_7_result,v1227_13);
      }
      const Space v1226_7 = std::move(v1226_7_result);
      v1225_8 = compose(v1225_5,v1226_7);
    }
    const Space v1225_9 = intersect(constant_6,v1225_2);
    const Space v1225_10 = (has_head(v1225_9) ? constant_7 : Space{});
    Space v1225_12;
    if (!v1225_10.empty()) {
      const Path v1230_6 = concat_path(p0,v1224_13_head);
      Space v1230_11_result;
      for (int v1230_11_label = 1; v1230_11_label <= 2; ++v1230_11_label) {
        const Space v1230_11_tail = child(v1224_13_tail,v1230_11_label);
        if (v1230_11_tail.empty()) continue;
        const Path v1230_11_head{v1230_11_label};
        const Space v1231_2 = singleton(v1230_11_head);
        const Space v1231_3 = intersect(constant_6,v1231_2);
        const Space v1231_4 = (has_head(v1231_3) ? constant_7 : Space{});
        const Space v1231_5 = subtract(constant_0,v1231_4);
        Space v1231_8;
        if (!v1231_5.empty()) {
          const Path v1232_6 = concat_path(v1230_6,v1230_11_head);
          const Space v1232_7 = routine_181(c, v1232_6, p1, v1230_11_tail, s1);
          v1231_8 = compose(v1231_5,v1232_7);
        }
        const Space v1231_9 = intersect(constant_6,v1231_2);
        const Space v1231_10 = (has_head(v1231_9) ? constant_7 : Space{});
        Space v1231_12;
        if (!v1231_10.empty()) {
          const Path v1233_6 = concat_path(v1230_6,v1230_11_head);
          const Space v1233_11 = routine_26(c, v1233_6, p1, v1230_11_tail, s1);
          v1231_12 = compose(v1231_10,v1233_11);
        }
        const Space v1231_13 = unite(v1231_8,v1231_12);
        v1230_11_result = unite(v1230_11_result,v1231_13);
      }
      const Space v1230_11 = std::move(v1230_11_result);
      v1225_12 = compose(v1225_10,v1230_11);
    }
    const Space v1225_13 = unite(v1225_8,v1225_12);
    v1224_13_result = unite(v1224_13_result,v1225_13);
  }
  const Space v1224_13 = std::move(v1224_13_result);
  return v1224_13;
}

static Space routine_132(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1234_8 = unwrap(s1,constant_8);
  Space v1234_21_result;
  for (int v1234_21_label = 1; v1234_21_label <= 2; ++v1234_21_label) {
    const Space v1234_21_tail = child(s0,v1234_21_label);
    if (v1234_21_tail.empty()) continue;
    const Path v1234_21_head{v1234_21_label};
    const Space v1235_2 = singleton(v1234_21_head);
    const Space v1235_3 = intersect(constant_6,v1235_2);
    const Space v1235_4 = (has_head(v1235_3) ? constant_7 : Space{});
    const Space v1235_5 = subtract(constant_0,v1235_4);
    Space v1235_8;
    if (!v1235_5.empty()) {
      const Path v1236_6 = concat_path(p0,v1234_21_head);
      Space v1236_7_result;
      for (int v1236_7_label = 1; v1236_7_label <= 2; ++v1236_7_label) {
        const Space v1236_7_tail = child(v1234_21_tail,v1236_7_label);
        if (v1236_7_tail.empty()) continue;
        const Path v1236_7_head{v1236_7_label};
        const Space v1237_2 = singleton(v1236_7_head);
        const Space v1237_3 = intersect(constant_6,v1237_2);
        const Space v1237_4 = (has_head(v1237_3) ? constant_7 : Space{});
        const Space v1237_5 = subtract(constant_0,v1237_4);
        Space v1237_8;
        if (!v1237_5.empty()) {
          const Path v1238_6 = concat_path(v1236_6,v1236_7_head);
          const Space v1238_7 = routine_181(c, v1238_6, p1, v1236_7_tail, s1);
          v1237_8 = compose(v1237_5,v1238_7);
        }
        const Space v1237_9 = intersect(constant_6,v1237_2);
        const Space v1237_10 = (has_head(v1237_9) ? constant_7 : Space{});
        Space v1237_12;
        if (!v1237_10.empty()) {
          const Path v1239_6 = concat_path(v1236_6,v1236_7_head);
          const Space v1239_11 = routine_182(c, v1239_6, p1, v1236_7_tail, s1);
          v1237_12 = compose(v1237_10,v1239_11);
        }
        const Space v1237_13 = unite(v1237_8,v1237_12);
        v1236_7_result = unite(v1236_7_result,v1237_13);
      }
      const Space v1236_7 = std::move(v1236_7_result);
      v1235_8 = compose(v1235_5,v1236_7);
    }
    const Space v1235_9 = intersect(constant_6,v1235_2);
    const Space v1235_10 = (has_head(v1235_9) ? constant_7 : Space{});
    Space v1235_22;
    if (!v1235_10.empty()) {
      const Path v1240_6 = concat_path(p0,v1234_21_head);
      const Path v1240_11 = concat_path(p1,v1240_6);
      const Space v1240_12 = routine_29(c, v1240_11);
      const Space v1240_13 = intersect(v1234_8,v1240_12);
      const Space v1240_14 = routine_30(c, v1240_13);
      Space v1240_15_result;
      for (int v1240_15_label = 1; v1240_15_label <= 2; ++v1240_15_label) {
        const Space v1240_15_tail = child(v1240_14,v1240_15_label);
        if (v1240_15_tail.empty()) continue;
        const Path v1240_15_head{v1240_15_label};
        const Space v1241_2 = singleton(v1240_15_head);
        const Space v1241_3 = intersect(constant_6,v1241_2);
        const Space v1241_4 = (has_head(v1241_3) ? constant_7 : Space{});
        const Space v1241_5 = subtract(constant_0,v1241_4);
        Space v1241_7;
        if (!v1241_5.empty()) {
          const Space v1242_6 = routine_31(c, v1240_15_head, v1240_15_tail);
          v1241_7 = compose(v1241_5,v1242_6);
        }
        const Space v1241_8 = intersect(constant_6,v1241_2);
        const Space v1241_9 = (has_head(v1241_8) ? constant_7 : Space{});
        Space v1241_11;
        if (!v1241_9.empty()) {
          const Space v1243_10 = routine_32(c, v1240_15_head, v1240_15_tail);
          v1241_11 = compose(v1241_9,v1243_10);
        }
        const Space v1241_12 = unite(v1241_7,v1241_11);
        v1240_15_result = unite(v1240_15_result,v1241_12);
      }
      const Space v1240_15 = std::move(v1240_15_result);
      const Space v1240_16 = routine_33(c, v1240_13);
      Space v1240_17_result;
      for (int v1240_17_label = 1; v1240_17_label <= 2; ++v1240_17_label) {
        const Space v1240_17_tail = child(v1240_16,v1240_17_label);
        if (v1240_17_tail.empty()) continue;
        const Path v1240_17_head{v1240_17_label};
        const Space v1244_2 = singleton(v1240_17_head);
        const Space v1244_3 = intersect(constant_6,v1244_2);
        const Space v1244_4 = (has_head(v1244_3) ? constant_7 : Space{});
        const Space v1244_5 = subtract(constant_0,v1244_4);
        Space v1244_7;
        if (!v1244_5.empty()) {
          const Space v1245_6 = routine_34(c, v1240_17_head, v1240_17_tail);
          v1244_7 = compose(v1244_5,v1245_6);
        }
        const Space v1244_8 = intersect(constant_6,v1244_2);
        const Space v1244_9 = (has_head(v1244_8) ? constant_7 : Space{});
        Space v1244_11;
        if (!v1244_9.empty()) {
          const Space v1246_10 = routine_35(c, v1240_17_head, v1240_17_tail);
          v1244_11 = compose(v1244_9,v1246_10);
        }
        const Space v1244_12 = unite(v1244_7,v1244_11);
        v1240_17_result = unite(v1240_17_result,v1244_12);
      }
      const Space v1240_17 = std::move(v1240_17_result);
      const Space v1240_18 = subtract(v1240_15,v1240_17);
      const Space v1240_19 = singleton(v1240_11);
      const Space v1240_20 = compose(v1240_18,v1240_19);
      Space v1240_21_result;
      for (int v1240_21_label = 1; v1240_21_label <= 2; ++v1240_21_label) {
        const Space v1240_21_tail = child(v1240_20,v1240_21_label);
        if (v1240_21_tail.empty()) continue;
        const Path v1240_21_head{v1240_21_label};
        const Space v1247_2 = singleton(v1240_21_head);
        const Space v1247_3 = intersect(constant_6,v1247_2);
        const Space v1247_4 = (has_head(v1247_3) ? constant_7 : Space{});
        const Space v1247_5 = subtract(constant_0,v1247_4);
        Space v1247_7;
        if (!v1247_5.empty()) {
          const Space v1248_6 = routine_36(c, v1240_21_head, v1240_21_tail);
          v1247_7 = compose(v1247_5,v1248_6);
        }
        const Space v1247_8 = intersect(constant_6,v1247_2);
        const Space v1247_9 = (has_head(v1247_8) ? constant_7 : Space{});
        Space v1247_11;
        if (!v1247_9.empty()) {
          const Space v1249_10 = routine_37(c, v1240_21_head, v1240_21_tail);
          v1247_11 = compose(v1247_9,v1249_10);
        }
        const Space v1247_12 = unite(v1247_7,v1247_11);
        v1240_21_result = unite(v1240_21_result,v1247_12);
      }
      const Space v1240_21 = std::move(v1240_21_result);
      v1235_22 = compose(v1235_10,v1240_21);
    }
    const Space v1235_23 = unite(v1235_8,v1235_22);
    v1234_21_result = unite(v1234_21_result,v1235_23);
  }
  const Space v1234_21 = std::move(v1234_21_result);
  return v1234_21;
}

static Space routine_133(Context& c, const Path& p0, const Space& s0) {
  Space v1250_11_result;
  for (int v1250_11_label = 1; v1250_11_label <= 2; ++v1250_11_label) {
    const Space v1250_11_tail = child(s0,v1250_11_label);
    if (v1250_11_tail.empty()) continue;
    const Path v1250_11_head{v1250_11_label};
    const Space v1251_2 = singleton(v1250_11_head);
    const Space v1251_3 = intersect(constant_6,v1251_2);
    const Space v1251_4 = (has_head(v1251_3) ? constant_7 : Space{});
    const Space v1251_5 = subtract(constant_0,v1251_4);
    Space v1251_8;
    if (!v1251_5.empty()) {
      const Path v1252_6 = concat_path(p0,v1250_11_head);
      Space v1252_7_result;
      for (int v1252_7_label = 1; v1252_7_label <= 2; ++v1252_7_label) {
        const Space v1252_7_tail = child(v1250_11_tail,v1252_7_label);
        if (v1252_7_tail.empty()) continue;
        const Path v1252_7_head{v1252_7_label};
        const Space v1253_2 = singleton(v1252_7_head);
        const Space v1253_3 = intersect(constant_6,v1253_2);
        const Space v1253_4 = (has_head(v1253_3) ? constant_7 : Space{});
        const Space v1253_5 = subtract(constant_0,v1253_4);
        Space v1253_8;
        if (!v1253_5.empty()) {
          const Path v1254_6 = concat_path(v1252_6,v1252_7_head);
          const Space v1254_7 = routine_183(c, v1254_6, v1252_7_tail);
          v1253_8 = compose(v1253_5,v1254_7);
        }
        const Space v1253_9 = intersect(constant_6,v1253_2);
        const Space v1253_10 = (has_head(v1253_9) ? constant_7 : Space{});
        Space v1253_12;
        if (!v1253_10.empty()) {
          const Path v1255_6 = concat_path(v1252_6,v1252_7_head);
          const Space v1255_11 = routine_184(c, v1255_6, v1252_7_tail);
          v1253_12 = compose(v1253_10,v1255_11);
        }
        const Space v1253_13 = unite(v1253_8,v1253_12);
        v1252_7_result = unite(v1252_7_result,v1253_13);
      }
      const Space v1252_7 = std::move(v1252_7_result);
      v1251_8 = compose(v1251_5,v1252_7);
    }
    const Space v1251_9 = intersect(constant_6,v1251_2);
    const Space v1251_10 = (has_head(v1251_9) ? constant_7 : Space{});
    Space v1251_12;
    if (!v1251_10.empty()) {
      const Path v1256_6 = concat_path(p0,v1250_11_head);
      Space v1256_11_result;
      for (int v1256_11_label = 1; v1256_11_label <= 2; ++v1256_11_label) {
        const Space v1256_11_tail = child(v1250_11_tail,v1256_11_label);
        if (v1256_11_tail.empty()) continue;
        const Path v1256_11_head{v1256_11_label};
        const Space v1257_2 = singleton(v1256_11_head);
        const Space v1257_3 = intersect(constant_6,v1257_2);
        const Space v1257_4 = (has_head(v1257_3) ? constant_7 : Space{});
        const Space v1257_5 = subtract(constant_0,v1257_4);
        Space v1257_8;
        if (!v1257_5.empty()) {
          const Path v1258_6 = concat_path(v1256_6,v1256_11_head);
          const Space v1258_7 = routine_183(c, v1258_6, v1256_11_tail);
          v1257_8 = compose(v1257_5,v1258_7);
        }
        const Space v1257_9 = intersect(constant_6,v1257_2);
        const Space v1257_10 = (has_head(v1257_9) ? constant_7 : Space{});
        Space v1257_12;
        if (!v1257_10.empty()) {
          const Path v1259_6 = concat_path(v1256_6,v1256_11_head);
          const Space v1259_11 = routine_80(c, v1259_6, v1256_11_tail);
          v1257_12 = compose(v1257_10,v1259_11);
        }
        const Space v1257_13 = unite(v1257_8,v1257_12);
        v1256_11_result = unite(v1256_11_result,v1257_13);
      }
      const Space v1256_11 = std::move(v1256_11_result);
      v1251_12 = compose(v1251_10,v1256_11);
    }
    const Space v1251_13 = unite(v1251_8,v1251_12);
    v1250_11_result = unite(v1250_11_result,v1251_13);
  }
  const Space v1250_11 = std::move(v1250_11_result);
  return v1250_11;
}

static Space routine_134(Context& c, const Path& p0, const Space& s0) {
  Space v1260_11_result;
  for (int v1260_11_label = 1; v1260_11_label <= 2; ++v1260_11_label) {
    const Space v1260_11_tail = child(s0,v1260_11_label);
    if (v1260_11_tail.empty()) continue;
    const Path v1260_11_head{v1260_11_label};
    const Space v1261_2 = singleton(v1260_11_head);
    const Space v1261_3 = intersect(constant_6,v1261_2);
    const Space v1261_4 = (has_head(v1261_3) ? constant_7 : Space{});
    const Space v1261_5 = subtract(constant_0,v1261_4);
    Space v1261_8;
    if (!v1261_5.empty()) {
      const Path v1262_6 = concat_path(p0,v1260_11_head);
      Space v1262_7_result;
      for (int v1262_7_label = 1; v1262_7_label <= 2; ++v1262_7_label) {
        const Space v1262_7_tail = child(v1260_11_tail,v1262_7_label);
        if (v1262_7_tail.empty()) continue;
        const Path v1262_7_head{v1262_7_label};
        const Space v1263_2 = singleton(v1262_7_head);
        const Space v1263_3 = intersect(constant_6,v1263_2);
        const Space v1263_4 = (has_head(v1263_3) ? constant_7 : Space{});
        const Space v1263_5 = subtract(constant_0,v1263_4);
        Space v1263_8;
        if (!v1263_5.empty()) {
          const Path v1264_6 = concat_path(v1262_6,v1262_7_head);
          const Space v1264_7 = routine_183(c, v1264_6, v1262_7_tail);
          v1263_8 = compose(v1263_5,v1264_7);
        }
        const Space v1263_9 = intersect(constant_6,v1263_2);
        const Space v1263_10 = (has_head(v1263_9) ? constant_7 : Space{});
        Space v1263_12;
        if (!v1263_10.empty()) {
          const Path v1265_6 = concat_path(v1262_6,v1262_7_head);
          const Space v1265_11 = routine_184(c, v1265_6, v1262_7_tail);
          v1263_12 = compose(v1263_10,v1265_11);
        }
        const Space v1263_13 = unite(v1263_8,v1263_12);
        v1262_7_result = unite(v1262_7_result,v1263_13);
      }
      const Space v1262_7 = std::move(v1262_7_result);
      v1261_8 = compose(v1261_5,v1262_7);
    }
    const Space v1261_9 = intersect(constant_6,v1261_2);
    const Space v1261_10 = (has_head(v1261_9) ? constant_7 : Space{});
    Space v1261_12;
    if (!v1261_10.empty()) {
      const Path v1266_6 = concat_path(p0,v1260_11_head);
      Space v1266_11_result;
      for (int v1266_11_label = 1; v1266_11_label <= 2; ++v1266_11_label) {
        const Space v1266_11_tail = child(v1260_11_tail,v1266_11_label);
        if (v1266_11_tail.empty()) continue;
        const Path v1266_11_head{v1266_11_label};
        const Space v1267_2 = singleton(v1266_11_head);
        const Space v1267_3 = intersect(constant_6,v1267_2);
        const Space v1267_4 = (has_head(v1267_3) ? constant_7 : Space{});
        const Space v1267_5 = subtract(constant_0,v1267_4);
        Space v1267_7;
        if (!v1267_5.empty()) {
          const Space v1268_6 = routine_122(c, v1266_11_head, v1266_6, v1266_11_tail);
          v1267_7 = compose(v1267_5,v1268_6);
        }
        const Space v1267_8 = intersect(constant_6,v1267_2);
        const Space v1267_9 = (has_head(v1267_8) ? constant_7 : Space{});
        Space v1267_11;
        if (!v1267_9.empty()) {
          const Space v1269_10 = routine_123(c, v1266_11_head, v1266_6, v1266_11_tail);
          v1267_11 = compose(v1267_9,v1269_10);
        }
        const Space v1267_12 = unite(v1267_7,v1267_11);
        v1266_11_result = unite(v1266_11_result,v1267_12);
      }
      const Space v1266_11 = std::move(v1266_11_result);
      v1261_12 = compose(v1261_10,v1266_11);
    }
    const Space v1261_13 = unite(v1261_8,v1261_12);
    v1260_11_result = unite(v1260_11_result,v1261_13);
  }
  const Space v1260_11 = std::move(v1260_11_result);
  return v1260_11;
}

static Space routine_135(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1270_12_result;
  for (int v1270_12_label = 1; v1270_12_label <= 2; ++v1270_12_label) {
    const Space v1270_12_tail = child(s0,v1270_12_label);
    if (v1270_12_tail.empty()) continue;
    const Path v1270_12_head{v1270_12_label};
    const Space v1271_2 = singleton(v1270_12_head);
    const Space v1271_3 = intersect(constant_6,v1271_2);
    const Space v1271_4 = (has_head(v1271_3) ? constant_7 : Space{});
    const Space v1271_5 = subtract(constant_0,v1271_4);
    Space v1271_8;
    if (!v1271_5.empty()) {
      const Path v1272_6 = concat_path(p0,v1270_12_head);
      Space v1272_7_result;
      for (int v1272_7_label = 1; v1272_7_label <= 2; ++v1272_7_label) {
        const Space v1272_7_tail = child(v1270_12_tail,v1272_7_label);
        if (v1272_7_tail.empty()) continue;
        const Path v1272_7_head{v1272_7_label};
        const Space v1273_2 = singleton(v1272_7_head);
        const Space v1273_3 = intersect(constant_6,v1273_2);
        const Space v1273_4 = (has_head(v1273_3) ? constant_7 : Space{});
        const Space v1273_5 = subtract(constant_0,v1273_4);
        Space v1273_8;
        if (!v1273_5.empty()) {
          const Path v1274_6 = concat_path(v1272_6,v1272_7_head);
          const Space v1274_7 = routine_185(c, v1274_6, p1, v1272_7_tail);
          v1273_8 = compose(v1273_5,v1274_7);
        }
        const Space v1273_9 = intersect(constant_6,v1273_2);
        const Space v1273_10 = (has_head(v1273_9) ? constant_7 : Space{});
        Space v1273_12;
        if (!v1273_10.empty()) {
          const Path v1275_6 = concat_path(v1272_6,v1272_7_head);
          const Space v1275_11 = routine_186(c, v1275_6, p1, v1272_7_tail);
          v1273_12 = compose(v1273_10,v1275_11);
        }
        const Space v1273_13 = unite(v1273_8,v1273_12);
        v1272_7_result = unite(v1272_7_result,v1273_13);
      }
      const Space v1272_7 = std::move(v1272_7_result);
      v1271_8 = compose(v1271_5,v1272_7);
    }
    const Space v1271_9 = intersect(constant_6,v1271_2);
    const Space v1271_10 = (has_head(v1271_9) ? constant_7 : Space{});
    Space v1271_12;
    if (!v1271_10.empty()) {
      const Path v1276_6 = concat_path(p0,v1270_12_head);
      Space v1276_11_result;
      for (int v1276_11_label = 1; v1276_11_label <= 2; ++v1276_11_label) {
        const Space v1276_11_tail = child(v1270_12_tail,v1276_11_label);
        if (v1276_11_tail.empty()) continue;
        const Path v1276_11_head{v1276_11_label};
        const Space v1277_2 = singleton(v1276_11_head);
        const Space v1277_3 = intersect(constant_6,v1277_2);
        const Space v1277_4 = (has_head(v1277_3) ? constant_7 : Space{});
        const Space v1277_5 = subtract(constant_0,v1277_4);
        Space v1277_8;
        if (!v1277_5.empty()) {
          const Path v1278_6 = concat_path(v1276_6,v1276_11_head);
          const Space v1278_7 = routine_185(c, v1278_6, p1, v1276_11_tail);
          v1277_8 = compose(v1277_5,v1278_7);
        }
        const Space v1277_9 = intersect(constant_6,v1277_2);
        const Space v1277_10 = (has_head(v1277_9) ? constant_7 : Space{});
        Space v1277_12;
        if (!v1277_10.empty()) {
          const Path v1279_6 = concat_path(v1276_6,v1276_11_head);
          const Space v1279_11 = routine_137(c, v1279_6, p1, v1276_11_tail);
          v1277_12 = compose(v1277_10,v1279_11);
        }
        const Space v1277_13 = unite(v1277_8,v1277_12);
        v1276_11_result = unite(v1276_11_result,v1277_13);
      }
      const Space v1276_11 = std::move(v1276_11_result);
      v1271_12 = compose(v1271_10,v1276_11);
    }
    const Space v1271_13 = unite(v1271_8,v1271_12);
    v1270_12_result = unite(v1270_12_result,v1271_13);
  }
  const Space v1270_12 = std::move(v1270_12_result);
  return v1270_12;
}

static Space routine_136(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1280_7 = unwrap(constant_12,p1);
  const Space v1280_9 = unwrap(constant_12,p0);
  Space v1280_13_result;
  for (int v1280_13_label = 1; v1280_13_label <= 2; ++v1280_13_label) {
    const Space v1280_13_tail = child(s0,v1280_13_label);
    if (v1280_13_tail.empty()) continue;
    const Path v1280_13_head{v1280_13_label};
    const Space v1281_2 = singleton(v1280_13_head);
    const Space v1281_3 = intersect(constant_6,v1281_2);
    const Space v1281_4 = (has_head(v1281_3) ? constant_7 : Space{});
    const Space v1281_5 = subtract(constant_0,v1281_4);
    Space v1281_8;
    if (!v1281_5.empty()) {
      const Path v1282_6 = concat_path(p0,v1280_13_head);
      Space v1282_7_result;
      for (int v1282_7_label = 1; v1282_7_label <= 2; ++v1282_7_label) {
        const Space v1282_7_tail = child(v1280_13_tail,v1282_7_label);
        if (v1282_7_tail.empty()) continue;
        const Path v1282_7_head{v1282_7_label};
        const Space v1283_2 = singleton(v1282_7_head);
        const Space v1283_3 = intersect(constant_6,v1283_2);
        const Space v1283_4 = (has_head(v1283_3) ? constant_7 : Space{});
        const Space v1283_5 = subtract(constant_0,v1283_4);
        Space v1283_8;
        if (!v1283_5.empty()) {
          const Path v1284_6 = concat_path(v1282_6,v1282_7_head);
          const Space v1284_7 = routine_185(c, v1284_6, p1, v1282_7_tail);
          v1283_8 = compose(v1283_5,v1284_7);
        }
        const Space v1283_9 = intersect(constant_6,v1283_2);
        const Space v1283_10 = (has_head(v1283_9) ? constant_7 : Space{});
        Space v1283_12;
        if (!v1283_10.empty()) {
          const Path v1285_6 = concat_path(v1282_6,v1282_7_head);
          const Space v1285_11 = routine_186(c, v1285_6, p1, v1282_7_tail);
          v1283_12 = compose(v1283_10,v1285_11);
        }
        const Space v1283_13 = unite(v1283_8,v1283_12);
        v1282_7_result = unite(v1282_7_result,v1283_13);
      }
      const Space v1282_7 = std::move(v1282_7_result);
      v1281_8 = compose(v1281_5,v1282_7);
    }
    const Space v1281_9 = intersect(constant_6,v1281_2);
    const Space v1281_10 = (has_head(v1281_9) ? constant_7 : Space{});
    const Space v1281_11 = unwrap(v1280_9,v1280_13_head);
    const Space v1281_12 = compose(v1280_7,v1281_11);
    const Path v1286_6 = concat_path(p0,v1280_13_head);
    const Path v1281_13 = concat_path(p1,v1286_6);
    const Space v1281_14 = singleton(v1281_13);
    const Space v1281_15 = subtract(v1281_12,v1281_14);
    const Space v1281_16 = compose(v1281_10,v1281_15);
    const Space v1281_17 = unite(v1281_8,v1281_16);
    v1280_13_result = unite(v1280_13_result,v1281_17);
  }
  const Space v1280_13 = std::move(v1280_13_result);
  return v1280_13;
}

static Space routine_137(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1287_4 = unwrap(constant_12,p1);
  const Space v1287_6 = unwrap(constant_12,p0);
  const Space v1287_7 = compose(v1287_4,v1287_6);
  const Path v1287_8 = concat_path(p1,p0);
  const Space v1287_9 = singleton(v1287_8);
  const Space v1287_10 = subtract(v1287_7,v1287_9);
  return v1287_10;
}

static Space routine_138(Context& c, const Path& p0, const Space& s0) {
  const Space v1288_3 = unwrap(s0,p0);
  const Space v1288_4 = first_matching(v1288_3,constant_0,false);
  const Space v1288_5 = intersect(constant_0,v1288_4);
  const Space v1288_6 = (has_head(v1288_4) ? constant_7 : Space{});
  const Space v1288_7 = unite(v1288_5,v1288_6);
  const Space v1288_9 = compose(v1288_7,constant_0);
  const Space v1288_11 = subtract(constant_0,v1288_4);
  const Space v1288_12 = subtract(v1288_11,v1288_6);
  Space v1288_16;
  if (!v1288_12.empty()) {
    const Space v1289_14 = first_listed(v1288_3,constant_11,true);
    const Space v1289_15 = routine_124(c, constant_10, v1289_14, v1288_3);
    v1288_16 = compose(v1288_12,v1289_15);
  }
  const Space v1288_17 = unite(v1288_9,v1288_16);
  const Space v1288_18 = wrap(v1288_17,p0);
  return v1288_18;
}

static Space routine_139(Context& c, const Path& p0, const Space& s0) {
  Space v1290_11_result;
  for (int v1290_11_label = 1; v1290_11_label <= 2; ++v1290_11_label) {
    const Space v1290_11_tail = child(s0,v1290_11_label);
    if (v1290_11_tail.empty()) continue;
    const Path v1290_11_head{v1290_11_label};
    const Space v1291_2 = singleton(v1290_11_head);
    const Space v1291_3 = intersect(constant_6,v1291_2);
    const Space v1291_4 = (has_head(v1291_3) ? constant_7 : Space{});
    const Space v1291_5 = subtract(constant_0,v1291_4);
    Space v1291_8;
    if (!v1291_5.empty()) {
      const Path v1292_6 = concat_path(p0,v1290_11_head);
      Space v1292_7_result;
      for (int v1292_7_label = 1; v1292_7_label <= 2; ++v1292_7_label) {
        const Space v1292_7_tail = child(v1290_11_tail,v1292_7_label);
        if (v1292_7_tail.empty()) continue;
        const Path v1292_7_head{v1292_7_label};
        const Space v1293_2 = singleton(v1292_7_head);
        const Space v1293_3 = intersect(constant_6,v1293_2);
        const Space v1293_4 = (has_head(v1293_3) ? constant_7 : Space{});
        const Space v1293_5 = subtract(constant_0,v1293_4);
        Space v1293_8;
        if (!v1293_5.empty()) {
          const Path v1294_6 = concat_path(v1292_6,v1292_7_head);
          const Space v1294_7 = routine_187(c, v1294_6, v1292_7_tail);
          v1293_8 = compose(v1293_5,v1294_7);
        }
        const Space v1293_9 = intersect(constant_6,v1293_2);
        const Space v1293_10 = (has_head(v1293_9) ? constant_7 : Space{});
        Space v1293_12;
        if (!v1293_10.empty()) {
          const Path v1295_6 = concat_path(v1292_6,v1292_7_head);
          const Space v1295_11 = routine_188(c, v1295_6, v1292_7_tail);
          v1293_12 = compose(v1293_10,v1295_11);
        }
        const Space v1293_13 = unite(v1293_8,v1293_12);
        v1292_7_result = unite(v1292_7_result,v1293_13);
      }
      const Space v1292_7 = std::move(v1292_7_result);
      v1291_8 = compose(v1291_5,v1292_7);
    }
    const Space v1291_9 = intersect(constant_6,v1291_2);
    const Space v1291_10 = (has_head(v1291_9) ? constant_7 : Space{});
    Space v1291_12;
    if (!v1291_10.empty()) {
      const Path v1296_6 = concat_path(p0,v1290_11_head);
      Space v1296_11_result;
      for (int v1296_11_label = 1; v1296_11_label <= 2; ++v1296_11_label) {
        const Space v1296_11_tail = child(v1290_11_tail,v1296_11_label);
        if (v1296_11_tail.empty()) continue;
        const Path v1296_11_head{v1296_11_label};
        const Space v1297_2 = singleton(v1296_11_head);
        const Space v1297_3 = intersect(constant_6,v1297_2);
        const Space v1297_4 = (has_head(v1297_3) ? constant_7 : Space{});
        const Space v1297_5 = subtract(constant_0,v1297_4);
        Space v1297_8;
        if (!v1297_5.empty()) {
          const Path v1298_6 = concat_path(v1296_6,v1296_11_head);
          const Space v1298_7 = routine_187(c, v1298_6, v1296_11_tail);
          v1297_8 = compose(v1297_5,v1298_7);
        }
        const Space v1297_9 = intersect(constant_6,v1297_2);
        const Space v1297_10 = (has_head(v1297_9) ? constant_7 : Space{});
        Space v1297_12;
        if (!v1297_10.empty()) {
          const Path v1299_6 = concat_path(v1296_6,v1296_11_head);
          const Space v1299_11 = routine_69(c, v1299_6, v1296_11_tail);
          v1297_12 = compose(v1297_10,v1299_11);
        }
        const Space v1297_13 = unite(v1297_8,v1297_12);
        v1296_11_result = unite(v1296_11_result,v1297_13);
      }
      const Space v1296_11 = std::move(v1296_11_result);
      v1291_12 = compose(v1291_10,v1296_11);
    }
    const Space v1291_13 = unite(v1291_8,v1291_12);
    v1290_11_result = unite(v1290_11_result,v1291_13);
  }
  const Space v1290_11 = std::move(v1290_11_result);
  return v1290_11;
}

static Space routine_140(Context& c, const Path& p0, const Space& s0) {
  Space v1300_9_result;
  for (int v1300_9_label = 1; v1300_9_label <= 2; ++v1300_9_label) {
    const Space v1300_9_tail = child(s0,v1300_9_label);
    if (v1300_9_tail.empty()) continue;
    const Path v1300_9_head{v1300_9_label};
    const Space v1301_2 = singleton(v1300_9_head);
    const Space v1301_3 = intersect(constant_6,v1301_2);
    const Space v1301_4 = (has_head(v1301_3) ? constant_7 : Space{});
    const Space v1301_5 = subtract(constant_0,v1301_4);
    Space v1301_8;
    if (!v1301_5.empty()) {
      const Path v1302_6 = concat_path(p0,v1300_9_head);
      Space v1302_7_result;
      for (int v1302_7_label = 1; v1302_7_label <= 2; ++v1302_7_label) {
        const Space v1302_7_tail = child(v1300_9_tail,v1302_7_label);
        if (v1302_7_tail.empty()) continue;
        const Path v1302_7_head{v1302_7_label};
        const Space v1303_2 = singleton(v1302_7_head);
        const Space v1303_3 = intersect(constant_6,v1303_2);
        const Space v1303_4 = (has_head(v1303_3) ? constant_7 : Space{});
        const Space v1303_5 = subtract(constant_0,v1303_4);
        Space v1303_8;
        if (!v1303_5.empty()) {
          const Path v1304_6 = concat_path(v1302_6,v1302_7_head);
          const Space v1304_7 = routine_187(c, v1304_6, v1302_7_tail);
          v1303_8 = compose(v1303_5,v1304_7);
        }
        const Space v1303_9 = intersect(constant_6,v1303_2);
        const Space v1303_10 = (has_head(v1303_9) ? constant_7 : Space{});
        Space v1303_12;
        if (!v1303_10.empty()) {
          const Path v1305_6 = concat_path(v1302_6,v1302_7_head);
          const Space v1305_11 = routine_188(c, v1305_6, v1302_7_tail);
          v1303_12 = compose(v1303_10,v1305_11);
        }
        const Space v1303_13 = unite(v1303_8,v1303_12);
        v1302_7_result = unite(v1302_7_result,v1303_13);
      }
      const Space v1302_7 = std::move(v1302_7_result);
      v1301_8 = compose(v1301_5,v1302_7);
    }
    const Space v1301_9 = intersect(constant_6,v1301_2);
    const Space v1301_10 = (has_head(v1301_9) ? constant_7 : Space{});
    const Space v1301_11 = compose(v1301_10,constant_9);
    const Space v1301_12 = unite(v1301_8,v1301_11);
    v1300_9_result = unite(v1300_9_result,v1301_12);
  }
  const Space v1300_9 = std::move(v1300_9_result);
  return v1300_9;
}

static Space routine_141(Context& c, const Path& p0, const Space& s0) {
  Space v1306_11_result;
  for (int v1306_11_label = 1; v1306_11_label <= 2; ++v1306_11_label) {
    const Space v1306_11_tail = child(s0,v1306_11_label);
    if (v1306_11_tail.empty()) continue;
    const Path v1306_11_head{v1306_11_label};
    const Space v1307_2 = singleton(v1306_11_head);
    const Space v1307_3 = intersect(constant_6,v1307_2);
    const Space v1307_4 = (has_head(v1307_3) ? constant_7 : Space{});
    const Space v1307_5 = subtract(constant_0,v1307_4);
    Space v1307_8;
    if (!v1307_5.empty()) {
      const Path v1308_6 = concat_path(p0,v1306_11_head);
      Space v1308_7_result;
      for (int v1308_7_label = 1; v1308_7_label <= 2; ++v1308_7_label) {
        const Space v1308_7_tail = child(v1306_11_tail,v1308_7_label);
        if (v1308_7_tail.empty()) continue;
        const Path v1308_7_head{v1308_7_label};
        const Space v1309_2 = singleton(v1308_7_head);
        const Space v1309_3 = intersect(constant_6,v1309_2);
        const Space v1309_4 = (has_head(v1309_3) ? constant_7 : Space{});
        const Space v1309_5 = subtract(constant_0,v1309_4);
        Space v1309_8;
        if (!v1309_5.empty()) {
          const Path v1310_6 = concat_path(v1308_6,v1308_7_head);
          const Space v1310_7 = routine_189(c, v1310_6, v1308_7_tail);
          v1309_8 = compose(v1309_5,v1310_7);
        }
        const Space v1309_9 = intersect(constant_6,v1309_2);
        const Space v1309_10 = (has_head(v1309_9) ? constant_7 : Space{});
        Space v1309_12;
        if (!v1309_10.empty()) {
          const Path v1311_6 = concat_path(v1308_6,v1308_7_head);
          const Space v1311_11 = routine_190(c, v1311_6, v1308_7_tail);
          v1309_12 = compose(v1309_10,v1311_11);
        }
        const Space v1309_13 = unite(v1309_8,v1309_12);
        v1308_7_result = unite(v1308_7_result,v1309_13);
      }
      const Space v1308_7 = std::move(v1308_7_result);
      v1307_8 = compose(v1307_5,v1308_7);
    }
    const Space v1307_9 = intersect(constant_6,v1307_2);
    const Space v1307_10 = (has_head(v1307_9) ? constant_7 : Space{});
    Space v1307_12;
    if (!v1307_10.empty()) {
      const Path v1312_6 = concat_path(p0,v1306_11_head);
      Space v1312_11_result;
      for (int v1312_11_label = 1; v1312_11_label <= 2; ++v1312_11_label) {
        const Space v1312_11_tail = child(v1306_11_tail,v1312_11_label);
        if (v1312_11_tail.empty()) continue;
        const Path v1312_11_head{v1312_11_label};
        const Space v1313_2 = singleton(v1312_11_head);
        const Space v1313_3 = intersect(constant_6,v1313_2);
        const Space v1313_4 = (has_head(v1313_3) ? constant_7 : Space{});
        const Space v1313_5 = subtract(constant_0,v1313_4);
        Space v1313_8;
        if (!v1313_5.empty()) {
          const Path v1314_6 = concat_path(v1312_6,v1312_11_head);
          const Space v1314_7 = routine_189(c, v1314_6, v1312_11_tail);
          v1313_8 = compose(v1313_5,v1314_7);
        }
        const Space v1313_9 = intersect(constant_6,v1313_2);
        const Space v1313_10 = (has_head(v1313_9) ? constant_7 : Space{});
        Space v1313_12;
        if (!v1313_10.empty()) {
          const Path v1315_6 = concat_path(v1312_6,v1312_11_head);
          const Space v1315_11 = routine_72(c, v1315_6, v1312_11_tail);
          v1313_12 = compose(v1313_10,v1315_11);
        }
        const Space v1313_13 = unite(v1313_8,v1313_12);
        v1312_11_result = unite(v1312_11_result,v1313_13);
      }
      const Space v1312_11 = std::move(v1312_11_result);
      v1307_12 = compose(v1307_10,v1312_11);
    }
    const Space v1307_13 = unite(v1307_8,v1307_12);
    v1306_11_result = unite(v1306_11_result,v1307_13);
  }
  const Space v1306_11 = std::move(v1306_11_result);
  return v1306_11;
}

static Space routine_142(Context& c, const Path& p0, const Space& s0) {
  Space v1316_9_result;
  for (int v1316_9_label = 1; v1316_9_label <= 2; ++v1316_9_label) {
    const Space v1316_9_tail = child(s0,v1316_9_label);
    if (v1316_9_tail.empty()) continue;
    const Path v1316_9_head{v1316_9_label};
    const Space v1317_2 = singleton(v1316_9_head);
    const Space v1317_3 = intersect(constant_6,v1317_2);
    const Space v1317_4 = (has_head(v1317_3) ? constant_7 : Space{});
    const Space v1317_5 = subtract(constant_0,v1317_4);
    Space v1317_8;
    if (!v1317_5.empty()) {
      const Path v1318_6 = concat_path(p0,v1316_9_head);
      Space v1318_7_result;
      for (int v1318_7_label = 1; v1318_7_label <= 2; ++v1318_7_label) {
        const Space v1318_7_tail = child(v1316_9_tail,v1318_7_label);
        if (v1318_7_tail.empty()) continue;
        const Path v1318_7_head{v1318_7_label};
        const Space v1319_2 = singleton(v1318_7_head);
        const Space v1319_3 = intersect(constant_6,v1319_2);
        const Space v1319_4 = (has_head(v1319_3) ? constant_7 : Space{});
        const Space v1319_5 = subtract(constant_0,v1319_4);
        Space v1319_8;
        if (!v1319_5.empty()) {
          const Path v1320_6 = concat_path(v1318_6,v1318_7_head);
          const Space v1320_7 = routine_189(c, v1320_6, v1318_7_tail);
          v1319_8 = compose(v1319_5,v1320_7);
        }
        const Space v1319_9 = intersect(constant_6,v1319_2);
        const Space v1319_10 = (has_head(v1319_9) ? constant_7 : Space{});
        Space v1319_12;
        if (!v1319_10.empty()) {
          const Path v1321_6 = concat_path(v1318_6,v1318_7_head);
          const Space v1321_11 = routine_190(c, v1321_6, v1318_7_tail);
          v1319_12 = compose(v1319_10,v1321_11);
        }
        const Space v1319_13 = unite(v1319_8,v1319_12);
        v1318_7_result = unite(v1318_7_result,v1319_13);
      }
      const Space v1318_7 = std::move(v1318_7_result);
      v1317_8 = compose(v1317_5,v1318_7);
    }
    const Space v1317_9 = intersect(constant_6,v1317_2);
    const Space v1317_10 = (has_head(v1317_9) ? constant_7 : Space{});
    const Space v1317_11 = compose(v1317_10,constant_9);
    const Space v1317_12 = unite(v1317_8,v1317_11);
    v1316_9_result = unite(v1316_9_result,v1317_12);
  }
  const Space v1316_9 = std::move(v1316_9_result);
  return v1316_9;
}

static Space routine_143(Context& c, const Path& p0, const Space& s0) {
  Space v1322_11_result;
  for (int v1322_11_label = 1; v1322_11_label <= 2; ++v1322_11_label) {
    const Space v1322_11_tail = child(s0,v1322_11_label);
    if (v1322_11_tail.empty()) continue;
    const Path v1322_11_head{v1322_11_label};
    const Space v1323_2 = singleton(v1322_11_head);
    const Space v1323_3 = intersect(constant_6,v1323_2);
    const Space v1323_4 = (has_head(v1323_3) ? constant_7 : Space{});
    const Space v1323_5 = subtract(constant_0,v1323_4);
    Space v1323_8;
    if (!v1323_5.empty()) {
      const Path v1324_6 = concat_path(p0,v1322_11_head);
      Space v1324_7_result;
      for (int v1324_7_label = 1; v1324_7_label <= 2; ++v1324_7_label) {
        const Space v1324_7_tail = child(v1322_11_tail,v1324_7_label);
        if (v1324_7_tail.empty()) continue;
        const Path v1324_7_head{v1324_7_label};
        const Space v1325_2 = singleton(v1324_7_head);
        const Space v1325_3 = intersect(constant_6,v1325_2);
        const Space v1325_4 = (has_head(v1325_3) ? constant_7 : Space{});
        const Space v1325_5 = subtract(constant_0,v1325_4);
        Space v1325_8;
        if (!v1325_5.empty()) {
          const Path v1326_6 = concat_path(v1324_6,v1324_7_head);
          const Space v1326_7 = routine_191(c, v1326_6, v1324_7_tail);
          v1325_8 = compose(v1325_5,v1326_7);
        }
        const Space v1325_9 = intersect(constant_6,v1325_2);
        const Space v1325_10 = (has_head(v1325_9) ? constant_7 : Space{});
        Space v1325_12;
        if (!v1325_10.empty()) {
          const Path v1327_6 = concat_path(v1324_6,v1324_7_head);
          const Space v1327_11 = routine_192(c, v1327_6, v1324_7_tail);
          v1325_12 = compose(v1325_10,v1327_11);
        }
        const Space v1325_13 = unite(v1325_8,v1325_12);
        v1324_7_result = unite(v1324_7_result,v1325_13);
      }
      const Space v1324_7 = std::move(v1324_7_result);
      v1323_8 = compose(v1323_5,v1324_7);
    }
    const Space v1323_9 = intersect(constant_6,v1323_2);
    const Space v1323_10 = (has_head(v1323_9) ? constant_7 : Space{});
    Space v1323_12;
    if (!v1323_10.empty()) {
      const Path v1328_6 = concat_path(p0,v1322_11_head);
      Space v1328_11_result;
      for (int v1328_11_label = 1; v1328_11_label <= 2; ++v1328_11_label) {
        const Space v1328_11_tail = child(v1322_11_tail,v1328_11_label);
        if (v1328_11_tail.empty()) continue;
        const Path v1328_11_head{v1328_11_label};
        const Space v1329_2 = singleton(v1328_11_head);
        const Space v1329_3 = intersect(constant_6,v1329_2);
        const Space v1329_4 = (has_head(v1329_3) ? constant_7 : Space{});
        const Space v1329_5 = subtract(constant_0,v1329_4);
        Space v1329_8;
        if (!v1329_5.empty()) {
          const Path v1330_6 = concat_path(v1328_6,v1328_11_head);
          const Space v1330_7 = routine_191(c, v1330_6, v1328_11_tail);
          v1329_8 = compose(v1329_5,v1330_7);
        }
        const Space v1329_9 = intersect(constant_6,v1329_2);
        const Space v1329_10 = (has_head(v1329_9) ? constant_7 : Space{});
        Space v1329_12;
        if (!v1329_10.empty()) {
          const Path v1331_6 = concat_path(v1328_6,v1328_11_head);
          const Space v1331_11 = routine_75(c, v1331_6, v1328_11_tail);
          v1329_12 = compose(v1329_10,v1331_11);
        }
        const Space v1329_13 = unite(v1329_8,v1329_12);
        v1328_11_result = unite(v1328_11_result,v1329_13);
      }
      const Space v1328_11 = std::move(v1328_11_result);
      v1323_12 = compose(v1323_10,v1328_11);
    }
    const Space v1323_13 = unite(v1323_8,v1323_12);
    v1322_11_result = unite(v1322_11_result,v1323_13);
  }
  const Space v1322_11 = std::move(v1322_11_result);
  return v1322_11;
}

static Space routine_144(Context& c, const Path& p0, const Space& s0) {
  Space v1332_8_result;
  for (int v1332_8_label = 1; v1332_8_label <= 2; ++v1332_8_label) {
    const Space v1332_8_tail = child(s0,v1332_8_label);
    if (v1332_8_tail.empty()) continue;
    const Path v1332_8_head{v1332_8_label};
    const Space v1333_2 = singleton(v1332_8_head);
    const Space v1333_3 = intersect(constant_6,v1333_2);
    const Space v1333_4 = (has_head(v1333_3) ? constant_7 : Space{});
    const Space v1333_5 = subtract(constant_0,v1333_4);
    Space v1333_8;
    if (!v1333_5.empty()) {
      const Path v1334_6 = concat_path(p0,v1332_8_head);
      Space v1334_7_result;
      for (int v1334_7_label = 1; v1334_7_label <= 2; ++v1334_7_label) {
        const Space v1334_7_tail = child(v1332_8_tail,v1334_7_label);
        if (v1334_7_tail.empty()) continue;
        const Path v1334_7_head{v1334_7_label};
        const Space v1335_2 = singleton(v1334_7_head);
        const Space v1335_3 = intersect(constant_6,v1335_2);
        const Space v1335_4 = (has_head(v1335_3) ? constant_7 : Space{});
        const Space v1335_5 = subtract(constant_0,v1335_4);
        Space v1335_8;
        if (!v1335_5.empty()) {
          const Path v1336_6 = concat_path(v1334_6,v1334_7_head);
          const Space v1336_7 = routine_191(c, v1336_6, v1334_7_tail);
          v1335_8 = compose(v1335_5,v1336_7);
        }
        const Space v1335_9 = intersect(constant_6,v1335_2);
        const Space v1335_10 = (has_head(v1335_9) ? constant_7 : Space{});
        Space v1335_12;
        if (!v1335_10.empty()) {
          const Path v1337_6 = concat_path(v1334_6,v1334_7_head);
          const Space v1337_11 = routine_192(c, v1337_6, v1334_7_tail);
          v1335_12 = compose(v1335_10,v1337_11);
        }
        const Space v1335_13 = unite(v1335_8,v1335_12);
        v1334_7_result = unite(v1334_7_result,v1335_13);
      }
      const Space v1334_7 = std::move(v1334_7_result);
      v1333_8 = compose(v1333_5,v1334_7);
    }
    const Space v1333_9 = intersect(constant_6,v1333_2);
    const Space v1333_10 = (has_head(v1333_9) ? constant_7 : Space{});
    const Space v1333_11 = compose(v1333_10,v1332_8_tail);
    const Space v1333_12 = unite(v1333_8,v1333_11);
    v1332_8_result = unite(v1332_8_result,v1333_12);
  }
  const Space v1332_8 = std::move(v1332_8_result);
  return v1332_8;
}

static Space routine_145(Context& c, const Path& p0, const Space& s0) {
  Space v1338_6_result;
  for (int v1338_6_label = 1; v1338_6_label <= 2; ++v1338_6_label) {
    const Space v1338_6_tail = child(s0,v1338_6_label);
    if (v1338_6_tail.empty()) continue;
    const Path v1338_6_head{v1338_6_label};
    const Space v1339_2 = singleton(v1338_6_head);
    const Space v1339_3 = intersect(constant_6,v1339_2);
    const Space v1339_4 = (has_head(v1339_3) ? constant_7 : Space{});
    const Space v1339_5 = subtract(constant_0,v1339_4);
    Space v1339_6_result;
    for (int v1339_6_label = 1; v1339_6_label <= 2; ++v1339_6_label) {
      const Space v1339_6_tail = child(v1338_6_tail,v1339_6_label);
      if (v1339_6_tail.empty()) continue;
      const Path v1339_6_head{v1339_6_label};
      const Space v1340_2 = Space{};
      v1339_6_result = unite(v1339_6_result,v1340_2);
    }
    const Space v1339_6 = std::move(v1339_6_result);
    const Space v1339_7 = compose(v1339_5,v1339_6);
    const Space v1339_8 = intersect(constant_6,v1339_2);
    const Space v1339_9 = (has_head(v1339_8) ? constant_7 : Space{});
    Space v1339_12;
    if (!v1339_9.empty()) {
      const Path v1341_10 = concat_path(p0,v1338_6_head);
      Space v1341_11_result;
      for (int v1341_11_label = 1; v1341_11_label <= 2; ++v1341_11_label) {
        const Space v1341_11_tail = child(v1338_6_tail,v1341_11_label);
        if (v1341_11_tail.empty()) continue;
        const Path v1341_11_head{v1341_11_label};
        const Space v1342_2 = singleton(v1341_11_head);
        const Space v1342_3 = intersect(constant_6,v1342_2);
        const Space v1342_4 = (has_head(v1342_3) ? constant_7 : Space{});
        Space v1342_7;
        if (!v1342_4.empty()) {
          const Path v1343_5 = concat_path(v1341_10,v1341_11_head);
          const Space v1343_6 = routine_14(c, v1343_5, v1341_11_tail);
          v1342_7 = compose(v1342_4,v1343_6);
        }
        v1341_11_result = unite(v1341_11_result,v1342_7);
      }
      const Space v1341_11 = std::move(v1341_11_result);
      v1339_12 = compose(v1339_9,v1341_11);
    }
    const Space v1339_13 = unite(v1339_7,v1339_12);
    v1338_6_result = unite(v1338_6_result,v1339_13);
  }
  const Space v1338_6 = std::move(v1338_6_result);
  return v1338_6;
}

static Space routine_146(Context& c, const Path& p0, const Space& s0) {
  Space v1344_8_result;
  for (int v1344_8_label = 1; v1344_8_label <= 2; ++v1344_8_label) {
    const Space v1344_8_tail = child(s0,v1344_8_label);
    if (v1344_8_tail.empty()) continue;
    const Path v1344_8_head{v1344_8_label};
    const Space v1345_2 = singleton(v1344_8_head);
    const Space v1345_3 = intersect(constant_6,v1345_2);
    const Space v1345_4 = (has_head(v1345_3) ? constant_7 : Space{});
    const Space v1345_5 = subtract(constant_0,v1345_4);
    Space v1345_6_result;
    for (int v1345_6_label = 1; v1345_6_label <= 2; ++v1345_6_label) {
      const Space v1345_6_tail = child(v1344_8_tail,v1345_6_label);
      if (v1345_6_tail.empty()) continue;
      const Path v1345_6_head{v1345_6_label};
      const Space v1346_2 = Space{};
      v1345_6_result = unite(v1345_6_result,v1346_2);
    }
    const Space v1345_6 = std::move(v1345_6_result);
    const Space v1345_7 = compose(v1345_5,v1345_6);
    const Space v1345_8 = intersect(constant_6,v1345_2);
    const Space v1345_9 = (has_head(v1345_8) ? constant_7 : Space{});
    Space v1345_12;
    if (!v1345_9.empty()) {
      const Path v1347_10 = concat_path(p0,v1344_8_head);
      Space v1347_11_result;
      for (int v1347_11_label = 1; v1347_11_label <= 2; ++v1347_11_label) {
        const Space v1347_11_tail = child(v1344_8_tail,v1347_11_label);
        if (v1347_11_tail.empty()) continue;
        const Path v1347_11_head{v1347_11_label};
        const Space v1348_2 = singleton(v1347_11_head);
        const Space v1348_3 = intersect(constant_6,v1348_2);
        const Space v1348_4 = (has_head(v1348_3) ? constant_7 : Space{});
        const Space v1348_5 = subtract(constant_0,v1348_4);
        Space v1348_7;
        if (!v1348_5.empty()) {
          const Space v1349_6 = routine_15(c, v1347_11_head, v1347_10, v1347_11_tail);
          v1348_7 = compose(v1348_5,v1349_6);
        }
        const Space v1348_8 = intersect(constant_6,v1348_2);
        const Space v1348_9 = (has_head(v1348_8) ? constant_7 : Space{});
        Space v1348_11;
        if (!v1348_9.empty()) {
          const Space v1350_10 = routine_16(c, v1347_11_head, v1347_10, v1347_11_tail);
          v1348_11 = compose(v1348_9,v1350_10);
        }
        const Space v1348_12 = unite(v1348_7,v1348_11);
        v1347_11_result = unite(v1347_11_result,v1348_12);
      }
      const Space v1347_11 = std::move(v1347_11_result);
      v1345_12 = compose(v1345_9,v1347_11);
    }
    const Space v1345_13 = unite(v1345_7,v1345_12);
    v1344_8_result = unite(v1344_8_result,v1345_13);
  }
  const Space v1344_8 = std::move(v1344_8_result);
  return v1344_8;
}

static Space routine_147(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1351_12_result;
  for (int v1351_12_label = 1; v1351_12_label <= 2; ++v1351_12_label) {
    const Space v1351_12_tail = child(s0,v1351_12_label);
    if (v1351_12_tail.empty()) continue;
    const Path v1351_12_head{v1351_12_label};
    const Space v1352_2 = singleton(v1351_12_head);
    const Space v1352_3 = intersect(constant_6,v1352_2);
    const Space v1352_4 = (has_head(v1352_3) ? constant_7 : Space{});
    const Space v1352_5 = subtract(constant_0,v1352_4);
    Space v1352_8;
    if (!v1352_5.empty()) {
      const Path v1353_6 = concat_path(p0,v1351_12_head);
      Space v1353_7_result;
      for (int v1353_7_label = 1; v1353_7_label <= 2; ++v1353_7_label) {
        const Space v1353_7_tail = child(v1351_12_tail,v1353_7_label);
        if (v1353_7_tail.empty()) continue;
        const Path v1353_7_head{v1353_7_label};
        const Space v1354_2 = singleton(v1353_7_head);
        const Space v1354_3 = intersect(constant_6,v1354_2);
        const Space v1354_4 = (has_head(v1354_3) ? constant_7 : Space{});
        const Space v1354_5 = subtract(constant_0,v1354_4);
        Space v1354_8;
        if (!v1354_5.empty()) {
          const Path v1355_6 = concat_path(v1353_6,v1353_7_head);
          const Space v1355_7 = routine_193(c, v1355_6, p1, v1353_7_tail);
          v1354_8 = compose(v1354_5,v1355_7);
        }
        const Space v1354_9 = intersect(constant_6,v1354_2);
        const Space v1354_10 = (has_head(v1354_9) ? constant_7 : Space{});
        Space v1354_12;
        if (!v1354_10.empty()) {
          const Path v1356_6 = concat_path(v1353_6,v1353_7_head);
          const Space v1356_11 = routine_194(c, v1356_6, p1, v1353_7_tail);
          v1354_12 = compose(v1354_10,v1356_11);
        }
        const Space v1354_13 = unite(v1354_8,v1354_12);
        v1353_7_result = unite(v1353_7_result,v1354_13);
      }
      const Space v1353_7 = std::move(v1353_7_result);
      v1352_8 = compose(v1352_5,v1353_7);
    }
    const Space v1352_9 = intersect(constant_6,v1352_2);
    const Space v1352_10 = (has_head(v1352_9) ? constant_7 : Space{});
    Space v1352_12;
    if (!v1352_10.empty()) {
      const Path v1357_6 = concat_path(p0,v1351_12_head);
      Space v1357_11_result;
      for (int v1357_11_label = 1; v1357_11_label <= 2; ++v1357_11_label) {
        const Space v1357_11_tail = child(v1351_12_tail,v1357_11_label);
        if (v1357_11_tail.empty()) continue;
        const Path v1357_11_head{v1357_11_label};
        const Space v1358_2 = singleton(v1357_11_head);
        const Space v1358_3 = intersect(constant_6,v1358_2);
        const Space v1358_4 = (has_head(v1358_3) ? constant_7 : Space{});
        const Space v1358_5 = subtract(constant_0,v1358_4);
        Space v1358_8;
        if (!v1358_5.empty()) {
          const Path v1359_6 = concat_path(v1357_6,v1357_11_head);
          const Space v1359_7 = routine_193(c, v1359_6, p1, v1357_11_tail);
          v1358_8 = compose(v1358_5,v1359_7);
        }
        const Space v1358_9 = intersect(constant_6,v1358_2);
        const Space v1358_10 = (has_head(v1358_9) ? constant_7 : Space{});
        Space v1358_12;
        if (!v1358_10.empty()) {
          const Path v1360_6 = concat_path(v1357_6,v1357_11_head);
          const Space v1360_11 = routine_42(c, v1360_6, p1, v1357_11_tail);
          v1358_12 = compose(v1358_10,v1360_11);
        }
        const Space v1358_13 = unite(v1358_8,v1358_12);
        v1357_11_result = unite(v1357_11_result,v1358_13);
      }
      const Space v1357_11 = std::move(v1357_11_result);
      v1352_12 = compose(v1352_10,v1357_11);
    }
    const Space v1352_13 = unite(v1352_8,v1352_12);
    v1351_12_result = unite(v1351_12_result,v1352_13);
  }
  const Space v1351_12 = std::move(v1351_12_result);
  return v1351_12;
}

static Space routine_148(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1361_9_result;
  for (int v1361_9_label = 1; v1361_9_label <= 2; ++v1361_9_label) {
    const Space v1361_9_tail = child(s0,v1361_9_label);
    if (v1361_9_tail.empty()) continue;
    const Path v1361_9_head{v1361_9_label};
    const Space v1362_2 = singleton(v1361_9_head);
    const Space v1362_3 = intersect(constant_6,v1362_2);
    const Space v1362_4 = (has_head(v1362_3) ? constant_7 : Space{});
    const Space v1362_5 = subtract(constant_0,v1362_4);
    Space v1362_8;
    if (!v1362_5.empty()) {
      const Path v1363_6 = concat_path(p0,v1361_9_head);
      Space v1363_7_result;
      for (int v1363_7_label = 1; v1363_7_label <= 2; ++v1363_7_label) {
        const Space v1363_7_tail = child(v1361_9_tail,v1363_7_label);
        if (v1363_7_tail.empty()) continue;
        const Path v1363_7_head{v1363_7_label};
        const Space v1364_2 = singleton(v1363_7_head);
        const Space v1364_3 = intersect(constant_6,v1364_2);
        const Space v1364_4 = (has_head(v1364_3) ? constant_7 : Space{});
        const Space v1364_5 = subtract(constant_0,v1364_4);
        Space v1364_8;
        if (!v1364_5.empty()) {
          const Path v1365_6 = concat_path(v1363_6,v1363_7_head);
          const Space v1365_7 = routine_193(c, v1365_6, p1, v1363_7_tail);
          v1364_8 = compose(v1364_5,v1365_7);
        }
        const Space v1364_9 = intersect(constant_6,v1364_2);
        const Space v1364_10 = (has_head(v1364_9) ? constant_7 : Space{});
        Space v1364_12;
        if (!v1364_10.empty()) {
          const Path v1366_6 = concat_path(v1363_6,v1363_7_head);
          const Space v1366_11 = routine_194(c, v1366_6, p1, v1363_7_tail);
          v1364_12 = compose(v1364_10,v1366_11);
        }
        const Space v1364_13 = unite(v1364_8,v1364_12);
        v1363_7_result = unite(v1363_7_result,v1364_13);
      }
      const Space v1363_7 = std::move(v1363_7_result);
      v1362_8 = compose(v1362_5,v1363_7);
    }
    const Space v1362_9 = intersect(constant_6,v1362_2);
    const Space v1362_10 = (has_head(v1362_9) ? constant_7 : Space{});
    Space v1362_13;
    if (!v1362_10.empty()) {
      const Path v1367_6 = concat_path(p0,v1361_9_head);
      const Path v1367_11 = concat_path(p1,v1367_6);
      const Space v1367_12 = routine_29(c, v1367_11);
      v1362_13 = compose(v1362_10,v1367_12);
    }
    const Space v1362_14 = unite(v1362_8,v1362_13);
    v1361_9_result = unite(v1361_9_result,v1362_14);
  }
  const Space v1361_9 = std::move(v1361_9_result);
  return v1361_9;
}

static Space routine_149(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1368_12_result;
  for (int v1368_12_label = 1; v1368_12_label <= 2; ++v1368_12_label) {
    const Space v1368_12_tail = child(s0,v1368_12_label);
    if (v1368_12_tail.empty()) continue;
    const Path v1368_12_head{v1368_12_label};
    const Space v1369_2 = singleton(v1368_12_head);
    const Space v1369_3 = intersect(constant_6,v1369_2);
    const Space v1369_4 = (has_head(v1369_3) ? constant_7 : Space{});
    const Space v1369_5 = subtract(constant_0,v1369_4);
    Space v1369_8;
    if (!v1369_5.empty()) {
      const Path v1370_6 = concat_path(p0,v1368_12_head);
      Space v1370_7_result;
      for (int v1370_7_label = 1; v1370_7_label <= 2; ++v1370_7_label) {
        const Space v1370_7_tail = child(v1368_12_tail,v1370_7_label);
        if (v1370_7_tail.empty()) continue;
        const Path v1370_7_head{v1370_7_label};
        const Space v1371_2 = singleton(v1370_7_head);
        const Space v1371_3 = intersect(constant_6,v1371_2);
        const Space v1371_4 = (has_head(v1371_3) ? constant_7 : Space{});
        const Space v1371_5 = subtract(constant_0,v1371_4);
        Space v1371_8;
        if (!v1371_5.empty()) {
          const Path v1372_6 = concat_path(v1370_6,v1370_7_head);
          const Space v1372_7 = routine_195(c, v1372_6, p1, v1370_7_tail);
          v1371_8 = compose(v1371_5,v1372_7);
        }
        const Space v1371_9 = intersect(constant_6,v1371_2);
        const Space v1371_10 = (has_head(v1371_9) ? constant_7 : Space{});
        Space v1371_12;
        if (!v1371_10.empty()) {
          const Path v1373_6 = concat_path(v1370_6,v1370_7_head);
          const Space v1373_11 = routine_196(c, v1373_6, p1, v1370_7_tail);
          v1371_12 = compose(v1371_10,v1373_11);
        }
        const Space v1371_13 = unite(v1371_8,v1371_12);
        v1370_7_result = unite(v1370_7_result,v1371_13);
      }
      const Space v1370_7 = std::move(v1370_7_result);
      v1369_8 = compose(v1369_5,v1370_7);
    }
    const Space v1369_9 = intersect(constant_6,v1369_2);
    const Space v1369_10 = (has_head(v1369_9) ? constant_7 : Space{});
    Space v1369_12;
    if (!v1369_10.empty()) {
      const Path v1374_6 = concat_path(p0,v1368_12_head);
      Space v1374_11_result;
      for (int v1374_11_label = 1; v1374_11_label <= 2; ++v1374_11_label) {
        const Space v1374_11_tail = child(v1368_12_tail,v1374_11_label);
        if (v1374_11_tail.empty()) continue;
        const Path v1374_11_head{v1374_11_label};
        const Space v1375_2 = singleton(v1374_11_head);
        const Space v1375_3 = intersect(constant_6,v1375_2);
        const Space v1375_4 = (has_head(v1375_3) ? constant_7 : Space{});
        const Space v1375_5 = subtract(constant_0,v1375_4);
        Space v1375_8;
        if (!v1375_5.empty()) {
          const Path v1376_6 = concat_path(v1374_6,v1374_11_head);
          const Space v1376_7 = routine_195(c, v1376_6, p1, v1374_11_tail);
          v1375_8 = compose(v1375_5,v1376_7);
        }
        const Space v1375_9 = intersect(constant_6,v1375_2);
        const Space v1375_10 = (has_head(v1375_9) ? constant_7 : Space{});
        Space v1375_12;
        if (!v1375_10.empty()) {
          const Path v1377_6 = concat_path(v1374_6,v1374_11_head);
          const Space v1377_11 = routine_42(c, v1377_6, p1, v1374_11_tail);
          v1375_12 = compose(v1375_10,v1377_11);
        }
        const Space v1375_13 = unite(v1375_8,v1375_12);
        v1374_11_result = unite(v1374_11_result,v1375_13);
      }
      const Space v1374_11 = std::move(v1374_11_result);
      v1369_12 = compose(v1369_10,v1374_11);
    }
    const Space v1369_13 = unite(v1369_8,v1369_12);
    v1368_12_result = unite(v1368_12_result,v1369_13);
  }
  const Space v1368_12 = std::move(v1368_12_result);
  return v1368_12;
}

static Space routine_150(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1378_9_result;
  for (int v1378_9_label = 1; v1378_9_label <= 2; ++v1378_9_label) {
    const Space v1378_9_tail = child(s0,v1378_9_label);
    if (v1378_9_tail.empty()) continue;
    const Path v1378_9_head{v1378_9_label};
    const Space v1379_2 = singleton(v1378_9_head);
    const Space v1379_3 = intersect(constant_6,v1379_2);
    const Space v1379_4 = (has_head(v1379_3) ? constant_7 : Space{});
    const Space v1379_5 = subtract(constant_0,v1379_4);
    Space v1379_8;
    if (!v1379_5.empty()) {
      const Path v1380_6 = concat_path(p0,v1378_9_head);
      Space v1380_7_result;
      for (int v1380_7_label = 1; v1380_7_label <= 2; ++v1380_7_label) {
        const Space v1380_7_tail = child(v1378_9_tail,v1380_7_label);
        if (v1380_7_tail.empty()) continue;
        const Path v1380_7_head{v1380_7_label};
        const Space v1381_2 = singleton(v1380_7_head);
        const Space v1381_3 = intersect(constant_6,v1381_2);
        const Space v1381_4 = (has_head(v1381_3) ? constant_7 : Space{});
        const Space v1381_5 = subtract(constant_0,v1381_4);
        Space v1381_8;
        if (!v1381_5.empty()) {
          const Path v1382_6 = concat_path(v1380_6,v1380_7_head);
          const Space v1382_7 = routine_195(c, v1382_6, p1, v1380_7_tail);
          v1381_8 = compose(v1381_5,v1382_7);
        }
        const Space v1381_9 = intersect(constant_6,v1381_2);
        const Space v1381_10 = (has_head(v1381_9) ? constant_7 : Space{});
        Space v1381_12;
        if (!v1381_10.empty()) {
          const Path v1383_6 = concat_path(v1380_6,v1380_7_head);
          const Space v1383_11 = routine_196(c, v1383_6, p1, v1380_7_tail);
          v1381_12 = compose(v1381_10,v1383_11);
        }
        const Space v1381_13 = unite(v1381_8,v1381_12);
        v1380_7_result = unite(v1380_7_result,v1381_13);
      }
      const Space v1380_7 = std::move(v1380_7_result);
      v1379_8 = compose(v1379_5,v1380_7);
    }
    const Space v1379_9 = intersect(constant_6,v1379_2);
    const Space v1379_10 = (has_head(v1379_9) ? constant_7 : Space{});
    Space v1379_13;
    if (!v1379_10.empty()) {
      const Path v1384_6 = concat_path(p0,v1378_9_head);
      const Path v1384_11 = concat_path(p1,v1384_6);
      const Space v1384_12 = routine_29(c, v1384_11);
      v1379_13 = compose(v1379_10,v1384_12);
    }
    const Space v1379_14 = unite(v1379_8,v1379_13);
    v1378_9_result = unite(v1378_9_result,v1379_14);
  }
  const Space v1378_9 = std::move(v1378_9_result);
  return v1378_9;
}

static Space routine_151(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1385_7_result;
  for (int v1385_7_label = 1; v1385_7_label <= 2; ++v1385_7_label) {
    const Space v1385_7_tail = child(s0,v1385_7_label);
    if (v1385_7_tail.empty()) continue;
    const Path v1385_7_head{v1385_7_label};
    const Space v1386_2 = singleton(v1385_7_head);
    const Space v1386_3 = intersect(constant_6,v1386_2);
    const Space v1386_4 = (has_head(v1386_3) ? constant_7 : Space{});
    const Space v1386_5 = subtract(constant_0,v1386_4);
    Space v1386_6_result;
    for (int v1386_6_label = 1; v1386_6_label <= 2; ++v1386_6_label) {
      const Space v1386_6_tail = child(v1385_7_tail,v1386_6_label);
      if (v1386_6_tail.empty()) continue;
      const Path v1386_6_head{v1386_6_label};
      const Space v1387_2 = Space{};
      v1386_6_result = unite(v1386_6_result,v1387_2);
    }
    const Space v1386_6 = std::move(v1386_6_result);
    const Space v1386_7 = compose(v1386_5,v1386_6);
    const Space v1386_8 = intersect(constant_6,v1386_2);
    const Space v1386_9 = (has_head(v1386_8) ? constant_7 : Space{});
    Space v1386_12;
    if (!v1386_9.empty()) {
      const Path v1388_10 = concat_path(p0,v1385_7_head);
      Space v1388_11_result;
      for (int v1388_11_label = 1; v1388_11_label <= 2; ++v1388_11_label) {
        const Space v1388_11_tail = child(v1385_7_tail,v1388_11_label);
        if (v1388_11_tail.empty()) continue;
        const Path v1388_11_head{v1388_11_label};
        const Space v1389_2 = singleton(v1388_11_head);
        const Space v1389_3 = intersect(constant_6,v1389_2);
        const Space v1389_4 = (has_head(v1389_3) ? constant_7 : Space{});
        Space v1389_7;
        if (!v1389_4.empty()) {
          const Path v1390_5 = concat_path(v1388_10,v1388_11_head);
          const Space v1390_6 = routine_19(c, v1390_5, v1388_11_tail, s1);
          v1389_7 = compose(v1389_4,v1390_6);
        }
        v1388_11_result = unite(v1388_11_result,v1389_7);
      }
      const Space v1388_11 = std::move(v1388_11_result);
      v1386_12 = compose(v1386_9,v1388_11);
    }
    const Space v1386_13 = unite(v1386_7,v1386_12);
    v1385_7_result = unite(v1385_7_result,v1386_13);
  }
  const Space v1385_7 = std::move(v1385_7_result);
  return v1385_7;
}

static Space routine_152(Context& c, const Path& p0, const Space& s0, const Space& s1) {
  Space v1391_9_result;
  for (int v1391_9_label = 1; v1391_9_label <= 2; ++v1391_9_label) {
    const Space v1391_9_tail = child(s0,v1391_9_label);
    if (v1391_9_tail.empty()) continue;
    const Path v1391_9_head{v1391_9_label};
    const Space v1392_2 = singleton(v1391_9_head);
    const Space v1392_3 = intersect(constant_6,v1392_2);
    const Space v1392_4 = (has_head(v1392_3) ? constant_7 : Space{});
    const Space v1392_5 = subtract(constant_0,v1392_4);
    Space v1392_6_result;
    for (int v1392_6_label = 1; v1392_6_label <= 2; ++v1392_6_label) {
      const Space v1392_6_tail = child(v1391_9_tail,v1392_6_label);
      if (v1392_6_tail.empty()) continue;
      const Path v1392_6_head{v1392_6_label};
      const Space v1393_2 = Space{};
      v1392_6_result = unite(v1392_6_result,v1393_2);
    }
    const Space v1392_6 = std::move(v1392_6_result);
    const Space v1392_7 = compose(v1392_5,v1392_6);
    const Space v1392_8 = intersect(constant_6,v1392_2);
    const Space v1392_9 = (has_head(v1392_8) ? constant_7 : Space{});
    Space v1392_12;
    if (!v1392_9.empty()) {
      const Path v1394_10 = concat_path(p0,v1391_9_head);
      Space v1394_11_result;
      for (int v1394_11_label = 1; v1394_11_label <= 2; ++v1394_11_label) {
        const Space v1394_11_tail = child(v1391_9_tail,v1394_11_label);
        if (v1394_11_tail.empty()) continue;
        const Path v1394_11_head{v1394_11_label};
        const Space v1395_2 = singleton(v1394_11_head);
        const Space v1395_3 = intersect(constant_6,v1395_2);
        const Space v1395_4 = (has_head(v1395_3) ? constant_7 : Space{});
        const Space v1395_5 = subtract(constant_0,v1395_4);
        Space v1395_7;
        if (!v1395_5.empty()) {
          const Space v1396_6 = routine_20(c, v1394_11_head, v1394_10, v1394_11_tail, s1);
          v1395_7 = compose(v1395_5,v1396_6);
        }
        const Space v1395_8 = intersect(constant_6,v1395_2);
        const Space v1395_9 = (has_head(v1395_8) ? constant_7 : Space{});
        Space v1395_11;
        if (!v1395_9.empty()) {
          const Space v1397_10 = routine_21(c, v1394_11_head, v1394_10, v1394_11_tail, s1);
          v1395_11 = compose(v1395_9,v1397_10);
        }
        const Space v1395_12 = unite(v1395_7,v1395_11);
        v1394_11_result = unite(v1394_11_result,v1395_12);
      }
      const Space v1394_11 = std::move(v1394_11_result);
      v1392_12 = compose(v1392_9,v1394_11);
    }
    const Space v1392_13 = unite(v1392_7,v1392_12);
    v1391_9_result = unite(v1391_9_result,v1392_13);
  }
  const Space v1391_9 = std::move(v1391_9_result);
  return v1391_9;
}

static Space routine_153(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1398_13_result;
  for (int v1398_13_label = 1; v1398_13_label <= 2; ++v1398_13_label) {
    const Space v1398_13_tail = child(s0,v1398_13_label);
    if (v1398_13_tail.empty()) continue;
    const Path v1398_13_head{v1398_13_label};
    const Space v1399_2 = singleton(v1398_13_head);
    const Space v1399_3 = intersect(constant_6,v1399_2);
    const Space v1399_4 = (has_head(v1399_3) ? constant_7 : Space{});
    const Space v1399_5 = subtract(constant_0,v1399_4);
    Space v1399_8;
    if (!v1399_5.empty()) {
      const Path v1400_6 = concat_path(p0,v1398_13_head);
      Space v1400_7_result;
      for (int v1400_7_label = 1; v1400_7_label <= 2; ++v1400_7_label) {
        const Space v1400_7_tail = child(v1398_13_tail,v1400_7_label);
        if (v1400_7_tail.empty()) continue;
        const Path v1400_7_head{v1400_7_label};
        const Space v1401_2 = singleton(v1400_7_head);
        const Space v1401_3 = intersect(constant_6,v1401_2);
        const Space v1401_4 = (has_head(v1401_3) ? constant_7 : Space{});
        const Space v1401_5 = subtract(constant_0,v1401_4);
        Space v1401_8;
        if (!v1401_5.empty()) {
          const Path v1402_6 = concat_path(v1400_6,v1400_7_head);
          const Space v1402_7 = routine_197(c, v1402_6, p1, v1400_7_tail, s1);
          v1401_8 = compose(v1401_5,v1402_7);
        }
        const Space v1401_9 = intersect(constant_6,v1401_2);
        const Space v1401_10 = (has_head(v1401_9) ? constant_7 : Space{});
        Space v1401_12;
        if (!v1401_10.empty()) {
          const Path v1403_6 = concat_path(v1400_6,v1400_7_head);
          const Space v1403_11 = routine_198(c, v1403_6, p1, v1400_7_tail, s1);
          v1401_12 = compose(v1401_10,v1403_11);
        }
        const Space v1401_13 = unite(v1401_8,v1401_12);
        v1400_7_result = unite(v1400_7_result,v1401_13);
      }
      const Space v1400_7 = std::move(v1400_7_result);
      v1399_8 = compose(v1399_5,v1400_7);
    }
    const Space v1399_9 = intersect(constant_6,v1399_2);
    const Space v1399_10 = (has_head(v1399_9) ? constant_7 : Space{});
    Space v1399_12;
    if (!v1399_10.empty()) {
      const Path v1404_6 = concat_path(p0,v1398_13_head);
      Space v1404_11_result;
      for (int v1404_11_label = 1; v1404_11_label <= 2; ++v1404_11_label) {
        const Space v1404_11_tail = child(v1398_13_tail,v1404_11_label);
        if (v1404_11_tail.empty()) continue;
        const Path v1404_11_head{v1404_11_label};
        const Space v1405_2 = singleton(v1404_11_head);
        const Space v1405_3 = intersect(constant_6,v1405_2);
        const Space v1405_4 = (has_head(v1405_3) ? constant_7 : Space{});
        const Space v1405_5 = subtract(constant_0,v1405_4);
        Space v1405_8;
        if (!v1405_5.empty()) {
          const Path v1406_6 = concat_path(v1404_6,v1404_11_head);
          const Space v1406_7 = routine_197(c, v1406_6, p1, v1404_11_tail, s1);
          v1405_8 = compose(v1405_5,v1406_7);
        }
        const Space v1405_9 = intersect(constant_6,v1405_2);
        const Space v1405_10 = (has_head(v1405_9) ? constant_7 : Space{});
        Space v1405_12;
        if (!v1405_10.empty()) {
          const Path v1407_6 = concat_path(v1404_6,v1404_11_head);
          const Space v1407_11 = routine_49(c, v1407_6, p1, v1404_11_tail, s1);
          v1405_12 = compose(v1405_10,v1407_11);
        }
        const Space v1405_13 = unite(v1405_8,v1405_12);
        v1404_11_result = unite(v1404_11_result,v1405_13);
      }
      const Space v1404_11 = std::move(v1404_11_result);
      v1399_12 = compose(v1399_10,v1404_11);
    }
    const Space v1399_13 = unite(v1399_8,v1399_12);
    v1398_13_result = unite(v1398_13_result,v1399_13);
  }
  const Space v1398_13 = std::move(v1398_13_result);
  return v1398_13;
}

static Space routine_154(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1408_8 = unwrap(s1,constant_8);
  Space v1408_21_result;
  for (int v1408_21_label = 1; v1408_21_label <= 2; ++v1408_21_label) {
    const Space v1408_21_tail = child(s0,v1408_21_label);
    if (v1408_21_tail.empty()) continue;
    const Path v1408_21_head{v1408_21_label};
    const Space v1409_2 = singleton(v1408_21_head);
    const Space v1409_3 = intersect(constant_6,v1409_2);
    const Space v1409_4 = (has_head(v1409_3) ? constant_7 : Space{});
    const Space v1409_5 = subtract(constant_0,v1409_4);
    Space v1409_8;
    if (!v1409_5.empty()) {
      const Path v1410_6 = concat_path(p0,v1408_21_head);
      Space v1410_7_result;
      for (int v1410_7_label = 1; v1410_7_label <= 2; ++v1410_7_label) {
        const Space v1410_7_tail = child(v1408_21_tail,v1410_7_label);
        if (v1410_7_tail.empty()) continue;
        const Path v1410_7_head{v1410_7_label};
        const Space v1411_2 = singleton(v1410_7_head);
        const Space v1411_3 = intersect(constant_6,v1411_2);
        const Space v1411_4 = (has_head(v1411_3) ? constant_7 : Space{});
        const Space v1411_5 = subtract(constant_0,v1411_4);
        Space v1411_8;
        if (!v1411_5.empty()) {
          const Path v1412_6 = concat_path(v1410_6,v1410_7_head);
          const Space v1412_7 = routine_197(c, v1412_6, p1, v1410_7_tail, s1);
          v1411_8 = compose(v1411_5,v1412_7);
        }
        const Space v1411_9 = intersect(constant_6,v1411_2);
        const Space v1411_10 = (has_head(v1411_9) ? constant_7 : Space{});
        Space v1411_12;
        if (!v1411_10.empty()) {
          const Path v1413_6 = concat_path(v1410_6,v1410_7_head);
          const Space v1413_11 = routine_198(c, v1413_6, p1, v1410_7_tail, s1);
          v1411_12 = compose(v1411_10,v1413_11);
        }
        const Space v1411_13 = unite(v1411_8,v1411_12);
        v1410_7_result = unite(v1410_7_result,v1411_13);
      }
      const Space v1410_7 = std::move(v1410_7_result);
      v1409_8 = compose(v1409_5,v1410_7);
    }
    const Space v1409_9 = intersect(constant_6,v1409_2);
    const Space v1409_10 = (has_head(v1409_9) ? constant_7 : Space{});
    Space v1409_22;
    if (!v1409_10.empty()) {
      const Path v1414_6 = concat_path(p0,v1408_21_head);
      const Path v1414_11 = concat_path(p1,v1414_6);
      const Space v1414_12 = routine_29(c, v1414_11);
      const Space v1414_13 = intersect(v1408_8,v1414_12);
      const Space v1414_14 = routine_33(c, v1414_13);
      Space v1414_15_result;
      for (int v1414_15_label = 1; v1414_15_label <= 2; ++v1414_15_label) {
        const Space v1414_15_tail = child(v1414_14,v1414_15_label);
        if (v1414_15_tail.empty()) continue;
        const Path v1414_15_head{v1414_15_label};
        const Space v1415_2 = singleton(v1414_15_head);
        const Space v1415_3 = intersect(constant_6,v1415_2);
        const Space v1415_4 = (has_head(v1415_3) ? constant_7 : Space{});
        const Space v1415_5 = subtract(constant_0,v1415_4);
        Space v1415_7;
        if (!v1415_5.empty()) {
          const Space v1416_6 = routine_52(c, v1414_15_head, v1414_15_tail);
          v1415_7 = compose(v1415_5,v1416_6);
        }
        const Space v1415_8 = intersect(constant_6,v1415_2);
        const Space v1415_9 = (has_head(v1415_8) ? constant_7 : Space{});
        Space v1415_11;
        if (!v1415_9.empty()) {
          const Space v1417_10 = routine_53(c, v1414_15_head, v1414_15_tail);
          v1415_11 = compose(v1415_9,v1417_10);
        }
        const Space v1415_12 = unite(v1415_7,v1415_11);
        v1414_15_result = unite(v1414_15_result,v1415_12);
      }
      const Space v1414_15 = std::move(v1414_15_result);
      const Space v1414_16 = routine_54(c, v1414_13);
      Space v1414_17_result;
      for (int v1414_17_label = 1; v1414_17_label <= 2; ++v1414_17_label) {
        const Space v1414_17_tail = child(v1414_16,v1414_17_label);
        if (v1414_17_tail.empty()) continue;
        const Path v1414_17_head{v1414_17_label};
        const Space v1418_2 = singleton(v1414_17_head);
        const Space v1418_3 = intersect(constant_6,v1418_2);
        const Space v1418_4 = (has_head(v1418_3) ? constant_7 : Space{});
        const Space v1418_5 = subtract(constant_0,v1418_4);
        Space v1418_7;
        if (!v1418_5.empty()) {
          const Space v1419_6 = routine_55(c, v1414_17_head, v1414_17_tail);
          v1418_7 = compose(v1418_5,v1419_6);
        }
        const Space v1418_8 = intersect(constant_6,v1418_2);
        const Space v1418_9 = (has_head(v1418_8) ? constant_7 : Space{});
        Space v1418_11;
        if (!v1418_9.empty()) {
          const Space v1420_10 = routine_56(c, v1414_17_head, v1414_17_tail);
          v1418_11 = compose(v1418_9,v1420_10);
        }
        const Space v1418_12 = unite(v1418_7,v1418_11);
        v1414_17_result = unite(v1414_17_result,v1418_12);
      }
      const Space v1414_17 = std::move(v1414_17_result);
      const Space v1414_18 = subtract(v1414_15,v1414_17);
      const Space v1414_19 = singleton(v1414_11);
      const Space v1414_20 = compose(v1414_18,v1414_19);
      Space v1414_21_result;
      for (int v1414_21_label = 1; v1414_21_label <= 2; ++v1414_21_label) {
        const Space v1414_21_tail = child(v1414_20,v1414_21_label);
        if (v1414_21_tail.empty()) continue;
        const Path v1414_21_head{v1414_21_label};
        const Space v1421_2 = singleton(v1414_21_head);
        const Space v1421_3 = intersect(constant_6,v1421_2);
        const Space v1421_4 = (has_head(v1421_3) ? constant_7 : Space{});
        const Space v1421_5 = subtract(constant_0,v1421_4);
        Space v1421_7;
        if (!v1421_5.empty()) {
          const Space v1422_6 = routine_57(c, v1414_21_head, v1414_21_tail);
          v1421_7 = compose(v1421_5,v1422_6);
        }
        const Space v1421_8 = intersect(constant_6,v1421_2);
        const Space v1421_9 = (has_head(v1421_8) ? constant_7 : Space{});
        Space v1421_11;
        if (!v1421_9.empty()) {
          const Space v1423_10 = routine_58(c, v1414_21_head, v1414_21_tail);
          v1421_11 = compose(v1421_9,v1423_10);
        }
        const Space v1421_12 = unite(v1421_7,v1421_11);
        v1414_21_result = unite(v1414_21_result,v1421_12);
      }
      const Space v1414_21 = std::move(v1414_21_result);
      v1409_22 = compose(v1409_10,v1414_21);
    }
    const Space v1409_23 = unite(v1409_8,v1409_22);
    v1408_21_result = unite(v1408_21_result,v1409_23);
  }
  const Space v1408_21 = std::move(v1408_21_result);
  return v1408_21;
}

static Space routine_155(Context& c, const Path& p0, const Space& s0) {
  Space v1424_11_result;
  for (int v1424_11_label = 1; v1424_11_label <= 2; ++v1424_11_label) {
    const Space v1424_11_tail = child(s0,v1424_11_label);
    if (v1424_11_tail.empty()) continue;
    const Path v1424_11_head{v1424_11_label};
    const Space v1425_2 = singleton(v1424_11_head);
    const Space v1425_3 = intersect(constant_6,v1425_2);
    const Space v1425_4 = (has_head(v1425_3) ? constant_7 : Space{});
    const Space v1425_5 = subtract(constant_0,v1425_4);
    Space v1425_8;
    if (!v1425_5.empty()) {
      const Path v1426_6 = concat_path(p0,v1424_11_head);
      Space v1426_7_result;
      for (int v1426_7_label = 1; v1426_7_label <= 2; ++v1426_7_label) {
        const Space v1426_7_tail = child(v1424_11_tail,v1426_7_label);
        if (v1426_7_tail.empty()) continue;
        const Path v1426_7_head{v1426_7_label};
        const Space v1427_2 = singleton(v1426_7_head);
        const Space v1427_3 = intersect(constant_6,v1427_2);
        const Space v1427_4 = (has_head(v1427_3) ? constant_7 : Space{});
        const Space v1427_5 = subtract(constant_0,v1427_4);
        Space v1427_8;
        if (!v1427_5.empty()) {
          const Path v1428_6 = concat_path(v1426_6,v1426_7_head);
          const Space v1428_7 = routine_199(c, v1428_6, v1426_7_tail);
          v1427_8 = compose(v1427_5,v1428_7);
        }
        const Space v1427_9 = intersect(constant_6,v1427_2);
        const Space v1427_10 = (has_head(v1427_9) ? constant_7 : Space{});
        Space v1427_12;
        if (!v1427_10.empty()) {
          const Path v1429_6 = concat_path(v1426_6,v1426_7_head);
          const Space v1429_11 = routine_200(c, v1429_6, v1426_7_tail);
          v1427_12 = compose(v1427_10,v1429_11);
        }
        const Space v1427_13 = unite(v1427_8,v1427_12);
        v1426_7_result = unite(v1426_7_result,v1427_13);
      }
      const Space v1426_7 = std::move(v1426_7_result);
      v1425_8 = compose(v1425_5,v1426_7);
    }
    const Space v1425_9 = intersect(constant_6,v1425_2);
    const Space v1425_10 = (has_head(v1425_9) ? constant_7 : Space{});
    Space v1425_12;
    if (!v1425_10.empty()) {
      const Path v1430_6 = concat_path(p0,v1424_11_head);
      Space v1430_11_result;
      for (int v1430_11_label = 1; v1430_11_label <= 2; ++v1430_11_label) {
        const Space v1430_11_tail = child(v1424_11_tail,v1430_11_label);
        if (v1430_11_tail.empty()) continue;
        const Path v1430_11_head{v1430_11_label};
        const Space v1431_2 = singleton(v1430_11_head);
        const Space v1431_3 = intersect(constant_6,v1431_2);
        const Space v1431_4 = (has_head(v1431_3) ? constant_7 : Space{});
        const Space v1431_5 = subtract(constant_0,v1431_4);
        Space v1431_8;
        if (!v1431_5.empty()) {
          const Path v1432_6 = concat_path(v1430_6,v1430_11_head);
          const Space v1432_7 = routine_199(c, v1432_6, v1430_11_tail);
          v1431_8 = compose(v1431_5,v1432_7);
        }
        const Space v1431_9 = intersect(constant_6,v1431_2);
        const Space v1431_10 = (has_head(v1431_9) ? constant_7 : Space{});
        Space v1431_12;
        if (!v1431_10.empty()) {
          const Path v1433_6 = concat_path(v1430_6,v1430_11_head);
          const Space v1433_11 = routine_100(c, v1433_6, v1430_11_tail);
          v1431_12 = compose(v1431_10,v1433_11);
        }
        const Space v1431_13 = unite(v1431_8,v1431_12);
        v1430_11_result = unite(v1430_11_result,v1431_13);
      }
      const Space v1430_11 = std::move(v1430_11_result);
      v1425_12 = compose(v1425_10,v1430_11);
    }
    const Space v1425_13 = unite(v1425_8,v1425_12);
    v1424_11_result = unite(v1424_11_result,v1425_13);
  }
  const Space v1424_11 = std::move(v1424_11_result);
  return v1424_11;
}

static Space routine_156(Context& c, const Path& p0, const Space& s0) {
  Space v1434_9_result;
  for (int v1434_9_label = 1; v1434_9_label <= 2; ++v1434_9_label) {
    const Space v1434_9_tail = child(s0,v1434_9_label);
    if (v1434_9_tail.empty()) continue;
    const Path v1434_9_head{v1434_9_label};
    const Space v1435_2 = singleton(v1434_9_head);
    const Space v1435_3 = intersect(constant_6,v1435_2);
    const Space v1435_4 = (has_head(v1435_3) ? constant_7 : Space{});
    const Space v1435_5 = subtract(constant_0,v1435_4);
    Space v1435_8;
    if (!v1435_5.empty()) {
      const Path v1436_6 = concat_path(p0,v1434_9_head);
      Space v1436_7_result;
      for (int v1436_7_label = 1; v1436_7_label <= 2; ++v1436_7_label) {
        const Space v1436_7_tail = child(v1434_9_tail,v1436_7_label);
        if (v1436_7_tail.empty()) continue;
        const Path v1436_7_head{v1436_7_label};
        const Space v1437_2 = singleton(v1436_7_head);
        const Space v1437_3 = intersect(constant_6,v1437_2);
        const Space v1437_4 = (has_head(v1437_3) ? constant_7 : Space{});
        const Space v1437_5 = subtract(constant_0,v1437_4);
        Space v1437_8;
        if (!v1437_5.empty()) {
          const Path v1438_6 = concat_path(v1436_6,v1436_7_head);
          const Space v1438_7 = routine_199(c, v1438_6, v1436_7_tail);
          v1437_8 = compose(v1437_5,v1438_7);
        }
        const Space v1437_9 = intersect(constant_6,v1437_2);
        const Space v1437_10 = (has_head(v1437_9) ? constant_7 : Space{});
        Space v1437_12;
        if (!v1437_10.empty()) {
          const Path v1439_6 = concat_path(v1436_6,v1436_7_head);
          const Space v1439_11 = routine_200(c, v1439_6, v1436_7_tail);
          v1437_12 = compose(v1437_10,v1439_11);
        }
        const Space v1437_13 = unite(v1437_8,v1437_12);
        v1436_7_result = unite(v1436_7_result,v1437_13);
      }
      const Space v1436_7 = std::move(v1436_7_result);
      v1435_8 = compose(v1435_5,v1436_7);
    }
    const Space v1435_9 = intersect(constant_6,v1435_2);
    const Space v1435_10 = (has_head(v1435_9) ? constant_7 : Space{});
    const Space v1435_11 = compose(v1435_10,constant_9);
    const Space v1435_12 = unite(v1435_8,v1435_11);
    v1434_9_result = unite(v1434_9_result,v1435_12);
  }
  const Space v1434_9 = std::move(v1434_9_result);
  return v1434_9;
}

static Space routine_157(Context& c, const Path& p0, const Space& s0) {
  Space v1440_11_result;
  for (int v1440_11_label = 1; v1440_11_label <= 2; ++v1440_11_label) {
    const Space v1440_11_tail = child(s0,v1440_11_label);
    if (v1440_11_tail.empty()) continue;
    const Path v1440_11_head{v1440_11_label};
    const Space v1441_2 = singleton(v1440_11_head);
    const Space v1441_3 = intersect(constant_6,v1441_2);
    const Space v1441_4 = (has_head(v1441_3) ? constant_7 : Space{});
    const Space v1441_5 = subtract(constant_0,v1441_4);
    Space v1441_8;
    if (!v1441_5.empty()) {
      const Path v1442_6 = concat_path(p0,v1440_11_head);
      Space v1442_7_result;
      for (int v1442_7_label = 1; v1442_7_label <= 2; ++v1442_7_label) {
        const Space v1442_7_tail = child(v1440_11_tail,v1442_7_label);
        if (v1442_7_tail.empty()) continue;
        const Path v1442_7_head{v1442_7_label};
        const Space v1443_2 = singleton(v1442_7_head);
        const Space v1443_3 = intersect(constant_6,v1443_2);
        const Space v1443_4 = (has_head(v1443_3) ? constant_7 : Space{});
        const Space v1443_5 = subtract(constant_0,v1443_4);
        Space v1443_8;
        if (!v1443_5.empty()) {
          const Path v1444_6 = concat_path(v1442_6,v1442_7_head);
          const Space v1444_7 = routine_201(c, v1444_6, v1442_7_tail);
          v1443_8 = compose(v1443_5,v1444_7);
        }
        const Space v1443_9 = intersect(constant_6,v1443_2);
        const Space v1443_10 = (has_head(v1443_9) ? constant_7 : Space{});
        Space v1443_12;
        if (!v1443_10.empty()) {
          const Path v1445_6 = concat_path(v1442_6,v1442_7_head);
          const Space v1445_11 = routine_202(c, v1445_6, v1442_7_tail);
          v1443_12 = compose(v1443_10,v1445_11);
        }
        const Space v1443_13 = unite(v1443_8,v1443_12);
        v1442_7_result = unite(v1442_7_result,v1443_13);
      }
      const Space v1442_7 = std::move(v1442_7_result);
      v1441_8 = compose(v1441_5,v1442_7);
    }
    const Space v1441_9 = intersect(constant_6,v1441_2);
    const Space v1441_10 = (has_head(v1441_9) ? constant_7 : Space{});
    Space v1441_12;
    if (!v1441_10.empty()) {
      const Path v1446_6 = concat_path(p0,v1440_11_head);
      Space v1446_11_result;
      for (int v1446_11_label = 1; v1446_11_label <= 2; ++v1446_11_label) {
        const Space v1446_11_tail = child(v1440_11_tail,v1446_11_label);
        if (v1446_11_tail.empty()) continue;
        const Path v1446_11_head{v1446_11_label};
        const Space v1447_2 = singleton(v1446_11_head);
        const Space v1447_3 = intersect(constant_6,v1447_2);
        const Space v1447_4 = (has_head(v1447_3) ? constant_7 : Space{});
        const Space v1447_5 = subtract(constant_0,v1447_4);
        Space v1447_8;
        if (!v1447_5.empty()) {
          const Path v1448_6 = concat_path(v1446_6,v1446_11_head);
          const Space v1448_7 = routine_201(c, v1448_6, v1446_11_tail);
          v1447_8 = compose(v1447_5,v1448_7);
        }
        const Space v1447_9 = intersect(constant_6,v1447_2);
        const Space v1447_10 = (has_head(v1447_9) ? constant_7 : Space{});
        Space v1447_12;
        if (!v1447_10.empty()) {
          const Path v1449_6 = concat_path(v1446_6,v1446_11_head);
          const Space v1449_11 = routine_104(c, v1449_6, v1446_11_tail);
          v1447_12 = compose(v1447_10,v1449_11);
        }
        const Space v1447_13 = unite(v1447_8,v1447_12);
        v1446_11_result = unite(v1446_11_result,v1447_13);
      }
      const Space v1446_11 = std::move(v1446_11_result);
      v1441_12 = compose(v1441_10,v1446_11);
    }
    const Space v1441_13 = unite(v1441_8,v1441_12);
    v1440_11_result = unite(v1440_11_result,v1441_13);
  }
  const Space v1440_11 = std::move(v1440_11_result);
  return v1440_11;
}

static Space routine_158(Context& c, const Path& p0, const Space& s0) {
  Space v1450_9_result;
  for (int v1450_9_label = 1; v1450_9_label <= 2; ++v1450_9_label) {
    const Space v1450_9_tail = child(s0,v1450_9_label);
    if (v1450_9_tail.empty()) continue;
    const Path v1450_9_head{v1450_9_label};
    const Space v1451_2 = singleton(v1450_9_head);
    const Space v1451_3 = intersect(constant_6,v1451_2);
    const Space v1451_4 = (has_head(v1451_3) ? constant_7 : Space{});
    const Space v1451_5 = subtract(constant_0,v1451_4);
    Space v1451_8;
    if (!v1451_5.empty()) {
      const Path v1452_6 = concat_path(p0,v1450_9_head);
      Space v1452_7_result;
      for (int v1452_7_label = 1; v1452_7_label <= 2; ++v1452_7_label) {
        const Space v1452_7_tail = child(v1450_9_tail,v1452_7_label);
        if (v1452_7_tail.empty()) continue;
        const Path v1452_7_head{v1452_7_label};
        const Space v1453_2 = singleton(v1452_7_head);
        const Space v1453_3 = intersect(constant_6,v1453_2);
        const Space v1453_4 = (has_head(v1453_3) ? constant_7 : Space{});
        const Space v1453_5 = subtract(constant_0,v1453_4);
        Space v1453_8;
        if (!v1453_5.empty()) {
          const Path v1454_6 = concat_path(v1452_6,v1452_7_head);
          const Space v1454_7 = routine_201(c, v1454_6, v1452_7_tail);
          v1453_8 = compose(v1453_5,v1454_7);
        }
        const Space v1453_9 = intersect(constant_6,v1453_2);
        const Space v1453_10 = (has_head(v1453_9) ? constant_7 : Space{});
        Space v1453_12;
        if (!v1453_10.empty()) {
          const Path v1455_6 = concat_path(v1452_6,v1452_7_head);
          const Space v1455_11 = routine_202(c, v1455_6, v1452_7_tail);
          v1453_12 = compose(v1453_10,v1455_11);
        }
        const Space v1453_13 = unite(v1453_8,v1453_12);
        v1452_7_result = unite(v1452_7_result,v1453_13);
      }
      const Space v1452_7 = std::move(v1452_7_result);
      v1451_8 = compose(v1451_5,v1452_7);
    }
    const Space v1451_9 = intersect(constant_6,v1451_2);
    const Space v1451_10 = (has_head(v1451_9) ? constant_7 : Space{});
    const Space v1451_11 = compose(v1451_10,constant_9);
    const Space v1451_12 = unite(v1451_8,v1451_11);
    v1450_9_result = unite(v1450_9_result,v1451_12);
  }
  const Space v1450_9 = std::move(v1450_9_result);
  return v1450_9;
}

static Space routine_159(Context& c, const Path& p0, const Space& s0) {
  Space v1456_11_result;
  for (int v1456_11_label = 1; v1456_11_label <= 2; ++v1456_11_label) {
    const Space v1456_11_tail = child(s0,v1456_11_label);
    if (v1456_11_tail.empty()) continue;
    const Path v1456_11_head{v1456_11_label};
    const Space v1457_2 = singleton(v1456_11_head);
    const Space v1457_3 = intersect(constant_6,v1457_2);
    const Space v1457_4 = (has_head(v1457_3) ? constant_7 : Space{});
    const Space v1457_5 = subtract(constant_0,v1457_4);
    Space v1457_8;
    if (!v1457_5.empty()) {
      const Path v1458_6 = concat_path(p0,v1456_11_head);
      Space v1458_7_result;
      for (int v1458_7_label = 1; v1458_7_label <= 2; ++v1458_7_label) {
        const Space v1458_7_tail = child(v1456_11_tail,v1458_7_label);
        if (v1458_7_tail.empty()) continue;
        const Path v1458_7_head{v1458_7_label};
        const Space v1459_2 = singleton(v1458_7_head);
        const Space v1459_3 = intersect(constant_6,v1459_2);
        const Space v1459_4 = (has_head(v1459_3) ? constant_7 : Space{});
        const Space v1459_5 = subtract(constant_0,v1459_4);
        Space v1459_8;
        if (!v1459_5.empty()) {
          const Path v1460_6 = concat_path(v1458_6,v1458_7_head);
          const Space v1460_7 = routine_203(c, v1460_6, v1458_7_tail);
          v1459_8 = compose(v1459_5,v1460_7);
        }
        const Space v1459_9 = intersect(constant_6,v1459_2);
        const Space v1459_10 = (has_head(v1459_9) ? constant_7 : Space{});
        Space v1459_12;
        if (!v1459_10.empty()) {
          const Path v1461_6 = concat_path(v1458_6,v1458_7_head);
          const Space v1461_11 = routine_204(c, v1461_6, v1458_7_tail);
          v1459_12 = compose(v1459_10,v1461_11);
        }
        const Space v1459_13 = unite(v1459_8,v1459_12);
        v1458_7_result = unite(v1458_7_result,v1459_13);
      }
      const Space v1458_7 = std::move(v1458_7_result);
      v1457_8 = compose(v1457_5,v1458_7);
    }
    const Space v1457_9 = intersect(constant_6,v1457_2);
    const Space v1457_10 = (has_head(v1457_9) ? constant_7 : Space{});
    Space v1457_12;
    if (!v1457_10.empty()) {
      const Path v1462_6 = concat_path(p0,v1456_11_head);
      Space v1462_11_result;
      for (int v1462_11_label = 1; v1462_11_label <= 2; ++v1462_11_label) {
        const Space v1462_11_tail = child(v1456_11_tail,v1462_11_label);
        if (v1462_11_tail.empty()) continue;
        const Path v1462_11_head{v1462_11_label};
        const Space v1463_2 = singleton(v1462_11_head);
        const Space v1463_3 = intersect(constant_6,v1463_2);
        const Space v1463_4 = (has_head(v1463_3) ? constant_7 : Space{});
        const Space v1463_5 = subtract(constant_0,v1463_4);
        Space v1463_8;
        if (!v1463_5.empty()) {
          const Path v1464_6 = concat_path(v1462_6,v1462_11_head);
          const Space v1464_7 = routine_203(c, v1464_6, v1462_11_tail);
          v1463_8 = compose(v1463_5,v1464_7);
        }
        const Space v1463_9 = intersect(constant_6,v1463_2);
        const Space v1463_10 = (has_head(v1463_9) ? constant_7 : Space{});
        Space v1463_12;
        if (!v1463_10.empty()) {
          const Path v1465_6 = concat_path(v1462_6,v1462_11_head);
          const Space v1465_11 = routine_107(c, v1465_6, v1462_11_tail);
          v1463_12 = compose(v1463_10,v1465_11);
        }
        const Space v1463_13 = unite(v1463_8,v1463_12);
        v1462_11_result = unite(v1462_11_result,v1463_13);
      }
      const Space v1462_11 = std::move(v1462_11_result);
      v1457_12 = compose(v1457_10,v1462_11);
    }
    const Space v1457_13 = unite(v1457_8,v1457_12);
    v1456_11_result = unite(v1456_11_result,v1457_13);
  }
  const Space v1456_11 = std::move(v1456_11_result);
  return v1456_11;
}

static Space routine_160(Context& c, const Path& p0, const Space& s0) {
  Space v1466_8_result;
  for (int v1466_8_label = 1; v1466_8_label <= 2; ++v1466_8_label) {
    const Space v1466_8_tail = child(s0,v1466_8_label);
    if (v1466_8_tail.empty()) continue;
    const Path v1466_8_head{v1466_8_label};
    const Space v1467_2 = singleton(v1466_8_head);
    const Space v1467_3 = intersect(constant_6,v1467_2);
    const Space v1467_4 = (has_head(v1467_3) ? constant_7 : Space{});
    const Space v1467_5 = subtract(constant_0,v1467_4);
    Space v1467_8;
    if (!v1467_5.empty()) {
      const Path v1468_6 = concat_path(p0,v1466_8_head);
      Space v1468_7_result;
      for (int v1468_7_label = 1; v1468_7_label <= 2; ++v1468_7_label) {
        const Space v1468_7_tail = child(v1466_8_tail,v1468_7_label);
        if (v1468_7_tail.empty()) continue;
        const Path v1468_7_head{v1468_7_label};
        const Space v1469_2 = singleton(v1468_7_head);
        const Space v1469_3 = intersect(constant_6,v1469_2);
        const Space v1469_4 = (has_head(v1469_3) ? constant_7 : Space{});
        const Space v1469_5 = subtract(constant_0,v1469_4);
        Space v1469_8;
        if (!v1469_5.empty()) {
          const Path v1470_6 = concat_path(v1468_6,v1468_7_head);
          const Space v1470_7 = routine_203(c, v1470_6, v1468_7_tail);
          v1469_8 = compose(v1469_5,v1470_7);
        }
        const Space v1469_9 = intersect(constant_6,v1469_2);
        const Space v1469_10 = (has_head(v1469_9) ? constant_7 : Space{});
        Space v1469_12;
        if (!v1469_10.empty()) {
          const Path v1471_6 = concat_path(v1468_6,v1468_7_head);
          const Space v1471_11 = routine_204(c, v1471_6, v1468_7_tail);
          v1469_12 = compose(v1469_10,v1471_11);
        }
        const Space v1469_13 = unite(v1469_8,v1469_12);
        v1468_7_result = unite(v1468_7_result,v1469_13);
      }
      const Space v1468_7 = std::move(v1468_7_result);
      v1467_8 = compose(v1467_5,v1468_7);
    }
    const Space v1467_9 = intersect(constant_6,v1467_2);
    const Space v1467_10 = (has_head(v1467_9) ? constant_7 : Space{});
    const Space v1467_11 = compose(v1467_10,v1466_8_tail);
    const Space v1467_12 = unite(v1467_8,v1467_11);
    v1466_8_result = unite(v1466_8_result,v1467_12);
  }
  const Space v1466_8 = std::move(v1466_8_result);
  return v1466_8;
}

static Space routine_161(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1472_13_result;
  for (int v1472_13_label = 1; v1472_13_label <= 2; ++v1472_13_label) {
    const Space v1472_13_tail = child(s0,v1472_13_label);
    if (v1472_13_tail.empty()) continue;
    const Path v1472_13_head{v1472_13_label};
    const Space v1473_2 = singleton(v1472_13_head);
    const Space v1473_3 = intersect(constant_6,v1473_2);
    const Space v1473_4 = (has_head(v1473_3) ? constant_7 : Space{});
    const Space v1473_5 = subtract(constant_0,v1473_4);
    Space v1473_8;
    if (!v1473_5.empty()) {
      const Path v1474_6 = concat_path(p0,v1472_13_head);
      Space v1474_7_result;
      for (int v1474_7_label = 1; v1474_7_label <= 2; ++v1474_7_label) {
        const Space v1474_7_tail = child(v1472_13_tail,v1474_7_label);
        if (v1474_7_tail.empty()) continue;
        const Path v1474_7_head{v1474_7_label};
        const Space v1475_2 = singleton(v1474_7_head);
        const Space v1475_3 = intersect(constant_6,v1475_2);
        const Space v1475_4 = (has_head(v1475_3) ? constant_7 : Space{});
        const Space v1475_5 = subtract(constant_0,v1475_4);
        Space v1475_8;
        if (!v1475_5.empty()) {
          const Path v1476_6 = concat_path(v1474_6,v1474_7_head);
          const Space v1476_7 = routine_205(c, v1476_6, p1, v1474_7_tail, s1);
          v1475_8 = compose(v1475_5,v1476_7);
        }
        const Space v1475_9 = intersect(constant_6,v1475_2);
        const Space v1475_10 = (has_head(v1475_9) ? constant_7 : Space{});
        Space v1475_12;
        if (!v1475_10.empty()) {
          const Path v1477_6 = concat_path(v1474_6,v1474_7_head);
          const Space v1477_11 = routine_206(c, v1477_6, p1, v1474_7_tail, s1);
          v1475_12 = compose(v1475_10,v1477_11);
        }
        const Space v1475_13 = unite(v1475_8,v1475_12);
        v1474_7_result = unite(v1474_7_result,v1475_13);
      }
      const Space v1474_7 = std::move(v1474_7_result);
      v1473_8 = compose(v1473_5,v1474_7);
    }
    const Space v1473_9 = intersect(constant_6,v1473_2);
    const Space v1473_10 = (has_head(v1473_9) ? constant_7 : Space{});
    Space v1473_12;
    if (!v1473_10.empty()) {
      const Path v1478_6 = concat_path(p0,v1472_13_head);
      Space v1478_11_result;
      for (int v1478_11_label = 1; v1478_11_label <= 2; ++v1478_11_label) {
        const Space v1478_11_tail = child(v1472_13_tail,v1478_11_label);
        if (v1478_11_tail.empty()) continue;
        const Path v1478_11_head{v1478_11_label};
        const Space v1479_2 = singleton(v1478_11_head);
        const Space v1479_3 = intersect(constant_6,v1479_2);
        const Space v1479_4 = (has_head(v1479_3) ? constant_7 : Space{});
        const Space v1479_5 = subtract(constant_0,v1479_4);
        Space v1479_8;
        if (!v1479_5.empty()) {
          const Path v1480_6 = concat_path(v1478_6,v1478_11_head);
          const Space v1480_7 = routine_205(c, v1480_6, p1, v1478_11_tail, s1);
          v1479_8 = compose(v1479_5,v1480_7);
        }
        const Space v1479_9 = intersect(constant_6,v1479_2);
        const Space v1479_10 = (has_head(v1479_9) ? constant_7 : Space{});
        Space v1479_12;
        if (!v1479_10.empty()) {
          const Path v1481_6 = concat_path(v1478_6,v1478_11_head);
          const Space v1481_11 = routine_49(c, v1481_6, p1, v1478_11_tail, s1);
          v1479_12 = compose(v1479_10,v1481_11);
        }
        const Space v1479_13 = unite(v1479_8,v1479_12);
        v1478_11_result = unite(v1478_11_result,v1479_13);
      }
      const Space v1478_11 = std::move(v1478_11_result);
      v1473_12 = compose(v1473_10,v1478_11);
    }
    const Space v1473_13 = unite(v1473_8,v1473_12);
    v1472_13_result = unite(v1472_13_result,v1473_13);
  }
  const Space v1472_13 = std::move(v1472_13_result);
  return v1472_13;
}

static Space routine_162(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1482_8 = unwrap(s1,constant_8);
  Space v1482_21_result;
  for (int v1482_21_label = 1; v1482_21_label <= 2; ++v1482_21_label) {
    const Space v1482_21_tail = child(s0,v1482_21_label);
    if (v1482_21_tail.empty()) continue;
    const Path v1482_21_head{v1482_21_label};
    const Space v1483_2 = singleton(v1482_21_head);
    const Space v1483_3 = intersect(constant_6,v1483_2);
    const Space v1483_4 = (has_head(v1483_3) ? constant_7 : Space{});
    const Space v1483_5 = subtract(constant_0,v1483_4);
    Space v1483_8;
    if (!v1483_5.empty()) {
      const Path v1484_6 = concat_path(p0,v1482_21_head);
      Space v1484_7_result;
      for (int v1484_7_label = 1; v1484_7_label <= 2; ++v1484_7_label) {
        const Space v1484_7_tail = child(v1482_21_tail,v1484_7_label);
        if (v1484_7_tail.empty()) continue;
        const Path v1484_7_head{v1484_7_label};
        const Space v1485_2 = singleton(v1484_7_head);
        const Space v1485_3 = intersect(constant_6,v1485_2);
        const Space v1485_4 = (has_head(v1485_3) ? constant_7 : Space{});
        const Space v1485_5 = subtract(constant_0,v1485_4);
        Space v1485_8;
        if (!v1485_5.empty()) {
          const Path v1486_6 = concat_path(v1484_6,v1484_7_head);
          const Space v1486_7 = routine_205(c, v1486_6, p1, v1484_7_tail, s1);
          v1485_8 = compose(v1485_5,v1486_7);
        }
        const Space v1485_9 = intersect(constant_6,v1485_2);
        const Space v1485_10 = (has_head(v1485_9) ? constant_7 : Space{});
        Space v1485_12;
        if (!v1485_10.empty()) {
          const Path v1487_6 = concat_path(v1484_6,v1484_7_head);
          const Space v1487_11 = routine_206(c, v1487_6, p1, v1484_7_tail, s1);
          v1485_12 = compose(v1485_10,v1487_11);
        }
        const Space v1485_13 = unite(v1485_8,v1485_12);
        v1484_7_result = unite(v1484_7_result,v1485_13);
      }
      const Space v1484_7 = std::move(v1484_7_result);
      v1483_8 = compose(v1483_5,v1484_7);
    }
    const Space v1483_9 = intersect(constant_6,v1483_2);
    const Space v1483_10 = (has_head(v1483_9) ? constant_7 : Space{});
    Space v1483_22;
    if (!v1483_10.empty()) {
      const Path v1488_6 = concat_path(p0,v1482_21_head);
      const Path v1488_11 = concat_path(p1,v1488_6);
      const Space v1488_12 = routine_29(c, v1488_11);
      const Space v1488_13 = intersect(v1482_8,v1488_12);
      const Space v1488_14 = routine_33(c, v1488_13);
      Space v1488_15_result;
      for (int v1488_15_label = 1; v1488_15_label <= 2; ++v1488_15_label) {
        const Space v1488_15_tail = child(v1488_14,v1488_15_label);
        if (v1488_15_tail.empty()) continue;
        const Path v1488_15_head{v1488_15_label};
        const Space v1489_2 = singleton(v1488_15_head);
        const Space v1489_3 = intersect(constant_6,v1489_2);
        const Space v1489_4 = (has_head(v1489_3) ? constant_7 : Space{});
        const Space v1489_5 = subtract(constant_0,v1489_4);
        Space v1489_7;
        if (!v1489_5.empty()) {
          const Space v1490_6 = routine_52(c, v1488_15_head, v1488_15_tail);
          v1489_7 = compose(v1489_5,v1490_6);
        }
        const Space v1489_8 = intersect(constant_6,v1489_2);
        const Space v1489_9 = (has_head(v1489_8) ? constant_7 : Space{});
        Space v1489_11;
        if (!v1489_9.empty()) {
          const Space v1491_10 = routine_53(c, v1488_15_head, v1488_15_tail);
          v1489_11 = compose(v1489_9,v1491_10);
        }
        const Space v1489_12 = unite(v1489_7,v1489_11);
        v1488_15_result = unite(v1488_15_result,v1489_12);
      }
      const Space v1488_15 = std::move(v1488_15_result);
      const Space v1488_16 = routine_54(c, v1488_13);
      Space v1488_17_result;
      for (int v1488_17_label = 1; v1488_17_label <= 2; ++v1488_17_label) {
        const Space v1488_17_tail = child(v1488_16,v1488_17_label);
        if (v1488_17_tail.empty()) continue;
        const Path v1488_17_head{v1488_17_label};
        const Space v1492_2 = singleton(v1488_17_head);
        const Space v1492_3 = intersect(constant_6,v1492_2);
        const Space v1492_4 = (has_head(v1492_3) ? constant_7 : Space{});
        const Space v1492_5 = subtract(constant_0,v1492_4);
        Space v1492_7;
        if (!v1492_5.empty()) {
          const Space v1493_6 = routine_55(c, v1488_17_head, v1488_17_tail);
          v1492_7 = compose(v1492_5,v1493_6);
        }
        const Space v1492_8 = intersect(constant_6,v1492_2);
        const Space v1492_9 = (has_head(v1492_8) ? constant_7 : Space{});
        Space v1492_11;
        if (!v1492_9.empty()) {
          const Space v1494_10 = routine_56(c, v1488_17_head, v1488_17_tail);
          v1492_11 = compose(v1492_9,v1494_10);
        }
        const Space v1492_12 = unite(v1492_7,v1492_11);
        v1488_17_result = unite(v1488_17_result,v1492_12);
      }
      const Space v1488_17 = std::move(v1488_17_result);
      const Space v1488_18 = subtract(v1488_15,v1488_17);
      const Space v1488_19 = singleton(v1488_11);
      const Space v1488_20 = compose(v1488_18,v1488_19);
      Space v1488_21_result;
      for (int v1488_21_label = 1; v1488_21_label <= 2; ++v1488_21_label) {
        const Space v1488_21_tail = child(v1488_20,v1488_21_label);
        if (v1488_21_tail.empty()) continue;
        const Path v1488_21_head{v1488_21_label};
        const Space v1495_2 = singleton(v1488_21_head);
        const Space v1495_3 = intersect(constant_6,v1495_2);
        const Space v1495_4 = (has_head(v1495_3) ? constant_7 : Space{});
        const Space v1495_5 = subtract(constant_0,v1495_4);
        Space v1495_7;
        if (!v1495_5.empty()) {
          const Space v1496_6 = routine_57(c, v1488_21_head, v1488_21_tail);
          v1495_7 = compose(v1495_5,v1496_6);
        }
        const Space v1495_8 = intersect(constant_6,v1495_2);
        const Space v1495_9 = (has_head(v1495_8) ? constant_7 : Space{});
        Space v1495_11;
        if (!v1495_9.empty()) {
          const Space v1497_10 = routine_58(c, v1488_21_head, v1488_21_tail);
          v1495_11 = compose(v1495_9,v1497_10);
        }
        const Space v1495_12 = unite(v1495_7,v1495_11);
        v1488_21_result = unite(v1488_21_result,v1495_12);
      }
      const Space v1488_21 = std::move(v1488_21_result);
      v1483_22 = compose(v1483_10,v1488_21);
    }
    const Space v1483_23 = unite(v1483_8,v1483_22);
    v1482_21_result = unite(v1482_21_result,v1483_23);
  }
  const Space v1482_21 = std::move(v1482_21_result);
  return v1482_21;
}

static Space routine_163(Context& c, const Path& p0, const Space& s0) {
  Space v1498_11_result;
  for (int v1498_11_label = 1; v1498_11_label <= 2; ++v1498_11_label) {
    const Space v1498_11_tail = child(s0,v1498_11_label);
    if (v1498_11_tail.empty()) continue;
    const Path v1498_11_head{v1498_11_label};
    const Space v1499_2 = singleton(v1498_11_head);
    const Space v1499_3 = intersect(constant_6,v1499_2);
    const Space v1499_4 = (has_head(v1499_3) ? constant_7 : Space{});
    const Space v1499_5 = subtract(constant_0,v1499_4);
    Space v1499_8;
    if (!v1499_5.empty()) {
      const Path v1500_6 = concat_path(p0,v1498_11_head);
      Space v1500_7_result;
      for (int v1500_7_label = 1; v1500_7_label <= 2; ++v1500_7_label) {
        const Space v1500_7_tail = child(v1498_11_tail,v1500_7_label);
        if (v1500_7_tail.empty()) continue;
        const Path v1500_7_head{v1500_7_label};
        const Space v1501_2 = singleton(v1500_7_head);
        const Space v1501_3 = intersect(constant_6,v1501_2);
        const Space v1501_4 = (has_head(v1501_3) ? constant_7 : Space{});
        const Space v1501_5 = subtract(constant_0,v1501_4);
        Space v1501_8;
        if (!v1501_5.empty()) {
          const Path v1502_6 = concat_path(v1500_6,v1500_7_head);
          const Space v1502_7 = routine_207(c, v1502_6, v1500_7_tail);
          v1501_8 = compose(v1501_5,v1502_7);
        }
        const Space v1501_9 = intersect(constant_6,v1501_2);
        const Space v1501_10 = (has_head(v1501_9) ? constant_7 : Space{});
        Space v1501_12;
        if (!v1501_10.empty()) {
          const Path v1503_6 = concat_path(v1500_6,v1500_7_head);
          const Space v1503_11 = routine_208(c, v1503_6, v1500_7_tail);
          v1501_12 = compose(v1501_10,v1503_11);
        }
        const Space v1501_13 = unite(v1501_8,v1501_12);
        v1500_7_result = unite(v1500_7_result,v1501_13);
      }
      const Space v1500_7 = std::move(v1500_7_result);
      v1499_8 = compose(v1499_5,v1500_7);
    }
    const Space v1499_9 = intersect(constant_6,v1499_2);
    const Space v1499_10 = (has_head(v1499_9) ? constant_7 : Space{});
    Space v1499_12;
    if (!v1499_10.empty()) {
      const Path v1504_6 = concat_path(p0,v1498_11_head);
      Space v1504_11_result;
      for (int v1504_11_label = 1; v1504_11_label <= 2; ++v1504_11_label) {
        const Space v1504_11_tail = child(v1498_11_tail,v1504_11_label);
        if (v1504_11_tail.empty()) continue;
        const Path v1504_11_head{v1504_11_label};
        const Space v1505_2 = singleton(v1504_11_head);
        const Space v1505_3 = intersect(constant_6,v1505_2);
        const Space v1505_4 = (has_head(v1505_3) ? constant_7 : Space{});
        const Space v1505_5 = subtract(constant_0,v1505_4);
        Space v1505_8;
        if (!v1505_5.empty()) {
          const Path v1506_6 = concat_path(v1504_6,v1504_11_head);
          const Space v1506_7 = routine_207(c, v1506_6, v1504_11_tail);
          v1505_8 = compose(v1505_5,v1506_7);
        }
        const Space v1505_9 = intersect(constant_6,v1505_2);
        const Space v1505_10 = (has_head(v1505_9) ? constant_7 : Space{});
        Space v1505_12;
        if (!v1505_10.empty()) {
          const Path v1507_6 = concat_path(v1504_6,v1504_11_head);
          const Space v1507_11 = routine_100(c, v1507_6, v1504_11_tail);
          v1505_12 = compose(v1505_10,v1507_11);
        }
        const Space v1505_13 = unite(v1505_8,v1505_12);
        v1504_11_result = unite(v1504_11_result,v1505_13);
      }
      const Space v1504_11 = std::move(v1504_11_result);
      v1499_12 = compose(v1499_10,v1504_11);
    }
    const Space v1499_13 = unite(v1499_8,v1499_12);
    v1498_11_result = unite(v1498_11_result,v1499_13);
  }
  const Space v1498_11 = std::move(v1498_11_result);
  return v1498_11;
}

static Space routine_164(Context& c, const Path& p0, const Space& s0) {
  Space v1508_9_result;
  for (int v1508_9_label = 1; v1508_9_label <= 2; ++v1508_9_label) {
    const Space v1508_9_tail = child(s0,v1508_9_label);
    if (v1508_9_tail.empty()) continue;
    const Path v1508_9_head{v1508_9_label};
    const Space v1509_2 = singleton(v1508_9_head);
    const Space v1509_3 = intersect(constant_6,v1509_2);
    const Space v1509_4 = (has_head(v1509_3) ? constant_7 : Space{});
    const Space v1509_5 = subtract(constant_0,v1509_4);
    Space v1509_8;
    if (!v1509_5.empty()) {
      const Path v1510_6 = concat_path(p0,v1508_9_head);
      Space v1510_7_result;
      for (int v1510_7_label = 1; v1510_7_label <= 2; ++v1510_7_label) {
        const Space v1510_7_tail = child(v1508_9_tail,v1510_7_label);
        if (v1510_7_tail.empty()) continue;
        const Path v1510_7_head{v1510_7_label};
        const Space v1511_2 = singleton(v1510_7_head);
        const Space v1511_3 = intersect(constant_6,v1511_2);
        const Space v1511_4 = (has_head(v1511_3) ? constant_7 : Space{});
        const Space v1511_5 = subtract(constant_0,v1511_4);
        Space v1511_8;
        if (!v1511_5.empty()) {
          const Path v1512_6 = concat_path(v1510_6,v1510_7_head);
          const Space v1512_7 = routine_207(c, v1512_6, v1510_7_tail);
          v1511_8 = compose(v1511_5,v1512_7);
        }
        const Space v1511_9 = intersect(constant_6,v1511_2);
        const Space v1511_10 = (has_head(v1511_9) ? constant_7 : Space{});
        Space v1511_12;
        if (!v1511_10.empty()) {
          const Path v1513_6 = concat_path(v1510_6,v1510_7_head);
          const Space v1513_11 = routine_208(c, v1513_6, v1510_7_tail);
          v1511_12 = compose(v1511_10,v1513_11);
        }
        const Space v1511_13 = unite(v1511_8,v1511_12);
        v1510_7_result = unite(v1510_7_result,v1511_13);
      }
      const Space v1510_7 = std::move(v1510_7_result);
      v1509_8 = compose(v1509_5,v1510_7);
    }
    const Space v1509_9 = intersect(constant_6,v1509_2);
    const Space v1509_10 = (has_head(v1509_9) ? constant_7 : Space{});
    const Space v1509_11 = compose(v1509_10,constant_9);
    const Space v1509_12 = unite(v1509_8,v1509_11);
    v1508_9_result = unite(v1508_9_result,v1509_12);
  }
  const Space v1508_9 = std::move(v1508_9_result);
  return v1508_9;
}

static Space routine_165(Context& c, const Path& p0, const Space& s0) {
  Space v1514_11_result;
  for (int v1514_11_label = 1; v1514_11_label <= 2; ++v1514_11_label) {
    const Space v1514_11_tail = child(s0,v1514_11_label);
    if (v1514_11_tail.empty()) continue;
    const Path v1514_11_head{v1514_11_label};
    const Space v1515_2 = singleton(v1514_11_head);
    const Space v1515_3 = intersect(constant_6,v1515_2);
    const Space v1515_4 = (has_head(v1515_3) ? constant_7 : Space{});
    const Space v1515_5 = subtract(constant_0,v1515_4);
    Space v1515_8;
    if (!v1515_5.empty()) {
      const Path v1516_6 = concat_path(p0,v1514_11_head);
      Space v1516_7_result;
      for (int v1516_7_label = 1; v1516_7_label <= 2; ++v1516_7_label) {
        const Space v1516_7_tail = child(v1514_11_tail,v1516_7_label);
        if (v1516_7_tail.empty()) continue;
        const Path v1516_7_head{v1516_7_label};
        const Space v1517_2 = singleton(v1516_7_head);
        const Space v1517_3 = intersect(constant_6,v1517_2);
        const Space v1517_4 = (has_head(v1517_3) ? constant_7 : Space{});
        const Space v1517_5 = subtract(constant_0,v1517_4);
        Space v1517_8;
        if (!v1517_5.empty()) {
          const Path v1518_6 = concat_path(v1516_6,v1516_7_head);
          const Space v1518_7 = routine_209(c, v1518_6, v1516_7_tail);
          v1517_8 = compose(v1517_5,v1518_7);
        }
        const Space v1517_9 = intersect(constant_6,v1517_2);
        const Space v1517_10 = (has_head(v1517_9) ? constant_7 : Space{});
        Space v1517_12;
        if (!v1517_10.empty()) {
          const Path v1519_6 = concat_path(v1516_6,v1516_7_head);
          const Space v1519_11 = routine_210(c, v1519_6, v1516_7_tail);
          v1517_12 = compose(v1517_10,v1519_11);
        }
        const Space v1517_13 = unite(v1517_8,v1517_12);
        v1516_7_result = unite(v1516_7_result,v1517_13);
      }
      const Space v1516_7 = std::move(v1516_7_result);
      v1515_8 = compose(v1515_5,v1516_7);
    }
    const Space v1515_9 = intersect(constant_6,v1515_2);
    const Space v1515_10 = (has_head(v1515_9) ? constant_7 : Space{});
    Space v1515_12;
    if (!v1515_10.empty()) {
      const Path v1520_6 = concat_path(p0,v1514_11_head);
      Space v1520_11_result;
      for (int v1520_11_label = 1; v1520_11_label <= 2; ++v1520_11_label) {
        const Space v1520_11_tail = child(v1514_11_tail,v1520_11_label);
        if (v1520_11_tail.empty()) continue;
        const Path v1520_11_head{v1520_11_label};
        const Space v1521_2 = singleton(v1520_11_head);
        const Space v1521_3 = intersect(constant_6,v1521_2);
        const Space v1521_4 = (has_head(v1521_3) ? constant_7 : Space{});
        const Space v1521_5 = subtract(constant_0,v1521_4);
        Space v1521_8;
        if (!v1521_5.empty()) {
          const Path v1522_6 = concat_path(v1520_6,v1520_11_head);
          const Space v1522_7 = routine_209(c, v1522_6, v1520_11_tail);
          v1521_8 = compose(v1521_5,v1522_7);
        }
        const Space v1521_9 = intersect(constant_6,v1521_2);
        const Space v1521_10 = (has_head(v1521_9) ? constant_7 : Space{});
        Space v1521_12;
        if (!v1521_10.empty()) {
          const Path v1523_6 = concat_path(v1520_6,v1520_11_head);
          const Space v1523_11 = routine_104(c, v1523_6, v1520_11_tail);
          v1521_12 = compose(v1521_10,v1523_11);
        }
        const Space v1521_13 = unite(v1521_8,v1521_12);
        v1520_11_result = unite(v1520_11_result,v1521_13);
      }
      const Space v1520_11 = std::move(v1520_11_result);
      v1515_12 = compose(v1515_10,v1520_11);
    }
    const Space v1515_13 = unite(v1515_8,v1515_12);
    v1514_11_result = unite(v1514_11_result,v1515_13);
  }
  const Space v1514_11 = std::move(v1514_11_result);
  return v1514_11;
}

static Space routine_166(Context& c, const Path& p0, const Space& s0) {
  Space v1524_9_result;
  for (int v1524_9_label = 1; v1524_9_label <= 2; ++v1524_9_label) {
    const Space v1524_9_tail = child(s0,v1524_9_label);
    if (v1524_9_tail.empty()) continue;
    const Path v1524_9_head{v1524_9_label};
    const Space v1525_2 = singleton(v1524_9_head);
    const Space v1525_3 = intersect(constant_6,v1525_2);
    const Space v1525_4 = (has_head(v1525_3) ? constant_7 : Space{});
    const Space v1525_5 = subtract(constant_0,v1525_4);
    Space v1525_8;
    if (!v1525_5.empty()) {
      const Path v1526_6 = concat_path(p0,v1524_9_head);
      Space v1526_7_result;
      for (int v1526_7_label = 1; v1526_7_label <= 2; ++v1526_7_label) {
        const Space v1526_7_tail = child(v1524_9_tail,v1526_7_label);
        if (v1526_7_tail.empty()) continue;
        const Path v1526_7_head{v1526_7_label};
        const Space v1527_2 = singleton(v1526_7_head);
        const Space v1527_3 = intersect(constant_6,v1527_2);
        const Space v1527_4 = (has_head(v1527_3) ? constant_7 : Space{});
        const Space v1527_5 = subtract(constant_0,v1527_4);
        Space v1527_8;
        if (!v1527_5.empty()) {
          const Path v1528_6 = concat_path(v1526_6,v1526_7_head);
          const Space v1528_7 = routine_209(c, v1528_6, v1526_7_tail);
          v1527_8 = compose(v1527_5,v1528_7);
        }
        const Space v1527_9 = intersect(constant_6,v1527_2);
        const Space v1527_10 = (has_head(v1527_9) ? constant_7 : Space{});
        Space v1527_12;
        if (!v1527_10.empty()) {
          const Path v1529_6 = concat_path(v1526_6,v1526_7_head);
          const Space v1529_11 = routine_210(c, v1529_6, v1526_7_tail);
          v1527_12 = compose(v1527_10,v1529_11);
        }
        const Space v1527_13 = unite(v1527_8,v1527_12);
        v1526_7_result = unite(v1526_7_result,v1527_13);
      }
      const Space v1526_7 = std::move(v1526_7_result);
      v1525_8 = compose(v1525_5,v1526_7);
    }
    const Space v1525_9 = intersect(constant_6,v1525_2);
    const Space v1525_10 = (has_head(v1525_9) ? constant_7 : Space{});
    const Space v1525_11 = compose(v1525_10,constant_9);
    const Space v1525_12 = unite(v1525_8,v1525_11);
    v1524_9_result = unite(v1524_9_result,v1525_12);
  }
  const Space v1524_9 = std::move(v1524_9_result);
  return v1524_9;
}

static Space routine_167(Context& c, const Path& p0, const Space& s0) {
  Space v1530_11_result;
  for (int v1530_11_label = 1; v1530_11_label <= 2; ++v1530_11_label) {
    const Space v1530_11_tail = child(s0,v1530_11_label);
    if (v1530_11_tail.empty()) continue;
    const Path v1530_11_head{v1530_11_label};
    const Space v1531_2 = singleton(v1530_11_head);
    const Space v1531_3 = intersect(constant_6,v1531_2);
    const Space v1531_4 = (has_head(v1531_3) ? constant_7 : Space{});
    const Space v1531_5 = subtract(constant_0,v1531_4);
    Space v1531_8;
    if (!v1531_5.empty()) {
      const Path v1532_6 = concat_path(p0,v1530_11_head);
      Space v1532_7_result;
      for (int v1532_7_label = 1; v1532_7_label <= 2; ++v1532_7_label) {
        const Space v1532_7_tail = child(v1530_11_tail,v1532_7_label);
        if (v1532_7_tail.empty()) continue;
        const Path v1532_7_head{v1532_7_label};
        const Space v1533_2 = singleton(v1532_7_head);
        const Space v1533_3 = intersect(constant_6,v1533_2);
        const Space v1533_4 = (has_head(v1533_3) ? constant_7 : Space{});
        const Space v1533_5 = subtract(constant_0,v1533_4);
        Space v1533_8;
        if (!v1533_5.empty()) {
          const Path v1534_6 = concat_path(v1532_6,v1532_7_head);
          const Space v1534_7 = routine_211(c, v1534_6, v1532_7_tail);
          v1533_8 = compose(v1533_5,v1534_7);
        }
        const Space v1533_9 = intersect(constant_6,v1533_2);
        const Space v1533_10 = (has_head(v1533_9) ? constant_7 : Space{});
        Space v1533_12;
        if (!v1533_10.empty()) {
          const Path v1535_6 = concat_path(v1532_6,v1532_7_head);
          const Space v1535_11 = routine_212(c, v1535_6, v1532_7_tail);
          v1533_12 = compose(v1533_10,v1535_11);
        }
        const Space v1533_13 = unite(v1533_8,v1533_12);
        v1532_7_result = unite(v1532_7_result,v1533_13);
      }
      const Space v1532_7 = std::move(v1532_7_result);
      v1531_8 = compose(v1531_5,v1532_7);
    }
    const Space v1531_9 = intersect(constant_6,v1531_2);
    const Space v1531_10 = (has_head(v1531_9) ? constant_7 : Space{});
    Space v1531_12;
    if (!v1531_10.empty()) {
      const Path v1536_6 = concat_path(p0,v1530_11_head);
      Space v1536_11_result;
      for (int v1536_11_label = 1; v1536_11_label <= 2; ++v1536_11_label) {
        const Space v1536_11_tail = child(v1530_11_tail,v1536_11_label);
        if (v1536_11_tail.empty()) continue;
        const Path v1536_11_head{v1536_11_label};
        const Space v1537_2 = singleton(v1536_11_head);
        const Space v1537_3 = intersect(constant_6,v1537_2);
        const Space v1537_4 = (has_head(v1537_3) ? constant_7 : Space{});
        const Space v1537_5 = subtract(constant_0,v1537_4);
        Space v1537_8;
        if (!v1537_5.empty()) {
          const Path v1538_6 = concat_path(v1536_6,v1536_11_head);
          const Space v1538_7 = routine_211(c, v1538_6, v1536_11_tail);
          v1537_8 = compose(v1537_5,v1538_7);
        }
        const Space v1537_9 = intersect(constant_6,v1537_2);
        const Space v1537_10 = (has_head(v1537_9) ? constant_7 : Space{});
        Space v1537_12;
        if (!v1537_10.empty()) {
          const Path v1539_6 = concat_path(v1536_6,v1536_11_head);
          const Space v1539_11 = routine_107(c, v1539_6, v1536_11_tail);
          v1537_12 = compose(v1537_10,v1539_11);
        }
        const Space v1537_13 = unite(v1537_8,v1537_12);
        v1536_11_result = unite(v1536_11_result,v1537_13);
      }
      const Space v1536_11 = std::move(v1536_11_result);
      v1531_12 = compose(v1531_10,v1536_11);
    }
    const Space v1531_13 = unite(v1531_8,v1531_12);
    v1530_11_result = unite(v1530_11_result,v1531_13);
  }
  const Space v1530_11 = std::move(v1530_11_result);
  return v1530_11;
}

static Space routine_168(Context& c, const Path& p0, const Space& s0) {
  Space v1540_8_result;
  for (int v1540_8_label = 1; v1540_8_label <= 2; ++v1540_8_label) {
    const Space v1540_8_tail = child(s0,v1540_8_label);
    if (v1540_8_tail.empty()) continue;
    const Path v1540_8_head{v1540_8_label};
    const Space v1541_2 = singleton(v1540_8_head);
    const Space v1541_3 = intersect(constant_6,v1541_2);
    const Space v1541_4 = (has_head(v1541_3) ? constant_7 : Space{});
    const Space v1541_5 = subtract(constant_0,v1541_4);
    Space v1541_8;
    if (!v1541_5.empty()) {
      const Path v1542_6 = concat_path(p0,v1540_8_head);
      Space v1542_7_result;
      for (int v1542_7_label = 1; v1542_7_label <= 2; ++v1542_7_label) {
        const Space v1542_7_tail = child(v1540_8_tail,v1542_7_label);
        if (v1542_7_tail.empty()) continue;
        const Path v1542_7_head{v1542_7_label};
        const Space v1543_2 = singleton(v1542_7_head);
        const Space v1543_3 = intersect(constant_6,v1543_2);
        const Space v1543_4 = (has_head(v1543_3) ? constant_7 : Space{});
        const Space v1543_5 = subtract(constant_0,v1543_4);
        Space v1543_8;
        if (!v1543_5.empty()) {
          const Path v1544_6 = concat_path(v1542_6,v1542_7_head);
          const Space v1544_7 = routine_211(c, v1544_6, v1542_7_tail);
          v1543_8 = compose(v1543_5,v1544_7);
        }
        const Space v1543_9 = intersect(constant_6,v1543_2);
        const Space v1543_10 = (has_head(v1543_9) ? constant_7 : Space{});
        Space v1543_12;
        if (!v1543_10.empty()) {
          const Path v1545_6 = concat_path(v1542_6,v1542_7_head);
          const Space v1545_11 = routine_212(c, v1545_6, v1542_7_tail);
          v1543_12 = compose(v1543_10,v1545_11);
        }
        const Space v1543_13 = unite(v1543_8,v1543_12);
        v1542_7_result = unite(v1542_7_result,v1543_13);
      }
      const Space v1542_7 = std::move(v1542_7_result);
      v1541_8 = compose(v1541_5,v1542_7);
    }
    const Space v1541_9 = intersect(constant_6,v1541_2);
    const Space v1541_10 = (has_head(v1541_9) ? constant_7 : Space{});
    const Space v1541_11 = compose(v1541_10,v1540_8_tail);
    const Space v1541_12 = unite(v1541_8,v1541_11);
    v1540_8_result = unite(v1540_8_result,v1541_12);
  }
  const Space v1540_8 = std::move(v1540_8_result);
  return v1540_8;
}

static Space routine_169(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1546_13_result;
  for (int v1546_13_label = 1; v1546_13_label <= 2; ++v1546_13_label) {
    const Space v1546_13_tail = child(s0,v1546_13_label);
    if (v1546_13_tail.empty()) continue;
    const Path v1546_13_head{v1546_13_label};
    const Space v1547_2 = singleton(v1546_13_head);
    const Space v1547_3 = intersect(constant_6,v1547_2);
    const Space v1547_4 = (has_head(v1547_3) ? constant_7 : Space{});
    const Space v1547_5 = subtract(constant_0,v1547_4);
    Space v1547_8;
    if (!v1547_5.empty()) {
      const Path v1548_6 = concat_path(p0,v1546_13_head);
      Space v1548_7_result;
      for (int v1548_7_label = 1; v1548_7_label <= 2; ++v1548_7_label) {
        const Space v1548_7_tail = child(v1546_13_tail,v1548_7_label);
        if (v1548_7_tail.empty()) continue;
        const Path v1548_7_head{v1548_7_label};
        const Space v1549_2 = singleton(v1548_7_head);
        const Space v1549_3 = intersect(constant_6,v1549_2);
        const Space v1549_4 = (has_head(v1549_3) ? constant_7 : Space{});
        const Space v1549_5 = subtract(constant_0,v1549_4);
        Space v1549_8;
        if (!v1549_5.empty()) {
          const Path v1550_6 = concat_path(v1548_6,v1548_7_head);
          const Space v1550_7 = routine_213(c, v1550_6, p1, v1548_7_tail, s1);
          v1549_8 = compose(v1549_5,v1550_7);
        }
        const Space v1549_9 = intersect(constant_6,v1549_2);
        const Space v1549_10 = (has_head(v1549_9) ? constant_7 : Space{});
        Space v1549_12;
        if (!v1549_10.empty()) {
          const Path v1551_6 = concat_path(v1548_6,v1548_7_head);
          const Space v1551_11 = routine_214(c, v1551_6, p1, v1548_7_tail, s1);
          v1549_12 = compose(v1549_10,v1551_11);
        }
        const Space v1549_13 = unite(v1549_8,v1549_12);
        v1548_7_result = unite(v1548_7_result,v1549_13);
      }
      const Space v1548_7 = std::move(v1548_7_result);
      v1547_8 = compose(v1547_5,v1548_7);
    }
    const Space v1547_9 = intersect(constant_6,v1547_2);
    const Space v1547_10 = (has_head(v1547_9) ? constant_7 : Space{});
    Space v1547_12;
    if (!v1547_10.empty()) {
      const Path v1552_6 = concat_path(p0,v1546_13_head);
      Space v1552_11_result;
      for (int v1552_11_label = 1; v1552_11_label <= 2; ++v1552_11_label) {
        const Space v1552_11_tail = child(v1546_13_tail,v1552_11_label);
        if (v1552_11_tail.empty()) continue;
        const Path v1552_11_head{v1552_11_label};
        const Space v1553_2 = singleton(v1552_11_head);
        const Space v1553_3 = intersect(constant_6,v1553_2);
        const Space v1553_4 = (has_head(v1553_3) ? constant_7 : Space{});
        const Space v1553_5 = subtract(constant_0,v1553_4);
        Space v1553_8;
        if (!v1553_5.empty()) {
          const Path v1554_6 = concat_path(v1552_6,v1552_11_head);
          const Space v1554_7 = routine_213(c, v1554_6, p1, v1552_11_tail, s1);
          v1553_8 = compose(v1553_5,v1554_7);
        }
        const Space v1553_9 = intersect(constant_6,v1553_2);
        const Space v1553_10 = (has_head(v1553_9) ? constant_7 : Space{});
        Space v1553_12;
        if (!v1553_10.empty()) {
          const Path v1555_6 = concat_path(v1552_6,v1552_11_head);
          const Space v1555_11 = routine_26(c, v1555_6, p1, v1552_11_tail, s1);
          v1553_12 = compose(v1553_10,v1555_11);
        }
        const Space v1553_13 = unite(v1553_8,v1553_12);
        v1552_11_result = unite(v1552_11_result,v1553_13);
      }
      const Space v1552_11 = std::move(v1552_11_result);
      v1547_12 = compose(v1547_10,v1552_11);
    }
    const Space v1547_13 = unite(v1547_8,v1547_12);
    v1546_13_result = unite(v1546_13_result,v1547_13);
  }
  const Space v1546_13 = std::move(v1546_13_result);
  return v1546_13;
}

static Space routine_170(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1556_8 = unwrap(s1,constant_8);
  Space v1556_21_result;
  for (int v1556_21_label = 1; v1556_21_label <= 2; ++v1556_21_label) {
    const Space v1556_21_tail = child(s0,v1556_21_label);
    if (v1556_21_tail.empty()) continue;
    const Path v1556_21_head{v1556_21_label};
    const Space v1557_2 = singleton(v1556_21_head);
    const Space v1557_3 = intersect(constant_6,v1557_2);
    const Space v1557_4 = (has_head(v1557_3) ? constant_7 : Space{});
    const Space v1557_5 = subtract(constant_0,v1557_4);
    Space v1557_8;
    if (!v1557_5.empty()) {
      const Path v1558_6 = concat_path(p0,v1556_21_head);
      Space v1558_7_result;
      for (int v1558_7_label = 1; v1558_7_label <= 2; ++v1558_7_label) {
        const Space v1558_7_tail = child(v1556_21_tail,v1558_7_label);
        if (v1558_7_tail.empty()) continue;
        const Path v1558_7_head{v1558_7_label};
        const Space v1559_2 = singleton(v1558_7_head);
        const Space v1559_3 = intersect(constant_6,v1559_2);
        const Space v1559_4 = (has_head(v1559_3) ? constant_7 : Space{});
        const Space v1559_5 = subtract(constant_0,v1559_4);
        Space v1559_8;
        if (!v1559_5.empty()) {
          const Path v1560_6 = concat_path(v1558_6,v1558_7_head);
          const Space v1560_7 = routine_213(c, v1560_6, p1, v1558_7_tail, s1);
          v1559_8 = compose(v1559_5,v1560_7);
        }
        const Space v1559_9 = intersect(constant_6,v1559_2);
        const Space v1559_10 = (has_head(v1559_9) ? constant_7 : Space{});
        Space v1559_12;
        if (!v1559_10.empty()) {
          const Path v1561_6 = concat_path(v1558_6,v1558_7_head);
          const Space v1561_11 = routine_214(c, v1561_6, p1, v1558_7_tail, s1);
          v1559_12 = compose(v1559_10,v1561_11);
        }
        const Space v1559_13 = unite(v1559_8,v1559_12);
        v1558_7_result = unite(v1558_7_result,v1559_13);
      }
      const Space v1558_7 = std::move(v1558_7_result);
      v1557_8 = compose(v1557_5,v1558_7);
    }
    const Space v1557_9 = intersect(constant_6,v1557_2);
    const Space v1557_10 = (has_head(v1557_9) ? constant_7 : Space{});
    Space v1557_22;
    if (!v1557_10.empty()) {
      const Path v1562_6 = concat_path(p0,v1556_21_head);
      const Path v1562_11 = concat_path(p1,v1562_6);
      const Space v1562_12 = routine_29(c, v1562_11);
      const Space v1562_13 = intersect(v1556_8,v1562_12);
      const Space v1562_14 = routine_30(c, v1562_13);
      Space v1562_15_result;
      for (int v1562_15_label = 1; v1562_15_label <= 2; ++v1562_15_label) {
        const Space v1562_15_tail = child(v1562_14,v1562_15_label);
        if (v1562_15_tail.empty()) continue;
        const Path v1562_15_head{v1562_15_label};
        const Space v1563_2 = singleton(v1562_15_head);
        const Space v1563_3 = intersect(constant_6,v1563_2);
        const Space v1563_4 = (has_head(v1563_3) ? constant_7 : Space{});
        const Space v1563_5 = subtract(constant_0,v1563_4);
        Space v1563_7;
        if (!v1563_5.empty()) {
          const Space v1564_6 = routine_31(c, v1562_15_head, v1562_15_tail);
          v1563_7 = compose(v1563_5,v1564_6);
        }
        const Space v1563_8 = intersect(constant_6,v1563_2);
        const Space v1563_9 = (has_head(v1563_8) ? constant_7 : Space{});
        Space v1563_11;
        if (!v1563_9.empty()) {
          const Space v1565_10 = routine_32(c, v1562_15_head, v1562_15_tail);
          v1563_11 = compose(v1563_9,v1565_10);
        }
        const Space v1563_12 = unite(v1563_7,v1563_11);
        v1562_15_result = unite(v1562_15_result,v1563_12);
      }
      const Space v1562_15 = std::move(v1562_15_result);
      const Space v1562_16 = routine_33(c, v1562_13);
      Space v1562_17_result;
      for (int v1562_17_label = 1; v1562_17_label <= 2; ++v1562_17_label) {
        const Space v1562_17_tail = child(v1562_16,v1562_17_label);
        if (v1562_17_tail.empty()) continue;
        const Path v1562_17_head{v1562_17_label};
        const Space v1566_2 = singleton(v1562_17_head);
        const Space v1566_3 = intersect(constant_6,v1566_2);
        const Space v1566_4 = (has_head(v1566_3) ? constant_7 : Space{});
        const Space v1566_5 = subtract(constant_0,v1566_4);
        Space v1566_7;
        if (!v1566_5.empty()) {
          const Space v1567_6 = routine_34(c, v1562_17_head, v1562_17_tail);
          v1566_7 = compose(v1566_5,v1567_6);
        }
        const Space v1566_8 = intersect(constant_6,v1566_2);
        const Space v1566_9 = (has_head(v1566_8) ? constant_7 : Space{});
        Space v1566_11;
        if (!v1566_9.empty()) {
          const Space v1568_10 = routine_35(c, v1562_17_head, v1562_17_tail);
          v1566_11 = compose(v1566_9,v1568_10);
        }
        const Space v1566_12 = unite(v1566_7,v1566_11);
        v1562_17_result = unite(v1562_17_result,v1566_12);
      }
      const Space v1562_17 = std::move(v1562_17_result);
      const Space v1562_18 = subtract(v1562_15,v1562_17);
      const Space v1562_19 = singleton(v1562_11);
      const Space v1562_20 = compose(v1562_18,v1562_19);
      Space v1562_21_result;
      for (int v1562_21_label = 1; v1562_21_label <= 2; ++v1562_21_label) {
        const Space v1562_21_tail = child(v1562_20,v1562_21_label);
        if (v1562_21_tail.empty()) continue;
        const Path v1562_21_head{v1562_21_label};
        const Space v1569_2 = singleton(v1562_21_head);
        const Space v1569_3 = intersect(constant_6,v1569_2);
        const Space v1569_4 = (has_head(v1569_3) ? constant_7 : Space{});
        const Space v1569_5 = subtract(constant_0,v1569_4);
        Space v1569_7;
        if (!v1569_5.empty()) {
          const Space v1570_6 = routine_36(c, v1562_21_head, v1562_21_tail);
          v1569_7 = compose(v1569_5,v1570_6);
        }
        const Space v1569_8 = intersect(constant_6,v1569_2);
        const Space v1569_9 = (has_head(v1569_8) ? constant_7 : Space{});
        Space v1569_11;
        if (!v1569_9.empty()) {
          const Space v1571_10 = routine_37(c, v1562_21_head, v1562_21_tail);
          v1569_11 = compose(v1569_9,v1571_10);
        }
        const Space v1569_12 = unite(v1569_7,v1569_11);
        v1562_21_result = unite(v1562_21_result,v1569_12);
      }
      const Space v1562_21 = std::move(v1562_21_result);
      v1557_22 = compose(v1557_10,v1562_21);
    }
    const Space v1557_23 = unite(v1557_8,v1557_22);
    v1556_21_result = unite(v1556_21_result,v1557_23);
  }
  const Space v1556_21 = std::move(v1556_21_result);
  return v1556_21;
}

static Space routine_171(Context& c, const Path& p0, const Space& s0) {
  Space v1572_11_result;
  for (int v1572_11_label = 1; v1572_11_label <= 2; ++v1572_11_label) {
    const Space v1572_11_tail = child(s0,v1572_11_label);
    if (v1572_11_tail.empty()) continue;
    const Path v1572_11_head{v1572_11_label};
    const Space v1573_2 = singleton(v1572_11_head);
    const Space v1573_3 = intersect(constant_6,v1573_2);
    const Space v1573_4 = (has_head(v1573_3) ? constant_7 : Space{});
    const Space v1573_5 = subtract(constant_0,v1573_4);
    Space v1573_8;
    if (!v1573_5.empty()) {
      const Path v1574_6 = concat_path(p0,v1572_11_head);
      Space v1574_7_result;
      for (int v1574_7_label = 1; v1574_7_label <= 2; ++v1574_7_label) {
        const Space v1574_7_tail = child(v1572_11_tail,v1574_7_label);
        if (v1574_7_tail.empty()) continue;
        const Path v1574_7_head{v1574_7_label};
        const Space v1575_2 = singleton(v1574_7_head);
        const Space v1575_3 = intersect(constant_6,v1575_2);
        const Space v1575_4 = (has_head(v1575_3) ? constant_7 : Space{});
        const Space v1575_5 = subtract(constant_0,v1575_4);
        Space v1575_8;
        if (!v1575_5.empty()) {
          const Path v1576_6 = concat_path(v1574_6,v1574_7_head);
          const Space v1576_7 = routine_215(c, v1576_6, v1574_7_tail);
          v1575_8 = compose(v1575_5,v1576_7);
        }
        const Space v1575_9 = intersect(constant_6,v1575_2);
        const Space v1575_10 = (has_head(v1575_9) ? constant_7 : Space{});
        Space v1575_12;
        if (!v1575_10.empty()) {
          const Path v1577_6 = concat_path(v1574_6,v1574_7_head);
          const Space v1577_11 = routine_216(c, v1577_6, v1574_7_tail);
          v1575_12 = compose(v1575_10,v1577_11);
        }
        const Space v1575_13 = unite(v1575_8,v1575_12);
        v1574_7_result = unite(v1574_7_result,v1575_13);
      }
      const Space v1574_7 = std::move(v1574_7_result);
      v1573_8 = compose(v1573_5,v1574_7);
    }
    const Space v1573_9 = intersect(constant_6,v1573_2);
    const Space v1573_10 = (has_head(v1573_9) ? constant_7 : Space{});
    Space v1573_12;
    if (!v1573_10.empty()) {
      const Path v1578_6 = concat_path(p0,v1572_11_head);
      Space v1578_11_result;
      for (int v1578_11_label = 1; v1578_11_label <= 2; ++v1578_11_label) {
        const Space v1578_11_tail = child(v1572_11_tail,v1578_11_label);
        if (v1578_11_tail.empty()) continue;
        const Path v1578_11_head{v1578_11_label};
        const Space v1579_2 = singleton(v1578_11_head);
        const Space v1579_3 = intersect(constant_6,v1579_2);
        const Space v1579_4 = (has_head(v1579_3) ? constant_7 : Space{});
        const Space v1579_5 = subtract(constant_0,v1579_4);
        Space v1579_8;
        if (!v1579_5.empty()) {
          const Path v1580_6 = concat_path(v1578_6,v1578_11_head);
          const Space v1580_7 = routine_215(c, v1580_6, v1578_11_tail);
          v1579_8 = compose(v1579_5,v1580_7);
        }
        const Space v1579_9 = intersect(constant_6,v1579_2);
        const Space v1579_10 = (has_head(v1579_9) ? constant_7 : Space{});
        Space v1579_12;
        if (!v1579_10.empty()) {
          const Path v1581_6 = concat_path(v1578_6,v1578_11_head);
          const Space v1581_11 = routine_80(c, v1581_6, v1578_11_tail);
          v1579_12 = compose(v1579_10,v1581_11);
        }
        const Space v1579_13 = unite(v1579_8,v1579_12);
        v1578_11_result = unite(v1578_11_result,v1579_13);
      }
      const Space v1578_11 = std::move(v1578_11_result);
      v1573_12 = compose(v1573_10,v1578_11);
    }
    const Space v1573_13 = unite(v1573_8,v1573_12);
    v1572_11_result = unite(v1572_11_result,v1573_13);
  }
  const Space v1572_11 = std::move(v1572_11_result);
  return v1572_11;
}

static Space routine_172(Context& c, const Path& p0, const Space& s0) {
  Space v1582_11_result;
  for (int v1582_11_label = 1; v1582_11_label <= 2; ++v1582_11_label) {
    const Space v1582_11_tail = child(s0,v1582_11_label);
    if (v1582_11_tail.empty()) continue;
    const Path v1582_11_head{v1582_11_label};
    const Space v1583_2 = singleton(v1582_11_head);
    const Space v1583_3 = intersect(constant_6,v1583_2);
    const Space v1583_4 = (has_head(v1583_3) ? constant_7 : Space{});
    const Space v1583_5 = subtract(constant_0,v1583_4);
    Space v1583_8;
    if (!v1583_5.empty()) {
      const Path v1584_6 = concat_path(p0,v1582_11_head);
      Space v1584_7_result;
      for (int v1584_7_label = 1; v1584_7_label <= 2; ++v1584_7_label) {
        const Space v1584_7_tail = child(v1582_11_tail,v1584_7_label);
        if (v1584_7_tail.empty()) continue;
        const Path v1584_7_head{v1584_7_label};
        const Space v1585_2 = singleton(v1584_7_head);
        const Space v1585_3 = intersect(constant_6,v1585_2);
        const Space v1585_4 = (has_head(v1585_3) ? constant_7 : Space{});
        const Space v1585_5 = subtract(constant_0,v1585_4);
        Space v1585_8;
        if (!v1585_5.empty()) {
          const Path v1586_6 = concat_path(v1584_6,v1584_7_head);
          const Space v1586_7 = routine_215(c, v1586_6, v1584_7_tail);
          v1585_8 = compose(v1585_5,v1586_7);
        }
        const Space v1585_9 = intersect(constant_6,v1585_2);
        const Space v1585_10 = (has_head(v1585_9) ? constant_7 : Space{});
        Space v1585_12;
        if (!v1585_10.empty()) {
          const Path v1587_6 = concat_path(v1584_6,v1584_7_head);
          const Space v1587_11 = routine_216(c, v1587_6, v1584_7_tail);
          v1585_12 = compose(v1585_10,v1587_11);
        }
        const Space v1585_13 = unite(v1585_8,v1585_12);
        v1584_7_result = unite(v1584_7_result,v1585_13);
      }
      const Space v1584_7 = std::move(v1584_7_result);
      v1583_8 = compose(v1583_5,v1584_7);
    }
    const Space v1583_9 = intersect(constant_6,v1583_2);
    const Space v1583_10 = (has_head(v1583_9) ? constant_7 : Space{});
    Space v1583_12;
    if (!v1583_10.empty()) {
      const Path v1588_6 = concat_path(p0,v1582_11_head);
      Space v1588_11_result;
      for (int v1588_11_label = 1; v1588_11_label <= 2; ++v1588_11_label) {
        const Space v1588_11_tail = child(v1582_11_tail,v1588_11_label);
        if (v1588_11_tail.empty()) continue;
        const Path v1588_11_head{v1588_11_label};
        const Space v1589_2 = singleton(v1588_11_head);
        const Space v1589_3 = intersect(constant_6,v1589_2);
        const Space v1589_4 = (has_head(v1589_3) ? constant_7 : Space{});
        const Space v1589_5 = subtract(constant_0,v1589_4);
        Space v1589_7;
        if (!v1589_5.empty()) {
          const Space v1590_6 = routine_122(c, v1588_11_head, v1588_6, v1588_11_tail);
          v1589_7 = compose(v1589_5,v1590_6);
        }
        const Space v1589_8 = intersect(constant_6,v1589_2);
        const Space v1589_9 = (has_head(v1589_8) ? constant_7 : Space{});
        Space v1589_11;
        if (!v1589_9.empty()) {
          const Space v1591_10 = routine_123(c, v1588_11_head, v1588_6, v1588_11_tail);
          v1589_11 = compose(v1589_9,v1591_10);
        }
        const Space v1589_12 = unite(v1589_7,v1589_11);
        v1588_11_result = unite(v1588_11_result,v1589_12);
      }
      const Space v1588_11 = std::move(v1588_11_result);
      v1583_12 = compose(v1583_10,v1588_11);
    }
    const Space v1583_13 = unite(v1583_8,v1583_12);
    v1582_11_result = unite(v1582_11_result,v1583_13);
  }
  const Space v1582_11 = std::move(v1582_11_result);
  return v1582_11;
}

static Space routine_173(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1592_12_result;
  for (int v1592_12_label = 1; v1592_12_label <= 2; ++v1592_12_label) {
    const Space v1592_12_tail = child(s0,v1592_12_label);
    if (v1592_12_tail.empty()) continue;
    const Path v1592_12_head{v1592_12_label};
    const Space v1593_2 = singleton(v1592_12_head);
    const Space v1593_3 = intersect(constant_6,v1593_2);
    const Space v1593_4 = (has_head(v1593_3) ? constant_7 : Space{});
    const Space v1593_5 = subtract(constant_0,v1593_4);
    Space v1593_8;
    if (!v1593_5.empty()) {
      const Path v1594_6 = concat_path(p0,v1592_12_head);
      Space v1594_7_result;
      for (int v1594_7_label = 1; v1594_7_label <= 2; ++v1594_7_label) {
        const Space v1594_7_tail = child(v1592_12_tail,v1594_7_label);
        if (v1594_7_tail.empty()) continue;
        const Path v1594_7_head{v1594_7_label};
        const Space v1595_2 = singleton(v1594_7_head);
        const Space v1595_3 = intersect(constant_6,v1595_2);
        const Space v1595_4 = (has_head(v1595_3) ? constant_7 : Space{});
        const Space v1595_5 = subtract(constant_0,v1595_4);
        Space v1595_8;
        if (!v1595_5.empty()) {
          const Path v1596_6 = concat_path(v1594_6,v1594_7_head);
          const Space v1596_7 = routine_217(c, v1596_6, p1, v1594_7_tail);
          v1595_8 = compose(v1595_5,v1596_7);
        }
        const Space v1595_9 = intersect(constant_6,v1595_2);
        const Space v1595_10 = (has_head(v1595_9) ? constant_7 : Space{});
        Space v1595_12;
        if (!v1595_10.empty()) {
          const Path v1597_6 = concat_path(v1594_6,v1594_7_head);
          const Space v1597_11 = routine_218(c, v1597_6, p1, v1594_7_tail);
          v1595_12 = compose(v1595_10,v1597_11);
        }
        const Space v1595_13 = unite(v1595_8,v1595_12);
        v1594_7_result = unite(v1594_7_result,v1595_13);
      }
      const Space v1594_7 = std::move(v1594_7_result);
      v1593_8 = compose(v1593_5,v1594_7);
    }
    const Space v1593_9 = intersect(constant_6,v1593_2);
    const Space v1593_10 = (has_head(v1593_9) ? constant_7 : Space{});
    Space v1593_12;
    if (!v1593_10.empty()) {
      const Path v1598_6 = concat_path(p0,v1592_12_head);
      Space v1598_11_result;
      for (int v1598_11_label = 1; v1598_11_label <= 2; ++v1598_11_label) {
        const Space v1598_11_tail = child(v1592_12_tail,v1598_11_label);
        if (v1598_11_tail.empty()) continue;
        const Path v1598_11_head{v1598_11_label};
        const Space v1599_2 = singleton(v1598_11_head);
        const Space v1599_3 = intersect(constant_6,v1599_2);
        const Space v1599_4 = (has_head(v1599_3) ? constant_7 : Space{});
        const Space v1599_5 = subtract(constant_0,v1599_4);
        Space v1599_8;
        if (!v1599_5.empty()) {
          const Path v1600_6 = concat_path(v1598_6,v1598_11_head);
          const Space v1600_7 = routine_217(c, v1600_6, p1, v1598_11_tail);
          v1599_8 = compose(v1599_5,v1600_7);
        }
        const Space v1599_9 = intersect(constant_6,v1599_2);
        const Space v1599_10 = (has_head(v1599_9) ? constant_7 : Space{});
        Space v1599_12;
        if (!v1599_10.empty()) {
          const Path v1601_6 = concat_path(v1598_6,v1598_11_head);
          const Space v1601_11 = routine_137(c, v1601_6, p1, v1598_11_tail);
          v1599_12 = compose(v1599_10,v1601_11);
        }
        const Space v1599_13 = unite(v1599_8,v1599_12);
        v1598_11_result = unite(v1598_11_result,v1599_13);
      }
      const Space v1598_11 = std::move(v1598_11_result);
      v1593_12 = compose(v1593_10,v1598_11);
    }
    const Space v1593_13 = unite(v1593_8,v1593_12);
    v1592_12_result = unite(v1592_12_result,v1593_13);
  }
  const Space v1592_12 = std::move(v1592_12_result);
  return v1592_12;
}

static Space routine_174(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1602_7 = unwrap(constant_12,p1);
  const Space v1602_9 = unwrap(constant_12,p0);
  Space v1602_13_result;
  for (int v1602_13_label = 1; v1602_13_label <= 2; ++v1602_13_label) {
    const Space v1602_13_tail = child(s0,v1602_13_label);
    if (v1602_13_tail.empty()) continue;
    const Path v1602_13_head{v1602_13_label};
    const Space v1603_2 = singleton(v1602_13_head);
    const Space v1603_3 = intersect(constant_6,v1603_2);
    const Space v1603_4 = (has_head(v1603_3) ? constant_7 : Space{});
    const Space v1603_5 = subtract(constant_0,v1603_4);
    Space v1603_8;
    if (!v1603_5.empty()) {
      const Path v1604_6 = concat_path(p0,v1602_13_head);
      Space v1604_7_result;
      for (int v1604_7_label = 1; v1604_7_label <= 2; ++v1604_7_label) {
        const Space v1604_7_tail = child(v1602_13_tail,v1604_7_label);
        if (v1604_7_tail.empty()) continue;
        const Path v1604_7_head{v1604_7_label};
        const Space v1605_2 = singleton(v1604_7_head);
        const Space v1605_3 = intersect(constant_6,v1605_2);
        const Space v1605_4 = (has_head(v1605_3) ? constant_7 : Space{});
        const Space v1605_5 = subtract(constant_0,v1605_4);
        Space v1605_8;
        if (!v1605_5.empty()) {
          const Path v1606_6 = concat_path(v1604_6,v1604_7_head);
          const Space v1606_7 = routine_217(c, v1606_6, p1, v1604_7_tail);
          v1605_8 = compose(v1605_5,v1606_7);
        }
        const Space v1605_9 = intersect(constant_6,v1605_2);
        const Space v1605_10 = (has_head(v1605_9) ? constant_7 : Space{});
        Space v1605_12;
        if (!v1605_10.empty()) {
          const Path v1607_6 = concat_path(v1604_6,v1604_7_head);
          const Space v1607_11 = routine_218(c, v1607_6, p1, v1604_7_tail);
          v1605_12 = compose(v1605_10,v1607_11);
        }
        const Space v1605_13 = unite(v1605_8,v1605_12);
        v1604_7_result = unite(v1604_7_result,v1605_13);
      }
      const Space v1604_7 = std::move(v1604_7_result);
      v1603_8 = compose(v1603_5,v1604_7);
    }
    const Space v1603_9 = intersect(constant_6,v1603_2);
    const Space v1603_10 = (has_head(v1603_9) ? constant_7 : Space{});
    const Space v1603_11 = unwrap(v1602_9,v1602_13_head);
    const Space v1603_12 = compose(v1602_7,v1603_11);
    const Path v1608_6 = concat_path(p0,v1602_13_head);
    const Path v1603_13 = concat_path(p1,v1608_6);
    const Space v1603_14 = singleton(v1603_13);
    const Space v1603_15 = subtract(v1603_12,v1603_14);
    const Space v1603_16 = compose(v1603_10,v1603_15);
    const Space v1603_17 = unite(v1603_8,v1603_16);
    v1602_13_result = unite(v1602_13_result,v1603_17);
  }
  const Space v1602_13 = std::move(v1602_13_result);
  return v1602_13;
}

static Space routine_175(Context& c, const Path& p0, const Space& s0) {
  Space v1609_11_result;
  for (int v1609_11_label = 1; v1609_11_label <= 2; ++v1609_11_label) {
    const Space v1609_11_tail = child(s0,v1609_11_label);
    if (v1609_11_tail.empty()) continue;
    const Path v1609_11_head{v1609_11_label};
    const Space v1610_2 = singleton(v1609_11_head);
    const Space v1610_3 = intersect(constant_6,v1610_2);
    const Space v1610_4 = (has_head(v1610_3) ? constant_7 : Space{});
    const Space v1610_5 = subtract(constant_0,v1610_4);
    Space v1610_8;
    if (!v1610_5.empty()) {
      const Path v1611_6 = concat_path(p0,v1609_11_head);
      Space v1611_7_result;
      for (int v1611_7_label = 1; v1611_7_label <= 2; ++v1611_7_label) {
        const Space v1611_7_tail = child(v1609_11_tail,v1611_7_label);
        if (v1611_7_tail.empty()) continue;
        const Path v1611_7_head{v1611_7_label};
        const Space v1612_2 = singleton(v1611_7_head);
        const Space v1612_3 = intersect(constant_6,v1612_2);
        const Space v1612_4 = (has_head(v1612_3) ? constant_7 : Space{});
        const Space v1612_5 = subtract(constant_0,v1612_4);
        Space v1612_8;
        if (!v1612_5.empty()) {
          const Path v1613_6 = concat_path(v1611_6,v1611_7_head);
          const Space v1613_7 = routine_219(c, v1613_6, v1611_7_tail);
          v1612_8 = compose(v1612_5,v1613_7);
        }
        const Space v1612_9 = intersect(constant_6,v1612_2);
        const Space v1612_10 = (has_head(v1612_9) ? constant_7 : Space{});
        Space v1612_12;
        if (!v1612_10.empty()) {
          const Path v1614_6 = concat_path(v1611_6,v1611_7_head);
          const Space v1614_11 = routine_220(c, v1614_6, v1611_7_tail);
          v1612_12 = compose(v1612_10,v1614_11);
        }
        const Space v1612_13 = unite(v1612_8,v1612_12);
        v1611_7_result = unite(v1611_7_result,v1612_13);
      }
      const Space v1611_7 = std::move(v1611_7_result);
      v1610_8 = compose(v1610_5,v1611_7);
    }
    const Space v1610_9 = intersect(constant_6,v1610_2);
    const Space v1610_10 = (has_head(v1610_9) ? constant_7 : Space{});
    Space v1610_12;
    if (!v1610_10.empty()) {
      const Path v1615_6 = concat_path(p0,v1609_11_head);
      Space v1615_11_result;
      for (int v1615_11_label = 1; v1615_11_label <= 2; ++v1615_11_label) {
        const Space v1615_11_tail = child(v1609_11_tail,v1615_11_label);
        if (v1615_11_tail.empty()) continue;
        const Path v1615_11_head{v1615_11_label};
        const Space v1616_2 = singleton(v1615_11_head);
        const Space v1616_3 = intersect(constant_6,v1616_2);
        const Space v1616_4 = (has_head(v1616_3) ? constant_7 : Space{});
        const Space v1616_5 = subtract(constant_0,v1616_4);
        Space v1616_8;
        if (!v1616_5.empty()) {
          const Path v1617_6 = concat_path(v1615_6,v1615_11_head);
          const Space v1617_7 = routine_219(c, v1617_6, v1615_11_tail);
          v1616_8 = compose(v1616_5,v1617_7);
        }
        const Space v1616_9 = intersect(constant_6,v1616_2);
        const Space v1616_10 = (has_head(v1616_9) ? constant_7 : Space{});
        Space v1616_12;
        if (!v1616_10.empty()) {
          const Path v1618_6 = concat_path(v1615_6,v1615_11_head);
          const Space v1618_11 = routine_69(c, v1618_6, v1615_11_tail);
          v1616_12 = compose(v1616_10,v1618_11);
        }
        const Space v1616_13 = unite(v1616_8,v1616_12);
        v1615_11_result = unite(v1615_11_result,v1616_13);
      }
      const Space v1615_11 = std::move(v1615_11_result);
      v1610_12 = compose(v1610_10,v1615_11);
    }
    const Space v1610_13 = unite(v1610_8,v1610_12);
    v1609_11_result = unite(v1609_11_result,v1610_13);
  }
  const Space v1609_11 = std::move(v1609_11_result);
  return v1609_11;
}

static Space routine_176(Context& c, const Path& p0, const Space& s0) {
  Space v1619_9_result;
  for (int v1619_9_label = 1; v1619_9_label <= 2; ++v1619_9_label) {
    const Space v1619_9_tail = child(s0,v1619_9_label);
    if (v1619_9_tail.empty()) continue;
    const Path v1619_9_head{v1619_9_label};
    const Space v1620_2 = singleton(v1619_9_head);
    const Space v1620_3 = intersect(constant_6,v1620_2);
    const Space v1620_4 = (has_head(v1620_3) ? constant_7 : Space{});
    const Space v1620_5 = subtract(constant_0,v1620_4);
    Space v1620_8;
    if (!v1620_5.empty()) {
      const Path v1621_6 = concat_path(p0,v1619_9_head);
      Space v1621_7_result;
      for (int v1621_7_label = 1; v1621_7_label <= 2; ++v1621_7_label) {
        const Space v1621_7_tail = child(v1619_9_tail,v1621_7_label);
        if (v1621_7_tail.empty()) continue;
        const Path v1621_7_head{v1621_7_label};
        const Space v1622_2 = singleton(v1621_7_head);
        const Space v1622_3 = intersect(constant_6,v1622_2);
        const Space v1622_4 = (has_head(v1622_3) ? constant_7 : Space{});
        const Space v1622_5 = subtract(constant_0,v1622_4);
        Space v1622_8;
        if (!v1622_5.empty()) {
          const Path v1623_6 = concat_path(v1621_6,v1621_7_head);
          const Space v1623_7 = routine_219(c, v1623_6, v1621_7_tail);
          v1622_8 = compose(v1622_5,v1623_7);
        }
        const Space v1622_9 = intersect(constant_6,v1622_2);
        const Space v1622_10 = (has_head(v1622_9) ? constant_7 : Space{});
        Space v1622_12;
        if (!v1622_10.empty()) {
          const Path v1624_6 = concat_path(v1621_6,v1621_7_head);
          const Space v1624_11 = routine_220(c, v1624_6, v1621_7_tail);
          v1622_12 = compose(v1622_10,v1624_11);
        }
        const Space v1622_13 = unite(v1622_8,v1622_12);
        v1621_7_result = unite(v1621_7_result,v1622_13);
      }
      const Space v1621_7 = std::move(v1621_7_result);
      v1620_8 = compose(v1620_5,v1621_7);
    }
    const Space v1620_9 = intersect(constant_6,v1620_2);
    const Space v1620_10 = (has_head(v1620_9) ? constant_7 : Space{});
    const Space v1620_11 = compose(v1620_10,constant_9);
    const Space v1620_12 = unite(v1620_8,v1620_11);
    v1619_9_result = unite(v1619_9_result,v1620_12);
  }
  const Space v1619_9 = std::move(v1619_9_result);
  return v1619_9;
}

static Space routine_177(Context& c, const Path& p0, const Space& s0) {
  Space v1625_11_result;
  for (int v1625_11_label = 1; v1625_11_label <= 2; ++v1625_11_label) {
    const Space v1625_11_tail = child(s0,v1625_11_label);
    if (v1625_11_tail.empty()) continue;
    const Path v1625_11_head{v1625_11_label};
    const Space v1626_2 = singleton(v1625_11_head);
    const Space v1626_3 = intersect(constant_6,v1626_2);
    const Space v1626_4 = (has_head(v1626_3) ? constant_7 : Space{});
    const Space v1626_5 = subtract(constant_0,v1626_4);
    Space v1626_8;
    if (!v1626_5.empty()) {
      const Path v1627_6 = concat_path(p0,v1625_11_head);
      Space v1627_7_result;
      for (int v1627_7_label = 1; v1627_7_label <= 2; ++v1627_7_label) {
        const Space v1627_7_tail = child(v1625_11_tail,v1627_7_label);
        if (v1627_7_tail.empty()) continue;
        const Path v1627_7_head{v1627_7_label};
        const Space v1628_2 = singleton(v1627_7_head);
        const Space v1628_3 = intersect(constant_6,v1628_2);
        const Space v1628_4 = (has_head(v1628_3) ? constant_7 : Space{});
        const Space v1628_5 = subtract(constant_0,v1628_4);
        Space v1628_8;
        if (!v1628_5.empty()) {
          const Path v1629_6 = concat_path(v1627_6,v1627_7_head);
          const Space v1629_7 = routine_221(c, v1629_6, v1627_7_tail);
          v1628_8 = compose(v1628_5,v1629_7);
        }
        const Space v1628_9 = intersect(constant_6,v1628_2);
        const Space v1628_10 = (has_head(v1628_9) ? constant_7 : Space{});
        Space v1628_12;
        if (!v1628_10.empty()) {
          const Path v1630_6 = concat_path(v1627_6,v1627_7_head);
          const Space v1630_11 = routine_222(c, v1630_6, v1627_7_tail);
          v1628_12 = compose(v1628_10,v1630_11);
        }
        const Space v1628_13 = unite(v1628_8,v1628_12);
        v1627_7_result = unite(v1627_7_result,v1628_13);
      }
      const Space v1627_7 = std::move(v1627_7_result);
      v1626_8 = compose(v1626_5,v1627_7);
    }
    const Space v1626_9 = intersect(constant_6,v1626_2);
    const Space v1626_10 = (has_head(v1626_9) ? constant_7 : Space{});
    Space v1626_12;
    if (!v1626_10.empty()) {
      const Path v1631_6 = concat_path(p0,v1625_11_head);
      Space v1631_11_result;
      for (int v1631_11_label = 1; v1631_11_label <= 2; ++v1631_11_label) {
        const Space v1631_11_tail = child(v1625_11_tail,v1631_11_label);
        if (v1631_11_tail.empty()) continue;
        const Path v1631_11_head{v1631_11_label};
        const Space v1632_2 = singleton(v1631_11_head);
        const Space v1632_3 = intersect(constant_6,v1632_2);
        const Space v1632_4 = (has_head(v1632_3) ? constant_7 : Space{});
        const Space v1632_5 = subtract(constant_0,v1632_4);
        Space v1632_8;
        if (!v1632_5.empty()) {
          const Path v1633_6 = concat_path(v1631_6,v1631_11_head);
          const Space v1633_7 = routine_221(c, v1633_6, v1631_11_tail);
          v1632_8 = compose(v1632_5,v1633_7);
        }
        const Space v1632_9 = intersect(constant_6,v1632_2);
        const Space v1632_10 = (has_head(v1632_9) ? constant_7 : Space{});
        Space v1632_12;
        if (!v1632_10.empty()) {
          const Path v1634_6 = concat_path(v1631_6,v1631_11_head);
          const Space v1634_11 = routine_72(c, v1634_6, v1631_11_tail);
          v1632_12 = compose(v1632_10,v1634_11);
        }
        const Space v1632_13 = unite(v1632_8,v1632_12);
        v1631_11_result = unite(v1631_11_result,v1632_13);
      }
      const Space v1631_11 = std::move(v1631_11_result);
      v1626_12 = compose(v1626_10,v1631_11);
    }
    const Space v1626_13 = unite(v1626_8,v1626_12);
    v1625_11_result = unite(v1625_11_result,v1626_13);
  }
  const Space v1625_11 = std::move(v1625_11_result);
  return v1625_11;
}

static Space routine_178(Context& c, const Path& p0, const Space& s0) {
  Space v1635_9_result;
  for (int v1635_9_label = 1; v1635_9_label <= 2; ++v1635_9_label) {
    const Space v1635_9_tail = child(s0,v1635_9_label);
    if (v1635_9_tail.empty()) continue;
    const Path v1635_9_head{v1635_9_label};
    const Space v1636_2 = singleton(v1635_9_head);
    const Space v1636_3 = intersect(constant_6,v1636_2);
    const Space v1636_4 = (has_head(v1636_3) ? constant_7 : Space{});
    const Space v1636_5 = subtract(constant_0,v1636_4);
    Space v1636_8;
    if (!v1636_5.empty()) {
      const Path v1637_6 = concat_path(p0,v1635_9_head);
      Space v1637_7_result;
      for (int v1637_7_label = 1; v1637_7_label <= 2; ++v1637_7_label) {
        const Space v1637_7_tail = child(v1635_9_tail,v1637_7_label);
        if (v1637_7_tail.empty()) continue;
        const Path v1637_7_head{v1637_7_label};
        const Space v1638_2 = singleton(v1637_7_head);
        const Space v1638_3 = intersect(constant_6,v1638_2);
        const Space v1638_4 = (has_head(v1638_3) ? constant_7 : Space{});
        const Space v1638_5 = subtract(constant_0,v1638_4);
        Space v1638_8;
        if (!v1638_5.empty()) {
          const Path v1639_6 = concat_path(v1637_6,v1637_7_head);
          const Space v1639_7 = routine_221(c, v1639_6, v1637_7_tail);
          v1638_8 = compose(v1638_5,v1639_7);
        }
        const Space v1638_9 = intersect(constant_6,v1638_2);
        const Space v1638_10 = (has_head(v1638_9) ? constant_7 : Space{});
        Space v1638_12;
        if (!v1638_10.empty()) {
          const Path v1640_6 = concat_path(v1637_6,v1637_7_head);
          const Space v1640_11 = routine_222(c, v1640_6, v1637_7_tail);
          v1638_12 = compose(v1638_10,v1640_11);
        }
        const Space v1638_13 = unite(v1638_8,v1638_12);
        v1637_7_result = unite(v1637_7_result,v1638_13);
      }
      const Space v1637_7 = std::move(v1637_7_result);
      v1636_8 = compose(v1636_5,v1637_7);
    }
    const Space v1636_9 = intersect(constant_6,v1636_2);
    const Space v1636_10 = (has_head(v1636_9) ? constant_7 : Space{});
    const Space v1636_11 = compose(v1636_10,constant_9);
    const Space v1636_12 = unite(v1636_8,v1636_11);
    v1635_9_result = unite(v1635_9_result,v1636_12);
  }
  const Space v1635_9 = std::move(v1635_9_result);
  return v1635_9;
}

static Space routine_179(Context& c, const Path& p0, const Space& s0) {
  Space v1641_11_result;
  for (int v1641_11_label = 1; v1641_11_label <= 2; ++v1641_11_label) {
    const Space v1641_11_tail = child(s0,v1641_11_label);
    if (v1641_11_tail.empty()) continue;
    const Path v1641_11_head{v1641_11_label};
    const Space v1642_2 = singleton(v1641_11_head);
    const Space v1642_3 = intersect(constant_6,v1642_2);
    const Space v1642_4 = (has_head(v1642_3) ? constant_7 : Space{});
    const Space v1642_5 = subtract(constant_0,v1642_4);
    Space v1642_8;
    if (!v1642_5.empty()) {
      const Path v1643_6 = concat_path(p0,v1641_11_head);
      Space v1643_7_result;
      for (int v1643_7_label = 1; v1643_7_label <= 2; ++v1643_7_label) {
        const Space v1643_7_tail = child(v1641_11_tail,v1643_7_label);
        if (v1643_7_tail.empty()) continue;
        const Path v1643_7_head{v1643_7_label};
        const Space v1644_2 = singleton(v1643_7_head);
        const Space v1644_3 = intersect(constant_6,v1644_2);
        const Space v1644_4 = (has_head(v1644_3) ? constant_7 : Space{});
        const Space v1644_5 = subtract(constant_0,v1644_4);
        Space v1644_8;
        if (!v1644_5.empty()) {
          const Path v1645_6 = concat_path(v1643_6,v1643_7_head);
          const Space v1645_7 = routine_223(c, v1645_6, v1643_7_tail);
          v1644_8 = compose(v1644_5,v1645_7);
        }
        const Space v1644_9 = intersect(constant_6,v1644_2);
        const Space v1644_10 = (has_head(v1644_9) ? constant_7 : Space{});
        Space v1644_12;
        if (!v1644_10.empty()) {
          const Path v1646_6 = concat_path(v1643_6,v1643_7_head);
          const Space v1646_11 = routine_224(c, v1646_6, v1643_7_tail);
          v1644_12 = compose(v1644_10,v1646_11);
        }
        const Space v1644_13 = unite(v1644_8,v1644_12);
        v1643_7_result = unite(v1643_7_result,v1644_13);
      }
      const Space v1643_7 = std::move(v1643_7_result);
      v1642_8 = compose(v1642_5,v1643_7);
    }
    const Space v1642_9 = intersect(constant_6,v1642_2);
    const Space v1642_10 = (has_head(v1642_9) ? constant_7 : Space{});
    Space v1642_12;
    if (!v1642_10.empty()) {
      const Path v1647_6 = concat_path(p0,v1641_11_head);
      Space v1647_11_result;
      for (int v1647_11_label = 1; v1647_11_label <= 2; ++v1647_11_label) {
        const Space v1647_11_tail = child(v1641_11_tail,v1647_11_label);
        if (v1647_11_tail.empty()) continue;
        const Path v1647_11_head{v1647_11_label};
        const Space v1648_2 = singleton(v1647_11_head);
        const Space v1648_3 = intersect(constant_6,v1648_2);
        const Space v1648_4 = (has_head(v1648_3) ? constant_7 : Space{});
        const Space v1648_5 = subtract(constant_0,v1648_4);
        Space v1648_8;
        if (!v1648_5.empty()) {
          const Path v1649_6 = concat_path(v1647_6,v1647_11_head);
          const Space v1649_7 = routine_223(c, v1649_6, v1647_11_tail);
          v1648_8 = compose(v1648_5,v1649_7);
        }
        const Space v1648_9 = intersect(constant_6,v1648_2);
        const Space v1648_10 = (has_head(v1648_9) ? constant_7 : Space{});
        Space v1648_12;
        if (!v1648_10.empty()) {
          const Path v1650_6 = concat_path(v1647_6,v1647_11_head);
          const Space v1650_11 = routine_75(c, v1650_6, v1647_11_tail);
          v1648_12 = compose(v1648_10,v1650_11);
        }
        const Space v1648_13 = unite(v1648_8,v1648_12);
        v1647_11_result = unite(v1647_11_result,v1648_13);
      }
      const Space v1647_11 = std::move(v1647_11_result);
      v1642_12 = compose(v1642_10,v1647_11);
    }
    const Space v1642_13 = unite(v1642_8,v1642_12);
    v1641_11_result = unite(v1641_11_result,v1642_13);
  }
  const Space v1641_11 = std::move(v1641_11_result);
  return v1641_11;
}

static Space routine_180(Context& c, const Path& p0, const Space& s0) {
  Space v1651_8_result;
  for (int v1651_8_label = 1; v1651_8_label <= 2; ++v1651_8_label) {
    const Space v1651_8_tail = child(s0,v1651_8_label);
    if (v1651_8_tail.empty()) continue;
    const Path v1651_8_head{v1651_8_label};
    const Space v1652_2 = singleton(v1651_8_head);
    const Space v1652_3 = intersect(constant_6,v1652_2);
    const Space v1652_4 = (has_head(v1652_3) ? constant_7 : Space{});
    const Space v1652_5 = subtract(constant_0,v1652_4);
    Space v1652_8;
    if (!v1652_5.empty()) {
      const Path v1653_6 = concat_path(p0,v1651_8_head);
      Space v1653_7_result;
      for (int v1653_7_label = 1; v1653_7_label <= 2; ++v1653_7_label) {
        const Space v1653_7_tail = child(v1651_8_tail,v1653_7_label);
        if (v1653_7_tail.empty()) continue;
        const Path v1653_7_head{v1653_7_label};
        const Space v1654_2 = singleton(v1653_7_head);
        const Space v1654_3 = intersect(constant_6,v1654_2);
        const Space v1654_4 = (has_head(v1654_3) ? constant_7 : Space{});
        const Space v1654_5 = subtract(constant_0,v1654_4);
        Space v1654_8;
        if (!v1654_5.empty()) {
          const Path v1655_6 = concat_path(v1653_6,v1653_7_head);
          const Space v1655_7 = routine_223(c, v1655_6, v1653_7_tail);
          v1654_8 = compose(v1654_5,v1655_7);
        }
        const Space v1654_9 = intersect(constant_6,v1654_2);
        const Space v1654_10 = (has_head(v1654_9) ? constant_7 : Space{});
        Space v1654_12;
        if (!v1654_10.empty()) {
          const Path v1656_6 = concat_path(v1653_6,v1653_7_head);
          const Space v1656_11 = routine_224(c, v1656_6, v1653_7_tail);
          v1654_12 = compose(v1654_10,v1656_11);
        }
        const Space v1654_13 = unite(v1654_8,v1654_12);
        v1653_7_result = unite(v1653_7_result,v1654_13);
      }
      const Space v1653_7 = std::move(v1653_7_result);
      v1652_8 = compose(v1652_5,v1653_7);
    }
    const Space v1652_9 = intersect(constant_6,v1652_2);
    const Space v1652_10 = (has_head(v1652_9) ? constant_7 : Space{});
    const Space v1652_11 = compose(v1652_10,v1651_8_tail);
    const Space v1652_12 = unite(v1652_8,v1652_11);
    v1651_8_result = unite(v1651_8_result,v1652_12);
  }
  const Space v1651_8 = std::move(v1651_8_result);
  return v1651_8;
}

static Space routine_181(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1657_8_result;
  for (int v1657_8_label = 1; v1657_8_label <= 2; ++v1657_8_label) {
    const Space v1657_8_tail = child(s0,v1657_8_label);
    if (v1657_8_tail.empty()) continue;
    const Path v1657_8_head{v1657_8_label};
    const Space v1658_2 = singleton(v1657_8_head);
    const Space v1658_3 = intersect(constant_6,v1658_2);
    const Space v1658_4 = (has_head(v1658_3) ? constant_7 : Space{});
    const Space v1658_5 = subtract(constant_0,v1658_4);
    Space v1658_6_result;
    for (int v1658_6_label = 1; v1658_6_label <= 2; ++v1658_6_label) {
      const Space v1658_6_tail = child(v1657_8_tail,v1658_6_label);
      if (v1658_6_tail.empty()) continue;
      const Path v1658_6_head{v1658_6_label};
      const Space v1659_2 = Space{};
      v1658_6_result = unite(v1658_6_result,v1659_2);
    }
    const Space v1658_6 = std::move(v1658_6_result);
    const Space v1658_7 = compose(v1658_5,v1658_6);
    const Space v1658_8 = intersect(constant_6,v1658_2);
    const Space v1658_9 = (has_head(v1658_8) ? constant_7 : Space{});
    Space v1658_12;
    if (!v1658_9.empty()) {
      const Path v1660_10 = concat_path(p0,v1657_8_head);
      Space v1660_11_result;
      for (int v1660_11_label = 1; v1660_11_label <= 2; ++v1660_11_label) {
        const Space v1660_11_tail = child(v1657_8_tail,v1660_11_label);
        if (v1660_11_tail.empty()) continue;
        const Path v1660_11_head{v1660_11_label};
        const Space v1661_2 = singleton(v1660_11_head);
        const Space v1661_3 = intersect(constant_6,v1661_2);
        const Space v1661_4 = (has_head(v1661_3) ? constant_7 : Space{});
        Space v1661_7;
        if (!v1661_4.empty()) {
          const Path v1662_5 = concat_path(v1660_10,v1660_11_head);
          const Space v1662_6 = routine_26(c, v1662_5, p1, v1660_11_tail, s1);
          v1661_7 = compose(v1661_4,v1662_6);
        }
        v1660_11_result = unite(v1660_11_result,v1661_7);
      }
      const Space v1660_11 = std::move(v1660_11_result);
      v1658_12 = compose(v1658_9,v1660_11);
    }
    const Space v1658_13 = unite(v1658_7,v1658_12);
    v1657_8_result = unite(v1657_8_result,v1658_13);
  }
  const Space v1657_8 = std::move(v1657_8_result);
  return v1657_8;
}

static Space routine_182(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1663_8 = unwrap(s1,constant_8);
  Space v1663_18_result;
  for (int v1663_18_label = 1; v1663_18_label <= 2; ++v1663_18_label) {
    const Space v1663_18_tail = child(s0,v1663_18_label);
    if (v1663_18_tail.empty()) continue;
    const Path v1663_18_head{v1663_18_label};
    const Space v1664_2 = singleton(v1663_18_head);
    const Space v1664_3 = intersect(constant_6,v1664_2);
    const Space v1664_4 = (has_head(v1664_3) ? constant_7 : Space{});
    const Space v1664_5 = subtract(constant_0,v1664_4);
    Space v1664_6_result;
    for (int v1664_6_label = 1; v1664_6_label <= 2; ++v1664_6_label) {
      const Space v1664_6_tail = child(v1663_18_tail,v1664_6_label);
      if (v1664_6_tail.empty()) continue;
      const Path v1664_6_head{v1664_6_label};
      const Space v1665_2 = Space{};
      v1664_6_result = unite(v1664_6_result,v1665_2);
    }
    const Space v1664_6 = std::move(v1664_6_result);
    const Space v1664_7 = compose(v1664_5,v1664_6);
    const Space v1664_8 = intersect(constant_6,v1664_2);
    const Space v1664_9 = (has_head(v1664_8) ? constant_7 : Space{});
    Space v1664_22;
    if (!v1664_9.empty()) {
      const Path v1666_10 = concat_path(p0,v1663_18_head);
      const Path v1666_11 = concat_path(p1,v1666_10);
      const Space v1666_12 = routine_29(c, v1666_11);
      const Space v1666_13 = intersect(v1663_8,v1666_12);
      const Space v1666_14 = routine_30(c, v1666_13);
      Space v1666_15_result;
      for (int v1666_15_label = 1; v1666_15_label <= 2; ++v1666_15_label) {
        const Space v1666_15_tail = child(v1666_14,v1666_15_label);
        if (v1666_15_tail.empty()) continue;
        const Path v1666_15_head{v1666_15_label};
        const Space v1667_2 = singleton(v1666_15_head);
        const Space v1667_3 = intersect(constant_6,v1667_2);
        const Space v1667_4 = (has_head(v1667_3) ? constant_7 : Space{});
        const Space v1667_5 = subtract(constant_0,v1667_4);
        Space v1667_7;
        if (!v1667_5.empty()) {
          const Space v1668_6 = routine_31(c, v1666_15_head, v1666_15_tail);
          v1667_7 = compose(v1667_5,v1668_6);
        }
        const Space v1667_8 = intersect(constant_6,v1667_2);
        const Space v1667_9 = (has_head(v1667_8) ? constant_7 : Space{});
        Space v1667_11;
        if (!v1667_9.empty()) {
          const Space v1669_10 = routine_32(c, v1666_15_head, v1666_15_tail);
          v1667_11 = compose(v1667_9,v1669_10);
        }
        const Space v1667_12 = unite(v1667_7,v1667_11);
        v1666_15_result = unite(v1666_15_result,v1667_12);
      }
      const Space v1666_15 = std::move(v1666_15_result);
      const Space v1666_16 = routine_33(c, v1666_13);
      Space v1666_17_result;
      for (int v1666_17_label = 1; v1666_17_label <= 2; ++v1666_17_label) {
        const Space v1666_17_tail = child(v1666_16,v1666_17_label);
        if (v1666_17_tail.empty()) continue;
        const Path v1666_17_head{v1666_17_label};
        const Space v1670_2 = singleton(v1666_17_head);
        const Space v1670_3 = intersect(constant_6,v1670_2);
        const Space v1670_4 = (has_head(v1670_3) ? constant_7 : Space{});
        const Space v1670_5 = subtract(constant_0,v1670_4);
        Space v1670_7;
        if (!v1670_5.empty()) {
          const Space v1671_6 = routine_34(c, v1666_17_head, v1666_17_tail);
          v1670_7 = compose(v1670_5,v1671_6);
        }
        const Space v1670_8 = intersect(constant_6,v1670_2);
        const Space v1670_9 = (has_head(v1670_8) ? constant_7 : Space{});
        Space v1670_11;
        if (!v1670_9.empty()) {
          const Space v1672_10 = routine_35(c, v1666_17_head, v1666_17_tail);
          v1670_11 = compose(v1670_9,v1672_10);
        }
        const Space v1670_12 = unite(v1670_7,v1670_11);
        v1666_17_result = unite(v1666_17_result,v1670_12);
      }
      const Space v1666_17 = std::move(v1666_17_result);
      const Space v1666_18 = subtract(v1666_15,v1666_17);
      const Space v1666_19 = singleton(v1666_11);
      const Space v1666_20 = compose(v1666_18,v1666_19);
      Space v1666_21_result;
      for (int v1666_21_label = 1; v1666_21_label <= 2; ++v1666_21_label) {
        const Space v1666_21_tail = child(v1666_20,v1666_21_label);
        if (v1666_21_tail.empty()) continue;
        const Path v1666_21_head{v1666_21_label};
        const Space v1673_2 = singleton(v1666_21_head);
        const Space v1673_3 = intersect(constant_6,v1673_2);
        const Space v1673_4 = (has_head(v1673_3) ? constant_7 : Space{});
        const Space v1673_5 = subtract(constant_0,v1673_4);
        Space v1673_7;
        if (!v1673_5.empty()) {
          const Space v1674_6 = routine_36(c, v1666_21_head, v1666_21_tail);
          v1673_7 = compose(v1673_5,v1674_6);
        }
        const Space v1673_8 = intersect(constant_6,v1673_2);
        const Space v1673_9 = (has_head(v1673_8) ? constant_7 : Space{});
        Space v1673_11;
        if (!v1673_9.empty()) {
          const Space v1675_10 = routine_37(c, v1666_21_head, v1666_21_tail);
          v1673_11 = compose(v1673_9,v1675_10);
        }
        const Space v1673_12 = unite(v1673_7,v1673_11);
        v1666_21_result = unite(v1666_21_result,v1673_12);
      }
      const Space v1666_21 = std::move(v1666_21_result);
      v1664_22 = compose(v1664_9,v1666_21);
    }
    const Space v1664_23 = unite(v1664_7,v1664_22);
    v1663_18_result = unite(v1663_18_result,v1664_23);
  }
  const Space v1663_18 = std::move(v1663_18_result);
  return v1663_18;
}

static Space routine_183(Context& c, const Path& p0, const Space& s0) {
  Space v1676_11_result;
  for (int v1676_11_label = 1; v1676_11_label <= 2; ++v1676_11_label) {
    const Space v1676_11_tail = child(s0,v1676_11_label);
    if (v1676_11_tail.empty()) continue;
    const Path v1676_11_head{v1676_11_label};
    const Space v1677_2 = singleton(v1676_11_head);
    const Space v1677_3 = intersect(constant_6,v1677_2);
    const Space v1677_4 = (has_head(v1677_3) ? constant_7 : Space{});
    const Space v1677_5 = subtract(constant_0,v1677_4);
    Space v1677_8;
    if (!v1677_5.empty()) {
      const Path v1678_6 = concat_path(p0,v1676_11_head);
      Space v1678_7_result;
      for (int v1678_7_label = 1; v1678_7_label <= 2; ++v1678_7_label) {
        const Space v1678_7_tail = child(v1676_11_tail,v1678_7_label);
        if (v1678_7_tail.empty()) continue;
        const Path v1678_7_head{v1678_7_label};
        const Space v1679_2 = singleton(v1678_7_head);
        const Space v1679_3 = intersect(constant_6,v1679_2);
        const Space v1679_4 = (has_head(v1679_3) ? constant_7 : Space{});
        const Space v1679_5 = subtract(constant_0,v1679_4);
        Space v1679_8;
        if (!v1679_5.empty()) {
          const Path v1680_6 = concat_path(v1678_6,v1678_7_head);
          const Space v1680_7 = routine_225(c, v1680_6, v1678_7_tail);
          v1679_8 = compose(v1679_5,v1680_7);
        }
        const Space v1679_9 = intersect(constant_6,v1679_2);
        const Space v1679_10 = (has_head(v1679_9) ? constant_7 : Space{});
        Space v1679_12;
        if (!v1679_10.empty()) {
          const Path v1681_6 = concat_path(v1678_6,v1678_7_head);
          const Space v1681_11 = routine_226(c, v1681_6, v1678_7_tail);
          v1679_12 = compose(v1679_10,v1681_11);
        }
        const Space v1679_13 = unite(v1679_8,v1679_12);
        v1678_7_result = unite(v1678_7_result,v1679_13);
      }
      const Space v1678_7 = std::move(v1678_7_result);
      v1677_8 = compose(v1677_5,v1678_7);
    }
    const Space v1677_9 = intersect(constant_6,v1677_2);
    const Space v1677_10 = (has_head(v1677_9) ? constant_7 : Space{});
    Space v1677_12;
    if (!v1677_10.empty()) {
      const Path v1682_6 = concat_path(p0,v1676_11_head);
      Space v1682_11_result;
      for (int v1682_11_label = 1; v1682_11_label <= 2; ++v1682_11_label) {
        const Space v1682_11_tail = child(v1676_11_tail,v1682_11_label);
        if (v1682_11_tail.empty()) continue;
        const Path v1682_11_head{v1682_11_label};
        const Space v1683_2 = singleton(v1682_11_head);
        const Space v1683_3 = intersect(constant_6,v1683_2);
        const Space v1683_4 = (has_head(v1683_3) ? constant_7 : Space{});
        const Space v1683_5 = subtract(constant_0,v1683_4);
        Space v1683_8;
        if (!v1683_5.empty()) {
          const Path v1684_6 = concat_path(v1682_6,v1682_11_head);
          const Space v1684_7 = routine_225(c, v1684_6, v1682_11_tail);
          v1683_8 = compose(v1683_5,v1684_7);
        }
        const Space v1683_9 = intersect(constant_6,v1683_2);
        const Space v1683_10 = (has_head(v1683_9) ? constant_7 : Space{});
        Space v1683_12;
        if (!v1683_10.empty()) {
          const Path v1685_6 = concat_path(v1682_6,v1682_11_head);
          const Space v1685_11 = routine_80(c, v1685_6, v1682_11_tail);
          v1683_12 = compose(v1683_10,v1685_11);
        }
        const Space v1683_13 = unite(v1683_8,v1683_12);
        v1682_11_result = unite(v1682_11_result,v1683_13);
      }
      const Space v1682_11 = std::move(v1682_11_result);
      v1677_12 = compose(v1677_10,v1682_11);
    }
    const Space v1677_13 = unite(v1677_8,v1677_12);
    v1676_11_result = unite(v1676_11_result,v1677_13);
  }
  const Space v1676_11 = std::move(v1676_11_result);
  return v1676_11;
}

static Space routine_184(Context& c, const Path& p0, const Space& s0) {
  Space v1686_11_result;
  for (int v1686_11_label = 1; v1686_11_label <= 2; ++v1686_11_label) {
    const Space v1686_11_tail = child(s0,v1686_11_label);
    if (v1686_11_tail.empty()) continue;
    const Path v1686_11_head{v1686_11_label};
    const Space v1687_2 = singleton(v1686_11_head);
    const Space v1687_3 = intersect(constant_6,v1687_2);
    const Space v1687_4 = (has_head(v1687_3) ? constant_7 : Space{});
    const Space v1687_5 = subtract(constant_0,v1687_4);
    Space v1687_8;
    if (!v1687_5.empty()) {
      const Path v1688_6 = concat_path(p0,v1686_11_head);
      Space v1688_7_result;
      for (int v1688_7_label = 1; v1688_7_label <= 2; ++v1688_7_label) {
        const Space v1688_7_tail = child(v1686_11_tail,v1688_7_label);
        if (v1688_7_tail.empty()) continue;
        const Path v1688_7_head{v1688_7_label};
        const Space v1689_2 = singleton(v1688_7_head);
        const Space v1689_3 = intersect(constant_6,v1689_2);
        const Space v1689_4 = (has_head(v1689_3) ? constant_7 : Space{});
        const Space v1689_5 = subtract(constant_0,v1689_4);
        Space v1689_8;
        if (!v1689_5.empty()) {
          const Path v1690_6 = concat_path(v1688_6,v1688_7_head);
          const Space v1690_7 = routine_225(c, v1690_6, v1688_7_tail);
          v1689_8 = compose(v1689_5,v1690_7);
        }
        const Space v1689_9 = intersect(constant_6,v1689_2);
        const Space v1689_10 = (has_head(v1689_9) ? constant_7 : Space{});
        Space v1689_12;
        if (!v1689_10.empty()) {
          const Path v1691_6 = concat_path(v1688_6,v1688_7_head);
          const Space v1691_11 = routine_226(c, v1691_6, v1688_7_tail);
          v1689_12 = compose(v1689_10,v1691_11);
        }
        const Space v1689_13 = unite(v1689_8,v1689_12);
        v1688_7_result = unite(v1688_7_result,v1689_13);
      }
      const Space v1688_7 = std::move(v1688_7_result);
      v1687_8 = compose(v1687_5,v1688_7);
    }
    const Space v1687_9 = intersect(constant_6,v1687_2);
    const Space v1687_10 = (has_head(v1687_9) ? constant_7 : Space{});
    Space v1687_12;
    if (!v1687_10.empty()) {
      const Path v1692_6 = concat_path(p0,v1686_11_head);
      Space v1692_11_result;
      for (int v1692_11_label = 1; v1692_11_label <= 2; ++v1692_11_label) {
        const Space v1692_11_tail = child(v1686_11_tail,v1692_11_label);
        if (v1692_11_tail.empty()) continue;
        const Path v1692_11_head{v1692_11_label};
        const Space v1693_2 = singleton(v1692_11_head);
        const Space v1693_3 = intersect(constant_6,v1693_2);
        const Space v1693_4 = (has_head(v1693_3) ? constant_7 : Space{});
        const Space v1693_5 = subtract(constant_0,v1693_4);
        Space v1693_7;
        if (!v1693_5.empty()) {
          const Space v1694_6 = routine_122(c, v1692_11_head, v1692_6, v1692_11_tail);
          v1693_7 = compose(v1693_5,v1694_6);
        }
        const Space v1693_8 = intersect(constant_6,v1693_2);
        const Space v1693_9 = (has_head(v1693_8) ? constant_7 : Space{});
        Space v1693_11;
        if (!v1693_9.empty()) {
          const Space v1695_10 = routine_123(c, v1692_11_head, v1692_6, v1692_11_tail);
          v1693_11 = compose(v1693_9,v1695_10);
        }
        const Space v1693_12 = unite(v1693_7,v1693_11);
        v1692_11_result = unite(v1692_11_result,v1693_12);
      }
      const Space v1692_11 = std::move(v1692_11_result);
      v1687_12 = compose(v1687_10,v1692_11);
    }
    const Space v1687_13 = unite(v1687_8,v1687_12);
    v1686_11_result = unite(v1686_11_result,v1687_13);
  }
  const Space v1686_11 = std::move(v1686_11_result);
  return v1686_11;
}

static Space routine_185(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1696_12_result;
  for (int v1696_12_label = 1; v1696_12_label <= 2; ++v1696_12_label) {
    const Space v1696_12_tail = child(s0,v1696_12_label);
    if (v1696_12_tail.empty()) continue;
    const Path v1696_12_head{v1696_12_label};
    const Space v1697_2 = singleton(v1696_12_head);
    const Space v1697_3 = intersect(constant_6,v1697_2);
    const Space v1697_4 = (has_head(v1697_3) ? constant_7 : Space{});
    const Space v1697_5 = subtract(constant_0,v1697_4);
    Space v1697_8;
    if (!v1697_5.empty()) {
      const Path v1698_6 = concat_path(p0,v1696_12_head);
      Space v1698_7_result;
      for (int v1698_7_label = 1; v1698_7_label <= 2; ++v1698_7_label) {
        const Space v1698_7_tail = child(v1696_12_tail,v1698_7_label);
        if (v1698_7_tail.empty()) continue;
        const Path v1698_7_head{v1698_7_label};
        const Space v1699_2 = singleton(v1698_7_head);
        const Space v1699_3 = intersect(constant_6,v1699_2);
        const Space v1699_4 = (has_head(v1699_3) ? constant_7 : Space{});
        const Space v1699_5 = subtract(constant_0,v1699_4);
        Space v1699_8;
        if (!v1699_5.empty()) {
          const Path v1700_6 = concat_path(v1698_6,v1698_7_head);
          const Space v1700_7 = routine_227(c, v1700_6, p1, v1698_7_tail);
          v1699_8 = compose(v1699_5,v1700_7);
        }
        const Space v1699_9 = intersect(constant_6,v1699_2);
        const Space v1699_10 = (has_head(v1699_9) ? constant_7 : Space{});
        Space v1699_12;
        if (!v1699_10.empty()) {
          const Path v1701_6 = concat_path(v1698_6,v1698_7_head);
          const Space v1701_11 = routine_228(c, v1701_6, p1, v1698_7_tail);
          v1699_12 = compose(v1699_10,v1701_11);
        }
        const Space v1699_13 = unite(v1699_8,v1699_12);
        v1698_7_result = unite(v1698_7_result,v1699_13);
      }
      const Space v1698_7 = std::move(v1698_7_result);
      v1697_8 = compose(v1697_5,v1698_7);
    }
    const Space v1697_9 = intersect(constant_6,v1697_2);
    const Space v1697_10 = (has_head(v1697_9) ? constant_7 : Space{});
    Space v1697_12;
    if (!v1697_10.empty()) {
      const Path v1702_6 = concat_path(p0,v1696_12_head);
      Space v1702_11_result;
      for (int v1702_11_label = 1; v1702_11_label <= 2; ++v1702_11_label) {
        const Space v1702_11_tail = child(v1696_12_tail,v1702_11_label);
        if (v1702_11_tail.empty()) continue;
        const Path v1702_11_head{v1702_11_label};
        const Space v1703_2 = singleton(v1702_11_head);
        const Space v1703_3 = intersect(constant_6,v1703_2);
        const Space v1703_4 = (has_head(v1703_3) ? constant_7 : Space{});
        const Space v1703_5 = subtract(constant_0,v1703_4);
        Space v1703_8;
        if (!v1703_5.empty()) {
          const Path v1704_6 = concat_path(v1702_6,v1702_11_head);
          const Space v1704_7 = routine_227(c, v1704_6, p1, v1702_11_tail);
          v1703_8 = compose(v1703_5,v1704_7);
        }
        const Space v1703_9 = intersect(constant_6,v1703_2);
        const Space v1703_10 = (has_head(v1703_9) ? constant_7 : Space{});
        Space v1703_12;
        if (!v1703_10.empty()) {
          const Path v1705_6 = concat_path(v1702_6,v1702_11_head);
          const Space v1705_11 = routine_137(c, v1705_6, p1, v1702_11_tail);
          v1703_12 = compose(v1703_10,v1705_11);
        }
        const Space v1703_13 = unite(v1703_8,v1703_12);
        v1702_11_result = unite(v1702_11_result,v1703_13);
      }
      const Space v1702_11 = std::move(v1702_11_result);
      v1697_12 = compose(v1697_10,v1702_11);
    }
    const Space v1697_13 = unite(v1697_8,v1697_12);
    v1696_12_result = unite(v1696_12_result,v1697_13);
  }
  const Space v1696_12 = std::move(v1696_12_result);
  return v1696_12;
}

static Space routine_186(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1706_7 = unwrap(constant_12,p1);
  const Space v1706_9 = unwrap(constant_12,p0);
  Space v1706_13_result;
  for (int v1706_13_label = 1; v1706_13_label <= 2; ++v1706_13_label) {
    const Space v1706_13_tail = child(s0,v1706_13_label);
    if (v1706_13_tail.empty()) continue;
    const Path v1706_13_head{v1706_13_label};
    const Space v1707_2 = singleton(v1706_13_head);
    const Space v1707_3 = intersect(constant_6,v1707_2);
    const Space v1707_4 = (has_head(v1707_3) ? constant_7 : Space{});
    const Space v1707_5 = subtract(constant_0,v1707_4);
    Space v1707_8;
    if (!v1707_5.empty()) {
      const Path v1708_6 = concat_path(p0,v1706_13_head);
      Space v1708_7_result;
      for (int v1708_7_label = 1; v1708_7_label <= 2; ++v1708_7_label) {
        const Space v1708_7_tail = child(v1706_13_tail,v1708_7_label);
        if (v1708_7_tail.empty()) continue;
        const Path v1708_7_head{v1708_7_label};
        const Space v1709_2 = singleton(v1708_7_head);
        const Space v1709_3 = intersect(constant_6,v1709_2);
        const Space v1709_4 = (has_head(v1709_3) ? constant_7 : Space{});
        const Space v1709_5 = subtract(constant_0,v1709_4);
        Space v1709_8;
        if (!v1709_5.empty()) {
          const Path v1710_6 = concat_path(v1708_6,v1708_7_head);
          const Space v1710_7 = routine_227(c, v1710_6, p1, v1708_7_tail);
          v1709_8 = compose(v1709_5,v1710_7);
        }
        const Space v1709_9 = intersect(constant_6,v1709_2);
        const Space v1709_10 = (has_head(v1709_9) ? constant_7 : Space{});
        Space v1709_12;
        if (!v1709_10.empty()) {
          const Path v1711_6 = concat_path(v1708_6,v1708_7_head);
          const Space v1711_11 = routine_228(c, v1711_6, p1, v1708_7_tail);
          v1709_12 = compose(v1709_10,v1711_11);
        }
        const Space v1709_13 = unite(v1709_8,v1709_12);
        v1708_7_result = unite(v1708_7_result,v1709_13);
      }
      const Space v1708_7 = std::move(v1708_7_result);
      v1707_8 = compose(v1707_5,v1708_7);
    }
    const Space v1707_9 = intersect(constant_6,v1707_2);
    const Space v1707_10 = (has_head(v1707_9) ? constant_7 : Space{});
    const Space v1707_11 = unwrap(v1706_9,v1706_13_head);
    const Space v1707_12 = compose(v1706_7,v1707_11);
    const Path v1712_6 = concat_path(p0,v1706_13_head);
    const Path v1707_13 = concat_path(p1,v1712_6);
    const Space v1707_14 = singleton(v1707_13);
    const Space v1707_15 = subtract(v1707_12,v1707_14);
    const Space v1707_16 = compose(v1707_10,v1707_15);
    const Space v1707_17 = unite(v1707_8,v1707_16);
    v1706_13_result = unite(v1706_13_result,v1707_17);
  }
  const Space v1706_13 = std::move(v1706_13_result);
  return v1706_13;
}

static Space routine_187(Context& c, const Path& p0, const Space& s0) {
  Space v1713_11_result;
  for (int v1713_11_label = 1; v1713_11_label <= 2; ++v1713_11_label) {
    const Space v1713_11_tail = child(s0,v1713_11_label);
    if (v1713_11_tail.empty()) continue;
    const Path v1713_11_head{v1713_11_label};
    const Space v1714_2 = singleton(v1713_11_head);
    const Space v1714_3 = intersect(constant_6,v1714_2);
    const Space v1714_4 = (has_head(v1714_3) ? constant_7 : Space{});
    const Space v1714_5 = subtract(constant_0,v1714_4);
    Space v1714_8;
    if (!v1714_5.empty()) {
      const Path v1715_6 = concat_path(p0,v1713_11_head);
      Space v1715_7_result;
      for (int v1715_7_label = 1; v1715_7_label <= 2; ++v1715_7_label) {
        const Space v1715_7_tail = child(v1713_11_tail,v1715_7_label);
        if (v1715_7_tail.empty()) continue;
        const Path v1715_7_head{v1715_7_label};
        const Space v1716_2 = singleton(v1715_7_head);
        const Space v1716_3 = intersect(constant_6,v1716_2);
        const Space v1716_4 = (has_head(v1716_3) ? constant_7 : Space{});
        const Space v1716_5 = subtract(constant_0,v1716_4);
        Space v1716_8;
        if (!v1716_5.empty()) {
          const Path v1717_6 = concat_path(v1715_6,v1715_7_head);
          const Space v1717_7 = routine_229(c, v1717_6, v1715_7_tail);
          v1716_8 = compose(v1716_5,v1717_7);
        }
        const Space v1716_9 = intersect(constant_6,v1716_2);
        const Space v1716_10 = (has_head(v1716_9) ? constant_7 : Space{});
        Space v1716_12;
        if (!v1716_10.empty()) {
          const Path v1718_6 = concat_path(v1715_6,v1715_7_head);
          const Space v1718_11 = routine_230(c, v1718_6, v1715_7_tail);
          v1716_12 = compose(v1716_10,v1718_11);
        }
        const Space v1716_13 = unite(v1716_8,v1716_12);
        v1715_7_result = unite(v1715_7_result,v1716_13);
      }
      const Space v1715_7 = std::move(v1715_7_result);
      v1714_8 = compose(v1714_5,v1715_7);
    }
    const Space v1714_9 = intersect(constant_6,v1714_2);
    const Space v1714_10 = (has_head(v1714_9) ? constant_7 : Space{});
    Space v1714_12;
    if (!v1714_10.empty()) {
      const Path v1719_6 = concat_path(p0,v1713_11_head);
      Space v1719_11_result;
      for (int v1719_11_label = 1; v1719_11_label <= 2; ++v1719_11_label) {
        const Space v1719_11_tail = child(v1713_11_tail,v1719_11_label);
        if (v1719_11_tail.empty()) continue;
        const Path v1719_11_head{v1719_11_label};
        const Space v1720_2 = singleton(v1719_11_head);
        const Space v1720_3 = intersect(constant_6,v1720_2);
        const Space v1720_4 = (has_head(v1720_3) ? constant_7 : Space{});
        const Space v1720_5 = subtract(constant_0,v1720_4);
        Space v1720_8;
        if (!v1720_5.empty()) {
          const Path v1721_6 = concat_path(v1719_6,v1719_11_head);
          const Space v1721_7 = routine_229(c, v1721_6, v1719_11_tail);
          v1720_8 = compose(v1720_5,v1721_7);
        }
        const Space v1720_9 = intersect(constant_6,v1720_2);
        const Space v1720_10 = (has_head(v1720_9) ? constant_7 : Space{});
        Space v1720_12;
        if (!v1720_10.empty()) {
          const Path v1722_6 = concat_path(v1719_6,v1719_11_head);
          const Space v1722_11 = routine_69(c, v1722_6, v1719_11_tail);
          v1720_12 = compose(v1720_10,v1722_11);
        }
        const Space v1720_13 = unite(v1720_8,v1720_12);
        v1719_11_result = unite(v1719_11_result,v1720_13);
      }
      const Space v1719_11 = std::move(v1719_11_result);
      v1714_12 = compose(v1714_10,v1719_11);
    }
    const Space v1714_13 = unite(v1714_8,v1714_12);
    v1713_11_result = unite(v1713_11_result,v1714_13);
  }
  const Space v1713_11 = std::move(v1713_11_result);
  return v1713_11;
}

static Space routine_188(Context& c, const Path& p0, const Space& s0) {
  Space v1723_9_result;
  for (int v1723_9_label = 1; v1723_9_label <= 2; ++v1723_9_label) {
    const Space v1723_9_tail = child(s0,v1723_9_label);
    if (v1723_9_tail.empty()) continue;
    const Path v1723_9_head{v1723_9_label};
    const Space v1724_2 = singleton(v1723_9_head);
    const Space v1724_3 = intersect(constant_6,v1724_2);
    const Space v1724_4 = (has_head(v1724_3) ? constant_7 : Space{});
    const Space v1724_5 = subtract(constant_0,v1724_4);
    Space v1724_8;
    if (!v1724_5.empty()) {
      const Path v1725_6 = concat_path(p0,v1723_9_head);
      Space v1725_7_result;
      for (int v1725_7_label = 1; v1725_7_label <= 2; ++v1725_7_label) {
        const Space v1725_7_tail = child(v1723_9_tail,v1725_7_label);
        if (v1725_7_tail.empty()) continue;
        const Path v1725_7_head{v1725_7_label};
        const Space v1726_2 = singleton(v1725_7_head);
        const Space v1726_3 = intersect(constant_6,v1726_2);
        const Space v1726_4 = (has_head(v1726_3) ? constant_7 : Space{});
        const Space v1726_5 = subtract(constant_0,v1726_4);
        Space v1726_8;
        if (!v1726_5.empty()) {
          const Path v1727_6 = concat_path(v1725_6,v1725_7_head);
          const Space v1727_7 = routine_229(c, v1727_6, v1725_7_tail);
          v1726_8 = compose(v1726_5,v1727_7);
        }
        const Space v1726_9 = intersect(constant_6,v1726_2);
        const Space v1726_10 = (has_head(v1726_9) ? constant_7 : Space{});
        Space v1726_12;
        if (!v1726_10.empty()) {
          const Path v1728_6 = concat_path(v1725_6,v1725_7_head);
          const Space v1728_11 = routine_230(c, v1728_6, v1725_7_tail);
          v1726_12 = compose(v1726_10,v1728_11);
        }
        const Space v1726_13 = unite(v1726_8,v1726_12);
        v1725_7_result = unite(v1725_7_result,v1726_13);
      }
      const Space v1725_7 = std::move(v1725_7_result);
      v1724_8 = compose(v1724_5,v1725_7);
    }
    const Space v1724_9 = intersect(constant_6,v1724_2);
    const Space v1724_10 = (has_head(v1724_9) ? constant_7 : Space{});
    const Space v1724_11 = compose(v1724_10,constant_9);
    const Space v1724_12 = unite(v1724_8,v1724_11);
    v1723_9_result = unite(v1723_9_result,v1724_12);
  }
  const Space v1723_9 = std::move(v1723_9_result);
  return v1723_9;
}

static Space routine_189(Context& c, const Path& p0, const Space& s0) {
  Space v1729_11_result;
  for (int v1729_11_label = 1; v1729_11_label <= 2; ++v1729_11_label) {
    const Space v1729_11_tail = child(s0,v1729_11_label);
    if (v1729_11_tail.empty()) continue;
    const Path v1729_11_head{v1729_11_label};
    const Space v1730_2 = singleton(v1729_11_head);
    const Space v1730_3 = intersect(constant_6,v1730_2);
    const Space v1730_4 = (has_head(v1730_3) ? constant_7 : Space{});
    const Space v1730_5 = subtract(constant_0,v1730_4);
    Space v1730_8;
    if (!v1730_5.empty()) {
      const Path v1731_6 = concat_path(p0,v1729_11_head);
      Space v1731_7_result;
      for (int v1731_7_label = 1; v1731_7_label <= 2; ++v1731_7_label) {
        const Space v1731_7_tail = child(v1729_11_tail,v1731_7_label);
        if (v1731_7_tail.empty()) continue;
        const Path v1731_7_head{v1731_7_label};
        const Space v1732_2 = singleton(v1731_7_head);
        const Space v1732_3 = intersect(constant_6,v1732_2);
        const Space v1732_4 = (has_head(v1732_3) ? constant_7 : Space{});
        const Space v1732_5 = subtract(constant_0,v1732_4);
        Space v1732_8;
        if (!v1732_5.empty()) {
          const Path v1733_6 = concat_path(v1731_6,v1731_7_head);
          const Space v1733_7 = routine_231(c, v1733_6, v1731_7_tail);
          v1732_8 = compose(v1732_5,v1733_7);
        }
        const Space v1732_9 = intersect(constant_6,v1732_2);
        const Space v1732_10 = (has_head(v1732_9) ? constant_7 : Space{});
        Space v1732_12;
        if (!v1732_10.empty()) {
          const Path v1734_6 = concat_path(v1731_6,v1731_7_head);
          const Space v1734_11 = routine_232(c, v1734_6, v1731_7_tail);
          v1732_12 = compose(v1732_10,v1734_11);
        }
        const Space v1732_13 = unite(v1732_8,v1732_12);
        v1731_7_result = unite(v1731_7_result,v1732_13);
      }
      const Space v1731_7 = std::move(v1731_7_result);
      v1730_8 = compose(v1730_5,v1731_7);
    }
    const Space v1730_9 = intersect(constant_6,v1730_2);
    const Space v1730_10 = (has_head(v1730_9) ? constant_7 : Space{});
    Space v1730_12;
    if (!v1730_10.empty()) {
      const Path v1735_6 = concat_path(p0,v1729_11_head);
      Space v1735_11_result;
      for (int v1735_11_label = 1; v1735_11_label <= 2; ++v1735_11_label) {
        const Space v1735_11_tail = child(v1729_11_tail,v1735_11_label);
        if (v1735_11_tail.empty()) continue;
        const Path v1735_11_head{v1735_11_label};
        const Space v1736_2 = singleton(v1735_11_head);
        const Space v1736_3 = intersect(constant_6,v1736_2);
        const Space v1736_4 = (has_head(v1736_3) ? constant_7 : Space{});
        const Space v1736_5 = subtract(constant_0,v1736_4);
        Space v1736_8;
        if (!v1736_5.empty()) {
          const Path v1737_6 = concat_path(v1735_6,v1735_11_head);
          const Space v1737_7 = routine_231(c, v1737_6, v1735_11_tail);
          v1736_8 = compose(v1736_5,v1737_7);
        }
        const Space v1736_9 = intersect(constant_6,v1736_2);
        const Space v1736_10 = (has_head(v1736_9) ? constant_7 : Space{});
        Space v1736_12;
        if (!v1736_10.empty()) {
          const Path v1738_6 = concat_path(v1735_6,v1735_11_head);
          const Space v1738_11 = routine_72(c, v1738_6, v1735_11_tail);
          v1736_12 = compose(v1736_10,v1738_11);
        }
        const Space v1736_13 = unite(v1736_8,v1736_12);
        v1735_11_result = unite(v1735_11_result,v1736_13);
      }
      const Space v1735_11 = std::move(v1735_11_result);
      v1730_12 = compose(v1730_10,v1735_11);
    }
    const Space v1730_13 = unite(v1730_8,v1730_12);
    v1729_11_result = unite(v1729_11_result,v1730_13);
  }
  const Space v1729_11 = std::move(v1729_11_result);
  return v1729_11;
}

static Space routine_190(Context& c, const Path& p0, const Space& s0) {
  Space v1739_9_result;
  for (int v1739_9_label = 1; v1739_9_label <= 2; ++v1739_9_label) {
    const Space v1739_9_tail = child(s0,v1739_9_label);
    if (v1739_9_tail.empty()) continue;
    const Path v1739_9_head{v1739_9_label};
    const Space v1740_2 = singleton(v1739_9_head);
    const Space v1740_3 = intersect(constant_6,v1740_2);
    const Space v1740_4 = (has_head(v1740_3) ? constant_7 : Space{});
    const Space v1740_5 = subtract(constant_0,v1740_4);
    Space v1740_8;
    if (!v1740_5.empty()) {
      const Path v1741_6 = concat_path(p0,v1739_9_head);
      Space v1741_7_result;
      for (int v1741_7_label = 1; v1741_7_label <= 2; ++v1741_7_label) {
        const Space v1741_7_tail = child(v1739_9_tail,v1741_7_label);
        if (v1741_7_tail.empty()) continue;
        const Path v1741_7_head{v1741_7_label};
        const Space v1742_2 = singleton(v1741_7_head);
        const Space v1742_3 = intersect(constant_6,v1742_2);
        const Space v1742_4 = (has_head(v1742_3) ? constant_7 : Space{});
        const Space v1742_5 = subtract(constant_0,v1742_4);
        Space v1742_8;
        if (!v1742_5.empty()) {
          const Path v1743_6 = concat_path(v1741_6,v1741_7_head);
          const Space v1743_7 = routine_231(c, v1743_6, v1741_7_tail);
          v1742_8 = compose(v1742_5,v1743_7);
        }
        const Space v1742_9 = intersect(constant_6,v1742_2);
        const Space v1742_10 = (has_head(v1742_9) ? constant_7 : Space{});
        Space v1742_12;
        if (!v1742_10.empty()) {
          const Path v1744_6 = concat_path(v1741_6,v1741_7_head);
          const Space v1744_11 = routine_232(c, v1744_6, v1741_7_tail);
          v1742_12 = compose(v1742_10,v1744_11);
        }
        const Space v1742_13 = unite(v1742_8,v1742_12);
        v1741_7_result = unite(v1741_7_result,v1742_13);
      }
      const Space v1741_7 = std::move(v1741_7_result);
      v1740_8 = compose(v1740_5,v1741_7);
    }
    const Space v1740_9 = intersect(constant_6,v1740_2);
    const Space v1740_10 = (has_head(v1740_9) ? constant_7 : Space{});
    const Space v1740_11 = compose(v1740_10,constant_9);
    const Space v1740_12 = unite(v1740_8,v1740_11);
    v1739_9_result = unite(v1739_9_result,v1740_12);
  }
  const Space v1739_9 = std::move(v1739_9_result);
  return v1739_9;
}

static Space routine_191(Context& c, const Path& p0, const Space& s0) {
  Space v1745_11_result;
  for (int v1745_11_label = 1; v1745_11_label <= 2; ++v1745_11_label) {
    const Space v1745_11_tail = child(s0,v1745_11_label);
    if (v1745_11_tail.empty()) continue;
    const Path v1745_11_head{v1745_11_label};
    const Space v1746_2 = singleton(v1745_11_head);
    const Space v1746_3 = intersect(constant_6,v1746_2);
    const Space v1746_4 = (has_head(v1746_3) ? constant_7 : Space{});
    const Space v1746_5 = subtract(constant_0,v1746_4);
    Space v1746_8;
    if (!v1746_5.empty()) {
      const Path v1747_6 = concat_path(p0,v1745_11_head);
      Space v1747_7_result;
      for (int v1747_7_label = 1; v1747_7_label <= 2; ++v1747_7_label) {
        const Space v1747_7_tail = child(v1745_11_tail,v1747_7_label);
        if (v1747_7_tail.empty()) continue;
        const Path v1747_7_head{v1747_7_label};
        const Space v1748_2 = singleton(v1747_7_head);
        const Space v1748_3 = intersect(constant_6,v1748_2);
        const Space v1748_4 = (has_head(v1748_3) ? constant_7 : Space{});
        const Space v1748_5 = subtract(constant_0,v1748_4);
        Space v1748_8;
        if (!v1748_5.empty()) {
          const Path v1749_6 = concat_path(v1747_6,v1747_7_head);
          const Space v1749_7 = routine_233(c, v1749_6, v1747_7_tail);
          v1748_8 = compose(v1748_5,v1749_7);
        }
        const Space v1748_9 = intersect(constant_6,v1748_2);
        const Space v1748_10 = (has_head(v1748_9) ? constant_7 : Space{});
        Space v1748_12;
        if (!v1748_10.empty()) {
          const Path v1750_6 = concat_path(v1747_6,v1747_7_head);
          const Space v1750_11 = routine_234(c, v1750_6, v1747_7_tail);
          v1748_12 = compose(v1748_10,v1750_11);
        }
        const Space v1748_13 = unite(v1748_8,v1748_12);
        v1747_7_result = unite(v1747_7_result,v1748_13);
      }
      const Space v1747_7 = std::move(v1747_7_result);
      v1746_8 = compose(v1746_5,v1747_7);
    }
    const Space v1746_9 = intersect(constant_6,v1746_2);
    const Space v1746_10 = (has_head(v1746_9) ? constant_7 : Space{});
    Space v1746_12;
    if (!v1746_10.empty()) {
      const Path v1751_6 = concat_path(p0,v1745_11_head);
      Space v1751_11_result;
      for (int v1751_11_label = 1; v1751_11_label <= 2; ++v1751_11_label) {
        const Space v1751_11_tail = child(v1745_11_tail,v1751_11_label);
        if (v1751_11_tail.empty()) continue;
        const Path v1751_11_head{v1751_11_label};
        const Space v1752_2 = singleton(v1751_11_head);
        const Space v1752_3 = intersect(constant_6,v1752_2);
        const Space v1752_4 = (has_head(v1752_3) ? constant_7 : Space{});
        const Space v1752_5 = subtract(constant_0,v1752_4);
        Space v1752_8;
        if (!v1752_5.empty()) {
          const Path v1753_6 = concat_path(v1751_6,v1751_11_head);
          const Space v1753_7 = routine_233(c, v1753_6, v1751_11_tail);
          v1752_8 = compose(v1752_5,v1753_7);
        }
        const Space v1752_9 = intersect(constant_6,v1752_2);
        const Space v1752_10 = (has_head(v1752_9) ? constant_7 : Space{});
        Space v1752_12;
        if (!v1752_10.empty()) {
          const Path v1754_6 = concat_path(v1751_6,v1751_11_head);
          const Space v1754_11 = routine_75(c, v1754_6, v1751_11_tail);
          v1752_12 = compose(v1752_10,v1754_11);
        }
        const Space v1752_13 = unite(v1752_8,v1752_12);
        v1751_11_result = unite(v1751_11_result,v1752_13);
      }
      const Space v1751_11 = std::move(v1751_11_result);
      v1746_12 = compose(v1746_10,v1751_11);
    }
    const Space v1746_13 = unite(v1746_8,v1746_12);
    v1745_11_result = unite(v1745_11_result,v1746_13);
  }
  const Space v1745_11 = std::move(v1745_11_result);
  return v1745_11;
}

static Space routine_192(Context& c, const Path& p0, const Space& s0) {
  Space v1755_8_result;
  for (int v1755_8_label = 1; v1755_8_label <= 2; ++v1755_8_label) {
    const Space v1755_8_tail = child(s0,v1755_8_label);
    if (v1755_8_tail.empty()) continue;
    const Path v1755_8_head{v1755_8_label};
    const Space v1756_2 = singleton(v1755_8_head);
    const Space v1756_3 = intersect(constant_6,v1756_2);
    const Space v1756_4 = (has_head(v1756_3) ? constant_7 : Space{});
    const Space v1756_5 = subtract(constant_0,v1756_4);
    Space v1756_8;
    if (!v1756_5.empty()) {
      const Path v1757_6 = concat_path(p0,v1755_8_head);
      Space v1757_7_result;
      for (int v1757_7_label = 1; v1757_7_label <= 2; ++v1757_7_label) {
        const Space v1757_7_tail = child(v1755_8_tail,v1757_7_label);
        if (v1757_7_tail.empty()) continue;
        const Path v1757_7_head{v1757_7_label};
        const Space v1758_2 = singleton(v1757_7_head);
        const Space v1758_3 = intersect(constant_6,v1758_2);
        const Space v1758_4 = (has_head(v1758_3) ? constant_7 : Space{});
        const Space v1758_5 = subtract(constant_0,v1758_4);
        Space v1758_8;
        if (!v1758_5.empty()) {
          const Path v1759_6 = concat_path(v1757_6,v1757_7_head);
          const Space v1759_7 = routine_233(c, v1759_6, v1757_7_tail);
          v1758_8 = compose(v1758_5,v1759_7);
        }
        const Space v1758_9 = intersect(constant_6,v1758_2);
        const Space v1758_10 = (has_head(v1758_9) ? constant_7 : Space{});
        Space v1758_12;
        if (!v1758_10.empty()) {
          const Path v1760_6 = concat_path(v1757_6,v1757_7_head);
          const Space v1760_11 = routine_234(c, v1760_6, v1757_7_tail);
          v1758_12 = compose(v1758_10,v1760_11);
        }
        const Space v1758_13 = unite(v1758_8,v1758_12);
        v1757_7_result = unite(v1757_7_result,v1758_13);
      }
      const Space v1757_7 = std::move(v1757_7_result);
      v1756_8 = compose(v1756_5,v1757_7);
    }
    const Space v1756_9 = intersect(constant_6,v1756_2);
    const Space v1756_10 = (has_head(v1756_9) ? constant_7 : Space{});
    const Space v1756_11 = compose(v1756_10,v1755_8_tail);
    const Space v1756_12 = unite(v1756_8,v1756_11);
    v1755_8_result = unite(v1755_8_result,v1756_12);
  }
  const Space v1755_8 = std::move(v1755_8_result);
  return v1755_8;
}

static Space routine_193(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1761_12_result;
  for (int v1761_12_label = 1; v1761_12_label <= 2; ++v1761_12_label) {
    const Space v1761_12_tail = child(s0,v1761_12_label);
    if (v1761_12_tail.empty()) continue;
    const Path v1761_12_head{v1761_12_label};
    const Space v1762_2 = singleton(v1761_12_head);
    const Space v1762_3 = intersect(constant_6,v1762_2);
    const Space v1762_4 = (has_head(v1762_3) ? constant_7 : Space{});
    const Space v1762_5 = subtract(constant_0,v1762_4);
    Space v1762_8;
    if (!v1762_5.empty()) {
      const Path v1763_6 = concat_path(p0,v1761_12_head);
      Space v1763_7_result;
      for (int v1763_7_label = 1; v1763_7_label <= 2; ++v1763_7_label) {
        const Space v1763_7_tail = child(v1761_12_tail,v1763_7_label);
        if (v1763_7_tail.empty()) continue;
        const Path v1763_7_head{v1763_7_label};
        const Space v1764_2 = singleton(v1763_7_head);
        const Space v1764_3 = intersect(constant_6,v1764_2);
        const Space v1764_4 = (has_head(v1764_3) ? constant_7 : Space{});
        const Space v1764_5 = subtract(constant_0,v1764_4);
        Space v1764_8;
        if (!v1764_5.empty()) {
          const Path v1765_6 = concat_path(v1763_6,v1763_7_head);
          const Space v1765_7 = routine_235(c, v1765_6, p1, v1763_7_tail);
          v1764_8 = compose(v1764_5,v1765_7);
        }
        const Space v1764_9 = intersect(constant_6,v1764_2);
        const Space v1764_10 = (has_head(v1764_9) ? constant_7 : Space{});
        Space v1764_12;
        if (!v1764_10.empty()) {
          const Path v1766_6 = concat_path(v1763_6,v1763_7_head);
          const Space v1766_11 = routine_236(c, v1766_6, p1, v1763_7_tail);
          v1764_12 = compose(v1764_10,v1766_11);
        }
        const Space v1764_13 = unite(v1764_8,v1764_12);
        v1763_7_result = unite(v1763_7_result,v1764_13);
      }
      const Space v1763_7 = std::move(v1763_7_result);
      v1762_8 = compose(v1762_5,v1763_7);
    }
    const Space v1762_9 = intersect(constant_6,v1762_2);
    const Space v1762_10 = (has_head(v1762_9) ? constant_7 : Space{});
    Space v1762_12;
    if (!v1762_10.empty()) {
      const Path v1767_6 = concat_path(p0,v1761_12_head);
      Space v1767_11_result;
      for (int v1767_11_label = 1; v1767_11_label <= 2; ++v1767_11_label) {
        const Space v1767_11_tail = child(v1761_12_tail,v1767_11_label);
        if (v1767_11_tail.empty()) continue;
        const Path v1767_11_head{v1767_11_label};
        const Space v1768_2 = singleton(v1767_11_head);
        const Space v1768_3 = intersect(constant_6,v1768_2);
        const Space v1768_4 = (has_head(v1768_3) ? constant_7 : Space{});
        const Space v1768_5 = subtract(constant_0,v1768_4);
        Space v1768_8;
        if (!v1768_5.empty()) {
          const Path v1769_6 = concat_path(v1767_6,v1767_11_head);
          const Space v1769_7 = routine_235(c, v1769_6, p1, v1767_11_tail);
          v1768_8 = compose(v1768_5,v1769_7);
        }
        const Space v1768_9 = intersect(constant_6,v1768_2);
        const Space v1768_10 = (has_head(v1768_9) ? constant_7 : Space{});
        Space v1768_12;
        if (!v1768_10.empty()) {
          const Path v1770_6 = concat_path(v1767_6,v1767_11_head);
          const Space v1770_11 = routine_42(c, v1770_6, p1, v1767_11_tail);
          v1768_12 = compose(v1768_10,v1770_11);
        }
        const Space v1768_13 = unite(v1768_8,v1768_12);
        v1767_11_result = unite(v1767_11_result,v1768_13);
      }
      const Space v1767_11 = std::move(v1767_11_result);
      v1762_12 = compose(v1762_10,v1767_11);
    }
    const Space v1762_13 = unite(v1762_8,v1762_12);
    v1761_12_result = unite(v1761_12_result,v1762_13);
  }
  const Space v1761_12 = std::move(v1761_12_result);
  return v1761_12;
}

static Space routine_194(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1771_9_result;
  for (int v1771_9_label = 1; v1771_9_label <= 2; ++v1771_9_label) {
    const Space v1771_9_tail = child(s0,v1771_9_label);
    if (v1771_9_tail.empty()) continue;
    const Path v1771_9_head{v1771_9_label};
    const Space v1772_2 = singleton(v1771_9_head);
    const Space v1772_3 = intersect(constant_6,v1772_2);
    const Space v1772_4 = (has_head(v1772_3) ? constant_7 : Space{});
    const Space v1772_5 = subtract(constant_0,v1772_4);
    Space v1772_8;
    if (!v1772_5.empty()) {
      const Path v1773_6 = concat_path(p0,v1771_9_head);
      Space v1773_7_result;
      for (int v1773_7_label = 1; v1773_7_label <= 2; ++v1773_7_label) {
        const Space v1773_7_tail = child(v1771_9_tail,v1773_7_label);
        if (v1773_7_tail.empty()) continue;
        const Path v1773_7_head{v1773_7_label};
        const Space v1774_2 = singleton(v1773_7_head);
        const Space v1774_3 = intersect(constant_6,v1774_2);
        const Space v1774_4 = (has_head(v1774_3) ? constant_7 : Space{});
        const Space v1774_5 = subtract(constant_0,v1774_4);
        Space v1774_8;
        if (!v1774_5.empty()) {
          const Path v1775_6 = concat_path(v1773_6,v1773_7_head);
          const Space v1775_7 = routine_235(c, v1775_6, p1, v1773_7_tail);
          v1774_8 = compose(v1774_5,v1775_7);
        }
        const Space v1774_9 = intersect(constant_6,v1774_2);
        const Space v1774_10 = (has_head(v1774_9) ? constant_7 : Space{});
        Space v1774_12;
        if (!v1774_10.empty()) {
          const Path v1776_6 = concat_path(v1773_6,v1773_7_head);
          const Space v1776_11 = routine_236(c, v1776_6, p1, v1773_7_tail);
          v1774_12 = compose(v1774_10,v1776_11);
        }
        const Space v1774_13 = unite(v1774_8,v1774_12);
        v1773_7_result = unite(v1773_7_result,v1774_13);
      }
      const Space v1773_7 = std::move(v1773_7_result);
      v1772_8 = compose(v1772_5,v1773_7);
    }
    const Space v1772_9 = intersect(constant_6,v1772_2);
    const Space v1772_10 = (has_head(v1772_9) ? constant_7 : Space{});
    Space v1772_13;
    if (!v1772_10.empty()) {
      const Path v1777_6 = concat_path(p0,v1771_9_head);
      const Path v1777_11 = concat_path(p1,v1777_6);
      const Space v1777_12 = routine_29(c, v1777_11);
      v1772_13 = compose(v1772_10,v1777_12);
    }
    const Space v1772_14 = unite(v1772_8,v1772_13);
    v1771_9_result = unite(v1771_9_result,v1772_14);
  }
  const Space v1771_9 = std::move(v1771_9_result);
  return v1771_9;
}

static Space routine_195(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1778_7_result;
  for (int v1778_7_label = 1; v1778_7_label <= 2; ++v1778_7_label) {
    const Space v1778_7_tail = child(s0,v1778_7_label);
    if (v1778_7_tail.empty()) continue;
    const Path v1778_7_head{v1778_7_label};
    const Space v1779_2 = singleton(v1778_7_head);
    const Space v1779_3 = intersect(constant_6,v1779_2);
    const Space v1779_4 = (has_head(v1779_3) ? constant_7 : Space{});
    const Space v1779_5 = subtract(constant_0,v1779_4);
    Space v1779_6_result;
    for (int v1779_6_label = 1; v1779_6_label <= 2; ++v1779_6_label) {
      const Space v1779_6_tail = child(v1778_7_tail,v1779_6_label);
      if (v1779_6_tail.empty()) continue;
      const Path v1779_6_head{v1779_6_label};
      const Space v1780_2 = Space{};
      v1779_6_result = unite(v1779_6_result,v1780_2);
    }
    const Space v1779_6 = std::move(v1779_6_result);
    const Space v1779_7 = compose(v1779_5,v1779_6);
    const Space v1779_8 = intersect(constant_6,v1779_2);
    const Space v1779_9 = (has_head(v1779_8) ? constant_7 : Space{});
    Space v1779_12;
    if (!v1779_9.empty()) {
      const Path v1781_10 = concat_path(p0,v1778_7_head);
      Space v1781_11_result;
      for (int v1781_11_label = 1; v1781_11_label <= 2; ++v1781_11_label) {
        const Space v1781_11_tail = child(v1778_7_tail,v1781_11_label);
        if (v1781_11_tail.empty()) continue;
        const Path v1781_11_head{v1781_11_label};
        const Space v1782_2 = singleton(v1781_11_head);
        const Space v1782_3 = intersect(constant_6,v1782_2);
        const Space v1782_4 = (has_head(v1782_3) ? constant_7 : Space{});
        Space v1782_7;
        if (!v1782_4.empty()) {
          const Path v1783_5 = concat_path(v1781_10,v1781_11_head);
          const Space v1783_6 = routine_42(c, v1783_5, p1, v1781_11_tail);
          v1782_7 = compose(v1782_4,v1783_6);
        }
        v1781_11_result = unite(v1781_11_result,v1782_7);
      }
      const Space v1781_11 = std::move(v1781_11_result);
      v1779_12 = compose(v1779_9,v1781_11);
    }
    const Space v1779_13 = unite(v1779_7,v1779_12);
    v1778_7_result = unite(v1778_7_result,v1779_13);
  }
  const Space v1778_7 = std::move(v1778_7_result);
  return v1778_7;
}

static Space routine_196(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1784_6_result;
  for (int v1784_6_label = 1; v1784_6_label <= 2; ++v1784_6_label) {
    const Space v1784_6_tail = child(s0,v1784_6_label);
    if (v1784_6_tail.empty()) continue;
    const Path v1784_6_head{v1784_6_label};
    const Space v1785_2 = singleton(v1784_6_head);
    const Space v1785_3 = intersect(constant_6,v1785_2);
    const Space v1785_4 = (has_head(v1785_3) ? constant_7 : Space{});
    const Space v1785_5 = subtract(constant_0,v1785_4);
    Space v1785_6_result;
    for (int v1785_6_label = 1; v1785_6_label <= 2; ++v1785_6_label) {
      const Space v1785_6_tail = child(v1784_6_tail,v1785_6_label);
      if (v1785_6_tail.empty()) continue;
      const Path v1785_6_head{v1785_6_label};
      const Space v1786_2 = Space{};
      v1785_6_result = unite(v1785_6_result,v1786_2);
    }
    const Space v1785_6 = std::move(v1785_6_result);
    const Space v1785_7 = compose(v1785_5,v1785_6);
    const Space v1785_8 = intersect(constant_6,v1785_2);
    const Space v1785_9 = (has_head(v1785_8) ? constant_7 : Space{});
    Space v1785_13;
    if (!v1785_9.empty()) {
      const Path v1787_10 = concat_path(p0,v1784_6_head);
      const Path v1787_11 = concat_path(p1,v1787_10);
      const Space v1787_12 = routine_29(c, v1787_11);
      v1785_13 = compose(v1785_9,v1787_12);
    }
    const Space v1785_14 = unite(v1785_7,v1785_13);
    v1784_6_result = unite(v1784_6_result,v1785_14);
  }
  const Space v1784_6 = std::move(v1784_6_result);
  return v1784_6;
}

static Space routine_197(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1788_13_result;
  for (int v1788_13_label = 1; v1788_13_label <= 2; ++v1788_13_label) {
    const Space v1788_13_tail = child(s0,v1788_13_label);
    if (v1788_13_tail.empty()) continue;
    const Path v1788_13_head{v1788_13_label};
    const Space v1789_2 = singleton(v1788_13_head);
    const Space v1789_3 = intersect(constant_6,v1789_2);
    const Space v1789_4 = (has_head(v1789_3) ? constant_7 : Space{});
    const Space v1789_5 = subtract(constant_0,v1789_4);
    Space v1789_8;
    if (!v1789_5.empty()) {
      const Path v1790_6 = concat_path(p0,v1788_13_head);
      Space v1790_7_result;
      for (int v1790_7_label = 1; v1790_7_label <= 2; ++v1790_7_label) {
        const Space v1790_7_tail = child(v1788_13_tail,v1790_7_label);
        if (v1790_7_tail.empty()) continue;
        const Path v1790_7_head{v1790_7_label};
        const Space v1791_2 = singleton(v1790_7_head);
        const Space v1791_3 = intersect(constant_6,v1791_2);
        const Space v1791_4 = (has_head(v1791_3) ? constant_7 : Space{});
        const Space v1791_5 = subtract(constant_0,v1791_4);
        Space v1791_8;
        if (!v1791_5.empty()) {
          const Path v1792_6 = concat_path(v1790_6,v1790_7_head);
          const Space v1792_7 = routine_237(c, v1792_6, p1, v1790_7_tail, s1);
          v1791_8 = compose(v1791_5,v1792_7);
        }
        const Space v1791_9 = intersect(constant_6,v1791_2);
        const Space v1791_10 = (has_head(v1791_9) ? constant_7 : Space{});
        Space v1791_12;
        if (!v1791_10.empty()) {
          const Path v1793_6 = concat_path(v1790_6,v1790_7_head);
          const Space v1793_11 = routine_238(c, v1793_6, p1, v1790_7_tail, s1);
          v1791_12 = compose(v1791_10,v1793_11);
        }
        const Space v1791_13 = unite(v1791_8,v1791_12);
        v1790_7_result = unite(v1790_7_result,v1791_13);
      }
      const Space v1790_7 = std::move(v1790_7_result);
      v1789_8 = compose(v1789_5,v1790_7);
    }
    const Space v1789_9 = intersect(constant_6,v1789_2);
    const Space v1789_10 = (has_head(v1789_9) ? constant_7 : Space{});
    Space v1789_12;
    if (!v1789_10.empty()) {
      const Path v1794_6 = concat_path(p0,v1788_13_head);
      Space v1794_11_result;
      for (int v1794_11_label = 1; v1794_11_label <= 2; ++v1794_11_label) {
        const Space v1794_11_tail = child(v1788_13_tail,v1794_11_label);
        if (v1794_11_tail.empty()) continue;
        const Path v1794_11_head{v1794_11_label};
        const Space v1795_2 = singleton(v1794_11_head);
        const Space v1795_3 = intersect(constant_6,v1795_2);
        const Space v1795_4 = (has_head(v1795_3) ? constant_7 : Space{});
        const Space v1795_5 = subtract(constant_0,v1795_4);
        Space v1795_8;
        if (!v1795_5.empty()) {
          const Path v1796_6 = concat_path(v1794_6,v1794_11_head);
          const Space v1796_7 = routine_237(c, v1796_6, p1, v1794_11_tail, s1);
          v1795_8 = compose(v1795_5,v1796_7);
        }
        const Space v1795_9 = intersect(constant_6,v1795_2);
        const Space v1795_10 = (has_head(v1795_9) ? constant_7 : Space{});
        Space v1795_12;
        if (!v1795_10.empty()) {
          const Path v1797_6 = concat_path(v1794_6,v1794_11_head);
          const Space v1797_11 = routine_49(c, v1797_6, p1, v1794_11_tail, s1);
          v1795_12 = compose(v1795_10,v1797_11);
        }
        const Space v1795_13 = unite(v1795_8,v1795_12);
        v1794_11_result = unite(v1794_11_result,v1795_13);
      }
      const Space v1794_11 = std::move(v1794_11_result);
      v1789_12 = compose(v1789_10,v1794_11);
    }
    const Space v1789_13 = unite(v1789_8,v1789_12);
    v1788_13_result = unite(v1788_13_result,v1789_13);
  }
  const Space v1788_13 = std::move(v1788_13_result);
  return v1788_13;
}

static Space routine_198(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1798_8 = unwrap(s1,constant_8);
  Space v1798_21_result;
  for (int v1798_21_label = 1; v1798_21_label <= 2; ++v1798_21_label) {
    const Space v1798_21_tail = child(s0,v1798_21_label);
    if (v1798_21_tail.empty()) continue;
    const Path v1798_21_head{v1798_21_label};
    const Space v1799_2 = singleton(v1798_21_head);
    const Space v1799_3 = intersect(constant_6,v1799_2);
    const Space v1799_4 = (has_head(v1799_3) ? constant_7 : Space{});
    const Space v1799_5 = subtract(constant_0,v1799_4);
    Space v1799_8;
    if (!v1799_5.empty()) {
      const Path v1800_6 = concat_path(p0,v1798_21_head);
      Space v1800_7_result;
      for (int v1800_7_label = 1; v1800_7_label <= 2; ++v1800_7_label) {
        const Space v1800_7_tail = child(v1798_21_tail,v1800_7_label);
        if (v1800_7_tail.empty()) continue;
        const Path v1800_7_head{v1800_7_label};
        const Space v1801_2 = singleton(v1800_7_head);
        const Space v1801_3 = intersect(constant_6,v1801_2);
        const Space v1801_4 = (has_head(v1801_3) ? constant_7 : Space{});
        const Space v1801_5 = subtract(constant_0,v1801_4);
        Space v1801_8;
        if (!v1801_5.empty()) {
          const Path v1802_6 = concat_path(v1800_6,v1800_7_head);
          const Space v1802_7 = routine_237(c, v1802_6, p1, v1800_7_tail, s1);
          v1801_8 = compose(v1801_5,v1802_7);
        }
        const Space v1801_9 = intersect(constant_6,v1801_2);
        const Space v1801_10 = (has_head(v1801_9) ? constant_7 : Space{});
        Space v1801_12;
        if (!v1801_10.empty()) {
          const Path v1803_6 = concat_path(v1800_6,v1800_7_head);
          const Space v1803_11 = routine_238(c, v1803_6, p1, v1800_7_tail, s1);
          v1801_12 = compose(v1801_10,v1803_11);
        }
        const Space v1801_13 = unite(v1801_8,v1801_12);
        v1800_7_result = unite(v1800_7_result,v1801_13);
      }
      const Space v1800_7 = std::move(v1800_7_result);
      v1799_8 = compose(v1799_5,v1800_7);
    }
    const Space v1799_9 = intersect(constant_6,v1799_2);
    const Space v1799_10 = (has_head(v1799_9) ? constant_7 : Space{});
    Space v1799_22;
    if (!v1799_10.empty()) {
      const Path v1804_6 = concat_path(p0,v1798_21_head);
      const Path v1804_11 = concat_path(p1,v1804_6);
      const Space v1804_12 = routine_29(c, v1804_11);
      const Space v1804_13 = intersect(v1798_8,v1804_12);
      const Space v1804_14 = routine_33(c, v1804_13);
      Space v1804_15_result;
      for (int v1804_15_label = 1; v1804_15_label <= 2; ++v1804_15_label) {
        const Space v1804_15_tail = child(v1804_14,v1804_15_label);
        if (v1804_15_tail.empty()) continue;
        const Path v1804_15_head{v1804_15_label};
        const Space v1805_2 = singleton(v1804_15_head);
        const Space v1805_3 = intersect(constant_6,v1805_2);
        const Space v1805_4 = (has_head(v1805_3) ? constant_7 : Space{});
        const Space v1805_5 = subtract(constant_0,v1805_4);
        Space v1805_7;
        if (!v1805_5.empty()) {
          const Space v1806_6 = routine_52(c, v1804_15_head, v1804_15_tail);
          v1805_7 = compose(v1805_5,v1806_6);
        }
        const Space v1805_8 = intersect(constant_6,v1805_2);
        const Space v1805_9 = (has_head(v1805_8) ? constant_7 : Space{});
        Space v1805_11;
        if (!v1805_9.empty()) {
          const Space v1807_10 = routine_53(c, v1804_15_head, v1804_15_tail);
          v1805_11 = compose(v1805_9,v1807_10);
        }
        const Space v1805_12 = unite(v1805_7,v1805_11);
        v1804_15_result = unite(v1804_15_result,v1805_12);
      }
      const Space v1804_15 = std::move(v1804_15_result);
      const Space v1804_16 = routine_54(c, v1804_13);
      Space v1804_17_result;
      for (int v1804_17_label = 1; v1804_17_label <= 2; ++v1804_17_label) {
        const Space v1804_17_tail = child(v1804_16,v1804_17_label);
        if (v1804_17_tail.empty()) continue;
        const Path v1804_17_head{v1804_17_label};
        const Space v1808_2 = singleton(v1804_17_head);
        const Space v1808_3 = intersect(constant_6,v1808_2);
        const Space v1808_4 = (has_head(v1808_3) ? constant_7 : Space{});
        const Space v1808_5 = subtract(constant_0,v1808_4);
        Space v1808_7;
        if (!v1808_5.empty()) {
          const Space v1809_6 = routine_55(c, v1804_17_head, v1804_17_tail);
          v1808_7 = compose(v1808_5,v1809_6);
        }
        const Space v1808_8 = intersect(constant_6,v1808_2);
        const Space v1808_9 = (has_head(v1808_8) ? constant_7 : Space{});
        Space v1808_11;
        if (!v1808_9.empty()) {
          const Space v1810_10 = routine_56(c, v1804_17_head, v1804_17_tail);
          v1808_11 = compose(v1808_9,v1810_10);
        }
        const Space v1808_12 = unite(v1808_7,v1808_11);
        v1804_17_result = unite(v1804_17_result,v1808_12);
      }
      const Space v1804_17 = std::move(v1804_17_result);
      const Space v1804_18 = subtract(v1804_15,v1804_17);
      const Space v1804_19 = singleton(v1804_11);
      const Space v1804_20 = compose(v1804_18,v1804_19);
      Space v1804_21_result;
      for (int v1804_21_label = 1; v1804_21_label <= 2; ++v1804_21_label) {
        const Space v1804_21_tail = child(v1804_20,v1804_21_label);
        if (v1804_21_tail.empty()) continue;
        const Path v1804_21_head{v1804_21_label};
        const Space v1811_2 = singleton(v1804_21_head);
        const Space v1811_3 = intersect(constant_6,v1811_2);
        const Space v1811_4 = (has_head(v1811_3) ? constant_7 : Space{});
        const Space v1811_5 = subtract(constant_0,v1811_4);
        Space v1811_7;
        if (!v1811_5.empty()) {
          const Space v1812_6 = routine_57(c, v1804_21_head, v1804_21_tail);
          v1811_7 = compose(v1811_5,v1812_6);
        }
        const Space v1811_8 = intersect(constant_6,v1811_2);
        const Space v1811_9 = (has_head(v1811_8) ? constant_7 : Space{});
        Space v1811_11;
        if (!v1811_9.empty()) {
          const Space v1813_10 = routine_58(c, v1804_21_head, v1804_21_tail);
          v1811_11 = compose(v1811_9,v1813_10);
        }
        const Space v1811_12 = unite(v1811_7,v1811_11);
        v1804_21_result = unite(v1804_21_result,v1811_12);
      }
      const Space v1804_21 = std::move(v1804_21_result);
      v1799_22 = compose(v1799_10,v1804_21);
    }
    const Space v1799_23 = unite(v1799_8,v1799_22);
    v1798_21_result = unite(v1798_21_result,v1799_23);
  }
  const Space v1798_21 = std::move(v1798_21_result);
  return v1798_21;
}

static Space routine_199(Context& c, const Path& p0, const Space& s0) {
  Space v1814_11_result;
  for (int v1814_11_label = 1; v1814_11_label <= 2; ++v1814_11_label) {
    const Space v1814_11_tail = child(s0,v1814_11_label);
    if (v1814_11_tail.empty()) continue;
    const Path v1814_11_head{v1814_11_label};
    const Space v1815_2 = singleton(v1814_11_head);
    const Space v1815_3 = intersect(constant_6,v1815_2);
    const Space v1815_4 = (has_head(v1815_3) ? constant_7 : Space{});
    const Space v1815_5 = subtract(constant_0,v1815_4);
    Space v1815_8;
    if (!v1815_5.empty()) {
      const Path v1816_6 = concat_path(p0,v1814_11_head);
      Space v1816_7_result;
      for (int v1816_7_label = 1; v1816_7_label <= 2; ++v1816_7_label) {
        const Space v1816_7_tail = child(v1814_11_tail,v1816_7_label);
        if (v1816_7_tail.empty()) continue;
        const Path v1816_7_head{v1816_7_label};
        const Space v1817_2 = singleton(v1816_7_head);
        const Space v1817_3 = intersect(constant_6,v1817_2);
        const Space v1817_4 = (has_head(v1817_3) ? constant_7 : Space{});
        const Space v1817_5 = subtract(constant_0,v1817_4);
        Space v1817_8;
        if (!v1817_5.empty()) {
          const Path v1818_6 = concat_path(v1816_6,v1816_7_head);
          const Space v1818_7 = routine_239(c, v1818_6, v1816_7_tail);
          v1817_8 = compose(v1817_5,v1818_7);
        }
        const Space v1817_9 = intersect(constant_6,v1817_2);
        const Space v1817_10 = (has_head(v1817_9) ? constant_7 : Space{});
        Space v1817_12;
        if (!v1817_10.empty()) {
          const Path v1819_6 = concat_path(v1816_6,v1816_7_head);
          const Space v1819_11 = routine_240(c, v1819_6, v1816_7_tail);
          v1817_12 = compose(v1817_10,v1819_11);
        }
        const Space v1817_13 = unite(v1817_8,v1817_12);
        v1816_7_result = unite(v1816_7_result,v1817_13);
      }
      const Space v1816_7 = std::move(v1816_7_result);
      v1815_8 = compose(v1815_5,v1816_7);
    }
    const Space v1815_9 = intersect(constant_6,v1815_2);
    const Space v1815_10 = (has_head(v1815_9) ? constant_7 : Space{});
    Space v1815_12;
    if (!v1815_10.empty()) {
      const Path v1820_6 = concat_path(p0,v1814_11_head);
      Space v1820_11_result;
      for (int v1820_11_label = 1; v1820_11_label <= 2; ++v1820_11_label) {
        const Space v1820_11_tail = child(v1814_11_tail,v1820_11_label);
        if (v1820_11_tail.empty()) continue;
        const Path v1820_11_head{v1820_11_label};
        const Space v1821_2 = singleton(v1820_11_head);
        const Space v1821_3 = intersect(constant_6,v1821_2);
        const Space v1821_4 = (has_head(v1821_3) ? constant_7 : Space{});
        const Space v1821_5 = subtract(constant_0,v1821_4);
        Space v1821_8;
        if (!v1821_5.empty()) {
          const Path v1822_6 = concat_path(v1820_6,v1820_11_head);
          const Space v1822_7 = routine_239(c, v1822_6, v1820_11_tail);
          v1821_8 = compose(v1821_5,v1822_7);
        }
        const Space v1821_9 = intersect(constant_6,v1821_2);
        const Space v1821_10 = (has_head(v1821_9) ? constant_7 : Space{});
        Space v1821_12;
        if (!v1821_10.empty()) {
          const Path v1823_6 = concat_path(v1820_6,v1820_11_head);
          const Space v1823_11 = routine_100(c, v1823_6, v1820_11_tail);
          v1821_12 = compose(v1821_10,v1823_11);
        }
        const Space v1821_13 = unite(v1821_8,v1821_12);
        v1820_11_result = unite(v1820_11_result,v1821_13);
      }
      const Space v1820_11 = std::move(v1820_11_result);
      v1815_12 = compose(v1815_10,v1820_11);
    }
    const Space v1815_13 = unite(v1815_8,v1815_12);
    v1814_11_result = unite(v1814_11_result,v1815_13);
  }
  const Space v1814_11 = std::move(v1814_11_result);
  return v1814_11;
}

static Space routine_200(Context& c, const Path& p0, const Space& s0) {
  Space v1824_9_result;
  for (int v1824_9_label = 1; v1824_9_label <= 2; ++v1824_9_label) {
    const Space v1824_9_tail = child(s0,v1824_9_label);
    if (v1824_9_tail.empty()) continue;
    const Path v1824_9_head{v1824_9_label};
    const Space v1825_2 = singleton(v1824_9_head);
    const Space v1825_3 = intersect(constant_6,v1825_2);
    const Space v1825_4 = (has_head(v1825_3) ? constant_7 : Space{});
    const Space v1825_5 = subtract(constant_0,v1825_4);
    Space v1825_8;
    if (!v1825_5.empty()) {
      const Path v1826_6 = concat_path(p0,v1824_9_head);
      Space v1826_7_result;
      for (int v1826_7_label = 1; v1826_7_label <= 2; ++v1826_7_label) {
        const Space v1826_7_tail = child(v1824_9_tail,v1826_7_label);
        if (v1826_7_tail.empty()) continue;
        const Path v1826_7_head{v1826_7_label};
        const Space v1827_2 = singleton(v1826_7_head);
        const Space v1827_3 = intersect(constant_6,v1827_2);
        const Space v1827_4 = (has_head(v1827_3) ? constant_7 : Space{});
        const Space v1827_5 = subtract(constant_0,v1827_4);
        Space v1827_8;
        if (!v1827_5.empty()) {
          const Path v1828_6 = concat_path(v1826_6,v1826_7_head);
          const Space v1828_7 = routine_239(c, v1828_6, v1826_7_tail);
          v1827_8 = compose(v1827_5,v1828_7);
        }
        const Space v1827_9 = intersect(constant_6,v1827_2);
        const Space v1827_10 = (has_head(v1827_9) ? constant_7 : Space{});
        Space v1827_12;
        if (!v1827_10.empty()) {
          const Path v1829_6 = concat_path(v1826_6,v1826_7_head);
          const Space v1829_11 = routine_240(c, v1829_6, v1826_7_tail);
          v1827_12 = compose(v1827_10,v1829_11);
        }
        const Space v1827_13 = unite(v1827_8,v1827_12);
        v1826_7_result = unite(v1826_7_result,v1827_13);
      }
      const Space v1826_7 = std::move(v1826_7_result);
      v1825_8 = compose(v1825_5,v1826_7);
    }
    const Space v1825_9 = intersect(constant_6,v1825_2);
    const Space v1825_10 = (has_head(v1825_9) ? constant_7 : Space{});
    const Space v1825_11 = compose(v1825_10,constant_9);
    const Space v1825_12 = unite(v1825_8,v1825_11);
    v1824_9_result = unite(v1824_9_result,v1825_12);
  }
  const Space v1824_9 = std::move(v1824_9_result);
  return v1824_9;
}

static Space routine_201(Context& c, const Path& p0, const Space& s0) {
  Space v1830_11_result;
  for (int v1830_11_label = 1; v1830_11_label <= 2; ++v1830_11_label) {
    const Space v1830_11_tail = child(s0,v1830_11_label);
    if (v1830_11_tail.empty()) continue;
    const Path v1830_11_head{v1830_11_label};
    const Space v1831_2 = singleton(v1830_11_head);
    const Space v1831_3 = intersect(constant_6,v1831_2);
    const Space v1831_4 = (has_head(v1831_3) ? constant_7 : Space{});
    const Space v1831_5 = subtract(constant_0,v1831_4);
    Space v1831_8;
    if (!v1831_5.empty()) {
      const Path v1832_6 = concat_path(p0,v1830_11_head);
      Space v1832_7_result;
      for (int v1832_7_label = 1; v1832_7_label <= 2; ++v1832_7_label) {
        const Space v1832_7_tail = child(v1830_11_tail,v1832_7_label);
        if (v1832_7_tail.empty()) continue;
        const Path v1832_7_head{v1832_7_label};
        const Space v1833_2 = singleton(v1832_7_head);
        const Space v1833_3 = intersect(constant_6,v1833_2);
        const Space v1833_4 = (has_head(v1833_3) ? constant_7 : Space{});
        const Space v1833_5 = subtract(constant_0,v1833_4);
        Space v1833_8;
        if (!v1833_5.empty()) {
          const Path v1834_6 = concat_path(v1832_6,v1832_7_head);
          const Space v1834_7 = routine_241(c, v1834_6, v1832_7_tail);
          v1833_8 = compose(v1833_5,v1834_7);
        }
        const Space v1833_9 = intersect(constant_6,v1833_2);
        const Space v1833_10 = (has_head(v1833_9) ? constant_7 : Space{});
        Space v1833_12;
        if (!v1833_10.empty()) {
          const Path v1835_6 = concat_path(v1832_6,v1832_7_head);
          const Space v1835_11 = routine_242(c, v1835_6, v1832_7_tail);
          v1833_12 = compose(v1833_10,v1835_11);
        }
        const Space v1833_13 = unite(v1833_8,v1833_12);
        v1832_7_result = unite(v1832_7_result,v1833_13);
      }
      const Space v1832_7 = std::move(v1832_7_result);
      v1831_8 = compose(v1831_5,v1832_7);
    }
    const Space v1831_9 = intersect(constant_6,v1831_2);
    const Space v1831_10 = (has_head(v1831_9) ? constant_7 : Space{});
    Space v1831_12;
    if (!v1831_10.empty()) {
      const Path v1836_6 = concat_path(p0,v1830_11_head);
      Space v1836_11_result;
      for (int v1836_11_label = 1; v1836_11_label <= 2; ++v1836_11_label) {
        const Space v1836_11_tail = child(v1830_11_tail,v1836_11_label);
        if (v1836_11_tail.empty()) continue;
        const Path v1836_11_head{v1836_11_label};
        const Space v1837_2 = singleton(v1836_11_head);
        const Space v1837_3 = intersect(constant_6,v1837_2);
        const Space v1837_4 = (has_head(v1837_3) ? constant_7 : Space{});
        const Space v1837_5 = subtract(constant_0,v1837_4);
        Space v1837_8;
        if (!v1837_5.empty()) {
          const Path v1838_6 = concat_path(v1836_6,v1836_11_head);
          const Space v1838_7 = routine_241(c, v1838_6, v1836_11_tail);
          v1837_8 = compose(v1837_5,v1838_7);
        }
        const Space v1837_9 = intersect(constant_6,v1837_2);
        const Space v1837_10 = (has_head(v1837_9) ? constant_7 : Space{});
        Space v1837_12;
        if (!v1837_10.empty()) {
          const Path v1839_6 = concat_path(v1836_6,v1836_11_head);
          const Space v1839_11 = routine_104(c, v1839_6, v1836_11_tail);
          v1837_12 = compose(v1837_10,v1839_11);
        }
        const Space v1837_13 = unite(v1837_8,v1837_12);
        v1836_11_result = unite(v1836_11_result,v1837_13);
      }
      const Space v1836_11 = std::move(v1836_11_result);
      v1831_12 = compose(v1831_10,v1836_11);
    }
    const Space v1831_13 = unite(v1831_8,v1831_12);
    v1830_11_result = unite(v1830_11_result,v1831_13);
  }
  const Space v1830_11 = std::move(v1830_11_result);
  return v1830_11;
}

static Space routine_202(Context& c, const Path& p0, const Space& s0) {
  Space v1840_9_result;
  for (int v1840_9_label = 1; v1840_9_label <= 2; ++v1840_9_label) {
    const Space v1840_9_tail = child(s0,v1840_9_label);
    if (v1840_9_tail.empty()) continue;
    const Path v1840_9_head{v1840_9_label};
    const Space v1841_2 = singleton(v1840_9_head);
    const Space v1841_3 = intersect(constant_6,v1841_2);
    const Space v1841_4 = (has_head(v1841_3) ? constant_7 : Space{});
    const Space v1841_5 = subtract(constant_0,v1841_4);
    Space v1841_8;
    if (!v1841_5.empty()) {
      const Path v1842_6 = concat_path(p0,v1840_9_head);
      Space v1842_7_result;
      for (int v1842_7_label = 1; v1842_7_label <= 2; ++v1842_7_label) {
        const Space v1842_7_tail = child(v1840_9_tail,v1842_7_label);
        if (v1842_7_tail.empty()) continue;
        const Path v1842_7_head{v1842_7_label};
        const Space v1843_2 = singleton(v1842_7_head);
        const Space v1843_3 = intersect(constant_6,v1843_2);
        const Space v1843_4 = (has_head(v1843_3) ? constant_7 : Space{});
        const Space v1843_5 = subtract(constant_0,v1843_4);
        Space v1843_8;
        if (!v1843_5.empty()) {
          const Path v1844_6 = concat_path(v1842_6,v1842_7_head);
          const Space v1844_7 = routine_241(c, v1844_6, v1842_7_tail);
          v1843_8 = compose(v1843_5,v1844_7);
        }
        const Space v1843_9 = intersect(constant_6,v1843_2);
        const Space v1843_10 = (has_head(v1843_9) ? constant_7 : Space{});
        Space v1843_12;
        if (!v1843_10.empty()) {
          const Path v1845_6 = concat_path(v1842_6,v1842_7_head);
          const Space v1845_11 = routine_242(c, v1845_6, v1842_7_tail);
          v1843_12 = compose(v1843_10,v1845_11);
        }
        const Space v1843_13 = unite(v1843_8,v1843_12);
        v1842_7_result = unite(v1842_7_result,v1843_13);
      }
      const Space v1842_7 = std::move(v1842_7_result);
      v1841_8 = compose(v1841_5,v1842_7);
    }
    const Space v1841_9 = intersect(constant_6,v1841_2);
    const Space v1841_10 = (has_head(v1841_9) ? constant_7 : Space{});
    const Space v1841_11 = compose(v1841_10,constant_9);
    const Space v1841_12 = unite(v1841_8,v1841_11);
    v1840_9_result = unite(v1840_9_result,v1841_12);
  }
  const Space v1840_9 = std::move(v1840_9_result);
  return v1840_9;
}

static Space routine_203(Context& c, const Path& p0, const Space& s0) {
  Space v1846_11_result;
  for (int v1846_11_label = 1; v1846_11_label <= 2; ++v1846_11_label) {
    const Space v1846_11_tail = child(s0,v1846_11_label);
    if (v1846_11_tail.empty()) continue;
    const Path v1846_11_head{v1846_11_label};
    const Space v1847_2 = singleton(v1846_11_head);
    const Space v1847_3 = intersect(constant_6,v1847_2);
    const Space v1847_4 = (has_head(v1847_3) ? constant_7 : Space{});
    const Space v1847_5 = subtract(constant_0,v1847_4);
    Space v1847_8;
    if (!v1847_5.empty()) {
      const Path v1848_6 = concat_path(p0,v1846_11_head);
      Space v1848_7_result;
      for (int v1848_7_label = 1; v1848_7_label <= 2; ++v1848_7_label) {
        const Space v1848_7_tail = child(v1846_11_tail,v1848_7_label);
        if (v1848_7_tail.empty()) continue;
        const Path v1848_7_head{v1848_7_label};
        const Space v1849_2 = singleton(v1848_7_head);
        const Space v1849_3 = intersect(constant_6,v1849_2);
        const Space v1849_4 = (has_head(v1849_3) ? constant_7 : Space{});
        const Space v1849_5 = subtract(constant_0,v1849_4);
        Space v1849_8;
        if (!v1849_5.empty()) {
          const Path v1850_6 = concat_path(v1848_6,v1848_7_head);
          const Space v1850_7 = routine_243(c, v1850_6, v1848_7_tail);
          v1849_8 = compose(v1849_5,v1850_7);
        }
        const Space v1849_9 = intersect(constant_6,v1849_2);
        const Space v1849_10 = (has_head(v1849_9) ? constant_7 : Space{});
        Space v1849_12;
        if (!v1849_10.empty()) {
          const Path v1851_6 = concat_path(v1848_6,v1848_7_head);
          const Space v1851_11 = routine_244(c, v1851_6, v1848_7_tail);
          v1849_12 = compose(v1849_10,v1851_11);
        }
        const Space v1849_13 = unite(v1849_8,v1849_12);
        v1848_7_result = unite(v1848_7_result,v1849_13);
      }
      const Space v1848_7 = std::move(v1848_7_result);
      v1847_8 = compose(v1847_5,v1848_7);
    }
    const Space v1847_9 = intersect(constant_6,v1847_2);
    const Space v1847_10 = (has_head(v1847_9) ? constant_7 : Space{});
    Space v1847_12;
    if (!v1847_10.empty()) {
      const Path v1852_6 = concat_path(p0,v1846_11_head);
      Space v1852_11_result;
      for (int v1852_11_label = 1; v1852_11_label <= 2; ++v1852_11_label) {
        const Space v1852_11_tail = child(v1846_11_tail,v1852_11_label);
        if (v1852_11_tail.empty()) continue;
        const Path v1852_11_head{v1852_11_label};
        const Space v1853_2 = singleton(v1852_11_head);
        const Space v1853_3 = intersect(constant_6,v1853_2);
        const Space v1853_4 = (has_head(v1853_3) ? constant_7 : Space{});
        const Space v1853_5 = subtract(constant_0,v1853_4);
        Space v1853_8;
        if (!v1853_5.empty()) {
          const Path v1854_6 = concat_path(v1852_6,v1852_11_head);
          const Space v1854_7 = routine_243(c, v1854_6, v1852_11_tail);
          v1853_8 = compose(v1853_5,v1854_7);
        }
        const Space v1853_9 = intersect(constant_6,v1853_2);
        const Space v1853_10 = (has_head(v1853_9) ? constant_7 : Space{});
        Space v1853_12;
        if (!v1853_10.empty()) {
          const Path v1855_6 = concat_path(v1852_6,v1852_11_head);
          const Space v1855_11 = routine_107(c, v1855_6, v1852_11_tail);
          v1853_12 = compose(v1853_10,v1855_11);
        }
        const Space v1853_13 = unite(v1853_8,v1853_12);
        v1852_11_result = unite(v1852_11_result,v1853_13);
      }
      const Space v1852_11 = std::move(v1852_11_result);
      v1847_12 = compose(v1847_10,v1852_11);
    }
    const Space v1847_13 = unite(v1847_8,v1847_12);
    v1846_11_result = unite(v1846_11_result,v1847_13);
  }
  const Space v1846_11 = std::move(v1846_11_result);
  return v1846_11;
}

static Space routine_204(Context& c, const Path& p0, const Space& s0) {
  Space v1856_8_result;
  for (int v1856_8_label = 1; v1856_8_label <= 2; ++v1856_8_label) {
    const Space v1856_8_tail = child(s0,v1856_8_label);
    if (v1856_8_tail.empty()) continue;
    const Path v1856_8_head{v1856_8_label};
    const Space v1857_2 = singleton(v1856_8_head);
    const Space v1857_3 = intersect(constant_6,v1857_2);
    const Space v1857_4 = (has_head(v1857_3) ? constant_7 : Space{});
    const Space v1857_5 = subtract(constant_0,v1857_4);
    Space v1857_8;
    if (!v1857_5.empty()) {
      const Path v1858_6 = concat_path(p0,v1856_8_head);
      Space v1858_7_result;
      for (int v1858_7_label = 1; v1858_7_label <= 2; ++v1858_7_label) {
        const Space v1858_7_tail = child(v1856_8_tail,v1858_7_label);
        if (v1858_7_tail.empty()) continue;
        const Path v1858_7_head{v1858_7_label};
        const Space v1859_2 = singleton(v1858_7_head);
        const Space v1859_3 = intersect(constant_6,v1859_2);
        const Space v1859_4 = (has_head(v1859_3) ? constant_7 : Space{});
        const Space v1859_5 = subtract(constant_0,v1859_4);
        Space v1859_8;
        if (!v1859_5.empty()) {
          const Path v1860_6 = concat_path(v1858_6,v1858_7_head);
          const Space v1860_7 = routine_243(c, v1860_6, v1858_7_tail);
          v1859_8 = compose(v1859_5,v1860_7);
        }
        const Space v1859_9 = intersect(constant_6,v1859_2);
        const Space v1859_10 = (has_head(v1859_9) ? constant_7 : Space{});
        Space v1859_12;
        if (!v1859_10.empty()) {
          const Path v1861_6 = concat_path(v1858_6,v1858_7_head);
          const Space v1861_11 = routine_244(c, v1861_6, v1858_7_tail);
          v1859_12 = compose(v1859_10,v1861_11);
        }
        const Space v1859_13 = unite(v1859_8,v1859_12);
        v1858_7_result = unite(v1858_7_result,v1859_13);
      }
      const Space v1858_7 = std::move(v1858_7_result);
      v1857_8 = compose(v1857_5,v1858_7);
    }
    const Space v1857_9 = intersect(constant_6,v1857_2);
    const Space v1857_10 = (has_head(v1857_9) ? constant_7 : Space{});
    const Space v1857_11 = compose(v1857_10,v1856_8_tail);
    const Space v1857_12 = unite(v1857_8,v1857_11);
    v1856_8_result = unite(v1856_8_result,v1857_12);
  }
  const Space v1856_8 = std::move(v1856_8_result);
  return v1856_8;
}

static Space routine_205(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1862_8_result;
  for (int v1862_8_label = 1; v1862_8_label <= 2; ++v1862_8_label) {
    const Space v1862_8_tail = child(s0,v1862_8_label);
    if (v1862_8_tail.empty()) continue;
    const Path v1862_8_head{v1862_8_label};
    const Space v1863_2 = singleton(v1862_8_head);
    const Space v1863_3 = intersect(constant_6,v1863_2);
    const Space v1863_4 = (has_head(v1863_3) ? constant_7 : Space{});
    const Space v1863_5 = subtract(constant_0,v1863_4);
    Space v1863_6_result;
    for (int v1863_6_label = 1; v1863_6_label <= 2; ++v1863_6_label) {
      const Space v1863_6_tail = child(v1862_8_tail,v1863_6_label);
      if (v1863_6_tail.empty()) continue;
      const Path v1863_6_head{v1863_6_label};
      const Space v1864_2 = Space{};
      v1863_6_result = unite(v1863_6_result,v1864_2);
    }
    const Space v1863_6 = std::move(v1863_6_result);
    const Space v1863_7 = compose(v1863_5,v1863_6);
    const Space v1863_8 = intersect(constant_6,v1863_2);
    const Space v1863_9 = (has_head(v1863_8) ? constant_7 : Space{});
    Space v1863_12;
    if (!v1863_9.empty()) {
      const Path v1865_10 = concat_path(p0,v1862_8_head);
      Space v1865_11_result;
      for (int v1865_11_label = 1; v1865_11_label <= 2; ++v1865_11_label) {
        const Space v1865_11_tail = child(v1862_8_tail,v1865_11_label);
        if (v1865_11_tail.empty()) continue;
        const Path v1865_11_head{v1865_11_label};
        const Space v1866_2 = singleton(v1865_11_head);
        const Space v1866_3 = intersect(constant_6,v1866_2);
        const Space v1866_4 = (has_head(v1866_3) ? constant_7 : Space{});
        Space v1866_7;
        if (!v1866_4.empty()) {
          const Path v1867_5 = concat_path(v1865_10,v1865_11_head);
          const Space v1867_6 = routine_49(c, v1867_5, p1, v1865_11_tail, s1);
          v1866_7 = compose(v1866_4,v1867_6);
        }
        v1865_11_result = unite(v1865_11_result,v1866_7);
      }
      const Space v1865_11 = std::move(v1865_11_result);
      v1863_12 = compose(v1863_9,v1865_11);
    }
    const Space v1863_13 = unite(v1863_7,v1863_12);
    v1862_8_result = unite(v1862_8_result,v1863_13);
  }
  const Space v1862_8 = std::move(v1862_8_result);
  return v1862_8;
}

static Space routine_206(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1868_8 = unwrap(s1,constant_8);
  Space v1868_18_result;
  for (int v1868_18_label = 1; v1868_18_label <= 2; ++v1868_18_label) {
    const Space v1868_18_tail = child(s0,v1868_18_label);
    if (v1868_18_tail.empty()) continue;
    const Path v1868_18_head{v1868_18_label};
    const Space v1869_2 = singleton(v1868_18_head);
    const Space v1869_3 = intersect(constant_6,v1869_2);
    const Space v1869_4 = (has_head(v1869_3) ? constant_7 : Space{});
    const Space v1869_5 = subtract(constant_0,v1869_4);
    Space v1869_6_result;
    for (int v1869_6_label = 1; v1869_6_label <= 2; ++v1869_6_label) {
      const Space v1869_6_tail = child(v1868_18_tail,v1869_6_label);
      if (v1869_6_tail.empty()) continue;
      const Path v1869_6_head{v1869_6_label};
      const Space v1870_2 = Space{};
      v1869_6_result = unite(v1869_6_result,v1870_2);
    }
    const Space v1869_6 = std::move(v1869_6_result);
    const Space v1869_7 = compose(v1869_5,v1869_6);
    const Space v1869_8 = intersect(constant_6,v1869_2);
    const Space v1869_9 = (has_head(v1869_8) ? constant_7 : Space{});
    Space v1869_22;
    if (!v1869_9.empty()) {
      const Path v1871_10 = concat_path(p0,v1868_18_head);
      const Path v1871_11 = concat_path(p1,v1871_10);
      const Space v1871_12 = routine_29(c, v1871_11);
      const Space v1871_13 = intersect(v1868_8,v1871_12);
      const Space v1871_14 = routine_33(c, v1871_13);
      Space v1871_15_result;
      for (int v1871_15_label = 1; v1871_15_label <= 2; ++v1871_15_label) {
        const Space v1871_15_tail = child(v1871_14,v1871_15_label);
        if (v1871_15_tail.empty()) continue;
        const Path v1871_15_head{v1871_15_label};
        const Space v1872_2 = singleton(v1871_15_head);
        const Space v1872_3 = intersect(constant_6,v1872_2);
        const Space v1872_4 = (has_head(v1872_3) ? constant_7 : Space{});
        const Space v1872_5 = subtract(constant_0,v1872_4);
        Space v1872_7;
        if (!v1872_5.empty()) {
          const Space v1873_6 = routine_52(c, v1871_15_head, v1871_15_tail);
          v1872_7 = compose(v1872_5,v1873_6);
        }
        const Space v1872_8 = intersect(constant_6,v1872_2);
        const Space v1872_9 = (has_head(v1872_8) ? constant_7 : Space{});
        Space v1872_11;
        if (!v1872_9.empty()) {
          const Space v1874_10 = routine_53(c, v1871_15_head, v1871_15_tail);
          v1872_11 = compose(v1872_9,v1874_10);
        }
        const Space v1872_12 = unite(v1872_7,v1872_11);
        v1871_15_result = unite(v1871_15_result,v1872_12);
      }
      const Space v1871_15 = std::move(v1871_15_result);
      const Space v1871_16 = routine_54(c, v1871_13);
      Space v1871_17_result;
      for (int v1871_17_label = 1; v1871_17_label <= 2; ++v1871_17_label) {
        const Space v1871_17_tail = child(v1871_16,v1871_17_label);
        if (v1871_17_tail.empty()) continue;
        const Path v1871_17_head{v1871_17_label};
        const Space v1875_2 = singleton(v1871_17_head);
        const Space v1875_3 = intersect(constant_6,v1875_2);
        const Space v1875_4 = (has_head(v1875_3) ? constant_7 : Space{});
        const Space v1875_5 = subtract(constant_0,v1875_4);
        Space v1875_7;
        if (!v1875_5.empty()) {
          const Space v1876_6 = routine_55(c, v1871_17_head, v1871_17_tail);
          v1875_7 = compose(v1875_5,v1876_6);
        }
        const Space v1875_8 = intersect(constant_6,v1875_2);
        const Space v1875_9 = (has_head(v1875_8) ? constant_7 : Space{});
        Space v1875_11;
        if (!v1875_9.empty()) {
          const Space v1877_10 = routine_56(c, v1871_17_head, v1871_17_tail);
          v1875_11 = compose(v1875_9,v1877_10);
        }
        const Space v1875_12 = unite(v1875_7,v1875_11);
        v1871_17_result = unite(v1871_17_result,v1875_12);
      }
      const Space v1871_17 = std::move(v1871_17_result);
      const Space v1871_18 = subtract(v1871_15,v1871_17);
      const Space v1871_19 = singleton(v1871_11);
      const Space v1871_20 = compose(v1871_18,v1871_19);
      Space v1871_21_result;
      for (int v1871_21_label = 1; v1871_21_label <= 2; ++v1871_21_label) {
        const Space v1871_21_tail = child(v1871_20,v1871_21_label);
        if (v1871_21_tail.empty()) continue;
        const Path v1871_21_head{v1871_21_label};
        const Space v1878_2 = singleton(v1871_21_head);
        const Space v1878_3 = intersect(constant_6,v1878_2);
        const Space v1878_4 = (has_head(v1878_3) ? constant_7 : Space{});
        const Space v1878_5 = subtract(constant_0,v1878_4);
        Space v1878_7;
        if (!v1878_5.empty()) {
          const Space v1879_6 = routine_57(c, v1871_21_head, v1871_21_tail);
          v1878_7 = compose(v1878_5,v1879_6);
        }
        const Space v1878_8 = intersect(constant_6,v1878_2);
        const Space v1878_9 = (has_head(v1878_8) ? constant_7 : Space{});
        Space v1878_11;
        if (!v1878_9.empty()) {
          const Space v1880_10 = routine_58(c, v1871_21_head, v1871_21_tail);
          v1878_11 = compose(v1878_9,v1880_10);
        }
        const Space v1878_12 = unite(v1878_7,v1878_11);
        v1871_21_result = unite(v1871_21_result,v1878_12);
      }
      const Space v1871_21 = std::move(v1871_21_result);
      v1869_22 = compose(v1869_9,v1871_21);
    }
    const Space v1869_23 = unite(v1869_7,v1869_22);
    v1868_18_result = unite(v1868_18_result,v1869_23);
  }
  const Space v1868_18 = std::move(v1868_18_result);
  return v1868_18;
}

static Space routine_207(Context& c, const Path& p0, const Space& s0) {
  Space v1881_11_result;
  for (int v1881_11_label = 1; v1881_11_label <= 2; ++v1881_11_label) {
    const Space v1881_11_tail = child(s0,v1881_11_label);
    if (v1881_11_tail.empty()) continue;
    const Path v1881_11_head{v1881_11_label};
    const Space v1882_2 = singleton(v1881_11_head);
    const Space v1882_3 = intersect(constant_6,v1882_2);
    const Space v1882_4 = (has_head(v1882_3) ? constant_7 : Space{});
    const Space v1882_5 = subtract(constant_0,v1882_4);
    Space v1882_8;
    if (!v1882_5.empty()) {
      const Path v1883_6 = concat_path(p0,v1881_11_head);
      Space v1883_7_result;
      for (int v1883_7_label = 1; v1883_7_label <= 2; ++v1883_7_label) {
        const Space v1883_7_tail = child(v1881_11_tail,v1883_7_label);
        if (v1883_7_tail.empty()) continue;
        const Path v1883_7_head{v1883_7_label};
        const Space v1884_2 = singleton(v1883_7_head);
        const Space v1884_3 = intersect(constant_6,v1884_2);
        const Space v1884_4 = (has_head(v1884_3) ? constant_7 : Space{});
        const Space v1884_5 = subtract(constant_0,v1884_4);
        Space v1884_8;
        if (!v1884_5.empty()) {
          const Path v1885_6 = concat_path(v1883_6,v1883_7_head);
          const Space v1885_7 = routine_245(c, v1885_6, v1883_7_tail);
          v1884_8 = compose(v1884_5,v1885_7);
        }
        const Space v1884_9 = intersect(constant_6,v1884_2);
        const Space v1884_10 = (has_head(v1884_9) ? constant_7 : Space{});
        Space v1884_12;
        if (!v1884_10.empty()) {
          const Path v1886_6 = concat_path(v1883_6,v1883_7_head);
          const Space v1886_11 = routine_246(c, v1886_6, v1883_7_tail);
          v1884_12 = compose(v1884_10,v1886_11);
        }
        const Space v1884_13 = unite(v1884_8,v1884_12);
        v1883_7_result = unite(v1883_7_result,v1884_13);
      }
      const Space v1883_7 = std::move(v1883_7_result);
      v1882_8 = compose(v1882_5,v1883_7);
    }
    const Space v1882_9 = intersect(constant_6,v1882_2);
    const Space v1882_10 = (has_head(v1882_9) ? constant_7 : Space{});
    Space v1882_12;
    if (!v1882_10.empty()) {
      const Path v1887_6 = concat_path(p0,v1881_11_head);
      Space v1887_11_result;
      for (int v1887_11_label = 1; v1887_11_label <= 2; ++v1887_11_label) {
        const Space v1887_11_tail = child(v1881_11_tail,v1887_11_label);
        if (v1887_11_tail.empty()) continue;
        const Path v1887_11_head{v1887_11_label};
        const Space v1888_2 = singleton(v1887_11_head);
        const Space v1888_3 = intersect(constant_6,v1888_2);
        const Space v1888_4 = (has_head(v1888_3) ? constant_7 : Space{});
        const Space v1888_5 = subtract(constant_0,v1888_4);
        Space v1888_8;
        if (!v1888_5.empty()) {
          const Path v1889_6 = concat_path(v1887_6,v1887_11_head);
          const Space v1889_7 = routine_245(c, v1889_6, v1887_11_tail);
          v1888_8 = compose(v1888_5,v1889_7);
        }
        const Space v1888_9 = intersect(constant_6,v1888_2);
        const Space v1888_10 = (has_head(v1888_9) ? constant_7 : Space{});
        Space v1888_12;
        if (!v1888_10.empty()) {
          const Path v1890_6 = concat_path(v1887_6,v1887_11_head);
          const Space v1890_11 = routine_100(c, v1890_6, v1887_11_tail);
          v1888_12 = compose(v1888_10,v1890_11);
        }
        const Space v1888_13 = unite(v1888_8,v1888_12);
        v1887_11_result = unite(v1887_11_result,v1888_13);
      }
      const Space v1887_11 = std::move(v1887_11_result);
      v1882_12 = compose(v1882_10,v1887_11);
    }
    const Space v1882_13 = unite(v1882_8,v1882_12);
    v1881_11_result = unite(v1881_11_result,v1882_13);
  }
  const Space v1881_11 = std::move(v1881_11_result);
  return v1881_11;
}

static Space routine_208(Context& c, const Path& p0, const Space& s0) {
  Space v1891_9_result;
  for (int v1891_9_label = 1; v1891_9_label <= 2; ++v1891_9_label) {
    const Space v1891_9_tail = child(s0,v1891_9_label);
    if (v1891_9_tail.empty()) continue;
    const Path v1891_9_head{v1891_9_label};
    const Space v1892_2 = singleton(v1891_9_head);
    const Space v1892_3 = intersect(constant_6,v1892_2);
    const Space v1892_4 = (has_head(v1892_3) ? constant_7 : Space{});
    const Space v1892_5 = subtract(constant_0,v1892_4);
    Space v1892_8;
    if (!v1892_5.empty()) {
      const Path v1893_6 = concat_path(p0,v1891_9_head);
      Space v1893_7_result;
      for (int v1893_7_label = 1; v1893_7_label <= 2; ++v1893_7_label) {
        const Space v1893_7_tail = child(v1891_9_tail,v1893_7_label);
        if (v1893_7_tail.empty()) continue;
        const Path v1893_7_head{v1893_7_label};
        const Space v1894_2 = singleton(v1893_7_head);
        const Space v1894_3 = intersect(constant_6,v1894_2);
        const Space v1894_4 = (has_head(v1894_3) ? constant_7 : Space{});
        const Space v1894_5 = subtract(constant_0,v1894_4);
        Space v1894_8;
        if (!v1894_5.empty()) {
          const Path v1895_6 = concat_path(v1893_6,v1893_7_head);
          const Space v1895_7 = routine_245(c, v1895_6, v1893_7_tail);
          v1894_8 = compose(v1894_5,v1895_7);
        }
        const Space v1894_9 = intersect(constant_6,v1894_2);
        const Space v1894_10 = (has_head(v1894_9) ? constant_7 : Space{});
        Space v1894_12;
        if (!v1894_10.empty()) {
          const Path v1896_6 = concat_path(v1893_6,v1893_7_head);
          const Space v1896_11 = routine_246(c, v1896_6, v1893_7_tail);
          v1894_12 = compose(v1894_10,v1896_11);
        }
        const Space v1894_13 = unite(v1894_8,v1894_12);
        v1893_7_result = unite(v1893_7_result,v1894_13);
      }
      const Space v1893_7 = std::move(v1893_7_result);
      v1892_8 = compose(v1892_5,v1893_7);
    }
    const Space v1892_9 = intersect(constant_6,v1892_2);
    const Space v1892_10 = (has_head(v1892_9) ? constant_7 : Space{});
    const Space v1892_11 = compose(v1892_10,constant_9);
    const Space v1892_12 = unite(v1892_8,v1892_11);
    v1891_9_result = unite(v1891_9_result,v1892_12);
  }
  const Space v1891_9 = std::move(v1891_9_result);
  return v1891_9;
}

static Space routine_209(Context& c, const Path& p0, const Space& s0) {
  Space v1897_11_result;
  for (int v1897_11_label = 1; v1897_11_label <= 2; ++v1897_11_label) {
    const Space v1897_11_tail = child(s0,v1897_11_label);
    if (v1897_11_tail.empty()) continue;
    const Path v1897_11_head{v1897_11_label};
    const Space v1898_2 = singleton(v1897_11_head);
    const Space v1898_3 = intersect(constant_6,v1898_2);
    const Space v1898_4 = (has_head(v1898_3) ? constant_7 : Space{});
    const Space v1898_5 = subtract(constant_0,v1898_4);
    Space v1898_8;
    if (!v1898_5.empty()) {
      const Path v1899_6 = concat_path(p0,v1897_11_head);
      Space v1899_7_result;
      for (int v1899_7_label = 1; v1899_7_label <= 2; ++v1899_7_label) {
        const Space v1899_7_tail = child(v1897_11_tail,v1899_7_label);
        if (v1899_7_tail.empty()) continue;
        const Path v1899_7_head{v1899_7_label};
        const Space v1900_2 = singleton(v1899_7_head);
        const Space v1900_3 = intersect(constant_6,v1900_2);
        const Space v1900_4 = (has_head(v1900_3) ? constant_7 : Space{});
        const Space v1900_5 = subtract(constant_0,v1900_4);
        Space v1900_8;
        if (!v1900_5.empty()) {
          const Path v1901_6 = concat_path(v1899_6,v1899_7_head);
          const Space v1901_7 = routine_247(c, v1901_6, v1899_7_tail);
          v1900_8 = compose(v1900_5,v1901_7);
        }
        const Space v1900_9 = intersect(constant_6,v1900_2);
        const Space v1900_10 = (has_head(v1900_9) ? constant_7 : Space{});
        Space v1900_12;
        if (!v1900_10.empty()) {
          const Path v1902_6 = concat_path(v1899_6,v1899_7_head);
          const Space v1902_11 = routine_248(c, v1902_6, v1899_7_tail);
          v1900_12 = compose(v1900_10,v1902_11);
        }
        const Space v1900_13 = unite(v1900_8,v1900_12);
        v1899_7_result = unite(v1899_7_result,v1900_13);
      }
      const Space v1899_7 = std::move(v1899_7_result);
      v1898_8 = compose(v1898_5,v1899_7);
    }
    const Space v1898_9 = intersect(constant_6,v1898_2);
    const Space v1898_10 = (has_head(v1898_9) ? constant_7 : Space{});
    Space v1898_12;
    if (!v1898_10.empty()) {
      const Path v1903_6 = concat_path(p0,v1897_11_head);
      Space v1903_11_result;
      for (int v1903_11_label = 1; v1903_11_label <= 2; ++v1903_11_label) {
        const Space v1903_11_tail = child(v1897_11_tail,v1903_11_label);
        if (v1903_11_tail.empty()) continue;
        const Path v1903_11_head{v1903_11_label};
        const Space v1904_2 = singleton(v1903_11_head);
        const Space v1904_3 = intersect(constant_6,v1904_2);
        const Space v1904_4 = (has_head(v1904_3) ? constant_7 : Space{});
        const Space v1904_5 = subtract(constant_0,v1904_4);
        Space v1904_8;
        if (!v1904_5.empty()) {
          const Path v1905_6 = concat_path(v1903_6,v1903_11_head);
          const Space v1905_7 = routine_247(c, v1905_6, v1903_11_tail);
          v1904_8 = compose(v1904_5,v1905_7);
        }
        const Space v1904_9 = intersect(constant_6,v1904_2);
        const Space v1904_10 = (has_head(v1904_9) ? constant_7 : Space{});
        Space v1904_12;
        if (!v1904_10.empty()) {
          const Path v1906_6 = concat_path(v1903_6,v1903_11_head);
          const Space v1906_11 = routine_104(c, v1906_6, v1903_11_tail);
          v1904_12 = compose(v1904_10,v1906_11);
        }
        const Space v1904_13 = unite(v1904_8,v1904_12);
        v1903_11_result = unite(v1903_11_result,v1904_13);
      }
      const Space v1903_11 = std::move(v1903_11_result);
      v1898_12 = compose(v1898_10,v1903_11);
    }
    const Space v1898_13 = unite(v1898_8,v1898_12);
    v1897_11_result = unite(v1897_11_result,v1898_13);
  }
  const Space v1897_11 = std::move(v1897_11_result);
  return v1897_11;
}

static Space routine_210(Context& c, const Path& p0, const Space& s0) {
  Space v1907_9_result;
  for (int v1907_9_label = 1; v1907_9_label <= 2; ++v1907_9_label) {
    const Space v1907_9_tail = child(s0,v1907_9_label);
    if (v1907_9_tail.empty()) continue;
    const Path v1907_9_head{v1907_9_label};
    const Space v1908_2 = singleton(v1907_9_head);
    const Space v1908_3 = intersect(constant_6,v1908_2);
    const Space v1908_4 = (has_head(v1908_3) ? constant_7 : Space{});
    const Space v1908_5 = subtract(constant_0,v1908_4);
    Space v1908_8;
    if (!v1908_5.empty()) {
      const Path v1909_6 = concat_path(p0,v1907_9_head);
      Space v1909_7_result;
      for (int v1909_7_label = 1; v1909_7_label <= 2; ++v1909_7_label) {
        const Space v1909_7_tail = child(v1907_9_tail,v1909_7_label);
        if (v1909_7_tail.empty()) continue;
        const Path v1909_7_head{v1909_7_label};
        const Space v1910_2 = singleton(v1909_7_head);
        const Space v1910_3 = intersect(constant_6,v1910_2);
        const Space v1910_4 = (has_head(v1910_3) ? constant_7 : Space{});
        const Space v1910_5 = subtract(constant_0,v1910_4);
        Space v1910_8;
        if (!v1910_5.empty()) {
          const Path v1911_6 = concat_path(v1909_6,v1909_7_head);
          const Space v1911_7 = routine_247(c, v1911_6, v1909_7_tail);
          v1910_8 = compose(v1910_5,v1911_7);
        }
        const Space v1910_9 = intersect(constant_6,v1910_2);
        const Space v1910_10 = (has_head(v1910_9) ? constant_7 : Space{});
        Space v1910_12;
        if (!v1910_10.empty()) {
          const Path v1912_6 = concat_path(v1909_6,v1909_7_head);
          const Space v1912_11 = routine_248(c, v1912_6, v1909_7_tail);
          v1910_12 = compose(v1910_10,v1912_11);
        }
        const Space v1910_13 = unite(v1910_8,v1910_12);
        v1909_7_result = unite(v1909_7_result,v1910_13);
      }
      const Space v1909_7 = std::move(v1909_7_result);
      v1908_8 = compose(v1908_5,v1909_7);
    }
    const Space v1908_9 = intersect(constant_6,v1908_2);
    const Space v1908_10 = (has_head(v1908_9) ? constant_7 : Space{});
    const Space v1908_11 = compose(v1908_10,constant_9);
    const Space v1908_12 = unite(v1908_8,v1908_11);
    v1907_9_result = unite(v1907_9_result,v1908_12);
  }
  const Space v1907_9 = std::move(v1907_9_result);
  return v1907_9;
}

static Space routine_211(Context& c, const Path& p0, const Space& s0) {
  Space v1913_11_result;
  for (int v1913_11_label = 1; v1913_11_label <= 2; ++v1913_11_label) {
    const Space v1913_11_tail = child(s0,v1913_11_label);
    if (v1913_11_tail.empty()) continue;
    const Path v1913_11_head{v1913_11_label};
    const Space v1914_2 = singleton(v1913_11_head);
    const Space v1914_3 = intersect(constant_6,v1914_2);
    const Space v1914_4 = (has_head(v1914_3) ? constant_7 : Space{});
    const Space v1914_5 = subtract(constant_0,v1914_4);
    Space v1914_8;
    if (!v1914_5.empty()) {
      const Path v1915_6 = concat_path(p0,v1913_11_head);
      Space v1915_7_result;
      for (int v1915_7_label = 1; v1915_7_label <= 2; ++v1915_7_label) {
        const Space v1915_7_tail = child(v1913_11_tail,v1915_7_label);
        if (v1915_7_tail.empty()) continue;
        const Path v1915_7_head{v1915_7_label};
        const Space v1916_2 = singleton(v1915_7_head);
        const Space v1916_3 = intersect(constant_6,v1916_2);
        const Space v1916_4 = (has_head(v1916_3) ? constant_7 : Space{});
        const Space v1916_5 = subtract(constant_0,v1916_4);
        Space v1916_8;
        if (!v1916_5.empty()) {
          const Path v1917_6 = concat_path(v1915_6,v1915_7_head);
          const Space v1917_7 = routine_249(c, v1917_6, v1915_7_tail);
          v1916_8 = compose(v1916_5,v1917_7);
        }
        const Space v1916_9 = intersect(constant_6,v1916_2);
        const Space v1916_10 = (has_head(v1916_9) ? constant_7 : Space{});
        Space v1916_12;
        if (!v1916_10.empty()) {
          const Path v1918_6 = concat_path(v1915_6,v1915_7_head);
          const Space v1918_11 = routine_250(c, v1918_6, v1915_7_tail);
          v1916_12 = compose(v1916_10,v1918_11);
        }
        const Space v1916_13 = unite(v1916_8,v1916_12);
        v1915_7_result = unite(v1915_7_result,v1916_13);
      }
      const Space v1915_7 = std::move(v1915_7_result);
      v1914_8 = compose(v1914_5,v1915_7);
    }
    const Space v1914_9 = intersect(constant_6,v1914_2);
    const Space v1914_10 = (has_head(v1914_9) ? constant_7 : Space{});
    Space v1914_12;
    if (!v1914_10.empty()) {
      const Path v1919_6 = concat_path(p0,v1913_11_head);
      Space v1919_11_result;
      for (int v1919_11_label = 1; v1919_11_label <= 2; ++v1919_11_label) {
        const Space v1919_11_tail = child(v1913_11_tail,v1919_11_label);
        if (v1919_11_tail.empty()) continue;
        const Path v1919_11_head{v1919_11_label};
        const Space v1920_2 = singleton(v1919_11_head);
        const Space v1920_3 = intersect(constant_6,v1920_2);
        const Space v1920_4 = (has_head(v1920_3) ? constant_7 : Space{});
        const Space v1920_5 = subtract(constant_0,v1920_4);
        Space v1920_8;
        if (!v1920_5.empty()) {
          const Path v1921_6 = concat_path(v1919_6,v1919_11_head);
          const Space v1921_7 = routine_249(c, v1921_6, v1919_11_tail);
          v1920_8 = compose(v1920_5,v1921_7);
        }
        const Space v1920_9 = intersect(constant_6,v1920_2);
        const Space v1920_10 = (has_head(v1920_9) ? constant_7 : Space{});
        Space v1920_12;
        if (!v1920_10.empty()) {
          const Path v1922_6 = concat_path(v1919_6,v1919_11_head);
          const Space v1922_11 = routine_107(c, v1922_6, v1919_11_tail);
          v1920_12 = compose(v1920_10,v1922_11);
        }
        const Space v1920_13 = unite(v1920_8,v1920_12);
        v1919_11_result = unite(v1919_11_result,v1920_13);
      }
      const Space v1919_11 = std::move(v1919_11_result);
      v1914_12 = compose(v1914_10,v1919_11);
    }
    const Space v1914_13 = unite(v1914_8,v1914_12);
    v1913_11_result = unite(v1913_11_result,v1914_13);
  }
  const Space v1913_11 = std::move(v1913_11_result);
  return v1913_11;
}

static Space routine_212(Context& c, const Path& p0, const Space& s0) {
  Space v1923_8_result;
  for (int v1923_8_label = 1; v1923_8_label <= 2; ++v1923_8_label) {
    const Space v1923_8_tail = child(s0,v1923_8_label);
    if (v1923_8_tail.empty()) continue;
    const Path v1923_8_head{v1923_8_label};
    const Space v1924_2 = singleton(v1923_8_head);
    const Space v1924_3 = intersect(constant_6,v1924_2);
    const Space v1924_4 = (has_head(v1924_3) ? constant_7 : Space{});
    const Space v1924_5 = subtract(constant_0,v1924_4);
    Space v1924_8;
    if (!v1924_5.empty()) {
      const Path v1925_6 = concat_path(p0,v1923_8_head);
      Space v1925_7_result;
      for (int v1925_7_label = 1; v1925_7_label <= 2; ++v1925_7_label) {
        const Space v1925_7_tail = child(v1923_8_tail,v1925_7_label);
        if (v1925_7_tail.empty()) continue;
        const Path v1925_7_head{v1925_7_label};
        const Space v1926_2 = singleton(v1925_7_head);
        const Space v1926_3 = intersect(constant_6,v1926_2);
        const Space v1926_4 = (has_head(v1926_3) ? constant_7 : Space{});
        const Space v1926_5 = subtract(constant_0,v1926_4);
        Space v1926_8;
        if (!v1926_5.empty()) {
          const Path v1927_6 = concat_path(v1925_6,v1925_7_head);
          const Space v1927_7 = routine_249(c, v1927_6, v1925_7_tail);
          v1926_8 = compose(v1926_5,v1927_7);
        }
        const Space v1926_9 = intersect(constant_6,v1926_2);
        const Space v1926_10 = (has_head(v1926_9) ? constant_7 : Space{});
        Space v1926_12;
        if (!v1926_10.empty()) {
          const Path v1928_6 = concat_path(v1925_6,v1925_7_head);
          const Space v1928_11 = routine_250(c, v1928_6, v1925_7_tail);
          v1926_12 = compose(v1926_10,v1928_11);
        }
        const Space v1926_13 = unite(v1926_8,v1926_12);
        v1925_7_result = unite(v1925_7_result,v1926_13);
      }
      const Space v1925_7 = std::move(v1925_7_result);
      v1924_8 = compose(v1924_5,v1925_7);
    }
    const Space v1924_9 = intersect(constant_6,v1924_2);
    const Space v1924_10 = (has_head(v1924_9) ? constant_7 : Space{});
    const Space v1924_11 = compose(v1924_10,v1923_8_tail);
    const Space v1924_12 = unite(v1924_8,v1924_11);
    v1923_8_result = unite(v1923_8_result,v1924_12);
  }
  const Space v1923_8 = std::move(v1923_8_result);
  return v1923_8;
}

static Space routine_213(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v1929_4_result;
  for (int v1929_4_label = 1; v1929_4_label <= 2; ++v1929_4_label) {
    const Space v1929_4_tail = child(s0,v1929_4_label);
    if (v1929_4_tail.empty()) continue;
    const Path v1929_4_head{v1929_4_label};
    const Space v1930_2 = Space{};
    v1929_4_result = unite(v1929_4_result,v1930_2);
  }
  const Space v1929_4 = std::move(v1929_4_result);
  return v1929_4;
}

static Space routine_214(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v1931_6 = unwrap(s1,constant_8);
  Space v1931_16_result;
  for (int v1931_16_label = 1; v1931_16_label <= 2; ++v1931_16_label) {
    const Space v1931_16_tail = child(s0,v1931_16_label);
    if (v1931_16_tail.empty()) continue;
    const Path v1931_16_head{v1931_16_label};
    const Space v1932_2 = singleton(v1931_16_head);
    const Space v1932_3 = intersect(constant_6,v1932_2);
    const Space v1932_4 = (has_head(v1932_3) ? constant_7 : Space{});
    Space v1932_17;
    if (!v1932_4.empty()) {
      const Path v1933_5 = concat_path(p0,v1931_16_head);
      const Path v1933_6 = concat_path(p1,v1933_5);
      const Space v1933_7 = routine_29(c, v1933_6);
      const Space v1933_8 = intersect(v1931_6,v1933_7);
      const Space v1933_9 = routine_30(c, v1933_8);
      Space v1933_10_result;
      for (int v1933_10_label = 1; v1933_10_label <= 2; ++v1933_10_label) {
        const Space v1933_10_tail = child(v1933_9,v1933_10_label);
        if (v1933_10_tail.empty()) continue;
        const Path v1933_10_head{v1933_10_label};
        const Space v1934_2 = singleton(v1933_10_head);
        const Space v1934_3 = intersect(constant_6,v1934_2);
        const Space v1934_4 = (has_head(v1934_3) ? constant_7 : Space{});
        const Space v1934_5 = subtract(constant_0,v1934_4);
        Space v1934_7;
        if (!v1934_5.empty()) {
          const Space v1935_6 = routine_31(c, v1933_10_head, v1933_10_tail);
          v1934_7 = compose(v1934_5,v1935_6);
        }
        const Space v1934_8 = intersect(constant_6,v1934_2);
        const Space v1934_9 = (has_head(v1934_8) ? constant_7 : Space{});
        Space v1934_11;
        if (!v1934_9.empty()) {
          const Space v1936_10 = routine_32(c, v1933_10_head, v1933_10_tail);
          v1934_11 = compose(v1934_9,v1936_10);
        }
        const Space v1934_12 = unite(v1934_7,v1934_11);
        v1933_10_result = unite(v1933_10_result,v1934_12);
      }
      const Space v1933_10 = std::move(v1933_10_result);
      const Space v1933_11 = routine_33(c, v1933_8);
      Space v1933_12_result;
      for (int v1933_12_label = 1; v1933_12_label <= 2; ++v1933_12_label) {
        const Space v1933_12_tail = child(v1933_11,v1933_12_label);
        if (v1933_12_tail.empty()) continue;
        const Path v1933_12_head{v1933_12_label};
        const Space v1937_2 = singleton(v1933_12_head);
        const Space v1937_3 = intersect(constant_6,v1937_2);
        const Space v1937_4 = (has_head(v1937_3) ? constant_7 : Space{});
        const Space v1937_5 = subtract(constant_0,v1937_4);
        Space v1937_7;
        if (!v1937_5.empty()) {
          const Space v1938_6 = routine_34(c, v1933_12_head, v1933_12_tail);
          v1937_7 = compose(v1937_5,v1938_6);
        }
        const Space v1937_8 = intersect(constant_6,v1937_2);
        const Space v1937_9 = (has_head(v1937_8) ? constant_7 : Space{});
        Space v1937_11;
        if (!v1937_9.empty()) {
          const Space v1939_10 = routine_35(c, v1933_12_head, v1933_12_tail);
          v1937_11 = compose(v1937_9,v1939_10);
        }
        const Space v1937_12 = unite(v1937_7,v1937_11);
        v1933_12_result = unite(v1933_12_result,v1937_12);
      }
      const Space v1933_12 = std::move(v1933_12_result);
      const Space v1933_13 = subtract(v1933_10,v1933_12);
      const Space v1933_14 = singleton(v1933_6);
      const Space v1933_15 = compose(v1933_13,v1933_14);
      Space v1933_16_result;
      for (int v1933_16_label = 1; v1933_16_label <= 2; ++v1933_16_label) {
        const Space v1933_16_tail = child(v1933_15,v1933_16_label);
        if (v1933_16_tail.empty()) continue;
        const Path v1933_16_head{v1933_16_label};
        const Space v1940_2 = singleton(v1933_16_head);
        const Space v1940_3 = intersect(constant_6,v1940_2);
        const Space v1940_4 = (has_head(v1940_3) ? constant_7 : Space{});
        const Space v1940_5 = subtract(constant_0,v1940_4);
        Space v1940_7;
        if (!v1940_5.empty()) {
          const Space v1941_6 = routine_36(c, v1933_16_head, v1933_16_tail);
          v1940_7 = compose(v1940_5,v1941_6);
        }
        const Space v1940_8 = intersect(constant_6,v1940_2);
        const Space v1940_9 = (has_head(v1940_8) ? constant_7 : Space{});
        Space v1940_11;
        if (!v1940_9.empty()) {
          const Space v1942_10 = routine_37(c, v1933_16_head, v1933_16_tail);
          v1940_11 = compose(v1940_9,v1942_10);
        }
        const Space v1940_12 = unite(v1940_7,v1940_11);
        v1933_16_result = unite(v1933_16_result,v1940_12);
      }
      const Space v1933_16 = std::move(v1933_16_result);
      v1932_17 = compose(v1932_4,v1933_16);
    }
    v1931_16_result = unite(v1931_16_result,v1932_17);
  }
  const Space v1931_16 = std::move(v1931_16_result);
  return v1931_16;
}

static Space routine_215(Context& c, const Path& p0, const Space& s0) {
  Space v1943_11_result;
  for (int v1943_11_label = 1; v1943_11_label <= 2; ++v1943_11_label) {
    const Space v1943_11_tail = child(s0,v1943_11_label);
    if (v1943_11_tail.empty()) continue;
    const Path v1943_11_head{v1943_11_label};
    const Space v1944_2 = singleton(v1943_11_head);
    const Space v1944_3 = intersect(constant_6,v1944_2);
    const Space v1944_4 = (has_head(v1944_3) ? constant_7 : Space{});
    const Space v1944_5 = subtract(constant_0,v1944_4);
    Space v1944_8;
    if (!v1944_5.empty()) {
      const Path v1945_6 = concat_path(p0,v1943_11_head);
      Space v1945_7_result;
      for (int v1945_7_label = 1; v1945_7_label <= 2; ++v1945_7_label) {
        const Space v1945_7_tail = child(v1943_11_tail,v1945_7_label);
        if (v1945_7_tail.empty()) continue;
        const Path v1945_7_head{v1945_7_label};
        const Space v1946_2 = singleton(v1945_7_head);
        const Space v1946_3 = intersect(constant_6,v1946_2);
        const Space v1946_4 = (has_head(v1946_3) ? constant_7 : Space{});
        const Space v1946_5 = subtract(constant_0,v1946_4);
        Space v1946_8;
        if (!v1946_5.empty()) {
          const Path v1947_6 = concat_path(v1945_6,v1945_7_head);
          const Space v1947_7 = routine_251(c, v1947_6, v1945_7_tail);
          v1946_8 = compose(v1946_5,v1947_7);
        }
        const Space v1946_9 = intersect(constant_6,v1946_2);
        const Space v1946_10 = (has_head(v1946_9) ? constant_7 : Space{});
        Space v1946_12;
        if (!v1946_10.empty()) {
          const Path v1948_6 = concat_path(v1945_6,v1945_7_head);
          const Space v1948_11 = routine_252(c, v1948_6, v1945_7_tail);
          v1946_12 = compose(v1946_10,v1948_11);
        }
        const Space v1946_13 = unite(v1946_8,v1946_12);
        v1945_7_result = unite(v1945_7_result,v1946_13);
      }
      const Space v1945_7 = std::move(v1945_7_result);
      v1944_8 = compose(v1944_5,v1945_7);
    }
    const Space v1944_9 = intersect(constant_6,v1944_2);
    const Space v1944_10 = (has_head(v1944_9) ? constant_7 : Space{});
    Space v1944_12;
    if (!v1944_10.empty()) {
      const Path v1949_6 = concat_path(p0,v1943_11_head);
      Space v1949_11_result;
      for (int v1949_11_label = 1; v1949_11_label <= 2; ++v1949_11_label) {
        const Space v1949_11_tail = child(v1943_11_tail,v1949_11_label);
        if (v1949_11_tail.empty()) continue;
        const Path v1949_11_head{v1949_11_label};
        const Space v1950_2 = singleton(v1949_11_head);
        const Space v1950_3 = intersect(constant_6,v1950_2);
        const Space v1950_4 = (has_head(v1950_3) ? constant_7 : Space{});
        const Space v1950_5 = subtract(constant_0,v1950_4);
        Space v1950_8;
        if (!v1950_5.empty()) {
          const Path v1951_6 = concat_path(v1949_6,v1949_11_head);
          const Space v1951_7 = routine_251(c, v1951_6, v1949_11_tail);
          v1950_8 = compose(v1950_5,v1951_7);
        }
        const Space v1950_9 = intersect(constant_6,v1950_2);
        const Space v1950_10 = (has_head(v1950_9) ? constant_7 : Space{});
        Space v1950_12;
        if (!v1950_10.empty()) {
          const Path v1952_6 = concat_path(v1949_6,v1949_11_head);
          const Space v1952_11 = routine_80(c, v1952_6, v1949_11_tail);
          v1950_12 = compose(v1950_10,v1952_11);
        }
        const Space v1950_13 = unite(v1950_8,v1950_12);
        v1949_11_result = unite(v1949_11_result,v1950_13);
      }
      const Space v1949_11 = std::move(v1949_11_result);
      v1944_12 = compose(v1944_10,v1949_11);
    }
    const Space v1944_13 = unite(v1944_8,v1944_12);
    v1943_11_result = unite(v1943_11_result,v1944_13);
  }
  const Space v1943_11 = std::move(v1943_11_result);
  return v1943_11;
}

static Space routine_216(Context& c, const Path& p0, const Space& s0) {
  Space v1953_11_result;
  for (int v1953_11_label = 1; v1953_11_label <= 2; ++v1953_11_label) {
    const Space v1953_11_tail = child(s0,v1953_11_label);
    if (v1953_11_tail.empty()) continue;
    const Path v1953_11_head{v1953_11_label};
    const Space v1954_2 = singleton(v1953_11_head);
    const Space v1954_3 = intersect(constant_6,v1954_2);
    const Space v1954_4 = (has_head(v1954_3) ? constant_7 : Space{});
    const Space v1954_5 = subtract(constant_0,v1954_4);
    Space v1954_8;
    if (!v1954_5.empty()) {
      const Path v1955_6 = concat_path(p0,v1953_11_head);
      Space v1955_7_result;
      for (int v1955_7_label = 1; v1955_7_label <= 2; ++v1955_7_label) {
        const Space v1955_7_tail = child(v1953_11_tail,v1955_7_label);
        if (v1955_7_tail.empty()) continue;
        const Path v1955_7_head{v1955_7_label};
        const Space v1956_2 = singleton(v1955_7_head);
        const Space v1956_3 = intersect(constant_6,v1956_2);
        const Space v1956_4 = (has_head(v1956_3) ? constant_7 : Space{});
        const Space v1956_5 = subtract(constant_0,v1956_4);
        Space v1956_8;
        if (!v1956_5.empty()) {
          const Path v1957_6 = concat_path(v1955_6,v1955_7_head);
          const Space v1957_7 = routine_251(c, v1957_6, v1955_7_tail);
          v1956_8 = compose(v1956_5,v1957_7);
        }
        const Space v1956_9 = intersect(constant_6,v1956_2);
        const Space v1956_10 = (has_head(v1956_9) ? constant_7 : Space{});
        Space v1956_12;
        if (!v1956_10.empty()) {
          const Path v1958_6 = concat_path(v1955_6,v1955_7_head);
          const Space v1958_11 = routine_252(c, v1958_6, v1955_7_tail);
          v1956_12 = compose(v1956_10,v1958_11);
        }
        const Space v1956_13 = unite(v1956_8,v1956_12);
        v1955_7_result = unite(v1955_7_result,v1956_13);
      }
      const Space v1955_7 = std::move(v1955_7_result);
      v1954_8 = compose(v1954_5,v1955_7);
    }
    const Space v1954_9 = intersect(constant_6,v1954_2);
    const Space v1954_10 = (has_head(v1954_9) ? constant_7 : Space{});
    Space v1954_12;
    if (!v1954_10.empty()) {
      const Path v1959_6 = concat_path(p0,v1953_11_head);
      Space v1959_11_result;
      for (int v1959_11_label = 1; v1959_11_label <= 2; ++v1959_11_label) {
        const Space v1959_11_tail = child(v1953_11_tail,v1959_11_label);
        if (v1959_11_tail.empty()) continue;
        const Path v1959_11_head{v1959_11_label};
        const Space v1960_2 = singleton(v1959_11_head);
        const Space v1960_3 = intersect(constant_6,v1960_2);
        const Space v1960_4 = (has_head(v1960_3) ? constant_7 : Space{});
        const Space v1960_5 = subtract(constant_0,v1960_4);
        Space v1960_7;
        if (!v1960_5.empty()) {
          const Space v1961_6 = routine_122(c, v1959_11_head, v1959_6, v1959_11_tail);
          v1960_7 = compose(v1960_5,v1961_6);
        }
        const Space v1960_8 = intersect(constant_6,v1960_2);
        const Space v1960_9 = (has_head(v1960_8) ? constant_7 : Space{});
        Space v1960_11;
        if (!v1960_9.empty()) {
          const Space v1962_10 = routine_123(c, v1959_11_head, v1959_6, v1959_11_tail);
          v1960_11 = compose(v1960_9,v1962_10);
        }
        const Space v1960_12 = unite(v1960_7,v1960_11);
        v1959_11_result = unite(v1959_11_result,v1960_12);
      }
      const Space v1959_11 = std::move(v1959_11_result);
      v1954_12 = compose(v1954_10,v1959_11);
    }
    const Space v1954_13 = unite(v1954_8,v1954_12);
    v1953_11_result = unite(v1953_11_result,v1954_13);
  }
  const Space v1953_11 = std::move(v1953_11_result);
  return v1953_11;
}

static Space routine_217(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v1963_12_result;
  for (int v1963_12_label = 1; v1963_12_label <= 2; ++v1963_12_label) {
    const Space v1963_12_tail = child(s0,v1963_12_label);
    if (v1963_12_tail.empty()) continue;
    const Path v1963_12_head{v1963_12_label};
    const Space v1964_2 = singleton(v1963_12_head);
    const Space v1964_3 = intersect(constant_6,v1964_2);
    const Space v1964_4 = (has_head(v1964_3) ? constant_7 : Space{});
    const Space v1964_5 = subtract(constant_0,v1964_4);
    Space v1964_8;
    if (!v1964_5.empty()) {
      const Path v1965_6 = concat_path(p0,v1963_12_head);
      Space v1965_7_result;
      for (int v1965_7_label = 1; v1965_7_label <= 2; ++v1965_7_label) {
        const Space v1965_7_tail = child(v1963_12_tail,v1965_7_label);
        if (v1965_7_tail.empty()) continue;
        const Path v1965_7_head{v1965_7_label};
        const Space v1966_2 = singleton(v1965_7_head);
        const Space v1966_3 = intersect(constant_6,v1966_2);
        const Space v1966_4 = (has_head(v1966_3) ? constant_7 : Space{});
        const Space v1966_5 = subtract(constant_0,v1966_4);
        Space v1966_8;
        if (!v1966_5.empty()) {
          const Path v1967_6 = concat_path(v1965_6,v1965_7_head);
          const Space v1967_7 = routine_253(c, v1967_6, p1, v1965_7_tail);
          v1966_8 = compose(v1966_5,v1967_7);
        }
        const Space v1966_9 = intersect(constant_6,v1966_2);
        const Space v1966_10 = (has_head(v1966_9) ? constant_7 : Space{});
        Space v1966_12;
        if (!v1966_10.empty()) {
          const Path v1968_6 = concat_path(v1965_6,v1965_7_head);
          const Space v1968_11 = routine_254(c, v1968_6, p1, v1965_7_tail);
          v1966_12 = compose(v1966_10,v1968_11);
        }
        const Space v1966_13 = unite(v1966_8,v1966_12);
        v1965_7_result = unite(v1965_7_result,v1966_13);
      }
      const Space v1965_7 = std::move(v1965_7_result);
      v1964_8 = compose(v1964_5,v1965_7);
    }
    const Space v1964_9 = intersect(constant_6,v1964_2);
    const Space v1964_10 = (has_head(v1964_9) ? constant_7 : Space{});
    Space v1964_12;
    if (!v1964_10.empty()) {
      const Path v1969_6 = concat_path(p0,v1963_12_head);
      Space v1969_11_result;
      for (int v1969_11_label = 1; v1969_11_label <= 2; ++v1969_11_label) {
        const Space v1969_11_tail = child(v1963_12_tail,v1969_11_label);
        if (v1969_11_tail.empty()) continue;
        const Path v1969_11_head{v1969_11_label};
        const Space v1970_2 = singleton(v1969_11_head);
        const Space v1970_3 = intersect(constant_6,v1970_2);
        const Space v1970_4 = (has_head(v1970_3) ? constant_7 : Space{});
        const Space v1970_5 = subtract(constant_0,v1970_4);
        Space v1970_8;
        if (!v1970_5.empty()) {
          const Path v1971_6 = concat_path(v1969_6,v1969_11_head);
          const Space v1971_7 = routine_253(c, v1971_6, p1, v1969_11_tail);
          v1970_8 = compose(v1970_5,v1971_7);
        }
        const Space v1970_9 = intersect(constant_6,v1970_2);
        const Space v1970_10 = (has_head(v1970_9) ? constant_7 : Space{});
        Space v1970_12;
        if (!v1970_10.empty()) {
          const Path v1972_6 = concat_path(v1969_6,v1969_11_head);
          const Space v1972_11 = routine_137(c, v1972_6, p1, v1969_11_tail);
          v1970_12 = compose(v1970_10,v1972_11);
        }
        const Space v1970_13 = unite(v1970_8,v1970_12);
        v1969_11_result = unite(v1969_11_result,v1970_13);
      }
      const Space v1969_11 = std::move(v1969_11_result);
      v1964_12 = compose(v1964_10,v1969_11);
    }
    const Space v1964_13 = unite(v1964_8,v1964_12);
    v1963_12_result = unite(v1963_12_result,v1964_13);
  }
  const Space v1963_12 = std::move(v1963_12_result);
  return v1963_12;
}

static Space routine_218(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v1973_7 = unwrap(constant_12,p1);
  const Space v1973_9 = unwrap(constant_12,p0);
  Space v1973_13_result;
  for (int v1973_13_label = 1; v1973_13_label <= 2; ++v1973_13_label) {
    const Space v1973_13_tail = child(s0,v1973_13_label);
    if (v1973_13_tail.empty()) continue;
    const Path v1973_13_head{v1973_13_label};
    const Space v1974_2 = singleton(v1973_13_head);
    const Space v1974_3 = intersect(constant_6,v1974_2);
    const Space v1974_4 = (has_head(v1974_3) ? constant_7 : Space{});
    const Space v1974_5 = subtract(constant_0,v1974_4);
    Space v1974_8;
    if (!v1974_5.empty()) {
      const Path v1975_6 = concat_path(p0,v1973_13_head);
      Space v1975_7_result;
      for (int v1975_7_label = 1; v1975_7_label <= 2; ++v1975_7_label) {
        const Space v1975_7_tail = child(v1973_13_tail,v1975_7_label);
        if (v1975_7_tail.empty()) continue;
        const Path v1975_7_head{v1975_7_label};
        const Space v1976_2 = singleton(v1975_7_head);
        const Space v1976_3 = intersect(constant_6,v1976_2);
        const Space v1976_4 = (has_head(v1976_3) ? constant_7 : Space{});
        const Space v1976_5 = subtract(constant_0,v1976_4);
        Space v1976_8;
        if (!v1976_5.empty()) {
          const Path v1977_6 = concat_path(v1975_6,v1975_7_head);
          const Space v1977_7 = routine_253(c, v1977_6, p1, v1975_7_tail);
          v1976_8 = compose(v1976_5,v1977_7);
        }
        const Space v1976_9 = intersect(constant_6,v1976_2);
        const Space v1976_10 = (has_head(v1976_9) ? constant_7 : Space{});
        Space v1976_12;
        if (!v1976_10.empty()) {
          const Path v1978_6 = concat_path(v1975_6,v1975_7_head);
          const Space v1978_11 = routine_254(c, v1978_6, p1, v1975_7_tail);
          v1976_12 = compose(v1976_10,v1978_11);
        }
        const Space v1976_13 = unite(v1976_8,v1976_12);
        v1975_7_result = unite(v1975_7_result,v1976_13);
      }
      const Space v1975_7 = std::move(v1975_7_result);
      v1974_8 = compose(v1974_5,v1975_7);
    }
    const Space v1974_9 = intersect(constant_6,v1974_2);
    const Space v1974_10 = (has_head(v1974_9) ? constant_7 : Space{});
    const Space v1974_11 = unwrap(v1973_9,v1973_13_head);
    const Space v1974_12 = compose(v1973_7,v1974_11);
    const Path v1979_6 = concat_path(p0,v1973_13_head);
    const Path v1974_13 = concat_path(p1,v1979_6);
    const Space v1974_14 = singleton(v1974_13);
    const Space v1974_15 = subtract(v1974_12,v1974_14);
    const Space v1974_16 = compose(v1974_10,v1974_15);
    const Space v1974_17 = unite(v1974_8,v1974_16);
    v1973_13_result = unite(v1973_13_result,v1974_17);
  }
  const Space v1973_13 = std::move(v1973_13_result);
  return v1973_13;
}

static Space routine_219(Context& c, const Path& p0, const Space& s0) {
  Space v1980_11_result;
  for (int v1980_11_label = 1; v1980_11_label <= 2; ++v1980_11_label) {
    const Space v1980_11_tail = child(s0,v1980_11_label);
    if (v1980_11_tail.empty()) continue;
    const Path v1980_11_head{v1980_11_label};
    const Space v1981_2 = singleton(v1980_11_head);
    const Space v1981_3 = intersect(constant_6,v1981_2);
    const Space v1981_4 = (has_head(v1981_3) ? constant_7 : Space{});
    const Space v1981_5 = subtract(constant_0,v1981_4);
    Space v1981_8;
    if (!v1981_5.empty()) {
      const Path v1982_6 = concat_path(p0,v1980_11_head);
      Space v1982_7_result;
      for (int v1982_7_label = 1; v1982_7_label <= 2; ++v1982_7_label) {
        const Space v1982_7_tail = child(v1980_11_tail,v1982_7_label);
        if (v1982_7_tail.empty()) continue;
        const Path v1982_7_head{v1982_7_label};
        const Space v1983_2 = singleton(v1982_7_head);
        const Space v1983_3 = intersect(constant_6,v1983_2);
        const Space v1983_4 = (has_head(v1983_3) ? constant_7 : Space{});
        const Space v1983_5 = subtract(constant_0,v1983_4);
        Space v1983_8;
        if (!v1983_5.empty()) {
          const Path v1984_6 = concat_path(v1982_6,v1982_7_head);
          const Space v1984_7 = routine_255(c, v1984_6, v1982_7_tail);
          v1983_8 = compose(v1983_5,v1984_7);
        }
        const Space v1983_9 = intersect(constant_6,v1983_2);
        const Space v1983_10 = (has_head(v1983_9) ? constant_7 : Space{});
        Space v1983_12;
        if (!v1983_10.empty()) {
          const Path v1985_6 = concat_path(v1982_6,v1982_7_head);
          const Space v1985_11 = routine_256(c, v1985_6, v1982_7_tail);
          v1983_12 = compose(v1983_10,v1985_11);
        }
        const Space v1983_13 = unite(v1983_8,v1983_12);
        v1982_7_result = unite(v1982_7_result,v1983_13);
      }
      const Space v1982_7 = std::move(v1982_7_result);
      v1981_8 = compose(v1981_5,v1982_7);
    }
    const Space v1981_9 = intersect(constant_6,v1981_2);
    const Space v1981_10 = (has_head(v1981_9) ? constant_7 : Space{});
    Space v1981_12;
    if (!v1981_10.empty()) {
      const Path v1986_6 = concat_path(p0,v1980_11_head);
      Space v1986_11_result;
      for (int v1986_11_label = 1; v1986_11_label <= 2; ++v1986_11_label) {
        const Space v1986_11_tail = child(v1980_11_tail,v1986_11_label);
        if (v1986_11_tail.empty()) continue;
        const Path v1986_11_head{v1986_11_label};
        const Space v1987_2 = singleton(v1986_11_head);
        const Space v1987_3 = intersect(constant_6,v1987_2);
        const Space v1987_4 = (has_head(v1987_3) ? constant_7 : Space{});
        const Space v1987_5 = subtract(constant_0,v1987_4);
        Space v1987_8;
        if (!v1987_5.empty()) {
          const Path v1988_6 = concat_path(v1986_6,v1986_11_head);
          const Space v1988_7 = routine_255(c, v1988_6, v1986_11_tail);
          v1987_8 = compose(v1987_5,v1988_7);
        }
        const Space v1987_9 = intersect(constant_6,v1987_2);
        const Space v1987_10 = (has_head(v1987_9) ? constant_7 : Space{});
        Space v1987_12;
        if (!v1987_10.empty()) {
          const Path v1989_6 = concat_path(v1986_6,v1986_11_head);
          const Space v1989_11 = routine_69(c, v1989_6, v1986_11_tail);
          v1987_12 = compose(v1987_10,v1989_11);
        }
        const Space v1987_13 = unite(v1987_8,v1987_12);
        v1986_11_result = unite(v1986_11_result,v1987_13);
      }
      const Space v1986_11 = std::move(v1986_11_result);
      v1981_12 = compose(v1981_10,v1986_11);
    }
    const Space v1981_13 = unite(v1981_8,v1981_12);
    v1980_11_result = unite(v1980_11_result,v1981_13);
  }
  const Space v1980_11 = std::move(v1980_11_result);
  return v1980_11;
}

static Space routine_220(Context& c, const Path& p0, const Space& s0) {
  Space v1990_9_result;
  for (int v1990_9_label = 1; v1990_9_label <= 2; ++v1990_9_label) {
    const Space v1990_9_tail = child(s0,v1990_9_label);
    if (v1990_9_tail.empty()) continue;
    const Path v1990_9_head{v1990_9_label};
    const Space v1991_2 = singleton(v1990_9_head);
    const Space v1991_3 = intersect(constant_6,v1991_2);
    const Space v1991_4 = (has_head(v1991_3) ? constant_7 : Space{});
    const Space v1991_5 = subtract(constant_0,v1991_4);
    Space v1991_8;
    if (!v1991_5.empty()) {
      const Path v1992_6 = concat_path(p0,v1990_9_head);
      Space v1992_7_result;
      for (int v1992_7_label = 1; v1992_7_label <= 2; ++v1992_7_label) {
        const Space v1992_7_tail = child(v1990_9_tail,v1992_7_label);
        if (v1992_7_tail.empty()) continue;
        const Path v1992_7_head{v1992_7_label};
        const Space v1993_2 = singleton(v1992_7_head);
        const Space v1993_3 = intersect(constant_6,v1993_2);
        const Space v1993_4 = (has_head(v1993_3) ? constant_7 : Space{});
        const Space v1993_5 = subtract(constant_0,v1993_4);
        Space v1993_8;
        if (!v1993_5.empty()) {
          const Path v1994_6 = concat_path(v1992_6,v1992_7_head);
          const Space v1994_7 = routine_255(c, v1994_6, v1992_7_tail);
          v1993_8 = compose(v1993_5,v1994_7);
        }
        const Space v1993_9 = intersect(constant_6,v1993_2);
        const Space v1993_10 = (has_head(v1993_9) ? constant_7 : Space{});
        Space v1993_12;
        if (!v1993_10.empty()) {
          const Path v1995_6 = concat_path(v1992_6,v1992_7_head);
          const Space v1995_11 = routine_256(c, v1995_6, v1992_7_tail);
          v1993_12 = compose(v1993_10,v1995_11);
        }
        const Space v1993_13 = unite(v1993_8,v1993_12);
        v1992_7_result = unite(v1992_7_result,v1993_13);
      }
      const Space v1992_7 = std::move(v1992_7_result);
      v1991_8 = compose(v1991_5,v1992_7);
    }
    const Space v1991_9 = intersect(constant_6,v1991_2);
    const Space v1991_10 = (has_head(v1991_9) ? constant_7 : Space{});
    const Space v1991_11 = compose(v1991_10,constant_9);
    const Space v1991_12 = unite(v1991_8,v1991_11);
    v1990_9_result = unite(v1990_9_result,v1991_12);
  }
  const Space v1990_9 = std::move(v1990_9_result);
  return v1990_9;
}

static Space routine_221(Context& c, const Path& p0, const Space& s0) {
  Space v1996_11_result;
  for (int v1996_11_label = 1; v1996_11_label <= 2; ++v1996_11_label) {
    const Space v1996_11_tail = child(s0,v1996_11_label);
    if (v1996_11_tail.empty()) continue;
    const Path v1996_11_head{v1996_11_label};
    const Space v1997_2 = singleton(v1996_11_head);
    const Space v1997_3 = intersect(constant_6,v1997_2);
    const Space v1997_4 = (has_head(v1997_3) ? constant_7 : Space{});
    const Space v1997_5 = subtract(constant_0,v1997_4);
    Space v1997_8;
    if (!v1997_5.empty()) {
      const Path v1998_6 = concat_path(p0,v1996_11_head);
      Space v1998_7_result;
      for (int v1998_7_label = 1; v1998_7_label <= 2; ++v1998_7_label) {
        const Space v1998_7_tail = child(v1996_11_tail,v1998_7_label);
        if (v1998_7_tail.empty()) continue;
        const Path v1998_7_head{v1998_7_label};
        const Space v1999_2 = singleton(v1998_7_head);
        const Space v1999_3 = intersect(constant_6,v1999_2);
        const Space v1999_4 = (has_head(v1999_3) ? constant_7 : Space{});
        const Space v1999_5 = subtract(constant_0,v1999_4);
        Space v1999_8;
        if (!v1999_5.empty()) {
          const Path v2000_6 = concat_path(v1998_6,v1998_7_head);
          const Space v2000_7 = routine_257(c, v2000_6, v1998_7_tail);
          v1999_8 = compose(v1999_5,v2000_7);
        }
        const Space v1999_9 = intersect(constant_6,v1999_2);
        const Space v1999_10 = (has_head(v1999_9) ? constant_7 : Space{});
        Space v1999_12;
        if (!v1999_10.empty()) {
          const Path v2001_6 = concat_path(v1998_6,v1998_7_head);
          const Space v2001_11 = routine_258(c, v2001_6, v1998_7_tail);
          v1999_12 = compose(v1999_10,v2001_11);
        }
        const Space v1999_13 = unite(v1999_8,v1999_12);
        v1998_7_result = unite(v1998_7_result,v1999_13);
      }
      const Space v1998_7 = std::move(v1998_7_result);
      v1997_8 = compose(v1997_5,v1998_7);
    }
    const Space v1997_9 = intersect(constant_6,v1997_2);
    const Space v1997_10 = (has_head(v1997_9) ? constant_7 : Space{});
    Space v1997_12;
    if (!v1997_10.empty()) {
      const Path v2002_6 = concat_path(p0,v1996_11_head);
      Space v2002_11_result;
      for (int v2002_11_label = 1; v2002_11_label <= 2; ++v2002_11_label) {
        const Space v2002_11_tail = child(v1996_11_tail,v2002_11_label);
        if (v2002_11_tail.empty()) continue;
        const Path v2002_11_head{v2002_11_label};
        const Space v2003_2 = singleton(v2002_11_head);
        const Space v2003_3 = intersect(constant_6,v2003_2);
        const Space v2003_4 = (has_head(v2003_3) ? constant_7 : Space{});
        const Space v2003_5 = subtract(constant_0,v2003_4);
        Space v2003_8;
        if (!v2003_5.empty()) {
          const Path v2004_6 = concat_path(v2002_6,v2002_11_head);
          const Space v2004_7 = routine_257(c, v2004_6, v2002_11_tail);
          v2003_8 = compose(v2003_5,v2004_7);
        }
        const Space v2003_9 = intersect(constant_6,v2003_2);
        const Space v2003_10 = (has_head(v2003_9) ? constant_7 : Space{});
        Space v2003_12;
        if (!v2003_10.empty()) {
          const Path v2005_6 = concat_path(v2002_6,v2002_11_head);
          const Space v2005_11 = routine_72(c, v2005_6, v2002_11_tail);
          v2003_12 = compose(v2003_10,v2005_11);
        }
        const Space v2003_13 = unite(v2003_8,v2003_12);
        v2002_11_result = unite(v2002_11_result,v2003_13);
      }
      const Space v2002_11 = std::move(v2002_11_result);
      v1997_12 = compose(v1997_10,v2002_11);
    }
    const Space v1997_13 = unite(v1997_8,v1997_12);
    v1996_11_result = unite(v1996_11_result,v1997_13);
  }
  const Space v1996_11 = std::move(v1996_11_result);
  return v1996_11;
}

static Space routine_222(Context& c, const Path& p0, const Space& s0) {
  Space v2006_9_result;
  for (int v2006_9_label = 1; v2006_9_label <= 2; ++v2006_9_label) {
    const Space v2006_9_tail = child(s0,v2006_9_label);
    if (v2006_9_tail.empty()) continue;
    const Path v2006_9_head{v2006_9_label};
    const Space v2007_2 = singleton(v2006_9_head);
    const Space v2007_3 = intersect(constant_6,v2007_2);
    const Space v2007_4 = (has_head(v2007_3) ? constant_7 : Space{});
    const Space v2007_5 = subtract(constant_0,v2007_4);
    Space v2007_8;
    if (!v2007_5.empty()) {
      const Path v2008_6 = concat_path(p0,v2006_9_head);
      Space v2008_7_result;
      for (int v2008_7_label = 1; v2008_7_label <= 2; ++v2008_7_label) {
        const Space v2008_7_tail = child(v2006_9_tail,v2008_7_label);
        if (v2008_7_tail.empty()) continue;
        const Path v2008_7_head{v2008_7_label};
        const Space v2009_2 = singleton(v2008_7_head);
        const Space v2009_3 = intersect(constant_6,v2009_2);
        const Space v2009_4 = (has_head(v2009_3) ? constant_7 : Space{});
        const Space v2009_5 = subtract(constant_0,v2009_4);
        Space v2009_8;
        if (!v2009_5.empty()) {
          const Path v2010_6 = concat_path(v2008_6,v2008_7_head);
          const Space v2010_7 = routine_257(c, v2010_6, v2008_7_tail);
          v2009_8 = compose(v2009_5,v2010_7);
        }
        const Space v2009_9 = intersect(constant_6,v2009_2);
        const Space v2009_10 = (has_head(v2009_9) ? constant_7 : Space{});
        Space v2009_12;
        if (!v2009_10.empty()) {
          const Path v2011_6 = concat_path(v2008_6,v2008_7_head);
          const Space v2011_11 = routine_258(c, v2011_6, v2008_7_tail);
          v2009_12 = compose(v2009_10,v2011_11);
        }
        const Space v2009_13 = unite(v2009_8,v2009_12);
        v2008_7_result = unite(v2008_7_result,v2009_13);
      }
      const Space v2008_7 = std::move(v2008_7_result);
      v2007_8 = compose(v2007_5,v2008_7);
    }
    const Space v2007_9 = intersect(constant_6,v2007_2);
    const Space v2007_10 = (has_head(v2007_9) ? constant_7 : Space{});
    const Space v2007_11 = compose(v2007_10,constant_9);
    const Space v2007_12 = unite(v2007_8,v2007_11);
    v2006_9_result = unite(v2006_9_result,v2007_12);
  }
  const Space v2006_9 = std::move(v2006_9_result);
  return v2006_9;
}

static Space routine_223(Context& c, const Path& p0, const Space& s0) {
  Space v2012_11_result;
  for (int v2012_11_label = 1; v2012_11_label <= 2; ++v2012_11_label) {
    const Space v2012_11_tail = child(s0,v2012_11_label);
    if (v2012_11_tail.empty()) continue;
    const Path v2012_11_head{v2012_11_label};
    const Space v2013_2 = singleton(v2012_11_head);
    const Space v2013_3 = intersect(constant_6,v2013_2);
    const Space v2013_4 = (has_head(v2013_3) ? constant_7 : Space{});
    const Space v2013_5 = subtract(constant_0,v2013_4);
    Space v2013_8;
    if (!v2013_5.empty()) {
      const Path v2014_6 = concat_path(p0,v2012_11_head);
      Space v2014_7_result;
      for (int v2014_7_label = 1; v2014_7_label <= 2; ++v2014_7_label) {
        const Space v2014_7_tail = child(v2012_11_tail,v2014_7_label);
        if (v2014_7_tail.empty()) continue;
        const Path v2014_7_head{v2014_7_label};
        const Space v2015_2 = singleton(v2014_7_head);
        const Space v2015_3 = intersect(constant_6,v2015_2);
        const Space v2015_4 = (has_head(v2015_3) ? constant_7 : Space{});
        const Space v2015_5 = subtract(constant_0,v2015_4);
        Space v2015_8;
        if (!v2015_5.empty()) {
          const Path v2016_6 = concat_path(v2014_6,v2014_7_head);
          const Space v2016_7 = routine_259(c, v2016_6, v2014_7_tail);
          v2015_8 = compose(v2015_5,v2016_7);
        }
        const Space v2015_9 = intersect(constant_6,v2015_2);
        const Space v2015_10 = (has_head(v2015_9) ? constant_7 : Space{});
        Space v2015_12;
        if (!v2015_10.empty()) {
          const Path v2017_6 = concat_path(v2014_6,v2014_7_head);
          const Space v2017_11 = routine_260(c, v2017_6, v2014_7_tail);
          v2015_12 = compose(v2015_10,v2017_11);
        }
        const Space v2015_13 = unite(v2015_8,v2015_12);
        v2014_7_result = unite(v2014_7_result,v2015_13);
      }
      const Space v2014_7 = std::move(v2014_7_result);
      v2013_8 = compose(v2013_5,v2014_7);
    }
    const Space v2013_9 = intersect(constant_6,v2013_2);
    const Space v2013_10 = (has_head(v2013_9) ? constant_7 : Space{});
    Space v2013_12;
    if (!v2013_10.empty()) {
      const Path v2018_6 = concat_path(p0,v2012_11_head);
      Space v2018_11_result;
      for (int v2018_11_label = 1; v2018_11_label <= 2; ++v2018_11_label) {
        const Space v2018_11_tail = child(v2012_11_tail,v2018_11_label);
        if (v2018_11_tail.empty()) continue;
        const Path v2018_11_head{v2018_11_label};
        const Space v2019_2 = singleton(v2018_11_head);
        const Space v2019_3 = intersect(constant_6,v2019_2);
        const Space v2019_4 = (has_head(v2019_3) ? constant_7 : Space{});
        const Space v2019_5 = subtract(constant_0,v2019_4);
        Space v2019_8;
        if (!v2019_5.empty()) {
          const Path v2020_6 = concat_path(v2018_6,v2018_11_head);
          const Space v2020_7 = routine_259(c, v2020_6, v2018_11_tail);
          v2019_8 = compose(v2019_5,v2020_7);
        }
        const Space v2019_9 = intersect(constant_6,v2019_2);
        const Space v2019_10 = (has_head(v2019_9) ? constant_7 : Space{});
        Space v2019_12;
        if (!v2019_10.empty()) {
          const Path v2021_6 = concat_path(v2018_6,v2018_11_head);
          const Space v2021_11 = routine_75(c, v2021_6, v2018_11_tail);
          v2019_12 = compose(v2019_10,v2021_11);
        }
        const Space v2019_13 = unite(v2019_8,v2019_12);
        v2018_11_result = unite(v2018_11_result,v2019_13);
      }
      const Space v2018_11 = std::move(v2018_11_result);
      v2013_12 = compose(v2013_10,v2018_11);
    }
    const Space v2013_13 = unite(v2013_8,v2013_12);
    v2012_11_result = unite(v2012_11_result,v2013_13);
  }
  const Space v2012_11 = std::move(v2012_11_result);
  return v2012_11;
}

static Space routine_224(Context& c, const Path& p0, const Space& s0) {
  Space v2022_8_result;
  for (int v2022_8_label = 1; v2022_8_label <= 2; ++v2022_8_label) {
    const Space v2022_8_tail = child(s0,v2022_8_label);
    if (v2022_8_tail.empty()) continue;
    const Path v2022_8_head{v2022_8_label};
    const Space v2023_2 = singleton(v2022_8_head);
    const Space v2023_3 = intersect(constant_6,v2023_2);
    const Space v2023_4 = (has_head(v2023_3) ? constant_7 : Space{});
    const Space v2023_5 = subtract(constant_0,v2023_4);
    Space v2023_8;
    if (!v2023_5.empty()) {
      const Path v2024_6 = concat_path(p0,v2022_8_head);
      Space v2024_7_result;
      for (int v2024_7_label = 1; v2024_7_label <= 2; ++v2024_7_label) {
        const Space v2024_7_tail = child(v2022_8_tail,v2024_7_label);
        if (v2024_7_tail.empty()) continue;
        const Path v2024_7_head{v2024_7_label};
        const Space v2025_2 = singleton(v2024_7_head);
        const Space v2025_3 = intersect(constant_6,v2025_2);
        const Space v2025_4 = (has_head(v2025_3) ? constant_7 : Space{});
        const Space v2025_5 = subtract(constant_0,v2025_4);
        Space v2025_8;
        if (!v2025_5.empty()) {
          const Path v2026_6 = concat_path(v2024_6,v2024_7_head);
          const Space v2026_7 = routine_259(c, v2026_6, v2024_7_tail);
          v2025_8 = compose(v2025_5,v2026_7);
        }
        const Space v2025_9 = intersect(constant_6,v2025_2);
        const Space v2025_10 = (has_head(v2025_9) ? constant_7 : Space{});
        Space v2025_12;
        if (!v2025_10.empty()) {
          const Path v2027_6 = concat_path(v2024_6,v2024_7_head);
          const Space v2027_11 = routine_260(c, v2027_6, v2024_7_tail);
          v2025_12 = compose(v2025_10,v2027_11);
        }
        const Space v2025_13 = unite(v2025_8,v2025_12);
        v2024_7_result = unite(v2024_7_result,v2025_13);
      }
      const Space v2024_7 = std::move(v2024_7_result);
      v2023_8 = compose(v2023_5,v2024_7);
    }
    const Space v2023_9 = intersect(constant_6,v2023_2);
    const Space v2023_10 = (has_head(v2023_9) ? constant_7 : Space{});
    const Space v2023_11 = compose(v2023_10,v2022_8_tail);
    const Space v2023_12 = unite(v2023_8,v2023_11);
    v2022_8_result = unite(v2022_8_result,v2023_12);
  }
  const Space v2022_8 = std::move(v2022_8_result);
  return v2022_8;
}

static Space routine_225(Context& c, const Path& p0, const Space& s0) {
  Space v2028_11_result;
  for (int v2028_11_label = 1; v2028_11_label <= 2; ++v2028_11_label) {
    const Space v2028_11_tail = child(s0,v2028_11_label);
    if (v2028_11_tail.empty()) continue;
    const Path v2028_11_head{v2028_11_label};
    const Space v2029_2 = singleton(v2028_11_head);
    const Space v2029_3 = intersect(constant_6,v2029_2);
    const Space v2029_4 = (has_head(v2029_3) ? constant_7 : Space{});
    const Space v2029_5 = subtract(constant_0,v2029_4);
    Space v2029_8;
    if (!v2029_5.empty()) {
      const Path v2030_6 = concat_path(p0,v2028_11_head);
      Space v2030_7_result;
      for (int v2030_7_label = 1; v2030_7_label <= 2; ++v2030_7_label) {
        const Space v2030_7_tail = child(v2028_11_tail,v2030_7_label);
        if (v2030_7_tail.empty()) continue;
        const Path v2030_7_head{v2030_7_label};
        const Space v2031_2 = singleton(v2030_7_head);
        const Space v2031_3 = intersect(constant_6,v2031_2);
        const Space v2031_4 = (has_head(v2031_3) ? constant_7 : Space{});
        const Space v2031_5 = subtract(constant_0,v2031_4);
        Space v2031_8;
        if (!v2031_5.empty()) {
          const Path v2032_6 = concat_path(v2030_6,v2030_7_head);
          const Space v2032_7 = routine_261(c, v2032_6, v2030_7_tail);
          v2031_8 = compose(v2031_5,v2032_7);
        }
        const Space v2031_9 = intersect(constant_6,v2031_2);
        const Space v2031_10 = (has_head(v2031_9) ? constant_7 : Space{});
        Space v2031_12;
        if (!v2031_10.empty()) {
          const Path v2033_6 = concat_path(v2030_6,v2030_7_head);
          const Space v2033_11 = routine_262(c, v2033_6, v2030_7_tail);
          v2031_12 = compose(v2031_10,v2033_11);
        }
        const Space v2031_13 = unite(v2031_8,v2031_12);
        v2030_7_result = unite(v2030_7_result,v2031_13);
      }
      const Space v2030_7 = std::move(v2030_7_result);
      v2029_8 = compose(v2029_5,v2030_7);
    }
    const Space v2029_9 = intersect(constant_6,v2029_2);
    const Space v2029_10 = (has_head(v2029_9) ? constant_7 : Space{});
    Space v2029_12;
    if (!v2029_10.empty()) {
      const Path v2034_6 = concat_path(p0,v2028_11_head);
      Space v2034_11_result;
      for (int v2034_11_label = 1; v2034_11_label <= 2; ++v2034_11_label) {
        const Space v2034_11_tail = child(v2028_11_tail,v2034_11_label);
        if (v2034_11_tail.empty()) continue;
        const Path v2034_11_head{v2034_11_label};
        const Space v2035_2 = singleton(v2034_11_head);
        const Space v2035_3 = intersect(constant_6,v2035_2);
        const Space v2035_4 = (has_head(v2035_3) ? constant_7 : Space{});
        const Space v2035_5 = subtract(constant_0,v2035_4);
        Space v2035_8;
        if (!v2035_5.empty()) {
          const Path v2036_6 = concat_path(v2034_6,v2034_11_head);
          const Space v2036_7 = routine_261(c, v2036_6, v2034_11_tail);
          v2035_8 = compose(v2035_5,v2036_7);
        }
        const Space v2035_9 = intersect(constant_6,v2035_2);
        const Space v2035_10 = (has_head(v2035_9) ? constant_7 : Space{});
        Space v2035_12;
        if (!v2035_10.empty()) {
          const Path v2037_6 = concat_path(v2034_6,v2034_11_head);
          const Space v2037_11 = routine_80(c, v2037_6, v2034_11_tail);
          v2035_12 = compose(v2035_10,v2037_11);
        }
        const Space v2035_13 = unite(v2035_8,v2035_12);
        v2034_11_result = unite(v2034_11_result,v2035_13);
      }
      const Space v2034_11 = std::move(v2034_11_result);
      v2029_12 = compose(v2029_10,v2034_11);
    }
    const Space v2029_13 = unite(v2029_8,v2029_12);
    v2028_11_result = unite(v2028_11_result,v2029_13);
  }
  const Space v2028_11 = std::move(v2028_11_result);
  return v2028_11;
}

static Space routine_226(Context& c, const Path& p0, const Space& s0) {
  Space v2038_11_result;
  for (int v2038_11_label = 1; v2038_11_label <= 2; ++v2038_11_label) {
    const Space v2038_11_tail = child(s0,v2038_11_label);
    if (v2038_11_tail.empty()) continue;
    const Path v2038_11_head{v2038_11_label};
    const Space v2039_2 = singleton(v2038_11_head);
    const Space v2039_3 = intersect(constant_6,v2039_2);
    const Space v2039_4 = (has_head(v2039_3) ? constant_7 : Space{});
    const Space v2039_5 = subtract(constant_0,v2039_4);
    Space v2039_8;
    if (!v2039_5.empty()) {
      const Path v2040_6 = concat_path(p0,v2038_11_head);
      Space v2040_7_result;
      for (int v2040_7_label = 1; v2040_7_label <= 2; ++v2040_7_label) {
        const Space v2040_7_tail = child(v2038_11_tail,v2040_7_label);
        if (v2040_7_tail.empty()) continue;
        const Path v2040_7_head{v2040_7_label};
        const Space v2041_2 = singleton(v2040_7_head);
        const Space v2041_3 = intersect(constant_6,v2041_2);
        const Space v2041_4 = (has_head(v2041_3) ? constant_7 : Space{});
        const Space v2041_5 = subtract(constant_0,v2041_4);
        Space v2041_8;
        if (!v2041_5.empty()) {
          const Path v2042_6 = concat_path(v2040_6,v2040_7_head);
          const Space v2042_7 = routine_261(c, v2042_6, v2040_7_tail);
          v2041_8 = compose(v2041_5,v2042_7);
        }
        const Space v2041_9 = intersect(constant_6,v2041_2);
        const Space v2041_10 = (has_head(v2041_9) ? constant_7 : Space{});
        Space v2041_12;
        if (!v2041_10.empty()) {
          const Path v2043_6 = concat_path(v2040_6,v2040_7_head);
          const Space v2043_11 = routine_262(c, v2043_6, v2040_7_tail);
          v2041_12 = compose(v2041_10,v2043_11);
        }
        const Space v2041_13 = unite(v2041_8,v2041_12);
        v2040_7_result = unite(v2040_7_result,v2041_13);
      }
      const Space v2040_7 = std::move(v2040_7_result);
      v2039_8 = compose(v2039_5,v2040_7);
    }
    const Space v2039_9 = intersect(constant_6,v2039_2);
    const Space v2039_10 = (has_head(v2039_9) ? constant_7 : Space{});
    Space v2039_12;
    if (!v2039_10.empty()) {
      const Path v2044_6 = concat_path(p0,v2038_11_head);
      Space v2044_11_result;
      for (int v2044_11_label = 1; v2044_11_label <= 2; ++v2044_11_label) {
        const Space v2044_11_tail = child(v2038_11_tail,v2044_11_label);
        if (v2044_11_tail.empty()) continue;
        const Path v2044_11_head{v2044_11_label};
        const Space v2045_2 = singleton(v2044_11_head);
        const Space v2045_3 = intersect(constant_6,v2045_2);
        const Space v2045_4 = (has_head(v2045_3) ? constant_7 : Space{});
        const Space v2045_5 = subtract(constant_0,v2045_4);
        Space v2045_7;
        if (!v2045_5.empty()) {
          const Space v2046_6 = routine_122(c, v2044_11_head, v2044_6, v2044_11_tail);
          v2045_7 = compose(v2045_5,v2046_6);
        }
        const Space v2045_8 = intersect(constant_6,v2045_2);
        const Space v2045_9 = (has_head(v2045_8) ? constant_7 : Space{});
        Space v2045_11;
        if (!v2045_9.empty()) {
          const Space v2047_10 = routine_123(c, v2044_11_head, v2044_6, v2044_11_tail);
          v2045_11 = compose(v2045_9,v2047_10);
        }
        const Space v2045_12 = unite(v2045_7,v2045_11);
        v2044_11_result = unite(v2044_11_result,v2045_12);
      }
      const Space v2044_11 = std::move(v2044_11_result);
      v2039_12 = compose(v2039_10,v2044_11);
    }
    const Space v2039_13 = unite(v2039_8,v2039_12);
    v2038_11_result = unite(v2038_11_result,v2039_13);
  }
  const Space v2038_11 = std::move(v2038_11_result);
  return v2038_11;
}

static Space routine_227(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2048_12_result;
  for (int v2048_12_label = 1; v2048_12_label <= 2; ++v2048_12_label) {
    const Space v2048_12_tail = child(s0,v2048_12_label);
    if (v2048_12_tail.empty()) continue;
    const Path v2048_12_head{v2048_12_label};
    const Space v2049_2 = singleton(v2048_12_head);
    const Space v2049_3 = intersect(constant_6,v2049_2);
    const Space v2049_4 = (has_head(v2049_3) ? constant_7 : Space{});
    const Space v2049_5 = subtract(constant_0,v2049_4);
    Space v2049_8;
    if (!v2049_5.empty()) {
      const Path v2050_6 = concat_path(p0,v2048_12_head);
      Space v2050_7_result;
      for (int v2050_7_label = 1; v2050_7_label <= 2; ++v2050_7_label) {
        const Space v2050_7_tail = child(v2048_12_tail,v2050_7_label);
        if (v2050_7_tail.empty()) continue;
        const Path v2050_7_head{v2050_7_label};
        const Space v2051_2 = singleton(v2050_7_head);
        const Space v2051_3 = intersect(constant_6,v2051_2);
        const Space v2051_4 = (has_head(v2051_3) ? constant_7 : Space{});
        const Space v2051_5 = subtract(constant_0,v2051_4);
        Space v2051_8;
        if (!v2051_5.empty()) {
          const Path v2052_6 = concat_path(v2050_6,v2050_7_head);
          const Space v2052_7 = routine_263(c, v2052_6, p1, v2050_7_tail);
          v2051_8 = compose(v2051_5,v2052_7);
        }
        const Space v2051_9 = intersect(constant_6,v2051_2);
        const Space v2051_10 = (has_head(v2051_9) ? constant_7 : Space{});
        Space v2051_12;
        if (!v2051_10.empty()) {
          const Path v2053_6 = concat_path(v2050_6,v2050_7_head);
          const Space v2053_11 = routine_264(c, v2053_6, p1, v2050_7_tail);
          v2051_12 = compose(v2051_10,v2053_11);
        }
        const Space v2051_13 = unite(v2051_8,v2051_12);
        v2050_7_result = unite(v2050_7_result,v2051_13);
      }
      const Space v2050_7 = std::move(v2050_7_result);
      v2049_8 = compose(v2049_5,v2050_7);
    }
    const Space v2049_9 = intersect(constant_6,v2049_2);
    const Space v2049_10 = (has_head(v2049_9) ? constant_7 : Space{});
    Space v2049_12;
    if (!v2049_10.empty()) {
      const Path v2054_6 = concat_path(p0,v2048_12_head);
      Space v2054_11_result;
      for (int v2054_11_label = 1; v2054_11_label <= 2; ++v2054_11_label) {
        const Space v2054_11_tail = child(v2048_12_tail,v2054_11_label);
        if (v2054_11_tail.empty()) continue;
        const Path v2054_11_head{v2054_11_label};
        const Space v2055_2 = singleton(v2054_11_head);
        const Space v2055_3 = intersect(constant_6,v2055_2);
        const Space v2055_4 = (has_head(v2055_3) ? constant_7 : Space{});
        const Space v2055_5 = subtract(constant_0,v2055_4);
        Space v2055_8;
        if (!v2055_5.empty()) {
          const Path v2056_6 = concat_path(v2054_6,v2054_11_head);
          const Space v2056_7 = routine_263(c, v2056_6, p1, v2054_11_tail);
          v2055_8 = compose(v2055_5,v2056_7);
        }
        const Space v2055_9 = intersect(constant_6,v2055_2);
        const Space v2055_10 = (has_head(v2055_9) ? constant_7 : Space{});
        Space v2055_12;
        if (!v2055_10.empty()) {
          const Path v2057_6 = concat_path(v2054_6,v2054_11_head);
          const Space v2057_11 = routine_137(c, v2057_6, p1, v2054_11_tail);
          v2055_12 = compose(v2055_10,v2057_11);
        }
        const Space v2055_13 = unite(v2055_8,v2055_12);
        v2054_11_result = unite(v2054_11_result,v2055_13);
      }
      const Space v2054_11 = std::move(v2054_11_result);
      v2049_12 = compose(v2049_10,v2054_11);
    }
    const Space v2049_13 = unite(v2049_8,v2049_12);
    v2048_12_result = unite(v2048_12_result,v2049_13);
  }
  const Space v2048_12 = std::move(v2048_12_result);
  return v2048_12;
}

static Space routine_228(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2058_7 = unwrap(constant_12,p1);
  const Space v2058_9 = unwrap(constant_12,p0);
  Space v2058_13_result;
  for (int v2058_13_label = 1; v2058_13_label <= 2; ++v2058_13_label) {
    const Space v2058_13_tail = child(s0,v2058_13_label);
    if (v2058_13_tail.empty()) continue;
    const Path v2058_13_head{v2058_13_label};
    const Space v2059_2 = singleton(v2058_13_head);
    const Space v2059_3 = intersect(constant_6,v2059_2);
    const Space v2059_4 = (has_head(v2059_3) ? constant_7 : Space{});
    const Space v2059_5 = subtract(constant_0,v2059_4);
    Space v2059_8;
    if (!v2059_5.empty()) {
      const Path v2060_6 = concat_path(p0,v2058_13_head);
      Space v2060_7_result;
      for (int v2060_7_label = 1; v2060_7_label <= 2; ++v2060_7_label) {
        const Space v2060_7_tail = child(v2058_13_tail,v2060_7_label);
        if (v2060_7_tail.empty()) continue;
        const Path v2060_7_head{v2060_7_label};
        const Space v2061_2 = singleton(v2060_7_head);
        const Space v2061_3 = intersect(constant_6,v2061_2);
        const Space v2061_4 = (has_head(v2061_3) ? constant_7 : Space{});
        const Space v2061_5 = subtract(constant_0,v2061_4);
        Space v2061_8;
        if (!v2061_5.empty()) {
          const Path v2062_6 = concat_path(v2060_6,v2060_7_head);
          const Space v2062_7 = routine_263(c, v2062_6, p1, v2060_7_tail);
          v2061_8 = compose(v2061_5,v2062_7);
        }
        const Space v2061_9 = intersect(constant_6,v2061_2);
        const Space v2061_10 = (has_head(v2061_9) ? constant_7 : Space{});
        Space v2061_12;
        if (!v2061_10.empty()) {
          const Path v2063_6 = concat_path(v2060_6,v2060_7_head);
          const Space v2063_11 = routine_264(c, v2063_6, p1, v2060_7_tail);
          v2061_12 = compose(v2061_10,v2063_11);
        }
        const Space v2061_13 = unite(v2061_8,v2061_12);
        v2060_7_result = unite(v2060_7_result,v2061_13);
      }
      const Space v2060_7 = std::move(v2060_7_result);
      v2059_8 = compose(v2059_5,v2060_7);
    }
    const Space v2059_9 = intersect(constant_6,v2059_2);
    const Space v2059_10 = (has_head(v2059_9) ? constant_7 : Space{});
    const Space v2059_11 = unwrap(v2058_9,v2058_13_head);
    const Space v2059_12 = compose(v2058_7,v2059_11);
    const Path v2064_6 = concat_path(p0,v2058_13_head);
    const Path v2059_13 = concat_path(p1,v2064_6);
    const Space v2059_14 = singleton(v2059_13);
    const Space v2059_15 = subtract(v2059_12,v2059_14);
    const Space v2059_16 = compose(v2059_10,v2059_15);
    const Space v2059_17 = unite(v2059_8,v2059_16);
    v2058_13_result = unite(v2058_13_result,v2059_17);
  }
  const Space v2058_13 = std::move(v2058_13_result);
  return v2058_13;
}

static Space routine_229(Context& c, const Path& p0, const Space& s0) {
  Space v2065_6_result;
  for (int v2065_6_label = 1; v2065_6_label <= 2; ++v2065_6_label) {
    const Space v2065_6_tail = child(s0,v2065_6_label);
    if (v2065_6_tail.empty()) continue;
    const Path v2065_6_head{v2065_6_label};
    const Space v2066_2 = singleton(v2065_6_head);
    const Space v2066_3 = intersect(constant_6,v2066_2);
    const Space v2066_4 = (has_head(v2066_3) ? constant_7 : Space{});
    const Space v2066_5 = subtract(constant_0,v2066_4);
    Space v2066_6_result;
    for (int v2066_6_label = 1; v2066_6_label <= 2; ++v2066_6_label) {
      const Space v2066_6_tail = child(v2065_6_tail,v2066_6_label);
      if (v2066_6_tail.empty()) continue;
      const Path v2066_6_head{v2066_6_label};
      const Space v2067_2 = Space{};
      v2066_6_result = unite(v2066_6_result,v2067_2);
    }
    const Space v2066_6 = std::move(v2066_6_result);
    const Space v2066_7 = compose(v2066_5,v2066_6);
    const Space v2066_8 = intersect(constant_6,v2066_2);
    const Space v2066_9 = (has_head(v2066_8) ? constant_7 : Space{});
    Space v2066_12;
    if (!v2066_9.empty()) {
      const Path v2068_10 = concat_path(p0,v2065_6_head);
      Space v2068_11_result;
      for (int v2068_11_label = 1; v2068_11_label <= 2; ++v2068_11_label) {
        const Space v2068_11_tail = child(v2065_6_tail,v2068_11_label);
        if (v2068_11_tail.empty()) continue;
        const Path v2068_11_head{v2068_11_label};
        const Space v2069_2 = singleton(v2068_11_head);
        const Space v2069_3 = intersect(constant_6,v2069_2);
        const Space v2069_4 = (has_head(v2069_3) ? constant_7 : Space{});
        Space v2069_7;
        if (!v2069_4.empty()) {
          const Path v2070_5 = concat_path(v2068_10,v2068_11_head);
          const Space v2070_6 = routine_69(c, v2070_5, v2068_11_tail);
          v2069_7 = compose(v2069_4,v2070_6);
        }
        v2068_11_result = unite(v2068_11_result,v2069_7);
      }
      const Space v2068_11 = std::move(v2068_11_result);
      v2066_12 = compose(v2066_9,v2068_11);
    }
    const Space v2066_13 = unite(v2066_7,v2066_12);
    v2065_6_result = unite(v2065_6_result,v2066_13);
  }
  const Space v2065_6 = std::move(v2065_6_result);
  return v2065_6;
}

static Space routine_230(Context& c, const Path& p0, const Space& s0) {
  Space v2071_6_result;
  for (int v2071_6_label = 1; v2071_6_label <= 2; ++v2071_6_label) {
    const Space v2071_6_tail = child(s0,v2071_6_label);
    if (v2071_6_tail.empty()) continue;
    const Path v2071_6_head{v2071_6_label};
    const Space v2072_2 = singleton(v2071_6_head);
    const Space v2072_3 = intersect(constant_6,v2072_2);
    const Space v2072_4 = (has_head(v2072_3) ? constant_7 : Space{});
    const Space v2072_5 = subtract(constant_0,v2072_4);
    Space v2072_6_result;
    for (int v2072_6_label = 1; v2072_6_label <= 2; ++v2072_6_label) {
      const Space v2072_6_tail = child(v2071_6_tail,v2072_6_label);
      if (v2072_6_tail.empty()) continue;
      const Path v2072_6_head{v2072_6_label};
      const Space v2073_2 = Space{};
      v2072_6_result = unite(v2072_6_result,v2073_2);
    }
    const Space v2072_6 = std::move(v2072_6_result);
    const Space v2072_7 = compose(v2072_5,v2072_6);
    const Space v2072_8 = intersect(constant_6,v2072_2);
    const Space v2072_9 = (has_head(v2072_8) ? constant_7 : Space{});
    const Space v2072_10 = compose(v2072_9,constant_9);
    const Space v2072_11 = unite(v2072_7,v2072_10);
    v2071_6_result = unite(v2071_6_result,v2072_11);
  }
  const Space v2071_6 = std::move(v2071_6_result);
  return v2071_6;
}

static Space routine_231(Context& c, const Path& p0, const Space& s0) {
  Space v2074_6_result;
  for (int v2074_6_label = 1; v2074_6_label <= 2; ++v2074_6_label) {
    const Space v2074_6_tail = child(s0,v2074_6_label);
    if (v2074_6_tail.empty()) continue;
    const Path v2074_6_head{v2074_6_label};
    const Space v2075_2 = singleton(v2074_6_head);
    const Space v2075_3 = intersect(constant_6,v2075_2);
    const Space v2075_4 = (has_head(v2075_3) ? constant_7 : Space{});
    const Space v2075_5 = subtract(constant_0,v2075_4);
    Space v2075_6_result;
    for (int v2075_6_label = 1; v2075_6_label <= 2; ++v2075_6_label) {
      const Space v2075_6_tail = child(v2074_6_tail,v2075_6_label);
      if (v2075_6_tail.empty()) continue;
      const Path v2075_6_head{v2075_6_label};
      const Space v2076_2 = Space{};
      v2075_6_result = unite(v2075_6_result,v2076_2);
    }
    const Space v2075_6 = std::move(v2075_6_result);
    const Space v2075_7 = compose(v2075_5,v2075_6);
    const Space v2075_8 = intersect(constant_6,v2075_2);
    const Space v2075_9 = (has_head(v2075_8) ? constant_7 : Space{});
    Space v2075_12;
    if (!v2075_9.empty()) {
      const Path v2077_10 = concat_path(p0,v2074_6_head);
      Space v2077_11_result;
      for (int v2077_11_label = 1; v2077_11_label <= 2; ++v2077_11_label) {
        const Space v2077_11_tail = child(v2074_6_tail,v2077_11_label);
        if (v2077_11_tail.empty()) continue;
        const Path v2077_11_head{v2077_11_label};
        const Space v2078_2 = singleton(v2077_11_head);
        const Space v2078_3 = intersect(constant_6,v2078_2);
        const Space v2078_4 = (has_head(v2078_3) ? constant_7 : Space{});
        Space v2078_7;
        if (!v2078_4.empty()) {
          const Path v2079_5 = concat_path(v2077_10,v2077_11_head);
          const Space v2079_6 = routine_72(c, v2079_5, v2077_11_tail);
          v2078_7 = compose(v2078_4,v2079_6);
        }
        v2077_11_result = unite(v2077_11_result,v2078_7);
      }
      const Space v2077_11 = std::move(v2077_11_result);
      v2075_12 = compose(v2075_9,v2077_11);
    }
    const Space v2075_13 = unite(v2075_7,v2075_12);
    v2074_6_result = unite(v2074_6_result,v2075_13);
  }
  const Space v2074_6 = std::move(v2074_6_result);
  return v2074_6;
}

static Space routine_232(Context& c, const Path& p0, const Space& s0) {
  Space v2080_6_result;
  for (int v2080_6_label = 1; v2080_6_label <= 2; ++v2080_6_label) {
    const Space v2080_6_tail = child(s0,v2080_6_label);
    if (v2080_6_tail.empty()) continue;
    const Path v2080_6_head{v2080_6_label};
    const Space v2081_2 = singleton(v2080_6_head);
    const Space v2081_3 = intersect(constant_6,v2081_2);
    const Space v2081_4 = (has_head(v2081_3) ? constant_7 : Space{});
    const Space v2081_5 = subtract(constant_0,v2081_4);
    Space v2081_6_result;
    for (int v2081_6_label = 1; v2081_6_label <= 2; ++v2081_6_label) {
      const Space v2081_6_tail = child(v2080_6_tail,v2081_6_label);
      if (v2081_6_tail.empty()) continue;
      const Path v2081_6_head{v2081_6_label};
      const Space v2082_2 = Space{};
      v2081_6_result = unite(v2081_6_result,v2082_2);
    }
    const Space v2081_6 = std::move(v2081_6_result);
    const Space v2081_7 = compose(v2081_5,v2081_6);
    const Space v2081_8 = intersect(constant_6,v2081_2);
    const Space v2081_9 = (has_head(v2081_8) ? constant_7 : Space{});
    const Space v2081_10 = compose(v2081_9,constant_9);
    const Space v2081_11 = unite(v2081_7,v2081_10);
    v2080_6_result = unite(v2080_6_result,v2081_11);
  }
  const Space v2080_6 = std::move(v2080_6_result);
  return v2080_6;
}

static Space routine_233(Context& c, const Path& p0, const Space& s0) {
  Space v2083_6_result;
  for (int v2083_6_label = 1; v2083_6_label <= 2; ++v2083_6_label) {
    const Space v2083_6_tail = child(s0,v2083_6_label);
    if (v2083_6_tail.empty()) continue;
    const Path v2083_6_head{v2083_6_label};
    const Space v2084_2 = singleton(v2083_6_head);
    const Space v2084_3 = intersect(constant_6,v2084_2);
    const Space v2084_4 = (has_head(v2084_3) ? constant_7 : Space{});
    const Space v2084_5 = subtract(constant_0,v2084_4);
    Space v2084_6_result;
    for (int v2084_6_label = 1; v2084_6_label <= 2; ++v2084_6_label) {
      const Space v2084_6_tail = child(v2083_6_tail,v2084_6_label);
      if (v2084_6_tail.empty()) continue;
      const Path v2084_6_head{v2084_6_label};
      const Space v2085_2 = Space{};
      v2084_6_result = unite(v2084_6_result,v2085_2);
    }
    const Space v2084_6 = std::move(v2084_6_result);
    const Space v2084_7 = compose(v2084_5,v2084_6);
    const Space v2084_8 = intersect(constant_6,v2084_2);
    const Space v2084_9 = (has_head(v2084_8) ? constant_7 : Space{});
    Space v2084_12;
    if (!v2084_9.empty()) {
      const Path v2086_10 = concat_path(p0,v2083_6_head);
      Space v2086_11_result;
      for (int v2086_11_label = 1; v2086_11_label <= 2; ++v2086_11_label) {
        const Space v2086_11_tail = child(v2083_6_tail,v2086_11_label);
        if (v2086_11_tail.empty()) continue;
        const Path v2086_11_head{v2086_11_label};
        const Space v2087_2 = singleton(v2086_11_head);
        const Space v2087_3 = intersect(constant_6,v2087_2);
        const Space v2087_4 = (has_head(v2087_3) ? constant_7 : Space{});
        Space v2087_7;
        if (!v2087_4.empty()) {
          const Path v2088_5 = concat_path(v2086_10,v2086_11_head);
          const Space v2088_6 = routine_75(c, v2088_5, v2086_11_tail);
          v2087_7 = compose(v2087_4,v2088_6);
        }
        v2086_11_result = unite(v2086_11_result,v2087_7);
      }
      const Space v2086_11 = std::move(v2086_11_result);
      v2084_12 = compose(v2084_9,v2086_11);
    }
    const Space v2084_13 = unite(v2084_7,v2084_12);
    v2083_6_result = unite(v2083_6_result,v2084_13);
  }
  const Space v2083_6 = std::move(v2083_6_result);
  return v2083_6;
}

static Space routine_234(Context& c, const Path& p0, const Space& s0) {
  Space v2089_5_result;
  for (int v2089_5_label = 1; v2089_5_label <= 2; ++v2089_5_label) {
    const Space v2089_5_tail = child(s0,v2089_5_label);
    if (v2089_5_tail.empty()) continue;
    const Path v2089_5_head{v2089_5_label};
    const Space v2090_2 = singleton(v2089_5_head);
    const Space v2090_3 = intersect(constant_6,v2090_2);
    const Space v2090_4 = (has_head(v2090_3) ? constant_7 : Space{});
    const Space v2090_5 = subtract(constant_0,v2090_4);
    Space v2090_6_result;
    for (int v2090_6_label = 1; v2090_6_label <= 2; ++v2090_6_label) {
      const Space v2090_6_tail = child(v2089_5_tail,v2090_6_label);
      if (v2090_6_tail.empty()) continue;
      const Path v2090_6_head{v2090_6_label};
      const Space v2091_2 = Space{};
      v2090_6_result = unite(v2090_6_result,v2091_2);
    }
    const Space v2090_6 = std::move(v2090_6_result);
    const Space v2090_7 = compose(v2090_5,v2090_6);
    const Space v2090_8 = intersect(constant_6,v2090_2);
    const Space v2090_9 = (has_head(v2090_8) ? constant_7 : Space{});
    const Space v2090_10 = compose(v2090_9,v2089_5_tail);
    const Space v2090_11 = unite(v2090_7,v2090_10);
    v2089_5_result = unite(v2089_5_result,v2090_11);
  }
  const Space v2089_5 = std::move(v2089_5_result);
  return v2089_5;
}

static Space routine_235(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2092_3_result;
  for (int v2092_3_label = 1; v2092_3_label <= 2; ++v2092_3_label) {
    const Space v2092_3_tail = child(s0,v2092_3_label);
    if (v2092_3_tail.empty()) continue;
    const Path v2092_3_head{v2092_3_label};
    const Space v2093_2 = Space{};
    v2092_3_result = unite(v2092_3_result,v2093_2);
  }
  const Space v2092_3 = std::move(v2092_3_result);
  return v2092_3;
}

static Space routine_236(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2094_4_result;
  for (int v2094_4_label = 1; v2094_4_label <= 2; ++v2094_4_label) {
    const Space v2094_4_tail = child(s0,v2094_4_label);
    if (v2094_4_tail.empty()) continue;
    const Path v2094_4_head{v2094_4_label};
    const Space v2095_2 = singleton(v2094_4_head);
    const Space v2095_3 = intersect(constant_6,v2095_2);
    const Space v2095_4 = (has_head(v2095_3) ? constant_7 : Space{});
    Space v2095_8;
    if (!v2095_4.empty()) {
      const Path v2096_5 = concat_path(p0,v2094_4_head);
      const Path v2096_6 = concat_path(p1,v2096_5);
      const Space v2096_7 = routine_29(c, v2096_6);
      v2095_8 = compose(v2095_4,v2096_7);
    }
    v2094_4_result = unite(v2094_4_result,v2095_8);
  }
  const Space v2094_4 = std::move(v2094_4_result);
  return v2094_4;
}

static Space routine_237(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  Space v2097_4_result;
  for (int v2097_4_label = 1; v2097_4_label <= 2; ++v2097_4_label) {
    const Space v2097_4_tail = child(s0,v2097_4_label);
    if (v2097_4_tail.empty()) continue;
    const Path v2097_4_head{v2097_4_label};
    const Space v2098_2 = Space{};
    v2097_4_result = unite(v2097_4_result,v2098_2);
  }
  const Space v2097_4 = std::move(v2097_4_result);
  return v2097_4;
}

static Space routine_238(Context& c, const Path& p0, const Path& p1, const Space& s0, const Space& s1) {
  const Space v2099_6 = unwrap(s1,constant_8);
  Space v2099_16_result;
  for (int v2099_16_label = 1; v2099_16_label <= 2; ++v2099_16_label) {
    const Space v2099_16_tail = child(s0,v2099_16_label);
    if (v2099_16_tail.empty()) continue;
    const Path v2099_16_head{v2099_16_label};
    const Space v2100_2 = singleton(v2099_16_head);
    const Space v2100_3 = intersect(constant_6,v2100_2);
    const Space v2100_4 = (has_head(v2100_3) ? constant_7 : Space{});
    Space v2100_17;
    if (!v2100_4.empty()) {
      const Path v2101_5 = concat_path(p0,v2099_16_head);
      const Path v2101_6 = concat_path(p1,v2101_5);
      const Space v2101_7 = routine_29(c, v2101_6);
      const Space v2101_8 = intersect(v2099_6,v2101_7);
      const Space v2101_9 = routine_33(c, v2101_8);
      Space v2101_10_result;
      for (int v2101_10_label = 1; v2101_10_label <= 2; ++v2101_10_label) {
        const Space v2101_10_tail = child(v2101_9,v2101_10_label);
        if (v2101_10_tail.empty()) continue;
        const Path v2101_10_head{v2101_10_label};
        const Space v2102_2 = singleton(v2101_10_head);
        const Space v2102_3 = intersect(constant_6,v2102_2);
        const Space v2102_4 = (has_head(v2102_3) ? constant_7 : Space{});
        const Space v2102_5 = subtract(constant_0,v2102_4);
        Space v2102_7;
        if (!v2102_5.empty()) {
          const Space v2103_6 = routine_52(c, v2101_10_head, v2101_10_tail);
          v2102_7 = compose(v2102_5,v2103_6);
        }
        const Space v2102_8 = intersect(constant_6,v2102_2);
        const Space v2102_9 = (has_head(v2102_8) ? constant_7 : Space{});
        Space v2102_11;
        if (!v2102_9.empty()) {
          const Space v2104_10 = routine_53(c, v2101_10_head, v2101_10_tail);
          v2102_11 = compose(v2102_9,v2104_10);
        }
        const Space v2102_12 = unite(v2102_7,v2102_11);
        v2101_10_result = unite(v2101_10_result,v2102_12);
      }
      const Space v2101_10 = std::move(v2101_10_result);
      const Space v2101_11 = routine_54(c, v2101_8);
      Space v2101_12_result;
      for (int v2101_12_label = 1; v2101_12_label <= 2; ++v2101_12_label) {
        const Space v2101_12_tail = child(v2101_11,v2101_12_label);
        if (v2101_12_tail.empty()) continue;
        const Path v2101_12_head{v2101_12_label};
        const Space v2105_2 = singleton(v2101_12_head);
        const Space v2105_3 = intersect(constant_6,v2105_2);
        const Space v2105_4 = (has_head(v2105_3) ? constant_7 : Space{});
        const Space v2105_5 = subtract(constant_0,v2105_4);
        Space v2105_7;
        if (!v2105_5.empty()) {
          const Space v2106_6 = routine_55(c, v2101_12_head, v2101_12_tail);
          v2105_7 = compose(v2105_5,v2106_6);
        }
        const Space v2105_8 = intersect(constant_6,v2105_2);
        const Space v2105_9 = (has_head(v2105_8) ? constant_7 : Space{});
        Space v2105_11;
        if (!v2105_9.empty()) {
          const Space v2107_10 = routine_56(c, v2101_12_head, v2101_12_tail);
          v2105_11 = compose(v2105_9,v2107_10);
        }
        const Space v2105_12 = unite(v2105_7,v2105_11);
        v2101_12_result = unite(v2101_12_result,v2105_12);
      }
      const Space v2101_12 = std::move(v2101_12_result);
      const Space v2101_13 = subtract(v2101_10,v2101_12);
      const Space v2101_14 = singleton(v2101_6);
      const Space v2101_15 = compose(v2101_13,v2101_14);
      Space v2101_16_result;
      for (int v2101_16_label = 1; v2101_16_label <= 2; ++v2101_16_label) {
        const Space v2101_16_tail = child(v2101_15,v2101_16_label);
        if (v2101_16_tail.empty()) continue;
        const Path v2101_16_head{v2101_16_label};
        const Space v2108_2 = singleton(v2101_16_head);
        const Space v2108_3 = intersect(constant_6,v2108_2);
        const Space v2108_4 = (has_head(v2108_3) ? constant_7 : Space{});
        const Space v2108_5 = subtract(constant_0,v2108_4);
        Space v2108_7;
        if (!v2108_5.empty()) {
          const Space v2109_6 = routine_57(c, v2101_16_head, v2101_16_tail);
          v2108_7 = compose(v2108_5,v2109_6);
        }
        const Space v2108_8 = intersect(constant_6,v2108_2);
        const Space v2108_9 = (has_head(v2108_8) ? constant_7 : Space{});
        Space v2108_11;
        if (!v2108_9.empty()) {
          const Space v2110_10 = routine_58(c, v2101_16_head, v2101_16_tail);
          v2108_11 = compose(v2108_9,v2110_10);
        }
        const Space v2108_12 = unite(v2108_7,v2108_11);
        v2101_16_result = unite(v2101_16_result,v2108_12);
      }
      const Space v2101_16 = std::move(v2101_16_result);
      v2100_17 = compose(v2100_4,v2101_16);
    }
    v2099_16_result = unite(v2099_16_result,v2100_17);
  }
  const Space v2099_16 = std::move(v2099_16_result);
  return v2099_16;
}

static Space routine_239(Context& c, const Path& p0, const Space& s0) {
  Space v2111_11_result;
  for (int v2111_11_label = 1; v2111_11_label <= 2; ++v2111_11_label) {
    const Space v2111_11_tail = child(s0,v2111_11_label);
    if (v2111_11_tail.empty()) continue;
    const Path v2111_11_head{v2111_11_label};
    const Space v2112_2 = singleton(v2111_11_head);
    const Space v2112_3 = intersect(constant_6,v2112_2);
    const Space v2112_4 = (has_head(v2112_3) ? constant_7 : Space{});
    const Space v2112_5 = subtract(constant_0,v2112_4);
    Space v2112_8;
    if (!v2112_5.empty()) {
      const Path v2113_6 = concat_path(p0,v2111_11_head);
      Space v2113_7_result;
      for (int v2113_7_label = 1; v2113_7_label <= 2; ++v2113_7_label) {
        const Space v2113_7_tail = child(v2111_11_tail,v2113_7_label);
        if (v2113_7_tail.empty()) continue;
        const Path v2113_7_head{v2113_7_label};
        const Space v2114_2 = singleton(v2113_7_head);
        const Space v2114_3 = intersect(constant_6,v2114_2);
        const Space v2114_4 = (has_head(v2114_3) ? constant_7 : Space{});
        const Space v2114_5 = subtract(constant_0,v2114_4);
        Space v2114_8;
        if (!v2114_5.empty()) {
          const Path v2115_6 = concat_path(v2113_6,v2113_7_head);
          const Space v2115_7 = routine_265(c, v2115_6, v2113_7_tail);
          v2114_8 = compose(v2114_5,v2115_7);
        }
        const Space v2114_9 = intersect(constant_6,v2114_2);
        const Space v2114_10 = (has_head(v2114_9) ? constant_7 : Space{});
        Space v2114_12;
        if (!v2114_10.empty()) {
          const Path v2116_6 = concat_path(v2113_6,v2113_7_head);
          const Space v2116_11 = routine_266(c, v2116_6, v2113_7_tail);
          v2114_12 = compose(v2114_10,v2116_11);
        }
        const Space v2114_13 = unite(v2114_8,v2114_12);
        v2113_7_result = unite(v2113_7_result,v2114_13);
      }
      const Space v2113_7 = std::move(v2113_7_result);
      v2112_8 = compose(v2112_5,v2113_7);
    }
    const Space v2112_9 = intersect(constant_6,v2112_2);
    const Space v2112_10 = (has_head(v2112_9) ? constant_7 : Space{});
    Space v2112_12;
    if (!v2112_10.empty()) {
      const Path v2117_6 = concat_path(p0,v2111_11_head);
      Space v2117_11_result;
      for (int v2117_11_label = 1; v2117_11_label <= 2; ++v2117_11_label) {
        const Space v2117_11_tail = child(v2111_11_tail,v2117_11_label);
        if (v2117_11_tail.empty()) continue;
        const Path v2117_11_head{v2117_11_label};
        const Space v2118_2 = singleton(v2117_11_head);
        const Space v2118_3 = intersect(constant_6,v2118_2);
        const Space v2118_4 = (has_head(v2118_3) ? constant_7 : Space{});
        const Space v2118_5 = subtract(constant_0,v2118_4);
        Space v2118_8;
        if (!v2118_5.empty()) {
          const Path v2119_6 = concat_path(v2117_6,v2117_11_head);
          const Space v2119_7 = routine_265(c, v2119_6, v2117_11_tail);
          v2118_8 = compose(v2118_5,v2119_7);
        }
        const Space v2118_9 = intersect(constant_6,v2118_2);
        const Space v2118_10 = (has_head(v2118_9) ? constant_7 : Space{});
        Space v2118_12;
        if (!v2118_10.empty()) {
          const Path v2120_6 = concat_path(v2117_6,v2117_11_head);
          const Space v2120_11 = routine_100(c, v2120_6, v2117_11_tail);
          v2118_12 = compose(v2118_10,v2120_11);
        }
        const Space v2118_13 = unite(v2118_8,v2118_12);
        v2117_11_result = unite(v2117_11_result,v2118_13);
      }
      const Space v2117_11 = std::move(v2117_11_result);
      v2112_12 = compose(v2112_10,v2117_11);
    }
    const Space v2112_13 = unite(v2112_8,v2112_12);
    v2111_11_result = unite(v2111_11_result,v2112_13);
  }
  const Space v2111_11 = std::move(v2111_11_result);
  return v2111_11;
}

static Space routine_240(Context& c, const Path& p0, const Space& s0) {
  Space v2121_9_result;
  for (int v2121_9_label = 1; v2121_9_label <= 2; ++v2121_9_label) {
    const Space v2121_9_tail = child(s0,v2121_9_label);
    if (v2121_9_tail.empty()) continue;
    const Path v2121_9_head{v2121_9_label};
    const Space v2122_2 = singleton(v2121_9_head);
    const Space v2122_3 = intersect(constant_6,v2122_2);
    const Space v2122_4 = (has_head(v2122_3) ? constant_7 : Space{});
    const Space v2122_5 = subtract(constant_0,v2122_4);
    Space v2122_8;
    if (!v2122_5.empty()) {
      const Path v2123_6 = concat_path(p0,v2121_9_head);
      Space v2123_7_result;
      for (int v2123_7_label = 1; v2123_7_label <= 2; ++v2123_7_label) {
        const Space v2123_7_tail = child(v2121_9_tail,v2123_7_label);
        if (v2123_7_tail.empty()) continue;
        const Path v2123_7_head{v2123_7_label};
        const Space v2124_2 = singleton(v2123_7_head);
        const Space v2124_3 = intersect(constant_6,v2124_2);
        const Space v2124_4 = (has_head(v2124_3) ? constant_7 : Space{});
        const Space v2124_5 = subtract(constant_0,v2124_4);
        Space v2124_8;
        if (!v2124_5.empty()) {
          const Path v2125_6 = concat_path(v2123_6,v2123_7_head);
          const Space v2125_7 = routine_265(c, v2125_6, v2123_7_tail);
          v2124_8 = compose(v2124_5,v2125_7);
        }
        const Space v2124_9 = intersect(constant_6,v2124_2);
        const Space v2124_10 = (has_head(v2124_9) ? constant_7 : Space{});
        Space v2124_12;
        if (!v2124_10.empty()) {
          const Path v2126_6 = concat_path(v2123_6,v2123_7_head);
          const Space v2126_11 = routine_266(c, v2126_6, v2123_7_tail);
          v2124_12 = compose(v2124_10,v2126_11);
        }
        const Space v2124_13 = unite(v2124_8,v2124_12);
        v2123_7_result = unite(v2123_7_result,v2124_13);
      }
      const Space v2123_7 = std::move(v2123_7_result);
      v2122_8 = compose(v2122_5,v2123_7);
    }
    const Space v2122_9 = intersect(constant_6,v2122_2);
    const Space v2122_10 = (has_head(v2122_9) ? constant_7 : Space{});
    const Space v2122_11 = compose(v2122_10,constant_9);
    const Space v2122_12 = unite(v2122_8,v2122_11);
    v2121_9_result = unite(v2121_9_result,v2122_12);
  }
  const Space v2121_9 = std::move(v2121_9_result);
  return v2121_9;
}

static Space routine_241(Context& c, const Path& p0, const Space& s0) {
  Space v2127_11_result;
  for (int v2127_11_label = 1; v2127_11_label <= 2; ++v2127_11_label) {
    const Space v2127_11_tail = child(s0,v2127_11_label);
    if (v2127_11_tail.empty()) continue;
    const Path v2127_11_head{v2127_11_label};
    const Space v2128_2 = singleton(v2127_11_head);
    const Space v2128_3 = intersect(constant_6,v2128_2);
    const Space v2128_4 = (has_head(v2128_3) ? constant_7 : Space{});
    const Space v2128_5 = subtract(constant_0,v2128_4);
    Space v2128_8;
    if (!v2128_5.empty()) {
      const Path v2129_6 = concat_path(p0,v2127_11_head);
      Space v2129_7_result;
      for (int v2129_7_label = 1; v2129_7_label <= 2; ++v2129_7_label) {
        const Space v2129_7_tail = child(v2127_11_tail,v2129_7_label);
        if (v2129_7_tail.empty()) continue;
        const Path v2129_7_head{v2129_7_label};
        const Space v2130_2 = singleton(v2129_7_head);
        const Space v2130_3 = intersect(constant_6,v2130_2);
        const Space v2130_4 = (has_head(v2130_3) ? constant_7 : Space{});
        const Space v2130_5 = subtract(constant_0,v2130_4);
        Space v2130_8;
        if (!v2130_5.empty()) {
          const Path v2131_6 = concat_path(v2129_6,v2129_7_head);
          const Space v2131_7 = routine_267(c, v2131_6, v2129_7_tail);
          v2130_8 = compose(v2130_5,v2131_7);
        }
        const Space v2130_9 = intersect(constant_6,v2130_2);
        const Space v2130_10 = (has_head(v2130_9) ? constant_7 : Space{});
        Space v2130_12;
        if (!v2130_10.empty()) {
          const Path v2132_6 = concat_path(v2129_6,v2129_7_head);
          const Space v2132_11 = routine_268(c, v2132_6, v2129_7_tail);
          v2130_12 = compose(v2130_10,v2132_11);
        }
        const Space v2130_13 = unite(v2130_8,v2130_12);
        v2129_7_result = unite(v2129_7_result,v2130_13);
      }
      const Space v2129_7 = std::move(v2129_7_result);
      v2128_8 = compose(v2128_5,v2129_7);
    }
    const Space v2128_9 = intersect(constant_6,v2128_2);
    const Space v2128_10 = (has_head(v2128_9) ? constant_7 : Space{});
    Space v2128_12;
    if (!v2128_10.empty()) {
      const Path v2133_6 = concat_path(p0,v2127_11_head);
      Space v2133_11_result;
      for (int v2133_11_label = 1; v2133_11_label <= 2; ++v2133_11_label) {
        const Space v2133_11_tail = child(v2127_11_tail,v2133_11_label);
        if (v2133_11_tail.empty()) continue;
        const Path v2133_11_head{v2133_11_label};
        const Space v2134_2 = singleton(v2133_11_head);
        const Space v2134_3 = intersect(constant_6,v2134_2);
        const Space v2134_4 = (has_head(v2134_3) ? constant_7 : Space{});
        const Space v2134_5 = subtract(constant_0,v2134_4);
        Space v2134_8;
        if (!v2134_5.empty()) {
          const Path v2135_6 = concat_path(v2133_6,v2133_11_head);
          const Space v2135_7 = routine_267(c, v2135_6, v2133_11_tail);
          v2134_8 = compose(v2134_5,v2135_7);
        }
        const Space v2134_9 = intersect(constant_6,v2134_2);
        const Space v2134_10 = (has_head(v2134_9) ? constant_7 : Space{});
        Space v2134_12;
        if (!v2134_10.empty()) {
          const Path v2136_6 = concat_path(v2133_6,v2133_11_head);
          const Space v2136_11 = routine_104(c, v2136_6, v2133_11_tail);
          v2134_12 = compose(v2134_10,v2136_11);
        }
        const Space v2134_13 = unite(v2134_8,v2134_12);
        v2133_11_result = unite(v2133_11_result,v2134_13);
      }
      const Space v2133_11 = std::move(v2133_11_result);
      v2128_12 = compose(v2128_10,v2133_11);
    }
    const Space v2128_13 = unite(v2128_8,v2128_12);
    v2127_11_result = unite(v2127_11_result,v2128_13);
  }
  const Space v2127_11 = std::move(v2127_11_result);
  return v2127_11;
}

static Space routine_242(Context& c, const Path& p0, const Space& s0) {
  Space v2137_9_result;
  for (int v2137_9_label = 1; v2137_9_label <= 2; ++v2137_9_label) {
    const Space v2137_9_tail = child(s0,v2137_9_label);
    if (v2137_9_tail.empty()) continue;
    const Path v2137_9_head{v2137_9_label};
    const Space v2138_2 = singleton(v2137_9_head);
    const Space v2138_3 = intersect(constant_6,v2138_2);
    const Space v2138_4 = (has_head(v2138_3) ? constant_7 : Space{});
    const Space v2138_5 = subtract(constant_0,v2138_4);
    Space v2138_8;
    if (!v2138_5.empty()) {
      const Path v2139_6 = concat_path(p0,v2137_9_head);
      Space v2139_7_result;
      for (int v2139_7_label = 1; v2139_7_label <= 2; ++v2139_7_label) {
        const Space v2139_7_tail = child(v2137_9_tail,v2139_7_label);
        if (v2139_7_tail.empty()) continue;
        const Path v2139_7_head{v2139_7_label};
        const Space v2140_2 = singleton(v2139_7_head);
        const Space v2140_3 = intersect(constant_6,v2140_2);
        const Space v2140_4 = (has_head(v2140_3) ? constant_7 : Space{});
        const Space v2140_5 = subtract(constant_0,v2140_4);
        Space v2140_8;
        if (!v2140_5.empty()) {
          const Path v2141_6 = concat_path(v2139_6,v2139_7_head);
          const Space v2141_7 = routine_267(c, v2141_6, v2139_7_tail);
          v2140_8 = compose(v2140_5,v2141_7);
        }
        const Space v2140_9 = intersect(constant_6,v2140_2);
        const Space v2140_10 = (has_head(v2140_9) ? constant_7 : Space{});
        Space v2140_12;
        if (!v2140_10.empty()) {
          const Path v2142_6 = concat_path(v2139_6,v2139_7_head);
          const Space v2142_11 = routine_268(c, v2142_6, v2139_7_tail);
          v2140_12 = compose(v2140_10,v2142_11);
        }
        const Space v2140_13 = unite(v2140_8,v2140_12);
        v2139_7_result = unite(v2139_7_result,v2140_13);
      }
      const Space v2139_7 = std::move(v2139_7_result);
      v2138_8 = compose(v2138_5,v2139_7);
    }
    const Space v2138_9 = intersect(constant_6,v2138_2);
    const Space v2138_10 = (has_head(v2138_9) ? constant_7 : Space{});
    const Space v2138_11 = compose(v2138_10,constant_9);
    const Space v2138_12 = unite(v2138_8,v2138_11);
    v2137_9_result = unite(v2137_9_result,v2138_12);
  }
  const Space v2137_9 = std::move(v2137_9_result);
  return v2137_9;
}

static Space routine_243(Context& c, const Path& p0, const Space& s0) {
  Space v2143_11_result;
  for (int v2143_11_label = 1; v2143_11_label <= 2; ++v2143_11_label) {
    const Space v2143_11_tail = child(s0,v2143_11_label);
    if (v2143_11_tail.empty()) continue;
    const Path v2143_11_head{v2143_11_label};
    const Space v2144_2 = singleton(v2143_11_head);
    const Space v2144_3 = intersect(constant_6,v2144_2);
    const Space v2144_4 = (has_head(v2144_3) ? constant_7 : Space{});
    const Space v2144_5 = subtract(constant_0,v2144_4);
    Space v2144_8;
    if (!v2144_5.empty()) {
      const Path v2145_6 = concat_path(p0,v2143_11_head);
      Space v2145_7_result;
      for (int v2145_7_label = 1; v2145_7_label <= 2; ++v2145_7_label) {
        const Space v2145_7_tail = child(v2143_11_tail,v2145_7_label);
        if (v2145_7_tail.empty()) continue;
        const Path v2145_7_head{v2145_7_label};
        const Space v2146_2 = singleton(v2145_7_head);
        const Space v2146_3 = intersect(constant_6,v2146_2);
        const Space v2146_4 = (has_head(v2146_3) ? constant_7 : Space{});
        const Space v2146_5 = subtract(constant_0,v2146_4);
        Space v2146_8;
        if (!v2146_5.empty()) {
          const Path v2147_6 = concat_path(v2145_6,v2145_7_head);
          const Space v2147_7 = routine_269(c, v2147_6, v2145_7_tail);
          v2146_8 = compose(v2146_5,v2147_7);
        }
        const Space v2146_9 = intersect(constant_6,v2146_2);
        const Space v2146_10 = (has_head(v2146_9) ? constant_7 : Space{});
        Space v2146_12;
        if (!v2146_10.empty()) {
          const Path v2148_6 = concat_path(v2145_6,v2145_7_head);
          const Space v2148_11 = routine_270(c, v2148_6, v2145_7_tail);
          v2146_12 = compose(v2146_10,v2148_11);
        }
        const Space v2146_13 = unite(v2146_8,v2146_12);
        v2145_7_result = unite(v2145_7_result,v2146_13);
      }
      const Space v2145_7 = std::move(v2145_7_result);
      v2144_8 = compose(v2144_5,v2145_7);
    }
    const Space v2144_9 = intersect(constant_6,v2144_2);
    const Space v2144_10 = (has_head(v2144_9) ? constant_7 : Space{});
    Space v2144_12;
    if (!v2144_10.empty()) {
      const Path v2149_6 = concat_path(p0,v2143_11_head);
      Space v2149_11_result;
      for (int v2149_11_label = 1; v2149_11_label <= 2; ++v2149_11_label) {
        const Space v2149_11_tail = child(v2143_11_tail,v2149_11_label);
        if (v2149_11_tail.empty()) continue;
        const Path v2149_11_head{v2149_11_label};
        const Space v2150_2 = singleton(v2149_11_head);
        const Space v2150_3 = intersect(constant_6,v2150_2);
        const Space v2150_4 = (has_head(v2150_3) ? constant_7 : Space{});
        const Space v2150_5 = subtract(constant_0,v2150_4);
        Space v2150_8;
        if (!v2150_5.empty()) {
          const Path v2151_6 = concat_path(v2149_6,v2149_11_head);
          const Space v2151_7 = routine_269(c, v2151_6, v2149_11_tail);
          v2150_8 = compose(v2150_5,v2151_7);
        }
        const Space v2150_9 = intersect(constant_6,v2150_2);
        const Space v2150_10 = (has_head(v2150_9) ? constant_7 : Space{});
        Space v2150_12;
        if (!v2150_10.empty()) {
          const Path v2152_6 = concat_path(v2149_6,v2149_11_head);
          const Space v2152_11 = routine_107(c, v2152_6, v2149_11_tail);
          v2150_12 = compose(v2150_10,v2152_11);
        }
        const Space v2150_13 = unite(v2150_8,v2150_12);
        v2149_11_result = unite(v2149_11_result,v2150_13);
      }
      const Space v2149_11 = std::move(v2149_11_result);
      v2144_12 = compose(v2144_10,v2149_11);
    }
    const Space v2144_13 = unite(v2144_8,v2144_12);
    v2143_11_result = unite(v2143_11_result,v2144_13);
  }
  const Space v2143_11 = std::move(v2143_11_result);
  return v2143_11;
}

static Space routine_244(Context& c, const Path& p0, const Space& s0) {
  Space v2153_8_result;
  for (int v2153_8_label = 1; v2153_8_label <= 2; ++v2153_8_label) {
    const Space v2153_8_tail = child(s0,v2153_8_label);
    if (v2153_8_tail.empty()) continue;
    const Path v2153_8_head{v2153_8_label};
    const Space v2154_2 = singleton(v2153_8_head);
    const Space v2154_3 = intersect(constant_6,v2154_2);
    const Space v2154_4 = (has_head(v2154_3) ? constant_7 : Space{});
    const Space v2154_5 = subtract(constant_0,v2154_4);
    Space v2154_8;
    if (!v2154_5.empty()) {
      const Path v2155_6 = concat_path(p0,v2153_8_head);
      Space v2155_7_result;
      for (int v2155_7_label = 1; v2155_7_label <= 2; ++v2155_7_label) {
        const Space v2155_7_tail = child(v2153_8_tail,v2155_7_label);
        if (v2155_7_tail.empty()) continue;
        const Path v2155_7_head{v2155_7_label};
        const Space v2156_2 = singleton(v2155_7_head);
        const Space v2156_3 = intersect(constant_6,v2156_2);
        const Space v2156_4 = (has_head(v2156_3) ? constant_7 : Space{});
        const Space v2156_5 = subtract(constant_0,v2156_4);
        Space v2156_8;
        if (!v2156_5.empty()) {
          const Path v2157_6 = concat_path(v2155_6,v2155_7_head);
          const Space v2157_7 = routine_269(c, v2157_6, v2155_7_tail);
          v2156_8 = compose(v2156_5,v2157_7);
        }
        const Space v2156_9 = intersect(constant_6,v2156_2);
        const Space v2156_10 = (has_head(v2156_9) ? constant_7 : Space{});
        Space v2156_12;
        if (!v2156_10.empty()) {
          const Path v2158_6 = concat_path(v2155_6,v2155_7_head);
          const Space v2158_11 = routine_270(c, v2158_6, v2155_7_tail);
          v2156_12 = compose(v2156_10,v2158_11);
        }
        const Space v2156_13 = unite(v2156_8,v2156_12);
        v2155_7_result = unite(v2155_7_result,v2156_13);
      }
      const Space v2155_7 = std::move(v2155_7_result);
      v2154_8 = compose(v2154_5,v2155_7);
    }
    const Space v2154_9 = intersect(constant_6,v2154_2);
    const Space v2154_10 = (has_head(v2154_9) ? constant_7 : Space{});
    const Space v2154_11 = compose(v2154_10,v2153_8_tail);
    const Space v2154_12 = unite(v2154_8,v2154_11);
    v2153_8_result = unite(v2153_8_result,v2154_12);
  }
  const Space v2153_8 = std::move(v2153_8_result);
  return v2153_8;
}

static Space routine_245(Context& c, const Path& p0, const Space& s0) {
  Space v2159_6_result;
  for (int v2159_6_label = 1; v2159_6_label <= 2; ++v2159_6_label) {
    const Space v2159_6_tail = child(s0,v2159_6_label);
    if (v2159_6_tail.empty()) continue;
    const Path v2159_6_head{v2159_6_label};
    const Space v2160_2 = singleton(v2159_6_head);
    const Space v2160_3 = intersect(constant_6,v2160_2);
    const Space v2160_4 = (has_head(v2160_3) ? constant_7 : Space{});
    const Space v2160_5 = subtract(constant_0,v2160_4);
    Space v2160_6_result;
    for (int v2160_6_label = 1; v2160_6_label <= 2; ++v2160_6_label) {
      const Space v2160_6_tail = child(v2159_6_tail,v2160_6_label);
      if (v2160_6_tail.empty()) continue;
      const Path v2160_6_head{v2160_6_label};
      const Space v2161_2 = Space{};
      v2160_6_result = unite(v2160_6_result,v2161_2);
    }
    const Space v2160_6 = std::move(v2160_6_result);
    const Space v2160_7 = compose(v2160_5,v2160_6);
    const Space v2160_8 = intersect(constant_6,v2160_2);
    const Space v2160_9 = (has_head(v2160_8) ? constant_7 : Space{});
    Space v2160_12;
    if (!v2160_9.empty()) {
      const Path v2162_10 = concat_path(p0,v2159_6_head);
      Space v2162_11_result;
      for (int v2162_11_label = 1; v2162_11_label <= 2; ++v2162_11_label) {
        const Space v2162_11_tail = child(v2159_6_tail,v2162_11_label);
        if (v2162_11_tail.empty()) continue;
        const Path v2162_11_head{v2162_11_label};
        const Space v2163_2 = singleton(v2162_11_head);
        const Space v2163_3 = intersect(constant_6,v2163_2);
        const Space v2163_4 = (has_head(v2163_3) ? constant_7 : Space{});
        Space v2163_7;
        if (!v2163_4.empty()) {
          const Path v2164_5 = concat_path(v2162_10,v2162_11_head);
          const Space v2164_6 = routine_100(c, v2164_5, v2162_11_tail);
          v2163_7 = compose(v2163_4,v2164_6);
        }
        v2162_11_result = unite(v2162_11_result,v2163_7);
      }
      const Space v2162_11 = std::move(v2162_11_result);
      v2160_12 = compose(v2160_9,v2162_11);
    }
    const Space v2160_13 = unite(v2160_7,v2160_12);
    v2159_6_result = unite(v2159_6_result,v2160_13);
  }
  const Space v2159_6 = std::move(v2159_6_result);
  return v2159_6;
}

static Space routine_246(Context& c, const Path& p0, const Space& s0) {
  Space v2165_6_result;
  for (int v2165_6_label = 1; v2165_6_label <= 2; ++v2165_6_label) {
    const Space v2165_6_tail = child(s0,v2165_6_label);
    if (v2165_6_tail.empty()) continue;
    const Path v2165_6_head{v2165_6_label};
    const Space v2166_2 = singleton(v2165_6_head);
    const Space v2166_3 = intersect(constant_6,v2166_2);
    const Space v2166_4 = (has_head(v2166_3) ? constant_7 : Space{});
    const Space v2166_5 = subtract(constant_0,v2166_4);
    Space v2166_6_result;
    for (int v2166_6_label = 1; v2166_6_label <= 2; ++v2166_6_label) {
      const Space v2166_6_tail = child(v2165_6_tail,v2166_6_label);
      if (v2166_6_tail.empty()) continue;
      const Path v2166_6_head{v2166_6_label};
      const Space v2167_2 = Space{};
      v2166_6_result = unite(v2166_6_result,v2167_2);
    }
    const Space v2166_6 = std::move(v2166_6_result);
    const Space v2166_7 = compose(v2166_5,v2166_6);
    const Space v2166_8 = intersect(constant_6,v2166_2);
    const Space v2166_9 = (has_head(v2166_8) ? constant_7 : Space{});
    const Space v2166_10 = compose(v2166_9,constant_9);
    const Space v2166_11 = unite(v2166_7,v2166_10);
    v2165_6_result = unite(v2165_6_result,v2166_11);
  }
  const Space v2165_6 = std::move(v2165_6_result);
  return v2165_6;
}

static Space routine_247(Context& c, const Path& p0, const Space& s0) {
  Space v2168_6_result;
  for (int v2168_6_label = 1; v2168_6_label <= 2; ++v2168_6_label) {
    const Space v2168_6_tail = child(s0,v2168_6_label);
    if (v2168_6_tail.empty()) continue;
    const Path v2168_6_head{v2168_6_label};
    const Space v2169_2 = singleton(v2168_6_head);
    const Space v2169_3 = intersect(constant_6,v2169_2);
    const Space v2169_4 = (has_head(v2169_3) ? constant_7 : Space{});
    const Space v2169_5 = subtract(constant_0,v2169_4);
    Space v2169_6_result;
    for (int v2169_6_label = 1; v2169_6_label <= 2; ++v2169_6_label) {
      const Space v2169_6_tail = child(v2168_6_tail,v2169_6_label);
      if (v2169_6_tail.empty()) continue;
      const Path v2169_6_head{v2169_6_label};
      const Space v2170_2 = Space{};
      v2169_6_result = unite(v2169_6_result,v2170_2);
    }
    const Space v2169_6 = std::move(v2169_6_result);
    const Space v2169_7 = compose(v2169_5,v2169_6);
    const Space v2169_8 = intersect(constant_6,v2169_2);
    const Space v2169_9 = (has_head(v2169_8) ? constant_7 : Space{});
    Space v2169_12;
    if (!v2169_9.empty()) {
      const Path v2171_10 = concat_path(p0,v2168_6_head);
      Space v2171_11_result;
      for (int v2171_11_label = 1; v2171_11_label <= 2; ++v2171_11_label) {
        const Space v2171_11_tail = child(v2168_6_tail,v2171_11_label);
        if (v2171_11_tail.empty()) continue;
        const Path v2171_11_head{v2171_11_label};
        const Space v2172_2 = singleton(v2171_11_head);
        const Space v2172_3 = intersect(constant_6,v2172_2);
        const Space v2172_4 = (has_head(v2172_3) ? constant_7 : Space{});
        Space v2172_7;
        if (!v2172_4.empty()) {
          const Path v2173_5 = concat_path(v2171_10,v2171_11_head);
          const Space v2173_6 = routine_104(c, v2173_5, v2171_11_tail);
          v2172_7 = compose(v2172_4,v2173_6);
        }
        v2171_11_result = unite(v2171_11_result,v2172_7);
      }
      const Space v2171_11 = std::move(v2171_11_result);
      v2169_12 = compose(v2169_9,v2171_11);
    }
    const Space v2169_13 = unite(v2169_7,v2169_12);
    v2168_6_result = unite(v2168_6_result,v2169_13);
  }
  const Space v2168_6 = std::move(v2168_6_result);
  return v2168_6;
}

static Space routine_248(Context& c, const Path& p0, const Space& s0) {
  Space v2174_6_result;
  for (int v2174_6_label = 1; v2174_6_label <= 2; ++v2174_6_label) {
    const Space v2174_6_tail = child(s0,v2174_6_label);
    if (v2174_6_tail.empty()) continue;
    const Path v2174_6_head{v2174_6_label};
    const Space v2175_2 = singleton(v2174_6_head);
    const Space v2175_3 = intersect(constant_6,v2175_2);
    const Space v2175_4 = (has_head(v2175_3) ? constant_7 : Space{});
    const Space v2175_5 = subtract(constant_0,v2175_4);
    Space v2175_6_result;
    for (int v2175_6_label = 1; v2175_6_label <= 2; ++v2175_6_label) {
      const Space v2175_6_tail = child(v2174_6_tail,v2175_6_label);
      if (v2175_6_tail.empty()) continue;
      const Path v2175_6_head{v2175_6_label};
      const Space v2176_2 = Space{};
      v2175_6_result = unite(v2175_6_result,v2176_2);
    }
    const Space v2175_6 = std::move(v2175_6_result);
    const Space v2175_7 = compose(v2175_5,v2175_6);
    const Space v2175_8 = intersect(constant_6,v2175_2);
    const Space v2175_9 = (has_head(v2175_8) ? constant_7 : Space{});
    const Space v2175_10 = compose(v2175_9,constant_9);
    const Space v2175_11 = unite(v2175_7,v2175_10);
    v2174_6_result = unite(v2174_6_result,v2175_11);
  }
  const Space v2174_6 = std::move(v2174_6_result);
  return v2174_6;
}

static Space routine_249(Context& c, const Path& p0, const Space& s0) {
  Space v2177_6_result;
  for (int v2177_6_label = 1; v2177_6_label <= 2; ++v2177_6_label) {
    const Space v2177_6_tail = child(s0,v2177_6_label);
    if (v2177_6_tail.empty()) continue;
    const Path v2177_6_head{v2177_6_label};
    const Space v2178_2 = singleton(v2177_6_head);
    const Space v2178_3 = intersect(constant_6,v2178_2);
    const Space v2178_4 = (has_head(v2178_3) ? constant_7 : Space{});
    const Space v2178_5 = subtract(constant_0,v2178_4);
    Space v2178_6_result;
    for (int v2178_6_label = 1; v2178_6_label <= 2; ++v2178_6_label) {
      const Space v2178_6_tail = child(v2177_6_tail,v2178_6_label);
      if (v2178_6_tail.empty()) continue;
      const Path v2178_6_head{v2178_6_label};
      const Space v2179_2 = Space{};
      v2178_6_result = unite(v2178_6_result,v2179_2);
    }
    const Space v2178_6 = std::move(v2178_6_result);
    const Space v2178_7 = compose(v2178_5,v2178_6);
    const Space v2178_8 = intersect(constant_6,v2178_2);
    const Space v2178_9 = (has_head(v2178_8) ? constant_7 : Space{});
    Space v2178_12;
    if (!v2178_9.empty()) {
      const Path v2180_10 = concat_path(p0,v2177_6_head);
      Space v2180_11_result;
      for (int v2180_11_label = 1; v2180_11_label <= 2; ++v2180_11_label) {
        const Space v2180_11_tail = child(v2177_6_tail,v2180_11_label);
        if (v2180_11_tail.empty()) continue;
        const Path v2180_11_head{v2180_11_label};
        const Space v2181_2 = singleton(v2180_11_head);
        const Space v2181_3 = intersect(constant_6,v2181_2);
        const Space v2181_4 = (has_head(v2181_3) ? constant_7 : Space{});
        Space v2181_7;
        if (!v2181_4.empty()) {
          const Path v2182_5 = concat_path(v2180_10,v2180_11_head);
          const Space v2182_6 = routine_107(c, v2182_5, v2180_11_tail);
          v2181_7 = compose(v2181_4,v2182_6);
        }
        v2180_11_result = unite(v2180_11_result,v2181_7);
      }
      const Space v2180_11 = std::move(v2180_11_result);
      v2178_12 = compose(v2178_9,v2180_11);
    }
    const Space v2178_13 = unite(v2178_7,v2178_12);
    v2177_6_result = unite(v2177_6_result,v2178_13);
  }
  const Space v2177_6 = std::move(v2177_6_result);
  return v2177_6;
}

static Space routine_250(Context& c, const Path& p0, const Space& s0) {
  Space v2183_5_result;
  for (int v2183_5_label = 1; v2183_5_label <= 2; ++v2183_5_label) {
    const Space v2183_5_tail = child(s0,v2183_5_label);
    if (v2183_5_tail.empty()) continue;
    const Path v2183_5_head{v2183_5_label};
    const Space v2184_2 = singleton(v2183_5_head);
    const Space v2184_3 = intersect(constant_6,v2184_2);
    const Space v2184_4 = (has_head(v2184_3) ? constant_7 : Space{});
    const Space v2184_5 = subtract(constant_0,v2184_4);
    Space v2184_6_result;
    for (int v2184_6_label = 1; v2184_6_label <= 2; ++v2184_6_label) {
      const Space v2184_6_tail = child(v2183_5_tail,v2184_6_label);
      if (v2184_6_tail.empty()) continue;
      const Path v2184_6_head{v2184_6_label};
      const Space v2185_2 = Space{};
      v2184_6_result = unite(v2184_6_result,v2185_2);
    }
    const Space v2184_6 = std::move(v2184_6_result);
    const Space v2184_7 = compose(v2184_5,v2184_6);
    const Space v2184_8 = intersect(constant_6,v2184_2);
    const Space v2184_9 = (has_head(v2184_8) ? constant_7 : Space{});
    const Space v2184_10 = compose(v2184_9,v2183_5_tail);
    const Space v2184_11 = unite(v2184_7,v2184_10);
    v2183_5_result = unite(v2183_5_result,v2184_11);
  }
  const Space v2183_5 = std::move(v2183_5_result);
  return v2183_5;
}

static Space routine_251(Context& c, const Path& p0, const Space& s0) {
  Space v2186_6_result;
  for (int v2186_6_label = 1; v2186_6_label <= 2; ++v2186_6_label) {
    const Space v2186_6_tail = child(s0,v2186_6_label);
    if (v2186_6_tail.empty()) continue;
    const Path v2186_6_head{v2186_6_label};
    const Space v2187_2 = singleton(v2186_6_head);
    const Space v2187_3 = intersect(constant_6,v2187_2);
    const Space v2187_4 = (has_head(v2187_3) ? constant_7 : Space{});
    const Space v2187_5 = subtract(constant_0,v2187_4);
    Space v2187_6_result;
    for (int v2187_6_label = 1; v2187_6_label <= 2; ++v2187_6_label) {
      const Space v2187_6_tail = child(v2186_6_tail,v2187_6_label);
      if (v2187_6_tail.empty()) continue;
      const Path v2187_6_head{v2187_6_label};
      const Space v2188_2 = Space{};
      v2187_6_result = unite(v2187_6_result,v2188_2);
    }
    const Space v2187_6 = std::move(v2187_6_result);
    const Space v2187_7 = compose(v2187_5,v2187_6);
    const Space v2187_8 = intersect(constant_6,v2187_2);
    const Space v2187_9 = (has_head(v2187_8) ? constant_7 : Space{});
    Space v2187_12;
    if (!v2187_9.empty()) {
      const Path v2189_10 = concat_path(p0,v2186_6_head);
      Space v2189_11_result;
      for (int v2189_11_label = 1; v2189_11_label <= 2; ++v2189_11_label) {
        const Space v2189_11_tail = child(v2186_6_tail,v2189_11_label);
        if (v2189_11_tail.empty()) continue;
        const Path v2189_11_head{v2189_11_label};
        const Space v2190_2 = singleton(v2189_11_head);
        const Space v2190_3 = intersect(constant_6,v2190_2);
        const Space v2190_4 = (has_head(v2190_3) ? constant_7 : Space{});
        Space v2190_7;
        if (!v2190_4.empty()) {
          const Path v2191_5 = concat_path(v2189_10,v2189_11_head);
          const Space v2191_6 = routine_80(c, v2191_5, v2189_11_tail);
          v2190_7 = compose(v2190_4,v2191_6);
        }
        v2189_11_result = unite(v2189_11_result,v2190_7);
      }
      const Space v2189_11 = std::move(v2189_11_result);
      v2187_12 = compose(v2187_9,v2189_11);
    }
    const Space v2187_13 = unite(v2187_7,v2187_12);
    v2186_6_result = unite(v2186_6_result,v2187_13);
  }
  const Space v2186_6 = std::move(v2186_6_result);
  return v2186_6;
}

static Space routine_252(Context& c, const Path& p0, const Space& s0) {
  Space v2192_8_result;
  for (int v2192_8_label = 1; v2192_8_label <= 2; ++v2192_8_label) {
    const Space v2192_8_tail = child(s0,v2192_8_label);
    if (v2192_8_tail.empty()) continue;
    const Path v2192_8_head{v2192_8_label};
    const Space v2193_2 = singleton(v2192_8_head);
    const Space v2193_3 = intersect(constant_6,v2193_2);
    const Space v2193_4 = (has_head(v2193_3) ? constant_7 : Space{});
    const Space v2193_5 = subtract(constant_0,v2193_4);
    Space v2193_6_result;
    for (int v2193_6_label = 1; v2193_6_label <= 2; ++v2193_6_label) {
      const Space v2193_6_tail = child(v2192_8_tail,v2193_6_label);
      if (v2193_6_tail.empty()) continue;
      const Path v2193_6_head{v2193_6_label};
      const Space v2194_2 = Space{};
      v2193_6_result = unite(v2193_6_result,v2194_2);
    }
    const Space v2193_6 = std::move(v2193_6_result);
    const Space v2193_7 = compose(v2193_5,v2193_6);
    const Space v2193_8 = intersect(constant_6,v2193_2);
    const Space v2193_9 = (has_head(v2193_8) ? constant_7 : Space{});
    Space v2193_12;
    if (!v2193_9.empty()) {
      const Path v2195_10 = concat_path(p0,v2192_8_head);
      Space v2195_11_result;
      for (int v2195_11_label = 1; v2195_11_label <= 2; ++v2195_11_label) {
        const Space v2195_11_tail = child(v2192_8_tail,v2195_11_label);
        if (v2195_11_tail.empty()) continue;
        const Path v2195_11_head{v2195_11_label};
        const Space v2196_2 = singleton(v2195_11_head);
        const Space v2196_3 = intersect(constant_6,v2196_2);
        const Space v2196_4 = (has_head(v2196_3) ? constant_7 : Space{});
        const Space v2196_5 = subtract(constant_0,v2196_4);
        Space v2196_7;
        if (!v2196_5.empty()) {
          const Space v2197_6 = routine_122(c, v2195_11_head, v2195_10, v2195_11_tail);
          v2196_7 = compose(v2196_5,v2197_6);
        }
        const Space v2196_8 = intersect(constant_6,v2196_2);
        const Space v2196_9 = (has_head(v2196_8) ? constant_7 : Space{});
        Space v2196_11;
        if (!v2196_9.empty()) {
          const Space v2198_10 = routine_123(c, v2195_11_head, v2195_10, v2195_11_tail);
          v2196_11 = compose(v2196_9,v2198_10);
        }
        const Space v2196_12 = unite(v2196_7,v2196_11);
        v2195_11_result = unite(v2195_11_result,v2196_12);
      }
      const Space v2195_11 = std::move(v2195_11_result);
      v2193_12 = compose(v2193_9,v2195_11);
    }
    const Space v2193_13 = unite(v2193_7,v2193_12);
    v2192_8_result = unite(v2192_8_result,v2193_13);
  }
  const Space v2192_8 = std::move(v2192_8_result);
  return v2192_8;
}

static Space routine_253(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2199_12_result;
  for (int v2199_12_label = 1; v2199_12_label <= 2; ++v2199_12_label) {
    const Space v2199_12_tail = child(s0,v2199_12_label);
    if (v2199_12_tail.empty()) continue;
    const Path v2199_12_head{v2199_12_label};
    const Space v2200_2 = singleton(v2199_12_head);
    const Space v2200_3 = intersect(constant_6,v2200_2);
    const Space v2200_4 = (has_head(v2200_3) ? constant_7 : Space{});
    const Space v2200_5 = subtract(constant_0,v2200_4);
    Space v2200_8;
    if (!v2200_5.empty()) {
      const Path v2201_6 = concat_path(p0,v2199_12_head);
      Space v2201_7_result;
      for (int v2201_7_label = 1; v2201_7_label <= 2; ++v2201_7_label) {
        const Space v2201_7_tail = child(v2199_12_tail,v2201_7_label);
        if (v2201_7_tail.empty()) continue;
        const Path v2201_7_head{v2201_7_label};
        const Space v2202_2 = singleton(v2201_7_head);
        const Space v2202_3 = intersect(constant_6,v2202_2);
        const Space v2202_4 = (has_head(v2202_3) ? constant_7 : Space{});
        const Space v2202_5 = subtract(constant_0,v2202_4);
        Space v2202_8;
        if (!v2202_5.empty()) {
          const Path v2203_6 = concat_path(v2201_6,v2201_7_head);
          const Space v2203_7 = routine_271(c, v2203_6, p1, v2201_7_tail);
          v2202_8 = compose(v2202_5,v2203_7);
        }
        const Space v2202_9 = intersect(constant_6,v2202_2);
        const Space v2202_10 = (has_head(v2202_9) ? constant_7 : Space{});
        Space v2202_12;
        if (!v2202_10.empty()) {
          const Path v2204_6 = concat_path(v2201_6,v2201_7_head);
          const Space v2204_11 = routine_272(c, v2204_6, p1, v2201_7_tail);
          v2202_12 = compose(v2202_10,v2204_11);
        }
        const Space v2202_13 = unite(v2202_8,v2202_12);
        v2201_7_result = unite(v2201_7_result,v2202_13);
      }
      const Space v2201_7 = std::move(v2201_7_result);
      v2200_8 = compose(v2200_5,v2201_7);
    }
    const Space v2200_9 = intersect(constant_6,v2200_2);
    const Space v2200_10 = (has_head(v2200_9) ? constant_7 : Space{});
    Space v2200_12;
    if (!v2200_10.empty()) {
      const Path v2205_6 = concat_path(p0,v2199_12_head);
      Space v2205_11_result;
      for (int v2205_11_label = 1; v2205_11_label <= 2; ++v2205_11_label) {
        const Space v2205_11_tail = child(v2199_12_tail,v2205_11_label);
        if (v2205_11_tail.empty()) continue;
        const Path v2205_11_head{v2205_11_label};
        const Space v2206_2 = singleton(v2205_11_head);
        const Space v2206_3 = intersect(constant_6,v2206_2);
        const Space v2206_4 = (has_head(v2206_3) ? constant_7 : Space{});
        const Space v2206_5 = subtract(constant_0,v2206_4);
        Space v2206_8;
        if (!v2206_5.empty()) {
          const Path v2207_6 = concat_path(v2205_6,v2205_11_head);
          const Space v2207_7 = routine_271(c, v2207_6, p1, v2205_11_tail);
          v2206_8 = compose(v2206_5,v2207_7);
        }
        const Space v2206_9 = intersect(constant_6,v2206_2);
        const Space v2206_10 = (has_head(v2206_9) ? constant_7 : Space{});
        Space v2206_12;
        if (!v2206_10.empty()) {
          const Path v2208_6 = concat_path(v2205_6,v2205_11_head);
          const Space v2208_11 = routine_137(c, v2208_6, p1, v2205_11_tail);
          v2206_12 = compose(v2206_10,v2208_11);
        }
        const Space v2206_13 = unite(v2206_8,v2206_12);
        v2205_11_result = unite(v2205_11_result,v2206_13);
      }
      const Space v2205_11 = std::move(v2205_11_result);
      v2200_12 = compose(v2200_10,v2205_11);
    }
    const Space v2200_13 = unite(v2200_8,v2200_12);
    v2199_12_result = unite(v2199_12_result,v2200_13);
  }
  const Space v2199_12 = std::move(v2199_12_result);
  return v2199_12;
}

static Space routine_254(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2209_7 = unwrap(constant_12,p1);
  const Space v2209_9 = unwrap(constant_12,p0);
  Space v2209_13_result;
  for (int v2209_13_label = 1; v2209_13_label <= 2; ++v2209_13_label) {
    const Space v2209_13_tail = child(s0,v2209_13_label);
    if (v2209_13_tail.empty()) continue;
    const Path v2209_13_head{v2209_13_label};
    const Space v2210_2 = singleton(v2209_13_head);
    const Space v2210_3 = intersect(constant_6,v2210_2);
    const Space v2210_4 = (has_head(v2210_3) ? constant_7 : Space{});
    const Space v2210_5 = subtract(constant_0,v2210_4);
    Space v2210_8;
    if (!v2210_5.empty()) {
      const Path v2211_6 = concat_path(p0,v2209_13_head);
      Space v2211_7_result;
      for (int v2211_7_label = 1; v2211_7_label <= 2; ++v2211_7_label) {
        const Space v2211_7_tail = child(v2209_13_tail,v2211_7_label);
        if (v2211_7_tail.empty()) continue;
        const Path v2211_7_head{v2211_7_label};
        const Space v2212_2 = singleton(v2211_7_head);
        const Space v2212_3 = intersect(constant_6,v2212_2);
        const Space v2212_4 = (has_head(v2212_3) ? constant_7 : Space{});
        const Space v2212_5 = subtract(constant_0,v2212_4);
        Space v2212_8;
        if (!v2212_5.empty()) {
          const Path v2213_6 = concat_path(v2211_6,v2211_7_head);
          const Space v2213_7 = routine_271(c, v2213_6, p1, v2211_7_tail);
          v2212_8 = compose(v2212_5,v2213_7);
        }
        const Space v2212_9 = intersect(constant_6,v2212_2);
        const Space v2212_10 = (has_head(v2212_9) ? constant_7 : Space{});
        Space v2212_12;
        if (!v2212_10.empty()) {
          const Path v2214_6 = concat_path(v2211_6,v2211_7_head);
          const Space v2214_11 = routine_272(c, v2214_6, p1, v2211_7_tail);
          v2212_12 = compose(v2212_10,v2214_11);
        }
        const Space v2212_13 = unite(v2212_8,v2212_12);
        v2211_7_result = unite(v2211_7_result,v2212_13);
      }
      const Space v2211_7 = std::move(v2211_7_result);
      v2210_8 = compose(v2210_5,v2211_7);
    }
    const Space v2210_9 = intersect(constant_6,v2210_2);
    const Space v2210_10 = (has_head(v2210_9) ? constant_7 : Space{});
    const Space v2210_11 = unwrap(v2209_9,v2209_13_head);
    const Space v2210_12 = compose(v2209_7,v2210_11);
    const Path v2215_6 = concat_path(p0,v2209_13_head);
    const Path v2210_13 = concat_path(p1,v2215_6);
    const Space v2210_14 = singleton(v2210_13);
    const Space v2210_15 = subtract(v2210_12,v2210_14);
    const Space v2210_16 = compose(v2210_10,v2210_15);
    const Space v2210_17 = unite(v2210_8,v2210_16);
    v2209_13_result = unite(v2209_13_result,v2210_17);
  }
  const Space v2209_13 = std::move(v2209_13_result);
  return v2209_13;
}

static Space routine_255(Context& c, const Path& p0, const Space& s0) {
  Space v2216_2_result;
  for (int v2216_2_label = 1; v2216_2_label <= 2; ++v2216_2_label) {
    const Space v2216_2_tail = child(s0,v2216_2_label);
    if (v2216_2_tail.empty()) continue;
    const Path v2216_2_head{v2216_2_label};
    const Space v2217_2 = Space{};
    v2216_2_result = unite(v2216_2_result,v2217_2);
  }
  const Space v2216_2 = std::move(v2216_2_result);
  return v2216_2;
}

static Space routine_256(Context& c, const Path& p0, const Space& s0) {
  Space v2218_4_result;
  for (int v2218_4_label = 1; v2218_4_label <= 2; ++v2218_4_label) {
    const Space v2218_4_tail = child(s0,v2218_4_label);
    if (v2218_4_tail.empty()) continue;
    const Path v2218_4_head{v2218_4_label};
    const Space v2219_2 = singleton(v2218_4_head);
    const Space v2219_3 = intersect(constant_6,v2219_2);
    const Space v2219_4 = (has_head(v2219_3) ? constant_7 : Space{});
    const Space v2219_5 = compose(v2219_4,constant_9);
    v2218_4_result = unite(v2218_4_result,v2219_5);
  }
  const Space v2218_4 = std::move(v2218_4_result);
  return v2218_4;
}

static Space routine_257(Context& c, const Path& p0, const Space& s0) {
  Space v2220_2_result;
  for (int v2220_2_label = 1; v2220_2_label <= 2; ++v2220_2_label) {
    const Space v2220_2_tail = child(s0,v2220_2_label);
    if (v2220_2_tail.empty()) continue;
    const Path v2220_2_head{v2220_2_label};
    const Space v2221_2 = Space{};
    v2220_2_result = unite(v2220_2_result,v2221_2);
  }
  const Space v2220_2 = std::move(v2220_2_result);
  return v2220_2;
}

static Space routine_258(Context& c, const Path& p0, const Space& s0) {
  Space v2222_4_result;
  for (int v2222_4_label = 1; v2222_4_label <= 2; ++v2222_4_label) {
    const Space v2222_4_tail = child(s0,v2222_4_label);
    if (v2222_4_tail.empty()) continue;
    const Path v2222_4_head{v2222_4_label};
    const Space v2223_2 = singleton(v2222_4_head);
    const Space v2223_3 = intersect(constant_6,v2223_2);
    const Space v2223_4 = (has_head(v2223_3) ? constant_7 : Space{});
    const Space v2223_5 = compose(v2223_4,constant_9);
    v2222_4_result = unite(v2222_4_result,v2223_5);
  }
  const Space v2222_4 = std::move(v2222_4_result);
  return v2222_4;
}

static Space routine_259(Context& c, const Path& p0, const Space& s0) {
  Space v2224_2_result;
  for (int v2224_2_label = 1; v2224_2_label <= 2; ++v2224_2_label) {
    const Space v2224_2_tail = child(s0,v2224_2_label);
    if (v2224_2_tail.empty()) continue;
    const Path v2224_2_head{v2224_2_label};
    const Space v2225_2 = Space{};
    v2224_2_result = unite(v2224_2_result,v2225_2);
  }
  const Space v2224_2 = std::move(v2224_2_result);
  return v2224_2;
}

static Space routine_260(Context& c, const Path& p0, const Space& s0) {
  Space v2226_3_result;
  for (int v2226_3_label = 1; v2226_3_label <= 2; ++v2226_3_label) {
    const Space v2226_3_tail = child(s0,v2226_3_label);
    if (v2226_3_tail.empty()) continue;
    const Path v2226_3_head{v2226_3_label};
    const Space v2227_2 = singleton(v2226_3_head);
    const Space v2227_3 = intersect(constant_6,v2227_2);
    const Space v2227_4 = (has_head(v2227_3) ? constant_7 : Space{});
    const Space v2227_5 = compose(v2227_4,v2226_3_tail);
    v2226_3_result = unite(v2226_3_result,v2227_5);
  }
  const Space v2226_3 = std::move(v2226_3_result);
  return v2226_3;
}

static Space routine_261(Context& c, const Path& p0, const Space& s0) {
  Space v2228_2_result;
  for (int v2228_2_label = 1; v2228_2_label <= 2; ++v2228_2_label) {
    const Space v2228_2_tail = child(s0,v2228_2_label);
    if (v2228_2_tail.empty()) continue;
    const Path v2228_2_head{v2228_2_label};
    const Space v2229_2 = Space{};
    v2228_2_result = unite(v2228_2_result,v2229_2);
  }
  const Space v2228_2 = std::move(v2228_2_result);
  return v2228_2;
}

static Space routine_262(Context& c, const Path& p0, const Space& s0) {
  Space v2230_6_result;
  for (int v2230_6_label = 1; v2230_6_label <= 2; ++v2230_6_label) {
    const Space v2230_6_tail = child(s0,v2230_6_label);
    if (v2230_6_tail.empty()) continue;
    const Path v2230_6_head{v2230_6_label};
    const Space v2231_2 = singleton(v2230_6_head);
    const Space v2231_3 = intersect(constant_6,v2231_2);
    const Space v2231_4 = (has_head(v2231_3) ? constant_7 : Space{});
    Space v2231_7;
    if (!v2231_4.empty()) {
      const Path v2232_5 = concat_path(p0,v2230_6_head);
      Space v2232_6_result;
      for (int v2232_6_label = 1; v2232_6_label <= 2; ++v2232_6_label) {
        const Space v2232_6_tail = child(v2230_6_tail,v2232_6_label);
        if (v2232_6_tail.empty()) continue;
        const Path v2232_6_head{v2232_6_label};
        const Space v2233_2 = singleton(v2232_6_head);
        const Space v2233_3 = intersect(constant_6,v2233_2);
        const Space v2233_4 = (has_head(v2233_3) ? constant_7 : Space{});
        const Space v2233_5 = subtract(constant_0,v2233_4);
        Space v2233_7;
        if (!v2233_5.empty()) {
          const Space v2234_6 = routine_122(c, v2232_6_head, v2232_5, v2232_6_tail);
          v2233_7 = compose(v2233_5,v2234_6);
        }
        const Space v2233_8 = intersect(constant_6,v2233_2);
        const Space v2233_9 = (has_head(v2233_8) ? constant_7 : Space{});
        Space v2233_11;
        if (!v2233_9.empty()) {
          const Space v2235_10 = routine_123(c, v2232_6_head, v2232_5, v2232_6_tail);
          v2233_11 = compose(v2233_9,v2235_10);
        }
        const Space v2233_12 = unite(v2233_7,v2233_11);
        v2232_6_result = unite(v2232_6_result,v2233_12);
      }
      const Space v2232_6 = std::move(v2232_6_result);
      v2231_7 = compose(v2231_4,v2232_6);
    }
    v2230_6_result = unite(v2230_6_result,v2231_7);
  }
  const Space v2230_6 = std::move(v2230_6_result);
  return v2230_6;
}

static Space routine_263(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2236_12_result;
  for (int v2236_12_label = 1; v2236_12_label <= 2; ++v2236_12_label) {
    const Space v2236_12_tail = child(s0,v2236_12_label);
    if (v2236_12_tail.empty()) continue;
    const Path v2236_12_head{v2236_12_label};
    const Space v2237_2 = singleton(v2236_12_head);
    const Space v2237_3 = intersect(constant_6,v2237_2);
    const Space v2237_4 = (has_head(v2237_3) ? constant_7 : Space{});
    const Space v2237_5 = subtract(constant_0,v2237_4);
    Space v2237_8;
    if (!v2237_5.empty()) {
      const Path v2238_6 = concat_path(p0,v2236_12_head);
      Space v2238_7_result;
      for (int v2238_7_label = 1; v2238_7_label <= 2; ++v2238_7_label) {
        const Space v2238_7_tail = child(v2236_12_tail,v2238_7_label);
        if (v2238_7_tail.empty()) continue;
        const Path v2238_7_head{v2238_7_label};
        const Space v2239_2 = singleton(v2238_7_head);
        const Space v2239_3 = intersect(constant_6,v2239_2);
        const Space v2239_4 = (has_head(v2239_3) ? constant_7 : Space{});
        const Space v2239_5 = subtract(constant_0,v2239_4);
        Space v2239_8;
        if (!v2239_5.empty()) {
          const Path v2240_6 = concat_path(v2238_6,v2238_7_head);
          const Space v2240_7 = routine_273(c, v2240_6, p1, v2238_7_tail);
          v2239_8 = compose(v2239_5,v2240_7);
        }
        const Space v2239_9 = intersect(constant_6,v2239_2);
        const Space v2239_10 = (has_head(v2239_9) ? constant_7 : Space{});
        Space v2239_12;
        if (!v2239_10.empty()) {
          const Path v2241_6 = concat_path(v2238_6,v2238_7_head);
          const Space v2241_11 = routine_274(c, v2241_6, p1, v2238_7_tail);
          v2239_12 = compose(v2239_10,v2241_11);
        }
        const Space v2239_13 = unite(v2239_8,v2239_12);
        v2238_7_result = unite(v2238_7_result,v2239_13);
      }
      const Space v2238_7 = std::move(v2238_7_result);
      v2237_8 = compose(v2237_5,v2238_7);
    }
    const Space v2237_9 = intersect(constant_6,v2237_2);
    const Space v2237_10 = (has_head(v2237_9) ? constant_7 : Space{});
    Space v2237_12;
    if (!v2237_10.empty()) {
      const Path v2242_6 = concat_path(p0,v2236_12_head);
      Space v2242_11_result;
      for (int v2242_11_label = 1; v2242_11_label <= 2; ++v2242_11_label) {
        const Space v2242_11_tail = child(v2236_12_tail,v2242_11_label);
        if (v2242_11_tail.empty()) continue;
        const Path v2242_11_head{v2242_11_label};
        const Space v2243_2 = singleton(v2242_11_head);
        const Space v2243_3 = intersect(constant_6,v2243_2);
        const Space v2243_4 = (has_head(v2243_3) ? constant_7 : Space{});
        const Space v2243_5 = subtract(constant_0,v2243_4);
        Space v2243_8;
        if (!v2243_5.empty()) {
          const Path v2244_6 = concat_path(v2242_6,v2242_11_head);
          const Space v2244_7 = routine_273(c, v2244_6, p1, v2242_11_tail);
          v2243_8 = compose(v2243_5,v2244_7);
        }
        const Space v2243_9 = intersect(constant_6,v2243_2);
        const Space v2243_10 = (has_head(v2243_9) ? constant_7 : Space{});
        Space v2243_12;
        if (!v2243_10.empty()) {
          const Path v2245_6 = concat_path(v2242_6,v2242_11_head);
          const Space v2245_11 = routine_137(c, v2245_6, p1, v2242_11_tail);
          v2243_12 = compose(v2243_10,v2245_11);
        }
        const Space v2243_13 = unite(v2243_8,v2243_12);
        v2242_11_result = unite(v2242_11_result,v2243_13);
      }
      const Space v2242_11 = std::move(v2242_11_result);
      v2237_12 = compose(v2237_10,v2242_11);
    }
    const Space v2237_13 = unite(v2237_8,v2237_12);
    v2236_12_result = unite(v2236_12_result,v2237_13);
  }
  const Space v2236_12 = std::move(v2236_12_result);
  return v2236_12;
}

static Space routine_264(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2246_7 = unwrap(constant_12,p1);
  const Space v2246_9 = unwrap(constant_12,p0);
  Space v2246_13_result;
  for (int v2246_13_label = 1; v2246_13_label <= 2; ++v2246_13_label) {
    const Space v2246_13_tail = child(s0,v2246_13_label);
    if (v2246_13_tail.empty()) continue;
    const Path v2246_13_head{v2246_13_label};
    const Space v2247_2 = singleton(v2246_13_head);
    const Space v2247_3 = intersect(constant_6,v2247_2);
    const Space v2247_4 = (has_head(v2247_3) ? constant_7 : Space{});
    const Space v2247_5 = subtract(constant_0,v2247_4);
    Space v2247_8;
    if (!v2247_5.empty()) {
      const Path v2248_6 = concat_path(p0,v2246_13_head);
      Space v2248_7_result;
      for (int v2248_7_label = 1; v2248_7_label <= 2; ++v2248_7_label) {
        const Space v2248_7_tail = child(v2246_13_tail,v2248_7_label);
        if (v2248_7_tail.empty()) continue;
        const Path v2248_7_head{v2248_7_label};
        const Space v2249_2 = singleton(v2248_7_head);
        const Space v2249_3 = intersect(constant_6,v2249_2);
        const Space v2249_4 = (has_head(v2249_3) ? constant_7 : Space{});
        const Space v2249_5 = subtract(constant_0,v2249_4);
        Space v2249_8;
        if (!v2249_5.empty()) {
          const Path v2250_6 = concat_path(v2248_6,v2248_7_head);
          const Space v2250_7 = routine_273(c, v2250_6, p1, v2248_7_tail);
          v2249_8 = compose(v2249_5,v2250_7);
        }
        const Space v2249_9 = intersect(constant_6,v2249_2);
        const Space v2249_10 = (has_head(v2249_9) ? constant_7 : Space{});
        Space v2249_12;
        if (!v2249_10.empty()) {
          const Path v2251_6 = concat_path(v2248_6,v2248_7_head);
          const Space v2251_11 = routine_274(c, v2251_6, p1, v2248_7_tail);
          v2249_12 = compose(v2249_10,v2251_11);
        }
        const Space v2249_13 = unite(v2249_8,v2249_12);
        v2248_7_result = unite(v2248_7_result,v2249_13);
      }
      const Space v2248_7 = std::move(v2248_7_result);
      v2247_8 = compose(v2247_5,v2248_7);
    }
    const Space v2247_9 = intersect(constant_6,v2247_2);
    const Space v2247_10 = (has_head(v2247_9) ? constant_7 : Space{});
    const Space v2247_11 = unwrap(v2246_9,v2246_13_head);
    const Space v2247_12 = compose(v2246_7,v2247_11);
    const Path v2252_6 = concat_path(p0,v2246_13_head);
    const Path v2247_13 = concat_path(p1,v2252_6);
    const Space v2247_14 = singleton(v2247_13);
    const Space v2247_15 = subtract(v2247_12,v2247_14);
    const Space v2247_16 = compose(v2247_10,v2247_15);
    const Space v2247_17 = unite(v2247_8,v2247_16);
    v2246_13_result = unite(v2246_13_result,v2247_17);
  }
  const Space v2246_13 = std::move(v2246_13_result);
  return v2246_13;
}

static Space routine_265(Context& c, const Path& p0, const Space& s0) {
  Space v2253_2_result;
  for (int v2253_2_label = 1; v2253_2_label <= 2; ++v2253_2_label) {
    const Space v2253_2_tail = child(s0,v2253_2_label);
    if (v2253_2_tail.empty()) continue;
    const Path v2253_2_head{v2253_2_label};
    const Space v2254_2 = Space{};
    v2253_2_result = unite(v2253_2_result,v2254_2);
  }
  const Space v2253_2 = std::move(v2253_2_result);
  return v2253_2;
}

static Space routine_266(Context& c, const Path& p0, const Space& s0) {
  Space v2255_4_result;
  for (int v2255_4_label = 1; v2255_4_label <= 2; ++v2255_4_label) {
    const Space v2255_4_tail = child(s0,v2255_4_label);
    if (v2255_4_tail.empty()) continue;
    const Path v2255_4_head{v2255_4_label};
    const Space v2256_2 = singleton(v2255_4_head);
    const Space v2256_3 = intersect(constant_6,v2256_2);
    const Space v2256_4 = (has_head(v2256_3) ? constant_7 : Space{});
    const Space v2256_5 = compose(v2256_4,constant_9);
    v2255_4_result = unite(v2255_4_result,v2256_5);
  }
  const Space v2255_4 = std::move(v2255_4_result);
  return v2255_4;
}

static Space routine_267(Context& c, const Path& p0, const Space& s0) {
  Space v2257_2_result;
  for (int v2257_2_label = 1; v2257_2_label <= 2; ++v2257_2_label) {
    const Space v2257_2_tail = child(s0,v2257_2_label);
    if (v2257_2_tail.empty()) continue;
    const Path v2257_2_head{v2257_2_label};
    const Space v2258_2 = Space{};
    v2257_2_result = unite(v2257_2_result,v2258_2);
  }
  const Space v2257_2 = std::move(v2257_2_result);
  return v2257_2;
}

static Space routine_268(Context& c, const Path& p0, const Space& s0) {
  Space v2259_4_result;
  for (int v2259_4_label = 1; v2259_4_label <= 2; ++v2259_4_label) {
    const Space v2259_4_tail = child(s0,v2259_4_label);
    if (v2259_4_tail.empty()) continue;
    const Path v2259_4_head{v2259_4_label};
    const Space v2260_2 = singleton(v2259_4_head);
    const Space v2260_3 = intersect(constant_6,v2260_2);
    const Space v2260_4 = (has_head(v2260_3) ? constant_7 : Space{});
    const Space v2260_5 = compose(v2260_4,constant_9);
    v2259_4_result = unite(v2259_4_result,v2260_5);
  }
  const Space v2259_4 = std::move(v2259_4_result);
  return v2259_4;
}

static Space routine_269(Context& c, const Path& p0, const Space& s0) {
  Space v2261_2_result;
  for (int v2261_2_label = 1; v2261_2_label <= 2; ++v2261_2_label) {
    const Space v2261_2_tail = child(s0,v2261_2_label);
    if (v2261_2_tail.empty()) continue;
    const Path v2261_2_head{v2261_2_label};
    const Space v2262_2 = Space{};
    v2261_2_result = unite(v2261_2_result,v2262_2);
  }
  const Space v2261_2 = std::move(v2261_2_result);
  return v2261_2;
}

static Space routine_270(Context& c, const Path& p0, const Space& s0) {
  Space v2263_3_result;
  for (int v2263_3_label = 1; v2263_3_label <= 2; ++v2263_3_label) {
    const Space v2263_3_tail = child(s0,v2263_3_label);
    if (v2263_3_tail.empty()) continue;
    const Path v2263_3_head{v2263_3_label};
    const Space v2264_2 = singleton(v2263_3_head);
    const Space v2264_3 = intersect(constant_6,v2264_2);
    const Space v2264_4 = (has_head(v2264_3) ? constant_7 : Space{});
    const Space v2264_5 = compose(v2264_4,v2263_3_tail);
    v2263_3_result = unite(v2263_3_result,v2264_5);
  }
  const Space v2263_3 = std::move(v2263_3_result);
  return v2263_3;
}

static Space routine_271(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2265_7_result;
  for (int v2265_7_label = 1; v2265_7_label <= 2; ++v2265_7_label) {
    const Space v2265_7_tail = child(s0,v2265_7_label);
    if (v2265_7_tail.empty()) continue;
    const Path v2265_7_head{v2265_7_label};
    const Space v2266_2 = singleton(v2265_7_head);
    const Space v2266_3 = intersect(constant_6,v2266_2);
    const Space v2266_4 = (has_head(v2266_3) ? constant_7 : Space{});
    const Space v2266_5 = subtract(constant_0,v2266_4);
    Space v2266_6_result;
    for (int v2266_6_label = 1; v2266_6_label <= 2; ++v2266_6_label) {
      const Space v2266_6_tail = child(v2265_7_tail,v2266_6_label);
      if (v2266_6_tail.empty()) continue;
      const Path v2266_6_head{v2266_6_label};
      const Space v2267_2 = Space{};
      v2266_6_result = unite(v2266_6_result,v2267_2);
    }
    const Space v2266_6 = std::move(v2266_6_result);
    const Space v2266_7 = compose(v2266_5,v2266_6);
    const Space v2266_8 = intersect(constant_6,v2266_2);
    const Space v2266_9 = (has_head(v2266_8) ? constant_7 : Space{});
    Space v2266_12;
    if (!v2266_9.empty()) {
      const Path v2268_10 = concat_path(p0,v2265_7_head);
      Space v2268_11_result;
      for (int v2268_11_label = 1; v2268_11_label <= 2; ++v2268_11_label) {
        const Space v2268_11_tail = child(v2265_7_tail,v2268_11_label);
        if (v2268_11_tail.empty()) continue;
        const Path v2268_11_head{v2268_11_label};
        const Space v2269_2 = singleton(v2268_11_head);
        const Space v2269_3 = intersect(constant_6,v2269_2);
        const Space v2269_4 = (has_head(v2269_3) ? constant_7 : Space{});
        Space v2269_7;
        if (!v2269_4.empty()) {
          const Path v2270_5 = concat_path(v2268_10,v2268_11_head);
          const Space v2270_6 = routine_137(c, v2270_5, p1, v2268_11_tail);
          v2269_7 = compose(v2269_4,v2270_6);
        }
        v2268_11_result = unite(v2268_11_result,v2269_7);
      }
      const Space v2268_11 = std::move(v2268_11_result);
      v2266_12 = compose(v2266_9,v2268_11);
    }
    const Space v2266_13 = unite(v2266_7,v2266_12);
    v2265_7_result = unite(v2265_7_result,v2266_13);
  }
  const Space v2265_7 = std::move(v2265_7_result);
  return v2265_7;
}

static Space routine_272(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2271_7 = unwrap(constant_12,p1);
  const Space v2271_9 = unwrap(constant_12,p0);
  Space v2271_10_result;
  for (int v2271_10_label = 1; v2271_10_label <= 2; ++v2271_10_label) {
    const Space v2271_10_tail = child(s0,v2271_10_label);
    if (v2271_10_tail.empty()) continue;
    const Path v2271_10_head{v2271_10_label};
    const Space v2272_2 = singleton(v2271_10_head);
    const Space v2272_3 = intersect(constant_6,v2272_2);
    const Space v2272_4 = (has_head(v2272_3) ? constant_7 : Space{});
    const Space v2272_5 = subtract(constant_0,v2272_4);
    Space v2272_6_result;
    for (int v2272_6_label = 1; v2272_6_label <= 2; ++v2272_6_label) {
      const Space v2272_6_tail = child(v2271_10_tail,v2272_6_label);
      if (v2272_6_tail.empty()) continue;
      const Path v2272_6_head{v2272_6_label};
      const Space v2273_2 = Space{};
      v2272_6_result = unite(v2272_6_result,v2273_2);
    }
    const Space v2272_6 = std::move(v2272_6_result);
    const Space v2272_7 = compose(v2272_5,v2272_6);
    const Space v2272_8 = intersect(constant_6,v2272_2);
    const Space v2272_9 = (has_head(v2272_8) ? constant_7 : Space{});
    const Space v2272_10 = unwrap(v2271_9,v2271_10_head);
    const Space v2272_11 = compose(v2271_7,v2272_10);
    const Path v2272_12 = concat_path(p0,v2271_10_head);
    const Path v2272_13 = concat_path(p1,v2272_12);
    const Space v2272_14 = singleton(v2272_13);
    const Space v2272_15 = subtract(v2272_11,v2272_14);
    const Space v2272_16 = compose(v2272_9,v2272_15);
    const Space v2272_17 = unite(v2272_7,v2272_16);
    v2271_10_result = unite(v2271_10_result,v2272_17);
  }
  const Space v2271_10 = std::move(v2271_10_result);
  return v2271_10;
}

static Space routine_273(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  Space v2274_3_result;
  for (int v2274_3_label = 1; v2274_3_label <= 2; ++v2274_3_label) {
    const Space v2274_3_tail = child(s0,v2274_3_label);
    if (v2274_3_tail.empty()) continue;
    const Path v2274_3_head{v2274_3_label};
    const Space v2275_2 = Space{};
    v2274_3_result = unite(v2274_3_result,v2275_2);
  }
  const Space v2274_3 = std::move(v2274_3_result);
  return v2274_3;
}

static Space routine_274(Context& c, const Path& p0, const Path& p1, const Space& s0) {
  const Space v2276_5 = unwrap(constant_12,p1);
  const Space v2276_7 = unwrap(constant_12,p0);
  Space v2276_8_result;
  for (int v2276_8_label = 1; v2276_8_label <= 2; ++v2276_8_label) {
    const Space v2276_8_tail = child(s0,v2276_8_label);
    if (v2276_8_tail.empty()) continue;
    const Path v2276_8_head{v2276_8_label};
    const Space v2277_2 = singleton(v2276_8_head);
    const Space v2277_3 = intersect(constant_6,v2277_2);
    const Space v2277_4 = (has_head(v2277_3) ? constant_7 : Space{});
    const Space v2277_5 = unwrap(v2276_7,v2276_8_head);
    const Space v2277_6 = compose(v2276_5,v2277_5);
    const Path v2277_7 = concat_path(p0,v2276_8_head);
    const Path v2277_8 = concat_path(p1,v2277_7);
    const Space v2277_9 = singleton(v2277_8);
    const Space v2277_10 = subtract(v2277_6,v2277_9);
    const Space v2277_11 = compose(v2277_4,v2277_10);
    v2276_8_result = unite(v2276_8_result,v2277_11);
  }
  const Space v2276_8 = std::move(v2276_8_result);
  return v2276_8;
}

static Space entry(Context& c,const Env& e) { return routine_0(c); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::entry(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
