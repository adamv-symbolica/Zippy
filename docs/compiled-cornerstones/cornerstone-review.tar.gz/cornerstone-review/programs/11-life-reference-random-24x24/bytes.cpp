#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_26(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Path n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Path n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Space n13(Context&, const Env&);
static ZIPPY_NOINLINE Space n14(Context&, const Env&);
static ZIPPY_NOINLINE Space n15(Context&, const Env&);
static ZIPPY_NOINLINE Path n16(Context&, const Env&);
static ZIPPY_NOINLINE Path n17(Context&, const Env&);
static ZIPPY_NOINLINE Path n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n19(Context&, const Env&);
static ZIPPY_NOINLINE Path n20(Context&, const Env&);
static ZIPPY_NOINLINE Path n21(Context&, const Env&);
static ZIPPY_NOINLINE Path n22(Context&, const Env&);
static ZIPPY_NOINLINE Path n23(Context&, const Env&);
static ZIPPY_NOINLINE Path n24(Context&, const Env&);
static ZIPPY_NOINLINE Space n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Space n29(Context&, const Env&);
static ZIPPY_NOINLINE Path n30(Context&, const Env&);
static ZIPPY_NOINLINE Space n31(Context&, const Env&);
static ZIPPY_NOINLINE Space n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Space n34(Context&, const Env&);
static ZIPPY_NOINLINE Space n35(Context&, const Env&);
static ZIPPY_NOINLINE Space n36(Context&, const Env&);
static ZIPPY_NOINLINE Space n37(Context&, const Env&);
static ZIPPY_NOINLINE Space n38(Context&, const Env&);
static ZIPPY_NOINLINE Path n39(Context&, const Env&);
static ZIPPY_NOINLINE Path n40(Context&, const Env&);
static ZIPPY_NOINLINE Path n41(Context&, const Env&);
static ZIPPY_NOINLINE Path n42(Context&, const Env&);
static ZIPPY_NOINLINE Path n43(Context&, const Env&);
static ZIPPY_NOINLINE Path n44(Context&, const Env&);
static ZIPPY_NOINLINE Path n45(Context&, const Env&);
static ZIPPY_NOINLINE Path n46(Context&, const Env&);
static ZIPPY_NOINLINE Space n47(Context&, const Env&);
static ZIPPY_NOINLINE Space n48(Context&, const Env&);
static ZIPPY_NOINLINE Space n49(Context&, const Env&);
static ZIPPY_NOINLINE Space n50(Context&, const Env&);
static ZIPPY_NOINLINE Space n51(Context&, const Env&);
static ZIPPY_NOINLINE Space n52(Context&, const Env&);
static ZIPPY_NOINLINE Space n53(Context&, const Env&);
static ZIPPY_NOINLINE Space n54(Context&, const Env&);
static ZIPPY_NOINLINE Path n55(Context&, const Env&);
static ZIPPY_NOINLINE Path n56(Context&, const Env&);
static ZIPPY_NOINLINE Path n57(Context&, const Env&);
static ZIPPY_NOINLINE Path n58(Context&, const Env&);
static ZIPPY_NOINLINE Path n59(Context&, const Env&);
static ZIPPY_NOINLINE Path n60(Context&, const Env&);
static ZIPPY_NOINLINE Path n61(Context&, const Env&);
static ZIPPY_NOINLINE Path n62(Context&, const Env&);
static ZIPPY_NOINLINE Space n63(Context&, const Env&);
static ZIPPY_NOINLINE Space n64(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_15(Context&, const Env&);
static ZIPPY_NOINLINE Space n65(Context&, const Env&);
static ZIPPY_NOINLINE Space n66(Context&, const Env&);
static ZIPPY_NOINLINE Space n67(Context&, const Env&);
static ZIPPY_NOINLINE Space n68(Context&, const Env&);
static ZIPPY_NOINLINE Space n69(Context&, const Env&);
static ZIPPY_NOINLINE Space n70(Context&, const Env&);
static ZIPPY_NOINLINE Space n71(Context&, const Env&);
static ZIPPY_NOINLINE Space n72(Context&, const Env&);
static ZIPPY_NOINLINE Space n73(Context&, const Env&);
static ZIPPY_NOINLINE Path n74(Context&, const Env&);
static ZIPPY_NOINLINE Path n75(Context&, const Env&);
static ZIPPY_NOINLINE Path n76(Context&, const Env&);
static ZIPPY_NOINLINE Path n77(Context&, const Env&);
static ZIPPY_NOINLINE Path n78(Context&, const Env&);
static ZIPPY_NOINLINE Path n79(Context&, const Env&);
static ZIPPY_NOINLINE Path n80(Context&, const Env&);
static ZIPPY_NOINLINE Path n81(Context&, const Env&);
static ZIPPY_NOINLINE Path n82(Context&, const Env&);
static ZIPPY_NOINLINE Space n83(Context&, const Env&);
static ZIPPY_NOINLINE Space n84(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_18(Context&, const Env&);
static ZIPPY_NOINLINE Space n85(Context&, const Env&);
static ZIPPY_NOINLINE Space n86(Context&, const Env&);
static ZIPPY_NOINLINE Space n87(Context&, const Env&);
static ZIPPY_NOINLINE Space n88(Context&, const Env&);
static ZIPPY_NOINLINE Space n89(Context&, const Env&);
static ZIPPY_NOINLINE Space n90(Context&, const Env&);
static ZIPPY_NOINLINE Space n91(Context&, const Env&);
static ZIPPY_NOINLINE Space n92(Context&, const Env&);
static ZIPPY_NOINLINE Space n93(Context&, const Env&);
static ZIPPY_NOINLINE Path n94(Context&, const Env&);
static ZIPPY_NOINLINE Path n95(Context&, const Env&);
static ZIPPY_NOINLINE Path n96(Context&, const Env&);
static ZIPPY_NOINLINE Path n97(Context&, const Env&);
static ZIPPY_NOINLINE Path n98(Context&, const Env&);
static ZIPPY_NOINLINE Path n99(Context&, const Env&);
static ZIPPY_NOINLINE Path n100(Context&, const Env&);
static ZIPPY_NOINLINE Path n101(Context&, const Env&);
static ZIPPY_NOINLINE Path n102(Context&, const Env&);
static ZIPPY_NOINLINE Space n103(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_24(Context&, const Env&);
static ZIPPY_NOINLINE Space n104(Context&, const Env&);
static ZIPPY_NOINLINE Space n105(Context&, const Env&);
static ZIPPY_NOINLINE Space n106(Context&, const Env&);
static ZIPPY_NOINLINE Space n107(Context&, const Env&);
static ZIPPY_NOINLINE Space n108(Context&, const Env&);
static ZIPPY_NOINLINE Space n109(Context&, const Env&);
static ZIPPY_NOINLINE Space n110(Context&, const Env&);
static ZIPPY_NOINLINE Space n111(Context&, const Env&);
static ZIPPY_NOINLINE Space n112(Context&, const Env&);
static ZIPPY_NOINLINE Path n113(Context&, const Env&);
static ZIPPY_NOINLINE Path n114(Context&, const Env&);
static ZIPPY_NOINLINE Path n115(Context&, const Env&);
static ZIPPY_NOINLINE Path n116(Context&, const Env&);
static ZIPPY_NOINLINE Path n117(Context&, const Env&);
static ZIPPY_NOINLINE Path n118(Context&, const Env&);
static ZIPPY_NOINLINE Path n119(Context&, const Env&);
static ZIPPY_NOINLINE Path n120(Context&, const Env&);
static ZIPPY_NOINLINE Path n121(Context&, const Env&);
static ZIPPY_NOINLINE Space n122(Context&, const Env&);
static ZIPPY_NOINLINE Space n123(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_14(Context&, const Env&);
static ZIPPY_NOINLINE Space n124(Context&, const Env&);
static ZIPPY_NOINLINE Space n125(Context&, const Env&);
static ZIPPY_NOINLINE Space n126(Context&, const Env&);
static ZIPPY_NOINLINE Space n127(Context&, const Env&);
static ZIPPY_NOINLINE Space n128(Context&, const Env&);
static ZIPPY_NOINLINE Space n129(Context&, const Env&);
static ZIPPY_NOINLINE Space n130(Context&, const Env&);
static ZIPPY_NOINLINE Path n131(Context&, const Env&);
static ZIPPY_NOINLINE Path n132(Context&, const Env&);
static ZIPPY_NOINLINE Path n133(Context&, const Env&);
static ZIPPY_NOINLINE Space n134(Context&, const Env&);
static ZIPPY_NOINLINE Path n135(Context&, const Env&);
static ZIPPY_NOINLINE Space n136(Context&, const Env&);
static ZIPPY_NOINLINE Space n137(Context&, const Env&);
static ZIPPY_NOINLINE Space n138(Context&, const Env&);
static ZIPPY_NOINLINE Space n139(Context&, const Env&);
static ZIPPY_NOINLINE Space n140(Context&, const Env&);
static ZIPPY_NOINLINE Space n141(Context&, const Env&);
static ZIPPY_NOINLINE Space n142(Context&, const Env&);
static ZIPPY_NOINLINE Space n143(Context&, const Env&);
static ZIPPY_NOINLINE Path n144(Context&, const Env&);
static ZIPPY_NOINLINE Path n145(Context&, const Env&);
static ZIPPY_NOINLINE Path n146(Context&, const Env&);
static ZIPPY_NOINLINE Path n147(Context&, const Env&);
static ZIPPY_NOINLINE Path n148(Context&, const Env&);
static ZIPPY_NOINLINE Path n149(Context&, const Env&);
static ZIPPY_NOINLINE Path n150(Context&, const Env&);
static ZIPPY_NOINLINE Path n151(Context&, const Env&);
static ZIPPY_NOINLINE Space n152(Context&, const Env&);
static ZIPPY_NOINLINE Space n153(Context&, const Env&);
static ZIPPY_NOINLINE Space n154(Context&, const Env&);
static ZIPPY_NOINLINE Space n155(Context&, const Env&);
static ZIPPY_NOINLINE Space n156(Context&, const Env&);
static ZIPPY_NOINLINE Path n157(Context&, const Env&);
static ZIPPY_NOINLINE Path n158(Context&, const Env&);
static ZIPPY_NOINLINE Path n159(Context&, const Env&);
static ZIPPY_NOINLINE Space n160(Context&, const Env&);
static ZIPPY_NOINLINE Path n161(Context&, const Env&);
static ZIPPY_NOINLINE Space n162(Context&, const Env&);
static ZIPPY_NOINLINE Space n163(Context&, const Env&);
static ZIPPY_NOINLINE Space n164(Context&, const Env&);
static ZIPPY_NOINLINE Space n165(Context&, const Env&);
static ZIPPY_NOINLINE Space n166(Context&, const Env&);
static ZIPPY_NOINLINE Space n167(Context&, const Env&);
static ZIPPY_NOINLINE Space n168(Context&, const Env&);
static ZIPPY_NOINLINE Space n169(Context&, const Env&);
static ZIPPY_NOINLINE Path n170(Context&, const Env&);
static ZIPPY_NOINLINE Path n171(Context&, const Env&);
static ZIPPY_NOINLINE Path n172(Context&, const Env&);
static ZIPPY_NOINLINE Path n173(Context&, const Env&);
static ZIPPY_NOINLINE Path n174(Context&, const Env&);
static ZIPPY_NOINLINE Path n175(Context&, const Env&);
static ZIPPY_NOINLINE Path n176(Context&, const Env&);
static ZIPPY_NOINLINE Path n177(Context&, const Env&);
static ZIPPY_NOINLINE Space n178(Context&, const Env&);
static ZIPPY_NOINLINE Space n179(Context&, const Env&);
static ZIPPY_NOINLINE Path n180(Context&, const Env&);
static ZIPPY_NOINLINE Path n181(Context&, const Env&);
static ZIPPY_NOINLINE Path n182(Context&, const Env&);
static ZIPPY_NOINLINE Space n183(Context&, const Env&);
static ZIPPY_NOINLINE Space n184(Context&, const Env&);
static ZIPPY_NOINLINE Space n185(Context&, const Env&);
static ZIPPY_NOINLINE Space n186(Context&, const Env&);
static ZIPPY_NOINLINE Space n187(Context&, const Env&);
static ZIPPY_NOINLINE Space n188(Context&, const Env&);
static ZIPPY_NOINLINE Space n189(Context&, const Env&);
static ZIPPY_NOINLINE Path n190(Context&, const Env&);
static ZIPPY_NOINLINE Path n191(Context&, const Env&);
static ZIPPY_NOINLINE Path n192(Context&, const Env&);
static ZIPPY_NOINLINE Path n193(Context&, const Env&);
static ZIPPY_NOINLINE Path n194(Context&, const Env&);
static ZIPPY_NOINLINE Path n195(Context&, const Env&);
static ZIPPY_NOINLINE Path n196(Context&, const Env&);
static ZIPPY_NOINLINE Path n197(Context&, const Env&);
static ZIPPY_NOINLINE Space n198(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_17(Context&, const Env&);
static ZIPPY_NOINLINE Space n199(Context&, const Env&);
static ZIPPY_NOINLINE Path n200(Context&, const Env&);
static ZIPPY_NOINLINE Path n201(Context&, const Env&);
static ZIPPY_NOINLINE Path n202(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_23(Context&, const Env&);
static ZIPPY_NOINLINE Space n203(Context&, const Env&);
static ZIPPY_NOINLINE Space n204(Context&, const Env&);
static ZIPPY_NOINLINE Space n205(Context&, const Env&);
static ZIPPY_NOINLINE Space n206(Context&, const Env&);
static ZIPPY_NOINLINE Space n207(Context&, const Env&);
static ZIPPY_NOINLINE Space n208(Context&, const Env&);
static ZIPPY_NOINLINE Space n209(Context&, const Env&);
static ZIPPY_NOINLINE Path n210(Context&, const Env&);
static ZIPPY_NOINLINE Path n211(Context&, const Env&);
static ZIPPY_NOINLINE Path n212(Context&, const Env&);
static ZIPPY_NOINLINE Space n213(Context&, const Env&);
static ZIPPY_NOINLINE Path n214(Context&, const Env&);
static ZIPPY_NOINLINE Space n215(Context&, const Env&);
static ZIPPY_NOINLINE Space n216(Context&, const Env&);
static ZIPPY_NOINLINE Space n217(Context&, const Env&);
static ZIPPY_NOINLINE Space n218(Context&, const Env&);
static ZIPPY_NOINLINE Space n219(Context&, const Env&);
static ZIPPY_NOINLINE Space n220(Context&, const Env&);
static ZIPPY_NOINLINE Space n221(Context&, const Env&);
static ZIPPY_NOINLINE Space n222(Context&, const Env&);
static ZIPPY_NOINLINE Path n223(Context&, const Env&);
static ZIPPY_NOINLINE Path n224(Context&, const Env&);
static ZIPPY_NOINLINE Path n225(Context&, const Env&);
static ZIPPY_NOINLINE Path n226(Context&, const Env&);
static ZIPPY_NOINLINE Path n227(Context&, const Env&);
static ZIPPY_NOINLINE Path n228(Context&, const Env&);
static ZIPPY_NOINLINE Path n229(Context&, const Env&);
static ZIPPY_NOINLINE Path n230(Context&, const Env&);
static ZIPPY_NOINLINE Space n231(Context&, const Env&);
static ZIPPY_NOINLINE Space n232(Context&, const Env&);
static ZIPPY_NOINLINE Space n233(Context&, const Env&);
static ZIPPY_NOINLINE Space n234(Context&, const Env&);
static ZIPPY_NOINLINE Space n235(Context&, const Env&);
static ZIPPY_NOINLINE Path n236(Context&, const Env&);
static ZIPPY_NOINLINE Path n237(Context&, const Env&);
static ZIPPY_NOINLINE Path n238(Context&, const Env&);
static ZIPPY_NOINLINE Space n239(Context&, const Env&);
static ZIPPY_NOINLINE Path n240(Context&, const Env&);
static ZIPPY_NOINLINE Space n241(Context&, const Env&);
static ZIPPY_NOINLINE Space n242(Context&, const Env&);
static ZIPPY_NOINLINE Space n243(Context&, const Env&);
static ZIPPY_NOINLINE Space n244(Context&, const Env&);
static ZIPPY_NOINLINE Space n245(Context&, const Env&);
static ZIPPY_NOINLINE Space n246(Context&, const Env&);
static ZIPPY_NOINLINE Space n247(Context&, const Env&);
static ZIPPY_NOINLINE Space n248(Context&, const Env&);
static ZIPPY_NOINLINE Path n249(Context&, const Env&);
static ZIPPY_NOINLINE Path n250(Context&, const Env&);
static ZIPPY_NOINLINE Path n251(Context&, const Env&);
static ZIPPY_NOINLINE Path n252(Context&, const Env&);
static ZIPPY_NOINLINE Path n253(Context&, const Env&);
static ZIPPY_NOINLINE Path n254(Context&, const Env&);
static ZIPPY_NOINLINE Path n255(Context&, const Env&);
static ZIPPY_NOINLINE Path n256(Context&, const Env&);
static ZIPPY_NOINLINE Space n257(Context&, const Env&);
static ZIPPY_NOINLINE Space n258(Context&, const Env&);
static ZIPPY_NOINLINE Path n259(Context&, const Env&);
static ZIPPY_NOINLINE Path n260(Context&, const Env&);
static ZIPPY_NOINLINE Path n261(Context&, const Env&);
static ZIPPY_NOINLINE Space n262(Context&, const Env&);
static ZIPPY_NOINLINE Space n263(Context&, const Env&);
static ZIPPY_NOINLINE Space n264(Context&, const Env&);
static ZIPPY_NOINLINE Space n265(Context&, const Env&);
static ZIPPY_NOINLINE Space n266(Context&, const Env&);
static ZIPPY_NOINLINE Space n267(Context&, const Env&);
static ZIPPY_NOINLINE Space n268(Context&, const Env&);
static ZIPPY_NOINLINE Path n269(Context&, const Env&);
static ZIPPY_NOINLINE Path n270(Context&, const Env&);
static ZIPPY_NOINLINE Path n271(Context&, const Env&);
static ZIPPY_NOINLINE Path n272(Context&, const Env&);
static ZIPPY_NOINLINE Path n273(Context&, const Env&);
static ZIPPY_NOINLINE Path n274(Context&, const Env&);
static ZIPPY_NOINLINE Path n275(Context&, const Env&);
static ZIPPY_NOINLINE Path n276(Context&, const Env&);
static ZIPPY_NOINLINE Space n277(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_6(Context&, const Env&);
static ZIPPY_NOINLINE Space n278(Context&, const Env&);
static ZIPPY_NOINLINE Space n279(Context&, const Env&);
static ZIPPY_NOINLINE Space n280(Context&, const Env&);
static ZIPPY_NOINLINE Space n281(Context&, const Env&);
static ZIPPY_NOINLINE Space n282(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_25(Context&, const Env&);
static ZIPPY_NOINLINE Space n283(Context&, const Env&);
static ZIPPY_NOINLINE Space n284(Context&, const Env&);
static ZIPPY_NOINLINE Path n285(Context&, const Env&);
static ZIPPY_NOINLINE Space n286(Context&, const Env&);
static ZIPPY_NOINLINE Space n287(Context&, const Env&);
static ZIPPY_NOINLINE Space n288(Context&, const Env&);
static ZIPPY_NOINLINE Space n289(Context&, const Env&);
static ZIPPY_NOINLINE Space n290(Context&, const Env&);
static ZIPPY_NOINLINE Space n291(Context&, const Env&);
static ZIPPY_NOINLINE Space n292(Context&, const Env&);
static ZIPPY_NOINLINE Path n293(Context&, const Env&);
static ZIPPY_NOINLINE Path n294(Context&, const Env&);
static ZIPPY_NOINLINE Path n295(Context&, const Env&);
static ZIPPY_NOINLINE Path n296(Context&, const Env&);
static ZIPPY_NOINLINE Path n297(Context&, const Env&);
static ZIPPY_NOINLINE Path n298(Context&, const Env&);
static ZIPPY_NOINLINE Path n299(Context&, const Env&);
static ZIPPY_NOINLINE Path n300(Context&, const Env&);
static ZIPPY_NOINLINE Space n301(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_11(Context&, const Env&);
static ZIPPY_NOINLINE Space n302(Context&, const Env&);
static ZIPPY_NOINLINE Path n303(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_7(Context&, const Env&);
static ZIPPY_NOINLINE Space n304(Context&, const Env&);
static ZIPPY_NOINLINE Space n305(Context&, const Env&);
static ZIPPY_NOINLINE Space n306(Context&, const Env&);
static ZIPPY_NOINLINE Space n307(Context&, const Env&);
static ZIPPY_NOINLINE Space n308(Context&, const Env&);
static ZIPPY_NOINLINE Space n309(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_12(Context&, const Env&);
static ZIPPY_NOINLINE Space n310(Context&, const Env&);
static ZIPPY_NOINLINE Path n311(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_13(Context&, const Env&);
static ZIPPY_NOINLINE Space n312(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_20(Context&, const Env&);
static ZIPPY_NOINLINE Space n313(Context&, const Env&);
static ZIPPY_NOINLINE Path n314(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_8(Context&, const Env&);
static ZIPPY_NOINLINE Space n315(Context&, const Env&);
static ZIPPY_NOINLINE Space n316(Context&, const Env&);
static ZIPPY_NOINLINE Space n317(Context&, const Env&);
static ZIPPY_NOINLINE Space n318(Context&, const Env&);
static ZIPPY_NOINLINE Space n319(Context&, const Env&);
static ZIPPY_NOINLINE Space n320(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_21(Context&, const Env&);
static ZIPPY_NOINLINE Space n321(Context&, const Env&);
static ZIPPY_NOINLINE Path n322(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_22(Context&, const Env&);
static ZIPPY_NOINLINE Space n323(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_1(Context&, const Env&);
static ZIPPY_NOINLINE Space n324(Context&, const Env&);
static ZIPPY_NOINLINE Space n325(Context&, const Env&);
static ZIPPY_NOINLINE Space n326(Context&, const Env&);
static ZIPPY_NOINLINE Space n327(Context&, const Env&);
static ZIPPY_NOINLINE Space n328(Context&, const Env&);
static ZIPPY_NOINLINE Space n329(Context&, const Env&);
static ZIPPY_NOINLINE Space n330(Context&, const Env&);
static ZIPPY_NOINLINE Space n331(Context&, const Env&);
static ZIPPY_NOINLINE Space n332(Context&, const Env&);
static ZIPPY_NOINLINE Space n333(Context&, const Env&);
static ZIPPY_NOINLINE Space n334(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_2(Context&, const Env&);
static ZIPPY_NOINLINE Space n335(Context&, const Env&);
static ZIPPY_NOINLINE Space n336(Context&, const Env&);
static ZIPPY_NOINLINE Space n337(Context&, const Env&);
static ZIPPY_NOINLINE Space n338(Context&, const Env&);
static ZIPPY_NOINLINE Space n339(Context&, const Env&);
static ZIPPY_NOINLINE Space n340(Context&, const Env&);
static ZIPPY_NOINLINE Space n341(Context&, const Env&);
static ZIPPY_NOINLINE Space n342(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_10(Context&, const Env&);
static ZIPPY_NOINLINE Space n343(Context&, const Env&);
static ZIPPY_NOINLINE Space n344(Context&, const Env&);
static ZIPPY_NOINLINE Space n345(Context&, const Env&);
static ZIPPY_NOINLINE Space n346(Context&, const Env&);
static ZIPPY_NOINLINE Space n347(Context&, const Env&);
static ZIPPY_NOINLINE Space n348(Context&, const Env&);
static ZIPPY_NOINLINE Space n349(Context&, const Env&);
static ZIPPY_NOINLINE Space n350(Context&, const Env&);
static ZIPPY_NOINLINE Space n351(Context&, const Env&);
static ZIPPY_NOINLINE Path n352(Context&, const Env&);
static ZIPPY_NOINLINE Path n353(Context&, const Env&);
static ZIPPY_NOINLINE Path n354(Context&, const Env&);
static ZIPPY_NOINLINE Path n355(Context&, const Env&);
static ZIPPY_NOINLINE Path n356(Context&, const Env&);
static ZIPPY_NOINLINE Path n357(Context&, const Env&);
static ZIPPY_NOINLINE Path n358(Context&, const Env&);
static ZIPPY_NOINLINE Path n359(Context&, const Env&);
static ZIPPY_NOINLINE Path n360(Context&, const Env&);
static ZIPPY_NOINLINE Space n361(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_3(Context&, const Env&);
static ZIPPY_NOINLINE Space n362(Context&, const Env&);
static ZIPPY_NOINLINE Space n363(Context&, const Env&);
static ZIPPY_NOINLINE Space n364(Context&, const Env&);
static ZIPPY_NOINLINE Space n365(Context&, const Env&);
static ZIPPY_NOINLINE Space n366(Context&, const Env&);
static ZIPPY_NOINLINE Space n367(Context&, const Env&);
static ZIPPY_NOINLINE Space n368(Context&, const Env&);
static ZIPPY_NOINLINE Space n369(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_4(Context&, const Env&);
static ZIPPY_NOINLINE Space n370(Context&, const Env&);
static ZIPPY_NOINLINE Space n371(Context&, const Env&);
static ZIPPY_NOINLINE Space n372(Context&, const Env&);
static ZIPPY_NOINLINE Space n373(Context&, const Env&);
static ZIPPY_NOINLINE Space n374(Context&, const Env&);
static ZIPPY_NOINLINE Space n375(Context&, const Env&);
static ZIPPY_NOINLINE Space n376(Context&, const Env&);
static ZIPPY_NOINLINE Space n377(Context&, const Env&);
static ZIPPY_NOINLINE Space n378(Context&, const Env&);
static ZIPPY_NOINLINE Space n379(Context&, const Env&);
static ZIPPY_NOINLINE Space n380(Context&, const Env&);
static ZIPPY_NOINLINE Space n381(Context&, const Env&);
static ZIPPY_NOINLINE Space n382(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_19(Context&, const Env&);
static ZIPPY_NOINLINE Space n383(Context&, const Env&);
static ZIPPY_NOINLINE Space n384(Context&, const Env&);
static ZIPPY_NOINLINE Space n385(Context&, const Env&);
static ZIPPY_NOINLINE Space n386(Context&, const Env&);
static ZIPPY_NOINLINE Space n387(Context&, const Env&);
static ZIPPY_NOINLINE Path n388(Context&, const Env&);
static ZIPPY_NOINLINE Space n389(Context&, const Env&);
static ZIPPY_NOINLINE Space n390(Context&, const Env&);
static ZIPPY_NOINLINE Path n391(Context&, const Env&);
static ZIPPY_NOINLINE Space n392(Context&, const Env&);
static ZIPPY_NOINLINE Space n393(Context&, const Env&);
static ZIPPY_NOINLINE Path n394(Context&, const Env&);
static ZIPPY_NOINLINE Space n395(Context&, const Env&);
static ZIPPY_NOINLINE Space n396(Context&, const Env&);
static ZIPPY_NOINLINE Space n397(Context&, const Env&);
static ZIPPY_NOINLINE Space n398(Context&, const Env&);
static ZIPPY_NOINLINE Path n399(Context&, const Env&);
static ZIPPY_NOINLINE Space n400(Context&, const Env&);
static ZIPPY_NOINLINE Space n401(Context&, const Env&);
static ZIPPY_NOINLINE Path n402(Context&, const Env&);
static ZIPPY_NOINLINE Space n403(Context&, const Env&);
static ZIPPY_NOINLINE Space n404(Context&, const Env&);
static ZIPPY_NOINLINE Path n405(Context&, const Env&);
static ZIPPY_NOINLINE Space n406(Context&, const Env&);
static ZIPPY_NOINLINE Space n407(Context&, const Env&);
static ZIPPY_NOINLINE Path n408(Context&, const Env&);
static ZIPPY_NOINLINE Path n409(Context&, const Env&);
static ZIPPY_NOINLINE Path n410(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n411(Context&, const Env&);
static ZIPPY_NOINLINE Space n412(Context&, const Env&);
static ZIPPY_NOINLINE Space n413(Context&, const Env&);
static ZIPPY_NOINLINE Space n414(Context&, const Env&);
static ZIPPY_NOINLINE Space n415(Context&, const Env&);
static ZIPPY_NOINLINE Path n416(Context&, const Env&);
static ZIPPY_NOINLINE Space n417(Context&, const Env&);
static ZIPPY_NOINLINE Space n418(Context&, const Env&);
static ZIPPY_NOINLINE Space n419(Context&, const Env&);
static ZIPPY_NOINLINE Space n420(Context&, const Env&);
static ZIPPY_NOINLINE Path n421(Context&, const Env&);
static ZIPPY_NOINLINE Path n422(Context&, const Env&);
static ZIPPY_NOINLINE Path n423(Context&, const Env&);
static ZIPPY_NOINLINE Space n424(Context&, const Env&);
static ZIPPY_NOINLINE Space n425(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_9(Context&, const Env&);
static ZIPPY_NOINLINE Space n426(Context&, const Env&);
static ZIPPY_NOINLINE Path n427(Context&, const Env&);
static ZIPPY_NOINLINE Space n428(Context&, const Env&);
static ZIPPY_NOINLINE Space n429(Context&, const Env&);
static ZIPPY_NOINLINE Path n430(Context&, const Env&);
static ZIPPY_NOINLINE Space n431(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { static const Space value=literal_text("120 12 1 1 1 1 1 1 1 2 1 1 1 3 12 1 1 1 1 1 1 1 2 1 1 1 4 12 1 1 1 1 1 1 1 3 1 1 1 9 12 1 1 1 1 1 1 1 3 1 1 1 10 12 1 1 1 1 1 1 1 3 1 1 1 11 12 1 1 1 1 1 1 1 3 1 1 1 12 12 1 1 1 1 1 1 1 3 1 1 1 13 12 1 1 1 1 1 1 1 4 1 1 1 4 12 1 1 1 1 1 1 1 4 1 1 1 9 12 1 1 1 1 1 1 1 4 1 1 1 11 12 1 1 1 1 1 1 1 4 1 1 1 14 12 1 1 1 1 1 1 1 4 1 1 1 15 12 1 1 1 1 1 1 1 5 1 1 1 6 12 1 1 1 1 1 1 1 5 1 1 1 7 12 1 1 1 1 1 1 1 5 1 1 1 8 12 1 1 1 1 1 1 1 6 1 1 1 7 12 1 1 1 1 1 1 1 6 1 1 1 8 12 1 1 1 1 1 1 1 6 1 1 1 13 12 1 1 1 1 1 1 1 6 1 1 1 19 12 1 1 1 1 1 1 1 7 1 1 1 2 12 1 1 1 1 1 1 1 7 1 1 1 10 12 1 1 1 1 1 1 1 7 1 1 1 12 12 1 1 1 1 1 1 1 7 1 1 1 13 12 1 1 1 1 1 1 1 7 1 1 1 20 12 1 1 1 1 1 1 1 8 1 1 1 13 12 1 1 1 1 1 1 1 8 1 1 1 15 12 1 1 1 1 1 1 1 8 1 1 1 18 12 1 1 1 1 1 1 1 8 1 1 1 21 12 1 1 1 1 1 1 1 8 1 1 1 24 12 1 1 1 1 1 1 1 9 1 1 1 16 12 1 1 1 1 1 1 1 9 1 1 1 17 12 1 1 1 1 1 1 1 9 1 1 1 18 12 1 1 1 1 1 1 1 10 1 1 1 3 12 1 1 1 1 1 1 1 10 1 1 1 6 12 1 1 1 1 1 1 1 10 1 1 1 9 12 1 1 1 1 1 1 1 10 1 1 1 15 12 1 1 1 1 1 1 1 10 1 1 1 21 12 1 1 1 1 1 1 1 10 1 1 1 22 12 1 1 1 1 1 1 1 10 1 1 1 25 12 1 1 1 1 1 1 1 11 1 1 1 5 12 1 1 1 1 1 1 1 11 1 1 1 13 12 1 1 1 1 1 1 1 11 1 1 1 15 12 1 1 1 1 1 1 1 11 1 1 1 18 12 1 1 1 1 1 1 1 11 1 1 1 24 12 1 1 1 1 1 1 1 12 1 1 1 5 12 1 1 1 1 1 1 1 12 1 1 1 7 12 1 1 1 1 1 1 1 12 1 1 1 8 12 1 1 1 1 1 1 1 12 1 1 1 12 12 1 1 1 1 1 1 1 12 1 1 1 18 12 1 1 1 1 1 1 1 12 1 1 1 23 12 1 1 1 1 1 1 1 13 1 1 1 9 12 1 1 1 1 1 1 1 13 1 1 1 11 12 1 1 1 1 1 1 1 13 1 1 1 14 12 1 1 1 1 1 1 1 13 1 1 1 15 12 1 1 1 1 1 1 1 13 1 1 1 17 12 1 1 1 1 1 1 1 13 1 1 1 22 12 1 1 1 1 1 1 1 13 1 1 1 23 12 1 1 1 1 1 1 1 13 1 1 1 24 12 1 1 1 1 1 1 1 14 1 1 1 5 12 1 1 1 1 1 1 1 14 1 1 1 15 12 1 1 1 1 1 1 1 14 1 1 1 18 12 1 1 1 1 1 1 1 14 1 1 1 19 12 1 1 1 1 1 1 1 14 1 1 1 24 12 1 1 1 1 1 1 1 15 1 1 1 3 12 1 1 1 1 1 1 1 15 1 1 1 9 12 1 1 1 1 1 1 1 15 1 1 1 10 12 1 1 1 1 1 1 1 15 1 1 1 17 12 1 1 1 1 1 1 1 15 1 1 1 24 12 1 1 1 1 1 1 1 16 1 1 1 2 12 1 1 1 1 1 1 1 17 1 1 1 10 12 1 1 1 1 1 1 1 17 1 1 1 14 12 1 1 1 1 1 1 1 17 1 1 1 19 12 1 1 1 1 1 1 1 18 1 1 1 3 12 1 1 1 1 1 1 1 18 1 1 1 6 12 1 1 1 1 1 1 1 18 1 1 1 19 12 1 1 1 1 1 1 1 19 1 1 1 6 12 1 1 1 1 1 1 1 19 1 1 1 13 12 1 1 1 1 1 1 1 19 1 1 1 20 12 1 1 1 1 1 1 1 19 1 1 1 21 12 1 1 1 1 1 1 1 19 1 1 1 23 12 1 1 1 1 1 1 1 20 1 1 1 4 12 1 1 1 1 1 1 1 20 1 1 1 12 12 1 1 1 1 1 1 1 20 1 1 1 13 12 1 1 1 1 1 1 1 20 1 1 1 15 12 1 1 1 1 1 1 1 20 1 1 1 17 12 1 1 1 1 1 1 1 20 1 1 1 19 12 1 1 1 1 1 1 1 21 1 1 1 5 12 1 1 1 1 1 1 1 21 1 1 1 8 12 1 1 1 1 1 1 1 21 1 1 1 12 12 1 1 1 1 1 1 1 21 1 1 1 14 12 1 1 1 1 1 1 1 21 1 1 1 15 12 1 1 1 1 1 1 1 21 1 1 1 16 12 1 1 1 1 1 1 1 21 1 1 1 17 12 1 1 1 1 1 1 1 21 1 1 1 22 12 1 1 1 1 1 1 1 22 1 1 1 9 12 1 1 1 1 1 1 1 22 1 1 1 10 12 1 1 1 1 1 1 1 22 1 1 1 12 12 1 1 1 1 1 1 1 22 1 1 1 13 12 1 1 1 1 1 1 1 22 1 1 1 14 12 1 1 1 1 1 1 1 22 1 1 1 16 12 1 1 1 1 1 1 1 22 1 1 1 18 12 1 1 1 1 1 1 1 22 1 1 1 23 12 1 1 1 1 1 1 1 22 1 1 1 24 12 1 1 1 1 1 1 1 23 1 1 1 4 12 1 1 1 1 1 1 1 23 1 1 1 8 12 1 1 1 1 1 1 1 23 1 1 1 11 12 1 1 1 1 1 1 1 23 1 1 1 16 12 1 1 1 1 1 1 1 23 1 1 1 17 12 1 1 1 1 1 1 1 23 1 1 1 20 12 1 1 1 1 1 1 1 23 1 1 1 21 12 1 1 1 1 1 1 1 24 1 1 1 3 12 1 1 1 1 1 1 1 24 1 1 1 5 12 1 1 1 1 1 1 1 24 1 1 1 7 12 1 1 1 1 1 1 1 24 1 1 1 8 12 1 1 1 1 1 1 1 24 1 1 1 15 12 1 1 1 1 1 1 1 24 1 1 1 17 12 1 1 1 1 1 1 1 24 1 1 1 23 12 1 1 1 1 1 1 1 25 1 1 1 16 12 1 1 1 1 1 1 1 25 1 1 1 18 12 1 1 1 1 1 1 1 25 1 1 1 25"); return value; }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n1(c,e)}; Env n; n.spaces[0]=sv[0];  return routine_26(c,n); }
static ZIPPY_NOINLINE Path n3(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Path n7(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { auto p=n7(c,e); return unwrap(n8(c,e),p); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Space n14(Context& c, const Env& e) { return e.spaces.at(3); }
static ZIPPY_NOINLINE Path n20(Context& c, const Env& e) { return Path{}; }
static ZIPPY_NOINLINE Path n21(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n19(Context& c, const Env& e) { auto a=n20(c,e); auto b=n21(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n22(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n18(Context& c, const Env& e) { auto a=n19(c,e); auto b=n22(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n23(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n17(Context& c, const Env& e) { auto a=n18(c,e); auto b=n23(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n24(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Path n16(Context& c, const Env& e) { auto a=n17(c,e); auto b=n24(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n25(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n15(Context& c, const Env& e) { std::vector<Path> pv{n16(c,e)}; std::vector<Space> sv{n25(c,e),n26(c,e)}; Env n; n.paths[4]=pv[0];n.spaces[5]=sv[0];n.spaces[0]=sv[1];  return routine_15(c,n); }
static ZIPPY_NOINLINE Space n13(Context& c, const Env& e) { return iterate(c,e,n14(c,e),3,4,n15); }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { return iterate(c,e,n12(c,e),2,3,n13); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { return iterate(c,e,n10(c,e),1,2,n11); }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return iterate(c,e,n6(c,e),0,1,n9); }
static ZIPPY_NOINLINE Path n30(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n31(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n29(Context& c, const Env& e) { auto p=n30(c,e); return unwrap(n31(c,e),p); }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Space n35(Context& c, const Env& e) { return e.spaces.at(7); }
static ZIPPY_NOINLINE Space n37(Context& c, const Env& e) { return e.spaces.at(8); }
static ZIPPY_NOINLINE Path n43(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Path n42(Context& c, const Env& e) { auto a=n20(c,e); auto b=n43(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n44(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Path n41(Context& c, const Env& e) { auto a=n42(c,e); auto b=n44(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n45(Context& c, const Env& e) { return e.paths.at(7); }
static ZIPPY_NOINLINE Path n40(Context& c, const Env& e) { auto a=n41(c,e); auto b=n45(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n46(Context& c, const Env& e) { return e.paths.at(8); }
static ZIPPY_NOINLINE Path n39(Context& c, const Env& e) { auto a=n40(c,e); auto b=n46(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n47(Context& c, const Env& e) { return e.spaces.at(9); }
static ZIPPY_NOINLINE Space n38(Context& c, const Env& e) { std::vector<Path> pv{n39(c,e)}; std::vector<Space> sv{n47(c,e)}; Env n; n.paths[9]=pv[0];n.spaces[10]=sv[0];  return routine_18(c,n); }
static ZIPPY_NOINLINE Space n36(Context& c, const Env& e) { return iterate(c,e,n37(c,e),8,9,n38); }
static ZIPPY_NOINLINE Space n34(Context& c, const Env& e) { return iterate(c,e,n35(c,e),7,8,n36); }
static ZIPPY_NOINLINE Space n32(Context& c, const Env& e) { return iterate(c,e,n33(c,e),6,7,n34); }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { return iterate(c,e,n29(c,e),5,6,n32); }
static ZIPPY_NOINLINE Space n49(Context& c, const Env& e) { return e.spaces.at(11); }
static ZIPPY_NOINLINE Space n51(Context& c, const Env& e) { return e.spaces.at(12); }
static ZIPPY_NOINLINE Space n53(Context& c, const Env& e) { return e.spaces.at(13); }
static ZIPPY_NOINLINE Path n59(Context& c, const Env& e) { return e.paths.at(10); }
static ZIPPY_NOINLINE Path n58(Context& c, const Env& e) { auto a=n20(c,e); auto b=n59(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n60(Context& c, const Env& e) { return e.paths.at(11); }
static ZIPPY_NOINLINE Path n57(Context& c, const Env& e) { auto a=n58(c,e); auto b=n60(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n61(Context& c, const Env& e) { return e.paths.at(12); }
static ZIPPY_NOINLINE Path n56(Context& c, const Env& e) { auto a=n57(c,e); auto b=n61(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n62(Context& c, const Env& e) { return e.paths.at(13); }
static ZIPPY_NOINLINE Path n55(Context& c, const Env& e) { auto a=n56(c,e); auto b=n62(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n63(Context& c, const Env& e) { return e.spaces.at(14); }
static ZIPPY_NOINLINE Space n64(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n54(Context& c, const Env& e) { std::vector<Path> pv{n55(c,e)}; std::vector<Space> sv{n63(c,e),n64(c,e)}; Env n; n.paths[14]=pv[0];n.spaces[15]=sv[0];n.spaces[0]=sv[1];  return routine_24(c,n); }
static ZIPPY_NOINLINE Space n52(Context& c, const Env& e) { return iterate(c,e,n53(c,e),13,14,n54); }
static ZIPPY_NOINLINE Space n50(Context& c, const Env& e) { return iterate(c,e,n51(c,e),12,13,n52); }
static ZIPPY_NOINLINE Space n48(Context& c, const Env& e) { return iterate(c,e,n49(c,e),11,12,n50); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { return iterate(c,e,n28(c,e),10,11,n48); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { auto a=n5(c,e); auto b=n27(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { auto p=n3(c,e); return wrap(n4(c,e),p); }
static ZIPPY_NOINLINE Space routine_26(Context& c,const Env& e) { return n2(c,e); }
static ZIPPY_NOINLINE Space n66(Context& c, const Env& e) { return e.spaces.at(5); }
static ZIPPY_NOINLINE Space n68(Context& c, const Env& e) { return e.spaces.at(16); }
static ZIPPY_NOINLINE Space n70(Context& c, const Env& e) { return e.spaces.at(17); }
static ZIPPY_NOINLINE Space n72(Context& c, const Env& e) { return e.spaces.at(18); }
static ZIPPY_NOINLINE Path n78(Context& c, const Env& e) { return e.paths.at(15); }
static ZIPPY_NOINLINE Path n77(Context& c, const Env& e) { auto a=n20(c,e); auto b=n78(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n79(Context& c, const Env& e) { return e.paths.at(16); }
static ZIPPY_NOINLINE Path n76(Context& c, const Env& e) { auto a=n77(c,e); auto b=n79(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n80(Context& c, const Env& e) { return e.paths.at(17); }
static ZIPPY_NOINLINE Path n75(Context& c, const Env& e) { auto a=n76(c,e); auto b=n80(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n81(Context& c, const Env& e) { return e.paths.at(18); }
static ZIPPY_NOINLINE Path n74(Context& c, const Env& e) { auto a=n75(c,e); auto b=n81(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n82(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Space n83(Context& c, const Env& e) { return e.spaces.at(19); }
static ZIPPY_NOINLINE Space n84(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n73(Context& c, const Env& e) { std::vector<Path> pv{n74(c,e),n82(c,e)}; std::vector<Space> sv{n83(c,e),n84(c,e)}; Env n; n.paths[19]=pv[0];n.paths[4]=pv[1];n.spaces[20]=sv[0];n.spaces[0]=sv[1];  return routine_14(c,n); }
static ZIPPY_NOINLINE Space n71(Context& c, const Env& e) { return iterate(c,e,n72(c,e),18,19,n73); }
static ZIPPY_NOINLINE Space n69(Context& c, const Env& e) { return iterate(c,e,n70(c,e),17,18,n71); }
static ZIPPY_NOINLINE Space n67(Context& c, const Env& e) { return iterate(c,e,n68(c,e),16,17,n69); }
static ZIPPY_NOINLINE Space n65(Context& c, const Env& e) { return iterate(c,e,n66(c,e),15,16,n67); }
static ZIPPY_NOINLINE Space routine_15(Context& c,const Env& e) { return n65(c,e); }
static ZIPPY_NOINLINE Space n86(Context& c, const Env& e) { return e.spaces.at(10); }
static ZIPPY_NOINLINE Space n88(Context& c, const Env& e) { return e.spaces.at(21); }
static ZIPPY_NOINLINE Space n90(Context& c, const Env& e) { return e.spaces.at(22); }
static ZIPPY_NOINLINE Space n92(Context& c, const Env& e) { return e.spaces.at(23); }
static ZIPPY_NOINLINE Path n98(Context& c, const Env& e) { return e.paths.at(20); }
static ZIPPY_NOINLINE Path n97(Context& c, const Env& e) { auto a=n20(c,e); auto b=n98(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n99(Context& c, const Env& e) { return e.paths.at(21); }
static ZIPPY_NOINLINE Path n96(Context& c, const Env& e) { auto a=n97(c,e); auto b=n99(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n100(Context& c, const Env& e) { return e.paths.at(22); }
static ZIPPY_NOINLINE Path n95(Context& c, const Env& e) { auto a=n96(c,e); auto b=n100(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n101(Context& c, const Env& e) { return e.paths.at(23); }
static ZIPPY_NOINLINE Path n94(Context& c, const Env& e) { auto a=n95(c,e); auto b=n101(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n102(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Space n103(Context& c, const Env& e) { return e.spaces.at(24); }
static ZIPPY_NOINLINE Space n93(Context& c, const Env& e) { std::vector<Path> pv{n94(c,e),n102(c,e)}; std::vector<Space> sv{n103(c,e)}; Env n; n.paths[24]=pv[0];n.paths[9]=pv[1];n.spaces[25]=sv[0];  return routine_17(c,n); }
static ZIPPY_NOINLINE Space n91(Context& c, const Env& e) { return iterate(c,e,n92(c,e),23,24,n93); }
static ZIPPY_NOINLINE Space n89(Context& c, const Env& e) { return iterate(c,e,n90(c,e),22,23,n91); }
static ZIPPY_NOINLINE Space n87(Context& c, const Env& e) { return iterate(c,e,n88(c,e),21,22,n89); }
static ZIPPY_NOINLINE Space n85(Context& c, const Env& e) { return iterate(c,e,n86(c,e),20,21,n87); }
static ZIPPY_NOINLINE Space routine_18(Context& c,const Env& e) { return n85(c,e); }
static ZIPPY_NOINLINE Space n105(Context& c, const Env& e) { return e.spaces.at(15); }
static ZIPPY_NOINLINE Space n107(Context& c, const Env& e) { return e.spaces.at(26); }
static ZIPPY_NOINLINE Space n109(Context& c, const Env& e) { return e.spaces.at(27); }
static ZIPPY_NOINLINE Space n111(Context& c, const Env& e) { return e.spaces.at(28); }
static ZIPPY_NOINLINE Path n117(Context& c, const Env& e) { return e.paths.at(25); }
static ZIPPY_NOINLINE Path n116(Context& c, const Env& e) { auto a=n20(c,e); auto b=n117(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n118(Context& c, const Env& e) { return e.paths.at(26); }
static ZIPPY_NOINLINE Path n115(Context& c, const Env& e) { auto a=n116(c,e); auto b=n118(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n119(Context& c, const Env& e) { return e.paths.at(27); }
static ZIPPY_NOINLINE Path n114(Context& c, const Env& e) { auto a=n115(c,e); auto b=n119(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n120(Context& c, const Env& e) { return e.paths.at(28); }
static ZIPPY_NOINLINE Path n113(Context& c, const Env& e) { auto a=n114(c,e); auto b=n120(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n121(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Space n122(Context& c, const Env& e) { return e.spaces.at(29); }
static ZIPPY_NOINLINE Space n123(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n112(Context& c, const Env& e) { std::vector<Path> pv{n113(c,e),n121(c,e)}; std::vector<Space> sv{n122(c,e),n123(c,e)}; Env n; n.paths[29]=pv[0];n.paths[14]=pv[1];n.spaces[30]=sv[0];n.spaces[0]=sv[1];  return routine_23(c,n); }
static ZIPPY_NOINLINE Space n110(Context& c, const Env& e) { return iterate(c,e,n111(c,e),28,29,n112); }
static ZIPPY_NOINLINE Space n108(Context& c, const Env& e) { return iterate(c,e,n109(c,e),27,28,n110); }
static ZIPPY_NOINLINE Space n106(Context& c, const Env& e) { return iterate(c,e,n107(c,e),26,27,n108); }
static ZIPPY_NOINLINE Space n104(Context& c, const Env& e) { return iterate(c,e,n105(c,e),25,26,n106); }
static ZIPPY_NOINLINE Space routine_24(Context& c,const Env& e) { return n104(c,e); }
static ZIPPY_NOINLINE Path n132(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n133(Context& c, const Env& e) { return e.paths.at(19); }
static ZIPPY_NOINLINE Path n131(Context& c, const Env& e) { auto a=n132(c,e); auto b=n133(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n130(Context& c, const Env& e) { std::vector<Path> pv{n131(c,e)}; std::vector<Space> sv{}; Env n; n.paths[30]=pv[0];  return routine_25(c,n); }
static ZIPPY_NOINLINE Path n135(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n136(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n134(Context& c, const Env& e) { auto p=n135(c,e); return unwrap(n136(c,e),p); }
static ZIPPY_NOINLINE Space n129(Context& c, const Env& e) { auto a=n130(c,e); auto b=n134(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n128(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n129(c,e)}; Env n; n.spaces[31]=sv[0];  return routine_6(c,n); }
static ZIPPY_NOINLINE Space n138(Context& c, const Env& e) { return e.spaces.at(32); }
static ZIPPY_NOINLINE Space n140(Context& c, const Env& e) { return e.spaces.at(33); }
static ZIPPY_NOINLINE Space n142(Context& c, const Env& e) { return e.spaces.at(34); }
static ZIPPY_NOINLINE Path n148(Context& c, const Env& e) { return e.paths.at(31); }
static ZIPPY_NOINLINE Path n147(Context& c, const Env& e) { auto a=n20(c,e); auto b=n148(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n149(Context& c, const Env& e) { return e.paths.at(32); }
static ZIPPY_NOINLINE Path n146(Context& c, const Env& e) { auto a=n147(c,e); auto b=n149(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n150(Context& c, const Env& e) { return e.paths.at(33); }
static ZIPPY_NOINLINE Path n145(Context& c, const Env& e) { auto a=n146(c,e); auto b=n150(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n151(Context& c, const Env& e) { return e.paths.at(34); }
static ZIPPY_NOINLINE Path n144(Context& c, const Env& e) { auto a=n145(c,e); auto b=n151(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n152(Context& c, const Env& e) { return e.spaces.at(35); }
static ZIPPY_NOINLINE Space n143(Context& c, const Env& e) { std::vector<Path> pv{n144(c,e)}; std::vector<Space> sv{n152(c,e)}; Env n; n.paths[35]=pv[0];n.spaces[36]=sv[0];  return routine_11(c,n); }
static ZIPPY_NOINLINE Space n141(Context& c, const Env& e) { return iterate(c,e,n142(c,e),34,35,n143); }
static ZIPPY_NOINLINE Space n139(Context& c, const Env& e) { return iterate(c,e,n140(c,e),33,34,n141); }
static ZIPPY_NOINLINE Space n137(Context& c, const Env& e) { return iterate(c,e,n138(c,e),32,33,n139); }
static ZIPPY_NOINLINE Space n127(Context& c, const Env& e) { return iterate(c,e,n128(c,e),31,32,n137); }
static ZIPPY_NOINLINE Path n158(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n159(Context& c, const Env& e) { return e.paths.at(19); }
static ZIPPY_NOINLINE Path n157(Context& c, const Env& e) { auto a=n158(c,e); auto b=n159(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n156(Context& c, const Env& e) { std::vector<Path> pv{n157(c,e)}; std::vector<Space> sv{}; Env n; n.paths[30]=pv[0];  return routine_25(c,n); }
static ZIPPY_NOINLINE Path n161(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n162(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n160(Context& c, const Env& e) { auto p=n161(c,e); return unwrap(n162(c,e),p); }
static ZIPPY_NOINLINE Space n155(Context& c, const Env& e) { auto a=n156(c,e); auto b=n160(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n154(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n155(c,e)}; Env n; n.spaces[37]=sv[0];  return routine_7(c,n); }
static ZIPPY_NOINLINE Space n164(Context& c, const Env& e) { return e.spaces.at(38); }
static ZIPPY_NOINLINE Space n166(Context& c, const Env& e) { return e.spaces.at(39); }
static ZIPPY_NOINLINE Space n168(Context& c, const Env& e) { return e.spaces.at(40); }
static ZIPPY_NOINLINE Path n174(Context& c, const Env& e) { return e.paths.at(36); }
static ZIPPY_NOINLINE Path n173(Context& c, const Env& e) { auto a=n20(c,e); auto b=n174(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n175(Context& c, const Env& e) { return e.paths.at(37); }
static ZIPPY_NOINLINE Path n172(Context& c, const Env& e) { auto a=n173(c,e); auto b=n175(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n176(Context& c, const Env& e) { return e.paths.at(38); }
static ZIPPY_NOINLINE Path n171(Context& c, const Env& e) { auto a=n172(c,e); auto b=n176(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n177(Context& c, const Env& e) { return e.paths.at(39); }
static ZIPPY_NOINLINE Path n170(Context& c, const Env& e) { auto a=n171(c,e); auto b=n177(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n178(Context& c, const Env& e) { return e.spaces.at(41); }
static ZIPPY_NOINLINE Space n169(Context& c, const Env& e) { std::vector<Path> pv{n170(c,e)}; std::vector<Space> sv{n178(c,e)}; Env n; n.paths[40]=pv[0];n.spaces[42]=sv[0];  return routine_12(c,n); }
static ZIPPY_NOINLINE Space n167(Context& c, const Env& e) { return iterate(c,e,n168(c,e),39,41,n169); }
static ZIPPY_NOINLINE Space n165(Context& c, const Env& e) { return iterate(c,e,n166(c,e),38,40,n167); }
static ZIPPY_NOINLINE Space n163(Context& c, const Env& e) { return iterate(c,e,n164(c,e),37,39,n165); }
static ZIPPY_NOINLINE Space n153(Context& c, const Env& e) { return iterate(c,e,n154(c,e),36,38,n163); }
static ZIPPY_NOINLINE Space n126(Context& c, const Env& e) { auto a=n127(c,e); auto b=n153(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n181(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n182(Context& c, const Env& e) { return e.paths.at(19); }
static ZIPPY_NOINLINE Path n180(Context& c, const Env& e) { auto a=n181(c,e); auto b=n182(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n179(Context& c, const Env& e) { return singleton(n180(c,e)); }
static ZIPPY_NOINLINE Space n125(Context& c, const Env& e) { auto a=n126(c,e); if(a.empty()) return a; return compose(a,n179(c,e)); }
static ZIPPY_NOINLINE Space n184(Context& c, const Env& e) { return e.spaces.at(43); }
static ZIPPY_NOINLINE Space n186(Context& c, const Env& e) { return e.spaces.at(44); }
static ZIPPY_NOINLINE Space n188(Context& c, const Env& e) { return e.spaces.at(45); }
static ZIPPY_NOINLINE Path n194(Context& c, const Env& e) { return e.paths.at(41); }
static ZIPPY_NOINLINE Path n193(Context& c, const Env& e) { auto a=n20(c,e); auto b=n194(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n195(Context& c, const Env& e) { return e.paths.at(42); }
static ZIPPY_NOINLINE Path n192(Context& c, const Env& e) { auto a=n193(c,e); auto b=n195(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n196(Context& c, const Env& e) { return e.paths.at(43); }
static ZIPPY_NOINLINE Path n191(Context& c, const Env& e) { auto a=n192(c,e); auto b=n196(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n197(Context& c, const Env& e) { return e.paths.at(44); }
static ZIPPY_NOINLINE Path n190(Context& c, const Env& e) { auto a=n191(c,e); auto b=n197(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n198(Context& c, const Env& e) { return e.spaces.at(46); }
static ZIPPY_NOINLINE Space n189(Context& c, const Env& e) { std::vector<Path> pv{n190(c,e)}; std::vector<Space> sv{n198(c,e)}; Env n; n.paths[45]=pv[0];n.spaces[47]=sv[0];  return routine_13(c,n); }
static ZIPPY_NOINLINE Space n187(Context& c, const Env& e) { return iterate(c,e,n188(c,e),44,46,n189); }
static ZIPPY_NOINLINE Space n185(Context& c, const Env& e) { return iterate(c,e,n186(c,e),43,45,n187); }
static ZIPPY_NOINLINE Space n183(Context& c, const Env& e) { return iterate(c,e,n184(c,e),42,44,n185); }
static ZIPPY_NOINLINE Space n124(Context& c, const Env& e) { return iterate(c,e,n125(c,e),41,43,n183); }
static ZIPPY_NOINLINE Space routine_14(Context& c,const Env& e) { return n124(c,e); }
static ZIPPY_NOINLINE Path n201(Context& c, const Env& e) { return e.paths.at(9); }
static ZIPPY_NOINLINE Path n202(Context& c, const Env& e) { return e.paths.at(24); }
static ZIPPY_NOINLINE Path n200(Context& c, const Env& e) { auto a=n201(c,e); auto b=n202(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n199(Context& c, const Env& e) { std::vector<Path> pv{n200(c,e)}; std::vector<Space> sv{}; Env n; n.paths[30]=pv[0];  return routine_25(c,n); }
static ZIPPY_NOINLINE Space routine_17(Context& c,const Env& e) { return n199(c,e); }
static ZIPPY_NOINLINE Path n211(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Path n212(Context& c, const Env& e) { return e.paths.at(29); }
static ZIPPY_NOINLINE Path n210(Context& c, const Env& e) { auto a=n211(c,e); auto b=n212(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n209(Context& c, const Env& e) { std::vector<Path> pv{n210(c,e)}; std::vector<Space> sv{}; Env n; n.paths[30]=pv[0];  return routine_25(c,n); }
static ZIPPY_NOINLINE Path n214(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n215(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n213(Context& c, const Env& e) { auto p=n214(c,e); return unwrap(n215(c,e),p); }
static ZIPPY_NOINLINE Space n208(Context& c, const Env& e) { auto a=n209(c,e); auto b=n213(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n207(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n208(c,e)}; Env n; n.spaces[37]=sv[0];  return routine_7(c,n); }
static ZIPPY_NOINLINE Space n217(Context& c, const Env& e) { return e.spaces.at(48); }
static ZIPPY_NOINLINE Space n219(Context& c, const Env& e) { return e.spaces.at(49); }
static ZIPPY_NOINLINE Space n221(Context& c, const Env& e) { return e.spaces.at(50); }
static ZIPPY_NOINLINE Path n227(Context& c, const Env& e) { return e.paths.at(46); }
static ZIPPY_NOINLINE Path n226(Context& c, const Env& e) { auto a=n20(c,e); auto b=n227(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n228(Context& c, const Env& e) { return e.paths.at(47); }
static ZIPPY_NOINLINE Path n225(Context& c, const Env& e) { auto a=n226(c,e); auto b=n228(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n229(Context& c, const Env& e) { return e.paths.at(48); }
static ZIPPY_NOINLINE Path n224(Context& c, const Env& e) { auto a=n225(c,e); auto b=n229(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n230(Context& c, const Env& e) { return e.paths.at(49); }
static ZIPPY_NOINLINE Path n223(Context& c, const Env& e) { auto a=n224(c,e); auto b=n230(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n231(Context& c, const Env& e) { return e.spaces.at(51); }
static ZIPPY_NOINLINE Space n222(Context& c, const Env& e) { std::vector<Path> pv{n223(c,e)}; std::vector<Space> sv{n231(c,e)}; Env n; n.paths[50]=pv[0];n.spaces[52]=sv[0];  return routine_20(c,n); }
static ZIPPY_NOINLINE Space n220(Context& c, const Env& e) { return iterate(c,e,n221(c,e),49,51,n222); }
static ZIPPY_NOINLINE Space n218(Context& c, const Env& e) { return iterate(c,e,n219(c,e),48,50,n220); }
static ZIPPY_NOINLINE Space n216(Context& c, const Env& e) { return iterate(c,e,n217(c,e),47,49,n218); }
static ZIPPY_NOINLINE Space n206(Context& c, const Env& e) { return iterate(c,e,n207(c,e),46,48,n216); }
static ZIPPY_NOINLINE Path n237(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Path n238(Context& c, const Env& e) { return e.paths.at(29); }
static ZIPPY_NOINLINE Path n236(Context& c, const Env& e) { auto a=n237(c,e); auto b=n238(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n235(Context& c, const Env& e) { std::vector<Path> pv{n236(c,e)}; std::vector<Space> sv{}; Env n; n.paths[30]=pv[0];  return routine_25(c,n); }
static ZIPPY_NOINLINE Path n240(Context& c, const Env& e) { return Path{1,1,1,1}; }
static ZIPPY_NOINLINE Space n241(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n239(Context& c, const Env& e) { auto p=n240(c,e); return unwrap(n241(c,e),p); }
static ZIPPY_NOINLINE Space n234(Context& c, const Env& e) { auto a=n235(c,e); auto b=n239(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n233(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n234(c,e)}; Env n; n.spaces[53]=sv[0];  return routine_8(c,n); }
static ZIPPY_NOINLINE Space n243(Context& c, const Env& e) { return e.spaces.at(54); }
static ZIPPY_NOINLINE Space n245(Context& c, const Env& e) { return e.spaces.at(55); }
static ZIPPY_NOINLINE Space n247(Context& c, const Env& e) { return e.spaces.at(56); }
static ZIPPY_NOINLINE Path n253(Context& c, const Env& e) { return e.paths.at(51); }
static ZIPPY_NOINLINE Path n252(Context& c, const Env& e) { auto a=n20(c,e); auto b=n253(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n254(Context& c, const Env& e) { return e.paths.at(52); }
static ZIPPY_NOINLINE Path n251(Context& c, const Env& e) { auto a=n252(c,e); auto b=n254(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n255(Context& c, const Env& e) { return e.paths.at(53); }
static ZIPPY_NOINLINE Path n250(Context& c, const Env& e) { auto a=n251(c,e); auto b=n255(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n256(Context& c, const Env& e) { return e.paths.at(54); }
static ZIPPY_NOINLINE Path n249(Context& c, const Env& e) { auto a=n250(c,e); auto b=n256(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n257(Context& c, const Env& e) { return e.spaces.at(57); }
static ZIPPY_NOINLINE Space n248(Context& c, const Env& e) { std::vector<Path> pv{n249(c,e)}; std::vector<Space> sv{n257(c,e)}; Env n; n.paths[55]=pv[0];n.spaces[58]=sv[0];  return routine_21(c,n); }
static ZIPPY_NOINLINE Space n246(Context& c, const Env& e) { return iterate(c,e,n247(c,e),54,57,n248); }
static ZIPPY_NOINLINE Space n244(Context& c, const Env& e) { return iterate(c,e,n245(c,e),53,56,n246); }
static ZIPPY_NOINLINE Space n242(Context& c, const Env& e) { return iterate(c,e,n243(c,e),52,55,n244); }
static ZIPPY_NOINLINE Space n232(Context& c, const Env& e) { return iterate(c,e,n233(c,e),51,54,n242); }
static ZIPPY_NOINLINE Space n205(Context& c, const Env& e) { auto a=n206(c,e); auto b=n232(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n260(Context& c, const Env& e) { return e.paths.at(14); }
static ZIPPY_NOINLINE Path n261(Context& c, const Env& e) { return e.paths.at(29); }
static ZIPPY_NOINLINE Path n259(Context& c, const Env& e) { auto a=n260(c,e); auto b=n261(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n258(Context& c, const Env& e) { return singleton(n259(c,e)); }
static ZIPPY_NOINLINE Space n204(Context& c, const Env& e) { auto a=n205(c,e); if(a.empty()) return a; return compose(a,n258(c,e)); }
static ZIPPY_NOINLINE Space n263(Context& c, const Env& e) { return e.spaces.at(59); }
static ZIPPY_NOINLINE Space n265(Context& c, const Env& e) { return e.spaces.at(60); }
static ZIPPY_NOINLINE Space n267(Context& c, const Env& e) { return e.spaces.at(61); }
static ZIPPY_NOINLINE Path n273(Context& c, const Env& e) { return e.paths.at(56); }
static ZIPPY_NOINLINE Path n272(Context& c, const Env& e) { auto a=n20(c,e); auto b=n273(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n274(Context& c, const Env& e) { return e.paths.at(57); }
static ZIPPY_NOINLINE Path n271(Context& c, const Env& e) { auto a=n272(c,e); auto b=n274(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n275(Context& c, const Env& e) { return e.paths.at(58); }
static ZIPPY_NOINLINE Path n270(Context& c, const Env& e) { auto a=n271(c,e); auto b=n275(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n276(Context& c, const Env& e) { return e.paths.at(59); }
static ZIPPY_NOINLINE Path n269(Context& c, const Env& e) { auto a=n270(c,e); auto b=n276(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n277(Context& c, const Env& e) { return e.spaces.at(62); }
static ZIPPY_NOINLINE Space n268(Context& c, const Env& e) { std::vector<Path> pv{n269(c,e)}; std::vector<Space> sv{n277(c,e)}; Env n; n.paths[60]=pv[0];n.spaces[63]=sv[0];  return routine_22(c,n); }
static ZIPPY_NOINLINE Space n266(Context& c, const Env& e) { return iterate(c,e,n267(c,e),59,62,n268); }
static ZIPPY_NOINLINE Space n264(Context& c, const Env& e) { return iterate(c,e,n265(c,e),58,61,n266); }
static ZIPPY_NOINLINE Space n262(Context& c, const Env& e) { return iterate(c,e,n263(c,e),57,60,n264); }
static ZIPPY_NOINLINE Space n203(Context& c, const Env& e) { return iterate(c,e,n204(c,e),56,59,n262); }
static ZIPPY_NOINLINE Space routine_23(Context& c,const Env& e) { return n203(c,e); }
static ZIPPY_NOINLINE Space n280(Context& c, const Env& e) { return e.spaces.at(31); }
static ZIPPY_NOINLINE Space n279(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n280(c,e)}; Env n; n.spaces[64]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n282(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n280(c,e)}; Env n; n.spaces[65]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n281(Context& c, const Env& e) { auto a=n280(c,e); auto b=n282(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n278(Context& c, const Env& e) { auto a=n279(c,e); auto b=n281(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space routine_6(Context& c,const Env& e) { return n278(c,e); }
static ZIPPY_NOINLINE Path n285(Context& c, const Env& e) { return e.paths.at(30); }
static ZIPPY_NOINLINE Space n284(Context& c, const Env& e) { return singleton(n285(c,e)); }
static ZIPPY_NOINLINE Space n287(Context& c, const Env& e) { return e.spaces.at(66); }
static ZIPPY_NOINLINE Space n289(Context& c, const Env& e) { return e.spaces.at(67); }
static ZIPPY_NOINLINE Space n291(Context& c, const Env& e) { return e.spaces.at(68); }
static ZIPPY_NOINLINE Path n297(Context& c, const Env& e) { return e.paths.at(61); }
static ZIPPY_NOINLINE Path n296(Context& c, const Env& e) { auto a=n20(c,e); auto b=n297(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n298(Context& c, const Env& e) { return e.paths.at(62); }
static ZIPPY_NOINLINE Path n295(Context& c, const Env& e) { auto a=n296(c,e); auto b=n298(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n299(Context& c, const Env& e) { return e.paths.at(63); }
static ZIPPY_NOINLINE Path n294(Context& c, const Env& e) { auto a=n295(c,e); auto b=n299(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n300(Context& c, const Env& e) { return e.paths.at(64); }
static ZIPPY_NOINLINE Path n293(Context& c, const Env& e) { auto a=n294(c,e); auto b=n300(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n301(Context& c, const Env& e) { return e.spaces.at(69); }
static ZIPPY_NOINLINE Space n292(Context& c, const Env& e) { std::vector<Path> pv{n293(c,e)}; std::vector<Space> sv{n301(c,e)}; Env n; n.paths[65]=pv[0];n.spaces[70]=sv[0];  return routine_10(c,n); }
static ZIPPY_NOINLINE Space n290(Context& c, const Env& e) { return iterate(c,e,n291(c,e),64,69,n292); }
static ZIPPY_NOINLINE Space n288(Context& c, const Env& e) { return iterate(c,e,n289(c,e),63,68,n290); }
static ZIPPY_NOINLINE Space n286(Context& c, const Env& e) { return iterate(c,e,n287(c,e),62,67,n288); }
static ZIPPY_NOINLINE Space n283(Context& c, const Env& e) { return iterate(c,e,n284(c,e),61,66,n286); }
static ZIPPY_NOINLINE Space routine_25(Context& c,const Env& e) { return n283(c,e); }
static ZIPPY_NOINLINE Path n303(Context& c, const Env& e) { return Path{1,1,1,133}; }
static ZIPPY_NOINLINE Space n302(Context& c, const Env& e) { return singleton(n303(c,e)); }
static ZIPPY_NOINLINE Space routine_11(Context& c,const Env& e) { return n302(c,e); }
static ZIPPY_NOINLINE Space n306(Context& c, const Env& e) { return e.spaces.at(37); }
static ZIPPY_NOINLINE Space n305(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n306(c,e)}; Env n; n.spaces[65]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n309(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n306(c,e)}; Env n; n.spaces[64]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n308(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n309(c,e)}; Env n; n.spaces[65]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n307(Context& c, const Env& e) { auto a=n306(c,e); auto b=n308(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n304(Context& c, const Env& e) { auto a=n305(c,e); auto b=n307(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space routine_7(Context& c,const Env& e) { return n304(c,e); }
static ZIPPY_NOINLINE Path n311(Context& c, const Env& e) { return Path{1,1,1,133}; }
static ZIPPY_NOINLINE Space n310(Context& c, const Env& e) { return singleton(n311(c,e)); }
static ZIPPY_NOINLINE Space routine_12(Context& c,const Env& e) { return n310(c,e); }
static ZIPPY_NOINLINE Space n312(Context& c, const Env& e) { return e.spaces.at(47); }
static ZIPPY_NOINLINE Space routine_13(Context& c,const Env& e) { return n312(c,e); }
static ZIPPY_NOINLINE Path n314(Context& c, const Env& e) { return Path{1,1,1,133}; }
static ZIPPY_NOINLINE Space n313(Context& c, const Env& e) { return singleton(n314(c,e)); }
static ZIPPY_NOINLINE Space routine_20(Context& c,const Env& e) { return n313(c,e); }
static ZIPPY_NOINLINE Space n318(Context& c, const Env& e) { return e.spaces.at(53); }
static ZIPPY_NOINLINE Space n317(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n318(c,e)}; Env n; n.spaces[64]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n316(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n317(c,e)}; Env n; n.spaces[65]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n320(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n318(c,e)}; Env n; n.spaces[71]=sv[0];  return routine_3(c,n); }
static ZIPPY_NOINLINE Space n319(Context& c, const Env& e) { auto a=n318(c,e); auto b=n320(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n315(Context& c, const Env& e) { auto a=n316(c,e); auto b=n319(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space routine_8(Context& c,const Env& e) { return n315(c,e); }
static ZIPPY_NOINLINE Path n322(Context& c, const Env& e) { return Path{1,1,1,133}; }
static ZIPPY_NOINLINE Space n321(Context& c, const Env& e) { return singleton(n322(c,e)); }
static ZIPPY_NOINLINE Space routine_21(Context& c,const Env& e) { return n321(c,e); }
static ZIPPY_NOINLINE Space n323(Context& c, const Env& e) { return e.spaces.at(63); }
static ZIPPY_NOINLINE Space routine_22(Context& c,const Env& e) { return n323(c,e); }
static ZIPPY_NOINLINE Space n326(Context& c, const Env& e) { return e.spaces.at(64).empty()?Space():singleton(Path{}); }
static ZIPPY_NOINLINE Space n328(Context& c, const Env& e) { return e.spaces.at(64); }
static ZIPPY_NOINLINE Space n330(Context& c, const Env& e) { return e.spaces.at(64); }
static ZIPPY_NOINLINE Space n329(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n330(c,e)}; Env n; n.spaces[72]=sv[0];  return routine_4(c,n); }
static ZIPPY_NOINLINE Space n327(Context& c, const Env& e) { auto a=n328(c,e); auto b=n329(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n325(Context& c, const Env& e) { auto a=n326(c,e); if(a.empty()) return a; return compose(a,n327(c,e)); }
static ZIPPY_NOINLINE Space n333(Context& c, const Env& e) { return singleton(n20(c,e)); }
static ZIPPY_NOINLINE Space n332(Context& c, const Env& e) { auto a=n333(c,e); auto b=n326(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n334(Context& c, const Env& e) { return Space(); }
static ZIPPY_NOINLINE Space n331(Context& c, const Env& e) { auto a=n332(c,e); if(a.empty()) return a; return compose(a,n334(c,e)); }
static ZIPPY_NOINLINE Space n324(Context& c, const Env& e) { auto a=n325(c,e); auto b=n331(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_1(Context& c,const Env& e) { return n324(c,e); }
static ZIPPY_NOINLINE Space n337(Context& c, const Env& e) { return e.spaces.at(65).empty()?Space():singleton(Path{}); }
static ZIPPY_NOINLINE Space n340(Context& c, const Env& e) { return e.spaces.at(65); }
static ZIPPY_NOINLINE Space n339(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n340(c,e)}; Env n; n.spaces[64]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n338(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n339(c,e)}; Env n; n.spaces[64]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n336(Context& c, const Env& e) { auto a=n337(c,e); if(a.empty()) return a; return compose(a,n338(c,e)); }
static ZIPPY_NOINLINE Space n342(Context& c, const Env& e) { auto a=n333(c,e); auto b=n337(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n341(Context& c, const Env& e) { auto a=n342(c,e); if(a.empty()) return a; return compose(a,n334(c,e)); }
static ZIPPY_NOINLINE Space n335(Context& c, const Env& e) { auto a=n336(c,e); auto b=n341(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_2(Context& c,const Env& e) { return n335(c,e); }
static ZIPPY_NOINLINE Space n344(Context& c, const Env& e) { return e.spaces.at(70); }
static ZIPPY_NOINLINE Space n346(Context& c, const Env& e) { return e.spaces.at(73); }
static ZIPPY_NOINLINE Space n348(Context& c, const Env& e) { return e.spaces.at(74); }
static ZIPPY_NOINLINE Space n350(Context& c, const Env& e) { return e.spaces.at(75); }
static ZIPPY_NOINLINE Path n356(Context& c, const Env& e) { return e.paths.at(66); }
static ZIPPY_NOINLINE Path n355(Context& c, const Env& e) { auto a=n20(c,e); auto b=n356(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n357(Context& c, const Env& e) { return e.paths.at(67); }
static ZIPPY_NOINLINE Path n354(Context& c, const Env& e) { auto a=n355(c,e); auto b=n357(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n358(Context& c, const Env& e) { return e.paths.at(68); }
static ZIPPY_NOINLINE Path n353(Context& c, const Env& e) { auto a=n354(c,e); auto b=n358(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n359(Context& c, const Env& e) { return e.paths.at(69); }
static ZIPPY_NOINLINE Path n352(Context& c, const Env& e) { auto a=n353(c,e); auto b=n359(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Path n360(Context& c, const Env& e) { return e.paths.at(65); }
static ZIPPY_NOINLINE Space n361(Context& c, const Env& e) { return e.spaces.at(76); }
static ZIPPY_NOINLINE Space n351(Context& c, const Env& e) { std::vector<Path> pv{n352(c,e),n360(c,e)}; std::vector<Space> sv{n361(c,e)}; Env n; n.paths[70]=pv[0];n.paths[65]=pv[1];n.spaces[77]=sv[0];  return routine_19(c,n); }
static ZIPPY_NOINLINE Space n349(Context& c, const Env& e) { return iterate(c,e,n350(c,e),69,76,n351); }
static ZIPPY_NOINLINE Space n347(Context& c, const Env& e) { return iterate(c,e,n348(c,e),68,75,n349); }
static ZIPPY_NOINLINE Space n345(Context& c, const Env& e) { return iterate(c,e,n346(c,e),67,74,n347); }
static ZIPPY_NOINLINE Space n343(Context& c, const Env& e) { return iterate(c,e,n344(c,e),66,73,n345); }
static ZIPPY_NOINLINE Space routine_10(Context& c,const Env& e) { return n343(c,e); }
static ZIPPY_NOINLINE Space n364(Context& c, const Env& e) { return e.spaces.at(71).empty()?Space():singleton(Path{}); }
static ZIPPY_NOINLINE Space n367(Context& c, const Env& e) { return e.spaces.at(71); }
static ZIPPY_NOINLINE Space n366(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n367(c,e)}; Env n; n.spaces[65]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n365(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n366(c,e)}; Env n; n.spaces[65]=sv[0];  return routine_2(c,n); }
static ZIPPY_NOINLINE Space n363(Context& c, const Env& e) { auto a=n364(c,e); if(a.empty()) return a; return compose(a,n365(c,e)); }
static ZIPPY_NOINLINE Space n369(Context& c, const Env& e) { auto a=n333(c,e); auto b=n364(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n368(Context& c, const Env& e) { auto a=n369(c,e); if(a.empty()) return a; return compose(a,n334(c,e)); }
static ZIPPY_NOINLINE Space n362(Context& c, const Env& e) { auto a=n363(c,e); auto b=n368(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_3(Context& c,const Env& e) { return n362(c,e); }
static ZIPPY_NOINLINE Space n375(Context& c, const Env& e) { return e.spaces.at(72); }
static ZIPPY_NOINLINE Space n374(Context& c, const Env& e) { static const Space allowed=literal_text("1 0 ");return first_matching(n375(c,e),allowed,false); }
static ZIPPY_NOINLINE Space n373(Context& c, const Env& e) { auto a=n374(c,e); auto b=n333(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n376(Context& c, const Env& e) { return iterate(c,e,n374(c,e),71,78,n333); }
static ZIPPY_NOINLINE Space n372(Context& c, const Env& e) { auto a=n373(c,e); auto b=n376(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n371(Context& c, const Env& e) { auto a=n372(c,e); if(a.empty()) return a; return compose(a,n333(c,e)); }
static ZIPPY_NOINLINE Space n378(Context& c, const Env& e) { auto a=n333(c,e); auto b=n372(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n381(Context& c, const Env& e) { return e.spaces.at(72); }
static ZIPPY_NOINLINE Space n380(Context& c, const Env& e) { static const auto order=paths_text("133 4 1 1 1 26 4 1 1 1 28 4 1 1 1 29 4 1 1 1 30 4 1 1 1 31 4 1 1 1 32 4 1 1 1 33 4 1 1 1 34 4 1 1 1 35 4 1 1 1 36 4 1 1 1 37 4 1 1 1 27 4 1 1 1 38 4 1 1 1 40 4 1 1 1 41 4 1 1 1 42 4 1 1 1 43 4 1 1 1 44 4 1 1 1 45 4 1 1 1 46 4 1 1 1 47 4 1 1 1 48 4 1 1 1 39 4 1 1 1 49 4 1 1 1 51 4 1 1 1 52 4 1 1 1 53 4 1 1 1 54 4 1 1 1 55 4 1 1 1 56 4 1 1 1 57 4 1 1 1 58 4 1 1 1 59 4 1 1 1 50 4 1 1 1 60 4 1 1 1 62 4 1 1 1 63 4 1 1 1 64 4 1 1 1 65 4 1 1 1 66 4 1 1 1 67 4 1 1 1 68 4 1 1 1 69 4 1 1 1 70 4 1 1 1 61 4 1 1 1 71 4 1 1 1 73 4 1 1 1 74 4 1 1 1 75 4 1 1 1 76 4 1 1 1 77 4 1 1 1 78 4 1 1 1 79 4 1 1 1 80 4 1 1 1 81 4 1 1 1 72 4 1 1 1 82 4 1 1 1 84 4 1 1 1 85 4 1 1 1 86 4 1 1 1 87 4 1 1 1 88 4 1 1 1 83 4 1 1 1 89 4 1 1 1 90 4 1 1 1 2 4 1 1 1 5 4 1 1 1 3 4 1 1 1 4 4 1 1 1 9 4 1 1 1 6 4 1 1 1 7 4 1 1 1 21 4 1 1 1 16 4 1 1 1 22 4 1 1 1 10 4 1 1 1 17 4 1 1 1 18 4 1 1 1 8 4 1 1 1 19 4 1 1 1 25 4 1 1 1 11 4 1 1 1 91 4 1 1 1 92 4 1 1 1 93 4 1 1 1 94 4 1 1 1 95 4 1 1 1 96 4 1 1 1 14 4 1 1 1 97 4 1 1 1 98 4 1 1 1 99 4 1 1 1 100 4 1 1 1 101 4 1 1 1 102 4 1 1 1 103 4 1 1 1 104 4 1 1 1 105 4 1 1 1 106 4 1 1 1 23 4 1 1 1 107 4 1 1 1 108 4 1 1 1 109 4 1 1 1 110 4 1 1 1 111 4 1 1 1 112 4 1 1 1 113 4 1 1 1 114 4 1 1 1 115 4 1 1 1 116 4 1 1 1 15 4 1 1 1 117 4 1 1 1 118 4 1 1 1 119 4 1 1 1 120 4 1 1 1 121 4 1 1 1 122 4 1 1 1 123 4 1 1 1 124 4 1 1 1 125 4 1 1 1 126 4 1 1 1 12 4 1 1 1 127 4 1 1 1 128 4 1 1 1 129 4 1 1 1 130 4 1 1 1 131 4 1 1 1 132 4 1 1 1 24 4 1 1 1 20 4 1 1 1 13 4 1 1 1 1 4 1 1 1 133");return first_listed(n381(c,e),order,true); }
static ZIPPY_NOINLINE Space n382(Context& c, const Env& e) { return e.spaces.at(72); }
static ZIPPY_NOINLINE Space n379(Context& c, const Env& e) { std::vector<Path> pv{n20(c,e)}; std::vector<Space> sv{n380(c,e),n382(c,e)}; Env n; n.paths[72]=pv[0];n.spaces[79]=sv[0];n.spaces[72]=sv[1];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n377(Context& c, const Env& e) { auto a=n378(c,e); if(a.empty()) return a; return compose(a,n379(c,e)); }
static ZIPPY_NOINLINE Space n370(Context& c, const Env& e) { auto a=n371(c,e); auto b=n377(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_4(Context& c,const Env& e) { return n370(c,e); }
static ZIPPY_NOINLINE Path n388(Context& c, const Env& e) { return e.paths.at(65); }
static ZIPPY_NOINLINE Space n389(Context& c, const Env& e) { static const Space value=literal_text("129 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 5 1 1 1 2 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 8 1 1 1 17 8 1 1 1 9 1 1 1 4 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 25 8 1 1 1 12 1 1 1 15 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 18 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 21 8 1 1 1 17 1 1 1 10 8 1 1 1 18 1 1 1 5 8 1 1 1 19 1 1 1 8 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 22 1 1 1 16 8 1 1 1 23 1 1 1 14 8 1 1 1 24 1 1 1 12 8 1 1 1 25 1 1 1 19 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 39 8 1 1 1 28 1 1 1 29 8 1 1 1 29 1 1 1 30 8 1 1 1 30 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 40 8 1 1 1 39 1 1 1 50 8 1 1 1 40 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 51 8 1 1 1 50 1 1 1 61 8 1 1 1 51 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 62 8 1 1 1 61 1 1 1 72 8 1 1 1 62 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 73 8 1 1 1 72 1 1 1 83 8 1 1 1 73 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 84 8 1 1 1 83 1 1 1 89 8 1 1 1 84 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 89 1 1 1 90 8 1 1 1 90 1 1 1 28 8 1 1 1 91 1 1 1 11 8 1 1 1 92 1 1 1 91 8 1 1 1 93 1 1 1 92 8 1 1 1 94 1 1 1 93 8 1 1 1 95 1 1 1 94 8 1 1 1 96 1 1 1 95 8 1 1 1 97 1 1 1 96 8 1 1 1 98 1 1 1 97 8 1 1 1 99 1 1 1 98 8 1 1 1 100 1 1 1 99 8 1 1 1 101 1 1 1 100 8 1 1 1 102 1 1 1 101 8 1 1 1 103 1 1 1 102 8 1 1 1 104 1 1 1 103 8 1 1 1 105 1 1 1 104 8 1 1 1 106 1 1 1 105 8 1 1 1 107 1 1 1 106 8 1 1 1 108 1 1 1 107 8 1 1 1 109 1 1 1 108 8 1 1 1 110 1 1 1 109 8 1 1 1 111 1 1 1 110 8 1 1 1 112 1 1 1 111 8 1 1 1 113 1 1 1 112 8 1 1 1 114 1 1 1 113 8 1 1 1 115 1 1 1 114 8 1 1 1 116 1 1 1 115 8 1 1 1 117 1 1 1 116 8 1 1 1 118 1 1 1 117 8 1 1 1 119 1 1 1 118 8 1 1 1 120 1 1 1 119 8 1 1 1 121 1 1 1 120 8 1 1 1 122 1 1 1 121 8 1 1 1 123 1 1 1 122 8 1 1 1 124 1 1 1 123 8 1 1 1 125 1 1 1 124 8 1 1 1 126 1 1 1 125 8 1 1 1 127 1 1 1 126 8 1 1 1 128 1 1 1 127 8 1 1 1 129 1 1 1 128 8 1 1 1 130 1 1 1 129 8 1 1 1 131 1 1 1 130"); return value; }
static ZIPPY_NOINLINE Space n387(Context& c, const Env& e) { auto p=n388(c,e); return unwrap(n389(c,e),p); }
static ZIPPY_NOINLINE Path n391(Context& c, const Env& e) { return e.paths.at(65); }
static ZIPPY_NOINLINE Space n392(Context& c, const Env& e) { static const Space value=literal_text("129 8 1 1 1 2 1 1 1 2 8 1 1 1 3 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 5 1 1 1 5 8 1 1 1 6 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 8 1 1 1 8 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 11 1 1 1 11 8 1 1 1 12 1 1 1 12 8 1 1 1 13 1 1 1 13 8 1 1 1 14 1 1 1 14 8 1 1 1 15 1 1 1 15 8 1 1 1 16 1 1 1 16 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 19 8 1 1 1 20 1 1 1 20 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 28 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 30 1 1 1 30 8 1 1 1 31 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 40 1 1 1 40 8 1 1 1 41 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 51 1 1 1 51 8 1 1 1 52 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 62 1 1 1 62 8 1 1 1 63 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 73 1 1 1 73 8 1 1 1 74 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 84 1 1 1 84 8 1 1 1 85 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 89 1 1 1 89 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 131 1 1 1 131"); return value; }
static ZIPPY_NOINLINE Space n390(Context& c, const Env& e) { auto p=n391(c,e); return unwrap(n392(c,e),p); }
static ZIPPY_NOINLINE Space n386(Context& c, const Env& e) { auto a=n387(c,e); auto b=n390(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n394(Context& c, const Env& e) { return e.paths.at(65); }
static ZIPPY_NOINLINE Space n395(Context& c, const Env& e) { static const Space value=literal_text("129 8 1 1 1 2 1 1 1 5 8 1 1 1 3 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 6 8 1 1 1 10 1 1 1 17 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 18 1 1 1 14 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 21 1 1 1 16 8 1 1 1 22 1 1 1 10 8 1 1 1 23 1 1 1 15 8 1 1 1 24 1 1 1 20 8 1 1 1 25 1 1 1 11 8 1 1 1 26 1 1 1 2 8 1 1 1 27 1 1 1 26 8 1 1 1 28 1 1 1 90 8 1 1 1 29 1 1 1 28 8 1 1 1 30 1 1 1 29 8 1 1 1 31 1 1 1 30 8 1 1 1 32 1 1 1 31 8 1 1 1 33 1 1 1 32 8 1 1 1 34 1 1 1 33 8 1 1 1 35 1 1 1 34 8 1 1 1 36 1 1 1 35 8 1 1 1 37 1 1 1 36 8 1 1 1 38 1 1 1 37 8 1 1 1 39 1 1 1 27 8 1 1 1 40 1 1 1 38 8 1 1 1 41 1 1 1 40 8 1 1 1 42 1 1 1 41 8 1 1 1 43 1 1 1 42 8 1 1 1 44 1 1 1 43 8 1 1 1 45 1 1 1 44 8 1 1 1 46 1 1 1 45 8 1 1 1 47 1 1 1 46 8 1 1 1 48 1 1 1 47 8 1 1 1 49 1 1 1 48 8 1 1 1 50 1 1 1 39 8 1 1 1 51 1 1 1 49 8 1 1 1 52 1 1 1 51 8 1 1 1 53 1 1 1 52 8 1 1 1 54 1 1 1 53 8 1 1 1 55 1 1 1 54 8 1 1 1 56 1 1 1 55 8 1 1 1 57 1 1 1 56 8 1 1 1 58 1 1 1 57 8 1 1 1 59 1 1 1 58 8 1 1 1 60 1 1 1 59 8 1 1 1 61 1 1 1 50 8 1 1 1 62 1 1 1 60 8 1 1 1 63 1 1 1 62 8 1 1 1 64 1 1 1 63 8 1 1 1 65 1 1 1 64 8 1 1 1 66 1 1 1 65 8 1 1 1 67 1 1 1 66 8 1 1 1 68 1 1 1 67 8 1 1 1 69 1 1 1 68 8 1 1 1 70 1 1 1 69 8 1 1 1 71 1 1 1 70 8 1 1 1 72 1 1 1 61 8 1 1 1 73 1 1 1 71 8 1 1 1 74 1 1 1 73 8 1 1 1 75 1 1 1 74 8 1 1 1 76 1 1 1 75 8 1 1 1 77 1 1 1 76 8 1 1 1 78 1 1 1 77 8 1 1 1 79 1 1 1 78 8 1 1 1 80 1 1 1 79 8 1 1 1 81 1 1 1 80 8 1 1 1 82 1 1 1 81 8 1 1 1 83 1 1 1 72 8 1 1 1 84 1 1 1 82 8 1 1 1 85 1 1 1 84 8 1 1 1 86 1 1 1 85 8 1 1 1 87 1 1 1 86 8 1 1 1 89 1 1 1 83 8 1 1 1 90 1 1 1 89 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n393(Context& c, const Env& e) { auto p=n394(c,e); return unwrap(n395(c,e),p); }
static ZIPPY_NOINLINE Space n385(Context& c, const Env& e) { auto a=n386(c,e); auto b=n393(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n399(Context& c, const Env& e) { return e.paths.at(70); }
static ZIPPY_NOINLINE Space n400(Context& c, const Env& e) { static const Space value=literal_text("129 8 1 1 1 2 1 1 1 26 8 1 1 1 3 1 1 1 13 8 1 1 1 4 1 1 1 3 8 1 1 1 5 1 1 1 2 8 1 1 1 6 1 1 1 9 8 1 1 1 7 1 1 1 6 8 1 1 1 8 1 1 1 17 8 1 1 1 9 1 1 1 4 8 1 1 1 10 1 1 1 22 8 1 1 1 11 1 1 1 25 8 1 1 1 12 1 1 1 15 8 1 1 1 13 1 1 1 20 8 1 1 1 14 1 1 1 18 8 1 1 1 15 1 1 1 23 8 1 1 1 16 1 1 1 21 8 1 1 1 17 1 1 1 10 8 1 1 1 18 1 1 1 5 8 1 1 1 19 1 1 1 8 8 1 1 1 20 1 1 1 24 8 1 1 1 21 1 1 1 7 8 1 1 1 22 1 1 1 16 8 1 1 1 23 1 1 1 14 8 1 1 1 24 1 1 1 12 8 1 1 1 25 1 1 1 19 8 1 1 1 26 1 1 1 27 8 1 1 1 27 1 1 1 39 8 1 1 1 28 1 1 1 29 8 1 1 1 29 1 1 1 30 8 1 1 1 30 1 1 1 31 8 1 1 1 31 1 1 1 32 8 1 1 1 32 1 1 1 33 8 1 1 1 33 1 1 1 34 8 1 1 1 34 1 1 1 35 8 1 1 1 35 1 1 1 36 8 1 1 1 36 1 1 1 37 8 1 1 1 37 1 1 1 38 8 1 1 1 38 1 1 1 40 8 1 1 1 39 1 1 1 50 8 1 1 1 40 1 1 1 41 8 1 1 1 41 1 1 1 42 8 1 1 1 42 1 1 1 43 8 1 1 1 43 1 1 1 44 8 1 1 1 44 1 1 1 45 8 1 1 1 45 1 1 1 46 8 1 1 1 46 1 1 1 47 8 1 1 1 47 1 1 1 48 8 1 1 1 48 1 1 1 49 8 1 1 1 49 1 1 1 51 8 1 1 1 50 1 1 1 61 8 1 1 1 51 1 1 1 52 8 1 1 1 52 1 1 1 53 8 1 1 1 53 1 1 1 54 8 1 1 1 54 1 1 1 55 8 1 1 1 55 1 1 1 56 8 1 1 1 56 1 1 1 57 8 1 1 1 57 1 1 1 58 8 1 1 1 58 1 1 1 59 8 1 1 1 59 1 1 1 60 8 1 1 1 60 1 1 1 62 8 1 1 1 61 1 1 1 72 8 1 1 1 62 1 1 1 63 8 1 1 1 63 1 1 1 64 8 1 1 1 64 1 1 1 65 8 1 1 1 65 1 1 1 66 8 1 1 1 66 1 1 1 67 8 1 1 1 67 1 1 1 68 8 1 1 1 68 1 1 1 69 8 1 1 1 69 1 1 1 70 8 1 1 1 70 1 1 1 71 8 1 1 1 71 1 1 1 73 8 1 1 1 72 1 1 1 83 8 1 1 1 73 1 1 1 74 8 1 1 1 74 1 1 1 75 8 1 1 1 75 1 1 1 76 8 1 1 1 76 1 1 1 77 8 1 1 1 77 1 1 1 78 8 1 1 1 78 1 1 1 79 8 1 1 1 79 1 1 1 80 8 1 1 1 80 1 1 1 81 8 1 1 1 81 1 1 1 82 8 1 1 1 82 1 1 1 84 8 1 1 1 83 1 1 1 89 8 1 1 1 84 1 1 1 85 8 1 1 1 85 1 1 1 86 8 1 1 1 86 1 1 1 87 8 1 1 1 87 1 1 1 88 8 1 1 1 89 1 1 1 90 8 1 1 1 90 1 1 1 28 8 1 1 1 91 1 1 1 11 8 1 1 1 92 1 1 1 91 8 1 1 1 93 1 1 1 92 8 1 1 1 94 1 1 1 93 8 1 1 1 95 1 1 1 94 8 1 1 1 96 1 1 1 95 8 1 1 1 97 1 1 1 96 8 1 1 1 98 1 1 1 97 8 1 1 1 99 1 1 1 98 8 1 1 1 100 1 1 1 99 8 1 1 1 101 1 1 1 100 8 1 1 1 102 1 1 1 101 8 1 1 1 103 1 1 1 102 8 1 1 1 104 1 1 1 103 8 1 1 1 105 1 1 1 104 8 1 1 1 106 1 1 1 105 8 1 1 1 107 1 1 1 106 8 1 1 1 108 1 1 1 107 8 1 1 1 109 1 1 1 108 8 1 1 1 110 1 1 1 109 8 1 1 1 111 1 1 1 110 8 1 1 1 112 1 1 1 111 8 1 1 1 113 1 1 1 112 8 1 1 1 114 1 1 1 113 8 1 1 1 115 1 1 1 114 8 1 1 1 116 1 1 1 115 8 1 1 1 117 1 1 1 116 8 1 1 1 118 1 1 1 117 8 1 1 1 119 1 1 1 118 8 1 1 1 120 1 1 1 119 8 1 1 1 121 1 1 1 120 8 1 1 1 122 1 1 1 121 8 1 1 1 123 1 1 1 122 8 1 1 1 124 1 1 1 123 8 1 1 1 125 1 1 1 124 8 1 1 1 126 1 1 1 125 8 1 1 1 127 1 1 1 126 8 1 1 1 128 1 1 1 127 8 1 1 1 129 1 1 1 128 8 1 1 1 130 1 1 1 129 8 1 1 1 131 1 1 1 130"); return value; }
static ZIPPY_NOINLINE Space n398(Context& c, const Env& e) { auto p=n399(c,e); return unwrap(n400(c,e),p); }
static ZIPPY_NOINLINE Path n402(Context& c, const Env& e) { return e.paths.at(70); }
static ZIPPY_NOINLINE Space n403(Context& c, const Env& e) { static const Space value=literal_text("129 8 1 1 1 2 1 1 1 2 8 1 1 1 3 1 1 1 3 8 1 1 1 4 1 1 1 4 8 1 1 1 5 1 1 1 5 8 1 1 1 6 1 1 1 6 8 1 1 1 7 1 1 1 7 8 1 1 1 8 1 1 1 8 8 1 1 1 9 1 1 1 9 8 1 1 1 10 1 1 1 10 8 1 1 1 11 1 1 1 11 8 1 1 1 12 1 1 1 12 8 1 1 1 13 1 1 1 13 8 1 1 1 14 1 1 1 14 8 1 1 1 15 1 1 1 15 8 1 1 1 16 1 1 1 16 8 1 1 1 17 1 1 1 17 8 1 1 1 18 1 1 1 18 8 1 1 1 19 1 1 1 19 8 1 1 1 20 1 1 1 20 8 1 1 1 21 1 1 1 21 8 1 1 1 22 1 1 1 22 8 1 1 1 23 1 1 1 23 8 1 1 1 24 1 1 1 24 8 1 1 1 25 1 1 1 25 8 1 1 1 26 1 1 1 26 8 1 1 1 27 1 1 1 27 8 1 1 1 28 1 1 1 28 8 1 1 1 29 1 1 1 29 8 1 1 1 30 1 1 1 30 8 1 1 1 31 1 1 1 31 8 1 1 1 32 1 1 1 32 8 1 1 1 33 1 1 1 33 8 1 1 1 34 1 1 1 34 8 1 1 1 35 1 1 1 35 8 1 1 1 36 1 1 1 36 8 1 1 1 37 1 1 1 37 8 1 1 1 38 1 1 1 38 8 1 1 1 39 1 1 1 39 8 1 1 1 40 1 1 1 40 8 1 1 1 41 1 1 1 41 8 1 1 1 42 1 1 1 42 8 1 1 1 43 1 1 1 43 8 1 1 1 44 1 1 1 44 8 1 1 1 45 1 1 1 45 8 1 1 1 46 1 1 1 46 8 1 1 1 47 1 1 1 47 8 1 1 1 48 1 1 1 48 8 1 1 1 49 1 1 1 49 8 1 1 1 50 1 1 1 50 8 1 1 1 51 1 1 1 51 8 1 1 1 52 1 1 1 52 8 1 1 1 53 1 1 1 53 8 1 1 1 54 1 1 1 54 8 1 1 1 55 1 1 1 55 8 1 1 1 56 1 1 1 56 8 1 1 1 57 1 1 1 57 8 1 1 1 58 1 1 1 58 8 1 1 1 59 1 1 1 59 8 1 1 1 60 1 1 1 60 8 1 1 1 61 1 1 1 61 8 1 1 1 62 1 1 1 62 8 1 1 1 63 1 1 1 63 8 1 1 1 64 1 1 1 64 8 1 1 1 65 1 1 1 65 8 1 1 1 66 1 1 1 66 8 1 1 1 67 1 1 1 67 8 1 1 1 68 1 1 1 68 8 1 1 1 69 1 1 1 69 8 1 1 1 70 1 1 1 70 8 1 1 1 71 1 1 1 71 8 1 1 1 72 1 1 1 72 8 1 1 1 73 1 1 1 73 8 1 1 1 74 1 1 1 74 8 1 1 1 75 1 1 1 75 8 1 1 1 76 1 1 1 76 8 1 1 1 77 1 1 1 77 8 1 1 1 78 1 1 1 78 8 1 1 1 79 1 1 1 79 8 1 1 1 80 1 1 1 80 8 1 1 1 81 1 1 1 81 8 1 1 1 82 1 1 1 82 8 1 1 1 83 1 1 1 83 8 1 1 1 84 1 1 1 84 8 1 1 1 85 1 1 1 85 8 1 1 1 86 1 1 1 86 8 1 1 1 87 1 1 1 87 8 1 1 1 89 1 1 1 89 8 1 1 1 90 1 1 1 90 8 1 1 1 91 1 1 1 91 8 1 1 1 92 1 1 1 92 8 1 1 1 93 1 1 1 93 8 1 1 1 94 1 1 1 94 8 1 1 1 95 1 1 1 95 8 1 1 1 96 1 1 1 96 8 1 1 1 97 1 1 1 97 8 1 1 1 98 1 1 1 98 8 1 1 1 99 1 1 1 99 8 1 1 1 100 1 1 1 100 8 1 1 1 101 1 1 1 101 8 1 1 1 102 1 1 1 102 8 1 1 1 103 1 1 1 103 8 1 1 1 104 1 1 1 104 8 1 1 1 105 1 1 1 105 8 1 1 1 106 1 1 1 106 8 1 1 1 107 1 1 1 107 8 1 1 1 108 1 1 1 108 8 1 1 1 109 1 1 1 109 8 1 1 1 110 1 1 1 110 8 1 1 1 111 1 1 1 111 8 1 1 1 112 1 1 1 112 8 1 1 1 113 1 1 1 113 8 1 1 1 114 1 1 1 114 8 1 1 1 115 1 1 1 115 8 1 1 1 116 1 1 1 116 8 1 1 1 117 1 1 1 117 8 1 1 1 118 1 1 1 118 8 1 1 1 119 1 1 1 119 8 1 1 1 120 1 1 1 120 8 1 1 1 121 1 1 1 121 8 1 1 1 122 1 1 1 122 8 1 1 1 123 1 1 1 123 8 1 1 1 124 1 1 1 124 8 1 1 1 125 1 1 1 125 8 1 1 1 126 1 1 1 126 8 1 1 1 127 1 1 1 127 8 1 1 1 128 1 1 1 128 8 1 1 1 129 1 1 1 129 8 1 1 1 130 1 1 1 130 8 1 1 1 131 1 1 1 131"); return value; }
static ZIPPY_NOINLINE Space n401(Context& c, const Env& e) { auto p=n402(c,e); return unwrap(n403(c,e),p); }
static ZIPPY_NOINLINE Space n397(Context& c, const Env& e) { auto a=n398(c,e); auto b=n401(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n405(Context& c, const Env& e) { return e.paths.at(70); }
static ZIPPY_NOINLINE Space n406(Context& c, const Env& e) { static const Space value=literal_text("129 8 1 1 1 2 1 1 1 5 8 1 1 1 3 1 1 1 4 8 1 1 1 4 1 1 1 9 8 1 1 1 5 1 1 1 18 8 1 1 1 6 1 1 1 7 8 1 1 1 7 1 1 1 21 8 1 1 1 8 1 1 1 19 8 1 1 1 9 1 1 1 6 8 1 1 1 10 1 1 1 17 8 1 1 1 11 1 1 1 91 8 1 1 1 12 1 1 1 24 8 1 1 1 13 1 1 1 3 8 1 1 1 14 1 1 1 23 8 1 1 1 15 1 1 1 12 8 1 1 1 16 1 1 1 22 8 1 1 1 17 1 1 1 8 8 1 1 1 18 1 1 1 14 8 1 1 1 19 1 1 1 25 8 1 1 1 20 1 1 1 13 8 1 1 1 21 1 1 1 16 8 1 1 1 22 1 1 1 10 8 1 1 1 23 1 1 1 15 8 1 1 1 24 1 1 1 20 8 1 1 1 25 1 1 1 11 8 1 1 1 26 1 1 1 2 8 1 1 1 27 1 1 1 26 8 1 1 1 28 1 1 1 90 8 1 1 1 29 1 1 1 28 8 1 1 1 30 1 1 1 29 8 1 1 1 31 1 1 1 30 8 1 1 1 32 1 1 1 31 8 1 1 1 33 1 1 1 32 8 1 1 1 34 1 1 1 33 8 1 1 1 35 1 1 1 34 8 1 1 1 36 1 1 1 35 8 1 1 1 37 1 1 1 36 8 1 1 1 38 1 1 1 37 8 1 1 1 39 1 1 1 27 8 1 1 1 40 1 1 1 38 8 1 1 1 41 1 1 1 40 8 1 1 1 42 1 1 1 41 8 1 1 1 43 1 1 1 42 8 1 1 1 44 1 1 1 43 8 1 1 1 45 1 1 1 44 8 1 1 1 46 1 1 1 45 8 1 1 1 47 1 1 1 46 8 1 1 1 48 1 1 1 47 8 1 1 1 49 1 1 1 48 8 1 1 1 50 1 1 1 39 8 1 1 1 51 1 1 1 49 8 1 1 1 52 1 1 1 51 8 1 1 1 53 1 1 1 52 8 1 1 1 54 1 1 1 53 8 1 1 1 55 1 1 1 54 8 1 1 1 56 1 1 1 55 8 1 1 1 57 1 1 1 56 8 1 1 1 58 1 1 1 57 8 1 1 1 59 1 1 1 58 8 1 1 1 60 1 1 1 59 8 1 1 1 61 1 1 1 50 8 1 1 1 62 1 1 1 60 8 1 1 1 63 1 1 1 62 8 1 1 1 64 1 1 1 63 8 1 1 1 65 1 1 1 64 8 1 1 1 66 1 1 1 65 8 1 1 1 67 1 1 1 66 8 1 1 1 68 1 1 1 67 8 1 1 1 69 1 1 1 68 8 1 1 1 70 1 1 1 69 8 1 1 1 71 1 1 1 70 8 1 1 1 72 1 1 1 61 8 1 1 1 73 1 1 1 71 8 1 1 1 74 1 1 1 73 8 1 1 1 75 1 1 1 74 8 1 1 1 76 1 1 1 75 8 1 1 1 77 1 1 1 76 8 1 1 1 78 1 1 1 77 8 1 1 1 79 1 1 1 78 8 1 1 1 80 1 1 1 79 8 1 1 1 81 1 1 1 80 8 1 1 1 82 1 1 1 81 8 1 1 1 83 1 1 1 72 8 1 1 1 84 1 1 1 82 8 1 1 1 85 1 1 1 84 8 1 1 1 86 1 1 1 85 8 1 1 1 87 1 1 1 86 8 1 1 1 89 1 1 1 83 8 1 1 1 90 1 1 1 89 8 1 1 1 91 1 1 1 92 8 1 1 1 92 1 1 1 93 8 1 1 1 93 1 1 1 94 8 1 1 1 94 1 1 1 95 8 1 1 1 95 1 1 1 96 8 1 1 1 96 1 1 1 97 8 1 1 1 97 1 1 1 98 8 1 1 1 98 1 1 1 99 8 1 1 1 99 1 1 1 100 8 1 1 1 100 1 1 1 101 8 1 1 1 101 1 1 1 102 8 1 1 1 102 1 1 1 103 8 1 1 1 103 1 1 1 104 8 1 1 1 104 1 1 1 105 8 1 1 1 105 1 1 1 106 8 1 1 1 106 1 1 1 107 8 1 1 1 107 1 1 1 108 8 1 1 1 108 1 1 1 109 8 1 1 1 109 1 1 1 110 8 1 1 1 110 1 1 1 111 8 1 1 1 111 1 1 1 112 8 1 1 1 112 1 1 1 113 8 1 1 1 113 1 1 1 114 8 1 1 1 114 1 1 1 115 8 1 1 1 115 1 1 1 116 8 1 1 1 116 1 1 1 117 8 1 1 1 117 1 1 1 118 8 1 1 1 118 1 1 1 119 8 1 1 1 119 1 1 1 120 8 1 1 1 120 1 1 1 121 8 1 1 1 121 1 1 1 122 8 1 1 1 122 1 1 1 123 8 1 1 1 123 1 1 1 124 8 1 1 1 124 1 1 1 125 8 1 1 1 125 1 1 1 126 8 1 1 1 126 1 1 1 127 8 1 1 1 127 1 1 1 128 8 1 1 1 128 1 1 1 129 8 1 1 1 129 1 1 1 130 8 1 1 1 130 1 1 1 131 8 1 1 1 131 1 1 1 132"); return value; }
static ZIPPY_NOINLINE Space n404(Context& c, const Env& e) { auto p=n405(c,e); return unwrap(n406(c,e),p); }
static ZIPPY_NOINLINE Space n396(Context& c, const Env& e) { auto a=n397(c,e); auto b=n404(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n384(Context& c, const Env& e) { auto a=n385(c,e); if(a.empty()) return a; return compose(a,n396(c,e)); }
static ZIPPY_NOINLINE Path n409(Context& c, const Env& e) { return e.paths.at(65); }
static ZIPPY_NOINLINE Path n410(Context& c, const Env& e) { return e.paths.at(70); }
static ZIPPY_NOINLINE Path n408(Context& c, const Env& e) { auto a=n409(c,e); auto b=n410(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n407(Context& c, const Env& e) { return singleton(n408(c,e)); }
static ZIPPY_NOINLINE Space n383(Context& c, const Env& e) { auto a=n384(c,e); auto b=n407(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space routine_19(Context& c,const Env& e) { return n383(c,e); }
static ZIPPY_NOINLINE Space n414(Context& c, const Env& e) { return e.spaces.at(79); }
static ZIPPY_NOINLINE Space n413(Context& c, const Env& e) { static const Space allowed=literal_text("1 0 ");return first_matching(n414(c,e),allowed,false); }
static ZIPPY_NOINLINE Path n416(Context& c, const Env& e) { return e.paths.at(72); }
static ZIPPY_NOINLINE Space n417(Context& c, const Env& e) { return e.spaces.at(72); }
static ZIPPY_NOINLINE Space n415(Context& c, const Env& e) { std::vector<Path> pv{n416(c,e)}; std::vector<Space> sv{n417(c,e)}; Env n; n.paths[73]=pv[0];n.spaces[72]=sv[0];  return routine_9(c,n); }
static ZIPPY_NOINLINE Space n412(Context& c, const Env& e) { auto a=n413(c,e); if(a.empty()) return a; return compose(a,n415(c,e)); }
static ZIPPY_NOINLINE Space n419(Context& c, const Env& e) { return e.spaces.at(79); }
static ZIPPY_NOINLINE Path n422(Context& c, const Env& e) { return e.paths.at(72); }
static ZIPPY_NOINLINE Path n423(Context& c, const Env& e) { return e.paths.at(74); }
static ZIPPY_NOINLINE Path n421(Context& c, const Env& e) { auto a=n422(c,e); auto b=n423(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n424(Context& c, const Env& e) { return e.spaces.at(80); }
static ZIPPY_NOINLINE Space n425(Context& c, const Env& e) { return e.spaces.at(72); }
static ZIPPY_NOINLINE Space n420(Context& c, const Env& e) { std::vector<Path> pv{n421(c,e)}; std::vector<Space> sv{n424(c,e),n425(c,e)}; Env n; n.paths[72]=pv[0];n.spaces[79]=sv[0];n.spaces[72]=sv[1];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n418(Context& c, const Env& e) { return iterate(c,e,n419(c,e),74,80,n420); }
static ZIPPY_NOINLINE Space n411(Context& c, const Env& e) { auto a=n412(c,e); auto b=n418(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n411(c,e); }
static ZIPPY_NOINLINE Path n427(Context& c, const Env& e) { return e.paths.at(73); }
static ZIPPY_NOINLINE Path n430(Context& c, const Env& e) { return e.paths.at(73); }
static ZIPPY_NOINLINE Space n431(Context& c, const Env& e) { return e.spaces.at(72); }
static ZIPPY_NOINLINE Space n429(Context& c, const Env& e) { auto p=n430(c,e); return unwrap(n431(c,e),p); }
static ZIPPY_NOINLINE Space n428(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n429(c,e)}; Env n; n.spaces[72]=sv[0];  return routine_4(c,n); }
static ZIPPY_NOINLINE Space n426(Context& c, const Env& e) { auto p=n427(c,e); return wrap(n428(c,e),p); }
static ZIPPY_NOINLINE Space routine_9(Context& c,const Env& e) { return n426(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=false; configure_symbols(c,"0 "); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
