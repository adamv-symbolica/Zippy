#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Path n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Path n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Space n13(Context&, const Env&);
static ZIPPY_NOINLINE Space n14(Context&, const Env&);
static ZIPPY_NOINLINE Space n15(Context&, const Env&);
static ZIPPY_NOINLINE Space n16(Context&, const Env&);
static ZIPPY_NOINLINE Space n17(Context&, const Env&);
static ZIPPY_NOINLINE Path n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n19(Context&, const Env&);
static ZIPPY_NOINLINE Path n20(Context&, const Env&);
static ZIPPY_NOINLINE Space n21(Context&, const Env&);
static ZIPPY_NOINLINE Path n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n23(Context&, const Env&);
static ZIPPY_NOINLINE Space n24(Context&, const Env&);
static ZIPPY_NOINLINE Path n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Space n29(Context&, const Env&);
static ZIPPY_NOINLINE Path n30(Context&, const Env&);
static ZIPPY_NOINLINE Path n31(Context&, const Env&);
static ZIPPY_NOINLINE Path n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Path n34(Context&, const Env&);
static ZIPPY_NOINLINE Space n35(Context&, const Env&);
static ZIPPY_NOINLINE Space n36(Context&, const Env&);
static ZIPPY_NOINLINE Path n37(Context&, const Env&);
static ZIPPY_NOINLINE Space n38(Context&, const Env&);
static ZIPPY_NOINLINE Path n39(Context&, const Env&);
static ZIPPY_NOINLINE Path n40(Context&, const Env&);
static ZIPPY_NOINLINE Path n41(Context&, const Env&);
static ZIPPY_NOINLINE Space n42(Context&, const Env&);
static ZIPPY_NOINLINE Space n43(Context&, const Env&);
static ZIPPY_NOINLINE Space n44(Context&, const Env&);
static ZIPPY_NOINLINE Path n45(Context&, const Env&);
static ZIPPY_NOINLINE Space n46(Context&, const Env&);
static ZIPPY_NOINLINE Space n47(Context&, const Env&);
static ZIPPY_NOINLINE Space n48(Context&, const Env&);
static ZIPPY_NOINLINE Space n49(Context&, const Env&);
static ZIPPY_NOINLINE Path n50(Context&, const Env&);
static ZIPPY_NOINLINE Path n51(Context&, const Env&);
static ZIPPY_NOINLINE Path n52(Context&, const Env&);
static ZIPPY_NOINLINE Space n53(Context&, const Env&);
static ZIPPY_NOINLINE Space n54(Context&, const Env&);
static ZIPPY_NOINLINE Space n55(Context&, const Env&);
static ZIPPY_NOINLINE Space n56(Context&, const Env&);
static ZIPPY_NOINLINE Space n57(Context&, const Env&);
static ZIPPY_NOINLINE Space n58(Context&, const Env&);
static ZIPPY_NOINLINE Space n59(Context&, const Env&);
static ZIPPY_NOINLINE Space n60(Context&, const Env&);
static ZIPPY_NOINLINE Space n61(Context&, const Env&);
static ZIPPY_NOINLINE Path n62(Context&, const Env&);
static ZIPPY_NOINLINE Path n63(Context&, const Env&);
static ZIPPY_NOINLINE Path n64(Context&, const Env&);
static ZIPPY_NOINLINE Space n65(Context&, const Env&);
static ZIPPY_NOINLINE Path n66(Context&, const Env&);
static ZIPPY_NOINLINE Space n67(Context&, const Env&);
static ZIPPY_NOINLINE Space n68(Context&, const Env&);
static ZIPPY_NOINLINE Path n69(Context&, const Env&);
static ZIPPY_NOINLINE Space n70(Context&, const Env&);
static ZIPPY_NOINLINE Space n71(Context&, const Env&);
static ZIPPY_NOINLINE Space n72(Context&, const Env&);
static ZIPPY_NOINLINE Space n73(Context&, const Env&);
static ZIPPY_NOINLINE Path n74(Context&, const Env&);
static ZIPPY_NOINLINE Path n75(Context&, const Env&);
static ZIPPY_NOINLINE Path n76(Context&, const Env&);
static ZIPPY_NOINLINE Space n77(Context&, const Env&);
static ZIPPY_NOINLINE Path n78(Context&, const Env&);
static ZIPPY_NOINLINE Space n79(Context&, const Env&);
static ZIPPY_NOINLINE Space n80(Context&, const Env&);
static ZIPPY_NOINLINE Path n81(Context&, const Env&);
static ZIPPY_NOINLINE Space n82(Context&, const Env&);
static ZIPPY_NOINLINE Path n83(Context&, const Env&);
static ZIPPY_NOINLINE Path n84(Context&, const Env&);
static ZIPPY_NOINLINE Path n85(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n86(Context&, const Env&);
static ZIPPY_NOINLINE Space n87(Context&, const Env&);
static ZIPPY_NOINLINE Path n88(Context&, const Env&);
static ZIPPY_NOINLINE Space n89(Context&, const Env&);
static ZIPPY_NOINLINE Space n90(Context&, const Env&);
static ZIPPY_NOINLINE Space n91(Context&, const Env&);
static ZIPPY_NOINLINE Space n92(Context&, const Env&);
static ZIPPY_NOINLINE Space n93(Context&, const Env&);
static ZIPPY_NOINLINE Space n94(Context&, const Env&);
static ZIPPY_NOINLINE Space n95(Context&, const Env&);
static ZIPPY_NOINLINE Path n96(Context&, const Env&);
static ZIPPY_NOINLINE Space n97(Context&, const Env&);
static ZIPPY_NOINLINE Space n98(Context&, const Env&);
static ZIPPY_NOINLINE Path n99(Context&, const Env&);
static ZIPPY_NOINLINE Space n100(Context&, const Env&);
static ZIPPY_NOINLINE Space n101(Context&, const Env&);
static ZIPPY_NOINLINE Path n102(Context&, const Env&);
static ZIPPY_NOINLINE Space n103(Context&, const Env&);
static ZIPPY_NOINLINE Space n104(Context&, const Env&);
static ZIPPY_NOINLINE Space n105(Context&, const Env&);
static ZIPPY_NOINLINE Space n106(Context&, const Env&);
static ZIPPY_NOINLINE Path n107(Context&, const Env&);
static ZIPPY_NOINLINE Space n108(Context&, const Env&);
static ZIPPY_NOINLINE Space n109(Context&, const Env&);
static ZIPPY_NOINLINE Path n110(Context&, const Env&);
static ZIPPY_NOINLINE Space n111(Context&, const Env&);
static ZIPPY_NOINLINE Space n112(Context&, const Env&);
static ZIPPY_NOINLINE Path n113(Context&, const Env&);
static ZIPPY_NOINLINE Space n114(Context&, const Env&);
static ZIPPY_NOINLINE Space n115(Context&, const Env&);
static ZIPPY_NOINLINE Path n116(Context&, const Env&);
static ZIPPY_NOINLINE Path n117(Context&, const Env&);
static ZIPPY_NOINLINE Path n118(Context&, const Env&);
static ZIPPY_NOINLINE Space n1(Context& c, const Env& e) { static const Space value=literal_text("120 3 1 2 3 3 1 2 7 3 1 2 10 3 1 2 11 3 1 2 13 3 1 2 16 3 1 2 18 3 1 2 23 3 1 3 3 3 1 3 5 3 1 3 7 3 1 3 8 3 1 3 10 3 1 3 12 3 1 4 5 3 1 4 9 3 1 4 11 3 1 4 13 3 1 4 14 3 1 4 16 3 1 4 20 3 1 4 23 3 1 5 2 3 1 5 6 3 1 5 10 3 1 5 16 3 1 5 18 3 1 5 20 3 1 5 22 3 1 6 3 3 1 6 4 3 1 6 13 3 1 6 15 3 1 6 16 3 1 6 22 3 1 7 8 3 1 7 10 3 1 7 25 3 1 8 3 3 1 8 4 3 1 8 6 3 1 8 17 3 1 8 21 3 1 9 5 3 1 9 7 3 1 9 8 3 1 9 10 3 1 9 13 3 1 9 16 3 1 9 19 3 1 10 2 3 1 10 4 3 1 10 9 3 1 10 12 3 1 10 13 3 1 11 7 3 1 11 9 3 1 11 12 3 1 11 13 3 1 11 15 3 1 12 15 3 1 12 19 3 1 12 25 3 1 13 9 3 1 13 14 3 1 13 16 3 1 13 17 3 1 13 19 3 1 14 12 3 1 14 16 3 1 14 18 3 1 15 2 3 1 15 4 3 1 15 5 3 1 15 6 3 1 15 25 3 1 16 11 3 1 16 15 3 1 16 17 3 1 17 2 3 1 17 13 3 1 17 14 3 1 17 19 3 1 17 23 3 1 17 24 3 1 17 25 3 1 18 21 3 1 19 3 3 1 19 4 3 1 19 14 3 1 19 17 3 1 19 20 3 1 20 4 3 1 20 7 3 1 20 9 3 1 20 12 3 1 20 13 3 1 21 19 3 1 21 22 3 1 22 11 3 1 22 13 3 1 22 14 3 1 22 20 3 1 22 22 3 1 23 3 3 1 23 4 3 1 23 5 3 1 23 9 3 1 23 11 3 1 23 12 3 1 23 14 3 1 23 17 3 1 23 18 3 1 24 12 3 1 24 18 3 1 24 24 3 1 25 4 3 1 25 8 3 1 25 10 3 1 25 15"); return value; }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n1(c,e)}; Env n; n.spaces[0]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Path n3(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Path n7(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { auto p=n7(c,e); return unwrap(n8(c,e),p); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Path n19(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n20(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n18(Context& c, const Env& e) { auto a=n19(c,e); auto b=n20(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n17(Context& c, const Env& e) { std::vector<Path> pv{n18(c,e)}; std::vector<Space> sv{}; Env n; n.paths[2]=pv[0];  return routine_0(c,n); }
static ZIPPY_NOINLINE Path n22(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n23(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n21(Context& c, const Env& e) { auto p=n22(c,e); return unwrap(n23(c,e),p); }
static ZIPPY_NOINLINE Space n16(Context& c, const Env& e) { auto a=n17(c,e); auto b=n21(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n15(Context& c, const Env& e) { return range(c,n16(c,e),2,3); }
static ZIPPY_NOINLINE Path n25(Context& c, const Env& e) { return Path{26}; }
static ZIPPY_NOINLINE Space n24(Context& c, const Env& e) { return singleton(n25(c,e)); }
static ZIPPY_NOINLINE Space n14(Context& c, const Env& e) { return iterate(c,e,n15(c,e),-1,-1,n24); }
static ZIPPY_NOINLINE Path n31(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n32(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n30(Context& c, const Env& e) { auto a=n31(c,e); auto b=n32(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n29(Context& c, const Env& e) { std::vector<Path> pv{n30(c,e)}; std::vector<Space> sv{}; Env n; n.paths[2]=pv[0];  return routine_0(c,n); }
static ZIPPY_NOINLINE Path n34(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n35(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { auto p=n34(c,e); return unwrap(n35(c,e),p); }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { auto a=n29(c,e); auto b=n33(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { return range(c,n28(c,e),3,4); }
static ZIPPY_NOINLINE Path n37(Context& c, const Env& e) { return Path{26}; }
static ZIPPY_NOINLINE Space n36(Context& c, const Env& e) { return singleton(n37(c,e)); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { return iterate(c,e,n27(c,e),-1,-1,n36); }
static ZIPPY_NOINLINE Space n13(Context& c, const Env& e) { auto a=n14(c,e); auto b=n26(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n40(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n41(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n39(Context& c, const Env& e) { auto a=n40(c,e); auto b=n41(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n38(Context& c, const Env& e) { return singleton(n39(c,e)); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { auto a=n13(c,e); if(a.empty()) return a; return compose(a,n38(c,e)); }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { return tails_union(n12(c,e)); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { return iterate(c,e,n10(c,e),1,-1,n11); }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { return iterate(c,e,n6(c,e),0,1,n9); }
static ZIPPY_NOINLINE Path n45(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n46(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n44(Context& c, const Env& e) { auto p=n45(c,e); return unwrap(n46(c,e),p); }
static ZIPPY_NOINLINE Space n48(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Path n51(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n52(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n50(Context& c, const Env& e) { auto a=n51(c,e); auto b=n52(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n49(Context& c, const Env& e) { std::vector<Path> pv{n50(c,e)}; std::vector<Space> sv{}; Env n; n.paths[2]=pv[0];  return routine_0(c,n); }
static ZIPPY_NOINLINE Space n47(Context& c, const Env& e) { return iterate(c,e,n48(c,e),1,-1,n49); }
static ZIPPY_NOINLINE Space n43(Context& c, const Env& e) { return iterate(c,e,n44(c,e),0,1,n47); }
static ZIPPY_NOINLINE Space n54(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Path n63(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n64(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n62(Context& c, const Env& e) { auto a=n63(c,e); auto b=n64(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n61(Context& c, const Env& e) { std::vector<Path> pv{n62(c,e)}; std::vector<Space> sv{}; Env n; n.paths[2]=pv[0];  return routine_0(c,n); }
static ZIPPY_NOINLINE Path n66(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n67(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n65(Context& c, const Env& e) { auto p=n66(c,e); return unwrap(n67(c,e),p); }
static ZIPPY_NOINLINE Space n60(Context& c, const Env& e) { auto a=n61(c,e); auto b=n65(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n59(Context& c, const Env& e) { return range(c,n60(c,e),3,4); }
static ZIPPY_NOINLINE Path n69(Context& c, const Env& e) { return Path{26}; }
static ZIPPY_NOINLINE Space n68(Context& c, const Env& e) { return singleton(n69(c,e)); }
static ZIPPY_NOINLINE Space n58(Context& c, const Env& e) { return iterate(c,e,n59(c,e),-1,-1,n68); }
static ZIPPY_NOINLINE Path n75(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n76(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n74(Context& c, const Env& e) { auto a=n75(c,e); auto b=n76(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n73(Context& c, const Env& e) { std::vector<Path> pv{n74(c,e)}; std::vector<Space> sv{}; Env n; n.paths[2]=pv[0];  return routine_0(c,n); }
static ZIPPY_NOINLINE Path n78(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n79(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n77(Context& c, const Env& e) { auto p=n78(c,e); return unwrap(n79(c,e),p); }
static ZIPPY_NOINLINE Space n72(Context& c, const Env& e) { auto a=n73(c,e); auto b=n77(c,e); return intersect(a,b); }
static ZIPPY_NOINLINE Space n71(Context& c, const Env& e) { return range(c,n72(c,e),4,5); }
static ZIPPY_NOINLINE Path n81(Context& c, const Env& e) { return Path{26}; }
static ZIPPY_NOINLINE Space n80(Context& c, const Env& e) { return singleton(n81(c,e)); }
static ZIPPY_NOINLINE Space n70(Context& c, const Env& e) { return iterate(c,e,n71(c,e),-1,-1,n80); }
static ZIPPY_NOINLINE Space n57(Context& c, const Env& e) { auto a=n58(c,e); auto b=n70(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n84(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n85(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n83(Context& c, const Env& e) { auto a=n84(c,e); auto b=n85(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n82(Context& c, const Env& e) { return singleton(n83(c,e)); }
static ZIPPY_NOINLINE Space n56(Context& c, const Env& e) { auto a=n57(c,e); if(a.empty()) return a; return compose(a,n82(c,e)); }
static ZIPPY_NOINLINE Space n55(Context& c, const Env& e) { return tails_union(n56(c,e)); }
static ZIPPY_NOINLINE Space n53(Context& c, const Env& e) { return iterate(c,e,n54(c,e),1,-1,n55); }
static ZIPPY_NOINLINE Space n42(Context& c, const Env& e) { return iterate(c,e,n43(c,e),0,1,n53); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { auto a=n5(c,e); auto b=n42(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { auto p=n3(c,e); return wrap(n4(c,e),p); }
static ZIPPY_NOINLINE Space routine_1(Context& c,const Env& e) { return n2(c,e); }
static ZIPPY_NOINLINE Path n88(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Space n87(Context& c, const Env& e) { return singleton(n88(c,e)); }
static ZIPPY_NOINLINE Space n90(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Path n96(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Space n97(Context& c, const Env& e) { static const Space value=literal_text("129 2 2 8 2 3 13 2 4 6 2 5 11 2 6 9 2 7 21 2 8 25 2 9 3 2 10 16 2 11 12 2 12 7 2 13 5 2 14 22 2 15 10 2 16 17 2 17 23 2 18 2 2 19 4 2 20 24 2 21 110 2 22 19 2 23 18 2 24 15 2 25 14 2 27 28 2 28 45 2 29 30 2 30 68 2 31 32 2 32 97 2 33 34 2 34 121 2 35 36 2 36 109 2 37 38 2 38 29 2 39 40 2 40 52 2 41 42 2 42 117 2 43 44 2 44 54 2 45 86 2 46 47 2 47 20 2 48 49 2 49 73 2 50 51 2 51 80 2 52 92 2 53 33 2 54 55 2 55 81 2 56 57 2 57 119 2 58 59 2 59 69 2 60 61 2 61 39 2 62 63 2 63 91 2 64 65 2 65 123 2 66 67 2 67 85 2 68 78 2 69 70 2 70 79 2 71 72 2 72 37 2 73 53 2 74 75 2 75 50 2 76 77 2 77 132 2 78 103 2 79 48 2 80 93 2 81 82 2 82 105 2 83 84 2 84 102 2 85 62 2 86 46 2 87 88 2 88 35 2 89 90 2 90 131 2 91 83 2 92 122 2 93 87 2 94 71 2 95 96 2 96 125 2 97 94 2 98 99 2 99 100 2 100 101 2 101 111 2 102 64 2 103 104 2 104 108 2 105 130 2 106 27 2 107 95 2 108 58 2 109 41 2 110 98 2 111 113 2 112 56 2 113 118 2 114 43 2 115 116 2 116 106 2 117 60 2 118 31 2 119 120 2 120 127 2 121 124 2 122 76 2 123 114 2 124 107 2 125 126 2 126 74 2 127 128 2 128 89 2 129 115 2 130 129 2 131 66"); return value; }
static ZIPPY_NOINLINE Space n95(Context& c, const Env& e) { auto p=n96(c,e); return unwrap(n97(c,e),p); }
static ZIPPY_NOINLINE Path n99(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Space n100(Context& c, const Env& e) { static const Space value=literal_text("129 2 2 2 2 3 3 2 4 4 2 5 5 2 6 6 2 7 7 2 8 8 2 9 9 2 10 10 2 11 11 2 12 12 2 13 13 2 14 14 2 15 15 2 16 16 2 17 17 2 18 18 2 19 19 2 20 20 2 21 21 2 22 22 2 23 23 2 24 24 2 25 25 2 27 27 2 28 28 2 29 29 2 30 30 2 31 31 2 32 32 2 33 33 2 34 34 2 35 35 2 36 36 2 37 37 2 38 38 2 39 39 2 40 40 2 41 41 2 42 42 2 43 43 2 44 44 2 45 45 2 46 46 2 47 47 2 48 48 2 49 49 2 50 50 2 51 51 2 52 52 2 53 53 2 54 54 2 55 55 2 56 56 2 57 57 2 58 58 2 59 59 2 60 60 2 61 61 2 62 62 2 63 63 2 64 64 2 65 65 2 66 66 2 67 67 2 68 68 2 69 69 2 70 70 2 71 71 2 72 72 2 73 73 2 74 74 2 75 75 2 76 76 2 77 77 2 78 78 2 79 79 2 80 80 2 81 81 2 82 82 2 83 83 2 84 84 2 85 85 2 86 86 2 87 87 2 88 88 2 89 89 2 90 90 2 91 91 2 92 92 2 93 93 2 94 94 2 95 95 2 96 96 2 97 97 2 98 98 2 99 99 2 100 100 2 101 101 2 102 102 2 103 103 2 104 104 2 105 105 2 106 106 2 107 107 2 108 108 2 109 109 2 110 110 2 111 111 2 112 112 2 113 113 2 114 114 2 115 115 2 116 116 2 117 117 2 118 118 2 119 119 2 120 120 2 121 121 2 122 122 2 123 123 2 124 124 2 125 125 2 126 126 2 127 127 2 128 128 2 129 129 2 130 130 2 131 131"); return value; }
static ZIPPY_NOINLINE Space n98(Context& c, const Env& e) { auto p=n99(c,e); return unwrap(n100(c,e),p); }
static ZIPPY_NOINLINE Space n94(Context& c, const Env& e) { auto a=n95(c,e); auto b=n98(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n102(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Space n103(Context& c, const Env& e) { static const Space value=literal_text("129 2 2 18 2 3 9 2 4 19 2 5 13 2 6 4 2 7 12 2 8 2 2 9 6 2 10 15 2 11 5 2 12 11 2 13 3 2 14 25 2 15 24 2 16 10 2 17 16 2 18 23 2 19 22 2 20 47 2 21 7 2 22 14 2 23 17 2 24 20 2 25 8 2 27 106 2 28 27 2 29 38 2 30 29 2 31 118 2 32 31 2 33 53 2 34 33 2 35 88 2 36 35 2 37 72 2 38 37 2 39 61 2 40 39 2 41 109 2 42 41 2 43 114 2 44 43 2 45 28 2 46 86 2 47 46 2 48 79 2 49 48 2 50 75 2 51 50 2 52 40 2 53 73 2 54 44 2 55 54 2 56 112 2 57 56 2 58 108 2 59 58 2 60 117 2 61 60 2 62 85 2 63 62 2 64 102 2 65 64 2 66 131 2 67 66 2 68 30 2 69 59 2 70 69 2 71 94 2 72 71 2 73 49 2 74 126 2 75 74 2 76 122 2 77 76 2 78 68 2 79 70 2 80 51 2 81 55 2 82 81 2 83 91 2 84 83 2 85 67 2 86 45 2 87 93 2 88 87 2 89 128 2 90 89 2 91 63 2 92 52 2 93 80 2 94 97 2 95 107 2 96 95 2 97 32 2 98 110 2 99 98 2 100 99 2 101 100 2 102 84 2 103 78 2 104 103 2 105 82 2 106 116 2 107 124 2 108 104 2 109 36 2 110 21 2 111 101 2 112 133 2 113 111 2 114 123 2 115 129 2 116 115 2 117 42 2 118 113 2 119 57 2 120 119 2 121 34 2 122 92 2 123 65 2 124 121 2 125 96 2 126 125 2 127 120 2 128 127 2 129 130 2 130 105 2 131 90"); return value; }
static ZIPPY_NOINLINE Space n101(Context& c, const Env& e) { auto p=n102(c,e); return unwrap(n103(c,e),p); }
static ZIPPY_NOINLINE Space n93(Context& c, const Env& e) { auto a=n94(c,e); auto b=n101(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n107(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Space n108(Context& c, const Env& e) { static const Space value=literal_text("129 2 2 8 2 3 13 2 4 6 2 5 11 2 6 9 2 7 21 2 8 25 2 9 3 2 10 16 2 11 12 2 12 7 2 13 5 2 14 22 2 15 10 2 16 17 2 17 23 2 18 2 2 19 4 2 20 24 2 21 110 2 22 19 2 23 18 2 24 15 2 25 14 2 27 28 2 28 45 2 29 30 2 30 68 2 31 32 2 32 97 2 33 34 2 34 121 2 35 36 2 36 109 2 37 38 2 38 29 2 39 40 2 40 52 2 41 42 2 42 117 2 43 44 2 44 54 2 45 86 2 46 47 2 47 20 2 48 49 2 49 73 2 50 51 2 51 80 2 52 92 2 53 33 2 54 55 2 55 81 2 56 57 2 57 119 2 58 59 2 59 69 2 60 61 2 61 39 2 62 63 2 63 91 2 64 65 2 65 123 2 66 67 2 67 85 2 68 78 2 69 70 2 70 79 2 71 72 2 72 37 2 73 53 2 74 75 2 75 50 2 76 77 2 77 132 2 78 103 2 79 48 2 80 93 2 81 82 2 82 105 2 83 84 2 84 102 2 85 62 2 86 46 2 87 88 2 88 35 2 89 90 2 90 131 2 91 83 2 92 122 2 93 87 2 94 71 2 95 96 2 96 125 2 97 94 2 98 99 2 99 100 2 100 101 2 101 111 2 102 64 2 103 104 2 104 108 2 105 130 2 106 27 2 107 95 2 108 58 2 109 41 2 110 98 2 111 113 2 112 56 2 113 118 2 114 43 2 115 116 2 116 106 2 117 60 2 118 31 2 119 120 2 120 127 2 121 124 2 122 76 2 123 114 2 124 107 2 125 126 2 126 74 2 127 128 2 128 89 2 129 115 2 130 129 2 131 66"); return value; }
static ZIPPY_NOINLINE Space n106(Context& c, const Env& e) { auto p=n107(c,e); return unwrap(n108(c,e),p); }
static ZIPPY_NOINLINE Path n110(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Space n111(Context& c, const Env& e) { static const Space value=literal_text("129 2 2 2 2 3 3 2 4 4 2 5 5 2 6 6 2 7 7 2 8 8 2 9 9 2 10 10 2 11 11 2 12 12 2 13 13 2 14 14 2 15 15 2 16 16 2 17 17 2 18 18 2 19 19 2 20 20 2 21 21 2 22 22 2 23 23 2 24 24 2 25 25 2 27 27 2 28 28 2 29 29 2 30 30 2 31 31 2 32 32 2 33 33 2 34 34 2 35 35 2 36 36 2 37 37 2 38 38 2 39 39 2 40 40 2 41 41 2 42 42 2 43 43 2 44 44 2 45 45 2 46 46 2 47 47 2 48 48 2 49 49 2 50 50 2 51 51 2 52 52 2 53 53 2 54 54 2 55 55 2 56 56 2 57 57 2 58 58 2 59 59 2 60 60 2 61 61 2 62 62 2 63 63 2 64 64 2 65 65 2 66 66 2 67 67 2 68 68 2 69 69 2 70 70 2 71 71 2 72 72 2 73 73 2 74 74 2 75 75 2 76 76 2 77 77 2 78 78 2 79 79 2 80 80 2 81 81 2 82 82 2 83 83 2 84 84 2 85 85 2 86 86 2 87 87 2 88 88 2 89 89 2 90 90 2 91 91 2 92 92 2 93 93 2 94 94 2 95 95 2 96 96 2 97 97 2 98 98 2 99 99 2 100 100 2 101 101 2 102 102 2 103 103 2 104 104 2 105 105 2 106 106 2 107 107 2 108 108 2 109 109 2 110 110 2 111 111 2 112 112 2 113 113 2 114 114 2 115 115 2 116 116 2 117 117 2 118 118 2 119 119 2 120 120 2 121 121 2 122 122 2 123 123 2 124 124 2 125 125 2 126 126 2 127 127 2 128 128 2 129 129 2 130 130 2 131 131"); return value; }
static ZIPPY_NOINLINE Space n109(Context& c, const Env& e) { auto p=n110(c,e); return unwrap(n111(c,e),p); }
static ZIPPY_NOINLINE Space n105(Context& c, const Env& e) { auto a=n106(c,e); auto b=n109(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n113(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Space n114(Context& c, const Env& e) { static const Space value=literal_text("129 2 2 18 2 3 9 2 4 19 2 5 13 2 6 4 2 7 12 2 8 2 2 9 6 2 10 15 2 11 5 2 12 11 2 13 3 2 14 25 2 15 24 2 16 10 2 17 16 2 18 23 2 19 22 2 20 47 2 21 7 2 22 14 2 23 17 2 24 20 2 25 8 2 27 106 2 28 27 2 29 38 2 30 29 2 31 118 2 32 31 2 33 53 2 34 33 2 35 88 2 36 35 2 37 72 2 38 37 2 39 61 2 40 39 2 41 109 2 42 41 2 43 114 2 44 43 2 45 28 2 46 86 2 47 46 2 48 79 2 49 48 2 50 75 2 51 50 2 52 40 2 53 73 2 54 44 2 55 54 2 56 112 2 57 56 2 58 108 2 59 58 2 60 117 2 61 60 2 62 85 2 63 62 2 64 102 2 65 64 2 66 131 2 67 66 2 68 30 2 69 59 2 70 69 2 71 94 2 72 71 2 73 49 2 74 126 2 75 74 2 76 122 2 77 76 2 78 68 2 79 70 2 80 51 2 81 55 2 82 81 2 83 91 2 84 83 2 85 67 2 86 45 2 87 93 2 88 87 2 89 128 2 90 89 2 91 63 2 92 52 2 93 80 2 94 97 2 95 107 2 96 95 2 97 32 2 98 110 2 99 98 2 100 99 2 101 100 2 102 84 2 103 78 2 104 103 2 105 82 2 106 116 2 107 124 2 108 104 2 109 36 2 110 21 2 111 101 2 112 133 2 113 111 2 114 123 2 115 129 2 116 115 2 117 42 2 118 113 2 119 57 2 120 119 2 121 34 2 122 92 2 123 65 2 124 121 2 125 96 2 126 125 2 127 120 2 128 127 2 129 130 2 130 105 2 131 90"); return value; }
static ZIPPY_NOINLINE Space n112(Context& c, const Env& e) { auto p=n113(c,e); return unwrap(n114(c,e),p); }
static ZIPPY_NOINLINE Space n104(Context& c, const Env& e) { auto a=n105(c,e); auto b=n112(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n92(Context& c, const Env& e) { auto a=n93(c,e); if(a.empty()) return a; return compose(a,n104(c,e)); }
static ZIPPY_NOINLINE Path n117(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Path n118(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Path n116(Context& c, const Env& e) { auto a=n117(c,e); auto b=n118(c,e); return concat_path(a,b); }
static ZIPPY_NOINLINE Space n115(Context& c, const Env& e) { return singleton(n116(c,e)); }
static ZIPPY_NOINLINE Space n91(Context& c, const Env& e) { auto a=n92(c,e); auto b=n115(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n89(Context& c, const Env& e) { return iterate(c,e,n90(c,e),1,-1,n91); }
static ZIPPY_NOINLINE Space n86(Context& c, const Env& e) { return iterate(c,e,n87(c,e),0,1,n89); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n86(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"133 1 4 67 101 108 108 2 2 49 53 3 1 54 4 1 57 5 1 52 6 1 56 7 1 49 8 2 49 52 9 1 55 10 2 50 48 11 1 51 12 1 50 13 1 53 14 2 49 50 15 2 50 49 16 2 49 57 17 2 49 56 18 2 49 54 19 2 49 48 20 2 50 51 21 1 48 22 2 49 49 23 2 49 55 24 2 50 50 25 2 49 51 26 3 104 105 116 27 2 50 57 28 2 50 56 29 3 45 49 55 30 3 45 49 56 31 2 45 57 32 3 45 49 48 33 3 45 51 51 34 3 45 51 52 35 3 45 53 48 36 3 45 53 49 37 3 45 49 53 38 3 45 49 54 39 3 45 53 56 40 3 45 53 57 41 3 45 53 51 42 3 45 53 52 43 2 52 49 44 2 52 48 45 2 50 55 46 2 50 53 47 2 50 52 48 3 45 50 57 49 3 45 51 48 50 3 45 52 52 51 3 45 52 53 52 3 45 54 48 53 3 45 51 50 54 2 51 57 55 2 51 56 56 2 54 51 57 2 54 50 58 3 45 50 52 59 3 45 50 53 60 3 45 53 54 61 3 45 53 55 62 2 53 49 63 2 53 48 64 2 52 53 65 2 52 52 66 2 53 52 67 2 53 51 68 3 45 49 57 69 3 45 50 54 70 3 45 50 55 71 3 45 49 51 72 3 45 49 52 73 3 45 51 49 74 3 45 52 50 75 3 45 52 51 76 3 45 54 51 77 3 45 54 52 78 3 45 50 48 79 3 45 50 56 80 3 45 52 54 81 2 51 55 82 2 51 54 83 2 52 56 84 2 52 55 85 2 53 50 86 2 50 54 87 3 45 52 56 88 3 45 52 57 89 2 53 55 90 2 53 54 91 2 52 57 92 3 45 54 49 93 3 45 52 55 94 3 45 49 50 95 3 45 51 56 96 3 45 51 57 97 3 45 49 49 98 2 45 50 99 2 45 51 100 2 45 52 101 2 45 53 102 2 52 54 103 3 45 50 49 104 3 45 50 50 105 2 51 53 106 2 51 48 107 3 45 51 55 108 3 45 50 51 109 3 45 53 50 110 2 45 49 111 2 45 54 112 2 54 52 113 2 45 55 114 2 52 50 115 2 51 50 116 2 51 49 117 3 45 53 53 118 2 45 56 119 2 54 49 120 2 54 48 121 3 45 51 53 122 3 45 54 50 123 2 52 51 124 3 45 51 54 125 3 45 52 48 126 3 45 52 49 127 2 53 57 128 2 53 56 129 2 51 51 130 2 51 52 131 2 53 53 132 3 45 54 53 133 2 54 53"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
