#include "zippy_openfst.hpp"
#include <iostream>
#include <stdexcept>
#if defined(__GNUC__) && !defined(__clang__) && __GNUC__ >= 9
#define ZIPPY_NOINLINE __attribute__((noipa))
#elif defined(__GNUC__)
#define ZIPPY_NOINLINE __attribute__((noinline))
#else
#define ZIPPY_NOINLINE
#endif
using namespace zippy;
namespace program_0 {
static ZIPPY_NOINLINE Space n0(Context&, const Env&);
static ZIPPY_NOINLINE Path n1(Context&, const Env&);
static ZIPPY_NOINLINE Space n2(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_0(Context&, const Env&);
static ZIPPY_NOINLINE Space n3(Context&, const Env&);
static ZIPPY_NOINLINE Space n4(Context&, const Env&);
static ZIPPY_NOINLINE Space n5(Context&, const Env&);
static ZIPPY_NOINLINE Space n6(Context&, const Env&);
static ZIPPY_NOINLINE Space routine_1(Context&, const Env&);
static ZIPPY_NOINLINE Space n7(Context&, const Env&);
static ZIPPY_NOINLINE Space n8(Context&, const Env&);
static ZIPPY_NOINLINE Space n9(Context&, const Env&);
static ZIPPY_NOINLINE Space n10(Context&, const Env&);
static ZIPPY_NOINLINE Space n11(Context&, const Env&);
static ZIPPY_NOINLINE Space n12(Context&, const Env&);
static ZIPPY_NOINLINE Path n13(Context&, const Env&);
static ZIPPY_NOINLINE Space n14(Context&, const Env&);
static ZIPPY_NOINLINE Space n15(Context&, const Env&);
static ZIPPY_NOINLINE Path n16(Context&, const Env&);
static ZIPPY_NOINLINE Space n17(Context&, const Env&);
static ZIPPY_NOINLINE Space n18(Context&, const Env&);
static ZIPPY_NOINLINE Path n19(Context&, const Env&);
static ZIPPY_NOINLINE Space n20(Context&, const Env&);
static ZIPPY_NOINLINE Space n21(Context&, const Env&);
static ZIPPY_NOINLINE Path n22(Context&, const Env&);
static ZIPPY_NOINLINE Space n23(Context&, const Env&);
static ZIPPY_NOINLINE Space n24(Context&, const Env&);
static ZIPPY_NOINLINE Space n25(Context&, const Env&);
static ZIPPY_NOINLINE Space n26(Context&, const Env&);
static ZIPPY_NOINLINE Space n27(Context&, const Env&);
static ZIPPY_NOINLINE Space n28(Context&, const Env&);
static ZIPPY_NOINLINE Space n29(Context&, const Env&);
static ZIPPY_NOINLINE Path n30(Context&, const Env&);
static ZIPPY_NOINLINE Space n31(Context&, const Env&);
static ZIPPY_NOINLINE Path n32(Context&, const Env&);
static ZIPPY_NOINLINE Space n33(Context&, const Env&);
static ZIPPY_NOINLINE Space n34(Context&, const Env&);
static ZIPPY_NOINLINE Path n35(Context&, const Env&);
static ZIPPY_NOINLINE Space n36(Context&, const Env&);
static ZIPPY_NOINLINE Space n37(Context&, const Env&);
static ZIPPY_NOINLINE Space n38(Context&, const Env&);
static ZIPPY_NOINLINE Space n39(Context&, const Env&);
static ZIPPY_NOINLINE Space n40(Context&, const Env&);
static ZIPPY_NOINLINE Path n41(Context&, const Env&);
static ZIPPY_NOINLINE Space n42(Context&, const Env&);
static ZIPPY_NOINLINE Path n43(Context&, const Env&);
static ZIPPY_NOINLINE Space n44(Context&, const Env&);
static ZIPPY_NOINLINE Space n45(Context&, const Env&);
static ZIPPY_NOINLINE Path n46(Context&, const Env&);
static ZIPPY_NOINLINE Space n47(Context&, const Env&);
static ZIPPY_NOINLINE Space n48(Context&, const Env&);
static ZIPPY_NOINLINE Space n49(Context&, const Env&);
static ZIPPY_NOINLINE Space n50(Context&, const Env&);
static ZIPPY_NOINLINE Path n51(Context&, const Env&);
static ZIPPY_NOINLINE Space n52(Context&, const Env&);
static ZIPPY_NOINLINE Path n53(Context&, const Env&);
static ZIPPY_NOINLINE Space n54(Context&, const Env&);
static ZIPPY_NOINLINE Path n55(Context&, const Env&);
static ZIPPY_NOINLINE Space n56(Context&, const Env&);
static ZIPPY_NOINLINE Space n57(Context&, const Env&);
static ZIPPY_NOINLINE Space n58(Context&, const Env&);
static ZIPPY_NOINLINE Space n59(Context&, const Env&);
static ZIPPY_NOINLINE Path n60(Context&, const Env&);
static ZIPPY_NOINLINE Space n61(Context&, const Env&);
static ZIPPY_NOINLINE Path n62(Context&, const Env&);
static ZIPPY_NOINLINE Space n63(Context&, const Env&);
static ZIPPY_NOINLINE Space n64(Context&, const Env&);
static ZIPPY_NOINLINE Path n65(Context&, const Env&);
static ZIPPY_NOINLINE Space n66(Context&, const Env&);
static ZIPPY_NOINLINE Space n67(Context&, const Env&);
static ZIPPY_NOINLINE Space n68(Context&, const Env&);
static ZIPPY_NOINLINE Space n69(Context&, const Env&);
static ZIPPY_NOINLINE Path n70(Context&, const Env&);
static ZIPPY_NOINLINE Space n71(Context&, const Env&);
static ZIPPY_NOINLINE Path n72(Context&, const Env&);
static ZIPPY_NOINLINE Space n73(Context&, const Env&);
static ZIPPY_NOINLINE Path n74(Context&, const Env&);
static ZIPPY_NOINLINE Space n75(Context&, const Env&);
static ZIPPY_NOINLINE Space n76(Context&, const Env&);
static ZIPPY_NOINLINE Space n77(Context&, const Env&);
static ZIPPY_NOINLINE Space n78(Context&, const Env&);
static ZIPPY_NOINLINE Path n79(Context&, const Env&);
static ZIPPY_NOINLINE Space n80(Context&, const Env&);
static ZIPPY_NOINLINE Path n81(Context&, const Env&);
static ZIPPY_NOINLINE Space n82(Context&, const Env&);
static ZIPPY_NOINLINE Space n83(Context&, const Env&);
static ZIPPY_NOINLINE Path n84(Context&, const Env&);
static ZIPPY_NOINLINE Space n85(Context&, const Env&);
static ZIPPY_NOINLINE Space n86(Context&, const Env&);
static ZIPPY_NOINLINE Space n87(Context&, const Env&);
static ZIPPY_NOINLINE Space n88(Context&, const Env&);
static ZIPPY_NOINLINE Path n89(Context&, const Env&);
static ZIPPY_NOINLINE Space n90(Context&, const Env&);
static ZIPPY_NOINLINE Path n91(Context&, const Env&);
static ZIPPY_NOINLINE Space n92(Context&, const Env&);
static ZIPPY_NOINLINE Path n93(Context&, const Env&);
static ZIPPY_NOINLINE Space n94(Context&, const Env&);
static ZIPPY_NOINLINE Space n95(Context&, const Env&);
static ZIPPY_NOINLINE Space n96(Context&, const Env&);
static ZIPPY_NOINLINE Path n97(Context&, const Env&);
static ZIPPY_NOINLINE Space n98(Context&, const Env&);
static ZIPPY_NOINLINE Space n99(Context&, const Env&);
static ZIPPY_NOINLINE Path n100(Context&, const Env&);
static ZIPPY_NOINLINE Space n101(Context&, const Env&);
static ZIPPY_NOINLINE Space n102(Context&, const Env&);
static ZIPPY_NOINLINE Path n1(Context& c, const Env& e) { return Path{1,2}; }
static ZIPPY_NOINLINE Space n2(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{}; Env n;   return routine_0(c,n); }
static ZIPPY_NOINLINE Space n0(Context& c, const Env& e) { auto p=n1(c,e); return unwrap(n2(c,e),p); }
static ZIPPY_NOINLINE Space n4(Context& c, const Env& e) { static const Space value=literal_text("94 4 1 3 4 5 4 1 3 7 8 4 1 3 7 13 4 1 3 8 14 4 1 3 8 26 4 1 3 9 10 4 1 3 9 19 4 1 3 10 17 4 1 3 10 20 4 1 3 11 12 4 1 3 11 23 4 1 3 12 23 4 1 3 12 27 4 1 3 13 8 4 1 3 13 14 4 1 3 14 18 4 1 3 14 26 4 1 3 15 9 4 1 3 15 25 4 1 3 16 7 4 1 3 16 22 4 1 3 17 16 4 1 3 17 21 4 1 3 18 11 4 1 3 18 28 4 1 3 19 10 4 1 3 19 20 4 1 3 20 17 4 1 3 20 21 4 1 3 21 16 4 1 3 21 22 4 1 3 22 7 4 1 3 22 13 4 1 3 23 24 4 1 3 23 27 4 1 3 24 4 4 1 3 24 29 4 1 3 25 9 4 1 3 25 19 4 1 3 26 18 4 1 3 26 28 4 1 3 27 24 4 1 3 27 29 4 1 3 28 11 4 1 3 28 12 4 1 3 29 4 4 1 3 29 5 4 6 2 4 5 4 6 2 7 8 4 6 2 7 13 4 6 2 8 14 4 6 2 8 26 4 6 2 9 10 4 6 2 9 19 4 6 2 10 17 4 6 2 10 20 4 6 2 11 12 4 6 2 11 23 4 6 2 12 23 4 6 2 12 27 4 6 2 13 8 4 6 2 13 14 4 6 2 14 18 4 6 2 14 26 4 6 2 15 9 4 6 2 15 25 4 6 2 16 7 4 6 2 16 22 4 6 2 17 16 4 6 2 17 21 4 6 2 18 11 4 6 2 18 28 4 6 2 19 10 4 6 2 19 20 4 6 2 20 17 4 6 2 20 21 4 6 2 21 16 4 6 2 21 22 4 6 2 22 7 4 6 2 22 13 4 6 2 23 24 4 6 2 23 27 4 6 2 24 4 4 6 2 24 29 4 6 2 25 9 4 6 2 25 19 4 6 2 26 18 4 6 2 26 28 4 6 2 27 24 4 6 2 27 29 4 6 2 28 11 4 6 2 28 12 4 6 2 29 4 4 6 2 29 5"); return value; }
static ZIPPY_NOINLINE Space n6(Context& c, const Env& e) { static const Space value=literal_text("184 4 1 2 4 5 4 1 2 7 8 4 1 2 7 13 4 1 2 8 14 4 1 2 8 26 4 1 2 9 10 4 1 2 9 19 4 1 2 10 17 4 1 2 10 20 4 1 2 11 12 4 1 2 11 23 4 1 2 12 23 4 1 2 12 27 4 1 2 13 8 4 1 2 13 14 4 1 2 14 18 4 1 2 14 26 4 1 2 15 9 4 1 2 15 25 4 1 2 16 7 4 1 2 16 22 4 1 2 17 16 4 1 2 17 21 4 1 2 18 11 4 1 2 18 28 4 1 2 19 10 4 1 2 19 20 4 1 2 20 17 4 1 2 20 21 4 1 2 21 16 4 1 2 21 22 4 1 2 22 7 4 1 2 22 13 4 1 2 23 24 4 1 2 23 27 4 1 2 24 4 4 1 2 24 29 4 1 2 25 9 4 1 2 25 19 4 1 2 26 18 4 1 2 26 28 4 1 2 27 24 4 1 2 27 29 4 1 2 28 11 4 1 2 28 12 4 1 2 29 4 4 1 2 29 5 4 1 3 4 5 4 1 3 7 8 4 1 3 7 13 4 1 3 8 14 4 1 3 8 26 4 1 3 9 10 4 1 3 9 19 4 1 3 10 17 4 1 3 10 20 4 1 3 11 12 4 1 3 11 23 4 1 3 12 23 4 1 3 12 27 4 1 3 13 8 4 1 3 13 14 4 1 3 14 18 4 1 3 14 26 4 1 3 15 9 4 1 3 15 25 4 1 3 16 7 4 1 3 16 22 4 1 3 17 16 4 1 3 17 21 4 1 3 18 11 4 1 3 18 28 4 1 3 19 10 4 1 3 19 20 4 1 3 20 17 4 1 3 20 21 4 1 3 21 16 4 1 3 21 22 4 1 3 22 7 4 1 3 22 13 4 1 3 23 24 4 1 3 23 27 4 1 3 24 4 4 1 3 24 29 4 1 3 25 9 4 1 3 25 19 4 1 3 26 18 4 1 3 26 28 4 1 3 27 24 4 1 3 27 29 4 1 3 28 11 4 1 3 28 12 4 1 3 29 4 4 1 3 29 5 4 6 2 4 5 4 6 2 7 8 4 6 2 7 13 4 6 2 7 14 4 6 2 7 26 4 6 2 8 14 4 6 2 8 18 4 6 2 8 26 4 6 2 8 28 4 6 2 9 10 4 6 2 9 17 4 6 2 9 19 4 6 2 9 20 4 6 2 10 16 4 6 2 10 17 4 6 2 10 20 4 6 2 10 21 4 6 2 11 12 4 6 2 11 23 4 6 2 11 24 4 6 2 11 27 4 6 2 12 23 4 6 2 12 24 4 6 2 12 27 4 6 2 12 29 4 6 2 13 8 4 6 2 13 14 4 6 2 13 18 4 6 2 13 26 4 6 2 14 11 4 6 2 14 18 4 6 2 14 26 4 6 2 14 28 4 6 2 15 9 4 6 2 15 10 4 6 2 15 19 4 6 2 15 25 4 6 2 16 7 4 6 2 16 8 4 6 2 16 13 4 6 2 16 22 4 6 2 17 7 4 6 2 17 16 4 6 2 17 21 4 6 2 17 22 4 6 2 18 11 4 6 2 18 12 4 6 2 18 23 4 6 2 18 28 4 6 2 19 10 4 6 2 19 17 4 6 2 19 20 4 6 2 19 21 4 6 2 20 16 4 6 2 20 17 4 6 2 20 21 4 6 2 20 22 4 6 2 21 7 4 6 2 21 13 4 6 2 21 16 4 6 2 21 22 4 6 2 22 7 4 6 2 22 8 4 6 2 22 13 4 6 2 22 14 4 6 2 23 4 4 6 2 23 24 4 6 2 23 27 4 6 2 23 29 4 6 2 24 4 4 6 2 24 5 4 6 2 24 29 4 6 2 25 9 4 6 2 25 10 4 6 2 25 19 4 6 2 25 20 4 6 2 26 11 4 6 2 26 12 4 6 2 26 18 4 6 2 26 28 4 6 2 27 4 4 6 2 27 5 4 6 2 27 24 4 6 2 27 29 4 6 2 28 11 4 6 2 28 12 4 6 2 28 23 4 6 2 28 27 4 6 2 29 4 4 6 2 29 5"); return value; }
static ZIPPY_NOINLINE Space n5(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n6(c,e)}; Env n; n.spaces[0]=sv[0];  return routine_1(c,n); }
static ZIPPY_NOINLINE Space n3(Context& c, const Env& e) { auto a=n4(c,e); auto b=n5(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_0(Context& c,const Env& e) { return n3(c,e); }
static ZIPPY_NOINLINE Space n8(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Path n13(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Path n16(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n17(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n15(Context& c, const Env& e) { auto p=n16(c,e); return unwrap(n17(c,e),p); }
static ZIPPY_NOINLINE Path n19(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Space n20(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n18(Context& c, const Env& e) { auto p=n19(c,e); return unwrap(n20(c,e),p); }
static ZIPPY_NOINLINE Space n14(Context& c, const Env& e) { auto a=n15(c,e); auto b=n18(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n12(Context& c, const Env& e) { auto p=n13(c,e); return wrap(n14(c,e),p); }
static ZIPPY_NOINLINE Path n22(Context& c, const Env& e) { return Path{6,2}; }
static ZIPPY_NOINLINE Path n30(Context& c, const Env& e) { return Path{3}; }
static ZIPPY_NOINLINE Path n32(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n33(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n31(Context& c, const Env& e) { auto p=n32(c,e); return unwrap(n33(c,e),p); }
static ZIPPY_NOINLINE Space n29(Context& c, const Env& e) { auto p=n30(c,e); return unwrap(n31(c,e),p); }
static ZIPPY_NOINLINE Path n35(Context& c, const Env& e) { return e.paths.at(0); }
static ZIPPY_NOINLINE Space n37(Context& c, const Env& e) { return e.spaces.at(1); }
static ZIPPY_NOINLINE Space n38(Context& c, const Env& e) { static const Space value=literal_text("1 0 "); return value; }
static ZIPPY_NOINLINE Space n36(Context& c, const Env& e) { auto a=n37(c,e); auto b=n38(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n34(Context& c, const Env& e) { auto p=n35(c,e); return wrap(n36(c,e),p); }
static ZIPPY_NOINLINE Space n28(Context& c, const Env& e) { return iterate(c,e,n29(c,e),0,1,n34); }
static ZIPPY_NOINLINE Path n41(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n43(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n44(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n42(Context& c, const Env& e) { auto p=n43(c,e); return unwrap(n44(c,e),p); }
static ZIPPY_NOINLINE Space n40(Context& c, const Env& e) { auto p=n41(c,e); return unwrap(n42(c,e),p); }
static ZIPPY_NOINLINE Path n46(Context& c, const Env& e) { return e.paths.at(1); }
static ZIPPY_NOINLINE Space n48(Context& c, const Env& e) { return e.spaces.at(2); }
static ZIPPY_NOINLINE Path n51(Context& c, const Env& e) { return e.paths.at(2); }
static ZIPPY_NOINLINE Path n53(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n55(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Space n56(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n54(Context& c, const Env& e) { auto p=n55(c,e); return unwrap(n56(c,e),p); }
static ZIPPY_NOINLINE Space n52(Context& c, const Env& e) { auto p=n53(c,e); return unwrap(n54(c,e),p); }
static ZIPPY_NOINLINE Space n50(Context& c, const Env& e) { auto p=n51(c,e); return unwrap(n52(c,e),p); }
static ZIPPY_NOINLINE Space n57(Context& c, const Env& e) { static const Space value=literal_text("1 0 "); return value; }
static ZIPPY_NOINLINE Space n49(Context& c, const Env& e) { auto a=n50(c,e); auto b=n57(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n47(Context& c, const Env& e) { return iterate(c,e,n48(c,e),2,3,n49); }
static ZIPPY_NOINLINE Space n45(Context& c, const Env& e) { auto p=n46(c,e); return wrap(n47(c,e),p); }
static ZIPPY_NOINLINE Space n39(Context& c, const Env& e) { return iterate(c,e,n40(c,e),1,2,n45); }
static ZIPPY_NOINLINE Space n27(Context& c, const Env& e) { auto a=n28(c,e); auto b=n39(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n60(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n62(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Space n63(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n61(Context& c, const Env& e) { auto p=n62(c,e); return unwrap(n63(c,e),p); }
static ZIPPY_NOINLINE Space n59(Context& c, const Env& e) { auto p=n60(c,e); return unwrap(n61(c,e),p); }
static ZIPPY_NOINLINE Path n65(Context& c, const Env& e) { return e.paths.at(3); }
static ZIPPY_NOINLINE Space n67(Context& c, const Env& e) { return e.spaces.at(4); }
static ZIPPY_NOINLINE Path n70(Context& c, const Env& e) { return e.paths.at(4); }
static ZIPPY_NOINLINE Path n72(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n74(Context& c, const Env& e) { return Path{1}; }
static ZIPPY_NOINLINE Space n75(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n73(Context& c, const Env& e) { auto p=n74(c,e); return unwrap(n75(c,e),p); }
static ZIPPY_NOINLINE Space n71(Context& c, const Env& e) { auto p=n72(c,e); return unwrap(n73(c,e),p); }
static ZIPPY_NOINLINE Space n69(Context& c, const Env& e) { auto p=n70(c,e); return unwrap(n71(c,e),p); }
static ZIPPY_NOINLINE Space n76(Context& c, const Env& e) { static const Space value=literal_text("1 0 "); return value; }
static ZIPPY_NOINLINE Space n68(Context& c, const Env& e) { auto a=n69(c,e); auto b=n76(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n66(Context& c, const Env& e) { return iterate(c,e,n67(c,e),4,5,n68); }
static ZIPPY_NOINLINE Space n64(Context& c, const Env& e) { auto p=n65(c,e); return wrap(n66(c,e),p); }
static ZIPPY_NOINLINE Space n58(Context& c, const Env& e) { return iterate(c,e,n59(c,e),3,4,n64); }
static ZIPPY_NOINLINE Space n26(Context& c, const Env& e) { auto a=n27(c,e); auto b=n58(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n79(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n81(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Space n82(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n80(Context& c, const Env& e) { auto p=n81(c,e); return unwrap(n82(c,e),p); }
static ZIPPY_NOINLINE Space n78(Context& c, const Env& e) { auto p=n79(c,e); return unwrap(n80(c,e),p); }
static ZIPPY_NOINLINE Path n84(Context& c, const Env& e) { return e.paths.at(5); }
static ZIPPY_NOINLINE Space n86(Context& c, const Env& e) { return e.spaces.at(6); }
static ZIPPY_NOINLINE Path n89(Context& c, const Env& e) { return e.paths.at(6); }
static ZIPPY_NOINLINE Path n91(Context& c, const Env& e) { return Path{2}; }
static ZIPPY_NOINLINE Path n93(Context& c, const Env& e) { return Path{6}; }
static ZIPPY_NOINLINE Space n94(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n92(Context& c, const Env& e) { auto p=n93(c,e); return unwrap(n94(c,e),p); }
static ZIPPY_NOINLINE Space n90(Context& c, const Env& e) { auto p=n91(c,e); return unwrap(n92(c,e),p); }
static ZIPPY_NOINLINE Space n88(Context& c, const Env& e) { auto p=n89(c,e); return unwrap(n90(c,e),p); }
static ZIPPY_NOINLINE Space n95(Context& c, const Env& e) { static const Space value=literal_text("1 0 "); return value; }
static ZIPPY_NOINLINE Space n87(Context& c, const Env& e) { auto a=n88(c,e); auto b=n95(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n85(Context& c, const Env& e) { return iterate(c,e,n86(c,e),6,7,n87); }
static ZIPPY_NOINLINE Space n83(Context& c, const Env& e) { auto p=n84(c,e); return wrap(n85(c,e),p); }
static ZIPPY_NOINLINE Space n77(Context& c, const Env& e) { return iterate(c,e,n78(c,e),5,6,n83); }
static ZIPPY_NOINLINE Space n25(Context& c, const Env& e) { auto a=n26(c,e); auto b=n77(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Path n97(Context& c, const Env& e) { return Path{1,2}; }
static ZIPPY_NOINLINE Space n98(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n96(Context& c, const Env& e) { auto p=n97(c,e); return unwrap(n98(c,e),p); }
static ZIPPY_NOINLINE Space n24(Context& c, const Env& e) { auto a=n25(c,e); auto b=n96(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Path n100(Context& c, const Env& e) { return Path{6,2}; }
static ZIPPY_NOINLINE Space n101(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n99(Context& c, const Env& e) { auto p=n100(c,e); return unwrap(n101(c,e),p); }
static ZIPPY_NOINLINE Space n23(Context& c, const Env& e) { auto a=n24(c,e); auto b=n99(c,e); return subtract(a,b); }
static ZIPPY_NOINLINE Space n21(Context& c, const Env& e) { auto p=n22(c,e); return wrap(n23(c,e),p); }
static ZIPPY_NOINLINE Space n11(Context& c, const Env& e) { auto a=n12(c,e); auto b=n21(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n102(Context& c, const Env& e) { return e.spaces.at(0); }
static ZIPPY_NOINLINE Space n10(Context& c, const Env& e) { auto a=n11(c,e); auto b=n102(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space n9(Context& c, const Env& e) { std::vector<Path> pv{}; std::vector<Space> sv{n10(c,e)}; Env n; n.spaces[0]=sv[0]; if(equal(n10(c,n),sv[0])) return n8(c,n); return routine_1(c,n); }
static ZIPPY_NOINLINE Space n7(Context& c, const Env& e) { auto a=n8(c,e); auto b=n9(c,e); return unite(a,b); }
static ZIPPY_NOINLINE Space routine_1(Context& c,const Env& e) { return n7(c,e); }

}

int main() {
 Context c(std::cin,std::cout);
 return run(c, [](int id, Context& c, const Env& e) -> Space {
   switch(id) { case 0: { if(c.program_id!=0) { c.program_id=0; c.native_callbacks.clear();  c.symbolic=true; configure_symbols(c,"29 1 8 99 111 109 112 108 101 116 101 2 4 112 97 116 104 3 4 101 100 103 101 4 3 110 50 51 5 3 110 50 52 6 5 100 101 108 116 97 7 3 110 49 48 8 3 110 49 50 9 2 110 50 10 2 110 52 11 3 110 49 55 12 3 110 49 56 13 3 110 49 49 14 3 110 49 51 15 2 110 48 16 2 110 56 17 2 110 54 18 3 110 49 53 19 2 110 51 20 2 110 53 21 2 110 55 22 2 110 57 23 3 110 49 57 24 3 110 50 49 25 2 110 49 26 3 110 49 52 27 3 110 50 48 28 3 110 49 54 29 3 110 50 50"); } return program_0::n0(c,e); } default: throw std::runtime_error("unknown program"); }
 });
}
